
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000045 	adrp	x5, d000 <_IO_stdin_used+0xc0>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	9107e0a5 	add	x5, x5, #0x1f8
    2b20:	f0000044 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91080084 	add	x4, x4, #0x200
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xeec0>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    2bb4:	91176000 	add	x0, x0, #0x5d8
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000042 	adrp	x2, c000 <f0+0x23d0>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	910a8042 	add	x2, x2, #0x2a0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    2cfc:	9117a000 	add	x0, x0, #0x5e8
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    2d0c:	911a2000 	add	x0, x0, #0x688
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    2d24:	91198000 	add	x0, x0, #0x660
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    2d30:	9118c000 	add	x0, x0, #0x630
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    2d3c:	91182000 	add	x0, x0, #0x608
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	f0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    2f34:	91344021 	add	x1, x1, #0xd10
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	b0000040 	adrp	x0, c000 <f0+0x23d0>
    30d0:	913d2000 	add	x0, x0, #0xf48
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    3198:	9133c021 	add	x1, x1, #0xcf0
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	b0000040 	adrp	x0, c000 <f0+0x23d0>
    31d0:	913d8000 	add	x0, x0, #0xf60
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	b0000042 	adrp	x2, c000 <f0+0x23d0>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000056 	adrp	x22, d000 <_IO_stdin_used+0xc0>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000058 	adrp	x24, d000 <_IO_stdin_used+0xc0>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	913ea042 	add	x2, x2, #0xfa8
    3260:	910002d6 	add	x22, x22, #0x0
    3264:	912a4318 	add	x24, x24, #0xa90
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	b0000059 	adrp	x25, c000 <f0+0x23d0>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	913fe323 	add	x3, x25, #0xff8
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	91004000 	add	x0, x0, #0x10
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	b0000040 	adrp	x0, c000 <f0+0x23d0>
    35f0:	913d2000 	add	x0, x0, #0xf48
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    3830:	aa1303e0 	mov	x0, x19
    3834:	91006021 	add	x1, x1, #0x18
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91008021 	add	x1, x1, #0x20
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    3860:	9100a021 	add	x1, x1, #0x28
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0xc0>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	9100c042 	add	x2, x2, #0x30
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	b0000040 	adrp	x0, c000 <f0+0x23d0>
    39d0:	913d2000 	add	x0, x0, #0xf48
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    39f0:	91010000 	add	x0, x0, #0x40
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    3a88:	91018000 	add	x0, x0, #0x60
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    3a98:	91020000 	add	x0, x0, #0x80
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc34820 	ldr	q0, [x1, #3360]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    3b98:	9102a000 	add	x0, x0, #0xa8
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	d0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    3c08:	91036000 	add	x0, x0, #0xd8
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	9104a084 	add	x4, x4, #0x128
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91050084 	add	x4, x4, #0x140
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	d0000044 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	9104c084 	add	x4, x4, #0x130
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    4028:	91174042 	add	x2, x2, #0x5d0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	b0000041 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	91052021 	add	x1, x1, #0x148
    4084:	91054000 	add	x0, x0, #0x150
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	b0000042 	adrp	x2, d000 <_IO_stdin_used+0xc0>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	9105c042 	add	x2, x2, #0x170
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    418c:	91134061 	add	x1, x3, #0x4d0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    419c:	91174262 	add	x2, x19, #0x5d0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	b0000042 	adrp	x2, d000 <_IO_stdin_used+0xc0>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    41cc:	91144021 	add	x1, x1, #0x510
    41d0:	3dc34c43 	ldr	q3, [x2, #3376]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    41fc:	91134063 	add	x3, x3, #0x4d0
    4200:	9115c084 	add	x4, x4, #0x570
    4204:	91174266 	add	x6, x19, #0x5d0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91174275 	add	x21, x19, #0x5d0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    42e8:	91088000 	add	x0, x0, #0x220
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91174273 	add	x19, x19, #0x5d0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	9101c122 	add	x2, x9, #0x70
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	9101c120 	add	x0, x9, #0x70
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	9101c129 	add	x9, x9, #0x70
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    444c:	9108c000 	add	x0, x0, #0x230
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	9108c000 	add	x0, x0, #0x230
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	9101c2d6 	add	x22, x22, #0x70
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	9108c000 	add	x0, x0, #0x230
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	9101c281 	add	x1, x20, #0x70
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	9101c280 	add	x0, x20, #0x70
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	9101c288 	add	x8, x20, #0x70
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	9101c281 	add	x1, x20, #0x70
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    473c:	91092000 	add	x0, x0, #0x248
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911742a2 	add	x2, x21, #0x5d0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    47f4:	910a8000 	add	x0, x0, #0x2a0
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911742b5 	add	x21, x21, #0x5d0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    4850:	9109e000 	add	x0, x0, #0x278
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    4860:	910b2000 	add	x0, x0, #0x2c8
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    48a0:	91174262 	add	x2, x19, #0x5d0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91174273 	add	x19, x19, #0x5d0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	b0000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    4900:	910a8000 	add	x0, x0, #0x2a0
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4920:	911742c2 	add	x2, x22, #0x5d0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911742c2 	add	x2, x22, #0x5d0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911742d6 	add	x22, x22, #0x5d0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a40:	911742b5 	add	x21, x21, #0x5d0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4b04:	911742a1 	add	x1, x21, #0x5d0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911742b5 	add	x21, x21, #0x5d0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911742a1 	add	x1, x21, #0x5d0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911742a0 	add	x0, x21, #0x5d0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911742b5 	add	x21, x21, #0x5d0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d08:	91174359 	add	x25, x26, #0x5d0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push.constprop.0>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	54000e8b 	b.lt	537c <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	aa0003e4 	mov	x4, x0
    51b8:	910003fd 	mov	x29, sp
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0003f5 	mov	x21, x0
    51c4:	aa020000 	orr	x0, x0, x2
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f7 	mov	x23, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	b6f80900 	tbz	x0, #63, 52fc <fwp_p_ad_push.constprop.0+0x158>
    51e0:	a90153f3 	stp	x19, x20, [sp, #16]
    51e4:	9360fc80 	asr	x0, x4, #32
    51e8:	b6f800c4 	tbz	x4, #63, 5200 <fwp_p_ad_push.constprop.0+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc40 	asr	x0, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5200:	97fffa6c 	bl	3bb0 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5001280 	cbnz	x0, 545c <fwp_p_ad_push.constprop.0+0x2b8>
    5210:	f9400a76 	ldr	x22, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002df 	cmp	x22, x0
    521c:	54000e2c 	b.gt	53e0 <fwp_p_ad_push.constprop.0+0x23c>
    5220:	eb3542df 	cmp	x22, w21, uxtw
    5224:	54000d4d 	b.le	53cc <fwp_p_ad_push.constprop.0+0x228>
    5228:	b7f80077 	tbnz	x23, #63, 5234 <fwp_p_ad_push.constprop.0+0x90>
    522c:	eb3742df 	cmp	x22, w23, uxtw
    5230:	54000ced 	b.le	53cc <fwp_p_ad_push.constprop.0+0x228>
    5234:	f9400678 	ldr	x24, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1802d8 	sub	x24, x22, x24
    5240:	91000701 	add	x1, x24, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000cc8 	b.hi	53e0 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    524c:	a9418274 	ldp	x20, x0, [x19, #24]
    5250:	a90573fb 	stp	x27, x28, [sp, #80]
    5254:	eb14003f 	cmp	x1, x20
    5258:	5400068d 	b.le	5328 <fwp_p_ad_push.constprop.0+0x184>
    525c:	f100029f 	cmp	x20, #0x0
    5260:	d2800803 	mov	x3, #0x40                  	// #64
    5264:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5268:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    526c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5270:	eb14003f 	cmp	x1, x20
    5274:	5400008d 	b.le	5284 <fwp_p_ad_push.constprop.0+0xe0>
    5278:	eb02029f 	cmp	x20, x2
    527c:	5400052d 	b.le	5320 <fwp_p_ad_push.constprop.0+0x17c>
    5280:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5284:	d37df299 	lsl	x25, x20, #3
    5288:	aa1903e1 	mov	x1, x25
    528c:	97fff59d 	bl	2900 <realloc@plt>
    5290:	aa0003e1 	mov	x1, x0
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_p_ad_push.constprop.0+0x250>
    5298:	f9400e62 	ldr	x2, [x19, #24]
    529c:	f9001261 	str	x1, [x19, #32]
    52a0:	f9401a60 	ldr	x0, [x19, #48]
    52a4:	d37cee9a 	lsl	x26, x20, #4
    52a8:	8b020821 	add	x1, x1, x2, lsl #2
    52ac:	f9001661 	str	x1, [x19, #40]
    52b0:	aa1a03e1 	mov	x1, x26
    52b4:	97fff593 	bl	2900 <realloc@plt>
    52b8:	aa0003e2 	mov	x2, x0
    52bc:	b40009c0 	cbz	x0, 53f4 <fwp_p_ad_push.constprop.0+0x250>
    52c0:	f9400e61 	ldr	x1, [x19, #24]
    52c4:	d37df31b 	lsl	x27, x24, #3
    52c8:	d37ef685 	lsl	x5, x20, #2
    52cc:	d37ef71c 	lsl	x28, x24, #2
    52d0:	8b190004 	add	x4, x0, x25
    52d4:	8b010c01 	add	x1, x0, x1, lsl #3
    52d8:	a9030660 	stp	x0, x1, [x19, #48]
    52dc:	b5000558 	cbnz	x24, 5384 <fwp_p_ad_push.constprop.0+0x1e0>
    52e0:	f9001e64 	str	x4, [x19, #56]
    52e4:	f9401260 	ldr	x0, [x19, #32]
    52e8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    52ec:	8b050001 	add	x1, x0, x5
    52f0:	f9000e74 	str	x20, [x19, #24]
    52f4:	f9001661 	str	x1, [x19, #40]
    52f8:	14000010 	b	5338 <fwp_p_ad_push.constprop.0+0x194>
    52fc:	9360fc40 	asr	x0, x2, #32
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	eb84801f 	cmp	x0, x4, asr #32
    5308:	54fff7c0 	b.eq	5200 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    530c:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    5310:	910ba000 	add	x0, x0, #0x2e8
    5314:	a9046bf9 	stp	x25, x26, [sp, #64]
    5318:	a90573fb 	stp	x27, x28, [sp, #80]
    531c:	97fff959 	bl	3880 <fwp_trap>
    5320:	d37ffa94 	lsl	x20, x20, #1
    5324:	17ffffd3 	b	5270 <fwp_p_ad_push.constprop.0+0xcc>
    5328:	a9428a61 	ldp	x1, x2, [x19, #40]
    532c:	d37ef71c 	lsl	x28, x24, #2
    5330:	f9401e64 	ldr	x4, [x19, #56]
    5334:	d37df31b 	lsl	x27, x24, #3
    5338:	b83c6815 	str	w21, [x0, x28]
    533c:	f10002ff 	cmp	x23, #0x0
    5340:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5344:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5348:	fc3b6849 	str	d9, [x2, x27]
    534c:	aa1602a0 	orr	x0, x21, x22
    5350:	b83c6837 	str	w23, [x1, x28]
    5354:	910006d6 	add	x22, x22, #0x1
    5358:	a94363f7 	ldp	x23, x24, [sp, #48]
    535c:	fc3b6888 	str	d8, [x4, x27]
    5360:	a94573fb 	ldp	x27, x28, [sp, #80]
    5364:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5368:	f9000a76 	str	x22, [x19, #16]
    536c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5378:	d65f03c0 	ret
    537c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5380:	d65f03c0 	ret
    5384:	eb1a033f 	cmp	x25, x26
    5388:	aa0403e0 	mov	x0, x4
    538c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5390:	aa1b03e2 	mov	x2, x27
    5394:	cb190063 	sub	x3, x3, x25
    5398:	f9003fe5 	str	x5, [sp, #120]
    539c:	97fff5c5 	bl	2ab0 <__memmove_chk@plt>
    53a0:	a9420660 	ldp	x0, x1, [x19, #32]
    53a4:	aa1c03e2 	mov	x2, x28
    53a8:	f9401a63 	ldr	x3, [x19, #48]
    53ac:	f9403fe5 	ldr	x5, [sp, #120]
    53b0:	8b190063 	add	x3, x3, x25
    53b4:	f9001e63 	str	x3, [x19, #56]
    53b8:	8b050000 	add	x0, x0, x5
    53bc:	97fff4f1 	bl	2780 <memmove@plt>
    53c0:	a9431262 	ldp	x2, x4, [x19, #48]
    53c4:	f9403fe5 	ldr	x5, [sp, #120]
    53c8:	17ffffc7 	b	52e4 <fwp_p_ad_push.constprop.0+0x140>
    53cc:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    53d0:	910e0000 	add	x0, x0, #0x380
    53d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53d8:	a90573fb 	stp	x27, x28, [sp, #80]
    53dc:	97fff929 	bl	3880 <fwp_trap>
    53e0:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    53e4:	910d8000 	add	x0, x0, #0x360
    53e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53ec:	a90573fb 	stp	x27, x28, [sp, #80]
    53f0:	97fff924 	bl	3880 <fwp_trap>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	97fff706 	bl	3010 <fwp_tape_unlink_scope>
    53fc:	f9401260 	ldr	x0, [x19, #32]
    5400:	97fff574 	bl	29d0 <free@plt>
    5404:	f9401a60 	ldr	x0, [x19, #48]
    5408:	97fff572 	bl	29d0 <free@plt>
    540c:	f9402260 	ldr	x0, [x19, #64]
    5410:	97fff570 	bl	29d0 <free@plt>
    5414:	f9000e7f 	str	xzr, [x19, #24]
    5418:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    541c:	f947e821 	ldr	x1, [x1, #4048]
    5420:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5424:	d2800262 	mov	x2, #0x13                  	// #19
    5428:	4f000400 	movi	v0.4s, #0x0
    542c:	f0000020 	adrp	x0, c000 <f0+0x23d0>
    5430:	f9400023 	ldr	x3, [x1]
    5434:	b900067f 	str	wzr, [x19, #4]
    5438:	d2800021 	mov	x1, #0x1                   	// #1
    543c:	913d2000 	add	x0, x0, #0xf48
    5440:	3c808260 	stur	q0, [x19, #8]
    5444:	ad010260 	stp	q0, q0, [x19, #32]
    5448:	97fff572 	bl	2a10 <fwrite@plt>
    544c:	d2800000 	mov	x0, #0x0                   	// #0
    5450:	97fff57c 	bl	2a40 <fflush@plt>
    5454:	52800cc0 	mov	w0, #0x66                  	// #102
    5458:	97fff58a 	bl	2a80 <_Exit@plt>
    545c:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    5460:	910cc000 	add	x0, x0, #0x330
    5464:	a9046bf9 	stp	x25, x26, [sp, #64]
    5468:	a90573fb 	stp	x27, x28, [sp, #80]
    546c:	97fff905 	bl	3880 <fwp_trap>

0000000000005470 <w120>:
    5470:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5474:	9e660003 	fmov	x3, d0
    5478:	aa0003e2 	mov	x2, x0
    547c:	910003fd 	mov	x29, sp
    5480:	6d0327e8 	stp	d8, d9, [sp, #48]
    5484:	1e604028 	fmov	d8, d1
    5488:	1e600809 	fmul	d9, d0, d0
    548c:	fd0023ea 	str	d10, [sp, #64]
    5490:	1e60400a 	fmov	d10, d0
    5494:	a90153f3 	stp	x19, x20, [sp, #16]
    5498:	aa0003f3 	mov	x19, x0
    549c:	aa0103f4 	mov	x20, x1
    54a0:	aa0303e1 	mov	x1, x3
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	97ffff3f 	bl	51a4 <fwp_p_ad_push.constprop.0>
    54ac:	1e693908 	fsub	d8, d8, d9
    54b0:	aa1403e2 	mov	x2, x20
    54b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54bc:	9e660116 	fmov	x22, d8
    54c0:	97ffff39 	bl	51a4 <fwp_p_ad_push.constprop.0>
    54c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    54c8:	aa0003e1 	mov	x1, x0
    54cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	1e6a3929 	fsub	d9, d9, d10
    54d8:	aa0103f3 	mov	x19, x1
    54dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    54e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54e4:	9e660135 	fmov	x21, d9
    54e8:	97ffff2f 	bl	51a4 <fwp_p_ad_push.constprop.0>
    54ec:	1e680908 	fmul	d8, d8, d8
    54f0:	aa0003f4 	mov	x20, x0
    54f4:	aa1603e3 	mov	x3, x22
    54f8:	aa1603e1 	mov	x1, x22
    54fc:	aa1303e2 	mov	x2, x19
    5500:	aa1303e0 	mov	x0, x19
    5504:	97ffff28 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5508:	aa0003e2 	mov	x2, x0
    550c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5510:	9e670020 	fmov	d0, x1
    5514:	9e660101 	fmov	x1, d8
    5518:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    551c:	1e600908 	fmul	d8, d8, d0
    5520:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5524:	97ffff20 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5528:	1e690929 	fmul	d9, d9, d9
    552c:	aa0003f3 	mov	x19, x0
    5530:	aa1503e3 	mov	x3, x21
    5534:	aa1503e1 	mov	x1, x21
    5538:	aa1403e2 	mov	x2, x20
    553c:	aa1403e0 	mov	x0, x20
    5540:	97ffff19 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5544:	1e692908 	fadd	d8, d8, d9
    5548:	aa1303e2 	mov	x2, x19
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa0303e1 	mov	x1, x3
    5554:	97ffff14 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5558:	aa0003e1 	mov	x1, x0
    555c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5560:	9e660100 	fmov	x0, d8
    5564:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5568:	6d4327e8 	ldp	d8, d9, [sp, #48]
    556c:	fd4023ea 	ldr	d10, [sp, #64]
    5570:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5574:	d65f03c0 	ret
    5578:	d503201f 	nop
    557c:	d503201f 	nop

0000000000005580 <w176.constprop.0>:
    5580:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5584:	910003fd 	mov	x29, sp
    5588:	a9025bf5 	stp	x21, x22, [sp, #32]
    558c:	fd001be8 	str	d8, [sp, #48]
    5590:	f9400015 	ldr	x21, [x0]
    5594:	b4000315 	cbz	x21, 55f4 <w176.constprop.0+0x74>
    5598:	2f00e408 	movi	d8, #0x0
    559c:	91002016 	add	x22, x0, #0x8
    55a0:	a90153f3 	stp	x19, x20, [sp, #16]
    55a4:	91004014 	add	x20, x0, #0x10
    55a8:	d2800013 	mov	x19, #0x0                   	// #0
    55ac:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55b0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    55b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55b8:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    55bc:	aa0303e1 	mov	x1, x3
    55c0:	1e602908 	fadd	d8, d8, d0
    55c4:	91000a73 	add	x19, x19, #0x2
    55c8:	97fffef7 	bl	51a4 <fwp_p_ad_push.constprop.0>
    55cc:	eb1302bf 	cmp	x21, x19
    55d0:	54ffff08 	b.hi	55b0 <w176.constprop.0+0x30>  // b.pmore
    55d4:	9e660102 	fmov	x2, d8
    55d8:	fd401be8 	ldr	d8, [sp, #48]
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	aa0003e1 	mov	x1, x0
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	aa0203e0 	mov	x0, x2
    55ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    55f0:	d65f03c0 	ret
    55f4:	2f00e408 	movi	d8, #0x0
    55f8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5600:	aa0003e1 	mov	x1, x0
    5604:	9e660102 	fmov	x2, d8
    5608:	fd401be8 	ldr	d8, [sp, #48]
    560c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5610:	aa0203e0 	mov	x0, x2
    5614:	d65f03c0 	ret
    5618:	d503201f 	nop
    561c:	d503201f 	nop

0000000000005620 <fwp_rc_share>:
    5620:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5624:	91174042 	add	x2, x2, #0x5d0
    5628:	f949d843 	ldr	x3, [x2, #5040]
    562c:	f949ec41 	ldr	x1, [x2, #5080]
    5630:	cb030000 	sub	x0, x0, x3
    5634:	eb01401f 	cmp	x0, x1, lsl #16
    5638:	540002c2 	b.cs	5690 <fwp_rc_share+0x70>  // b.hs, b.nlast
    563c:	d350fc01 	lsr	x1, x0, #16
    5640:	f949fc44 	ldr	x4, [x2, #5112]
    5644:	8b010821 	add	x1, x1, x1, lsl #2
    5648:	d37df021 	lsl	x1, x1, #3
    564c:	8b010083 	add	x3, x4, x1
    5650:	f9401062 	ldr	x2, [x3, #32]
    5654:	b40001e2 	cbz	x2, 5690 <fwp_rc_share+0x70>
    5658:	38616881 	ldrb	w1, [x4, x1]
    565c:	7100083f 	cmp	w1, #0x2
    5660:	540001a0 	b.eq	5694 <fwp_rc_share+0x74>  // b.none
    5664:	7100043f 	cmp	w1, #0x1
    5668:	54000141 	b.ne	5690 <fwp_rc_share+0x70>  // b.any
    566c:	29430464 	ldp	w4, w1, [x3, #24]
    5670:	92403c00 	and	x0, x0, #0xffff
    5674:	9b047c00 	mul	x0, x0, x4
    5678:	d360fc00 	lsr	x0, x0, #32
    567c:	eb01001f 	cmp	x0, x1
    5680:	54000082 	b.cs	5690 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5684:	8b000042 	add	x2, x2, x0
    5688:	39400040 	ldrb	w0, [x2]
    568c:	350000a0 	cbnz	w0, 56a0 <fwp_rc_share+0x80>
    5690:	d65f03c0 	ret
    5694:	72003c1f 	tst	w0, #0xffff
    5698:	54ffff80 	b.eq	5688 <fwp_rc_share+0x68>  // b.none
    569c:	d65f03c0 	ret
    56a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    56a4:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    56a8:	910e8000 	add	x0, x0, #0x3a0
    56ac:	910003fd 	mov	x29, sp
    56b0:	97fff874 	bl	3880 <fwp_trap>

00000000000056b4 <fwp_rc_fresh>:
    56b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    56b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    56bc:	91174063 	add	x3, x3, #0x5d0
    56c0:	910003fd 	mov	x29, sp
    56c4:	a90153f3 	stp	x19, x20, [sp, #16]
    56c8:	aa0003f3 	mov	x19, x0
    56cc:	f949d861 	ldr	x1, [x3, #5040]
    56d0:	f949ec60 	ldr	x0, [x3, #5080]
    56d4:	cb010261 	sub	x1, x19, x1
    56d8:	eb00403f 	cmp	x1, x0, lsl #16
    56dc:	54000322 	b.cs	5740 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    56e0:	d350fc22 	lsr	x2, x1, #16
    56e4:	f949fc63 	ldr	x3, [x3, #5112]
    56e8:	8b020842 	add	x2, x2, x2, lsl #2
    56ec:	d37df042 	lsl	x2, x2, #3
    56f0:	8b020060 	add	x0, x3, x2
    56f4:	f9401014 	ldr	x20, [x0, #32]
    56f8:	b4000254 	cbz	x20, 5740 <fwp_rc_fresh+0x8c>
    56fc:	38626862 	ldrb	w2, [x3, x2]
    5700:	7100085f 	cmp	w2, #0x2
    5704:	54000260 	b.eq	5750 <fwp_rc_fresh+0x9c>  // b.none
    5708:	7100045f 	cmp	w2, #0x1
    570c:	540001a1 	b.ne	5740 <fwp_rc_fresh+0x8c>  // b.any
    5710:	29430002 	ldp	w2, w0, [x0, #24]
    5714:	92403c21 	and	x1, x1, #0xffff
    5718:	9b027c21 	mul	x1, x1, x2
    571c:	d360fc21 	lsr	x1, x1, #32
    5720:	eb00003f 	cmp	x1, x0
    5724:	540000e2 	b.cs	5740 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5728:	8b010294 	add	x20, x20, x1
    572c:	39400280 	ldrb	w0, [x20]
    5730:	7103fc1f 	cmp	w0, #0xff
    5734:	540001a0 	b.eq	5768 <fwp_rc_fresh+0xb4>  // b.none
    5738:	52800020 	mov	w0, #0x1                   	// #1
    573c:	39000280 	strb	w0, [x20]
    5740:	aa1303e0 	mov	x0, x19
    5744:	a94153f3 	ldp	x19, x20, [sp, #16]
    5748:	a8c27bfd 	ldp	x29, x30, [sp], #32
    574c:	d65f03c0 	ret
    5750:	72003c3f 	tst	w1, #0xffff
    5754:	54fffec0 	b.eq	572c <fwp_rc_fresh+0x78>  // b.none
    5758:	aa1303e0 	mov	x0, x19
    575c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5760:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5764:	d65f03c0 	ret
    5768:	aa1403e0 	mov	x0, x20
    576c:	97fffc41 	bl	4870 <fwp_rc_forget_slot>
    5770:	17fffff2 	b	5738 <fwp_rc_fresh+0x84>

0000000000005774 <fwp_rc_free_arr>:
    5774:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5778:	91174063 	add	x3, x3, #0x5d0
    577c:	f949d861 	ldr	x1, [x3, #5040]
    5780:	f949ec62 	ldr	x2, [x3, #5080]
    5784:	cb010001 	sub	x1, x0, x1
    5788:	eb02403f 	cmp	x1, x2, lsl #16
    578c:	54000342 	b.cs	57f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5790:	d350fc22 	lsr	x2, x1, #16
    5794:	f949fc65 	ldr	x5, [x3, #5112]
    5798:	8b020842 	add	x2, x2, x2, lsl #2
    579c:	d37df042 	lsl	x2, x2, #3
    57a0:	8b0200a4 	add	x4, x5, x2
    57a4:	f9401083 	ldr	x3, [x4, #32]
    57a8:	b4000263 	cbz	x3, 57f4 <fwp_rc_free_arr+0x80>
    57ac:	386268a2 	ldrb	w2, [x5, x2]
    57b0:	7100085f 	cmp	w2, #0x2
    57b4:	540001c0 	b.eq	57ec <fwp_rc_free_arr+0x78>  // b.none
    57b8:	7100045f 	cmp	w2, #0x1
    57bc:	540001c1 	b.ne	57f4 <fwp_rc_free_arr+0x80>  // b.any
    57c0:	29430885 	ldp	w5, w2, [x4, #24]
    57c4:	92403c21 	and	x1, x1, #0xffff
    57c8:	9b057c21 	mul	x1, x1, x5
    57cc:	d360fc21 	lsr	x1, x1, #32
    57d0:	eb02003f 	cmp	x1, x2
    57d4:	54000102 	b.cs	57f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57d8:	8b010063 	add	x3, x3, x1
    57dc:	39400061 	ldrb	w1, [x3]
    57e0:	7100043f 	cmp	w1, #0x1
    57e4:	54000081 	b.ne	57f4 <fwp_rc_free_arr+0x80>  // b.any
    57e8:	17fffcc2 	b	4af0 <fwp_mem_free>
    57ec:	72003c3f 	tst	w1, #0xffff
    57f0:	54ffff60 	b.eq	57dc <fwp_rc_free_arr+0x68>  // b.none
    57f4:	d65f03c0 	ret
    57f8:	d503201f 	nop
    57fc:	d503201f 	nop

0000000000005800 <fwp_rc_dup>:
    5800:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5804:	91174042 	add	x2, x2, #0x5d0
    5808:	f949d841 	ldr	x1, [x2, #5040]
    580c:	f949ec43 	ldr	x3, [x2, #5080]
    5810:	cb010001 	sub	x1, x0, x1
    5814:	eb03403f 	cmp	x1, x3, lsl #16
    5818:	54000342 	b.cs	5880 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    581c:	d350fc20 	lsr	x0, x1, #16
    5820:	f949fc44 	ldr	x4, [x2, #5112]
    5824:	8b000800 	add	x0, x0, x0, lsl #2
    5828:	d37df002 	lsl	x2, x0, #3
    582c:	8b020083 	add	x3, x4, x2
    5830:	f9401060 	ldr	x0, [x3, #32]
    5834:	b4000260 	cbz	x0, 5880 <fwp_rc_dup+0x80>
    5838:	38626882 	ldrb	w2, [x4, x2]
    583c:	7100085f 	cmp	w2, #0x2
    5840:	54000220 	b.eq	5884 <fwp_rc_dup+0x84>  // b.none
    5844:	7100045f 	cmp	w2, #0x1
    5848:	540001c1 	b.ne	5880 <fwp_rc_dup+0x80>  // b.any
    584c:	29430864 	ldp	w4, w2, [x3, #24]
    5850:	92403c21 	and	x1, x1, #0xffff
    5854:	9b047c21 	mul	x1, x1, x4
    5858:	d360fc21 	lsr	x1, x1, #32
    585c:	eb02003f 	cmp	x1, x2
    5860:	54000102 	b.cs	5880 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5864:	8b010000 	add	x0, x0, x1
    5868:	39400001 	ldrb	w1, [x0]
    586c:	340000a1 	cbz	w1, 5880 <fwp_rc_dup+0x80>
    5870:	7103f43f 	cmp	w1, #0xfd
    5874:	540000e8 	b.hi	5890 <fwp_rc_dup+0x90>  // b.pmore
    5878:	11000421 	add	w1, w1, #0x1
    587c:	39000001 	strb	w1, [x0]
    5880:	d65f03c0 	ret
    5884:	72003c3f 	tst	w1, #0xffff
    5888:	54ffff00 	b.eq	5868 <fwp_rc_dup+0x68>  // b.none
    588c:	d65f03c0 	ret
    5890:	17fffbb1 	b	4754 <fwp_rc_wide_dup>

0000000000005894 <fwp_owned_entry173>:
    5894:	d10103ff 	sub	sp, sp, #0x40
    5898:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    589c:	f947f442 	ldr	x2, [x2, #4072]
    58a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    58a4:	910083fd 	add	x29, sp, #0x20
    58a8:	a90353f3 	stp	x19, x20, [sp, #48]
    58ac:	f9400043 	ldr	x3, [x2]
    58b0:	f9000fe3 	str	x3, [sp, #24]
    58b4:	d2800003 	mov	x3, #0x0                   	// #0
    58b8:	a9400c01 	ldp	x1, x3, [x0]
    58bc:	f9400802 	ldr	x2, [x0, #16]
    58c0:	ab020022 	adds	x2, x1, x2
    58c4:	540006e6 	b.vs	59a0 <fwp_owned_entry173+0x10c>
    58c8:	910023e1 	add	x1, sp, #0x8
    58cc:	52800000 	mov	w0, #0x0                   	// #0
    58d0:	a9008be3 	stp	x3, x2, [sp, #8]
    58d4:	97fffdec 	bl	5084 <fwp_data.part.0.constprop.0>
    58d8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    58dc:	91174063 	add	x3, x3, #0x5d0
    58e0:	aa0003f3 	mov	x19, x0
    58e4:	f949d861 	ldr	x1, [x3, #5040]
    58e8:	f949ec60 	ldr	x0, [x3, #5080]
    58ec:	cb010261 	sub	x1, x19, x1
    58f0:	eb00403f 	cmp	x1, x0, lsl #16
    58f4:	54000322 	b.cs	5958 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    58f8:	d350fc22 	lsr	x2, x1, #16
    58fc:	f949fc63 	ldr	x3, [x3, #5112]
    5900:	8b020842 	add	x2, x2, x2, lsl #2
    5904:	d37df042 	lsl	x2, x2, #3
    5908:	8b020060 	add	x0, x3, x2
    590c:	f9401014 	ldr	x20, [x0, #32]
    5910:	b4000254 	cbz	x20, 5958 <fwp_owned_entry173+0xc4>
    5914:	38626862 	ldrb	w2, [x3, x2]
    5918:	7100085f 	cmp	w2, #0x2
    591c:	54000360 	b.eq	5988 <fwp_owned_entry173+0xf4>  // b.none
    5920:	7100045f 	cmp	w2, #0x1
    5924:	540001a1 	b.ne	5958 <fwp_owned_entry173+0xc4>  // b.any
    5928:	29430002 	ldp	w2, w0, [x0, #24]
    592c:	92403c21 	and	x1, x1, #0xffff
    5930:	9b027c21 	mul	x1, x1, x2
    5934:	d360fc21 	lsr	x1, x1, #32
    5938:	eb00003f 	cmp	x1, x0
    593c:	540000e2 	b.cs	5958 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5940:	8b010294 	add	x20, x20, x1
    5944:	39400280 	ldrb	w0, [x20]
    5948:	7103fc1f 	cmp	w0, #0xff
    594c:	54000240 	b.eq	5994 <fwp_owned_entry173+0x100>  // b.none
    5950:	52800020 	mov	w0, #0x1                   	// #1
    5954:	39000280 	strb	w0, [x20]
    5958:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    595c:	f947f400 	ldr	x0, [x0, #4072]
    5960:	f9400fe2 	ldr	x2, [sp, #24]
    5964:	f9400001 	ldr	x1, [x0]
    5968:	eb010042 	subs	x2, x2, x1
    596c:	d2800001 	mov	x1, #0x0                   	// #0
    5970:	540001a1 	b.ne	59a4 <fwp_owned_entry173+0x110>  // b.any
    5974:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5978:	aa1303e0 	mov	x0, x19
    597c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5980:	910103ff 	add	sp, sp, #0x40
    5984:	d65f03c0 	ret
    5988:	72003c3f 	tst	w1, #0xffff
    598c:	54fffe61 	b.ne	5958 <fwp_owned_entry173+0xc4>  // b.any
    5990:	17ffffed 	b	5944 <fwp_owned_entry173+0xb0>
    5994:	aa1403e0 	mov	x0, x20
    5998:	97fffbb6 	bl	4870 <fwp_rc_forget_slot>
    599c:	17ffffed 	b	5950 <fwp_owned_entry173+0xbc>
    59a0:	97fff458 	bl	2b00 <fwp_trap_overflow.constprop.0>
    59a4:	97fff3db 	bl	2910 <__stack_chk_fail@plt>
    59a8:	d503201f 	nop
    59ac:	d503201f 	nop

00000000000059b0 <e173>:
    59b0:	d10103ff 	sub	sp, sp, #0x40
    59b4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    59b8:	f947f442 	ldr	x2, [x2, #4072]
    59bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    59c0:	910083fd 	add	x29, sp, #0x20
    59c4:	a90353f3 	stp	x19, x20, [sp, #48]
    59c8:	f9400043 	ldr	x3, [x2]
    59cc:	f9000fe3 	str	x3, [sp, #24]
    59d0:	d2800003 	mov	x3, #0x0                   	// #0
    59d4:	a9400c01 	ldp	x1, x3, [x0]
    59d8:	f9400802 	ldr	x2, [x0, #16]
    59dc:	ab020022 	adds	x2, x1, x2
    59e0:	54000726 	b.vs	5ac4 <e173+0x114>
    59e4:	910023e1 	add	x1, sp, #0x8
    59e8:	52800000 	mov	w0, #0x0                   	// #0
    59ec:	a9008be3 	stp	x3, x2, [sp, #8]
    59f0:	97fffda5 	bl	5084 <fwp_data.part.0.constprop.0>
    59f4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    59f8:	91174063 	add	x3, x3, #0x5d0
    59fc:	aa0003f3 	mov	x19, x0
    5a00:	f949d861 	ldr	x1, [x3, #5040]
    5a04:	f949ec60 	ldr	x0, [x3, #5080]
    5a08:	cb010261 	sub	x1, x19, x1
    5a0c:	eb00403f 	cmp	x1, x0, lsl #16
    5a10:	54000322 	b.cs	5a74 <e173+0xc4>  // b.hs, b.nlast
    5a14:	d350fc22 	lsr	x2, x1, #16
    5a18:	f949fc63 	ldr	x3, [x3, #5112]
    5a1c:	8b020842 	add	x2, x2, x2, lsl #2
    5a20:	d37df042 	lsl	x2, x2, #3
    5a24:	8b020060 	add	x0, x3, x2
    5a28:	f9401014 	ldr	x20, [x0, #32]
    5a2c:	b4000254 	cbz	x20, 5a74 <e173+0xc4>
    5a30:	38626862 	ldrb	w2, [x3, x2]
    5a34:	7100085f 	cmp	w2, #0x2
    5a38:	540003a0 	b.eq	5aac <e173+0xfc>  // b.none
    5a3c:	7100045f 	cmp	w2, #0x1
    5a40:	540001a1 	b.ne	5a74 <e173+0xc4>  // b.any
    5a44:	29430002 	ldp	w2, w0, [x0, #24]
    5a48:	92403c21 	and	x1, x1, #0xffff
    5a4c:	9b027c21 	mul	x1, x1, x2
    5a50:	d360fc21 	lsr	x1, x1, #32
    5a54:	eb00003f 	cmp	x1, x0
    5a58:	540000e2 	b.cs	5a74 <e173+0xc4>  // b.hs, b.nlast
    5a5c:	8b010294 	add	x20, x20, x1
    5a60:	39400280 	ldrb	w0, [x20]
    5a64:	7103fc1f 	cmp	w0, #0xff
    5a68:	54000280 	b.eq	5ab8 <e173+0x108>  // b.none
    5a6c:	52800020 	mov	w0, #0x1                   	// #1
    5a70:	39000280 	strb	w0, [x20]
    5a74:	aa1303e0 	mov	x0, x19
    5a78:	97fffeea 	bl	5620 <fwp_rc_share>
    5a7c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5a80:	f947f400 	ldr	x0, [x0, #4072]
    5a84:	f9400fe2 	ldr	x2, [sp, #24]
    5a88:	f9400001 	ldr	x1, [x0]
    5a8c:	eb010042 	subs	x2, x2, x1
    5a90:	d2800001 	mov	x1, #0x0                   	// #0
    5a94:	540001a1 	b.ne	5ac8 <e173+0x118>  // b.any
    5a98:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a9c:	aa1303e0 	mov	x0, x19
    5aa0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5aa4:	910103ff 	add	sp, sp, #0x40
    5aa8:	d65f03c0 	ret
    5aac:	72003c3f 	tst	w1, #0xffff
    5ab0:	54fffe21 	b.ne	5a74 <e173+0xc4>  // b.any
    5ab4:	17ffffeb 	b	5a60 <e173+0xb0>
    5ab8:	aa1403e0 	mov	x0, x20
    5abc:	97fffb6d 	bl	4870 <fwp_rc_forget_slot>
    5ac0:	17ffffeb 	b	5a6c <e173+0xbc>
    5ac4:	97fff40f 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5ac8:	97fff392 	bl	2910 <__stack_chk_fail@plt>
    5acc:	d503201f 	nop

0000000000005ad0 <fwp_drop0>:
    5ad0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ad4:	910003fd 	mov	x29, sp
    5ad8:	a90153f3 	stp	x19, x20, [sp, #16]
    5adc:	f90013f5 	str	x21, [sp, #32]
    5ae0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5ae4:	911742b4 	add	x20, x21, #0x5d0
    5ae8:	f949da81 	ldr	x1, [x20, #5040]
    5aec:	f949ee82 	ldr	x2, [x20, #5080]
    5af0:	cb010001 	sub	x1, x0, x1
    5af4:	eb02403f 	cmp	x1, x2, lsl #16
    5af8:	54000382 	b.cs	5b68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5afc:	d350fc22 	lsr	x2, x1, #16
    5b00:	f949fe84 	ldr	x4, [x20, #5112]
    5b04:	8b020842 	add	x2, x2, x2, lsl #2
    5b08:	d37df042 	lsl	x2, x2, #3
    5b0c:	8b020083 	add	x3, x4, x2
    5b10:	f9401073 	ldr	x19, [x3, #32]
    5b14:	b40002b3 	cbz	x19, 5b68 <fwp_drop0+0x98>
    5b18:	38626882 	ldrb	w2, [x4, x2]
    5b1c:	7100085f 	cmp	w2, #0x2
    5b20:	540002c0 	b.eq	5b78 <fwp_drop0+0xa8>  // b.none
    5b24:	7100045f 	cmp	w2, #0x1
    5b28:	54000201 	b.ne	5b68 <fwp_drop0+0x98>  // b.any
    5b2c:	29430864 	ldp	w4, w2, [x3, #24]
    5b30:	92403c21 	and	x1, x1, #0xffff
    5b34:	9b047c21 	mul	x1, x1, x4
    5b38:	d360fc21 	lsr	x1, x1, #32
    5b3c:	eb02003f 	cmp	x1, x2
    5b40:	54000142 	b.cs	5b68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b44:	8b010273 	add	x19, x19, x1
    5b48:	39400261 	ldrb	w1, [x19]
    5b4c:	340000e1 	cbz	w1, 5b68 <fwp_drop0+0x98>
    5b50:	7100043f 	cmp	w1, #0x1
    5b54:	540001e0 	b.eq	5b90 <fwp_drop0+0xc0>  // b.none
    5b58:	7103fc3f 	cmp	w1, #0xff
    5b5c:	540002e0 	b.eq	5bb8 <fwp_drop0+0xe8>  // b.none
    5b60:	51000421 	sub	w1, w1, #0x1
    5b64:	39000261 	strb	w1, [x19]
    5b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b6c:	f94013f5 	ldr	x21, [sp, #32]
    5b70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b74:	d65f03c0 	ret
    5b78:	72003c3f 	tst	w1, #0xffff
    5b7c:	54fffe60 	b.eq	5b48 <fwp_drop0+0x78>  // b.none
    5b80:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b84:	f94013f5 	ldr	x21, [sp, #32]
    5b88:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b8c:	d65f03c0 	ret
    5b90:	f9400813 	ldr	x19, [x0, #16]
    5b94:	97fffef8 	bl	5774 <fwp_rc_free_arr>
    5b98:	911742a0 	add	x0, x21, #0x5d0
    5b9c:	f949d801 	ldr	x1, [x0, #5040]
    5ba0:	f949ec00 	ldr	x0, [x0, #5080]
    5ba4:	cb010261 	sub	x1, x19, x1
    5ba8:	eb00403f 	cmp	x1, x0, lsl #16
    5bac:	54fffde2 	b.cs	5b68 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bb0:	aa1303e0 	mov	x0, x19
    5bb4:	17ffffd2 	b	5afc <fwp_drop0+0x2c>
    5bb8:	ca534660 	eor	x0, x19, x19, lsr #17
    5bbc:	911742b5 	add	x21, x21, #0x5d0
    5bc0:	ca402400 	eor	x0, x0, x0, lsr #9
    5bc4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5bc8:	f94a2400 	ldr	x0, [x0, #5192]
    5bcc:	b5000080 	cbnz	x0, 5bdc <fwp_drop0+0x10c>
    5bd0:	14000010 	b	5c10 <fwp_drop0+0x140>
    5bd4:	f9400800 	ldr	x0, [x0, #16]
    5bd8:	b40001c0 	cbz	x0, 5c10 <fwp_drop0+0x140>
    5bdc:	f9400001 	ldr	x1, [x0]
    5be0:	eb13003f 	cmp	x1, x19
    5be4:	54ffff81 	b.ne	5bd4 <fwp_drop0+0x104>  // b.any
    5be8:	f9400401 	ldr	x1, [x0, #8]
    5bec:	d1000421 	sub	x1, x1, #0x1
    5bf0:	f9000401 	str	x1, [x0, #8]
    5bf4:	f103f83f 	cmp	x1, #0xfe
    5bf8:	54fffb81 	b.ne	5b68 <fwp_drop0+0x98>  // b.any
    5bfc:	aa1303e0 	mov	x0, x19
    5c00:	97fffb1c 	bl	4870 <fwp_rc_forget_slot>
    5c04:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c08:	39000260 	strb	w0, [x19]
    5c0c:	17ffffd7 	b	5b68 <fwp_drop0+0x98>
    5c10:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    5c14:	910a8000 	add	x0, x0, #0x2a0
    5c18:	97fff71a 	bl	3880 <fwp_trap>
    5c1c:	d503201f 	nop

0000000000005c20 <fwp_drop1>:
    5c20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c24:	910003fd 	mov	x29, sp
    5c28:	a90153f3 	stp	x19, x20, [sp, #16]
    5c2c:	f90013f5 	str	x21, [sp, #32]
    5c30:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5c34:	911742b4 	add	x20, x21, #0x5d0
    5c38:	f949da81 	ldr	x1, [x20, #5040]
    5c3c:	f949ee82 	ldr	x2, [x20, #5080]
    5c40:	cb010001 	sub	x1, x0, x1
    5c44:	eb02403f 	cmp	x1, x2, lsl #16
    5c48:	54000382 	b.cs	5cb8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c4c:	d350fc22 	lsr	x2, x1, #16
    5c50:	f949fe84 	ldr	x4, [x20, #5112]
    5c54:	8b020842 	add	x2, x2, x2, lsl #2
    5c58:	d37df042 	lsl	x2, x2, #3
    5c5c:	8b020083 	add	x3, x4, x2
    5c60:	f9401073 	ldr	x19, [x3, #32]
    5c64:	b40002b3 	cbz	x19, 5cb8 <fwp_drop1+0x98>
    5c68:	38626882 	ldrb	w2, [x4, x2]
    5c6c:	7100085f 	cmp	w2, #0x2
    5c70:	540002c0 	b.eq	5cc8 <fwp_drop1+0xa8>  // b.none
    5c74:	7100045f 	cmp	w2, #0x1
    5c78:	54000201 	b.ne	5cb8 <fwp_drop1+0x98>  // b.any
    5c7c:	29430864 	ldp	w4, w2, [x3, #24]
    5c80:	92403c21 	and	x1, x1, #0xffff
    5c84:	9b047c21 	mul	x1, x1, x4
    5c88:	d360fc21 	lsr	x1, x1, #32
    5c8c:	eb02003f 	cmp	x1, x2
    5c90:	54000142 	b.cs	5cb8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c94:	8b010273 	add	x19, x19, x1
    5c98:	39400261 	ldrb	w1, [x19]
    5c9c:	340000e1 	cbz	w1, 5cb8 <fwp_drop1+0x98>
    5ca0:	7100043f 	cmp	w1, #0x1
    5ca4:	540001e0 	b.eq	5ce0 <fwp_drop1+0xc0>  // b.none
    5ca8:	7103fc3f 	cmp	w1, #0xff
    5cac:	540002e0 	b.eq	5d08 <fwp_drop1+0xe8>  // b.none
    5cb0:	51000421 	sub	w1, w1, #0x1
    5cb4:	39000261 	strb	w1, [x19]
    5cb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cbc:	f94013f5 	ldr	x21, [sp, #32]
    5cc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cc4:	d65f03c0 	ret
    5cc8:	72003c3f 	tst	w1, #0xffff
    5ccc:	54fffe60 	b.eq	5c98 <fwp_drop1+0x78>  // b.none
    5cd0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cd4:	f94013f5 	ldr	x21, [sp, #32]
    5cd8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cdc:	d65f03c0 	ret
    5ce0:	f9400813 	ldr	x19, [x0, #16]
    5ce4:	97fffea4 	bl	5774 <fwp_rc_free_arr>
    5ce8:	911742a0 	add	x0, x21, #0x5d0
    5cec:	f949d801 	ldr	x1, [x0, #5040]
    5cf0:	f949ec00 	ldr	x0, [x0, #5080]
    5cf4:	cb010261 	sub	x1, x19, x1
    5cf8:	eb00403f 	cmp	x1, x0, lsl #16
    5cfc:	54fffde2 	b.cs	5cb8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d00:	aa1303e0 	mov	x0, x19
    5d04:	17ffffd2 	b	5c4c <fwp_drop1+0x2c>
    5d08:	ca534660 	eor	x0, x19, x19, lsr #17
    5d0c:	911742b5 	add	x21, x21, #0x5d0
    5d10:	ca402400 	eor	x0, x0, x0, lsr #9
    5d14:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5d18:	f94a2400 	ldr	x0, [x0, #5192]
    5d1c:	b5000080 	cbnz	x0, 5d2c <fwp_drop1+0x10c>
    5d20:	14000010 	b	5d60 <fwp_drop1+0x140>
    5d24:	f9400800 	ldr	x0, [x0, #16]
    5d28:	b40001c0 	cbz	x0, 5d60 <fwp_drop1+0x140>
    5d2c:	f9400001 	ldr	x1, [x0]
    5d30:	eb13003f 	cmp	x1, x19
    5d34:	54ffff81 	b.ne	5d24 <fwp_drop1+0x104>  // b.any
    5d38:	f9400401 	ldr	x1, [x0, #8]
    5d3c:	d1000421 	sub	x1, x1, #0x1
    5d40:	f9000401 	str	x1, [x0, #8]
    5d44:	f103f83f 	cmp	x1, #0xfe
    5d48:	54fffb81 	b.ne	5cb8 <fwp_drop1+0x98>  // b.any
    5d4c:	aa1303e0 	mov	x0, x19
    5d50:	97fffac8 	bl	4870 <fwp_rc_forget_slot>
    5d54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d58:	39000260 	strb	w0, [x19]
    5d5c:	17ffffd7 	b	5cb8 <fwp_drop1+0x98>
    5d60:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    5d64:	910a8000 	add	x0, x0, #0x2a0
    5d68:	97fff6c6 	bl	3880 <fwp_trap>
    5d6c:	d503201f 	nop

0000000000005d70 <fwp_closure_drop>:
    5d70:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5d74:	911740a4 	add	x4, x5, #0x5d0
    5d78:	aa0003e1 	mov	x1, x0
    5d7c:	f949d882 	ldr	x2, [x4, #5040]
    5d80:	f949ec80 	ldr	x0, [x4, #5080]
    5d84:	cb020022 	sub	x2, x1, x2
    5d88:	eb00405f 	cmp	x2, x0, lsl #16
    5d8c:	54000662 	b.cs	5e58 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5d90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d94:	d350fc43 	lsr	x3, x2, #16
    5d98:	910003fd 	mov	x29, sp
    5d9c:	8b030863 	add	x3, x3, x3, lsl #2
    5da0:	f949fc84 	ldr	x4, [x4, #5112]
    5da4:	d37df063 	lsl	x3, x3, #3
    5da8:	f9000bf3 	str	x19, [sp, #16]
    5dac:	8b030080 	add	x0, x4, x3
    5db0:	f9401013 	ldr	x19, [x0, #32]
    5db4:	b40002b3 	cbz	x19, 5e08 <fwp_closure_drop+0x98>
    5db8:	38636883 	ldrb	w3, [x4, x3]
    5dbc:	7100087f 	cmp	w3, #0x2
    5dc0:	54000420 	b.eq	5e44 <fwp_closure_drop+0xd4>  // b.none
    5dc4:	7100047f 	cmp	w3, #0x1
    5dc8:	54000201 	b.ne	5e08 <fwp_closure_drop+0x98>  // b.any
    5dcc:	29430003 	ldp	w3, w0, [x0, #24]
    5dd0:	92403c42 	and	x2, x2, #0xffff
    5dd4:	9b037c42 	mul	x2, x2, x3
    5dd8:	d360fc42 	lsr	x2, x2, #32
    5ddc:	eb00005f 	cmp	x2, x0
    5de0:	54000142 	b.cs	5e08 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5de4:	8b020273 	add	x19, x19, x2
    5de8:	39400260 	ldrb	w0, [x19]
    5dec:	340000e0 	cbz	w0, 5e08 <fwp_closure_drop+0x98>
    5df0:	7100041f 	cmp	w0, #0x1
    5df4:	54000100 	b.eq	5e14 <fwp_closure_drop+0xa4>  // b.none
    5df8:	7103fc1f 	cmp	w0, #0xff
    5dfc:	54000300 	b.eq	5e5c <fwp_closure_drop+0xec>  // b.none
    5e00:	51000400 	sub	w0, w0, #0x1
    5e04:	39000260 	strb	w0, [x19]
    5e08:	f9400bf3 	ldr	x19, [sp, #16]
    5e0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e10:	d65f03c0 	ret
    5e14:	d53bd040 	mrs	x0, tpidr_el0
    5e18:	91400000 	add	x0, x0, #0x0, lsl #12
    5e1c:	91004000 	add	x0, x0, #0x10
    5e20:	f9400000 	ldr	x0, [x0]
    5e24:	b4000080 	cbz	x0, 5e34 <fwp_closure_drop+0xc4>
    5e28:	f9400bf3 	ldr	x19, [sp, #16]
    5e2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e30:	17fff6ad 	b	38e4 <fwp_closure_drop_push>
    5e34:	f9400bf3 	ldr	x19, [sp, #16]
    5e38:	aa0103e0 	mov	x0, x1
    5e3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e40:	17fff718 	b	3aa0 <fwp_closure_drop.part.0>
    5e44:	72003c5f 	tst	w2, #0xffff
    5e48:	54fffd00 	b.eq	5de8 <fwp_closure_drop+0x78>  // b.none
    5e4c:	f9400bf3 	ldr	x19, [sp, #16]
    5e50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e54:	d65f03c0 	ret
    5e58:	d65f03c0 	ret
    5e5c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e60:	911740a5 	add	x5, x5, #0x5d0
    5e64:	ca402400 	eor	x0, x0, x0, lsr #9
    5e68:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5e6c:	f94a2400 	ldr	x0, [x0, #5192]
    5e70:	b5000080 	cbnz	x0, 5e80 <fwp_closure_drop+0x110>
    5e74:	14000010 	b	5eb4 <fwp_closure_drop+0x144>
    5e78:	f9400800 	ldr	x0, [x0, #16]
    5e7c:	b40001c0 	cbz	x0, 5eb4 <fwp_closure_drop+0x144>
    5e80:	f9400001 	ldr	x1, [x0]
    5e84:	eb13003f 	cmp	x1, x19
    5e88:	54ffff81 	b.ne	5e78 <fwp_closure_drop+0x108>  // b.any
    5e8c:	f9400401 	ldr	x1, [x0, #8]
    5e90:	d1000421 	sub	x1, x1, #0x1
    5e94:	f9000401 	str	x1, [x0, #8]
    5e98:	f103f83f 	cmp	x1, #0xfe
    5e9c:	54fffb61 	b.ne	5e08 <fwp_closure_drop+0x98>  // b.any
    5ea0:	aa1303e0 	mov	x0, x19
    5ea4:	97fffa73 	bl	4870 <fwp_rc_forget_slot>
    5ea8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5eac:	39000260 	strb	w0, [x19]
    5eb0:	17ffffd6 	b	5e08 <fwp_closure_drop+0x98>
    5eb4:	90000040 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    5eb8:	910a8000 	add	x0, x0, #0x2a0
    5ebc:	97fff671 	bl	3880 <fwp_trap>

0000000000005ec0 <fwp_owned_tape_release>:
    5ec0:	b4000940 	cbz	x0, 5fe8 <fwp_owned_tape_release+0x128>
    5ec4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ec8:	910003fd 	mov	x29, sp
    5ecc:	a90153f3 	stp	x19, x20, [sp, #16]
    5ed0:	aa0003f3 	mov	x19, x0
    5ed4:	f9400000 	ldr	x0, [x0]
    5ed8:	b4000060 	cbz	x0, 5ee4 <fwp_owned_tape_release+0x24>
    5edc:	f9400661 	ldr	x1, [x19, #8]
    5ee0:	f9000401 	str	x1, [x0, #8]
    5ee4:	f9400661 	ldr	x1, [x19, #8]
    5ee8:	b4000041 	cbz	x1, 5ef0 <fwp_owned_tape_release+0x30>
    5eec:	f9000020 	str	x0, [x1]
    5ef0:	f9400a60 	ldr	x0, [x19, #16]
    5ef4:	f9403401 	ldr	x1, [x0, #104]
    5ef8:	b40005c1 	cbz	x1, 5fb0 <fwp_owned_tape_release+0xf0>
    5efc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5f00:	eb00005f 	cmp	x2, x0
    5f04:	540002ed 	b.le	5f60 <fwp_owned_tape_release+0xa0>
    5f08:	d2800014 	mov	x20, #0x0                   	// #0
    5f0c:	f90013f5 	str	x21, [sp, #32]
    5f10:	d2800015 	mov	x21, #0x0                   	// #0
    5f14:	d503201f 	nop
    5f18:	f9402260 	ldr	x0, [x19, #64]
    5f1c:	910006b5 	add	x21, x21, #0x1
    5f20:	f8746800 	ldr	x0, [x0, x20]
    5f24:	d63f0020 	blr	x1
    5f28:	f9402260 	ldr	x0, [x19, #64]
    5f2c:	f9400a61 	ldr	x1, [x19, #16]
    5f30:	8b140000 	add	x0, x0, x20
    5f34:	91004294 	add	x20, x20, #0x10
    5f38:	f9400400 	ldr	x0, [x0, #8]
    5f3c:	f9403421 	ldr	x1, [x1, #104]
    5f40:	d63f0020 	blr	x1
    5f44:	a9450261 	ldp	x1, x0, [x19, #80]
    5f48:	cb010000 	sub	x0, x0, x1
    5f4c:	eb15001f 	cmp	x0, x21
    5f50:	f9400a60 	ldr	x0, [x19, #16]
    5f54:	f9403401 	ldr	x1, [x0, #104]
    5f58:	54fffe0c 	b.gt	5f18 <fwp_owned_tape_release+0x58>
    5f5c:	f94013f5 	ldr	x21, [sp, #32]
    5f60:	f9403663 	ldr	x3, [x19, #104]
    5f64:	f9401262 	ldr	x2, [x19, #32]
    5f68:	f100007f 	cmp	x3, #0x0
    5f6c:	540001ed 	b.le	5fa8 <fwp_owned_tape_release+0xe8>
    5f70:	d2800014 	mov	x20, #0x0                   	// #0
    5f74:	d503201f 	nop
    5f78:	f9402660 	ldr	x0, [x19, #72]
    5f7c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5f80:	eb02001f 	cmp	x0, x2
    5f84:	540000c0 	b.eq	5f9c <fwp_owned_tape_release+0xdc>  // b.none
    5f88:	d63f0020 	blr	x1
    5f8c:	f9400a60 	ldr	x0, [x19, #16]
    5f90:	f9401262 	ldr	x2, [x19, #32]
    5f94:	f9403663 	ldr	x3, [x19, #104]
    5f98:	f9403401 	ldr	x1, [x0, #104]
    5f9c:	91000694 	add	x20, x20, #0x1
    5fa0:	eb14007f 	cmp	x3, x20
    5fa4:	54fffeac 	b.gt	5f78 <fwp_owned_tape_release+0xb8>
    5fa8:	aa0203e0 	mov	x0, x2
    5fac:	d63f0020 	blr	x1
    5fb0:	f9401660 	ldr	x0, [x19, #40]
    5fb4:	97ffff6f 	bl	5d70 <fwp_closure_drop>
    5fb8:	f9401a60 	ldr	x0, [x19, #48]
    5fbc:	97ffff6d 	bl	5d70 <fwp_closure_drop>
    5fc0:	f9401e60 	ldr	x0, [x19, #56]
    5fc4:	97ffff6b 	bl	5d70 <fwp_closure_drop>
    5fc8:	f9402260 	ldr	x0, [x19, #64]
    5fcc:	97fffac9 	bl	4af0 <fwp_mem_free>
    5fd0:	f9402660 	ldr	x0, [x19, #72]
    5fd4:	97fffac7 	bl	4af0 <fwp_mem_free>
    5fd8:	aa1303e0 	mov	x0, x19
    5fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fe0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fe4:	17fffac3 	b	4af0 <fwp_mem_free>
    5fe8:	d65f03c0 	ret
    5fec:	d503201f 	nop

0000000000005ff0 <fwp_tape_finish>:
    5ff0:	d10203ff 	sub	sp, sp, #0x80
    5ff4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5ff8:	f947f421 	ldr	x1, [x1, #4072]
    5ffc:	a9047bfd 	stp	x29, x30, [sp, #64]
    6000:	910103fd 	add	x29, sp, #0x40
    6004:	a90553f3 	stp	x19, x20, [sp, #80]
    6008:	a9065bf5 	stp	x21, x22, [sp, #96]
    600c:	a90763f7 	stp	x23, x24, [sp, #112]
    6010:	d00000d8 	adrp	x24, 20000 <__data_start>
    6014:	9101c316 	add	x22, x24, #0x70
    6018:	f9400022 	ldr	x2, [x1]
    601c:	f9001fe2 	str	x2, [sp, #56]
    6020:	d2800002 	mov	x2, #0x0                   	// #0
    6024:	910262c0 	add	x0, x22, #0x98
    6028:	97fff536 	bl	3500 <fwp_tape_buffers_dispose>
    602c:	f9006adf 	str	xzr, [x22, #208]
    6030:	f9404ac0 	ldr	x0, [x22, #144]
    6034:	f100001f 	cmp	x0, #0x0
    6038:	5400030d 	b.le	6098 <fwp_tape_finish+0xa8>
    603c:	910003f7 	mov	x23, sp
    6040:	d2800015 	mov	x21, #0x0                   	// #0
    6044:	d2800014 	mov	x20, #0x0                   	// #0
    6048:	f94002d3 	ldr	x19, [x22]
    604c:	91000694 	add	x20, x20, #0x1
    6050:	8b150273 	add	x19, x19, x21
    6054:	9101a2b5 	add	x21, x21, #0x68
    6058:	aa1303e0 	mov	x0, x19
    605c:	97fff3ed 	bl	3010 <fwp_tape_unlink_scope>
    6060:	aa1703e0 	mov	x0, x23
    6064:	f9401261 	ldr	x1, [x19, #32]
    6068:	f90003e1 	str	x1, [sp]
    606c:	f9401a62 	ldr	x2, [x19, #48]
    6070:	f9000be2 	str	x2, [sp, #16]
    6074:	f9402261 	ldr	x1, [x19, #64]
    6078:	f90013e1 	str	x1, [sp, #32]
    607c:	97fff521 	bl	3500 <fwp_tape_buffers_dispose>
    6080:	f9403260 	ldr	x0, [x19, #96]
    6084:	97ffff8f 	bl	5ec0 <fwp_owned_tape_release>
    6088:	f900327f 	str	xzr, [x19, #96]
    608c:	f9404ac0 	ldr	x0, [x22, #144]
    6090:	eb14001f 	cmp	x0, x20
    6094:	54fffdac 	b.gt	6048 <fwp_tape_finish+0x58>
    6098:	f9403b00 	ldr	x0, [x24, #112]
    609c:	9101c313 	add	x19, x24, #0x70
    60a0:	97fff24c 	bl	29d0 <free@plt>
    60a4:	f9003b1f 	str	xzr, [x24, #112]
    60a8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    60ac:	f947f400 	ldr	x0, [x0, #4072]
    60b0:	f9004a7f 	str	xzr, [x19, #144]
    60b4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    60b8:	f9401fe2 	ldr	x2, [sp, #56]
    60bc:	f9400001 	ldr	x1, [x0]
    60c0:	eb010042 	subs	x2, x2, x1
    60c4:	d2800001 	mov	x1, #0x0                   	// #0
    60c8:	540000e1 	b.ne	60e4 <fwp_tape_finish+0xf4>  // b.any
    60cc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60d0:	a94553f3 	ldp	x19, x20, [sp, #80]
    60d4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60d8:	a94763f7 	ldp	x23, x24, [sp, #112]
    60dc:	910203ff 	add	sp, sp, #0x80
    60e0:	d65f03c0 	ret
    60e4:	97fff20b 	bl	2910 <__stack_chk_fail@plt>
    60e8:	d503201f 	nop
    60ec:	d503201f 	nop

00000000000060f0 <fwp_tape_scope_release>:
    60f0:	d10243ff 	sub	sp, sp, #0x90
    60f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    60f8:	910103fd 	add	x29, sp, #0x40
    60fc:	a90553f3 	stp	x19, x20, [sp, #80]
    6100:	aa0003f4 	mov	x20, x0
    6104:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6108:	f947f400 	ldr	x0, [x0, #4072]
    610c:	b9400285 	ldr	w5, [x20]
    6110:	f9400001 	ldr	x1, [x0]
    6114:	f9001fe1 	str	x1, [sp, #56]
    6118:	d2800001 	mov	x1, #0x0                   	// #0
    611c:	37f806c5 	tbnz	w5, #31, 61f4 <fwp_tape_scope_release+0x104>
    6120:	a90763f7 	stp	x23, x24, [sp, #112]
    6124:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6128:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    612c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6130:	d00000d3 	adrp	x19, 20000 <__data_start>
    6134:	910003f7 	mov	x23, sp
    6138:	9101c273 	add	x19, x19, #0x70
    613c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6140:	a9065bf5 	stp	x21, x22, [sp, #96]
    6144:	52800d16 	mov	w22, #0x68                  	// #104
    6148:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    614c:	f90043f9 	str	x25, [sp, #128]
    6150:	14000006 	b	6168 <fwp_tape_scope_release+0x78>
    6154:	97fff4eb 	bl	3500 <fwp_tape_buffers_dispose>
    6158:	aa1903e0 	mov	x0, x25
    615c:	97ffff59 	bl	5ec0 <fwp_owned_tape_release>
    6160:	b9400285 	ldr	w5, [x20]
    6164:	37f80425 	tbnz	w5, #31, 61e8 <fwp_tape_scope_release+0xf8>
    6168:	f9400266 	ldr	x6, [x19]
    616c:	9b367ca5 	smull	x5, w5, w22
    6170:	8b0500c0 	add	x0, x6, x5
    6174:	97fff3a7 	bl	3010 <fwp_tape_unlink_scope>
    6178:	ad410001 	ldp	q1, q0, [x0, #32]
    617c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6180:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6184:	f9400c03 	ldr	x3, [x0, #24]
    6188:	ad0003e1 	stp	q1, q0, [sp]
    618c:	b86568c1 	ldr	w1, [x6, x5]
    6190:	a9440804 	ldp	x4, x2, [x0, #64]
    6194:	b900041f 	str	wzr, [x0, #4]
    6198:	f9403019 	ldr	x25, [x0, #96]
    619c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    61a0:	f9000c1f 	str	xzr, [x0, #24]
    61a4:	a9020fe4 	stp	x4, x3, [sp, #32]
    61a8:	f9001be2 	str	x2, [sp, #48]
    61ac:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    61b0:	f900301f 	str	xzr, [x0, #96]
    61b4:	6b15003f 	cmp	w1, w21
    61b8:	540000e8 	b.hi	61d4 <fwp_tape_scope_release+0xe4>  // b.pmore
    61bc:	9343fca5 	asr	x5, x5, #3
    61c0:	f9407660 	ldr	x0, [x19, #232]
    61c4:	9b187ca5 	mul	x5, x5, x24
    61c8:	eb0000bf 	cmp	x5, x0
    61cc:	5400004a 	b.ge	61d4 <fwp_tape_scope_release+0xe4>  // b.tcont
    61d0:	f9007665 	str	x5, [x19, #232]
    61d4:	aa1703e0 	mov	x0, x23
    61d8:	b5fffbf9 	cbnz	x25, 6154 <fwp_tape_scope_release+0x64>
    61dc:	97fff889 	bl	4400 <fwp_tape_buffers_release>
    61e0:	b9400285 	ldr	w5, [x20]
    61e4:	36fffc25 	tbz	w5, #31, 6168 <fwp_tape_scope_release+0x78>
    61e8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61ec:	a94763f7 	ldp	x23, x24, [sp, #112]
    61f0:	f94043f9 	ldr	x25, [sp, #128]
    61f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61f8:	f947f400 	ldr	x0, [x0, #4072]
    61fc:	f9401fe2 	ldr	x2, [sp, #56]
    6200:	f9400001 	ldr	x1, [x0]
    6204:	eb010042 	subs	x2, x2, x1
    6208:	d2800001 	mov	x1, #0x0                   	// #0
    620c:	540000a1 	b.ne	6220 <fwp_tape_scope_release+0x130>  // b.any
    6210:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6214:	a94553f3 	ldp	x19, x20, [sp, #80]
    6218:	910243ff 	add	sp, sp, #0x90
    621c:	d65f03c0 	ret
    6220:	a9065bf5 	stp	x21, x22, [sp, #96]
    6224:	a90763f7 	stp	x23, x24, [sp, #112]
    6228:	f90043f9 	str	x25, [sp, #128]
    622c:	97fff1b9 	bl	2910 <__stack_chk_fail@plt>

0000000000006230 <fwp_drop4>:
    6230:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6234:	910003fd 	mov	x29, sp
    6238:	a9025bf5 	stp	x21, x22, [sp, #32]
    623c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6240:	911742d5 	add	x21, x22, #0x5d0
    6244:	a90153f3 	stp	x19, x20, [sp, #16]
    6248:	aa0003f3 	mov	x19, x0
    624c:	f949daa1 	ldr	x1, [x21, #5040]
    6250:	f949eea0 	ldr	x0, [x21, #5080]
    6254:	cb010261 	sub	x1, x19, x1
    6258:	eb00403f 	cmp	x1, x0, lsl #16
    625c:	54000382 	b.cs	62cc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6260:	d350fc22 	lsr	x2, x1, #16
    6264:	f949fea3 	ldr	x3, [x21, #5112]
    6268:	8b020842 	add	x2, x2, x2, lsl #2
    626c:	d37df042 	lsl	x2, x2, #3
    6270:	8b020060 	add	x0, x3, x2
    6274:	f9401014 	ldr	x20, [x0, #32]
    6278:	b40002b4 	cbz	x20, 62cc <fwp_drop4+0x9c>
    627c:	38626862 	ldrb	w2, [x3, x2]
    6280:	7100085f 	cmp	w2, #0x2
    6284:	540002c0 	b.eq	62dc <fwp_drop4+0xac>  // b.none
    6288:	7100045f 	cmp	w2, #0x1
    628c:	54000201 	b.ne	62cc <fwp_drop4+0x9c>  // b.any
    6290:	29430002 	ldp	w2, w0, [x0, #24]
    6294:	92403c21 	and	x1, x1, #0xffff
    6298:	9b027c21 	mul	x1, x1, x2
    629c:	d360fc21 	lsr	x1, x1, #32
    62a0:	eb00003f 	cmp	x1, x0
    62a4:	54000142 	b.cs	62cc <fwp_drop4+0x9c>  // b.hs, b.nlast
    62a8:	8b010294 	add	x20, x20, x1
    62ac:	39400280 	ldrb	w0, [x20]
    62b0:	340000e0 	cbz	w0, 62cc <fwp_drop4+0x9c>
    62b4:	7100041f 	cmp	w0, #0x1
    62b8:	540001e0 	b.eq	62f4 <fwp_drop4+0xc4>  // b.none
    62bc:	7103fc1f 	cmp	w0, #0xff
    62c0:	540007c0 	b.eq	63b8 <fwp_drop4+0x188>  // b.none
    62c4:	51000400 	sub	w0, w0, #0x1
    62c8:	39000280 	strb	w0, [x20]
    62cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    62d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62d8:	d65f03c0 	ret
    62dc:	72003c3f 	tst	w1, #0xffff
    62e0:	54fffe60 	b.eq	62ac <fwp_drop4+0x7c>  // b.none
    62e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    62e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62f0:	d65f03c0 	ret
    62f4:	911742c2 	add	x2, x22, #0x5d0
    62f8:	f9400660 	ldr	x0, [x19, #8]
    62fc:	f949d841 	ldr	x1, [x2, #5040]
    6300:	f949ec42 	ldr	x2, [x2, #5080]
    6304:	cb010001 	sub	x1, x0, x1
    6308:	eb02403f 	cmp	x1, x2, lsl #16
    630c:	54000362 	b.cs	6378 <fwp_drop4+0x148>  // b.hs, b.nlast
    6310:	d350fc22 	lsr	x2, x1, #16
    6314:	8b020842 	add	x2, x2, x2, lsl #2
    6318:	d37df042 	lsl	x2, x2, #3
    631c:	8b020064 	add	x4, x3, x2
    6320:	f9401094 	ldr	x20, [x4, #32]
    6324:	b40002b4 	cbz	x20, 6378 <fwp_drop4+0x148>
    6328:	38626862 	ldrb	w2, [x3, x2]
    632c:	7100085f 	cmp	w2, #0x2
    6330:	540003e0 	b.eq	63ac <fwp_drop4+0x17c>  // b.none
    6334:	7100045f 	cmp	w2, #0x1
    6338:	54000201 	b.ne	6378 <fwp_drop4+0x148>  // b.any
    633c:	29430883 	ldp	w3, w2, [x4, #24]
    6340:	92403c21 	and	x1, x1, #0xffff
    6344:	9b037c21 	mul	x1, x1, x3
    6348:	d360fc21 	lsr	x1, x1, #32
    634c:	eb02003f 	cmp	x1, x2
    6350:	54000142 	b.cs	6378 <fwp_drop4+0x148>  // b.hs, b.nlast
    6354:	8b010294 	add	x20, x20, x1
    6358:	39400281 	ldrb	w1, [x20]
    635c:	340000e1 	cbz	w1, 6378 <fwp_drop4+0x148>
    6360:	7100043f 	cmp	w1, #0x1
    6364:	54000200 	b.eq	63a4 <fwp_drop4+0x174>  // b.none
    6368:	7103fc3f 	cmp	w1, #0xff
    636c:	54000580 	b.eq	641c <fwp_drop4+0x1ec>  // b.none
    6370:	51000421 	sub	w1, w1, #0x1
    6374:	39000281 	strb	w1, [x20]
    6378:	f9400a74 	ldr	x20, [x19, #16]
    637c:	aa1303e0 	mov	x0, x19
    6380:	97fffcfd 	bl	5774 <fwp_rc_free_arr>
    6384:	911742c0 	add	x0, x22, #0x5d0
    6388:	f949d801 	ldr	x1, [x0, #5040]
    638c:	f949ec00 	ldr	x0, [x0, #5080]
    6390:	cb010281 	sub	x1, x20, x1
    6394:	eb00403f 	cmp	x1, x0, lsl #16
    6398:	54fff9a2 	b.cs	62cc <fwp_drop4+0x9c>  // b.hs, b.nlast
    639c:	aa1403f3 	mov	x19, x20
    63a0:	17ffffb0 	b	6260 <fwp_drop4+0x30>
    63a4:	97fffcf4 	bl	5774 <fwp_rc_free_arr>
    63a8:	17fffff4 	b	6378 <fwp_drop4+0x148>
    63ac:	72003c3f 	tst	w1, #0xffff
    63b0:	54fffe41 	b.ne	6378 <fwp_drop4+0x148>  // b.any
    63b4:	17ffffe9 	b	6358 <fwp_drop4+0x128>
    63b8:	ca544681 	eor	x1, x20, x20, lsr #17
    63bc:	911742c0 	add	x0, x22, #0x5d0
    63c0:	ca412421 	eor	x1, x1, x1, lsr #9
    63c4:	8b210c01 	add	x1, x0, w1, uxtb #3
    63c8:	f94a2420 	ldr	x0, [x1, #5192]
    63cc:	b5000080 	cbnz	x0, 63dc <fwp_drop4+0x1ac>
    63d0:	14000010 	b	6410 <fwp_drop4+0x1e0>
    63d4:	f9400800 	ldr	x0, [x0, #16]
    63d8:	b40001c0 	cbz	x0, 6410 <fwp_drop4+0x1e0>
    63dc:	f9400001 	ldr	x1, [x0]
    63e0:	eb14003f 	cmp	x1, x20
    63e4:	54ffff81 	b.ne	63d4 <fwp_drop4+0x1a4>  // b.any
    63e8:	f9400401 	ldr	x1, [x0, #8]
    63ec:	d1000421 	sub	x1, x1, #0x1
    63f0:	f9000401 	str	x1, [x0, #8]
    63f4:	f103f83f 	cmp	x1, #0xfe
    63f8:	54fff6a1 	b.ne	62cc <fwp_drop4+0x9c>  // b.any
    63fc:	aa1403e0 	mov	x0, x20
    6400:	97fff91c 	bl	4870 <fwp_rc_forget_slot>
    6404:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6408:	39000280 	strb	w0, [x20]
    640c:	17ffffb0 	b	62cc <fwp_drop4+0x9c>
    6410:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    6414:	910a8000 	add	x0, x0, #0x2a0
    6418:	97fff51a 	bl	3880 <fwp_trap>
    641c:	ca544680 	eor	x0, x20, x20, lsr #17
    6420:	911742c1 	add	x1, x22, #0x5d0
    6424:	ca402400 	eor	x0, x0, x0, lsr #9
    6428:	8b200c20 	add	x0, x1, w0, uxtb #3
    642c:	f94a2400 	ldr	x0, [x0, #5192]
    6430:	b5000080 	cbnz	x0, 6440 <fwp_drop4+0x210>
    6434:	17fffff7 	b	6410 <fwp_drop4+0x1e0>
    6438:	f9400800 	ldr	x0, [x0, #16]
    643c:	b4fffea0 	cbz	x0, 6410 <fwp_drop4+0x1e0>
    6440:	f9400001 	ldr	x1, [x0]
    6444:	eb14003f 	cmp	x1, x20
    6448:	54ffff81 	b.ne	6438 <fwp_drop4+0x208>  // b.any
    644c:	f9400401 	ldr	x1, [x0, #8]
    6450:	d1000421 	sub	x1, x1, #0x1
    6454:	f9000401 	str	x1, [x0, #8]
    6458:	f103f83f 	cmp	x1, #0xfe
    645c:	54fff8e1 	b.ne	6378 <fwp_drop4+0x148>  // b.any
    6460:	aa1403e0 	mov	x0, x20
    6464:	97fff903 	bl	4870 <fwp_rc_forget_slot>
    6468:	12800020 	mov	w0, #0xfffffffe            	// #-2
    646c:	39000280 	strb	w0, [x20]
    6470:	17ffffc2 	b	6378 <fwp_drop4+0x148>

0000000000006474 <fwp_arg_drop37>:
    6474:	7100003f 	cmp	w1, #0x0
    6478:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    647c:	54000041 	b.ne	6484 <fwp_arg_drop37+0x10>  // b.any
    6480:	d65f03c0 	ret
    6484:	f9400000 	ldr	x0, [x0]
    6488:	17ffff6a 	b	6230 <fwp_drop4>
    648c:	d503201f 	nop

0000000000006490 <fwp_task_dispose>:
    6490:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6494:	910003fd 	mov	x29, sp
    6498:	f9000bf3 	str	x19, [sp, #16]
    649c:	aa0003f3 	mov	x19, x0
    64a0:	39414000 	ldrb	w0, [x0, #80]
    64a4:	36000720 	tbz	w0, #0, 6588 <fwp_task_dispose+0xf8>
    64a8:	f9400a60 	ldr	x0, [x19, #16]
    64ac:	b50006e0 	cbnz	x0, 6588 <fwp_task_dispose+0xf8>
    64b0:	a9478660 	ldp	x0, x1, [x19, #120]
    64b4:	39014e7f 	strb	wzr, [x19, #83]
    64b8:	f9003e7f 	str	xzr, [x19, #120]
    64bc:	f100003f 	cmp	x1, #0x0
    64c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64c4:	54000040 	b.eq	64cc <fwp_task_dispose+0x3c>  // b.none
    64c8:	d63f0020 	blr	x1
    64cc:	f9405660 	ldr	x0, [x19, #168]
    64d0:	97fff988 	bl	4af0 <fwp_mem_free>
    64d4:	f900567f 	str	xzr, [x19, #168]
    64d8:	b9405e60 	ldr	w0, [x19, #92]
    64dc:	7100041f 	cmp	w0, #0x1
    64e0:	54000420 	b.eq	6564 <fwp_task_dispose+0xd4>  // b.none
    64e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    64e8:	91174042 	add	x2, x2, #0x5d0
    64ec:	f949d840 	ldr	x0, [x2, #5040]
    64f0:	f949ec41 	ldr	x1, [x2, #5080]
    64f4:	cb000260 	sub	x0, x19, x0
    64f8:	eb01401f 	cmp	x0, x1, lsl #16
    64fc:	540002e2 	b.cs	6558 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6500:	d350fc01 	lsr	x1, x0, #16
    6504:	f949fc44 	ldr	x4, [x2, #5112]
    6508:	8b010821 	add	x1, x1, x1, lsl #2
    650c:	d37df021 	lsl	x1, x1, #3
    6510:	8b010083 	add	x3, x4, x1
    6514:	f9401062 	ldr	x2, [x3, #32]
    6518:	b4000202 	cbz	x2, 6558 <fwp_task_dispose+0xc8>
    651c:	38616881 	ldrb	w1, [x4, x1]
    6520:	7100083f 	cmp	w1, #0x2
    6524:	54000280 	b.eq	6574 <fwp_task_dispose+0xe4>  // b.none
    6528:	7100043f 	cmp	w1, #0x1
    652c:	54000161 	b.ne	6558 <fwp_task_dispose+0xc8>  // b.any
    6530:	29430464 	ldp	w4, w1, [x3, #24]
    6534:	92403c00 	and	x0, x0, #0xffff
    6538:	9b047c00 	mul	x0, x0, x4
    653c:	d360fc00 	lsr	x0, x0, #32
    6540:	eb01001f 	cmp	x0, x1
    6544:	540000a2 	b.cs	6558 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6548:	8b000042 	add	x2, x2, x0
    654c:	39400040 	ldrb	w0, [x2]
    6550:	7100041f 	cmp	w0, #0x1
    6554:	54000080 	b.eq	6564 <fwp_task_dispose+0xd4>  // b.none
    6558:	f9400bf3 	ldr	x19, [sp, #16]
    655c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6560:	d65f03c0 	ret
    6564:	aa1303e0 	mov	x0, x19
    6568:	f9400bf3 	ldr	x19, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	17fff960 	b	4af0 <fwp_mem_free>
    6574:	72003c1f 	tst	w0, #0xffff
    6578:	54fffea0 	b.eq	654c <fwp_task_dispose+0xbc>  // b.none
    657c:	f9400bf3 	ldr	x19, [sp, #16]
    6580:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6584:	d65f03c0 	ret
    6588:	97fff0f6 	bl	2960 <abort@plt>
    658c:	d503201f 	nop

0000000000006590 <fwp_free_zombie>:
    6590:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6594:	910003fd 	mov	x29, sp
    6598:	a90153f3 	stp	x19, x20, [sp, #16]
    659c:	d00000d4 	adrp	x20, 20000 <__data_start>
    65a0:	9101c281 	add	x1, x20, #0x70
    65a4:	f9407833 	ldr	x19, [x1, #240]
    65a8:	b4000333 	cbz	x19, 660c <fwp_free_zombie+0x7c>
    65ac:	f9400820 	ldr	x0, [x1, #16]
    65b0:	eb00027f 	cmp	x19, x0
    65b4:	540002c0 	b.eq	660c <fwp_free_zombie+0x7c>  // b.none
    65b8:	b940f822 	ldr	w2, [x1, #248]
    65bc:	f9400a60 	ldr	x0, [x19, #16]
    65c0:	7100fc5f 	cmp	w2, #0x3f
    65c4:	5400078c 	b.gt	66b4 <fwp_free_zombie+0x124>
    65c8:	91040023 	add	x3, x1, #0x100
    65cc:	11000444 	add	w4, w2, #0x1
    65d0:	b900f824 	str	w4, [x1, #248]
    65d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    65d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    65dc:	a9530261 	ldp	x1, x0, [x19, #304]
    65e0:	b4000741 	cbz	x1, 66c8 <fwp_free_zombie+0x138>
    65e4:	f9009c20 	str	x0, [x1, #312]
    65e8:	b4000040 	cbz	x0, 65f0 <fwp_free_zombie+0x60>
    65ec:	f9009801 	str	x1, [x0, #304]
    65f0:	9101c294 	add	x20, x20, #0x70
    65f4:	b9405e60 	ldr	w0, [x19, #92]
    65f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    65fc:	f9007a9f 	str	xzr, [x20, #240]
    6600:	34000140 	cbz	w0, 6628 <fwp_free_zombie+0x98>
    6604:	7100041f 	cmp	w0, #0x1
    6608:	54000080 	b.eq	6618 <fwp_free_zombie+0x88>  // b.none
    660c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6614:	d65f03c0 	ret
    6618:	aa1303e0 	mov	x0, x19
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6624:	17ffff9b 	b	6490 <fwp_task_dispose>
    6628:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    662c:	91174082 	add	x2, x4, #0x5d0
    6630:	f949d841 	ldr	x1, [x2, #5040]
    6634:	f949ec40 	ldr	x0, [x2, #5080]
    6638:	cb010261 	sub	x1, x19, x1
    663c:	eb00403f 	cmp	x1, x0, lsl #16
    6640:	54fffe62 	b.cs	660c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6644:	d350fc20 	lsr	x0, x1, #16
    6648:	f949fc43 	ldr	x3, [x2, #5112]
    664c:	8b000800 	add	x0, x0, x0, lsl #2
    6650:	d37df000 	lsl	x0, x0, #3
    6654:	8b000062 	add	x2, x3, x0
    6658:	f9401054 	ldr	x20, [x2, #32]
    665c:	b4fffd94 	cbz	x20, 660c <fwp_free_zombie+0x7c>
    6660:	38606860 	ldrb	w0, [x3, x0]
    6664:	7100081f 	cmp	w0, #0x2
    6668:	54000360 	b.eq	66d4 <fwp_free_zombie+0x144>  // b.none
    666c:	7100041f 	cmp	w0, #0x1
    6670:	54fffce1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    6674:	29430043 	ldp	w3, w0, [x2, #24]
    6678:	92403c21 	and	x1, x1, #0xffff
    667c:	9b037c21 	mul	x1, x1, x3
    6680:	d360fc21 	lsr	x1, x1, #32
    6684:	eb00003f 	cmp	x1, x0
    6688:	54fffc22 	b.cs	660c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    668c:	8b010294 	add	x20, x20, x1
    6690:	39400280 	ldrb	w0, [x20]
    6694:	34fffbc0 	cbz	w0, 660c <fwp_free_zombie+0x7c>
    6698:	7100041f 	cmp	w0, #0x1
    669c:	54fffbe0 	b.eq	6618 <fwp_free_zombie+0x88>  // b.none
    66a0:	7103fc1f 	cmp	w0, #0xff
    66a4:	540001e0 	b.eq	66e0 <fwp_free_zombie+0x150>  // b.none
    66a8:	51000400 	sub	w0, w0, #0x1
    66ac:	39000280 	strb	w0, [x20]
    66b0:	17ffffd7 	b	660c <fwp_free_zombie+0x7c>
    66b4:	f9400e61 	ldr	x1, [x19, #24]
    66b8:	97fff0de 	bl	2a30 <munmap@plt>
    66bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66c0:	a9530261 	ldp	x1, x0, [x19, #304]
    66c4:	b5fff901 	cbnz	x1, 65e4 <fwp_free_zombie+0x54>
    66c8:	9101c282 	add	x2, x20, #0x70
    66cc:	f9018040 	str	x0, [x2, #768]
    66d0:	17ffffc6 	b	65e8 <fwp_free_zombie+0x58>
    66d4:	72003c3f 	tst	w1, #0xffff
    66d8:	54fff9a1 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    66dc:	17ffffed 	b	6690 <fwp_free_zombie+0x100>
    66e0:	ca544680 	eor	x0, x20, x20, lsr #17
    66e4:	91174084 	add	x4, x4, #0x5d0
    66e8:	ca402400 	eor	x0, x0, x0, lsr #9
    66ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    66f0:	f94a2400 	ldr	x0, [x0, #5192]
    66f4:	b5000080 	cbnz	x0, 6704 <fwp_free_zombie+0x174>
    66f8:	14000010 	b	6738 <fwp_free_zombie+0x1a8>
    66fc:	f9400800 	ldr	x0, [x0, #16]
    6700:	b40001c0 	cbz	x0, 6738 <fwp_free_zombie+0x1a8>
    6704:	f9400001 	ldr	x1, [x0]
    6708:	eb14003f 	cmp	x1, x20
    670c:	54ffff81 	b.ne	66fc <fwp_free_zombie+0x16c>  // b.any
    6710:	f9400401 	ldr	x1, [x0, #8]
    6714:	d1000421 	sub	x1, x1, #0x1
    6718:	f9000401 	str	x1, [x0, #8]
    671c:	f103f83f 	cmp	x1, #0xfe
    6720:	54fff761 	b.ne	660c <fwp_free_zombie+0x7c>  // b.any
    6724:	aa1403e0 	mov	x0, x20
    6728:	97fff852 	bl	4870 <fwp_rc_forget_slot>
    672c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6730:	39000280 	strb	w0, [x20]
    6734:	17ffffb6 	b	660c <fwp_free_zombie+0x7c>
    6738:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    673c:	910a8000 	add	x0, x0, #0x2a0
    6740:	97fff450 	bl	3880 <fwp_trap>

0000000000006744 <fwp_block>:
    6744:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6748:	910003fd 	mov	x29, sp
    674c:	a90153f3 	stp	x19, x20, [sp, #16]
    6750:	d00000d3 	adrp	x19, 20000 <__data_start>
    6754:	9101c274 	add	x20, x19, #0x70
    6758:	f9404282 	ldr	x2, [x20, #128]
    675c:	b4000622 	cbz	x2, 6820 <fwp_block+0xdc>
    6760:	9101c261 	add	x1, x19, #0x70
    6764:	f9408040 	ldr	x0, [x2, #256]
    6768:	f9004020 	str	x0, [x1, #128]
    676c:	b4000680 	cbz	x0, 683c <fwp_block+0xf8>
    6770:	9101c263 	add	x3, x19, #0x70
    6774:	3901505f 	strb	wzr, [x2, #84]
    6778:	f9400864 	ldr	x4, [x3, #16]
    677c:	eb02009f 	cmp	x4, x2
    6780:	54000440 	b.eq	6808 <fwp_block+0xc4>  // b.none
    6784:	f9418465 	ldr	x5, [x3, #776]
    6788:	f9000862 	str	x2, [x3, #16]
    678c:	f9400441 	ldr	x1, [x2, #8]
    6790:	f9004885 	str	x5, [x4, #144]
    6794:	f9418865 	ldr	x5, [x3, #784]
    6798:	f9004c85 	str	x5, [x4, #152]
    679c:	f9418c65 	ldr	x5, [x3, #792]
    67a0:	f9005085 	str	x5, [x4, #160]
    67a4:	f9419065 	ldr	x5, [x3, #800]
    67a8:	f9005485 	str	x5, [x4, #168]
    67ac:	f9419465 	ldr	x5, [x3, #808]
    67b0:	f9005885 	str	x5, [x4, #176]
    67b4:	f9419865 	ldr	x5, [x3, #816]
    67b8:	f9005c85 	str	x5, [x4, #184]
    67bc:	f9419c65 	ldr	x5, [x3, #824]
    67c0:	f9006085 	str	x5, [x4, #192]
    67c4:	f9400480 	ldr	x0, [x4, #8]
    67c8:	f9404844 	ldr	x4, [x2, #144]
    67cc:	f9018464 	str	x4, [x3, #776]
    67d0:	f9404c44 	ldr	x4, [x2, #152]
    67d4:	f9018864 	str	x4, [x3, #784]
    67d8:	f9405044 	ldr	x4, [x2, #160]
    67dc:	f9018c64 	str	x4, [x3, #792]
    67e0:	f9405444 	ldr	x4, [x2, #168]
    67e4:	f9019064 	str	x4, [x3, #800]
    67e8:	f9405844 	ldr	x4, [x2, #176]
    67ec:	f9019464 	str	x4, [x3, #808]
    67f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    67f4:	f9019864 	str	x4, [x3, #816]
    67f8:	f9019c62 	str	x2, [x3, #824]
    67fc:	97fff05d 	bl	2970 <swapcontext@plt>
    6800:	97ffff64 	bl	6590 <fwp_free_zombie>
    6804:	d503201f 	nop
    6808:	9101c260 	add	x0, x19, #0x70
    680c:	b9434000 	ldr	w0, [x0, #832]
    6810:	340001a0 	cbz	w0, 6844 <fwp_block+0x100>
    6814:	a94153f3 	ldp	x19, x20, [sp, #16]
    6818:	a8c27bfd 	ldp	x29, x30, [sp], #32
    681c:	d65f03c0 	ret
    6820:	97fff740 	bl	4520 <fwp_poll_events>
    6824:	f9404282 	ldr	x2, [x20, #128]
    6828:	b4ffffc2 	cbz	x2, 6820 <fwp_block+0xdc>
    682c:	9101c261 	add	x1, x19, #0x70
    6830:	f9408040 	ldr	x0, [x2, #256]
    6834:	f9004020 	str	x0, [x1, #128]
    6838:	b5fff9c0 	cbnz	x0, 6770 <fwp_block+0x2c>
    683c:	f9003c3f 	str	xzr, [x1, #120]
    6840:	17ffffcc 	b	6770 <fwp_block+0x2c>
    6844:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    6848:	910f4000 	add	x0, x0, #0x3d0
    684c:	97fff095 	bl	2aa0 <getenv@plt>
    6850:	5284e202 	mov	w2, #0x2710                	// #10000
    6854:	b4000060 	cbz	x0, 6860 <fwp_block+0x11c>
    6858:	39400001 	ldrb	w1, [x0]
    685c:	350000c1 	cbnz	w1, 6874 <fwp_block+0x130>
    6860:	9101c273 	add	x19, x19, #0x70
    6864:	b9034262 	str	w2, [x19, #832]
    6868:	a94153f3 	ldp	x19, x20, [sp, #16]
    686c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6870:	d65f03c0 	ret
    6874:	52800142 	mov	w2, #0xa                   	// #10
    6878:	d2800001 	mov	x1, #0x0                   	// #0
    687c:	97ffefd9 	bl	27e0 <strtoll@plt>
    6880:	d1000403 	sub	x3, x0, #0x1
    6884:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6888:	eb02007f 	cmp	x3, x2
    688c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6890:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6894:	17fffff3 	b	6860 <fwp_block+0x11c>
    6898:	d503201f 	nop
    689c:	d503201f 	nop

00000000000068a0 <fwp_drop10>:
    68a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    68a4:	910003fd 	mov	x29, sp
    68a8:	a90153f3 	stp	x19, x20, [sp, #16]
    68ac:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    68b0:	f90013f5 	str	x21, [sp, #32]
    68b4:	91174275 	add	x21, x19, #0x5d0
    68b8:	f949daa1 	ldr	x1, [x21, #5040]
    68bc:	f949eea2 	ldr	x2, [x21, #5080]
    68c0:	cb010001 	sub	x1, x0, x1
    68c4:	eb02403f 	cmp	x1, x2, lsl #16
    68c8:	54000382 	b.cs	6938 <fwp_drop10+0x98>  // b.hs, b.nlast
    68cc:	d350fc22 	lsr	x2, x1, #16
    68d0:	f949fea3 	ldr	x3, [x21, #5112]
    68d4:	8b020842 	add	x2, x2, x2, lsl #2
    68d8:	d37df042 	lsl	x2, x2, #3
    68dc:	8b020064 	add	x4, x3, x2
    68e0:	f9401094 	ldr	x20, [x4, #32]
    68e4:	b40002b4 	cbz	x20, 6938 <fwp_drop10+0x98>
    68e8:	38626862 	ldrb	w2, [x3, x2]
    68ec:	7100085f 	cmp	w2, #0x2
    68f0:	540007a0 	b.eq	69e4 <fwp_drop10+0x144>  // b.none
    68f4:	7100045f 	cmp	w2, #0x1
    68f8:	54000201 	b.ne	6938 <fwp_drop10+0x98>  // b.any
    68fc:	29430885 	ldp	w5, w2, [x4, #24]
    6900:	92403c21 	and	x1, x1, #0xffff
    6904:	9b057c21 	mul	x1, x1, x5
    6908:	d360fc21 	lsr	x1, x1, #32
    690c:	eb02003f 	cmp	x1, x2
    6910:	54000142 	b.cs	6938 <fwp_drop10+0x98>  // b.hs, b.nlast
    6914:	8b010294 	add	x20, x20, x1
    6918:	39400281 	ldrb	w1, [x20]
    691c:	340000e1 	cbz	w1, 6938 <fwp_drop10+0x98>
    6920:	7100043f 	cmp	w1, #0x1
    6924:	54000120 	b.eq	6948 <fwp_drop10+0xa8>  // b.none
    6928:	7103fc3f 	cmp	w1, #0xff
    692c:	540007c0 	b.eq	6a24 <fwp_drop10+0x184>  // b.none
    6930:	51000421 	sub	w1, w1, #0x1
    6934:	39000281 	strb	w1, [x20]
    6938:	a94153f3 	ldp	x19, x20, [sp, #16]
    693c:	f94013f5 	ldr	x21, [sp, #32]
    6940:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6944:	d65f03c0 	ret
    6948:	f9400001 	ldr	x1, [x0]
    694c:	b7f80581 	tbnz	x1, #63, 69fc <fwp_drop10+0x15c>
    6950:	91174273 	add	x19, x19, #0x5d0
    6954:	f949da61 	ldr	x1, [x19, #5040]
    6958:	f949ee62 	ldr	x2, [x19, #5080]
    695c:	cb010001 	sub	x1, x0, x1
    6960:	eb02403f 	cmp	x1, x2, lsl #16
    6964:	54fffea2 	b.cs	6938 <fwp_drop10+0x98>  // b.hs, b.nlast
    6968:	d350fc22 	lsr	x2, x1, #16
    696c:	8b020842 	add	x2, x2, x2, lsl #2
    6970:	d37df042 	lsl	x2, x2, #3
    6974:	8b020065 	add	x5, x3, x2
    6978:	f94010a4 	ldr	x4, [x5, #32]
    697c:	b4fffde4 	cbz	x4, 6938 <fwp_drop10+0x98>
    6980:	38626862 	ldrb	w2, [x3, x2]
    6984:	7100085f 	cmp	w2, #0x2
    6988:	54000220 	b.eq	69cc <fwp_drop10+0x12c>  // b.none
    698c:	7100045f 	cmp	w2, #0x1
    6990:	54fffd41 	b.ne	6938 <fwp_drop10+0x98>  // b.any
    6994:	294308a3 	ldp	w3, w2, [x5, #24]
    6998:	92403c21 	and	x1, x1, #0xffff
    699c:	9b037c21 	mul	x1, x1, x3
    69a0:	d360fc21 	lsr	x1, x1, #32
    69a4:	eb02003f 	cmp	x1, x2
    69a8:	54fffc82 	b.cs	6938 <fwp_drop10+0x98>  // b.hs, b.nlast
    69ac:	8b010084 	add	x4, x4, x1
    69b0:	39400081 	ldrb	w1, [x4]
    69b4:	7100043f 	cmp	w1, #0x1
    69b8:	54fffc01 	b.ne	6938 <fwp_drop10+0x98>  // b.any
    69bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69c0:	f94013f5 	ldr	x21, [sp, #32]
    69c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69c8:	17fff84a 	b	4af0 <fwp_mem_free>
    69cc:	72003c3f 	tst	w1, #0xffff
    69d0:	54ffff00 	b.eq	69b0 <fwp_drop10+0x110>  // b.none
    69d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d8:	f94013f5 	ldr	x21, [sp, #32]
    69dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69e0:	d65f03c0 	ret
    69e4:	72003c3f 	tst	w1, #0xffff
    69e8:	54fff980 	b.eq	6918 <fwp_drop10+0x78>  // b.none
    69ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    69f0:	f94013f5 	ldr	x21, [sp, #32]
    69f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69f8:	d65f03c0 	ret
    69fc:	f9400414 	ldr	x20, [x0, #8]
    6a00:	97fffb5d 	bl	5774 <fwp_rc_free_arr>
    6a04:	91174260 	add	x0, x19, #0x5d0
    6a08:	f949d801 	ldr	x1, [x0, #5040]
    6a0c:	f949ec00 	ldr	x0, [x0, #5080]
    6a10:	cb010281 	sub	x1, x20, x1
    6a14:	eb00403f 	cmp	x1, x0, lsl #16
    6a18:	54fff902 	b.cs	6938 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a1c:	aa1403e0 	mov	x0, x20
    6a20:	17ffffab 	b	68cc <fwp_drop10+0x2c>
    6a24:	ca544680 	eor	x0, x20, x20, lsr #17
    6a28:	91174273 	add	x19, x19, #0x5d0
    6a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a30:	8b200e60 	add	x0, x19, w0, uxtb #3
    6a34:	f94a2400 	ldr	x0, [x0, #5192]
    6a38:	b5000080 	cbnz	x0, 6a48 <fwp_drop10+0x1a8>
    6a3c:	14000010 	b	6a7c <fwp_drop10+0x1dc>
    6a40:	f9400800 	ldr	x0, [x0, #16]
    6a44:	b40001c0 	cbz	x0, 6a7c <fwp_drop10+0x1dc>
    6a48:	f9400001 	ldr	x1, [x0]
    6a4c:	eb14003f 	cmp	x1, x20
    6a50:	54ffff81 	b.ne	6a40 <fwp_drop10+0x1a0>  // b.any
    6a54:	f9400401 	ldr	x1, [x0, #8]
    6a58:	d1000421 	sub	x1, x1, #0x1
    6a5c:	f9000401 	str	x1, [x0, #8]
    6a60:	f103f83f 	cmp	x1, #0xfe
    6a64:	54fff6a1 	b.ne	6938 <fwp_drop10+0x98>  // b.any
    6a68:	aa1403e0 	mov	x0, x20
    6a6c:	97fff781 	bl	4870 <fwp_rc_forget_slot>
    6a70:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a74:	39000280 	strb	w0, [x20]
    6a78:	17ffffb0 	b	6938 <fwp_drop10+0x98>
    6a7c:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    6a80:	910a8000 	add	x0, x0, #0x2a0
    6a84:	97fff37f 	bl	3880 <fwp_trap>
    6a88:	d503201f 	nop
    6a8c:	d503201f 	nop

0000000000006a90 <fwp_caps173>:
    6a90:	34000041 	cbz	w1, 6a98 <fwp_caps173+0x8>
    6a94:	d65f03c0 	ret
    6a98:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6a9c:	91174063 	add	x3, x3, #0x5d0
    6aa0:	f949d861 	ldr	x1, [x3, #5040]
    6aa4:	f949ec62 	ldr	x2, [x3, #5080]
    6aa8:	cb010001 	sub	x1, x0, x1
    6aac:	eb02403f 	cmp	x1, x2, lsl #16
    6ab0:	54ffff22 	b.cs	6a94 <fwp_caps173+0x4>  // b.hs, b.nlast
    6ab4:	d350fc22 	lsr	x2, x1, #16
    6ab8:	f949fc65 	ldr	x5, [x3, #5112]
    6abc:	8b020842 	add	x2, x2, x2, lsl #2
    6ac0:	d37df042 	lsl	x2, x2, #3
    6ac4:	8b0200a4 	add	x4, x5, x2
    6ac8:	f9401083 	ldr	x3, [x4, #32]
    6acc:	b4fffe43 	cbz	x3, 6a94 <fwp_caps173+0x4>
    6ad0:	386268a2 	ldrb	w2, [x5, x2]
    6ad4:	7100085f 	cmp	w2, #0x2
    6ad8:	540001c0 	b.eq	6b10 <fwp_caps173+0x80>  // b.none
    6adc:	7100045f 	cmp	w2, #0x1
    6ae0:	54fffda1 	b.ne	6a94 <fwp_caps173+0x4>  // b.any
    6ae4:	29430885 	ldp	w5, w2, [x4, #24]
    6ae8:	92403c21 	and	x1, x1, #0xffff
    6aec:	9b057c21 	mul	x1, x1, x5
    6af0:	d360fc21 	lsr	x1, x1, #32
    6af4:	eb02003f 	cmp	x1, x2
    6af8:	54fffce2 	b.cs	6a94 <fwp_caps173+0x4>  // b.hs, b.nlast
    6afc:	8b010063 	add	x3, x3, x1
    6b00:	39400061 	ldrb	w1, [x3]
    6b04:	7100043f 	cmp	w1, #0x1
    6b08:	54fffc61 	b.ne	6a94 <fwp_caps173+0x4>  // b.any
    6b0c:	17fff7f9 	b	4af0 <fwp_mem_free>
    6b10:	72003c3f 	tst	w1, #0xffff
    6b14:	54ffff60 	b.eq	6b00 <fwp_caps173+0x70>  // b.none
    6b18:	d65f03c0 	ret
    6b1c:	d503201f 	nop

0000000000006b20 <fwp_args37>:
    6b20:	7100003f 	cmp	w1, #0x0
    6b24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b28:	54000041 	b.ne	6b30 <fwp_args37+0x10>  // b.any
    6b2c:	d65f03c0 	ret
    6b30:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6b34:	91174042 	add	x2, x2, #0x5d0
    6b38:	f9400001 	ldr	x1, [x0]
    6b3c:	f949d843 	ldr	x3, [x2, #5040]
    6b40:	f949ec40 	ldr	x0, [x2, #5080]
    6b44:	cb030021 	sub	x1, x1, x3
    6b48:	eb00403f 	cmp	x1, x0, lsl #16
    6b4c:	54ffff02 	b.cs	6b2c <fwp_args37+0xc>  // b.hs, b.nlast
    6b50:	d350fc20 	lsr	x0, x1, #16
    6b54:	f949fc44 	ldr	x4, [x2, #5112]
    6b58:	8b000800 	add	x0, x0, x0, lsl #2
    6b5c:	d37df002 	lsl	x2, x0, #3
    6b60:	8b020083 	add	x3, x4, x2
    6b64:	f9401060 	ldr	x0, [x3, #32]
    6b68:	b4fffe20 	cbz	x0, 6b2c <fwp_args37+0xc>
    6b6c:	38626882 	ldrb	w2, [x4, x2]
    6b70:	7100085f 	cmp	w2, #0x2
    6b74:	54000220 	b.eq	6bb8 <fwp_args37+0x98>  // b.none
    6b78:	7100045f 	cmp	w2, #0x1
    6b7c:	54fffd81 	b.ne	6b2c <fwp_args37+0xc>  // b.any
    6b80:	29430864 	ldp	w4, w2, [x3, #24]
    6b84:	92403c21 	and	x1, x1, #0xffff
    6b88:	9b047c21 	mul	x1, x1, x4
    6b8c:	d360fc21 	lsr	x1, x1, #32
    6b90:	eb02003f 	cmp	x1, x2
    6b94:	54fffcc2 	b.cs	6b2c <fwp_args37+0xc>  // b.hs, b.nlast
    6b98:	8b010000 	add	x0, x0, x1
    6b9c:	39400001 	ldrb	w1, [x0]
    6ba0:	34fffc61 	cbz	w1, 6b2c <fwp_args37+0xc>
    6ba4:	7103f43f 	cmp	w1, #0xfd
    6ba8:	540000e8 	b.hi	6bc4 <fwp_args37+0xa4>  // b.pmore
    6bac:	11000421 	add	w1, w1, #0x1
    6bb0:	39000001 	strb	w1, [x0]
    6bb4:	d65f03c0 	ret
    6bb8:	72003c3f 	tst	w1, #0xffff
    6bbc:	54ffff00 	b.eq	6b9c <fwp_args37+0x7c>  // b.none
    6bc0:	d65f03c0 	ret
    6bc4:	17fff6e4 	b	4754 <fwp_rc_wide_dup>
    6bc8:	d503201f 	nop
    6bcc:	d503201f 	nop

0000000000006bd0 <fwp_caps37>:
    6bd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6bd4:	910003fd 	mov	x29, sp
    6bd8:	f9000bf3 	str	x19, [sp, #16]
    6bdc:	aa0003f3 	mov	x19, x0
    6be0:	b9400400 	ldr	w0, [x0, #4]
    6be4:	340004a0 	cbz	w0, 6c78 <fwp_caps37+0xa8>
    6be8:	f9400660 	ldr	x0, [x19, #8]
    6bec:	350004e1 	cbnz	w1, 6c88 <fwp_caps37+0xb8>
    6bf0:	97fffd90 	bl	6230 <fwp_drop4>
    6bf4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6bf8:	91174042 	add	x2, x2, #0x5d0
    6bfc:	f949d840 	ldr	x0, [x2, #5040]
    6c00:	f949ec41 	ldr	x1, [x2, #5080]
    6c04:	cb000260 	sub	x0, x19, x0
    6c08:	eb01401f 	cmp	x0, x1, lsl #16
    6c0c:	54000382 	b.cs	6c7c <fwp_caps37+0xac>  // b.hs, b.nlast
    6c10:	d350fc01 	lsr	x1, x0, #16
    6c14:	f949fc44 	ldr	x4, [x2, #5112]
    6c18:	8b010821 	add	x1, x1, x1, lsl #2
    6c1c:	d37df021 	lsl	x1, x1, #3
    6c20:	8b010083 	add	x3, x4, x1
    6c24:	f9401062 	ldr	x2, [x3, #32]
    6c28:	b40002a2 	cbz	x2, 6c7c <fwp_caps37+0xac>
    6c2c:	38616881 	ldrb	w1, [x4, x1]
    6c30:	7100083f 	cmp	w1, #0x2
    6c34:	540006c0 	b.eq	6d0c <fwp_caps37+0x13c>  // b.none
    6c38:	7100043f 	cmp	w1, #0x1
    6c3c:	54000201 	b.ne	6c7c <fwp_caps37+0xac>  // b.any
    6c40:	29430464 	ldp	w4, w1, [x3, #24]
    6c44:	92403c00 	and	x0, x0, #0xffff
    6c48:	9b047c00 	mul	x0, x0, x4
    6c4c:	d360fc00 	lsr	x0, x0, #32
    6c50:	eb01001f 	cmp	x0, x1
    6c54:	54000142 	b.cs	6c7c <fwp_caps37+0xac>  // b.hs, b.nlast
    6c58:	8b000042 	add	x2, x2, x0
    6c5c:	39400040 	ldrb	w0, [x2]
    6c60:	7100041f 	cmp	w0, #0x1
    6c64:	540000c1 	b.ne	6c7c <fwp_caps37+0xac>  // b.any
    6c68:	aa1303e0 	mov	x0, x19
    6c6c:	f9400bf3 	ldr	x19, [sp, #16]
    6c70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c74:	17fff79f 	b	4af0 <fwp_mem_free>
    6c78:	34fffbe1 	cbz	w1, 6bf4 <fwp_caps37+0x24>
    6c7c:	f9400bf3 	ldr	x19, [sp, #16]
    6c80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c84:	d65f03c0 	ret
    6c88:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6c8c:	91174042 	add	x2, x2, #0x5d0
    6c90:	f949d843 	ldr	x3, [x2, #5040]
    6c94:	f949ec41 	ldr	x1, [x2, #5080]
    6c98:	cb030000 	sub	x0, x0, x3
    6c9c:	eb01401f 	cmp	x0, x1, lsl #16
    6ca0:	54fffee2 	b.cs	6c7c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ca4:	d350fc01 	lsr	x1, x0, #16
    6ca8:	f949fc44 	ldr	x4, [x2, #5112]
    6cac:	8b010821 	add	x1, x1, x1, lsl #2
    6cb0:	d37df021 	lsl	x1, x1, #3
    6cb4:	8b010083 	add	x3, x4, x1
    6cb8:	f9401062 	ldr	x2, [x3, #32]
    6cbc:	b4fffe02 	cbz	x2, 6c7c <fwp_caps37+0xac>
    6cc0:	38616881 	ldrb	w1, [x4, x1]
    6cc4:	7100083f 	cmp	w1, #0x2
    6cc8:	54000280 	b.eq	6d18 <fwp_caps37+0x148>  // b.none
    6ccc:	7100043f 	cmp	w1, #0x1
    6cd0:	54fffd61 	b.ne	6c7c <fwp_caps37+0xac>  // b.any
    6cd4:	92403c01 	and	x1, x0, #0xffff
    6cd8:	29430064 	ldp	w4, w0, [x3, #24]
    6cdc:	9b047c21 	mul	x1, x1, x4
    6ce0:	d360fc21 	lsr	x1, x1, #32
    6ce4:	eb00003f 	cmp	x1, x0
    6ce8:	54fffca2 	b.cs	6c7c <fwp_caps37+0xac>  // b.hs, b.nlast
    6cec:	8b010042 	add	x2, x2, x1
    6cf0:	39400040 	ldrb	w0, [x2]
    6cf4:	34fffc40 	cbz	w0, 6c7c <fwp_caps37+0xac>
    6cf8:	7103f41f 	cmp	w0, #0xfd
    6cfc:	54000148 	b.hi	6d24 <fwp_caps37+0x154>  // b.pmore
    6d00:	11000400 	add	w0, w0, #0x1
    6d04:	39000040 	strb	w0, [x2]
    6d08:	17ffffdd 	b	6c7c <fwp_caps37+0xac>
    6d0c:	72003c1f 	tst	w0, #0xffff
    6d10:	54fffb61 	b.ne	6c7c <fwp_caps37+0xac>  // b.any
    6d14:	17ffffd2 	b	6c5c <fwp_caps37+0x8c>
    6d18:	72003c1f 	tst	w0, #0xffff
    6d1c:	54fffb01 	b.ne	6c7c <fwp_caps37+0xac>  // b.any
    6d20:	17fffff4 	b	6cf0 <fwp_caps37+0x120>
    6d24:	f9400bf3 	ldr	x19, [sp, #16]
    6d28:	aa0203e0 	mov	x0, x2
    6d2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d30:	17fff689 	b	4754 <fwp_rc_wide_dup>

0000000000006d34 <f37>:
    6d34:	d101c3ff 	sub	sp, sp, #0x70
    6d38:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6d3c:	f947f421 	ldr	x1, [x1, #4072]
    6d40:	a9027bfd 	stp	x29, x30, [sp, #32]
    6d44:	910083fd 	add	x29, sp, #0x20
    6d48:	a90563f7 	stp	x23, x24, [sp, #80]
    6d4c:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    6d50:	911742e3 	add	x3, x23, #0x5d0
    6d54:	a90353f3 	stp	x19, x20, [sp, #48]
    6d58:	a9045bf5 	stp	x21, x22, [sp, #64]
    6d5c:	aa0003f6 	mov	x22, x0
    6d60:	a9066bf9 	stp	x25, x26, [sp, #96]
    6d64:	f949ec62 	ldr	x2, [x3, #5080]
    6d68:	f9400024 	ldr	x4, [x1]
    6d6c:	f9000fe4 	str	x4, [sp, #24]
    6d70:	d2800004 	mov	x4, #0x0                   	// #0
    6d74:	f949d861 	ldr	x1, [x3, #5040]
    6d78:	d370bc42 	lsl	x2, x2, #16
    6d7c:	b40015a0 	cbz	x0, 7030 <f37+0x2fc>
    6d80:	f9400818 	ldr	x24, [x0, #16]
    6d84:	cb010301 	sub	x1, x24, x1
    6d88:	eb02003f 	cmp	x1, x2
    6d8c:	54000362 	b.cs	6df8 <f37+0xc4>  // b.hs, b.nlast
    6d90:	f949fc60 	ldr	x0, [x3, #5112]
    6d94:	d350fc22 	lsr	x2, x1, #16
    6d98:	8b020842 	add	x2, x2, x2, lsl #2
    6d9c:	8b020c02 	add	x2, x0, x2, lsl #3
    6da0:	f9401040 	ldr	x0, [x2, #32]
    6da4:	b40002a0 	cbz	x0, 6df8 <f37+0xc4>
    6da8:	39400043 	ldrb	w3, [x2]
    6dac:	7100087f 	cmp	w3, #0x2
    6db0:	540013a0 	b.eq	7024 <f37+0x2f0>  // b.none
    6db4:	7100047f 	cmp	w3, #0x1
    6db8:	540001c1 	b.ne	6df0 <f37+0xbc>  // b.any
    6dbc:	29430843 	ldp	w3, w2, [x2, #24]
    6dc0:	92403c21 	and	x1, x1, #0xffff
    6dc4:	9b037c21 	mul	x1, x1, x3
    6dc8:	d360fc21 	lsr	x1, x1, #32
    6dcc:	eb02003f 	cmp	x1, x2
    6dd0:	54000102 	b.cs	6df0 <f37+0xbc>  // b.hs, b.nlast
    6dd4:	8b010000 	add	x0, x0, x1
    6dd8:	39400001 	ldrb	w1, [x0]
    6ddc:	340000a1 	cbz	w1, 6df0 <f37+0xbc>
    6de0:	7103f43f 	cmp	w1, #0xfd
    6de4:	54001688 	b.hi	70b4 <f37+0x380>  // b.pmore
    6de8:	11000421 	add	w1, w1, #0x1
    6dec:	39000001 	strb	w1, [x0]
    6df0:	d2800000 	mov	x0, #0x0                   	// #0
    6df4:	b40000d6 	cbz	x22, 6e0c <f37+0xd8>
    6df8:	aa1603e1 	mov	x1, x22
    6dfc:	d2800000 	mov	x0, #0x0                   	// #0
    6e00:	f9400821 	ldr	x1, [x1, #16]
    6e04:	91000400 	add	x0, x0, #0x1
    6e08:	b5ffffc1 	cbnz	x1, 6e00 <f37+0xcc>
    6e0c:	b40011b8 	cbz	x24, 7040 <f37+0x30c>
    6e10:	aa1803e1 	mov	x1, x24
    6e14:	d2800002 	mov	x2, #0x0                   	// #0
    6e18:	f9400821 	ldr	x1, [x1, #16]
    6e1c:	91000442 	add	x2, x2, #0x1
    6e20:	b5ffffc1 	cbnz	x1, 6e18 <f37+0xe4>
    6e24:	eb00005f 	cmp	x2, x0
    6e28:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6e2c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6e30:	eb01033f 	cmp	x25, x1
    6e34:	54001468 	b.hi	70c0 <f37+0x38c>  // b.pmore
    6e38:	d37ffb33 	lsl	x19, x25, #1
    6e3c:	52800041 	mov	w1, #0x2                   	// #2
    6e40:	91000660 	add	x0, x19, #0x1
    6e44:	d37df000 	lsl	x0, x0, #3
    6e48:	97fff84a 	bl	4f70 <fwp_heap_alloc>
    6e4c:	911742e1 	add	x1, x23, #0x5d0
    6e50:	aa0003fa 	mov	x26, x0
    6e54:	f9000013 	str	x19, [x0]
    6e58:	aa0103e0 	mov	x0, x1
    6e5c:	f949d821 	ldr	x1, [x1, #5040]
    6e60:	f949ec00 	ldr	x0, [x0, #5080]
    6e64:	cb010341 	sub	x1, x26, x1
    6e68:	eb00403f 	cmp	x1, x0, lsl #16
    6e6c:	54000342 	b.cs	6ed4 <f37+0x1a0>  // b.hs, b.nlast
    6e70:	911742e2 	add	x2, x23, #0x5d0
    6e74:	d350fc20 	lsr	x0, x1, #16
    6e78:	8b000800 	add	x0, x0, x0, lsl #2
    6e7c:	f949fc43 	ldr	x3, [x2, #5112]
    6e80:	d37df002 	lsl	x2, x0, #3
    6e84:	8b020060 	add	x0, x3, x2
    6e88:	f9401013 	ldr	x19, [x0, #32]
    6e8c:	b4000253 	cbz	x19, 6ed4 <f37+0x1a0>
    6e90:	38626862 	ldrb	w2, [x3, x2]
    6e94:	7100085f 	cmp	w2, #0x2
    6e98:	54000c00 	b.eq	7018 <f37+0x2e4>  // b.none
    6e9c:	7100045f 	cmp	w2, #0x1
    6ea0:	540001a1 	b.ne	6ed4 <f37+0x1a0>  // b.any
    6ea4:	29430002 	ldp	w2, w0, [x0, #24]
    6ea8:	92403c21 	and	x1, x1, #0xffff
    6eac:	9b027c21 	mul	x1, x1, x2
    6eb0:	d360fc21 	lsr	x1, x1, #32
    6eb4:	eb00003f 	cmp	x1, x0
    6eb8:	540000e2 	b.cs	6ed4 <f37+0x1a0>  // b.hs, b.nlast
    6ebc:	8b010273 	add	x19, x19, x1
    6ec0:	39400260 	ldrb	w0, [x19]
    6ec4:	7103fc1f 	cmp	w0, #0xff
    6ec8:	54000da0 	b.eq	707c <f37+0x348>  // b.none
    6ecc:	52800020 	mov	w0, #0x1                   	// #1
    6ed0:	39000260 	strb	w0, [x19]
    6ed4:	b4000259 	cbz	x25, 6f1c <f37+0x1e8>
    6ed8:	8b191359 	add	x25, x26, x25, lsl #4
    6edc:	aa1a03f3 	mov	x19, x26
    6ee0:	aa1603f5 	mov	x21, x22
    6ee4:	aa1803f4 	mov	x20, x24
    6ee8:	f9400683 	ldr	x3, [x20, #8]
    6eec:	f94006a2 	ldr	x2, [x21, #8]
    6ef0:	f9400861 	ldr	x1, [x3, #16]
    6ef4:	f9400840 	ldr	x0, [x2, #16]
    6ef8:	fd400461 	ldr	d1, [x3, #8]
    6efc:	fd400440 	ldr	d0, [x2, #8]
    6f00:	97fff95c 	bl	5470 <w120>
    6f04:	f9000660 	str	x0, [x19, #8]
    6f08:	f8010e61 	str	x1, [x19, #16]!
    6f0c:	f9400a94 	ldr	x20, [x20, #16]
    6f10:	f9400ab5 	ldr	x21, [x21, #16]
    6f14:	eb13033f 	cmp	x25, x19
    6f18:	54fffe81 	b.ne	6ee8 <f37+0x1b4>  // b.any
    6f1c:	aa1803e0 	mov	x0, x24
    6f20:	97fffcc4 	bl	6230 <fwp_drop4>
    6f24:	aa1603e0 	mov	x0, x22
    6f28:	97fffcc2 	bl	6230 <fwp_drop4>
    6f2c:	911742f7 	add	x23, x23, #0x5d0
    6f30:	aa1a03e0 	mov	x0, x26
    6f34:	97fff993 	bl	5580 <w176.constprop.0>
    6f38:	aa0103f3 	mov	x19, x1
    6f3c:	aa0003f4 	mov	x20, x0
    6f40:	aa1a03e0 	mov	x0, x26
    6f44:	97fffe57 	bl	68a0 <fwp_drop10>
    6f48:	a900cff4 	stp	x20, x19, [sp, #8]
    6f4c:	910023e1 	add	x1, sp, #0x8
    6f50:	52800000 	mov	w0, #0x0                   	// #0
    6f54:	97fff84c 	bl	5084 <fwp_data.part.0.constprop.0>
    6f58:	f949dae1 	ldr	x1, [x23, #5040]
    6f5c:	aa0003f3 	mov	x19, x0
    6f60:	f949eee0 	ldr	x0, [x23, #5080]
    6f64:	cb010261 	sub	x1, x19, x1
    6f68:	eb00403f 	cmp	x1, x0, lsl #16
    6f6c:	54000322 	b.cs	6fd0 <f37+0x29c>  // b.hs, b.nlast
    6f70:	d350fc22 	lsr	x2, x1, #16
    6f74:	f949fee3 	ldr	x3, [x23, #5112]
    6f78:	8b020842 	add	x2, x2, x2, lsl #2
    6f7c:	d37df042 	lsl	x2, x2, #3
    6f80:	8b020060 	add	x0, x3, x2
    6f84:	f9401014 	ldr	x20, [x0, #32]
    6f88:	b4000254 	cbz	x20, 6fd0 <f37+0x29c>
    6f8c:	38626862 	ldrb	w2, [x3, x2]
    6f90:	7100085f 	cmp	w2, #0x2
    6f94:	540003c0 	b.eq	700c <f37+0x2d8>  // b.none
    6f98:	7100045f 	cmp	w2, #0x1
    6f9c:	540001a1 	b.ne	6fd0 <f37+0x29c>  // b.any
    6fa0:	29430002 	ldp	w2, w0, [x0, #24]
    6fa4:	92403c21 	and	x1, x1, #0xffff
    6fa8:	9b027c21 	mul	x1, x1, x2
    6fac:	d360fc21 	lsr	x1, x1, #32
    6fb0:	eb00003f 	cmp	x1, x0
    6fb4:	540000e2 	b.cs	6fd0 <f37+0x29c>  // b.hs, b.nlast
    6fb8:	8b010294 	add	x20, x20, x1
    6fbc:	39400280 	ldrb	w0, [x20]
    6fc0:	7103fc1f 	cmp	w0, #0xff
    6fc4:	54000620 	b.eq	7088 <f37+0x354>  // b.none
    6fc8:	52800020 	mov	w0, #0x1                   	// #1
    6fcc:	39000280 	strb	w0, [x20]
    6fd0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6fd4:	f947f400 	ldr	x0, [x0, #4072]
    6fd8:	f9400fe2 	ldr	x2, [sp, #24]
    6fdc:	f9400001 	ldr	x1, [x0]
    6fe0:	eb010042 	subs	x2, x2, x1
    6fe4:	d2800001 	mov	x1, #0x0                   	// #0
    6fe8:	540006a1 	b.ne	70bc <f37+0x388>  // b.any
    6fec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6ff0:	aa1303e0 	mov	x0, x19
    6ff4:	a94353f3 	ldp	x19, x20, [sp, #48]
    6ff8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6ffc:	a94563f7 	ldp	x23, x24, [sp, #80]
    7000:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7004:	9101c3ff 	add	sp, sp, #0x70
    7008:	d65f03c0 	ret
    700c:	72003c3f 	tst	w1, #0xffff
    7010:	54fffe01 	b.ne	6fd0 <f37+0x29c>  // b.any
    7014:	17ffffea 	b	6fbc <f37+0x288>
    7018:	72003c3f 	tst	w1, #0xffff
    701c:	54fff5c1 	b.ne	6ed4 <f37+0x1a0>  // b.any
    7020:	17ffffa8 	b	6ec0 <f37+0x18c>
    7024:	72003c3f 	tst	w1, #0xffff
    7028:	54ffee41 	b.ne	6df0 <f37+0xbc>  // b.any
    702c:	17ffff6b 	b	6dd8 <f37+0xa4>
    7030:	cb0103e1 	neg	x1, x1
    7034:	eb02003f 	cmp	x1, x2
    7038:	540002e3 	b.cc	7094 <f37+0x360>  // b.lo, b.ul, b.last
    703c:	d503201f 	nop
    7040:	52800041 	mov	w1, #0x2                   	// #2
    7044:	d2800100 	mov	x0, #0x8                   	// #8
    7048:	97fff7ca 	bl	4f70 <fwp_heap_alloc>
    704c:	aa0003e1 	mov	x1, x0
    7050:	911742e0 	add	x0, x23, #0x5d0
    7054:	aa0103fa 	mov	x26, x1
    7058:	d2800018 	mov	x24, #0x0                   	// #0
    705c:	f900003f 	str	xzr, [x1]
    7060:	f949d801 	ldr	x1, [x0, #5040]
    7064:	f949ec00 	ldr	x0, [x0, #5080]
    7068:	cb010341 	sub	x1, x26, x1
    706c:	eb00403f 	cmp	x1, x0, lsl #16
    7070:	54fff562 	b.cs	6f1c <f37+0x1e8>  // b.hs, b.nlast
    7074:	d2800019 	mov	x25, #0x0                   	// #0
    7078:	17ffff7e 	b	6e70 <f37+0x13c>
    707c:	aa1303e0 	mov	x0, x19
    7080:	97fff5fc 	bl	4870 <fwp_rc_forget_slot>
    7084:	17ffff92 	b	6ecc <f37+0x198>
    7088:	aa1403e0 	mov	x0, x20
    708c:	97fff5f9 	bl	4870 <fwp_rc_forget_slot>
    7090:	17ffffce 	b	6fc8 <f37+0x294>
    7094:	f949fc62 	ldr	x2, [x3, #5112]
    7098:	d350fc20 	lsr	x0, x1, #16
    709c:	8b000800 	add	x0, x0, x0, lsl #2
    70a0:	8b000c42 	add	x2, x2, x0, lsl #3
    70a4:	f9401040 	ldr	x0, [x2, #32]
    70a8:	b4fffcc0 	cbz	x0, 7040 <f37+0x30c>
    70ac:	d2800018 	mov	x24, #0x0                   	// #0
    70b0:	17ffff3e 	b	6da8 <f37+0x74>
    70b4:	97fff5a8 	bl	4754 <fwp_rc_wide_dup>
    70b8:	17ffff4e 	b	6df0 <f37+0xbc>
    70bc:	97ffee15 	bl	2910 <__stack_chk_fail@plt>
    70c0:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    70c4:	910f8000 	add	x0, x0, #0x3e0
    70c8:	97fff1ee 	bl	3880 <fwp_trap>
    70cc:	d503201f 	nop

00000000000070d0 <fwp_owned_entry37>:
    70d0:	f9400000 	ldr	x0, [x0]
    70d4:	17ffff18 	b	6d34 <f37>
    70d8:	d503201f 	nop
    70dc:	d503201f 	nop

00000000000070e0 <e37>:
    70e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    70e4:	910003fd 	mov	x29, sp
    70e8:	f9000bf3 	str	x19, [sp, #16]
    70ec:	f9400013 	ldr	x19, [x0]
    70f0:	aa1303e0 	mov	x0, x19
    70f4:	97fff94b 	bl	5620 <fwp_rc_share>
    70f8:	aa1303e0 	mov	x0, x19
    70fc:	97ffff0e 	bl	6d34 <f37>
    7100:	aa0003f3 	mov	x19, x0
    7104:	97fff947 	bl	5620 <fwp_rc_share>
    7108:	aa1303e0 	mov	x0, x19
    710c:	f9400bf3 	ldr	x19, [sp, #16]
    7110:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7114:	d65f03c0 	ret
    7118:	d503201f 	nop
    711c:	d503201f 	nop

0000000000007120 <fwp_write>:
    7120:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7124:	910003fd 	mov	x29, sp
    7128:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    712c:	f947f484 	ldr	x4, [x4, #4072]
    7130:	a90153f3 	stp	x19, x20, [sp, #16]
    7134:	d10943ff 	sub	sp, sp, #0x250
    7138:	b9400045 	ldr	w5, [x2]
    713c:	aa0003f4 	mov	x20, x0
    7140:	f9400080 	ldr	x0, [x4]
    7144:	f90127e0 	str	x0, [sp, #584]
    7148:	d2800000 	mov	x0, #0x0                   	// #0
    714c:	710064bf 	cmp	w5, #0x19
    7150:	54000408 	b.hi	71d0 <fwp_write+0xb0>  // b.pmore
    7154:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    7158:	aa0103f3 	mov	x19, x1
    715c:	9132c000 	add	x0, x0, #0xcb0
    7160:	f9013bf5 	str	x21, [sp, #624]
    7164:	f9013ff6 	str	x22, [sp, #632]
    7168:	f90153fb 	str	x27, [sp, #672]
    716c:	f90157fc 	str	x28, [sp, #680]
    7170:	aa0203fc 	mov	x28, x2
    7174:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7178:	10000061 	adr	x1, 7184 <fwp_write+0x64>
    717c:	8b20a820 	add	x0, x1, w0, sxth #2
    7180:	d61f0000 	br	x0
    7184:	910123e0 	add	x0, sp, #0x48
    7188:	aa1303e5 	mov	x5, x19
    718c:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    7190:	aa0003f3 	mov	x19, x0
    7194:	9110a084 	add	x4, x4, #0x428
    7198:	d2804003 	mov	x3, #0x200                 	// #512
    719c:	aa0303e1 	mov	x1, x3
    71a0:	52800042 	mov	w2, #0x2                   	// #2
    71a4:	97ffedb7 	bl	2880 <__snprintf_chk@plt>
    71a8:	aa1303e0 	mov	x0, x19
    71ac:	97ffed7d 	bl	27a0 <strlen@plt>
    71b0:	aa1303e1 	mov	x1, x19
    71b4:	aa0003e2 	mov	x2, x0
    71b8:	aa1403e0 	mov	x0, x20
    71bc:	97fff115 	bl	3610 <buf_put>
    71c0:	f9413bf5 	ldr	x21, [sp, #624]
    71c4:	f9413ff6 	ldr	x22, [sp, #632]
    71c8:	f94153fb 	ldr	x27, [sp, #672]
    71cc:	f94157fc 	ldr	x28, [sp, #680]
    71d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    71d4:	f947f400 	ldr	x0, [x0, #4072]
    71d8:	f94127e2 	ldr	x2, [sp, #584]
    71dc:	f9400001 	ldr	x1, [x0]
    71e0:	eb010042 	subs	x2, x2, x1
    71e4:	d2800001 	mov	x1, #0x0                   	// #0
    71e8:	540077c1 	b.ne	80e0 <fwp_write+0xfc0>  // b.any
    71ec:	910943ff 	add	sp, sp, #0x250
    71f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    71f4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    71f8:	d65f03c0 	ret
    71fc:	910123e0 	add	x0, sp, #0x48
    7200:	aa1303e5 	mov	x5, x19
    7204:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    7208:	aa0003f3 	mov	x19, x0
    720c:	91108084 	add	x4, x4, #0x420
    7210:	d2804003 	mov	x3, #0x200                 	// #512
    7214:	17ffffe2 	b	719c <fwp_write+0x7c>
    7218:	71004cbf 	cmp	w5, #0x13
    721c:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    7220:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7224:	91104000 	add	x0, x0, #0x410
    7228:	91106021 	add	x1, x1, #0x418
    722c:	d2800082 	mov	x2, #0x4                   	// #4
    7230:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7234:	aa1403e0 	mov	x0, x20
    7238:	f90143f7 	str	x23, [sp, #640]
    723c:	d2800016 	mov	x22, #0x0                   	// #0
    7240:	f90147f8 	str	x24, [sp, #648]
    7244:	97fff0f3 	bl	3610 <buf_put>
    7248:	f9400260 	ldr	x0, [x19]
    724c:	d0000037 	adrp	x23, d000 <_IO_stdin_used+0xc0>
    7250:	d2800015 	mov	x21, #0x0                   	// #0
    7254:	911262f7 	add	x23, x23, #0x498
    7258:	b40047a0 	cbz	x0, 7b4c <fwp_write+0xa2c>
    725c:	b9400380 	ldr	w0, [x28]
    7260:	52800003 	mov	w3, #0x0                   	// #0
    7264:	f9401f82 	ldr	x2, [x28, #56]
    7268:	71004c1f 	cmp	w0, #0x13
    726c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7270:	aa1403e0 	mov	x0, x20
    7274:	8b010e61 	add	x1, x19, x1, lsl #3
    7278:	f9400421 	ldr	x1, [x1, #8]
    727c:	97ffffa9 	bl	7120 <fwp_write>
    7280:	b9400380 	ldr	w0, [x28]
    7284:	7100481f 	cmp	w0, #0x12
    7288:	54004b40 	b.eq	7bf0 <fwp_write+0xad0>  // b.none
    728c:	f9400260 	ldr	x0, [x19]
    7290:	910006b5 	add	x21, x21, #0x1
    7294:	91000ad6 	add	x22, x22, #0x2
    7298:	eb15001f 	cmp	x0, x21
    729c:	54004589 	b.ls	7b4c <fwp_write+0xa2c>  // b.plast
    72a0:	aa1703e1 	mov	x1, x23
    72a4:	aa1403e0 	mov	x0, x20
    72a8:	d2800042 	mov	x2, #0x2                   	// #2
    72ac:	97fff0d9 	bl	3610 <buf_put>
    72b0:	17ffffeb 	b	725c <fwp_write+0x13c>
    72b4:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    72b8:	91114021 	add	x1, x1, #0x450
    72bc:	d28000c2 	mov	x2, #0x6                   	// #6
    72c0:	aa1403e0 	mov	x0, x20
    72c4:	91004273 	add	x19, x19, #0x10
    72c8:	97fff0d2 	bl	3610 <buf_put>
    72cc:	aa1303e0 	mov	x0, x19
    72d0:	97ffed34 	bl	27a0 <strlen@plt>
    72d4:	aa1303e1 	mov	x1, x19
    72d8:	aa0003e2 	mov	x2, x0
    72dc:	aa1403e0 	mov	x0, x20
    72e0:	97fff0cc 	bl	3610 <buf_put>
    72e4:	528007c3 	mov	w3, #0x3e                  	// #62
    72e8:	aa1403e0 	mov	x0, x20
    72ec:	91001fe1 	add	x1, sp, #0x7
    72f0:	d2800022 	mov	x2, #0x1                   	// #1
    72f4:	39001fe3 	strb	w3, [sp, #7]
    72f8:	17ffffb1 	b	71bc <fwp_write+0x9c>
    72fc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7300:	f947f400 	ldr	x0, [x0, #4072]
    7304:	f94127e2 	ldr	x2, [sp, #584]
    7308:	f9400001 	ldr	x1, [x0]
    730c:	eb010042 	subs	x2, x2, x1
    7310:	d2800001 	mov	x1, #0x0                   	// #0
    7314:	540034e1 	b.ne	79b0 <fwp_write+0x890>  // b.any
    7318:	f9413bf5 	ldr	x21, [sp, #624]
    731c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7320:	f9413ff6 	ldr	x22, [sp, #632]
    7324:	aa1403e0 	mov	x0, x20
    7328:	9110c021 	add	x1, x1, #0x430
    732c:	d2800142 	mov	x2, #0xa                   	// #10
    7330:	f94153fb 	ldr	x27, [sp, #672]
    7334:	f94157fc 	ldr	x28, [sp, #680]
    7338:	910943ff 	add	sp, sp, #0x250
    733c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7340:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7344:	17fff0b3 	b	3610 <buf_put>
    7348:	f9400456 	ldr	x22, [x2, #8]
    734c:	f90143f7 	str	x23, [sp, #640]
    7350:	f90147f8 	str	x24, [sp, #648]
    7354:	b4005b16 	cbz	x22, 7eb4 <fwp_write+0xd94>
    7358:	aa1603e0 	mov	x0, x22
    735c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7360:	9112c021 	add	x1, x1, #0x4b0
    7364:	97ffed8b 	bl	2990 <strcmp@plt>
    7368:	2a0003f5 	mov	w21, w0
    736c:	34005fe0 	cbz	w0, 7f68 <fwp_write+0xe48>
    7370:	aa1603e0 	mov	x0, x22
    7374:	97ffed0b 	bl	27a0 <strlen@plt>
    7378:	aa1603e1 	mov	x1, x22
    737c:	aa0003e2 	mov	x2, x0
    7380:	aa1403e0 	mov	x0, x20
    7384:	97fff0a3 	bl	3610 <buf_put>
    7388:	52800403 	mov	w3, #0x20                  	// #32
    738c:	91001ff5 	add	x21, sp, #0x7
    7390:	aa1503e1 	mov	x1, x21
    7394:	aa1403e0 	mov	x0, x20
    7398:	d2800022 	mov	x2, #0x1                   	// #1
    739c:	39001fe3 	strb	w3, [sp, #7]
    73a0:	97fff09c 	bl	3610 <buf_put>
    73a4:	52800f63 	mov	w3, #0x7b                  	// #123
    73a8:	aa1403e0 	mov	x0, x20
    73ac:	aa1503e1 	mov	x1, x21
    73b0:	d2800022 	mov	x2, #0x1                   	// #1
    73b4:	39001fe3 	strb	w3, [sp, #7]
    73b8:	97fff096 	bl	3610 <buf_put>
    73bc:	b9401380 	ldr	w0, [x28, #16]
    73c0:	52800018 	mov	w24, #0x0                   	// #0
    73c4:	7100001f 	cmp	w0, #0x0
    73c8:	54003aad 	b.le	7b1c <fwp_write+0x9fc>
    73cc:	f9014bf9 	str	x25, [sp, #656]
    73d0:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0xc0>
    73d4:	91136339 	add	x25, x25, #0x4d8
    73d8:	f9014ffa 	str	x26, [sp, #664]
    73dc:	d000003a 	adrp	x26, d000 <_IO_stdin_used+0xc0>
    73e0:	9112635a 	add	x26, x26, #0x498
    73e4:	91002276 	add	x22, x19, #0x8
    73e8:	d2800013 	mov	x19, #0x0                   	// #0
    73ec:	b5003e93 	cbnz	x19, 7bbc <fwp_write+0xa9c>
    73f0:	d37df277 	lsl	x23, x19, #3
    73f4:	34003cb8 	cbz	w24, 7b88 <fwp_write+0xa68>
    73f8:	f9401382 	ldr	x2, [x28, #32]
    73fc:	aa1403e0 	mov	x0, x20
    7400:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7404:	52800003 	mov	w3, #0x0                   	// #0
    7408:	f8776842 	ldr	x2, [x2, x23]
    740c:	91000673 	add	x19, x19, #0x1
    7410:	97ffff44 	bl	7120 <fwp_write>
    7414:	b9401380 	ldr	w0, [x28, #16]
    7418:	6b13001f 	cmp	w0, w19
    741c:	54fffe8c 	b.gt	73ec <fwp_write+0x2cc>
    7420:	f9414bf9 	ldr	x25, [sp, #656]
    7424:	f9414ffa 	ldr	x26, [sp, #664]
    7428:	340037b8 	cbz	w24, 7b1c <fwp_write+0x9fc>
    742c:	52800523 	mov	w3, #0x29                  	// #41
    7430:	aa1503e1 	mov	x1, x21
    7434:	aa1403e0 	mov	x0, x20
    7438:	d2800022 	mov	x2, #0x1                   	// #1
    743c:	39001fe3 	strb	w3, [sp, #7]
    7440:	97fff074 	bl	3610 <buf_put>
    7444:	f9413bf5 	ldr	x21, [sp, #624]
    7448:	f9413ff6 	ldr	x22, [sp, #632]
    744c:	f94143f7 	ldr	x23, [sp, #640]
    7450:	f94147f8 	ldr	x24, [sp, #648]
    7454:	f94153fb 	ldr	x27, [sp, #672]
    7458:	f94157fc 	ldr	x28, [sp, #680]
    745c:	17ffff5d 	b	71d0 <fwp_write+0xb0>
    7460:	b9404855 	ldr	w21, [x2, #72]
    7464:	aa1403e0 	mov	x0, x20
    7468:	93407eb6 	sxtw	x22, w21
    746c:	91000ac1 	add	x1, x22, #0x2
    7470:	97fff035 	bl	3544 <buf_grow>
    7474:	a9400281 	ldp	x1, x0, [x20]
    7478:	528e8603 	mov	w3, #0x7430                	// #29744
    747c:	78206823 	strh	w3, [x1, x0]
    7480:	8b000022 	add	x2, x1, x0
    7484:	710002bf 	cmp	w21, #0x0
    7488:	540036cd 	b.le	7b60 <fwp_write+0xa40>
    748c:	110006a3 	add	w3, w21, #0x1
    7490:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7494:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7498:	91000449 	add	x9, x2, #0x1
    749c:	8b23c043 	add	x3, x2, w3, sxtw
    74a0:	f28aaac6 	movk	x6, #0x5556
    74a4:	f2955568 	movk	x8, #0xaaab
    74a8:	1400000d 	b	74dc <fwp_write+0x3bc>
    74ac:	d2800021 	mov	x1, #0x1                   	// #1
    74b0:	528005a5 	mov	w5, #0x2d                  	// #45
    74b4:	f100001f 	cmp	x0, #0x0
    74b8:	9b467e60 	smulh	x0, x19, x6
    74bc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    74c0:	381ff465 	strb	w5, [x3], #-1
    74c4:	cb040000 	sub	x0, x0, x4
    74c8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    74cc:	cb020000 	sub	x0, x0, x2
    74d0:	8b010013 	add	x19, x0, x1
    74d4:	eb03013f 	cmp	x9, x3
    74d8:	54003440 	b.eq	7b60 <fwp_write+0xa40>  // b.none
    74dc:	9b467e60 	smulh	x0, x19, x6
    74e0:	937ffe64 	asr	x4, x19, #63
    74e4:	52800605 	mov	w5, #0x30                  	// #48
    74e8:	cb040000 	sub	x0, x0, x4
    74ec:	8b000400 	add	x0, x0, x0, lsl #1
    74f0:	cb000260 	sub	x0, x19, x0
    74f4:	91000c01 	add	x1, x0, #0x3
    74f8:	9bc87c22 	umulh	x2, x1, x8
    74fc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7500:	8b4204e2 	add	x2, x7, x2, lsr #1
    7504:	eb020021 	subs	x1, x1, x2
    7508:	54fffd60 	b.eq	74b4 <fwp_write+0x394>  // b.none
    750c:	f100043f 	cmp	x1, #0x1
    7510:	54fffce1 	b.ne	74ac <fwp_write+0x38c>  // b.any
    7514:	d2800001 	mov	x1, #0x0                   	// #0
    7518:	52800565 	mov	w5, #0x2b                  	// #43
    751c:	17ffffe6 	b	74b4 <fwp_write+0x394>
    7520:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7524:	f947f400 	ldr	x0, [x0, #4072]
    7528:	f94127e2 	ldr	x2, [sp, #584]
    752c:	f9400001 	ldr	x1, [x0]
    7530:	eb010042 	subs	x2, x2, x1
    7534:	d2800001 	mov	x1, #0x0                   	// #0
    7538:	540023c1 	b.ne	79b0 <fwp_write+0x890>  // b.any
    753c:	f9413bf5 	ldr	x21, [sp, #624]
    7540:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7544:	f9413ff6 	ldr	x22, [sp, #632]
    7548:	aa1403e0 	mov	x0, x20
    754c:	91110021 	add	x1, x1, #0x440
    7550:	d2800102 	mov	x2, #0x8                   	// #8
    7554:	17ffff77 	b	7330 <fwp_write+0x210>
    7558:	aa1403e0 	mov	x0, x20
    755c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7560:	d28000c2 	mov	x2, #0x6                   	// #6
    7564:	91128021 	add	x1, x1, #0x4a0
    7568:	97fff02a 	bl	3610 <buf_put>
    756c:	d2800015 	mov	x21, #0x0                   	// #0
    7570:	f9400263 	ldr	x3, [x19]
    7574:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7578:	54002c60 	b.eq	7b04 <fwp_write+0x9e4>  // b.none
    757c:	f9401f82 	ldr	x2, [x28, #56]
    7580:	f90143f7 	str	x23, [sp, #640]
    7584:	f90147f8 	str	x24, [sp, #648]
    7588:	d2800857 	mov	x23, #0x42                  	// #66
    758c:	f9014bf9 	str	x25, [sp, #656]
    7590:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0xc0>
    7594:	f9014ffa 	str	x26, [sp, #664]
    7598:	911262d6 	add	x22, x22, #0x498
    759c:	d2800038 	mov	x24, #0x1                   	// #1
    75a0:	f2a18017 	movk	x23, #0xc00, lsl #16
    75a4:	d2809099 	mov	x25, #0x484                 	// #1156
    75a8:	b40004a2 	cbz	x2, 763c <fwp_write+0x51c>
    75ac:	b9400040 	ldr	w0, [x2]
    75b0:	7100701f 	cmp	w0, #0x1c
    75b4:	540042c0 	b.eq	7e0c <fwp_write+0xcec>  // b.none
    75b8:	71006c1f 	cmp	w0, #0x1b
    75bc:	54000408 	b.hi	763c <fwp_write+0x51c>  // b.pmore
    75c0:	9ac02301 	lsl	x1, x24, x0
    75c4:	ea17003f 	tst	x1, x23
    75c8:	540036a1 	b.ne	7c9c <fwp_write+0xb7c>  // b.any
    75cc:	ea19003f 	tst	x1, x25
    75d0:	54003521 	b.ne	7c74 <fwp_write+0xb54>  // b.any
    75d4:	d2800424 	mov	x4, #0x21                  	// #33
    75d8:	ea04003f 	tst	x1, x4
    75dc:	54000300 	b.eq	763c <fwp_write+0x51c>  // b.none
    75e0:	b7f849c3 	tbnz	x3, #63, 7f18 <fwp_write+0xdf8>
    75e4:	91002261 	add	x1, x19, #0x8
    75e8:	8b150021 	add	x1, x1, x21
    75ec:	39400021 	ldrb	w1, [x1]
    75f0:	7100001f 	cmp	w0, #0x0
    75f4:	93401c23 	sxtb	x3, w1
    75f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    75fc:	d503201f 	nop
    7600:	aa1403e0 	mov	x0, x20
    7604:	52800003 	mov	w3, #0x0                   	// #0
    7608:	97fffec6 	bl	7120 <fwp_write>
    760c:	910006b5 	add	x21, x21, #0x1
    7610:	f9400260 	ldr	x0, [x19]
    7614:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7618:	eb0002bf 	cmp	x21, x0
    761c:	540026c2 	b.cs	7af4 <fwp_write+0x9d4>  // b.hs, b.nlast
    7620:	d2800042 	mov	x2, #0x2                   	// #2
    7624:	aa1603e1 	mov	x1, x22
    7628:	aa1403e0 	mov	x0, x20
    762c:	97ffeff9 	bl	3610 <buf_put>
    7630:	f9401f82 	ldr	x2, [x28, #56]
    7634:	f9400263 	ldr	x3, [x19]
    7638:	b5fffba2 	cbnz	x2, 75ac <fwp_write+0x48c>
    763c:	d37df2a0 	lsl	x0, x21, #3
    7640:	b7f83f03 	tbnz	x3, #63, 7e20 <fwp_write+0xd00>
    7644:	91002261 	add	x1, x19, #0x8
    7648:	8b000020 	add	x0, x1, x0
    764c:	f9400001 	ldr	x1, [x0]
    7650:	17ffffec 	b	7600 <fwp_write+0x4e0>
    7654:	a9400e62 	ldp	x2, x3, [x19]
    7658:	b7f83ca3 	tbnz	x3, #63, 7dec <fwp_write+0xccc>
    765c:	910123f5 	add	x21, sp, #0x48
    7660:	aa1503e0 	mov	x0, x21
    7664:	97ffee0f 	bl	2ea0 <fwp_fmt_u128>
    7668:	aa1503e0 	mov	x0, x21
    766c:	97ffec4d 	bl	27a0 <strlen@plt>
    7670:	aa1503e1 	mov	x1, x21
    7674:	aa0003e2 	mov	x2, x0
    7678:	17fffed0 	b	71b8 <fwp_write+0x98>
    767c:	fd015be8 	str	d8, [sp, #688]
    7680:	1e270268 	fmov	s8, w19
    7684:	fd015fe9 	str	d9, [sp, #696]
    7688:	1e282100 	fcmp	s8, s8
    768c:	54004d26 	b.vs	8030 <fwp_write+0xf10>
    7690:	1e20c101 	fabs	s1, s8
    7694:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7698:	1e270000 	fmov	s0, w0
    769c:	1e202020 	fcmp	s1, s0
    76a0:	54002c0d 	b.le	7c20 <fwp_write+0xb00>
    76a4:	1e202118 	fcmpe	s8, #0.0
    76a8:	d0000022 	adrp	x2, d000 <_IO_stdin_used+0xc0>
    76ac:	91006042 	add	x2, x2, #0x18
    76b0:	910123f5 	add	x21, sp, #0x48
    76b4:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    76b8:	910fc021 	add	x1, x1, #0x3f0
    76bc:	aa1503e0 	mov	x0, x21
    76c0:	9a81c041 	csel	x1, x2, x1, gt
    76c4:	97ffece3 	bl	2a50 <strcpy@plt>
    76c8:	aa1503e0 	mov	x0, x21
    76cc:	97ffec35 	bl	27a0 <strlen@plt>
    76d0:	aa1503e1 	mov	x1, x21
    76d4:	aa0003e2 	mov	x2, x0
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	97ffefcd 	bl	3610 <buf_put>
    76e0:	f9413bf5 	ldr	x21, [sp, #624]
    76e4:	f9413ff6 	ldr	x22, [sp, #632]
    76e8:	f94153fb 	ldr	x27, [sp, #672]
    76ec:	f94157fc 	ldr	x28, [sp, #680]
    76f0:	fd415be8 	ldr	d8, [sp, #688]
    76f4:	fd415fe9 	ldr	d9, [sp, #696]
    76f8:	17fffeb6 	b	71d0 <fwp_write+0xb0>
    76fc:	f9400276 	ldr	x22, [x19]
    7700:	34002e03 	cbz	w3, 7cc0 <fwp_write+0xba0>
    7704:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7708:	f947f400 	ldr	x0, [x0, #4072]
    770c:	f94127e2 	ldr	x2, [sp, #584]
    7710:	f9400001 	ldr	x1, [x0]
    7714:	eb010042 	subs	x2, x2, x1
    7718:	d2800001 	mov	x1, #0x0                   	// #0
    771c:	540014a1 	b.ne	79b0 <fwp_write+0x890>  // b.any
    7720:	aa1603e2 	mov	x2, x22
    7724:	91002261 	add	x1, x19, #0x8
    7728:	f9413bf5 	ldr	x21, [sp, #624]
    772c:	aa1403e0 	mov	x0, x20
    7730:	f9413ff6 	ldr	x22, [sp, #632]
    7734:	17fffeff 	b	7330 <fwp_write+0x210>
    7738:	fd015be8 	str	d8, [sp, #688]
    773c:	9e670268 	fmov	d8, x19
    7740:	fd015fe9 	str	d9, [sp, #696]
    7744:	1e682100 	fcmp	d8, d8
    7748:	54004746 	b.vs	8030 <fwp_write+0xf10>
    774c:	1e60c101 	fabs	d1, d8
    7750:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7754:	9e670000 	fmov	d0, x0
    7758:	910123f5 	add	x21, sp, #0x48
    775c:	52800033 	mov	w19, #0x1                   	// #1
    7760:	1e602020 	fcmp	d1, d0
    7764:	540001ad 	b.le	7798 <fwp_write+0x678>
    7768:	1e602118 	fcmpe	d8, #0.0
    776c:	d0000022 	adrp	x2, d000 <_IO_stdin_used+0xc0>
    7770:	91006042 	add	x2, x2, #0x18
    7774:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7778:	910fc021 	add	x1, x1, #0x3f0
    777c:	aa1503e0 	mov	x0, x21
    7780:	9a81c041 	csel	x1, x2, x1, gt
    7784:	97ffecb3 	bl	2a50 <strcpy@plt>
    7788:	17ffffd0 	b	76c8 <fwp_write+0x5a8>
    778c:	11000673 	add	w19, w19, #0x1
    7790:	71004a7f 	cmp	w19, #0x12
    7794:	54003860 	b.eq	7ea0 <fwp_write+0xd80>  // b.none
    7798:	1e604100 	fmov	d0, d8
    779c:	2a1303e1 	mov	w1, w19
    77a0:	aa1503e0 	mov	x0, x21
    77a4:	97fff11c 	bl	3c14 <fwp_format_g.constprop.0>
    77a8:	aa1503e0 	mov	x0, x21
    77ac:	d2800001 	mov	x1, #0x0                   	// #0
    77b0:	97ffec10 	bl	27f0 <strtod@plt>
    77b4:	1e602100 	fcmp	d8, d0
    77b8:	54fffea1 	b.ne	778c <fwp_write+0x66c>  // b.any
    77bc:	aa1503e0 	mov	x0, x21
    77c0:	97fff00d 	bl	37f4 <fwp_finish_float>
    77c4:	17ffffc1 	b	76c8 <fwp_write+0x5a8>
    77c8:	a9400e62 	ldp	x2, x3, [x19]
    77cc:	910123f3 	add	x19, sp, #0x48
    77d0:	aa1303e0 	mov	x0, x19
    77d4:	97ffedb3 	bl	2ea0 <fwp_fmt_u128>
    77d8:	17fffe74 	b	71a8 <fwp_write+0x88>
    77dc:	f90143f7 	str	x23, [sp, #640]
    77e0:	f90147f8 	str	x24, [sp, #648]
    77e4:	2a1303f8 	mov	w24, w19
    77e8:	f9014bf9 	str	x25, [sp, #656]
    77ec:	f9014ffa 	str	x26, [sp, #664]
    77f0:	f13ffe7f 	cmp	x19, #0xfff
    77f4:	54000049 	b.ls	77fc <fwp_write+0x6dc>  // b.plast
    77f8:	b9400278 	ldr	w24, [x19]
    77fc:	f9400f80 	ldr	x0, [x28, #24]
    7800:	2a1803f5 	mov	w21, w24
    7804:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7808:	d37ef6b9 	lsl	x25, x21, #2
    780c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7810:	aa1603e0 	mov	x0, x22
    7814:	97ffebe3 	bl	27a0 <strlen@plt>
    7818:	aa1603e1 	mov	x1, x22
    781c:	aa0003e2 	mov	x2, x0
    7820:	aa1403e0 	mov	x0, x20
    7824:	97ffef7b 	bl	3610 <buf_put>
    7828:	f9401780 	ldr	x0, [x28, #40]
    782c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7830:	7100001f 	cmp	w0, #0x0
    7834:	5400068d 	b.le	7904 <fwp_write+0x7e4>
    7838:	91002276 	add	x22, x19, #0x8
    783c:	91001ff5 	add	x21, sp, #0x7
    7840:	d280001b 	mov	x27, #0x0                   	// #0
    7844:	5280041a 	mov	w26, #0x20                  	// #32
    7848:	f9401b80 	ldr	x0, [x28, #48]
    784c:	aa1503e1 	mov	x1, x21
    7850:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7854:	d2800022 	mov	x2, #0x1                   	// #1
    7858:	f8786803 	ldr	x3, [x0, x24]
    785c:	aa1403e0 	mov	x0, x20
    7860:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7864:	39001ffa 	strb	w26, [sp, #7]
    7868:	97ffef6a 	bl	3610 <buf_put>
    786c:	f13ffeff 	cmp	x23, #0xfff
    7870:	b9400261 	ldr	w1, [x19]
    7874:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7878:	7100383f 	cmp	w1, #0xe
    787c:	54000160 	b.eq	78a8 <fwp_write+0x788>  // b.none
    7880:	7100403f 	cmp	w1, #0x10
    7884:	54001a60 	b.eq	7bd0 <fwp_write+0xab0>  // b.none
    7888:	7100283f 	cmp	w1, #0xa
    788c:	54002aa0 	b.eq	7de0 <fwp_write+0xcc0>  // b.none
    7890:	540014ac 	b.gt	7b24 <fwp_write+0xa04>
    7894:	71000c3f 	cmp	w1, #0x3
    7898:	540029ac 	b.gt	7dcc <fwp_write+0xcac>
    789c:	d37ffee0 	lsr	x0, x23, #63
    78a0:	37f814a1 	tbnz	w1, #31, 7b34 <fwp_write+0xa14>
    78a4:	d503201f 	nop
    78a8:	34001460 	cbz	w0, 7b34 <fwp_write+0xa14>
    78ac:	52800503 	mov	w3, #0x28                  	// #40
    78b0:	aa1503e1 	mov	x1, x21
    78b4:	aa1403e0 	mov	x0, x20
    78b8:	d2800022 	mov	x2, #0x1                   	// #1
    78bc:	39001fe3 	strb	w3, [sp, #7]
    78c0:	97ffef54 	bl	3610 <buf_put>
    78c4:	aa1303e2 	mov	x2, x19
    78c8:	aa1703e1 	mov	x1, x23
    78cc:	aa1403e0 	mov	x0, x20
    78d0:	52800003 	mov	w3, #0x0                   	// #0
    78d4:	97fffe13 	bl	7120 <fwp_write>
    78d8:	52800523 	mov	w3, #0x29                  	// #41
    78dc:	aa1503e1 	mov	x1, x21
    78e0:	aa1403e0 	mov	x0, x20
    78e4:	d2800022 	mov	x2, #0x1                   	// #1
    78e8:	39001fe3 	strb	w3, [sp, #7]
    78ec:	97ffef49 	bl	3610 <buf_put>
    78f0:	f9401780 	ldr	x0, [x28, #40]
    78f4:	9100077b 	add	x27, x27, #0x1
    78f8:	b8796800 	ldr	w0, [x0, x25]
    78fc:	6b1b001f 	cmp	w0, w27
    7900:	54fffa4c 	b.gt	7848 <fwp_write+0x728>
    7904:	f9413bf5 	ldr	x21, [sp, #624]
    7908:	f9413ff6 	ldr	x22, [sp, #632]
    790c:	f94143f7 	ldr	x23, [sp, #640]
    7910:	f94147f8 	ldr	x24, [sp, #648]
    7914:	f9414bf9 	ldr	x25, [sp, #656]
    7918:	f9414ffa 	ldr	x26, [sp, #664]
    791c:	f94153fb 	ldr	x27, [sp, #672]
    7920:	f94157fc 	ldr	x28, [sp, #680]
    7924:	17fffe2b 	b	71d0 <fwp_write+0xb0>
    7928:	52800783 	mov	w3, #0x3c                  	// #60
    792c:	91001ff3 	add	x19, sp, #0x7
    7930:	aa1303e1 	mov	x1, x19
    7934:	d2800022 	mov	x2, #0x1                   	// #1
    7938:	aa1403e0 	mov	x0, x20
    793c:	39001fe3 	strb	w3, [sp, #7]
    7940:	97ffef34 	bl	3610 <buf_put>
    7944:	f9400795 	ldr	x21, [x28, #8]
    7948:	aa1503e0 	mov	x0, x21
    794c:	97ffeb95 	bl	27a0 <strlen@plt>
    7950:	aa1503e1 	mov	x1, x21
    7954:	aa0003e2 	mov	x2, x0
    7958:	aa1403e0 	mov	x0, x20
    795c:	97ffef2d 	bl	3610 <buf_put>
    7960:	528007c3 	mov	w3, #0x3e                  	// #62
    7964:	aa1303e1 	mov	x1, x19
    7968:	aa1403e0 	mov	x0, x20
    796c:	d2800022 	mov	x2, #0x1                   	// #1
    7970:	39001fe3 	strb	w3, [sp, #7]
    7974:	17fffe12 	b	71bc <fwp_write+0x9c>
    7978:	f100067f 	cmp	x19, #0x1
    797c:	540025a0 	b.eq	7e30 <fwp_write+0xd10>  // b.none
    7980:	b100067f 	cmn	x19, #0x1
    7984:	54002bc0 	b.eq	7efc <fwp_write+0xddc>  // b.none
    7988:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    798c:	910fe021 	add	x1, x1, #0x3f8
    7990:	d2800022 	mov	x2, #0x1                   	// #1
    7994:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7998:	f947f400 	ldr	x0, [x0, #4072]
    799c:	f94127e4 	ldr	x4, [sp, #584]
    79a0:	f9400003 	ldr	x3, [x0]
    79a4:	eb030084 	subs	x4, x4, x3
    79a8:	d2800003 	mov	x3, #0x0                   	// #0
    79ac:	54ffebe0 	b.eq	7728 <fwp_write+0x608>  // b.none
    79b0:	f90143f7 	str	x23, [sp, #640]
    79b4:	f90147f8 	str	x24, [sp, #648]
    79b8:	f9014bf9 	str	x25, [sp, #656]
    79bc:	f9014ffa 	str	x26, [sp, #664]
    79c0:	fd015be8 	str	d8, [sp, #688]
    79c4:	fd015fe9 	str	d9, [sp, #696]
    79c8:	97ffebd2 	bl	2910 <__stack_chk_fail@plt>
    79cc:	52800b63 	mov	w3, #0x5b                  	// #91
    79d0:	91001ff5 	add	x21, sp, #0x7
    79d4:	aa1503e1 	mov	x1, x21
    79d8:	aa1403e0 	mov	x0, x20
    79dc:	d2800022 	mov	x2, #0x1                   	// #1
    79e0:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0xc0>
    79e4:	911262d6 	add	x22, x22, #0x498
    79e8:	39001fe3 	strb	w3, [sp, #7]
    79ec:	97ffef09 	bl	3610 <buf_put>
    79f0:	b4000273 	cbz	x19, 7a3c <fwp_write+0x91c>
    79f4:	f9400661 	ldr	x1, [x19, #8]
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	f9401f82 	ldr	x2, [x28, #56]
    7a00:	52800003 	mov	w3, #0x0                   	// #0
    7a04:	97fffdc7 	bl	7120 <fwp_write>
    7a08:	f9400a73 	ldr	x19, [x19, #16]
    7a0c:	b4000193 	cbz	x19, 7a3c <fwp_write+0x91c>
    7a10:	aa1603e1 	mov	x1, x22
    7a14:	aa1403e0 	mov	x0, x20
    7a18:	d2800042 	mov	x2, #0x2                   	// #2
    7a1c:	97ffeefd 	bl	3610 <buf_put>
    7a20:	f9400661 	ldr	x1, [x19, #8]
    7a24:	aa1403e0 	mov	x0, x20
    7a28:	f9401f82 	ldr	x2, [x28, #56]
    7a2c:	52800003 	mov	w3, #0x0                   	// #0
    7a30:	97fffdbc 	bl	7120 <fwp_write>
    7a34:	f9400a73 	ldr	x19, [x19, #16]
    7a38:	b5fffed3 	cbnz	x19, 7a10 <fwp_write+0x8f0>
    7a3c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7a40:	aa1503e1 	mov	x1, x21
    7a44:	aa1403e0 	mov	x0, x20
    7a48:	d2800022 	mov	x2, #0x1                   	// #1
    7a4c:	39001fe3 	strb	w3, [sp, #7]
    7a50:	17fffddb 	b	71bc <fwp_write+0x9c>
    7a54:	aa1403e0 	mov	x0, x20
    7a58:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7a5c:	d28000c2 	mov	x2, #0x6                   	// #6
    7a60:	91122021 	add	x1, x1, #0x488
    7a64:	97ffeeeb 	bl	3610 <buf_put>
    7a68:	f9400260 	ldr	x0, [x19]
    7a6c:	b40004c0 	cbz	x0, 7b04 <fwp_write+0x9e4>
    7a70:	910123f5 	add	x21, sp, #0x48
    7a74:	91002276 	add	x22, x19, #0x8
    7a78:	f90143f7 	str	x23, [sp, #640]
    7a7c:	d2800017 	mov	x23, #0x0                   	// #0
    7a80:	f90147f8 	str	x24, [sp, #648]
    7a84:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0xc0>
    7a88:	91124318 	add	x24, x24, #0x490
    7a8c:	f9014bf9 	str	x25, [sp, #656]
    7a90:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0xc0>
    7a94:	91126339 	add	x25, x25, #0x498
    7a98:	f9014ffa 	str	x26, [sp, #664]
    7a9c:	14000005 	b	7ab0 <fwp_write+0x990>
    7aa0:	aa1903e1 	mov	x1, x25
    7aa4:	aa1403e0 	mov	x0, x20
    7aa8:	d2800042 	mov	x2, #0x2                   	// #2
    7aac:	97ffeed9 	bl	3610 <buf_put>
    7ab0:	38776ac5 	ldrb	w5, [x22, x23]
    7ab4:	d2804003 	mov	x3, #0x200                 	// #512
    7ab8:	aa1803e4 	mov	x4, x24
    7abc:	aa0303e1 	mov	x1, x3
    7ac0:	52800042 	mov	w2, #0x2                   	// #2
    7ac4:	aa1503e0 	mov	x0, x21
    7ac8:	910006f7 	add	x23, x23, #0x1
    7acc:	97ffeb6d 	bl	2880 <__snprintf_chk@plt>
    7ad0:	aa1503e0 	mov	x0, x21
    7ad4:	97ffeb33 	bl	27a0 <strlen@plt>
    7ad8:	aa1503e1 	mov	x1, x21
    7adc:	aa0003e2 	mov	x2, x0
    7ae0:	aa1403e0 	mov	x0, x20
    7ae4:	97ffeecb 	bl	3610 <buf_put>
    7ae8:	f9400260 	ldr	x0, [x19]
    7aec:	eb17001f 	cmp	x0, x23
    7af0:	54fffd88 	b.hi	7aa0 <fwp_write+0x980>  // b.pmore
    7af4:	f94143f7 	ldr	x23, [sp, #640]
    7af8:	f94147f8 	ldr	x24, [sp, #648]
    7afc:	f9414bf9 	ldr	x25, [sp, #656]
    7b00:	f9414ffa 	ldr	x26, [sp, #664]
    7b04:	52800ba3 	mov	w3, #0x5d                  	// #93
    7b08:	aa1403e0 	mov	x0, x20
    7b0c:	91001fe1 	add	x1, sp, #0x7
    7b10:	d2800022 	mov	x2, #0x1                   	// #1
    7b14:	39001fe3 	strb	w3, [sp, #7]
    7b18:	17fffda9 	b	71bc <fwp_write+0x9c>
    7b1c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b20:	17fffe44 	b	7430 <fwp_write+0x310>
    7b24:	f10002ff 	cmp	x23, #0x0
    7b28:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7b2c:	71002c3f 	cmp	w1, #0xb
    7b30:	54ffebc0 	b.eq	78a8 <fwp_write+0x788>  // b.none
    7b34:	aa1303e2 	mov	x2, x19
    7b38:	aa1703e1 	mov	x1, x23
    7b3c:	aa1403e0 	mov	x0, x20
    7b40:	52800003 	mov	w3, #0x0                   	// #0
    7b44:	97fffd77 	bl	7120 <fwp_write>
    7b48:	17ffff6a 	b	78f0 <fwp_write+0x7d0>
    7b4c:	aa1403e0 	mov	x0, x20
    7b50:	91001fe1 	add	x1, sp, #0x7
    7b54:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b58:	d2800022 	mov	x2, #0x1                   	// #1
    7b5c:	17fffe38 	b	743c <fwp_write+0x31c>
    7b60:	a9400281 	ldp	x1, x0, [x20]
    7b64:	91000800 	add	x0, x0, #0x2
    7b68:	8b160000 	add	x0, x0, x22
    7b6c:	f9000680 	str	x0, [x20, #8]
    7b70:	3820683f 	strb	wzr, [x1, x0]
    7b74:	f9413bf5 	ldr	x21, [sp, #624]
    7b78:	f9413ff6 	ldr	x22, [sp, #632]
    7b7c:	f94153fb 	ldr	x27, [sp, #672]
    7b80:	f94157fc 	ldr	x28, [sp, #680]
    7b84:	17fffd93 	b	71d0 <fwp_write+0xb0>
    7b88:	f9400f80 	ldr	x0, [x28, #24]
    7b8c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7b90:	aa1b03e0 	mov	x0, x27
    7b94:	97ffeb03 	bl	27a0 <strlen@plt>
    7b98:	aa1b03e1 	mov	x1, x27
    7b9c:	aa0003e2 	mov	x2, x0
    7ba0:	aa1403e0 	mov	x0, x20
    7ba4:	97ffee9b 	bl	3610 <buf_put>
    7ba8:	aa1903e1 	mov	x1, x25
    7bac:	aa1403e0 	mov	x0, x20
    7bb0:	d2800062 	mov	x2, #0x3                   	// #3
    7bb4:	97ffee97 	bl	3610 <buf_put>
    7bb8:	17fffe10 	b	73f8 <fwp_write+0x2d8>
    7bbc:	aa1a03e1 	mov	x1, x26
    7bc0:	aa1403e0 	mov	x0, x20
    7bc4:	d2800042 	mov	x2, #0x2                   	// #2
    7bc8:	97ffee92 	bl	3610 <buf_put>
    7bcc:	17fffe09 	b	73f0 <fwp_write+0x2d0>
    7bd0:	f9400660 	ldr	x0, [x19, #8]
    7bd4:	b4fffb00 	cbz	x0, 7b34 <fwp_write+0xa14>
    7bd8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7bdc:	9112c021 	add	x1, x1, #0x4b0
    7be0:	97ffeb6c 	bl	2990 <strcmp@plt>
    7be4:	7100001f 	cmp	w0, #0x0
    7be8:	1a9f07e0 	cset	w0, ne	// ne = any
    7bec:	17ffff2f 	b	78a8 <fwp_write+0x788>
    7bf0:	aa1403e0 	mov	x0, x20
    7bf4:	d2800042 	mov	x2, #0x2                   	// #2
    7bf8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7bfc:	9112a021 	add	x1, x1, #0x4a8
    7c00:	97ffee84 	bl	3610 <buf_put>
    7c04:	91004261 	add	x1, x19, #0x10
    7c08:	aa1403e0 	mov	x0, x20
    7c0c:	f9402382 	ldr	x2, [x28, #64]
    7c10:	52800003 	mov	w3, #0x0                   	// #0
    7c14:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7c18:	97fffd42 	bl	7120 <fwp_write>
    7c1c:	17fffd9c 	b	728c <fwp_write+0x16c>
    7c20:	1e22c109 	fcvt	d9, s8
    7c24:	910123f5 	add	x21, sp, #0x48
    7c28:	52800033 	mov	w19, #0x1                   	// #1
    7c2c:	d503201f 	nop
    7c30:	1e604120 	fmov	d0, d9
    7c34:	2a1303e1 	mov	w1, w19
    7c38:	aa1503e0 	mov	x0, x21
    7c3c:	97ffeff6 	bl	3c14 <fwp_format_g.constprop.0>
    7c40:	aa1503e0 	mov	x0, x21
    7c44:	d2800001 	mov	x1, #0x0                   	// #0
    7c48:	97ffeb5e 	bl	29c0 <strtof@plt>
    7c4c:	1e202100 	fcmp	s8, s0
    7c50:	54ffdb60 	b.eq	77bc <fwp_write+0x69c>  // b.none
    7c54:	11000673 	add	w19, w19, #0x1
    7c58:	71002a7f 	cmp	w19, #0xa
    7c5c:	54fffea1 	b.ne	7c30 <fwp_write+0xb10>  // b.any
    7c60:	1e604120 	fmov	d0, d9
    7c64:	aa1503e0 	mov	x0, x21
    7c68:	52800121 	mov	w1, #0x9                   	// #9
    7c6c:	97ffefea 	bl	3c14 <fwp_format_g.constprop.0>
    7c70:	17fffed3 	b	77bc <fwp_write+0x69c>
    7c74:	d37ef6a1 	lsl	x1, x21, #2
    7c78:	b7f81563 	tbnz	x3, #63, 7f24 <fwp_write+0xe04>
    7c7c:	91002263 	add	x3, x19, #0x8
    7c80:	8b010061 	add	x1, x3, x1
    7c84:	b9400023 	ldr	w3, [x1]
    7c88:	7100081f 	cmp	w0, #0x2
    7c8c:	2a0303e1 	mov	w1, w3
    7c90:	93407c63 	sxtw	x3, w3
    7c94:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7c98:	17fffe5a 	b	7600 <fwp_write+0x4e0>
    7c9c:	d37ffaa1 	lsl	x1, x21, #1
    7ca0:	b7f81363 	tbnz	x3, #63, 7f0c <fwp_write+0xdec>
    7ca4:	91002263 	add	x3, x19, #0x8
    7ca8:	8b010061 	add	x1, x3, x1
    7cac:	79400021 	ldrh	w1, [x1]
    7cb0:	7100041f 	cmp	w0, #0x1
    7cb4:	93403c23 	sxth	x3, w1
    7cb8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7cbc:	17fffe51 	b	7600 <fwp_write+0x4e0>
    7cc0:	52800443 	mov	w3, #0x22                  	// #34
    7cc4:	91001ff5 	add	x21, sp, #0x7
    7cc8:	91002273 	add	x19, x19, #0x8
    7ccc:	aa1503e1 	mov	x1, x21
    7cd0:	aa1403e0 	mov	x0, x20
    7cd4:	d2800022 	mov	x2, #0x1                   	// #1
    7cd8:	39001fe3 	strb	w3, [sp, #7]
    7cdc:	f90143f7 	str	x23, [sp, #640]
    7ce0:	8b160277 	add	x23, x19, x22
    7ce4:	f90147f8 	str	x24, [sp, #648]
    7ce8:	97ffee4a 	bl	3610 <buf_put>
    7cec:	b4000696 	cbz	x22, 7dbc <fwp_write+0xc9c>
    7cf0:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0xc0>
    7cf4:	91116318 	add	x24, x24, #0x458
    7cf8:	f9014bf9 	str	x25, [sp, #656]
    7cfc:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0xc0>
    7d00:	9111e339 	add	x25, x25, #0x478
    7d04:	f9014ffa 	str	x26, [sp, #664]
    7d08:	1400000d 	b	7d3c <fwp_write+0xc1c>
    7d0c:	710024bf 	cmp	w5, #0x9
    7d10:	54000460 	b.eq	7d9c <fwp_write+0xc7c>  // b.none
    7d14:	710028bf 	cmp	w5, #0xa
    7d18:	54000a61 	b.ne	7e64 <fwp_write+0xd44>  // b.any
    7d1c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7d20:	aa1403e0 	mov	x0, x20
    7d24:	9111a021 	add	x1, x1, #0x468
    7d28:	d2800042 	mov	x2, #0x2                   	// #2
    7d2c:	97ffee39 	bl	3610 <buf_put>
    7d30:	91000673 	add	x19, x19, #0x1
    7d34:	eb17027f 	cmp	x19, x23
    7d38:	540003e0 	b.eq	7db4 <fwp_write+0xc94>  // b.none
    7d3c:	39400265 	ldrb	w5, [x19]
    7d40:	710034bf 	cmp	w5, #0xd
    7d44:	54000180 	b.eq	7d74 <fwp_write+0xc54>  // b.none
    7d48:	54fffe29 	b.ls	7d0c <fwp_write+0xbec>  // b.plast
    7d4c:	710088bf 	cmp	w5, #0x22
    7d50:	540001c0 	b.eq	7d88 <fwp_write+0xc68>  // b.none
    7d54:	710170bf 	cmp	w5, #0x5c
    7d58:	54000741 	b.ne	7e40 <fwp_write+0xd20>  // b.any
    7d5c:	aa1403e0 	mov	x0, x20
    7d60:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7d64:	d2800042 	mov	x2, #0x2                   	// #2
    7d68:	91118021 	add	x1, x1, #0x460
    7d6c:	97ffee29 	bl	3610 <buf_put>
    7d70:	17fffff0 	b	7d30 <fwp_write+0xc10>
    7d74:	aa1903e1 	mov	x1, x25
    7d78:	aa1403e0 	mov	x0, x20
    7d7c:	d2800042 	mov	x2, #0x2                   	// #2
    7d80:	97ffee24 	bl	3610 <buf_put>
    7d84:	17ffffeb 	b	7d30 <fwp_write+0xc10>
    7d88:	aa1803e1 	mov	x1, x24
    7d8c:	aa1403e0 	mov	x0, x20
    7d90:	d2800042 	mov	x2, #0x2                   	// #2
    7d94:	97ffee1f 	bl	3610 <buf_put>
    7d98:	17ffffe6 	b	7d30 <fwp_write+0xc10>
    7d9c:	aa1403e0 	mov	x0, x20
    7da0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7da4:	d2800042 	mov	x2, #0x2                   	// #2
    7da8:	9111c021 	add	x1, x1, #0x470
    7dac:	97ffee19 	bl	3610 <buf_put>
    7db0:	17ffffe0 	b	7d30 <fwp_write+0xc10>
    7db4:	f9414bf9 	ldr	x25, [sp, #656]
    7db8:	f9414ffa 	ldr	x26, [sp, #664]
    7dbc:	aa1503e1 	mov	x1, x21
    7dc0:	aa1403e0 	mov	x0, x20
    7dc4:	52800443 	mov	w3, #0x22                  	// #34
    7dc8:	17fffd9c 	b	7438 <fwp_write+0x318>
    7dcc:	7100103f 	cmp	w1, #0x4
    7dd0:	54ffeb21 	b.ne	7b34 <fwp_write+0xa14>  // b.any
    7dd4:	f94006e0 	ldr	x0, [x23, #8]
    7dd8:	d37ffc00 	lsr	x0, x0, #63
    7ddc:	17fffeb3 	b	78a8 <fwp_write+0x788>
    7de0:	710002ff 	cmp	w23, #0x0
    7de4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7de8:	17fffeb0 	b	78a8 <fwp_write+0x788>
    7dec:	528005a1 	mov	w1, #0x2d                  	// #45
    7df0:	eb0203e2 	negs	x2, x2
    7df4:	da0303e3 	ngc	x3, x3
    7df8:	910127e0 	add	x0, sp, #0x49
    7dfc:	910123f5 	add	x21, sp, #0x48
    7e00:	390123e1 	strb	w1, [sp, #72]
    7e04:	97ffec27 	bl	2ea0 <fwp_fmt_u128>
    7e08:	17fffe18 	b	7668 <fwp_write+0x548>
    7e0c:	d37ceea1 	lsl	x1, x21, #4
    7e10:	b7f810a3 	tbnz	x3, #63, 8024 <fwp_write+0xf04>
    7e14:	91002260 	add	x0, x19, #0x8
    7e18:	8b010001 	add	x1, x0, x1
    7e1c:	17fffdf9 	b	7600 <fwp_write+0x4e0>
    7e20:	f9400a61 	ldr	x1, [x19, #16]
    7e24:	8b010000 	add	x0, x0, x1
    7e28:	f9400001 	ldr	x1, [x0]
    7e2c:	17fffdf5 	b	7600 <fwp_write+0x4e0>
    7e30:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7e34:	d2800042 	mov	x2, #0x2                   	// #2
    7e38:	91100021 	add	x1, x1, #0x400
    7e3c:	17fffed6 	b	7994 <fwp_write+0x874>
    7e40:	7101fcbf 	cmp	w5, #0x7f
    7e44:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7e48:	540000e9 	b.ls	7e64 <fwp_write+0xd44>  // b.plast
    7e4c:	aa1503e1 	mov	x1, x21
    7e50:	aa1403e0 	mov	x0, x20
    7e54:	d2800022 	mov	x2, #0x1                   	// #1
    7e58:	39001fe5 	strb	w5, [sp, #7]
    7e5c:	97ffeded 	bl	3610 <buf_put>
    7e60:	17ffffb4 	b	7d30 <fwp_write+0xc10>
    7e64:	d2800203 	mov	x3, #0x10                  	// #16
    7e68:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0xc0>
    7e6c:	aa0303e1 	mov	x1, x3
    7e70:	91120084 	add	x4, x4, #0x480
    7e74:	910123f6 	add	x22, sp, #0x48
    7e78:	52800042 	mov	w2, #0x2                   	// #2
    7e7c:	aa1603e0 	mov	x0, x22
    7e80:	97ffea80 	bl	2880 <__snprintf_chk@plt>
    7e84:	aa1603e0 	mov	x0, x22
    7e88:	97ffea46 	bl	27a0 <strlen@plt>
    7e8c:	aa1603e1 	mov	x1, x22
    7e90:	aa0003e2 	mov	x2, x0
    7e94:	aa1403e0 	mov	x0, x20
    7e98:	97ffedde 	bl	3610 <buf_put>
    7e9c:	17ffffa5 	b	7d30 <fwp_write+0xc10>
    7ea0:	1e604100 	fmov	d0, d8
    7ea4:	aa1503e0 	mov	x0, x21
    7ea8:	52800221 	mov	w1, #0x11                  	// #17
    7eac:	97ffef5a 	bl	3c14 <fwp_format_g.constprop.0>
    7eb0:	17fffe43 	b	77bc <fwp_write+0x69c>
    7eb4:	b9401040 	ldr	w0, [x2, #16]
    7eb8:	350003c0 	cbnz	w0, 7f30 <fwp_write+0xe10>
    7ebc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ec0:	f947f400 	ldr	x0, [x0, #4072]
    7ec4:	f94127e2 	ldr	x2, [sp, #584]
    7ec8:	f9400001 	ldr	x1, [x0]
    7ecc:	eb010042 	subs	x2, x2, x1
    7ed0:	d2800001 	mov	x1, #0x0                   	// #0
    7ed4:	54ffd721 	b.ne	79b8 <fwp_write+0x898>  // b.any
    7ed8:	f9413bf5 	ldr	x21, [sp, #624]
    7edc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7ee0:	f9413ff6 	ldr	x22, [sp, #632]
    7ee4:	aa1403e0 	mov	x0, x20
    7ee8:	f94143f7 	ldr	x23, [sp, #640]
    7eec:	91134021 	add	x1, x1, #0x4d0
    7ef0:	f94147f8 	ldr	x24, [sp, #648]
    7ef4:	d2800042 	mov	x2, #0x2                   	// #2
    7ef8:	17fffd0e 	b	7330 <fwp_write+0x210>
    7efc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0xc0>
    7f00:	d2800042 	mov	x2, #0x2                   	// #2
    7f04:	91102021 	add	x1, x1, #0x408
    7f08:	17fffea3 	b	7994 <fwp_write+0x874>
    7f0c:	f9400a63 	ldr	x3, [x19, #16]
    7f10:	8b030021 	add	x1, x1, x3
    7f14:	17ffff66 	b	7cac <fwp_write+0xb8c>
    7f18:	f9400a61 	ldr	x1, [x19, #16]
    7f1c:	8b0102a1 	add	x1, x21, x1
    7f20:	17fffdb3 	b	75ec <fwp_write+0x4cc>
    7f24:	f9400a63 	ldr	x3, [x19, #16]
    7f28:	8b030021 	add	x1, x1, x3
    7f2c:	17ffff56 	b	7c84 <fwp_write+0xb64>
    7f30:	b9404840 	ldr	w0, [x2, #72]
    7f34:	91001ff5 	add	x21, sp, #0x7
    7f38:	34ffa360 	cbz	w0, 73a4 <fwp_write+0x284>
    7f3c:	52800503 	mov	w3, #0x28                  	// #40
    7f40:	aa1403e0 	mov	x0, x20
    7f44:	aa1503e1 	mov	x1, x21
    7f48:	d2800022 	mov	x2, #0x1                   	// #1
    7f4c:	39001fe3 	strb	w3, [sp, #7]
    7f50:	97ffedb0 	bl	3610 <buf_put>
    7f54:	b9401380 	ldr	w0, [x28, #16]
    7f58:	52800038 	mov	w24, #0x1                   	// #1
    7f5c:	7100001f 	cmp	w0, #0x0
    7f60:	54ffa36c 	b.gt	73cc <fwp_write+0x2ac>
    7f64:	17fffd32 	b	742c <fwp_write+0x30c>
    7f68:	f9014bf9 	str	x25, [sp, #656]
    7f6c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xeec0>
    7f70:	f9014ffa 	str	x26, [sp, #664]
    7f74:	f9400676 	ldr	x22, [x19, #8]
    7f78:	910aa333 	add	x19, x25, #0x2a8
    7f7c:	91002273 	add	x19, x19, #0x8
    7f80:	937ffed8 	asr	x24, x22, #63
    7f84:	aa1802c0 	orr	x0, x22, x24
    7f88:	b5000320 	cbnz	x0, 7fec <fwp_write+0xecc>
    7f8c:	110006b5 	add	w21, w21, #0x1
    7f90:	710016bf 	cmp	w21, #0x5
    7f94:	54ffffc1 	b.ne	7f8c <fwp_write+0xe6c>  // b.any
    7f98:	b7f80578 	tbnz	x24, #63, 8044 <fwp_write+0xf24>
    7f9c:	910023f3 	add	x19, sp, #0x8
    7fa0:	aa1603e2 	mov	x2, x22
    7fa4:	aa1303e0 	mov	x0, x19
    7fa8:	d2800003 	mov	x3, #0x0                   	// #0
    7fac:	97ffebbd 	bl	2ea0 <fwp_fmt_u128>
    7fb0:	910123f5 	add	x21, sp, #0x48
    7fb4:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0xc0>
    7fb8:	aa1303e4 	mov	x4, x19
    7fbc:	aa1503e0 	mov	x0, x21
    7fc0:	91132063 	add	x3, x3, #0x4c8
    7fc4:	d2804002 	mov	x2, #0x200                 	// #512
    7fc8:	52800041 	mov	w1, #0x2                   	// #2
    7fcc:	97ffe9f9 	bl	27b0 <__sprintf_chk@plt>
    7fd0:	aa1503e0 	mov	x0, x21
    7fd4:	97ffe9f3 	bl	27a0 <strlen@plt>
    7fd8:	aa1503e1 	mov	x1, x21
    7fdc:	aa0003e2 	mov	x2, x0
    7fe0:	aa1403e0 	mov	x0, x20
    7fe4:	97ffed8b 	bl	3610 <buf_put>
    7fe8:	17fffe47 	b	7904 <fwp_write+0x7e4>
    7fec:	f9400277 	ldr	x23, [x19]
    7ff0:	aa1603e0 	mov	x0, x22
    7ff4:	aa1803e1 	mov	x1, x24
    7ff8:	aa1703e2 	mov	x2, x23
    7ffc:	937ffefa 	asr	x26, x23, #63
    8000:	aa1a03e3 	mov	x3, x26
    8004:	940012e7 	bl	cba0 <__modti3>
    8008:	aa010000 	orr	x0, x0, x1
    800c:	b40002c0 	cbz	x0, 8064 <fwp_write+0xf44>
    8010:	110006b5 	add	w21, w21, #0x1
    8014:	91004273 	add	x19, x19, #0x10
    8018:	710016bf 	cmp	w21, #0x5
    801c:	54fffe81 	b.ne	7fec <fwp_write+0xecc>  // b.any
    8020:	17ffffde 	b	7f98 <fwp_write+0xe78>
    8024:	f9400a60 	ldr	x0, [x19, #16]
    8028:	8b000021 	add	x1, x1, x0
    802c:	17fffd75 	b	7600 <fwp_write+0x4e0>
    8030:	528c29c0 	mov	w0, #0x614e                	// #24910
    8034:	910123f5 	add	x21, sp, #0x48
    8038:	72a009c0 	movk	w0, #0x4e, lsl #16
    803c:	b9004be0 	str	w0, [sp, #72]
    8040:	17fffda2 	b	76c8 <fwp_write+0x5a8>
    8044:	528005a1 	mov	w1, #0x2d                  	// #45
    8048:	eb1603e2 	negs	x2, x22
    804c:	da1803e3 	ngc	x3, x24
    8050:	910027e0 	add	x0, sp, #0x9
    8054:	910023f3 	add	x19, sp, #0x8
    8058:	390023e1 	strb	w1, [sp, #8]
    805c:	97ffeb91 	bl	2ea0 <fwp_fmt_u128>
    8060:	17ffffd4 	b	7fb0 <fwp_write+0xe90>
    8064:	aa1703e2 	mov	x2, x23
    8068:	aa1a03e3 	mov	x3, x26
    806c:	aa1603e0 	mov	x0, x22
    8070:	aa1803e1 	mov	x1, x24
    8074:	940011eb 	bl	c820 <__divti3>
    8078:	aa0003e2 	mov	x2, x0
    807c:	aa0103e3 	mov	x3, x1
    8080:	b7f80201 	tbnz	x1, #63, 80c0 <fwp_write+0xfa0>
    8084:	910023f3 	add	x19, sp, #0x8
    8088:	aa1303e0 	mov	x0, x19
    808c:	97ffeb85 	bl	2ea0 <fwp_fmt_u128>
    8090:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8094:	910aa339 	add	x25, x25, #0x2a8
    8098:	910123f5 	add	x21, sp, #0x48
    809c:	aa1303e4 	mov	x4, x19
    80a0:	aa1503e0 	mov	x0, x21
    80a4:	b0000023 	adrp	x3, d000 <_IO_stdin_used+0xc0>
    80a8:	f8616b25 	ldr	x5, [x25, x1]
    80ac:	91130063 	add	x3, x3, #0x4c0
    80b0:	d2804002 	mov	x2, #0x200                 	// #512
    80b4:	52800041 	mov	w1, #0x2                   	// #2
    80b8:	97ffe9be 	bl	27b0 <__sprintf_chk@plt>
    80bc:	17ffffc5 	b	7fd0 <fwp_write+0xeb0>
    80c0:	528005a4 	mov	w4, #0x2d                  	// #45
    80c4:	eb0003e2 	negs	x2, x0
    80c8:	da0103e3 	ngc	x3, x1
    80cc:	910027e0 	add	x0, sp, #0x9
    80d0:	910023f3 	add	x19, sp, #0x8
    80d4:	390023e4 	strb	w4, [sp, #8]
    80d8:	97ffeb72 	bl	2ea0 <fwp_fmt_u128>
    80dc:	17ffffed 	b	8090 <fwp_write+0xf70>
    80e0:	f9013bf5 	str	x21, [sp, #624]
    80e4:	f9013ff6 	str	x22, [sp, #632]
    80e8:	f90143f7 	str	x23, [sp, #640]
    80ec:	f90147f8 	str	x24, [sp, #648]
    80f0:	f9014bf9 	str	x25, [sp, #656]
    80f4:	f9014ffa 	str	x26, [sp, #664]
    80f8:	f90153fb 	str	x27, [sp, #672]
    80fc:	f90157fc 	str	x28, [sp, #680]
    8100:	fd015be8 	str	d8, [sp, #688]
    8104:	fd015fe9 	str	d9, [sp, #696]
    8108:	97ffea02 	bl	2910 <__stack_chk_fail@plt>
    810c:	d503201f 	nop

0000000000008110 <fwp_hof0.constprop.0>:
    8110:	d10543ff 	sub	sp, sp, #0x150
    8114:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    8118:	f947f442 	ldr	x2, [x2, #4072]
    811c:	a90e7bfd 	stp	x29, x30, [sp, #224]
    8120:	910383fd 	add	x29, sp, #0xe0
    8124:	f90023e0 	str	x0, [sp, #64]
    8128:	f9400040 	ldr	x0, [x2]
    812c:	f9006fe0 	str	x0, [sp, #216]
    8130:	d2800000 	mov	x0, #0x0                   	// #0
    8134:	f90027e1 	str	x1, [sp, #72]
    8138:	b400a641 	cbz	x1, 9600 <fwp_hof0.constprop.0+0x14f0>
    813c:	900000c0 	adrp	x0, 20000 <__data_start>
    8140:	91004000 	add	x0, x0, #0x10
    8144:	9100e000 	add	x0, x0, #0x38
    8148:	f90017e0 	str	x0, [sp, #40]
    814c:	910163e0 	add	x0, sp, #0x58
    8150:	f9000fe0 	str	x0, [sp, #24]
    8154:	910183e0 	add	x0, sp, #0x60
    8158:	f90013e0 	str	x0, [sp, #32]
    815c:	b0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    8160:	fd00a3e8 	str	d8, [sp, #320]
    8164:	a90f53f3 	stp	x19, x20, [sp, #240]
    8168:	b0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    816c:	fd46a808 	ldr	d8, [x0, #3408]
    8170:	a9105bf5 	stp	x21, x22, [sp, #256]
    8174:	900000d5 	adrp	x21, 20000 <__data_start>
    8178:	a91163f7 	stp	x23, x24, [sp, #272]
    817c:	a9126bf9 	stp	x25, x26, [sp, #288]
    8180:	a91373fb 	stp	x27, x28, [sp, #304]
    8184:	91174282 	add	x2, x20, #0x5d0
    8188:	f94023e0 	ldr	x0, [sp, #64]
    818c:	f949ec43 	ldr	x3, [x2, #5080]
    8190:	f949d841 	ldr	x1, [x2, #5040]
    8194:	d370bc63 	lsl	x3, x3, #16
    8198:	cb010004 	sub	x4, x0, x1
    819c:	eb03009f 	cmp	x4, x3
    81a0:	540003e2 	b.cs	821c <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    81a4:	d350fc80 	lsr	x0, x4, #16
    81a8:	f949fc46 	ldr	x6, [x2, #5112]
    81ac:	8b000800 	add	x0, x0, x0, lsl #2
    81b0:	d37df002 	lsl	x2, x0, #3
    81b4:	8b0200c5 	add	x5, x6, x2
    81b8:	f94010a0 	ldr	x0, [x5, #32]
    81bc:	b4000300 	cbz	x0, 821c <fwp_hof0.constprop.0+0x10c>
    81c0:	386268c2 	ldrb	w2, [x6, x2]
    81c4:	7100085f 	cmp	w2, #0x2
    81c8:	5400bbc0 	b.eq	9940 <fwp_hof0.constprop.0+0x1830>  // b.none
    81cc:	7100045f 	cmp	w2, #0x1
    81d0:	54000261 	b.ne	821c <fwp_hof0.constprop.0+0x10c>  // b.any
    81d4:	92403c82 	and	x2, x4, #0xffff
    81d8:	294310a6 	ldp	w6, w4, [x5, #24]
    81dc:	9b067c42 	mul	x2, x2, x6
    81e0:	d360fc42 	lsr	x2, x2, #32
    81e4:	eb04005f 	cmp	x2, x4
    81e8:	540001a2 	b.cs	821c <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    81ec:	8b020000 	add	x0, x0, x2
    81f0:	39400002 	ldrb	w2, [x0]
    81f4:	34000142 	cbz	w2, 821c <fwp_hof0.constprop.0+0x10c>
    81f8:	7103f45f 	cmp	w2, #0xfd
    81fc:	5400cc68 	b.hi	9b88 <fwp_hof0.constprop.0+0x1a78>  // b.pmore
    8200:	91174281 	add	x1, x20, #0x5d0
    8204:	11000442 	add	w2, w2, #0x1
    8208:	39000002 	strb	w2, [x0]
    820c:	aa0103e0 	mov	x0, x1
    8210:	f949d821 	ldr	x1, [x1, #5040]
    8214:	f949ec03 	ldr	x3, [x0, #5080]
    8218:	d370bc63 	lsl	x3, x3, #16
    821c:	f94023f6 	ldr	x22, [sp, #64]
    8220:	d28018c0 	mov	x0, #0xc6                  	// #198
    8224:	f90007e0 	str	x0, [sp, #8]
    8228:	f94017e0 	ldr	x0, [sp, #40]
    822c:	9101c2a2 	add	x2, x21, #0x70
    8230:	12800004 	mov	w4, #0xffffffff            	// #-1
    8234:	b9005be4 	str	w4, [sp, #88]
    8238:	cb010001 	sub	x1, x0, x1
    823c:	d0ffffe0 	adrp	x0, 6000 <fwp_tape_finish+0x10>
    8240:	9103c000 	add	x0, x0, #0xf0
    8244:	f90037e0 	str	x0, [sp, #104]
    8248:	f9418840 	ldr	x0, [x2, #784]
    824c:	f90033e0 	str	x0, [sp, #96]
    8250:	f9400fe0 	ldr	x0, [sp, #24]
    8254:	f9003be0 	str	x0, [sp, #112]
    8258:	f94013e0 	ldr	x0, [sp, #32]
    825c:	f9018840 	str	x0, [x2, #784]
    8260:	eb03003f 	cmp	x1, x3
    8264:	540007a2 	b.cs	8358 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8268:	91174282 	add	x2, x20, #0x5d0
    826c:	d350fc20 	lsr	x0, x1, #16
    8270:	8b000800 	add	x0, x0, x0, lsl #2
    8274:	f949fc44 	ldr	x4, [x2, #5112]
    8278:	d37df003 	lsl	x3, x0, #3
    827c:	8b030082 	add	x2, x4, x3
    8280:	f9401053 	ldr	x19, [x2, #32]
    8284:	b40006b3 	cbz	x19, 8358 <fwp_hof0.constprop.0+0x248>
    8288:	38636880 	ldrb	w0, [x4, x3]
    828c:	7100081f 	cmp	w0, #0x2
    8290:	5400a880 	b.eq	97a0 <fwp_hof0.constprop.0+0x1690>  // b.none
    8294:	7100041f 	cmp	w0, #0x1
    8298:	54000601 	b.ne	8358 <fwp_hof0.constprop.0+0x248>  // b.any
    829c:	29430c44 	ldp	w4, w3, [x2, #24]
    82a0:	92403c20 	and	x0, x1, #0xffff
    82a4:	9b047c00 	mul	x0, x0, x4
    82a8:	d360fc00 	lsr	x0, x0, #32
    82ac:	eb03001f 	cmp	x0, x3
    82b0:	540002a2 	b.cs	8304 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    82b4:	8b000260 	add	x0, x19, x0
    82b8:	39400003 	ldrb	w3, [x0]
    82bc:	34000243 	cbz	w3, 8304 <fwp_hof0.constprop.0+0x1f4>
    82c0:	7103f47f 	cmp	w3, #0xfd
    82c4:	5400c228 	b.hi	9b08 <fwp_hof0.constprop.0+0x19f8>  // b.pmore
    82c8:	11000463 	add	w3, w3, #0x1
    82cc:	39000003 	strb	w3, [x0]
    82d0:	91174280 	add	x0, x20, #0x5d0
    82d4:	f94017e3 	ldr	x3, [sp, #40]
    82d8:	f949d801 	ldr	x1, [x0, #5040]
    82dc:	f949ec02 	ldr	x2, [x0, #5080]
    82e0:	cb010061 	sub	x1, x3, x1
    82e4:	eb02403f 	cmp	x1, x2, lsl #16
    82e8:	54000382 	b.cs	8358 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    82ec:	f949fc00 	ldr	x0, [x0, #5112]
    82f0:	d350fc22 	lsr	x2, x1, #16
    82f4:	8b020842 	add	x2, x2, x2, lsl #2
    82f8:	8b020c02 	add	x2, x0, x2, lsl #3
    82fc:	f9401053 	ldr	x19, [x2, #32]
    8300:	b40002d3 	cbz	x19, 8358 <fwp_hof0.constprop.0+0x248>
    8304:	39400040 	ldrb	w0, [x2]
    8308:	7100081f 	cmp	w0, #0x2
    830c:	5400a520 	b.eq	97b0 <fwp_hof0.constprop.0+0x16a0>  // b.none
    8310:	7100041f 	cmp	w0, #0x1
    8314:	54000221 	b.ne	8358 <fwp_hof0.constprop.0+0x248>  // b.any
    8318:	29430043 	ldp	w3, w0, [x2, #24]
    831c:	92403c21 	and	x1, x1, #0xffff
    8320:	9b037c21 	mul	x1, x1, x3
    8324:	d360fc21 	lsr	x1, x1, #32
    8328:	eb00003f 	cmp	x1, x0
    832c:	54000162 	b.cs	8358 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8330:	8b010273 	add	x19, x19, x1
    8334:	39400261 	ldrb	w1, [x19]
    8338:	34000101 	cbz	w1, 8358 <fwp_hof0.constprop.0+0x248>
    833c:	7100043f 	cmp	w1, #0x1
    8340:	54007820 	b.eq	9244 <fwp_hof0.constprop.0+0x1134>  // b.none
    8344:	7103fc3f 	cmp	w1, #0xff
    8348:	5400bb40 	b.eq	9ab0 <fwp_hof0.constprop.0+0x19a0>  // b.none
    834c:	51000421 	sub	w1, w1, #0x1
    8350:	39000261 	strb	w1, [x19]
    8354:	d503201f 	nop
    8358:	b4007876 	cbz	x22, 9264 <fwp_hof0.constprop.0+0x1154>
    835c:	aa1603e0 	mov	x0, x22
    8360:	d2800013 	mov	x19, #0x0                   	// #0
    8364:	d503201f 	nop
    8368:	f9400800 	ldr	x0, [x0, #16]
    836c:	91000673 	add	x19, x19, #0x1
    8370:	b5ffffc0 	cbnz	x0, 8368 <fwp_hof0.constprop.0+0x258>
    8374:	52800000 	mov	w0, #0x0                   	// #0
    8378:	97ffecbe 	bl	3670 <descent_phase_step>
    837c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8380:	eb00027f 	cmp	x19, x0
    8384:	5400c368 	b.hi	9bf0 <fwp_hof0.constprop.0+0x1ae0>  // b.pmore
    8388:	9101c2b7 	add	x23, x21, #0x70
    838c:	b94346e0 	ldr	w0, [x23, #836]
    8390:	34007780 	cbz	w0, 9280 <fwp_hof0.constprop.0+0x1170>
    8394:	9101c2a0 	add	x0, x21, #0x70
    8398:	f9404817 	ldr	x23, [x0, #144]
    839c:	f9407418 	ldr	x24, [x0, #232]
    83a0:	eb17031f 	cmp	x24, x23
    83a4:	5400786a 	b.ge	92b0 <fwp_hof0.constprop.0+0x11a0>  // b.tcont
    83a8:	f9403aa1 	ldr	x1, [x21, #112]
    83ac:	8b180700 	add	x0, x24, x24, lsl #1
    83b0:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    83b4:	8b000b00 	add	x0, x24, x0, lsl #2
    83b8:	8b000c20 	add	x0, x1, x0, lsl #3
    83bc:	d503201f 	nop
    83c0:	b9400401 	ldr	w1, [x0, #4]
    83c4:	35000081 	cbnz	w1, 83d4 <fwp_hof0.constprop.0+0x2c4>
    83c8:	b9400001 	ldr	w1, [x0]
    83cc:	6b02003f 	cmp	w1, w2
    83d0:	54007709 	b.ls	92b0 <fwp_hof0.constprop.0+0x11a0>  // b.plast
    83d4:	91000718 	add	x24, x24, #0x1
    83d8:	9101a000 	add	x0, x0, #0x68
    83dc:	eb17031f 	cmp	x24, x23
    83e0:	54ffff01 	b.ne	83c0 <fwp_hof0.constprop.0+0x2b0>  // b.any
    83e4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    83e8:	eb0002ff 	cmp	x23, x0
    83ec:	5400bfcc 	b.gt	9be4 <fwp_hof0.constprop.0+0x1ad4>
    83f0:	9101c2a0 	add	x0, x21, #0x70
    83f4:	f9403abb 	ldr	x27, [x21, #112]
    83f8:	f9407000 	ldr	x0, [x0, #224]
    83fc:	eb17001f 	cmp	x0, x23
    8400:	54000201 	b.ne	8440 <fwp_hof0.constprop.0+0x330>  // b.any
    8404:	b400a6b7 	cbz	x23, 98d8 <fwp_hof0.constprop.0+0x17c8>
    8408:	d37ffafc 	lsl	x28, x23, #1
    840c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8410:	eb00039f 	cmp	x28, x0
    8414:	9a80d39c 	csel	x28, x28, x0, le
    8418:	8b1c0781 	add	x1, x28, x28, lsl #1
    841c:	8b010b81 	add	x1, x28, x1, lsl #2
    8420:	d37df021 	lsl	x1, x1, #3
    8424:	aa1b03e0 	mov	x0, x27
    8428:	97ffe936 	bl	2900 <realloc@plt>
    842c:	aa0003fb 	mov	x27, x0
    8430:	b4003980 	cbz	x0, 8b60 <fwp_hof0.constprop.0+0xa50>
    8434:	9101c2a0 	add	x0, x21, #0x70
    8438:	f9003abb 	str	x27, [x21, #112]
    843c:	f900701c 	str	x28, [x0, #224]
    8440:	8b1706e1 	add	x1, x23, x23, lsl #1
    8444:	910006e2 	add	x2, x23, #0x1
    8448:	4f000400 	movi	v0.4s, #0x0
    844c:	9101c2a0 	add	x0, x21, #0x70
    8450:	8b010ae1 	add	x1, x23, x1, lsl #2
    8454:	8b180717 	add	x23, x24, x24, lsl #1
    8458:	8b170b17 	add	x23, x24, x23, lsl #2
    845c:	8b010f61 	add	x1, x27, x1, lsl #3
    8460:	f9004802 	str	x2, [x0, #144]
    8464:	b0000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    8468:	8b170f77 	add	x23, x27, x23, lsl #3
    846c:	9108c000 	add	x0, x0, #0x230
    8470:	ad000020 	stp	q0, q0, [x1]
    8474:	ad010020 	stp	q0, q0, [x1, #32]
    8478:	ad020020 	stp	q0, q0, [x1, #64]
    847c:	f900303f 	str	xzr, [x1, #96]
    8480:	f90032ff 	str	xzr, [x23, #96]
    8484:	97ffe987 	bl	2aa0 <getenv@plt>
    8488:	b40072a0 	cbz	x0, 92dc <fwp_hof0.constprop.0+0x11cc>
    848c:	39400001 	ldrb	w1, [x0]
    8490:	7100c03f 	cmp	w1, #0x30
    8494:	54007241 	b.ne	92dc <fwp_hof0.constprop.0+0x11cc>  // b.any
    8498:	39400400 	ldrb	w0, [x0, #1]
    849c:	35007200 	cbnz	w0, 92dc <fwp_hof0.constprop.0+0x11cc>
    84a0:	9101c2a0 	add	x0, x21, #0x70
    84a4:	2f000400 	mvni	v0.2s, #0x0
    84a8:	b94002e4 	ldr	w4, [x23]
    84ac:	52800022 	mov	w2, #0x1                   	// #1
    84b0:	91000705 	add	x5, x24, #0x1
    84b4:	a900cef3 	stp	x19, x19, [x23, #8]
    84b8:	0b020084 	add	w4, w4, w2
    84bc:	f9418801 	ldr	x1, [x0, #784]
    84c0:	29000ae4 	stp	w4, w2, [x23]
    84c4:	f9002aff 	str	xzr, [x23, #80]
    84c8:	f9007405 	str	x5, [x0, #232]
    84cc:	fd002ee0 	str	d0, [x23, #88]
    84d0:	b400b961 	cbz	x1, 9bfc <fwp_hof0.constprop.0+0x1aec>
    84d4:	d0ffffe0 	adrp	x0, 6000 <fwp_tape_finish+0x10>
    84d8:	9103c003 	add	x3, x0, #0xf0
    84dc:	14000003 	b	84e8 <fwp_hof0.constprop.0+0x3d8>
    84e0:	f9400021 	ldr	x1, [x1]
    84e4:	b400b8c1 	cbz	x1, 9bfc <fwp_hof0.constprop.0+0x1aec>
    84e8:	f9400422 	ldr	x2, [x1, #8]
    84ec:	eb03005f 	cmp	x2, x3
    84f0:	54ffff81 	b.ne	84e0 <fwp_hof0.constprop.0+0x3d0>  // b.any
    84f4:	f9400820 	ldr	x0, [x1, #16]
    84f8:	2a1803e2 	mov	w2, w24
    84fc:	b9400001 	ldr	w1, [x0]
    8500:	f9002ae0 	str	x0, [x23, #80]
    8504:	b9005ee1 	str	w1, [x23, #92]
    8508:	37f80081 	tbnz	w1, #31, 8518 <fwp_hof0.constprop.0+0x408>
    850c:	52800d03 	mov	w3, #0x68                  	// #104
    8510:	9b236c21 	smaddl	x1, w1, w3, x27
    8514:	b9005838 	str	w24, [x1, #88]
    8518:	b9000002 	str	w2, [x0]
    851c:	d3707c93 	ubfiz	x19, x4, #16, #32
    8520:	52800020 	mov	w0, #0x1                   	// #1
    8524:	aa050273 	orr	x19, x19, x5
    8528:	97ffec52 	bl	3670 <descent_phase_step>
    852c:	aa1603e0 	mov	x0, x22
    8530:	d2800002 	mov	x2, #0x0                   	// #0
    8534:	b40075f6 	cbz	x22, 93f0 <fwp_hof0.constprop.0+0x12e0>
    8538:	f9400800 	ldr	x0, [x0, #16]
    853c:	91000442 	add	x2, x2, #0x1
    8540:	b5ffffc0 	cbnz	x0, 8538 <fwp_hof0.constprop.0+0x428>
    8544:	aa1603e1 	mov	x1, x22
    8548:	f9400821 	ldr	x1, [x1, #16]
    854c:	91000400 	add	x0, x0, #0x1
    8550:	b5ffffc1 	cbnz	x1, 8548 <fwp_hof0.constprop.0+0x438>
    8554:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8558:	eb01001f 	cmp	x0, x1
    855c:	5400b288 	b.hi	9bac <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    8560:	f100005f 	cmp	x2, #0x0
    8564:	5400746d 	b.le	93f0 <fwp_hof0.constprop.0+0x12e0>
    8568:	eb00005f 	cmp	x2, x0
    856c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8570:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8574:	eb0102ff 	cmp	x23, x1
    8578:	5400b1a8 	b.hi	9bac <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    857c:	d37ffafc 	lsl	x28, x23, #1
    8580:	52800041 	mov	w1, #0x2                   	// #2
    8584:	91000780 	add	x0, x28, #0x1
    8588:	d37df000 	lsl	x0, x0, #3
    858c:	97fff279 	bl	4f70 <fwp_heap_alloc>
    8590:	aa0003f8 	mov	x24, x0
    8594:	91174281 	add	x1, x20, #0x5d0
    8598:	aa0003fb 	mov	x27, x0
    859c:	aa0103e0 	mov	x0, x1
    85a0:	f900031c 	str	x28, [x24]
    85a4:	f949d821 	ldr	x1, [x1, #5040]
    85a8:	f949ec00 	ldr	x0, [x0, #5080]
    85ac:	cb010301 	sub	x1, x24, x1
    85b0:	eb00403f 	cmp	x1, x0, lsl #16
    85b4:	540083c2 	b.cs	962c <fwp_hof0.constprop.0+0x151c>  // b.hs, b.nlast
    85b8:	91174282 	add	x2, x20, #0x5d0
    85bc:	d350fc20 	lsr	x0, x1, #16
    85c0:	8b000800 	add	x0, x0, x0, lsl #2
    85c4:	f949fc43 	ldr	x3, [x2, #5112]
    85c8:	d37df002 	lsl	x2, x0, #3
    85cc:	8b020060 	add	x0, x3, x2
    85d0:	f940101c 	ldr	x28, [x0, #32]
    85d4:	b400025c 	cbz	x28, 861c <fwp_hof0.constprop.0+0x50c>
    85d8:	38626862 	ldrb	w2, [x3, x2]
    85dc:	7100085f 	cmp	w2, #0x2
    85e0:	54008d00 	b.eq	9780 <fwp_hof0.constprop.0+0x1670>  // b.none
    85e4:	7100045f 	cmp	w2, #0x1
    85e8:	540001a1 	b.ne	861c <fwp_hof0.constprop.0+0x50c>  // b.any
    85ec:	29430002 	ldp	w2, w0, [x0, #24]
    85f0:	92403c21 	and	x1, x1, #0xffff
    85f4:	9b027c21 	mul	x1, x1, x2
    85f8:	d360fc21 	lsr	x1, x1, #32
    85fc:	eb00003f 	cmp	x1, x0
    8600:	540000e2 	b.cs	861c <fwp_hof0.constprop.0+0x50c>  // b.hs, b.nlast
    8604:	8b01039c 	add	x28, x28, x1
    8608:	39400380 	ldrb	w0, [x28]
    860c:	7103fc1f 	cmp	w0, #0xff
    8610:	54008c20 	b.eq	9794 <fwp_hof0.constprop.0+0x1684>  // b.none
    8614:	52800020 	mov	w0, #0x1                   	// #1
    8618:	39000380 	strb	w0, [x28]
    861c:	b4000237 	cbz	x23, 8660 <fwp_hof0.constprop.0+0x550>
    8620:	d3607e64 	lsl	x4, x19, #32
    8624:	aa1603e1 	mov	x1, x22
    8628:	f94006c5 	ldr	x5, [x22, #8]
    862c:	aa0403e3 	mov	x3, x4
    8630:	91002302 	add	x2, x24, #0x8
    8634:	d2800000 	mov	x0, #0x0                   	// #0
    8638:	14000005 	b	864c <fwp_hof0.constprop.0+0x53c>
    863c:	f9400425 	ldr	x5, [x1, #8]
    8640:	ab000083 	adds	x3, x4, x0
    8644:	91004042 	add	x2, x2, #0x10
    8648:	5400aee6 	b.vs	9c24 <fwp_hof0.constprop.0+0x1b14>
    864c:	a9000c45 	stp	x5, x3, [x2]
    8650:	91000400 	add	x0, x0, #0x1
    8654:	f9400821 	ldr	x1, [x1, #16]
    8658:	eb17001f 	cmp	x0, x23
    865c:	54ffff03 	b.cc	863c <fwp_hof0.constprop.0+0x52c>  // b.lo, b.ul, b.last
    8660:	f9400300 	ldr	x0, [x24]
    8664:	f100041f 	cmp	x0, #0x1
    8668:	54007e49 	b.ls	9630 <fwp_hof0.constprop.0+0x1520>  // b.plast
    866c:	d341fc00 	lsr	x0, x0, #1
    8670:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8674:	d1000401 	sub	x1, x0, #0x1
    8678:	eb02003f 	cmp	x1, x2
    867c:	5400a988 	b.hi	9bac <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    8680:	d37ff83c 	lsl	x28, x1, #1
    8684:	b4007d61 	cbz	x1, 9630 <fwp_hof0.constprop.0+0x1520>
    8688:	d1002301 	sub	x1, x24, #0x8
    868c:	91002319 	add	x25, x24, #0x8
    8690:	8b001037 	add	x23, x1, x0, lsl #4
    8694:	d503201f 	nop
    8698:	f9400720 	ldr	x0, [x25, #8]
    869c:	f9400f21 	ldr	x1, [x25, #24]
    86a0:	fd400320 	ldr	d0, [x25]
    86a4:	fd400b21 	ldr	d1, [x25, #16]
    86a8:	97fff372 	bl	5470 <w120>
    86ac:	a9000720 	stp	x0, x1, [x25]
    86b0:	91004339 	add	x25, x25, #0x10
    86b4:	eb17033f 	cmp	x25, x23
    86b8:	54ffff01 	b.ne	8698 <fwp_hof0.constprop.0+0x588>  // b.any
    86bc:	91174297 	add	x23, x20, #0x5d0
    86c0:	f900031c 	str	x28, [x24]
    86c4:	aa1803e0 	mov	x0, x24
    86c8:	97fff3ae 	bl	5580 <w176.constprop.0>
    86cc:	aa0103e5 	mov	x5, x1
    86d0:	f949dae1 	ldr	x1, [x23, #5040]
    86d4:	f949eee0 	ldr	x0, [x23, #5080]
    86d8:	cb010301 	sub	x1, x24, x1
    86dc:	eb00403f 	cmp	x1, x0, lsl #16
    86e0:	54000382 	b.cs	8750 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    86e4:	d350fc20 	lsr	x0, x1, #16
    86e8:	f949fee4 	ldr	x4, [x23, #5112]
    86ec:	8b000800 	add	x0, x0, x0, lsl #2
    86f0:	d37df000 	lsl	x0, x0, #3
    86f4:	8b000082 	add	x2, x4, x0
    86f8:	f9401058 	ldr	x24, [x2, #32]
    86fc:	b40002b8 	cbz	x24, 8750 <fwp_hof0.constprop.0+0x640>
    8700:	38606880 	ldrb	w0, [x4, x0]
    8704:	7100081f 	cmp	w0, #0x2
    8708:	54007980 	b.eq	9638 <fwp_hof0.constprop.0+0x1528>  // b.none
    870c:	7100041f 	cmp	w0, #0x1
    8710:	54000201 	b.ne	8750 <fwp_hof0.constprop.0+0x640>  // b.any
    8714:	29430043 	ldp	w3, w0, [x2, #24]
    8718:	92403c21 	and	x1, x1, #0xffff
    871c:	9b037c21 	mul	x1, x1, x3
    8720:	d360fc21 	lsr	x1, x1, #32
    8724:	eb00003f 	cmp	x1, x0
    8728:	54000142 	b.cs	8750 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    872c:	8b010318 	add	x24, x24, x1
    8730:	39400300 	ldrb	w0, [x24]
    8734:	340000e0 	cbz	w0, 8750 <fwp_hof0.constprop.0+0x640>
    8738:	7100041f 	cmp	w0, #0x1
    873c:	540022a0 	b.eq	8b90 <fwp_hof0.constprop.0+0xa80>  // b.none
    8740:	7103fc1f 	cmp	w0, #0xff
    8744:	54009040 	b.eq	994c <fwp_hof0.constprop.0+0x183c>  // b.none
    8748:	51000400 	sub	w0, w0, #0x1
    874c:	39000300 	strb	w0, [x24]
    8750:	52800040 	mov	w0, #0x2                   	// #2
    8754:	93407e7c 	sxtw	x28, w19
    8758:	f90003e5 	str	x5, [sp]
    875c:	97ffebc5 	bl	3670 <descent_phase_step>
    8760:	aa1c03e0 	mov	x0, x28
    8764:	97ffed13 	bl	3bb0 <fwp_tape_of>
    8768:	f9403002 	ldr	x2, [x0, #96]
    876c:	aa0003e7 	mov	x7, x0
    8770:	f94003e5 	ldr	x5, [sp]
    8774:	b500a222 	cbnz	x2, 9bb8 <fwp_hof0.constprop.0+0x1aa8>
    8778:	97ffea26 	bl	3010 <fwp_tape_unlink_scope>
    877c:	b9400008 	ldr	w8, [x0]
    8780:	a9408019 	ldp	x25, x0, [x0, #8]
    8784:	b90004ff 	str	wzr, [x7, #4]
    8788:	a941dcea 	ldp	x10, x23, [x7, #24]
    878c:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8790:	a942ecf8 	ldp	x24, x27, [x7, #40]
    8794:	a943e8f3 	ldp	x19, x26, [x7, #56]
    8798:	f94024e2 	ldr	x2, [x7, #72]
    879c:	6b03011f 	cmp	w8, w3
    87a0:	54000108 	b.hi	87c0 <fwp_hof0.constprop.0+0x6b0>  // b.pmore
    87a4:	9101c2a8 	add	x8, x21, #0x70
    87a8:	92403f83 	and	x3, x28, #0xffff
    87ac:	d1000463 	sub	x3, x3, #0x1
    87b0:	f9407509 	ldr	x9, [x8, #232]
    87b4:	eb09007f 	cmp	x3, x9
    87b8:	5400004a 	b.ge	87c0 <fwp_hof0.constprop.0+0x6b0>  // b.tcont
    87bc:	f9007503 	str	x3, [x8, #232]
    87c0:	4f000400 	movi	v0.4s, #0x0
    87c4:	9101c2a9 	add	x9, x21, #0x70
    87c8:	f9000cff 	str	xzr, [x7, #24]
    87cc:	910243e1 	add	x1, sp, #0x90
    87d0:	a9047cff 	stp	xzr, xzr, [x7, #64]
    87d4:	9101e3e3 	add	x3, sp, #0x78
    87d8:	90ffffe8 	adrp	x8, 4000 <fwp_format_g.constprop.0+0x3ec>
    87dc:	f941892b 	ldr	x11, [x9, #784]
    87e0:	3c8080e0 	stur	q0, [x7, #8]
    87e4:	91100108 	add	x8, x8, #0x400
    87e8:	ad0100e0 	stp	q0, q0, [x7, #32]
    87ec:	f9000be1 	str	x1, [sp, #16]
    87f0:	a907a3eb 	stp	x11, x8, [sp, #120]
    87f4:	a908dfe1 	stp	x1, x23, [sp, #136]
    87f8:	a909eff8 	stp	x24, x27, [sp, #152]
    87fc:	a90aebf3 	stp	x19, x26, [sp, #168]
    8800:	a90b8bea 	stp	x10, x2, [sp, #184]
    8804:	f9018923 	str	x3, [x9, #784]
    8808:	b7f87da5 	tbnz	x5, #63, 97bc <fwp_hof0.constprop.0+0x16ac>
    880c:	eb85839f 	cmp	x28, x5, asr #32
    8810:	540098a1 	b.ne	9b24 <fwp_hof0.constprop.0+0x1a14>  // b.any
    8814:	92407ca3 	and	x3, x5, #0xffffffff
    8818:	eb25401f 	cmp	x0, w5, uxtw
    881c:	540097ed 	b.le	9b18 <fwp_hof0.constprop.0+0x1a08>
    8820:	eb03033f 	cmp	x25, x3
    8824:	9a83c73c 	csinc	x28, x25, x3, gt
    8828:	eb1c005f 	cmp	x2, x28
    882c:	5400186a 	b.ge	8b38 <fwp_hof0.constprop.0+0xa28>  // b.tcont
    8830:	f100005f 	cmp	x2, #0x0
    8834:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    8838:	14000005 	b	884c <fwp_hof0.constprop.0+0x73c>
    883c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8840:	eb00005f 	cmp	x2, x0
    8844:	d37ff842 	lsl	x2, x2, #1
    8848:	9a9cd042 	csel	x2, x2, x28, le
    884c:	eb1c005f 	cmp	x2, x28
    8850:	54ffff6b 	b.lt	883c <fwp_hof0.constprop.0+0x72c>  // b.tstop
    8854:	f9001be5 	str	x5, [sp, #48]
    8858:	b400831a 	cbz	x26, 98b8 <fwp_hof0.constprop.0+0x17a8>
    885c:	aa1a03e0 	mov	x0, x26
    8860:	d37df041 	lsl	x1, x2, #3
    8864:	f90003e2 	str	x2, [sp]
    8868:	97ffe826 	bl	2900 <realloc@plt>
    886c:	f94003e2 	ldr	x2, [sp]
    8870:	aa0003fa 	mov	x26, x0
    8874:	f9401be5 	ldr	x5, [sp, #48]
    8878:	b4009b3a 	cbz	x26, 9bdc <fwp_hof0.constprop.0+0x1acc>
    887c:	f9005bfa 	str	x26, [sp, #176]
    8880:	f90063e2 	str	x2, [sp, #192]
    8884:	b50014dc 	cbnz	x28, 8b1c <fwp_hof0.constprop.0+0xa0c>
    8888:	b7f800c5 	tbnz	x5, #63, 88a0 <fwp_hof0.constprop.0+0x790>
    888c:	92407ca1 	and	x1, x5, #0xffffffff
    8890:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8894:	fc617b40 	ldr	d0, [x26, x1, lsl #3]
    8898:	1e612800 	fadd	d0, d0, d1
    889c:	fc217b40 	str	d0, [x26, x1, lsl #3]
    88a0:	9101c2a1 	add	x1, x21, #0x70
    88a4:	cb190385 	sub	x5, x28, x25
    88a8:	52800060 	mov	w0, #0x3                   	// #3
    88ac:	a9428827 	ldp	x7, x2, [x1, #40]
    88b0:	8b0700a5 	add	x5, x5, x7
    88b4:	8b190042 	add	x2, x2, x25
    88b8:	a9028825 	stp	x5, x2, [x1, #40]
    88bc:	97ffeb6d 	bl	3670 <descent_phase_step>
    88c0:	d1000783 	sub	x3, x28, #0x1
    88c4:	d1000725 	sub	x5, x25, #0x1
    88c8:	eb03033f 	cmp	x25, x3
    88cc:	540003ac 	b.gt	8940 <fwp_hof0.constprop.0+0x830>
    88d0:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    88d4:	1e602008 	fcmp	d0, #0.0
    88d8:	540002e0 	b.eq	8934 <fwp_hof0.constprop.0+0x824>  // b.none
    88dc:	cb190be0 	neg	x0, x25, lsl #2
    88e0:	cb1903e2 	neg	x2, x25
    88e4:	8b0002e1 	add	x1, x23, x0
    88e8:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    88ec:	37f80101 	tbnz	w1, #31, 890c <fwp_hof0.constprop.0+0x7fc>
    88f0:	8b020f67 	add	x7, x27, x2, lsl #3
    88f4:	93407c21 	sxtw	x1, w1
    88f8:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    88fc:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    8900:	1e620802 	fmul	d2, d0, d2
    8904:	1e622821 	fadd	d1, d1, d2
    8908:	fc217b41 	str	d1, [x26, x1, lsl #3]
    890c:	8b000300 	add	x0, x24, x0
    8910:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    8914:	37f80100 	tbnz	w0, #31, 8934 <fwp_hof0.constprop.0+0x824>
    8918:	8b020e62 	add	x2, x19, x2, lsl #3
    891c:	93407c00 	sxtw	x0, w0
    8920:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    8924:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    8928:	1e620800 	fmul	d0, d0, d2
    892c:	1e602820 	fadd	d0, d1, d0
    8930:	fc207b40 	str	d0, [x26, x0, lsl #3]
    8934:	d1000463 	sub	x3, x3, #0x1
    8938:	eb0300bf 	cmp	x5, x3
    893c:	54fffca1 	b.ne	88d0 <fwp_hof0.constprop.0+0x7c0>  // b.any
    8940:	52800080 	mov	w0, #0x4                   	// #4
    8944:	97ffeb4b 	bl	3670 <descent_phase_step>
    8948:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    894c:	eb00033f 	cmp	x25, x0
    8950:	54009408 	b.hi	9bd0 <fwp_hof0.constprop.0+0x1ac0>  // b.pmore
    8954:	91000720 	add	x0, x25, #0x1
    8958:	52800041 	mov	w1, #0x2                   	// #2
    895c:	d37df000 	lsl	x0, x0, #3
    8960:	97fff184 	bl	4f70 <fwp_heap_alloc>
    8964:	aa0003e2 	mov	x2, x0
    8968:	aa0003f3 	mov	x19, x0
    896c:	d2800001 	mov	x1, #0x0                   	// #0
    8970:	f8008459 	str	x25, [x2], #8
    8974:	b40000d9 	cbz	x25, 898c <fwp_hof0.constprop.0+0x87c>
    8978:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    897c:	f8217840 	str	x0, [x2, x1, lsl #3]
    8980:	91000421 	add	x1, x1, #0x1
    8984:	eb01033f 	cmp	x25, x1
    8988:	54ffff81 	b.ne	8978 <fwp_hof0.constprop.0+0x868>  // b.any
    898c:	528000a0 	mov	w0, #0x5                   	// #5
    8990:	97ffeb38 	bl	3670 <descent_phase_step>
    8994:	f9400be0 	ldr	x0, [sp, #16]
    8998:	9101c2a1 	add	x1, x21, #0x70
    899c:	f9403ff8 	ldr	x24, [sp, #120]
    89a0:	f9018838 	str	x24, [x1, #784]
    89a4:	97ffee97 	bl	4400 <fwp_tape_buffers_release>
    89a8:	528000c0 	mov	w0, #0x6                   	// #6
    89ac:	97ffeb31 	bl	3670 <descent_phase_step>
    89b0:	91174282 	add	x2, x20, #0x5d0
    89b4:	f949d841 	ldr	x1, [x2, #5040]
    89b8:	f949ec40 	ldr	x0, [x2, #5080]
    89bc:	cb010261 	sub	x1, x19, x1
    89c0:	eb00403f 	cmp	x1, x0, lsl #16
    89c4:	54000322 	b.cs	8a28 <fwp_hof0.constprop.0+0x918>  // b.hs, b.nlast
    89c8:	d350fc20 	lsr	x0, x1, #16
    89cc:	f949fc43 	ldr	x3, [x2, #5112]
    89d0:	8b000800 	add	x0, x0, x0, lsl #2
    89d4:	d37df002 	lsl	x2, x0, #3
    89d8:	8b020060 	add	x0, x3, x2
    89dc:	f9401017 	ldr	x23, [x0, #32]
    89e0:	b4000257 	cbz	x23, 8a28 <fwp_hof0.constprop.0+0x918>
    89e4:	38626862 	ldrb	w2, [x3, x2]
    89e8:	7100085f 	cmp	w2, #0x2
    89ec:	54006ec0 	b.eq	97c4 <fwp_hof0.constprop.0+0x16b4>  // b.none
    89f0:	7100045f 	cmp	w2, #0x1
    89f4:	540001a1 	b.ne	8a28 <fwp_hof0.constprop.0+0x918>  // b.any
    89f8:	29430002 	ldp	w2, w0, [x0, #24]
    89fc:	92403c21 	and	x1, x1, #0xffff
    8a00:	9b027c21 	mul	x1, x1, x2
    8a04:	d360fc21 	lsr	x1, x1, #32
    8a08:	eb00003f 	cmp	x1, x0
    8a0c:	540000e2 	b.cs	8a28 <fwp_hof0.constprop.0+0x918>  // b.hs, b.nlast
    8a10:	8b0102f7 	add	x23, x23, x1
    8a14:	394002e0 	ldrb	w0, [x23]
    8a18:	7103fc1f 	cmp	w0, #0xff
    8a1c:	54006de0 	b.eq	97d8 <fwp_hof0.constprop.0+0x16c8>  // b.none
    8a20:	52800020 	mov	w0, #0x1                   	// #1
    8a24:	390002e0 	strb	w0, [x23]
    8a28:	f94013e0 	ldr	x0, [sp, #32]
    8a2c:	eb00031f 	cmp	x24, x0
    8a30:	54008fc1 	b.ne	9c28 <fwp_hof0.constprop.0+0x1b18>  // b.any
    8a34:	f9400fe0 	ldr	x0, [sp, #24]
    8a38:	9101c2a1 	add	x1, x21, #0x70
    8a3c:	f94033e2 	ldr	x2, [sp, #96]
    8a40:	f9018822 	str	x2, [x1, #784]
    8a44:	97fff5ab 	bl	60f0 <fwp_tape_scope_release>
    8a48:	f9400260 	ldr	x0, [x19]
    8a4c:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8a50:	b7f84700 	tbnz	x0, #63, 9330 <fwp_hof0.constprop.0+0x1220>
    8a54:	91174282 	add	x2, x20, #0x5d0
    8a58:	f949d840 	ldr	x0, [x2, #5040]
    8a5c:	f949ec41 	ldr	x1, [x2, #5080]
    8a60:	cb000260 	sub	x0, x19, x0
    8a64:	eb01401f 	cmp	x0, x1, lsl #16
    8a68:	54004642 	b.cs	9330 <fwp_hof0.constprop.0+0x1220>  // b.hs, b.nlast
    8a6c:	d350fc01 	lsr	x1, x0, #16
    8a70:	f949fc44 	ldr	x4, [x2, #5112]
    8a74:	8b010821 	add	x1, x1, x1, lsl #2
    8a78:	d37df021 	lsl	x1, x1, #3
    8a7c:	8b010083 	add	x3, x4, x1
    8a80:	f9401062 	ldr	x2, [x3, #32]
    8a84:	b4004562 	cbz	x2, 9330 <fwp_hof0.constprop.0+0x1220>
    8a88:	38616881 	ldrb	w1, [x4, x1]
    8a8c:	7100083f 	cmp	w1, #0x2
    8a90:	540044a0 	b.eq	9324 <fwp_hof0.constprop.0+0x1214>  // b.none
    8a94:	7100043f 	cmp	w1, #0x1
    8a98:	540044c1 	b.ne	9330 <fwp_hof0.constprop.0+0x1220>  // b.any
    8a9c:	29430464 	ldp	w4, w1, [x3, #24]
    8aa0:	92403c00 	and	x0, x0, #0xffff
    8aa4:	9b047c00 	mul	x0, x0, x4
    8aa8:	d360fc00 	lsr	x0, x0, #32
    8aac:	eb01001f 	cmp	x0, x1
    8ab0:	54004402 	b.cs	9330 <fwp_hof0.constprop.0+0x1220>  // b.hs, b.nlast
    8ab4:	8b000042 	add	x2, x2, x0
    8ab8:	39400040 	ldrb	w0, [x2]
    8abc:	7100041f 	cmp	w0, #0x1
    8ac0:	54004381 	b.ne	9330 <fwp_hof0.constprop.0+0x1220>  // b.any
    8ac4:	aa1303fb 	mov	x27, x19
    8ac8:	d2800000 	mov	x0, #0x0                   	// #0
    8acc:	f90003f3 	str	x19, [sp]
    8ad0:	f94003e1 	ldr	x1, [sp]
    8ad4:	91002265 	add	x5, x19, #0x8
    8ad8:	91002023 	add	x3, x1, #0x8
    8adc:	d2800001 	mov	x1, #0x0                   	// #0
    8ae0:	b5000158 	cbnz	x24, 8b08 <fwp_hof0.constprop.0+0x9f8>
    8ae4:	1400004e 	b	8c1c <fwp_hof0.constprop.0+0xb0c>
    8ae8:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8aec:	f9400362 	ldr	x2, [x27]
    8af0:	1e600900 	fmul	d0, d8, d0
    8af4:	b7f88562 	tbnz	x2, #63, 9ba0 <fwp_hof0.constprop.0+0x1a90>
    8af8:	91000421 	add	x1, x1, #0x1
    8afc:	fc008460 	str	d0, [x3], #8
    8b00:	eb01031f 	cmp	x24, x1
    8b04:	540008c0 	b.eq	8c1c <fwp_hof0.constprop.0+0xb0c>  // b.none
    8b08:	f9400264 	ldr	x4, [x19]
    8b0c:	aa0503e2 	mov	x2, x5
    8b10:	b6fffec4 	tbz	x4, #63, 8ae8 <fwp_hof0.constprop.0+0x9d8>
    8b14:	f9400a62 	ldr	x2, [x19, #16]
    8b18:	17fffff4 	b	8ae8 <fwp_hof0.constprop.0+0x9d8>
    8b1c:	d37df382 	lsl	x2, x28, #3
    8b20:	aa1a03e0 	mov	x0, x26
    8b24:	52800001 	mov	w1, #0x0                   	// #0
    8b28:	f90003e5 	str	x5, [sp]
    8b2c:	97ffe76d 	bl	28e0 <memset@plt>
    8b30:	f94003e5 	ldr	x5, [sp]
    8b34:	17ffff55 	b	8888 <fwp_hof0.constprop.0+0x778>
    8b38:	f100035f 	cmp	x26, #0x0
    8b3c:	1a9f17e0 	cset	w0, eq	// eq = none
    8b40:	f100039f 	cmp	x28, #0x0
    8b44:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8b48:	54ffe9e0 	b.eq	8884 <fwp_hof0.constprop.0+0x774>  // b.none
    8b4c:	f9400be0 	ldr	x0, [sp, #16]
    8b50:	9101c2b5 	add	x21, x21, #0x70
    8b54:	f9403fe1 	ldr	x1, [sp, #120]
    8b58:	f9018aa1 	str	x1, [x21, #784]
    8b5c:	97ffee29 	bl	4400 <fwp_tape_buffers_release>
    8b60:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8b64:	f947e863 	ldr	x3, [x3, #4048]
    8b68:	d2800262 	mov	x2, #0x13                  	// #19
    8b6c:	d2800021 	mov	x1, #0x1                   	// #1
    8b70:	90000020 	adrp	x0, c000 <f0+0x23d0>
    8b74:	913d2000 	add	x0, x0, #0xf48
    8b78:	f9400063 	ldr	x3, [x3]
    8b7c:	97ffe7a5 	bl	2a10 <fwrite@plt>
    8b80:	d2800000 	mov	x0, #0x0                   	// #0
    8b84:	97ffe7af 	bl	2a40 <fflush@plt>
    8b88:	52800cc0 	mov	w0, #0x66                  	// #102
    8b8c:	97ffe7bd 	bl	2a80 <_Exit@plt>
    8b90:	f9400366 	ldr	x6, [x27]
    8b94:	aa1b03e0 	mov	x0, x27
    8b98:	f949eee3 	ldr	x3, [x23, #5080]
    8b9c:	f949dae1 	ldr	x1, [x23, #5040]
    8ba0:	d370bc63 	lsl	x3, x3, #16
    8ba4:	cb010362 	sub	x2, x27, x1
    8ba8:	b7f85546 	tbnz	x6, #63, 9650 <fwp_hof0.constprop.0+0x1540>
    8bac:	eb02007f 	cmp	x3, x2
    8bb0:	54ffdd09 	b.ls	8750 <fwp_hof0.constprop.0+0x640>  // b.plast
    8bb4:	d350fc40 	lsr	x0, x2, #16
    8bb8:	8b000800 	add	x0, x0, x0, lsl #2
    8bbc:	d37df000 	lsl	x0, x0, #3
    8bc0:	8b000083 	add	x3, x4, x0
    8bc4:	f9401061 	ldr	x1, [x3, #32]
    8bc8:	b4ffdc41 	cbz	x1, 8750 <fwp_hof0.constprop.0+0x640>
    8bcc:	38606880 	ldrb	w0, [x4, x0]
    8bd0:	7100081f 	cmp	w0, #0x2
    8bd4:	54006080 	b.eq	97e4 <fwp_hof0.constprop.0+0x16d4>  // b.none
    8bd8:	7100041f 	cmp	w0, #0x1
    8bdc:	54ffdba1 	b.ne	8750 <fwp_hof0.constprop.0+0x640>  // b.any
    8be0:	92403c40 	and	x0, x2, #0xffff
    8be4:	29430864 	ldp	w4, w2, [x3, #24]
    8be8:	9b047c00 	mul	x0, x0, x4
    8bec:	d360fc00 	lsr	x0, x0, #32
    8bf0:	eb02001f 	cmp	x0, x2
    8bf4:	54ffdae2 	b.cs	8750 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    8bf8:	8b000021 	add	x1, x1, x0
    8bfc:	39400020 	ldrb	w0, [x1]
    8c00:	7100041f 	cmp	w0, #0x1
    8c04:	54ffda61 	b.ne	8750 <fwp_hof0.constprop.0+0x640>  // b.any
    8c08:	aa1b03e0 	mov	x0, x27
    8c0c:	f90003e5 	str	x5, [sp]
    8c10:	97ffefb8 	bl	4af0 <fwp_mem_free>
    8c14:	f94003e5 	ldr	x5, [sp]
    8c18:	17fffece 	b	8750 <fwp_hof0.constprop.0+0x640>
    8c1c:	97fff721 	bl	68a0 <fwp_drop10>
    8c20:	aa1603e1 	mov	x1, x22
    8c24:	d2800002 	mov	x2, #0x0                   	// #0
    8c28:	b40065f6 	cbz	x22, 98e4 <fwp_hof0.constprop.0+0x17d4>
    8c2c:	d503201f 	nop
    8c30:	f9400821 	ldr	x1, [x1, #16]
    8c34:	91000442 	add	x2, x2, #0x1
    8c38:	b5ffffc1 	cbnz	x1, 8c30 <fwp_hof0.constprop.0+0xb20>
    8c3c:	f9400360 	ldr	x0, [x27]
    8c40:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    8c44:	b7f82c40 	tbnz	x0, #63, 91cc <fwp_hof0.constprop.0+0x10bc>
    8c48:	91174283 	add	x3, x20, #0x5d0
    8c4c:	f94003e4 	ldr	x4, [sp]
    8c50:	f949d861 	ldr	x1, [x3, #5040]
    8c54:	f949ec63 	ldr	x3, [x3, #5080]
    8c58:	cb010081 	sub	x1, x4, x1
    8c5c:	eb03403f 	cmp	x1, x3, lsl #16
    8c60:	54002b62 	b.cs	91cc <fwp_hof0.constprop.0+0x10bc>  // b.hs, b.nlast
    8c64:	91174284 	add	x4, x20, #0x5d0
    8c68:	d350fc23 	lsr	x3, x1, #16
    8c6c:	8b030863 	add	x3, x3, x3, lsl #2
    8c70:	f949fc87 	ldr	x7, [x4, #5112]
    8c74:	d37df063 	lsl	x3, x3, #3
    8c78:	8b0300e6 	add	x6, x7, x3
    8c7c:	f94010c4 	ldr	x4, [x6, #32]
    8c80:	b4002a44 	cbz	x4, 91c8 <fwp_hof0.constprop.0+0x10b8>
    8c84:	386368e3 	ldrb	w3, [x7, x3]
    8c88:	7100087f 	cmp	w3, #0x2
    8c8c:	540029a0 	b.eq	91c0 <fwp_hof0.constprop.0+0x10b0>  // b.none
    8c90:	7100047f 	cmp	w3, #0x1
    8c94:	540029a1 	b.ne	91c8 <fwp_hof0.constprop.0+0x10b8>  // b.any
    8c98:	29430cc7 	ldp	w7, w3, [x6, #24]
    8c9c:	92403c21 	and	x1, x1, #0xffff
    8ca0:	9b077c21 	mul	x1, x1, x7
    8ca4:	d360fc21 	lsr	x1, x1, #32
    8ca8:	eb03003f 	cmp	x1, x3
    8cac:	540028e2 	b.cs	91c8 <fwp_hof0.constprop.0+0x10b8>  // b.hs, b.nlast
    8cb0:	8b010084 	add	x4, x4, x1
    8cb4:	39400081 	ldrb	w1, [x4]
    8cb8:	7100043f 	cmp	w1, #0x1
    8cbc:	54002861 	b.ne	91c8 <fwp_hof0.constprop.0+0x10b8>  // b.any
    8cc0:	b90033e1 	str	w1, [sp, #48]
    8cc4:	eb05005f 	cmp	x2, x5
    8cc8:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8ccc:	9100237c 	add	x28, x27, #0x8
    8cd0:	b4006ea5 	cbz	x5, 9aa4 <fwp_hof0.constprop.0+0x1994>
    8cd4:	f94003e1 	ldr	x1, [sp]
    8cd8:	d37df0a7 	lsl	x7, x5, #3
    8cdc:	aa1603e2 	mov	x2, x22
    8ce0:	91002026 	add	x6, x1, #0x8
    8ce4:	d2800001 	mov	x1, #0x0                   	// #0
    8ce8:	1400000a 	b	8d10 <fwp_hof0.constprop.0+0xc00>
    8cec:	fc616881 	ldr	d1, [x4, x1]
    8cf0:	fd400440 	ldr	d0, [x2, #8]
    8cf4:	1e613800 	fsub	d0, d0, d1
    8cf8:	fc216b80 	str	d0, [x28, x1]
    8cfc:	91002021 	add	x1, x1, #0x8
    8d00:	f9400842 	ldr	x2, [x2, #16]
    8d04:	eb07003f 	cmp	x1, x7
    8d08:	540001c0 	b.eq	8d40 <fwp_hof0.constprop.0+0xc30>  // b.none
    8d0c:	f9400360 	ldr	x0, [x27]
    8d10:	aa0603e4 	mov	x4, x6
    8d14:	b6fffec0 	tbz	x0, #63, 8cec <fwp_hof0.constprop.0+0xbdc>
    8d18:	f94003e0 	ldr	x0, [sp]
    8d1c:	fd400440 	ldr	d0, [x2, #8]
    8d20:	f9400804 	ldr	x4, [x0, #16]
    8d24:	fc616881 	ldr	d1, [x4, x1]
    8d28:	1e613800 	fsub	d0, d0, d1
    8d2c:	fc216b80 	str	d0, [x28, x1]
    8d30:	91002021 	add	x1, x1, #0x8
    8d34:	f9400842 	ldr	x2, [x2, #16]
    8d38:	eb07003f 	cmp	x1, x7
    8d3c:	54fffe81 	b.ne	8d0c <fwp_hof0.constprop.0+0xbfc>  // b.any
    8d40:	b4006e96 	cbz	x22, 9b10 <fwp_hof0.constprop.0+0x1a00>
    8d44:	91174280 	add	x0, x20, #0x5d0
    8d48:	aa1603e7 	mov	x7, x22
    8d4c:	d2800018 	mov	x24, #0x0                   	// #0
    8d50:	f949ec09 	ldr	x9, [x0, #5080]
    8d54:	f949d80a 	ldr	x10, [x0, #5040]
    8d58:	f949fc08 	ldr	x8, [x0, #5112]
    8d5c:	d370bd29 	lsl	x9, x9, #16
    8d60:	14000006 	b	8d78 <fwp_hof0.constprop.0+0xc68>
    8d64:	f94008e7 	ldr	x7, [x7, #16]
    8d68:	91000718 	add	x24, x24, #0x1
    8d6c:	f10000ff 	cmp	x7, #0x0
    8d70:	fa5810a0 	ccmp	x5, x24, #0x0, ne	// ne = any
    8d74:	54000329 	b.ls	8dd8 <fwp_hof0.constprop.0+0xcc8>  // b.plast
    8d78:	cb0a00e0 	sub	x0, x7, x10
    8d7c:	eb09001f 	cmp	x0, x9
    8d80:	540002c2 	b.cs	8dd8 <fwp_hof0.constprop.0+0xcc8>  // b.hs, b.nlast
    8d84:	d350fc01 	lsr	x1, x0, #16
    8d88:	8b010821 	add	x1, x1, x1, lsl #2
    8d8c:	d37df021 	lsl	x1, x1, #3
    8d90:	8b010106 	add	x6, x8, x1
    8d94:	f94010c2 	ldr	x2, [x6, #32]
    8d98:	b4000202 	cbz	x2, 8dd8 <fwp_hof0.constprop.0+0xcc8>
    8d9c:	38616901 	ldrb	w1, [x8, x1]
    8da0:	7100083f 	cmp	w1, #0x2
    8da4:	54000e20 	b.eq	8f68 <fwp_hof0.constprop.0+0xe58>  // b.none
    8da8:	7100043f 	cmp	w1, #0x1
    8dac:	54000161 	b.ne	8dd8 <fwp_hof0.constprop.0+0xcc8>  // b.any
    8db0:	294304cb 	ldp	w11, w1, [x6, #24]
    8db4:	92403c00 	and	x0, x0, #0xffff
    8db8:	9b0b7c00 	mul	x0, x0, x11
    8dbc:	d360fc00 	lsr	x0, x0, #32
    8dc0:	eb01001f 	cmp	x0, x1
    8dc4:	540000a2 	b.cs	8dd8 <fwp_hof0.constprop.0+0xcc8>  // b.hs, b.nlast
    8dc8:	8b000042 	add	x2, x2, x0
    8dcc:	39400040 	ldrb	w0, [x2]
    8dd0:	7100041f 	cmp	w0, #0x1
    8dd4:	54fffc80 	b.eq	8d64 <fwp_hof0.constprop.0+0xc54>  // b.none
    8dd8:	eb1800bf 	cmp	x5, x24
    8ddc:	54000ce9 	b.ls	8f78 <fwp_hof0.constprop.0+0xe68>  // b.plast
    8de0:	aa0503f7 	mov	x23, x5
    8de4:	d1002399 	sub	x25, x28, #0x8
    8de8:	910323f3 	add	x19, sp, #0xc8
    8dec:	9117429a 	add	x26, x20, #0x5d0
    8df0:	d280001b 	mov	x27, #0x0                   	// #0
    8df4:	14000012 	b	8e3c <fwp_hof0.constprop.0+0xd2c>
    8df8:	7100045f 	cmp	w2, #0x1
    8dfc:	540001a1 	b.ne	8e30 <fwp_hof0.constprop.0+0xd20>  // b.any
    8e00:	29430909 	ldp	w9, w2, [x8, #24]
    8e04:	92403c21 	and	x1, x1, #0xffff
    8e08:	9b097c21 	mul	x1, x1, x9
    8e0c:	d360fc21 	lsr	x1, x1, #32
    8e10:	eb02003f 	cmp	x1, x2
    8e14:	540000e2 	b.cs	8e30 <fwp_hof0.constprop.0+0xd20>  // b.hs, b.nlast
    8e18:	8b010000 	add	x0, x0, x1
    8e1c:	39400001 	ldrb	w1, [x0]
    8e20:	7103fc3f 	cmp	w1, #0xff
    8e24:	54003020 	b.eq	9428 <fwp_hof0.constprop.0+0x1318>  // b.none
    8e28:	52800021 	mov	w1, #0x1                   	// #1
    8e2c:	39000001 	strb	w1, [x0]
    8e30:	d10006f7 	sub	x23, x23, #0x1
    8e34:	eb1802ff 	cmp	x23, x24
    8e38:	54000389 	b.ls	8ea8 <fwp_hof0.constprop.0+0xd98>  // b.plast
    8e3c:	f8777b22 	ldr	x2, [x25, x23, lsl #3]
    8e40:	aa1303e1 	mov	x1, x19
    8e44:	52800020 	mov	w0, #0x1                   	// #1
    8e48:	a90cefe2 	stp	x2, x27, [sp, #200]
    8e4c:	97fff08e 	bl	5084 <fwp_data.part.0.constprop.0>
    8e50:	aa0003fb 	mov	x27, x0
    8e54:	f949db41 	ldr	x1, [x26, #5040]
    8e58:	f949ef40 	ldr	x0, [x26, #5080]
    8e5c:	cb010361 	sub	x1, x27, x1
    8e60:	eb00403f 	cmp	x1, x0, lsl #16
    8e64:	54fffe62 	b.cs	8e30 <fwp_hof0.constprop.0+0xd20>  // b.hs, b.nlast
    8e68:	d350fc20 	lsr	x0, x1, #16
    8e6c:	f949ff49 	ldr	x9, [x26, #5112]
    8e70:	8b000800 	add	x0, x0, x0, lsl #2
    8e74:	d37df002 	lsl	x2, x0, #3
    8e78:	8b020128 	add	x8, x9, x2
    8e7c:	f9401100 	ldr	x0, [x8, #32]
    8e80:	b4fffd80 	cbz	x0, 8e30 <fwp_hof0.constprop.0+0xd20>
    8e84:	38626922 	ldrb	w2, [x9, x2]
    8e88:	7100085f 	cmp	w2, #0x2
    8e8c:	54fffb61 	b.ne	8df8 <fwp_hof0.constprop.0+0xce8>  // b.any
    8e90:	72003c3f 	tst	w1, #0xffff
    8e94:	54fffc40 	b.eq	8e1c <fwp_hof0.constprop.0+0xd0c>  // b.none
    8e98:	d10006f7 	sub	x23, x23, #0x1
    8e9c:	eb1802ff 	cmp	x23, x24
    8ea0:	54fffce8 	b.hi	8e3c <fwp_hof0.constprop.0+0xd2c>  // b.pmore
    8ea4:	d503201f 	nop
    8ea8:	b50006b8 	cbnz	x24, 8f7c <fwp_hof0.constprop.0+0xe6c>
    8eac:	b94033e0 	ldr	w0, [sp, #48]
    8eb0:	d2800004 	mov	x4, #0x0                   	// #0
    8eb4:	7100001f 	cmp	w0, #0x0
    8eb8:	d2800020 	mov	x0, #0x1                   	// #1
    8ebc:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    8ec0:	b40007c4 	cbz	x4, 8fb8 <fwp_hof0.constprop.0+0xea8>
    8ec4:	d1000498 	sub	x24, x4, #0x1
    8ec8:	2a0003f9 	mov	w25, w0
    8ecc:	9117429a 	add	x26, x20, #0x5d0
    8ed0:	f8787b82 	ldr	x2, [x28, x24, lsl #3]
    8ed4:	aa1303e1 	mov	x1, x19
    8ed8:	52800020 	mov	w0, #0x1                   	// #1
    8edc:	a90cefe2 	stp	x2, x27, [sp, #200]
    8ee0:	97fff069 	bl	5084 <fwp_data.part.0.constprop.0>
    8ee4:	aa0003fb 	mov	x27, x0
    8ee8:	f949db41 	ldr	x1, [x26, #5040]
    8eec:	f949ef40 	ldr	x0, [x26, #5080]
    8ef0:	cb010361 	sub	x1, x27, x1
    8ef4:	eb00403f 	cmp	x1, x0, lsl #16
    8ef8:	54000302 	b.cs	8f58 <fwp_hof0.constprop.0+0xe48>  // b.hs, b.nlast
    8efc:	d350fc22 	lsr	x2, x1, #16
    8f00:	f949ff47 	ldr	x7, [x26, #5112]
    8f04:	8b020842 	add	x2, x2, x2, lsl #2
    8f08:	d37df042 	lsl	x2, x2, #3
    8f0c:	8b0200e6 	add	x6, x7, x2
    8f10:	f94010d7 	ldr	x23, [x6, #32]
    8f14:	b4000237 	cbz	x23, 8f58 <fwp_hof0.constprop.0+0xe48>
    8f18:	386268e2 	ldrb	w2, [x7, x2]
    8f1c:	7100085f 	cmp	w2, #0x2
    8f20:	540014a0 	b.eq	91b4 <fwp_hof0.constprop.0+0x10a4>  // b.none
    8f24:	7100045f 	cmp	w2, #0x1
    8f28:	54000181 	b.ne	8f58 <fwp_hof0.constprop.0+0xe48>  // b.any
    8f2c:	294308c7 	ldp	w7, w2, [x6, #24]
    8f30:	92403c21 	and	x1, x1, #0xffff
    8f34:	9b077c21 	mul	x1, x1, x7
    8f38:	d360fc21 	lsr	x1, x1, #32
    8f3c:	eb02003f 	cmp	x1, x2
    8f40:	540000c2 	b.cs	8f58 <fwp_hof0.constprop.0+0xe48>  // b.hs, b.nlast
    8f44:	8b0102f7 	add	x23, x23, x1
    8f48:	394002e1 	ldrb	w1, [x23]
    8f4c:	7103fc3f 	cmp	w1, #0xff
    8f50:	540012c0 	b.eq	91a8 <fwp_hof0.constprop.0+0x1098>  // b.none
    8f54:	390002f9 	strb	w25, [x23]
    8f58:	d1000718 	sub	x24, x24, #0x1
    8f5c:	b100071f 	cmn	x24, #0x1
    8f60:	54fffb81 	b.ne	8ed0 <fwp_hof0.constprop.0+0xdc0>  // b.any
    8f64:	14000015 	b	8fb8 <fwp_hof0.constprop.0+0xea8>
    8f68:	72003c1f 	tst	w0, #0xffff
    8f6c:	54fff300 	b.eq	8dcc <fwp_hof0.constprop.0+0xcbc>  // b.none
    8f70:	eb1800bf 	cmp	x5, x24
    8f74:	54fff368 	b.hi	8de0 <fwp_hof0.constprop.0+0xcd0>  // b.pmore
    8f78:	d280001b 	mov	x27, #0x0                   	// #0
    8f7c:	8b180f84 	add	x4, x28, x24, lsl #3
    8f80:	aa1c03e1 	mov	x1, x28
    8f84:	aa1603e0 	mov	x0, x22
    8f88:	f8408422 	ldr	x2, [x1], #8
    8f8c:	f9000402 	str	x2, [x0, #8]
    8f90:	aa0003e2 	mov	x2, x0
    8f94:	f9400800 	ldr	x0, [x0, #16]
    8f98:	eb04003f 	cmp	x1, x4
    8f9c:	54ffff61 	b.ne	8f88 <fwp_hof0.constprop.0+0xe78>  // b.any
    8fa0:	b94033e1 	ldr	w1, [sp, #48]
    8fa4:	f900085b 	str	x27, [x2, #16]
    8fa8:	aa1603fb 	mov	x27, x22
    8fac:	aa0003f6 	mov	x22, x0
    8fb0:	34000041 	cbz	w1, 8fb8 <fwp_hof0.constprop.0+0xea8>
    8fb4:	d280001c 	mov	x28, #0x0                   	// #0
    8fb8:	91174293 	add	x19, x20, #0x5d0
    8fbc:	aa1c03e0 	mov	x0, x28
    8fc0:	97ffeecc 	bl	4af0 <fwp_mem_free>
    8fc4:	f94003e0 	ldr	x0, [sp]
    8fc8:	f949ee62 	ldr	x2, [x19, #5080]
    8fcc:	f949da61 	ldr	x1, [x19, #5040]
    8fd0:	d370bc42 	lsl	x2, x2, #16
    8fd4:	cb010003 	sub	x3, x0, x1
    8fd8:	eb02007f 	cmp	x3, x2
    8fdc:	54000422 	b.cs	9060 <fwp_hof0.constprop.0+0xf50>  // b.hs, b.nlast
    8fe0:	d350fc60 	lsr	x0, x3, #16
    8fe4:	f949fe65 	ldr	x5, [x19, #5112]
    8fe8:	8b000800 	add	x0, x0, x0, lsl #2
    8fec:	d37df000 	lsl	x0, x0, #3
    8ff0:	8b0000a2 	add	x2, x5, x0
    8ff4:	f9401058 	ldr	x24, [x2, #32]
    8ff8:	b4000cf8 	cbz	x24, 9194 <fwp_hof0.constprop.0+0x1084>
    8ffc:	386068a1 	ldrb	w1, [x5, x0]
    9000:	7100083f 	cmp	w1, #0x2
    9004:	54003200 	b.eq	9644 <fwp_hof0.constprop.0+0x1534>  // b.none
    9008:	7100043f 	cmp	w1, #0x1
    900c:	54000c41 	b.ne	9194 <fwp_hof0.constprop.0+0x1084>  // b.any
    9010:	29430844 	ldp	w4, w2, [x2, #24]
    9014:	92403c61 	and	x1, x3, #0xffff
    9018:	9b047c21 	mul	x1, x1, x4
    901c:	d360fc21 	lsr	x1, x1, #32
    9020:	eb02003f 	cmp	x1, x2
    9024:	54000b82 	b.cs	9194 <fwp_hof0.constprop.0+0x1084>  // b.hs, b.nlast
    9028:	8b010318 	add	x24, x24, x1
    902c:	39400301 	ldrb	w1, [x24]
    9030:	34000b21 	cbz	w1, 9194 <fwp_hof0.constprop.0+0x1084>
    9034:	7100043f 	cmp	w1, #0x1
    9038:	540006c0 	b.eq	9110 <fwp_hof0.constprop.0+0x1000>  // b.none
    903c:	7103fc3f 	cmp	w1, #0xff
    9040:	54004bc0 	b.eq	99b8 <fwp_hof0.constprop.0+0x18a8>  // b.none
    9044:	91174280 	add	x0, x20, #0x5d0
    9048:	51000421 	sub	w1, w1, #0x1
    904c:	39000301 	strb	w1, [x24]
    9050:	f949ec02 	ldr	x2, [x0, #5080]
    9054:	f949d801 	ldr	x1, [x0, #5040]
    9058:	d370bc42 	lsl	x2, x2, #16
    905c:	d503201f 	nop
    9060:	cb0102c1 	sub	x1, x22, x1
    9064:	eb02003f 	cmp	x1, x2
    9068:	540003c2 	b.cs	90e0 <fwp_hof0.constprop.0+0xfd0>  // b.hs, b.nlast
    906c:	91174297 	add	x23, x20, #0x5d0
    9070:	d350fc20 	lsr	x0, x1, #16
    9074:	f949fee3 	ldr	x3, [x23, #5112]
    9078:	8b000800 	add	x0, x0, x0, lsl #2
    907c:	d37df000 	lsl	x0, x0, #3
    9080:	8b000062 	add	x2, x3, x0
    9084:	f9401053 	ldr	x19, [x2, #32]
    9088:	b40002d3 	cbz	x19, 90e0 <fwp_hof0.constprop.0+0xfd0>
    908c:	38606860 	ldrb	w0, [x3, x0]
    9090:	7100081f 	cmp	w0, #0x2
    9094:	54003240 	b.eq	96dc <fwp_hof0.constprop.0+0x15cc>  // b.none
    9098:	7100041f 	cmp	w0, #0x1
    909c:	54000221 	b.ne	90e0 <fwp_hof0.constprop.0+0xfd0>  // b.any
    90a0:	29430044 	ldp	w4, w0, [x2, #24]
    90a4:	92403c21 	and	x1, x1, #0xffff
    90a8:	9b047c21 	mul	x1, x1, x4
    90ac:	d360fc21 	lsr	x1, x1, #32
    90b0:	eb00003f 	cmp	x1, x0
    90b4:	54000162 	b.cs	90e0 <fwp_hof0.constprop.0+0xfd0>  // b.hs, b.nlast
    90b8:	8b010273 	add	x19, x19, x1
    90bc:	39400260 	ldrb	w0, [x19]
    90c0:	34000100 	cbz	w0, 90e0 <fwp_hof0.constprop.0+0xfd0>
    90c4:	7100041f 	cmp	w0, #0x1
    90c8:	54003940 	b.eq	97f0 <fwp_hof0.constprop.0+0x16e0>  // b.none
    90cc:	7103fc1f 	cmp	w0, #0xff
    90d0:	54004a80 	b.eq	9a20 <fwp_hof0.constprop.0+0x1910>  // b.none
    90d4:	51000400 	sub	w0, w0, #0x1
    90d8:	39000260 	strb	w0, [x19]
    90dc:	d503201f 	nop
    90e0:	f94007e0 	ldr	x0, [sp, #8]
    90e4:	b4001aa0 	cbz	x0, 9438 <fwp_hof0.constprop.0+0x1328>
    90e8:	f94007e0 	ldr	x0, [sp, #8]
    90ec:	f100041a 	subs	x26, x0, #0x1
    90f0:	f90007fa 	str	x26, [sp, #8]
    90f4:	54005986 	b.vs	9c24 <fwp_hof0.constprop.0+0x1b14>
    90f8:	91174280 	add	x0, x20, #0x5d0
    90fc:	aa1b03f6 	mov	x22, x27
    9100:	f949ec03 	ldr	x3, [x0, #5080]
    9104:	f949d801 	ldr	x1, [x0, #5040]
    9108:	d370bc63 	lsl	x3, x3, #16
    910c:	17fffc47 	b	8228 <fwp_hof0.constprop.0+0x118>
    9110:	f94003e4 	ldr	x4, [sp]
    9114:	f949ee62 	ldr	x2, [x19, #5080]
    9118:	aa0403e0 	mov	x0, x4
    911c:	f9400083 	ldr	x3, [x4]
    9120:	f949da61 	ldr	x1, [x19, #5040]
    9124:	d370bc42 	lsl	x2, x2, #16
    9128:	cb010087 	sub	x7, x4, x1
    912c:	b7f82de3 	tbnz	x3, #63, 96e8 <fwp_hof0.constprop.0+0x15d8>
    9130:	eb0200ff 	cmp	x7, x2
    9134:	54fff962 	b.cs	9060 <fwp_hof0.constprop.0+0xf50>  // b.hs, b.nlast
    9138:	d350fce3 	lsr	x3, x7, #16
    913c:	8b030863 	add	x3, x3, x3, lsl #2
    9140:	d37df063 	lsl	x3, x3, #3
    9144:	8b0300a6 	add	x6, x5, x3
    9148:	f94010c4 	ldr	x4, [x6, #32]
    914c:	b4fff8a4 	cbz	x4, 9060 <fwp_hof0.constprop.0+0xf50>
    9150:	386368a3 	ldrb	w3, [x5, x3]
    9154:	7100087f 	cmp	w3, #0x2
    9158:	540039c0 	b.eq	9890 <fwp_hof0.constprop.0+0x1780>  // b.none
    915c:	7100047f 	cmp	w3, #0x1
    9160:	54fff801 	b.ne	9060 <fwp_hof0.constprop.0+0xf50>  // b.any
    9164:	29430cc5 	ldp	w5, w3, [x6, #24]
    9168:	92403ce0 	and	x0, x7, #0xffff
    916c:	9b057c00 	mul	x0, x0, x5
    9170:	d360fc00 	lsr	x0, x0, #32
    9174:	eb03001f 	cmp	x0, x3
    9178:	54fff742 	b.cs	9060 <fwp_hof0.constprop.0+0xf50>  // b.hs, b.nlast
    917c:	8b000084 	add	x4, x4, x0
    9180:	39400080 	ldrb	w0, [x4]
    9184:	7100041f 	cmp	w0, #0x1
    9188:	54fff6c1 	b.ne	9060 <fwp_hof0.constprop.0+0xf50>  // b.any
    918c:	f94003e0 	ldr	x0, [sp]
    9190:	97ffee58 	bl	4af0 <fwp_mem_free>
    9194:	91174280 	add	x0, x20, #0x5d0
    9198:	f949ec02 	ldr	x2, [x0, #5080]
    919c:	f949d801 	ldr	x1, [x0, #5040]
    91a0:	d370bc42 	lsl	x2, x2, #16
    91a4:	17ffffaf 	b	9060 <fwp_hof0.constprop.0+0xf50>
    91a8:	aa1703e0 	mov	x0, x23
    91ac:	97ffedb1 	bl	4870 <fwp_rc_forget_slot>
    91b0:	17ffff69 	b	8f54 <fwp_hof0.constprop.0+0xe44>
    91b4:	72003c3f 	tst	w1, #0xffff
    91b8:	54ffed01 	b.ne	8f58 <fwp_hof0.constprop.0+0xe48>  // b.any
    91bc:	17ffff63 	b	8f48 <fwp_hof0.constprop.0+0xe38>
    91c0:	72003c3f 	tst	w1, #0xffff
    91c4:	54ffd780 	b.eq	8cb4 <fwp_hof0.constprop.0+0xba4>  // b.none
    91c8:	b4001096 	cbz	x22, 93d8 <fwp_hof0.constprop.0+0x12c8>
    91cc:	aa1603f3 	mov	x19, x22
    91d0:	d2800018 	mov	x24, #0x0                   	// #0
    91d4:	d503201f 	nop
    91d8:	f9400a73 	ldr	x19, [x19, #16]
    91dc:	aa1803e0 	mov	x0, x24
    91e0:	91000718 	add	x24, x24, #0x1
    91e4:	b5ffffb3 	cbnz	x19, 91d8 <fwp_hof0.constprop.0+0x10c8>
    91e8:	f9001be5 	str	x5, [sp, #48]
    91ec:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    91f0:	eb01031f 	cmp	x24, x1
    91f4:	54004dc8 	b.hi	9bac <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    91f8:	91000800 	add	x0, x0, #0x2
    91fc:	52800041 	mov	w1, #0x2                   	// #2
    9200:	d37df000 	lsl	x0, x0, #3
    9204:	97ffef5b 	bl	4f70 <fwp_heap_alloc>
    9208:	f9401be5 	ldr	x5, [sp, #48]
    920c:	aa0003fc 	mov	x28, x0
    9210:	aa1603e1 	mov	x1, x22
    9214:	eb05031f 	cmp	x24, x5
    9218:	9a859305 	csel	x5, x24, x5, ls	// ls = plast
    921c:	d503201f 	nop
    9220:	f9400420 	ldr	x0, [x1, #8]
    9224:	f8337b80 	str	x0, [x28, x19, lsl #3]
    9228:	91000673 	add	x19, x19, #0x1
    922c:	f9400821 	ldr	x1, [x1, #16]
    9230:	b5ffff81 	cbnz	x1, 9220 <fwp_hof0.constprop.0+0x1110>
    9234:	b4000da5 	cbz	x5, 93e8 <fwp_hof0.constprop.0+0x12d8>
    9238:	f9400360 	ldr	x0, [x27]
    923c:	b90033ff 	str	wzr, [sp, #48]
    9240:	17fffea5 	b	8cd4 <fwp_hof0.constprop.0+0xbc4>
    9244:	d53bd040 	mrs	x0, tpidr_el0
    9248:	91400000 	add	x0, x0, #0x0, lsl #12
    924c:	91004000 	add	x0, x0, #0x10
    9250:	f9400000 	ldr	x0, [x0]
    9254:	b4002900 	cbz	x0, 9774 <fwp_hof0.constprop.0+0x1664>
    9258:	f94017e1 	ldr	x1, [sp, #40]
    925c:	97ffe9a2 	bl	38e4 <fwp_closure_drop_push>
    9260:	b5ff87f6 	cbnz	x22, 835c <fwp_hof0.constprop.0+0x24c>
    9264:	9101c2b7 	add	x23, x21, #0x70
    9268:	52800000 	mov	w0, #0x0                   	// #0
    926c:	97ffe901 	bl	3670 <descent_phase_step>
    9270:	d2800013 	mov	x19, #0x0                   	// #0
    9274:	b94346e0 	ldr	w0, [x23, #836]
    9278:	35ff88e0 	cbnz	w0, 8394 <fwp_hof0.constprop.0+0x284>
    927c:	d503201f 	nop
    9280:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    9284:	913fc000 	add	x0, x0, #0xff0
    9288:	94000f22 	bl	cf10 <atexit>
    928c:	35ffc6a0 	cbnz	w0, 8b60 <fwp_hof0.constprop.0+0xa50>
    9290:	52800020 	mov	w0, #0x1                   	// #1
    9294:	b90346e0 	str	w0, [x23, #836]
    9298:	9101c2a0 	add	x0, x21, #0x70
    929c:	f9404817 	ldr	x23, [x0, #144]
    92a0:	f9407418 	ldr	x24, [x0, #232]
    92a4:	eb17031f 	cmp	x24, x23
    92a8:	54ff880b 	b.lt	83a8 <fwp_hof0.constprop.0+0x298>  // b.tstop
    92ac:	d503201f 	nop
    92b0:	eb17031f 	cmp	x24, x23
    92b4:	54ff8980 	b.eq	83e4 <fwp_hof0.constprop.0+0x2d4>  // b.none
    92b8:	f9403abb 	ldr	x27, [x21, #112]
    92bc:	8b180717 	add	x23, x24, x24, lsl #1
    92c0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    92c4:	9108c000 	add	x0, x0, #0x230
    92c8:	8b170b17 	add	x23, x24, x23, lsl #2
    92cc:	8b170f77 	add	x23, x27, x23, lsl #3
    92d0:	f90032ff 	str	xzr, [x23, #96]
    92d4:	97ffe5f3 	bl	2aa0 <getenv@plt>
    92d8:	b5ff8da0 	cbnz	x0, 848c <fwp_hof0.constprop.0+0x37c>
    92dc:	9101c2a0 	add	x0, x21, #0x70
    92e0:	f9406801 	ldr	x1, [x0, #208]
    92e4:	b4ff8de1 	cbz	x1, 84a0 <fwp_hof0.constprop.0+0x390>
    92e8:	3cc98002 	ldur	q2, [x0, #152]
    92ec:	91026001 	add	x1, x0, #0x98
    92f0:	3cca8001 	ldur	q1, [x0, #168]
    92f4:	f900681f 	str	xzr, [x0, #208]
    92f8:	4f000400 	movi	v0.4s, #0x0
    92fc:	ad0106e2 	stp	q2, q1, [x23, #32]
    9300:	a94b8002 	ldp	x2, x0, [x0, #184]
    9304:	f9000ee0 	str	x0, [x23, #24]
    9308:	f9401820 	ldr	x0, [x1, #48]
    930c:	f90022e2 	str	x2, [x23, #64]
    9310:	f90026e0 	str	x0, [x23, #72]
    9314:	ad000020 	stp	q0, q0, [x1]
    9318:	3d800820 	str	q0, [x1, #32]
    931c:	f900183f 	str	xzr, [x1, #48]
    9320:	17fffc60 	b	84a0 <fwp_hof0.constprop.0+0x390>
    9324:	72003c1f 	tst	w0, #0xffff
    9328:	54ffbc80 	b.eq	8ab8 <fwp_hof0.constprop.0+0x9a8>  // b.none
    932c:	d503201f 	nop
    9330:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9334:	eb00031f 	cmp	x24, x0
    9338:	540044c8 	b.hi	9bd0 <fwp_hof0.constprop.0+0x1ac0>  // b.pmore
    933c:	91000700 	add	x0, x24, #0x1
    9340:	52800021 	mov	w1, #0x1                   	// #1
    9344:	d37df000 	lsl	x0, x0, #3
    9348:	97ffef0a 	bl	4f70 <fwp_heap_alloc>
    934c:	91174282 	add	x2, x20, #0x5d0
    9350:	f9000018 	str	x24, [x0]
    9354:	aa0003fb 	mov	x27, x0
    9358:	f90003fb 	str	x27, [sp]
    935c:	f949d841 	ldr	x1, [x2, #5040]
    9360:	f949ec40 	ldr	x0, [x2, #5080]
    9364:	cb010361 	sub	x1, x27, x1
    9368:	eb00403f 	cmp	x1, x0, lsl #16
    936c:	54000322 	b.cs	93d0 <fwp_hof0.constprop.0+0x12c0>  // b.hs, b.nlast
    9370:	d350fc20 	lsr	x0, x1, #16
    9374:	f949fc44 	ldr	x4, [x2, #5112]
    9378:	8b000800 	add	x0, x0, x0, lsl #2
    937c:	d37df002 	lsl	x2, x0, #3
    9380:	8b020083 	add	x3, x4, x2
    9384:	f9401077 	ldr	x23, [x3, #32]
    9388:	b4000257 	cbz	x23, 93d0 <fwp_hof0.constprop.0+0x12c0>
    938c:	38626882 	ldrb	w2, [x4, x2]
    9390:	7100085f 	cmp	w2, #0x2
    9394:	54002840 	b.eq	989c <fwp_hof0.constprop.0+0x178c>  // b.none
    9398:	7100045f 	cmp	w2, #0x1
    939c:	540001a1 	b.ne	93d0 <fwp_hof0.constprop.0+0x12c0>  // b.any
    93a0:	29430864 	ldp	w4, w2, [x3, #24]
    93a4:	92403c21 	and	x1, x1, #0xffff
    93a8:	9b047c21 	mul	x1, x1, x4
    93ac:	d360fc21 	lsr	x1, x1, #32
    93b0:	eb02003f 	cmp	x1, x2
    93b4:	540000e2 	b.cs	93d0 <fwp_hof0.constprop.0+0x12c0>  // b.hs, b.nlast
    93b8:	8b0102f7 	add	x23, x23, x1
    93bc:	394002e1 	ldrb	w1, [x23]
    93c0:	7103fc3f 	cmp	w1, #0xff
    93c4:	54002740 	b.eq	98ac <fwp_hof0.constprop.0+0x179c>  // b.none
    93c8:	52800021 	mov	w1, #0x1                   	// #1
    93cc:	390002e1 	strb	w1, [x23]
    93d0:	aa1303e0 	mov	x0, x19
    93d4:	17fffdbf 	b	8ad0 <fwp_hof0.constprop.0+0x9c0>
    93d8:	52800041 	mov	w1, #0x2                   	// #2
    93dc:	d2800100 	mov	x0, #0x8                   	// #8
    93e0:	97ffeee4 	bl	4f70 <fwp_heap_alloc>
    93e4:	aa0003fc 	mov	x28, x0
    93e8:	d280001b 	mov	x27, #0x0                   	// #0
    93ec:	17fffef3 	b	8fb8 <fwp_hof0.constprop.0+0xea8>
    93f0:	52800041 	mov	w1, #0x2                   	// #2
    93f4:	d2800100 	mov	x0, #0x8                   	// #8
    93f8:	97ffeede 	bl	4f70 <fwp_heap_alloc>
    93fc:	aa0003f8 	mov	x24, x0
    9400:	91174280 	add	x0, x20, #0x5d0
    9404:	aa1803fb 	mov	x27, x24
    9408:	f900031f 	str	xzr, [x24]
    940c:	f949d801 	ldr	x1, [x0, #5040]
    9410:	f949ec00 	ldr	x0, [x0, #5080]
    9414:	cb010301 	sub	x1, x24, x1
    9418:	eb00403f 	cmp	x1, x0, lsl #16
    941c:	540010a2 	b.cs	9630 <fwp_hof0.constprop.0+0x1520>  // b.hs, b.nlast
    9420:	d2800017 	mov	x23, #0x0                   	// #0
    9424:	17fffc65 	b	85b8 <fwp_hof0.constprop.0+0x4a8>
    9428:	f9001fe0 	str	x0, [sp, #56]
    942c:	97ffed11 	bl	4870 <fwp_rc_forget_slot>
    9430:	f9401fe0 	ldr	x0, [sp, #56]
    9434:	17fffe7d 	b	8e28 <fwp_hof0.constprop.0+0xd18>
    9438:	f9400be0 	ldr	x0, [sp, #16]
    943c:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xeec0>
    9440:	910aa042 	add	x2, x2, #0x2a8
    9444:	aa1b03e1 	mov	x1, x27
    9448:	91014042 	add	x2, x2, #0x50
    944c:	52800023 	mov	w3, #0x1                   	// #1
    9450:	a9097fff 	stp	xzr, xzr, [sp, #144]
    9454:	f90053ff 	str	xzr, [sp, #160]
    9458:	97fff732 	bl	7120 <fwp_write>
    945c:	a9495ff6 	ldp	x22, x23, [sp, #144]
    9460:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9464:	912a4000 	add	x0, x0, #0xa90
    9468:	f10002df 	cmp	x22, #0x0
    946c:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9470:	b1002aff 	cmn	x23, #0xa
    9474:	54003a88 	b.hi	9bc4 <fwp_hof0.constprop.0+0x1ab4>  // b.pmore
    9478:	910026e0 	add	x0, x23, #0x9
    947c:	52800021 	mov	w1, #0x1                   	// #1
    9480:	97ffeebc 	bl	4f70 <fwp_heap_alloc>
    9484:	aa0003f8 	mov	x24, x0
    9488:	aa0003f3 	mov	x19, x0
    948c:	aa1703e2 	mov	x2, x23
    9490:	aa1603e1 	mov	x1, x22
    9494:	f8008717 	str	x23, [x24], #8
    9498:	8b170277 	add	x23, x19, x23
    949c:	aa1803e0 	mov	x0, x24
    94a0:	97ffe4b0 	bl	2760 <memcpy@plt>
    94a4:	390022ff 	strb	wzr, [x23, #8]
    94a8:	f9404be0 	ldr	x0, [sp, #144]
    94ac:	97ffe549 	bl	29d0 <free@plt>
    94b0:	91174281 	add	x1, x20, #0x5d0
    94b4:	f949d822 	ldr	x2, [x1, #5040]
    94b8:	f949ec20 	ldr	x0, [x1, #5080]
    94bc:	cb020262 	sub	x2, x19, x2
    94c0:	eb00405f 	cmp	x2, x0, lsl #16
    94c4:	54000322 	b.cs	9528 <fwp_hof0.constprop.0+0x1418>  // b.hs, b.nlast
    94c8:	d350fc40 	lsr	x0, x2, #16
    94cc:	f949fc23 	ldr	x3, [x1, #5112]
    94d0:	8b000800 	add	x0, x0, x0, lsl #2
    94d4:	d37df001 	lsl	x1, x0, #3
    94d8:	8b010060 	add	x0, x3, x1
    94dc:	f9401016 	ldr	x22, [x0, #32]
    94e0:	b4000256 	cbz	x22, 9528 <fwp_hof0.constprop.0+0x1418>
    94e4:	38616861 	ldrb	w1, [x3, x1]
    94e8:	7100083f 	cmp	w1, #0x2
    94ec:	54002cc0 	b.eq	9a84 <fwp_hof0.constprop.0+0x1974>  // b.none
    94f0:	7100043f 	cmp	w1, #0x1
    94f4:	540001a1 	b.ne	9528 <fwp_hof0.constprop.0+0x1418>  // b.any
    94f8:	29430003 	ldp	w3, w0, [x0, #24]
    94fc:	92403c41 	and	x1, x2, #0xffff
    9500:	9b037c21 	mul	x1, x1, x3
    9504:	d360fc21 	lsr	x1, x1, #32
    9508:	eb00003f 	cmp	x1, x0
    950c:	540000e2 	b.cs	9528 <fwp_hof0.constprop.0+0x1418>  // b.hs, b.nlast
    9510:	8b0102d6 	add	x22, x22, x1
    9514:	394002c0 	ldrb	w0, [x22]
    9518:	7103fc1f 	cmp	w0, #0xff
    951c:	54002be0 	b.eq	9a98 <fwp_hof0.constprop.0+0x1988>  // b.none
    9520:	52800020 	mov	w0, #0x1                   	// #1
    9524:	390002c0 	strb	w0, [x22]
    9528:	9101c2b6 	add	x22, x21, #0x70
    952c:	aa1b03e0 	mov	x0, x27
    9530:	97fff168 	bl	5ad0 <fwp_drop0>
    9534:	f9400262 	ldr	x2, [x19]
    9538:	d2800021 	mov	x1, #0x1                   	// #1
    953c:	f94006c3 	ldr	x3, [x22, #8]
    9540:	aa1803e0 	mov	x0, x24
    9544:	97ffe533 	bl	2a10 <fwrite@plt>
    9548:	f94006c1 	ldr	x1, [x22, #8]
    954c:	52800140 	mov	w0, #0xa                   	// #10
    9550:	97ffe4b8 	bl	2830 <fputc@plt>
    9554:	91174281 	add	x1, x20, #0x5d0
    9558:	f949d822 	ldr	x2, [x1, #5040]
    955c:	f949ec20 	ldr	x0, [x1, #5080]
    9560:	cb020262 	sub	x2, x19, x2
    9564:	eb00405f 	cmp	x2, x0, lsl #16
    9568:	54000382 	b.cs	95d8 <fwp_hof0.constprop.0+0x14c8>  // b.hs, b.nlast
    956c:	d350fc40 	lsr	x0, x2, #16
    9570:	f949fc23 	ldr	x3, [x1, #5112]
    9574:	8b000800 	add	x0, x0, x0, lsl #2
    9578:	d37df001 	lsl	x1, x0, #3
    957c:	8b010060 	add	x0, x3, x1
    9580:	f9401016 	ldr	x22, [x0, #32]
    9584:	b40002b6 	cbz	x22, 95d8 <fwp_hof0.constprop.0+0x14c8>
    9588:	38616861 	ldrb	w1, [x3, x1]
    958c:	7100083f 	cmp	w1, #0x2
    9590:	54002740 	b.eq	9a78 <fwp_hof0.constprop.0+0x1968>  // b.none
    9594:	7100043f 	cmp	w1, #0x1
    9598:	54000201 	b.ne	95d8 <fwp_hof0.constprop.0+0x14c8>  // b.any
    959c:	29430003 	ldp	w3, w0, [x0, #24]
    95a0:	92403c41 	and	x1, x2, #0xffff
    95a4:	9b037c21 	mul	x1, x1, x3
    95a8:	d360fc21 	lsr	x1, x1, #32
    95ac:	eb00003f 	cmp	x1, x0
    95b0:	54000142 	b.cs	95d8 <fwp_hof0.constprop.0+0x14c8>  // b.hs, b.nlast
    95b4:	8b0102d6 	add	x22, x22, x1
    95b8:	394002c0 	ldrb	w0, [x22]
    95bc:	340000e0 	cbz	w0, 95d8 <fwp_hof0.constprop.0+0x14c8>
    95c0:	7100041f 	cmp	w0, #0x1
    95c4:	54001b20 	b.eq	9928 <fwp_hof0.constprop.0+0x1818>  // b.none
    95c8:	7103fc1f 	cmp	w0, #0xff
    95cc:	54002b20 	b.eq	9b30 <fwp_hof0.constprop.0+0x1a20>  // b.none
    95d0:	51000400 	sub	w0, w0, #0x1
    95d4:	390002c0 	strb	w0, [x22]
    95d8:	f94027e0 	ldr	x0, [sp, #72]
    95dc:	f9400800 	ldr	x0, [x0, #16]
    95e0:	f90027e0 	str	x0, [sp, #72]
    95e4:	b5ff5d00 	cbnz	x0, 8184 <fwp_hof0.constprop.0+0x74>
    95e8:	a94f53f3 	ldp	x19, x20, [sp, #240]
    95ec:	a9505bf5 	ldp	x21, x22, [sp, #256]
    95f0:	a95163f7 	ldp	x23, x24, [sp, #272]
    95f4:	a9526bf9 	ldp	x25, x26, [sp, #288]
    95f8:	a95373fb 	ldp	x27, x28, [sp, #304]
    95fc:	fd40a3e8 	ldr	d8, [sp, #320]
    9600:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9604:	f947f400 	ldr	x0, [x0, #4072]
    9608:	f9406fe2 	ldr	x2, [sp, #216]
    960c:	f9400001 	ldr	x1, [x0]
    9610:	eb010042 	subs	x2, x2, x1
    9614:	d2800001 	mov	x1, #0x0                   	// #0
    9618:	54002f81 	b.ne	9c08 <fwp_hof0.constprop.0+0x1af8>  // b.any
    961c:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    9620:	d2800000 	mov	x0, #0x0                   	// #0
    9624:	910543ff 	add	sp, sp, #0x150
    9628:	d65f03c0 	ret
    962c:	b5ff7fb7 	cbnz	x23, 8620 <fwp_hof0.constprop.0+0x510>
    9630:	d280001c 	mov	x28, #0x0                   	// #0
    9634:	17fffc22 	b	86bc <fwp_hof0.constprop.0+0x5ac>
    9638:	72003c3f 	tst	w1, #0xffff
    963c:	54ff88a1 	b.ne	8750 <fwp_hof0.constprop.0+0x640>  // b.any
    9640:	17fffc3c 	b	8730 <fwp_hof0.constprop.0+0x620>
    9644:	72003c7f 	tst	w3, #0xffff
    9648:	54ffda61 	b.ne	9194 <fwp_hof0.constprop.0+0x1084>  // b.any
    964c:	17fffe78 	b	902c <fwp_hof0.constprop.0+0xf1c>
    9650:	f940077b 	ldr	x27, [x27, #8]
    9654:	eb02007f 	cmp	x3, x2
    9658:	540003a9 	b.ls	96cc <fwp_hof0.constprop.0+0x15bc>  // b.plast
    965c:	d350fc46 	lsr	x6, x2, #16
    9660:	8b0608c6 	add	x6, x6, x6, lsl #2
    9664:	d37df0c6 	lsl	x6, x6, #3
    9668:	8b060088 	add	x8, x4, x6
    966c:	f9401107 	ldr	x7, [x8, #32]
    9670:	b40002e7 	cbz	x7, 96cc <fwp_hof0.constprop.0+0x15bc>
    9674:	38666884 	ldrb	w4, [x4, x6]
    9678:	7100089f 	cmp	w4, #0x2
    967c:	540014a0 	b.eq	9910 <fwp_hof0.constprop.0+0x1800>  // b.none
    9680:	7100049f 	cmp	w4, #0x1
    9684:	54000241 	b.ne	96cc <fwp_hof0.constprop.0+0x15bc>  // b.any
    9688:	29431106 	ldp	w6, w4, [x8, #24]
    968c:	92403c42 	and	x2, x2, #0xffff
    9690:	9b067c42 	mul	x2, x2, x6
    9694:	d360fc42 	lsr	x2, x2, #32
    9698:	eb04005f 	cmp	x2, x4
    969c:	54000182 	b.cs	96cc <fwp_hof0.constprop.0+0x15bc>  // b.hs, b.nlast
    96a0:	8b0200e7 	add	x7, x7, x2
    96a4:	394000e2 	ldrb	w2, [x7]
    96a8:	7100045f 	cmp	w2, #0x1
    96ac:	54000101 	b.ne	96cc <fwp_hof0.constprop.0+0x15bc>  // b.any
    96b0:	f90003e5 	str	x5, [sp]
    96b4:	97ffed0f 	bl	4af0 <fwp_mem_free>
    96b8:	91174280 	add	x0, x20, #0x5d0
    96bc:	f94003e5 	ldr	x5, [sp]
    96c0:	f949ec03 	ldr	x3, [x0, #5080]
    96c4:	f949d801 	ldr	x1, [x0, #5040]
    96c8:	d370bc63 	lsl	x3, x3, #16
    96cc:	cb010361 	sub	x1, x27, x1
    96d0:	eb03003f 	cmp	x1, x3
    96d4:	54ff8083 	b.cc	86e4 <fwp_hof0.constprop.0+0x5d4>  // b.lo, b.ul, b.last
    96d8:	17fffc1e 	b	8750 <fwp_hof0.constprop.0+0x640>
    96dc:	72003c3f 	tst	w1, #0xffff
    96e0:	54ffd001 	b.ne	90e0 <fwp_hof0.constprop.0+0xfd0>  // b.any
    96e4:	17fffe76 	b	90bc <fwp_hof0.constprop.0+0xfac>
    96e8:	f9400483 	ldr	x3, [x4, #8]
    96ec:	f90003e3 	str	x3, [sp]
    96f0:	eb0200ff 	cmp	x7, x2
    96f4:	54000362 	b.cs	9760 <fwp_hof0.constprop.0+0x1650>  // b.hs, b.nlast
    96f8:	d350fce3 	lsr	x3, x7, #16
    96fc:	8b030863 	add	x3, x3, x3, lsl #2
    9700:	d37df063 	lsl	x3, x3, #3
    9704:	8b0300a6 	add	x6, x5, x3
    9708:	f94010c4 	ldr	x4, [x6, #32]
    970c:	b40002a4 	cbz	x4, 9760 <fwp_hof0.constprop.0+0x1650>
    9710:	386368a3 	ldrb	w3, [x5, x3]
    9714:	7100087f 	cmp	w3, #0x2
    9718:	54001020 	b.eq	991c <fwp_hof0.constprop.0+0x180c>  // b.none
    971c:	7100047f 	cmp	w3, #0x1
    9720:	54000201 	b.ne	9760 <fwp_hof0.constprop.0+0x1650>  // b.any
    9724:	294314c8 	ldp	w8, w5, [x6, #24]
    9728:	92403ce3 	and	x3, x7, #0xffff
    972c:	9b087c63 	mul	x3, x3, x8
    9730:	d360fc63 	lsr	x3, x3, #32
    9734:	eb05007f 	cmp	x3, x5
    9738:	54000142 	b.cs	9760 <fwp_hof0.constprop.0+0x1650>  // b.hs, b.nlast
    973c:	8b030084 	add	x4, x4, x3
    9740:	39400083 	ldrb	w3, [x4]
    9744:	7100047f 	cmp	w3, #0x1
    9748:	540000c1 	b.ne	9760 <fwp_hof0.constprop.0+0x1650>  // b.any
    974c:	97ffece9 	bl	4af0 <fwp_mem_free>
    9750:	91174280 	add	x0, x20, #0x5d0
    9754:	f949ec02 	ldr	x2, [x0, #5080]
    9758:	f949d801 	ldr	x1, [x0, #5040]
    975c:	d370bc42 	lsl	x2, x2, #16
    9760:	f94003e0 	ldr	x0, [sp]
    9764:	cb010003 	sub	x3, x0, x1
    9768:	eb03005f 	cmp	x2, x3
    976c:	54ffc3a8 	b.hi	8fe0 <fwp_hof0.constprop.0+0xed0>  // b.pmore
    9770:	17fffe3c 	b	9060 <fwp_hof0.constprop.0+0xf50>
    9774:	f94017e0 	ldr	x0, [sp, #40]
    9778:	97ffe8ca 	bl	3aa0 <fwp_closure_drop.part.0>
    977c:	17fffaf7 	b	8358 <fwp_hof0.constprop.0+0x248>
    9780:	72003c3f 	tst	w1, #0xffff
    9784:	54ff74c1 	b.ne	861c <fwp_hof0.constprop.0+0x50c>  // b.any
    9788:	39400380 	ldrb	w0, [x28]
    978c:	7103fc1f 	cmp	w0, #0xff
    9790:	54ff7421 	b.ne	8614 <fwp_hof0.constprop.0+0x504>  // b.any
    9794:	aa1c03e0 	mov	x0, x28
    9798:	97ffec36 	bl	4870 <fwp_rc_forget_slot>
    979c:	17fffb9e 	b	8614 <fwp_hof0.constprop.0+0x504>
    97a0:	72003c3f 	tst	w1, #0xffff
    97a4:	54ff5b01 	b.ne	8304 <fwp_hof0.constprop.0+0x1f4>  // b.any
    97a8:	aa1303e0 	mov	x0, x19
    97ac:	17fffac3 	b	82b8 <fwp_hof0.constprop.0+0x1a8>
    97b0:	72003c3f 	tst	w1, #0xffff
    97b4:	54ff5d21 	b.ne	8358 <fwp_hof0.constprop.0+0x248>  // b.any
    97b8:	17fffadf 	b	8334 <fwp_hof0.constprop.0+0x224>
    97bc:	aa1903fc 	mov	x28, x25
    97c0:	17fffc1a 	b	8828 <fwp_hof0.constprop.0+0x718>
    97c4:	72003c3f 	tst	w1, #0xffff
    97c8:	54ff9301 	b.ne	8a28 <fwp_hof0.constprop.0+0x918>  // b.any
    97cc:	394002e0 	ldrb	w0, [x23]
    97d0:	7103fc1f 	cmp	w0, #0xff
    97d4:	54ff9261 	b.ne	8a20 <fwp_hof0.constprop.0+0x910>  // b.any
    97d8:	aa1703e0 	mov	x0, x23
    97dc:	97ffec25 	bl	4870 <fwp_rc_forget_slot>
    97e0:	17fffc90 	b	8a20 <fwp_hof0.constprop.0+0x910>
    97e4:	72003c5f 	tst	w2, #0xffff
    97e8:	54ff7b41 	b.ne	8750 <fwp_hof0.constprop.0+0x640>  // b.any
    97ec:	17fffd04 	b	8bfc <fwp_hof0.constprop.0+0xaec>
    97f0:	91174280 	add	x0, x20, #0x5d0
    97f4:	f9400ad3 	ldr	x19, [x22, #16]
    97f8:	f949ec04 	ldr	x4, [x0, #5080]
    97fc:	f949d801 	ldr	x1, [x0, #5040]
    9800:	d370bc84 	lsl	x4, x4, #16
    9804:	cb0102c0 	sub	x0, x22, x1
    9808:	eb04001f 	cmp	x0, x4
    980c:	54000382 	b.cs	987c <fwp_hof0.constprop.0+0x176c>  // b.hs, b.nlast
    9810:	d350fc02 	lsr	x2, x0, #16
    9814:	8b020842 	add	x2, x2, x2, lsl #2
    9818:	d37df042 	lsl	x2, x2, #3
    981c:	8b020066 	add	x6, x3, x2
    9820:	f94010c5 	ldr	x5, [x6, #32]
    9824:	b40002c5 	cbz	x5, 987c <fwp_hof0.constprop.0+0x176c>
    9828:	38626862 	ldrb	w2, [x3, x2]
    982c:	7100085f 	cmp	w2, #0x2
    9830:	54000820 	b.eq	9934 <fwp_hof0.constprop.0+0x1824>  // b.none
    9834:	7100045f 	cmp	w2, #0x1
    9838:	54000221 	b.ne	987c <fwp_hof0.constprop.0+0x176c>  // b.any
    983c:	294308c3 	ldp	w3, w2, [x6, #24]
    9840:	92403c00 	and	x0, x0, #0xffff
    9844:	9b037c00 	mul	x0, x0, x3
    9848:	d360fc00 	lsr	x0, x0, #32
    984c:	eb02001f 	cmp	x0, x2
    9850:	54000162 	b.cs	987c <fwp_hof0.constprop.0+0x176c>  // b.hs, b.nlast
    9854:	8b0000a5 	add	x5, x5, x0
    9858:	394000a0 	ldrb	w0, [x5]
    985c:	7100041f 	cmp	w0, #0x1
    9860:	540000e1 	b.ne	987c <fwp_hof0.constprop.0+0x176c>  // b.any
    9864:	aa1603e0 	mov	x0, x22
    9868:	97ffeca2 	bl	4af0 <fwp_mem_free>
    986c:	91174280 	add	x0, x20, #0x5d0
    9870:	f949ec04 	ldr	x4, [x0, #5080]
    9874:	f949d801 	ldr	x1, [x0, #5040]
    9878:	d370bc84 	lsl	x4, x4, #16
    987c:	cb010261 	sub	x1, x19, x1
    9880:	eb01009f 	cmp	x4, x1
    9884:	54ffc2e9 	b.ls	90e0 <fwp_hof0.constprop.0+0xfd0>  // b.plast
    9888:	aa1303f6 	mov	x22, x19
    988c:	17fffdf9 	b	9070 <fwp_hof0.constprop.0+0xf60>
    9890:	72003cff 	tst	w7, #0xffff
    9894:	54ffbe61 	b.ne	9060 <fwp_hof0.constprop.0+0xf50>  // b.any
    9898:	17fffe3a 	b	9180 <fwp_hof0.constprop.0+0x1070>
    989c:	72003c3f 	tst	w1, #0xffff
    98a0:	54ffd8e0 	b.eq	93bc <fwp_hof0.constprop.0+0x12ac>  // b.none
    98a4:	aa1303e0 	mov	x0, x19
    98a8:	17fffc8a 	b	8ad0 <fwp_hof0.constprop.0+0x9c0>
    98ac:	aa1703e0 	mov	x0, x23
    98b0:	97ffebf0 	bl	4870 <fwp_rc_forget_slot>
    98b4:	17fffec5 	b	93c8 <fwp_hof0.constprop.0+0x12b8>
    98b8:	aa0203e0 	mov	x0, x2
    98bc:	d2800101 	mov	x1, #0x8                   	// #8
    98c0:	f90003e2 	str	x2, [sp]
    98c4:	97ffe40b 	bl	28f0 <calloc@plt>
    98c8:	f94003e2 	ldr	x2, [sp]
    98cc:	aa0003fa 	mov	x26, x0
    98d0:	f9401be5 	ldr	x5, [sp, #48]
    98d4:	17fffbe9 	b	8878 <fwp_hof0.constprop.0+0x768>
    98d8:	d2800d01 	mov	x1, #0x68                  	// #104
    98dc:	d280003c 	mov	x28, #0x1                   	// #1
    98e0:	17fffad1 	b	8424 <fwp_hof0.constprop.0+0x314>
    98e4:	f9400360 	ldr	x0, [x27]
    98e8:	b7ffd780 	tbnz	x0, #63, 93d8 <fwp_hof0.constprop.0+0x12c8>
    98ec:	91174283 	add	x3, x20, #0x5d0
    98f0:	f94003e4 	ldr	x4, [sp]
    98f4:	f949d861 	ldr	x1, [x3, #5040]
    98f8:	f949ec63 	ldr	x3, [x3, #5080]
    98fc:	cb010081 	sub	x1, x4, x1
    9900:	eb03403f 	cmp	x1, x3, lsl #16
    9904:	54ffd6a2 	b.cs	93d8 <fwp_hof0.constprop.0+0x12c8>  // b.hs, b.nlast
    9908:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    990c:	17fffcd6 	b	8c64 <fwp_hof0.constprop.0+0xb54>
    9910:	72003c5f 	tst	w2, #0xffff
    9914:	54ffedc1 	b.ne	96cc <fwp_hof0.constprop.0+0x15bc>  // b.any
    9918:	17ffff63 	b	96a4 <fwp_hof0.constprop.0+0x1594>
    991c:	72003cff 	tst	w7, #0xffff
    9920:	54fff201 	b.ne	9760 <fwp_hof0.constprop.0+0x1650>  // b.any
    9924:	17ffff87 	b	9740 <fwp_hof0.constprop.0+0x1630>
    9928:	aa1303e0 	mov	x0, x19
    992c:	97ffef92 	bl	5774 <fwp_rc_free_arr>
    9930:	17ffff2a 	b	95d8 <fwp_hof0.constprop.0+0x14c8>
    9934:	72003c1f 	tst	w0, #0xffff
    9938:	54fffa21 	b.ne	987c <fwp_hof0.constprop.0+0x176c>  // b.any
    993c:	17ffffc7 	b	9858 <fwp_hof0.constprop.0+0x1748>
    9940:	72003c9f 	tst	w4, #0xffff
    9944:	54ff46c1 	b.ne	821c <fwp_hof0.constprop.0+0x10c>  // b.any
    9948:	17fffa2a 	b	81f0 <fwp_hof0.constprop.0+0xe0>
    994c:	ca584700 	eor	x0, x24, x24, lsr #17
    9950:	91174281 	add	x1, x20, #0x5d0
    9954:	ca402400 	eor	x0, x0, x0, lsr #9
    9958:	8b200c20 	add	x0, x1, w0, uxtb #3
    995c:	f94a2400 	ldr	x0, [x0, #5192]
    9960:	b5000080 	cbnz	x0, 9970 <fwp_hof0.constprop.0+0x1860>
    9964:	14000012 	b	99ac <fwp_hof0.constprop.0+0x189c>
    9968:	f9400800 	ldr	x0, [x0, #16]
    996c:	b4000200 	cbz	x0, 99ac <fwp_hof0.constprop.0+0x189c>
    9970:	f9400001 	ldr	x1, [x0]
    9974:	eb18003f 	cmp	x1, x24
    9978:	54ffff81 	b.ne	9968 <fwp_hof0.constprop.0+0x1858>  // b.any
    997c:	f9400401 	ldr	x1, [x0, #8]
    9980:	d1000421 	sub	x1, x1, #0x1
    9984:	f9000401 	str	x1, [x0, #8]
    9988:	f103f83f 	cmp	x1, #0xfe
    998c:	54ff6e21 	b.ne	8750 <fwp_hof0.constprop.0+0x640>  // b.any
    9990:	aa1803e0 	mov	x0, x24
    9994:	f90003e5 	str	x5, [sp]
    9998:	97ffebb6 	bl	4870 <fwp_rc_forget_slot>
    999c:	f94003e5 	ldr	x5, [sp]
    99a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    99a4:	39000300 	strb	w0, [x24]
    99a8:	17fffb6a 	b	8750 <fwp_hof0.constprop.0+0x640>
    99ac:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    99b0:	910a8000 	add	x0, x0, #0x2a0
    99b4:	97ffe7b3 	bl	3880 <fwp_trap>
    99b8:	ca584700 	eor	x0, x24, x24, lsr #17
    99bc:	91174281 	add	x1, x20, #0x5d0
    99c0:	ca402400 	eor	x0, x0, x0, lsr #9
    99c4:	8b200c20 	add	x0, x1, w0, uxtb #3
    99c8:	f94a2401 	ldr	x1, [x0, #5192]
    99cc:	b5000081 	cbnz	x1, 99dc <fwp_hof0.constprop.0+0x18cc>
    99d0:	17fffff7 	b	99ac <fwp_hof0.constprop.0+0x189c>
    99d4:	f9400821 	ldr	x1, [x1, #16]
    99d8:	b4fffea1 	cbz	x1, 99ac <fwp_hof0.constprop.0+0x189c>
    99dc:	f9400020 	ldr	x0, [x1]
    99e0:	eb18001f 	cmp	x0, x24
    99e4:	54ffff81 	b.ne	99d4 <fwp_hof0.constprop.0+0x18c4>  // b.any
    99e8:	f9400420 	ldr	x0, [x1, #8]
    99ec:	d1000400 	sub	x0, x0, #0x1
    99f0:	f9000420 	str	x0, [x1, #8]
    99f4:	f103f81f 	cmp	x0, #0xfe
    99f8:	54ffbce1 	b.ne	9194 <fwp_hof0.constprop.0+0x1084>  // b.any
    99fc:	aa1803e0 	mov	x0, x24
    9a00:	97ffeb9c 	bl	4870 <fwp_rc_forget_slot>
    9a04:	91174280 	add	x0, x20, #0x5d0
    9a08:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9a0c:	39000301 	strb	w1, [x24]
    9a10:	f949ec02 	ldr	x2, [x0, #5080]
    9a14:	f949d801 	ldr	x1, [x0, #5040]
    9a18:	d370bc42 	lsl	x2, x2, #16
    9a1c:	17fffd91 	b	9060 <fwp_hof0.constprop.0+0xf50>
    9a20:	ca534660 	eor	x0, x19, x19, lsr #17
    9a24:	91174281 	add	x1, x20, #0x5d0
    9a28:	ca402400 	eor	x0, x0, x0, lsr #9
    9a2c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9a30:	f94a2400 	ldr	x0, [x0, #5192]
    9a34:	b5000080 	cbnz	x0, 9a44 <fwp_hof0.constprop.0+0x1934>
    9a38:	17ffffdd 	b	99ac <fwp_hof0.constprop.0+0x189c>
    9a3c:	f9400800 	ldr	x0, [x0, #16]
    9a40:	b4fffb60 	cbz	x0, 99ac <fwp_hof0.constprop.0+0x189c>
    9a44:	f9400001 	ldr	x1, [x0]
    9a48:	eb01027f 	cmp	x19, x1
    9a4c:	54ffff81 	b.ne	9a3c <fwp_hof0.constprop.0+0x192c>  // b.any
    9a50:	f9400401 	ldr	x1, [x0, #8]
    9a54:	d1000421 	sub	x1, x1, #0x1
    9a58:	f9000401 	str	x1, [x0, #8]
    9a5c:	f103f83f 	cmp	x1, #0xfe
    9a60:	54ffb401 	b.ne	90e0 <fwp_hof0.constprop.0+0xfd0>  // b.any
    9a64:	aa1303e0 	mov	x0, x19
    9a68:	97ffeb82 	bl	4870 <fwp_rc_forget_slot>
    9a6c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9a70:	39000260 	strb	w0, [x19]
    9a74:	17fffd9b 	b	90e0 <fwp_hof0.constprop.0+0xfd0>
    9a78:	72003c5f 	tst	w2, #0xffff
    9a7c:	54ffdae1 	b.ne	95d8 <fwp_hof0.constprop.0+0x14c8>  // b.any
    9a80:	17fffece 	b	95b8 <fwp_hof0.constprop.0+0x14a8>
    9a84:	72003c5f 	tst	w2, #0xffff
    9a88:	54ffd501 	b.ne	9528 <fwp_hof0.constprop.0+0x1418>  // b.any
    9a8c:	394002c0 	ldrb	w0, [x22]
    9a90:	7103fc1f 	cmp	w0, #0xff
    9a94:	54ffd461 	b.ne	9520 <fwp_hof0.constprop.0+0x1410>  // b.any
    9a98:	aa1603e0 	mov	x0, x22
    9a9c:	97ffeb75 	bl	4870 <fwp_rc_forget_slot>
    9aa0:	17fffea0 	b	9520 <fwp_hof0.constprop.0+0x1410>
    9aa4:	d280001c 	mov	x28, #0x0                   	// #0
    9aa8:	d280001b 	mov	x27, #0x0                   	// #0
    9aac:	17fffd43 	b	8fb8 <fwp_hof0.constprop.0+0xea8>
    9ab0:	ca534660 	eor	x0, x19, x19, lsr #17
    9ab4:	91174281 	add	x1, x20, #0x5d0
    9ab8:	ca402400 	eor	x0, x0, x0, lsr #9
    9abc:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ac0:	f94a2400 	ldr	x0, [x0, #5192]
    9ac4:	b5000080 	cbnz	x0, 9ad4 <fwp_hof0.constprop.0+0x19c4>
    9ac8:	17ffffb9 	b	99ac <fwp_hof0.constprop.0+0x189c>
    9acc:	f9400800 	ldr	x0, [x0, #16]
    9ad0:	b4fff6e0 	cbz	x0, 99ac <fwp_hof0.constprop.0+0x189c>
    9ad4:	f9400001 	ldr	x1, [x0]
    9ad8:	eb13003f 	cmp	x1, x19
    9adc:	54ffff81 	b.ne	9acc <fwp_hof0.constprop.0+0x19bc>  // b.any
    9ae0:	f9400401 	ldr	x1, [x0, #8]
    9ae4:	d1000421 	sub	x1, x1, #0x1
    9ae8:	f9000401 	str	x1, [x0, #8]
    9aec:	f103f83f 	cmp	x1, #0xfe
    9af0:	54ff4341 	b.ne	8358 <fwp_hof0.constprop.0+0x248>  // b.any
    9af4:	aa1303e0 	mov	x0, x19
    9af8:	97ffeb5e 	bl	4870 <fwp_rc_forget_slot>
    9afc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b00:	39000260 	strb	w0, [x19]
    9b04:	17fffa15 	b	8358 <fwp_hof0.constprop.0+0x248>
    9b08:	97ffeb13 	bl	4754 <fwp_rc_wide_dup>
    9b0c:	17fff9f1 	b	82d0 <fwp_hof0.constprop.0+0x1c0>
    9b10:	d2800018 	mov	x24, #0x0                   	// #0
    9b14:	17fffcb3 	b	8de0 <fwp_hof0.constprop.0+0xcd0>
    9b18:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9b1c:	910e0000 	add	x0, x0, #0x380
    9b20:	97ffe758 	bl	3880 <fwp_trap>
    9b24:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9b28:	910ba000 	add	x0, x0, #0x2e8
    9b2c:	97ffe755 	bl	3880 <fwp_trap>
    9b30:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9b34:	91174281 	add	x1, x20, #0x5d0
    9b38:	ca402400 	eor	x0, x0, x0, lsr #9
    9b3c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9b40:	f94a2400 	ldr	x0, [x0, #5192]
    9b44:	b5000080 	cbnz	x0, 9b54 <fwp_hof0.constprop.0+0x1a44>
    9b48:	17ffff99 	b	99ac <fwp_hof0.constprop.0+0x189c>
    9b4c:	f9400800 	ldr	x0, [x0, #16]
    9b50:	b4fff2e0 	cbz	x0, 99ac <fwp_hof0.constprop.0+0x189c>
    9b54:	f9400001 	ldr	x1, [x0]
    9b58:	eb16003f 	cmp	x1, x22
    9b5c:	54ffff81 	b.ne	9b4c <fwp_hof0.constprop.0+0x1a3c>  // b.any
    9b60:	f9400401 	ldr	x1, [x0, #8]
    9b64:	d1000421 	sub	x1, x1, #0x1
    9b68:	f9000401 	str	x1, [x0, #8]
    9b6c:	f103f83f 	cmp	x1, #0xfe
    9b70:	54ffd341 	b.ne	95d8 <fwp_hof0.constprop.0+0x14c8>  // b.any
    9b74:	aa1603e0 	mov	x0, x22
    9b78:	97ffeb3e 	bl	4870 <fwp_rc_forget_slot>
    9b7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b80:	390002c0 	strb	w0, [x22]
    9b84:	17fffe95 	b	95d8 <fwp_hof0.constprop.0+0x14c8>
    9b88:	97ffeaf3 	bl	4754 <fwp_rc_wide_dup>
    9b8c:	91174280 	add	x0, x20, #0x5d0
    9b90:	f949ec03 	ldr	x3, [x0, #5080]
    9b94:	f949d801 	ldr	x1, [x0, #5040]
    9b98:	d370bc63 	lsl	x3, x3, #16
    9b9c:	17fff9a0 	b	821c <fwp_hof0.constprop.0+0x10c>
    9ba0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9ba4:	91150000 	add	x0, x0, #0x540
    9ba8:	97ffe736 	bl	3880 <fwp_trap>
    9bac:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9bb0:	910f8000 	add	x0, x0, #0x3e0
    9bb4:	97ffe733 	bl	3880 <fwp_trap>
    9bb8:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9bbc:	910cc000 	add	x0, x0, #0x330
    9bc0:	97ffe730 	bl	3880 <fwp_trap>
    9bc4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9bc8:	9115a000 	add	x0, x0, #0x568
    9bcc:	97ffe72d 	bl	3880 <fwp_trap>
    9bd0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9bd4:	9114c000 	add	x0, x0, #0x530
    9bd8:	97ffe72a 	bl	3880 <fwp_trap>
    9bdc:	52800020 	mov	w0, #0x1                   	// #1
    9be0:	17fffbd8 	b	8b40 <fwp_hof0.constprop.0+0xa30>
    9be4:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9be8:	91140000 	add	x0, x0, #0x500
    9bec:	97ffe725 	bl	3880 <fwp_trap>
    9bf0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9bf4:	91138000 	add	x0, x0, #0x4e0
    9bf8:	97ffe722 	bl	3880 <fwp_trap>
    9bfc:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9c00:	91160000 	add	x0, x0, #0x580
    9c04:	97ffe71f 	bl	3880 <fwp_trap>
    9c08:	a90f53f3 	stp	x19, x20, [sp, #240]
    9c0c:	a9105bf5 	stp	x21, x22, [sp, #256]
    9c10:	a91163f7 	stp	x23, x24, [sp, #272]
    9c14:	a9126bf9 	stp	x25, x26, [sp, #288]
    9c18:	a91373fb 	stp	x27, x28, [sp, #304]
    9c1c:	fd00a3e8 	str	d8, [sp, #320]
    9c20:	97ffe33c 	bl	2910 <__stack_chk_fail@plt>
    9c24:	97ffe3b7 	bl	2b00 <fwp_trap_overflow.constprop.0>
    9c28:	97ffe34e 	bl	2960 <abort@plt>
    9c2c:	d503201f 	nop

0000000000009c30 <f0>:
    9c30:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9c34:	910003fd 	mov	x29, sp
    9c38:	a90153f3 	stp	x19, x20, [sp, #16]
    9c3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9c40:	a90363f7 	stp	x23, x24, [sp, #48]
    9c44:	a9046bf9 	stp	x25, x26, [sp, #64]
    9c48:	a90573fb 	stp	x27, x28, [sp, #80]
    9c4c:	d12183ff 	sub	sp, sp, #0x860
    9c50:	f90203ff 	str	xzr, [sp, #1024]
    9c54:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c58:	9101c005 	add	x5, x0, #0x70
    9c5c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9c60:	f947f400 	ldr	x0, [x0, #4072]
    9c64:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    9c68:	f94188a6 	ldr	x6, [x5, #784]
    9c6c:	f9400001 	ldr	x1, [x0]
    9c70:	f9042fe1 	str	x1, [sp, #2136]
    9c74:	d2800001 	mov	x1, #0x0                   	// #0
    9c78:	91174298 	add	x24, x20, #0x5d0
    9c7c:	912123f6 	add	x22, sp, #0x848
    9c80:	910023e0 	add	x0, sp, #0x8
    9c84:	910083e2 	add	x2, sp, #0x20
    9c88:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    9c8c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9c90:	91308021 	add	x1, x1, #0xc20
    9c94:	913f4084 	add	x4, x4, #0xfd0
    9c98:	d2800013 	mov	x19, #0x0                   	// #0
    9c9c:	d2800119 	mov	x25, #0x8                   	// #8
    9ca0:	d2800015 	mov	x21, #0x0                   	// #0
    9ca4:	52800037 	mov	w23, #0x1                   	// #1
    9ca8:	a90093e6 	stp	x6, x4, [sp, #8]
    9cac:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9cb0:	a90307ff 	stp	xzr, x1, [sp, #48]
    9cb4:	f90188a0 	str	x0, [x5, #784]
    9cb8:	f100073a 	subs	x26, x25, #0x1
    9cbc:	aa1603e1 	mov	x1, x22
    9cc0:	da1f02bc 	sbc	x28, x21, xzr
    9cc4:	52800020 	mov	w0, #0x1                   	// #1
    9cc8:	f90017fa 	str	x26, [sp, #40]
    9ccc:	aa1a03f9 	mov	x25, x26
    9cd0:	f90427fa 	str	x26, [sp, #2120]
    9cd4:	aa1c03f5 	mov	x21, x28
    9cd8:	f9042bf3 	str	x19, [sp, #2128]
    9cdc:	97ffecea 	bl	5084 <fwp_data.part.0.constprop.0>
    9ce0:	f949db02 	ldr	x2, [x24, #5040]
    9ce4:	aa0003f3 	mov	x19, x0
    9ce8:	f949ef00 	ldr	x0, [x24, #5080]
    9cec:	cb020262 	sub	x2, x19, x2
    9cf0:	eb00405f 	cmp	x2, x0, lsl #16
    9cf4:	54000302 	b.cs	9d54 <f0+0x124>  // b.hs, b.nlast
    9cf8:	d350fc40 	lsr	x0, x2, #16
    9cfc:	f949ff04 	ldr	x4, [x24, #5112]
    9d00:	8b000800 	add	x0, x0, x0, lsl #2
    9d04:	d37df001 	lsl	x1, x0, #3
    9d08:	8b010080 	add	x0, x4, x1
    9d0c:	f940101b 	ldr	x27, [x0, #32]
    9d10:	b400023b 	cbz	x27, 9d54 <f0+0x124>
    9d14:	38616881 	ldrb	w1, [x4, x1]
    9d18:	7100083f 	cmp	w1, #0x2
    9d1c:	54010e20 	b.eq	bee0 <f0+0x22b0>  // b.none
    9d20:	7100043f 	cmp	w1, #0x1
    9d24:	54000181 	b.ne	9d54 <f0+0x124>  // b.any
    9d28:	29430001 	ldp	w1, w0, [x0, #24]
    9d2c:	92403c42 	and	x2, x2, #0xffff
    9d30:	9b017c42 	mul	x2, x2, x1
    9d34:	d360fc42 	lsr	x2, x2, #32
    9d38:	eb00005f 	cmp	x2, x0
    9d3c:	540000c2 	b.cs	9d54 <f0+0x124>  // b.hs, b.nlast
    9d40:	8b02037b 	add	x27, x27, x2
    9d44:	39400360 	ldrb	w0, [x27]
    9d48:	7103fc1f 	cmp	w0, #0xff
    9d4c:	54010c40 	b.eq	bed4 <f0+0x22a4>  // b.none
    9d50:	39000377 	strb	w23, [x27]
    9d54:	f90013f3 	str	x19, [sp, #32]
    9d58:	aa1c035a 	orr	x26, x26, x28
    9d5c:	b5fffafa 	cbnz	x26, 9cb8 <f0+0x88>
    9d60:	90000020 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    9d64:	910103e1 	add	x1, sp, #0x40
    9d68:	f94007e2 	ldr	x2, [sp, #8]
    9d6c:	3dc35000 	ldr	q0, [x0, #3392]
    9d70:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d74:	9101c018 	add	x24, x0, #0x70
    9d78:	52800020 	mov	w0, #0x1                   	// #1
    9d7c:	3d8013e0 	str	q0, [sp, #64]
    9d80:	f9018b02 	str	x2, [x24, #784]
    9d84:	97ffecc0 	bl	5084 <fwp_data.part.0.constprop.0>
    9d88:	97ffee4b 	bl	56b4 <fwp_rc_fresh>
    9d8c:	aa0003e2 	mov	x2, x0
    9d90:	910163e1 	add	x1, sp, #0x58
    9d94:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9d98:	52800020 	mov	w0, #0x1                   	// #1
    9d9c:	a9058be3 	stp	x3, x2, [sp, #88]
    9da0:	97ffecb9 	bl	5084 <fwp_data.part.0.constprop.0>
    9da4:	97ffee44 	bl	56b4 <fwp_rc_fresh>
    9da8:	aa0003e2 	mov	x2, x0
    9dac:	90000023 	adrp	x3, d000 <_IO_stdin_used+0xc0>
    9db0:	9101a3e1 	add	x1, sp, #0x68
    9db4:	52800020 	mov	w0, #0x1                   	// #1
    9db8:	f9003be2 	str	x2, [sp, #112]
    9dbc:	3dc35060 	ldr	q0, [x3, #3392]
    9dc0:	fd0037e0 	str	d0, [sp, #104]
    9dc4:	97ffecb0 	bl	5084 <fwp_data.part.0.constprop.0>
    9dc8:	91174283 	add	x3, x20, #0x5d0
    9dcc:	aa0003f5 	mov	x21, x0
    9dd0:	f949d861 	ldr	x1, [x3, #5040]
    9dd4:	f949ec60 	ldr	x0, [x3, #5080]
    9dd8:	cb0102a1 	sub	x1, x21, x1
    9ddc:	eb00403f 	cmp	x1, x0, lsl #16
    9de0:	54000322 	b.cs	9e44 <f0+0x214>  // b.hs, b.nlast
    9de4:	d350fc22 	lsr	x2, x1, #16
    9de8:	f949fc63 	ldr	x3, [x3, #5112]
    9dec:	8b020842 	add	x2, x2, x2, lsl #2
    9df0:	d37df042 	lsl	x2, x2, #3
    9df4:	8b020060 	add	x0, x3, x2
    9df8:	f9401017 	ldr	x23, [x0, #32]
    9dfc:	b4000257 	cbz	x23, 9e44 <f0+0x214>
    9e00:	38626862 	ldrb	w2, [x3, x2]
    9e04:	7100085f 	cmp	w2, #0x2
    9e08:	54010ae0 	b.eq	bf64 <f0+0x2334>  // b.none
    9e0c:	7100045f 	cmp	w2, #0x1
    9e10:	540001a1 	b.ne	9e44 <f0+0x214>  // b.any
    9e14:	29430002 	ldp	w2, w0, [x0, #24]
    9e18:	92403c21 	and	x1, x1, #0xffff
    9e1c:	9b027c21 	mul	x1, x1, x2
    9e20:	d360fc21 	lsr	x1, x1, #32
    9e24:	eb00003f 	cmp	x1, x0
    9e28:	540000e2 	b.cs	9e44 <f0+0x214>  // b.hs, b.nlast
    9e2c:	8b0102f7 	add	x23, x23, x1
    9e30:	394002e0 	ldrb	w0, [x23]
    9e34:	7103fc1f 	cmp	w0, #0xff
    9e38:	540114a0 	b.eq	c0cc <f0+0x249c>  // b.none
    9e3c:	52800020 	mov	w0, #0x1                   	// #1
    9e40:	390002e0 	strb	w0, [x23]
    9e44:	9101e3e1 	add	x1, sp, #0x78
    9e48:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9e4c:	52800020 	mov	w0, #0x1                   	// #1
    9e50:	a907d7e2 	stp	x2, x21, [sp, #120]
    9e54:	97ffec8c 	bl	5084 <fwp_data.part.0.constprop.0>
    9e58:	97ffee17 	bl	56b4 <fwp_rc_fresh>
    9e5c:	aa0003e2 	mov	x2, x0
    9e60:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9e64:	910223e1 	add	x1, sp, #0x88
    9e68:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9e6c:	52800020 	mov	w0, #0x1                   	// #1
    9e70:	a9088be3 	stp	x3, x2, [sp, #136]
    9e74:	97ffec84 	bl	5084 <fwp_data.part.0.constprop.0>
    9e78:	91174283 	add	x3, x20, #0x5d0
    9e7c:	aa0003f7 	mov	x23, x0
    9e80:	f949d861 	ldr	x1, [x3, #5040]
    9e84:	f949ec60 	ldr	x0, [x3, #5080]
    9e88:	cb0102e1 	sub	x1, x23, x1
    9e8c:	eb00403f 	cmp	x1, x0, lsl #16
    9e90:	54000322 	b.cs	9ef4 <f0+0x2c4>  // b.hs, b.nlast
    9e94:	d350fc22 	lsr	x2, x1, #16
    9e98:	f949fc63 	ldr	x3, [x3, #5112]
    9e9c:	8b020842 	add	x2, x2, x2, lsl #2
    9ea0:	d37df042 	lsl	x2, x2, #3
    9ea4:	8b020060 	add	x0, x3, x2
    9ea8:	f9401015 	ldr	x21, [x0, #32]
    9eac:	b4000255 	cbz	x21, 9ef4 <f0+0x2c4>
    9eb0:	38626862 	ldrb	w2, [x3, x2]
    9eb4:	7100085f 	cmp	w2, #0x2
    9eb8:	54010500 	b.eq	bf58 <f0+0x2328>  // b.none
    9ebc:	7100045f 	cmp	w2, #0x1
    9ec0:	540001a1 	b.ne	9ef4 <f0+0x2c4>  // b.any
    9ec4:	29430002 	ldp	w2, w0, [x0, #24]
    9ec8:	92403c21 	and	x1, x1, #0xffff
    9ecc:	9b027c21 	mul	x1, x1, x2
    9ed0:	d360fc21 	lsr	x1, x1, #32
    9ed4:	eb00003f 	cmp	x1, x0
    9ed8:	540000e2 	b.cs	9ef4 <f0+0x2c4>  // b.hs, b.nlast
    9edc:	8b0102b5 	add	x21, x21, x1
    9ee0:	394002a0 	ldrb	w0, [x21]
    9ee4:	7103fc1f 	cmp	w0, #0xff
    9ee8:	54010f80 	b.eq	c0d8 <f0+0x24a8>  // b.none
    9eec:	52800020 	mov	w0, #0x1                   	// #1
    9ef0:	390002a0 	strb	w0, [x21]
    9ef4:	910263e1 	add	x1, sp, #0x98
    9ef8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9efc:	52800020 	mov	w0, #0x1                   	// #1
    9f00:	a909dff5 	stp	x21, x23, [sp, #152]
    9f04:	97ffec60 	bl	5084 <fwp_data.part.0.constprop.0>
    9f08:	97ffedeb 	bl	56b4 <fwp_rc_fresh>
    9f0c:	aa0003e2 	mov	x2, x0
    9f10:	9102a3e1 	add	x1, sp, #0xa8
    9f14:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9f18:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9f1c:	52800020 	mov	w0, #0x1                   	// #1
    9f20:	a90a8bf7 	stp	x23, x2, [sp, #168]
    9f24:	97ffec58 	bl	5084 <fwp_data.part.0.constprop.0>
    9f28:	97ffede3 	bl	56b4 <fwp_rc_fresh>
    9f2c:	aa0003e2 	mov	x2, x0
    9f30:	9102e3e1 	add	x1, sp, #0xb8
    9f34:	52800020 	mov	w0, #0x1                   	// #1
    9f38:	a90b8bf5 	stp	x21, x2, [sp, #184]
    9f3c:	97ffec52 	bl	5084 <fwp_data.part.0.constprop.0>
    9f40:	97ffeddd 	bl	56b4 <fwp_rc_fresh>
    9f44:	aa0003e2 	mov	x2, x0
    9f48:	910323e1 	add	x1, sp, #0xc8
    9f4c:	52800020 	mov	w0, #0x1                   	// #1
    9f50:	a90c8bf7 	stp	x23, x2, [sp, #200]
    9f54:	97ffec4c 	bl	5084 <fwp_data.part.0.constprop.0>
    9f58:	97ffedd7 	bl	56b4 <fwp_rc_fresh>
    9f5c:	aa0003e2 	mov	x2, x0
    9f60:	910363e1 	add	x1, sp, #0xd8
    9f64:	52800020 	mov	w0, #0x1                   	// #1
    9f68:	a90d8bf5 	stp	x21, x2, [sp, #216]
    9f6c:	97ffec46 	bl	5084 <fwp_data.part.0.constprop.0>
    9f70:	97ffedd1 	bl	56b4 <fwp_rc_fresh>
    9f74:	aa0003e2 	mov	x2, x0
    9f78:	9103a3e1 	add	x1, sp, #0xe8
    9f7c:	52800020 	mov	w0, #0x1                   	// #1
    9f80:	a90e8bf7 	stp	x23, x2, [sp, #232]
    9f84:	97ffec40 	bl	5084 <fwp_data.part.0.constprop.0>
    9f88:	97ffedcb 	bl	56b4 <fwp_rc_fresh>
    9f8c:	aa0003e2 	mov	x2, x0
    9f90:	9103e3e1 	add	x1, sp, #0xf8
    9f94:	52800020 	mov	w0, #0x1                   	// #1
    9f98:	a90f8bf5 	stp	x21, x2, [sp, #248]
    9f9c:	97ffec3a 	bl	5084 <fwp_data.part.0.constprop.0>
    9fa0:	97ffedc5 	bl	56b4 <fwp_rc_fresh>
    9fa4:	aa0003e2 	mov	x2, x0
    9fa8:	910423e1 	add	x1, sp, #0x108
    9fac:	52800020 	mov	w0, #0x1                   	// #1
    9fb0:	a9108bf7 	stp	x23, x2, [sp, #264]
    9fb4:	97ffec34 	bl	5084 <fwp_data.part.0.constprop.0>
    9fb8:	97ffedbf 	bl	56b4 <fwp_rc_fresh>
    9fbc:	aa0003e2 	mov	x2, x0
    9fc0:	910463e1 	add	x1, sp, #0x118
    9fc4:	52800020 	mov	w0, #0x1                   	// #1
    9fc8:	a9118bf5 	stp	x21, x2, [sp, #280]
    9fcc:	97ffec2e 	bl	5084 <fwp_data.part.0.constprop.0>
    9fd0:	91174283 	add	x3, x20, #0x5d0
    9fd4:	aa0003f5 	mov	x21, x0
    9fd8:	f949d861 	ldr	x1, [x3, #5040]
    9fdc:	f949ec60 	ldr	x0, [x3, #5080]
    9fe0:	cb0102a1 	sub	x1, x21, x1
    9fe4:	eb00403f 	cmp	x1, x0, lsl #16
    9fe8:	54000322 	b.cs	a04c <f0+0x41c>  // b.hs, b.nlast
    9fec:	d350fc22 	lsr	x2, x1, #16
    9ff0:	f949fc63 	ldr	x3, [x3, #5112]
    9ff4:	8b020842 	add	x2, x2, x2, lsl #2
    9ff8:	d37df042 	lsl	x2, x2, #3
    9ffc:	8b020060 	add	x0, x3, x2
    a000:	f9401017 	ldr	x23, [x0, #32]
    a004:	b4000257 	cbz	x23, a04c <f0+0x41c>
    a008:	38626862 	ldrb	w2, [x3, x2]
    a00c:	7100085f 	cmp	w2, #0x2
    a010:	5400f9e0 	b.eq	bf4c <f0+0x231c>  // b.none
    a014:	7100045f 	cmp	w2, #0x1
    a018:	540001a1 	b.ne	a04c <f0+0x41c>  // b.any
    a01c:	29430002 	ldp	w2, w0, [x0, #24]
    a020:	92403c21 	and	x1, x1, #0xffff
    a024:	9b027c21 	mul	x1, x1, x2
    a028:	d360fc21 	lsr	x1, x1, #32
    a02c:	eb00003f 	cmp	x1, x0
    a030:	540000e2 	b.cs	a04c <f0+0x41c>  // b.hs, b.nlast
    a034:	8b0102f7 	add	x23, x23, x1
    a038:	394002e0 	ldrb	w0, [x23]
    a03c:	7103fc1f 	cmp	w0, #0xff
    a040:	54010520 	b.eq	c0e4 <f0+0x24b4>  // b.none
    a044:	52800020 	mov	w0, #0x1                   	// #1
    a048:	390002e0 	strb	w0, [x23]
    a04c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a050:	9104a3e1 	add	x1, sp, #0x128
    a054:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a058:	52800020 	mov	w0, #0x1                   	// #1
    a05c:	a912d7e2 	stp	x2, x21, [sp, #296]
    a060:	97ffec09 	bl	5084 <fwp_data.part.0.constprop.0>
    a064:	97ffed94 	bl	56b4 <fwp_rc_fresh>
    a068:	aa0003e2 	mov	x2, x0
    a06c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a070:	9104e3e1 	add	x1, sp, #0x138
    a074:	52800020 	mov	w0, #0x1                   	// #1
    a078:	a9138be3 	stp	x3, x2, [sp, #312]
    a07c:	97ffec02 	bl	5084 <fwp_data.part.0.constprop.0>
    a080:	91174283 	add	x3, x20, #0x5d0
    a084:	aa0003f5 	mov	x21, x0
    a088:	f949d861 	ldr	x1, [x3, #5040]
    a08c:	f949ec60 	ldr	x0, [x3, #5080]
    a090:	cb0102a1 	sub	x1, x21, x1
    a094:	eb00403f 	cmp	x1, x0, lsl #16
    a098:	54000322 	b.cs	a0fc <f0+0x4cc>  // b.hs, b.nlast
    a09c:	d350fc22 	lsr	x2, x1, #16
    a0a0:	f949fc63 	ldr	x3, [x3, #5112]
    a0a4:	8b020842 	add	x2, x2, x2, lsl #2
    a0a8:	d37df042 	lsl	x2, x2, #3
    a0ac:	8b020060 	add	x0, x3, x2
    a0b0:	f9401017 	ldr	x23, [x0, #32]
    a0b4:	b4000257 	cbz	x23, a0fc <f0+0x4cc>
    a0b8:	38626862 	ldrb	w2, [x3, x2]
    a0bc:	7100085f 	cmp	w2, #0x2
    a0c0:	5400f6a0 	b.eq	bf94 <f0+0x2364>  // b.none
    a0c4:	7100045f 	cmp	w2, #0x1
    a0c8:	540001a1 	b.ne	a0fc <f0+0x4cc>  // b.any
    a0cc:	29430002 	ldp	w2, w0, [x0, #24]
    a0d0:	92403c21 	and	x1, x1, #0xffff
    a0d4:	9b027c21 	mul	x1, x1, x2
    a0d8:	d360fc21 	lsr	x1, x1, #32
    a0dc:	eb00003f 	cmp	x1, x0
    a0e0:	540000e2 	b.cs	a0fc <f0+0x4cc>  // b.hs, b.nlast
    a0e4:	8b0102f7 	add	x23, x23, x1
    a0e8:	394002e0 	ldrb	w0, [x23]
    a0ec:	7103fc1f 	cmp	w0, #0xff
    a0f0:	54010000 	b.eq	c0f0 <f0+0x24c0>  // b.none
    a0f4:	52800020 	mov	w0, #0x1                   	// #1
    a0f8:	390002e0 	strb	w0, [x23]
    a0fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a100:	910523e1 	add	x1, sp, #0x148
    a104:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a108:	52800020 	mov	w0, #0x1                   	// #1
    a10c:	a914d7e2 	stp	x2, x21, [sp, #328]
    a110:	97ffebdd 	bl	5084 <fwp_data.part.0.constprop.0>
    a114:	97ffed68 	bl	56b4 <fwp_rc_fresh>
    a118:	aa0003e2 	mov	x2, x0
    a11c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a120:	910563e1 	add	x1, sp, #0x158
    a124:	52800020 	mov	w0, #0x1                   	// #1
    a128:	a9158be3 	stp	x3, x2, [sp, #344]
    a12c:	97ffebd6 	bl	5084 <fwp_data.part.0.constprop.0>
    a130:	91174283 	add	x3, x20, #0x5d0
    a134:	aa0003f5 	mov	x21, x0
    a138:	f949d861 	ldr	x1, [x3, #5040]
    a13c:	f949ec60 	ldr	x0, [x3, #5080]
    a140:	cb0102a1 	sub	x1, x21, x1
    a144:	eb00403f 	cmp	x1, x0, lsl #16
    a148:	54000322 	b.cs	a1ac <f0+0x57c>  // b.hs, b.nlast
    a14c:	d350fc22 	lsr	x2, x1, #16
    a150:	f949fc63 	ldr	x3, [x3, #5112]
    a154:	8b020842 	add	x2, x2, x2, lsl #2
    a158:	d37df042 	lsl	x2, x2, #3
    a15c:	8b020060 	add	x0, x3, x2
    a160:	f9401017 	ldr	x23, [x0, #32]
    a164:	b4000257 	cbz	x23, a1ac <f0+0x57c>
    a168:	38626862 	ldrb	w2, [x3, x2]
    a16c:	7100085f 	cmp	w2, #0x2
    a170:	5400f0c0 	b.eq	bf88 <f0+0x2358>  // b.none
    a174:	7100045f 	cmp	w2, #0x1
    a178:	540001a1 	b.ne	a1ac <f0+0x57c>  // b.any
    a17c:	29430002 	ldp	w2, w0, [x0, #24]
    a180:	92403c21 	and	x1, x1, #0xffff
    a184:	9b027c21 	mul	x1, x1, x2
    a188:	d360fc21 	lsr	x1, x1, #32
    a18c:	eb00003f 	cmp	x1, x0
    a190:	540000e2 	b.cs	a1ac <f0+0x57c>  // b.hs, b.nlast
    a194:	8b0102f7 	add	x23, x23, x1
    a198:	394002e0 	ldrb	w0, [x23]
    a19c:	7103fc1f 	cmp	w0, #0xff
    a1a0:	5400fae0 	b.eq	c0fc <f0+0x24cc>  // b.none
    a1a4:	52800020 	mov	w0, #0x1                   	// #1
    a1a8:	390002e0 	strb	w0, [x23]
    a1ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a1b0:	9105a3e1 	add	x1, sp, #0x168
    a1b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a1b8:	52800020 	mov	w0, #0x1                   	// #1
    a1bc:	a916d7e2 	stp	x2, x21, [sp, #360]
    a1c0:	97ffebb1 	bl	5084 <fwp_data.part.0.constprop.0>
    a1c4:	97ffed3c 	bl	56b4 <fwp_rc_fresh>
    a1c8:	aa0003e2 	mov	x2, x0
    a1cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a1d0:	9105e3e1 	add	x1, sp, #0x178
    a1d4:	52800020 	mov	w0, #0x1                   	// #1
    a1d8:	a9178be3 	stp	x3, x2, [sp, #376]
    a1dc:	97ffebaa 	bl	5084 <fwp_data.part.0.constprop.0>
    a1e0:	91174283 	add	x3, x20, #0x5d0
    a1e4:	aa0003f5 	mov	x21, x0
    a1e8:	f949d861 	ldr	x1, [x3, #5040]
    a1ec:	f949ec60 	ldr	x0, [x3, #5080]
    a1f0:	cb0102a1 	sub	x1, x21, x1
    a1f4:	eb00403f 	cmp	x1, x0, lsl #16
    a1f8:	54000322 	b.cs	a25c <f0+0x62c>  // b.hs, b.nlast
    a1fc:	d350fc22 	lsr	x2, x1, #16
    a200:	f949fc63 	ldr	x3, [x3, #5112]
    a204:	8b020842 	add	x2, x2, x2, lsl #2
    a208:	d37df042 	lsl	x2, x2, #3
    a20c:	8b020060 	add	x0, x3, x2
    a210:	f9401017 	ldr	x23, [x0, #32]
    a214:	b4000257 	cbz	x23, a25c <f0+0x62c>
    a218:	38626862 	ldrb	w2, [x3, x2]
    a21c:	7100085f 	cmp	w2, #0x2
    a220:	5400eae0 	b.eq	bf7c <f0+0x234c>  // b.none
    a224:	7100045f 	cmp	w2, #0x1
    a228:	540001a1 	b.ne	a25c <f0+0x62c>  // b.any
    a22c:	29430002 	ldp	w2, w0, [x0, #24]
    a230:	92403c21 	and	x1, x1, #0xffff
    a234:	9b027c21 	mul	x1, x1, x2
    a238:	d360fc21 	lsr	x1, x1, #32
    a23c:	eb00003f 	cmp	x1, x0
    a240:	540000e2 	b.cs	a25c <f0+0x62c>  // b.hs, b.nlast
    a244:	8b0102f7 	add	x23, x23, x1
    a248:	394002e0 	ldrb	w0, [x23]
    a24c:	7103fc1f 	cmp	w0, #0xff
    a250:	5400f5c0 	b.eq	c108 <f0+0x24d8>  // b.none
    a254:	52800020 	mov	w0, #0x1                   	// #1
    a258:	390002e0 	strb	w0, [x23]
    a25c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a260:	910623e1 	add	x1, sp, #0x188
    a264:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a268:	52800020 	mov	w0, #0x1                   	// #1
    a26c:	a918d7e2 	stp	x2, x21, [sp, #392]
    a270:	97ffeb85 	bl	5084 <fwp_data.part.0.constprop.0>
    a274:	97ffed10 	bl	56b4 <fwp_rc_fresh>
    a278:	aa0003e2 	mov	x2, x0
    a27c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a280:	910663e1 	add	x1, sp, #0x198
    a284:	52800020 	mov	w0, #0x1                   	// #1
    a288:	a9198be3 	stp	x3, x2, [sp, #408]
    a28c:	97ffeb7e 	bl	5084 <fwp_data.part.0.constprop.0>
    a290:	91174283 	add	x3, x20, #0x5d0
    a294:	aa0003f5 	mov	x21, x0
    a298:	f949d861 	ldr	x1, [x3, #5040]
    a29c:	f949ec60 	ldr	x0, [x3, #5080]
    a2a0:	cb0102a1 	sub	x1, x21, x1
    a2a4:	eb00403f 	cmp	x1, x0, lsl #16
    a2a8:	54000322 	b.cs	a30c <f0+0x6dc>  // b.hs, b.nlast
    a2ac:	d350fc22 	lsr	x2, x1, #16
    a2b0:	f949fc63 	ldr	x3, [x3, #5112]
    a2b4:	8b020842 	add	x2, x2, x2, lsl #2
    a2b8:	d37df042 	lsl	x2, x2, #3
    a2bc:	8b020060 	add	x0, x3, x2
    a2c0:	f9401017 	ldr	x23, [x0, #32]
    a2c4:	b4000257 	cbz	x23, a30c <f0+0x6dc>
    a2c8:	38626862 	ldrb	w2, [x3, x2]
    a2cc:	7100085f 	cmp	w2, #0x2
    a2d0:	5400e500 	b.eq	bf70 <f0+0x2340>  // b.none
    a2d4:	7100045f 	cmp	w2, #0x1
    a2d8:	540001a1 	b.ne	a30c <f0+0x6dc>  // b.any
    a2dc:	29430002 	ldp	w2, w0, [x0, #24]
    a2e0:	92403c21 	and	x1, x1, #0xffff
    a2e4:	9b027c21 	mul	x1, x1, x2
    a2e8:	d360fc21 	lsr	x1, x1, #32
    a2ec:	eb00003f 	cmp	x1, x0
    a2f0:	540000e2 	b.cs	a30c <f0+0x6dc>  // b.hs, b.nlast
    a2f4:	8b0102f7 	add	x23, x23, x1
    a2f8:	394002e0 	ldrb	w0, [x23]
    a2fc:	7103fc1f 	cmp	w0, #0xff
    a300:	5400f0a0 	b.eq	c114 <f0+0x24e4>  // b.none
    a304:	52800020 	mov	w0, #0x1                   	// #1
    a308:	390002e0 	strb	w0, [x23]
    a30c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a310:	9106a3e1 	add	x1, sp, #0x1a8
    a314:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a318:	52800020 	mov	w0, #0x1                   	// #1
    a31c:	a91ad7e2 	stp	x2, x21, [sp, #424]
    a320:	97ffeb59 	bl	5084 <fwp_data.part.0.constprop.0>
    a324:	97ffece4 	bl	56b4 <fwp_rc_fresh>
    a328:	aa0003e2 	mov	x2, x0
    a32c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a330:	9106e3e1 	add	x1, sp, #0x1b8
    a334:	52800020 	mov	w0, #0x1                   	// #1
    a338:	a91b8be3 	stp	x3, x2, [sp, #440]
    a33c:	97ffeb52 	bl	5084 <fwp_data.part.0.constprop.0>
    a340:	91174283 	add	x3, x20, #0x5d0
    a344:	aa0003f5 	mov	x21, x0
    a348:	f949d861 	ldr	x1, [x3, #5040]
    a34c:	f949ec60 	ldr	x0, [x3, #5080]
    a350:	cb0102a1 	sub	x1, x21, x1
    a354:	eb00403f 	cmp	x1, x0, lsl #16
    a358:	54000322 	b.cs	a3bc <f0+0x78c>  // b.hs, b.nlast
    a35c:	d350fc22 	lsr	x2, x1, #16
    a360:	f949fc63 	ldr	x3, [x3, #5112]
    a364:	8b020842 	add	x2, x2, x2, lsl #2
    a368:	d37df042 	lsl	x2, x2, #3
    a36c:	8b020060 	add	x0, x3, x2
    a370:	f9401017 	ldr	x23, [x0, #32]
    a374:	b4000257 	cbz	x23, a3bc <f0+0x78c>
    a378:	38626862 	ldrb	w2, [x3, x2]
    a37c:	7100085f 	cmp	w2, #0x2
    a380:	5400e3a0 	b.eq	bff4 <f0+0x23c4>  // b.none
    a384:	7100045f 	cmp	w2, #0x1
    a388:	540001a1 	b.ne	a3bc <f0+0x78c>  // b.any
    a38c:	29430002 	ldp	w2, w0, [x0, #24]
    a390:	92403c21 	and	x1, x1, #0xffff
    a394:	9b027c21 	mul	x1, x1, x2
    a398:	d360fc21 	lsr	x1, x1, #32
    a39c:	eb00003f 	cmp	x1, x0
    a3a0:	540000e2 	b.cs	a3bc <f0+0x78c>  // b.hs, b.nlast
    a3a4:	8b0102f7 	add	x23, x23, x1
    a3a8:	394002e0 	ldrb	w0, [x23]
    a3ac:	7103fc1f 	cmp	w0, #0xff
    a3b0:	5400eb80 	b.eq	c120 <f0+0x24f0>  // b.none
    a3b4:	52800020 	mov	w0, #0x1                   	// #1
    a3b8:	390002e0 	strb	w0, [x23]
    a3bc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a3c0:	910723e1 	add	x1, sp, #0x1c8
    a3c4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a3c8:	52800020 	mov	w0, #0x1                   	// #1
    a3cc:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a3d0:	97ffeb2d 	bl	5084 <fwp_data.part.0.constprop.0>
    a3d4:	91174283 	add	x3, x20, #0x5d0
    a3d8:	aa0003f5 	mov	x21, x0
    a3dc:	f949d861 	ldr	x1, [x3, #5040]
    a3e0:	f949ec60 	ldr	x0, [x3, #5080]
    a3e4:	cb0102a1 	sub	x1, x21, x1
    a3e8:	eb00403f 	cmp	x1, x0, lsl #16
    a3ec:	54000322 	b.cs	a450 <f0+0x820>  // b.hs, b.nlast
    a3f0:	d350fc22 	lsr	x2, x1, #16
    a3f4:	f949fc63 	ldr	x3, [x3, #5112]
    a3f8:	8b020842 	add	x2, x2, x2, lsl #2
    a3fc:	d37df042 	lsl	x2, x2, #3
    a400:	8b020060 	add	x0, x3, x2
    a404:	f9401017 	ldr	x23, [x0, #32]
    a408:	b4000257 	cbz	x23, a450 <f0+0x820>
    a40c:	38626862 	ldrb	w2, [x3, x2]
    a410:	7100085f 	cmp	w2, #0x2
    a414:	5400dea0 	b.eq	bfe8 <f0+0x23b8>  // b.none
    a418:	7100045f 	cmp	w2, #0x1
    a41c:	540001a1 	b.ne	a450 <f0+0x820>  // b.any
    a420:	29430002 	ldp	w2, w0, [x0, #24]
    a424:	92403c21 	and	x1, x1, #0xffff
    a428:	9b027c21 	mul	x1, x1, x2
    a42c:	d360fc21 	lsr	x1, x1, #32
    a430:	eb00003f 	cmp	x1, x0
    a434:	540000e2 	b.cs	a450 <f0+0x820>  // b.hs, b.nlast
    a438:	8b0102f7 	add	x23, x23, x1
    a43c:	394002e0 	ldrb	w0, [x23]
    a440:	7103fc1f 	cmp	w0, #0xff
    a444:	5400e740 	b.eq	c12c <f0+0x24fc>  // b.none
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	390002e0 	strb	w0, [x23]
    a450:	910763e1 	add	x1, sp, #0x1d8
    a454:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a458:	52800020 	mov	w0, #0x1                   	// #1
    a45c:	a91dd7f7 	stp	x23, x21, [sp, #472]
    a460:	97ffeb09 	bl	5084 <fwp_data.part.0.constprop.0>
    a464:	97ffec94 	bl	56b4 <fwp_rc_fresh>
    a468:	aa0003e2 	mov	x2, x0
    a46c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a470:	9107a3e1 	add	x1, sp, #0x1e8
    a474:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a478:	52800020 	mov	w0, #0x1                   	// #1
    a47c:	a91e8be3 	stp	x3, x2, [sp, #488]
    a480:	97ffeb01 	bl	5084 <fwp_data.part.0.constprop.0>
    a484:	97ffec8c 	bl	56b4 <fwp_rc_fresh>
    a488:	aa0003e2 	mov	x2, x0
    a48c:	9107e3e1 	add	x1, sp, #0x1f8
    a490:	52800020 	mov	w0, #0x1                   	// #1
    a494:	a91f8bf7 	stp	x23, x2, [sp, #504]
    a498:	97ffeafb 	bl	5084 <fwp_data.part.0.constprop.0>
    a49c:	91174283 	add	x3, x20, #0x5d0
    a4a0:	aa0003f5 	mov	x21, x0
    a4a4:	f949d861 	ldr	x1, [x3, #5040]
    a4a8:	f949ec60 	ldr	x0, [x3, #5080]
    a4ac:	cb0102a1 	sub	x1, x21, x1
    a4b0:	eb00403f 	cmp	x1, x0, lsl #16
    a4b4:	54000322 	b.cs	a518 <f0+0x8e8>  // b.hs, b.nlast
    a4b8:	d350fc22 	lsr	x2, x1, #16
    a4bc:	f949fc63 	ldr	x3, [x3, #5112]
    a4c0:	8b020842 	add	x2, x2, x2, lsl #2
    a4c4:	d37df042 	lsl	x2, x2, #3
    a4c8:	8b020060 	add	x0, x3, x2
    a4cc:	f9401017 	ldr	x23, [x0, #32]
    a4d0:	b4000257 	cbz	x23, a518 <f0+0x8e8>
    a4d4:	38626862 	ldrb	w2, [x3, x2]
    a4d8:	7100085f 	cmp	w2, #0x2
    a4dc:	5400d800 	b.eq	bfdc <f0+0x23ac>  // b.none
    a4e0:	7100045f 	cmp	w2, #0x1
    a4e4:	540001a1 	b.ne	a518 <f0+0x8e8>  // b.any
    a4e8:	29430002 	ldp	w2, w0, [x0, #24]
    a4ec:	92403c21 	and	x1, x1, #0xffff
    a4f0:	9b027c21 	mul	x1, x1, x2
    a4f4:	d360fc21 	lsr	x1, x1, #32
    a4f8:	eb00003f 	cmp	x1, x0
    a4fc:	540000e2 	b.cs	a518 <f0+0x8e8>  // b.hs, b.nlast
    a500:	8b0102f7 	add	x23, x23, x1
    a504:	394002e0 	ldrb	w0, [x23]
    a508:	7103fc1f 	cmp	w0, #0xff
    a50c:	5400e160 	b.eq	c138 <f0+0x2508>  // b.none
    a510:	52800020 	mov	w0, #0x1                   	// #1
    a514:	390002e0 	strb	w0, [x23]
    a518:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a51c:	910823e1 	add	x1, sp, #0x208
    a520:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a524:	52800020 	mov	w0, #0x1                   	// #1
    a528:	f90107e2 	str	x2, [sp, #520]
    a52c:	f9010bf5 	str	x21, [sp, #528]
    a530:	97ffead5 	bl	5084 <fwp_data.part.0.constprop.0>
    a534:	97ffec60 	bl	56b4 <fwp_rc_fresh>
    a538:	aa0003e2 	mov	x2, x0
    a53c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a540:	910863e1 	add	x1, sp, #0x218
    a544:	52800020 	mov	w0, #0x1                   	// #1
    a548:	f9010fe3 	str	x3, [sp, #536]
    a54c:	f90113e2 	str	x2, [sp, #544]
    a550:	97ffeacd 	bl	5084 <fwp_data.part.0.constprop.0>
    a554:	91174283 	add	x3, x20, #0x5d0
    a558:	aa0003f5 	mov	x21, x0
    a55c:	f949d861 	ldr	x1, [x3, #5040]
    a560:	f949ec60 	ldr	x0, [x3, #5080]
    a564:	cb0102a1 	sub	x1, x21, x1
    a568:	eb00403f 	cmp	x1, x0, lsl #16
    a56c:	54000322 	b.cs	a5d0 <f0+0x9a0>  // b.hs, b.nlast
    a570:	d350fc22 	lsr	x2, x1, #16
    a574:	f949fc63 	ldr	x3, [x3, #5112]
    a578:	8b020842 	add	x2, x2, x2, lsl #2
    a57c:	d37df042 	lsl	x2, x2, #3
    a580:	8b020060 	add	x0, x3, x2
    a584:	f9401017 	ldr	x23, [x0, #32]
    a588:	b4000257 	cbz	x23, a5d0 <f0+0x9a0>
    a58c:	38626862 	ldrb	w2, [x3, x2]
    a590:	7100085f 	cmp	w2, #0x2
    a594:	5400d1e0 	b.eq	bfd0 <f0+0x23a0>  // b.none
    a598:	7100045f 	cmp	w2, #0x1
    a59c:	540001a1 	b.ne	a5d0 <f0+0x9a0>  // b.any
    a5a0:	29430002 	ldp	w2, w0, [x0, #24]
    a5a4:	92403c21 	and	x1, x1, #0xffff
    a5a8:	9b027c21 	mul	x1, x1, x2
    a5ac:	d360fc21 	lsr	x1, x1, #32
    a5b0:	eb00003f 	cmp	x1, x0
    a5b4:	540000e2 	b.cs	a5d0 <f0+0x9a0>  // b.hs, b.nlast
    a5b8:	8b0102f7 	add	x23, x23, x1
    a5bc:	394002e0 	ldrb	w0, [x23]
    a5c0:	7103fc1f 	cmp	w0, #0xff
    a5c4:	5400dc00 	b.eq	c144 <f0+0x2514>  // b.none
    a5c8:	52800020 	mov	w0, #0x1                   	// #1
    a5cc:	390002e0 	strb	w0, [x23]
    a5d0:	9108a3e1 	add	x1, sp, #0x228
    a5d4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a5d8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a5dc:	52800020 	mov	w0, #0x1                   	// #1
    a5e0:	f90117f7 	str	x23, [sp, #552]
    a5e4:	f9011bf5 	str	x21, [sp, #560]
    a5e8:	97ffeaa7 	bl	5084 <fwp_data.part.0.constprop.0>
    a5ec:	97ffec32 	bl	56b4 <fwp_rc_fresh>
    a5f0:	aa0003e2 	mov	x2, x0
    a5f4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a5f8:	9108e3e1 	add	x1, sp, #0x238
    a5fc:	52800020 	mov	w0, #0x1                   	// #1
    a600:	f9011fe3 	str	x3, [sp, #568]
    a604:	f90123e2 	str	x2, [sp, #576]
    a608:	97ffea9f 	bl	5084 <fwp_data.part.0.constprop.0>
    a60c:	97ffec2a 	bl	56b4 <fwp_rc_fresh>
    a610:	aa0003e2 	mov	x2, x0
    a614:	910923e1 	add	x1, sp, #0x248
    a618:	52800020 	mov	w0, #0x1                   	// #1
    a61c:	f90127f7 	str	x23, [sp, #584]
    a620:	f9012be2 	str	x2, [sp, #592]
    a624:	97ffea98 	bl	5084 <fwp_data.part.0.constprop.0>
    a628:	91174283 	add	x3, x20, #0x5d0
    a62c:	aa0003f5 	mov	x21, x0
    a630:	f949d861 	ldr	x1, [x3, #5040]
    a634:	f949ec60 	ldr	x0, [x3, #5080]
    a638:	cb0102a1 	sub	x1, x21, x1
    a63c:	eb00403f 	cmp	x1, x0, lsl #16
    a640:	54000322 	b.cs	a6a4 <f0+0xa74>  // b.hs, b.nlast
    a644:	d350fc22 	lsr	x2, x1, #16
    a648:	f949fc63 	ldr	x3, [x3, #5112]
    a64c:	8b020842 	add	x2, x2, x2, lsl #2
    a650:	d37df042 	lsl	x2, x2, #3
    a654:	8b020060 	add	x0, x3, x2
    a658:	f9401017 	ldr	x23, [x0, #32]
    a65c:	b4000257 	cbz	x23, a6a4 <f0+0xa74>
    a660:	38626862 	ldrb	w2, [x3, x2]
    a664:	7100085f 	cmp	w2, #0x2
    a668:	5400cae0 	b.eq	bfc4 <f0+0x2394>  // b.none
    a66c:	7100045f 	cmp	w2, #0x1
    a670:	540001a1 	b.ne	a6a4 <f0+0xa74>  // b.any
    a674:	29430002 	ldp	w2, w0, [x0, #24]
    a678:	92403c21 	and	x1, x1, #0xffff
    a67c:	9b027c21 	mul	x1, x1, x2
    a680:	d360fc21 	lsr	x1, x1, #32
    a684:	eb00003f 	cmp	x1, x0
    a688:	540000e2 	b.cs	a6a4 <f0+0xa74>  // b.hs, b.nlast
    a68c:	8b0102f7 	add	x23, x23, x1
    a690:	394002e0 	ldrb	w0, [x23]
    a694:	7103fc1f 	cmp	w0, #0xff
    a698:	5400d5c0 	b.eq	c150 <f0+0x2520>  // b.none
    a69c:	52800020 	mov	w0, #0x1                   	// #1
    a6a0:	390002e0 	strb	w0, [x23]
    a6a4:	910963e1 	add	x1, sp, #0x258
    a6a8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a6ac:	52800020 	mov	w0, #0x1                   	// #1
    a6b0:	f9012ff7 	str	x23, [sp, #600]
    a6b4:	f90133f5 	str	x21, [sp, #608]
    a6b8:	97ffea73 	bl	5084 <fwp_data.part.0.constprop.0>
    a6bc:	97ffebfe 	bl	56b4 <fwp_rc_fresh>
    a6c0:	aa0003e2 	mov	x2, x0
    a6c4:	9109a3e1 	add	x1, sp, #0x268
    a6c8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a6cc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a6d0:	52800020 	mov	w0, #0x1                   	// #1
    a6d4:	f90137f5 	str	x21, [sp, #616]
    a6d8:	f9013be2 	str	x2, [sp, #624]
    a6dc:	97ffea6a 	bl	5084 <fwp_data.part.0.constprop.0>
    a6e0:	97ffebf5 	bl	56b4 <fwp_rc_fresh>
    a6e4:	aa0003e2 	mov	x2, x0
    a6e8:	9109e3e1 	add	x1, sp, #0x278
    a6ec:	52800020 	mov	w0, #0x1                   	// #1
    a6f0:	f9013ff7 	str	x23, [sp, #632]
    a6f4:	f90143e2 	str	x2, [sp, #640]
    a6f8:	97ffea63 	bl	5084 <fwp_data.part.0.constprop.0>
    a6fc:	97ffebee 	bl	56b4 <fwp_rc_fresh>
    a700:	aa0003e2 	mov	x2, x0
    a704:	910a23e1 	add	x1, sp, #0x288
    a708:	52800020 	mov	w0, #0x1                   	// #1
    a70c:	f90147f5 	str	x21, [sp, #648]
    a710:	f9014be2 	str	x2, [sp, #656]
    a714:	97ffea5c 	bl	5084 <fwp_data.part.0.constprop.0>
    a718:	91174283 	add	x3, x20, #0x5d0
    a71c:	aa0003f5 	mov	x21, x0
    a720:	f949d861 	ldr	x1, [x3, #5040]
    a724:	f949ec60 	ldr	x0, [x3, #5080]
    a728:	cb0102a1 	sub	x1, x21, x1
    a72c:	eb00403f 	cmp	x1, x0, lsl #16
    a730:	54000322 	b.cs	a794 <f0+0xb64>  // b.hs, b.nlast
    a734:	d350fc22 	lsr	x2, x1, #16
    a738:	f949fc63 	ldr	x3, [x3, #5112]
    a73c:	8b020842 	add	x2, x2, x2, lsl #2
    a740:	d37df042 	lsl	x2, x2, #3
    a744:	8b020060 	add	x0, x3, x2
    a748:	f9401017 	ldr	x23, [x0, #32]
    a74c:	b4000257 	cbz	x23, a794 <f0+0xb64>
    a750:	38626862 	ldrb	w2, [x3, x2]
    a754:	7100085f 	cmp	w2, #0x2
    a758:	5400c300 	b.eq	bfb8 <f0+0x2388>  // b.none
    a75c:	7100045f 	cmp	w2, #0x1
    a760:	540001a1 	b.ne	a794 <f0+0xb64>  // b.any
    a764:	29430002 	ldp	w2, w0, [x0, #24]
    a768:	92403c21 	and	x1, x1, #0xffff
    a76c:	9b027c21 	mul	x1, x1, x2
    a770:	d360fc21 	lsr	x1, x1, #32
    a774:	eb00003f 	cmp	x1, x0
    a778:	540000e2 	b.cs	a794 <f0+0xb64>  // b.hs, b.nlast
    a77c:	8b0102f7 	add	x23, x23, x1
    a780:	394002e0 	ldrb	w0, [x23]
    a784:	7103fc1f 	cmp	w0, #0xff
    a788:	5400cea0 	b.eq	c15c <f0+0x252c>  // b.none
    a78c:	52800020 	mov	w0, #0x1                   	// #1
    a790:	390002e0 	strb	w0, [x23]
    a794:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a798:	910a63e1 	add	x1, sp, #0x298
    a79c:	52800020 	mov	w0, #0x1                   	// #1
    a7a0:	f9014fe2 	str	x2, [sp, #664]
    a7a4:	f90153f5 	str	x21, [sp, #672]
    a7a8:	97ffea37 	bl	5084 <fwp_data.part.0.constprop.0>
    a7ac:	91174283 	add	x3, x20, #0x5d0
    a7b0:	aa0003f5 	mov	x21, x0
    a7b4:	f949d861 	ldr	x1, [x3, #5040]
    a7b8:	f949ec60 	ldr	x0, [x3, #5080]
    a7bc:	cb0102a1 	sub	x1, x21, x1
    a7c0:	eb00403f 	cmp	x1, x0, lsl #16
    a7c4:	54000322 	b.cs	a828 <f0+0xbf8>  // b.hs, b.nlast
    a7c8:	d350fc22 	lsr	x2, x1, #16
    a7cc:	f949fc63 	ldr	x3, [x3, #5112]
    a7d0:	8b020842 	add	x2, x2, x2, lsl #2
    a7d4:	d37df042 	lsl	x2, x2, #3
    a7d8:	8b020060 	add	x0, x3, x2
    a7dc:	f9401017 	ldr	x23, [x0, #32]
    a7e0:	b4000257 	cbz	x23, a828 <f0+0xbf8>
    a7e4:	38626862 	ldrb	w2, [x3, x2]
    a7e8:	7100085f 	cmp	w2, #0x2
    a7ec:	5400be00 	b.eq	bfac <f0+0x237c>  // b.none
    a7f0:	7100045f 	cmp	w2, #0x1
    a7f4:	540001a1 	b.ne	a828 <f0+0xbf8>  // b.any
    a7f8:	29430002 	ldp	w2, w0, [x0, #24]
    a7fc:	92403c21 	and	x1, x1, #0xffff
    a800:	9b027c21 	mul	x1, x1, x2
    a804:	d360fc21 	lsr	x1, x1, #32
    a808:	eb00003f 	cmp	x1, x0
    a80c:	540000e2 	b.cs	a828 <f0+0xbf8>  // b.hs, b.nlast
    a810:	8b0102f7 	add	x23, x23, x1
    a814:	394002e0 	ldrb	w0, [x23]
    a818:	7103fc1f 	cmp	w0, #0xff
    a81c:	5400ca60 	b.eq	c168 <f0+0x2538>  // b.none
    a820:	52800020 	mov	w0, #0x1                   	// #1
    a824:	390002e0 	strb	w0, [x23]
    a828:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a82c:	910aa3e1 	add	x1, sp, #0x2a8
    a830:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a834:	52800020 	mov	w0, #0x1                   	// #1
    a838:	f90157e2 	str	x2, [sp, #680]
    a83c:	f9015bf5 	str	x21, [sp, #688]
    a840:	97ffea11 	bl	5084 <fwp_data.part.0.constprop.0>
    a844:	91174283 	add	x3, x20, #0x5d0
    a848:	aa0003f5 	mov	x21, x0
    a84c:	f949d861 	ldr	x1, [x3, #5040]
    a850:	f949ec60 	ldr	x0, [x3, #5080]
    a854:	cb0102a1 	sub	x1, x21, x1
    a858:	eb00403f 	cmp	x1, x0, lsl #16
    a85c:	54000322 	b.cs	a8c0 <f0+0xc90>  // b.hs, b.nlast
    a860:	d350fc22 	lsr	x2, x1, #16
    a864:	f949fc63 	ldr	x3, [x3, #5112]
    a868:	8b020842 	add	x2, x2, x2, lsl #2
    a86c:	d37df042 	lsl	x2, x2, #3
    a870:	8b020060 	add	x0, x3, x2
    a874:	f9401017 	ldr	x23, [x0, #32]
    a878:	b4000257 	cbz	x23, a8c0 <f0+0xc90>
    a87c:	38626862 	ldrb	w2, [x3, x2]
    a880:	7100085f 	cmp	w2, #0x2
    a884:	5400b8e0 	b.eq	bfa0 <f0+0x2370>  // b.none
    a888:	7100045f 	cmp	w2, #0x1
    a88c:	540001a1 	b.ne	a8c0 <f0+0xc90>  // b.any
    a890:	29430002 	ldp	w2, w0, [x0, #24]
    a894:	92403c21 	and	x1, x1, #0xffff
    a898:	9b027c21 	mul	x1, x1, x2
    a89c:	d360fc21 	lsr	x1, x1, #32
    a8a0:	eb00003f 	cmp	x1, x0
    a8a4:	540000e2 	b.cs	a8c0 <f0+0xc90>  // b.hs, b.nlast
    a8a8:	8b0102f7 	add	x23, x23, x1
    a8ac:	394002e0 	ldrb	w0, [x23]
    a8b0:	7103fc1f 	cmp	w0, #0xff
    a8b4:	5400c600 	b.eq	c174 <f0+0x2544>  // b.none
    a8b8:	52800020 	mov	w0, #0x1                   	// #1
    a8bc:	390002e0 	strb	w0, [x23]
    a8c0:	910ae3e1 	add	x1, sp, #0x2b8
    a8c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a8c8:	52800020 	mov	w0, #0x1                   	// #1
    a8cc:	f9015fe2 	str	x2, [sp, #696]
    a8d0:	f90163f5 	str	x21, [sp, #704]
    a8d4:	97ffe9ec 	bl	5084 <fwp_data.part.0.constprop.0>
    a8d8:	97ffeb77 	bl	56b4 <fwp_rc_fresh>
    a8dc:	aa0003e2 	mov	x2, x0
    a8e0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a8e4:	910b23e1 	add	x1, sp, #0x2c8
    a8e8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	f90167e3 	str	x3, [sp, #712]
    a8f4:	f9016be2 	str	x2, [sp, #720]
    a8f8:	97ffe9e3 	bl	5084 <fwp_data.part.0.constprop.0>
    a8fc:	91174283 	add	x3, x20, #0x5d0
    a900:	aa0003f5 	mov	x21, x0
    a904:	f949d861 	ldr	x1, [x3, #5040]
    a908:	f949ec60 	ldr	x0, [x3, #5080]
    a90c:	cb0102a1 	sub	x1, x21, x1
    a910:	eb00403f 	cmp	x1, x0, lsl #16
    a914:	54000322 	b.cs	a978 <f0+0xd48>  // b.hs, b.nlast
    a918:	d350fc22 	lsr	x2, x1, #16
    a91c:	f949fc63 	ldr	x3, [x3, #5112]
    a920:	8b020842 	add	x2, x2, x2, lsl #2
    a924:	d37df042 	lsl	x2, x2, #3
    a928:	8b020060 	add	x0, x3, x2
    a92c:	f9401017 	ldr	x23, [x0, #32]
    a930:	b4000257 	cbz	x23, a978 <f0+0xd48>
    a934:	38626862 	ldrb	w2, [x3, x2]
    a938:	7100085f 	cmp	w2, #0x2
    a93c:	5400b020 	b.eq	bf40 <f0+0x2310>  // b.none
    a940:	7100045f 	cmp	w2, #0x1
    a944:	540001a1 	b.ne	a978 <f0+0xd48>  // b.any
    a948:	29430002 	ldp	w2, w0, [x0, #24]
    a94c:	92403c21 	and	x1, x1, #0xffff
    a950:	9b027c21 	mul	x1, x1, x2
    a954:	d360fc21 	lsr	x1, x1, #32
    a958:	eb00003f 	cmp	x1, x0
    a95c:	540000e2 	b.cs	a978 <f0+0xd48>  // b.hs, b.nlast
    a960:	8b0102f7 	add	x23, x23, x1
    a964:	394002e0 	ldrb	w0, [x23]
    a968:	7103fc1f 	cmp	w0, #0xff
    a96c:	5400c0a0 	b.eq	c180 <f0+0x2550>  // b.none
    a970:	52800020 	mov	w0, #0x1                   	// #1
    a974:	390002e0 	strb	w0, [x23]
    a978:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a97c:	910b63e1 	add	x1, sp, #0x2d8
    a980:	52800020 	mov	w0, #0x1                   	// #1
    a984:	f9016fe2 	str	x2, [sp, #728]
    a988:	f90173f5 	str	x21, [sp, #736]
    a98c:	97ffe9be 	bl	5084 <fwp_data.part.0.constprop.0>
    a990:	91174283 	add	x3, x20, #0x5d0
    a994:	aa0003f5 	mov	x21, x0
    a998:	f949d861 	ldr	x1, [x3, #5040]
    a99c:	f949ec60 	ldr	x0, [x3, #5080]
    a9a0:	cb0102a1 	sub	x1, x21, x1
    a9a4:	eb00403f 	cmp	x1, x0, lsl #16
    a9a8:	54000322 	b.cs	aa0c <f0+0xddc>  // b.hs, b.nlast
    a9ac:	d350fc22 	lsr	x2, x1, #16
    a9b0:	f949fc63 	ldr	x3, [x3, #5112]
    a9b4:	8b020842 	add	x2, x2, x2, lsl #2
    a9b8:	d37df042 	lsl	x2, x2, #3
    a9bc:	8b020060 	add	x0, x3, x2
    a9c0:	f9401017 	ldr	x23, [x0, #32]
    a9c4:	b4000257 	cbz	x23, aa0c <f0+0xddc>
    a9c8:	38626862 	ldrb	w2, [x3, x2]
    a9cc:	7100085f 	cmp	w2, #0x2
    a9d0:	5400ab20 	b.eq	bf34 <f0+0x2304>  // b.none
    a9d4:	7100045f 	cmp	w2, #0x1
    a9d8:	540001a1 	b.ne	aa0c <f0+0xddc>  // b.any
    a9dc:	29430002 	ldp	w2, w0, [x0, #24]
    a9e0:	92403c21 	and	x1, x1, #0xffff
    a9e4:	9b027c21 	mul	x1, x1, x2
    a9e8:	d360fc21 	lsr	x1, x1, #32
    a9ec:	eb00003f 	cmp	x1, x0
    a9f0:	540000e2 	b.cs	aa0c <f0+0xddc>  // b.hs, b.nlast
    a9f4:	8b0102f7 	add	x23, x23, x1
    a9f8:	394002e0 	ldrb	w0, [x23]
    a9fc:	7103fc1f 	cmp	w0, #0xff
    aa00:	5400bc60 	b.eq	c18c <f0+0x255c>  // b.none
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	390002e0 	strb	w0, [x23]
    aa0c:	910ba3e1 	add	x1, sp, #0x2e8
    aa10:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aa14:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aa18:	52800020 	mov	w0, #0x1                   	// #1
    aa1c:	f90177f7 	str	x23, [sp, #744]
    aa20:	f9017bf5 	str	x21, [sp, #752]
    aa24:	97ffe998 	bl	5084 <fwp_data.part.0.constprop.0>
    aa28:	97ffeb23 	bl	56b4 <fwp_rc_fresh>
    aa2c:	aa0003e2 	mov	x2, x0
    aa30:	910be3e1 	add	x1, sp, #0x2f8
    aa34:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aa38:	52800020 	mov	w0, #0x1                   	// #1
    aa3c:	f9017ff5 	str	x21, [sp, #760]
    aa40:	f90183e2 	str	x2, [sp, #768]
    aa44:	97ffe990 	bl	5084 <fwp_data.part.0.constprop.0>
    aa48:	97ffeb1b 	bl	56b4 <fwp_rc_fresh>
    aa4c:	aa0003e2 	mov	x2, x0
    aa50:	910c23e1 	add	x1, sp, #0x308
    aa54:	52800020 	mov	w0, #0x1                   	// #1
    aa58:	f90187f7 	str	x23, [sp, #776]
    aa5c:	f9018be2 	str	x2, [sp, #784]
    aa60:	97ffe989 	bl	5084 <fwp_data.part.0.constprop.0>
    aa64:	97ffeb14 	bl	56b4 <fwp_rc_fresh>
    aa68:	aa0003e2 	mov	x2, x0
    aa6c:	910c63e1 	add	x1, sp, #0x318
    aa70:	52800020 	mov	w0, #0x1                   	// #1
    aa74:	f9018ff5 	str	x21, [sp, #792]
    aa78:	f90193e2 	str	x2, [sp, #800]
    aa7c:	97ffe982 	bl	5084 <fwp_data.part.0.constprop.0>
    aa80:	97ffeb0d 	bl	56b4 <fwp_rc_fresh>
    aa84:	aa0003e2 	mov	x2, x0
    aa88:	910ca3e1 	add	x1, sp, #0x328
    aa8c:	52800020 	mov	w0, #0x1                   	// #1
    aa90:	f90197f7 	str	x23, [sp, #808]
    aa94:	f9019be2 	str	x2, [sp, #816]
    aa98:	97ffe97b 	bl	5084 <fwp_data.part.0.constprop.0>
    aa9c:	97ffeb06 	bl	56b4 <fwp_rc_fresh>
    aaa0:	aa0003e2 	mov	x2, x0
    aaa4:	910ce3e1 	add	x1, sp, #0x338
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	f9019ff5 	str	x21, [sp, #824]
    aab0:	f901a3e2 	str	x2, [sp, #832]
    aab4:	97ffe974 	bl	5084 <fwp_data.part.0.constprop.0>
    aab8:	97ffeaff 	bl	56b4 <fwp_rc_fresh>
    aabc:	aa0003e2 	mov	x2, x0
    aac0:	910d23e1 	add	x1, sp, #0x348
    aac4:	52800020 	mov	w0, #0x1                   	// #1
    aac8:	f901a7f7 	str	x23, [sp, #840]
    aacc:	f901abe2 	str	x2, [sp, #848]
    aad0:	97ffe96d 	bl	5084 <fwp_data.part.0.constprop.0>
    aad4:	97ffeaf8 	bl	56b4 <fwp_rc_fresh>
    aad8:	aa0003e2 	mov	x2, x0
    aadc:	910d63e1 	add	x1, sp, #0x358
    aae0:	52800020 	mov	w0, #0x1                   	// #1
    aae4:	f901aff5 	str	x21, [sp, #856]
    aae8:	f901b3e2 	str	x2, [sp, #864]
    aaec:	97ffe966 	bl	5084 <fwp_data.part.0.constprop.0>
    aaf0:	91174283 	add	x3, x20, #0x5d0
    aaf4:	aa0003f5 	mov	x21, x0
    aaf8:	f949d861 	ldr	x1, [x3, #5040]
    aafc:	f949ec60 	ldr	x0, [x3, #5080]
    ab00:	cb0102a1 	sub	x1, x21, x1
    ab04:	eb00403f 	cmp	x1, x0, lsl #16
    ab08:	54000322 	b.cs	ab6c <f0+0xf3c>  // b.hs, b.nlast
    ab0c:	d350fc22 	lsr	x2, x1, #16
    ab10:	f949fc63 	ldr	x3, [x3, #5112]
    ab14:	8b020842 	add	x2, x2, x2, lsl #2
    ab18:	d37df042 	lsl	x2, x2, #3
    ab1c:	8b020060 	add	x0, x3, x2
    ab20:	f9401017 	ldr	x23, [x0, #32]
    ab24:	b4000257 	cbz	x23, ab6c <f0+0xf3c>
    ab28:	38626862 	ldrb	w2, [x3, x2]
    ab2c:	7100085f 	cmp	w2, #0x2
    ab30:	54009fc0 	b.eq	bf28 <f0+0x22f8>  // b.none
    ab34:	7100045f 	cmp	w2, #0x1
    ab38:	540001a1 	b.ne	ab6c <f0+0xf3c>  // b.any
    ab3c:	29430002 	ldp	w2, w0, [x0, #24]
    ab40:	92403c21 	and	x1, x1, #0xffff
    ab44:	9b027c21 	mul	x1, x1, x2
    ab48:	d360fc21 	lsr	x1, x1, #32
    ab4c:	eb00003f 	cmp	x1, x0
    ab50:	540000e2 	b.cs	ab6c <f0+0xf3c>  // b.hs, b.nlast
    ab54:	8b0102f7 	add	x23, x23, x1
    ab58:	394002e0 	ldrb	w0, [x23]
    ab5c:	7103fc1f 	cmp	w0, #0xff
    ab60:	5400b1c0 	b.eq	c198 <f0+0x2568>  // b.none
    ab64:	52800020 	mov	w0, #0x1                   	// #1
    ab68:	390002e0 	strb	w0, [x23]
    ab6c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ab70:	910da3e1 	add	x1, sp, #0x368
    ab74:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ab78:	52800020 	mov	w0, #0x1                   	// #1
    ab7c:	f901b7e2 	str	x2, [sp, #872]
    ab80:	f901bbf5 	str	x21, [sp, #880]
    ab84:	97ffe940 	bl	5084 <fwp_data.part.0.constprop.0>
    ab88:	91174283 	add	x3, x20, #0x5d0
    ab8c:	aa0003f5 	mov	x21, x0
    ab90:	f949d861 	ldr	x1, [x3, #5040]
    ab94:	f949ec60 	ldr	x0, [x3, #5080]
    ab98:	cb0102a1 	sub	x1, x21, x1
    ab9c:	eb00403f 	cmp	x1, x0, lsl #16
    aba0:	54000322 	b.cs	ac04 <f0+0xfd4>  // b.hs, b.nlast
    aba4:	d350fc22 	lsr	x2, x1, #16
    aba8:	f949fc63 	ldr	x3, [x3, #5112]
    abac:	8b020842 	add	x2, x2, x2, lsl #2
    abb0:	d37df042 	lsl	x2, x2, #3
    abb4:	8b020060 	add	x0, x3, x2
    abb8:	f9401017 	ldr	x23, [x0, #32]
    abbc:	b4000257 	cbz	x23, ac04 <f0+0xfd4>
    abc0:	38626862 	ldrb	w2, [x3, x2]
    abc4:	7100085f 	cmp	w2, #0x2
    abc8:	54009aa0 	b.eq	bf1c <f0+0x22ec>  // b.none
    abcc:	7100045f 	cmp	w2, #0x1
    abd0:	540001a1 	b.ne	ac04 <f0+0xfd4>  // b.any
    abd4:	29430002 	ldp	w2, w0, [x0, #24]
    abd8:	92403c21 	and	x1, x1, #0xffff
    abdc:	9b027c21 	mul	x1, x1, x2
    abe0:	d360fc21 	lsr	x1, x1, #32
    abe4:	eb00003f 	cmp	x1, x0
    abe8:	540000e2 	b.cs	ac04 <f0+0xfd4>  // b.hs, b.nlast
    abec:	8b0102f7 	add	x23, x23, x1
    abf0:	394002e0 	ldrb	w0, [x23]
    abf4:	7103fc1f 	cmp	w0, #0xff
    abf8:	5400ad60 	b.eq	c1a4 <f0+0x2574>  // b.none
    abfc:	52800020 	mov	w0, #0x1                   	// #1
    ac00:	390002e0 	strb	w0, [x23]
    ac04:	910de3e1 	add	x1, sp, #0x378
    ac08:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac0c:	52800020 	mov	w0, #0x1                   	// #1
    ac10:	f901bff7 	str	x23, [sp, #888]
    ac14:	f901c3f5 	str	x21, [sp, #896]
    ac18:	97ffe91b 	bl	5084 <fwp_data.part.0.constprop.0>
    ac1c:	97ffeaa6 	bl	56b4 <fwp_rc_fresh>
    ac20:	aa0003e2 	mov	x2, x0
    ac24:	910e23e1 	add	x1, sp, #0x388
    ac28:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ac2c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ac30:	52800020 	mov	w0, #0x1                   	// #1
    ac34:	f901c7f5 	str	x21, [sp, #904]
    ac38:	f901cbe2 	str	x2, [sp, #912]
    ac3c:	97ffe912 	bl	5084 <fwp_data.part.0.constprop.0>
    ac40:	97ffea9d 	bl	56b4 <fwp_rc_fresh>
    ac44:	aa0003e2 	mov	x2, x0
    ac48:	910e63e1 	add	x1, sp, #0x398
    ac4c:	52800020 	mov	w0, #0x1                   	// #1
    ac50:	f901cff7 	str	x23, [sp, #920]
    ac54:	f901d3e2 	str	x2, [sp, #928]
    ac58:	97ffe90b 	bl	5084 <fwp_data.part.0.constprop.0>
    ac5c:	97ffea96 	bl	56b4 <fwp_rc_fresh>
    ac60:	aa0003e2 	mov	x2, x0
    ac64:	910ea3e1 	add	x1, sp, #0x3a8
    ac68:	52800020 	mov	w0, #0x1                   	// #1
    ac6c:	f901d7f5 	str	x21, [sp, #936]
    ac70:	f901dbe2 	str	x2, [sp, #944]
    ac74:	97ffe904 	bl	5084 <fwp_data.part.0.constprop.0>
    ac78:	97ffea8f 	bl	56b4 <fwp_rc_fresh>
    ac7c:	aa0003e2 	mov	x2, x0
    ac80:	910ee3e1 	add	x1, sp, #0x3b8
    ac84:	52800020 	mov	w0, #0x1                   	// #1
    ac88:	f901dff7 	str	x23, [sp, #952]
    ac8c:	f901e3e2 	str	x2, [sp, #960]
    ac90:	97ffe8fd 	bl	5084 <fwp_data.part.0.constprop.0>
    ac94:	97ffea88 	bl	56b4 <fwp_rc_fresh>
    ac98:	aa0003e2 	mov	x2, x0
    ac9c:	910f23e1 	add	x1, sp, #0x3c8
    aca0:	52800020 	mov	w0, #0x1                   	// #1
    aca4:	f901e7f5 	str	x21, [sp, #968]
    aca8:	f901ebe2 	str	x2, [sp, #976]
    acac:	97ffe8f6 	bl	5084 <fwp_data.part.0.constprop.0>
    acb0:	91174283 	add	x3, x20, #0x5d0
    acb4:	aa0003f5 	mov	x21, x0
    acb8:	f949d861 	ldr	x1, [x3, #5040]
    acbc:	f949ec60 	ldr	x0, [x3, #5080]
    acc0:	cb0102a1 	sub	x1, x21, x1
    acc4:	eb00403f 	cmp	x1, x0, lsl #16
    acc8:	54000322 	b.cs	ad2c <f0+0x10fc>  // b.hs, b.nlast
    accc:	d350fc22 	lsr	x2, x1, #16
    acd0:	f949fc63 	ldr	x3, [x3, #5112]
    acd4:	8b020842 	add	x2, x2, x2, lsl #2
    acd8:	d37df042 	lsl	x2, x2, #3
    acdc:	8b020060 	add	x0, x3, x2
    ace0:	f9401017 	ldr	x23, [x0, #32]
    ace4:	b4000257 	cbz	x23, ad2c <f0+0x10fc>
    ace8:	38626862 	ldrb	w2, [x3, x2]
    acec:	7100085f 	cmp	w2, #0x2
    acf0:	54009100 	b.eq	bf10 <f0+0x22e0>  // b.none
    acf4:	7100045f 	cmp	w2, #0x1
    acf8:	540001a1 	b.ne	ad2c <f0+0x10fc>  // b.any
    acfc:	29430002 	ldp	w2, w0, [x0, #24]
    ad00:	92403c21 	and	x1, x1, #0xffff
    ad04:	9b027c21 	mul	x1, x1, x2
    ad08:	d360fc21 	lsr	x1, x1, #32
    ad0c:	eb00003f 	cmp	x1, x0
    ad10:	540000e2 	b.cs	ad2c <f0+0x10fc>  // b.hs, b.nlast
    ad14:	8b0102f7 	add	x23, x23, x1
    ad18:	394002e0 	ldrb	w0, [x23]
    ad1c:	7103fc1f 	cmp	w0, #0xff
    ad20:	5400a480 	b.eq	c1b0 <f0+0x2580>  // b.none
    ad24:	52800020 	mov	w0, #0x1                   	// #1
    ad28:	390002e0 	strb	w0, [x23]
    ad2c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad30:	910f63e1 	add	x1, sp, #0x3d8
    ad34:	52800020 	mov	w0, #0x1                   	// #1
    ad38:	f901efe2 	str	x2, [sp, #984]
    ad3c:	f901f3f5 	str	x21, [sp, #992]
    ad40:	97ffe8d1 	bl	5084 <fwp_data.part.0.constprop.0>
    ad44:	91174283 	add	x3, x20, #0x5d0
    ad48:	aa0003f5 	mov	x21, x0
    ad4c:	f949d861 	ldr	x1, [x3, #5040]
    ad50:	f949ec60 	ldr	x0, [x3, #5080]
    ad54:	cb0102a1 	sub	x1, x21, x1
    ad58:	eb00403f 	cmp	x1, x0, lsl #16
    ad5c:	54000322 	b.cs	adc0 <f0+0x1190>  // b.hs, b.nlast
    ad60:	d350fc22 	lsr	x2, x1, #16
    ad64:	f949fc63 	ldr	x3, [x3, #5112]
    ad68:	8b020842 	add	x2, x2, x2, lsl #2
    ad6c:	d37df042 	lsl	x2, x2, #3
    ad70:	8b020060 	add	x0, x3, x2
    ad74:	f9401017 	ldr	x23, [x0, #32]
    ad78:	b4000257 	cbz	x23, adc0 <f0+0x1190>
    ad7c:	38626862 	ldrb	w2, [x3, x2]
    ad80:	7100085f 	cmp	w2, #0x2
    ad84:	54008c00 	b.eq	bf04 <f0+0x22d4>  // b.none
    ad88:	7100045f 	cmp	w2, #0x1
    ad8c:	540001a1 	b.ne	adc0 <f0+0x1190>  // b.any
    ad90:	29430002 	ldp	w2, w0, [x0, #24]
    ad94:	92403c21 	and	x1, x1, #0xffff
    ad98:	9b027c21 	mul	x1, x1, x2
    ad9c:	d360fc21 	lsr	x1, x1, #32
    ada0:	eb00003f 	cmp	x1, x0
    ada4:	540000e2 	b.cs	adc0 <f0+0x1190>  // b.hs, b.nlast
    ada8:	8b0102f7 	add	x23, x23, x1
    adac:	394002e0 	ldrb	w0, [x23]
    adb0:	7103fc1f 	cmp	w0, #0xff
    adb4:	5400a040 	b.eq	c1bc <f0+0x258c>  // b.none
    adb8:	52800020 	mov	w0, #0x1                   	// #1
    adbc:	390002e0 	strb	w0, [x23]
    adc0:	910fa3e1 	add	x1, sp, #0x3e8
    adc4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    adc8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    adcc:	52800020 	mov	w0, #0x1                   	// #1
    add0:	f901f7f7 	str	x23, [sp, #1000]
    add4:	f901fbf5 	str	x21, [sp, #1008]
    add8:	97ffe8ab 	bl	5084 <fwp_data.part.0.constprop.0>
    addc:	97ffea36 	bl	56b4 <fwp_rc_fresh>
    ade0:	aa0003e2 	mov	x2, x0
    ade4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ade8:	910fe3e1 	add	x1, sp, #0x3f8
    adec:	52800020 	mov	w0, #0x1                   	// #1
    adf0:	f901ffe3 	str	x3, [sp, #1016]
    adf4:	f90203e2 	str	x2, [sp, #1024]
    adf8:	97ffe8a3 	bl	5084 <fwp_data.part.0.constprop.0>
    adfc:	97ffea2e 	bl	56b4 <fwp_rc_fresh>
    ae00:	aa0003e2 	mov	x2, x0
    ae04:	911023e1 	add	x1, sp, #0x408
    ae08:	52800020 	mov	w0, #0x1                   	// #1
    ae0c:	f90207f7 	str	x23, [sp, #1032]
    ae10:	f9020be2 	str	x2, [sp, #1040]
    ae14:	97ffe89c 	bl	5084 <fwp_data.part.0.constprop.0>
    ae18:	91174283 	add	x3, x20, #0x5d0
    ae1c:	aa0003f5 	mov	x21, x0
    ae20:	f949d861 	ldr	x1, [x3, #5040]
    ae24:	f949ec60 	ldr	x0, [x3, #5080]
    ae28:	cb0102a1 	sub	x1, x21, x1
    ae2c:	eb00403f 	cmp	x1, x0, lsl #16
    ae30:	54000322 	b.cs	ae94 <f0+0x1264>  // b.hs, b.nlast
    ae34:	d350fc22 	lsr	x2, x1, #16
    ae38:	f949fc63 	ldr	x3, [x3, #5112]
    ae3c:	8b020842 	add	x2, x2, x2, lsl #2
    ae40:	d37df042 	lsl	x2, x2, #3
    ae44:	8b020060 	add	x0, x3, x2
    ae48:	f9401017 	ldr	x23, [x0, #32]
    ae4c:	b4000257 	cbz	x23, ae94 <f0+0x1264>
    ae50:	38626862 	ldrb	w2, [x3, x2]
    ae54:	7100085f 	cmp	w2, #0x2
    ae58:	54008500 	b.eq	bef8 <f0+0x22c8>  // b.none
    ae5c:	7100045f 	cmp	w2, #0x1
    ae60:	540001a1 	b.ne	ae94 <f0+0x1264>  // b.any
    ae64:	29430002 	ldp	w2, w0, [x0, #24]
    ae68:	92403c21 	and	x1, x1, #0xffff
    ae6c:	9b027c21 	mul	x1, x1, x2
    ae70:	d360fc21 	lsr	x1, x1, #32
    ae74:	eb00003f 	cmp	x1, x0
    ae78:	540000e2 	b.cs	ae94 <f0+0x1264>  // b.hs, b.nlast
    ae7c:	8b0102f7 	add	x23, x23, x1
    ae80:	394002e0 	ldrb	w0, [x23]
    ae84:	7103fc1f 	cmp	w0, #0xff
    ae88:	54009a00 	b.eq	c1c8 <f0+0x2598>  // b.none
    ae8c:	52800020 	mov	w0, #0x1                   	// #1
    ae90:	390002e0 	strb	w0, [x23]
    ae94:	911063e1 	add	x1, sp, #0x418
    ae98:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ae9c:	52800020 	mov	w0, #0x1                   	// #1
    aea0:	f9020ff7 	str	x23, [sp, #1048]
    aea4:	f90213f5 	str	x21, [sp, #1056]
    aea8:	97ffe877 	bl	5084 <fwp_data.part.0.constprop.0>
    aeac:	97ffea02 	bl	56b4 <fwp_rc_fresh>
    aeb0:	aa0003e2 	mov	x2, x0
    aeb4:	9110a3e1 	add	x1, sp, #0x428
    aeb8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    aebc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    aec0:	52800020 	mov	w0, #0x1                   	// #1
    aec4:	f90217f5 	str	x21, [sp, #1064]
    aec8:	f9021be2 	str	x2, [sp, #1072]
    aecc:	97ffe86e 	bl	5084 <fwp_data.part.0.constprop.0>
    aed0:	97ffe9f9 	bl	56b4 <fwp_rc_fresh>
    aed4:	aa0003e2 	mov	x2, x0
    aed8:	9110e3e1 	add	x1, sp, #0x438
    aedc:	52800020 	mov	w0, #0x1                   	// #1
    aee0:	f9021ff7 	str	x23, [sp, #1080]
    aee4:	f90223e2 	str	x2, [sp, #1088]
    aee8:	97ffe867 	bl	5084 <fwp_data.part.0.constprop.0>
    aeec:	97ffe9f2 	bl	56b4 <fwp_rc_fresh>
    aef0:	aa0003e2 	mov	x2, x0
    aef4:	911123e1 	add	x1, sp, #0x448
    aef8:	52800020 	mov	w0, #0x1                   	// #1
    aefc:	f90227f5 	str	x21, [sp, #1096]
    af00:	f9022be2 	str	x2, [sp, #1104]
    af04:	97ffe860 	bl	5084 <fwp_data.part.0.constprop.0>
    af08:	97ffe9eb 	bl	56b4 <fwp_rc_fresh>
    af0c:	aa0003e2 	mov	x2, x0
    af10:	911163e1 	add	x1, sp, #0x458
    af14:	52800020 	mov	w0, #0x1                   	// #1
    af18:	f9022ff7 	str	x23, [sp, #1112]
    af1c:	f90233e2 	str	x2, [sp, #1120]
    af20:	97ffe859 	bl	5084 <fwp_data.part.0.constprop.0>
    af24:	91174283 	add	x3, x20, #0x5d0
    af28:	aa0003f5 	mov	x21, x0
    af2c:	f949d861 	ldr	x1, [x3, #5040]
    af30:	f949ec60 	ldr	x0, [x3, #5080]
    af34:	cb0102a1 	sub	x1, x21, x1
    af38:	eb00403f 	cmp	x1, x0, lsl #16
    af3c:	54000322 	b.cs	afa0 <f0+0x1370>  // b.hs, b.nlast
    af40:	d350fc22 	lsr	x2, x1, #16
    af44:	f949fc63 	ldr	x3, [x3, #5112]
    af48:	8b020842 	add	x2, x2, x2, lsl #2
    af4c:	d37df042 	lsl	x2, x2, #3
    af50:	8b020060 	add	x0, x3, x2
    af54:	f9401017 	ldr	x23, [x0, #32]
    af58:	b4000257 	cbz	x23, afa0 <f0+0x1370>
    af5c:	38626862 	ldrb	w2, [x3, x2]
    af60:	7100085f 	cmp	w2, #0x2
    af64:	54007c40 	b.eq	beec <f0+0x22bc>  // b.none
    af68:	7100045f 	cmp	w2, #0x1
    af6c:	540001a1 	b.ne	afa0 <f0+0x1370>  // b.any
    af70:	29430002 	ldp	w2, w0, [x0, #24]
    af74:	92403c21 	and	x1, x1, #0xffff
    af78:	9b027c21 	mul	x1, x1, x2
    af7c:	d360fc21 	lsr	x1, x1, #32
    af80:	eb00003f 	cmp	x1, x0
    af84:	540000e2 	b.cs	afa0 <f0+0x1370>  // b.hs, b.nlast
    af88:	8b0102f7 	add	x23, x23, x1
    af8c:	394002e0 	ldrb	w0, [x23]
    af90:	7103fc1f 	cmp	w0, #0xff
    af94:	54009200 	b.eq	c1d4 <f0+0x25a4>  // b.none
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	390002e0 	strb	w0, [x23]
    afa0:	9111a3e1 	add	x1, sp, #0x468
    afa4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    afa8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    afac:	52800020 	mov	w0, #0x1                   	// #1
    afb0:	f90237f7 	str	x23, [sp, #1128]
    afb4:	f9023bf5 	str	x21, [sp, #1136]
    afb8:	97ffe833 	bl	5084 <fwp_data.part.0.constprop.0>
    afbc:	97ffe9be 	bl	56b4 <fwp_rc_fresh>
    afc0:	aa0003e2 	mov	x2, x0
    afc4:	9111e3e1 	add	x1, sp, #0x478
    afc8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f9023ff5 	str	x21, [sp, #1144]
    afd4:	f90243e2 	str	x2, [sp, #1152]
    afd8:	97ffe82b 	bl	5084 <fwp_data.part.0.constprop.0>
    afdc:	97ffe9b6 	bl	56b4 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	911223e1 	add	x1, sp, #0x488
    afe8:	52800020 	mov	w0, #0x1                   	// #1
    afec:	f90247f7 	str	x23, [sp, #1160]
    aff0:	f9024be2 	str	x2, [sp, #1168]
    aff4:	97ffe824 	bl	5084 <fwp_data.part.0.constprop.0>
    aff8:	97ffe9af 	bl	56b4 <fwp_rc_fresh>
    affc:	aa0003e2 	mov	x2, x0
    b000:	911263e1 	add	x1, sp, #0x498
    b004:	52800020 	mov	w0, #0x1                   	// #1
    b008:	f9024ff5 	str	x21, [sp, #1176]
    b00c:	f90253e2 	str	x2, [sp, #1184]
    b010:	97ffe81d 	bl	5084 <fwp_data.part.0.constprop.0>
    b014:	91174283 	add	x3, x20, #0x5d0
    b018:	aa0003f5 	mov	x21, x0
    b01c:	f949d861 	ldr	x1, [x3, #5040]
    b020:	f949ec60 	ldr	x0, [x3, #5080]
    b024:	cb0102a1 	sub	x1, x21, x1
    b028:	eb00403f 	cmp	x1, x0, lsl #16
    b02c:	54000322 	b.cs	b090 <f0+0x1460>  // b.hs, b.nlast
    b030:	d350fc22 	lsr	x2, x1, #16
    b034:	f949fc63 	ldr	x3, [x3, #5112]
    b038:	8b020842 	add	x2, x2, x2, lsl #2
    b03c:	d37df042 	lsl	x2, x2, #3
    b040:	8b020060 	add	x0, x3, x2
    b044:	f9401017 	ldr	x23, [x0, #32]
    b048:	b4000257 	cbz	x23, b090 <f0+0x1460>
    b04c:	38626862 	ldrb	w2, [x3, x2]
    b050:	7100085f 	cmp	w2, #0x2
    b054:	54008300 	b.eq	c0b4 <f0+0x2484>  // b.none
    b058:	7100045f 	cmp	w2, #0x1
    b05c:	540001a1 	b.ne	b090 <f0+0x1460>  // b.any
    b060:	29430002 	ldp	w2, w0, [x0, #24]
    b064:	92403c21 	and	x1, x1, #0xffff
    b068:	9b027c21 	mul	x1, x1, x2
    b06c:	d360fc21 	lsr	x1, x1, #32
    b070:	eb00003f 	cmp	x1, x0
    b074:	540000e2 	b.cs	b090 <f0+0x1460>  // b.hs, b.nlast
    b078:	8b0102f7 	add	x23, x23, x1
    b07c:	394002e0 	ldrb	w0, [x23]
    b080:	7103fc1f 	cmp	w0, #0xff
    b084:	54008ae0 	b.eq	c1e0 <f0+0x25b0>  // b.none
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	390002e0 	strb	w0, [x23]
    b090:	9112a3e1 	add	x1, sp, #0x4a8
    b094:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b098:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b09c:	52800020 	mov	w0, #0x1                   	// #1
    b0a0:	f90257f7 	str	x23, [sp, #1192]
    b0a4:	f9025bf5 	str	x21, [sp, #1200]
    b0a8:	97ffe7f7 	bl	5084 <fwp_data.part.0.constprop.0>
    b0ac:	97ffe982 	bl	56b4 <fwp_rc_fresh>
    b0b0:	aa0003e2 	mov	x2, x0
    b0b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b0b8:	9112e3e1 	add	x1, sp, #0x4b8
    b0bc:	52800020 	mov	w0, #0x1                   	// #1
    b0c0:	f9025fe3 	str	x3, [sp, #1208]
    b0c4:	f90263e2 	str	x2, [sp, #1216]
    b0c8:	97ffe7ef 	bl	5084 <fwp_data.part.0.constprop.0>
    b0cc:	97ffe97a 	bl	56b4 <fwp_rc_fresh>
    b0d0:	aa0003e2 	mov	x2, x0
    b0d4:	911323e1 	add	x1, sp, #0x4c8
    b0d8:	52800020 	mov	w0, #0x1                   	// #1
    b0dc:	f90267f7 	str	x23, [sp, #1224]
    b0e0:	f9026be2 	str	x2, [sp, #1232]
    b0e4:	97ffe7e8 	bl	5084 <fwp_data.part.0.constprop.0>
    b0e8:	91174283 	add	x3, x20, #0x5d0
    b0ec:	aa0003f5 	mov	x21, x0
    b0f0:	f949d861 	ldr	x1, [x3, #5040]
    b0f4:	f949ec60 	ldr	x0, [x3, #5080]
    b0f8:	cb0102a1 	sub	x1, x21, x1
    b0fc:	eb00403f 	cmp	x1, x0, lsl #16
    b100:	54000322 	b.cs	b164 <f0+0x1534>  // b.hs, b.nlast
    b104:	d350fc22 	lsr	x2, x1, #16
    b108:	f949fc63 	ldr	x3, [x3, #5112]
    b10c:	8b020842 	add	x2, x2, x2, lsl #2
    b110:	d37df042 	lsl	x2, x2, #3
    b114:	8b020060 	add	x0, x3, x2
    b118:	f9401017 	ldr	x23, [x0, #32]
    b11c:	b4000257 	cbz	x23, b164 <f0+0x1534>
    b120:	38626862 	ldrb	w2, [x3, x2]
    b124:	7100085f 	cmp	w2, #0x2
    b128:	54007c00 	b.eq	c0a8 <f0+0x2478>  // b.none
    b12c:	7100045f 	cmp	w2, #0x1
    b130:	540001a1 	b.ne	b164 <f0+0x1534>  // b.any
    b134:	29430002 	ldp	w2, w0, [x0, #24]
    b138:	92403c21 	and	x1, x1, #0xffff
    b13c:	9b027c21 	mul	x1, x1, x2
    b140:	d360fc21 	lsr	x1, x1, #32
    b144:	eb00003f 	cmp	x1, x0
    b148:	540000e2 	b.cs	b164 <f0+0x1534>  // b.hs, b.nlast
    b14c:	8b0102f7 	add	x23, x23, x1
    b150:	394002e0 	ldrb	w0, [x23]
    b154:	7103fc1f 	cmp	w0, #0xff
    b158:	540084a0 	b.eq	c1ec <f0+0x25bc>  // b.none
    b15c:	52800020 	mov	w0, #0x1                   	// #1
    b160:	390002e0 	strb	w0, [x23]
    b164:	911363e1 	add	x1, sp, #0x4d8
    b168:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b16c:	52800020 	mov	w0, #0x1                   	// #1
    b170:	f9026ff7 	str	x23, [sp, #1240]
    b174:	f90273f5 	str	x21, [sp, #1248]
    b178:	97ffe7c3 	bl	5084 <fwp_data.part.0.constprop.0>
    b17c:	97ffe94e 	bl	56b4 <fwp_rc_fresh>
    b180:	aa0003e2 	mov	x2, x0
    b184:	9113a3e1 	add	x1, sp, #0x4e8
    b188:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b18c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b190:	52800020 	mov	w0, #0x1                   	// #1
    b194:	f90277f5 	str	x21, [sp, #1256]
    b198:	f9027be2 	str	x2, [sp, #1264]
    b19c:	97ffe7ba 	bl	5084 <fwp_data.part.0.constprop.0>
    b1a0:	97ffe945 	bl	56b4 <fwp_rc_fresh>
    b1a4:	aa0003e2 	mov	x2, x0
    b1a8:	9113e3e1 	add	x1, sp, #0x4f8
    b1ac:	52800020 	mov	w0, #0x1                   	// #1
    b1b0:	f9027ff7 	str	x23, [sp, #1272]
    b1b4:	f90283e2 	str	x2, [sp, #1280]
    b1b8:	97ffe7b3 	bl	5084 <fwp_data.part.0.constprop.0>
    b1bc:	97ffe93e 	bl	56b4 <fwp_rc_fresh>
    b1c0:	aa0003e2 	mov	x2, x0
    b1c4:	911423e1 	add	x1, sp, #0x508
    b1c8:	52800020 	mov	w0, #0x1                   	// #1
    b1cc:	f90287f5 	str	x21, [sp, #1288]
    b1d0:	f9028be2 	str	x2, [sp, #1296]
    b1d4:	97ffe7ac 	bl	5084 <fwp_data.part.0.constprop.0>
    b1d8:	97ffe937 	bl	56b4 <fwp_rc_fresh>
    b1dc:	aa0003e2 	mov	x2, x0
    b1e0:	911463e1 	add	x1, sp, #0x518
    b1e4:	52800020 	mov	w0, #0x1                   	// #1
    b1e8:	f9028ff7 	str	x23, [sp, #1304]
    b1ec:	f90293e2 	str	x2, [sp, #1312]
    b1f0:	97ffe7a5 	bl	5084 <fwp_data.part.0.constprop.0>
    b1f4:	91174283 	add	x3, x20, #0x5d0
    b1f8:	aa0003f5 	mov	x21, x0
    b1fc:	f949d861 	ldr	x1, [x3, #5040]
    b200:	f949ec60 	ldr	x0, [x3, #5080]
    b204:	cb0102a1 	sub	x1, x21, x1
    b208:	eb00403f 	cmp	x1, x0, lsl #16
    b20c:	54000322 	b.cs	b270 <f0+0x1640>  // b.hs, b.nlast
    b210:	d350fc22 	lsr	x2, x1, #16
    b214:	f949fc63 	ldr	x3, [x3, #5112]
    b218:	8b020842 	add	x2, x2, x2, lsl #2
    b21c:	d37df042 	lsl	x2, x2, #3
    b220:	8b020060 	add	x0, x3, x2
    b224:	f9401017 	ldr	x23, [x0, #32]
    b228:	b4000257 	cbz	x23, b270 <f0+0x1640>
    b22c:	38626862 	ldrb	w2, [x3, x2]
    b230:	7100085f 	cmp	w2, #0x2
    b234:	54007340 	b.eq	c09c <f0+0x246c>  // b.none
    b238:	7100045f 	cmp	w2, #0x1
    b23c:	540001a1 	b.ne	b270 <f0+0x1640>  // b.any
    b240:	29430002 	ldp	w2, w0, [x0, #24]
    b244:	92403c21 	and	x1, x1, #0xffff
    b248:	9b027c21 	mul	x1, x1, x2
    b24c:	d360fc21 	lsr	x1, x1, #32
    b250:	eb00003f 	cmp	x1, x0
    b254:	540000e2 	b.cs	b270 <f0+0x1640>  // b.hs, b.nlast
    b258:	8b0102f7 	add	x23, x23, x1
    b25c:	394002e0 	ldrb	w0, [x23]
    b260:	7103fc1f 	cmp	w0, #0xff
    b264:	54007ca0 	b.eq	c1f8 <f0+0x25c8>  // b.none
    b268:	52800020 	mov	w0, #0x1                   	// #1
    b26c:	390002e0 	strb	w0, [x23]
    b270:	9114a3e1 	add	x1, sp, #0x528
    b274:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b278:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b27c:	52800020 	mov	w0, #0x1                   	// #1
    b280:	f90297f7 	str	x23, [sp, #1320]
    b284:	f9029bf5 	str	x21, [sp, #1328]
    b288:	97ffe77f 	bl	5084 <fwp_data.part.0.constprop.0>
    b28c:	97ffe90a 	bl	56b4 <fwp_rc_fresh>
    b290:	aa0003e2 	mov	x2, x0
    b294:	9114e3e1 	add	x1, sp, #0x538
    b298:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b29c:	52800020 	mov	w0, #0x1                   	// #1
    b2a0:	f9029ff5 	str	x21, [sp, #1336]
    b2a4:	f902a3e2 	str	x2, [sp, #1344]
    b2a8:	97ffe777 	bl	5084 <fwp_data.part.0.constprop.0>
    b2ac:	97ffe902 	bl	56b4 <fwp_rc_fresh>
    b2b0:	aa0003e2 	mov	x2, x0
    b2b4:	911523e1 	add	x1, sp, #0x548
    b2b8:	52800020 	mov	w0, #0x1                   	// #1
    b2bc:	f902a7f7 	str	x23, [sp, #1352]
    b2c0:	f902abe2 	str	x2, [sp, #1360]
    b2c4:	97ffe770 	bl	5084 <fwp_data.part.0.constprop.0>
    b2c8:	97ffe8fb 	bl	56b4 <fwp_rc_fresh>
    b2cc:	aa0003e2 	mov	x2, x0
    b2d0:	911563e1 	add	x1, sp, #0x558
    b2d4:	52800020 	mov	w0, #0x1                   	// #1
    b2d8:	f902aff5 	str	x21, [sp, #1368]
    b2dc:	f902b3e2 	str	x2, [sp, #1376]
    b2e0:	97ffe769 	bl	5084 <fwp_data.part.0.constprop.0>
    b2e4:	97ffe8f4 	bl	56b4 <fwp_rc_fresh>
    b2e8:	aa0003e2 	mov	x2, x0
    b2ec:	9115a3e1 	add	x1, sp, #0x568
    b2f0:	52800020 	mov	w0, #0x1                   	// #1
    b2f4:	f902b7f7 	str	x23, [sp, #1384]
    b2f8:	f902bbe2 	str	x2, [sp, #1392]
    b2fc:	97ffe762 	bl	5084 <fwp_data.part.0.constprop.0>
    b300:	97ffe8ed 	bl	56b4 <fwp_rc_fresh>
    b304:	aa0003e2 	mov	x2, x0
    b308:	9115e3e1 	add	x1, sp, #0x578
    b30c:	52800020 	mov	w0, #0x1                   	// #1
    b310:	f902bff5 	str	x21, [sp, #1400]
    b314:	f902c3e2 	str	x2, [sp, #1408]
    b318:	97ffe75b 	bl	5084 <fwp_data.part.0.constprop.0>
    b31c:	97ffe8e6 	bl	56b4 <fwp_rc_fresh>
    b320:	aa0003e2 	mov	x2, x0
    b324:	911623e1 	add	x1, sp, #0x588
    b328:	52800020 	mov	w0, #0x1                   	// #1
    b32c:	f902c7f7 	str	x23, [sp, #1416]
    b330:	f902cbe2 	str	x2, [sp, #1424]
    b334:	97ffe754 	bl	5084 <fwp_data.part.0.constprop.0>
    b338:	97ffe8df 	bl	56b4 <fwp_rc_fresh>
    b33c:	aa0003e2 	mov	x2, x0
    b340:	911663e1 	add	x1, sp, #0x598
    b344:	52800020 	mov	w0, #0x1                   	// #1
    b348:	f902cff5 	str	x21, [sp, #1432]
    b34c:	f902d3e2 	str	x2, [sp, #1440]
    b350:	97ffe74d 	bl	5084 <fwp_data.part.0.constprop.0>
    b354:	97ffe8d8 	bl	56b4 <fwp_rc_fresh>
    b358:	aa0003e2 	mov	x2, x0
    b35c:	9116a3e1 	add	x1, sp, #0x5a8
    b360:	52800020 	mov	w0, #0x1                   	// #1
    b364:	f902d7f7 	str	x23, [sp, #1448]
    b368:	f902dbe2 	str	x2, [sp, #1456]
    b36c:	97ffe746 	bl	5084 <fwp_data.part.0.constprop.0>
    b370:	97ffe8d1 	bl	56b4 <fwp_rc_fresh>
    b374:	aa0003e2 	mov	x2, x0
    b378:	9116e3e1 	add	x1, sp, #0x5b8
    b37c:	52800020 	mov	w0, #0x1                   	// #1
    b380:	f902dff5 	str	x21, [sp, #1464]
    b384:	f902e3e2 	str	x2, [sp, #1472]
    b388:	97ffe73f 	bl	5084 <fwp_data.part.0.constprop.0>
    b38c:	97ffe8ca 	bl	56b4 <fwp_rc_fresh>
    b390:	aa0003e2 	mov	x2, x0
    b394:	911723e1 	add	x1, sp, #0x5c8
    b398:	52800020 	mov	w0, #0x1                   	// #1
    b39c:	f902e7f7 	str	x23, [sp, #1480]
    b3a0:	f902ebe2 	str	x2, [sp, #1488]
    b3a4:	97ffe738 	bl	5084 <fwp_data.part.0.constprop.0>
    b3a8:	97ffe8c3 	bl	56b4 <fwp_rc_fresh>
    b3ac:	aa0003e2 	mov	x2, x0
    b3b0:	911763e1 	add	x1, sp, #0x5d8
    b3b4:	52800020 	mov	w0, #0x1                   	// #1
    b3b8:	f902eff5 	str	x21, [sp, #1496]
    b3bc:	f902f3e2 	str	x2, [sp, #1504]
    b3c0:	97ffe731 	bl	5084 <fwp_data.part.0.constprop.0>
    b3c4:	91174283 	add	x3, x20, #0x5d0
    b3c8:	aa0003f7 	mov	x23, x0
    b3cc:	f949d861 	ldr	x1, [x3, #5040]
    b3d0:	f949ec60 	ldr	x0, [x3, #5080]
    b3d4:	cb0102e1 	sub	x1, x23, x1
    b3d8:	eb00403f 	cmp	x1, x0, lsl #16
    b3dc:	54000322 	b.cs	b440 <f0+0x1810>  // b.hs, b.nlast
    b3e0:	d350fc22 	lsr	x2, x1, #16
    b3e4:	f949fc63 	ldr	x3, [x3, #5112]
    b3e8:	8b020842 	add	x2, x2, x2, lsl #2
    b3ec:	d37df042 	lsl	x2, x2, #3
    b3f0:	8b020060 	add	x0, x3, x2
    b3f4:	f9401015 	ldr	x21, [x0, #32]
    b3f8:	b4000255 	cbz	x21, b440 <f0+0x1810>
    b3fc:	38626862 	ldrb	w2, [x3, x2]
    b400:	7100085f 	cmp	w2, #0x2
    b404:	54006460 	b.eq	c090 <f0+0x2460>  // b.none
    b408:	7100045f 	cmp	w2, #0x1
    b40c:	540001a1 	b.ne	b440 <f0+0x1810>  // b.any
    b410:	29430002 	ldp	w2, w0, [x0, #24]
    b414:	92403c21 	and	x1, x1, #0xffff
    b418:	9b027c21 	mul	x1, x1, x2
    b41c:	d360fc21 	lsr	x1, x1, #32
    b420:	eb00003f 	cmp	x1, x0
    b424:	540000e2 	b.cs	b440 <f0+0x1810>  // b.hs, b.nlast
    b428:	8b0102b5 	add	x21, x21, x1
    b42c:	394002a0 	ldrb	w0, [x21]
    b430:	7103fc1f 	cmp	w0, #0xff
    b434:	54006e80 	b.eq	c204 <f0+0x25d4>  // b.none
    b438:	52800020 	mov	w0, #0x1                   	// #1
    b43c:	390002a0 	strb	w0, [x21]
    b440:	9117a3e1 	add	x1, sp, #0x5e8
    b444:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b448:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b44c:	52800020 	mov	w0, #0x1                   	// #1
    b450:	f902f7f5 	str	x21, [sp, #1512]
    b454:	f902fbf7 	str	x23, [sp, #1520]
    b458:	97ffe70b 	bl	5084 <fwp_data.part.0.constprop.0>
    b45c:	97ffe896 	bl	56b4 <fwp_rc_fresh>
    b460:	aa0003e2 	mov	x2, x0
    b464:	9117e3e1 	add	x1, sp, #0x5f8
    b468:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b46c:	52800020 	mov	w0, #0x1                   	// #1
    b470:	f902fff7 	str	x23, [sp, #1528]
    b474:	f90303e2 	str	x2, [sp, #1536]
    b478:	97ffe703 	bl	5084 <fwp_data.part.0.constprop.0>
    b47c:	97ffe88e 	bl	56b4 <fwp_rc_fresh>
    b480:	aa0003e2 	mov	x2, x0
    b484:	911823e1 	add	x1, sp, #0x608
    b488:	52800020 	mov	w0, #0x1                   	// #1
    b48c:	f90307f5 	str	x21, [sp, #1544]
    b490:	f9030be2 	str	x2, [sp, #1552]
    b494:	97ffe6fc 	bl	5084 <fwp_data.part.0.constprop.0>
    b498:	97ffe887 	bl	56b4 <fwp_rc_fresh>
    b49c:	aa0003e2 	mov	x2, x0
    b4a0:	911863e1 	add	x1, sp, #0x618
    b4a4:	52800020 	mov	w0, #0x1                   	// #1
    b4a8:	f9030ff7 	str	x23, [sp, #1560]
    b4ac:	f90313e2 	str	x2, [sp, #1568]
    b4b0:	97ffe6f5 	bl	5084 <fwp_data.part.0.constprop.0>
    b4b4:	97ffe880 	bl	56b4 <fwp_rc_fresh>
    b4b8:	aa0003e2 	mov	x2, x0
    b4bc:	9118a3e1 	add	x1, sp, #0x628
    b4c0:	52800020 	mov	w0, #0x1                   	// #1
    b4c4:	f90317f5 	str	x21, [sp, #1576]
    b4c8:	f9031be2 	str	x2, [sp, #1584]
    b4cc:	97ffe6ee 	bl	5084 <fwp_data.part.0.constprop.0>
    b4d0:	97ffe879 	bl	56b4 <fwp_rc_fresh>
    b4d4:	aa0003e2 	mov	x2, x0
    b4d8:	9118e3e1 	add	x1, sp, #0x638
    b4dc:	52800020 	mov	w0, #0x1                   	// #1
    b4e0:	f9031ff7 	str	x23, [sp, #1592]
    b4e4:	f90323e2 	str	x2, [sp, #1600]
    b4e8:	97ffe6e7 	bl	5084 <fwp_data.part.0.constprop.0>
    b4ec:	97ffe872 	bl	56b4 <fwp_rc_fresh>
    b4f0:	aa0003e2 	mov	x2, x0
    b4f4:	911923e1 	add	x1, sp, #0x648
    b4f8:	52800020 	mov	w0, #0x1                   	// #1
    b4fc:	f90327f5 	str	x21, [sp, #1608]
    b500:	f9032be2 	str	x2, [sp, #1616]
    b504:	97ffe6e0 	bl	5084 <fwp_data.part.0.constprop.0>
    b508:	91174283 	add	x3, x20, #0x5d0
    b50c:	aa0003f5 	mov	x21, x0
    b510:	f949d861 	ldr	x1, [x3, #5040]
    b514:	f949ec60 	ldr	x0, [x3, #5080]
    b518:	cb0102a1 	sub	x1, x21, x1
    b51c:	eb00403f 	cmp	x1, x0, lsl #16
    b520:	54000322 	b.cs	b584 <f0+0x1954>  // b.hs, b.nlast
    b524:	d350fc22 	lsr	x2, x1, #16
    b528:	f949fc63 	ldr	x3, [x3, #5112]
    b52c:	8b020842 	add	x2, x2, x2, lsl #2
    b530:	d37df042 	lsl	x2, x2, #3
    b534:	8b020060 	add	x0, x3, x2
    b538:	f9401017 	ldr	x23, [x0, #32]
    b53c:	b4000257 	cbz	x23, b584 <f0+0x1954>
    b540:	38626862 	ldrb	w2, [x3, x2]
    b544:	7100085f 	cmp	w2, #0x2
    b548:	540059e0 	b.eq	c084 <f0+0x2454>  // b.none
    b54c:	7100045f 	cmp	w2, #0x1
    b550:	540001a1 	b.ne	b584 <f0+0x1954>  // b.any
    b554:	29430002 	ldp	w2, w0, [x0, #24]
    b558:	92403c21 	and	x1, x1, #0xffff
    b55c:	9b027c21 	mul	x1, x1, x2
    b560:	d360fc21 	lsr	x1, x1, #32
    b564:	eb00003f 	cmp	x1, x0
    b568:	540000e2 	b.cs	b584 <f0+0x1954>  // b.hs, b.nlast
    b56c:	8b0102f7 	add	x23, x23, x1
    b570:	394002e0 	ldrb	w0, [x23]
    b574:	7103fc1f 	cmp	w0, #0xff
    b578:	540064c0 	b.eq	c210 <f0+0x25e0>  // b.none
    b57c:	52800020 	mov	w0, #0x1                   	// #1
    b580:	390002e0 	strb	w0, [x23]
    b584:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b588:	911963e1 	add	x1, sp, #0x658
    b58c:	52800020 	mov	w0, #0x1                   	// #1
    b590:	f9032fe2 	str	x2, [sp, #1624]
    b594:	f90333f5 	str	x21, [sp, #1632]
    b598:	97ffe6bb 	bl	5084 <fwp_data.part.0.constprop.0>
    b59c:	91174283 	add	x3, x20, #0x5d0
    b5a0:	aa0003f5 	mov	x21, x0
    b5a4:	f949d861 	ldr	x1, [x3, #5040]
    b5a8:	f949ec60 	ldr	x0, [x3, #5080]
    b5ac:	cb0102a1 	sub	x1, x21, x1
    b5b0:	eb00403f 	cmp	x1, x0, lsl #16
    b5b4:	54000322 	b.cs	b618 <f0+0x19e8>  // b.hs, b.nlast
    b5b8:	d350fc22 	lsr	x2, x1, #16
    b5bc:	f949fc63 	ldr	x3, [x3, #5112]
    b5c0:	8b020842 	add	x2, x2, x2, lsl #2
    b5c4:	d37df042 	lsl	x2, x2, #3
    b5c8:	8b020060 	add	x0, x3, x2
    b5cc:	f9401017 	ldr	x23, [x0, #32]
    b5d0:	b4000257 	cbz	x23, b618 <f0+0x19e8>
    b5d4:	38626862 	ldrb	w2, [x3, x2]
    b5d8:	7100085f 	cmp	w2, #0x2
    b5dc:	540054e0 	b.eq	c078 <f0+0x2448>  // b.none
    b5e0:	7100045f 	cmp	w2, #0x1
    b5e4:	540001a1 	b.ne	b618 <f0+0x19e8>  // b.any
    b5e8:	29430002 	ldp	w2, w0, [x0, #24]
    b5ec:	92403c21 	and	x1, x1, #0xffff
    b5f0:	9b027c21 	mul	x1, x1, x2
    b5f4:	d360fc21 	lsr	x1, x1, #32
    b5f8:	eb00003f 	cmp	x1, x0
    b5fc:	540000e2 	b.cs	b618 <f0+0x19e8>  // b.hs, b.nlast
    b600:	8b0102f7 	add	x23, x23, x1
    b604:	394002e0 	ldrb	w0, [x23]
    b608:	7103fc1f 	cmp	w0, #0xff
    b60c:	54006080 	b.eq	c21c <f0+0x25ec>  // b.none
    b610:	52800020 	mov	w0, #0x1                   	// #1
    b614:	390002e0 	strb	w0, [x23]
    b618:	9119a3e1 	add	x1, sp, #0x668
    b61c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b620:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b624:	52800020 	mov	w0, #0x1                   	// #1
    b628:	f90337f7 	str	x23, [sp, #1640]
    b62c:	f9033bf5 	str	x21, [sp, #1648]
    b630:	97ffe695 	bl	5084 <fwp_data.part.0.constprop.0>
    b634:	97ffe820 	bl	56b4 <fwp_rc_fresh>
    b638:	aa0003e2 	mov	x2, x0
    b63c:	9119e3e1 	add	x1, sp, #0x678
    b640:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b644:	52800020 	mov	w0, #0x1                   	// #1
    b648:	f9033ff5 	str	x21, [sp, #1656]
    b64c:	f90343e2 	str	x2, [sp, #1664]
    b650:	97ffe68d 	bl	5084 <fwp_data.part.0.constprop.0>
    b654:	97ffe818 	bl	56b4 <fwp_rc_fresh>
    b658:	aa0003e2 	mov	x2, x0
    b65c:	911a23e1 	add	x1, sp, #0x688
    b660:	52800020 	mov	w0, #0x1                   	// #1
    b664:	f90347f7 	str	x23, [sp, #1672]
    b668:	f9034be2 	str	x2, [sp, #1680]
    b66c:	97ffe686 	bl	5084 <fwp_data.part.0.constprop.0>
    b670:	97ffe811 	bl	56b4 <fwp_rc_fresh>
    b674:	aa0003e2 	mov	x2, x0
    b678:	911a63e1 	add	x1, sp, #0x698
    b67c:	52800020 	mov	w0, #0x1                   	// #1
    b680:	f9034ff5 	str	x21, [sp, #1688]
    b684:	f90353e2 	str	x2, [sp, #1696]
    b688:	97ffe67f 	bl	5084 <fwp_data.part.0.constprop.0>
    b68c:	91174283 	add	x3, x20, #0x5d0
    b690:	aa0003f5 	mov	x21, x0
    b694:	f949d861 	ldr	x1, [x3, #5040]
    b698:	f949ec60 	ldr	x0, [x3, #5080]
    b69c:	cb0102a1 	sub	x1, x21, x1
    b6a0:	eb00403f 	cmp	x1, x0, lsl #16
    b6a4:	54000322 	b.cs	b708 <f0+0x1ad8>  // b.hs, b.nlast
    b6a8:	d350fc22 	lsr	x2, x1, #16
    b6ac:	f949fc63 	ldr	x3, [x3, #5112]
    b6b0:	8b020842 	add	x2, x2, x2, lsl #2
    b6b4:	d37df042 	lsl	x2, x2, #3
    b6b8:	8b020060 	add	x0, x3, x2
    b6bc:	f9401017 	ldr	x23, [x0, #32]
    b6c0:	b4000257 	cbz	x23, b708 <f0+0x1ad8>
    b6c4:	38626862 	ldrb	w2, [x3, x2]
    b6c8:	7100085f 	cmp	w2, #0x2
    b6cc:	54004d00 	b.eq	c06c <f0+0x243c>  // b.none
    b6d0:	7100045f 	cmp	w2, #0x1
    b6d4:	540001a1 	b.ne	b708 <f0+0x1ad8>  // b.any
    b6d8:	29430002 	ldp	w2, w0, [x0, #24]
    b6dc:	92403c21 	and	x1, x1, #0xffff
    b6e0:	9b027c21 	mul	x1, x1, x2
    b6e4:	d360fc21 	lsr	x1, x1, #32
    b6e8:	eb00003f 	cmp	x1, x0
    b6ec:	540000e2 	b.cs	b708 <f0+0x1ad8>  // b.hs, b.nlast
    b6f0:	8b0102f7 	add	x23, x23, x1
    b6f4:	394002e0 	ldrb	w0, [x23]
    b6f8:	7103fc1f 	cmp	w0, #0xff
    b6fc:	54005960 	b.eq	c228 <f0+0x25f8>  // b.none
    b700:	52800020 	mov	w0, #0x1                   	// #1
    b704:	390002e0 	strb	w0, [x23]
    b708:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b70c:	911aa3e1 	add	x1, sp, #0x6a8
    b710:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b714:	52800020 	mov	w0, #0x1                   	// #1
    b718:	f90357e2 	str	x2, [sp, #1704]
    b71c:	f9035bf5 	str	x21, [sp, #1712]
    b720:	97ffe659 	bl	5084 <fwp_data.part.0.constprop.0>
    b724:	97ffe7e4 	bl	56b4 <fwp_rc_fresh>
    b728:	aa0003e2 	mov	x2, x0
    b72c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b730:	911ae3e1 	add	x1, sp, #0x6b8
    b734:	52800020 	mov	w0, #0x1                   	// #1
    b738:	f9035fe3 	str	x3, [sp, #1720]
    b73c:	f90363e2 	str	x2, [sp, #1728]
    b740:	97ffe651 	bl	5084 <fwp_data.part.0.constprop.0>
    b744:	91174283 	add	x3, x20, #0x5d0
    b748:	aa0003f5 	mov	x21, x0
    b74c:	f949d861 	ldr	x1, [x3, #5040]
    b750:	f949ec60 	ldr	x0, [x3, #5080]
    b754:	cb0102a1 	sub	x1, x21, x1
    b758:	eb00403f 	cmp	x1, x0, lsl #16
    b75c:	54000322 	b.cs	b7c0 <f0+0x1b90>  // b.hs, b.nlast
    b760:	d350fc22 	lsr	x2, x1, #16
    b764:	f949fc63 	ldr	x3, [x3, #5112]
    b768:	8b020842 	add	x2, x2, x2, lsl #2
    b76c:	d37df042 	lsl	x2, x2, #3
    b770:	8b020060 	add	x0, x3, x2
    b774:	f9401017 	ldr	x23, [x0, #32]
    b778:	b4000257 	cbz	x23, b7c0 <f0+0x1b90>
    b77c:	38626862 	ldrb	w2, [x3, x2]
    b780:	7100085f 	cmp	w2, #0x2
    b784:	540046e0 	b.eq	c060 <f0+0x2430>  // b.none
    b788:	7100045f 	cmp	w2, #0x1
    b78c:	540001a1 	b.ne	b7c0 <f0+0x1b90>  // b.any
    b790:	29430002 	ldp	w2, w0, [x0, #24]
    b794:	92403c21 	and	x1, x1, #0xffff
    b798:	9b027c21 	mul	x1, x1, x2
    b79c:	d360fc21 	lsr	x1, x1, #32
    b7a0:	eb00003f 	cmp	x1, x0
    b7a4:	540000e2 	b.cs	b7c0 <f0+0x1b90>  // b.hs, b.nlast
    b7a8:	8b0102f7 	add	x23, x23, x1
    b7ac:	394002e0 	ldrb	w0, [x23]
    b7b0:	7103fc1f 	cmp	w0, #0xff
    b7b4:	54005400 	b.eq	c234 <f0+0x2604>  // b.none
    b7b8:	52800020 	mov	w0, #0x1                   	// #1
    b7bc:	390002e0 	strb	w0, [x23]
    b7c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b7c4:	911b23e1 	add	x1, sp, #0x6c8
    b7c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b7cc:	52800020 	mov	w0, #0x1                   	// #1
    b7d0:	f90367e2 	str	x2, [sp, #1736]
    b7d4:	f9036bf5 	str	x21, [sp, #1744]
    b7d8:	97ffe62b 	bl	5084 <fwp_data.part.0.constprop.0>
    b7dc:	91174283 	add	x3, x20, #0x5d0
    b7e0:	aa0003f5 	mov	x21, x0
    b7e4:	f949d861 	ldr	x1, [x3, #5040]
    b7e8:	f949ec60 	ldr	x0, [x3, #5080]
    b7ec:	cb0102a1 	sub	x1, x21, x1
    b7f0:	eb00403f 	cmp	x1, x0, lsl #16
    b7f4:	54000322 	b.cs	b858 <f0+0x1c28>  // b.hs, b.nlast
    b7f8:	d350fc22 	lsr	x2, x1, #16
    b7fc:	f949fc63 	ldr	x3, [x3, #5112]
    b800:	8b020842 	add	x2, x2, x2, lsl #2
    b804:	d37df042 	lsl	x2, x2, #3
    b808:	8b020060 	add	x0, x3, x2
    b80c:	f9401017 	ldr	x23, [x0, #32]
    b810:	b4000257 	cbz	x23, b858 <f0+0x1c28>
    b814:	38626862 	ldrb	w2, [x3, x2]
    b818:	7100085f 	cmp	w2, #0x2
    b81c:	540041c0 	b.eq	c054 <f0+0x2424>  // b.none
    b820:	7100045f 	cmp	w2, #0x1
    b824:	540001a1 	b.ne	b858 <f0+0x1c28>  // b.any
    b828:	29430002 	ldp	w2, w0, [x0, #24]
    b82c:	92403c21 	and	x1, x1, #0xffff
    b830:	9b027c21 	mul	x1, x1, x2
    b834:	d360fc21 	lsr	x1, x1, #32
    b838:	eb00003f 	cmp	x1, x0
    b83c:	540000e2 	b.cs	b858 <f0+0x1c28>  // b.hs, b.nlast
    b840:	8b0102f7 	add	x23, x23, x1
    b844:	394002e0 	ldrb	w0, [x23]
    b848:	7103fc1f 	cmp	w0, #0xff
    b84c:	54004fa0 	b.eq	c240 <f0+0x2610>  // b.none
    b850:	52800020 	mov	w0, #0x1                   	// #1
    b854:	390002e0 	strb	w0, [x23]
    b858:	911b63e1 	add	x1, sp, #0x6d8
    b85c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b860:	52800020 	mov	w0, #0x1                   	// #1
    b864:	f9036ff7 	str	x23, [sp, #1752]
    b868:	f90373f5 	str	x21, [sp, #1760]
    b86c:	97ffe606 	bl	5084 <fwp_data.part.0.constprop.0>
    b870:	97ffe791 	bl	56b4 <fwp_rc_fresh>
    b874:	aa0003e2 	mov	x2, x0
    b878:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b87c:	911ba3e1 	add	x1, sp, #0x6e8
    b880:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b884:	52800020 	mov	w0, #0x1                   	// #1
    b888:	f90377e3 	str	x3, [sp, #1768]
    b88c:	f9037be2 	str	x2, [sp, #1776]
    b890:	97ffe5fd 	bl	5084 <fwp_data.part.0.constprop.0>
    b894:	97ffe788 	bl	56b4 <fwp_rc_fresh>
    b898:	aa0003e2 	mov	x2, x0
    b89c:	911be3e1 	add	x1, sp, #0x6f8
    b8a0:	52800020 	mov	w0, #0x1                   	// #1
    b8a4:	f9037ff7 	str	x23, [sp, #1784]
    b8a8:	f90383e2 	str	x2, [sp, #1792]
    b8ac:	97ffe5f6 	bl	5084 <fwp_data.part.0.constprop.0>
    b8b0:	91174283 	add	x3, x20, #0x5d0
    b8b4:	aa0003f5 	mov	x21, x0
    b8b8:	f949d861 	ldr	x1, [x3, #5040]
    b8bc:	f949ec60 	ldr	x0, [x3, #5080]
    b8c0:	cb0102a1 	sub	x1, x21, x1
    b8c4:	eb00403f 	cmp	x1, x0, lsl #16
    b8c8:	54000322 	b.cs	b92c <f0+0x1cfc>  // b.hs, b.nlast
    b8cc:	d350fc22 	lsr	x2, x1, #16
    b8d0:	f949fc63 	ldr	x3, [x3, #5112]
    b8d4:	8b020842 	add	x2, x2, x2, lsl #2
    b8d8:	d37df042 	lsl	x2, x2, #3
    b8dc:	8b020060 	add	x0, x3, x2
    b8e0:	f9401017 	ldr	x23, [x0, #32]
    b8e4:	b4000257 	cbz	x23, b92c <f0+0x1cfc>
    b8e8:	38626862 	ldrb	w2, [x3, x2]
    b8ec:	7100085f 	cmp	w2, #0x2
    b8f0:	54003ac0 	b.eq	c048 <f0+0x2418>  // b.none
    b8f4:	7100045f 	cmp	w2, #0x1
    b8f8:	540001a1 	b.ne	b92c <f0+0x1cfc>  // b.any
    b8fc:	29430002 	ldp	w2, w0, [x0, #24]
    b900:	92403c21 	and	x1, x1, #0xffff
    b904:	9b027c21 	mul	x1, x1, x2
    b908:	d360fc21 	lsr	x1, x1, #32
    b90c:	eb00003f 	cmp	x1, x0
    b910:	540000e2 	b.cs	b92c <f0+0x1cfc>  // b.hs, b.nlast
    b914:	8b0102f7 	add	x23, x23, x1
    b918:	394002e0 	ldrb	w0, [x23]
    b91c:	7103fc1f 	cmp	w0, #0xff
    b920:	54004960 	b.eq	c24c <f0+0x261c>  // b.none
    b924:	52800020 	mov	w0, #0x1                   	// #1
    b928:	390002e0 	strb	w0, [x23]
    b92c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b930:	911c23e1 	add	x1, sp, #0x708
    b934:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b938:	52800020 	mov	w0, #0x1                   	// #1
    b93c:	f90387e2 	str	x2, [sp, #1800]
    b940:	f9038bf5 	str	x21, [sp, #1808]
    b944:	97ffe5d0 	bl	5084 <fwp_data.part.0.constprop.0>
    b948:	97ffe75b 	bl	56b4 <fwp_rc_fresh>
    b94c:	aa0003e2 	mov	x2, x0
    b950:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b954:	911c63e1 	add	x1, sp, #0x718
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f9038fe3 	str	x3, [sp, #1816]
    b960:	f90393e2 	str	x2, [sp, #1824]
    b964:	97ffe5c8 	bl	5084 <fwp_data.part.0.constprop.0>
    b968:	91174283 	add	x3, x20, #0x5d0
    b96c:	aa0003f5 	mov	x21, x0
    b970:	f949d861 	ldr	x1, [x3, #5040]
    b974:	f949ec60 	ldr	x0, [x3, #5080]
    b978:	cb0102a1 	sub	x1, x21, x1
    b97c:	eb00403f 	cmp	x1, x0, lsl #16
    b980:	54000322 	b.cs	b9e4 <f0+0x1db4>  // b.hs, b.nlast
    b984:	d350fc22 	lsr	x2, x1, #16
    b988:	f949fc63 	ldr	x3, [x3, #5112]
    b98c:	8b020842 	add	x2, x2, x2, lsl #2
    b990:	d37df042 	lsl	x2, x2, #3
    b994:	8b020060 	add	x0, x3, x2
    b998:	f9401017 	ldr	x23, [x0, #32]
    b99c:	b4000257 	cbz	x23, b9e4 <f0+0x1db4>
    b9a0:	38626862 	ldrb	w2, [x3, x2]
    b9a4:	7100085f 	cmp	w2, #0x2
    b9a8:	540034a0 	b.eq	c03c <f0+0x240c>  // b.none
    b9ac:	7100045f 	cmp	w2, #0x1
    b9b0:	540001a1 	b.ne	b9e4 <f0+0x1db4>  // b.any
    b9b4:	29430002 	ldp	w2, w0, [x0, #24]
    b9b8:	92403c21 	and	x1, x1, #0xffff
    b9bc:	9b027c21 	mul	x1, x1, x2
    b9c0:	d360fc21 	lsr	x1, x1, #32
    b9c4:	eb00003f 	cmp	x1, x0
    b9c8:	540000e2 	b.cs	b9e4 <f0+0x1db4>  // b.hs, b.nlast
    b9cc:	8b0102f7 	add	x23, x23, x1
    b9d0:	394002e0 	ldrb	w0, [x23]
    b9d4:	7103fc1f 	cmp	w0, #0xff
    b9d8:	54004400 	b.eq	c258 <f0+0x2628>  // b.none
    b9dc:	52800020 	mov	w0, #0x1                   	// #1
    b9e0:	390002e0 	strb	w0, [x23]
    b9e4:	911ca3e1 	add	x1, sp, #0x728
    b9e8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b9ec:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b9f0:	52800020 	mov	w0, #0x1                   	// #1
    b9f4:	f90397f7 	str	x23, [sp, #1832]
    b9f8:	f9039bf5 	str	x21, [sp, #1840]
    b9fc:	97ffe5a2 	bl	5084 <fwp_data.part.0.constprop.0>
    ba00:	97ffe72d 	bl	56b4 <fwp_rc_fresh>
    ba04:	aa0003e2 	mov	x2, x0
    ba08:	911ce3e1 	add	x1, sp, #0x738
    ba0c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba10:	52800020 	mov	w0, #0x1                   	// #1
    ba14:	f9039ff5 	str	x21, [sp, #1848]
    ba18:	f903a3e2 	str	x2, [sp, #1856]
    ba1c:	97ffe59a 	bl	5084 <fwp_data.part.0.constprop.0>
    ba20:	97ffe725 	bl	56b4 <fwp_rc_fresh>
    ba24:	aa0003e2 	mov	x2, x0
    ba28:	911d23e1 	add	x1, sp, #0x748
    ba2c:	52800020 	mov	w0, #0x1                   	// #1
    ba30:	f903a7f7 	str	x23, [sp, #1864]
    ba34:	f903abe2 	str	x2, [sp, #1872]
    ba38:	97ffe593 	bl	5084 <fwp_data.part.0.constprop.0>
    ba3c:	97ffe71e 	bl	56b4 <fwp_rc_fresh>
    ba40:	aa0003e2 	mov	x2, x0
    ba44:	911d63e1 	add	x1, sp, #0x758
    ba48:	52800020 	mov	w0, #0x1                   	// #1
    ba4c:	f903aff5 	str	x21, [sp, #1880]
    ba50:	f903b3e2 	str	x2, [sp, #1888]
    ba54:	97ffe58c 	bl	5084 <fwp_data.part.0.constprop.0>
    ba58:	97ffe717 	bl	56b4 <fwp_rc_fresh>
    ba5c:	aa0003e2 	mov	x2, x0
    ba60:	911da3e1 	add	x1, sp, #0x768
    ba64:	52800020 	mov	w0, #0x1                   	// #1
    ba68:	f903b7f7 	str	x23, [sp, #1896]
    ba6c:	f903bbe2 	str	x2, [sp, #1904]
    ba70:	97ffe585 	bl	5084 <fwp_data.part.0.constprop.0>
    ba74:	97ffe710 	bl	56b4 <fwp_rc_fresh>
    ba78:	aa0003e2 	mov	x2, x0
    ba7c:	911de3e1 	add	x1, sp, #0x778
    ba80:	52800020 	mov	w0, #0x1                   	// #1
    ba84:	f903bff5 	str	x21, [sp, #1912]
    ba88:	f903c3e2 	str	x2, [sp, #1920]
    ba8c:	97ffe57e 	bl	5084 <fwp_data.part.0.constprop.0>
    ba90:	97ffe709 	bl	56b4 <fwp_rc_fresh>
    ba94:	aa0003e2 	mov	x2, x0
    ba98:	911e23e1 	add	x1, sp, #0x788
    ba9c:	52800020 	mov	w0, #0x1                   	// #1
    baa0:	f903c7f7 	str	x23, [sp, #1928]
    baa4:	f903cbe2 	str	x2, [sp, #1936]
    baa8:	97ffe577 	bl	5084 <fwp_data.part.0.constprop.0>
    baac:	97ffe702 	bl	56b4 <fwp_rc_fresh>
    bab0:	aa0003e2 	mov	x2, x0
    bab4:	911e63e1 	add	x1, sp, #0x798
    bab8:	52800020 	mov	w0, #0x1                   	// #1
    babc:	f903cff5 	str	x21, [sp, #1944]
    bac0:	f903d3e2 	str	x2, [sp, #1952]
    bac4:	97ffe570 	bl	5084 <fwp_data.part.0.constprop.0>
    bac8:	91174283 	add	x3, x20, #0x5d0
    bacc:	aa0003f5 	mov	x21, x0
    bad0:	f949d861 	ldr	x1, [x3, #5040]
    bad4:	f949ec60 	ldr	x0, [x3, #5080]
    bad8:	cb0102a1 	sub	x1, x21, x1
    badc:	eb00403f 	cmp	x1, x0, lsl #16
    bae0:	54000322 	b.cs	bb44 <f0+0x1f14>  // b.hs, b.nlast
    bae4:	d350fc22 	lsr	x2, x1, #16
    bae8:	f949fc63 	ldr	x3, [x3, #5112]
    baec:	8b020842 	add	x2, x2, x2, lsl #2
    baf0:	d37df042 	lsl	x2, x2, #3
    baf4:	8b020060 	add	x0, x3, x2
    baf8:	f9401017 	ldr	x23, [x0, #32]
    bafc:	b4000257 	cbz	x23, bb44 <f0+0x1f14>
    bb00:	38626862 	ldrb	w2, [x3, x2]
    bb04:	7100085f 	cmp	w2, #0x2
    bb08:	54002940 	b.eq	c030 <f0+0x2400>  // b.none
    bb0c:	7100045f 	cmp	w2, #0x1
    bb10:	540001a1 	b.ne	bb44 <f0+0x1f14>  // b.any
    bb14:	29430002 	ldp	w2, w0, [x0, #24]
    bb18:	92403c21 	and	x1, x1, #0xffff
    bb1c:	9b027c21 	mul	x1, x1, x2
    bb20:	d360fc21 	lsr	x1, x1, #32
    bb24:	eb00003f 	cmp	x1, x0
    bb28:	540000e2 	b.cs	bb44 <f0+0x1f14>  // b.hs, b.nlast
    bb2c:	8b0102f7 	add	x23, x23, x1
    bb30:	394002e0 	ldrb	w0, [x23]
    bb34:	7103fc1f 	cmp	w0, #0xff
    bb38:	54003960 	b.eq	c264 <f0+0x2634>  // b.none
    bb3c:	52800020 	mov	w0, #0x1                   	// #1
    bb40:	390002e0 	strb	w0, [x23]
    bb44:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bb48:	911ea3e1 	add	x1, sp, #0x7a8
    bb4c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bb50:	52800020 	mov	w0, #0x1                   	// #1
    bb54:	f903d7e2 	str	x2, [sp, #1960]
    bb58:	f903dbf5 	str	x21, [sp, #1968]
    bb5c:	97ffe54a 	bl	5084 <fwp_data.part.0.constprop.0>
    bb60:	91174283 	add	x3, x20, #0x5d0
    bb64:	aa0003f5 	mov	x21, x0
    bb68:	f949d861 	ldr	x1, [x3, #5040]
    bb6c:	f949ec60 	ldr	x0, [x3, #5080]
    bb70:	cb0102a1 	sub	x1, x21, x1
    bb74:	eb00403f 	cmp	x1, x0, lsl #16
    bb78:	54000322 	b.cs	bbdc <f0+0x1fac>  // b.hs, b.nlast
    bb7c:	d350fc22 	lsr	x2, x1, #16
    bb80:	f949fc63 	ldr	x3, [x3, #5112]
    bb84:	8b020842 	add	x2, x2, x2, lsl #2
    bb88:	d37df042 	lsl	x2, x2, #3
    bb8c:	8b020060 	add	x0, x3, x2
    bb90:	f9401017 	ldr	x23, [x0, #32]
    bb94:	b4000257 	cbz	x23, bbdc <f0+0x1fac>
    bb98:	38626862 	ldrb	w2, [x3, x2]
    bb9c:	7100085f 	cmp	w2, #0x2
    bba0:	54002420 	b.eq	c024 <f0+0x23f4>  // b.none
    bba4:	7100045f 	cmp	w2, #0x1
    bba8:	540001a1 	b.ne	bbdc <f0+0x1fac>  // b.any
    bbac:	29430002 	ldp	w2, w0, [x0, #24]
    bbb0:	92403c21 	and	x1, x1, #0xffff
    bbb4:	9b027c21 	mul	x1, x1, x2
    bbb8:	d360fc21 	lsr	x1, x1, #32
    bbbc:	eb00003f 	cmp	x1, x0
    bbc0:	540000e2 	b.cs	bbdc <f0+0x1fac>  // b.hs, b.nlast
    bbc4:	8b0102f7 	add	x23, x23, x1
    bbc8:	394002e0 	ldrb	w0, [x23]
    bbcc:	7103fc1f 	cmp	w0, #0xff
    bbd0:	54003500 	b.eq	c270 <f0+0x2640>  // b.none
    bbd4:	52800020 	mov	w0, #0x1                   	// #1
    bbd8:	390002e0 	strb	w0, [x23]
    bbdc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbe0:	911ee3e1 	add	x1, sp, #0x7b8
    bbe4:	52800020 	mov	w0, #0x1                   	// #1
    bbe8:	f903dfe2 	str	x2, [sp, #1976]
    bbec:	f903e3f5 	str	x21, [sp, #1984]
    bbf0:	97ffe525 	bl	5084 <fwp_data.part.0.constprop.0>
    bbf4:	91174283 	add	x3, x20, #0x5d0
    bbf8:	aa0003f5 	mov	x21, x0
    bbfc:	f949d861 	ldr	x1, [x3, #5040]
    bc00:	f949ec60 	ldr	x0, [x3, #5080]
    bc04:	cb0102a1 	sub	x1, x21, x1
    bc08:	eb00403f 	cmp	x1, x0, lsl #16
    bc0c:	54000322 	b.cs	bc70 <f0+0x2040>  // b.hs, b.nlast
    bc10:	d350fc22 	lsr	x2, x1, #16
    bc14:	f949fc63 	ldr	x3, [x3, #5112]
    bc18:	8b020842 	add	x2, x2, x2, lsl #2
    bc1c:	d37df042 	lsl	x2, x2, #3
    bc20:	8b020060 	add	x0, x3, x2
    bc24:	f9401017 	ldr	x23, [x0, #32]
    bc28:	b4000257 	cbz	x23, bc70 <f0+0x2040>
    bc2c:	38626862 	ldrb	w2, [x3, x2]
    bc30:	7100085f 	cmp	w2, #0x2
    bc34:	54001f20 	b.eq	c018 <f0+0x23e8>  // b.none
    bc38:	7100045f 	cmp	w2, #0x1
    bc3c:	540001a1 	b.ne	bc70 <f0+0x2040>  // b.any
    bc40:	29430002 	ldp	w2, w0, [x0, #24]
    bc44:	92403c21 	and	x1, x1, #0xffff
    bc48:	9b027c21 	mul	x1, x1, x2
    bc4c:	d360fc21 	lsr	x1, x1, #32
    bc50:	eb00003f 	cmp	x1, x0
    bc54:	540000e2 	b.cs	bc70 <f0+0x2040>  // b.hs, b.nlast
    bc58:	8b0102f7 	add	x23, x23, x1
    bc5c:	394002e0 	ldrb	w0, [x23]
    bc60:	7103fc1f 	cmp	w0, #0xff
    bc64:	540030c0 	b.eq	c27c <f0+0x264c>  // b.none
    bc68:	52800020 	mov	w0, #0x1                   	// #1
    bc6c:	390002e0 	strb	w0, [x23]
    bc70:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc74:	911f23e1 	add	x1, sp, #0x7c8
    bc78:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc7c:	52800020 	mov	w0, #0x1                   	// #1
    bc80:	f903e7e2 	str	x2, [sp, #1992]
    bc84:	f903ebf5 	str	x21, [sp, #2000]
    bc88:	97ffe4ff 	bl	5084 <fwp_data.part.0.constprop.0>
    bc8c:	97ffe68a 	bl	56b4 <fwp_rc_fresh>
    bc90:	aa0003e2 	mov	x2, x0
    bc94:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bc98:	911f63e1 	add	x1, sp, #0x7d8
    bc9c:	52800020 	mov	w0, #0x1                   	// #1
    bca0:	f903efe3 	str	x3, [sp, #2008]
    bca4:	f903f3e2 	str	x2, [sp, #2016]
    bca8:	97ffe4f7 	bl	5084 <fwp_data.part.0.constprop.0>
    bcac:	91174283 	add	x3, x20, #0x5d0
    bcb0:	aa0003f5 	mov	x21, x0
    bcb4:	f949d861 	ldr	x1, [x3, #5040]
    bcb8:	f949ec60 	ldr	x0, [x3, #5080]
    bcbc:	cb0102a1 	sub	x1, x21, x1
    bcc0:	eb00403f 	cmp	x1, x0, lsl #16
    bcc4:	54000322 	b.cs	bd28 <f0+0x20f8>  // b.hs, b.nlast
    bcc8:	d350fc22 	lsr	x2, x1, #16
    bccc:	f949fc63 	ldr	x3, [x3, #5112]
    bcd0:	8b020842 	add	x2, x2, x2, lsl #2
    bcd4:	d37df042 	lsl	x2, x2, #3
    bcd8:	8b020060 	add	x0, x3, x2
    bcdc:	f9401017 	ldr	x23, [x0, #32]
    bce0:	b4000257 	cbz	x23, bd28 <f0+0x20f8>
    bce4:	38626862 	ldrb	w2, [x3, x2]
    bce8:	7100085f 	cmp	w2, #0x2
    bcec:	54001900 	b.eq	c00c <f0+0x23dc>  // b.none
    bcf0:	7100045f 	cmp	w2, #0x1
    bcf4:	540001a1 	b.ne	bd28 <f0+0x20f8>  // b.any
    bcf8:	29430002 	ldp	w2, w0, [x0, #24]
    bcfc:	92403c21 	and	x1, x1, #0xffff
    bd00:	9b027c21 	mul	x1, x1, x2
    bd04:	d360fc21 	lsr	x1, x1, #32
    bd08:	eb00003f 	cmp	x1, x0
    bd0c:	540000e2 	b.cs	bd28 <f0+0x20f8>  // b.hs, b.nlast
    bd10:	8b0102f7 	add	x23, x23, x1
    bd14:	394002e0 	ldrb	w0, [x23]
    bd18:	7103fc1f 	cmp	w0, #0xff
    bd1c:	54002b60 	b.eq	c288 <f0+0x2658>  // b.none
    bd20:	52800020 	mov	w0, #0x1                   	// #1
    bd24:	390002e0 	strb	w0, [x23]
    bd28:	911fa3e1 	add	x1, sp, #0x7e8
    bd2c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd30:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd34:	52800020 	mov	w0, #0x1                   	// #1
    bd38:	f903f7f7 	str	x23, [sp, #2024]
    bd3c:	91174294 	add	x20, x20, #0x5d0
    bd40:	f903fbf5 	str	x21, [sp, #2032]
    bd44:	97ffe4d0 	bl	5084 <fwp_data.part.0.constprop.0>
    bd48:	97ffe65b 	bl	56b4 <fwp_rc_fresh>
    bd4c:	aa0003e2 	mov	x2, x0
    bd50:	911fe3e1 	add	x1, sp, #0x7f8
    bd54:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd58:	52800020 	mov	w0, #0x1                   	// #1
    bd5c:	f903fff5 	str	x21, [sp, #2040]
    bd60:	f90403e2 	str	x2, [sp, #2048]
    bd64:	97ffe4c8 	bl	5084 <fwp_data.part.0.constprop.0>
    bd68:	97ffe653 	bl	56b4 <fwp_rc_fresh>
    bd6c:	aa0003e2 	mov	x2, x0
    bd70:	912023e1 	add	x1, sp, #0x808
    bd74:	52800020 	mov	w0, #0x1                   	// #1
    bd78:	f90407f7 	str	x23, [sp, #2056]
    bd7c:	f9040be2 	str	x2, [sp, #2064]
    bd80:	97ffe4c1 	bl	5084 <fwp_data.part.0.constprop.0>
    bd84:	97ffe64c 	bl	56b4 <fwp_rc_fresh>
    bd88:	aa0003e2 	mov	x2, x0
    bd8c:	912063e1 	add	x1, sp, #0x818
    bd90:	52800020 	mov	w0, #0x1                   	// #1
    bd94:	f9040ff5 	str	x21, [sp, #2072]
    bd98:	f90413e2 	str	x2, [sp, #2080]
    bd9c:	97ffe4ba 	bl	5084 <fwp_data.part.0.constprop.0>
    bda0:	f949da81 	ldr	x1, [x20, #5040]
    bda4:	aa0003f5 	mov	x21, x0
    bda8:	f949ee80 	ldr	x0, [x20, #5080]
    bdac:	cb0102a1 	sub	x1, x21, x1
    bdb0:	eb00403f 	cmp	x1, x0, lsl #16
    bdb4:	54000322 	b.cs	be18 <f0+0x21e8>  // b.hs, b.nlast
    bdb8:	d350fc22 	lsr	x2, x1, #16
    bdbc:	f949fe83 	ldr	x3, [x20, #5112]
    bdc0:	8b020842 	add	x2, x2, x2, lsl #2
    bdc4:	d37df042 	lsl	x2, x2, #3
    bdc8:	8b020060 	add	x0, x3, x2
    bdcc:	f9401014 	ldr	x20, [x0, #32]
    bdd0:	b4000254 	cbz	x20, be18 <f0+0x21e8>
    bdd4:	38626862 	ldrb	w2, [x3, x2]
    bdd8:	7100085f 	cmp	w2, #0x2
    bddc:	54001120 	b.eq	c000 <f0+0x23d0>  // b.none
    bde0:	7100045f 	cmp	w2, #0x1
    bde4:	540001a1 	b.ne	be18 <f0+0x21e8>  // b.any
    bde8:	29430002 	ldp	w2, w0, [x0, #24]
    bdec:	92403c21 	and	x1, x1, #0xffff
    bdf0:	9b027c21 	mul	x1, x1, x2
    bdf4:	d360fc21 	lsr	x1, x1, #32
    bdf8:	eb00003f 	cmp	x1, x0
    bdfc:	540000e2 	b.cs	be18 <f0+0x21e8>  // b.hs, b.nlast
    be00:	8b010294 	add	x20, x20, x1
    be04:	39400280 	ldrb	w0, [x20]
    be08:	7103fc1f 	cmp	w0, #0xff
    be0c:	540015a0 	b.eq	c0c0 <f0+0x2490>  // b.none
    be10:	52800020 	mov	w0, #0x1                   	// #1
    be14:	39000280 	strb	w0, [x20]
    be18:	9120a3e1 	add	x1, sp, #0x828
    be1c:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    be20:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    be24:	52800020 	mov	w0, #0x1                   	// #1
    be28:	f90417f4 	str	x20, [sp, #2088]
    be2c:	f9041bf5 	str	x21, [sp, #2096]
    be30:	97ffe495 	bl	5084 <fwp_data.part.0.constprop.0>
    be34:	97ffe620 	bl	56b4 <fwp_rc_fresh>
    be38:	aa0003e2 	mov	x2, x0
    be3c:	9120e3e1 	add	x1, sp, #0x838
    be40:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    be44:	52800020 	mov	w0, #0x1                   	// #1
    be48:	f9041fe3 	str	x3, [sp, #2104]
    be4c:	f90423e2 	str	x2, [sp, #2112]
    be50:	97ffe48d 	bl	5084 <fwp_data.part.0.constprop.0>
    be54:	97ffe618 	bl	56b4 <fwp_rc_fresh>
    be58:	aa0003e2 	mov	x2, x0
    be5c:	aa1603e1 	mov	x1, x22
    be60:	52800020 	mov	w0, #0x1                   	// #1
    be64:	f90427f4 	str	x20, [sp, #2120]
    be68:	f9042be2 	str	x2, [sp, #2128]
    be6c:	97ffe486 	bl	5084 <fwp_data.part.0.constprop.0>
    be70:	97ffe611 	bl	56b4 <fwp_rc_fresh>
    be74:	aa0003f5 	mov	x21, x0
    be78:	aa1303e1 	mov	x1, x19
    be7c:	97fff0a5 	bl	8110 <fwp_hof0.constprop.0>
    be80:	aa0003f4 	mov	x20, x0
    be84:	aa1503e0 	mov	x0, x21
    be88:	97ffe712 	bl	5ad0 <fwp_drop0>
    be8c:	aa1303e0 	mov	x0, x19
    be90:	97ffe710 	bl	5ad0 <fwp_drop0>
    be94:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    be98:	f947f400 	ldr	x0, [x0, #4072]
    be9c:	f9442fe2 	ldr	x2, [sp, #2136]
    bea0:	f9400001 	ldr	x1, [x0]
    bea4:	eb010042 	subs	x2, x2, x1
    bea8:	d2800001 	mov	x1, #0x0                   	// #0
    beac:	54001f41 	b.ne	c294 <f0+0x2664>  // b.any
    beb0:	912183ff 	add	sp, sp, #0x860
    beb4:	aa1403e0 	mov	x0, x20
    beb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    bebc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bec0:	a94363f7 	ldp	x23, x24, [sp, #48]
    bec4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    bec8:	a94573fb 	ldp	x27, x28, [sp, #80]
    becc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    bed0:	d65f03c0 	ret
    bed4:	aa1b03e0 	mov	x0, x27
    bed8:	97ffe266 	bl	4870 <fwp_rc_forget_slot>
    bedc:	17fff79d 	b	9d50 <f0+0x120>
    bee0:	72003c5f 	tst	w2, #0xffff
    bee4:	54fef381 	b.ne	9d54 <f0+0x124>  // b.any
    bee8:	17fff797 	b	9d44 <f0+0x114>
    beec:	72003c3f 	tst	w1, #0xffff
    bef0:	54ff8581 	b.ne	afa0 <f0+0x1370>  // b.any
    bef4:	17fffc26 	b	af8c <f0+0x135c>
    bef8:	72003c3f 	tst	w1, #0xffff
    befc:	54ff7cc1 	b.ne	ae94 <f0+0x1264>  // b.any
    bf00:	17fffbe0 	b	ae80 <f0+0x1250>
    bf04:	72003c3f 	tst	w1, #0xffff
    bf08:	54ff75c1 	b.ne	adc0 <f0+0x1190>  // b.any
    bf0c:	17fffba8 	b	adac <f0+0x117c>
    bf10:	72003c3f 	tst	w1, #0xffff
    bf14:	54ff70c1 	b.ne	ad2c <f0+0x10fc>  // b.any
    bf18:	17fffb80 	b	ad18 <f0+0x10e8>
    bf1c:	72003c3f 	tst	w1, #0xffff
    bf20:	54ff6721 	b.ne	ac04 <f0+0xfd4>  // b.any
    bf24:	17fffb33 	b	abf0 <f0+0xfc0>
    bf28:	72003c3f 	tst	w1, #0xffff
    bf2c:	54ff6201 	b.ne	ab6c <f0+0xf3c>  // b.any
    bf30:	17fffb0a 	b	ab58 <f0+0xf28>
    bf34:	72003c3f 	tst	w1, #0xffff
    bf38:	54ff56a1 	b.ne	aa0c <f0+0xddc>  // b.any
    bf3c:	17fffaaf 	b	a9f8 <f0+0xdc8>
    bf40:	72003c3f 	tst	w1, #0xffff
    bf44:	54ff51a1 	b.ne	a978 <f0+0xd48>  // b.any
    bf48:	17fffa87 	b	a964 <f0+0xd34>
    bf4c:	72003c3f 	tst	w1, #0xffff
    bf50:	54ff07e1 	b.ne	a04c <f0+0x41c>  // b.any
    bf54:	17fff839 	b	a038 <f0+0x408>
    bf58:	72003c3f 	tst	w1, #0xffff
    bf5c:	54fefcc1 	b.ne	9ef4 <f0+0x2c4>  // b.any
    bf60:	17fff7e0 	b	9ee0 <f0+0x2b0>
    bf64:	72003c3f 	tst	w1, #0xffff
    bf68:	54fef6e1 	b.ne	9e44 <f0+0x214>  // b.any
    bf6c:	17fff7b1 	b	9e30 <f0+0x200>
    bf70:	72003c3f 	tst	w1, #0xffff
    bf74:	54ff1cc1 	b.ne	a30c <f0+0x6dc>  // b.any
    bf78:	17fff8e0 	b	a2f8 <f0+0x6c8>
    bf7c:	72003c3f 	tst	w1, #0xffff
    bf80:	54ff16e1 	b.ne	a25c <f0+0x62c>  // b.any
    bf84:	17fff8b1 	b	a248 <f0+0x618>
    bf88:	72003c3f 	tst	w1, #0xffff
    bf8c:	54ff1101 	b.ne	a1ac <f0+0x57c>  // b.any
    bf90:	17fff882 	b	a198 <f0+0x568>
    bf94:	72003c3f 	tst	w1, #0xffff
    bf98:	54ff0b21 	b.ne	a0fc <f0+0x4cc>  // b.any
    bf9c:	17fff853 	b	a0e8 <f0+0x4b8>
    bfa0:	72003c3f 	tst	w1, #0xffff
    bfa4:	54ff48e1 	b.ne	a8c0 <f0+0xc90>  // b.any
    bfa8:	17fffa41 	b	a8ac <f0+0xc7c>
    bfac:	72003c3f 	tst	w1, #0xffff
    bfb0:	54ff43c1 	b.ne	a828 <f0+0xbf8>  // b.any
    bfb4:	17fffa18 	b	a814 <f0+0xbe4>
    bfb8:	72003c3f 	tst	w1, #0xffff
    bfbc:	54ff3ec1 	b.ne	a794 <f0+0xb64>  // b.any
    bfc0:	17fff9f0 	b	a780 <f0+0xb50>
    bfc4:	72003c3f 	tst	w1, #0xffff
    bfc8:	54ff36e1 	b.ne	a6a4 <f0+0xa74>  // b.any
    bfcc:	17fff9b1 	b	a690 <f0+0xa60>
    bfd0:	72003c3f 	tst	w1, #0xffff
    bfd4:	54ff2fe1 	b.ne	a5d0 <f0+0x9a0>  // b.any
    bfd8:	17fff979 	b	a5bc <f0+0x98c>
    bfdc:	72003c3f 	tst	w1, #0xffff
    bfe0:	54ff29c1 	b.ne	a518 <f0+0x8e8>  // b.any
    bfe4:	17fff948 	b	a504 <f0+0x8d4>
    bfe8:	72003c3f 	tst	w1, #0xffff
    bfec:	54ff2321 	b.ne	a450 <f0+0x820>  // b.any
    bff0:	17fff913 	b	a43c <f0+0x80c>
    bff4:	72003c3f 	tst	w1, #0xffff
    bff8:	54ff1e21 	b.ne	a3bc <f0+0x78c>  // b.any
    bffc:	17fff8eb 	b	a3a8 <f0+0x778>
    c000:	72003c3f 	tst	w1, #0xffff
    c004:	54fff0a1 	b.ne	be18 <f0+0x21e8>  // b.any
    c008:	17ffff7f 	b	be04 <f0+0x21d4>
    c00c:	72003c3f 	tst	w1, #0xffff
    c010:	54ffe8c1 	b.ne	bd28 <f0+0x20f8>  // b.any
    c014:	17ffff40 	b	bd14 <f0+0x20e4>
    c018:	72003c3f 	tst	w1, #0xffff
    c01c:	54ffe2a1 	b.ne	bc70 <f0+0x2040>  // b.any
    c020:	17ffff0f 	b	bc5c <f0+0x202c>
    c024:	72003c3f 	tst	w1, #0xffff
    c028:	54ffdda1 	b.ne	bbdc <f0+0x1fac>  // b.any
    c02c:	17fffee7 	b	bbc8 <f0+0x1f98>
    c030:	72003c3f 	tst	w1, #0xffff
    c034:	54ffd881 	b.ne	bb44 <f0+0x1f14>  // b.any
    c038:	17fffebe 	b	bb30 <f0+0x1f00>
    c03c:	72003c3f 	tst	w1, #0xffff
    c040:	54ffcd21 	b.ne	b9e4 <f0+0x1db4>  // b.any
    c044:	17fffe63 	b	b9d0 <f0+0x1da0>
    c048:	72003c3f 	tst	w1, #0xffff
    c04c:	54ffc701 	b.ne	b92c <f0+0x1cfc>  // b.any
    c050:	17fffe32 	b	b918 <f0+0x1ce8>
    c054:	72003c3f 	tst	w1, #0xffff
    c058:	54ffc001 	b.ne	b858 <f0+0x1c28>  // b.any
    c05c:	17fffdfa 	b	b844 <f0+0x1c14>
    c060:	72003c3f 	tst	w1, #0xffff
    c064:	54ffbae1 	b.ne	b7c0 <f0+0x1b90>  // b.any
    c068:	17fffdd1 	b	b7ac <f0+0x1b7c>
    c06c:	72003c3f 	tst	w1, #0xffff
    c070:	54ffb4c1 	b.ne	b708 <f0+0x1ad8>  // b.any
    c074:	17fffda0 	b	b6f4 <f0+0x1ac4>
    c078:	72003c3f 	tst	w1, #0xffff
    c07c:	54fface1 	b.ne	b618 <f0+0x19e8>  // b.any
    c080:	17fffd61 	b	b604 <f0+0x19d4>
    c084:	72003c3f 	tst	w1, #0xffff
    c088:	54ffa7e1 	b.ne	b584 <f0+0x1954>  // b.any
    c08c:	17fffd39 	b	b570 <f0+0x1940>
    c090:	72003c3f 	tst	w1, #0xffff
    c094:	54ff9d61 	b.ne	b440 <f0+0x1810>  // b.any
    c098:	17fffce5 	b	b42c <f0+0x17fc>
    c09c:	72003c3f 	tst	w1, #0xffff
    c0a0:	54ff8e81 	b.ne	b270 <f0+0x1640>  // b.any
    c0a4:	17fffc6e 	b	b25c <f0+0x162c>
    c0a8:	72003c3f 	tst	w1, #0xffff
    c0ac:	54ff85c1 	b.ne	b164 <f0+0x1534>  // b.any
    c0b0:	17fffc28 	b	b150 <f0+0x1520>
    c0b4:	72003c3f 	tst	w1, #0xffff
    c0b8:	54ff7ec1 	b.ne	b090 <f0+0x1460>  // b.any
    c0bc:	17fffbf0 	b	b07c <f0+0x144c>
    c0c0:	aa1403e0 	mov	x0, x20
    c0c4:	97ffe1eb 	bl	4870 <fwp_rc_forget_slot>
    c0c8:	17ffff52 	b	be10 <f0+0x21e0>
    c0cc:	aa1703e0 	mov	x0, x23
    c0d0:	97ffe1e8 	bl	4870 <fwp_rc_forget_slot>
    c0d4:	17fff75a 	b	9e3c <f0+0x20c>
    c0d8:	aa1503e0 	mov	x0, x21
    c0dc:	97ffe1e5 	bl	4870 <fwp_rc_forget_slot>
    c0e0:	17fff783 	b	9eec <f0+0x2bc>
    c0e4:	aa1703e0 	mov	x0, x23
    c0e8:	97ffe1e2 	bl	4870 <fwp_rc_forget_slot>
    c0ec:	17fff7d6 	b	a044 <f0+0x414>
    c0f0:	aa1703e0 	mov	x0, x23
    c0f4:	97ffe1df 	bl	4870 <fwp_rc_forget_slot>
    c0f8:	17fff7ff 	b	a0f4 <f0+0x4c4>
    c0fc:	aa1703e0 	mov	x0, x23
    c100:	97ffe1dc 	bl	4870 <fwp_rc_forget_slot>
    c104:	17fff828 	b	a1a4 <f0+0x574>
    c108:	aa1703e0 	mov	x0, x23
    c10c:	97ffe1d9 	bl	4870 <fwp_rc_forget_slot>
    c110:	17fff851 	b	a254 <f0+0x624>
    c114:	aa1703e0 	mov	x0, x23
    c118:	97ffe1d6 	bl	4870 <fwp_rc_forget_slot>
    c11c:	17fff87a 	b	a304 <f0+0x6d4>
    c120:	aa1703e0 	mov	x0, x23
    c124:	97ffe1d3 	bl	4870 <fwp_rc_forget_slot>
    c128:	17fff8a3 	b	a3b4 <f0+0x784>
    c12c:	aa1703e0 	mov	x0, x23
    c130:	97ffe1d0 	bl	4870 <fwp_rc_forget_slot>
    c134:	17fff8c5 	b	a448 <f0+0x818>
    c138:	aa1703e0 	mov	x0, x23
    c13c:	97ffe1cd 	bl	4870 <fwp_rc_forget_slot>
    c140:	17fff8f4 	b	a510 <f0+0x8e0>
    c144:	aa1703e0 	mov	x0, x23
    c148:	97ffe1ca 	bl	4870 <fwp_rc_forget_slot>
    c14c:	17fff91f 	b	a5c8 <f0+0x998>
    c150:	aa1703e0 	mov	x0, x23
    c154:	97ffe1c7 	bl	4870 <fwp_rc_forget_slot>
    c158:	17fff951 	b	a69c <f0+0xa6c>
    c15c:	aa1703e0 	mov	x0, x23
    c160:	97ffe1c4 	bl	4870 <fwp_rc_forget_slot>
    c164:	17fff98a 	b	a78c <f0+0xb5c>
    c168:	aa1703e0 	mov	x0, x23
    c16c:	97ffe1c1 	bl	4870 <fwp_rc_forget_slot>
    c170:	17fff9ac 	b	a820 <f0+0xbf0>
    c174:	aa1703e0 	mov	x0, x23
    c178:	97ffe1be 	bl	4870 <fwp_rc_forget_slot>
    c17c:	17fff9cf 	b	a8b8 <f0+0xc88>
    c180:	aa1703e0 	mov	x0, x23
    c184:	97ffe1bb 	bl	4870 <fwp_rc_forget_slot>
    c188:	17fff9fa 	b	a970 <f0+0xd40>
    c18c:	aa1703e0 	mov	x0, x23
    c190:	97ffe1b8 	bl	4870 <fwp_rc_forget_slot>
    c194:	17fffa1c 	b	aa04 <f0+0xdd4>
    c198:	aa1703e0 	mov	x0, x23
    c19c:	97ffe1b5 	bl	4870 <fwp_rc_forget_slot>
    c1a0:	17fffa71 	b	ab64 <f0+0xf34>
    c1a4:	aa1703e0 	mov	x0, x23
    c1a8:	97ffe1b2 	bl	4870 <fwp_rc_forget_slot>
    c1ac:	17fffa94 	b	abfc <f0+0xfcc>
    c1b0:	aa1703e0 	mov	x0, x23
    c1b4:	97ffe1af 	bl	4870 <fwp_rc_forget_slot>
    c1b8:	17fffadb 	b	ad24 <f0+0x10f4>
    c1bc:	aa1703e0 	mov	x0, x23
    c1c0:	97ffe1ac 	bl	4870 <fwp_rc_forget_slot>
    c1c4:	17fffafd 	b	adb8 <f0+0x1188>
    c1c8:	aa1703e0 	mov	x0, x23
    c1cc:	97ffe1a9 	bl	4870 <fwp_rc_forget_slot>
    c1d0:	17fffb2f 	b	ae8c <f0+0x125c>
    c1d4:	aa1703e0 	mov	x0, x23
    c1d8:	97ffe1a6 	bl	4870 <fwp_rc_forget_slot>
    c1dc:	17fffb6f 	b	af98 <f0+0x1368>
    c1e0:	aa1703e0 	mov	x0, x23
    c1e4:	97ffe1a3 	bl	4870 <fwp_rc_forget_slot>
    c1e8:	17fffba8 	b	b088 <f0+0x1458>
    c1ec:	aa1703e0 	mov	x0, x23
    c1f0:	97ffe1a0 	bl	4870 <fwp_rc_forget_slot>
    c1f4:	17fffbda 	b	b15c <f0+0x152c>
    c1f8:	aa1703e0 	mov	x0, x23
    c1fc:	97ffe19d 	bl	4870 <fwp_rc_forget_slot>
    c200:	17fffc1a 	b	b268 <f0+0x1638>
    c204:	aa1503e0 	mov	x0, x21
    c208:	97ffe19a 	bl	4870 <fwp_rc_forget_slot>
    c20c:	17fffc8b 	b	b438 <f0+0x1808>
    c210:	aa1703e0 	mov	x0, x23
    c214:	97ffe197 	bl	4870 <fwp_rc_forget_slot>
    c218:	17fffcd9 	b	b57c <f0+0x194c>
    c21c:	aa1703e0 	mov	x0, x23
    c220:	97ffe194 	bl	4870 <fwp_rc_forget_slot>
    c224:	17fffcfb 	b	b610 <f0+0x19e0>
    c228:	aa1703e0 	mov	x0, x23
    c22c:	97ffe191 	bl	4870 <fwp_rc_forget_slot>
    c230:	17fffd34 	b	b700 <f0+0x1ad0>
    c234:	aa1703e0 	mov	x0, x23
    c238:	97ffe18e 	bl	4870 <fwp_rc_forget_slot>
    c23c:	17fffd5f 	b	b7b8 <f0+0x1b88>
    c240:	aa1703e0 	mov	x0, x23
    c244:	97ffe18b 	bl	4870 <fwp_rc_forget_slot>
    c248:	17fffd82 	b	b850 <f0+0x1c20>
    c24c:	aa1703e0 	mov	x0, x23
    c250:	97ffe188 	bl	4870 <fwp_rc_forget_slot>
    c254:	17fffdb4 	b	b924 <f0+0x1cf4>
    c258:	aa1703e0 	mov	x0, x23
    c25c:	97ffe185 	bl	4870 <fwp_rc_forget_slot>
    c260:	17fffddf 	b	b9dc <f0+0x1dac>
    c264:	aa1703e0 	mov	x0, x23
    c268:	97ffe182 	bl	4870 <fwp_rc_forget_slot>
    c26c:	17fffe34 	b	bb3c <f0+0x1f0c>
    c270:	aa1703e0 	mov	x0, x23
    c274:	97ffe17f 	bl	4870 <fwp_rc_forget_slot>
    c278:	17fffe57 	b	bbd4 <f0+0x1fa4>
    c27c:	aa1703e0 	mov	x0, x23
    c280:	97ffe17c 	bl	4870 <fwp_rc_forget_slot>
    c284:	17fffe79 	b	bc68 <f0+0x2038>
    c288:	aa1703e0 	mov	x0, x23
    c28c:	97ffe179 	bl	4870 <fwp_rc_forget_slot>
    c290:	17fffea4 	b	bd20 <f0+0x20f0>
    c294:	97ffd99f 	bl	2910 <__stack_chk_fail@plt>
    c298:	d503201f 	nop
    c29c:	d503201f 	nop

000000000000c2a0 <fwp_main_thread>:
    c2a0:	d10443ff 	sub	sp, sp, #0x110
    c2a4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c2a8:	f947f400 	ldr	x0, [x0, #4072]
    c2ac:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c2b0:	910303fd 	add	x29, sp, #0xc0
    c2b4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c2b8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c2bc:	91174261 	add	x1, x19, #0x5d0
    c2c0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c2c4:	b953a421 	ldr	w1, [x1, #5028]
    c2c8:	f9400002 	ldr	x2, [x0]
    c2cc:	f9005fe2 	str	x2, [sp, #184]
    c2d0:	d2800002 	mov	x2, #0x0                   	// #0
    c2d4:	34002821 	cbz	w1, c7d8 <fwp_main_thread+0x538>
    c2d8:	91174273 	add	x19, x19, #0x5d0
    c2dc:	b953aa60 	ldr	w0, [x19, #5032]
    c2e0:	35002740 	cbnz	w0, c7c8 <fwp_main_thread+0x528>
    c2e4:	91001fe2 	add	x2, sp, #0x7
    c2e8:	900000b5 	adrp	x21, 20000 <__data_start>
    c2ec:	900000a3 	adrp	x3, 20000 <__data_start>
    c2f0:	9101c2b3 	add	x19, x21, #0x70
    c2f4:	910fc063 	add	x3, x3, #0x3f0
    c2f8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c2fc:	d2a00025 	mov	x5, #0x10000               	// #65536
    c300:	910023e0 	add	x0, sp, #0x8
    c304:	d2800001 	mov	x1, #0x0                   	// #0
    c308:	f90007e3 	str	x3, [sp, #8]
    c30c:	b90013ff 	str	wzr, [sp, #16]
    c310:	a9019262 	stp	x2, x4, [x19, #24]
    c314:	f9000fe5 	str	x5, [sp, #24]
    c318:	97ffd916 	bl	2770 <sigaltstack@plt>
    c31c:	350026e0 	cbnz	w0, c7f8 <fwp_main_thread+0x558>
    c320:	4f000400 	movi	v0.4s, #0x0
    c324:	9100a3e0 	add	x0, sp, #0x28
    c328:	f0ffffa1 	adrp	x1, 3000 <fwp_range_release+0x30>
    c32c:	52800082 	mov	w2, #0x4                   	// #4
    c330:	9103c021 	add	x1, x1, #0xf0
    c334:	72a10002 	movk	w2, #0x800, lsl #16
    c338:	910083f4 	add	x20, sp, #0x20
    c33c:	f90013e1 	str	x1, [sp, #32]
    c340:	3d802000 	str	q0, [x0, #128]
    c344:	b900abe2 	str	w2, [sp, #168]
    c348:	ad000000 	stp	q0, q0, [x0]
    c34c:	ad010000 	stp	q0, q0, [x0, #32]
    c350:	ad020000 	stp	q0, q0, [x0, #64]
    c354:	ad030000 	stp	q0, q0, [x0, #96]
    c358:	97ffd95e 	bl	28d0 <sigemptyset@plt>
    c35c:	350024e0 	cbnz	w0, c7f8 <fwp_main_thread+0x558>
    c360:	aa1403e1 	mov	x1, x20
    c364:	d2800002 	mov	x2, #0x0                   	// #0
    c368:	52800160 	mov	w0, #0xb                   	// #11
    c36c:	97ffd971 	bl	2930 <sigaction@plt>
    c370:	35002440 	cbnz	w0, c7f8 <fwp_main_thread+0x558>
    c374:	aa1403e1 	mov	x1, x20
    c378:	d2800002 	mov	x2, #0x0                   	// #0
    c37c:	528000e0 	mov	w0, #0x7                   	// #7
    c380:	97ffd96c 	bl	2930 <sigaction@plt>
    c384:	350023a0 	cbnz	w0, c7f8 <fwp_main_thread+0x558>
    c388:	b9434a60 	ldr	w0, [x19, #840]
    c38c:	34002000 	cbz	w0, c78c <fwp_main_thread+0x4ec>
    c390:	9101c2b3 	add	x19, x21, #0x70
    c394:	a90f63f7 	stp	x23, x24, [sp, #240]
    c398:	b9434e60 	ldr	w0, [x19, #844]
    c39c:	340020c0 	cbz	w0, c7b4 <fwp_main_thread+0x514>
    c3a0:	9101c2b6 	add	x22, x21, #0x70
    c3a4:	f9400ad4 	ldr	x20, [x22, #16]
    c3a8:	b40010f4 	cbz	x20, c5c4 <fwp_main_thread+0x324>
    c3ac:	aa1403f3 	mov	x19, x20
    c3b0:	91010297 	add	x23, x20, #0x40
    c3b4:	f90083f9 	str	x25, [sp, #256]
    c3b8:	52800038 	mov	w24, #0x1                   	// #1
    c3bc:	39414a99 	ldrb	w25, [x20, #82]
    c3c0:	39014a98 	strb	w24, [x20, #82]
    c3c4:	f9401680 	ldr	x0, [x20, #40]
    c3c8:	b4000620 	cbz	x0, c48c <fwp_main_thread+0x1ec>
    c3cc:	f9403281 	ldr	x1, [x20, #96]
    c3d0:	39414680 	ldrb	w0, [x20, #81]
    c3d4:	b4000b61 	cbz	x1, c540 <fwp_main_thread+0x2a0>
    c3d8:	36000aa0 	tbz	w0, #0, c52c <fwp_main_thread+0x28c>
    c3dc:	39414a62 	ldrb	w2, [x19, #82]
    c3e0:	f9402280 	ldr	x0, [x20, #64]
    c3e4:	37000d82 	tbnz	w2, #0, c594 <fwp_main_thread+0x2f4>
    c3e8:	f9403261 	ldr	x1, [x19, #96]
    c3ec:	a911fe77 	stp	x23, xzr, [x19, #280]
    c3f0:	f9009660 	str	x0, [x19, #296]
    c3f4:	b4000040 	cbz	x0, c3fc <fwp_main_thread+0x15c>
    c3f8:	f9009013 	str	x19, [x0, #288]
    c3fc:	f9002293 	str	x19, [x20, #64]
    c400:	b4000101 	cbz	x1, c420 <fwp_main_thread+0x180>
    c404:	f9406ec0 	ldr	x0, [x22, #216]
    c408:	39015678 	strb	w24, [x19, #85]
    c40c:	f9003661 	str	x1, [x19, #104]
    c410:	a910827f 	stp	xzr, x0, [x19, #264]
    c414:	b4000040 	cbz	x0, c41c <fwp_main_thread+0x17c>
    c418:	f9008413 	str	x19, [x0, #264]
    c41c:	f9006ed3 	str	x19, [x22, #216]
    c420:	39015a7f 	strb	wzr, [x19, #86]
    c424:	97ffe8c8 	bl	6744 <fwp_block>
    c428:	f9408e62 	ldr	x2, [x19, #280]
    c42c:	b4000142 	cbz	x2, c454 <fwp_main_thread+0x1b4>
    c430:	a9520261 	ldp	x1, x0, [x19, #288]
    c434:	b4000bc1 	cbz	x1, c5ac <fwp_main_thread+0x30c>
    c438:	f9009420 	str	x0, [x1, #296]
    c43c:	f9409660 	ldr	x0, [x19, #296]
    c440:	b4000040 	cbz	x0, c448 <fwp_main_thread+0x1a8>
    c444:	f9009001 	str	x1, [x0, #288]
    c448:	91080260 	add	x0, x19, #0x200
    c44c:	f900967f 	str	xzr, [x19, #296]
    c450:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c454:	39415660 	ldrb	w0, [x19, #85]
    c458:	f9400ac2 	ldr	x2, [x22, #16]
    c45c:	36000980 	tbz	w0, #0, c58c <fwp_main_thread+0x2ec>
    c460:	a9508261 	ldp	x1, x0, [x19, #264]
    c464:	b4000a81 	cbz	x1, c5b4 <fwp_main_thread+0x314>
    c468:	f9008820 	str	x0, [x1, #272]
    c46c:	b4000040 	cbz	x0, c474 <fwp_main_thread+0x1d4>
    c470:	f9008401 	str	x1, [x0, #264]
    c474:	91080260 	add	x0, x19, #0x200
    c478:	3901567f 	strb	wzr, [x19, #85]
    c47c:	aa0203f3 	mov	x19, x2
    c480:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c484:	f9401680 	ldr	x0, [x20, #40]
    c488:	b5fffa20 	cbnz	x0, c3cc <fwp_main_thread+0x12c>
    c48c:	9101c2a0 	add	x0, x21, #0x70
    c490:	39014a99 	strb	w25, [x20, #82]
    c494:	f94083f9 	ldr	x25, [sp, #256]
    c498:	f9419400 	ldr	x0, [x0, #808]
    c49c:	b4001580 	cbz	x0, c74c <fwp_main_thread+0x4ac>
    c4a0:	9101c2a0 	add	x0, x21, #0x70
    c4a4:	f941b001 	ldr	x1, [x0, #864]
    c4a8:	b903581f 	str	wzr, [x0, #856]
    c4ac:	eb13003f 	cmp	x1, x19
    c4b0:	540016a1 	b.ne	c784 <fwp_main_thread+0x4e4>  // b.any
    c4b4:	b4000933 	cbz	x19, c5d8 <fwp_main_thread+0x338>
    c4b8:	9101c2a0 	add	x0, x21, #0x70
    c4bc:	52800021 	mov	w1, #0x1                   	// #1
    c4c0:	39014a61 	strb	w1, [x19, #82]
    c4c4:	f9418005 	ldr	x5, [x0, #768]
    c4c8:	b4000885 	cbz	x5, c5d8 <fwp_main_thread+0x338>
    c4cc:	d503201f 	nop
    c4d0:	394140a0 	ldrb	w0, [x5, #80]
    c4d4:	37000060 	tbnz	w0, #0, c4e0 <fwp_main_thread+0x240>
    c4d8:	aa0503e0 	mov	x0, x5
    c4dc:	97ffdca5 	bl	3770 <fwp_cancel_tree.part.0>
    c4e0:	f9409ca5 	ldr	x5, [x5, #312]
    c4e4:	b5ffff65 	cbnz	x5, c4d0 <fwp_main_thread+0x230>
    c4e8:	9101c2b4 	add	x20, x21, #0x70
    c4ec:	52800036 	mov	w22, #0x1                   	// #1
    c4f0:	f9402a60 	ldr	x0, [x19, #80]
    c4f4:	f2001c1f 	tst	x0, #0xff000000ff
    c4f8:	540000e1 	b.ne	c514 <fwp_main_thread+0x274>  // b.any
    c4fc:	f9403e80 	ldr	x0, [x20, #120]
    c500:	39015276 	strb	w22, [x19, #84]
    c504:	f900827f 	str	xzr, [x19, #256]
    c508:	b40005a0 	cbz	x0, c5bc <fwp_main_thread+0x31c>
    c50c:	f9008013 	str	x19, [x0, #256]
    c510:	f9003e93 	str	x19, [x20, #120]
    c514:	97ffe88c 	bl	6744 <fwp_block>
    c518:	97ffe81e 	bl	6590 <fwp_free_zombie>
    c51c:	f9418280 	ldr	x0, [x20, #768]
    c520:	b40005c0 	cbz	x0, c5d8 <fwp_main_thread+0x338>
    c524:	f941b293 	ldr	x19, [x20, #864]
    c528:	17fffff2 	b	c4f0 <fwp_main_thread+0x250>
    c52c:	97ffdd35 	bl	3a00 <fwp_now_ns>
    c530:	f9403281 	ldr	x1, [x20, #96]
    c534:	eb01001f 	cmp	x0, x1
    c538:	54000fca 	b.ge	c730 <fwp_main_thread+0x490>  // b.tcont
    c53c:	39414680 	ldrb	w0, [x20, #81]
    c540:	39414a62 	ldrb	w2, [x19, #82]
    c544:	3707f4e0 	tbnz	w0, #0, c3e0 <fwp_main_thread+0x140>
    c548:	f9403281 	ldr	x1, [x20, #96]
    c54c:	370001c2 	tbnz	w2, #0, c584 <fwp_main_thread+0x2e4>
    c550:	f9403260 	ldr	x0, [x19, #96]
    c554:	b4000180 	cbz	x0, c584 <fwp_main_thread+0x2e4>
    c558:	b4000061 	cbz	x1, c564 <fwp_main_thread+0x2c4>
    c55c:	eb01001f 	cmp	x0, x1
    c560:	9a81d000 	csel	x0, x0, x1, le
    c564:	f9402281 	ldr	x1, [x20, #64]
    c568:	a911fe77 	stp	x23, xzr, [x19, #280]
    c56c:	f9009661 	str	x1, [x19, #296]
    c570:	b4001381 	cbz	x1, c7e0 <fwp_main_thread+0x540>
    c574:	f9009033 	str	x19, [x1, #288]
    c578:	aa0003e1 	mov	x1, x0
    c57c:	f9002293 	str	x19, [x20, #64]
    c580:	17ffffa1 	b	c404 <fwp_main_thread+0x164>
    c584:	f9402280 	ldr	x0, [x20, #64]
    c588:	17ffff99 	b	c3ec <fwp_main_thread+0x14c>
    c58c:	aa0203f3 	mov	x19, x2
    c590:	17ffff8d 	b	c3c4 <fwp_main_thread+0x124>
    c594:	a911fe77 	stp	x23, xzr, [x19, #280]
    c598:	f9009660 	str	x0, [x19, #296]
    c59c:	b4000040 	cbz	x0, c5a4 <fwp_main_thread+0x304>
    c5a0:	f9009013 	str	x19, [x0, #288]
    c5a4:	f9002293 	str	x19, [x20, #64]
    c5a8:	17ffff9e 	b	c420 <fwp_main_thread+0x180>
    c5ac:	f9000040 	str	x0, [x2]
    c5b0:	17ffffa4 	b	c440 <fwp_main_thread+0x1a0>
    c5b4:	f9006ec0 	str	x0, [x22, #216]
    c5b8:	17ffffad 	b	c46c <fwp_main_thread+0x1cc>
    c5bc:	f9004293 	str	x19, [x20, #128]
    c5c0:	17ffffd4 	b	c510 <fwp_main_thread+0x270>
    c5c4:	f94196c0 	ldr	x0, [x22, #808]
    c5c8:	b4000c00 	cbz	x0, c748 <fwp_main_thread+0x4a8>
    c5cc:	f941b2c0 	ldr	x0, [x22, #864]
    c5d0:	b9035adf 	str	wzr, [x22, #856]
    c5d4:	b5000d80 	cbnz	x0, c784 <fwp_main_thread+0x4e4>
    c5d8:	9101c2b4 	add	x20, x21, #0x70
    c5dc:	97ffe7ed 	bl	6590 <fwp_free_zombie>
    c5e0:	f9404280 	ldr	x0, [x20, #128]
    c5e4:	b5000d00 	cbnz	x0, c784 <fwp_main_thread+0x4e4>
    c5e8:	f9406e80 	ldr	x0, [x20, #216]
    c5ec:	b5000cc0 	cbnz	x0, c784 <fwp_main_thread+0x4e4>
    c5f0:	b940fa93 	ldr	w19, [x20, #248]
    c5f4:	340001d3 	cbz	w19, c62c <fwp_main_thread+0x38c>
    c5f8:	93407e76 	sxtw	x22, w19
    c5fc:	51000673 	sub	w19, w19, #0x1
    c600:	d1000ad6 	sub	x22, x22, #0x2
    c604:	91040297 	add	x23, x20, #0x100
    c608:	cb3342d6 	sub	x22, x22, w19, uxtw
    c60c:	93407e73 	sxtw	x19, w19
    c610:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c614:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c618:	b900fa93 	str	w19, [x20, #248]
    c61c:	d1000673 	sub	x19, x19, #0x1
    c620:	97ffd904 	bl	2a30 <munmap@plt>
    c624:	eb16027f 	cmp	x19, x22
    c628:	54ffff41 	b.ne	c610 <fwp_main_thread+0x370>  // b.any
    c62c:	900000b3 	adrp	x19, 20000 <__data_start>
    c630:	91004260 	add	x0, x19, #0x10
    c634:	b9404000 	ldr	w0, [x0, #64]
    c638:	37f80040 	tbnz	w0, #31, c640 <fwp_main_thread+0x3a0>
    c63c:	97ffd8b9 	bl	2920 <close@plt>
    c640:	9101c2a0 	add	x0, x21, #0x70
    c644:	91004261 	add	x1, x19, #0x10
    c648:	12800002 	mov	w2, #0xffffffff            	// #-1
    c64c:	d2800013 	mov	x19, #0x0                   	// #0
    c650:	f941b416 	ldr	x22, [x0, #872]
    c654:	b9004022 	str	w2, [x1, #64]
    c658:	f941b814 	ldr	x20, [x0, #880]
    c65c:	b4000176 	cbz	x22, c688 <fwp_main_thread+0x3e8>
    c660:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c664:	b40000c0 	cbz	x0, c67c <fwp_main_thread+0x3dc>
    c668:	f9400001 	ldr	x1, [x0]
    c66c:	b50008c1 	cbnz	x1, c784 <fwp_main_thread+0x4e4>
    c670:	f9400401 	ldr	x1, [x0, #8]
    c674:	b5000881 	cbnz	x1, c784 <fwp_main_thread+0x4e4>
    c678:	97ffe11e 	bl	4af0 <fwp_mem_free>
    c67c:	91000673 	add	x19, x19, #0x1
    c680:	eb16027f 	cmp	x19, x22
    c684:	54fffee1 	b.ne	c660 <fwp_main_thread+0x3c0>  // b.any
    c688:	aa1403e0 	mov	x0, x20
    c68c:	97ffe119 	bl	4af0 <fwp_mem_free>
    c690:	9101c2a0 	add	x0, x21, #0x70
    c694:	f941b013 	ldr	x19, [x0, #864]
    c698:	f901b41f 	str	xzr, [x0, #872]
    c69c:	f901b81f 	str	xzr, [x0, #880]
    c6a0:	b40001f3 	cbz	x19, c6dc <fwp_main_thread+0x43c>
    c6a4:	f9401661 	ldr	x1, [x19, #40]
    c6a8:	b50006e1 	cbnz	x1, c784 <fwp_main_thread+0x4e4>
    c6ac:	f9405661 	ldr	x1, [x19, #168]
    c6b0:	b50006a1 	cbnz	x1, c784 <fwp_main_thread+0x4e4>
    c6b4:	f9419401 	ldr	x1, [x0, #808]
    c6b8:	b5000661 	cbnz	x1, c784 <fwp_main_thread+0x4e4>
    c6bc:	f9419c00 	ldr	x0, [x0, #824]
    c6c0:	b5000620 	cbnz	x0, c784 <fwp_main_thread+0x4e4>
    c6c4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c6c8:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    c6cc:	910fc000 	add	x0, x0, #0x3f0
    c6d0:	97ffd884 	bl	28e0 <memset@plt>
    c6d4:	aa1303e0 	mov	x0, x19
    c6d8:	97ffe106 	bl	4af0 <fwp_mem_free>
    c6dc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c6e0:	f947ec00 	ldr	x0, [x0, #4056]
    c6e4:	9101c2b5 	add	x21, x21, #0x70
    c6e8:	f9400000 	ldr	x0, [x0]
    c6ec:	f9000abf 	str	xzr, [x21, #16]
    c6f0:	f901b2bf 	str	xzr, [x21, #864]
    c6f4:	97ffd8d3 	bl	2a40 <fflush@plt>
    c6f8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c6fc:	f947f400 	ldr	x0, [x0, #4072]
    c700:	f9405fe2 	ldr	x2, [sp, #184]
    c704:	f9400001 	ldr	x1, [x0]
    c708:	eb010042 	subs	x2, x2, x1
    c70c:	d2800001 	mov	x1, #0x0                   	// #0
    c710:	54000821 	b.ne	c814 <fwp_main_thread+0x574>  // b.any
    c714:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c718:	d2800000 	mov	x0, #0x0                   	// #0
    c71c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c720:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c724:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c728:	910443ff 	add	sp, sp, #0x110
    c72c:	d65f03c0 	ret
    c730:	39414280 	ldrb	w0, [x20, #80]
    c734:	3707f040 	tbnz	w0, #0, c53c <fwp_main_thread+0x29c>
    c738:	aa1403e0 	mov	x0, x20
    c73c:	97ffdc0d 	bl	3770 <fwp_cancel_tree.part.0>
    c740:	39414680 	ldrb	w0, [x20, #81]
    c744:	17ffff7f 	b	c540 <fwp_main_thread+0x2a0>
    c748:	d2800013 	mov	x19, #0x0                   	// #0
    c74c:	9101c2b4 	add	x20, x21, #0x70
    c750:	f9419e80 	ldr	x0, [x20, #824]
    c754:	b5ffea60 	cbnz	x0, c4a0 <fwp_main_thread+0x200>
    c758:	f9419280 	ldr	x0, [x20, #800]
    c75c:	97ffe0e5 	bl	4af0 <fwp_mem_free>
    c760:	f901929f 	str	xzr, [x20, #800]
    c764:	f9019a9f 	str	xzr, [x20, #816]
    c768:	f941b280 	ldr	x0, [x20, #864]
    c76c:	b4000413 	cbz	x19, c7ec <fwp_main_thread+0x54c>
    c770:	f900567f 	str	xzr, [x19, #168]
    c774:	f9005e7f 	str	xzr, [x19, #184]
    c778:	b9035a9f 	str	wzr, [x20, #856]
    c77c:	eb00027f 	cmp	x19, x0
    c780:	54ffe9c0 	b.eq	c4b8 <fwp_main_thread+0x218>  // b.none
    c784:	f90083f9 	str	x25, [sp, #256]
    c788:	97ffd876 	bl	2960 <abort@plt>
    c78c:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    c790:	91078000 	add	x0, x0, #0x1e0
    c794:	940001df 	bl	cf10 <atexit>
    c798:	a90f63f7 	stp	x23, x24, [sp, #240]
    c79c:	35000380 	cbnz	w0, c80c <fwp_main_thread+0x56c>
    c7a0:	52800020 	mov	w0, #0x1                   	// #1
    c7a4:	b9034a60 	str	w0, [x19, #840]
    c7a8:	9101c2b3 	add	x19, x21, #0x70
    c7ac:	b9434e60 	ldr	w0, [x19, #844]
    c7b0:	35ffdf80 	cbnz	w0, c3a0 <fwp_main_thread+0x100>
    c7b4:	97fff51f 	bl	9c30 <f0>
    c7b8:	f901aa60 	str	x0, [x19, #848]
    c7bc:	52800021 	mov	w1, #0x1                   	// #1
    c7c0:	b9034e61 	str	w1, [x19, #844]
    c7c4:	17fffef7 	b	c3a0 <fwp_main_thread+0x100>
    c7c8:	90ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    c7cc:	91008000 	add	x0, x0, #0x20
    c7d0:	940001d0 	bl	cf10 <atexit>
    c7d4:	17fffec4 	b	c2e4 <fwp_main_thread+0x44>
    c7d8:	97ffde6b 	bl	4184 <fwp_heap_init>
    c7dc:	17fffebf 	b	c2d8 <fwp_main_thread+0x38>
    c7e0:	aa0003e1 	mov	x1, x0
    c7e4:	f9002293 	str	x19, [x20, #64]
    c7e8:	17ffff07 	b	c404 <fwp_main_thread+0x164>
    c7ec:	b9035a9f 	str	wzr, [x20, #856]
    c7f0:	b4ffef40 	cbz	x0, c5d8 <fwp_main_thread+0x338>
    c7f4:	17ffffe4 	b	c784 <fwp_main_thread+0x4e4>
    c7f8:	b0000000 	adrp	x0, d000 <_IO_stdin_used+0xc0>
    c7fc:	9116c000 	add	x0, x0, #0x5b0
    c800:	a90f63f7 	stp	x23, x24, [sp, #240]
    c804:	f90083f9 	str	x25, [sp, #256]
    c808:	97ffdc1e 	bl	3880 <fwp_trap>
    c80c:	f90083f9 	str	x25, [sp, #256]
    c810:	97ffda68 	bl	31b0 <descent_phase_fail>
    c814:	f90083f9 	str	x25, [sp, #256]
    c818:	97ffd83e 	bl	2910 <__stack_chk_fail@plt>
    c81c:	d503201f 	nop

000000000000c820 <__divti3>:
    c820:	d503245f 	bti	c
    c824:	d2800004 	mov	x4, #0x0                   	// #0
    c828:	b7f80721 	tbnz	x1, #63, c90c <__divti3+0xec>
    c82c:	b6f80083 	tbz	x3, #63, c83c <__divti3+0x1c>
    c830:	eb0203e2 	negs	x2, x2
    c834:	aa2403e4 	mvn	x4, x4
    c838:	da0303e3 	ngc	x3, x3
    c83c:	aa0203e6 	mov	x6, x2
    c840:	aa0003e7 	mov	x7, x0
    c844:	aa0103e5 	mov	x5, x1
    c848:	b5000583 	cbnz	x3, c8f8 <__divti3+0xd8>
    c84c:	eb01005f 	cmp	x2, x1
    c850:	54000e69 	b.ls	ca1c <__divti3+0x1fc>  // b.plast
    c854:	dac01040 	clz	x0, x2
    c858:	b40000e0 	cbz	x0, c874 <__divti3+0x54>
    c85c:	4b0003e1 	neg	w1, w0
    c860:	9ac020a5 	lsl	x5, x5, x0
    c864:	9ac02046 	lsl	x6, x2, x0
    c868:	9ac124e1 	lsr	x1, x7, x1
    c86c:	aa050025 	orr	x5, x1, x5
    c870:	9ac020e7 	lsl	x7, x7, x0
    c874:	d360fcc8 	lsr	x8, x6, #32
    c878:	92407cc2 	and	x2, x6, #0xffffffff
    c87c:	9ac808a3 	udiv	x3, x5, x8
    c880:	9b089465 	msub	x5, x3, x8, x5
    c884:	aa0303e0 	mov	x0, x3
    c888:	9b037c41 	mul	x1, x2, x3
    c88c:	93c780a5 	extr	x5, x5, x7, #32
    c890:	eb05003f 	cmp	x1, x5
    c894:	540000a9 	b.ls	c8a8 <__divti3+0x88>  // b.plast
    c898:	ab0500c5 	adds	x5, x6, x5
    c89c:	d1000460 	sub	x0, x3, #0x1
    c8a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c8a4:	540015a8 	b.hi	cb58 <__divti3+0x338>  // b.pmore
    c8a8:	cb0100a5 	sub	x5, x5, x1
    c8ac:	9ac808a3 	udiv	x3, x5, x8
    c8b0:	9b089465 	msub	x5, x3, x8, x5
    c8b4:	aa0303e1 	mov	x1, x3
    c8b8:	9b037c42 	mul	x2, x2, x3
    c8bc:	aa0703e3 	mov	x3, x7
    c8c0:	b3607ca3 	bfi	x3, x5, #32, #32
    c8c4:	eb03005f 	cmp	x2, x3
    c8c8:	540000c9 	b.ls	c8e0 <__divti3+0xc0>  // b.plast
    c8cc:	ab0300c3 	adds	x3, x6, x3
    c8d0:	d1000425 	sub	x5, x1, #0x1
    c8d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c8d8:	d1000821 	sub	x1, x1, #0x2
    c8dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c8e0:	aa008020 	orr	x0, x1, x0, lsl #32
    c8e4:	d2800001 	mov	x1, #0x0                   	// #0
    c8e8:	b4000064 	cbz	x4, c8f4 <__divti3+0xd4>
    c8ec:	eb0003e0 	negs	x0, x0
    c8f0:	da0103e1 	ngc	x1, x1
    c8f4:	d65f03c0 	ret
    c8f8:	eb01007f 	cmp	x3, x1
    c8fc:	54000109 	b.ls	c91c <__divti3+0xfc>  // b.plast
    c900:	d2800001 	mov	x1, #0x0                   	// #0
    c904:	d2800000 	mov	x0, #0x0                   	// #0
    c908:	17fffff8 	b	c8e8 <__divti3+0xc8>
    c90c:	eb0003e0 	negs	x0, x0
    c910:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c914:	da0103e1 	ngc	x1, x1
    c918:	17ffffc5 	b	c82c <__divti3+0xc>
    c91c:	dac01067 	clz	x7, x3
    c920:	b40010e7 	cbz	x7, cb3c <__divti3+0x31c>
    c924:	d2800805 	mov	x5, #0x40                  	// #64
    c928:	cb0700a5 	sub	x5, x5, x7
    c92c:	9ac72063 	lsl	x3, x3, x7
    c930:	9ac52448 	lsr	x8, x2, x5
    c934:	aa030108 	orr	x8, x8, x3
    c938:	9ac52426 	lsr	x6, x1, x5
    c93c:	92407d0a 	and	x10, x8, #0xffffffff
    c940:	d360fd09 	lsr	x9, x8, #32
    c944:	9ac52403 	lsr	x3, x0, x5
    c948:	9ac72021 	lsl	x1, x1, x7
    c94c:	aa010063 	orr	x3, x3, x1
    c950:	9ac72042 	lsl	x2, x2, x7
    c954:	9ac908cb 	udiv	x11, x6, x9
    c958:	9b099965 	msub	x5, x11, x9, x6
    c95c:	aa0b03e1 	mov	x1, x11
    c960:	9b0b7d46 	mul	x6, x10, x11
    c964:	93c380a5 	extr	x5, x5, x3, #32
    c968:	eb0500df 	cmp	x6, x5
    c96c:	540000a9 	b.ls	c980 <__divti3+0x160>  // b.plast
    c970:	ab050105 	adds	x5, x8, x5
    c974:	d1000561 	sub	x1, x11, #0x1
    c978:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    c97c:	54000f48 	b.hi	cb64 <__divti3+0x344>  // b.pmore
    c980:	cb0600a6 	sub	x6, x5, x6
    c984:	9ac908cb 	udiv	x11, x6, x9
    c988:	9b099969 	msub	x9, x11, x9, x6
    c98c:	aa0b03e5 	mov	x5, x11
    c990:	9b0b7d4a 	mul	x10, x10, x11
    c994:	b3607d23 	bfi	x3, x9, #32, #32
    c998:	eb03015f 	cmp	x10, x3
    c99c:	540000a9 	b.ls	c9b0 <__divti3+0x190>  // b.plast
    c9a0:	ab030103 	adds	x3, x8, x3
    c9a4:	d1000565 	sub	x5, x11, #0x1
    c9a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    c9ac:	54000e28 	b.hi	cb70 <__divti3+0x350>  // b.pmore
    c9b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    c9b4:	92407c48 	and	x8, x2, #0xffffffff
    c9b8:	2a0503e5 	mov	w5, w5
    c9bc:	d360fc42 	lsr	x2, x2, #32
    c9c0:	d360fc26 	lsr	x6, x1, #32
    c9c4:	cb0a0063 	sub	x3, x3, x10
    c9c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    c9cc:	9b087caa 	mul	x10, x5, x8
    c9d0:	9b087cc8 	mul	x8, x6, x8
    c9d4:	9b0220a5 	madd	x5, x5, x2, x8
    c9d8:	9b027cc6 	mul	x6, x6, x2
    c9dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    c9e0:	8b0900c5 	add	x5, x6, x9
    c9e4:	eb02011f 	cmp	x8, x2
    c9e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    c9ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    c9f0:	eb06007f 	cmp	x3, x6
    c9f4:	540000e3 	b.cc	ca10 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    c9f8:	92407d4a 	and	x10, x10, #0xffffffff
    c9fc:	9ac72000 	lsl	x0, x0, x7
    ca00:	8b028142 	add	x2, x10, x2, lsl #32
    ca04:	eb02001f 	cmp	x0, x2
    ca08:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    ca0c:	54000a01 	b.ne	cb4c <__divti3+0x32c>  // b.any
    ca10:	d1000420 	sub	x0, x1, #0x1
    ca14:	d2800001 	mov	x1, #0x0                   	// #0
    ca18:	17ffffb4 	b	c8e8 <__divti3+0xc8>
    ca1c:	b5000062 	cbnz	x2, ca28 <__divti3+0x208>
    ca20:	d2800022 	mov	x2, #0x1                   	// #1
    ca24:	9ac30846 	udiv	x6, x2, x3
    ca28:	dac010c8 	clz	x8, x6
    ca2c:	b5000408 	cbnz	x8, caac <__divti3+0x28c>
    ca30:	d360fcc9 	lsr	x9, x6, #32
    ca34:	92407cc5 	and	x5, x6, #0xffffffff
    ca38:	cb060023 	sub	x3, x1, x6
    ca3c:	d2800021 	mov	x1, #0x1                   	// #1
    ca40:	9ac90868 	udiv	x8, x3, x9
    ca44:	9b098d03 	msub	x3, x8, x9, x3
    ca48:	aa0803e0 	mov	x0, x8
    ca4c:	9b057d02 	mul	x2, x8, x5
    ca50:	93c78063 	extr	x3, x3, x7, #32
    ca54:	eb03005f 	cmp	x2, x3
    ca58:	540000a9 	b.ls	ca6c <__divti3+0x24c>  // b.plast
    ca5c:	ab0300c3 	adds	x3, x6, x3
    ca60:	d1000500 	sub	x0, x8, #0x1
    ca64:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca68:	54000968 	b.hi	cb94 <__divti3+0x374>  // b.pmore
    ca6c:	cb020063 	sub	x3, x3, x2
    ca70:	9ac90862 	udiv	x2, x3, x9
    ca74:	aa0203e8 	mov	x8, x2
    ca78:	9b098c42 	msub	x2, x2, x9, x3
    ca7c:	aa0703e3 	mov	x3, x7
    ca80:	9b057d05 	mul	x5, x8, x5
    ca84:	b3607c43 	bfi	x3, x2, #32, #32
    ca88:	eb0300bf 	cmp	x5, x3
    ca8c:	540000c9 	b.ls	caa4 <__divti3+0x284>  // b.plast
    ca90:	ab0300c2 	adds	x2, x6, x3
    ca94:	d1000503 	sub	x3, x8, #0x1
    ca98:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ca9c:	d1000908 	sub	x8, x8, #0x2
    caa0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    caa4:	aa008100 	orr	x0, x8, x0, lsl #32
    caa8:	17ffff90 	b	c8e8 <__divti3+0xc8>
    caac:	9ac820c6 	lsl	x6, x6, x8
    cab0:	d2800803 	mov	x3, #0x40                  	// #64
    cab4:	cb080063 	sub	x3, x3, x8
    cab8:	d360fcc9 	lsr	x9, x6, #32
    cabc:	9ac82027 	lsl	x7, x1, x8
    cac0:	92407cc5 	and	x5, x6, #0xffffffff
    cac4:	9ac32422 	lsr	x2, x1, x3
    cac8:	9ac32403 	lsr	x3, x0, x3
    cacc:	aa070063 	orr	x3, x3, x7
    cad0:	9ac9084a 	udiv	x10, x2, x9
    cad4:	9ac82007 	lsl	x7, x0, x8
    cad8:	9b098940 	msub	x0, x10, x9, x2
    cadc:	aa0a03e1 	mov	x1, x10
    cae0:	9b0a7ca2 	mul	x2, x5, x10
    cae4:	93c38000 	extr	x0, x0, x3, #32
    cae8:	eb00005f 	cmp	x2, x0
    caec:	540000a9 	b.ls	cb00 <__divti3+0x2e0>  // b.plast
    caf0:	ab0000c0 	adds	x0, x6, x0
    caf4:	d1000541 	sub	x1, x10, #0x1
    caf8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cafc:	54000468 	b.hi	cb88 <__divti3+0x368>  // b.pmore
    cb00:	cb020000 	sub	x0, x0, x2
    cb04:	9ac9080a 	udiv	x10, x0, x9
    cb08:	9b098140 	msub	x0, x10, x9, x0
    cb0c:	aa0a03e2 	mov	x2, x10
    cb10:	9b0a7ca8 	mul	x8, x5, x10
    cb14:	b3607c03 	bfi	x3, x0, #32, #32
    cb18:	eb03011f 	cmp	x8, x3
    cb1c:	540000a9 	b.ls	cb30 <__divti3+0x310>  // b.plast
    cb20:	ab0300c3 	adds	x3, x6, x3
    cb24:	d1000542 	sub	x2, x10, #0x1
    cb28:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cb2c:	54000288 	b.hi	cb7c <__divti3+0x35c>  // b.pmore
    cb30:	cb080063 	sub	x3, x3, x8
    cb34:	aa018041 	orr	x1, x2, x1, lsl #32
    cb38:	17ffffc2 	b	ca40 <__divti3+0x220>
    cb3c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cb40:	d2800001 	mov	x1, #0x0                   	// #0
    cb44:	9a9f87e0 	cset	x0, ls	// ls = plast
    cb48:	17ffff68 	b	c8e8 <__divti3+0xc8>
    cb4c:	aa0103e0 	mov	x0, x1
    cb50:	d2800001 	mov	x1, #0x0                   	// #0
    cb54:	17ffff65 	b	c8e8 <__divti3+0xc8>
    cb58:	d1000860 	sub	x0, x3, #0x2
    cb5c:	8b0600a5 	add	x5, x5, x6
    cb60:	17ffff52 	b	c8a8 <__divti3+0x88>
    cb64:	d1000961 	sub	x1, x11, #0x2
    cb68:	8b0800a5 	add	x5, x5, x8
    cb6c:	17ffff85 	b	c980 <__divti3+0x160>
    cb70:	d1000965 	sub	x5, x11, #0x2
    cb74:	8b080063 	add	x3, x3, x8
    cb78:	17ffff8e 	b	c9b0 <__divti3+0x190>
    cb7c:	d1000942 	sub	x2, x10, #0x2
    cb80:	8b060063 	add	x3, x3, x6
    cb84:	17ffffeb 	b	cb30 <__divti3+0x310>
    cb88:	d1000941 	sub	x1, x10, #0x2
    cb8c:	8b060000 	add	x0, x0, x6
    cb90:	17ffffdc 	b	cb00 <__divti3+0x2e0>
    cb94:	d1000900 	sub	x0, x8, #0x2
    cb98:	8b060063 	add	x3, x3, x6
    cb9c:	17ffffb4 	b	ca6c <__divti3+0x24c>

000000000000cba0 <__modti3>:
    cba0:	d503245f 	bti	c
    cba4:	d2800004 	mov	x4, #0x0                   	// #0
    cba8:	b6f80081 	tbz	x1, #63, cbb8 <__modti3+0x18>
    cbac:	eb0003e0 	negs	x0, x0
    cbb0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cbb4:	da0103e1 	ngc	x1, x1
    cbb8:	f100007f 	cmp	x3, #0x0
    cbbc:	5400128b 	b.lt	ce0c <__modti3+0x26c>  // b.tstop
    cbc0:	aa0003e7 	mov	x7, x0
    cbc4:	aa0103e6 	mov	x6, x1
    cbc8:	540004e1 	b.ne	cc64 <__modti3+0xc4>  // b.any
    cbcc:	eb02003f 	cmp	x1, x2
    cbd0:	54000dc2 	b.cs	cd88 <__modti3+0x1e8>  // b.hs, b.nlast
    cbd4:	dac01043 	clz	x3, x2
    cbd8:	aa0303e5 	mov	x5, x3
    cbdc:	b40000e3 	cbz	x3, cbf8 <__modti3+0x58>
    cbe0:	4b0303e6 	neg	w6, w3
    cbe4:	9ac32021 	lsl	x1, x1, x3
    cbe8:	9ac32042 	lsl	x2, x2, x3
    cbec:	9ac62406 	lsr	x6, x0, x6
    cbf0:	aa0100c6 	orr	x6, x6, x1
    cbf4:	9ac32007 	lsl	x7, x0, x3
    cbf8:	d360fc40 	lsr	x0, x2, #32
    cbfc:	92407c43 	and	x3, x2, #0xffffffff
    cc00:	9ac008c1 	udiv	x1, x6, x0
    cc04:	9b009826 	msub	x6, x1, x0, x6
    cc08:	9b017c61 	mul	x1, x3, x1
    cc0c:	93c780c6 	extr	x6, x6, x7, #32
    cc10:	eb06003f 	cmp	x1, x6
    cc14:	540000a9 	b.ls	cc28 <__modti3+0x88>  // b.plast
    cc18:	ab060046 	adds	x6, x2, x6
    cc1c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cc20:	8b0200c8 	add	x8, x6, x2
    cc24:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cc28:	cb0100c6 	sub	x6, x6, x1
    cc2c:	9ac008c8 	udiv	x8, x6, x0
    cc30:	9b009901 	msub	x1, x8, x0, x6
    cc34:	aa0703e0 	mov	x0, x7
    cc38:	9b087c63 	mul	x3, x3, x8
    cc3c:	b3607c20 	bfi	x0, x1, #32, #32
    cc40:	eb00007f 	cmp	x3, x0
    cc44:	54001088 	b.hi	ce54 <__modti3+0x2b4>  // b.pmore
    cc48:	cb030000 	sub	x0, x0, x3
    cc4c:	9ac52400 	lsr	x0, x0, x5
    cc50:	d2800001 	mov	x1, #0x0                   	// #0
    cc54:	b4000064 	cbz	x4, cc60 <__modti3+0xc0>
    cc58:	eb0003e0 	negs	x0, x0
    cc5c:	da0103e1 	ngc	x1, x1
    cc60:	d65f03c0 	ret
    cc64:	dac01066 	clz	x6, x3
    cc68:	eb03003f 	cmp	x1, x3
    cc6c:	54ffff43 	b.cc	cc54 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cc70:	93407cc5 	sxtw	x5, w6
    cc74:	d2800808 	mov	x8, #0x40                  	// #64
    cc78:	cb050108 	sub	x8, x8, x5
    cc7c:	9ac62063 	lsl	x3, x3, x6
    cc80:	9ac62025 	lsl	x5, x1, x6
    cc84:	9ac82447 	lsr	x7, x2, x8
    cc88:	aa0300e7 	orr	x7, x7, x3
    cc8c:	9ac82423 	lsr	x3, x1, x8
    cc90:	92407cec 	and	x12, x7, #0xffffffff
    cc94:	d360fcea 	lsr	x10, x7, #32
    cc98:	9ac82401 	lsr	x1, x0, x8
    cc9c:	aa050021 	orr	x1, x1, x5
    cca0:	9ac62042 	lsl	x2, x2, x6
    cca4:	9ac62000 	lsl	x0, x0, x6
    cca8:	9aca086b 	udiv	x11, x3, x10
    ccac:	9b0a8d63 	msub	x3, x11, x10, x3
    ccb0:	aa0b03e5 	mov	x5, x11
    ccb4:	9b0b7d89 	mul	x9, x12, x11
    ccb8:	93c18063 	extr	x3, x3, x1, #32
    ccbc:	eb03013f 	cmp	x9, x3
    ccc0:	540000a9 	b.ls	ccd4 <__modti3+0x134>  // b.plast
    ccc4:	ab0300e3 	adds	x3, x7, x3
    ccc8:	d1000565 	sub	x5, x11, #0x1
    cccc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ccd0:	54001168 	b.hi	cefc <__modti3+0x35c>  // b.pmore
    ccd4:	cb090063 	sub	x3, x3, x9
    ccd8:	9aca086b 	udiv	x11, x3, x10
    ccdc:	9b0a8d6a 	msub	x10, x11, x10, x3
    cce0:	aa0b03e9 	mov	x9, x11
    cce4:	9b0b7d8c 	mul	x12, x12, x11
    cce8:	b3607d41 	bfi	x1, x10, #32, #32
    ccec:	eb01019f 	cmp	x12, x1
    ccf0:	540000a9 	b.ls	cd04 <__modti3+0x164>  // b.plast
    ccf4:	ab0100e1 	adds	x1, x7, x1
    ccf8:	d1000569 	sub	x9, x11, #0x1
    ccfc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cd00:	54000f88 	b.hi	cef0 <__modti3+0x350>  // b.pmore
    cd04:	aa058123 	orr	x3, x9, x5, lsl #32
    cd08:	92407c4b 	and	x11, x2, #0xffffffff
    cd0c:	2a0903e9 	mov	w9, w9
    cd10:	d360fc4a 	lsr	x10, x2, #32
    cd14:	d360fc63 	lsr	x3, x3, #32
    cd18:	cb0c0021 	sub	x1, x1, x12
    cd1c:	aa0a03ec 	mov	x12, x10
    cd20:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cd24:	9b0b7d25 	mul	x5, x9, x11
    cd28:	9b0b7c6b 	mul	x11, x3, x11
    cd2c:	9b0a2d29 	madd	x9, x9, x10, x11
    cd30:	92407caa 	and	x10, x5, #0xffffffff
    cd34:	9b0c7c63 	mul	x3, x3, x12
    cd38:	8b458125 	add	x5, x9, x5, lsr #32
    cd3c:	8b0d0069 	add	x9, x3, x13
    cd40:	eb05017f 	cmp	x11, x5
    cd44:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cd48:	8b058149 	add	x9, x10, x5, lsl #32
    cd4c:	8b458063 	add	x3, x3, x5, lsr #32
    cd50:	eb03003f 	cmp	x1, x3
    cd54:	54000063 	b.cc	cd60 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cd58:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cd5c:	54000082 	b.cs	cd6c <__modti3+0x1cc>  // b.hs, b.nlast
    cd60:	eb020129 	subs	x9, x9, x2
    cd64:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cd68:	cb070063 	sub	x3, x3, x7
    cd6c:	eb090000 	subs	x0, x0, x9
    cd70:	da030021 	sbc	x1, x1, x3
    cd74:	9ac62400 	lsr	x0, x0, x6
    cd78:	9ac82028 	lsl	x8, x1, x8
    cd7c:	aa000100 	orr	x0, x8, x0
    cd80:	9ac62421 	lsr	x1, x1, x6
    cd84:	17ffffb4 	b	cc54 <__modti3+0xb4>
    cd88:	b5000062 	cbnz	x2, cd94 <__modti3+0x1f4>
    cd8c:	d2800023 	mov	x3, #0x1                   	// #1
    cd90:	9ac20862 	udiv	x2, x3, x2
    cd94:	dac01048 	clz	x8, x2
    cd98:	aa0803e5 	mov	x5, x8
    cd9c:	b5000668 	cbnz	x8, ce68 <__modti3+0x2c8>
    cda0:	cb020020 	sub	x0, x1, x2
    cda4:	d360fc49 	lsr	x9, x2, #32
    cda8:	92407c4a 	and	x10, x2, #0xffffffff
    cdac:	9ac90801 	udiv	x1, x0, x9
    cdb0:	9b098020 	msub	x0, x1, x9, x0
    cdb4:	9b0a7c21 	mul	x1, x1, x10
    cdb8:	93c78000 	extr	x0, x0, x7, #32
    cdbc:	eb00003f 	cmp	x1, x0
    cdc0:	540000a9 	b.ls	cdd4 <__modti3+0x234>  // b.plast
    cdc4:	ab000040 	adds	x0, x2, x0
    cdc8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cdcc:	8b020003 	add	x3, x0, x2
    cdd0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cdd4:	cb010001 	sub	x1, x0, x1
    cdd8:	9ac90820 	udiv	x0, x1, x9
    cddc:	9b098403 	msub	x3, x0, x9, x1
    cde0:	aa0703e1 	mov	x1, x7
    cde4:	9b0a7c00 	mul	x0, x0, x10
    cde8:	b3607c61 	bfi	x1, x3, #32, #32
    cdec:	eb01001f 	cmp	x0, x1
    cdf0:	540000a9 	b.ls	ce04 <__modti3+0x264>  // b.plast
    cdf4:	ab010041 	adds	x1, x2, x1
    cdf8:	8b020022 	add	x2, x1, x2
    cdfc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ce00:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ce04:	cb000020 	sub	x0, x1, x0
    ce08:	17ffff91 	b	cc4c <__modti3+0xac>
    ce0c:	eb0203e5 	negs	x5, x2
    ce10:	aa0003e7 	mov	x7, x0
    ce14:	da0303e8 	ngc	x8, x3
    ce18:	aa0503e2 	mov	x2, x5
    ce1c:	aa0803e3 	mov	x3, x8
    ce20:	aa0103e6 	mov	x6, x1
    ce24:	b4ffed48 	cbz	x8, cbcc <__modti3+0x2c>
    ce28:	eb01011f 	cmp	x8, x1
    ce2c:	54fff148 	b.hi	cc54 <__modti3+0xb4>  // b.pmore
    ce30:	dac01109 	clz	x9, x8
    ce34:	2a0903e6 	mov	w6, w9
    ce38:	b5fff1c9 	cbnz	x9, cc70 <__modti3+0xd0>
    ce3c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ce40:	54000068 	b.hi	ce4c <__modti3+0x2ac>  // b.pmore
    ce44:	eb050007 	subs	x7, x0, x5
    ce48:	da080021 	sbc	x1, x1, x8
    ce4c:	aa0703e0 	mov	x0, x7
    ce50:	17ffff81 	b	cc54 <__modti3+0xb4>
    ce54:	ab000040 	adds	x0, x2, x0
    ce58:	8b020002 	add	x2, x0, x2
    ce5c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    ce60:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    ce64:	17ffff79 	b	cc48 <__modti3+0xa8>
    ce68:	9ac82042 	lsl	x2, x2, x8
    ce6c:	d2800803 	mov	x3, #0x40                  	// #64
    ce70:	cb080063 	sub	x3, x3, x8
    ce74:	d360fc49 	lsr	x9, x2, #32
    ce78:	9ac82027 	lsl	x7, x1, x8
    ce7c:	92407c4a 	and	x10, x2, #0xffffffff
    ce80:	9ac32426 	lsr	x6, x1, x3
    ce84:	9ac32403 	lsr	x3, x0, x3
    ce88:	aa070063 	orr	x3, x3, x7
    ce8c:	9ac908c1 	udiv	x1, x6, x9
    ce90:	9ac82007 	lsl	x7, x0, x8
    ce94:	9b099820 	msub	x0, x1, x9, x6
    ce98:	9b017d41 	mul	x1, x10, x1
    ce9c:	93c38000 	extr	x0, x0, x3, #32
    cea0:	eb00003f 	cmp	x1, x0
    cea4:	540000a9 	b.ls	ceb8 <__modti3+0x318>  // b.plast
    cea8:	ab000040 	adds	x0, x2, x0
    ceac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ceb0:	8b020006 	add	x6, x0, x2
    ceb4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    ceb8:	cb010000 	sub	x0, x0, x1
    cebc:	9ac90801 	udiv	x1, x0, x9
    cec0:	9b098026 	msub	x6, x1, x9, x0
    cec4:	aa0303e0 	mov	x0, x3
    cec8:	9b017d41 	mul	x1, x10, x1
    cecc:	b3607cc0 	bfi	x0, x6, #32, #32
    ced0:	eb00003f 	cmp	x1, x0
    ced4:	540000a9 	b.ls	cee8 <__modti3+0x348>  // b.plast
    ced8:	ab000040 	adds	x0, x2, x0
    cedc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cee0:	8b020003 	add	x3, x0, x2
    cee4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cee8:	cb010000 	sub	x0, x0, x1
    ceec:	17ffffb0 	b	cdac <__modti3+0x20c>
    cef0:	d1000969 	sub	x9, x11, #0x2
    cef4:	8b070021 	add	x1, x1, x7
    cef8:	17ffff83 	b	cd04 <__modti3+0x164>
    cefc:	d1000965 	sub	x5, x11, #0x2
    cf00:	8b070063 	add	x3, x3, x7
    cf04:	17ffff74 	b	ccd4 <__modti3+0x134>
    cf08:	d503201f 	nop
    cf0c:	d503201f 	nop

000000000000cf10 <atexit>:
    cf10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cf14:	900000a2 	adrp	x2, 20000 <__data_start>
    cf18:	d2800001 	mov	x1, #0x0                   	// #0
    cf1c:	910003fd 	mov	x29, sp
    cf20:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cf24:	f9400442 	ldr	x2, [x2, #8]
    cf28:	17ffd63a 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cf2c <_fini>:
    cf2c:	d503201f 	nop
    cf30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cf34:	910003fd 	mov	x29, sp
    cf38:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cf3c:	d65f03c0 	ret
