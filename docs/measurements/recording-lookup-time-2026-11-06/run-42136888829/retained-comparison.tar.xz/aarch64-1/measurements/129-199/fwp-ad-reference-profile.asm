
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__modti3+0x60>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911a60a5 	add	x5, x5, #0x698
    2aa0:	f0000044 	adrp	x4, d000 <__modti3+0x60>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911a8084 	add	x4, x4, #0x6a0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe8e0>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__modti3+0x60>
    2b34:	912fa000 	add	x0, x0, #0xbe8
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x2070>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91198042 	add	x2, x2, #0x660
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943da60 	ldr	w0, [x19, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__modti3+0x60>
    2c7c:	912fe000 	add	x0, x0, #0xbf8
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__modti3+0x60>
    2c8c:	91326000 	add	x0, x0, #0xc98
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__modti3+0x60>
    2ca4:	9131c000 	add	x0, x0, #0xc70
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__modti3+0x60>
    2cb0:	91310000 	add	x0, x0, #0xc40
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__modti3+0x60>
    2cbc:	91306000 	add	x0, x0, #0xc18
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xcc0>
    2eb4:	910bc021 	add	x1, x1, #0x2f0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xcc0>
    3158:	910b4021 	add	x1, x1, #0x2d0
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3190:	910d2000 	add	x0, x0, #0x348
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000042 	adrp	x2, d000 <__modti3+0x60>
    339c:	910d8042 	add	x2, x2, #0x360
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000042 	adrp	x2, d000 <__modti3+0x60>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	910ee042 	add	x2, x2, #0x3b8
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000059 	adrp	x25, d000 <__modti3+0x60>
    3428:	d000005a 	adrp	x26, d000 <__modti3+0x60>
    342c:	91106339 	add	x25, x25, #0x418
    3430:	910e035a 	add	x26, x26, #0x380
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000005b 	adrp	x27, d000 <__modti3+0x60>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	910e2377 	add	x23, x27, #0x388
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	91116000 	add	x0, x0, #0x458
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    34fc:	d0000043 	adrp	x3, d000 <__modti3+0x60>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000055 	adrp	x21, d000 <__modti3+0x60>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	910e0063 	add	x3, x3, #0x380
    3520:	9111c2b5 	add	x21, x21, #0x470
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	9112c000 	add	x0, x0, #0x4b0
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    35ac:	910e4000 	add	x0, x0, #0x390
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    366c:	910d2000 	add	x0, x0, #0x348
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__modti3+0x60>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9112e021 	add	x1, x1, #0x4b8
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__modti3+0x60>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91130021 	add	x1, x1, #0x4c0
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__modti3+0x60>
    37e0:	91132021 	add	x1, x1, #0x4c8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__modti3+0x60>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91134042 	add	x2, x2, #0x4d0
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3950:	910d2000 	add	x0, x0, #0x348
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3970:	91138000 	add	x0, x0, #0x4e0
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3a08:	91140000 	add	x0, x0, #0x500
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3a18:	91148000 	add	x0, x0, #0x520
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xcc0>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0c020 	ldr	q0, [x1, #768]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3b18:	91152000 	add	x0, x0, #0x548
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3b88:	9115e000 	add	x0, x0, #0x578
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__modti3+0x60>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	91172084 	add	x4, x4, #0x5c8
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__modti3+0x60>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91178084 	add	x4, x4, #0x5e0
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__modti3+0x60>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91174084 	add	x4, x4, #0x5d0
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3fa8:	9118c042 	add	x2, x2, #0x630
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__modti3+0x60>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__modti3+0x60>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	9117a021 	add	x1, x1, #0x5e8
    4004:	9117c000 	add	x0, x0, #0x5f0
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__modti3+0x60>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91184042 	add	x2, x2, #0x610
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    410c:	9114c061 	add	x1, x3, #0x530
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    411c:	9118c262 	add	x2, x19, #0x630
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xcc0>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    414c:	9115c021 	add	x1, x1, #0x570
    4150:	3dc0c443 	ldr	q3, [x2, #784]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    417c:	9114c063 	add	x3, x3, #0x530
    4180:	91174084 	add	x4, x4, #0x5d0
    4184:	9118c266 	add	x6, x19, #0x630
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	9118c275 	add	x21, x19, #0x630
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4268:	911b0000 	add	x0, x0, #0x6c0
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	9118c273 	add	x19, x19, #0x630
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	91014122 	add	x2, x9, #0x50
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9406046 	ldr	x6, [x2, #192]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	91014120 	add	x0, x9, #0x50
    4354:	f900640b 	str	x11, [x0, #200]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	91014129 	add	x9, x9, #0x50
    4360:	f9006126 	str	x6, [x9, #192]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <ad_raw_free.part.0>:
    4380:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	91114082 	add	x2, x4, #0x450
    438c:	14000005 	b	43a0 <ad_raw_free.part.0+0x20>
    4390:	91000421 	add	x1, x1, #0x1
    4394:	91006042 	add	x2, x2, #0x18
    4398:	f140043f 	cmp	x1, #0x1, lsl #12
    439c:	54000220 	b.eq	43e0 <ad_raw_free.part.0+0x60>  // b.none
    43a0:	f9400043 	ldr	x3, [x2]
    43a4:	eb03001f 	cmp	x0, x3
    43a8:	54ffff41 	b.ne	4390 <ad_raw_free.part.0+0x10>  // b.any
    43ac:	8b010421 	add	x1, x1, x1, lsl #1
    43b0:	91114084 	add	x4, x4, #0x450
    43b4:	900000e2 	adrp	x2, 20000 <__data_start>
    43b8:	91014042 	add	x2, x2, #0x50
    43bc:	8b010c81 	add	x1, x4, x1, lsl #3
    43c0:	b9401024 	ldr	w4, [x1, #16]
    43c4:	f9400425 	ldr	x5, [x1, #8]
    43c8:	a9007c3f 	stp	xzr, xzr, [x1]
    43cc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43d0:	f900083f 	str	xzr, [x1, #16]
    43d4:	cb050061 	sub	x1, x3, x5
    43d8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43dc:	17fff961 	b	2960 <free@plt>
    43e0:	f100001f 	cmp	x0, #0x0
    43e4:	b0000041 	adrp	x1, d000 <__modti3+0x60>
    43e8:	911ba021 	add	x1, x1, #0x6e8
    43ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43f0:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    43f4:	911b4000 	add	x0, x0, #0x6d0
    43f8:	910003fd 	mov	x29, sp
    43fc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4400:	97fffbe0 	bl	3380 <ad_raw_fail>

0000000000004404 <fwp_tape_buffers_dispose>:
    4404:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4408:	910003fd 	mov	x29, sp
    440c:	f9000bf3 	str	x19, [sp, #16]
    4410:	aa0003f3 	mov	x19, x0
    4414:	f9400000 	ldr	x0, [x0]
    4418:	b4000040 	cbz	x0, 4420 <fwp_tape_buffers_dispose+0x1c>
    441c:	97ffffd9 	bl	4380 <ad_raw_free.part.0>
    4420:	f9400a60 	ldr	x0, [x19, #16]
    4424:	b4000040 	cbz	x0, 442c <fwp_tape_buffers_dispose+0x28>
    4428:	97ffffd6 	bl	4380 <ad_raw_free.part.0>
    442c:	f9401260 	ldr	x0, [x19, #32]
    4430:	b4000040 	cbz	x0, 4438 <fwp_tape_buffers_dispose+0x34>
    4434:	97ffffd3 	bl	4380 <ad_raw_free.part.0>
    4438:	4f000400 	movi	v0.4s, #0x0
    443c:	f9001a7f 	str	xzr, [x19, #48]
    4440:	ad000260 	stp	q0, q0, [x19]
    4444:	3d800a60 	str	q0, [x19, #32]
    4448:	f9400bf3 	ldr	x19, [sp, #16]
    444c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4450:	d65f03c0 	ret

0000000000004454 <ad_raw_realloc>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	f90013f5 	str	x21, [sp, #32]
    4464:	b40005a1 	cbz	x1, 4518 <ad_raw_realloc+0xc4>
    4468:	aa0103f4 	mov	x20, x1
    446c:	2a0203f5 	mov	w21, w2
    4470:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    4474:	d2800004 	mov	x4, #0x0                   	// #0
    4478:	91114025 	add	x5, x1, #0x450
    447c:	14000005 	b	4490 <ad_raw_realloc+0x3c>
    4480:	91000484 	add	x4, x4, #0x1
    4484:	910060a5 	add	x5, x5, #0x18
    4488:	f140049f 	cmp	x4, #0x1, lsl #12
    448c:	54000320 	b.eq	44f0 <ad_raw_realloc+0x9c>  // b.none
    4490:	f94000a6 	ldr	x6, [x5]
    4494:	eb06001f 	cmp	x0, x6
    4498:	54ffff41 	b.ne	4480 <ad_raw_realloc+0x2c>  // b.any
    449c:	8b040484 	add	x4, x4, x4, lsl #1
    44a0:	91114021 	add	x1, x1, #0x450
    44a4:	8b040c33 	add	x19, x1, x4, lsl #3
    44a8:	b4000080 	cbz	x0, 44b8 <ad_raw_realloc+0x64>
    44ac:	b9401261 	ldr	w1, [x19, #16]
    44b0:	6b15003f 	cmp	w1, w21
    44b4:	540002c1 	b.ne	450c <ad_raw_realloc+0xb8>  // b.any
    44b8:	aa1403e1 	mov	x1, x20
    44bc:	97fff8f5 	bl	2890 <realloc@plt>
    44c0:	aa0003ed 	mov	x13, x0
    44c4:	b40000c0 	cbz	x0, 44dc <ad_raw_realloc+0x88>
    44c8:	2a1503e3 	mov	w3, w21
    44cc:	aa1403e2 	mov	x2, x20
    44d0:	aa1303e0 	mov	x0, x19
    44d4:	aa0d03e1 	mov	x1, x13
    44d8:	97fffaae 	bl	2f90 <ad_raw_record>
    44dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e0:	aa0d03e0 	mov	x0, x13
    44e4:	f94013f5 	ldr	x21, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f100001f 	cmp	x0, #0x0
    44f4:	b0000041 	adrp	x1, d000 <__modti3+0x60>
    44f8:	911ba021 	add	x1, x1, #0x6e8
    44fc:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4500:	911b4000 	add	x0, x0, #0x6d0
    4504:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4508:	97fffb9e 	bl	3380 <ad_raw_fail>
    450c:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4510:	911ca000 	add	x0, x0, #0x728
    4514:	97fffb9b 	bl	3380 <ad_raw_fail>
    4518:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    451c:	911c2000 	add	x0, x0, #0x708
    4520:	97fffb98 	bl	3380 <ad_raw_fail>

0000000000004524 <fwp_tape_buffers_release>:
    4524:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4528:	910003fd 	mov	x29, sp
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	aa0003f4 	mov	x20, x0
    4534:	f9401400 	ldr	x0, [x0, #40]
    4538:	a9025bf5 	stp	x21, x22, [sp, #32]
    453c:	b7f80560 	tbnz	x0, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4540:	f9401a93 	ldr	x19, [x20, #48]
    4544:	b7f80533 	tbnz	x19, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4548:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    454c:	eb01001f 	cmp	x0, x1
    4550:	540004c8 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4554:	8b000400 	add	x0, x0, x0, lsl #1
    4558:	d2a00101 	mov	x1, #0x80000               	// #524288
    455c:	d37df000 	lsl	x0, x0, #3
    4560:	cb000021 	sub	x1, x1, x0
    4564:	eb410e7f 	cmp	x19, x1, lsr #3
    4568:	54000408 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    456c:	8b130c13 	add	x19, x0, x19, lsl #3
    4570:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4574:	911d0000 	add	x0, x0, #0x740
    4578:	97fff92e 	bl	2a30 <getenv@plt>
    457c:	b4000080 	cbz	x0, 458c <fwp_tape_buffers_release+0x68>
    4580:	39400001 	ldrb	w1, [x0]
    4584:	7100c03f 	cmp	w1, #0x30
    4588:	54000880 	b.eq	4698 <fwp_tape_buffers_release+0x174>  // b.none
    458c:	d1000661 	sub	x1, x19, #0x1
    4590:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4594:	eb00003f 	cmp	x1, x0
    4598:	54000328 	b.hi	45fc <fwp_tape_buffers_release+0xd8>  // b.pmore
    459c:	900000f5 	adrp	x21, 20000 <__data_start>
    45a0:	f9001bf7 	str	x23, [sp, #48]
    45a4:	910142b7 	add	x23, x21, #0x50
    45a8:	910382f6 	add	x22, x23, #0xe0
    45ac:	aa1603e0 	mov	x0, x22
    45b0:	97ffff95 	bl	4404 <fwp_tape_buffers_dispose>
    45b4:	ad400a81 	ldp	q1, q2, [x20]
    45b8:	f9008ef3 	str	x19, [x23, #280]
    45bc:	4f000400 	movi	v0.4s, #0x0
    45c0:	ad000ac1 	stp	q1, q2, [x22]
    45c4:	3dc00a81 	ldr	q1, [x20, #32]
    45c8:	3d800ac1 	str	q1, [x22, #32]
    45cc:	f9401a80 	ldr	x0, [x20, #48]
    45d0:	f9001ac0 	str	x0, [x22, #48]
    45d4:	f9001a9f 	str	xzr, [x20, #48]
    45d8:	ad000280 	stp	q0, q0, [x20]
    45dc:	3d800a80 	str	q0, [x20, #32]
    45e0:	f9401bf7 	ldr	x23, [sp, #48]
    45e4:	1400000b 	b	4610 <fwp_tape_buffers_release+0xec>
    45e8:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    45ec:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45f0:	911d0000 	add	x0, x0, #0x740
    45f4:	97fff90f 	bl	2a30 <getenv@plt>
    45f8:	b5fffc40 	cbnz	x0, 4580 <fwp_tape_buffers_release+0x5c>
    45fc:	aa1403e0 	mov	x0, x20
    4600:	97ffff81 	bl	4404 <fwp_tape_buffers_dispose>
    4604:	900000f5 	adrp	x21, 20000 <__data_start>
    4608:	910142a0 	add	x0, x21, #0x50
    460c:	f9408c13 	ldr	x19, [x0, #280]
    4610:	910142a2 	add	x2, x21, #0x50
    4614:	f9409044 	ldr	x4, [x2, #288]
    4618:	a9400c45 	ldp	x5, x3, [x2]
    461c:	8b040481 	add	x1, x4, x4, lsl #1
    4620:	f9400840 	ldr	x0, [x2, #16]
    4624:	8b010881 	add	x1, x4, x1, lsl #2
    4628:	f9400c44 	ldr	x4, [x2, #24]
    462c:	8b0300a3 	add	x3, x5, x3
    4630:	d37df021 	lsl	x1, x1, #3
    4634:	8b040000 	add	x0, x0, x4
    4638:	8b030000 	add	x0, x0, x3
    463c:	eb05003f 	cmp	x1, x5
    4640:	54000321 	b.ne	46a4 <fwp_tape_buffers_release+0x180>  // b.any
    4644:	8b130023 	add	x3, x1, x19
    4648:	eb00007f 	cmp	x3, x0
    464c:	540002c8 	b.hi	46a4 <fwp_tape_buffers_release+0x180>  // b.pmore
    4650:	f9405c43 	ldr	x3, [x2, #184]
    4654:	f140087f 	cmp	x3, #0x2, lsl #12
    4658:	540002e0 	b.eq	46b4 <fwp_tape_buffers_release+0x190>  // b.none
    465c:	8b030464 	add	x4, x3, x3, lsl #1
    4660:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    4664:	911140a5 	add	x5, x5, #0x450
    4668:	cb010000 	sub	x0, x0, x1
    466c:	d37df084 	lsl	x4, x4, #3
    4670:	cb130000 	sub	x0, x0, x19
    4674:	8b0400a6 	add	x6, x5, x4
    4678:	91000463 	add	x3, x3, #0x1
    467c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4680:	f82468a1 	str	x1, [x5, x4]
    4684:	a90080d3 	stp	x19, x0, [x6, #8]
    4688:	f9005c43 	str	x3, [x2, #184]
    468c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4694:	d65f03c0 	ret
    4698:	39400400 	ldrb	w0, [x0, #1]
    469c:	34fffb00 	cbz	w0, 45fc <fwp_tape_buffers_release+0xd8>
    46a0:	17ffffbb 	b	458c <fwp_tape_buffers_release+0x68>
    46a4:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    46a8:	911d6000 	add	x0, x0, #0x758
    46ac:	f9001bf7 	str	x23, [sp, #48]
    46b0:	97fffb34 	bl	3380 <ad_raw_fail>
    46b4:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    46b8:	911e2000 	add	x0, x0, #0x788
    46bc:	f9001bf7 	str	x23, [sp, #48]
    46c0:	97fffb30 	bl	3380 <ad_raw_fail>

00000000000046c4 <fwp_poll_events>:
    46c4:	d10103ff 	sub	sp, sp, #0x40
    46c8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    46cc:	f947f400 	ldr	x0, [x0, #4072]
    46d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46d4:	910083fd 	add	x29, sp, #0x20
    46d8:	a90353f3 	stp	x19, x20, [sp, #48]
    46dc:	900000f4 	adrp	x20, 20000 <__data_start>
    46e0:	f9400001 	ldr	x1, [x0]
    46e4:	f9000fe1 	str	x1, [sp, #24]
    46e8:	d2800001 	mov	x1, #0x0                   	// #0
    46ec:	97fffca5 	bl	3980 <fwp_now_ns>
    46f0:	91014281 	add	x1, x20, #0x50
    46f4:	f9409433 	ldr	x19, [x1, #296]
    46f8:	b4000e73 	cbz	x19, 48c4 <fwp_poll_events+0x200>
    46fc:	aa1303e1 	mov	x1, x19
    4700:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4704:	14000005 	b	4718 <fwp_poll_events+0x54>
    4708:	f9408821 	ldr	x1, [x1, #272]
    470c:	eb03005f 	cmp	x2, x3
    4710:	9a83d042 	csel	x2, x2, x3, le
    4714:	b40000c1 	cbz	x1, 472c <fwp_poll_events+0x68>
    4718:	f9403423 	ldr	x3, [x1, #104]
    471c:	b6ffff62 	tbz	x2, #63, 4708 <fwp_poll_events+0x44>
    4720:	f9408821 	ldr	x1, [x1, #272]
    4724:	aa0303e2 	mov	x2, x3
    4728:	b5ffff81 	cbnz	x1, 4718 <fwp_poll_events+0x54>
    472c:	b7f80cc2 	tbnz	x2, #63, 48c4 <fwp_poll_events+0x200>
    4730:	cb000042 	sub	x2, x2, x0
    4734:	f100005f 	cmp	x2, #0x0
    4738:	540005ad 	b.le	47ec <fwp_poll_events+0x128>
    473c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4740:	d2884801 	mov	x1, #0x4240                	// #16960
    4744:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4748:	f2a001e1 	movk	x1, #0xf, lsl #16
    474c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4750:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4754:	f2e86360 	movk	x0, #0x431b, lsl #48
    4758:	9b407c40 	smulh	x0, x2, x0
    475c:	9352fc00 	asr	x0, x0, #18
    4760:	cb82fc00 	sub	x0, x0, x2, asr #63
    4764:	9b018802 	msub	x2, x0, x1, x2
    4768:	f100005f 	cmp	x2, #0x0
    476c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4770:	eb03001f 	cmp	x0, x3
    4774:	540009ec 	b.gt	48b0 <fwp_poll_events+0x1ec>
    4778:	340003a0 	cbz	w0, 47ec <fwp_poll_events+0x128>
    477c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4780:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4784:	72a20c42 	movk	w2, #0x1062, lsl #16
    4788:	9ba27c02 	umull	x2, w0, w2
    478c:	d366fc43 	lsr	x3, x2, #38
    4790:	aa0303e2 	mov	x2, x3
    4794:	1b048063 	msub	w3, w3, w4, w0
    4798:	9b217c63 	smull	x3, w3, w1
    479c:	d2800001 	mov	x1, #0x0                   	// #0
    47a0:	910023e0 	add	x0, sp, #0x8
    47a4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47a8:	97fff872 	bl	2970 <nanosleep@plt>
    47ac:	91014280 	add	x0, x20, #0x50
    47b0:	f9409413 	ldr	x19, [x0, #296]
    47b4:	97fffc73 	bl	3980 <fwp_now_ns>
    47b8:	aa0003e6 	mov	x6, x0
    47bc:	b50001d3 	cbnz	x19, 47f4 <fwp_poll_events+0x130>
    47c0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    47c4:	f947f400 	ldr	x0, [x0, #4072]
    47c8:	f9400fe2 	ldr	x2, [sp, #24]
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	eb010042 	subs	x2, x2, x1
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	540008c1 	b.ne	48f0 <fwp_poll_events+0x22c>  // b.any
    47dc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47e4:	910103ff 	add	sp, sp, #0x40
    47e8:	d65f03c0 	ret
    47ec:	97fffc65 	bl	3980 <fwp_now_ns>
    47f0:	aa0003e6 	mov	x6, x0
    47f4:	4f000400 	movi	v0.4s, #0x0
    47f8:	91014288 	add	x8, x20, #0x50
    47fc:	52800027 	mov	w7, #0x1                   	// #1
    4800:	f9403661 	ldr	x1, [x19, #104]
    4804:	aa1303e5 	mov	x5, x19
    4808:	f9408a73 	ldr	x19, [x19, #272]
    480c:	eb06003f 	cmp	x1, x6
    4810:	5400032c 	b.gt	4874 <fwp_poll_events+0x1b0>
    4814:	394154a0 	ldrb	w0, [x5, #85]
    4818:	36000120 	tbz	w0, #0, 483c <fwp_poll_events+0x178>
    481c:	f94084a0 	ldr	x0, [x5, #264]
    4820:	b40003c0 	cbz	x0, 4898 <fwp_poll_events+0x1d4>
    4824:	f9008813 	str	x19, [x0, #272]
    4828:	b4000053 	cbz	x19, 4830 <fwp_poll_events+0x16c>
    482c:	f9008660 	str	x0, [x19, #264]
    4830:	910800a0 	add	x0, x5, #0x200
    4834:	390154bf 	strb	wzr, [x5, #85]
    4838:	3c908000 	stur	q0, [x0, #-248]
    483c:	f94030a0 	ldr	x0, [x5, #96]
    4840:	390158a7 	strb	w7, [x5, #86]
    4844:	f100001f 	cmp	x0, #0x0
    4848:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    484c:	5400018d 	b.le	487c <fwp_poll_events+0x1b8>
    4850:	f94028a0 	ldr	x0, [x5, #80]
    4854:	f2001c1f 	tst	x0, #0xff000000ff
    4858:	540000e1 	b.ne	4874 <fwp_poll_events+0x1b0>  // b.any
    485c:	f9406100 	ldr	x0, [x8, #192]
    4860:	390150a7 	strb	w7, [x5, #84]
    4864:	f90080bf 	str	xzr, [x5, #256]
    4868:	b40001e0 	cbz	x0, 48a4 <fwp_poll_events+0x1e0>
    486c:	f9006105 	str	x5, [x8, #192]
    4870:	f9008005 	str	x5, [x0, #256]
    4874:	b5fffc73 	cbnz	x19, 4800 <fwp_poll_events+0x13c>
    4878:	17ffffd2 	b	47c0 <fwp_poll_events+0xfc>
    487c:	394144a0 	ldrb	w0, [x5, #81]
    4880:	3707fe80 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    4884:	394140a0 	ldrb	w0, [x5, #80]
    4888:	3707fe40 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    488c:	aa0503e0 	mov	x0, x5
    4890:	97fffb98 	bl	36f0 <fwp_cancel_tree.part.0>
    4894:	17ffffef 	b	4850 <fwp_poll_events+0x18c>
    4898:	91014281 	add	x1, x20, #0x50
    489c:	f9009433 	str	x19, [x1, #296]
    48a0:	17ffffe2 	b	4828 <fwp_poll_events+0x164>
    48a4:	f9006105 	str	x5, [x8, #192]
    48a8:	f9006505 	str	x5, [x8, #200]
    48ac:	17fffff2 	b	4874 <fwp_poll_events+0x1b0>
    48b0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    48b4:	d2989362 	mov	x2, #0xc49b                	// #50331
    48b8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    48bc:	f2a00402 	movk	x2, #0x20, lsl #16
    48c0:	17ffffb7 	b	479c <fwp_poll_events+0xd8>
    48c4:	97fff9ec 	bl	3074 <fwp_flush>
    48c8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    48cc:	f947e863 	ldr	x3, [x3, #4048]
    48d0:	d2800562 	mov	x2, #0x2b                  	// #43
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    48dc:	911ea000 	add	x0, x0, #0x7a8
    48e0:	f9400063 	ldr	x3, [x3]
    48e4:	97fff82f 	bl	29a0 <fwrite@plt>
    48e8:	52800ca0 	mov	w0, #0x65                  	// #101
    48ec:	97fff799 	bl	2750 <exit@plt>
    48f0:	97fff7ec 	bl	28a0 <__stack_chk_fail@plt>

00000000000048f4 <fwp_rc_wide_dup>:
    48f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48f8:	910003fd 	mov	x29, sp
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f3 	mov	x19, x0
    4904:	ca404400 	eor	x0, x0, x0, lsr #17
    4908:	f90013f5 	str	x21, [sp, #32]
    490c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4910:	ca402400 	eor	x0, x0, x0, lsr #9
    4914:	9118c2a2 	add	x2, x21, #0x630
    4918:	92401c00 	and	x0, x0, #0xff
    491c:	910a2403 	add	x3, x0, #0x289
    4920:	8b000c40 	add	x0, x2, x0, lsl #3
    4924:	8b030c54 	add	x20, x2, x3, lsl #3
    4928:	f94a2401 	ldr	x1, [x0, #5192]
    492c:	b50000a1 	cbnz	x1, 4940 <fwp_rc_wide_dup+0x4c>
    4930:	1400002d 	b	49e4 <fwp_rc_wide_dup+0xf0>
    4934:	91004034 	add	x20, x1, #0x10
    4938:	f9400821 	ldr	x1, [x1, #16]
    493c:	b4000241 	cbz	x1, 4984 <fwp_rc_wide_dup+0x90>
    4940:	f9400022 	ldr	x2, [x1]
    4944:	eb02027f 	cmp	x19, x2
    4948:	54ffff61 	b.ne	4934 <fwp_rc_wide_dup+0x40>  // b.any
    494c:	f9400281 	ldr	x1, [x20]
    4950:	39400260 	ldrb	w0, [x19]
    4954:	7103f81f 	cmp	w0, #0xfe
    4958:	54000220 	b.eq	499c <fwp_rc_wide_dup+0xa8>  // b.none
    495c:	b40001a1 	cbz	x1, 4990 <fwp_rc_wide_dup+0x9c>
    4960:	f9400420 	ldr	x0, [x1, #8]
    4964:	b100041f 	cmn	x0, #0x1
    4968:	540004a0 	b.eq	49fc <fwp_rc_wide_dup+0x108>  // b.none
    496c:	91000400 	add	x0, x0, #0x1
    4970:	f9000420 	str	x0, [x1, #8]
    4974:	a94153f3 	ldp	x19, x20, [sp, #16]
    4978:	f94013f5 	ldr	x21, [sp, #32]
    497c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4980:	d65f03c0 	ret
    4984:	39400260 	ldrb	w0, [x19]
    4988:	7103f81f 	cmp	w0, #0xfe
    498c:	540000a0 	b.eq	49a0 <fwp_rc_wide_dup+0xac>  // b.none
    4990:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4994:	91200000 	add	x0, x0, #0x800
    4998:	97fffb9a 	bl	3800 <fwp_trap>
    499c:	b5000281 	cbnz	x1, 49ec <fwp_rc_wide_dup+0xf8>
    49a0:	d2800300 	mov	x0, #0x18                  	// #24
    49a4:	97fff7a7 	bl	2840 <malloc@plt>
    49a8:	b4000280 	cbz	x0, 49f8 <fwp_rc_wide_dup+0x104>
    49ac:	d2801fe1 	mov	x1, #0xff                  	// #255
    49b0:	a9000413 	stp	x19, x1, [x0]
    49b4:	9118c2b5 	add	x21, x21, #0x630
    49b8:	f900081f 	str	xzr, [x0, #16]
    49bc:	12800001 	mov	w1, #0xffffffff            	// #-1
    49c0:	f9000280 	str	x0, [x20]
    49c4:	39000261 	strb	w1, [x19]
    49c8:	f94e26a0 	ldr	x0, [x21, #7240]
    49cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    49d0:	91000400 	add	x0, x0, #0x1
    49d4:	f90e26a0 	str	x0, [x21, #7240]
    49d8:	f94013f5 	ldr	x21, [sp, #32]
    49dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49e0:	d65f03c0 	ret
    49e4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49e8:	17ffffda 	b	4950 <fwp_rc_wide_dup+0x5c>
    49ec:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    49f0:	911f6000 	add	x0, x0, #0x7d8
    49f4:	97fffb83 	bl	3800 <fwp_trap>
    49f8:	97fff9de 	bl	3170 <fwp_heap_oom>
    49fc:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4a00:	9120a000 	add	x0, x0, #0x828
    4a04:	97fffb7f 	bl	3800 <fwp_trap>
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_rc_forget_slot>:
    4a10:	aa0003e1 	mov	x1, x0
    4a14:	39400000 	ldrb	w0, [x0]
    4a18:	7103fc1f 	cmp	w0, #0xff
    4a1c:	54000040 	b.eq	4a24 <fwp_rc_forget_slot+0x14>  // b.none
    4a20:	d65f03c0 	ret
    4a24:	ca414420 	eor	x0, x1, x1, lsr #17
    4a28:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a30:	910003fd 	mov	x29, sp
    4a34:	92401c00 	and	x0, x0, #0xff
    4a38:	f9000bf3 	str	x19, [sp, #16]
    4a3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4a40:	9118c262 	add	x2, x19, #0x630
    4a44:	910a2403 	add	x3, x0, #0x289
    4a48:	8b000c40 	add	x0, x2, x0, lsl #3
    4a4c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a50:	f94a2400 	ldr	x0, [x0, #5192]
    4a54:	b50000a0 	cbnz	x0, 4a68 <fwp_rc_forget_slot+0x58>
    4a58:	14000011 	b	4a9c <fwp_rc_forget_slot+0x8c>
    4a5c:	91004003 	add	x3, x0, #0x10
    4a60:	f9400800 	ldr	x0, [x0, #16]
    4a64:	b40001c0 	cbz	x0, 4a9c <fwp_rc_forget_slot+0x8c>
    4a68:	f9400002 	ldr	x2, [x0]
    4a6c:	eb02003f 	cmp	x1, x2
    4a70:	54ffff61 	b.ne	4a5c <fwp_rc_forget_slot+0x4c>  // b.any
    4a74:	f9400801 	ldr	x1, [x0, #16]
    4a78:	9118c273 	add	x19, x19, #0x630
    4a7c:	f9000061 	str	x1, [x3]
    4a80:	97fff7b8 	bl	2960 <free@plt>
    4a84:	f94e2660 	ldr	x0, [x19, #7240]
    4a88:	d1000400 	sub	x0, x0, #0x1
    4a8c:	f90e2660 	str	x0, [x19, #7240]
    4a90:	f9400bf3 	ldr	x19, [sp, #16]
    4a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a98:	d65f03c0 	ret
    4a9c:	b0000040 	adrp	x0, d000 <__modti3+0x60>
    4aa0:	91200000 	add	x0, x0, #0x800
    4aa4:	97fffb57 	bl	3800 <fwp_trap>
    4aa8:	d503201f 	nop
    4aac:	d503201f 	nop

0000000000004ab0 <fwp_rc_prepare_chunk>:
    4ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ab4:	910003fd 	mov	x29, sp
    4ab8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4abc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4ac0:	9118c2c2 	add	x2, x22, #0x630
    4ac4:	b9401c03 	ldr	w3, [x0, #28]
    4ac8:	aa0103f5 	mov	x21, x1
    4acc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ad0:	aa0003f4 	mov	x20, x0
    4ad4:	f94e2440 	ldr	x0, [x2, #7240]
    4ad8:	b4000440 	cbz	x0, 4b60 <fwp_rc_prepare_chunk+0xb0>
    4adc:	d2800013 	mov	x19, #0x0                   	// #0
    4ae0:	35000203 	cbnz	w3, 4b20 <fwp_rc_prepare_chunk+0x70>
    4ae4:	b4000361 	cbz	x1, 4b50 <fwp_rc_prepare_chunk+0xa0>
    4ae8:	f9401280 	ldr	x0, [x20, #32]
    4aec:	97fff79d 	bl	2960 <free@plt>
    4af0:	aa1503e0 	mov	x0, x21
    4af4:	d2800021 	mov	x1, #0x1                   	// #1
    4af8:	97fff762 	bl	2880 <calloc@plt>
    4afc:	f9001280 	str	x0, [x20, #32]
    4b00:	b5000460 	cbnz	x0, 4b8c <fwp_rc_prepare_chunk+0xdc>
    4b04:	97fff99b 	bl	3170 <fwp_heap_oom>
    4b08:	97ffffc2 	bl	4a10 <fwp_rc_forget_slot>
    4b0c:	91000673 	add	x19, x19, #0x1
    4b10:	b9401e83 	ldr	w3, [x20, #28]
    4b14:	eb13007f 	cmp	x3, x19
    4b18:	54000169 	b.ls	4b44 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b1c:	d503201f 	nop
    4b20:	f9401283 	ldr	x3, [x20, #32]
    4b24:	8b130060 	add	x0, x3, x19
    4b28:	38736863 	ldrb	w3, [x3, x19]
    4b2c:	7103fc7f 	cmp	w3, #0xff
    4b30:	54fffec0 	b.eq	4b08 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b34:	b9401e83 	ldr	w3, [x20, #28]
    4b38:	91000673 	add	x19, x19, #0x1
    4b3c:	eb13007f 	cmp	x3, x19
    4b40:	54ffff08 	b.hi	4b20 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b44:	eb0302bf 	cmp	x21, x3
    4b48:	54000121 	b.ne	4b6c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b4c:	b5000335 	cbnz	x21, 4bb0 <fwp_rc_prepare_chunk+0x100>
    4b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b5c:	d65f03c0 	ret
    4b60:	2a0303e3 	mov	w3, w3
    4b64:	eb0302bf 	cmp	x21, x3
    4b68:	54ffff20 	b.eq	4b4c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b6c:	9118c2c2 	add	x2, x22, #0x630
    4b70:	f9401280 	ldr	x0, [x20, #32]
    4b74:	f94e2841 	ldr	x1, [x2, #7248]
    4b78:	cb030021 	sub	x1, x1, x3
    4b7c:	f90e2841 	str	x1, [x2, #7248]
    4b80:	97fff778 	bl	2960 <free@plt>
    4b84:	b5fffb75 	cbnz	x21, 4af0 <fwp_rc_prepare_chunk+0x40>
    4b88:	f900129f 	str	xzr, [x20, #32]
    4b8c:	9118c2d6 	add	x22, x22, #0x630
    4b90:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b94:	b9001e95 	str	w21, [x20, #28]
    4b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b9c:	8b150000 	add	x0, x0, x21
    4ba0:	f90e2ac0 	str	x0, [x22, #7248]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	f9401280 	ldr	x0, [x20, #32]
    4bb4:	aa1503e2 	mov	x2, x21
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	52800001 	mov	w1, #0x0                   	// #0
    4bc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bc8:	17fff72a 	b	2870 <memset@plt>
    4bcc:	d503201f 	nop

0000000000004bd0 <fwp_heap_refill>:
    4bd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4bd4:	910003fd 	mov	x29, sp
    4bd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bdc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4be0:	9118c2b5 	add	x21, x21, #0x630
    4be4:	aa0003f6 	mov	x22, x0
    4be8:	d2800020 	mov	x0, #0x1                   	// #1
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bf4:	2a0103f7 	mov	w23, w1
    4bf8:	2a0203f8 	mov	w24, w2
    4bfc:	97fff96d 	bl	31b0 <fwp_heap_chunks>
    4c00:	aa0003f3 	mov	x19, x0
    4c04:	f949fea2 	ldr	x2, [x21, #5112]
    4c08:	8b000800 	add	x0, x0, x0, lsl #2
    4c0c:	2a1703e1 	mov	w1, w23
    4c10:	52800025 	mov	w5, #0x1                   	// #1
    4c14:	d37df000 	lsl	x0, x0, #3
    4c18:	910f0021 	add	x1, x1, #0x3c0
    4c1c:	8b000054 	add	x20, x2, x0
    4c20:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c24:	52a00024 	mov	w4, #0x10000               	// #65536
    4c28:	38206845 	strb	w5, [x2, x0]
    4c2c:	aa1403e0 	mov	x0, x20
    4c30:	39000698 	strb	w24, [x20, #1]
    4c34:	39000a97 	strb	w23, [x20, #2]
    4c38:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c3c:	b9000681 	str	w1, [x20, #4]
    4c40:	2a0103e5 	mov	w5, w1
    4c44:	8b0300a2 	add	x2, x5, x3
    4c48:	1ac10881 	udiv	w1, w4, w1
    4c4c:	9ac50842 	udiv	x2, x2, x5
    4c50:	b9000a81 	str	w1, [x20, #8]
    4c54:	92404021 	and	x1, x1, #0x1ffff
    4c58:	b9001a82 	str	w2, [x20, #24]
    4c5c:	97ffff95 	bl	4ab0 <fwp_rc_prepare_chunk>
    4c60:	f949daa0 	ldr	x0, [x21, #5040]
    4c64:	29408a81 	ldp	w1, w2, [x20, #4]
    4c68:	8b134000 	add	x0, x0, x19, lsl #16
    4c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c70:	8b214003 	add	x3, x0, w1, uxtw
    4c74:	9ba20021 	umaddl	x1, w1, w2, x0
    4c78:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c7c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c88:	d65f03c0 	ret
    4c8c:	d503201f 	nop

0000000000004c90 <fwp_mem_free>:
    4c90:	b40003c0 	cbz	x0, 4d08 <fwp_mem_free+0x78>
    4c94:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c98:	910003fd 	mov	x29, sp
    4c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ca0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4ca4:	9118c2a1 	add	x1, x21, #0x630
    4ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cac:	aa0003f3 	mov	x19, x0
    4cb0:	f949d823 	ldr	x3, [x1, #5040]
    4cb4:	f949ec22 	ldr	x2, [x1, #5080]
    4cb8:	cb030000 	sub	x0, x0, x3
    4cbc:	eb02401f 	cmp	x0, x2, lsl #16
    4cc0:	540001c2 	b.cs	4cf8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4cc4:	d350fc16 	lsr	x22, x0, #16
    4cc8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ccc:	f949fc22 	ldr	x2, [x1, #5112]
    4cd0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4cd4:	d37df294 	lsl	x20, x20, #3
    4cd8:	ab140057 	adds	x23, x2, x20
    4cdc:	540000c0 	b.eq	4cf4 <fwp_mem_free+0x64>  // b.none
    4ce0:	38746842 	ldrb	w2, [x2, x20]
    4ce4:	7100045f 	cmp	w2, #0x1
    4ce8:	54000120 	b.eq	4d0c <fwp_mem_free+0x7c>  // b.none
    4cec:	7100085f 	cmp	w2, #0x2
    4cf0:	540005e0 	b.eq	4dac <fwp_mem_free+0x11c>  // b.none
    4cf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d00:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d04:	d65f03c0 	ret
    4d08:	d65f03c0 	ret
    4d0c:	f94012f8 	ldr	x24, [x23, #32]
    4d10:	b94006e1 	ldr	w1, [x23, #4]
    4d14:	f90023f9 	str	x25, [sp, #64]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	394006f9 	ldrb	w25, [x23, #1]
    4d20:	39400af4 	ldrb	w20, [x23, #2]
    4d24:	b4000158 	cbz	x24, 4d4c <fwp_mem_free+0xbc>
    4d28:	92403e76 	and	x22, x19, #0xffff
    4d2c:	9ac20ad6 	udiv	x22, x22, x2
    4d30:	38766b01 	ldrb	w1, [x24, x22]
    4d34:	8b160300 	add	x0, x24, x22
    4d38:	7103fc3f 	cmp	w1, #0xff
    4d3c:	54000980 	b.eq	4e6c <fwp_mem_free+0x1dc>  // b.none
    4d40:	38366b1f 	strb	wzr, [x24, x22]
    4d44:	b94006e1 	ldr	w1, [x23, #4]
    4d48:	2a0103e2 	mov	w2, w1
    4d4c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d50:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d54:	cb390000 	sub	x0, x0, w25, uxtb
    4d58:	8b340074 	add	x20, x3, w20, uxtb
    4d5c:	9118c2b5 	add	x21, x21, #0x630
    4d60:	1e630021 	ucvtf	d1, w1
    4d64:	d37ae400 	lsl	x0, x0, #6
    4d68:	8b140c14 	add	x20, x0, x20, lsl #3
    4d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d70:	f8746aa0 	ldr	x0, [x21, x20]
    4d74:	f94023f9 	ldr	x25, [sp, #64]
    4d78:	aa2003e0 	mvn	x0, x0
    4d7c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d80:	f9000260 	str	x0, [x19]
    4d84:	f8346ab3 	str	x19, [x21, x20]
    4d88:	f94a12a0 	ldr	x0, [x21, #5152]
    4d8c:	1e612800 	fadd	d0, d0, d1
    4d90:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d94:	cb020000 	sub	x0, x0, x2
    4d98:	f90a12a0 	str	x0, [x21, #5152]
    4d9c:	fd0a22a0 	str	d0, [x21, #5184]
    4da0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4da8:	d65f03c0 	ret
    4dac:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4db0:	8b000063 	add	x3, x3, x0
    4db4:	eb03027f 	cmp	x19, x3
    4db8:	54fff9e1 	b.ne	4cf4 <fwp_mem_free+0x64>  // b.any
    4dbc:	fd400ae1 	ldr	d1, [x23, #16]
    4dc0:	fd4a2020 	ldr	d0, [x1, #5184]
    4dc4:	f9400ae0 	ldr	x0, [x23, #16]
    4dc8:	7e61d821 	ucvtf	d1, d1
    4dcc:	f94a1022 	ldr	x2, [x1, #5152]
    4dd0:	f94012f3 	ldr	x19, [x23, #32]
    4dd4:	1e612800 	fadd	d0, d0, d1
    4dd8:	cb000042 	sub	x2, x2, x0
    4ddc:	f90a1022 	str	x2, [x1, #5152]
    4de0:	fd0a2020 	str	d0, [x1, #5184]
    4de4:	b40000b3 	cbz	x19, 4df8 <fwp_mem_free+0x168>
    4de8:	39400260 	ldrb	w0, [x19]
    4dec:	7103fc1f 	cmp	w0, #0xff
    4df0:	54000380 	b.eq	4e60 <fwp_mem_free+0x1d0>  // b.none
    4df4:	3900027f 	strb	wzr, [x19]
    4df8:	b9400ee2 	ldr	w2, [x23, #12]
    4dfc:	b4000142 	cbz	x2, 4e24 <fwp_mem_free+0x194>
    4e00:	9118c2a1 	add	x1, x21, #0x630
    4e04:	8b160040 	add	x0, x2, x22
    4e08:	8b000800 	add	x0, x0, x0, lsl #2
    4e0c:	f949fc21 	ldr	x1, [x1, #5112]
    4e10:	8b140034 	add	x20, x1, x20
    4e14:	8b000c20 	add	x0, x1, x0, lsl #3
    4e18:	3802869f 	strb	wzr, [x20], #40
    4e1c:	eb00029f 	cmp	x20, x0
    4e20:	54ffffc1 	b.ne	4e18 <fwp_mem_free+0x188>  // b.any
    4e24:	9118c2a0 	add	x0, x21, #0x630
    4e28:	f94a1801 	ldr	x1, [x0, #5168]
    4e2c:	f949f803 	ldr	x3, [x0, #5104]
    4e30:	8b020021 	add	x1, x1, x2
    4e34:	f90a1801 	str	x1, [x0, #5168]
    4e38:	eb16007f 	cmp	x3, x22
    4e3c:	54000049 	b.ls	4e44 <fwp_mem_free+0x1b4>  // b.plast
    4e40:	f909f816 	str	x22, [x0, #5104]
    4e44:	9118c2b5 	add	x21, x21, #0x630
    4e48:	f949f6a0 	ldr	x0, [x21, #5096]
    4e4c:	eb16001f 	cmp	x0, x22
    4e50:	54fff529 	b.ls	4cf4 <fwp_mem_free+0x64>  // b.plast
    4e54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e58:	f909f6b6 	str	x22, [x21, #5096]
    4e5c:	17ffffa7 	b	4cf8 <fwp_mem_free+0x68>
    4e60:	aa1303e0 	mov	x0, x19
    4e64:	97fffeeb 	bl	4a10 <fwp_rc_forget_slot>
    4e68:	17ffffe3 	b	4df4 <fwp_mem_free+0x164>
    4e6c:	97fffee9 	bl	4a10 <fwp_rc_forget_slot>
    4e70:	17ffffb4 	b	4d40 <fwp_mem_free+0xb0>

0000000000004e74 <fwp_heap_alloc_big>:
    4e74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e78:	910003fd 	mov	x29, sp
    4e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e80:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	aa0003f7 	mov	x23, x0
    4e8c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e94:	eb0002ff 	cmp	x23, x0
    4e98:	54000888 	b.hi	4fa8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ea0:	8b0002f4 	add	x20, x23, x0
    4ea4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4ea8:	9118c359 	add	x25, x26, #0x630
    4eac:	d350fe94 	lsr	x20, x20, #16
    4eb0:	2a0103f5 	mov	w21, w1
    4eb4:	aa1403e0 	mov	x0, x20
    4eb8:	97fff8be 	bl	31b0 <fwp_heap_chunks>
    4ebc:	f949ff22 	ldr	x2, [x25, #5112]
    4ec0:	8b000813 	add	x19, x0, x0, lsl #2
    4ec4:	aa0003f8 	mov	x24, x0
    4ec8:	52800043 	mov	w3, #0x2                   	// #2
    4ecc:	d37df273 	lsl	x19, x19, #3
    4ed0:	d2800021 	mov	x1, #0x1                   	// #1
    4ed4:	8b130040 	add	x0, x2, x19
    4ed8:	38336843 	strb	w3, [x2, x19]
    4edc:	39000415 	strb	w21, [x0, #1]
    4ee0:	b9000c14 	str	w20, [x0, #12]
    4ee4:	f9000817 	str	x23, [x0, #16]
    4ee8:	97fffef2 	bl	4ab0 <fwp_rc_prepare_chunk>
    4eec:	f100069f 	cmp	x20, #0x1
    4ef0:	54000269 	b.ls	4f3c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ef4:	8b180294 	add	x20, x20, x24
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	a90573fb 	stp	x27, x28, [sp, #80]
    4f00:	5280007b 	mov	w27, #0x3                   	// #3
    4f04:	8b140a94 	add	x20, x20, x20, lsl #2
    4f08:	2a1803fc 	mov	w28, w24
    4f0c:	9adb2296 	lsl	x22, x20, x27
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffee4 	bl	4ab0 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0x9c>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x104>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffc1c 	bl	4104 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff70 	b	4e74 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffeb5 	bl	4bd0 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	54000861 	b.ne	5244 <fwp_heap_alloc+0x134>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	540006e2 	b.cs	5290 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	540002cc 	b.gt	5258 <fwp_heap_alloc+0x148>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000209 	b.ls	5274 <fwp_heap_alloc+0x164>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	17ffffe8 	b	51e0 <fwp_heap_alloc+0xd0>
    5244:	a9538c44 	ldp	x4, x3, [x2, #312]
    5248:	91000484 	add	x4, x4, #0x1
    524c:	8b000063 	add	x3, x3, x0
    5250:	a9138c44 	stp	x4, x3, [x2, #312]
    5254:	17ffffba 	b	513c <fwp_heap_alloc+0x2c>
    5258:	a94153f3 	ldp	x19, x20, [sp, #16]
    525c:	fd00a800 	str	d0, [x0, #336]
    5260:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5264:	aa0403e0 	mov	x0, x4
    5268:	a94363f7 	ldp	x23, x24, [sp, #48]
    526c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5270:	d65f03c0 	ret
    5274:	7100043f 	cmp	w1, #0x1
    5278:	8b140085 	add	x5, x4, x20
    527c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5280:	52800001 	mov	w1, #0x0                   	// #0
    5284:	aa0403e0 	mov	x0, x4
    5288:	f9000465 	str	x5, [x3, #8]
    528c:	17ffffc6 	b	51a4 <fwp_heap_alloc+0x94>
    5290:	97fff7b8 	bl	3170 <fwp_heap_oom>

0000000000005294 <fwp_data.part.0.constprop.0>:
    5294:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5298:	910003fd 	mov	x29, sp
    529c:	a9025bf5 	stp	x21, x22, [sp, #32]
    52a0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52a4:	910142c2 	add	x2, x22, #0x50
    52a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52ac:	b9413059 	ldr	w25, [x2, #304]
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	aa0103f4 	mov	x20, x1
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	2a0003f7 	mov	w23, w0
    52c0:	340000b9 	cbz	w25, 52d4 <fwp_data.part.0.constprop.0+0x40>
    52c4:	a9538041 	ldp	x1, x0, [x2, #312]
    52c8:	91000421 	add	x1, x1, #0x1
    52cc:	91006000 	add	x0, x0, #0x18
    52d0:	a9138041 	stp	x1, x0, [x2, #312]
    52d4:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    52d8:	9118c2a3 	add	x3, x21, #0x630
    52dc:	b953a460 	ldr	w0, [x3, #5028]
    52e0:	34000840 	cbz	w0, 53e8 <fwp_data.part.0.constprop.0+0x154>
    52e4:	397e8862 	ldrb	w2, [x3, #4002]
    52e8:	910f0040 	add	x0, x2, #0x3c0
    52ec:	8b020442 	add	x2, x2, x2, lsl #1
    52f0:	d37df042 	lsl	x2, x2, #3
    52f4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52f8:	2a1a03f8 	mov	w24, w26
    52fc:	f8626873 	ldr	x19, [x3, x2]
    5300:	b4000613 	cbz	x19, 53c0 <fwp_data.part.0.constprop.0+0x12c>
    5304:	f9400260 	ldr	x0, [x19]
    5308:	aa2003e0 	mvn	x0, x0
    530c:	f8226860 	str	x0, [x3, x2]
    5310:	f100631f 	cmp	x24, #0x18
    5314:	540000e9 	b.ls	5330 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5318:	d1006702 	sub	x2, x24, #0x19
    531c:	91006260 	add	x0, x19, #0x18
    5320:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5324:	52800001 	mov	w1, #0x0                   	// #0
    5328:	91002042 	add	x2, x2, #0x8
    532c:	97fff551 	bl	2870 <memset@plt>
    5330:	9118c2a0 	add	x0, x21, #0x630
    5334:	f94a1001 	ldr	x1, [x0, #5152]
    5338:	ab180021 	adds	x1, x1, x24
    533c:	54000642 	b.cs	5404 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5340:	f94a1402 	ldr	x2, [x0, #5160]
    5344:	f90a1001 	str	x1, [x0, #5152]
    5348:	eb02003f 	cmp	x1, x2
    534c:	54000049 	b.ls	5354 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5350:	f90a1401 	str	x1, [x0, #5160]
    5354:	9118c2a0 	add	x0, x21, #0x630
    5358:	1e630341 	ucvtf	d1, w26
    535c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5360:	1e612800 	fadd	d0, d0, d1
    5364:	fd0a1c00 	str	d0, [x0, #5176]
    5368:	34000139 	cbz	w25, 538c <fwp_data.part.0.constprop.0+0xf8>
    536c:	9118c2b5 	add	x21, x21, #0x630
    5370:	910142d6 	add	x22, x22, #0x50
    5374:	fd4a12a0 	ldr	d0, [x21, #5152]
    5378:	6d5486c2 	ldp	d2, d1, [x22, #328]
    537c:	7e61d800 	ucvtf	d0, d0
    5380:	1e623800 	fsub	d0, d0, d2
    5384:	1e612010 	fcmpe	d0, d1
    5388:	540003ac 	b.gt	53fc <fwp_data.part.0.constprop.0+0x168>
    538c:	52800040 	mov	w0, #0x2                   	// #2
    5390:	29000277 	stp	w23, w0, [x19]
    5394:	aa1303e0 	mov	x0, x19
    5398:	f9400281 	ldr	x1, [x20]
    539c:	f9000661 	str	x1, [x19, #8]
    53a0:	f9400681 	ldr	x1, [x20, #8]
    53a4:	f9000a61 	str	x1, [x19, #16]
    53a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53bc:	d65f03c0 	ret
    53c0:	8b020063 	add	x3, x3, x2
    53c4:	f9400473 	ldr	x19, [x3, #8]
    53c8:	b4000113 	cbz	x19, 53e8 <fwp_data.part.0.constprop.0+0x154>
    53cc:	f9400860 	ldr	x0, [x3, #16]
    53d0:	cb130000 	sub	x0, x0, x19
    53d4:	eb00031f 	cmp	x24, x0
    53d8:	54000088 	b.hi	53e8 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53dc:	8b180260 	add	x0, x19, x24
    53e0:	f9000460 	str	x0, [x3, #8]
    53e4:	17ffffcb 	b	5310 <fwp_data.part.0.constprop.0+0x7c>
    53e8:	52800001 	mov	w1, #0x0                   	// #0
    53ec:	d2800300 	mov	x0, #0x18                  	// #24
    53f0:	97ffff48 	bl	5110 <fwp_heap_alloc>
    53f4:	aa0003f3 	mov	x19, x0
    53f8:	17ffffdc 	b	5368 <fwp_data.part.0.constprop.0+0xd4>
    53fc:	fd00aac0 	str	d0, [x22, #336]
    5400:	17ffffe3 	b	538c <fwp_data.part.0.constprop.0+0xf8>
    5404:	97fff75b 	bl	3170 <fwp_heap_oom>
    5408:	d503201f 	nop
    540c:	d503201f 	nop

0000000000005410 <fwp_p_ad_push.constprop.0>:
    5410:	f100001f 	cmp	x0, #0x0
    5414:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5418:	54000eab 	b.lt	55ec <fwp_p_ad_push.constprop.0+0x1dc>  // b.tstop
    541c:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5420:	aa0003e4 	mov	x4, x0
    5424:	910003fd 	mov	x29, sp
    5428:	a9025bf5 	stp	x21, x22, [sp, #32]
    542c:	aa0003f5 	mov	x21, x0
    5430:	aa020000 	orr	x0, x0, x2
    5434:	a90363f7 	stp	x23, x24, [sp, #48]
    5438:	aa0203f7 	mov	x23, x2
    543c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5440:	9e670029 	fmov	d9, x1
    5444:	9e670068 	fmov	d8, x3
    5448:	b6f80920 	tbz	x0, #63, 556c <fwp_p_ad_push.constprop.0+0x15c>
    544c:	a90153f3 	stp	x19, x20, [sp, #16]
    5450:	9360fc80 	asr	x0, x4, #32
    5454:	b6f800c4 	tbz	x4, #63, 546c <fwp_p_ad_push.constprop.0+0x5c>
    5458:	1e604109 	fmov	d9, d8
    545c:	2f00e408 	movi	d8, #0x0
    5460:	9360fc40 	asr	x0, x2, #32
    5464:	aa0203f5 	mov	x21, x2
    5468:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    546c:	97fff9b1 	bl	3b30 <fwp_tape_of>
    5470:	aa0003f3 	mov	x19, x0
    5474:	f9403000 	ldr	x0, [x0, #96]
    5478:	b5001240 	cbnz	x0, 56c0 <fwp_p_ad_push.constprop.0+0x2b0>
    547c:	f9400a76 	ldr	x22, [x19, #16]
    5480:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5484:	eb0002df 	cmp	x22, x0
    5488:	54000d8c 	b.gt	5638 <fwp_p_ad_push.constprop.0+0x228>
    548c:	eb3542df 	cmp	x22, w21, uxtw
    5490:	54000cad 	b.le	5624 <fwp_p_ad_push.constprop.0+0x214>
    5494:	b7f80077 	tbnz	x23, #63, 54a0 <fwp_p_ad_push.constprop.0+0x90>
    5498:	eb3742df 	cmp	x22, w23, uxtw
    549c:	54000c4d 	b.le	5624 <fwp_p_ad_push.constprop.0+0x214>
    54a0:	f9400678 	ldr	x24, [x19, #8]
    54a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54a8:	cb1802d8 	sub	x24, x22, x24
    54ac:	91000701 	add	x1, x24, #0x1
    54b0:	eb00003f 	cmp	x1, x0
    54b4:	54000c28 	b.hi	5638 <fwp_p_ad_push.constprop.0+0x228>  // b.pmore
    54b8:	a9418274 	ldp	x20, x0, [x19, #24]
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	eb14003f 	cmp	x1, x20
    54c4:	540006ad 	b.le	5598 <fwp_p_ad_push.constprop.0+0x188>
    54c8:	f100029f 	cmp	x20, #0x0
    54cc:	d2800803 	mov	x3, #0x40                  	// #64
    54d0:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54d4:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    54dc:	eb14003f 	cmp	x1, x20
    54e0:	5400008d 	b.le	54f0 <fwp_p_ad_push.constprop.0+0xe0>
    54e4:	eb02029f 	cmp	x20, x2
    54e8:	5400054d 	b.le	5590 <fwp_p_ad_push.constprop.0+0x180>
    54ec:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    54f0:	d37df299 	lsl	x25, x20, #3
    54f4:	52800022 	mov	w2, #0x1                   	// #1
    54f8:	aa1903e1 	mov	x1, x25
    54fc:	97fffbd6 	bl	4454 <ad_raw_realloc>
    5500:	aa0003e1 	mov	x1, x0
    5504:	b4000a40 	cbz	x0, 564c <fwp_p_ad_push.constprop.0+0x23c>
    5508:	f9400e63 	ldr	x3, [x19, #24]
    550c:	f9001261 	str	x1, [x19, #32]
    5510:	f9401a60 	ldr	x0, [x19, #48]
    5514:	52800042 	mov	w2, #0x2                   	// #2
    5518:	8b030821 	add	x1, x1, x3, lsl #2
    551c:	f9001661 	str	x1, [x19, #40]
    5520:	d37cee81 	lsl	x1, x20, #4
    5524:	97fffbcc 	bl	4454 <ad_raw_realloc>
    5528:	aa0003e2 	mov	x2, x0
    552c:	b4000900 	cbz	x0, 564c <fwp_p_ad_push.constprop.0+0x23c>
    5530:	f9400e61 	ldr	x1, [x19, #24]
    5534:	d37df31b 	lsl	x27, x24, #3
    5538:	d37ef69a 	lsl	x26, x20, #2
    553c:	d37ef71c 	lsl	x28, x24, #2
    5540:	8b190003 	add	x3, x0, x25
    5544:	8b010c01 	add	x1, x0, x1, lsl #3
    5548:	a9030660 	stp	x0, x1, [x19, #48]
    554c:	b5000558 	cbnz	x24, 55f4 <fwp_p_ad_push.constprop.0+0x1e4>
    5550:	f9001e63 	str	x3, [x19, #56]
    5554:	f9401260 	ldr	x0, [x19, #32]
    5558:	8b1a0001 	add	x1, x0, x26
    555c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5560:	f9000e74 	str	x20, [x19, #24]
    5564:	f9001661 	str	x1, [x19, #40]
    5568:	14000010 	b	55a8 <fwp_p_ad_push.constprop.0+0x198>
    556c:	9360fc40 	asr	x0, x2, #32
    5570:	a90153f3 	stp	x19, x20, [sp, #16]
    5574:	eb84801f 	cmp	x0, x4, asr #32
    5578:	54fff7a0 	b.eq	546c <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    557c:	90000040 	adrp	x0, d000 <__modti3+0x60>
    5580:	91212000 	add	x0, x0, #0x848
    5584:	a9046bf9 	stp	x25, x26, [sp, #64]
    5588:	a90573fb 	stp	x27, x28, [sp, #80]
    558c:	97fff89d 	bl	3800 <fwp_trap>
    5590:	d37ffa94 	lsl	x20, x20, #1
    5594:	17ffffd2 	b	54dc <fwp_p_ad_push.constprop.0+0xcc>
    5598:	a9428a61 	ldp	x1, x2, [x19, #40]
    559c:	d37ef71c 	lsl	x28, x24, #2
    55a0:	f9401e63 	ldr	x3, [x19, #56]
    55a4:	d37df31b 	lsl	x27, x24, #3
    55a8:	b83c6815 	str	w21, [x0, x28]
    55ac:	f10002ff 	cmp	x23, #0x0
    55b0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55b4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55b8:	fc3b6849 	str	d9, [x2, x27]
    55bc:	aa1602a0 	orr	x0, x21, x22
    55c0:	b83c6837 	str	w23, [x1, x28]
    55c4:	910006d6 	add	x22, x22, #0x1
    55c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55cc:	fc3b6868 	str	d8, [x3, x27]
    55d0:	a94573fb 	ldp	x27, x28, [sp, #80]
    55d4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55d8:	f9000a76 	str	x22, [x19, #16]
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    55e8:	d65f03c0 	ret
    55ec:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55f0:	d65f03c0 	ret
    55f4:	aa0303e0 	mov	x0, x3
    55f8:	aa1b03e2 	mov	x2, x27
    55fc:	97fff445 	bl	2710 <memmove@plt>
    5600:	a9420660 	ldp	x0, x1, [x19, #32]
    5604:	aa1c03e2 	mov	x2, x28
    5608:	f9401a63 	ldr	x3, [x19, #48]
    560c:	8b190063 	add	x3, x3, x25
    5610:	f9001e63 	str	x3, [x19, #56]
    5614:	8b1a0000 	add	x0, x0, x26
    5618:	97fff43e 	bl	2710 <memmove@plt>
    561c:	a9430e62 	ldp	x2, x3, [x19, #48]
    5620:	17ffffcd 	b	5554 <fwp_p_ad_push.constprop.0+0x144>
    5624:	90000040 	adrp	x0, d000 <__modti3+0x60>
    5628:	91238000 	add	x0, x0, #0x8e0
    562c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5630:	a90573fb 	stp	x27, x28, [sp, #80]
    5634:	97fff873 	bl	3800 <fwp_trap>
    5638:	90000040 	adrp	x0, d000 <__modti3+0x60>
    563c:	91230000 	add	x0, x0, #0x8c0
    5640:	a9046bf9 	stp	x25, x26, [sp, #64]
    5644:	a90573fb 	stp	x27, x28, [sp, #80]
    5648:	97fff86e 	bl	3800 <fwp_trap>
    564c:	aa1303e0 	mov	x0, x19
    5650:	97fff671 	bl	3014 <fwp_tape_unlink_scope>
    5654:	f9401260 	ldr	x0, [x19, #32]
    5658:	b4000040 	cbz	x0, 5660 <fwp_p_ad_push.constprop.0+0x250>
    565c:	97fffb49 	bl	4380 <ad_raw_free.part.0>
    5660:	f9401a60 	ldr	x0, [x19, #48]
    5664:	b4000040 	cbz	x0, 566c <fwp_p_ad_push.constprop.0+0x25c>
    5668:	97fffb46 	bl	4380 <ad_raw_free.part.0>
    566c:	f9402260 	ldr	x0, [x19, #64]
    5670:	b4000040 	cbz	x0, 5678 <fwp_p_ad_push.constprop.0+0x268>
    5674:	97fffb43 	bl	4380 <ad_raw_free.part.0>
    5678:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    567c:	f947e821 	ldr	x1, [x1, #4048]
    5680:	f9000e7f 	str	xzr, [x19, #24]
    5684:	4f000400 	movi	v0.4s, #0x0
    5688:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    568c:	d2800262 	mov	x2, #0x13                  	// #19
    5690:	f9400023 	ldr	x3, [x1]
    5694:	b900067f 	str	wzr, [x19, #4]
    5698:	d2800021 	mov	x1, #0x1                   	// #1
    569c:	90000040 	adrp	x0, d000 <__modti3+0x60>
    56a0:	910d2000 	add	x0, x0, #0x348
    56a4:	3c808260 	stur	q0, [x19, #8]
    56a8:	ad010260 	stp	q0, q0, [x19, #32]
    56ac:	97fff4bd 	bl	29a0 <fwrite@plt>
    56b0:	d2800000 	mov	x0, #0x0                   	// #0
    56b4:	97fff4c7 	bl	29d0 <fflush@plt>
    56b8:	52800cc0 	mov	w0, #0x66                  	// #102
    56bc:	97fff4d5 	bl	2a10 <_Exit@plt>
    56c0:	90000040 	adrp	x0, d000 <__modti3+0x60>
    56c4:	91224000 	add	x0, x0, #0x890
    56c8:	a9046bf9 	stp	x25, x26, [sp, #64]
    56cc:	a90573fb 	stp	x27, x28, [sp, #80]
    56d0:	97fff84c 	bl	3800 <fwp_trap>

00000000000056d4 <w120>:
    56d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    56d8:	9e660003 	fmov	x3, d0
    56dc:	aa0003e2 	mov	x2, x0
    56e0:	910003fd 	mov	x29, sp
    56e4:	6d0327e8 	stp	d8, d9, [sp, #48]
    56e8:	1e604028 	fmov	d8, d1
    56ec:	1e600809 	fmul	d9, d0, d0
    56f0:	fd0023ea 	str	d10, [sp, #64]
    56f4:	1e60400a 	fmov	d10, d0
    56f8:	a90153f3 	stp	x19, x20, [sp, #16]
    56fc:	aa0003f3 	mov	x19, x0
    5700:	aa0103f4 	mov	x20, x1
    5704:	aa0303e1 	mov	x1, x3
    5708:	a9025bf5 	stp	x21, x22, [sp, #32]
    570c:	97ffff41 	bl	5410 <fwp_p_ad_push.constprop.0>
    5710:	1e693908 	fsub	d8, d8, d9
    5714:	aa1403e2 	mov	x2, x20
    5718:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    571c:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5720:	9e660116 	fmov	x22, d8
    5724:	97ffff3b 	bl	5410 <fwp_p_ad_push.constprop.0>
    5728:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    572c:	aa0003e1 	mov	x1, x0
    5730:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5734:	aa1303e0 	mov	x0, x19
    5738:	1e6a3929 	fsub	d9, d9, d10
    573c:	aa0103f3 	mov	x19, x1
    5740:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5744:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5748:	9e660135 	fmov	x21, d9
    574c:	97ffff31 	bl	5410 <fwp_p_ad_push.constprop.0>
    5750:	1e680908 	fmul	d8, d8, d8
    5754:	aa0003f4 	mov	x20, x0
    5758:	aa1603e3 	mov	x3, x22
    575c:	aa1603e1 	mov	x1, x22
    5760:	aa1303e2 	mov	x2, x19
    5764:	aa1303e0 	mov	x0, x19
    5768:	97ffff2a 	bl	5410 <fwp_p_ad_push.constprop.0>
    576c:	aa0003e2 	mov	x2, x0
    5770:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5774:	9e670020 	fmov	d0, x1
    5778:	9e660101 	fmov	x1, d8
    577c:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5780:	1e600908 	fmul	d8, d8, d0
    5784:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5788:	97ffff22 	bl	5410 <fwp_p_ad_push.constprop.0>
    578c:	1e690929 	fmul	d9, d9, d9
    5790:	aa0003f3 	mov	x19, x0
    5794:	aa1503e3 	mov	x3, x21
    5798:	aa1503e1 	mov	x1, x21
    579c:	aa1403e2 	mov	x2, x20
    57a0:	aa1403e0 	mov	x0, x20
    57a4:	97ffff1b 	bl	5410 <fwp_p_ad_push.constprop.0>
    57a8:	1e692908 	fadd	d8, d8, d9
    57ac:	aa1303e2 	mov	x2, x19
    57b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57b4:	aa0303e1 	mov	x1, x3
    57b8:	97ffff16 	bl	5410 <fwp_p_ad_push.constprop.0>
    57bc:	aa0003e1 	mov	x1, x0
    57c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c4:	9e660100 	fmov	x0, d8
    57c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57cc:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57d0:	fd4023ea 	ldr	d10, [sp, #64]
    57d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    57d8:	d65f03c0 	ret
    57dc:	d503201f 	nop

00000000000057e0 <w176.constprop.0>:
    57e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    57e4:	910003fd 	mov	x29, sp
    57e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    57ec:	fd001be8 	str	d8, [sp, #48]
    57f0:	f9400015 	ldr	x21, [x0]
    57f4:	b4000315 	cbz	x21, 5854 <w176.constprop.0+0x74>
    57f8:	2f00e408 	movi	d8, #0x0
    57fc:	91002016 	add	x22, x0, #0x8
    5800:	a90153f3 	stp	x19, x20, [sp, #16]
    5804:	91004014 	add	x20, x0, #0x10
    5808:	d2800013 	mov	x19, #0x0                   	// #0
    580c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5810:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5814:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5818:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    581c:	aa0303e1 	mov	x1, x3
    5820:	1e602908 	fadd	d8, d8, d0
    5824:	91000a73 	add	x19, x19, #0x2
    5828:	97fffefa 	bl	5410 <fwp_p_ad_push.constprop.0>
    582c:	eb1302bf 	cmp	x21, x19
    5830:	54ffff08 	b.hi	5810 <w176.constprop.0+0x30>  // b.pmore
    5834:	9e660102 	fmov	x2, d8
    5838:	fd401be8 	ldr	d8, [sp, #48]
    583c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5840:	aa0003e1 	mov	x1, x0
    5844:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5848:	aa0203e0 	mov	x0, x2
    584c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5850:	d65f03c0 	ret
    5854:	2f00e408 	movi	d8, #0x0
    5858:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    585c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5860:	aa0003e1 	mov	x1, x0
    5864:	9e660102 	fmov	x2, d8
    5868:	fd401be8 	ldr	d8, [sp, #48]
    586c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5870:	aa0203e0 	mov	x0, x2
    5874:	d65f03c0 	ret
    5878:	d503201f 	nop
    587c:	d503201f 	nop

0000000000005880 <fwp_rc_share>:
    5880:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5884:	9118c042 	add	x2, x2, #0x630
    5888:	f949d843 	ldr	x3, [x2, #5040]
    588c:	f949ec41 	ldr	x1, [x2, #5080]
    5890:	cb030000 	sub	x0, x0, x3
    5894:	eb01401f 	cmp	x0, x1, lsl #16
    5898:	540002c2 	b.cs	58f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    589c:	d350fc01 	lsr	x1, x0, #16
    58a0:	f949fc44 	ldr	x4, [x2, #5112]
    58a4:	8b010821 	add	x1, x1, x1, lsl #2
    58a8:	d37df021 	lsl	x1, x1, #3
    58ac:	8b010083 	add	x3, x4, x1
    58b0:	f9401062 	ldr	x2, [x3, #32]
    58b4:	b40001e2 	cbz	x2, 58f0 <fwp_rc_share+0x70>
    58b8:	38616881 	ldrb	w1, [x4, x1]
    58bc:	7100083f 	cmp	w1, #0x2
    58c0:	540001a0 	b.eq	58f4 <fwp_rc_share+0x74>  // b.none
    58c4:	7100043f 	cmp	w1, #0x1
    58c8:	54000141 	b.ne	58f0 <fwp_rc_share+0x70>  // b.any
    58cc:	29430464 	ldp	w4, w1, [x3, #24]
    58d0:	92403c00 	and	x0, x0, #0xffff
    58d4:	9b047c00 	mul	x0, x0, x4
    58d8:	d360fc00 	lsr	x0, x0, #32
    58dc:	eb01001f 	cmp	x0, x1
    58e0:	54000082 	b.cs	58f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    58e4:	8b000042 	add	x2, x2, x0
    58e8:	39400040 	ldrb	w0, [x2]
    58ec:	350000a0 	cbnz	w0, 5900 <fwp_rc_share+0x80>
    58f0:	d65f03c0 	ret
    58f4:	72003c1f 	tst	w0, #0xffff
    58f8:	54ffff80 	b.eq	58e8 <fwp_rc_share+0x68>  // b.none
    58fc:	d65f03c0 	ret
    5900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5904:	90000040 	adrp	x0, d000 <__modti3+0x60>
    5908:	91240000 	add	x0, x0, #0x900
    590c:	910003fd 	mov	x29, sp
    5910:	97fff7bc 	bl	3800 <fwp_trap>

0000000000005914 <fwp_rc_fresh>:
    5914:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5918:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    591c:	9118c063 	add	x3, x3, #0x630
    5920:	910003fd 	mov	x29, sp
    5924:	a90153f3 	stp	x19, x20, [sp, #16]
    5928:	aa0003f3 	mov	x19, x0
    592c:	f949d861 	ldr	x1, [x3, #5040]
    5930:	f949ec60 	ldr	x0, [x3, #5080]
    5934:	cb010261 	sub	x1, x19, x1
    5938:	eb00403f 	cmp	x1, x0, lsl #16
    593c:	54000322 	b.cs	59a0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5940:	d350fc22 	lsr	x2, x1, #16
    5944:	f949fc63 	ldr	x3, [x3, #5112]
    5948:	8b020842 	add	x2, x2, x2, lsl #2
    594c:	d37df042 	lsl	x2, x2, #3
    5950:	8b020060 	add	x0, x3, x2
    5954:	f9401014 	ldr	x20, [x0, #32]
    5958:	b4000254 	cbz	x20, 59a0 <fwp_rc_fresh+0x8c>
    595c:	38626862 	ldrb	w2, [x3, x2]
    5960:	7100085f 	cmp	w2, #0x2
    5964:	54000260 	b.eq	59b0 <fwp_rc_fresh+0x9c>  // b.none
    5968:	7100045f 	cmp	w2, #0x1
    596c:	540001a1 	b.ne	59a0 <fwp_rc_fresh+0x8c>  // b.any
    5970:	29430002 	ldp	w2, w0, [x0, #24]
    5974:	92403c21 	and	x1, x1, #0xffff
    5978:	9b027c21 	mul	x1, x1, x2
    597c:	d360fc21 	lsr	x1, x1, #32
    5980:	eb00003f 	cmp	x1, x0
    5984:	540000e2 	b.cs	59a0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5988:	8b010294 	add	x20, x20, x1
    598c:	39400280 	ldrb	w0, [x20]
    5990:	7103fc1f 	cmp	w0, #0xff
    5994:	540001a0 	b.eq	59c8 <fwp_rc_fresh+0xb4>  // b.none
    5998:	52800020 	mov	w0, #0x1                   	// #1
    599c:	39000280 	strb	w0, [x20]
    59a0:	aa1303e0 	mov	x0, x19
    59a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    59a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59ac:	d65f03c0 	ret
    59b0:	72003c3f 	tst	w1, #0xffff
    59b4:	54fffec0 	b.eq	598c <fwp_rc_fresh+0x78>  // b.none
    59b8:	aa1303e0 	mov	x0, x19
    59bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    59c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59c4:	d65f03c0 	ret
    59c8:	aa1403e0 	mov	x0, x20
    59cc:	97fffc11 	bl	4a10 <fwp_rc_forget_slot>
    59d0:	17fffff2 	b	5998 <fwp_rc_fresh+0x84>

00000000000059d4 <fwp_rc_free_arr>:
    59d4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    59d8:	9118c063 	add	x3, x3, #0x630
    59dc:	f949d861 	ldr	x1, [x3, #5040]
    59e0:	f949ec62 	ldr	x2, [x3, #5080]
    59e4:	cb010001 	sub	x1, x0, x1
    59e8:	eb02403f 	cmp	x1, x2, lsl #16
    59ec:	54000342 	b.cs	5a54 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    59f0:	d350fc22 	lsr	x2, x1, #16
    59f4:	f949fc65 	ldr	x5, [x3, #5112]
    59f8:	8b020842 	add	x2, x2, x2, lsl #2
    59fc:	d37df042 	lsl	x2, x2, #3
    5a00:	8b0200a4 	add	x4, x5, x2
    5a04:	f9401083 	ldr	x3, [x4, #32]
    5a08:	b4000263 	cbz	x3, 5a54 <fwp_rc_free_arr+0x80>
    5a0c:	386268a2 	ldrb	w2, [x5, x2]
    5a10:	7100085f 	cmp	w2, #0x2
    5a14:	540001c0 	b.eq	5a4c <fwp_rc_free_arr+0x78>  // b.none
    5a18:	7100045f 	cmp	w2, #0x1
    5a1c:	540001c1 	b.ne	5a54 <fwp_rc_free_arr+0x80>  // b.any
    5a20:	29430885 	ldp	w5, w2, [x4, #24]
    5a24:	92403c21 	and	x1, x1, #0xffff
    5a28:	9b057c21 	mul	x1, x1, x5
    5a2c:	d360fc21 	lsr	x1, x1, #32
    5a30:	eb02003f 	cmp	x1, x2
    5a34:	54000102 	b.cs	5a54 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a38:	8b010063 	add	x3, x3, x1
    5a3c:	39400061 	ldrb	w1, [x3]
    5a40:	7100043f 	cmp	w1, #0x1
    5a44:	54000081 	b.ne	5a54 <fwp_rc_free_arr+0x80>  // b.any
    5a48:	17fffc92 	b	4c90 <fwp_mem_free>
    5a4c:	72003c3f 	tst	w1, #0xffff
    5a50:	54ffff60 	b.eq	5a3c <fwp_rc_free_arr+0x68>  // b.none
    5a54:	d65f03c0 	ret
    5a58:	d503201f 	nop
    5a5c:	d503201f 	nop

0000000000005a60 <fwp_rc_dup>:
    5a60:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5a64:	9118c042 	add	x2, x2, #0x630
    5a68:	f949d841 	ldr	x1, [x2, #5040]
    5a6c:	f949ec43 	ldr	x3, [x2, #5080]
    5a70:	cb010001 	sub	x1, x0, x1
    5a74:	eb03403f 	cmp	x1, x3, lsl #16
    5a78:	540003c2 	b.cs	5af0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5a7c:	d350fc20 	lsr	x0, x1, #16
    5a80:	f949fc44 	ldr	x4, [x2, #5112]
    5a84:	8b000800 	add	x0, x0, x0, lsl #2
    5a88:	d37df002 	lsl	x2, x0, #3
    5a8c:	8b020083 	add	x3, x4, x2
    5a90:	f9401060 	ldr	x0, [x3, #32]
    5a94:	b40002e0 	cbz	x0, 5af0 <fwp_rc_dup+0x90>
    5a98:	38626882 	ldrb	w2, [x4, x2]
    5a9c:	7100085f 	cmp	w2, #0x2
    5aa0:	540002a0 	b.eq	5af4 <fwp_rc_dup+0x94>  // b.none
    5aa4:	7100045f 	cmp	w2, #0x1
    5aa8:	54000241 	b.ne	5af0 <fwp_rc_dup+0x90>  // b.any
    5aac:	29430864 	ldp	w4, w2, [x3, #24]
    5ab0:	92403c21 	and	x1, x1, #0xffff
    5ab4:	9b047c21 	mul	x1, x1, x4
    5ab8:	d360fc21 	lsr	x1, x1, #32
    5abc:	eb02003f 	cmp	x1, x2
    5ac0:	54000182 	b.cs	5af0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5ac4:	8b010000 	add	x0, x0, x1
    5ac8:	39400001 	ldrb	w1, [x0]
    5acc:	34000121 	cbz	w1, 5af0 <fwp_rc_dup+0x90>
    5ad0:	f00000c2 	adrp	x2, 20000 <__data_start>
    5ad4:	91014042 	add	x2, x2, #0x50
    5ad8:	b9413043 	ldr	w3, [x2, #304]
    5adc:	35000123 	cbnz	w3, 5b00 <fwp_rc_dup+0xa0>
    5ae0:	7103f43f 	cmp	w1, #0xfd
    5ae4:	54000168 	b.hi	5b10 <fwp_rc_dup+0xb0>  // b.pmore
    5ae8:	11000421 	add	w1, w1, #0x1
    5aec:	39000001 	strb	w1, [x0]
    5af0:	d65f03c0 	ret
    5af4:	72003c3f 	tst	w1, #0xffff
    5af8:	54fffe80 	b.eq	5ac8 <fwp_rc_dup+0x68>  // b.none
    5afc:	d65f03c0 	ret
    5b00:	f940ac43 	ldr	x3, [x2, #344]
    5b04:	91000463 	add	x3, x3, #0x1
    5b08:	f900ac43 	str	x3, [x2, #344]
    5b0c:	17fffff5 	b	5ae0 <fwp_rc_dup+0x80>
    5b10:	17fffb79 	b	48f4 <fwp_rc_wide_dup>

0000000000005b14 <fwp_owned_entry173>:
    5b14:	d10103ff 	sub	sp, sp, #0x40
    5b18:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5b1c:	f947f442 	ldr	x2, [x2, #4072]
    5b20:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b24:	910083fd 	add	x29, sp, #0x20
    5b28:	a90353f3 	stp	x19, x20, [sp, #48]
    5b2c:	f9400043 	ldr	x3, [x2]
    5b30:	f9000fe3 	str	x3, [sp, #24]
    5b34:	d2800003 	mov	x3, #0x0                   	// #0
    5b38:	a9400c01 	ldp	x1, x3, [x0]
    5b3c:	f9400802 	ldr	x2, [x0, #16]
    5b40:	ab020022 	adds	x2, x1, x2
    5b44:	540006e6 	b.vs	5c20 <fwp_owned_entry173+0x10c>
    5b48:	910023e1 	add	x1, sp, #0x8
    5b4c:	52800000 	mov	w0, #0x0                   	// #0
    5b50:	a9008be3 	stp	x3, x2, [sp, #8]
    5b54:	97fffdd0 	bl	5294 <fwp_data.part.0.constprop.0>
    5b58:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5b5c:	9118c063 	add	x3, x3, #0x630
    5b60:	aa0003f3 	mov	x19, x0
    5b64:	f949d861 	ldr	x1, [x3, #5040]
    5b68:	f949ec60 	ldr	x0, [x3, #5080]
    5b6c:	cb010261 	sub	x1, x19, x1
    5b70:	eb00403f 	cmp	x1, x0, lsl #16
    5b74:	54000322 	b.cs	5bd8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5b78:	d350fc22 	lsr	x2, x1, #16
    5b7c:	f949fc63 	ldr	x3, [x3, #5112]
    5b80:	8b020842 	add	x2, x2, x2, lsl #2
    5b84:	d37df042 	lsl	x2, x2, #3
    5b88:	8b020060 	add	x0, x3, x2
    5b8c:	f9401014 	ldr	x20, [x0, #32]
    5b90:	b4000254 	cbz	x20, 5bd8 <fwp_owned_entry173+0xc4>
    5b94:	38626862 	ldrb	w2, [x3, x2]
    5b98:	7100085f 	cmp	w2, #0x2
    5b9c:	54000360 	b.eq	5c08 <fwp_owned_entry173+0xf4>  // b.none
    5ba0:	7100045f 	cmp	w2, #0x1
    5ba4:	540001a1 	b.ne	5bd8 <fwp_owned_entry173+0xc4>  // b.any
    5ba8:	29430002 	ldp	w2, w0, [x0, #24]
    5bac:	92403c21 	and	x1, x1, #0xffff
    5bb0:	9b027c21 	mul	x1, x1, x2
    5bb4:	d360fc21 	lsr	x1, x1, #32
    5bb8:	eb00003f 	cmp	x1, x0
    5bbc:	540000e2 	b.cs	5bd8 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5bc0:	8b010294 	add	x20, x20, x1
    5bc4:	39400280 	ldrb	w0, [x20]
    5bc8:	7103fc1f 	cmp	w0, #0xff
    5bcc:	54000240 	b.eq	5c14 <fwp_owned_entry173+0x100>  // b.none
    5bd0:	52800020 	mov	w0, #0x1                   	// #1
    5bd4:	39000280 	strb	w0, [x20]
    5bd8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5bdc:	f947f400 	ldr	x0, [x0, #4072]
    5be0:	f9400fe2 	ldr	x2, [sp, #24]
    5be4:	f9400001 	ldr	x1, [x0]
    5be8:	eb010042 	subs	x2, x2, x1
    5bec:	d2800001 	mov	x1, #0x0                   	// #0
    5bf0:	540001a1 	b.ne	5c24 <fwp_owned_entry173+0x110>  // b.any
    5bf4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5bf8:	aa1303e0 	mov	x0, x19
    5bfc:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c00:	910103ff 	add	sp, sp, #0x40
    5c04:	d65f03c0 	ret
    5c08:	72003c3f 	tst	w1, #0xffff
    5c0c:	54fffe61 	b.ne	5bd8 <fwp_owned_entry173+0xc4>  // b.any
    5c10:	17ffffed 	b	5bc4 <fwp_owned_entry173+0xb0>
    5c14:	aa1403e0 	mov	x0, x20
    5c18:	97fffb7e 	bl	4a10 <fwp_rc_forget_slot>
    5c1c:	17ffffed 	b	5bd0 <fwp_owned_entry173+0xbc>
    5c20:	97fff398 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5c24:	97fff31f 	bl	28a0 <__stack_chk_fail@plt>
    5c28:	d503201f 	nop
    5c2c:	d503201f 	nop

0000000000005c30 <e173>:
    5c30:	d10103ff 	sub	sp, sp, #0x40
    5c34:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5c38:	f947f442 	ldr	x2, [x2, #4072]
    5c3c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c40:	910083fd 	add	x29, sp, #0x20
    5c44:	a90353f3 	stp	x19, x20, [sp, #48]
    5c48:	f9400043 	ldr	x3, [x2]
    5c4c:	f9000fe3 	str	x3, [sp, #24]
    5c50:	d2800003 	mov	x3, #0x0                   	// #0
    5c54:	a9400c01 	ldp	x1, x3, [x0]
    5c58:	f9400802 	ldr	x2, [x0, #16]
    5c5c:	ab020022 	adds	x2, x1, x2
    5c60:	54000726 	b.vs	5d44 <e173+0x114>
    5c64:	910023e1 	add	x1, sp, #0x8
    5c68:	52800000 	mov	w0, #0x0                   	// #0
    5c6c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c70:	97fffd89 	bl	5294 <fwp_data.part.0.constprop.0>
    5c74:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5c78:	9118c063 	add	x3, x3, #0x630
    5c7c:	aa0003f3 	mov	x19, x0
    5c80:	f949d861 	ldr	x1, [x3, #5040]
    5c84:	f949ec60 	ldr	x0, [x3, #5080]
    5c88:	cb010261 	sub	x1, x19, x1
    5c8c:	eb00403f 	cmp	x1, x0, lsl #16
    5c90:	54000322 	b.cs	5cf4 <e173+0xc4>  // b.hs, b.nlast
    5c94:	d350fc22 	lsr	x2, x1, #16
    5c98:	f949fc63 	ldr	x3, [x3, #5112]
    5c9c:	8b020842 	add	x2, x2, x2, lsl #2
    5ca0:	d37df042 	lsl	x2, x2, #3
    5ca4:	8b020060 	add	x0, x3, x2
    5ca8:	f9401014 	ldr	x20, [x0, #32]
    5cac:	b4000254 	cbz	x20, 5cf4 <e173+0xc4>
    5cb0:	38626862 	ldrb	w2, [x3, x2]
    5cb4:	7100085f 	cmp	w2, #0x2
    5cb8:	540003a0 	b.eq	5d2c <e173+0xfc>  // b.none
    5cbc:	7100045f 	cmp	w2, #0x1
    5cc0:	540001a1 	b.ne	5cf4 <e173+0xc4>  // b.any
    5cc4:	29430002 	ldp	w2, w0, [x0, #24]
    5cc8:	92403c21 	and	x1, x1, #0xffff
    5ccc:	9b027c21 	mul	x1, x1, x2
    5cd0:	d360fc21 	lsr	x1, x1, #32
    5cd4:	eb00003f 	cmp	x1, x0
    5cd8:	540000e2 	b.cs	5cf4 <e173+0xc4>  // b.hs, b.nlast
    5cdc:	8b010294 	add	x20, x20, x1
    5ce0:	39400280 	ldrb	w0, [x20]
    5ce4:	7103fc1f 	cmp	w0, #0xff
    5ce8:	54000280 	b.eq	5d38 <e173+0x108>  // b.none
    5cec:	52800020 	mov	w0, #0x1                   	// #1
    5cf0:	39000280 	strb	w0, [x20]
    5cf4:	aa1303e0 	mov	x0, x19
    5cf8:	97fffee2 	bl	5880 <fwp_rc_share>
    5cfc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5d00:	f947f400 	ldr	x0, [x0, #4072]
    5d04:	f9400fe2 	ldr	x2, [sp, #24]
    5d08:	f9400001 	ldr	x1, [x0]
    5d0c:	eb010042 	subs	x2, x2, x1
    5d10:	d2800001 	mov	x1, #0x0                   	// #0
    5d14:	540001a1 	b.ne	5d48 <e173+0x118>  // b.any
    5d18:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d1c:	aa1303e0 	mov	x0, x19
    5d20:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d24:	910103ff 	add	sp, sp, #0x40
    5d28:	d65f03c0 	ret
    5d2c:	72003c3f 	tst	w1, #0xffff
    5d30:	54fffe21 	b.ne	5cf4 <e173+0xc4>  // b.any
    5d34:	17ffffeb 	b	5ce0 <e173+0xb0>
    5d38:	aa1403e0 	mov	x0, x20
    5d3c:	97fffb35 	bl	4a10 <fwp_rc_forget_slot>
    5d40:	17ffffeb 	b	5cec <e173+0xbc>
    5d44:	97fff34f 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5d48:	97fff2d6 	bl	28a0 <__stack_chk_fail@plt>
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_drop1>:
    5d50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d54:	910003fd 	mov	x29, sp
    5d58:	a90153f3 	stp	x19, x20, [sp, #16]
    5d5c:	f90013f5 	str	x21, [sp, #32]
    5d60:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5d64:	9118c2b4 	add	x20, x21, #0x630
    5d68:	f949da81 	ldr	x1, [x20, #5040]
    5d6c:	f949ee82 	ldr	x2, [x20, #5080]
    5d70:	cb010001 	sub	x1, x0, x1
    5d74:	eb02403f 	cmp	x1, x2, lsl #16
    5d78:	54000382 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d7c:	d350fc22 	lsr	x2, x1, #16
    5d80:	f949fe84 	ldr	x4, [x20, #5112]
    5d84:	8b020842 	add	x2, x2, x2, lsl #2
    5d88:	d37df042 	lsl	x2, x2, #3
    5d8c:	8b020083 	add	x3, x4, x2
    5d90:	f9401073 	ldr	x19, [x3, #32]
    5d94:	b40002b3 	cbz	x19, 5de8 <fwp_drop1+0x98>
    5d98:	38626882 	ldrb	w2, [x4, x2]
    5d9c:	7100085f 	cmp	w2, #0x2
    5da0:	540002c0 	b.eq	5df8 <fwp_drop1+0xa8>  // b.none
    5da4:	7100045f 	cmp	w2, #0x1
    5da8:	54000201 	b.ne	5de8 <fwp_drop1+0x98>  // b.any
    5dac:	29430864 	ldp	w4, w2, [x3, #24]
    5db0:	92403c21 	and	x1, x1, #0xffff
    5db4:	9b047c21 	mul	x1, x1, x4
    5db8:	d360fc21 	lsr	x1, x1, #32
    5dbc:	eb02003f 	cmp	x1, x2
    5dc0:	54000142 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5dc4:	8b010273 	add	x19, x19, x1
    5dc8:	39400261 	ldrb	w1, [x19]
    5dcc:	340000e1 	cbz	w1, 5de8 <fwp_drop1+0x98>
    5dd0:	7100043f 	cmp	w1, #0x1
    5dd4:	540001e0 	b.eq	5e10 <fwp_drop1+0xc0>  // b.none
    5dd8:	7103fc3f 	cmp	w1, #0xff
    5ddc:	540002e0 	b.eq	5e38 <fwp_drop1+0xe8>  // b.none
    5de0:	51000421 	sub	w1, w1, #0x1
    5de4:	39000261 	strb	w1, [x19]
    5de8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dec:	f94013f5 	ldr	x21, [sp, #32]
    5df0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5df4:	d65f03c0 	ret
    5df8:	72003c3f 	tst	w1, #0xffff
    5dfc:	54fffe60 	b.eq	5dc8 <fwp_drop1+0x78>  // b.none
    5e00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e04:	f94013f5 	ldr	x21, [sp, #32]
    5e08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e0c:	d65f03c0 	ret
    5e10:	f9400813 	ldr	x19, [x0, #16]
    5e14:	97fffef0 	bl	59d4 <fwp_rc_free_arr>
    5e18:	9118c2a0 	add	x0, x21, #0x630
    5e1c:	f949d801 	ldr	x1, [x0, #5040]
    5e20:	f949ec00 	ldr	x0, [x0, #5080]
    5e24:	cb010261 	sub	x1, x19, x1
    5e28:	eb00403f 	cmp	x1, x0, lsl #16
    5e2c:	54fffde2 	b.cs	5de8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e30:	aa1303e0 	mov	x0, x19
    5e34:	17ffffd2 	b	5d7c <fwp_drop1+0x2c>
    5e38:	ca534660 	eor	x0, x19, x19, lsr #17
    5e3c:	9118c2b5 	add	x21, x21, #0x630
    5e40:	ca402400 	eor	x0, x0, x0, lsr #9
    5e44:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e48:	f94a2400 	ldr	x0, [x0, #5192]
    5e4c:	b5000080 	cbnz	x0, 5e5c <fwp_drop1+0x10c>
    5e50:	14000010 	b	5e90 <fwp_drop1+0x140>
    5e54:	f9400800 	ldr	x0, [x0, #16]
    5e58:	b40001c0 	cbz	x0, 5e90 <fwp_drop1+0x140>
    5e5c:	f9400001 	ldr	x1, [x0]
    5e60:	eb13003f 	cmp	x1, x19
    5e64:	54ffff81 	b.ne	5e54 <fwp_drop1+0x104>  // b.any
    5e68:	f9400401 	ldr	x1, [x0, #8]
    5e6c:	d1000421 	sub	x1, x1, #0x1
    5e70:	f9000401 	str	x1, [x0, #8]
    5e74:	f103f83f 	cmp	x1, #0xfe
    5e78:	54fffb81 	b.ne	5de8 <fwp_drop1+0x98>  // b.any
    5e7c:	aa1303e0 	mov	x0, x19
    5e80:	97fffae4 	bl	4a10 <fwp_rc_forget_slot>
    5e84:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e88:	39000260 	strb	w0, [x19]
    5e8c:	17ffffd7 	b	5de8 <fwp_drop1+0x98>
    5e90:	90000040 	adrp	x0, d000 <__modti3+0x60>
    5e94:	91200000 	add	x0, x0, #0x800
    5e98:	97fff65a 	bl	3800 <fwp_trap>
    5e9c:	d503201f 	nop

0000000000005ea0 <fwp_drop0>:
    5ea0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ea4:	910003fd 	mov	x29, sp
    5ea8:	a90153f3 	stp	x19, x20, [sp, #16]
    5eac:	f90013f5 	str	x21, [sp, #32]
    5eb0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5eb4:	9118c2b4 	add	x20, x21, #0x630
    5eb8:	f949da81 	ldr	x1, [x20, #5040]
    5ebc:	f949ee82 	ldr	x2, [x20, #5080]
    5ec0:	cb010001 	sub	x1, x0, x1
    5ec4:	eb02403f 	cmp	x1, x2, lsl #16
    5ec8:	54000382 	b.cs	5f38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ecc:	d350fc22 	lsr	x2, x1, #16
    5ed0:	f949fe84 	ldr	x4, [x20, #5112]
    5ed4:	8b020842 	add	x2, x2, x2, lsl #2
    5ed8:	d37df042 	lsl	x2, x2, #3
    5edc:	8b020083 	add	x3, x4, x2
    5ee0:	f9401073 	ldr	x19, [x3, #32]
    5ee4:	b40002b3 	cbz	x19, 5f38 <fwp_drop0+0x98>
    5ee8:	38626882 	ldrb	w2, [x4, x2]
    5eec:	7100085f 	cmp	w2, #0x2
    5ef0:	540002c0 	b.eq	5f48 <fwp_drop0+0xa8>  // b.none
    5ef4:	7100045f 	cmp	w2, #0x1
    5ef8:	54000201 	b.ne	5f38 <fwp_drop0+0x98>  // b.any
    5efc:	29430864 	ldp	w4, w2, [x3, #24]
    5f00:	92403c21 	and	x1, x1, #0xffff
    5f04:	9b047c21 	mul	x1, x1, x4
    5f08:	d360fc21 	lsr	x1, x1, #32
    5f0c:	eb02003f 	cmp	x1, x2
    5f10:	54000142 	b.cs	5f38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f14:	8b010273 	add	x19, x19, x1
    5f18:	39400261 	ldrb	w1, [x19]
    5f1c:	340000e1 	cbz	w1, 5f38 <fwp_drop0+0x98>
    5f20:	7100043f 	cmp	w1, #0x1
    5f24:	540001e0 	b.eq	5f60 <fwp_drop0+0xc0>  // b.none
    5f28:	7103fc3f 	cmp	w1, #0xff
    5f2c:	540002e0 	b.eq	5f88 <fwp_drop0+0xe8>  // b.none
    5f30:	51000421 	sub	w1, w1, #0x1
    5f34:	39000261 	strb	w1, [x19]
    5f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f3c:	f94013f5 	ldr	x21, [sp, #32]
    5f40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f44:	d65f03c0 	ret
    5f48:	72003c3f 	tst	w1, #0xffff
    5f4c:	54fffe60 	b.eq	5f18 <fwp_drop0+0x78>  // b.none
    5f50:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f54:	f94013f5 	ldr	x21, [sp, #32]
    5f58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f5c:	d65f03c0 	ret
    5f60:	f9400813 	ldr	x19, [x0, #16]
    5f64:	97fffe9c 	bl	59d4 <fwp_rc_free_arr>
    5f68:	9118c2a0 	add	x0, x21, #0x630
    5f6c:	f949d801 	ldr	x1, [x0, #5040]
    5f70:	f949ec00 	ldr	x0, [x0, #5080]
    5f74:	cb010261 	sub	x1, x19, x1
    5f78:	eb00403f 	cmp	x1, x0, lsl #16
    5f7c:	54fffde2 	b.cs	5f38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f80:	aa1303e0 	mov	x0, x19
    5f84:	17ffffd2 	b	5ecc <fwp_drop0+0x2c>
    5f88:	ca534660 	eor	x0, x19, x19, lsr #17
    5f8c:	9118c2b5 	add	x21, x21, #0x630
    5f90:	ca402400 	eor	x0, x0, x0, lsr #9
    5f94:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5f98:	f94a2400 	ldr	x0, [x0, #5192]
    5f9c:	b5000080 	cbnz	x0, 5fac <fwp_drop0+0x10c>
    5fa0:	14000010 	b	5fe0 <fwp_drop0+0x140>
    5fa4:	f9400800 	ldr	x0, [x0, #16]
    5fa8:	b40001c0 	cbz	x0, 5fe0 <fwp_drop0+0x140>
    5fac:	f9400001 	ldr	x1, [x0]
    5fb0:	eb13003f 	cmp	x1, x19
    5fb4:	54ffff81 	b.ne	5fa4 <fwp_drop0+0x104>  // b.any
    5fb8:	f9400401 	ldr	x1, [x0, #8]
    5fbc:	d1000421 	sub	x1, x1, #0x1
    5fc0:	f9000401 	str	x1, [x0, #8]
    5fc4:	f103f83f 	cmp	x1, #0xfe
    5fc8:	54fffb81 	b.ne	5f38 <fwp_drop0+0x98>  // b.any
    5fcc:	aa1303e0 	mov	x0, x19
    5fd0:	97fffa90 	bl	4a10 <fwp_rc_forget_slot>
    5fd4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fd8:	39000260 	strb	w0, [x19]
    5fdc:	17ffffd7 	b	5f38 <fwp_drop0+0x98>
    5fe0:	90000040 	adrp	x0, d000 <__modti3+0x60>
    5fe4:	91200000 	add	x0, x0, #0x800
    5fe8:	97fff606 	bl	3800 <fwp_trap>
    5fec:	d503201f 	nop

0000000000005ff0 <fwp_closure_drop>:
    5ff0:	900003a5 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    5ff4:	9118c0a4 	add	x4, x5, #0x630
    5ff8:	aa0003e1 	mov	x1, x0
    5ffc:	f949d882 	ldr	x2, [x4, #5040]
    6000:	f949ec80 	ldr	x0, [x4, #5080]
    6004:	cb020022 	sub	x2, x1, x2
    6008:	eb00405f 	cmp	x2, x0, lsl #16
    600c:	54000662 	b.cs	60d8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6010:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6014:	d350fc43 	lsr	x3, x2, #16
    6018:	910003fd 	mov	x29, sp
    601c:	8b030863 	add	x3, x3, x3, lsl #2
    6020:	f949fc84 	ldr	x4, [x4, #5112]
    6024:	d37df063 	lsl	x3, x3, #3
    6028:	f9000bf3 	str	x19, [sp, #16]
    602c:	8b030080 	add	x0, x4, x3
    6030:	f9401013 	ldr	x19, [x0, #32]
    6034:	b40002b3 	cbz	x19, 6088 <fwp_closure_drop+0x98>
    6038:	38636883 	ldrb	w3, [x4, x3]
    603c:	7100087f 	cmp	w3, #0x2
    6040:	54000420 	b.eq	60c4 <fwp_closure_drop+0xd4>  // b.none
    6044:	7100047f 	cmp	w3, #0x1
    6048:	54000201 	b.ne	6088 <fwp_closure_drop+0x98>  // b.any
    604c:	29430003 	ldp	w3, w0, [x0, #24]
    6050:	92403c42 	and	x2, x2, #0xffff
    6054:	9b037c42 	mul	x2, x2, x3
    6058:	d360fc42 	lsr	x2, x2, #32
    605c:	eb00005f 	cmp	x2, x0
    6060:	54000142 	b.cs	6088 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6064:	8b020273 	add	x19, x19, x2
    6068:	39400260 	ldrb	w0, [x19]
    606c:	340000e0 	cbz	w0, 6088 <fwp_closure_drop+0x98>
    6070:	7100041f 	cmp	w0, #0x1
    6074:	54000100 	b.eq	6094 <fwp_closure_drop+0xa4>  // b.none
    6078:	7103fc1f 	cmp	w0, #0xff
    607c:	54000300 	b.eq	60dc <fwp_closure_drop+0xec>  // b.none
    6080:	51000400 	sub	w0, w0, #0x1
    6084:	39000260 	strb	w0, [x19]
    6088:	f9400bf3 	ldr	x19, [sp, #16]
    608c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6090:	d65f03c0 	ret
    6094:	d53bd040 	mrs	x0, tpidr_el0
    6098:	91400000 	add	x0, x0, #0x0, lsl #12
    609c:	91004000 	add	x0, x0, #0x10
    60a0:	f9400000 	ldr	x0, [x0]
    60a4:	b4000080 	cbz	x0, 60b4 <fwp_closure_drop+0xc4>
    60a8:	f9400bf3 	ldr	x19, [sp, #16]
    60ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60b0:	17fff5ed 	b	3864 <fwp_closure_drop_push>
    60b4:	f9400bf3 	ldr	x19, [sp, #16]
    60b8:	aa0103e0 	mov	x0, x1
    60bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60c0:	17fff658 	b	3a20 <fwp_closure_drop.part.0>
    60c4:	72003c5f 	tst	w2, #0xffff
    60c8:	54fffd00 	b.eq	6068 <fwp_closure_drop+0x78>  // b.none
    60cc:	f9400bf3 	ldr	x19, [sp, #16]
    60d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60d4:	d65f03c0 	ret
    60d8:	d65f03c0 	ret
    60dc:	ca534660 	eor	x0, x19, x19, lsr #17
    60e0:	9118c0a5 	add	x5, x5, #0x630
    60e4:	ca402400 	eor	x0, x0, x0, lsr #9
    60e8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    60ec:	f94a2400 	ldr	x0, [x0, #5192]
    60f0:	b5000080 	cbnz	x0, 6100 <fwp_closure_drop+0x110>
    60f4:	14000010 	b	6134 <fwp_closure_drop+0x144>
    60f8:	f9400800 	ldr	x0, [x0, #16]
    60fc:	b40001c0 	cbz	x0, 6134 <fwp_closure_drop+0x144>
    6100:	f9400001 	ldr	x1, [x0]
    6104:	eb13003f 	cmp	x1, x19
    6108:	54ffff81 	b.ne	60f8 <fwp_closure_drop+0x108>  // b.any
    610c:	f9400401 	ldr	x1, [x0, #8]
    6110:	d1000421 	sub	x1, x1, #0x1
    6114:	f9000401 	str	x1, [x0, #8]
    6118:	f103f83f 	cmp	x1, #0xfe
    611c:	54fffb61 	b.ne	6088 <fwp_closure_drop+0x98>  // b.any
    6120:	aa1303e0 	mov	x0, x19
    6124:	97fffa3b 	bl	4a10 <fwp_rc_forget_slot>
    6128:	12800020 	mov	w0, #0xfffffffe            	// #-2
    612c:	39000260 	strb	w0, [x19]
    6130:	17ffffd6 	b	6088 <fwp_closure_drop+0x98>
    6134:	f0000020 	adrp	x0, d000 <__modti3+0x60>
    6138:	91200000 	add	x0, x0, #0x800
    613c:	97fff5b1 	bl	3800 <fwp_trap>

0000000000006140 <fwp_owned_tape_release>:
    6140:	b4000940 	cbz	x0, 6268 <fwp_owned_tape_release+0x128>
    6144:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6148:	910003fd 	mov	x29, sp
    614c:	a90153f3 	stp	x19, x20, [sp, #16]
    6150:	aa0003f3 	mov	x19, x0
    6154:	f9400000 	ldr	x0, [x0]
    6158:	b4000060 	cbz	x0, 6164 <fwp_owned_tape_release+0x24>
    615c:	f9400661 	ldr	x1, [x19, #8]
    6160:	f9000401 	str	x1, [x0, #8]
    6164:	f9400661 	ldr	x1, [x19, #8]
    6168:	b4000041 	cbz	x1, 6170 <fwp_owned_tape_release+0x30>
    616c:	f9000020 	str	x0, [x1]
    6170:	f9400a60 	ldr	x0, [x19, #16]
    6174:	f9403401 	ldr	x1, [x0, #104]
    6178:	b40005c1 	cbz	x1, 6230 <fwp_owned_tape_release+0xf0>
    617c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6180:	eb00005f 	cmp	x2, x0
    6184:	540002ed 	b.le	61e0 <fwp_owned_tape_release+0xa0>
    6188:	d2800014 	mov	x20, #0x0                   	// #0
    618c:	f90013f5 	str	x21, [sp, #32]
    6190:	d2800015 	mov	x21, #0x0                   	// #0
    6194:	d503201f 	nop
    6198:	f9402260 	ldr	x0, [x19, #64]
    619c:	910006b5 	add	x21, x21, #0x1
    61a0:	f8746800 	ldr	x0, [x0, x20]
    61a4:	d63f0020 	blr	x1
    61a8:	f9402260 	ldr	x0, [x19, #64]
    61ac:	f9400a61 	ldr	x1, [x19, #16]
    61b0:	8b140000 	add	x0, x0, x20
    61b4:	91004294 	add	x20, x20, #0x10
    61b8:	f9400400 	ldr	x0, [x0, #8]
    61bc:	f9403421 	ldr	x1, [x1, #104]
    61c0:	d63f0020 	blr	x1
    61c4:	a9450261 	ldp	x1, x0, [x19, #80]
    61c8:	cb010000 	sub	x0, x0, x1
    61cc:	eb15001f 	cmp	x0, x21
    61d0:	f9400a60 	ldr	x0, [x19, #16]
    61d4:	f9403401 	ldr	x1, [x0, #104]
    61d8:	54fffe0c 	b.gt	6198 <fwp_owned_tape_release+0x58>
    61dc:	f94013f5 	ldr	x21, [sp, #32]
    61e0:	f9403663 	ldr	x3, [x19, #104]
    61e4:	f9401262 	ldr	x2, [x19, #32]
    61e8:	f100007f 	cmp	x3, #0x0
    61ec:	540001ed 	b.le	6228 <fwp_owned_tape_release+0xe8>
    61f0:	d2800014 	mov	x20, #0x0                   	// #0
    61f4:	d503201f 	nop
    61f8:	f9402660 	ldr	x0, [x19, #72]
    61fc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6200:	eb02001f 	cmp	x0, x2
    6204:	540000c0 	b.eq	621c <fwp_owned_tape_release+0xdc>  // b.none
    6208:	d63f0020 	blr	x1
    620c:	f9400a60 	ldr	x0, [x19, #16]
    6210:	f9401262 	ldr	x2, [x19, #32]
    6214:	f9403663 	ldr	x3, [x19, #104]
    6218:	f9403401 	ldr	x1, [x0, #104]
    621c:	91000694 	add	x20, x20, #0x1
    6220:	eb14007f 	cmp	x3, x20
    6224:	54fffeac 	b.gt	61f8 <fwp_owned_tape_release+0xb8>
    6228:	aa0203e0 	mov	x0, x2
    622c:	d63f0020 	blr	x1
    6230:	f9401660 	ldr	x0, [x19, #40]
    6234:	97ffff6f 	bl	5ff0 <fwp_closure_drop>
    6238:	f9401a60 	ldr	x0, [x19, #48]
    623c:	97ffff6d 	bl	5ff0 <fwp_closure_drop>
    6240:	f9401e60 	ldr	x0, [x19, #56]
    6244:	97ffff6b 	bl	5ff0 <fwp_closure_drop>
    6248:	f9402260 	ldr	x0, [x19, #64]
    624c:	97fffa91 	bl	4c90 <fwp_mem_free>
    6250:	f9402660 	ldr	x0, [x19, #72]
    6254:	97fffa8f 	bl	4c90 <fwp_mem_free>
    6258:	aa1303e0 	mov	x0, x19
    625c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6260:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6264:	17fffa8b 	b	4c90 <fwp_mem_free>
    6268:	d65f03c0 	ret
    626c:	d503201f 	nop

0000000000006270 <fwp_tape_finish>:
    6270:	d10203ff 	sub	sp, sp, #0x80
    6274:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6278:	f947f421 	ldr	x1, [x1, #4072]
    627c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6280:	910103fd 	add	x29, sp, #0x40
    6284:	a9065bf5 	stp	x21, x22, [sp, #96]
    6288:	a90763f7 	stp	x23, x24, [sp, #112]
    628c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6290:	910142f6 	add	x22, x23, #0x50
    6294:	f9400022 	ldr	x2, [x1]
    6298:	f9001fe2 	str	x2, [sp, #56]
    629c:	d2800002 	mov	x2, #0x0                   	// #0
    62a0:	910382c0 	add	x0, x22, #0xe0
    62a4:	97fff858 	bl	4404 <fwp_tape_buffers_dispose>
    62a8:	f9008edf 	str	xzr, [x22, #280]
    62ac:	f9406ec0 	ldr	x0, [x22, #216]
    62b0:	f100001f 	cmp	x0, #0x0
    62b4:	5400034d 	b.le	631c <fwp_tape_finish+0xac>
    62b8:	910003f8 	mov	x24, sp
    62bc:	d2800015 	mov	x21, #0x0                   	// #0
    62c0:	a90553f3 	stp	x19, x20, [sp, #80]
    62c4:	d2800014 	mov	x20, #0x0                   	// #0
    62c8:	91000694 	add	x20, x20, #0x1
    62cc:	f94046d3 	ldr	x19, [x22, #136]
    62d0:	8b150273 	add	x19, x19, x21
    62d4:	9101a2b5 	add	x21, x21, #0x68
    62d8:	aa1303e0 	mov	x0, x19
    62dc:	97fff34e 	bl	3014 <fwp_tape_unlink_scope>
    62e0:	aa1803e0 	mov	x0, x24
    62e4:	a9440663 	ldp	x3, x1, [x19, #64]
    62e8:	f9001be1 	str	x1, [sp, #48]
    62ec:	f9400e62 	ldr	x2, [x19, #24]
    62f0:	a9020be3 	stp	x3, x2, [sp, #32]
    62f4:	ad410261 	ldp	q1, q0, [x19, #32]
    62f8:	ad0003e1 	stp	q1, q0, [sp]
    62fc:	97fff842 	bl	4404 <fwp_tape_buffers_dispose>
    6300:	f9403260 	ldr	x0, [x19, #96]
    6304:	97ffff8f 	bl	6140 <fwp_owned_tape_release>
    6308:	f900327f 	str	xzr, [x19, #96]
    630c:	f9406ec0 	ldr	x0, [x22, #216]
    6310:	eb14001f 	cmp	x0, x20
    6314:	54fffdac 	b.gt	62c8 <fwp_tape_finish+0x58>
    6318:	a94553f3 	ldp	x19, x20, [sp, #80]
    631c:	910142e0 	add	x0, x23, #0x50
    6320:	f9404400 	ldr	x0, [x0, #136]
    6324:	b4000040 	cbz	x0, 632c <fwp_tape_finish+0xbc>
    6328:	97fff816 	bl	4380 <ad_raw_free.part.0>
    632c:	910142f7 	add	x23, x23, #0x50
    6330:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6334:	f947f400 	ldr	x0, [x0, #4072]
    6338:	f90046ff 	str	xzr, [x23, #136]
    633c:	f9006eff 	str	xzr, [x23, #216]
    6340:	f90092ff 	str	xzr, [x23, #288]
    6344:	f900b2ff 	str	xzr, [x23, #352]
    6348:	f9401fe2 	ldr	x2, [sp, #56]
    634c:	f9400001 	ldr	x1, [x0]
    6350:	eb010042 	subs	x2, x2, x1
    6354:	d2800001 	mov	x1, #0x0                   	// #0
    6358:	540000c1 	b.ne	6370 <fwp_tape_finish+0x100>  // b.any
    635c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6360:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6364:	a94763f7 	ldp	x23, x24, [sp, #112]
    6368:	910203ff 	add	sp, sp, #0x80
    636c:	d65f03c0 	ret
    6370:	a90553f3 	stp	x19, x20, [sp, #80]
    6374:	97fff14b 	bl	28a0 <__stack_chk_fail@plt>
    6378:	d503201f 	nop
    637c:	d503201f 	nop

0000000000006380 <fwp_tape_scope_release>:
    6380:	d10243ff 	sub	sp, sp, #0x90
    6384:	a9047bfd 	stp	x29, x30, [sp, #64]
    6388:	910103fd 	add	x29, sp, #0x40
    638c:	a90553f3 	stp	x19, x20, [sp, #80]
    6390:	aa0003f4 	mov	x20, x0
    6394:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6398:	f947f400 	ldr	x0, [x0, #4072]
    639c:	b9400285 	ldr	w5, [x20]
    63a0:	f9400001 	ldr	x1, [x0]
    63a4:	f9001fe1 	str	x1, [sp, #56]
    63a8:	d2800001 	mov	x1, #0x0                   	// #0
    63ac:	37f806c5 	tbnz	w5, #31, 6484 <fwp_tape_scope_release+0x104>
    63b0:	a90763f7 	stp	x23, x24, [sp, #112]
    63b4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    63b8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    63bc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    63c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    63c4:	910003f7 	mov	x23, sp
    63c8:	91014273 	add	x19, x19, #0x50
    63cc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    63d0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63d4:	52800d16 	mov	w22, #0x68                  	// #104
    63d8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    63dc:	f90043f9 	str	x25, [sp, #128]
    63e0:	14000006 	b	63f8 <fwp_tape_scope_release+0x78>
    63e4:	97fff808 	bl	4404 <fwp_tape_buffers_dispose>
    63e8:	aa1903e0 	mov	x0, x25
    63ec:	97ffff55 	bl	6140 <fwp_owned_tape_release>
    63f0:	b9400285 	ldr	w5, [x20]
    63f4:	37f80425 	tbnz	w5, #31, 6478 <fwp_tape_scope_release+0xf8>
    63f8:	f9404666 	ldr	x6, [x19, #136]
    63fc:	9b367ca5 	smull	x5, w5, w22
    6400:	8b0500c0 	add	x0, x6, x5
    6404:	97fff304 	bl	3014 <fwp_tape_unlink_scope>
    6408:	ad410001 	ldp	q1, q0, [x0, #32]
    640c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6410:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6414:	f9400c03 	ldr	x3, [x0, #24]
    6418:	ad0003e1 	stp	q1, q0, [sp]
    641c:	b86568c1 	ldr	w1, [x6, x5]
    6420:	a9440804 	ldp	x4, x2, [x0, #64]
    6424:	b900041f 	str	wzr, [x0, #4]
    6428:	f9403019 	ldr	x25, [x0, #96]
    642c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6430:	f9000c1f 	str	xzr, [x0, #24]
    6434:	a9020fe4 	stp	x4, x3, [sp, #32]
    6438:	f9001be2 	str	x2, [sp, #48]
    643c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6440:	f900301f 	str	xzr, [x0, #96]
    6444:	6b15003f 	cmp	w1, w21
    6448:	540000e8 	b.hi	6464 <fwp_tape_scope_release+0xe4>  // b.pmore
    644c:	9343fca5 	asr	x5, x5, #3
    6450:	f940b260 	ldr	x0, [x19, #352]
    6454:	9b187ca5 	mul	x5, x5, x24
    6458:	eb0000bf 	cmp	x5, x0
    645c:	5400004a 	b.ge	6464 <fwp_tape_scope_release+0xe4>  // b.tcont
    6460:	f900b265 	str	x5, [x19, #352]
    6464:	aa1703e0 	mov	x0, x23
    6468:	b5fffbf9 	cbnz	x25, 63e4 <fwp_tape_scope_release+0x64>
    646c:	97fff82e 	bl	4524 <fwp_tape_buffers_release>
    6470:	b9400285 	ldr	w5, [x20]
    6474:	36fffc25 	tbz	w5, #31, 63f8 <fwp_tape_scope_release+0x78>
    6478:	a9465bf5 	ldp	x21, x22, [sp, #96]
    647c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6480:	f94043f9 	ldr	x25, [sp, #128]
    6484:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6488:	f947f400 	ldr	x0, [x0, #4072]
    648c:	f9401fe2 	ldr	x2, [sp, #56]
    6490:	f9400001 	ldr	x1, [x0]
    6494:	eb010042 	subs	x2, x2, x1
    6498:	d2800001 	mov	x1, #0x0                   	// #0
    649c:	540000a1 	b.ne	64b0 <fwp_tape_scope_release+0x130>  // b.any
    64a0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    64a4:	a94553f3 	ldp	x19, x20, [sp, #80]
    64a8:	910243ff 	add	sp, sp, #0x90
    64ac:	d65f03c0 	ret
    64b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    64b4:	a90763f7 	stp	x23, x24, [sp, #112]
    64b8:	f90043f9 	str	x25, [sp, #128]
    64bc:	97fff0f9 	bl	28a0 <__stack_chk_fail@plt>

00000000000064c0 <fwp_drop4>:
    64c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    64c4:	910003fd 	mov	x29, sp
    64c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    64cc:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    64d0:	9118c2d5 	add	x21, x22, #0x630
    64d4:	a90153f3 	stp	x19, x20, [sp, #16]
    64d8:	aa0003f3 	mov	x19, x0
    64dc:	f949daa1 	ldr	x1, [x21, #5040]
    64e0:	f949eea0 	ldr	x0, [x21, #5080]
    64e4:	cb010261 	sub	x1, x19, x1
    64e8:	eb00403f 	cmp	x1, x0, lsl #16
    64ec:	54000382 	b.cs	655c <fwp_drop4+0x9c>  // b.hs, b.nlast
    64f0:	d350fc22 	lsr	x2, x1, #16
    64f4:	f949fea3 	ldr	x3, [x21, #5112]
    64f8:	8b020842 	add	x2, x2, x2, lsl #2
    64fc:	d37df042 	lsl	x2, x2, #3
    6500:	8b020060 	add	x0, x3, x2
    6504:	f9401014 	ldr	x20, [x0, #32]
    6508:	b40002b4 	cbz	x20, 655c <fwp_drop4+0x9c>
    650c:	38626862 	ldrb	w2, [x3, x2]
    6510:	7100085f 	cmp	w2, #0x2
    6514:	540002c0 	b.eq	656c <fwp_drop4+0xac>  // b.none
    6518:	7100045f 	cmp	w2, #0x1
    651c:	54000201 	b.ne	655c <fwp_drop4+0x9c>  // b.any
    6520:	29430002 	ldp	w2, w0, [x0, #24]
    6524:	92403c21 	and	x1, x1, #0xffff
    6528:	9b027c21 	mul	x1, x1, x2
    652c:	d360fc21 	lsr	x1, x1, #32
    6530:	eb00003f 	cmp	x1, x0
    6534:	54000142 	b.cs	655c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6538:	8b010294 	add	x20, x20, x1
    653c:	39400280 	ldrb	w0, [x20]
    6540:	340000e0 	cbz	w0, 655c <fwp_drop4+0x9c>
    6544:	7100041f 	cmp	w0, #0x1
    6548:	540001e0 	b.eq	6584 <fwp_drop4+0xc4>  // b.none
    654c:	7103fc1f 	cmp	w0, #0xff
    6550:	540007c0 	b.eq	6648 <fwp_drop4+0x188>  // b.none
    6554:	51000400 	sub	w0, w0, #0x1
    6558:	39000280 	strb	w0, [x20]
    655c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6560:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6564:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6568:	d65f03c0 	ret
    656c:	72003c3f 	tst	w1, #0xffff
    6570:	54fffe60 	b.eq	653c <fwp_drop4+0x7c>  // b.none
    6574:	a94153f3 	ldp	x19, x20, [sp, #16]
    6578:	a9425bf5 	ldp	x21, x22, [sp, #32]
    657c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6580:	d65f03c0 	ret
    6584:	9118c2c2 	add	x2, x22, #0x630
    6588:	f9400660 	ldr	x0, [x19, #8]
    658c:	f949d841 	ldr	x1, [x2, #5040]
    6590:	f949ec42 	ldr	x2, [x2, #5080]
    6594:	cb010001 	sub	x1, x0, x1
    6598:	eb02403f 	cmp	x1, x2, lsl #16
    659c:	54000362 	b.cs	6608 <fwp_drop4+0x148>  // b.hs, b.nlast
    65a0:	d350fc22 	lsr	x2, x1, #16
    65a4:	8b020842 	add	x2, x2, x2, lsl #2
    65a8:	d37df042 	lsl	x2, x2, #3
    65ac:	8b020064 	add	x4, x3, x2
    65b0:	f9401094 	ldr	x20, [x4, #32]
    65b4:	b40002b4 	cbz	x20, 6608 <fwp_drop4+0x148>
    65b8:	38626862 	ldrb	w2, [x3, x2]
    65bc:	7100085f 	cmp	w2, #0x2
    65c0:	540003e0 	b.eq	663c <fwp_drop4+0x17c>  // b.none
    65c4:	7100045f 	cmp	w2, #0x1
    65c8:	54000201 	b.ne	6608 <fwp_drop4+0x148>  // b.any
    65cc:	29430883 	ldp	w3, w2, [x4, #24]
    65d0:	92403c21 	and	x1, x1, #0xffff
    65d4:	9b037c21 	mul	x1, x1, x3
    65d8:	d360fc21 	lsr	x1, x1, #32
    65dc:	eb02003f 	cmp	x1, x2
    65e0:	54000142 	b.cs	6608 <fwp_drop4+0x148>  // b.hs, b.nlast
    65e4:	8b010294 	add	x20, x20, x1
    65e8:	39400281 	ldrb	w1, [x20]
    65ec:	340000e1 	cbz	w1, 6608 <fwp_drop4+0x148>
    65f0:	7100043f 	cmp	w1, #0x1
    65f4:	54000200 	b.eq	6634 <fwp_drop4+0x174>  // b.none
    65f8:	7103fc3f 	cmp	w1, #0xff
    65fc:	54000580 	b.eq	66ac <fwp_drop4+0x1ec>  // b.none
    6600:	51000421 	sub	w1, w1, #0x1
    6604:	39000281 	strb	w1, [x20]
    6608:	f9400a74 	ldr	x20, [x19, #16]
    660c:	aa1303e0 	mov	x0, x19
    6610:	97fffcf1 	bl	59d4 <fwp_rc_free_arr>
    6614:	9118c2c0 	add	x0, x22, #0x630
    6618:	f949d801 	ldr	x1, [x0, #5040]
    661c:	f949ec00 	ldr	x0, [x0, #5080]
    6620:	cb010281 	sub	x1, x20, x1
    6624:	eb00403f 	cmp	x1, x0, lsl #16
    6628:	54fff9a2 	b.cs	655c <fwp_drop4+0x9c>  // b.hs, b.nlast
    662c:	aa1403f3 	mov	x19, x20
    6630:	17ffffb0 	b	64f0 <fwp_drop4+0x30>
    6634:	97fffce8 	bl	59d4 <fwp_rc_free_arr>
    6638:	17fffff4 	b	6608 <fwp_drop4+0x148>
    663c:	72003c3f 	tst	w1, #0xffff
    6640:	54fffe41 	b.ne	6608 <fwp_drop4+0x148>  // b.any
    6644:	17ffffe9 	b	65e8 <fwp_drop4+0x128>
    6648:	ca544681 	eor	x1, x20, x20, lsr #17
    664c:	9118c2c0 	add	x0, x22, #0x630
    6650:	ca412421 	eor	x1, x1, x1, lsr #9
    6654:	8b210c01 	add	x1, x0, w1, uxtb #3
    6658:	f94a2420 	ldr	x0, [x1, #5192]
    665c:	b5000080 	cbnz	x0, 666c <fwp_drop4+0x1ac>
    6660:	14000010 	b	66a0 <fwp_drop4+0x1e0>
    6664:	f9400800 	ldr	x0, [x0, #16]
    6668:	b40001c0 	cbz	x0, 66a0 <fwp_drop4+0x1e0>
    666c:	f9400001 	ldr	x1, [x0]
    6670:	eb14003f 	cmp	x1, x20
    6674:	54ffff81 	b.ne	6664 <fwp_drop4+0x1a4>  // b.any
    6678:	f9400401 	ldr	x1, [x0, #8]
    667c:	d1000421 	sub	x1, x1, #0x1
    6680:	f9000401 	str	x1, [x0, #8]
    6684:	f103f83f 	cmp	x1, #0xfe
    6688:	54fff6a1 	b.ne	655c <fwp_drop4+0x9c>  // b.any
    668c:	aa1403e0 	mov	x0, x20
    6690:	97fff8e0 	bl	4a10 <fwp_rc_forget_slot>
    6694:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6698:	39000280 	strb	w0, [x20]
    669c:	17ffffb0 	b	655c <fwp_drop4+0x9c>
    66a0:	f0000020 	adrp	x0, d000 <__modti3+0x60>
    66a4:	91200000 	add	x0, x0, #0x800
    66a8:	97fff456 	bl	3800 <fwp_trap>
    66ac:	ca544680 	eor	x0, x20, x20, lsr #17
    66b0:	9118c2c1 	add	x1, x22, #0x630
    66b4:	ca402400 	eor	x0, x0, x0, lsr #9
    66b8:	8b200c20 	add	x0, x1, w0, uxtb #3
    66bc:	f94a2400 	ldr	x0, [x0, #5192]
    66c0:	b5000080 	cbnz	x0, 66d0 <fwp_drop4+0x210>
    66c4:	17fffff7 	b	66a0 <fwp_drop4+0x1e0>
    66c8:	f9400800 	ldr	x0, [x0, #16]
    66cc:	b4fffea0 	cbz	x0, 66a0 <fwp_drop4+0x1e0>
    66d0:	f9400001 	ldr	x1, [x0]
    66d4:	eb14003f 	cmp	x1, x20
    66d8:	54ffff81 	b.ne	66c8 <fwp_drop4+0x208>  // b.any
    66dc:	f9400401 	ldr	x1, [x0, #8]
    66e0:	d1000421 	sub	x1, x1, #0x1
    66e4:	f9000401 	str	x1, [x0, #8]
    66e8:	f103f83f 	cmp	x1, #0xfe
    66ec:	54fff8e1 	b.ne	6608 <fwp_drop4+0x148>  // b.any
    66f0:	aa1403e0 	mov	x0, x20
    66f4:	97fff8c7 	bl	4a10 <fwp_rc_forget_slot>
    66f8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66fc:	39000280 	strb	w0, [x20]
    6700:	17ffffc2 	b	6608 <fwp_drop4+0x148>

0000000000006704 <fwp_arg_drop37>:
    6704:	7100003f 	cmp	w1, #0x0
    6708:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    670c:	54000041 	b.ne	6714 <fwp_arg_drop37+0x10>  // b.any
    6710:	d65f03c0 	ret
    6714:	f9400000 	ldr	x0, [x0]
    6718:	17ffff6a 	b	64c0 <fwp_drop4>
    671c:	d503201f 	nop

0000000000006720 <fwp_task_dispose>:
    6720:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6724:	910003fd 	mov	x29, sp
    6728:	f9000bf3 	str	x19, [sp, #16]
    672c:	aa0003f3 	mov	x19, x0
    6730:	39414000 	ldrb	w0, [x0, #80]
    6734:	36000720 	tbz	w0, #0, 6818 <fwp_task_dispose+0xf8>
    6738:	f9400a60 	ldr	x0, [x19, #16]
    673c:	b50006e0 	cbnz	x0, 6818 <fwp_task_dispose+0xf8>
    6740:	a9478660 	ldp	x0, x1, [x19, #120]
    6744:	39014e7f 	strb	wzr, [x19, #83]
    6748:	f9003e7f 	str	xzr, [x19, #120]
    674c:	f100003f 	cmp	x1, #0x0
    6750:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6754:	54000040 	b.eq	675c <fwp_task_dispose+0x3c>  // b.none
    6758:	d63f0020 	blr	x1
    675c:	f9405660 	ldr	x0, [x19, #168]
    6760:	97fff94c 	bl	4c90 <fwp_mem_free>
    6764:	f900567f 	str	xzr, [x19, #168]
    6768:	b9405e60 	ldr	w0, [x19, #92]
    676c:	7100041f 	cmp	w0, #0x1
    6770:	54000420 	b.eq	67f4 <fwp_task_dispose+0xd4>  // b.none
    6774:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6778:	9118c042 	add	x2, x2, #0x630
    677c:	f949d840 	ldr	x0, [x2, #5040]
    6780:	f949ec41 	ldr	x1, [x2, #5080]
    6784:	cb000260 	sub	x0, x19, x0
    6788:	eb01401f 	cmp	x0, x1, lsl #16
    678c:	540002e2 	b.cs	67e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6790:	d350fc01 	lsr	x1, x0, #16
    6794:	f949fc44 	ldr	x4, [x2, #5112]
    6798:	8b010821 	add	x1, x1, x1, lsl #2
    679c:	d37df021 	lsl	x1, x1, #3
    67a0:	8b010083 	add	x3, x4, x1
    67a4:	f9401062 	ldr	x2, [x3, #32]
    67a8:	b4000202 	cbz	x2, 67e8 <fwp_task_dispose+0xc8>
    67ac:	38616881 	ldrb	w1, [x4, x1]
    67b0:	7100083f 	cmp	w1, #0x2
    67b4:	54000280 	b.eq	6804 <fwp_task_dispose+0xe4>  // b.none
    67b8:	7100043f 	cmp	w1, #0x1
    67bc:	54000161 	b.ne	67e8 <fwp_task_dispose+0xc8>  // b.any
    67c0:	29430464 	ldp	w4, w1, [x3, #24]
    67c4:	92403c00 	and	x0, x0, #0xffff
    67c8:	9b047c00 	mul	x0, x0, x4
    67cc:	d360fc00 	lsr	x0, x0, #32
    67d0:	eb01001f 	cmp	x0, x1
    67d4:	540000a2 	b.cs	67e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    67d8:	8b000042 	add	x2, x2, x0
    67dc:	39400040 	ldrb	w0, [x2]
    67e0:	7100041f 	cmp	w0, #0x1
    67e4:	54000080 	b.eq	67f4 <fwp_task_dispose+0xd4>  // b.none
    67e8:	f9400bf3 	ldr	x19, [sp, #16]
    67ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f0:	d65f03c0 	ret
    67f4:	aa1303e0 	mov	x0, x19
    67f8:	f9400bf3 	ldr	x19, [sp, #16]
    67fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6800:	17fff924 	b	4c90 <fwp_mem_free>
    6804:	72003c1f 	tst	w0, #0xffff
    6808:	54fffea0 	b.eq	67dc <fwp_task_dispose+0xbc>  // b.none
    680c:	f9400bf3 	ldr	x19, [sp, #16]
    6810:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6814:	d65f03c0 	ret
    6818:	97fff036 	bl	28f0 <abort@plt>
    681c:	d503201f 	nop

0000000000006820 <fwp_free_zombie>:
    6820:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6824:	910003fd 	mov	x29, sp
    6828:	a90153f3 	stp	x19, x20, [sp, #16]
    682c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6830:	91014281 	add	x1, x20, #0x50
    6834:	f940b433 	ldr	x19, [x1, #360]
    6838:	b4000333 	cbz	x19, 689c <fwp_free_zombie+0x7c>
    683c:	f9404c20 	ldr	x0, [x1, #152]
    6840:	eb00027f 	cmp	x19, x0
    6844:	540002c0 	b.eq	689c <fwp_free_zombie+0x7c>  // b.none
    6848:	b9417022 	ldr	w2, [x1, #368]
    684c:	f9400a60 	ldr	x0, [x19, #16]
    6850:	7100fc5f 	cmp	w2, #0x3f
    6854:	5400078c 	b.gt	6944 <fwp_free_zombie+0x124>
    6858:	91060023 	add	x3, x1, #0x180
    685c:	11000444 	add	w4, w2, #0x1
    6860:	b9017024 	str	w4, [x1, #368]
    6864:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6868:	f822d860 	str	x0, [x3, w2, sxtw #3]
    686c:	a9530261 	ldp	x1, x0, [x19, #304]
    6870:	b4000741 	cbz	x1, 6958 <fwp_free_zombie+0x138>
    6874:	f9009c20 	str	x0, [x1, #312]
    6878:	b4000040 	cbz	x0, 6880 <fwp_free_zombie+0x60>
    687c:	f9009801 	str	x1, [x0, #304]
    6880:	91014294 	add	x20, x20, #0x50
    6884:	b9405e60 	ldr	w0, [x19, #92]
    6888:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    688c:	f900b69f 	str	xzr, [x20, #360]
    6890:	34000140 	cbz	w0, 68b8 <fwp_free_zombie+0x98>
    6894:	7100041f 	cmp	w0, #0x1
    6898:	54000080 	b.eq	68a8 <fwp_free_zombie+0x88>  // b.none
    689c:	a94153f3 	ldp	x19, x20, [sp, #16]
    68a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a4:	d65f03c0 	ret
    68a8:	aa1303e0 	mov	x0, x19
    68ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    68b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68b4:	17ffff9b 	b	6720 <fwp_task_dispose>
    68b8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    68bc:	9118c082 	add	x2, x4, #0x630
    68c0:	f949d841 	ldr	x1, [x2, #5040]
    68c4:	f949ec40 	ldr	x0, [x2, #5080]
    68c8:	cb010261 	sub	x1, x19, x1
    68cc:	eb00403f 	cmp	x1, x0, lsl #16
    68d0:	54fffe62 	b.cs	689c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    68d4:	d350fc20 	lsr	x0, x1, #16
    68d8:	f949fc43 	ldr	x3, [x2, #5112]
    68dc:	8b000800 	add	x0, x0, x0, lsl #2
    68e0:	d37df000 	lsl	x0, x0, #3
    68e4:	8b000062 	add	x2, x3, x0
    68e8:	f9401054 	ldr	x20, [x2, #32]
    68ec:	b4fffd94 	cbz	x20, 689c <fwp_free_zombie+0x7c>
    68f0:	38606860 	ldrb	w0, [x3, x0]
    68f4:	7100081f 	cmp	w0, #0x2
    68f8:	54000360 	b.eq	6964 <fwp_free_zombie+0x144>  // b.none
    68fc:	7100041f 	cmp	w0, #0x1
    6900:	54fffce1 	b.ne	689c <fwp_free_zombie+0x7c>  // b.any
    6904:	29430043 	ldp	w3, w0, [x2, #24]
    6908:	92403c21 	and	x1, x1, #0xffff
    690c:	9b037c21 	mul	x1, x1, x3
    6910:	d360fc21 	lsr	x1, x1, #32
    6914:	eb00003f 	cmp	x1, x0
    6918:	54fffc22 	b.cs	689c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    691c:	8b010294 	add	x20, x20, x1
    6920:	39400280 	ldrb	w0, [x20]
    6924:	34fffbc0 	cbz	w0, 689c <fwp_free_zombie+0x7c>
    6928:	7100041f 	cmp	w0, #0x1
    692c:	54fffbe0 	b.eq	68a8 <fwp_free_zombie+0x88>  // b.none
    6930:	7103fc1f 	cmp	w0, #0xff
    6934:	540001e0 	b.eq	6970 <fwp_free_zombie+0x150>  // b.none
    6938:	51000400 	sub	w0, w0, #0x1
    693c:	39000280 	strb	w0, [x20]
    6940:	17ffffd7 	b	689c <fwp_free_zombie+0x7c>
    6944:	f9400e61 	ldr	x1, [x19, #24]
    6948:	97fff01e 	bl	29c0 <munmap@plt>
    694c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6950:	a9530261 	ldp	x1, x0, [x19, #304]
    6954:	b5fff901 	cbnz	x1, 6874 <fwp_free_zombie+0x54>
    6958:	91014282 	add	x2, x20, #0x50
    695c:	f901c040 	str	x0, [x2, #896]
    6960:	17ffffc6 	b	6878 <fwp_free_zombie+0x58>
    6964:	72003c3f 	tst	w1, #0xffff
    6968:	54fff9a1 	b.ne	689c <fwp_free_zombie+0x7c>  // b.any
    696c:	17ffffed 	b	6920 <fwp_free_zombie+0x100>
    6970:	ca544680 	eor	x0, x20, x20, lsr #17
    6974:	9118c084 	add	x4, x4, #0x630
    6978:	ca402400 	eor	x0, x0, x0, lsr #9
    697c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6980:	f94a2400 	ldr	x0, [x0, #5192]
    6984:	b5000080 	cbnz	x0, 6994 <fwp_free_zombie+0x174>
    6988:	14000010 	b	69c8 <fwp_free_zombie+0x1a8>
    698c:	f9400800 	ldr	x0, [x0, #16]
    6990:	b40001c0 	cbz	x0, 69c8 <fwp_free_zombie+0x1a8>
    6994:	f9400001 	ldr	x1, [x0]
    6998:	eb14003f 	cmp	x1, x20
    699c:	54ffff81 	b.ne	698c <fwp_free_zombie+0x16c>  // b.any
    69a0:	f9400401 	ldr	x1, [x0, #8]
    69a4:	d1000421 	sub	x1, x1, #0x1
    69a8:	f9000401 	str	x1, [x0, #8]
    69ac:	f103f83f 	cmp	x1, #0xfe
    69b0:	54fff761 	b.ne	689c <fwp_free_zombie+0x7c>  // b.any
    69b4:	aa1403e0 	mov	x0, x20
    69b8:	97fff816 	bl	4a10 <fwp_rc_forget_slot>
    69bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69c0:	39000280 	strb	w0, [x20]
    69c4:	17ffffb6 	b	689c <fwp_free_zombie+0x7c>
    69c8:	f0000020 	adrp	x0, d000 <__modti3+0x60>
    69cc:	91200000 	add	x0, x0, #0x800
    69d0:	97fff38c 	bl	3800 <fwp_trap>

00000000000069d4 <fwp_block>:
    69d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69d8:	910003fd 	mov	x29, sp
    69dc:	a90153f3 	stp	x19, x20, [sp, #16]
    69e0:	d00000d3 	adrp	x19, 20000 <__data_start>
    69e4:	91014274 	add	x20, x19, #0x50
    69e8:	f9406682 	ldr	x2, [x20, #200]
    69ec:	b4000622 	cbz	x2, 6ab0 <fwp_block+0xdc>
    69f0:	91014261 	add	x1, x19, #0x50
    69f4:	f9408040 	ldr	x0, [x2, #256]
    69f8:	f9006420 	str	x0, [x1, #200]
    69fc:	b4000680 	cbz	x0, 6acc <fwp_block+0xf8>
    6a00:	91014263 	add	x3, x19, #0x50
    6a04:	3901505f 	strb	wzr, [x2, #84]
    6a08:	f9404c64 	ldr	x4, [x3, #152]
    6a0c:	eb02009f 	cmp	x4, x2
    6a10:	54000440 	b.eq	6a98 <fwp_block+0xc4>  // b.none
    6a14:	f941c465 	ldr	x5, [x3, #904]
    6a18:	f9004c62 	str	x2, [x3, #152]
    6a1c:	f9400441 	ldr	x1, [x2, #8]
    6a20:	f9004885 	str	x5, [x4, #144]
    6a24:	f941c865 	ldr	x5, [x3, #912]
    6a28:	f9004c85 	str	x5, [x4, #152]
    6a2c:	f941cc65 	ldr	x5, [x3, #920]
    6a30:	f9005085 	str	x5, [x4, #160]
    6a34:	f941d065 	ldr	x5, [x3, #928]
    6a38:	f9005485 	str	x5, [x4, #168]
    6a3c:	f941d465 	ldr	x5, [x3, #936]
    6a40:	f9005885 	str	x5, [x4, #176]
    6a44:	f941d865 	ldr	x5, [x3, #944]
    6a48:	f9005c85 	str	x5, [x4, #184]
    6a4c:	f941dc65 	ldr	x5, [x3, #952]
    6a50:	f9006085 	str	x5, [x4, #192]
    6a54:	f9400480 	ldr	x0, [x4, #8]
    6a58:	f9404844 	ldr	x4, [x2, #144]
    6a5c:	f901c464 	str	x4, [x3, #904]
    6a60:	f9404c44 	ldr	x4, [x2, #152]
    6a64:	f901c864 	str	x4, [x3, #912]
    6a68:	f9405044 	ldr	x4, [x2, #160]
    6a6c:	f901cc64 	str	x4, [x3, #920]
    6a70:	f9405444 	ldr	x4, [x2, #168]
    6a74:	f901d064 	str	x4, [x3, #928]
    6a78:	f9405844 	ldr	x4, [x2, #176]
    6a7c:	f901d464 	str	x4, [x3, #936]
    6a80:	a94b8844 	ldp	x4, x2, [x2, #184]
    6a84:	f901d864 	str	x4, [x3, #944]
    6a88:	f901dc62 	str	x2, [x3, #952]
    6a8c:	97ffef9d 	bl	2900 <swapcontext@plt>
    6a90:	97ffff64 	bl	6820 <fwp_free_zombie>
    6a94:	d503201f 	nop
    6a98:	91014260 	add	x0, x19, #0x50
    6a9c:	b943c000 	ldr	w0, [x0, #960]
    6aa0:	340001a0 	cbz	w0, 6ad4 <fwp_block+0x100>
    6aa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6aa8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6aac:	d65f03c0 	ret
    6ab0:	97fff705 	bl	46c4 <fwp_poll_events>
    6ab4:	f9406682 	ldr	x2, [x20, #200]
    6ab8:	b4ffffc2 	cbz	x2, 6ab0 <fwp_block+0xdc>
    6abc:	91014261 	add	x1, x19, #0x50
    6ac0:	f9408040 	ldr	x0, [x2, #256]
    6ac4:	f9006420 	str	x0, [x1, #200]
    6ac8:	b5fff9c0 	cbnz	x0, 6a00 <fwp_block+0x2c>
    6acc:	f900603f 	str	xzr, [x1, #192]
    6ad0:	17ffffcc 	b	6a00 <fwp_block+0x2c>
    6ad4:	f0000020 	adrp	x0, d000 <__modti3+0x60>
    6ad8:	9124c000 	add	x0, x0, #0x930
    6adc:	97ffefd5 	bl	2a30 <getenv@plt>
    6ae0:	5284e202 	mov	w2, #0x2710                	// #10000
    6ae4:	b4000060 	cbz	x0, 6af0 <fwp_block+0x11c>
    6ae8:	39400001 	ldrb	w1, [x0]
    6aec:	350000c1 	cbnz	w1, 6b04 <fwp_block+0x130>
    6af0:	91014273 	add	x19, x19, #0x50
    6af4:	b903c262 	str	w2, [x19, #960]
    6af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6afc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b00:	d65f03c0 	ret
    6b04:	52800142 	mov	w2, #0xa                   	// #10
    6b08:	d2800001 	mov	x1, #0x0                   	// #0
    6b0c:	97ffef19 	bl	2770 <strtoll@plt>
    6b10:	d1000403 	sub	x3, x0, #0x1
    6b14:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6b18:	eb02007f 	cmp	x3, x2
    6b1c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6b20:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6b24:	17fffff3 	b	6af0 <fwp_block+0x11c>
    6b28:	d503201f 	nop
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_drop10>:
    6b30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6b34:	910003fd 	mov	x29, sp
    6b38:	a90153f3 	stp	x19, x20, [sp, #16]
    6b3c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6b40:	f90013f5 	str	x21, [sp, #32]
    6b44:	9118c275 	add	x21, x19, #0x630
    6b48:	f949daa1 	ldr	x1, [x21, #5040]
    6b4c:	f949eea2 	ldr	x2, [x21, #5080]
    6b50:	cb010001 	sub	x1, x0, x1
    6b54:	eb02403f 	cmp	x1, x2, lsl #16
    6b58:	54000382 	b.cs	6bc8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b5c:	d350fc22 	lsr	x2, x1, #16
    6b60:	f949fea3 	ldr	x3, [x21, #5112]
    6b64:	8b020842 	add	x2, x2, x2, lsl #2
    6b68:	d37df042 	lsl	x2, x2, #3
    6b6c:	8b020064 	add	x4, x3, x2
    6b70:	f9401094 	ldr	x20, [x4, #32]
    6b74:	b40002b4 	cbz	x20, 6bc8 <fwp_drop10+0x98>
    6b78:	38626862 	ldrb	w2, [x3, x2]
    6b7c:	7100085f 	cmp	w2, #0x2
    6b80:	540007a0 	b.eq	6c74 <fwp_drop10+0x144>  // b.none
    6b84:	7100045f 	cmp	w2, #0x1
    6b88:	54000201 	b.ne	6bc8 <fwp_drop10+0x98>  // b.any
    6b8c:	29430885 	ldp	w5, w2, [x4, #24]
    6b90:	92403c21 	and	x1, x1, #0xffff
    6b94:	9b057c21 	mul	x1, x1, x5
    6b98:	d360fc21 	lsr	x1, x1, #32
    6b9c:	eb02003f 	cmp	x1, x2
    6ba0:	54000142 	b.cs	6bc8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6ba4:	8b010294 	add	x20, x20, x1
    6ba8:	39400281 	ldrb	w1, [x20]
    6bac:	340000e1 	cbz	w1, 6bc8 <fwp_drop10+0x98>
    6bb0:	7100043f 	cmp	w1, #0x1
    6bb4:	54000120 	b.eq	6bd8 <fwp_drop10+0xa8>  // b.none
    6bb8:	7103fc3f 	cmp	w1, #0xff
    6bbc:	540007c0 	b.eq	6cb4 <fwp_drop10+0x184>  // b.none
    6bc0:	51000421 	sub	w1, w1, #0x1
    6bc4:	39000281 	strb	w1, [x20]
    6bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bcc:	f94013f5 	ldr	x21, [sp, #32]
    6bd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bd4:	d65f03c0 	ret
    6bd8:	f9400001 	ldr	x1, [x0]
    6bdc:	b7f80581 	tbnz	x1, #63, 6c8c <fwp_drop10+0x15c>
    6be0:	9118c273 	add	x19, x19, #0x630
    6be4:	f949da61 	ldr	x1, [x19, #5040]
    6be8:	f949ee62 	ldr	x2, [x19, #5080]
    6bec:	cb010001 	sub	x1, x0, x1
    6bf0:	eb02403f 	cmp	x1, x2, lsl #16
    6bf4:	54fffea2 	b.cs	6bc8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bf8:	d350fc22 	lsr	x2, x1, #16
    6bfc:	8b020842 	add	x2, x2, x2, lsl #2
    6c00:	d37df042 	lsl	x2, x2, #3
    6c04:	8b020065 	add	x5, x3, x2
    6c08:	f94010a4 	ldr	x4, [x5, #32]
    6c0c:	b4fffde4 	cbz	x4, 6bc8 <fwp_drop10+0x98>
    6c10:	38626862 	ldrb	w2, [x3, x2]
    6c14:	7100085f 	cmp	w2, #0x2
    6c18:	54000220 	b.eq	6c5c <fwp_drop10+0x12c>  // b.none
    6c1c:	7100045f 	cmp	w2, #0x1
    6c20:	54fffd41 	b.ne	6bc8 <fwp_drop10+0x98>  // b.any
    6c24:	294308a3 	ldp	w3, w2, [x5, #24]
    6c28:	92403c21 	and	x1, x1, #0xffff
    6c2c:	9b037c21 	mul	x1, x1, x3
    6c30:	d360fc21 	lsr	x1, x1, #32
    6c34:	eb02003f 	cmp	x1, x2
    6c38:	54fffc82 	b.cs	6bc8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c3c:	8b010084 	add	x4, x4, x1
    6c40:	39400081 	ldrb	w1, [x4]
    6c44:	7100043f 	cmp	w1, #0x1
    6c48:	54fffc01 	b.ne	6bc8 <fwp_drop10+0x98>  // b.any
    6c4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c50:	f94013f5 	ldr	x21, [sp, #32]
    6c54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c58:	17fff80e 	b	4c90 <fwp_mem_free>
    6c5c:	72003c3f 	tst	w1, #0xffff
    6c60:	54ffff00 	b.eq	6c40 <fwp_drop10+0x110>  // b.none
    6c64:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c68:	f94013f5 	ldr	x21, [sp, #32]
    6c6c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c70:	d65f03c0 	ret
    6c74:	72003c3f 	tst	w1, #0xffff
    6c78:	54fff980 	b.eq	6ba8 <fwp_drop10+0x78>  // b.none
    6c7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c80:	f94013f5 	ldr	x21, [sp, #32]
    6c84:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c88:	d65f03c0 	ret
    6c8c:	f9400414 	ldr	x20, [x0, #8]
    6c90:	97fffb51 	bl	59d4 <fwp_rc_free_arr>
    6c94:	9118c260 	add	x0, x19, #0x630
    6c98:	f949d801 	ldr	x1, [x0, #5040]
    6c9c:	f949ec00 	ldr	x0, [x0, #5080]
    6ca0:	cb010281 	sub	x1, x20, x1
    6ca4:	eb00403f 	cmp	x1, x0, lsl #16
    6ca8:	54fff902 	b.cs	6bc8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cac:	aa1403e0 	mov	x0, x20
    6cb0:	17ffffab 	b	6b5c <fwp_drop10+0x2c>
    6cb4:	ca544680 	eor	x0, x20, x20, lsr #17
    6cb8:	9118c273 	add	x19, x19, #0x630
    6cbc:	ca402400 	eor	x0, x0, x0, lsr #9
    6cc0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6cc4:	f94a2400 	ldr	x0, [x0, #5192]
    6cc8:	b5000080 	cbnz	x0, 6cd8 <fwp_drop10+0x1a8>
    6ccc:	14000010 	b	6d0c <fwp_drop10+0x1dc>
    6cd0:	f9400800 	ldr	x0, [x0, #16]
    6cd4:	b40001c0 	cbz	x0, 6d0c <fwp_drop10+0x1dc>
    6cd8:	f9400001 	ldr	x1, [x0]
    6cdc:	eb14003f 	cmp	x1, x20
    6ce0:	54ffff81 	b.ne	6cd0 <fwp_drop10+0x1a0>  // b.any
    6ce4:	f9400401 	ldr	x1, [x0, #8]
    6ce8:	d1000421 	sub	x1, x1, #0x1
    6cec:	f9000401 	str	x1, [x0, #8]
    6cf0:	f103f83f 	cmp	x1, #0xfe
    6cf4:	54fff6a1 	b.ne	6bc8 <fwp_drop10+0x98>  // b.any
    6cf8:	aa1403e0 	mov	x0, x20
    6cfc:	97fff745 	bl	4a10 <fwp_rc_forget_slot>
    6d00:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d04:	39000280 	strb	w0, [x20]
    6d08:	17ffffb0 	b	6bc8 <fwp_drop10+0x98>
    6d0c:	f0000020 	adrp	x0, d000 <__modti3+0x60>
    6d10:	91200000 	add	x0, x0, #0x800
    6d14:	97fff2bb 	bl	3800 <fwp_trap>
    6d18:	d503201f 	nop
    6d1c:	d503201f 	nop

0000000000006d20 <fwp_caps173>:
    6d20:	34000041 	cbz	w1, 6d28 <fwp_caps173+0x8>
    6d24:	d65f03c0 	ret
    6d28:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    6d2c:	9118c063 	add	x3, x3, #0x630
    6d30:	f949d861 	ldr	x1, [x3, #5040]
    6d34:	f949ec62 	ldr	x2, [x3, #5080]
    6d38:	cb010001 	sub	x1, x0, x1
    6d3c:	eb02403f 	cmp	x1, x2, lsl #16
    6d40:	54ffff22 	b.cs	6d24 <fwp_caps173+0x4>  // b.hs, b.nlast
    6d44:	d350fc22 	lsr	x2, x1, #16
    6d48:	f949fc65 	ldr	x5, [x3, #5112]
    6d4c:	8b020842 	add	x2, x2, x2, lsl #2
    6d50:	d37df042 	lsl	x2, x2, #3
    6d54:	8b0200a4 	add	x4, x5, x2
    6d58:	f9401083 	ldr	x3, [x4, #32]
    6d5c:	b4fffe43 	cbz	x3, 6d24 <fwp_caps173+0x4>
    6d60:	386268a2 	ldrb	w2, [x5, x2]
    6d64:	7100085f 	cmp	w2, #0x2
    6d68:	540001c0 	b.eq	6da0 <fwp_caps173+0x80>  // b.none
    6d6c:	7100045f 	cmp	w2, #0x1
    6d70:	54fffda1 	b.ne	6d24 <fwp_caps173+0x4>  // b.any
    6d74:	29430885 	ldp	w5, w2, [x4, #24]
    6d78:	92403c21 	and	x1, x1, #0xffff
    6d7c:	9b057c21 	mul	x1, x1, x5
    6d80:	d360fc21 	lsr	x1, x1, #32
    6d84:	eb02003f 	cmp	x1, x2
    6d88:	54fffce2 	b.cs	6d24 <fwp_caps173+0x4>  // b.hs, b.nlast
    6d8c:	8b010063 	add	x3, x3, x1
    6d90:	39400061 	ldrb	w1, [x3]
    6d94:	7100043f 	cmp	w1, #0x1
    6d98:	54fffc61 	b.ne	6d24 <fwp_caps173+0x4>  // b.any
    6d9c:	17fff7bd 	b	4c90 <fwp_mem_free>
    6da0:	72003c3f 	tst	w1, #0xffff
    6da4:	54ffff60 	b.eq	6d90 <fwp_caps173+0x70>  // b.none
    6da8:	d65f03c0 	ret
    6dac:	d503201f 	nop

0000000000006db0 <fwp_args37>:
    6db0:	7100003f 	cmp	w1, #0x0
    6db4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6db8:	54000041 	b.ne	6dc0 <fwp_args37+0x10>  // b.any
    6dbc:	d65f03c0 	ret
    6dc0:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6dc4:	9118c042 	add	x2, x2, #0x630
    6dc8:	f9400001 	ldr	x1, [x0]
    6dcc:	f949d843 	ldr	x3, [x2, #5040]
    6dd0:	f949ec40 	ldr	x0, [x2, #5080]
    6dd4:	cb030021 	sub	x1, x1, x3
    6dd8:	eb00403f 	cmp	x1, x0, lsl #16
    6ddc:	54ffff02 	b.cs	6dbc <fwp_args37+0xc>  // b.hs, b.nlast
    6de0:	d350fc20 	lsr	x0, x1, #16
    6de4:	f949fc44 	ldr	x4, [x2, #5112]
    6de8:	8b000800 	add	x0, x0, x0, lsl #2
    6dec:	d37df002 	lsl	x2, x0, #3
    6df0:	8b020083 	add	x3, x4, x2
    6df4:	f9401060 	ldr	x0, [x3, #32]
    6df8:	b4fffe20 	cbz	x0, 6dbc <fwp_args37+0xc>
    6dfc:	38626882 	ldrb	w2, [x4, x2]
    6e00:	7100085f 	cmp	w2, #0x2
    6e04:	54000320 	b.eq	6e68 <fwp_args37+0xb8>  // b.none
    6e08:	7100045f 	cmp	w2, #0x1
    6e0c:	54fffd81 	b.ne	6dbc <fwp_args37+0xc>  // b.any
    6e10:	29430864 	ldp	w4, w2, [x3, #24]
    6e14:	92403c21 	and	x1, x1, #0xffff
    6e18:	9b047c21 	mul	x1, x1, x4
    6e1c:	d360fc21 	lsr	x1, x1, #32
    6e20:	eb02003f 	cmp	x1, x2
    6e24:	54fffcc2 	b.cs	6dbc <fwp_args37+0xc>  // b.hs, b.nlast
    6e28:	8b010000 	add	x0, x0, x1
    6e2c:	39400001 	ldrb	w1, [x0]
    6e30:	34fffc61 	cbz	w1, 6dbc <fwp_args37+0xc>
    6e34:	d00000c2 	adrp	x2, 20000 <__data_start>
    6e38:	91014042 	add	x2, x2, #0x50
    6e3c:	b9413043 	ldr	w3, [x2, #304]
    6e40:	350000c3 	cbnz	w3, 6e58 <fwp_args37+0xa8>
    6e44:	7103f43f 	cmp	w1, #0xfd
    6e48:	54000168 	b.hi	6e74 <fwp_args37+0xc4>  // b.pmore
    6e4c:	11000421 	add	w1, w1, #0x1
    6e50:	39000001 	strb	w1, [x0]
    6e54:	d65f03c0 	ret
    6e58:	f940ac43 	ldr	x3, [x2, #344]
    6e5c:	91000463 	add	x3, x3, #0x1
    6e60:	f900ac43 	str	x3, [x2, #344]
    6e64:	17fffff8 	b	6e44 <fwp_args37+0x94>
    6e68:	72003c3f 	tst	w1, #0xffff
    6e6c:	54fffe00 	b.eq	6e2c <fwp_args37+0x7c>  // b.none
    6e70:	d65f03c0 	ret
    6e74:	17fff6a0 	b	48f4 <fwp_rc_wide_dup>
    6e78:	d503201f 	nop
    6e7c:	d503201f 	nop

0000000000006e80 <fwp_caps37>:
    6e80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6e84:	910003fd 	mov	x29, sp
    6e88:	f9000bf3 	str	x19, [sp, #16]
    6e8c:	aa0003f3 	mov	x19, x0
    6e90:	b9400400 	ldr	w0, [x0, #4]
    6e94:	340004a0 	cbz	w0, 6f28 <fwp_caps37+0xa8>
    6e98:	f9400660 	ldr	x0, [x19, #8]
    6e9c:	350004e1 	cbnz	w1, 6f38 <fwp_caps37+0xb8>
    6ea0:	97fffd88 	bl	64c0 <fwp_drop4>
    6ea4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6ea8:	9118c042 	add	x2, x2, #0x630
    6eac:	f949d840 	ldr	x0, [x2, #5040]
    6eb0:	f949ec41 	ldr	x1, [x2, #5080]
    6eb4:	cb000260 	sub	x0, x19, x0
    6eb8:	eb01401f 	cmp	x0, x1, lsl #16
    6ebc:	54000382 	b.cs	6f2c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ec0:	d350fc01 	lsr	x1, x0, #16
    6ec4:	f949fc44 	ldr	x4, [x2, #5112]
    6ec8:	8b010821 	add	x1, x1, x1, lsl #2
    6ecc:	d37df021 	lsl	x1, x1, #3
    6ed0:	8b010083 	add	x3, x4, x1
    6ed4:	f9401062 	ldr	x2, [x3, #32]
    6ed8:	b40002a2 	cbz	x2, 6f2c <fwp_caps37+0xac>
    6edc:	38616881 	ldrb	w1, [x4, x1]
    6ee0:	7100083f 	cmp	w1, #0x2
    6ee4:	54000740 	b.eq	6fcc <fwp_caps37+0x14c>  // b.none
    6ee8:	7100043f 	cmp	w1, #0x1
    6eec:	54000201 	b.ne	6f2c <fwp_caps37+0xac>  // b.any
    6ef0:	29430464 	ldp	w4, w1, [x3, #24]
    6ef4:	92403c00 	and	x0, x0, #0xffff
    6ef8:	9b047c00 	mul	x0, x0, x4
    6efc:	d360fc00 	lsr	x0, x0, #32
    6f00:	eb01001f 	cmp	x0, x1
    6f04:	54000142 	b.cs	6f2c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f08:	8b000042 	add	x2, x2, x0
    6f0c:	39400040 	ldrb	w0, [x2]
    6f10:	7100041f 	cmp	w0, #0x1
    6f14:	540000c1 	b.ne	6f2c <fwp_caps37+0xac>  // b.any
    6f18:	aa1303e0 	mov	x0, x19
    6f1c:	f9400bf3 	ldr	x19, [sp, #16]
    6f20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f24:	17fff75b 	b	4c90 <fwp_mem_free>
    6f28:	34fffbe1 	cbz	w1, 6ea4 <fwp_caps37+0x24>
    6f2c:	f9400bf3 	ldr	x19, [sp, #16]
    6f30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f34:	d65f03c0 	ret
    6f38:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6f3c:	9118c042 	add	x2, x2, #0x630
    6f40:	f949d843 	ldr	x3, [x2, #5040]
    6f44:	f949ec41 	ldr	x1, [x2, #5080]
    6f48:	cb030000 	sub	x0, x0, x3
    6f4c:	eb01401f 	cmp	x0, x1, lsl #16
    6f50:	54fffee2 	b.cs	6f2c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f54:	d350fc01 	lsr	x1, x0, #16
    6f58:	f949fc44 	ldr	x4, [x2, #5112]
    6f5c:	8b010821 	add	x1, x1, x1, lsl #2
    6f60:	d37df021 	lsl	x1, x1, #3
    6f64:	8b010083 	add	x3, x4, x1
    6f68:	f9401062 	ldr	x2, [x3, #32]
    6f6c:	b4fffe02 	cbz	x2, 6f2c <fwp_caps37+0xac>
    6f70:	38616881 	ldrb	w1, [x4, x1]
    6f74:	7100083f 	cmp	w1, #0x2
    6f78:	54000300 	b.eq	6fd8 <fwp_caps37+0x158>  // b.none
    6f7c:	7100043f 	cmp	w1, #0x1
    6f80:	54fffd61 	b.ne	6f2c <fwp_caps37+0xac>  // b.any
    6f84:	92403c01 	and	x1, x0, #0xffff
    6f88:	29430064 	ldp	w4, w0, [x3, #24]
    6f8c:	9b047c21 	mul	x1, x1, x4
    6f90:	d360fc21 	lsr	x1, x1, #32
    6f94:	eb00003f 	cmp	x1, x0
    6f98:	54fffca2 	b.cs	6f2c <fwp_caps37+0xac>  // b.hs, b.nlast
    6f9c:	8b010042 	add	x2, x2, x1
    6fa0:	39400040 	ldrb	w0, [x2]
    6fa4:	34fffc40 	cbz	w0, 6f2c <fwp_caps37+0xac>
    6fa8:	d00000c1 	adrp	x1, 20000 <__data_start>
    6fac:	91014021 	add	x1, x1, #0x50
    6fb0:	b9413023 	ldr	w3, [x1, #304]
    6fb4:	35000183 	cbnz	w3, 6fe4 <fwp_caps37+0x164>
    6fb8:	7103f41f 	cmp	w0, #0xfd
    6fbc:	540001c8 	b.hi	6ff4 <fwp_caps37+0x174>  // b.pmore
    6fc0:	11000400 	add	w0, w0, #0x1
    6fc4:	39000040 	strb	w0, [x2]
    6fc8:	17ffffd9 	b	6f2c <fwp_caps37+0xac>
    6fcc:	72003c1f 	tst	w0, #0xffff
    6fd0:	54fffae1 	b.ne	6f2c <fwp_caps37+0xac>  // b.any
    6fd4:	17ffffce 	b	6f0c <fwp_caps37+0x8c>
    6fd8:	72003c1f 	tst	w0, #0xffff
    6fdc:	54fffa81 	b.ne	6f2c <fwp_caps37+0xac>  // b.any
    6fe0:	17fffff0 	b	6fa0 <fwp_caps37+0x120>
    6fe4:	f940ac23 	ldr	x3, [x1, #344]
    6fe8:	91000463 	add	x3, x3, #0x1
    6fec:	f900ac23 	str	x3, [x1, #344]
    6ff0:	17fffff2 	b	6fb8 <fwp_caps37+0x138>
    6ff4:	f9400bf3 	ldr	x19, [sp, #16]
    6ff8:	aa0203e0 	mov	x0, x2
    6ffc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7000:	17fff63d 	b	48f4 <fwp_rc_wide_dup>

0000000000007004 <f37>:
    7004:	d101c3ff 	sub	sp, sp, #0x70
    7008:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    700c:	f947f421 	ldr	x1, [x1, #4072]
    7010:	a9027bfd 	stp	x29, x30, [sp, #32]
    7014:	910083fd 	add	x29, sp, #0x20
    7018:	a90563f7 	stp	x23, x24, [sp, #80]
    701c:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    7020:	9118c2e3 	add	x3, x23, #0x630
    7024:	a90353f3 	stp	x19, x20, [sp, #48]
    7028:	a9045bf5 	stp	x21, x22, [sp, #64]
    702c:	aa0003f6 	mov	x22, x0
    7030:	a9066bf9 	stp	x25, x26, [sp, #96]
    7034:	f949ec62 	ldr	x2, [x3, #5080]
    7038:	f9400024 	ldr	x4, [x1]
    703c:	f9000fe4 	str	x4, [sp, #24]
    7040:	d2800004 	mov	x4, #0x0                   	// #0
    7044:	f949d861 	ldr	x1, [x3, #5040]
    7048:	d370bc42 	lsl	x2, x2, #16
    704c:	b40016a0 	cbz	x0, 7320 <f37+0x31c>
    7050:	f9400818 	ldr	x24, [x0, #16]
    7054:	cb010301 	sub	x1, x24, x1
    7058:	eb02003f 	cmp	x1, x2
    705c:	540003e2 	b.cs	70d8 <f37+0xd4>  // b.hs, b.nlast
    7060:	f949fc60 	ldr	x0, [x3, #5112]
    7064:	d350fc22 	lsr	x2, x1, #16
    7068:	8b020842 	add	x2, x2, x2, lsl #2
    706c:	8b020c02 	add	x2, x0, x2, lsl #3
    7070:	f9401040 	ldr	x0, [x2, #32]
    7074:	b4000320 	cbz	x0, 70d8 <f37+0xd4>
    7078:	39400043 	ldrb	w3, [x2]
    707c:	7100087f 	cmp	w3, #0x2
    7080:	54001420 	b.eq	7304 <f37+0x300>  // b.none
    7084:	7100047f 	cmp	w3, #0x1
    7088:	54000241 	b.ne	70d0 <f37+0xcc>  // b.any
    708c:	29430843 	ldp	w3, w2, [x2, #24]
    7090:	92403c21 	and	x1, x1, #0xffff
    7094:	9b037c21 	mul	x1, x1, x3
    7098:	d360fc21 	lsr	x1, x1, #32
    709c:	eb02003f 	cmp	x1, x2
    70a0:	54000182 	b.cs	70d0 <f37+0xcc>  // b.hs, b.nlast
    70a4:	8b010000 	add	x0, x0, x1
    70a8:	39400001 	ldrb	w1, [x0]
    70ac:	34000121 	cbz	w1, 70d0 <f37+0xcc>
    70b0:	b00000c2 	adrp	x2, 20000 <__data_start>
    70b4:	91014042 	add	x2, x2, #0x50
    70b8:	b9413043 	ldr	w3, [x2, #304]
    70bc:	350012a3 	cbnz	w3, 7310 <f37+0x30c>
    70c0:	7103f43f 	cmp	w1, #0xfd
    70c4:	54001708 	b.hi	73a4 <f37+0x3a0>  // b.pmore
    70c8:	11000421 	add	w1, w1, #0x1
    70cc:	39000001 	strb	w1, [x0]
    70d0:	d2800000 	mov	x0, #0x0                   	// #0
    70d4:	b40000d6 	cbz	x22, 70ec <f37+0xe8>
    70d8:	aa1603e1 	mov	x1, x22
    70dc:	d2800000 	mov	x0, #0x0                   	// #0
    70e0:	f9400821 	ldr	x1, [x1, #16]
    70e4:	91000400 	add	x0, x0, #0x1
    70e8:	b5ffffc1 	cbnz	x1, 70e0 <f37+0xdc>
    70ec:	b4001238 	cbz	x24, 7330 <f37+0x32c>
    70f0:	aa1803e1 	mov	x1, x24
    70f4:	d2800002 	mov	x2, #0x0                   	// #0
    70f8:	f9400821 	ldr	x1, [x1, #16]
    70fc:	91000442 	add	x2, x2, #0x1
    7100:	b5ffffc1 	cbnz	x1, 70f8 <f37+0xf4>
    7104:	eb00005f 	cmp	x2, x0
    7108:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    710c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7110:	eb01033f 	cmp	x25, x1
    7114:	540014e8 	b.hi	73b0 <f37+0x3ac>  // b.pmore
    7118:	d37ffb33 	lsl	x19, x25, #1
    711c:	52800041 	mov	w1, #0x2                   	// #2
    7120:	91000660 	add	x0, x19, #0x1
    7124:	d37df000 	lsl	x0, x0, #3
    7128:	97fff7fa 	bl	5110 <fwp_heap_alloc>
    712c:	9118c2e1 	add	x1, x23, #0x630
    7130:	aa0003fa 	mov	x26, x0
    7134:	f9000013 	str	x19, [x0]
    7138:	aa0103e0 	mov	x0, x1
    713c:	f949d821 	ldr	x1, [x1, #5040]
    7140:	f949ec00 	ldr	x0, [x0, #5080]
    7144:	cb010341 	sub	x1, x26, x1
    7148:	eb00403f 	cmp	x1, x0, lsl #16
    714c:	54000342 	b.cs	71b4 <f37+0x1b0>  // b.hs, b.nlast
    7150:	9118c2e2 	add	x2, x23, #0x630
    7154:	d350fc20 	lsr	x0, x1, #16
    7158:	8b000800 	add	x0, x0, x0, lsl #2
    715c:	f949fc43 	ldr	x3, [x2, #5112]
    7160:	d37df002 	lsl	x2, x0, #3
    7164:	8b020060 	add	x0, x3, x2
    7168:	f9401013 	ldr	x19, [x0, #32]
    716c:	b4000253 	cbz	x19, 71b4 <f37+0x1b0>
    7170:	38626862 	ldrb	w2, [x3, x2]
    7174:	7100085f 	cmp	w2, #0x2
    7178:	54000c00 	b.eq	72f8 <f37+0x2f4>  // b.none
    717c:	7100045f 	cmp	w2, #0x1
    7180:	540001a1 	b.ne	71b4 <f37+0x1b0>  // b.any
    7184:	29430002 	ldp	w2, w0, [x0, #24]
    7188:	92403c21 	and	x1, x1, #0xffff
    718c:	9b027c21 	mul	x1, x1, x2
    7190:	d360fc21 	lsr	x1, x1, #32
    7194:	eb00003f 	cmp	x1, x0
    7198:	540000e2 	b.cs	71b4 <f37+0x1b0>  // b.hs, b.nlast
    719c:	8b010273 	add	x19, x19, x1
    71a0:	39400260 	ldrb	w0, [x19]
    71a4:	7103fc1f 	cmp	w0, #0xff
    71a8:	54000e80 	b.eq	7378 <f37+0x374>  // b.none
    71ac:	52800020 	mov	w0, #0x1                   	// #1
    71b0:	39000260 	strb	w0, [x19]
    71b4:	b4000259 	cbz	x25, 71fc <f37+0x1f8>
    71b8:	8b191359 	add	x25, x26, x25, lsl #4
    71bc:	aa1a03f3 	mov	x19, x26
    71c0:	aa1603f5 	mov	x21, x22
    71c4:	aa1803f4 	mov	x20, x24
    71c8:	f9400683 	ldr	x3, [x20, #8]
    71cc:	f94006a2 	ldr	x2, [x21, #8]
    71d0:	f9400861 	ldr	x1, [x3, #16]
    71d4:	f9400840 	ldr	x0, [x2, #16]
    71d8:	fd400461 	ldr	d1, [x3, #8]
    71dc:	fd400440 	ldr	d0, [x2, #8]
    71e0:	97fff93d 	bl	56d4 <w120>
    71e4:	f9000660 	str	x0, [x19, #8]
    71e8:	f8010e61 	str	x1, [x19, #16]!
    71ec:	f9400a94 	ldr	x20, [x20, #16]
    71f0:	f9400ab5 	ldr	x21, [x21, #16]
    71f4:	eb13033f 	cmp	x25, x19
    71f8:	54fffe81 	b.ne	71c8 <f37+0x1c4>  // b.any
    71fc:	aa1803e0 	mov	x0, x24
    7200:	97fffcb0 	bl	64c0 <fwp_drop4>
    7204:	aa1603e0 	mov	x0, x22
    7208:	97fffcae 	bl	64c0 <fwp_drop4>
    720c:	9118c2f7 	add	x23, x23, #0x630
    7210:	aa1a03e0 	mov	x0, x26
    7214:	97fff973 	bl	57e0 <w176.constprop.0>
    7218:	aa0103f3 	mov	x19, x1
    721c:	aa0003f4 	mov	x20, x0
    7220:	aa1a03e0 	mov	x0, x26
    7224:	97fffe43 	bl	6b30 <fwp_drop10>
    7228:	a900cff4 	stp	x20, x19, [sp, #8]
    722c:	910023e1 	add	x1, sp, #0x8
    7230:	52800000 	mov	w0, #0x0                   	// #0
    7234:	97fff818 	bl	5294 <fwp_data.part.0.constprop.0>
    7238:	f949dae1 	ldr	x1, [x23, #5040]
    723c:	aa0003f3 	mov	x19, x0
    7240:	f949eee0 	ldr	x0, [x23, #5080]
    7244:	cb010261 	sub	x1, x19, x1
    7248:	eb00403f 	cmp	x1, x0, lsl #16
    724c:	54000322 	b.cs	72b0 <f37+0x2ac>  // b.hs, b.nlast
    7250:	d350fc22 	lsr	x2, x1, #16
    7254:	f949fee3 	ldr	x3, [x23, #5112]
    7258:	8b020842 	add	x2, x2, x2, lsl #2
    725c:	d37df042 	lsl	x2, x2, #3
    7260:	8b020060 	add	x0, x3, x2
    7264:	f9401014 	ldr	x20, [x0, #32]
    7268:	b4000254 	cbz	x20, 72b0 <f37+0x2ac>
    726c:	38626862 	ldrb	w2, [x3, x2]
    7270:	7100085f 	cmp	w2, #0x2
    7274:	540003c0 	b.eq	72ec <f37+0x2e8>  // b.none
    7278:	7100045f 	cmp	w2, #0x1
    727c:	540001a1 	b.ne	72b0 <f37+0x2ac>  // b.any
    7280:	29430002 	ldp	w2, w0, [x0, #24]
    7284:	92403c21 	and	x1, x1, #0xffff
    7288:	9b027c21 	mul	x1, x1, x2
    728c:	d360fc21 	lsr	x1, x1, #32
    7290:	eb00003f 	cmp	x1, x0
    7294:	540000e2 	b.cs	72b0 <f37+0x2ac>  // b.hs, b.nlast
    7298:	8b010294 	add	x20, x20, x1
    729c:	39400280 	ldrb	w0, [x20]
    72a0:	7103fc1f 	cmp	w0, #0xff
    72a4:	54000640 	b.eq	736c <f37+0x368>  // b.none
    72a8:	52800020 	mov	w0, #0x1                   	// #1
    72ac:	39000280 	strb	w0, [x20]
    72b0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    72b4:	f947f400 	ldr	x0, [x0, #4072]
    72b8:	f9400fe2 	ldr	x2, [sp, #24]
    72bc:	f9400001 	ldr	x1, [x0]
    72c0:	eb010042 	subs	x2, x2, x1
    72c4:	d2800001 	mov	x1, #0x0                   	// #0
    72c8:	54000721 	b.ne	73ac <f37+0x3a8>  // b.any
    72cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    72d0:	aa1303e0 	mov	x0, x19
    72d4:	a94353f3 	ldp	x19, x20, [sp, #48]
    72d8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    72dc:	a94563f7 	ldp	x23, x24, [sp, #80]
    72e0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    72e4:	9101c3ff 	add	sp, sp, #0x70
    72e8:	d65f03c0 	ret
    72ec:	72003c3f 	tst	w1, #0xffff
    72f0:	54fffe01 	b.ne	72b0 <f37+0x2ac>  // b.any
    72f4:	17ffffea 	b	729c <f37+0x298>
    72f8:	72003c3f 	tst	w1, #0xffff
    72fc:	54fff5c1 	b.ne	71b4 <f37+0x1b0>  // b.any
    7300:	17ffffa8 	b	71a0 <f37+0x19c>
    7304:	72003c3f 	tst	w1, #0xffff
    7308:	54ffee41 	b.ne	70d0 <f37+0xcc>  // b.any
    730c:	17ffff67 	b	70a8 <f37+0xa4>
    7310:	f940ac43 	ldr	x3, [x2, #344]
    7314:	91000463 	add	x3, x3, #0x1
    7318:	f900ac43 	str	x3, [x2, #344]
    731c:	17ffff69 	b	70c0 <f37+0xbc>
    7320:	cb0103e1 	neg	x1, x1
    7324:	eb02003f 	cmp	x1, x2
    7328:	540002e3 	b.cc	7384 <f37+0x380>  // b.lo, b.ul, b.last
    732c:	d503201f 	nop
    7330:	52800041 	mov	w1, #0x2                   	// #2
    7334:	d2800100 	mov	x0, #0x8                   	// #8
    7338:	97fff776 	bl	5110 <fwp_heap_alloc>
    733c:	aa0003e1 	mov	x1, x0
    7340:	9118c2e0 	add	x0, x23, #0x630
    7344:	aa0103fa 	mov	x26, x1
    7348:	d2800018 	mov	x24, #0x0                   	// #0
    734c:	f900003f 	str	xzr, [x1]
    7350:	f949d801 	ldr	x1, [x0, #5040]
    7354:	f949ec00 	ldr	x0, [x0, #5080]
    7358:	cb010341 	sub	x1, x26, x1
    735c:	eb00403f 	cmp	x1, x0, lsl #16
    7360:	54fff4e2 	b.cs	71fc <f37+0x1f8>  // b.hs, b.nlast
    7364:	d2800019 	mov	x25, #0x0                   	// #0
    7368:	17ffff7a 	b	7150 <f37+0x14c>
    736c:	aa1403e0 	mov	x0, x20
    7370:	97fff5a8 	bl	4a10 <fwp_rc_forget_slot>
    7374:	17ffffcd 	b	72a8 <f37+0x2a4>
    7378:	aa1303e0 	mov	x0, x19
    737c:	97fff5a5 	bl	4a10 <fwp_rc_forget_slot>
    7380:	17ffff8b 	b	71ac <f37+0x1a8>
    7384:	f949fc62 	ldr	x2, [x3, #5112]
    7388:	d350fc20 	lsr	x0, x1, #16
    738c:	8b000800 	add	x0, x0, x0, lsl #2
    7390:	8b000c42 	add	x2, x2, x0, lsl #3
    7394:	f9401040 	ldr	x0, [x2, #32]
    7398:	b4fffcc0 	cbz	x0, 7330 <f37+0x32c>
    739c:	d2800018 	mov	x24, #0x0                   	// #0
    73a0:	17ffff36 	b	7078 <f37+0x74>
    73a4:	97fff554 	bl	48f4 <fwp_rc_wide_dup>
    73a8:	17ffff4a 	b	70d0 <f37+0xcc>
    73ac:	97ffed3d 	bl	28a0 <__stack_chk_fail@plt>
    73b0:	d0000020 	adrp	x0, d000 <__modti3+0x60>
    73b4:	91250000 	add	x0, x0, #0x940
    73b8:	97fff112 	bl	3800 <fwp_trap>
    73bc:	d503201f 	nop

00000000000073c0 <fwp_owned_entry37>:
    73c0:	f9400000 	ldr	x0, [x0]
    73c4:	17ffff10 	b	7004 <f37>
    73c8:	d503201f 	nop
    73cc:	d503201f 	nop

00000000000073d0 <e37>:
    73d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    73d4:	910003fd 	mov	x29, sp
    73d8:	f9000bf3 	str	x19, [sp, #16]
    73dc:	f9400013 	ldr	x19, [x0]
    73e0:	aa1303e0 	mov	x0, x19
    73e4:	97fff927 	bl	5880 <fwp_rc_share>
    73e8:	aa1303e0 	mov	x0, x19
    73ec:	97ffff06 	bl	7004 <f37>
    73f0:	aa0003f3 	mov	x19, x0
    73f4:	97fff923 	bl	5880 <fwp_rc_share>
    73f8:	aa1303e0 	mov	x0, x19
    73fc:	f9400bf3 	ldr	x19, [sp, #16]
    7400:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7404:	d65f03c0 	ret
    7408:	d503201f 	nop
    740c:	d503201f 	nop

0000000000007410 <fwp_write>:
    7410:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7414:	910003fd 	mov	x29, sp
    7418:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    741c:	f947f484 	ldr	x4, [x4, #4072]
    7420:	a90153f3 	stp	x19, x20, [sp, #16]
    7424:	d10943ff 	sub	sp, sp, #0x250
    7428:	b9400045 	ldr	w5, [x2]
    742c:	aa0003f4 	mov	x20, x0
    7430:	f9400080 	ldr	x0, [x4]
    7434:	f90127e0 	str	x0, [sp, #584]
    7438:	d2800000 	mov	x0, #0x0                   	// #0
    743c:	710064bf 	cmp	w5, #0x19
    7440:	54000408 	b.hi	74c0 <fwp_write+0xb0>  // b.pmore
    7444:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xcc0>
    7448:	aa0103f3 	mov	x19, x1
    744c:	910a4000 	add	x0, x0, #0x290
    7450:	f9013bf5 	str	x21, [sp, #624]
    7454:	f9013ff6 	str	x22, [sp, #632]
    7458:	f90153fb 	str	x27, [sp, #672]
    745c:	f90157fc 	str	x28, [sp, #680]
    7460:	aa0203fc 	mov	x28, x2
    7464:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7468:	10000061 	adr	x1, 7474 <fwp_write+0x64>
    746c:	8b20a820 	add	x0, x1, w0, sxth #2
    7470:	d61f0000 	br	x0
    7474:	910123e0 	add	x0, sp, #0x48
    7478:	aa1303e5 	mov	x5, x19
    747c:	d0000024 	adrp	x4, d000 <__modti3+0x60>
    7480:	aa0003f3 	mov	x19, x0
    7484:	91262084 	add	x4, x4, #0x988
    7488:	d2804003 	mov	x3, #0x200                 	// #512
    748c:	aa0303e1 	mov	x1, x3
    7490:	52800042 	mov	w2, #0x2                   	// #2
    7494:	97ffecdf 	bl	2810 <__snprintf_chk@plt>
    7498:	aa1303e0 	mov	x0, x19
    749c:	97ffeca5 	bl	2730 <strlen@plt>
    74a0:	aa1303e1 	mov	x1, x19
    74a4:	aa0003e2 	mov	x2, x0
    74a8:	aa1403e0 	mov	x0, x20
    74ac:	97fff079 	bl	3690 <buf_put>
    74b0:	f9413bf5 	ldr	x21, [sp, #624]
    74b4:	f9413ff6 	ldr	x22, [sp, #632]
    74b8:	f94153fb 	ldr	x27, [sp, #672]
    74bc:	f94157fc 	ldr	x28, [sp, #680]
    74c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    74c4:	f947f400 	ldr	x0, [x0, #4072]
    74c8:	f94127e2 	ldr	x2, [sp, #584]
    74cc:	f9400001 	ldr	x1, [x0]
    74d0:	eb010042 	subs	x2, x2, x1
    74d4:	d2800001 	mov	x1, #0x0                   	// #0
    74d8:	540077c1 	b.ne	83d0 <fwp_write+0xfc0>  // b.any
    74dc:	910943ff 	add	sp, sp, #0x250
    74e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    74e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    74e8:	d65f03c0 	ret
    74ec:	910123e0 	add	x0, sp, #0x48
    74f0:	aa1303e5 	mov	x5, x19
    74f4:	d0000024 	adrp	x4, d000 <__modti3+0x60>
    74f8:	aa0003f3 	mov	x19, x0
    74fc:	91260084 	add	x4, x4, #0x980
    7500:	d2804003 	mov	x3, #0x200                 	// #512
    7504:	17ffffe2 	b	748c <fwp_write+0x7c>
    7508:	71004cbf 	cmp	w5, #0x13
    750c:	d0000020 	adrp	x0, d000 <__modti3+0x60>
    7510:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7514:	9125c000 	add	x0, x0, #0x970
    7518:	9125e021 	add	x1, x1, #0x978
    751c:	d2800082 	mov	x2, #0x4                   	// #4
    7520:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7524:	aa1403e0 	mov	x0, x20
    7528:	f90143f7 	str	x23, [sp, #640]
    752c:	d2800016 	mov	x22, #0x0                   	// #0
    7530:	f90147f8 	str	x24, [sp, #648]
    7534:	97fff057 	bl	3690 <buf_put>
    7538:	f9400260 	ldr	x0, [x19]
    753c:	d0000037 	adrp	x23, d000 <__modti3+0x60>
    7540:	d2800015 	mov	x21, #0x0                   	// #0
    7544:	9127e2f7 	add	x23, x23, #0x9f8
    7548:	b40047a0 	cbz	x0, 7e3c <fwp_write+0xa2c>
    754c:	b9400380 	ldr	w0, [x28]
    7550:	52800003 	mov	w3, #0x0                   	// #0
    7554:	f9401f82 	ldr	x2, [x28, #56]
    7558:	71004c1f 	cmp	w0, #0x13
    755c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7560:	aa1403e0 	mov	x0, x20
    7564:	8b010e61 	add	x1, x19, x1, lsl #3
    7568:	f9400421 	ldr	x1, [x1, #8]
    756c:	97ffffa9 	bl	7410 <fwp_write>
    7570:	b9400380 	ldr	w0, [x28]
    7574:	7100481f 	cmp	w0, #0x12
    7578:	54004b40 	b.eq	7ee0 <fwp_write+0xad0>  // b.none
    757c:	f9400260 	ldr	x0, [x19]
    7580:	910006b5 	add	x21, x21, #0x1
    7584:	91000ad6 	add	x22, x22, #0x2
    7588:	eb15001f 	cmp	x0, x21
    758c:	54004589 	b.ls	7e3c <fwp_write+0xa2c>  // b.plast
    7590:	aa1703e1 	mov	x1, x23
    7594:	aa1403e0 	mov	x0, x20
    7598:	d2800042 	mov	x2, #0x2                   	// #2
    759c:	97fff03d 	bl	3690 <buf_put>
    75a0:	17ffffeb 	b	754c <fwp_write+0x13c>
    75a4:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    75a8:	9126c021 	add	x1, x1, #0x9b0
    75ac:	d28000c2 	mov	x2, #0x6                   	// #6
    75b0:	aa1403e0 	mov	x0, x20
    75b4:	91004273 	add	x19, x19, #0x10
    75b8:	97fff036 	bl	3690 <buf_put>
    75bc:	aa1303e0 	mov	x0, x19
    75c0:	97ffec5c 	bl	2730 <strlen@plt>
    75c4:	aa1303e1 	mov	x1, x19
    75c8:	aa0003e2 	mov	x2, x0
    75cc:	aa1403e0 	mov	x0, x20
    75d0:	97fff030 	bl	3690 <buf_put>
    75d4:	528007c3 	mov	w3, #0x3e                  	// #62
    75d8:	aa1403e0 	mov	x0, x20
    75dc:	91001fe1 	add	x1, sp, #0x7
    75e0:	d2800022 	mov	x2, #0x1                   	// #1
    75e4:	39001fe3 	strb	w3, [sp, #7]
    75e8:	17ffffb1 	b	74ac <fwp_write+0x9c>
    75ec:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    75f0:	f947f400 	ldr	x0, [x0, #4072]
    75f4:	f94127e2 	ldr	x2, [sp, #584]
    75f8:	f9400001 	ldr	x1, [x0]
    75fc:	eb010042 	subs	x2, x2, x1
    7600:	d2800001 	mov	x1, #0x0                   	// #0
    7604:	540034e1 	b.ne	7ca0 <fwp_write+0x890>  // b.any
    7608:	f9413bf5 	ldr	x21, [sp, #624]
    760c:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7610:	f9413ff6 	ldr	x22, [sp, #632]
    7614:	aa1403e0 	mov	x0, x20
    7618:	91264021 	add	x1, x1, #0x990
    761c:	d2800142 	mov	x2, #0xa                   	// #10
    7620:	f94153fb 	ldr	x27, [sp, #672]
    7624:	f94157fc 	ldr	x28, [sp, #680]
    7628:	910943ff 	add	sp, sp, #0x250
    762c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7630:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7634:	17fff017 	b	3690 <buf_put>
    7638:	f9400456 	ldr	x22, [x2, #8]
    763c:	f90143f7 	str	x23, [sp, #640]
    7640:	f90147f8 	str	x24, [sp, #648]
    7644:	b4005b16 	cbz	x22, 81a4 <fwp_write+0xd94>
    7648:	aa1603e0 	mov	x0, x22
    764c:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7650:	91284021 	add	x1, x1, #0xa10
    7654:	97ffecb3 	bl	2920 <strcmp@plt>
    7658:	2a0003f5 	mov	w21, w0
    765c:	34005fe0 	cbz	w0, 8258 <fwp_write+0xe48>
    7660:	aa1603e0 	mov	x0, x22
    7664:	97ffec33 	bl	2730 <strlen@plt>
    7668:	aa1603e1 	mov	x1, x22
    766c:	aa0003e2 	mov	x2, x0
    7670:	aa1403e0 	mov	x0, x20
    7674:	97fff007 	bl	3690 <buf_put>
    7678:	52800403 	mov	w3, #0x20                  	// #32
    767c:	91001ff5 	add	x21, sp, #0x7
    7680:	aa1503e1 	mov	x1, x21
    7684:	aa1403e0 	mov	x0, x20
    7688:	d2800022 	mov	x2, #0x1                   	// #1
    768c:	39001fe3 	strb	w3, [sp, #7]
    7690:	97fff000 	bl	3690 <buf_put>
    7694:	52800f63 	mov	w3, #0x7b                  	// #123
    7698:	aa1403e0 	mov	x0, x20
    769c:	aa1503e1 	mov	x1, x21
    76a0:	d2800022 	mov	x2, #0x1                   	// #1
    76a4:	39001fe3 	strb	w3, [sp, #7]
    76a8:	97ffeffa 	bl	3690 <buf_put>
    76ac:	b9401380 	ldr	w0, [x28, #16]
    76b0:	52800018 	mov	w24, #0x0                   	// #0
    76b4:	7100001f 	cmp	w0, #0x0
    76b8:	54003aad 	b.le	7e0c <fwp_write+0x9fc>
    76bc:	f9014bf9 	str	x25, [sp, #656]
    76c0:	d0000039 	adrp	x25, d000 <__modti3+0x60>
    76c4:	9128e339 	add	x25, x25, #0xa38
    76c8:	f9014ffa 	str	x26, [sp, #664]
    76cc:	d000003a 	adrp	x26, d000 <__modti3+0x60>
    76d0:	9127e35a 	add	x26, x26, #0x9f8
    76d4:	91002276 	add	x22, x19, #0x8
    76d8:	d2800013 	mov	x19, #0x0                   	// #0
    76dc:	b5003e93 	cbnz	x19, 7eac <fwp_write+0xa9c>
    76e0:	d37df277 	lsl	x23, x19, #3
    76e4:	34003cb8 	cbz	w24, 7e78 <fwp_write+0xa68>
    76e8:	f9401382 	ldr	x2, [x28, #32]
    76ec:	aa1403e0 	mov	x0, x20
    76f0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    76f4:	52800003 	mov	w3, #0x0                   	// #0
    76f8:	f8776842 	ldr	x2, [x2, x23]
    76fc:	91000673 	add	x19, x19, #0x1
    7700:	97ffff44 	bl	7410 <fwp_write>
    7704:	b9401380 	ldr	w0, [x28, #16]
    7708:	6b13001f 	cmp	w0, w19
    770c:	54fffe8c 	b.gt	76dc <fwp_write+0x2cc>
    7710:	f9414bf9 	ldr	x25, [sp, #656]
    7714:	f9414ffa 	ldr	x26, [sp, #664]
    7718:	340037b8 	cbz	w24, 7e0c <fwp_write+0x9fc>
    771c:	52800523 	mov	w3, #0x29                  	// #41
    7720:	aa1503e1 	mov	x1, x21
    7724:	aa1403e0 	mov	x0, x20
    7728:	d2800022 	mov	x2, #0x1                   	// #1
    772c:	39001fe3 	strb	w3, [sp, #7]
    7730:	97ffefd8 	bl	3690 <buf_put>
    7734:	f9413bf5 	ldr	x21, [sp, #624]
    7738:	f9413ff6 	ldr	x22, [sp, #632]
    773c:	f94143f7 	ldr	x23, [sp, #640]
    7740:	f94147f8 	ldr	x24, [sp, #648]
    7744:	f94153fb 	ldr	x27, [sp, #672]
    7748:	f94157fc 	ldr	x28, [sp, #680]
    774c:	17ffff5d 	b	74c0 <fwp_write+0xb0>
    7750:	b9404855 	ldr	w21, [x2, #72]
    7754:	aa1403e0 	mov	x0, x20
    7758:	93407eb6 	sxtw	x22, w21
    775c:	91000ac1 	add	x1, x22, #0x2
    7760:	97ffef98 	bl	35c0 <buf_grow>
    7764:	a9400281 	ldp	x1, x0, [x20]
    7768:	528e8603 	mov	w3, #0x7430                	// #29744
    776c:	78206823 	strh	w3, [x1, x0]
    7770:	8b000022 	add	x2, x1, x0
    7774:	710002bf 	cmp	w21, #0x0
    7778:	540036cd 	b.le	7e50 <fwp_write+0xa40>
    777c:	110006a3 	add	w3, w21, #0x1
    7780:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7784:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7788:	91000449 	add	x9, x2, #0x1
    778c:	8b23c043 	add	x3, x2, w3, sxtw
    7790:	f28aaac6 	movk	x6, #0x5556
    7794:	f2955568 	movk	x8, #0xaaab
    7798:	1400000d 	b	77cc <fwp_write+0x3bc>
    779c:	d2800021 	mov	x1, #0x1                   	// #1
    77a0:	528005a5 	mov	w5, #0x2d                  	// #45
    77a4:	f100001f 	cmp	x0, #0x0
    77a8:	9b467e60 	smulh	x0, x19, x6
    77ac:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    77b0:	381ff465 	strb	w5, [x3], #-1
    77b4:	cb040000 	sub	x0, x0, x4
    77b8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    77bc:	cb020000 	sub	x0, x0, x2
    77c0:	8b010013 	add	x19, x0, x1
    77c4:	eb03013f 	cmp	x9, x3
    77c8:	54003440 	b.eq	7e50 <fwp_write+0xa40>  // b.none
    77cc:	9b467e60 	smulh	x0, x19, x6
    77d0:	937ffe64 	asr	x4, x19, #63
    77d4:	52800605 	mov	w5, #0x30                  	// #48
    77d8:	cb040000 	sub	x0, x0, x4
    77dc:	8b000400 	add	x0, x0, x0, lsl #1
    77e0:	cb000260 	sub	x0, x19, x0
    77e4:	91000c01 	add	x1, x0, #0x3
    77e8:	9bc87c22 	umulh	x2, x1, x8
    77ec:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    77f0:	8b4204e2 	add	x2, x7, x2, lsr #1
    77f4:	eb020021 	subs	x1, x1, x2
    77f8:	54fffd60 	b.eq	77a4 <fwp_write+0x394>  // b.none
    77fc:	f100043f 	cmp	x1, #0x1
    7800:	54fffce1 	b.ne	779c <fwp_write+0x38c>  // b.any
    7804:	d2800001 	mov	x1, #0x0                   	// #0
    7808:	52800565 	mov	w5, #0x2b                  	// #43
    780c:	17ffffe6 	b	77a4 <fwp_write+0x394>
    7810:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7814:	f947f400 	ldr	x0, [x0, #4072]
    7818:	f94127e2 	ldr	x2, [sp, #584]
    781c:	f9400001 	ldr	x1, [x0]
    7820:	eb010042 	subs	x2, x2, x1
    7824:	d2800001 	mov	x1, #0x0                   	// #0
    7828:	540023c1 	b.ne	7ca0 <fwp_write+0x890>  // b.any
    782c:	f9413bf5 	ldr	x21, [sp, #624]
    7830:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7834:	f9413ff6 	ldr	x22, [sp, #632]
    7838:	aa1403e0 	mov	x0, x20
    783c:	91268021 	add	x1, x1, #0x9a0
    7840:	d2800102 	mov	x2, #0x8                   	// #8
    7844:	17ffff77 	b	7620 <fwp_write+0x210>
    7848:	aa1403e0 	mov	x0, x20
    784c:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7850:	d28000c2 	mov	x2, #0x6                   	// #6
    7854:	91280021 	add	x1, x1, #0xa00
    7858:	97ffef8e 	bl	3690 <buf_put>
    785c:	d2800015 	mov	x21, #0x0                   	// #0
    7860:	f9400263 	ldr	x3, [x19]
    7864:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7868:	54002c60 	b.eq	7df4 <fwp_write+0x9e4>  // b.none
    786c:	f9401f82 	ldr	x2, [x28, #56]
    7870:	f90143f7 	str	x23, [sp, #640]
    7874:	f90147f8 	str	x24, [sp, #648]
    7878:	d2800857 	mov	x23, #0x42                  	// #66
    787c:	f9014bf9 	str	x25, [sp, #656]
    7880:	d0000036 	adrp	x22, d000 <__modti3+0x60>
    7884:	f9014ffa 	str	x26, [sp, #664]
    7888:	9127e2d6 	add	x22, x22, #0x9f8
    788c:	d2800038 	mov	x24, #0x1                   	// #1
    7890:	f2a18017 	movk	x23, #0xc00, lsl #16
    7894:	d2809099 	mov	x25, #0x484                 	// #1156
    7898:	b40004a2 	cbz	x2, 792c <fwp_write+0x51c>
    789c:	b9400040 	ldr	w0, [x2]
    78a0:	7100701f 	cmp	w0, #0x1c
    78a4:	540042c0 	b.eq	80fc <fwp_write+0xcec>  // b.none
    78a8:	71006c1f 	cmp	w0, #0x1b
    78ac:	54000408 	b.hi	792c <fwp_write+0x51c>  // b.pmore
    78b0:	9ac02301 	lsl	x1, x24, x0
    78b4:	ea17003f 	tst	x1, x23
    78b8:	540036a1 	b.ne	7f8c <fwp_write+0xb7c>  // b.any
    78bc:	ea19003f 	tst	x1, x25
    78c0:	54003521 	b.ne	7f64 <fwp_write+0xb54>  // b.any
    78c4:	d2800424 	mov	x4, #0x21                  	// #33
    78c8:	ea04003f 	tst	x1, x4
    78cc:	54000300 	b.eq	792c <fwp_write+0x51c>  // b.none
    78d0:	b7f849c3 	tbnz	x3, #63, 8208 <fwp_write+0xdf8>
    78d4:	91002261 	add	x1, x19, #0x8
    78d8:	8b150021 	add	x1, x1, x21
    78dc:	39400021 	ldrb	w1, [x1]
    78e0:	7100001f 	cmp	w0, #0x0
    78e4:	93401c23 	sxtb	x3, w1
    78e8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    78ec:	d503201f 	nop
    78f0:	aa1403e0 	mov	x0, x20
    78f4:	52800003 	mov	w3, #0x0                   	// #0
    78f8:	97fffec6 	bl	7410 <fwp_write>
    78fc:	910006b5 	add	x21, x21, #0x1
    7900:	f9400260 	ldr	x0, [x19]
    7904:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7908:	eb0002bf 	cmp	x21, x0
    790c:	540026c2 	b.cs	7de4 <fwp_write+0x9d4>  // b.hs, b.nlast
    7910:	d2800042 	mov	x2, #0x2                   	// #2
    7914:	aa1603e1 	mov	x1, x22
    7918:	aa1403e0 	mov	x0, x20
    791c:	97ffef5d 	bl	3690 <buf_put>
    7920:	f9401f82 	ldr	x2, [x28, #56]
    7924:	f9400263 	ldr	x3, [x19]
    7928:	b5fffba2 	cbnz	x2, 789c <fwp_write+0x48c>
    792c:	d37df2a0 	lsl	x0, x21, #3
    7930:	b7f83f03 	tbnz	x3, #63, 8110 <fwp_write+0xd00>
    7934:	91002261 	add	x1, x19, #0x8
    7938:	8b000020 	add	x0, x1, x0
    793c:	f9400001 	ldr	x1, [x0]
    7940:	17ffffec 	b	78f0 <fwp_write+0x4e0>
    7944:	a9400e62 	ldp	x2, x3, [x19]
    7948:	b7f83ca3 	tbnz	x3, #63, 80dc <fwp_write+0xccc>
    794c:	910123f5 	add	x21, sp, #0x48
    7950:	aa1503e0 	mov	x0, x21
    7954:	97ffed33 	bl	2e20 <fwp_fmt_u128>
    7958:	aa1503e0 	mov	x0, x21
    795c:	97ffeb75 	bl	2730 <strlen@plt>
    7960:	aa1503e1 	mov	x1, x21
    7964:	aa0003e2 	mov	x2, x0
    7968:	17fffed0 	b	74a8 <fwp_write+0x98>
    796c:	fd015be8 	str	d8, [sp, #688]
    7970:	1e270268 	fmov	s8, w19
    7974:	fd015fe9 	str	d9, [sp, #696]
    7978:	1e282100 	fcmp	s8, s8
    797c:	54004d26 	b.vs	8320 <fwp_write+0xf10>
    7980:	1e20c101 	fabs	s1, s8
    7984:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7988:	1e270000 	fmov	s0, w0
    798c:	1e202020 	fcmp	s1, s0
    7990:	54002c0d 	b.le	7f10 <fwp_write+0xb00>
    7994:	1e202118 	fcmpe	s8, #0.0
    7998:	d0000022 	adrp	x2, d000 <__modti3+0x60>
    799c:	9112e042 	add	x2, x2, #0x4b8
    79a0:	910123f5 	add	x21, sp, #0x48
    79a4:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    79a8:	91254021 	add	x1, x1, #0x950
    79ac:	aa1503e0 	mov	x0, x21
    79b0:	9a81c041 	csel	x1, x2, x1, gt
    79b4:	97ffec0b 	bl	29e0 <strcpy@plt>
    79b8:	aa1503e0 	mov	x0, x21
    79bc:	97ffeb5d 	bl	2730 <strlen@plt>
    79c0:	aa1503e1 	mov	x1, x21
    79c4:	aa0003e2 	mov	x2, x0
    79c8:	aa1403e0 	mov	x0, x20
    79cc:	97ffef31 	bl	3690 <buf_put>
    79d0:	f9413bf5 	ldr	x21, [sp, #624]
    79d4:	f9413ff6 	ldr	x22, [sp, #632]
    79d8:	f94153fb 	ldr	x27, [sp, #672]
    79dc:	f94157fc 	ldr	x28, [sp, #680]
    79e0:	fd415be8 	ldr	d8, [sp, #688]
    79e4:	fd415fe9 	ldr	d9, [sp, #696]
    79e8:	17fffeb6 	b	74c0 <fwp_write+0xb0>
    79ec:	f9400276 	ldr	x22, [x19]
    79f0:	34002e03 	cbz	w3, 7fb0 <fwp_write+0xba0>
    79f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    79f8:	f947f400 	ldr	x0, [x0, #4072]
    79fc:	f94127e2 	ldr	x2, [sp, #584]
    7a00:	f9400001 	ldr	x1, [x0]
    7a04:	eb010042 	subs	x2, x2, x1
    7a08:	d2800001 	mov	x1, #0x0                   	// #0
    7a0c:	540014a1 	b.ne	7ca0 <fwp_write+0x890>  // b.any
    7a10:	aa1603e2 	mov	x2, x22
    7a14:	91002261 	add	x1, x19, #0x8
    7a18:	f9413bf5 	ldr	x21, [sp, #624]
    7a1c:	aa1403e0 	mov	x0, x20
    7a20:	f9413ff6 	ldr	x22, [sp, #632]
    7a24:	17fffeff 	b	7620 <fwp_write+0x210>
    7a28:	fd015be8 	str	d8, [sp, #688]
    7a2c:	9e670268 	fmov	d8, x19
    7a30:	fd015fe9 	str	d9, [sp, #696]
    7a34:	1e682100 	fcmp	d8, d8
    7a38:	54004746 	b.vs	8320 <fwp_write+0xf10>
    7a3c:	1e60c101 	fabs	d1, d8
    7a40:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7a44:	9e670000 	fmov	d0, x0
    7a48:	910123f5 	add	x21, sp, #0x48
    7a4c:	52800033 	mov	w19, #0x1                   	// #1
    7a50:	1e602020 	fcmp	d1, d0
    7a54:	540001ad 	b.le	7a88 <fwp_write+0x678>
    7a58:	1e602118 	fcmpe	d8, #0.0
    7a5c:	d0000022 	adrp	x2, d000 <__modti3+0x60>
    7a60:	9112e042 	add	x2, x2, #0x4b8
    7a64:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7a68:	91254021 	add	x1, x1, #0x950
    7a6c:	aa1503e0 	mov	x0, x21
    7a70:	9a81c041 	csel	x1, x2, x1, gt
    7a74:	97ffebdb 	bl	29e0 <strcpy@plt>
    7a78:	17ffffd0 	b	79b8 <fwp_write+0x5a8>
    7a7c:	11000673 	add	w19, w19, #0x1
    7a80:	71004a7f 	cmp	w19, #0x12
    7a84:	54003860 	b.eq	8190 <fwp_write+0xd80>  // b.none
    7a88:	1e604100 	fmov	d0, d8
    7a8c:	2a1303e1 	mov	w1, w19
    7a90:	aa1503e0 	mov	x0, x21
    7a94:	97fff040 	bl	3b94 <fwp_format_g.constprop.0>
    7a98:	aa1503e0 	mov	x0, x21
    7a9c:	d2800001 	mov	x1, #0x0                   	// #0
    7aa0:	97ffeb38 	bl	2780 <strtod@plt>
    7aa4:	1e602100 	fcmp	d8, d0
    7aa8:	54fffea1 	b.ne	7a7c <fwp_write+0x66c>  // b.any
    7aac:	aa1503e0 	mov	x0, x21
    7ab0:	97ffef31 	bl	3774 <fwp_finish_float>
    7ab4:	17ffffc1 	b	79b8 <fwp_write+0x5a8>
    7ab8:	a9400e62 	ldp	x2, x3, [x19]
    7abc:	910123f3 	add	x19, sp, #0x48
    7ac0:	aa1303e0 	mov	x0, x19
    7ac4:	97ffecd7 	bl	2e20 <fwp_fmt_u128>
    7ac8:	17fffe74 	b	7498 <fwp_write+0x88>
    7acc:	f90143f7 	str	x23, [sp, #640]
    7ad0:	f90147f8 	str	x24, [sp, #648]
    7ad4:	2a1303f8 	mov	w24, w19
    7ad8:	f9014bf9 	str	x25, [sp, #656]
    7adc:	f9014ffa 	str	x26, [sp, #664]
    7ae0:	f13ffe7f 	cmp	x19, #0xfff
    7ae4:	54000049 	b.ls	7aec <fwp_write+0x6dc>  // b.plast
    7ae8:	b9400278 	ldr	w24, [x19]
    7aec:	f9400f80 	ldr	x0, [x28, #24]
    7af0:	2a1803f5 	mov	w21, w24
    7af4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7af8:	d37ef6b9 	lsl	x25, x21, #2
    7afc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7b00:	aa1603e0 	mov	x0, x22
    7b04:	97ffeb0b 	bl	2730 <strlen@plt>
    7b08:	aa1603e1 	mov	x1, x22
    7b0c:	aa0003e2 	mov	x2, x0
    7b10:	aa1403e0 	mov	x0, x20
    7b14:	97ffeedf 	bl	3690 <buf_put>
    7b18:	f9401780 	ldr	x0, [x28, #40]
    7b1c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7b20:	7100001f 	cmp	w0, #0x0
    7b24:	5400068d 	b.le	7bf4 <fwp_write+0x7e4>
    7b28:	91002276 	add	x22, x19, #0x8
    7b2c:	91001ff5 	add	x21, sp, #0x7
    7b30:	d280001b 	mov	x27, #0x0                   	// #0
    7b34:	5280041a 	mov	w26, #0x20                  	// #32
    7b38:	f9401b80 	ldr	x0, [x28, #48]
    7b3c:	aa1503e1 	mov	x1, x21
    7b40:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7b44:	d2800022 	mov	x2, #0x1                   	// #1
    7b48:	f8786803 	ldr	x3, [x0, x24]
    7b4c:	aa1403e0 	mov	x0, x20
    7b50:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7b54:	39001ffa 	strb	w26, [sp, #7]
    7b58:	97ffeece 	bl	3690 <buf_put>
    7b5c:	f13ffeff 	cmp	x23, #0xfff
    7b60:	b9400261 	ldr	w1, [x19]
    7b64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7b68:	7100383f 	cmp	w1, #0xe
    7b6c:	54000160 	b.eq	7b98 <fwp_write+0x788>  // b.none
    7b70:	7100403f 	cmp	w1, #0x10
    7b74:	54001a60 	b.eq	7ec0 <fwp_write+0xab0>  // b.none
    7b78:	7100283f 	cmp	w1, #0xa
    7b7c:	54002aa0 	b.eq	80d0 <fwp_write+0xcc0>  // b.none
    7b80:	540014ac 	b.gt	7e14 <fwp_write+0xa04>
    7b84:	71000c3f 	cmp	w1, #0x3
    7b88:	540029ac 	b.gt	80bc <fwp_write+0xcac>
    7b8c:	d37ffee0 	lsr	x0, x23, #63
    7b90:	37f814a1 	tbnz	w1, #31, 7e24 <fwp_write+0xa14>
    7b94:	d503201f 	nop
    7b98:	34001460 	cbz	w0, 7e24 <fwp_write+0xa14>
    7b9c:	52800503 	mov	w3, #0x28                  	// #40
    7ba0:	aa1503e1 	mov	x1, x21
    7ba4:	aa1403e0 	mov	x0, x20
    7ba8:	d2800022 	mov	x2, #0x1                   	// #1
    7bac:	39001fe3 	strb	w3, [sp, #7]
    7bb0:	97ffeeb8 	bl	3690 <buf_put>
    7bb4:	aa1303e2 	mov	x2, x19
    7bb8:	aa1703e1 	mov	x1, x23
    7bbc:	aa1403e0 	mov	x0, x20
    7bc0:	52800003 	mov	w3, #0x0                   	// #0
    7bc4:	97fffe13 	bl	7410 <fwp_write>
    7bc8:	52800523 	mov	w3, #0x29                  	// #41
    7bcc:	aa1503e1 	mov	x1, x21
    7bd0:	aa1403e0 	mov	x0, x20
    7bd4:	d2800022 	mov	x2, #0x1                   	// #1
    7bd8:	39001fe3 	strb	w3, [sp, #7]
    7bdc:	97ffeead 	bl	3690 <buf_put>
    7be0:	f9401780 	ldr	x0, [x28, #40]
    7be4:	9100077b 	add	x27, x27, #0x1
    7be8:	b8796800 	ldr	w0, [x0, x25]
    7bec:	6b1b001f 	cmp	w0, w27
    7bf0:	54fffa4c 	b.gt	7b38 <fwp_write+0x728>
    7bf4:	f9413bf5 	ldr	x21, [sp, #624]
    7bf8:	f9413ff6 	ldr	x22, [sp, #632]
    7bfc:	f94143f7 	ldr	x23, [sp, #640]
    7c00:	f94147f8 	ldr	x24, [sp, #648]
    7c04:	f9414bf9 	ldr	x25, [sp, #656]
    7c08:	f9414ffa 	ldr	x26, [sp, #664]
    7c0c:	f94153fb 	ldr	x27, [sp, #672]
    7c10:	f94157fc 	ldr	x28, [sp, #680]
    7c14:	17fffe2b 	b	74c0 <fwp_write+0xb0>
    7c18:	52800783 	mov	w3, #0x3c                  	// #60
    7c1c:	91001ff3 	add	x19, sp, #0x7
    7c20:	aa1303e1 	mov	x1, x19
    7c24:	d2800022 	mov	x2, #0x1                   	// #1
    7c28:	aa1403e0 	mov	x0, x20
    7c2c:	39001fe3 	strb	w3, [sp, #7]
    7c30:	97ffee98 	bl	3690 <buf_put>
    7c34:	f9400795 	ldr	x21, [x28, #8]
    7c38:	aa1503e0 	mov	x0, x21
    7c3c:	97ffeabd 	bl	2730 <strlen@plt>
    7c40:	aa1503e1 	mov	x1, x21
    7c44:	aa0003e2 	mov	x2, x0
    7c48:	aa1403e0 	mov	x0, x20
    7c4c:	97ffee91 	bl	3690 <buf_put>
    7c50:	528007c3 	mov	w3, #0x3e                  	// #62
    7c54:	aa1303e1 	mov	x1, x19
    7c58:	aa1403e0 	mov	x0, x20
    7c5c:	d2800022 	mov	x2, #0x1                   	// #1
    7c60:	39001fe3 	strb	w3, [sp, #7]
    7c64:	17fffe12 	b	74ac <fwp_write+0x9c>
    7c68:	f100067f 	cmp	x19, #0x1
    7c6c:	540025a0 	b.eq	8120 <fwp_write+0xd10>  // b.none
    7c70:	b100067f 	cmn	x19, #0x1
    7c74:	54002bc0 	b.eq	81ec <fwp_write+0xddc>  // b.none
    7c78:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7c7c:	91256021 	add	x1, x1, #0x958
    7c80:	d2800022 	mov	x2, #0x1                   	// #1
    7c84:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7c88:	f947f400 	ldr	x0, [x0, #4072]
    7c8c:	f94127e4 	ldr	x4, [sp, #584]
    7c90:	f9400003 	ldr	x3, [x0]
    7c94:	eb030084 	subs	x4, x4, x3
    7c98:	d2800003 	mov	x3, #0x0                   	// #0
    7c9c:	54ffebe0 	b.eq	7a18 <fwp_write+0x608>  // b.none
    7ca0:	f90143f7 	str	x23, [sp, #640]
    7ca4:	f90147f8 	str	x24, [sp, #648]
    7ca8:	f9014bf9 	str	x25, [sp, #656]
    7cac:	f9014ffa 	str	x26, [sp, #664]
    7cb0:	fd015be8 	str	d8, [sp, #688]
    7cb4:	fd015fe9 	str	d9, [sp, #696]
    7cb8:	97ffeafa 	bl	28a0 <__stack_chk_fail@plt>
    7cbc:	52800b63 	mov	w3, #0x5b                  	// #91
    7cc0:	91001ff5 	add	x21, sp, #0x7
    7cc4:	aa1503e1 	mov	x1, x21
    7cc8:	aa1403e0 	mov	x0, x20
    7ccc:	d2800022 	mov	x2, #0x1                   	// #1
    7cd0:	d0000036 	adrp	x22, d000 <__modti3+0x60>
    7cd4:	9127e2d6 	add	x22, x22, #0x9f8
    7cd8:	39001fe3 	strb	w3, [sp, #7]
    7cdc:	97ffee6d 	bl	3690 <buf_put>
    7ce0:	b4000273 	cbz	x19, 7d2c <fwp_write+0x91c>
    7ce4:	f9400661 	ldr	x1, [x19, #8]
    7ce8:	aa1403e0 	mov	x0, x20
    7cec:	f9401f82 	ldr	x2, [x28, #56]
    7cf0:	52800003 	mov	w3, #0x0                   	// #0
    7cf4:	97fffdc7 	bl	7410 <fwp_write>
    7cf8:	f9400a73 	ldr	x19, [x19, #16]
    7cfc:	b4000193 	cbz	x19, 7d2c <fwp_write+0x91c>
    7d00:	aa1603e1 	mov	x1, x22
    7d04:	aa1403e0 	mov	x0, x20
    7d08:	d2800042 	mov	x2, #0x2                   	// #2
    7d0c:	97ffee61 	bl	3690 <buf_put>
    7d10:	f9400661 	ldr	x1, [x19, #8]
    7d14:	aa1403e0 	mov	x0, x20
    7d18:	f9401f82 	ldr	x2, [x28, #56]
    7d1c:	52800003 	mov	w3, #0x0                   	// #0
    7d20:	97fffdbc 	bl	7410 <fwp_write>
    7d24:	f9400a73 	ldr	x19, [x19, #16]
    7d28:	b5fffed3 	cbnz	x19, 7d00 <fwp_write+0x8f0>
    7d2c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7d30:	aa1503e1 	mov	x1, x21
    7d34:	aa1403e0 	mov	x0, x20
    7d38:	d2800022 	mov	x2, #0x1                   	// #1
    7d3c:	39001fe3 	strb	w3, [sp, #7]
    7d40:	17fffddb 	b	74ac <fwp_write+0x9c>
    7d44:	aa1403e0 	mov	x0, x20
    7d48:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7d4c:	d28000c2 	mov	x2, #0x6                   	// #6
    7d50:	9127a021 	add	x1, x1, #0x9e8
    7d54:	97ffee4f 	bl	3690 <buf_put>
    7d58:	f9400260 	ldr	x0, [x19]
    7d5c:	b40004c0 	cbz	x0, 7df4 <fwp_write+0x9e4>
    7d60:	910123f5 	add	x21, sp, #0x48
    7d64:	91002276 	add	x22, x19, #0x8
    7d68:	f90143f7 	str	x23, [sp, #640]
    7d6c:	d2800017 	mov	x23, #0x0                   	// #0
    7d70:	f90147f8 	str	x24, [sp, #648]
    7d74:	d0000038 	adrp	x24, d000 <__modti3+0x60>
    7d78:	9127c318 	add	x24, x24, #0x9f0
    7d7c:	f9014bf9 	str	x25, [sp, #656]
    7d80:	d0000039 	adrp	x25, d000 <__modti3+0x60>
    7d84:	9127e339 	add	x25, x25, #0x9f8
    7d88:	f9014ffa 	str	x26, [sp, #664]
    7d8c:	14000005 	b	7da0 <fwp_write+0x990>
    7d90:	aa1903e1 	mov	x1, x25
    7d94:	aa1403e0 	mov	x0, x20
    7d98:	d2800042 	mov	x2, #0x2                   	// #2
    7d9c:	97ffee3d 	bl	3690 <buf_put>
    7da0:	38776ac5 	ldrb	w5, [x22, x23]
    7da4:	d2804003 	mov	x3, #0x200                 	// #512
    7da8:	aa1803e4 	mov	x4, x24
    7dac:	aa0303e1 	mov	x1, x3
    7db0:	52800042 	mov	w2, #0x2                   	// #2
    7db4:	aa1503e0 	mov	x0, x21
    7db8:	910006f7 	add	x23, x23, #0x1
    7dbc:	97ffea95 	bl	2810 <__snprintf_chk@plt>
    7dc0:	aa1503e0 	mov	x0, x21
    7dc4:	97ffea5b 	bl	2730 <strlen@plt>
    7dc8:	aa1503e1 	mov	x1, x21
    7dcc:	aa0003e2 	mov	x2, x0
    7dd0:	aa1403e0 	mov	x0, x20
    7dd4:	97ffee2f 	bl	3690 <buf_put>
    7dd8:	f9400260 	ldr	x0, [x19]
    7ddc:	eb17001f 	cmp	x0, x23
    7de0:	54fffd88 	b.hi	7d90 <fwp_write+0x980>  // b.pmore
    7de4:	f94143f7 	ldr	x23, [sp, #640]
    7de8:	f94147f8 	ldr	x24, [sp, #648]
    7dec:	f9414bf9 	ldr	x25, [sp, #656]
    7df0:	f9414ffa 	ldr	x26, [sp, #664]
    7df4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7df8:	aa1403e0 	mov	x0, x20
    7dfc:	91001fe1 	add	x1, sp, #0x7
    7e00:	d2800022 	mov	x2, #0x1                   	// #1
    7e04:	39001fe3 	strb	w3, [sp, #7]
    7e08:	17fffda9 	b	74ac <fwp_write+0x9c>
    7e0c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7e10:	17fffe44 	b	7720 <fwp_write+0x310>
    7e14:	f10002ff 	cmp	x23, #0x0
    7e18:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7e1c:	71002c3f 	cmp	w1, #0xb
    7e20:	54ffebc0 	b.eq	7b98 <fwp_write+0x788>  // b.none
    7e24:	aa1303e2 	mov	x2, x19
    7e28:	aa1703e1 	mov	x1, x23
    7e2c:	aa1403e0 	mov	x0, x20
    7e30:	52800003 	mov	w3, #0x0                   	// #0
    7e34:	97fffd77 	bl	7410 <fwp_write>
    7e38:	17ffff6a 	b	7be0 <fwp_write+0x7d0>
    7e3c:	aa1403e0 	mov	x0, x20
    7e40:	91001fe1 	add	x1, sp, #0x7
    7e44:	52800fa3 	mov	w3, #0x7d                  	// #125
    7e48:	d2800022 	mov	x2, #0x1                   	// #1
    7e4c:	17fffe38 	b	772c <fwp_write+0x31c>
    7e50:	a9400281 	ldp	x1, x0, [x20]
    7e54:	91000800 	add	x0, x0, #0x2
    7e58:	8b160000 	add	x0, x0, x22
    7e5c:	f9000680 	str	x0, [x20, #8]
    7e60:	3820683f 	strb	wzr, [x1, x0]
    7e64:	f9413bf5 	ldr	x21, [sp, #624]
    7e68:	f9413ff6 	ldr	x22, [sp, #632]
    7e6c:	f94153fb 	ldr	x27, [sp, #672]
    7e70:	f94157fc 	ldr	x28, [sp, #680]
    7e74:	17fffd93 	b	74c0 <fwp_write+0xb0>
    7e78:	f9400f80 	ldr	x0, [x28, #24]
    7e7c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7e80:	aa1b03e0 	mov	x0, x27
    7e84:	97ffea2b 	bl	2730 <strlen@plt>
    7e88:	aa1b03e1 	mov	x1, x27
    7e8c:	aa0003e2 	mov	x2, x0
    7e90:	aa1403e0 	mov	x0, x20
    7e94:	97ffedff 	bl	3690 <buf_put>
    7e98:	aa1903e1 	mov	x1, x25
    7e9c:	aa1403e0 	mov	x0, x20
    7ea0:	d2800062 	mov	x2, #0x3                   	// #3
    7ea4:	97ffedfb 	bl	3690 <buf_put>
    7ea8:	17fffe10 	b	76e8 <fwp_write+0x2d8>
    7eac:	aa1a03e1 	mov	x1, x26
    7eb0:	aa1403e0 	mov	x0, x20
    7eb4:	d2800042 	mov	x2, #0x2                   	// #2
    7eb8:	97ffedf6 	bl	3690 <buf_put>
    7ebc:	17fffe09 	b	76e0 <fwp_write+0x2d0>
    7ec0:	f9400660 	ldr	x0, [x19, #8]
    7ec4:	b4fffb00 	cbz	x0, 7e24 <fwp_write+0xa14>
    7ec8:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7ecc:	91284021 	add	x1, x1, #0xa10
    7ed0:	97ffea94 	bl	2920 <strcmp@plt>
    7ed4:	7100001f 	cmp	w0, #0x0
    7ed8:	1a9f07e0 	cset	w0, ne	// ne = any
    7edc:	17ffff2f 	b	7b98 <fwp_write+0x788>
    7ee0:	aa1403e0 	mov	x0, x20
    7ee4:	d2800042 	mov	x2, #0x2                   	// #2
    7ee8:	d0000021 	adrp	x1, d000 <__modti3+0x60>
    7eec:	91282021 	add	x1, x1, #0xa08
    7ef0:	97ffede8 	bl	3690 <buf_put>
    7ef4:	91004261 	add	x1, x19, #0x10
    7ef8:	aa1403e0 	mov	x0, x20
    7efc:	f9402382 	ldr	x2, [x28, #64]
    7f00:	52800003 	mov	w3, #0x0                   	// #0
    7f04:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7f08:	97fffd42 	bl	7410 <fwp_write>
    7f0c:	17fffd9c 	b	757c <fwp_write+0x16c>
    7f10:	1e22c109 	fcvt	d9, s8
    7f14:	910123f5 	add	x21, sp, #0x48
    7f18:	52800033 	mov	w19, #0x1                   	// #1
    7f1c:	d503201f 	nop
    7f20:	1e604120 	fmov	d0, d9
    7f24:	2a1303e1 	mov	w1, w19
    7f28:	aa1503e0 	mov	x0, x21
    7f2c:	97ffef1a 	bl	3b94 <fwp_format_g.constprop.0>
    7f30:	aa1503e0 	mov	x0, x21
    7f34:	d2800001 	mov	x1, #0x0                   	// #0
    7f38:	97ffea86 	bl	2950 <strtof@plt>
    7f3c:	1e202100 	fcmp	s8, s0
    7f40:	54ffdb60 	b.eq	7aac <fwp_write+0x69c>  // b.none
    7f44:	11000673 	add	w19, w19, #0x1
    7f48:	71002a7f 	cmp	w19, #0xa
    7f4c:	54fffea1 	b.ne	7f20 <fwp_write+0xb10>  // b.any
    7f50:	1e604120 	fmov	d0, d9
    7f54:	aa1503e0 	mov	x0, x21
    7f58:	52800121 	mov	w1, #0x9                   	// #9
    7f5c:	97ffef0e 	bl	3b94 <fwp_format_g.constprop.0>
    7f60:	17fffed3 	b	7aac <fwp_write+0x69c>
    7f64:	d37ef6a1 	lsl	x1, x21, #2
    7f68:	b7f81563 	tbnz	x3, #63, 8214 <fwp_write+0xe04>
    7f6c:	91002263 	add	x3, x19, #0x8
    7f70:	8b010061 	add	x1, x3, x1
    7f74:	b9400023 	ldr	w3, [x1]
    7f78:	7100081f 	cmp	w0, #0x2
    7f7c:	2a0303e1 	mov	w1, w3
    7f80:	93407c63 	sxtw	x3, w3
    7f84:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f88:	17fffe5a 	b	78f0 <fwp_write+0x4e0>
    7f8c:	d37ffaa1 	lsl	x1, x21, #1
    7f90:	b7f81363 	tbnz	x3, #63, 81fc <fwp_write+0xdec>
    7f94:	91002263 	add	x3, x19, #0x8
    7f98:	8b010061 	add	x1, x3, x1
    7f9c:	79400021 	ldrh	w1, [x1]
    7fa0:	7100041f 	cmp	w0, #0x1
    7fa4:	93403c23 	sxth	x3, w1
    7fa8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7fac:	17fffe51 	b	78f0 <fwp_write+0x4e0>
    7fb0:	52800443 	mov	w3, #0x22                  	// #34
    7fb4:	91001ff5 	add	x21, sp, #0x7
    7fb8:	91002273 	add	x19, x19, #0x8
    7fbc:	aa1503e1 	mov	x1, x21
    7fc0:	aa1403e0 	mov	x0, x20
    7fc4:	d2800022 	mov	x2, #0x1                   	// #1
    7fc8:	39001fe3 	strb	w3, [sp, #7]
    7fcc:	f90143f7 	str	x23, [sp, #640]
    7fd0:	8b160277 	add	x23, x19, x22
    7fd4:	f90147f8 	str	x24, [sp, #648]
    7fd8:	97ffedae 	bl	3690 <buf_put>
    7fdc:	b4000696 	cbz	x22, 80ac <fwp_write+0xc9c>
    7fe0:	d0000038 	adrp	x24, d000 <__modti3+0x60>
    7fe4:	9126e318 	add	x24, x24, #0x9b8
    7fe8:	f9014bf9 	str	x25, [sp, #656]
    7fec:	d0000039 	adrp	x25, d000 <__modti3+0x60>
    7ff0:	91276339 	add	x25, x25, #0x9d8
    7ff4:	f9014ffa 	str	x26, [sp, #664]
    7ff8:	1400000d 	b	802c <fwp_write+0xc1c>
    7ffc:	710024bf 	cmp	w5, #0x9
    8000:	54000460 	b.eq	808c <fwp_write+0xc7c>  // b.none
    8004:	710028bf 	cmp	w5, #0xa
    8008:	54000a61 	b.ne	8154 <fwp_write+0xd44>  // b.any
    800c:	b0000021 	adrp	x1, d000 <__modti3+0x60>
    8010:	aa1403e0 	mov	x0, x20
    8014:	91272021 	add	x1, x1, #0x9c8
    8018:	d2800042 	mov	x2, #0x2                   	// #2
    801c:	97ffed9d 	bl	3690 <buf_put>
    8020:	91000673 	add	x19, x19, #0x1
    8024:	eb17027f 	cmp	x19, x23
    8028:	540003e0 	b.eq	80a4 <fwp_write+0xc94>  // b.none
    802c:	39400265 	ldrb	w5, [x19]
    8030:	710034bf 	cmp	w5, #0xd
    8034:	54000180 	b.eq	8064 <fwp_write+0xc54>  // b.none
    8038:	54fffe29 	b.ls	7ffc <fwp_write+0xbec>  // b.plast
    803c:	710088bf 	cmp	w5, #0x22
    8040:	540001c0 	b.eq	8078 <fwp_write+0xc68>  // b.none
    8044:	710170bf 	cmp	w5, #0x5c
    8048:	54000741 	b.ne	8130 <fwp_write+0xd20>  // b.any
    804c:	aa1403e0 	mov	x0, x20
    8050:	b0000021 	adrp	x1, d000 <__modti3+0x60>
    8054:	d2800042 	mov	x2, #0x2                   	// #2
    8058:	91270021 	add	x1, x1, #0x9c0
    805c:	97ffed8d 	bl	3690 <buf_put>
    8060:	17fffff0 	b	8020 <fwp_write+0xc10>
    8064:	aa1903e1 	mov	x1, x25
    8068:	aa1403e0 	mov	x0, x20
    806c:	d2800042 	mov	x2, #0x2                   	// #2
    8070:	97ffed88 	bl	3690 <buf_put>
    8074:	17ffffeb 	b	8020 <fwp_write+0xc10>
    8078:	aa1803e1 	mov	x1, x24
    807c:	aa1403e0 	mov	x0, x20
    8080:	d2800042 	mov	x2, #0x2                   	// #2
    8084:	97ffed83 	bl	3690 <buf_put>
    8088:	17ffffe6 	b	8020 <fwp_write+0xc10>
    808c:	aa1403e0 	mov	x0, x20
    8090:	b0000021 	adrp	x1, d000 <__modti3+0x60>
    8094:	d2800042 	mov	x2, #0x2                   	// #2
    8098:	91274021 	add	x1, x1, #0x9d0
    809c:	97ffed7d 	bl	3690 <buf_put>
    80a0:	17ffffe0 	b	8020 <fwp_write+0xc10>
    80a4:	f9414bf9 	ldr	x25, [sp, #656]
    80a8:	f9414ffa 	ldr	x26, [sp, #664]
    80ac:	aa1503e1 	mov	x1, x21
    80b0:	aa1403e0 	mov	x0, x20
    80b4:	52800443 	mov	w3, #0x22                  	// #34
    80b8:	17fffd9c 	b	7728 <fwp_write+0x318>
    80bc:	7100103f 	cmp	w1, #0x4
    80c0:	54ffeb21 	b.ne	7e24 <fwp_write+0xa14>  // b.any
    80c4:	f94006e0 	ldr	x0, [x23, #8]
    80c8:	d37ffc00 	lsr	x0, x0, #63
    80cc:	17fffeb3 	b	7b98 <fwp_write+0x788>
    80d0:	710002ff 	cmp	w23, #0x0
    80d4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    80d8:	17fffeb0 	b	7b98 <fwp_write+0x788>
    80dc:	528005a1 	mov	w1, #0x2d                  	// #45
    80e0:	eb0203e2 	negs	x2, x2
    80e4:	da0303e3 	ngc	x3, x3
    80e8:	910127e0 	add	x0, sp, #0x49
    80ec:	910123f5 	add	x21, sp, #0x48
    80f0:	390123e1 	strb	w1, [sp, #72]
    80f4:	97ffeb4b 	bl	2e20 <fwp_fmt_u128>
    80f8:	17fffe18 	b	7958 <fwp_write+0x548>
    80fc:	d37ceea1 	lsl	x1, x21, #4
    8100:	b7f810a3 	tbnz	x3, #63, 8314 <fwp_write+0xf04>
    8104:	91002260 	add	x0, x19, #0x8
    8108:	8b010001 	add	x1, x0, x1
    810c:	17fffdf9 	b	78f0 <fwp_write+0x4e0>
    8110:	f9400a61 	ldr	x1, [x19, #16]
    8114:	8b010000 	add	x0, x0, x1
    8118:	f9400001 	ldr	x1, [x0]
    811c:	17fffdf5 	b	78f0 <fwp_write+0x4e0>
    8120:	b0000021 	adrp	x1, d000 <__modti3+0x60>
    8124:	d2800042 	mov	x2, #0x2                   	// #2
    8128:	91258021 	add	x1, x1, #0x960
    812c:	17fffed6 	b	7c84 <fwp_write+0x874>
    8130:	7101fcbf 	cmp	w5, #0x7f
    8134:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8138:	540000e9 	b.ls	8154 <fwp_write+0xd44>  // b.plast
    813c:	aa1503e1 	mov	x1, x21
    8140:	aa1403e0 	mov	x0, x20
    8144:	d2800022 	mov	x2, #0x1                   	// #1
    8148:	39001fe5 	strb	w5, [sp, #7]
    814c:	97ffed51 	bl	3690 <buf_put>
    8150:	17ffffb4 	b	8020 <fwp_write+0xc10>
    8154:	d2800203 	mov	x3, #0x10                  	// #16
    8158:	b0000024 	adrp	x4, d000 <__modti3+0x60>
    815c:	aa0303e1 	mov	x1, x3
    8160:	91278084 	add	x4, x4, #0x9e0
    8164:	910123f6 	add	x22, sp, #0x48
    8168:	52800042 	mov	w2, #0x2                   	// #2
    816c:	aa1603e0 	mov	x0, x22
    8170:	97ffe9a8 	bl	2810 <__snprintf_chk@plt>
    8174:	aa1603e0 	mov	x0, x22
    8178:	97ffe96e 	bl	2730 <strlen@plt>
    817c:	aa1603e1 	mov	x1, x22
    8180:	aa0003e2 	mov	x2, x0
    8184:	aa1403e0 	mov	x0, x20
    8188:	97ffed42 	bl	3690 <buf_put>
    818c:	17ffffa5 	b	8020 <fwp_write+0xc10>
    8190:	1e604100 	fmov	d0, d8
    8194:	aa1503e0 	mov	x0, x21
    8198:	52800221 	mov	w1, #0x11                  	// #17
    819c:	97ffee7e 	bl	3b94 <fwp_format_g.constprop.0>
    81a0:	17fffe43 	b	7aac <fwp_write+0x69c>
    81a4:	b9401040 	ldr	w0, [x2, #16]
    81a8:	350003c0 	cbnz	w0, 8220 <fwp_write+0xe10>
    81ac:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    81b0:	f947f400 	ldr	x0, [x0, #4072]
    81b4:	f94127e2 	ldr	x2, [sp, #584]
    81b8:	f9400001 	ldr	x1, [x0]
    81bc:	eb010042 	subs	x2, x2, x1
    81c0:	d2800001 	mov	x1, #0x0                   	// #0
    81c4:	54ffd721 	b.ne	7ca8 <fwp_write+0x898>  // b.any
    81c8:	f9413bf5 	ldr	x21, [sp, #624]
    81cc:	b0000021 	adrp	x1, d000 <__modti3+0x60>
    81d0:	f9413ff6 	ldr	x22, [sp, #632]
    81d4:	aa1403e0 	mov	x0, x20
    81d8:	f94143f7 	ldr	x23, [sp, #640]
    81dc:	9128c021 	add	x1, x1, #0xa30
    81e0:	f94147f8 	ldr	x24, [sp, #648]
    81e4:	d2800042 	mov	x2, #0x2                   	// #2
    81e8:	17fffd0e 	b	7620 <fwp_write+0x210>
    81ec:	b0000021 	adrp	x1, d000 <__modti3+0x60>
    81f0:	d2800042 	mov	x2, #0x2                   	// #2
    81f4:	9125a021 	add	x1, x1, #0x968
    81f8:	17fffea3 	b	7c84 <fwp_write+0x874>
    81fc:	f9400a63 	ldr	x3, [x19, #16]
    8200:	8b030021 	add	x1, x1, x3
    8204:	17ffff66 	b	7f9c <fwp_write+0xb8c>
    8208:	f9400a61 	ldr	x1, [x19, #16]
    820c:	8b0102a1 	add	x1, x21, x1
    8210:	17fffdb3 	b	78dc <fwp_write+0x4cc>
    8214:	f9400a63 	ldr	x3, [x19, #16]
    8218:	8b030021 	add	x1, x1, x3
    821c:	17ffff56 	b	7f74 <fwp_write+0xb64>
    8220:	b9404840 	ldr	w0, [x2, #72]
    8224:	91001ff5 	add	x21, sp, #0x7
    8228:	34ffa360 	cbz	w0, 7694 <fwp_write+0x284>
    822c:	52800503 	mov	w3, #0x28                  	// #40
    8230:	aa1403e0 	mov	x0, x20
    8234:	aa1503e1 	mov	x1, x21
    8238:	d2800022 	mov	x2, #0x1                   	// #1
    823c:	39001fe3 	strb	w3, [sp, #7]
    8240:	97ffed14 	bl	3690 <buf_put>
    8244:	b9401380 	ldr	w0, [x28, #16]
    8248:	52800038 	mov	w24, #0x1                   	// #1
    824c:	7100001f 	cmp	w0, #0x0
    8250:	54ffa36c 	b.gt	76bc <fwp_write+0x2ac>
    8254:	17fffd32 	b	771c <fwp_write+0x30c>
    8258:	f9014bf9 	str	x25, [sp, #656]
    825c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe8e0>
    8260:	f9014ffa 	str	x26, [sp, #664]
    8264:	f9400676 	ldr	x22, [x19, #8]
    8268:	910ac333 	add	x19, x25, #0x2b0
    826c:	91002273 	add	x19, x19, #0x8
    8270:	937ffed8 	asr	x24, x22, #63
    8274:	aa1802c0 	orr	x0, x22, x24
    8278:	b5000320 	cbnz	x0, 82dc <fwp_write+0xecc>
    827c:	110006b5 	add	w21, w21, #0x1
    8280:	710016bf 	cmp	w21, #0x5
    8284:	54ffffc1 	b.ne	827c <fwp_write+0xe6c>  // b.any
    8288:	b7f80578 	tbnz	x24, #63, 8334 <fwp_write+0xf24>
    828c:	910023f3 	add	x19, sp, #0x8
    8290:	aa1603e2 	mov	x2, x22
    8294:	aa1303e0 	mov	x0, x19
    8298:	d2800003 	mov	x3, #0x0                   	// #0
    829c:	97ffeae1 	bl	2e20 <fwp_fmt_u128>
    82a0:	910123f5 	add	x21, sp, #0x48
    82a4:	b0000023 	adrp	x3, d000 <__modti3+0x60>
    82a8:	aa1303e4 	mov	x4, x19
    82ac:	aa1503e0 	mov	x0, x21
    82b0:	9128a063 	add	x3, x3, #0xa28
    82b4:	d2804002 	mov	x2, #0x200                 	// #512
    82b8:	52800041 	mov	w1, #0x2                   	// #2
    82bc:	97ffe921 	bl	2740 <__sprintf_chk@plt>
    82c0:	aa1503e0 	mov	x0, x21
    82c4:	97ffe91b 	bl	2730 <strlen@plt>
    82c8:	aa1503e1 	mov	x1, x21
    82cc:	aa0003e2 	mov	x2, x0
    82d0:	aa1403e0 	mov	x0, x20
    82d4:	97ffecef 	bl	3690 <buf_put>
    82d8:	17fffe47 	b	7bf4 <fwp_write+0x7e4>
    82dc:	f9400277 	ldr	x23, [x19]
    82e0:	aa1603e0 	mov	x0, x22
    82e4:	aa1803e1 	mov	x1, x24
    82e8:	aa1703e2 	mov	x2, x23
    82ec:	937ffefa 	asr	x26, x23, #63
    82f0:	aa1a03e3 	mov	x3, x26
    82f4:	9400132b 	bl	cfa0 <__modti3>
    82f8:	aa010000 	orr	x0, x0, x1
    82fc:	b40002c0 	cbz	x0, 8354 <fwp_write+0xf44>
    8300:	110006b5 	add	w21, w21, #0x1
    8304:	91004273 	add	x19, x19, #0x10
    8308:	710016bf 	cmp	w21, #0x5
    830c:	54fffe81 	b.ne	82dc <fwp_write+0xecc>  // b.any
    8310:	17ffffde 	b	8288 <fwp_write+0xe78>
    8314:	f9400a60 	ldr	x0, [x19, #16]
    8318:	8b000021 	add	x1, x1, x0
    831c:	17fffd75 	b	78f0 <fwp_write+0x4e0>
    8320:	528c29c0 	mov	w0, #0x614e                	// #24910
    8324:	910123f5 	add	x21, sp, #0x48
    8328:	72a009c0 	movk	w0, #0x4e, lsl #16
    832c:	b9004be0 	str	w0, [sp, #72]
    8330:	17fffda2 	b	79b8 <fwp_write+0x5a8>
    8334:	528005a1 	mov	w1, #0x2d                  	// #45
    8338:	eb1603e2 	negs	x2, x22
    833c:	da1803e3 	ngc	x3, x24
    8340:	910027e0 	add	x0, sp, #0x9
    8344:	910023f3 	add	x19, sp, #0x8
    8348:	390023e1 	strb	w1, [sp, #8]
    834c:	97ffeab5 	bl	2e20 <fwp_fmt_u128>
    8350:	17ffffd4 	b	82a0 <fwp_write+0xe90>
    8354:	aa1703e2 	mov	x2, x23
    8358:	aa1a03e3 	mov	x3, x26
    835c:	aa1603e0 	mov	x0, x22
    8360:	aa1803e1 	mov	x1, x24
    8364:	9400122f 	bl	cc20 <__divti3>
    8368:	aa0003e2 	mov	x2, x0
    836c:	aa0103e3 	mov	x3, x1
    8370:	b7f80201 	tbnz	x1, #63, 83b0 <fwp_write+0xfa0>
    8374:	910023f3 	add	x19, sp, #0x8
    8378:	aa1303e0 	mov	x0, x19
    837c:	97ffeaa9 	bl	2e20 <fwp_fmt_u128>
    8380:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8384:	910ac339 	add	x25, x25, #0x2b0
    8388:	910123f5 	add	x21, sp, #0x48
    838c:	aa1303e4 	mov	x4, x19
    8390:	aa1503e0 	mov	x0, x21
    8394:	b0000023 	adrp	x3, d000 <__modti3+0x60>
    8398:	f8616b25 	ldr	x5, [x25, x1]
    839c:	91288063 	add	x3, x3, #0xa20
    83a0:	d2804002 	mov	x2, #0x200                 	// #512
    83a4:	52800041 	mov	w1, #0x2                   	// #2
    83a8:	97ffe8e6 	bl	2740 <__sprintf_chk@plt>
    83ac:	17ffffc5 	b	82c0 <fwp_write+0xeb0>
    83b0:	528005a4 	mov	w4, #0x2d                  	// #45
    83b4:	eb0003e2 	negs	x2, x0
    83b8:	da0103e3 	ngc	x3, x1
    83bc:	910027e0 	add	x0, sp, #0x9
    83c0:	910023f3 	add	x19, sp, #0x8
    83c4:	390023e4 	strb	w4, [sp, #8]
    83c8:	97ffea96 	bl	2e20 <fwp_fmt_u128>
    83cc:	17ffffed 	b	8380 <fwp_write+0xf70>
    83d0:	f9013bf5 	str	x21, [sp, #624]
    83d4:	f9013ff6 	str	x22, [sp, #632]
    83d8:	f90143f7 	str	x23, [sp, #640]
    83dc:	f90147f8 	str	x24, [sp, #648]
    83e0:	f9014bf9 	str	x25, [sp, #656]
    83e4:	f9014ffa 	str	x26, [sp, #664]
    83e8:	f90153fb 	str	x27, [sp, #672]
    83ec:	f90157fc 	str	x28, [sp, #680]
    83f0:	fd015be8 	str	d8, [sp, #688]
    83f4:	fd015fe9 	str	d9, [sp, #696]
    83f8:	97ffe92a 	bl	28a0 <__stack_chk_fail@plt>
    83fc:	d503201f 	nop

0000000000008400 <fwp_hof0.constprop.0>:
    8400:	d10543ff 	sub	sp, sp, #0x150
    8404:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    8408:	f947f442 	ldr	x2, [x2, #4072]
    840c:	a90e7bfd 	stp	x29, x30, [sp, #224]
    8410:	910383fd 	add	x29, sp, #0xe0
    8414:	f90023e0 	str	x0, [sp, #64]
    8418:	f9400040 	ldr	x0, [x2]
    841c:	f9006fe0 	str	x0, [sp, #216]
    8420:	d2800000 	mov	x0, #0x0                   	// #0
    8424:	f90027e1 	str	x1, [sp, #72]
    8428:	b400a5a1 	cbz	x1, 98dc <fwp_hof0.constprop.0+0x14dc>
    842c:	900000c0 	adrp	x0, 20000 <__data_start>
    8430:	91004000 	add	x0, x0, #0x10
    8434:	91008000 	add	x0, x0, #0x20
    8438:	f90017e0 	str	x0, [sp, #40]
    843c:	910163e0 	add	x0, sp, #0x58
    8440:	f9000fe0 	str	x0, [sp, #24]
    8444:	910183e0 	add	x0, sp, #0x60
    8448:	f90013e0 	str	x0, [sp, #32]
    844c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xcc0>
    8450:	fd00a3e8 	str	d8, [sp, #320]
    8454:	a90f53f3 	stp	x19, x20, [sp, #240]
    8458:	b0000394 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    845c:	fd419808 	ldr	d8, [x0, #816]
    8460:	a9105bf5 	stp	x21, x22, [sp, #256]
    8464:	a91163f7 	stp	x23, x24, [sp, #272]
    8468:	a9126bf9 	stp	x25, x26, [sp, #288]
    846c:	a91373fb 	stp	x27, x28, [sp, #304]
    8470:	9118c282 	add	x2, x20, #0x630
    8474:	f94023e0 	ldr	x0, [sp, #64]
    8478:	f949ec43 	ldr	x3, [x2, #5080]
    847c:	f949d841 	ldr	x1, [x2, #5040]
    8480:	d370bc63 	lsl	x3, x3, #16
    8484:	cb010004 	sub	x4, x0, x1
    8488:	eb03009f 	cmp	x4, x3
    848c:	540004c2 	b.cs	8524 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    8490:	d350fc80 	lsr	x0, x4, #16
    8494:	f949fc46 	ldr	x6, [x2, #5112]
    8498:	8b000800 	add	x0, x0, x0, lsl #2
    849c:	d37df002 	lsl	x2, x0, #3
    84a0:	8b0200c5 	add	x5, x6, x2
    84a4:	f94010a0 	ldr	x0, [x5, #32]
    84a8:	b40003e0 	cbz	x0, 8524 <fwp_hof0.constprop.0+0x124>
    84ac:	386268c2 	ldrb	w2, [x6, x2]
    84b0:	7100085f 	cmp	w2, #0x2
    84b4:	5400bea0 	b.eq	9c88 <fwp_hof0.constprop.0+0x1888>  // b.none
    84b8:	7100045f 	cmp	w2, #0x1
    84bc:	54000341 	b.ne	8524 <fwp_hof0.constprop.0+0x124>  // b.any
    84c0:	92403c82 	and	x2, x4, #0xffff
    84c4:	294310a6 	ldp	w6, w4, [x5, #24]
    84c8:	9b067c42 	mul	x2, x2, x6
    84cc:	d360fc42 	lsr	x2, x2, #32
    84d0:	eb04005f 	cmp	x2, x4
    84d4:	54000282 	b.cs	8524 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    84d8:	8b020000 	add	x0, x0, x2
    84dc:	39400002 	ldrb	w2, [x0]
    84e0:	34000222 	cbz	w2, 8524 <fwp_hof0.constprop.0+0x124>
    84e4:	900000c1 	adrp	x1, 20000 <__data_start>
    84e8:	91014021 	add	x1, x1, #0x50
    84ec:	b9413023 	ldr	w3, [x1, #304]
    84f0:	34000083 	cbz	w3, 8500 <fwp_hof0.constprop.0+0x100>
    84f4:	f940ac23 	ldr	x3, [x1, #344]
    84f8:	91000463 	add	x3, x3, #0x1
    84fc:	f900ac23 	str	x3, [x1, #344]
    8500:	7103f45f 	cmp	w2, #0xfd
    8504:	5400cbe8 	b.hi	9e80 <fwp_hof0.constprop.0+0x1a80>  // b.pmore
    8508:	9118c281 	add	x1, x20, #0x630
    850c:	11000442 	add	w2, w2, #0x1
    8510:	39000002 	strb	w2, [x0]
    8514:	aa0103e0 	mov	x0, x1
    8518:	f949d821 	ldr	x1, [x1, #5040]
    851c:	f949ec03 	ldr	x3, [x0, #5080]
    8520:	d370bc63 	lsl	x3, x3, #16
    8524:	f94023f5 	ldr	x21, [sp, #64]
    8528:	d28018c0 	mov	x0, #0xc6                  	// #198
    852c:	f90007e0 	str	x0, [sp, #8]
    8530:	900000c0 	adrp	x0, 20000 <__data_start>
    8534:	91014002 	add	x2, x0, #0x50
    8538:	f94017e0 	ldr	x0, [sp, #40]
    853c:	12800004 	mov	w4, #0xffffffff            	// #-1
    8540:	b9005be4 	str	w4, [sp, #88]
    8544:	cb010001 	sub	x1, x0, x1
    8548:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x10>
    854c:	910e0000 	add	x0, x0, #0x380
    8550:	f90037e0 	str	x0, [sp, #104]
    8554:	f941c840 	ldr	x0, [x2, #912]
    8558:	f90033e0 	str	x0, [sp, #96]
    855c:	f9400fe0 	ldr	x0, [sp, #24]
    8560:	f9003be0 	str	x0, [sp, #112]
    8564:	f94013e0 	ldr	x0, [sp, #32]
    8568:	f901c840 	str	x0, [x2, #912]
    856c:	eb03003f 	cmp	x1, x3
    8570:	54000882 	b.cs	8680 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8574:	9118c282 	add	x2, x20, #0x630
    8578:	d350fc20 	lsr	x0, x1, #16
    857c:	8b000800 	add	x0, x0, x0, lsl #2
    8580:	f949fc44 	ldr	x4, [x2, #5112]
    8584:	d37df003 	lsl	x3, x0, #3
    8588:	8b030082 	add	x2, x4, x3
    858c:	f9401053 	ldr	x19, [x2, #32]
    8590:	b4000793 	cbz	x19, 8680 <fwp_hof0.constprop.0+0x280>
    8594:	38636880 	ldrb	w0, [x4, x3]
    8598:	7100081f 	cmp	w0, #0x2
    859c:	5400a5a0 	b.eq	9a50 <fwp_hof0.constprop.0+0x1650>  // b.none
    85a0:	7100041f 	cmp	w0, #0x1
    85a4:	540006e1 	b.ne	8680 <fwp_hof0.constprop.0+0x280>  // b.any
    85a8:	29430c44 	ldp	w4, w3, [x2, #24]
    85ac:	92403c20 	and	x0, x1, #0xffff
    85b0:	9b047c00 	mul	x0, x0, x4
    85b4:	d360fc00 	lsr	x0, x0, #32
    85b8:	eb03001f 	cmp	x0, x3
    85bc:	54000382 	b.cs	862c <fwp_hof0.constprop.0+0x22c>  // b.hs, b.nlast
    85c0:	8b000260 	add	x0, x19, x0
    85c4:	39400003 	ldrb	w3, [x0]
    85c8:	34000323 	cbz	w3, 862c <fwp_hof0.constprop.0+0x22c>
    85cc:	900000c1 	adrp	x1, 20000 <__data_start>
    85d0:	91014021 	add	x1, x1, #0x50
    85d4:	b9413022 	ldr	w2, [x1, #304]
    85d8:	34000082 	cbz	w2, 85e8 <fwp_hof0.constprop.0+0x1e8>
    85dc:	f940ac22 	ldr	x2, [x1, #344]
    85e0:	91000442 	add	x2, x2, #0x1
    85e4:	f900ac22 	str	x2, [x1, #344]
    85e8:	7103f47f 	cmp	w3, #0xfd
    85ec:	5400c0a8 	b.hi	9e00 <fwp_hof0.constprop.0+0x1a00>  // b.pmore
    85f0:	11000463 	add	w3, w3, #0x1
    85f4:	39000003 	strb	w3, [x0]
    85f8:	9118c280 	add	x0, x20, #0x630
    85fc:	f94017e3 	ldr	x3, [sp, #40]
    8600:	f949d801 	ldr	x1, [x0, #5040]
    8604:	f949ec02 	ldr	x2, [x0, #5080]
    8608:	cb010061 	sub	x1, x3, x1
    860c:	eb02403f 	cmp	x1, x2, lsl #16
    8610:	54000382 	b.cs	8680 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8614:	f949fc00 	ldr	x0, [x0, #5112]
    8618:	d350fc22 	lsr	x2, x1, #16
    861c:	8b020842 	add	x2, x2, x2, lsl #2
    8620:	8b020c02 	add	x2, x0, x2, lsl #3
    8624:	f9401053 	ldr	x19, [x2, #32]
    8628:	b40002d3 	cbz	x19, 8680 <fwp_hof0.constprop.0+0x280>
    862c:	39400040 	ldrb	w0, [x2]
    8630:	7100081f 	cmp	w0, #0x2
    8634:	5400a160 	b.eq	9a60 <fwp_hof0.constprop.0+0x1660>  // b.none
    8638:	7100041f 	cmp	w0, #0x1
    863c:	54000221 	b.ne	8680 <fwp_hof0.constprop.0+0x280>  // b.any
    8640:	29430043 	ldp	w3, w0, [x2, #24]
    8644:	92403c21 	and	x1, x1, #0xffff
    8648:	9b037c21 	mul	x1, x1, x3
    864c:	d360fc21 	lsr	x1, x1, #32
    8650:	eb00003f 	cmp	x1, x0
    8654:	54000162 	b.cs	8680 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8658:	8b010273 	add	x19, x19, x1
    865c:	39400261 	ldrb	w1, [x19]
    8660:	34000101 	cbz	w1, 8680 <fwp_hof0.constprop.0+0x280>
    8664:	7100043f 	cmp	w1, #0x1
    8668:	540075a0 	b.eq	951c <fwp_hof0.constprop.0+0x111c>  // b.none
    866c:	7103fc3f 	cmp	w1, #0xff
    8670:	5400bcc0 	b.eq	9e08 <fwp_hof0.constprop.0+0x1a08>  // b.none
    8674:	51000421 	sub	w1, w1, #0x1
    8678:	39000261 	strb	w1, [x19]
    867c:	d503201f 	nop
    8680:	b40075f5 	cbz	x21, 953c <fwp_hof0.constprop.0+0x113c>
    8684:	aa1503e0 	mov	x0, x21
    8688:	d2800001 	mov	x1, #0x0                   	// #0
    868c:	d503201f 	nop
    8690:	f9400800 	ldr	x0, [x0, #16]
    8694:	91000421 	add	x1, x1, #0x1
    8698:	b5ffffc0 	cbnz	x0, 8690 <fwp_hof0.constprop.0+0x290>
    869c:	aa0103f6 	mov	x22, x1
    86a0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    86a4:	eb00003f 	cmp	x1, x0
    86a8:	5400c4a8 	b.hi	9f3c <fwp_hof0.constprop.0+0x1b3c>  // b.pmore
    86ac:	900000c0 	adrp	x0, 20000 <__data_start>
    86b0:	91014013 	add	x19, x0, #0x50
    86b4:	b943c660 	ldr	w0, [x19, #964]
    86b8:	340074c0 	cbz	w0, 9550 <fwp_hof0.constprop.0+0x1150>
    86bc:	900000c0 	adrp	x0, 20000 <__data_start>
    86c0:	91014000 	add	x0, x0, #0x50
    86c4:	f9406c13 	ldr	x19, [x0, #216]
    86c8:	f940b017 	ldr	x23, [x0, #352]
    86cc:	eb1302ff 	cmp	x23, x19
    86d0:	5400758a 	b.ge	9580 <fwp_hof0.constprop.0+0x1180>  // b.tcont
    86d4:	f9404401 	ldr	x1, [x0, #136]
    86d8:	8b1706e0 	add	x0, x23, x23, lsl #1
    86dc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    86e0:	8b000ae0 	add	x0, x23, x0, lsl #2
    86e4:	8b000c20 	add	x0, x1, x0, lsl #3
    86e8:	b9400401 	ldr	w1, [x0, #4]
    86ec:	35000081 	cbnz	w1, 86fc <fwp_hof0.constprop.0+0x2fc>
    86f0:	b9400001 	ldr	w1, [x0]
    86f4:	6b02003f 	cmp	w1, w2
    86f8:	54007449 	b.ls	9580 <fwp_hof0.constprop.0+0x1180>  // b.plast
    86fc:	910006f7 	add	x23, x23, #0x1
    8700:	9101a000 	add	x0, x0, #0x68
    8704:	eb1302ff 	cmp	x23, x19
    8708:	54ffff01 	b.ne	86e8 <fwp_hof0.constprop.0+0x2e8>  // b.any
    870c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8710:	eb00027f 	cmp	x19, x0
    8714:	5400c1ac 	b.gt	9f48 <fwp_hof0.constprop.0+0x1b48>
    8718:	900000c0 	adrp	x0, 20000 <__data_start>
    871c:	91014000 	add	x0, x0, #0x50
    8720:	f9409001 	ldr	x1, [x0, #288]
    8724:	f940441c 	ldr	x28, [x0, #136]
    8728:	eb13003f 	cmp	x1, x19
    872c:	54000241 	b.ne	8774 <fwp_hof0.constprop.0+0x374>  // b.any
    8730:	b400a873 	cbz	x19, 9c3c <fwp_hof0.constprop.0+0x183c>
    8734:	d37ffa7b 	lsl	x27, x19, #1
    8738:	d29fffe0 	mov	x0, #0xffff                	// #65535
    873c:	eb00037f 	cmp	x27, x0
    8740:	9a80d37b 	csel	x27, x27, x0, le
    8744:	8b1b0761 	add	x1, x27, x27, lsl #1
    8748:	8b010b61 	add	x1, x27, x1, lsl #2
    874c:	d37df021 	lsl	x1, x1, #3
    8750:	aa1c03e0 	mov	x0, x28
    8754:	52800002 	mov	w2, #0x0                   	// #0
    8758:	97ffef3f 	bl	4454 <ad_raw_realloc>
    875c:	aa0003fc 	mov	x28, x0
    8760:	b4003800 	cbz	x0, 8e60 <fwp_hof0.constprop.0+0xa60>
    8764:	900000c0 	adrp	x0, 20000 <__data_start>
    8768:	91014000 	add	x0, x0, #0x50
    876c:	f900441c 	str	x28, [x0, #136]
    8770:	f900901b 	str	x27, [x0, #288]
    8774:	8b130660 	add	x0, x19, x19, lsl #1
    8778:	8b1706fb 	add	x27, x23, x23, lsl #1
    877c:	4f000400 	movi	v0.4s, #0x0
    8780:	91000662 	add	x2, x19, #0x1
    8784:	8b000a60 	add	x0, x19, x0, lsl #2
    8788:	8b1b0afb 	add	x27, x23, x27, lsl #2
    878c:	900000c1 	adrp	x1, 20000 <__data_start>
    8790:	91014021 	add	x1, x1, #0x50
    8794:	8b000f80 	add	x0, x28, x0, lsl #3
    8798:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    879c:	f9006c22 	str	x2, [x1, #216]
    87a0:	ad000000 	stp	q0, q0, [x0]
    87a4:	ad010000 	stp	q0, q0, [x0, #32]
    87a8:	ad020000 	stp	q0, q0, [x0, #64]
    87ac:	f900301f 	str	xzr, [x0, #96]
    87b0:	b0000020 	adrp	x0, d000 <__modti3+0x60>
    87b4:	f900337f 	str	xzr, [x27, #96]
    87b8:	911d0000 	add	x0, x0, #0x740
    87bc:	97ffe89d 	bl	2a30 <getenv@plt>
    87c0:	b4006fa0 	cbz	x0, 95b4 <fwp_hof0.constprop.0+0x11b4>
    87c4:	39400001 	ldrb	w1, [x0]
    87c8:	7100c03f 	cmp	w1, #0x30
    87cc:	54006f41 	b.ne	95b4 <fwp_hof0.constprop.0+0x11b4>  // b.any
    87d0:	39400400 	ldrb	w0, [x0, #1]
    87d4:	35006f00 	cbnz	w0, 95b4 <fwp_hof0.constprop.0+0x11b4>
    87d8:	900000c0 	adrp	x0, 20000 <__data_start>
    87dc:	91014000 	add	x0, x0, #0x50
    87e0:	2f000400 	mvni	v0.2s, #0x0
    87e4:	b9400373 	ldr	w19, [x27]
    87e8:	52800022 	mov	w2, #0x1                   	// #1
    87ec:	910006e4 	add	x4, x23, #0x1
    87f0:	f941c801 	ldr	x1, [x0, #912]
    87f4:	0b020273 	add	w19, w19, w2
    87f8:	29000b73 	stp	w19, w2, [x27]
    87fc:	a900db76 	stp	x22, x22, [x27, #8]
    8800:	f9002b7f 	str	xzr, [x27, #80]
    8804:	f900b004 	str	x4, [x0, #352]
    8808:	fd002f60 	str	d0, [x27, #88]
    880c:	b400ba41 	cbz	x1, 9f54 <fwp_hof0.constprop.0+0x1b54>
    8810:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x10>
    8814:	910e0003 	add	x3, x0, #0x380
    8818:	14000003 	b	8824 <fwp_hof0.constprop.0+0x424>
    881c:	f9400021 	ldr	x1, [x1]
    8820:	b400b9a1 	cbz	x1, 9f54 <fwp_hof0.constprop.0+0x1b54>
    8824:	f9400422 	ldr	x2, [x1, #8]
    8828:	eb03005f 	cmp	x2, x3
    882c:	54ffff81 	b.ne	881c <fwp_hof0.constprop.0+0x41c>  // b.any
    8830:	f9400820 	ldr	x0, [x1, #16]
    8834:	2a1703e2 	mov	w2, w23
    8838:	b9400001 	ldr	w1, [x0]
    883c:	f9002b60 	str	x0, [x27, #80]
    8840:	b9005f61 	str	w1, [x27, #92]
    8844:	37f80081 	tbnz	w1, #31, 8854 <fwp_hof0.constprop.0+0x454>
    8848:	52800d03 	mov	w3, #0x68                  	// #104
    884c:	9b237021 	smaddl	x1, w1, w3, x28
    8850:	b9005837 	str	w23, [x1, #88]
    8854:	b9000002 	str	w2, [x0]
    8858:	d3707e73 	ubfiz	x19, x19, #16, #32
    885c:	aa040273 	orr	x19, x19, x4
    8860:	aa1503e0 	mov	x0, x21
    8864:	d2800002 	mov	x2, #0x0                   	// #0
    8868:	b4007255 	cbz	x21, 96b0 <fwp_hof0.constprop.0+0x12b0>
    886c:	d503201f 	nop
    8870:	f9400800 	ldr	x0, [x0, #16]
    8874:	91000442 	add	x2, x2, #0x1
    8878:	b5ffffc0 	cbnz	x0, 8870 <fwp_hof0.constprop.0+0x470>
    887c:	aa1503e1 	mov	x1, x21
    8880:	f9400821 	ldr	x1, [x1, #16]
    8884:	91000400 	add	x0, x0, #0x1
    8888:	b5ffffc1 	cbnz	x1, 8880 <fwp_hof0.constprop.0+0x480>
    888c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8890:	eb01001f 	cmp	x0, x1
    8894:	5400b3a8 	b.hi	9f08 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    8898:	f100005f 	cmp	x2, #0x0
    889c:	540070ad 	b.le	96b0 <fwp_hof0.constprop.0+0x12b0>
    88a0:	eb00005f 	cmp	x2, x0
    88a4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    88a8:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    88ac:	eb0102df 	cmp	x22, x1
    88b0:	5400b2c8 	b.hi	9f08 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    88b4:	d37ffadc 	lsl	x28, x22, #1
    88b8:	52800041 	mov	w1, #0x2                   	// #2
    88bc:	91000780 	add	x0, x28, #0x1
    88c0:	d37df000 	lsl	x0, x0, #3
    88c4:	97fff213 	bl	5110 <fwp_heap_alloc>
    88c8:	aa0003f7 	mov	x23, x0
    88cc:	9118c281 	add	x1, x20, #0x630
    88d0:	aa0003fb 	mov	x27, x0
    88d4:	aa0103e0 	mov	x0, x1
    88d8:	f90002fc 	str	x28, [x23]
    88dc:	f949d821 	ldr	x1, [x1, #5040]
    88e0:	f949ec00 	ldr	x0, [x0, #5080]
    88e4:	cb0102e1 	sub	x1, x23, x1
    88e8:	eb00403f 	cmp	x1, x0, lsl #16
    88ec:	540080e2 	b.cs	9908 <fwp_hof0.constprop.0+0x1508>  // b.hs, b.nlast
    88f0:	9118c282 	add	x2, x20, #0x630
    88f4:	d350fc20 	lsr	x0, x1, #16
    88f8:	8b000800 	add	x0, x0, x0, lsl #2
    88fc:	f949fc43 	ldr	x3, [x2, #5112]
    8900:	d37df002 	lsl	x2, x0, #3
    8904:	8b020060 	add	x0, x3, x2
    8908:	f940101c 	ldr	x28, [x0, #32]
    890c:	b400025c 	cbz	x28, 8954 <fwp_hof0.constprop.0+0x554>
    8910:	38626862 	ldrb	w2, [x3, x2]
    8914:	7100085f 	cmp	w2, #0x2
    8918:	54008aa0 	b.eq	9a6c <fwp_hof0.constprop.0+0x166c>  // b.none
    891c:	7100045f 	cmp	w2, #0x1
    8920:	540001a1 	b.ne	8954 <fwp_hof0.constprop.0+0x554>  // b.any
    8924:	29430002 	ldp	w2, w0, [x0, #24]
    8928:	92403c21 	and	x1, x1, #0xffff
    892c:	9b027c21 	mul	x1, x1, x2
    8930:	d360fc21 	lsr	x1, x1, #32
    8934:	eb00003f 	cmp	x1, x0
    8938:	540000e2 	b.cs	8954 <fwp_hof0.constprop.0+0x554>  // b.hs, b.nlast
    893c:	8b01039c 	add	x28, x28, x1
    8940:	39400380 	ldrb	w0, [x28]
    8944:	7103fc1f 	cmp	w0, #0xff
    8948:	540089c0 	b.eq	9a80 <fwp_hof0.constprop.0+0x1680>  // b.none
    894c:	52800020 	mov	w0, #0x1                   	// #1
    8950:	39000380 	strb	w0, [x28]
    8954:	b4000236 	cbz	x22, 8998 <fwp_hof0.constprop.0+0x598>
    8958:	d3607e64 	lsl	x4, x19, #32
    895c:	aa1503e1 	mov	x1, x21
    8960:	f94006a5 	ldr	x5, [x21, #8]
    8964:	aa0403e3 	mov	x3, x4
    8968:	910022e2 	add	x2, x23, #0x8
    896c:	d2800000 	mov	x0, #0x0                   	// #0
    8970:	14000005 	b	8984 <fwp_hof0.constprop.0+0x584>
    8974:	f9400425 	ldr	x5, [x1, #8]
    8978:	ab040003 	adds	x3, x0, x4
    897c:	91004042 	add	x2, x2, #0x10
    8980:	5400b046 	b.vs	9f88 <fwp_hof0.constprop.0+0x1b88>
    8984:	a9000c45 	stp	x5, x3, [x2]
    8988:	91000400 	add	x0, x0, #0x1
    898c:	f9400821 	ldr	x1, [x1, #16]
    8990:	eb16001f 	cmp	x0, x22
    8994:	54ffff03 	b.cc	8974 <fwp_hof0.constprop.0+0x574>  // b.lo, b.ul, b.last
    8998:	f94002e0 	ldr	x0, [x23]
    899c:	f100041f 	cmp	x0, #0x1
    89a0:	54007b89 	b.ls	9910 <fwp_hof0.constprop.0+0x1510>  // b.plast
    89a4:	d341fc00 	lsr	x0, x0, #1
    89a8:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    89ac:	d1000401 	sub	x1, x0, #0x1
    89b0:	eb02003f 	cmp	x1, x2
    89b4:	5400aaa8 	b.hi	9f08 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    89b8:	d37ff83c 	lsl	x28, x1, #1
    89bc:	b4007aa1 	cbz	x1, 9910 <fwp_hof0.constprop.0+0x1510>
    89c0:	d10022e1 	sub	x1, x23, #0x8
    89c4:	910022f8 	add	x24, x23, #0x8
    89c8:	8b001036 	add	x22, x1, x0, lsl #4
    89cc:	d503201f 	nop
    89d0:	f9400700 	ldr	x0, [x24, #8]
    89d4:	f9400f01 	ldr	x1, [x24, #24]
    89d8:	fd400300 	ldr	d0, [x24]
    89dc:	fd400b01 	ldr	d1, [x24, #16]
    89e0:	97fff33d 	bl	56d4 <w120>
    89e4:	a9000700 	stp	x0, x1, [x24]
    89e8:	91004318 	add	x24, x24, #0x10
    89ec:	eb16031f 	cmp	x24, x22
    89f0:	54ffff01 	b.ne	89d0 <fwp_hof0.constprop.0+0x5d0>  // b.any
    89f4:	9118c296 	add	x22, x20, #0x630
    89f8:	f90002fc 	str	x28, [x23]
    89fc:	aa1703e0 	mov	x0, x23
    8a00:	97fff378 	bl	57e0 <w176.constprop.0>
    8a04:	aa0103fc 	mov	x28, x1
    8a08:	f949dac1 	ldr	x1, [x22, #5040]
    8a0c:	f949eec0 	ldr	x0, [x22, #5080]
    8a10:	cb0102e1 	sub	x1, x23, x1
    8a14:	eb00403f 	cmp	x1, x0, lsl #16
    8a18:	54000382 	b.cs	8a88 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8a1c:	d350fc20 	lsr	x0, x1, #16
    8a20:	f949fec4 	ldr	x4, [x22, #5112]
    8a24:	8b000800 	add	x0, x0, x0, lsl #2
    8a28:	d37df000 	lsl	x0, x0, #3
    8a2c:	8b000082 	add	x2, x4, x0
    8a30:	f9401057 	ldr	x23, [x2, #32]
    8a34:	b40002b7 	cbz	x23, 8a88 <fwp_hof0.constprop.0+0x688>
    8a38:	38606880 	ldrb	w0, [x4, x0]
    8a3c:	7100081f 	cmp	w0, #0x2
    8a40:	540076c0 	b.eq	9918 <fwp_hof0.constprop.0+0x1518>  // b.none
    8a44:	7100041f 	cmp	w0, #0x1
    8a48:	54000201 	b.ne	8a88 <fwp_hof0.constprop.0+0x688>  // b.any
    8a4c:	29430043 	ldp	w3, w0, [x2, #24]
    8a50:	92403c21 	and	x1, x1, #0xffff
    8a54:	9b037c21 	mul	x1, x1, x3
    8a58:	d360fc21 	lsr	x1, x1, #32
    8a5c:	eb00003f 	cmp	x1, x0
    8a60:	54000142 	b.cs	8a88 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8a64:	8b0102f7 	add	x23, x23, x1
    8a68:	394002e0 	ldrb	w0, [x23]
    8a6c:	340000e0 	cbz	w0, 8a88 <fwp_hof0.constprop.0+0x688>
    8a70:	7100041f 	cmp	w0, #0x1
    8a74:	540020e0 	b.eq	8e90 <fwp_hof0.constprop.0+0xa90>  // b.none
    8a78:	7103fc1f 	cmp	w0, #0xff
    8a7c:	540090c0 	b.eq	9c94 <fwp_hof0.constprop.0+0x1894>  // b.none
    8a80:	51000400 	sub	w0, w0, #0x1
    8a84:	390002e0 	strb	w0, [x23]
    8a88:	93407e73 	sxtw	x19, w19
    8a8c:	aa1303e0 	mov	x0, x19
    8a90:	97ffec28 	bl	3b30 <fwp_tape_of>
    8a94:	f9403001 	ldr	x1, [x0, #96]
    8a98:	aa0003ea 	mov	x10, x0
    8a9c:	b500a4a1 	cbnz	x1, 9f30 <fwp_hof0.constprop.0+0x1b30>
    8aa0:	97ffe95d 	bl	3014 <fwp_tape_unlink_scope>
    8aa4:	b9400002 	ldr	w2, [x0]
    8aa8:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    8aac:	a9408018 	ldp	x24, x0, [x0, #8]
    8ab0:	b900055f 	str	wzr, [x10, #4]
    8ab4:	a941e94b 	ldp	x11, x26, [x10, #24]
    8ab8:	a942a15b 	ldp	x27, x8, [x10, #40]
    8abc:	a943e549 	ldp	x9, x25, [x10, #56]
    8ac0:	f9402557 	ldr	x23, [x10, #72]
    8ac4:	6b01005f 	cmp	w2, w1
    8ac8:	54000128 	b.hi	8aec <fwp_hof0.constprop.0+0x6ec>  // b.pmore
    8acc:	900000c1 	adrp	x1, 20000 <__data_start>
    8ad0:	91014022 	add	x2, x1, #0x50
    8ad4:	92403e61 	and	x1, x19, #0xffff
    8ad8:	d1000421 	sub	x1, x1, #0x1
    8adc:	f940b043 	ldr	x3, [x2, #352]
    8ae0:	eb03003f 	cmp	x1, x3
    8ae4:	5400004a 	b.ge	8aec <fwp_hof0.constprop.0+0x6ec>  // b.tcont
    8ae8:	f900b041 	str	x1, [x2, #352]
    8aec:	4f000400 	movi	v0.4s, #0x0
    8af0:	900000c1 	adrp	x1, 20000 <__data_start>
    8af4:	91014023 	add	x3, x1, #0x50
    8af8:	f9000d5f 	str	xzr, [x10, #24]
    8afc:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    8b00:	910243e4 	add	x4, sp, #0x90
    8b04:	9101e3e1 	add	x1, sp, #0x78
    8b08:	f941c86c 	ldr	x12, [x3, #912]
    8b0c:	3c808140 	stur	q0, [x10, #8]
    8b10:	90ffffe2 	adrp	x2, 4000 <fwp_heap_report+0x60>
    8b14:	ad010140 	stp	q0, q0, [x10, #32]
    8b18:	91149042 	add	x2, x2, #0x524
    8b1c:	f9000be4 	str	x4, [sp, #16]
    8b20:	a9078bec 	stp	x12, x2, [sp, #120]
    8b24:	a908ebe4 	stp	x4, x26, [sp, #136]
    8b28:	a909a3fb 	stp	x27, x8, [sp, #152]
    8b2c:	a90ae7e9 	stp	x9, x25, [sp, #168]
    8b30:	a90bdfeb 	stp	x11, x23, [sp, #184]
    8b34:	f901c861 	str	x1, [x3, #912]
    8b38:	b7f87abc 	tbnz	x28, #63, 9a8c <fwp_hof0.constprop.0+0x168c>
    8b3c:	eb9c827f 	cmp	x19, x28, asr #32
    8b40:	54009ac1 	b.ne	9e98 <fwp_hof0.constprop.0+0x1a98>  // b.any
    8b44:	92407f96 	and	x22, x28, #0xffffffff
    8b48:	eb3c401f 	cmp	x0, w28, uxtw
    8b4c:	5400994d 	b.le	9e74 <fwp_hof0.constprop.0+0x1a74>
    8b50:	eb16031f 	cmp	x24, x22
    8b54:	9a96c716 	csinc	x22, x24, x22, gt
    8b58:	eb1602ff 	cmp	x23, x22
    8b5c:	540016ca 	b.ge	8e34 <fwp_hof0.constprop.0+0xa34>  // b.tcont
    8b60:	f10002ff 	cmp	x23, #0x0
    8b64:	9a9612f7 	csel	x23, x23, x22, ne	// ne = any
    8b68:	14000005 	b	8b7c <fwp_hof0.constprop.0+0x77c>
    8b6c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8b70:	eb0002ff 	cmp	x23, x0
    8b74:	d37ffaf7 	lsl	x23, x23, #1
    8b78:	9a96d2f7 	csel	x23, x23, x22, le
    8b7c:	eb1602ff 	cmp	x23, x22
    8b80:	54ffff6b 	b.lt	8b6c <fwp_hof0.constprop.0+0x76c>  // b.tstop
    8b84:	b4008099 	cbz	x25, 9b94 <fwp_hof0.constprop.0+0x1794>
    8b88:	aa1903e0 	mov	x0, x25
    8b8c:	d37df2e1 	lsl	x1, x23, #3
    8b90:	52800062 	mov	w2, #0x3                   	// #3
    8b94:	a90327e8 	stp	x8, x9, [sp, #48]
    8b98:	97ffee2f 	bl	4454 <ad_raw_realloc>
    8b9c:	a94327e8 	ldp	x8, x9, [sp, #48]
    8ba0:	aa0003f9 	mov	x25, x0
    8ba4:	b4007e40 	cbz	x0, 9b6c <fwp_hof0.constprop.0+0x176c>
    8ba8:	f9005bf9 	str	x25, [sp, #176]
    8bac:	f90063f7 	str	x23, [sp, #192]
    8bb0:	b5001356 	cbnz	x22, 8e18 <fwp_hof0.constprop.0+0xa18>
    8bb4:	b7f800dc 	tbnz	x28, #63, 8bcc <fwp_hof0.constprop.0+0x7cc>
    8bb8:	92407f81 	and	x1, x28, #0xffffffff
    8bbc:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8bc0:	fc617b20 	ldr	d0, [x25, x1, lsl #3]
    8bc4:	1e612800 	fadd	d0, d0, d1
    8bc8:	fc217b20 	str	d0, [x25, x1, lsl #3]
    8bcc:	d10006d6 	sub	x22, x22, #0x1
    8bd0:	d1000703 	sub	x3, x24, #0x1
    8bd4:	eb16031f 	cmp	x24, x22
    8bd8:	540003ac 	b.gt	8c4c <fwp_hof0.constprop.0+0x84c>
    8bdc:	fc767b20 	ldr	d0, [x25, x22, lsl #3]
    8be0:	1e602008 	fcmp	d0, #0.0
    8be4:	540002e0 	b.eq	8c40 <fwp_hof0.constprop.0+0x840>  // b.none
    8be8:	cb180be0 	neg	x0, x24, lsl #2
    8bec:	cb1803e2 	neg	x2, x24
    8bf0:	8b000341 	add	x1, x26, x0
    8bf4:	b8767821 	ldr	w1, [x1, x22, lsl #2]
    8bf8:	37f80101 	tbnz	w1, #31, 8c18 <fwp_hof0.constprop.0+0x818>
    8bfc:	8b020d0a 	add	x10, x8, x2, lsl #3
    8c00:	93407c21 	sxtw	x1, w1
    8c04:	fc767942 	ldr	d2, [x10, x22, lsl #3]
    8c08:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    8c0c:	1e620802 	fmul	d2, d0, d2
    8c10:	1e622821 	fadd	d1, d1, d2
    8c14:	fc217b21 	str	d1, [x25, x1, lsl #3]
    8c18:	8b000360 	add	x0, x27, x0
    8c1c:	b8767800 	ldr	w0, [x0, x22, lsl #2]
    8c20:	37f80100 	tbnz	w0, #31, 8c40 <fwp_hof0.constprop.0+0x840>
    8c24:	8b020d22 	add	x2, x9, x2, lsl #3
    8c28:	93407c00 	sxtw	x0, w0
    8c2c:	fc767842 	ldr	d2, [x2, x22, lsl #3]
    8c30:	fc607b21 	ldr	d1, [x25, x0, lsl #3]
    8c34:	1e620800 	fmul	d0, d0, d2
    8c38:	1e602820 	fadd	d0, d1, d0
    8c3c:	fc207b20 	str	d0, [x25, x0, lsl #3]
    8c40:	d10006d6 	sub	x22, x22, #0x1
    8c44:	eb16007f 	cmp	x3, x22
    8c48:	54fffca1 	b.ne	8bdc <fwp_hof0.constprop.0+0x7dc>  // b.any
    8c4c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8c50:	eb00031f 	cmp	x24, x0
    8c54:	540098c8 	b.hi	9f6c <fwp_hof0.constprop.0+0x1b6c>  // b.pmore
    8c58:	91000700 	add	x0, x24, #0x1
    8c5c:	52800041 	mov	w1, #0x2                   	// #2
    8c60:	d37df000 	lsl	x0, x0, #3
    8c64:	97fff12b 	bl	5110 <fwp_heap_alloc>
    8c68:	aa0003e2 	mov	x2, x0
    8c6c:	aa0003f3 	mov	x19, x0
    8c70:	d2800001 	mov	x1, #0x0                   	// #0
    8c74:	f8008458 	str	x24, [x2], #8
    8c78:	b40000f8 	cbz	x24, 8c94 <fwp_hof0.constprop.0+0x894>
    8c7c:	d503201f 	nop
    8c80:	f8617b20 	ldr	x0, [x25, x1, lsl #3]
    8c84:	f8217840 	str	x0, [x2, x1, lsl #3]
    8c88:	91000421 	add	x1, x1, #0x1
    8c8c:	eb01031f 	cmp	x24, x1
    8c90:	54ffff81 	b.ne	8c80 <fwp_hof0.constprop.0+0x880>  // b.any
    8c94:	900000c0 	adrp	x0, 20000 <__data_start>
    8c98:	91014001 	add	x1, x0, #0x50
    8c9c:	f9400be0 	ldr	x0, [sp, #16]
    8ca0:	f9403ff7 	ldr	x23, [sp, #120]
    8ca4:	f901c837 	str	x23, [x1, #912]
    8ca8:	97ffee1f 	bl	4524 <fwp_tape_buffers_release>
    8cac:	9118c282 	add	x2, x20, #0x630
    8cb0:	f949d841 	ldr	x1, [x2, #5040]
    8cb4:	f949ec40 	ldr	x0, [x2, #5080]
    8cb8:	cb010261 	sub	x1, x19, x1
    8cbc:	eb00403f 	cmp	x1, x0, lsl #16
    8cc0:	54000322 	b.cs	8d24 <fwp_hof0.constprop.0+0x924>  // b.hs, b.nlast
    8cc4:	d350fc20 	lsr	x0, x1, #16
    8cc8:	f949fc43 	ldr	x3, [x2, #5112]
    8ccc:	8b000800 	add	x0, x0, x0, lsl #2
    8cd0:	d37df002 	lsl	x2, x0, #3
    8cd4:	8b020060 	add	x0, x3, x2
    8cd8:	f9401016 	ldr	x22, [x0, #32]
    8cdc:	b4000256 	cbz	x22, 8d24 <fwp_hof0.constprop.0+0x924>
    8ce0:	38626862 	ldrb	w2, [x3, x2]
    8ce4:	7100085f 	cmp	w2, #0x2
    8ce8:	54006d60 	b.eq	9a94 <fwp_hof0.constprop.0+0x1694>  // b.none
    8cec:	7100045f 	cmp	w2, #0x1
    8cf0:	540001a1 	b.ne	8d24 <fwp_hof0.constprop.0+0x924>  // b.any
    8cf4:	29430002 	ldp	w2, w0, [x0, #24]
    8cf8:	92403c21 	and	x1, x1, #0xffff
    8cfc:	9b027c21 	mul	x1, x1, x2
    8d00:	d360fc21 	lsr	x1, x1, #32
    8d04:	eb00003f 	cmp	x1, x0
    8d08:	540000e2 	b.cs	8d24 <fwp_hof0.constprop.0+0x924>  // b.hs, b.nlast
    8d0c:	8b0102d6 	add	x22, x22, x1
    8d10:	394002c0 	ldrb	w0, [x22]
    8d14:	7103fc1f 	cmp	w0, #0xff
    8d18:	54006c80 	b.eq	9aa8 <fwp_hof0.constprop.0+0x16a8>  // b.none
    8d1c:	52800020 	mov	w0, #0x1                   	// #1
    8d20:	390002c0 	strb	w0, [x22]
    8d24:	f94013e0 	ldr	x0, [sp, #32]
    8d28:	eb0002ff 	cmp	x23, x0
    8d2c:	540092c1 	b.ne	9f84 <fwp_hof0.constprop.0+0x1b84>  // b.any
    8d30:	900000c0 	adrp	x0, 20000 <__data_start>
    8d34:	91014001 	add	x1, x0, #0x50
    8d38:	f9400fe0 	ldr	x0, [sp, #24]
    8d3c:	f94033e2 	ldr	x2, [sp, #96]
    8d40:	f901c822 	str	x2, [x1, #912]
    8d44:	97fff58f 	bl	6380 <fwp_tape_scope_release>
    8d48:	f9400260 	ldr	x0, [x19]
    8d4c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8d50:	b7f845c0 	tbnz	x0, #63, 9608 <fwp_hof0.constprop.0+0x1208>
    8d54:	9118c282 	add	x2, x20, #0x630
    8d58:	f949d840 	ldr	x0, [x2, #5040]
    8d5c:	f949ec41 	ldr	x1, [x2, #5080]
    8d60:	cb000260 	sub	x0, x19, x0
    8d64:	eb01401f 	cmp	x0, x1, lsl #16
    8d68:	54004502 	b.cs	9608 <fwp_hof0.constprop.0+0x1208>  // b.hs, b.nlast
    8d6c:	d350fc01 	lsr	x1, x0, #16
    8d70:	f949fc44 	ldr	x4, [x2, #5112]
    8d74:	8b010821 	add	x1, x1, x1, lsl #2
    8d78:	d37df021 	lsl	x1, x1, #3
    8d7c:	8b010083 	add	x3, x4, x1
    8d80:	f9401062 	ldr	x2, [x3, #32]
    8d84:	b4004422 	cbz	x2, 9608 <fwp_hof0.constprop.0+0x1208>
    8d88:	38616881 	ldrb	w1, [x4, x1]
    8d8c:	7100083f 	cmp	w1, #0x2
    8d90:	54004360 	b.eq	95fc <fwp_hof0.constprop.0+0x11fc>  // b.none
    8d94:	7100043f 	cmp	w1, #0x1
    8d98:	54004381 	b.ne	9608 <fwp_hof0.constprop.0+0x1208>  // b.any
    8d9c:	29430464 	ldp	w4, w1, [x3, #24]
    8da0:	92403c00 	and	x0, x0, #0xffff
    8da4:	9b047c00 	mul	x0, x0, x4
    8da8:	d360fc00 	lsr	x0, x0, #32
    8dac:	eb01001f 	cmp	x0, x1
    8db0:	540042c2 	b.cs	9608 <fwp_hof0.constprop.0+0x1208>  // b.hs, b.nlast
    8db4:	8b000042 	add	x2, x2, x0
    8db8:	39400040 	ldrb	w0, [x2]
    8dbc:	7100041f 	cmp	w0, #0x1
    8dc0:	54004241 	b.ne	9608 <fwp_hof0.constprop.0+0x1208>  // b.any
    8dc4:	aa1303fc 	mov	x28, x19
    8dc8:	aa1303f6 	mov	x22, x19
    8dcc:	d2800000 	mov	x0, #0x0                   	// #0
    8dd0:	910022c3 	add	x3, x22, #0x8
    8dd4:	91002265 	add	x5, x19, #0x8
    8dd8:	d2800001 	mov	x1, #0x0                   	// #0
    8ddc:	b5000157 	cbnz	x23, 8e04 <fwp_hof0.constprop.0+0xa04>
    8de0:	1400004d 	b	8f14 <fwp_hof0.constprop.0+0xb14>
    8de4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8de8:	f9400382 	ldr	x2, [x28]
    8dec:	1e600900 	fmul	d0, d8, d0
    8df0:	b7f88862 	tbnz	x2, #63, 9efc <fwp_hof0.constprop.0+0x1afc>
    8df4:	91000421 	add	x1, x1, #0x1
    8df8:	fc008460 	str	d0, [x3], #8
    8dfc:	eb0102ff 	cmp	x23, x1
    8e00:	540008a0 	b.eq	8f14 <fwp_hof0.constprop.0+0xb14>  // b.none
    8e04:	f9400264 	ldr	x4, [x19]
    8e08:	aa0503e2 	mov	x2, x5
    8e0c:	b6fffec4 	tbz	x4, #63, 8de4 <fwp_hof0.constprop.0+0x9e4>
    8e10:	f9400a62 	ldr	x2, [x19, #16]
    8e14:	17fffff4 	b	8de4 <fwp_hof0.constprop.0+0x9e4>
    8e18:	d37df2c2 	lsl	x2, x22, #3
    8e1c:	aa1903e0 	mov	x0, x25
    8e20:	52800001 	mov	w1, #0x0                   	// #0
    8e24:	a90327e8 	stp	x8, x9, [sp, #48]
    8e28:	97ffe692 	bl	2870 <memset@plt>
    8e2c:	a94327e8 	ldp	x8, x9, [sp, #48]
    8e30:	17ffff61 	b	8bb4 <fwp_hof0.constprop.0+0x7b4>
    8e34:	f100033f 	cmp	x25, #0x0
    8e38:	1a9f17e0 	cset	w0, eq	// eq = none
    8e3c:	f10002df 	cmp	x22, #0x0
    8e40:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8e44:	54ffeb60 	b.eq	8bb0 <fwp_hof0.constprop.0+0x7b0>  // b.none
    8e48:	900000c0 	adrp	x0, 20000 <__data_start>
    8e4c:	91014018 	add	x24, x0, #0x50
    8e50:	f9400be0 	ldr	x0, [sp, #16]
    8e54:	f9403fe1 	ldr	x1, [sp, #120]
    8e58:	f901cb01 	str	x1, [x24, #912]
    8e5c:	97ffedb2 	bl	4524 <fwp_tape_buffers_release>
    8e60:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    8e64:	f947e863 	ldr	x3, [x3, #4048]
    8e68:	d2800262 	mov	x2, #0x13                  	// #19
    8e6c:	d2800021 	mov	x1, #0x1                   	// #1
    8e70:	b0000020 	adrp	x0, d000 <__modti3+0x60>
    8e74:	910d2000 	add	x0, x0, #0x348
    8e78:	f9400063 	ldr	x3, [x3]
    8e7c:	97ffe6c9 	bl	29a0 <fwrite@plt>
    8e80:	d2800000 	mov	x0, #0x0                   	// #0
    8e84:	97ffe6d3 	bl	29d0 <fflush@plt>
    8e88:	52800cc0 	mov	w0, #0x66                  	// #102
    8e8c:	97ffe6e1 	bl	2a10 <_Exit@plt>
    8e90:	f9400365 	ldr	x5, [x27]
    8e94:	aa1b03e0 	mov	x0, x27
    8e98:	f949eec3 	ldr	x3, [x22, #5080]
    8e9c:	f949dac1 	ldr	x1, [x22, #5040]
    8ea0:	d370bc63 	lsl	x3, x3, #16
    8ea4:	cb010362 	sub	x2, x27, x1
    8ea8:	b7f85445 	tbnz	x5, #63, 9930 <fwp_hof0.constprop.0+0x1530>
    8eac:	eb03005f 	cmp	x2, x3
    8eb0:	54ffdec2 	b.cs	8a88 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8eb4:	d350fc40 	lsr	x0, x2, #16
    8eb8:	8b000800 	add	x0, x0, x0, lsl #2
    8ebc:	d37df000 	lsl	x0, x0, #3
    8ec0:	8b000083 	add	x3, x4, x0
    8ec4:	f9401061 	ldr	x1, [x3, #32]
    8ec8:	b4ffde01 	cbz	x1, 8a88 <fwp_hof0.constprop.0+0x688>
    8ecc:	38606880 	ldrb	w0, [x4, x0]
    8ed0:	7100081f 	cmp	w0, #0x2
    8ed4:	54005f00 	b.eq	9ab4 <fwp_hof0.constprop.0+0x16b4>  // b.none
    8ed8:	7100041f 	cmp	w0, #0x1
    8edc:	54ffdd61 	b.ne	8a88 <fwp_hof0.constprop.0+0x688>  // b.any
    8ee0:	92403c40 	and	x0, x2, #0xffff
    8ee4:	29430864 	ldp	w4, w2, [x3, #24]
    8ee8:	9b047c00 	mul	x0, x0, x4
    8eec:	d360fc00 	lsr	x0, x0, #32
    8ef0:	eb02001f 	cmp	x0, x2
    8ef4:	54ffdca2 	b.cs	8a88 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8ef8:	8b000021 	add	x1, x1, x0
    8efc:	39400020 	ldrb	w0, [x1]
    8f00:	7100041f 	cmp	w0, #0x1
    8f04:	54ffdc21 	b.ne	8a88 <fwp_hof0.constprop.0+0x688>  // b.any
    8f08:	aa1b03e0 	mov	x0, x27
    8f0c:	97ffef61 	bl	4c90 <fwp_mem_free>
    8f10:	17fffede 	b	8a88 <fwp_hof0.constprop.0+0x688>
    8f14:	97fff707 	bl	6b30 <fwp_drop10>
    8f18:	aa1503e1 	mov	x1, x21
    8f1c:	d2800002 	mov	x2, #0x0                   	// #0
    8f20:	b40067b5 	cbz	x21, 9c14 <fwp_hof0.constprop.0+0x1814>
    8f24:	d503201f 	nop
    8f28:	f9400821 	ldr	x1, [x1, #16]
    8f2c:	91000442 	add	x2, x2, #0x1
    8f30:	b5ffffc1 	cbnz	x1, 8f28 <fwp_hof0.constprop.0+0xb28>
    8f34:	f9400385 	ldr	x5, [x28]
    8f38:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    8f3c:	b7f82b65 	tbnz	x5, #63, 94a8 <fwp_hof0.constprop.0+0x10a8>
    8f40:	9118c281 	add	x1, x20, #0x630
    8f44:	f949d820 	ldr	x0, [x1, #5040]
    8f48:	f949ec21 	ldr	x1, [x1, #5080]
    8f4c:	cb0002c0 	sub	x0, x22, x0
    8f50:	eb01401f 	cmp	x0, x1, lsl #16
    8f54:	54002aa2 	b.cs	94a8 <fwp_hof0.constprop.0+0x10a8>  // b.hs, b.nlast
    8f58:	9118c283 	add	x3, x20, #0x630
    8f5c:	d350fc01 	lsr	x1, x0, #16
    8f60:	8b010821 	add	x1, x1, x1, lsl #2
    8f64:	f949fc67 	ldr	x7, [x3, #5112]
    8f68:	d37df021 	lsl	x1, x1, #3
    8f6c:	8b0100e6 	add	x6, x7, x1
    8f70:	f94010c3 	ldr	x3, [x6, #32]
    8f74:	b4002983 	cbz	x3, 94a4 <fwp_hof0.constprop.0+0x10a4>
    8f78:	386168e1 	ldrb	w1, [x7, x1]
    8f7c:	7100083f 	cmp	w1, #0x2
    8f80:	540028e0 	b.eq	949c <fwp_hof0.constprop.0+0x109c>  // b.none
    8f84:	7100043f 	cmp	w1, #0x1
    8f88:	540028e1 	b.ne	94a4 <fwp_hof0.constprop.0+0x10a4>  // b.any
    8f8c:	294304c7 	ldp	w7, w1, [x6, #24]
    8f90:	92403c00 	and	x0, x0, #0xffff
    8f94:	9b077c00 	mul	x0, x0, x7
    8f98:	d360fc00 	lsr	x0, x0, #32
    8f9c:	eb01001f 	cmp	x0, x1
    8fa0:	54002822 	b.cs	94a4 <fwp_hof0.constprop.0+0x10a4>  // b.hs, b.nlast
    8fa4:	8b000063 	add	x3, x3, x0
    8fa8:	39400060 	ldrb	w0, [x3]
    8fac:	7100041f 	cmp	w0, #0x1
    8fb0:	540027a1 	b.ne	94a4 <fwp_hof0.constprop.0+0x10a4>  // b.any
    8fb4:	b90033e0 	str	w0, [sp, #48]
    8fb8:	eb02009f 	cmp	x4, x2
    8fbc:	9a829084 	csel	x4, x4, x2, ls	// ls = plast
    8fc0:	9100239b 	add	x27, x28, #0x8
    8fc4:	b4007184 	cbz	x4, 9df4 <fwp_hof0.constprop.0+0x19f4>
    8fc8:	d37df087 	lsl	x7, x4, #3
    8fcc:	aa1503e2 	mov	x2, x21
    8fd0:	910022c0 	add	x0, x22, #0x8
    8fd4:	d2800001 	mov	x1, #0x0                   	// #0
    8fd8:	1400000a 	b	9000 <fwp_hof0.constprop.0+0xc00>
    8fdc:	fc6168c1 	ldr	d1, [x6, x1]
    8fe0:	fd400440 	ldr	d0, [x2, #8]
    8fe4:	1e613800 	fsub	d0, d0, d1
    8fe8:	fc216b60 	str	d0, [x27, x1]
    8fec:	91002021 	add	x1, x1, #0x8
    8ff0:	f9400842 	ldr	x2, [x2, #16]
    8ff4:	eb07003f 	cmp	x1, x7
    8ff8:	540001a0 	b.eq	902c <fwp_hof0.constprop.0+0xc2c>  // b.none
    8ffc:	f9400385 	ldr	x5, [x28]
    9000:	aa0003e6 	mov	x6, x0
    9004:	b6fffec5 	tbz	x5, #63, 8fdc <fwp_hof0.constprop.0+0xbdc>
    9008:	f9400ac6 	ldr	x6, [x22, #16]
    900c:	fd400440 	ldr	d0, [x2, #8]
    9010:	fc6168c1 	ldr	d1, [x6, x1]
    9014:	1e613800 	fsub	d0, d0, d1
    9018:	fc216b60 	str	d0, [x27, x1]
    901c:	91002021 	add	x1, x1, #0x8
    9020:	f9400842 	ldr	x2, [x2, #16]
    9024:	eb07003f 	cmp	x1, x7
    9028:	54fffea1 	b.ne	8ffc <fwp_hof0.constprop.0+0xbfc>  // b.any
    902c:	b4007215 	cbz	x21, 9e6c <fwp_hof0.constprop.0+0x1a6c>
    9030:	9118c280 	add	x0, x20, #0x630
    9034:	aa1503e7 	mov	x7, x21
    9038:	d2800017 	mov	x23, #0x0                   	// #0
    903c:	f949ec09 	ldr	x9, [x0, #5080]
    9040:	f949d80a 	ldr	x10, [x0, #5040]
    9044:	f949fc08 	ldr	x8, [x0, #5112]
    9048:	d370bd29 	lsl	x9, x9, #16
    904c:	14000006 	b	9064 <fwp_hof0.constprop.0+0xc64>
    9050:	f94008e7 	ldr	x7, [x7, #16]
    9054:	910006f7 	add	x23, x23, #0x1
    9058:	f10000ff 	cmp	x7, #0x0
    905c:	fa571080 	ccmp	x4, x23, #0x0, ne	// ne = any
    9060:	54000329 	b.ls	90c4 <fwp_hof0.constprop.0+0xcc4>  // b.plast
    9064:	cb0a00e0 	sub	x0, x7, x10
    9068:	eb09001f 	cmp	x0, x9
    906c:	540002c2 	b.cs	90c4 <fwp_hof0.constprop.0+0xcc4>  // b.hs, b.nlast
    9070:	d350fc01 	lsr	x1, x0, #16
    9074:	8b010821 	add	x1, x1, x1, lsl #2
    9078:	d37df021 	lsl	x1, x1, #3
    907c:	8b010106 	add	x6, x8, x1
    9080:	f94010c2 	ldr	x2, [x6, #32]
    9084:	b4000202 	cbz	x2, 90c4 <fwp_hof0.constprop.0+0xcc4>
    9088:	38616901 	ldrb	w1, [x8, x1]
    908c:	7100083f 	cmp	w1, #0x2
    9090:	54000e00 	b.eq	9250 <fwp_hof0.constprop.0+0xe50>  // b.none
    9094:	7100043f 	cmp	w1, #0x1
    9098:	54000161 	b.ne	90c4 <fwp_hof0.constprop.0+0xcc4>  // b.any
    909c:	294304cb 	ldp	w11, w1, [x6, #24]
    90a0:	92403c00 	and	x0, x0, #0xffff
    90a4:	9b0b7c00 	mul	x0, x0, x11
    90a8:	d360fc00 	lsr	x0, x0, #32
    90ac:	eb01001f 	cmp	x0, x1
    90b0:	540000a2 	b.cs	90c4 <fwp_hof0.constprop.0+0xcc4>  // b.hs, b.nlast
    90b4:	8b000042 	add	x2, x2, x0
    90b8:	39400040 	ldrb	w0, [x2]
    90bc:	7100041f 	cmp	w0, #0x1
    90c0:	54fffc80 	b.eq	9050 <fwp_hof0.constprop.0+0xc50>  // b.none
    90c4:	eb17009f 	cmp	x4, x23
    90c8:	54000cc9 	b.ls	9260 <fwp_hof0.constprop.0+0xe60>  // b.plast
    90cc:	aa0403f8 	mov	x24, x4
    90d0:	d1002379 	sub	x25, x27, #0x8
    90d4:	910323f3 	add	x19, sp, #0xc8
    90d8:	9118c29a 	add	x26, x20, #0x630
    90dc:	d280001c 	mov	x28, #0x0                   	// #0
    90e0:	14000012 	b	9128 <fwp_hof0.constprop.0+0xd28>
    90e4:	7100045f 	cmp	w2, #0x1
    90e8:	540001a1 	b.ne	911c <fwp_hof0.constprop.0+0xd1c>  // b.any
    90ec:	29430909 	ldp	w9, w2, [x8, #24]
    90f0:	92403c21 	and	x1, x1, #0xffff
    90f4:	9b097c21 	mul	x1, x1, x9
    90f8:	d360fc21 	lsr	x1, x1, #32
    90fc:	eb02003f 	cmp	x1, x2
    9100:	540000e2 	b.cs	911c <fwp_hof0.constprop.0+0xd1c>  // b.hs, b.nlast
    9104:	8b010000 	add	x0, x0, x1
    9108:	39400001 	ldrb	w1, [x0]
    910c:	7103fc3f 	cmp	w1, #0xff
    9110:	54002f80 	b.eq	9700 <fwp_hof0.constprop.0+0x1300>  // b.none
    9114:	52800021 	mov	w1, #0x1                   	// #1
    9118:	39000001 	strb	w1, [x0]
    911c:	d1000718 	sub	x24, x24, #0x1
    9120:	eb1802ff 	cmp	x23, x24
    9124:	54000362 	b.cs	9190 <fwp_hof0.constprop.0+0xd90>  // b.hs, b.nlast
    9128:	f8787b22 	ldr	x2, [x25, x24, lsl #3]
    912c:	aa1303e1 	mov	x1, x19
    9130:	52800020 	mov	w0, #0x1                   	// #1
    9134:	a90cf3e2 	stp	x2, x28, [sp, #200]
    9138:	97fff057 	bl	5294 <fwp_data.part.0.constprop.0>
    913c:	aa0003fc 	mov	x28, x0
    9140:	f949db41 	ldr	x1, [x26, #5040]
    9144:	f949ef40 	ldr	x0, [x26, #5080]
    9148:	cb010381 	sub	x1, x28, x1
    914c:	eb00403f 	cmp	x1, x0, lsl #16
    9150:	54fffe62 	b.cs	911c <fwp_hof0.constprop.0+0xd1c>  // b.hs, b.nlast
    9154:	d350fc20 	lsr	x0, x1, #16
    9158:	f949ff49 	ldr	x9, [x26, #5112]
    915c:	8b000800 	add	x0, x0, x0, lsl #2
    9160:	d37df002 	lsl	x2, x0, #3
    9164:	8b020128 	add	x8, x9, x2
    9168:	f9401100 	ldr	x0, [x8, #32]
    916c:	b4fffd80 	cbz	x0, 911c <fwp_hof0.constprop.0+0xd1c>
    9170:	38626922 	ldrb	w2, [x9, x2]
    9174:	7100085f 	cmp	w2, #0x2
    9178:	54fffb61 	b.ne	90e4 <fwp_hof0.constprop.0+0xce4>  // b.any
    917c:	72003c3f 	tst	w1, #0xffff
    9180:	54fffc40 	b.eq	9108 <fwp_hof0.constprop.0+0xd08>  // b.none
    9184:	d1000718 	sub	x24, x24, #0x1
    9188:	eb1802ff 	cmp	x23, x24
    918c:	54fffce3 	b.cc	9128 <fwp_hof0.constprop.0+0xd28>  // b.lo, b.ul, b.last
    9190:	b50006b7 	cbnz	x23, 9264 <fwp_hof0.constprop.0+0xe64>
    9194:	b94033e0 	ldr	w0, [sp, #48]
    9198:	d2800004 	mov	x4, #0x0                   	// #0
    919c:	7100001f 	cmp	w0, #0x0
    91a0:	d2800020 	mov	x0, #0x1                   	// #1
    91a4:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    91a8:	b40007c4 	cbz	x4, 92a0 <fwp_hof0.constprop.0+0xea0>
    91ac:	d1000497 	sub	x23, x4, #0x1
    91b0:	2a0003f9 	mov	w25, w0
    91b4:	9118c29a 	add	x26, x20, #0x630
    91b8:	f8777b62 	ldr	x2, [x27, x23, lsl #3]
    91bc:	aa1303e1 	mov	x1, x19
    91c0:	52800020 	mov	w0, #0x1                   	// #1
    91c4:	a90cf3e2 	stp	x2, x28, [sp, #200]
    91c8:	97fff033 	bl	5294 <fwp_data.part.0.constprop.0>
    91cc:	aa0003fc 	mov	x28, x0
    91d0:	f949db41 	ldr	x1, [x26, #5040]
    91d4:	f949ef40 	ldr	x0, [x26, #5080]
    91d8:	cb010381 	sub	x1, x28, x1
    91dc:	eb00403f 	cmp	x1, x0, lsl #16
    91e0:	54000302 	b.cs	9240 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    91e4:	d350fc22 	lsr	x2, x1, #16
    91e8:	f949ff47 	ldr	x7, [x26, #5112]
    91ec:	8b020842 	add	x2, x2, x2, lsl #2
    91f0:	d37df042 	lsl	x2, x2, #3
    91f4:	8b0200e5 	add	x5, x7, x2
    91f8:	f94010b8 	ldr	x24, [x5, #32]
    91fc:	b4000238 	cbz	x24, 9240 <fwp_hof0.constprop.0+0xe40>
    9200:	386268e2 	ldrb	w2, [x7, x2]
    9204:	7100085f 	cmp	w2, #0x2
    9208:	54001440 	b.eq	9490 <fwp_hof0.constprop.0+0x1090>  // b.none
    920c:	7100045f 	cmp	w2, #0x1
    9210:	54000181 	b.ne	9240 <fwp_hof0.constprop.0+0xe40>  // b.any
    9214:	294308a7 	ldp	w7, w2, [x5, #24]
    9218:	92403c21 	and	x1, x1, #0xffff
    921c:	9b077c21 	mul	x1, x1, x7
    9220:	d360fc21 	lsr	x1, x1, #32
    9224:	eb02003f 	cmp	x1, x2
    9228:	540000c2 	b.cs	9240 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    922c:	8b010318 	add	x24, x24, x1
    9230:	39400301 	ldrb	w1, [x24]
    9234:	7103fc3f 	cmp	w1, #0xff
    9238:	54001260 	b.eq	9484 <fwp_hof0.constprop.0+0x1084>  // b.none
    923c:	39000319 	strb	w25, [x24]
    9240:	d10006f7 	sub	x23, x23, #0x1
    9244:	b10006ff 	cmn	x23, #0x1
    9248:	54fffb81 	b.ne	91b8 <fwp_hof0.constprop.0+0xdb8>  // b.any
    924c:	14000015 	b	92a0 <fwp_hof0.constprop.0+0xea0>
    9250:	72003c1f 	tst	w0, #0xffff
    9254:	54fff320 	b.eq	90b8 <fwp_hof0.constprop.0+0xcb8>  // b.none
    9258:	eb17009f 	cmp	x4, x23
    925c:	54fff388 	b.hi	90cc <fwp_hof0.constprop.0+0xccc>  // b.pmore
    9260:	d280001c 	mov	x28, #0x0                   	// #0
    9264:	8b170f65 	add	x5, x27, x23, lsl #3
    9268:	aa1b03e1 	mov	x1, x27
    926c:	aa1503e0 	mov	x0, x21
    9270:	f8408422 	ldr	x2, [x1], #8
    9274:	f9000402 	str	x2, [x0, #8]
    9278:	aa0003e2 	mov	x2, x0
    927c:	f9400800 	ldr	x0, [x0, #16]
    9280:	eb05003f 	cmp	x1, x5
    9284:	54ffff61 	b.ne	9270 <fwp_hof0.constprop.0+0xe70>  // b.any
    9288:	b94033e1 	ldr	w1, [sp, #48]
    928c:	f900085c 	str	x28, [x2, #16]
    9290:	aa1503fc 	mov	x28, x21
    9294:	aa0003f5 	mov	x21, x0
    9298:	34000041 	cbz	w1, 92a0 <fwp_hof0.constprop.0+0xea0>
    929c:	d280001b 	mov	x27, #0x0                   	// #0
    92a0:	9118c293 	add	x19, x20, #0x630
    92a4:	aa1b03e0 	mov	x0, x27
    92a8:	97ffee7a 	bl	4c90 <fwp_mem_free>
    92ac:	f949ee62 	ldr	x2, [x19, #5080]
    92b0:	f949da61 	ldr	x1, [x19, #5040]
    92b4:	d370bc42 	lsl	x2, x2, #16
    92b8:	cb0102c3 	sub	x3, x22, x1
    92bc:	eb02007f 	cmp	x3, x2
    92c0:	54000402 	b.cs	9340 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    92c4:	d350fc60 	lsr	x0, x3, #16
    92c8:	f949fe65 	ldr	x5, [x19, #5112]
    92cc:	8b000800 	add	x0, x0, x0, lsl #2
    92d0:	d37df000 	lsl	x0, x0, #3
    92d4:	8b0000a2 	add	x2, x5, x0
    92d8:	f9401057 	ldr	x23, [x2, #32]
    92dc:	b4000cb7 	cbz	x23, 9470 <fwp_hof0.constprop.0+0x1070>
    92e0:	386068a1 	ldrb	w1, [x5, x0]
    92e4:	7100083f 	cmp	w1, #0x2
    92e8:	540031e0 	b.eq	9924 <fwp_hof0.constprop.0+0x1524>  // b.none
    92ec:	7100043f 	cmp	w1, #0x1
    92f0:	54000c01 	b.ne	9470 <fwp_hof0.constprop.0+0x1070>  // b.any
    92f4:	29430844 	ldp	w4, w2, [x2, #24]
    92f8:	92403c61 	and	x1, x3, #0xffff
    92fc:	9b047c21 	mul	x1, x1, x4
    9300:	d360fc21 	lsr	x1, x1, #32
    9304:	eb02003f 	cmp	x1, x2
    9308:	54000b42 	b.cs	9470 <fwp_hof0.constprop.0+0x1070>  // b.hs, b.nlast
    930c:	8b0102f7 	add	x23, x23, x1
    9310:	394002e1 	ldrb	w1, [x23]
    9314:	34000ae1 	cbz	w1, 9470 <fwp_hof0.constprop.0+0x1070>
    9318:	7100043f 	cmp	w1, #0x1
    931c:	540006a0 	b.eq	93f0 <fwp_hof0.constprop.0+0xff0>  // b.none
    9320:	7103fc3f 	cmp	w1, #0xff
    9324:	54005340 	b.eq	9d8c <fwp_hof0.constprop.0+0x198c>  // b.none
    9328:	9118c280 	add	x0, x20, #0x630
    932c:	51000421 	sub	w1, w1, #0x1
    9330:	390002e1 	strb	w1, [x23]
    9334:	f949ec02 	ldr	x2, [x0, #5080]
    9338:	f949d801 	ldr	x1, [x0, #5040]
    933c:	d370bc42 	lsl	x2, x2, #16
    9340:	cb0102a1 	sub	x1, x21, x1
    9344:	eb01005f 	cmp	x2, x1
    9348:	540003c9 	b.ls	93c0 <fwp_hof0.constprop.0+0xfc0>  // b.plast
    934c:	9118c296 	add	x22, x20, #0x630
    9350:	d350fc20 	lsr	x0, x1, #16
    9354:	f949fec3 	ldr	x3, [x22, #5112]
    9358:	8b000800 	add	x0, x0, x0, lsl #2
    935c:	d37df000 	lsl	x0, x0, #3
    9360:	8b000062 	add	x2, x3, x0
    9364:	f9401053 	ldr	x19, [x2, #32]
    9368:	b40002d3 	cbz	x19, 93c0 <fwp_hof0.constprop.0+0xfc0>
    936c:	38606860 	ldrb	w0, [x3, x0]
    9370:	7100081f 	cmp	w0, #0x2
    9374:	54003200 	b.eq	99b4 <fwp_hof0.constprop.0+0x15b4>  // b.none
    9378:	7100041f 	cmp	w0, #0x1
    937c:	54000221 	b.ne	93c0 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9380:	29430044 	ldp	w4, w0, [x2, #24]
    9384:	92403c21 	and	x1, x1, #0xffff
    9388:	9b047c21 	mul	x1, x1, x4
    938c:	d360fc21 	lsr	x1, x1, #32
    9390:	eb00003f 	cmp	x1, x0
    9394:	54000162 	b.cs	93c0 <fwp_hof0.constprop.0+0xfc0>  // b.hs, b.nlast
    9398:	8b010273 	add	x19, x19, x1
    939c:	39400260 	ldrb	w0, [x19]
    93a0:	34000100 	cbz	w0, 93c0 <fwp_hof0.constprop.0+0xfc0>
    93a4:	7100041f 	cmp	w0, #0x1
    93a8:	540038c0 	b.eq	9ac0 <fwp_hof0.constprop.0+0x16c0>  // b.none
    93ac:	7103fc1f 	cmp	w0, #0xff
    93b0:	54004b20 	b.eq	9d14 <fwp_hof0.constprop.0+0x1914>  // b.none
    93b4:	51000400 	sub	w0, w0, #0x1
    93b8:	39000260 	strb	w0, [x19]
    93bc:	d503201f 	nop
    93c0:	f94007e0 	ldr	x0, [sp, #8]
    93c4:	b4001a60 	cbz	x0, 9710 <fwp_hof0.constprop.0+0x1310>
    93c8:	f94007e0 	ldr	x0, [sp, #8]
    93cc:	f100041a 	subs	x26, x0, #0x1
    93d0:	f90007fa 	str	x26, [sp, #8]
    93d4:	54005da6 	b.vs	9f88 <fwp_hof0.constprop.0+0x1b88>
    93d8:	9118c280 	add	x0, x20, #0x630
    93dc:	aa1c03f5 	mov	x21, x28
    93e0:	f949ec03 	ldr	x3, [x0, #5080]
    93e4:	f949d801 	ldr	x1, [x0, #5040]
    93e8:	d370bc63 	lsl	x3, x3, #16
    93ec:	17fffc51 	b	8530 <fwp_hof0.constprop.0+0x130>
    93f0:	f94002c3 	ldr	x3, [x22]
    93f4:	aa1603e0 	mov	x0, x22
    93f8:	f949ee62 	ldr	x2, [x19, #5080]
    93fc:	f949da61 	ldr	x1, [x19, #5040]
    9400:	d370bc42 	lsl	x2, x2, #16
    9404:	cb0102c7 	sub	x7, x22, x1
    9408:	b7f82dc3 	tbnz	x3, #63, 99c0 <fwp_hof0.constprop.0+0x15c0>
    940c:	eb0200ff 	cmp	x7, x2
    9410:	54fff982 	b.cs	9340 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    9414:	d350fce3 	lsr	x3, x7, #16
    9418:	8b030863 	add	x3, x3, x3, lsl #2
    941c:	d37df063 	lsl	x3, x3, #3
    9420:	8b0300a6 	add	x6, x5, x3
    9424:	f94010c4 	ldr	x4, [x6, #32]
    9428:	b4fff8c4 	cbz	x4, 9340 <fwp_hof0.constprop.0+0xf40>
    942c:	386368a3 	ldrb	w3, [x5, x3]
    9430:	7100087f 	cmp	w3, #0x2
    9434:	54003960 	b.eq	9b60 <fwp_hof0.constprop.0+0x1760>  // b.none
    9438:	7100047f 	cmp	w3, #0x1
    943c:	54fff821 	b.ne	9340 <fwp_hof0.constprop.0+0xf40>  // b.any
    9440:	29430cc5 	ldp	w5, w3, [x6, #24]
    9444:	92403ce0 	and	x0, x7, #0xffff
    9448:	9b057c00 	mul	x0, x0, x5
    944c:	d360fc00 	lsr	x0, x0, #32
    9450:	eb03001f 	cmp	x0, x3
    9454:	54fff762 	b.cs	9340 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    9458:	8b000084 	add	x4, x4, x0
    945c:	39400080 	ldrb	w0, [x4]
    9460:	7100041f 	cmp	w0, #0x1
    9464:	54fff6e1 	b.ne	9340 <fwp_hof0.constprop.0+0xf40>  // b.any
    9468:	aa1603e0 	mov	x0, x22
    946c:	97ffee09 	bl	4c90 <fwp_mem_free>
    9470:	9118c280 	add	x0, x20, #0x630
    9474:	f949ec02 	ldr	x2, [x0, #5080]
    9478:	f949d801 	ldr	x1, [x0, #5040]
    947c:	d370bc42 	lsl	x2, x2, #16
    9480:	17ffffb0 	b	9340 <fwp_hof0.constprop.0+0xf40>
    9484:	aa1803e0 	mov	x0, x24
    9488:	97ffed62 	bl	4a10 <fwp_rc_forget_slot>
    948c:	17ffff6c 	b	923c <fwp_hof0.constprop.0+0xe3c>
    9490:	72003c3f 	tst	w1, #0xffff
    9494:	54ffed61 	b.ne	9240 <fwp_hof0.constprop.0+0xe40>  // b.any
    9498:	17ffff66 	b	9230 <fwp_hof0.constprop.0+0xe30>
    949c:	72003c1f 	tst	w0, #0xffff
    94a0:	54ffd840 	b.eq	8fa8 <fwp_hof0.constprop.0+0xba8>  // b.none
    94a4:	b4001235 	cbz	x21, 96e8 <fwp_hof0.constprop.0+0x12e8>
    94a8:	aa1503f3 	mov	x19, x21
    94ac:	d2800017 	mov	x23, #0x0                   	// #0
    94b0:	f9400a73 	ldr	x19, [x19, #16]
    94b4:	aa1703e0 	mov	x0, x23
    94b8:	910006f7 	add	x23, x23, #0x1
    94bc:	b5ffffb3 	cbnz	x19, 94b0 <fwp_hof0.constprop.0+0x10b0>
    94c0:	f9001be4 	str	x4, [sp, #48]
    94c4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    94c8:	eb0102ff 	cmp	x23, x1
    94cc:	540051e8 	b.hi	9f08 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    94d0:	91000800 	add	x0, x0, #0x2
    94d4:	52800041 	mov	w1, #0x2                   	// #2
    94d8:	d37df000 	lsl	x0, x0, #3
    94dc:	97ffef0d 	bl	5110 <fwp_heap_alloc>
    94e0:	f9401be4 	ldr	x4, [sp, #48]
    94e4:	aa0003fb 	mov	x27, x0
    94e8:	aa1503e1 	mov	x1, x21
    94ec:	eb0402ff 	cmp	x23, x4
    94f0:	9a8492e4 	csel	x4, x23, x4, ls	// ls = plast
    94f4:	d503201f 	nop
    94f8:	f9400420 	ldr	x0, [x1, #8]
    94fc:	f8337b60 	str	x0, [x27, x19, lsl #3]
    9500:	91000673 	add	x19, x19, #0x1
    9504:	f9400821 	ldr	x1, [x1, #16]
    9508:	b5ffff81 	cbnz	x1, 94f8 <fwp_hof0.constprop.0+0x10f8>
    950c:	b4000f64 	cbz	x4, 96f8 <fwp_hof0.constprop.0+0x12f8>
    9510:	f9400385 	ldr	x5, [x28]
    9514:	b90033ff 	str	wzr, [sp, #48]
    9518:	17fffeac 	b	8fc8 <fwp_hof0.constprop.0+0xbc8>
    951c:	d53bd040 	mrs	x0, tpidr_el0
    9520:	91400000 	add	x0, x0, #0x0, lsl #12
    9524:	91004000 	add	x0, x0, #0x10
    9528:	f9400000 	ldr	x0, [x0]
    952c:	b40028c0 	cbz	x0, 9a44 <fwp_hof0.constprop.0+0x1644>
    9530:	f94017e1 	ldr	x1, [sp, #40]
    9534:	97ffe8cc 	bl	3864 <fwp_closure_drop_push>
    9538:	b5ff8a75 	cbnz	x21, 8684 <fwp_hof0.constprop.0+0x284>
    953c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9540:	91014013 	add	x19, x0, #0x50
    9544:	d2800016 	mov	x22, #0x0                   	// #0
    9548:	b943c660 	ldr	w0, [x19, #964]
    954c:	35ff8b80 	cbnz	w0, 86bc <fwp_hof0.constprop.0+0x2bc>
    9550:	b0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x10>
    9554:	9109c000 	add	x0, x0, #0x270
    9558:	94000f6e 	bl	d310 <atexit>
    955c:	35ffc820 	cbnz	w0, 8e60 <fwp_hof0.constprop.0+0xa60>
    9560:	52800020 	mov	w0, #0x1                   	// #1
    9564:	b903c660 	str	w0, [x19, #964]
    9568:	f00000a0 	adrp	x0, 20000 <__data_start>
    956c:	91014000 	add	x0, x0, #0x50
    9570:	f9406c13 	ldr	x19, [x0, #216]
    9574:	f940b017 	ldr	x23, [x0, #352]
    9578:	eb1302ff 	cmp	x23, x19
    957c:	54ff8acb 	b.lt	86d4 <fwp_hof0.constprop.0+0x2d4>  // b.tstop
    9580:	eb1302ff 	cmp	x23, x19
    9584:	54ff8c40 	b.eq	870c <fwp_hof0.constprop.0+0x30c>  // b.none
    9588:	f00000a0 	adrp	x0, 20000 <__data_start>
    958c:	91014000 	add	x0, x0, #0x50
    9590:	8b1706fb 	add	x27, x23, x23, lsl #1
    9594:	f940441c 	ldr	x28, [x0, #136]
    9598:	8b1b0afb 	add	x27, x23, x27, lsl #2
    959c:	90000020 	adrp	x0, d000 <__modti3+0x60>
    95a0:	911d0000 	add	x0, x0, #0x740
    95a4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    95a8:	f900337f 	str	xzr, [x27, #96]
    95ac:	97ffe521 	bl	2a30 <getenv@plt>
    95b0:	b5ff90a0 	cbnz	x0, 87c4 <fwp_hof0.constprop.0+0x3c4>
    95b4:	f00000a0 	adrp	x0, 20000 <__data_start>
    95b8:	91014000 	add	x0, x0, #0x50
    95bc:	f9408c01 	ldr	x1, [x0, #280]
    95c0:	b4ff90c1 	cbz	x1, 87d8 <fwp_hof0.constprop.0+0x3d8>
    95c4:	ad470402 	ldp	q2, q1, [x0, #224]
    95c8:	91038001 	add	x1, x0, #0xe0
    95cc:	4f000400 	movi	v0.4s, #0x0
    95d0:	f9008c1f 	str	xzr, [x0, #280]
    95d4:	ad010762 	stp	q2, q1, [x27, #32]
    95d8:	a9500002 	ldp	x2, x0, [x0, #256]
    95dc:	f9000f60 	str	x0, [x27, #24]
    95e0:	f9401820 	ldr	x0, [x1, #48]
    95e4:	f9002362 	str	x2, [x27, #64]
    95e8:	f9002760 	str	x0, [x27, #72]
    95ec:	ad000020 	stp	q0, q0, [x1]
    95f0:	3d800820 	str	q0, [x1, #32]
    95f4:	f900183f 	str	xzr, [x1, #48]
    95f8:	17fffc78 	b	87d8 <fwp_hof0.constprop.0+0x3d8>
    95fc:	72003c1f 	tst	w0, #0xffff
    9600:	54ffbdc0 	b.eq	8db8 <fwp_hof0.constprop.0+0x9b8>  // b.none
    9604:	d503201f 	nop
    9608:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    960c:	eb0002ff 	cmp	x23, x0
    9610:	54004ae8 	b.hi	9f6c <fwp_hof0.constprop.0+0x1b6c>  // b.pmore
    9614:	910006e0 	add	x0, x23, #0x1
    9618:	52800021 	mov	w1, #0x1                   	// #1
    961c:	d37df000 	lsl	x0, x0, #3
    9620:	97ffeebc 	bl	5110 <fwp_heap_alloc>
    9624:	9118c282 	add	x2, x20, #0x630
    9628:	f9000017 	str	x23, [x0]
    962c:	aa0003fc 	mov	x28, x0
    9630:	aa0003f6 	mov	x22, x0
    9634:	f949d841 	ldr	x1, [x2, #5040]
    9638:	f949ec40 	ldr	x0, [x2, #5080]
    963c:	cb010381 	sub	x1, x28, x1
    9640:	eb00403f 	cmp	x1, x0, lsl #16
    9644:	54000322 	b.cs	96a8 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    9648:	d350fc20 	lsr	x0, x1, #16
    964c:	f949fc44 	ldr	x4, [x2, #5112]
    9650:	8b000800 	add	x0, x0, x0, lsl #2
    9654:	d37df002 	lsl	x2, x0, #3
    9658:	8b020083 	add	x3, x4, x2
    965c:	f9401078 	ldr	x24, [x3, #32]
    9660:	b4000258 	cbz	x24, 96a8 <fwp_hof0.constprop.0+0x12a8>
    9664:	38626882 	ldrb	w2, [x4, x2]
    9668:	7100085f 	cmp	w2, #0x2
    966c:	54002860 	b.eq	9b78 <fwp_hof0.constprop.0+0x1778>  // b.none
    9670:	7100045f 	cmp	w2, #0x1
    9674:	540001a1 	b.ne	96a8 <fwp_hof0.constprop.0+0x12a8>  // b.any
    9678:	29430864 	ldp	w4, w2, [x3, #24]
    967c:	92403c21 	and	x1, x1, #0xffff
    9680:	9b047c21 	mul	x1, x1, x4
    9684:	d360fc21 	lsr	x1, x1, #32
    9688:	eb02003f 	cmp	x1, x2
    968c:	540000e2 	b.cs	96a8 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    9690:	8b010318 	add	x24, x24, x1
    9694:	39400301 	ldrb	w1, [x24]
    9698:	7103fc3f 	cmp	w1, #0xff
    969c:	54002760 	b.eq	9b88 <fwp_hof0.constprop.0+0x1788>  // b.none
    96a0:	52800021 	mov	w1, #0x1                   	// #1
    96a4:	39000301 	strb	w1, [x24]
    96a8:	aa1303e0 	mov	x0, x19
    96ac:	17fffdc9 	b	8dd0 <fwp_hof0.constprop.0+0x9d0>
    96b0:	52800041 	mov	w1, #0x2                   	// #2
    96b4:	d2800100 	mov	x0, #0x8                   	// #8
    96b8:	97ffee96 	bl	5110 <fwp_heap_alloc>
    96bc:	aa0003f7 	mov	x23, x0
    96c0:	9118c280 	add	x0, x20, #0x630
    96c4:	aa1703fb 	mov	x27, x23
    96c8:	f90002ff 	str	xzr, [x23]
    96cc:	f949d801 	ldr	x1, [x0, #5040]
    96d0:	f949ec00 	ldr	x0, [x0, #5080]
    96d4:	cb0102e1 	sub	x1, x23, x1
    96d8:	eb00403f 	cmp	x1, x0, lsl #16
    96dc:	540011a2 	b.cs	9910 <fwp_hof0.constprop.0+0x1510>  // b.hs, b.nlast
    96e0:	d2800016 	mov	x22, #0x0                   	// #0
    96e4:	17fffc83 	b	88f0 <fwp_hof0.constprop.0+0x4f0>
    96e8:	52800041 	mov	w1, #0x2                   	// #2
    96ec:	d2800100 	mov	x0, #0x8                   	// #8
    96f0:	97ffee88 	bl	5110 <fwp_heap_alloc>
    96f4:	aa0003fb 	mov	x27, x0
    96f8:	d280001c 	mov	x28, #0x0                   	// #0
    96fc:	17fffee9 	b	92a0 <fwp_hof0.constprop.0+0xea0>
    9700:	f9001fe0 	str	x0, [sp, #56]
    9704:	97ffecc3 	bl	4a10 <fwp_rc_forget_slot>
    9708:	f9401fe0 	ldr	x0, [sp, #56]
    970c:	17fffe82 	b	9114 <fwp_hof0.constprop.0+0xd14>
    9710:	f9400be0 	ldr	x0, [sp, #16]
    9714:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe8e0>
    9718:	910ac042 	add	x2, x2, #0x2b0
    971c:	aa1c03e1 	mov	x1, x28
    9720:	91014042 	add	x2, x2, #0x50
    9724:	52800023 	mov	w3, #0x1                   	// #1
    9728:	a9097fff 	stp	xzr, xzr, [sp, #144]
    972c:	f90053ff 	str	xzr, [sp, #160]
    9730:	97fff738 	bl	7410 <fwp_write>
    9734:	a9495bf5 	ldp	x21, x22, [sp, #144]
    9738:	90000020 	adrp	x0, d000 <__modti3+0x60>
    973c:	910e0000 	add	x0, x0, #0x380
    9740:	f10002bf 	cmp	x21, #0x0
    9744:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    9748:	b1002adf 	cmn	x22, #0xa
    974c:	54004168 	b.hi	9f78 <fwp_hof0.constprop.0+0x1b78>  // b.pmore
    9750:	910026c0 	add	x0, x22, #0x9
    9754:	52800021 	mov	w1, #0x1                   	// #1
    9758:	97ffee6e 	bl	5110 <fwp_heap_alloc>
    975c:	aa0003f7 	mov	x23, x0
    9760:	aa0003f3 	mov	x19, x0
    9764:	aa1603e2 	mov	x2, x22
    9768:	aa1503e1 	mov	x1, x21
    976c:	f80086f6 	str	x22, [x23], #8
    9770:	8b160276 	add	x22, x19, x22
    9774:	aa1703e0 	mov	x0, x23
    9778:	97ffe3de 	bl	26f0 <memcpy@plt>
    977c:	390022df 	strb	wzr, [x22, #8]
    9780:	f9404be0 	ldr	x0, [sp, #144]
    9784:	97ffe477 	bl	2960 <free@plt>
    9788:	9118c281 	add	x1, x20, #0x630
    978c:	f949d822 	ldr	x2, [x1, #5040]
    9790:	f949ec20 	ldr	x0, [x1, #5080]
    9794:	cb020262 	sub	x2, x19, x2
    9798:	eb00405f 	cmp	x2, x0, lsl #16
    979c:	54000322 	b.cs	9800 <fwp_hof0.constprop.0+0x1400>  // b.hs, b.nlast
    97a0:	d350fc40 	lsr	x0, x2, #16
    97a4:	f949fc23 	ldr	x3, [x1, #5112]
    97a8:	8b000800 	add	x0, x0, x0, lsl #2
    97ac:	d37df001 	lsl	x1, x0, #3
    97b0:	8b010060 	add	x0, x3, x1
    97b4:	f9401015 	ldr	x21, [x0, #32]
    97b8:	b4000255 	cbz	x21, 9800 <fwp_hof0.constprop.0+0x1400>
    97bc:	38616861 	ldrb	w1, [x3, x1]
    97c0:	7100083f 	cmp	w1, #0x2
    97c4:	54002d40 	b.eq	9d6c <fwp_hof0.constprop.0+0x196c>  // b.none
    97c8:	7100043f 	cmp	w1, #0x1
    97cc:	540001a1 	b.ne	9800 <fwp_hof0.constprop.0+0x1400>  // b.any
    97d0:	29430003 	ldp	w3, w0, [x0, #24]
    97d4:	92403c41 	and	x1, x2, #0xffff
    97d8:	9b037c21 	mul	x1, x1, x3
    97dc:	d360fc21 	lsr	x1, x1, #32
    97e0:	eb00003f 	cmp	x1, x0
    97e4:	540000e2 	b.cs	9800 <fwp_hof0.constprop.0+0x1400>  // b.hs, b.nlast
    97e8:	8b0102b5 	add	x21, x21, x1
    97ec:	394002a0 	ldrb	w0, [x21]
    97f0:	7103fc1f 	cmp	w0, #0xff
    97f4:	54002c60 	b.eq	9d80 <fwp_hof0.constprop.0+0x1980>  // b.none
    97f8:	52800020 	mov	w0, #0x1                   	// #1
    97fc:	390002a0 	strb	w0, [x21]
    9800:	aa1c03e0 	mov	x0, x28
    9804:	97fff1a7 	bl	5ea0 <fwp_drop0>
    9808:	f00000a0 	adrp	x0, 20000 <__data_start>
    980c:	91014015 	add	x21, x0, #0x50
    9810:	f9400262 	ldr	x2, [x19]
    9814:	d2800021 	mov	x1, #0x1                   	// #1
    9818:	f9404aa3 	ldr	x3, [x21, #144]
    981c:	aa1703e0 	mov	x0, x23
    9820:	97ffe460 	bl	29a0 <fwrite@plt>
    9824:	f9404aa1 	ldr	x1, [x21, #144]
    9828:	52800140 	mov	w0, #0xa                   	// #10
    982c:	97ffe3e5 	bl	27c0 <fputc@plt>
    9830:	9118c281 	add	x1, x20, #0x630
    9834:	f949d822 	ldr	x2, [x1, #5040]
    9838:	f949ec20 	ldr	x0, [x1, #5080]
    983c:	cb020262 	sub	x2, x19, x2
    9840:	eb00405f 	cmp	x2, x0, lsl #16
    9844:	54000382 	b.cs	98b4 <fwp_hof0.constprop.0+0x14b4>  // b.hs, b.nlast
    9848:	d350fc40 	lsr	x0, x2, #16
    984c:	f949fc23 	ldr	x3, [x1, #5112]
    9850:	8b000800 	add	x0, x0, x0, lsl #2
    9854:	d37df001 	lsl	x1, x0, #3
    9858:	8b010060 	add	x0, x3, x1
    985c:	f9401015 	ldr	x21, [x0, #32]
    9860:	b40002b5 	cbz	x21, 98b4 <fwp_hof0.constprop.0+0x14b4>
    9864:	38616861 	ldrb	w1, [x3, x1]
    9868:	7100083f 	cmp	w1, #0x2
    986c:	54002460 	b.eq	9cf8 <fwp_hof0.constprop.0+0x18f8>  // b.none
    9870:	7100043f 	cmp	w1, #0x1
    9874:	54000201 	b.ne	98b4 <fwp_hof0.constprop.0+0x14b4>  // b.any
    9878:	29430003 	ldp	w3, w0, [x0, #24]
    987c:	92403c41 	and	x1, x2, #0xffff
    9880:	9b037c21 	mul	x1, x1, x3
    9884:	d360fc21 	lsr	x1, x1, #32
    9888:	eb00003f 	cmp	x1, x0
    988c:	54000142 	b.cs	98b4 <fwp_hof0.constprop.0+0x14b4>  // b.hs, b.nlast
    9890:	8b0102b5 	add	x21, x21, x1
    9894:	394002a0 	ldrb	w0, [x21]
    9898:	340000e0 	cbz	w0, 98b4 <fwp_hof0.constprop.0+0x14b4>
    989c:	7100041f 	cmp	w0, #0x1
    98a0:	54001da0 	b.eq	9c54 <fwp_hof0.constprop.0+0x1854>  // b.none
    98a4:	7103fc1f 	cmp	w0, #0xff
    98a8:	54002fe0 	b.eq	9ea4 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    98ac:	51000400 	sub	w0, w0, #0x1
    98b0:	390002a0 	strb	w0, [x21]
    98b4:	f94027e0 	ldr	x0, [sp, #72]
    98b8:	f9400800 	ldr	x0, [x0, #16]
    98bc:	f90027e0 	str	x0, [sp, #72]
    98c0:	b5ff5d80 	cbnz	x0, 8470 <fwp_hof0.constprop.0+0x70>
    98c4:	a94f53f3 	ldp	x19, x20, [sp, #240]
    98c8:	a9505bf5 	ldp	x21, x22, [sp, #256]
    98cc:	a95163f7 	ldp	x23, x24, [sp, #272]
    98d0:	a9526bf9 	ldp	x25, x26, [sp, #288]
    98d4:	a95373fb 	ldp	x27, x28, [sp, #304]
    98d8:	fd40a3e8 	ldr	d8, [sp, #320]
    98dc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    98e0:	f947f400 	ldr	x0, [x0, #4072]
    98e4:	f9406fe2 	ldr	x2, [sp, #216]
    98e8:	f9400001 	ldr	x1, [x0]
    98ec:	eb010042 	subs	x2, x2, x1
    98f0:	d2800001 	mov	x1, #0x0                   	// #0
    98f4:	54003101 	b.ne	9f14 <fwp_hof0.constprop.0+0x1b14>  // b.any
    98f8:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    98fc:	d2800000 	mov	x0, #0x0                   	// #0
    9900:	910543ff 	add	sp, sp, #0x150
    9904:	d65f03c0 	ret
    9908:	b5ff8296 	cbnz	x22, 8958 <fwp_hof0.constprop.0+0x558>
    990c:	d503201f 	nop
    9910:	d280001c 	mov	x28, #0x0                   	// #0
    9914:	17fffc38 	b	89f4 <fwp_hof0.constprop.0+0x5f4>
    9918:	72003c3f 	tst	w1, #0xffff
    991c:	54ff8b61 	b.ne	8a88 <fwp_hof0.constprop.0+0x688>  // b.any
    9920:	17fffc52 	b	8a68 <fwp_hof0.constprop.0+0x668>
    9924:	72003c7f 	tst	w3, #0xffff
    9928:	54ffda41 	b.ne	9470 <fwp_hof0.constprop.0+0x1070>  // b.any
    992c:	17fffe79 	b	9310 <fwp_hof0.constprop.0+0xf10>
    9930:	f940077b 	ldr	x27, [x27, #8]
    9934:	eb03005f 	cmp	x2, x3
    9938:	54000362 	b.cs	99a4 <fwp_hof0.constprop.0+0x15a4>  // b.hs, b.nlast
    993c:	d350fc45 	lsr	x5, x2, #16
    9940:	8b0508a5 	add	x5, x5, x5, lsl #2
    9944:	d37df0a5 	lsl	x5, x5, #3
    9948:	8b050087 	add	x7, x4, x5
    994c:	f94010e6 	ldr	x6, [x7, #32]
    9950:	b40002a6 	cbz	x6, 99a4 <fwp_hof0.constprop.0+0x15a4>
    9954:	38656884 	ldrb	w4, [x4, x5]
    9958:	7100089f 	cmp	w4, #0x2
    995c:	54001760 	b.eq	9c48 <fwp_hof0.constprop.0+0x1848>  // b.none
    9960:	7100049f 	cmp	w4, #0x1
    9964:	54000201 	b.ne	99a4 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9968:	294310e5 	ldp	w5, w4, [x7, #24]
    996c:	92403c42 	and	x2, x2, #0xffff
    9970:	9b057c42 	mul	x2, x2, x5
    9974:	d360fc42 	lsr	x2, x2, #32
    9978:	eb04005f 	cmp	x2, x4
    997c:	54000142 	b.cs	99a4 <fwp_hof0.constprop.0+0x15a4>  // b.hs, b.nlast
    9980:	8b0200c6 	add	x6, x6, x2
    9984:	394000c2 	ldrb	w2, [x6]
    9988:	7100045f 	cmp	w2, #0x1
    998c:	540000c1 	b.ne	99a4 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9990:	97ffecc0 	bl	4c90 <fwp_mem_free>
    9994:	9118c280 	add	x0, x20, #0x630
    9998:	f949ec03 	ldr	x3, [x0, #5080]
    999c:	f949d801 	ldr	x1, [x0, #5040]
    99a0:	d370bc63 	lsl	x3, x3, #16
    99a4:	cb010361 	sub	x1, x27, x1
    99a8:	eb03003f 	cmp	x1, x3
    99ac:	54ff8383 	b.cc	8a1c <fwp_hof0.constprop.0+0x61c>  // b.lo, b.ul, b.last
    99b0:	17fffc36 	b	8a88 <fwp_hof0.constprop.0+0x688>
    99b4:	72003c3f 	tst	w1, #0xffff
    99b8:	54ffd041 	b.ne	93c0 <fwp_hof0.constprop.0+0xfc0>  // b.any
    99bc:	17fffe78 	b	939c <fwp_hof0.constprop.0+0xf9c>
    99c0:	f94006d6 	ldr	x22, [x22, #8]
    99c4:	eb0200ff 	cmp	x7, x2
    99c8:	54000362 	b.cs	9a34 <fwp_hof0.constprop.0+0x1634>  // b.hs, b.nlast
    99cc:	d350fce3 	lsr	x3, x7, #16
    99d0:	8b030863 	add	x3, x3, x3, lsl #2
    99d4:	d37df063 	lsl	x3, x3, #3
    99d8:	8b0300a6 	add	x6, x5, x3
    99dc:	f94010c4 	ldr	x4, [x6, #32]
    99e0:	b40002a4 	cbz	x4, 9a34 <fwp_hof0.constprop.0+0x1634>
    99e4:	386368a3 	ldrb	w3, [x5, x3]
    99e8:	7100087f 	cmp	w3, #0x2
    99ec:	54001420 	b.eq	9c70 <fwp_hof0.constprop.0+0x1870>  // b.none
    99f0:	7100047f 	cmp	w3, #0x1
    99f4:	54000201 	b.ne	9a34 <fwp_hof0.constprop.0+0x1634>  // b.any
    99f8:	294314c8 	ldp	w8, w5, [x6, #24]
    99fc:	92403ce3 	and	x3, x7, #0xffff
    9a00:	9b087c63 	mul	x3, x3, x8
    9a04:	d360fc63 	lsr	x3, x3, #32
    9a08:	eb05007f 	cmp	x3, x5
    9a0c:	54000142 	b.cs	9a34 <fwp_hof0.constprop.0+0x1634>  // b.hs, b.nlast
    9a10:	8b030084 	add	x4, x4, x3
    9a14:	39400083 	ldrb	w3, [x4]
    9a18:	7100047f 	cmp	w3, #0x1
    9a1c:	540000c1 	b.ne	9a34 <fwp_hof0.constprop.0+0x1634>  // b.any
    9a20:	97ffec9c 	bl	4c90 <fwp_mem_free>
    9a24:	9118c280 	add	x0, x20, #0x630
    9a28:	f949ec02 	ldr	x2, [x0, #5080]
    9a2c:	f949d801 	ldr	x1, [x0, #5040]
    9a30:	d370bc42 	lsl	x2, x2, #16
    9a34:	cb0102c3 	sub	x3, x22, x1
    9a38:	eb02007f 	cmp	x3, x2
    9a3c:	54ffc443 	b.cc	92c4 <fwp_hof0.constprop.0+0xec4>  // b.lo, b.ul, b.last
    9a40:	17fffe40 	b	9340 <fwp_hof0.constprop.0+0xf40>
    9a44:	f94017e0 	ldr	x0, [sp, #40]
    9a48:	97ffe7f6 	bl	3a20 <fwp_closure_drop.part.0>
    9a4c:	17fffb0d 	b	8680 <fwp_hof0.constprop.0+0x280>
    9a50:	72003c3f 	tst	w1, #0xffff
    9a54:	54ff5ec1 	b.ne	862c <fwp_hof0.constprop.0+0x22c>  // b.any
    9a58:	aa1303e0 	mov	x0, x19
    9a5c:	17fffada 	b	85c4 <fwp_hof0.constprop.0+0x1c4>
    9a60:	72003c3f 	tst	w1, #0xffff
    9a64:	54ff60e1 	b.ne	8680 <fwp_hof0.constprop.0+0x280>  // b.any
    9a68:	17fffafd 	b	865c <fwp_hof0.constprop.0+0x25c>
    9a6c:	72003c3f 	tst	w1, #0xffff
    9a70:	54ff7721 	b.ne	8954 <fwp_hof0.constprop.0+0x554>  // b.any
    9a74:	39400380 	ldrb	w0, [x28]
    9a78:	7103fc1f 	cmp	w0, #0xff
    9a7c:	54ff7681 	b.ne	894c <fwp_hof0.constprop.0+0x54c>  // b.any
    9a80:	aa1c03e0 	mov	x0, x28
    9a84:	97ffebe3 	bl	4a10 <fwp_rc_forget_slot>
    9a88:	17fffbb1 	b	894c <fwp_hof0.constprop.0+0x54c>
    9a8c:	aa1803f6 	mov	x22, x24
    9a90:	17fffc32 	b	8b58 <fwp_hof0.constprop.0+0x758>
    9a94:	72003c3f 	tst	w1, #0xffff
    9a98:	54ff9461 	b.ne	8d24 <fwp_hof0.constprop.0+0x924>  // b.any
    9a9c:	394002c0 	ldrb	w0, [x22]
    9aa0:	7103fc1f 	cmp	w0, #0xff
    9aa4:	54ff93c1 	b.ne	8d1c <fwp_hof0.constprop.0+0x91c>  // b.any
    9aa8:	aa1603e0 	mov	x0, x22
    9aac:	97ffebd9 	bl	4a10 <fwp_rc_forget_slot>
    9ab0:	17fffc9b 	b	8d1c <fwp_hof0.constprop.0+0x91c>
    9ab4:	72003c5f 	tst	w2, #0xffff
    9ab8:	54ff7e81 	b.ne	8a88 <fwp_hof0.constprop.0+0x688>  // b.any
    9abc:	17fffd10 	b	8efc <fwp_hof0.constprop.0+0xafc>
    9ac0:	9118c280 	add	x0, x20, #0x630
    9ac4:	f9400ab3 	ldr	x19, [x21, #16]
    9ac8:	f949ec04 	ldr	x4, [x0, #5080]
    9acc:	f949d801 	ldr	x1, [x0, #5040]
    9ad0:	d370bc84 	lsl	x4, x4, #16
    9ad4:	cb0102a0 	sub	x0, x21, x1
    9ad8:	eb04001f 	cmp	x0, x4
    9adc:	54000382 	b.cs	9b4c <fwp_hof0.constprop.0+0x174c>  // b.hs, b.nlast
    9ae0:	d350fc02 	lsr	x2, x0, #16
    9ae4:	8b020842 	add	x2, x2, x2, lsl #2
    9ae8:	d37df042 	lsl	x2, x2, #3
    9aec:	8b020066 	add	x6, x3, x2
    9af0:	f94010c5 	ldr	x5, [x6, #32]
    9af4:	b40002c5 	cbz	x5, 9b4c <fwp_hof0.constprop.0+0x174c>
    9af8:	38626862 	ldrb	w2, [x3, x2]
    9afc:	7100085f 	cmp	w2, #0x2
    9b00:	54000be0 	b.eq	9c7c <fwp_hof0.constprop.0+0x187c>  // b.none
    9b04:	7100045f 	cmp	w2, #0x1
    9b08:	54000221 	b.ne	9b4c <fwp_hof0.constprop.0+0x174c>  // b.any
    9b0c:	294308c3 	ldp	w3, w2, [x6, #24]
    9b10:	92403c00 	and	x0, x0, #0xffff
    9b14:	9b037c00 	mul	x0, x0, x3
    9b18:	d360fc00 	lsr	x0, x0, #32
    9b1c:	eb02001f 	cmp	x0, x2
    9b20:	54000162 	b.cs	9b4c <fwp_hof0.constprop.0+0x174c>  // b.hs, b.nlast
    9b24:	8b0000a5 	add	x5, x5, x0
    9b28:	394000a0 	ldrb	w0, [x5]
    9b2c:	7100041f 	cmp	w0, #0x1
    9b30:	540000e1 	b.ne	9b4c <fwp_hof0.constprop.0+0x174c>  // b.any
    9b34:	aa1503e0 	mov	x0, x21
    9b38:	97ffec56 	bl	4c90 <fwp_mem_free>
    9b3c:	9118c280 	add	x0, x20, #0x630
    9b40:	f949ec04 	ldr	x4, [x0, #5080]
    9b44:	f949d801 	ldr	x1, [x0, #5040]
    9b48:	d370bc84 	lsl	x4, x4, #16
    9b4c:	cb010261 	sub	x1, x19, x1
    9b50:	eb01009f 	cmp	x4, x1
    9b54:	54ffc369 	b.ls	93c0 <fwp_hof0.constprop.0+0xfc0>  // b.plast
    9b58:	aa1303f5 	mov	x21, x19
    9b5c:	17fffdfd 	b	9350 <fwp_hof0.constprop.0+0xf50>
    9b60:	72003cff 	tst	w7, #0xffff
    9b64:	54ffbee1 	b.ne	9340 <fwp_hof0.constprop.0+0xf40>  // b.any
    9b68:	17fffe3d 	b	945c <fwp_hof0.constprop.0+0x105c>
    9b6c:	d2800019 	mov	x25, #0x0                   	// #0
    9b70:	52800020 	mov	w0, #0x1                   	// #1
    9b74:	17fffcb2 	b	8e3c <fwp_hof0.constprop.0+0xa3c>
    9b78:	72003c3f 	tst	w1, #0xffff
    9b7c:	54ffd8c0 	b.eq	9694 <fwp_hof0.constprop.0+0x1294>  // b.none
    9b80:	aa1303e0 	mov	x0, x19
    9b84:	17fffc93 	b	8dd0 <fwp_hof0.constprop.0+0x9d0>
    9b88:	aa1803e0 	mov	x0, x24
    9b8c:	97ffeba1 	bl	4a10 <fwp_rc_forget_slot>
    9b90:	17fffec4 	b	96a0 <fwp_hof0.constprop.0+0x12a0>
    9b94:	d10006e1 	sub	x1, x23, #0x1
    9b98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9b9c:	eb00003f 	cmp	x1, x0
    9ba0:	54001e08 	b.hi	9f60 <fwp_hof0.constprop.0+0x1b60>  // b.pmore
    9ba4:	f00002a3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fbb0>
    9ba8:	d2800000 	mov	x0, #0x0                   	// #0
    9bac:	91114061 	add	x1, x3, #0x450
    9bb0:	14000005 	b	9bc4 <fwp_hof0.constprop.0+0x17c4>
    9bb4:	91000400 	add	x0, x0, #0x1
    9bb8:	91006021 	add	x1, x1, #0x18
    9bbc:	f140041f 	cmp	x0, #0x1, lsl #12
    9bc0:	54001500 	b.eq	9e60 <fwp_hof0.constprop.0+0x1a60>  // b.none
    9bc4:	f9400022 	ldr	x2, [x1]
    9bc8:	b5ffff62 	cbnz	x2, 9bb4 <fwp_hof0.constprop.0+0x17b4>
    9bcc:	8b000402 	add	x2, x0, x0, lsl #1
    9bd0:	91114063 	add	x3, x3, #0x450
    9bd4:	aa1703e0 	mov	x0, x23
    9bd8:	d2800101 	mov	x1, #0x8                   	// #8
    9bdc:	8b020c73 	add	x19, x3, x2, lsl #3
    9be0:	a90327e8 	stp	x8, x9, [sp, #48]
    9be4:	97ffe327 	bl	2880 <calloc@plt>
    9be8:	a94327e8 	ldp	x8, x9, [sp, #48]
    9bec:	aa0003f9 	mov	x25, x0
    9bf0:	b4fffbe0 	cbz	x0, 9b6c <fwp_hof0.constprop.0+0x176c>
    9bf4:	aa1303e0 	mov	x0, x19
    9bf8:	d37df2e2 	lsl	x2, x23, #3
    9bfc:	aa1903e1 	mov	x1, x25
    9c00:	52800063 	mov	w3, #0x3                   	// #3
    9c04:	a90327e8 	stp	x8, x9, [sp, #48]
    9c08:	97ffe4e2 	bl	2f90 <ad_raw_record>
    9c0c:	a94327e8 	ldp	x8, x9, [sp, #48]
    9c10:	17fffbe6 	b	8ba8 <fwp_hof0.constprop.0+0x7a8>
    9c14:	f9400385 	ldr	x5, [x28]
    9c18:	b7ffd685 	tbnz	x5, #63, 96e8 <fwp_hof0.constprop.0+0x12e8>
    9c1c:	9118c281 	add	x1, x20, #0x630
    9c20:	f949d820 	ldr	x0, [x1, #5040]
    9c24:	f949ec21 	ldr	x1, [x1, #5080]
    9c28:	cb0002c0 	sub	x0, x22, x0
    9c2c:	eb01401f 	cmp	x0, x1, lsl #16
    9c30:	54ffd5c2 	b.cs	96e8 <fwp_hof0.constprop.0+0x12e8>  // b.hs, b.nlast
    9c34:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    9c38:	17fffcc8 	b	8f58 <fwp_hof0.constprop.0+0xb58>
    9c3c:	d2800d01 	mov	x1, #0x68                  	// #104
    9c40:	d280003b 	mov	x27, #0x1                   	// #1
    9c44:	17fffac3 	b	8750 <fwp_hof0.constprop.0+0x350>
    9c48:	72003c5f 	tst	w2, #0xffff
    9c4c:	54ffeac1 	b.ne	99a4 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9c50:	17ffff4d 	b	9984 <fwp_hof0.constprop.0+0x1584>
    9c54:	aa1303e0 	mov	x0, x19
    9c58:	97ffef5f 	bl	59d4 <fwp_rc_free_arr>
    9c5c:	f94027e0 	ldr	x0, [sp, #72]
    9c60:	f9400800 	ldr	x0, [x0, #16]
    9c64:	f90027e0 	str	x0, [sp, #72]
    9c68:	b5ff4040 	cbnz	x0, 8470 <fwp_hof0.constprop.0+0x70>
    9c6c:	17ffff16 	b	98c4 <fwp_hof0.constprop.0+0x14c4>
    9c70:	72003cff 	tst	w7, #0xffff
    9c74:	54ffee01 	b.ne	9a34 <fwp_hof0.constprop.0+0x1634>  // b.any
    9c78:	17ffff67 	b	9a14 <fwp_hof0.constprop.0+0x1614>
    9c7c:	72003c1f 	tst	w0, #0xffff
    9c80:	54fff661 	b.ne	9b4c <fwp_hof0.constprop.0+0x174c>  // b.any
    9c84:	17ffffa9 	b	9b28 <fwp_hof0.constprop.0+0x1728>
    9c88:	72003c9f 	tst	w4, #0xffff
    9c8c:	54ff44c1 	b.ne	8524 <fwp_hof0.constprop.0+0x124>  // b.any
    9c90:	17fffa13 	b	84dc <fwp_hof0.constprop.0+0xdc>
    9c94:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9c98:	9118c281 	add	x1, x20, #0x630
    9c9c:	ca402400 	eor	x0, x0, x0, lsr #9
    9ca0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ca4:	f94a2400 	ldr	x0, [x0, #5192]
    9ca8:	b5000080 	cbnz	x0, 9cb8 <fwp_hof0.constprop.0+0x18b8>
    9cac:	14000010 	b	9cec <fwp_hof0.constprop.0+0x18ec>
    9cb0:	f9400800 	ldr	x0, [x0, #16]
    9cb4:	b40001c0 	cbz	x0, 9cec <fwp_hof0.constprop.0+0x18ec>
    9cb8:	f9400001 	ldr	x1, [x0]
    9cbc:	eb17003f 	cmp	x1, x23
    9cc0:	54ffff81 	b.ne	9cb0 <fwp_hof0.constprop.0+0x18b0>  // b.any
    9cc4:	f9400401 	ldr	x1, [x0, #8]
    9cc8:	d1000421 	sub	x1, x1, #0x1
    9ccc:	f9000401 	str	x1, [x0, #8]
    9cd0:	f103f83f 	cmp	x1, #0xfe
    9cd4:	54ff6da1 	b.ne	8a88 <fwp_hof0.constprop.0+0x688>  // b.any
    9cd8:	aa1703e0 	mov	x0, x23
    9cdc:	97ffeb4d 	bl	4a10 <fwp_rc_forget_slot>
    9ce0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ce4:	390002e0 	strb	w0, [x23]
    9ce8:	17fffb68 	b	8a88 <fwp_hof0.constprop.0+0x688>
    9cec:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9cf0:	91200000 	add	x0, x0, #0x800
    9cf4:	97ffe6c3 	bl	3800 <fwp_trap>
    9cf8:	72003c5f 	tst	w2, #0xffff
    9cfc:	54ffdcc0 	b.eq	9894 <fwp_hof0.constprop.0+0x1494>  // b.none
    9d00:	f94027e0 	ldr	x0, [sp, #72]
    9d04:	f9400800 	ldr	x0, [x0, #16]
    9d08:	f90027e0 	str	x0, [sp, #72]
    9d0c:	b5ff3b20 	cbnz	x0, 8470 <fwp_hof0.constprop.0+0x70>
    9d10:	17fffeed 	b	98c4 <fwp_hof0.constprop.0+0x14c4>
    9d14:	ca534660 	eor	x0, x19, x19, lsr #17
    9d18:	9118c281 	add	x1, x20, #0x630
    9d1c:	ca402400 	eor	x0, x0, x0, lsr #9
    9d20:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d24:	f94a2400 	ldr	x0, [x0, #5192]
    9d28:	b5000080 	cbnz	x0, 9d38 <fwp_hof0.constprop.0+0x1938>
    9d2c:	17fffff0 	b	9cec <fwp_hof0.constprop.0+0x18ec>
    9d30:	f9400800 	ldr	x0, [x0, #16]
    9d34:	b4fffdc0 	cbz	x0, 9cec <fwp_hof0.constprop.0+0x18ec>
    9d38:	f9400001 	ldr	x1, [x0]
    9d3c:	eb01027f 	cmp	x19, x1
    9d40:	54ffff81 	b.ne	9d30 <fwp_hof0.constprop.0+0x1930>  // b.any
    9d44:	f9400401 	ldr	x1, [x0, #8]
    9d48:	d1000421 	sub	x1, x1, #0x1
    9d4c:	f9000401 	str	x1, [x0, #8]
    9d50:	f103f83f 	cmp	x1, #0xfe
    9d54:	54ffb361 	b.ne	93c0 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9d58:	aa1303e0 	mov	x0, x19
    9d5c:	97ffeb2d 	bl	4a10 <fwp_rc_forget_slot>
    9d60:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d64:	39000260 	strb	w0, [x19]
    9d68:	17fffd96 	b	93c0 <fwp_hof0.constprop.0+0xfc0>
    9d6c:	72003c5f 	tst	w2, #0xffff
    9d70:	54ffd481 	b.ne	9800 <fwp_hof0.constprop.0+0x1400>  // b.any
    9d74:	394002a0 	ldrb	w0, [x21]
    9d78:	7103fc1f 	cmp	w0, #0xff
    9d7c:	54ffd3e1 	b.ne	97f8 <fwp_hof0.constprop.0+0x13f8>  // b.any
    9d80:	aa1503e0 	mov	x0, x21
    9d84:	97ffeb23 	bl	4a10 <fwp_rc_forget_slot>
    9d88:	17fffe9c 	b	97f8 <fwp_hof0.constprop.0+0x13f8>
    9d8c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9d90:	9118c281 	add	x1, x20, #0x630
    9d94:	ca402400 	eor	x0, x0, x0, lsr #9
    9d98:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d9c:	f94a2401 	ldr	x1, [x0, #5192]
    9da0:	b5000081 	cbnz	x1, 9db0 <fwp_hof0.constprop.0+0x19b0>
    9da4:	17ffffd2 	b	9cec <fwp_hof0.constprop.0+0x18ec>
    9da8:	f9400821 	ldr	x1, [x1, #16]
    9dac:	b4fffa01 	cbz	x1, 9cec <fwp_hof0.constprop.0+0x18ec>
    9db0:	f9400020 	ldr	x0, [x1]
    9db4:	eb17001f 	cmp	x0, x23
    9db8:	54ffff81 	b.ne	9da8 <fwp_hof0.constprop.0+0x19a8>  // b.any
    9dbc:	f9400420 	ldr	x0, [x1, #8]
    9dc0:	d1000400 	sub	x0, x0, #0x1
    9dc4:	f9000420 	str	x0, [x1, #8]
    9dc8:	f103f81f 	cmp	x0, #0xfe
    9dcc:	54ffb521 	b.ne	9470 <fwp_hof0.constprop.0+0x1070>  // b.any
    9dd0:	aa1703e0 	mov	x0, x23
    9dd4:	97ffeb0f 	bl	4a10 <fwp_rc_forget_slot>
    9dd8:	9118c280 	add	x0, x20, #0x630
    9ddc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9de0:	390002e1 	strb	w1, [x23]
    9de4:	f949ec02 	ldr	x2, [x0, #5080]
    9de8:	f949d801 	ldr	x1, [x0, #5040]
    9dec:	d370bc42 	lsl	x2, x2, #16
    9df0:	17fffd54 	b	9340 <fwp_hof0.constprop.0+0xf40>
    9df4:	d280001b 	mov	x27, #0x0                   	// #0
    9df8:	d280001c 	mov	x28, #0x0                   	// #0
    9dfc:	17fffd29 	b	92a0 <fwp_hof0.constprop.0+0xea0>
    9e00:	97ffeabd 	bl	48f4 <fwp_rc_wide_dup>
    9e04:	17fff9fd 	b	85f8 <fwp_hof0.constprop.0+0x1f8>
    9e08:	ca534660 	eor	x0, x19, x19, lsr #17
    9e0c:	9118c281 	add	x1, x20, #0x630
    9e10:	ca402400 	eor	x0, x0, x0, lsr #9
    9e14:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e18:	f94a2400 	ldr	x0, [x0, #5192]
    9e1c:	b5000080 	cbnz	x0, 9e2c <fwp_hof0.constprop.0+0x1a2c>
    9e20:	17ffffb3 	b	9cec <fwp_hof0.constprop.0+0x18ec>
    9e24:	f9400800 	ldr	x0, [x0, #16]
    9e28:	b4fff620 	cbz	x0, 9cec <fwp_hof0.constprop.0+0x18ec>
    9e2c:	f9400001 	ldr	x1, [x0]
    9e30:	eb01027f 	cmp	x19, x1
    9e34:	54ffff81 	b.ne	9e24 <fwp_hof0.constprop.0+0x1a24>  // b.any
    9e38:	f9400401 	ldr	x1, [x0, #8]
    9e3c:	d1000421 	sub	x1, x1, #0x1
    9e40:	f9000401 	str	x1, [x0, #8]
    9e44:	f103f83f 	cmp	x1, #0xfe
    9e48:	54ff41c1 	b.ne	8680 <fwp_hof0.constprop.0+0x280>  // b.any
    9e4c:	aa1303e0 	mov	x0, x19
    9e50:	97ffeaf0 	bl	4a10 <fwp_rc_forget_slot>
    9e54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e58:	39000260 	strb	w0, [x19]
    9e5c:	17fffa09 	b	8680 <fwp_hof0.constprop.0+0x280>
    9e60:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9e64:	911ba000 	add	x0, x0, #0x6e8
    9e68:	97ffe546 	bl	3380 <ad_raw_fail>
    9e6c:	d2800017 	mov	x23, #0x0                   	// #0
    9e70:	17fffc97 	b	90cc <fwp_hof0.constprop.0+0xccc>
    9e74:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9e78:	91238000 	add	x0, x0, #0x8e0
    9e7c:	97ffe661 	bl	3800 <fwp_trap>
    9e80:	97ffea9d 	bl	48f4 <fwp_rc_wide_dup>
    9e84:	9118c280 	add	x0, x20, #0x630
    9e88:	f949ec03 	ldr	x3, [x0, #5080]
    9e8c:	f949d801 	ldr	x1, [x0, #5040]
    9e90:	d370bc63 	lsl	x3, x3, #16
    9e94:	17fff9a4 	b	8524 <fwp_hof0.constprop.0+0x124>
    9e98:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9e9c:	91212000 	add	x0, x0, #0x848
    9ea0:	97ffe658 	bl	3800 <fwp_trap>
    9ea4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9ea8:	9118c281 	add	x1, x20, #0x630
    9eac:	ca402400 	eor	x0, x0, x0, lsr #9
    9eb0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9eb4:	f94a2400 	ldr	x0, [x0, #5192]
    9eb8:	b5000080 	cbnz	x0, 9ec8 <fwp_hof0.constprop.0+0x1ac8>
    9ebc:	17ffff8c 	b	9cec <fwp_hof0.constprop.0+0x18ec>
    9ec0:	f9400800 	ldr	x0, [x0, #16]
    9ec4:	b4fff140 	cbz	x0, 9cec <fwp_hof0.constprop.0+0x18ec>
    9ec8:	f9400001 	ldr	x1, [x0]
    9ecc:	eb0102bf 	cmp	x21, x1
    9ed0:	54ffff81 	b.ne	9ec0 <fwp_hof0.constprop.0+0x1ac0>  // b.any
    9ed4:	f9400401 	ldr	x1, [x0, #8]
    9ed8:	d1000421 	sub	x1, x1, #0x1
    9edc:	f9000401 	str	x1, [x0, #8]
    9ee0:	f103f83f 	cmp	x1, #0xfe
    9ee4:	54ffce81 	b.ne	98b4 <fwp_hof0.constprop.0+0x14b4>  // b.any
    9ee8:	aa1503e0 	mov	x0, x21
    9eec:	97ffeac9 	bl	4a10 <fwp_rc_forget_slot>
    9ef0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ef4:	390002a0 	strb	w0, [x21]
    9ef8:	17fffe6f 	b	98b4 <fwp_hof0.constprop.0+0x14b4>
    9efc:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f00:	912b0000 	add	x0, x0, #0xac0
    9f04:	97ffe63f 	bl	3800 <fwp_trap>
    9f08:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f0c:	91250000 	add	x0, x0, #0x940
    9f10:	97ffe63c 	bl	3800 <fwp_trap>
    9f14:	a90f53f3 	stp	x19, x20, [sp, #240]
    9f18:	a9105bf5 	stp	x21, x22, [sp, #256]
    9f1c:	a91163f7 	stp	x23, x24, [sp, #272]
    9f20:	a9126bf9 	stp	x25, x26, [sp, #288]
    9f24:	a91373fb 	stp	x27, x28, [sp, #304]
    9f28:	fd00a3e8 	str	d8, [sp, #320]
    9f2c:	97ffe25d 	bl	28a0 <__stack_chk_fail@plt>
    9f30:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f34:	91224000 	add	x0, x0, #0x890
    9f38:	97ffe632 	bl	3800 <fwp_trap>
    9f3c:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f40:	91290000 	add	x0, x0, #0xa40
    9f44:	97ffe62f 	bl	3800 <fwp_trap>
    9f48:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f4c:	91298000 	add	x0, x0, #0xa60
    9f50:	97ffe62c 	bl	3800 <fwp_trap>
    9f54:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f58:	912c0000 	add	x0, x0, #0xb00
    9f5c:	97ffe629 	bl	3800 <fwp_trap>
    9f60:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f64:	912a4000 	add	x0, x0, #0xa90
    9f68:	97ffe506 	bl	3380 <ad_raw_fail>
    9f6c:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f70:	912ac000 	add	x0, x0, #0xab0
    9f74:	97ffe623 	bl	3800 <fwp_trap>
    9f78:	90000020 	adrp	x0, d000 <__modti3+0x60>
    9f7c:	912ba000 	add	x0, x0, #0xae8
    9f80:	97ffe620 	bl	3800 <fwp_trap>
    9f84:	97ffe25b 	bl	28f0 <abort@plt>
    9f88:	97ffe2be 	bl	2a80 <fwp_trap_overflow.constprop.0>
    9f8c:	d503201f 	nop

0000000000009f90 <f0>:
    9f90:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9f94:	910003fd 	mov	x29, sp
    9f98:	a90153f3 	stp	x19, x20, [sp, #16]
    9f9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9fa0:	a90363f7 	stp	x23, x24, [sp, #48]
    9fa4:	a9046bf9 	stp	x25, x26, [sp, #64]
    9fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    9fac:	d12183ff 	sub	sp, sp, #0x860
    9fb0:	f90203ff 	str	xzr, [sp, #1024]
    9fb4:	f00000a0 	adrp	x0, 20000 <__data_start>
    9fb8:	91014005 	add	x5, x0, #0x50
    9fbc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    9fc0:	f947f400 	ldr	x0, [x0, #4072]
    9fc4:	90000394 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    9fc8:	f941c8a6 	ldr	x6, [x5, #912]
    9fcc:	f9400001 	ldr	x1, [x0]
    9fd0:	f9042fe1 	str	x1, [sp, #2136]
    9fd4:	d2800001 	mov	x1, #0x0                   	// #0
    9fd8:	9118c298 	add	x24, x20, #0x630
    9fdc:	912123f6 	add	x22, sp, #0x848
    9fe0:	910023e0 	add	x0, sp, #0x8
    9fe4:	910083e2 	add	x2, sp, #0x20
    9fe8:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc_slow+0x50>
    9fec:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9ff0:	91354021 	add	x1, x1, #0xd50
    9ff4:	913d4084 	add	x4, x4, #0xf50
    9ff8:	d2800013 	mov	x19, #0x0                   	// #0
    9ffc:	d2800119 	mov	x25, #0x8                   	// #8
    a000:	d2800015 	mov	x21, #0x0                   	// #0
    a004:	52800037 	mov	w23, #0x1                   	// #1
    a008:	a90093e6 	stp	x6, x4, [sp, #8]
    a00c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a010:	a90307ff 	stp	xzr, x1, [sp, #48]
    a014:	f901c8a0 	str	x0, [x5, #912]
    a018:	f100073a 	subs	x26, x25, #0x1
    a01c:	aa1603e1 	mov	x1, x22
    a020:	da1f02bc 	sbc	x28, x21, xzr
    a024:	52800020 	mov	w0, #0x1                   	// #1
    a028:	f90017fa 	str	x26, [sp, #40]
    a02c:	aa1a03f9 	mov	x25, x26
    a030:	f90427fa 	str	x26, [sp, #2120]
    a034:	aa1c03f5 	mov	x21, x28
    a038:	f9042bf3 	str	x19, [sp, #2128]
    a03c:	97ffec96 	bl	5294 <fwp_data.part.0.constprop.0>
    a040:	f949db02 	ldr	x2, [x24, #5040]
    a044:	aa0003f3 	mov	x19, x0
    a048:	f949ef00 	ldr	x0, [x24, #5080]
    a04c:	cb020262 	sub	x2, x19, x2
    a050:	eb00405f 	cmp	x2, x0, lsl #16
    a054:	54000302 	b.cs	a0b4 <f0+0x124>  // b.hs, b.nlast
    a058:	d350fc40 	lsr	x0, x2, #16
    a05c:	f949ff04 	ldr	x4, [x24, #5112]
    a060:	8b000800 	add	x0, x0, x0, lsl #2
    a064:	d37df001 	lsl	x1, x0, #3
    a068:	8b010080 	add	x0, x4, x1
    a06c:	f940101b 	ldr	x27, [x0, #32]
    a070:	b400023b 	cbz	x27, a0b4 <f0+0x124>
    a074:	38616881 	ldrb	w1, [x4, x1]
    a078:	7100083f 	cmp	w1, #0x2
    a07c:	54011140 	b.eq	c2a4 <f0+0x2314>  // b.none
    a080:	7100043f 	cmp	w1, #0x1
    a084:	54000181 	b.ne	a0b4 <f0+0x124>  // b.any
    a088:	29430001 	ldp	w1, w0, [x0, #24]
    a08c:	92403c42 	and	x2, x2, #0xffff
    a090:	9b017c42 	mul	x2, x2, x1
    a094:	d360fc42 	lsr	x2, x2, #32
    a098:	eb00005f 	cmp	x2, x0
    a09c:	540000c2 	b.cs	a0b4 <f0+0x124>  // b.hs, b.nlast
    a0a0:	8b02037b 	add	x27, x27, x2
    a0a4:	39400360 	ldrb	w0, [x27]
    a0a8:	7103fc1f 	cmp	w0, #0xff
    a0ac:	54010f60 	b.eq	c298 <f0+0x2308>  // b.none
    a0b0:	39000377 	strb	w23, [x27]
    a0b4:	f90013f3 	str	x19, [sp, #32]
    a0b8:	aa1c035a 	orr	x26, x26, x28
    a0bc:	b5fffafa 	cbnz	x26, a018 <f0+0x88>
    a0c0:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xcc0>
    a0c4:	910103e1 	add	x1, sp, #0x40
    a0c8:	f94007e2 	ldr	x2, [sp, #8]
    a0cc:	d00000a0 	adrp	x0, 20000 <__data_start>
    a0d0:	3dc0c860 	ldr	q0, [x3, #800]
    a0d4:	91014018 	add	x24, x0, #0x50
    a0d8:	52800020 	mov	w0, #0x1                   	// #1
    a0dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a0e0:	3d8013e0 	str	q0, [sp, #64]
    a0e4:	f901cb02 	str	x2, [x24, #912]
    a0e8:	97ffec6b 	bl	5294 <fwp_data.part.0.constprop.0>
    a0ec:	97ffee0a 	bl	5914 <fwp_rc_fresh>
    a0f0:	aa0003e2 	mov	x2, x0
    a0f4:	910163e1 	add	x1, sp, #0x58
    a0f8:	52800020 	mov	w0, #0x1                   	// #1
    a0fc:	a9058bf5 	stp	x21, x2, [sp, #88]
    a100:	97ffec65 	bl	5294 <fwp_data.part.0.constprop.0>
    a104:	97ffee04 	bl	5914 <fwp_rc_fresh>
    a108:	aa0003e2 	mov	x2, x0
    a10c:	9101a3e1 	add	x1, sp, #0x68
    a110:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a114:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a118:	52800020 	mov	w0, #0x1                   	// #1
    a11c:	a9068be3 	stp	x3, x2, [sp, #104]
    a120:	97ffec5d 	bl	5294 <fwp_data.part.0.constprop.0>
    a124:	97ffedfc 	bl	5914 <fwp_rc_fresh>
    a128:	aa0003e2 	mov	x2, x0
    a12c:	9101e3e1 	add	x1, sp, #0x78
    a130:	52800020 	mov	w0, #0x1                   	// #1
    a134:	a9078bf5 	stp	x21, x2, [sp, #120]
    a138:	97ffec57 	bl	5294 <fwp_data.part.0.constprop.0>
    a13c:	97ffedf6 	bl	5914 <fwp_rc_fresh>
    a140:	aa0003e2 	mov	x2, x0
    a144:	910223e1 	add	x1, sp, #0x88
    a148:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a14c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a150:	52800020 	mov	w0, #0x1                   	// #1
    a154:	a9088be3 	stp	x3, x2, [sp, #136]
    a158:	97ffec4f 	bl	5294 <fwp_data.part.0.constprop.0>
    a15c:	97ffedee 	bl	5914 <fwp_rc_fresh>
    a160:	aa0003e2 	mov	x2, x0
    a164:	910263e1 	add	x1, sp, #0x98
    a168:	52800020 	mov	w0, #0x1                   	// #1
    a16c:	a9098bf5 	stp	x21, x2, [sp, #152]
    a170:	97ffec49 	bl	5294 <fwp_data.part.0.constprop.0>
    a174:	97ffede8 	bl	5914 <fwp_rc_fresh>
    a178:	aa0003e2 	mov	x2, x0
    a17c:	9102a3e1 	add	x1, sp, #0xa8
    a180:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a184:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a188:	52800020 	mov	w0, #0x1                   	// #1
    a18c:	a90a8be3 	stp	x3, x2, [sp, #168]
    a190:	97ffec41 	bl	5294 <fwp_data.part.0.constprop.0>
    a194:	97ffede0 	bl	5914 <fwp_rc_fresh>
    a198:	aa0003e2 	mov	x2, x0
    a19c:	9102e3e1 	add	x1, sp, #0xb8
    a1a0:	52800020 	mov	w0, #0x1                   	// #1
    a1a4:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a1a8:	97ffec3b 	bl	5294 <fwp_data.part.0.constprop.0>
    a1ac:	97ffedda 	bl	5914 <fwp_rc_fresh>
    a1b0:	aa0003e2 	mov	x2, x0
    a1b4:	910323e1 	add	x1, sp, #0xc8
    a1b8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a1bc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a1c0:	52800020 	mov	w0, #0x1                   	// #1
    a1c4:	a90c8be3 	stp	x3, x2, [sp, #200]
    a1c8:	97ffec33 	bl	5294 <fwp_data.part.0.constprop.0>
    a1cc:	97ffedd2 	bl	5914 <fwp_rc_fresh>
    a1d0:	aa0003e2 	mov	x2, x0
    a1d4:	910363e1 	add	x1, sp, #0xd8
    a1d8:	52800020 	mov	w0, #0x1                   	// #1
    a1dc:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a1e0:	97ffec2d 	bl	5294 <fwp_data.part.0.constprop.0>
    a1e4:	97ffedcc 	bl	5914 <fwp_rc_fresh>
    a1e8:	aa0003e2 	mov	x2, x0
    a1ec:	9103a3e1 	add	x1, sp, #0xe8
    a1f0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a1f4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a1f8:	52800020 	mov	w0, #0x1                   	// #1
    a1fc:	a90e8be3 	stp	x3, x2, [sp, #232]
    a200:	97ffec25 	bl	5294 <fwp_data.part.0.constprop.0>
    a204:	97ffedc4 	bl	5914 <fwp_rc_fresh>
    a208:	aa0003e2 	mov	x2, x0
    a20c:	9103e3e1 	add	x1, sp, #0xf8
    a210:	52800020 	mov	w0, #0x1                   	// #1
    a214:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a218:	97ffec1f 	bl	5294 <fwp_data.part.0.constprop.0>
    a21c:	97ffedbe 	bl	5914 <fwp_rc_fresh>
    a220:	aa0003e2 	mov	x2, x0
    a224:	910423e1 	add	x1, sp, #0x108
    a228:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a22c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a230:	52800020 	mov	w0, #0x1                   	// #1
    a234:	a9108be3 	stp	x3, x2, [sp, #264]
    a238:	97ffec17 	bl	5294 <fwp_data.part.0.constprop.0>
    a23c:	97ffedb6 	bl	5914 <fwp_rc_fresh>
    a240:	aa0003e2 	mov	x2, x0
    a244:	910463e1 	add	x1, sp, #0x118
    a248:	52800020 	mov	w0, #0x1                   	// #1
    a24c:	a9118bf5 	stp	x21, x2, [sp, #280]
    a250:	97ffec11 	bl	5294 <fwp_data.part.0.constprop.0>
    a254:	97ffedb0 	bl	5914 <fwp_rc_fresh>
    a258:	aa0003e2 	mov	x2, x0
    a25c:	9104a3e1 	add	x1, sp, #0x128
    a260:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a264:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a268:	52800020 	mov	w0, #0x1                   	// #1
    a26c:	a9128be3 	stp	x3, x2, [sp, #296]
    a270:	97ffec09 	bl	5294 <fwp_data.part.0.constprop.0>
    a274:	97ffeda8 	bl	5914 <fwp_rc_fresh>
    a278:	aa0003e2 	mov	x2, x0
    a27c:	9104e3e1 	add	x1, sp, #0x138
    a280:	52800020 	mov	w0, #0x1                   	// #1
    a284:	a9138bf5 	stp	x21, x2, [sp, #312]
    a288:	97ffec03 	bl	5294 <fwp_data.part.0.constprop.0>
    a28c:	97ffeda2 	bl	5914 <fwp_rc_fresh>
    a290:	aa0003e2 	mov	x2, x0
    a294:	910523e1 	add	x1, sp, #0x148
    a298:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a29c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2a0:	52800020 	mov	w0, #0x1                   	// #1
    a2a4:	a9148be3 	stp	x3, x2, [sp, #328]
    a2a8:	97ffebfb 	bl	5294 <fwp_data.part.0.constprop.0>
    a2ac:	97ffed9a 	bl	5914 <fwp_rc_fresh>
    a2b0:	aa0003e2 	mov	x2, x0
    a2b4:	910563e1 	add	x1, sp, #0x158
    a2b8:	52800020 	mov	w0, #0x1                   	// #1
    a2bc:	a9158bf5 	stp	x21, x2, [sp, #344]
    a2c0:	97ffebf5 	bl	5294 <fwp_data.part.0.constprop.0>
    a2c4:	97ffed94 	bl	5914 <fwp_rc_fresh>
    a2c8:	aa0003e2 	mov	x2, x0
    a2cc:	9105a3e1 	add	x1, sp, #0x168
    a2d0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a2d4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2d8:	52800020 	mov	w0, #0x1                   	// #1
    a2dc:	a9168be3 	stp	x3, x2, [sp, #360]
    a2e0:	97ffebed 	bl	5294 <fwp_data.part.0.constprop.0>
    a2e4:	97ffed8c 	bl	5914 <fwp_rc_fresh>
    a2e8:	aa0003e2 	mov	x2, x0
    a2ec:	9105e3e1 	add	x1, sp, #0x178
    a2f0:	52800020 	mov	w0, #0x1                   	// #1
    a2f4:	a9178bf5 	stp	x21, x2, [sp, #376]
    a2f8:	97ffebe7 	bl	5294 <fwp_data.part.0.constprop.0>
    a2fc:	97ffed86 	bl	5914 <fwp_rc_fresh>
    a300:	aa0003e2 	mov	x2, x0
    a304:	910623e1 	add	x1, sp, #0x188
    a308:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a30c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a310:	52800020 	mov	w0, #0x1                   	// #1
    a314:	a9188be3 	stp	x3, x2, [sp, #392]
    a318:	97ffebdf 	bl	5294 <fwp_data.part.0.constprop.0>
    a31c:	97ffed7e 	bl	5914 <fwp_rc_fresh>
    a320:	aa0003e2 	mov	x2, x0
    a324:	910663e1 	add	x1, sp, #0x198
    a328:	52800020 	mov	w0, #0x1                   	// #1
    a32c:	a9198bf5 	stp	x21, x2, [sp, #408]
    a330:	97ffebd9 	bl	5294 <fwp_data.part.0.constprop.0>
    a334:	97ffed78 	bl	5914 <fwp_rc_fresh>
    a338:	aa0003e2 	mov	x2, x0
    a33c:	9106a3e1 	add	x1, sp, #0x1a8
    a340:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a344:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a348:	52800020 	mov	w0, #0x1                   	// #1
    a34c:	a91a8be3 	stp	x3, x2, [sp, #424]
    a350:	97ffebd1 	bl	5294 <fwp_data.part.0.constprop.0>
    a354:	97ffed70 	bl	5914 <fwp_rc_fresh>
    a358:	aa0003e2 	mov	x2, x0
    a35c:	9106e3e1 	add	x1, sp, #0x1b8
    a360:	52800020 	mov	w0, #0x1                   	// #1
    a364:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a368:	97ffebcb 	bl	5294 <fwp_data.part.0.constprop.0>
    a36c:	97ffed6a 	bl	5914 <fwp_rc_fresh>
    a370:	aa0003e2 	mov	x2, x0
    a374:	910723e1 	add	x1, sp, #0x1c8
    a378:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a37c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a380:	52800020 	mov	w0, #0x1                   	// #1
    a384:	a91c8be3 	stp	x3, x2, [sp, #456]
    a388:	97ffebc3 	bl	5294 <fwp_data.part.0.constprop.0>
    a38c:	97ffed62 	bl	5914 <fwp_rc_fresh>
    a390:	aa0003e2 	mov	x2, x0
    a394:	910763e1 	add	x1, sp, #0x1d8
    a398:	52800020 	mov	w0, #0x1                   	// #1
    a39c:	a91d8bf5 	stp	x21, x2, [sp, #472]
    a3a0:	97ffebbd 	bl	5294 <fwp_data.part.0.constprop.0>
    a3a4:	97ffed5c 	bl	5914 <fwp_rc_fresh>
    a3a8:	aa0003e2 	mov	x2, x0
    a3ac:	9107a3e1 	add	x1, sp, #0x1e8
    a3b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a3b4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a3b8:	52800020 	mov	w0, #0x1                   	// #1
    a3bc:	a91e8be3 	stp	x3, x2, [sp, #488]
    a3c0:	97ffebb5 	bl	5294 <fwp_data.part.0.constprop.0>
    a3c4:	97ffed54 	bl	5914 <fwp_rc_fresh>
    a3c8:	aa0003e2 	mov	x2, x0
    a3cc:	9107e3e1 	add	x1, sp, #0x1f8
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	a91f8bf5 	stp	x21, x2, [sp, #504]
    a3d8:	97ffebaf 	bl	5294 <fwp_data.part.0.constprop.0>
    a3dc:	97ffed4e 	bl	5914 <fwp_rc_fresh>
    a3e0:	aa0003e2 	mov	x2, x0
    a3e4:	910823e1 	add	x1, sp, #0x208
    a3e8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a3ec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a3f0:	52800020 	mov	w0, #0x1                   	// #1
    a3f4:	f90107e3 	str	x3, [sp, #520]
    a3f8:	f9010be2 	str	x2, [sp, #528]
    a3fc:	97ffeba6 	bl	5294 <fwp_data.part.0.constprop.0>
    a400:	97ffed45 	bl	5914 <fwp_rc_fresh>
    a404:	aa0003e2 	mov	x2, x0
    a408:	910863e1 	add	x1, sp, #0x218
    a40c:	52800020 	mov	w0, #0x1                   	// #1
    a410:	f9010ff5 	str	x21, [sp, #536]
    a414:	f90113e2 	str	x2, [sp, #544]
    a418:	97ffeb9f 	bl	5294 <fwp_data.part.0.constprop.0>
    a41c:	97ffed3e 	bl	5914 <fwp_rc_fresh>
    a420:	aa0003e2 	mov	x2, x0
    a424:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a428:	9108a3e1 	add	x1, sp, #0x228
    a42c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a430:	52800020 	mov	w0, #0x1                   	// #1
    a434:	f90117e3 	str	x3, [sp, #552]
    a438:	f9011be2 	str	x2, [sp, #560]
    a43c:	97ffeb96 	bl	5294 <fwp_data.part.0.constprop.0>
    a440:	97ffed35 	bl	5914 <fwp_rc_fresh>
    a444:	aa0003e2 	mov	x2, x0
    a448:	9108e3e1 	add	x1, sp, #0x238
    a44c:	52800020 	mov	w0, #0x1                   	// #1
    a450:	f9011ff5 	str	x21, [sp, #568]
    a454:	f90123e2 	str	x2, [sp, #576]
    a458:	97ffeb8f 	bl	5294 <fwp_data.part.0.constprop.0>
    a45c:	9118c283 	add	x3, x20, #0x630
    a460:	aa0003f5 	mov	x21, x0
    a464:	f949d861 	ldr	x1, [x3, #5040]
    a468:	f949ec60 	ldr	x0, [x3, #5080]
    a46c:	cb0102a1 	sub	x1, x21, x1
    a470:	eb00403f 	cmp	x1, x0, lsl #16
    a474:	54000322 	b.cs	a4d8 <f0+0x548>  // b.hs, b.nlast
    a478:	d350fc22 	lsr	x2, x1, #16
    a47c:	f949fc63 	ldr	x3, [x3, #5112]
    a480:	8b020842 	add	x2, x2, x2, lsl #2
    a484:	d37df042 	lsl	x2, x2, #3
    a488:	8b020060 	add	x0, x3, x2
    a48c:	f9401017 	ldr	x23, [x0, #32]
    a490:	b4000257 	cbz	x23, a4d8 <f0+0x548>
    a494:	38626862 	ldrb	w2, [x3, x2]
    a498:	7100085f 	cmp	w2, #0x2
    a49c:	5400f460 	b.eq	c328 <f0+0x2398>  // b.none
    a4a0:	7100045f 	cmp	w2, #0x1
    a4a4:	540001a1 	b.ne	a4d8 <f0+0x548>  // b.any
    a4a8:	29430002 	ldp	w2, w0, [x0, #24]
    a4ac:	92403c21 	and	x1, x1, #0xffff
    a4b0:	9b027c21 	mul	x1, x1, x2
    a4b4:	d360fc21 	lsr	x1, x1, #32
    a4b8:	eb00003f 	cmp	x1, x0
    a4bc:	540000e2 	b.cs	a4d8 <f0+0x548>  // b.hs, b.nlast
    a4c0:	8b0102f7 	add	x23, x23, x1
    a4c4:	394002e0 	ldrb	w0, [x23]
    a4c8:	7103fc1f 	cmp	w0, #0xff
    a4cc:	5400fe20 	b.eq	c490 <f0+0x2500>  // b.none
    a4d0:	52800020 	mov	w0, #0x1                   	// #1
    a4d4:	390002e0 	strb	w0, [x23]
    a4d8:	910923e1 	add	x1, sp, #0x248
    a4dc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a4e0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a4e4:	52800020 	mov	w0, #0x1                   	// #1
    a4e8:	f90127f7 	str	x23, [sp, #584]
    a4ec:	f9012bf5 	str	x21, [sp, #592]
    a4f0:	97ffeb69 	bl	5294 <fwp_data.part.0.constprop.0>
    a4f4:	97ffed08 	bl	5914 <fwp_rc_fresh>
    a4f8:	aa0003e2 	mov	x2, x0
    a4fc:	910963e1 	add	x1, sp, #0x258
    a500:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a504:	52800020 	mov	w0, #0x1                   	// #1
    a508:	f9012ff5 	str	x21, [sp, #600]
    a50c:	f90133e2 	str	x2, [sp, #608]
    a510:	97ffeb61 	bl	5294 <fwp_data.part.0.constprop.0>
    a514:	97ffed00 	bl	5914 <fwp_rc_fresh>
    a518:	aa0003e2 	mov	x2, x0
    a51c:	9109a3e1 	add	x1, sp, #0x268
    a520:	52800020 	mov	w0, #0x1                   	// #1
    a524:	f90137f7 	str	x23, [sp, #616]
    a528:	f9013be2 	str	x2, [sp, #624]
    a52c:	97ffeb5a 	bl	5294 <fwp_data.part.0.constprop.0>
    a530:	97ffecf9 	bl	5914 <fwp_rc_fresh>
    a534:	aa0003e2 	mov	x2, x0
    a538:	9109e3e1 	add	x1, sp, #0x278
    a53c:	52800020 	mov	w0, #0x1                   	// #1
    a540:	f9013ff5 	str	x21, [sp, #632]
    a544:	f90143e2 	str	x2, [sp, #640]
    a548:	97ffeb53 	bl	5294 <fwp_data.part.0.constprop.0>
    a54c:	97ffecf2 	bl	5914 <fwp_rc_fresh>
    a550:	aa0003e2 	mov	x2, x0
    a554:	910a23e1 	add	x1, sp, #0x288
    a558:	52800020 	mov	w0, #0x1                   	// #1
    a55c:	f90147f7 	str	x23, [sp, #648]
    a560:	f9014be2 	str	x2, [sp, #656]
    a564:	97ffeb4c 	bl	5294 <fwp_data.part.0.constprop.0>
    a568:	97ffeceb 	bl	5914 <fwp_rc_fresh>
    a56c:	aa0003e2 	mov	x2, x0
    a570:	910a63e1 	add	x1, sp, #0x298
    a574:	52800020 	mov	w0, #0x1                   	// #1
    a578:	f9014ff5 	str	x21, [sp, #664]
    a57c:	f90153e2 	str	x2, [sp, #672]
    a580:	97ffeb45 	bl	5294 <fwp_data.part.0.constprop.0>
    a584:	9118c283 	add	x3, x20, #0x630
    a588:	aa0003f5 	mov	x21, x0
    a58c:	f949d861 	ldr	x1, [x3, #5040]
    a590:	f949ec60 	ldr	x0, [x3, #5080]
    a594:	cb0102a1 	sub	x1, x21, x1
    a598:	eb00403f 	cmp	x1, x0, lsl #16
    a59c:	54000322 	b.cs	a600 <f0+0x670>  // b.hs, b.nlast
    a5a0:	d350fc22 	lsr	x2, x1, #16
    a5a4:	f949fc63 	ldr	x3, [x3, #5112]
    a5a8:	8b020842 	add	x2, x2, x2, lsl #2
    a5ac:	d37df042 	lsl	x2, x2, #3
    a5b0:	8b020060 	add	x0, x3, x2
    a5b4:	f9401017 	ldr	x23, [x0, #32]
    a5b8:	b4000257 	cbz	x23, a600 <f0+0x670>
    a5bc:	38626862 	ldrb	w2, [x3, x2]
    a5c0:	7100085f 	cmp	w2, #0x2
    a5c4:	5400eac0 	b.eq	c31c <f0+0x238c>  // b.none
    a5c8:	7100045f 	cmp	w2, #0x1
    a5cc:	540001a1 	b.ne	a600 <f0+0x670>  // b.any
    a5d0:	29430002 	ldp	w2, w0, [x0, #24]
    a5d4:	92403c21 	and	x1, x1, #0xffff
    a5d8:	9b027c21 	mul	x1, x1, x2
    a5dc:	d360fc21 	lsr	x1, x1, #32
    a5e0:	eb00003f 	cmp	x1, x0
    a5e4:	540000e2 	b.cs	a600 <f0+0x670>  // b.hs, b.nlast
    a5e8:	8b0102f7 	add	x23, x23, x1
    a5ec:	394002e0 	ldrb	w0, [x23]
    a5f0:	7103fc1f 	cmp	w0, #0xff
    a5f4:	5400f540 	b.eq	c49c <f0+0x250c>  // b.none
    a5f8:	52800020 	mov	w0, #0x1                   	// #1
    a5fc:	390002e0 	strb	w0, [x23]
    a600:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a604:	910aa3e1 	add	x1, sp, #0x2a8
    a608:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a60c:	52800020 	mov	w0, #0x1                   	// #1
    a610:	f90157e2 	str	x2, [sp, #680]
    a614:	f9015bf5 	str	x21, [sp, #688]
    a618:	97ffeb1f 	bl	5294 <fwp_data.part.0.constprop.0>
    a61c:	97ffecbe 	bl	5914 <fwp_rc_fresh>
    a620:	aa0003e2 	mov	x2, x0
    a624:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a628:	910ae3e1 	add	x1, sp, #0x2b8
    a62c:	52800020 	mov	w0, #0x1                   	// #1
    a630:	f9015fe3 	str	x3, [sp, #696]
    a634:	f90163e2 	str	x2, [sp, #704]
    a638:	97ffeb17 	bl	5294 <fwp_data.part.0.constprop.0>
    a63c:	9118c283 	add	x3, x20, #0x630
    a640:	aa0003f5 	mov	x21, x0
    a644:	f949d861 	ldr	x1, [x3, #5040]
    a648:	f949ec60 	ldr	x0, [x3, #5080]
    a64c:	cb0102a1 	sub	x1, x21, x1
    a650:	eb00403f 	cmp	x1, x0, lsl #16
    a654:	54000322 	b.cs	a6b8 <f0+0x728>  // b.hs, b.nlast
    a658:	d350fc22 	lsr	x2, x1, #16
    a65c:	f949fc63 	ldr	x3, [x3, #5112]
    a660:	8b020842 	add	x2, x2, x2, lsl #2
    a664:	d37df042 	lsl	x2, x2, #3
    a668:	8b020060 	add	x0, x3, x2
    a66c:	f9401017 	ldr	x23, [x0, #32]
    a670:	b4000257 	cbz	x23, a6b8 <f0+0x728>
    a674:	38626862 	ldrb	w2, [x3, x2]
    a678:	7100085f 	cmp	w2, #0x2
    a67c:	5400e4a0 	b.eq	c310 <f0+0x2380>  // b.none
    a680:	7100045f 	cmp	w2, #0x1
    a684:	540001a1 	b.ne	a6b8 <f0+0x728>  // b.any
    a688:	29430002 	ldp	w2, w0, [x0, #24]
    a68c:	92403c21 	and	x1, x1, #0xffff
    a690:	9b027c21 	mul	x1, x1, x2
    a694:	d360fc21 	lsr	x1, x1, #32
    a698:	eb00003f 	cmp	x1, x0
    a69c:	540000e2 	b.cs	a6b8 <f0+0x728>  // b.hs, b.nlast
    a6a0:	8b0102f7 	add	x23, x23, x1
    a6a4:	394002e0 	ldrb	w0, [x23]
    a6a8:	7103fc1f 	cmp	w0, #0xff
    a6ac:	5400efe0 	b.eq	c4a8 <f0+0x2518>  // b.none
    a6b0:	52800020 	mov	w0, #0x1                   	// #1
    a6b4:	390002e0 	strb	w0, [x23]
    a6b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a6bc:	910b23e1 	add	x1, sp, #0x2c8
    a6c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a6c4:	52800020 	mov	w0, #0x1                   	// #1
    a6c8:	f90167e2 	str	x2, [sp, #712]
    a6cc:	f9016bf5 	str	x21, [sp, #720]
    a6d0:	97ffeaf1 	bl	5294 <fwp_data.part.0.constprop.0>
    a6d4:	9118c283 	add	x3, x20, #0x630
    a6d8:	aa0003f5 	mov	x21, x0
    a6dc:	f949d861 	ldr	x1, [x3, #5040]
    a6e0:	f949ec60 	ldr	x0, [x3, #5080]
    a6e4:	cb0102a1 	sub	x1, x21, x1
    a6e8:	eb00403f 	cmp	x1, x0, lsl #16
    a6ec:	54000322 	b.cs	a750 <f0+0x7c0>  // b.hs, b.nlast
    a6f0:	d350fc22 	lsr	x2, x1, #16
    a6f4:	f949fc63 	ldr	x3, [x3, #5112]
    a6f8:	8b020842 	add	x2, x2, x2, lsl #2
    a6fc:	d37df042 	lsl	x2, x2, #3
    a700:	8b020060 	add	x0, x3, x2
    a704:	f9401017 	ldr	x23, [x0, #32]
    a708:	b4000257 	cbz	x23, a750 <f0+0x7c0>
    a70c:	38626862 	ldrb	w2, [x3, x2]
    a710:	7100085f 	cmp	w2, #0x2
    a714:	5400e220 	b.eq	c358 <f0+0x23c8>  // b.none
    a718:	7100045f 	cmp	w2, #0x1
    a71c:	540001a1 	b.ne	a750 <f0+0x7c0>  // b.any
    a720:	29430002 	ldp	w2, w0, [x0, #24]
    a724:	92403c21 	and	x1, x1, #0xffff
    a728:	9b027c21 	mul	x1, x1, x2
    a72c:	d360fc21 	lsr	x1, x1, #32
    a730:	eb00003f 	cmp	x1, x0
    a734:	540000e2 	b.cs	a750 <f0+0x7c0>  // b.hs, b.nlast
    a738:	8b0102f7 	add	x23, x23, x1
    a73c:	394002e0 	ldrb	w0, [x23]
    a740:	7103fc1f 	cmp	w0, #0xff
    a744:	5400eb80 	b.eq	c4b4 <f0+0x2524>  // b.none
    a748:	52800020 	mov	w0, #0x1                   	// #1
    a74c:	390002e0 	strb	w0, [x23]
    a750:	910b63e1 	add	x1, sp, #0x2d8
    a754:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a758:	52800020 	mov	w0, #0x1                   	// #1
    a75c:	f9016ff7 	str	x23, [sp, #728]
    a760:	f90173f5 	str	x21, [sp, #736]
    a764:	97ffeacc 	bl	5294 <fwp_data.part.0.constprop.0>
    a768:	97ffec6b 	bl	5914 <fwp_rc_fresh>
    a76c:	aa0003e2 	mov	x2, x0
    a770:	910ba3e1 	add	x1, sp, #0x2e8
    a774:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a778:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a77c:	52800020 	mov	w0, #0x1                   	// #1
    a780:	f90177f5 	str	x21, [sp, #744]
    a784:	f9017be2 	str	x2, [sp, #752]
    a788:	97ffeac3 	bl	5294 <fwp_data.part.0.constprop.0>
    a78c:	97ffec62 	bl	5914 <fwp_rc_fresh>
    a790:	aa0003e2 	mov	x2, x0
    a794:	910be3e1 	add	x1, sp, #0x2f8
    a798:	52800020 	mov	w0, #0x1                   	// #1
    a79c:	f9017ff7 	str	x23, [sp, #760]
    a7a0:	f90183e2 	str	x2, [sp, #768]
    a7a4:	97ffeabc 	bl	5294 <fwp_data.part.0.constprop.0>
    a7a8:	97ffec5b 	bl	5914 <fwp_rc_fresh>
    a7ac:	aa0003e2 	mov	x2, x0
    a7b0:	910c23e1 	add	x1, sp, #0x308
    a7b4:	52800020 	mov	w0, #0x1                   	// #1
    a7b8:	f90187f5 	str	x21, [sp, #776]
    a7bc:	f9018be2 	str	x2, [sp, #784]
    a7c0:	97ffeab5 	bl	5294 <fwp_data.part.0.constprop.0>
    a7c4:	9118c283 	add	x3, x20, #0x630
    a7c8:	aa0003f5 	mov	x21, x0
    a7cc:	f949d861 	ldr	x1, [x3, #5040]
    a7d0:	f949ec60 	ldr	x0, [x3, #5080]
    a7d4:	cb0102a1 	sub	x1, x21, x1
    a7d8:	eb00403f 	cmp	x1, x0, lsl #16
    a7dc:	54000322 	b.cs	a840 <f0+0x8b0>  // b.hs, b.nlast
    a7e0:	d350fc22 	lsr	x2, x1, #16
    a7e4:	f949fc63 	ldr	x3, [x3, #5112]
    a7e8:	8b020842 	add	x2, x2, x2, lsl #2
    a7ec:	d37df042 	lsl	x2, x2, #3
    a7f0:	8b020060 	add	x0, x3, x2
    a7f4:	f9401017 	ldr	x23, [x0, #32]
    a7f8:	b4000257 	cbz	x23, a840 <f0+0x8b0>
    a7fc:	38626862 	ldrb	w2, [x3, x2]
    a800:	7100085f 	cmp	w2, #0x2
    a804:	5400da40 	b.eq	c34c <f0+0x23bc>  // b.none
    a808:	7100045f 	cmp	w2, #0x1
    a80c:	540001a1 	b.ne	a840 <f0+0x8b0>  // b.any
    a810:	29430002 	ldp	w2, w0, [x0, #24]
    a814:	92403c21 	and	x1, x1, #0xffff
    a818:	9b027c21 	mul	x1, x1, x2
    a81c:	d360fc21 	lsr	x1, x1, #32
    a820:	eb00003f 	cmp	x1, x0
    a824:	540000e2 	b.cs	a840 <f0+0x8b0>  // b.hs, b.nlast
    a828:	8b0102f7 	add	x23, x23, x1
    a82c:	394002e0 	ldrb	w0, [x23]
    a830:	7103fc1f 	cmp	w0, #0xff
    a834:	5400e460 	b.eq	c4c0 <f0+0x2530>  // b.none
    a838:	52800020 	mov	w0, #0x1                   	// #1
    a83c:	390002e0 	strb	w0, [x23]
    a840:	910c63e1 	add	x1, sp, #0x318
    a844:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a848:	52800020 	mov	w0, #0x1                   	// #1
    a84c:	f9018ff7 	str	x23, [sp, #792]
    a850:	f90193f5 	str	x21, [sp, #800]
    a854:	97ffea90 	bl	5294 <fwp_data.part.0.constprop.0>
    a858:	97ffec2f 	bl	5914 <fwp_rc_fresh>
    a85c:	aa0003e2 	mov	x2, x0
    a860:	910ca3e1 	add	x1, sp, #0x328
    a864:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a868:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a86c:	52800020 	mov	w0, #0x1                   	// #1
    a870:	f90197f5 	str	x21, [sp, #808]
    a874:	f9019be2 	str	x2, [sp, #816]
    a878:	97ffea87 	bl	5294 <fwp_data.part.0.constprop.0>
    a87c:	97ffec26 	bl	5914 <fwp_rc_fresh>
    a880:	aa0003e2 	mov	x2, x0
    a884:	910ce3e1 	add	x1, sp, #0x338
    a888:	52800020 	mov	w0, #0x1                   	// #1
    a88c:	f9019ff7 	str	x23, [sp, #824]
    a890:	f901a3e2 	str	x2, [sp, #832]
    a894:	97ffea80 	bl	5294 <fwp_data.part.0.constprop.0>
    a898:	97ffec1f 	bl	5914 <fwp_rc_fresh>
    a89c:	aa0003e2 	mov	x2, x0
    a8a0:	910d23e1 	add	x1, sp, #0x348
    a8a4:	52800020 	mov	w0, #0x1                   	// #1
    a8a8:	f901a7f5 	str	x21, [sp, #840]
    a8ac:	f901abe2 	str	x2, [sp, #848]
    a8b0:	97ffea79 	bl	5294 <fwp_data.part.0.constprop.0>
    a8b4:	97ffec18 	bl	5914 <fwp_rc_fresh>
    a8b8:	aa0003e2 	mov	x2, x0
    a8bc:	910d63e1 	add	x1, sp, #0x358
    a8c0:	52800020 	mov	w0, #0x1                   	// #1
    a8c4:	f901aff7 	str	x23, [sp, #856]
    a8c8:	f901b3e2 	str	x2, [sp, #864]
    a8cc:	97ffea72 	bl	5294 <fwp_data.part.0.constprop.0>
    a8d0:	97ffec11 	bl	5914 <fwp_rc_fresh>
    a8d4:	aa0003e2 	mov	x2, x0
    a8d8:	910da3e1 	add	x1, sp, #0x368
    a8dc:	52800020 	mov	w0, #0x1                   	// #1
    a8e0:	f901b7f5 	str	x21, [sp, #872]
    a8e4:	f901bbe2 	str	x2, [sp, #880]
    a8e8:	97ffea6b 	bl	5294 <fwp_data.part.0.constprop.0>
    a8ec:	97ffec0a 	bl	5914 <fwp_rc_fresh>
    a8f0:	aa0003e2 	mov	x2, x0
    a8f4:	910de3e1 	add	x1, sp, #0x378
    a8f8:	52800020 	mov	w0, #0x1                   	// #1
    a8fc:	f901bff7 	str	x23, [sp, #888]
    a900:	f901c3e2 	str	x2, [sp, #896]
    a904:	97ffea64 	bl	5294 <fwp_data.part.0.constprop.0>
    a908:	97ffec03 	bl	5914 <fwp_rc_fresh>
    a90c:	aa0003e2 	mov	x2, x0
    a910:	910e23e1 	add	x1, sp, #0x388
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	f901c7f5 	str	x21, [sp, #904]
    a91c:	f901cbe2 	str	x2, [sp, #912]
    a920:	97ffea5d 	bl	5294 <fwp_data.part.0.constprop.0>
    a924:	97ffebfc 	bl	5914 <fwp_rc_fresh>
    a928:	aa0003e2 	mov	x2, x0
    a92c:	910e63e1 	add	x1, sp, #0x398
    a930:	52800020 	mov	w0, #0x1                   	// #1
    a934:	f901cff7 	str	x23, [sp, #920]
    a938:	f901d3e2 	str	x2, [sp, #928]
    a93c:	97ffea56 	bl	5294 <fwp_data.part.0.constprop.0>
    a940:	97ffebf5 	bl	5914 <fwp_rc_fresh>
    a944:	aa0003e2 	mov	x2, x0
    a948:	910ea3e1 	add	x1, sp, #0x3a8
    a94c:	52800020 	mov	w0, #0x1                   	// #1
    a950:	f901d7f5 	str	x21, [sp, #936]
    a954:	f901dbe2 	str	x2, [sp, #944]
    a958:	97ffea4f 	bl	5294 <fwp_data.part.0.constprop.0>
    a95c:	9118c283 	add	x3, x20, #0x630
    a960:	aa0003f5 	mov	x21, x0
    a964:	f949d861 	ldr	x1, [x3, #5040]
    a968:	f949ec60 	ldr	x0, [x3, #5080]
    a96c:	cb0102a1 	sub	x1, x21, x1
    a970:	eb00403f 	cmp	x1, x0, lsl #16
    a974:	54000322 	b.cs	a9d8 <f0+0xa48>  // b.hs, b.nlast
    a978:	d350fc22 	lsr	x2, x1, #16
    a97c:	f949fc63 	ldr	x3, [x3, #5112]
    a980:	8b020842 	add	x2, x2, x2, lsl #2
    a984:	d37df042 	lsl	x2, x2, #3
    a988:	8b020060 	add	x0, x3, x2
    a98c:	f9401017 	ldr	x23, [x0, #32]
    a990:	b4000257 	cbz	x23, a9d8 <f0+0xa48>
    a994:	38626862 	ldrb	w2, [x3, x2]
    a998:	7100085f 	cmp	w2, #0x2
    a99c:	5400cd20 	b.eq	c340 <f0+0x23b0>  // b.none
    a9a0:	7100045f 	cmp	w2, #0x1
    a9a4:	540001a1 	b.ne	a9d8 <f0+0xa48>  // b.any
    a9a8:	29430002 	ldp	w2, w0, [x0, #24]
    a9ac:	92403c21 	and	x1, x1, #0xffff
    a9b0:	9b027c21 	mul	x1, x1, x2
    a9b4:	d360fc21 	lsr	x1, x1, #32
    a9b8:	eb00003f 	cmp	x1, x0
    a9bc:	540000e2 	b.cs	a9d8 <f0+0xa48>  // b.hs, b.nlast
    a9c0:	8b0102f7 	add	x23, x23, x1
    a9c4:	394002e0 	ldrb	w0, [x23]
    a9c8:	7103fc1f 	cmp	w0, #0xff
    a9cc:	5400d800 	b.eq	c4cc <f0+0x253c>  // b.none
    a9d0:	52800020 	mov	w0, #0x1                   	// #1
    a9d4:	390002e0 	strb	w0, [x23]
    a9d8:	910ee3e1 	add	x1, sp, #0x3b8
    a9dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9e0:	52800020 	mov	w0, #0x1                   	// #1
    a9e4:	f901dfe2 	str	x2, [sp, #952]
    a9e8:	f901e3f5 	str	x21, [sp, #960]
    a9ec:	97ffea2a 	bl	5294 <fwp_data.part.0.constprop.0>
    a9f0:	97ffebc9 	bl	5914 <fwp_rc_fresh>
    a9f4:	aa0003e2 	mov	x2, x0
    a9f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9fc:	910f23e1 	add	x1, sp, #0x3c8
    aa00:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa04:	52800020 	mov	w0, #0x1                   	// #1
    aa08:	f901e7e3 	str	x3, [sp, #968]
    aa0c:	f901ebe2 	str	x2, [sp, #976]
    aa10:	97ffea21 	bl	5294 <fwp_data.part.0.constprop.0>
    aa14:	9118c283 	add	x3, x20, #0x630
    aa18:	aa0003f5 	mov	x21, x0
    aa1c:	f949d861 	ldr	x1, [x3, #5040]
    aa20:	f949ec60 	ldr	x0, [x3, #5080]
    aa24:	cb0102a1 	sub	x1, x21, x1
    aa28:	eb00403f 	cmp	x1, x0, lsl #16
    aa2c:	54000322 	b.cs	aa90 <f0+0xb00>  // b.hs, b.nlast
    aa30:	d350fc22 	lsr	x2, x1, #16
    aa34:	f949fc63 	ldr	x3, [x3, #5112]
    aa38:	8b020842 	add	x2, x2, x2, lsl #2
    aa3c:	d37df042 	lsl	x2, x2, #3
    aa40:	8b020060 	add	x0, x3, x2
    aa44:	f9401017 	ldr	x23, [x0, #32]
    aa48:	b4000257 	cbz	x23, aa90 <f0+0xb00>
    aa4c:	38626862 	ldrb	w2, [x3, x2]
    aa50:	7100085f 	cmp	w2, #0x2
    aa54:	5400c700 	b.eq	c334 <f0+0x23a4>  // b.none
    aa58:	7100045f 	cmp	w2, #0x1
    aa5c:	540001a1 	b.ne	aa90 <f0+0xb00>  // b.any
    aa60:	29430002 	ldp	w2, w0, [x0, #24]
    aa64:	92403c21 	and	x1, x1, #0xffff
    aa68:	9b027c21 	mul	x1, x1, x2
    aa6c:	d360fc21 	lsr	x1, x1, #32
    aa70:	eb00003f 	cmp	x1, x0
    aa74:	540000e2 	b.cs	aa90 <f0+0xb00>  // b.hs, b.nlast
    aa78:	8b0102f7 	add	x23, x23, x1
    aa7c:	394002e0 	ldrb	w0, [x23]
    aa80:	7103fc1f 	cmp	w0, #0xff
    aa84:	5400d2a0 	b.eq	c4d8 <f0+0x2548>  // b.none
    aa88:	52800020 	mov	w0, #0x1                   	// #1
    aa8c:	390002e0 	strb	w0, [x23]
    aa90:	910f63e1 	add	x1, sp, #0x3d8
    aa94:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa98:	52800020 	mov	w0, #0x1                   	// #1
    aa9c:	f901efe2 	str	x2, [sp, #984]
    aaa0:	f901f3f5 	str	x21, [sp, #992]
    aaa4:	97ffe9fc 	bl	5294 <fwp_data.part.0.constprop.0>
    aaa8:	97ffeb9b 	bl	5914 <fwp_rc_fresh>
    aaac:	aa0003e2 	mov	x2, x0
    aab0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aab4:	910fa3e1 	add	x1, sp, #0x3e8
    aab8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	f901f7e3 	str	x3, [sp, #1000]
    aac4:	f901fbe2 	str	x2, [sp, #1008]
    aac8:	97ffe9f3 	bl	5294 <fwp_data.part.0.constprop.0>
    aacc:	9118c283 	add	x3, x20, #0x630
    aad0:	aa0003f7 	mov	x23, x0
    aad4:	f949d861 	ldr	x1, [x3, #5040]
    aad8:	f949ec60 	ldr	x0, [x3, #5080]
    aadc:	cb0102e1 	sub	x1, x23, x1
    aae0:	eb00403f 	cmp	x1, x0, lsl #16
    aae4:	54000322 	b.cs	ab48 <f0+0xbb8>  // b.hs, b.nlast
    aae8:	d350fc22 	lsr	x2, x1, #16
    aaec:	f949fc63 	ldr	x3, [x3, #5112]
    aaf0:	8b020842 	add	x2, x2, x2, lsl #2
    aaf4:	d37df042 	lsl	x2, x2, #3
    aaf8:	8b020060 	add	x0, x3, x2
    aafc:	f9401015 	ldr	x21, [x0, #32]
    ab00:	b4000255 	cbz	x21, ab48 <f0+0xbb8>
    ab04:	38626862 	ldrb	w2, [x3, x2]
    ab08:	7100085f 	cmp	w2, #0x2
    ab0c:	5400c560 	b.eq	c3b8 <f0+0x2428>  // b.none
    ab10:	7100045f 	cmp	w2, #0x1
    ab14:	540001a1 	b.ne	ab48 <f0+0xbb8>  // b.any
    ab18:	29430002 	ldp	w2, w0, [x0, #24]
    ab1c:	92403c21 	and	x1, x1, #0xffff
    ab20:	9b027c21 	mul	x1, x1, x2
    ab24:	d360fc21 	lsr	x1, x1, #32
    ab28:	eb00003f 	cmp	x1, x0
    ab2c:	540000e2 	b.cs	ab48 <f0+0xbb8>  // b.hs, b.nlast
    ab30:	8b0102b5 	add	x21, x21, x1
    ab34:	394002a0 	ldrb	w0, [x21]
    ab38:	7103fc1f 	cmp	w0, #0xff
    ab3c:	5400cd40 	b.eq	c4e4 <f0+0x2554>  // b.none
    ab40:	52800020 	mov	w0, #0x1                   	// #1
    ab44:	390002a0 	strb	w0, [x21]
    ab48:	910fe3e1 	add	x1, sp, #0x3f8
    ab4c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ab50:	52800020 	mov	w0, #0x1                   	// #1
    ab54:	f901fff5 	str	x21, [sp, #1016]
    ab58:	f90203f7 	str	x23, [sp, #1024]
    ab5c:	97ffe9ce 	bl	5294 <fwp_data.part.0.constprop.0>
    ab60:	97ffeb6d 	bl	5914 <fwp_rc_fresh>
    ab64:	aa0003e2 	mov	x2, x0
    ab68:	911023e1 	add	x1, sp, #0x408
    ab6c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ab70:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ab74:	52800020 	mov	w0, #0x1                   	// #1
    ab78:	f90207f7 	str	x23, [sp, #1032]
    ab7c:	f9020be2 	str	x2, [sp, #1040]
    ab80:	97ffe9c5 	bl	5294 <fwp_data.part.0.constprop.0>
    ab84:	97ffeb64 	bl	5914 <fwp_rc_fresh>
    ab88:	aa0003e2 	mov	x2, x0
    ab8c:	911063e1 	add	x1, sp, #0x418
    ab90:	52800020 	mov	w0, #0x1                   	// #1
    ab94:	f9020ff5 	str	x21, [sp, #1048]
    ab98:	f90213e2 	str	x2, [sp, #1056]
    ab9c:	97ffe9be 	bl	5294 <fwp_data.part.0.constprop.0>
    aba0:	97ffeb5d 	bl	5914 <fwp_rc_fresh>
    aba4:	aa0003e2 	mov	x2, x0
    aba8:	9110a3e1 	add	x1, sp, #0x428
    abac:	52800020 	mov	w0, #0x1                   	// #1
    abb0:	f90217f7 	str	x23, [sp, #1064]
    abb4:	f9021be2 	str	x2, [sp, #1072]
    abb8:	97ffe9b7 	bl	5294 <fwp_data.part.0.constprop.0>
    abbc:	97ffeb56 	bl	5914 <fwp_rc_fresh>
    abc0:	aa0003e2 	mov	x2, x0
    abc4:	9110e3e1 	add	x1, sp, #0x438
    abc8:	52800020 	mov	w0, #0x1                   	// #1
    abcc:	f9021ff5 	str	x21, [sp, #1080]
    abd0:	f90223e2 	str	x2, [sp, #1088]
    abd4:	97ffe9b0 	bl	5294 <fwp_data.part.0.constprop.0>
    abd8:	97ffeb4f 	bl	5914 <fwp_rc_fresh>
    abdc:	aa0003e2 	mov	x2, x0
    abe0:	911123e1 	add	x1, sp, #0x448
    abe4:	52800020 	mov	w0, #0x1                   	// #1
    abe8:	f90227f7 	str	x23, [sp, #1096]
    abec:	f9022be2 	str	x2, [sp, #1104]
    abf0:	97ffe9a9 	bl	5294 <fwp_data.part.0.constprop.0>
    abf4:	97ffeb48 	bl	5914 <fwp_rc_fresh>
    abf8:	aa0003e2 	mov	x2, x0
    abfc:	911163e1 	add	x1, sp, #0x458
    ac00:	52800020 	mov	w0, #0x1                   	// #1
    ac04:	f9022ff5 	str	x21, [sp, #1112]
    ac08:	f90233e2 	str	x2, [sp, #1120]
    ac0c:	97ffe9a2 	bl	5294 <fwp_data.part.0.constprop.0>
    ac10:	9118c283 	add	x3, x20, #0x630
    ac14:	aa0003f5 	mov	x21, x0
    ac18:	f949d861 	ldr	x1, [x3, #5040]
    ac1c:	f949ec60 	ldr	x0, [x3, #5080]
    ac20:	cb0102a1 	sub	x1, x21, x1
    ac24:	eb00403f 	cmp	x1, x0, lsl #16
    ac28:	54000322 	b.cs	ac8c <f0+0xcfc>  // b.hs, b.nlast
    ac2c:	d350fc22 	lsr	x2, x1, #16
    ac30:	f949fc63 	ldr	x3, [x3, #5112]
    ac34:	8b020842 	add	x2, x2, x2, lsl #2
    ac38:	d37df042 	lsl	x2, x2, #3
    ac3c:	8b020060 	add	x0, x3, x2
    ac40:	f9401017 	ldr	x23, [x0, #32]
    ac44:	b4000257 	cbz	x23, ac8c <f0+0xcfc>
    ac48:	38626862 	ldrb	w2, [x3, x2]
    ac4c:	7100085f 	cmp	w2, #0x2
    ac50:	5400bae0 	b.eq	c3ac <f0+0x241c>  // b.none
    ac54:	7100045f 	cmp	w2, #0x1
    ac58:	540001a1 	b.ne	ac8c <f0+0xcfc>  // b.any
    ac5c:	29430002 	ldp	w2, w0, [x0, #24]
    ac60:	92403c21 	and	x1, x1, #0xffff
    ac64:	9b027c21 	mul	x1, x1, x2
    ac68:	d360fc21 	lsr	x1, x1, #32
    ac6c:	eb00003f 	cmp	x1, x0
    ac70:	540000e2 	b.cs	ac8c <f0+0xcfc>  // b.hs, b.nlast
    ac74:	8b0102f7 	add	x23, x23, x1
    ac78:	394002e0 	ldrb	w0, [x23]
    ac7c:	7103fc1f 	cmp	w0, #0xff
    ac80:	5400c380 	b.eq	c4f0 <f0+0x2560>  // b.none
    ac84:	52800020 	mov	w0, #0x1                   	// #1
    ac88:	390002e0 	strb	w0, [x23]
    ac8c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ac90:	9111a3e1 	add	x1, sp, #0x468
    ac94:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ac98:	52800020 	mov	w0, #0x1                   	// #1
    ac9c:	f90237e2 	str	x2, [sp, #1128]
    aca0:	f9023bf5 	str	x21, [sp, #1136]
    aca4:	97ffe97c 	bl	5294 <fwp_data.part.0.constprop.0>
    aca8:	9118c283 	add	x3, x20, #0x630
    acac:	aa0003f5 	mov	x21, x0
    acb0:	f949d861 	ldr	x1, [x3, #5040]
    acb4:	f949ec60 	ldr	x0, [x3, #5080]
    acb8:	cb0102a1 	sub	x1, x21, x1
    acbc:	eb00403f 	cmp	x1, x0, lsl #16
    acc0:	54000322 	b.cs	ad24 <f0+0xd94>  // b.hs, b.nlast
    acc4:	d350fc22 	lsr	x2, x1, #16
    acc8:	f949fc63 	ldr	x3, [x3, #5112]
    accc:	8b020842 	add	x2, x2, x2, lsl #2
    acd0:	d37df042 	lsl	x2, x2, #3
    acd4:	8b020060 	add	x0, x3, x2
    acd8:	f9401017 	ldr	x23, [x0, #32]
    acdc:	b4000257 	cbz	x23, ad24 <f0+0xd94>
    ace0:	38626862 	ldrb	w2, [x3, x2]
    ace4:	7100085f 	cmp	w2, #0x2
    ace8:	5400b5c0 	b.eq	c3a0 <f0+0x2410>  // b.none
    acec:	7100045f 	cmp	w2, #0x1
    acf0:	540001a1 	b.ne	ad24 <f0+0xd94>  // b.any
    acf4:	29430002 	ldp	w2, w0, [x0, #24]
    acf8:	92403c21 	and	x1, x1, #0xffff
    acfc:	9b027c21 	mul	x1, x1, x2
    ad00:	d360fc21 	lsr	x1, x1, #32
    ad04:	eb00003f 	cmp	x1, x0
    ad08:	540000e2 	b.cs	ad24 <f0+0xd94>  // b.hs, b.nlast
    ad0c:	8b0102f7 	add	x23, x23, x1
    ad10:	394002e0 	ldrb	w0, [x23]
    ad14:	7103fc1f 	cmp	w0, #0xff
    ad18:	5400bf20 	b.eq	c4fc <f0+0x256c>  // b.none
    ad1c:	52800020 	mov	w0, #0x1                   	// #1
    ad20:	390002e0 	strb	w0, [x23]
    ad24:	9111e3e1 	add	x1, sp, #0x478
    ad28:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad2c:	52800020 	mov	w0, #0x1                   	// #1
    ad30:	f9023fe2 	str	x2, [sp, #1144]
    ad34:	f90243f5 	str	x21, [sp, #1152]
    ad38:	97ffe957 	bl	5294 <fwp_data.part.0.constprop.0>
    ad3c:	97ffeaf6 	bl	5914 <fwp_rc_fresh>
    ad40:	aa0003e2 	mov	x2, x0
    ad44:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad48:	911223e1 	add	x1, sp, #0x488
    ad4c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad50:	52800020 	mov	w0, #0x1                   	// #1
    ad54:	f90247e3 	str	x3, [sp, #1160]
    ad58:	f9024be2 	str	x2, [sp, #1168]
    ad5c:	97ffe94e 	bl	5294 <fwp_data.part.0.constprop.0>
    ad60:	9118c283 	add	x3, x20, #0x630
    ad64:	aa0003f5 	mov	x21, x0
    ad68:	f949d861 	ldr	x1, [x3, #5040]
    ad6c:	f949ec60 	ldr	x0, [x3, #5080]
    ad70:	cb0102a1 	sub	x1, x21, x1
    ad74:	eb00403f 	cmp	x1, x0, lsl #16
    ad78:	54000322 	b.cs	addc <f0+0xe4c>  // b.hs, b.nlast
    ad7c:	d350fc22 	lsr	x2, x1, #16
    ad80:	f949fc63 	ldr	x3, [x3, #5112]
    ad84:	8b020842 	add	x2, x2, x2, lsl #2
    ad88:	d37df042 	lsl	x2, x2, #3
    ad8c:	8b020060 	add	x0, x3, x2
    ad90:	f9401017 	ldr	x23, [x0, #32]
    ad94:	b4000257 	cbz	x23, addc <f0+0xe4c>
    ad98:	38626862 	ldrb	w2, [x3, x2]
    ad9c:	7100085f 	cmp	w2, #0x2
    ada0:	5400afa0 	b.eq	c394 <f0+0x2404>  // b.none
    ada4:	7100045f 	cmp	w2, #0x1
    ada8:	540001a1 	b.ne	addc <f0+0xe4c>  // b.any
    adac:	29430002 	ldp	w2, w0, [x0, #24]
    adb0:	92403c21 	and	x1, x1, #0xffff
    adb4:	9b027c21 	mul	x1, x1, x2
    adb8:	d360fc21 	lsr	x1, x1, #32
    adbc:	eb00003f 	cmp	x1, x0
    adc0:	540000e2 	b.cs	addc <f0+0xe4c>  // b.hs, b.nlast
    adc4:	8b0102f7 	add	x23, x23, x1
    adc8:	394002e0 	ldrb	w0, [x23]
    adcc:	7103fc1f 	cmp	w0, #0xff
    add0:	5400b9c0 	b.eq	c508 <f0+0x2578>  // b.none
    add4:	52800020 	mov	w0, #0x1                   	// #1
    add8:	390002e0 	strb	w0, [x23]
    addc:	911263e1 	add	x1, sp, #0x498
    ade0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ade4:	52800020 	mov	w0, #0x1                   	// #1
    ade8:	f9024fe2 	str	x2, [sp, #1176]
    adec:	f90253f5 	str	x21, [sp, #1184]
    adf0:	97ffe929 	bl	5294 <fwp_data.part.0.constprop.0>
    adf4:	97ffeac8 	bl	5914 <fwp_rc_fresh>
    adf8:	aa0003e2 	mov	x2, x0
    adfc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae00:	9112a3e1 	add	x1, sp, #0x4a8
    ae04:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae08:	52800020 	mov	w0, #0x1                   	// #1
    ae0c:	f90257e3 	str	x3, [sp, #1192]
    ae10:	f9025be2 	str	x2, [sp, #1200]
    ae14:	97ffe920 	bl	5294 <fwp_data.part.0.constprop.0>
    ae18:	9118c283 	add	x3, x20, #0x630
    ae1c:	aa0003f5 	mov	x21, x0
    ae20:	f949d861 	ldr	x1, [x3, #5040]
    ae24:	f949ec60 	ldr	x0, [x3, #5080]
    ae28:	cb0102a1 	sub	x1, x21, x1
    ae2c:	eb00403f 	cmp	x1, x0, lsl #16
    ae30:	54000322 	b.cs	ae94 <f0+0xf04>  // b.hs, b.nlast
    ae34:	d350fc22 	lsr	x2, x1, #16
    ae38:	f949fc63 	ldr	x3, [x3, #5112]
    ae3c:	8b020842 	add	x2, x2, x2, lsl #2
    ae40:	d37df042 	lsl	x2, x2, #3
    ae44:	8b020060 	add	x0, x3, x2
    ae48:	f9401017 	ldr	x23, [x0, #32]
    ae4c:	b4000257 	cbz	x23, ae94 <f0+0xf04>
    ae50:	38626862 	ldrb	w2, [x3, x2]
    ae54:	7100085f 	cmp	w2, #0x2
    ae58:	5400a980 	b.eq	c388 <f0+0x23f8>  // b.none
    ae5c:	7100045f 	cmp	w2, #0x1
    ae60:	540001a1 	b.ne	ae94 <f0+0xf04>  // b.any
    ae64:	29430002 	ldp	w2, w0, [x0, #24]
    ae68:	92403c21 	and	x1, x1, #0xffff
    ae6c:	9b027c21 	mul	x1, x1, x2
    ae70:	d360fc21 	lsr	x1, x1, #32
    ae74:	eb00003f 	cmp	x1, x0
    ae78:	540000e2 	b.cs	ae94 <f0+0xf04>  // b.hs, b.nlast
    ae7c:	8b0102f7 	add	x23, x23, x1
    ae80:	394002e0 	ldrb	w0, [x23]
    ae84:	7103fc1f 	cmp	w0, #0xff
    ae88:	5400b460 	b.eq	c514 <f0+0x2584>  // b.none
    ae8c:	52800020 	mov	w0, #0x1                   	// #1
    ae90:	390002e0 	strb	w0, [x23]
    ae94:	9112e3e1 	add	x1, sp, #0x4b8
    ae98:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ae9c:	52800020 	mov	w0, #0x1                   	// #1
    aea0:	f9025ff7 	str	x23, [sp, #1208]
    aea4:	f90263f5 	str	x21, [sp, #1216]
    aea8:	97ffe8fb 	bl	5294 <fwp_data.part.0.constprop.0>
    aeac:	97ffea9a 	bl	5914 <fwp_rc_fresh>
    aeb0:	aa0003e2 	mov	x2, x0
    aeb4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aeb8:	911323e1 	add	x1, sp, #0x4c8
    aebc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aec0:	52800020 	mov	w0, #0x1                   	// #1
    aec4:	f90267e3 	str	x3, [sp, #1224]
    aec8:	f9026be2 	str	x2, [sp, #1232]
    aecc:	97ffe8f2 	bl	5294 <fwp_data.part.0.constprop.0>
    aed0:	97ffea91 	bl	5914 <fwp_rc_fresh>
    aed4:	aa0003e2 	mov	x2, x0
    aed8:	911363e1 	add	x1, sp, #0x4d8
    aedc:	52800020 	mov	w0, #0x1                   	// #1
    aee0:	f9026ff7 	str	x23, [sp, #1240]
    aee4:	f90273e2 	str	x2, [sp, #1248]
    aee8:	97ffe8eb 	bl	5294 <fwp_data.part.0.constprop.0>
    aeec:	9118c283 	add	x3, x20, #0x630
    aef0:	aa0003f5 	mov	x21, x0
    aef4:	f949d861 	ldr	x1, [x3, #5040]
    aef8:	f949ec60 	ldr	x0, [x3, #5080]
    aefc:	cb0102a1 	sub	x1, x21, x1
    af00:	eb00403f 	cmp	x1, x0, lsl #16
    af04:	54000322 	b.cs	af68 <f0+0xfd8>  // b.hs, b.nlast
    af08:	d350fc22 	lsr	x2, x1, #16
    af0c:	f949fc63 	ldr	x3, [x3, #5112]
    af10:	8b020842 	add	x2, x2, x2, lsl #2
    af14:	d37df042 	lsl	x2, x2, #3
    af18:	8b020060 	add	x0, x3, x2
    af1c:	f9401017 	ldr	x23, [x0, #32]
    af20:	b4000257 	cbz	x23, af68 <f0+0xfd8>
    af24:	38626862 	ldrb	w2, [x3, x2]
    af28:	7100085f 	cmp	w2, #0x2
    af2c:	5400a280 	b.eq	c37c <f0+0x23ec>  // b.none
    af30:	7100045f 	cmp	w2, #0x1
    af34:	540001a1 	b.ne	af68 <f0+0xfd8>  // b.any
    af38:	29430002 	ldp	w2, w0, [x0, #24]
    af3c:	92403c21 	and	x1, x1, #0xffff
    af40:	9b027c21 	mul	x1, x1, x2
    af44:	d360fc21 	lsr	x1, x1, #32
    af48:	eb00003f 	cmp	x1, x0
    af4c:	540000e2 	b.cs	af68 <f0+0xfd8>  // b.hs, b.nlast
    af50:	8b0102f7 	add	x23, x23, x1
    af54:	394002e0 	ldrb	w0, [x23]
    af58:	7103fc1f 	cmp	w0, #0xff
    af5c:	5400ae20 	b.eq	c520 <f0+0x2590>  // b.none
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	390002e0 	strb	w0, [x23]
    af68:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af6c:	9113a3e1 	add	x1, sp, #0x4e8
    af70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af74:	52800020 	mov	w0, #0x1                   	// #1
    af78:	f90277e2 	str	x2, [sp, #1256]
    af7c:	f9027bf5 	str	x21, [sp, #1264]
    af80:	97ffe8c5 	bl	5294 <fwp_data.part.0.constprop.0>
    af84:	9118c283 	add	x3, x20, #0x630
    af88:	aa0003f5 	mov	x21, x0
    af8c:	f949d861 	ldr	x1, [x3, #5040]
    af90:	f949ec60 	ldr	x0, [x3, #5080]
    af94:	cb0102a1 	sub	x1, x21, x1
    af98:	eb00403f 	cmp	x1, x0, lsl #16
    af9c:	54000322 	b.cs	b000 <f0+0x1070>  // b.hs, b.nlast
    afa0:	d350fc22 	lsr	x2, x1, #16
    afa4:	f949fc63 	ldr	x3, [x3, #5112]
    afa8:	8b020842 	add	x2, x2, x2, lsl #2
    afac:	d37df042 	lsl	x2, x2, #3
    afb0:	8b020060 	add	x0, x3, x2
    afb4:	f9401017 	ldr	x23, [x0, #32]
    afb8:	b4000257 	cbz	x23, b000 <f0+0x1070>
    afbc:	38626862 	ldrb	w2, [x3, x2]
    afc0:	7100085f 	cmp	w2, #0x2
    afc4:	54009d60 	b.eq	c370 <f0+0x23e0>  // b.none
    afc8:	7100045f 	cmp	w2, #0x1
    afcc:	540001a1 	b.ne	b000 <f0+0x1070>  // b.any
    afd0:	29430002 	ldp	w2, w0, [x0, #24]
    afd4:	92403c21 	and	x1, x1, #0xffff
    afd8:	9b027c21 	mul	x1, x1, x2
    afdc:	d360fc21 	lsr	x1, x1, #32
    afe0:	eb00003f 	cmp	x1, x0
    afe4:	540000e2 	b.cs	b000 <f0+0x1070>  // b.hs, b.nlast
    afe8:	8b0102f7 	add	x23, x23, x1
    afec:	394002e0 	ldrb	w0, [x23]
    aff0:	7103fc1f 	cmp	w0, #0xff
    aff4:	5400a9c0 	b.eq	c52c <f0+0x259c>  // b.none
    aff8:	52800020 	mov	w0, #0x1                   	// #1
    affc:	390002e0 	strb	w0, [x23]
    b000:	9113e3e1 	add	x1, sp, #0x4f8
    b004:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b008:	52800020 	mov	w0, #0x1                   	// #1
    b00c:	f9027fe2 	str	x2, [sp, #1272]
    b010:	f90283f5 	str	x21, [sp, #1280]
    b014:	97ffe8a0 	bl	5294 <fwp_data.part.0.constprop.0>
    b018:	97ffea3f 	bl	5914 <fwp_rc_fresh>
    b01c:	aa0003e2 	mov	x2, x0
    b020:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b024:	911423e1 	add	x1, sp, #0x508
    b028:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b02c:	52800020 	mov	w0, #0x1                   	// #1
    b030:	f90287e3 	str	x3, [sp, #1288]
    b034:	f9028be2 	str	x2, [sp, #1296]
    b038:	97ffe897 	bl	5294 <fwp_data.part.0.constprop.0>
    b03c:	9118c283 	add	x3, x20, #0x630
    b040:	aa0003f5 	mov	x21, x0
    b044:	f949d861 	ldr	x1, [x3, #5040]
    b048:	f949ec60 	ldr	x0, [x3, #5080]
    b04c:	cb0102a1 	sub	x1, x21, x1
    b050:	eb00403f 	cmp	x1, x0, lsl #16
    b054:	54000322 	b.cs	b0b8 <f0+0x1128>  // b.hs, b.nlast
    b058:	d350fc22 	lsr	x2, x1, #16
    b05c:	f949fc63 	ldr	x3, [x3, #5112]
    b060:	8b020842 	add	x2, x2, x2, lsl #2
    b064:	d37df042 	lsl	x2, x2, #3
    b068:	8b020060 	add	x0, x3, x2
    b06c:	f9401017 	ldr	x23, [x0, #32]
    b070:	b4000257 	cbz	x23, b0b8 <f0+0x1128>
    b074:	38626862 	ldrb	w2, [x3, x2]
    b078:	7100085f 	cmp	w2, #0x2
    b07c:	54009740 	b.eq	c364 <f0+0x23d4>  // b.none
    b080:	7100045f 	cmp	w2, #0x1
    b084:	540001a1 	b.ne	b0b8 <f0+0x1128>  // b.any
    b088:	29430002 	ldp	w2, w0, [x0, #24]
    b08c:	92403c21 	and	x1, x1, #0xffff
    b090:	9b027c21 	mul	x1, x1, x2
    b094:	d360fc21 	lsr	x1, x1, #32
    b098:	eb00003f 	cmp	x1, x0
    b09c:	540000e2 	b.cs	b0b8 <f0+0x1128>  // b.hs, b.nlast
    b0a0:	8b0102f7 	add	x23, x23, x1
    b0a4:	394002e0 	ldrb	w0, [x23]
    b0a8:	7103fc1f 	cmp	w0, #0xff
    b0ac:	5400a460 	b.eq	c538 <f0+0x25a8>  // b.none
    b0b0:	52800020 	mov	w0, #0x1                   	// #1
    b0b4:	390002e0 	strb	w0, [x23]
    b0b8:	911463e1 	add	x1, sp, #0x518
    b0bc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b0c0:	52800020 	mov	w0, #0x1                   	// #1
    b0c4:	f9028fe2 	str	x2, [sp, #1304]
    b0c8:	f90293f5 	str	x21, [sp, #1312]
    b0cc:	97ffe872 	bl	5294 <fwp_data.part.0.constprop.0>
    b0d0:	97ffea11 	bl	5914 <fwp_rc_fresh>
    b0d4:	aa0003e2 	mov	x2, x0
    b0d8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b0dc:	9114a3e1 	add	x1, sp, #0x528
    b0e0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b0e4:	52800020 	mov	w0, #0x1                   	// #1
    b0e8:	f90297e3 	str	x3, [sp, #1320]
    b0ec:	f9029be2 	str	x2, [sp, #1328]
    b0f0:	97ffe869 	bl	5294 <fwp_data.part.0.constprop.0>
    b0f4:	9118c283 	add	x3, x20, #0x630
    b0f8:	aa0003f5 	mov	x21, x0
    b0fc:	f949d861 	ldr	x1, [x3, #5040]
    b100:	f949ec60 	ldr	x0, [x3, #5080]
    b104:	cb0102a1 	sub	x1, x21, x1
    b108:	eb00403f 	cmp	x1, x0, lsl #16
    b10c:	54000322 	b.cs	b170 <f0+0x11e0>  // b.hs, b.nlast
    b110:	d350fc22 	lsr	x2, x1, #16
    b114:	f949fc63 	ldr	x3, [x3, #5112]
    b118:	8b020842 	add	x2, x2, x2, lsl #2
    b11c:	d37df042 	lsl	x2, x2, #3
    b120:	8b020060 	add	x0, x3, x2
    b124:	f9401017 	ldr	x23, [x0, #32]
    b128:	b4000257 	cbz	x23, b170 <f0+0x11e0>
    b12c:	38626862 	ldrb	w2, [x3, x2]
    b130:	7100085f 	cmp	w2, #0x2
    b134:	54008e80 	b.eq	c304 <f0+0x2374>  // b.none
    b138:	7100045f 	cmp	w2, #0x1
    b13c:	540001a1 	b.ne	b170 <f0+0x11e0>  // b.any
    b140:	29430002 	ldp	w2, w0, [x0, #24]
    b144:	92403c21 	and	x1, x1, #0xffff
    b148:	9b027c21 	mul	x1, x1, x2
    b14c:	d360fc21 	lsr	x1, x1, #32
    b150:	eb00003f 	cmp	x1, x0
    b154:	540000e2 	b.cs	b170 <f0+0x11e0>  // b.hs, b.nlast
    b158:	8b0102f7 	add	x23, x23, x1
    b15c:	394002e0 	ldrb	w0, [x23]
    b160:	7103fc1f 	cmp	w0, #0xff
    b164:	54009f00 	b.eq	c544 <f0+0x25b4>  // b.none
    b168:	52800020 	mov	w0, #0x1                   	// #1
    b16c:	390002e0 	strb	w0, [x23]
    b170:	9114e3e1 	add	x1, sp, #0x538
    b174:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b178:	52800020 	mov	w0, #0x1                   	// #1
    b17c:	f9029ff7 	str	x23, [sp, #1336]
    b180:	f902a3f5 	str	x21, [sp, #1344]
    b184:	97ffe844 	bl	5294 <fwp_data.part.0.constprop.0>
    b188:	97ffe9e3 	bl	5914 <fwp_rc_fresh>
    b18c:	aa0003e2 	mov	x2, x0
    b190:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b194:	911523e1 	add	x1, sp, #0x548
    b198:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b19c:	52800020 	mov	w0, #0x1                   	// #1
    b1a0:	f902a7e3 	str	x3, [sp, #1352]
    b1a4:	f902abe2 	str	x2, [sp, #1360]
    b1a8:	97ffe83b 	bl	5294 <fwp_data.part.0.constprop.0>
    b1ac:	97ffe9da 	bl	5914 <fwp_rc_fresh>
    b1b0:	aa0003e2 	mov	x2, x0
    b1b4:	911563e1 	add	x1, sp, #0x558
    b1b8:	52800020 	mov	w0, #0x1                   	// #1
    b1bc:	f902aff7 	str	x23, [sp, #1368]
    b1c0:	f902b3e2 	str	x2, [sp, #1376]
    b1c4:	97ffe834 	bl	5294 <fwp_data.part.0.constprop.0>
    b1c8:	9118c283 	add	x3, x20, #0x630
    b1cc:	aa0003f5 	mov	x21, x0
    b1d0:	f949d861 	ldr	x1, [x3, #5040]
    b1d4:	f949ec60 	ldr	x0, [x3, #5080]
    b1d8:	cb0102a1 	sub	x1, x21, x1
    b1dc:	eb00403f 	cmp	x1, x0, lsl #16
    b1e0:	54000322 	b.cs	b244 <f0+0x12b4>  // b.hs, b.nlast
    b1e4:	d350fc22 	lsr	x2, x1, #16
    b1e8:	f949fc63 	ldr	x3, [x3, #5112]
    b1ec:	8b020842 	add	x2, x2, x2, lsl #2
    b1f0:	d37df042 	lsl	x2, x2, #3
    b1f4:	8b020060 	add	x0, x3, x2
    b1f8:	f9401017 	ldr	x23, [x0, #32]
    b1fc:	b4000257 	cbz	x23, b244 <f0+0x12b4>
    b200:	38626862 	ldrb	w2, [x3, x2]
    b204:	7100085f 	cmp	w2, #0x2
    b208:	54008780 	b.eq	c2f8 <f0+0x2368>  // b.none
    b20c:	7100045f 	cmp	w2, #0x1
    b210:	540001a1 	b.ne	b244 <f0+0x12b4>  // b.any
    b214:	29430002 	ldp	w2, w0, [x0, #24]
    b218:	92403c21 	and	x1, x1, #0xffff
    b21c:	9b027c21 	mul	x1, x1, x2
    b220:	d360fc21 	lsr	x1, x1, #32
    b224:	eb00003f 	cmp	x1, x0
    b228:	540000e2 	b.cs	b244 <f0+0x12b4>  // b.hs, b.nlast
    b22c:	8b0102f7 	add	x23, x23, x1
    b230:	394002e0 	ldrb	w0, [x23]
    b234:	7103fc1f 	cmp	w0, #0xff
    b238:	540098c0 	b.eq	c550 <f0+0x25c0>  // b.none
    b23c:	52800020 	mov	w0, #0x1                   	// #1
    b240:	390002e0 	strb	w0, [x23]
    b244:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b248:	9115a3e1 	add	x1, sp, #0x568
    b24c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b250:	52800020 	mov	w0, #0x1                   	// #1
    b254:	f902b7e2 	str	x2, [sp, #1384]
    b258:	f902bbf5 	str	x21, [sp, #1392]
    b25c:	97ffe80e 	bl	5294 <fwp_data.part.0.constprop.0>
    b260:	9118c283 	add	x3, x20, #0x630
    b264:	aa0003f5 	mov	x21, x0
    b268:	f949d861 	ldr	x1, [x3, #5040]
    b26c:	f949ec60 	ldr	x0, [x3, #5080]
    b270:	cb0102a1 	sub	x1, x21, x1
    b274:	eb00403f 	cmp	x1, x0, lsl #16
    b278:	54000322 	b.cs	b2dc <f0+0x134c>  // b.hs, b.nlast
    b27c:	d350fc22 	lsr	x2, x1, #16
    b280:	f949fc63 	ldr	x3, [x3, #5112]
    b284:	8b020842 	add	x2, x2, x2, lsl #2
    b288:	d37df042 	lsl	x2, x2, #3
    b28c:	8b020060 	add	x0, x3, x2
    b290:	f9401017 	ldr	x23, [x0, #32]
    b294:	b4000257 	cbz	x23, b2dc <f0+0x134c>
    b298:	38626862 	ldrb	w2, [x3, x2]
    b29c:	7100085f 	cmp	w2, #0x2
    b2a0:	54008260 	b.eq	c2ec <f0+0x235c>  // b.none
    b2a4:	7100045f 	cmp	w2, #0x1
    b2a8:	540001a1 	b.ne	b2dc <f0+0x134c>  // b.any
    b2ac:	29430002 	ldp	w2, w0, [x0, #24]
    b2b0:	92403c21 	and	x1, x1, #0xffff
    b2b4:	9b027c21 	mul	x1, x1, x2
    b2b8:	d360fc21 	lsr	x1, x1, #32
    b2bc:	eb00003f 	cmp	x1, x0
    b2c0:	540000e2 	b.cs	b2dc <f0+0x134c>  // b.hs, b.nlast
    b2c4:	8b0102f7 	add	x23, x23, x1
    b2c8:	394002e0 	ldrb	w0, [x23]
    b2cc:	7103fc1f 	cmp	w0, #0xff
    b2d0:	54009460 	b.eq	c55c <f0+0x25cc>  // b.none
    b2d4:	52800020 	mov	w0, #0x1                   	// #1
    b2d8:	390002e0 	strb	w0, [x23]
    b2dc:	9115e3e1 	add	x1, sp, #0x578
    b2e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b2e4:	52800020 	mov	w0, #0x1                   	// #1
    b2e8:	f902bfe2 	str	x2, [sp, #1400]
    b2ec:	f902c3f5 	str	x21, [sp, #1408]
    b2f0:	97ffe7e9 	bl	5294 <fwp_data.part.0.constprop.0>
    b2f4:	97ffe988 	bl	5914 <fwp_rc_fresh>
    b2f8:	aa0003e2 	mov	x2, x0
    b2fc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b300:	911623e1 	add	x1, sp, #0x588
    b304:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b308:	52800020 	mov	w0, #0x1                   	// #1
    b30c:	f902c7e3 	str	x3, [sp, #1416]
    b310:	f902cbe2 	str	x2, [sp, #1424]
    b314:	97ffe7e0 	bl	5294 <fwp_data.part.0.constprop.0>
    b318:	9118c283 	add	x3, x20, #0x630
    b31c:	aa0003f5 	mov	x21, x0
    b320:	f949d861 	ldr	x1, [x3, #5040]
    b324:	f949ec60 	ldr	x0, [x3, #5080]
    b328:	cb0102a1 	sub	x1, x21, x1
    b32c:	eb00403f 	cmp	x1, x0, lsl #16
    b330:	54000322 	b.cs	b394 <f0+0x1404>  // b.hs, b.nlast
    b334:	d350fc22 	lsr	x2, x1, #16
    b338:	f949fc63 	ldr	x3, [x3, #5112]
    b33c:	8b020842 	add	x2, x2, x2, lsl #2
    b340:	d37df042 	lsl	x2, x2, #3
    b344:	8b020060 	add	x0, x3, x2
    b348:	f9401017 	ldr	x23, [x0, #32]
    b34c:	b4000257 	cbz	x23, b394 <f0+0x1404>
    b350:	38626862 	ldrb	w2, [x3, x2]
    b354:	7100085f 	cmp	w2, #0x2
    b358:	54007c40 	b.eq	c2e0 <f0+0x2350>  // b.none
    b35c:	7100045f 	cmp	w2, #0x1
    b360:	540001a1 	b.ne	b394 <f0+0x1404>  // b.any
    b364:	29430002 	ldp	w2, w0, [x0, #24]
    b368:	92403c21 	and	x1, x1, #0xffff
    b36c:	9b027c21 	mul	x1, x1, x2
    b370:	d360fc21 	lsr	x1, x1, #32
    b374:	eb00003f 	cmp	x1, x0
    b378:	540000e2 	b.cs	b394 <f0+0x1404>  // b.hs, b.nlast
    b37c:	8b0102f7 	add	x23, x23, x1
    b380:	394002e0 	ldrb	w0, [x23]
    b384:	7103fc1f 	cmp	w0, #0xff
    b388:	54008f00 	b.eq	c568 <f0+0x25d8>  // b.none
    b38c:	52800020 	mov	w0, #0x1                   	// #1
    b390:	390002e0 	strb	w0, [x23]
    b394:	911663e1 	add	x1, sp, #0x598
    b398:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b39c:	52800020 	mov	w0, #0x1                   	// #1
    b3a0:	f902cfe2 	str	x2, [sp, #1432]
    b3a4:	f902d3f5 	str	x21, [sp, #1440]
    b3a8:	97ffe7bb 	bl	5294 <fwp_data.part.0.constprop.0>
    b3ac:	97ffe95a 	bl	5914 <fwp_rc_fresh>
    b3b0:	aa0003e2 	mov	x2, x0
    b3b4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b3b8:	9116a3e1 	add	x1, sp, #0x5a8
    b3bc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b3c0:	52800020 	mov	w0, #0x1                   	// #1
    b3c4:	f902d7e3 	str	x3, [sp, #1448]
    b3c8:	f902dbe2 	str	x2, [sp, #1456]
    b3cc:	97ffe7b2 	bl	5294 <fwp_data.part.0.constprop.0>
    b3d0:	9118c283 	add	x3, x20, #0x630
    b3d4:	aa0003f5 	mov	x21, x0
    b3d8:	f949d861 	ldr	x1, [x3, #5040]
    b3dc:	f949ec60 	ldr	x0, [x3, #5080]
    b3e0:	cb0102a1 	sub	x1, x21, x1
    b3e4:	eb00403f 	cmp	x1, x0, lsl #16
    b3e8:	54000322 	b.cs	b44c <f0+0x14bc>  // b.hs, b.nlast
    b3ec:	d350fc22 	lsr	x2, x1, #16
    b3f0:	f949fc63 	ldr	x3, [x3, #5112]
    b3f4:	8b020842 	add	x2, x2, x2, lsl #2
    b3f8:	d37df042 	lsl	x2, x2, #3
    b3fc:	8b020060 	add	x0, x3, x2
    b400:	f9401017 	ldr	x23, [x0, #32]
    b404:	b4000257 	cbz	x23, b44c <f0+0x14bc>
    b408:	38626862 	ldrb	w2, [x3, x2]
    b40c:	7100085f 	cmp	w2, #0x2
    b410:	54007620 	b.eq	c2d4 <f0+0x2344>  // b.none
    b414:	7100045f 	cmp	w2, #0x1
    b418:	540001a1 	b.ne	b44c <f0+0x14bc>  // b.any
    b41c:	29430002 	ldp	w2, w0, [x0, #24]
    b420:	92403c21 	and	x1, x1, #0xffff
    b424:	9b027c21 	mul	x1, x1, x2
    b428:	d360fc21 	lsr	x1, x1, #32
    b42c:	eb00003f 	cmp	x1, x0
    b430:	540000e2 	b.cs	b44c <f0+0x14bc>  // b.hs, b.nlast
    b434:	8b0102f7 	add	x23, x23, x1
    b438:	394002e0 	ldrb	w0, [x23]
    b43c:	7103fc1f 	cmp	w0, #0xff
    b440:	540089a0 	b.eq	c574 <f0+0x25e4>  // b.none
    b444:	52800020 	mov	w0, #0x1                   	// #1
    b448:	390002e0 	strb	w0, [x23]
    b44c:	9116e3e1 	add	x1, sp, #0x5b8
    b450:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b454:	52800020 	mov	w0, #0x1                   	// #1
    b458:	f902dff7 	str	x23, [sp, #1464]
    b45c:	f902e3f5 	str	x21, [sp, #1472]
    b460:	97ffe78d 	bl	5294 <fwp_data.part.0.constprop.0>
    b464:	97ffe92c 	bl	5914 <fwp_rc_fresh>
    b468:	aa0003e2 	mov	x2, x0
    b46c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b470:	911723e1 	add	x1, sp, #0x5c8
    b474:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b478:	52800020 	mov	w0, #0x1                   	// #1
    b47c:	f902e7e3 	str	x3, [sp, #1480]
    b480:	f902ebe2 	str	x2, [sp, #1488]
    b484:	97ffe784 	bl	5294 <fwp_data.part.0.constprop.0>
    b488:	97ffe923 	bl	5914 <fwp_rc_fresh>
    b48c:	aa0003e2 	mov	x2, x0
    b490:	911763e1 	add	x1, sp, #0x5d8
    b494:	52800020 	mov	w0, #0x1                   	// #1
    b498:	f902eff7 	str	x23, [sp, #1496]
    b49c:	f902f3e2 	str	x2, [sp, #1504]
    b4a0:	97ffe77d 	bl	5294 <fwp_data.part.0.constprop.0>
    b4a4:	9118c283 	add	x3, x20, #0x630
    b4a8:	aa0003f5 	mov	x21, x0
    b4ac:	f949d861 	ldr	x1, [x3, #5040]
    b4b0:	f949ec60 	ldr	x0, [x3, #5080]
    b4b4:	cb0102a1 	sub	x1, x21, x1
    b4b8:	eb00403f 	cmp	x1, x0, lsl #16
    b4bc:	54000322 	b.cs	b520 <f0+0x1590>  // b.hs, b.nlast
    b4c0:	d350fc22 	lsr	x2, x1, #16
    b4c4:	f949fc63 	ldr	x3, [x3, #5112]
    b4c8:	8b020842 	add	x2, x2, x2, lsl #2
    b4cc:	d37df042 	lsl	x2, x2, #3
    b4d0:	8b020060 	add	x0, x3, x2
    b4d4:	f9401017 	ldr	x23, [x0, #32]
    b4d8:	b4000257 	cbz	x23, b520 <f0+0x1590>
    b4dc:	38626862 	ldrb	w2, [x3, x2]
    b4e0:	7100085f 	cmp	w2, #0x2
    b4e4:	54006f20 	b.eq	c2c8 <f0+0x2338>  // b.none
    b4e8:	7100045f 	cmp	w2, #0x1
    b4ec:	540001a1 	b.ne	b520 <f0+0x1590>  // b.any
    b4f0:	29430002 	ldp	w2, w0, [x0, #24]
    b4f4:	92403c21 	and	x1, x1, #0xffff
    b4f8:	9b027c21 	mul	x1, x1, x2
    b4fc:	d360fc21 	lsr	x1, x1, #32
    b500:	eb00003f 	cmp	x1, x0
    b504:	540000e2 	b.cs	b520 <f0+0x1590>  // b.hs, b.nlast
    b508:	8b0102f7 	add	x23, x23, x1
    b50c:	394002e0 	ldrb	w0, [x23]
    b510:	7103fc1f 	cmp	w0, #0xff
    b514:	54008360 	b.eq	c580 <f0+0x25f0>  // b.none
    b518:	52800020 	mov	w0, #0x1                   	// #1
    b51c:	390002e0 	strb	w0, [x23]
    b520:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b524:	9117a3e1 	add	x1, sp, #0x5e8
    b528:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b52c:	52800020 	mov	w0, #0x1                   	// #1
    b530:	f902f7e2 	str	x2, [sp, #1512]
    b534:	f902fbf5 	str	x21, [sp, #1520]
    b538:	97ffe757 	bl	5294 <fwp_data.part.0.constprop.0>
    b53c:	9118c283 	add	x3, x20, #0x630
    b540:	aa0003f5 	mov	x21, x0
    b544:	f949d861 	ldr	x1, [x3, #5040]
    b548:	f949ec60 	ldr	x0, [x3, #5080]
    b54c:	cb0102a1 	sub	x1, x21, x1
    b550:	eb00403f 	cmp	x1, x0, lsl #16
    b554:	54000322 	b.cs	b5b8 <f0+0x1628>  // b.hs, b.nlast
    b558:	d350fc22 	lsr	x2, x1, #16
    b55c:	f949fc63 	ldr	x3, [x3, #5112]
    b560:	8b020842 	add	x2, x2, x2, lsl #2
    b564:	d37df042 	lsl	x2, x2, #3
    b568:	8b020060 	add	x0, x3, x2
    b56c:	f9401017 	ldr	x23, [x0, #32]
    b570:	b4000257 	cbz	x23, b5b8 <f0+0x1628>
    b574:	38626862 	ldrb	w2, [x3, x2]
    b578:	7100085f 	cmp	w2, #0x2
    b57c:	54006a00 	b.eq	c2bc <f0+0x232c>  // b.none
    b580:	7100045f 	cmp	w2, #0x1
    b584:	540001a1 	b.ne	b5b8 <f0+0x1628>  // b.any
    b588:	29430002 	ldp	w2, w0, [x0, #24]
    b58c:	92403c21 	and	x1, x1, #0xffff
    b590:	9b027c21 	mul	x1, x1, x2
    b594:	d360fc21 	lsr	x1, x1, #32
    b598:	eb00003f 	cmp	x1, x0
    b59c:	540000e2 	b.cs	b5b8 <f0+0x1628>  // b.hs, b.nlast
    b5a0:	8b0102f7 	add	x23, x23, x1
    b5a4:	394002e0 	ldrb	w0, [x23]
    b5a8:	7103fc1f 	cmp	w0, #0xff
    b5ac:	54007f00 	b.eq	c58c <f0+0x25fc>  // b.none
    b5b0:	52800020 	mov	w0, #0x1                   	// #1
    b5b4:	390002e0 	strb	w0, [x23]
    b5b8:	9117e3e1 	add	x1, sp, #0x5f8
    b5bc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b5c0:	52800020 	mov	w0, #0x1                   	// #1
    b5c4:	f902ffe2 	str	x2, [sp, #1528]
    b5c8:	f90303f5 	str	x21, [sp, #1536]
    b5cc:	97ffe732 	bl	5294 <fwp_data.part.0.constprop.0>
    b5d0:	97ffe8d1 	bl	5914 <fwp_rc_fresh>
    b5d4:	aa0003e2 	mov	x2, x0
    b5d8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b5dc:	911823e1 	add	x1, sp, #0x608
    b5e0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b5e4:	52800020 	mov	w0, #0x1                   	// #1
    b5e8:	f90307e3 	str	x3, [sp, #1544]
    b5ec:	f9030be2 	str	x2, [sp, #1552]
    b5f0:	97ffe729 	bl	5294 <fwp_data.part.0.constprop.0>
    b5f4:	9118c283 	add	x3, x20, #0x630
    b5f8:	aa0003f5 	mov	x21, x0
    b5fc:	f949d861 	ldr	x1, [x3, #5040]
    b600:	f949ec60 	ldr	x0, [x3, #5080]
    b604:	cb0102a1 	sub	x1, x21, x1
    b608:	eb00403f 	cmp	x1, x0, lsl #16
    b60c:	54000322 	b.cs	b670 <f0+0x16e0>  // b.hs, b.nlast
    b610:	d350fc22 	lsr	x2, x1, #16
    b614:	f949fc63 	ldr	x3, [x3, #5112]
    b618:	8b020842 	add	x2, x2, x2, lsl #2
    b61c:	d37df042 	lsl	x2, x2, #3
    b620:	8b020060 	add	x0, x3, x2
    b624:	f9401017 	ldr	x23, [x0, #32]
    b628:	b4000257 	cbz	x23, b670 <f0+0x16e0>
    b62c:	38626862 	ldrb	w2, [x3, x2]
    b630:	7100085f 	cmp	w2, #0x2
    b634:	540063e0 	b.eq	c2b0 <f0+0x2320>  // b.none
    b638:	7100045f 	cmp	w2, #0x1
    b63c:	540001a1 	b.ne	b670 <f0+0x16e0>  // b.any
    b640:	29430002 	ldp	w2, w0, [x0, #24]
    b644:	92403c21 	and	x1, x1, #0xffff
    b648:	9b027c21 	mul	x1, x1, x2
    b64c:	d360fc21 	lsr	x1, x1, #32
    b650:	eb00003f 	cmp	x1, x0
    b654:	540000e2 	b.cs	b670 <f0+0x16e0>  // b.hs, b.nlast
    b658:	8b0102f7 	add	x23, x23, x1
    b65c:	394002e0 	ldrb	w0, [x23]
    b660:	7103fc1f 	cmp	w0, #0xff
    b664:	540079a0 	b.eq	c598 <f0+0x2608>  // b.none
    b668:	52800020 	mov	w0, #0x1                   	// #1
    b66c:	390002e0 	strb	w0, [x23]
    b670:	911863e1 	add	x1, sp, #0x618
    b674:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b678:	52800020 	mov	w0, #0x1                   	// #1
    b67c:	f9030fe2 	str	x2, [sp, #1560]
    b680:	f90313f5 	str	x21, [sp, #1568]
    b684:	97ffe704 	bl	5294 <fwp_data.part.0.constprop.0>
    b688:	97ffe8a3 	bl	5914 <fwp_rc_fresh>
    b68c:	aa0003e2 	mov	x2, x0
    b690:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b694:	9118a3e1 	add	x1, sp, #0x628
    b698:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b69c:	52800020 	mov	w0, #0x1                   	// #1
    b6a0:	f90317e3 	str	x3, [sp, #1576]
    b6a4:	f9031be2 	str	x2, [sp, #1584]
    b6a8:	97ffe6fb 	bl	5294 <fwp_data.part.0.constprop.0>
    b6ac:	9118c283 	add	x3, x20, #0x630
    b6b0:	aa0003f5 	mov	x21, x0
    b6b4:	f949d861 	ldr	x1, [x3, #5040]
    b6b8:	f949ec60 	ldr	x0, [x3, #5080]
    b6bc:	cb0102a1 	sub	x1, x21, x1
    b6c0:	eb00403f 	cmp	x1, x0, lsl #16
    b6c4:	54000322 	b.cs	b728 <f0+0x1798>  // b.hs, b.nlast
    b6c8:	d350fc22 	lsr	x2, x1, #16
    b6cc:	f949fc63 	ldr	x3, [x3, #5112]
    b6d0:	8b020842 	add	x2, x2, x2, lsl #2
    b6d4:	d37df042 	lsl	x2, x2, #3
    b6d8:	8b020060 	add	x0, x3, x2
    b6dc:	f9401017 	ldr	x23, [x0, #32]
    b6e0:	b4000257 	cbz	x23, b728 <f0+0x1798>
    b6e4:	38626862 	ldrb	w2, [x3, x2]
    b6e8:	7100085f 	cmp	w2, #0x2
    b6ec:	54006c60 	b.eq	c478 <f0+0x24e8>  // b.none
    b6f0:	7100045f 	cmp	w2, #0x1
    b6f4:	540001a1 	b.ne	b728 <f0+0x1798>  // b.any
    b6f8:	29430002 	ldp	w2, w0, [x0, #24]
    b6fc:	92403c21 	and	x1, x1, #0xffff
    b700:	9b027c21 	mul	x1, x1, x2
    b704:	d360fc21 	lsr	x1, x1, #32
    b708:	eb00003f 	cmp	x1, x0
    b70c:	540000e2 	b.cs	b728 <f0+0x1798>  // b.hs, b.nlast
    b710:	8b0102f7 	add	x23, x23, x1
    b714:	394002e0 	ldrb	w0, [x23]
    b718:	7103fc1f 	cmp	w0, #0xff
    b71c:	54007440 	b.eq	c5a4 <f0+0x2614>  // b.none
    b720:	52800020 	mov	w0, #0x1                   	// #1
    b724:	390002e0 	strb	w0, [x23]
    b728:	9118e3e1 	add	x1, sp, #0x638
    b72c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b730:	52800020 	mov	w0, #0x1                   	// #1
    b734:	f9031fe2 	str	x2, [sp, #1592]
    b738:	f90323f5 	str	x21, [sp, #1600]
    b73c:	97ffe6d6 	bl	5294 <fwp_data.part.0.constprop.0>
    b740:	97ffe875 	bl	5914 <fwp_rc_fresh>
    b744:	aa0003e2 	mov	x2, x0
    b748:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b74c:	911923e1 	add	x1, sp, #0x648
    b750:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b754:	52800020 	mov	w0, #0x1                   	// #1
    b758:	f90327e3 	str	x3, [sp, #1608]
    b75c:	f9032be2 	str	x2, [sp, #1616]
    b760:	97ffe6cd 	bl	5294 <fwp_data.part.0.constprop.0>
    b764:	9118c283 	add	x3, x20, #0x630
    b768:	aa0003f5 	mov	x21, x0
    b76c:	f949d861 	ldr	x1, [x3, #5040]
    b770:	f949ec60 	ldr	x0, [x3, #5080]
    b774:	cb0102a1 	sub	x1, x21, x1
    b778:	eb00403f 	cmp	x1, x0, lsl #16
    b77c:	54000322 	b.cs	b7e0 <f0+0x1850>  // b.hs, b.nlast
    b780:	d350fc22 	lsr	x2, x1, #16
    b784:	f949fc63 	ldr	x3, [x3, #5112]
    b788:	8b020842 	add	x2, x2, x2, lsl #2
    b78c:	d37df042 	lsl	x2, x2, #3
    b790:	8b020060 	add	x0, x3, x2
    b794:	f9401017 	ldr	x23, [x0, #32]
    b798:	b4000257 	cbz	x23, b7e0 <f0+0x1850>
    b79c:	38626862 	ldrb	w2, [x3, x2]
    b7a0:	7100085f 	cmp	w2, #0x2
    b7a4:	54006640 	b.eq	c46c <f0+0x24dc>  // b.none
    b7a8:	7100045f 	cmp	w2, #0x1
    b7ac:	540001a1 	b.ne	b7e0 <f0+0x1850>  // b.any
    b7b0:	29430002 	ldp	w2, w0, [x0, #24]
    b7b4:	92403c21 	and	x1, x1, #0xffff
    b7b8:	9b027c21 	mul	x1, x1, x2
    b7bc:	d360fc21 	lsr	x1, x1, #32
    b7c0:	eb00003f 	cmp	x1, x0
    b7c4:	540000e2 	b.cs	b7e0 <f0+0x1850>  // b.hs, b.nlast
    b7c8:	8b0102f7 	add	x23, x23, x1
    b7cc:	394002e0 	ldrb	w0, [x23]
    b7d0:	7103fc1f 	cmp	w0, #0xff
    b7d4:	54006ee0 	b.eq	c5b0 <f0+0x2620>  // b.none
    b7d8:	52800020 	mov	w0, #0x1                   	// #1
    b7dc:	390002e0 	strb	w0, [x23]
    b7e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b7e4:	911963e1 	add	x1, sp, #0x658
    b7e8:	52800020 	mov	w0, #0x1                   	// #1
    b7ec:	f9032fe2 	str	x2, [sp, #1624]
    b7f0:	f90333f5 	str	x21, [sp, #1632]
    b7f4:	97ffe6a8 	bl	5294 <fwp_data.part.0.constprop.0>
    b7f8:	9118c283 	add	x3, x20, #0x630
    b7fc:	aa0003f5 	mov	x21, x0
    b800:	f949d861 	ldr	x1, [x3, #5040]
    b804:	f949ec60 	ldr	x0, [x3, #5080]
    b808:	cb0102a1 	sub	x1, x21, x1
    b80c:	eb00403f 	cmp	x1, x0, lsl #16
    b810:	54000322 	b.cs	b874 <f0+0x18e4>  // b.hs, b.nlast
    b814:	d350fc22 	lsr	x2, x1, #16
    b818:	f949fc63 	ldr	x3, [x3, #5112]
    b81c:	8b020842 	add	x2, x2, x2, lsl #2
    b820:	d37df042 	lsl	x2, x2, #3
    b824:	8b020060 	add	x0, x3, x2
    b828:	f9401017 	ldr	x23, [x0, #32]
    b82c:	b4000257 	cbz	x23, b874 <f0+0x18e4>
    b830:	38626862 	ldrb	w2, [x3, x2]
    b834:	7100085f 	cmp	w2, #0x2
    b838:	54006140 	b.eq	c460 <f0+0x24d0>  // b.none
    b83c:	7100045f 	cmp	w2, #0x1
    b840:	540001a1 	b.ne	b874 <f0+0x18e4>  // b.any
    b844:	29430002 	ldp	w2, w0, [x0, #24]
    b848:	92403c21 	and	x1, x1, #0xffff
    b84c:	9b027c21 	mul	x1, x1, x2
    b850:	d360fc21 	lsr	x1, x1, #32
    b854:	eb00003f 	cmp	x1, x0
    b858:	540000e2 	b.cs	b874 <f0+0x18e4>  // b.hs, b.nlast
    b85c:	8b0102f7 	add	x23, x23, x1
    b860:	394002e0 	ldrb	w0, [x23]
    b864:	7103fc1f 	cmp	w0, #0xff
    b868:	54006aa0 	b.eq	c5bc <f0+0x262c>  // b.none
    b86c:	52800020 	mov	w0, #0x1                   	// #1
    b870:	390002e0 	strb	w0, [x23]
    b874:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b878:	9119a3e1 	add	x1, sp, #0x668
    b87c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b880:	52800020 	mov	w0, #0x1                   	// #1
    b884:	f90337e2 	str	x2, [sp, #1640]
    b888:	f9033bf5 	str	x21, [sp, #1648]
    b88c:	97ffe682 	bl	5294 <fwp_data.part.0.constprop.0>
    b890:	9118c283 	add	x3, x20, #0x630
    b894:	aa0003f5 	mov	x21, x0
    b898:	f949d861 	ldr	x1, [x3, #5040]
    b89c:	f949ec60 	ldr	x0, [x3, #5080]
    b8a0:	cb0102a1 	sub	x1, x21, x1
    b8a4:	eb00403f 	cmp	x1, x0, lsl #16
    b8a8:	54000322 	b.cs	b90c <f0+0x197c>  // b.hs, b.nlast
    b8ac:	d350fc22 	lsr	x2, x1, #16
    b8b0:	f949fc63 	ldr	x3, [x3, #5112]
    b8b4:	8b020842 	add	x2, x2, x2, lsl #2
    b8b8:	d37df042 	lsl	x2, x2, #3
    b8bc:	8b020060 	add	x0, x3, x2
    b8c0:	f9401017 	ldr	x23, [x0, #32]
    b8c4:	b4000257 	cbz	x23, b90c <f0+0x197c>
    b8c8:	38626862 	ldrb	w2, [x3, x2]
    b8cc:	7100085f 	cmp	w2, #0x2
    b8d0:	54005c20 	b.eq	c454 <f0+0x24c4>  // b.none
    b8d4:	7100045f 	cmp	w2, #0x1
    b8d8:	540001a1 	b.ne	b90c <f0+0x197c>  // b.any
    b8dc:	29430002 	ldp	w2, w0, [x0, #24]
    b8e0:	92403c21 	and	x1, x1, #0xffff
    b8e4:	9b027c21 	mul	x1, x1, x2
    b8e8:	d360fc21 	lsr	x1, x1, #32
    b8ec:	eb00003f 	cmp	x1, x0
    b8f0:	540000e2 	b.cs	b90c <f0+0x197c>  // b.hs, b.nlast
    b8f4:	8b0102f7 	add	x23, x23, x1
    b8f8:	394002e0 	ldrb	w0, [x23]
    b8fc:	7103fc1f 	cmp	w0, #0xff
    b900:	54006640 	b.eq	c5c8 <f0+0x2638>  // b.none
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	390002e0 	strb	w0, [x23]
    b90c:	9119e3e1 	add	x1, sp, #0x678
    b910:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b914:	52800020 	mov	w0, #0x1                   	// #1
    b918:	f9033ff7 	str	x23, [sp, #1656]
    b91c:	f90343f5 	str	x21, [sp, #1664]
    b920:	97ffe65d 	bl	5294 <fwp_data.part.0.constprop.0>
    b924:	97ffe7fc 	bl	5914 <fwp_rc_fresh>
    b928:	aa0003e2 	mov	x2, x0
    b92c:	911a23e1 	add	x1, sp, #0x688
    b930:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b934:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b938:	52800020 	mov	w0, #0x1                   	// #1
    b93c:	f90347f5 	str	x21, [sp, #1672]
    b940:	f9034be2 	str	x2, [sp, #1680]
    b944:	97ffe654 	bl	5294 <fwp_data.part.0.constprop.0>
    b948:	97ffe7f3 	bl	5914 <fwp_rc_fresh>
    b94c:	aa0003e2 	mov	x2, x0
    b950:	911a63e1 	add	x1, sp, #0x698
    b954:	52800020 	mov	w0, #0x1                   	// #1
    b958:	f9034ff7 	str	x23, [sp, #1688]
    b95c:	f90353e2 	str	x2, [sp, #1696]
    b960:	97ffe64d 	bl	5294 <fwp_data.part.0.constprop.0>
    b964:	97ffe7ec 	bl	5914 <fwp_rc_fresh>
    b968:	aa0003e2 	mov	x2, x0
    b96c:	911aa3e1 	add	x1, sp, #0x6a8
    b970:	52800020 	mov	w0, #0x1                   	// #1
    b974:	f90357f5 	str	x21, [sp, #1704]
    b978:	f9035be2 	str	x2, [sp, #1712]
    b97c:	97ffe646 	bl	5294 <fwp_data.part.0.constprop.0>
    b980:	9118c283 	add	x3, x20, #0x630
    b984:	aa0003f5 	mov	x21, x0
    b988:	f949d861 	ldr	x1, [x3, #5040]
    b98c:	f949ec60 	ldr	x0, [x3, #5080]
    b990:	cb0102a1 	sub	x1, x21, x1
    b994:	eb00403f 	cmp	x1, x0, lsl #16
    b998:	54000322 	b.cs	b9fc <f0+0x1a6c>  // b.hs, b.nlast
    b99c:	d350fc22 	lsr	x2, x1, #16
    b9a0:	f949fc63 	ldr	x3, [x3, #5112]
    b9a4:	8b020842 	add	x2, x2, x2, lsl #2
    b9a8:	d37df042 	lsl	x2, x2, #3
    b9ac:	8b020060 	add	x0, x3, x2
    b9b0:	f9401017 	ldr	x23, [x0, #32]
    b9b4:	b4000257 	cbz	x23, b9fc <f0+0x1a6c>
    b9b8:	38626862 	ldrb	w2, [x3, x2]
    b9bc:	7100085f 	cmp	w2, #0x2
    b9c0:	54005440 	b.eq	c448 <f0+0x24b8>  // b.none
    b9c4:	7100045f 	cmp	w2, #0x1
    b9c8:	540001a1 	b.ne	b9fc <f0+0x1a6c>  // b.any
    b9cc:	29430002 	ldp	w2, w0, [x0, #24]
    b9d0:	92403c21 	and	x1, x1, #0xffff
    b9d4:	9b027c21 	mul	x1, x1, x2
    b9d8:	d360fc21 	lsr	x1, x1, #32
    b9dc:	eb00003f 	cmp	x1, x0
    b9e0:	540000e2 	b.cs	b9fc <f0+0x1a6c>  // b.hs, b.nlast
    b9e4:	8b0102f7 	add	x23, x23, x1
    b9e8:	394002e0 	ldrb	w0, [x23]
    b9ec:	7103fc1f 	cmp	w0, #0xff
    b9f0:	54005f20 	b.eq	c5d4 <f0+0x2644>  // b.none
    b9f4:	52800020 	mov	w0, #0x1                   	// #1
    b9f8:	390002e0 	strb	w0, [x23]
    b9fc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba00:	911ae3e1 	add	x1, sp, #0x6b8
    ba04:	52800020 	mov	w0, #0x1                   	// #1
    ba08:	f9035fe2 	str	x2, [sp, #1720]
    ba0c:	f90363f5 	str	x21, [sp, #1728]
    ba10:	97ffe621 	bl	5294 <fwp_data.part.0.constprop.0>
    ba14:	9118c283 	add	x3, x20, #0x630
    ba18:	aa0003f5 	mov	x21, x0
    ba1c:	f949d861 	ldr	x1, [x3, #5040]
    ba20:	f949ec60 	ldr	x0, [x3, #5080]
    ba24:	cb0102a1 	sub	x1, x21, x1
    ba28:	eb00403f 	cmp	x1, x0, lsl #16
    ba2c:	54000322 	b.cs	ba90 <f0+0x1b00>  // b.hs, b.nlast
    ba30:	d350fc22 	lsr	x2, x1, #16
    ba34:	f949fc63 	ldr	x3, [x3, #5112]
    ba38:	8b020842 	add	x2, x2, x2, lsl #2
    ba3c:	d37df042 	lsl	x2, x2, #3
    ba40:	8b020060 	add	x0, x3, x2
    ba44:	f9401017 	ldr	x23, [x0, #32]
    ba48:	b4000257 	cbz	x23, ba90 <f0+0x1b00>
    ba4c:	38626862 	ldrb	w2, [x3, x2]
    ba50:	7100085f 	cmp	w2, #0x2
    ba54:	54004f40 	b.eq	c43c <f0+0x24ac>  // b.none
    ba58:	7100045f 	cmp	w2, #0x1
    ba5c:	540001a1 	b.ne	ba90 <f0+0x1b00>  // b.any
    ba60:	29430002 	ldp	w2, w0, [x0, #24]
    ba64:	92403c21 	and	x1, x1, #0xffff
    ba68:	9b027c21 	mul	x1, x1, x2
    ba6c:	d360fc21 	lsr	x1, x1, #32
    ba70:	eb00003f 	cmp	x1, x0
    ba74:	540000e2 	b.cs	ba90 <f0+0x1b00>  // b.hs, b.nlast
    ba78:	8b0102f7 	add	x23, x23, x1
    ba7c:	394002e0 	ldrb	w0, [x23]
    ba80:	7103fc1f 	cmp	w0, #0xff
    ba84:	54005ae0 	b.eq	c5e0 <f0+0x2650>  // b.none
    ba88:	52800020 	mov	w0, #0x1                   	// #1
    ba8c:	390002e0 	strb	w0, [x23]
    ba90:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ba94:	911b23e1 	add	x1, sp, #0x6c8
    ba98:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ba9c:	52800020 	mov	w0, #0x1                   	// #1
    baa0:	f90367e2 	str	x2, [sp, #1736]
    baa4:	f9036bf5 	str	x21, [sp, #1744]
    baa8:	97ffe5fb 	bl	5294 <fwp_data.part.0.constprop.0>
    baac:	9118c283 	add	x3, x20, #0x630
    bab0:	aa0003f5 	mov	x21, x0
    bab4:	f949d861 	ldr	x1, [x3, #5040]
    bab8:	f949ec60 	ldr	x0, [x3, #5080]
    babc:	cb0102a1 	sub	x1, x21, x1
    bac0:	eb00403f 	cmp	x1, x0, lsl #16
    bac4:	54000322 	b.cs	bb28 <f0+0x1b98>  // b.hs, b.nlast
    bac8:	d350fc22 	lsr	x2, x1, #16
    bacc:	f949fc63 	ldr	x3, [x3, #5112]
    bad0:	8b020842 	add	x2, x2, x2, lsl #2
    bad4:	d37df042 	lsl	x2, x2, #3
    bad8:	8b020060 	add	x0, x3, x2
    badc:	f9401017 	ldr	x23, [x0, #32]
    bae0:	b4000257 	cbz	x23, bb28 <f0+0x1b98>
    bae4:	38626862 	ldrb	w2, [x3, x2]
    bae8:	7100085f 	cmp	w2, #0x2
    baec:	54004a20 	b.eq	c430 <f0+0x24a0>  // b.none
    baf0:	7100045f 	cmp	w2, #0x1
    baf4:	540001a1 	b.ne	bb28 <f0+0x1b98>  // b.any
    baf8:	29430002 	ldp	w2, w0, [x0, #24]
    bafc:	92403c21 	and	x1, x1, #0xffff
    bb00:	9b027c21 	mul	x1, x1, x2
    bb04:	d360fc21 	lsr	x1, x1, #32
    bb08:	eb00003f 	cmp	x1, x0
    bb0c:	540000e2 	b.cs	bb28 <f0+0x1b98>  // b.hs, b.nlast
    bb10:	8b0102f7 	add	x23, x23, x1
    bb14:	394002e0 	ldrb	w0, [x23]
    bb18:	7103fc1f 	cmp	w0, #0xff
    bb1c:	54005680 	b.eq	c5ec <f0+0x265c>  // b.none
    bb20:	52800020 	mov	w0, #0x1                   	// #1
    bb24:	390002e0 	strb	w0, [x23]
    bb28:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb2c:	911b63e1 	add	x1, sp, #0x6d8
    bb30:	52800020 	mov	w0, #0x1                   	// #1
    bb34:	f9036fe2 	str	x2, [sp, #1752]
    bb38:	f90373f5 	str	x21, [sp, #1760]
    bb3c:	97ffe5d6 	bl	5294 <fwp_data.part.0.constprop.0>
    bb40:	9118c283 	add	x3, x20, #0x630
    bb44:	aa0003f5 	mov	x21, x0
    bb48:	f949d861 	ldr	x1, [x3, #5040]
    bb4c:	f949ec60 	ldr	x0, [x3, #5080]
    bb50:	cb0102a1 	sub	x1, x21, x1
    bb54:	eb00403f 	cmp	x1, x0, lsl #16
    bb58:	54000322 	b.cs	bbbc <f0+0x1c2c>  // b.hs, b.nlast
    bb5c:	d350fc22 	lsr	x2, x1, #16
    bb60:	f949fc63 	ldr	x3, [x3, #5112]
    bb64:	8b020842 	add	x2, x2, x2, lsl #2
    bb68:	d37df042 	lsl	x2, x2, #3
    bb6c:	8b020060 	add	x0, x3, x2
    bb70:	f9401017 	ldr	x23, [x0, #32]
    bb74:	b4000257 	cbz	x23, bbbc <f0+0x1c2c>
    bb78:	38626862 	ldrb	w2, [x3, x2]
    bb7c:	7100085f 	cmp	w2, #0x2
    bb80:	54004520 	b.eq	c424 <f0+0x2494>  // b.none
    bb84:	7100045f 	cmp	w2, #0x1
    bb88:	540001a1 	b.ne	bbbc <f0+0x1c2c>  // b.any
    bb8c:	29430002 	ldp	w2, w0, [x0, #24]
    bb90:	92403c21 	and	x1, x1, #0xffff
    bb94:	9b027c21 	mul	x1, x1, x2
    bb98:	d360fc21 	lsr	x1, x1, #32
    bb9c:	eb00003f 	cmp	x1, x0
    bba0:	540000e2 	b.cs	bbbc <f0+0x1c2c>  // b.hs, b.nlast
    bba4:	8b0102f7 	add	x23, x23, x1
    bba8:	394002e0 	ldrb	w0, [x23]
    bbac:	7103fc1f 	cmp	w0, #0xff
    bbb0:	54005240 	b.eq	c5f8 <f0+0x2668>  // b.none
    bbb4:	52800020 	mov	w0, #0x1                   	// #1
    bbb8:	390002e0 	strb	w0, [x23]
    bbbc:	911ba3e1 	add	x1, sp, #0x6e8
    bbc0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bbc4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bbc8:	52800020 	mov	w0, #0x1                   	// #1
    bbcc:	f90377f7 	str	x23, [sp, #1768]
    bbd0:	f9037bf5 	str	x21, [sp, #1776]
    bbd4:	97ffe5b0 	bl	5294 <fwp_data.part.0.constprop.0>
    bbd8:	97ffe74f 	bl	5914 <fwp_rc_fresh>
    bbdc:	aa0003e2 	mov	x2, x0
    bbe0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bbe4:	911be3e1 	add	x1, sp, #0x6f8
    bbe8:	52800020 	mov	w0, #0x1                   	// #1
    bbec:	f9037fe3 	str	x3, [sp, #1784]
    bbf0:	f90383e2 	str	x2, [sp, #1792]
    bbf4:	97ffe5a8 	bl	5294 <fwp_data.part.0.constprop.0>
    bbf8:	97ffe747 	bl	5914 <fwp_rc_fresh>
    bbfc:	aa0003e2 	mov	x2, x0
    bc00:	911c23e1 	add	x1, sp, #0x708
    bc04:	52800020 	mov	w0, #0x1                   	// #1
    bc08:	f90387f7 	str	x23, [sp, #1800]
    bc0c:	f9038be2 	str	x2, [sp, #1808]
    bc10:	97ffe5a1 	bl	5294 <fwp_data.part.0.constprop.0>
    bc14:	9118c283 	add	x3, x20, #0x630
    bc18:	aa0003f5 	mov	x21, x0
    bc1c:	f949d861 	ldr	x1, [x3, #5040]
    bc20:	f949ec60 	ldr	x0, [x3, #5080]
    bc24:	cb0102a1 	sub	x1, x21, x1
    bc28:	eb00403f 	cmp	x1, x0, lsl #16
    bc2c:	54000322 	b.cs	bc90 <f0+0x1d00>  // b.hs, b.nlast
    bc30:	d350fc22 	lsr	x2, x1, #16
    bc34:	f949fc63 	ldr	x3, [x3, #5112]
    bc38:	8b020842 	add	x2, x2, x2, lsl #2
    bc3c:	d37df042 	lsl	x2, x2, #3
    bc40:	8b020060 	add	x0, x3, x2
    bc44:	f9401017 	ldr	x23, [x0, #32]
    bc48:	b4000257 	cbz	x23, bc90 <f0+0x1d00>
    bc4c:	38626862 	ldrb	w2, [x3, x2]
    bc50:	7100085f 	cmp	w2, #0x2
    bc54:	54003e20 	b.eq	c418 <f0+0x2488>  // b.none
    bc58:	7100045f 	cmp	w2, #0x1
    bc5c:	540001a1 	b.ne	bc90 <f0+0x1d00>  // b.any
    bc60:	29430002 	ldp	w2, w0, [x0, #24]
    bc64:	92403c21 	and	x1, x1, #0xffff
    bc68:	9b027c21 	mul	x1, x1, x2
    bc6c:	d360fc21 	lsr	x1, x1, #32
    bc70:	eb00003f 	cmp	x1, x0
    bc74:	540000e2 	b.cs	bc90 <f0+0x1d00>  // b.hs, b.nlast
    bc78:	8b0102f7 	add	x23, x23, x1
    bc7c:	394002e0 	ldrb	w0, [x23]
    bc80:	7103fc1f 	cmp	w0, #0xff
    bc84:	54004c00 	b.eq	c604 <f0+0x2674>  // b.none
    bc88:	52800020 	mov	w0, #0x1                   	// #1
    bc8c:	390002e0 	strb	w0, [x23]
    bc90:	911c63e1 	add	x1, sp, #0x718
    bc94:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc98:	52800020 	mov	w0, #0x1                   	// #1
    bc9c:	f9038ff7 	str	x23, [sp, #1816]
    bca0:	f90393f5 	str	x21, [sp, #1824]
    bca4:	97ffe57c 	bl	5294 <fwp_data.part.0.constprop.0>
    bca8:	97ffe71b 	bl	5914 <fwp_rc_fresh>
    bcac:	aa0003e2 	mov	x2, x0
    bcb0:	911ca3e1 	add	x1, sp, #0x728
    bcb4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bcb8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bcbc:	52800020 	mov	w0, #0x1                   	// #1
    bcc0:	f90397f5 	str	x21, [sp, #1832]
    bcc4:	f9039be2 	str	x2, [sp, #1840]
    bcc8:	97ffe573 	bl	5294 <fwp_data.part.0.constprop.0>
    bccc:	97ffe712 	bl	5914 <fwp_rc_fresh>
    bcd0:	aa0003e2 	mov	x2, x0
    bcd4:	911ce3e1 	add	x1, sp, #0x738
    bcd8:	52800020 	mov	w0, #0x1                   	// #1
    bcdc:	f9039ff7 	str	x23, [sp, #1848]
    bce0:	f903a3e2 	str	x2, [sp, #1856]
    bce4:	97ffe56c 	bl	5294 <fwp_data.part.0.constprop.0>
    bce8:	97ffe70b 	bl	5914 <fwp_rc_fresh>
    bcec:	aa0003e2 	mov	x2, x0
    bcf0:	911d23e1 	add	x1, sp, #0x748
    bcf4:	52800020 	mov	w0, #0x1                   	// #1
    bcf8:	f903a7f5 	str	x21, [sp, #1864]
    bcfc:	f903abe2 	str	x2, [sp, #1872]
    bd00:	97ffe565 	bl	5294 <fwp_data.part.0.constprop.0>
    bd04:	97ffe704 	bl	5914 <fwp_rc_fresh>
    bd08:	aa0003e2 	mov	x2, x0
    bd0c:	911d63e1 	add	x1, sp, #0x758
    bd10:	52800020 	mov	w0, #0x1                   	// #1
    bd14:	f903aff7 	str	x23, [sp, #1880]
    bd18:	f903b3e2 	str	x2, [sp, #1888]
    bd1c:	97ffe55e 	bl	5294 <fwp_data.part.0.constprop.0>
    bd20:	9118c283 	add	x3, x20, #0x630
    bd24:	aa0003f5 	mov	x21, x0
    bd28:	f949d861 	ldr	x1, [x3, #5040]
    bd2c:	f949ec60 	ldr	x0, [x3, #5080]
    bd30:	cb0102a1 	sub	x1, x21, x1
    bd34:	eb00403f 	cmp	x1, x0, lsl #16
    bd38:	54000322 	b.cs	bd9c <f0+0x1e0c>  // b.hs, b.nlast
    bd3c:	d350fc22 	lsr	x2, x1, #16
    bd40:	f949fc63 	ldr	x3, [x3, #5112]
    bd44:	8b020842 	add	x2, x2, x2, lsl #2
    bd48:	d37df042 	lsl	x2, x2, #3
    bd4c:	8b020060 	add	x0, x3, x2
    bd50:	f9401017 	ldr	x23, [x0, #32]
    bd54:	b4000257 	cbz	x23, bd9c <f0+0x1e0c>
    bd58:	38626862 	ldrb	w2, [x3, x2]
    bd5c:	7100085f 	cmp	w2, #0x2
    bd60:	54003560 	b.eq	c40c <f0+0x247c>  // b.none
    bd64:	7100045f 	cmp	w2, #0x1
    bd68:	540001a1 	b.ne	bd9c <f0+0x1e0c>  // b.any
    bd6c:	29430002 	ldp	w2, w0, [x0, #24]
    bd70:	92403c21 	and	x1, x1, #0xffff
    bd74:	9b027c21 	mul	x1, x1, x2
    bd78:	d360fc21 	lsr	x1, x1, #32
    bd7c:	eb00003f 	cmp	x1, x0
    bd80:	540000e2 	b.cs	bd9c <f0+0x1e0c>  // b.hs, b.nlast
    bd84:	8b0102f7 	add	x23, x23, x1
    bd88:	394002e0 	ldrb	w0, [x23]
    bd8c:	7103fc1f 	cmp	w0, #0xff
    bd90:	54004400 	b.eq	c610 <f0+0x2680>  // b.none
    bd94:	52800020 	mov	w0, #0x1                   	// #1
    bd98:	390002e0 	strb	w0, [x23]
    bd9c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bda0:	911da3e1 	add	x1, sp, #0x768
    bda4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bda8:	52800020 	mov	w0, #0x1                   	// #1
    bdac:	f903b7e2 	str	x2, [sp, #1896]
    bdb0:	f903bbf5 	str	x21, [sp, #1904]
    bdb4:	97ffe538 	bl	5294 <fwp_data.part.0.constprop.0>
    bdb8:	9118c283 	add	x3, x20, #0x630
    bdbc:	aa0003f5 	mov	x21, x0
    bdc0:	f949d861 	ldr	x1, [x3, #5040]
    bdc4:	f949ec60 	ldr	x0, [x3, #5080]
    bdc8:	cb0102a1 	sub	x1, x21, x1
    bdcc:	eb00403f 	cmp	x1, x0, lsl #16
    bdd0:	54000322 	b.cs	be34 <f0+0x1ea4>  // b.hs, b.nlast
    bdd4:	d350fc22 	lsr	x2, x1, #16
    bdd8:	f949fc63 	ldr	x3, [x3, #5112]
    bddc:	8b020842 	add	x2, x2, x2, lsl #2
    bde0:	d37df042 	lsl	x2, x2, #3
    bde4:	8b020060 	add	x0, x3, x2
    bde8:	f9401017 	ldr	x23, [x0, #32]
    bdec:	b4000257 	cbz	x23, be34 <f0+0x1ea4>
    bdf0:	38626862 	ldrb	w2, [x3, x2]
    bdf4:	7100085f 	cmp	w2, #0x2
    bdf8:	54003040 	b.eq	c400 <f0+0x2470>  // b.none
    bdfc:	7100045f 	cmp	w2, #0x1
    be00:	540001a1 	b.ne	be34 <f0+0x1ea4>  // b.any
    be04:	29430002 	ldp	w2, w0, [x0, #24]
    be08:	92403c21 	and	x1, x1, #0xffff
    be0c:	9b027c21 	mul	x1, x1, x2
    be10:	d360fc21 	lsr	x1, x1, #32
    be14:	eb00003f 	cmp	x1, x0
    be18:	540000e2 	b.cs	be34 <f0+0x1ea4>  // b.hs, b.nlast
    be1c:	8b0102f7 	add	x23, x23, x1
    be20:	394002e0 	ldrb	w0, [x23]
    be24:	7103fc1f 	cmp	w0, #0xff
    be28:	54003fa0 	b.eq	c61c <f0+0x268c>  // b.none
    be2c:	52800020 	mov	w0, #0x1                   	// #1
    be30:	390002e0 	strb	w0, [x23]
    be34:	911de3e1 	add	x1, sp, #0x778
    be38:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    be3c:	52800020 	mov	w0, #0x1                   	// #1
    be40:	f903bff7 	str	x23, [sp, #1912]
    be44:	f903c3f5 	str	x21, [sp, #1920]
    be48:	97ffe513 	bl	5294 <fwp_data.part.0.constprop.0>
    be4c:	97ffe6b2 	bl	5914 <fwp_rc_fresh>
    be50:	aa0003e2 	mov	x2, x0
    be54:	911e23e1 	add	x1, sp, #0x788
    be58:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    be5c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    be60:	52800020 	mov	w0, #0x1                   	// #1
    be64:	f903c7f5 	str	x21, [sp, #1928]
    be68:	f903cbe2 	str	x2, [sp, #1936]
    be6c:	97ffe50a 	bl	5294 <fwp_data.part.0.constprop.0>
    be70:	97ffe6a9 	bl	5914 <fwp_rc_fresh>
    be74:	aa0003e2 	mov	x2, x0
    be78:	911e63e1 	add	x1, sp, #0x798
    be7c:	52800020 	mov	w0, #0x1                   	// #1
    be80:	f903cff7 	str	x23, [sp, #1944]
    be84:	f903d3e2 	str	x2, [sp, #1952]
    be88:	97ffe503 	bl	5294 <fwp_data.part.0.constprop.0>
    be8c:	97ffe6a2 	bl	5914 <fwp_rc_fresh>
    be90:	aa0003e2 	mov	x2, x0
    be94:	911ea3e1 	add	x1, sp, #0x7a8
    be98:	52800020 	mov	w0, #0x1                   	// #1
    be9c:	f903d7f5 	str	x21, [sp, #1960]
    bea0:	f903dbe2 	str	x2, [sp, #1968]
    bea4:	97ffe4fc 	bl	5294 <fwp_data.part.0.constprop.0>
    bea8:	9118c283 	add	x3, x20, #0x630
    beac:	aa0003f5 	mov	x21, x0
    beb0:	f949d861 	ldr	x1, [x3, #5040]
    beb4:	f949ec60 	ldr	x0, [x3, #5080]
    beb8:	cb0102a1 	sub	x1, x21, x1
    bebc:	eb00403f 	cmp	x1, x0, lsl #16
    bec0:	54000322 	b.cs	bf24 <f0+0x1f94>  // b.hs, b.nlast
    bec4:	d350fc22 	lsr	x2, x1, #16
    bec8:	f949fc63 	ldr	x3, [x3, #5112]
    becc:	8b020842 	add	x2, x2, x2, lsl #2
    bed0:	d37df042 	lsl	x2, x2, #3
    bed4:	8b020060 	add	x0, x3, x2
    bed8:	f9401017 	ldr	x23, [x0, #32]
    bedc:	b4000257 	cbz	x23, bf24 <f0+0x1f94>
    bee0:	38626862 	ldrb	w2, [x3, x2]
    bee4:	7100085f 	cmp	w2, #0x2
    bee8:	54002860 	b.eq	c3f4 <f0+0x2464>  // b.none
    beec:	7100045f 	cmp	w2, #0x1
    bef0:	540001a1 	b.ne	bf24 <f0+0x1f94>  // b.any
    bef4:	29430002 	ldp	w2, w0, [x0, #24]
    bef8:	92403c21 	and	x1, x1, #0xffff
    befc:	9b027c21 	mul	x1, x1, x2
    bf00:	d360fc21 	lsr	x1, x1, #32
    bf04:	eb00003f 	cmp	x1, x0
    bf08:	540000e2 	b.cs	bf24 <f0+0x1f94>  // b.hs, b.nlast
    bf0c:	8b0102f7 	add	x23, x23, x1
    bf10:	394002e0 	ldrb	w0, [x23]
    bf14:	7103fc1f 	cmp	w0, #0xff
    bf18:	54003880 	b.eq	c628 <f0+0x2698>  // b.none
    bf1c:	52800020 	mov	w0, #0x1                   	// #1
    bf20:	390002e0 	strb	w0, [x23]
    bf24:	911ee3e1 	add	x1, sp, #0x7b8
    bf28:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bf2c:	52800020 	mov	w0, #0x1                   	// #1
    bf30:	f903dfe2 	str	x2, [sp, #1976]
    bf34:	f903e3f5 	str	x21, [sp, #1984]
    bf38:	97ffe4d7 	bl	5294 <fwp_data.part.0.constprop.0>
    bf3c:	97ffe676 	bl	5914 <fwp_rc_fresh>
    bf40:	aa0003e2 	mov	x2, x0
    bf44:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bf48:	911f23e1 	add	x1, sp, #0x7c8
    bf4c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bf50:	52800020 	mov	w0, #0x1                   	// #1
    bf54:	f903e7e3 	str	x3, [sp, #1992]
    bf58:	f903ebe2 	str	x2, [sp, #2000]
    bf5c:	97ffe4ce 	bl	5294 <fwp_data.part.0.constprop.0>
    bf60:	9118c283 	add	x3, x20, #0x630
    bf64:	aa0003f5 	mov	x21, x0
    bf68:	f949d861 	ldr	x1, [x3, #5040]
    bf6c:	f949ec60 	ldr	x0, [x3, #5080]
    bf70:	cb0102a1 	sub	x1, x21, x1
    bf74:	eb00403f 	cmp	x1, x0, lsl #16
    bf78:	54000322 	b.cs	bfdc <f0+0x204c>  // b.hs, b.nlast
    bf7c:	d350fc22 	lsr	x2, x1, #16
    bf80:	f949fc63 	ldr	x3, [x3, #5112]
    bf84:	8b020842 	add	x2, x2, x2, lsl #2
    bf88:	d37df042 	lsl	x2, x2, #3
    bf8c:	8b020060 	add	x0, x3, x2
    bf90:	f9401017 	ldr	x23, [x0, #32]
    bf94:	b4000257 	cbz	x23, bfdc <f0+0x204c>
    bf98:	38626862 	ldrb	w2, [x3, x2]
    bf9c:	7100085f 	cmp	w2, #0x2
    bfa0:	54002240 	b.eq	c3e8 <f0+0x2458>  // b.none
    bfa4:	7100045f 	cmp	w2, #0x1
    bfa8:	540001a1 	b.ne	bfdc <f0+0x204c>  // b.any
    bfac:	29430002 	ldp	w2, w0, [x0, #24]
    bfb0:	92403c21 	and	x1, x1, #0xffff
    bfb4:	9b027c21 	mul	x1, x1, x2
    bfb8:	d360fc21 	lsr	x1, x1, #32
    bfbc:	eb00003f 	cmp	x1, x0
    bfc0:	540000e2 	b.cs	bfdc <f0+0x204c>  // b.hs, b.nlast
    bfc4:	8b0102f7 	add	x23, x23, x1
    bfc8:	394002e0 	ldrb	w0, [x23]
    bfcc:	7103fc1f 	cmp	w0, #0xff
    bfd0:	54003320 	b.eq	c634 <f0+0x26a4>  // b.none
    bfd4:	52800020 	mov	w0, #0x1                   	// #1
    bfd8:	390002e0 	strb	w0, [x23]
    bfdc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bfe0:	911f63e1 	add	x1, sp, #0x7d8
    bfe4:	52800020 	mov	w0, #0x1                   	// #1
    bfe8:	f903efe2 	str	x2, [sp, #2008]
    bfec:	f903f3f5 	str	x21, [sp, #2016]
    bff0:	97ffe4a9 	bl	5294 <fwp_data.part.0.constprop.0>
    bff4:	9118c283 	add	x3, x20, #0x630
    bff8:	aa0003f5 	mov	x21, x0
    bffc:	f949d861 	ldr	x1, [x3, #5040]
    c000:	f949ec60 	ldr	x0, [x3, #5080]
    c004:	cb0102a1 	sub	x1, x21, x1
    c008:	eb00403f 	cmp	x1, x0, lsl #16
    c00c:	54000322 	b.cs	c070 <f0+0x20e0>  // b.hs, b.nlast
    c010:	d350fc22 	lsr	x2, x1, #16
    c014:	f949fc63 	ldr	x3, [x3, #5112]
    c018:	8b020842 	add	x2, x2, x2, lsl #2
    c01c:	d37df042 	lsl	x2, x2, #3
    c020:	8b020060 	add	x0, x3, x2
    c024:	f9401017 	ldr	x23, [x0, #32]
    c028:	b4000257 	cbz	x23, c070 <f0+0x20e0>
    c02c:	38626862 	ldrb	w2, [x3, x2]
    c030:	7100085f 	cmp	w2, #0x2
    c034:	54001d40 	b.eq	c3dc <f0+0x244c>  // b.none
    c038:	7100045f 	cmp	w2, #0x1
    c03c:	540001a1 	b.ne	c070 <f0+0x20e0>  // b.any
    c040:	29430002 	ldp	w2, w0, [x0, #24]
    c044:	92403c21 	and	x1, x1, #0xffff
    c048:	9b027c21 	mul	x1, x1, x2
    c04c:	d360fc21 	lsr	x1, x1, #32
    c050:	eb00003f 	cmp	x1, x0
    c054:	540000e2 	b.cs	c070 <f0+0x20e0>  // b.hs, b.nlast
    c058:	8b0102f7 	add	x23, x23, x1
    c05c:	394002e0 	ldrb	w0, [x23]
    c060:	7103fc1f 	cmp	w0, #0xff
    c064:	54002ee0 	b.eq	c640 <f0+0x26b0>  // b.none
    c068:	52800020 	mov	w0, #0x1                   	// #1
    c06c:	390002e0 	strb	w0, [x23]
    c070:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c074:	911fa3e1 	add	x1, sp, #0x7e8
    c078:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c07c:	52800020 	mov	w0, #0x1                   	// #1
    c080:	f903f7e2 	str	x2, [sp, #2024]
    c084:	f903fbf5 	str	x21, [sp, #2032]
    c088:	97ffe483 	bl	5294 <fwp_data.part.0.constprop.0>
    c08c:	9118c283 	add	x3, x20, #0x630
    c090:	aa0003f5 	mov	x21, x0
    c094:	f949d861 	ldr	x1, [x3, #5040]
    c098:	f949ec60 	ldr	x0, [x3, #5080]
    c09c:	cb0102a1 	sub	x1, x21, x1
    c0a0:	eb00403f 	cmp	x1, x0, lsl #16
    c0a4:	54000322 	b.cs	c108 <f0+0x2178>  // b.hs, b.nlast
    c0a8:	d350fc22 	lsr	x2, x1, #16
    c0ac:	f949fc63 	ldr	x3, [x3, #5112]
    c0b0:	8b020842 	add	x2, x2, x2, lsl #2
    c0b4:	d37df042 	lsl	x2, x2, #3
    c0b8:	8b020060 	add	x0, x3, x2
    c0bc:	f9401017 	ldr	x23, [x0, #32]
    c0c0:	b4000257 	cbz	x23, c108 <f0+0x2178>
    c0c4:	38626862 	ldrb	w2, [x3, x2]
    c0c8:	7100085f 	cmp	w2, #0x2
    c0cc:	54001820 	b.eq	c3d0 <f0+0x2440>  // b.none
    c0d0:	7100045f 	cmp	w2, #0x1
    c0d4:	540001a1 	b.ne	c108 <f0+0x2178>  // b.any
    c0d8:	29430002 	ldp	w2, w0, [x0, #24]
    c0dc:	92403c21 	and	x1, x1, #0xffff
    c0e0:	9b027c21 	mul	x1, x1, x2
    c0e4:	d360fc21 	lsr	x1, x1, #32
    c0e8:	eb00003f 	cmp	x1, x0
    c0ec:	540000e2 	b.cs	c108 <f0+0x2178>  // b.hs, b.nlast
    c0f0:	8b0102f7 	add	x23, x23, x1
    c0f4:	394002e0 	ldrb	w0, [x23]
    c0f8:	7103fc1f 	cmp	w0, #0xff
    c0fc:	54002a80 	b.eq	c64c <f0+0x26bc>  // b.none
    c100:	52800020 	mov	w0, #0x1                   	// #1
    c104:	390002e0 	strb	w0, [x23]
    c108:	911fe3e1 	add	x1, sp, #0x7f8
    c10c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c110:	52800020 	mov	w0, #0x1                   	// #1
    c114:	f903fff7 	str	x23, [sp, #2040]
    c118:	f90403f5 	str	x21, [sp, #2048]
    c11c:	97ffe45e 	bl	5294 <fwp_data.part.0.constprop.0>
    c120:	97ffe5fd 	bl	5914 <fwp_rc_fresh>
    c124:	aa0003e2 	mov	x2, x0
    c128:	912023e1 	add	x1, sp, #0x808
    c12c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c130:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c134:	52800020 	mov	w0, #0x1                   	// #1
    c138:	f90407f5 	str	x21, [sp, #2056]
    c13c:	9118c294 	add	x20, x20, #0x630
    c140:	f9040be2 	str	x2, [sp, #2064]
    c144:	97ffe454 	bl	5294 <fwp_data.part.0.constprop.0>
    c148:	97ffe5f3 	bl	5914 <fwp_rc_fresh>
    c14c:	aa0003e2 	mov	x2, x0
    c150:	912063e1 	add	x1, sp, #0x818
    c154:	52800020 	mov	w0, #0x1                   	// #1
    c158:	f9040ff7 	str	x23, [sp, #2072]
    c15c:	f90413e2 	str	x2, [sp, #2080]
    c160:	97ffe44d 	bl	5294 <fwp_data.part.0.constprop.0>
    c164:	97ffe5ec 	bl	5914 <fwp_rc_fresh>
    c168:	aa0003e2 	mov	x2, x0
    c16c:	9120a3e1 	add	x1, sp, #0x828
    c170:	52800020 	mov	w0, #0x1                   	// #1
    c174:	f90417f5 	str	x21, [sp, #2088]
    c178:	f9041be2 	str	x2, [sp, #2096]
    c17c:	97ffe446 	bl	5294 <fwp_data.part.0.constprop.0>
    c180:	f949da81 	ldr	x1, [x20, #5040]
    c184:	aa0003f5 	mov	x21, x0
    c188:	f949ee80 	ldr	x0, [x20, #5080]
    c18c:	cb0102a1 	sub	x1, x21, x1
    c190:	eb00403f 	cmp	x1, x0, lsl #16
    c194:	54000322 	b.cs	c1f8 <f0+0x2268>  // b.hs, b.nlast
    c198:	d350fc22 	lsr	x2, x1, #16
    c19c:	f949fe83 	ldr	x3, [x20, #5112]
    c1a0:	8b020842 	add	x2, x2, x2, lsl #2
    c1a4:	d37df042 	lsl	x2, x2, #3
    c1a8:	8b020060 	add	x0, x3, x2
    c1ac:	f9401014 	ldr	x20, [x0, #32]
    c1b0:	b4000254 	cbz	x20, c1f8 <f0+0x2268>
    c1b4:	38626862 	ldrb	w2, [x3, x2]
    c1b8:	7100085f 	cmp	w2, #0x2
    c1bc:	54001040 	b.eq	c3c4 <f0+0x2434>  // b.none
    c1c0:	7100045f 	cmp	w2, #0x1
    c1c4:	540001a1 	b.ne	c1f8 <f0+0x2268>  // b.any
    c1c8:	29430002 	ldp	w2, w0, [x0, #24]
    c1cc:	92403c21 	and	x1, x1, #0xffff
    c1d0:	9b027c21 	mul	x1, x1, x2
    c1d4:	d360fc21 	lsr	x1, x1, #32
    c1d8:	eb00003f 	cmp	x1, x0
    c1dc:	540000e2 	b.cs	c1f8 <f0+0x2268>  // b.hs, b.nlast
    c1e0:	8b010294 	add	x20, x20, x1
    c1e4:	39400280 	ldrb	w0, [x20]
    c1e8:	7103fc1f 	cmp	w0, #0xff
    c1ec:	540014c0 	b.eq	c484 <f0+0x24f4>  // b.none
    c1f0:	52800020 	mov	w0, #0x1                   	// #1
    c1f4:	39000280 	strb	w0, [x20]
    c1f8:	9120e3e1 	add	x1, sp, #0x838
    c1fc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c200:	52800020 	mov	w0, #0x1                   	// #1
    c204:	f9041fe2 	str	x2, [sp, #2104]
    c208:	f90423f5 	str	x21, [sp, #2112]
    c20c:	97ffe422 	bl	5294 <fwp_data.part.0.constprop.0>
    c210:	97ffe5c1 	bl	5914 <fwp_rc_fresh>
    c214:	aa0003e2 	mov	x2, x0
    c218:	aa1603e1 	mov	x1, x22
    c21c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c220:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c224:	52800020 	mov	w0, #0x1                   	// #1
    c228:	f90427e3 	str	x3, [sp, #2120]
    c22c:	f9042be2 	str	x2, [sp, #2128]
    c230:	97ffe419 	bl	5294 <fwp_data.part.0.constprop.0>
    c234:	97ffe5b8 	bl	5914 <fwp_rc_fresh>
    c238:	aa0003f5 	mov	x21, x0
    c23c:	aa1303e1 	mov	x1, x19
    c240:	97fff070 	bl	8400 <fwp_hof0.constprop.0>
    c244:	aa0003f4 	mov	x20, x0
    c248:	aa1503e0 	mov	x0, x21
    c24c:	97ffe715 	bl	5ea0 <fwp_drop0>
    c250:	aa1303e0 	mov	x0, x19
    c254:	97ffe713 	bl	5ea0 <fwp_drop0>
    c258:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c25c:	f947f400 	ldr	x0, [x0, #4072]
    c260:	f9442fe2 	ldr	x2, [sp, #2136]
    c264:	f9400001 	ldr	x1, [x0]
    c268:	eb010042 	subs	x2, x2, x1
    c26c:	d2800001 	mov	x1, #0x0                   	// #0
    c270:	54001f41 	b.ne	c658 <f0+0x26c8>  // b.any
    c274:	912183ff 	add	sp, sp, #0x860
    c278:	aa1403e0 	mov	x0, x20
    c27c:	a94153f3 	ldp	x19, x20, [sp, #16]
    c280:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c284:	a94363f7 	ldp	x23, x24, [sp, #48]
    c288:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c28c:	a94573fb 	ldp	x27, x28, [sp, #80]
    c290:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c294:	d65f03c0 	ret
    c298:	aa1b03e0 	mov	x0, x27
    c29c:	97ffe1dd 	bl	4a10 <fwp_rc_forget_slot>
    c2a0:	17fff784 	b	a0b0 <f0+0x120>
    c2a4:	72003c5f 	tst	w2, #0xffff
    c2a8:	54fef061 	b.ne	a0b4 <f0+0x124>  // b.any
    c2ac:	17fff77e 	b	a0a4 <f0+0x114>
    c2b0:	72003c3f 	tst	w1, #0xffff
    c2b4:	54ff9de1 	b.ne	b670 <f0+0x16e0>  // b.any
    c2b8:	17fffce9 	b	b65c <f0+0x16cc>
    c2bc:	72003c3f 	tst	w1, #0xffff
    c2c0:	54ff97c1 	b.ne	b5b8 <f0+0x1628>  // b.any
    c2c4:	17fffcb8 	b	b5a4 <f0+0x1614>
    c2c8:	72003c3f 	tst	w1, #0xffff
    c2cc:	54ff92a1 	b.ne	b520 <f0+0x1590>  // b.any
    c2d0:	17fffc8f 	b	b50c <f0+0x157c>
    c2d4:	72003c3f 	tst	w1, #0xffff
    c2d8:	54ff8ba1 	b.ne	b44c <f0+0x14bc>  // b.any
    c2dc:	17fffc57 	b	b438 <f0+0x14a8>
    c2e0:	72003c3f 	tst	w1, #0xffff
    c2e4:	54ff8581 	b.ne	b394 <f0+0x1404>  // b.any
    c2e8:	17fffc26 	b	b380 <f0+0x13f0>
    c2ec:	72003c3f 	tst	w1, #0xffff
    c2f0:	54ff7f61 	b.ne	b2dc <f0+0x134c>  // b.any
    c2f4:	17fffbf5 	b	b2c8 <f0+0x1338>
    c2f8:	72003c3f 	tst	w1, #0xffff
    c2fc:	54ff7a41 	b.ne	b244 <f0+0x12b4>  // b.any
    c300:	17fffbcc 	b	b230 <f0+0x12a0>
    c304:	72003c3f 	tst	w1, #0xffff
    c308:	54ff7341 	b.ne	b170 <f0+0x11e0>  // b.any
    c30c:	17fffb94 	b	b15c <f0+0x11cc>
    c310:	72003c3f 	tst	w1, #0xffff
    c314:	54ff1d21 	b.ne	a6b8 <f0+0x728>  // b.any
    c318:	17fff8e3 	b	a6a4 <f0+0x714>
    c31c:	72003c3f 	tst	w1, #0xffff
    c320:	54ff1701 	b.ne	a600 <f0+0x670>  // b.any
    c324:	17fff8b2 	b	a5ec <f0+0x65c>
    c328:	72003c3f 	tst	w1, #0xffff
    c32c:	54ff0d61 	b.ne	a4d8 <f0+0x548>  // b.any
    c330:	17fff865 	b	a4c4 <f0+0x534>
    c334:	72003c3f 	tst	w1, #0xffff
    c338:	54ff3ac1 	b.ne	aa90 <f0+0xb00>  // b.any
    c33c:	17fff9d0 	b	aa7c <f0+0xaec>
    c340:	72003c3f 	tst	w1, #0xffff
    c344:	54ff34a1 	b.ne	a9d8 <f0+0xa48>  // b.any
    c348:	17fff99f 	b	a9c4 <f0+0xa34>
    c34c:	72003c3f 	tst	w1, #0xffff
    c350:	54ff2781 	b.ne	a840 <f0+0x8b0>  // b.any
    c354:	17fff936 	b	a82c <f0+0x89c>
    c358:	72003c3f 	tst	w1, #0xffff
    c35c:	54ff1fa1 	b.ne	a750 <f0+0x7c0>  // b.any
    c360:	17fff8f7 	b	a73c <f0+0x7ac>
    c364:	72003c3f 	tst	w1, #0xffff
    c368:	54ff6a81 	b.ne	b0b8 <f0+0x1128>  // b.any
    c36c:	17fffb4e 	b	b0a4 <f0+0x1114>
    c370:	72003c3f 	tst	w1, #0xffff
    c374:	54ff6461 	b.ne	b000 <f0+0x1070>  // b.any
    c378:	17fffb1d 	b	afec <f0+0x105c>
    c37c:	72003c3f 	tst	w1, #0xffff
    c380:	54ff5f41 	b.ne	af68 <f0+0xfd8>  // b.any
    c384:	17fffaf4 	b	af54 <f0+0xfc4>
    c388:	72003c3f 	tst	w1, #0xffff
    c38c:	54ff5841 	b.ne	ae94 <f0+0xf04>  // b.any
    c390:	17fffabc 	b	ae80 <f0+0xef0>
    c394:	72003c3f 	tst	w1, #0xffff
    c398:	54ff5221 	b.ne	addc <f0+0xe4c>  // b.any
    c39c:	17fffa8b 	b	adc8 <f0+0xe38>
    c3a0:	72003c3f 	tst	w1, #0xffff
    c3a4:	54ff4c01 	b.ne	ad24 <f0+0xd94>  // b.any
    c3a8:	17fffa5a 	b	ad10 <f0+0xd80>
    c3ac:	72003c3f 	tst	w1, #0xffff
    c3b0:	54ff46e1 	b.ne	ac8c <f0+0xcfc>  // b.any
    c3b4:	17fffa31 	b	ac78 <f0+0xce8>
    c3b8:	72003c3f 	tst	w1, #0xffff
    c3bc:	54ff3c61 	b.ne	ab48 <f0+0xbb8>  // b.any
    c3c0:	17fff9dd 	b	ab34 <f0+0xba4>
    c3c4:	72003c3f 	tst	w1, #0xffff
    c3c8:	54fff181 	b.ne	c1f8 <f0+0x2268>  // b.any
    c3cc:	17ffff86 	b	c1e4 <f0+0x2254>
    c3d0:	72003c3f 	tst	w1, #0xffff
    c3d4:	54ffe9a1 	b.ne	c108 <f0+0x2178>  // b.any
    c3d8:	17ffff47 	b	c0f4 <f0+0x2164>
    c3dc:	72003c3f 	tst	w1, #0xffff
    c3e0:	54ffe481 	b.ne	c070 <f0+0x20e0>  // b.any
    c3e4:	17ffff1e 	b	c05c <f0+0x20cc>
    c3e8:	72003c3f 	tst	w1, #0xffff
    c3ec:	54ffdf81 	b.ne	bfdc <f0+0x204c>  // b.any
    c3f0:	17fffef6 	b	bfc8 <f0+0x2038>
    c3f4:	72003c3f 	tst	w1, #0xffff
    c3f8:	54ffd961 	b.ne	bf24 <f0+0x1f94>  // b.any
    c3fc:	17fffec5 	b	bf10 <f0+0x1f80>
    c400:	72003c3f 	tst	w1, #0xffff
    c404:	54ffd181 	b.ne	be34 <f0+0x1ea4>  // b.any
    c408:	17fffe86 	b	be20 <f0+0x1e90>
    c40c:	72003c3f 	tst	w1, #0xffff
    c410:	54ffcc61 	b.ne	bd9c <f0+0x1e0c>  // b.any
    c414:	17fffe5d 	b	bd88 <f0+0x1df8>
    c418:	72003c3f 	tst	w1, #0xffff
    c41c:	54ffc3a1 	b.ne	bc90 <f0+0x1d00>  // b.any
    c420:	17fffe17 	b	bc7c <f0+0x1cec>
    c424:	72003c3f 	tst	w1, #0xffff
    c428:	54ffbca1 	b.ne	bbbc <f0+0x1c2c>  // b.any
    c42c:	17fffddf 	b	bba8 <f0+0x1c18>
    c430:	72003c3f 	tst	w1, #0xffff
    c434:	54ffb7a1 	b.ne	bb28 <f0+0x1b98>  // b.any
    c438:	17fffdb7 	b	bb14 <f0+0x1b84>
    c43c:	72003c3f 	tst	w1, #0xffff
    c440:	54ffb281 	b.ne	ba90 <f0+0x1b00>  // b.any
    c444:	17fffd8e 	b	ba7c <f0+0x1aec>
    c448:	72003c3f 	tst	w1, #0xffff
    c44c:	54ffad81 	b.ne	b9fc <f0+0x1a6c>  // b.any
    c450:	17fffd66 	b	b9e8 <f0+0x1a58>
    c454:	72003c3f 	tst	w1, #0xffff
    c458:	54ffa5a1 	b.ne	b90c <f0+0x197c>  // b.any
    c45c:	17fffd27 	b	b8f8 <f0+0x1968>
    c460:	72003c3f 	tst	w1, #0xffff
    c464:	54ffa081 	b.ne	b874 <f0+0x18e4>  // b.any
    c468:	17fffcfe 	b	b860 <f0+0x18d0>
    c46c:	72003c3f 	tst	w1, #0xffff
    c470:	54ff9b81 	b.ne	b7e0 <f0+0x1850>  // b.any
    c474:	17fffcd6 	b	b7cc <f0+0x183c>
    c478:	72003c3f 	tst	w1, #0xffff
    c47c:	54ff9561 	b.ne	b728 <f0+0x1798>  // b.any
    c480:	17fffca5 	b	b714 <f0+0x1784>
    c484:	aa1403e0 	mov	x0, x20
    c488:	97ffe162 	bl	4a10 <fwp_rc_forget_slot>
    c48c:	17ffff59 	b	c1f0 <f0+0x2260>
    c490:	aa1703e0 	mov	x0, x23
    c494:	97ffe15f 	bl	4a10 <fwp_rc_forget_slot>
    c498:	17fff80e 	b	a4d0 <f0+0x540>
    c49c:	aa1703e0 	mov	x0, x23
    c4a0:	97ffe15c 	bl	4a10 <fwp_rc_forget_slot>
    c4a4:	17fff855 	b	a5f8 <f0+0x668>
    c4a8:	aa1703e0 	mov	x0, x23
    c4ac:	97ffe159 	bl	4a10 <fwp_rc_forget_slot>
    c4b0:	17fff880 	b	a6b0 <f0+0x720>
    c4b4:	aa1703e0 	mov	x0, x23
    c4b8:	97ffe156 	bl	4a10 <fwp_rc_forget_slot>
    c4bc:	17fff8a3 	b	a748 <f0+0x7b8>
    c4c0:	aa1703e0 	mov	x0, x23
    c4c4:	97ffe153 	bl	4a10 <fwp_rc_forget_slot>
    c4c8:	17fff8dc 	b	a838 <f0+0x8a8>
    c4cc:	aa1703e0 	mov	x0, x23
    c4d0:	97ffe150 	bl	4a10 <fwp_rc_forget_slot>
    c4d4:	17fff93f 	b	a9d0 <f0+0xa40>
    c4d8:	aa1703e0 	mov	x0, x23
    c4dc:	97ffe14d 	bl	4a10 <fwp_rc_forget_slot>
    c4e0:	17fff96a 	b	aa88 <f0+0xaf8>
    c4e4:	aa1503e0 	mov	x0, x21
    c4e8:	97ffe14a 	bl	4a10 <fwp_rc_forget_slot>
    c4ec:	17fff995 	b	ab40 <f0+0xbb0>
    c4f0:	aa1703e0 	mov	x0, x23
    c4f4:	97ffe147 	bl	4a10 <fwp_rc_forget_slot>
    c4f8:	17fff9e3 	b	ac84 <f0+0xcf4>
    c4fc:	aa1703e0 	mov	x0, x23
    c500:	97ffe144 	bl	4a10 <fwp_rc_forget_slot>
    c504:	17fffa06 	b	ad1c <f0+0xd8c>
    c508:	aa1703e0 	mov	x0, x23
    c50c:	97ffe141 	bl	4a10 <fwp_rc_forget_slot>
    c510:	17fffa31 	b	add4 <f0+0xe44>
    c514:	aa1703e0 	mov	x0, x23
    c518:	97ffe13e 	bl	4a10 <fwp_rc_forget_slot>
    c51c:	17fffa5c 	b	ae8c <f0+0xefc>
    c520:	aa1703e0 	mov	x0, x23
    c524:	97ffe13b 	bl	4a10 <fwp_rc_forget_slot>
    c528:	17fffa8e 	b	af60 <f0+0xfd0>
    c52c:	aa1703e0 	mov	x0, x23
    c530:	97ffe138 	bl	4a10 <fwp_rc_forget_slot>
    c534:	17fffab1 	b	aff8 <f0+0x1068>
    c538:	aa1703e0 	mov	x0, x23
    c53c:	97ffe135 	bl	4a10 <fwp_rc_forget_slot>
    c540:	17fffadc 	b	b0b0 <f0+0x1120>
    c544:	aa1703e0 	mov	x0, x23
    c548:	97ffe132 	bl	4a10 <fwp_rc_forget_slot>
    c54c:	17fffb07 	b	b168 <f0+0x11d8>
    c550:	aa1703e0 	mov	x0, x23
    c554:	97ffe12f 	bl	4a10 <fwp_rc_forget_slot>
    c558:	17fffb39 	b	b23c <f0+0x12ac>
    c55c:	aa1703e0 	mov	x0, x23
    c560:	97ffe12c 	bl	4a10 <fwp_rc_forget_slot>
    c564:	17fffb5c 	b	b2d4 <f0+0x1344>
    c568:	aa1703e0 	mov	x0, x23
    c56c:	97ffe129 	bl	4a10 <fwp_rc_forget_slot>
    c570:	17fffb87 	b	b38c <f0+0x13fc>
    c574:	aa1703e0 	mov	x0, x23
    c578:	97ffe126 	bl	4a10 <fwp_rc_forget_slot>
    c57c:	17fffbb2 	b	b444 <f0+0x14b4>
    c580:	aa1703e0 	mov	x0, x23
    c584:	97ffe123 	bl	4a10 <fwp_rc_forget_slot>
    c588:	17fffbe4 	b	b518 <f0+0x1588>
    c58c:	aa1703e0 	mov	x0, x23
    c590:	97ffe120 	bl	4a10 <fwp_rc_forget_slot>
    c594:	17fffc07 	b	b5b0 <f0+0x1620>
    c598:	aa1703e0 	mov	x0, x23
    c59c:	97ffe11d 	bl	4a10 <fwp_rc_forget_slot>
    c5a0:	17fffc32 	b	b668 <f0+0x16d8>
    c5a4:	aa1703e0 	mov	x0, x23
    c5a8:	97ffe11a 	bl	4a10 <fwp_rc_forget_slot>
    c5ac:	17fffc5d 	b	b720 <f0+0x1790>
    c5b0:	aa1703e0 	mov	x0, x23
    c5b4:	97ffe117 	bl	4a10 <fwp_rc_forget_slot>
    c5b8:	17fffc88 	b	b7d8 <f0+0x1848>
    c5bc:	aa1703e0 	mov	x0, x23
    c5c0:	97ffe114 	bl	4a10 <fwp_rc_forget_slot>
    c5c4:	17fffcaa 	b	b86c <f0+0x18dc>
    c5c8:	aa1703e0 	mov	x0, x23
    c5cc:	97ffe111 	bl	4a10 <fwp_rc_forget_slot>
    c5d0:	17fffccd 	b	b904 <f0+0x1974>
    c5d4:	aa1703e0 	mov	x0, x23
    c5d8:	97ffe10e 	bl	4a10 <fwp_rc_forget_slot>
    c5dc:	17fffd06 	b	b9f4 <f0+0x1a64>
    c5e0:	aa1703e0 	mov	x0, x23
    c5e4:	97ffe10b 	bl	4a10 <fwp_rc_forget_slot>
    c5e8:	17fffd28 	b	ba88 <f0+0x1af8>
    c5ec:	aa1703e0 	mov	x0, x23
    c5f0:	97ffe108 	bl	4a10 <fwp_rc_forget_slot>
    c5f4:	17fffd4b 	b	bb20 <f0+0x1b90>
    c5f8:	aa1703e0 	mov	x0, x23
    c5fc:	97ffe105 	bl	4a10 <fwp_rc_forget_slot>
    c600:	17fffd6d 	b	bbb4 <f0+0x1c24>
    c604:	aa1703e0 	mov	x0, x23
    c608:	97ffe102 	bl	4a10 <fwp_rc_forget_slot>
    c60c:	17fffd9f 	b	bc88 <f0+0x1cf8>
    c610:	aa1703e0 	mov	x0, x23
    c614:	97ffe0ff 	bl	4a10 <fwp_rc_forget_slot>
    c618:	17fffddf 	b	bd94 <f0+0x1e04>
    c61c:	aa1703e0 	mov	x0, x23
    c620:	97ffe0fc 	bl	4a10 <fwp_rc_forget_slot>
    c624:	17fffe02 	b	be2c <f0+0x1e9c>
    c628:	aa1703e0 	mov	x0, x23
    c62c:	97ffe0f9 	bl	4a10 <fwp_rc_forget_slot>
    c630:	17fffe3b 	b	bf1c <f0+0x1f8c>
    c634:	aa1703e0 	mov	x0, x23
    c638:	97ffe0f6 	bl	4a10 <fwp_rc_forget_slot>
    c63c:	17fffe66 	b	bfd4 <f0+0x2044>
    c640:	aa1703e0 	mov	x0, x23
    c644:	97ffe0f3 	bl	4a10 <fwp_rc_forget_slot>
    c648:	17fffe88 	b	c068 <f0+0x20d8>
    c64c:	aa1703e0 	mov	x0, x23
    c650:	97ffe0f0 	bl	4a10 <fwp_rc_forget_slot>
    c654:	17fffeab 	b	c100 <f0+0x2170>
    c658:	97ffd892 	bl	28a0 <__stack_chk_fail@plt>
    c65c:	d503201f 	nop

000000000000c660 <fwp_main_thread>:
    c660:	d10443ff 	sub	sp, sp, #0x110
    c664:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c668:	f947f400 	ldr	x0, [x0, #4072]
    c66c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c670:	910303fd 	add	x29, sp, #0xc0
    c674:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c678:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    c67c:	9118c2c1 	add	x1, x22, #0x630
    c680:	a90d53f3 	stp	x19, x20, [sp, #208]
    c684:	a90f63f7 	stp	x23, x24, [sp, #240]
    c688:	b953a421 	ldr	w1, [x1, #5028]
    c68c:	a9106bf9 	stp	x25, x26, [sp, #256]
    c690:	f9400002 	ldr	x2, [x0]
    c694:	f9005fe2 	str	x2, [sp, #184]
    c698:	d2800002 	mov	x2, #0x0                   	// #0
    c69c:	34002961 	cbz	w1, cbc8 <fwp_main_thread+0x568>
    c6a0:	9118c2c0 	add	x0, x22, #0x630
    c6a4:	b953a800 	ldr	w0, [x0, #5032]
    c6a8:	35002880 	cbnz	w0, cbb8 <fwp_main_thread+0x558>
    c6ac:	91001fe2 	add	x2, sp, #0x7
    c6b0:	900000b5 	adrp	x21, 20000 <__data_start>
    c6b4:	900000a3 	adrp	x3, 20000 <__data_start>
    c6b8:	910142b3 	add	x19, x21, #0x50
    c6bc:	91114063 	add	x3, x3, #0x450
    c6c0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c6c4:	d2a00025 	mov	x5, #0x10000               	// #65536
    c6c8:	910023e0 	add	x0, sp, #0x8
    c6cc:	d2800001 	mov	x1, #0x0                   	// #0
    c6d0:	f90007e3 	str	x3, [sp, #8]
    c6d4:	b90013ff 	str	wzr, [sp, #16]
    c6d8:	f9000fe5 	str	x5, [sp, #24]
    c6dc:	a90a1262 	stp	x2, x4, [x19, #160]
    c6e0:	97ffd808 	bl	2700 <sigaltstack@plt>
    c6e4:	350028a0 	cbnz	w0, cbf8 <fwp_main_thread+0x598>
    c6e8:	4f000400 	movi	v0.4s, #0x0
    c6ec:	9100a3e0 	add	x0, sp, #0x28
    c6f0:	f0ffffa1 	adrp	x1, 3000 <ad_raw_record+0x70>
    c6f4:	52800082 	mov	w2, #0x4                   	// #4
    c6f8:	9102c021 	add	x1, x1, #0xb0
    c6fc:	72a10002 	movk	w2, #0x800, lsl #16
    c700:	910083f4 	add	x20, sp, #0x20
    c704:	f90013e1 	str	x1, [sp, #32]
    c708:	3d802000 	str	q0, [x0, #128]
    c70c:	b900abe2 	str	w2, [sp, #168]
    c710:	ad000000 	stp	q0, q0, [x0]
    c714:	ad010000 	stp	q0, q0, [x0, #32]
    c718:	ad020000 	stp	q0, q0, [x0, #64]
    c71c:	ad030000 	stp	q0, q0, [x0, #96]
    c720:	97ffd850 	bl	2860 <sigemptyset@plt>
    c724:	350026a0 	cbnz	w0, cbf8 <fwp_main_thread+0x598>
    c728:	aa1403e1 	mov	x1, x20
    c72c:	d2800002 	mov	x2, #0x0                   	// #0
    c730:	52800160 	mov	w0, #0xb                   	// #11
    c734:	97ffd863 	bl	28c0 <sigaction@plt>
    c738:	35002600 	cbnz	w0, cbf8 <fwp_main_thread+0x598>
    c73c:	aa1403e1 	mov	x1, x20
    c740:	d2800002 	mov	x2, #0x0                   	// #0
    c744:	528000e0 	mov	w0, #0x7                   	// #7
    c748:	97ffd85e 	bl	28c0 <sigaction@plt>
    c74c:	35002560 	cbnz	w0, cbf8 <fwp_main_thread+0x598>
    c750:	9118c2c1 	add	x1, x22, #0x630
    c754:	52800034 	mov	w20, #0x1                   	// #1
    c758:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    c75c:	910ec000 	add	x0, x0, #0x3b0
    c760:	b9013274 	str	w20, [x19, #304]
    c764:	fd4a1020 	ldr	d0, [x1, #5152]
    c768:	7e61d800 	ucvtf	d0, d0
    c76c:	fd00a660 	str	d0, [x19, #328]
    c770:	940002e8 	bl	d310 <atexit>
    c774:	35002480 	cbnz	w0, cc04 <fwp_main_thread+0x5a4>
    c778:	b943ca60 	ldr	w0, [x19, #968]
    c77c:	340022a0 	cbz	w0, cbd0 <fwp_main_thread+0x570>
    c780:	910142ba 	add	x26, x21, #0x50
    c784:	f9404f54 	ldr	x20, [x26, #152]
    c788:	b40010b4 	cbz	x20, c99c <fwp_main_thread+0x33c>
    c78c:	aa1403f3 	mov	x19, x20
    c790:	91010297 	add	x23, x20, #0x40
    c794:	39414a99 	ldrb	w25, [x20, #82]
    c798:	52800038 	mov	w24, #0x1                   	// #1
    c79c:	39014a98 	strb	w24, [x20, #82]
    c7a0:	f9401680 	ldr	x0, [x20, #40]
    c7a4:	b4000620 	cbz	x0, c868 <fwp_main_thread+0x208>
    c7a8:	f9403281 	ldr	x1, [x20, #96]
    c7ac:	39414680 	ldrb	w0, [x20, #81]
    c7b0:	b4000b41 	cbz	x1, c918 <fwp_main_thread+0x2b8>
    c7b4:	36000a80 	tbz	w0, #0, c904 <fwp_main_thread+0x2a4>
    c7b8:	39414a62 	ldrb	w2, [x19, #82]
    c7bc:	f9402280 	ldr	x0, [x20, #64]
    c7c0:	37000d62 	tbnz	w2, #0, c96c <fwp_main_thread+0x30c>
    c7c4:	f9403261 	ldr	x1, [x19, #96]
    c7c8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c7cc:	f9009660 	str	x0, [x19, #296]
    c7d0:	b4000040 	cbz	x0, c7d8 <fwp_main_thread+0x178>
    c7d4:	f9009013 	str	x19, [x0, #288]
    c7d8:	f9002293 	str	x19, [x20, #64]
    c7dc:	b4000101 	cbz	x1, c7fc <fwp_main_thread+0x19c>
    c7e0:	f9409740 	ldr	x0, [x26, #296]
    c7e4:	39015678 	strb	w24, [x19, #85]
    c7e8:	f9003661 	str	x1, [x19, #104]
    c7ec:	a910827f 	stp	xzr, x0, [x19, #264]
    c7f0:	b4000040 	cbz	x0, c7f8 <fwp_main_thread+0x198>
    c7f4:	f9008413 	str	x19, [x0, #264]
    c7f8:	f9009753 	str	x19, [x26, #296]
    c7fc:	39015a7f 	strb	wzr, [x19, #86]
    c800:	97ffe875 	bl	69d4 <fwp_block>
    c804:	f9408e62 	ldr	x2, [x19, #280]
    c808:	b4000142 	cbz	x2, c830 <fwp_main_thread+0x1d0>
    c80c:	a9520261 	ldp	x1, x0, [x19, #288]
    c810:	b4000ba1 	cbz	x1, c984 <fwp_main_thread+0x324>
    c814:	f9009420 	str	x0, [x1, #296]
    c818:	f9409660 	ldr	x0, [x19, #296]
    c81c:	b4000040 	cbz	x0, c824 <fwp_main_thread+0x1c4>
    c820:	f9009001 	str	x1, [x0, #288]
    c824:	91080260 	add	x0, x19, #0x200
    c828:	f900967f 	str	xzr, [x19, #296]
    c82c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c830:	39415660 	ldrb	w0, [x19, #85]
    c834:	f9404f42 	ldr	x2, [x26, #152]
    c838:	36000960 	tbz	w0, #0, c964 <fwp_main_thread+0x304>
    c83c:	a9508261 	ldp	x1, x0, [x19, #264]
    c840:	b4000a61 	cbz	x1, c98c <fwp_main_thread+0x32c>
    c844:	f9008820 	str	x0, [x1, #272]
    c848:	b4000040 	cbz	x0, c850 <fwp_main_thread+0x1f0>
    c84c:	f9008401 	str	x1, [x0, #264]
    c850:	91080260 	add	x0, x19, #0x200
    c854:	3901567f 	strb	wzr, [x19, #85]
    c858:	aa0203f3 	mov	x19, x2
    c85c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c860:	f9401680 	ldr	x0, [x20, #40]
    c864:	b5fffa20 	cbnz	x0, c7a8 <fwp_main_thread+0x148>
    c868:	910142a0 	add	x0, x21, #0x50
    c86c:	39014a99 	strb	w25, [x20, #82]
    c870:	f941d400 	ldr	x0, [x0, #936]
    c874:	b4001840 	cbz	x0, cb7c <fwp_main_thread+0x51c>
    c878:	910142a0 	add	x0, x21, #0x50
    c87c:	f941f001 	ldr	x1, [x0, #992]
    c880:	b903d81f 	str	wzr, [x0, #984]
    c884:	eb13003f 	cmp	x1, x19
    c888:	54001961 	b.ne	cbb4 <fwp_main_thread+0x554>  // b.any
    c88c:	b4000933 	cbz	x19, c9b0 <fwp_main_thread+0x350>
    c890:	910142a0 	add	x0, x21, #0x50
    c894:	52800021 	mov	w1, #0x1                   	// #1
    c898:	39014a61 	strb	w1, [x19, #82]
    c89c:	f941c005 	ldr	x5, [x0, #896]
    c8a0:	b4000885 	cbz	x5, c9b0 <fwp_main_thread+0x350>
    c8a4:	d503201f 	nop
    c8a8:	394140a0 	ldrb	w0, [x5, #80]
    c8ac:	37000060 	tbnz	w0, #0, c8b8 <fwp_main_thread+0x258>
    c8b0:	aa0503e0 	mov	x0, x5
    c8b4:	97ffdb8f 	bl	36f0 <fwp_cancel_tree.part.0>
    c8b8:	f9409ca5 	ldr	x5, [x5, #312]
    c8bc:	b5ffff65 	cbnz	x5, c8a8 <fwp_main_thread+0x248>
    c8c0:	910142b4 	add	x20, x21, #0x50
    c8c4:	52800037 	mov	w23, #0x1                   	// #1
    c8c8:	f9402a60 	ldr	x0, [x19, #80]
    c8cc:	f2001c1f 	tst	x0, #0xff000000ff
    c8d0:	540000e1 	b.ne	c8ec <fwp_main_thread+0x28c>  // b.any
    c8d4:	f9406280 	ldr	x0, [x20, #192]
    c8d8:	39015277 	strb	w23, [x19, #84]
    c8dc:	f900827f 	str	xzr, [x19, #256]
    c8e0:	b40005a0 	cbz	x0, c994 <fwp_main_thread+0x334>
    c8e4:	f9008013 	str	x19, [x0, #256]
    c8e8:	f9006293 	str	x19, [x20, #192]
    c8ec:	97ffe83a 	bl	69d4 <fwp_block>
    c8f0:	97ffe7cc 	bl	6820 <fwp_free_zombie>
    c8f4:	f941c280 	ldr	x0, [x20, #896]
    c8f8:	b40005c0 	cbz	x0, c9b0 <fwp_main_thread+0x350>
    c8fc:	f941f293 	ldr	x19, [x20, #992]
    c900:	17fffff2 	b	c8c8 <fwp_main_thread+0x268>
    c904:	97ffdc1f 	bl	3980 <fwp_now_ns>
    c908:	f9403281 	ldr	x1, [x20, #96]
    c90c:	eb01001f 	cmp	x0, x1
    c910:	5400128a 	b.ge	cb60 <fwp_main_thread+0x500>  // b.tcont
    c914:	39414680 	ldrb	w0, [x20, #81]
    c918:	39414a62 	ldrb	w2, [x19, #82]
    c91c:	3707f500 	tbnz	w0, #0, c7bc <fwp_main_thread+0x15c>
    c920:	f9403281 	ldr	x1, [x20, #96]
    c924:	370001c2 	tbnz	w2, #0, c95c <fwp_main_thread+0x2fc>
    c928:	f9403260 	ldr	x0, [x19, #96]
    c92c:	b4000180 	cbz	x0, c95c <fwp_main_thread+0x2fc>
    c930:	b4000061 	cbz	x1, c93c <fwp_main_thread+0x2dc>
    c934:	eb01001f 	cmp	x0, x1
    c938:	9a81d000 	csel	x0, x0, x1, le
    c93c:	f9402281 	ldr	x1, [x20, #64]
    c940:	a911fe77 	stp	x23, xzr, [x19, #280]
    c944:	f9009661 	str	x1, [x19, #296]
    c948:	b40014c1 	cbz	x1, cbe0 <fwp_main_thread+0x580>
    c94c:	f9009033 	str	x19, [x1, #288]
    c950:	aa0003e1 	mov	x1, x0
    c954:	f9002293 	str	x19, [x20, #64]
    c958:	17ffffa2 	b	c7e0 <fwp_main_thread+0x180>
    c95c:	f9402280 	ldr	x0, [x20, #64]
    c960:	17ffff9a 	b	c7c8 <fwp_main_thread+0x168>
    c964:	aa0203f3 	mov	x19, x2
    c968:	17ffff8e 	b	c7a0 <fwp_main_thread+0x140>
    c96c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c970:	f9009660 	str	x0, [x19, #296]
    c974:	b4000040 	cbz	x0, c97c <fwp_main_thread+0x31c>
    c978:	f9009013 	str	x19, [x0, #288]
    c97c:	f9002293 	str	x19, [x20, #64]
    c980:	17ffff9f 	b	c7fc <fwp_main_thread+0x19c>
    c984:	f9000040 	str	x0, [x2]
    c988:	17ffffa5 	b	c81c <fwp_main_thread+0x1bc>
    c98c:	f9009740 	str	x0, [x26, #296]
    c990:	17ffffae 	b	c848 <fwp_main_thread+0x1e8>
    c994:	f9006693 	str	x19, [x20, #200]
    c998:	17ffffd4 	b	c8e8 <fwp_main_thread+0x288>
    c99c:	f941d740 	ldr	x0, [x26, #936]
    c9a0:	b4000ec0 	cbz	x0, cb78 <fwp_main_thread+0x518>
    c9a4:	f941f340 	ldr	x0, [x26, #992]
    c9a8:	b903db5f 	str	wzr, [x26, #984]
    c9ac:	b5001040 	cbnz	x0, cbb4 <fwp_main_thread+0x554>
    c9b0:	910142b4 	add	x20, x21, #0x50
    c9b4:	97ffe79b 	bl	6820 <fwp_free_zombie>
    c9b8:	f9406680 	ldr	x0, [x20, #200]
    c9bc:	b5000fc0 	cbnz	x0, cbb4 <fwp_main_thread+0x554>
    c9c0:	f9409680 	ldr	x0, [x20, #296]
    c9c4:	b5000f80 	cbnz	x0, cbb4 <fwp_main_thread+0x554>
    c9c8:	b9417293 	ldr	w19, [x20, #368]
    c9cc:	340001d3 	cbz	w19, ca04 <fwp_main_thread+0x3a4>
    c9d0:	93407e77 	sxtw	x23, w19
    c9d4:	51000673 	sub	w19, w19, #0x1
    c9d8:	d1000af7 	sub	x23, x23, #0x2
    c9dc:	91060298 	add	x24, x20, #0x180
    c9e0:	cb3342f7 	sub	x23, x23, w19, uxtw
    c9e4:	93407e73 	sxtw	x19, w19
    c9e8:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    c9ec:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c9f0:	b9017293 	str	w19, [x20, #368]
    c9f4:	d1000673 	sub	x19, x19, #0x1
    c9f8:	97ffd7f2 	bl	29c0 <munmap@plt>
    c9fc:	eb1302ff 	cmp	x23, x19
    ca00:	54ffff41 	b.ne	c9e8 <fwp_main_thread+0x388>  // b.any
    ca04:	900000b3 	adrp	x19, 20000 <__data_start>
    ca08:	91004260 	add	x0, x19, #0x10
    ca0c:	b9402800 	ldr	w0, [x0, #40]
    ca10:	37f80040 	tbnz	w0, #31, ca18 <fwp_main_thread+0x3b8>
    ca14:	97ffd7a7 	bl	28b0 <close@plt>
    ca18:	910142a0 	add	x0, x21, #0x50
    ca1c:	91004261 	add	x1, x19, #0x10
    ca20:	12800002 	mov	w2, #0xffffffff            	// #-1
    ca24:	d2800013 	mov	x19, #0x0                   	// #0
    ca28:	f941f417 	ldr	x23, [x0, #1000]
    ca2c:	b9002822 	str	w2, [x1, #40]
    ca30:	f941f814 	ldr	x20, [x0, #1008]
    ca34:	b4000177 	cbz	x23, ca60 <fwp_main_thread+0x400>
    ca38:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    ca3c:	b40000c0 	cbz	x0, ca54 <fwp_main_thread+0x3f4>
    ca40:	f9400001 	ldr	x1, [x0]
    ca44:	b5000b81 	cbnz	x1, cbb4 <fwp_main_thread+0x554>
    ca48:	f9400401 	ldr	x1, [x0, #8]
    ca4c:	b5000b41 	cbnz	x1, cbb4 <fwp_main_thread+0x554>
    ca50:	97ffe090 	bl	4c90 <fwp_mem_free>
    ca54:	91000673 	add	x19, x19, #0x1
    ca58:	eb1302ff 	cmp	x23, x19
    ca5c:	54fffee1 	b.ne	ca38 <fwp_main_thread+0x3d8>  // b.any
    ca60:	aa1403e0 	mov	x0, x20
    ca64:	97ffe08b 	bl	4c90 <fwp_mem_free>
    ca68:	910142a0 	add	x0, x21, #0x50
    ca6c:	f941f013 	ldr	x19, [x0, #992]
    ca70:	f901f41f 	str	xzr, [x0, #1000]
    ca74:	f901f81f 	str	xzr, [x0, #1008]
    ca78:	b40001f3 	cbz	x19, cab4 <fwp_main_thread+0x454>
    ca7c:	f9401661 	ldr	x1, [x19, #40]
    ca80:	b50009a1 	cbnz	x1, cbb4 <fwp_main_thread+0x554>
    ca84:	f9405661 	ldr	x1, [x19, #168]
    ca88:	b5000961 	cbnz	x1, cbb4 <fwp_main_thread+0x554>
    ca8c:	f941d401 	ldr	x1, [x0, #936]
    ca90:	b5000921 	cbnz	x1, cbb4 <fwp_main_thread+0x554>
    ca94:	f941dc00 	ldr	x0, [x0, #952]
    ca98:	b50008e0 	cbnz	x0, cbb4 <fwp_main_thread+0x554>
    ca9c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    caa0:	90000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    caa4:	91114000 	add	x0, x0, #0x450
    caa8:	97ffd772 	bl	2870 <memset@plt>
    caac:	aa1303e0 	mov	x0, x19
    cab0:	97ffe078 	bl	4c90 <fwp_mem_free>
    cab4:	910142a6 	add	x6, x21, #0x50
    cab8:	9118c2d6 	add	x22, x22, #0x630
    cabc:	3dc016a1 	ldr	q1, [x21, #80]
    cac0:	52800041 	mov	w1, #0x2                   	// #2
    cac4:	3dc004c2 	ldr	q2, [x6, #16]
    cac8:	b0000002 	adrp	x2, d000 <__modti3+0x60>
    cacc:	fd4a12c0 	ldr	d0, [x22, #5152]
    cad0:	912de042 	add	x2, x2, #0xb78
    cad4:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    cad8:	fd40a4c1 	ldr	d1, [x6, #328]
    cadc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cae0:	f947e800 	ldr	x0, [x0, #4048]
    cae4:	7e61d800 	ucvtf	d0, d0
    cae8:	a95390c3 	ldp	x3, x4, [x6, #312]
    caec:	f9004cdf 	str	xzr, [x6, #152]
    caf0:	f9400000 	ldr	x0, [x0]
    caf4:	1e613801 	fsub	d1, d0, d1
    caf8:	f940acc5 	ldr	x5, [x6, #344]
    cafc:	b90130df 	str	wzr, [x6, #304]
    cb00:	5ef1b842 	addp	d2, v2.2d
    cb04:	fd40a8c0 	ldr	d0, [x6, #336]
    cb08:	f901f0df 	str	xzr, [x6, #992]
    cb0c:	fd0058c2 	str	d2, [x6, #176]
    cb10:	97ffd780 	bl	2910 <__fprintf_chk@plt>
    cb14:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cb18:	f947ec00 	ldr	x0, [x0, #4056]
    cb1c:	f9400000 	ldr	x0, [x0]
    cb20:	97ffd7ac 	bl	29d0 <fflush@plt>
    cb24:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cb28:	f947f400 	ldr	x0, [x0, #4072]
    cb2c:	f9405fe2 	ldr	x2, [sp, #184]
    cb30:	f9400001 	ldr	x1, [x0]
    cb34:	eb010042 	subs	x2, x2, x1
    cb38:	d2800001 	mov	x1, #0x0                   	// #0
    cb3c:	540006a1 	b.ne	cc10 <fwp_main_thread+0x5b0>  // b.any
    cb40:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cb44:	d2800000 	mov	x0, #0x0                   	// #0
    cb48:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cb4c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cb50:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cb54:	a9506bf9 	ldp	x25, x26, [sp, #256]
    cb58:	910443ff 	add	sp, sp, #0x110
    cb5c:	d65f03c0 	ret
    cb60:	39414280 	ldrb	w0, [x20, #80]
    cb64:	3707ed80 	tbnz	w0, #0, c914 <fwp_main_thread+0x2b4>
    cb68:	aa1403e0 	mov	x0, x20
    cb6c:	97ffdae1 	bl	36f0 <fwp_cancel_tree.part.0>
    cb70:	39414680 	ldrb	w0, [x20, #81]
    cb74:	17ffff69 	b	c918 <fwp_main_thread+0x2b8>
    cb78:	d2800013 	mov	x19, #0x0                   	// #0
    cb7c:	910142b4 	add	x20, x21, #0x50
    cb80:	f941de80 	ldr	x0, [x20, #952]
    cb84:	b5ffe7a0 	cbnz	x0, c878 <fwp_main_thread+0x218>
    cb88:	f941d280 	ldr	x0, [x20, #928]
    cb8c:	97ffe041 	bl	4c90 <fwp_mem_free>
    cb90:	f901d29f 	str	xzr, [x20, #928]
    cb94:	f901da9f 	str	xzr, [x20, #944]
    cb98:	f941f280 	ldr	x0, [x20, #992]
    cb9c:	b4000293 	cbz	x19, cbec <fwp_main_thread+0x58c>
    cba0:	f900567f 	str	xzr, [x19, #168]
    cba4:	f9005e7f 	str	xzr, [x19, #184]
    cba8:	b903da9f 	str	wzr, [x20, #984]
    cbac:	eb13001f 	cmp	x0, x19
    cbb0:	54ffe700 	b.eq	c890 <fwp_main_thread+0x230>  // b.none
    cbb4:	97ffd74f 	bl	28f0 <abort@plt>
    cbb8:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    cbbc:	913e8000 	add	x0, x0, #0xfa0
    cbc0:	940001d4 	bl	d310 <atexit>
    cbc4:	17fffeba 	b	c6ac <fwp_main_thread+0x4c>
    cbc8:	97ffdd4f 	bl	4104 <fwp_heap_init>
    cbcc:	17fffeb5 	b	c6a0 <fwp_main_thread+0x40>
    cbd0:	97fff4f0 	bl	9f90 <f0>
    cbd4:	b903ca74 	str	w20, [x19, #968]
    cbd8:	f901ea60 	str	x0, [x19, #976]
    cbdc:	17fffee9 	b	c780 <fwp_main_thread+0x120>
    cbe0:	aa0003e1 	mov	x1, x0
    cbe4:	f9002293 	str	x19, [x20, #64]
    cbe8:	17fffefe 	b	c7e0 <fwp_main_thread+0x180>
    cbec:	b903da9f 	str	wzr, [x20, #984]
    cbf0:	b4ffee00 	cbz	x0, c9b0 <fwp_main_thread+0x350>
    cbf4:	97ffd73f 	bl	28f0 <abort@plt>
    cbf8:	b0000000 	adrp	x0, d000 <__modti3+0x60>
    cbfc:	912cc000 	add	x0, x0, #0xb30
    cc00:	97ffdb00 	bl	3800 <fwp_trap>
    cc04:	b0000000 	adrp	x0, d000 <__modti3+0x60>
    cc08:	912d6000 	add	x0, x0, #0xb58
    cc0c:	97ffd9dd 	bl	3380 <ad_raw_fail>
    cc10:	97ffd724 	bl	28a0 <__stack_chk_fail@plt>
    cc14:	d503201f 	nop
    cc18:	d503201f 	nop
    cc1c:	d503201f 	nop

000000000000cc20 <__divti3>:
    cc20:	d503245f 	bti	c
    cc24:	d2800004 	mov	x4, #0x0                   	// #0
    cc28:	b7f80721 	tbnz	x1, #63, cd0c <__divti3+0xec>
    cc2c:	b6f80083 	tbz	x3, #63, cc3c <__divti3+0x1c>
    cc30:	eb0203e2 	negs	x2, x2
    cc34:	aa2403e4 	mvn	x4, x4
    cc38:	da0303e3 	ngc	x3, x3
    cc3c:	aa0203e6 	mov	x6, x2
    cc40:	aa0003e7 	mov	x7, x0
    cc44:	aa0103e5 	mov	x5, x1
    cc48:	b5000583 	cbnz	x3, ccf8 <__divti3+0xd8>
    cc4c:	eb01005f 	cmp	x2, x1
    cc50:	54000e69 	b.ls	ce1c <__divti3+0x1fc>  // b.plast
    cc54:	dac01040 	clz	x0, x2
    cc58:	b40000e0 	cbz	x0, cc74 <__divti3+0x54>
    cc5c:	4b0003e1 	neg	w1, w0
    cc60:	9ac020a5 	lsl	x5, x5, x0
    cc64:	9ac02046 	lsl	x6, x2, x0
    cc68:	9ac124e1 	lsr	x1, x7, x1
    cc6c:	aa050025 	orr	x5, x1, x5
    cc70:	9ac020e7 	lsl	x7, x7, x0
    cc74:	d360fcc8 	lsr	x8, x6, #32
    cc78:	92407cc2 	and	x2, x6, #0xffffffff
    cc7c:	9ac808a3 	udiv	x3, x5, x8
    cc80:	9b089465 	msub	x5, x3, x8, x5
    cc84:	aa0303e0 	mov	x0, x3
    cc88:	9b037c41 	mul	x1, x2, x3
    cc8c:	93c780a5 	extr	x5, x5, x7, #32
    cc90:	eb05003f 	cmp	x1, x5
    cc94:	540000a9 	b.ls	cca8 <__divti3+0x88>  // b.plast
    cc98:	ab0500c5 	adds	x5, x6, x5
    cc9c:	d1000460 	sub	x0, x3, #0x1
    cca0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cca4:	540015a8 	b.hi	cf58 <__divti3+0x338>  // b.pmore
    cca8:	cb0100a5 	sub	x5, x5, x1
    ccac:	9ac808a3 	udiv	x3, x5, x8
    ccb0:	9b089465 	msub	x5, x3, x8, x5
    ccb4:	aa0303e1 	mov	x1, x3
    ccb8:	9b037c42 	mul	x2, x2, x3
    ccbc:	aa0703e3 	mov	x3, x7
    ccc0:	b3607ca3 	bfi	x3, x5, #32, #32
    ccc4:	eb03005f 	cmp	x2, x3
    ccc8:	540000c9 	b.ls	cce0 <__divti3+0xc0>  // b.plast
    cccc:	ab0300c3 	adds	x3, x6, x3
    ccd0:	d1000425 	sub	x5, x1, #0x1
    ccd4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ccd8:	d1000821 	sub	x1, x1, #0x2
    ccdc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cce0:	aa008020 	orr	x0, x1, x0, lsl #32
    cce4:	d2800001 	mov	x1, #0x0                   	// #0
    cce8:	b4000064 	cbz	x4, ccf4 <__divti3+0xd4>
    ccec:	eb0003e0 	negs	x0, x0
    ccf0:	da0103e1 	ngc	x1, x1
    ccf4:	d65f03c0 	ret
    ccf8:	eb01007f 	cmp	x3, x1
    ccfc:	54000109 	b.ls	cd1c <__divti3+0xfc>  // b.plast
    cd00:	d2800001 	mov	x1, #0x0                   	// #0
    cd04:	d2800000 	mov	x0, #0x0                   	// #0
    cd08:	17fffff8 	b	cce8 <__divti3+0xc8>
    cd0c:	eb0003e0 	negs	x0, x0
    cd10:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cd14:	da0103e1 	ngc	x1, x1
    cd18:	17ffffc5 	b	cc2c <__divti3+0xc>
    cd1c:	dac01067 	clz	x7, x3
    cd20:	b40010e7 	cbz	x7, cf3c <__divti3+0x31c>
    cd24:	d2800805 	mov	x5, #0x40                  	// #64
    cd28:	cb0700a5 	sub	x5, x5, x7
    cd2c:	9ac72063 	lsl	x3, x3, x7
    cd30:	9ac52448 	lsr	x8, x2, x5
    cd34:	aa030108 	orr	x8, x8, x3
    cd38:	9ac52426 	lsr	x6, x1, x5
    cd3c:	92407d0a 	and	x10, x8, #0xffffffff
    cd40:	d360fd09 	lsr	x9, x8, #32
    cd44:	9ac52403 	lsr	x3, x0, x5
    cd48:	9ac72021 	lsl	x1, x1, x7
    cd4c:	aa010063 	orr	x3, x3, x1
    cd50:	9ac72042 	lsl	x2, x2, x7
    cd54:	9ac908cb 	udiv	x11, x6, x9
    cd58:	9b099965 	msub	x5, x11, x9, x6
    cd5c:	aa0b03e1 	mov	x1, x11
    cd60:	9b0b7d46 	mul	x6, x10, x11
    cd64:	93c380a5 	extr	x5, x5, x3, #32
    cd68:	eb0500df 	cmp	x6, x5
    cd6c:	540000a9 	b.ls	cd80 <__divti3+0x160>  // b.plast
    cd70:	ab050105 	adds	x5, x8, x5
    cd74:	d1000561 	sub	x1, x11, #0x1
    cd78:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cd7c:	54000f48 	b.hi	cf64 <__divti3+0x344>  // b.pmore
    cd80:	cb0600a6 	sub	x6, x5, x6
    cd84:	9ac908cb 	udiv	x11, x6, x9
    cd88:	9b099969 	msub	x9, x11, x9, x6
    cd8c:	aa0b03e5 	mov	x5, x11
    cd90:	9b0b7d4a 	mul	x10, x10, x11
    cd94:	b3607d23 	bfi	x3, x9, #32, #32
    cd98:	eb03015f 	cmp	x10, x3
    cd9c:	540000a9 	b.ls	cdb0 <__divti3+0x190>  // b.plast
    cda0:	ab030103 	adds	x3, x8, x3
    cda4:	d1000565 	sub	x5, x11, #0x1
    cda8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cdac:	54000e28 	b.hi	cf70 <__divti3+0x350>  // b.pmore
    cdb0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cdb4:	92407c48 	and	x8, x2, #0xffffffff
    cdb8:	2a0503e5 	mov	w5, w5
    cdbc:	d360fc42 	lsr	x2, x2, #32
    cdc0:	d360fc26 	lsr	x6, x1, #32
    cdc4:	cb0a0063 	sub	x3, x3, x10
    cdc8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cdcc:	9b087caa 	mul	x10, x5, x8
    cdd0:	9b087cc8 	mul	x8, x6, x8
    cdd4:	9b0220a5 	madd	x5, x5, x2, x8
    cdd8:	9b027cc6 	mul	x6, x6, x2
    cddc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cde0:	8b0900c5 	add	x5, x6, x9
    cde4:	eb02011f 	cmp	x8, x2
    cde8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cdec:	8b4280c6 	add	x6, x6, x2, lsr #32
    cdf0:	eb06007f 	cmp	x3, x6
    cdf4:	540000e3 	b.cc	ce10 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cdf8:	92407d4a 	and	x10, x10, #0xffffffff
    cdfc:	9ac72000 	lsl	x0, x0, x7
    ce00:	8b028142 	add	x2, x10, x2, lsl #32
    ce04:	eb02001f 	cmp	x0, x2
    ce08:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    ce0c:	54000a01 	b.ne	cf4c <__divti3+0x32c>  // b.any
    ce10:	d1000420 	sub	x0, x1, #0x1
    ce14:	d2800001 	mov	x1, #0x0                   	// #0
    ce18:	17ffffb4 	b	cce8 <__divti3+0xc8>
    ce1c:	b5000062 	cbnz	x2, ce28 <__divti3+0x208>
    ce20:	d2800022 	mov	x2, #0x1                   	// #1
    ce24:	9ac30846 	udiv	x6, x2, x3
    ce28:	dac010c8 	clz	x8, x6
    ce2c:	b5000408 	cbnz	x8, ceac <__divti3+0x28c>
    ce30:	d360fcc9 	lsr	x9, x6, #32
    ce34:	92407cc5 	and	x5, x6, #0xffffffff
    ce38:	cb060023 	sub	x3, x1, x6
    ce3c:	d2800021 	mov	x1, #0x1                   	// #1
    ce40:	9ac90868 	udiv	x8, x3, x9
    ce44:	9b098d03 	msub	x3, x8, x9, x3
    ce48:	aa0803e0 	mov	x0, x8
    ce4c:	9b057d02 	mul	x2, x8, x5
    ce50:	93c78063 	extr	x3, x3, x7, #32
    ce54:	eb03005f 	cmp	x2, x3
    ce58:	540000a9 	b.ls	ce6c <__divti3+0x24c>  // b.plast
    ce5c:	ab0300c3 	adds	x3, x6, x3
    ce60:	d1000500 	sub	x0, x8, #0x1
    ce64:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ce68:	54000968 	b.hi	cf94 <__divti3+0x374>  // b.pmore
    ce6c:	cb020063 	sub	x3, x3, x2
    ce70:	9ac90862 	udiv	x2, x3, x9
    ce74:	aa0203e8 	mov	x8, x2
    ce78:	9b098c42 	msub	x2, x2, x9, x3
    ce7c:	aa0703e3 	mov	x3, x7
    ce80:	9b057d05 	mul	x5, x8, x5
    ce84:	b3607c43 	bfi	x3, x2, #32, #32
    ce88:	eb0300bf 	cmp	x5, x3
    ce8c:	540000c9 	b.ls	cea4 <__divti3+0x284>  // b.plast
    ce90:	ab0300c2 	adds	x2, x6, x3
    ce94:	d1000503 	sub	x3, x8, #0x1
    ce98:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ce9c:	d1000908 	sub	x8, x8, #0x2
    cea0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cea4:	aa008100 	orr	x0, x8, x0, lsl #32
    cea8:	17ffff90 	b	cce8 <__divti3+0xc8>
    ceac:	9ac820c6 	lsl	x6, x6, x8
    ceb0:	d2800803 	mov	x3, #0x40                  	// #64
    ceb4:	cb080063 	sub	x3, x3, x8
    ceb8:	d360fcc9 	lsr	x9, x6, #32
    cebc:	9ac82027 	lsl	x7, x1, x8
    cec0:	92407cc5 	and	x5, x6, #0xffffffff
    cec4:	9ac32422 	lsr	x2, x1, x3
    cec8:	9ac32403 	lsr	x3, x0, x3
    cecc:	aa070063 	orr	x3, x3, x7
    ced0:	9ac9084a 	udiv	x10, x2, x9
    ced4:	9ac82007 	lsl	x7, x0, x8
    ced8:	9b098940 	msub	x0, x10, x9, x2
    cedc:	aa0a03e1 	mov	x1, x10
    cee0:	9b0a7ca2 	mul	x2, x5, x10
    cee4:	93c38000 	extr	x0, x0, x3, #32
    cee8:	eb00005f 	cmp	x2, x0
    ceec:	540000a9 	b.ls	cf00 <__divti3+0x2e0>  // b.plast
    cef0:	ab0000c0 	adds	x0, x6, x0
    cef4:	d1000541 	sub	x1, x10, #0x1
    cef8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cefc:	54000468 	b.hi	cf88 <__divti3+0x368>  // b.pmore
    cf00:	cb020000 	sub	x0, x0, x2
    cf04:	9ac9080a 	udiv	x10, x0, x9
    cf08:	9b098140 	msub	x0, x10, x9, x0
    cf0c:	aa0a03e2 	mov	x2, x10
    cf10:	9b0a7ca8 	mul	x8, x5, x10
    cf14:	b3607c03 	bfi	x3, x0, #32, #32
    cf18:	eb03011f 	cmp	x8, x3
    cf1c:	540000a9 	b.ls	cf30 <__divti3+0x310>  // b.plast
    cf20:	ab0300c3 	adds	x3, x6, x3
    cf24:	d1000542 	sub	x2, x10, #0x1
    cf28:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cf2c:	54000288 	b.hi	cf7c <__divti3+0x35c>  // b.pmore
    cf30:	cb080063 	sub	x3, x3, x8
    cf34:	aa018041 	orr	x1, x2, x1, lsl #32
    cf38:	17ffffc2 	b	ce40 <__divti3+0x220>
    cf3c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cf40:	d2800001 	mov	x1, #0x0                   	// #0
    cf44:	9a9f87e0 	cset	x0, ls	// ls = plast
    cf48:	17ffff68 	b	cce8 <__divti3+0xc8>
    cf4c:	aa0103e0 	mov	x0, x1
    cf50:	d2800001 	mov	x1, #0x0                   	// #0
    cf54:	17ffff65 	b	cce8 <__divti3+0xc8>
    cf58:	d1000860 	sub	x0, x3, #0x2
    cf5c:	8b0600a5 	add	x5, x5, x6
    cf60:	17ffff52 	b	cca8 <__divti3+0x88>
    cf64:	d1000961 	sub	x1, x11, #0x2
    cf68:	8b0800a5 	add	x5, x5, x8
    cf6c:	17ffff85 	b	cd80 <__divti3+0x160>
    cf70:	d1000965 	sub	x5, x11, #0x2
    cf74:	8b080063 	add	x3, x3, x8
    cf78:	17ffff8e 	b	cdb0 <__divti3+0x190>
    cf7c:	d1000942 	sub	x2, x10, #0x2
    cf80:	8b060063 	add	x3, x3, x6
    cf84:	17ffffeb 	b	cf30 <__divti3+0x310>
    cf88:	d1000941 	sub	x1, x10, #0x2
    cf8c:	8b060000 	add	x0, x0, x6
    cf90:	17ffffdc 	b	cf00 <__divti3+0x2e0>
    cf94:	d1000900 	sub	x0, x8, #0x2
    cf98:	8b060063 	add	x3, x3, x6
    cf9c:	17ffffb4 	b	ce6c <__divti3+0x24c>

000000000000cfa0 <__modti3>:
    cfa0:	d503245f 	bti	c
    cfa4:	d2800004 	mov	x4, #0x0                   	// #0
    cfa8:	b6f80081 	tbz	x1, #63, cfb8 <__modti3+0x18>
    cfac:	eb0003e0 	negs	x0, x0
    cfb0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cfb4:	da0103e1 	ngc	x1, x1
    cfb8:	f100007f 	cmp	x3, #0x0
    cfbc:	5400128b 	b.lt	d20c <__modti3+0x26c>  // b.tstop
    cfc0:	aa0003e7 	mov	x7, x0
    cfc4:	aa0103e6 	mov	x6, x1
    cfc8:	540004e1 	b.ne	d064 <__modti3+0xc4>  // b.any
    cfcc:	eb02003f 	cmp	x1, x2
    cfd0:	54000dc2 	b.cs	d188 <__modti3+0x1e8>  // b.hs, b.nlast
    cfd4:	dac01043 	clz	x3, x2
    cfd8:	aa0303e5 	mov	x5, x3
    cfdc:	b40000e3 	cbz	x3, cff8 <__modti3+0x58>
    cfe0:	4b0303e6 	neg	w6, w3
    cfe4:	9ac32021 	lsl	x1, x1, x3
    cfe8:	9ac32042 	lsl	x2, x2, x3
    cfec:	9ac62406 	lsr	x6, x0, x6
    cff0:	aa0100c6 	orr	x6, x6, x1
    cff4:	9ac32007 	lsl	x7, x0, x3
    cff8:	d360fc40 	lsr	x0, x2, #32
    cffc:	92407c43 	and	x3, x2, #0xffffffff
    d000:	9ac008c1 	udiv	x1, x6, x0
    d004:	9b009826 	msub	x6, x1, x0, x6
    d008:	9b017c61 	mul	x1, x3, x1
    d00c:	93c780c6 	extr	x6, x6, x7, #32
    d010:	eb06003f 	cmp	x1, x6
    d014:	540000a9 	b.ls	d028 <__modti3+0x88>  // b.plast
    d018:	ab060046 	adds	x6, x2, x6
    d01c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d020:	8b0200c8 	add	x8, x6, x2
    d024:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d028:	cb0100c6 	sub	x6, x6, x1
    d02c:	9ac008c8 	udiv	x8, x6, x0
    d030:	9b009901 	msub	x1, x8, x0, x6
    d034:	aa0703e0 	mov	x0, x7
    d038:	9b087c63 	mul	x3, x3, x8
    d03c:	b3607c20 	bfi	x0, x1, #32, #32
    d040:	eb00007f 	cmp	x3, x0
    d044:	54001088 	b.hi	d254 <__modti3+0x2b4>  // b.pmore
    d048:	cb030000 	sub	x0, x0, x3
    d04c:	9ac52400 	lsr	x0, x0, x5
    d050:	d2800001 	mov	x1, #0x0                   	// #0
    d054:	b4000064 	cbz	x4, d060 <__modti3+0xc0>
    d058:	eb0003e0 	negs	x0, x0
    d05c:	da0103e1 	ngc	x1, x1
    d060:	d65f03c0 	ret
    d064:	dac01066 	clz	x6, x3
    d068:	eb03003f 	cmp	x1, x3
    d06c:	54ffff43 	b.cc	d054 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d070:	93407cc5 	sxtw	x5, w6
    d074:	d2800808 	mov	x8, #0x40                  	// #64
    d078:	cb050108 	sub	x8, x8, x5
    d07c:	9ac62063 	lsl	x3, x3, x6
    d080:	9ac62025 	lsl	x5, x1, x6
    d084:	9ac82447 	lsr	x7, x2, x8
    d088:	aa0300e7 	orr	x7, x7, x3
    d08c:	9ac82423 	lsr	x3, x1, x8
    d090:	92407cec 	and	x12, x7, #0xffffffff
    d094:	d360fcea 	lsr	x10, x7, #32
    d098:	9ac82401 	lsr	x1, x0, x8
    d09c:	aa050021 	orr	x1, x1, x5
    d0a0:	9ac62042 	lsl	x2, x2, x6
    d0a4:	9ac62000 	lsl	x0, x0, x6
    d0a8:	9aca086b 	udiv	x11, x3, x10
    d0ac:	9b0a8d63 	msub	x3, x11, x10, x3
    d0b0:	aa0b03e5 	mov	x5, x11
    d0b4:	9b0b7d89 	mul	x9, x12, x11
    d0b8:	93c18063 	extr	x3, x3, x1, #32
    d0bc:	eb03013f 	cmp	x9, x3
    d0c0:	540000a9 	b.ls	d0d4 <__modti3+0x134>  // b.plast
    d0c4:	ab0300e3 	adds	x3, x7, x3
    d0c8:	d1000565 	sub	x5, x11, #0x1
    d0cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d0d0:	54001168 	b.hi	d2fc <__modti3+0x35c>  // b.pmore
    d0d4:	cb090063 	sub	x3, x3, x9
    d0d8:	9aca086b 	udiv	x11, x3, x10
    d0dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    d0e0:	aa0b03e9 	mov	x9, x11
    d0e4:	9b0b7d8c 	mul	x12, x12, x11
    d0e8:	b3607d41 	bfi	x1, x10, #32, #32
    d0ec:	eb01019f 	cmp	x12, x1
    d0f0:	540000a9 	b.ls	d104 <__modti3+0x164>  // b.plast
    d0f4:	ab0100e1 	adds	x1, x7, x1
    d0f8:	d1000569 	sub	x9, x11, #0x1
    d0fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d100:	54000f88 	b.hi	d2f0 <__modti3+0x350>  // b.pmore
    d104:	aa058123 	orr	x3, x9, x5, lsl #32
    d108:	92407c4b 	and	x11, x2, #0xffffffff
    d10c:	2a0903e9 	mov	w9, w9
    d110:	d360fc4a 	lsr	x10, x2, #32
    d114:	d360fc63 	lsr	x3, x3, #32
    d118:	cb0c0021 	sub	x1, x1, x12
    d11c:	aa0a03ec 	mov	x12, x10
    d120:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d124:	9b0b7d25 	mul	x5, x9, x11
    d128:	9b0b7c6b 	mul	x11, x3, x11
    d12c:	9b0a2d29 	madd	x9, x9, x10, x11
    d130:	92407caa 	and	x10, x5, #0xffffffff
    d134:	9b0c7c63 	mul	x3, x3, x12
    d138:	8b458125 	add	x5, x9, x5, lsr #32
    d13c:	8b0d0069 	add	x9, x3, x13
    d140:	eb05017f 	cmp	x11, x5
    d144:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d148:	8b058149 	add	x9, x10, x5, lsl #32
    d14c:	8b458063 	add	x3, x3, x5, lsr #32
    d150:	eb03003f 	cmp	x1, x3
    d154:	54000063 	b.cc	d160 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d158:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d15c:	54000082 	b.cs	d16c <__modti3+0x1cc>  // b.hs, b.nlast
    d160:	eb020129 	subs	x9, x9, x2
    d164:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d168:	cb070063 	sub	x3, x3, x7
    d16c:	eb090000 	subs	x0, x0, x9
    d170:	da030021 	sbc	x1, x1, x3
    d174:	9ac62400 	lsr	x0, x0, x6
    d178:	9ac82028 	lsl	x8, x1, x8
    d17c:	aa000100 	orr	x0, x8, x0
    d180:	9ac62421 	lsr	x1, x1, x6
    d184:	17ffffb4 	b	d054 <__modti3+0xb4>
    d188:	b5000062 	cbnz	x2, d194 <__modti3+0x1f4>
    d18c:	d2800023 	mov	x3, #0x1                   	// #1
    d190:	9ac20862 	udiv	x2, x3, x2
    d194:	dac01048 	clz	x8, x2
    d198:	aa0803e5 	mov	x5, x8
    d19c:	b5000668 	cbnz	x8, d268 <__modti3+0x2c8>
    d1a0:	cb020020 	sub	x0, x1, x2
    d1a4:	d360fc49 	lsr	x9, x2, #32
    d1a8:	92407c4a 	and	x10, x2, #0xffffffff
    d1ac:	9ac90801 	udiv	x1, x0, x9
    d1b0:	9b098020 	msub	x0, x1, x9, x0
    d1b4:	9b0a7c21 	mul	x1, x1, x10
    d1b8:	93c78000 	extr	x0, x0, x7, #32
    d1bc:	eb00003f 	cmp	x1, x0
    d1c0:	540000a9 	b.ls	d1d4 <__modti3+0x234>  // b.plast
    d1c4:	ab000040 	adds	x0, x2, x0
    d1c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d1cc:	8b020003 	add	x3, x0, x2
    d1d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d1d4:	cb010001 	sub	x1, x0, x1
    d1d8:	9ac90820 	udiv	x0, x1, x9
    d1dc:	9b098403 	msub	x3, x0, x9, x1
    d1e0:	aa0703e1 	mov	x1, x7
    d1e4:	9b0a7c00 	mul	x0, x0, x10
    d1e8:	b3607c61 	bfi	x1, x3, #32, #32
    d1ec:	eb01001f 	cmp	x0, x1
    d1f0:	540000a9 	b.ls	d204 <__modti3+0x264>  // b.plast
    d1f4:	ab010041 	adds	x1, x2, x1
    d1f8:	8b020022 	add	x2, x1, x2
    d1fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d200:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d204:	cb000020 	sub	x0, x1, x0
    d208:	17ffff91 	b	d04c <__modti3+0xac>
    d20c:	eb0203e5 	negs	x5, x2
    d210:	aa0003e7 	mov	x7, x0
    d214:	da0303e8 	ngc	x8, x3
    d218:	aa0503e2 	mov	x2, x5
    d21c:	aa0803e3 	mov	x3, x8
    d220:	aa0103e6 	mov	x6, x1
    d224:	b4ffed48 	cbz	x8, cfcc <__modti3+0x2c>
    d228:	eb01011f 	cmp	x8, x1
    d22c:	54fff148 	b.hi	d054 <__modti3+0xb4>  // b.pmore
    d230:	dac01109 	clz	x9, x8
    d234:	2a0903e6 	mov	w6, w9
    d238:	b5fff1c9 	cbnz	x9, d070 <__modti3+0xd0>
    d23c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d240:	54000068 	b.hi	d24c <__modti3+0x2ac>  // b.pmore
    d244:	eb050007 	subs	x7, x0, x5
    d248:	da080021 	sbc	x1, x1, x8
    d24c:	aa0703e0 	mov	x0, x7
    d250:	17ffff81 	b	d054 <__modti3+0xb4>
    d254:	ab000040 	adds	x0, x2, x0
    d258:	8b020002 	add	x2, x0, x2
    d25c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d260:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d264:	17ffff79 	b	d048 <__modti3+0xa8>
    d268:	9ac82042 	lsl	x2, x2, x8
    d26c:	d2800803 	mov	x3, #0x40                  	// #64
    d270:	cb080063 	sub	x3, x3, x8
    d274:	d360fc49 	lsr	x9, x2, #32
    d278:	9ac82027 	lsl	x7, x1, x8
    d27c:	92407c4a 	and	x10, x2, #0xffffffff
    d280:	9ac32426 	lsr	x6, x1, x3
    d284:	9ac32403 	lsr	x3, x0, x3
    d288:	aa070063 	orr	x3, x3, x7
    d28c:	9ac908c1 	udiv	x1, x6, x9
    d290:	9ac82007 	lsl	x7, x0, x8
    d294:	9b099820 	msub	x0, x1, x9, x6
    d298:	9b017d41 	mul	x1, x10, x1
    d29c:	93c38000 	extr	x0, x0, x3, #32
    d2a0:	eb00003f 	cmp	x1, x0
    d2a4:	540000a9 	b.ls	d2b8 <__modti3+0x318>  // b.plast
    d2a8:	ab000040 	adds	x0, x2, x0
    d2ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d2b0:	8b020006 	add	x6, x0, x2
    d2b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d2b8:	cb010000 	sub	x0, x0, x1
    d2bc:	9ac90801 	udiv	x1, x0, x9
    d2c0:	9b098026 	msub	x6, x1, x9, x0
    d2c4:	aa0303e0 	mov	x0, x3
    d2c8:	9b017d41 	mul	x1, x10, x1
    d2cc:	b3607cc0 	bfi	x0, x6, #32, #32
    d2d0:	eb00003f 	cmp	x1, x0
    d2d4:	540000a9 	b.ls	d2e8 <__modti3+0x348>  // b.plast
    d2d8:	ab000040 	adds	x0, x2, x0
    d2dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d2e0:	8b020003 	add	x3, x0, x2
    d2e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d2e8:	cb010000 	sub	x0, x0, x1
    d2ec:	17ffffb0 	b	d1ac <__modti3+0x20c>
    d2f0:	d1000969 	sub	x9, x11, #0x2
    d2f4:	8b070021 	add	x1, x1, x7
    d2f8:	17ffff83 	b	d104 <__modti3+0x164>
    d2fc:	d1000965 	sub	x5, x11, #0x2
    d300:	8b070063 	add	x3, x3, x7
    d304:	17ffff74 	b	d0d4 <__modti3+0x134>
    d308:	d503201f 	nop
    d30c:	d503201f 	nop

000000000000d310 <atexit>:
    d310:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d314:	f0000082 	adrp	x2, 20000 <__data_start>
    d318:	d2800001 	mov	x1, #0x0                   	// #0
    d31c:	910003fd 	mov	x29, sp
    d320:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d324:	f9400442 	ldr	x2, [x2, #8]
    d328:	17ffd51e 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d32c <_fini>:
    d32c:	d503201f 	nop
    d330:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d334:	910003fd 	mov	x29, sp
    d338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d33c:	d65f03c0 	ret
