
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <__modti3+0x310>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910a40a5 	add	x5, x5, #0x290
    2a20:	f0000044 	adrp	x4, d000 <__modti3+0x310>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	910a6084 	add	x4, x4, #0x298
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xee50>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2ab4:	9119c000 	add	x0, x0, #0x670
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x2210>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	9110c042 	add	x2, x2, #0x430
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430a60 	ldr	w0, [x19, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2bfc:	911a0000 	add	x0, x0, #0x680
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2c0c:	911c8000 	add	x0, x0, #0x720
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2c24:	911be000 	add	x0, x0, #0x6f8
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2c30:	911b2000 	add	x0, x0, #0x6c8
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2c3c:	911a8000 	add	x0, x0, #0x6a0
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	f0000041 	adrp	x1, d000 <__modti3+0x310>
    2e34:	91348021 	add	x1, x1, #0xd20
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <__modti3+0x310>
    2fd0:	91026000 	add	x0, x0, #0x98
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	d0000041 	adrp	x1, d000 <__modti3+0x310>
    3098:	91340021 	add	x1, x1, #0xd00
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3370:	91026000 	add	x0, x0, #0x98
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <__modti3+0x310>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	9102c021 	add	x1, x1, #0xb0
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <__modti3+0x310>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	9102e021 	add	x1, x1, #0xb8
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <__modti3+0x310>
    34e0:	91030021 	add	x1, x1, #0xc0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	d0000042 	adrp	x2, d000 <__modti3+0x310>
    3538:	aa1303e3 	mov	x3, x19
    353c:	91032042 	add	x2, x2, #0xc8
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3650:	91026000 	add	x0, x0, #0x98
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3670:	91036000 	add	x0, x0, #0xd8
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3708:	9103e000 	add	x0, x0, #0xf8
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3718:	91046000 	add	x0, x0, #0x118
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	d0000041 	adrp	x1, d000 <__modti3+0x310>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc34c20 	ldr	q0, [x1, #3376]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3818:	91050000 	add	x0, x0, #0x140
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3888:	9105c000 	add	x0, x0, #0x170
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	d0000044 	adrp	x4, d000 <__modti3+0x310>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	91070084 	add	x4, x4, #0x1c0
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	d0000044 	adrp	x4, d000 <__modti3+0x310>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	91076084 	add	x4, x4, #0x1d8
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	d0000044 	adrp	x4, d000 <__modti3+0x310>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	91072084 	add	x4, x4, #0x1c8
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    3ca8:	91154042 	add	x2, x2, #0x550
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	d0000041 	adrp	x1, d000 <__modti3+0x310>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	91078021 	add	x1, x1, #0x1e0
    3d04:	9107a000 	add	x0, x0, #0x1e8
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	d0000042 	adrp	x2, d000 <__modti3+0x310>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	91082042 	add	x2, x2, #0x208
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3e0c:	91114061 	add	x1, x3, #0x450
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3e1c:	91154262 	add	x2, x19, #0x550
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	d0000042 	adrp	x2, d000 <__modti3+0x310>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3e4c:	91124021 	add	x1, x1, #0x490
    3e50:	3dc35043 	ldr	q3, [x2, #3392]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3e7c:	91114063 	add	x3, x3, #0x450
    3e80:	9113c084 	add	x4, x4, #0x4f0
    3e84:	91154266 	add	x6, x19, #0x550
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	91154275 	add	x21, x19, #0x550
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	d0000040 	adrp	x0, d000 <__modti3+0x310>
    3f68:	910ae000 	add	x0, x0, #0x2b8
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	91154273 	add	x19, x19, #0x550
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <fwp_wake_io>:
    3fc4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fc8:	91010122 	add	x2, x9, #0x40
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	5280000a 	mov	w10, #0x0                   	// #0
    3fd4:	f9401446 	ldr	x6, [x2, #40]
    3fd8:	52800008 	mov	w8, #0x0                   	// #0
    3fdc:	4f000400 	movi	v0.4s, #0x0
    3fe0:	52800027 	mov	w7, #0x1                   	// #1
    3fe4:	aa0103e2 	mov	x2, x1
    3fe8:	b4000321 	cbz	x1, 404c <fwp_wake_io+0x88>
    3fec:	f9408c25 	ldr	x5, [x1, #280]
    3ff0:	39015c27 	strb	w7, [x1, #87]
    3ff4:	b4000165 	cbz	x5, 4020 <fwp_wake_io+0x5c>
    3ff8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3ffc:	b4000364 	cbz	x4, 4068 <fwp_wake_io+0xa4>
    4000:	f9009483 	str	x3, [x4, #296]
    4004:	f9409423 	ldr	x3, [x1, #296]
    4008:	b4000043 	cbz	x3, 4010 <fwp_wake_io+0x4c>
    400c:	f9009064 	str	x4, [x3, #288]
    4010:	91080023 	add	x3, x1, #0x200
    4014:	f900943f 	str	xzr, [x1, #296]
    4018:	3c918060 	stur	q0, [x3, #-232]
    401c:	f9400001 	ldr	x1, [x0]
    4020:	f9402843 	ldr	x3, [x2, #80]
    4024:	f2001c7f 	tst	x3, #0xff000000ff
    4028:	54fffde1 	b.ne	3fe4 <fwp_wake_io+0x20>  // b.any
    402c:	39015047 	strb	w7, [x2, #84]
    4030:	f900805f 	str	xzr, [x2, #256]
    4034:	b40001e6 	cbz	x6, 4070 <fwp_wake_io+0xac>
    4038:	f90080c2 	str	x2, [x6, #256]
    403c:	aa0203e6 	mov	x6, x2
    4040:	52800028 	mov	w8, #0x1                   	// #1
    4044:	aa0103e2 	mov	x2, x1
    4048:	b5fffd21 	cbnz	x1, 3fec <fwp_wake_io+0x28>
    404c:	3400006a 	cbz	w10, 4058 <fwp_wake_io+0x94>
    4050:	91010120 	add	x0, x9, #0x40
    4054:	f900180b 	str	x11, [x0, #48]
    4058:	34000068 	cbz	w8, 4064 <fwp_wake_io+0xa0>
    405c:	91010129 	add	x9, x9, #0x40
    4060:	f9001526 	str	x6, [x9, #40]
    4064:	d65f03c0 	ret
    4068:	f90000a3 	str	x3, [x5]
    406c:	17ffffe7 	b	4008 <fwp_wake_io+0x44>
    4070:	aa0203eb 	mov	x11, x2
    4074:	5280002a 	mov	w10, #0x1                   	// #1
    4078:	17fffff1 	b	403c <fwp_wake_io+0x78>
    407c:	d503201f 	nop

0000000000004080 <fwp_tape_buffers_release>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	aa0003f3 	mov	x19, x0
    4090:	f9401400 	ldr	x0, [x0, #40]
    4094:	b7f80760 	tbnz	x0, #63, 4180 <fwp_tape_buffers_release+0x100>
    4098:	f9401a61 	ldr	x1, [x19, #48]
    409c:	b7f80301 	tbnz	x1, #63, 40fc <fwp_tape_buffers_release+0x7c>
    40a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40a4:	eb02001f 	cmp	x0, x2
    40a8:	540002a8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40ac:	8b000400 	add	x0, x0, x0, lsl #1
    40b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40b4:	d37df000 	lsl	x0, x0, #3
    40b8:	cb000042 	sub	x2, x2, x0
    40bc:	eb420c3f 	cmp	x1, x2, lsr #3
    40c0:	540001e8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40c4:	8b010c14 	add	x20, x0, x1, lsl #3
    40c8:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    40cc:	910b2000 	add	x0, x0, #0x2c8
    40d0:	97fffa2c 	bl	2980 <getenv@plt>
    40d4:	b4000240 	cbz	x0, 411c <fwp_tape_buffers_release+0x9c>
    40d8:	39400001 	ldrb	w1, [x0]
    40dc:	7100c03f 	cmp	w1, #0x30
    40e0:	540001e1 	b.ne	411c <fwp_tape_buffers_release+0x9c>  // b.any
    40e4:	39400400 	ldrb	w0, [x0, #1]
    40e8:	350001a0 	cbnz	w0, 411c <fwp_tape_buffers_release+0x9c>
    40ec:	aa1303e0 	mov	x0, x19
    40f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40f8:	17fffc62 	b	3280 <fwp_tape_buffers_dispose>
    40fc:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    4100:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4104:	910b2000 	add	x0, x0, #0x2c8
    4108:	97fffa1e 	bl	2980 <getenv@plt>
    410c:	b4ffff00 	cbz	x0, 40ec <fwp_tape_buffers_release+0x6c>
    4110:	39400001 	ldrb	w1, [x0]
    4114:	7100c03f 	cmp	w1, #0x30
    4118:	54fffe60 	b.eq	40e4 <fwp_tape_buffers_release+0x64>  // b.none
    411c:	d1000681 	sub	x1, x20, #0x1
    4120:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4124:	eb00003f 	cmp	x1, x0
    4128:	54fffe28 	b.hi	40ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    412c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4130:	900000f6 	adrp	x22, 20000 <__data_start>
    4134:	910102d6 	add	x22, x22, #0x40
    4138:	910122d5 	add	x21, x22, #0x48
    413c:	aa1503e0 	mov	x0, x21
    4140:	97fffc50 	bl	3280 <fwp_tape_buffers_dispose>
    4144:	ad400a61 	ldp	q1, q2, [x19]
    4148:	f90042d4 	str	x20, [x22, #128]
    414c:	4f000400 	movi	v0.4s, #0x0
    4150:	ad000aa1 	stp	q1, q2, [x21]
    4154:	3dc00a61 	ldr	q1, [x19, #32]
    4158:	3d800aa1 	str	q1, [x21, #32]
    415c:	f9401a60 	ldr	x0, [x19, #48]
    4160:	f9001aa0 	str	x0, [x21, #48]
    4164:	f9001a7f 	str	xzr, [x19, #48]
    4168:	ad000260 	stp	q0, q0, [x19]
    416c:	3d800a60 	str	q0, [x19, #32]
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    417c:	d65f03c0 	ret
    4180:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    4184:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4188:	910b2000 	add	x0, x0, #0x2c8
    418c:	97fff9fd 	bl	2980 <getenv@plt>
    4190:	b5fffa40 	cbnz	x0, 40d8 <fwp_tape_buffers_release+0x58>
    4194:	17ffffd6 	b	40ec <fwp_tape_buffers_release+0x6c>
    4198:	d503201f 	nop
    419c:	d503201f 	nop

00000000000041a0 <fwp_poll_events>:
    41a0:	d10103ff 	sub	sp, sp, #0x40
    41a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41a8:	f947f400 	ldr	x0, [x0, #4072]
    41ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    41b0:	910083fd 	add	x29, sp, #0x20
    41b4:	a90353f3 	stp	x19, x20, [sp, #48]
    41b8:	900000f4 	adrp	x20, 20000 <__data_start>
    41bc:	f9400001 	ldr	x1, [x0]
    41c0:	f9000fe1 	str	x1, [sp, #24]
    41c4:	d2800001 	mov	x1, #0x0                   	// #0
    41c8:	97fffd2e 	bl	3680 <fwp_now_ns>
    41cc:	91010281 	add	x1, x20, #0x40
    41d0:	f9404433 	ldr	x19, [x1, #136]
    41d4:	b4000e93 	cbz	x19, 43a4 <fwp_poll_events+0x204>
    41d8:	aa1303e1 	mov	x1, x19
    41dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    41e0:	14000005 	b	41f4 <fwp_poll_events+0x54>
    41e4:	f9408821 	ldr	x1, [x1, #272]
    41e8:	eb03005f 	cmp	x2, x3
    41ec:	9a83d042 	csel	x2, x2, x3, le
    41f0:	b40000c1 	cbz	x1, 4208 <fwp_poll_events+0x68>
    41f4:	f9403423 	ldr	x3, [x1, #104]
    41f8:	b6ffff62 	tbz	x2, #63, 41e4 <fwp_poll_events+0x44>
    41fc:	f9408821 	ldr	x1, [x1, #272]
    4200:	aa0303e2 	mov	x2, x3
    4204:	b5ffff81 	cbnz	x1, 41f4 <fwp_poll_events+0x54>
    4208:	b7f80ce2 	tbnz	x2, #63, 43a4 <fwp_poll_events+0x204>
    420c:	cb000042 	sub	x2, x2, x0
    4210:	f100005f 	cmp	x2, #0x0
    4214:	540005cd 	b.le	42cc <fwp_poll_events+0x12c>
    4218:	d2869b60 	mov	x0, #0x34db                	// #13531
    421c:	d2884801 	mov	x1, #0x4240                	// #16960
    4220:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4224:	f2a001e1 	movk	x1, #0xf, lsl #16
    4228:	f2dbd040 	movk	x0, #0xde82, lsl #32
    422c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4230:	f2e86360 	movk	x0, #0x431b, lsl #48
    4234:	9b407c40 	smulh	x0, x2, x0
    4238:	9352fc00 	asr	x0, x0, #18
    423c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4240:	9b018802 	msub	x2, x0, x1, x2
    4244:	f100005f 	cmp	x2, #0x0
    4248:	9a800400 	cinc	x0, x0, ne	// ne = any
    424c:	eb03001f 	cmp	x0, x3
    4250:	54000a0c 	b.gt	4390 <fwp_poll_events+0x1f0>
    4254:	340003c0 	cbz	w0, 42cc <fwp_poll_events+0x12c>
    4258:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    425c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4260:	72a20c42 	movk	w2, #0x1062, lsl #16
    4264:	9ba27c02 	umull	x2, w0, w2
    4268:	d366fc43 	lsr	x3, x2, #38
    426c:	aa0303e2 	mov	x2, x3
    4270:	1b048063 	msub	w3, w3, w4, w0
    4274:	9b217c63 	smull	x3, w3, w1
    4278:	d2800001 	mov	x1, #0x0                   	// #0
    427c:	910023e0 	add	x0, sp, #0x8
    4280:	a9008fe2 	stp	x2, x3, [sp, #8]
    4284:	97fff98f 	bl	28c0 <nanosleep@plt>
    4288:	91010280 	add	x0, x20, #0x40
    428c:	f9404413 	ldr	x19, [x0, #136]
    4290:	97fffcfc 	bl	3680 <fwp_now_ns>
    4294:	aa0003e6 	mov	x6, x0
    4298:	b50001f3 	cbnz	x19, 42d4 <fwp_poll_events+0x134>
    429c:	d503201f 	nop
    42a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42a4:	f947f400 	ldr	x0, [x0, #4072]
    42a8:	f9400fe2 	ldr	x2, [sp, #24]
    42ac:	f9400001 	ldr	x1, [x0]
    42b0:	eb010042 	subs	x2, x2, x1
    42b4:	d2800001 	mov	x1, #0x0                   	// #0
    42b8:	540008c1 	b.ne	43d0 <fwp_poll_events+0x230>  // b.any
    42bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    42c4:	910103ff 	add	sp, sp, #0x40
    42c8:	d65f03c0 	ret
    42cc:	97fffced 	bl	3680 <fwp_now_ns>
    42d0:	aa0003e6 	mov	x6, x0
    42d4:	4f000400 	movi	v0.4s, #0x0
    42d8:	91010288 	add	x8, x20, #0x40
    42dc:	52800027 	mov	w7, #0x1                   	// #1
    42e0:	f9403661 	ldr	x1, [x19, #104]
    42e4:	aa1303e5 	mov	x5, x19
    42e8:	f9408a73 	ldr	x19, [x19, #272]
    42ec:	eb06003f 	cmp	x1, x6
    42f0:	5400032c 	b.gt	4354 <fwp_poll_events+0x1b4>
    42f4:	394154a0 	ldrb	w0, [x5, #85]
    42f8:	36000120 	tbz	w0, #0, 431c <fwp_poll_events+0x17c>
    42fc:	f94084a0 	ldr	x0, [x5, #264]
    4300:	b40003c0 	cbz	x0, 4378 <fwp_poll_events+0x1d8>
    4304:	f9008813 	str	x19, [x0, #272]
    4308:	b4000053 	cbz	x19, 4310 <fwp_poll_events+0x170>
    430c:	f9008660 	str	x0, [x19, #264]
    4310:	910800a0 	add	x0, x5, #0x200
    4314:	390154bf 	strb	wzr, [x5, #85]
    4318:	3c908000 	stur	q0, [x0, #-248]
    431c:	f94030a0 	ldr	x0, [x5, #96]
    4320:	390158a7 	strb	w7, [x5, #86]
    4324:	f100001f 	cmp	x0, #0x0
    4328:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    432c:	5400018d 	b.le	435c <fwp_poll_events+0x1bc>
    4330:	f94028a0 	ldr	x0, [x5, #80]
    4334:	f2001c1f 	tst	x0, #0xff000000ff
    4338:	540000e1 	b.ne	4354 <fwp_poll_events+0x1b4>  // b.any
    433c:	f9401500 	ldr	x0, [x8, #40]
    4340:	390150a7 	strb	w7, [x5, #84]
    4344:	f90080bf 	str	xzr, [x5, #256]
    4348:	b40001e0 	cbz	x0, 4384 <fwp_poll_events+0x1e4>
    434c:	f9001505 	str	x5, [x8, #40]
    4350:	f9008005 	str	x5, [x0, #256]
    4354:	b5fffc73 	cbnz	x19, 42e0 <fwp_poll_events+0x140>
    4358:	17ffffd2 	b	42a0 <fwp_poll_events+0x100>
    435c:	394144a0 	ldrb	w0, [x5, #81]
    4360:	3707fe80 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    4364:	394140a0 	ldrb	w0, [x5, #80]
    4368:	3707fe40 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    436c:	aa0503e0 	mov	x0, x5
    4370:	97fffc20 	bl	33f0 <fwp_cancel_tree.part.0>
    4374:	17ffffef 	b	4330 <fwp_poll_events+0x190>
    4378:	91010281 	add	x1, x20, #0x40
    437c:	f9004433 	str	x19, [x1, #136]
    4380:	17ffffe2 	b	4308 <fwp_poll_events+0x168>
    4384:	f9001505 	str	x5, [x8, #40]
    4388:	f9001905 	str	x5, [x8, #48]
    438c:	17fffff2 	b	4354 <fwp_poll_events+0x1b4>
    4390:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4394:	d2989362 	mov	x2, #0xc49b                	// #50331
    4398:	f2a4d203 	movk	x3, #0x2690, lsl #16
    439c:	f2a00402 	movk	x2, #0x20, lsl #16
    43a0:	17ffffb6 	b	4278 <fwp_poll_events+0xd8>
    43a4:	97fffaf3 	bl	2f70 <fwp_flush>
    43a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43ac:	f947e863 	ldr	x3, [x3, #4048]
    43b0:	d2800562 	mov	x2, #0x2b                  	// #43
    43b4:	d2800021 	mov	x1, #0x1                   	// #1
    43b8:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    43bc:	910b8000 	add	x0, x0, #0x2e0
    43c0:	f9400063 	ldr	x3, [x3]
    43c4:	97fff94b 	bl	28f0 <fwrite@plt>
    43c8:	52800ca0 	mov	w0, #0x65                  	// #101
    43cc:	97fff8b5 	bl	26a0 <exit@plt>
    43d0:	97fff908 	bl	27f0 <__stack_chk_fail@plt>

00000000000043d4 <fwp_rc_wide_dup>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	ca404400 	eor	x0, x0, x0, lsr #17
    43e8:	f90013f5 	str	x21, [sp, #32]
    43ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    43f0:	ca402400 	eor	x0, x0, x0, lsr #9
    43f4:	911542a2 	add	x2, x21, #0x550
    43f8:	92401c00 	and	x0, x0, #0xff
    43fc:	910a2403 	add	x3, x0, #0x289
    4400:	8b000c40 	add	x0, x2, x0, lsl #3
    4404:	8b030c54 	add	x20, x2, x3, lsl #3
    4408:	f94a2401 	ldr	x1, [x0, #5192]
    440c:	b50000a1 	cbnz	x1, 4420 <fwp_rc_wide_dup+0x4c>
    4410:	1400002d 	b	44c4 <fwp_rc_wide_dup+0xf0>
    4414:	91004034 	add	x20, x1, #0x10
    4418:	f9400821 	ldr	x1, [x1, #16]
    441c:	b4000241 	cbz	x1, 4464 <fwp_rc_wide_dup+0x90>
    4420:	f9400022 	ldr	x2, [x1]
    4424:	eb02027f 	cmp	x19, x2
    4428:	54ffff61 	b.ne	4414 <fwp_rc_wide_dup+0x40>  // b.any
    442c:	f9400281 	ldr	x1, [x20]
    4430:	39400260 	ldrb	w0, [x19]
    4434:	7103f81f 	cmp	w0, #0xfe
    4438:	54000220 	b.eq	447c <fwp_rc_wide_dup+0xa8>  // b.none
    443c:	b40001a1 	cbz	x1, 4470 <fwp_rc_wide_dup+0x9c>
    4440:	f9400420 	ldr	x0, [x1, #8]
    4444:	b100041f 	cmn	x0, #0x1
    4448:	540004a0 	b.eq	44dc <fwp_rc_wide_dup+0x108>  // b.none
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f9000420 	str	x0, [x1, #8]
    4454:	a94153f3 	ldp	x19, x20, [sp, #16]
    4458:	f94013f5 	ldr	x21, [sp, #32]
    445c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4460:	d65f03c0 	ret
    4464:	39400260 	ldrb	w0, [x19]
    4468:	7103f81f 	cmp	w0, #0xfe
    446c:	540000a0 	b.eq	4480 <fwp_rc_wide_dup+0xac>  // b.none
    4470:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    4474:	910ce000 	add	x0, x0, #0x338
    4478:	97fffc22 	bl	3500 <fwp_trap>
    447c:	b5000281 	cbnz	x1, 44cc <fwp_rc_wide_dup+0xf8>
    4480:	d2800300 	mov	x0, #0x18                  	// #24
    4484:	97fff8c3 	bl	2790 <malloc@plt>
    4488:	b4000280 	cbz	x0, 44d8 <fwp_rc_wide_dup+0x104>
    448c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4490:	a9000413 	stp	x19, x1, [x0]
    4494:	911542b5 	add	x21, x21, #0x550
    4498:	f900081f 	str	xzr, [x0, #16]
    449c:	12800001 	mov	w1, #0xffffffff            	// #-1
    44a0:	f9000280 	str	x0, [x20]
    44a4:	39000261 	strb	w1, [x19]
    44a8:	f94e26a0 	ldr	x0, [x21, #7240]
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	91000400 	add	x0, x0, #0x1
    44b4:	f90e26a0 	str	x0, [x21, #7240]
    44b8:	f94013f5 	ldr	x21, [sp, #32]
    44bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c0:	d65f03c0 	ret
    44c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    44c8:	17ffffda 	b	4430 <fwp_rc_wide_dup+0x5c>
    44cc:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    44d0:	910c4000 	add	x0, x0, #0x310
    44d4:	97fffc0b 	bl	3500 <fwp_trap>
    44d8:	97fffab6 	bl	2fb0 <fwp_heap_oom>
    44dc:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    44e0:	910d8000 	add	x0, x0, #0x360
    44e4:	97fffc07 	bl	3500 <fwp_trap>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_rc_forget_slot>:
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	39400000 	ldrb	w0, [x0]
    44f8:	7103fc1f 	cmp	w0, #0xff
    44fc:	54000040 	b.eq	4504 <fwp_rc_forget_slot+0x14>  // b.none
    4500:	d65f03c0 	ret
    4504:	ca414420 	eor	x0, x1, x1, lsr #17
    4508:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    450c:	ca402400 	eor	x0, x0, x0, lsr #9
    4510:	910003fd 	mov	x29, sp
    4514:	92401c00 	and	x0, x0, #0xff
    4518:	f9000bf3 	str	x19, [sp, #16]
    451c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4520:	91154262 	add	x2, x19, #0x550
    4524:	910a2403 	add	x3, x0, #0x289
    4528:	8b000c40 	add	x0, x2, x0, lsl #3
    452c:	8b030c43 	add	x3, x2, x3, lsl #3
    4530:	f94a2400 	ldr	x0, [x0, #5192]
    4534:	b50000a0 	cbnz	x0, 4548 <fwp_rc_forget_slot+0x58>
    4538:	14000011 	b	457c <fwp_rc_forget_slot+0x8c>
    453c:	91004003 	add	x3, x0, #0x10
    4540:	f9400800 	ldr	x0, [x0, #16]
    4544:	b40001c0 	cbz	x0, 457c <fwp_rc_forget_slot+0x8c>
    4548:	f9400002 	ldr	x2, [x0]
    454c:	eb02003f 	cmp	x1, x2
    4550:	54ffff61 	b.ne	453c <fwp_rc_forget_slot+0x4c>  // b.any
    4554:	f9400801 	ldr	x1, [x0, #16]
    4558:	91154273 	add	x19, x19, #0x550
    455c:	f9000061 	str	x1, [x3]
    4560:	97fff8d4 	bl	28b0 <free@plt>
    4564:	f94e2660 	ldr	x0, [x19, #7240]
    4568:	d1000400 	sub	x0, x0, #0x1
    456c:	f90e2660 	str	x0, [x19, #7240]
    4570:	f9400bf3 	ldr	x19, [sp, #16]
    4574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4578:	d65f03c0 	ret
    457c:	b0000040 	adrp	x0, d000 <__modti3+0x310>
    4580:	910ce000 	add	x0, x0, #0x338
    4584:	97fffbdf 	bl	3500 <fwp_trap>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_rc_prepare_chunk>:
    4590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4594:	910003fd 	mov	x29, sp
    4598:	a9025bf5 	stp	x21, x22, [sp, #32]
    459c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    45a0:	911542c2 	add	x2, x22, #0x550
    45a4:	b9401c03 	ldr	w3, [x0, #28]
    45a8:	aa0103f5 	mov	x21, x1
    45ac:	a90153f3 	stp	x19, x20, [sp, #16]
    45b0:	aa0003f4 	mov	x20, x0
    45b4:	f94e2440 	ldr	x0, [x2, #7240]
    45b8:	b4000440 	cbz	x0, 4640 <fwp_rc_prepare_chunk+0xb0>
    45bc:	d2800013 	mov	x19, #0x0                   	// #0
    45c0:	35000203 	cbnz	w3, 4600 <fwp_rc_prepare_chunk+0x70>
    45c4:	b4000361 	cbz	x1, 4630 <fwp_rc_prepare_chunk+0xa0>
    45c8:	f9401280 	ldr	x0, [x20, #32]
    45cc:	97fff8b9 	bl	28b0 <free@plt>
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	d2800021 	mov	x1, #0x1                   	// #1
    45d8:	97fff87e 	bl	27d0 <calloc@plt>
    45dc:	f9001280 	str	x0, [x20, #32]
    45e0:	b5000460 	cbnz	x0, 466c <fwp_rc_prepare_chunk+0xdc>
    45e4:	97fffa73 	bl	2fb0 <fwp_heap_oom>
    45e8:	97ffffc2 	bl	44f0 <fwp_rc_forget_slot>
    45ec:	91000673 	add	x19, x19, #0x1
    45f0:	b9401e83 	ldr	w3, [x20, #28]
    45f4:	eb13007f 	cmp	x3, x19
    45f8:	54000169 	b.ls	4624 <fwp_rc_prepare_chunk+0x94>  // b.plast
    45fc:	d503201f 	nop
    4600:	f9401283 	ldr	x3, [x20, #32]
    4604:	8b130060 	add	x0, x3, x19
    4608:	38736863 	ldrb	w3, [x3, x19]
    460c:	7103fc7f 	cmp	w3, #0xff
    4610:	54fffec0 	b.eq	45e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4614:	b9401e83 	ldr	w3, [x20, #28]
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb13007f 	cmp	x3, x19
    4620:	54ffff08 	b.hi	4600 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4624:	eb0302bf 	cmp	x21, x3
    4628:	54000121 	b.ne	464c <fwp_rc_prepare_chunk+0xbc>  // b.any
    462c:	b5000335 	cbnz	x21, 4690 <fwp_rc_prepare_chunk+0x100>
    4630:	a94153f3 	ldp	x19, x20, [sp, #16]
    4634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4638:	a8c37bfd 	ldp	x29, x30, [sp], #48
    463c:	d65f03c0 	ret
    4640:	2a0303e3 	mov	w3, w3
    4644:	eb0302bf 	cmp	x21, x3
    4648:	54ffff20 	b.eq	462c <fwp_rc_prepare_chunk+0x9c>  // b.none
    464c:	911542c2 	add	x2, x22, #0x550
    4650:	f9401280 	ldr	x0, [x20, #32]
    4654:	f94e2841 	ldr	x1, [x2, #7248]
    4658:	cb030021 	sub	x1, x1, x3
    465c:	f90e2841 	str	x1, [x2, #7248]
    4660:	97fff894 	bl	28b0 <free@plt>
    4664:	b5fffb75 	cbnz	x21, 45d0 <fwp_rc_prepare_chunk+0x40>
    4668:	f900129f 	str	xzr, [x20, #32]
    466c:	911542d6 	add	x22, x22, #0x550
    4670:	f94e2ac0 	ldr	x0, [x22, #7248]
    4674:	b9001e95 	str	w21, [x20, #28]
    4678:	a94153f3 	ldp	x19, x20, [sp, #16]
    467c:	8b150000 	add	x0, x0, x21
    4680:	f90e2ac0 	str	x0, [x22, #7248]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	f9401280 	ldr	x0, [x20, #32]
    4694:	aa1503e2 	mov	x2, x21
    4698:	a94153f3 	ldp	x19, x20, [sp, #16]
    469c:	52800001 	mov	w1, #0x0                   	// #0
    46a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46a8:	17fff846 	b	27c0 <memset@plt>
    46ac:	d503201f 	nop

00000000000046b0 <fwp_heap_refill>:
    46b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    46b4:	910003fd 	mov	x29, sp
    46b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    46bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    46c0:	911542b5 	add	x21, x21, #0x550
    46c4:	aa0003f6 	mov	x22, x0
    46c8:	d2800020 	mov	x0, #0x1                   	// #1
    46cc:	a90153f3 	stp	x19, x20, [sp, #16]
    46d0:	a90363f7 	stp	x23, x24, [sp, #48]
    46d4:	2a0103f7 	mov	w23, w1
    46d8:	2a0203f8 	mov	w24, w2
    46dc:	97fffa75 	bl	30b0 <fwp_heap_chunks>
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	f949fea2 	ldr	x2, [x21, #5112]
    46e8:	8b000800 	add	x0, x0, x0, lsl #2
    46ec:	2a1703e1 	mov	w1, w23
    46f0:	52800025 	mov	w5, #0x1                   	// #1
    46f4:	d37df000 	lsl	x0, x0, #3
    46f8:	910f0021 	add	x1, x1, #0x3c0
    46fc:	8b000054 	add	x20, x2, x0
    4700:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4704:	52a00024 	mov	w4, #0x10000               	// #65536
    4708:	38206845 	strb	w5, [x2, x0]
    470c:	aa1403e0 	mov	x0, x20
    4710:	39000698 	strb	w24, [x20, #1]
    4714:	39000a97 	strb	w23, [x20, #2]
    4718:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    471c:	b9000681 	str	w1, [x20, #4]
    4720:	2a0103e5 	mov	w5, w1
    4724:	8b0300a2 	add	x2, x5, x3
    4728:	1ac10881 	udiv	w1, w4, w1
    472c:	9ac50842 	udiv	x2, x2, x5
    4730:	b9000a81 	str	w1, [x20, #8]
    4734:	92404021 	and	x1, x1, #0x1ffff
    4738:	b9001a82 	str	w2, [x20, #24]
    473c:	97ffff95 	bl	4590 <fwp_rc_prepare_chunk>
    4740:	f949daa0 	ldr	x0, [x21, #5040]
    4744:	29408a81 	ldp	w1, w2, [x20, #4]
    4748:	8b134000 	add	x0, x0, x19, lsl #16
    474c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4750:	8b214003 	add	x3, x0, w1, uxtw
    4754:	9ba20021 	umaddl	x1, w1, w2, x0
    4758:	a94363f7 	ldp	x23, x24, [sp, #48]
    475c:	a90086c3 	stp	x3, x1, [x22, #8]
    4760:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4764:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4768:	d65f03c0 	ret
    476c:	d503201f 	nop

0000000000004770 <fwp_mem_free>:
    4770:	b40003c0 	cbz	x0, 47e8 <fwp_mem_free+0x78>
    4774:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4778:	910003fd 	mov	x29, sp
    477c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4780:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4784:	911542a1 	add	x1, x21, #0x550
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	f949d823 	ldr	x3, [x1, #5040]
    4794:	f949ec22 	ldr	x2, [x1, #5080]
    4798:	cb030000 	sub	x0, x0, x3
    479c:	eb02401f 	cmp	x0, x2, lsl #16
    47a0:	540001c2 	b.cs	47d8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47a4:	d350fc16 	lsr	x22, x0, #16
    47a8:	a90363f7 	stp	x23, x24, [sp, #48]
    47ac:	f949fc22 	ldr	x2, [x1, #5112]
    47b0:	8b160ad4 	add	x20, x22, x22, lsl #2
    47b4:	d37df294 	lsl	x20, x20, #3
    47b8:	ab140057 	adds	x23, x2, x20
    47bc:	540000c0 	b.eq	47d4 <fwp_mem_free+0x64>  // b.none
    47c0:	38746842 	ldrb	w2, [x2, x20]
    47c4:	7100045f 	cmp	w2, #0x1
    47c8:	54000120 	b.eq	47ec <fwp_mem_free+0x7c>  // b.none
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540005e0 	b.eq	488c <fwp_mem_free+0x11c>  // b.none
    47d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47e4:	d65f03c0 	ret
    47e8:	d65f03c0 	ret
    47ec:	f94012f8 	ldr	x24, [x23, #32]
    47f0:	b94006e1 	ldr	w1, [x23, #4]
    47f4:	f90023f9 	str	x25, [sp, #64]
    47f8:	2a0103e2 	mov	w2, w1
    47fc:	394006f9 	ldrb	w25, [x23, #1]
    4800:	39400af4 	ldrb	w20, [x23, #2]
    4804:	b4000158 	cbz	x24, 482c <fwp_mem_free+0xbc>
    4808:	92403e76 	and	x22, x19, #0xffff
    480c:	9ac20ad6 	udiv	x22, x22, x2
    4810:	38766b01 	ldrb	w1, [x24, x22]
    4814:	8b160300 	add	x0, x24, x22
    4818:	7103fc3f 	cmp	w1, #0xff
    481c:	54000980 	b.eq	494c <fwp_mem_free+0x1dc>  // b.none
    4820:	38366b1f 	strb	wzr, [x24, x22]
    4824:	b94006e1 	ldr	w1, [x23, #4]
    4828:	2a0103e2 	mov	w2, w1
    482c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4830:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4834:	cb390000 	sub	x0, x0, w25, uxtb
    4838:	8b340074 	add	x20, x3, w20, uxtb
    483c:	911542b5 	add	x21, x21, #0x550
    4840:	1e630021 	ucvtf	d1, w1
    4844:	d37ae400 	lsl	x0, x0, #6
    4848:	8b140c14 	add	x20, x0, x20, lsl #3
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	f8746aa0 	ldr	x0, [x21, x20]
    4854:	f94023f9 	ldr	x25, [sp, #64]
    4858:	aa2003e0 	mvn	x0, x0
    485c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4860:	f9000260 	str	x0, [x19]
    4864:	f8346ab3 	str	x19, [x21, x20]
    4868:	f94a12a0 	ldr	x0, [x21, #5152]
    486c:	1e612800 	fadd	d0, d0, d1
    4870:	a94153f3 	ldp	x19, x20, [sp, #16]
    4874:	cb020000 	sub	x0, x0, x2
    4878:	f90a12a0 	str	x0, [x21, #5152]
    487c:	fd0a22a0 	str	d0, [x21, #5184]
    4880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4884:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4888:	d65f03c0 	ret
    488c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4890:	8b000063 	add	x3, x3, x0
    4894:	eb03027f 	cmp	x19, x3
    4898:	54fff9e1 	b.ne	47d4 <fwp_mem_free+0x64>  // b.any
    489c:	fd400ae1 	ldr	d1, [x23, #16]
    48a0:	fd4a2020 	ldr	d0, [x1, #5184]
    48a4:	f9400ae0 	ldr	x0, [x23, #16]
    48a8:	7e61d821 	ucvtf	d1, d1
    48ac:	f94a1022 	ldr	x2, [x1, #5152]
    48b0:	f94012f3 	ldr	x19, [x23, #32]
    48b4:	1e612800 	fadd	d0, d0, d1
    48b8:	cb000042 	sub	x2, x2, x0
    48bc:	f90a1022 	str	x2, [x1, #5152]
    48c0:	fd0a2020 	str	d0, [x1, #5184]
    48c4:	b40000b3 	cbz	x19, 48d8 <fwp_mem_free+0x168>
    48c8:	39400260 	ldrb	w0, [x19]
    48cc:	7103fc1f 	cmp	w0, #0xff
    48d0:	54000380 	b.eq	4940 <fwp_mem_free+0x1d0>  // b.none
    48d4:	3900027f 	strb	wzr, [x19]
    48d8:	b9400ee2 	ldr	w2, [x23, #12]
    48dc:	b4000142 	cbz	x2, 4904 <fwp_mem_free+0x194>
    48e0:	911542a1 	add	x1, x21, #0x550
    48e4:	8b160040 	add	x0, x2, x22
    48e8:	8b000800 	add	x0, x0, x0, lsl #2
    48ec:	f949fc21 	ldr	x1, [x1, #5112]
    48f0:	8b140034 	add	x20, x1, x20
    48f4:	8b000c20 	add	x0, x1, x0, lsl #3
    48f8:	3802869f 	strb	wzr, [x20], #40
    48fc:	eb00029f 	cmp	x20, x0
    4900:	54ffffc1 	b.ne	48f8 <fwp_mem_free+0x188>  // b.any
    4904:	911542a0 	add	x0, x21, #0x550
    4908:	f94a1801 	ldr	x1, [x0, #5168]
    490c:	f949f803 	ldr	x3, [x0, #5104]
    4910:	8b020021 	add	x1, x1, x2
    4914:	f90a1801 	str	x1, [x0, #5168]
    4918:	eb16007f 	cmp	x3, x22
    491c:	54000049 	b.ls	4924 <fwp_mem_free+0x1b4>  // b.plast
    4920:	f909f816 	str	x22, [x0, #5104]
    4924:	911542b5 	add	x21, x21, #0x550
    4928:	f949f6a0 	ldr	x0, [x21, #5096]
    492c:	eb16001f 	cmp	x0, x22
    4930:	54fff529 	b.ls	47d4 <fwp_mem_free+0x64>  // b.plast
    4934:	a94363f7 	ldp	x23, x24, [sp, #48]
    4938:	f909f6b6 	str	x22, [x21, #5096]
    493c:	17ffffa7 	b	47d8 <fwp_mem_free+0x68>
    4940:	aa1303e0 	mov	x0, x19
    4944:	97fffeeb 	bl	44f0 <fwp_rc_forget_slot>
    4948:	17ffffe3 	b	48d4 <fwp_mem_free+0x164>
    494c:	97fffee9 	bl	44f0 <fwp_rc_forget_slot>
    4950:	17ffffb4 	b	4820 <fwp_mem_free+0xb0>

0000000000004954 <fwp_heap_alloc_big>:
    4954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4958:	910003fd 	mov	x29, sp
    495c:	a90153f3 	stp	x19, x20, [sp, #16]
    4960:	a9025bf5 	stp	x21, x22, [sp, #32]
    4964:	a90363f7 	stp	x23, x24, [sp, #48]
    4968:	aa0003f7 	mov	x23, x0
    496c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	eb0002ff 	cmp	x23, x0
    4978:	54000888 	b.hi	4a88 <fwp_heap_alloc_big+0x134>  // b.pmore
    497c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4980:	8b0002f4 	add	x20, x23, x0
    4984:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4988:	91154359 	add	x25, x26, #0x550
    498c:	d350fe94 	lsr	x20, x20, #16
    4990:	2a0103f5 	mov	w21, w1
    4994:	aa1403e0 	mov	x0, x20
    4998:	97fff9c6 	bl	30b0 <fwp_heap_chunks>
    499c:	f949ff22 	ldr	x2, [x25, #5112]
    49a0:	8b000813 	add	x19, x0, x0, lsl #2
    49a4:	aa0003f8 	mov	x24, x0
    49a8:	52800043 	mov	w3, #0x2                   	// #2
    49ac:	d37df273 	lsl	x19, x19, #3
    49b0:	d2800021 	mov	x1, #0x1                   	// #1
    49b4:	8b130040 	add	x0, x2, x19
    49b8:	38336843 	strb	w3, [x2, x19]
    49bc:	39000415 	strb	w21, [x0, #1]
    49c0:	b9000c14 	str	w20, [x0, #12]
    49c4:	f9000817 	str	x23, [x0, #16]
    49c8:	97fffef2 	bl	4590 <fwp_rc_prepare_chunk>
    49cc:	f100069f 	cmp	x20, #0x1
    49d0:	54000269 	b.ls	4a1c <fwp_heap_alloc_big+0xc8>  // b.plast
    49d4:	8b180294 	add	x20, x20, x24
    49d8:	9100a273 	add	x19, x19, #0x28
    49dc:	a90573fb 	stp	x27, x28, [sp, #80]
    49e0:	5280007b 	mov	w27, #0x3                   	// #3
    49e4:	8b140a94 	add	x20, x20, x20, lsl #2
    49e8:	2a1803fc 	mov	w28, w24
    49ec:	9adb2296 	lsl	x22, x20, x27
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffee4 	bl	4590 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0x9c>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x104>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffca4 	bl	3e04 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff70 	b	4954 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffeb5 	bl	46b0 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9401ee0 	ldr	x0, [x23, #56]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_p_ad_push.constprop.0>:
    4f24:	f100001f 	cmp	x0, #0x0
    4f28:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f2c:	54000e8b 	b.lt	50fc <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    4f30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f34:	aa0003e4 	mov	x4, x0
    4f38:	910003fd 	mov	x29, sp
    4f3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f40:	aa0003f5 	mov	x21, x0
    4f44:	aa020000 	orr	x0, x0, x2
    4f48:	a90363f7 	stp	x23, x24, [sp, #48]
    4f4c:	aa0203f7 	mov	x23, x2
    4f50:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f54:	9e670029 	fmov	d9, x1
    4f58:	9e670068 	fmov	d8, x3
    4f5c:	b6f80900 	tbz	x0, #63, 507c <fwp_p_ad_push.constprop.0+0x158>
    4f60:	a90153f3 	stp	x19, x20, [sp, #16]
    4f64:	9360fc80 	asr	x0, x4, #32
    4f68:	b6f800c4 	tbz	x4, #63, 4f80 <fwp_p_ad_push.constprop.0+0x5c>
    4f6c:	1e604109 	fmov	d9, d8
    4f70:	2f00e408 	movi	d8, #0x0
    4f74:	9360fc40 	asr	x0, x2, #32
    4f78:	aa0203f5 	mov	x21, x2
    4f7c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f80:	97fffa2c 	bl	3830 <fwp_tape_of>
    4f84:	aa0003f3 	mov	x19, x0
    4f88:	f9403000 	ldr	x0, [x0, #96]
    4f8c:	b5001280 	cbnz	x0, 51dc <fwp_p_ad_push.constprop.0+0x2b8>
    4f90:	f9400a76 	ldr	x22, [x19, #16]
    4f94:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f98:	eb0002df 	cmp	x22, x0
    4f9c:	54000e2c 	b.gt	5160 <fwp_p_ad_push.constprop.0+0x23c>
    4fa0:	eb3542df 	cmp	x22, w21, uxtw
    4fa4:	54000d4d 	b.le	514c <fwp_p_ad_push.constprop.0+0x228>
    4fa8:	b7f80077 	tbnz	x23, #63, 4fb4 <fwp_p_ad_push.constprop.0+0x90>
    4fac:	eb3742df 	cmp	x22, w23, uxtw
    4fb0:	54000ced 	b.le	514c <fwp_p_ad_push.constprop.0+0x228>
    4fb4:	f9400678 	ldr	x24, [x19, #8]
    4fb8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4fbc:	cb1802d8 	sub	x24, x22, x24
    4fc0:	91000701 	add	x1, x24, #0x1
    4fc4:	eb00003f 	cmp	x1, x0
    4fc8:	54000cc8 	b.hi	5160 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    4fcc:	a9418274 	ldp	x20, x0, [x19, #24]
    4fd0:	a90573fb 	stp	x27, x28, [sp, #80]
    4fd4:	eb14003f 	cmp	x1, x20
    4fd8:	5400068d 	b.le	50a8 <fwp_p_ad_push.constprop.0+0x184>
    4fdc:	f100029f 	cmp	x20, #0x0
    4fe0:	d2800803 	mov	x3, #0x40                  	// #64
    4fe4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4fe8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4fec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4ff0:	eb14003f 	cmp	x1, x20
    4ff4:	5400008d 	b.le	5004 <fwp_p_ad_push.constprop.0+0xe0>
    4ff8:	eb02029f 	cmp	x20, x2
    4ffc:	5400052d 	b.le	50a0 <fwp_p_ad_push.constprop.0+0x17c>
    5000:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5004:	d37df299 	lsl	x25, x20, #3
    5008:	aa1903e1 	mov	x1, x25
    500c:	97fff5f5 	bl	27e0 <realloc@plt>
    5010:	aa0003e1 	mov	x1, x0
    5014:	b4000b00 	cbz	x0, 5174 <fwp_p_ad_push.constprop.0+0x250>
    5018:	f9400e62 	ldr	x2, [x19, #24]
    501c:	f9001261 	str	x1, [x19, #32]
    5020:	f9401a60 	ldr	x0, [x19, #48]
    5024:	d37cee9a 	lsl	x26, x20, #4
    5028:	8b020821 	add	x1, x1, x2, lsl #2
    502c:	f9001661 	str	x1, [x19, #40]
    5030:	aa1a03e1 	mov	x1, x26
    5034:	97fff5eb 	bl	27e0 <realloc@plt>
    5038:	aa0003e2 	mov	x2, x0
    503c:	b40009c0 	cbz	x0, 5174 <fwp_p_ad_push.constprop.0+0x250>
    5040:	f9400e61 	ldr	x1, [x19, #24]
    5044:	d37df31b 	lsl	x27, x24, #3
    5048:	d37ef685 	lsl	x5, x20, #2
    504c:	d37ef71c 	lsl	x28, x24, #2
    5050:	8b190004 	add	x4, x0, x25
    5054:	8b010c01 	add	x1, x0, x1, lsl #3
    5058:	a9030660 	stp	x0, x1, [x19, #48]
    505c:	b5000558 	cbnz	x24, 5104 <fwp_p_ad_push.constprop.0+0x1e0>
    5060:	f9001e64 	str	x4, [x19, #56]
    5064:	f9401260 	ldr	x0, [x19, #32]
    5068:	a9446bf9 	ldp	x25, x26, [sp, #64]
    506c:	8b050001 	add	x1, x0, x5
    5070:	f9000e74 	str	x20, [x19, #24]
    5074:	f9001661 	str	x1, [x19, #40]
    5078:	14000010 	b	50b8 <fwp_p_ad_push.constprop.0+0x194>
    507c:	9360fc40 	asr	x0, x2, #32
    5080:	a90153f3 	stp	x19, x20, [sp, #16]
    5084:	eb84801f 	cmp	x0, x4, asr #32
    5088:	54fff7c0 	b.eq	4f80 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    508c:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5090:	910e0000 	add	x0, x0, #0x380
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	a90573fb 	stp	x27, x28, [sp, #80]
    509c:	97fff919 	bl	3500 <fwp_trap>
    50a0:	d37ffa94 	lsl	x20, x20, #1
    50a4:	17ffffd3 	b	4ff0 <fwp_p_ad_push.constprop.0+0xcc>
    50a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    50ac:	d37ef71c 	lsl	x28, x24, #2
    50b0:	f9401e64 	ldr	x4, [x19, #56]
    50b4:	d37df31b 	lsl	x27, x24, #3
    50b8:	b83c6815 	str	w21, [x0, x28]
    50bc:	f10002ff 	cmp	x23, #0x0
    50c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    50c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    50c8:	fc3b6849 	str	d9, [x2, x27]
    50cc:	aa1602a0 	orr	x0, x21, x22
    50d0:	b83c6837 	str	w23, [x1, x28]
    50d4:	910006d6 	add	x22, x22, #0x1
    50d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50dc:	fc3b6888 	str	d8, [x4, x27]
    50e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    50e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    50e8:	f9000a76 	str	x22, [x19, #16]
    50ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    50f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    50f8:	d65f03c0 	ret
    50fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5100:	d65f03c0 	ret
    5104:	eb1a033f 	cmp	x25, x26
    5108:	aa0403e0 	mov	x0, x4
    510c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5110:	aa1b03e2 	mov	x2, x27
    5114:	cb190063 	sub	x3, x3, x25
    5118:	f9003fe5 	str	x5, [sp, #120]
    511c:	97fff61d 	bl	2990 <__memmove_chk@plt>
    5120:	a9420660 	ldp	x0, x1, [x19, #32]
    5124:	aa1c03e2 	mov	x2, x28
    5128:	f9401a63 	ldr	x3, [x19, #48]
    512c:	f9403fe5 	ldr	x5, [sp, #120]
    5130:	8b190063 	add	x3, x3, x25
    5134:	f9001e63 	str	x3, [x19, #56]
    5138:	8b050000 	add	x0, x0, x5
    513c:	97fff549 	bl	2660 <memmove@plt>
    5140:	a9431262 	ldp	x2, x4, [x19, #48]
    5144:	f9403fe5 	ldr	x5, [sp, #120]
    5148:	17ffffc7 	b	5064 <fwp_p_ad_push.constprop.0+0x140>
    514c:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5150:	91106000 	add	x0, x0, #0x418
    5154:	a9046bf9 	stp	x25, x26, [sp, #64]
    5158:	a90573fb 	stp	x27, x28, [sp, #80]
    515c:	97fff8e9 	bl	3500 <fwp_trap>
    5160:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5164:	910fe000 	add	x0, x0, #0x3f8
    5168:	a9046bf9 	stp	x25, x26, [sp, #64]
    516c:	a90573fb 	stp	x27, x28, [sp, #80]
    5170:	97fff8e4 	bl	3500 <fwp_trap>
    5174:	aa1303e0 	mov	x0, x19
    5178:	97fff766 	bl	2f10 <fwp_tape_unlink_scope>
    517c:	f9401260 	ldr	x0, [x19, #32]
    5180:	97fff5cc 	bl	28b0 <free@plt>
    5184:	f9401a60 	ldr	x0, [x19, #48]
    5188:	97fff5ca 	bl	28b0 <free@plt>
    518c:	f9402260 	ldr	x0, [x19, #64]
    5190:	97fff5c8 	bl	28b0 <free@plt>
    5194:	f9000e7f 	str	xzr, [x19, #24]
    5198:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    519c:	f947e821 	ldr	x1, [x1, #4048]
    51a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51a4:	d2800262 	mov	x2, #0x13                  	// #19
    51a8:	4f000400 	movi	v0.4s, #0x0
    51ac:	90000040 	adrp	x0, d000 <__modti3+0x310>
    51b0:	f9400023 	ldr	x3, [x1]
    51b4:	b900067f 	str	wzr, [x19, #4]
    51b8:	d2800021 	mov	x1, #0x1                   	// #1
    51bc:	91026000 	add	x0, x0, #0x98
    51c0:	3c808260 	stur	q0, [x19, #8]
    51c4:	ad010260 	stp	q0, q0, [x19, #32]
    51c8:	97fff5ca 	bl	28f0 <fwrite@plt>
    51cc:	d2800000 	mov	x0, #0x0                   	// #0
    51d0:	97fff5d4 	bl	2920 <fflush@plt>
    51d4:	52800cc0 	mov	w0, #0x66                  	// #102
    51d8:	97fff5e2 	bl	2960 <_Exit@plt>
    51dc:	90000040 	adrp	x0, d000 <__modti3+0x310>
    51e0:	910f2000 	add	x0, x0, #0x3c8
    51e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51e8:	a90573fb 	stp	x27, x28, [sp, #80]
    51ec:	97fff8c5 	bl	3500 <fwp_trap>

00000000000051f0 <w107>:
    51f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51f4:	9e660003 	fmov	x3, d0
    51f8:	aa0003e2 	mov	x2, x0
    51fc:	910003fd 	mov	x29, sp
    5200:	6d0327e8 	stp	d8, d9, [sp, #48]
    5204:	1e604028 	fmov	d8, d1
    5208:	1e600809 	fmul	d9, d0, d0
    520c:	fd0023ea 	str	d10, [sp, #64]
    5210:	1e60400a 	fmov	d10, d0
    5214:	a90153f3 	stp	x19, x20, [sp, #16]
    5218:	aa0003f3 	mov	x19, x0
    521c:	aa0103f4 	mov	x20, x1
    5220:	aa0303e1 	mov	x1, x3
    5224:	a9025bf5 	stp	x21, x22, [sp, #32]
    5228:	97ffff3f 	bl	4f24 <fwp_p_ad_push.constprop.0>
    522c:	1e693908 	fsub	d8, d8, d9
    5230:	aa1403e2 	mov	x2, x20
    5234:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5238:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    523c:	9e660116 	fmov	x22, d8
    5240:	97ffff39 	bl	4f24 <fwp_p_ad_push.constprop.0>
    5244:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5248:	aa0003e1 	mov	x1, x0
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa1303e0 	mov	x0, x19
    5254:	1e6a3929 	fsub	d9, d9, d10
    5258:	aa0103f3 	mov	x19, x1
    525c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5260:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5264:	9e660135 	fmov	x21, d9
    5268:	97ffff2f 	bl	4f24 <fwp_p_ad_push.constprop.0>
    526c:	1e680908 	fmul	d8, d8, d8
    5270:	aa0003f4 	mov	x20, x0
    5274:	aa1603e3 	mov	x3, x22
    5278:	aa1603e1 	mov	x1, x22
    527c:	aa1303e2 	mov	x2, x19
    5280:	aa1303e0 	mov	x0, x19
    5284:	97ffff28 	bl	4f24 <fwp_p_ad_push.constprop.0>
    5288:	aa0003e2 	mov	x2, x0
    528c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5290:	9e670020 	fmov	d0, x1
    5294:	9e660101 	fmov	x1, d8
    5298:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    529c:	1e600908 	fmul	d8, d8, d0
    52a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52a4:	97ffff20 	bl	4f24 <fwp_p_ad_push.constprop.0>
    52a8:	1e690929 	fmul	d9, d9, d9
    52ac:	aa0003f3 	mov	x19, x0
    52b0:	aa1503e3 	mov	x3, x21
    52b4:	aa1503e1 	mov	x1, x21
    52b8:	aa1403e2 	mov	x2, x20
    52bc:	aa1403e0 	mov	x0, x20
    52c0:	97ffff19 	bl	4f24 <fwp_p_ad_push.constprop.0>
    52c4:	1e692908 	fadd	d8, d8, d9
    52c8:	aa1303e2 	mov	x2, x19
    52cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52d0:	aa0303e1 	mov	x1, x3
    52d4:	97ffff14 	bl	4f24 <fwp_p_ad_push.constprop.0>
    52d8:	aa0003e1 	mov	x1, x0
    52dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    52e0:	9e660100 	fmov	x0, d8
    52e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    52ec:	fd4023ea 	ldr	d10, [sp, #64]
    52f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52f4:	d65f03c0 	ret
    52f8:	d503201f 	nop
    52fc:	d503201f 	nop

0000000000005300 <w164.constprop.0>:
    5300:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5304:	910003fd 	mov	x29, sp
    5308:	a9025bf5 	stp	x21, x22, [sp, #32]
    530c:	fd001be8 	str	d8, [sp, #48]
    5310:	f9400015 	ldr	x21, [x0]
    5314:	b4000315 	cbz	x21, 5374 <w164.constprop.0+0x74>
    5318:	2f00e408 	movi	d8, #0x0
    531c:	91002016 	add	x22, x0, #0x8
    5320:	a90153f3 	stp	x19, x20, [sp, #16]
    5324:	91004014 	add	x20, x0, #0x10
    5328:	d2800013 	mov	x19, #0x0                   	// #0
    532c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5330:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5334:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5338:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    533c:	aa0303e1 	mov	x1, x3
    5340:	1e602908 	fadd	d8, d8, d0
    5344:	91000a73 	add	x19, x19, #0x2
    5348:	97fffef7 	bl	4f24 <fwp_p_ad_push.constprop.0>
    534c:	eb1302bf 	cmp	x21, x19
    5350:	54ffff08 	b.hi	5330 <w164.constprop.0+0x30>  // b.pmore
    5354:	9e660102 	fmov	x2, d8
    5358:	fd401be8 	ldr	d8, [sp, #48]
    535c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5360:	aa0003e1 	mov	x1, x0
    5364:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5368:	aa0203e0 	mov	x0, x2
    536c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5370:	d65f03c0 	ret
    5374:	2f00e408 	movi	d8, #0x0
    5378:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    537c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5380:	aa0003e1 	mov	x1, x0
    5384:	9e660102 	fmov	x2, d8
    5388:	fd401be8 	ldr	d8, [sp, #48]
    538c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5390:	aa0203e0 	mov	x0, x2
    5394:	d65f03c0 	ret
    5398:	d503201f 	nop
    539c:	d503201f 	nop

00000000000053a0 <fwp_data.part.0.constprop.0>:
    53a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53a4:	910003fd 	mov	x29, sp
    53a8:	a90153f3 	stp	x19, x20, [sp, #16]
    53ac:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    53b0:	91154283 	add	x3, x20, #0x550
    53b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    53b8:	aa0103f5 	mov	x21, x1
    53bc:	b953a461 	ldr	w1, [x3, #5028]
    53c0:	a90363f7 	stp	x23, x24, [sp, #48]
    53c4:	2a0003f8 	mov	w24, w0
    53c8:	34000701 	cbz	w1, 54a8 <fwp_data.part.0.constprop.0+0x108>
    53cc:	397e8862 	ldrb	w2, [x3, #4002]
    53d0:	910f0040 	add	x0, x2, #0x3c0
    53d4:	8b020442 	add	x2, x2, x2, lsl #1
    53d8:	d37df042 	lsl	x2, x2, #3
    53dc:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    53e0:	2a1703f6 	mov	w22, w23
    53e4:	f8626873 	ldr	x19, [x3, x2]
    53e8:	b40004d3 	cbz	x19, 5480 <fwp_data.part.0.constprop.0+0xe0>
    53ec:	f9400260 	ldr	x0, [x19]
    53f0:	aa2003e0 	mvn	x0, x0
    53f4:	f8226860 	str	x0, [x3, x2]
    53f8:	f10062df 	cmp	x22, #0x18
    53fc:	540000e9 	b.ls	5418 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5400:	d10066c2 	sub	x2, x22, #0x19
    5404:	91006260 	add	x0, x19, #0x18
    5408:	927df042 	and	x2, x2, #0xfffffffffffffff8
    540c:	52800001 	mov	w1, #0x0                   	// #0
    5410:	91002042 	add	x2, x2, #0x8
    5414:	97fff4eb 	bl	27c0 <memset@plt>
    5418:	91154282 	add	x2, x20, #0x550
    541c:	f94a1041 	ldr	x1, [x2, #5152]
    5420:	ab160021 	adds	x1, x1, x22
    5424:	540004c2 	b.cs	54bc <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5428:	f94a1440 	ldr	x0, [x2, #5160]
    542c:	f90a1041 	str	x1, [x2, #5152]
    5430:	eb00003f 	cmp	x1, x0
    5434:	54000049 	b.ls	543c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5438:	f90a1441 	str	x1, [x2, #5160]
    543c:	91154294 	add	x20, x20, #0x550
    5440:	1e6302e1 	ucvtf	d1, w23
    5444:	fd4a1e80 	ldr	d0, [x20, #5176]
    5448:	1e612800 	fadd	d0, d0, d1
    544c:	fd0a1e80 	str	d0, [x20, #5176]
    5450:	52800041 	mov	w1, #0x2                   	// #2
    5454:	29000678 	stp	w24, w1, [x19]
    5458:	aa1303e0 	mov	x0, x19
    545c:	f94002a1 	ldr	x1, [x21]
    5460:	f9000661 	str	x1, [x19, #8]
    5464:	f94006a1 	ldr	x1, [x21, #8]
    5468:	f9000a61 	str	x1, [x19, #16]
    546c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5474:	a94363f7 	ldp	x23, x24, [sp, #48]
    5478:	a8c47bfd 	ldp	x29, x30, [sp], #64
    547c:	d65f03c0 	ret
    5480:	8b020063 	add	x3, x3, x2
    5484:	f9400473 	ldr	x19, [x3, #8]
    5488:	b4000113 	cbz	x19, 54a8 <fwp_data.part.0.constprop.0+0x108>
    548c:	f9400860 	ldr	x0, [x3, #16]
    5490:	cb130000 	sub	x0, x0, x19
    5494:	eb0002df 	cmp	x22, x0
    5498:	54000088 	b.hi	54a8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    549c:	8b160260 	add	x0, x19, x22
    54a0:	f9000460 	str	x0, [x3, #8]
    54a4:	17ffffd5 	b	53f8 <fwp_data.part.0.constprop.0+0x58>
    54a8:	52800001 	mov	w1, #0x0                   	// #0
    54ac:	d2800300 	mov	x0, #0x18                  	// #24
    54b0:	97fffdd0 	bl	4bf0 <fwp_heap_alloc>
    54b4:	aa0003f3 	mov	x19, x0
    54b8:	17ffffe6 	b	5450 <fwp_data.part.0.constprop.0+0xb0>
    54bc:	97fff6bd 	bl	2fb0 <fwp_heap_oom>

00000000000054c0 <fwp_rc_share>:
    54c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    54c4:	91154042 	add	x2, x2, #0x550
    54c8:	f949d843 	ldr	x3, [x2, #5040]
    54cc:	f949ec41 	ldr	x1, [x2, #5080]
    54d0:	cb030000 	sub	x0, x0, x3
    54d4:	eb01401f 	cmp	x0, x1, lsl #16
    54d8:	540002c2 	b.cs	5530 <fwp_rc_share+0x70>  // b.hs, b.nlast
    54dc:	d350fc01 	lsr	x1, x0, #16
    54e0:	f949fc44 	ldr	x4, [x2, #5112]
    54e4:	8b010821 	add	x1, x1, x1, lsl #2
    54e8:	d37df021 	lsl	x1, x1, #3
    54ec:	8b010083 	add	x3, x4, x1
    54f0:	f9401062 	ldr	x2, [x3, #32]
    54f4:	b40001e2 	cbz	x2, 5530 <fwp_rc_share+0x70>
    54f8:	38616881 	ldrb	w1, [x4, x1]
    54fc:	7100083f 	cmp	w1, #0x2
    5500:	540001a0 	b.eq	5534 <fwp_rc_share+0x74>  // b.none
    5504:	7100043f 	cmp	w1, #0x1
    5508:	54000141 	b.ne	5530 <fwp_rc_share+0x70>  // b.any
    550c:	29430464 	ldp	w4, w1, [x3, #24]
    5510:	92403c00 	and	x0, x0, #0xffff
    5514:	9b047c00 	mul	x0, x0, x4
    5518:	d360fc00 	lsr	x0, x0, #32
    551c:	eb01001f 	cmp	x0, x1
    5520:	54000082 	b.cs	5530 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5524:	8b000042 	add	x2, x2, x0
    5528:	39400040 	ldrb	w0, [x2]
    552c:	350000a0 	cbnz	w0, 5540 <fwp_rc_share+0x80>
    5530:	d65f03c0 	ret
    5534:	72003c1f 	tst	w0, #0xffff
    5538:	54ffff80 	b.eq	5528 <fwp_rc_share+0x68>  // b.none
    553c:	d65f03c0 	ret
    5540:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5544:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5548:	9110e000 	add	x0, x0, #0x438
    554c:	910003fd 	mov	x29, sp
    5550:	97fff7ec 	bl	3500 <fwp_trap>

0000000000005554 <fwp_rc_fresh>:
    5554:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5558:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    555c:	91154063 	add	x3, x3, #0x550
    5560:	910003fd 	mov	x29, sp
    5564:	a90153f3 	stp	x19, x20, [sp, #16]
    5568:	aa0003f3 	mov	x19, x0
    556c:	f949d861 	ldr	x1, [x3, #5040]
    5570:	f949ec60 	ldr	x0, [x3, #5080]
    5574:	cb010261 	sub	x1, x19, x1
    5578:	eb00403f 	cmp	x1, x0, lsl #16
    557c:	54000322 	b.cs	55e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5580:	d350fc22 	lsr	x2, x1, #16
    5584:	f949fc63 	ldr	x3, [x3, #5112]
    5588:	8b020842 	add	x2, x2, x2, lsl #2
    558c:	d37df042 	lsl	x2, x2, #3
    5590:	8b020060 	add	x0, x3, x2
    5594:	f9401014 	ldr	x20, [x0, #32]
    5598:	b4000254 	cbz	x20, 55e0 <fwp_rc_fresh+0x8c>
    559c:	38626862 	ldrb	w2, [x3, x2]
    55a0:	7100085f 	cmp	w2, #0x2
    55a4:	54000260 	b.eq	55f0 <fwp_rc_fresh+0x9c>  // b.none
    55a8:	7100045f 	cmp	w2, #0x1
    55ac:	540001a1 	b.ne	55e0 <fwp_rc_fresh+0x8c>  // b.any
    55b0:	29430002 	ldp	w2, w0, [x0, #24]
    55b4:	92403c21 	and	x1, x1, #0xffff
    55b8:	9b027c21 	mul	x1, x1, x2
    55bc:	d360fc21 	lsr	x1, x1, #32
    55c0:	eb00003f 	cmp	x1, x0
    55c4:	540000e2 	b.cs	55e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    55c8:	8b010294 	add	x20, x20, x1
    55cc:	39400280 	ldrb	w0, [x20]
    55d0:	7103fc1f 	cmp	w0, #0xff
    55d4:	540001a0 	b.eq	5608 <fwp_rc_fresh+0xb4>  // b.none
    55d8:	52800020 	mov	w0, #0x1                   	// #1
    55dc:	39000280 	strb	w0, [x20]
    55e0:	aa1303e0 	mov	x0, x19
    55e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    55ec:	d65f03c0 	ret
    55f0:	72003c3f 	tst	w1, #0xffff
    55f4:	54fffec0 	b.eq	55cc <fwp_rc_fresh+0x78>  // b.none
    55f8:	aa1303e0 	mov	x0, x19
    55fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5600:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5604:	d65f03c0 	ret
    5608:	aa1403e0 	mov	x0, x20
    560c:	97fffbb9 	bl	44f0 <fwp_rc_forget_slot>
    5610:	17fffff2 	b	55d8 <fwp_rc_fresh+0x84>

0000000000005614 <fwp_rc_free_arr>:
    5614:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5618:	91154063 	add	x3, x3, #0x550
    561c:	f949d861 	ldr	x1, [x3, #5040]
    5620:	f949ec62 	ldr	x2, [x3, #5080]
    5624:	cb010001 	sub	x1, x0, x1
    5628:	eb02403f 	cmp	x1, x2, lsl #16
    562c:	54000342 	b.cs	5694 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5630:	d350fc22 	lsr	x2, x1, #16
    5634:	f949fc65 	ldr	x5, [x3, #5112]
    5638:	8b020842 	add	x2, x2, x2, lsl #2
    563c:	d37df042 	lsl	x2, x2, #3
    5640:	8b0200a4 	add	x4, x5, x2
    5644:	f9401083 	ldr	x3, [x4, #32]
    5648:	b4000263 	cbz	x3, 5694 <fwp_rc_free_arr+0x80>
    564c:	386268a2 	ldrb	w2, [x5, x2]
    5650:	7100085f 	cmp	w2, #0x2
    5654:	540001c0 	b.eq	568c <fwp_rc_free_arr+0x78>  // b.none
    5658:	7100045f 	cmp	w2, #0x1
    565c:	540001c1 	b.ne	5694 <fwp_rc_free_arr+0x80>  // b.any
    5660:	29430885 	ldp	w5, w2, [x4, #24]
    5664:	92403c21 	and	x1, x1, #0xffff
    5668:	9b057c21 	mul	x1, x1, x5
    566c:	d360fc21 	lsr	x1, x1, #32
    5670:	eb02003f 	cmp	x1, x2
    5674:	54000102 	b.cs	5694 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5678:	8b010063 	add	x3, x3, x1
    567c:	39400061 	ldrb	w1, [x3]
    5680:	7100043f 	cmp	w1, #0x1
    5684:	54000081 	b.ne	5694 <fwp_rc_free_arr+0x80>  // b.any
    5688:	17fffc3a 	b	4770 <fwp_mem_free>
    568c:	72003c3f 	tst	w1, #0xffff
    5690:	54ffff60 	b.eq	567c <fwp_rc_free_arr+0x68>  // b.none
    5694:	d65f03c0 	ret
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <fwp_rc_dup>:
    56a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    56a4:	91154042 	add	x2, x2, #0x550
    56a8:	f949d841 	ldr	x1, [x2, #5040]
    56ac:	f949ec43 	ldr	x3, [x2, #5080]
    56b0:	cb010001 	sub	x1, x0, x1
    56b4:	eb03403f 	cmp	x1, x3, lsl #16
    56b8:	54000342 	b.cs	5720 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    56bc:	d350fc20 	lsr	x0, x1, #16
    56c0:	f949fc44 	ldr	x4, [x2, #5112]
    56c4:	8b000800 	add	x0, x0, x0, lsl #2
    56c8:	d37df002 	lsl	x2, x0, #3
    56cc:	8b020083 	add	x3, x4, x2
    56d0:	f9401060 	ldr	x0, [x3, #32]
    56d4:	b4000260 	cbz	x0, 5720 <fwp_rc_dup+0x80>
    56d8:	38626882 	ldrb	w2, [x4, x2]
    56dc:	7100085f 	cmp	w2, #0x2
    56e0:	54000220 	b.eq	5724 <fwp_rc_dup+0x84>  // b.none
    56e4:	7100045f 	cmp	w2, #0x1
    56e8:	540001c1 	b.ne	5720 <fwp_rc_dup+0x80>  // b.any
    56ec:	29430864 	ldp	w4, w2, [x3, #24]
    56f0:	92403c21 	and	x1, x1, #0xffff
    56f4:	9b047c21 	mul	x1, x1, x4
    56f8:	d360fc21 	lsr	x1, x1, #32
    56fc:	eb02003f 	cmp	x1, x2
    5700:	54000102 	b.cs	5720 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5704:	8b010000 	add	x0, x0, x1
    5708:	39400001 	ldrb	w1, [x0]
    570c:	340000a1 	cbz	w1, 5720 <fwp_rc_dup+0x80>
    5710:	7103f43f 	cmp	w1, #0xfd
    5714:	540000e8 	b.hi	5730 <fwp_rc_dup+0x90>  // b.pmore
    5718:	11000421 	add	w1, w1, #0x1
    571c:	39000001 	strb	w1, [x0]
    5720:	d65f03c0 	ret
    5724:	72003c3f 	tst	w1, #0xffff
    5728:	54ffff00 	b.eq	5708 <fwp_rc_dup+0x68>  // b.none
    572c:	d65f03c0 	ret
    5730:	17fffb29 	b	43d4 <fwp_rc_wide_dup>

0000000000005734 <fwp_owned_entry161>:
    5734:	d10103ff 	sub	sp, sp, #0x40
    5738:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    573c:	f947f442 	ldr	x2, [x2, #4072]
    5740:	a9027bfd 	stp	x29, x30, [sp, #32]
    5744:	910083fd 	add	x29, sp, #0x20
    5748:	a90353f3 	stp	x19, x20, [sp, #48]
    574c:	f9400043 	ldr	x3, [x2]
    5750:	f9000fe3 	str	x3, [sp, #24]
    5754:	d2800003 	mov	x3, #0x0                   	// #0
    5758:	a9400c01 	ldp	x1, x3, [x0]
    575c:	f9400802 	ldr	x2, [x0, #16]
    5760:	ab020022 	adds	x2, x1, x2
    5764:	540006e6 	b.vs	5840 <fwp_owned_entry161+0x10c>
    5768:	910023e1 	add	x1, sp, #0x8
    576c:	52800000 	mov	w0, #0x0                   	// #0
    5770:	a9008be3 	stp	x3, x2, [sp, #8]
    5774:	97ffff0b 	bl	53a0 <fwp_data.part.0.constprop.0>
    5778:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    577c:	91154063 	add	x3, x3, #0x550
    5780:	aa0003f3 	mov	x19, x0
    5784:	f949d861 	ldr	x1, [x3, #5040]
    5788:	f949ec60 	ldr	x0, [x3, #5080]
    578c:	cb010261 	sub	x1, x19, x1
    5790:	eb00403f 	cmp	x1, x0, lsl #16
    5794:	54000322 	b.cs	57f8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5798:	d350fc22 	lsr	x2, x1, #16
    579c:	f949fc63 	ldr	x3, [x3, #5112]
    57a0:	8b020842 	add	x2, x2, x2, lsl #2
    57a4:	d37df042 	lsl	x2, x2, #3
    57a8:	8b020060 	add	x0, x3, x2
    57ac:	f9401014 	ldr	x20, [x0, #32]
    57b0:	b4000254 	cbz	x20, 57f8 <fwp_owned_entry161+0xc4>
    57b4:	38626862 	ldrb	w2, [x3, x2]
    57b8:	7100085f 	cmp	w2, #0x2
    57bc:	54000360 	b.eq	5828 <fwp_owned_entry161+0xf4>  // b.none
    57c0:	7100045f 	cmp	w2, #0x1
    57c4:	540001a1 	b.ne	57f8 <fwp_owned_entry161+0xc4>  // b.any
    57c8:	29430002 	ldp	w2, w0, [x0, #24]
    57cc:	92403c21 	and	x1, x1, #0xffff
    57d0:	9b027c21 	mul	x1, x1, x2
    57d4:	d360fc21 	lsr	x1, x1, #32
    57d8:	eb00003f 	cmp	x1, x0
    57dc:	540000e2 	b.cs	57f8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    57e0:	8b010294 	add	x20, x20, x1
    57e4:	39400280 	ldrb	w0, [x20]
    57e8:	7103fc1f 	cmp	w0, #0xff
    57ec:	54000240 	b.eq	5834 <fwp_owned_entry161+0x100>  // b.none
    57f0:	52800020 	mov	w0, #0x1                   	// #1
    57f4:	39000280 	strb	w0, [x20]
    57f8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    57fc:	f947f400 	ldr	x0, [x0, #4072]
    5800:	f9400fe2 	ldr	x2, [sp, #24]
    5804:	f9400001 	ldr	x1, [x0]
    5808:	eb010042 	subs	x2, x2, x1
    580c:	d2800001 	mov	x1, #0x0                   	// #0
    5810:	540001a1 	b.ne	5844 <fwp_owned_entry161+0x110>  // b.any
    5814:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5818:	aa1303e0 	mov	x0, x19
    581c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5820:	910103ff 	add	sp, sp, #0x40
    5824:	d65f03c0 	ret
    5828:	72003c3f 	tst	w1, #0xffff
    582c:	54fffe61 	b.ne	57f8 <fwp_owned_entry161+0xc4>  // b.any
    5830:	17ffffed 	b	57e4 <fwp_owned_entry161+0xb0>
    5834:	aa1403e0 	mov	x0, x20
    5838:	97fffb2e 	bl	44f0 <fwp_rc_forget_slot>
    583c:	17ffffed 	b	57f0 <fwp_owned_entry161+0xbc>
    5840:	97fff470 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5844:	97fff3eb 	bl	27f0 <__stack_chk_fail@plt>
    5848:	d503201f 	nop
    584c:	d503201f 	nop

0000000000005850 <e161>:
    5850:	d10103ff 	sub	sp, sp, #0x40
    5854:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5858:	f947f442 	ldr	x2, [x2, #4072]
    585c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5860:	910083fd 	add	x29, sp, #0x20
    5864:	a90353f3 	stp	x19, x20, [sp, #48]
    5868:	f9400043 	ldr	x3, [x2]
    586c:	f9000fe3 	str	x3, [sp, #24]
    5870:	d2800003 	mov	x3, #0x0                   	// #0
    5874:	a9400c01 	ldp	x1, x3, [x0]
    5878:	f9400802 	ldr	x2, [x0, #16]
    587c:	ab020022 	adds	x2, x1, x2
    5880:	54000726 	b.vs	5964 <e161+0x114>
    5884:	910023e1 	add	x1, sp, #0x8
    5888:	52800000 	mov	w0, #0x0                   	// #0
    588c:	a9008be3 	stp	x3, x2, [sp, #8]
    5890:	97fffec4 	bl	53a0 <fwp_data.part.0.constprop.0>
    5894:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5898:	91154063 	add	x3, x3, #0x550
    589c:	aa0003f3 	mov	x19, x0
    58a0:	f949d861 	ldr	x1, [x3, #5040]
    58a4:	f949ec60 	ldr	x0, [x3, #5080]
    58a8:	cb010261 	sub	x1, x19, x1
    58ac:	eb00403f 	cmp	x1, x0, lsl #16
    58b0:	54000322 	b.cs	5914 <e161+0xc4>  // b.hs, b.nlast
    58b4:	d350fc22 	lsr	x2, x1, #16
    58b8:	f949fc63 	ldr	x3, [x3, #5112]
    58bc:	8b020842 	add	x2, x2, x2, lsl #2
    58c0:	d37df042 	lsl	x2, x2, #3
    58c4:	8b020060 	add	x0, x3, x2
    58c8:	f9401014 	ldr	x20, [x0, #32]
    58cc:	b4000254 	cbz	x20, 5914 <e161+0xc4>
    58d0:	38626862 	ldrb	w2, [x3, x2]
    58d4:	7100085f 	cmp	w2, #0x2
    58d8:	540003a0 	b.eq	594c <e161+0xfc>  // b.none
    58dc:	7100045f 	cmp	w2, #0x1
    58e0:	540001a1 	b.ne	5914 <e161+0xc4>  // b.any
    58e4:	29430002 	ldp	w2, w0, [x0, #24]
    58e8:	92403c21 	and	x1, x1, #0xffff
    58ec:	9b027c21 	mul	x1, x1, x2
    58f0:	d360fc21 	lsr	x1, x1, #32
    58f4:	eb00003f 	cmp	x1, x0
    58f8:	540000e2 	b.cs	5914 <e161+0xc4>  // b.hs, b.nlast
    58fc:	8b010294 	add	x20, x20, x1
    5900:	39400280 	ldrb	w0, [x20]
    5904:	7103fc1f 	cmp	w0, #0xff
    5908:	54000280 	b.eq	5958 <e161+0x108>  // b.none
    590c:	52800020 	mov	w0, #0x1                   	// #1
    5910:	39000280 	strb	w0, [x20]
    5914:	aa1303e0 	mov	x0, x19
    5918:	97fffeea 	bl	54c0 <fwp_rc_share>
    591c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5920:	f947f400 	ldr	x0, [x0, #4072]
    5924:	f9400fe2 	ldr	x2, [sp, #24]
    5928:	f9400001 	ldr	x1, [x0]
    592c:	eb010042 	subs	x2, x2, x1
    5930:	d2800001 	mov	x1, #0x0                   	// #0
    5934:	540001a1 	b.ne	5968 <e161+0x118>  // b.any
    5938:	a9427bfd 	ldp	x29, x30, [sp, #32]
    593c:	aa1303e0 	mov	x0, x19
    5940:	a94353f3 	ldp	x19, x20, [sp, #48]
    5944:	910103ff 	add	sp, sp, #0x40
    5948:	d65f03c0 	ret
    594c:	72003c3f 	tst	w1, #0xffff
    5950:	54fffe21 	b.ne	5914 <e161+0xc4>  // b.any
    5954:	17ffffeb 	b	5900 <e161+0xb0>
    5958:	aa1403e0 	mov	x0, x20
    595c:	97fffae5 	bl	44f0 <fwp_rc_forget_slot>
    5960:	17ffffeb 	b	590c <e161+0xbc>
    5964:	97fff427 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5968:	97fff3a2 	bl	27f0 <__stack_chk_fail@plt>
    596c:	d503201f 	nop

0000000000005970 <fwp_drop1>:
    5970:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5974:	910003fd 	mov	x29, sp
    5978:	a90153f3 	stp	x19, x20, [sp, #16]
    597c:	f90013f5 	str	x21, [sp, #32]
    5980:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5984:	911542b4 	add	x20, x21, #0x550
    5988:	f949da81 	ldr	x1, [x20, #5040]
    598c:	f949ee82 	ldr	x2, [x20, #5080]
    5990:	cb010001 	sub	x1, x0, x1
    5994:	eb02403f 	cmp	x1, x2, lsl #16
    5998:	54000382 	b.cs	5a08 <fwp_drop1+0x98>  // b.hs, b.nlast
    599c:	d350fc22 	lsr	x2, x1, #16
    59a0:	f949fe84 	ldr	x4, [x20, #5112]
    59a4:	8b020842 	add	x2, x2, x2, lsl #2
    59a8:	d37df042 	lsl	x2, x2, #3
    59ac:	8b020083 	add	x3, x4, x2
    59b0:	f9401073 	ldr	x19, [x3, #32]
    59b4:	b40002b3 	cbz	x19, 5a08 <fwp_drop1+0x98>
    59b8:	38626882 	ldrb	w2, [x4, x2]
    59bc:	7100085f 	cmp	w2, #0x2
    59c0:	540002c0 	b.eq	5a18 <fwp_drop1+0xa8>  // b.none
    59c4:	7100045f 	cmp	w2, #0x1
    59c8:	54000201 	b.ne	5a08 <fwp_drop1+0x98>  // b.any
    59cc:	29430864 	ldp	w4, w2, [x3, #24]
    59d0:	92403c21 	and	x1, x1, #0xffff
    59d4:	9b047c21 	mul	x1, x1, x4
    59d8:	d360fc21 	lsr	x1, x1, #32
    59dc:	eb02003f 	cmp	x1, x2
    59e0:	54000142 	b.cs	5a08 <fwp_drop1+0x98>  // b.hs, b.nlast
    59e4:	8b010273 	add	x19, x19, x1
    59e8:	39400261 	ldrb	w1, [x19]
    59ec:	340000e1 	cbz	w1, 5a08 <fwp_drop1+0x98>
    59f0:	7100043f 	cmp	w1, #0x1
    59f4:	540001e0 	b.eq	5a30 <fwp_drop1+0xc0>  // b.none
    59f8:	7103fc3f 	cmp	w1, #0xff
    59fc:	540002e0 	b.eq	5a58 <fwp_drop1+0xe8>  // b.none
    5a00:	51000421 	sub	w1, w1, #0x1
    5a04:	39000261 	strb	w1, [x19]
    5a08:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a0c:	f94013f5 	ldr	x21, [sp, #32]
    5a10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a14:	d65f03c0 	ret
    5a18:	72003c3f 	tst	w1, #0xffff
    5a1c:	54fffe60 	b.eq	59e8 <fwp_drop1+0x78>  // b.none
    5a20:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a24:	f94013f5 	ldr	x21, [sp, #32]
    5a28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a2c:	d65f03c0 	ret
    5a30:	f9400813 	ldr	x19, [x0, #16]
    5a34:	97fffef8 	bl	5614 <fwp_rc_free_arr>
    5a38:	911542a0 	add	x0, x21, #0x550
    5a3c:	f949d801 	ldr	x1, [x0, #5040]
    5a40:	f949ec00 	ldr	x0, [x0, #5080]
    5a44:	cb010261 	sub	x1, x19, x1
    5a48:	eb00403f 	cmp	x1, x0, lsl #16
    5a4c:	54fffde2 	b.cs	5a08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a50:	aa1303e0 	mov	x0, x19
    5a54:	17ffffd2 	b	599c <fwp_drop1+0x2c>
    5a58:	ca534660 	eor	x0, x19, x19, lsr #17
    5a5c:	911542b5 	add	x21, x21, #0x550
    5a60:	ca402400 	eor	x0, x0, x0, lsr #9
    5a64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a68:	f94a2400 	ldr	x0, [x0, #5192]
    5a6c:	b5000080 	cbnz	x0, 5a7c <fwp_drop1+0x10c>
    5a70:	14000010 	b	5ab0 <fwp_drop1+0x140>
    5a74:	f9400800 	ldr	x0, [x0, #16]
    5a78:	b40001c0 	cbz	x0, 5ab0 <fwp_drop1+0x140>
    5a7c:	f9400001 	ldr	x1, [x0]
    5a80:	eb13003f 	cmp	x1, x19
    5a84:	54ffff81 	b.ne	5a74 <fwp_drop1+0x104>  // b.any
    5a88:	f9400401 	ldr	x1, [x0, #8]
    5a8c:	d1000421 	sub	x1, x1, #0x1
    5a90:	f9000401 	str	x1, [x0, #8]
    5a94:	f103f83f 	cmp	x1, #0xfe
    5a98:	54fffb81 	b.ne	5a08 <fwp_drop1+0x98>  // b.any
    5a9c:	aa1303e0 	mov	x0, x19
    5aa0:	97fffa94 	bl	44f0 <fwp_rc_forget_slot>
    5aa4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5aa8:	39000260 	strb	w0, [x19]
    5aac:	17ffffd7 	b	5a08 <fwp_drop1+0x98>
    5ab0:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5ab4:	910ce000 	add	x0, x0, #0x338
    5ab8:	97fff692 	bl	3500 <fwp_trap>
    5abc:	d503201f 	nop

0000000000005ac0 <fwp_drop0>:
    5ac0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ac4:	910003fd 	mov	x29, sp
    5ac8:	a90153f3 	stp	x19, x20, [sp, #16]
    5acc:	f90013f5 	str	x21, [sp, #32]
    5ad0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5ad4:	911542b4 	add	x20, x21, #0x550
    5ad8:	f949da81 	ldr	x1, [x20, #5040]
    5adc:	f949ee82 	ldr	x2, [x20, #5080]
    5ae0:	cb010001 	sub	x1, x0, x1
    5ae4:	eb02403f 	cmp	x1, x2, lsl #16
    5ae8:	54000382 	b.cs	5b58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5aec:	d350fc22 	lsr	x2, x1, #16
    5af0:	f949fe84 	ldr	x4, [x20, #5112]
    5af4:	8b020842 	add	x2, x2, x2, lsl #2
    5af8:	d37df042 	lsl	x2, x2, #3
    5afc:	8b020083 	add	x3, x4, x2
    5b00:	f9401073 	ldr	x19, [x3, #32]
    5b04:	b40002b3 	cbz	x19, 5b58 <fwp_drop0+0x98>
    5b08:	38626882 	ldrb	w2, [x4, x2]
    5b0c:	7100085f 	cmp	w2, #0x2
    5b10:	540002c0 	b.eq	5b68 <fwp_drop0+0xa8>  // b.none
    5b14:	7100045f 	cmp	w2, #0x1
    5b18:	54000201 	b.ne	5b58 <fwp_drop0+0x98>  // b.any
    5b1c:	29430864 	ldp	w4, w2, [x3, #24]
    5b20:	92403c21 	and	x1, x1, #0xffff
    5b24:	9b047c21 	mul	x1, x1, x4
    5b28:	d360fc21 	lsr	x1, x1, #32
    5b2c:	eb02003f 	cmp	x1, x2
    5b30:	54000142 	b.cs	5b58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b34:	8b010273 	add	x19, x19, x1
    5b38:	39400261 	ldrb	w1, [x19]
    5b3c:	340000e1 	cbz	w1, 5b58 <fwp_drop0+0x98>
    5b40:	7100043f 	cmp	w1, #0x1
    5b44:	540001e0 	b.eq	5b80 <fwp_drop0+0xc0>  // b.none
    5b48:	7103fc3f 	cmp	w1, #0xff
    5b4c:	540002e0 	b.eq	5ba8 <fwp_drop0+0xe8>  // b.none
    5b50:	51000421 	sub	w1, w1, #0x1
    5b54:	39000261 	strb	w1, [x19]
    5b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b5c:	f94013f5 	ldr	x21, [sp, #32]
    5b60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b64:	d65f03c0 	ret
    5b68:	72003c3f 	tst	w1, #0xffff
    5b6c:	54fffe60 	b.eq	5b38 <fwp_drop0+0x78>  // b.none
    5b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b74:	f94013f5 	ldr	x21, [sp, #32]
    5b78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b7c:	d65f03c0 	ret
    5b80:	f9400813 	ldr	x19, [x0, #16]
    5b84:	97fffea4 	bl	5614 <fwp_rc_free_arr>
    5b88:	911542a0 	add	x0, x21, #0x550
    5b8c:	f949d801 	ldr	x1, [x0, #5040]
    5b90:	f949ec00 	ldr	x0, [x0, #5080]
    5b94:	cb010261 	sub	x1, x19, x1
    5b98:	eb00403f 	cmp	x1, x0, lsl #16
    5b9c:	54fffde2 	b.cs	5b58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ba0:	aa1303e0 	mov	x0, x19
    5ba4:	17ffffd2 	b	5aec <fwp_drop0+0x2c>
    5ba8:	ca534660 	eor	x0, x19, x19, lsr #17
    5bac:	911542b5 	add	x21, x21, #0x550
    5bb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5bb4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5bb8:	f94a2400 	ldr	x0, [x0, #5192]
    5bbc:	b5000080 	cbnz	x0, 5bcc <fwp_drop0+0x10c>
    5bc0:	14000010 	b	5c00 <fwp_drop0+0x140>
    5bc4:	f9400800 	ldr	x0, [x0, #16]
    5bc8:	b40001c0 	cbz	x0, 5c00 <fwp_drop0+0x140>
    5bcc:	f9400001 	ldr	x1, [x0]
    5bd0:	eb13003f 	cmp	x1, x19
    5bd4:	54ffff81 	b.ne	5bc4 <fwp_drop0+0x104>  // b.any
    5bd8:	f9400401 	ldr	x1, [x0, #8]
    5bdc:	d1000421 	sub	x1, x1, #0x1
    5be0:	f9000401 	str	x1, [x0, #8]
    5be4:	f103f83f 	cmp	x1, #0xfe
    5be8:	54fffb81 	b.ne	5b58 <fwp_drop0+0x98>  // b.any
    5bec:	aa1303e0 	mov	x0, x19
    5bf0:	97fffa40 	bl	44f0 <fwp_rc_forget_slot>
    5bf4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bf8:	39000260 	strb	w0, [x19]
    5bfc:	17ffffd7 	b	5b58 <fwp_drop0+0x98>
    5c00:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5c04:	910ce000 	add	x0, x0, #0x338
    5c08:	97fff63e 	bl	3500 <fwp_trap>
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_arg_drop12>:
    5c10:	7100003f 	cmp	w1, #0x0
    5c14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5c18:	54000041 	b.ne	5c20 <fwp_arg_drop12+0x10>  // b.any
    5c1c:	d65f03c0 	ret
    5c20:	f9400000 	ldr	x0, [x0]
    5c24:	17ffffa7 	b	5ac0 <fwp_drop0>
    5c28:	d503201f 	nop
    5c2c:	d503201f 	nop

0000000000005c30 <fwp_closure_drop>:
    5c30:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5c34:	911540a4 	add	x4, x5, #0x550
    5c38:	aa0003e1 	mov	x1, x0
    5c3c:	f949d882 	ldr	x2, [x4, #5040]
    5c40:	f949ec80 	ldr	x0, [x4, #5080]
    5c44:	cb020022 	sub	x2, x1, x2
    5c48:	eb00405f 	cmp	x2, x0, lsl #16
    5c4c:	54000662 	b.cs	5d18 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5c50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5c54:	d350fc43 	lsr	x3, x2, #16
    5c58:	910003fd 	mov	x29, sp
    5c5c:	8b030863 	add	x3, x3, x3, lsl #2
    5c60:	f949fc84 	ldr	x4, [x4, #5112]
    5c64:	d37df063 	lsl	x3, x3, #3
    5c68:	f9000bf3 	str	x19, [sp, #16]
    5c6c:	8b030080 	add	x0, x4, x3
    5c70:	f9401013 	ldr	x19, [x0, #32]
    5c74:	b40002b3 	cbz	x19, 5cc8 <fwp_closure_drop+0x98>
    5c78:	38636883 	ldrb	w3, [x4, x3]
    5c7c:	7100087f 	cmp	w3, #0x2
    5c80:	54000420 	b.eq	5d04 <fwp_closure_drop+0xd4>  // b.none
    5c84:	7100047f 	cmp	w3, #0x1
    5c88:	54000201 	b.ne	5cc8 <fwp_closure_drop+0x98>  // b.any
    5c8c:	29430003 	ldp	w3, w0, [x0, #24]
    5c90:	92403c42 	and	x2, x2, #0xffff
    5c94:	9b037c42 	mul	x2, x2, x3
    5c98:	d360fc42 	lsr	x2, x2, #32
    5c9c:	eb00005f 	cmp	x2, x0
    5ca0:	54000142 	b.cs	5cc8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5ca4:	8b020273 	add	x19, x19, x2
    5ca8:	39400260 	ldrb	w0, [x19]
    5cac:	340000e0 	cbz	w0, 5cc8 <fwp_closure_drop+0x98>
    5cb0:	7100041f 	cmp	w0, #0x1
    5cb4:	54000100 	b.eq	5cd4 <fwp_closure_drop+0xa4>  // b.none
    5cb8:	7103fc1f 	cmp	w0, #0xff
    5cbc:	54000300 	b.eq	5d1c <fwp_closure_drop+0xec>  // b.none
    5cc0:	51000400 	sub	w0, w0, #0x1
    5cc4:	39000260 	strb	w0, [x19]
    5cc8:	f9400bf3 	ldr	x19, [sp, #16]
    5ccc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cd0:	d65f03c0 	ret
    5cd4:	d53bd040 	mrs	x0, tpidr_el0
    5cd8:	91400000 	add	x0, x0, #0x0, lsl #12
    5cdc:	91004000 	add	x0, x0, #0x10
    5ce0:	f9400000 	ldr	x0, [x0]
    5ce4:	b4000080 	cbz	x0, 5cf4 <fwp_closure_drop+0xc4>
    5ce8:	f9400bf3 	ldr	x19, [sp, #16]
    5cec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cf0:	17fff61d 	b	3564 <fwp_closure_drop_push>
    5cf4:	f9400bf3 	ldr	x19, [sp, #16]
    5cf8:	aa0103e0 	mov	x0, x1
    5cfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d00:	17fff688 	b	3720 <fwp_closure_drop.part.0>
    5d04:	72003c5f 	tst	w2, #0xffff
    5d08:	54fffd00 	b.eq	5ca8 <fwp_closure_drop+0x78>  // b.none
    5d0c:	f9400bf3 	ldr	x19, [sp, #16]
    5d10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d14:	d65f03c0 	ret
    5d18:	d65f03c0 	ret
    5d1c:	ca534660 	eor	x0, x19, x19, lsr #17
    5d20:	911540a5 	add	x5, x5, #0x550
    5d24:	ca402400 	eor	x0, x0, x0, lsr #9
    5d28:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5d2c:	f94a2400 	ldr	x0, [x0, #5192]
    5d30:	b5000080 	cbnz	x0, 5d40 <fwp_closure_drop+0x110>
    5d34:	14000010 	b	5d74 <fwp_closure_drop+0x144>
    5d38:	f9400800 	ldr	x0, [x0, #16]
    5d3c:	b40001c0 	cbz	x0, 5d74 <fwp_closure_drop+0x144>
    5d40:	f9400001 	ldr	x1, [x0]
    5d44:	eb13003f 	cmp	x1, x19
    5d48:	54ffff81 	b.ne	5d38 <fwp_closure_drop+0x108>  // b.any
    5d4c:	f9400401 	ldr	x1, [x0, #8]
    5d50:	d1000421 	sub	x1, x1, #0x1
    5d54:	f9000401 	str	x1, [x0, #8]
    5d58:	f103f83f 	cmp	x1, #0xfe
    5d5c:	54fffb61 	b.ne	5cc8 <fwp_closure_drop+0x98>  // b.any
    5d60:	aa1303e0 	mov	x0, x19
    5d64:	97fff9e3 	bl	44f0 <fwp_rc_forget_slot>
    5d68:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d6c:	39000260 	strb	w0, [x19]
    5d70:	17ffffd6 	b	5cc8 <fwp_closure_drop+0x98>
    5d74:	90000040 	adrp	x0, d000 <__modti3+0x310>
    5d78:	910ce000 	add	x0, x0, #0x338
    5d7c:	97fff5e1 	bl	3500 <fwp_trap>

0000000000005d80 <fwp_owned_tape_release>:
    5d80:	b4000940 	cbz	x0, 5ea8 <fwp_owned_tape_release+0x128>
    5d84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d88:	910003fd 	mov	x29, sp
    5d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    5d90:	aa0003f3 	mov	x19, x0
    5d94:	f9400000 	ldr	x0, [x0]
    5d98:	b4000060 	cbz	x0, 5da4 <fwp_owned_tape_release+0x24>
    5d9c:	f9400661 	ldr	x1, [x19, #8]
    5da0:	f9000401 	str	x1, [x0, #8]
    5da4:	f9400661 	ldr	x1, [x19, #8]
    5da8:	b4000041 	cbz	x1, 5db0 <fwp_owned_tape_release+0x30>
    5dac:	f9000020 	str	x0, [x1]
    5db0:	f9400a60 	ldr	x0, [x19, #16]
    5db4:	f9403401 	ldr	x1, [x0, #104]
    5db8:	b40005c1 	cbz	x1, 5e70 <fwp_owned_tape_release+0xf0>
    5dbc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5dc0:	eb00005f 	cmp	x2, x0
    5dc4:	540002ed 	b.le	5e20 <fwp_owned_tape_release+0xa0>
    5dc8:	d2800014 	mov	x20, #0x0                   	// #0
    5dcc:	f90013f5 	str	x21, [sp, #32]
    5dd0:	d2800015 	mov	x21, #0x0                   	// #0
    5dd4:	d503201f 	nop
    5dd8:	f9402260 	ldr	x0, [x19, #64]
    5ddc:	910006b5 	add	x21, x21, #0x1
    5de0:	f8746800 	ldr	x0, [x0, x20]
    5de4:	d63f0020 	blr	x1
    5de8:	f9402260 	ldr	x0, [x19, #64]
    5dec:	f9400a61 	ldr	x1, [x19, #16]
    5df0:	8b140000 	add	x0, x0, x20
    5df4:	91004294 	add	x20, x20, #0x10
    5df8:	f9400400 	ldr	x0, [x0, #8]
    5dfc:	f9403421 	ldr	x1, [x1, #104]
    5e00:	d63f0020 	blr	x1
    5e04:	a9450261 	ldp	x1, x0, [x19, #80]
    5e08:	cb010000 	sub	x0, x0, x1
    5e0c:	eb15001f 	cmp	x0, x21
    5e10:	f9400a60 	ldr	x0, [x19, #16]
    5e14:	f9403401 	ldr	x1, [x0, #104]
    5e18:	54fffe0c 	b.gt	5dd8 <fwp_owned_tape_release+0x58>
    5e1c:	f94013f5 	ldr	x21, [sp, #32]
    5e20:	f9403663 	ldr	x3, [x19, #104]
    5e24:	f9401262 	ldr	x2, [x19, #32]
    5e28:	f100007f 	cmp	x3, #0x0
    5e2c:	540001ed 	b.le	5e68 <fwp_owned_tape_release+0xe8>
    5e30:	d2800014 	mov	x20, #0x0                   	// #0
    5e34:	d503201f 	nop
    5e38:	f9402660 	ldr	x0, [x19, #72]
    5e3c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5e40:	eb02001f 	cmp	x0, x2
    5e44:	540000c0 	b.eq	5e5c <fwp_owned_tape_release+0xdc>  // b.none
    5e48:	d63f0020 	blr	x1
    5e4c:	f9400a60 	ldr	x0, [x19, #16]
    5e50:	f9401262 	ldr	x2, [x19, #32]
    5e54:	f9403663 	ldr	x3, [x19, #104]
    5e58:	f9403401 	ldr	x1, [x0, #104]
    5e5c:	91000694 	add	x20, x20, #0x1
    5e60:	eb14007f 	cmp	x3, x20
    5e64:	54fffeac 	b.gt	5e38 <fwp_owned_tape_release+0xb8>
    5e68:	aa0203e0 	mov	x0, x2
    5e6c:	d63f0020 	blr	x1
    5e70:	f9401660 	ldr	x0, [x19, #40]
    5e74:	97ffff6f 	bl	5c30 <fwp_closure_drop>
    5e78:	f9401a60 	ldr	x0, [x19, #48]
    5e7c:	97ffff6d 	bl	5c30 <fwp_closure_drop>
    5e80:	f9401e60 	ldr	x0, [x19, #56]
    5e84:	97ffff6b 	bl	5c30 <fwp_closure_drop>
    5e88:	f9402260 	ldr	x0, [x19, #64]
    5e8c:	97fffa39 	bl	4770 <fwp_mem_free>
    5e90:	f9402660 	ldr	x0, [x19, #72]
    5e94:	97fffa37 	bl	4770 <fwp_mem_free>
    5e98:	aa1303e0 	mov	x0, x19
    5e9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ea0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ea4:	17fffa33 	b	4770 <fwp_mem_free>
    5ea8:	d65f03c0 	ret
    5eac:	d503201f 	nop

0000000000005eb0 <fwp_tape_finish>:
    5eb0:	d10203ff 	sub	sp, sp, #0x80
    5eb4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5eb8:	f947f421 	ldr	x1, [x1, #4072]
    5ebc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ec0:	910103fd 	add	x29, sp, #0x40
    5ec4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ec8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5ecc:	a90763f7 	stp	x23, x24, [sp, #112]
    5ed0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5ed4:	91010316 	add	x22, x24, #0x40
    5ed8:	f9400022 	ldr	x2, [x1]
    5edc:	f9001fe2 	str	x2, [sp, #56]
    5ee0:	d2800002 	mov	x2, #0x0                   	// #0
    5ee4:	910122c0 	add	x0, x22, #0x48
    5ee8:	97fff4e6 	bl	3280 <fwp_tape_buffers_dispose>
    5eec:	f90042df 	str	xzr, [x22, #128]
    5ef0:	f94022c0 	ldr	x0, [x22, #64]
    5ef4:	f100001f 	cmp	x0, #0x0
    5ef8:	5400030d 	b.le	5f58 <fwp_tape_finish+0xa8>
    5efc:	910003f7 	mov	x23, sp
    5f00:	d2800015 	mov	x21, #0x0                   	// #0
    5f04:	d2800014 	mov	x20, #0x0                   	// #0
    5f08:	f94002d3 	ldr	x19, [x22]
    5f0c:	91000694 	add	x20, x20, #0x1
    5f10:	8b150273 	add	x19, x19, x21
    5f14:	9101a2b5 	add	x21, x21, #0x68
    5f18:	aa1303e0 	mov	x0, x19
    5f1c:	97fff3fd 	bl	2f10 <fwp_tape_unlink_scope>
    5f20:	aa1703e0 	mov	x0, x23
    5f24:	f9401261 	ldr	x1, [x19, #32]
    5f28:	f90003e1 	str	x1, [sp]
    5f2c:	f9401a62 	ldr	x2, [x19, #48]
    5f30:	f9000be2 	str	x2, [sp, #16]
    5f34:	f9402261 	ldr	x1, [x19, #64]
    5f38:	f90013e1 	str	x1, [sp, #32]
    5f3c:	97fff4d1 	bl	3280 <fwp_tape_buffers_dispose>
    5f40:	f9403260 	ldr	x0, [x19, #96]
    5f44:	97ffff8f 	bl	5d80 <fwp_owned_tape_release>
    5f48:	f900327f 	str	xzr, [x19, #96]
    5f4c:	f94022c0 	ldr	x0, [x22, #64]
    5f50:	eb14001f 	cmp	x0, x20
    5f54:	54fffdac 	b.gt	5f08 <fwp_tape_finish+0x58>
    5f58:	f9402300 	ldr	x0, [x24, #64]
    5f5c:	91010313 	add	x19, x24, #0x40
    5f60:	97fff254 	bl	28b0 <free@plt>
    5f64:	f900231f 	str	xzr, [x24, #64]
    5f68:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5f6c:	f947f400 	ldr	x0, [x0, #4072]
    5f70:	f900227f 	str	xzr, [x19, #64]
    5f74:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5f78:	f9401fe2 	ldr	x2, [sp, #56]
    5f7c:	f9400001 	ldr	x1, [x0]
    5f80:	eb010042 	subs	x2, x2, x1
    5f84:	d2800001 	mov	x1, #0x0                   	// #0
    5f88:	540000e1 	b.ne	5fa4 <fwp_tape_finish+0xf4>  // b.any
    5f8c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f90:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f94:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5f98:	a94763f7 	ldp	x23, x24, [sp, #112]
    5f9c:	910203ff 	add	sp, sp, #0x80
    5fa0:	d65f03c0 	ret
    5fa4:	97fff213 	bl	27f0 <__stack_chk_fail@plt>
    5fa8:	d503201f 	nop
    5fac:	d503201f 	nop

0000000000005fb0 <fwp_tape_scope_release>:
    5fb0:	d10243ff 	sub	sp, sp, #0x90
    5fb4:	a9047bfd 	stp	x29, x30, [sp, #64]
    5fb8:	910103fd 	add	x29, sp, #0x40
    5fbc:	a90553f3 	stp	x19, x20, [sp, #80]
    5fc0:	aa0003f4 	mov	x20, x0
    5fc4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5fc8:	f947f400 	ldr	x0, [x0, #4072]
    5fcc:	b9400285 	ldr	w5, [x20]
    5fd0:	f9400001 	ldr	x1, [x0]
    5fd4:	f9001fe1 	str	x1, [sp, #56]
    5fd8:	d2800001 	mov	x1, #0x0                   	// #0
    5fdc:	37f806c5 	tbnz	w5, #31, 60b4 <fwp_tape_scope_release+0x104>
    5fe0:	a90763f7 	stp	x23, x24, [sp, #112]
    5fe4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5fe8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5fec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5ff0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5ff4:	910003f7 	mov	x23, sp
    5ff8:	91010273 	add	x19, x19, #0x40
    5ffc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6000:	a9065bf5 	stp	x21, x22, [sp, #96]
    6004:	52800d16 	mov	w22, #0x68                  	// #104
    6008:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    600c:	f90043f9 	str	x25, [sp, #128]
    6010:	14000006 	b	6028 <fwp_tape_scope_release+0x78>
    6014:	97fff49b 	bl	3280 <fwp_tape_buffers_dispose>
    6018:	aa1903e0 	mov	x0, x25
    601c:	97ffff59 	bl	5d80 <fwp_owned_tape_release>
    6020:	b9400285 	ldr	w5, [x20]
    6024:	37f80425 	tbnz	w5, #31, 60a8 <fwp_tape_scope_release+0xf8>
    6028:	f9400266 	ldr	x6, [x19]
    602c:	9b367ca5 	smull	x5, w5, w22
    6030:	8b0500c0 	add	x0, x6, x5
    6034:	97fff3b7 	bl	2f10 <fwp_tape_unlink_scope>
    6038:	ad410001 	ldp	q1, q0, [x0, #32]
    603c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6040:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6044:	f9400c03 	ldr	x3, [x0, #24]
    6048:	ad0003e1 	stp	q1, q0, [sp]
    604c:	b86568c1 	ldr	w1, [x6, x5]
    6050:	a9440804 	ldp	x4, x2, [x0, #64]
    6054:	b900041f 	str	wzr, [x0, #4]
    6058:	f9403019 	ldr	x25, [x0, #96]
    605c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6060:	f9000c1f 	str	xzr, [x0, #24]
    6064:	a9020fe4 	stp	x4, x3, [sp, #32]
    6068:	f9001be2 	str	x2, [sp, #48]
    606c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6070:	f900301f 	str	xzr, [x0, #96]
    6074:	6b15003f 	cmp	w1, w21
    6078:	540000e8 	b.hi	6094 <fwp_tape_scope_release+0xe4>  // b.pmore
    607c:	9343fca5 	asr	x5, x5, #3
    6080:	f9404e60 	ldr	x0, [x19, #152]
    6084:	9b187ca5 	mul	x5, x5, x24
    6088:	eb0000bf 	cmp	x5, x0
    608c:	5400004a 	b.ge	6094 <fwp_tape_scope_release+0xe4>  // b.tcont
    6090:	f9004e65 	str	x5, [x19, #152]
    6094:	aa1703e0 	mov	x0, x23
    6098:	b5fffbf9 	cbnz	x25, 6014 <fwp_tape_scope_release+0x64>
    609c:	97fff7f9 	bl	4080 <fwp_tape_buffers_release>
    60a0:	b9400285 	ldr	w5, [x20]
    60a4:	36fffc25 	tbz	w5, #31, 6028 <fwp_tape_scope_release+0x78>
    60a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    60b0:	f94043f9 	ldr	x25, [sp, #128]
    60b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    60b8:	f947f400 	ldr	x0, [x0, #4072]
    60bc:	f9401fe2 	ldr	x2, [sp, #56]
    60c0:	f9400001 	ldr	x1, [x0]
    60c4:	eb010042 	subs	x2, x2, x1
    60c8:	d2800001 	mov	x1, #0x0                   	// #0
    60cc:	540000a1 	b.ne	60e0 <fwp_tape_scope_release+0x130>  // b.any
    60d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    60d8:	910243ff 	add	sp, sp, #0x90
    60dc:	d65f03c0 	ret
    60e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60e4:	a90763f7 	stp	x23, x24, [sp, #112]
    60e8:	f90043f9 	str	x25, [sp, #128]
    60ec:	97fff1c1 	bl	27f0 <__stack_chk_fail@plt>

00000000000060f0 <fwp_task_dispose>:
    60f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60f4:	910003fd 	mov	x29, sp
    60f8:	f9000bf3 	str	x19, [sp, #16]
    60fc:	aa0003f3 	mov	x19, x0
    6100:	39414000 	ldrb	w0, [x0, #80]
    6104:	36000720 	tbz	w0, #0, 61e8 <fwp_task_dispose+0xf8>
    6108:	f9400a60 	ldr	x0, [x19, #16]
    610c:	b50006e0 	cbnz	x0, 61e8 <fwp_task_dispose+0xf8>
    6110:	a9478660 	ldp	x0, x1, [x19, #120]
    6114:	39014e7f 	strb	wzr, [x19, #83]
    6118:	f9003e7f 	str	xzr, [x19, #120]
    611c:	f100003f 	cmp	x1, #0x0
    6120:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6124:	54000040 	b.eq	612c <fwp_task_dispose+0x3c>  // b.none
    6128:	d63f0020 	blr	x1
    612c:	f9405660 	ldr	x0, [x19, #168]
    6130:	97fff990 	bl	4770 <fwp_mem_free>
    6134:	f900567f 	str	xzr, [x19, #168]
    6138:	b9405e60 	ldr	w0, [x19, #92]
    613c:	7100041f 	cmp	w0, #0x1
    6140:	54000420 	b.eq	61c4 <fwp_task_dispose+0xd4>  // b.none
    6144:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6148:	91154042 	add	x2, x2, #0x550
    614c:	f949d840 	ldr	x0, [x2, #5040]
    6150:	f949ec41 	ldr	x1, [x2, #5080]
    6154:	cb000260 	sub	x0, x19, x0
    6158:	eb01401f 	cmp	x0, x1, lsl #16
    615c:	540002e2 	b.cs	61b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6160:	d350fc01 	lsr	x1, x0, #16
    6164:	f949fc44 	ldr	x4, [x2, #5112]
    6168:	8b010821 	add	x1, x1, x1, lsl #2
    616c:	d37df021 	lsl	x1, x1, #3
    6170:	8b010083 	add	x3, x4, x1
    6174:	f9401062 	ldr	x2, [x3, #32]
    6178:	b4000202 	cbz	x2, 61b8 <fwp_task_dispose+0xc8>
    617c:	38616881 	ldrb	w1, [x4, x1]
    6180:	7100083f 	cmp	w1, #0x2
    6184:	54000280 	b.eq	61d4 <fwp_task_dispose+0xe4>  // b.none
    6188:	7100043f 	cmp	w1, #0x1
    618c:	54000161 	b.ne	61b8 <fwp_task_dispose+0xc8>  // b.any
    6190:	29430464 	ldp	w4, w1, [x3, #24]
    6194:	92403c00 	and	x0, x0, #0xffff
    6198:	9b047c00 	mul	x0, x0, x4
    619c:	d360fc00 	lsr	x0, x0, #32
    61a0:	eb01001f 	cmp	x0, x1
    61a4:	540000a2 	b.cs	61b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    61a8:	8b000042 	add	x2, x2, x0
    61ac:	39400040 	ldrb	w0, [x2]
    61b0:	7100041f 	cmp	w0, #0x1
    61b4:	54000080 	b.eq	61c4 <fwp_task_dispose+0xd4>  // b.none
    61b8:	f9400bf3 	ldr	x19, [sp, #16]
    61bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c0:	d65f03c0 	ret
    61c4:	aa1303e0 	mov	x0, x19
    61c8:	f9400bf3 	ldr	x19, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	17fff968 	b	4770 <fwp_mem_free>
    61d4:	72003c1f 	tst	w0, #0xffff
    61d8:	54fffea0 	b.eq	61ac <fwp_task_dispose+0xbc>  // b.none
    61dc:	f9400bf3 	ldr	x19, [sp, #16]
    61e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e4:	d65f03c0 	ret
    61e8:	97fff196 	bl	2840 <abort@plt>
    61ec:	d503201f 	nop

00000000000061f0 <fwp_free_zombie>:
    61f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61f4:	910003fd 	mov	x29, sp
    61f8:	a90153f3 	stp	x19, x20, [sp, #16]
    61fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6200:	91010281 	add	x1, x20, #0x40
    6204:	f9405033 	ldr	x19, [x1, #160]
    6208:	b4000333 	cbz	x19, 626c <fwp_free_zombie+0x7c>
    620c:	f9400820 	ldr	x0, [x1, #16]
    6210:	eb00027f 	cmp	x19, x0
    6214:	540002c0 	b.eq	626c <fwp_free_zombie+0x7c>  // b.none
    6218:	b940a822 	ldr	w2, [x1, #168]
    621c:	f9400a60 	ldr	x0, [x19, #16]
    6220:	7100fc5f 	cmp	w2, #0x3f
    6224:	5400078c 	b.gt	6314 <fwp_free_zombie+0x124>
    6228:	9102c023 	add	x3, x1, #0xb0
    622c:	11000444 	add	w4, w2, #0x1
    6230:	b900a824 	str	w4, [x1, #168]
    6234:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6238:	f822d860 	str	x0, [x3, w2, sxtw #3]
    623c:	a9530261 	ldp	x1, x0, [x19, #304]
    6240:	b4000741 	cbz	x1, 6328 <fwp_free_zombie+0x138>
    6244:	f9009c20 	str	x0, [x1, #312]
    6248:	b4000040 	cbz	x0, 6250 <fwp_free_zombie+0x60>
    624c:	f9009801 	str	x1, [x0, #304]
    6250:	91010294 	add	x20, x20, #0x40
    6254:	b9405e60 	ldr	w0, [x19, #92]
    6258:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    625c:	f900529f 	str	xzr, [x20, #160]
    6260:	34000140 	cbz	w0, 6288 <fwp_free_zombie+0x98>
    6264:	7100041f 	cmp	w0, #0x1
    6268:	54000080 	b.eq	6278 <fwp_free_zombie+0x88>  // b.none
    626c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6270:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6274:	d65f03c0 	ret
    6278:	aa1303e0 	mov	x0, x19
    627c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6284:	17ffff9b 	b	60f0 <fwp_task_dispose>
    6288:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    628c:	91154082 	add	x2, x4, #0x550
    6290:	f949d841 	ldr	x1, [x2, #5040]
    6294:	f949ec40 	ldr	x0, [x2, #5080]
    6298:	cb010261 	sub	x1, x19, x1
    629c:	eb00403f 	cmp	x1, x0, lsl #16
    62a0:	54fffe62 	b.cs	626c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62a4:	d350fc20 	lsr	x0, x1, #16
    62a8:	f949fc43 	ldr	x3, [x2, #5112]
    62ac:	8b000800 	add	x0, x0, x0, lsl #2
    62b0:	d37df000 	lsl	x0, x0, #3
    62b4:	8b000062 	add	x2, x3, x0
    62b8:	f9401054 	ldr	x20, [x2, #32]
    62bc:	b4fffd94 	cbz	x20, 626c <fwp_free_zombie+0x7c>
    62c0:	38606860 	ldrb	w0, [x3, x0]
    62c4:	7100081f 	cmp	w0, #0x2
    62c8:	54000360 	b.eq	6334 <fwp_free_zombie+0x144>  // b.none
    62cc:	7100041f 	cmp	w0, #0x1
    62d0:	54fffce1 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    62d4:	29430043 	ldp	w3, w0, [x2, #24]
    62d8:	92403c21 	and	x1, x1, #0xffff
    62dc:	9b037c21 	mul	x1, x1, x3
    62e0:	d360fc21 	lsr	x1, x1, #32
    62e4:	eb00003f 	cmp	x1, x0
    62e8:	54fffc22 	b.cs	626c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62ec:	8b010294 	add	x20, x20, x1
    62f0:	39400280 	ldrb	w0, [x20]
    62f4:	34fffbc0 	cbz	w0, 626c <fwp_free_zombie+0x7c>
    62f8:	7100041f 	cmp	w0, #0x1
    62fc:	54fffbe0 	b.eq	6278 <fwp_free_zombie+0x88>  // b.none
    6300:	7103fc1f 	cmp	w0, #0xff
    6304:	540001e0 	b.eq	6340 <fwp_free_zombie+0x150>  // b.none
    6308:	51000400 	sub	w0, w0, #0x1
    630c:	39000280 	strb	w0, [x20]
    6310:	17ffffd7 	b	626c <fwp_free_zombie+0x7c>
    6314:	f9400e61 	ldr	x1, [x19, #24]
    6318:	97fff17e 	bl	2910 <munmap@plt>
    631c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6320:	a9530261 	ldp	x1, x0, [x19, #304]
    6324:	b5fff901 	cbnz	x1, 6244 <fwp_free_zombie+0x54>
    6328:	91010282 	add	x2, x20, #0x40
    632c:	f9015840 	str	x0, [x2, #688]
    6330:	17ffffc6 	b	6248 <fwp_free_zombie+0x58>
    6334:	72003c3f 	tst	w1, #0xffff
    6338:	54fff9a1 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    633c:	17ffffed 	b	62f0 <fwp_free_zombie+0x100>
    6340:	ca544680 	eor	x0, x20, x20, lsr #17
    6344:	91154084 	add	x4, x4, #0x550
    6348:	ca402400 	eor	x0, x0, x0, lsr #9
    634c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6350:	f94a2400 	ldr	x0, [x0, #5192]
    6354:	b5000080 	cbnz	x0, 6364 <fwp_free_zombie+0x174>
    6358:	14000010 	b	6398 <fwp_free_zombie+0x1a8>
    635c:	f9400800 	ldr	x0, [x0, #16]
    6360:	b40001c0 	cbz	x0, 6398 <fwp_free_zombie+0x1a8>
    6364:	f9400001 	ldr	x1, [x0]
    6368:	eb14003f 	cmp	x1, x20
    636c:	54ffff81 	b.ne	635c <fwp_free_zombie+0x16c>  // b.any
    6370:	f9400401 	ldr	x1, [x0, #8]
    6374:	d1000421 	sub	x1, x1, #0x1
    6378:	f9000401 	str	x1, [x0, #8]
    637c:	f103f83f 	cmp	x1, #0xfe
    6380:	54fff761 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    6384:	aa1403e0 	mov	x0, x20
    6388:	97fff85a 	bl	44f0 <fwp_rc_forget_slot>
    638c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6390:	39000280 	strb	w0, [x20]
    6394:	17ffffb6 	b	626c <fwp_free_zombie+0x7c>
    6398:	f0000020 	adrp	x0, d000 <__modti3+0x310>
    639c:	910ce000 	add	x0, x0, #0x338
    63a0:	97fff458 	bl	3500 <fwp_trap>

00000000000063a4 <fwp_block>:
    63a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63a8:	910003fd 	mov	x29, sp
    63ac:	a90153f3 	stp	x19, x20, [sp, #16]
    63b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    63b4:	91010274 	add	x20, x19, #0x40
    63b8:	f9401a82 	ldr	x2, [x20, #48]
    63bc:	b4000622 	cbz	x2, 6480 <fwp_block+0xdc>
    63c0:	91010261 	add	x1, x19, #0x40
    63c4:	f9408040 	ldr	x0, [x2, #256]
    63c8:	f9001820 	str	x0, [x1, #48]
    63cc:	b4000680 	cbz	x0, 649c <fwp_block+0xf8>
    63d0:	91010263 	add	x3, x19, #0x40
    63d4:	3901505f 	strb	wzr, [x2, #84]
    63d8:	f9400864 	ldr	x4, [x3, #16]
    63dc:	eb02009f 	cmp	x4, x2
    63e0:	54000440 	b.eq	6468 <fwp_block+0xc4>  // b.none
    63e4:	f9415c65 	ldr	x5, [x3, #696]
    63e8:	f9000862 	str	x2, [x3, #16]
    63ec:	f9400441 	ldr	x1, [x2, #8]
    63f0:	f9004885 	str	x5, [x4, #144]
    63f4:	f9416065 	ldr	x5, [x3, #704]
    63f8:	f9004c85 	str	x5, [x4, #152]
    63fc:	f9416465 	ldr	x5, [x3, #712]
    6400:	f9005085 	str	x5, [x4, #160]
    6404:	f9416865 	ldr	x5, [x3, #720]
    6408:	f9005485 	str	x5, [x4, #168]
    640c:	f9416c65 	ldr	x5, [x3, #728]
    6410:	f9005885 	str	x5, [x4, #176]
    6414:	f9417065 	ldr	x5, [x3, #736]
    6418:	f9005c85 	str	x5, [x4, #184]
    641c:	f9417465 	ldr	x5, [x3, #744]
    6420:	f9006085 	str	x5, [x4, #192]
    6424:	f9400480 	ldr	x0, [x4, #8]
    6428:	f9404844 	ldr	x4, [x2, #144]
    642c:	f9015c64 	str	x4, [x3, #696]
    6430:	f9404c44 	ldr	x4, [x2, #152]
    6434:	f9016064 	str	x4, [x3, #704]
    6438:	f9405044 	ldr	x4, [x2, #160]
    643c:	f9016464 	str	x4, [x3, #712]
    6440:	f9405444 	ldr	x4, [x2, #168]
    6444:	f9016864 	str	x4, [x3, #720]
    6448:	f9405844 	ldr	x4, [x2, #176]
    644c:	f9016c64 	str	x4, [x3, #728]
    6450:	a94b8844 	ldp	x4, x2, [x2, #184]
    6454:	f9017064 	str	x4, [x3, #736]
    6458:	f9017462 	str	x2, [x3, #744]
    645c:	97fff0fd 	bl	2850 <swapcontext@plt>
    6460:	97ffff64 	bl	61f0 <fwp_free_zombie>
    6464:	d503201f 	nop
    6468:	91010260 	add	x0, x19, #0x40
    646c:	b942f000 	ldr	w0, [x0, #752]
    6470:	340001a0 	cbz	w0, 64a4 <fwp_block+0x100>
    6474:	a94153f3 	ldp	x19, x20, [sp, #16]
    6478:	a8c27bfd 	ldp	x29, x30, [sp], #32
    647c:	d65f03c0 	ret
    6480:	97fff748 	bl	41a0 <fwp_poll_events>
    6484:	f9401a82 	ldr	x2, [x20, #48]
    6488:	b4ffffc2 	cbz	x2, 6480 <fwp_block+0xdc>
    648c:	91010261 	add	x1, x19, #0x40
    6490:	f9408040 	ldr	x0, [x2, #256]
    6494:	f9001820 	str	x0, [x1, #48]
    6498:	b5fff9c0 	cbnz	x0, 63d0 <fwp_block+0x2c>
    649c:	f900143f 	str	xzr, [x1, #40]
    64a0:	17ffffcc 	b	63d0 <fwp_block+0x2c>
    64a4:	f0000020 	adrp	x0, d000 <__modti3+0x310>
    64a8:	9111a000 	add	x0, x0, #0x468
    64ac:	97fff135 	bl	2980 <getenv@plt>
    64b0:	5284e202 	mov	w2, #0x2710                	// #10000
    64b4:	b4000060 	cbz	x0, 64c0 <fwp_block+0x11c>
    64b8:	39400001 	ldrb	w1, [x0]
    64bc:	350000c1 	cbnz	w1, 64d4 <fwp_block+0x130>
    64c0:	91010273 	add	x19, x19, #0x40
    64c4:	b902f262 	str	w2, [x19, #752]
    64c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    64cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64d0:	d65f03c0 	ret
    64d4:	52800142 	mov	w2, #0xa                   	// #10
    64d8:	d2800001 	mov	x1, #0x0                   	// #0
    64dc:	97fff079 	bl	26c0 <strtoll@plt>
    64e0:	d1000403 	sub	x3, x0, #0x1
    64e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    64e8:	eb02007f 	cmp	x3, x2
    64ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    64f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    64f4:	17fffff3 	b	64c0 <fwp_block+0x11c>
    64f8:	d503201f 	nop
    64fc:	d503201f 	nop

0000000000006500 <fwp_drop4>:
    6500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6504:	910003fd 	mov	x29, sp
    6508:	a90153f3 	stp	x19, x20, [sp, #16]
    650c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    6510:	f90013f5 	str	x21, [sp, #32]
    6514:	91154275 	add	x21, x19, #0x550
    6518:	f949daa1 	ldr	x1, [x21, #5040]
    651c:	f949eea2 	ldr	x2, [x21, #5080]
    6520:	cb010001 	sub	x1, x0, x1
    6524:	eb02403f 	cmp	x1, x2, lsl #16
    6528:	54000382 	b.cs	6598 <fwp_drop4+0x98>  // b.hs, b.nlast
    652c:	d350fc22 	lsr	x2, x1, #16
    6530:	f949fea3 	ldr	x3, [x21, #5112]
    6534:	8b020842 	add	x2, x2, x2, lsl #2
    6538:	d37df042 	lsl	x2, x2, #3
    653c:	8b020064 	add	x4, x3, x2
    6540:	f9401094 	ldr	x20, [x4, #32]
    6544:	b40002b4 	cbz	x20, 6598 <fwp_drop4+0x98>
    6548:	38626862 	ldrb	w2, [x3, x2]
    654c:	7100085f 	cmp	w2, #0x2
    6550:	540007a0 	b.eq	6644 <fwp_drop4+0x144>  // b.none
    6554:	7100045f 	cmp	w2, #0x1
    6558:	54000201 	b.ne	6598 <fwp_drop4+0x98>  // b.any
    655c:	29430885 	ldp	w5, w2, [x4, #24]
    6560:	92403c21 	and	x1, x1, #0xffff
    6564:	9b057c21 	mul	x1, x1, x5
    6568:	d360fc21 	lsr	x1, x1, #32
    656c:	eb02003f 	cmp	x1, x2
    6570:	54000142 	b.cs	6598 <fwp_drop4+0x98>  // b.hs, b.nlast
    6574:	8b010294 	add	x20, x20, x1
    6578:	39400281 	ldrb	w1, [x20]
    657c:	340000e1 	cbz	w1, 6598 <fwp_drop4+0x98>
    6580:	7100043f 	cmp	w1, #0x1
    6584:	54000120 	b.eq	65a8 <fwp_drop4+0xa8>  // b.none
    6588:	7103fc3f 	cmp	w1, #0xff
    658c:	540007c0 	b.eq	6684 <fwp_drop4+0x184>  // b.none
    6590:	51000421 	sub	w1, w1, #0x1
    6594:	39000281 	strb	w1, [x20]
    6598:	a94153f3 	ldp	x19, x20, [sp, #16]
    659c:	f94013f5 	ldr	x21, [sp, #32]
    65a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65a4:	d65f03c0 	ret
    65a8:	f9400001 	ldr	x1, [x0]
    65ac:	b7f80581 	tbnz	x1, #63, 665c <fwp_drop4+0x15c>
    65b0:	91154273 	add	x19, x19, #0x550
    65b4:	f949da61 	ldr	x1, [x19, #5040]
    65b8:	f949ee62 	ldr	x2, [x19, #5080]
    65bc:	cb010001 	sub	x1, x0, x1
    65c0:	eb02403f 	cmp	x1, x2, lsl #16
    65c4:	54fffea2 	b.cs	6598 <fwp_drop4+0x98>  // b.hs, b.nlast
    65c8:	d350fc22 	lsr	x2, x1, #16
    65cc:	8b020842 	add	x2, x2, x2, lsl #2
    65d0:	d37df042 	lsl	x2, x2, #3
    65d4:	8b020065 	add	x5, x3, x2
    65d8:	f94010a4 	ldr	x4, [x5, #32]
    65dc:	b4fffde4 	cbz	x4, 6598 <fwp_drop4+0x98>
    65e0:	38626862 	ldrb	w2, [x3, x2]
    65e4:	7100085f 	cmp	w2, #0x2
    65e8:	54000220 	b.eq	662c <fwp_drop4+0x12c>  // b.none
    65ec:	7100045f 	cmp	w2, #0x1
    65f0:	54fffd41 	b.ne	6598 <fwp_drop4+0x98>  // b.any
    65f4:	294308a3 	ldp	w3, w2, [x5, #24]
    65f8:	92403c21 	and	x1, x1, #0xffff
    65fc:	9b037c21 	mul	x1, x1, x3
    6600:	d360fc21 	lsr	x1, x1, #32
    6604:	eb02003f 	cmp	x1, x2
    6608:	54fffc82 	b.cs	6598 <fwp_drop4+0x98>  // b.hs, b.nlast
    660c:	8b010084 	add	x4, x4, x1
    6610:	39400081 	ldrb	w1, [x4]
    6614:	7100043f 	cmp	w1, #0x1
    6618:	54fffc01 	b.ne	6598 <fwp_drop4+0x98>  // b.any
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	f94013f5 	ldr	x21, [sp, #32]
    6624:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6628:	17fff852 	b	4770 <fwp_mem_free>
    662c:	72003c3f 	tst	w1, #0xffff
    6630:	54ffff00 	b.eq	6610 <fwp_drop4+0x110>  // b.none
    6634:	a94153f3 	ldp	x19, x20, [sp, #16]
    6638:	f94013f5 	ldr	x21, [sp, #32]
    663c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6640:	d65f03c0 	ret
    6644:	72003c3f 	tst	w1, #0xffff
    6648:	54fff980 	b.eq	6578 <fwp_drop4+0x78>  // b.none
    664c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6650:	f94013f5 	ldr	x21, [sp, #32]
    6654:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6658:	d65f03c0 	ret
    665c:	f9400414 	ldr	x20, [x0, #8]
    6660:	97fffbed 	bl	5614 <fwp_rc_free_arr>
    6664:	91154260 	add	x0, x19, #0x550
    6668:	f949d801 	ldr	x1, [x0, #5040]
    666c:	f949ec00 	ldr	x0, [x0, #5080]
    6670:	cb010281 	sub	x1, x20, x1
    6674:	eb00403f 	cmp	x1, x0, lsl #16
    6678:	54fff902 	b.cs	6598 <fwp_drop4+0x98>  // b.hs, b.nlast
    667c:	aa1403e0 	mov	x0, x20
    6680:	17ffffab 	b	652c <fwp_drop4+0x2c>
    6684:	ca544680 	eor	x0, x20, x20, lsr #17
    6688:	91154273 	add	x19, x19, #0x550
    668c:	ca402400 	eor	x0, x0, x0, lsr #9
    6690:	8b200e60 	add	x0, x19, w0, uxtb #3
    6694:	f94a2400 	ldr	x0, [x0, #5192]
    6698:	b5000080 	cbnz	x0, 66a8 <fwp_drop4+0x1a8>
    669c:	14000010 	b	66dc <fwp_drop4+0x1dc>
    66a0:	f9400800 	ldr	x0, [x0, #16]
    66a4:	b40001c0 	cbz	x0, 66dc <fwp_drop4+0x1dc>
    66a8:	f9400001 	ldr	x1, [x0]
    66ac:	eb14003f 	cmp	x1, x20
    66b0:	54ffff81 	b.ne	66a0 <fwp_drop4+0x1a0>  // b.any
    66b4:	f9400401 	ldr	x1, [x0, #8]
    66b8:	d1000421 	sub	x1, x1, #0x1
    66bc:	f9000401 	str	x1, [x0, #8]
    66c0:	f103f83f 	cmp	x1, #0xfe
    66c4:	54fff6a1 	b.ne	6598 <fwp_drop4+0x98>  // b.any
    66c8:	aa1403e0 	mov	x0, x20
    66cc:	97fff789 	bl	44f0 <fwp_rc_forget_slot>
    66d0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66d4:	39000280 	strb	w0, [x20]
    66d8:	17ffffb0 	b	6598 <fwp_drop4+0x98>
    66dc:	f0000020 	adrp	x0, d000 <__modti3+0x310>
    66e0:	910ce000 	add	x0, x0, #0x338
    66e4:	97fff387 	bl	3500 <fwp_trap>
    66e8:	d503201f 	nop
    66ec:	d503201f 	nop

00000000000066f0 <fwp_caps161>:
    66f0:	34000041 	cbz	w1, 66f8 <fwp_caps161+0x8>
    66f4:	d65f03c0 	ret
    66f8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    66fc:	91154063 	add	x3, x3, #0x550
    6700:	f949d861 	ldr	x1, [x3, #5040]
    6704:	f949ec62 	ldr	x2, [x3, #5080]
    6708:	cb010001 	sub	x1, x0, x1
    670c:	eb02403f 	cmp	x1, x2, lsl #16
    6710:	54ffff22 	b.cs	66f4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6714:	d350fc22 	lsr	x2, x1, #16
    6718:	f949fc65 	ldr	x5, [x3, #5112]
    671c:	8b020842 	add	x2, x2, x2, lsl #2
    6720:	d37df042 	lsl	x2, x2, #3
    6724:	8b0200a4 	add	x4, x5, x2
    6728:	f9401083 	ldr	x3, [x4, #32]
    672c:	b4fffe43 	cbz	x3, 66f4 <fwp_caps161+0x4>
    6730:	386268a2 	ldrb	w2, [x5, x2]
    6734:	7100085f 	cmp	w2, #0x2
    6738:	540001c0 	b.eq	6770 <fwp_caps161+0x80>  // b.none
    673c:	7100045f 	cmp	w2, #0x1
    6740:	54fffda1 	b.ne	66f4 <fwp_caps161+0x4>  // b.any
    6744:	29430885 	ldp	w5, w2, [x4, #24]
    6748:	92403c21 	and	x1, x1, #0xffff
    674c:	9b057c21 	mul	x1, x1, x5
    6750:	d360fc21 	lsr	x1, x1, #32
    6754:	eb02003f 	cmp	x1, x2
    6758:	54fffce2 	b.cs	66f4 <fwp_caps161+0x4>  // b.hs, b.nlast
    675c:	8b010063 	add	x3, x3, x1
    6760:	39400061 	ldrb	w1, [x3]
    6764:	7100043f 	cmp	w1, #0x1
    6768:	54fffc61 	b.ne	66f4 <fwp_caps161+0x4>  // b.any
    676c:	17fff801 	b	4770 <fwp_mem_free>
    6770:	72003c3f 	tst	w1, #0xffff
    6774:	54ffff60 	b.eq	6760 <fwp_caps161+0x70>  // b.none
    6778:	d65f03c0 	ret
    677c:	d503201f 	nop

0000000000006780 <fwp_args23>:
    6780:	7100003f 	cmp	w1, #0x0
    6784:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6788:	54000041 	b.ne	6790 <fwp_args23+0x10>  // b.any
    678c:	d65f03c0 	ret
    6790:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6794:	91154042 	add	x2, x2, #0x550
    6798:	f9400001 	ldr	x1, [x0]
    679c:	f949d843 	ldr	x3, [x2, #5040]
    67a0:	f949ec40 	ldr	x0, [x2, #5080]
    67a4:	cb030021 	sub	x1, x1, x3
    67a8:	eb00403f 	cmp	x1, x0, lsl #16
    67ac:	54ffff02 	b.cs	678c <fwp_args23+0xc>  // b.hs, b.nlast
    67b0:	d350fc20 	lsr	x0, x1, #16
    67b4:	f949fc44 	ldr	x4, [x2, #5112]
    67b8:	8b000800 	add	x0, x0, x0, lsl #2
    67bc:	d37df002 	lsl	x2, x0, #3
    67c0:	8b020083 	add	x3, x4, x2
    67c4:	f9401060 	ldr	x0, [x3, #32]
    67c8:	b4fffe20 	cbz	x0, 678c <fwp_args23+0xc>
    67cc:	38626882 	ldrb	w2, [x4, x2]
    67d0:	7100085f 	cmp	w2, #0x2
    67d4:	54000220 	b.eq	6818 <fwp_args23+0x98>  // b.none
    67d8:	7100045f 	cmp	w2, #0x1
    67dc:	54fffd81 	b.ne	678c <fwp_args23+0xc>  // b.any
    67e0:	29430864 	ldp	w4, w2, [x3, #24]
    67e4:	92403c21 	and	x1, x1, #0xffff
    67e8:	9b047c21 	mul	x1, x1, x4
    67ec:	d360fc21 	lsr	x1, x1, #32
    67f0:	eb02003f 	cmp	x1, x2
    67f4:	54fffcc2 	b.cs	678c <fwp_args23+0xc>  // b.hs, b.nlast
    67f8:	8b010000 	add	x0, x0, x1
    67fc:	39400001 	ldrb	w1, [x0]
    6800:	34fffc61 	cbz	w1, 678c <fwp_args23+0xc>
    6804:	7103f43f 	cmp	w1, #0xfd
    6808:	540000e8 	b.hi	6824 <fwp_args23+0xa4>  // b.pmore
    680c:	11000421 	add	w1, w1, #0x1
    6810:	39000001 	strb	w1, [x0]
    6814:	d65f03c0 	ret
    6818:	72003c3f 	tst	w1, #0xffff
    681c:	54ffff00 	b.eq	67fc <fwp_args23+0x7c>  // b.none
    6820:	d65f03c0 	ret
    6824:	17fff6ec 	b	43d4 <fwp_rc_wide_dup>
    6828:	d503201f 	nop
    682c:	d503201f 	nop

0000000000006830 <fwp_args12>:
    6830:	7100003f 	cmp	w1, #0x0
    6834:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6838:	54000041 	b.ne	6840 <fwp_args12+0x10>  // b.any
    683c:	d65f03c0 	ret
    6840:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6844:	91154042 	add	x2, x2, #0x550
    6848:	f9400001 	ldr	x1, [x0]
    684c:	f949d843 	ldr	x3, [x2, #5040]
    6850:	f949ec40 	ldr	x0, [x2, #5080]
    6854:	cb030021 	sub	x1, x1, x3
    6858:	eb00403f 	cmp	x1, x0, lsl #16
    685c:	54ffff02 	b.cs	683c <fwp_args12+0xc>  // b.hs, b.nlast
    6860:	d350fc20 	lsr	x0, x1, #16
    6864:	f949fc44 	ldr	x4, [x2, #5112]
    6868:	8b000800 	add	x0, x0, x0, lsl #2
    686c:	d37df002 	lsl	x2, x0, #3
    6870:	8b020083 	add	x3, x4, x2
    6874:	f9401060 	ldr	x0, [x3, #32]
    6878:	b4fffe20 	cbz	x0, 683c <fwp_args12+0xc>
    687c:	38626882 	ldrb	w2, [x4, x2]
    6880:	7100085f 	cmp	w2, #0x2
    6884:	54000220 	b.eq	68c8 <fwp_args12+0x98>  // b.none
    6888:	7100045f 	cmp	w2, #0x1
    688c:	54fffd81 	b.ne	683c <fwp_args12+0xc>  // b.any
    6890:	29430864 	ldp	w4, w2, [x3, #24]
    6894:	92403c21 	and	x1, x1, #0xffff
    6898:	9b047c21 	mul	x1, x1, x4
    689c:	d360fc21 	lsr	x1, x1, #32
    68a0:	eb02003f 	cmp	x1, x2
    68a4:	54fffcc2 	b.cs	683c <fwp_args12+0xc>  // b.hs, b.nlast
    68a8:	8b010000 	add	x0, x0, x1
    68ac:	39400001 	ldrb	w1, [x0]
    68b0:	34fffc61 	cbz	w1, 683c <fwp_args12+0xc>
    68b4:	7103f43f 	cmp	w1, #0xfd
    68b8:	540000e8 	b.hi	68d4 <fwp_args12+0xa4>  // b.pmore
    68bc:	11000421 	add	w1, w1, #0x1
    68c0:	39000001 	strb	w1, [x0]
    68c4:	d65f03c0 	ret
    68c8:	72003c3f 	tst	w1, #0xffff
    68cc:	54ffff00 	b.eq	68ac <fwp_args12+0x7c>  // b.none
    68d0:	d65f03c0 	ret
    68d4:	17fff6c0 	b	43d4 <fwp_rc_wide_dup>
    68d8:	d503201f 	nop
    68dc:	d503201f 	nop

00000000000068e0 <fwp_caps12>:
    68e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68e4:	910003fd 	mov	x29, sp
    68e8:	f9000bf3 	str	x19, [sp, #16]
    68ec:	aa0003f3 	mov	x19, x0
    68f0:	b9400400 	ldr	w0, [x0, #4]
    68f4:	340004a0 	cbz	w0, 6988 <fwp_caps12+0xa8>
    68f8:	f9400660 	ldr	x0, [x19, #8]
    68fc:	350004e1 	cbnz	w1, 6998 <fwp_caps12+0xb8>
    6900:	97fffc70 	bl	5ac0 <fwp_drop0>
    6904:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6908:	91154042 	add	x2, x2, #0x550
    690c:	f949d840 	ldr	x0, [x2, #5040]
    6910:	f949ec41 	ldr	x1, [x2, #5080]
    6914:	cb000260 	sub	x0, x19, x0
    6918:	eb01401f 	cmp	x0, x1, lsl #16
    691c:	54000382 	b.cs	698c <fwp_caps12+0xac>  // b.hs, b.nlast
    6920:	d350fc01 	lsr	x1, x0, #16
    6924:	f949fc44 	ldr	x4, [x2, #5112]
    6928:	8b010821 	add	x1, x1, x1, lsl #2
    692c:	d37df021 	lsl	x1, x1, #3
    6930:	8b010083 	add	x3, x4, x1
    6934:	f9401062 	ldr	x2, [x3, #32]
    6938:	b40002a2 	cbz	x2, 698c <fwp_caps12+0xac>
    693c:	38616881 	ldrb	w1, [x4, x1]
    6940:	7100083f 	cmp	w1, #0x2
    6944:	540006c0 	b.eq	6a1c <fwp_caps12+0x13c>  // b.none
    6948:	7100043f 	cmp	w1, #0x1
    694c:	54000201 	b.ne	698c <fwp_caps12+0xac>  // b.any
    6950:	29430464 	ldp	w4, w1, [x3, #24]
    6954:	92403c00 	and	x0, x0, #0xffff
    6958:	9b047c00 	mul	x0, x0, x4
    695c:	d360fc00 	lsr	x0, x0, #32
    6960:	eb01001f 	cmp	x0, x1
    6964:	54000142 	b.cs	698c <fwp_caps12+0xac>  // b.hs, b.nlast
    6968:	8b000042 	add	x2, x2, x0
    696c:	39400040 	ldrb	w0, [x2]
    6970:	7100041f 	cmp	w0, #0x1
    6974:	540000c1 	b.ne	698c <fwp_caps12+0xac>  // b.any
    6978:	aa1303e0 	mov	x0, x19
    697c:	f9400bf3 	ldr	x19, [sp, #16]
    6980:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6984:	17fff77b 	b	4770 <fwp_mem_free>
    6988:	34fffbe1 	cbz	w1, 6904 <fwp_caps12+0x24>
    698c:	f9400bf3 	ldr	x19, [sp, #16]
    6990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6994:	d65f03c0 	ret
    6998:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    699c:	91154042 	add	x2, x2, #0x550
    69a0:	f949d843 	ldr	x3, [x2, #5040]
    69a4:	f949ec41 	ldr	x1, [x2, #5080]
    69a8:	cb030000 	sub	x0, x0, x3
    69ac:	eb01401f 	cmp	x0, x1, lsl #16
    69b0:	54fffee2 	b.cs	698c <fwp_caps12+0xac>  // b.hs, b.nlast
    69b4:	d350fc01 	lsr	x1, x0, #16
    69b8:	f949fc44 	ldr	x4, [x2, #5112]
    69bc:	8b010821 	add	x1, x1, x1, lsl #2
    69c0:	d37df021 	lsl	x1, x1, #3
    69c4:	8b010083 	add	x3, x4, x1
    69c8:	f9401062 	ldr	x2, [x3, #32]
    69cc:	b4fffe02 	cbz	x2, 698c <fwp_caps12+0xac>
    69d0:	38616881 	ldrb	w1, [x4, x1]
    69d4:	7100083f 	cmp	w1, #0x2
    69d8:	54000280 	b.eq	6a28 <fwp_caps12+0x148>  // b.none
    69dc:	7100043f 	cmp	w1, #0x1
    69e0:	54fffd61 	b.ne	698c <fwp_caps12+0xac>  // b.any
    69e4:	92403c01 	and	x1, x0, #0xffff
    69e8:	29430064 	ldp	w4, w0, [x3, #24]
    69ec:	9b047c21 	mul	x1, x1, x4
    69f0:	d360fc21 	lsr	x1, x1, #32
    69f4:	eb00003f 	cmp	x1, x0
    69f8:	54fffca2 	b.cs	698c <fwp_caps12+0xac>  // b.hs, b.nlast
    69fc:	8b010042 	add	x2, x2, x1
    6a00:	39400040 	ldrb	w0, [x2]
    6a04:	34fffc40 	cbz	w0, 698c <fwp_caps12+0xac>
    6a08:	7103f41f 	cmp	w0, #0xfd
    6a0c:	54000148 	b.hi	6a34 <fwp_caps12+0x154>  // b.pmore
    6a10:	11000400 	add	w0, w0, #0x1
    6a14:	39000040 	strb	w0, [x2]
    6a18:	17ffffdd 	b	698c <fwp_caps12+0xac>
    6a1c:	72003c1f 	tst	w0, #0xffff
    6a20:	54fffb61 	b.ne	698c <fwp_caps12+0xac>  // b.any
    6a24:	17ffffd2 	b	696c <fwp_caps12+0x8c>
    6a28:	72003c1f 	tst	w0, #0xffff
    6a2c:	54fffb01 	b.ne	698c <fwp_caps12+0xac>  // b.any
    6a30:	17fffff4 	b	6a00 <fwp_caps12+0x120>
    6a34:	f9400bf3 	ldr	x19, [sp, #16]
    6a38:	aa0203e0 	mov	x0, x2
    6a3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a40:	17fff665 	b	43d4 <fwp_rc_wide_dup>

0000000000006a44 <fwp_drop2>:
    6a44:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6a48:	910003fd 	mov	x29, sp
    6a4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6a50:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    6a54:	911542d5 	add	x21, x22, #0x550
    6a58:	a90153f3 	stp	x19, x20, [sp, #16]
    6a5c:	aa0003f3 	mov	x19, x0
    6a60:	f949daa1 	ldr	x1, [x21, #5040]
    6a64:	f949eea0 	ldr	x0, [x21, #5080]
    6a68:	cb010261 	sub	x1, x19, x1
    6a6c:	eb00403f 	cmp	x1, x0, lsl #16
    6a70:	54000382 	b.cs	6ae0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6a74:	d350fc22 	lsr	x2, x1, #16
    6a78:	f949fea3 	ldr	x3, [x21, #5112]
    6a7c:	8b020842 	add	x2, x2, x2, lsl #2
    6a80:	d37df042 	lsl	x2, x2, #3
    6a84:	8b020060 	add	x0, x3, x2
    6a88:	f9401014 	ldr	x20, [x0, #32]
    6a8c:	b40002b4 	cbz	x20, 6ae0 <fwp_drop2+0x9c>
    6a90:	38626862 	ldrb	w2, [x3, x2]
    6a94:	7100085f 	cmp	w2, #0x2
    6a98:	540002c0 	b.eq	6af0 <fwp_drop2+0xac>  // b.none
    6a9c:	7100045f 	cmp	w2, #0x1
    6aa0:	54000201 	b.ne	6ae0 <fwp_drop2+0x9c>  // b.any
    6aa4:	29430002 	ldp	w2, w0, [x0, #24]
    6aa8:	92403c21 	and	x1, x1, #0xffff
    6aac:	9b027c21 	mul	x1, x1, x2
    6ab0:	d360fc21 	lsr	x1, x1, #32
    6ab4:	eb00003f 	cmp	x1, x0
    6ab8:	54000142 	b.cs	6ae0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6abc:	8b010294 	add	x20, x20, x1
    6ac0:	39400280 	ldrb	w0, [x20]
    6ac4:	340000e0 	cbz	w0, 6ae0 <fwp_drop2+0x9c>
    6ac8:	7100041f 	cmp	w0, #0x1
    6acc:	540001e0 	b.eq	6b08 <fwp_drop2+0xc4>  // b.none
    6ad0:	7103fc1f 	cmp	w0, #0xff
    6ad4:	540007e0 	b.eq	6bd0 <fwp_drop2+0x18c>  // b.none
    6ad8:	51000400 	sub	w0, w0, #0x1
    6adc:	39000280 	strb	w0, [x20]
    6ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ae4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ae8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6aec:	d65f03c0 	ret
    6af0:	72003c3f 	tst	w1, #0xffff
    6af4:	54fffe60 	b.eq	6ac0 <fwp_drop2+0x7c>  // b.none
    6af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6afc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6b00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b04:	d65f03c0 	ret
    6b08:	911542c2 	add	x2, x22, #0x550
    6b0c:	f9400660 	ldr	x0, [x19, #8]
    6b10:	f949d841 	ldr	x1, [x2, #5040]
    6b14:	f949ec42 	ldr	x2, [x2, #5080]
    6b18:	cb010001 	sub	x1, x0, x1
    6b1c:	eb02403f 	cmp	x1, x2, lsl #16
    6b20:	54000382 	b.cs	6b90 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6b24:	d350fc22 	lsr	x2, x1, #16
    6b28:	8b020842 	add	x2, x2, x2, lsl #2
    6b2c:	d37df042 	lsl	x2, x2, #3
    6b30:	8b020064 	add	x4, x3, x2
    6b34:	f9401094 	ldr	x20, [x4, #32]
    6b38:	b40002d4 	cbz	x20, 6b90 <fwp_drop2+0x14c>
    6b3c:	38626862 	ldrb	w2, [x3, x2]
    6b40:	7100085f 	cmp	w2, #0x2
    6b44:	54000400 	b.eq	6bc4 <fwp_drop2+0x180>  // b.none
    6b48:	7100045f 	cmp	w2, #0x1
    6b4c:	54000221 	b.ne	6b90 <fwp_drop2+0x14c>  // b.any
    6b50:	29430883 	ldp	w3, w2, [x4, #24]
    6b54:	92403c21 	and	x1, x1, #0xffff
    6b58:	9b037c21 	mul	x1, x1, x3
    6b5c:	d360fc21 	lsr	x1, x1, #32
    6b60:	eb02003f 	cmp	x1, x2
    6b64:	54000162 	b.cs	6b90 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6b68:	8b010294 	add	x20, x20, x1
    6b6c:	39400281 	ldrb	w1, [x20]
    6b70:	34000101 	cbz	w1, 6b90 <fwp_drop2+0x14c>
    6b74:	7100043f 	cmp	w1, #0x1
    6b78:	54000220 	b.eq	6bbc <fwp_drop2+0x178>  // b.none
    6b7c:	7103fc3f 	cmp	w1, #0xff
    6b80:	540005a0 	b.eq	6c34 <fwp_drop2+0x1f0>  // b.none
    6b84:	51000421 	sub	w1, w1, #0x1
    6b88:	39000281 	strb	w1, [x20]
    6b8c:	d503201f 	nop
    6b90:	f9400a74 	ldr	x20, [x19, #16]
    6b94:	aa1303e0 	mov	x0, x19
    6b98:	97fffa9f 	bl	5614 <fwp_rc_free_arr>
    6b9c:	911542c0 	add	x0, x22, #0x550
    6ba0:	f949d801 	ldr	x1, [x0, #5040]
    6ba4:	f949ec00 	ldr	x0, [x0, #5080]
    6ba8:	cb010281 	sub	x1, x20, x1
    6bac:	eb00403f 	cmp	x1, x0, lsl #16
    6bb0:	54fff982 	b.cs	6ae0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6bb4:	aa1403f3 	mov	x19, x20
    6bb8:	17ffffaf 	b	6a74 <fwp_drop2+0x30>
    6bbc:	97fffa96 	bl	5614 <fwp_rc_free_arr>
    6bc0:	17fffff4 	b	6b90 <fwp_drop2+0x14c>
    6bc4:	72003c3f 	tst	w1, #0xffff
    6bc8:	54fffe41 	b.ne	6b90 <fwp_drop2+0x14c>  // b.any
    6bcc:	17ffffe8 	b	6b6c <fwp_drop2+0x128>
    6bd0:	ca544681 	eor	x1, x20, x20, lsr #17
    6bd4:	911542c0 	add	x0, x22, #0x550
    6bd8:	ca412421 	eor	x1, x1, x1, lsr #9
    6bdc:	8b210c01 	add	x1, x0, w1, uxtb #3
    6be0:	f94a2420 	ldr	x0, [x1, #5192]
    6be4:	b5000080 	cbnz	x0, 6bf4 <fwp_drop2+0x1b0>
    6be8:	14000010 	b	6c28 <fwp_drop2+0x1e4>
    6bec:	f9400800 	ldr	x0, [x0, #16]
    6bf0:	b40001c0 	cbz	x0, 6c28 <fwp_drop2+0x1e4>
    6bf4:	f9400001 	ldr	x1, [x0]
    6bf8:	eb14003f 	cmp	x1, x20
    6bfc:	54ffff81 	b.ne	6bec <fwp_drop2+0x1a8>  // b.any
    6c00:	f9400401 	ldr	x1, [x0, #8]
    6c04:	d1000421 	sub	x1, x1, #0x1
    6c08:	f9000401 	str	x1, [x0, #8]
    6c0c:	f103f83f 	cmp	x1, #0xfe
    6c10:	54fff681 	b.ne	6ae0 <fwp_drop2+0x9c>  // b.any
    6c14:	aa1403e0 	mov	x0, x20
    6c18:	97fff636 	bl	44f0 <fwp_rc_forget_slot>
    6c1c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c20:	39000280 	strb	w0, [x20]
    6c24:	17ffffaf 	b	6ae0 <fwp_drop2+0x9c>
    6c28:	f0000020 	adrp	x0, d000 <__modti3+0x310>
    6c2c:	910ce000 	add	x0, x0, #0x338
    6c30:	97fff234 	bl	3500 <fwp_trap>
    6c34:	ca544680 	eor	x0, x20, x20, lsr #17
    6c38:	911542c1 	add	x1, x22, #0x550
    6c3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6c40:	8b200c20 	add	x0, x1, w0, uxtb #3
    6c44:	f94a2400 	ldr	x0, [x0, #5192]
    6c48:	b5000080 	cbnz	x0, 6c58 <fwp_drop2+0x214>
    6c4c:	17fffff7 	b	6c28 <fwp_drop2+0x1e4>
    6c50:	f9400800 	ldr	x0, [x0, #16]
    6c54:	b4fffea0 	cbz	x0, 6c28 <fwp_drop2+0x1e4>
    6c58:	f9400001 	ldr	x1, [x0]
    6c5c:	eb14003f 	cmp	x1, x20
    6c60:	54ffff81 	b.ne	6c50 <fwp_drop2+0x20c>  // b.any
    6c64:	f9400401 	ldr	x1, [x0, #8]
    6c68:	d1000421 	sub	x1, x1, #0x1
    6c6c:	f9000401 	str	x1, [x0, #8]
    6c70:	f103f83f 	cmp	x1, #0xfe
    6c74:	54fff8e1 	b.ne	6b90 <fwp_drop2+0x14c>  // b.any
    6c78:	aa1403e0 	mov	x0, x20
    6c7c:	97fff61d 	bl	44f0 <fwp_rc_forget_slot>
    6c80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c84:	39000280 	strb	w0, [x20]
    6c88:	17ffffc2 	b	6b90 <fwp_drop2+0x14c>
    6c8c:	d503201f 	nop

0000000000006c90 <fwp_arg_drop23>:
    6c90:	7100003f 	cmp	w1, #0x0
    6c94:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c98:	54000041 	b.ne	6ca0 <fwp_arg_drop23+0x10>  // b.any
    6c9c:	d65f03c0 	ret
    6ca0:	f9400000 	ldr	x0, [x0]
    6ca4:	17ffff68 	b	6a44 <fwp_drop2>
    6ca8:	d503201f 	nop
    6cac:	d503201f 	nop

0000000000006cb0 <fwp_caps23>:
    6cb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6cb4:	910003fd 	mov	x29, sp
    6cb8:	f9000bf3 	str	x19, [sp, #16]
    6cbc:	aa0003f3 	mov	x19, x0
    6cc0:	b9400400 	ldr	w0, [x0, #4]
    6cc4:	340004a0 	cbz	w0, 6d58 <fwp_caps23+0xa8>
    6cc8:	f9400660 	ldr	x0, [x19, #8]
    6ccc:	350004e1 	cbnz	w1, 6d68 <fwp_caps23+0xb8>
    6cd0:	97ffff5d 	bl	6a44 <fwp_drop2>
    6cd4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6cd8:	91154042 	add	x2, x2, #0x550
    6cdc:	f949d840 	ldr	x0, [x2, #5040]
    6ce0:	f949ec41 	ldr	x1, [x2, #5080]
    6ce4:	cb000260 	sub	x0, x19, x0
    6ce8:	eb01401f 	cmp	x0, x1, lsl #16
    6cec:	54000382 	b.cs	6d5c <fwp_caps23+0xac>  // b.hs, b.nlast
    6cf0:	d350fc01 	lsr	x1, x0, #16
    6cf4:	f949fc44 	ldr	x4, [x2, #5112]
    6cf8:	8b010821 	add	x1, x1, x1, lsl #2
    6cfc:	d37df021 	lsl	x1, x1, #3
    6d00:	8b010083 	add	x3, x4, x1
    6d04:	f9401062 	ldr	x2, [x3, #32]
    6d08:	b40002a2 	cbz	x2, 6d5c <fwp_caps23+0xac>
    6d0c:	38616881 	ldrb	w1, [x4, x1]
    6d10:	7100083f 	cmp	w1, #0x2
    6d14:	540006c0 	b.eq	6dec <fwp_caps23+0x13c>  // b.none
    6d18:	7100043f 	cmp	w1, #0x1
    6d1c:	54000201 	b.ne	6d5c <fwp_caps23+0xac>  // b.any
    6d20:	29430464 	ldp	w4, w1, [x3, #24]
    6d24:	92403c00 	and	x0, x0, #0xffff
    6d28:	9b047c00 	mul	x0, x0, x4
    6d2c:	d360fc00 	lsr	x0, x0, #32
    6d30:	eb01001f 	cmp	x0, x1
    6d34:	54000142 	b.cs	6d5c <fwp_caps23+0xac>  // b.hs, b.nlast
    6d38:	8b000042 	add	x2, x2, x0
    6d3c:	39400040 	ldrb	w0, [x2]
    6d40:	7100041f 	cmp	w0, #0x1
    6d44:	540000c1 	b.ne	6d5c <fwp_caps23+0xac>  // b.any
    6d48:	aa1303e0 	mov	x0, x19
    6d4c:	f9400bf3 	ldr	x19, [sp, #16]
    6d50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d54:	17fff687 	b	4770 <fwp_mem_free>
    6d58:	34fffbe1 	cbz	w1, 6cd4 <fwp_caps23+0x24>
    6d5c:	f9400bf3 	ldr	x19, [sp, #16]
    6d60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d64:	d65f03c0 	ret
    6d68:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6d6c:	91154042 	add	x2, x2, #0x550
    6d70:	f949d843 	ldr	x3, [x2, #5040]
    6d74:	f949ec41 	ldr	x1, [x2, #5080]
    6d78:	cb030000 	sub	x0, x0, x3
    6d7c:	eb01401f 	cmp	x0, x1, lsl #16
    6d80:	54fffee2 	b.cs	6d5c <fwp_caps23+0xac>  // b.hs, b.nlast
    6d84:	d350fc01 	lsr	x1, x0, #16
    6d88:	f949fc44 	ldr	x4, [x2, #5112]
    6d8c:	8b010821 	add	x1, x1, x1, lsl #2
    6d90:	d37df021 	lsl	x1, x1, #3
    6d94:	8b010083 	add	x3, x4, x1
    6d98:	f9401062 	ldr	x2, [x3, #32]
    6d9c:	b4fffe02 	cbz	x2, 6d5c <fwp_caps23+0xac>
    6da0:	38616881 	ldrb	w1, [x4, x1]
    6da4:	7100083f 	cmp	w1, #0x2
    6da8:	54000280 	b.eq	6df8 <fwp_caps23+0x148>  // b.none
    6dac:	7100043f 	cmp	w1, #0x1
    6db0:	54fffd61 	b.ne	6d5c <fwp_caps23+0xac>  // b.any
    6db4:	92403c01 	and	x1, x0, #0xffff
    6db8:	29430064 	ldp	w4, w0, [x3, #24]
    6dbc:	9b047c21 	mul	x1, x1, x4
    6dc0:	d360fc21 	lsr	x1, x1, #32
    6dc4:	eb00003f 	cmp	x1, x0
    6dc8:	54fffca2 	b.cs	6d5c <fwp_caps23+0xac>  // b.hs, b.nlast
    6dcc:	8b010042 	add	x2, x2, x1
    6dd0:	39400040 	ldrb	w0, [x2]
    6dd4:	34fffc40 	cbz	w0, 6d5c <fwp_caps23+0xac>
    6dd8:	7103f41f 	cmp	w0, #0xfd
    6ddc:	54000148 	b.hi	6e04 <fwp_caps23+0x154>  // b.pmore
    6de0:	11000400 	add	w0, w0, #0x1
    6de4:	39000040 	strb	w0, [x2]
    6de8:	17ffffdd 	b	6d5c <fwp_caps23+0xac>
    6dec:	72003c1f 	tst	w0, #0xffff
    6df0:	54fffb61 	b.ne	6d5c <fwp_caps23+0xac>  // b.any
    6df4:	17ffffd2 	b	6d3c <fwp_caps23+0x8c>
    6df8:	72003c1f 	tst	w0, #0xffff
    6dfc:	54fffb01 	b.ne	6d5c <fwp_caps23+0xac>  // b.any
    6e00:	17fffff4 	b	6dd0 <fwp_caps23+0x120>
    6e04:	f9400bf3 	ldr	x19, [sp, #16]
    6e08:	aa0203e0 	mov	x0, x2
    6e0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e10:	17fff571 	b	43d4 <fwp_rc_wide_dup>

0000000000006e14 <f23>:
    6e14:	d101c3ff 	sub	sp, sp, #0x70
    6e18:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6e1c:	f947f421 	ldr	x1, [x1, #4072]
    6e20:	a9027bfd 	stp	x29, x30, [sp, #32]
    6e24:	910083fd 	add	x29, sp, #0x20
    6e28:	a90563f7 	stp	x23, x24, [sp, #80]
    6e2c:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    6e30:	911542e3 	add	x3, x23, #0x550
    6e34:	a90353f3 	stp	x19, x20, [sp, #48]
    6e38:	a9045bf5 	stp	x21, x22, [sp, #64]
    6e3c:	aa0003f6 	mov	x22, x0
    6e40:	a9066bf9 	stp	x25, x26, [sp, #96]
    6e44:	f949ec62 	ldr	x2, [x3, #5080]
    6e48:	f9400024 	ldr	x4, [x1]
    6e4c:	f9000fe4 	str	x4, [sp, #24]
    6e50:	d2800004 	mov	x4, #0x0                   	// #0
    6e54:	f949d861 	ldr	x1, [x3, #5040]
    6e58:	d370bc42 	lsl	x2, x2, #16
    6e5c:	b40015a0 	cbz	x0, 7110 <f23+0x2fc>
    6e60:	f9400818 	ldr	x24, [x0, #16]
    6e64:	cb010301 	sub	x1, x24, x1
    6e68:	eb02003f 	cmp	x1, x2
    6e6c:	54000362 	b.cs	6ed8 <f23+0xc4>  // b.hs, b.nlast
    6e70:	f949fc60 	ldr	x0, [x3, #5112]
    6e74:	d350fc22 	lsr	x2, x1, #16
    6e78:	8b020842 	add	x2, x2, x2, lsl #2
    6e7c:	8b020c02 	add	x2, x0, x2, lsl #3
    6e80:	f9401040 	ldr	x0, [x2, #32]
    6e84:	b40002a0 	cbz	x0, 6ed8 <f23+0xc4>
    6e88:	39400043 	ldrb	w3, [x2]
    6e8c:	7100087f 	cmp	w3, #0x2
    6e90:	540013a0 	b.eq	7104 <f23+0x2f0>  // b.none
    6e94:	7100047f 	cmp	w3, #0x1
    6e98:	540001c1 	b.ne	6ed0 <f23+0xbc>  // b.any
    6e9c:	29430843 	ldp	w3, w2, [x2, #24]
    6ea0:	92403c21 	and	x1, x1, #0xffff
    6ea4:	9b037c21 	mul	x1, x1, x3
    6ea8:	d360fc21 	lsr	x1, x1, #32
    6eac:	eb02003f 	cmp	x1, x2
    6eb0:	54000102 	b.cs	6ed0 <f23+0xbc>  // b.hs, b.nlast
    6eb4:	8b010000 	add	x0, x0, x1
    6eb8:	39400001 	ldrb	w1, [x0]
    6ebc:	340000a1 	cbz	w1, 6ed0 <f23+0xbc>
    6ec0:	7103f43f 	cmp	w1, #0xfd
    6ec4:	54001688 	b.hi	7194 <f23+0x380>  // b.pmore
    6ec8:	11000421 	add	w1, w1, #0x1
    6ecc:	39000001 	strb	w1, [x0]
    6ed0:	d2800000 	mov	x0, #0x0                   	// #0
    6ed4:	b40000d6 	cbz	x22, 6eec <f23+0xd8>
    6ed8:	aa1603e1 	mov	x1, x22
    6edc:	d2800000 	mov	x0, #0x0                   	// #0
    6ee0:	f9400821 	ldr	x1, [x1, #16]
    6ee4:	91000400 	add	x0, x0, #0x1
    6ee8:	b5ffffc1 	cbnz	x1, 6ee0 <f23+0xcc>
    6eec:	b40011b8 	cbz	x24, 7120 <f23+0x30c>
    6ef0:	aa1803e1 	mov	x1, x24
    6ef4:	d2800002 	mov	x2, #0x0                   	// #0
    6ef8:	f9400821 	ldr	x1, [x1, #16]
    6efc:	91000442 	add	x2, x2, #0x1
    6f00:	b5ffffc1 	cbnz	x1, 6ef8 <f23+0xe4>
    6f04:	eb00005f 	cmp	x2, x0
    6f08:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6f0c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6f10:	eb01033f 	cmp	x25, x1
    6f14:	54001468 	b.hi	71a0 <f23+0x38c>  // b.pmore
    6f18:	d37ffb33 	lsl	x19, x25, #1
    6f1c:	52800041 	mov	w1, #0x2                   	// #2
    6f20:	91000660 	add	x0, x19, #0x1
    6f24:	d37df000 	lsl	x0, x0, #3
    6f28:	97fff732 	bl	4bf0 <fwp_heap_alloc>
    6f2c:	911542e1 	add	x1, x23, #0x550
    6f30:	aa0003fa 	mov	x26, x0
    6f34:	f9000013 	str	x19, [x0]
    6f38:	aa0103e0 	mov	x0, x1
    6f3c:	f949d821 	ldr	x1, [x1, #5040]
    6f40:	f949ec00 	ldr	x0, [x0, #5080]
    6f44:	cb010341 	sub	x1, x26, x1
    6f48:	eb00403f 	cmp	x1, x0, lsl #16
    6f4c:	54000342 	b.cs	6fb4 <f23+0x1a0>  // b.hs, b.nlast
    6f50:	911542e2 	add	x2, x23, #0x550
    6f54:	d350fc20 	lsr	x0, x1, #16
    6f58:	8b000800 	add	x0, x0, x0, lsl #2
    6f5c:	f949fc43 	ldr	x3, [x2, #5112]
    6f60:	d37df002 	lsl	x2, x0, #3
    6f64:	8b020060 	add	x0, x3, x2
    6f68:	f9401013 	ldr	x19, [x0, #32]
    6f6c:	b4000253 	cbz	x19, 6fb4 <f23+0x1a0>
    6f70:	38626862 	ldrb	w2, [x3, x2]
    6f74:	7100085f 	cmp	w2, #0x2
    6f78:	54000c00 	b.eq	70f8 <f23+0x2e4>  // b.none
    6f7c:	7100045f 	cmp	w2, #0x1
    6f80:	540001a1 	b.ne	6fb4 <f23+0x1a0>  // b.any
    6f84:	29430002 	ldp	w2, w0, [x0, #24]
    6f88:	92403c21 	and	x1, x1, #0xffff
    6f8c:	9b027c21 	mul	x1, x1, x2
    6f90:	d360fc21 	lsr	x1, x1, #32
    6f94:	eb00003f 	cmp	x1, x0
    6f98:	540000e2 	b.cs	6fb4 <f23+0x1a0>  // b.hs, b.nlast
    6f9c:	8b010273 	add	x19, x19, x1
    6fa0:	39400260 	ldrb	w0, [x19]
    6fa4:	7103fc1f 	cmp	w0, #0xff
    6fa8:	54000da0 	b.eq	715c <f23+0x348>  // b.none
    6fac:	52800020 	mov	w0, #0x1                   	// #1
    6fb0:	39000260 	strb	w0, [x19]
    6fb4:	b4000259 	cbz	x25, 6ffc <f23+0x1e8>
    6fb8:	8b191359 	add	x25, x26, x25, lsl #4
    6fbc:	aa1a03f3 	mov	x19, x26
    6fc0:	aa1603f5 	mov	x21, x22
    6fc4:	aa1803f4 	mov	x20, x24
    6fc8:	f9400683 	ldr	x3, [x20, #8]
    6fcc:	f94006a2 	ldr	x2, [x21, #8]
    6fd0:	f9400861 	ldr	x1, [x3, #16]
    6fd4:	f9400840 	ldr	x0, [x2, #16]
    6fd8:	fd400461 	ldr	d1, [x3, #8]
    6fdc:	fd400440 	ldr	d0, [x2, #8]
    6fe0:	97fff884 	bl	51f0 <w107>
    6fe4:	f9000660 	str	x0, [x19, #8]
    6fe8:	f8010e61 	str	x1, [x19, #16]!
    6fec:	f9400a94 	ldr	x20, [x20, #16]
    6ff0:	f9400ab5 	ldr	x21, [x21, #16]
    6ff4:	eb13033f 	cmp	x25, x19
    6ff8:	54fffe81 	b.ne	6fc8 <f23+0x1b4>  // b.any
    6ffc:	aa1803e0 	mov	x0, x24
    7000:	97fffe91 	bl	6a44 <fwp_drop2>
    7004:	aa1603e0 	mov	x0, x22
    7008:	97fffe8f 	bl	6a44 <fwp_drop2>
    700c:	911542f7 	add	x23, x23, #0x550
    7010:	aa1a03e0 	mov	x0, x26
    7014:	97fff8bb 	bl	5300 <w164.constprop.0>
    7018:	aa0103f3 	mov	x19, x1
    701c:	aa0003f4 	mov	x20, x0
    7020:	aa1a03e0 	mov	x0, x26
    7024:	97fffd37 	bl	6500 <fwp_drop4>
    7028:	a900cff4 	stp	x20, x19, [sp, #8]
    702c:	910023e1 	add	x1, sp, #0x8
    7030:	52800000 	mov	w0, #0x0                   	// #0
    7034:	97fff8db 	bl	53a0 <fwp_data.part.0.constprop.0>
    7038:	f949dae1 	ldr	x1, [x23, #5040]
    703c:	aa0003f3 	mov	x19, x0
    7040:	f949eee0 	ldr	x0, [x23, #5080]
    7044:	cb010261 	sub	x1, x19, x1
    7048:	eb00403f 	cmp	x1, x0, lsl #16
    704c:	54000322 	b.cs	70b0 <f23+0x29c>  // b.hs, b.nlast
    7050:	d350fc22 	lsr	x2, x1, #16
    7054:	f949fee3 	ldr	x3, [x23, #5112]
    7058:	8b020842 	add	x2, x2, x2, lsl #2
    705c:	d37df042 	lsl	x2, x2, #3
    7060:	8b020060 	add	x0, x3, x2
    7064:	f9401014 	ldr	x20, [x0, #32]
    7068:	b4000254 	cbz	x20, 70b0 <f23+0x29c>
    706c:	38626862 	ldrb	w2, [x3, x2]
    7070:	7100085f 	cmp	w2, #0x2
    7074:	540003c0 	b.eq	70ec <f23+0x2d8>  // b.none
    7078:	7100045f 	cmp	w2, #0x1
    707c:	540001a1 	b.ne	70b0 <f23+0x29c>  // b.any
    7080:	29430002 	ldp	w2, w0, [x0, #24]
    7084:	92403c21 	and	x1, x1, #0xffff
    7088:	9b027c21 	mul	x1, x1, x2
    708c:	d360fc21 	lsr	x1, x1, #32
    7090:	eb00003f 	cmp	x1, x0
    7094:	540000e2 	b.cs	70b0 <f23+0x29c>  // b.hs, b.nlast
    7098:	8b010294 	add	x20, x20, x1
    709c:	39400280 	ldrb	w0, [x20]
    70a0:	7103fc1f 	cmp	w0, #0xff
    70a4:	54000620 	b.eq	7168 <f23+0x354>  // b.none
    70a8:	52800020 	mov	w0, #0x1                   	// #1
    70ac:	39000280 	strb	w0, [x20]
    70b0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    70b4:	f947f400 	ldr	x0, [x0, #4072]
    70b8:	f9400fe2 	ldr	x2, [sp, #24]
    70bc:	f9400001 	ldr	x1, [x0]
    70c0:	eb010042 	subs	x2, x2, x1
    70c4:	d2800001 	mov	x1, #0x0                   	// #0
    70c8:	540006a1 	b.ne	719c <f23+0x388>  // b.any
    70cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    70d0:	aa1303e0 	mov	x0, x19
    70d4:	a94353f3 	ldp	x19, x20, [sp, #48]
    70d8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    70dc:	a94563f7 	ldp	x23, x24, [sp, #80]
    70e0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    70e4:	9101c3ff 	add	sp, sp, #0x70
    70e8:	d65f03c0 	ret
    70ec:	72003c3f 	tst	w1, #0xffff
    70f0:	54fffe01 	b.ne	70b0 <f23+0x29c>  // b.any
    70f4:	17ffffea 	b	709c <f23+0x288>
    70f8:	72003c3f 	tst	w1, #0xffff
    70fc:	54fff5c1 	b.ne	6fb4 <f23+0x1a0>  // b.any
    7100:	17ffffa8 	b	6fa0 <f23+0x18c>
    7104:	72003c3f 	tst	w1, #0xffff
    7108:	54ffee41 	b.ne	6ed0 <f23+0xbc>  // b.any
    710c:	17ffff6b 	b	6eb8 <f23+0xa4>
    7110:	cb0103e1 	neg	x1, x1
    7114:	eb02003f 	cmp	x1, x2
    7118:	540002e3 	b.cc	7174 <f23+0x360>  // b.lo, b.ul, b.last
    711c:	d503201f 	nop
    7120:	52800041 	mov	w1, #0x2                   	// #2
    7124:	d2800100 	mov	x0, #0x8                   	// #8
    7128:	97fff6b2 	bl	4bf0 <fwp_heap_alloc>
    712c:	aa0003e1 	mov	x1, x0
    7130:	911542e0 	add	x0, x23, #0x550
    7134:	aa0103fa 	mov	x26, x1
    7138:	d2800018 	mov	x24, #0x0                   	// #0
    713c:	f900003f 	str	xzr, [x1]
    7140:	f949d801 	ldr	x1, [x0, #5040]
    7144:	f949ec00 	ldr	x0, [x0, #5080]
    7148:	cb010341 	sub	x1, x26, x1
    714c:	eb00403f 	cmp	x1, x0, lsl #16
    7150:	54fff562 	b.cs	6ffc <f23+0x1e8>  // b.hs, b.nlast
    7154:	d2800019 	mov	x25, #0x0                   	// #0
    7158:	17ffff7e 	b	6f50 <f23+0x13c>
    715c:	aa1303e0 	mov	x0, x19
    7160:	97fff4e4 	bl	44f0 <fwp_rc_forget_slot>
    7164:	17ffff92 	b	6fac <f23+0x198>
    7168:	aa1403e0 	mov	x0, x20
    716c:	97fff4e1 	bl	44f0 <fwp_rc_forget_slot>
    7170:	17ffffce 	b	70a8 <f23+0x294>
    7174:	f949fc62 	ldr	x2, [x3, #5112]
    7178:	d350fc20 	lsr	x0, x1, #16
    717c:	8b000800 	add	x0, x0, x0, lsl #2
    7180:	8b000c42 	add	x2, x2, x0, lsl #3
    7184:	f9401040 	ldr	x0, [x2, #32]
    7188:	b4fffcc0 	cbz	x0, 7120 <f23+0x30c>
    718c:	d2800018 	mov	x24, #0x0                   	// #0
    7190:	17ffff3e 	b	6e88 <f23+0x74>
    7194:	97fff490 	bl	43d4 <fwp_rc_wide_dup>
    7198:	17ffff4e 	b	6ed0 <f23+0xbc>
    719c:	97ffed95 	bl	27f0 <__stack_chk_fail@plt>
    71a0:	d0000020 	adrp	x0, d000 <__modti3+0x310>
    71a4:	9111e000 	add	x0, x0, #0x478
    71a8:	97fff0d6 	bl	3500 <fwp_trap>
    71ac:	d503201f 	nop

00000000000071b0 <fwp_owned_entry23>:
    71b0:	f9400000 	ldr	x0, [x0]
    71b4:	17ffff18 	b	6e14 <f23>
    71b8:	d503201f 	nop
    71bc:	d503201f 	nop

00000000000071c0 <e23>:
    71c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    71c4:	910003fd 	mov	x29, sp
    71c8:	f9000bf3 	str	x19, [sp, #16]
    71cc:	f9400013 	ldr	x19, [x0]
    71d0:	aa1303e0 	mov	x0, x19
    71d4:	97fff8bb 	bl	54c0 <fwp_rc_share>
    71d8:	aa1303e0 	mov	x0, x19
    71dc:	97ffff0e 	bl	6e14 <f23>
    71e0:	aa0003f3 	mov	x19, x0
    71e4:	97fff8b7 	bl	54c0 <fwp_rc_share>
    71e8:	aa1303e0 	mov	x0, x19
    71ec:	f9400bf3 	ldr	x19, [sp, #16]
    71f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71f4:	d65f03c0 	ret
    71f8:	d503201f 	nop
    71fc:	d503201f 	nop

0000000000007200 <f12>:
    7200:	d10443ff 	sub	sp, sp, #0x110
    7204:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7208:	f947f442 	ldr	x2, [x2, #4072]
    720c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    7210:	9102c3fd 	add	x29, sp, #0xb0
    7214:	a90d5bf5 	stp	x21, x22, [sp, #208]
    7218:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    721c:	911542a3 	add	x3, x21, #0x550
    7220:	a90e63f7 	stp	x23, x24, [sp, #224]
    7224:	b00000d7 	adrp	x23, 20000 <__data_start>
    7228:	910102e4 	add	x4, x23, #0x40
    722c:	f949d861 	ldr	x1, [x3, #5040]
    7230:	a90c53f3 	stp	x19, x20, [sp, #192]
    7234:	b00000d4 	adrp	x20, 20000 <__data_start>
    7238:	f949ec65 	ldr	x5, [x3, #5080]
    723c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    7240:	91004294 	add	x20, x20, #0x10
    7244:	a91073fb 	stp	x27, x28, [sp, #256]
    7248:	9100c3fa 	add	x26, sp, #0x30
    724c:	9100a3f9 	add	x25, sp, #0x28
    7250:	f9416086 	ldr	x6, [x4, #704]
    7254:	f9400047 	ldr	x7, [x2]
    7258:	f90057e7 	str	x7, [sp, #168]
    725c:	d2800007 	mov	x7, #0x0                   	// #0
    7260:	d0fffff3 	adrp	x19, 5000 <fwp_p_ad_push.constprop.0+0xdc>
    7264:	12800007 	mov	w7, #0xffffffff            	// #-1
    7268:	913ec262 	add	x2, x19, #0xfb0
    726c:	cb010281 	sub	x1, x20, x1
    7270:	b9002be7 	str	w7, [sp, #40]
    7274:	aa0003f6 	mov	x22, x0
    7278:	a9030be6 	stp	x6, x2, [sp, #48]
    727c:	f90023f9 	str	x25, [sp, #64]
    7280:	f901609a 	str	x26, [x4, #704]
    7284:	eb05403f 	cmp	x1, x5, lsl #16
    7288:	54000342 	b.cs	72f0 <f12+0xf0>  // b.hs, b.nlast
    728c:	d350fc20 	lsr	x0, x1, #16
    7290:	f949fc64 	ldr	x4, [x3, #5112]
    7294:	8b000800 	add	x0, x0, x0, lsl #2
    7298:	d37df002 	lsl	x2, x0, #3
    729c:	8b020083 	add	x3, x4, x2
    72a0:	f9401060 	ldr	x0, [x3, #32]
    72a4:	b4000260 	cbz	x0, 72f0 <f12+0xf0>
    72a8:	38626882 	ldrb	w2, [x4, x2]
    72ac:	7100085f 	cmp	w2, #0x2
    72b0:	54006c80 	b.eq	8040 <f12+0xe40>  // b.none
    72b4:	7100045f 	cmp	w2, #0x1
    72b8:	540001c1 	b.ne	72f0 <f12+0xf0>  // b.any
    72bc:	29430864 	ldp	w4, w2, [x3, #24]
    72c0:	92403c21 	and	x1, x1, #0xffff
    72c4:	9b047c21 	mul	x1, x1, x4
    72c8:	d360fc21 	lsr	x1, x1, #32
    72cc:	eb02003f 	cmp	x1, x2
    72d0:	54000102 	b.cs	72f0 <f12+0xf0>  // b.hs, b.nlast
    72d4:	8b010000 	add	x0, x0, x1
    72d8:	39400001 	ldrb	w1, [x0]
    72dc:	340000a1 	cbz	w1, 72f0 <f12+0xf0>
    72e0:	7103f43f 	cmp	w1, #0xfd
    72e4:	54007348 	b.hi	814c <f12+0xf4c>  // b.pmore
    72e8:	11000421 	add	w1, w1, #0x1
    72ec:	39000001 	strb	w1, [x0]
    72f0:	aa1403e0 	mov	x0, x20
    72f4:	97fffa4f 	bl	5c30 <fwp_closure_drop>
    72f8:	b4006af6 	cbz	x22, 8054 <f12+0xe54>
    72fc:	aa1603e0 	mov	x0, x22
    7300:	d2800001 	mov	x1, #0x0                   	// #0
    7304:	d503201f 	nop
    7308:	f9400800 	ldr	x0, [x0, #16]
    730c:	91000421 	add	x1, x1, #0x1
    7310:	b5ffffc0 	cbnz	x0, 7308 <f12+0x108>
    7314:	aa0103fc 	mov	x28, x1
    7318:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    731c:	eb00003f 	cmp	x1, x0
    7320:	54007488 	b.hi	81b0 <f12+0xfb0>  // b.pmore
    7324:	910102f4 	add	x20, x23, #0x40
    7328:	b942f680 	ldr	w0, [x20, #756]
    732c:	34006760 	cbz	w0, 8018 <f12+0xe18>
    7330:	910102e0 	add	x0, x23, #0x40
    7334:	f9402014 	ldr	x20, [x0, #64]
    7338:	f9404c1b 	ldr	x27, [x0, #152]
    733c:	eb14037f 	cmp	x27, x20
    7340:	5400066a 	b.ge	740c <f12+0x20c>  // b.tcont
    7344:	f94022e1 	ldr	x1, [x23, #64]
    7348:	8b1b0760 	add	x0, x27, x27, lsl #1
    734c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7350:	8b000b60 	add	x0, x27, x0, lsl #2
    7354:	8b000c20 	add	x0, x1, x0, lsl #3
    7358:	b9400401 	ldr	w1, [x0, #4]
    735c:	35000081 	cbnz	w1, 736c <f12+0x16c>
    7360:	b9400001 	ldr	w1, [x0]
    7364:	6b02003f 	cmp	w1, w2
    7368:	54000529 	b.ls	740c <f12+0x20c>  // b.plast
    736c:	9100077b 	add	x27, x27, #0x1
    7370:	9101a000 	add	x0, x0, #0x68
    7374:	eb14037f 	cmp	x27, x20
    7378:	54ffff01 	b.ne	7358 <f12+0x158>  // b.any
    737c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7380:	eb00029f 	cmp	x20, x0
    7384:	540071ec 	b.gt	81c0 <f12+0xfc0>
    7388:	910102e0 	add	x0, x23, #0x40
    738c:	f94022e3 	ldr	x3, [x23, #64]
    7390:	f9404800 	ldr	x0, [x0, #144]
    7394:	eb14001f 	cmp	x0, x20
    7398:	54000201 	b.ne	73d8 <f12+0x1d8>  // b.any
    739c:	b4006c14 	cbz	x20, 811c <f12+0xf1c>
    73a0:	d37ffa98 	lsl	x24, x20, #1
    73a4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    73a8:	eb00031f 	cmp	x24, x0
    73ac:	9a80d318 	csel	x24, x24, x0, le
    73b0:	8b180701 	add	x1, x24, x24, lsl #1
    73b4:	8b010b01 	add	x1, x24, x1, lsl #2
    73b8:	d37df021 	lsl	x1, x1, #3
    73bc:	aa0303e0 	mov	x0, x3
    73c0:	97ffed08 	bl	27e0 <realloc@plt>
    73c4:	aa0003e3 	mov	x3, x0
    73c8:	b40060a0 	cbz	x0, 7fdc <f12+0xddc>
    73cc:	910102e0 	add	x0, x23, #0x40
    73d0:	f90022e3 	str	x3, [x23, #64]
    73d4:	f9004818 	str	x24, [x0, #144]
    73d8:	8b140681 	add	x1, x20, x20, lsl #1
    73dc:	910102e0 	add	x0, x23, #0x40
    73e0:	4f000400 	movi	v0.4s, #0x0
    73e4:	aa1403fb 	mov	x27, x20
    73e8:	8b010a81 	add	x1, x20, x1, lsl #2
    73ec:	91000694 	add	x20, x20, #0x1
    73f0:	f9002014 	str	x20, [x0, #64]
    73f4:	8b010c61 	add	x1, x3, x1, lsl #3
    73f8:	ad000020 	stp	q0, q0, [x1]
    73fc:	ad010020 	stp	q0, q0, [x1, #32]
    7400:	ad020020 	stp	q0, q0, [x1, #64]
    7404:	f900303f 	str	xzr, [x1, #96]
    7408:	14000004 	b	7418 <f12+0x218>
    740c:	eb1b029f 	cmp	x20, x27
    7410:	54fffb60 	b.eq	737c <f12+0x17c>  // b.none
    7414:	f94022e3 	ldr	x3, [x23, #64]
    7418:	8b1b0774 	add	x20, x27, x27, lsl #1
    741c:	d0000020 	adrp	x0, d000 <__modti3+0x310>
    7420:	910b2000 	add	x0, x0, #0x2c8
    7424:	8b140b74 	add	x20, x27, x20, lsl #2
    7428:	f90003e3 	str	x3, [sp]
    742c:	8b140c74 	add	x20, x3, x20, lsl #3
    7430:	f900329f 	str	xzr, [x20, #96]
    7434:	97ffed53 	bl	2980 <getenv@plt>
    7438:	f94003e3 	ldr	x3, [sp]
    743c:	b4000080 	cbz	x0, 744c <f12+0x24c>
    7440:	39400001 	ldrb	w1, [x0]
    7444:	7100c03f 	cmp	w1, #0x30
    7448:	54002e00 	b.eq	7a08 <f12+0x808>  // b.none
    744c:	910102e0 	add	x0, x23, #0x40
    7450:	f9404001 	ldr	x1, [x0, #128]
    7454:	b50060e1 	cbnz	x1, 8070 <f12+0xe70>
    7458:	910102e2 	add	x2, x23, #0x40
    745c:	2f000400 	mvni	v0.2s, #0x0
    7460:	b9400298 	ldr	w24, [x20]
    7464:	52800024 	mov	w4, #0x1                   	// #1
    7468:	91000760 	add	x0, x27, #0x1
    746c:	a900f29c 	stp	x28, x28, [x20, #8]
    7470:	0b040318 	add	w24, w24, w4
    7474:	f9416041 	ldr	x1, [x2, #704]
    7478:	29001298 	stp	w24, w4, [x20]
    747c:	f9002a9f 	str	xzr, [x20, #80]
    7480:	f9004c40 	str	x0, [x2, #152]
    7484:	fd002e80 	str	d0, [x20, #88]
    7488:	b40068e1 	cbz	x1, 81a4 <f12+0xfa4>
    748c:	913ec273 	add	x19, x19, #0xfb0
    7490:	14000003 	b	749c <f12+0x29c>
    7494:	f9400021 	ldr	x1, [x1]
    7498:	b4006861 	cbz	x1, 81a4 <f12+0xfa4>
    749c:	f9400422 	ldr	x2, [x1, #8]
    74a0:	eb13005f 	cmp	x2, x19
    74a4:	54ffff81 	b.ne	7494 <f12+0x294>  // b.any
    74a8:	f9400821 	ldr	x1, [x1, #16]
    74ac:	2a1b03e4 	mov	w4, w27
    74b0:	b9400022 	ldr	w2, [x1]
    74b4:	f9002a81 	str	x1, [x20, #80]
    74b8:	b9005e82 	str	w2, [x20, #92]
    74bc:	37f80082 	tbnz	w2, #31, 74cc <f12+0x2cc>
    74c0:	52800d05 	mov	w5, #0x68                  	// #104
    74c4:	9b250c42 	smaddl	x2, w2, w5, x3
    74c8:	b900585b 	str	w27, [x2, #88]
    74cc:	b9000024 	str	w4, [x1]
    74d0:	d3707f18 	ubfiz	x24, x24, #16, #32
    74d4:	aa000318 	orr	x24, x24, x0
    74d8:	d2800002 	mov	x2, #0x0                   	// #0
    74dc:	aa1603e0 	mov	x0, x22
    74e0:	b40054f6 	cbz	x22, 7f7c <f12+0xd7c>
    74e4:	d503201f 	nop
    74e8:	f9400800 	ldr	x0, [x0, #16]
    74ec:	91000442 	add	x2, x2, #0x1
    74f0:	b5ffffc0 	cbnz	x0, 74e8 <f12+0x2e8>
    74f4:	aa1603e1 	mov	x1, x22
    74f8:	f9400821 	ldr	x1, [x1, #16]
    74fc:	91000400 	add	x0, x0, #0x1
    7500:	b5ffffc1 	cbnz	x1, 74f8 <f12+0x2f8>
    7504:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7508:	eb01001f 	cmp	x0, x1
    750c:	54006408 	b.hi	818c <f12+0xf8c>  // b.pmore
    7510:	f100005f 	cmp	x2, #0x0
    7514:	5400534d 	b.le	7f7c <f12+0xd7c>
    7518:	eb00005f 	cmp	x2, x0
    751c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7520:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7524:	eb01027f 	cmp	x19, x1
    7528:	54006328 	b.hi	818c <f12+0xf8c>  // b.pmore
    752c:	d37ffa74 	lsl	x20, x19, #1
    7530:	52800041 	mov	w1, #0x2                   	// #2
    7534:	91000680 	add	x0, x20, #0x1
    7538:	d37df000 	lsl	x0, x0, #3
    753c:	97fff5ad 	bl	4bf0 <fwp_heap_alloc>
    7540:	aa0003fb 	mov	x27, x0
    7544:	911542a1 	add	x1, x21, #0x550
    7548:	aa0103e0 	mov	x0, x1
    754c:	f9000374 	str	x20, [x27]
    7550:	f949d821 	ldr	x1, [x1, #5040]
    7554:	f949ec00 	ldr	x0, [x0, #5080]
    7558:	cb010361 	sub	x1, x27, x1
    755c:	eb00403f 	cmp	x1, x0, lsl #16
    7560:	54005562 	b.cs	800c <f12+0xe0c>  // b.hs, b.nlast
    7564:	911542a2 	add	x2, x21, #0x550
    7568:	d350fc20 	lsr	x0, x1, #16
    756c:	8b000800 	add	x0, x0, x0, lsl #2
    7570:	f949fc43 	ldr	x3, [x2, #5112]
    7574:	d37df002 	lsl	x2, x0, #3
    7578:	8b020060 	add	x0, x3, x2
    757c:	f9401014 	ldr	x20, [x0, #32]
    7580:	b4000254 	cbz	x20, 75c8 <f12+0x3c8>
    7584:	38626862 	ldrb	w2, [x3, x2]
    7588:	7100085f 	cmp	w2, #0x2
    758c:	54005540 	b.eq	8034 <f12+0xe34>  // b.none
    7590:	7100045f 	cmp	w2, #0x1
    7594:	540001a1 	b.ne	75c8 <f12+0x3c8>  // b.any
    7598:	29430002 	ldp	w2, w0, [x0, #24]
    759c:	92403c21 	and	x1, x1, #0xffff
    75a0:	9b027c21 	mul	x1, x1, x2
    75a4:	d360fc21 	lsr	x1, x1, #32
    75a8:	eb00003f 	cmp	x1, x0
    75ac:	540000e2 	b.cs	75c8 <f12+0x3c8>  // b.hs, b.nlast
    75b0:	8b010294 	add	x20, x20, x1
    75b4:	39400280 	ldrb	w0, [x20]
    75b8:	7103fc1f 	cmp	w0, #0xff
    75bc:	54005bc0 	b.eq	8134 <f12+0xf34>  // b.none
    75c0:	52800020 	mov	w0, #0x1                   	// #1
    75c4:	39000280 	strb	w0, [x20]
    75c8:	b4000233 	cbz	x19, 760c <f12+0x40c>
    75cc:	d3607f04 	lsl	x4, x24, #32
    75d0:	aa1603e2 	mov	x2, x22
    75d4:	f94006c5 	ldr	x5, [x22, #8]
    75d8:	aa0403e3 	mov	x3, x4
    75dc:	91002360 	add	x0, x27, #0x8
    75e0:	d2800001 	mov	x1, #0x0                   	// #0
    75e4:	14000005 	b	75f8 <f12+0x3f8>
    75e8:	f9400445 	ldr	x5, [x2, #8]
    75ec:	ab040023 	adds	x3, x1, x4
    75f0:	91004000 	add	x0, x0, #0x10
    75f4:	54005f26 	b.vs	81d8 <f12+0xfd8>
    75f8:	a9000c05 	stp	x5, x3, [x0]
    75fc:	91000421 	add	x1, x1, #0x1
    7600:	f9400842 	ldr	x2, [x2, #16]
    7604:	eb01027f 	cmp	x19, x1
    7608:	54ffff08 	b.hi	75e8 <f12+0x3e8>  // b.pmore
    760c:	f9400360 	ldr	x0, [x27]
    7610:	f100041f 	cmp	x0, #0x1
    7614:	54004fe9 	b.ls	8010 <f12+0xe10>  // b.plast
    7618:	d341fc00 	lsr	x0, x0, #1
    761c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7620:	d1000401 	sub	x1, x0, #0x1
    7624:	eb02003f 	cmp	x1, x2
    7628:	54005b28 	b.hi	818c <f12+0xf8c>  // b.pmore
    762c:	d37ff83c 	lsl	x28, x1, #1
    7630:	b4004f01 	cbz	x1, 8010 <f12+0xe10>
    7634:	d1002361 	sub	x1, x27, #0x8
    7638:	91002373 	add	x19, x27, #0x8
    763c:	8b001034 	add	x20, x1, x0, lsl #4
    7640:	f9400660 	ldr	x0, [x19, #8]
    7644:	f9400e61 	ldr	x1, [x19, #24]
    7648:	fd400260 	ldr	d0, [x19]
    764c:	fd400a61 	ldr	d1, [x19, #16]
    7650:	97fff6e8 	bl	51f0 <w107>
    7654:	a9000660 	stp	x0, x1, [x19]
    7658:	91004273 	add	x19, x19, #0x10
    765c:	eb14027f 	cmp	x19, x20
    7660:	54ffff01 	b.ne	7640 <f12+0x440>  // b.any
    7664:	f900037c 	str	x28, [x27]
    7668:	aa1b03e0 	mov	x0, x27
    766c:	93407f13 	sxtw	x19, w24
    7670:	97fff724 	bl	5300 <w164.constprop.0>
    7674:	aa0103f4 	mov	x20, x1
    7678:	aa1b03e0 	mov	x0, x27
    767c:	97fffba1 	bl	6500 <fwp_drop4>
    7680:	aa1303e0 	mov	x0, x19
    7684:	97fff06b 	bl	3830 <fwp_tape_of>
    7688:	f9403001 	ldr	x1, [x0, #96]
    768c:	aa0003e8 	mov	x8, x0
    7690:	b5005841 	cbnz	x1, 8198 <f12+0xf98>
    7694:	97ffee1f 	bl	2f10 <fwp_tape_unlink_scope>
    7698:	b9400002 	ldr	w2, [x0]
    769c:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    76a0:	a940801c 	ldp	x28, x0, [x0, #8]
    76a4:	b900051f 	str	wzr, [x8, #4]
    76a8:	a941910a 	ldp	x10, x4, [x8, #24]
    76ac:	a9429905 	ldp	x5, x6, [x8, #40]
    76b0:	a9438d07 	ldp	x7, x3, [x8, #56]
    76b4:	f940251b 	ldr	x27, [x8, #72]
    76b8:	6b01005f 	cmp	w2, w1
    76bc:	54000108 	b.hi	76dc <f12+0x4dc>  // b.pmore
    76c0:	910102e2 	add	x2, x23, #0x40
    76c4:	92403e61 	and	x1, x19, #0xffff
    76c8:	d1000421 	sub	x1, x1, #0x1
    76cc:	f9404c49 	ldr	x9, [x2, #152]
    76d0:	eb09003f 	cmp	x1, x9
    76d4:	5400004a 	b.ge	76dc <f12+0x4dc>  // b.tcont
    76d8:	f9004c41 	str	x1, [x2, #152]
    76dc:	4f000400 	movi	v0.4s, #0x0
    76e0:	910102e9 	add	x9, x23, #0x40
    76e4:	f9000d1f 	str	xzr, [x8, #24]
    76e8:	910123e1 	add	x1, sp, #0x48
    76ec:	910183f8 	add	x24, sp, #0x60
    76f0:	b0ffffe2 	adrp	x2, 4000 <fwp_wake_io+0x3c>
    76f4:	f941612b 	ldr	x11, [x9, #704]
    76f8:	3c808100 	stur	q0, [x8, #8]
    76fc:	91020042 	add	x2, x2, #0x80
    7700:	ad010100 	stp	q0, q0, [x8, #32]
    7704:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    7708:	a9048beb 	stp	x11, x2, [sp, #72]
    770c:	a90593f8 	stp	x24, x4, [sp, #88]
    7710:	a9069be5 	stp	x5, x6, [sp, #104]
    7714:	a9078fe7 	stp	x7, x3, [sp, #120]
    7718:	a908efea 	stp	x10, x27, [sp, #136]
    771c:	f9016121 	str	x1, [x9, #704]
    7720:	b7f849f4 	tbnz	x20, #63, 805c <f12+0xe5c>
    7724:	eb94827f 	cmp	x19, x20, asr #32
    7728:	54005261 	b.ne	8174 <f12+0xf74>  // b.any
    772c:	92407e93 	and	x19, x20, #0xffffffff
    7730:	eb34401f 	cmp	x0, w20, uxtw
    7734:	540051ad 	b.le	8168 <f12+0xf68>
    7738:	eb13039f 	cmp	x28, x19
    773c:	9a93c793 	csinc	x19, x28, x19, gt
    7740:	eb13037f 	cmp	x27, x19
    7744:	540043ca 	b.ge	7fbc <f12+0xdbc>  // b.tcont
    7748:	f100037f 	cmp	x27, #0x0
    774c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7750:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7754:	14000004 	b	7764 <f12+0x564>
    7758:	eb01037f 	cmp	x27, x1
    775c:	d37ffb7b 	lsl	x27, x27, #1
    7760:	9a93d37b 	csel	x27, x27, x19, le
    7764:	eb13037f 	cmp	x27, x19
    7768:	54ffff8b 	b.lt	7758 <f12+0x558>  // b.tstop
    776c:	a90017e4 	stp	x4, x5, [sp]
    7770:	a9011fe6 	stp	x6, x7, [sp, #16]
    7774:	b4004b03 	cbz	x3, 80d4 <f12+0xed4>
    7778:	aa0303e0 	mov	x0, x3
    777c:	d37df361 	lsl	x1, x27, #3
    7780:	97ffec18 	bl	27e0 <realloc@plt>
    7784:	aa0003e3 	mov	x3, x0
    7788:	a94017e4 	ldp	x4, x5, [sp]
    778c:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7790:	b4004163 	cbz	x3, 7fbc <f12+0xdbc>
    7794:	f90043e3 	str	x3, [sp, #128]
    7798:	f9004bfb 	str	x27, [sp, #144]
    779c:	b50013d3 	cbnz	x19, 7a14 <f12+0x814>
    77a0:	b7f800d4 	tbnz	x20, #63, 77b8 <f12+0x5b8>
    77a4:	92407e94 	and	x20, x20, #0xffffffff
    77a8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    77ac:	fc747860 	ldr	d0, [x3, x20, lsl #3]
    77b0:	1e612800 	fadd	d0, d0, d1
    77b4:	fc347860 	str	d0, [x3, x20, lsl #3]
    77b8:	d1000673 	sub	x19, x19, #0x1
    77bc:	d1000788 	sub	x8, x28, #0x1
    77c0:	eb13039f 	cmp	x28, x19
    77c4:	540003ac 	b.gt	7838 <f12+0x638>
    77c8:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    77cc:	1e602008 	fcmp	d0, #0.0
    77d0:	540002e0 	b.eq	782c <f12+0x62c>  // b.none
    77d4:	cb1c0be0 	neg	x0, x28, lsl #2
    77d8:	cb1c03e2 	neg	x2, x28
    77dc:	8b000081 	add	x1, x4, x0
    77e0:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    77e4:	37f80101 	tbnz	w1, #31, 7804 <f12+0x604>
    77e8:	8b020cc9 	add	x9, x6, x2, lsl #3
    77ec:	93407c21 	sxtw	x1, w1
    77f0:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    77f4:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    77f8:	1e620802 	fmul	d2, d0, d2
    77fc:	1e622821 	fadd	d1, d1, d2
    7800:	fc217861 	str	d1, [x3, x1, lsl #3]
    7804:	8b0000a0 	add	x0, x5, x0
    7808:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    780c:	37f80100 	tbnz	w0, #31, 782c <f12+0x62c>
    7810:	8b020ce2 	add	x2, x7, x2, lsl #3
    7814:	93407c00 	sxtw	x0, w0
    7818:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    781c:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    7820:	1e620800 	fmul	d0, d0, d2
    7824:	1e602820 	fadd	d0, d1, d0
    7828:	fc207860 	str	d0, [x3, x0, lsl #3]
    782c:	d1000673 	sub	x19, x19, #0x1
    7830:	eb13011f 	cmp	x8, x19
    7834:	54fffca1 	b.ne	77c8 <f12+0x5c8>  // b.any
    7838:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    783c:	eb00039f 	cmp	x28, x0
    7840:	54004c68 	b.hi	81cc <f12+0xfcc>  // b.pmore
    7844:	91000780 	add	x0, x28, #0x1
    7848:	52800041 	mov	w1, #0x2                   	// #2
    784c:	f90003e3 	str	x3, [sp]
    7850:	d37df000 	lsl	x0, x0, #3
    7854:	97fff4e7 	bl	4bf0 <fwp_heap_alloc>
    7858:	aa0003e2 	mov	x2, x0
    785c:	aa0003f3 	mov	x19, x0
    7860:	f94003e3 	ldr	x3, [sp]
    7864:	d2800001 	mov	x1, #0x0                   	// #0
    7868:	f800845c 	str	x28, [x2], #8
    786c:	b40000dc 	cbz	x28, 7884 <f12+0x684>
    7870:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    7874:	f8217840 	str	x0, [x2, x1, lsl #3]
    7878:	91000421 	add	x1, x1, #0x1
    787c:	eb01039f 	cmp	x28, x1
    7880:	54ffff81 	b.ne	7870 <f12+0x670>  // b.any
    7884:	910102e1 	add	x1, x23, #0x40
    7888:	aa1803e0 	mov	x0, x24
    788c:	f94027f8 	ldr	x24, [sp, #72]
    7890:	f9016038 	str	x24, [x1, #704]
    7894:	97fff1fb 	bl	4080 <fwp_tape_buffers_release>
    7898:	911542a2 	add	x2, x21, #0x550
    789c:	f949d841 	ldr	x1, [x2, #5040]
    78a0:	f949ec40 	ldr	x0, [x2, #5080]
    78a4:	cb010261 	sub	x1, x19, x1
    78a8:	eb00403f 	cmp	x1, x0, lsl #16
    78ac:	54000322 	b.cs	7910 <f12+0x710>  // b.hs, b.nlast
    78b0:	d350fc20 	lsr	x0, x1, #16
    78b4:	f949fc43 	ldr	x3, [x2, #5112]
    78b8:	8b000800 	add	x0, x0, x0, lsl #2
    78bc:	d37df002 	lsl	x2, x0, #3
    78c0:	8b020060 	add	x0, x3, x2
    78c4:	f9401014 	ldr	x20, [x0, #32]
    78c8:	b4000254 	cbz	x20, 7910 <f12+0x710>
    78cc:	38626862 	ldrb	w2, [x3, x2]
    78d0:	7100085f 	cmp	w2, #0x2
    78d4:	54003c80 	b.eq	8064 <f12+0xe64>  // b.none
    78d8:	7100045f 	cmp	w2, #0x1
    78dc:	540001a1 	b.ne	7910 <f12+0x710>  // b.any
    78e0:	29430002 	ldp	w2, w0, [x0, #24]
    78e4:	92403c21 	and	x1, x1, #0xffff
    78e8:	9b027c21 	mul	x1, x1, x2
    78ec:	d360fc21 	lsr	x1, x1, #32
    78f0:	eb00003f 	cmp	x1, x0
    78f4:	540000e2 	b.cs	7910 <f12+0x710>  // b.hs, b.nlast
    78f8:	8b010294 	add	x20, x20, x1
    78fc:	39400280 	ldrb	w0, [x20]
    7900:	7103fc1f 	cmp	w0, #0xff
    7904:	54004120 	b.eq	8128 <f12+0xf28>  // b.none
    7908:	52800020 	mov	w0, #0x1                   	// #1
    790c:	39000280 	strb	w0, [x20]
    7910:	eb1a031f 	cmp	x24, x26
    7914:	54004641 	b.ne	81dc <f12+0xfdc>  // b.any
    7918:	f9401be1 	ldr	x1, [sp, #48]
    791c:	910102f7 	add	x23, x23, #0x40
    7920:	aa1903e0 	mov	x0, x25
    7924:	f90162e1 	str	x1, [x23, #704]
    7928:	97fff9a2 	bl	5fb0 <fwp_tape_scope_release>
    792c:	f9400260 	ldr	x0, [x19]
    7930:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7934:	b7f82ca0 	tbnz	x0, #63, 7ec8 <f12+0xcc8>
    7938:	911542a2 	add	x2, x21, #0x550
    793c:	f949d840 	ldr	x0, [x2, #5040]
    7940:	f949ec41 	ldr	x1, [x2, #5080]
    7944:	cb000260 	sub	x0, x19, x0
    7948:	eb01401f 	cmp	x0, x1, lsl #16
    794c:	54002be2 	b.cs	7ec8 <f12+0xcc8>  // b.hs, b.nlast
    7950:	d350fc01 	lsr	x1, x0, #16
    7954:	f949fc44 	ldr	x4, [x2, #5112]
    7958:	8b010821 	add	x1, x1, x1, lsl #2
    795c:	d37df021 	lsl	x1, x1, #3
    7960:	8b010083 	add	x3, x4, x1
    7964:	f9401062 	ldr	x2, [x3, #32]
    7968:	b4002b02 	cbz	x2, 7ec8 <f12+0xcc8>
    796c:	38616881 	ldrb	w1, [x4, x1]
    7970:	7100083f 	cmp	w1, #0x2
    7974:	54002a40 	b.eq	7ebc <f12+0xcbc>  // b.none
    7978:	7100043f 	cmp	w1, #0x1
    797c:	54002a61 	b.ne	7ec8 <f12+0xcc8>  // b.any
    7980:	29430464 	ldp	w4, w1, [x3, #24]
    7984:	92403c00 	and	x0, x0, #0xffff
    7988:	9b047c00 	mul	x0, x0, x4
    798c:	d360fc00 	lsr	x0, x0, #32
    7990:	eb01001f 	cmp	x0, x1
    7994:	540029a2 	b.cs	7ec8 <f12+0xcc8>  // b.hs, b.nlast
    7998:	8b000042 	add	x2, x2, x0
    799c:	39400040 	ldrb	w0, [x2]
    79a0:	7100041f 	cmp	w0, #0x1
    79a4:	54002921 	b.ne	7ec8 <f12+0xcc8>  // b.any
    79a8:	aa1303fa 	mov	x26, x19
    79ac:	d2800000 	mov	x0, #0x0                   	// #0
    79b0:	f90003f3 	str	x19, [sp]
    79b4:	f94003e1 	ldr	x1, [sp]
    79b8:	91002023 	add	x3, x1, #0x8
    79bc:	d2800001 	mov	x1, #0x0                   	// #0
    79c0:	b40003f4 	cbz	x20, 7a3c <f12+0x83c>
    79c4:	d0000022 	adrp	x2, d000 <__modti3+0x310>
    79c8:	91002265 	add	x5, x19, #0x8
    79cc:	fd46b041 	ldr	d1, [x2, #3424]
    79d0:	14000009 	b	79f4 <f12+0x7f4>
    79d4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    79d8:	f9400342 	ldr	x2, [x26]
    79dc:	1e600820 	fmul	d0, d1, d0
    79e0:	b7f83d02 	tbnz	x2, #63, 8180 <f12+0xf80>
    79e4:	91000421 	add	x1, x1, #0x1
    79e8:	fc008460 	str	d0, [x3], #8
    79ec:	eb01029f 	cmp	x20, x1
    79f0:	54000260 	b.eq	7a3c <f12+0x83c>  // b.none
    79f4:	f9400264 	ldr	x4, [x19]
    79f8:	aa0503e2 	mov	x2, x5
    79fc:	b6fffec4 	tbz	x4, #63, 79d4 <f12+0x7d4>
    7a00:	f9400a62 	ldr	x2, [x19, #16]
    7a04:	17fffff4 	b	79d4 <f12+0x7d4>
    7a08:	39400400 	ldrb	w0, [x0, #1]
    7a0c:	34ffd260 	cbz	w0, 7458 <f12+0x258>
    7a10:	17fffe8f 	b	744c <f12+0x24c>
    7a14:	aa0303e0 	mov	x0, x3
    7a18:	d37df262 	lsl	x2, x19, #3
    7a1c:	52800001 	mov	w1, #0x0                   	// #0
    7a20:	a90017e4 	stp	x4, x5, [sp]
    7a24:	a9011fe6 	stp	x6, x7, [sp, #16]
    7a28:	97ffeb66 	bl	27c0 <memset@plt>
    7a2c:	aa0003e3 	mov	x3, x0
    7a30:	a94017e4 	ldp	x4, x5, [sp]
    7a34:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7a38:	17ffff5a 	b	77a0 <f12+0x5a0>
    7a3c:	97fffab1 	bl	6500 <fwp_drop4>
    7a40:	aa1603e1 	mov	x1, x22
    7a44:	d2800002 	mov	x2, #0x0                   	// #0
    7a48:	b4003556 	cbz	x22, 80f0 <f12+0xef0>
    7a4c:	d503201f 	nop
    7a50:	f9400821 	ldr	x1, [x1, #16]
    7a54:	91000442 	add	x2, x2, #0x1
    7a58:	b5ffffc1 	cbnz	x1, 7a50 <f12+0x850>
    7a5c:	f9400343 	ldr	x3, [x26]
    7a60:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7a64:	b7f81f43 	tbnz	x3, #63, 7e4c <f12+0xc4c>
    7a68:	911542a1 	add	x1, x21, #0x550
    7a6c:	f94003e4 	ldr	x4, [sp]
    7a70:	f949d820 	ldr	x0, [x1, #5040]
    7a74:	f949ec21 	ldr	x1, [x1, #5080]
    7a78:	cb000080 	sub	x0, x4, x0
    7a7c:	eb01401f 	cmp	x0, x1, lsl #16
    7a80:	54001e62 	b.cs	7e4c <f12+0xc4c>  // b.hs, b.nlast
    7a84:	911542a4 	add	x4, x21, #0x550
    7a88:	d350fc01 	lsr	x1, x0, #16
    7a8c:	8b010821 	add	x1, x1, x1, lsl #2
    7a90:	f949fc86 	ldr	x6, [x4, #5112]
    7a94:	d37df021 	lsl	x1, x1, #3
    7a98:	8b0100c5 	add	x5, x6, x1
    7a9c:	f94010a4 	ldr	x4, [x5, #32]
    7aa0:	b4001d44 	cbz	x4, 7e48 <f12+0xc48>
    7aa4:	386168c1 	ldrb	w1, [x6, x1]
    7aa8:	7100083f 	cmp	w1, #0x2
    7aac:	54001ca0 	b.eq	7e40 <f12+0xc40>  // b.none
    7ab0:	7100043f 	cmp	w1, #0x1
    7ab4:	54001ca1 	b.ne	7e48 <f12+0xc48>  // b.any
    7ab8:	294304a6 	ldp	w6, w1, [x5, #24]
    7abc:	92403c00 	and	x0, x0, #0xffff
    7ac0:	9b067c00 	mul	x0, x0, x6
    7ac4:	d360fc00 	lsr	x0, x0, #32
    7ac8:	eb01001f 	cmp	x0, x1
    7acc:	54001be2 	b.cs	7e48 <f12+0xc48>  // b.hs, b.nlast
    7ad0:	8b000084 	add	x4, x4, x0
    7ad4:	39400098 	ldrb	w24, [x4]
    7ad8:	7100071f 	cmp	w24, #0x1
    7adc:	54001b61 	b.ne	7e48 <f12+0xc48>  // b.any
    7ae0:	b9000bf8 	str	w24, [sp, #8]
    7ae4:	eb1c005f 	cmp	x2, x28
    7ae8:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7aec:	91002359 	add	x25, x26, #0x8
    7af0:	b400337c 	cbz	x28, 815c <f12+0xf5c>
    7af4:	f94003e0 	ldr	x0, [sp]
    7af8:	d37df385 	lsl	x5, x28, #3
    7afc:	aa1603e2 	mov	x2, x22
    7b00:	d2800001 	mov	x1, #0x0                   	// #0
    7b04:	91002000 	add	x0, x0, #0x8
    7b08:	1400000a 	b	7b30 <f12+0x930>
    7b0c:	fc616881 	ldr	d1, [x4, x1]
    7b10:	fd400440 	ldr	d0, [x2, #8]
    7b14:	1e613800 	fsub	d0, d0, d1
    7b18:	fc216b20 	str	d0, [x25, x1]
    7b1c:	91002021 	add	x1, x1, #0x8
    7b20:	f9400842 	ldr	x2, [x2, #16]
    7b24:	eb05003f 	cmp	x1, x5
    7b28:	540001c0 	b.eq	7b60 <f12+0x960>  // b.none
    7b2c:	f9400343 	ldr	x3, [x26]
    7b30:	aa0003e4 	mov	x4, x0
    7b34:	b6fffec3 	tbz	x3, #63, 7b0c <f12+0x90c>
    7b38:	f94003e3 	ldr	x3, [sp]
    7b3c:	fd400440 	ldr	d0, [x2, #8]
    7b40:	f9400864 	ldr	x4, [x3, #16]
    7b44:	fc616881 	ldr	d1, [x4, x1]
    7b48:	1e613800 	fsub	d0, d0, d1
    7b4c:	fc216b20 	str	d0, [x25, x1]
    7b50:	91002021 	add	x1, x1, #0x8
    7b54:	f9400842 	ldr	x2, [x2, #16]
    7b58:	eb05003f 	cmp	x1, x5
    7b5c:	54fffe81 	b.ne	7b2c <f12+0x92c>  // b.any
    7b60:	b4002fb6 	cbz	x22, 8154 <f12+0xf54>
    7b64:	911542a0 	add	x0, x21, #0x550
    7b68:	aa1603e2 	mov	x2, x22
    7b6c:	d280001a 	mov	x26, #0x0                   	// #0
    7b70:	f949ec06 	ldr	x6, [x0, #5080]
    7b74:	f949d807 	ldr	x7, [x0, #5040]
    7b78:	f949fc05 	ldr	x5, [x0, #5112]
    7b7c:	d370bcc6 	lsl	x6, x6, #16
    7b80:	14000006 	b	7b98 <f12+0x998>
    7b84:	f9400842 	ldr	x2, [x2, #16]
    7b88:	9100075a 	add	x26, x26, #0x1
    7b8c:	f100005f 	cmp	x2, #0x0
    7b90:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7b94:	54001ee9 	b.ls	7f70 <f12+0xd70>  // b.plast
    7b98:	cb070040 	sub	x0, x2, x7
    7b9c:	eb06001f 	cmp	x0, x6
    7ba0:	540002c2 	b.cs	7bf8 <f12+0x9f8>  // b.hs, b.nlast
    7ba4:	d350fc01 	lsr	x1, x0, #16
    7ba8:	8b010821 	add	x1, x1, x1, lsl #2
    7bac:	d37df021 	lsl	x1, x1, #3
    7bb0:	8b0100a4 	add	x4, x5, x1
    7bb4:	f9401083 	ldr	x3, [x4, #32]
    7bb8:	b4000203 	cbz	x3, 7bf8 <f12+0x9f8>
    7bbc:	386168a1 	ldrb	w1, [x5, x1]
    7bc0:	7100083f 	cmp	w1, #0x2
    7bc4:	54000de0 	b.eq	7d80 <f12+0xb80>  // b.none
    7bc8:	7100043f 	cmp	w1, #0x1
    7bcc:	54000161 	b.ne	7bf8 <f12+0x9f8>  // b.any
    7bd0:	29430488 	ldp	w8, w1, [x4, #24]
    7bd4:	92403c00 	and	x0, x0, #0xffff
    7bd8:	9b087c00 	mul	x0, x0, x8
    7bdc:	d360fc00 	lsr	x0, x0, #32
    7be0:	eb01001f 	cmp	x0, x1
    7be4:	540000a2 	b.cs	7bf8 <f12+0x9f8>  // b.hs, b.nlast
    7be8:	8b000063 	add	x3, x3, x0
    7bec:	39400060 	ldrb	w0, [x3]
    7bf0:	7100041f 	cmp	w0, #0x1
    7bf4:	54fffc80 	b.eq	7b84 <f12+0x984>  // b.none
    7bf8:	eb1c035f 	cmp	x26, x28
    7bfc:	54000ca2 	b.cs	7d90 <f12+0xb90>  // b.hs, b.nlast
    7c00:	d1002337 	sub	x23, x25, #0x8
    7c04:	910263f4 	add	x20, sp, #0x98
    7c08:	911542b8 	add	x24, x21, #0x550
    7c0c:	d2800013 	mov	x19, #0x0                   	// #0
    7c10:	14000012 	b	7c58 <f12+0xa58>
    7c14:	7100045f 	cmp	w2, #0x1
    7c18:	540001a1 	b.ne	7c4c <f12+0xa4c>  // b.any
    7c1c:	29430002 	ldp	w2, w0, [x0, #24]
    7c20:	92403c21 	and	x1, x1, #0xffff
    7c24:	9b027c21 	mul	x1, x1, x2
    7c28:	d360fc21 	lsr	x1, x1, #32
    7c2c:	eb00003f 	cmp	x1, x0
    7c30:	540000e2 	b.cs	7c4c <f12+0xa4c>  // b.hs, b.nlast
    7c34:	8b01037b 	add	x27, x27, x1
    7c38:	39400360 	ldrb	w0, [x27]
    7c3c:	7103fc1f 	cmp	w0, #0xff
    7c40:	54001b80 	b.eq	7fb0 <f12+0xdb0>  // b.none
    7c44:	52800020 	mov	w0, #0x1                   	// #1
    7c48:	39000360 	strb	w0, [x27]
    7c4c:	d100079c 	sub	x28, x28, #0x1
    7c50:	eb1c035f 	cmp	x26, x28
    7c54:	54000362 	b.cs	7cc0 <f12+0xac0>  // b.hs, b.nlast
    7c58:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    7c5c:	aa1403e1 	mov	x1, x20
    7c60:	52800020 	mov	w0, #0x1                   	// #1
    7c64:	a909cfe2 	stp	x2, x19, [sp, #152]
    7c68:	97fff5ce 	bl	53a0 <fwp_data.part.0.constprop.0>
    7c6c:	aa0003f3 	mov	x19, x0
    7c70:	f949db01 	ldr	x1, [x24, #5040]
    7c74:	f949ef00 	ldr	x0, [x24, #5080]
    7c78:	cb010261 	sub	x1, x19, x1
    7c7c:	eb00403f 	cmp	x1, x0, lsl #16
    7c80:	54fffe62 	b.cs	7c4c <f12+0xa4c>  // b.hs, b.nlast
    7c84:	d350fc22 	lsr	x2, x1, #16
    7c88:	f949ff03 	ldr	x3, [x24, #5112]
    7c8c:	8b020842 	add	x2, x2, x2, lsl #2
    7c90:	d37df042 	lsl	x2, x2, #3
    7c94:	8b020060 	add	x0, x3, x2
    7c98:	f940101b 	ldr	x27, [x0, #32]
    7c9c:	b4fffd9b 	cbz	x27, 7c4c <f12+0xa4c>
    7ca0:	38626862 	ldrb	w2, [x3, x2]
    7ca4:	7100085f 	cmp	w2, #0x2
    7ca8:	54fffb61 	b.ne	7c14 <f12+0xa14>  // b.any
    7cac:	72003c3f 	tst	w1, #0xffff
    7cb0:	54fffc40 	b.eq	7c38 <f12+0xa38>  // b.none
    7cb4:	d100079c 	sub	x28, x28, #0x1
    7cb8:	eb1c035f 	cmp	x26, x28
    7cbc:	54fffce3 	b.cc	7c58 <f12+0xa58>  // b.lo, b.ul, b.last
    7cc0:	b50006ba 	cbnz	x26, 7d94 <f12+0xb94>
    7cc4:	b9400be0 	ldr	w0, [sp, #8]
    7cc8:	d2800038 	mov	x24, #0x1                   	// #1
    7ccc:	d280001b 	mov	x27, #0x0                   	// #0
    7cd0:	7100001f 	cmp	w0, #0x0
    7cd4:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7cd8:	b40007db 	cbz	x27, 7dd0 <f12+0xbd0>
    7cdc:	d100077b 	sub	x27, x27, #0x1
    7ce0:	911542b5 	add	x21, x21, #0x550
    7ce4:	d503201f 	nop
    7ce8:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7cec:	aa1403e1 	mov	x1, x20
    7cf0:	52800020 	mov	w0, #0x1                   	// #1
    7cf4:	a909cfe2 	stp	x2, x19, [sp, #152]
    7cf8:	97fff5aa 	bl	53a0 <fwp_data.part.0.constprop.0>
    7cfc:	aa0003f3 	mov	x19, x0
    7d00:	f949daa1 	ldr	x1, [x21, #5040]
    7d04:	f949eea0 	ldr	x0, [x21, #5080]
    7d08:	cb010261 	sub	x1, x19, x1
    7d0c:	eb00403f 	cmp	x1, x0, lsl #16
    7d10:	54000302 	b.cs	7d70 <f12+0xb70>  // b.hs, b.nlast
    7d14:	d350fc22 	lsr	x2, x1, #16
    7d18:	f949fea3 	ldr	x3, [x21, #5112]
    7d1c:	8b020842 	add	x2, x2, x2, lsl #2
    7d20:	d37df042 	lsl	x2, x2, #3
    7d24:	8b020060 	add	x0, x3, x2
    7d28:	f940101a 	ldr	x26, [x0, #32]
    7d2c:	b400023a 	cbz	x26, 7d70 <f12+0xb70>
    7d30:	38626862 	ldrb	w2, [x3, x2]
    7d34:	7100085f 	cmp	w2, #0x2
    7d38:	540007e0 	b.eq	7e34 <f12+0xc34>  // b.none
    7d3c:	7100045f 	cmp	w2, #0x1
    7d40:	54000181 	b.ne	7d70 <f12+0xb70>  // b.any
    7d44:	29430002 	ldp	w2, w0, [x0, #24]
    7d48:	92403c21 	and	x1, x1, #0xffff
    7d4c:	9b027c21 	mul	x1, x1, x2
    7d50:	d360fc21 	lsr	x1, x1, #32
    7d54:	eb00003f 	cmp	x1, x0
    7d58:	540000c2 	b.cs	7d70 <f12+0xb70>  // b.hs, b.nlast
    7d5c:	8b01035a 	add	x26, x26, x1
    7d60:	39400340 	ldrb	w0, [x26]
    7d64:	7103fc1f 	cmp	w0, #0xff
    7d68:	54000600 	b.eq	7e28 <f12+0xc28>  // b.none
    7d6c:	39000358 	strb	w24, [x26]
    7d70:	d100077b 	sub	x27, x27, #0x1
    7d74:	b100077f 	cmn	x27, #0x1
    7d78:	54fffb81 	b.ne	7ce8 <f12+0xae8>  // b.any
    7d7c:	14000015 	b	7dd0 <f12+0xbd0>
    7d80:	72003c1f 	tst	w0, #0xffff
    7d84:	54fff340 	b.eq	7bec <f12+0x9ec>  // b.none
    7d88:	eb1c035f 	cmp	x26, x28
    7d8c:	54fff3a3 	b.cc	7c00 <f12+0xa00>  // b.lo, b.ul, b.last
    7d90:	d2800013 	mov	x19, #0x0                   	// #0
    7d94:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    7d98:	aa1903e1 	mov	x1, x25
    7d9c:	aa1603e0 	mov	x0, x22
    7da0:	f8408422 	ldr	x2, [x1], #8
    7da4:	f9000402 	str	x2, [x0, #8]
    7da8:	aa0003e2 	mov	x2, x0
    7dac:	f9400800 	ldr	x0, [x0, #16]
    7db0:	eb1a003f 	cmp	x1, x26
    7db4:	54ffff61 	b.ne	7da0 <f12+0xba0>  // b.any
    7db8:	b9400be1 	ldr	w1, [sp, #8]
    7dbc:	f9000853 	str	x19, [x2, #16]
    7dc0:	aa1603f3 	mov	x19, x22
    7dc4:	aa0003f6 	mov	x22, x0
    7dc8:	34000041 	cbz	w1, 7dd0 <f12+0xbd0>
    7dcc:	d2800019 	mov	x25, #0x0                   	// #0
    7dd0:	aa1903e0 	mov	x0, x25
    7dd4:	97fff267 	bl	4770 <fwp_mem_free>
    7dd8:	f94003e0 	ldr	x0, [sp]
    7ddc:	97fff9c9 	bl	6500 <fwp_drop4>
    7de0:	aa1603e0 	mov	x0, x22
    7de4:	97fff737 	bl	5ac0 <fwp_drop0>
    7de8:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7dec:	f947f400 	ldr	x0, [x0, #4072]
    7df0:	f94057e2 	ldr	x2, [sp, #168]
    7df4:	f9400001 	ldr	x1, [x0]
    7df8:	eb010042 	subs	x2, x2, x1
    7dfc:	d2800001 	mov	x1, #0x0                   	// #0
    7e00:	54001de1 	b.ne	81bc <f12+0xfbc>  // b.any
    7e04:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7e08:	aa1303e0 	mov	x0, x19
    7e0c:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7e10:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7e14:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7e18:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    7e20:	910443ff 	add	sp, sp, #0x110
    7e24:	d65f03c0 	ret
    7e28:	aa1a03e0 	mov	x0, x26
    7e2c:	97fff1b1 	bl	44f0 <fwp_rc_forget_slot>
    7e30:	17ffffcf 	b	7d6c <f12+0xb6c>
    7e34:	72003c3f 	tst	w1, #0xffff
    7e38:	54fff9c1 	b.ne	7d70 <f12+0xb70>  // b.any
    7e3c:	17ffffc9 	b	7d60 <f12+0xb60>
    7e40:	72003c1f 	tst	w0, #0xffff
    7e44:	54ffe480 	b.eq	7ad4 <f12+0x8d4>  // b.none
    7e48:	b4001336 	cbz	x22, 80ac <f12+0xeac>
    7e4c:	aa1603f3 	mov	x19, x22
    7e50:	d2800014 	mov	x20, #0x0                   	// #0
    7e54:	d503201f 	nop
    7e58:	f9400a73 	ldr	x19, [x19, #16]
    7e5c:	aa1403e0 	mov	x0, x20
    7e60:	91000694 	add	x20, x20, #0x1
    7e64:	b5ffffb3 	cbnz	x19, 7e58 <f12+0xc58>
    7e68:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7e6c:	eb01029f 	cmp	x20, x1
    7e70:	540018e8 	b.hi	818c <f12+0xf8c>  // b.pmore
    7e74:	91000800 	add	x0, x0, #0x2
    7e78:	52800041 	mov	w1, #0x2                   	// #2
    7e7c:	d37df000 	lsl	x0, x0, #3
    7e80:	97fff35c 	bl	4bf0 <fwp_heap_alloc>
    7e84:	eb1c029f 	cmp	x20, x28
    7e88:	aa0003f9 	mov	x25, x0
    7e8c:	9a9c929c 	csel	x28, x20, x28, ls	// ls = plast
    7e90:	aa1603e1 	mov	x1, x22
    7e94:	d503201f 	nop
    7e98:	f9400420 	ldr	x0, [x1, #8]
    7e9c:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7ea0:	91000673 	add	x19, x19, #0x1
    7ea4:	f9400821 	ldr	x1, [x1, #16]
    7ea8:	b5ffff81 	cbnz	x1, 7e98 <f12+0xc98>
    7eac:	b400109c 	cbz	x28, 80bc <f12+0xebc>
    7eb0:	f9400343 	ldr	x3, [x26]
    7eb4:	b9000bff 	str	wzr, [sp, #8]
    7eb8:	17ffff0f 	b	7af4 <f12+0x8f4>
    7ebc:	72003c1f 	tst	w0, #0xffff
    7ec0:	54ffd6e0 	b.eq	799c <f12+0x79c>  // b.none
    7ec4:	d503201f 	nop
    7ec8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7ecc:	eb00029f 	cmp	x20, x0
    7ed0:	540017e8 	b.hi	81cc <f12+0xfcc>  // b.pmore
    7ed4:	91000680 	add	x0, x20, #0x1
    7ed8:	52800021 	mov	w1, #0x1                   	// #1
    7edc:	d37df000 	lsl	x0, x0, #3
    7ee0:	97fff344 	bl	4bf0 <fwp_heap_alloc>
    7ee4:	911542a2 	add	x2, x21, #0x550
    7ee8:	f9000014 	str	x20, [x0]
    7eec:	aa0003fa 	mov	x26, x0
    7ef0:	f90003fa 	str	x26, [sp]
    7ef4:	f949d841 	ldr	x1, [x2, #5040]
    7ef8:	f949ec40 	ldr	x0, [x2, #5080]
    7efc:	cb010341 	sub	x1, x26, x1
    7f00:	eb00403f 	cmp	x1, x0, lsl #16
    7f04:	54000322 	b.cs	7f68 <f12+0xd68>  // b.hs, b.nlast
    7f08:	d350fc20 	lsr	x0, x1, #16
    7f0c:	f949fc43 	ldr	x3, [x2, #5112]
    7f10:	8b000800 	add	x0, x0, x0, lsl #2
    7f14:	d37df002 	lsl	x2, x0, #3
    7f18:	8b020060 	add	x0, x3, x2
    7f1c:	f9401018 	ldr	x24, [x0, #32]
    7f20:	b4000258 	cbz	x24, 7f68 <f12+0xd68>
    7f24:	38626862 	ldrb	w2, [x3, x2]
    7f28:	7100085f 	cmp	w2, #0x2
    7f2c:	54000cc0 	b.eq	80c4 <f12+0xec4>  // b.none
    7f30:	7100045f 	cmp	w2, #0x1
    7f34:	540001a1 	b.ne	7f68 <f12+0xd68>  // b.any
    7f38:	29430002 	ldp	w2, w0, [x0, #24]
    7f3c:	92403c21 	and	x1, x1, #0xffff
    7f40:	9b027c21 	mul	x1, x1, x2
    7f44:	d360fc21 	lsr	x1, x1, #32
    7f48:	eb00003f 	cmp	x1, x0
    7f4c:	540000e2 	b.cs	7f68 <f12+0xd68>  // b.hs, b.nlast
    7f50:	8b010318 	add	x24, x24, x1
    7f54:	39400300 	ldrb	w0, [x24]
    7f58:	7103fc1f 	cmp	w0, #0xff
    7f5c:	54000f20 	b.eq	8140 <f12+0xf40>  // b.none
    7f60:	52800020 	mov	w0, #0x1                   	// #1
    7f64:	39000300 	strb	w0, [x24]
    7f68:	aa1303e0 	mov	x0, x19
    7f6c:	17fffe92 	b	79b4 <f12+0x7b4>
    7f70:	eb1a039f 	cmp	x28, x26
    7f74:	54ffe468 	b.hi	7c00 <f12+0xa00>  // b.pmore
    7f78:	17ffff86 	b	7d90 <f12+0xb90>
    7f7c:	52800041 	mov	w1, #0x2                   	// #2
    7f80:	d2800100 	mov	x0, #0x8                   	// #8
    7f84:	97fff31b 	bl	4bf0 <fwp_heap_alloc>
    7f88:	aa0003fb 	mov	x27, x0
    7f8c:	911542a0 	add	x0, x21, #0x550
    7f90:	f900037f 	str	xzr, [x27]
    7f94:	f949d801 	ldr	x1, [x0, #5040]
    7f98:	f949ec00 	ldr	x0, [x0, #5080]
    7f9c:	cb010361 	sub	x1, x27, x1
    7fa0:	eb00403f 	cmp	x1, x0, lsl #16
    7fa4:	54000362 	b.cs	8010 <f12+0xe10>  // b.hs, b.nlast
    7fa8:	d2800013 	mov	x19, #0x0                   	// #0
    7fac:	17fffd6e 	b	7564 <f12+0x364>
    7fb0:	aa1b03e0 	mov	x0, x27
    7fb4:	97fff14f 	bl	44f0 <fwp_rc_forget_slot>
    7fb8:	17ffff23 	b	7c44 <f12+0xa44>
    7fbc:	f100027f 	cmp	x19, #0x0
    7fc0:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    7fc4:	54ffbec1 	b.ne	779c <f12+0x59c>  // b.any
    7fc8:	f94027e1 	ldr	x1, [sp, #72]
    7fcc:	910102f7 	add	x23, x23, #0x40
    7fd0:	aa1803e0 	mov	x0, x24
    7fd4:	f90162e1 	str	x1, [x23, #704]
    7fd8:	97fff02a 	bl	4080 <fwp_tape_buffers_release>
    7fdc:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7fe0:	f947e863 	ldr	x3, [x3, #4048]
    7fe4:	d2800262 	mov	x2, #0x13                  	// #19
    7fe8:	d2800021 	mov	x1, #0x1                   	// #1
    7fec:	d0000020 	adrp	x0, d000 <__modti3+0x310>
    7ff0:	91026000 	add	x0, x0, #0x98
    7ff4:	f9400063 	ldr	x3, [x3]
    7ff8:	97ffea3e 	bl	28f0 <fwrite@plt>
    7ffc:	d2800000 	mov	x0, #0x0                   	// #0
    8000:	97ffea48 	bl	2920 <fflush@plt>
    8004:	52800cc0 	mov	w0, #0x66                  	// #102
    8008:	97ffea56 	bl	2960 <_Exit@plt>
    800c:	b5ffae13 	cbnz	x19, 75cc <f12+0x3cc>
    8010:	d280001c 	mov	x28, #0x0                   	// #0
    8014:	17fffd94 	b	7664 <f12+0x464>
    8018:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0xdc>
    801c:	913ac000 	add	x0, x0, #0xeb0
    8020:	94001410 	bl	d060 <atexit>
    8024:	35fffdc0 	cbnz	w0, 7fdc <f12+0xddc>
    8028:	52800020 	mov	w0, #0x1                   	// #1
    802c:	b902f680 	str	w0, [x20, #756]
    8030:	17fffcc0 	b	7330 <f12+0x130>
    8034:	72003c3f 	tst	w1, #0xffff
    8038:	54ffac81 	b.ne	75c8 <f12+0x3c8>  // b.any
    803c:	17fffd5e 	b	75b4 <f12+0x3b4>
    8040:	72003c3f 	tst	w1, #0xffff
    8044:	54ff94a0 	b.eq	72d8 <f12+0xd8>  // b.none
    8048:	aa1403e0 	mov	x0, x20
    804c:	97fff6f9 	bl	5c30 <fwp_closure_drop>
    8050:	b5ff9576 	cbnz	x22, 72fc <f12+0xfc>
    8054:	d280001c 	mov	x28, #0x0                   	// #0
    8058:	17fffcb3 	b	7324 <f12+0x124>
    805c:	aa1c03f3 	mov	x19, x28
    8060:	17fffdb8 	b	7740 <f12+0x540>
    8064:	72003c3f 	tst	w1, #0xffff
    8068:	54ffc541 	b.ne	7910 <f12+0x710>  // b.any
    806c:	17fffe24 	b	78fc <f12+0x6fc>
    8070:	3cc48002 	ldur	q2, [x0, #72]
    8074:	91012001 	add	x1, x0, #0x48
    8078:	3cc58001 	ldur	q1, [x0, #88]
    807c:	f900401f 	str	xzr, [x0, #128]
    8080:	4f000400 	movi	v0.4s, #0x0
    8084:	ad010682 	stp	q2, q1, [x20, #32]
    8088:	a9468002 	ldp	x2, x0, [x0, #104]
    808c:	f9000e80 	str	x0, [x20, #24]
    8090:	f9401820 	ldr	x0, [x1, #48]
    8094:	f9002282 	str	x2, [x20, #64]
    8098:	f9002680 	str	x0, [x20, #72]
    809c:	ad000020 	stp	q0, q0, [x1]
    80a0:	3d800820 	str	q0, [x1, #32]
    80a4:	f900183f 	str	xzr, [x1, #48]
    80a8:	17fffcec 	b	7458 <f12+0x258>
    80ac:	52800041 	mov	w1, #0x2                   	// #2
    80b0:	d2800100 	mov	x0, #0x8                   	// #8
    80b4:	97fff2cf 	bl	4bf0 <fwp_heap_alloc>
    80b8:	aa0003f9 	mov	x25, x0
    80bc:	d2800013 	mov	x19, #0x0                   	// #0
    80c0:	17ffff44 	b	7dd0 <f12+0xbd0>
    80c4:	72003c3f 	tst	w1, #0xffff
    80c8:	54fff460 	b.eq	7f54 <f12+0xd54>  // b.none
    80cc:	aa1303e0 	mov	x0, x19
    80d0:	17fffe39 	b	79b4 <f12+0x7b4>
    80d4:	aa1b03e0 	mov	x0, x27
    80d8:	d2800101 	mov	x1, #0x8                   	// #8
    80dc:	97ffe9bd 	bl	27d0 <calloc@plt>
    80e0:	aa0003e3 	mov	x3, x0
    80e4:	a94017e4 	ldp	x4, x5, [sp]
    80e8:	a9411fe6 	ldp	x6, x7, [sp, #16]
    80ec:	17fffda9 	b	7790 <f12+0x590>
    80f0:	f9400343 	ldr	x3, [x26]
    80f4:	b7fffdc3 	tbnz	x3, #63, 80ac <f12+0xeac>
    80f8:	911542a1 	add	x1, x21, #0x550
    80fc:	f94003e4 	ldr	x4, [sp]
    8100:	f949d820 	ldr	x0, [x1, #5040]
    8104:	f949ec21 	ldr	x1, [x1, #5080]
    8108:	cb000080 	sub	x0, x4, x0
    810c:	eb01401f 	cmp	x0, x1, lsl #16
    8110:	54fffce2 	b.cs	80ac <f12+0xeac>  // b.hs, b.nlast
    8114:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8118:	17fffe5b 	b	7a84 <f12+0x884>
    811c:	d2800d01 	mov	x1, #0x68                  	// #104
    8120:	d2800038 	mov	x24, #0x1                   	// #1
    8124:	17fffca6 	b	73bc <f12+0x1bc>
    8128:	aa1403e0 	mov	x0, x20
    812c:	97fff0f1 	bl	44f0 <fwp_rc_forget_slot>
    8130:	17fffdf6 	b	7908 <f12+0x708>
    8134:	aa1403e0 	mov	x0, x20
    8138:	97fff0ee 	bl	44f0 <fwp_rc_forget_slot>
    813c:	17fffd21 	b	75c0 <f12+0x3c0>
    8140:	aa1803e0 	mov	x0, x24
    8144:	97fff0eb 	bl	44f0 <fwp_rc_forget_slot>
    8148:	17ffff86 	b	7f60 <f12+0xd60>
    814c:	97fff0a2 	bl	43d4 <fwp_rc_wide_dup>
    8150:	17fffc68 	b	72f0 <f12+0xf0>
    8154:	d280001a 	mov	x26, #0x0                   	// #0
    8158:	17fffeaa 	b	7c00 <f12+0xa00>
    815c:	d2800019 	mov	x25, #0x0                   	// #0
    8160:	d2800013 	mov	x19, #0x0                   	// #0
    8164:	17ffff1b 	b	7dd0 <f12+0xbd0>
    8168:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    816c:	91106000 	add	x0, x0, #0x418
    8170:	97ffece4 	bl	3500 <fwp_trap>
    8174:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    8178:	910e0000 	add	x0, x0, #0x380
    817c:	97ffece1 	bl	3500 <fwp_trap>
    8180:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    8184:	91146000 	add	x0, x0, #0x518
    8188:	97ffecde 	bl	3500 <fwp_trap>
    818c:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    8190:	9111e000 	add	x0, x0, #0x478
    8194:	97ffecdb 	bl	3500 <fwp_trap>
    8198:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    819c:	910f2000 	add	x0, x0, #0x3c8
    81a0:	97ffecd8 	bl	3500 <fwp_trap>
    81a4:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    81a8:	91136000 	add	x0, x0, #0x4d8
    81ac:	97ffecd5 	bl	3500 <fwp_trap>
    81b0:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    81b4:	91122000 	add	x0, x0, #0x488
    81b8:	97ffecd2 	bl	3500 <fwp_trap>
    81bc:	97ffe98d 	bl	27f0 <__stack_chk_fail@plt>
    81c0:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    81c4:	9112a000 	add	x0, x0, #0x4a8
    81c8:	97ffecce 	bl	3500 <fwp_trap>
    81cc:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    81d0:	91142000 	add	x0, x0, #0x508
    81d4:	97ffeccb 	bl	3500 <fwp_trap>
    81d8:	97ffea0a 	bl	2a00 <fwp_trap_overflow.constprop.0>
    81dc:	97ffe999 	bl	2840 <abort@plt>

00000000000081e0 <fwp_owned_entry12>:
    81e0:	f9400000 	ldr	x0, [x0]
    81e4:	17fffc07 	b	7200 <f12>
    81e8:	d503201f 	nop
    81ec:	d503201f 	nop

00000000000081f0 <e12>:
    81f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    81f4:	910003fd 	mov	x29, sp
    81f8:	f9000bf3 	str	x19, [sp, #16]
    81fc:	f9400013 	ldr	x19, [x0]
    8200:	aa1303e0 	mov	x0, x19
    8204:	97fff4af 	bl	54c0 <fwp_rc_share>
    8208:	aa1303e0 	mov	x0, x19
    820c:	97fffbfd 	bl	7200 <f12>
    8210:	aa0003f3 	mov	x19, x0
    8214:	97fff4ab 	bl	54c0 <fwp_rc_share>
    8218:	aa1303e0 	mov	x0, x19
    821c:	f9400bf3 	ldr	x19, [sp, #16]
    8220:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8224:	d65f03c0 	ret
    8228:	d503201f 	nop
    822c:	d503201f 	nop

0000000000008230 <fwp_write>:
    8230:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8234:	910003fd 	mov	x29, sp
    8238:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    823c:	f947f484 	ldr	x4, [x4, #4072]
    8240:	a90153f3 	stp	x19, x20, [sp, #16]
    8244:	d10943ff 	sub	sp, sp, #0x250
    8248:	b9400045 	ldr	w5, [x2]
    824c:	aa0003f4 	mov	x20, x0
    8250:	f9400080 	ldr	x0, [x4]
    8254:	f90127e0 	str	x0, [sp, #584]
    8258:	d2800000 	mov	x0, #0x0                   	// #0
    825c:	710064bf 	cmp	w5, #0x19
    8260:	54000408 	b.hi	82e0 <fwp_write+0xb0>  // b.pmore
    8264:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    8268:	aa0103f3 	mov	x19, x1
    826c:	91330000 	add	x0, x0, #0xcc0
    8270:	f9013bf5 	str	x21, [sp, #624]
    8274:	f9013ff6 	str	x22, [sp, #632]
    8278:	f90153fb 	str	x27, [sp, #672]
    827c:	f90157fc 	str	x28, [sp, #680]
    8280:	aa0203fc 	mov	x28, x2
    8284:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8288:	10000061 	adr	x1, 8294 <fwp_write+0x64>
    828c:	8b20a820 	add	x0, x1, w0, sxth #2
    8290:	d61f0000 	br	x0
    8294:	910123e0 	add	x0, sp, #0x48
    8298:	aa1303e5 	mov	x5, x19
    829c:	b0000024 	adrp	x4, d000 <__modti3+0x310>
    82a0:	aa0003f3 	mov	x19, x0
    82a4:	9115e084 	add	x4, x4, #0x578
    82a8:	d2804003 	mov	x3, #0x200                 	// #512
    82ac:	aa0303e1 	mov	x1, x3
    82b0:	52800042 	mov	w2, #0x2                   	// #2
    82b4:	97ffe92b 	bl	2760 <__snprintf_chk@plt>
    82b8:	aa1303e0 	mov	x0, x19
    82bc:	97ffe8f1 	bl	2680 <strlen@plt>
    82c0:	aa1303e1 	mov	x1, x19
    82c4:	aa0003e2 	mov	x2, x0
    82c8:	aa1403e0 	mov	x0, x20
    82cc:	97ffec31 	bl	3390 <buf_put>
    82d0:	f9413bf5 	ldr	x21, [sp, #624]
    82d4:	f9413ff6 	ldr	x22, [sp, #632]
    82d8:	f94153fb 	ldr	x27, [sp, #672]
    82dc:	f94157fc 	ldr	x28, [sp, #680]
    82e0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    82e4:	f947f400 	ldr	x0, [x0, #4072]
    82e8:	f94127e2 	ldr	x2, [sp, #584]
    82ec:	f9400001 	ldr	x1, [x0]
    82f0:	eb010042 	subs	x2, x2, x1
    82f4:	d2800001 	mov	x1, #0x0                   	// #0
    82f8:	540077c1 	b.ne	91f0 <fwp_write+0xfc0>  // b.any
    82fc:	910943ff 	add	sp, sp, #0x250
    8300:	a94153f3 	ldp	x19, x20, [sp, #16]
    8304:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8308:	d65f03c0 	ret
    830c:	910123e0 	add	x0, sp, #0x48
    8310:	aa1303e5 	mov	x5, x19
    8314:	b0000024 	adrp	x4, d000 <__modti3+0x310>
    8318:	aa0003f3 	mov	x19, x0
    831c:	9115c084 	add	x4, x4, #0x570
    8320:	d2804003 	mov	x3, #0x200                 	// #512
    8324:	17ffffe2 	b	82ac <fwp_write+0x7c>
    8328:	71004cbf 	cmp	w5, #0x13
    832c:	b0000020 	adrp	x0, d000 <__modti3+0x310>
    8330:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8334:	91158000 	add	x0, x0, #0x560
    8338:	9115a021 	add	x1, x1, #0x568
    833c:	d2800082 	mov	x2, #0x4                   	// #4
    8340:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8344:	aa1403e0 	mov	x0, x20
    8348:	f90143f7 	str	x23, [sp, #640]
    834c:	d2800016 	mov	x22, #0x0                   	// #0
    8350:	f90147f8 	str	x24, [sp, #648]
    8354:	97ffec0f 	bl	3390 <buf_put>
    8358:	f9400260 	ldr	x0, [x19]
    835c:	b0000037 	adrp	x23, d000 <__modti3+0x310>
    8360:	d2800015 	mov	x21, #0x0                   	// #0
    8364:	9117a2f7 	add	x23, x23, #0x5e8
    8368:	b40047a0 	cbz	x0, 8c5c <fwp_write+0xa2c>
    836c:	b9400380 	ldr	w0, [x28]
    8370:	52800003 	mov	w3, #0x0                   	// #0
    8374:	f9401f82 	ldr	x2, [x28, #56]
    8378:	71004c1f 	cmp	w0, #0x13
    837c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8380:	aa1403e0 	mov	x0, x20
    8384:	8b010e61 	add	x1, x19, x1, lsl #3
    8388:	f9400421 	ldr	x1, [x1, #8]
    838c:	97ffffa9 	bl	8230 <fwp_write>
    8390:	b9400380 	ldr	w0, [x28]
    8394:	7100481f 	cmp	w0, #0x12
    8398:	54004b40 	b.eq	8d00 <fwp_write+0xad0>  // b.none
    839c:	f9400260 	ldr	x0, [x19]
    83a0:	910006b5 	add	x21, x21, #0x1
    83a4:	91000ad6 	add	x22, x22, #0x2
    83a8:	eb15001f 	cmp	x0, x21
    83ac:	54004589 	b.ls	8c5c <fwp_write+0xa2c>  // b.plast
    83b0:	aa1703e1 	mov	x1, x23
    83b4:	aa1403e0 	mov	x0, x20
    83b8:	d2800042 	mov	x2, #0x2                   	// #2
    83bc:	97ffebf5 	bl	3390 <buf_put>
    83c0:	17ffffeb 	b	836c <fwp_write+0x13c>
    83c4:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    83c8:	91168021 	add	x1, x1, #0x5a0
    83cc:	d28000c2 	mov	x2, #0x6                   	// #6
    83d0:	aa1403e0 	mov	x0, x20
    83d4:	91004273 	add	x19, x19, #0x10
    83d8:	97ffebee 	bl	3390 <buf_put>
    83dc:	aa1303e0 	mov	x0, x19
    83e0:	97ffe8a8 	bl	2680 <strlen@plt>
    83e4:	aa1303e1 	mov	x1, x19
    83e8:	aa0003e2 	mov	x2, x0
    83ec:	aa1403e0 	mov	x0, x20
    83f0:	97ffebe8 	bl	3390 <buf_put>
    83f4:	528007c3 	mov	w3, #0x3e                  	// #62
    83f8:	aa1403e0 	mov	x0, x20
    83fc:	91001fe1 	add	x1, sp, #0x7
    8400:	d2800022 	mov	x2, #0x1                   	// #1
    8404:	39001fe3 	strb	w3, [sp, #7]
    8408:	17ffffb1 	b	82cc <fwp_write+0x9c>
    840c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8410:	f947f400 	ldr	x0, [x0, #4072]
    8414:	f94127e2 	ldr	x2, [sp, #584]
    8418:	f9400001 	ldr	x1, [x0]
    841c:	eb010042 	subs	x2, x2, x1
    8420:	d2800001 	mov	x1, #0x0                   	// #0
    8424:	540034e1 	b.ne	8ac0 <fwp_write+0x890>  // b.any
    8428:	f9413bf5 	ldr	x21, [sp, #624]
    842c:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8430:	f9413ff6 	ldr	x22, [sp, #632]
    8434:	aa1403e0 	mov	x0, x20
    8438:	91160021 	add	x1, x1, #0x580
    843c:	d2800142 	mov	x2, #0xa                   	// #10
    8440:	f94153fb 	ldr	x27, [sp, #672]
    8444:	f94157fc 	ldr	x28, [sp, #680]
    8448:	910943ff 	add	sp, sp, #0x250
    844c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8450:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8454:	17ffebcf 	b	3390 <buf_put>
    8458:	f9400456 	ldr	x22, [x2, #8]
    845c:	f90143f7 	str	x23, [sp, #640]
    8460:	f90147f8 	str	x24, [sp, #648]
    8464:	b4005b16 	cbz	x22, 8fc4 <fwp_write+0xd94>
    8468:	aa1603e0 	mov	x0, x22
    846c:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8470:	91180021 	add	x1, x1, #0x600
    8474:	97ffe8ff 	bl	2870 <strcmp@plt>
    8478:	2a0003f5 	mov	w21, w0
    847c:	34005fe0 	cbz	w0, 9078 <fwp_write+0xe48>
    8480:	aa1603e0 	mov	x0, x22
    8484:	97ffe87f 	bl	2680 <strlen@plt>
    8488:	aa1603e1 	mov	x1, x22
    848c:	aa0003e2 	mov	x2, x0
    8490:	aa1403e0 	mov	x0, x20
    8494:	97ffebbf 	bl	3390 <buf_put>
    8498:	52800403 	mov	w3, #0x20                  	// #32
    849c:	91001ff5 	add	x21, sp, #0x7
    84a0:	aa1503e1 	mov	x1, x21
    84a4:	aa1403e0 	mov	x0, x20
    84a8:	d2800022 	mov	x2, #0x1                   	// #1
    84ac:	39001fe3 	strb	w3, [sp, #7]
    84b0:	97ffebb8 	bl	3390 <buf_put>
    84b4:	52800f63 	mov	w3, #0x7b                  	// #123
    84b8:	aa1403e0 	mov	x0, x20
    84bc:	aa1503e1 	mov	x1, x21
    84c0:	d2800022 	mov	x2, #0x1                   	// #1
    84c4:	39001fe3 	strb	w3, [sp, #7]
    84c8:	97ffebb2 	bl	3390 <buf_put>
    84cc:	b9401380 	ldr	w0, [x28, #16]
    84d0:	52800018 	mov	w24, #0x0                   	// #0
    84d4:	7100001f 	cmp	w0, #0x0
    84d8:	54003aad 	b.le	8c2c <fwp_write+0x9fc>
    84dc:	f9014bf9 	str	x25, [sp, #656]
    84e0:	b0000039 	adrp	x25, d000 <__modti3+0x310>
    84e4:	9118a339 	add	x25, x25, #0x628
    84e8:	f9014ffa 	str	x26, [sp, #664]
    84ec:	b000003a 	adrp	x26, d000 <__modti3+0x310>
    84f0:	9117a35a 	add	x26, x26, #0x5e8
    84f4:	91002276 	add	x22, x19, #0x8
    84f8:	d2800013 	mov	x19, #0x0                   	// #0
    84fc:	b5003e93 	cbnz	x19, 8ccc <fwp_write+0xa9c>
    8500:	d37df277 	lsl	x23, x19, #3
    8504:	34003cb8 	cbz	w24, 8c98 <fwp_write+0xa68>
    8508:	f9401382 	ldr	x2, [x28, #32]
    850c:	aa1403e0 	mov	x0, x20
    8510:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8514:	52800003 	mov	w3, #0x0                   	// #0
    8518:	f8776842 	ldr	x2, [x2, x23]
    851c:	91000673 	add	x19, x19, #0x1
    8520:	97ffff44 	bl	8230 <fwp_write>
    8524:	b9401380 	ldr	w0, [x28, #16]
    8528:	6b13001f 	cmp	w0, w19
    852c:	54fffe8c 	b.gt	84fc <fwp_write+0x2cc>
    8530:	f9414bf9 	ldr	x25, [sp, #656]
    8534:	f9414ffa 	ldr	x26, [sp, #664]
    8538:	340037b8 	cbz	w24, 8c2c <fwp_write+0x9fc>
    853c:	52800523 	mov	w3, #0x29                  	// #41
    8540:	aa1503e1 	mov	x1, x21
    8544:	aa1403e0 	mov	x0, x20
    8548:	d2800022 	mov	x2, #0x1                   	// #1
    854c:	39001fe3 	strb	w3, [sp, #7]
    8550:	97ffeb90 	bl	3390 <buf_put>
    8554:	f9413bf5 	ldr	x21, [sp, #624]
    8558:	f9413ff6 	ldr	x22, [sp, #632]
    855c:	f94143f7 	ldr	x23, [sp, #640]
    8560:	f94147f8 	ldr	x24, [sp, #648]
    8564:	f94153fb 	ldr	x27, [sp, #672]
    8568:	f94157fc 	ldr	x28, [sp, #680]
    856c:	17ffff5d 	b	82e0 <fwp_write+0xb0>
    8570:	b9404855 	ldr	w21, [x2, #72]
    8574:	aa1403e0 	mov	x0, x20
    8578:	93407eb6 	sxtw	x22, w21
    857c:	91000ac1 	add	x1, x22, #0x2
    8580:	97ffeb51 	bl	32c4 <buf_grow>
    8584:	a9400281 	ldp	x1, x0, [x20]
    8588:	528e8603 	mov	w3, #0x7430                	// #29744
    858c:	78206823 	strh	w3, [x1, x0]
    8590:	8b000022 	add	x2, x1, x0
    8594:	710002bf 	cmp	w21, #0x0
    8598:	540036cd 	b.le	8c70 <fwp_write+0xa40>
    859c:	110006a3 	add	w3, w21, #0x1
    85a0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    85a4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    85a8:	91000449 	add	x9, x2, #0x1
    85ac:	8b23c043 	add	x3, x2, w3, sxtw
    85b0:	f28aaac6 	movk	x6, #0x5556
    85b4:	f2955568 	movk	x8, #0xaaab
    85b8:	1400000d 	b	85ec <fwp_write+0x3bc>
    85bc:	d2800021 	mov	x1, #0x1                   	// #1
    85c0:	528005a5 	mov	w5, #0x2d                  	// #45
    85c4:	f100001f 	cmp	x0, #0x0
    85c8:	9b467e60 	smulh	x0, x19, x6
    85cc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    85d0:	381ff465 	strb	w5, [x3], #-1
    85d4:	cb040000 	sub	x0, x0, x4
    85d8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    85dc:	cb020000 	sub	x0, x0, x2
    85e0:	8b010013 	add	x19, x0, x1
    85e4:	eb03013f 	cmp	x9, x3
    85e8:	54003440 	b.eq	8c70 <fwp_write+0xa40>  // b.none
    85ec:	9b467e60 	smulh	x0, x19, x6
    85f0:	937ffe64 	asr	x4, x19, #63
    85f4:	52800605 	mov	w5, #0x30                  	// #48
    85f8:	cb040000 	sub	x0, x0, x4
    85fc:	8b000400 	add	x0, x0, x0, lsl #1
    8600:	cb000260 	sub	x0, x19, x0
    8604:	91000c01 	add	x1, x0, #0x3
    8608:	9bc87c22 	umulh	x2, x1, x8
    860c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8610:	8b4204e2 	add	x2, x7, x2, lsr #1
    8614:	eb020021 	subs	x1, x1, x2
    8618:	54fffd60 	b.eq	85c4 <fwp_write+0x394>  // b.none
    861c:	f100043f 	cmp	x1, #0x1
    8620:	54fffce1 	b.ne	85bc <fwp_write+0x38c>  // b.any
    8624:	d2800001 	mov	x1, #0x0                   	// #0
    8628:	52800565 	mov	w5, #0x2b                  	// #43
    862c:	17ffffe6 	b	85c4 <fwp_write+0x394>
    8630:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8634:	f947f400 	ldr	x0, [x0, #4072]
    8638:	f94127e2 	ldr	x2, [sp, #584]
    863c:	f9400001 	ldr	x1, [x0]
    8640:	eb010042 	subs	x2, x2, x1
    8644:	d2800001 	mov	x1, #0x0                   	// #0
    8648:	540023c1 	b.ne	8ac0 <fwp_write+0x890>  // b.any
    864c:	f9413bf5 	ldr	x21, [sp, #624]
    8650:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8654:	f9413ff6 	ldr	x22, [sp, #632]
    8658:	aa1403e0 	mov	x0, x20
    865c:	91164021 	add	x1, x1, #0x590
    8660:	d2800102 	mov	x2, #0x8                   	// #8
    8664:	17ffff77 	b	8440 <fwp_write+0x210>
    8668:	aa1403e0 	mov	x0, x20
    866c:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8670:	d28000c2 	mov	x2, #0x6                   	// #6
    8674:	9117c021 	add	x1, x1, #0x5f0
    8678:	97ffeb46 	bl	3390 <buf_put>
    867c:	d2800015 	mov	x21, #0x0                   	// #0
    8680:	f9400263 	ldr	x3, [x19]
    8684:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8688:	54002c60 	b.eq	8c14 <fwp_write+0x9e4>  // b.none
    868c:	f9401f82 	ldr	x2, [x28, #56]
    8690:	f90143f7 	str	x23, [sp, #640]
    8694:	f90147f8 	str	x24, [sp, #648]
    8698:	d2800857 	mov	x23, #0x42                  	// #66
    869c:	f9014bf9 	str	x25, [sp, #656]
    86a0:	b0000036 	adrp	x22, d000 <__modti3+0x310>
    86a4:	f9014ffa 	str	x26, [sp, #664]
    86a8:	9117a2d6 	add	x22, x22, #0x5e8
    86ac:	d2800038 	mov	x24, #0x1                   	// #1
    86b0:	f2a18017 	movk	x23, #0xc00, lsl #16
    86b4:	d2809099 	mov	x25, #0x484                 	// #1156
    86b8:	b40004a2 	cbz	x2, 874c <fwp_write+0x51c>
    86bc:	b9400040 	ldr	w0, [x2]
    86c0:	7100701f 	cmp	w0, #0x1c
    86c4:	540042c0 	b.eq	8f1c <fwp_write+0xcec>  // b.none
    86c8:	71006c1f 	cmp	w0, #0x1b
    86cc:	54000408 	b.hi	874c <fwp_write+0x51c>  // b.pmore
    86d0:	9ac02301 	lsl	x1, x24, x0
    86d4:	ea17003f 	tst	x1, x23
    86d8:	540036a1 	b.ne	8dac <fwp_write+0xb7c>  // b.any
    86dc:	ea19003f 	tst	x1, x25
    86e0:	54003521 	b.ne	8d84 <fwp_write+0xb54>  // b.any
    86e4:	d2800424 	mov	x4, #0x21                  	// #33
    86e8:	ea04003f 	tst	x1, x4
    86ec:	54000300 	b.eq	874c <fwp_write+0x51c>  // b.none
    86f0:	b7f849c3 	tbnz	x3, #63, 9028 <fwp_write+0xdf8>
    86f4:	91002261 	add	x1, x19, #0x8
    86f8:	8b150021 	add	x1, x1, x21
    86fc:	39400021 	ldrb	w1, [x1]
    8700:	7100001f 	cmp	w0, #0x0
    8704:	93401c23 	sxtb	x3, w1
    8708:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    870c:	d503201f 	nop
    8710:	aa1403e0 	mov	x0, x20
    8714:	52800003 	mov	w3, #0x0                   	// #0
    8718:	97fffec6 	bl	8230 <fwp_write>
    871c:	910006b5 	add	x21, x21, #0x1
    8720:	f9400260 	ldr	x0, [x19]
    8724:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8728:	eb0002bf 	cmp	x21, x0
    872c:	540026c2 	b.cs	8c04 <fwp_write+0x9d4>  // b.hs, b.nlast
    8730:	d2800042 	mov	x2, #0x2                   	// #2
    8734:	aa1603e1 	mov	x1, x22
    8738:	aa1403e0 	mov	x0, x20
    873c:	97ffeb15 	bl	3390 <buf_put>
    8740:	f9401f82 	ldr	x2, [x28, #56]
    8744:	f9400263 	ldr	x3, [x19]
    8748:	b5fffba2 	cbnz	x2, 86bc <fwp_write+0x48c>
    874c:	d37df2a0 	lsl	x0, x21, #3
    8750:	b7f83f03 	tbnz	x3, #63, 8f30 <fwp_write+0xd00>
    8754:	91002261 	add	x1, x19, #0x8
    8758:	8b000020 	add	x0, x1, x0
    875c:	f9400001 	ldr	x1, [x0]
    8760:	17ffffec 	b	8710 <fwp_write+0x4e0>
    8764:	a9400e62 	ldp	x2, x3, [x19]
    8768:	b7f83ca3 	tbnz	x3, #63, 8efc <fwp_write+0xccc>
    876c:	910123f5 	add	x21, sp, #0x48
    8770:	aa1503e0 	mov	x0, x21
    8774:	97ffe98b 	bl	2da0 <fwp_fmt_u128>
    8778:	aa1503e0 	mov	x0, x21
    877c:	97ffe7c1 	bl	2680 <strlen@plt>
    8780:	aa1503e1 	mov	x1, x21
    8784:	aa0003e2 	mov	x2, x0
    8788:	17fffed0 	b	82c8 <fwp_write+0x98>
    878c:	fd015be8 	str	d8, [sp, #688]
    8790:	1e270268 	fmov	s8, w19
    8794:	fd015fe9 	str	d9, [sp, #696]
    8798:	1e282100 	fcmp	s8, s8
    879c:	54004d26 	b.vs	9140 <fwp_write+0xf10>
    87a0:	1e20c101 	fabs	s1, s8
    87a4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    87a8:	1e270000 	fmov	s0, w0
    87ac:	1e202020 	fcmp	s1, s0
    87b0:	54002c0d 	b.le	8d30 <fwp_write+0xb00>
    87b4:	1e202118 	fcmpe	s8, #0.0
    87b8:	b0000022 	adrp	x2, d000 <__modti3+0x310>
    87bc:	9102c042 	add	x2, x2, #0xb0
    87c0:	910123f5 	add	x21, sp, #0x48
    87c4:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    87c8:	91150021 	add	x1, x1, #0x540
    87cc:	aa1503e0 	mov	x0, x21
    87d0:	9a81c041 	csel	x1, x2, x1, gt
    87d4:	97ffe857 	bl	2930 <strcpy@plt>
    87d8:	aa1503e0 	mov	x0, x21
    87dc:	97ffe7a9 	bl	2680 <strlen@plt>
    87e0:	aa1503e1 	mov	x1, x21
    87e4:	aa0003e2 	mov	x2, x0
    87e8:	aa1403e0 	mov	x0, x20
    87ec:	97ffeae9 	bl	3390 <buf_put>
    87f0:	f9413bf5 	ldr	x21, [sp, #624]
    87f4:	f9413ff6 	ldr	x22, [sp, #632]
    87f8:	f94153fb 	ldr	x27, [sp, #672]
    87fc:	f94157fc 	ldr	x28, [sp, #680]
    8800:	fd415be8 	ldr	d8, [sp, #688]
    8804:	fd415fe9 	ldr	d9, [sp, #696]
    8808:	17fffeb6 	b	82e0 <fwp_write+0xb0>
    880c:	f9400276 	ldr	x22, [x19]
    8810:	34002e03 	cbz	w3, 8dd0 <fwp_write+0xba0>
    8814:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8818:	f947f400 	ldr	x0, [x0, #4072]
    881c:	f94127e2 	ldr	x2, [sp, #584]
    8820:	f9400001 	ldr	x1, [x0]
    8824:	eb010042 	subs	x2, x2, x1
    8828:	d2800001 	mov	x1, #0x0                   	// #0
    882c:	540014a1 	b.ne	8ac0 <fwp_write+0x890>  // b.any
    8830:	aa1603e2 	mov	x2, x22
    8834:	91002261 	add	x1, x19, #0x8
    8838:	f9413bf5 	ldr	x21, [sp, #624]
    883c:	aa1403e0 	mov	x0, x20
    8840:	f9413ff6 	ldr	x22, [sp, #632]
    8844:	17fffeff 	b	8440 <fwp_write+0x210>
    8848:	fd015be8 	str	d8, [sp, #688]
    884c:	9e670268 	fmov	d8, x19
    8850:	fd015fe9 	str	d9, [sp, #696]
    8854:	1e682100 	fcmp	d8, d8
    8858:	54004746 	b.vs	9140 <fwp_write+0xf10>
    885c:	1e60c101 	fabs	d1, d8
    8860:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8864:	9e670000 	fmov	d0, x0
    8868:	910123f5 	add	x21, sp, #0x48
    886c:	52800033 	mov	w19, #0x1                   	// #1
    8870:	1e602020 	fcmp	d1, d0
    8874:	540001ad 	b.le	88a8 <fwp_write+0x678>
    8878:	1e602118 	fcmpe	d8, #0.0
    887c:	b0000022 	adrp	x2, d000 <__modti3+0x310>
    8880:	9102c042 	add	x2, x2, #0xb0
    8884:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8888:	91150021 	add	x1, x1, #0x540
    888c:	aa1503e0 	mov	x0, x21
    8890:	9a81c041 	csel	x1, x2, x1, gt
    8894:	97ffe827 	bl	2930 <strcpy@plt>
    8898:	17ffffd0 	b	87d8 <fwp_write+0x5a8>
    889c:	11000673 	add	w19, w19, #0x1
    88a0:	71004a7f 	cmp	w19, #0x12
    88a4:	54003860 	b.eq	8fb0 <fwp_write+0xd80>  // b.none
    88a8:	1e604100 	fmov	d0, d8
    88ac:	2a1303e1 	mov	w1, w19
    88b0:	aa1503e0 	mov	x0, x21
    88b4:	97ffebf8 	bl	3894 <fwp_format_g.constprop.0>
    88b8:	aa1503e0 	mov	x0, x21
    88bc:	d2800001 	mov	x1, #0x0                   	// #0
    88c0:	97ffe784 	bl	26d0 <strtod@plt>
    88c4:	1e602100 	fcmp	d8, d0
    88c8:	54fffea1 	b.ne	889c <fwp_write+0x66c>  // b.any
    88cc:	aa1503e0 	mov	x0, x21
    88d0:	97ffeae9 	bl	3474 <fwp_finish_float>
    88d4:	17ffffc1 	b	87d8 <fwp_write+0x5a8>
    88d8:	a9400e62 	ldp	x2, x3, [x19]
    88dc:	910123f3 	add	x19, sp, #0x48
    88e0:	aa1303e0 	mov	x0, x19
    88e4:	97ffe92f 	bl	2da0 <fwp_fmt_u128>
    88e8:	17fffe74 	b	82b8 <fwp_write+0x88>
    88ec:	f90143f7 	str	x23, [sp, #640]
    88f0:	f90147f8 	str	x24, [sp, #648]
    88f4:	2a1303f8 	mov	w24, w19
    88f8:	f9014bf9 	str	x25, [sp, #656]
    88fc:	f9014ffa 	str	x26, [sp, #664]
    8900:	f13ffe7f 	cmp	x19, #0xfff
    8904:	54000049 	b.ls	890c <fwp_write+0x6dc>  // b.plast
    8908:	b9400278 	ldr	w24, [x19]
    890c:	f9400f80 	ldr	x0, [x28, #24]
    8910:	2a1803f5 	mov	w21, w24
    8914:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8918:	d37ef6b9 	lsl	x25, x21, #2
    891c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8920:	aa1603e0 	mov	x0, x22
    8924:	97ffe757 	bl	2680 <strlen@plt>
    8928:	aa1603e1 	mov	x1, x22
    892c:	aa0003e2 	mov	x2, x0
    8930:	aa1403e0 	mov	x0, x20
    8934:	97ffea97 	bl	3390 <buf_put>
    8938:	f9401780 	ldr	x0, [x28, #40]
    893c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8940:	7100001f 	cmp	w0, #0x0
    8944:	5400068d 	b.le	8a14 <fwp_write+0x7e4>
    8948:	91002276 	add	x22, x19, #0x8
    894c:	91001ff5 	add	x21, sp, #0x7
    8950:	d280001b 	mov	x27, #0x0                   	// #0
    8954:	5280041a 	mov	w26, #0x20                  	// #32
    8958:	f9401b80 	ldr	x0, [x28, #48]
    895c:	aa1503e1 	mov	x1, x21
    8960:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8964:	d2800022 	mov	x2, #0x1                   	// #1
    8968:	f8786803 	ldr	x3, [x0, x24]
    896c:	aa1403e0 	mov	x0, x20
    8970:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8974:	39001ffa 	strb	w26, [sp, #7]
    8978:	97ffea86 	bl	3390 <buf_put>
    897c:	f13ffeff 	cmp	x23, #0xfff
    8980:	b9400261 	ldr	w1, [x19]
    8984:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8988:	7100383f 	cmp	w1, #0xe
    898c:	54000160 	b.eq	89b8 <fwp_write+0x788>  // b.none
    8990:	7100403f 	cmp	w1, #0x10
    8994:	54001a60 	b.eq	8ce0 <fwp_write+0xab0>  // b.none
    8998:	7100283f 	cmp	w1, #0xa
    899c:	54002aa0 	b.eq	8ef0 <fwp_write+0xcc0>  // b.none
    89a0:	540014ac 	b.gt	8c34 <fwp_write+0xa04>
    89a4:	71000c3f 	cmp	w1, #0x3
    89a8:	540029ac 	b.gt	8edc <fwp_write+0xcac>
    89ac:	d37ffee0 	lsr	x0, x23, #63
    89b0:	37f814a1 	tbnz	w1, #31, 8c44 <fwp_write+0xa14>
    89b4:	d503201f 	nop
    89b8:	34001460 	cbz	w0, 8c44 <fwp_write+0xa14>
    89bc:	52800503 	mov	w3, #0x28                  	// #40
    89c0:	aa1503e1 	mov	x1, x21
    89c4:	aa1403e0 	mov	x0, x20
    89c8:	d2800022 	mov	x2, #0x1                   	// #1
    89cc:	39001fe3 	strb	w3, [sp, #7]
    89d0:	97ffea70 	bl	3390 <buf_put>
    89d4:	aa1303e2 	mov	x2, x19
    89d8:	aa1703e1 	mov	x1, x23
    89dc:	aa1403e0 	mov	x0, x20
    89e0:	52800003 	mov	w3, #0x0                   	// #0
    89e4:	97fffe13 	bl	8230 <fwp_write>
    89e8:	52800523 	mov	w3, #0x29                  	// #41
    89ec:	aa1503e1 	mov	x1, x21
    89f0:	aa1403e0 	mov	x0, x20
    89f4:	d2800022 	mov	x2, #0x1                   	// #1
    89f8:	39001fe3 	strb	w3, [sp, #7]
    89fc:	97ffea65 	bl	3390 <buf_put>
    8a00:	f9401780 	ldr	x0, [x28, #40]
    8a04:	9100077b 	add	x27, x27, #0x1
    8a08:	b8796800 	ldr	w0, [x0, x25]
    8a0c:	6b1b001f 	cmp	w0, w27
    8a10:	54fffa4c 	b.gt	8958 <fwp_write+0x728>
    8a14:	f9413bf5 	ldr	x21, [sp, #624]
    8a18:	f9413ff6 	ldr	x22, [sp, #632]
    8a1c:	f94143f7 	ldr	x23, [sp, #640]
    8a20:	f94147f8 	ldr	x24, [sp, #648]
    8a24:	f9414bf9 	ldr	x25, [sp, #656]
    8a28:	f9414ffa 	ldr	x26, [sp, #664]
    8a2c:	f94153fb 	ldr	x27, [sp, #672]
    8a30:	f94157fc 	ldr	x28, [sp, #680]
    8a34:	17fffe2b 	b	82e0 <fwp_write+0xb0>
    8a38:	52800783 	mov	w3, #0x3c                  	// #60
    8a3c:	91001ff3 	add	x19, sp, #0x7
    8a40:	aa1303e1 	mov	x1, x19
    8a44:	d2800022 	mov	x2, #0x1                   	// #1
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	39001fe3 	strb	w3, [sp, #7]
    8a50:	97ffea50 	bl	3390 <buf_put>
    8a54:	f9400795 	ldr	x21, [x28, #8]
    8a58:	aa1503e0 	mov	x0, x21
    8a5c:	97ffe709 	bl	2680 <strlen@plt>
    8a60:	aa1503e1 	mov	x1, x21
    8a64:	aa0003e2 	mov	x2, x0
    8a68:	aa1403e0 	mov	x0, x20
    8a6c:	97ffea49 	bl	3390 <buf_put>
    8a70:	528007c3 	mov	w3, #0x3e                  	// #62
    8a74:	aa1303e1 	mov	x1, x19
    8a78:	aa1403e0 	mov	x0, x20
    8a7c:	d2800022 	mov	x2, #0x1                   	// #1
    8a80:	39001fe3 	strb	w3, [sp, #7]
    8a84:	17fffe12 	b	82cc <fwp_write+0x9c>
    8a88:	f100067f 	cmp	x19, #0x1
    8a8c:	540025a0 	b.eq	8f40 <fwp_write+0xd10>  // b.none
    8a90:	b100067f 	cmn	x19, #0x1
    8a94:	54002bc0 	b.eq	900c <fwp_write+0xddc>  // b.none
    8a98:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8a9c:	91152021 	add	x1, x1, #0x548
    8aa0:	d2800022 	mov	x2, #0x1                   	// #1
    8aa4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8aa8:	f947f400 	ldr	x0, [x0, #4072]
    8aac:	f94127e4 	ldr	x4, [sp, #584]
    8ab0:	f9400003 	ldr	x3, [x0]
    8ab4:	eb030084 	subs	x4, x4, x3
    8ab8:	d2800003 	mov	x3, #0x0                   	// #0
    8abc:	54ffebe0 	b.eq	8838 <fwp_write+0x608>  // b.none
    8ac0:	f90143f7 	str	x23, [sp, #640]
    8ac4:	f90147f8 	str	x24, [sp, #648]
    8ac8:	f9014bf9 	str	x25, [sp, #656]
    8acc:	f9014ffa 	str	x26, [sp, #664]
    8ad0:	fd015be8 	str	d8, [sp, #688]
    8ad4:	fd015fe9 	str	d9, [sp, #696]
    8ad8:	97ffe746 	bl	27f0 <__stack_chk_fail@plt>
    8adc:	52800b63 	mov	w3, #0x5b                  	// #91
    8ae0:	91001ff5 	add	x21, sp, #0x7
    8ae4:	aa1503e1 	mov	x1, x21
    8ae8:	aa1403e0 	mov	x0, x20
    8aec:	d2800022 	mov	x2, #0x1                   	// #1
    8af0:	b0000036 	adrp	x22, d000 <__modti3+0x310>
    8af4:	9117a2d6 	add	x22, x22, #0x5e8
    8af8:	39001fe3 	strb	w3, [sp, #7]
    8afc:	97ffea25 	bl	3390 <buf_put>
    8b00:	b4000273 	cbz	x19, 8b4c <fwp_write+0x91c>
    8b04:	f9400661 	ldr	x1, [x19, #8]
    8b08:	aa1403e0 	mov	x0, x20
    8b0c:	f9401f82 	ldr	x2, [x28, #56]
    8b10:	52800003 	mov	w3, #0x0                   	// #0
    8b14:	97fffdc7 	bl	8230 <fwp_write>
    8b18:	f9400a73 	ldr	x19, [x19, #16]
    8b1c:	b4000193 	cbz	x19, 8b4c <fwp_write+0x91c>
    8b20:	aa1603e1 	mov	x1, x22
    8b24:	aa1403e0 	mov	x0, x20
    8b28:	d2800042 	mov	x2, #0x2                   	// #2
    8b2c:	97ffea19 	bl	3390 <buf_put>
    8b30:	f9400661 	ldr	x1, [x19, #8]
    8b34:	aa1403e0 	mov	x0, x20
    8b38:	f9401f82 	ldr	x2, [x28, #56]
    8b3c:	52800003 	mov	w3, #0x0                   	// #0
    8b40:	97fffdbc 	bl	8230 <fwp_write>
    8b44:	f9400a73 	ldr	x19, [x19, #16]
    8b48:	b5fffed3 	cbnz	x19, 8b20 <fwp_write+0x8f0>
    8b4c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8b50:	aa1503e1 	mov	x1, x21
    8b54:	aa1403e0 	mov	x0, x20
    8b58:	d2800022 	mov	x2, #0x1                   	// #1
    8b5c:	39001fe3 	strb	w3, [sp, #7]
    8b60:	17fffddb 	b	82cc <fwp_write+0x9c>
    8b64:	aa1403e0 	mov	x0, x20
    8b68:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8b6c:	d28000c2 	mov	x2, #0x6                   	// #6
    8b70:	91176021 	add	x1, x1, #0x5d8
    8b74:	97ffea07 	bl	3390 <buf_put>
    8b78:	f9400260 	ldr	x0, [x19]
    8b7c:	b40004c0 	cbz	x0, 8c14 <fwp_write+0x9e4>
    8b80:	910123f5 	add	x21, sp, #0x48
    8b84:	91002276 	add	x22, x19, #0x8
    8b88:	f90143f7 	str	x23, [sp, #640]
    8b8c:	d2800017 	mov	x23, #0x0                   	// #0
    8b90:	f90147f8 	str	x24, [sp, #648]
    8b94:	b0000038 	adrp	x24, d000 <__modti3+0x310>
    8b98:	91178318 	add	x24, x24, #0x5e0
    8b9c:	f9014bf9 	str	x25, [sp, #656]
    8ba0:	b0000039 	adrp	x25, d000 <__modti3+0x310>
    8ba4:	9117a339 	add	x25, x25, #0x5e8
    8ba8:	f9014ffa 	str	x26, [sp, #664]
    8bac:	14000005 	b	8bc0 <fwp_write+0x990>
    8bb0:	aa1903e1 	mov	x1, x25
    8bb4:	aa1403e0 	mov	x0, x20
    8bb8:	d2800042 	mov	x2, #0x2                   	// #2
    8bbc:	97ffe9f5 	bl	3390 <buf_put>
    8bc0:	38776ac5 	ldrb	w5, [x22, x23]
    8bc4:	d2804003 	mov	x3, #0x200                 	// #512
    8bc8:	aa1803e4 	mov	x4, x24
    8bcc:	aa0303e1 	mov	x1, x3
    8bd0:	52800042 	mov	w2, #0x2                   	// #2
    8bd4:	aa1503e0 	mov	x0, x21
    8bd8:	910006f7 	add	x23, x23, #0x1
    8bdc:	97ffe6e1 	bl	2760 <__snprintf_chk@plt>
    8be0:	aa1503e0 	mov	x0, x21
    8be4:	97ffe6a7 	bl	2680 <strlen@plt>
    8be8:	aa1503e1 	mov	x1, x21
    8bec:	aa0003e2 	mov	x2, x0
    8bf0:	aa1403e0 	mov	x0, x20
    8bf4:	97ffe9e7 	bl	3390 <buf_put>
    8bf8:	f9400260 	ldr	x0, [x19]
    8bfc:	eb17001f 	cmp	x0, x23
    8c00:	54fffd88 	b.hi	8bb0 <fwp_write+0x980>  // b.pmore
    8c04:	f94143f7 	ldr	x23, [sp, #640]
    8c08:	f94147f8 	ldr	x24, [sp, #648]
    8c0c:	f9414bf9 	ldr	x25, [sp, #656]
    8c10:	f9414ffa 	ldr	x26, [sp, #664]
    8c14:	52800ba3 	mov	w3, #0x5d                  	// #93
    8c18:	aa1403e0 	mov	x0, x20
    8c1c:	91001fe1 	add	x1, sp, #0x7
    8c20:	d2800022 	mov	x2, #0x1                   	// #1
    8c24:	39001fe3 	strb	w3, [sp, #7]
    8c28:	17fffda9 	b	82cc <fwp_write+0x9c>
    8c2c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8c30:	17fffe44 	b	8540 <fwp_write+0x310>
    8c34:	f10002ff 	cmp	x23, #0x0
    8c38:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8c3c:	71002c3f 	cmp	w1, #0xb
    8c40:	54ffebc0 	b.eq	89b8 <fwp_write+0x788>  // b.none
    8c44:	aa1303e2 	mov	x2, x19
    8c48:	aa1703e1 	mov	x1, x23
    8c4c:	aa1403e0 	mov	x0, x20
    8c50:	52800003 	mov	w3, #0x0                   	// #0
    8c54:	97fffd77 	bl	8230 <fwp_write>
    8c58:	17ffff6a 	b	8a00 <fwp_write+0x7d0>
    8c5c:	aa1403e0 	mov	x0, x20
    8c60:	91001fe1 	add	x1, sp, #0x7
    8c64:	52800fa3 	mov	w3, #0x7d                  	// #125
    8c68:	d2800022 	mov	x2, #0x1                   	// #1
    8c6c:	17fffe38 	b	854c <fwp_write+0x31c>
    8c70:	a9400281 	ldp	x1, x0, [x20]
    8c74:	91000800 	add	x0, x0, #0x2
    8c78:	8b160000 	add	x0, x0, x22
    8c7c:	f9000680 	str	x0, [x20, #8]
    8c80:	3820683f 	strb	wzr, [x1, x0]
    8c84:	f9413bf5 	ldr	x21, [sp, #624]
    8c88:	f9413ff6 	ldr	x22, [sp, #632]
    8c8c:	f94153fb 	ldr	x27, [sp, #672]
    8c90:	f94157fc 	ldr	x28, [sp, #680]
    8c94:	17fffd93 	b	82e0 <fwp_write+0xb0>
    8c98:	f9400f80 	ldr	x0, [x28, #24]
    8c9c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8ca0:	aa1b03e0 	mov	x0, x27
    8ca4:	97ffe677 	bl	2680 <strlen@plt>
    8ca8:	aa1b03e1 	mov	x1, x27
    8cac:	aa0003e2 	mov	x2, x0
    8cb0:	aa1403e0 	mov	x0, x20
    8cb4:	97ffe9b7 	bl	3390 <buf_put>
    8cb8:	aa1903e1 	mov	x1, x25
    8cbc:	aa1403e0 	mov	x0, x20
    8cc0:	d2800062 	mov	x2, #0x3                   	// #3
    8cc4:	97ffe9b3 	bl	3390 <buf_put>
    8cc8:	17fffe10 	b	8508 <fwp_write+0x2d8>
    8ccc:	aa1a03e1 	mov	x1, x26
    8cd0:	aa1403e0 	mov	x0, x20
    8cd4:	d2800042 	mov	x2, #0x2                   	// #2
    8cd8:	97ffe9ae 	bl	3390 <buf_put>
    8cdc:	17fffe09 	b	8500 <fwp_write+0x2d0>
    8ce0:	f9400660 	ldr	x0, [x19, #8]
    8ce4:	b4fffb00 	cbz	x0, 8c44 <fwp_write+0xa14>
    8ce8:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8cec:	91180021 	add	x1, x1, #0x600
    8cf0:	97ffe6e0 	bl	2870 <strcmp@plt>
    8cf4:	7100001f 	cmp	w0, #0x0
    8cf8:	1a9f07e0 	cset	w0, ne	// ne = any
    8cfc:	17ffff2f 	b	89b8 <fwp_write+0x788>
    8d00:	aa1403e0 	mov	x0, x20
    8d04:	d2800042 	mov	x2, #0x2                   	// #2
    8d08:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8d0c:	9117e021 	add	x1, x1, #0x5f8
    8d10:	97ffe9a0 	bl	3390 <buf_put>
    8d14:	91004261 	add	x1, x19, #0x10
    8d18:	aa1403e0 	mov	x0, x20
    8d1c:	f9402382 	ldr	x2, [x28, #64]
    8d20:	52800003 	mov	w3, #0x0                   	// #0
    8d24:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8d28:	97fffd42 	bl	8230 <fwp_write>
    8d2c:	17fffd9c 	b	839c <fwp_write+0x16c>
    8d30:	1e22c109 	fcvt	d9, s8
    8d34:	910123f5 	add	x21, sp, #0x48
    8d38:	52800033 	mov	w19, #0x1                   	// #1
    8d3c:	d503201f 	nop
    8d40:	1e604120 	fmov	d0, d9
    8d44:	2a1303e1 	mov	w1, w19
    8d48:	aa1503e0 	mov	x0, x21
    8d4c:	97ffead2 	bl	3894 <fwp_format_g.constprop.0>
    8d50:	aa1503e0 	mov	x0, x21
    8d54:	d2800001 	mov	x1, #0x0                   	// #0
    8d58:	97ffe6d2 	bl	28a0 <strtof@plt>
    8d5c:	1e202100 	fcmp	s8, s0
    8d60:	54ffdb60 	b.eq	88cc <fwp_write+0x69c>  // b.none
    8d64:	11000673 	add	w19, w19, #0x1
    8d68:	71002a7f 	cmp	w19, #0xa
    8d6c:	54fffea1 	b.ne	8d40 <fwp_write+0xb10>  // b.any
    8d70:	1e604120 	fmov	d0, d9
    8d74:	aa1503e0 	mov	x0, x21
    8d78:	52800121 	mov	w1, #0x9                   	// #9
    8d7c:	97ffeac6 	bl	3894 <fwp_format_g.constprop.0>
    8d80:	17fffed3 	b	88cc <fwp_write+0x69c>
    8d84:	d37ef6a1 	lsl	x1, x21, #2
    8d88:	b7f81563 	tbnz	x3, #63, 9034 <fwp_write+0xe04>
    8d8c:	91002263 	add	x3, x19, #0x8
    8d90:	8b010061 	add	x1, x3, x1
    8d94:	b9400023 	ldr	w3, [x1]
    8d98:	7100081f 	cmp	w0, #0x2
    8d9c:	2a0303e1 	mov	w1, w3
    8da0:	93407c63 	sxtw	x3, w3
    8da4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8da8:	17fffe5a 	b	8710 <fwp_write+0x4e0>
    8dac:	d37ffaa1 	lsl	x1, x21, #1
    8db0:	b7f81363 	tbnz	x3, #63, 901c <fwp_write+0xdec>
    8db4:	91002263 	add	x3, x19, #0x8
    8db8:	8b010061 	add	x1, x3, x1
    8dbc:	79400021 	ldrh	w1, [x1]
    8dc0:	7100041f 	cmp	w0, #0x1
    8dc4:	93403c23 	sxth	x3, w1
    8dc8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8dcc:	17fffe51 	b	8710 <fwp_write+0x4e0>
    8dd0:	52800443 	mov	w3, #0x22                  	// #34
    8dd4:	91001ff5 	add	x21, sp, #0x7
    8dd8:	91002273 	add	x19, x19, #0x8
    8ddc:	aa1503e1 	mov	x1, x21
    8de0:	aa1403e0 	mov	x0, x20
    8de4:	d2800022 	mov	x2, #0x1                   	// #1
    8de8:	39001fe3 	strb	w3, [sp, #7]
    8dec:	f90143f7 	str	x23, [sp, #640]
    8df0:	8b160277 	add	x23, x19, x22
    8df4:	f90147f8 	str	x24, [sp, #648]
    8df8:	97ffe966 	bl	3390 <buf_put>
    8dfc:	b4000696 	cbz	x22, 8ecc <fwp_write+0xc9c>
    8e00:	b0000038 	adrp	x24, d000 <__modti3+0x310>
    8e04:	9116a318 	add	x24, x24, #0x5a8
    8e08:	f9014bf9 	str	x25, [sp, #656]
    8e0c:	b0000039 	adrp	x25, d000 <__modti3+0x310>
    8e10:	91172339 	add	x25, x25, #0x5c8
    8e14:	f9014ffa 	str	x26, [sp, #664]
    8e18:	1400000d 	b	8e4c <fwp_write+0xc1c>
    8e1c:	710024bf 	cmp	w5, #0x9
    8e20:	54000460 	b.eq	8eac <fwp_write+0xc7c>  // b.none
    8e24:	710028bf 	cmp	w5, #0xa
    8e28:	54000a61 	b.ne	8f74 <fwp_write+0xd44>  // b.any
    8e2c:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8e30:	aa1403e0 	mov	x0, x20
    8e34:	9116e021 	add	x1, x1, #0x5b8
    8e38:	d2800042 	mov	x2, #0x2                   	// #2
    8e3c:	97ffe955 	bl	3390 <buf_put>
    8e40:	91000673 	add	x19, x19, #0x1
    8e44:	eb17027f 	cmp	x19, x23
    8e48:	540003e0 	b.eq	8ec4 <fwp_write+0xc94>  // b.none
    8e4c:	39400265 	ldrb	w5, [x19]
    8e50:	710034bf 	cmp	w5, #0xd
    8e54:	54000180 	b.eq	8e84 <fwp_write+0xc54>  // b.none
    8e58:	54fffe29 	b.ls	8e1c <fwp_write+0xbec>  // b.plast
    8e5c:	710088bf 	cmp	w5, #0x22
    8e60:	540001c0 	b.eq	8e98 <fwp_write+0xc68>  // b.none
    8e64:	710170bf 	cmp	w5, #0x5c
    8e68:	54000741 	b.ne	8f50 <fwp_write+0xd20>  // b.any
    8e6c:	aa1403e0 	mov	x0, x20
    8e70:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8e74:	d2800042 	mov	x2, #0x2                   	// #2
    8e78:	9116c021 	add	x1, x1, #0x5b0
    8e7c:	97ffe945 	bl	3390 <buf_put>
    8e80:	17fffff0 	b	8e40 <fwp_write+0xc10>
    8e84:	aa1903e1 	mov	x1, x25
    8e88:	aa1403e0 	mov	x0, x20
    8e8c:	d2800042 	mov	x2, #0x2                   	// #2
    8e90:	97ffe940 	bl	3390 <buf_put>
    8e94:	17ffffeb 	b	8e40 <fwp_write+0xc10>
    8e98:	aa1803e1 	mov	x1, x24
    8e9c:	aa1403e0 	mov	x0, x20
    8ea0:	d2800042 	mov	x2, #0x2                   	// #2
    8ea4:	97ffe93b 	bl	3390 <buf_put>
    8ea8:	17ffffe6 	b	8e40 <fwp_write+0xc10>
    8eac:	aa1403e0 	mov	x0, x20
    8eb0:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8eb4:	d2800042 	mov	x2, #0x2                   	// #2
    8eb8:	91170021 	add	x1, x1, #0x5c0
    8ebc:	97ffe935 	bl	3390 <buf_put>
    8ec0:	17ffffe0 	b	8e40 <fwp_write+0xc10>
    8ec4:	f9414bf9 	ldr	x25, [sp, #656]
    8ec8:	f9414ffa 	ldr	x26, [sp, #664]
    8ecc:	aa1503e1 	mov	x1, x21
    8ed0:	aa1403e0 	mov	x0, x20
    8ed4:	52800443 	mov	w3, #0x22                  	// #34
    8ed8:	17fffd9c 	b	8548 <fwp_write+0x318>
    8edc:	7100103f 	cmp	w1, #0x4
    8ee0:	54ffeb21 	b.ne	8c44 <fwp_write+0xa14>  // b.any
    8ee4:	f94006e0 	ldr	x0, [x23, #8]
    8ee8:	d37ffc00 	lsr	x0, x0, #63
    8eec:	17fffeb3 	b	89b8 <fwp_write+0x788>
    8ef0:	710002ff 	cmp	w23, #0x0
    8ef4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8ef8:	17fffeb0 	b	89b8 <fwp_write+0x788>
    8efc:	528005a1 	mov	w1, #0x2d                  	// #45
    8f00:	eb0203e2 	negs	x2, x2
    8f04:	da0303e3 	ngc	x3, x3
    8f08:	910127e0 	add	x0, sp, #0x49
    8f0c:	910123f5 	add	x21, sp, #0x48
    8f10:	390123e1 	strb	w1, [sp, #72]
    8f14:	97ffe7a3 	bl	2da0 <fwp_fmt_u128>
    8f18:	17fffe18 	b	8778 <fwp_write+0x548>
    8f1c:	d37ceea1 	lsl	x1, x21, #4
    8f20:	b7f810a3 	tbnz	x3, #63, 9134 <fwp_write+0xf04>
    8f24:	91002260 	add	x0, x19, #0x8
    8f28:	8b010001 	add	x1, x0, x1
    8f2c:	17fffdf9 	b	8710 <fwp_write+0x4e0>
    8f30:	f9400a61 	ldr	x1, [x19, #16]
    8f34:	8b010000 	add	x0, x0, x1
    8f38:	f9400001 	ldr	x1, [x0]
    8f3c:	17fffdf5 	b	8710 <fwp_write+0x4e0>
    8f40:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8f44:	d2800042 	mov	x2, #0x2                   	// #2
    8f48:	91154021 	add	x1, x1, #0x550
    8f4c:	17fffed6 	b	8aa4 <fwp_write+0x874>
    8f50:	7101fcbf 	cmp	w5, #0x7f
    8f54:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8f58:	540000e9 	b.ls	8f74 <fwp_write+0xd44>  // b.plast
    8f5c:	aa1503e1 	mov	x1, x21
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	d2800022 	mov	x2, #0x1                   	// #1
    8f68:	39001fe5 	strb	w5, [sp, #7]
    8f6c:	97ffe909 	bl	3390 <buf_put>
    8f70:	17ffffb4 	b	8e40 <fwp_write+0xc10>
    8f74:	d2800203 	mov	x3, #0x10                  	// #16
    8f78:	b0000024 	adrp	x4, d000 <__modti3+0x310>
    8f7c:	aa0303e1 	mov	x1, x3
    8f80:	91174084 	add	x4, x4, #0x5d0
    8f84:	910123f6 	add	x22, sp, #0x48
    8f88:	52800042 	mov	w2, #0x2                   	// #2
    8f8c:	aa1603e0 	mov	x0, x22
    8f90:	97ffe5f4 	bl	2760 <__snprintf_chk@plt>
    8f94:	aa1603e0 	mov	x0, x22
    8f98:	97ffe5ba 	bl	2680 <strlen@plt>
    8f9c:	aa1603e1 	mov	x1, x22
    8fa0:	aa0003e2 	mov	x2, x0
    8fa4:	aa1403e0 	mov	x0, x20
    8fa8:	97ffe8fa 	bl	3390 <buf_put>
    8fac:	17ffffa5 	b	8e40 <fwp_write+0xc10>
    8fb0:	1e604100 	fmov	d0, d8
    8fb4:	aa1503e0 	mov	x0, x21
    8fb8:	52800221 	mov	w1, #0x11                  	// #17
    8fbc:	97ffea36 	bl	3894 <fwp_format_g.constprop.0>
    8fc0:	17fffe43 	b	88cc <fwp_write+0x69c>
    8fc4:	b9401040 	ldr	w0, [x2, #16]
    8fc8:	350003c0 	cbnz	w0, 9040 <fwp_write+0xe10>
    8fcc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8fd0:	f947f400 	ldr	x0, [x0, #4072]
    8fd4:	f94127e2 	ldr	x2, [sp, #584]
    8fd8:	f9400001 	ldr	x1, [x0]
    8fdc:	eb010042 	subs	x2, x2, x1
    8fe0:	d2800001 	mov	x1, #0x0                   	// #0
    8fe4:	54ffd721 	b.ne	8ac8 <fwp_write+0x898>  // b.any
    8fe8:	f9413bf5 	ldr	x21, [sp, #624]
    8fec:	b0000021 	adrp	x1, d000 <__modti3+0x310>
    8ff0:	f9413ff6 	ldr	x22, [sp, #632]
    8ff4:	aa1403e0 	mov	x0, x20
    8ff8:	f94143f7 	ldr	x23, [sp, #640]
    8ffc:	91188021 	add	x1, x1, #0x620
    9000:	f94147f8 	ldr	x24, [sp, #648]
    9004:	d2800042 	mov	x2, #0x2                   	// #2
    9008:	17fffd0e 	b	8440 <fwp_write+0x210>
    900c:	90000021 	adrp	x1, d000 <__modti3+0x310>
    9010:	d2800042 	mov	x2, #0x2                   	// #2
    9014:	91156021 	add	x1, x1, #0x558
    9018:	17fffea3 	b	8aa4 <fwp_write+0x874>
    901c:	f9400a63 	ldr	x3, [x19, #16]
    9020:	8b030021 	add	x1, x1, x3
    9024:	17ffff66 	b	8dbc <fwp_write+0xb8c>
    9028:	f9400a61 	ldr	x1, [x19, #16]
    902c:	8b0102a1 	add	x1, x21, x1
    9030:	17fffdb3 	b	86fc <fwp_write+0x4cc>
    9034:	f9400a63 	ldr	x3, [x19, #16]
    9038:	8b030021 	add	x1, x1, x3
    903c:	17ffff56 	b	8d94 <fwp_write+0xb64>
    9040:	b9404840 	ldr	w0, [x2, #72]
    9044:	91001ff5 	add	x21, sp, #0x7
    9048:	34ffa360 	cbz	w0, 84b4 <fwp_write+0x284>
    904c:	52800503 	mov	w3, #0x28                  	// #40
    9050:	aa1403e0 	mov	x0, x20
    9054:	aa1503e1 	mov	x1, x21
    9058:	d2800022 	mov	x2, #0x1                   	// #1
    905c:	39001fe3 	strb	w3, [sp, #7]
    9060:	97ffe8cc 	bl	3390 <buf_put>
    9064:	b9401380 	ldr	w0, [x28, #16]
    9068:	52800038 	mov	w24, #0x1                   	// #1
    906c:	7100001f 	cmp	w0, #0x0
    9070:	54ffa36c 	b.gt	84dc <fwp_write+0x2ac>
    9074:	17fffd32 	b	853c <fwp_write+0x30c>
    9078:	f9014bf9 	str	x25, [sp, #656]
    907c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xee50>
    9080:	f9014ffa 	str	x26, [sp, #664]
    9084:	f9400676 	ldr	x22, [x19, #8]
    9088:	91102333 	add	x19, x25, #0x408
    908c:	91002273 	add	x19, x19, #0x8
    9090:	937ffed8 	asr	x24, x22, #63
    9094:	aa1802c0 	orr	x0, x22, x24
    9098:	b5000320 	cbnz	x0, 90fc <fwp_write+0xecc>
    909c:	110006b5 	add	w21, w21, #0x1
    90a0:	710016bf 	cmp	w21, #0x5
    90a4:	54ffffc1 	b.ne	909c <fwp_write+0xe6c>  // b.any
    90a8:	b7f80578 	tbnz	x24, #63, 9154 <fwp_write+0xf24>
    90ac:	910023f3 	add	x19, sp, #0x8
    90b0:	aa1603e2 	mov	x2, x22
    90b4:	aa1303e0 	mov	x0, x19
    90b8:	d2800003 	mov	x3, #0x0                   	// #0
    90bc:	97ffe739 	bl	2da0 <fwp_fmt_u128>
    90c0:	910123f5 	add	x21, sp, #0x48
    90c4:	90000023 	adrp	x3, d000 <__modti3+0x310>
    90c8:	aa1303e4 	mov	x4, x19
    90cc:	aa1503e0 	mov	x0, x21
    90d0:	91186063 	add	x3, x3, #0x618
    90d4:	d2804002 	mov	x2, #0x200                 	// #512
    90d8:	52800041 	mov	w1, #0x2                   	// #2
    90dc:	97ffe56d 	bl	2690 <__sprintf_chk@plt>
    90e0:	aa1503e0 	mov	x0, x21
    90e4:	97ffe567 	bl	2680 <strlen@plt>
    90e8:	aa1503e1 	mov	x1, x21
    90ec:	aa0003e2 	mov	x2, x0
    90f0:	aa1403e0 	mov	x0, x20
    90f4:	97ffe8a7 	bl	3390 <buf_put>
    90f8:	17fffe47 	b	8a14 <fwp_write+0x7e4>
    90fc:	f9400277 	ldr	x23, [x19]
    9100:	aa1603e0 	mov	x0, x22
    9104:	aa1803e1 	mov	x1, x24
    9108:	aa1703e2 	mov	x2, x23
    910c:	937ffefa 	asr	x26, x23, #63
    9110:	aa1a03e3 	mov	x3, x26
    9114:	94000ef7 	bl	ccf0 <__modti3>
    9118:	aa010000 	orr	x0, x0, x1
    911c:	b40002c0 	cbz	x0, 9174 <fwp_write+0xf44>
    9120:	110006b5 	add	w21, w21, #0x1
    9124:	91004273 	add	x19, x19, #0x10
    9128:	710016bf 	cmp	w21, #0x5
    912c:	54fffe81 	b.ne	90fc <fwp_write+0xecc>  // b.any
    9130:	17ffffde 	b	90a8 <fwp_write+0xe78>
    9134:	f9400a60 	ldr	x0, [x19, #16]
    9138:	8b000021 	add	x1, x1, x0
    913c:	17fffd75 	b	8710 <fwp_write+0x4e0>
    9140:	528c29c0 	mov	w0, #0x614e                	// #24910
    9144:	910123f5 	add	x21, sp, #0x48
    9148:	72a009c0 	movk	w0, #0x4e, lsl #16
    914c:	b9004be0 	str	w0, [sp, #72]
    9150:	17fffda2 	b	87d8 <fwp_write+0x5a8>
    9154:	528005a1 	mov	w1, #0x2d                  	// #45
    9158:	eb1603e2 	negs	x2, x22
    915c:	da1803e3 	ngc	x3, x24
    9160:	910027e0 	add	x0, sp, #0x9
    9164:	910023f3 	add	x19, sp, #0x8
    9168:	390023e1 	strb	w1, [sp, #8]
    916c:	97ffe70d 	bl	2da0 <fwp_fmt_u128>
    9170:	17ffffd4 	b	90c0 <fwp_write+0xe90>
    9174:	aa1703e2 	mov	x2, x23
    9178:	aa1a03e3 	mov	x3, x26
    917c:	aa1603e0 	mov	x0, x22
    9180:	aa1803e1 	mov	x1, x24
    9184:	94000dfb 	bl	c970 <__divti3>
    9188:	aa0003e2 	mov	x2, x0
    918c:	aa0103e3 	mov	x3, x1
    9190:	b7f80201 	tbnz	x1, #63, 91d0 <fwp_write+0xfa0>
    9194:	910023f3 	add	x19, sp, #0x8
    9198:	aa1303e0 	mov	x0, x19
    919c:	97ffe701 	bl	2da0 <fwp_fmt_u128>
    91a0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    91a4:	91102339 	add	x25, x25, #0x408
    91a8:	910123f5 	add	x21, sp, #0x48
    91ac:	aa1303e4 	mov	x4, x19
    91b0:	aa1503e0 	mov	x0, x21
    91b4:	90000023 	adrp	x3, d000 <__modti3+0x310>
    91b8:	f8616b25 	ldr	x5, [x25, x1]
    91bc:	91184063 	add	x3, x3, #0x610
    91c0:	d2804002 	mov	x2, #0x200                 	// #512
    91c4:	52800041 	mov	w1, #0x2                   	// #2
    91c8:	97ffe532 	bl	2690 <__sprintf_chk@plt>
    91cc:	17ffffc5 	b	90e0 <fwp_write+0xeb0>
    91d0:	528005a4 	mov	w4, #0x2d                  	// #45
    91d4:	eb0003e2 	negs	x2, x0
    91d8:	da0103e3 	ngc	x3, x1
    91dc:	910027e0 	add	x0, sp, #0x9
    91e0:	910023f3 	add	x19, sp, #0x8
    91e4:	390023e4 	strb	w4, [sp, #8]
    91e8:	97ffe6ee 	bl	2da0 <fwp_fmt_u128>
    91ec:	17ffffed 	b	91a0 <fwp_write+0xf70>
    91f0:	f9013bf5 	str	x21, [sp, #624]
    91f4:	f9013ff6 	str	x22, [sp, #632]
    91f8:	f90143f7 	str	x23, [sp, #640]
    91fc:	f90147f8 	str	x24, [sp, #648]
    9200:	f9014bf9 	str	x25, [sp, #656]
    9204:	f9014ffa 	str	x26, [sp, #664]
    9208:	f90153fb 	str	x27, [sp, #672]
    920c:	f90157fc 	str	x28, [sp, #680]
    9210:	fd015be8 	str	d8, [sp, #688]
    9214:	fd015fe9 	str	d9, [sp, #696]
    9218:	97ffe576 	bl	27f0 <__stack_chk_fail@plt>
    921c:	d503201f 	nop

0000000000009220 <fwp_hof0.constprop.0>:
    9220:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9224:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9228:	f947f442 	ldr	x2, [x2, #4072]
    922c:	910003fd 	mov	x29, sp
    9230:	a90153f3 	stp	x19, x20, [sp, #16]
    9234:	a9025bf5 	stp	x21, x22, [sp, #32]
    9238:	a90363f7 	stp	x23, x24, [sp, #48]
    923c:	aa0003f7 	mov	x23, x0
    9240:	a9046bf9 	stp	x25, x26, [sp, #64]
    9244:	a90573fb 	stp	x27, x28, [sp, #80]
    9248:	d10243ff 	sub	sp, sp, #0x90
    924c:	f9400040 	ldr	x0, [x2]
    9250:	f81f83a0 	stur	x0, [x29, #-8]
    9254:	d2800000 	mov	x0, #0x0                   	// #0
    9258:	b4002da1 	cbz	x1, 980c <fwp_hof0.constprop.0+0x5ec>
    925c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9260:	9100401c 	add	x28, x0, #0x10
    9264:	9100239c 	add	x28, x28, #0x8
    9268:	f00000a0 	adrp	x0, 20000 <__data_start>
    926c:	aa0103fa 	mov	x26, x1
    9270:	d10083b4 	sub	x20, x29, #0x20
    9274:	91010015 	add	x21, x0, #0x40
    9278:	aa1c03f8 	mov	x24, x28
    927c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9280:	91154002 	add	x2, x0, #0x550
    9284:	f949d841 	ldr	x1, [x2, #5040]
    9288:	f949ec40 	ldr	x0, [x2, #5080]
    928c:	cb0102e1 	sub	x1, x23, x1
    9290:	eb00403f 	cmp	x1, x0, lsl #16
    9294:	54000342 	b.cs	92fc <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9298:	d350fc20 	lsr	x0, x1, #16
    929c:	f949fc44 	ldr	x4, [x2, #5112]
    92a0:	8b000800 	add	x0, x0, x0, lsl #2
    92a4:	d37df002 	lsl	x2, x0, #3
    92a8:	8b020083 	add	x3, x4, x2
    92ac:	f9401060 	ldr	x0, [x3, #32]
    92b0:	b4000260 	cbz	x0, 92fc <fwp_hof0.constprop.0+0xdc>
    92b4:	38626882 	ldrb	w2, [x4, x2]
    92b8:	7100085f 	cmp	w2, #0x2
    92bc:	54005240 	b.eq	9d04 <fwp_hof0.constprop.0+0xae4>  // b.none
    92c0:	7100045f 	cmp	w2, #0x1
    92c4:	540001c1 	b.ne	92fc <fwp_hof0.constprop.0+0xdc>  // b.any
    92c8:	29430864 	ldp	w4, w2, [x3, #24]
    92cc:	92403c21 	and	x1, x1, #0xffff
    92d0:	9b047c21 	mul	x1, x1, x4
    92d4:	d360fc21 	lsr	x1, x1, #32
    92d8:	eb02003f 	cmp	x1, x2
    92dc:	54000102 	b.cs	92fc <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    92e0:	8b010000 	add	x0, x0, x1
    92e4:	39400001 	ldrb	w1, [x0]
    92e8:	340000a1 	cbz	w1, 92fc <fwp_hof0.constprop.0+0xdc>
    92ec:	7103f43f 	cmp	w1, #0xfd
    92f0:	54005728 	b.hi	9dd4 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    92f4:	11000421 	add	w1, w1, #0x1
    92f8:	39000001 	strb	w1, [x0]
    92fc:	aa1703f9 	mov	x25, x23
    9300:	a938dfba 	stp	x26, x23, [x29, #-120]
    9304:	aa1803fa 	mov	x26, x24
    9308:	d28018f3 	mov	x19, #0xc7                  	// #199
    930c:	f81983b3 	stur	x19, [x29, #-104]
    9310:	f00000a0 	adrp	x0, 20000 <__data_start>
    9314:	91004000 	add	x0, x0, #0x10
    9318:	f9401ea3 	ldr	x3, [x21, #56]
    931c:	91002005 	add	x5, x0, #0x8
    9320:	b9400802 	ldr	w2, [x0, #8]
    9324:	d37be842 	lsl	x2, x2, #5
    9328:	8b02007b 	add	x27, x3, x2
    932c:	f9400f61 	ldr	x1, [x27, #24]
    9330:	f81e03b9 	stur	x25, [x29, #-32]
    9334:	b4004ee1 	cbz	x1, 9d10 <fwp_hof0.constprop.0+0xaf0>
    9338:	f9400c20 	ldr	x0, [x1, #24]
    933c:	b40042a0 	cbz	x0, 9b90 <fwp_hof0.constprop.0+0x970>
    9340:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9344:	91154002 	add	x2, x0, #0x550
    9348:	f949d841 	ldr	x1, [x2, #5040]
    934c:	f949ec40 	ldr	x0, [x2, #5080]
    9350:	cb010341 	sub	x1, x26, x1
    9354:	eb00403f 	cmp	x1, x0, lsl #16
    9358:	54000342 	b.cs	93c0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    935c:	d350fc20 	lsr	x0, x1, #16
    9360:	f949fc45 	ldr	x5, [x2, #5112]
    9364:	8b000800 	add	x0, x0, x0, lsl #2
    9368:	d37df002 	lsl	x2, x0, #3
    936c:	8b0200a3 	add	x3, x5, x2
    9370:	f9401060 	ldr	x0, [x3, #32]
    9374:	b4000260 	cbz	x0, 93c0 <fwp_hof0.constprop.0+0x1a0>
    9378:	386268a2 	ldrb	w2, [x5, x2]
    937c:	7100085f 	cmp	w2, #0x2
    9380:	54004700 	b.eq	9c60 <fwp_hof0.constprop.0+0xa40>  // b.none
    9384:	7100045f 	cmp	w2, #0x1
    9388:	540001c1 	b.ne	93c0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    938c:	29430865 	ldp	w5, w2, [x3, #24]
    9390:	92403c21 	and	x1, x1, #0xffff
    9394:	9b057c21 	mul	x1, x1, x5
    9398:	d360fc21 	lsr	x1, x1, #32
    939c:	eb02003f 	cmp	x1, x2
    93a0:	54000102 	b.cs	93c0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    93a4:	8b010000 	add	x0, x0, x1
    93a8:	39400001 	ldrb	w1, [x0]
    93ac:	340000a1 	cbz	w1, 93c0 <fwp_hof0.constprop.0+0x1a0>
    93b0:	7103f43f 	cmp	w1, #0xfd
    93b4:	54004988 	b.hi	9ce4 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    93b8:	11000421 	add	w1, w1, #0x1
    93bc:	39000001 	strb	w1, [x0]
    93c0:	aa1a03f9 	mov	x25, x26
    93c4:	aa1a03e0 	mov	x0, x26
    93c8:	aa1b03e3 	mov	x3, x27
    93cc:	52800037 	mov	w23, #0x1                   	// #1
    93d0:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    93d4:	91154036 	add	x22, x1, #0x550
    93d8:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    93dc:	f81b03b6 	stur	x22, [x29, #-80]
    93e0:	b81cc3b7 	stur	w23, [x29, #-52]
    93e4:	f81d03b4 	stur	x20, [x29, #-48]
    93e8:	b9400401 	ldr	w1, [x0, #4]
    93ec:	b9400078 	ldr	w24, [x3]
    93f0:	b85cc3a0 	ldur	w0, [x29, #-52]
    93f4:	4b010318 	sub	w24, w24, w1
    93f8:	6b17031f 	cmp	w24, w23
    93fc:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9400:	6b0000ff 	cmp	w7, w0
    9404:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9408:	b81c83a0 	stur	w0, [x29, #-56]
    940c:	6b0000e2 	subs	w2, w7, w0
    9410:	54000120 	b.eq	9434 <fwp_hof0.constprop.0+0x214>  // b.none
    9414:	f9400c63 	ldr	x3, [x3, #24]
    9418:	0b000021 	add	w1, w1, w0
    941c:	f85d03a4 	ldur	x4, [x29, #-48]
    9420:	b81d83a7 	stur	w7, [x29, #-40]
    9424:	f9400863 	ldr	x3, [x3, #16]
    9428:	8b204c80 	add	x0, x4, w0, uxtw #3
    942c:	d63f0060 	blr	x3
    9430:	b85d83a7 	ldur	w7, [x29, #-40]
    9434:	f9401ea0 	ldr	x0, [x21, #56]
    9438:	aa1903e6 	mov	x6, x25
    943c:	b9400323 	ldr	w3, [x25]
    9440:	2a0703f4 	mov	w20, w7
    9444:	f85d03bb 	ldur	x27, [x29, #-48]
    9448:	aa1903fc 	mov	x28, x25
    944c:	8b03141a 	add	x26, x0, x3, lsl #5
    9450:	f9400f40 	ldr	x0, [x26, #24]
    9454:	b40020e0 	cbz	x0, 9870 <fwp_hof0.constprop.0+0x650>
    9458:	f85b03bc 	ldur	x28, [x29, #-80]
    945c:	29371fb7 	stp	w23, w7, [x29, #-72]
    9460:	aa1a03f7 	mov	x23, x26
    9464:	b81c03b8 	stur	w24, [x29, #-64]
    9468:	aa1b03f8 	mov	x24, x27
    946c:	14000012 	b	94b4 <fwp_hof0.constprop.0+0x294>
    9470:	f9400001 	ldr	x1, [x0]
    9474:	aa1803e0 	mov	x0, x24
    9478:	d63f0020 	blr	x1
    947c:	aa0003fb 	mov	x27, x0
    9480:	aa1903e0 	mov	x0, x25
    9484:	97fff1eb 	bl	5c30 <fwp_closure_drop>
    9488:	6b13029f 	cmp	w20, w19
    948c:	54000ca0 	b.eq	9620 <fwp_hof0.constprop.0+0x400>  // b.none
    9490:	f9401ea0 	ldr	x0, [x21, #56]
    9494:	8b334f18 	add	x24, x24, w19, uxtw #3
    9498:	b9400363 	ldr	w3, [x27]
    949c:	4b1a02d4 	sub	w20, w22, w26
    94a0:	aa1b03e6 	mov	x6, x27
    94a4:	8b031417 	add	x23, x0, x3, lsl #5
    94a8:	f9400ee0 	ldr	x0, [x23, #24]
    94ac:	b4001da0 	cbz	x0, 9860 <fwp_hof0.constprop.0+0x640>
    94b0:	aa1b03f9 	mov	x25, x27
    94b4:	b94004c1 	ldr	w1, [x6, #4]
    94b8:	b94002fa 	ldr	w26, [x23]
    94bc:	0b010296 	add	w22, w20, w1
    94c0:	6b16035f 	cmp	w26, w22
    94c4:	54002488 	b.hi	9954 <fwp_hof0.constprop.0+0x734>  // b.pmore
    94c8:	7100003f 	cmp	w1, #0x0
    94cc:	4b010353 	sub	w19, w26, w1
    94d0:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    94d4:	54fffce1 	b.ne	9470 <fwp_hof0.constprop.0+0x250>  // b.any
    94d8:	7100035f 	cmp	w26, #0x0
    94dc:	910003e2 	mov	x2, sp
    94e0:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    94e4:	f81d83a2 	stur	x2, [x29, #-40]
    94e8:	d37df084 	lsl	x4, x4, #3
    94ec:	91003c84 	add	x4, x4, #0xf
    94f0:	92704c87 	and	x7, x4, #0xfffff0000
    94f4:	927c7c84 	and	x4, x4, #0xffffffff0
    94f8:	cb2763e7 	sub	x7, sp, x7
    94fc:	eb2763ff 	cmp	sp, x7
    9500:	540000a0 	b.eq	9514 <fwp_hof0.constprop.0+0x2f4>  // b.none
    9504:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9508:	f90203ff 	str	xzr, [sp, #1024]
    950c:	eb2763ff 	cmp	sp, x7
    9510:	54ffffa1 	b.ne	9504 <fwp_hof0.constprop.0+0x2e4>  // b.any
    9514:	92403c84 	and	x4, x4, #0xffff
    9518:	cb2463ff 	sub	sp, sp, x4
    951c:	f90003ff 	str	xzr, [sp]
    9520:	f110009f 	cmp	x4, #0x400
    9524:	54000043 	b.cc	952c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9528:	f90203ff 	str	xzr, [sp, #1024]
    952c:	910043fb 	add	x27, sp, #0x10
    9530:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9534:	910020c9 	add	x9, x6, #0x8
    9538:	d2800004 	mov	x4, #0x0                   	// #0
    953c:	340000c1 	cbz	w1, 9554 <fwp_hof0.constprop.0+0x334>
    9540:	f8646922 	ldr	x2, [x9, x4]
    9544:	f8246b62 	str	x2, [x27, x4]
    9548:	91002084 	add	x4, x4, #0x8
    954c:	eb04015f 	cmp	x10, x4
    9550:	54ffff81 	b.ne	9540 <fwp_hof0.constprop.0+0x320>  // b.any
    9554:	2a1303ea 	mov	w10, w19
    9558:	d2800004 	mov	x4, #0x0                   	// #0
    955c:	340000f3 	cbz	w19, 9578 <fwp_hof0.constprop.0+0x358>
    9560:	0b040022 	add	w2, w1, w4
    9564:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9568:	91000484 	add	x4, x4, #0x1
    956c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9570:	eb04015f 	cmp	x10, x4
    9574:	54ffff61 	b.ne	9560 <fwp_hof0.constprop.0+0x340>  // b.any
    9578:	f949db81 	ldr	x1, [x28, #5040]
    957c:	f949ef84 	ldr	x4, [x28, #5080]
    9580:	cb010321 	sub	x1, x25, x1
    9584:	eb04403f 	cmp	x1, x4, lsl #16
    9588:	540002e2 	b.cs	95e4 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    958c:	d350fc24 	lsr	x4, x1, #16
    9590:	f949ff8a 	ldr	x10, [x28, #5112]
    9594:	8b040884 	add	x4, x4, x4, lsl #2
    9598:	d37df084 	lsl	x4, x4, #3
    959c:	8b040149 	add	x9, x10, x4
    95a0:	f9401128 	ldr	x8, [x9, #32]
    95a4:	b4000208 	cbz	x8, 95e4 <fwp_hof0.constprop.0+0x3c4>
    95a8:	38646944 	ldrb	w4, [x10, x4]
    95ac:	7100089f 	cmp	w4, #0x2
    95b0:	54001520 	b.eq	9854 <fwp_hof0.constprop.0+0x634>  // b.none
    95b4:	7100049f 	cmp	w4, #0x1
    95b8:	54000161 	b.ne	95e4 <fwp_hof0.constprop.0+0x3c4>  // b.any
    95bc:	2943112a 	ldp	w10, w4, [x9, #24]
    95c0:	92403c21 	and	x1, x1, #0xffff
    95c4:	9b0a7c21 	mul	x1, x1, x10
    95c8:	d360fc21 	lsr	x1, x1, #32
    95cc:	eb04003f 	cmp	x1, x4
    95d0:	540000a2 	b.cs	95e4 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    95d4:	8b010108 	add	x8, x8, x1
    95d8:	39400101 	ldrb	w1, [x8]
    95dc:	7100043f 	cmp	w1, #0x1
    95e0:	54001360 	b.eq	984c <fwp_hof0.constprop.0+0x62c>  // b.none
    95e4:	f9400404 	ldr	x4, [x0, #8]
    95e8:	52800021 	mov	w1, #0x1                   	// #1
    95ec:	aa1903e0 	mov	x0, x25
    95f0:	d63f0080 	blr	x4
    95f4:	f9400ee1 	ldr	x1, [x23, #24]
    95f8:	aa1b03e0 	mov	x0, x27
    95fc:	f9400021 	ldr	x1, [x1]
    9600:	d63f0020 	blr	x1
    9604:	aa0003fb 	mov	x27, x0
    9608:	f85d83a0 	ldur	x0, [x29, #-40]
    960c:	9100001f 	mov	sp, x0
    9610:	aa1903e0 	mov	x0, x25
    9614:	97fff187 	bl	5c30 <fwp_closure_drop>
    9618:	6b13029f 	cmp	w20, w19
    961c:	54fff3a1 	b.ne	9490 <fwp_hof0.constprop.0+0x270>  // b.any
    9620:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9624:	aa1b03f9 	mov	x25, x27
    9628:	b85c03b8 	ldur	w24, [x29, #-64]
    962c:	6b17031f 	cmp	w24, w23
    9630:	540014c3 	b.cc	98c8 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9634:	f85983a0 	ldur	x0, [x29, #-104]
    9638:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    963c:	f1000400 	subs	x0, x0, #0x1
    9640:	f81983a0 	stur	x0, [x29, #-104]
    9644:	54ffe661 	b.ne	9310 <fwp_hof0.constprop.0+0xf0>  // b.any
    9648:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xee50>
    964c:	91102042 	add	x2, x2, #0x408
    9650:	aa1903e1 	mov	x1, x25
    9654:	aa1403e0 	mov	x0, x20
    9658:	aa1a03f8 	mov	x24, x26
    965c:	aa1903fb 	mov	x27, x25
    9660:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9664:	91014042 	add	x2, x2, #0x50
    9668:	52800023 	mov	w3, #0x1                   	// #1
    966c:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9670:	f81f03bf 	stur	xzr, [x29, #-16]
    9674:	97fffaef 	bl	8230 <fwp_write>
    9678:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    967c:	90000020 	adrp	x0, d000 <__modti3+0x310>
    9680:	912a2000 	add	x0, x0, #0xa88
    9684:	f10002df 	cmp	x22, #0x0
    9688:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    968c:	b1002b3f 	cmn	x25, #0xa
    9690:	540039c8 	b.hi	9dc8 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9694:	91002720 	add	x0, x25, #0x9
    9698:	52800021 	mov	w1, #0x1                   	// #1
    969c:	97ffed55 	bl	4bf0 <fwp_heap_alloc>
    96a0:	aa0003f3 	mov	x19, x0
    96a4:	aa1603e1 	mov	x1, x22
    96a8:	aa0003f6 	mov	x22, x0
    96ac:	aa1903e2 	mov	x2, x25
    96b0:	f80086d9 	str	x25, [x22], #8
    96b4:	8b190279 	add	x25, x19, x25
    96b8:	aa1603e0 	mov	x0, x22
    96bc:	97ffe3e1 	bl	2640 <memcpy@plt>
    96c0:	3900233f 	strb	wzr, [x25, #8]
    96c4:	f85e03a0 	ldur	x0, [x29, #-32]
    96c8:	97ffe47a 	bl	28b0 <free@plt>
    96cc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    96d0:	91154002 	add	x2, x0, #0x550
    96d4:	f949d841 	ldr	x1, [x2, #5040]
    96d8:	f949ec40 	ldr	x0, [x2, #5080]
    96dc:	cb010261 	sub	x1, x19, x1
    96e0:	eb00403f 	cmp	x1, x0, lsl #16
    96e4:	54000322 	b.cs	9748 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    96e8:	d350fc20 	lsr	x0, x1, #16
    96ec:	f949fc43 	ldr	x3, [x2, #5112]
    96f0:	8b000800 	add	x0, x0, x0, lsl #2
    96f4:	d37df002 	lsl	x2, x0, #3
    96f8:	8b020060 	add	x0, x3, x2
    96fc:	f9401019 	ldr	x25, [x0, #32]
    9700:	b4000259 	cbz	x25, 9748 <fwp_hof0.constprop.0+0x528>
    9704:	38626862 	ldrb	w2, [x3, x2]
    9708:	7100085f 	cmp	w2, #0x2
    970c:	54003220 	b.eq	9d50 <fwp_hof0.constprop.0+0xb30>  // b.none
    9710:	7100045f 	cmp	w2, #0x1
    9714:	540001a1 	b.ne	9748 <fwp_hof0.constprop.0+0x528>  // b.any
    9718:	29430002 	ldp	w2, w0, [x0, #24]
    971c:	92403c21 	and	x1, x1, #0xffff
    9720:	9b027c21 	mul	x1, x1, x2
    9724:	d360fc21 	lsr	x1, x1, #32
    9728:	eb00003f 	cmp	x1, x0
    972c:	540000e2 	b.cs	9748 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9730:	8b010339 	add	x25, x25, x1
    9734:	39400320 	ldrb	w0, [x25]
    9738:	7103fc1f 	cmp	w0, #0xff
    973c:	54003520 	b.eq	9de0 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9740:	52800020 	mov	w0, #0x1                   	// #1
    9744:	39000320 	strb	w0, [x25]
    9748:	aa1b03e0 	mov	x0, x27
    974c:	97fff0dd 	bl	5ac0 <fwp_drop0>
    9750:	f00000a0 	adrp	x0, 20000 <__data_start>
    9754:	91010003 	add	x3, x0, #0x40
    9758:	f9400262 	ldr	x2, [x19]
    975c:	aa1603e0 	mov	x0, x22
    9760:	aa0303f6 	mov	x22, x3
    9764:	d2800021 	mov	x1, #0x1                   	// #1
    9768:	f9400463 	ldr	x3, [x3, #8]
    976c:	97ffe461 	bl	28f0 <fwrite@plt>
    9770:	f94006c1 	ldr	x1, [x22, #8]
    9774:	52800140 	mov	w0, #0xa                   	// #10
    9778:	97ffe3e6 	bl	2710 <fputc@plt>
    977c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9780:	91154002 	add	x2, x0, #0x550
    9784:	f949d841 	ldr	x1, [x2, #5040]
    9788:	f949ec40 	ldr	x0, [x2, #5080]
    978c:	cb010261 	sub	x1, x19, x1
    9790:	eb00403f 	cmp	x1, x0, lsl #16
    9794:	54000382 	b.cs	9804 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9798:	d350fc20 	lsr	x0, x1, #16
    979c:	f949fc43 	ldr	x3, [x2, #5112]
    97a0:	8b000800 	add	x0, x0, x0, lsl #2
    97a4:	d37df000 	lsl	x0, x0, #3
    97a8:	8b000062 	add	x2, x3, x0
    97ac:	f9401056 	ldr	x22, [x2, #32]
    97b0:	b40002b6 	cbz	x22, 9804 <fwp_hof0.constprop.0+0x5e4>
    97b4:	38606860 	ldrb	w0, [x3, x0]
    97b8:	7100081f 	cmp	w0, #0x2
    97bc:	54002c40 	b.eq	9d44 <fwp_hof0.constprop.0+0xb24>  // b.none
    97c0:	7100041f 	cmp	w0, #0x1
    97c4:	54000201 	b.ne	9804 <fwp_hof0.constprop.0+0x5e4>  // b.any
    97c8:	29430043 	ldp	w3, w0, [x2, #24]
    97cc:	92403c21 	and	x1, x1, #0xffff
    97d0:	9b037c21 	mul	x1, x1, x3
    97d4:	d360fc21 	lsr	x1, x1, #32
    97d8:	eb00003f 	cmp	x1, x0
    97dc:	54000142 	b.cs	9804 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    97e0:	8b0102d6 	add	x22, x22, x1
    97e4:	394002c0 	ldrb	w0, [x22]
    97e8:	340000e0 	cbz	w0, 9804 <fwp_hof0.constprop.0+0x5e4>
    97ec:	7100041f 	cmp	w0, #0x1
    97f0:	54002a00 	b.eq	9d30 <fwp_hof0.constprop.0+0xb10>  // b.none
    97f4:	7103fc1f 	cmp	w0, #0xff
    97f8:	54002b20 	b.eq	9d5c <fwp_hof0.constprop.0+0xb3c>  // b.none
    97fc:	51000400 	sub	w0, w0, #0x1
    9800:	390002c0 	strb	w0, [x22]
    9804:	f9400b5a 	ldr	x26, [x26, #16]
    9808:	b5ffd3ba 	cbnz	x26, 927c <fwp_hof0.constprop.0+0x5c>
    980c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9810:	f947f400 	ldr	x0, [x0, #4072]
    9814:	f85f83a2 	ldur	x2, [x29, #-8]
    9818:	f9400001 	ldr	x1, [x0]
    981c:	eb010042 	subs	x2, x2, x1
    9820:	d2800001 	mov	x1, #0x0                   	// #0
    9824:	54002dc1 	b.ne	9ddc <fwp_hof0.constprop.0+0xbbc>  // b.any
    9828:	910003bf 	mov	sp, x29
    982c:	d2800000 	mov	x0, #0x0                   	// #0
    9830:	a94153f3 	ldp	x19, x20, [sp, #16]
    9834:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9838:	a94363f7 	ldp	x23, x24, [sp, #48]
    983c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9840:	a94573fb 	ldp	x27, x28, [sp, #80]
    9844:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9848:	d65f03c0 	ret
    984c:	b90004df 	str	wzr, [x6, #4]
    9850:	17ffff69 	b	95f4 <fwp_hof0.constprop.0+0x3d4>
    9854:	72003c3f 	tst	w1, #0xffff
    9858:	54ffec61 	b.ne	95e4 <fwp_hof0.constprop.0+0x3c4>  // b.any
    985c:	17ffff5f 	b	95d8 <fwp_hof0.constprop.0+0x3b8>
    9860:	aa1b03fc 	mov	x28, x27
    9864:	aa1803fb 	mov	x27, x24
    9868:	29771fb7 	ldp	w23, w7, [x29, #-72]
    986c:	b85c03b8 	ldur	w24, [x29, #-64]
    9870:	aa1c03e0 	mov	x0, x28
    9874:	b81d83a7 	stur	w7, [x29, #-40]
    9878:	97ffef12 	bl	54c0 <fwp_rc_share>
    987c:	b85d83a7 	ldur	w7, [x29, #-40]
    9880:	34000134 	cbz	w20, 98a4 <fwp_hof0.constprop.0+0x684>
    9884:	aa1b03f6 	mov	x22, x27
    9888:	8b344f73 	add	x19, x27, w20, uxtw #3
    988c:	2a0703f9 	mov	w25, w7
    9890:	f84086c0 	ldr	x0, [x22], #8
    9894:	97ffef0b 	bl	54c0 <fwp_rc_share>
    9898:	eb16027f 	cmp	x19, x22
    989c:	54ffffa1 	b.ne	9890 <fwp_hof0.constprop.0+0x670>  // b.any
    98a0:	2a1903e7 	mov	w7, w25
    98a4:	aa1b03e2 	mov	x2, x27
    98a8:	2a1403e1 	mov	w1, w20
    98ac:	aa1c03e0 	mov	x0, x28
    98b0:	b81d83a7 	stur	w7, [x29, #-40]
    98b4:	97ffed14 	bl	4d04 <fwp_apply>
    98b8:	aa0003f9 	mov	x25, x0
    98bc:	b85d83a7 	ldur	w7, [x29, #-40]
    98c0:	6b17031f 	cmp	w24, w23
    98c4:	54ffeb82 	b.cs	9634 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    98c8:	f9401ea1 	ldr	x1, [x21, #56]
    98cc:	4b0702f7 	sub	w23, w23, w7
    98d0:	b9400323 	ldr	w3, [x25]
    98d4:	f85d03a0 	ldur	x0, [x29, #-48]
    98d8:	8b031423 	add	x3, x1, x3, lsl #5
    98dc:	b85c83a2 	ldur	w2, [x29, #-56]
    98e0:	8b274c00 	add	x0, x0, w7, uxtw #3
    98e4:	f81d03a0 	stur	x0, [x29, #-48]
    98e8:	f9400c61 	ldr	x1, [x3, #24]
    98ec:	b85cc3a0 	ldur	w0, [x29, #-52]
    98f0:	4b020000 	sub	w0, w0, w2
    98f4:	b81cc3a0 	stur	w0, [x29, #-52]
    98f8:	aa1903e0 	mov	x0, x25
    98fc:	b5ffd761 	cbnz	x1, 93e8 <fwp_hof0.constprop.0+0x1c8>
    9900:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9904:	aa1903e0 	mov	x0, x25
    9908:	97ffeeee 	bl	54c0 <fwp_rc_share>
    990c:	34000117 	cbz	w23, 992c <fwp_hof0.constprop.0+0x70c>
    9910:	f85d03b8 	ldur	x24, [x29, #-48]
    9914:	d2800016 	mov	x22, #0x0                   	// #0
    9918:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    991c:	910006d6 	add	x22, x22, #0x1
    9920:	97ffeee8 	bl	54c0 <fwp_rc_share>
    9924:	6b1602ff 	cmp	w23, w22
    9928:	54ffff88 	b.hi	9918 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    992c:	f85d03a2 	ldur	x2, [x29, #-48]
    9930:	aa1903e0 	mov	x0, x25
    9934:	2a1703e1 	mov	w1, w23
    9938:	97ffecf3 	bl	4d04 <fwp_apply>
    993c:	aa0003f9 	mov	x25, x0
    9940:	f85983a0 	ldur	x0, [x29, #-104]
    9944:	f1000400 	subs	x0, x0, #0x1
    9948:	f81983a0 	stur	x0, [x29, #-104]
    994c:	54ffce21 	b.ne	9310 <fwp_hof0.constprop.0+0xf0>  // b.any
    9950:	17ffff3e 	b	9648 <fwp_hof0.constprop.0+0x428>
    9954:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9958:	9115400a 	add	x10, x0, #0x550
    995c:	2a0103fc 	mov	w28, w1
    9960:	110006c0 	add	w0, w22, #0x1
    9964:	f120001f 	cmp	x0, #0x800
    9968:	aa1703fa 	mov	x26, x23
    996c:	b953a541 	ldr	w1, [x10, #5028]
    9970:	aa1803fb 	mov	x27, x24
    9974:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9978:	d37df000 	lsl	x0, x0, #3
    997c:	b85c03b8 	ldur	w24, [x29, #-64]
    9980:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9984:	54001860 	b.eq	9c90 <fwp_hof0.constprop.0+0xa70>  // b.none
    9988:	91003c01 	add	x1, x0, #0xf
    998c:	8b411141 	add	x1, x10, x1, lsr #4
    9990:	397e8021 	ldrb	w1, [x1, #4000]
    9994:	910f002b 	add	x11, x1, #0x3c0
    9998:	8b010429 	add	x9, x1, x1, lsl #1
    999c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    99a0:	8b090d4c 	add	x12, x10, x9, lsl #3
    99a4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    99a8:	2a0b03e1 	mov	w1, w11
    99ac:	b4001613 	cbz	x19, 9c6c <fwp_hof0.constprop.0+0xa4c>
    99b0:	f940026c 	ldr	x12, [x19]
    99b4:	aa2c03ec 	mvn	x12, x12
    99b8:	f829794c 	str	x12, [x10, x9, lsl #3]
    99bc:	eb01001f 	cmp	x0, x1
    99c0:	540000c2 	b.cs	99d8 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    99c4:	d503201f 	nop
    99c8:	f8206a7f 	str	xzr, [x19, x0]
    99cc:	91002000 	add	x0, x0, #0x8
    99d0:	eb00003f 	cmp	x1, x0
    99d4:	54ffffa8 	b.hi	99c8 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    99d8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    99dc:	91154009 	add	x9, x0, #0x550
    99e0:	f94a1120 	ldr	x0, [x9, #5152]
    99e4:	ab010000 	adds	x0, x0, x1
    99e8:	54001e82 	b.cs	9db8 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    99ec:	f94a1521 	ldr	x1, [x9, #5160]
    99f0:	f90a1120 	str	x0, [x9, #5152]
    99f4:	eb01001f 	cmp	x0, x1
    99f8:	54000049 	b.ls	9a00 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    99fc:	f90a1520 	str	x0, [x9, #5160]
    9a00:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9a04:	91154000 	add	x0, x0, #0x550
    9a08:	1e630161 	ucvtf	d1, w11
    9a0c:	fd4a1c00 	ldr	d0, [x0, #5176]
    9a10:	1e612800 	fadd	d0, d0, d1
    9a14:	fd0a1c00 	str	d0, [x0, #5176]
    9a18:	b94000c0 	ldr	w0, [x6]
    9a1c:	29005a60 	stp	w0, w22, [x19]
    9a20:	3400013c 	cbz	w28, 9a44 <fwp_hof0.constprop.0+0x824>
    9a24:	910020c1 	add	x1, x6, #0x8
    9a28:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9a2c:	91002260 	add	x0, x19, #0x8
    9a30:	b81c03a7 	stur	w7, [x29, #-64]
    9a34:	f81d83a6 	stur	x6, [x29, #-40]
    9a38:	97ffe30a 	bl	2660 <memmove@plt>
    9a3c:	f85d83a6 	ldur	x6, [x29, #-40]
    9a40:	b85c03a7 	ldur	w7, [x29, #-64]
    9a44:	2a1403e9 	mov	w9, w20
    9a48:	d2800001 	mov	x1, #0x0                   	// #0
    9a4c:	34000114 	cbz	w20, 9a6c <fwp_hof0.constprop.0+0x84c>
    9a50:	0b010380 	add	w0, w28, w1
    9a54:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9a58:	8b000e60 	add	x0, x19, x0, lsl #3
    9a5c:	91000421 	add	x1, x1, #0x1
    9a60:	f9000402 	str	x2, [x0, #8]
    9a64:	eb01013f 	cmp	x9, x1
    9a68:	54ffff41 	b.ne	9a50 <fwp_hof0.constprop.0+0x830>  // b.any
    9a6c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9a70:	91154002 	add	x2, x0, #0x550
    9a74:	f949d840 	ldr	x0, [x2, #5040]
    9a78:	f949ec41 	ldr	x1, [x2, #5080]
    9a7c:	cb000320 	sub	x0, x25, x0
    9a80:	eb01401f 	cmp	x0, x1, lsl #16
    9a84:	540002e2 	b.cs	9ae0 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9a88:	d350fc01 	lsr	x1, x0, #16
    9a8c:	f949fc45 	ldr	x5, [x2, #5112]
    9a90:	8b010821 	add	x1, x1, x1, lsl #2
    9a94:	d37df021 	lsl	x1, x1, #3
    9a98:	8b0100a4 	add	x4, x5, x1
    9a9c:	f9401082 	ldr	x2, [x4, #32]
    9aa0:	b4000202 	cbz	x2, 9ae0 <fwp_hof0.constprop.0+0x8c0>
    9aa4:	386168a1 	ldrb	w1, [x5, x1]
    9aa8:	7100083f 	cmp	w1, #0x2
    9aac:	54001020 	b.eq	9cb0 <fwp_hof0.constprop.0+0xa90>  // b.none
    9ab0:	7100043f 	cmp	w1, #0x1
    9ab4:	54000161 	b.ne	9ae0 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9ab8:	29430485 	ldp	w5, w1, [x4, #24]
    9abc:	92403c00 	and	x0, x0, #0xffff
    9ac0:	9b057c00 	mul	x0, x0, x5
    9ac4:	d360fc00 	lsr	x0, x0, #32
    9ac8:	eb01001f 	cmp	x0, x1
    9acc:	540000a2 	b.cs	9ae0 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9ad0:	8b000042 	add	x2, x2, x0
    9ad4:	39400040 	ldrb	w0, [x2]
    9ad8:	7100041f 	cmp	w0, #0x1
    9adc:	54000be0 	b.eq	9c58 <fwp_hof0.constprop.0+0xa38>  // b.none
    9ae0:	f9400f42 	ldr	x2, [x26, #24]
    9ae4:	aa1903e0 	mov	x0, x25
    9ae8:	52800021 	mov	w1, #0x1                   	// #1
    9aec:	b81d83a7 	stur	w7, [x29, #-40]
    9af0:	f9400442 	ldr	x2, [x2, #8]
    9af4:	d63f0040 	blr	x2
    9af8:	b85d83a7 	ldur	w7, [x29, #-40]
    9afc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9b00:	91154002 	add	x2, x0, #0x550
    9b04:	f949d841 	ldr	x1, [x2, #5040]
    9b08:	f949ec40 	ldr	x0, [x2, #5080]
    9b0c:	cb010261 	sub	x1, x19, x1
    9b10:	eb00403f 	cmp	x1, x0, lsl #16
    9b14:	54000322 	b.cs	9b78 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9b18:	d350fc20 	lsr	x0, x1, #16
    9b1c:	f949fc43 	ldr	x3, [x2, #5112]
    9b20:	8b000800 	add	x0, x0, x0, lsl #2
    9b24:	d37df002 	lsl	x2, x0, #3
    9b28:	8b020060 	add	x0, x3, x2
    9b2c:	f9401014 	ldr	x20, [x0, #32]
    9b30:	b4000254 	cbz	x20, 9b78 <fwp_hof0.constprop.0+0x958>
    9b34:	38626862 	ldrb	w2, [x3, x2]
    9b38:	7100085f 	cmp	w2, #0x2
    9b3c:	54000c00 	b.eq	9cbc <fwp_hof0.constprop.0+0xa9c>  // b.none
    9b40:	7100045f 	cmp	w2, #0x1
    9b44:	540001a1 	b.ne	9b78 <fwp_hof0.constprop.0+0x958>  // b.any
    9b48:	29430002 	ldp	w2, w0, [x0, #24]
    9b4c:	92403c21 	and	x1, x1, #0xffff
    9b50:	9b027c21 	mul	x1, x1, x2
    9b54:	d360fc21 	lsr	x1, x1, #32
    9b58:	eb00003f 	cmp	x1, x0
    9b5c:	540000e2 	b.cs	9b78 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9b60:	8b010294 	add	x20, x20, x1
    9b64:	39400280 	ldrb	w0, [x20]
    9b68:	7103fc1f 	cmp	w0, #0xff
    9b6c:	54000b20 	b.eq	9cd0 <fwp_hof0.constprop.0+0xab0>  // b.none
    9b70:	52800020 	mov	w0, #0x1                   	// #1
    9b74:	39000280 	strb	w0, [x20]
    9b78:	aa1903e0 	mov	x0, x25
    9b7c:	b81d83a7 	stur	w7, [x29, #-40]
    9b80:	97fff02c 	bl	5c30 <fwp_closure_drop>
    9b84:	aa1303f9 	mov	x25, x19
    9b88:	b85d83a7 	ldur	w7, [x29, #-40]
    9b8c:	17ffff4d 	b	98c0 <fwp_hof0.constprop.0+0x6a0>
    9b90:	b8626860 	ldr	w0, [x3, x2]
    9b94:	b94004a2 	ldr	w2, [x5, #4]
    9b98:	4b020003 	sub	w3, w0, w2
    9b9c:	7100047f 	cmp	w3, #0x1
    9ba0:	54ffbd01 	b.ne	9340 <fwp_hof0.constprop.0+0x120>  // b.any
    9ba4:	910003f6 	mov	x22, sp
    9ba8:	34000a22 	cbz	w2, 9cec <fwp_hof0.constprop.0+0xacc>
    9bac:	7100001f 	cmp	w0, #0x0
    9bb0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9bb4:	d2800101 	mov	x1, #0x8                   	// #8
    9bb8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9bbc:	91003ee0 	add	x0, x23, #0xf
    9bc0:	92704c01 	and	x1, x0, #0xfffff0000
    9bc4:	927c7c00 	and	x0, x0, #0xffffffff0
    9bc8:	cb2163e1 	sub	x1, sp, x1
    9bcc:	eb2163ff 	cmp	sp, x1
    9bd0:	540000a0 	b.eq	9be4 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9bd4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9bd8:	f90203ff 	str	xzr, [sp, #1024]
    9bdc:	eb2163ff 	cmp	sp, x1
    9be0:	54ffffa1 	b.ne	9bd4 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9be4:	92403c00 	and	x0, x0, #0xffff
    9be8:	cb2063ff 	sub	sp, sp, x0
    9bec:	f90003ff 	str	xzr, [sp]
    9bf0:	f110001f 	cmp	x0, #0x400
    9bf4:	54000043 	b.cc	9bfc <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9bf8:	f90203ff 	str	xzr, [sp, #1024]
    9bfc:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9c00:	910043f8 	add	x24, sp, #0x10
    9c04:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c08:	91004001 	add	x1, x0, #0x10
    9c0c:	aa1c03e2 	mov	x2, x28
    9c10:	91004021 	add	x1, x1, #0x10
    9c14:	aa1703e3 	mov	x3, x23
    9c18:	aa1803e0 	mov	x0, x24
    9c1c:	97ffe2c9 	bl	2740 <__memcpy_chk@plt>
    9c20:	eb1c02ff 	cmp	x23, x28
    9c24:	aa1403e1 	mov	x1, x20
    9c28:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    9c2c:	d2800102 	mov	x2, #0x8                   	// #8
    9c30:	cb1c0063 	sub	x3, x3, x28
    9c34:	8b1c0300 	add	x0, x24, x28
    9c38:	97ffe2c2 	bl	2740 <__memcpy_chk@plt>
    9c3c:	f9400f61 	ldr	x1, [x27, #24]
    9c40:	aa1803e0 	mov	x0, x24
    9c44:	f9400021 	ldr	x1, [x1]
    9c48:	d63f0020 	blr	x1
    9c4c:	aa0003f9 	mov	x25, x0
    9c50:	910002df 	mov	sp, x22
    9c54:	17ffff3b 	b	9940 <fwp_hof0.constprop.0+0x720>
    9c58:	b90004df 	str	wzr, [x6, #4]
    9c5c:	17ffffa8 	b	9afc <fwp_hof0.constprop.0+0x8dc>
    9c60:	72003c3f 	tst	w1, #0xffff
    9c64:	54ffbae1 	b.ne	93c0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9c68:	17fffdd0 	b	93a8 <fwp_hof0.constprop.0+0x188>
    9c6c:	f9400593 	ldr	x19, [x12, #8]
    9c70:	b4000113 	cbz	x19, 9c90 <fwp_hof0.constprop.0+0xa70>
    9c74:	f9400989 	ldr	x9, [x12, #16]
    9c78:	cb130129 	sub	x9, x9, x19
    9c7c:	eb09003f 	cmp	x1, x9
    9c80:	54000088 	b.hi	9c90 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    9c84:	8b010269 	add	x9, x19, x1
    9c88:	f9000589 	str	x9, [x12, #8]
    9c8c:	17ffff4c 	b	99bc <fwp_hof0.constprop.0+0x79c>
    9c90:	52800001 	mov	w1, #0x0                   	// #0
    9c94:	f81c03a6 	stur	x6, [x29, #-64]
    9c98:	b81d83a7 	stur	w7, [x29, #-40]
    9c9c:	97ffebd5 	bl	4bf0 <fwp_heap_alloc>
    9ca0:	f85c03a6 	ldur	x6, [x29, #-64]
    9ca4:	aa0003f3 	mov	x19, x0
    9ca8:	b85d83a7 	ldur	w7, [x29, #-40]
    9cac:	17ffff5b 	b	9a18 <fwp_hof0.constprop.0+0x7f8>
    9cb0:	72003c1f 	tst	w0, #0xffff
    9cb4:	54fff161 	b.ne	9ae0 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9cb8:	17ffff87 	b	9ad4 <fwp_hof0.constprop.0+0x8b4>
    9cbc:	72003c3f 	tst	w1, #0xffff
    9cc0:	54fff5c1 	b.ne	9b78 <fwp_hof0.constprop.0+0x958>  // b.any
    9cc4:	39400280 	ldrb	w0, [x20]
    9cc8:	7103fc1f 	cmp	w0, #0xff
    9ccc:	54fff521 	b.ne	9b70 <fwp_hof0.constprop.0+0x950>  // b.any
    9cd0:	aa1403e0 	mov	x0, x20
    9cd4:	b81d83a7 	stur	w7, [x29, #-40]
    9cd8:	97ffea06 	bl	44f0 <fwp_rc_forget_slot>
    9cdc:	b85d83a7 	ldur	w7, [x29, #-40]
    9ce0:	17ffffa4 	b	9b70 <fwp_hof0.constprop.0+0x950>
    9ce4:	97ffe9bc 	bl	43d4 <fwp_rc_wide_dup>
    9ce8:	17fffdb6 	b	93c0 <fwp_hof0.constprop.0+0x1a0>
    9cec:	f9400021 	ldr	x1, [x1]
    9cf0:	aa1403e0 	mov	x0, x20
    9cf4:	d63f0020 	blr	x1
    9cf8:	aa0003f9 	mov	x25, x0
    9cfc:	910002df 	mov	sp, x22
    9d00:	17ffff10 	b	9940 <fwp_hof0.constprop.0+0x720>
    9d04:	72003c3f 	tst	w1, #0xffff
    9d08:	54ffafa1 	b.ne	92fc <fwp_hof0.constprop.0+0xdc>  // b.any
    9d0c:	17fffd76 	b	92e4 <fwp_hof0.constprop.0+0xc4>
    9d10:	aa1a03e0 	mov	x0, x26
    9d14:	97ffedeb 	bl	54c0 <fwp_rc_share>
    9d18:	aa1903e0 	mov	x0, x25
    9d1c:	52800037 	mov	w23, #0x1                   	// #1
    9d20:	97ffede8 	bl	54c0 <fwp_rc_share>
    9d24:	aa1a03f9 	mov	x25, x26
    9d28:	f81d03b4 	stur	x20, [x29, #-48]
    9d2c:	17ffff00 	b	992c <fwp_hof0.constprop.0+0x70c>
    9d30:	aa1303e0 	mov	x0, x19
    9d34:	97ffee38 	bl	5614 <fwp_rc_free_arr>
    9d38:	f9400b5a 	ldr	x26, [x26, #16]
    9d3c:	b5ffaa1a 	cbnz	x26, 927c <fwp_hof0.constprop.0+0x5c>
    9d40:	17fffeb3 	b	980c <fwp_hof0.constprop.0+0x5ec>
    9d44:	72003c3f 	tst	w1, #0xffff
    9d48:	54ffd5e1 	b.ne	9804 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9d4c:	17fffea6 	b	97e4 <fwp_hof0.constprop.0+0x5c4>
    9d50:	72003c3f 	tst	w1, #0xffff
    9d54:	54ffcfa1 	b.ne	9748 <fwp_hof0.constprop.0+0x528>  // b.any
    9d58:	17fffe77 	b	9734 <fwp_hof0.constprop.0+0x514>
    9d5c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9d60:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9d64:	91154021 	add	x1, x1, #0x550
    9d68:	ca402400 	eor	x0, x0, x0, lsr #9
    9d6c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d70:	f94a2400 	ldr	x0, [x0, #5192]
    9d74:	b5000080 	cbnz	x0, 9d84 <fwp_hof0.constprop.0+0xb64>
    9d78:	14000011 	b	9dbc <fwp_hof0.constprop.0+0xb9c>
    9d7c:	f9400800 	ldr	x0, [x0, #16]
    9d80:	b40001e0 	cbz	x0, 9dbc <fwp_hof0.constprop.0+0xb9c>
    9d84:	f9400001 	ldr	x1, [x0]
    9d88:	eb0102df 	cmp	x22, x1
    9d8c:	54ffff81 	b.ne	9d7c <fwp_hof0.constprop.0+0xb5c>  // b.any
    9d90:	f9400401 	ldr	x1, [x0, #8]
    9d94:	d1000421 	sub	x1, x1, #0x1
    9d98:	f9000401 	str	x1, [x0, #8]
    9d9c:	f103f83f 	cmp	x1, #0xfe
    9da0:	54ffd321 	b.ne	9804 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9da4:	aa1603e0 	mov	x0, x22
    9da8:	97ffe9d2 	bl	44f0 <fwp_rc_forget_slot>
    9dac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9db0:	390002c0 	strb	w0, [x22]
    9db4:	17fffe94 	b	9804 <fwp_hof0.constprop.0+0x5e4>
    9db8:	97ffe47e 	bl	2fb0 <fwp_heap_oom>
    9dbc:	90000020 	adrp	x0, d000 <__modti3+0x310>
    9dc0:	910ce000 	add	x0, x0, #0x338
    9dc4:	97ffe5cf 	bl	3500 <fwp_trap>
    9dc8:	90000020 	adrp	x0, d000 <__modti3+0x310>
    9dcc:	9118c000 	add	x0, x0, #0x630
    9dd0:	97ffe5cc 	bl	3500 <fwp_trap>
    9dd4:	97ffe980 	bl	43d4 <fwp_rc_wide_dup>
    9dd8:	17fffd49 	b	92fc <fwp_hof0.constprop.0+0xdc>
    9ddc:	97ffe285 	bl	27f0 <__stack_chk_fail@plt>
    9de0:	aa1903e0 	mov	x0, x25
    9de4:	97ffe9c3 	bl	44f0 <fwp_rc_forget_slot>
    9de8:	17fffe56 	b	9740 <fwp_hof0.constprop.0+0x520>
    9dec:	d503201f 	nop

0000000000009df0 <f0>:
    9df0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9df4:	910003fd 	mov	x29, sp
    9df8:	a90153f3 	stp	x19, x20, [sp, #16]
    9dfc:	a9025bf5 	stp	x21, x22, [sp, #32]
    9e00:	a90363f7 	stp	x23, x24, [sp, #48]
    9e04:	a9046bf9 	stp	x25, x26, [sp, #64]
    9e08:	a90573fb 	stp	x27, x28, [sp, #80]
    9e0c:	d12183ff 	sub	sp, sp, #0x860
    9e10:	f90203ff 	str	xzr, [sp, #1024]
    9e14:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e18:	91010005 	add	x5, x0, #0x40
    9e1c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9e20:	f947f400 	ldr	x0, [x0, #4072]
    9e24:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    9e28:	f94160a6 	ldr	x6, [x5, #704]
    9e2c:	f9400001 	ldr	x1, [x0]
    9e30:	f9042fe1 	str	x1, [sp, #2136]
    9e34:	d2800001 	mov	x1, #0x0                   	// #0
    9e38:	91154298 	add	x24, x20, #0x550
    9e3c:	912123f6 	add	x22, sp, #0x848
    9e40:	910023e0 	add	x0, sp, #0x8
    9e44:	910083e2 	add	x2, sp, #0x20
    9e48:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push.constprop.0+0xdc>
    9e4c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9e50:	9125c021 	add	x1, x1, #0x970
    9e54:	913b4084 	add	x4, x4, #0xed0
    9e58:	d2800013 	mov	x19, #0x0                   	// #0
    9e5c:	d2800119 	mov	x25, #0x8                   	// #8
    9e60:	d2800015 	mov	x21, #0x0                   	// #0
    9e64:	52800037 	mov	w23, #0x1                   	// #1
    9e68:	a90093e6 	stp	x6, x4, [sp, #8]
    9e6c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9e70:	a90307ff 	stp	xzr, x1, [sp, #48]
    9e74:	f90160a0 	str	x0, [x5, #704]
    9e78:	f100073a 	subs	x26, x25, #0x1
    9e7c:	aa1603e1 	mov	x1, x22
    9e80:	da1f02bc 	sbc	x28, x21, xzr
    9e84:	52800020 	mov	w0, #0x1                   	// #1
    9e88:	f90017fa 	str	x26, [sp, #40]
    9e8c:	aa1a03f9 	mov	x25, x26
    9e90:	f90427fa 	str	x26, [sp, #2120]
    9e94:	aa1c03f5 	mov	x21, x28
    9e98:	f9042bf3 	str	x19, [sp, #2128]
    9e9c:	97ffed41 	bl	53a0 <fwp_data.part.0.constprop.0>
    9ea0:	f949db02 	ldr	x2, [x24, #5040]
    9ea4:	aa0003f3 	mov	x19, x0
    9ea8:	f949ef00 	ldr	x0, [x24, #5080]
    9eac:	cb020262 	sub	x2, x19, x2
    9eb0:	eb00405f 	cmp	x2, x0, lsl #16
    9eb4:	54000302 	b.cs	9f14 <f0+0x124>  // b.hs, b.nlast
    9eb8:	d350fc40 	lsr	x0, x2, #16
    9ebc:	f949ff04 	ldr	x4, [x24, #5112]
    9ec0:	8b000800 	add	x0, x0, x0, lsl #2
    9ec4:	d37df001 	lsl	x1, x0, #3
    9ec8:	8b010080 	add	x0, x4, x1
    9ecc:	f940101b 	ldr	x27, [x0, #32]
    9ed0:	b400023b 	cbz	x27, 9f14 <f0+0x124>
    9ed4:	38616881 	ldrb	w1, [x4, x1]
    9ed8:	7100083f 	cmp	w1, #0x2
    9edc:	54010ca0 	b.eq	c070 <f0+0x2280>  // b.none
    9ee0:	7100043f 	cmp	w1, #0x1
    9ee4:	54000181 	b.ne	9f14 <f0+0x124>  // b.any
    9ee8:	29430001 	ldp	w1, w0, [x0, #24]
    9eec:	92403c42 	and	x2, x2, #0xffff
    9ef0:	9b017c42 	mul	x2, x2, x1
    9ef4:	d360fc42 	lsr	x2, x2, #32
    9ef8:	eb00005f 	cmp	x2, x0
    9efc:	540000c2 	b.cs	9f14 <f0+0x124>  // b.hs, b.nlast
    9f00:	8b02037b 	add	x27, x27, x2
    9f04:	39400360 	ldrb	w0, [x27]
    9f08:	7103fc1f 	cmp	w0, #0xff
    9f0c:	54010ac0 	b.eq	c064 <f0+0x2274>  // b.none
    9f10:	39000377 	strb	w23, [x27]
    9f14:	f90013f3 	str	x19, [sp, #32]
    9f18:	aa1c035a 	orr	x26, x26, x28
    9f1c:	b5fffafa 	cbnz	x26, 9e78 <f0+0x88>
    9f20:	90000020 	adrp	x0, d000 <__modti3+0x310>
    9f24:	910103e1 	add	x1, sp, #0x40
    9f28:	f94007e2 	ldr	x2, [sp, #8]
    9f2c:	3dc35400 	ldr	q0, [x0, #3408]
    9f30:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f34:	91010018 	add	x24, x0, #0x40
    9f38:	52800020 	mov	w0, #0x1                   	// #1
    9f3c:	3d8013e0 	str	q0, [sp, #64]
    9f40:	f9016302 	str	x2, [x24, #704]
    9f44:	97ffed17 	bl	53a0 <fwp_data.part.0.constprop.0>
    9f48:	91154283 	add	x3, x20, #0x550
    9f4c:	aa0003f5 	mov	x21, x0
    9f50:	f949d861 	ldr	x1, [x3, #5040]
    9f54:	f949ec60 	ldr	x0, [x3, #5080]
    9f58:	cb0102a1 	sub	x1, x21, x1
    9f5c:	eb00403f 	cmp	x1, x0, lsl #16
    9f60:	54000322 	b.cs	9fc4 <f0+0x1d4>  // b.hs, b.nlast
    9f64:	d350fc22 	lsr	x2, x1, #16
    9f68:	f949fc63 	ldr	x3, [x3, #5112]
    9f6c:	8b020842 	add	x2, x2, x2, lsl #2
    9f70:	d37df042 	lsl	x2, x2, #3
    9f74:	8b020060 	add	x0, x3, x2
    9f78:	f9401017 	ldr	x23, [x0, #32]
    9f7c:	b4000257 	cbz	x23, 9fc4 <f0+0x1d4>
    9f80:	38626862 	ldrb	w2, [x3, x2]
    9f84:	7100085f 	cmp	w2, #0x2
    9f88:	54010b60 	b.eq	c0f4 <f0+0x2304>  // b.none
    9f8c:	7100045f 	cmp	w2, #0x1
    9f90:	540001a1 	b.ne	9fc4 <f0+0x1d4>  // b.any
    9f94:	29430002 	ldp	w2, w0, [x0, #24]
    9f98:	92403c21 	and	x1, x1, #0xffff
    9f9c:	9b027c21 	mul	x1, x1, x2
    9fa0:	d360fc21 	lsr	x1, x1, #32
    9fa4:	eb00003f 	cmp	x1, x0
    9fa8:	540000e2 	b.cs	9fc4 <f0+0x1d4>  // b.hs, b.nlast
    9fac:	8b0102f7 	add	x23, x23, x1
    9fb0:	394002e0 	ldrb	w0, [x23]
    9fb4:	7103fc1f 	cmp	w0, #0xff
    9fb8:	54011520 	b.eq	c25c <f0+0x246c>  // b.none
    9fbc:	52800020 	mov	w0, #0x1                   	// #1
    9fc0:	390002e0 	strb	w0, [x23]
    9fc4:	910163e1 	add	x1, sp, #0x58
    9fc8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    9fcc:	52800020 	mov	w0, #0x1                   	// #1
    9fd0:	a905d7f7 	stp	x23, x21, [sp, #88]
    9fd4:	97ffecf3 	bl	53a0 <fwp_data.part.0.constprop.0>
    9fd8:	97ffed5f 	bl	5554 <fwp_rc_fresh>
    9fdc:	aa0003e2 	mov	x2, x0
    9fe0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9fe4:	9101a3e1 	add	x1, sp, #0x68
    9fe8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9fec:	52800020 	mov	w0, #0x1                   	// #1
    9ff0:	a9068be3 	stp	x3, x2, [sp, #104]
    9ff4:	97ffeceb 	bl	53a0 <fwp_data.part.0.constprop.0>
    9ff8:	97ffed57 	bl	5554 <fwp_rc_fresh>
    9ffc:	aa0003e2 	mov	x2, x0
    a000:	9101e3e1 	add	x1, sp, #0x78
    a004:	52800020 	mov	w0, #0x1                   	// #1
    a008:	a9078bf7 	stp	x23, x2, [sp, #120]
    a00c:	97ffece5 	bl	53a0 <fwp_data.part.0.constprop.0>
    a010:	91154283 	add	x3, x20, #0x550
    a014:	aa0003f5 	mov	x21, x0
    a018:	f949d861 	ldr	x1, [x3, #5040]
    a01c:	f949ec60 	ldr	x0, [x3, #5080]
    a020:	cb0102a1 	sub	x1, x21, x1
    a024:	eb00403f 	cmp	x1, x0, lsl #16
    a028:	54000322 	b.cs	a08c <f0+0x29c>  // b.hs, b.nlast
    a02c:	d350fc22 	lsr	x2, x1, #16
    a030:	f949fc63 	ldr	x3, [x3, #5112]
    a034:	8b020842 	add	x2, x2, x2, lsl #2
    a038:	d37df042 	lsl	x2, x2, #3
    a03c:	8b020060 	add	x0, x3, x2
    a040:	f9401017 	ldr	x23, [x0, #32]
    a044:	b4000257 	cbz	x23, a08c <f0+0x29c>
    a048:	38626862 	ldrb	w2, [x3, x2]
    a04c:	7100085f 	cmp	w2, #0x2
    a050:	540104c0 	b.eq	c0e8 <f0+0x22f8>  // b.none
    a054:	7100045f 	cmp	w2, #0x1
    a058:	540001a1 	b.ne	a08c <f0+0x29c>  // b.any
    a05c:	29430002 	ldp	w2, w0, [x0, #24]
    a060:	92403c21 	and	x1, x1, #0xffff
    a064:	9b027c21 	mul	x1, x1, x2
    a068:	d360fc21 	lsr	x1, x1, #32
    a06c:	eb00003f 	cmp	x1, x0
    a070:	540000e2 	b.cs	a08c <f0+0x29c>  // b.hs, b.nlast
    a074:	8b0102f7 	add	x23, x23, x1
    a078:	394002e0 	ldrb	w0, [x23]
    a07c:	7103fc1f 	cmp	w0, #0xff
    a080:	54010f40 	b.eq	c268 <f0+0x2478>  // b.none
    a084:	52800020 	mov	w0, #0x1                   	// #1
    a088:	390002e0 	strb	w0, [x23]
    a08c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a090:	910223e1 	add	x1, sp, #0x88
    a094:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a098:	52800020 	mov	w0, #0x1                   	// #1
    a09c:	a908d7e2 	stp	x2, x21, [sp, #136]
    a0a0:	97ffecc0 	bl	53a0 <fwp_data.part.0.constprop.0>
    a0a4:	91154283 	add	x3, x20, #0x550
    a0a8:	aa0003f5 	mov	x21, x0
    a0ac:	f949d861 	ldr	x1, [x3, #5040]
    a0b0:	f949ec60 	ldr	x0, [x3, #5080]
    a0b4:	cb0102a1 	sub	x1, x21, x1
    a0b8:	eb00403f 	cmp	x1, x0, lsl #16
    a0bc:	54000322 	b.cs	a120 <f0+0x330>  // b.hs, b.nlast
    a0c0:	d350fc22 	lsr	x2, x1, #16
    a0c4:	f949fc63 	ldr	x3, [x3, #5112]
    a0c8:	8b020842 	add	x2, x2, x2, lsl #2
    a0cc:	d37df042 	lsl	x2, x2, #3
    a0d0:	8b020060 	add	x0, x3, x2
    a0d4:	f9401017 	ldr	x23, [x0, #32]
    a0d8:	b4000257 	cbz	x23, a120 <f0+0x330>
    a0dc:	38626862 	ldrb	w2, [x3, x2]
    a0e0:	7100085f 	cmp	w2, #0x2
    a0e4:	5400ffc0 	b.eq	c0dc <f0+0x22ec>  // b.none
    a0e8:	7100045f 	cmp	w2, #0x1
    a0ec:	540001a1 	b.ne	a120 <f0+0x330>  // b.any
    a0f0:	29430002 	ldp	w2, w0, [x0, #24]
    a0f4:	92403c21 	and	x1, x1, #0xffff
    a0f8:	9b027c21 	mul	x1, x1, x2
    a0fc:	d360fc21 	lsr	x1, x1, #32
    a100:	eb00003f 	cmp	x1, x0
    a104:	540000e2 	b.cs	a120 <f0+0x330>  // b.hs, b.nlast
    a108:	8b0102f7 	add	x23, x23, x1
    a10c:	394002e0 	ldrb	w0, [x23]
    a110:	7103fc1f 	cmp	w0, #0xff
    a114:	54010b00 	b.eq	c274 <f0+0x2484>  // b.none
    a118:	52800020 	mov	w0, #0x1                   	// #1
    a11c:	390002e0 	strb	w0, [x23]
    a120:	910263e1 	add	x1, sp, #0x98
    a124:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a128:	52800020 	mov	w0, #0x1                   	// #1
    a12c:	a909d7e2 	stp	x2, x21, [sp, #152]
    a130:	97ffec9c 	bl	53a0 <fwp_data.part.0.constprop.0>
    a134:	97ffed08 	bl	5554 <fwp_rc_fresh>
    a138:	aa0003e2 	mov	x2, x0
    a13c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a140:	9102a3e1 	add	x1, sp, #0xa8
    a144:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a148:	52800020 	mov	w0, #0x1                   	// #1
    a14c:	a90a8be3 	stp	x3, x2, [sp, #168]
    a150:	97ffec94 	bl	53a0 <fwp_data.part.0.constprop.0>
    a154:	91154283 	add	x3, x20, #0x550
    a158:	aa0003f5 	mov	x21, x0
    a15c:	f949d861 	ldr	x1, [x3, #5040]
    a160:	f949ec60 	ldr	x0, [x3, #5080]
    a164:	cb0102a1 	sub	x1, x21, x1
    a168:	eb00403f 	cmp	x1, x0, lsl #16
    a16c:	54000322 	b.cs	a1d0 <f0+0x3e0>  // b.hs, b.nlast
    a170:	d350fc22 	lsr	x2, x1, #16
    a174:	f949fc63 	ldr	x3, [x3, #5112]
    a178:	8b020842 	add	x2, x2, x2, lsl #2
    a17c:	d37df042 	lsl	x2, x2, #3
    a180:	8b020060 	add	x0, x3, x2
    a184:	f9401017 	ldr	x23, [x0, #32]
    a188:	b4000257 	cbz	x23, a1d0 <f0+0x3e0>
    a18c:	38626862 	ldrb	w2, [x3, x2]
    a190:	7100085f 	cmp	w2, #0x2
    a194:	5400fc80 	b.eq	c124 <f0+0x2334>  // b.none
    a198:	7100045f 	cmp	w2, #0x1
    a19c:	540001a1 	b.ne	a1d0 <f0+0x3e0>  // b.any
    a1a0:	29430002 	ldp	w2, w0, [x0, #24]
    a1a4:	92403c21 	and	x1, x1, #0xffff
    a1a8:	9b027c21 	mul	x1, x1, x2
    a1ac:	d360fc21 	lsr	x1, x1, #32
    a1b0:	eb00003f 	cmp	x1, x0
    a1b4:	540000e2 	b.cs	a1d0 <f0+0x3e0>  // b.hs, b.nlast
    a1b8:	8b0102f7 	add	x23, x23, x1
    a1bc:	394002e0 	ldrb	w0, [x23]
    a1c0:	7103fc1f 	cmp	w0, #0xff
    a1c4:	540105e0 	b.eq	c280 <f0+0x2490>  // b.none
    a1c8:	52800020 	mov	w0, #0x1                   	// #1
    a1cc:	390002e0 	strb	w0, [x23]
    a1d0:	9102e3e1 	add	x1, sp, #0xb8
    a1d4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a1d8:	52800020 	mov	w0, #0x1                   	// #1
    a1dc:	a90bd7f7 	stp	x23, x21, [sp, #184]
    a1e0:	97ffec70 	bl	53a0 <fwp_data.part.0.constprop.0>
    a1e4:	97ffecdc 	bl	5554 <fwp_rc_fresh>
    a1e8:	aa0003e2 	mov	x2, x0
    a1ec:	910323e1 	add	x1, sp, #0xc8
    a1f0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a1f4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a1f8:	52800020 	mov	w0, #0x1                   	// #1
    a1fc:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a200:	97ffec68 	bl	53a0 <fwp_data.part.0.constprop.0>
    a204:	97ffecd4 	bl	5554 <fwp_rc_fresh>
    a208:	aa0003e2 	mov	x2, x0
    a20c:	910363e1 	add	x1, sp, #0xd8
    a210:	52800020 	mov	w0, #0x1                   	// #1
    a214:	a90d8bf7 	stp	x23, x2, [sp, #216]
    a218:	97ffec62 	bl	53a0 <fwp_data.part.0.constprop.0>
    a21c:	97ffecce 	bl	5554 <fwp_rc_fresh>
    a220:	aa0003e2 	mov	x2, x0
    a224:	9103a3e1 	add	x1, sp, #0xe8
    a228:	52800020 	mov	w0, #0x1                   	// #1
    a22c:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a230:	97ffec5c 	bl	53a0 <fwp_data.part.0.constprop.0>
    a234:	97ffecc8 	bl	5554 <fwp_rc_fresh>
    a238:	aa0003e2 	mov	x2, x0
    a23c:	9103e3e1 	add	x1, sp, #0xf8
    a240:	52800020 	mov	w0, #0x1                   	// #1
    a244:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a248:	97ffec56 	bl	53a0 <fwp_data.part.0.constprop.0>
    a24c:	97ffecc2 	bl	5554 <fwp_rc_fresh>
    a250:	aa0003e2 	mov	x2, x0
    a254:	910423e1 	add	x1, sp, #0x108
    a258:	52800020 	mov	w0, #0x1                   	// #1
    a25c:	a9108bf5 	stp	x21, x2, [sp, #264]
    a260:	97ffec50 	bl	53a0 <fwp_data.part.0.constprop.0>
    a264:	97ffecbc 	bl	5554 <fwp_rc_fresh>
    a268:	aa0003e2 	mov	x2, x0
    a26c:	910463e1 	add	x1, sp, #0x118
    a270:	52800020 	mov	w0, #0x1                   	// #1
    a274:	a9118bf7 	stp	x23, x2, [sp, #280]
    a278:	97ffec4a 	bl	53a0 <fwp_data.part.0.constprop.0>
    a27c:	97ffecb6 	bl	5554 <fwp_rc_fresh>
    a280:	aa0003e2 	mov	x2, x0
    a284:	9104a3e1 	add	x1, sp, #0x128
    a288:	52800020 	mov	w0, #0x1                   	// #1
    a28c:	a9128bf5 	stp	x21, x2, [sp, #296]
    a290:	97ffec44 	bl	53a0 <fwp_data.part.0.constprop.0>
    a294:	97ffecb0 	bl	5554 <fwp_rc_fresh>
    a298:	aa0003e2 	mov	x2, x0
    a29c:	9104e3e1 	add	x1, sp, #0x138
    a2a0:	52800020 	mov	w0, #0x1                   	// #1
    a2a4:	a9138bf7 	stp	x23, x2, [sp, #312]
    a2a8:	97ffec3e 	bl	53a0 <fwp_data.part.0.constprop.0>
    a2ac:	97ffecaa 	bl	5554 <fwp_rc_fresh>
    a2b0:	aa0003e2 	mov	x2, x0
    a2b4:	910523e1 	add	x1, sp, #0x148
    a2b8:	52800020 	mov	w0, #0x1                   	// #1
    a2bc:	a9148bf5 	stp	x21, x2, [sp, #328]
    a2c0:	97ffec38 	bl	53a0 <fwp_data.part.0.constprop.0>
    a2c4:	91154283 	add	x3, x20, #0x550
    a2c8:	aa0003f5 	mov	x21, x0
    a2cc:	f949d861 	ldr	x1, [x3, #5040]
    a2d0:	f949ec60 	ldr	x0, [x3, #5080]
    a2d4:	cb0102a1 	sub	x1, x21, x1
    a2d8:	eb00403f 	cmp	x1, x0, lsl #16
    a2dc:	54000322 	b.cs	a340 <f0+0x550>  // b.hs, b.nlast
    a2e0:	d350fc22 	lsr	x2, x1, #16
    a2e4:	f949fc63 	ldr	x3, [x3, #5112]
    a2e8:	8b020842 	add	x2, x2, x2, lsl #2
    a2ec:	d37df042 	lsl	x2, x2, #3
    a2f0:	8b020060 	add	x0, x3, x2
    a2f4:	f9401017 	ldr	x23, [x0, #32]
    a2f8:	b4000257 	cbz	x23, a340 <f0+0x550>
    a2fc:	38626862 	ldrb	w2, [x3, x2]
    a300:	7100085f 	cmp	w2, #0x2
    a304:	5400f0a0 	b.eq	c118 <f0+0x2328>  // b.none
    a308:	7100045f 	cmp	w2, #0x1
    a30c:	540001a1 	b.ne	a340 <f0+0x550>  // b.any
    a310:	29430002 	ldp	w2, w0, [x0, #24]
    a314:	92403c21 	and	x1, x1, #0xffff
    a318:	9b027c21 	mul	x1, x1, x2
    a31c:	d360fc21 	lsr	x1, x1, #32
    a320:	eb00003f 	cmp	x1, x0
    a324:	540000e2 	b.cs	a340 <f0+0x550>  // b.hs, b.nlast
    a328:	8b0102f7 	add	x23, x23, x1
    a32c:	394002e0 	ldrb	w0, [x23]
    a330:	7103fc1f 	cmp	w0, #0xff
    a334:	5400fac0 	b.eq	c28c <f0+0x249c>  // b.none
    a338:	52800020 	mov	w0, #0x1                   	// #1
    a33c:	390002e0 	strb	w0, [x23]
    a340:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a344:	910563e1 	add	x1, sp, #0x158
    a348:	52800020 	mov	w0, #0x1                   	// #1
    a34c:	a915d7e2 	stp	x2, x21, [sp, #344]
    a350:	97ffec14 	bl	53a0 <fwp_data.part.0.constprop.0>
    a354:	91154283 	add	x3, x20, #0x550
    a358:	aa0003f5 	mov	x21, x0
    a35c:	f949d861 	ldr	x1, [x3, #5040]
    a360:	f949ec60 	ldr	x0, [x3, #5080]
    a364:	cb0102a1 	sub	x1, x21, x1
    a368:	eb00403f 	cmp	x1, x0, lsl #16
    a36c:	54000322 	b.cs	a3d0 <f0+0x5e0>  // b.hs, b.nlast
    a370:	d350fc22 	lsr	x2, x1, #16
    a374:	f949fc63 	ldr	x3, [x3, #5112]
    a378:	8b020842 	add	x2, x2, x2, lsl #2
    a37c:	d37df042 	lsl	x2, x2, #3
    a380:	8b020060 	add	x0, x3, x2
    a384:	f9401017 	ldr	x23, [x0, #32]
    a388:	b4000257 	cbz	x23, a3d0 <f0+0x5e0>
    a38c:	38626862 	ldrb	w2, [x3, x2]
    a390:	7100085f 	cmp	w2, #0x2
    a394:	5400ebc0 	b.eq	c10c <f0+0x231c>  // b.none
    a398:	7100045f 	cmp	w2, #0x1
    a39c:	540001a1 	b.ne	a3d0 <f0+0x5e0>  // b.any
    a3a0:	29430002 	ldp	w2, w0, [x0, #24]
    a3a4:	92403c21 	and	x1, x1, #0xffff
    a3a8:	9b027c21 	mul	x1, x1, x2
    a3ac:	d360fc21 	lsr	x1, x1, #32
    a3b0:	eb00003f 	cmp	x1, x0
    a3b4:	540000e2 	b.cs	a3d0 <f0+0x5e0>  // b.hs, b.nlast
    a3b8:	8b0102f7 	add	x23, x23, x1
    a3bc:	394002e0 	ldrb	w0, [x23]
    a3c0:	7103fc1f 	cmp	w0, #0xff
    a3c4:	5400f6a0 	b.eq	c298 <f0+0x24a8>  // b.none
    a3c8:	52800020 	mov	w0, #0x1                   	// #1
    a3cc:	390002e0 	strb	w0, [x23]
    a3d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a3d4:	9105a3e1 	add	x1, sp, #0x168
    a3d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a3dc:	52800020 	mov	w0, #0x1                   	// #1
    a3e0:	a916d7e2 	stp	x2, x21, [sp, #360]
    a3e4:	97ffebef 	bl	53a0 <fwp_data.part.0.constprop.0>
    a3e8:	97ffec5b 	bl	5554 <fwp_rc_fresh>
    a3ec:	aa0003e2 	mov	x2, x0
    a3f0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a3f4:	9105e3e1 	add	x1, sp, #0x178
    a3f8:	52800020 	mov	w0, #0x1                   	// #1
    a3fc:	a9178be3 	stp	x3, x2, [sp, #376]
    a400:	97ffebe8 	bl	53a0 <fwp_data.part.0.constprop.0>
    a404:	91154283 	add	x3, x20, #0x550
    a408:	aa0003f5 	mov	x21, x0
    a40c:	f949d861 	ldr	x1, [x3, #5040]
    a410:	f949ec60 	ldr	x0, [x3, #5080]
    a414:	cb0102a1 	sub	x1, x21, x1
    a418:	eb00403f 	cmp	x1, x0, lsl #16
    a41c:	54000322 	b.cs	a480 <f0+0x690>  // b.hs, b.nlast
    a420:	d350fc22 	lsr	x2, x1, #16
    a424:	f949fc63 	ldr	x3, [x3, #5112]
    a428:	8b020842 	add	x2, x2, x2, lsl #2
    a42c:	d37df042 	lsl	x2, x2, #3
    a430:	8b020060 	add	x0, x3, x2
    a434:	f9401017 	ldr	x23, [x0, #32]
    a438:	b4000257 	cbz	x23, a480 <f0+0x690>
    a43c:	38626862 	ldrb	w2, [x3, x2]
    a440:	7100085f 	cmp	w2, #0x2
    a444:	5400e5e0 	b.eq	c100 <f0+0x2310>  // b.none
    a448:	7100045f 	cmp	w2, #0x1
    a44c:	540001a1 	b.ne	a480 <f0+0x690>  // b.any
    a450:	29430002 	ldp	w2, w0, [x0, #24]
    a454:	92403c21 	and	x1, x1, #0xffff
    a458:	9b027c21 	mul	x1, x1, x2
    a45c:	d360fc21 	lsr	x1, x1, #32
    a460:	eb00003f 	cmp	x1, x0
    a464:	540000e2 	b.cs	a480 <f0+0x690>  // b.hs, b.nlast
    a468:	8b0102f7 	add	x23, x23, x1
    a46c:	394002e0 	ldrb	w0, [x23]
    a470:	7103fc1f 	cmp	w0, #0xff
    a474:	5400f180 	b.eq	c2a4 <f0+0x24b4>  // b.none
    a478:	52800020 	mov	w0, #0x1                   	// #1
    a47c:	390002e0 	strb	w0, [x23]
    a480:	910623e1 	add	x1, sp, #0x188
    a484:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a488:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a48c:	52800020 	mov	w0, #0x1                   	// #1
    a490:	a918d7f7 	stp	x23, x21, [sp, #392]
    a494:	97ffebc3 	bl	53a0 <fwp_data.part.0.constprop.0>
    a498:	97ffec2f 	bl	5554 <fwp_rc_fresh>
    a49c:	aa0003e2 	mov	x2, x0
    a4a0:	910663e1 	add	x1, sp, #0x198
    a4a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a4a8:	52800020 	mov	w0, #0x1                   	// #1
    a4ac:	a9198bf5 	stp	x21, x2, [sp, #408]
    a4b0:	97ffebbc 	bl	53a0 <fwp_data.part.0.constprop.0>
    a4b4:	97ffec28 	bl	5554 <fwp_rc_fresh>
    a4b8:	aa0003e2 	mov	x2, x0
    a4bc:	9106a3e1 	add	x1, sp, #0x1a8
    a4c0:	52800020 	mov	w0, #0x1                   	// #1
    a4c4:	a91a8bf7 	stp	x23, x2, [sp, #424]
    a4c8:	97ffebb6 	bl	53a0 <fwp_data.part.0.constprop.0>
    a4cc:	97ffec22 	bl	5554 <fwp_rc_fresh>
    a4d0:	aa0003e2 	mov	x2, x0
    a4d4:	9106e3e1 	add	x1, sp, #0x1b8
    a4d8:	52800020 	mov	w0, #0x1                   	// #1
    a4dc:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a4e0:	97ffebb0 	bl	53a0 <fwp_data.part.0.constprop.0>
    a4e4:	91154283 	add	x3, x20, #0x550
    a4e8:	aa0003f5 	mov	x21, x0
    a4ec:	f949d861 	ldr	x1, [x3, #5040]
    a4f0:	f949ec60 	ldr	x0, [x3, #5080]
    a4f4:	cb0102a1 	sub	x1, x21, x1
    a4f8:	eb00403f 	cmp	x1, x0, lsl #16
    a4fc:	54000322 	b.cs	a560 <f0+0x770>  // b.hs, b.nlast
    a500:	d350fc22 	lsr	x2, x1, #16
    a504:	f949fc63 	ldr	x3, [x3, #5112]
    a508:	8b020842 	add	x2, x2, x2, lsl #2
    a50c:	d37df042 	lsl	x2, x2, #3
    a510:	8b020060 	add	x0, x3, x2
    a514:	f9401017 	ldr	x23, [x0, #32]
    a518:	b4000257 	cbz	x23, a560 <f0+0x770>
    a51c:	38626862 	ldrb	w2, [x3, x2]
    a520:	7100085f 	cmp	w2, #0x2
    a524:	5400e300 	b.eq	c184 <f0+0x2394>  // b.none
    a528:	7100045f 	cmp	w2, #0x1
    a52c:	540001a1 	b.ne	a560 <f0+0x770>  // b.any
    a530:	29430002 	ldp	w2, w0, [x0, #24]
    a534:	92403c21 	and	x1, x1, #0xffff
    a538:	9b027c21 	mul	x1, x1, x2
    a53c:	d360fc21 	lsr	x1, x1, #32
    a540:	eb00003f 	cmp	x1, x0
    a544:	540000e2 	b.cs	a560 <f0+0x770>  // b.hs, b.nlast
    a548:	8b0102f7 	add	x23, x23, x1
    a54c:	394002e0 	ldrb	w0, [x23]
    a550:	7103fc1f 	cmp	w0, #0xff
    a554:	5400eae0 	b.eq	c2b0 <f0+0x24c0>  // b.none
    a558:	52800020 	mov	w0, #0x1                   	// #1
    a55c:	390002e0 	strb	w0, [x23]
    a560:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a564:	910723e1 	add	x1, sp, #0x1c8
    a568:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a56c:	52800020 	mov	w0, #0x1                   	// #1
    a570:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a574:	97ffeb8b 	bl	53a0 <fwp_data.part.0.constprop.0>
    a578:	91154283 	add	x3, x20, #0x550
    a57c:	aa0003f5 	mov	x21, x0
    a580:	f949d861 	ldr	x1, [x3, #5040]
    a584:	f949ec60 	ldr	x0, [x3, #5080]
    a588:	cb0102a1 	sub	x1, x21, x1
    a58c:	eb00403f 	cmp	x1, x0, lsl #16
    a590:	54000322 	b.cs	a5f4 <f0+0x804>  // b.hs, b.nlast
    a594:	d350fc22 	lsr	x2, x1, #16
    a598:	f949fc63 	ldr	x3, [x3, #5112]
    a59c:	8b020842 	add	x2, x2, x2, lsl #2
    a5a0:	d37df042 	lsl	x2, x2, #3
    a5a4:	8b020060 	add	x0, x3, x2
    a5a8:	f9401017 	ldr	x23, [x0, #32]
    a5ac:	b4000257 	cbz	x23, a5f4 <f0+0x804>
    a5b0:	38626862 	ldrb	w2, [x3, x2]
    a5b4:	7100085f 	cmp	w2, #0x2
    a5b8:	5400de00 	b.eq	c178 <f0+0x2388>  // b.none
    a5bc:	7100045f 	cmp	w2, #0x1
    a5c0:	540001a1 	b.ne	a5f4 <f0+0x804>  // b.any
    a5c4:	29430002 	ldp	w2, w0, [x0, #24]
    a5c8:	92403c21 	and	x1, x1, #0xffff
    a5cc:	9b027c21 	mul	x1, x1, x2
    a5d0:	d360fc21 	lsr	x1, x1, #32
    a5d4:	eb00003f 	cmp	x1, x0
    a5d8:	540000e2 	b.cs	a5f4 <f0+0x804>  // b.hs, b.nlast
    a5dc:	8b0102f7 	add	x23, x23, x1
    a5e0:	394002e0 	ldrb	w0, [x23]
    a5e4:	7103fc1f 	cmp	w0, #0xff
    a5e8:	5400e6a0 	b.eq	c2bc <f0+0x24cc>  // b.none
    a5ec:	52800020 	mov	w0, #0x1                   	// #1
    a5f0:	390002e0 	strb	w0, [x23]
    a5f4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a5f8:	910763e1 	add	x1, sp, #0x1d8
    a5fc:	52800020 	mov	w0, #0x1                   	// #1
    a600:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a604:	97ffeb67 	bl	53a0 <fwp_data.part.0.constprop.0>
    a608:	91154283 	add	x3, x20, #0x550
    a60c:	aa0003f5 	mov	x21, x0
    a610:	f949d861 	ldr	x1, [x3, #5040]
    a614:	f949ec60 	ldr	x0, [x3, #5080]
    a618:	cb0102a1 	sub	x1, x21, x1
    a61c:	eb00403f 	cmp	x1, x0, lsl #16
    a620:	54000322 	b.cs	a684 <f0+0x894>  // b.hs, b.nlast
    a624:	d350fc22 	lsr	x2, x1, #16
    a628:	f949fc63 	ldr	x3, [x3, #5112]
    a62c:	8b020842 	add	x2, x2, x2, lsl #2
    a630:	d37df042 	lsl	x2, x2, #3
    a634:	8b020060 	add	x0, x3, x2
    a638:	f9401017 	ldr	x23, [x0, #32]
    a63c:	b4000257 	cbz	x23, a684 <f0+0x894>
    a640:	38626862 	ldrb	w2, [x3, x2]
    a644:	7100085f 	cmp	w2, #0x2
    a648:	5400d920 	b.eq	c16c <f0+0x237c>  // b.none
    a64c:	7100045f 	cmp	w2, #0x1
    a650:	540001a1 	b.ne	a684 <f0+0x894>  // b.any
    a654:	29430002 	ldp	w2, w0, [x0, #24]
    a658:	92403c21 	and	x1, x1, #0xffff
    a65c:	9b027c21 	mul	x1, x1, x2
    a660:	d360fc21 	lsr	x1, x1, #32
    a664:	eb00003f 	cmp	x1, x0
    a668:	540000e2 	b.cs	a684 <f0+0x894>  // b.hs, b.nlast
    a66c:	8b0102f7 	add	x23, x23, x1
    a670:	394002e0 	ldrb	w0, [x23]
    a674:	7103fc1f 	cmp	w0, #0xff
    a678:	5400e280 	b.eq	c2c8 <f0+0x24d8>  // b.none
    a67c:	52800020 	mov	w0, #0x1                   	// #1
    a680:	390002e0 	strb	w0, [x23]
    a684:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a688:	9107a3e1 	add	x1, sp, #0x1e8
    a68c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a690:	52800020 	mov	w0, #0x1                   	// #1
    a694:	a91ed7e2 	stp	x2, x21, [sp, #488]
    a698:	97ffeb42 	bl	53a0 <fwp_data.part.0.constprop.0>
    a69c:	97ffebae 	bl	5554 <fwp_rc_fresh>
    a6a0:	aa0003e2 	mov	x2, x0
    a6a4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a6a8:	9107e3e1 	add	x1, sp, #0x1f8
    a6ac:	52800020 	mov	w0, #0x1                   	// #1
    a6b0:	a91f8be3 	stp	x3, x2, [sp, #504]
    a6b4:	97ffeb3b 	bl	53a0 <fwp_data.part.0.constprop.0>
    a6b8:	91154283 	add	x3, x20, #0x550
    a6bc:	aa0003f5 	mov	x21, x0
    a6c0:	f949d861 	ldr	x1, [x3, #5040]
    a6c4:	f949ec60 	ldr	x0, [x3, #5080]
    a6c8:	cb0102a1 	sub	x1, x21, x1
    a6cc:	eb00403f 	cmp	x1, x0, lsl #16
    a6d0:	54000322 	b.cs	a734 <f0+0x944>  // b.hs, b.nlast
    a6d4:	d350fc22 	lsr	x2, x1, #16
    a6d8:	f949fc63 	ldr	x3, [x3, #5112]
    a6dc:	8b020842 	add	x2, x2, x2, lsl #2
    a6e0:	d37df042 	lsl	x2, x2, #3
    a6e4:	8b020060 	add	x0, x3, x2
    a6e8:	f9401017 	ldr	x23, [x0, #32]
    a6ec:	b4000257 	cbz	x23, a734 <f0+0x944>
    a6f0:	38626862 	ldrb	w2, [x3, x2]
    a6f4:	7100085f 	cmp	w2, #0x2
    a6f8:	5400d340 	b.eq	c160 <f0+0x2370>  // b.none
    a6fc:	7100045f 	cmp	w2, #0x1
    a700:	540001a1 	b.ne	a734 <f0+0x944>  // b.any
    a704:	29430002 	ldp	w2, w0, [x0, #24]
    a708:	92403c21 	and	x1, x1, #0xffff
    a70c:	9b027c21 	mul	x1, x1, x2
    a710:	d360fc21 	lsr	x1, x1, #32
    a714:	eb00003f 	cmp	x1, x0
    a718:	540000e2 	b.cs	a734 <f0+0x944>  // b.hs, b.nlast
    a71c:	8b0102f7 	add	x23, x23, x1
    a720:	394002e0 	ldrb	w0, [x23]
    a724:	7103fc1f 	cmp	w0, #0xff
    a728:	5400dd60 	b.eq	c2d4 <f0+0x24e4>  // b.none
    a72c:	52800020 	mov	w0, #0x1                   	// #1
    a730:	390002e0 	strb	w0, [x23]
    a734:	910823e1 	add	x1, sp, #0x208
    a738:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a73c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a740:	52800020 	mov	w0, #0x1                   	// #1
    a744:	f90107f7 	str	x23, [sp, #520]
    a748:	f9010bf5 	str	x21, [sp, #528]
    a74c:	97ffeb15 	bl	53a0 <fwp_data.part.0.constprop.0>
    a750:	97ffeb81 	bl	5554 <fwp_rc_fresh>
    a754:	aa0003e2 	mov	x2, x0
    a758:	910863e1 	add	x1, sp, #0x218
    a75c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a760:	52800020 	mov	w0, #0x1                   	// #1
    a764:	f9010ff5 	str	x21, [sp, #536]
    a768:	f90113e2 	str	x2, [sp, #544]
    a76c:	97ffeb0d 	bl	53a0 <fwp_data.part.0.constprop.0>
    a770:	97ffeb79 	bl	5554 <fwp_rc_fresh>
    a774:	aa0003e2 	mov	x2, x0
    a778:	9108a3e1 	add	x1, sp, #0x228
    a77c:	52800020 	mov	w0, #0x1                   	// #1
    a780:	f90117f7 	str	x23, [sp, #552]
    a784:	f9011be2 	str	x2, [sp, #560]
    a788:	97ffeb06 	bl	53a0 <fwp_data.part.0.constprop.0>
    a78c:	97ffeb72 	bl	5554 <fwp_rc_fresh>
    a790:	aa0003e2 	mov	x2, x0
    a794:	9108e3e1 	add	x1, sp, #0x238
    a798:	52800020 	mov	w0, #0x1                   	// #1
    a79c:	f9011ff5 	str	x21, [sp, #568]
    a7a0:	f90123e2 	str	x2, [sp, #576]
    a7a4:	97ffeaff 	bl	53a0 <fwp_data.part.0.constprop.0>
    a7a8:	91154283 	add	x3, x20, #0x550
    a7ac:	aa0003f5 	mov	x21, x0
    a7b0:	f949d861 	ldr	x1, [x3, #5040]
    a7b4:	f949ec60 	ldr	x0, [x3, #5080]
    a7b8:	cb0102a1 	sub	x1, x21, x1
    a7bc:	eb00403f 	cmp	x1, x0, lsl #16
    a7c0:	54000322 	b.cs	a824 <f0+0xa34>  // b.hs, b.nlast
    a7c4:	d350fc22 	lsr	x2, x1, #16
    a7c8:	f949fc63 	ldr	x3, [x3, #5112]
    a7cc:	8b020842 	add	x2, x2, x2, lsl #2
    a7d0:	d37df042 	lsl	x2, x2, #3
    a7d4:	8b020060 	add	x0, x3, x2
    a7d8:	f9401017 	ldr	x23, [x0, #32]
    a7dc:	b4000257 	cbz	x23, a824 <f0+0xa34>
    a7e0:	38626862 	ldrb	w2, [x3, x2]
    a7e4:	7100085f 	cmp	w2, #0x2
    a7e8:	5400cb60 	b.eq	c154 <f0+0x2364>  // b.none
    a7ec:	7100045f 	cmp	w2, #0x1
    a7f0:	540001a1 	b.ne	a824 <f0+0xa34>  // b.any
    a7f4:	29430002 	ldp	w2, w0, [x0, #24]
    a7f8:	92403c21 	and	x1, x1, #0xffff
    a7fc:	9b027c21 	mul	x1, x1, x2
    a800:	d360fc21 	lsr	x1, x1, #32
    a804:	eb00003f 	cmp	x1, x0
    a808:	540000e2 	b.cs	a824 <f0+0xa34>  // b.hs, b.nlast
    a80c:	8b0102f7 	add	x23, x23, x1
    a810:	394002e0 	ldrb	w0, [x23]
    a814:	7103fc1f 	cmp	w0, #0xff
    a818:	5400d640 	b.eq	c2e0 <f0+0x24f0>  // b.none
    a81c:	52800020 	mov	w0, #0x1                   	// #1
    a820:	390002e0 	strb	w0, [x23]
    a824:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a828:	910923e1 	add	x1, sp, #0x248
    a82c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a830:	52800020 	mov	w0, #0x1                   	// #1
    a834:	f90127e2 	str	x2, [sp, #584]
    a838:	f9012bf5 	str	x21, [sp, #592]
    a83c:	97ffead9 	bl	53a0 <fwp_data.part.0.constprop.0>
    a840:	91154283 	add	x3, x20, #0x550
    a844:	aa0003f5 	mov	x21, x0
    a848:	f949d861 	ldr	x1, [x3, #5040]
    a84c:	f949ec60 	ldr	x0, [x3, #5080]
    a850:	cb0102a1 	sub	x1, x21, x1
    a854:	eb00403f 	cmp	x1, x0, lsl #16
    a858:	54000322 	b.cs	a8bc <f0+0xacc>  // b.hs, b.nlast
    a85c:	d350fc22 	lsr	x2, x1, #16
    a860:	f949fc63 	ldr	x3, [x3, #5112]
    a864:	8b020842 	add	x2, x2, x2, lsl #2
    a868:	d37df042 	lsl	x2, x2, #3
    a86c:	8b020060 	add	x0, x3, x2
    a870:	f9401017 	ldr	x23, [x0, #32]
    a874:	b4000257 	cbz	x23, a8bc <f0+0xacc>
    a878:	38626862 	ldrb	w2, [x3, x2]
    a87c:	7100085f 	cmp	w2, #0x2
    a880:	5400c640 	b.eq	c148 <f0+0x2358>  // b.none
    a884:	7100045f 	cmp	w2, #0x1
    a888:	540001a1 	b.ne	a8bc <f0+0xacc>  // b.any
    a88c:	29430002 	ldp	w2, w0, [x0, #24]
    a890:	92403c21 	and	x1, x1, #0xffff
    a894:	9b027c21 	mul	x1, x1, x2
    a898:	d360fc21 	lsr	x1, x1, #32
    a89c:	eb00003f 	cmp	x1, x0
    a8a0:	540000e2 	b.cs	a8bc <f0+0xacc>  // b.hs, b.nlast
    a8a4:	8b0102f7 	add	x23, x23, x1
    a8a8:	394002e0 	ldrb	w0, [x23]
    a8ac:	7103fc1f 	cmp	w0, #0xff
    a8b0:	5400d1e0 	b.eq	c2ec <f0+0x24fc>  // b.none
    a8b4:	52800020 	mov	w0, #0x1                   	// #1
    a8b8:	390002e0 	strb	w0, [x23]
    a8bc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a8c0:	910963e1 	add	x1, sp, #0x258
    a8c4:	52800020 	mov	w0, #0x1                   	// #1
    a8c8:	f9012fe2 	str	x2, [sp, #600]
    a8cc:	f90133f5 	str	x21, [sp, #608]
    a8d0:	97ffeab4 	bl	53a0 <fwp_data.part.0.constprop.0>
    a8d4:	91154283 	add	x3, x20, #0x550
    a8d8:	aa0003f5 	mov	x21, x0
    a8dc:	f949d861 	ldr	x1, [x3, #5040]
    a8e0:	f949ec60 	ldr	x0, [x3, #5080]
    a8e4:	cb0102a1 	sub	x1, x21, x1
    a8e8:	eb00403f 	cmp	x1, x0, lsl #16
    a8ec:	54000322 	b.cs	a950 <f0+0xb60>  // b.hs, b.nlast
    a8f0:	d350fc22 	lsr	x2, x1, #16
    a8f4:	f949fc63 	ldr	x3, [x3, #5112]
    a8f8:	8b020842 	add	x2, x2, x2, lsl #2
    a8fc:	d37df042 	lsl	x2, x2, #3
    a900:	8b020060 	add	x0, x3, x2
    a904:	f9401017 	ldr	x23, [x0, #32]
    a908:	b4000257 	cbz	x23, a950 <f0+0xb60>
    a90c:	38626862 	ldrb	w2, [x3, x2]
    a910:	7100085f 	cmp	w2, #0x2
    a914:	5400c140 	b.eq	c13c <f0+0x234c>  // b.none
    a918:	7100045f 	cmp	w2, #0x1
    a91c:	540001a1 	b.ne	a950 <f0+0xb60>  // b.any
    a920:	29430002 	ldp	w2, w0, [x0, #24]
    a924:	92403c21 	and	x1, x1, #0xffff
    a928:	9b027c21 	mul	x1, x1, x2
    a92c:	d360fc21 	lsr	x1, x1, #32
    a930:	eb00003f 	cmp	x1, x0
    a934:	540000e2 	b.cs	a950 <f0+0xb60>  // b.hs, b.nlast
    a938:	8b0102f7 	add	x23, x23, x1
    a93c:	394002e0 	ldrb	w0, [x23]
    a940:	7103fc1f 	cmp	w0, #0xff
    a944:	5400cda0 	b.eq	c2f8 <f0+0x2508>  // b.none
    a948:	52800020 	mov	w0, #0x1                   	// #1
    a94c:	390002e0 	strb	w0, [x23]
    a950:	9109a3e1 	add	x1, sp, #0x268
    a954:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a958:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a95c:	52800020 	mov	w0, #0x1                   	// #1
    a960:	f90137f7 	str	x23, [sp, #616]
    a964:	f9013bf5 	str	x21, [sp, #624]
    a968:	97ffea8e 	bl	53a0 <fwp_data.part.0.constprop.0>
    a96c:	97ffeafa 	bl	5554 <fwp_rc_fresh>
    a970:	aa0003e2 	mov	x2, x0
    a974:	9109e3e1 	add	x1, sp, #0x278
    a978:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a97c:	52800020 	mov	w0, #0x1                   	// #1
    a980:	f9013ff5 	str	x21, [sp, #632]
    a984:	f90143e2 	str	x2, [sp, #640]
    a988:	97ffea86 	bl	53a0 <fwp_data.part.0.constprop.0>
    a98c:	97ffeaf2 	bl	5554 <fwp_rc_fresh>
    a990:	aa0003e2 	mov	x2, x0
    a994:	910a23e1 	add	x1, sp, #0x288
    a998:	52800020 	mov	w0, #0x1                   	// #1
    a99c:	f90147f7 	str	x23, [sp, #648]
    a9a0:	f9014be2 	str	x2, [sp, #656]
    a9a4:	97ffea7f 	bl	53a0 <fwp_data.part.0.constprop.0>
    a9a8:	97ffeaeb 	bl	5554 <fwp_rc_fresh>
    a9ac:	aa0003e2 	mov	x2, x0
    a9b0:	910a63e1 	add	x1, sp, #0x298
    a9b4:	52800020 	mov	w0, #0x1                   	// #1
    a9b8:	f9014ff5 	str	x21, [sp, #664]
    a9bc:	f90153e2 	str	x2, [sp, #672]
    a9c0:	97ffea78 	bl	53a0 <fwp_data.part.0.constprop.0>
    a9c4:	97ffeae4 	bl	5554 <fwp_rc_fresh>
    a9c8:	aa0003e2 	mov	x2, x0
    a9cc:	910aa3e1 	add	x1, sp, #0x2a8
    a9d0:	52800020 	mov	w0, #0x1                   	// #1
    a9d4:	f90157f7 	str	x23, [sp, #680]
    a9d8:	f9015be2 	str	x2, [sp, #688]
    a9dc:	97ffea71 	bl	53a0 <fwp_data.part.0.constprop.0>
    a9e0:	91154283 	add	x3, x20, #0x550
    a9e4:	aa0003f5 	mov	x21, x0
    a9e8:	f949d861 	ldr	x1, [x3, #5040]
    a9ec:	f949ec60 	ldr	x0, [x3, #5080]
    a9f0:	cb0102a1 	sub	x1, x21, x1
    a9f4:	eb00403f 	cmp	x1, x0, lsl #16
    a9f8:	54000322 	b.cs	aa5c <f0+0xc6c>  // b.hs, b.nlast
    a9fc:	d350fc22 	lsr	x2, x1, #16
    aa00:	f949fc63 	ldr	x3, [x3, #5112]
    aa04:	8b020842 	add	x2, x2, x2, lsl #2
    aa08:	d37df042 	lsl	x2, x2, #3
    aa0c:	8b020060 	add	x0, x3, x2
    aa10:	f9401017 	ldr	x23, [x0, #32]
    aa14:	b4000257 	cbz	x23, aa5c <f0+0xc6c>
    aa18:	38626862 	ldrb	w2, [x3, x2]
    aa1c:	7100085f 	cmp	w2, #0x2
    aa20:	5400b880 	b.eq	c130 <f0+0x2340>  // b.none
    aa24:	7100045f 	cmp	w2, #0x1
    aa28:	540001a1 	b.ne	aa5c <f0+0xc6c>  // b.any
    aa2c:	29430002 	ldp	w2, w0, [x0, #24]
    aa30:	92403c21 	and	x1, x1, #0xffff
    aa34:	9b027c21 	mul	x1, x1, x2
    aa38:	d360fc21 	lsr	x1, x1, #32
    aa3c:	eb00003f 	cmp	x1, x0
    aa40:	540000e2 	b.cs	aa5c <f0+0xc6c>  // b.hs, b.nlast
    aa44:	8b0102f7 	add	x23, x23, x1
    aa48:	394002e0 	ldrb	w0, [x23]
    aa4c:	7103fc1f 	cmp	w0, #0xff
    aa50:	5400c5a0 	b.eq	c304 <f0+0x2514>  // b.none
    aa54:	52800020 	mov	w0, #0x1                   	// #1
    aa58:	390002e0 	strb	w0, [x23]
    aa5c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa60:	910ae3e1 	add	x1, sp, #0x2b8
    aa64:	52800020 	mov	w0, #0x1                   	// #1
    aa68:	f9015fe2 	str	x2, [sp, #696]
    aa6c:	f90163f5 	str	x21, [sp, #704]
    aa70:	97ffea4c 	bl	53a0 <fwp_data.part.0.constprop.0>
    aa74:	91154283 	add	x3, x20, #0x550
    aa78:	aa0003f5 	mov	x21, x0
    aa7c:	f949d861 	ldr	x1, [x3, #5040]
    aa80:	f949ec60 	ldr	x0, [x3, #5080]
    aa84:	cb0102a1 	sub	x1, x21, x1
    aa88:	eb00403f 	cmp	x1, x0, lsl #16
    aa8c:	54000322 	b.cs	aaf0 <f0+0xd00>  // b.hs, b.nlast
    aa90:	d350fc22 	lsr	x2, x1, #16
    aa94:	f949fc63 	ldr	x3, [x3, #5112]
    aa98:	8b020842 	add	x2, x2, x2, lsl #2
    aa9c:	d37df042 	lsl	x2, x2, #3
    aaa0:	8b020060 	add	x0, x3, x2
    aaa4:	f9401017 	ldr	x23, [x0, #32]
    aaa8:	b4000257 	cbz	x23, aaf0 <f0+0xd00>
    aaac:	38626862 	ldrb	w2, [x3, x2]
    aab0:	7100085f 	cmp	w2, #0x2
    aab4:	5400b0e0 	b.eq	c0d0 <f0+0x22e0>  // b.none
    aab8:	7100045f 	cmp	w2, #0x1
    aabc:	540001a1 	b.ne	aaf0 <f0+0xd00>  // b.any
    aac0:	29430002 	ldp	w2, w0, [x0, #24]
    aac4:	92403c21 	and	x1, x1, #0xffff
    aac8:	9b027c21 	mul	x1, x1, x2
    aacc:	d360fc21 	lsr	x1, x1, #32
    aad0:	eb00003f 	cmp	x1, x0
    aad4:	540000e2 	b.cs	aaf0 <f0+0xd00>  // b.hs, b.nlast
    aad8:	8b0102f7 	add	x23, x23, x1
    aadc:	394002e0 	ldrb	w0, [x23]
    aae0:	7103fc1f 	cmp	w0, #0xff
    aae4:	5400c160 	b.eq	c310 <f0+0x2520>  // b.none
    aae8:	52800020 	mov	w0, #0x1                   	// #1
    aaec:	390002e0 	strb	w0, [x23]
    aaf0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aaf4:	910b23e1 	add	x1, sp, #0x2c8
    aaf8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aafc:	52800020 	mov	w0, #0x1                   	// #1
    ab00:	f90167e2 	str	x2, [sp, #712]
    ab04:	f9016bf5 	str	x21, [sp, #720]
    ab08:	97ffea26 	bl	53a0 <fwp_data.part.0.constprop.0>
    ab0c:	91154283 	add	x3, x20, #0x550
    ab10:	aa0003f5 	mov	x21, x0
    ab14:	f949d861 	ldr	x1, [x3, #5040]
    ab18:	f949ec60 	ldr	x0, [x3, #5080]
    ab1c:	cb0102a1 	sub	x1, x21, x1
    ab20:	eb00403f 	cmp	x1, x0, lsl #16
    ab24:	54000322 	b.cs	ab88 <f0+0xd98>  // b.hs, b.nlast
    ab28:	d350fc22 	lsr	x2, x1, #16
    ab2c:	f949fc63 	ldr	x3, [x3, #5112]
    ab30:	8b020842 	add	x2, x2, x2, lsl #2
    ab34:	d37df042 	lsl	x2, x2, #3
    ab38:	8b020060 	add	x0, x3, x2
    ab3c:	f9401017 	ldr	x23, [x0, #32]
    ab40:	b4000257 	cbz	x23, ab88 <f0+0xd98>
    ab44:	38626862 	ldrb	w2, [x3, x2]
    ab48:	7100085f 	cmp	w2, #0x2
    ab4c:	5400abc0 	b.eq	c0c4 <f0+0x22d4>  // b.none
    ab50:	7100045f 	cmp	w2, #0x1
    ab54:	540001a1 	b.ne	ab88 <f0+0xd98>  // b.any
    ab58:	29430002 	ldp	w2, w0, [x0, #24]
    ab5c:	92403c21 	and	x1, x1, #0xffff
    ab60:	9b027c21 	mul	x1, x1, x2
    ab64:	d360fc21 	lsr	x1, x1, #32
    ab68:	eb00003f 	cmp	x1, x0
    ab6c:	540000e2 	b.cs	ab88 <f0+0xd98>  // b.hs, b.nlast
    ab70:	8b0102f7 	add	x23, x23, x1
    ab74:	394002e0 	ldrb	w0, [x23]
    ab78:	7103fc1f 	cmp	w0, #0xff
    ab7c:	5400bd00 	b.eq	c31c <f0+0x252c>  // b.none
    ab80:	52800020 	mov	w0, #0x1                   	// #1
    ab84:	390002e0 	strb	w0, [x23]
    ab88:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab8c:	910b63e1 	add	x1, sp, #0x2d8
    ab90:	52800020 	mov	w0, #0x1                   	// #1
    ab94:	f9016fe2 	str	x2, [sp, #728]
    ab98:	f90173f5 	str	x21, [sp, #736]
    ab9c:	97ffea01 	bl	53a0 <fwp_data.part.0.constprop.0>
    aba0:	91154283 	add	x3, x20, #0x550
    aba4:	aa0003f5 	mov	x21, x0
    aba8:	f949d861 	ldr	x1, [x3, #5040]
    abac:	f949ec60 	ldr	x0, [x3, #5080]
    abb0:	cb0102a1 	sub	x1, x21, x1
    abb4:	eb00403f 	cmp	x1, x0, lsl #16
    abb8:	54000322 	b.cs	ac1c <f0+0xe2c>  // b.hs, b.nlast
    abbc:	d350fc22 	lsr	x2, x1, #16
    abc0:	f949fc63 	ldr	x3, [x3, #5112]
    abc4:	8b020842 	add	x2, x2, x2, lsl #2
    abc8:	d37df042 	lsl	x2, x2, #3
    abcc:	8b020060 	add	x0, x3, x2
    abd0:	f9401017 	ldr	x23, [x0, #32]
    abd4:	b4000257 	cbz	x23, ac1c <f0+0xe2c>
    abd8:	38626862 	ldrb	w2, [x3, x2]
    abdc:	7100085f 	cmp	w2, #0x2
    abe0:	5400a6c0 	b.eq	c0b8 <f0+0x22c8>  // b.none
    abe4:	7100045f 	cmp	w2, #0x1
    abe8:	540001a1 	b.ne	ac1c <f0+0xe2c>  // b.any
    abec:	29430002 	ldp	w2, w0, [x0, #24]
    abf0:	92403c21 	and	x1, x1, #0xffff
    abf4:	9b027c21 	mul	x1, x1, x2
    abf8:	d360fc21 	lsr	x1, x1, #32
    abfc:	eb00003f 	cmp	x1, x0
    ac00:	540000e2 	b.cs	ac1c <f0+0xe2c>  // b.hs, b.nlast
    ac04:	8b0102f7 	add	x23, x23, x1
    ac08:	394002e0 	ldrb	w0, [x23]
    ac0c:	7103fc1f 	cmp	w0, #0xff
    ac10:	5400b8c0 	b.eq	c328 <f0+0x2538>  // b.none
    ac14:	52800020 	mov	w0, #0x1                   	// #1
    ac18:	390002e0 	strb	w0, [x23]
    ac1c:	910ba3e1 	add	x1, sp, #0x2e8
    ac20:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ac24:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ac28:	52800020 	mov	w0, #0x1                   	// #1
    ac2c:	f90177f7 	str	x23, [sp, #744]
    ac30:	f9017bf5 	str	x21, [sp, #752]
    ac34:	97ffe9db 	bl	53a0 <fwp_data.part.0.constprop.0>
    ac38:	97ffea47 	bl	5554 <fwp_rc_fresh>
    ac3c:	aa0003e2 	mov	x2, x0
    ac40:	910be3e1 	add	x1, sp, #0x2f8
    ac44:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ac48:	52800020 	mov	w0, #0x1                   	// #1
    ac4c:	f9017ff5 	str	x21, [sp, #760]
    ac50:	f90183e2 	str	x2, [sp, #768]
    ac54:	97ffe9d3 	bl	53a0 <fwp_data.part.0.constprop.0>
    ac58:	97ffea3f 	bl	5554 <fwp_rc_fresh>
    ac5c:	aa0003e2 	mov	x2, x0
    ac60:	910c23e1 	add	x1, sp, #0x308
    ac64:	52800020 	mov	w0, #0x1                   	// #1
    ac68:	f90187f7 	str	x23, [sp, #776]
    ac6c:	f9018be2 	str	x2, [sp, #784]
    ac70:	97ffe9cc 	bl	53a0 <fwp_data.part.0.constprop.0>
    ac74:	97ffea38 	bl	5554 <fwp_rc_fresh>
    ac78:	aa0003e2 	mov	x2, x0
    ac7c:	910c63e1 	add	x1, sp, #0x318
    ac80:	52800020 	mov	w0, #0x1                   	// #1
    ac84:	f9018ff5 	str	x21, [sp, #792]
    ac88:	f90193e2 	str	x2, [sp, #800]
    ac8c:	97ffe9c5 	bl	53a0 <fwp_data.part.0.constprop.0>
    ac90:	91154283 	add	x3, x20, #0x550
    ac94:	aa0003f5 	mov	x21, x0
    ac98:	f949d861 	ldr	x1, [x3, #5040]
    ac9c:	f949ec60 	ldr	x0, [x3, #5080]
    aca0:	cb0102a1 	sub	x1, x21, x1
    aca4:	eb00403f 	cmp	x1, x0, lsl #16
    aca8:	54000322 	b.cs	ad0c <f0+0xf1c>  // b.hs, b.nlast
    acac:	d350fc22 	lsr	x2, x1, #16
    acb0:	f949fc63 	ldr	x3, [x3, #5112]
    acb4:	8b020842 	add	x2, x2, x2, lsl #2
    acb8:	d37df042 	lsl	x2, x2, #3
    acbc:	8b020060 	add	x0, x3, x2
    acc0:	f9401017 	ldr	x23, [x0, #32]
    acc4:	b4000257 	cbz	x23, ad0c <f0+0xf1c>
    acc8:	38626862 	ldrb	w2, [x3, x2]
    accc:	7100085f 	cmp	w2, #0x2
    acd0:	54009ee0 	b.eq	c0ac <f0+0x22bc>  // b.none
    acd4:	7100045f 	cmp	w2, #0x1
    acd8:	540001a1 	b.ne	ad0c <f0+0xf1c>  // b.any
    acdc:	29430002 	ldp	w2, w0, [x0, #24]
    ace0:	92403c21 	and	x1, x1, #0xffff
    ace4:	9b027c21 	mul	x1, x1, x2
    ace8:	d360fc21 	lsr	x1, x1, #32
    acec:	eb00003f 	cmp	x1, x0
    acf0:	540000e2 	b.cs	ad0c <f0+0xf1c>  // b.hs, b.nlast
    acf4:	8b0102f7 	add	x23, x23, x1
    acf8:	394002e0 	ldrb	w0, [x23]
    acfc:	7103fc1f 	cmp	w0, #0xff
    ad00:	5400b1a0 	b.eq	c334 <f0+0x2544>  // b.none
    ad04:	52800020 	mov	w0, #0x1                   	// #1
    ad08:	390002e0 	strb	w0, [x23]
    ad0c:	910ca3e1 	add	x1, sp, #0x328
    ad10:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ad14:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ad18:	52800020 	mov	w0, #0x1                   	// #1
    ad1c:	f90197f7 	str	x23, [sp, #808]
    ad20:	f9019bf5 	str	x21, [sp, #816]
    ad24:	97ffe99f 	bl	53a0 <fwp_data.part.0.constprop.0>
    ad28:	97ffea0b 	bl	5554 <fwp_rc_fresh>
    ad2c:	aa0003e2 	mov	x2, x0
    ad30:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ad34:	910ce3e1 	add	x1, sp, #0x338
    ad38:	52800020 	mov	w0, #0x1                   	// #1
    ad3c:	f9019fe3 	str	x3, [sp, #824]
    ad40:	f901a3e2 	str	x2, [sp, #832]
    ad44:	97ffe997 	bl	53a0 <fwp_data.part.0.constprop.0>
    ad48:	97ffea03 	bl	5554 <fwp_rc_fresh>
    ad4c:	aa0003e2 	mov	x2, x0
    ad50:	910d23e1 	add	x1, sp, #0x348
    ad54:	52800020 	mov	w0, #0x1                   	// #1
    ad58:	f901a7f7 	str	x23, [sp, #840]
    ad5c:	f901abe2 	str	x2, [sp, #848]
    ad60:	97ffe990 	bl	53a0 <fwp_data.part.0.constprop.0>
    ad64:	91154283 	add	x3, x20, #0x550
    ad68:	aa0003f7 	mov	x23, x0
    ad6c:	f949d861 	ldr	x1, [x3, #5040]
    ad70:	f949ec60 	ldr	x0, [x3, #5080]
    ad74:	cb0102e1 	sub	x1, x23, x1
    ad78:	eb00403f 	cmp	x1, x0, lsl #16
    ad7c:	54000322 	b.cs	ade0 <f0+0xff0>  // b.hs, b.nlast
    ad80:	d350fc22 	lsr	x2, x1, #16
    ad84:	f949fc63 	ldr	x3, [x3, #5112]
    ad88:	8b020842 	add	x2, x2, x2, lsl #2
    ad8c:	d37df042 	lsl	x2, x2, #3
    ad90:	8b020060 	add	x0, x3, x2
    ad94:	f9401015 	ldr	x21, [x0, #32]
    ad98:	b4000255 	cbz	x21, ade0 <f0+0xff0>
    ad9c:	38626862 	ldrb	w2, [x3, x2]
    ada0:	7100085f 	cmp	w2, #0x2
    ada4:	540097e0 	b.eq	c0a0 <f0+0x22b0>  // b.none
    ada8:	7100045f 	cmp	w2, #0x1
    adac:	540001a1 	b.ne	ade0 <f0+0xff0>  // b.any
    adb0:	29430002 	ldp	w2, w0, [x0, #24]
    adb4:	92403c21 	and	x1, x1, #0xffff
    adb8:	9b027c21 	mul	x1, x1, x2
    adbc:	d360fc21 	lsr	x1, x1, #32
    adc0:	eb00003f 	cmp	x1, x0
    adc4:	540000e2 	b.cs	ade0 <f0+0xff0>  // b.hs, b.nlast
    adc8:	8b0102b5 	add	x21, x21, x1
    adcc:	394002a0 	ldrb	w0, [x21]
    add0:	7103fc1f 	cmp	w0, #0xff
    add4:	5400ab60 	b.eq	c340 <f0+0x2550>  // b.none
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	390002a0 	strb	w0, [x21]
    ade0:	910d63e1 	add	x1, sp, #0x358
    ade4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ade8:	52800020 	mov	w0, #0x1                   	// #1
    adec:	f901aff5 	str	x21, [sp, #856]
    adf0:	f901b3f7 	str	x23, [sp, #864]
    adf4:	97ffe96b 	bl	53a0 <fwp_data.part.0.constprop.0>
    adf8:	97ffe9d7 	bl	5554 <fwp_rc_fresh>
    adfc:	aa0003e2 	mov	x2, x0
    ae00:	910da3e1 	add	x1, sp, #0x368
    ae04:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae08:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae0c:	52800020 	mov	w0, #0x1                   	// #1
    ae10:	f901b7f7 	str	x23, [sp, #872]
    ae14:	f901bbe2 	str	x2, [sp, #880]
    ae18:	97ffe962 	bl	53a0 <fwp_data.part.0.constprop.0>
    ae1c:	97ffe9ce 	bl	5554 <fwp_rc_fresh>
    ae20:	aa0003e2 	mov	x2, x0
    ae24:	910de3e1 	add	x1, sp, #0x378
    ae28:	52800020 	mov	w0, #0x1                   	// #1
    ae2c:	f901bff5 	str	x21, [sp, #888]
    ae30:	f901c3e2 	str	x2, [sp, #896]
    ae34:	97ffe95b 	bl	53a0 <fwp_data.part.0.constprop.0>
    ae38:	97ffe9c7 	bl	5554 <fwp_rc_fresh>
    ae3c:	aa0003e2 	mov	x2, x0
    ae40:	910e23e1 	add	x1, sp, #0x388
    ae44:	52800020 	mov	w0, #0x1                   	// #1
    ae48:	f901c7f7 	str	x23, [sp, #904]
    ae4c:	f901cbe2 	str	x2, [sp, #912]
    ae50:	97ffe954 	bl	53a0 <fwp_data.part.0.constprop.0>
    ae54:	97ffe9c0 	bl	5554 <fwp_rc_fresh>
    ae58:	aa0003e2 	mov	x2, x0
    ae5c:	910e63e1 	add	x1, sp, #0x398
    ae60:	52800020 	mov	w0, #0x1                   	// #1
    ae64:	f901cff5 	str	x21, [sp, #920]
    ae68:	f901d3e2 	str	x2, [sp, #928]
    ae6c:	97ffe94d 	bl	53a0 <fwp_data.part.0.constprop.0>
    ae70:	97ffe9b9 	bl	5554 <fwp_rc_fresh>
    ae74:	aa0003e2 	mov	x2, x0
    ae78:	910ea3e1 	add	x1, sp, #0x3a8
    ae7c:	52800020 	mov	w0, #0x1                   	// #1
    ae80:	f901d7f7 	str	x23, [sp, #936]
    ae84:	f901dbe2 	str	x2, [sp, #944]
    ae88:	97ffe946 	bl	53a0 <fwp_data.part.0.constprop.0>
    ae8c:	97ffe9b2 	bl	5554 <fwp_rc_fresh>
    ae90:	aa0003e2 	mov	x2, x0
    ae94:	910ee3e1 	add	x1, sp, #0x3b8
    ae98:	52800020 	mov	w0, #0x1                   	// #1
    ae9c:	f901dff5 	str	x21, [sp, #952]
    aea0:	f901e3e2 	str	x2, [sp, #960]
    aea4:	97ffe93f 	bl	53a0 <fwp_data.part.0.constprop.0>
    aea8:	97ffe9ab 	bl	5554 <fwp_rc_fresh>
    aeac:	aa0003e2 	mov	x2, x0
    aeb0:	910f23e1 	add	x1, sp, #0x3c8
    aeb4:	52800020 	mov	w0, #0x1                   	// #1
    aeb8:	f901e7f7 	str	x23, [sp, #968]
    aebc:	f901ebe2 	str	x2, [sp, #976]
    aec0:	97ffe938 	bl	53a0 <fwp_data.part.0.constprop.0>
    aec4:	97ffe9a4 	bl	5554 <fwp_rc_fresh>
    aec8:	aa0003e2 	mov	x2, x0
    aecc:	910f63e1 	add	x1, sp, #0x3d8
    aed0:	52800020 	mov	w0, #0x1                   	// #1
    aed4:	f901eff5 	str	x21, [sp, #984]
    aed8:	f901f3e2 	str	x2, [sp, #992]
    aedc:	97ffe931 	bl	53a0 <fwp_data.part.0.constprop.0>
    aee0:	91154283 	add	x3, x20, #0x550
    aee4:	aa0003f5 	mov	x21, x0
    aee8:	f949d861 	ldr	x1, [x3, #5040]
    aeec:	f949ec60 	ldr	x0, [x3, #5080]
    aef0:	cb0102a1 	sub	x1, x21, x1
    aef4:	eb00403f 	cmp	x1, x0, lsl #16
    aef8:	54000322 	b.cs	af5c <f0+0x116c>  // b.hs, b.nlast
    aefc:	d350fc22 	lsr	x2, x1, #16
    af00:	f949fc63 	ldr	x3, [x3, #5112]
    af04:	8b020842 	add	x2, x2, x2, lsl #2
    af08:	d37df042 	lsl	x2, x2, #3
    af0c:	8b020060 	add	x0, x3, x2
    af10:	f9401017 	ldr	x23, [x0, #32]
    af14:	b4000257 	cbz	x23, af5c <f0+0x116c>
    af18:	38626862 	ldrb	w2, [x3, x2]
    af1c:	7100085f 	cmp	w2, #0x2
    af20:	54008ba0 	b.eq	c094 <f0+0x22a4>  // b.none
    af24:	7100045f 	cmp	w2, #0x1
    af28:	540001a1 	b.ne	af5c <f0+0x116c>  // b.any
    af2c:	29430002 	ldp	w2, w0, [x0, #24]
    af30:	92403c21 	and	x1, x1, #0xffff
    af34:	9b027c21 	mul	x1, x1, x2
    af38:	d360fc21 	lsr	x1, x1, #32
    af3c:	eb00003f 	cmp	x1, x0
    af40:	540000e2 	b.cs	af5c <f0+0x116c>  // b.hs, b.nlast
    af44:	8b0102f7 	add	x23, x23, x1
    af48:	394002e0 	ldrb	w0, [x23]
    af4c:	7103fc1f 	cmp	w0, #0xff
    af50:	54009fe0 	b.eq	c34c <f0+0x255c>  // b.none
    af54:	52800020 	mov	w0, #0x1                   	// #1
    af58:	390002e0 	strb	w0, [x23]
    af5c:	910fa3e1 	add	x1, sp, #0x3e8
    af60:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    af64:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    af68:	52800020 	mov	w0, #0x1                   	// #1
    af6c:	f901f7f7 	str	x23, [sp, #1000]
    af70:	f901fbf5 	str	x21, [sp, #1008]
    af74:	97ffe90b 	bl	53a0 <fwp_data.part.0.constprop.0>
    af78:	97ffe977 	bl	5554 <fwp_rc_fresh>
    af7c:	aa0003e2 	mov	x2, x0
    af80:	910fe3e1 	add	x1, sp, #0x3f8
    af84:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    af88:	52800020 	mov	w0, #0x1                   	// #1
    af8c:	f901fff5 	str	x21, [sp, #1016]
    af90:	f90203e2 	str	x2, [sp, #1024]
    af94:	97ffe903 	bl	53a0 <fwp_data.part.0.constprop.0>
    af98:	97ffe96f 	bl	5554 <fwp_rc_fresh>
    af9c:	aa0003e2 	mov	x2, x0
    afa0:	911023e1 	add	x1, sp, #0x408
    afa4:	52800020 	mov	w0, #0x1                   	// #1
    afa8:	f90207f7 	str	x23, [sp, #1032]
    afac:	f9020be2 	str	x2, [sp, #1040]
    afb0:	97ffe8fc 	bl	53a0 <fwp_data.part.0.constprop.0>
    afb4:	97ffe968 	bl	5554 <fwp_rc_fresh>
    afb8:	aa0003e2 	mov	x2, x0
    afbc:	911063e1 	add	x1, sp, #0x418
    afc0:	52800020 	mov	w0, #0x1                   	// #1
    afc4:	f9020ff5 	str	x21, [sp, #1048]
    afc8:	f90213e2 	str	x2, [sp, #1056]
    afcc:	97ffe8f5 	bl	53a0 <fwp_data.part.0.constprop.0>
    afd0:	97ffe961 	bl	5554 <fwp_rc_fresh>
    afd4:	aa0003e2 	mov	x2, x0
    afd8:	9110a3e1 	add	x1, sp, #0x428
    afdc:	52800020 	mov	w0, #0x1                   	// #1
    afe0:	f90217f7 	str	x23, [sp, #1064]
    afe4:	f9021be2 	str	x2, [sp, #1072]
    afe8:	97ffe8ee 	bl	53a0 <fwp_data.part.0.constprop.0>
    afec:	97ffe95a 	bl	5554 <fwp_rc_fresh>
    aff0:	aa0003e2 	mov	x2, x0
    aff4:	9110e3e1 	add	x1, sp, #0x438
    aff8:	52800020 	mov	w0, #0x1                   	// #1
    affc:	f9021ff5 	str	x21, [sp, #1080]
    b000:	f90223e2 	str	x2, [sp, #1088]
    b004:	97ffe8e7 	bl	53a0 <fwp_data.part.0.constprop.0>
    b008:	97ffe953 	bl	5554 <fwp_rc_fresh>
    b00c:	aa0003e2 	mov	x2, x0
    b010:	911123e1 	add	x1, sp, #0x448
    b014:	52800020 	mov	w0, #0x1                   	// #1
    b018:	f90227f7 	str	x23, [sp, #1096]
    b01c:	f9022be2 	str	x2, [sp, #1104]
    b020:	97ffe8e0 	bl	53a0 <fwp_data.part.0.constprop.0>
    b024:	97ffe94c 	bl	5554 <fwp_rc_fresh>
    b028:	aa0003e2 	mov	x2, x0
    b02c:	911163e1 	add	x1, sp, #0x458
    b030:	52800020 	mov	w0, #0x1                   	// #1
    b034:	f9022ff5 	str	x21, [sp, #1112]
    b038:	f90233e2 	str	x2, [sp, #1120]
    b03c:	97ffe8d9 	bl	53a0 <fwp_data.part.0.constprop.0>
    b040:	91154283 	add	x3, x20, #0x550
    b044:	aa0003f5 	mov	x21, x0
    b048:	f949d861 	ldr	x1, [x3, #5040]
    b04c:	f949ec60 	ldr	x0, [x3, #5080]
    b050:	cb0102a1 	sub	x1, x21, x1
    b054:	eb00403f 	cmp	x1, x0, lsl #16
    b058:	54000322 	b.cs	b0bc <f0+0x12cc>  // b.hs, b.nlast
    b05c:	d350fc22 	lsr	x2, x1, #16
    b060:	f949fc63 	ldr	x3, [x3, #5112]
    b064:	8b020842 	add	x2, x2, x2, lsl #2
    b068:	d37df042 	lsl	x2, x2, #3
    b06c:	8b020060 	add	x0, x3, x2
    b070:	f9401017 	ldr	x23, [x0, #32]
    b074:	b4000257 	cbz	x23, b0bc <f0+0x12cc>
    b078:	38626862 	ldrb	w2, [x3, x2]
    b07c:	7100085f 	cmp	w2, #0x2
    b080:	54008040 	b.eq	c088 <f0+0x2298>  // b.none
    b084:	7100045f 	cmp	w2, #0x1
    b088:	540001a1 	b.ne	b0bc <f0+0x12cc>  // b.any
    b08c:	29430002 	ldp	w2, w0, [x0, #24]
    b090:	92403c21 	and	x1, x1, #0xffff
    b094:	9b027c21 	mul	x1, x1, x2
    b098:	d360fc21 	lsr	x1, x1, #32
    b09c:	eb00003f 	cmp	x1, x0
    b0a0:	540000e2 	b.cs	b0bc <f0+0x12cc>  // b.hs, b.nlast
    b0a4:	8b0102f7 	add	x23, x23, x1
    b0a8:	394002e0 	ldrb	w0, [x23]
    b0ac:	7103fc1f 	cmp	w0, #0xff
    b0b0:	54009540 	b.eq	c358 <f0+0x2568>  // b.none
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	390002e0 	strb	w0, [x23]
    b0bc:	9111a3e1 	add	x1, sp, #0x468
    b0c0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b0c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b0c8:	52800020 	mov	w0, #0x1                   	// #1
    b0cc:	f90237f7 	str	x23, [sp, #1128]
    b0d0:	f9023bf5 	str	x21, [sp, #1136]
    b0d4:	97ffe8b3 	bl	53a0 <fwp_data.part.0.constprop.0>
    b0d8:	97ffe91f 	bl	5554 <fwp_rc_fresh>
    b0dc:	aa0003e2 	mov	x2, x0
    b0e0:	9111e3e1 	add	x1, sp, #0x478
    b0e4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0e8:	52800020 	mov	w0, #0x1                   	// #1
    b0ec:	f9023ff5 	str	x21, [sp, #1144]
    b0f0:	f90243e2 	str	x2, [sp, #1152]
    b0f4:	97ffe8ab 	bl	53a0 <fwp_data.part.0.constprop.0>
    b0f8:	97ffe917 	bl	5554 <fwp_rc_fresh>
    b0fc:	aa0003e2 	mov	x2, x0
    b100:	911223e1 	add	x1, sp, #0x488
    b104:	52800020 	mov	w0, #0x1                   	// #1
    b108:	f90247f7 	str	x23, [sp, #1160]
    b10c:	f9024be2 	str	x2, [sp, #1168]
    b110:	97ffe8a4 	bl	53a0 <fwp_data.part.0.constprop.0>
    b114:	97ffe910 	bl	5554 <fwp_rc_fresh>
    b118:	aa0003e2 	mov	x2, x0
    b11c:	911263e1 	add	x1, sp, #0x498
    b120:	52800020 	mov	w0, #0x1                   	// #1
    b124:	f9024ff5 	str	x21, [sp, #1176]
    b128:	f90253e2 	str	x2, [sp, #1184]
    b12c:	97ffe89d 	bl	53a0 <fwp_data.part.0.constprop.0>
    b130:	91154283 	add	x3, x20, #0x550
    b134:	aa0003f5 	mov	x21, x0
    b138:	f949d861 	ldr	x1, [x3, #5040]
    b13c:	f949ec60 	ldr	x0, [x3, #5080]
    b140:	cb0102a1 	sub	x1, x21, x1
    b144:	eb00403f 	cmp	x1, x0, lsl #16
    b148:	54000322 	b.cs	b1ac <f0+0x13bc>  // b.hs, b.nlast
    b14c:	d350fc22 	lsr	x2, x1, #16
    b150:	f949fc63 	ldr	x3, [x3, #5112]
    b154:	8b020842 	add	x2, x2, x2, lsl #2
    b158:	d37df042 	lsl	x2, x2, #3
    b15c:	8b020060 	add	x0, x3, x2
    b160:	f9401017 	ldr	x23, [x0, #32]
    b164:	b4000257 	cbz	x23, b1ac <f0+0x13bc>
    b168:	38626862 	ldrb	w2, [x3, x2]
    b16c:	7100085f 	cmp	w2, #0x2
    b170:	54007860 	b.eq	c07c <f0+0x228c>  // b.none
    b174:	7100045f 	cmp	w2, #0x1
    b178:	540001a1 	b.ne	b1ac <f0+0x13bc>  // b.any
    b17c:	29430002 	ldp	w2, w0, [x0, #24]
    b180:	92403c21 	and	x1, x1, #0xffff
    b184:	9b027c21 	mul	x1, x1, x2
    b188:	d360fc21 	lsr	x1, x1, #32
    b18c:	eb00003f 	cmp	x1, x0
    b190:	540000e2 	b.cs	b1ac <f0+0x13bc>  // b.hs, b.nlast
    b194:	8b0102f7 	add	x23, x23, x1
    b198:	394002e0 	ldrb	w0, [x23]
    b19c:	7103fc1f 	cmp	w0, #0xff
    b1a0:	54008e20 	b.eq	c364 <f0+0x2574>  // b.none
    b1a4:	52800020 	mov	w0, #0x1                   	// #1
    b1a8:	390002e0 	strb	w0, [x23]
    b1ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b1b0:	9112a3e1 	add	x1, sp, #0x4a8
    b1b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b1b8:	52800020 	mov	w0, #0x1                   	// #1
    b1bc:	f90257e2 	str	x2, [sp, #1192]
    b1c0:	f9025bf5 	str	x21, [sp, #1200]
    b1c4:	97ffe877 	bl	53a0 <fwp_data.part.0.constprop.0>
    b1c8:	97ffe8e3 	bl	5554 <fwp_rc_fresh>
    b1cc:	aa0003e2 	mov	x2, x0
    b1d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b1d4:	9112e3e1 	add	x1, sp, #0x4b8
    b1d8:	52800020 	mov	w0, #0x1                   	// #1
    b1dc:	f9025fe3 	str	x3, [sp, #1208]
    b1e0:	f90263e2 	str	x2, [sp, #1216]
    b1e4:	97ffe86f 	bl	53a0 <fwp_data.part.0.constprop.0>
    b1e8:	91154283 	add	x3, x20, #0x550
    b1ec:	aa0003f5 	mov	x21, x0
    b1f0:	f949d861 	ldr	x1, [x3, #5040]
    b1f4:	f949ec60 	ldr	x0, [x3, #5080]
    b1f8:	cb0102a1 	sub	x1, x21, x1
    b1fc:	eb00403f 	cmp	x1, x0, lsl #16
    b200:	54000322 	b.cs	b264 <f0+0x1474>  // b.hs, b.nlast
    b204:	d350fc22 	lsr	x2, x1, #16
    b208:	f949fc63 	ldr	x3, [x3, #5112]
    b20c:	8b020842 	add	x2, x2, x2, lsl #2
    b210:	d37df042 	lsl	x2, x2, #3
    b214:	8b020060 	add	x0, x3, x2
    b218:	f9401017 	ldr	x23, [x0, #32]
    b21c:	b4000257 	cbz	x23, b264 <f0+0x1474>
    b220:	38626862 	ldrb	w2, [x3, x2]
    b224:	7100085f 	cmp	w2, #0x2
    b228:	540080e0 	b.eq	c244 <f0+0x2454>  // b.none
    b22c:	7100045f 	cmp	w2, #0x1
    b230:	540001a1 	b.ne	b264 <f0+0x1474>  // b.any
    b234:	29430002 	ldp	w2, w0, [x0, #24]
    b238:	92403c21 	and	x1, x1, #0xffff
    b23c:	9b027c21 	mul	x1, x1, x2
    b240:	d360fc21 	lsr	x1, x1, #32
    b244:	eb00003f 	cmp	x1, x0
    b248:	540000e2 	b.cs	b264 <f0+0x1474>  // b.hs, b.nlast
    b24c:	8b0102f7 	add	x23, x23, x1
    b250:	394002e0 	ldrb	w0, [x23]
    b254:	7103fc1f 	cmp	w0, #0xff
    b258:	540088c0 	b.eq	c370 <f0+0x2580>  // b.none
    b25c:	52800020 	mov	w0, #0x1                   	// #1
    b260:	390002e0 	strb	w0, [x23]
    b264:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b268:	911323e1 	add	x1, sp, #0x4c8
    b26c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b270:	52800020 	mov	w0, #0x1                   	// #1
    b274:	f90267e2 	str	x2, [sp, #1224]
    b278:	f9026bf5 	str	x21, [sp, #1232]
    b27c:	97ffe849 	bl	53a0 <fwp_data.part.0.constprop.0>
    b280:	91154283 	add	x3, x20, #0x550
    b284:	aa0003f5 	mov	x21, x0
    b288:	f949d861 	ldr	x1, [x3, #5040]
    b28c:	f949ec60 	ldr	x0, [x3, #5080]
    b290:	cb0102a1 	sub	x1, x21, x1
    b294:	eb00403f 	cmp	x1, x0, lsl #16
    b298:	54000322 	b.cs	b2fc <f0+0x150c>  // b.hs, b.nlast
    b29c:	d350fc22 	lsr	x2, x1, #16
    b2a0:	f949fc63 	ldr	x3, [x3, #5112]
    b2a4:	8b020842 	add	x2, x2, x2, lsl #2
    b2a8:	d37df042 	lsl	x2, x2, #3
    b2ac:	8b020060 	add	x0, x3, x2
    b2b0:	f9401017 	ldr	x23, [x0, #32]
    b2b4:	b4000257 	cbz	x23, b2fc <f0+0x150c>
    b2b8:	38626862 	ldrb	w2, [x3, x2]
    b2bc:	7100085f 	cmp	w2, #0x2
    b2c0:	54007bc0 	b.eq	c238 <f0+0x2448>  // b.none
    b2c4:	7100045f 	cmp	w2, #0x1
    b2c8:	540001a1 	b.ne	b2fc <f0+0x150c>  // b.any
    b2cc:	29430002 	ldp	w2, w0, [x0, #24]
    b2d0:	92403c21 	and	x1, x1, #0xffff
    b2d4:	9b027c21 	mul	x1, x1, x2
    b2d8:	d360fc21 	lsr	x1, x1, #32
    b2dc:	eb00003f 	cmp	x1, x0
    b2e0:	540000e2 	b.cs	b2fc <f0+0x150c>  // b.hs, b.nlast
    b2e4:	8b0102f7 	add	x23, x23, x1
    b2e8:	394002e0 	ldrb	w0, [x23]
    b2ec:	7103fc1f 	cmp	w0, #0xff
    b2f0:	54008460 	b.eq	c37c <f0+0x258c>  // b.none
    b2f4:	52800020 	mov	w0, #0x1                   	// #1
    b2f8:	390002e0 	strb	w0, [x23]
    b2fc:	911363e1 	add	x1, sp, #0x4d8
    b300:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b304:	52800020 	mov	w0, #0x1                   	// #1
    b308:	f9026ff7 	str	x23, [sp, #1240]
    b30c:	f90273f5 	str	x21, [sp, #1248]
    b310:	97ffe824 	bl	53a0 <fwp_data.part.0.constprop.0>
    b314:	97ffe890 	bl	5554 <fwp_rc_fresh>
    b318:	aa0003e2 	mov	x2, x0
    b31c:	9113a3e1 	add	x1, sp, #0x4e8
    b320:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b324:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b328:	52800020 	mov	w0, #0x1                   	// #1
    b32c:	f90277f5 	str	x21, [sp, #1256]
    b330:	f9027be2 	str	x2, [sp, #1264]
    b334:	97ffe81b 	bl	53a0 <fwp_data.part.0.constprop.0>
    b338:	97ffe887 	bl	5554 <fwp_rc_fresh>
    b33c:	aa0003e2 	mov	x2, x0
    b340:	9113e3e1 	add	x1, sp, #0x4f8
    b344:	52800020 	mov	w0, #0x1                   	// #1
    b348:	f9027ff7 	str	x23, [sp, #1272]
    b34c:	f90283e2 	str	x2, [sp, #1280]
    b350:	97ffe814 	bl	53a0 <fwp_data.part.0.constprop.0>
    b354:	97ffe880 	bl	5554 <fwp_rc_fresh>
    b358:	aa0003e2 	mov	x2, x0
    b35c:	911423e1 	add	x1, sp, #0x508
    b360:	52800020 	mov	w0, #0x1                   	// #1
    b364:	f90287f5 	str	x21, [sp, #1288]
    b368:	f9028be2 	str	x2, [sp, #1296]
    b36c:	97ffe80d 	bl	53a0 <fwp_data.part.0.constprop.0>
    b370:	97ffe879 	bl	5554 <fwp_rc_fresh>
    b374:	aa0003e2 	mov	x2, x0
    b378:	911463e1 	add	x1, sp, #0x518
    b37c:	52800020 	mov	w0, #0x1                   	// #1
    b380:	f9028ff7 	str	x23, [sp, #1304]
    b384:	f90293e2 	str	x2, [sp, #1312]
    b388:	97ffe806 	bl	53a0 <fwp_data.part.0.constprop.0>
    b38c:	91154283 	add	x3, x20, #0x550
    b390:	aa0003f5 	mov	x21, x0
    b394:	f949d861 	ldr	x1, [x3, #5040]
    b398:	f949ec60 	ldr	x0, [x3, #5080]
    b39c:	cb0102a1 	sub	x1, x21, x1
    b3a0:	eb00403f 	cmp	x1, x0, lsl #16
    b3a4:	54000322 	b.cs	b408 <f0+0x1618>  // b.hs, b.nlast
    b3a8:	d350fc22 	lsr	x2, x1, #16
    b3ac:	f949fc63 	ldr	x3, [x3, #5112]
    b3b0:	8b020842 	add	x2, x2, x2, lsl #2
    b3b4:	d37df042 	lsl	x2, x2, #3
    b3b8:	8b020060 	add	x0, x3, x2
    b3bc:	f9401017 	ldr	x23, [x0, #32]
    b3c0:	b4000257 	cbz	x23, b408 <f0+0x1618>
    b3c4:	38626862 	ldrb	w2, [x3, x2]
    b3c8:	7100085f 	cmp	w2, #0x2
    b3cc:	54007300 	b.eq	c22c <f0+0x243c>  // b.none
    b3d0:	7100045f 	cmp	w2, #0x1
    b3d4:	540001a1 	b.ne	b408 <f0+0x1618>  // b.any
    b3d8:	29430002 	ldp	w2, w0, [x0, #24]
    b3dc:	92403c21 	and	x1, x1, #0xffff
    b3e0:	9b027c21 	mul	x1, x1, x2
    b3e4:	d360fc21 	lsr	x1, x1, #32
    b3e8:	eb00003f 	cmp	x1, x0
    b3ec:	540000e2 	b.cs	b408 <f0+0x1618>  // b.hs, b.nlast
    b3f0:	8b0102f7 	add	x23, x23, x1
    b3f4:	394002e0 	ldrb	w0, [x23]
    b3f8:	7103fc1f 	cmp	w0, #0xff
    b3fc:	54007c60 	b.eq	c388 <f0+0x2598>  // b.none
    b400:	52800020 	mov	w0, #0x1                   	// #1
    b404:	390002e0 	strb	w0, [x23]
    b408:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b40c:	9114a3e1 	add	x1, sp, #0x528
    b410:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	f90297e2 	str	x2, [sp, #1320]
    b41c:	f9029bf5 	str	x21, [sp, #1328]
    b420:	97ffe7e0 	bl	53a0 <fwp_data.part.0.constprop.0>
    b424:	91154283 	add	x3, x20, #0x550
    b428:	aa0003f7 	mov	x23, x0
    b42c:	f949d861 	ldr	x1, [x3, #5040]
    b430:	f949ec60 	ldr	x0, [x3, #5080]
    b434:	cb0102e1 	sub	x1, x23, x1
    b438:	eb00403f 	cmp	x1, x0, lsl #16
    b43c:	54000322 	b.cs	b4a0 <f0+0x16b0>  // b.hs, b.nlast
    b440:	d350fc22 	lsr	x2, x1, #16
    b444:	f949fc63 	ldr	x3, [x3, #5112]
    b448:	8b020842 	add	x2, x2, x2, lsl #2
    b44c:	d37df042 	lsl	x2, x2, #3
    b450:	8b020060 	add	x0, x3, x2
    b454:	f9401015 	ldr	x21, [x0, #32]
    b458:	b4000255 	cbz	x21, b4a0 <f0+0x16b0>
    b45c:	38626862 	ldrb	w2, [x3, x2]
    b460:	7100085f 	cmp	w2, #0x2
    b464:	54006de0 	b.eq	c220 <f0+0x2430>  // b.none
    b468:	7100045f 	cmp	w2, #0x1
    b46c:	540001a1 	b.ne	b4a0 <f0+0x16b0>  // b.any
    b470:	29430002 	ldp	w2, w0, [x0, #24]
    b474:	92403c21 	and	x1, x1, #0xffff
    b478:	9b027c21 	mul	x1, x1, x2
    b47c:	d360fc21 	lsr	x1, x1, #32
    b480:	eb00003f 	cmp	x1, x0
    b484:	540000e2 	b.cs	b4a0 <f0+0x16b0>  // b.hs, b.nlast
    b488:	8b0102b5 	add	x21, x21, x1
    b48c:	394002a0 	ldrb	w0, [x21]
    b490:	7103fc1f 	cmp	w0, #0xff
    b494:	54007800 	b.eq	c394 <f0+0x25a4>  // b.none
    b498:	52800020 	mov	w0, #0x1                   	// #1
    b49c:	390002a0 	strb	w0, [x21]
    b4a0:	9114e3e1 	add	x1, sp, #0x538
    b4a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b4a8:	52800020 	mov	w0, #0x1                   	// #1
    b4ac:	f9029ff5 	str	x21, [sp, #1336]
    b4b0:	f902a3f7 	str	x23, [sp, #1344]
    b4b4:	97ffe7bb 	bl	53a0 <fwp_data.part.0.constprop.0>
    b4b8:	97ffe827 	bl	5554 <fwp_rc_fresh>
    b4bc:	aa0003e2 	mov	x2, x0
    b4c0:	911523e1 	add	x1, sp, #0x548
    b4c4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b4c8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	f902a7f7 	str	x23, [sp, #1352]
    b4d4:	f902abe2 	str	x2, [sp, #1360]
    b4d8:	97ffe7b2 	bl	53a0 <fwp_data.part.0.constprop.0>
    b4dc:	97ffe81e 	bl	5554 <fwp_rc_fresh>
    b4e0:	aa0003e2 	mov	x2, x0
    b4e4:	911563e1 	add	x1, sp, #0x558
    b4e8:	52800020 	mov	w0, #0x1                   	// #1
    b4ec:	f902aff5 	str	x21, [sp, #1368]
    b4f0:	f902b3e2 	str	x2, [sp, #1376]
    b4f4:	97ffe7ab 	bl	53a0 <fwp_data.part.0.constprop.0>
    b4f8:	97ffe817 	bl	5554 <fwp_rc_fresh>
    b4fc:	aa0003e2 	mov	x2, x0
    b500:	9115a3e1 	add	x1, sp, #0x568
    b504:	52800020 	mov	w0, #0x1                   	// #1
    b508:	f902b7f7 	str	x23, [sp, #1384]
    b50c:	f902bbe2 	str	x2, [sp, #1392]
    b510:	97ffe7a4 	bl	53a0 <fwp_data.part.0.constprop.0>
    b514:	97ffe810 	bl	5554 <fwp_rc_fresh>
    b518:	aa0003e2 	mov	x2, x0
    b51c:	9115e3e1 	add	x1, sp, #0x578
    b520:	52800020 	mov	w0, #0x1                   	// #1
    b524:	f902bff5 	str	x21, [sp, #1400]
    b528:	f902c3e2 	str	x2, [sp, #1408]
    b52c:	97ffe79d 	bl	53a0 <fwp_data.part.0.constprop.0>
    b530:	97ffe809 	bl	5554 <fwp_rc_fresh>
    b534:	aa0003e2 	mov	x2, x0
    b538:	911623e1 	add	x1, sp, #0x588
    b53c:	52800020 	mov	w0, #0x1                   	// #1
    b540:	f902c7f7 	str	x23, [sp, #1416]
    b544:	f902cbe2 	str	x2, [sp, #1424]
    b548:	97ffe796 	bl	53a0 <fwp_data.part.0.constprop.0>
    b54c:	97ffe802 	bl	5554 <fwp_rc_fresh>
    b550:	aa0003e2 	mov	x2, x0
    b554:	911663e1 	add	x1, sp, #0x598
    b558:	52800020 	mov	w0, #0x1                   	// #1
    b55c:	f902cff5 	str	x21, [sp, #1432]
    b560:	f902d3e2 	str	x2, [sp, #1440]
    b564:	97ffe78f 	bl	53a0 <fwp_data.part.0.constprop.0>
    b568:	97ffe7fb 	bl	5554 <fwp_rc_fresh>
    b56c:	aa0003e2 	mov	x2, x0
    b570:	9116a3e1 	add	x1, sp, #0x5a8
    b574:	52800020 	mov	w0, #0x1                   	// #1
    b578:	f902d7f7 	str	x23, [sp, #1448]
    b57c:	f902dbe2 	str	x2, [sp, #1456]
    b580:	97ffe788 	bl	53a0 <fwp_data.part.0.constprop.0>
    b584:	97ffe7f4 	bl	5554 <fwp_rc_fresh>
    b588:	aa0003e2 	mov	x2, x0
    b58c:	9116e3e1 	add	x1, sp, #0x5b8
    b590:	52800020 	mov	w0, #0x1                   	// #1
    b594:	f902dff5 	str	x21, [sp, #1464]
    b598:	f902e3e2 	str	x2, [sp, #1472]
    b59c:	97ffe781 	bl	53a0 <fwp_data.part.0.constprop.0>
    b5a0:	91154283 	add	x3, x20, #0x550
    b5a4:	aa0003f5 	mov	x21, x0
    b5a8:	f949d861 	ldr	x1, [x3, #5040]
    b5ac:	f949ec60 	ldr	x0, [x3, #5080]
    b5b0:	cb0102a1 	sub	x1, x21, x1
    b5b4:	eb00403f 	cmp	x1, x0, lsl #16
    b5b8:	54000322 	b.cs	b61c <f0+0x182c>  // b.hs, b.nlast
    b5bc:	d350fc22 	lsr	x2, x1, #16
    b5c0:	f949fc63 	ldr	x3, [x3, #5112]
    b5c4:	8b020842 	add	x2, x2, x2, lsl #2
    b5c8:	d37df042 	lsl	x2, x2, #3
    b5cc:	8b020060 	add	x0, x3, x2
    b5d0:	f9401017 	ldr	x23, [x0, #32]
    b5d4:	b4000257 	cbz	x23, b61c <f0+0x182c>
    b5d8:	38626862 	ldrb	w2, [x3, x2]
    b5dc:	7100085f 	cmp	w2, #0x2
    b5e0:	540061a0 	b.eq	c214 <f0+0x2424>  // b.none
    b5e4:	7100045f 	cmp	w2, #0x1
    b5e8:	540001a1 	b.ne	b61c <f0+0x182c>  // b.any
    b5ec:	29430002 	ldp	w2, w0, [x0, #24]
    b5f0:	92403c21 	and	x1, x1, #0xffff
    b5f4:	9b027c21 	mul	x1, x1, x2
    b5f8:	d360fc21 	lsr	x1, x1, #32
    b5fc:	eb00003f 	cmp	x1, x0
    b600:	540000e2 	b.cs	b61c <f0+0x182c>  // b.hs, b.nlast
    b604:	8b0102f7 	add	x23, x23, x1
    b608:	394002e0 	ldrb	w0, [x23]
    b60c:	7103fc1f 	cmp	w0, #0xff
    b610:	54006c80 	b.eq	c3a0 <f0+0x25b0>  // b.none
    b614:	52800020 	mov	w0, #0x1                   	// #1
    b618:	390002e0 	strb	w0, [x23]
    b61c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b620:	911723e1 	add	x1, sp, #0x5c8
    b624:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b628:	52800020 	mov	w0, #0x1                   	// #1
    b62c:	f902e7e2 	str	x2, [sp, #1480]
    b630:	f902ebf5 	str	x21, [sp, #1488]
    b634:	97ffe75b 	bl	53a0 <fwp_data.part.0.constprop.0>
    b638:	91154283 	add	x3, x20, #0x550
    b63c:	aa0003f5 	mov	x21, x0
    b640:	f949d861 	ldr	x1, [x3, #5040]
    b644:	f949ec60 	ldr	x0, [x3, #5080]
    b648:	cb0102a1 	sub	x1, x21, x1
    b64c:	eb00403f 	cmp	x1, x0, lsl #16
    b650:	54000322 	b.cs	b6b4 <f0+0x18c4>  // b.hs, b.nlast
    b654:	d350fc22 	lsr	x2, x1, #16
    b658:	f949fc63 	ldr	x3, [x3, #5112]
    b65c:	8b020842 	add	x2, x2, x2, lsl #2
    b660:	d37df042 	lsl	x2, x2, #3
    b664:	8b020060 	add	x0, x3, x2
    b668:	f9401017 	ldr	x23, [x0, #32]
    b66c:	b4000257 	cbz	x23, b6b4 <f0+0x18c4>
    b670:	38626862 	ldrb	w2, [x3, x2]
    b674:	7100085f 	cmp	w2, #0x2
    b678:	54005c80 	b.eq	c208 <f0+0x2418>  // b.none
    b67c:	7100045f 	cmp	w2, #0x1
    b680:	540001a1 	b.ne	b6b4 <f0+0x18c4>  // b.any
    b684:	29430002 	ldp	w2, w0, [x0, #24]
    b688:	92403c21 	and	x1, x1, #0xffff
    b68c:	9b027c21 	mul	x1, x1, x2
    b690:	d360fc21 	lsr	x1, x1, #32
    b694:	eb00003f 	cmp	x1, x0
    b698:	540000e2 	b.cs	b6b4 <f0+0x18c4>  // b.hs, b.nlast
    b69c:	8b0102f7 	add	x23, x23, x1
    b6a0:	394002e0 	ldrb	w0, [x23]
    b6a4:	7103fc1f 	cmp	w0, #0xff
    b6a8:	54006820 	b.eq	c3ac <f0+0x25bc>  // b.none
    b6ac:	52800020 	mov	w0, #0x1                   	// #1
    b6b0:	390002e0 	strb	w0, [x23]
    b6b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b6b8:	911763e1 	add	x1, sp, #0x5d8
    b6bc:	52800020 	mov	w0, #0x1                   	// #1
    b6c0:	f902efe2 	str	x2, [sp, #1496]
    b6c4:	f902f3f5 	str	x21, [sp, #1504]
    b6c8:	97ffe736 	bl	53a0 <fwp_data.part.0.constprop.0>
    b6cc:	91154283 	add	x3, x20, #0x550
    b6d0:	aa0003f7 	mov	x23, x0
    b6d4:	f949d861 	ldr	x1, [x3, #5040]
    b6d8:	f949ec60 	ldr	x0, [x3, #5080]
    b6dc:	cb0102e1 	sub	x1, x23, x1
    b6e0:	eb00403f 	cmp	x1, x0, lsl #16
    b6e4:	54000322 	b.cs	b748 <f0+0x1958>  // b.hs, b.nlast
    b6e8:	d350fc22 	lsr	x2, x1, #16
    b6ec:	f949fc63 	ldr	x3, [x3, #5112]
    b6f0:	8b020842 	add	x2, x2, x2, lsl #2
    b6f4:	d37df042 	lsl	x2, x2, #3
    b6f8:	8b020060 	add	x0, x3, x2
    b6fc:	f9401015 	ldr	x21, [x0, #32]
    b700:	b4000255 	cbz	x21, b748 <f0+0x1958>
    b704:	38626862 	ldrb	w2, [x3, x2]
    b708:	7100085f 	cmp	w2, #0x2
    b70c:	54005780 	b.eq	c1fc <f0+0x240c>  // b.none
    b710:	7100045f 	cmp	w2, #0x1
    b714:	540001a1 	b.ne	b748 <f0+0x1958>  // b.any
    b718:	29430002 	ldp	w2, w0, [x0, #24]
    b71c:	92403c21 	and	x1, x1, #0xffff
    b720:	9b027c21 	mul	x1, x1, x2
    b724:	d360fc21 	lsr	x1, x1, #32
    b728:	eb00003f 	cmp	x1, x0
    b72c:	540000e2 	b.cs	b748 <f0+0x1958>  // b.hs, b.nlast
    b730:	8b0102b5 	add	x21, x21, x1
    b734:	394002a0 	ldrb	w0, [x21]
    b738:	7103fc1f 	cmp	w0, #0xff
    b73c:	540063e0 	b.eq	c3b8 <f0+0x25c8>  // b.none
    b740:	52800020 	mov	w0, #0x1                   	// #1
    b744:	390002a0 	strb	w0, [x21]
    b748:	9117a3e1 	add	x1, sp, #0x5e8
    b74c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b750:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b754:	52800020 	mov	w0, #0x1                   	// #1
    b758:	f902f7f5 	str	x21, [sp, #1512]
    b75c:	f902fbf7 	str	x23, [sp, #1520]
    b760:	97ffe710 	bl	53a0 <fwp_data.part.0.constprop.0>
    b764:	97ffe77c 	bl	5554 <fwp_rc_fresh>
    b768:	aa0003e2 	mov	x2, x0
    b76c:	9117e3e1 	add	x1, sp, #0x5f8
    b770:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b774:	52800020 	mov	w0, #0x1                   	// #1
    b778:	f902fff7 	str	x23, [sp, #1528]
    b77c:	f90303e2 	str	x2, [sp, #1536]
    b780:	97ffe708 	bl	53a0 <fwp_data.part.0.constprop.0>
    b784:	97ffe774 	bl	5554 <fwp_rc_fresh>
    b788:	aa0003e2 	mov	x2, x0
    b78c:	911823e1 	add	x1, sp, #0x608
    b790:	52800020 	mov	w0, #0x1                   	// #1
    b794:	f90307f5 	str	x21, [sp, #1544]
    b798:	f9030be2 	str	x2, [sp, #1552]
    b79c:	97ffe701 	bl	53a0 <fwp_data.part.0.constprop.0>
    b7a0:	97ffe76d 	bl	5554 <fwp_rc_fresh>
    b7a4:	aa0003e2 	mov	x2, x0
    b7a8:	911863e1 	add	x1, sp, #0x618
    b7ac:	52800020 	mov	w0, #0x1                   	// #1
    b7b0:	f9030ff7 	str	x23, [sp, #1560]
    b7b4:	f90313e2 	str	x2, [sp, #1568]
    b7b8:	97ffe6fa 	bl	53a0 <fwp_data.part.0.constprop.0>
    b7bc:	97ffe766 	bl	5554 <fwp_rc_fresh>
    b7c0:	aa0003e2 	mov	x2, x0
    b7c4:	9118a3e1 	add	x1, sp, #0x628
    b7c8:	52800020 	mov	w0, #0x1                   	// #1
    b7cc:	f90317f5 	str	x21, [sp, #1576]
    b7d0:	f9031be2 	str	x2, [sp, #1584]
    b7d4:	97ffe6f3 	bl	53a0 <fwp_data.part.0.constprop.0>
    b7d8:	97ffe75f 	bl	5554 <fwp_rc_fresh>
    b7dc:	aa0003e2 	mov	x2, x0
    b7e0:	9118e3e1 	add	x1, sp, #0x638
    b7e4:	52800020 	mov	w0, #0x1                   	// #1
    b7e8:	f9031ff7 	str	x23, [sp, #1592]
    b7ec:	f90323e2 	str	x2, [sp, #1600]
    b7f0:	97ffe6ec 	bl	53a0 <fwp_data.part.0.constprop.0>
    b7f4:	97ffe758 	bl	5554 <fwp_rc_fresh>
    b7f8:	aa0003e2 	mov	x2, x0
    b7fc:	911923e1 	add	x1, sp, #0x648
    b800:	52800020 	mov	w0, #0x1                   	// #1
    b804:	f90327f5 	str	x21, [sp, #1608]
    b808:	f9032be2 	str	x2, [sp, #1616]
    b80c:	97ffe6e5 	bl	53a0 <fwp_data.part.0.constprop.0>
    b810:	91154283 	add	x3, x20, #0x550
    b814:	aa0003f5 	mov	x21, x0
    b818:	f949d861 	ldr	x1, [x3, #5040]
    b81c:	f949ec60 	ldr	x0, [x3, #5080]
    b820:	cb0102a1 	sub	x1, x21, x1
    b824:	eb00403f 	cmp	x1, x0, lsl #16
    b828:	54000322 	b.cs	b88c <f0+0x1a9c>  // b.hs, b.nlast
    b82c:	d350fc22 	lsr	x2, x1, #16
    b830:	f949fc63 	ldr	x3, [x3, #5112]
    b834:	8b020842 	add	x2, x2, x2, lsl #2
    b838:	d37df042 	lsl	x2, x2, #3
    b83c:	8b020060 	add	x0, x3, x2
    b840:	f9401017 	ldr	x23, [x0, #32]
    b844:	b4000257 	cbz	x23, b88c <f0+0x1a9c>
    b848:	38626862 	ldrb	w2, [x3, x2]
    b84c:	7100085f 	cmp	w2, #0x2
    b850:	54004d00 	b.eq	c1f0 <f0+0x2400>  // b.none
    b854:	7100045f 	cmp	w2, #0x1
    b858:	540001a1 	b.ne	b88c <f0+0x1a9c>  // b.any
    b85c:	29430002 	ldp	w2, w0, [x0, #24]
    b860:	92403c21 	and	x1, x1, #0xffff
    b864:	9b027c21 	mul	x1, x1, x2
    b868:	d360fc21 	lsr	x1, x1, #32
    b86c:	eb00003f 	cmp	x1, x0
    b870:	540000e2 	b.cs	b88c <f0+0x1a9c>  // b.hs, b.nlast
    b874:	8b0102f7 	add	x23, x23, x1
    b878:	394002e0 	ldrb	w0, [x23]
    b87c:	7103fc1f 	cmp	w0, #0xff
    b880:	54005a20 	b.eq	c3c4 <f0+0x25d4>  // b.none
    b884:	52800020 	mov	w0, #0x1                   	// #1
    b888:	390002e0 	strb	w0, [x23]
    b88c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b890:	911963e1 	add	x1, sp, #0x658
    b894:	52800020 	mov	w0, #0x1                   	// #1
    b898:	f9032fe2 	str	x2, [sp, #1624]
    b89c:	f90333f5 	str	x21, [sp, #1632]
    b8a0:	97ffe6c0 	bl	53a0 <fwp_data.part.0.constprop.0>
    b8a4:	91154283 	add	x3, x20, #0x550
    b8a8:	aa0003f5 	mov	x21, x0
    b8ac:	f949d861 	ldr	x1, [x3, #5040]
    b8b0:	f949ec60 	ldr	x0, [x3, #5080]
    b8b4:	cb0102a1 	sub	x1, x21, x1
    b8b8:	eb00403f 	cmp	x1, x0, lsl #16
    b8bc:	54000322 	b.cs	b920 <f0+0x1b30>  // b.hs, b.nlast
    b8c0:	d350fc22 	lsr	x2, x1, #16
    b8c4:	f949fc63 	ldr	x3, [x3, #5112]
    b8c8:	8b020842 	add	x2, x2, x2, lsl #2
    b8cc:	d37df042 	lsl	x2, x2, #3
    b8d0:	8b020060 	add	x0, x3, x2
    b8d4:	f9401017 	ldr	x23, [x0, #32]
    b8d8:	b4000257 	cbz	x23, b920 <f0+0x1b30>
    b8dc:	38626862 	ldrb	w2, [x3, x2]
    b8e0:	7100085f 	cmp	w2, #0x2
    b8e4:	54004800 	b.eq	c1e4 <f0+0x23f4>  // b.none
    b8e8:	7100045f 	cmp	w2, #0x1
    b8ec:	540001a1 	b.ne	b920 <f0+0x1b30>  // b.any
    b8f0:	29430002 	ldp	w2, w0, [x0, #24]
    b8f4:	92403c21 	and	x1, x1, #0xffff
    b8f8:	9b027c21 	mul	x1, x1, x2
    b8fc:	d360fc21 	lsr	x1, x1, #32
    b900:	eb00003f 	cmp	x1, x0
    b904:	540000e2 	b.cs	b920 <f0+0x1b30>  // b.hs, b.nlast
    b908:	8b0102f7 	add	x23, x23, x1
    b90c:	394002e0 	ldrb	w0, [x23]
    b910:	7103fc1f 	cmp	w0, #0xff
    b914:	540055e0 	b.eq	c3d0 <f0+0x25e0>  // b.none
    b918:	52800020 	mov	w0, #0x1                   	// #1
    b91c:	390002e0 	strb	w0, [x23]
    b920:	9119a3e1 	add	x1, sp, #0x668
    b924:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b928:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b92c:	52800020 	mov	w0, #0x1                   	// #1
    b930:	f90337f7 	str	x23, [sp, #1640]
    b934:	f9033bf5 	str	x21, [sp, #1648]
    b938:	97ffe69a 	bl	53a0 <fwp_data.part.0.constprop.0>
    b93c:	97ffe706 	bl	5554 <fwp_rc_fresh>
    b940:	aa0003e2 	mov	x2, x0
    b944:	9119e3e1 	add	x1, sp, #0x678
    b948:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b94c:	52800020 	mov	w0, #0x1                   	// #1
    b950:	f9033ff5 	str	x21, [sp, #1656]
    b954:	f90343e2 	str	x2, [sp, #1664]
    b958:	97ffe692 	bl	53a0 <fwp_data.part.0.constprop.0>
    b95c:	97ffe6fe 	bl	5554 <fwp_rc_fresh>
    b960:	aa0003e2 	mov	x2, x0
    b964:	911a23e1 	add	x1, sp, #0x688
    b968:	52800020 	mov	w0, #0x1                   	// #1
    b96c:	f90347f7 	str	x23, [sp, #1672]
    b970:	f9034be2 	str	x2, [sp, #1680]
    b974:	97ffe68b 	bl	53a0 <fwp_data.part.0.constprop.0>
    b978:	97ffe6f7 	bl	5554 <fwp_rc_fresh>
    b97c:	aa0003e2 	mov	x2, x0
    b980:	911a63e1 	add	x1, sp, #0x698
    b984:	52800020 	mov	w0, #0x1                   	// #1
    b988:	f9034ff5 	str	x21, [sp, #1688]
    b98c:	f90353e2 	str	x2, [sp, #1696]
    b990:	97ffe684 	bl	53a0 <fwp_data.part.0.constprop.0>
    b994:	91154283 	add	x3, x20, #0x550
    b998:	aa0003f5 	mov	x21, x0
    b99c:	f949d861 	ldr	x1, [x3, #5040]
    b9a0:	f949ec60 	ldr	x0, [x3, #5080]
    b9a4:	cb0102a1 	sub	x1, x21, x1
    b9a8:	eb00403f 	cmp	x1, x0, lsl #16
    b9ac:	54000322 	b.cs	ba10 <f0+0x1c20>  // b.hs, b.nlast
    b9b0:	d350fc22 	lsr	x2, x1, #16
    b9b4:	f949fc63 	ldr	x3, [x3, #5112]
    b9b8:	8b020842 	add	x2, x2, x2, lsl #2
    b9bc:	d37df042 	lsl	x2, x2, #3
    b9c0:	8b020060 	add	x0, x3, x2
    b9c4:	f9401017 	ldr	x23, [x0, #32]
    b9c8:	b4000257 	cbz	x23, ba10 <f0+0x1c20>
    b9cc:	38626862 	ldrb	w2, [x3, x2]
    b9d0:	7100085f 	cmp	w2, #0x2
    b9d4:	54004020 	b.eq	c1d8 <f0+0x23e8>  // b.none
    b9d8:	7100045f 	cmp	w2, #0x1
    b9dc:	540001a1 	b.ne	ba10 <f0+0x1c20>  // b.any
    b9e0:	29430002 	ldp	w2, w0, [x0, #24]
    b9e4:	92403c21 	and	x1, x1, #0xffff
    b9e8:	9b027c21 	mul	x1, x1, x2
    b9ec:	d360fc21 	lsr	x1, x1, #32
    b9f0:	eb00003f 	cmp	x1, x0
    b9f4:	540000e2 	b.cs	ba10 <f0+0x1c20>  // b.hs, b.nlast
    b9f8:	8b0102f7 	add	x23, x23, x1
    b9fc:	394002e0 	ldrb	w0, [x23]
    ba00:	7103fc1f 	cmp	w0, #0xff
    ba04:	54004ec0 	b.eq	c3dc <f0+0x25ec>  // b.none
    ba08:	52800020 	mov	w0, #0x1                   	// #1
    ba0c:	390002e0 	strb	w0, [x23]
    ba10:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ba14:	911aa3e1 	add	x1, sp, #0x6a8
    ba18:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ba1c:	52800020 	mov	w0, #0x1                   	// #1
    ba20:	f90357e2 	str	x2, [sp, #1704]
    ba24:	f9035bf5 	str	x21, [sp, #1712]
    ba28:	97ffe65e 	bl	53a0 <fwp_data.part.0.constprop.0>
    ba2c:	97ffe6ca 	bl	5554 <fwp_rc_fresh>
    ba30:	aa0003e2 	mov	x2, x0
    ba34:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ba38:	911ae3e1 	add	x1, sp, #0x6b8
    ba3c:	52800020 	mov	w0, #0x1                   	// #1
    ba40:	f9035fe3 	str	x3, [sp, #1720]
    ba44:	f90363e2 	str	x2, [sp, #1728]
    ba48:	97ffe656 	bl	53a0 <fwp_data.part.0.constprop.0>
    ba4c:	91154283 	add	x3, x20, #0x550
    ba50:	aa0003f5 	mov	x21, x0
    ba54:	f949d861 	ldr	x1, [x3, #5040]
    ba58:	f949ec60 	ldr	x0, [x3, #5080]
    ba5c:	cb0102a1 	sub	x1, x21, x1
    ba60:	eb00403f 	cmp	x1, x0, lsl #16
    ba64:	54000322 	b.cs	bac8 <f0+0x1cd8>  // b.hs, b.nlast
    ba68:	d350fc22 	lsr	x2, x1, #16
    ba6c:	f949fc63 	ldr	x3, [x3, #5112]
    ba70:	8b020842 	add	x2, x2, x2, lsl #2
    ba74:	d37df042 	lsl	x2, x2, #3
    ba78:	8b020060 	add	x0, x3, x2
    ba7c:	f9401017 	ldr	x23, [x0, #32]
    ba80:	b4000257 	cbz	x23, bac8 <f0+0x1cd8>
    ba84:	38626862 	ldrb	w2, [x3, x2]
    ba88:	7100085f 	cmp	w2, #0x2
    ba8c:	54003a00 	b.eq	c1cc <f0+0x23dc>  // b.none
    ba90:	7100045f 	cmp	w2, #0x1
    ba94:	540001a1 	b.ne	bac8 <f0+0x1cd8>  // b.any
    ba98:	29430002 	ldp	w2, w0, [x0, #24]
    ba9c:	92403c21 	and	x1, x1, #0xffff
    baa0:	9b027c21 	mul	x1, x1, x2
    baa4:	d360fc21 	lsr	x1, x1, #32
    baa8:	eb00003f 	cmp	x1, x0
    baac:	540000e2 	b.cs	bac8 <f0+0x1cd8>  // b.hs, b.nlast
    bab0:	8b0102f7 	add	x23, x23, x1
    bab4:	394002e0 	ldrb	w0, [x23]
    bab8:	7103fc1f 	cmp	w0, #0xff
    babc:	54004960 	b.eq	c3e8 <f0+0x25f8>  // b.none
    bac0:	52800020 	mov	w0, #0x1                   	// #1
    bac4:	390002e0 	strb	w0, [x23]
    bac8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bacc:	911b23e1 	add	x1, sp, #0x6c8
    bad0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bad4:	52800020 	mov	w0, #0x1                   	// #1
    bad8:	f90367e2 	str	x2, [sp, #1736]
    badc:	f9036bf5 	str	x21, [sp, #1744]
    bae0:	97ffe630 	bl	53a0 <fwp_data.part.0.constprop.0>
    bae4:	91154283 	add	x3, x20, #0x550
    bae8:	aa0003f5 	mov	x21, x0
    baec:	f949d861 	ldr	x1, [x3, #5040]
    baf0:	f949ec60 	ldr	x0, [x3, #5080]
    baf4:	cb0102a1 	sub	x1, x21, x1
    baf8:	eb00403f 	cmp	x1, x0, lsl #16
    bafc:	54000322 	b.cs	bb60 <f0+0x1d70>  // b.hs, b.nlast
    bb00:	d350fc22 	lsr	x2, x1, #16
    bb04:	f949fc63 	ldr	x3, [x3, #5112]
    bb08:	8b020842 	add	x2, x2, x2, lsl #2
    bb0c:	d37df042 	lsl	x2, x2, #3
    bb10:	8b020060 	add	x0, x3, x2
    bb14:	f9401017 	ldr	x23, [x0, #32]
    bb18:	b4000257 	cbz	x23, bb60 <f0+0x1d70>
    bb1c:	38626862 	ldrb	w2, [x3, x2]
    bb20:	7100085f 	cmp	w2, #0x2
    bb24:	540034e0 	b.eq	c1c0 <f0+0x23d0>  // b.none
    bb28:	7100045f 	cmp	w2, #0x1
    bb2c:	540001a1 	b.ne	bb60 <f0+0x1d70>  // b.any
    bb30:	29430002 	ldp	w2, w0, [x0, #24]
    bb34:	92403c21 	and	x1, x1, #0xffff
    bb38:	9b027c21 	mul	x1, x1, x2
    bb3c:	d360fc21 	lsr	x1, x1, #32
    bb40:	eb00003f 	cmp	x1, x0
    bb44:	540000e2 	b.cs	bb60 <f0+0x1d70>  // b.hs, b.nlast
    bb48:	8b0102f7 	add	x23, x23, x1
    bb4c:	394002e0 	ldrb	w0, [x23]
    bb50:	7103fc1f 	cmp	w0, #0xff
    bb54:	54004500 	b.eq	c3f4 <f0+0x2604>  // b.none
    bb58:	52800020 	mov	w0, #0x1                   	// #1
    bb5c:	390002e0 	strb	w0, [x23]
    bb60:	911b63e1 	add	x1, sp, #0x6d8
    bb64:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bb68:	52800020 	mov	w0, #0x1                   	// #1
    bb6c:	f9036ff7 	str	x23, [sp, #1752]
    bb70:	f90373f5 	str	x21, [sp, #1760]
    bb74:	97ffe60b 	bl	53a0 <fwp_data.part.0.constprop.0>
    bb78:	97ffe677 	bl	5554 <fwp_rc_fresh>
    bb7c:	aa0003e2 	mov	x2, x0
    bb80:	911ba3e1 	add	x1, sp, #0x6e8
    bb84:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bb88:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bb8c:	52800020 	mov	w0, #0x1                   	// #1
    bb90:	f90377f5 	str	x21, [sp, #1768]
    bb94:	f9037be2 	str	x2, [sp, #1776]
    bb98:	97ffe602 	bl	53a0 <fwp_data.part.0.constprop.0>
    bb9c:	97ffe66e 	bl	5554 <fwp_rc_fresh>
    bba0:	aa0003e2 	mov	x2, x0
    bba4:	911be3e1 	add	x1, sp, #0x6f8
    bba8:	52800020 	mov	w0, #0x1                   	// #1
    bbac:	f9037ff7 	str	x23, [sp, #1784]
    bbb0:	f90383e2 	str	x2, [sp, #1792]
    bbb4:	97ffe5fb 	bl	53a0 <fwp_data.part.0.constprop.0>
    bbb8:	97ffe667 	bl	5554 <fwp_rc_fresh>
    bbbc:	aa0003e2 	mov	x2, x0
    bbc0:	911c23e1 	add	x1, sp, #0x708
    bbc4:	52800020 	mov	w0, #0x1                   	// #1
    bbc8:	f90387f5 	str	x21, [sp, #1800]
    bbcc:	f9038be2 	str	x2, [sp, #1808]
    bbd0:	97ffe5f4 	bl	53a0 <fwp_data.part.0.constprop.0>
    bbd4:	97ffe660 	bl	5554 <fwp_rc_fresh>
    bbd8:	aa0003e2 	mov	x2, x0
    bbdc:	911c63e1 	add	x1, sp, #0x718
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	f9038ff7 	str	x23, [sp, #1816]
    bbe8:	f90393e2 	str	x2, [sp, #1824]
    bbec:	97ffe5ed 	bl	53a0 <fwp_data.part.0.constprop.0>
    bbf0:	91154283 	add	x3, x20, #0x550
    bbf4:	aa0003f5 	mov	x21, x0
    bbf8:	f949d861 	ldr	x1, [x3, #5040]
    bbfc:	f949ec60 	ldr	x0, [x3, #5080]
    bc00:	cb0102a1 	sub	x1, x21, x1
    bc04:	eb00403f 	cmp	x1, x0, lsl #16
    bc08:	54000322 	b.cs	bc6c <f0+0x1e7c>  // b.hs, b.nlast
    bc0c:	d350fc22 	lsr	x2, x1, #16
    bc10:	f949fc63 	ldr	x3, [x3, #5112]
    bc14:	8b020842 	add	x2, x2, x2, lsl #2
    bc18:	d37df042 	lsl	x2, x2, #3
    bc1c:	8b020060 	add	x0, x3, x2
    bc20:	f9401017 	ldr	x23, [x0, #32]
    bc24:	b4000257 	cbz	x23, bc6c <f0+0x1e7c>
    bc28:	38626862 	ldrb	w2, [x3, x2]
    bc2c:	7100085f 	cmp	w2, #0x2
    bc30:	54002c20 	b.eq	c1b4 <f0+0x23c4>  // b.none
    bc34:	7100045f 	cmp	w2, #0x1
    bc38:	540001a1 	b.ne	bc6c <f0+0x1e7c>  // b.any
    bc3c:	29430002 	ldp	w2, w0, [x0, #24]
    bc40:	92403c21 	and	x1, x1, #0xffff
    bc44:	9b027c21 	mul	x1, x1, x2
    bc48:	d360fc21 	lsr	x1, x1, #32
    bc4c:	eb00003f 	cmp	x1, x0
    bc50:	540000e2 	b.cs	bc6c <f0+0x1e7c>  // b.hs, b.nlast
    bc54:	8b0102f7 	add	x23, x23, x1
    bc58:	394002e0 	ldrb	w0, [x23]
    bc5c:	7103fc1f 	cmp	w0, #0xff
    bc60:	54003d00 	b.eq	c400 <f0+0x2610>  // b.none
    bc64:	52800020 	mov	w0, #0x1                   	// #1
    bc68:	390002e0 	strb	w0, [x23]
    bc6c:	911ca3e1 	add	x1, sp, #0x728
    bc70:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bc74:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bc78:	52800020 	mov	w0, #0x1                   	// #1
    bc7c:	f90397f7 	str	x23, [sp, #1832]
    bc80:	f9039bf5 	str	x21, [sp, #1840]
    bc84:	97ffe5c7 	bl	53a0 <fwp_data.part.0.constprop.0>
    bc88:	97ffe633 	bl	5554 <fwp_rc_fresh>
    bc8c:	aa0003e2 	mov	x2, x0
    bc90:	911ce3e1 	add	x1, sp, #0x738
    bc94:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bc98:	52800020 	mov	w0, #0x1                   	// #1
    bc9c:	f9039ff5 	str	x21, [sp, #1848]
    bca0:	f903a3e2 	str	x2, [sp, #1856]
    bca4:	97ffe5bf 	bl	53a0 <fwp_data.part.0.constprop.0>
    bca8:	97ffe62b 	bl	5554 <fwp_rc_fresh>
    bcac:	aa0003e2 	mov	x2, x0
    bcb0:	911d23e1 	add	x1, sp, #0x748
    bcb4:	52800020 	mov	w0, #0x1                   	// #1
    bcb8:	f903a7f7 	str	x23, [sp, #1864]
    bcbc:	f903abe2 	str	x2, [sp, #1872]
    bcc0:	97ffe5b8 	bl	53a0 <fwp_data.part.0.constprop.0>
    bcc4:	97ffe624 	bl	5554 <fwp_rc_fresh>
    bcc8:	aa0003e2 	mov	x2, x0
    bccc:	911d63e1 	add	x1, sp, #0x758
    bcd0:	52800020 	mov	w0, #0x1                   	// #1
    bcd4:	f903aff5 	str	x21, [sp, #1880]
    bcd8:	f903b3e2 	str	x2, [sp, #1888]
    bcdc:	97ffe5b1 	bl	53a0 <fwp_data.part.0.constprop.0>
    bce0:	91154283 	add	x3, x20, #0x550
    bce4:	aa0003f5 	mov	x21, x0
    bce8:	f949d861 	ldr	x1, [x3, #5040]
    bcec:	f949ec60 	ldr	x0, [x3, #5080]
    bcf0:	cb0102a1 	sub	x1, x21, x1
    bcf4:	eb00403f 	cmp	x1, x0, lsl #16
    bcf8:	54000322 	b.cs	bd5c <f0+0x1f6c>  // b.hs, b.nlast
    bcfc:	d350fc22 	lsr	x2, x1, #16
    bd00:	f949fc63 	ldr	x3, [x3, #5112]
    bd04:	8b020842 	add	x2, x2, x2, lsl #2
    bd08:	d37df042 	lsl	x2, x2, #3
    bd0c:	8b020060 	add	x0, x3, x2
    bd10:	f9401017 	ldr	x23, [x0, #32]
    bd14:	b4000257 	cbz	x23, bd5c <f0+0x1f6c>
    bd18:	38626862 	ldrb	w2, [x3, x2]
    bd1c:	7100085f 	cmp	w2, #0x2
    bd20:	54002440 	b.eq	c1a8 <f0+0x23b8>  // b.none
    bd24:	7100045f 	cmp	w2, #0x1
    bd28:	540001a1 	b.ne	bd5c <f0+0x1f6c>  // b.any
    bd2c:	29430002 	ldp	w2, w0, [x0, #24]
    bd30:	92403c21 	and	x1, x1, #0xffff
    bd34:	9b027c21 	mul	x1, x1, x2
    bd38:	d360fc21 	lsr	x1, x1, #32
    bd3c:	eb00003f 	cmp	x1, x0
    bd40:	540000e2 	b.cs	bd5c <f0+0x1f6c>  // b.hs, b.nlast
    bd44:	8b0102f7 	add	x23, x23, x1
    bd48:	394002e0 	ldrb	w0, [x23]
    bd4c:	7103fc1f 	cmp	w0, #0xff
    bd50:	540035e0 	b.eq	c40c <f0+0x261c>  // b.none
    bd54:	52800020 	mov	w0, #0x1                   	// #1
    bd58:	390002e0 	strb	w0, [x23]
    bd5c:	911da3e1 	add	x1, sp, #0x768
    bd60:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd64:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd68:	52800020 	mov	w0, #0x1                   	// #1
    bd6c:	f903b7f7 	str	x23, [sp, #1896]
    bd70:	f903bbf5 	str	x21, [sp, #1904]
    bd74:	97ffe58b 	bl	53a0 <fwp_data.part.0.constprop.0>
    bd78:	97ffe5f7 	bl	5554 <fwp_rc_fresh>
    bd7c:	aa0003e2 	mov	x2, x0
    bd80:	911de3e1 	add	x1, sp, #0x778
    bd84:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd88:	52800020 	mov	w0, #0x1                   	// #1
    bd8c:	f903bff5 	str	x21, [sp, #1912]
    bd90:	f903c3e2 	str	x2, [sp, #1920]
    bd94:	97ffe583 	bl	53a0 <fwp_data.part.0.constprop.0>
    bd98:	97ffe5ef 	bl	5554 <fwp_rc_fresh>
    bd9c:	aa0003e2 	mov	x2, x0
    bda0:	911e23e1 	add	x1, sp, #0x788
    bda4:	52800020 	mov	w0, #0x1                   	// #1
    bda8:	f903c7f7 	str	x23, [sp, #1928]
    bdac:	f903cbe2 	str	x2, [sp, #1936]
    bdb0:	97ffe57c 	bl	53a0 <fwp_data.part.0.constprop.0>
    bdb4:	97ffe5e8 	bl	5554 <fwp_rc_fresh>
    bdb8:	aa0003e2 	mov	x2, x0
    bdbc:	911e63e1 	add	x1, sp, #0x798
    bdc0:	52800020 	mov	w0, #0x1                   	// #1
    bdc4:	f903cff5 	str	x21, [sp, #1944]
    bdc8:	f903d3e2 	str	x2, [sp, #1952]
    bdcc:	97ffe575 	bl	53a0 <fwp_data.part.0.constprop.0>
    bdd0:	97ffe5e1 	bl	5554 <fwp_rc_fresh>
    bdd4:	aa0003e2 	mov	x2, x0
    bdd8:	911ea3e1 	add	x1, sp, #0x7a8
    bddc:	52800020 	mov	w0, #0x1                   	// #1
    bde0:	f903d7f7 	str	x23, [sp, #1960]
    bde4:	f903dbe2 	str	x2, [sp, #1968]
    bde8:	97ffe56e 	bl	53a0 <fwp_data.part.0.constprop.0>
    bdec:	97ffe5da 	bl	5554 <fwp_rc_fresh>
    bdf0:	aa0003e2 	mov	x2, x0
    bdf4:	911ee3e1 	add	x1, sp, #0x7b8
    bdf8:	52800020 	mov	w0, #0x1                   	// #1
    bdfc:	f903dff5 	str	x21, [sp, #1976]
    be00:	f903e3e2 	str	x2, [sp, #1984]
    be04:	97ffe567 	bl	53a0 <fwp_data.part.0.constprop.0>
    be08:	91154283 	add	x3, x20, #0x550
    be0c:	aa0003f5 	mov	x21, x0
    be10:	f949d861 	ldr	x1, [x3, #5040]
    be14:	f949ec60 	ldr	x0, [x3, #5080]
    be18:	cb0102a1 	sub	x1, x21, x1
    be1c:	eb00403f 	cmp	x1, x0, lsl #16
    be20:	54000322 	b.cs	be84 <f0+0x2094>  // b.hs, b.nlast
    be24:	d350fc22 	lsr	x2, x1, #16
    be28:	f949fc63 	ldr	x3, [x3, #5112]
    be2c:	8b020842 	add	x2, x2, x2, lsl #2
    be30:	d37df042 	lsl	x2, x2, #3
    be34:	8b020060 	add	x0, x3, x2
    be38:	f9401017 	ldr	x23, [x0, #32]
    be3c:	b4000257 	cbz	x23, be84 <f0+0x2094>
    be40:	38626862 	ldrb	w2, [x3, x2]
    be44:	7100085f 	cmp	w2, #0x2
    be48:	54001aa0 	b.eq	c19c <f0+0x23ac>  // b.none
    be4c:	7100045f 	cmp	w2, #0x1
    be50:	540001a1 	b.ne	be84 <f0+0x2094>  // b.any
    be54:	29430002 	ldp	w2, w0, [x0, #24]
    be58:	92403c21 	and	x1, x1, #0xffff
    be5c:	9b027c21 	mul	x1, x1, x2
    be60:	d360fc21 	lsr	x1, x1, #32
    be64:	eb00003f 	cmp	x1, x0
    be68:	540000e2 	b.cs	be84 <f0+0x2094>  // b.hs, b.nlast
    be6c:	8b0102f7 	add	x23, x23, x1
    be70:	394002e0 	ldrb	w0, [x23]
    be74:	7103fc1f 	cmp	w0, #0xff
    be78:	54002d00 	b.eq	c418 <f0+0x2628>  // b.none
    be7c:	52800020 	mov	w0, #0x1                   	// #1
    be80:	390002e0 	strb	w0, [x23]
    be84:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be88:	91154294 	add	x20, x20, #0x550
    be8c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be90:	911f23e1 	add	x1, sp, #0x7c8
    be94:	52800020 	mov	w0, #0x1                   	// #1
    be98:	f903e7e2 	str	x2, [sp, #1992]
    be9c:	f903ebf5 	str	x21, [sp, #2000]
    bea0:	97ffe540 	bl	53a0 <fwp_data.part.0.constprop.0>
    bea4:	f949da81 	ldr	x1, [x20, #5040]
    bea8:	aa0003f7 	mov	x23, x0
    beac:	f949ee80 	ldr	x0, [x20, #5080]
    beb0:	cb0102e1 	sub	x1, x23, x1
    beb4:	eb00403f 	cmp	x1, x0, lsl #16
    beb8:	54000322 	b.cs	bf1c <f0+0x212c>  // b.hs, b.nlast
    bebc:	d350fc22 	lsr	x2, x1, #16
    bec0:	f949fe83 	ldr	x3, [x20, #5112]
    bec4:	8b020842 	add	x2, x2, x2, lsl #2
    bec8:	d37df042 	lsl	x2, x2, #3
    becc:	8b020060 	add	x0, x3, x2
    bed0:	f9401014 	ldr	x20, [x0, #32]
    bed4:	b4000254 	cbz	x20, bf1c <f0+0x212c>
    bed8:	38626862 	ldrb	w2, [x3, x2]
    bedc:	7100085f 	cmp	w2, #0x2
    bee0:	54001580 	b.eq	c190 <f0+0x23a0>  // b.none
    bee4:	7100045f 	cmp	w2, #0x1
    bee8:	540001a1 	b.ne	bf1c <f0+0x212c>  // b.any
    beec:	29430002 	ldp	w2, w0, [x0, #24]
    bef0:	92403c21 	and	x1, x1, #0xffff
    bef4:	9b027c21 	mul	x1, x1, x2
    bef8:	d360fc21 	lsr	x1, x1, #32
    befc:	eb00003f 	cmp	x1, x0
    bf00:	540000e2 	b.cs	bf1c <f0+0x212c>  // b.hs, b.nlast
    bf04:	8b010294 	add	x20, x20, x1
    bf08:	39400280 	ldrb	w0, [x20]
    bf0c:	7103fc1f 	cmp	w0, #0xff
    bf10:	54001a00 	b.eq	c250 <f0+0x2460>  // b.none
    bf14:	52800020 	mov	w0, #0x1                   	// #1
    bf18:	39000280 	strb	w0, [x20]
    bf1c:	911f63e1 	add	x1, sp, #0x7d8
    bf20:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bf24:	52800020 	mov	w0, #0x1                   	// #1
    bf28:	f903eff5 	str	x21, [sp, #2008]
    bf2c:	f903f3f7 	str	x23, [sp, #2016]
    bf30:	97ffe51c 	bl	53a0 <fwp_data.part.0.constprop.0>
    bf34:	97ffe588 	bl	5554 <fwp_rc_fresh>
    bf38:	aa0003e2 	mov	x2, x0
    bf3c:	911fa3e1 	add	x1, sp, #0x7e8
    bf40:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    bf44:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	f903f7f4 	str	x20, [sp, #2024]
    bf50:	f903fbe2 	str	x2, [sp, #2032]
    bf54:	97ffe513 	bl	53a0 <fwp_data.part.0.constprop.0>
    bf58:	97ffe57f 	bl	5554 <fwp_rc_fresh>
    bf5c:	aa0003e2 	mov	x2, x0
    bf60:	911fe3e1 	add	x1, sp, #0x7f8
    bf64:	52800020 	mov	w0, #0x1                   	// #1
    bf68:	f903fff5 	str	x21, [sp, #2040]
    bf6c:	f90403e2 	str	x2, [sp, #2048]
    bf70:	97ffe50c 	bl	53a0 <fwp_data.part.0.constprop.0>
    bf74:	97ffe578 	bl	5554 <fwp_rc_fresh>
    bf78:	aa0003e2 	mov	x2, x0
    bf7c:	912023e1 	add	x1, sp, #0x808
    bf80:	52800020 	mov	w0, #0x1                   	// #1
    bf84:	f90407f4 	str	x20, [sp, #2056]
    bf88:	f9040be2 	str	x2, [sp, #2064]
    bf8c:	97ffe505 	bl	53a0 <fwp_data.part.0.constprop.0>
    bf90:	97ffe571 	bl	5554 <fwp_rc_fresh>
    bf94:	aa0003e2 	mov	x2, x0
    bf98:	912063e1 	add	x1, sp, #0x818
    bf9c:	52800020 	mov	w0, #0x1                   	// #1
    bfa0:	f9040ff5 	str	x21, [sp, #2072]
    bfa4:	f90413e2 	str	x2, [sp, #2080]
    bfa8:	97ffe4fe 	bl	53a0 <fwp_data.part.0.constprop.0>
    bfac:	97ffe56a 	bl	5554 <fwp_rc_fresh>
    bfb0:	aa0003e2 	mov	x2, x0
    bfb4:	9120a3e1 	add	x1, sp, #0x828
    bfb8:	52800020 	mov	w0, #0x1                   	// #1
    bfbc:	f90417f4 	str	x20, [sp, #2088]
    bfc0:	f9041be2 	str	x2, [sp, #2096]
    bfc4:	97ffe4f7 	bl	53a0 <fwp_data.part.0.constprop.0>
    bfc8:	97ffe563 	bl	5554 <fwp_rc_fresh>
    bfcc:	aa0003e2 	mov	x2, x0
    bfd0:	9120e3e1 	add	x1, sp, #0x838
    bfd4:	52800020 	mov	w0, #0x1                   	// #1
    bfd8:	f9041ff5 	str	x21, [sp, #2104]
    bfdc:	f90423e2 	str	x2, [sp, #2112]
    bfe0:	97ffe4f0 	bl	53a0 <fwp_data.part.0.constprop.0>
    bfe4:	97ffe55c 	bl	5554 <fwp_rc_fresh>
    bfe8:	aa0003e2 	mov	x2, x0
    bfec:	aa1603e1 	mov	x1, x22
    bff0:	52800020 	mov	w0, #0x1                   	// #1
    bff4:	f90427f4 	str	x20, [sp, #2120]
    bff8:	f9042be2 	str	x2, [sp, #2128]
    bffc:	97ffe4e9 	bl	53a0 <fwp_data.part.0.constprop.0>
    c000:	97ffe555 	bl	5554 <fwp_rc_fresh>
    c004:	aa0003f5 	mov	x21, x0
    c008:	aa1303e1 	mov	x1, x19
    c00c:	97fff485 	bl	9220 <fwp_hof0.constprop.0>
    c010:	aa0003f4 	mov	x20, x0
    c014:	aa1503e0 	mov	x0, x21
    c018:	97ffe6aa 	bl	5ac0 <fwp_drop0>
    c01c:	aa1303e0 	mov	x0, x19
    c020:	97ffe6a8 	bl	5ac0 <fwp_drop0>
    c024:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c028:	f947f400 	ldr	x0, [x0, #4072]
    c02c:	f9442fe2 	ldr	x2, [sp, #2136]
    c030:	f9400001 	ldr	x1, [x0]
    c034:	eb010042 	subs	x2, x2, x1
    c038:	d2800001 	mov	x1, #0x0                   	// #0
    c03c:	54001f41 	b.ne	c424 <f0+0x2634>  // b.any
    c040:	912183ff 	add	sp, sp, #0x860
    c044:	aa1403e0 	mov	x0, x20
    c048:	a94153f3 	ldp	x19, x20, [sp, #16]
    c04c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c050:	a94363f7 	ldp	x23, x24, [sp, #48]
    c054:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c058:	a94573fb 	ldp	x27, x28, [sp, #80]
    c05c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c060:	d65f03c0 	ret
    c064:	aa1b03e0 	mov	x0, x27
    c068:	97ffe122 	bl	44f0 <fwp_rc_forget_slot>
    c06c:	17fff7a9 	b	9f10 <f0+0x120>
    c070:	72003c5f 	tst	w2, #0xffff
    c074:	54fef501 	b.ne	9f14 <f0+0x124>  // b.any
    c078:	17fff7a3 	b	9f04 <f0+0x114>
    c07c:	72003c3f 	tst	w1, #0xffff
    c080:	54ff8961 	b.ne	b1ac <f0+0x13bc>  // b.any
    c084:	17fffc45 	b	b198 <f0+0x13a8>
    c088:	72003c3f 	tst	w1, #0xffff
    c08c:	54ff8181 	b.ne	b0bc <f0+0x12cc>  // b.any
    c090:	17fffc06 	b	b0a8 <f0+0x12b8>
    c094:	72003c3f 	tst	w1, #0xffff
    c098:	54ff7621 	b.ne	af5c <f0+0x116c>  // b.any
    c09c:	17fffbab 	b	af48 <f0+0x1158>
    c0a0:	72003c3f 	tst	w1, #0xffff
    c0a4:	54ff69e1 	b.ne	ade0 <f0+0xff0>  // b.any
    c0a8:	17fffb49 	b	adcc <f0+0xfdc>
    c0ac:	72003c3f 	tst	w1, #0xffff
    c0b0:	54ff62e1 	b.ne	ad0c <f0+0xf1c>  // b.any
    c0b4:	17fffb11 	b	acf8 <f0+0xf08>
    c0b8:	72003c3f 	tst	w1, #0xffff
    c0bc:	54ff5b01 	b.ne	ac1c <f0+0xe2c>  // b.any
    c0c0:	17fffad2 	b	ac08 <f0+0xe18>
    c0c4:	72003c3f 	tst	w1, #0xffff
    c0c8:	54ff5601 	b.ne	ab88 <f0+0xd98>  // b.any
    c0cc:	17fffaaa 	b	ab74 <f0+0xd84>
    c0d0:	72003c3f 	tst	w1, #0xffff
    c0d4:	54ff50e1 	b.ne	aaf0 <f0+0xd00>  // b.any
    c0d8:	17fffa81 	b	aadc <f0+0xcec>
    c0dc:	72003c3f 	tst	w1, #0xffff
    c0e0:	54ff0201 	b.ne	a120 <f0+0x330>  // b.any
    c0e4:	17fff80a 	b	a10c <f0+0x31c>
    c0e8:	72003c3f 	tst	w1, #0xffff
    c0ec:	54fefd01 	b.ne	a08c <f0+0x29c>  // b.any
    c0f0:	17fff7e2 	b	a078 <f0+0x288>
    c0f4:	72003c3f 	tst	w1, #0xffff
    c0f8:	54fef661 	b.ne	9fc4 <f0+0x1d4>  // b.any
    c0fc:	17fff7ad 	b	9fb0 <f0+0x1c0>
    c100:	72003c3f 	tst	w1, #0xffff
    c104:	54ff1be1 	b.ne	a480 <f0+0x690>  // b.any
    c108:	17fff8d9 	b	a46c <f0+0x67c>
    c10c:	72003c3f 	tst	w1, #0xffff
    c110:	54ff1601 	b.ne	a3d0 <f0+0x5e0>  // b.any
    c114:	17fff8aa 	b	a3bc <f0+0x5cc>
    c118:	72003c3f 	tst	w1, #0xffff
    c11c:	54ff1121 	b.ne	a340 <f0+0x550>  // b.any
    c120:	17fff883 	b	a32c <f0+0x53c>
    c124:	72003c3f 	tst	w1, #0xffff
    c128:	54ff0541 	b.ne	a1d0 <f0+0x3e0>  // b.any
    c12c:	17fff824 	b	a1bc <f0+0x3cc>
    c130:	72003c3f 	tst	w1, #0xffff
    c134:	54ff4941 	b.ne	aa5c <f0+0xc6c>  // b.any
    c138:	17fffa44 	b	aa48 <f0+0xc58>
    c13c:	72003c3f 	tst	w1, #0xffff
    c140:	54ff4081 	b.ne	a950 <f0+0xb60>  // b.any
    c144:	17fff9fe 	b	a93c <f0+0xb4c>
    c148:	72003c3f 	tst	w1, #0xffff
    c14c:	54ff3b81 	b.ne	a8bc <f0+0xacc>  // b.any
    c150:	17fff9d6 	b	a8a8 <f0+0xab8>
    c154:	72003c3f 	tst	w1, #0xffff
    c158:	54ff3661 	b.ne	a824 <f0+0xa34>  // b.any
    c15c:	17fff9ad 	b	a810 <f0+0xa20>
    c160:	72003c3f 	tst	w1, #0xffff
    c164:	54ff2e81 	b.ne	a734 <f0+0x944>  // b.any
    c168:	17fff96e 	b	a720 <f0+0x930>
    c16c:	72003c3f 	tst	w1, #0xffff
    c170:	54ff28a1 	b.ne	a684 <f0+0x894>  // b.any
    c174:	17fff93f 	b	a670 <f0+0x880>
    c178:	72003c3f 	tst	w1, #0xffff
    c17c:	54ff23c1 	b.ne	a5f4 <f0+0x804>  // b.any
    c180:	17fff918 	b	a5e0 <f0+0x7f0>
    c184:	72003c3f 	tst	w1, #0xffff
    c188:	54ff1ec1 	b.ne	a560 <f0+0x770>  // b.any
    c18c:	17fff8f0 	b	a54c <f0+0x75c>
    c190:	72003c3f 	tst	w1, #0xffff
    c194:	54ffec41 	b.ne	bf1c <f0+0x212c>  // b.any
    c198:	17ffff5c 	b	bf08 <f0+0x2118>
    c19c:	72003c3f 	tst	w1, #0xffff
    c1a0:	54ffe721 	b.ne	be84 <f0+0x2094>  // b.any
    c1a4:	17ffff33 	b	be70 <f0+0x2080>
    c1a8:	72003c3f 	tst	w1, #0xffff
    c1ac:	54ffdd81 	b.ne	bd5c <f0+0x1f6c>  // b.any
    c1b0:	17fffee6 	b	bd48 <f0+0x1f58>
    c1b4:	72003c3f 	tst	w1, #0xffff
    c1b8:	54ffd5a1 	b.ne	bc6c <f0+0x1e7c>  // b.any
    c1bc:	17fffea7 	b	bc58 <f0+0x1e68>
    c1c0:	72003c3f 	tst	w1, #0xffff
    c1c4:	54ffcce1 	b.ne	bb60 <f0+0x1d70>  // b.any
    c1c8:	17fffe61 	b	bb4c <f0+0x1d5c>
    c1cc:	72003c3f 	tst	w1, #0xffff
    c1d0:	54ffc7c1 	b.ne	bac8 <f0+0x1cd8>  // b.any
    c1d4:	17fffe38 	b	bab4 <f0+0x1cc4>
    c1d8:	72003c3f 	tst	w1, #0xffff
    c1dc:	54ffc1a1 	b.ne	ba10 <f0+0x1c20>  // b.any
    c1e0:	17fffe07 	b	b9fc <f0+0x1c0c>
    c1e4:	72003c3f 	tst	w1, #0xffff
    c1e8:	54ffb9c1 	b.ne	b920 <f0+0x1b30>  // b.any
    c1ec:	17fffdc8 	b	b90c <f0+0x1b1c>
    c1f0:	72003c3f 	tst	w1, #0xffff
    c1f4:	54ffb4c1 	b.ne	b88c <f0+0x1a9c>  // b.any
    c1f8:	17fffda0 	b	b878 <f0+0x1a88>
    c1fc:	72003c3f 	tst	w1, #0xffff
    c200:	54ffaa41 	b.ne	b748 <f0+0x1958>  // b.any
    c204:	17fffd4c 	b	b734 <f0+0x1944>
    c208:	72003c3f 	tst	w1, #0xffff
    c20c:	54ffa541 	b.ne	b6b4 <f0+0x18c4>  // b.any
    c210:	17fffd24 	b	b6a0 <f0+0x18b0>
    c214:	72003c3f 	tst	w1, #0xffff
    c218:	54ffa021 	b.ne	b61c <f0+0x182c>  // b.any
    c21c:	17fffcfb 	b	b608 <f0+0x1818>
    c220:	72003c3f 	tst	w1, #0xffff
    c224:	54ff93e1 	b.ne	b4a0 <f0+0x16b0>  // b.any
    c228:	17fffc99 	b	b48c <f0+0x169c>
    c22c:	72003c3f 	tst	w1, #0xffff
    c230:	54ff8ec1 	b.ne	b408 <f0+0x1618>  // b.any
    c234:	17fffc70 	b	b3f4 <f0+0x1604>
    c238:	72003c3f 	tst	w1, #0xffff
    c23c:	54ff8601 	b.ne	b2fc <f0+0x150c>  // b.any
    c240:	17fffc2a 	b	b2e8 <f0+0x14f8>
    c244:	72003c3f 	tst	w1, #0xffff
    c248:	54ff80e1 	b.ne	b264 <f0+0x1474>  // b.any
    c24c:	17fffc01 	b	b250 <f0+0x1460>
    c250:	aa1403e0 	mov	x0, x20
    c254:	97ffe0a7 	bl	44f0 <fwp_rc_forget_slot>
    c258:	17ffff2f 	b	bf14 <f0+0x2124>
    c25c:	aa1703e0 	mov	x0, x23
    c260:	97ffe0a4 	bl	44f0 <fwp_rc_forget_slot>
    c264:	17fff756 	b	9fbc <f0+0x1cc>
    c268:	aa1703e0 	mov	x0, x23
    c26c:	97ffe0a1 	bl	44f0 <fwp_rc_forget_slot>
    c270:	17fff785 	b	a084 <f0+0x294>
    c274:	aa1703e0 	mov	x0, x23
    c278:	97ffe09e 	bl	44f0 <fwp_rc_forget_slot>
    c27c:	17fff7a7 	b	a118 <f0+0x328>
    c280:	aa1703e0 	mov	x0, x23
    c284:	97ffe09b 	bl	44f0 <fwp_rc_forget_slot>
    c288:	17fff7d0 	b	a1c8 <f0+0x3d8>
    c28c:	aa1703e0 	mov	x0, x23
    c290:	97ffe098 	bl	44f0 <fwp_rc_forget_slot>
    c294:	17fff829 	b	a338 <f0+0x548>
    c298:	aa1703e0 	mov	x0, x23
    c29c:	97ffe095 	bl	44f0 <fwp_rc_forget_slot>
    c2a0:	17fff84a 	b	a3c8 <f0+0x5d8>
    c2a4:	aa1703e0 	mov	x0, x23
    c2a8:	97ffe092 	bl	44f0 <fwp_rc_forget_slot>
    c2ac:	17fff873 	b	a478 <f0+0x688>
    c2b0:	aa1703e0 	mov	x0, x23
    c2b4:	97ffe08f 	bl	44f0 <fwp_rc_forget_slot>
    c2b8:	17fff8a8 	b	a558 <f0+0x768>
    c2bc:	aa1703e0 	mov	x0, x23
    c2c0:	97ffe08c 	bl	44f0 <fwp_rc_forget_slot>
    c2c4:	17fff8ca 	b	a5ec <f0+0x7fc>
    c2c8:	aa1703e0 	mov	x0, x23
    c2cc:	97ffe089 	bl	44f0 <fwp_rc_forget_slot>
    c2d0:	17fff8eb 	b	a67c <f0+0x88c>
    c2d4:	aa1703e0 	mov	x0, x23
    c2d8:	97ffe086 	bl	44f0 <fwp_rc_forget_slot>
    c2dc:	17fff914 	b	a72c <f0+0x93c>
    c2e0:	aa1703e0 	mov	x0, x23
    c2e4:	97ffe083 	bl	44f0 <fwp_rc_forget_slot>
    c2e8:	17fff94d 	b	a81c <f0+0xa2c>
    c2ec:	aa1703e0 	mov	x0, x23
    c2f0:	97ffe080 	bl	44f0 <fwp_rc_forget_slot>
    c2f4:	17fff970 	b	a8b4 <f0+0xac4>
    c2f8:	aa1703e0 	mov	x0, x23
    c2fc:	97ffe07d 	bl	44f0 <fwp_rc_forget_slot>
    c300:	17fff992 	b	a948 <f0+0xb58>
    c304:	aa1703e0 	mov	x0, x23
    c308:	97ffe07a 	bl	44f0 <fwp_rc_forget_slot>
    c30c:	17fff9d2 	b	aa54 <f0+0xc64>
    c310:	aa1703e0 	mov	x0, x23
    c314:	97ffe077 	bl	44f0 <fwp_rc_forget_slot>
    c318:	17fff9f4 	b	aae8 <f0+0xcf8>
    c31c:	aa1703e0 	mov	x0, x23
    c320:	97ffe074 	bl	44f0 <fwp_rc_forget_slot>
    c324:	17fffa17 	b	ab80 <f0+0xd90>
    c328:	aa1703e0 	mov	x0, x23
    c32c:	97ffe071 	bl	44f0 <fwp_rc_forget_slot>
    c330:	17fffa39 	b	ac14 <f0+0xe24>
    c334:	aa1703e0 	mov	x0, x23
    c338:	97ffe06e 	bl	44f0 <fwp_rc_forget_slot>
    c33c:	17fffa72 	b	ad04 <f0+0xf14>
    c340:	aa1503e0 	mov	x0, x21
    c344:	97ffe06b 	bl	44f0 <fwp_rc_forget_slot>
    c348:	17fffaa4 	b	add8 <f0+0xfe8>
    c34c:	aa1703e0 	mov	x0, x23
    c350:	97ffe068 	bl	44f0 <fwp_rc_forget_slot>
    c354:	17fffb00 	b	af54 <f0+0x1164>
    c358:	aa1703e0 	mov	x0, x23
    c35c:	97ffe065 	bl	44f0 <fwp_rc_forget_slot>
    c360:	17fffb55 	b	b0b4 <f0+0x12c4>
    c364:	aa1703e0 	mov	x0, x23
    c368:	97ffe062 	bl	44f0 <fwp_rc_forget_slot>
    c36c:	17fffb8e 	b	b1a4 <f0+0x13b4>
    c370:	aa1703e0 	mov	x0, x23
    c374:	97ffe05f 	bl	44f0 <fwp_rc_forget_slot>
    c378:	17fffbb9 	b	b25c <f0+0x146c>
    c37c:	aa1703e0 	mov	x0, x23
    c380:	97ffe05c 	bl	44f0 <fwp_rc_forget_slot>
    c384:	17fffbdc 	b	b2f4 <f0+0x1504>
    c388:	aa1703e0 	mov	x0, x23
    c38c:	97ffe059 	bl	44f0 <fwp_rc_forget_slot>
    c390:	17fffc1c 	b	b400 <f0+0x1610>
    c394:	aa1503e0 	mov	x0, x21
    c398:	97ffe056 	bl	44f0 <fwp_rc_forget_slot>
    c39c:	17fffc3f 	b	b498 <f0+0x16a8>
    c3a0:	aa1703e0 	mov	x0, x23
    c3a4:	97ffe053 	bl	44f0 <fwp_rc_forget_slot>
    c3a8:	17fffc9b 	b	b614 <f0+0x1824>
    c3ac:	aa1703e0 	mov	x0, x23
    c3b0:	97ffe050 	bl	44f0 <fwp_rc_forget_slot>
    c3b4:	17fffcbe 	b	b6ac <f0+0x18bc>
    c3b8:	aa1503e0 	mov	x0, x21
    c3bc:	97ffe04d 	bl	44f0 <fwp_rc_forget_slot>
    c3c0:	17fffce0 	b	b740 <f0+0x1950>
    c3c4:	aa1703e0 	mov	x0, x23
    c3c8:	97ffe04a 	bl	44f0 <fwp_rc_forget_slot>
    c3cc:	17fffd2e 	b	b884 <f0+0x1a94>
    c3d0:	aa1703e0 	mov	x0, x23
    c3d4:	97ffe047 	bl	44f0 <fwp_rc_forget_slot>
    c3d8:	17fffd50 	b	b918 <f0+0x1b28>
    c3dc:	aa1703e0 	mov	x0, x23
    c3e0:	97ffe044 	bl	44f0 <fwp_rc_forget_slot>
    c3e4:	17fffd89 	b	ba08 <f0+0x1c18>
    c3e8:	aa1703e0 	mov	x0, x23
    c3ec:	97ffe041 	bl	44f0 <fwp_rc_forget_slot>
    c3f0:	17fffdb4 	b	bac0 <f0+0x1cd0>
    c3f4:	aa1703e0 	mov	x0, x23
    c3f8:	97ffe03e 	bl	44f0 <fwp_rc_forget_slot>
    c3fc:	17fffdd7 	b	bb58 <f0+0x1d68>
    c400:	aa1703e0 	mov	x0, x23
    c404:	97ffe03b 	bl	44f0 <fwp_rc_forget_slot>
    c408:	17fffe17 	b	bc64 <f0+0x1e74>
    c40c:	aa1703e0 	mov	x0, x23
    c410:	97ffe038 	bl	44f0 <fwp_rc_forget_slot>
    c414:	17fffe50 	b	bd54 <f0+0x1f64>
    c418:	aa1703e0 	mov	x0, x23
    c41c:	97ffe035 	bl	44f0 <fwp_rc_forget_slot>
    c420:	17fffe97 	b	be7c <f0+0x208c>
    c424:	97ffd8f3 	bl	27f0 <__stack_chk_fail@plt>
    c428:	d503201f 	nop
    c42c:	d503201f 	nop

000000000000c430 <fwp_main_thread>:
    c430:	d10443ff 	sub	sp, sp, #0x110
    c434:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c438:	f947f400 	ldr	x0, [x0, #4072]
    c43c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c440:	910303fd 	add	x29, sp, #0xc0
    c444:	a90d53f3 	stp	x19, x20, [sp, #208]
    c448:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc90>
    c44c:	91154261 	add	x1, x19, #0x550
    c450:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c454:	b953a421 	ldr	w1, [x1, #5028]
    c458:	f9400002 	ldr	x2, [x0]
    c45c:	f9005fe2 	str	x2, [sp, #184]
    c460:	d2800002 	mov	x2, #0x0                   	// #0
    c464:	340025c1 	cbz	w1, c91c <fwp_main_thread+0x4ec>
    c468:	91154273 	add	x19, x19, #0x550
    c46c:	b953aa60 	ldr	w0, [x19, #5032]
    c470:	350024e0 	cbnz	w0, c90c <fwp_main_thread+0x4dc>
    c474:	91001fe2 	add	x2, sp, #0x7
    c478:	900000b5 	adrp	x21, 20000 <__data_start>
    c47c:	900000a3 	adrp	x3, 20000 <__data_start>
    c480:	910102b3 	add	x19, x21, #0x40
    c484:	910dc063 	add	x3, x3, #0x370
    c488:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c48c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c490:	910023e0 	add	x0, sp, #0x8
    c494:	d2800001 	mov	x1, #0x0                   	// #0
    c498:	f90007e3 	str	x3, [sp, #8]
    c49c:	b90013ff 	str	wzr, [sp, #16]
    c4a0:	a9019262 	stp	x2, x4, [x19, #24]
    c4a4:	f9000fe5 	str	x5, [sp, #24]
    c4a8:	97ffd86a 	bl	2650 <sigaltstack@plt>
    c4ac:	35002520 	cbnz	w0, c950 <fwp_main_thread+0x520>
    c4b0:	4f000400 	movi	v0.4s, #0x0
    c4b4:	9100a3e0 	add	x0, sp, #0x28
    c4b8:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    c4bc:	52800082 	mov	w2, #0x4                   	// #4
    c4c0:	913fc021 	add	x1, x1, #0xff0
    c4c4:	72a10002 	movk	w2, #0x800, lsl #16
    c4c8:	910083f4 	add	x20, sp, #0x20
    c4cc:	f90013e1 	str	x1, [sp, #32]
    c4d0:	3d802000 	str	q0, [x0, #128]
    c4d4:	b900abe2 	str	w2, [sp, #168]
    c4d8:	ad000000 	stp	q0, q0, [x0]
    c4dc:	ad010000 	stp	q0, q0, [x0, #32]
    c4e0:	ad020000 	stp	q0, q0, [x0, #64]
    c4e4:	ad030000 	stp	q0, q0, [x0, #96]
    c4e8:	97ffd8b2 	bl	27b0 <sigemptyset@plt>
    c4ec:	35002320 	cbnz	w0, c950 <fwp_main_thread+0x520>
    c4f0:	aa1403e1 	mov	x1, x20
    c4f4:	d2800002 	mov	x2, #0x0                   	// #0
    c4f8:	52800160 	mov	w0, #0xb                   	// #11
    c4fc:	97ffd8c5 	bl	2810 <sigaction@plt>
    c500:	35002280 	cbnz	w0, c950 <fwp_main_thread+0x520>
    c504:	aa1403e1 	mov	x1, x20
    c508:	d2800002 	mov	x2, #0x0                   	// #0
    c50c:	528000e0 	mov	w0, #0x7                   	// #7
    c510:	97ffd8c0 	bl	2810 <sigaction@plt>
    c514:	350021e0 	cbnz	w0, c950 <fwp_main_thread+0x520>
    c518:	b942fa60 	ldr	w0, [x19, #760]
    c51c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c520:	34002020 	cbz	w0, c924 <fwp_main_thread+0x4f4>
    c524:	910102b6 	add	x22, x21, #0x40
    c528:	f9400ad4 	ldr	x20, [x22, #16]
    c52c:	b40010d4 	cbz	x20, c744 <fwp_main_thread+0x314>
    c530:	aa1403f3 	mov	x19, x20
    c534:	91010297 	add	x23, x20, #0x40
    c538:	f90083f9 	str	x25, [sp, #256]
    c53c:	52800038 	mov	w24, #0x1                   	// #1
    c540:	39414a99 	ldrb	w25, [x20, #82]
    c544:	39014a98 	strb	w24, [x20, #82]
    c548:	f9401680 	ldr	x0, [x20, #40]
    c54c:	b4000620 	cbz	x0, c610 <fwp_main_thread+0x1e0>
    c550:	f9403281 	ldr	x1, [x20, #96]
    c554:	39414680 	ldrb	w0, [x20, #81]
    c558:	b4000b41 	cbz	x1, c6c0 <fwp_main_thread+0x290>
    c55c:	36000a80 	tbz	w0, #0, c6ac <fwp_main_thread+0x27c>
    c560:	39414a62 	ldrb	w2, [x19, #82]
    c564:	f9402280 	ldr	x0, [x20, #64]
    c568:	37000d62 	tbnz	w2, #0, c714 <fwp_main_thread+0x2e4>
    c56c:	f9403261 	ldr	x1, [x19, #96]
    c570:	a911fe77 	stp	x23, xzr, [x19, #280]
    c574:	f9009660 	str	x0, [x19, #296]
    c578:	b4000040 	cbz	x0, c580 <fwp_main_thread+0x150>
    c57c:	f9009013 	str	x19, [x0, #288]
    c580:	f9002293 	str	x19, [x20, #64]
    c584:	b4000101 	cbz	x1, c5a4 <fwp_main_thread+0x174>
    c588:	f94046c0 	ldr	x0, [x22, #136]
    c58c:	39015678 	strb	w24, [x19, #85]
    c590:	f9003661 	str	x1, [x19, #104]
    c594:	a910827f 	stp	xzr, x0, [x19, #264]
    c598:	b4000040 	cbz	x0, c5a0 <fwp_main_thread+0x170>
    c59c:	f9008413 	str	x19, [x0, #264]
    c5a0:	f90046d3 	str	x19, [x22, #136]
    c5a4:	39015a7f 	strb	wzr, [x19, #86]
    c5a8:	97ffe77f 	bl	63a4 <fwp_block>
    c5ac:	f9408e62 	ldr	x2, [x19, #280]
    c5b0:	b4000142 	cbz	x2, c5d8 <fwp_main_thread+0x1a8>
    c5b4:	a9520261 	ldp	x1, x0, [x19, #288]
    c5b8:	b4000ba1 	cbz	x1, c72c <fwp_main_thread+0x2fc>
    c5bc:	f9009420 	str	x0, [x1, #296]
    c5c0:	f9409660 	ldr	x0, [x19, #296]
    c5c4:	b4000040 	cbz	x0, c5cc <fwp_main_thread+0x19c>
    c5c8:	f9009001 	str	x1, [x0, #288]
    c5cc:	91080260 	add	x0, x19, #0x200
    c5d0:	f900967f 	str	xzr, [x19, #296]
    c5d4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c5d8:	39415660 	ldrb	w0, [x19, #85]
    c5dc:	f9400ac2 	ldr	x2, [x22, #16]
    c5e0:	36000960 	tbz	w0, #0, c70c <fwp_main_thread+0x2dc>
    c5e4:	a9508261 	ldp	x1, x0, [x19, #264]
    c5e8:	b4000a61 	cbz	x1, c734 <fwp_main_thread+0x304>
    c5ec:	f9008820 	str	x0, [x1, #272]
    c5f0:	b4000040 	cbz	x0, c5f8 <fwp_main_thread+0x1c8>
    c5f4:	f9008401 	str	x1, [x0, #264]
    c5f8:	91080260 	add	x0, x19, #0x200
    c5fc:	3901567f 	strb	wzr, [x19, #85]
    c600:	aa0203f3 	mov	x19, x2
    c604:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c608:	f9401680 	ldr	x0, [x20, #40]
    c60c:	b5fffa20 	cbnz	x0, c550 <fwp_main_thread+0x120>
    c610:	910102a0 	add	x0, x21, #0x40
    c614:	39014a99 	strb	w25, [x20, #82]
    c618:	f94083f9 	ldr	x25, [sp, #256]
    c61c:	f9416c00 	ldr	x0, [x0, #728]
    c620:	b4001560 	cbz	x0, c8cc <fwp_main_thread+0x49c>
    c624:	910102a0 	add	x0, x21, #0x40
    c628:	f9418801 	ldr	x1, [x0, #784]
    c62c:	b903081f 	str	wzr, [x0, #776]
    c630:	eb13003f 	cmp	x1, x19
    c634:	54001681 	b.ne	c904 <fwp_main_thread+0x4d4>  // b.any
    c638:	b4000913 	cbz	x19, c758 <fwp_main_thread+0x328>
    c63c:	910102a0 	add	x0, x21, #0x40
    c640:	52800021 	mov	w1, #0x1                   	// #1
    c644:	39014a61 	strb	w1, [x19, #82]
    c648:	f9415805 	ldr	x5, [x0, #688]
    c64c:	b4000865 	cbz	x5, c758 <fwp_main_thread+0x328>
    c650:	394140a0 	ldrb	w0, [x5, #80]
    c654:	37000060 	tbnz	w0, #0, c660 <fwp_main_thread+0x230>
    c658:	aa0503e0 	mov	x0, x5
    c65c:	97ffdb65 	bl	33f0 <fwp_cancel_tree.part.0>
    c660:	f9409ca5 	ldr	x5, [x5, #312]
    c664:	b5ffff65 	cbnz	x5, c650 <fwp_main_thread+0x220>
    c668:	910102b4 	add	x20, x21, #0x40
    c66c:	52800036 	mov	w22, #0x1                   	// #1
    c670:	f9402a60 	ldr	x0, [x19, #80]
    c674:	f2001c1f 	tst	x0, #0xff000000ff
    c678:	540000e1 	b.ne	c694 <fwp_main_thread+0x264>  // b.any
    c67c:	f9401680 	ldr	x0, [x20, #40]
    c680:	39015276 	strb	w22, [x19, #84]
    c684:	f900827f 	str	xzr, [x19, #256]
    c688:	b40005a0 	cbz	x0, c73c <fwp_main_thread+0x30c>
    c68c:	f9008013 	str	x19, [x0, #256]
    c690:	f9001693 	str	x19, [x20, #40]
    c694:	97ffe744 	bl	63a4 <fwp_block>
    c698:	97ffe6d6 	bl	61f0 <fwp_free_zombie>
    c69c:	f9415a80 	ldr	x0, [x20, #688]
    c6a0:	b40005c0 	cbz	x0, c758 <fwp_main_thread+0x328>
    c6a4:	f9418a93 	ldr	x19, [x20, #784]
    c6a8:	17fffff2 	b	c670 <fwp_main_thread+0x240>
    c6ac:	97ffdbf5 	bl	3680 <fwp_now_ns>
    c6b0:	f9403281 	ldr	x1, [x20, #96]
    c6b4:	eb01001f 	cmp	x0, x1
    c6b8:	54000fca 	b.ge	c8b0 <fwp_main_thread+0x480>  // b.tcont
    c6bc:	39414680 	ldrb	w0, [x20, #81]
    c6c0:	39414a62 	ldrb	w2, [x19, #82]
    c6c4:	3707f500 	tbnz	w0, #0, c564 <fwp_main_thread+0x134>
    c6c8:	f9403281 	ldr	x1, [x20, #96]
    c6cc:	370001c2 	tbnz	w2, #0, c704 <fwp_main_thread+0x2d4>
    c6d0:	f9403260 	ldr	x0, [x19, #96]
    c6d4:	b4000180 	cbz	x0, c704 <fwp_main_thread+0x2d4>
    c6d8:	b4000061 	cbz	x1, c6e4 <fwp_main_thread+0x2b4>
    c6dc:	eb01001f 	cmp	x0, x1
    c6e0:	9a81d000 	csel	x0, x0, x1, le
    c6e4:	f9402281 	ldr	x1, [x20, #64]
    c6e8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c6ec:	f9009661 	str	x1, [x19, #296]
    c6f0:	b4001241 	cbz	x1, c938 <fwp_main_thread+0x508>
    c6f4:	f9009033 	str	x19, [x1, #288]
    c6f8:	aa0003e1 	mov	x1, x0
    c6fc:	f9002293 	str	x19, [x20, #64]
    c700:	17ffffa2 	b	c588 <fwp_main_thread+0x158>
    c704:	f9402280 	ldr	x0, [x20, #64]
    c708:	17ffff9a 	b	c570 <fwp_main_thread+0x140>
    c70c:	aa0203f3 	mov	x19, x2
    c710:	17ffff8e 	b	c548 <fwp_main_thread+0x118>
    c714:	a911fe77 	stp	x23, xzr, [x19, #280]
    c718:	f9009660 	str	x0, [x19, #296]
    c71c:	b4000040 	cbz	x0, c724 <fwp_main_thread+0x2f4>
    c720:	f9009013 	str	x19, [x0, #288]
    c724:	f9002293 	str	x19, [x20, #64]
    c728:	17ffff9f 	b	c5a4 <fwp_main_thread+0x174>
    c72c:	f9000040 	str	x0, [x2]
    c730:	17ffffa5 	b	c5c4 <fwp_main_thread+0x194>
    c734:	f90046c0 	str	x0, [x22, #136]
    c738:	17ffffae 	b	c5f0 <fwp_main_thread+0x1c0>
    c73c:	f9001a93 	str	x19, [x20, #48]
    c740:	17ffffd4 	b	c690 <fwp_main_thread+0x260>
    c744:	f9416ec0 	ldr	x0, [x22, #728]
    c748:	b4000c00 	cbz	x0, c8c8 <fwp_main_thread+0x498>
    c74c:	f9418ac0 	ldr	x0, [x22, #784]
    c750:	b9030adf 	str	wzr, [x22, #776]
    c754:	b5000d80 	cbnz	x0, c904 <fwp_main_thread+0x4d4>
    c758:	910102b4 	add	x20, x21, #0x40
    c75c:	97ffe6a5 	bl	61f0 <fwp_free_zombie>
    c760:	f9401a80 	ldr	x0, [x20, #48]
    c764:	b5000d00 	cbnz	x0, c904 <fwp_main_thread+0x4d4>
    c768:	f9404680 	ldr	x0, [x20, #136]
    c76c:	b5000cc0 	cbnz	x0, c904 <fwp_main_thread+0x4d4>
    c770:	b940aa93 	ldr	w19, [x20, #168]
    c774:	340001d3 	cbz	w19, c7ac <fwp_main_thread+0x37c>
    c778:	93407e76 	sxtw	x22, w19
    c77c:	51000673 	sub	w19, w19, #0x1
    c780:	d1000ad6 	sub	x22, x22, #0x2
    c784:	9102c297 	add	x23, x20, #0xb0
    c788:	cb3342d6 	sub	x22, x22, w19, uxtw
    c78c:	93407e73 	sxtw	x19, w19
    c790:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c794:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c798:	b900aa93 	str	w19, [x20, #168]
    c79c:	d1000673 	sub	x19, x19, #0x1
    c7a0:	97ffd85c 	bl	2910 <munmap@plt>
    c7a4:	eb16027f 	cmp	x19, x22
    c7a8:	54ffff41 	b.ne	c790 <fwp_main_thread+0x360>  // b.any
    c7ac:	900000b3 	adrp	x19, 20000 <__data_start>
    c7b0:	91004260 	add	x0, x19, #0x10
    c7b4:	b9401000 	ldr	w0, [x0, #16]
    c7b8:	37f80040 	tbnz	w0, #31, c7c0 <fwp_main_thread+0x390>
    c7bc:	97ffd811 	bl	2800 <close@plt>
    c7c0:	910102a0 	add	x0, x21, #0x40
    c7c4:	91004261 	add	x1, x19, #0x10
    c7c8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c7cc:	d2800013 	mov	x19, #0x0                   	// #0
    c7d0:	f9418c16 	ldr	x22, [x0, #792]
    c7d4:	b9001022 	str	w2, [x1, #16]
    c7d8:	f9419014 	ldr	x20, [x0, #800]
    c7dc:	b4000176 	cbz	x22, c808 <fwp_main_thread+0x3d8>
    c7e0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c7e4:	b40000c0 	cbz	x0, c7fc <fwp_main_thread+0x3cc>
    c7e8:	f9400001 	ldr	x1, [x0]
    c7ec:	b50008c1 	cbnz	x1, c904 <fwp_main_thread+0x4d4>
    c7f0:	f9400401 	ldr	x1, [x0, #8]
    c7f4:	b5000881 	cbnz	x1, c904 <fwp_main_thread+0x4d4>
    c7f8:	97ffdfde 	bl	4770 <fwp_mem_free>
    c7fc:	91000673 	add	x19, x19, #0x1
    c800:	eb16027f 	cmp	x19, x22
    c804:	54fffee1 	b.ne	c7e0 <fwp_main_thread+0x3b0>  // b.any
    c808:	aa1403e0 	mov	x0, x20
    c80c:	97ffdfd9 	bl	4770 <fwp_mem_free>
    c810:	910102a0 	add	x0, x21, #0x40
    c814:	f9418813 	ldr	x19, [x0, #784]
    c818:	f9018c1f 	str	xzr, [x0, #792]
    c81c:	f901901f 	str	xzr, [x0, #800]
    c820:	b40001f3 	cbz	x19, c85c <fwp_main_thread+0x42c>
    c824:	f9401661 	ldr	x1, [x19, #40]
    c828:	b50006e1 	cbnz	x1, c904 <fwp_main_thread+0x4d4>
    c82c:	f9405661 	ldr	x1, [x19, #168]
    c830:	b50006a1 	cbnz	x1, c904 <fwp_main_thread+0x4d4>
    c834:	f9416c01 	ldr	x1, [x0, #728]
    c838:	b5000661 	cbnz	x1, c904 <fwp_main_thread+0x4d4>
    c83c:	f9417400 	ldr	x0, [x0, #744]
    c840:	b5000620 	cbnz	x0, c904 <fwp_main_thread+0x4d4>
    c844:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c848:	90000120 	adrp	x0, 30000 <alt.5+0xfc90>
    c84c:	910dc000 	add	x0, x0, #0x370
    c850:	97ffd7dc 	bl	27c0 <memset@plt>
    c854:	aa1303e0 	mov	x0, x19
    c858:	97ffdfc6 	bl	4770 <fwp_mem_free>
    c85c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c860:	f947ec00 	ldr	x0, [x0, #4056]
    c864:	910102b5 	add	x21, x21, #0x40
    c868:	f9400000 	ldr	x0, [x0]
    c86c:	f9000abf 	str	xzr, [x21, #16]
    c870:	f9018abf 	str	xzr, [x21, #784]
    c874:	97ffd82b 	bl	2920 <fflush@plt>
    c878:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c87c:	f947f400 	ldr	x0, [x0, #4072]
    c880:	f9405fe2 	ldr	x2, [sp, #184]
    c884:	f9400001 	ldr	x1, [x0]
    c888:	eb010042 	subs	x2, x2, x1
    c88c:	d2800001 	mov	x1, #0x0                   	// #0
    c890:	540006a1 	b.ne	c964 <fwp_main_thread+0x534>  // b.any
    c894:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c898:	d2800000 	mov	x0, #0x0                   	// #0
    c89c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c8a0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c8a4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c8a8:	910443ff 	add	sp, sp, #0x110
    c8ac:	d65f03c0 	ret
    c8b0:	39414280 	ldrb	w0, [x20, #80]
    c8b4:	3707f040 	tbnz	w0, #0, c6bc <fwp_main_thread+0x28c>
    c8b8:	aa1403e0 	mov	x0, x20
    c8bc:	97ffdacd 	bl	33f0 <fwp_cancel_tree.part.0>
    c8c0:	39414680 	ldrb	w0, [x20, #81]
    c8c4:	17ffff7f 	b	c6c0 <fwp_main_thread+0x290>
    c8c8:	d2800013 	mov	x19, #0x0                   	// #0
    c8cc:	910102b4 	add	x20, x21, #0x40
    c8d0:	f9417680 	ldr	x0, [x20, #744]
    c8d4:	b5ffea80 	cbnz	x0, c624 <fwp_main_thread+0x1f4>
    c8d8:	f9416a80 	ldr	x0, [x20, #720]
    c8dc:	97ffdfa5 	bl	4770 <fwp_mem_free>
    c8e0:	f9016a9f 	str	xzr, [x20, #720]
    c8e4:	f901729f 	str	xzr, [x20, #736]
    c8e8:	f9418a80 	ldr	x0, [x20, #784]
    c8ec:	b40002d3 	cbz	x19, c944 <fwp_main_thread+0x514>
    c8f0:	f900567f 	str	xzr, [x19, #168]
    c8f4:	f9005e7f 	str	xzr, [x19, #184]
    c8f8:	b9030a9f 	str	wzr, [x20, #776]
    c8fc:	eb00027f 	cmp	x19, x0
    c900:	54ffe9e0 	b.eq	c63c <fwp_main_thread+0x20c>  // b.none
    c904:	f90083f9 	str	x25, [sp, #256]
    c908:	97ffd7ce 	bl	2840 <abort@plt>
    c90c:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    c910:	91328000 	add	x0, x0, #0xca0
    c914:	940001d3 	bl	d060 <atexit>
    c918:	17fffed7 	b	c474 <fwp_main_thread+0x44>
    c91c:	97ffdd3a 	bl	3e04 <fwp_heap_init>
    c920:	17fffed2 	b	c468 <fwp_main_thread+0x38>
    c924:	97fff533 	bl	9df0 <f0>
    c928:	f9018260 	str	x0, [x19, #768]
    c92c:	52800021 	mov	w1, #0x1                   	// #1
    c930:	b902fa61 	str	w1, [x19, #760]
    c934:	17fffefc 	b	c524 <fwp_main_thread+0xf4>
    c938:	aa0003e1 	mov	x1, x0
    c93c:	f9002293 	str	x19, [x20, #64]
    c940:	17ffff12 	b	c588 <fwp_main_thread+0x158>
    c944:	b9030a9f 	str	wzr, [x20, #776]
    c948:	b4fff080 	cbz	x0, c758 <fwp_main_thread+0x328>
    c94c:	17ffffee 	b	c904 <fwp_main_thread+0x4d4>
    c950:	b0000000 	adrp	x0, d000 <__modti3+0x310>
    c954:	91192000 	add	x0, x0, #0x648
    c958:	a90f63f7 	stp	x23, x24, [sp, #240]
    c95c:	f90083f9 	str	x25, [sp, #256]
    c960:	97ffdae8 	bl	3500 <fwp_trap>
    c964:	f90083f9 	str	x25, [sp, #256]
    c968:	97ffd7a2 	bl	27f0 <__stack_chk_fail@plt>
    c96c:	d503201f 	nop

000000000000c970 <__divti3>:
    c970:	d503245f 	bti	c
    c974:	d2800004 	mov	x4, #0x0                   	// #0
    c978:	b7f80721 	tbnz	x1, #63, ca5c <__divti3+0xec>
    c97c:	b6f80083 	tbz	x3, #63, c98c <__divti3+0x1c>
    c980:	eb0203e2 	negs	x2, x2
    c984:	aa2403e4 	mvn	x4, x4
    c988:	da0303e3 	ngc	x3, x3
    c98c:	aa0203e6 	mov	x6, x2
    c990:	aa0003e7 	mov	x7, x0
    c994:	aa0103e5 	mov	x5, x1
    c998:	b5000583 	cbnz	x3, ca48 <__divti3+0xd8>
    c99c:	eb01005f 	cmp	x2, x1
    c9a0:	54000e69 	b.ls	cb6c <__divti3+0x1fc>  // b.plast
    c9a4:	dac01040 	clz	x0, x2
    c9a8:	b40000e0 	cbz	x0, c9c4 <__divti3+0x54>
    c9ac:	4b0003e1 	neg	w1, w0
    c9b0:	9ac020a5 	lsl	x5, x5, x0
    c9b4:	9ac02046 	lsl	x6, x2, x0
    c9b8:	9ac124e1 	lsr	x1, x7, x1
    c9bc:	aa050025 	orr	x5, x1, x5
    c9c0:	9ac020e7 	lsl	x7, x7, x0
    c9c4:	d360fcc8 	lsr	x8, x6, #32
    c9c8:	92407cc2 	and	x2, x6, #0xffffffff
    c9cc:	9ac808a3 	udiv	x3, x5, x8
    c9d0:	9b089465 	msub	x5, x3, x8, x5
    c9d4:	aa0303e0 	mov	x0, x3
    c9d8:	9b037c41 	mul	x1, x2, x3
    c9dc:	93c780a5 	extr	x5, x5, x7, #32
    c9e0:	eb05003f 	cmp	x1, x5
    c9e4:	540000a9 	b.ls	c9f8 <__divti3+0x88>  // b.plast
    c9e8:	ab0500c5 	adds	x5, x6, x5
    c9ec:	d1000460 	sub	x0, x3, #0x1
    c9f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c9f4:	540015a8 	b.hi	cca8 <__divti3+0x338>  // b.pmore
    c9f8:	cb0100a5 	sub	x5, x5, x1
    c9fc:	9ac808a3 	udiv	x3, x5, x8
    ca00:	9b089465 	msub	x5, x3, x8, x5
    ca04:	aa0303e1 	mov	x1, x3
    ca08:	9b037c42 	mul	x2, x2, x3
    ca0c:	aa0703e3 	mov	x3, x7
    ca10:	b3607ca3 	bfi	x3, x5, #32, #32
    ca14:	eb03005f 	cmp	x2, x3
    ca18:	540000c9 	b.ls	ca30 <__divti3+0xc0>  // b.plast
    ca1c:	ab0300c3 	adds	x3, x6, x3
    ca20:	d1000425 	sub	x5, x1, #0x1
    ca24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca28:	d1000821 	sub	x1, x1, #0x2
    ca2c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ca30:	aa008020 	orr	x0, x1, x0, lsl #32
    ca34:	d2800001 	mov	x1, #0x0                   	// #0
    ca38:	b4000064 	cbz	x4, ca44 <__divti3+0xd4>
    ca3c:	eb0003e0 	negs	x0, x0
    ca40:	da0103e1 	ngc	x1, x1
    ca44:	d65f03c0 	ret
    ca48:	eb01007f 	cmp	x3, x1
    ca4c:	54000109 	b.ls	ca6c <__divti3+0xfc>  // b.plast
    ca50:	d2800001 	mov	x1, #0x0                   	// #0
    ca54:	d2800000 	mov	x0, #0x0                   	// #0
    ca58:	17fffff8 	b	ca38 <__divti3+0xc8>
    ca5c:	eb0003e0 	negs	x0, x0
    ca60:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ca64:	da0103e1 	ngc	x1, x1
    ca68:	17ffffc5 	b	c97c <__divti3+0xc>
    ca6c:	dac01067 	clz	x7, x3
    ca70:	b40010e7 	cbz	x7, cc8c <__divti3+0x31c>
    ca74:	d2800805 	mov	x5, #0x40                  	// #64
    ca78:	cb0700a5 	sub	x5, x5, x7
    ca7c:	9ac72063 	lsl	x3, x3, x7
    ca80:	9ac52448 	lsr	x8, x2, x5
    ca84:	aa030108 	orr	x8, x8, x3
    ca88:	9ac52426 	lsr	x6, x1, x5
    ca8c:	92407d0a 	and	x10, x8, #0xffffffff
    ca90:	d360fd09 	lsr	x9, x8, #32
    ca94:	9ac52403 	lsr	x3, x0, x5
    ca98:	9ac72021 	lsl	x1, x1, x7
    ca9c:	aa010063 	orr	x3, x3, x1
    caa0:	9ac72042 	lsl	x2, x2, x7
    caa4:	9ac908cb 	udiv	x11, x6, x9
    caa8:	9b099965 	msub	x5, x11, x9, x6
    caac:	aa0b03e1 	mov	x1, x11
    cab0:	9b0b7d46 	mul	x6, x10, x11
    cab4:	93c380a5 	extr	x5, x5, x3, #32
    cab8:	eb0500df 	cmp	x6, x5
    cabc:	540000a9 	b.ls	cad0 <__divti3+0x160>  // b.plast
    cac0:	ab050105 	adds	x5, x8, x5
    cac4:	d1000561 	sub	x1, x11, #0x1
    cac8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cacc:	54000f48 	b.hi	ccb4 <__divti3+0x344>  // b.pmore
    cad0:	cb0600a6 	sub	x6, x5, x6
    cad4:	9ac908cb 	udiv	x11, x6, x9
    cad8:	9b099969 	msub	x9, x11, x9, x6
    cadc:	aa0b03e5 	mov	x5, x11
    cae0:	9b0b7d4a 	mul	x10, x10, x11
    cae4:	b3607d23 	bfi	x3, x9, #32, #32
    cae8:	eb03015f 	cmp	x10, x3
    caec:	540000a9 	b.ls	cb00 <__divti3+0x190>  // b.plast
    caf0:	ab030103 	adds	x3, x8, x3
    caf4:	d1000565 	sub	x5, x11, #0x1
    caf8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cafc:	54000e28 	b.hi	ccc0 <__divti3+0x350>  // b.pmore
    cb00:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cb04:	92407c48 	and	x8, x2, #0xffffffff
    cb08:	2a0503e5 	mov	w5, w5
    cb0c:	d360fc42 	lsr	x2, x2, #32
    cb10:	d360fc26 	lsr	x6, x1, #32
    cb14:	cb0a0063 	sub	x3, x3, x10
    cb18:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cb1c:	9b087caa 	mul	x10, x5, x8
    cb20:	9b087cc8 	mul	x8, x6, x8
    cb24:	9b0220a5 	madd	x5, x5, x2, x8
    cb28:	9b027cc6 	mul	x6, x6, x2
    cb2c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cb30:	8b0900c5 	add	x5, x6, x9
    cb34:	eb02011f 	cmp	x8, x2
    cb38:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cb3c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cb40:	eb06007f 	cmp	x3, x6
    cb44:	540000e3 	b.cc	cb60 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cb48:	92407d4a 	and	x10, x10, #0xffffffff
    cb4c:	9ac72000 	lsl	x0, x0, x7
    cb50:	8b028142 	add	x2, x10, x2, lsl #32
    cb54:	eb02001f 	cmp	x0, x2
    cb58:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cb5c:	54000a01 	b.ne	cc9c <__divti3+0x32c>  // b.any
    cb60:	d1000420 	sub	x0, x1, #0x1
    cb64:	d2800001 	mov	x1, #0x0                   	// #0
    cb68:	17ffffb4 	b	ca38 <__divti3+0xc8>
    cb6c:	b5000062 	cbnz	x2, cb78 <__divti3+0x208>
    cb70:	d2800022 	mov	x2, #0x1                   	// #1
    cb74:	9ac30846 	udiv	x6, x2, x3
    cb78:	dac010c8 	clz	x8, x6
    cb7c:	b5000408 	cbnz	x8, cbfc <__divti3+0x28c>
    cb80:	d360fcc9 	lsr	x9, x6, #32
    cb84:	92407cc5 	and	x5, x6, #0xffffffff
    cb88:	cb060023 	sub	x3, x1, x6
    cb8c:	d2800021 	mov	x1, #0x1                   	// #1
    cb90:	9ac90868 	udiv	x8, x3, x9
    cb94:	9b098d03 	msub	x3, x8, x9, x3
    cb98:	aa0803e0 	mov	x0, x8
    cb9c:	9b057d02 	mul	x2, x8, x5
    cba0:	93c78063 	extr	x3, x3, x7, #32
    cba4:	eb03005f 	cmp	x2, x3
    cba8:	540000a9 	b.ls	cbbc <__divti3+0x24c>  // b.plast
    cbac:	ab0300c3 	adds	x3, x6, x3
    cbb0:	d1000500 	sub	x0, x8, #0x1
    cbb4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cbb8:	54000968 	b.hi	cce4 <__divti3+0x374>  // b.pmore
    cbbc:	cb020063 	sub	x3, x3, x2
    cbc0:	9ac90862 	udiv	x2, x3, x9
    cbc4:	aa0203e8 	mov	x8, x2
    cbc8:	9b098c42 	msub	x2, x2, x9, x3
    cbcc:	aa0703e3 	mov	x3, x7
    cbd0:	9b057d05 	mul	x5, x8, x5
    cbd4:	b3607c43 	bfi	x3, x2, #32, #32
    cbd8:	eb0300bf 	cmp	x5, x3
    cbdc:	540000c9 	b.ls	cbf4 <__divti3+0x284>  // b.plast
    cbe0:	ab0300c2 	adds	x2, x6, x3
    cbe4:	d1000503 	sub	x3, x8, #0x1
    cbe8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cbec:	d1000908 	sub	x8, x8, #0x2
    cbf0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cbf4:	aa008100 	orr	x0, x8, x0, lsl #32
    cbf8:	17ffff90 	b	ca38 <__divti3+0xc8>
    cbfc:	9ac820c6 	lsl	x6, x6, x8
    cc00:	d2800803 	mov	x3, #0x40                  	// #64
    cc04:	cb080063 	sub	x3, x3, x8
    cc08:	d360fcc9 	lsr	x9, x6, #32
    cc0c:	9ac82027 	lsl	x7, x1, x8
    cc10:	92407cc5 	and	x5, x6, #0xffffffff
    cc14:	9ac32422 	lsr	x2, x1, x3
    cc18:	9ac32403 	lsr	x3, x0, x3
    cc1c:	aa070063 	orr	x3, x3, x7
    cc20:	9ac9084a 	udiv	x10, x2, x9
    cc24:	9ac82007 	lsl	x7, x0, x8
    cc28:	9b098940 	msub	x0, x10, x9, x2
    cc2c:	aa0a03e1 	mov	x1, x10
    cc30:	9b0a7ca2 	mul	x2, x5, x10
    cc34:	93c38000 	extr	x0, x0, x3, #32
    cc38:	eb00005f 	cmp	x2, x0
    cc3c:	540000a9 	b.ls	cc50 <__divti3+0x2e0>  // b.plast
    cc40:	ab0000c0 	adds	x0, x6, x0
    cc44:	d1000541 	sub	x1, x10, #0x1
    cc48:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cc4c:	54000468 	b.hi	ccd8 <__divti3+0x368>  // b.pmore
    cc50:	cb020000 	sub	x0, x0, x2
    cc54:	9ac9080a 	udiv	x10, x0, x9
    cc58:	9b098140 	msub	x0, x10, x9, x0
    cc5c:	aa0a03e2 	mov	x2, x10
    cc60:	9b0a7ca8 	mul	x8, x5, x10
    cc64:	b3607c03 	bfi	x3, x0, #32, #32
    cc68:	eb03011f 	cmp	x8, x3
    cc6c:	540000a9 	b.ls	cc80 <__divti3+0x310>  // b.plast
    cc70:	ab0300c3 	adds	x3, x6, x3
    cc74:	d1000542 	sub	x2, x10, #0x1
    cc78:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cc7c:	54000288 	b.hi	cccc <__divti3+0x35c>  // b.pmore
    cc80:	cb080063 	sub	x3, x3, x8
    cc84:	aa018041 	orr	x1, x2, x1, lsl #32
    cc88:	17ffffc2 	b	cb90 <__divti3+0x220>
    cc8c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cc90:	d2800001 	mov	x1, #0x0                   	// #0
    cc94:	9a9f87e0 	cset	x0, ls	// ls = plast
    cc98:	17ffff68 	b	ca38 <__divti3+0xc8>
    cc9c:	aa0103e0 	mov	x0, x1
    cca0:	d2800001 	mov	x1, #0x0                   	// #0
    cca4:	17ffff65 	b	ca38 <__divti3+0xc8>
    cca8:	d1000860 	sub	x0, x3, #0x2
    ccac:	8b0600a5 	add	x5, x5, x6
    ccb0:	17ffff52 	b	c9f8 <__divti3+0x88>
    ccb4:	d1000961 	sub	x1, x11, #0x2
    ccb8:	8b0800a5 	add	x5, x5, x8
    ccbc:	17ffff85 	b	cad0 <__divti3+0x160>
    ccc0:	d1000965 	sub	x5, x11, #0x2
    ccc4:	8b080063 	add	x3, x3, x8
    ccc8:	17ffff8e 	b	cb00 <__divti3+0x190>
    cccc:	d1000942 	sub	x2, x10, #0x2
    ccd0:	8b060063 	add	x3, x3, x6
    ccd4:	17ffffeb 	b	cc80 <__divti3+0x310>
    ccd8:	d1000941 	sub	x1, x10, #0x2
    ccdc:	8b060000 	add	x0, x0, x6
    cce0:	17ffffdc 	b	cc50 <__divti3+0x2e0>
    cce4:	d1000900 	sub	x0, x8, #0x2
    cce8:	8b060063 	add	x3, x3, x6
    ccec:	17ffffb4 	b	cbbc <__divti3+0x24c>

000000000000ccf0 <__modti3>:
    ccf0:	d503245f 	bti	c
    ccf4:	d2800004 	mov	x4, #0x0                   	// #0
    ccf8:	b6f80081 	tbz	x1, #63, cd08 <__modti3+0x18>
    ccfc:	eb0003e0 	negs	x0, x0
    cd00:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cd04:	da0103e1 	ngc	x1, x1
    cd08:	f100007f 	cmp	x3, #0x0
    cd0c:	5400128b 	b.lt	cf5c <__modti3+0x26c>  // b.tstop
    cd10:	aa0003e7 	mov	x7, x0
    cd14:	aa0103e6 	mov	x6, x1
    cd18:	540004e1 	b.ne	cdb4 <__modti3+0xc4>  // b.any
    cd1c:	eb02003f 	cmp	x1, x2
    cd20:	54000dc2 	b.cs	ced8 <__modti3+0x1e8>  // b.hs, b.nlast
    cd24:	dac01043 	clz	x3, x2
    cd28:	aa0303e5 	mov	x5, x3
    cd2c:	b40000e3 	cbz	x3, cd48 <__modti3+0x58>
    cd30:	4b0303e6 	neg	w6, w3
    cd34:	9ac32021 	lsl	x1, x1, x3
    cd38:	9ac32042 	lsl	x2, x2, x3
    cd3c:	9ac62406 	lsr	x6, x0, x6
    cd40:	aa0100c6 	orr	x6, x6, x1
    cd44:	9ac32007 	lsl	x7, x0, x3
    cd48:	d360fc40 	lsr	x0, x2, #32
    cd4c:	92407c43 	and	x3, x2, #0xffffffff
    cd50:	9ac008c1 	udiv	x1, x6, x0
    cd54:	9b009826 	msub	x6, x1, x0, x6
    cd58:	9b017c61 	mul	x1, x3, x1
    cd5c:	93c780c6 	extr	x6, x6, x7, #32
    cd60:	eb06003f 	cmp	x1, x6
    cd64:	540000a9 	b.ls	cd78 <__modti3+0x88>  // b.plast
    cd68:	ab060046 	adds	x6, x2, x6
    cd6c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cd70:	8b0200c8 	add	x8, x6, x2
    cd74:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cd78:	cb0100c6 	sub	x6, x6, x1
    cd7c:	9ac008c8 	udiv	x8, x6, x0
    cd80:	9b009901 	msub	x1, x8, x0, x6
    cd84:	aa0703e0 	mov	x0, x7
    cd88:	9b087c63 	mul	x3, x3, x8
    cd8c:	b3607c20 	bfi	x0, x1, #32, #32
    cd90:	eb00007f 	cmp	x3, x0
    cd94:	54001088 	b.hi	cfa4 <__modti3+0x2b4>  // b.pmore
    cd98:	cb030000 	sub	x0, x0, x3
    cd9c:	9ac52400 	lsr	x0, x0, x5
    cda0:	d2800001 	mov	x1, #0x0                   	// #0
    cda4:	b4000064 	cbz	x4, cdb0 <__modti3+0xc0>
    cda8:	eb0003e0 	negs	x0, x0
    cdac:	da0103e1 	ngc	x1, x1
    cdb0:	d65f03c0 	ret
    cdb4:	dac01066 	clz	x6, x3
    cdb8:	eb03003f 	cmp	x1, x3
    cdbc:	54ffff43 	b.cc	cda4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cdc0:	93407cc5 	sxtw	x5, w6
    cdc4:	d2800808 	mov	x8, #0x40                  	// #64
    cdc8:	cb050108 	sub	x8, x8, x5
    cdcc:	9ac62063 	lsl	x3, x3, x6
    cdd0:	9ac62025 	lsl	x5, x1, x6
    cdd4:	9ac82447 	lsr	x7, x2, x8
    cdd8:	aa0300e7 	orr	x7, x7, x3
    cddc:	9ac82423 	lsr	x3, x1, x8
    cde0:	92407cec 	and	x12, x7, #0xffffffff
    cde4:	d360fcea 	lsr	x10, x7, #32
    cde8:	9ac82401 	lsr	x1, x0, x8
    cdec:	aa050021 	orr	x1, x1, x5
    cdf0:	9ac62042 	lsl	x2, x2, x6
    cdf4:	9ac62000 	lsl	x0, x0, x6
    cdf8:	9aca086b 	udiv	x11, x3, x10
    cdfc:	9b0a8d63 	msub	x3, x11, x10, x3
    ce00:	aa0b03e5 	mov	x5, x11
    ce04:	9b0b7d89 	mul	x9, x12, x11
    ce08:	93c18063 	extr	x3, x3, x1, #32
    ce0c:	eb03013f 	cmp	x9, x3
    ce10:	540000a9 	b.ls	ce24 <__modti3+0x134>  // b.plast
    ce14:	ab0300e3 	adds	x3, x7, x3
    ce18:	d1000565 	sub	x5, x11, #0x1
    ce1c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ce20:	54001168 	b.hi	d04c <__modti3+0x35c>  // b.pmore
    ce24:	cb090063 	sub	x3, x3, x9
    ce28:	9aca086b 	udiv	x11, x3, x10
    ce2c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ce30:	aa0b03e9 	mov	x9, x11
    ce34:	9b0b7d8c 	mul	x12, x12, x11
    ce38:	b3607d41 	bfi	x1, x10, #32, #32
    ce3c:	eb01019f 	cmp	x12, x1
    ce40:	540000a9 	b.ls	ce54 <__modti3+0x164>  // b.plast
    ce44:	ab0100e1 	adds	x1, x7, x1
    ce48:	d1000569 	sub	x9, x11, #0x1
    ce4c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ce50:	54000f88 	b.hi	d040 <__modti3+0x350>  // b.pmore
    ce54:	aa058123 	orr	x3, x9, x5, lsl #32
    ce58:	92407c4b 	and	x11, x2, #0xffffffff
    ce5c:	2a0903e9 	mov	w9, w9
    ce60:	d360fc4a 	lsr	x10, x2, #32
    ce64:	d360fc63 	lsr	x3, x3, #32
    ce68:	cb0c0021 	sub	x1, x1, x12
    ce6c:	aa0a03ec 	mov	x12, x10
    ce70:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ce74:	9b0b7d25 	mul	x5, x9, x11
    ce78:	9b0b7c6b 	mul	x11, x3, x11
    ce7c:	9b0a2d29 	madd	x9, x9, x10, x11
    ce80:	92407caa 	and	x10, x5, #0xffffffff
    ce84:	9b0c7c63 	mul	x3, x3, x12
    ce88:	8b458125 	add	x5, x9, x5, lsr #32
    ce8c:	8b0d0069 	add	x9, x3, x13
    ce90:	eb05017f 	cmp	x11, x5
    ce94:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ce98:	8b058149 	add	x9, x10, x5, lsl #32
    ce9c:	8b458063 	add	x3, x3, x5, lsr #32
    cea0:	eb03003f 	cmp	x1, x3
    cea4:	54000063 	b.cc	ceb0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cea8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ceac:	54000082 	b.cs	cebc <__modti3+0x1cc>  // b.hs, b.nlast
    ceb0:	eb020129 	subs	x9, x9, x2
    ceb4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    ceb8:	cb070063 	sub	x3, x3, x7
    cebc:	eb090000 	subs	x0, x0, x9
    cec0:	da030021 	sbc	x1, x1, x3
    cec4:	9ac62400 	lsr	x0, x0, x6
    cec8:	9ac82028 	lsl	x8, x1, x8
    cecc:	aa000100 	orr	x0, x8, x0
    ced0:	9ac62421 	lsr	x1, x1, x6
    ced4:	17ffffb4 	b	cda4 <__modti3+0xb4>
    ced8:	b5000062 	cbnz	x2, cee4 <__modti3+0x1f4>
    cedc:	d2800023 	mov	x3, #0x1                   	// #1
    cee0:	9ac20862 	udiv	x2, x3, x2
    cee4:	dac01048 	clz	x8, x2
    cee8:	aa0803e5 	mov	x5, x8
    ceec:	b5000668 	cbnz	x8, cfb8 <__modti3+0x2c8>
    cef0:	cb020020 	sub	x0, x1, x2
    cef4:	d360fc49 	lsr	x9, x2, #32
    cef8:	92407c4a 	and	x10, x2, #0xffffffff
    cefc:	9ac90801 	udiv	x1, x0, x9
    cf00:	9b098020 	msub	x0, x1, x9, x0
    cf04:	9b0a7c21 	mul	x1, x1, x10
    cf08:	93c78000 	extr	x0, x0, x7, #32
    cf0c:	eb00003f 	cmp	x1, x0
    cf10:	540000a9 	b.ls	cf24 <__modti3+0x234>  // b.plast
    cf14:	ab000040 	adds	x0, x2, x0
    cf18:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf1c:	8b020003 	add	x3, x0, x2
    cf20:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cf24:	cb010001 	sub	x1, x0, x1
    cf28:	9ac90820 	udiv	x0, x1, x9
    cf2c:	9b098403 	msub	x3, x0, x9, x1
    cf30:	aa0703e1 	mov	x1, x7
    cf34:	9b0a7c00 	mul	x0, x0, x10
    cf38:	b3607c61 	bfi	x1, x3, #32, #32
    cf3c:	eb01001f 	cmp	x0, x1
    cf40:	540000a9 	b.ls	cf54 <__modti3+0x264>  // b.plast
    cf44:	ab010041 	adds	x1, x2, x1
    cf48:	8b020022 	add	x2, x1, x2
    cf4c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cf50:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cf54:	cb000020 	sub	x0, x1, x0
    cf58:	17ffff91 	b	cd9c <__modti3+0xac>
    cf5c:	eb0203e5 	negs	x5, x2
    cf60:	aa0003e7 	mov	x7, x0
    cf64:	da0303e8 	ngc	x8, x3
    cf68:	aa0503e2 	mov	x2, x5
    cf6c:	aa0803e3 	mov	x3, x8
    cf70:	aa0103e6 	mov	x6, x1
    cf74:	b4ffed48 	cbz	x8, cd1c <__modti3+0x2c>
    cf78:	eb01011f 	cmp	x8, x1
    cf7c:	54fff148 	b.hi	cda4 <__modti3+0xb4>  // b.pmore
    cf80:	dac01109 	clz	x9, x8
    cf84:	2a0903e6 	mov	w6, w9
    cf88:	b5fff1c9 	cbnz	x9, cdc0 <__modti3+0xd0>
    cf8c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cf90:	54000068 	b.hi	cf9c <__modti3+0x2ac>  // b.pmore
    cf94:	eb050007 	subs	x7, x0, x5
    cf98:	da080021 	sbc	x1, x1, x8
    cf9c:	aa0703e0 	mov	x0, x7
    cfa0:	17ffff81 	b	cda4 <__modti3+0xb4>
    cfa4:	ab000040 	adds	x0, x2, x0
    cfa8:	8b020002 	add	x2, x0, x2
    cfac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cfb0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cfb4:	17ffff79 	b	cd98 <__modti3+0xa8>
    cfb8:	9ac82042 	lsl	x2, x2, x8
    cfbc:	d2800803 	mov	x3, #0x40                  	// #64
    cfc0:	cb080063 	sub	x3, x3, x8
    cfc4:	d360fc49 	lsr	x9, x2, #32
    cfc8:	9ac82027 	lsl	x7, x1, x8
    cfcc:	92407c4a 	and	x10, x2, #0xffffffff
    cfd0:	9ac32426 	lsr	x6, x1, x3
    cfd4:	9ac32403 	lsr	x3, x0, x3
    cfd8:	aa070063 	orr	x3, x3, x7
    cfdc:	9ac908c1 	udiv	x1, x6, x9
    cfe0:	9ac82007 	lsl	x7, x0, x8
    cfe4:	9b099820 	msub	x0, x1, x9, x6
    cfe8:	9b017d41 	mul	x1, x10, x1
    cfec:	93c38000 	extr	x0, x0, x3, #32
    cff0:	eb00003f 	cmp	x1, x0
    cff4:	540000a9 	b.ls	d008 <__modti3+0x318>  // b.plast
    cff8:	ab000040 	adds	x0, x2, x0
    cffc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d000:	8b020006 	add	x6, x0, x2
    d004:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d008:	cb010000 	sub	x0, x0, x1
    d00c:	9ac90801 	udiv	x1, x0, x9
    d010:	9b098026 	msub	x6, x1, x9, x0
    d014:	aa0303e0 	mov	x0, x3
    d018:	9b017d41 	mul	x1, x10, x1
    d01c:	b3607cc0 	bfi	x0, x6, #32, #32
    d020:	eb00003f 	cmp	x1, x0
    d024:	540000a9 	b.ls	d038 <__modti3+0x348>  // b.plast
    d028:	ab000040 	adds	x0, x2, x0
    d02c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d030:	8b020003 	add	x3, x0, x2
    d034:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d038:	cb010000 	sub	x0, x0, x1
    d03c:	17ffffb0 	b	cefc <__modti3+0x20c>
    d040:	d1000969 	sub	x9, x11, #0x2
    d044:	8b070021 	add	x1, x1, x7
    d048:	17ffff83 	b	ce54 <__modti3+0x164>
    d04c:	d1000965 	sub	x5, x11, #0x2
    d050:	8b070063 	add	x3, x3, x7
    d054:	17ffff74 	b	ce24 <__modti3+0x134>
    d058:	d503201f 	nop
    d05c:	d503201f 	nop

000000000000d060 <atexit>:
    d060:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d064:	f0000082 	adrp	x2, 20000 <__data_start>
    d068:	d2800001 	mov	x1, #0x0                   	// #0
    d06c:	910003fd 	mov	x29, sp
    d070:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d074:	f9400442 	ldr	x2, [x2, #8]
    d078:	17ffd59e 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d07c <_fini>:
    d07c:	d503201f 	nop
    d080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d084:	910003fd 	mov	x29, sp
    d088:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d08c:	d65f03c0 	ret
