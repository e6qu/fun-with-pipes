
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x400>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9130e0a5 	add	x5, x5, #0xc38
    2a20:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x400>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91310084 	add	x4, x4, #0xc40
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe260>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x720>
    2ab4:	91062000 	add	x0, x0, #0x188
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x1a6c>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91300042 	add	x2, x2, #0xc00
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943da60 	ldr	w0, [x19, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x720>
    2bfc:	91066000 	add	x0, x0, #0x198
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x720>
    2c0c:	9108e000 	add	x0, x0, #0x238
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x720>
    2c24:	91084000 	add	x0, x0, #0x210
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x720>
    2c30:	91078000 	add	x0, x0, #0x1e0
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x720>
    2c3c:	9106e000 	add	x0, x0, #0x1b8
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x720>
    2e34:	9121c021 	add	x1, x1, #0x870
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x720>
    30d8:	91214021 	add	x1, x1, #0x850
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3110:	9123a000 	add	x0, x0, #0x8e8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x400>
    331c:	91240042 	add	x2, x2, #0x900
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x400>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	91256042 	add	x2, x2, #0x958
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x400>
    33a8:	d000005a 	adrp	x26, d000 <fwp_main_thread+0x400>
    33ac:	9126e339 	add	x25, x25, #0x9b8
    33b0:	9124835a 	add	x26, x26, #0x920
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	d000005b 	adrp	x27, d000 <fwp_main_thread+0x400>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	9124a377 	add	x23, x27, #0x928
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	9127e000 	add	x0, x0, #0x9f8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfba0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfba0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfba0>
    347c:	d0000043 	adrp	x3, d000 <fwp_main_thread+0x400>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	d0000055 	adrp	x21, d000 <fwp_main_thread+0x400>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	91248063 	add	x3, x3, #0x920
    34a0:	912842b5 	add	x21, x21, #0xa10
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91294000 	add	x0, x0, #0xa50
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    352c:	9124c000 	add	x0, x0, #0x930
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    35ec:	9123a000 	add	x0, x0, #0x8e8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x400>
    3730:	aa1303e0 	mov	x0, x19
    3734:	91296021 	add	x1, x1, #0xa58
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x400>
    3744:	aa1303e0 	mov	x0, x19
    3748:	91298021 	add	x1, x1, #0xa60
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x400>
    3760:	9129a021 	add	x1, x1, #0xa68
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x400>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	9129c042 	add	x2, x2, #0xa70
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    38d0:	9123a000 	add	x0, x0, #0x8e8
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    38f0:	912a0000 	add	x0, x0, #0xa80
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3988:	912a8000 	add	x0, x0, #0xaa0
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3998:	912b0000 	add	x0, x0, #0xac0
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x720>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc22020 	ldr	q0, [x1, #2176]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3a98:	912ba000 	add	x0, x0, #0xae8
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3b08:	912c6000 	add	x0, x0, #0xb18
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x400>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	912da084 	add	x4, x4, #0xb68
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x400>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	912e0084 	add	x4, x4, #0xb80
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x400>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	912dc084 	add	x4, x4, #0xb70
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3f28:	91190042 	add	x2, x2, #0x640
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x400>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	912e2021 	add	x1, x1, #0xb88
    3f84:	912e4000 	add	x0, x0, #0xb90
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x400>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	912ec042 	add	x2, x2, #0xbb0
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    408c:	91150061 	add	x1, x3, #0x540
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    409c:	91190262 	add	x2, x19, #0x640
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0x720>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    40cc:	91160021 	add	x1, x1, #0x580
    40d0:	3dc22443 	ldr	q3, [x2, #2192]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    40fc:	91150063 	add	x3, x3, #0x540
    4100:	91178084 	add	x4, x4, #0x5e0
    4104:	91190266 	add	x6, x19, #0x640
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91190275 	add	x21, x19, #0x640
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    41e8:	91318000 	add	x0, x0, #0xc60
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91190273 	add	x19, x19, #0x640
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <fwp_wake_io>:
    4244:	900000e9 	adrp	x9, 20000 <__data_start>
    4248:	91018122 	add	x2, x9, #0x60
    424c:	f9400001 	ldr	x1, [x0]
    4250:	5280000a 	mov	w10, #0x0                   	// #0
    4254:	f9406046 	ldr	x6, [x2, #192]
    4258:	52800008 	mov	w8, #0x0                   	// #0
    425c:	4f000400 	movi	v0.4s, #0x0
    4260:	52800027 	mov	w7, #0x1                   	// #1
    4264:	aa0103e2 	mov	x2, x1
    4268:	b4000321 	cbz	x1, 42cc <fwp_wake_io+0x88>
    426c:	f9408c25 	ldr	x5, [x1, #280]
    4270:	39015c27 	strb	w7, [x1, #87]
    4274:	b4000165 	cbz	x5, 42a0 <fwp_wake_io+0x5c>
    4278:	a9520c24 	ldp	x4, x3, [x1, #288]
    427c:	b4000364 	cbz	x4, 42e8 <fwp_wake_io+0xa4>
    4280:	f9009483 	str	x3, [x4, #296]
    4284:	f9409423 	ldr	x3, [x1, #296]
    4288:	b4000043 	cbz	x3, 4290 <fwp_wake_io+0x4c>
    428c:	f9009064 	str	x4, [x3, #288]
    4290:	91080023 	add	x3, x1, #0x200
    4294:	f900943f 	str	xzr, [x1, #296]
    4298:	3c918060 	stur	q0, [x3, #-232]
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	f9402843 	ldr	x3, [x2, #80]
    42a4:	f2001c7f 	tst	x3, #0xff000000ff
    42a8:	54fffde1 	b.ne	4264 <fwp_wake_io+0x20>  // b.any
    42ac:	39015047 	strb	w7, [x2, #84]
    42b0:	f900805f 	str	xzr, [x2, #256]
    42b4:	b40001e6 	cbz	x6, 42f0 <fwp_wake_io+0xac>
    42b8:	f90080c2 	str	x2, [x6, #256]
    42bc:	aa0203e6 	mov	x6, x2
    42c0:	52800028 	mov	w8, #0x1                   	// #1
    42c4:	aa0103e2 	mov	x2, x1
    42c8:	b5fffd21 	cbnz	x1, 426c <fwp_wake_io+0x28>
    42cc:	3400006a 	cbz	w10, 42d8 <fwp_wake_io+0x94>
    42d0:	91018120 	add	x0, x9, #0x60
    42d4:	f900640b 	str	x11, [x0, #200]
    42d8:	34000068 	cbz	w8, 42e4 <fwp_wake_io+0xa0>
    42dc:	91018129 	add	x9, x9, #0x60
    42e0:	f9006126 	str	x6, [x9, #192]
    42e4:	d65f03c0 	ret
    42e8:	f90000a3 	str	x3, [x5]
    42ec:	17ffffe7 	b	4288 <fwp_wake_io+0x44>
    42f0:	aa0203eb 	mov	x11, x2
    42f4:	5280002a 	mov	w10, #0x1                   	// #1
    42f8:	17fffff1 	b	42bc <fwp_wake_io+0x78>
    42fc:	d503201f 	nop

0000000000004300 <ad_raw_free.part.0>:
    4300:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	91118082 	add	x2, x4, #0x460
    430c:	14000005 	b	4320 <ad_raw_free.part.0+0x20>
    4310:	91000421 	add	x1, x1, #0x1
    4314:	91006042 	add	x2, x2, #0x18
    4318:	f140043f 	cmp	x1, #0x1, lsl #12
    431c:	54000220 	b.eq	4360 <ad_raw_free.part.0+0x60>  // b.none
    4320:	f9400043 	ldr	x3, [x2]
    4324:	eb03001f 	cmp	x0, x3
    4328:	54ffff41 	b.ne	4310 <ad_raw_free.part.0+0x10>  // b.any
    432c:	8b010421 	add	x1, x1, x1, lsl #1
    4330:	91118084 	add	x4, x4, #0x460
    4334:	900000e2 	adrp	x2, 20000 <__data_start>
    4338:	91018042 	add	x2, x2, #0x60
    433c:	8b010c81 	add	x1, x4, x1, lsl #3
    4340:	b9401024 	ldr	w4, [x1, #16]
    4344:	f9400425 	ldr	x5, [x1, #8]
    4348:	a9007c3f 	stp	xzr, xzr, [x1]
    434c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4350:	f900083f 	str	xzr, [x1, #16]
    4354:	cb050061 	sub	x1, x3, x5
    4358:	f8247841 	str	x1, [x2, x4, lsl #3]
    435c:	17fff95d 	b	28d0 <free@plt>
    4360:	f100001f 	cmp	x0, #0x0
    4364:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x400>
    4368:	91322021 	add	x1, x1, #0xc88
    436c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4370:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4374:	9131c000 	add	x0, x0, #0xc70
    4378:	910003fd 	mov	x29, sp
    437c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4380:	97fffbe0 	bl	3300 <ad_raw_fail>

0000000000004384 <fwp_tape_buffers_dispose>:
    4384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4388:	910003fd 	mov	x29, sp
    438c:	f9000bf3 	str	x19, [sp, #16]
    4390:	aa0003f3 	mov	x19, x0
    4394:	f9400000 	ldr	x0, [x0]
    4398:	b4000040 	cbz	x0, 43a0 <fwp_tape_buffers_dispose+0x1c>
    439c:	97ffffd9 	bl	4300 <ad_raw_free.part.0>
    43a0:	f9400a60 	ldr	x0, [x19, #16]
    43a4:	b4000040 	cbz	x0, 43ac <fwp_tape_buffers_dispose+0x28>
    43a8:	97ffffd6 	bl	4300 <ad_raw_free.part.0>
    43ac:	f9401260 	ldr	x0, [x19, #32]
    43b0:	b4000040 	cbz	x0, 43b8 <fwp_tape_buffers_dispose+0x34>
    43b4:	97ffffd3 	bl	4300 <ad_raw_free.part.0>
    43b8:	4f000400 	movi	v0.4s, #0x0
    43bc:	f9001a7f 	str	xzr, [x19, #48]
    43c0:	ad000260 	stp	q0, q0, [x19]
    43c4:	3d800a60 	str	q0, [x19, #32]
    43c8:	f9400bf3 	ldr	x19, [sp, #16]
    43cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43d0:	d65f03c0 	ret

00000000000043d4 <ad_raw_realloc>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	f90013f5 	str	x21, [sp, #32]
    43e4:	b40005a1 	cbz	x1, 4498 <ad_raw_realloc+0xc4>
    43e8:	aa0103f4 	mov	x20, x1
    43ec:	2a0203f5 	mov	w21, w2
    43f0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    43f4:	d2800004 	mov	x4, #0x0                   	// #0
    43f8:	91118025 	add	x5, x1, #0x460
    43fc:	14000005 	b	4410 <ad_raw_realloc+0x3c>
    4400:	91000484 	add	x4, x4, #0x1
    4404:	910060a5 	add	x5, x5, #0x18
    4408:	f140049f 	cmp	x4, #0x1, lsl #12
    440c:	54000320 	b.eq	4470 <ad_raw_realloc+0x9c>  // b.none
    4410:	f94000a6 	ldr	x6, [x5]
    4414:	eb06001f 	cmp	x0, x6
    4418:	54ffff41 	b.ne	4400 <ad_raw_realloc+0x2c>  // b.any
    441c:	8b040484 	add	x4, x4, x4, lsl #1
    4420:	91118021 	add	x1, x1, #0x460
    4424:	8b040c33 	add	x19, x1, x4, lsl #3
    4428:	b4000080 	cbz	x0, 4438 <ad_raw_realloc+0x64>
    442c:	b9401261 	ldr	w1, [x19, #16]
    4430:	6b15003f 	cmp	w1, w21
    4434:	540002c1 	b.ne	448c <ad_raw_realloc+0xb8>  // b.any
    4438:	aa1403e1 	mov	x1, x20
    443c:	97fff8f1 	bl	2800 <realloc@plt>
    4440:	aa0003ed 	mov	x13, x0
    4444:	b40000c0 	cbz	x0, 445c <ad_raw_realloc+0x88>
    4448:	2a1503e3 	mov	w3, w21
    444c:	aa1403e2 	mov	x2, x20
    4450:	aa1303e0 	mov	x0, x19
    4454:	aa0d03e1 	mov	x1, x13
    4458:	97fffaae 	bl	2f10 <ad_raw_record>
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	aa0d03e0 	mov	x0, x13
    4464:	f94013f5 	ldr	x21, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	f100001f 	cmp	x0, #0x0
    4474:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x400>
    4478:	91322021 	add	x1, x1, #0xc88
    447c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4480:	9131c000 	add	x0, x0, #0xc70
    4484:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4488:	97fffb9e 	bl	3300 <ad_raw_fail>
    448c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4490:	91332000 	add	x0, x0, #0xcc8
    4494:	97fffb9b 	bl	3300 <ad_raw_fail>
    4498:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    449c:	9132a000 	add	x0, x0, #0xca8
    44a0:	97fffb98 	bl	3300 <ad_raw_fail>

00000000000044a4 <fwp_tape_buffers_release>:
    44a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f4 	mov	x20, x0
    44b4:	f9401400 	ldr	x0, [x0, #40]
    44b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44bc:	b7f80560 	tbnz	x0, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c0:	f9401a93 	ldr	x19, [x20, #48]
    44c4:	b7f80533 	tbnz	x19, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    44cc:	eb01001f 	cmp	x0, x1
    44d0:	540004c8 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44d4:	8b000400 	add	x0, x0, x0, lsl #1
    44d8:	d2a00101 	mov	x1, #0x80000               	// #524288
    44dc:	d37df000 	lsl	x0, x0, #3
    44e0:	cb000021 	sub	x1, x1, x0
    44e4:	eb410e7f 	cmp	x19, x1, lsr #3
    44e8:	54000408 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44ec:	8b130c13 	add	x19, x0, x19, lsl #3
    44f0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    44f4:	91338000 	add	x0, x0, #0xce0
    44f8:	97fff92a 	bl	29a0 <getenv@plt>
    44fc:	b4000080 	cbz	x0, 450c <fwp_tape_buffers_release+0x68>
    4500:	39400001 	ldrb	w1, [x0]
    4504:	7100c03f 	cmp	w1, #0x30
    4508:	54000880 	b.eq	4618 <fwp_tape_buffers_release+0x174>  // b.none
    450c:	d1000661 	sub	x1, x19, #0x1
    4510:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4514:	eb00003f 	cmp	x1, x0
    4518:	54000328 	b.hi	457c <fwp_tape_buffers_release+0xd8>  // b.pmore
    451c:	900000f5 	adrp	x21, 20000 <__data_start>
    4520:	f9001bf7 	str	x23, [sp, #48]
    4524:	910182b7 	add	x23, x21, #0x60
    4528:	910382f6 	add	x22, x23, #0xe0
    452c:	aa1603e0 	mov	x0, x22
    4530:	97ffff95 	bl	4384 <fwp_tape_buffers_dispose>
    4534:	ad400a81 	ldp	q1, q2, [x20]
    4538:	f9008ef3 	str	x19, [x23, #280]
    453c:	4f000400 	movi	v0.4s, #0x0
    4540:	ad000ac1 	stp	q1, q2, [x22]
    4544:	3dc00a81 	ldr	q1, [x20, #32]
    4548:	3d800ac1 	str	q1, [x22, #32]
    454c:	f9401a80 	ldr	x0, [x20, #48]
    4550:	f9001ac0 	str	x0, [x22, #48]
    4554:	f9001a9f 	str	xzr, [x20, #48]
    4558:	ad000280 	stp	q0, q0, [x20]
    455c:	3d800a80 	str	q0, [x20, #32]
    4560:	f9401bf7 	ldr	x23, [sp, #48]
    4564:	1400000b 	b	4590 <fwp_tape_buffers_release+0xec>
    4568:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    456c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4570:	91338000 	add	x0, x0, #0xce0
    4574:	97fff90b 	bl	29a0 <getenv@plt>
    4578:	b5fffc40 	cbnz	x0, 4500 <fwp_tape_buffers_release+0x5c>
    457c:	aa1403e0 	mov	x0, x20
    4580:	97ffff81 	bl	4384 <fwp_tape_buffers_dispose>
    4584:	900000f5 	adrp	x21, 20000 <__data_start>
    4588:	910182a0 	add	x0, x21, #0x60
    458c:	f9408c13 	ldr	x19, [x0, #280]
    4590:	910182a2 	add	x2, x21, #0x60
    4594:	f9409044 	ldr	x4, [x2, #288]
    4598:	a9400c45 	ldp	x5, x3, [x2]
    459c:	8b040481 	add	x1, x4, x4, lsl #1
    45a0:	f9400840 	ldr	x0, [x2, #16]
    45a4:	8b010881 	add	x1, x4, x1, lsl #2
    45a8:	f9400c44 	ldr	x4, [x2, #24]
    45ac:	8b0300a3 	add	x3, x5, x3
    45b0:	d37df021 	lsl	x1, x1, #3
    45b4:	8b040000 	add	x0, x0, x4
    45b8:	8b030000 	add	x0, x0, x3
    45bc:	eb05003f 	cmp	x1, x5
    45c0:	54000321 	b.ne	4624 <fwp_tape_buffers_release+0x180>  // b.any
    45c4:	8b130023 	add	x3, x1, x19
    45c8:	eb00007f 	cmp	x3, x0
    45cc:	540002c8 	b.hi	4624 <fwp_tape_buffers_release+0x180>  // b.pmore
    45d0:	f9405c43 	ldr	x3, [x2, #184]
    45d4:	f140087f 	cmp	x3, #0x2, lsl #12
    45d8:	540002e0 	b.eq	4634 <fwp_tape_buffers_release+0x190>  // b.none
    45dc:	8b030464 	add	x4, x3, x3, lsl #1
    45e0:	90000165 	adrp	x5, 30000 <alt.5+0xfba0>
    45e4:	911180a5 	add	x5, x5, #0x460
    45e8:	cb010000 	sub	x0, x0, x1
    45ec:	d37df084 	lsl	x4, x4, #3
    45f0:	cb130000 	sub	x0, x0, x19
    45f4:	8b0400a6 	add	x6, x5, x4
    45f8:	91000463 	add	x3, x3, #0x1
    45fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4600:	f82468a1 	str	x1, [x5, x4]
    4604:	a90080d3 	stp	x19, x0, [x6, #8]
    4608:	f9005c43 	str	x3, [x2, #184]
    460c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4610:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4614:	d65f03c0 	ret
    4618:	39400400 	ldrb	w0, [x0, #1]
    461c:	34fffb00 	cbz	w0, 457c <fwp_tape_buffers_release+0xd8>
    4620:	17ffffbb 	b	450c <fwp_tape_buffers_release+0x68>
    4624:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4628:	9133e000 	add	x0, x0, #0xcf8
    462c:	f9001bf7 	str	x23, [sp, #48]
    4630:	97fffb34 	bl	3300 <ad_raw_fail>
    4634:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4638:	9134a000 	add	x0, x0, #0xd28
    463c:	f9001bf7 	str	x23, [sp, #48]
    4640:	97fffb30 	bl	3300 <ad_raw_fail>

0000000000004644 <fwp_poll_events>:
    4644:	d10103ff 	sub	sp, sp, #0x40
    4648:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    464c:	f947f400 	ldr	x0, [x0, #4072]
    4650:	a9027bfd 	stp	x29, x30, [sp, #32]
    4654:	910083fd 	add	x29, sp, #0x20
    4658:	a90353f3 	stp	x19, x20, [sp, #48]
    465c:	900000f4 	adrp	x20, 20000 <__data_start>
    4660:	f9400001 	ldr	x1, [x0]
    4664:	f9000fe1 	str	x1, [sp, #24]
    4668:	d2800001 	mov	x1, #0x0                   	// #0
    466c:	97fffca5 	bl	3900 <fwp_now_ns>
    4670:	91018281 	add	x1, x20, #0x60
    4674:	f9409433 	ldr	x19, [x1, #296]
    4678:	b4000e73 	cbz	x19, 4844 <fwp_poll_events+0x200>
    467c:	aa1303e1 	mov	x1, x19
    4680:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4684:	14000005 	b	4698 <fwp_poll_events+0x54>
    4688:	f9408821 	ldr	x1, [x1, #272]
    468c:	eb03005f 	cmp	x2, x3
    4690:	9a83d042 	csel	x2, x2, x3, le
    4694:	b40000c1 	cbz	x1, 46ac <fwp_poll_events+0x68>
    4698:	f9403423 	ldr	x3, [x1, #104]
    469c:	b6ffff62 	tbz	x2, #63, 4688 <fwp_poll_events+0x44>
    46a0:	f9408821 	ldr	x1, [x1, #272]
    46a4:	aa0303e2 	mov	x2, x3
    46a8:	b5ffff81 	cbnz	x1, 4698 <fwp_poll_events+0x54>
    46ac:	b7f80cc2 	tbnz	x2, #63, 4844 <fwp_poll_events+0x200>
    46b0:	cb000042 	sub	x2, x2, x0
    46b4:	f100005f 	cmp	x2, #0x0
    46b8:	540005ad 	b.le	476c <fwp_poll_events+0x128>
    46bc:	d2869b60 	mov	x0, #0x34db                	// #13531
    46c0:	d2884801 	mov	x1, #0x4240                	// #16960
    46c4:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    46c8:	f2a001e1 	movk	x1, #0xf, lsl #16
    46cc:	f2dbd040 	movk	x0, #0xde82, lsl #32
    46d0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    46d4:	f2e86360 	movk	x0, #0x431b, lsl #48
    46d8:	9b407c40 	smulh	x0, x2, x0
    46dc:	9352fc00 	asr	x0, x0, #18
    46e0:	cb82fc00 	sub	x0, x0, x2, asr #63
    46e4:	9b018802 	msub	x2, x0, x1, x2
    46e8:	f100005f 	cmp	x2, #0x0
    46ec:	9a800400 	cinc	x0, x0, ne	// ne = any
    46f0:	eb03001f 	cmp	x0, x3
    46f4:	540009ec 	b.gt	4830 <fwp_poll_events+0x1ec>
    46f8:	340003a0 	cbz	w0, 476c <fwp_poll_events+0x128>
    46fc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4700:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4704:	72a20c42 	movk	w2, #0x1062, lsl #16
    4708:	9ba27c02 	umull	x2, w0, w2
    470c:	d366fc43 	lsr	x3, x2, #38
    4710:	aa0303e2 	mov	x2, x3
    4714:	1b048063 	msub	w3, w3, w4, w0
    4718:	9b217c63 	smull	x3, w3, w1
    471c:	d2800001 	mov	x1, #0x0                   	// #0
    4720:	910023e0 	add	x0, sp, #0x8
    4724:	a9008fe2 	stp	x2, x3, [sp, #8]
    4728:	97fff86e 	bl	28e0 <nanosleep@plt>
    472c:	91018280 	add	x0, x20, #0x60
    4730:	f9409413 	ldr	x19, [x0, #296]
    4734:	97fffc73 	bl	3900 <fwp_now_ns>
    4738:	aa0003e6 	mov	x6, x0
    473c:	b50001d3 	cbnz	x19, 4774 <fwp_poll_events+0x130>
    4740:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4744:	f947f400 	ldr	x0, [x0, #4072]
    4748:	f9400fe2 	ldr	x2, [sp, #24]
    474c:	f9400001 	ldr	x1, [x0]
    4750:	eb010042 	subs	x2, x2, x1
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	540008c1 	b.ne	4870 <fwp_poll_events+0x22c>  // b.any
    475c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4760:	a94353f3 	ldp	x19, x20, [sp, #48]
    4764:	910103ff 	add	sp, sp, #0x40
    4768:	d65f03c0 	ret
    476c:	97fffc65 	bl	3900 <fwp_now_ns>
    4770:	aa0003e6 	mov	x6, x0
    4774:	4f000400 	movi	v0.4s, #0x0
    4778:	91018288 	add	x8, x20, #0x60
    477c:	52800027 	mov	w7, #0x1                   	// #1
    4780:	f9403661 	ldr	x1, [x19, #104]
    4784:	aa1303e5 	mov	x5, x19
    4788:	f9408a73 	ldr	x19, [x19, #272]
    478c:	eb06003f 	cmp	x1, x6
    4790:	5400032c 	b.gt	47f4 <fwp_poll_events+0x1b0>
    4794:	394154a0 	ldrb	w0, [x5, #85]
    4798:	36000120 	tbz	w0, #0, 47bc <fwp_poll_events+0x178>
    479c:	f94084a0 	ldr	x0, [x5, #264]
    47a0:	b40003c0 	cbz	x0, 4818 <fwp_poll_events+0x1d4>
    47a4:	f9008813 	str	x19, [x0, #272]
    47a8:	b4000053 	cbz	x19, 47b0 <fwp_poll_events+0x16c>
    47ac:	f9008660 	str	x0, [x19, #264]
    47b0:	910800a0 	add	x0, x5, #0x200
    47b4:	390154bf 	strb	wzr, [x5, #85]
    47b8:	3c908000 	stur	q0, [x0, #-248]
    47bc:	f94030a0 	ldr	x0, [x5, #96]
    47c0:	390158a7 	strb	w7, [x5, #86]
    47c4:	f100001f 	cmp	x0, #0x0
    47c8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    47cc:	5400018d 	b.le	47fc <fwp_poll_events+0x1b8>
    47d0:	f94028a0 	ldr	x0, [x5, #80]
    47d4:	f2001c1f 	tst	x0, #0xff000000ff
    47d8:	540000e1 	b.ne	47f4 <fwp_poll_events+0x1b0>  // b.any
    47dc:	f9406100 	ldr	x0, [x8, #192]
    47e0:	390150a7 	strb	w7, [x5, #84]
    47e4:	f90080bf 	str	xzr, [x5, #256]
    47e8:	b40001e0 	cbz	x0, 4824 <fwp_poll_events+0x1e0>
    47ec:	f9006105 	str	x5, [x8, #192]
    47f0:	f9008005 	str	x5, [x0, #256]
    47f4:	b5fffc73 	cbnz	x19, 4780 <fwp_poll_events+0x13c>
    47f8:	17ffffd2 	b	4740 <fwp_poll_events+0xfc>
    47fc:	394144a0 	ldrb	w0, [x5, #81]
    4800:	3707fe80 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    4804:	394140a0 	ldrb	w0, [x5, #80]
    4808:	3707fe40 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    480c:	aa0503e0 	mov	x0, x5
    4810:	97fffb98 	bl	3670 <fwp_cancel_tree.part.0>
    4814:	17ffffef 	b	47d0 <fwp_poll_events+0x18c>
    4818:	91018281 	add	x1, x20, #0x60
    481c:	f9009433 	str	x19, [x1, #296]
    4820:	17ffffe2 	b	47a8 <fwp_poll_events+0x164>
    4824:	f9006105 	str	x5, [x8, #192]
    4828:	f9006505 	str	x5, [x8, #200]
    482c:	17fffff2 	b	47f4 <fwp_poll_events+0x1b0>
    4830:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4834:	d2989362 	mov	x2, #0xc49b                	// #50331
    4838:	f2a4d203 	movk	x3, #0x2690, lsl #16
    483c:	f2a00402 	movk	x2, #0x20, lsl #16
    4840:	17ffffb7 	b	471c <fwp_poll_events+0xd8>
    4844:	97fff9ec 	bl	2ff4 <fwp_flush>
    4848:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    484c:	f947e863 	ldr	x3, [x3, #4048]
    4850:	d2800562 	mov	x2, #0x2b                  	// #43
    4854:	d2800021 	mov	x1, #0x1                   	// #1
    4858:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    485c:	91352000 	add	x0, x0, #0xd48
    4860:	f9400063 	ldr	x3, [x3]
    4864:	97fff82b 	bl	2910 <fwrite@plt>
    4868:	52800ca0 	mov	w0, #0x65                  	// #101
    486c:	97fff795 	bl	26c0 <exit@plt>
    4870:	97fff7e8 	bl	2810 <__stack_chk_fail@plt>

0000000000004874 <fwp_rc_wide_dup>:
    4874:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4878:	910003fd 	mov	x29, sp
    487c:	a90153f3 	stp	x19, x20, [sp, #16]
    4880:	aa0003f3 	mov	x19, x0
    4884:	ca404400 	eor	x0, x0, x0, lsr #17
    4888:	f90013f5 	str	x21, [sp, #32]
    488c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4890:	ca402400 	eor	x0, x0, x0, lsr #9
    4894:	911902a2 	add	x2, x21, #0x640
    4898:	92401c00 	and	x0, x0, #0xff
    489c:	910a2403 	add	x3, x0, #0x289
    48a0:	8b000c40 	add	x0, x2, x0, lsl #3
    48a4:	8b030c54 	add	x20, x2, x3, lsl #3
    48a8:	f94a2401 	ldr	x1, [x0, #5192]
    48ac:	b50000a1 	cbnz	x1, 48c0 <fwp_rc_wide_dup+0x4c>
    48b0:	1400002d 	b	4964 <fwp_rc_wide_dup+0xf0>
    48b4:	91004034 	add	x20, x1, #0x10
    48b8:	f9400821 	ldr	x1, [x1, #16]
    48bc:	b4000241 	cbz	x1, 4904 <fwp_rc_wide_dup+0x90>
    48c0:	f9400022 	ldr	x2, [x1]
    48c4:	eb02027f 	cmp	x19, x2
    48c8:	54ffff61 	b.ne	48b4 <fwp_rc_wide_dup+0x40>  // b.any
    48cc:	f9400281 	ldr	x1, [x20]
    48d0:	39400260 	ldrb	w0, [x19]
    48d4:	7103f81f 	cmp	w0, #0xfe
    48d8:	54000220 	b.eq	491c <fwp_rc_wide_dup+0xa8>  // b.none
    48dc:	b40001a1 	cbz	x1, 4910 <fwp_rc_wide_dup+0x9c>
    48e0:	f9400420 	ldr	x0, [x1, #8]
    48e4:	b100041f 	cmn	x0, #0x1
    48e8:	540004a0 	b.eq	497c <fwp_rc_wide_dup+0x108>  // b.none
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f9000420 	str	x0, [x1, #8]
    48f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f8:	f94013f5 	ldr	x21, [sp, #32]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	39400260 	ldrb	w0, [x19]
    4908:	7103f81f 	cmp	w0, #0xfe
    490c:	540000a0 	b.eq	4920 <fwp_rc_wide_dup+0xac>  // b.none
    4910:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4914:	91368000 	add	x0, x0, #0xda0
    4918:	97fffb9a 	bl	3780 <fwp_trap>
    491c:	b5000281 	cbnz	x1, 496c <fwp_rc_wide_dup+0xf8>
    4920:	d2800300 	mov	x0, #0x18                  	// #24
    4924:	97fff7a3 	bl	27b0 <malloc@plt>
    4928:	b4000280 	cbz	x0, 4978 <fwp_rc_wide_dup+0x104>
    492c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4930:	a9000413 	stp	x19, x1, [x0]
    4934:	911902b5 	add	x21, x21, #0x640
    4938:	f900081f 	str	xzr, [x0, #16]
    493c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4940:	f9000280 	str	x0, [x20]
    4944:	39000261 	strb	w1, [x19]
    4948:	f94e26a0 	ldr	x0, [x21, #7240]
    494c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4950:	91000400 	add	x0, x0, #0x1
    4954:	f90e26a0 	str	x0, [x21, #7240]
    4958:	f94013f5 	ldr	x21, [sp, #32]
    495c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4960:	d65f03c0 	ret
    4964:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4968:	17ffffda 	b	48d0 <fwp_rc_wide_dup+0x5c>
    496c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4970:	9135e000 	add	x0, x0, #0xd78
    4974:	97fffb83 	bl	3780 <fwp_trap>
    4978:	97fff9de 	bl	30f0 <fwp_heap_oom>
    497c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4980:	91372000 	add	x0, x0, #0xdc8
    4984:	97fffb7f 	bl	3780 <fwp_trap>
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_rc_forget_slot>:
    4990:	aa0003e1 	mov	x1, x0
    4994:	39400000 	ldrb	w0, [x0]
    4998:	7103fc1f 	cmp	w0, #0xff
    499c:	54000040 	b.eq	49a4 <fwp_rc_forget_slot+0x14>  // b.none
    49a0:	d65f03c0 	ret
    49a4:	ca414420 	eor	x0, x1, x1, lsr #17
    49a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49ac:	ca402400 	eor	x0, x0, x0, lsr #9
    49b0:	910003fd 	mov	x29, sp
    49b4:	92401c00 	and	x0, x0, #0xff
    49b8:	f9000bf3 	str	x19, [sp, #16]
    49bc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    49c0:	91190262 	add	x2, x19, #0x640
    49c4:	910a2403 	add	x3, x0, #0x289
    49c8:	8b000c40 	add	x0, x2, x0, lsl #3
    49cc:	8b030c43 	add	x3, x2, x3, lsl #3
    49d0:	f94a2400 	ldr	x0, [x0, #5192]
    49d4:	b50000a0 	cbnz	x0, 49e8 <fwp_rc_forget_slot+0x58>
    49d8:	14000011 	b	4a1c <fwp_rc_forget_slot+0x8c>
    49dc:	91004003 	add	x3, x0, #0x10
    49e0:	f9400800 	ldr	x0, [x0, #16]
    49e4:	b40001c0 	cbz	x0, 4a1c <fwp_rc_forget_slot+0x8c>
    49e8:	f9400002 	ldr	x2, [x0]
    49ec:	eb02003f 	cmp	x1, x2
    49f0:	54ffff61 	b.ne	49dc <fwp_rc_forget_slot+0x4c>  // b.any
    49f4:	f9400801 	ldr	x1, [x0, #16]
    49f8:	91190273 	add	x19, x19, #0x640
    49fc:	f9000061 	str	x1, [x3]
    4a00:	97fff7b4 	bl	28d0 <free@plt>
    4a04:	f94e2660 	ldr	x0, [x19, #7240]
    4a08:	d1000400 	sub	x0, x0, #0x1
    4a0c:	f90e2660 	str	x0, [x19, #7240]
    4a10:	f9400bf3 	ldr	x19, [sp, #16]
    4a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a18:	d65f03c0 	ret
    4a1c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    4a20:	91368000 	add	x0, x0, #0xda0
    4a24:	97fffb57 	bl	3780 <fwp_trap>
    4a28:	d503201f 	nop
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_rc_prepare_chunk>:
    4a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    4a40:	911902c2 	add	x2, x22, #0x640
    4a44:	b9401c03 	ldr	w3, [x0, #28]
    4a48:	aa0103f5 	mov	x21, x1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	aa0003f4 	mov	x20, x0
    4a54:	f94e2440 	ldr	x0, [x2, #7240]
    4a58:	b4000440 	cbz	x0, 4ae0 <fwp_rc_prepare_chunk+0xb0>
    4a5c:	d2800013 	mov	x19, #0x0                   	// #0
    4a60:	35000203 	cbnz	w3, 4aa0 <fwp_rc_prepare_chunk+0x70>
    4a64:	b4000361 	cbz	x1, 4ad0 <fwp_rc_prepare_chunk+0xa0>
    4a68:	f9401280 	ldr	x0, [x20, #32]
    4a6c:	97fff799 	bl	28d0 <free@plt>
    4a70:	aa1503e0 	mov	x0, x21
    4a74:	d2800021 	mov	x1, #0x1                   	// #1
    4a78:	97fff75e 	bl	27f0 <calloc@plt>
    4a7c:	f9001280 	str	x0, [x20, #32]
    4a80:	b5000460 	cbnz	x0, 4b0c <fwp_rc_prepare_chunk+0xdc>
    4a84:	97fff99b 	bl	30f0 <fwp_heap_oom>
    4a88:	97ffffc2 	bl	4990 <fwp_rc_forget_slot>
    4a8c:	91000673 	add	x19, x19, #0x1
    4a90:	b9401e83 	ldr	w3, [x20, #28]
    4a94:	eb13007f 	cmp	x3, x19
    4a98:	54000169 	b.ls	4ac4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4a9c:	d503201f 	nop
    4aa0:	f9401283 	ldr	x3, [x20, #32]
    4aa4:	8b130060 	add	x0, x3, x19
    4aa8:	38736863 	ldrb	w3, [x3, x19]
    4aac:	7103fc7f 	cmp	w3, #0xff
    4ab0:	54fffec0 	b.eq	4a88 <fwp_rc_prepare_chunk+0x58>  // b.none
    4ab4:	b9401e83 	ldr	w3, [x20, #28]
    4ab8:	91000673 	add	x19, x19, #0x1
    4abc:	eb13007f 	cmp	x3, x19
    4ac0:	54ffff08 	b.hi	4aa0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4ac4:	eb0302bf 	cmp	x21, x3
    4ac8:	54000121 	b.ne	4aec <fwp_rc_prepare_chunk+0xbc>  // b.any
    4acc:	b5000335 	cbnz	x21, 4b30 <fwp_rc_prepare_chunk+0x100>
    4ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4adc:	d65f03c0 	ret
    4ae0:	2a0303e3 	mov	w3, w3
    4ae4:	eb0302bf 	cmp	x21, x3
    4ae8:	54ffff20 	b.eq	4acc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4aec:	911902c2 	add	x2, x22, #0x640
    4af0:	f9401280 	ldr	x0, [x20, #32]
    4af4:	f94e2841 	ldr	x1, [x2, #7248]
    4af8:	cb030021 	sub	x1, x1, x3
    4afc:	f90e2841 	str	x1, [x2, #7248]
    4b00:	97fff774 	bl	28d0 <free@plt>
    4b04:	b5fffb75 	cbnz	x21, 4a70 <fwp_rc_prepare_chunk+0x40>
    4b08:	f900129f 	str	xzr, [x20, #32]
    4b0c:	911902d6 	add	x22, x22, #0x640
    4b10:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b14:	b9001e95 	str	w21, [x20, #28]
    4b18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b1c:	8b150000 	add	x0, x0, x21
    4b20:	f90e2ac0 	str	x0, [x22, #7248]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	f9401280 	ldr	x0, [x20, #32]
    4b34:	aa1503e2 	mov	x2, x21
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	52800001 	mov	w1, #0x0                   	// #0
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b48:	17fff726 	b	27e0 <memset@plt>
    4b4c:	d503201f 	nop

0000000000004b50 <fwp_heap_refill>:
    4b50:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b54:	910003fd 	mov	x29, sp
    4b58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b5c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4b60:	911902b5 	add	x21, x21, #0x640
    4b64:	aa0003f6 	mov	x22, x0
    4b68:	d2800020 	mov	x0, #0x1                   	// #1
    4b6c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b70:	a90363f7 	stp	x23, x24, [sp, #48]
    4b74:	2a0103f7 	mov	w23, w1
    4b78:	2a0203f8 	mov	w24, w2
    4b7c:	97fff96d 	bl	3130 <fwp_heap_chunks>
    4b80:	aa0003f3 	mov	x19, x0
    4b84:	f949fea2 	ldr	x2, [x21, #5112]
    4b88:	8b000800 	add	x0, x0, x0, lsl #2
    4b8c:	2a1703e1 	mov	w1, w23
    4b90:	52800025 	mov	w5, #0x1                   	// #1
    4b94:	d37df000 	lsl	x0, x0, #3
    4b98:	910f0021 	add	x1, x1, #0x3c0
    4b9c:	8b000054 	add	x20, x2, x0
    4ba0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ba4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ba8:	38206845 	strb	w5, [x2, x0]
    4bac:	aa1403e0 	mov	x0, x20
    4bb0:	39000698 	strb	w24, [x20, #1]
    4bb4:	39000a97 	strb	w23, [x20, #2]
    4bb8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4bbc:	b9000681 	str	w1, [x20, #4]
    4bc0:	2a0103e5 	mov	w5, w1
    4bc4:	8b0300a2 	add	x2, x5, x3
    4bc8:	1ac10881 	udiv	w1, w4, w1
    4bcc:	9ac50842 	udiv	x2, x2, x5
    4bd0:	b9000a81 	str	w1, [x20, #8]
    4bd4:	92404021 	and	x1, x1, #0x1ffff
    4bd8:	b9001a82 	str	w2, [x20, #24]
    4bdc:	97ffff95 	bl	4a30 <fwp_rc_prepare_chunk>
    4be0:	f949daa0 	ldr	x0, [x21, #5040]
    4be4:	29408a81 	ldp	w1, w2, [x20, #4]
    4be8:	8b134000 	add	x0, x0, x19, lsl #16
    4bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf0:	8b214003 	add	x3, x0, w1, uxtw
    4bf4:	9ba20021 	umaddl	x1, w1, w2, x0
    4bf8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bfc:	a90086c3 	stp	x3, x1, [x22, #8]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c08:	d65f03c0 	ret
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_mem_free>:
    4c10:	b40003c0 	cbz	x0, 4c88 <fwp_mem_free+0x78>
    4c14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c18:	910003fd 	mov	x29, sp
    4c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c20:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4c24:	911902a1 	add	x1, x21, #0x640
    4c28:	a90153f3 	stp	x19, x20, [sp, #16]
    4c2c:	aa0003f3 	mov	x19, x0
    4c30:	f949d823 	ldr	x3, [x1, #5040]
    4c34:	f949ec22 	ldr	x2, [x1, #5080]
    4c38:	cb030000 	sub	x0, x0, x3
    4c3c:	eb02401f 	cmp	x0, x2, lsl #16
    4c40:	540001c2 	b.cs	4c78 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c44:	d350fc16 	lsr	x22, x0, #16
    4c48:	a90363f7 	stp	x23, x24, [sp, #48]
    4c4c:	f949fc22 	ldr	x2, [x1, #5112]
    4c50:	8b160ad4 	add	x20, x22, x22, lsl #2
    4c54:	d37df294 	lsl	x20, x20, #3
    4c58:	ab140057 	adds	x23, x2, x20
    4c5c:	540000c0 	b.eq	4c74 <fwp_mem_free+0x64>  // b.none
    4c60:	38746842 	ldrb	w2, [x2, x20]
    4c64:	7100045f 	cmp	w2, #0x1
    4c68:	54000120 	b.eq	4c8c <fwp_mem_free+0x7c>  // b.none
    4c6c:	7100085f 	cmp	w2, #0x2
    4c70:	540005e0 	b.eq	4d2c <fwp_mem_free+0x11c>  // b.none
    4c74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c80:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c84:	d65f03c0 	ret
    4c88:	d65f03c0 	ret
    4c8c:	f94012f8 	ldr	x24, [x23, #32]
    4c90:	b94006e1 	ldr	w1, [x23, #4]
    4c94:	f90023f9 	str	x25, [sp, #64]
    4c98:	2a0103e2 	mov	w2, w1
    4c9c:	394006f9 	ldrb	w25, [x23, #1]
    4ca0:	39400af4 	ldrb	w20, [x23, #2]
    4ca4:	b4000158 	cbz	x24, 4ccc <fwp_mem_free+0xbc>
    4ca8:	92403e76 	and	x22, x19, #0xffff
    4cac:	9ac20ad6 	udiv	x22, x22, x2
    4cb0:	38766b01 	ldrb	w1, [x24, x22]
    4cb4:	8b160300 	add	x0, x24, x22
    4cb8:	7103fc3f 	cmp	w1, #0xff
    4cbc:	54000980 	b.eq	4dec <fwp_mem_free+0x1dc>  // b.none
    4cc0:	38366b1f 	strb	wzr, [x24, x22]
    4cc4:	b94006e1 	ldr	w1, [x23, #4]
    4cc8:	2a0103e2 	mov	w2, w1
    4ccc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4cd0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4cd4:	cb390000 	sub	x0, x0, w25, uxtb
    4cd8:	8b340074 	add	x20, x3, w20, uxtb
    4cdc:	911902b5 	add	x21, x21, #0x640
    4ce0:	1e630021 	ucvtf	d1, w1
    4ce4:	d37ae400 	lsl	x0, x0, #6
    4ce8:	8b140c14 	add	x20, x0, x20, lsl #3
    4cec:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf0:	f8746aa0 	ldr	x0, [x21, x20]
    4cf4:	f94023f9 	ldr	x25, [sp, #64]
    4cf8:	aa2003e0 	mvn	x0, x0
    4cfc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d00:	f9000260 	str	x0, [x19]
    4d04:	f8346ab3 	str	x19, [x21, x20]
    4d08:	f94a12a0 	ldr	x0, [x21, #5152]
    4d0c:	1e612800 	fadd	d0, d0, d1
    4d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d14:	cb020000 	sub	x0, x0, x2
    4d18:	f90a12a0 	str	x0, [x21, #5152]
    4d1c:	fd0a22a0 	str	d0, [x21, #5184]
    4d20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d24:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d28:	d65f03c0 	ret
    4d2c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d30:	8b000063 	add	x3, x3, x0
    4d34:	eb03027f 	cmp	x19, x3
    4d38:	54fff9e1 	b.ne	4c74 <fwp_mem_free+0x64>  // b.any
    4d3c:	fd400ae1 	ldr	d1, [x23, #16]
    4d40:	fd4a2020 	ldr	d0, [x1, #5184]
    4d44:	f9400ae0 	ldr	x0, [x23, #16]
    4d48:	7e61d821 	ucvtf	d1, d1
    4d4c:	f94a1022 	ldr	x2, [x1, #5152]
    4d50:	f94012f3 	ldr	x19, [x23, #32]
    4d54:	1e612800 	fadd	d0, d0, d1
    4d58:	cb000042 	sub	x2, x2, x0
    4d5c:	f90a1022 	str	x2, [x1, #5152]
    4d60:	fd0a2020 	str	d0, [x1, #5184]
    4d64:	b40000b3 	cbz	x19, 4d78 <fwp_mem_free+0x168>
    4d68:	39400260 	ldrb	w0, [x19]
    4d6c:	7103fc1f 	cmp	w0, #0xff
    4d70:	54000380 	b.eq	4de0 <fwp_mem_free+0x1d0>  // b.none
    4d74:	3900027f 	strb	wzr, [x19]
    4d78:	b9400ee2 	ldr	w2, [x23, #12]
    4d7c:	b4000142 	cbz	x2, 4da4 <fwp_mem_free+0x194>
    4d80:	911902a1 	add	x1, x21, #0x640
    4d84:	8b160040 	add	x0, x2, x22
    4d88:	8b000800 	add	x0, x0, x0, lsl #2
    4d8c:	f949fc21 	ldr	x1, [x1, #5112]
    4d90:	8b140034 	add	x20, x1, x20
    4d94:	8b000c20 	add	x0, x1, x0, lsl #3
    4d98:	3802869f 	strb	wzr, [x20], #40
    4d9c:	eb00029f 	cmp	x20, x0
    4da0:	54ffffc1 	b.ne	4d98 <fwp_mem_free+0x188>  // b.any
    4da4:	911902a0 	add	x0, x21, #0x640
    4da8:	f94a1801 	ldr	x1, [x0, #5168]
    4dac:	f949f803 	ldr	x3, [x0, #5104]
    4db0:	8b020021 	add	x1, x1, x2
    4db4:	f90a1801 	str	x1, [x0, #5168]
    4db8:	eb16007f 	cmp	x3, x22
    4dbc:	54000049 	b.ls	4dc4 <fwp_mem_free+0x1b4>  // b.plast
    4dc0:	f909f816 	str	x22, [x0, #5104]
    4dc4:	911902b5 	add	x21, x21, #0x640
    4dc8:	f949f6a0 	ldr	x0, [x21, #5096]
    4dcc:	eb16001f 	cmp	x0, x22
    4dd0:	54fff529 	b.ls	4c74 <fwp_mem_free+0x64>  // b.plast
    4dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dd8:	f909f6b6 	str	x22, [x21, #5096]
    4ddc:	17ffffa7 	b	4c78 <fwp_mem_free+0x68>
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	97fffeeb 	bl	4990 <fwp_rc_forget_slot>
    4de8:	17ffffe3 	b	4d74 <fwp_mem_free+0x164>
    4dec:	97fffee9 	bl	4990 <fwp_rc_forget_slot>
    4df0:	17ffffb4 	b	4cc0 <fwp_mem_free+0xb0>

0000000000004df4 <fwp_heap_alloc_big>:
    4df4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df8:	910003fd 	mov	x29, sp
    4dfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4e00:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e04:	a90363f7 	stp	x23, x24, [sp, #48]
    4e08:	aa0003f7 	mov	x23, x0
    4e0c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e10:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e14:	eb0002ff 	cmp	x23, x0
    4e18:	54000888 	b.hi	4f28 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e1c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e20:	8b0002f4 	add	x20, x23, x0
    4e24:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4e28:	91190359 	add	x25, x26, #0x640
    4e2c:	d350fe94 	lsr	x20, x20, #16
    4e30:	2a0103f5 	mov	w21, w1
    4e34:	aa1403e0 	mov	x0, x20
    4e38:	97fff8be 	bl	3130 <fwp_heap_chunks>
    4e3c:	f949ff22 	ldr	x2, [x25, #5112]
    4e40:	8b000813 	add	x19, x0, x0, lsl #2
    4e44:	aa0003f8 	mov	x24, x0
    4e48:	52800043 	mov	w3, #0x2                   	// #2
    4e4c:	d37df273 	lsl	x19, x19, #3
    4e50:	d2800021 	mov	x1, #0x1                   	// #1
    4e54:	8b130040 	add	x0, x2, x19
    4e58:	38336843 	strb	w3, [x2, x19]
    4e5c:	39000415 	strb	w21, [x0, #1]
    4e60:	b9000c14 	str	w20, [x0, #12]
    4e64:	f9000817 	str	x23, [x0, #16]
    4e68:	97fffef2 	bl	4a30 <fwp_rc_prepare_chunk>
    4e6c:	f100069f 	cmp	x20, #0x1
    4e70:	54000269 	b.ls	4ebc <fwp_heap_alloc_big+0xc8>  // b.plast
    4e74:	8b180294 	add	x20, x20, x24
    4e78:	9100a273 	add	x19, x19, #0x28
    4e7c:	a90573fb 	stp	x27, x28, [sp, #80]
    4e80:	5280007b 	mov	w27, #0x3                   	// #3
    4e84:	8b140a94 	add	x20, x20, x20, lsl #2
    4e88:	2a1803fc 	mov	w28, w24
    4e8c:	9adb2296 	lsl	x22, x20, x27
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffee4 	bl	4a30 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0x9c>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffc1c 	bl	4084 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff70 	b	4df4 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffeb5 	bl	4b50 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	54000861 	b.ne	51c4 <fwp_heap_alloc+0x134>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	540006e2 	b.cs	5210 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	540002cc 	b.gt	51d8 <fwp_heap_alloc+0x148>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000209 	b.ls	51f4 <fwp_heap_alloc+0x164>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	17ffffe8 	b	5160 <fwp_heap_alloc+0xd0>
    51c4:	a9538c44 	ldp	x4, x3, [x2, #312]
    51c8:	91000484 	add	x4, x4, #0x1
    51cc:	8b000063 	add	x3, x3, x0
    51d0:	a9138c44 	stp	x4, x3, [x2, #312]
    51d4:	17ffffba 	b	50bc <fwp_heap_alloc+0x2c>
    51d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51dc:	fd00a800 	str	d0, [x0, #336]
    51e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f0:	d65f03c0 	ret
    51f4:	7100043f 	cmp	w1, #0x1
    51f8:	8b140085 	add	x5, x4, x20
    51fc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5200:	52800001 	mov	w1, #0x0                   	// #0
    5204:	aa0403e0 	mov	x0, x4
    5208:	f9000465 	str	x5, [x3, #8]
    520c:	17ffffc6 	b	5124 <fwp_heap_alloc+0x94>
    5210:	97fff7b8 	bl	30f0 <fwp_heap_oom>

0000000000005214 <fwp_apply>:
    5214:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5218:	aa0003e6 	mov	x6, x0
    521c:	910003fd 	mov	x29, sp
    5220:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5224:	f947f463 	ldr	x3, [x3, #4072]
    5228:	a90153f3 	stp	x19, x20, [sp, #16]
    522c:	aa0203f4 	mov	x20, x2
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	2a0103f5 	mov	w21, w1
    5238:	52800033 	mov	w19, #0x1                   	// #1
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	f00000d7 	adrp	x23, 20000 <__data_start>
    5244:	910182f7 	add	x23, x23, #0x60
    5248:	a9046bf9 	stp	x25, x26, [sp, #64]
    524c:	d100c3ff 	sub	sp, sp, #0x30
    5250:	f9400060 	ldr	x0, [x3]
    5254:	f81f83a0 	stur	x0, [x29, #-8]
    5258:	d2800000 	mov	x0, #0x0                   	// #0
    525c:	294058c3 	ldp	w3, w22, [x6]
    5260:	910003f8 	mov	x24, sp
    5264:	f9406ae0 	ldr	x0, [x23, #208]
    5268:	710002df 	cmp	w22, #0x0
    526c:	d37be863 	lsl	x3, x3, #5
    5270:	8b030007 	add	x7, x0, x3
    5274:	b8636819 	ldr	w25, [x0, x3]
    5278:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    527c:	54000163 	b.cc	52a8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5280:	f94004e3 	ldr	x3, [x7, #8]
    5284:	34000bd9 	cbz	w25, 53fc <fwp_apply+0x1e8>
    5288:	aa1403e0 	mov	x0, x20
    528c:	d63f0060 	blr	x3
    5290:	aa0003e6 	mov	x6, x0
    5294:	6b1902bf 	cmp	w21, w25
    5298:	54000940 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    529c:	8b394e94 	add	x20, x20, w25, uxtw #3
    52a0:	4b1902b5 	sub	w21, w21, w25
    52a4:	17ffffee 	b	525c <fwp_apply+0x48>
    52a8:	0b1602ba 	add	w26, w21, w22
    52ac:	6b19035f 	cmp	w26, w25
    52b0:	54000543 	b.cc	5358 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    52b4:	7100033f 	cmp	w25, #0x0
    52b8:	4b16033a 	sub	w26, w25, w22
    52bc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52c0:	d37df000 	lsl	x0, x0, #3
    52c4:	91003c00 	add	x0, x0, #0xf
    52c8:	92704c01 	and	x1, x0, #0xfffff0000
    52cc:	927c7c00 	and	x0, x0, #0xffffffff0
    52d0:	cb2163e1 	sub	x1, sp, x1
    52d4:	eb2163ff 	cmp	sp, x1
    52d8:	540000a0 	b.eq	52ec <fwp_apply+0xd8>  // b.none
    52dc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52e0:	f90203ff 	str	xzr, [sp, #1024]
    52e4:	eb2163ff 	cmp	sp, x1
    52e8:	54ffffa1 	b.ne	52dc <fwp_apply+0xc8>  // b.any
    52ec:	92403c00 	and	x0, x0, #0xffff
    52f0:	cb2063ff 	sub	sp, sp, x0
    52f4:	f90003ff 	str	xzr, [sp]
    52f8:	f110001f 	cmp	x0, #0x400
    52fc:	54000962 	b.cs	5428 <fwp_apply+0x214>  // b.hs, b.nlast
    5300:	910020c6 	add	x6, x6, #0x8
    5304:	910043e0 	add	x0, sp, #0x10
    5308:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    530c:	d2800003 	mov	x3, #0x0                   	// #0
    5310:	340000f6 	cbz	w22, 532c <fwp_apply+0x118>
    5314:	d503201f 	nop
    5318:	f86368c4 	ldr	x4, [x6, x3]
    531c:	f8236804 	str	x4, [x0, x3]
    5320:	91002063 	add	x3, x3, #0x8
    5324:	eb0300bf 	cmp	x5, x3
    5328:	54ffff81 	b.ne	5318 <fwp_apply+0x104>  // b.any
    532c:	3400013a 	cbz	w26, 5350 <fwp_apply+0x13c>
    5330:	2a1a03e6 	mov	w6, w26
    5334:	d2800003 	mov	x3, #0x0                   	// #0
    5338:	0b0302c4 	add	w4, w22, w3
    533c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5340:	91000463 	add	x3, x3, #0x1
    5344:	f8247805 	str	x5, [x0, x4, lsl #3]
    5348:	eb0300df 	cmp	x6, x3
    534c:	54ffff61 	b.ne	5338 <fwp_apply+0x124>  // b.any
    5350:	f94004e3 	ldr	x3, [x7, #8]
    5354:	1400002c 	b	5404 <fwp_apply+0x1f0>
    5358:	11000740 	add	w0, w26, #0x1
    535c:	52800041 	mov	w1, #0x2                   	// #2
    5360:	f81e83a6 	stur	x6, [x29, #-24]
    5364:	d37df000 	lsl	x0, x0, #3
    5368:	97ffff4a 	bl	5090 <fwp_heap_alloc>
    536c:	f85e83a6 	ldur	x6, [x29, #-24]
    5370:	aa0003f3 	mov	x19, x0
    5374:	b94000c1 	ldr	w1, [x6]
    5378:	29006801 	stp	w1, w26, [x0]
    537c:	340000b6 	cbz	w22, 5390 <fwp_apply+0x17c>
    5380:	910020c1 	add	x1, x6, #0x8
    5384:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5388:	91002000 	add	x0, x0, #0x8
    538c:	97fff4bd 	bl	2680 <memmove@plt>
    5390:	2a1503e3 	mov	w3, w21
    5394:	d2800000 	mov	x0, #0x0                   	// #0
    5398:	34000135 	cbz	w21, 53bc <fwp_apply+0x1a8>
    539c:	d503201f 	nop
    53a0:	0b0002c1 	add	w1, w22, w0
    53a4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53a8:	8b010e61 	add	x1, x19, x1, lsl #3
    53ac:	91000400 	add	x0, x0, #0x1
    53b0:	f9000422 	str	x2, [x1, #8]
    53b4:	eb00007f 	cmp	x3, x0
    53b8:	54ffff41 	b.ne	53a0 <fwp_apply+0x18c>  // b.any
    53bc:	aa1303e6 	mov	x6, x19
    53c0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53c4:	f947f400 	ldr	x0, [x0, #4072]
    53c8:	f85f83a2 	ldur	x2, [x29, #-8]
    53cc:	f9400001 	ldr	x1, [x0]
    53d0:	eb010042 	subs	x2, x2, x1
    53d4:	d2800001 	mov	x1, #0x0                   	// #0
    53d8:	540002c1 	b.ne	5430 <fwp_apply+0x21c>  // b.any
    53dc:	910003bf 	mov	sp, x29
    53e0:	aa0603e0 	mov	x0, x6
    53e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53f4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53f8:	d65f03c0 	ret
    53fc:	d10043a0 	sub	x0, x29, #0x10
    5400:	5280001a 	mov	w26, #0x0                   	// #0
    5404:	d63f0060 	blr	x3
    5408:	aa0003e6 	mov	x6, x0
    540c:	6b1a02bf 	cmp	w21, w26
    5410:	54fffd80 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    5414:	0b1602b6 	add	w22, w21, w22
    5418:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    541c:	4b1902d5 	sub	w21, w22, w25
    5420:	9100031f 	mov	sp, x24
    5424:	17ffff8e 	b	525c <fwp_apply+0x48>
    5428:	f90203ff 	str	xzr, [sp, #1024]
    542c:	17ffffb5 	b	5300 <fwp_apply+0xec>
    5430:	97fff4f8 	bl	2810 <__stack_chk_fail@plt>

0000000000005434 <fwp_p_ad_push.constprop.0>:
    5434:	f100001f 	cmp	x0, #0x0
    5438:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    543c:	54000eab 	b.lt	5610 <fwp_p_ad_push.constprop.0+0x1dc>  // b.tstop
    5440:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5444:	aa0003e4 	mov	x4, x0
    5448:	910003fd 	mov	x29, sp
    544c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5450:	aa0003f5 	mov	x21, x0
    5454:	aa020000 	orr	x0, x0, x2
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0203f7 	mov	x23, x2
    5460:	6d0627e8 	stp	d8, d9, [sp, #96]
    5464:	9e670029 	fmov	d9, x1
    5468:	9e670068 	fmov	d8, x3
    546c:	b6f80920 	tbz	x0, #63, 5590 <fwp_p_ad_push.constprop.0+0x15c>
    5470:	a90153f3 	stp	x19, x20, [sp, #16]
    5474:	9360fc80 	asr	x0, x4, #32
    5478:	b6f800c4 	tbz	x4, #63, 5490 <fwp_p_ad_push.constprop.0+0x5c>
    547c:	1e604109 	fmov	d9, d8
    5480:	2f00e408 	movi	d8, #0x0
    5484:	9360fc40 	asr	x0, x2, #32
    5488:	aa0203f5 	mov	x21, x2
    548c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5490:	97fff988 	bl	3ab0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5001240 	cbnz	x0, 56e4 <fwp_p_ad_push.constprop.0+0x2b0>
    54a0:	f9400a76 	ldr	x22, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002df 	cmp	x22, x0
    54ac:	54000d8c 	b.gt	565c <fwp_p_ad_push.constprop.0+0x228>
    54b0:	eb3542df 	cmp	x22, w21, uxtw
    54b4:	54000cad 	b.le	5648 <fwp_p_ad_push.constprop.0+0x214>
    54b8:	b7f80077 	tbnz	x23, #63, 54c4 <fwp_p_ad_push.constprop.0+0x90>
    54bc:	eb3742df 	cmp	x22, w23, uxtw
    54c0:	54000c4d 	b.le	5648 <fwp_p_ad_push.constprop.0+0x214>
    54c4:	f9400678 	ldr	x24, [x19, #8]
    54c8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54cc:	cb1802d8 	sub	x24, x22, x24
    54d0:	91000701 	add	x1, x24, #0x1
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000c28 	b.hi	565c <fwp_p_ad_push.constprop.0+0x228>  // b.pmore
    54dc:	a9418274 	ldp	x20, x0, [x19, #24]
    54e0:	a90573fb 	stp	x27, x28, [sp, #80]
    54e4:	eb14003f 	cmp	x1, x20
    54e8:	540006ad 	b.le	55bc <fwp_p_ad_push.constprop.0+0x188>
    54ec:	f100029f 	cmp	x20, #0x0
    54f0:	d2800803 	mov	x3, #0x40                  	// #64
    54f4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54f8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54fc:	a9046bf9 	stp	x25, x26, [sp, #64]
    5500:	eb14003f 	cmp	x1, x20
    5504:	5400008d 	b.le	5514 <fwp_p_ad_push.constprop.0+0xe0>
    5508:	eb02029f 	cmp	x20, x2
    550c:	5400054d 	b.le	55b4 <fwp_p_ad_push.constprop.0+0x180>
    5510:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5514:	d37df299 	lsl	x25, x20, #3
    5518:	52800022 	mov	w2, #0x1                   	// #1
    551c:	aa1903e1 	mov	x1, x25
    5520:	97fffbad 	bl	43d4 <ad_raw_realloc>
    5524:	aa0003e1 	mov	x1, x0
    5528:	b4000a40 	cbz	x0, 5670 <fwp_p_ad_push.constprop.0+0x23c>
    552c:	f9400e63 	ldr	x3, [x19, #24]
    5530:	f9001261 	str	x1, [x19, #32]
    5534:	f9401a60 	ldr	x0, [x19, #48]
    5538:	52800042 	mov	w2, #0x2                   	// #2
    553c:	8b030821 	add	x1, x1, x3, lsl #2
    5540:	f9001661 	str	x1, [x19, #40]
    5544:	d37cee81 	lsl	x1, x20, #4
    5548:	97fffba3 	bl	43d4 <ad_raw_realloc>
    554c:	aa0003e2 	mov	x2, x0
    5550:	b4000900 	cbz	x0, 5670 <fwp_p_ad_push.constprop.0+0x23c>
    5554:	f9400e61 	ldr	x1, [x19, #24]
    5558:	d37df31b 	lsl	x27, x24, #3
    555c:	d37ef69a 	lsl	x26, x20, #2
    5560:	d37ef71c 	lsl	x28, x24, #2
    5564:	8b190003 	add	x3, x0, x25
    5568:	8b010c01 	add	x1, x0, x1, lsl #3
    556c:	a9030660 	stp	x0, x1, [x19, #48]
    5570:	b5000558 	cbnz	x24, 5618 <fwp_p_ad_push.constprop.0+0x1e4>
    5574:	f9001e63 	str	x3, [x19, #56]
    5578:	f9401260 	ldr	x0, [x19, #32]
    557c:	8b1a0001 	add	x1, x0, x26
    5580:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5584:	f9000e74 	str	x20, [x19, #24]
    5588:	f9001661 	str	x1, [x19, #40]
    558c:	14000010 	b	55cc <fwp_p_ad_push.constprop.0+0x198>
    5590:	9360fc40 	asr	x0, x2, #32
    5594:	a90153f3 	stp	x19, x20, [sp, #16]
    5598:	eb84801f 	cmp	x0, x4, asr #32
    559c:	54fff7a0 	b.eq	5490 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    55a0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    55a4:	9137a000 	add	x0, x0, #0xde8
    55a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55ac:	a90573fb 	stp	x27, x28, [sp, #80]
    55b0:	97fff874 	bl	3780 <fwp_trap>
    55b4:	d37ffa94 	lsl	x20, x20, #1
    55b8:	17ffffd2 	b	5500 <fwp_p_ad_push.constprop.0+0xcc>
    55bc:	a9428a61 	ldp	x1, x2, [x19, #40]
    55c0:	d37ef71c 	lsl	x28, x24, #2
    55c4:	f9401e63 	ldr	x3, [x19, #56]
    55c8:	d37df31b 	lsl	x27, x24, #3
    55cc:	b83c6815 	str	w21, [x0, x28]
    55d0:	f10002ff 	cmp	x23, #0x0
    55d4:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55d8:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55dc:	fc3b6849 	str	d9, [x2, x27]
    55e0:	aa1602a0 	orr	x0, x21, x22
    55e4:	b83c6837 	str	w23, [x1, x28]
    55e8:	910006d6 	add	x22, x22, #0x1
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	fc3b6868 	str	d8, [x3, x27]
    55f4:	a94573fb 	ldp	x27, x28, [sp, #80]
    55f8:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55fc:	f9000a76 	str	x22, [x19, #16]
    5600:	a94153f3 	ldp	x19, x20, [sp, #16]
    5604:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5608:	a8c77bfd 	ldp	x29, x30, [sp], #112
    560c:	d65f03c0 	ret
    5610:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5614:	d65f03c0 	ret
    5618:	aa0303e0 	mov	x0, x3
    561c:	aa1b03e2 	mov	x2, x27
    5620:	97fff418 	bl	2680 <memmove@plt>
    5624:	a9420660 	ldp	x0, x1, [x19, #32]
    5628:	aa1c03e2 	mov	x2, x28
    562c:	f9401a63 	ldr	x3, [x19, #48]
    5630:	8b190063 	add	x3, x3, x25
    5634:	f9001e63 	str	x3, [x19, #56]
    5638:	8b1a0000 	add	x0, x0, x26
    563c:	97fff411 	bl	2680 <memmove@plt>
    5640:	a9430e62 	ldp	x2, x3, [x19, #48]
    5644:	17ffffcd 	b	5578 <fwp_p_ad_push.constprop.0+0x144>
    5648:	90000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    564c:	913a0000 	add	x0, x0, #0xe80
    5650:	a9046bf9 	stp	x25, x26, [sp, #64]
    5654:	a90573fb 	stp	x27, x28, [sp, #80]
    5658:	97fff84a 	bl	3780 <fwp_trap>
    565c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    5660:	91398000 	add	x0, x0, #0xe60
    5664:	a9046bf9 	stp	x25, x26, [sp, #64]
    5668:	a90573fb 	stp	x27, x28, [sp, #80]
    566c:	97fff845 	bl	3780 <fwp_trap>
    5670:	aa1303e0 	mov	x0, x19
    5674:	97fff648 	bl	2f94 <fwp_tape_unlink_scope>
    5678:	f9401260 	ldr	x0, [x19, #32]
    567c:	b4000040 	cbz	x0, 5684 <fwp_p_ad_push.constprop.0+0x250>
    5680:	97fffb20 	bl	4300 <ad_raw_free.part.0>
    5684:	f9401a60 	ldr	x0, [x19, #48]
    5688:	b4000040 	cbz	x0, 5690 <fwp_p_ad_push.constprop.0+0x25c>
    568c:	97fffb1d 	bl	4300 <ad_raw_free.part.0>
    5690:	f9402260 	ldr	x0, [x19, #64]
    5694:	b4000040 	cbz	x0, 569c <fwp_p_ad_push.constprop.0+0x268>
    5698:	97fffb1a 	bl	4300 <ad_raw_free.part.0>
    569c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    56a0:	f947e821 	ldr	x1, [x1, #4048]
    56a4:	f9000e7f 	str	xzr, [x19, #24]
    56a8:	4f000400 	movi	v0.4s, #0x0
    56ac:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    56b0:	d2800262 	mov	x2, #0x13                  	// #19
    56b4:	f9400023 	ldr	x3, [x1]
    56b8:	b900067f 	str	wzr, [x19, #4]
    56bc:	d2800021 	mov	x1, #0x1                   	// #1
    56c0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    56c4:	9123a000 	add	x0, x0, #0x8e8
    56c8:	3c808260 	stur	q0, [x19, #8]
    56cc:	ad010260 	stp	q0, q0, [x19, #32]
    56d0:	97fff490 	bl	2910 <fwrite@plt>
    56d4:	d2800000 	mov	x0, #0x0                   	// #0
    56d8:	97fff49a 	bl	2940 <fflush@plt>
    56dc:	52800cc0 	mov	w0, #0x66                  	// #102
    56e0:	97fff4a8 	bl	2980 <_Exit@plt>
    56e4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    56e8:	9138c000 	add	x0, x0, #0xe30
    56ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    56f0:	a90573fb 	stp	x27, x28, [sp, #80]
    56f4:	97fff823 	bl	3780 <fwp_trap>
    56f8:	d503201f 	nop
    56fc:	d503201f 	nop

0000000000005700 <w107>:
    5700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5704:	9e660003 	fmov	x3, d0
    5708:	aa0003e2 	mov	x2, x0
    570c:	910003fd 	mov	x29, sp
    5710:	6d0327e8 	stp	d8, d9, [sp, #48]
    5714:	1e604028 	fmov	d8, d1
    5718:	1e600809 	fmul	d9, d0, d0
    571c:	fd0023ea 	str	d10, [sp, #64]
    5720:	1e60400a 	fmov	d10, d0
    5724:	a90153f3 	stp	x19, x20, [sp, #16]
    5728:	aa0003f3 	mov	x19, x0
    572c:	aa0103f4 	mov	x20, x1
    5730:	aa0303e1 	mov	x1, x3
    5734:	a9025bf5 	stp	x21, x22, [sp, #32]
    5738:	97ffff3f 	bl	5434 <fwp_p_ad_push.constprop.0>
    573c:	1e693908 	fsub	d8, d8, d9
    5740:	aa1403e2 	mov	x2, x20
    5744:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5748:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    574c:	9e660116 	fmov	x22, d8
    5750:	97ffff39 	bl	5434 <fwp_p_ad_push.constprop.0>
    5754:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5758:	aa0003e1 	mov	x1, x0
    575c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5760:	aa1303e0 	mov	x0, x19
    5764:	1e6a3929 	fsub	d9, d9, d10
    5768:	aa0103f3 	mov	x19, x1
    576c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5770:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5774:	9e660135 	fmov	x21, d9
    5778:	97ffff2f 	bl	5434 <fwp_p_ad_push.constprop.0>
    577c:	1e680908 	fmul	d8, d8, d8
    5780:	aa0003f4 	mov	x20, x0
    5784:	aa1603e3 	mov	x3, x22
    5788:	aa1603e1 	mov	x1, x22
    578c:	aa1303e2 	mov	x2, x19
    5790:	aa1303e0 	mov	x0, x19
    5794:	97ffff28 	bl	5434 <fwp_p_ad_push.constprop.0>
    5798:	aa0003e2 	mov	x2, x0
    579c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    57a0:	9e670020 	fmov	d0, x1
    57a4:	9e660101 	fmov	x1, d8
    57a8:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    57ac:	1e600908 	fmul	d8, d8, d0
    57b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57b4:	97ffff20 	bl	5434 <fwp_p_ad_push.constprop.0>
    57b8:	1e690929 	fmul	d9, d9, d9
    57bc:	aa0003f3 	mov	x19, x0
    57c0:	aa1503e3 	mov	x3, x21
    57c4:	aa1503e1 	mov	x1, x21
    57c8:	aa1403e2 	mov	x2, x20
    57cc:	aa1403e0 	mov	x0, x20
    57d0:	97ffff19 	bl	5434 <fwp_p_ad_push.constprop.0>
    57d4:	1e692908 	fadd	d8, d8, d9
    57d8:	aa1303e2 	mov	x2, x19
    57dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57e0:	aa0303e1 	mov	x1, x3
    57e4:	97ffff14 	bl	5434 <fwp_p_ad_push.constprop.0>
    57e8:	aa0003e1 	mov	x1, x0
    57ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    57f0:	9e660100 	fmov	x0, d8
    57f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57f8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57fc:	fd4023ea 	ldr	d10, [sp, #64]
    5800:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5804:	d65f03c0 	ret
    5808:	d503201f 	nop
    580c:	d503201f 	nop

0000000000005810 <w164.constprop.0>:
    5810:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5814:	910003fd 	mov	x29, sp
    5818:	a9025bf5 	stp	x21, x22, [sp, #32]
    581c:	fd001be8 	str	d8, [sp, #48]
    5820:	f9400015 	ldr	x21, [x0]
    5824:	b4000315 	cbz	x21, 5884 <w164.constprop.0+0x74>
    5828:	2f00e408 	movi	d8, #0x0
    582c:	91002016 	add	x22, x0, #0x8
    5830:	a90153f3 	stp	x19, x20, [sp, #16]
    5834:	91004014 	add	x20, x0, #0x10
    5838:	d2800013 	mov	x19, #0x0                   	// #0
    583c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5840:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5844:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5848:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    584c:	aa0303e1 	mov	x1, x3
    5850:	1e602908 	fadd	d8, d8, d0
    5854:	91000a73 	add	x19, x19, #0x2
    5858:	97fffef7 	bl	5434 <fwp_p_ad_push.constprop.0>
    585c:	eb1302bf 	cmp	x21, x19
    5860:	54ffff08 	b.hi	5840 <w164.constprop.0+0x30>  // b.pmore
    5864:	9e660102 	fmov	x2, d8
    5868:	fd401be8 	ldr	d8, [sp, #48]
    586c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5870:	aa0003e1 	mov	x1, x0
    5874:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5878:	aa0203e0 	mov	x0, x2
    587c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5880:	d65f03c0 	ret
    5884:	2f00e408 	movi	d8, #0x0
    5888:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    588c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5890:	aa0003e1 	mov	x1, x0
    5894:	9e660102 	fmov	x2, d8
    5898:	fd401be8 	ldr	d8, [sp, #48]
    589c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58a0:	aa0203e0 	mov	x0, x2
    58a4:	d65f03c0 	ret
    58a8:	d503201f 	nop
    58ac:	d503201f 	nop

00000000000058b0 <fwp_data.part.0.constprop.0>:
    58b0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    58b4:	910003fd 	mov	x29, sp
    58b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    58bc:	f00000d6 	adrp	x22, 20000 <__data_start>
    58c0:	910182c2 	add	x2, x22, #0x60
    58c4:	a9046bf9 	stp	x25, x26, [sp, #64]
    58c8:	b9413059 	ldr	w25, [x2, #304]
    58cc:	a90153f3 	stp	x19, x20, [sp, #16]
    58d0:	aa0103f4 	mov	x20, x1
    58d4:	a90363f7 	stp	x23, x24, [sp, #48]
    58d8:	2a0003f7 	mov	w23, w0
    58dc:	340000b9 	cbz	w25, 58f0 <fwp_data.part.0.constprop.0+0x40>
    58e0:	a9538041 	ldp	x1, x0, [x2, #312]
    58e4:	91000421 	add	x1, x1, #0x1
    58e8:	91006000 	add	x0, x0, #0x18
    58ec:	a9138041 	stp	x1, x0, [x2, #312]
    58f0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    58f4:	911902a3 	add	x3, x21, #0x640
    58f8:	b953a460 	ldr	w0, [x3, #5028]
    58fc:	34000840 	cbz	w0, 5a04 <fwp_data.part.0.constprop.0+0x154>
    5900:	397e8862 	ldrb	w2, [x3, #4002]
    5904:	910f0040 	add	x0, x2, #0x3c0
    5908:	8b020442 	add	x2, x2, x2, lsl #1
    590c:	d37df042 	lsl	x2, x2, #3
    5910:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5914:	2a1a03f8 	mov	w24, w26
    5918:	f8626873 	ldr	x19, [x3, x2]
    591c:	b4000613 	cbz	x19, 59dc <fwp_data.part.0.constprop.0+0x12c>
    5920:	f9400260 	ldr	x0, [x19]
    5924:	aa2003e0 	mvn	x0, x0
    5928:	f8226860 	str	x0, [x3, x2]
    592c:	f100631f 	cmp	x24, #0x18
    5930:	540000e9 	b.ls	594c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5934:	d1006702 	sub	x2, x24, #0x19
    5938:	91006260 	add	x0, x19, #0x18
    593c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5940:	52800001 	mov	w1, #0x0                   	// #0
    5944:	91002042 	add	x2, x2, #0x8
    5948:	97fff3a6 	bl	27e0 <memset@plt>
    594c:	911902a0 	add	x0, x21, #0x640
    5950:	f94a1001 	ldr	x1, [x0, #5152]
    5954:	ab180021 	adds	x1, x1, x24
    5958:	54000642 	b.cs	5a20 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    595c:	f94a1402 	ldr	x2, [x0, #5160]
    5960:	f90a1001 	str	x1, [x0, #5152]
    5964:	eb02003f 	cmp	x1, x2
    5968:	54000049 	b.ls	5970 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    596c:	f90a1401 	str	x1, [x0, #5160]
    5970:	911902a0 	add	x0, x21, #0x640
    5974:	1e630341 	ucvtf	d1, w26
    5978:	fd4a1c00 	ldr	d0, [x0, #5176]
    597c:	1e612800 	fadd	d0, d0, d1
    5980:	fd0a1c00 	str	d0, [x0, #5176]
    5984:	34000139 	cbz	w25, 59a8 <fwp_data.part.0.constprop.0+0xf8>
    5988:	911902b5 	add	x21, x21, #0x640
    598c:	910182d6 	add	x22, x22, #0x60
    5990:	fd4a12a0 	ldr	d0, [x21, #5152]
    5994:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5998:	7e61d800 	ucvtf	d0, d0
    599c:	1e623800 	fsub	d0, d0, d2
    59a0:	1e612010 	fcmpe	d0, d1
    59a4:	540003ac 	b.gt	5a18 <fwp_data.part.0.constprop.0+0x168>
    59a8:	52800040 	mov	w0, #0x2                   	// #2
    59ac:	29000277 	stp	w23, w0, [x19]
    59b0:	aa1303e0 	mov	x0, x19
    59b4:	f9400281 	ldr	x1, [x20]
    59b8:	f9000661 	str	x1, [x19, #8]
    59bc:	f9400681 	ldr	x1, [x20, #8]
    59c0:	f9000a61 	str	x1, [x19, #16]
    59c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    59c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    59d0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    59d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    59d8:	d65f03c0 	ret
    59dc:	8b020063 	add	x3, x3, x2
    59e0:	f9400473 	ldr	x19, [x3, #8]
    59e4:	b4000113 	cbz	x19, 5a04 <fwp_data.part.0.constprop.0+0x154>
    59e8:	f9400860 	ldr	x0, [x3, #16]
    59ec:	cb130000 	sub	x0, x0, x19
    59f0:	eb00031f 	cmp	x24, x0
    59f4:	54000088 	b.hi	5a04 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    59f8:	8b180260 	add	x0, x19, x24
    59fc:	f9000460 	str	x0, [x3, #8]
    5a00:	17ffffcb 	b	592c <fwp_data.part.0.constprop.0+0x7c>
    5a04:	52800001 	mov	w1, #0x0                   	// #0
    5a08:	d2800300 	mov	x0, #0x18                  	// #24
    5a0c:	97fffda1 	bl	5090 <fwp_heap_alloc>
    5a10:	aa0003f3 	mov	x19, x0
    5a14:	17ffffdc 	b	5984 <fwp_data.part.0.constprop.0+0xd4>
    5a18:	fd00aac0 	str	d0, [x22, #336]
    5a1c:	17ffffe3 	b	59a8 <fwp_data.part.0.constprop.0+0xf8>
    5a20:	97fff5b4 	bl	30f0 <fwp_heap_oom>

0000000000005a24 <fwp_rc_share>:
    5a24:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5a28:	91190042 	add	x2, x2, #0x640
    5a2c:	f949d843 	ldr	x3, [x2, #5040]
    5a30:	f949ec41 	ldr	x1, [x2, #5080]
    5a34:	cb030000 	sub	x0, x0, x3
    5a38:	eb01401f 	cmp	x0, x1, lsl #16
    5a3c:	540002c2 	b.cs	5a94 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5a40:	d350fc01 	lsr	x1, x0, #16
    5a44:	f949fc44 	ldr	x4, [x2, #5112]
    5a48:	8b010821 	add	x1, x1, x1, lsl #2
    5a4c:	d37df021 	lsl	x1, x1, #3
    5a50:	8b010083 	add	x3, x4, x1
    5a54:	f9401062 	ldr	x2, [x3, #32]
    5a58:	b40001e2 	cbz	x2, 5a94 <fwp_rc_share+0x70>
    5a5c:	38616881 	ldrb	w1, [x4, x1]
    5a60:	7100083f 	cmp	w1, #0x2
    5a64:	540001a0 	b.eq	5a98 <fwp_rc_share+0x74>  // b.none
    5a68:	7100043f 	cmp	w1, #0x1
    5a6c:	54000141 	b.ne	5a94 <fwp_rc_share+0x70>  // b.any
    5a70:	29430464 	ldp	w4, w1, [x3, #24]
    5a74:	92403c00 	and	x0, x0, #0xffff
    5a78:	9b047c00 	mul	x0, x0, x4
    5a7c:	d360fc00 	lsr	x0, x0, #32
    5a80:	eb01001f 	cmp	x0, x1
    5a84:	54000082 	b.cs	5a94 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5a88:	8b000042 	add	x2, x2, x0
    5a8c:	39400040 	ldrb	w0, [x2]
    5a90:	350000a0 	cbnz	w0, 5aa4 <fwp_rc_share+0x80>
    5a94:	d65f03c0 	ret
    5a98:	72003c1f 	tst	w0, #0xffff
    5a9c:	54ffff80 	b.eq	5a8c <fwp_rc_share+0x68>  // b.none
    5aa0:	d65f03c0 	ret
    5aa4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5aa8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x400>
    5aac:	913a8000 	add	x0, x0, #0xea0
    5ab0:	910003fd 	mov	x29, sp
    5ab4:	97fff733 	bl	3780 <fwp_trap>
    5ab8:	d503201f 	nop
    5abc:	d503201f 	nop

0000000000005ac0 <fwp_rc_fresh>:
    5ac0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ac4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5ac8:	91190063 	add	x3, x3, #0x640
    5acc:	910003fd 	mov	x29, sp
    5ad0:	a90153f3 	stp	x19, x20, [sp, #16]
    5ad4:	aa0003f3 	mov	x19, x0
    5ad8:	f949d861 	ldr	x1, [x3, #5040]
    5adc:	f949ec60 	ldr	x0, [x3, #5080]
    5ae0:	cb010261 	sub	x1, x19, x1
    5ae4:	eb00403f 	cmp	x1, x0, lsl #16
    5ae8:	54000322 	b.cs	5b4c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5aec:	d350fc22 	lsr	x2, x1, #16
    5af0:	f949fc63 	ldr	x3, [x3, #5112]
    5af4:	8b020842 	add	x2, x2, x2, lsl #2
    5af8:	d37df042 	lsl	x2, x2, #3
    5afc:	8b020060 	add	x0, x3, x2
    5b00:	f9401014 	ldr	x20, [x0, #32]
    5b04:	b4000254 	cbz	x20, 5b4c <fwp_rc_fresh+0x8c>
    5b08:	38626862 	ldrb	w2, [x3, x2]
    5b0c:	7100085f 	cmp	w2, #0x2
    5b10:	54000260 	b.eq	5b5c <fwp_rc_fresh+0x9c>  // b.none
    5b14:	7100045f 	cmp	w2, #0x1
    5b18:	540001a1 	b.ne	5b4c <fwp_rc_fresh+0x8c>  // b.any
    5b1c:	29430002 	ldp	w2, w0, [x0, #24]
    5b20:	92403c21 	and	x1, x1, #0xffff
    5b24:	9b027c21 	mul	x1, x1, x2
    5b28:	d360fc21 	lsr	x1, x1, #32
    5b2c:	eb00003f 	cmp	x1, x0
    5b30:	540000e2 	b.cs	5b4c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5b34:	8b010294 	add	x20, x20, x1
    5b38:	39400280 	ldrb	w0, [x20]
    5b3c:	7103fc1f 	cmp	w0, #0xff
    5b40:	540001a0 	b.eq	5b74 <fwp_rc_fresh+0xb4>  // b.none
    5b44:	52800020 	mov	w0, #0x1                   	// #1
    5b48:	39000280 	strb	w0, [x20]
    5b4c:	aa1303e0 	mov	x0, x19
    5b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b54:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b58:	d65f03c0 	ret
    5b5c:	72003c3f 	tst	w1, #0xffff
    5b60:	54fffec0 	b.eq	5b38 <fwp_rc_fresh+0x78>  // b.none
    5b64:	aa1303e0 	mov	x0, x19
    5b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b70:	d65f03c0 	ret
    5b74:	aa1403e0 	mov	x0, x20
    5b78:	97fffb86 	bl	4990 <fwp_rc_forget_slot>
    5b7c:	17fffff2 	b	5b44 <fwp_rc_fresh+0x84>

0000000000005b80 <fwp_rc_free_arr>:
    5b80:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5b84:	91190063 	add	x3, x3, #0x640
    5b88:	f949d861 	ldr	x1, [x3, #5040]
    5b8c:	f949ec62 	ldr	x2, [x3, #5080]
    5b90:	cb010001 	sub	x1, x0, x1
    5b94:	eb02403f 	cmp	x1, x2, lsl #16
    5b98:	54000342 	b.cs	5c00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b9c:	d350fc22 	lsr	x2, x1, #16
    5ba0:	f949fc65 	ldr	x5, [x3, #5112]
    5ba4:	8b020842 	add	x2, x2, x2, lsl #2
    5ba8:	d37df042 	lsl	x2, x2, #3
    5bac:	8b0200a4 	add	x4, x5, x2
    5bb0:	f9401083 	ldr	x3, [x4, #32]
    5bb4:	b4000263 	cbz	x3, 5c00 <fwp_rc_free_arr+0x80>
    5bb8:	386268a2 	ldrb	w2, [x5, x2]
    5bbc:	7100085f 	cmp	w2, #0x2
    5bc0:	540001c0 	b.eq	5bf8 <fwp_rc_free_arr+0x78>  // b.none
    5bc4:	7100045f 	cmp	w2, #0x1
    5bc8:	540001c1 	b.ne	5c00 <fwp_rc_free_arr+0x80>  // b.any
    5bcc:	29430885 	ldp	w5, w2, [x4, #24]
    5bd0:	92403c21 	and	x1, x1, #0xffff
    5bd4:	9b057c21 	mul	x1, x1, x5
    5bd8:	d360fc21 	lsr	x1, x1, #32
    5bdc:	eb02003f 	cmp	x1, x2
    5be0:	54000102 	b.cs	5c00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5be4:	8b010063 	add	x3, x3, x1
    5be8:	39400061 	ldrb	w1, [x3]
    5bec:	7100043f 	cmp	w1, #0x1
    5bf0:	54000081 	b.ne	5c00 <fwp_rc_free_arr+0x80>  // b.any
    5bf4:	17fffc07 	b	4c10 <fwp_mem_free>
    5bf8:	72003c3f 	tst	w1, #0xffff
    5bfc:	54ffff60 	b.eq	5be8 <fwp_rc_free_arr+0x68>  // b.none
    5c00:	d65f03c0 	ret

0000000000005c04 <fwp_rc_dup>:
    5c04:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5c08:	91190042 	add	x2, x2, #0x640
    5c0c:	f949d841 	ldr	x1, [x2, #5040]
    5c10:	f949ec43 	ldr	x3, [x2, #5080]
    5c14:	cb010001 	sub	x1, x0, x1
    5c18:	eb03403f 	cmp	x1, x3, lsl #16
    5c1c:	540003c2 	b.cs	5c94 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5c20:	d350fc20 	lsr	x0, x1, #16
    5c24:	f949fc44 	ldr	x4, [x2, #5112]
    5c28:	8b000800 	add	x0, x0, x0, lsl #2
    5c2c:	d37df002 	lsl	x2, x0, #3
    5c30:	8b020083 	add	x3, x4, x2
    5c34:	f9401060 	ldr	x0, [x3, #32]
    5c38:	b40002e0 	cbz	x0, 5c94 <fwp_rc_dup+0x90>
    5c3c:	38626882 	ldrb	w2, [x4, x2]
    5c40:	7100085f 	cmp	w2, #0x2
    5c44:	540002a0 	b.eq	5c98 <fwp_rc_dup+0x94>  // b.none
    5c48:	7100045f 	cmp	w2, #0x1
    5c4c:	54000241 	b.ne	5c94 <fwp_rc_dup+0x90>  // b.any
    5c50:	29430864 	ldp	w4, w2, [x3, #24]
    5c54:	92403c21 	and	x1, x1, #0xffff
    5c58:	9b047c21 	mul	x1, x1, x4
    5c5c:	d360fc21 	lsr	x1, x1, #32
    5c60:	eb02003f 	cmp	x1, x2
    5c64:	54000182 	b.cs	5c94 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5c68:	8b010000 	add	x0, x0, x1
    5c6c:	39400001 	ldrb	w1, [x0]
    5c70:	34000121 	cbz	w1, 5c94 <fwp_rc_dup+0x90>
    5c74:	f00000c2 	adrp	x2, 20000 <__data_start>
    5c78:	91018042 	add	x2, x2, #0x60
    5c7c:	b9413043 	ldr	w3, [x2, #304]
    5c80:	35000123 	cbnz	w3, 5ca4 <fwp_rc_dup+0xa0>
    5c84:	7103f43f 	cmp	w1, #0xfd
    5c88:	54000168 	b.hi	5cb4 <fwp_rc_dup+0xb0>  // b.pmore
    5c8c:	11000421 	add	w1, w1, #0x1
    5c90:	39000001 	strb	w1, [x0]
    5c94:	d65f03c0 	ret
    5c98:	72003c3f 	tst	w1, #0xffff
    5c9c:	54fffe80 	b.eq	5c6c <fwp_rc_dup+0x68>  // b.none
    5ca0:	d65f03c0 	ret
    5ca4:	f940ac43 	ldr	x3, [x2, #344]
    5ca8:	91000463 	add	x3, x3, #0x1
    5cac:	f900ac43 	str	x3, [x2, #344]
    5cb0:	17fffff5 	b	5c84 <fwp_rc_dup+0x80>
    5cb4:	17fffaf0 	b	4874 <fwp_rc_wide_dup>
    5cb8:	d503201f 	nop
    5cbc:	d503201f 	nop

0000000000005cc0 <fwp_owned_entry161>:
    5cc0:	d10103ff 	sub	sp, sp, #0x40
    5cc4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5cc8:	f947f442 	ldr	x2, [x2, #4072]
    5ccc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5cd0:	910083fd 	add	x29, sp, #0x20
    5cd4:	a90353f3 	stp	x19, x20, [sp, #48]
    5cd8:	f9400043 	ldr	x3, [x2]
    5cdc:	f9000fe3 	str	x3, [sp, #24]
    5ce0:	d2800003 	mov	x3, #0x0                   	// #0
    5ce4:	a9400c01 	ldp	x1, x3, [x0]
    5ce8:	f9400802 	ldr	x2, [x0, #16]
    5cec:	ab020022 	adds	x2, x1, x2
    5cf0:	540006e6 	b.vs	5dcc <fwp_owned_entry161+0x10c>
    5cf4:	910023e1 	add	x1, sp, #0x8
    5cf8:	52800000 	mov	w0, #0x0                   	// #0
    5cfc:	a9008be3 	stp	x3, x2, [sp, #8]
    5d00:	97fffeec 	bl	58b0 <fwp_data.part.0.constprop.0>
    5d04:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5d08:	91190063 	add	x3, x3, #0x640
    5d0c:	aa0003f3 	mov	x19, x0
    5d10:	f949d861 	ldr	x1, [x3, #5040]
    5d14:	f949ec60 	ldr	x0, [x3, #5080]
    5d18:	cb010261 	sub	x1, x19, x1
    5d1c:	eb00403f 	cmp	x1, x0, lsl #16
    5d20:	54000322 	b.cs	5d84 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5d24:	d350fc22 	lsr	x2, x1, #16
    5d28:	f949fc63 	ldr	x3, [x3, #5112]
    5d2c:	8b020842 	add	x2, x2, x2, lsl #2
    5d30:	d37df042 	lsl	x2, x2, #3
    5d34:	8b020060 	add	x0, x3, x2
    5d38:	f9401014 	ldr	x20, [x0, #32]
    5d3c:	b4000254 	cbz	x20, 5d84 <fwp_owned_entry161+0xc4>
    5d40:	38626862 	ldrb	w2, [x3, x2]
    5d44:	7100085f 	cmp	w2, #0x2
    5d48:	54000360 	b.eq	5db4 <fwp_owned_entry161+0xf4>  // b.none
    5d4c:	7100045f 	cmp	w2, #0x1
    5d50:	540001a1 	b.ne	5d84 <fwp_owned_entry161+0xc4>  // b.any
    5d54:	29430002 	ldp	w2, w0, [x0, #24]
    5d58:	92403c21 	and	x1, x1, #0xffff
    5d5c:	9b027c21 	mul	x1, x1, x2
    5d60:	d360fc21 	lsr	x1, x1, #32
    5d64:	eb00003f 	cmp	x1, x0
    5d68:	540000e2 	b.cs	5d84 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5d6c:	8b010294 	add	x20, x20, x1
    5d70:	39400280 	ldrb	w0, [x20]
    5d74:	7103fc1f 	cmp	w0, #0xff
    5d78:	54000240 	b.eq	5dc0 <fwp_owned_entry161+0x100>  // b.none
    5d7c:	52800020 	mov	w0, #0x1                   	// #1
    5d80:	39000280 	strb	w0, [x20]
    5d84:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5d88:	f947f400 	ldr	x0, [x0, #4072]
    5d8c:	f9400fe2 	ldr	x2, [sp, #24]
    5d90:	f9400001 	ldr	x1, [x0]
    5d94:	eb010042 	subs	x2, x2, x1
    5d98:	d2800001 	mov	x1, #0x0                   	// #0
    5d9c:	540001a1 	b.ne	5dd0 <fwp_owned_entry161+0x110>  // b.any
    5da0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5da4:	aa1303e0 	mov	x0, x19
    5da8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5dac:	910103ff 	add	sp, sp, #0x40
    5db0:	d65f03c0 	ret
    5db4:	72003c3f 	tst	w1, #0xffff
    5db8:	54fffe61 	b.ne	5d84 <fwp_owned_entry161+0xc4>  // b.any
    5dbc:	17ffffed 	b	5d70 <fwp_owned_entry161+0xb0>
    5dc0:	aa1403e0 	mov	x0, x20
    5dc4:	97fffaf3 	bl	4990 <fwp_rc_forget_slot>
    5dc8:	17ffffed 	b	5d7c <fwp_owned_entry161+0xbc>
    5dcc:	97fff30d 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5dd0:	97fff290 	bl	2810 <__stack_chk_fail@plt>

0000000000005dd4 <e161>:
    5dd4:	d10103ff 	sub	sp, sp, #0x40
    5dd8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5ddc:	f947f442 	ldr	x2, [x2, #4072]
    5de0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5de4:	910083fd 	add	x29, sp, #0x20
    5de8:	a90353f3 	stp	x19, x20, [sp, #48]
    5dec:	f9400043 	ldr	x3, [x2]
    5df0:	f9000fe3 	str	x3, [sp, #24]
    5df4:	d2800003 	mov	x3, #0x0                   	// #0
    5df8:	a9400c01 	ldp	x1, x3, [x0]
    5dfc:	f9400802 	ldr	x2, [x0, #16]
    5e00:	ab020022 	adds	x2, x1, x2
    5e04:	54000726 	b.vs	5ee8 <e161+0x114>
    5e08:	910023e1 	add	x1, sp, #0x8
    5e0c:	52800000 	mov	w0, #0x0                   	// #0
    5e10:	a9008be3 	stp	x3, x2, [sp, #8]
    5e14:	97fffea7 	bl	58b0 <fwp_data.part.0.constprop.0>
    5e18:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5e1c:	91190063 	add	x3, x3, #0x640
    5e20:	aa0003f3 	mov	x19, x0
    5e24:	f949d861 	ldr	x1, [x3, #5040]
    5e28:	f949ec60 	ldr	x0, [x3, #5080]
    5e2c:	cb010261 	sub	x1, x19, x1
    5e30:	eb00403f 	cmp	x1, x0, lsl #16
    5e34:	54000322 	b.cs	5e98 <e161+0xc4>  // b.hs, b.nlast
    5e38:	d350fc22 	lsr	x2, x1, #16
    5e3c:	f949fc63 	ldr	x3, [x3, #5112]
    5e40:	8b020842 	add	x2, x2, x2, lsl #2
    5e44:	d37df042 	lsl	x2, x2, #3
    5e48:	8b020060 	add	x0, x3, x2
    5e4c:	f9401014 	ldr	x20, [x0, #32]
    5e50:	b4000254 	cbz	x20, 5e98 <e161+0xc4>
    5e54:	38626862 	ldrb	w2, [x3, x2]
    5e58:	7100085f 	cmp	w2, #0x2
    5e5c:	540003a0 	b.eq	5ed0 <e161+0xfc>  // b.none
    5e60:	7100045f 	cmp	w2, #0x1
    5e64:	540001a1 	b.ne	5e98 <e161+0xc4>  // b.any
    5e68:	29430002 	ldp	w2, w0, [x0, #24]
    5e6c:	92403c21 	and	x1, x1, #0xffff
    5e70:	9b027c21 	mul	x1, x1, x2
    5e74:	d360fc21 	lsr	x1, x1, #32
    5e78:	eb00003f 	cmp	x1, x0
    5e7c:	540000e2 	b.cs	5e98 <e161+0xc4>  // b.hs, b.nlast
    5e80:	8b010294 	add	x20, x20, x1
    5e84:	39400280 	ldrb	w0, [x20]
    5e88:	7103fc1f 	cmp	w0, #0xff
    5e8c:	54000280 	b.eq	5edc <e161+0x108>  // b.none
    5e90:	52800020 	mov	w0, #0x1                   	// #1
    5e94:	39000280 	strb	w0, [x20]
    5e98:	aa1303e0 	mov	x0, x19
    5e9c:	97fffee2 	bl	5a24 <fwp_rc_share>
    5ea0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5ea4:	f947f400 	ldr	x0, [x0, #4072]
    5ea8:	f9400fe2 	ldr	x2, [sp, #24]
    5eac:	f9400001 	ldr	x1, [x0]
    5eb0:	eb010042 	subs	x2, x2, x1
    5eb4:	d2800001 	mov	x1, #0x0                   	// #0
    5eb8:	540001a1 	b.ne	5eec <e161+0x118>  // b.any
    5ebc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ec0:	aa1303e0 	mov	x0, x19
    5ec4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ec8:	910103ff 	add	sp, sp, #0x40
    5ecc:	d65f03c0 	ret
    5ed0:	72003c3f 	tst	w1, #0xffff
    5ed4:	54fffe21 	b.ne	5e98 <e161+0xc4>  // b.any
    5ed8:	17ffffeb 	b	5e84 <e161+0xb0>
    5edc:	aa1403e0 	mov	x0, x20
    5ee0:	97fffaac 	bl	4990 <fwp_rc_forget_slot>
    5ee4:	17ffffeb 	b	5e90 <e161+0xbc>
    5ee8:	97fff2c6 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5eec:	97fff249 	bl	2810 <__stack_chk_fail@plt>

0000000000005ef0 <fwp_drop1>:
    5ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ef4:	910003fd 	mov	x29, sp
    5ef8:	a90153f3 	stp	x19, x20, [sp, #16]
    5efc:	f90013f5 	str	x21, [sp, #32]
    5f00:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5f04:	911902b4 	add	x20, x21, #0x640
    5f08:	f949da81 	ldr	x1, [x20, #5040]
    5f0c:	f949ee82 	ldr	x2, [x20, #5080]
    5f10:	cb010001 	sub	x1, x0, x1
    5f14:	eb02403f 	cmp	x1, x2, lsl #16
    5f18:	54000382 	b.cs	5f88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f1c:	d350fc22 	lsr	x2, x1, #16
    5f20:	f949fe84 	ldr	x4, [x20, #5112]
    5f24:	8b020842 	add	x2, x2, x2, lsl #2
    5f28:	d37df042 	lsl	x2, x2, #3
    5f2c:	8b020083 	add	x3, x4, x2
    5f30:	f9401073 	ldr	x19, [x3, #32]
    5f34:	b40002b3 	cbz	x19, 5f88 <fwp_drop1+0x98>
    5f38:	38626882 	ldrb	w2, [x4, x2]
    5f3c:	7100085f 	cmp	w2, #0x2
    5f40:	540002c0 	b.eq	5f98 <fwp_drop1+0xa8>  // b.none
    5f44:	7100045f 	cmp	w2, #0x1
    5f48:	54000201 	b.ne	5f88 <fwp_drop1+0x98>  // b.any
    5f4c:	29430864 	ldp	w4, w2, [x3, #24]
    5f50:	92403c21 	and	x1, x1, #0xffff
    5f54:	9b047c21 	mul	x1, x1, x4
    5f58:	d360fc21 	lsr	x1, x1, #32
    5f5c:	eb02003f 	cmp	x1, x2
    5f60:	54000142 	b.cs	5f88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f64:	8b010273 	add	x19, x19, x1
    5f68:	39400261 	ldrb	w1, [x19]
    5f6c:	340000e1 	cbz	w1, 5f88 <fwp_drop1+0x98>
    5f70:	7100043f 	cmp	w1, #0x1
    5f74:	540001e0 	b.eq	5fb0 <fwp_drop1+0xc0>  // b.none
    5f78:	7103fc3f 	cmp	w1, #0xff
    5f7c:	540002e0 	b.eq	5fd8 <fwp_drop1+0xe8>  // b.none
    5f80:	51000421 	sub	w1, w1, #0x1
    5f84:	39000261 	strb	w1, [x19]
    5f88:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f8c:	f94013f5 	ldr	x21, [sp, #32]
    5f90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f94:	d65f03c0 	ret
    5f98:	72003c3f 	tst	w1, #0xffff
    5f9c:	54fffe60 	b.eq	5f68 <fwp_drop1+0x78>  // b.none
    5fa0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fa4:	f94013f5 	ldr	x21, [sp, #32]
    5fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fac:	d65f03c0 	ret
    5fb0:	f9400813 	ldr	x19, [x0, #16]
    5fb4:	97fffef3 	bl	5b80 <fwp_rc_free_arr>
    5fb8:	911902a0 	add	x0, x21, #0x640
    5fbc:	f949d801 	ldr	x1, [x0, #5040]
    5fc0:	f949ec00 	ldr	x0, [x0, #5080]
    5fc4:	cb010261 	sub	x1, x19, x1
    5fc8:	eb00403f 	cmp	x1, x0, lsl #16
    5fcc:	54fffde2 	b.cs	5f88 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fd0:	aa1303e0 	mov	x0, x19
    5fd4:	17ffffd2 	b	5f1c <fwp_drop1+0x2c>
    5fd8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fdc:	911902b5 	add	x21, x21, #0x640
    5fe0:	ca402400 	eor	x0, x0, x0, lsr #9
    5fe4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5fe8:	f94a2400 	ldr	x0, [x0, #5192]
    5fec:	b5000080 	cbnz	x0, 5ffc <fwp_drop1+0x10c>
    5ff0:	14000010 	b	6030 <fwp_drop1+0x140>
    5ff4:	f9400800 	ldr	x0, [x0, #16]
    5ff8:	b40001c0 	cbz	x0, 6030 <fwp_drop1+0x140>
    5ffc:	f9400001 	ldr	x1, [x0]
    6000:	eb13003f 	cmp	x1, x19
    6004:	54ffff81 	b.ne	5ff4 <fwp_drop1+0x104>  // b.any
    6008:	f9400401 	ldr	x1, [x0, #8]
    600c:	d1000421 	sub	x1, x1, #0x1
    6010:	f9000401 	str	x1, [x0, #8]
    6014:	f103f83f 	cmp	x1, #0xfe
    6018:	54fffb81 	b.ne	5f88 <fwp_drop1+0x98>  // b.any
    601c:	aa1303e0 	mov	x0, x19
    6020:	97fffa5c 	bl	4990 <fwp_rc_forget_slot>
    6024:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6028:	39000260 	strb	w0, [x19]
    602c:	17ffffd7 	b	5f88 <fwp_drop1+0x98>
    6030:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    6034:	91368000 	add	x0, x0, #0xda0
    6038:	97fff5d2 	bl	3780 <fwp_trap>
    603c:	d503201f 	nop

0000000000006040 <fwp_drop0>:
    6040:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6044:	910003fd 	mov	x29, sp
    6048:	a90153f3 	stp	x19, x20, [sp, #16]
    604c:	f90013f5 	str	x21, [sp, #32]
    6050:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    6054:	911902b4 	add	x20, x21, #0x640
    6058:	f949da81 	ldr	x1, [x20, #5040]
    605c:	f949ee82 	ldr	x2, [x20, #5080]
    6060:	cb010001 	sub	x1, x0, x1
    6064:	eb02403f 	cmp	x1, x2, lsl #16
    6068:	54000382 	b.cs	60d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    606c:	d350fc22 	lsr	x2, x1, #16
    6070:	f949fe84 	ldr	x4, [x20, #5112]
    6074:	8b020842 	add	x2, x2, x2, lsl #2
    6078:	d37df042 	lsl	x2, x2, #3
    607c:	8b020083 	add	x3, x4, x2
    6080:	f9401073 	ldr	x19, [x3, #32]
    6084:	b40002b3 	cbz	x19, 60d8 <fwp_drop0+0x98>
    6088:	38626882 	ldrb	w2, [x4, x2]
    608c:	7100085f 	cmp	w2, #0x2
    6090:	540002c0 	b.eq	60e8 <fwp_drop0+0xa8>  // b.none
    6094:	7100045f 	cmp	w2, #0x1
    6098:	54000201 	b.ne	60d8 <fwp_drop0+0x98>  // b.any
    609c:	29430864 	ldp	w4, w2, [x3, #24]
    60a0:	92403c21 	and	x1, x1, #0xffff
    60a4:	9b047c21 	mul	x1, x1, x4
    60a8:	d360fc21 	lsr	x1, x1, #32
    60ac:	eb02003f 	cmp	x1, x2
    60b0:	54000142 	b.cs	60d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    60b4:	8b010273 	add	x19, x19, x1
    60b8:	39400261 	ldrb	w1, [x19]
    60bc:	340000e1 	cbz	w1, 60d8 <fwp_drop0+0x98>
    60c0:	7100043f 	cmp	w1, #0x1
    60c4:	540001e0 	b.eq	6100 <fwp_drop0+0xc0>  // b.none
    60c8:	7103fc3f 	cmp	w1, #0xff
    60cc:	540002e0 	b.eq	6128 <fwp_drop0+0xe8>  // b.none
    60d0:	51000421 	sub	w1, w1, #0x1
    60d4:	39000261 	strb	w1, [x19]
    60d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    60dc:	f94013f5 	ldr	x21, [sp, #32]
    60e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60e4:	d65f03c0 	ret
    60e8:	72003c3f 	tst	w1, #0xffff
    60ec:	54fffe60 	b.eq	60b8 <fwp_drop0+0x78>  // b.none
    60f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    60f4:	f94013f5 	ldr	x21, [sp, #32]
    60f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60fc:	d65f03c0 	ret
    6100:	f9400813 	ldr	x19, [x0, #16]
    6104:	97fffe9f 	bl	5b80 <fwp_rc_free_arr>
    6108:	911902a0 	add	x0, x21, #0x640
    610c:	f949d801 	ldr	x1, [x0, #5040]
    6110:	f949ec00 	ldr	x0, [x0, #5080]
    6114:	cb010261 	sub	x1, x19, x1
    6118:	eb00403f 	cmp	x1, x0, lsl #16
    611c:	54fffde2 	b.cs	60d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6120:	aa1303e0 	mov	x0, x19
    6124:	17ffffd2 	b	606c <fwp_drop0+0x2c>
    6128:	ca534660 	eor	x0, x19, x19, lsr #17
    612c:	911902b5 	add	x21, x21, #0x640
    6130:	ca402400 	eor	x0, x0, x0, lsr #9
    6134:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6138:	f94a2400 	ldr	x0, [x0, #5192]
    613c:	b5000080 	cbnz	x0, 614c <fwp_drop0+0x10c>
    6140:	14000010 	b	6180 <fwp_drop0+0x140>
    6144:	f9400800 	ldr	x0, [x0, #16]
    6148:	b40001c0 	cbz	x0, 6180 <fwp_drop0+0x140>
    614c:	f9400001 	ldr	x1, [x0]
    6150:	eb13003f 	cmp	x1, x19
    6154:	54ffff81 	b.ne	6144 <fwp_drop0+0x104>  // b.any
    6158:	f9400401 	ldr	x1, [x0, #8]
    615c:	d1000421 	sub	x1, x1, #0x1
    6160:	f9000401 	str	x1, [x0, #8]
    6164:	f103f83f 	cmp	x1, #0xfe
    6168:	54fffb81 	b.ne	60d8 <fwp_drop0+0x98>  // b.any
    616c:	aa1303e0 	mov	x0, x19
    6170:	97fffa08 	bl	4990 <fwp_rc_forget_slot>
    6174:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6178:	39000260 	strb	w0, [x19]
    617c:	17ffffd7 	b	60d8 <fwp_drop0+0x98>
    6180:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    6184:	91368000 	add	x0, x0, #0xda0
    6188:	97fff57e 	bl	3780 <fwp_trap>
    618c:	d503201f 	nop

0000000000006190 <fwp_arg_drop12>:
    6190:	7100003f 	cmp	w1, #0x0
    6194:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6198:	54000041 	b.ne	61a0 <fwp_arg_drop12+0x10>  // b.any
    619c:	d65f03c0 	ret
    61a0:	f9400000 	ldr	x0, [x0]
    61a4:	17ffffa7 	b	6040 <fwp_drop0>
    61a8:	d503201f 	nop
    61ac:	d503201f 	nop

00000000000061b0 <fwp_closure_drop>:
    61b0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xba0>
    61b4:	911900a4 	add	x4, x5, #0x640
    61b8:	aa0003e1 	mov	x1, x0
    61bc:	f949d882 	ldr	x2, [x4, #5040]
    61c0:	f949ec80 	ldr	x0, [x4, #5080]
    61c4:	cb020022 	sub	x2, x1, x2
    61c8:	eb00405f 	cmp	x2, x0, lsl #16
    61cc:	54000662 	b.cs	6298 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    61d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61d4:	d350fc43 	lsr	x3, x2, #16
    61d8:	910003fd 	mov	x29, sp
    61dc:	8b030863 	add	x3, x3, x3, lsl #2
    61e0:	f949fc84 	ldr	x4, [x4, #5112]
    61e4:	d37df063 	lsl	x3, x3, #3
    61e8:	f9000bf3 	str	x19, [sp, #16]
    61ec:	8b030080 	add	x0, x4, x3
    61f0:	f9401013 	ldr	x19, [x0, #32]
    61f4:	b40002b3 	cbz	x19, 6248 <fwp_closure_drop+0x98>
    61f8:	38636883 	ldrb	w3, [x4, x3]
    61fc:	7100087f 	cmp	w3, #0x2
    6200:	54000420 	b.eq	6284 <fwp_closure_drop+0xd4>  // b.none
    6204:	7100047f 	cmp	w3, #0x1
    6208:	54000201 	b.ne	6248 <fwp_closure_drop+0x98>  // b.any
    620c:	29430003 	ldp	w3, w0, [x0, #24]
    6210:	92403c42 	and	x2, x2, #0xffff
    6214:	9b037c42 	mul	x2, x2, x3
    6218:	d360fc42 	lsr	x2, x2, #32
    621c:	eb00005f 	cmp	x2, x0
    6220:	54000142 	b.cs	6248 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6224:	8b020273 	add	x19, x19, x2
    6228:	39400260 	ldrb	w0, [x19]
    622c:	340000e0 	cbz	w0, 6248 <fwp_closure_drop+0x98>
    6230:	7100041f 	cmp	w0, #0x1
    6234:	54000100 	b.eq	6254 <fwp_closure_drop+0xa4>  // b.none
    6238:	7103fc1f 	cmp	w0, #0xff
    623c:	54000300 	b.eq	629c <fwp_closure_drop+0xec>  // b.none
    6240:	51000400 	sub	w0, w0, #0x1
    6244:	39000260 	strb	w0, [x19]
    6248:	f9400bf3 	ldr	x19, [sp, #16]
    624c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6250:	d65f03c0 	ret
    6254:	d53bd040 	mrs	x0, tpidr_el0
    6258:	91400000 	add	x0, x0, #0x0, lsl #12
    625c:	91004000 	add	x0, x0, #0x10
    6260:	f9400000 	ldr	x0, [x0]
    6264:	b4000080 	cbz	x0, 6274 <fwp_closure_drop+0xc4>
    6268:	f9400bf3 	ldr	x19, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	17fff55d 	b	37e4 <fwp_closure_drop_push>
    6274:	f9400bf3 	ldr	x19, [sp, #16]
    6278:	aa0103e0 	mov	x0, x1
    627c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6280:	17fff5c8 	b	39a0 <fwp_closure_drop.part.0>
    6284:	72003c5f 	tst	w2, #0xffff
    6288:	54fffd00 	b.eq	6228 <fwp_closure_drop+0x78>  // b.none
    628c:	f9400bf3 	ldr	x19, [sp, #16]
    6290:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6294:	d65f03c0 	ret
    6298:	d65f03c0 	ret
    629c:	ca534660 	eor	x0, x19, x19, lsr #17
    62a0:	911900a5 	add	x5, x5, #0x640
    62a4:	ca402400 	eor	x0, x0, x0, lsr #9
    62a8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    62ac:	f94a2400 	ldr	x0, [x0, #5192]
    62b0:	b5000080 	cbnz	x0, 62c0 <fwp_closure_drop+0x110>
    62b4:	14000010 	b	62f4 <fwp_closure_drop+0x144>
    62b8:	f9400800 	ldr	x0, [x0, #16]
    62bc:	b40001c0 	cbz	x0, 62f4 <fwp_closure_drop+0x144>
    62c0:	f9400001 	ldr	x1, [x0]
    62c4:	eb13003f 	cmp	x1, x19
    62c8:	54ffff81 	b.ne	62b8 <fwp_closure_drop+0x108>  // b.any
    62cc:	f9400401 	ldr	x1, [x0, #8]
    62d0:	d1000421 	sub	x1, x1, #0x1
    62d4:	f9000401 	str	x1, [x0, #8]
    62d8:	f103f83f 	cmp	x1, #0xfe
    62dc:	54fffb61 	b.ne	6248 <fwp_closure_drop+0x98>  // b.any
    62e0:	aa1303e0 	mov	x0, x19
    62e4:	97fff9ab 	bl	4990 <fwp_rc_forget_slot>
    62e8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62ec:	39000260 	strb	w0, [x19]
    62f0:	17ffffd6 	b	6248 <fwp_closure_drop+0x98>
    62f4:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    62f8:	91368000 	add	x0, x0, #0xda0
    62fc:	97fff521 	bl	3780 <fwp_trap>

0000000000006300 <fwp_owned_tape_release>:
    6300:	b4000940 	cbz	x0, 6428 <fwp_owned_tape_release+0x128>
    6304:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6308:	910003fd 	mov	x29, sp
    630c:	a90153f3 	stp	x19, x20, [sp, #16]
    6310:	aa0003f3 	mov	x19, x0
    6314:	f9400000 	ldr	x0, [x0]
    6318:	b4000060 	cbz	x0, 6324 <fwp_owned_tape_release+0x24>
    631c:	f9400661 	ldr	x1, [x19, #8]
    6320:	f9000401 	str	x1, [x0, #8]
    6324:	f9400661 	ldr	x1, [x19, #8]
    6328:	b4000041 	cbz	x1, 6330 <fwp_owned_tape_release+0x30>
    632c:	f9000020 	str	x0, [x1]
    6330:	f9400a60 	ldr	x0, [x19, #16]
    6334:	f9403401 	ldr	x1, [x0, #104]
    6338:	b40005c1 	cbz	x1, 63f0 <fwp_owned_tape_release+0xf0>
    633c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6340:	eb00005f 	cmp	x2, x0
    6344:	540002ed 	b.le	63a0 <fwp_owned_tape_release+0xa0>
    6348:	d2800014 	mov	x20, #0x0                   	// #0
    634c:	f90013f5 	str	x21, [sp, #32]
    6350:	d2800015 	mov	x21, #0x0                   	// #0
    6354:	d503201f 	nop
    6358:	f9402260 	ldr	x0, [x19, #64]
    635c:	910006b5 	add	x21, x21, #0x1
    6360:	f8746800 	ldr	x0, [x0, x20]
    6364:	d63f0020 	blr	x1
    6368:	f9402260 	ldr	x0, [x19, #64]
    636c:	f9400a61 	ldr	x1, [x19, #16]
    6370:	8b140000 	add	x0, x0, x20
    6374:	91004294 	add	x20, x20, #0x10
    6378:	f9400400 	ldr	x0, [x0, #8]
    637c:	f9403421 	ldr	x1, [x1, #104]
    6380:	d63f0020 	blr	x1
    6384:	a9450261 	ldp	x1, x0, [x19, #80]
    6388:	cb010000 	sub	x0, x0, x1
    638c:	eb15001f 	cmp	x0, x21
    6390:	f9400a60 	ldr	x0, [x19, #16]
    6394:	f9403401 	ldr	x1, [x0, #104]
    6398:	54fffe0c 	b.gt	6358 <fwp_owned_tape_release+0x58>
    639c:	f94013f5 	ldr	x21, [sp, #32]
    63a0:	f9403663 	ldr	x3, [x19, #104]
    63a4:	f9401262 	ldr	x2, [x19, #32]
    63a8:	f100007f 	cmp	x3, #0x0
    63ac:	540001ed 	b.le	63e8 <fwp_owned_tape_release+0xe8>
    63b0:	d2800014 	mov	x20, #0x0                   	// #0
    63b4:	d503201f 	nop
    63b8:	f9402660 	ldr	x0, [x19, #72]
    63bc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    63c0:	eb02001f 	cmp	x0, x2
    63c4:	540000c0 	b.eq	63dc <fwp_owned_tape_release+0xdc>  // b.none
    63c8:	d63f0020 	blr	x1
    63cc:	f9400a60 	ldr	x0, [x19, #16]
    63d0:	f9401262 	ldr	x2, [x19, #32]
    63d4:	f9403663 	ldr	x3, [x19, #104]
    63d8:	f9403401 	ldr	x1, [x0, #104]
    63dc:	91000694 	add	x20, x20, #0x1
    63e0:	eb14007f 	cmp	x3, x20
    63e4:	54fffeac 	b.gt	63b8 <fwp_owned_tape_release+0xb8>
    63e8:	aa0203e0 	mov	x0, x2
    63ec:	d63f0020 	blr	x1
    63f0:	f9401660 	ldr	x0, [x19, #40]
    63f4:	97ffff6f 	bl	61b0 <fwp_closure_drop>
    63f8:	f9401a60 	ldr	x0, [x19, #48]
    63fc:	97ffff6d 	bl	61b0 <fwp_closure_drop>
    6400:	f9401e60 	ldr	x0, [x19, #56]
    6404:	97ffff6b 	bl	61b0 <fwp_closure_drop>
    6408:	f9402260 	ldr	x0, [x19, #64]
    640c:	97fffa01 	bl	4c10 <fwp_mem_free>
    6410:	f9402660 	ldr	x0, [x19, #72]
    6414:	97fff9ff 	bl	4c10 <fwp_mem_free>
    6418:	aa1303e0 	mov	x0, x19
    641c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6420:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6424:	17fff9fb 	b	4c10 <fwp_mem_free>
    6428:	d65f03c0 	ret
    642c:	d503201f 	nop

0000000000006430 <fwp_tape_finish>:
    6430:	d10203ff 	sub	sp, sp, #0x80
    6434:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6438:	f947f421 	ldr	x1, [x1, #4072]
    643c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6440:	910103fd 	add	x29, sp, #0x40
    6444:	a9065bf5 	stp	x21, x22, [sp, #96]
    6448:	a90763f7 	stp	x23, x24, [sp, #112]
    644c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6450:	910182f6 	add	x22, x23, #0x60
    6454:	f9400022 	ldr	x2, [x1]
    6458:	f9001fe2 	str	x2, [sp, #56]
    645c:	d2800002 	mov	x2, #0x0                   	// #0
    6460:	910382c0 	add	x0, x22, #0xe0
    6464:	97fff7c8 	bl	4384 <fwp_tape_buffers_dispose>
    6468:	f9008edf 	str	xzr, [x22, #280]
    646c:	f9406ec0 	ldr	x0, [x22, #216]
    6470:	f100001f 	cmp	x0, #0x0
    6474:	5400034d 	b.le	64dc <fwp_tape_finish+0xac>
    6478:	910003f8 	mov	x24, sp
    647c:	d2800015 	mov	x21, #0x0                   	// #0
    6480:	a90553f3 	stp	x19, x20, [sp, #80]
    6484:	d2800014 	mov	x20, #0x0                   	// #0
    6488:	91000694 	add	x20, x20, #0x1
    648c:	f94046d3 	ldr	x19, [x22, #136]
    6490:	8b150273 	add	x19, x19, x21
    6494:	9101a2b5 	add	x21, x21, #0x68
    6498:	aa1303e0 	mov	x0, x19
    649c:	97fff2be 	bl	2f94 <fwp_tape_unlink_scope>
    64a0:	aa1803e0 	mov	x0, x24
    64a4:	a9440663 	ldp	x3, x1, [x19, #64]
    64a8:	f9001be1 	str	x1, [sp, #48]
    64ac:	f9400e62 	ldr	x2, [x19, #24]
    64b0:	a9020be3 	stp	x3, x2, [sp, #32]
    64b4:	ad410261 	ldp	q1, q0, [x19, #32]
    64b8:	ad0003e1 	stp	q1, q0, [sp]
    64bc:	97fff7b2 	bl	4384 <fwp_tape_buffers_dispose>
    64c0:	f9403260 	ldr	x0, [x19, #96]
    64c4:	97ffff8f 	bl	6300 <fwp_owned_tape_release>
    64c8:	f900327f 	str	xzr, [x19, #96]
    64cc:	f9406ec0 	ldr	x0, [x22, #216]
    64d0:	eb14001f 	cmp	x0, x20
    64d4:	54fffdac 	b.gt	6488 <fwp_tape_finish+0x58>
    64d8:	a94553f3 	ldp	x19, x20, [sp, #80]
    64dc:	910182e0 	add	x0, x23, #0x60
    64e0:	f9404400 	ldr	x0, [x0, #136]
    64e4:	b4000040 	cbz	x0, 64ec <fwp_tape_finish+0xbc>
    64e8:	97fff786 	bl	4300 <ad_raw_free.part.0>
    64ec:	910182f7 	add	x23, x23, #0x60
    64f0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    64f4:	f947f400 	ldr	x0, [x0, #4072]
    64f8:	f90046ff 	str	xzr, [x23, #136]
    64fc:	f9006eff 	str	xzr, [x23, #216]
    6500:	f90092ff 	str	xzr, [x23, #288]
    6504:	f900b2ff 	str	xzr, [x23, #352]
    6508:	f9401fe2 	ldr	x2, [sp, #56]
    650c:	f9400001 	ldr	x1, [x0]
    6510:	eb010042 	subs	x2, x2, x1
    6514:	d2800001 	mov	x1, #0x0                   	// #0
    6518:	540000c1 	b.ne	6530 <fwp_tape_finish+0x100>  // b.any
    651c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6520:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6524:	a94763f7 	ldp	x23, x24, [sp, #112]
    6528:	910203ff 	add	sp, sp, #0x80
    652c:	d65f03c0 	ret
    6530:	a90553f3 	stp	x19, x20, [sp, #80]
    6534:	97fff0b7 	bl	2810 <__stack_chk_fail@plt>
    6538:	d503201f 	nop
    653c:	d503201f 	nop

0000000000006540 <fwp_tape_scope_release>:
    6540:	d10243ff 	sub	sp, sp, #0x90
    6544:	a9047bfd 	stp	x29, x30, [sp, #64]
    6548:	910103fd 	add	x29, sp, #0x40
    654c:	a90553f3 	stp	x19, x20, [sp, #80]
    6550:	aa0003f4 	mov	x20, x0
    6554:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6558:	f947f400 	ldr	x0, [x0, #4072]
    655c:	b9400285 	ldr	w5, [x20]
    6560:	f9400001 	ldr	x1, [x0]
    6564:	f9001fe1 	str	x1, [sp, #56]
    6568:	d2800001 	mov	x1, #0x0                   	// #0
    656c:	37f806c5 	tbnz	w5, #31, 6644 <fwp_tape_scope_release+0x104>
    6570:	a90763f7 	stp	x23, x24, [sp, #112]
    6574:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6578:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    657c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6580:	d00000d3 	adrp	x19, 20000 <__data_start>
    6584:	910003f7 	mov	x23, sp
    6588:	91018273 	add	x19, x19, #0x60
    658c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6590:	a9065bf5 	stp	x21, x22, [sp, #96]
    6594:	52800d16 	mov	w22, #0x68                  	// #104
    6598:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    659c:	f90043f9 	str	x25, [sp, #128]
    65a0:	14000006 	b	65b8 <fwp_tape_scope_release+0x78>
    65a4:	97fff778 	bl	4384 <fwp_tape_buffers_dispose>
    65a8:	aa1903e0 	mov	x0, x25
    65ac:	97ffff55 	bl	6300 <fwp_owned_tape_release>
    65b0:	b9400285 	ldr	w5, [x20]
    65b4:	37f80425 	tbnz	w5, #31, 6638 <fwp_tape_scope_release+0xf8>
    65b8:	f9404666 	ldr	x6, [x19, #136]
    65bc:	9b367ca5 	smull	x5, w5, w22
    65c0:	8b0500c0 	add	x0, x6, x5
    65c4:	97fff274 	bl	2f94 <fwp_tape_unlink_scope>
    65c8:	ad410001 	ldp	q1, q0, [x0, #32]
    65cc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    65d0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    65d4:	f9400c03 	ldr	x3, [x0, #24]
    65d8:	ad0003e1 	stp	q1, q0, [sp]
    65dc:	b86568c1 	ldr	w1, [x6, x5]
    65e0:	a9440804 	ldp	x4, x2, [x0, #64]
    65e4:	b900041f 	str	wzr, [x0, #4]
    65e8:	f9403019 	ldr	x25, [x0, #96]
    65ec:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    65f0:	f9000c1f 	str	xzr, [x0, #24]
    65f4:	a9020fe4 	stp	x4, x3, [sp, #32]
    65f8:	f9001be2 	str	x2, [sp, #48]
    65fc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6600:	f900301f 	str	xzr, [x0, #96]
    6604:	6b15003f 	cmp	w1, w21
    6608:	540000e8 	b.hi	6624 <fwp_tape_scope_release+0xe4>  // b.pmore
    660c:	9343fca5 	asr	x5, x5, #3
    6610:	f940b260 	ldr	x0, [x19, #352]
    6614:	9b187ca5 	mul	x5, x5, x24
    6618:	eb0000bf 	cmp	x5, x0
    661c:	5400004a 	b.ge	6624 <fwp_tape_scope_release+0xe4>  // b.tcont
    6620:	f900b265 	str	x5, [x19, #352]
    6624:	aa1703e0 	mov	x0, x23
    6628:	b5fffbf9 	cbnz	x25, 65a4 <fwp_tape_scope_release+0x64>
    662c:	97fff79e 	bl	44a4 <fwp_tape_buffers_release>
    6630:	b9400285 	ldr	w5, [x20]
    6634:	36fffc25 	tbz	w5, #31, 65b8 <fwp_tape_scope_release+0x78>
    6638:	a9465bf5 	ldp	x21, x22, [sp, #96]
    663c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6640:	f94043f9 	ldr	x25, [sp, #128]
    6644:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6648:	f947f400 	ldr	x0, [x0, #4072]
    664c:	f9401fe2 	ldr	x2, [sp, #56]
    6650:	f9400001 	ldr	x1, [x0]
    6654:	eb010042 	subs	x2, x2, x1
    6658:	d2800001 	mov	x1, #0x0                   	// #0
    665c:	540000a1 	b.ne	6670 <fwp_tape_scope_release+0x130>  // b.any
    6660:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6664:	a94553f3 	ldp	x19, x20, [sp, #80]
    6668:	910243ff 	add	sp, sp, #0x90
    666c:	d65f03c0 	ret
    6670:	a9065bf5 	stp	x21, x22, [sp, #96]
    6674:	a90763f7 	stp	x23, x24, [sp, #112]
    6678:	f90043f9 	str	x25, [sp, #128]
    667c:	97fff065 	bl	2810 <__stack_chk_fail@plt>

0000000000006680 <fwp_task_dispose>:
    6680:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6684:	910003fd 	mov	x29, sp
    6688:	f9000bf3 	str	x19, [sp, #16]
    668c:	aa0003f3 	mov	x19, x0
    6690:	39414000 	ldrb	w0, [x0, #80]
    6694:	36000720 	tbz	w0, #0, 6778 <fwp_task_dispose+0xf8>
    6698:	f9400a60 	ldr	x0, [x19, #16]
    669c:	b50006e0 	cbnz	x0, 6778 <fwp_task_dispose+0xf8>
    66a0:	a9478660 	ldp	x0, x1, [x19, #120]
    66a4:	39014e7f 	strb	wzr, [x19, #83]
    66a8:	f9003e7f 	str	xzr, [x19, #120]
    66ac:	f100003f 	cmp	x1, #0x0
    66b0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    66b4:	54000040 	b.eq	66bc <fwp_task_dispose+0x3c>  // b.none
    66b8:	d63f0020 	blr	x1
    66bc:	f9405660 	ldr	x0, [x19, #168]
    66c0:	97fff954 	bl	4c10 <fwp_mem_free>
    66c4:	f900567f 	str	xzr, [x19, #168]
    66c8:	b9405e60 	ldr	w0, [x19, #92]
    66cc:	7100041f 	cmp	w0, #0x1
    66d0:	54000420 	b.eq	6754 <fwp_task_dispose+0xd4>  // b.none
    66d4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    66d8:	91190042 	add	x2, x2, #0x640
    66dc:	f949d840 	ldr	x0, [x2, #5040]
    66e0:	f949ec41 	ldr	x1, [x2, #5080]
    66e4:	cb000260 	sub	x0, x19, x0
    66e8:	eb01401f 	cmp	x0, x1, lsl #16
    66ec:	540002e2 	b.cs	6748 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    66f0:	d350fc01 	lsr	x1, x0, #16
    66f4:	f949fc44 	ldr	x4, [x2, #5112]
    66f8:	8b010821 	add	x1, x1, x1, lsl #2
    66fc:	d37df021 	lsl	x1, x1, #3
    6700:	8b010083 	add	x3, x4, x1
    6704:	f9401062 	ldr	x2, [x3, #32]
    6708:	b4000202 	cbz	x2, 6748 <fwp_task_dispose+0xc8>
    670c:	38616881 	ldrb	w1, [x4, x1]
    6710:	7100083f 	cmp	w1, #0x2
    6714:	54000280 	b.eq	6764 <fwp_task_dispose+0xe4>  // b.none
    6718:	7100043f 	cmp	w1, #0x1
    671c:	54000161 	b.ne	6748 <fwp_task_dispose+0xc8>  // b.any
    6720:	29430464 	ldp	w4, w1, [x3, #24]
    6724:	92403c00 	and	x0, x0, #0xffff
    6728:	9b047c00 	mul	x0, x0, x4
    672c:	d360fc00 	lsr	x0, x0, #32
    6730:	eb01001f 	cmp	x0, x1
    6734:	540000a2 	b.cs	6748 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6738:	8b000042 	add	x2, x2, x0
    673c:	39400040 	ldrb	w0, [x2]
    6740:	7100041f 	cmp	w0, #0x1
    6744:	54000080 	b.eq	6754 <fwp_task_dispose+0xd4>  // b.none
    6748:	f9400bf3 	ldr	x19, [sp, #16]
    674c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6750:	d65f03c0 	ret
    6754:	aa1303e0 	mov	x0, x19
    6758:	f9400bf3 	ldr	x19, [sp, #16]
    675c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6760:	17fff92c 	b	4c10 <fwp_mem_free>
    6764:	72003c1f 	tst	w0, #0xffff
    6768:	54fffea0 	b.eq	673c <fwp_task_dispose+0xbc>  // b.none
    676c:	f9400bf3 	ldr	x19, [sp, #16]
    6770:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6774:	d65f03c0 	ret
    6778:	97fff03a 	bl	2860 <abort@plt>
    677c:	d503201f 	nop

0000000000006780 <fwp_free_zombie>:
    6780:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6784:	910003fd 	mov	x29, sp
    6788:	a90153f3 	stp	x19, x20, [sp, #16]
    678c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6790:	91018281 	add	x1, x20, #0x60
    6794:	f940b433 	ldr	x19, [x1, #360]
    6798:	b4000333 	cbz	x19, 67fc <fwp_free_zombie+0x7c>
    679c:	f9404c20 	ldr	x0, [x1, #152]
    67a0:	eb00027f 	cmp	x19, x0
    67a4:	540002c0 	b.eq	67fc <fwp_free_zombie+0x7c>  // b.none
    67a8:	b9417022 	ldr	w2, [x1, #368]
    67ac:	f9400a60 	ldr	x0, [x19, #16]
    67b0:	7100fc5f 	cmp	w2, #0x3f
    67b4:	5400078c 	b.gt	68a4 <fwp_free_zombie+0x124>
    67b8:	91060023 	add	x3, x1, #0x180
    67bc:	11000444 	add	w4, w2, #0x1
    67c0:	b9017024 	str	w4, [x1, #368]
    67c4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67c8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    67cc:	a9530261 	ldp	x1, x0, [x19, #304]
    67d0:	b4000741 	cbz	x1, 68b8 <fwp_free_zombie+0x138>
    67d4:	f9009c20 	str	x0, [x1, #312]
    67d8:	b4000040 	cbz	x0, 67e0 <fwp_free_zombie+0x60>
    67dc:	f9009801 	str	x1, [x0, #304]
    67e0:	91018294 	add	x20, x20, #0x60
    67e4:	b9405e60 	ldr	w0, [x19, #92]
    67e8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    67ec:	f900b69f 	str	xzr, [x20, #360]
    67f0:	34000140 	cbz	w0, 6818 <fwp_free_zombie+0x98>
    67f4:	7100041f 	cmp	w0, #0x1
    67f8:	54000080 	b.eq	6808 <fwp_free_zombie+0x88>  // b.none
    67fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6800:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6804:	d65f03c0 	ret
    6808:	aa1303e0 	mov	x0, x19
    680c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6810:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6814:	17ffff9b 	b	6680 <fwp_task_dispose>
    6818:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    681c:	91190082 	add	x2, x4, #0x640
    6820:	f949d841 	ldr	x1, [x2, #5040]
    6824:	f949ec40 	ldr	x0, [x2, #5080]
    6828:	cb010261 	sub	x1, x19, x1
    682c:	eb00403f 	cmp	x1, x0, lsl #16
    6830:	54fffe62 	b.cs	67fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6834:	d350fc20 	lsr	x0, x1, #16
    6838:	f949fc43 	ldr	x3, [x2, #5112]
    683c:	8b000800 	add	x0, x0, x0, lsl #2
    6840:	d37df000 	lsl	x0, x0, #3
    6844:	8b000062 	add	x2, x3, x0
    6848:	f9401054 	ldr	x20, [x2, #32]
    684c:	b4fffd94 	cbz	x20, 67fc <fwp_free_zombie+0x7c>
    6850:	38606860 	ldrb	w0, [x3, x0]
    6854:	7100081f 	cmp	w0, #0x2
    6858:	54000360 	b.eq	68c4 <fwp_free_zombie+0x144>  // b.none
    685c:	7100041f 	cmp	w0, #0x1
    6860:	54fffce1 	b.ne	67fc <fwp_free_zombie+0x7c>  // b.any
    6864:	29430043 	ldp	w3, w0, [x2, #24]
    6868:	92403c21 	and	x1, x1, #0xffff
    686c:	9b037c21 	mul	x1, x1, x3
    6870:	d360fc21 	lsr	x1, x1, #32
    6874:	eb00003f 	cmp	x1, x0
    6878:	54fffc22 	b.cs	67fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    687c:	8b010294 	add	x20, x20, x1
    6880:	39400280 	ldrb	w0, [x20]
    6884:	34fffbc0 	cbz	w0, 67fc <fwp_free_zombie+0x7c>
    6888:	7100041f 	cmp	w0, #0x1
    688c:	54fffbe0 	b.eq	6808 <fwp_free_zombie+0x88>  // b.none
    6890:	7103fc1f 	cmp	w0, #0xff
    6894:	540001e0 	b.eq	68d0 <fwp_free_zombie+0x150>  // b.none
    6898:	51000400 	sub	w0, w0, #0x1
    689c:	39000280 	strb	w0, [x20]
    68a0:	17ffffd7 	b	67fc <fwp_free_zombie+0x7c>
    68a4:	f9400e61 	ldr	x1, [x19, #24]
    68a8:	97fff022 	bl	2930 <munmap@plt>
    68ac:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    68b0:	a9530261 	ldp	x1, x0, [x19, #304]
    68b4:	b5fff901 	cbnz	x1, 67d4 <fwp_free_zombie+0x54>
    68b8:	91018282 	add	x2, x20, #0x60
    68bc:	f901c040 	str	x0, [x2, #896]
    68c0:	17ffffc6 	b	67d8 <fwp_free_zombie+0x58>
    68c4:	72003c3f 	tst	w1, #0xffff
    68c8:	54fff9a1 	b.ne	67fc <fwp_free_zombie+0x7c>  // b.any
    68cc:	17ffffed 	b	6880 <fwp_free_zombie+0x100>
    68d0:	ca544680 	eor	x0, x20, x20, lsr #17
    68d4:	91190084 	add	x4, x4, #0x640
    68d8:	ca402400 	eor	x0, x0, x0, lsr #9
    68dc:	8b200c80 	add	x0, x4, w0, uxtb #3
    68e0:	f94a2400 	ldr	x0, [x0, #5192]
    68e4:	b5000080 	cbnz	x0, 68f4 <fwp_free_zombie+0x174>
    68e8:	14000010 	b	6928 <fwp_free_zombie+0x1a8>
    68ec:	f9400800 	ldr	x0, [x0, #16]
    68f0:	b40001c0 	cbz	x0, 6928 <fwp_free_zombie+0x1a8>
    68f4:	f9400001 	ldr	x1, [x0]
    68f8:	eb14003f 	cmp	x1, x20
    68fc:	54ffff81 	b.ne	68ec <fwp_free_zombie+0x16c>  // b.any
    6900:	f9400401 	ldr	x1, [x0, #8]
    6904:	d1000421 	sub	x1, x1, #0x1
    6908:	f9000401 	str	x1, [x0, #8]
    690c:	f103f83f 	cmp	x1, #0xfe
    6910:	54fff761 	b.ne	67fc <fwp_free_zombie+0x7c>  // b.any
    6914:	aa1403e0 	mov	x0, x20
    6918:	97fff81e 	bl	4990 <fwp_rc_forget_slot>
    691c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6920:	39000280 	strb	w0, [x20]
    6924:	17ffffb6 	b	67fc <fwp_free_zombie+0x7c>
    6928:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    692c:	91368000 	add	x0, x0, #0xda0
    6930:	97fff394 	bl	3780 <fwp_trap>

0000000000006934 <fwp_block>:
    6934:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6938:	910003fd 	mov	x29, sp
    693c:	a90153f3 	stp	x19, x20, [sp, #16]
    6940:	d00000d3 	adrp	x19, 20000 <__data_start>
    6944:	91018274 	add	x20, x19, #0x60
    6948:	f9406682 	ldr	x2, [x20, #200]
    694c:	b4000622 	cbz	x2, 6a10 <fwp_block+0xdc>
    6950:	91018261 	add	x1, x19, #0x60
    6954:	f9408040 	ldr	x0, [x2, #256]
    6958:	f9006420 	str	x0, [x1, #200]
    695c:	b4000680 	cbz	x0, 6a2c <fwp_block+0xf8>
    6960:	91018263 	add	x3, x19, #0x60
    6964:	3901505f 	strb	wzr, [x2, #84]
    6968:	f9404c64 	ldr	x4, [x3, #152]
    696c:	eb02009f 	cmp	x4, x2
    6970:	54000440 	b.eq	69f8 <fwp_block+0xc4>  // b.none
    6974:	f941c465 	ldr	x5, [x3, #904]
    6978:	f9004c62 	str	x2, [x3, #152]
    697c:	f9400441 	ldr	x1, [x2, #8]
    6980:	f9004885 	str	x5, [x4, #144]
    6984:	f941c865 	ldr	x5, [x3, #912]
    6988:	f9004c85 	str	x5, [x4, #152]
    698c:	f941cc65 	ldr	x5, [x3, #920]
    6990:	f9005085 	str	x5, [x4, #160]
    6994:	f941d065 	ldr	x5, [x3, #928]
    6998:	f9005485 	str	x5, [x4, #168]
    699c:	f941d465 	ldr	x5, [x3, #936]
    69a0:	f9005885 	str	x5, [x4, #176]
    69a4:	f941d865 	ldr	x5, [x3, #944]
    69a8:	f9005c85 	str	x5, [x4, #184]
    69ac:	f941dc65 	ldr	x5, [x3, #952]
    69b0:	f9006085 	str	x5, [x4, #192]
    69b4:	f9400480 	ldr	x0, [x4, #8]
    69b8:	f9404844 	ldr	x4, [x2, #144]
    69bc:	f901c464 	str	x4, [x3, #904]
    69c0:	f9404c44 	ldr	x4, [x2, #152]
    69c4:	f901c864 	str	x4, [x3, #912]
    69c8:	f9405044 	ldr	x4, [x2, #160]
    69cc:	f901cc64 	str	x4, [x3, #920]
    69d0:	f9405444 	ldr	x4, [x2, #168]
    69d4:	f901d064 	str	x4, [x3, #928]
    69d8:	f9405844 	ldr	x4, [x2, #176]
    69dc:	f901d464 	str	x4, [x3, #936]
    69e0:	a94b8844 	ldp	x4, x2, [x2, #184]
    69e4:	f901d864 	str	x4, [x3, #944]
    69e8:	f901dc62 	str	x2, [x3, #952]
    69ec:	97ffefa1 	bl	2870 <swapcontext@plt>
    69f0:	97ffff64 	bl	6780 <fwp_free_zombie>
    69f4:	d503201f 	nop
    69f8:	91018260 	add	x0, x19, #0x60
    69fc:	b943c000 	ldr	w0, [x0, #960]
    6a00:	340001a0 	cbz	w0, 6a34 <fwp_block+0x100>
    6a04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a0c:	d65f03c0 	ret
    6a10:	97fff70d 	bl	4644 <fwp_poll_events>
    6a14:	f9406682 	ldr	x2, [x20, #200]
    6a18:	b4ffffc2 	cbz	x2, 6a10 <fwp_block+0xdc>
    6a1c:	91018261 	add	x1, x19, #0x60
    6a20:	f9408040 	ldr	x0, [x2, #256]
    6a24:	f9006420 	str	x0, [x1, #200]
    6a28:	b5fff9c0 	cbnz	x0, 6960 <fwp_block+0x2c>
    6a2c:	f900603f 	str	xzr, [x1, #192]
    6a30:	17ffffcc 	b	6960 <fwp_block+0x2c>
    6a34:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    6a38:	913b4000 	add	x0, x0, #0xed0
    6a3c:	97ffefd9 	bl	29a0 <getenv@plt>
    6a40:	5284e202 	mov	w2, #0x2710                	// #10000
    6a44:	b4000060 	cbz	x0, 6a50 <fwp_block+0x11c>
    6a48:	39400001 	ldrb	w1, [x0]
    6a4c:	350000c1 	cbnz	w1, 6a64 <fwp_block+0x130>
    6a50:	91018273 	add	x19, x19, #0x60
    6a54:	b903c262 	str	w2, [x19, #960]
    6a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a60:	d65f03c0 	ret
    6a64:	52800142 	mov	w2, #0xa                   	// #10
    6a68:	d2800001 	mov	x1, #0x0                   	// #0
    6a6c:	97ffef1d 	bl	26e0 <strtoll@plt>
    6a70:	d1000403 	sub	x3, x0, #0x1
    6a74:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6a78:	eb02007f 	cmp	x3, x2
    6a7c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6a80:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6a84:	17fffff3 	b	6a50 <fwp_block+0x11c>
    6a88:	d503201f 	nop
    6a8c:	d503201f 	nop

0000000000006a90 <fwp_drop4>:
    6a90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6a94:	910003fd 	mov	x29, sp
    6a98:	a90153f3 	stp	x19, x20, [sp, #16]
    6a9c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    6aa0:	f90013f5 	str	x21, [sp, #32]
    6aa4:	91190275 	add	x21, x19, #0x640
    6aa8:	f949daa1 	ldr	x1, [x21, #5040]
    6aac:	f949eea2 	ldr	x2, [x21, #5080]
    6ab0:	cb010001 	sub	x1, x0, x1
    6ab4:	eb02403f 	cmp	x1, x2, lsl #16
    6ab8:	54000382 	b.cs	6b28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6abc:	d350fc22 	lsr	x2, x1, #16
    6ac0:	f949fea3 	ldr	x3, [x21, #5112]
    6ac4:	8b020842 	add	x2, x2, x2, lsl #2
    6ac8:	d37df042 	lsl	x2, x2, #3
    6acc:	8b020064 	add	x4, x3, x2
    6ad0:	f9401094 	ldr	x20, [x4, #32]
    6ad4:	b40002b4 	cbz	x20, 6b28 <fwp_drop4+0x98>
    6ad8:	38626862 	ldrb	w2, [x3, x2]
    6adc:	7100085f 	cmp	w2, #0x2
    6ae0:	540007a0 	b.eq	6bd4 <fwp_drop4+0x144>  // b.none
    6ae4:	7100045f 	cmp	w2, #0x1
    6ae8:	54000201 	b.ne	6b28 <fwp_drop4+0x98>  // b.any
    6aec:	29430885 	ldp	w5, w2, [x4, #24]
    6af0:	92403c21 	and	x1, x1, #0xffff
    6af4:	9b057c21 	mul	x1, x1, x5
    6af8:	d360fc21 	lsr	x1, x1, #32
    6afc:	eb02003f 	cmp	x1, x2
    6b00:	54000142 	b.cs	6b28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b04:	8b010294 	add	x20, x20, x1
    6b08:	39400281 	ldrb	w1, [x20]
    6b0c:	340000e1 	cbz	w1, 6b28 <fwp_drop4+0x98>
    6b10:	7100043f 	cmp	w1, #0x1
    6b14:	54000120 	b.eq	6b38 <fwp_drop4+0xa8>  // b.none
    6b18:	7103fc3f 	cmp	w1, #0xff
    6b1c:	540007c0 	b.eq	6c14 <fwp_drop4+0x184>  // b.none
    6b20:	51000421 	sub	w1, w1, #0x1
    6b24:	39000281 	strb	w1, [x20]
    6b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b2c:	f94013f5 	ldr	x21, [sp, #32]
    6b30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b34:	d65f03c0 	ret
    6b38:	f9400001 	ldr	x1, [x0]
    6b3c:	b7f80581 	tbnz	x1, #63, 6bec <fwp_drop4+0x15c>
    6b40:	91190273 	add	x19, x19, #0x640
    6b44:	f949da61 	ldr	x1, [x19, #5040]
    6b48:	f949ee62 	ldr	x2, [x19, #5080]
    6b4c:	cb010001 	sub	x1, x0, x1
    6b50:	eb02403f 	cmp	x1, x2, lsl #16
    6b54:	54fffea2 	b.cs	6b28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b58:	d350fc22 	lsr	x2, x1, #16
    6b5c:	8b020842 	add	x2, x2, x2, lsl #2
    6b60:	d37df042 	lsl	x2, x2, #3
    6b64:	8b020065 	add	x5, x3, x2
    6b68:	f94010a4 	ldr	x4, [x5, #32]
    6b6c:	b4fffde4 	cbz	x4, 6b28 <fwp_drop4+0x98>
    6b70:	38626862 	ldrb	w2, [x3, x2]
    6b74:	7100085f 	cmp	w2, #0x2
    6b78:	54000220 	b.eq	6bbc <fwp_drop4+0x12c>  // b.none
    6b7c:	7100045f 	cmp	w2, #0x1
    6b80:	54fffd41 	b.ne	6b28 <fwp_drop4+0x98>  // b.any
    6b84:	294308a3 	ldp	w3, w2, [x5, #24]
    6b88:	92403c21 	and	x1, x1, #0xffff
    6b8c:	9b037c21 	mul	x1, x1, x3
    6b90:	d360fc21 	lsr	x1, x1, #32
    6b94:	eb02003f 	cmp	x1, x2
    6b98:	54fffc82 	b.cs	6b28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b9c:	8b010084 	add	x4, x4, x1
    6ba0:	39400081 	ldrb	w1, [x4]
    6ba4:	7100043f 	cmp	w1, #0x1
    6ba8:	54fffc01 	b.ne	6b28 <fwp_drop4+0x98>  // b.any
    6bac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bb0:	f94013f5 	ldr	x21, [sp, #32]
    6bb4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bb8:	17fff816 	b	4c10 <fwp_mem_free>
    6bbc:	72003c3f 	tst	w1, #0xffff
    6bc0:	54ffff00 	b.eq	6ba0 <fwp_drop4+0x110>  // b.none
    6bc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bc8:	f94013f5 	ldr	x21, [sp, #32]
    6bcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bd0:	d65f03c0 	ret
    6bd4:	72003c3f 	tst	w1, #0xffff
    6bd8:	54fff980 	b.eq	6b08 <fwp_drop4+0x78>  // b.none
    6bdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6be0:	f94013f5 	ldr	x21, [sp, #32]
    6be4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6be8:	d65f03c0 	ret
    6bec:	f9400414 	ldr	x20, [x0, #8]
    6bf0:	97fffbe4 	bl	5b80 <fwp_rc_free_arr>
    6bf4:	91190260 	add	x0, x19, #0x640
    6bf8:	f949d801 	ldr	x1, [x0, #5040]
    6bfc:	f949ec00 	ldr	x0, [x0, #5080]
    6c00:	cb010281 	sub	x1, x20, x1
    6c04:	eb00403f 	cmp	x1, x0, lsl #16
    6c08:	54fff902 	b.cs	6b28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c0c:	aa1403e0 	mov	x0, x20
    6c10:	17ffffab 	b	6abc <fwp_drop4+0x2c>
    6c14:	ca544680 	eor	x0, x20, x20, lsr #17
    6c18:	91190273 	add	x19, x19, #0x640
    6c1c:	ca402400 	eor	x0, x0, x0, lsr #9
    6c20:	8b200e60 	add	x0, x19, w0, uxtb #3
    6c24:	f94a2400 	ldr	x0, [x0, #5192]
    6c28:	b5000080 	cbnz	x0, 6c38 <fwp_drop4+0x1a8>
    6c2c:	14000010 	b	6c6c <fwp_drop4+0x1dc>
    6c30:	f9400800 	ldr	x0, [x0, #16]
    6c34:	b40001c0 	cbz	x0, 6c6c <fwp_drop4+0x1dc>
    6c38:	f9400001 	ldr	x1, [x0]
    6c3c:	eb14003f 	cmp	x1, x20
    6c40:	54ffff81 	b.ne	6c30 <fwp_drop4+0x1a0>  // b.any
    6c44:	f9400401 	ldr	x1, [x0, #8]
    6c48:	d1000421 	sub	x1, x1, #0x1
    6c4c:	f9000401 	str	x1, [x0, #8]
    6c50:	f103f83f 	cmp	x1, #0xfe
    6c54:	54fff6a1 	b.ne	6b28 <fwp_drop4+0x98>  // b.any
    6c58:	aa1403e0 	mov	x0, x20
    6c5c:	97fff74d 	bl	4990 <fwp_rc_forget_slot>
    6c60:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c64:	39000280 	strb	w0, [x20]
    6c68:	17ffffb0 	b	6b28 <fwp_drop4+0x98>
    6c6c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    6c70:	91368000 	add	x0, x0, #0xda0
    6c74:	97fff2c3 	bl	3780 <fwp_trap>
    6c78:	d503201f 	nop
    6c7c:	d503201f 	nop

0000000000006c80 <fwp_caps161>:
    6c80:	34000041 	cbz	w1, 6c88 <fwp_caps161+0x8>
    6c84:	d65f03c0 	ret
    6c88:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6c8c:	91190063 	add	x3, x3, #0x640
    6c90:	f949d861 	ldr	x1, [x3, #5040]
    6c94:	f949ec62 	ldr	x2, [x3, #5080]
    6c98:	cb010001 	sub	x1, x0, x1
    6c9c:	eb02403f 	cmp	x1, x2, lsl #16
    6ca0:	54ffff22 	b.cs	6c84 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ca4:	d350fc22 	lsr	x2, x1, #16
    6ca8:	f949fc65 	ldr	x5, [x3, #5112]
    6cac:	8b020842 	add	x2, x2, x2, lsl #2
    6cb0:	d37df042 	lsl	x2, x2, #3
    6cb4:	8b0200a4 	add	x4, x5, x2
    6cb8:	f9401083 	ldr	x3, [x4, #32]
    6cbc:	b4fffe43 	cbz	x3, 6c84 <fwp_caps161+0x4>
    6cc0:	386268a2 	ldrb	w2, [x5, x2]
    6cc4:	7100085f 	cmp	w2, #0x2
    6cc8:	540001c0 	b.eq	6d00 <fwp_caps161+0x80>  // b.none
    6ccc:	7100045f 	cmp	w2, #0x1
    6cd0:	54fffda1 	b.ne	6c84 <fwp_caps161+0x4>  // b.any
    6cd4:	29430885 	ldp	w5, w2, [x4, #24]
    6cd8:	92403c21 	and	x1, x1, #0xffff
    6cdc:	9b057c21 	mul	x1, x1, x5
    6ce0:	d360fc21 	lsr	x1, x1, #32
    6ce4:	eb02003f 	cmp	x1, x2
    6ce8:	54fffce2 	b.cs	6c84 <fwp_caps161+0x4>  // b.hs, b.nlast
    6cec:	8b010063 	add	x3, x3, x1
    6cf0:	39400061 	ldrb	w1, [x3]
    6cf4:	7100043f 	cmp	w1, #0x1
    6cf8:	54fffc61 	b.ne	6c84 <fwp_caps161+0x4>  // b.any
    6cfc:	17fff7c5 	b	4c10 <fwp_mem_free>
    6d00:	72003c3f 	tst	w1, #0xffff
    6d04:	54ffff60 	b.eq	6cf0 <fwp_caps161+0x70>  // b.none
    6d08:	d65f03c0 	ret
    6d0c:	d503201f 	nop

0000000000006d10 <fwp_drop2>:
    6d10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6d14:	910003fd 	mov	x29, sp
    6d18:	a9025bf5 	stp	x21, x22, [sp, #32]
    6d1c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    6d20:	911902d5 	add	x21, x22, #0x640
    6d24:	a90153f3 	stp	x19, x20, [sp, #16]
    6d28:	aa0003f3 	mov	x19, x0
    6d2c:	f949daa1 	ldr	x1, [x21, #5040]
    6d30:	f949eea0 	ldr	x0, [x21, #5080]
    6d34:	cb010261 	sub	x1, x19, x1
    6d38:	eb00403f 	cmp	x1, x0, lsl #16
    6d3c:	54000382 	b.cs	6dac <fwp_drop2+0x9c>  // b.hs, b.nlast
    6d40:	d350fc22 	lsr	x2, x1, #16
    6d44:	f949fea3 	ldr	x3, [x21, #5112]
    6d48:	8b020842 	add	x2, x2, x2, lsl #2
    6d4c:	d37df042 	lsl	x2, x2, #3
    6d50:	8b020060 	add	x0, x3, x2
    6d54:	f9401014 	ldr	x20, [x0, #32]
    6d58:	b40002b4 	cbz	x20, 6dac <fwp_drop2+0x9c>
    6d5c:	38626862 	ldrb	w2, [x3, x2]
    6d60:	7100085f 	cmp	w2, #0x2
    6d64:	540002c0 	b.eq	6dbc <fwp_drop2+0xac>  // b.none
    6d68:	7100045f 	cmp	w2, #0x1
    6d6c:	54000201 	b.ne	6dac <fwp_drop2+0x9c>  // b.any
    6d70:	29430002 	ldp	w2, w0, [x0, #24]
    6d74:	92403c21 	and	x1, x1, #0xffff
    6d78:	9b027c21 	mul	x1, x1, x2
    6d7c:	d360fc21 	lsr	x1, x1, #32
    6d80:	eb00003f 	cmp	x1, x0
    6d84:	54000142 	b.cs	6dac <fwp_drop2+0x9c>  // b.hs, b.nlast
    6d88:	8b010294 	add	x20, x20, x1
    6d8c:	39400280 	ldrb	w0, [x20]
    6d90:	340000e0 	cbz	w0, 6dac <fwp_drop2+0x9c>
    6d94:	7100041f 	cmp	w0, #0x1
    6d98:	540001e0 	b.eq	6dd4 <fwp_drop2+0xc4>  // b.none
    6d9c:	7103fc1f 	cmp	w0, #0xff
    6da0:	540007c0 	b.eq	6e98 <fwp_drop2+0x188>  // b.none
    6da4:	51000400 	sub	w0, w0, #0x1
    6da8:	39000280 	strb	w0, [x20]
    6dac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6db0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6db4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6db8:	d65f03c0 	ret
    6dbc:	72003c3f 	tst	w1, #0xffff
    6dc0:	54fffe60 	b.eq	6d8c <fwp_drop2+0x7c>  // b.none
    6dc4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6dc8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6dcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6dd0:	d65f03c0 	ret
    6dd4:	911902c2 	add	x2, x22, #0x640
    6dd8:	f9400660 	ldr	x0, [x19, #8]
    6ddc:	f949d841 	ldr	x1, [x2, #5040]
    6de0:	f949ec42 	ldr	x2, [x2, #5080]
    6de4:	cb010001 	sub	x1, x0, x1
    6de8:	eb02403f 	cmp	x1, x2, lsl #16
    6dec:	54000362 	b.cs	6e58 <fwp_drop2+0x148>  // b.hs, b.nlast
    6df0:	d350fc22 	lsr	x2, x1, #16
    6df4:	8b020842 	add	x2, x2, x2, lsl #2
    6df8:	d37df042 	lsl	x2, x2, #3
    6dfc:	8b020064 	add	x4, x3, x2
    6e00:	f9401094 	ldr	x20, [x4, #32]
    6e04:	b40002b4 	cbz	x20, 6e58 <fwp_drop2+0x148>
    6e08:	38626862 	ldrb	w2, [x3, x2]
    6e0c:	7100085f 	cmp	w2, #0x2
    6e10:	540003e0 	b.eq	6e8c <fwp_drop2+0x17c>  // b.none
    6e14:	7100045f 	cmp	w2, #0x1
    6e18:	54000201 	b.ne	6e58 <fwp_drop2+0x148>  // b.any
    6e1c:	29430883 	ldp	w3, w2, [x4, #24]
    6e20:	92403c21 	and	x1, x1, #0xffff
    6e24:	9b037c21 	mul	x1, x1, x3
    6e28:	d360fc21 	lsr	x1, x1, #32
    6e2c:	eb02003f 	cmp	x1, x2
    6e30:	54000142 	b.cs	6e58 <fwp_drop2+0x148>  // b.hs, b.nlast
    6e34:	8b010294 	add	x20, x20, x1
    6e38:	39400281 	ldrb	w1, [x20]
    6e3c:	340000e1 	cbz	w1, 6e58 <fwp_drop2+0x148>
    6e40:	7100043f 	cmp	w1, #0x1
    6e44:	54000200 	b.eq	6e84 <fwp_drop2+0x174>  // b.none
    6e48:	7103fc3f 	cmp	w1, #0xff
    6e4c:	54000580 	b.eq	6efc <fwp_drop2+0x1ec>  // b.none
    6e50:	51000421 	sub	w1, w1, #0x1
    6e54:	39000281 	strb	w1, [x20]
    6e58:	f9400a74 	ldr	x20, [x19, #16]
    6e5c:	aa1303e0 	mov	x0, x19
    6e60:	97fffb48 	bl	5b80 <fwp_rc_free_arr>
    6e64:	911902c0 	add	x0, x22, #0x640
    6e68:	f949d801 	ldr	x1, [x0, #5040]
    6e6c:	f949ec00 	ldr	x0, [x0, #5080]
    6e70:	cb010281 	sub	x1, x20, x1
    6e74:	eb00403f 	cmp	x1, x0, lsl #16
    6e78:	54fff9a2 	b.cs	6dac <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e7c:	aa1403f3 	mov	x19, x20
    6e80:	17ffffb0 	b	6d40 <fwp_drop2+0x30>
    6e84:	97fffb3f 	bl	5b80 <fwp_rc_free_arr>
    6e88:	17fffff4 	b	6e58 <fwp_drop2+0x148>
    6e8c:	72003c3f 	tst	w1, #0xffff
    6e90:	54fffe41 	b.ne	6e58 <fwp_drop2+0x148>  // b.any
    6e94:	17ffffe9 	b	6e38 <fwp_drop2+0x128>
    6e98:	ca544681 	eor	x1, x20, x20, lsr #17
    6e9c:	911902c0 	add	x0, x22, #0x640
    6ea0:	ca412421 	eor	x1, x1, x1, lsr #9
    6ea4:	8b210c01 	add	x1, x0, w1, uxtb #3
    6ea8:	f94a2420 	ldr	x0, [x1, #5192]
    6eac:	b5000080 	cbnz	x0, 6ebc <fwp_drop2+0x1ac>
    6eb0:	14000010 	b	6ef0 <fwp_drop2+0x1e0>
    6eb4:	f9400800 	ldr	x0, [x0, #16]
    6eb8:	b40001c0 	cbz	x0, 6ef0 <fwp_drop2+0x1e0>
    6ebc:	f9400001 	ldr	x1, [x0]
    6ec0:	eb14003f 	cmp	x1, x20
    6ec4:	54ffff81 	b.ne	6eb4 <fwp_drop2+0x1a4>  // b.any
    6ec8:	f9400401 	ldr	x1, [x0, #8]
    6ecc:	d1000421 	sub	x1, x1, #0x1
    6ed0:	f9000401 	str	x1, [x0, #8]
    6ed4:	f103f83f 	cmp	x1, #0xfe
    6ed8:	54fff6a1 	b.ne	6dac <fwp_drop2+0x9c>  // b.any
    6edc:	aa1403e0 	mov	x0, x20
    6ee0:	97fff6ac 	bl	4990 <fwp_rc_forget_slot>
    6ee4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ee8:	39000280 	strb	w0, [x20]
    6eec:	17ffffb0 	b	6dac <fwp_drop2+0x9c>
    6ef0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    6ef4:	91368000 	add	x0, x0, #0xda0
    6ef8:	97fff222 	bl	3780 <fwp_trap>
    6efc:	ca544680 	eor	x0, x20, x20, lsr #17
    6f00:	911902c1 	add	x1, x22, #0x640
    6f04:	ca402400 	eor	x0, x0, x0, lsr #9
    6f08:	8b200c20 	add	x0, x1, w0, uxtb #3
    6f0c:	f94a2400 	ldr	x0, [x0, #5192]
    6f10:	b5000080 	cbnz	x0, 6f20 <fwp_drop2+0x210>
    6f14:	17fffff7 	b	6ef0 <fwp_drop2+0x1e0>
    6f18:	f9400800 	ldr	x0, [x0, #16]
    6f1c:	b4fffea0 	cbz	x0, 6ef0 <fwp_drop2+0x1e0>
    6f20:	f9400001 	ldr	x1, [x0]
    6f24:	eb14003f 	cmp	x1, x20
    6f28:	54ffff81 	b.ne	6f18 <fwp_drop2+0x208>  // b.any
    6f2c:	f9400401 	ldr	x1, [x0, #8]
    6f30:	d1000421 	sub	x1, x1, #0x1
    6f34:	f9000401 	str	x1, [x0, #8]
    6f38:	f103f83f 	cmp	x1, #0xfe
    6f3c:	54fff8e1 	b.ne	6e58 <fwp_drop2+0x148>  // b.any
    6f40:	aa1403e0 	mov	x0, x20
    6f44:	97fff693 	bl	4990 <fwp_rc_forget_slot>
    6f48:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f4c:	39000280 	strb	w0, [x20]
    6f50:	17ffffc2 	b	6e58 <fwp_drop2+0x148>

0000000000006f54 <fwp_arg_drop23>:
    6f54:	7100003f 	cmp	w1, #0x0
    6f58:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f5c:	54000041 	b.ne	6f64 <fwp_arg_drop23+0x10>  // b.any
    6f60:	d65f03c0 	ret
    6f64:	f9400000 	ldr	x0, [x0]
    6f68:	17ffff6a 	b	6d10 <fwp_drop2>
    6f6c:	d503201f 	nop

0000000000006f70 <fwp_args23>:
    6f70:	7100003f 	cmp	w1, #0x0
    6f74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f78:	54000041 	b.ne	6f80 <fwp_args23+0x10>  // b.any
    6f7c:	d65f03c0 	ret
    6f80:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6f84:	91190042 	add	x2, x2, #0x640
    6f88:	f9400001 	ldr	x1, [x0]
    6f8c:	f949d843 	ldr	x3, [x2, #5040]
    6f90:	f949ec40 	ldr	x0, [x2, #5080]
    6f94:	cb030021 	sub	x1, x1, x3
    6f98:	eb00403f 	cmp	x1, x0, lsl #16
    6f9c:	54ffff02 	b.cs	6f7c <fwp_args23+0xc>  // b.hs, b.nlast
    6fa0:	d350fc20 	lsr	x0, x1, #16
    6fa4:	f949fc44 	ldr	x4, [x2, #5112]
    6fa8:	8b000800 	add	x0, x0, x0, lsl #2
    6fac:	d37df002 	lsl	x2, x0, #3
    6fb0:	8b020083 	add	x3, x4, x2
    6fb4:	f9401060 	ldr	x0, [x3, #32]
    6fb8:	b4fffe20 	cbz	x0, 6f7c <fwp_args23+0xc>
    6fbc:	38626882 	ldrb	w2, [x4, x2]
    6fc0:	7100085f 	cmp	w2, #0x2
    6fc4:	54000320 	b.eq	7028 <fwp_args23+0xb8>  // b.none
    6fc8:	7100045f 	cmp	w2, #0x1
    6fcc:	54fffd81 	b.ne	6f7c <fwp_args23+0xc>  // b.any
    6fd0:	29430864 	ldp	w4, w2, [x3, #24]
    6fd4:	92403c21 	and	x1, x1, #0xffff
    6fd8:	9b047c21 	mul	x1, x1, x4
    6fdc:	d360fc21 	lsr	x1, x1, #32
    6fe0:	eb02003f 	cmp	x1, x2
    6fe4:	54fffcc2 	b.cs	6f7c <fwp_args23+0xc>  // b.hs, b.nlast
    6fe8:	8b010000 	add	x0, x0, x1
    6fec:	39400001 	ldrb	w1, [x0]
    6ff0:	34fffc61 	cbz	w1, 6f7c <fwp_args23+0xc>
    6ff4:	d00000c2 	adrp	x2, 20000 <__data_start>
    6ff8:	91018042 	add	x2, x2, #0x60
    6ffc:	b9413043 	ldr	w3, [x2, #304]
    7000:	350000c3 	cbnz	w3, 7018 <fwp_args23+0xa8>
    7004:	7103f43f 	cmp	w1, #0xfd
    7008:	54000168 	b.hi	7034 <fwp_args23+0xc4>  // b.pmore
    700c:	11000421 	add	w1, w1, #0x1
    7010:	39000001 	strb	w1, [x0]
    7014:	d65f03c0 	ret
    7018:	f940ac43 	ldr	x3, [x2, #344]
    701c:	91000463 	add	x3, x3, #0x1
    7020:	f900ac43 	str	x3, [x2, #344]
    7024:	17fffff8 	b	7004 <fwp_args23+0x94>
    7028:	72003c3f 	tst	w1, #0xffff
    702c:	54fffe00 	b.eq	6fec <fwp_args23+0x7c>  // b.none
    7030:	d65f03c0 	ret
    7034:	17fff610 	b	4874 <fwp_rc_wide_dup>
    7038:	d503201f 	nop
    703c:	d503201f 	nop

0000000000007040 <fwp_args12>:
    7040:	7100003f 	cmp	w1, #0x0
    7044:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7048:	54000041 	b.ne	7050 <fwp_args12+0x10>  // b.any
    704c:	d65f03c0 	ret
    7050:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7054:	91190042 	add	x2, x2, #0x640
    7058:	f9400001 	ldr	x1, [x0]
    705c:	f949d843 	ldr	x3, [x2, #5040]
    7060:	f949ec40 	ldr	x0, [x2, #5080]
    7064:	cb030021 	sub	x1, x1, x3
    7068:	eb00403f 	cmp	x1, x0, lsl #16
    706c:	54ffff02 	b.cs	704c <fwp_args12+0xc>  // b.hs, b.nlast
    7070:	d350fc20 	lsr	x0, x1, #16
    7074:	f949fc44 	ldr	x4, [x2, #5112]
    7078:	8b000800 	add	x0, x0, x0, lsl #2
    707c:	d37df002 	lsl	x2, x0, #3
    7080:	8b020083 	add	x3, x4, x2
    7084:	f9401060 	ldr	x0, [x3, #32]
    7088:	b4fffe20 	cbz	x0, 704c <fwp_args12+0xc>
    708c:	38626882 	ldrb	w2, [x4, x2]
    7090:	7100085f 	cmp	w2, #0x2
    7094:	54000320 	b.eq	70f8 <fwp_args12+0xb8>  // b.none
    7098:	7100045f 	cmp	w2, #0x1
    709c:	54fffd81 	b.ne	704c <fwp_args12+0xc>  // b.any
    70a0:	29430864 	ldp	w4, w2, [x3, #24]
    70a4:	92403c21 	and	x1, x1, #0xffff
    70a8:	9b047c21 	mul	x1, x1, x4
    70ac:	d360fc21 	lsr	x1, x1, #32
    70b0:	eb02003f 	cmp	x1, x2
    70b4:	54fffcc2 	b.cs	704c <fwp_args12+0xc>  // b.hs, b.nlast
    70b8:	8b010000 	add	x0, x0, x1
    70bc:	39400001 	ldrb	w1, [x0]
    70c0:	34fffc61 	cbz	w1, 704c <fwp_args12+0xc>
    70c4:	b00000c2 	adrp	x2, 20000 <__data_start>
    70c8:	91018042 	add	x2, x2, #0x60
    70cc:	b9413043 	ldr	w3, [x2, #304]
    70d0:	350000c3 	cbnz	w3, 70e8 <fwp_args12+0xa8>
    70d4:	7103f43f 	cmp	w1, #0xfd
    70d8:	54000168 	b.hi	7104 <fwp_args12+0xc4>  // b.pmore
    70dc:	11000421 	add	w1, w1, #0x1
    70e0:	39000001 	strb	w1, [x0]
    70e4:	d65f03c0 	ret
    70e8:	f940ac43 	ldr	x3, [x2, #344]
    70ec:	91000463 	add	x3, x3, #0x1
    70f0:	f900ac43 	str	x3, [x2, #344]
    70f4:	17fffff8 	b	70d4 <fwp_args12+0x94>
    70f8:	72003c3f 	tst	w1, #0xffff
    70fc:	54fffe00 	b.eq	70bc <fwp_args12+0x7c>  // b.none
    7100:	d65f03c0 	ret
    7104:	17fff5dc 	b	4874 <fwp_rc_wide_dup>
    7108:	d503201f 	nop
    710c:	d503201f 	nop

0000000000007110 <fwp_caps23>:
    7110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7114:	910003fd 	mov	x29, sp
    7118:	f9000bf3 	str	x19, [sp, #16]
    711c:	aa0003f3 	mov	x19, x0
    7120:	b9400400 	ldr	w0, [x0, #4]
    7124:	340004a0 	cbz	w0, 71b8 <fwp_caps23+0xa8>
    7128:	f9400660 	ldr	x0, [x19, #8]
    712c:	350004e1 	cbnz	w1, 71c8 <fwp_caps23+0xb8>
    7130:	97fffef8 	bl	6d10 <fwp_drop2>
    7134:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7138:	91190042 	add	x2, x2, #0x640
    713c:	f949d840 	ldr	x0, [x2, #5040]
    7140:	f949ec41 	ldr	x1, [x2, #5080]
    7144:	cb000260 	sub	x0, x19, x0
    7148:	eb01401f 	cmp	x0, x1, lsl #16
    714c:	54000382 	b.cs	71bc <fwp_caps23+0xac>  // b.hs, b.nlast
    7150:	d350fc01 	lsr	x1, x0, #16
    7154:	f949fc44 	ldr	x4, [x2, #5112]
    7158:	8b010821 	add	x1, x1, x1, lsl #2
    715c:	d37df021 	lsl	x1, x1, #3
    7160:	8b010083 	add	x3, x4, x1
    7164:	f9401062 	ldr	x2, [x3, #32]
    7168:	b40002a2 	cbz	x2, 71bc <fwp_caps23+0xac>
    716c:	38616881 	ldrb	w1, [x4, x1]
    7170:	7100083f 	cmp	w1, #0x2
    7174:	54000740 	b.eq	725c <fwp_caps23+0x14c>  // b.none
    7178:	7100043f 	cmp	w1, #0x1
    717c:	54000201 	b.ne	71bc <fwp_caps23+0xac>  // b.any
    7180:	29430464 	ldp	w4, w1, [x3, #24]
    7184:	92403c00 	and	x0, x0, #0xffff
    7188:	9b047c00 	mul	x0, x0, x4
    718c:	d360fc00 	lsr	x0, x0, #32
    7190:	eb01001f 	cmp	x0, x1
    7194:	54000142 	b.cs	71bc <fwp_caps23+0xac>  // b.hs, b.nlast
    7198:	8b000042 	add	x2, x2, x0
    719c:	39400040 	ldrb	w0, [x2]
    71a0:	7100041f 	cmp	w0, #0x1
    71a4:	540000c1 	b.ne	71bc <fwp_caps23+0xac>  // b.any
    71a8:	aa1303e0 	mov	x0, x19
    71ac:	f9400bf3 	ldr	x19, [sp, #16]
    71b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71b4:	17fff697 	b	4c10 <fwp_mem_free>
    71b8:	34fffbe1 	cbz	w1, 7134 <fwp_caps23+0x24>
    71bc:	f9400bf3 	ldr	x19, [sp, #16]
    71c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71c4:	d65f03c0 	ret
    71c8:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    71cc:	91190042 	add	x2, x2, #0x640
    71d0:	f949d843 	ldr	x3, [x2, #5040]
    71d4:	f949ec41 	ldr	x1, [x2, #5080]
    71d8:	cb030000 	sub	x0, x0, x3
    71dc:	eb01401f 	cmp	x0, x1, lsl #16
    71e0:	54fffee2 	b.cs	71bc <fwp_caps23+0xac>  // b.hs, b.nlast
    71e4:	d350fc01 	lsr	x1, x0, #16
    71e8:	f949fc44 	ldr	x4, [x2, #5112]
    71ec:	8b010821 	add	x1, x1, x1, lsl #2
    71f0:	d37df021 	lsl	x1, x1, #3
    71f4:	8b010083 	add	x3, x4, x1
    71f8:	f9401062 	ldr	x2, [x3, #32]
    71fc:	b4fffe02 	cbz	x2, 71bc <fwp_caps23+0xac>
    7200:	38616881 	ldrb	w1, [x4, x1]
    7204:	7100083f 	cmp	w1, #0x2
    7208:	54000300 	b.eq	7268 <fwp_caps23+0x158>  // b.none
    720c:	7100043f 	cmp	w1, #0x1
    7210:	54fffd61 	b.ne	71bc <fwp_caps23+0xac>  // b.any
    7214:	92403c01 	and	x1, x0, #0xffff
    7218:	29430064 	ldp	w4, w0, [x3, #24]
    721c:	9b047c21 	mul	x1, x1, x4
    7220:	d360fc21 	lsr	x1, x1, #32
    7224:	eb00003f 	cmp	x1, x0
    7228:	54fffca2 	b.cs	71bc <fwp_caps23+0xac>  // b.hs, b.nlast
    722c:	8b010042 	add	x2, x2, x1
    7230:	39400040 	ldrb	w0, [x2]
    7234:	34fffc40 	cbz	w0, 71bc <fwp_caps23+0xac>
    7238:	b00000c1 	adrp	x1, 20000 <__data_start>
    723c:	91018021 	add	x1, x1, #0x60
    7240:	b9413023 	ldr	w3, [x1, #304]
    7244:	35000183 	cbnz	w3, 7274 <fwp_caps23+0x164>
    7248:	7103f41f 	cmp	w0, #0xfd
    724c:	540001c8 	b.hi	7284 <fwp_caps23+0x174>  // b.pmore
    7250:	11000400 	add	w0, w0, #0x1
    7254:	39000040 	strb	w0, [x2]
    7258:	17ffffd9 	b	71bc <fwp_caps23+0xac>
    725c:	72003c1f 	tst	w0, #0xffff
    7260:	54fffae1 	b.ne	71bc <fwp_caps23+0xac>  // b.any
    7264:	17ffffce 	b	719c <fwp_caps23+0x8c>
    7268:	72003c1f 	tst	w0, #0xffff
    726c:	54fffa81 	b.ne	71bc <fwp_caps23+0xac>  // b.any
    7270:	17fffff0 	b	7230 <fwp_caps23+0x120>
    7274:	f940ac23 	ldr	x3, [x1, #344]
    7278:	91000463 	add	x3, x3, #0x1
    727c:	f900ac23 	str	x3, [x1, #344]
    7280:	17fffff2 	b	7248 <fwp_caps23+0x138>
    7284:	f9400bf3 	ldr	x19, [sp, #16]
    7288:	aa0203e0 	mov	x0, x2
    728c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7290:	17fff579 	b	4874 <fwp_rc_wide_dup>

0000000000007294 <fwp_caps12>:
    7294:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7298:	910003fd 	mov	x29, sp
    729c:	f9000bf3 	str	x19, [sp, #16]
    72a0:	aa0003f3 	mov	x19, x0
    72a4:	b9400400 	ldr	w0, [x0, #4]
    72a8:	340004a0 	cbz	w0, 733c <fwp_caps12+0xa8>
    72ac:	f9400660 	ldr	x0, [x19, #8]
    72b0:	350004e1 	cbnz	w1, 734c <fwp_caps12+0xb8>
    72b4:	97fffb63 	bl	6040 <fwp_drop0>
    72b8:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    72bc:	91190042 	add	x2, x2, #0x640
    72c0:	f949d840 	ldr	x0, [x2, #5040]
    72c4:	f949ec41 	ldr	x1, [x2, #5080]
    72c8:	cb000260 	sub	x0, x19, x0
    72cc:	eb01401f 	cmp	x0, x1, lsl #16
    72d0:	54000382 	b.cs	7340 <fwp_caps12+0xac>  // b.hs, b.nlast
    72d4:	d350fc01 	lsr	x1, x0, #16
    72d8:	f949fc44 	ldr	x4, [x2, #5112]
    72dc:	8b010821 	add	x1, x1, x1, lsl #2
    72e0:	d37df021 	lsl	x1, x1, #3
    72e4:	8b010083 	add	x3, x4, x1
    72e8:	f9401062 	ldr	x2, [x3, #32]
    72ec:	b40002a2 	cbz	x2, 7340 <fwp_caps12+0xac>
    72f0:	38616881 	ldrb	w1, [x4, x1]
    72f4:	7100083f 	cmp	w1, #0x2
    72f8:	54000740 	b.eq	73e0 <fwp_caps12+0x14c>  // b.none
    72fc:	7100043f 	cmp	w1, #0x1
    7300:	54000201 	b.ne	7340 <fwp_caps12+0xac>  // b.any
    7304:	29430464 	ldp	w4, w1, [x3, #24]
    7308:	92403c00 	and	x0, x0, #0xffff
    730c:	9b047c00 	mul	x0, x0, x4
    7310:	d360fc00 	lsr	x0, x0, #32
    7314:	eb01001f 	cmp	x0, x1
    7318:	54000142 	b.cs	7340 <fwp_caps12+0xac>  // b.hs, b.nlast
    731c:	8b000042 	add	x2, x2, x0
    7320:	39400040 	ldrb	w0, [x2]
    7324:	7100041f 	cmp	w0, #0x1
    7328:	540000c1 	b.ne	7340 <fwp_caps12+0xac>  // b.any
    732c:	aa1303e0 	mov	x0, x19
    7330:	f9400bf3 	ldr	x19, [sp, #16]
    7334:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7338:	17fff636 	b	4c10 <fwp_mem_free>
    733c:	34fffbe1 	cbz	w1, 72b8 <fwp_caps12+0x24>
    7340:	f9400bf3 	ldr	x19, [sp, #16]
    7344:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7348:	d65f03c0 	ret
    734c:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7350:	91190042 	add	x2, x2, #0x640
    7354:	f949d843 	ldr	x3, [x2, #5040]
    7358:	f949ec41 	ldr	x1, [x2, #5080]
    735c:	cb030000 	sub	x0, x0, x3
    7360:	eb01401f 	cmp	x0, x1, lsl #16
    7364:	54fffee2 	b.cs	7340 <fwp_caps12+0xac>  // b.hs, b.nlast
    7368:	d350fc01 	lsr	x1, x0, #16
    736c:	f949fc44 	ldr	x4, [x2, #5112]
    7370:	8b010821 	add	x1, x1, x1, lsl #2
    7374:	d37df021 	lsl	x1, x1, #3
    7378:	8b010083 	add	x3, x4, x1
    737c:	f9401062 	ldr	x2, [x3, #32]
    7380:	b4fffe02 	cbz	x2, 7340 <fwp_caps12+0xac>
    7384:	38616881 	ldrb	w1, [x4, x1]
    7388:	7100083f 	cmp	w1, #0x2
    738c:	54000300 	b.eq	73ec <fwp_caps12+0x158>  // b.none
    7390:	7100043f 	cmp	w1, #0x1
    7394:	54fffd61 	b.ne	7340 <fwp_caps12+0xac>  // b.any
    7398:	92403c01 	and	x1, x0, #0xffff
    739c:	29430064 	ldp	w4, w0, [x3, #24]
    73a0:	9b047c21 	mul	x1, x1, x4
    73a4:	d360fc21 	lsr	x1, x1, #32
    73a8:	eb00003f 	cmp	x1, x0
    73ac:	54fffca2 	b.cs	7340 <fwp_caps12+0xac>  // b.hs, b.nlast
    73b0:	8b010042 	add	x2, x2, x1
    73b4:	39400040 	ldrb	w0, [x2]
    73b8:	34fffc40 	cbz	w0, 7340 <fwp_caps12+0xac>
    73bc:	b00000c1 	adrp	x1, 20000 <__data_start>
    73c0:	91018021 	add	x1, x1, #0x60
    73c4:	b9413023 	ldr	w3, [x1, #304]
    73c8:	35000183 	cbnz	w3, 73f8 <fwp_caps12+0x164>
    73cc:	7103f41f 	cmp	w0, #0xfd
    73d0:	540001c8 	b.hi	7408 <fwp_caps12+0x174>  // b.pmore
    73d4:	11000400 	add	w0, w0, #0x1
    73d8:	39000040 	strb	w0, [x2]
    73dc:	17ffffd9 	b	7340 <fwp_caps12+0xac>
    73e0:	72003c1f 	tst	w0, #0xffff
    73e4:	54fffae1 	b.ne	7340 <fwp_caps12+0xac>  // b.any
    73e8:	17ffffce 	b	7320 <fwp_caps12+0x8c>
    73ec:	72003c1f 	tst	w0, #0xffff
    73f0:	54fffa81 	b.ne	7340 <fwp_caps12+0xac>  // b.any
    73f4:	17fffff0 	b	73b4 <fwp_caps12+0x120>
    73f8:	f940ac23 	ldr	x3, [x1, #344]
    73fc:	91000463 	add	x3, x3, #0x1
    7400:	f900ac23 	str	x3, [x1, #344]
    7404:	17fffff2 	b	73cc <fwp_caps12+0x138>
    7408:	f9400bf3 	ldr	x19, [sp, #16]
    740c:	aa0203e0 	mov	x0, x2
    7410:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7414:	17fff518 	b	4874 <fwp_rc_wide_dup>
    7418:	d503201f 	nop
    741c:	d503201f 	nop

0000000000007420 <f23>:
    7420:	d101c3ff 	sub	sp, sp, #0x70
    7424:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    7428:	f947f421 	ldr	x1, [x1, #4072]
    742c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7430:	910083fd 	add	x29, sp, #0x20
    7434:	a90563f7 	stp	x23, x24, [sp, #80]
    7438:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    743c:	911902e3 	add	x3, x23, #0x640
    7440:	a90353f3 	stp	x19, x20, [sp, #48]
    7444:	a9045bf5 	stp	x21, x22, [sp, #64]
    7448:	aa0003f6 	mov	x22, x0
    744c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7450:	f949ec62 	ldr	x2, [x3, #5080]
    7454:	f9400024 	ldr	x4, [x1]
    7458:	f9000fe4 	str	x4, [sp, #24]
    745c:	d2800004 	mov	x4, #0x0                   	// #0
    7460:	f949d861 	ldr	x1, [x3, #5040]
    7464:	d370bc42 	lsl	x2, x2, #16
    7468:	b40016c0 	cbz	x0, 7740 <f23+0x320>
    746c:	f9400818 	ldr	x24, [x0, #16]
    7470:	cb010301 	sub	x1, x24, x1
    7474:	eb02003f 	cmp	x1, x2
    7478:	540003e2 	b.cs	74f4 <f23+0xd4>  // b.hs, b.nlast
    747c:	f949fc60 	ldr	x0, [x3, #5112]
    7480:	d350fc22 	lsr	x2, x1, #16
    7484:	8b020842 	add	x2, x2, x2, lsl #2
    7488:	8b020c02 	add	x2, x0, x2, lsl #3
    748c:	f9401040 	ldr	x0, [x2, #32]
    7490:	b4000320 	cbz	x0, 74f4 <f23+0xd4>
    7494:	39400043 	ldrb	w3, [x2]
    7498:	7100087f 	cmp	w3, #0x2
    749c:	54001440 	b.eq	7724 <f23+0x304>  // b.none
    74a0:	7100047f 	cmp	w3, #0x1
    74a4:	54000241 	b.ne	74ec <f23+0xcc>  // b.any
    74a8:	29430843 	ldp	w3, w2, [x2, #24]
    74ac:	92403c21 	and	x1, x1, #0xffff
    74b0:	9b037c21 	mul	x1, x1, x3
    74b4:	d360fc21 	lsr	x1, x1, #32
    74b8:	eb02003f 	cmp	x1, x2
    74bc:	54000182 	b.cs	74ec <f23+0xcc>  // b.hs, b.nlast
    74c0:	8b010000 	add	x0, x0, x1
    74c4:	39400001 	ldrb	w1, [x0]
    74c8:	34000121 	cbz	w1, 74ec <f23+0xcc>
    74cc:	b00000c2 	adrp	x2, 20000 <__data_start>
    74d0:	91018042 	add	x2, x2, #0x60
    74d4:	b9413043 	ldr	w3, [x2, #304]
    74d8:	350012c3 	cbnz	w3, 7730 <f23+0x310>
    74dc:	7103f43f 	cmp	w1, #0xfd
    74e0:	54001728 	b.hi	77c4 <f23+0x3a4>  // b.pmore
    74e4:	11000421 	add	w1, w1, #0x1
    74e8:	39000001 	strb	w1, [x0]
    74ec:	d2800000 	mov	x0, #0x0                   	// #0
    74f0:	b40000f6 	cbz	x22, 750c <f23+0xec>
    74f4:	aa1603e1 	mov	x1, x22
    74f8:	d2800000 	mov	x0, #0x0                   	// #0
    74fc:	d503201f 	nop
    7500:	f9400821 	ldr	x1, [x1, #16]
    7504:	91000400 	add	x0, x0, #0x1
    7508:	b5ffffc1 	cbnz	x1, 7500 <f23+0xe0>
    750c:	b4001238 	cbz	x24, 7750 <f23+0x330>
    7510:	aa1803e1 	mov	x1, x24
    7514:	d2800002 	mov	x2, #0x0                   	// #0
    7518:	f9400821 	ldr	x1, [x1, #16]
    751c:	91000442 	add	x2, x2, #0x1
    7520:	b5ffffc1 	cbnz	x1, 7518 <f23+0xf8>
    7524:	eb00005f 	cmp	x2, x0
    7528:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    752c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7530:	eb01033f 	cmp	x25, x1
    7534:	540014e8 	b.hi	77d0 <f23+0x3b0>  // b.pmore
    7538:	d37ffb33 	lsl	x19, x25, #1
    753c:	52800041 	mov	w1, #0x2                   	// #2
    7540:	91000660 	add	x0, x19, #0x1
    7544:	d37df000 	lsl	x0, x0, #3
    7548:	97fff6d2 	bl	5090 <fwp_heap_alloc>
    754c:	911902e1 	add	x1, x23, #0x640
    7550:	aa0003fa 	mov	x26, x0
    7554:	f9000013 	str	x19, [x0]
    7558:	aa0103e0 	mov	x0, x1
    755c:	f949d821 	ldr	x1, [x1, #5040]
    7560:	f949ec00 	ldr	x0, [x0, #5080]
    7564:	cb010341 	sub	x1, x26, x1
    7568:	eb00403f 	cmp	x1, x0, lsl #16
    756c:	54000342 	b.cs	75d4 <f23+0x1b4>  // b.hs, b.nlast
    7570:	911902e2 	add	x2, x23, #0x640
    7574:	d350fc20 	lsr	x0, x1, #16
    7578:	8b000800 	add	x0, x0, x0, lsl #2
    757c:	f949fc43 	ldr	x3, [x2, #5112]
    7580:	d37df002 	lsl	x2, x0, #3
    7584:	8b020060 	add	x0, x3, x2
    7588:	f9401013 	ldr	x19, [x0, #32]
    758c:	b4000253 	cbz	x19, 75d4 <f23+0x1b4>
    7590:	38626862 	ldrb	w2, [x3, x2]
    7594:	7100085f 	cmp	w2, #0x2
    7598:	54000c00 	b.eq	7718 <f23+0x2f8>  // b.none
    759c:	7100045f 	cmp	w2, #0x1
    75a0:	540001a1 	b.ne	75d4 <f23+0x1b4>  // b.any
    75a4:	29430002 	ldp	w2, w0, [x0, #24]
    75a8:	92403c21 	and	x1, x1, #0xffff
    75ac:	9b027c21 	mul	x1, x1, x2
    75b0:	d360fc21 	lsr	x1, x1, #32
    75b4:	eb00003f 	cmp	x1, x0
    75b8:	540000e2 	b.cs	75d4 <f23+0x1b4>  // b.hs, b.nlast
    75bc:	8b010273 	add	x19, x19, x1
    75c0:	39400260 	ldrb	w0, [x19]
    75c4:	7103fc1f 	cmp	w0, #0xff
    75c8:	54000e80 	b.eq	7798 <f23+0x378>  // b.none
    75cc:	52800020 	mov	w0, #0x1                   	// #1
    75d0:	39000260 	strb	w0, [x19]
    75d4:	b4000259 	cbz	x25, 761c <f23+0x1fc>
    75d8:	8b191359 	add	x25, x26, x25, lsl #4
    75dc:	aa1a03f3 	mov	x19, x26
    75e0:	aa1603f5 	mov	x21, x22
    75e4:	aa1803f4 	mov	x20, x24
    75e8:	f9400683 	ldr	x3, [x20, #8]
    75ec:	f94006a2 	ldr	x2, [x21, #8]
    75f0:	f9400861 	ldr	x1, [x3, #16]
    75f4:	f9400840 	ldr	x0, [x2, #16]
    75f8:	fd400461 	ldr	d1, [x3, #8]
    75fc:	fd400440 	ldr	d0, [x2, #8]
    7600:	97fff840 	bl	5700 <w107>
    7604:	f9000660 	str	x0, [x19, #8]
    7608:	f8010e61 	str	x1, [x19, #16]!
    760c:	f9400a94 	ldr	x20, [x20, #16]
    7610:	f9400ab5 	ldr	x21, [x21, #16]
    7614:	eb13033f 	cmp	x25, x19
    7618:	54fffe81 	b.ne	75e8 <f23+0x1c8>  // b.any
    761c:	aa1803e0 	mov	x0, x24
    7620:	97fffdbc 	bl	6d10 <fwp_drop2>
    7624:	aa1603e0 	mov	x0, x22
    7628:	97fffdba 	bl	6d10 <fwp_drop2>
    762c:	911902f7 	add	x23, x23, #0x640
    7630:	aa1a03e0 	mov	x0, x26
    7634:	97fff877 	bl	5810 <w164.constprop.0>
    7638:	aa0103f3 	mov	x19, x1
    763c:	aa0003f4 	mov	x20, x0
    7640:	aa1a03e0 	mov	x0, x26
    7644:	97fffd13 	bl	6a90 <fwp_drop4>
    7648:	a900cff4 	stp	x20, x19, [sp, #8]
    764c:	910023e1 	add	x1, sp, #0x8
    7650:	52800000 	mov	w0, #0x0                   	// #0
    7654:	97fff897 	bl	58b0 <fwp_data.part.0.constprop.0>
    7658:	f949dae1 	ldr	x1, [x23, #5040]
    765c:	aa0003f3 	mov	x19, x0
    7660:	f949eee0 	ldr	x0, [x23, #5080]
    7664:	cb010261 	sub	x1, x19, x1
    7668:	eb00403f 	cmp	x1, x0, lsl #16
    766c:	54000322 	b.cs	76d0 <f23+0x2b0>  // b.hs, b.nlast
    7670:	d350fc22 	lsr	x2, x1, #16
    7674:	f949fee3 	ldr	x3, [x23, #5112]
    7678:	8b020842 	add	x2, x2, x2, lsl #2
    767c:	d37df042 	lsl	x2, x2, #3
    7680:	8b020060 	add	x0, x3, x2
    7684:	f9401014 	ldr	x20, [x0, #32]
    7688:	b4000254 	cbz	x20, 76d0 <f23+0x2b0>
    768c:	38626862 	ldrb	w2, [x3, x2]
    7690:	7100085f 	cmp	w2, #0x2
    7694:	540003c0 	b.eq	770c <f23+0x2ec>  // b.none
    7698:	7100045f 	cmp	w2, #0x1
    769c:	540001a1 	b.ne	76d0 <f23+0x2b0>  // b.any
    76a0:	29430002 	ldp	w2, w0, [x0, #24]
    76a4:	92403c21 	and	x1, x1, #0xffff
    76a8:	9b027c21 	mul	x1, x1, x2
    76ac:	d360fc21 	lsr	x1, x1, #32
    76b0:	eb00003f 	cmp	x1, x0
    76b4:	540000e2 	b.cs	76d0 <f23+0x2b0>  // b.hs, b.nlast
    76b8:	8b010294 	add	x20, x20, x1
    76bc:	39400280 	ldrb	w0, [x20]
    76c0:	7103fc1f 	cmp	w0, #0xff
    76c4:	54000640 	b.eq	778c <f23+0x36c>  // b.none
    76c8:	52800020 	mov	w0, #0x1                   	// #1
    76cc:	39000280 	strb	w0, [x20]
    76d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    76d4:	f947f400 	ldr	x0, [x0, #4072]
    76d8:	f9400fe2 	ldr	x2, [sp, #24]
    76dc:	f9400001 	ldr	x1, [x0]
    76e0:	eb010042 	subs	x2, x2, x1
    76e4:	d2800001 	mov	x1, #0x0                   	// #0
    76e8:	54000721 	b.ne	77cc <f23+0x3ac>  // b.any
    76ec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    76f0:	aa1303e0 	mov	x0, x19
    76f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    76f8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    76fc:	a94563f7 	ldp	x23, x24, [sp, #80]
    7700:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7704:	9101c3ff 	add	sp, sp, #0x70
    7708:	d65f03c0 	ret
    770c:	72003c3f 	tst	w1, #0xffff
    7710:	54fffe01 	b.ne	76d0 <f23+0x2b0>  // b.any
    7714:	17ffffea 	b	76bc <f23+0x29c>
    7718:	72003c3f 	tst	w1, #0xffff
    771c:	54fff5c1 	b.ne	75d4 <f23+0x1b4>  // b.any
    7720:	17ffffa8 	b	75c0 <f23+0x1a0>
    7724:	72003c3f 	tst	w1, #0xffff
    7728:	54ffee21 	b.ne	74ec <f23+0xcc>  // b.any
    772c:	17ffff66 	b	74c4 <f23+0xa4>
    7730:	f940ac43 	ldr	x3, [x2, #344]
    7734:	91000463 	add	x3, x3, #0x1
    7738:	f900ac43 	str	x3, [x2, #344]
    773c:	17ffff68 	b	74dc <f23+0xbc>
    7740:	cb0103e1 	neg	x1, x1
    7744:	eb02003f 	cmp	x1, x2
    7748:	540002e3 	b.cc	77a4 <f23+0x384>  // b.lo, b.ul, b.last
    774c:	d503201f 	nop
    7750:	52800041 	mov	w1, #0x2                   	// #2
    7754:	d2800100 	mov	x0, #0x8                   	// #8
    7758:	97fff64e 	bl	5090 <fwp_heap_alloc>
    775c:	aa0003e1 	mov	x1, x0
    7760:	911902e0 	add	x0, x23, #0x640
    7764:	aa0103fa 	mov	x26, x1
    7768:	d2800018 	mov	x24, #0x0                   	// #0
    776c:	f900003f 	str	xzr, [x1]
    7770:	f949d801 	ldr	x1, [x0, #5040]
    7774:	f949ec00 	ldr	x0, [x0, #5080]
    7778:	cb010341 	sub	x1, x26, x1
    777c:	eb00403f 	cmp	x1, x0, lsl #16
    7780:	54fff4e2 	b.cs	761c <f23+0x1fc>  // b.hs, b.nlast
    7784:	d2800019 	mov	x25, #0x0                   	// #0
    7788:	17ffff7a 	b	7570 <f23+0x150>
    778c:	aa1403e0 	mov	x0, x20
    7790:	97fff480 	bl	4990 <fwp_rc_forget_slot>
    7794:	17ffffcd 	b	76c8 <f23+0x2a8>
    7798:	aa1303e0 	mov	x0, x19
    779c:	97fff47d 	bl	4990 <fwp_rc_forget_slot>
    77a0:	17ffff8b 	b	75cc <f23+0x1ac>
    77a4:	f949fc62 	ldr	x2, [x3, #5112]
    77a8:	d350fc20 	lsr	x0, x1, #16
    77ac:	8b000800 	add	x0, x0, x0, lsl #2
    77b0:	8b000c42 	add	x2, x2, x0, lsl #3
    77b4:	f9401040 	ldr	x0, [x2, #32]
    77b8:	b4fffcc0 	cbz	x0, 7750 <f23+0x330>
    77bc:	d2800018 	mov	x24, #0x0                   	// #0
    77c0:	17ffff35 	b	7494 <f23+0x74>
    77c4:	97fff42c 	bl	4874 <fwp_rc_wide_dup>
    77c8:	17ffff49 	b	74ec <f23+0xcc>
    77cc:	97ffec11 	bl	2810 <__stack_chk_fail@plt>
    77d0:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    77d4:	913b8000 	add	x0, x0, #0xee0
    77d8:	97ffefea 	bl	3780 <fwp_trap>
    77dc:	d503201f 	nop

00000000000077e0 <fwp_owned_entry23>:
    77e0:	f9400000 	ldr	x0, [x0]
    77e4:	17ffff0f 	b	7420 <f23>
    77e8:	d503201f 	nop
    77ec:	d503201f 	nop

00000000000077f0 <e23>:
    77f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    77f4:	910003fd 	mov	x29, sp
    77f8:	f9000bf3 	str	x19, [sp, #16]
    77fc:	f9400013 	ldr	x19, [x0]
    7800:	aa1303e0 	mov	x0, x19
    7804:	97fff888 	bl	5a24 <fwp_rc_share>
    7808:	aa1303e0 	mov	x0, x19
    780c:	97ffff05 	bl	7420 <f23>
    7810:	aa0003f3 	mov	x19, x0
    7814:	97fff884 	bl	5a24 <fwp_rc_share>
    7818:	aa1303e0 	mov	x0, x19
    781c:	f9400bf3 	ldr	x19, [sp, #16]
    7820:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7824:	d65f03c0 	ret
    7828:	d503201f 	nop
    782c:	d503201f 	nop

0000000000007830 <f12>:
    7830:	d10483ff 	sub	sp, sp, #0x120
    7834:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    7838:	f947f442 	ldr	x2, [x2, #4072]
    783c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7840:	910303fd 	add	x29, sp, #0xc0
    7844:	a90f63f7 	stp	x23, x24, [sp, #240]
    7848:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    784c:	911902e3 	add	x3, x23, #0x640
    7850:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7854:	b00000d5 	adrp	x21, 20000 <__data_start>
    7858:	910182a4 	add	x4, x21, #0x60
    785c:	f949d861 	ldr	x1, [x3, #5040]
    7860:	a90d53f3 	stp	x19, x20, [sp, #208]
    7864:	910103f8 	add	x24, sp, #0x40
    7868:	f949ec65 	ldr	x5, [x3, #5080]
    786c:	a9106bf9 	stp	x25, x26, [sp, #256]
    7870:	b00000d9 	adrp	x25, 20000 <__data_start>
    7874:	a91173fb 	stp	x27, x28, [sp, #272]
    7878:	91004339 	add	x25, x25, #0x10
    787c:	91008339 	add	x25, x25, #0x20
    7880:	f941c886 	ldr	x6, [x4, #912]
    7884:	f9400047 	ldr	x7, [x2]
    7888:	f9005fe7 	str	x7, [sp, #184]
    788c:	d2800007 	mov	x7, #0x0                   	// #0
    7890:	9100e3f6 	add	x22, sp, #0x38
    7894:	f0fffff3 	adrp	x19, 6000 <fwp_drop1+0x110>
    7898:	12800007 	mov	w7, #0xffffffff            	// #-1
    789c:	91150262 	add	x2, x19, #0x540
    78a0:	cb010321 	sub	x1, x25, x1
    78a4:	b9003be7 	str	w7, [sp, #56]
    78a8:	a9040be6 	stp	x6, x2, [sp, #64]
    78ac:	aa0003f4 	mov	x20, x0
    78b0:	f9002bf6 	str	x22, [sp, #80]
    78b4:	f901c898 	str	x24, [x4, #912]
    78b8:	eb05403f 	cmp	x1, x5, lsl #16
    78bc:	540003a2 	b.cs	7930 <f12+0x100>  // b.hs, b.nlast
    78c0:	d350fc20 	lsr	x0, x1, #16
    78c4:	f949fc64 	ldr	x4, [x3, #5112]
    78c8:	8b000800 	add	x0, x0, x0, lsl #2
    78cc:	d37df002 	lsl	x2, x0, #3
    78d0:	8b020083 	add	x3, x4, x2
    78d4:	f9401060 	ldr	x0, [x3, #32]
    78d8:	b40002c0 	cbz	x0, 7930 <f12+0x100>
    78dc:	38626882 	ldrb	w2, [x4, x2]
    78e0:	7100085f 	cmp	w2, #0x2
    78e4:	54006de0 	b.eq	86a0 <f12+0xe70>  // b.none
    78e8:	7100045f 	cmp	w2, #0x1
    78ec:	54000221 	b.ne	7930 <f12+0x100>  // b.any
    78f0:	29430864 	ldp	w4, w2, [x3, #24]
    78f4:	92403c21 	and	x1, x1, #0xffff
    78f8:	9b047c21 	mul	x1, x1, x4
    78fc:	d360fc21 	lsr	x1, x1, #32
    7900:	eb02003f 	cmp	x1, x2
    7904:	54000162 	b.cs	7930 <f12+0x100>  // b.hs, b.nlast
    7908:	8b010000 	add	x0, x0, x1
    790c:	39400001 	ldrb	w1, [x0]
    7910:	34000101 	cbz	w1, 7930 <f12+0x100>
    7914:	910182a2 	add	x2, x21, #0x60
    7918:	b9413043 	ldr	w3, [x2, #304]
    791c:	35006f63 	cbnz	w3, 8708 <f12+0xed8>
    7920:	7103f43f 	cmp	w1, #0xfd
    7924:	54007948 	b.hi	884c <f12+0x101c>  // b.pmore
    7928:	11000421 	add	w1, w1, #0x1
    792c:	39000001 	strb	w1, [x0]
    7930:	aa1903e0 	mov	x0, x25
    7934:	97fffa1f 	bl	61b0 <fwp_closure_drop>
    7938:	b4006bf4 	cbz	x20, 86b4 <f12+0xe84>
    793c:	aa1403e0 	mov	x0, x20
    7940:	d2800001 	mov	x1, #0x0                   	// #0
    7944:	d503201f 	nop
    7948:	f9400800 	ldr	x0, [x0, #16]
    794c:	91000421 	add	x1, x1, #0x1
    7950:	b5ffffc0 	cbnz	x0, 7948 <f12+0x118>
    7954:	aa0103fa 	mov	x26, x1
    7958:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    795c:	eb00003f 	cmp	x1, x0
    7960:	54007b48 	b.hi	88c8 <f12+0x1098>  // b.pmore
    7964:	910182b9 	add	x25, x21, #0x60
    7968:	b943c720 	ldr	w0, [x25, #964]
    796c:	34006860 	cbz	w0, 8678 <f12+0xe48>
    7970:	910182a0 	add	x0, x21, #0x60
    7974:	f9406c1b 	ldr	x27, [x0, #216]
    7978:	f940b019 	ldr	x25, [x0, #352]
    797c:	eb1b033f 	cmp	x25, x27
    7980:	5400358a 	b.ge	8030 <f12+0x800>  // b.tcont
    7984:	f9404401 	ldr	x1, [x0, #136]
    7988:	8b190720 	add	x0, x25, x25, lsl #1
    798c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7990:	8b000b20 	add	x0, x25, x0, lsl #2
    7994:	8b000c20 	add	x0, x1, x0, lsl #3
    7998:	b9400401 	ldr	w1, [x0, #4]
    799c:	35000081 	cbnz	w1, 79ac <f12+0x17c>
    79a0:	b9400001 	ldr	w1, [x0]
    79a4:	6b02003f 	cmp	w1, w2
    79a8:	54003449 	b.ls	8030 <f12+0x800>  // b.plast
    79ac:	91000739 	add	x25, x25, #0x1
    79b0:	9101a000 	add	x0, x0, #0x68
    79b4:	eb1b033f 	cmp	x25, x27
    79b8:	54ffff01 	b.ne	7998 <f12+0x168>  // b.any
    79bc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    79c0:	eb00037f 	cmp	x27, x0
    79c4:	540078ec 	b.gt	88e0 <f12+0x10b0>
    79c8:	910182a0 	add	x0, x21, #0x60
    79cc:	f9409001 	ldr	x1, [x0, #288]
    79d0:	f940441c 	ldr	x28, [x0, #136]
    79d4:	eb1b003f 	cmp	x1, x27
    79d8:	54000221 	b.ne	7a1c <f12+0x1ec>  // b.any
    79dc:	b400721b 	cbz	x27, 881c <f12+0xfec>
    79e0:	d37ffb79 	lsl	x25, x27, #1
    79e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    79e8:	eb00033f 	cmp	x25, x0
    79ec:	9a80d339 	csel	x25, x25, x0, le
    79f0:	8b190721 	add	x1, x25, x25, lsl #1
    79f4:	8b010b21 	add	x1, x25, x1, lsl #2
    79f8:	d37df021 	lsl	x1, x1, #3
    79fc:	aa1c03e0 	mov	x0, x28
    7a00:	52800002 	mov	w2, #0x0                   	// #0
    7a04:	97fff274 	bl	43d4 <ad_raw_realloc>
    7a08:	aa0003fc 	mov	x28, x0
    7a0c:	b40035e0 	cbz	x0, 80c8 <f12+0x898>
    7a10:	910182a0 	add	x0, x21, #0x60
    7a14:	f900441c 	str	x28, [x0, #136]
    7a18:	f9009019 	str	x25, [x0, #288]
    7a1c:	8b1b0761 	add	x1, x27, x27, lsl #1
    7a20:	910182a0 	add	x0, x21, #0x60
    7a24:	4f000400 	movi	v0.4s, #0x0
    7a28:	aa1b03f9 	mov	x25, x27
    7a2c:	8b010b61 	add	x1, x27, x1, lsl #2
    7a30:	9100077b 	add	x27, x27, #0x1
    7a34:	f9006c1b 	str	x27, [x0, #216]
    7a38:	8b19073b 	add	x27, x25, x25, lsl #1
    7a3c:	8b010f81 	add	x1, x28, x1, lsl #3
    7a40:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    7a44:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    7a48:	91338000 	add	x0, x0, #0xce0
    7a4c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7a50:	ad000020 	stp	q0, q0, [x1]
    7a54:	ad010020 	stp	q0, q0, [x1, #32]
    7a58:	ad020020 	stp	q0, q0, [x1, #64]
    7a5c:	f900303f 	str	xzr, [x1, #96]
    7a60:	f900337f 	str	xzr, [x27, #96]
    7a64:	97ffebcf 	bl	29a0 <getenv@plt>
    7a68:	b5002fc0 	cbnz	x0, 8060 <f12+0x830>
    7a6c:	d503201f 	nop
    7a70:	910182a0 	add	x0, x21, #0x60
    7a74:	f9408c01 	ldr	x1, [x0, #280]
    7a78:	b50062c1 	cbnz	x1, 86d0 <f12+0xea0>
    7a7c:	910182a2 	add	x2, x21, #0x60
    7a80:	2f000400 	mvni	v0.2s, #0x0
    7a84:	b9400363 	ldr	w3, [x27]
    7a88:	52800024 	mov	w4, #0x1                   	// #1
    7a8c:	91000720 	add	x0, x25, #0x1
    7a90:	a900eb7a 	stp	x26, x26, [x27, #8]
    7a94:	0b040063 	add	w3, w3, w4
    7a98:	f941c841 	ldr	x1, [x2, #912]
    7a9c:	29001363 	stp	w3, w4, [x27]
    7aa0:	f9002b7f 	str	xzr, [x27, #80]
    7aa4:	f900b040 	str	x0, [x2, #352]
    7aa8:	fd002f60 	str	d0, [x27, #88]
    7aac:	b4007081 	cbz	x1, 88bc <f12+0x108c>
    7ab0:	91150273 	add	x19, x19, #0x540
    7ab4:	14000003 	b	7ac0 <f12+0x290>
    7ab8:	f9400021 	ldr	x1, [x1]
    7abc:	b4007001 	cbz	x1, 88bc <f12+0x108c>
    7ac0:	f9400422 	ldr	x2, [x1, #8]
    7ac4:	eb13005f 	cmp	x2, x19
    7ac8:	54ffff81 	b.ne	7ab8 <f12+0x288>  // b.any
    7acc:	f9400821 	ldr	x1, [x1, #16]
    7ad0:	2a1903e4 	mov	w4, w25
    7ad4:	b9400022 	ldr	w2, [x1]
    7ad8:	f9002b61 	str	x1, [x27, #80]
    7adc:	b9005f62 	str	w2, [x27, #92]
    7ae0:	37f80082 	tbnz	w2, #31, 7af0 <f12+0x2c0>
    7ae4:	52800d05 	mov	w5, #0x68                  	// #104
    7ae8:	9b257042 	smaddl	x2, w2, w5, x28
    7aec:	b9005859 	str	w25, [x2, #88]
    7af0:	b9000024 	str	w4, [x1]
    7af4:	d3707c79 	ubfiz	x25, x3, #16, #32
    7af8:	aa000339 	orr	x25, x25, x0
    7afc:	d2800002 	mov	x2, #0x0                   	// #0
    7b00:	aa1403e0 	mov	x0, x20
    7b04:	b4005934 	cbz	x20, 8628 <f12+0xdf8>
    7b08:	f9400800 	ldr	x0, [x0, #16]
    7b0c:	91000442 	add	x2, x2, #0x1
    7b10:	b5ffffc0 	cbnz	x0, 7b08 <f12+0x2d8>
    7b14:	aa1403e1 	mov	x1, x20
    7b18:	f9400821 	ldr	x1, [x1, #16]
    7b1c:	91000400 	add	x0, x0, #0x1
    7b20:	b5ffffc1 	cbnz	x1, 7b18 <f12+0x2e8>
    7b24:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7b28:	eb01001f 	cmp	x0, x1
    7b2c:	54006b68 	b.hi	8898 <f12+0x1068>  // b.pmore
    7b30:	f100005f 	cmp	x2, #0x0
    7b34:	540057ad 	b.le	8628 <f12+0xdf8>
    7b38:	eb00005f 	cmp	x2, x0
    7b3c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7b40:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7b44:	eb01027f 	cmp	x19, x1
    7b48:	54006a88 	b.hi	8898 <f12+0x1068>  // b.pmore
    7b4c:	d37ffa7a 	lsl	x26, x19, #1
    7b50:	52800041 	mov	w1, #0x2                   	// #2
    7b54:	91000740 	add	x0, x26, #0x1
    7b58:	d37df000 	lsl	x0, x0, #3
    7b5c:	97fff54d 	bl	5090 <fwp_heap_alloc>
    7b60:	aa0003fb 	mov	x27, x0
    7b64:	911902e1 	add	x1, x23, #0x640
    7b68:	aa0103e0 	mov	x0, x1
    7b6c:	f900037a 	str	x26, [x27]
    7b70:	f949d821 	ldr	x1, [x1, #5040]
    7b74:	f949ec00 	ldr	x0, [x0, #5080]
    7b78:	cb010361 	sub	x1, x27, x1
    7b7c:	eb00403f 	cmp	x1, x0, lsl #16
    7b80:	54005742 	b.cs	8668 <f12+0xe38>  // b.hs, b.nlast
    7b84:	911902e2 	add	x2, x23, #0x640
    7b88:	d350fc20 	lsr	x0, x1, #16
    7b8c:	8b000800 	add	x0, x0, x0, lsl #2
    7b90:	f949fc43 	ldr	x3, [x2, #5112]
    7b94:	d37df002 	lsl	x2, x0, #3
    7b98:	8b020060 	add	x0, x3, x2
    7b9c:	f940101a 	ldr	x26, [x0, #32]
    7ba0:	b400025a 	cbz	x26, 7be8 <f12+0x3b8>
    7ba4:	38626862 	ldrb	w2, [x3, x2]
    7ba8:	7100085f 	cmp	w2, #0x2
    7bac:	54005740 	b.eq	8694 <f12+0xe64>  // b.none
    7bb0:	7100045f 	cmp	w2, #0x1
    7bb4:	540001a1 	b.ne	7be8 <f12+0x3b8>  // b.any
    7bb8:	29430002 	ldp	w2, w0, [x0, #24]
    7bbc:	92403c21 	and	x1, x1, #0xffff
    7bc0:	9b027c21 	mul	x1, x1, x2
    7bc4:	d360fc21 	lsr	x1, x1, #32
    7bc8:	eb00003f 	cmp	x1, x0
    7bcc:	540000e2 	b.cs	7be8 <f12+0x3b8>  // b.hs, b.nlast
    7bd0:	8b01035a 	add	x26, x26, x1
    7bd4:	39400340 	ldrb	w0, [x26]
    7bd8:	7103fc1f 	cmp	w0, #0xff
    7bdc:	54006260 	b.eq	8828 <f12+0xff8>  // b.none
    7be0:	52800020 	mov	w0, #0x1                   	// #1
    7be4:	39000340 	strb	w0, [x26]
    7be8:	b4000233 	cbz	x19, 7c2c <f12+0x3fc>
    7bec:	d3607f24 	lsl	x4, x25, #32
    7bf0:	aa1403e2 	mov	x2, x20
    7bf4:	f9400685 	ldr	x5, [x20, #8]
    7bf8:	aa0403e3 	mov	x3, x4
    7bfc:	91002360 	add	x0, x27, #0x8
    7c00:	d2800001 	mov	x1, #0x0                   	// #0
    7c04:	14000005 	b	7c18 <f12+0x3e8>
    7c08:	f9400445 	ldr	x5, [x2, #8]
    7c0c:	ab040023 	adds	x3, x1, x4
    7c10:	91004000 	add	x0, x0, #0x10
    7c14:	54006706 	b.vs	88f4 <f12+0x10c4>
    7c18:	a9000c05 	stp	x5, x3, [x0]
    7c1c:	91000421 	add	x1, x1, #0x1
    7c20:	f9400842 	ldr	x2, [x2, #16]
    7c24:	eb01027f 	cmp	x19, x1
    7c28:	54ffff08 	b.hi	7c08 <f12+0x3d8>  // b.pmore
    7c2c:	f9400360 	ldr	x0, [x27]
    7c30:	f100041f 	cmp	x0, #0x1
    7c34:	540051e9 	b.ls	8670 <f12+0xe40>  // b.plast
    7c38:	d341fc00 	lsr	x0, x0, #1
    7c3c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7c40:	d1000401 	sub	x1, x0, #0x1
    7c44:	eb02003f 	cmp	x1, x2
    7c48:	54006288 	b.hi	8898 <f12+0x1068>  // b.pmore
    7c4c:	d37ff83c 	lsl	x28, x1, #1
    7c50:	b4005101 	cbz	x1, 8670 <f12+0xe40>
    7c54:	d1002361 	sub	x1, x27, #0x8
    7c58:	91002373 	add	x19, x27, #0x8
    7c5c:	8b00103a 	add	x26, x1, x0, lsl #4
    7c60:	f9400660 	ldr	x0, [x19, #8]
    7c64:	f9400e61 	ldr	x1, [x19, #24]
    7c68:	fd400260 	ldr	d0, [x19]
    7c6c:	fd400a61 	ldr	d1, [x19, #16]
    7c70:	97fff6a4 	bl	5700 <w107>
    7c74:	a9000660 	stp	x0, x1, [x19]
    7c78:	91004273 	add	x19, x19, #0x10
    7c7c:	eb1a027f 	cmp	x19, x26
    7c80:	54ffff01 	b.ne	7c60 <f12+0x430>  // b.any
    7c84:	f900037c 	str	x28, [x27]
    7c88:	aa1b03e0 	mov	x0, x27
    7c8c:	93407f33 	sxtw	x19, w25
    7c90:	97fff6e0 	bl	5810 <w164.constprop.0>
    7c94:	aa0103fa 	mov	x26, x1
    7c98:	aa1b03e0 	mov	x0, x27
    7c9c:	97fffb7d 	bl	6a90 <fwp_drop4>
    7ca0:	aa1303e0 	mov	x0, x19
    7ca4:	97ffef83 	bl	3ab0 <fwp_tape_of>
    7ca8:	f9403001 	ldr	x1, [x0, #96]
    7cac:	aa0003ea 	mov	x10, x0
    7cb0:	b5006121 	cbnz	x1, 88d4 <f12+0x10a4>
    7cb4:	97ffecb8 	bl	2f94 <fwp_tape_unlink_scope>
    7cb8:	b9400002 	ldr	w2, [x0]
    7cbc:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7cc0:	a940801c 	ldp	x28, x0, [x0, #8]
    7cc4:	b900055f 	str	wzr, [x10, #4]
    7cc8:	a941994b 	ldp	x11, x6, [x10, #24]
    7ccc:	a942a147 	ldp	x7, x8, [x10, #40]
    7cd0:	a9439549 	ldp	x9, x5, [x10, #56]
    7cd4:	f940255b 	ldr	x27, [x10, #72]
    7cd8:	6b01005f 	cmp	w2, w1
    7cdc:	54000108 	b.hi	7cfc <f12+0x4cc>  // b.pmore
    7ce0:	910182a2 	add	x2, x21, #0x60
    7ce4:	92403e61 	and	x1, x19, #0xffff
    7ce8:	d1000421 	sub	x1, x1, #0x1
    7cec:	f940b043 	ldr	x3, [x2, #352]
    7cf0:	eb03003f 	cmp	x1, x3
    7cf4:	5400004a 	b.ge	7cfc <f12+0x4cc>  // b.tcont
    7cf8:	f900b041 	str	x1, [x2, #352]
    7cfc:	4f000400 	movi	v0.4s, #0x0
    7d00:	910182a3 	add	x3, x21, #0x60
    7d04:	f9000d5f 	str	xzr, [x10, #24]
    7d08:	910163e1 	add	x1, sp, #0x58
    7d0c:	9101c3f9 	add	x25, sp, #0x70
    7d10:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    7d14:	f941c86c 	ldr	x12, [x3, #912]
    7d18:	3c808140 	stur	q0, [x10, #8]
    7d1c:	91129042 	add	x2, x2, #0x4a4
    7d20:	ad010140 	stp	q0, q0, [x10, #32]
    7d24:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    7d28:	a9058bec 	stp	x12, x2, [sp, #88]
    7d2c:	a9069bf9 	stp	x25, x6, [sp, #104]
    7d30:	a907a3e7 	stp	x7, x8, [sp, #120]
    7d34:	a90897e9 	stp	x9, x5, [sp, #136]
    7d38:	a909efeb 	stp	x11, x27, [sp, #152]
    7d3c:	f901c861 	str	x1, [x3, #912]
    7d40:	b7f84bfa 	tbnz	x26, #63, 86bc <f12+0xe8c>
    7d44:	eb9a827f 	cmp	x19, x26, asr #32
    7d48:	54005961 	b.ne	8874 <f12+0x1044>  // b.any
    7d4c:	92407f53 	and	x19, x26, #0xffffffff
    7d50:	eb3a401f 	cmp	x0, w26, uxtw
    7d54:	5400596d 	b.le	8880 <f12+0x1050>
    7d58:	eb13039f 	cmp	x28, x19
    7d5c:	9a93c793 	csinc	x19, x28, x19, gt
    7d60:	eb13037f 	cmp	x27, x19
    7d64:	540019ea 	b.ge	80a0 <f12+0x870>  // b.tcont
    7d68:	f100037f 	cmp	x27, #0x0
    7d6c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7d70:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7d74:	14000004 	b	7d84 <f12+0x554>
    7d78:	eb01037f 	cmp	x27, x1
    7d7c:	d37ffb7b 	lsl	x27, x27, #1
    7d80:	9a93d37b 	csel	x27, x27, x19, le
    7d84:	eb13037f 	cmp	x27, x19
    7d88:	54ffff8b 	b.lt	7d78 <f12+0x548>  // b.tstop
    7d8c:	b4004e05 	cbz	x5, 874c <f12+0xf1c>
    7d90:	aa0503e0 	mov	x0, x5
    7d94:	d37df361 	lsl	x1, x27, #3
    7d98:	52800062 	mov	w2, #0x3                   	// #3
    7d9c:	a9009fe6 	stp	x6, x7, [sp, #8]
    7da0:	a901a7e8 	stp	x8, x9, [sp, #24]
    7da4:	97fff18c 	bl	43d4 <ad_raw_realloc>
    7da8:	aa0003e5 	mov	x5, x0
    7dac:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7db0:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7db4:	b4004b20 	cbz	x0, 8718 <f12+0xee8>
    7db8:	f9004be5 	str	x5, [sp, #144]
    7dbc:	f90053fb 	str	x27, [sp, #160]
    7dc0:	b50015d3 	cbnz	x19, 8078 <f12+0x848>
    7dc4:	b7f800da 	tbnz	x26, #63, 7ddc <f12+0x5ac>
    7dc8:	92407f41 	and	x1, x26, #0xffffffff
    7dcc:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7dd0:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    7dd4:	1e612800 	fadd	d0, d0, d1
    7dd8:	fc2178a0 	str	d0, [x5, x1, lsl #3]
    7ddc:	d1000673 	sub	x19, x19, #0x1
    7de0:	d1000783 	sub	x3, x28, #0x1
    7de4:	eb13039f 	cmp	x28, x19
    7de8:	540003ac 	b.gt	7e5c <f12+0x62c>
    7dec:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7df0:	1e602008 	fcmp	d0, #0.0
    7df4:	540002e0 	b.eq	7e50 <f12+0x620>  // b.none
    7df8:	cb1c0be0 	neg	x0, x28, lsl #2
    7dfc:	cb1c03e2 	neg	x2, x28
    7e00:	8b0000c1 	add	x1, x6, x0
    7e04:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7e08:	37f80101 	tbnz	w1, #31, 7e28 <f12+0x5f8>
    7e0c:	8b020d0a 	add	x10, x8, x2, lsl #3
    7e10:	93407c21 	sxtw	x1, w1
    7e14:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    7e18:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    7e1c:	1e620802 	fmul	d2, d0, d2
    7e20:	1e622821 	fadd	d1, d1, d2
    7e24:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    7e28:	8b0000e0 	add	x0, x7, x0
    7e2c:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    7e30:	37f80100 	tbnz	w0, #31, 7e50 <f12+0x620>
    7e34:	8b020d22 	add	x2, x9, x2, lsl #3
    7e38:	93407c00 	sxtw	x0, w0
    7e3c:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7e40:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7e44:	1e620800 	fmul	d0, d0, d2
    7e48:	1e602820 	fadd	d0, d1, d0
    7e4c:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7e50:	d1000673 	sub	x19, x19, #0x1
    7e54:	eb13007f 	cmp	x3, x19
    7e58:	54fffca1 	b.ne	7dec <f12+0x5bc>  // b.any
    7e5c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7e60:	eb00039f 	cmp	x28, x0
    7e64:	54005208 	b.hi	88a4 <f12+0x1074>  // b.pmore
    7e68:	91000780 	add	x0, x28, #0x1
    7e6c:	52800041 	mov	w1, #0x2                   	// #2
    7e70:	f90007e5 	str	x5, [sp, #8]
    7e74:	d37df000 	lsl	x0, x0, #3
    7e78:	97fff486 	bl	5090 <fwp_heap_alloc>
    7e7c:	aa0003e2 	mov	x2, x0
    7e80:	aa0003f3 	mov	x19, x0
    7e84:	f94007e5 	ldr	x5, [sp, #8]
    7e88:	d2800001 	mov	x1, #0x0                   	// #0
    7e8c:	f800845c 	str	x28, [x2], #8
    7e90:	b40000fc 	cbz	x28, 7eac <f12+0x67c>
    7e94:	d503201f 	nop
    7e98:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    7e9c:	f8217840 	str	x0, [x2, x1, lsl #3]
    7ea0:	91000421 	add	x1, x1, #0x1
    7ea4:	eb01039f 	cmp	x28, x1
    7ea8:	54ffff81 	b.ne	7e98 <f12+0x668>  // b.any
    7eac:	910182a1 	add	x1, x21, #0x60
    7eb0:	aa1903e0 	mov	x0, x25
    7eb4:	f9402ffa 	ldr	x26, [sp, #88]
    7eb8:	f901c83a 	str	x26, [x1, #912]
    7ebc:	97fff17a 	bl	44a4 <fwp_tape_buffers_release>
    7ec0:	911902e2 	add	x2, x23, #0x640
    7ec4:	f949d841 	ldr	x1, [x2, #5040]
    7ec8:	f949ec40 	ldr	x0, [x2, #5080]
    7ecc:	cb010261 	sub	x1, x19, x1
    7ed0:	eb00403f 	cmp	x1, x0, lsl #16
    7ed4:	54000322 	b.cs	7f38 <f12+0x708>  // b.hs, b.nlast
    7ed8:	d350fc20 	lsr	x0, x1, #16
    7edc:	f949fc43 	ldr	x3, [x2, #5112]
    7ee0:	8b000800 	add	x0, x0, x0, lsl #2
    7ee4:	d37df002 	lsl	x2, x0, #3
    7ee8:	8b020060 	add	x0, x3, x2
    7eec:	f9401019 	ldr	x25, [x0, #32]
    7ef0:	b4000259 	cbz	x25, 7f38 <f12+0x708>
    7ef4:	38626862 	ldrb	w2, [x3, x2]
    7ef8:	7100085f 	cmp	w2, #0x2
    7efc:	54003e40 	b.eq	86c4 <f12+0xe94>  // b.none
    7f00:	7100045f 	cmp	w2, #0x1
    7f04:	540001a1 	b.ne	7f38 <f12+0x708>  // b.any
    7f08:	29430002 	ldp	w2, w0, [x0, #24]
    7f0c:	92403c21 	and	x1, x1, #0xffff
    7f10:	9b027c21 	mul	x1, x1, x2
    7f14:	d360fc21 	lsr	x1, x1, #32
    7f18:	eb00003f 	cmp	x1, x0
    7f1c:	540000e2 	b.cs	7f38 <f12+0x708>  // b.hs, b.nlast
    7f20:	8b010339 	add	x25, x25, x1
    7f24:	39400320 	ldrb	w0, [x25]
    7f28:	7103fc1f 	cmp	w0, #0xff
    7f2c:	54004840 	b.eq	8834 <f12+0x1004>  // b.none
    7f30:	52800020 	mov	w0, #0x1                   	// #1
    7f34:	39000320 	strb	w0, [x25]
    7f38:	eb18035f 	cmp	x26, x24
    7f3c:	54004da1 	b.ne	88f0 <f12+0x10c0>  // b.any
    7f40:	f94023e1 	ldr	x1, [sp, #64]
    7f44:	910182b5 	add	x21, x21, #0x60
    7f48:	aa1603e0 	mov	x0, x22
    7f4c:	f901caa1 	str	x1, [x21, #912]
    7f50:	97fff97c 	bl	6540 <fwp_tape_scope_release>
    7f54:	f9400260 	ldr	x0, [x19]
    7f58:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7f5c:	b7f83120 	tbnz	x0, #63, 8580 <f12+0xd50>
    7f60:	911902e2 	add	x2, x23, #0x640
    7f64:	f949d840 	ldr	x0, [x2, #5040]
    7f68:	f949ec41 	ldr	x1, [x2, #5080]
    7f6c:	cb000260 	sub	x0, x19, x0
    7f70:	eb01401f 	cmp	x0, x1, lsl #16
    7f74:	54003062 	b.cs	8580 <f12+0xd50>  // b.hs, b.nlast
    7f78:	d350fc01 	lsr	x1, x0, #16
    7f7c:	f949fc44 	ldr	x4, [x2, #5112]
    7f80:	8b010821 	add	x1, x1, x1, lsl #2
    7f84:	d37df021 	lsl	x1, x1, #3
    7f88:	8b010083 	add	x3, x4, x1
    7f8c:	f9401062 	ldr	x2, [x3, #32]
    7f90:	b4002f82 	cbz	x2, 8580 <f12+0xd50>
    7f94:	38616881 	ldrb	w1, [x4, x1]
    7f98:	7100083f 	cmp	w1, #0x2
    7f9c:	54002ec0 	b.eq	8574 <f12+0xd44>  // b.none
    7fa0:	7100043f 	cmp	w1, #0x1
    7fa4:	54002ee1 	b.ne	8580 <f12+0xd50>  // b.any
    7fa8:	29430464 	ldp	w4, w1, [x3, #24]
    7fac:	92403c00 	and	x0, x0, #0xffff
    7fb0:	9b047c00 	mul	x0, x0, x4
    7fb4:	d360fc00 	lsr	x0, x0, #32
    7fb8:	eb01001f 	cmp	x0, x1
    7fbc:	54002e22 	b.cs	8580 <f12+0xd50>  // b.hs, b.nlast
    7fc0:	8b000042 	add	x2, x2, x0
    7fc4:	39400040 	ldrb	w0, [x2]
    7fc8:	7100041f 	cmp	w0, #0x1
    7fcc:	54002da1 	b.ne	8580 <f12+0xd50>  // b.any
    7fd0:	aa1303f5 	mov	x21, x19
    7fd4:	d2800000 	mov	x0, #0x0                   	// #0
    7fd8:	f90007f3 	str	x19, [sp, #8]
    7fdc:	f94007e1 	ldr	x1, [sp, #8]
    7fe0:	91002023 	add	x3, x1, #0x8
    7fe4:	d2800001 	mov	x1, #0x0                   	// #0
    7fe8:	b4000898 	cbz	x24, 80f8 <f12+0x8c8>
    7fec:	f0000022 	adrp	x2, e000 <_IO_stdin_used+0x720>
    7ff0:	91002265 	add	x5, x19, #0x8
    7ff4:	fd445841 	ldr	d1, [x2, #2224]
    7ff8:	14000009 	b	801c <f12+0x7ec>
    7ffc:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8000:	f94002a2 	ldr	x2, [x21]
    8004:	1e600820 	fmul	d0, d1, d0
    8008:	b7f84422 	tbnz	x2, #63, 888c <f12+0x105c>
    800c:	91000421 	add	x1, x1, #0x1
    8010:	fc008460 	str	d0, [x3], #8
    8014:	eb01031f 	cmp	x24, x1
    8018:	54000700 	b.eq	80f8 <f12+0x8c8>  // b.none
    801c:	f9400264 	ldr	x4, [x19]
    8020:	aa0503e2 	mov	x2, x5
    8024:	b6fffec4 	tbz	x4, #63, 7ffc <f12+0x7cc>
    8028:	f9400a62 	ldr	x2, [x19, #16]
    802c:	17fffff4 	b	7ffc <f12+0x7cc>
    8030:	eb19037f 	cmp	x27, x25
    8034:	54ffcc40 	b.eq	79bc <f12+0x18c>  // b.none
    8038:	910182a0 	add	x0, x21, #0x60
    803c:	8b19073b 	add	x27, x25, x25, lsl #1
    8040:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    8044:	f940441c 	ldr	x28, [x0, #136]
    8048:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    804c:	91338000 	add	x0, x0, #0xce0
    8050:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8054:	f900337f 	str	xzr, [x27, #96]
    8058:	97ffea52 	bl	29a0 <getenv@plt>
    805c:	b4ffd0a0 	cbz	x0, 7a70 <f12+0x240>
    8060:	39400001 	ldrb	w1, [x0]
    8064:	7100c03f 	cmp	w1, #0x30
    8068:	54ffd041 	b.ne	7a70 <f12+0x240>  // b.any
    806c:	39400400 	ldrb	w0, [x0, #1]
    8070:	34ffd060 	cbz	w0, 7a7c <f12+0x24c>
    8074:	17fffe7f 	b	7a70 <f12+0x240>
    8078:	aa0503e0 	mov	x0, x5
    807c:	d37df262 	lsl	x2, x19, #3
    8080:	52800001 	mov	w1, #0x0                   	// #0
    8084:	a9009fe6 	stp	x6, x7, [sp, #8]
    8088:	a901a7e8 	stp	x8, x9, [sp, #24]
    808c:	97ffe9d5 	bl	27e0 <memset@plt>
    8090:	aa0003e5 	mov	x5, x0
    8094:	a9409fe6 	ldp	x6, x7, [sp, #8]
    8098:	a941a7e8 	ldp	x8, x9, [sp, #24]
    809c:	17ffff4a 	b	7dc4 <f12+0x594>
    80a0:	f10000bf 	cmp	x5, #0x0
    80a4:	1a9f17e0 	cset	w0, eq	// eq = none
    80a8:	f100027f 	cmp	x19, #0x0
    80ac:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    80b0:	54ffe880 	b.eq	7dc0 <f12+0x590>  // b.none
    80b4:	f9402fe1 	ldr	x1, [sp, #88]
    80b8:	910182b5 	add	x21, x21, #0x60
    80bc:	aa1903e0 	mov	x0, x25
    80c0:	f901caa1 	str	x1, [x21, #912]
    80c4:	97fff0f8 	bl	44a4 <fwp_tape_buffers_release>
    80c8:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    80cc:	f947e863 	ldr	x3, [x3, #4048]
    80d0:	d2800262 	mov	x2, #0x13                  	// #19
    80d4:	d2800021 	mov	x1, #0x1                   	// #1
    80d8:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    80dc:	9123a000 	add	x0, x0, #0x8e8
    80e0:	f9400063 	ldr	x3, [x3]
    80e4:	97ffea0b 	bl	2910 <fwrite@plt>
    80e8:	d2800000 	mov	x0, #0x0                   	// #0
    80ec:	97ffea15 	bl	2940 <fflush@plt>
    80f0:	52800cc0 	mov	w0, #0x66                  	// #102
    80f4:	97ffea23 	bl	2980 <_Exit@plt>
    80f8:	97fffa66 	bl	6a90 <fwp_drop4>
    80fc:	aa1403e1 	mov	x1, x20
    8100:	d2800002 	mov	x2, #0x0                   	// #0
    8104:	b4003774 	cbz	x20, 87f0 <f12+0xfc0>
    8108:	f9400821 	ldr	x1, [x1, #16]
    810c:	91000442 	add	x2, x2, #0x1
    8110:	b5ffffc1 	cbnz	x1, 8108 <f12+0x8d8>
    8114:	f94002a3 	ldr	x3, [x21]
    8118:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    811c:	b7f81f43 	tbnz	x3, #63, 8504 <f12+0xcd4>
    8120:	911902e1 	add	x1, x23, #0x640
    8124:	f94007e4 	ldr	x4, [sp, #8]
    8128:	f949d820 	ldr	x0, [x1, #5040]
    812c:	f949ec21 	ldr	x1, [x1, #5080]
    8130:	cb000080 	sub	x0, x4, x0
    8134:	eb01401f 	cmp	x0, x1, lsl #16
    8138:	54001e62 	b.cs	8504 <f12+0xcd4>  // b.hs, b.nlast
    813c:	911902e4 	add	x4, x23, #0x640
    8140:	d350fc01 	lsr	x1, x0, #16
    8144:	8b010821 	add	x1, x1, x1, lsl #2
    8148:	f949fc86 	ldr	x6, [x4, #5112]
    814c:	d37df021 	lsl	x1, x1, #3
    8150:	8b0100c5 	add	x5, x6, x1
    8154:	f94010a4 	ldr	x4, [x5, #32]
    8158:	b4001d44 	cbz	x4, 8500 <f12+0xcd0>
    815c:	386168c1 	ldrb	w1, [x6, x1]
    8160:	7100083f 	cmp	w1, #0x2
    8164:	54001ca0 	b.eq	84f8 <f12+0xcc8>  // b.none
    8168:	7100043f 	cmp	w1, #0x1
    816c:	54001ca1 	b.ne	8500 <f12+0xcd0>  // b.any
    8170:	294304a6 	ldp	w6, w1, [x5, #24]
    8174:	92403c00 	and	x0, x0, #0xffff
    8178:	9b067c00 	mul	x0, x0, x6
    817c:	d360fc00 	lsr	x0, x0, #32
    8180:	eb01001f 	cmp	x0, x1
    8184:	54001be2 	b.cs	8500 <f12+0xcd0>  // b.hs, b.nlast
    8188:	8b000084 	add	x4, x4, x0
    818c:	39400098 	ldrb	w24, [x4]
    8190:	7100071f 	cmp	w24, #0x1
    8194:	54001b61 	b.ne	8500 <f12+0xcd0>  // b.any
    8198:	b90013f8 	str	w24, [sp, #16]
    819c:	eb1c005f 	cmp	x2, x28
    81a0:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    81a4:	910022b9 	add	x25, x21, #0x8
    81a8:	b400361c 	cbz	x28, 8868 <f12+0x1038>
    81ac:	f94007e0 	ldr	x0, [sp, #8]
    81b0:	d37df385 	lsl	x5, x28, #3
    81b4:	aa1403e2 	mov	x2, x20
    81b8:	d2800001 	mov	x1, #0x0                   	// #0
    81bc:	91002000 	add	x0, x0, #0x8
    81c0:	1400000a 	b	81e8 <f12+0x9b8>
    81c4:	fc616881 	ldr	d1, [x4, x1]
    81c8:	fd400440 	ldr	d0, [x2, #8]
    81cc:	1e613800 	fsub	d0, d0, d1
    81d0:	fc216b20 	str	d0, [x25, x1]
    81d4:	91002021 	add	x1, x1, #0x8
    81d8:	f9400842 	ldr	x2, [x2, #16]
    81dc:	eb05003f 	cmp	x1, x5
    81e0:	540001c0 	b.eq	8218 <f12+0x9e8>  // b.none
    81e4:	f94002a3 	ldr	x3, [x21]
    81e8:	aa0003e4 	mov	x4, x0
    81ec:	b6fffec3 	tbz	x3, #63, 81c4 <f12+0x994>
    81f0:	f94007e3 	ldr	x3, [sp, #8]
    81f4:	fd400440 	ldr	d0, [x2, #8]
    81f8:	f9400864 	ldr	x4, [x3, #16]
    81fc:	fc616881 	ldr	d1, [x4, x1]
    8200:	1e613800 	fsub	d0, d0, d1
    8204:	fc216b20 	str	d0, [x25, x1]
    8208:	91002021 	add	x1, x1, #0x8
    820c:	f9400842 	ldr	x2, [x2, #16]
    8210:	eb05003f 	cmp	x1, x5
    8214:	54fffe81 	b.ne	81e4 <f12+0x9b4>  // b.any
    8218:	b4003254 	cbz	x20, 8860 <f12+0x1030>
    821c:	911902e0 	add	x0, x23, #0x640
    8220:	aa1403e2 	mov	x2, x20
    8224:	d280001a 	mov	x26, #0x0                   	// #0
    8228:	f949ec06 	ldr	x6, [x0, #5080]
    822c:	f949d807 	ldr	x7, [x0, #5040]
    8230:	f949fc05 	ldr	x5, [x0, #5112]
    8234:	d370bcc6 	lsl	x6, x6, #16
    8238:	14000006 	b	8250 <f12+0xa20>
    823c:	f9400842 	ldr	x2, [x2, #16]
    8240:	9100075a 	add	x26, x26, #0x1
    8244:	f100005f 	cmp	x2, #0x0
    8248:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    824c:	54000329 	b.ls	82b0 <f12+0xa80>  // b.plast
    8250:	cb070040 	sub	x0, x2, x7
    8254:	eb06001f 	cmp	x0, x6
    8258:	540002c2 	b.cs	82b0 <f12+0xa80>  // b.hs, b.nlast
    825c:	d350fc01 	lsr	x1, x0, #16
    8260:	8b010821 	add	x1, x1, x1, lsl #2
    8264:	d37df021 	lsl	x1, x1, #3
    8268:	8b0100a4 	add	x4, x5, x1
    826c:	f9401083 	ldr	x3, [x4, #32]
    8270:	b4000203 	cbz	x3, 82b0 <f12+0xa80>
    8274:	386168a1 	ldrb	w1, [x5, x1]
    8278:	7100083f 	cmp	w1, #0x2
    827c:	54000de0 	b.eq	8438 <f12+0xc08>  // b.none
    8280:	7100043f 	cmp	w1, #0x1
    8284:	54000161 	b.ne	82b0 <f12+0xa80>  // b.any
    8288:	29430488 	ldp	w8, w1, [x4, #24]
    828c:	92403c00 	and	x0, x0, #0xffff
    8290:	9b087c00 	mul	x0, x0, x8
    8294:	d360fc00 	lsr	x0, x0, #32
    8298:	eb01001f 	cmp	x0, x1
    829c:	540000a2 	b.cs	82b0 <f12+0xa80>  // b.hs, b.nlast
    82a0:	8b000063 	add	x3, x3, x0
    82a4:	39400060 	ldrb	w0, [x3]
    82a8:	7100041f 	cmp	w0, #0x1
    82ac:	54fffc80 	b.eq	823c <f12+0xa0c>  // b.none
    82b0:	eb1a039f 	cmp	x28, x26
    82b4:	54000ca9 	b.ls	8448 <f12+0xc18>  // b.plast
    82b8:	d1002336 	sub	x22, x25, #0x8
    82bc:	9102a3f5 	add	x21, sp, #0xa8
    82c0:	911902f8 	add	x24, x23, #0x640
    82c4:	d2800013 	mov	x19, #0x0                   	// #0
    82c8:	14000012 	b	8310 <f12+0xae0>
    82cc:	7100045f 	cmp	w2, #0x1
    82d0:	540001a1 	b.ne	8304 <f12+0xad4>  // b.any
    82d4:	29430002 	ldp	w2, w0, [x0, #24]
    82d8:	92403c21 	and	x1, x1, #0xffff
    82dc:	9b027c21 	mul	x1, x1, x2
    82e0:	d360fc21 	lsr	x1, x1, #32
    82e4:	eb00003f 	cmp	x1, x0
    82e8:	540000e2 	b.cs	8304 <f12+0xad4>  // b.hs, b.nlast
    82ec:	8b01037b 	add	x27, x27, x1
    82f0:	39400360 	ldrb	w0, [x27]
    82f4:	7103fc1f 	cmp	w0, #0xff
    82f8:	54001b20 	b.eq	865c <f12+0xe2c>  // b.none
    82fc:	52800020 	mov	w0, #0x1                   	// #1
    8300:	39000360 	strb	w0, [x27]
    8304:	d100079c 	sub	x28, x28, #0x1
    8308:	eb1c035f 	cmp	x26, x28
    830c:	54000362 	b.cs	8378 <f12+0xb48>  // b.hs, b.nlast
    8310:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    8314:	aa1503e1 	mov	x1, x21
    8318:	52800020 	mov	w0, #0x1                   	// #1
    831c:	a90acfe2 	stp	x2, x19, [sp, #168]
    8320:	97fff564 	bl	58b0 <fwp_data.part.0.constprop.0>
    8324:	aa0003f3 	mov	x19, x0
    8328:	f949db01 	ldr	x1, [x24, #5040]
    832c:	f949ef00 	ldr	x0, [x24, #5080]
    8330:	cb010261 	sub	x1, x19, x1
    8334:	eb00403f 	cmp	x1, x0, lsl #16
    8338:	54fffe62 	b.cs	8304 <f12+0xad4>  // b.hs, b.nlast
    833c:	d350fc22 	lsr	x2, x1, #16
    8340:	f949ff03 	ldr	x3, [x24, #5112]
    8344:	8b020842 	add	x2, x2, x2, lsl #2
    8348:	d37df042 	lsl	x2, x2, #3
    834c:	8b020060 	add	x0, x3, x2
    8350:	f940101b 	ldr	x27, [x0, #32]
    8354:	b4fffd9b 	cbz	x27, 8304 <f12+0xad4>
    8358:	38626862 	ldrb	w2, [x3, x2]
    835c:	7100085f 	cmp	w2, #0x2
    8360:	54fffb61 	b.ne	82cc <f12+0xa9c>  // b.any
    8364:	72003c3f 	tst	w1, #0xffff
    8368:	54fffc40 	b.eq	82f0 <f12+0xac0>  // b.none
    836c:	d100079c 	sub	x28, x28, #0x1
    8370:	eb1c035f 	cmp	x26, x28
    8374:	54fffce3 	b.cc	8310 <f12+0xae0>  // b.lo, b.ul, b.last
    8378:	b50006ba 	cbnz	x26, 844c <f12+0xc1c>
    837c:	b94013e0 	ldr	w0, [sp, #16]
    8380:	d2800038 	mov	x24, #0x1                   	// #1
    8384:	d280001b 	mov	x27, #0x0                   	// #0
    8388:	7100001f 	cmp	w0, #0x0
    838c:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    8390:	b40007db 	cbz	x27, 8488 <f12+0xc58>
    8394:	d100077b 	sub	x27, x27, #0x1
    8398:	911902f7 	add	x23, x23, #0x640
    839c:	d503201f 	nop
    83a0:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    83a4:	aa1503e1 	mov	x1, x21
    83a8:	52800020 	mov	w0, #0x1                   	// #1
    83ac:	a90acfe2 	stp	x2, x19, [sp, #168]
    83b0:	97fff540 	bl	58b0 <fwp_data.part.0.constprop.0>
    83b4:	aa0003f3 	mov	x19, x0
    83b8:	f949dae1 	ldr	x1, [x23, #5040]
    83bc:	f949eee0 	ldr	x0, [x23, #5080]
    83c0:	cb010261 	sub	x1, x19, x1
    83c4:	eb00403f 	cmp	x1, x0, lsl #16
    83c8:	54000302 	b.cs	8428 <f12+0xbf8>  // b.hs, b.nlast
    83cc:	d350fc22 	lsr	x2, x1, #16
    83d0:	f949fee3 	ldr	x3, [x23, #5112]
    83d4:	8b020842 	add	x2, x2, x2, lsl #2
    83d8:	d37df042 	lsl	x2, x2, #3
    83dc:	8b020060 	add	x0, x3, x2
    83e0:	f940101a 	ldr	x26, [x0, #32]
    83e4:	b400023a 	cbz	x26, 8428 <f12+0xbf8>
    83e8:	38626862 	ldrb	w2, [x3, x2]
    83ec:	7100085f 	cmp	w2, #0x2
    83f0:	540007e0 	b.eq	84ec <f12+0xcbc>  // b.none
    83f4:	7100045f 	cmp	w2, #0x1
    83f8:	54000181 	b.ne	8428 <f12+0xbf8>  // b.any
    83fc:	29430002 	ldp	w2, w0, [x0, #24]
    8400:	92403c21 	and	x1, x1, #0xffff
    8404:	9b027c21 	mul	x1, x1, x2
    8408:	d360fc21 	lsr	x1, x1, #32
    840c:	eb00003f 	cmp	x1, x0
    8410:	540000c2 	b.cs	8428 <f12+0xbf8>  // b.hs, b.nlast
    8414:	8b01035a 	add	x26, x26, x1
    8418:	39400340 	ldrb	w0, [x26]
    841c:	7103fc1f 	cmp	w0, #0xff
    8420:	54000600 	b.eq	84e0 <f12+0xcb0>  // b.none
    8424:	39000358 	strb	w24, [x26]
    8428:	d100077b 	sub	x27, x27, #0x1
    842c:	b100077f 	cmn	x27, #0x1
    8430:	54fffb81 	b.ne	83a0 <f12+0xb70>  // b.any
    8434:	14000015 	b	8488 <f12+0xc58>
    8438:	72003c1f 	tst	w0, #0xffff
    843c:	54fff340 	b.eq	82a4 <f12+0xa74>  // b.none
    8440:	eb1a039f 	cmp	x28, x26
    8444:	54fff3a8 	b.hi	82b8 <f12+0xa88>  // b.pmore
    8448:	d2800013 	mov	x19, #0x0                   	// #0
    844c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    8450:	aa1903e1 	mov	x1, x25
    8454:	aa1403e0 	mov	x0, x20
    8458:	f8408422 	ldr	x2, [x1], #8
    845c:	f9000402 	str	x2, [x0, #8]
    8460:	aa0003e2 	mov	x2, x0
    8464:	f9400800 	ldr	x0, [x0, #16]
    8468:	eb01035f 	cmp	x26, x1
    846c:	54ffff61 	b.ne	8458 <f12+0xc28>  // b.any
    8470:	b94013e1 	ldr	w1, [sp, #16]
    8474:	f9000853 	str	x19, [x2, #16]
    8478:	aa1403f3 	mov	x19, x20
    847c:	aa0003f4 	mov	x20, x0
    8480:	34000041 	cbz	w1, 8488 <f12+0xc58>
    8484:	d2800019 	mov	x25, #0x0                   	// #0
    8488:	aa1903e0 	mov	x0, x25
    848c:	97fff1e1 	bl	4c10 <fwp_mem_free>
    8490:	f94007e0 	ldr	x0, [sp, #8]
    8494:	97fff97f 	bl	6a90 <fwp_drop4>
    8498:	aa1403e0 	mov	x0, x20
    849c:	97fff6e9 	bl	6040 <fwp_drop0>
    84a0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    84a4:	f947f400 	ldr	x0, [x0, #4072]
    84a8:	f9405fe2 	ldr	x2, [sp, #184]
    84ac:	f9400001 	ldr	x1, [x0]
    84b0:	eb010042 	subs	x2, x2, x1
    84b4:	d2800001 	mov	x1, #0x0                   	// #0
    84b8:	540021a1 	b.ne	88ec <f12+0x10bc>  // b.any
    84bc:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    84c0:	aa1303e0 	mov	x0, x19
    84c4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    84c8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    84cc:	a94f63f7 	ldp	x23, x24, [sp, #240]
    84d0:	a9506bf9 	ldp	x25, x26, [sp, #256]
    84d4:	a95173fb 	ldp	x27, x28, [sp, #272]
    84d8:	910483ff 	add	sp, sp, #0x120
    84dc:	d65f03c0 	ret
    84e0:	aa1a03e0 	mov	x0, x26
    84e4:	97fff12b 	bl	4990 <fwp_rc_forget_slot>
    84e8:	17ffffcf 	b	8424 <f12+0xbf4>
    84ec:	72003c3f 	tst	w1, #0xffff
    84f0:	54fff9c1 	b.ne	8428 <f12+0xbf8>  // b.any
    84f4:	17ffffc9 	b	8418 <f12+0xbe8>
    84f8:	72003c1f 	tst	w0, #0xffff
    84fc:	54ffe480 	b.eq	818c <f12+0x95c>  // b.none
    8500:	b4001134 	cbz	x20, 8724 <f12+0xef4>
    8504:	aa1403f3 	mov	x19, x20
    8508:	d2800018 	mov	x24, #0x0                   	// #0
    850c:	d503201f 	nop
    8510:	f9400a73 	ldr	x19, [x19, #16]
    8514:	aa1803e0 	mov	x0, x24
    8518:	91000718 	add	x24, x24, #0x1
    851c:	b5ffffb3 	cbnz	x19, 8510 <f12+0xce0>
    8520:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8524:	eb01031f 	cmp	x24, x1
    8528:	54001b88 	b.hi	8898 <f12+0x1068>  // b.pmore
    852c:	91000800 	add	x0, x0, #0x2
    8530:	52800041 	mov	w1, #0x2                   	// #2
    8534:	d37df000 	lsl	x0, x0, #3
    8538:	97fff2d6 	bl	5090 <fwp_heap_alloc>
    853c:	eb1c031f 	cmp	x24, x28
    8540:	aa0003f9 	mov	x25, x0
    8544:	9a9c931c 	csel	x28, x24, x28, ls	// ls = plast
    8548:	aa1403e1 	mov	x1, x20
    854c:	d503201f 	nop
    8550:	f9400420 	ldr	x0, [x1, #8]
    8554:	f8337b20 	str	x0, [x25, x19, lsl #3]
    8558:	91000673 	add	x19, x19, #0x1
    855c:	f9400821 	ldr	x1, [x1, #16]
    8560:	b5ffff81 	cbnz	x1, 8550 <f12+0xd20>
    8564:	b4000e9c 	cbz	x28, 8734 <f12+0xf04>
    8568:	f94002a3 	ldr	x3, [x21]
    856c:	b90013ff 	str	wzr, [sp, #16]
    8570:	17ffff0f 	b	81ac <f12+0x97c>
    8574:	72003c1f 	tst	w0, #0xffff
    8578:	54ffd260 	b.eq	7fc4 <f12+0x794>  // b.none
    857c:	d503201f 	nop
    8580:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8584:	eb00031f 	cmp	x24, x0
    8588:	540018e8 	b.hi	88a4 <f12+0x1074>  // b.pmore
    858c:	91000700 	add	x0, x24, #0x1
    8590:	52800021 	mov	w1, #0x1                   	// #1
    8594:	d37df000 	lsl	x0, x0, #3
    8598:	97fff2be 	bl	5090 <fwp_heap_alloc>
    859c:	911902e2 	add	x2, x23, #0x640
    85a0:	f9000018 	str	x24, [x0]
    85a4:	aa0003f5 	mov	x21, x0
    85a8:	f90007f5 	str	x21, [sp, #8]
    85ac:	f949d841 	ldr	x1, [x2, #5040]
    85b0:	f949ec40 	ldr	x0, [x2, #5080]
    85b4:	cb0102a1 	sub	x1, x21, x1
    85b8:	eb00403f 	cmp	x1, x0, lsl #16
    85bc:	54000322 	b.cs	8620 <f12+0xdf0>  // b.hs, b.nlast
    85c0:	d350fc20 	lsr	x0, x1, #16
    85c4:	f949fc43 	ldr	x3, [x2, #5112]
    85c8:	8b000800 	add	x0, x0, x0, lsl #2
    85cc:	d37df002 	lsl	x2, x0, #3
    85d0:	8b020060 	add	x0, x3, x2
    85d4:	f9401019 	ldr	x25, [x0, #32]
    85d8:	b4000259 	cbz	x25, 8620 <f12+0xdf0>
    85dc:	38626862 	ldrb	w2, [x3, x2]
    85e0:	7100085f 	cmp	w2, #0x2
    85e4:	54000ac0 	b.eq	873c <f12+0xf0c>  // b.none
    85e8:	7100045f 	cmp	w2, #0x1
    85ec:	540001a1 	b.ne	8620 <f12+0xdf0>  // b.any
    85f0:	29430002 	ldp	w2, w0, [x0, #24]
    85f4:	92403c21 	and	x1, x1, #0xffff
    85f8:	9b027c21 	mul	x1, x1, x2
    85fc:	d360fc21 	lsr	x1, x1, #32
    8600:	eb00003f 	cmp	x1, x0
    8604:	540000e2 	b.cs	8620 <f12+0xdf0>  // b.hs, b.nlast
    8608:	8b010339 	add	x25, x25, x1
    860c:	39400320 	ldrb	w0, [x25]
    8610:	7103fc1f 	cmp	w0, #0xff
    8614:	54001160 	b.eq	8840 <f12+0x1010>  // b.none
    8618:	52800020 	mov	w0, #0x1                   	// #1
    861c:	39000320 	strb	w0, [x25]
    8620:	aa1303e0 	mov	x0, x19
    8624:	17fffe6e 	b	7fdc <f12+0x7ac>
    8628:	52800041 	mov	w1, #0x2                   	// #2
    862c:	d2800100 	mov	x0, #0x8                   	// #8
    8630:	97fff298 	bl	5090 <fwp_heap_alloc>
    8634:	aa0003fb 	mov	x27, x0
    8638:	911902e0 	add	x0, x23, #0x640
    863c:	f900037f 	str	xzr, [x27]
    8640:	f949d801 	ldr	x1, [x0, #5040]
    8644:	f949ec00 	ldr	x0, [x0, #5080]
    8648:	cb010361 	sub	x1, x27, x1
    864c:	eb00403f 	cmp	x1, x0, lsl #16
    8650:	54000102 	b.cs	8670 <f12+0xe40>  // b.hs, b.nlast
    8654:	d2800013 	mov	x19, #0x0                   	// #0
    8658:	17fffd4b 	b	7b84 <f12+0x354>
    865c:	aa1b03e0 	mov	x0, x27
    8660:	97fff0cc 	bl	4990 <fwp_rc_forget_slot>
    8664:	17ffff26 	b	82fc <f12+0xacc>
    8668:	b5ffac33 	cbnz	x19, 7bec <f12+0x3bc>
    866c:	d503201f 	nop
    8670:	d280001c 	mov	x28, #0x0                   	// #0
    8674:	17fffd84 	b	7c84 <f12+0x454>
    8678:	d0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x110>
    867c:	9110c000 	add	x0, x0, #0x430
    8680:	9400148c 	bl	d8b0 <atexit>
    8684:	35ffd220 	cbnz	w0, 80c8 <f12+0x898>
    8688:	52800020 	mov	w0, #0x1                   	// #1
    868c:	b903c720 	str	w0, [x25, #964]
    8690:	17fffcb8 	b	7970 <f12+0x140>
    8694:	72003c3f 	tst	w1, #0xffff
    8698:	54ffaa81 	b.ne	7be8 <f12+0x3b8>  // b.any
    869c:	17fffd4e 	b	7bd4 <f12+0x3a4>
    86a0:	72003c3f 	tst	w1, #0xffff
    86a4:	54ff9340 	b.eq	790c <f12+0xdc>  // b.none
    86a8:	aa1903e0 	mov	x0, x25
    86ac:	97fff6c1 	bl	61b0 <fwp_closure_drop>
    86b0:	b5ff9474 	cbnz	x20, 793c <f12+0x10c>
    86b4:	d280001a 	mov	x26, #0x0                   	// #0
    86b8:	17fffcab 	b	7964 <f12+0x134>
    86bc:	aa1c03f3 	mov	x19, x28
    86c0:	17fffda8 	b	7d60 <f12+0x530>
    86c4:	72003c3f 	tst	w1, #0xffff
    86c8:	54ffc381 	b.ne	7f38 <f12+0x708>  // b.any
    86cc:	17fffe16 	b	7f24 <f12+0x6f4>
    86d0:	ad470402 	ldp	q2, q1, [x0, #224]
    86d4:	91038001 	add	x1, x0, #0xe0
    86d8:	4f000400 	movi	v0.4s, #0x0
    86dc:	f9008c1f 	str	xzr, [x0, #280]
    86e0:	ad010762 	stp	q2, q1, [x27, #32]
    86e4:	a9500002 	ldp	x2, x0, [x0, #256]
    86e8:	f9000f60 	str	x0, [x27, #24]
    86ec:	f9401820 	ldr	x0, [x1, #48]
    86f0:	f9002362 	str	x2, [x27, #64]
    86f4:	f9002760 	str	x0, [x27, #72]
    86f8:	ad000020 	stp	q0, q0, [x1]
    86fc:	3d800820 	str	q0, [x1, #32]
    8700:	f900183f 	str	xzr, [x1, #48]
    8704:	17fffcde 	b	7a7c <f12+0x24c>
    8708:	f940ac43 	ldr	x3, [x2, #344]
    870c:	91000463 	add	x3, x3, #0x1
    8710:	f900ac43 	str	x3, [x2, #344]
    8714:	17fffc83 	b	7920 <f12+0xf0>
    8718:	d2800005 	mov	x5, #0x0                   	// #0
    871c:	52800020 	mov	w0, #0x1                   	// #1
    8720:	17fffe62 	b	80a8 <f12+0x878>
    8724:	52800041 	mov	w1, #0x2                   	// #2
    8728:	d2800100 	mov	x0, #0x8                   	// #8
    872c:	97fff259 	bl	5090 <fwp_heap_alloc>
    8730:	aa0003f9 	mov	x25, x0
    8734:	d2800013 	mov	x19, #0x0                   	// #0
    8738:	17ffff54 	b	8488 <f12+0xc58>
    873c:	72003c3f 	tst	w1, #0xffff
    8740:	54fff660 	b.eq	860c <f12+0xddc>  // b.none
    8744:	aa1303e0 	mov	x0, x19
    8748:	17fffe25 	b	7fdc <f12+0x7ac>
    874c:	d1000761 	sub	x1, x27, #0x1
    8750:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8754:	eb00003f 	cmp	x1, x0
    8758:	54000ac8 	b.hi	88b0 <f12+0x1080>  // b.pmore
    875c:	900002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fba0>
    8760:	d2800000 	mov	x0, #0x0                   	// #0
    8764:	91118061 	add	x1, x3, #0x460
    8768:	14000005 	b	877c <f12+0xf4c>
    876c:	91000400 	add	x0, x0, #0x1
    8770:	91006021 	add	x1, x1, #0x18
    8774:	f140041f 	cmp	x0, #0x1, lsl #12
    8778:	540006e0 	b.eq	8854 <f12+0x1024>  // b.none
    877c:	f9400022 	ldr	x2, [x1]
    8780:	b5ffff62 	cbnz	x2, 876c <f12+0xf3c>
    8784:	8b000402 	add	x2, x0, x0, lsl #1
    8788:	91118063 	add	x3, x3, #0x460
    878c:	aa1b03e0 	mov	x0, x27
    8790:	d2800101 	mov	x1, #0x8                   	// #8
    8794:	8b020c62 	add	x2, x3, x2, lsl #3
    8798:	a9009be2 	stp	x2, x6, [sp, #8]
    879c:	a901a3e7 	stp	x7, x8, [sp, #24]
    87a0:	f90017e9 	str	x9, [sp, #40]
    87a4:	97ffe813 	bl	27f0 <calloc@plt>
    87a8:	a9411fe6 	ldp	x6, x7, [sp, #16]
    87ac:	aa0003e5 	mov	x5, x0
    87b0:	a94227e8 	ldp	x8, x9, [sp, #32]
    87b4:	b4fffb20 	cbz	x0, 8718 <f12+0xee8>
    87b8:	aa0003e1 	mov	x1, x0
    87bc:	d37df362 	lsl	x2, x27, #3
    87c0:	f94007e0 	ldr	x0, [sp, #8]
    87c4:	52800063 	mov	w3, #0x3                   	// #3
    87c8:	a9009be5 	stp	x5, x6, [sp, #8]
    87cc:	a901a3e7 	stp	x7, x8, [sp, #24]
    87d0:	f90017e9 	str	x9, [sp, #40]
    87d4:	97ffe9cf 	bl	2f10 <ad_raw_record>
    87d8:	a9409be5 	ldp	x5, x6, [sp, #8]
    87dc:	f9004be5 	str	x5, [sp, #144]
    87e0:	a941a3e7 	ldp	x7, x8, [sp, #24]
    87e4:	f90053fb 	str	x27, [sp, #160]
    87e8:	f94017e9 	ldr	x9, [sp, #40]
    87ec:	17fffd75 	b	7dc0 <f12+0x590>
    87f0:	f94002a3 	ldr	x3, [x21]
    87f4:	b7fff983 	tbnz	x3, #63, 8724 <f12+0xef4>
    87f8:	911902e1 	add	x1, x23, #0x640
    87fc:	f94007e4 	ldr	x4, [sp, #8]
    8800:	f949d820 	ldr	x0, [x1, #5040]
    8804:	f949ec21 	ldr	x1, [x1, #5080]
    8808:	cb000080 	sub	x0, x4, x0
    880c:	eb01401f 	cmp	x0, x1, lsl #16
    8810:	54fff8a2 	b.cs	8724 <f12+0xef4>  // b.hs, b.nlast
    8814:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8818:	17fffe49 	b	813c <f12+0x90c>
    881c:	d2800d01 	mov	x1, #0x68                  	// #104
    8820:	d2800039 	mov	x25, #0x1                   	// #1
    8824:	17fffc76 	b	79fc <f12+0x1cc>
    8828:	aa1a03e0 	mov	x0, x26
    882c:	97fff059 	bl	4990 <fwp_rc_forget_slot>
    8830:	17fffcec 	b	7be0 <f12+0x3b0>
    8834:	aa1903e0 	mov	x0, x25
    8838:	97fff056 	bl	4990 <fwp_rc_forget_slot>
    883c:	17fffdbd 	b	7f30 <f12+0x700>
    8840:	aa1903e0 	mov	x0, x25
    8844:	97fff053 	bl	4990 <fwp_rc_forget_slot>
    8848:	17ffff74 	b	8618 <f12+0xde8>
    884c:	97fff00a 	bl	4874 <fwp_rc_wide_dup>
    8850:	17fffc38 	b	7930 <f12+0x100>
    8854:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    8858:	91322000 	add	x0, x0, #0xc88
    885c:	97ffeaa9 	bl	3300 <ad_raw_fail>
    8860:	d280001a 	mov	x26, #0x0                   	// #0
    8864:	17fffe95 	b	82b8 <f12+0xa88>
    8868:	d2800019 	mov	x25, #0x0                   	// #0
    886c:	d2800013 	mov	x19, #0x0                   	// #0
    8870:	17ffff06 	b	8488 <f12+0xc58>
    8874:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    8878:	9137a000 	add	x0, x0, #0xde8
    887c:	97ffebc1 	bl	3780 <fwp_trap>
    8880:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    8884:	913a0000 	add	x0, x0, #0xe80
    8888:	97ffebbe 	bl	3780 <fwp_trap>
    888c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    8890:	913e8000 	add	x0, x0, #0xfa0
    8894:	97ffebbb 	bl	3780 <fwp_trap>
    8898:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    889c:	913b8000 	add	x0, x0, #0xee0
    88a0:	97ffebb8 	bl	3780 <fwp_trap>
    88a4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    88a8:	913e4000 	add	x0, x0, #0xf90
    88ac:	97ffebb5 	bl	3780 <fwp_trap>
    88b0:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    88b4:	913dc000 	add	x0, x0, #0xf70
    88b8:	97ffea92 	bl	3300 <ad_raw_fail>
    88bc:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    88c0:	913d0000 	add	x0, x0, #0xf40
    88c4:	97ffebaf 	bl	3780 <fwp_trap>
    88c8:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    88cc:	913bc000 	add	x0, x0, #0xef0
    88d0:	97ffebac 	bl	3780 <fwp_trap>
    88d4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    88d8:	9138c000 	add	x0, x0, #0xe30
    88dc:	97ffeba9 	bl	3780 <fwp_trap>
    88e0:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    88e4:	913c4000 	add	x0, x0, #0xf10
    88e8:	97ffeba6 	bl	3780 <fwp_trap>
    88ec:	97ffe7c9 	bl	2810 <__stack_chk_fail@plt>
    88f0:	97ffe7dc 	bl	2860 <abort@plt>
    88f4:	97ffe843 	bl	2a00 <fwp_trap_overflow.constprop.0>
    88f8:	d503201f 	nop
    88fc:	d503201f 	nop

0000000000008900 <fwp_owned_entry12>:
    8900:	f9400000 	ldr	x0, [x0]
    8904:	17fffbcb 	b	7830 <f12>
    8908:	d503201f 	nop
    890c:	d503201f 	nop

0000000000008910 <e12>:
    8910:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8914:	910003fd 	mov	x29, sp
    8918:	f9000bf3 	str	x19, [sp, #16]
    891c:	f9400013 	ldr	x19, [x0]
    8920:	aa1303e0 	mov	x0, x19
    8924:	97fff440 	bl	5a24 <fwp_rc_share>
    8928:	aa1303e0 	mov	x0, x19
    892c:	97fffbc1 	bl	7830 <f12>
    8930:	aa0003f3 	mov	x19, x0
    8934:	97fff43c 	bl	5a24 <fwp_rc_share>
    8938:	aa1303e0 	mov	x0, x19
    893c:	f9400bf3 	ldr	x19, [sp, #16]
    8940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8944:	d65f03c0 	ret
    8948:	d503201f 	nop
    894c:	d503201f 	nop

0000000000008950 <fwp_write>:
    8950:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8954:	910003fd 	mov	x29, sp
    8958:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    895c:	f947f484 	ldr	x4, [x4, #4072]
    8960:	a90153f3 	stp	x19, x20, [sp, #16]
    8964:	d10943ff 	sub	sp, sp, #0x250
    8968:	b9400045 	ldr	w5, [x2]
    896c:	aa0003f4 	mov	x20, x0
    8970:	f9400080 	ldr	x0, [x4]
    8974:	f90127e0 	str	x0, [sp, #584]
    8978:	d2800000 	mov	x0, #0x0                   	// #0
    897c:	710064bf 	cmp	w5, #0x19
    8980:	54000408 	b.hi	8a00 <fwp_write+0xb0>  // b.pmore
    8984:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x720>
    8988:	aa0103f3 	mov	x19, x1
    898c:	91204000 	add	x0, x0, #0x810
    8990:	f9013bf5 	str	x21, [sp, #624]
    8994:	f9013ff6 	str	x22, [sp, #632]
    8998:	f90153fb 	str	x27, [sp, #672]
    899c:	f90157fc 	str	x28, [sp, #680]
    89a0:	aa0203fc 	mov	x28, x2
    89a4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    89a8:	10000061 	adr	x1, 89b4 <fwp_write+0x64>
    89ac:	8b20a820 	add	x0, x1, w0, sxth #2
    89b0:	d61f0000 	br	x0
    89b4:	910123e0 	add	x0, sp, #0x48
    89b8:	aa1303e5 	mov	x5, x19
    89bc:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x720>
    89c0:	aa0003f3 	mov	x19, x0
    89c4:	91000084 	add	x4, x4, #0x0
    89c8:	d2804003 	mov	x3, #0x200                 	// #512
    89cc:	aa0303e1 	mov	x1, x3
    89d0:	52800042 	mov	w2, #0x2                   	// #2
    89d4:	97ffe76b 	bl	2780 <__snprintf_chk@plt>
    89d8:	aa1303e0 	mov	x0, x19
    89dc:	97ffe731 	bl	26a0 <strlen@plt>
    89e0:	aa1303e1 	mov	x1, x19
    89e4:	aa0003e2 	mov	x2, x0
    89e8:	aa1403e0 	mov	x0, x20
    89ec:	97ffeb09 	bl	3610 <buf_put>
    89f0:	f9413bf5 	ldr	x21, [sp, #624]
    89f4:	f9413ff6 	ldr	x22, [sp, #632]
    89f8:	f94153fb 	ldr	x27, [sp, #672]
    89fc:	f94157fc 	ldr	x28, [sp, #680]
    8a00:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8a04:	f947f400 	ldr	x0, [x0, #4072]
    8a08:	f94127e2 	ldr	x2, [sp, #584]
    8a0c:	f9400001 	ldr	x1, [x0]
    8a10:	eb010042 	subs	x2, x2, x1
    8a14:	d2800001 	mov	x1, #0x0                   	// #0
    8a18:	540077c1 	b.ne	9910 <fwp_write+0xfc0>  // b.any
    8a1c:	910943ff 	add	sp, sp, #0x250
    8a20:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a24:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a28:	d65f03c0 	ret
    8a2c:	910123e0 	add	x0, sp, #0x48
    8a30:	aa1303e5 	mov	x5, x19
    8a34:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x400>
    8a38:	aa0003f3 	mov	x19, x0
    8a3c:	913fe084 	add	x4, x4, #0xff8
    8a40:	d2804003 	mov	x3, #0x200                 	// #512
    8a44:	17ffffe2 	b	89cc <fwp_write+0x7c>
    8a48:	71004cbf 	cmp	w5, #0x13
    8a4c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    8a50:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x400>
    8a54:	913fa000 	add	x0, x0, #0xfe8
    8a58:	913fc021 	add	x1, x1, #0xff0
    8a5c:	d2800082 	mov	x2, #0x4                   	// #4
    8a60:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8a64:	aa1403e0 	mov	x0, x20
    8a68:	f90143f7 	str	x23, [sp, #640]
    8a6c:	d2800016 	mov	x22, #0x0                   	// #0
    8a70:	f90147f8 	str	x24, [sp, #648]
    8a74:	97ffeae7 	bl	3610 <buf_put>
    8a78:	f9400260 	ldr	x0, [x19]
    8a7c:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x720>
    8a80:	d2800015 	mov	x21, #0x0                   	// #0
    8a84:	9101c2f7 	add	x23, x23, #0x70
    8a88:	b40047a0 	cbz	x0, 937c <fwp_write+0xa2c>
    8a8c:	b9400380 	ldr	w0, [x28]
    8a90:	52800003 	mov	w3, #0x0                   	// #0
    8a94:	f9401f82 	ldr	x2, [x28, #56]
    8a98:	71004c1f 	cmp	w0, #0x13
    8a9c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8aa0:	aa1403e0 	mov	x0, x20
    8aa4:	8b010e61 	add	x1, x19, x1, lsl #3
    8aa8:	f9400421 	ldr	x1, [x1, #8]
    8aac:	97ffffa9 	bl	8950 <fwp_write>
    8ab0:	b9400380 	ldr	w0, [x28]
    8ab4:	7100481f 	cmp	w0, #0x12
    8ab8:	54004b40 	b.eq	9420 <fwp_write+0xad0>  // b.none
    8abc:	f9400260 	ldr	x0, [x19]
    8ac0:	910006b5 	add	x21, x21, #0x1
    8ac4:	91000ad6 	add	x22, x22, #0x2
    8ac8:	eb15001f 	cmp	x0, x21
    8acc:	54004589 	b.ls	937c <fwp_write+0xa2c>  // b.plast
    8ad0:	aa1703e1 	mov	x1, x23
    8ad4:	aa1403e0 	mov	x0, x20
    8ad8:	d2800042 	mov	x2, #0x2                   	// #2
    8adc:	97ffeacd 	bl	3610 <buf_put>
    8ae0:	17ffffeb 	b	8a8c <fwp_write+0x13c>
    8ae4:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    8ae8:	9100a021 	add	x1, x1, #0x28
    8aec:	d28000c2 	mov	x2, #0x6                   	// #6
    8af0:	aa1403e0 	mov	x0, x20
    8af4:	91004273 	add	x19, x19, #0x10
    8af8:	97ffeac6 	bl	3610 <buf_put>
    8afc:	aa1303e0 	mov	x0, x19
    8b00:	97ffe6e8 	bl	26a0 <strlen@plt>
    8b04:	aa1303e1 	mov	x1, x19
    8b08:	aa0003e2 	mov	x2, x0
    8b0c:	aa1403e0 	mov	x0, x20
    8b10:	97ffeac0 	bl	3610 <buf_put>
    8b14:	528007c3 	mov	w3, #0x3e                  	// #62
    8b18:	aa1403e0 	mov	x0, x20
    8b1c:	91001fe1 	add	x1, sp, #0x7
    8b20:	d2800022 	mov	x2, #0x1                   	// #1
    8b24:	39001fe3 	strb	w3, [sp, #7]
    8b28:	17ffffb1 	b	89ec <fwp_write+0x9c>
    8b2c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8b30:	f947f400 	ldr	x0, [x0, #4072]
    8b34:	f94127e2 	ldr	x2, [sp, #584]
    8b38:	f9400001 	ldr	x1, [x0]
    8b3c:	eb010042 	subs	x2, x2, x1
    8b40:	d2800001 	mov	x1, #0x0                   	// #0
    8b44:	540034e1 	b.ne	91e0 <fwp_write+0x890>  // b.any
    8b48:	f9413bf5 	ldr	x21, [sp, #624]
    8b4c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    8b50:	f9413ff6 	ldr	x22, [sp, #632]
    8b54:	aa1403e0 	mov	x0, x20
    8b58:	91002021 	add	x1, x1, #0x8
    8b5c:	d2800142 	mov	x2, #0xa                   	// #10
    8b60:	f94153fb 	ldr	x27, [sp, #672]
    8b64:	f94157fc 	ldr	x28, [sp, #680]
    8b68:	910943ff 	add	sp, sp, #0x250
    8b6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b70:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b74:	17ffeaa7 	b	3610 <buf_put>
    8b78:	f9400456 	ldr	x22, [x2, #8]
    8b7c:	f90143f7 	str	x23, [sp, #640]
    8b80:	f90147f8 	str	x24, [sp, #648]
    8b84:	b4005b16 	cbz	x22, 96e4 <fwp_write+0xd94>
    8b88:	aa1603e0 	mov	x0, x22
    8b8c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    8b90:	91022021 	add	x1, x1, #0x88
    8b94:	97ffe73f 	bl	2890 <strcmp@plt>
    8b98:	2a0003f5 	mov	w21, w0
    8b9c:	34005fe0 	cbz	w0, 9798 <fwp_write+0xe48>
    8ba0:	aa1603e0 	mov	x0, x22
    8ba4:	97ffe6bf 	bl	26a0 <strlen@plt>
    8ba8:	aa1603e1 	mov	x1, x22
    8bac:	aa0003e2 	mov	x2, x0
    8bb0:	aa1403e0 	mov	x0, x20
    8bb4:	97ffea97 	bl	3610 <buf_put>
    8bb8:	52800403 	mov	w3, #0x20                  	// #32
    8bbc:	91001ff5 	add	x21, sp, #0x7
    8bc0:	aa1503e1 	mov	x1, x21
    8bc4:	aa1403e0 	mov	x0, x20
    8bc8:	d2800022 	mov	x2, #0x1                   	// #1
    8bcc:	39001fe3 	strb	w3, [sp, #7]
    8bd0:	97ffea90 	bl	3610 <buf_put>
    8bd4:	52800f63 	mov	w3, #0x7b                  	// #123
    8bd8:	aa1403e0 	mov	x0, x20
    8bdc:	aa1503e1 	mov	x1, x21
    8be0:	d2800022 	mov	x2, #0x1                   	// #1
    8be4:	39001fe3 	strb	w3, [sp, #7]
    8be8:	97ffea8a 	bl	3610 <buf_put>
    8bec:	b9401380 	ldr	w0, [x28, #16]
    8bf0:	52800018 	mov	w24, #0x0                   	// #0
    8bf4:	7100001f 	cmp	w0, #0x0
    8bf8:	54003aad 	b.le	934c <fwp_write+0x9fc>
    8bfc:	f9014bf9 	str	x25, [sp, #656]
    8c00:	d0000039 	adrp	x25, e000 <_IO_stdin_used+0x720>
    8c04:	9102c339 	add	x25, x25, #0xb0
    8c08:	f9014ffa 	str	x26, [sp, #664]
    8c0c:	d000003a 	adrp	x26, e000 <_IO_stdin_used+0x720>
    8c10:	9101c35a 	add	x26, x26, #0x70
    8c14:	91002276 	add	x22, x19, #0x8
    8c18:	d2800013 	mov	x19, #0x0                   	// #0
    8c1c:	b5003e93 	cbnz	x19, 93ec <fwp_write+0xa9c>
    8c20:	d37df277 	lsl	x23, x19, #3
    8c24:	34003cb8 	cbz	w24, 93b8 <fwp_write+0xa68>
    8c28:	f9401382 	ldr	x2, [x28, #32]
    8c2c:	aa1403e0 	mov	x0, x20
    8c30:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8c34:	52800003 	mov	w3, #0x0                   	// #0
    8c38:	f8776842 	ldr	x2, [x2, x23]
    8c3c:	91000673 	add	x19, x19, #0x1
    8c40:	97ffff44 	bl	8950 <fwp_write>
    8c44:	b9401380 	ldr	w0, [x28, #16]
    8c48:	6b13001f 	cmp	w0, w19
    8c4c:	54fffe8c 	b.gt	8c1c <fwp_write+0x2cc>
    8c50:	f9414bf9 	ldr	x25, [sp, #656]
    8c54:	f9414ffa 	ldr	x26, [sp, #664]
    8c58:	340037b8 	cbz	w24, 934c <fwp_write+0x9fc>
    8c5c:	52800523 	mov	w3, #0x29                  	// #41
    8c60:	aa1503e1 	mov	x1, x21
    8c64:	aa1403e0 	mov	x0, x20
    8c68:	d2800022 	mov	x2, #0x1                   	// #1
    8c6c:	39001fe3 	strb	w3, [sp, #7]
    8c70:	97ffea68 	bl	3610 <buf_put>
    8c74:	f9413bf5 	ldr	x21, [sp, #624]
    8c78:	f9413ff6 	ldr	x22, [sp, #632]
    8c7c:	f94143f7 	ldr	x23, [sp, #640]
    8c80:	f94147f8 	ldr	x24, [sp, #648]
    8c84:	f94153fb 	ldr	x27, [sp, #672]
    8c88:	f94157fc 	ldr	x28, [sp, #680]
    8c8c:	17ffff5d 	b	8a00 <fwp_write+0xb0>
    8c90:	b9404855 	ldr	w21, [x2, #72]
    8c94:	aa1403e0 	mov	x0, x20
    8c98:	93407eb6 	sxtw	x22, w21
    8c9c:	91000ac1 	add	x1, x22, #0x2
    8ca0:	97ffea28 	bl	3540 <buf_grow>
    8ca4:	a9400281 	ldp	x1, x0, [x20]
    8ca8:	528e8603 	mov	w3, #0x7430                	// #29744
    8cac:	78206823 	strh	w3, [x1, x0]
    8cb0:	8b000022 	add	x2, x1, x0
    8cb4:	710002bf 	cmp	w21, #0x0
    8cb8:	540036cd 	b.le	9390 <fwp_write+0xa40>
    8cbc:	110006a3 	add	w3, w21, #0x1
    8cc0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8cc4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8cc8:	91000449 	add	x9, x2, #0x1
    8ccc:	8b23c043 	add	x3, x2, w3, sxtw
    8cd0:	f28aaac6 	movk	x6, #0x5556
    8cd4:	f2955568 	movk	x8, #0xaaab
    8cd8:	1400000d 	b	8d0c <fwp_write+0x3bc>
    8cdc:	d2800021 	mov	x1, #0x1                   	// #1
    8ce0:	528005a5 	mov	w5, #0x2d                  	// #45
    8ce4:	f100001f 	cmp	x0, #0x0
    8ce8:	9b467e60 	smulh	x0, x19, x6
    8cec:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8cf0:	381ff465 	strb	w5, [x3], #-1
    8cf4:	cb040000 	sub	x0, x0, x4
    8cf8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8cfc:	cb020000 	sub	x0, x0, x2
    8d00:	8b010013 	add	x19, x0, x1
    8d04:	eb03013f 	cmp	x9, x3
    8d08:	54003440 	b.eq	9390 <fwp_write+0xa40>  // b.none
    8d0c:	9b467e60 	smulh	x0, x19, x6
    8d10:	937ffe64 	asr	x4, x19, #63
    8d14:	52800605 	mov	w5, #0x30                  	// #48
    8d18:	cb040000 	sub	x0, x0, x4
    8d1c:	8b000400 	add	x0, x0, x0, lsl #1
    8d20:	cb000260 	sub	x0, x19, x0
    8d24:	91000c01 	add	x1, x0, #0x3
    8d28:	9bc87c22 	umulh	x2, x1, x8
    8d2c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8d30:	8b4204e2 	add	x2, x7, x2, lsr #1
    8d34:	eb020021 	subs	x1, x1, x2
    8d38:	54fffd60 	b.eq	8ce4 <fwp_write+0x394>  // b.none
    8d3c:	f100043f 	cmp	x1, #0x1
    8d40:	54fffce1 	b.ne	8cdc <fwp_write+0x38c>  // b.any
    8d44:	d2800001 	mov	x1, #0x0                   	// #0
    8d48:	52800565 	mov	w5, #0x2b                  	// #43
    8d4c:	17ffffe6 	b	8ce4 <fwp_write+0x394>
    8d50:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8d54:	f947f400 	ldr	x0, [x0, #4072]
    8d58:	f94127e2 	ldr	x2, [sp, #584]
    8d5c:	f9400001 	ldr	x1, [x0]
    8d60:	eb010042 	subs	x2, x2, x1
    8d64:	d2800001 	mov	x1, #0x0                   	// #0
    8d68:	540023c1 	b.ne	91e0 <fwp_write+0x890>  // b.any
    8d6c:	f9413bf5 	ldr	x21, [sp, #624]
    8d70:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    8d74:	f9413ff6 	ldr	x22, [sp, #632]
    8d78:	aa1403e0 	mov	x0, x20
    8d7c:	91006021 	add	x1, x1, #0x18
    8d80:	d2800102 	mov	x2, #0x8                   	// #8
    8d84:	17ffff77 	b	8b60 <fwp_write+0x210>
    8d88:	aa1403e0 	mov	x0, x20
    8d8c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    8d90:	d28000c2 	mov	x2, #0x6                   	// #6
    8d94:	9101e021 	add	x1, x1, #0x78
    8d98:	97ffea1e 	bl	3610 <buf_put>
    8d9c:	d2800015 	mov	x21, #0x0                   	// #0
    8da0:	f9400263 	ldr	x3, [x19]
    8da4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8da8:	54002c60 	b.eq	9334 <fwp_write+0x9e4>  // b.none
    8dac:	f9401f82 	ldr	x2, [x28, #56]
    8db0:	f90143f7 	str	x23, [sp, #640]
    8db4:	f90147f8 	str	x24, [sp, #648]
    8db8:	d2800857 	mov	x23, #0x42                  	// #66
    8dbc:	f9014bf9 	str	x25, [sp, #656]
    8dc0:	d0000036 	adrp	x22, e000 <_IO_stdin_used+0x720>
    8dc4:	f9014ffa 	str	x26, [sp, #664]
    8dc8:	9101c2d6 	add	x22, x22, #0x70
    8dcc:	d2800038 	mov	x24, #0x1                   	// #1
    8dd0:	f2a18017 	movk	x23, #0xc00, lsl #16
    8dd4:	d2809099 	mov	x25, #0x484                 	// #1156
    8dd8:	b40004a2 	cbz	x2, 8e6c <fwp_write+0x51c>
    8ddc:	b9400040 	ldr	w0, [x2]
    8de0:	7100701f 	cmp	w0, #0x1c
    8de4:	540042c0 	b.eq	963c <fwp_write+0xcec>  // b.none
    8de8:	71006c1f 	cmp	w0, #0x1b
    8dec:	54000408 	b.hi	8e6c <fwp_write+0x51c>  // b.pmore
    8df0:	9ac02301 	lsl	x1, x24, x0
    8df4:	ea17003f 	tst	x1, x23
    8df8:	540036a1 	b.ne	94cc <fwp_write+0xb7c>  // b.any
    8dfc:	ea19003f 	tst	x1, x25
    8e00:	54003521 	b.ne	94a4 <fwp_write+0xb54>  // b.any
    8e04:	d2800424 	mov	x4, #0x21                  	// #33
    8e08:	ea04003f 	tst	x1, x4
    8e0c:	54000300 	b.eq	8e6c <fwp_write+0x51c>  // b.none
    8e10:	b7f849c3 	tbnz	x3, #63, 9748 <fwp_write+0xdf8>
    8e14:	91002261 	add	x1, x19, #0x8
    8e18:	8b150021 	add	x1, x1, x21
    8e1c:	39400021 	ldrb	w1, [x1]
    8e20:	7100001f 	cmp	w0, #0x0
    8e24:	93401c23 	sxtb	x3, w1
    8e28:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e2c:	d503201f 	nop
    8e30:	aa1403e0 	mov	x0, x20
    8e34:	52800003 	mov	w3, #0x0                   	// #0
    8e38:	97fffec6 	bl	8950 <fwp_write>
    8e3c:	910006b5 	add	x21, x21, #0x1
    8e40:	f9400260 	ldr	x0, [x19]
    8e44:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8e48:	eb0002bf 	cmp	x21, x0
    8e4c:	540026c2 	b.cs	9324 <fwp_write+0x9d4>  // b.hs, b.nlast
    8e50:	d2800042 	mov	x2, #0x2                   	// #2
    8e54:	aa1603e1 	mov	x1, x22
    8e58:	aa1403e0 	mov	x0, x20
    8e5c:	97ffe9ed 	bl	3610 <buf_put>
    8e60:	f9401f82 	ldr	x2, [x28, #56]
    8e64:	f9400263 	ldr	x3, [x19]
    8e68:	b5fffba2 	cbnz	x2, 8ddc <fwp_write+0x48c>
    8e6c:	d37df2a0 	lsl	x0, x21, #3
    8e70:	b7f83f03 	tbnz	x3, #63, 9650 <fwp_write+0xd00>
    8e74:	91002261 	add	x1, x19, #0x8
    8e78:	8b000020 	add	x0, x1, x0
    8e7c:	f9400001 	ldr	x1, [x0]
    8e80:	17ffffec 	b	8e30 <fwp_write+0x4e0>
    8e84:	a9400e62 	ldp	x2, x3, [x19]
    8e88:	b7f83ca3 	tbnz	x3, #63, 961c <fwp_write+0xccc>
    8e8c:	910123f5 	add	x21, sp, #0x48
    8e90:	aa1503e0 	mov	x0, x21
    8e94:	97ffe7c3 	bl	2da0 <fwp_fmt_u128>
    8e98:	aa1503e0 	mov	x0, x21
    8e9c:	97ffe601 	bl	26a0 <strlen@plt>
    8ea0:	aa1503e1 	mov	x1, x21
    8ea4:	aa0003e2 	mov	x2, x0
    8ea8:	17fffed0 	b	89e8 <fwp_write+0x98>
    8eac:	fd015be8 	str	d8, [sp, #688]
    8eb0:	1e270268 	fmov	s8, w19
    8eb4:	fd015fe9 	str	d9, [sp, #696]
    8eb8:	1e282100 	fcmp	s8, s8
    8ebc:	54004d26 	b.vs	9860 <fwp_write+0xf10>
    8ec0:	1e20c101 	fabs	s1, s8
    8ec4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8ec8:	1e270000 	fmov	s0, w0
    8ecc:	1e202020 	fcmp	s1, s0
    8ed0:	54002c0d 	b.le	9450 <fwp_write+0xb00>
    8ed4:	1e202118 	fcmpe	s8, #0.0
    8ed8:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x400>
    8edc:	91296042 	add	x2, x2, #0xa58
    8ee0:	910123f5 	add	x21, sp, #0x48
    8ee4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x400>
    8ee8:	913f2021 	add	x1, x1, #0xfc8
    8eec:	aa1503e0 	mov	x0, x21
    8ef0:	9a81c041 	csel	x1, x2, x1, gt
    8ef4:	97ffe697 	bl	2950 <strcpy@plt>
    8ef8:	aa1503e0 	mov	x0, x21
    8efc:	97ffe5e9 	bl	26a0 <strlen@plt>
    8f00:	aa1503e1 	mov	x1, x21
    8f04:	aa0003e2 	mov	x2, x0
    8f08:	aa1403e0 	mov	x0, x20
    8f0c:	97ffe9c1 	bl	3610 <buf_put>
    8f10:	f9413bf5 	ldr	x21, [sp, #624]
    8f14:	f9413ff6 	ldr	x22, [sp, #632]
    8f18:	f94153fb 	ldr	x27, [sp, #672]
    8f1c:	f94157fc 	ldr	x28, [sp, #680]
    8f20:	fd415be8 	ldr	d8, [sp, #688]
    8f24:	fd415fe9 	ldr	d9, [sp, #696]
    8f28:	17fffeb6 	b	8a00 <fwp_write+0xb0>
    8f2c:	f9400276 	ldr	x22, [x19]
    8f30:	34002e03 	cbz	w3, 94f0 <fwp_write+0xba0>
    8f34:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8f38:	f947f400 	ldr	x0, [x0, #4072]
    8f3c:	f94127e2 	ldr	x2, [sp, #584]
    8f40:	f9400001 	ldr	x1, [x0]
    8f44:	eb010042 	subs	x2, x2, x1
    8f48:	d2800001 	mov	x1, #0x0                   	// #0
    8f4c:	540014a1 	b.ne	91e0 <fwp_write+0x890>  // b.any
    8f50:	aa1603e2 	mov	x2, x22
    8f54:	91002261 	add	x1, x19, #0x8
    8f58:	f9413bf5 	ldr	x21, [sp, #624]
    8f5c:	aa1403e0 	mov	x0, x20
    8f60:	f9413ff6 	ldr	x22, [sp, #632]
    8f64:	17fffeff 	b	8b60 <fwp_write+0x210>
    8f68:	fd015be8 	str	d8, [sp, #688]
    8f6c:	9e670268 	fmov	d8, x19
    8f70:	fd015fe9 	str	d9, [sp, #696]
    8f74:	1e682100 	fcmp	d8, d8
    8f78:	54004746 	b.vs	9860 <fwp_write+0xf10>
    8f7c:	1e60c101 	fabs	d1, d8
    8f80:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8f84:	9e670000 	fmov	d0, x0
    8f88:	910123f5 	add	x21, sp, #0x48
    8f8c:	52800033 	mov	w19, #0x1                   	// #1
    8f90:	1e602020 	fcmp	d1, d0
    8f94:	540001ad 	b.le	8fc8 <fwp_write+0x678>
    8f98:	1e602118 	fcmpe	d8, #0.0
    8f9c:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x400>
    8fa0:	91296042 	add	x2, x2, #0xa58
    8fa4:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x400>
    8fa8:	913f2021 	add	x1, x1, #0xfc8
    8fac:	aa1503e0 	mov	x0, x21
    8fb0:	9a81c041 	csel	x1, x2, x1, gt
    8fb4:	97ffe667 	bl	2950 <strcpy@plt>
    8fb8:	17ffffd0 	b	8ef8 <fwp_write+0x5a8>
    8fbc:	11000673 	add	w19, w19, #0x1
    8fc0:	71004a7f 	cmp	w19, #0x12
    8fc4:	54003860 	b.eq	96d0 <fwp_write+0xd80>  // b.none
    8fc8:	1e604100 	fmov	d0, d8
    8fcc:	2a1303e1 	mov	w1, w19
    8fd0:	aa1503e0 	mov	x0, x21
    8fd4:	97ffead0 	bl	3b14 <fwp_format_g.constprop.0>
    8fd8:	aa1503e0 	mov	x0, x21
    8fdc:	d2800001 	mov	x1, #0x0                   	// #0
    8fe0:	97ffe5c4 	bl	26f0 <strtod@plt>
    8fe4:	1e602100 	fcmp	d8, d0
    8fe8:	54fffea1 	b.ne	8fbc <fwp_write+0x66c>  // b.any
    8fec:	aa1503e0 	mov	x0, x21
    8ff0:	97ffe9c1 	bl	36f4 <fwp_finish_float>
    8ff4:	17ffffc1 	b	8ef8 <fwp_write+0x5a8>
    8ff8:	a9400e62 	ldp	x2, x3, [x19]
    8ffc:	910123f3 	add	x19, sp, #0x48
    9000:	aa1303e0 	mov	x0, x19
    9004:	97ffe767 	bl	2da0 <fwp_fmt_u128>
    9008:	17fffe74 	b	89d8 <fwp_write+0x88>
    900c:	f90143f7 	str	x23, [sp, #640]
    9010:	f90147f8 	str	x24, [sp, #648]
    9014:	2a1303f8 	mov	w24, w19
    9018:	f9014bf9 	str	x25, [sp, #656]
    901c:	f9014ffa 	str	x26, [sp, #664]
    9020:	f13ffe7f 	cmp	x19, #0xfff
    9024:	54000049 	b.ls	902c <fwp_write+0x6dc>  // b.plast
    9028:	b9400278 	ldr	w24, [x19]
    902c:	f9400f80 	ldr	x0, [x28, #24]
    9030:	2a1803f5 	mov	w21, w24
    9034:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9038:	d37ef6b9 	lsl	x25, x21, #2
    903c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9040:	aa1603e0 	mov	x0, x22
    9044:	97ffe597 	bl	26a0 <strlen@plt>
    9048:	aa1603e1 	mov	x1, x22
    904c:	aa0003e2 	mov	x2, x0
    9050:	aa1403e0 	mov	x0, x20
    9054:	97ffe96f 	bl	3610 <buf_put>
    9058:	f9401780 	ldr	x0, [x28, #40]
    905c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9060:	7100001f 	cmp	w0, #0x0
    9064:	5400068d 	b.le	9134 <fwp_write+0x7e4>
    9068:	91002276 	add	x22, x19, #0x8
    906c:	91001ff5 	add	x21, sp, #0x7
    9070:	d280001b 	mov	x27, #0x0                   	// #0
    9074:	5280041a 	mov	w26, #0x20                  	// #32
    9078:	f9401b80 	ldr	x0, [x28, #48]
    907c:	aa1503e1 	mov	x1, x21
    9080:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9084:	d2800022 	mov	x2, #0x1                   	// #1
    9088:	f8786803 	ldr	x3, [x0, x24]
    908c:	aa1403e0 	mov	x0, x20
    9090:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9094:	39001ffa 	strb	w26, [sp, #7]
    9098:	97ffe95e 	bl	3610 <buf_put>
    909c:	f13ffeff 	cmp	x23, #0xfff
    90a0:	b9400261 	ldr	w1, [x19]
    90a4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    90a8:	7100383f 	cmp	w1, #0xe
    90ac:	54000160 	b.eq	90d8 <fwp_write+0x788>  // b.none
    90b0:	7100403f 	cmp	w1, #0x10
    90b4:	54001a60 	b.eq	9400 <fwp_write+0xab0>  // b.none
    90b8:	7100283f 	cmp	w1, #0xa
    90bc:	54002aa0 	b.eq	9610 <fwp_write+0xcc0>  // b.none
    90c0:	540014ac 	b.gt	9354 <fwp_write+0xa04>
    90c4:	71000c3f 	cmp	w1, #0x3
    90c8:	540029ac 	b.gt	95fc <fwp_write+0xcac>
    90cc:	d37ffee0 	lsr	x0, x23, #63
    90d0:	37f814a1 	tbnz	w1, #31, 9364 <fwp_write+0xa14>
    90d4:	d503201f 	nop
    90d8:	34001460 	cbz	w0, 9364 <fwp_write+0xa14>
    90dc:	52800503 	mov	w3, #0x28                  	// #40
    90e0:	aa1503e1 	mov	x1, x21
    90e4:	aa1403e0 	mov	x0, x20
    90e8:	d2800022 	mov	x2, #0x1                   	// #1
    90ec:	39001fe3 	strb	w3, [sp, #7]
    90f0:	97ffe948 	bl	3610 <buf_put>
    90f4:	aa1303e2 	mov	x2, x19
    90f8:	aa1703e1 	mov	x1, x23
    90fc:	aa1403e0 	mov	x0, x20
    9100:	52800003 	mov	w3, #0x0                   	// #0
    9104:	97fffe13 	bl	8950 <fwp_write>
    9108:	52800523 	mov	w3, #0x29                  	// #41
    910c:	aa1503e1 	mov	x1, x21
    9110:	aa1403e0 	mov	x0, x20
    9114:	d2800022 	mov	x2, #0x1                   	// #1
    9118:	39001fe3 	strb	w3, [sp, #7]
    911c:	97ffe93d 	bl	3610 <buf_put>
    9120:	f9401780 	ldr	x0, [x28, #40]
    9124:	9100077b 	add	x27, x27, #0x1
    9128:	b8796800 	ldr	w0, [x0, x25]
    912c:	6b1b001f 	cmp	w0, w27
    9130:	54fffa4c 	b.gt	9078 <fwp_write+0x728>
    9134:	f9413bf5 	ldr	x21, [sp, #624]
    9138:	f9413ff6 	ldr	x22, [sp, #632]
    913c:	f94143f7 	ldr	x23, [sp, #640]
    9140:	f94147f8 	ldr	x24, [sp, #648]
    9144:	f9414bf9 	ldr	x25, [sp, #656]
    9148:	f9414ffa 	ldr	x26, [sp, #664]
    914c:	f94153fb 	ldr	x27, [sp, #672]
    9150:	f94157fc 	ldr	x28, [sp, #680]
    9154:	17fffe2b 	b	8a00 <fwp_write+0xb0>
    9158:	52800783 	mov	w3, #0x3c                  	// #60
    915c:	91001ff3 	add	x19, sp, #0x7
    9160:	aa1303e1 	mov	x1, x19
    9164:	d2800022 	mov	x2, #0x1                   	// #1
    9168:	aa1403e0 	mov	x0, x20
    916c:	39001fe3 	strb	w3, [sp, #7]
    9170:	97ffe928 	bl	3610 <buf_put>
    9174:	f9400795 	ldr	x21, [x28, #8]
    9178:	aa1503e0 	mov	x0, x21
    917c:	97ffe549 	bl	26a0 <strlen@plt>
    9180:	aa1503e1 	mov	x1, x21
    9184:	aa0003e2 	mov	x2, x0
    9188:	aa1403e0 	mov	x0, x20
    918c:	97ffe921 	bl	3610 <buf_put>
    9190:	528007c3 	mov	w3, #0x3e                  	// #62
    9194:	aa1303e1 	mov	x1, x19
    9198:	aa1403e0 	mov	x0, x20
    919c:	d2800022 	mov	x2, #0x1                   	// #1
    91a0:	39001fe3 	strb	w3, [sp, #7]
    91a4:	17fffe12 	b	89ec <fwp_write+0x9c>
    91a8:	f100067f 	cmp	x19, #0x1
    91ac:	540025a0 	b.eq	9660 <fwp_write+0xd10>  // b.none
    91b0:	b100067f 	cmn	x19, #0x1
    91b4:	54002bc0 	b.eq	972c <fwp_write+0xddc>  // b.none
    91b8:	90000021 	adrp	x1, d000 <fwp_main_thread+0x400>
    91bc:	913f4021 	add	x1, x1, #0xfd0
    91c0:	d2800022 	mov	x2, #0x1                   	// #1
    91c4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    91c8:	f947f400 	ldr	x0, [x0, #4072]
    91cc:	f94127e4 	ldr	x4, [sp, #584]
    91d0:	f9400003 	ldr	x3, [x0]
    91d4:	eb030084 	subs	x4, x4, x3
    91d8:	d2800003 	mov	x3, #0x0                   	// #0
    91dc:	54ffebe0 	b.eq	8f58 <fwp_write+0x608>  // b.none
    91e0:	f90143f7 	str	x23, [sp, #640]
    91e4:	f90147f8 	str	x24, [sp, #648]
    91e8:	f9014bf9 	str	x25, [sp, #656]
    91ec:	f9014ffa 	str	x26, [sp, #664]
    91f0:	fd015be8 	str	d8, [sp, #688]
    91f4:	fd015fe9 	str	d9, [sp, #696]
    91f8:	97ffe586 	bl	2810 <__stack_chk_fail@plt>
    91fc:	52800b63 	mov	w3, #0x5b                  	// #91
    9200:	91001ff5 	add	x21, sp, #0x7
    9204:	aa1503e1 	mov	x1, x21
    9208:	aa1403e0 	mov	x0, x20
    920c:	d2800022 	mov	x2, #0x1                   	// #1
    9210:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x720>
    9214:	9101c2d6 	add	x22, x22, #0x70
    9218:	39001fe3 	strb	w3, [sp, #7]
    921c:	97ffe8fd 	bl	3610 <buf_put>
    9220:	b4000273 	cbz	x19, 926c <fwp_write+0x91c>
    9224:	f9400661 	ldr	x1, [x19, #8]
    9228:	aa1403e0 	mov	x0, x20
    922c:	f9401f82 	ldr	x2, [x28, #56]
    9230:	52800003 	mov	w3, #0x0                   	// #0
    9234:	97fffdc7 	bl	8950 <fwp_write>
    9238:	f9400a73 	ldr	x19, [x19, #16]
    923c:	b4000193 	cbz	x19, 926c <fwp_write+0x91c>
    9240:	aa1603e1 	mov	x1, x22
    9244:	aa1403e0 	mov	x0, x20
    9248:	d2800042 	mov	x2, #0x2                   	// #2
    924c:	97ffe8f1 	bl	3610 <buf_put>
    9250:	f9400661 	ldr	x1, [x19, #8]
    9254:	aa1403e0 	mov	x0, x20
    9258:	f9401f82 	ldr	x2, [x28, #56]
    925c:	52800003 	mov	w3, #0x0                   	// #0
    9260:	97fffdbc 	bl	8950 <fwp_write>
    9264:	f9400a73 	ldr	x19, [x19, #16]
    9268:	b5fffed3 	cbnz	x19, 9240 <fwp_write+0x8f0>
    926c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9270:	aa1503e1 	mov	x1, x21
    9274:	aa1403e0 	mov	x0, x20
    9278:	d2800022 	mov	x2, #0x1                   	// #1
    927c:	39001fe3 	strb	w3, [sp, #7]
    9280:	17fffddb 	b	89ec <fwp_write+0x9c>
    9284:	aa1403e0 	mov	x0, x20
    9288:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    928c:	d28000c2 	mov	x2, #0x6                   	// #6
    9290:	91018021 	add	x1, x1, #0x60
    9294:	97ffe8df 	bl	3610 <buf_put>
    9298:	f9400260 	ldr	x0, [x19]
    929c:	b40004c0 	cbz	x0, 9334 <fwp_write+0x9e4>
    92a0:	910123f5 	add	x21, sp, #0x48
    92a4:	91002276 	add	x22, x19, #0x8
    92a8:	f90143f7 	str	x23, [sp, #640]
    92ac:	d2800017 	mov	x23, #0x0                   	// #0
    92b0:	f90147f8 	str	x24, [sp, #648]
    92b4:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x720>
    92b8:	9101a318 	add	x24, x24, #0x68
    92bc:	f9014bf9 	str	x25, [sp, #656]
    92c0:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x720>
    92c4:	9101c339 	add	x25, x25, #0x70
    92c8:	f9014ffa 	str	x26, [sp, #664]
    92cc:	14000005 	b	92e0 <fwp_write+0x990>
    92d0:	aa1903e1 	mov	x1, x25
    92d4:	aa1403e0 	mov	x0, x20
    92d8:	d2800042 	mov	x2, #0x2                   	// #2
    92dc:	97ffe8cd 	bl	3610 <buf_put>
    92e0:	38776ac5 	ldrb	w5, [x22, x23]
    92e4:	d2804003 	mov	x3, #0x200                 	// #512
    92e8:	aa1803e4 	mov	x4, x24
    92ec:	aa0303e1 	mov	x1, x3
    92f0:	52800042 	mov	w2, #0x2                   	// #2
    92f4:	aa1503e0 	mov	x0, x21
    92f8:	910006f7 	add	x23, x23, #0x1
    92fc:	97ffe521 	bl	2780 <__snprintf_chk@plt>
    9300:	aa1503e0 	mov	x0, x21
    9304:	97ffe4e7 	bl	26a0 <strlen@plt>
    9308:	aa1503e1 	mov	x1, x21
    930c:	aa0003e2 	mov	x2, x0
    9310:	aa1403e0 	mov	x0, x20
    9314:	97ffe8bf 	bl	3610 <buf_put>
    9318:	f9400260 	ldr	x0, [x19]
    931c:	eb17001f 	cmp	x0, x23
    9320:	54fffd88 	b.hi	92d0 <fwp_write+0x980>  // b.pmore
    9324:	f94143f7 	ldr	x23, [sp, #640]
    9328:	f94147f8 	ldr	x24, [sp, #648]
    932c:	f9414bf9 	ldr	x25, [sp, #656]
    9330:	f9414ffa 	ldr	x26, [sp, #664]
    9334:	52800ba3 	mov	w3, #0x5d                  	// #93
    9338:	aa1403e0 	mov	x0, x20
    933c:	91001fe1 	add	x1, sp, #0x7
    9340:	d2800022 	mov	x2, #0x1                   	// #1
    9344:	39001fe3 	strb	w3, [sp, #7]
    9348:	17fffda9 	b	89ec <fwp_write+0x9c>
    934c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9350:	17fffe44 	b	8c60 <fwp_write+0x310>
    9354:	f10002ff 	cmp	x23, #0x0
    9358:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    935c:	71002c3f 	cmp	w1, #0xb
    9360:	54ffebc0 	b.eq	90d8 <fwp_write+0x788>  // b.none
    9364:	aa1303e2 	mov	x2, x19
    9368:	aa1703e1 	mov	x1, x23
    936c:	aa1403e0 	mov	x0, x20
    9370:	52800003 	mov	w3, #0x0                   	// #0
    9374:	97fffd77 	bl	8950 <fwp_write>
    9378:	17ffff6a 	b	9120 <fwp_write+0x7d0>
    937c:	aa1403e0 	mov	x0, x20
    9380:	91001fe1 	add	x1, sp, #0x7
    9384:	52800fa3 	mov	w3, #0x7d                  	// #125
    9388:	d2800022 	mov	x2, #0x1                   	// #1
    938c:	17fffe38 	b	8c6c <fwp_write+0x31c>
    9390:	a9400281 	ldp	x1, x0, [x20]
    9394:	91000800 	add	x0, x0, #0x2
    9398:	8b160000 	add	x0, x0, x22
    939c:	f9000680 	str	x0, [x20, #8]
    93a0:	3820683f 	strb	wzr, [x1, x0]
    93a4:	f9413bf5 	ldr	x21, [sp, #624]
    93a8:	f9413ff6 	ldr	x22, [sp, #632]
    93ac:	f94153fb 	ldr	x27, [sp, #672]
    93b0:	f94157fc 	ldr	x28, [sp, #680]
    93b4:	17fffd93 	b	8a00 <fwp_write+0xb0>
    93b8:	f9400f80 	ldr	x0, [x28, #24]
    93bc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    93c0:	aa1b03e0 	mov	x0, x27
    93c4:	97ffe4b7 	bl	26a0 <strlen@plt>
    93c8:	aa1b03e1 	mov	x1, x27
    93cc:	aa0003e2 	mov	x2, x0
    93d0:	aa1403e0 	mov	x0, x20
    93d4:	97ffe88f 	bl	3610 <buf_put>
    93d8:	aa1903e1 	mov	x1, x25
    93dc:	aa1403e0 	mov	x0, x20
    93e0:	d2800062 	mov	x2, #0x3                   	// #3
    93e4:	97ffe88b 	bl	3610 <buf_put>
    93e8:	17fffe10 	b	8c28 <fwp_write+0x2d8>
    93ec:	aa1a03e1 	mov	x1, x26
    93f0:	aa1403e0 	mov	x0, x20
    93f4:	d2800042 	mov	x2, #0x2                   	// #2
    93f8:	97ffe886 	bl	3610 <buf_put>
    93fc:	17fffe09 	b	8c20 <fwp_write+0x2d0>
    9400:	f9400660 	ldr	x0, [x19, #8]
    9404:	b4fffb00 	cbz	x0, 9364 <fwp_write+0xa14>
    9408:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    940c:	91022021 	add	x1, x1, #0x88
    9410:	97ffe520 	bl	2890 <strcmp@plt>
    9414:	7100001f 	cmp	w0, #0x0
    9418:	1a9f07e0 	cset	w0, ne	// ne = any
    941c:	17ffff2f 	b	90d8 <fwp_write+0x788>
    9420:	aa1403e0 	mov	x0, x20
    9424:	d2800042 	mov	x2, #0x2                   	// #2
    9428:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    942c:	91020021 	add	x1, x1, #0x80
    9430:	97ffe878 	bl	3610 <buf_put>
    9434:	91004261 	add	x1, x19, #0x10
    9438:	aa1403e0 	mov	x0, x20
    943c:	f9402382 	ldr	x2, [x28, #64]
    9440:	52800003 	mov	w3, #0x0                   	// #0
    9444:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9448:	97fffd42 	bl	8950 <fwp_write>
    944c:	17fffd9c 	b	8abc <fwp_write+0x16c>
    9450:	1e22c109 	fcvt	d9, s8
    9454:	910123f5 	add	x21, sp, #0x48
    9458:	52800033 	mov	w19, #0x1                   	// #1
    945c:	d503201f 	nop
    9460:	1e604120 	fmov	d0, d9
    9464:	2a1303e1 	mov	w1, w19
    9468:	aa1503e0 	mov	x0, x21
    946c:	97ffe9aa 	bl	3b14 <fwp_format_g.constprop.0>
    9470:	aa1503e0 	mov	x0, x21
    9474:	d2800001 	mov	x1, #0x0                   	// #0
    9478:	97ffe512 	bl	28c0 <strtof@plt>
    947c:	1e202100 	fcmp	s8, s0
    9480:	54ffdb60 	b.eq	8fec <fwp_write+0x69c>  // b.none
    9484:	11000673 	add	w19, w19, #0x1
    9488:	71002a7f 	cmp	w19, #0xa
    948c:	54fffea1 	b.ne	9460 <fwp_write+0xb10>  // b.any
    9490:	1e604120 	fmov	d0, d9
    9494:	aa1503e0 	mov	x0, x21
    9498:	52800121 	mov	w1, #0x9                   	// #9
    949c:	97ffe99e 	bl	3b14 <fwp_format_g.constprop.0>
    94a0:	17fffed3 	b	8fec <fwp_write+0x69c>
    94a4:	d37ef6a1 	lsl	x1, x21, #2
    94a8:	b7f81563 	tbnz	x3, #63, 9754 <fwp_write+0xe04>
    94ac:	91002263 	add	x3, x19, #0x8
    94b0:	8b010061 	add	x1, x3, x1
    94b4:	b9400023 	ldr	w3, [x1]
    94b8:	7100081f 	cmp	w0, #0x2
    94bc:	2a0303e1 	mov	w1, w3
    94c0:	93407c63 	sxtw	x3, w3
    94c4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    94c8:	17fffe5a 	b	8e30 <fwp_write+0x4e0>
    94cc:	d37ffaa1 	lsl	x1, x21, #1
    94d0:	b7f81363 	tbnz	x3, #63, 973c <fwp_write+0xdec>
    94d4:	91002263 	add	x3, x19, #0x8
    94d8:	8b010061 	add	x1, x3, x1
    94dc:	79400021 	ldrh	w1, [x1]
    94e0:	7100041f 	cmp	w0, #0x1
    94e4:	93403c23 	sxth	x3, w1
    94e8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    94ec:	17fffe51 	b	8e30 <fwp_write+0x4e0>
    94f0:	52800443 	mov	w3, #0x22                  	// #34
    94f4:	91001ff5 	add	x21, sp, #0x7
    94f8:	91002273 	add	x19, x19, #0x8
    94fc:	aa1503e1 	mov	x1, x21
    9500:	aa1403e0 	mov	x0, x20
    9504:	d2800022 	mov	x2, #0x1                   	// #1
    9508:	39001fe3 	strb	w3, [sp, #7]
    950c:	f90143f7 	str	x23, [sp, #640]
    9510:	8b160277 	add	x23, x19, x22
    9514:	f90147f8 	str	x24, [sp, #648]
    9518:	97ffe83e 	bl	3610 <buf_put>
    951c:	b4000696 	cbz	x22, 95ec <fwp_write+0xc9c>
    9520:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x720>
    9524:	9100c318 	add	x24, x24, #0x30
    9528:	f9014bf9 	str	x25, [sp, #656]
    952c:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x720>
    9530:	91014339 	add	x25, x25, #0x50
    9534:	f9014ffa 	str	x26, [sp, #664]
    9538:	1400000d 	b	956c <fwp_write+0xc1c>
    953c:	710024bf 	cmp	w5, #0x9
    9540:	54000460 	b.eq	95cc <fwp_write+0xc7c>  // b.none
    9544:	710028bf 	cmp	w5, #0xa
    9548:	54000a61 	b.ne	9694 <fwp_write+0xd44>  // b.any
    954c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    9550:	aa1403e0 	mov	x0, x20
    9554:	91010021 	add	x1, x1, #0x40
    9558:	d2800042 	mov	x2, #0x2                   	// #2
    955c:	97ffe82d 	bl	3610 <buf_put>
    9560:	91000673 	add	x19, x19, #0x1
    9564:	eb17027f 	cmp	x19, x23
    9568:	540003e0 	b.eq	95e4 <fwp_write+0xc94>  // b.none
    956c:	39400265 	ldrb	w5, [x19]
    9570:	710034bf 	cmp	w5, #0xd
    9574:	54000180 	b.eq	95a4 <fwp_write+0xc54>  // b.none
    9578:	54fffe29 	b.ls	953c <fwp_write+0xbec>  // b.plast
    957c:	710088bf 	cmp	w5, #0x22
    9580:	540001c0 	b.eq	95b8 <fwp_write+0xc68>  // b.none
    9584:	710170bf 	cmp	w5, #0x5c
    9588:	54000741 	b.ne	9670 <fwp_write+0xd20>  // b.any
    958c:	aa1403e0 	mov	x0, x20
    9590:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    9594:	d2800042 	mov	x2, #0x2                   	// #2
    9598:	9100e021 	add	x1, x1, #0x38
    959c:	97ffe81d 	bl	3610 <buf_put>
    95a0:	17fffff0 	b	9560 <fwp_write+0xc10>
    95a4:	aa1903e1 	mov	x1, x25
    95a8:	aa1403e0 	mov	x0, x20
    95ac:	d2800042 	mov	x2, #0x2                   	// #2
    95b0:	97ffe818 	bl	3610 <buf_put>
    95b4:	17ffffeb 	b	9560 <fwp_write+0xc10>
    95b8:	aa1803e1 	mov	x1, x24
    95bc:	aa1403e0 	mov	x0, x20
    95c0:	d2800042 	mov	x2, #0x2                   	// #2
    95c4:	97ffe813 	bl	3610 <buf_put>
    95c8:	17ffffe6 	b	9560 <fwp_write+0xc10>
    95cc:	aa1403e0 	mov	x0, x20
    95d0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    95d4:	d2800042 	mov	x2, #0x2                   	// #2
    95d8:	91012021 	add	x1, x1, #0x48
    95dc:	97ffe80d 	bl	3610 <buf_put>
    95e0:	17ffffe0 	b	9560 <fwp_write+0xc10>
    95e4:	f9414bf9 	ldr	x25, [sp, #656]
    95e8:	f9414ffa 	ldr	x26, [sp, #664]
    95ec:	aa1503e1 	mov	x1, x21
    95f0:	aa1403e0 	mov	x0, x20
    95f4:	52800443 	mov	w3, #0x22                  	// #34
    95f8:	17fffd9c 	b	8c68 <fwp_write+0x318>
    95fc:	7100103f 	cmp	w1, #0x4
    9600:	54ffeb21 	b.ne	9364 <fwp_write+0xa14>  // b.any
    9604:	f94006e0 	ldr	x0, [x23, #8]
    9608:	d37ffc00 	lsr	x0, x0, #63
    960c:	17fffeb3 	b	90d8 <fwp_write+0x788>
    9610:	710002ff 	cmp	w23, #0x0
    9614:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9618:	17fffeb0 	b	90d8 <fwp_write+0x788>
    961c:	528005a1 	mov	w1, #0x2d                  	// #45
    9620:	eb0203e2 	negs	x2, x2
    9624:	da0303e3 	ngc	x3, x3
    9628:	910127e0 	add	x0, sp, #0x49
    962c:	910123f5 	add	x21, sp, #0x48
    9630:	390123e1 	strb	w1, [sp, #72]
    9634:	97ffe5db 	bl	2da0 <fwp_fmt_u128>
    9638:	17fffe18 	b	8e98 <fwp_write+0x548>
    963c:	d37ceea1 	lsl	x1, x21, #4
    9640:	b7f810a3 	tbnz	x3, #63, 9854 <fwp_write+0xf04>
    9644:	91002260 	add	x0, x19, #0x8
    9648:	8b010001 	add	x1, x0, x1
    964c:	17fffdf9 	b	8e30 <fwp_write+0x4e0>
    9650:	f9400a61 	ldr	x1, [x19, #16]
    9654:	8b010000 	add	x0, x0, x1
    9658:	f9400001 	ldr	x1, [x0]
    965c:	17fffdf5 	b	8e30 <fwp_write+0x4e0>
    9660:	90000021 	adrp	x1, d000 <fwp_main_thread+0x400>
    9664:	d2800042 	mov	x2, #0x2                   	// #2
    9668:	913f6021 	add	x1, x1, #0xfd8
    966c:	17fffed6 	b	91c4 <fwp_write+0x874>
    9670:	7101fcbf 	cmp	w5, #0x7f
    9674:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9678:	540000e9 	b.ls	9694 <fwp_write+0xd44>  // b.plast
    967c:	aa1503e1 	mov	x1, x21
    9680:	aa1403e0 	mov	x0, x20
    9684:	d2800022 	mov	x2, #0x1                   	// #1
    9688:	39001fe5 	strb	w5, [sp, #7]
    968c:	97ffe7e1 	bl	3610 <buf_put>
    9690:	17ffffb4 	b	9560 <fwp_write+0xc10>
    9694:	d2800203 	mov	x3, #0x10                  	// #16
    9698:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x720>
    969c:	aa0303e1 	mov	x1, x3
    96a0:	91016084 	add	x4, x4, #0x58
    96a4:	910123f6 	add	x22, sp, #0x48
    96a8:	52800042 	mov	w2, #0x2                   	// #2
    96ac:	aa1603e0 	mov	x0, x22
    96b0:	97ffe434 	bl	2780 <__snprintf_chk@plt>
    96b4:	aa1603e0 	mov	x0, x22
    96b8:	97ffe3fa 	bl	26a0 <strlen@plt>
    96bc:	aa1603e1 	mov	x1, x22
    96c0:	aa0003e2 	mov	x2, x0
    96c4:	aa1403e0 	mov	x0, x20
    96c8:	97ffe7d2 	bl	3610 <buf_put>
    96cc:	17ffffa5 	b	9560 <fwp_write+0xc10>
    96d0:	1e604100 	fmov	d0, d8
    96d4:	aa1503e0 	mov	x0, x21
    96d8:	52800221 	mov	w1, #0x11                  	// #17
    96dc:	97ffe90e 	bl	3b14 <fwp_format_g.constprop.0>
    96e0:	17fffe43 	b	8fec <fwp_write+0x69c>
    96e4:	b9401040 	ldr	w0, [x2, #16]
    96e8:	350003c0 	cbnz	w0, 9760 <fwp_write+0xe10>
    96ec:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    96f0:	f947f400 	ldr	x0, [x0, #4072]
    96f4:	f94127e2 	ldr	x2, [sp, #584]
    96f8:	f9400001 	ldr	x1, [x0]
    96fc:	eb010042 	subs	x2, x2, x1
    9700:	d2800001 	mov	x1, #0x0                   	// #0
    9704:	54ffd721 	b.ne	91e8 <fwp_write+0x898>  // b.any
    9708:	f9413bf5 	ldr	x21, [sp, #624]
    970c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x720>
    9710:	f9413ff6 	ldr	x22, [sp, #632]
    9714:	aa1403e0 	mov	x0, x20
    9718:	f94143f7 	ldr	x23, [sp, #640]
    971c:	9102a021 	add	x1, x1, #0xa8
    9720:	f94147f8 	ldr	x24, [sp, #648]
    9724:	d2800042 	mov	x2, #0x2                   	// #2
    9728:	17fffd0e 	b	8b60 <fwp_write+0x210>
    972c:	90000021 	adrp	x1, d000 <fwp_main_thread+0x400>
    9730:	d2800042 	mov	x2, #0x2                   	// #2
    9734:	913f8021 	add	x1, x1, #0xfe0
    9738:	17fffea3 	b	91c4 <fwp_write+0x874>
    973c:	f9400a63 	ldr	x3, [x19, #16]
    9740:	8b030021 	add	x1, x1, x3
    9744:	17ffff66 	b	94dc <fwp_write+0xb8c>
    9748:	f9400a61 	ldr	x1, [x19, #16]
    974c:	8b0102a1 	add	x1, x21, x1
    9750:	17fffdb3 	b	8e1c <fwp_write+0x4cc>
    9754:	f9400a63 	ldr	x3, [x19, #16]
    9758:	8b030021 	add	x1, x1, x3
    975c:	17ffff56 	b	94b4 <fwp_write+0xb64>
    9760:	b9404840 	ldr	w0, [x2, #72]
    9764:	91001ff5 	add	x21, sp, #0x7
    9768:	34ffa360 	cbz	w0, 8bd4 <fwp_write+0x284>
    976c:	52800503 	mov	w3, #0x28                  	// #40
    9770:	aa1403e0 	mov	x0, x20
    9774:	aa1503e1 	mov	x1, x21
    9778:	d2800022 	mov	x2, #0x1                   	// #1
    977c:	39001fe3 	strb	w3, [sp, #7]
    9780:	97ffe7a4 	bl	3610 <buf_put>
    9784:	b9401380 	ldr	w0, [x28, #16]
    9788:	52800038 	mov	w24, #0x1                   	// #1
    978c:	7100001f 	cmp	w0, #0x0
    9790:	54ffa36c 	b.gt	8bfc <fwp_write+0x2ac>
    9794:	17fffd32 	b	8c5c <fwp_write+0x30c>
    9798:	f9014bf9 	str	x25, [sp, #656]
    979c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe260>
    97a0:	f9014ffa 	str	x26, [sp, #664]
    97a4:	f9400676 	ldr	x22, [x19, #8]
    97a8:	91104333 	add	x19, x25, #0x410
    97ac:	91002273 	add	x19, x19, #0x8
    97b0:	937ffed8 	asr	x24, x22, #63
    97b4:	aa1802c0 	orr	x0, x22, x24
    97b8:	b5000320 	cbnz	x0, 981c <fwp_write+0xecc>
    97bc:	110006b5 	add	w21, w21, #0x1
    97c0:	710016bf 	cmp	w21, #0x5
    97c4:	54ffffc1 	b.ne	97bc <fwp_write+0xe6c>  // b.any
    97c8:	b7f80578 	tbnz	x24, #63, 9874 <fwp_write+0xf24>
    97cc:	910023f3 	add	x19, sp, #0x8
    97d0:	aa1603e2 	mov	x2, x22
    97d4:	aa1303e0 	mov	x0, x19
    97d8:	d2800003 	mov	x3, #0x0                   	// #0
    97dc:	97ffe571 	bl	2da0 <fwp_fmt_u128>
    97e0:	910123f5 	add	x21, sp, #0x48
    97e4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x720>
    97e8:	aa1303e4 	mov	x4, x19
    97ec:	aa1503e0 	mov	x0, x21
    97f0:	91028063 	add	x3, x3, #0xa0
    97f4:	d2804002 	mov	x2, #0x200                 	// #512
    97f8:	52800041 	mov	w1, #0x2                   	// #2
    97fc:	97ffe3ad 	bl	26b0 <__sprintf_chk@plt>
    9800:	aa1503e0 	mov	x0, x21
    9804:	97ffe3a7 	bl	26a0 <strlen@plt>
    9808:	aa1503e1 	mov	x1, x21
    980c:	aa0003e2 	mov	x2, x0
    9810:	aa1403e0 	mov	x0, x20
    9814:	97ffe77f 	bl	3610 <buf_put>
    9818:	17fffe47 	b	9134 <fwp_write+0x7e4>
    981c:	f9400277 	ldr	x23, [x19]
    9820:	aa1603e0 	mov	x0, x22
    9824:	aa1803e1 	mov	x1, x24
    9828:	aa1703e2 	mov	x2, x23
    982c:	937ffefa 	asr	x26, x23, #63
    9830:	aa1a03e3 	mov	x3, x26
    9834:	94000f43 	bl	d540 <__modti3>
    9838:	aa010000 	orr	x0, x0, x1
    983c:	b40002c0 	cbz	x0, 9894 <fwp_write+0xf44>
    9840:	110006b5 	add	w21, w21, #0x1
    9844:	91004273 	add	x19, x19, #0x10
    9848:	710016bf 	cmp	w21, #0x5
    984c:	54fffe81 	b.ne	981c <fwp_write+0xecc>  // b.any
    9850:	17ffffde 	b	97c8 <fwp_write+0xe78>
    9854:	f9400a60 	ldr	x0, [x19, #16]
    9858:	8b000021 	add	x1, x1, x0
    985c:	17fffd75 	b	8e30 <fwp_write+0x4e0>
    9860:	528c29c0 	mov	w0, #0x614e                	// #24910
    9864:	910123f5 	add	x21, sp, #0x48
    9868:	72a009c0 	movk	w0, #0x4e, lsl #16
    986c:	b9004be0 	str	w0, [sp, #72]
    9870:	17fffda2 	b	8ef8 <fwp_write+0x5a8>
    9874:	528005a1 	mov	w1, #0x2d                  	// #45
    9878:	eb1603e2 	negs	x2, x22
    987c:	da1803e3 	ngc	x3, x24
    9880:	910027e0 	add	x0, sp, #0x9
    9884:	910023f3 	add	x19, sp, #0x8
    9888:	390023e1 	strb	w1, [sp, #8]
    988c:	97ffe545 	bl	2da0 <fwp_fmt_u128>
    9890:	17ffffd4 	b	97e0 <fwp_write+0xe90>
    9894:	aa1703e2 	mov	x2, x23
    9898:	aa1a03e3 	mov	x3, x26
    989c:	aa1603e0 	mov	x0, x22
    98a0:	aa1803e1 	mov	x1, x24
    98a4:	94000e47 	bl	d1c0 <__divti3>
    98a8:	aa0003e2 	mov	x2, x0
    98ac:	aa0103e3 	mov	x3, x1
    98b0:	b7f80201 	tbnz	x1, #63, 98f0 <fwp_write+0xfa0>
    98b4:	910023f3 	add	x19, sp, #0x8
    98b8:	aa1303e0 	mov	x0, x19
    98bc:	97ffe539 	bl	2da0 <fwp_fmt_u128>
    98c0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    98c4:	91104339 	add	x25, x25, #0x410
    98c8:	910123f5 	add	x21, sp, #0x48
    98cc:	aa1303e4 	mov	x4, x19
    98d0:	aa1503e0 	mov	x0, x21
    98d4:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x720>
    98d8:	f8616b25 	ldr	x5, [x25, x1]
    98dc:	91026063 	add	x3, x3, #0x98
    98e0:	d2804002 	mov	x2, #0x200                 	// #512
    98e4:	52800041 	mov	w1, #0x2                   	// #2
    98e8:	97ffe372 	bl	26b0 <__sprintf_chk@plt>
    98ec:	17ffffc5 	b	9800 <fwp_write+0xeb0>
    98f0:	528005a4 	mov	w4, #0x2d                  	// #45
    98f4:	eb0003e2 	negs	x2, x0
    98f8:	da0103e3 	ngc	x3, x1
    98fc:	910027e0 	add	x0, sp, #0x9
    9900:	910023f3 	add	x19, sp, #0x8
    9904:	390023e4 	strb	w4, [sp, #8]
    9908:	97ffe526 	bl	2da0 <fwp_fmt_u128>
    990c:	17ffffed 	b	98c0 <fwp_write+0xf70>
    9910:	f9013bf5 	str	x21, [sp, #624]
    9914:	f9013ff6 	str	x22, [sp, #632]
    9918:	f90143f7 	str	x23, [sp, #640]
    991c:	f90147f8 	str	x24, [sp, #648]
    9920:	f9014bf9 	str	x25, [sp, #656]
    9924:	f9014ffa 	str	x26, [sp, #664]
    9928:	f90153fb 	str	x27, [sp, #672]
    992c:	f90157fc 	str	x28, [sp, #680]
    9930:	fd015be8 	str	d8, [sp, #688]
    9934:	fd015fe9 	str	d9, [sp, #696]
    9938:	97ffe3b6 	bl	2810 <__stack_chk_fail@plt>
    993c:	d503201f 	nop

0000000000009940 <fwp_hof0.constprop.0>:
    9940:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9944:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    9948:	f947f442 	ldr	x2, [x2, #4072]
    994c:	910003fd 	mov	x29, sp
    9950:	a90153f3 	stp	x19, x20, [sp, #16]
    9954:	a9025bf5 	stp	x21, x22, [sp, #32]
    9958:	a90363f7 	stp	x23, x24, [sp, #48]
    995c:	aa0003f7 	mov	x23, x0
    9960:	a9046bf9 	stp	x25, x26, [sp, #64]
    9964:	a90573fb 	stp	x27, x28, [sp, #80]
    9968:	d10243ff 	sub	sp, sp, #0x90
    996c:	f9400040 	ldr	x0, [x2]
    9970:	f81f83a0 	stur	x0, [x29, #-8]
    9974:	d2800000 	mov	x0, #0x0                   	// #0
    9978:	b4002ee1 	cbz	x1, 9f54 <fwp_hof0.constprop.0+0x614>
    997c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9980:	9100401c 	add	x28, x0, #0x10
    9984:	9100a39c 	add	x28, x28, #0x28
    9988:	f00000a0 	adrp	x0, 20000 <__data_start>
    998c:	aa0103fa 	mov	x26, x1
    9990:	d10083b4 	sub	x20, x29, #0x20
    9994:	91018015 	add	x21, x0, #0x60
    9998:	aa1c03f8 	mov	x24, x28
    999c:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    99a0:	91190002 	add	x2, x0, #0x640
    99a4:	f949d841 	ldr	x1, [x2, #5040]
    99a8:	f949ec40 	ldr	x0, [x2, #5080]
    99ac:	cb0102e1 	sub	x1, x23, x1
    99b0:	eb00403f 	cmp	x1, x0, lsl #16
    99b4:	540003c2 	b.cs	9a2c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    99b8:	d350fc20 	lsr	x0, x1, #16
    99bc:	f949fc44 	ldr	x4, [x2, #5112]
    99c0:	8b000800 	add	x0, x0, x0, lsl #2
    99c4:	d37df002 	lsl	x2, x0, #3
    99c8:	8b020083 	add	x3, x4, x2
    99cc:	f9401060 	ldr	x0, [x3, #32]
    99d0:	b40002e0 	cbz	x0, 9a2c <fwp_hof0.constprop.0+0xec>
    99d4:	38626882 	ldrb	w2, [x4, x2]
    99d8:	7100085f 	cmp	w2, #0x2
    99dc:	54005600 	b.eq	a49c <fwp_hof0.constprop.0+0xb5c>  // b.none
    99e0:	7100045f 	cmp	w2, #0x1
    99e4:	54000241 	b.ne	9a2c <fwp_hof0.constprop.0+0xec>  // b.any
    99e8:	29430864 	ldp	w4, w2, [x3, #24]
    99ec:	92403c21 	and	x1, x1, #0xffff
    99f0:	9b047c21 	mul	x1, x1, x4
    99f4:	d360fc21 	lsr	x1, x1, #32
    99f8:	eb02003f 	cmp	x1, x2
    99fc:	54000182 	b.cs	9a2c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9a00:	8b010000 	add	x0, x0, x1
    9a04:	39400001 	ldrb	w1, [x0]
    9a08:	34000121 	cbz	w1, 9a2c <fwp_hof0.constprop.0+0xec>
    9a0c:	f00000a2 	adrp	x2, 20000 <__data_start>
    9a10:	91018042 	add	x2, x2, #0x60
    9a14:	b9413043 	ldr	w3, [x2, #304]
    9a18:	35005583 	cbnz	w3, a4c8 <fwp_hof0.constprop.0+0xb88>
    9a1c:	7103f43f 	cmp	w1, #0xfd
    9a20:	54005ae8 	b.hi	a57c <fwp_hof0.constprop.0+0xc3c>  // b.pmore
    9a24:	11000421 	add	w1, w1, #0x1
    9a28:	39000001 	strb	w1, [x0]
    9a2c:	aa1703f9 	mov	x25, x23
    9a30:	a938dfba 	stp	x26, x23, [x29, #-120]
    9a34:	aa1803fa 	mov	x26, x24
    9a38:	d28018f3 	mov	x19, #0xc7                  	// #199
    9a3c:	f81983b3 	stur	x19, [x29, #-104]
    9a40:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a44:	91004000 	add	x0, x0, #0x10
    9a48:	f9406aa3 	ldr	x3, [x21, #208]
    9a4c:	9100a005 	add	x5, x0, #0x28
    9a50:	b9402802 	ldr	w2, [x0, #40]
    9a54:	d37be842 	lsl	x2, x2, #5
    9a58:	8b02007b 	add	x27, x3, x2
    9a5c:	f9400f61 	ldr	x1, [x27, #24]
    9a60:	f81e03b9 	stur	x25, [x29, #-32]
    9a64:	b4005221 	cbz	x1, a4a8 <fwp_hof0.constprop.0+0xb68>
    9a68:	f9400c20 	ldr	x0, [x1, #24]
    9a6c:	b4004560 	cbz	x0, a318 <fwp_hof0.constprop.0+0x9d8>
    9a70:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9a74:	91190002 	add	x2, x0, #0x640
    9a78:	f949d841 	ldr	x1, [x2, #5040]
    9a7c:	f949ec40 	ldr	x0, [x2, #5080]
    9a80:	cb010341 	sub	x1, x26, x1
    9a84:	eb00403f 	cmp	x1, x0, lsl #16
    9a88:	540003e2 	b.cs	9b04 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9a8c:	d350fc20 	lsr	x0, x1, #16
    9a90:	f949fc45 	ldr	x5, [x2, #5112]
    9a94:	8b000800 	add	x0, x0, x0, lsl #2
    9a98:	d37df002 	lsl	x2, x0, #3
    9a9c:	8b0200a3 	add	x3, x5, x2
    9aa0:	f9401060 	ldr	x0, [x3, #32]
    9aa4:	b4000300 	cbz	x0, 9b04 <fwp_hof0.constprop.0+0x1c4>
    9aa8:	386268a2 	ldrb	w2, [x5, x2]
    9aac:	7100085f 	cmp	w2, #0x2
    9ab0:	540049c0 	b.eq	a3e8 <fwp_hof0.constprop.0+0xaa8>  // b.none
    9ab4:	7100045f 	cmp	w2, #0x1
    9ab8:	54000261 	b.ne	9b04 <fwp_hof0.constprop.0+0x1c4>  // b.any
    9abc:	29430865 	ldp	w5, w2, [x3, #24]
    9ac0:	92403c21 	and	x1, x1, #0xffff
    9ac4:	9b057c21 	mul	x1, x1, x5
    9ac8:	d360fc21 	lsr	x1, x1, #32
    9acc:	eb02003f 	cmp	x1, x2
    9ad0:	540001a2 	b.cs	9b04 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9ad4:	8b010000 	add	x0, x0, x1
    9ad8:	39400001 	ldrb	w1, [x0]
    9adc:	34000141 	cbz	w1, 9b04 <fwp_hof0.constprop.0+0x1c4>
    9ae0:	b94132a2 	ldr	w2, [x21, #304]
    9ae4:	34000082 	cbz	w2, 9af4 <fwp_hof0.constprop.0+0x1b4>
    9ae8:	f940aea2 	ldr	x2, [x21, #344]
    9aec:	91000442 	add	x2, x2, #0x1
    9af0:	f900aea2 	str	x2, [x21, #344]
    9af4:	7103f43f 	cmp	w1, #0xfd
    9af8:	54004c28 	b.hi	a47c <fwp_hof0.constprop.0+0xb3c>  // b.pmore
    9afc:	11000421 	add	w1, w1, #0x1
    9b00:	39000001 	strb	w1, [x0]
    9b04:	aa1a03f9 	mov	x25, x26
    9b08:	aa1a03e0 	mov	x0, x26
    9b0c:	aa1b03e3 	mov	x3, x27
    9b10:	52800037 	mov	w23, #0x1                   	// #1
    9b14:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9b18:	91190036 	add	x22, x1, #0x640
    9b1c:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    9b20:	f81b03b6 	stur	x22, [x29, #-80]
    9b24:	b81cc3b7 	stur	w23, [x29, #-52]
    9b28:	f81d03b4 	stur	x20, [x29, #-48]
    9b2c:	b9400401 	ldr	w1, [x0, #4]
    9b30:	b9400078 	ldr	w24, [x3]
    9b34:	b85cc3a0 	ldur	w0, [x29, #-52]
    9b38:	4b010318 	sub	w24, w24, w1
    9b3c:	6b17031f 	cmp	w24, w23
    9b40:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9b44:	6b0000ff 	cmp	w7, w0
    9b48:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9b4c:	b81c83a0 	stur	w0, [x29, #-56]
    9b50:	6b0000e2 	subs	w2, w7, w0
    9b54:	54000120 	b.eq	9b78 <fwp_hof0.constprop.0+0x238>  // b.none
    9b58:	f9400c63 	ldr	x3, [x3, #24]
    9b5c:	0b000021 	add	w1, w1, w0
    9b60:	f85d03a4 	ldur	x4, [x29, #-48]
    9b64:	b81d83a7 	stur	w7, [x29, #-40]
    9b68:	f9400863 	ldr	x3, [x3, #16]
    9b6c:	8b204c80 	add	x0, x4, w0, uxtw #3
    9b70:	d63f0060 	blr	x3
    9b74:	b85d83a7 	ldur	w7, [x29, #-40]
    9b78:	f9406aa0 	ldr	x0, [x21, #208]
    9b7c:	aa1903e6 	mov	x6, x25
    9b80:	b9400323 	ldr	w3, [x25]
    9b84:	2a0703f4 	mov	w20, w7
    9b88:	f85d03bb 	ldur	x27, [x29, #-48]
    9b8c:	aa1903fc 	mov	x28, x25
    9b90:	8b03141a 	add	x26, x0, x3, lsl #5
    9b94:	f9400f40 	ldr	x0, [x26, #24]
    9b98:	b4002100 	cbz	x0, 9fb8 <fwp_hof0.constprop.0+0x678>
    9b9c:	f85b03bc 	ldur	x28, [x29, #-80]
    9ba0:	29371fb7 	stp	w23, w7, [x29, #-72]
    9ba4:	aa1a03f7 	mov	x23, x26
    9ba8:	b81c03b8 	stur	w24, [x29, #-64]
    9bac:	aa1b03f8 	mov	x24, x27
    9bb0:	14000012 	b	9bf8 <fwp_hof0.constprop.0+0x2b8>
    9bb4:	f9400001 	ldr	x1, [x0]
    9bb8:	aa1803e0 	mov	x0, x24
    9bbc:	d63f0020 	blr	x1
    9bc0:	aa0003fb 	mov	x27, x0
    9bc4:	aa1903e0 	mov	x0, x25
    9bc8:	97fff17a 	bl	61b0 <fwp_closure_drop>
    9bcc:	6b13029f 	cmp	w20, w19
    9bd0:	54000cc0 	b.eq	9d68 <fwp_hof0.constprop.0+0x428>  // b.none
    9bd4:	f9406aa0 	ldr	x0, [x21, #208]
    9bd8:	8b334f18 	add	x24, x24, w19, uxtw #3
    9bdc:	b9400363 	ldr	w3, [x27]
    9be0:	4b1a02d4 	sub	w20, w22, w26
    9be4:	aa1b03e6 	mov	x6, x27
    9be8:	8b031417 	add	x23, x0, x3, lsl #5
    9bec:	f9400ee0 	ldr	x0, [x23, #24]
    9bf0:	b4001dc0 	cbz	x0, 9fa8 <fwp_hof0.constprop.0+0x668>
    9bf4:	aa1b03f9 	mov	x25, x27
    9bf8:	b94004c1 	ldr	w1, [x6, #4]
    9bfc:	b94002fa 	ldr	w26, [x23]
    9c00:	0b010296 	add	w22, w20, w1
    9c04:	6b16035f 	cmp	w26, w22
    9c08:	540024a8 	b.hi	a09c <fwp_hof0.constprop.0+0x75c>  // b.pmore
    9c0c:	7100003f 	cmp	w1, #0x0
    9c10:	4b010353 	sub	w19, w26, w1
    9c14:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9c18:	54fffce1 	b.ne	9bb4 <fwp_hof0.constprop.0+0x274>  // b.any
    9c1c:	7100035f 	cmp	w26, #0x0
    9c20:	910003e2 	mov	x2, sp
    9c24:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9c28:	f81d83a2 	stur	x2, [x29, #-40]
    9c2c:	d37df084 	lsl	x4, x4, #3
    9c30:	91003c84 	add	x4, x4, #0xf
    9c34:	92704c87 	and	x7, x4, #0xfffff0000
    9c38:	927c7c84 	and	x4, x4, #0xffffffff0
    9c3c:	cb2763e7 	sub	x7, sp, x7
    9c40:	eb2763ff 	cmp	sp, x7
    9c44:	540000a0 	b.eq	9c58 <fwp_hof0.constprop.0+0x318>  // b.none
    9c48:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9c4c:	f90203ff 	str	xzr, [sp, #1024]
    9c50:	eb2763ff 	cmp	sp, x7
    9c54:	54ffffa1 	b.ne	9c48 <fwp_hof0.constprop.0+0x308>  // b.any
    9c58:	92403c84 	and	x4, x4, #0xffff
    9c5c:	cb2463ff 	sub	sp, sp, x4
    9c60:	f90003ff 	str	xzr, [sp]
    9c64:	f110009f 	cmp	x4, #0x400
    9c68:	54000043 	b.cc	9c70 <fwp_hof0.constprop.0+0x330>  // b.lo, b.ul, b.last
    9c6c:	f90203ff 	str	xzr, [sp, #1024]
    9c70:	910043fb 	add	x27, sp, #0x10
    9c74:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9c78:	910020c9 	add	x9, x6, #0x8
    9c7c:	d2800004 	mov	x4, #0x0                   	// #0
    9c80:	340000e1 	cbz	w1, 9c9c <fwp_hof0.constprop.0+0x35c>
    9c84:	d503201f 	nop
    9c88:	f8646922 	ldr	x2, [x9, x4]
    9c8c:	f8246b62 	str	x2, [x27, x4]
    9c90:	91002084 	add	x4, x4, #0x8
    9c94:	eb04015f 	cmp	x10, x4
    9c98:	54ffff81 	b.ne	9c88 <fwp_hof0.constprop.0+0x348>  // b.any
    9c9c:	2a1303ea 	mov	w10, w19
    9ca0:	d2800004 	mov	x4, #0x0                   	// #0
    9ca4:	340000f3 	cbz	w19, 9cc0 <fwp_hof0.constprop.0+0x380>
    9ca8:	0b040022 	add	w2, w1, w4
    9cac:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9cb0:	91000484 	add	x4, x4, #0x1
    9cb4:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9cb8:	eb04015f 	cmp	x10, x4
    9cbc:	54ffff61 	b.ne	9ca8 <fwp_hof0.constprop.0+0x368>  // b.any
    9cc0:	f949db81 	ldr	x1, [x28, #5040]
    9cc4:	f949ef84 	ldr	x4, [x28, #5080]
    9cc8:	cb010321 	sub	x1, x25, x1
    9ccc:	eb04403f 	cmp	x1, x4, lsl #16
    9cd0:	540002e2 	b.cs	9d2c <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9cd4:	d350fc24 	lsr	x4, x1, #16
    9cd8:	f949ff8a 	ldr	x10, [x28, #5112]
    9cdc:	8b040884 	add	x4, x4, x4, lsl #2
    9ce0:	d37df084 	lsl	x4, x4, #3
    9ce4:	8b040149 	add	x9, x10, x4
    9ce8:	f9401128 	ldr	x8, [x9, #32]
    9cec:	b4000208 	cbz	x8, 9d2c <fwp_hof0.constprop.0+0x3ec>
    9cf0:	38646944 	ldrb	w4, [x10, x4]
    9cf4:	7100089f 	cmp	w4, #0x2
    9cf8:	54001520 	b.eq	9f9c <fwp_hof0.constprop.0+0x65c>  // b.none
    9cfc:	7100049f 	cmp	w4, #0x1
    9d00:	54000161 	b.ne	9d2c <fwp_hof0.constprop.0+0x3ec>  // b.any
    9d04:	2943112a 	ldp	w10, w4, [x9, #24]
    9d08:	92403c21 	and	x1, x1, #0xffff
    9d0c:	9b0a7c21 	mul	x1, x1, x10
    9d10:	d360fc21 	lsr	x1, x1, #32
    9d14:	eb04003f 	cmp	x1, x4
    9d18:	540000a2 	b.cs	9d2c <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9d1c:	8b010108 	add	x8, x8, x1
    9d20:	39400101 	ldrb	w1, [x8]
    9d24:	7100043f 	cmp	w1, #0x1
    9d28:	54001360 	b.eq	9f94 <fwp_hof0.constprop.0+0x654>  // b.none
    9d2c:	f9400404 	ldr	x4, [x0, #8]
    9d30:	52800021 	mov	w1, #0x1                   	// #1
    9d34:	aa1903e0 	mov	x0, x25
    9d38:	d63f0080 	blr	x4
    9d3c:	f9400ee1 	ldr	x1, [x23, #24]
    9d40:	aa1b03e0 	mov	x0, x27
    9d44:	f9400021 	ldr	x1, [x1]
    9d48:	d63f0020 	blr	x1
    9d4c:	aa0003fb 	mov	x27, x0
    9d50:	f85d83a0 	ldur	x0, [x29, #-40]
    9d54:	9100001f 	mov	sp, x0
    9d58:	aa1903e0 	mov	x0, x25
    9d5c:	97fff115 	bl	61b0 <fwp_closure_drop>
    9d60:	6b13029f 	cmp	w20, w19
    9d64:	54fff381 	b.ne	9bd4 <fwp_hof0.constprop.0+0x294>  // b.any
    9d68:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9d6c:	aa1b03f9 	mov	x25, x27
    9d70:	b85c03b8 	ldur	w24, [x29, #-64]
    9d74:	6b17031f 	cmp	w24, w23
    9d78:	540014c3 	b.cc	a010 <fwp_hof0.constprop.0+0x6d0>  // b.lo, b.ul, b.last
    9d7c:	f85983a0 	ldur	x0, [x29, #-104]
    9d80:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9d84:	f1000400 	subs	x0, x0, #0x1
    9d88:	f81983a0 	stur	x0, [x29, #-104]
    9d8c:	54ffe5a1 	b.ne	9a40 <fwp_hof0.constprop.0+0x100>  // b.any
    9d90:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe260>
    9d94:	91104042 	add	x2, x2, #0x410
    9d98:	aa1903e1 	mov	x1, x25
    9d9c:	aa1403e0 	mov	x0, x20
    9da0:	aa1a03f8 	mov	x24, x26
    9da4:	aa1903fb 	mov	x27, x25
    9da8:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9dac:	91014042 	add	x2, x2, #0x50
    9db0:	52800023 	mov	w3, #0x1                   	// #1
    9db4:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9db8:	f81f03bf 	stur	xzr, [x29, #-16]
    9dbc:	97fffae5 	bl	8950 <fwp_write>
    9dc0:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    9dc4:	90000020 	adrp	x0, d000 <fwp_main_thread+0x400>
    9dc8:	91248000 	add	x0, x0, #0x920
    9dcc:	f10002df 	cmp	x22, #0x0
    9dd0:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9dd4:	b1002b3f 	cmn	x25, #0xa
    9dd8:	54003cc8 	b.hi	a570 <fwp_hof0.constprop.0+0xc30>  // b.pmore
    9ddc:	91002720 	add	x0, x25, #0x9
    9de0:	52800021 	mov	w1, #0x1                   	// #1
    9de4:	97ffecab 	bl	5090 <fwp_heap_alloc>
    9de8:	aa0003f3 	mov	x19, x0
    9dec:	aa1603e1 	mov	x1, x22
    9df0:	aa0003f6 	mov	x22, x0
    9df4:	aa1903e2 	mov	x2, x25
    9df8:	f80086d9 	str	x25, [x22], #8
    9dfc:	8b190279 	add	x25, x19, x25
    9e00:	aa1603e0 	mov	x0, x22
    9e04:	97ffe217 	bl	2660 <memcpy@plt>
    9e08:	3900233f 	strb	wzr, [x25, #8]
    9e0c:	f85e03a0 	ldur	x0, [x29, #-32]
    9e10:	97ffe2b0 	bl	28d0 <free@plt>
    9e14:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9e18:	91190002 	add	x2, x0, #0x640
    9e1c:	f949d841 	ldr	x1, [x2, #5040]
    9e20:	f949ec40 	ldr	x0, [x2, #5080]
    9e24:	cb010261 	sub	x1, x19, x1
    9e28:	eb00403f 	cmp	x1, x0, lsl #16
    9e2c:	54000322 	b.cs	9e90 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9e30:	d350fc20 	lsr	x0, x1, #16
    9e34:	f949fc43 	ldr	x3, [x2, #5112]
    9e38:	8b000800 	add	x0, x0, x0, lsl #2
    9e3c:	d37df002 	lsl	x2, x0, #3
    9e40:	8b020060 	add	x0, x3, x2
    9e44:	f9401019 	ldr	x25, [x0, #32]
    9e48:	b4000259 	cbz	x25, 9e90 <fwp_hof0.constprop.0+0x550>
    9e4c:	38626862 	ldrb	w2, [x3, x2]
    9e50:	7100085f 	cmp	w2, #0x2
    9e54:	54003520 	b.eq	a4f8 <fwp_hof0.constprop.0+0xbb8>  // b.none
    9e58:	7100045f 	cmp	w2, #0x1
    9e5c:	540001a1 	b.ne	9e90 <fwp_hof0.constprop.0+0x550>  // b.any
    9e60:	29430002 	ldp	w2, w0, [x0, #24]
    9e64:	92403c21 	and	x1, x1, #0xffff
    9e68:	9b027c21 	mul	x1, x1, x2
    9e6c:	d360fc21 	lsr	x1, x1, #32
    9e70:	eb00003f 	cmp	x1, x0
    9e74:	540000e2 	b.cs	9e90 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9e78:	8b010339 	add	x25, x25, x1
    9e7c:	39400320 	ldrb	w0, [x25]
    9e80:	7103fc1f 	cmp	w0, #0xff
    9e84:	54003820 	b.eq	a588 <fwp_hof0.constprop.0+0xc48>  // b.none
    9e88:	52800020 	mov	w0, #0x1                   	// #1
    9e8c:	39000320 	strb	w0, [x25]
    9e90:	aa1b03e0 	mov	x0, x27
    9e94:	97fff06b 	bl	6040 <fwp_drop0>
    9e98:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e9c:	91018003 	add	x3, x0, #0x60
    9ea0:	f9400262 	ldr	x2, [x19]
    9ea4:	aa1603e0 	mov	x0, x22
    9ea8:	aa0303f6 	mov	x22, x3
    9eac:	d2800021 	mov	x1, #0x1                   	// #1
    9eb0:	f9404863 	ldr	x3, [x3, #144]
    9eb4:	97ffe297 	bl	2910 <fwrite@plt>
    9eb8:	f9404ac1 	ldr	x1, [x22, #144]
    9ebc:	52800140 	mov	w0, #0xa                   	// #10
    9ec0:	97ffe21c 	bl	2730 <fputc@plt>
    9ec4:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9ec8:	91190002 	add	x2, x0, #0x640
    9ecc:	f949d841 	ldr	x1, [x2, #5040]
    9ed0:	f949ec40 	ldr	x0, [x2, #5080]
    9ed4:	cb010261 	sub	x1, x19, x1
    9ed8:	eb00403f 	cmp	x1, x0, lsl #16
    9edc:	54000382 	b.cs	9f4c <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    9ee0:	d350fc20 	lsr	x0, x1, #16
    9ee4:	f949fc43 	ldr	x3, [x2, #5112]
    9ee8:	8b000800 	add	x0, x0, x0, lsl #2
    9eec:	d37df000 	lsl	x0, x0, #3
    9ef0:	8b000062 	add	x2, x3, x0
    9ef4:	f9401056 	ldr	x22, [x2, #32]
    9ef8:	b40002b6 	cbz	x22, 9f4c <fwp_hof0.constprop.0+0x60c>
    9efc:	38606860 	ldrb	w0, [x3, x0]
    9f00:	7100081f 	cmp	w0, #0x2
    9f04:	54002f40 	b.eq	a4ec <fwp_hof0.constprop.0+0xbac>  // b.none
    9f08:	7100041f 	cmp	w0, #0x1
    9f0c:	54000201 	b.ne	9f4c <fwp_hof0.constprop.0+0x60c>  // b.any
    9f10:	29430043 	ldp	w3, w0, [x2, #24]
    9f14:	92403c21 	and	x1, x1, #0xffff
    9f18:	9b037c21 	mul	x1, x1, x3
    9f1c:	d360fc21 	lsr	x1, x1, #32
    9f20:	eb00003f 	cmp	x1, x0
    9f24:	54000142 	b.cs	9f4c <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    9f28:	8b0102d6 	add	x22, x22, x1
    9f2c:	394002c0 	ldrb	w0, [x22]
    9f30:	340000e0 	cbz	w0, 9f4c <fwp_hof0.constprop.0+0x60c>
    9f34:	7100041f 	cmp	w0, #0x1
    9f38:	54002d00 	b.eq	a4d8 <fwp_hof0.constprop.0+0xb98>  // b.none
    9f3c:	7103fc1f 	cmp	w0, #0xff
    9f40:	54002e20 	b.eq	a504 <fwp_hof0.constprop.0+0xbc4>  // b.none
    9f44:	51000400 	sub	w0, w0, #0x1
    9f48:	390002c0 	strb	w0, [x22]
    9f4c:	f9400b5a 	ldr	x26, [x26, #16]
    9f50:	b5ffd27a 	cbnz	x26, 999c <fwp_hof0.constprop.0+0x5c>
    9f54:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9f58:	f947f400 	ldr	x0, [x0, #4072]
    9f5c:	f85f83a2 	ldur	x2, [x29, #-8]
    9f60:	f9400001 	ldr	x1, [x0]
    9f64:	eb010042 	subs	x2, x2, x1
    9f68:	d2800001 	mov	x1, #0x0                   	// #0
    9f6c:	540030c1 	b.ne	a584 <fwp_hof0.constprop.0+0xc44>  // b.any
    9f70:	910003bf 	mov	sp, x29
    9f74:	d2800000 	mov	x0, #0x0                   	// #0
    9f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    9f7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9f80:	a94363f7 	ldp	x23, x24, [sp, #48]
    9f84:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9f88:	a94573fb 	ldp	x27, x28, [sp, #80]
    9f8c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9f90:	d65f03c0 	ret
    9f94:	b90004df 	str	wzr, [x6, #4]
    9f98:	17ffff69 	b	9d3c <fwp_hof0.constprop.0+0x3fc>
    9f9c:	72003c3f 	tst	w1, #0xffff
    9fa0:	54ffec61 	b.ne	9d2c <fwp_hof0.constprop.0+0x3ec>  // b.any
    9fa4:	17ffff5f 	b	9d20 <fwp_hof0.constprop.0+0x3e0>
    9fa8:	aa1b03fc 	mov	x28, x27
    9fac:	aa1803fb 	mov	x27, x24
    9fb0:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9fb4:	b85c03b8 	ldur	w24, [x29, #-64]
    9fb8:	aa1c03e0 	mov	x0, x28
    9fbc:	b81d83a7 	stur	w7, [x29, #-40]
    9fc0:	97ffee99 	bl	5a24 <fwp_rc_share>
    9fc4:	b85d83a7 	ldur	w7, [x29, #-40]
    9fc8:	34000134 	cbz	w20, 9fec <fwp_hof0.constprop.0+0x6ac>
    9fcc:	aa1b03f6 	mov	x22, x27
    9fd0:	8b344f73 	add	x19, x27, w20, uxtw #3
    9fd4:	2a0703f9 	mov	w25, w7
    9fd8:	f84086c0 	ldr	x0, [x22], #8
    9fdc:	97ffee92 	bl	5a24 <fwp_rc_share>
    9fe0:	eb16027f 	cmp	x19, x22
    9fe4:	54ffffa1 	b.ne	9fd8 <fwp_hof0.constprop.0+0x698>  // b.any
    9fe8:	2a1903e7 	mov	w7, w25
    9fec:	aa1b03e2 	mov	x2, x27
    9ff0:	2a1403e1 	mov	w1, w20
    9ff4:	aa1c03e0 	mov	x0, x28
    9ff8:	b81d83a7 	stur	w7, [x29, #-40]
    9ffc:	97ffec86 	bl	5214 <fwp_apply>
    a000:	aa0003f9 	mov	x25, x0
    a004:	b85d83a7 	ldur	w7, [x29, #-40]
    a008:	6b17031f 	cmp	w24, w23
    a00c:	54ffeb82 	b.cs	9d7c <fwp_hof0.constprop.0+0x43c>  // b.hs, b.nlast
    a010:	f9406aa1 	ldr	x1, [x21, #208]
    a014:	4b0702f7 	sub	w23, w23, w7
    a018:	b9400323 	ldr	w3, [x25]
    a01c:	f85d03a0 	ldur	x0, [x29, #-48]
    a020:	8b031423 	add	x3, x1, x3, lsl #5
    a024:	b85c83a2 	ldur	w2, [x29, #-56]
    a028:	8b274c00 	add	x0, x0, w7, uxtw #3
    a02c:	f81d03a0 	stur	x0, [x29, #-48]
    a030:	f9400c61 	ldr	x1, [x3, #24]
    a034:	b85cc3a0 	ldur	w0, [x29, #-52]
    a038:	4b020000 	sub	w0, w0, w2
    a03c:	b81cc3a0 	stur	w0, [x29, #-52]
    a040:	aa1903e0 	mov	x0, x25
    a044:	b5ffd741 	cbnz	x1, 9b2c <fwp_hof0.constprop.0+0x1ec>
    a048:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    a04c:	aa1903e0 	mov	x0, x25
    a050:	97ffee75 	bl	5a24 <fwp_rc_share>
    a054:	34000117 	cbz	w23, a074 <fwp_hof0.constprop.0+0x734>
    a058:	f85d03b8 	ldur	x24, [x29, #-48]
    a05c:	d2800016 	mov	x22, #0x0                   	// #0
    a060:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    a064:	910006d6 	add	x22, x22, #0x1
    a068:	97ffee6f 	bl	5a24 <fwp_rc_share>
    a06c:	6b1602ff 	cmp	w23, w22
    a070:	54ffff88 	b.hi	a060 <fwp_hof0.constprop.0+0x720>  // b.pmore
    a074:	f85d03a2 	ldur	x2, [x29, #-48]
    a078:	aa1903e0 	mov	x0, x25
    a07c:	2a1703e1 	mov	w1, w23
    a080:	97ffec65 	bl	5214 <fwp_apply>
    a084:	aa0003f9 	mov	x25, x0
    a088:	f85983a0 	ldur	x0, [x29, #-104]
    a08c:	f1000400 	subs	x0, x0, #0x1
    a090:	f81983a0 	stur	x0, [x29, #-104]
    a094:	54ffcd61 	b.ne	9a40 <fwp_hof0.constprop.0+0x100>  // b.any
    a098:	17ffff3e 	b	9d90 <fwp_hof0.constprop.0+0x450>
    a09c:	b94132ab 	ldr	w11, [x21, #304]
    a0a0:	110006c0 	add	w0, w22, #0x1
    a0a4:	aa1703fa 	mov	x26, x23
    a0a8:	aa1803fb 	mov	x27, x24
    a0ac:	29771fb7 	ldp	w23, w7, [x29, #-72]
    a0b0:	2a0103fc 	mov	w28, w1
    a0b4:	b85c03b8 	ldur	w24, [x29, #-64]
    a0b8:	d37df000 	lsl	x0, x0, #3
    a0bc:	340000ab 	cbz	w11, a0d0 <fwp_hof0.constprop.0+0x790>
    a0c0:	a95386a9 	ldp	x9, x1, [x21, #312]
    a0c4:	91000529 	add	x9, x9, #0x1
    a0c8:	8b000021 	add	x1, x1, x0
    a0cc:	a91386a9 	stp	x9, x1, [x21, #312]
    a0d0:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a0d4:	9119002a 	add	x10, x1, #0x640
    a0d8:	f140101f 	cmp	x0, #0x4, lsl #12
    a0dc:	b953a541 	ldr	w1, [x10, #5028]
    a0e0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a0e4:	540019a0 	b.eq	a418 <fwp_hof0.constprop.0+0xad8>  // b.none
    a0e8:	91003c01 	add	x1, x0, #0xf
    a0ec:	8b411141 	add	x1, x10, x1, lsr #4
    a0f0:	397e8021 	ldrb	w1, [x1, #4000]
    a0f4:	910f002c 	add	x12, x1, #0x3c0
    a0f8:	8b010429 	add	x9, x1, x1, lsl #1
    a0fc:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a100:	8b090d4d 	add	x13, x10, x9, lsl #3
    a104:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    a108:	2a0c03e1 	mov	w1, w12
    a10c:	b4001753 	cbz	x19, a3f4 <fwp_hof0.constprop.0+0xab4>
    a110:	f940026d 	ldr	x13, [x19]
    a114:	aa2d03ed 	mvn	x13, x13
    a118:	f829794d 	str	x13, [x10, x9, lsl #3]
    a11c:	eb01001f 	cmp	x0, x1
    a120:	540000c2 	b.cs	a138 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    a124:	d503201f 	nop
    a128:	f8206a7f 	str	xzr, [x19, x0]
    a12c:	91002000 	add	x0, x0, #0x8
    a130:	eb00003f 	cmp	x1, x0
    a134:	54ffffa8 	b.hi	a128 <fwp_hof0.constprop.0+0x7e8>  // b.pmore
    a138:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a13c:	91190009 	add	x9, x0, #0x640
    a140:	f94a1120 	ldr	x0, [x9, #5152]
    a144:	ab010000 	adds	x0, x0, x1
    a148:	540020c2 	b.cs	a560 <fwp_hof0.constprop.0+0xc20>  // b.hs, b.nlast
    a14c:	f94a1521 	ldr	x1, [x9, #5160]
    a150:	f90a1120 	str	x0, [x9, #5152]
    a154:	eb01001f 	cmp	x0, x1
    a158:	54000049 	b.ls	a160 <fwp_hof0.constprop.0+0x820>  // b.plast
    a15c:	f90a1520 	str	x0, [x9, #5160]
    a160:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a164:	91190000 	add	x0, x0, #0x640
    a168:	1e630181 	ucvtf	d1, w12
    a16c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a170:	1e612800 	fadd	d0, d0, d1
    a174:	fd0a1c00 	str	d0, [x0, #5176]
    a178:	3400012b 	cbz	w11, a19c <fwp_hof0.constprop.0+0x85c>
    a17c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a180:	91190000 	add	x0, x0, #0x640
    a184:	6d5486a2 	ldp	d2, d1, [x21, #328]
    a188:	fd4a1000 	ldr	d0, [x0, #5152]
    a18c:	7e61d800 	ucvtf	d0, d0
    a190:	1e623800 	fsub	d0, d0, d2
    a194:	1e612010 	fcmpe	d0, d1
    a198:	540016ec 	b.gt	a474 <fwp_hof0.constprop.0+0xb34>
    a19c:	b94000c0 	ldr	w0, [x6]
    a1a0:	29005a60 	stp	w0, w22, [x19]
    a1a4:	3400013c 	cbz	w28, a1c8 <fwp_hof0.constprop.0+0x888>
    a1a8:	910020c1 	add	x1, x6, #0x8
    a1ac:	d37d7f82 	ubfiz	x2, x28, #3, #32
    a1b0:	91002260 	add	x0, x19, #0x8
    a1b4:	b81c03a7 	stur	w7, [x29, #-64]
    a1b8:	f81d83a6 	stur	x6, [x29, #-40]
    a1bc:	97ffe131 	bl	2680 <memmove@plt>
    a1c0:	f85d83a6 	ldur	x6, [x29, #-40]
    a1c4:	b85c03a7 	ldur	w7, [x29, #-64]
    a1c8:	2a1403e9 	mov	w9, w20
    a1cc:	d2800001 	mov	x1, #0x0                   	// #0
    a1d0:	34000134 	cbz	w20, a1f4 <fwp_hof0.constprop.0+0x8b4>
    a1d4:	d503201f 	nop
    a1d8:	0b010380 	add	w0, w28, w1
    a1dc:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a1e0:	8b000e60 	add	x0, x19, x0, lsl #3
    a1e4:	91000421 	add	x1, x1, #0x1
    a1e8:	f9000402 	str	x2, [x0, #8]
    a1ec:	eb01013f 	cmp	x9, x1
    a1f0:	54ffff41 	b.ne	a1d8 <fwp_hof0.constprop.0+0x898>  // b.any
    a1f4:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a1f8:	91190002 	add	x2, x0, #0x640
    a1fc:	f949d840 	ldr	x0, [x2, #5040]
    a200:	f949ec41 	ldr	x1, [x2, #5080]
    a204:	cb000320 	sub	x0, x25, x0
    a208:	eb01401f 	cmp	x0, x1, lsl #16
    a20c:	540002e2 	b.cs	a268 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a210:	d350fc01 	lsr	x1, x0, #16
    a214:	f949fc45 	ldr	x5, [x2, #5112]
    a218:	8b010821 	add	x1, x1, x1, lsl #2
    a21c:	d37df021 	lsl	x1, x1, #3
    a220:	8b0100a4 	add	x4, x5, x1
    a224:	f9401082 	ldr	x2, [x4, #32]
    a228:	b4000202 	cbz	x2, a268 <fwp_hof0.constprop.0+0x928>
    a22c:	386168a1 	ldrb	w1, [x5, x1]
    a230:	7100083f 	cmp	w1, #0x2
    a234:	54001060 	b.eq	a440 <fwp_hof0.constprop.0+0xb00>  // b.none
    a238:	7100043f 	cmp	w1, #0x1
    a23c:	54000161 	b.ne	a268 <fwp_hof0.constprop.0+0x928>  // b.any
    a240:	29430485 	ldp	w5, w1, [x4, #24]
    a244:	92403c00 	and	x0, x0, #0xffff
    a248:	9b057c00 	mul	x0, x0, x5
    a24c:	d360fc00 	lsr	x0, x0, #32
    a250:	eb01001f 	cmp	x0, x1
    a254:	540000a2 	b.cs	a268 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a258:	8b000042 	add	x2, x2, x0
    a25c:	39400040 	ldrb	w0, [x2]
    a260:	7100041f 	cmp	w0, #0x1
    a264:	54000be0 	b.eq	a3e0 <fwp_hof0.constprop.0+0xaa0>  // b.none
    a268:	f9400f42 	ldr	x2, [x26, #24]
    a26c:	aa1903e0 	mov	x0, x25
    a270:	52800021 	mov	w1, #0x1                   	// #1
    a274:	b81d83a7 	stur	w7, [x29, #-40]
    a278:	f9400442 	ldr	x2, [x2, #8]
    a27c:	d63f0040 	blr	x2
    a280:	b85d83a7 	ldur	w7, [x29, #-40]
    a284:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a288:	91190002 	add	x2, x0, #0x640
    a28c:	f949d841 	ldr	x1, [x2, #5040]
    a290:	f949ec40 	ldr	x0, [x2, #5080]
    a294:	cb010261 	sub	x1, x19, x1
    a298:	eb00403f 	cmp	x1, x0, lsl #16
    a29c:	54000322 	b.cs	a300 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a2a0:	d350fc20 	lsr	x0, x1, #16
    a2a4:	f949fc43 	ldr	x3, [x2, #5112]
    a2a8:	8b000800 	add	x0, x0, x0, lsl #2
    a2ac:	d37df002 	lsl	x2, x0, #3
    a2b0:	8b020060 	add	x0, x3, x2
    a2b4:	f9401014 	ldr	x20, [x0, #32]
    a2b8:	b4000254 	cbz	x20, a300 <fwp_hof0.constprop.0+0x9c0>
    a2bc:	38626862 	ldrb	w2, [x3, x2]
    a2c0:	7100085f 	cmp	w2, #0x2
    a2c4:	54000c40 	b.eq	a44c <fwp_hof0.constprop.0+0xb0c>  // b.none
    a2c8:	7100045f 	cmp	w2, #0x1
    a2cc:	540001a1 	b.ne	a300 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a2d0:	29430002 	ldp	w2, w0, [x0, #24]
    a2d4:	92403c21 	and	x1, x1, #0xffff
    a2d8:	9b027c21 	mul	x1, x1, x2
    a2dc:	d360fc21 	lsr	x1, x1, #32
    a2e0:	eb00003f 	cmp	x1, x0
    a2e4:	540000e2 	b.cs	a300 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a2e8:	8b010294 	add	x20, x20, x1
    a2ec:	39400280 	ldrb	w0, [x20]
    a2f0:	7103fc1f 	cmp	w0, #0xff
    a2f4:	54000b60 	b.eq	a460 <fwp_hof0.constprop.0+0xb20>  // b.none
    a2f8:	52800020 	mov	w0, #0x1                   	// #1
    a2fc:	39000280 	strb	w0, [x20]
    a300:	aa1903e0 	mov	x0, x25
    a304:	b81d83a7 	stur	w7, [x29, #-40]
    a308:	97ffefaa 	bl	61b0 <fwp_closure_drop>
    a30c:	aa1303f9 	mov	x25, x19
    a310:	b85d83a7 	ldur	w7, [x29, #-40]
    a314:	17ffff3d 	b	a008 <fwp_hof0.constprop.0+0x6c8>
    a318:	b8626860 	ldr	w0, [x3, x2]
    a31c:	b94004a2 	ldr	w2, [x5, #4]
    a320:	4b020003 	sub	w3, w0, w2
    a324:	7100047f 	cmp	w3, #0x1
    a328:	54ffba41 	b.ne	9a70 <fwp_hof0.constprop.0+0x130>  // b.any
    a32c:	910003f6 	mov	x22, sp
    a330:	34000aa2 	cbz	w2, a484 <fwp_hof0.constprop.0+0xb44>
    a334:	7100001f 	cmp	w0, #0x0
    a338:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a33c:	d2800101 	mov	x1, #0x8                   	// #8
    a340:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a344:	91003ee0 	add	x0, x23, #0xf
    a348:	92704c01 	and	x1, x0, #0xfffff0000
    a34c:	927c7c00 	and	x0, x0, #0xffffffff0
    a350:	cb2163e1 	sub	x1, sp, x1
    a354:	eb2163ff 	cmp	sp, x1
    a358:	540000a0 	b.eq	a36c <fwp_hof0.constprop.0+0xa2c>  // b.none
    a35c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a360:	f90203ff 	str	xzr, [sp, #1024]
    a364:	eb2163ff 	cmp	sp, x1
    a368:	54ffffa1 	b.ne	a35c <fwp_hof0.constprop.0+0xa1c>  // b.any
    a36c:	92403c00 	and	x0, x0, #0xffff
    a370:	cb2063ff 	sub	sp, sp, x0
    a374:	f90003ff 	str	xzr, [sp]
    a378:	f110001f 	cmp	x0, #0x400
    a37c:	54000043 	b.cc	a384 <fwp_hof0.constprop.0+0xa44>  // b.lo, b.ul, b.last
    a380:	f90203ff 	str	xzr, [sp, #1024]
    a384:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    a388:	910043f8 	add	x24, sp, #0x10
    a38c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a390:	91004001 	add	x1, x0, #0x10
    a394:	aa1c03e2 	mov	x2, x28
    a398:	9100c021 	add	x1, x1, #0x30
    a39c:	aa1703e3 	mov	x3, x23
    a3a0:	aa1803e0 	mov	x0, x24
    a3a4:	97ffe0ef 	bl	2760 <__memcpy_chk@plt>
    a3a8:	eb1c02ff 	cmp	x23, x28
    a3ac:	aa1403e1 	mov	x1, x20
    a3b0:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    a3b4:	d2800102 	mov	x2, #0x8                   	// #8
    a3b8:	cb1c0063 	sub	x3, x3, x28
    a3bc:	8b1c0300 	add	x0, x24, x28
    a3c0:	97ffe0e8 	bl	2760 <__memcpy_chk@plt>
    a3c4:	f9400f61 	ldr	x1, [x27, #24]
    a3c8:	aa1803e0 	mov	x0, x24
    a3cc:	f9400021 	ldr	x1, [x1]
    a3d0:	d63f0020 	blr	x1
    a3d4:	aa0003f9 	mov	x25, x0
    a3d8:	910002df 	mov	sp, x22
    a3dc:	17ffff2b 	b	a088 <fwp_hof0.constprop.0+0x748>
    a3e0:	b90004df 	str	wzr, [x6, #4]
    a3e4:	17ffffa8 	b	a284 <fwp_hof0.constprop.0+0x944>
    a3e8:	72003c3f 	tst	w1, #0xffff
    a3ec:	54ffb8c1 	b.ne	9b04 <fwp_hof0.constprop.0+0x1c4>  // b.any
    a3f0:	17fffdba 	b	9ad8 <fwp_hof0.constprop.0+0x198>
    a3f4:	f94005b3 	ldr	x19, [x13, #8]
    a3f8:	b4000113 	cbz	x19, a418 <fwp_hof0.constprop.0+0xad8>
    a3fc:	f94009a9 	ldr	x9, [x13, #16]
    a400:	cb130129 	sub	x9, x9, x19
    a404:	eb09003f 	cmp	x1, x9
    a408:	54000088 	b.hi	a418 <fwp_hof0.constprop.0+0xad8>  // b.pmore
    a40c:	8b010269 	add	x9, x19, x1
    a410:	f90005a9 	str	x9, [x13, #8]
    a414:	17ffff42 	b	a11c <fwp_hof0.constprop.0+0x7dc>
    a418:	52800001 	mov	w1, #0x0                   	// #0
    a41c:	b81bc3ab 	stur	w11, [x29, #-68]
    a420:	f81c03a6 	stur	x6, [x29, #-64]
    a424:	b81d83a7 	stur	w7, [x29, #-40]
    a428:	97ffeb1a 	bl	5090 <fwp_heap_alloc>
    a42c:	f85c03a6 	ldur	x6, [x29, #-64]
    a430:	aa0003f3 	mov	x19, x0
    a434:	b85bc3ab 	ldur	w11, [x29, #-68]
    a438:	b85d83a7 	ldur	w7, [x29, #-40]
    a43c:	17ffff4f 	b	a178 <fwp_hof0.constprop.0+0x838>
    a440:	72003c1f 	tst	w0, #0xffff
    a444:	54fff121 	b.ne	a268 <fwp_hof0.constprop.0+0x928>  // b.any
    a448:	17ffff85 	b	a25c <fwp_hof0.constprop.0+0x91c>
    a44c:	72003c3f 	tst	w1, #0xffff
    a450:	54fff581 	b.ne	a300 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a454:	39400280 	ldrb	w0, [x20]
    a458:	7103fc1f 	cmp	w0, #0xff
    a45c:	54fff4e1 	b.ne	a2f8 <fwp_hof0.constprop.0+0x9b8>  // b.any
    a460:	aa1403e0 	mov	x0, x20
    a464:	b81d83a7 	stur	w7, [x29, #-40]
    a468:	97ffe94a 	bl	4990 <fwp_rc_forget_slot>
    a46c:	b85d83a7 	ldur	w7, [x29, #-40]
    a470:	17ffffa2 	b	a2f8 <fwp_hof0.constprop.0+0x9b8>
    a474:	fd00aaa0 	str	d0, [x21, #336]
    a478:	17ffff49 	b	a19c <fwp_hof0.constprop.0+0x85c>
    a47c:	97ffe8fe 	bl	4874 <fwp_rc_wide_dup>
    a480:	17fffda1 	b	9b04 <fwp_hof0.constprop.0+0x1c4>
    a484:	f9400021 	ldr	x1, [x1]
    a488:	aa1403e0 	mov	x0, x20
    a48c:	d63f0020 	blr	x1
    a490:	aa0003f9 	mov	x25, x0
    a494:	910002df 	mov	sp, x22
    a498:	17fffefc 	b	a088 <fwp_hof0.constprop.0+0x748>
    a49c:	72003c3f 	tst	w1, #0xffff
    a4a0:	54ffac61 	b.ne	9a2c <fwp_hof0.constprop.0+0xec>  // b.any
    a4a4:	17fffd58 	b	9a04 <fwp_hof0.constprop.0+0xc4>
    a4a8:	aa1a03e0 	mov	x0, x26
    a4ac:	97ffed5e 	bl	5a24 <fwp_rc_share>
    a4b0:	aa1903e0 	mov	x0, x25
    a4b4:	52800037 	mov	w23, #0x1                   	// #1
    a4b8:	97ffed5b 	bl	5a24 <fwp_rc_share>
    a4bc:	aa1a03f9 	mov	x25, x26
    a4c0:	f81d03b4 	stur	x20, [x29, #-48]
    a4c4:	17fffeec 	b	a074 <fwp_hof0.constprop.0+0x734>
    a4c8:	f940ac43 	ldr	x3, [x2, #344]
    a4cc:	91000463 	add	x3, x3, #0x1
    a4d0:	f900ac43 	str	x3, [x2, #344]
    a4d4:	17fffd52 	b	9a1c <fwp_hof0.constprop.0+0xdc>
    a4d8:	aa1303e0 	mov	x0, x19
    a4dc:	97ffeda9 	bl	5b80 <fwp_rc_free_arr>
    a4e0:	f9400b5a 	ldr	x26, [x26, #16]
    a4e4:	b5ffa5da 	cbnz	x26, 999c <fwp_hof0.constprop.0+0x5c>
    a4e8:	17fffe9b 	b	9f54 <fwp_hof0.constprop.0+0x614>
    a4ec:	72003c3f 	tst	w1, #0xffff
    a4f0:	54ffd2e1 	b.ne	9f4c <fwp_hof0.constprop.0+0x60c>  // b.any
    a4f4:	17fffe8e 	b	9f2c <fwp_hof0.constprop.0+0x5ec>
    a4f8:	72003c3f 	tst	w1, #0xffff
    a4fc:	54ffcca1 	b.ne	9e90 <fwp_hof0.constprop.0+0x550>  // b.any
    a500:	17fffe5f 	b	9e7c <fwp_hof0.constprop.0+0x53c>
    a504:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a508:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a50c:	91190021 	add	x1, x1, #0x640
    a510:	ca402400 	eor	x0, x0, x0, lsr #9
    a514:	8b200c20 	add	x0, x1, w0, uxtb #3
    a518:	f94a2400 	ldr	x0, [x0, #5192]
    a51c:	b5000080 	cbnz	x0, a52c <fwp_hof0.constprop.0+0xbec>
    a520:	14000011 	b	a564 <fwp_hof0.constprop.0+0xc24>
    a524:	f9400800 	ldr	x0, [x0, #16]
    a528:	b40001e0 	cbz	x0, a564 <fwp_hof0.constprop.0+0xc24>
    a52c:	f9400001 	ldr	x1, [x0]
    a530:	eb16003f 	cmp	x1, x22
    a534:	54ffff81 	b.ne	a524 <fwp_hof0.constprop.0+0xbe4>  // b.any
    a538:	f9400401 	ldr	x1, [x0, #8]
    a53c:	d1000421 	sub	x1, x1, #0x1
    a540:	f9000401 	str	x1, [x0, #8]
    a544:	f103f83f 	cmp	x1, #0xfe
    a548:	54ffd021 	b.ne	9f4c <fwp_hof0.constprop.0+0x60c>  // b.any
    a54c:	aa1603e0 	mov	x0, x22
    a550:	97ffe910 	bl	4990 <fwp_rc_forget_slot>
    a554:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a558:	390002c0 	strb	w0, [x22]
    a55c:	17fffe7c 	b	9f4c <fwp_hof0.constprop.0+0x60c>
    a560:	97ffe2e4 	bl	30f0 <fwp_heap_oom>
    a564:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x400>
    a568:	91368000 	add	x0, x0, #0xda0
    a56c:	97ffe485 	bl	3780 <fwp_trap>
    a570:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x720>
    a574:	9102e000 	add	x0, x0, #0xb8
    a578:	97ffe482 	bl	3780 <fwp_trap>
    a57c:	97ffe8be 	bl	4874 <fwp_rc_wide_dup>
    a580:	17fffd2b 	b	9a2c <fwp_hof0.constprop.0+0xec>
    a584:	97ffe0a3 	bl	2810 <__stack_chk_fail@plt>
    a588:	aa1903e0 	mov	x0, x25
    a58c:	97ffe901 	bl	4990 <fwp_rc_forget_slot>
    a590:	17fffe3e 	b	9e88 <fwp_hof0.constprop.0+0x548>

000000000000a594 <f0>:
    a594:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a598:	910003fd 	mov	x29, sp
    a59c:	a90153f3 	stp	x19, x20, [sp, #16]
    a5a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    a5a4:	a90363f7 	stp	x23, x24, [sp, #48]
    a5a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    a5ac:	a90573fb 	stp	x27, x28, [sp, #80]
    a5b0:	d12183ff 	sub	sp, sp, #0x860
    a5b4:	f90203ff 	str	xzr, [sp, #1024]
    a5b8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a5bc:	91018005 	add	x5, x0, #0x60
    a5c0:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a5c4:	f947f400 	ldr	x0, [x0, #4072]
    a5c8:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xba0>
    a5cc:	f941c8a6 	ldr	x6, [x5, #912]
    a5d0:	f9400001 	ldr	x1, [x0]
    a5d4:	f9042fe1 	str	x1, [sp, #2136]
    a5d8:	d2800001 	mov	x1, #0x0                   	// #0
    a5dc:	91190298 	add	x24, x20, #0x640
    a5e0:	912123f6 	add	x22, sp, #0x848
    a5e4:	910023e0 	add	x0, sp, #0x8
    a5e8:	910083e2 	add	x2, sp, #0x20
    a5ec:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc_slow+0xd0>
    a5f0:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a5f4:	913bc021 	add	x1, x1, #0xef0
    a5f8:	913b4084 	add	x4, x4, #0xed0
    a5fc:	d2800013 	mov	x19, #0x0                   	// #0
    a600:	d2800119 	mov	x25, #0x8                   	// #8
    a604:	d2800015 	mov	x21, #0x0                   	// #0
    a608:	52800037 	mov	w23, #0x1                   	// #1
    a60c:	a90093e6 	stp	x6, x4, [sp, #8]
    a610:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a614:	a90307ff 	stp	xzr, x1, [sp, #48]
    a618:	f901c8a0 	str	x0, [x5, #912]
    a61c:	d503201f 	nop
    a620:	f100073a 	subs	x26, x25, #0x1
    a624:	aa1603e1 	mov	x1, x22
    a628:	da1f02bc 	sbc	x28, x21, xzr
    a62c:	52800020 	mov	w0, #0x1                   	// #1
    a630:	f90017fa 	str	x26, [sp, #40]
    a634:	aa1a03f9 	mov	x25, x26
    a638:	f90427fa 	str	x26, [sp, #2120]
    a63c:	aa1c03f5 	mov	x21, x28
    a640:	f9042bf3 	str	x19, [sp, #2128]
    a644:	97ffec9b 	bl	58b0 <fwp_data.part.0.constprop.0>
    a648:	f949db02 	ldr	x2, [x24, #5040]
    a64c:	aa0003f3 	mov	x19, x0
    a650:	f949ef00 	ldr	x0, [x24, #5080]
    a654:	cb020262 	sub	x2, x19, x2
    a658:	eb00405f 	cmp	x2, x0, lsl #16
    a65c:	54000302 	b.cs	a6bc <f0+0x128>  // b.hs, b.nlast
    a660:	d350fc40 	lsr	x0, x2, #16
    a664:	f949ff04 	ldr	x4, [x24, #5112]
    a668:	8b000800 	add	x0, x0, x0, lsl #2
    a66c:	d37df001 	lsl	x1, x0, #3
    a670:	8b010080 	add	x0, x4, x1
    a674:	f940101b 	ldr	x27, [x0, #32]
    a678:	b400023b 	cbz	x27, a6bc <f0+0x128>
    a67c:	38616881 	ldrb	w1, [x4, x1]
    a680:	7100083f 	cmp	w1, #0x2
    a684:	54010de0 	b.eq	c840 <f0+0x22ac>  // b.none
    a688:	7100043f 	cmp	w1, #0x1
    a68c:	54000181 	b.ne	a6bc <f0+0x128>  // b.any
    a690:	29430001 	ldp	w1, w0, [x0, #24]
    a694:	92403c42 	and	x2, x2, #0xffff
    a698:	9b017c42 	mul	x2, x2, x1
    a69c:	d360fc42 	lsr	x2, x2, #32
    a6a0:	eb00005f 	cmp	x2, x0
    a6a4:	540000c2 	b.cs	a6bc <f0+0x128>  // b.hs, b.nlast
    a6a8:	8b02037b 	add	x27, x27, x2
    a6ac:	39400360 	ldrb	w0, [x27]
    a6b0:	7103fc1f 	cmp	w0, #0xff
    a6b4:	54010c00 	b.eq	c834 <f0+0x22a0>  // b.none
    a6b8:	39000377 	strb	w23, [x27]
    a6bc:	f90013f3 	str	x19, [sp, #32]
    a6c0:	aa1c035a 	orr	x26, x26, x28
    a6c4:	b5fffafa 	cbnz	x26, a620 <f0+0x8c>
    a6c8:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x720>
    a6cc:	910103e1 	add	x1, sp, #0x40
    a6d0:	f94007e2 	ldr	x2, [sp, #8]
    a6d4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a6d8:	3dc22800 	ldr	q0, [x0, #2208]
    a6dc:	d00000a0 	adrp	x0, 20000 <__data_start>
    a6e0:	91018018 	add	x24, x0, #0x60
    a6e4:	52800020 	mov	w0, #0x1                   	// #1
    a6e8:	3d8013e0 	str	q0, [sp, #64]
    a6ec:	f901cb02 	str	x2, [x24, #912]
    a6f0:	97ffec70 	bl	58b0 <fwp_data.part.0.constprop.0>
    a6f4:	97ffecf3 	bl	5ac0 <fwp_rc_fresh>
    a6f8:	aa0003e2 	mov	x2, x0
    a6fc:	910163e1 	add	x1, sp, #0x58
    a700:	52800020 	mov	w0, #0x1                   	// #1
    a704:	a9058bf5 	stp	x21, x2, [sp, #88]
    a708:	97ffec6a 	bl	58b0 <fwp_data.part.0.constprop.0>
    a70c:	97ffeced 	bl	5ac0 <fwp_rc_fresh>
    a710:	aa0003e2 	mov	x2, x0
    a714:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x720>
    a718:	9101a3e1 	add	x1, sp, #0x68
    a71c:	52800020 	mov	w0, #0x1                   	// #1
    a720:	f9003be2 	str	x2, [sp, #112]
    a724:	3dc22860 	ldr	q0, [x3, #2208]
    a728:	fd0037e0 	str	d0, [sp, #104]
    a72c:	97ffec61 	bl	58b0 <fwp_data.part.0.constprop.0>
    a730:	97ffece4 	bl	5ac0 <fwp_rc_fresh>
    a734:	aa0003e2 	mov	x2, x0
    a738:	9101e3e1 	add	x1, sp, #0x78
    a73c:	52800020 	mov	w0, #0x1                   	// #1
    a740:	a9078bf5 	stp	x21, x2, [sp, #120]
    a744:	97ffec5b 	bl	58b0 <fwp_data.part.0.constprop.0>
    a748:	91190283 	add	x3, x20, #0x640
    a74c:	aa0003f5 	mov	x21, x0
    a750:	f949d861 	ldr	x1, [x3, #5040]
    a754:	f949ec60 	ldr	x0, [x3, #5080]
    a758:	cb0102a1 	sub	x1, x21, x1
    a75c:	eb00403f 	cmp	x1, x0, lsl #16
    a760:	54000322 	b.cs	a7c4 <f0+0x230>  // b.hs, b.nlast
    a764:	d350fc22 	lsr	x2, x1, #16
    a768:	f949fc63 	ldr	x3, [x3, #5112]
    a76c:	8b020842 	add	x2, x2, x2, lsl #2
    a770:	d37df042 	lsl	x2, x2, #3
    a774:	8b020060 	add	x0, x3, x2
    a778:	f9401017 	ldr	x23, [x0, #32]
    a77c:	b4000257 	cbz	x23, a7c4 <f0+0x230>
    a780:	38626862 	ldrb	w2, [x3, x2]
    a784:	7100085f 	cmp	w2, #0x2
    a788:	540109e0 	b.eq	c8c4 <f0+0x2330>  // b.none
    a78c:	7100045f 	cmp	w2, #0x1
    a790:	540001a1 	b.ne	a7c4 <f0+0x230>  // b.any
    a794:	29430002 	ldp	w2, w0, [x0, #24]
    a798:	92403c21 	and	x1, x1, #0xffff
    a79c:	9b027c21 	mul	x1, x1, x2
    a7a0:	d360fc21 	lsr	x1, x1, #32
    a7a4:	eb00003f 	cmp	x1, x0
    a7a8:	540000e2 	b.cs	a7c4 <f0+0x230>  // b.hs, b.nlast
    a7ac:	8b0102f7 	add	x23, x23, x1
    a7b0:	394002e0 	ldrb	w0, [x23]
    a7b4:	7103fc1f 	cmp	w0, #0xff
    a7b8:	540113a0 	b.eq	ca2c <f0+0x2498>  // b.none
    a7bc:	52800020 	mov	w0, #0x1                   	// #1
    a7c0:	390002e0 	strb	w0, [x23]
    a7c4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7c8:	910223e1 	add	x1, sp, #0x88
    a7cc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7d0:	52800020 	mov	w0, #0x1                   	// #1
    a7d4:	a908d7e2 	stp	x2, x21, [sp, #136]
    a7d8:	97ffec36 	bl	58b0 <fwp_data.part.0.constprop.0>
    a7dc:	91190283 	add	x3, x20, #0x640
    a7e0:	aa0003f5 	mov	x21, x0
    a7e4:	f949d861 	ldr	x1, [x3, #5040]
    a7e8:	f949ec60 	ldr	x0, [x3, #5080]
    a7ec:	cb0102a1 	sub	x1, x21, x1
    a7f0:	eb00403f 	cmp	x1, x0, lsl #16
    a7f4:	54000322 	b.cs	a858 <f0+0x2c4>  // b.hs, b.nlast
    a7f8:	d350fc22 	lsr	x2, x1, #16
    a7fc:	f949fc63 	ldr	x3, [x3, #5112]
    a800:	8b020842 	add	x2, x2, x2, lsl #2
    a804:	d37df042 	lsl	x2, x2, #3
    a808:	8b020060 	add	x0, x3, x2
    a80c:	f9401017 	ldr	x23, [x0, #32]
    a810:	b4000257 	cbz	x23, a858 <f0+0x2c4>
    a814:	38626862 	ldrb	w2, [x3, x2]
    a818:	7100085f 	cmp	w2, #0x2
    a81c:	540104e0 	b.eq	c8b8 <f0+0x2324>  // b.none
    a820:	7100045f 	cmp	w2, #0x1
    a824:	540001a1 	b.ne	a858 <f0+0x2c4>  // b.any
    a828:	29430002 	ldp	w2, w0, [x0, #24]
    a82c:	92403c21 	and	x1, x1, #0xffff
    a830:	9b027c21 	mul	x1, x1, x2
    a834:	d360fc21 	lsr	x1, x1, #32
    a838:	eb00003f 	cmp	x1, x0
    a83c:	540000e2 	b.cs	a858 <f0+0x2c4>  // b.hs, b.nlast
    a840:	8b0102f7 	add	x23, x23, x1
    a844:	394002e0 	ldrb	w0, [x23]
    a848:	7103fc1f 	cmp	w0, #0xff
    a84c:	54010f60 	b.eq	ca38 <f0+0x24a4>  // b.none
    a850:	52800020 	mov	w0, #0x1                   	// #1
    a854:	390002e0 	strb	w0, [x23]
    a858:	910263e1 	add	x1, sp, #0x98
    a85c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a860:	52800020 	mov	w0, #0x1                   	// #1
    a864:	a909d7e2 	stp	x2, x21, [sp, #152]
    a868:	97ffec12 	bl	58b0 <fwp_data.part.0.constprop.0>
    a86c:	97ffec95 	bl	5ac0 <fwp_rc_fresh>
    a870:	aa0003e2 	mov	x2, x0
    a874:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a878:	9102a3e1 	add	x1, sp, #0xa8
    a87c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a880:	52800020 	mov	w0, #0x1                   	// #1
    a884:	a90a8be3 	stp	x3, x2, [sp, #168]
    a888:	97ffec0a 	bl	58b0 <fwp_data.part.0.constprop.0>
    a88c:	91190283 	add	x3, x20, #0x640
    a890:	aa0003f5 	mov	x21, x0
    a894:	f949d861 	ldr	x1, [x3, #5040]
    a898:	f949ec60 	ldr	x0, [x3, #5080]
    a89c:	cb0102a1 	sub	x1, x21, x1
    a8a0:	eb00403f 	cmp	x1, x0, lsl #16
    a8a4:	54000322 	b.cs	a908 <f0+0x374>  // b.hs, b.nlast
    a8a8:	d350fc22 	lsr	x2, x1, #16
    a8ac:	f949fc63 	ldr	x3, [x3, #5112]
    a8b0:	8b020842 	add	x2, x2, x2, lsl #2
    a8b4:	d37df042 	lsl	x2, x2, #3
    a8b8:	8b020060 	add	x0, x3, x2
    a8bc:	f9401017 	ldr	x23, [x0, #32]
    a8c0:	b4000257 	cbz	x23, a908 <f0+0x374>
    a8c4:	38626862 	ldrb	w2, [x3, x2]
    a8c8:	7100085f 	cmp	w2, #0x2
    a8cc:	5400ff00 	b.eq	c8ac <f0+0x2318>  // b.none
    a8d0:	7100045f 	cmp	w2, #0x1
    a8d4:	540001a1 	b.ne	a908 <f0+0x374>  // b.any
    a8d8:	29430002 	ldp	w2, w0, [x0, #24]
    a8dc:	92403c21 	and	x1, x1, #0xffff
    a8e0:	9b027c21 	mul	x1, x1, x2
    a8e4:	d360fc21 	lsr	x1, x1, #32
    a8e8:	eb00003f 	cmp	x1, x0
    a8ec:	540000e2 	b.cs	a908 <f0+0x374>  // b.hs, b.nlast
    a8f0:	8b0102f7 	add	x23, x23, x1
    a8f4:	394002e0 	ldrb	w0, [x23]
    a8f8:	7103fc1f 	cmp	w0, #0xff
    a8fc:	54010a40 	b.eq	ca44 <f0+0x24b0>  // b.none
    a900:	52800020 	mov	w0, #0x1                   	// #1
    a904:	390002e0 	strb	w0, [x23]
    a908:	9102e3e1 	add	x1, sp, #0xb8
    a90c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a910:	52800020 	mov	w0, #0x1                   	// #1
    a914:	a90bd7e2 	stp	x2, x21, [sp, #184]
    a918:	97ffebe6 	bl	58b0 <fwp_data.part.0.constprop.0>
    a91c:	97ffec69 	bl	5ac0 <fwp_rc_fresh>
    a920:	aa0003e2 	mov	x2, x0
    a924:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a928:	910323e1 	add	x1, sp, #0xc8
    a92c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a930:	52800020 	mov	w0, #0x1                   	// #1
    a934:	a90c8be3 	stp	x3, x2, [sp, #200]
    a938:	97ffebde 	bl	58b0 <fwp_data.part.0.constprop.0>
    a93c:	91190283 	add	x3, x20, #0x640
    a940:	aa0003f5 	mov	x21, x0
    a944:	f949d861 	ldr	x1, [x3, #5040]
    a948:	f949ec60 	ldr	x0, [x3, #5080]
    a94c:	cb0102a1 	sub	x1, x21, x1
    a950:	eb00403f 	cmp	x1, x0, lsl #16
    a954:	54000322 	b.cs	a9b8 <f0+0x424>  // b.hs, b.nlast
    a958:	d350fc22 	lsr	x2, x1, #16
    a95c:	f949fc63 	ldr	x3, [x3, #5112]
    a960:	8b020842 	add	x2, x2, x2, lsl #2
    a964:	d37df042 	lsl	x2, x2, #3
    a968:	8b020060 	add	x0, x3, x2
    a96c:	f9401017 	ldr	x23, [x0, #32]
    a970:	b4000257 	cbz	x23, a9b8 <f0+0x424>
    a974:	38626862 	ldrb	w2, [x3, x2]
    a978:	7100085f 	cmp	w2, #0x2
    a97c:	5400fbc0 	b.eq	c8f4 <f0+0x2360>  // b.none
    a980:	7100045f 	cmp	w2, #0x1
    a984:	540001a1 	b.ne	a9b8 <f0+0x424>  // b.any
    a988:	29430002 	ldp	w2, w0, [x0, #24]
    a98c:	92403c21 	and	x1, x1, #0xffff
    a990:	9b027c21 	mul	x1, x1, x2
    a994:	d360fc21 	lsr	x1, x1, #32
    a998:	eb00003f 	cmp	x1, x0
    a99c:	540000e2 	b.cs	a9b8 <f0+0x424>  // b.hs, b.nlast
    a9a0:	8b0102f7 	add	x23, x23, x1
    a9a4:	394002e0 	ldrb	w0, [x23]
    a9a8:	7103fc1f 	cmp	w0, #0xff
    a9ac:	54010520 	b.eq	ca50 <f0+0x24bc>  // b.none
    a9b0:	52800020 	mov	w0, #0x1                   	// #1
    a9b4:	390002e0 	strb	w0, [x23]
    a9b8:	910363e1 	add	x1, sp, #0xd8
    a9bc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a9c0:	52800020 	mov	w0, #0x1                   	// #1
    a9c4:	a90dd7f7 	stp	x23, x21, [sp, #216]
    a9c8:	97ffebba 	bl	58b0 <fwp_data.part.0.constprop.0>
    a9cc:	97ffec3d 	bl	5ac0 <fwp_rc_fresh>
    a9d0:	aa0003e2 	mov	x2, x0
    a9d4:	9103a3e1 	add	x1, sp, #0xe8
    a9d8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a9dc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a9e0:	52800020 	mov	w0, #0x1                   	// #1
    a9e4:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a9e8:	97ffebb2 	bl	58b0 <fwp_data.part.0.constprop.0>
    a9ec:	97ffec35 	bl	5ac0 <fwp_rc_fresh>
    a9f0:	aa0003e2 	mov	x2, x0
    a9f4:	9103e3e1 	add	x1, sp, #0xf8
    a9f8:	52800020 	mov	w0, #0x1                   	// #1
    a9fc:	a90f8bf7 	stp	x23, x2, [sp, #248]
    aa00:	97ffebac 	bl	58b0 <fwp_data.part.0.constprop.0>
    aa04:	97ffec2f 	bl	5ac0 <fwp_rc_fresh>
    aa08:	aa0003e2 	mov	x2, x0
    aa0c:	910423e1 	add	x1, sp, #0x108
    aa10:	52800020 	mov	w0, #0x1                   	// #1
    aa14:	a9108bf5 	stp	x21, x2, [sp, #264]
    aa18:	97ffeba6 	bl	58b0 <fwp_data.part.0.constprop.0>
    aa1c:	97ffec29 	bl	5ac0 <fwp_rc_fresh>
    aa20:	aa0003e2 	mov	x2, x0
    aa24:	910463e1 	add	x1, sp, #0x118
    aa28:	52800020 	mov	w0, #0x1                   	// #1
    aa2c:	a9118bf7 	stp	x23, x2, [sp, #280]
    aa30:	97ffeba0 	bl	58b0 <fwp_data.part.0.constprop.0>
    aa34:	91190283 	add	x3, x20, #0x640
    aa38:	aa0003f5 	mov	x21, x0
    aa3c:	f949d861 	ldr	x1, [x3, #5040]
    aa40:	f949ec60 	ldr	x0, [x3, #5080]
    aa44:	cb0102a1 	sub	x1, x21, x1
    aa48:	eb00403f 	cmp	x1, x0, lsl #16
    aa4c:	54000322 	b.cs	aab0 <f0+0x51c>  // b.hs, b.nlast
    aa50:	d350fc22 	lsr	x2, x1, #16
    aa54:	f949fc63 	ldr	x3, [x3, #5112]
    aa58:	8b020842 	add	x2, x2, x2, lsl #2
    aa5c:	d37df042 	lsl	x2, x2, #3
    aa60:	8b020060 	add	x0, x3, x2
    aa64:	f9401017 	ldr	x23, [x0, #32]
    aa68:	b4000257 	cbz	x23, aab0 <f0+0x51c>
    aa6c:	38626862 	ldrb	w2, [x3, x2]
    aa70:	7100085f 	cmp	w2, #0x2
    aa74:	5400f3a0 	b.eq	c8e8 <f0+0x2354>  // b.none
    aa78:	7100045f 	cmp	w2, #0x1
    aa7c:	540001a1 	b.ne	aab0 <f0+0x51c>  // b.any
    aa80:	29430002 	ldp	w2, w0, [x0, #24]
    aa84:	92403c21 	and	x1, x1, #0xffff
    aa88:	9b027c21 	mul	x1, x1, x2
    aa8c:	d360fc21 	lsr	x1, x1, #32
    aa90:	eb00003f 	cmp	x1, x0
    aa94:	540000e2 	b.cs	aab0 <f0+0x51c>  // b.hs, b.nlast
    aa98:	8b0102f7 	add	x23, x23, x1
    aa9c:	394002e0 	ldrb	w0, [x23]
    aaa0:	7103fc1f 	cmp	w0, #0xff
    aaa4:	5400fdc0 	b.eq	ca5c <f0+0x24c8>  // b.none
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	390002e0 	strb	w0, [x23]
    aab0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aab4:	9104a3e1 	add	x1, sp, #0x128
    aab8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	a912d7e2 	stp	x2, x21, [sp, #296]
    aac4:	97ffeb7b 	bl	58b0 <fwp_data.part.0.constprop.0>
    aac8:	97ffebfe 	bl	5ac0 <fwp_rc_fresh>
    aacc:	aa0003e2 	mov	x2, x0
    aad0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aad4:	9104e3e1 	add	x1, sp, #0x138
    aad8:	52800020 	mov	w0, #0x1                   	// #1
    aadc:	a9138be3 	stp	x3, x2, [sp, #312]
    aae0:	97ffeb74 	bl	58b0 <fwp_data.part.0.constprop.0>
    aae4:	91190283 	add	x3, x20, #0x640
    aae8:	aa0003f5 	mov	x21, x0
    aaec:	f949d861 	ldr	x1, [x3, #5040]
    aaf0:	f949ec60 	ldr	x0, [x3, #5080]
    aaf4:	cb0102a1 	sub	x1, x21, x1
    aaf8:	eb00403f 	cmp	x1, x0, lsl #16
    aafc:	54000322 	b.cs	ab60 <f0+0x5cc>  // b.hs, b.nlast
    ab00:	d350fc22 	lsr	x2, x1, #16
    ab04:	f949fc63 	ldr	x3, [x3, #5112]
    ab08:	8b020842 	add	x2, x2, x2, lsl #2
    ab0c:	d37df042 	lsl	x2, x2, #3
    ab10:	8b020060 	add	x0, x3, x2
    ab14:	f9401017 	ldr	x23, [x0, #32]
    ab18:	b4000257 	cbz	x23, ab60 <f0+0x5cc>
    ab1c:	38626862 	ldrb	w2, [x3, x2]
    ab20:	7100085f 	cmp	w2, #0x2
    ab24:	5400edc0 	b.eq	c8dc <f0+0x2348>  // b.none
    ab28:	7100045f 	cmp	w2, #0x1
    ab2c:	540001a1 	b.ne	ab60 <f0+0x5cc>  // b.any
    ab30:	29430002 	ldp	w2, w0, [x0, #24]
    ab34:	92403c21 	and	x1, x1, #0xffff
    ab38:	9b027c21 	mul	x1, x1, x2
    ab3c:	d360fc21 	lsr	x1, x1, #32
    ab40:	eb00003f 	cmp	x1, x0
    ab44:	540000e2 	b.cs	ab60 <f0+0x5cc>  // b.hs, b.nlast
    ab48:	8b0102f7 	add	x23, x23, x1
    ab4c:	394002e0 	ldrb	w0, [x23]
    ab50:	7103fc1f 	cmp	w0, #0xff
    ab54:	5400f8a0 	b.eq	ca68 <f0+0x24d4>  // b.none
    ab58:	52800020 	mov	w0, #0x1                   	// #1
    ab5c:	390002e0 	strb	w0, [x23]
    ab60:	910523e1 	add	x1, sp, #0x148
    ab64:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ab68:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ab6c:	52800020 	mov	w0, #0x1                   	// #1
    ab70:	a914d7f7 	stp	x23, x21, [sp, #328]
    ab74:	97ffeb4f 	bl	58b0 <fwp_data.part.0.constprop.0>
    ab78:	97ffebd2 	bl	5ac0 <fwp_rc_fresh>
    ab7c:	aa0003e2 	mov	x2, x0
    ab80:	910563e1 	add	x1, sp, #0x158
    ab84:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ab88:	52800020 	mov	w0, #0x1                   	// #1
    ab8c:	a9158bf5 	stp	x21, x2, [sp, #344]
    ab90:	97ffeb48 	bl	58b0 <fwp_data.part.0.constprop.0>
    ab94:	97ffebcb 	bl	5ac0 <fwp_rc_fresh>
    ab98:	aa0003e2 	mov	x2, x0
    ab9c:	9105a3e1 	add	x1, sp, #0x168
    aba0:	52800020 	mov	w0, #0x1                   	// #1
    aba4:	a9168bf7 	stp	x23, x2, [sp, #360]
    aba8:	97ffeb42 	bl	58b0 <fwp_data.part.0.constprop.0>
    abac:	97ffebc5 	bl	5ac0 <fwp_rc_fresh>
    abb0:	aa0003e2 	mov	x2, x0
    abb4:	9105e3e1 	add	x1, sp, #0x178
    abb8:	52800020 	mov	w0, #0x1                   	// #1
    abbc:	a9178bf5 	stp	x21, x2, [sp, #376]
    abc0:	97ffeb3c 	bl	58b0 <fwp_data.part.0.constprop.0>
    abc4:	91190283 	add	x3, x20, #0x640
    abc8:	aa0003f5 	mov	x21, x0
    abcc:	f949d861 	ldr	x1, [x3, #5040]
    abd0:	f949ec60 	ldr	x0, [x3, #5080]
    abd4:	cb0102a1 	sub	x1, x21, x1
    abd8:	eb00403f 	cmp	x1, x0, lsl #16
    abdc:	54000322 	b.cs	ac40 <f0+0x6ac>  // b.hs, b.nlast
    abe0:	d350fc22 	lsr	x2, x1, #16
    abe4:	f949fc63 	ldr	x3, [x3, #5112]
    abe8:	8b020842 	add	x2, x2, x2, lsl #2
    abec:	d37df042 	lsl	x2, x2, #3
    abf0:	8b020060 	add	x0, x3, x2
    abf4:	f9401017 	ldr	x23, [x0, #32]
    abf8:	b4000257 	cbz	x23, ac40 <f0+0x6ac>
    abfc:	38626862 	ldrb	w2, [x3, x2]
    ac00:	7100085f 	cmp	w2, #0x2
    ac04:	5400e660 	b.eq	c8d0 <f0+0x233c>  // b.none
    ac08:	7100045f 	cmp	w2, #0x1
    ac0c:	540001a1 	b.ne	ac40 <f0+0x6ac>  // b.any
    ac10:	29430002 	ldp	w2, w0, [x0, #24]
    ac14:	92403c21 	and	x1, x1, #0xffff
    ac18:	9b027c21 	mul	x1, x1, x2
    ac1c:	d360fc21 	lsr	x1, x1, #32
    ac20:	eb00003f 	cmp	x1, x0
    ac24:	540000e2 	b.cs	ac40 <f0+0x6ac>  // b.hs, b.nlast
    ac28:	8b0102f7 	add	x23, x23, x1
    ac2c:	394002e0 	ldrb	w0, [x23]
    ac30:	7103fc1f 	cmp	w0, #0xff
    ac34:	5400f200 	b.eq	ca74 <f0+0x24e0>  // b.none
    ac38:	52800020 	mov	w0, #0x1                   	// #1
    ac3c:	390002e0 	strb	w0, [x23]
    ac40:	910623e1 	add	x1, sp, #0x188
    ac44:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ac48:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ac4c:	52800020 	mov	w0, #0x1                   	// #1
    ac50:	a918d7f7 	stp	x23, x21, [sp, #392]
    ac54:	97ffeb17 	bl	58b0 <fwp_data.part.0.constprop.0>
    ac58:	97ffeb9a 	bl	5ac0 <fwp_rc_fresh>
    ac5c:	aa0003e2 	mov	x2, x0
    ac60:	910663e1 	add	x1, sp, #0x198
    ac64:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ac68:	52800020 	mov	w0, #0x1                   	// #1
    ac6c:	a9198bf5 	stp	x21, x2, [sp, #408]
    ac70:	97ffeb10 	bl	58b0 <fwp_data.part.0.constprop.0>
    ac74:	97ffeb93 	bl	5ac0 <fwp_rc_fresh>
    ac78:	aa0003e2 	mov	x2, x0
    ac7c:	9106a3e1 	add	x1, sp, #0x1a8
    ac80:	52800020 	mov	w0, #0x1                   	// #1
    ac84:	a91a8bf7 	stp	x23, x2, [sp, #424]
    ac88:	97ffeb0a 	bl	58b0 <fwp_data.part.0.constprop.0>
    ac8c:	97ffeb8d 	bl	5ac0 <fwp_rc_fresh>
    ac90:	aa0003e2 	mov	x2, x0
    ac94:	9106e3e1 	add	x1, sp, #0x1b8
    ac98:	52800020 	mov	w0, #0x1                   	// #1
    ac9c:	a91b8bf5 	stp	x21, x2, [sp, #440]
    aca0:	97ffeb04 	bl	58b0 <fwp_data.part.0.constprop.0>
    aca4:	91190283 	add	x3, x20, #0x640
    aca8:	aa0003f5 	mov	x21, x0
    acac:	f949d861 	ldr	x1, [x3, #5040]
    acb0:	f949ec60 	ldr	x0, [x3, #5080]
    acb4:	cb0102a1 	sub	x1, x21, x1
    acb8:	eb00403f 	cmp	x1, x0, lsl #16
    acbc:	54000322 	b.cs	ad20 <f0+0x78c>  // b.hs, b.nlast
    acc0:	d350fc22 	lsr	x2, x1, #16
    acc4:	f949fc63 	ldr	x3, [x3, #5112]
    acc8:	8b020842 	add	x2, x2, x2, lsl #2
    accc:	d37df042 	lsl	x2, x2, #3
    acd0:	8b020060 	add	x0, x3, x2
    acd4:	f9401017 	ldr	x23, [x0, #32]
    acd8:	b4000257 	cbz	x23, ad20 <f0+0x78c>
    acdc:	38626862 	ldrb	w2, [x3, x2]
    ace0:	7100085f 	cmp	w2, #0x2
    ace4:	5400e380 	b.eq	c954 <f0+0x23c0>  // b.none
    ace8:	7100045f 	cmp	w2, #0x1
    acec:	540001a1 	b.ne	ad20 <f0+0x78c>  // b.any
    acf0:	29430002 	ldp	w2, w0, [x0, #24]
    acf4:	92403c21 	and	x1, x1, #0xffff
    acf8:	9b027c21 	mul	x1, x1, x2
    acfc:	d360fc21 	lsr	x1, x1, #32
    ad00:	eb00003f 	cmp	x1, x0
    ad04:	540000e2 	b.cs	ad20 <f0+0x78c>  // b.hs, b.nlast
    ad08:	8b0102f7 	add	x23, x23, x1
    ad0c:	394002e0 	ldrb	w0, [x23]
    ad10:	7103fc1f 	cmp	w0, #0xff
    ad14:	5400eb60 	b.eq	ca80 <f0+0x24ec>  // b.none
    ad18:	52800020 	mov	w0, #0x1                   	// #1
    ad1c:	390002e0 	strb	w0, [x23]
    ad20:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad24:	910723e1 	add	x1, sp, #0x1c8
    ad28:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad2c:	52800020 	mov	w0, #0x1                   	// #1
    ad30:	a91cd7e2 	stp	x2, x21, [sp, #456]
    ad34:	97ffeadf 	bl	58b0 <fwp_data.part.0.constprop.0>
    ad38:	97ffeb62 	bl	5ac0 <fwp_rc_fresh>
    ad3c:	aa0003e2 	mov	x2, x0
    ad40:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ad44:	910763e1 	add	x1, sp, #0x1d8
    ad48:	52800020 	mov	w0, #0x1                   	// #1
    ad4c:	a91d8be3 	stp	x3, x2, [sp, #472]
    ad50:	97ffead8 	bl	58b0 <fwp_data.part.0.constprop.0>
    ad54:	91190283 	add	x3, x20, #0x640
    ad58:	aa0003f5 	mov	x21, x0
    ad5c:	f949d861 	ldr	x1, [x3, #5040]
    ad60:	f949ec60 	ldr	x0, [x3, #5080]
    ad64:	cb0102a1 	sub	x1, x21, x1
    ad68:	eb00403f 	cmp	x1, x0, lsl #16
    ad6c:	54000322 	b.cs	add0 <f0+0x83c>  // b.hs, b.nlast
    ad70:	d350fc22 	lsr	x2, x1, #16
    ad74:	f949fc63 	ldr	x3, [x3, #5112]
    ad78:	8b020842 	add	x2, x2, x2, lsl #2
    ad7c:	d37df042 	lsl	x2, x2, #3
    ad80:	8b020060 	add	x0, x3, x2
    ad84:	f9401017 	ldr	x23, [x0, #32]
    ad88:	b4000257 	cbz	x23, add0 <f0+0x83c>
    ad8c:	38626862 	ldrb	w2, [x3, x2]
    ad90:	7100085f 	cmp	w2, #0x2
    ad94:	5400dda0 	b.eq	c948 <f0+0x23b4>  // b.none
    ad98:	7100045f 	cmp	w2, #0x1
    ad9c:	540001a1 	b.ne	add0 <f0+0x83c>  // b.any
    ada0:	29430002 	ldp	w2, w0, [x0, #24]
    ada4:	92403c21 	and	x1, x1, #0xffff
    ada8:	9b027c21 	mul	x1, x1, x2
    adac:	d360fc21 	lsr	x1, x1, #32
    adb0:	eb00003f 	cmp	x1, x0
    adb4:	540000e2 	b.cs	add0 <f0+0x83c>  // b.hs, b.nlast
    adb8:	8b0102f7 	add	x23, x23, x1
    adbc:	394002e0 	ldrb	w0, [x23]
    adc0:	7103fc1f 	cmp	w0, #0xff
    adc4:	5400e640 	b.eq	ca8c <f0+0x24f8>  // b.none
    adc8:	52800020 	mov	w0, #0x1                   	// #1
    adcc:	390002e0 	strb	w0, [x23]
    add0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    add4:	9107a3e1 	add	x1, sp, #0x1e8
    add8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    addc:	52800020 	mov	w0, #0x1                   	// #1
    ade0:	a91ed7e2 	stp	x2, x21, [sp, #488]
    ade4:	97ffeab3 	bl	58b0 <fwp_data.part.0.constprop.0>
    ade8:	91190283 	add	x3, x20, #0x640
    adec:	aa0003f5 	mov	x21, x0
    adf0:	f949d861 	ldr	x1, [x3, #5040]
    adf4:	f949ec60 	ldr	x0, [x3, #5080]
    adf8:	cb0102a1 	sub	x1, x21, x1
    adfc:	eb00403f 	cmp	x1, x0, lsl #16
    ae00:	54000322 	b.cs	ae64 <f0+0x8d0>  // b.hs, b.nlast
    ae04:	d350fc22 	lsr	x2, x1, #16
    ae08:	f949fc63 	ldr	x3, [x3, #5112]
    ae0c:	8b020842 	add	x2, x2, x2, lsl #2
    ae10:	d37df042 	lsl	x2, x2, #3
    ae14:	8b020060 	add	x0, x3, x2
    ae18:	f9401017 	ldr	x23, [x0, #32]
    ae1c:	b4000257 	cbz	x23, ae64 <f0+0x8d0>
    ae20:	38626862 	ldrb	w2, [x3, x2]
    ae24:	7100085f 	cmp	w2, #0x2
    ae28:	5400d8a0 	b.eq	c93c <f0+0x23a8>  // b.none
    ae2c:	7100045f 	cmp	w2, #0x1
    ae30:	540001a1 	b.ne	ae64 <f0+0x8d0>  // b.any
    ae34:	29430002 	ldp	w2, w0, [x0, #24]
    ae38:	92403c21 	and	x1, x1, #0xffff
    ae3c:	9b027c21 	mul	x1, x1, x2
    ae40:	d360fc21 	lsr	x1, x1, #32
    ae44:	eb00003f 	cmp	x1, x0
    ae48:	540000e2 	b.cs	ae64 <f0+0x8d0>  // b.hs, b.nlast
    ae4c:	8b0102f7 	add	x23, x23, x1
    ae50:	394002e0 	ldrb	w0, [x23]
    ae54:	7103fc1f 	cmp	w0, #0xff
    ae58:	5400e200 	b.eq	ca98 <f0+0x2504>  // b.none
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	390002e0 	strb	w0, [x23]
    ae64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae68:	9107e3e1 	add	x1, sp, #0x1f8
    ae6c:	52800020 	mov	w0, #0x1                   	// #1
    ae70:	a91fd7e2 	stp	x2, x21, [sp, #504]
    ae74:	97ffea8f 	bl	58b0 <fwp_data.part.0.constprop.0>
    ae78:	91190283 	add	x3, x20, #0x640
    ae7c:	aa0003f7 	mov	x23, x0
    ae80:	f949d861 	ldr	x1, [x3, #5040]
    ae84:	f949ec60 	ldr	x0, [x3, #5080]
    ae88:	cb0102e1 	sub	x1, x23, x1
    ae8c:	eb00403f 	cmp	x1, x0, lsl #16
    ae90:	54000322 	b.cs	aef4 <f0+0x960>  // b.hs, b.nlast
    ae94:	d350fc22 	lsr	x2, x1, #16
    ae98:	f949fc63 	ldr	x3, [x3, #5112]
    ae9c:	8b020842 	add	x2, x2, x2, lsl #2
    aea0:	d37df042 	lsl	x2, x2, #3
    aea4:	8b020060 	add	x0, x3, x2
    aea8:	f9401015 	ldr	x21, [x0, #32]
    aeac:	b4000255 	cbz	x21, aef4 <f0+0x960>
    aeb0:	38626862 	ldrb	w2, [x3, x2]
    aeb4:	7100085f 	cmp	w2, #0x2
    aeb8:	5400d3c0 	b.eq	c930 <f0+0x239c>  // b.none
    aebc:	7100045f 	cmp	w2, #0x1
    aec0:	540001a1 	b.ne	aef4 <f0+0x960>  // b.any
    aec4:	29430002 	ldp	w2, w0, [x0, #24]
    aec8:	92403c21 	and	x1, x1, #0xffff
    aecc:	9b027c21 	mul	x1, x1, x2
    aed0:	d360fc21 	lsr	x1, x1, #32
    aed4:	eb00003f 	cmp	x1, x0
    aed8:	540000e2 	b.cs	aef4 <f0+0x960>  // b.hs, b.nlast
    aedc:	8b0102b5 	add	x21, x21, x1
    aee0:	394002a0 	ldrb	w0, [x21]
    aee4:	7103fc1f 	cmp	w0, #0xff
    aee8:	5400dde0 	b.eq	caa4 <f0+0x2510>  // b.none
    aeec:	52800020 	mov	w0, #0x1                   	// #1
    aef0:	390002a0 	strb	w0, [x21]
    aef4:	910823e1 	add	x1, sp, #0x208
    aef8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    aefc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    af00:	52800020 	mov	w0, #0x1                   	// #1
    af04:	f90107f5 	str	x21, [sp, #520]
    af08:	f9010bf7 	str	x23, [sp, #528]
    af0c:	97ffea69 	bl	58b0 <fwp_data.part.0.constprop.0>
    af10:	97ffeaec 	bl	5ac0 <fwp_rc_fresh>
    af14:	aa0003e2 	mov	x2, x0
    af18:	910863e1 	add	x1, sp, #0x218
    af1c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af20:	52800020 	mov	w0, #0x1                   	// #1
    af24:	f9010ff7 	str	x23, [sp, #536]
    af28:	f90113e2 	str	x2, [sp, #544]
    af2c:	97ffea61 	bl	58b0 <fwp_data.part.0.constprop.0>
    af30:	97ffeae4 	bl	5ac0 <fwp_rc_fresh>
    af34:	aa0003e2 	mov	x2, x0
    af38:	9108a3e1 	add	x1, sp, #0x228
    af3c:	52800020 	mov	w0, #0x1                   	// #1
    af40:	f90117f5 	str	x21, [sp, #552]
    af44:	f9011be2 	str	x2, [sp, #560]
    af48:	97ffea5a 	bl	58b0 <fwp_data.part.0.constprop.0>
    af4c:	97ffeadd 	bl	5ac0 <fwp_rc_fresh>
    af50:	aa0003e2 	mov	x2, x0
    af54:	9108e3e1 	add	x1, sp, #0x238
    af58:	52800020 	mov	w0, #0x1                   	// #1
    af5c:	f9011ff7 	str	x23, [sp, #568]
    af60:	f90123e2 	str	x2, [sp, #576]
    af64:	97ffea53 	bl	58b0 <fwp_data.part.0.constprop.0>
    af68:	97ffead6 	bl	5ac0 <fwp_rc_fresh>
    af6c:	aa0003e2 	mov	x2, x0
    af70:	910923e1 	add	x1, sp, #0x248
    af74:	52800020 	mov	w0, #0x1                   	// #1
    af78:	f90127f5 	str	x21, [sp, #584]
    af7c:	f9012be2 	str	x2, [sp, #592]
    af80:	97ffea4c 	bl	58b0 <fwp_data.part.0.constprop.0>
    af84:	97ffeacf 	bl	5ac0 <fwp_rc_fresh>
    af88:	aa0003e2 	mov	x2, x0
    af8c:	910963e1 	add	x1, sp, #0x258
    af90:	52800020 	mov	w0, #0x1                   	// #1
    af94:	f9012ff7 	str	x23, [sp, #600]
    af98:	f90133e2 	str	x2, [sp, #608]
    af9c:	97ffea45 	bl	58b0 <fwp_data.part.0.constprop.0>
    afa0:	97ffeac8 	bl	5ac0 <fwp_rc_fresh>
    afa4:	aa0003e2 	mov	x2, x0
    afa8:	9109a3e1 	add	x1, sp, #0x268
    afac:	52800020 	mov	w0, #0x1                   	// #1
    afb0:	f90137f5 	str	x21, [sp, #616]
    afb4:	f9013be2 	str	x2, [sp, #624]
    afb8:	97ffea3e 	bl	58b0 <fwp_data.part.0.constprop.0>
    afbc:	91190283 	add	x3, x20, #0x640
    afc0:	aa0003f5 	mov	x21, x0
    afc4:	f949d861 	ldr	x1, [x3, #5040]
    afc8:	f949ec60 	ldr	x0, [x3, #5080]
    afcc:	cb0102a1 	sub	x1, x21, x1
    afd0:	eb00403f 	cmp	x1, x0, lsl #16
    afd4:	54000322 	b.cs	b038 <f0+0xaa4>  // b.hs, b.nlast
    afd8:	d350fc22 	lsr	x2, x1, #16
    afdc:	f949fc63 	ldr	x3, [x3, #5112]
    afe0:	8b020842 	add	x2, x2, x2, lsl #2
    afe4:	d37df042 	lsl	x2, x2, #3
    afe8:	8b020060 	add	x0, x3, x2
    afec:	f9401017 	ldr	x23, [x0, #32]
    aff0:	b4000257 	cbz	x23, b038 <f0+0xaa4>
    aff4:	38626862 	ldrb	w2, [x3, x2]
    aff8:	7100085f 	cmp	w2, #0x2
    affc:	5400c940 	b.eq	c924 <f0+0x2390>  // b.none
    b000:	7100045f 	cmp	w2, #0x1
    b004:	540001a1 	b.ne	b038 <f0+0xaa4>  // b.any
    b008:	29430002 	ldp	w2, w0, [x0, #24]
    b00c:	92403c21 	and	x1, x1, #0xffff
    b010:	9b027c21 	mul	x1, x1, x2
    b014:	d360fc21 	lsr	x1, x1, #32
    b018:	eb00003f 	cmp	x1, x0
    b01c:	540000e2 	b.cs	b038 <f0+0xaa4>  // b.hs, b.nlast
    b020:	8b0102f7 	add	x23, x23, x1
    b024:	394002e0 	ldrb	w0, [x23]
    b028:	7103fc1f 	cmp	w0, #0xff
    b02c:	5400d420 	b.eq	cab0 <f0+0x251c>  // b.none
    b030:	52800020 	mov	w0, #0x1                   	// #1
    b034:	390002e0 	strb	w0, [x23]
    b038:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b03c:	9109e3e1 	add	x1, sp, #0x278
    b040:	52800020 	mov	w0, #0x1                   	// #1
    b044:	f9013fe2 	str	x2, [sp, #632]
    b048:	f90143f5 	str	x21, [sp, #640]
    b04c:	97ffea19 	bl	58b0 <fwp_data.part.0.constprop.0>
    b050:	91190283 	add	x3, x20, #0x640
    b054:	aa0003f5 	mov	x21, x0
    b058:	f949d861 	ldr	x1, [x3, #5040]
    b05c:	f949ec60 	ldr	x0, [x3, #5080]
    b060:	cb0102a1 	sub	x1, x21, x1
    b064:	eb00403f 	cmp	x1, x0, lsl #16
    b068:	54000322 	b.cs	b0cc <f0+0xb38>  // b.hs, b.nlast
    b06c:	d350fc22 	lsr	x2, x1, #16
    b070:	f949fc63 	ldr	x3, [x3, #5112]
    b074:	8b020842 	add	x2, x2, x2, lsl #2
    b078:	d37df042 	lsl	x2, x2, #3
    b07c:	8b020060 	add	x0, x3, x2
    b080:	f9401017 	ldr	x23, [x0, #32]
    b084:	b4000257 	cbz	x23, b0cc <f0+0xb38>
    b088:	38626862 	ldrb	w2, [x3, x2]
    b08c:	7100085f 	cmp	w2, #0x2
    b090:	5400c440 	b.eq	c918 <f0+0x2384>  // b.none
    b094:	7100045f 	cmp	w2, #0x1
    b098:	540001a1 	b.ne	b0cc <f0+0xb38>  // b.any
    b09c:	29430002 	ldp	w2, w0, [x0, #24]
    b0a0:	92403c21 	and	x1, x1, #0xffff
    b0a4:	9b027c21 	mul	x1, x1, x2
    b0a8:	d360fc21 	lsr	x1, x1, #32
    b0ac:	eb00003f 	cmp	x1, x0
    b0b0:	540000e2 	b.cs	b0cc <f0+0xb38>  // b.hs, b.nlast
    b0b4:	8b0102f7 	add	x23, x23, x1
    b0b8:	394002e0 	ldrb	w0, [x23]
    b0bc:	7103fc1f 	cmp	w0, #0xff
    b0c0:	5400cfe0 	b.eq	cabc <f0+0x2528>  // b.none
    b0c4:	52800020 	mov	w0, #0x1                   	// #1
    b0c8:	390002e0 	strb	w0, [x23]
    b0cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b0d0:	910a23e1 	add	x1, sp, #0x288
    b0d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b0d8:	52800020 	mov	w0, #0x1                   	// #1
    b0dc:	f90147e2 	str	x2, [sp, #648]
    b0e0:	f9014bf5 	str	x21, [sp, #656]
    b0e4:	97ffe9f3 	bl	58b0 <fwp_data.part.0.constprop.0>
    b0e8:	97ffea76 	bl	5ac0 <fwp_rc_fresh>
    b0ec:	aa0003e2 	mov	x2, x0
    b0f0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b0f4:	910a63e1 	add	x1, sp, #0x298
    b0f8:	52800020 	mov	w0, #0x1                   	// #1
    b0fc:	f9014fe3 	str	x3, [sp, #664]
    b100:	f90153e2 	str	x2, [sp, #672]
    b104:	97ffe9eb 	bl	58b0 <fwp_data.part.0.constprop.0>
    b108:	91190283 	add	x3, x20, #0x640
    b10c:	aa0003f5 	mov	x21, x0
    b110:	f949d861 	ldr	x1, [x3, #5040]
    b114:	f949ec60 	ldr	x0, [x3, #5080]
    b118:	cb0102a1 	sub	x1, x21, x1
    b11c:	eb00403f 	cmp	x1, x0, lsl #16
    b120:	54000322 	b.cs	b184 <f0+0xbf0>  // b.hs, b.nlast
    b124:	d350fc22 	lsr	x2, x1, #16
    b128:	f949fc63 	ldr	x3, [x3, #5112]
    b12c:	8b020842 	add	x2, x2, x2, lsl #2
    b130:	d37df042 	lsl	x2, x2, #3
    b134:	8b020060 	add	x0, x3, x2
    b138:	f9401017 	ldr	x23, [x0, #32]
    b13c:	b4000257 	cbz	x23, b184 <f0+0xbf0>
    b140:	38626862 	ldrb	w2, [x3, x2]
    b144:	7100085f 	cmp	w2, #0x2
    b148:	5400be20 	b.eq	c90c <f0+0x2378>  // b.none
    b14c:	7100045f 	cmp	w2, #0x1
    b150:	540001a1 	b.ne	b184 <f0+0xbf0>  // b.any
    b154:	29430002 	ldp	w2, w0, [x0, #24]
    b158:	92403c21 	and	x1, x1, #0xffff
    b15c:	9b027c21 	mul	x1, x1, x2
    b160:	d360fc21 	lsr	x1, x1, #32
    b164:	eb00003f 	cmp	x1, x0
    b168:	540000e2 	b.cs	b184 <f0+0xbf0>  // b.hs, b.nlast
    b16c:	8b0102f7 	add	x23, x23, x1
    b170:	394002e0 	ldrb	w0, [x23]
    b174:	7103fc1f 	cmp	w0, #0xff
    b178:	5400ca80 	b.eq	cac8 <f0+0x2534>  // b.none
    b17c:	52800020 	mov	w0, #0x1                   	// #1
    b180:	390002e0 	strb	w0, [x23]
    b184:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b188:	910aa3e1 	add	x1, sp, #0x2a8
    b18c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b190:	52800020 	mov	w0, #0x1                   	// #1
    b194:	f90157e2 	str	x2, [sp, #680]
    b198:	f9015bf5 	str	x21, [sp, #688]
    b19c:	97ffe9c5 	bl	58b0 <fwp_data.part.0.constprop.0>
    b1a0:	97ffea48 	bl	5ac0 <fwp_rc_fresh>
    b1a4:	aa0003e2 	mov	x2, x0
    b1a8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b1ac:	910ae3e1 	add	x1, sp, #0x2b8
    b1b0:	52800020 	mov	w0, #0x1                   	// #1
    b1b4:	f9015fe3 	str	x3, [sp, #696]
    b1b8:	f90163e2 	str	x2, [sp, #704]
    b1bc:	97ffe9bd 	bl	58b0 <fwp_data.part.0.constprop.0>
    b1c0:	91190283 	add	x3, x20, #0x640
    b1c4:	aa0003f5 	mov	x21, x0
    b1c8:	f949d861 	ldr	x1, [x3, #5040]
    b1cc:	f949ec60 	ldr	x0, [x3, #5080]
    b1d0:	cb0102a1 	sub	x1, x21, x1
    b1d4:	eb00403f 	cmp	x1, x0, lsl #16
    b1d8:	54000322 	b.cs	b23c <f0+0xca8>  // b.hs, b.nlast
    b1dc:	d350fc22 	lsr	x2, x1, #16
    b1e0:	f949fc63 	ldr	x3, [x3, #5112]
    b1e4:	8b020842 	add	x2, x2, x2, lsl #2
    b1e8:	d37df042 	lsl	x2, x2, #3
    b1ec:	8b020060 	add	x0, x3, x2
    b1f0:	f9401017 	ldr	x23, [x0, #32]
    b1f4:	b4000257 	cbz	x23, b23c <f0+0xca8>
    b1f8:	38626862 	ldrb	w2, [x3, x2]
    b1fc:	7100085f 	cmp	w2, #0x2
    b200:	5400b800 	b.eq	c900 <f0+0x236c>  // b.none
    b204:	7100045f 	cmp	w2, #0x1
    b208:	540001a1 	b.ne	b23c <f0+0xca8>  // b.any
    b20c:	29430002 	ldp	w2, w0, [x0, #24]
    b210:	92403c21 	and	x1, x1, #0xffff
    b214:	9b027c21 	mul	x1, x1, x2
    b218:	d360fc21 	lsr	x1, x1, #32
    b21c:	eb00003f 	cmp	x1, x0
    b220:	540000e2 	b.cs	b23c <f0+0xca8>  // b.hs, b.nlast
    b224:	8b0102f7 	add	x23, x23, x1
    b228:	394002e0 	ldrb	w0, [x23]
    b22c:	7103fc1f 	cmp	w0, #0xff
    b230:	5400c520 	b.eq	cad4 <f0+0x2540>  // b.none
    b234:	52800020 	mov	w0, #0x1                   	// #1
    b238:	390002e0 	strb	w0, [x23]
    b23c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b240:	910b23e1 	add	x1, sp, #0x2c8
    b244:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b248:	52800020 	mov	w0, #0x1                   	// #1
    b24c:	f90167e2 	str	x2, [sp, #712]
    b250:	f9016bf5 	str	x21, [sp, #720]
    b254:	97ffe997 	bl	58b0 <fwp_data.part.0.constprop.0>
    b258:	97ffea1a 	bl	5ac0 <fwp_rc_fresh>
    b25c:	aa0003e2 	mov	x2, x0
    b260:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b264:	910b63e1 	add	x1, sp, #0x2d8
    b268:	52800020 	mov	w0, #0x1                   	// #1
    b26c:	f9016fe3 	str	x3, [sp, #728]
    b270:	f90173e2 	str	x2, [sp, #736]
    b274:	97ffe98f 	bl	58b0 <fwp_data.part.0.constprop.0>
    b278:	91190283 	add	x3, x20, #0x640
    b27c:	aa0003f5 	mov	x21, x0
    b280:	f949d861 	ldr	x1, [x3, #5040]
    b284:	f949ec60 	ldr	x0, [x3, #5080]
    b288:	cb0102a1 	sub	x1, x21, x1
    b28c:	eb00403f 	cmp	x1, x0, lsl #16
    b290:	54000322 	b.cs	b2f4 <f0+0xd60>  // b.hs, b.nlast
    b294:	d350fc22 	lsr	x2, x1, #16
    b298:	f949fc63 	ldr	x3, [x3, #5112]
    b29c:	8b020842 	add	x2, x2, x2, lsl #2
    b2a0:	d37df042 	lsl	x2, x2, #3
    b2a4:	8b020060 	add	x0, x3, x2
    b2a8:	f9401017 	ldr	x23, [x0, #32]
    b2ac:	b4000257 	cbz	x23, b2f4 <f0+0xd60>
    b2b0:	38626862 	ldrb	w2, [x3, x2]
    b2b4:	7100085f 	cmp	w2, #0x2
    b2b8:	5400af40 	b.eq	c8a0 <f0+0x230c>  // b.none
    b2bc:	7100045f 	cmp	w2, #0x1
    b2c0:	540001a1 	b.ne	b2f4 <f0+0xd60>  // b.any
    b2c4:	29430002 	ldp	w2, w0, [x0, #24]
    b2c8:	92403c21 	and	x1, x1, #0xffff
    b2cc:	9b027c21 	mul	x1, x1, x2
    b2d0:	d360fc21 	lsr	x1, x1, #32
    b2d4:	eb00003f 	cmp	x1, x0
    b2d8:	540000e2 	b.cs	b2f4 <f0+0xd60>  // b.hs, b.nlast
    b2dc:	8b0102f7 	add	x23, x23, x1
    b2e0:	394002e0 	ldrb	w0, [x23]
    b2e4:	7103fc1f 	cmp	w0, #0xff
    b2e8:	5400bfc0 	b.eq	cae0 <f0+0x254c>  // b.none
    b2ec:	52800020 	mov	w0, #0x1                   	// #1
    b2f0:	390002e0 	strb	w0, [x23]
    b2f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b2f8:	910ba3e1 	add	x1, sp, #0x2e8
    b2fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b300:	52800020 	mov	w0, #0x1                   	// #1
    b304:	f90177e2 	str	x2, [sp, #744]
    b308:	f9017bf5 	str	x21, [sp, #752]
    b30c:	97ffe969 	bl	58b0 <fwp_data.part.0.constprop.0>
    b310:	91190283 	add	x3, x20, #0x640
    b314:	aa0003f7 	mov	x23, x0
    b318:	f949d861 	ldr	x1, [x3, #5040]
    b31c:	f949ec60 	ldr	x0, [x3, #5080]
    b320:	cb0102e1 	sub	x1, x23, x1
    b324:	eb00403f 	cmp	x1, x0, lsl #16
    b328:	54000322 	b.cs	b38c <f0+0xdf8>  // b.hs, b.nlast
    b32c:	d350fc22 	lsr	x2, x1, #16
    b330:	f949fc63 	ldr	x3, [x3, #5112]
    b334:	8b020842 	add	x2, x2, x2, lsl #2
    b338:	d37df042 	lsl	x2, x2, #3
    b33c:	8b020060 	add	x0, x3, x2
    b340:	f9401015 	ldr	x21, [x0, #32]
    b344:	b4000255 	cbz	x21, b38c <f0+0xdf8>
    b348:	38626862 	ldrb	w2, [x3, x2]
    b34c:	7100085f 	cmp	w2, #0x2
    b350:	5400aa20 	b.eq	c894 <f0+0x2300>  // b.none
    b354:	7100045f 	cmp	w2, #0x1
    b358:	540001a1 	b.ne	b38c <f0+0xdf8>  // b.any
    b35c:	29430002 	ldp	w2, w0, [x0, #24]
    b360:	92403c21 	and	x1, x1, #0xffff
    b364:	9b027c21 	mul	x1, x1, x2
    b368:	d360fc21 	lsr	x1, x1, #32
    b36c:	eb00003f 	cmp	x1, x0
    b370:	540000e2 	b.cs	b38c <f0+0xdf8>  // b.hs, b.nlast
    b374:	8b0102b5 	add	x21, x21, x1
    b378:	394002a0 	ldrb	w0, [x21]
    b37c:	7103fc1f 	cmp	w0, #0xff
    b380:	5400bb60 	b.eq	caec <f0+0x2558>  // b.none
    b384:	52800020 	mov	w0, #0x1                   	// #1
    b388:	390002a0 	strb	w0, [x21]
    b38c:	910be3e1 	add	x1, sp, #0x2f8
    b390:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b394:	52800020 	mov	w0, #0x1                   	// #1
    b398:	f9017ff5 	str	x21, [sp, #760]
    b39c:	f90183f7 	str	x23, [sp, #768]
    b3a0:	97ffe944 	bl	58b0 <fwp_data.part.0.constprop.0>
    b3a4:	97ffe9c7 	bl	5ac0 <fwp_rc_fresh>
    b3a8:	aa0003e2 	mov	x2, x0
    b3ac:	910c23e1 	add	x1, sp, #0x308
    b3b0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b3b4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b3b8:	52800020 	mov	w0, #0x1                   	// #1
    b3bc:	f90187f7 	str	x23, [sp, #776]
    b3c0:	f9018be2 	str	x2, [sp, #784]
    b3c4:	97ffe93b 	bl	58b0 <fwp_data.part.0.constprop.0>
    b3c8:	97ffe9be 	bl	5ac0 <fwp_rc_fresh>
    b3cc:	aa0003e2 	mov	x2, x0
    b3d0:	910c63e1 	add	x1, sp, #0x318
    b3d4:	52800020 	mov	w0, #0x1                   	// #1
    b3d8:	f9018ff5 	str	x21, [sp, #792]
    b3dc:	f90193e2 	str	x2, [sp, #800]
    b3e0:	97ffe934 	bl	58b0 <fwp_data.part.0.constprop.0>
    b3e4:	97ffe9b7 	bl	5ac0 <fwp_rc_fresh>
    b3e8:	aa0003e2 	mov	x2, x0
    b3ec:	910ca3e1 	add	x1, sp, #0x328
    b3f0:	52800020 	mov	w0, #0x1                   	// #1
    b3f4:	f90197f7 	str	x23, [sp, #808]
    b3f8:	f9019be2 	str	x2, [sp, #816]
    b3fc:	97ffe92d 	bl	58b0 <fwp_data.part.0.constprop.0>
    b400:	97ffe9b0 	bl	5ac0 <fwp_rc_fresh>
    b404:	aa0003e2 	mov	x2, x0
    b408:	910ce3e1 	add	x1, sp, #0x338
    b40c:	52800020 	mov	w0, #0x1                   	// #1
    b410:	f9019ff5 	str	x21, [sp, #824]
    b414:	f901a3e2 	str	x2, [sp, #832]
    b418:	97ffe926 	bl	58b0 <fwp_data.part.0.constprop.0>
    b41c:	97ffe9a9 	bl	5ac0 <fwp_rc_fresh>
    b420:	aa0003e2 	mov	x2, x0
    b424:	910d23e1 	add	x1, sp, #0x348
    b428:	52800020 	mov	w0, #0x1                   	// #1
    b42c:	f901a7f7 	str	x23, [sp, #840]
    b430:	f901abe2 	str	x2, [sp, #848]
    b434:	97ffe91f 	bl	58b0 <fwp_data.part.0.constprop.0>
    b438:	97ffe9a2 	bl	5ac0 <fwp_rc_fresh>
    b43c:	aa0003e2 	mov	x2, x0
    b440:	910d63e1 	add	x1, sp, #0x358
    b444:	52800020 	mov	w0, #0x1                   	// #1
    b448:	f901aff5 	str	x21, [sp, #856]
    b44c:	f901b3e2 	str	x2, [sp, #864]
    b450:	97ffe918 	bl	58b0 <fwp_data.part.0.constprop.0>
    b454:	97ffe99b 	bl	5ac0 <fwp_rc_fresh>
    b458:	aa0003e2 	mov	x2, x0
    b45c:	910da3e1 	add	x1, sp, #0x368
    b460:	52800020 	mov	w0, #0x1                   	// #1
    b464:	f901b7f7 	str	x23, [sp, #872]
    b468:	f901bbe2 	str	x2, [sp, #880]
    b46c:	97ffe911 	bl	58b0 <fwp_data.part.0.constprop.0>
    b470:	97ffe994 	bl	5ac0 <fwp_rc_fresh>
    b474:	aa0003e2 	mov	x2, x0
    b478:	910de3e1 	add	x1, sp, #0x378
    b47c:	52800020 	mov	w0, #0x1                   	// #1
    b480:	f901bff5 	str	x21, [sp, #888]
    b484:	f901c3e2 	str	x2, [sp, #896]
    b488:	97ffe90a 	bl	58b0 <fwp_data.part.0.constprop.0>
    b48c:	97ffe98d 	bl	5ac0 <fwp_rc_fresh>
    b490:	aa0003e2 	mov	x2, x0
    b494:	910e23e1 	add	x1, sp, #0x388
    b498:	52800020 	mov	w0, #0x1                   	// #1
    b49c:	f901c7f7 	str	x23, [sp, #904]
    b4a0:	f901cbe2 	str	x2, [sp, #912]
    b4a4:	97ffe903 	bl	58b0 <fwp_data.part.0.constprop.0>
    b4a8:	97ffe986 	bl	5ac0 <fwp_rc_fresh>
    b4ac:	aa0003e2 	mov	x2, x0
    b4b0:	910e63e1 	add	x1, sp, #0x398
    b4b4:	52800020 	mov	w0, #0x1                   	// #1
    b4b8:	f901cff5 	str	x21, [sp, #920]
    b4bc:	f901d3e2 	str	x2, [sp, #928]
    b4c0:	97ffe8fc 	bl	58b0 <fwp_data.part.0.constprop.0>
    b4c4:	97ffe97f 	bl	5ac0 <fwp_rc_fresh>
    b4c8:	aa0003e2 	mov	x2, x0
    b4cc:	910ea3e1 	add	x1, sp, #0x3a8
    b4d0:	52800020 	mov	w0, #0x1                   	// #1
    b4d4:	f901d7f7 	str	x23, [sp, #936]
    b4d8:	f901dbe2 	str	x2, [sp, #944]
    b4dc:	97ffe8f5 	bl	58b0 <fwp_data.part.0.constprop.0>
    b4e0:	97ffe978 	bl	5ac0 <fwp_rc_fresh>
    b4e4:	aa0003e2 	mov	x2, x0
    b4e8:	910ee3e1 	add	x1, sp, #0x3b8
    b4ec:	52800020 	mov	w0, #0x1                   	// #1
    b4f0:	f901dff5 	str	x21, [sp, #952]
    b4f4:	f901e3e2 	str	x2, [sp, #960]
    b4f8:	97ffe8ee 	bl	58b0 <fwp_data.part.0.constprop.0>
    b4fc:	91190283 	add	x3, x20, #0x640
    b500:	aa0003f5 	mov	x21, x0
    b504:	f949d861 	ldr	x1, [x3, #5040]
    b508:	f949ec60 	ldr	x0, [x3, #5080]
    b50c:	cb0102a1 	sub	x1, x21, x1
    b510:	eb00403f 	cmp	x1, x0, lsl #16
    b514:	54000322 	b.cs	b578 <f0+0xfe4>  // b.hs, b.nlast
    b518:	d350fc22 	lsr	x2, x1, #16
    b51c:	f949fc63 	ldr	x3, [x3, #5112]
    b520:	8b020842 	add	x2, x2, x2, lsl #2
    b524:	d37df042 	lsl	x2, x2, #3
    b528:	8b020060 	add	x0, x3, x2
    b52c:	f9401017 	ldr	x23, [x0, #32]
    b530:	b4000257 	cbz	x23, b578 <f0+0xfe4>
    b534:	38626862 	ldrb	w2, [x3, x2]
    b538:	7100085f 	cmp	w2, #0x2
    b53c:	54009a60 	b.eq	c888 <f0+0x22f4>  // b.none
    b540:	7100045f 	cmp	w2, #0x1
    b544:	540001a1 	b.ne	b578 <f0+0xfe4>  // b.any
    b548:	29430002 	ldp	w2, w0, [x0, #24]
    b54c:	92403c21 	and	x1, x1, #0xffff
    b550:	9b027c21 	mul	x1, x1, x2
    b554:	d360fc21 	lsr	x1, x1, #32
    b558:	eb00003f 	cmp	x1, x0
    b55c:	540000e2 	b.cs	b578 <f0+0xfe4>  // b.hs, b.nlast
    b560:	8b0102f7 	add	x23, x23, x1
    b564:	394002e0 	ldrb	w0, [x23]
    b568:	7103fc1f 	cmp	w0, #0xff
    b56c:	5400ac60 	b.eq	caf8 <f0+0x2564>  // b.none
    b570:	52800020 	mov	w0, #0x1                   	// #1
    b574:	390002e0 	strb	w0, [x23]
    b578:	910f23e1 	add	x1, sp, #0x3c8
    b57c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b580:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	f901e7f7 	str	x23, [sp, #968]
    b58c:	f901ebf5 	str	x21, [sp, #976]
    b590:	97ffe8c8 	bl	58b0 <fwp_data.part.0.constprop.0>
    b594:	97ffe94b 	bl	5ac0 <fwp_rc_fresh>
    b598:	aa0003e2 	mov	x2, x0
    b59c:	910f63e1 	add	x1, sp, #0x3d8
    b5a0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b5a4:	52800020 	mov	w0, #0x1                   	// #1
    b5a8:	f901eff5 	str	x21, [sp, #984]
    b5ac:	f901f3e2 	str	x2, [sp, #992]
    b5b0:	97ffe8c0 	bl	58b0 <fwp_data.part.0.constprop.0>
    b5b4:	97ffe943 	bl	5ac0 <fwp_rc_fresh>
    b5b8:	aa0003e2 	mov	x2, x0
    b5bc:	910fa3e1 	add	x1, sp, #0x3e8
    b5c0:	52800020 	mov	w0, #0x1                   	// #1
    b5c4:	f901f7f7 	str	x23, [sp, #1000]
    b5c8:	f901fbe2 	str	x2, [sp, #1008]
    b5cc:	97ffe8b9 	bl	58b0 <fwp_data.part.0.constprop.0>
    b5d0:	97ffe93c 	bl	5ac0 <fwp_rc_fresh>
    b5d4:	aa0003e2 	mov	x2, x0
    b5d8:	910fe3e1 	add	x1, sp, #0x3f8
    b5dc:	52800020 	mov	w0, #0x1                   	// #1
    b5e0:	f901fff5 	str	x21, [sp, #1016]
    b5e4:	f90203e2 	str	x2, [sp, #1024]
    b5e8:	97ffe8b2 	bl	58b0 <fwp_data.part.0.constprop.0>
    b5ec:	91190283 	add	x3, x20, #0x640
    b5f0:	aa0003f7 	mov	x23, x0
    b5f4:	f949d861 	ldr	x1, [x3, #5040]
    b5f8:	f949ec60 	ldr	x0, [x3, #5080]
    b5fc:	cb0102e1 	sub	x1, x23, x1
    b600:	eb00403f 	cmp	x1, x0, lsl #16
    b604:	54000322 	b.cs	b668 <f0+0x10d4>  // b.hs, b.nlast
    b608:	d350fc22 	lsr	x2, x1, #16
    b60c:	f949fc63 	ldr	x3, [x3, #5112]
    b610:	8b020842 	add	x2, x2, x2, lsl #2
    b614:	d37df042 	lsl	x2, x2, #3
    b618:	8b020060 	add	x0, x3, x2
    b61c:	f9401015 	ldr	x21, [x0, #32]
    b620:	b4000255 	cbz	x21, b668 <f0+0x10d4>
    b624:	38626862 	ldrb	w2, [x3, x2]
    b628:	7100085f 	cmp	w2, #0x2
    b62c:	54009280 	b.eq	c87c <f0+0x22e8>  // b.none
    b630:	7100045f 	cmp	w2, #0x1
    b634:	540001a1 	b.ne	b668 <f0+0x10d4>  // b.any
    b638:	29430002 	ldp	w2, w0, [x0, #24]
    b63c:	92403c21 	and	x1, x1, #0xffff
    b640:	9b027c21 	mul	x1, x1, x2
    b644:	d360fc21 	lsr	x1, x1, #32
    b648:	eb00003f 	cmp	x1, x0
    b64c:	540000e2 	b.cs	b668 <f0+0x10d4>  // b.hs, b.nlast
    b650:	8b0102b5 	add	x21, x21, x1
    b654:	394002a0 	ldrb	w0, [x21]
    b658:	7103fc1f 	cmp	w0, #0xff
    b65c:	5400a540 	b.eq	cb04 <f0+0x2570>  // b.none
    b660:	52800020 	mov	w0, #0x1                   	// #1
    b664:	390002a0 	strb	w0, [x21]
    b668:	911023e1 	add	x1, sp, #0x408
    b66c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b670:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b674:	52800020 	mov	w0, #0x1                   	// #1
    b678:	f90207f5 	str	x21, [sp, #1032]
    b67c:	f9020bf7 	str	x23, [sp, #1040]
    b680:	97ffe88c 	bl	58b0 <fwp_data.part.0.constprop.0>
    b684:	97ffe90f 	bl	5ac0 <fwp_rc_fresh>
    b688:	aa0003e2 	mov	x2, x0
    b68c:	911063e1 	add	x1, sp, #0x418
    b690:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b694:	52800020 	mov	w0, #0x1                   	// #1
    b698:	f9020ff7 	str	x23, [sp, #1048]
    b69c:	f90213e2 	str	x2, [sp, #1056]
    b6a0:	97ffe884 	bl	58b0 <fwp_data.part.0.constprop.0>
    b6a4:	97ffe907 	bl	5ac0 <fwp_rc_fresh>
    b6a8:	aa0003e2 	mov	x2, x0
    b6ac:	9110a3e1 	add	x1, sp, #0x428
    b6b0:	52800020 	mov	w0, #0x1                   	// #1
    b6b4:	f90217f5 	str	x21, [sp, #1064]
    b6b8:	f9021be2 	str	x2, [sp, #1072]
    b6bc:	97ffe87d 	bl	58b0 <fwp_data.part.0.constprop.0>
    b6c0:	97ffe900 	bl	5ac0 <fwp_rc_fresh>
    b6c4:	aa0003e2 	mov	x2, x0
    b6c8:	9110e3e1 	add	x1, sp, #0x438
    b6cc:	52800020 	mov	w0, #0x1                   	// #1
    b6d0:	f9021ff7 	str	x23, [sp, #1080]
    b6d4:	f90223e2 	str	x2, [sp, #1088]
    b6d8:	97ffe876 	bl	58b0 <fwp_data.part.0.constprop.0>
    b6dc:	97ffe8f9 	bl	5ac0 <fwp_rc_fresh>
    b6e0:	aa0003e2 	mov	x2, x0
    b6e4:	911123e1 	add	x1, sp, #0x448
    b6e8:	52800020 	mov	w0, #0x1                   	// #1
    b6ec:	f90227f5 	str	x21, [sp, #1096]
    b6f0:	f9022be2 	str	x2, [sp, #1104]
    b6f4:	97ffe86f 	bl	58b0 <fwp_data.part.0.constprop.0>
    b6f8:	97ffe8f2 	bl	5ac0 <fwp_rc_fresh>
    b6fc:	aa0003e2 	mov	x2, x0
    b700:	911163e1 	add	x1, sp, #0x458
    b704:	52800020 	mov	w0, #0x1                   	// #1
    b708:	f9022ff7 	str	x23, [sp, #1112]
    b70c:	f90233e2 	str	x2, [sp, #1120]
    b710:	97ffe868 	bl	58b0 <fwp_data.part.0.constprop.0>
    b714:	97ffe8eb 	bl	5ac0 <fwp_rc_fresh>
    b718:	aa0003e2 	mov	x2, x0
    b71c:	9111a3e1 	add	x1, sp, #0x468
    b720:	52800020 	mov	w0, #0x1                   	// #1
    b724:	f90237f5 	str	x21, [sp, #1128]
    b728:	f9023be2 	str	x2, [sp, #1136]
    b72c:	97ffe861 	bl	58b0 <fwp_data.part.0.constprop.0>
    b730:	91190283 	add	x3, x20, #0x640
    b734:	aa0003f5 	mov	x21, x0
    b738:	f949d861 	ldr	x1, [x3, #5040]
    b73c:	f949ec60 	ldr	x0, [x3, #5080]
    b740:	cb0102a1 	sub	x1, x21, x1
    b744:	eb00403f 	cmp	x1, x0, lsl #16
    b748:	54000322 	b.cs	b7ac <f0+0x1218>  // b.hs, b.nlast
    b74c:	d350fc22 	lsr	x2, x1, #16
    b750:	f949fc63 	ldr	x3, [x3, #5112]
    b754:	8b020842 	add	x2, x2, x2, lsl #2
    b758:	d37df042 	lsl	x2, x2, #3
    b75c:	8b020060 	add	x0, x3, x2
    b760:	f9401017 	ldr	x23, [x0, #32]
    b764:	b4000257 	cbz	x23, b7ac <f0+0x1218>
    b768:	38626862 	ldrb	w2, [x3, x2]
    b76c:	7100085f 	cmp	w2, #0x2
    b770:	54008800 	b.eq	c870 <f0+0x22dc>  // b.none
    b774:	7100045f 	cmp	w2, #0x1
    b778:	540001a1 	b.ne	b7ac <f0+0x1218>  // b.any
    b77c:	29430002 	ldp	w2, w0, [x0, #24]
    b780:	92403c21 	and	x1, x1, #0xffff
    b784:	9b027c21 	mul	x1, x1, x2
    b788:	d360fc21 	lsr	x1, x1, #32
    b78c:	eb00003f 	cmp	x1, x0
    b790:	540000e2 	b.cs	b7ac <f0+0x1218>  // b.hs, b.nlast
    b794:	8b0102f7 	add	x23, x23, x1
    b798:	394002e0 	ldrb	w0, [x23]
    b79c:	7103fc1f 	cmp	w0, #0xff
    b7a0:	54009b80 	b.eq	cb10 <f0+0x257c>  // b.none
    b7a4:	52800020 	mov	w0, #0x1                   	// #1
    b7a8:	390002e0 	strb	w0, [x23]
    b7ac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b7b0:	9111e3e1 	add	x1, sp, #0x478
    b7b4:	52800020 	mov	w0, #0x1                   	// #1
    b7b8:	f9023fe2 	str	x2, [sp, #1144]
    b7bc:	f90243f5 	str	x21, [sp, #1152]
    b7c0:	97ffe83c 	bl	58b0 <fwp_data.part.0.constprop.0>
    b7c4:	91190283 	add	x3, x20, #0x640
    b7c8:	aa0003f5 	mov	x21, x0
    b7cc:	f949d861 	ldr	x1, [x3, #5040]
    b7d0:	f949ec60 	ldr	x0, [x3, #5080]
    b7d4:	cb0102a1 	sub	x1, x21, x1
    b7d8:	eb00403f 	cmp	x1, x0, lsl #16
    b7dc:	54000322 	b.cs	b840 <f0+0x12ac>  // b.hs, b.nlast
    b7e0:	d350fc22 	lsr	x2, x1, #16
    b7e4:	f949fc63 	ldr	x3, [x3, #5112]
    b7e8:	8b020842 	add	x2, x2, x2, lsl #2
    b7ec:	d37df042 	lsl	x2, x2, #3
    b7f0:	8b020060 	add	x0, x3, x2
    b7f4:	f9401017 	ldr	x23, [x0, #32]
    b7f8:	b4000257 	cbz	x23, b840 <f0+0x12ac>
    b7fc:	38626862 	ldrb	w2, [x3, x2]
    b800:	7100085f 	cmp	w2, #0x2
    b804:	54008300 	b.eq	c864 <f0+0x22d0>  // b.none
    b808:	7100045f 	cmp	w2, #0x1
    b80c:	540001a1 	b.ne	b840 <f0+0x12ac>  // b.any
    b810:	29430002 	ldp	w2, w0, [x0, #24]
    b814:	92403c21 	and	x1, x1, #0xffff
    b818:	9b027c21 	mul	x1, x1, x2
    b81c:	d360fc21 	lsr	x1, x1, #32
    b820:	eb00003f 	cmp	x1, x0
    b824:	540000e2 	b.cs	b840 <f0+0x12ac>  // b.hs, b.nlast
    b828:	8b0102f7 	add	x23, x23, x1
    b82c:	394002e0 	ldrb	w0, [x23]
    b830:	7103fc1f 	cmp	w0, #0xff
    b834:	54009740 	b.eq	cb1c <f0+0x2588>  // b.none
    b838:	52800020 	mov	w0, #0x1                   	// #1
    b83c:	390002e0 	strb	w0, [x23]
    b840:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b844:	911223e1 	add	x1, sp, #0x488
    b848:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b84c:	52800020 	mov	w0, #0x1                   	// #1
    b850:	f90247e2 	str	x2, [sp, #1160]
    b854:	f9024bf5 	str	x21, [sp, #1168]
    b858:	97ffe816 	bl	58b0 <fwp_data.part.0.constprop.0>
    b85c:	97ffe899 	bl	5ac0 <fwp_rc_fresh>
    b860:	aa0003e2 	mov	x2, x0
    b864:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b868:	911263e1 	add	x1, sp, #0x498
    b86c:	52800020 	mov	w0, #0x1                   	// #1
    b870:	f9024fe3 	str	x3, [sp, #1176]
    b874:	f90253e2 	str	x2, [sp, #1184]
    b878:	97ffe80e 	bl	58b0 <fwp_data.part.0.constprop.0>
    b87c:	91190283 	add	x3, x20, #0x640
    b880:	aa0003f5 	mov	x21, x0
    b884:	f949d861 	ldr	x1, [x3, #5040]
    b888:	f949ec60 	ldr	x0, [x3, #5080]
    b88c:	cb0102a1 	sub	x1, x21, x1
    b890:	eb00403f 	cmp	x1, x0, lsl #16
    b894:	54000322 	b.cs	b8f8 <f0+0x1364>  // b.hs, b.nlast
    b898:	d350fc22 	lsr	x2, x1, #16
    b89c:	f949fc63 	ldr	x3, [x3, #5112]
    b8a0:	8b020842 	add	x2, x2, x2, lsl #2
    b8a4:	d37df042 	lsl	x2, x2, #3
    b8a8:	8b020060 	add	x0, x3, x2
    b8ac:	f9401017 	ldr	x23, [x0, #32]
    b8b0:	b4000257 	cbz	x23, b8f8 <f0+0x1364>
    b8b4:	38626862 	ldrb	w2, [x3, x2]
    b8b8:	7100085f 	cmp	w2, #0x2
    b8bc:	54007ce0 	b.eq	c858 <f0+0x22c4>  // b.none
    b8c0:	7100045f 	cmp	w2, #0x1
    b8c4:	540001a1 	b.ne	b8f8 <f0+0x1364>  // b.any
    b8c8:	29430002 	ldp	w2, w0, [x0, #24]
    b8cc:	92403c21 	and	x1, x1, #0xffff
    b8d0:	9b027c21 	mul	x1, x1, x2
    b8d4:	d360fc21 	lsr	x1, x1, #32
    b8d8:	eb00003f 	cmp	x1, x0
    b8dc:	540000e2 	b.cs	b8f8 <f0+0x1364>  // b.hs, b.nlast
    b8e0:	8b0102f7 	add	x23, x23, x1
    b8e4:	394002e0 	ldrb	w0, [x23]
    b8e8:	7103fc1f 	cmp	w0, #0xff
    b8ec:	540091e0 	b.eq	cb28 <f0+0x2594>  // b.none
    b8f0:	52800020 	mov	w0, #0x1                   	// #1
    b8f4:	390002e0 	strb	w0, [x23]
    b8f8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b8fc:	9112a3e1 	add	x1, sp, #0x4a8
    b900:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f90257e2 	str	x2, [sp, #1192]
    b90c:	f9025bf5 	str	x21, [sp, #1200]
    b910:	97ffe7e8 	bl	58b0 <fwp_data.part.0.constprop.0>
    b914:	97ffe86b 	bl	5ac0 <fwp_rc_fresh>
    b918:	aa0003e2 	mov	x2, x0
    b91c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b920:	9112e3e1 	add	x1, sp, #0x4b8
    b924:	52800020 	mov	w0, #0x1                   	// #1
    b928:	f9025fe3 	str	x3, [sp, #1208]
    b92c:	f90263e2 	str	x2, [sp, #1216]
    b930:	97ffe7e0 	bl	58b0 <fwp_data.part.0.constprop.0>
    b934:	91190283 	add	x3, x20, #0x640
    b938:	aa0003f5 	mov	x21, x0
    b93c:	f949d861 	ldr	x1, [x3, #5040]
    b940:	f949ec60 	ldr	x0, [x3, #5080]
    b944:	cb0102a1 	sub	x1, x21, x1
    b948:	eb00403f 	cmp	x1, x0, lsl #16
    b94c:	54000322 	b.cs	b9b0 <f0+0x141c>  // b.hs, b.nlast
    b950:	d350fc22 	lsr	x2, x1, #16
    b954:	f949fc63 	ldr	x3, [x3, #5112]
    b958:	8b020842 	add	x2, x2, x2, lsl #2
    b95c:	d37df042 	lsl	x2, x2, #3
    b960:	8b020060 	add	x0, x3, x2
    b964:	f9401017 	ldr	x23, [x0, #32]
    b968:	b4000257 	cbz	x23, b9b0 <f0+0x141c>
    b96c:	38626862 	ldrb	w2, [x3, x2]
    b970:	7100085f 	cmp	w2, #0x2
    b974:	540076c0 	b.eq	c84c <f0+0x22b8>  // b.none
    b978:	7100045f 	cmp	w2, #0x1
    b97c:	540001a1 	b.ne	b9b0 <f0+0x141c>  // b.any
    b980:	29430002 	ldp	w2, w0, [x0, #24]
    b984:	92403c21 	and	x1, x1, #0xffff
    b988:	9b027c21 	mul	x1, x1, x2
    b98c:	d360fc21 	lsr	x1, x1, #32
    b990:	eb00003f 	cmp	x1, x0
    b994:	540000e2 	b.cs	b9b0 <f0+0x141c>  // b.hs, b.nlast
    b998:	8b0102f7 	add	x23, x23, x1
    b99c:	394002e0 	ldrb	w0, [x23]
    b9a0:	7103fc1f 	cmp	w0, #0xff
    b9a4:	54008c80 	b.eq	cb34 <f0+0x25a0>  // b.none
    b9a8:	52800020 	mov	w0, #0x1                   	// #1
    b9ac:	390002e0 	strb	w0, [x23]
    b9b0:	911323e1 	add	x1, sp, #0x4c8
    b9b4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b9b8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b9bc:	52800020 	mov	w0, #0x1                   	// #1
    b9c0:	f90267f7 	str	x23, [sp, #1224]
    b9c4:	f9026bf5 	str	x21, [sp, #1232]
    b9c8:	97ffe7ba 	bl	58b0 <fwp_data.part.0.constprop.0>
    b9cc:	97ffe83d 	bl	5ac0 <fwp_rc_fresh>
    b9d0:	aa0003e2 	mov	x2, x0
    b9d4:	911363e1 	add	x1, sp, #0x4d8
    b9d8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b9dc:	52800020 	mov	w0, #0x1                   	// #1
    b9e0:	f9026ff5 	str	x21, [sp, #1240]
    b9e4:	f90273e2 	str	x2, [sp, #1248]
    b9e8:	97ffe7b2 	bl	58b0 <fwp_data.part.0.constprop.0>
    b9ec:	97ffe835 	bl	5ac0 <fwp_rc_fresh>
    b9f0:	aa0003e2 	mov	x2, x0
    b9f4:	9113a3e1 	add	x1, sp, #0x4e8
    b9f8:	52800020 	mov	w0, #0x1                   	// #1
    b9fc:	f90277f7 	str	x23, [sp, #1256]
    ba00:	f9027be2 	str	x2, [sp, #1264]
    ba04:	97ffe7ab 	bl	58b0 <fwp_data.part.0.constprop.0>
    ba08:	97ffe82e 	bl	5ac0 <fwp_rc_fresh>
    ba0c:	aa0003e2 	mov	x2, x0
    ba10:	9113e3e1 	add	x1, sp, #0x4f8
    ba14:	52800020 	mov	w0, #0x1                   	// #1
    ba18:	f9027ff5 	str	x21, [sp, #1272]
    ba1c:	f90283e2 	str	x2, [sp, #1280]
    ba20:	97ffe7a4 	bl	58b0 <fwp_data.part.0.constprop.0>
    ba24:	91190283 	add	x3, x20, #0x640
    ba28:	aa0003f5 	mov	x21, x0
    ba2c:	f949d861 	ldr	x1, [x3, #5040]
    ba30:	f949ec60 	ldr	x0, [x3, #5080]
    ba34:	cb0102a1 	sub	x1, x21, x1
    ba38:	eb00403f 	cmp	x1, x0, lsl #16
    ba3c:	54000322 	b.cs	baa0 <f0+0x150c>  // b.hs, b.nlast
    ba40:	d350fc22 	lsr	x2, x1, #16
    ba44:	f949fc63 	ldr	x3, [x3, #5112]
    ba48:	8b020842 	add	x2, x2, x2, lsl #2
    ba4c:	d37df042 	lsl	x2, x2, #3
    ba50:	8b020060 	add	x0, x3, x2
    ba54:	f9401017 	ldr	x23, [x0, #32]
    ba58:	b4000257 	cbz	x23, baa0 <f0+0x150c>
    ba5c:	38626862 	ldrb	w2, [x3, x2]
    ba60:	7100085f 	cmp	w2, #0x2
    ba64:	54007d80 	b.eq	ca14 <f0+0x2480>  // b.none
    ba68:	7100045f 	cmp	w2, #0x1
    ba6c:	540001a1 	b.ne	baa0 <f0+0x150c>  // b.any
    ba70:	29430002 	ldp	w2, w0, [x0, #24]
    ba74:	92403c21 	and	x1, x1, #0xffff
    ba78:	9b027c21 	mul	x1, x1, x2
    ba7c:	d360fc21 	lsr	x1, x1, #32
    ba80:	eb00003f 	cmp	x1, x0
    ba84:	540000e2 	b.cs	baa0 <f0+0x150c>  // b.hs, b.nlast
    ba88:	8b0102f7 	add	x23, x23, x1
    ba8c:	394002e0 	ldrb	w0, [x23]
    ba90:	7103fc1f 	cmp	w0, #0xff
    ba94:	54008560 	b.eq	cb40 <f0+0x25ac>  // b.none
    ba98:	52800020 	mov	w0, #0x1                   	// #1
    ba9c:	390002e0 	strb	w0, [x23]
    baa0:	911423e1 	add	x1, sp, #0x508
    baa4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    baa8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    baac:	52800020 	mov	w0, #0x1                   	// #1
    bab0:	f90287f7 	str	x23, [sp, #1288]
    bab4:	f9028bf5 	str	x21, [sp, #1296]
    bab8:	97ffe77e 	bl	58b0 <fwp_data.part.0.constprop.0>
    babc:	97ffe801 	bl	5ac0 <fwp_rc_fresh>
    bac0:	aa0003e2 	mov	x2, x0
    bac4:	911463e1 	add	x1, sp, #0x518
    bac8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bacc:	52800020 	mov	w0, #0x1                   	// #1
    bad0:	f9028ff5 	str	x21, [sp, #1304]
    bad4:	f90293e2 	str	x2, [sp, #1312]
    bad8:	97ffe776 	bl	58b0 <fwp_data.part.0.constprop.0>
    badc:	97ffe7f9 	bl	5ac0 <fwp_rc_fresh>
    bae0:	aa0003e2 	mov	x2, x0
    bae4:	9114a3e1 	add	x1, sp, #0x528
    bae8:	52800020 	mov	w0, #0x1                   	// #1
    baec:	f90297f7 	str	x23, [sp, #1320]
    baf0:	f9029be2 	str	x2, [sp, #1328]
    baf4:	97ffe76f 	bl	58b0 <fwp_data.part.0.constprop.0>
    baf8:	97ffe7f2 	bl	5ac0 <fwp_rc_fresh>
    bafc:	aa0003e2 	mov	x2, x0
    bb00:	9114e3e1 	add	x1, sp, #0x538
    bb04:	52800020 	mov	w0, #0x1                   	// #1
    bb08:	f9029ff5 	str	x21, [sp, #1336]
    bb0c:	f902a3e2 	str	x2, [sp, #1344]
    bb10:	97ffe768 	bl	58b0 <fwp_data.part.0.constprop.0>
    bb14:	91190283 	add	x3, x20, #0x640
    bb18:	aa0003f5 	mov	x21, x0
    bb1c:	f949d861 	ldr	x1, [x3, #5040]
    bb20:	f949ec60 	ldr	x0, [x3, #5080]
    bb24:	cb0102a1 	sub	x1, x21, x1
    bb28:	eb00403f 	cmp	x1, x0, lsl #16
    bb2c:	54000322 	b.cs	bb90 <f0+0x15fc>  // b.hs, b.nlast
    bb30:	d350fc22 	lsr	x2, x1, #16
    bb34:	f949fc63 	ldr	x3, [x3, #5112]
    bb38:	8b020842 	add	x2, x2, x2, lsl #2
    bb3c:	d37df042 	lsl	x2, x2, #3
    bb40:	8b020060 	add	x0, x3, x2
    bb44:	f9401017 	ldr	x23, [x0, #32]
    bb48:	b4000257 	cbz	x23, bb90 <f0+0x15fc>
    bb4c:	38626862 	ldrb	w2, [x3, x2]
    bb50:	7100085f 	cmp	w2, #0x2
    bb54:	540075a0 	b.eq	ca08 <f0+0x2474>  // b.none
    bb58:	7100045f 	cmp	w2, #0x1
    bb5c:	540001a1 	b.ne	bb90 <f0+0x15fc>  // b.any
    bb60:	29430002 	ldp	w2, w0, [x0, #24]
    bb64:	92403c21 	and	x1, x1, #0xffff
    bb68:	9b027c21 	mul	x1, x1, x2
    bb6c:	d360fc21 	lsr	x1, x1, #32
    bb70:	eb00003f 	cmp	x1, x0
    bb74:	540000e2 	b.cs	bb90 <f0+0x15fc>  // b.hs, b.nlast
    bb78:	8b0102f7 	add	x23, x23, x1
    bb7c:	394002e0 	ldrb	w0, [x23]
    bb80:	7103fc1f 	cmp	w0, #0xff
    bb84:	54007e40 	b.eq	cb4c <f0+0x25b8>  // b.none
    bb88:	52800020 	mov	w0, #0x1                   	// #1
    bb8c:	390002e0 	strb	w0, [x23]
    bb90:	911523e1 	add	x1, sp, #0x548
    bb94:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb98:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	f902a7f7 	str	x23, [sp, #1352]
    bba4:	f902abf5 	str	x21, [sp, #1360]
    bba8:	97ffe742 	bl	58b0 <fwp_data.part.0.constprop.0>
    bbac:	97ffe7c5 	bl	5ac0 <fwp_rc_fresh>
    bbb0:	aa0003e2 	mov	x2, x0
    bbb4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bbb8:	911563e1 	add	x1, sp, #0x558
    bbbc:	52800020 	mov	w0, #0x1                   	// #1
    bbc0:	f902afe3 	str	x3, [sp, #1368]
    bbc4:	f902b3e2 	str	x2, [sp, #1376]
    bbc8:	97ffe73a 	bl	58b0 <fwp_data.part.0.constprop.0>
    bbcc:	97ffe7bd 	bl	5ac0 <fwp_rc_fresh>
    bbd0:	aa0003e2 	mov	x2, x0
    bbd4:	9115a3e1 	add	x1, sp, #0x568
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	f902b7f7 	str	x23, [sp, #1384]
    bbe0:	f902bbe2 	str	x2, [sp, #1392]
    bbe4:	97ffe733 	bl	58b0 <fwp_data.part.0.constprop.0>
    bbe8:	91190283 	add	x3, x20, #0x640
    bbec:	aa0003f5 	mov	x21, x0
    bbf0:	f949d861 	ldr	x1, [x3, #5040]
    bbf4:	f949ec60 	ldr	x0, [x3, #5080]
    bbf8:	cb0102a1 	sub	x1, x21, x1
    bbfc:	eb00403f 	cmp	x1, x0, lsl #16
    bc00:	54000322 	b.cs	bc64 <f0+0x16d0>  // b.hs, b.nlast
    bc04:	d350fc22 	lsr	x2, x1, #16
    bc08:	f949fc63 	ldr	x3, [x3, #5112]
    bc0c:	8b020842 	add	x2, x2, x2, lsl #2
    bc10:	d37df042 	lsl	x2, x2, #3
    bc14:	8b020060 	add	x0, x3, x2
    bc18:	f9401017 	ldr	x23, [x0, #32]
    bc1c:	b4000257 	cbz	x23, bc64 <f0+0x16d0>
    bc20:	38626862 	ldrb	w2, [x3, x2]
    bc24:	7100085f 	cmp	w2, #0x2
    bc28:	54006ea0 	b.eq	c9fc <f0+0x2468>  // b.none
    bc2c:	7100045f 	cmp	w2, #0x1
    bc30:	540001a1 	b.ne	bc64 <f0+0x16d0>  // b.any
    bc34:	29430002 	ldp	w2, w0, [x0, #24]
    bc38:	92403c21 	and	x1, x1, #0xffff
    bc3c:	9b027c21 	mul	x1, x1, x2
    bc40:	d360fc21 	lsr	x1, x1, #32
    bc44:	eb00003f 	cmp	x1, x0
    bc48:	540000e2 	b.cs	bc64 <f0+0x16d0>  // b.hs, b.nlast
    bc4c:	8b0102f7 	add	x23, x23, x1
    bc50:	394002e0 	ldrb	w0, [x23]
    bc54:	7103fc1f 	cmp	w0, #0xff
    bc58:	54007800 	b.eq	cb58 <f0+0x25c4>  // b.none
    bc5c:	52800020 	mov	w0, #0x1                   	// #1
    bc60:	390002e0 	strb	w0, [x23]
    bc64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc68:	9115e3e1 	add	x1, sp, #0x578
    bc6c:	52800020 	mov	w0, #0x1                   	// #1
    bc70:	f902bfe2 	str	x2, [sp, #1400]
    bc74:	f902c3f5 	str	x21, [sp, #1408]
    bc78:	97ffe70e 	bl	58b0 <fwp_data.part.0.constprop.0>
    bc7c:	91190283 	add	x3, x20, #0x640
    bc80:	aa0003f5 	mov	x21, x0
    bc84:	f949d861 	ldr	x1, [x3, #5040]
    bc88:	f949ec60 	ldr	x0, [x3, #5080]
    bc8c:	cb0102a1 	sub	x1, x21, x1
    bc90:	eb00403f 	cmp	x1, x0, lsl #16
    bc94:	54000322 	b.cs	bcf8 <f0+0x1764>  // b.hs, b.nlast
    bc98:	d350fc22 	lsr	x2, x1, #16
    bc9c:	f949fc63 	ldr	x3, [x3, #5112]
    bca0:	8b020842 	add	x2, x2, x2, lsl #2
    bca4:	d37df042 	lsl	x2, x2, #3
    bca8:	8b020060 	add	x0, x3, x2
    bcac:	f9401017 	ldr	x23, [x0, #32]
    bcb0:	b4000257 	cbz	x23, bcf8 <f0+0x1764>
    bcb4:	38626862 	ldrb	w2, [x3, x2]
    bcb8:	7100085f 	cmp	w2, #0x2
    bcbc:	540069a0 	b.eq	c9f0 <f0+0x245c>  // b.none
    bcc0:	7100045f 	cmp	w2, #0x1
    bcc4:	540001a1 	b.ne	bcf8 <f0+0x1764>  // b.any
    bcc8:	29430002 	ldp	w2, w0, [x0, #24]
    bccc:	92403c21 	and	x1, x1, #0xffff
    bcd0:	9b027c21 	mul	x1, x1, x2
    bcd4:	d360fc21 	lsr	x1, x1, #32
    bcd8:	eb00003f 	cmp	x1, x0
    bcdc:	540000e2 	b.cs	bcf8 <f0+0x1764>  // b.hs, b.nlast
    bce0:	8b0102f7 	add	x23, x23, x1
    bce4:	394002e0 	ldrb	w0, [x23]
    bce8:	7103fc1f 	cmp	w0, #0xff
    bcec:	540073c0 	b.eq	cb64 <f0+0x25d0>  // b.none
    bcf0:	52800020 	mov	w0, #0x1                   	// #1
    bcf4:	390002e0 	strb	w0, [x23]
    bcf8:	911623e1 	add	x1, sp, #0x588
    bcfc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd00:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd04:	52800020 	mov	w0, #0x1                   	// #1
    bd08:	f902c7f7 	str	x23, [sp, #1416]
    bd0c:	f902cbf5 	str	x21, [sp, #1424]
    bd10:	97ffe6e8 	bl	58b0 <fwp_data.part.0.constprop.0>
    bd14:	97ffe76b 	bl	5ac0 <fwp_rc_fresh>
    bd18:	aa0003e2 	mov	x2, x0
    bd1c:	911663e1 	add	x1, sp, #0x598
    bd20:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd24:	52800020 	mov	w0, #0x1                   	// #1
    bd28:	f902cff5 	str	x21, [sp, #1432]
    bd2c:	f902d3e2 	str	x2, [sp, #1440]
    bd30:	97ffe6e0 	bl	58b0 <fwp_data.part.0.constprop.0>
    bd34:	97ffe763 	bl	5ac0 <fwp_rc_fresh>
    bd38:	aa0003e2 	mov	x2, x0
    bd3c:	9116a3e1 	add	x1, sp, #0x5a8
    bd40:	52800020 	mov	w0, #0x1                   	// #1
    bd44:	f902d7f7 	str	x23, [sp, #1448]
    bd48:	f902dbe2 	str	x2, [sp, #1456]
    bd4c:	97ffe6d9 	bl	58b0 <fwp_data.part.0.constprop.0>
    bd50:	97ffe75c 	bl	5ac0 <fwp_rc_fresh>
    bd54:	aa0003e2 	mov	x2, x0
    bd58:	9116e3e1 	add	x1, sp, #0x5b8
    bd5c:	52800020 	mov	w0, #0x1                   	// #1
    bd60:	f902dff5 	str	x21, [sp, #1464]
    bd64:	f902e3e2 	str	x2, [sp, #1472]
    bd68:	97ffe6d2 	bl	58b0 <fwp_data.part.0.constprop.0>
    bd6c:	91190283 	add	x3, x20, #0x640
    bd70:	aa0003f5 	mov	x21, x0
    bd74:	f949d861 	ldr	x1, [x3, #5040]
    bd78:	f949ec60 	ldr	x0, [x3, #5080]
    bd7c:	cb0102a1 	sub	x1, x21, x1
    bd80:	eb00403f 	cmp	x1, x0, lsl #16
    bd84:	54000322 	b.cs	bde8 <f0+0x1854>  // b.hs, b.nlast
    bd88:	d350fc22 	lsr	x2, x1, #16
    bd8c:	f949fc63 	ldr	x3, [x3, #5112]
    bd90:	8b020842 	add	x2, x2, x2, lsl #2
    bd94:	d37df042 	lsl	x2, x2, #3
    bd98:	8b020060 	add	x0, x3, x2
    bd9c:	f9401017 	ldr	x23, [x0, #32]
    bda0:	b4000257 	cbz	x23, bde8 <f0+0x1854>
    bda4:	38626862 	ldrb	w2, [x3, x2]
    bda8:	7100085f 	cmp	w2, #0x2
    bdac:	540061c0 	b.eq	c9e4 <f0+0x2450>  // b.none
    bdb0:	7100045f 	cmp	w2, #0x1
    bdb4:	540001a1 	b.ne	bde8 <f0+0x1854>  // b.any
    bdb8:	29430002 	ldp	w2, w0, [x0, #24]
    bdbc:	92403c21 	and	x1, x1, #0xffff
    bdc0:	9b027c21 	mul	x1, x1, x2
    bdc4:	d360fc21 	lsr	x1, x1, #32
    bdc8:	eb00003f 	cmp	x1, x0
    bdcc:	540000e2 	b.cs	bde8 <f0+0x1854>  // b.hs, b.nlast
    bdd0:	8b0102f7 	add	x23, x23, x1
    bdd4:	394002e0 	ldrb	w0, [x23]
    bdd8:	7103fc1f 	cmp	w0, #0xff
    bddc:	54006ca0 	b.eq	cb70 <f0+0x25dc>  // b.none
    bde0:	52800020 	mov	w0, #0x1                   	// #1
    bde4:	390002e0 	strb	w0, [x23]
    bde8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bdec:	911723e1 	add	x1, sp, #0x5c8
    bdf0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bdf4:	52800020 	mov	w0, #0x1                   	// #1
    bdf8:	f902e7e2 	str	x2, [sp, #1480]
    bdfc:	f902ebf5 	str	x21, [sp, #1488]
    be00:	97ffe6ac 	bl	58b0 <fwp_data.part.0.constprop.0>
    be04:	97ffe72f 	bl	5ac0 <fwp_rc_fresh>
    be08:	aa0003e2 	mov	x2, x0
    be0c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    be10:	911763e1 	add	x1, sp, #0x5d8
    be14:	52800020 	mov	w0, #0x1                   	// #1
    be18:	f902efe3 	str	x3, [sp, #1496]
    be1c:	f902f3e2 	str	x2, [sp, #1504]
    be20:	97ffe6a4 	bl	58b0 <fwp_data.part.0.constprop.0>
    be24:	91190283 	add	x3, x20, #0x640
    be28:	aa0003f5 	mov	x21, x0
    be2c:	f949d861 	ldr	x1, [x3, #5040]
    be30:	f949ec60 	ldr	x0, [x3, #5080]
    be34:	cb0102a1 	sub	x1, x21, x1
    be38:	eb00403f 	cmp	x1, x0, lsl #16
    be3c:	54000322 	b.cs	bea0 <f0+0x190c>  // b.hs, b.nlast
    be40:	d350fc22 	lsr	x2, x1, #16
    be44:	f949fc63 	ldr	x3, [x3, #5112]
    be48:	8b020842 	add	x2, x2, x2, lsl #2
    be4c:	d37df042 	lsl	x2, x2, #3
    be50:	8b020060 	add	x0, x3, x2
    be54:	f9401017 	ldr	x23, [x0, #32]
    be58:	b4000257 	cbz	x23, bea0 <f0+0x190c>
    be5c:	38626862 	ldrb	w2, [x3, x2]
    be60:	7100085f 	cmp	w2, #0x2
    be64:	54005ba0 	b.eq	c9d8 <f0+0x2444>  // b.none
    be68:	7100045f 	cmp	w2, #0x1
    be6c:	540001a1 	b.ne	bea0 <f0+0x190c>  // b.any
    be70:	29430002 	ldp	w2, w0, [x0, #24]
    be74:	92403c21 	and	x1, x1, #0xffff
    be78:	9b027c21 	mul	x1, x1, x2
    be7c:	d360fc21 	lsr	x1, x1, #32
    be80:	eb00003f 	cmp	x1, x0
    be84:	540000e2 	b.cs	bea0 <f0+0x190c>  // b.hs, b.nlast
    be88:	8b0102f7 	add	x23, x23, x1
    be8c:	394002e0 	ldrb	w0, [x23]
    be90:	7103fc1f 	cmp	w0, #0xff
    be94:	54006740 	b.eq	cb7c <f0+0x25e8>  // b.none
    be98:	52800020 	mov	w0, #0x1                   	// #1
    be9c:	390002e0 	strb	w0, [x23]
    bea0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bea4:	9117a3e1 	add	x1, sp, #0x5e8
    bea8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    beac:	52800020 	mov	w0, #0x1                   	// #1
    beb0:	f902f7e2 	str	x2, [sp, #1512]
    beb4:	f902fbf5 	str	x21, [sp, #1520]
    beb8:	97ffe67e 	bl	58b0 <fwp_data.part.0.constprop.0>
    bebc:	91190283 	add	x3, x20, #0x640
    bec0:	aa0003f5 	mov	x21, x0
    bec4:	f949d861 	ldr	x1, [x3, #5040]
    bec8:	f949ec60 	ldr	x0, [x3, #5080]
    becc:	cb0102a1 	sub	x1, x21, x1
    bed0:	eb00403f 	cmp	x1, x0, lsl #16
    bed4:	54000322 	b.cs	bf38 <f0+0x19a4>  // b.hs, b.nlast
    bed8:	d350fc22 	lsr	x2, x1, #16
    bedc:	f949fc63 	ldr	x3, [x3, #5112]
    bee0:	8b020842 	add	x2, x2, x2, lsl #2
    bee4:	d37df042 	lsl	x2, x2, #3
    bee8:	8b020060 	add	x0, x3, x2
    beec:	f9401017 	ldr	x23, [x0, #32]
    bef0:	b4000257 	cbz	x23, bf38 <f0+0x19a4>
    bef4:	38626862 	ldrb	w2, [x3, x2]
    bef8:	7100085f 	cmp	w2, #0x2
    befc:	54005680 	b.eq	c9cc <f0+0x2438>  // b.none
    bf00:	7100045f 	cmp	w2, #0x1
    bf04:	540001a1 	b.ne	bf38 <f0+0x19a4>  // b.any
    bf08:	29430002 	ldp	w2, w0, [x0, #24]
    bf0c:	92403c21 	and	x1, x1, #0xffff
    bf10:	9b027c21 	mul	x1, x1, x2
    bf14:	d360fc21 	lsr	x1, x1, #32
    bf18:	eb00003f 	cmp	x1, x0
    bf1c:	540000e2 	b.cs	bf38 <f0+0x19a4>  // b.hs, b.nlast
    bf20:	8b0102f7 	add	x23, x23, x1
    bf24:	394002e0 	ldrb	w0, [x23]
    bf28:	7103fc1f 	cmp	w0, #0xff
    bf2c:	540062e0 	b.eq	cb88 <f0+0x25f4>  // b.none
    bf30:	52800020 	mov	w0, #0x1                   	// #1
    bf34:	390002e0 	strb	w0, [x23]
    bf38:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bf3c:	9117e3e1 	add	x1, sp, #0x5f8
    bf40:	52800020 	mov	w0, #0x1                   	// #1
    bf44:	f902ffe2 	str	x2, [sp, #1528]
    bf48:	f90303f5 	str	x21, [sp, #1536]
    bf4c:	97ffe659 	bl	58b0 <fwp_data.part.0.constprop.0>
    bf50:	91190283 	add	x3, x20, #0x640
    bf54:	aa0003f5 	mov	x21, x0
    bf58:	f949d861 	ldr	x1, [x3, #5040]
    bf5c:	f949ec60 	ldr	x0, [x3, #5080]
    bf60:	cb0102a1 	sub	x1, x21, x1
    bf64:	eb00403f 	cmp	x1, x0, lsl #16
    bf68:	54000322 	b.cs	bfcc <f0+0x1a38>  // b.hs, b.nlast
    bf6c:	d350fc22 	lsr	x2, x1, #16
    bf70:	f949fc63 	ldr	x3, [x3, #5112]
    bf74:	8b020842 	add	x2, x2, x2, lsl #2
    bf78:	d37df042 	lsl	x2, x2, #3
    bf7c:	8b020060 	add	x0, x3, x2
    bf80:	f9401017 	ldr	x23, [x0, #32]
    bf84:	b4000257 	cbz	x23, bfcc <f0+0x1a38>
    bf88:	38626862 	ldrb	w2, [x3, x2]
    bf8c:	7100085f 	cmp	w2, #0x2
    bf90:	54005180 	b.eq	c9c0 <f0+0x242c>  // b.none
    bf94:	7100045f 	cmp	w2, #0x1
    bf98:	540001a1 	b.ne	bfcc <f0+0x1a38>  // b.any
    bf9c:	29430002 	ldp	w2, w0, [x0, #24]
    bfa0:	92403c21 	and	x1, x1, #0xffff
    bfa4:	9b027c21 	mul	x1, x1, x2
    bfa8:	d360fc21 	lsr	x1, x1, #32
    bfac:	eb00003f 	cmp	x1, x0
    bfb0:	540000e2 	b.cs	bfcc <f0+0x1a38>  // b.hs, b.nlast
    bfb4:	8b0102f7 	add	x23, x23, x1
    bfb8:	394002e0 	ldrb	w0, [x23]
    bfbc:	7103fc1f 	cmp	w0, #0xff
    bfc0:	54005ea0 	b.eq	cb94 <f0+0x2600>  // b.none
    bfc4:	52800020 	mov	w0, #0x1                   	// #1
    bfc8:	390002e0 	strb	w0, [x23]
    bfcc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfd0:	911823e1 	add	x1, sp, #0x608
    bfd4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfd8:	52800020 	mov	w0, #0x1                   	// #1
    bfdc:	f90307e2 	str	x2, [sp, #1544]
    bfe0:	f9030bf5 	str	x21, [sp, #1552]
    bfe4:	97ffe633 	bl	58b0 <fwp_data.part.0.constprop.0>
    bfe8:	97ffe6b6 	bl	5ac0 <fwp_rc_fresh>
    bfec:	aa0003e2 	mov	x2, x0
    bff0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bff4:	911863e1 	add	x1, sp, #0x618
    bff8:	52800020 	mov	w0, #0x1                   	// #1
    bffc:	f9030fe3 	str	x3, [sp, #1560]
    c000:	f90313e2 	str	x2, [sp, #1568]
    c004:	97ffe62b 	bl	58b0 <fwp_data.part.0.constprop.0>
    c008:	91190283 	add	x3, x20, #0x640
    c00c:	aa0003f5 	mov	x21, x0
    c010:	f949d861 	ldr	x1, [x3, #5040]
    c014:	f949ec60 	ldr	x0, [x3, #5080]
    c018:	cb0102a1 	sub	x1, x21, x1
    c01c:	eb00403f 	cmp	x1, x0, lsl #16
    c020:	54000322 	b.cs	c084 <f0+0x1af0>  // b.hs, b.nlast
    c024:	d350fc22 	lsr	x2, x1, #16
    c028:	f949fc63 	ldr	x3, [x3, #5112]
    c02c:	8b020842 	add	x2, x2, x2, lsl #2
    c030:	d37df042 	lsl	x2, x2, #3
    c034:	8b020060 	add	x0, x3, x2
    c038:	f9401017 	ldr	x23, [x0, #32]
    c03c:	b4000257 	cbz	x23, c084 <f0+0x1af0>
    c040:	38626862 	ldrb	w2, [x3, x2]
    c044:	7100085f 	cmp	w2, #0x2
    c048:	54004b60 	b.eq	c9b4 <f0+0x2420>  // b.none
    c04c:	7100045f 	cmp	w2, #0x1
    c050:	540001a1 	b.ne	c084 <f0+0x1af0>  // b.any
    c054:	29430002 	ldp	w2, w0, [x0, #24]
    c058:	92403c21 	and	x1, x1, #0xffff
    c05c:	9b027c21 	mul	x1, x1, x2
    c060:	d360fc21 	lsr	x1, x1, #32
    c064:	eb00003f 	cmp	x1, x0
    c068:	540000e2 	b.cs	c084 <f0+0x1af0>  // b.hs, b.nlast
    c06c:	8b0102f7 	add	x23, x23, x1
    c070:	394002e0 	ldrb	w0, [x23]
    c074:	7103fc1f 	cmp	w0, #0xff
    c078:	54005940 	b.eq	cba0 <f0+0x260c>  // b.none
    c07c:	52800020 	mov	w0, #0x1                   	// #1
    c080:	390002e0 	strb	w0, [x23]
    c084:	9118a3e1 	add	x1, sp, #0x628
    c088:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c08c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c090:	52800020 	mov	w0, #0x1                   	// #1
    c094:	f90317f7 	str	x23, [sp, #1576]
    c098:	f9031bf5 	str	x21, [sp, #1584]
    c09c:	97ffe605 	bl	58b0 <fwp_data.part.0.constprop.0>
    c0a0:	97ffe688 	bl	5ac0 <fwp_rc_fresh>
    c0a4:	aa0003e2 	mov	x2, x0
    c0a8:	9118e3e1 	add	x1, sp, #0x638
    c0ac:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c0b0:	52800020 	mov	w0, #0x1                   	// #1
    c0b4:	f9031ff5 	str	x21, [sp, #1592]
    c0b8:	f90323e2 	str	x2, [sp, #1600]
    c0bc:	97ffe5fd 	bl	58b0 <fwp_data.part.0.constprop.0>
    c0c0:	97ffe680 	bl	5ac0 <fwp_rc_fresh>
    c0c4:	aa0003e2 	mov	x2, x0
    c0c8:	911923e1 	add	x1, sp, #0x648
    c0cc:	52800020 	mov	w0, #0x1                   	// #1
    c0d0:	f90327f7 	str	x23, [sp, #1608]
    c0d4:	f9032be2 	str	x2, [sp, #1616]
    c0d8:	97ffe5f6 	bl	58b0 <fwp_data.part.0.constprop.0>
    c0dc:	97ffe679 	bl	5ac0 <fwp_rc_fresh>
    c0e0:	aa0003e2 	mov	x2, x0
    c0e4:	911963e1 	add	x1, sp, #0x658
    c0e8:	52800020 	mov	w0, #0x1                   	// #1
    c0ec:	f9032ff5 	str	x21, [sp, #1624]
    c0f0:	f90333e2 	str	x2, [sp, #1632]
    c0f4:	97ffe5ef 	bl	58b0 <fwp_data.part.0.constprop.0>
    c0f8:	97ffe672 	bl	5ac0 <fwp_rc_fresh>
    c0fc:	aa0003e2 	mov	x2, x0
    c100:	9119a3e1 	add	x1, sp, #0x668
    c104:	52800020 	mov	w0, #0x1                   	// #1
    c108:	f90337f7 	str	x23, [sp, #1640]
    c10c:	f9033be2 	str	x2, [sp, #1648]
    c110:	97ffe5e8 	bl	58b0 <fwp_data.part.0.constprop.0>
    c114:	91190283 	add	x3, x20, #0x640
    c118:	aa0003f5 	mov	x21, x0
    c11c:	f949d861 	ldr	x1, [x3, #5040]
    c120:	f949ec60 	ldr	x0, [x3, #5080]
    c124:	cb0102a1 	sub	x1, x21, x1
    c128:	eb00403f 	cmp	x1, x0, lsl #16
    c12c:	54000322 	b.cs	c190 <f0+0x1bfc>  // b.hs, b.nlast
    c130:	d350fc22 	lsr	x2, x1, #16
    c134:	f949fc63 	ldr	x3, [x3, #5112]
    c138:	8b020842 	add	x2, x2, x2, lsl #2
    c13c:	d37df042 	lsl	x2, x2, #3
    c140:	8b020060 	add	x0, x3, x2
    c144:	f9401017 	ldr	x23, [x0, #32]
    c148:	b4000257 	cbz	x23, c190 <f0+0x1bfc>
    c14c:	38626862 	ldrb	w2, [x3, x2]
    c150:	7100085f 	cmp	w2, #0x2
    c154:	540042a0 	b.eq	c9a8 <f0+0x2414>  // b.none
    c158:	7100045f 	cmp	w2, #0x1
    c15c:	540001a1 	b.ne	c190 <f0+0x1bfc>  // b.any
    c160:	29430002 	ldp	w2, w0, [x0, #24]
    c164:	92403c21 	and	x1, x1, #0xffff
    c168:	9b027c21 	mul	x1, x1, x2
    c16c:	d360fc21 	lsr	x1, x1, #32
    c170:	eb00003f 	cmp	x1, x0
    c174:	540000e2 	b.cs	c190 <f0+0x1bfc>  // b.hs, b.nlast
    c178:	8b0102f7 	add	x23, x23, x1
    c17c:	394002e0 	ldrb	w0, [x23]
    c180:	7103fc1f 	cmp	w0, #0xff
    c184:	54005140 	b.eq	cbac <f0+0x2618>  // b.none
    c188:	52800020 	mov	w0, #0x1                   	// #1
    c18c:	390002e0 	strb	w0, [x23]
    c190:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c194:	9119e3e1 	add	x1, sp, #0x678
    c198:	52800020 	mov	w0, #0x1                   	// #1
    c19c:	f9033fe2 	str	x2, [sp, #1656]
    c1a0:	f90343f5 	str	x21, [sp, #1664]
    c1a4:	97ffe5c3 	bl	58b0 <fwp_data.part.0.constprop.0>
    c1a8:	91190283 	add	x3, x20, #0x640
    c1ac:	aa0003f5 	mov	x21, x0
    c1b0:	f949d861 	ldr	x1, [x3, #5040]
    c1b4:	f949ec60 	ldr	x0, [x3, #5080]
    c1b8:	cb0102a1 	sub	x1, x21, x1
    c1bc:	eb00403f 	cmp	x1, x0, lsl #16
    c1c0:	54000322 	b.cs	c224 <f0+0x1c90>  // b.hs, b.nlast
    c1c4:	d350fc22 	lsr	x2, x1, #16
    c1c8:	f949fc63 	ldr	x3, [x3, #5112]
    c1cc:	8b020842 	add	x2, x2, x2, lsl #2
    c1d0:	d37df042 	lsl	x2, x2, #3
    c1d4:	8b020060 	add	x0, x3, x2
    c1d8:	f9401017 	ldr	x23, [x0, #32]
    c1dc:	b4000257 	cbz	x23, c224 <f0+0x1c90>
    c1e0:	38626862 	ldrb	w2, [x3, x2]
    c1e4:	7100085f 	cmp	w2, #0x2
    c1e8:	54003da0 	b.eq	c99c <f0+0x2408>  // b.none
    c1ec:	7100045f 	cmp	w2, #0x1
    c1f0:	540001a1 	b.ne	c224 <f0+0x1c90>  // b.any
    c1f4:	29430002 	ldp	w2, w0, [x0, #24]
    c1f8:	92403c21 	and	x1, x1, #0xffff
    c1fc:	9b027c21 	mul	x1, x1, x2
    c200:	d360fc21 	lsr	x1, x1, #32
    c204:	eb00003f 	cmp	x1, x0
    c208:	540000e2 	b.cs	c224 <f0+0x1c90>  // b.hs, b.nlast
    c20c:	8b0102f7 	add	x23, x23, x1
    c210:	394002e0 	ldrb	w0, [x23]
    c214:	7103fc1f 	cmp	w0, #0xff
    c218:	54004d00 	b.eq	cbb8 <f0+0x2624>  // b.none
    c21c:	52800020 	mov	w0, #0x1                   	// #1
    c220:	390002e0 	strb	w0, [x23]
    c224:	911a23e1 	add	x1, sp, #0x688
    c228:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c22c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c230:	52800020 	mov	w0, #0x1                   	// #1
    c234:	f90347f7 	str	x23, [sp, #1672]
    c238:	f9034bf5 	str	x21, [sp, #1680]
    c23c:	97ffe59d 	bl	58b0 <fwp_data.part.0.constprop.0>
    c240:	97ffe620 	bl	5ac0 <fwp_rc_fresh>
    c244:	aa0003e2 	mov	x2, x0
    c248:	911a63e1 	add	x1, sp, #0x698
    c24c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c250:	52800020 	mov	w0, #0x1                   	// #1
    c254:	f9034ff5 	str	x21, [sp, #1688]
    c258:	f90353e2 	str	x2, [sp, #1696]
    c25c:	97ffe595 	bl	58b0 <fwp_data.part.0.constprop.0>
    c260:	97ffe618 	bl	5ac0 <fwp_rc_fresh>
    c264:	aa0003e2 	mov	x2, x0
    c268:	911aa3e1 	add	x1, sp, #0x6a8
    c26c:	52800020 	mov	w0, #0x1                   	// #1
    c270:	f90357f7 	str	x23, [sp, #1704]
    c274:	f9035be2 	str	x2, [sp, #1712]
    c278:	97ffe58e 	bl	58b0 <fwp_data.part.0.constprop.0>
    c27c:	97ffe611 	bl	5ac0 <fwp_rc_fresh>
    c280:	aa0003e2 	mov	x2, x0
    c284:	911ae3e1 	add	x1, sp, #0x6b8
    c288:	52800020 	mov	w0, #0x1                   	// #1
    c28c:	f9035ff5 	str	x21, [sp, #1720]
    c290:	f90363e2 	str	x2, [sp, #1728]
    c294:	97ffe587 	bl	58b0 <fwp_data.part.0.constprop.0>
    c298:	91190283 	add	x3, x20, #0x640
    c29c:	aa0003f5 	mov	x21, x0
    c2a0:	f949d861 	ldr	x1, [x3, #5040]
    c2a4:	f949ec60 	ldr	x0, [x3, #5080]
    c2a8:	cb0102a1 	sub	x1, x21, x1
    c2ac:	eb00403f 	cmp	x1, x0, lsl #16
    c2b0:	54000322 	b.cs	c314 <f0+0x1d80>  // b.hs, b.nlast
    c2b4:	d350fc22 	lsr	x2, x1, #16
    c2b8:	f949fc63 	ldr	x3, [x3, #5112]
    c2bc:	8b020842 	add	x2, x2, x2, lsl #2
    c2c0:	d37df042 	lsl	x2, x2, #3
    c2c4:	8b020060 	add	x0, x3, x2
    c2c8:	f9401017 	ldr	x23, [x0, #32]
    c2cc:	b4000257 	cbz	x23, c314 <f0+0x1d80>
    c2d0:	38626862 	ldrb	w2, [x3, x2]
    c2d4:	7100085f 	cmp	w2, #0x2
    c2d8:	540035c0 	b.eq	c990 <f0+0x23fc>  // b.none
    c2dc:	7100045f 	cmp	w2, #0x1
    c2e0:	540001a1 	b.ne	c314 <f0+0x1d80>  // b.any
    c2e4:	29430002 	ldp	w2, w0, [x0, #24]
    c2e8:	92403c21 	and	x1, x1, #0xffff
    c2ec:	9b027c21 	mul	x1, x1, x2
    c2f0:	d360fc21 	lsr	x1, x1, #32
    c2f4:	eb00003f 	cmp	x1, x0
    c2f8:	540000e2 	b.cs	c314 <f0+0x1d80>  // b.hs, b.nlast
    c2fc:	8b0102f7 	add	x23, x23, x1
    c300:	394002e0 	ldrb	w0, [x23]
    c304:	7103fc1f 	cmp	w0, #0xff
    c308:	540045e0 	b.eq	cbc4 <f0+0x2630>  // b.none
    c30c:	52800020 	mov	w0, #0x1                   	// #1
    c310:	390002e0 	strb	w0, [x23]
    c314:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c318:	911b23e1 	add	x1, sp, #0x6c8
    c31c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c320:	52800020 	mov	w0, #0x1                   	// #1
    c324:	f90367e2 	str	x2, [sp, #1736]
    c328:	f9036bf5 	str	x21, [sp, #1744]
    c32c:	97ffe561 	bl	58b0 <fwp_data.part.0.constprop.0>
    c330:	97ffe5e4 	bl	5ac0 <fwp_rc_fresh>
    c334:	aa0003e2 	mov	x2, x0
    c338:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c33c:	911b63e1 	add	x1, sp, #0x6d8
    c340:	52800020 	mov	w0, #0x1                   	// #1
    c344:	f9036fe3 	str	x3, [sp, #1752]
    c348:	f90373e2 	str	x2, [sp, #1760]
    c34c:	97ffe559 	bl	58b0 <fwp_data.part.0.constprop.0>
    c350:	91190283 	add	x3, x20, #0x640
    c354:	aa0003f5 	mov	x21, x0
    c358:	f949d861 	ldr	x1, [x3, #5040]
    c35c:	f949ec60 	ldr	x0, [x3, #5080]
    c360:	cb0102a1 	sub	x1, x21, x1
    c364:	eb00403f 	cmp	x1, x0, lsl #16
    c368:	54000322 	b.cs	c3cc <f0+0x1e38>  // b.hs, b.nlast
    c36c:	d350fc22 	lsr	x2, x1, #16
    c370:	f949fc63 	ldr	x3, [x3, #5112]
    c374:	8b020842 	add	x2, x2, x2, lsl #2
    c378:	d37df042 	lsl	x2, x2, #3
    c37c:	8b020060 	add	x0, x3, x2
    c380:	f9401017 	ldr	x23, [x0, #32]
    c384:	b4000257 	cbz	x23, c3cc <f0+0x1e38>
    c388:	38626862 	ldrb	w2, [x3, x2]
    c38c:	7100085f 	cmp	w2, #0x2
    c390:	54002fa0 	b.eq	c984 <f0+0x23f0>  // b.none
    c394:	7100045f 	cmp	w2, #0x1
    c398:	540001a1 	b.ne	c3cc <f0+0x1e38>  // b.any
    c39c:	29430002 	ldp	w2, w0, [x0, #24]
    c3a0:	92403c21 	and	x1, x1, #0xffff
    c3a4:	9b027c21 	mul	x1, x1, x2
    c3a8:	d360fc21 	lsr	x1, x1, #32
    c3ac:	eb00003f 	cmp	x1, x0
    c3b0:	540000e2 	b.cs	c3cc <f0+0x1e38>  // b.hs, b.nlast
    c3b4:	8b0102f7 	add	x23, x23, x1
    c3b8:	394002e0 	ldrb	w0, [x23]
    c3bc:	7103fc1f 	cmp	w0, #0xff
    c3c0:	54004080 	b.eq	cbd0 <f0+0x263c>  // b.none
    c3c4:	52800020 	mov	w0, #0x1                   	// #1
    c3c8:	390002e0 	strb	w0, [x23]
    c3cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c3d0:	911ba3e1 	add	x1, sp, #0x6e8
    c3d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c3d8:	52800020 	mov	w0, #0x1                   	// #1
    c3dc:	f90377e2 	str	x2, [sp, #1768]
    c3e0:	f9037bf5 	str	x21, [sp, #1776]
    c3e4:	97ffe533 	bl	58b0 <fwp_data.part.0.constprop.0>
    c3e8:	91190283 	add	x3, x20, #0x640
    c3ec:	aa0003f7 	mov	x23, x0
    c3f0:	f949d861 	ldr	x1, [x3, #5040]
    c3f4:	f949ec60 	ldr	x0, [x3, #5080]
    c3f8:	cb0102e1 	sub	x1, x23, x1
    c3fc:	eb00403f 	cmp	x1, x0, lsl #16
    c400:	54000322 	b.cs	c464 <f0+0x1ed0>  // b.hs, b.nlast
    c404:	d350fc22 	lsr	x2, x1, #16
    c408:	f949fc63 	ldr	x3, [x3, #5112]
    c40c:	8b020842 	add	x2, x2, x2, lsl #2
    c410:	d37df042 	lsl	x2, x2, #3
    c414:	8b020060 	add	x0, x3, x2
    c418:	f9401015 	ldr	x21, [x0, #32]
    c41c:	b4000255 	cbz	x21, c464 <f0+0x1ed0>
    c420:	38626862 	ldrb	w2, [x3, x2]
    c424:	7100085f 	cmp	w2, #0x2
    c428:	54002a80 	b.eq	c978 <f0+0x23e4>  // b.none
    c42c:	7100045f 	cmp	w2, #0x1
    c430:	540001a1 	b.ne	c464 <f0+0x1ed0>  // b.any
    c434:	29430002 	ldp	w2, w0, [x0, #24]
    c438:	92403c21 	and	x1, x1, #0xffff
    c43c:	9b027c21 	mul	x1, x1, x2
    c440:	d360fc21 	lsr	x1, x1, #32
    c444:	eb00003f 	cmp	x1, x0
    c448:	540000e2 	b.cs	c464 <f0+0x1ed0>  // b.hs, b.nlast
    c44c:	8b0102b5 	add	x21, x21, x1
    c450:	394002a0 	ldrb	w0, [x21]
    c454:	7103fc1f 	cmp	w0, #0xff
    c458:	54003c20 	b.eq	cbdc <f0+0x2648>  // b.none
    c45c:	52800020 	mov	w0, #0x1                   	// #1
    c460:	390002a0 	strb	w0, [x21]
    c464:	911be3e1 	add	x1, sp, #0x6f8
    c468:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c46c:	52800020 	mov	w0, #0x1                   	// #1
    c470:	f9037ff5 	str	x21, [sp, #1784]
    c474:	f90383f7 	str	x23, [sp, #1792]
    c478:	97ffe50e 	bl	58b0 <fwp_data.part.0.constprop.0>
    c47c:	97ffe591 	bl	5ac0 <fwp_rc_fresh>
    c480:	aa0003e2 	mov	x2, x0
    c484:	911c23e1 	add	x1, sp, #0x708
    c488:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c48c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c490:	52800020 	mov	w0, #0x1                   	// #1
    c494:	f90387f7 	str	x23, [sp, #1800]
    c498:	f9038be2 	str	x2, [sp, #1808]
    c49c:	97ffe505 	bl	58b0 <fwp_data.part.0.constprop.0>
    c4a0:	97ffe588 	bl	5ac0 <fwp_rc_fresh>
    c4a4:	aa0003e2 	mov	x2, x0
    c4a8:	911c63e1 	add	x1, sp, #0x718
    c4ac:	52800020 	mov	w0, #0x1                   	// #1
    c4b0:	f9038ff5 	str	x21, [sp, #1816]
    c4b4:	f90393e2 	str	x2, [sp, #1824]
    c4b8:	97ffe4fe 	bl	58b0 <fwp_data.part.0.constprop.0>
    c4bc:	97ffe581 	bl	5ac0 <fwp_rc_fresh>
    c4c0:	aa0003e2 	mov	x2, x0
    c4c4:	911ca3e1 	add	x1, sp, #0x728
    c4c8:	52800020 	mov	w0, #0x1                   	// #1
    c4cc:	f90397f7 	str	x23, [sp, #1832]
    c4d0:	f9039be2 	str	x2, [sp, #1840]
    c4d4:	97ffe4f7 	bl	58b0 <fwp_data.part.0.constprop.0>
    c4d8:	97ffe57a 	bl	5ac0 <fwp_rc_fresh>
    c4dc:	aa0003e2 	mov	x2, x0
    c4e0:	911ce3e1 	add	x1, sp, #0x738
    c4e4:	52800020 	mov	w0, #0x1                   	// #1
    c4e8:	f9039ff5 	str	x21, [sp, #1848]
    c4ec:	f903a3e2 	str	x2, [sp, #1856]
    c4f0:	97ffe4f0 	bl	58b0 <fwp_data.part.0.constprop.0>
    c4f4:	97ffe573 	bl	5ac0 <fwp_rc_fresh>
    c4f8:	aa0003e2 	mov	x2, x0
    c4fc:	911d23e1 	add	x1, sp, #0x748
    c500:	52800020 	mov	w0, #0x1                   	// #1
    c504:	f903a7f7 	str	x23, [sp, #1864]
    c508:	f903abe2 	str	x2, [sp, #1872]
    c50c:	97ffe4e9 	bl	58b0 <fwp_data.part.0.constprop.0>
    c510:	97ffe56c 	bl	5ac0 <fwp_rc_fresh>
    c514:	aa0003e2 	mov	x2, x0
    c518:	911d63e1 	add	x1, sp, #0x758
    c51c:	52800020 	mov	w0, #0x1                   	// #1
    c520:	f903aff5 	str	x21, [sp, #1880]
    c524:	f903b3e2 	str	x2, [sp, #1888]
    c528:	97ffe4e2 	bl	58b0 <fwp_data.part.0.constprop.0>
    c52c:	91190283 	add	x3, x20, #0x640
    c530:	aa0003f5 	mov	x21, x0
    c534:	f949d861 	ldr	x1, [x3, #5040]
    c538:	f949ec60 	ldr	x0, [x3, #5080]
    c53c:	cb0102a1 	sub	x1, x21, x1
    c540:	eb00403f 	cmp	x1, x0, lsl #16
    c544:	54000322 	b.cs	c5a8 <f0+0x2014>  // b.hs, b.nlast
    c548:	d350fc22 	lsr	x2, x1, #16
    c54c:	f949fc63 	ldr	x3, [x3, #5112]
    c550:	8b020842 	add	x2, x2, x2, lsl #2
    c554:	d37df042 	lsl	x2, x2, #3
    c558:	8b020060 	add	x0, x3, x2
    c55c:	f9401017 	ldr	x23, [x0, #32]
    c560:	b4000257 	cbz	x23, c5a8 <f0+0x2014>
    c564:	38626862 	ldrb	w2, [x3, x2]
    c568:	7100085f 	cmp	w2, #0x2
    c56c:	54002000 	b.eq	c96c <f0+0x23d8>  // b.none
    c570:	7100045f 	cmp	w2, #0x1
    c574:	540001a1 	b.ne	c5a8 <f0+0x2014>  // b.any
    c578:	29430002 	ldp	w2, w0, [x0, #24]
    c57c:	92403c21 	and	x1, x1, #0xffff
    c580:	9b027c21 	mul	x1, x1, x2
    c584:	d360fc21 	lsr	x1, x1, #32
    c588:	eb00003f 	cmp	x1, x0
    c58c:	540000e2 	b.cs	c5a8 <f0+0x2014>  // b.hs, b.nlast
    c590:	8b0102f7 	add	x23, x23, x1
    c594:	394002e0 	ldrb	w0, [x23]
    c598:	7103fc1f 	cmp	w0, #0xff
    c59c:	54003260 	b.eq	cbe8 <f0+0x2654>  // b.none
    c5a0:	52800020 	mov	w0, #0x1                   	// #1
    c5a4:	390002e0 	strb	w0, [x23]
    c5a8:	911da3e1 	add	x1, sp, #0x768
    c5ac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c5b0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c5b4:	52800020 	mov	w0, #0x1                   	// #1
    c5b8:	f903b7f7 	str	x23, [sp, #1896]
    c5bc:	91190294 	add	x20, x20, #0x640
    c5c0:	f903bbf5 	str	x21, [sp, #1904]
    c5c4:	97ffe4bb 	bl	58b0 <fwp_data.part.0.constprop.0>
    c5c8:	97ffe53e 	bl	5ac0 <fwp_rc_fresh>
    c5cc:	aa0003e2 	mov	x2, x0
    c5d0:	911de3e1 	add	x1, sp, #0x778
    c5d4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c5d8:	52800020 	mov	w0, #0x1                   	// #1
    c5dc:	f903bff5 	str	x21, [sp, #1912]
    c5e0:	f903c3e2 	str	x2, [sp, #1920]
    c5e4:	97ffe4b3 	bl	58b0 <fwp_data.part.0.constprop.0>
    c5e8:	97ffe536 	bl	5ac0 <fwp_rc_fresh>
    c5ec:	aa0003e2 	mov	x2, x0
    c5f0:	911e23e1 	add	x1, sp, #0x788
    c5f4:	52800020 	mov	w0, #0x1                   	// #1
    c5f8:	f903c7f7 	str	x23, [sp, #1928]
    c5fc:	f903cbe2 	str	x2, [sp, #1936]
    c600:	97ffe4ac 	bl	58b0 <fwp_data.part.0.constprop.0>
    c604:	97ffe52f 	bl	5ac0 <fwp_rc_fresh>
    c608:	aa0003e2 	mov	x2, x0
    c60c:	911e63e1 	add	x1, sp, #0x798
    c610:	52800020 	mov	w0, #0x1                   	// #1
    c614:	f903cff5 	str	x21, [sp, #1944]
    c618:	f903d3e2 	str	x2, [sp, #1952]
    c61c:	97ffe4a5 	bl	58b0 <fwp_data.part.0.constprop.0>
    c620:	97ffe528 	bl	5ac0 <fwp_rc_fresh>
    c624:	aa0003e2 	mov	x2, x0
    c628:	911ea3e1 	add	x1, sp, #0x7a8
    c62c:	52800020 	mov	w0, #0x1                   	// #1
    c630:	f903d7f7 	str	x23, [sp, #1960]
    c634:	f903dbe2 	str	x2, [sp, #1968]
    c638:	97ffe49e 	bl	58b0 <fwp_data.part.0.constprop.0>
    c63c:	97ffe521 	bl	5ac0 <fwp_rc_fresh>
    c640:	aa0003e2 	mov	x2, x0
    c644:	911ee3e1 	add	x1, sp, #0x7b8
    c648:	52800020 	mov	w0, #0x1                   	// #1
    c64c:	f903dff5 	str	x21, [sp, #1976]
    c650:	f903e3e2 	str	x2, [sp, #1984]
    c654:	97ffe497 	bl	58b0 <fwp_data.part.0.constprop.0>
    c658:	97ffe51a 	bl	5ac0 <fwp_rc_fresh>
    c65c:	aa0003e2 	mov	x2, x0
    c660:	911f23e1 	add	x1, sp, #0x7c8
    c664:	52800020 	mov	w0, #0x1                   	// #1
    c668:	f903e7f7 	str	x23, [sp, #1992]
    c66c:	f903ebe2 	str	x2, [sp, #2000]
    c670:	97ffe490 	bl	58b0 <fwp_data.part.0.constprop.0>
    c674:	97ffe513 	bl	5ac0 <fwp_rc_fresh>
    c678:	aa0003e2 	mov	x2, x0
    c67c:	911f63e1 	add	x1, sp, #0x7d8
    c680:	52800020 	mov	w0, #0x1                   	// #1
    c684:	f903eff5 	str	x21, [sp, #2008]
    c688:	f903f3e2 	str	x2, [sp, #2016]
    c68c:	97ffe489 	bl	58b0 <fwp_data.part.0.constprop.0>
    c690:	f949da81 	ldr	x1, [x20, #5040]
    c694:	aa0003f5 	mov	x21, x0
    c698:	f949ee80 	ldr	x0, [x20, #5080]
    c69c:	cb0102a1 	sub	x1, x21, x1
    c6a0:	eb00403f 	cmp	x1, x0, lsl #16
    c6a4:	54000322 	b.cs	c708 <f0+0x2174>  // b.hs, b.nlast
    c6a8:	d350fc22 	lsr	x2, x1, #16
    c6ac:	f949fe83 	ldr	x3, [x20, #5112]
    c6b0:	8b020842 	add	x2, x2, x2, lsl #2
    c6b4:	d37df042 	lsl	x2, x2, #3
    c6b8:	8b020060 	add	x0, x3, x2
    c6bc:	f9401014 	ldr	x20, [x0, #32]
    c6c0:	b4000254 	cbz	x20, c708 <f0+0x2174>
    c6c4:	38626862 	ldrb	w2, [x3, x2]
    c6c8:	7100085f 	cmp	w2, #0x2
    c6cc:	540014a0 	b.eq	c960 <f0+0x23cc>  // b.none
    c6d0:	7100045f 	cmp	w2, #0x1
    c6d4:	540001a1 	b.ne	c708 <f0+0x2174>  // b.any
    c6d8:	29430002 	ldp	w2, w0, [x0, #24]
    c6dc:	92403c21 	and	x1, x1, #0xffff
    c6e0:	9b027c21 	mul	x1, x1, x2
    c6e4:	d360fc21 	lsr	x1, x1, #32
    c6e8:	eb00003f 	cmp	x1, x0
    c6ec:	540000e2 	b.cs	c708 <f0+0x2174>  // b.hs, b.nlast
    c6f0:	8b010294 	add	x20, x20, x1
    c6f4:	39400280 	ldrb	w0, [x20]
    c6f8:	7103fc1f 	cmp	w0, #0xff
    c6fc:	54001920 	b.eq	ca20 <f0+0x248c>  // b.none
    c700:	52800020 	mov	w0, #0x1                   	// #1
    c704:	39000280 	strb	w0, [x20]
    c708:	911fa3e1 	add	x1, sp, #0x7e8
    c70c:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c710:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c714:	52800020 	mov	w0, #0x1                   	// #1
    c718:	f903f7f4 	str	x20, [sp, #2024]
    c71c:	f903fbf5 	str	x21, [sp, #2032]
    c720:	97ffe464 	bl	58b0 <fwp_data.part.0.constprop.0>
    c724:	97ffe4e7 	bl	5ac0 <fwp_rc_fresh>
    c728:	aa0003e2 	mov	x2, x0
    c72c:	911fe3e1 	add	x1, sp, #0x7f8
    c730:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c734:	52800020 	mov	w0, #0x1                   	// #1
    c738:	f903fff5 	str	x21, [sp, #2040]
    c73c:	f90403e2 	str	x2, [sp, #2048]
    c740:	97ffe45c 	bl	58b0 <fwp_data.part.0.constprop.0>
    c744:	97ffe4df 	bl	5ac0 <fwp_rc_fresh>
    c748:	aa0003e2 	mov	x2, x0
    c74c:	912023e1 	add	x1, sp, #0x808
    c750:	52800020 	mov	w0, #0x1                   	// #1
    c754:	f90407f4 	str	x20, [sp, #2056]
    c758:	f9040be2 	str	x2, [sp, #2064]
    c75c:	97ffe455 	bl	58b0 <fwp_data.part.0.constprop.0>
    c760:	97ffe4d8 	bl	5ac0 <fwp_rc_fresh>
    c764:	aa0003e2 	mov	x2, x0
    c768:	912063e1 	add	x1, sp, #0x818
    c76c:	52800020 	mov	w0, #0x1                   	// #1
    c770:	f9040ff5 	str	x21, [sp, #2072]
    c774:	f90413e2 	str	x2, [sp, #2080]
    c778:	97ffe44e 	bl	58b0 <fwp_data.part.0.constprop.0>
    c77c:	97ffe4d1 	bl	5ac0 <fwp_rc_fresh>
    c780:	aa0003e2 	mov	x2, x0
    c784:	9120a3e1 	add	x1, sp, #0x828
    c788:	52800020 	mov	w0, #0x1                   	// #1
    c78c:	f90417f4 	str	x20, [sp, #2088]
    c790:	f9041be2 	str	x2, [sp, #2096]
    c794:	97ffe447 	bl	58b0 <fwp_data.part.0.constprop.0>
    c798:	97ffe4ca 	bl	5ac0 <fwp_rc_fresh>
    c79c:	aa0003e2 	mov	x2, x0
    c7a0:	9120e3e1 	add	x1, sp, #0x838
    c7a4:	52800020 	mov	w0, #0x1                   	// #1
    c7a8:	f9041ff5 	str	x21, [sp, #2104]
    c7ac:	f90423e2 	str	x2, [sp, #2112]
    c7b0:	97ffe440 	bl	58b0 <fwp_data.part.0.constprop.0>
    c7b4:	97ffe4c3 	bl	5ac0 <fwp_rc_fresh>
    c7b8:	aa0003e2 	mov	x2, x0
    c7bc:	aa1603e1 	mov	x1, x22
    c7c0:	52800020 	mov	w0, #0x1                   	// #1
    c7c4:	f90427f4 	str	x20, [sp, #2120]
    c7c8:	f9042be2 	str	x2, [sp, #2128]
    c7cc:	97ffe439 	bl	58b0 <fwp_data.part.0.constprop.0>
    c7d0:	97ffe4bc 	bl	5ac0 <fwp_rc_fresh>
    c7d4:	aa0003f5 	mov	x21, x0
    c7d8:	aa1303e1 	mov	x1, x19
    c7dc:	97fff459 	bl	9940 <fwp_hof0.constprop.0>
    c7e0:	aa0003f4 	mov	x20, x0
    c7e4:	aa1503e0 	mov	x0, x21
    c7e8:	97ffe616 	bl	6040 <fwp_drop0>
    c7ec:	aa1303e0 	mov	x0, x19
    c7f0:	97ffe614 	bl	6040 <fwp_drop0>
    c7f4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    c7f8:	f947f400 	ldr	x0, [x0, #4072]
    c7fc:	f9442fe2 	ldr	x2, [sp, #2136]
    c800:	f9400001 	ldr	x1, [x0]
    c804:	eb010042 	subs	x2, x2, x1
    c808:	d2800001 	mov	x1, #0x0                   	// #0
    c80c:	54001f41 	b.ne	cbf4 <f0+0x2660>  // b.any
    c810:	912183ff 	add	sp, sp, #0x860
    c814:	aa1403e0 	mov	x0, x20
    c818:	a94153f3 	ldp	x19, x20, [sp, #16]
    c81c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c820:	a94363f7 	ldp	x23, x24, [sp, #48]
    c824:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c828:	a94573fb 	ldp	x27, x28, [sp, #80]
    c82c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c830:	d65f03c0 	ret
    c834:	aa1b03e0 	mov	x0, x27
    c838:	97ffe056 	bl	4990 <fwp_rc_forget_slot>
    c83c:	17fff79f 	b	a6b8 <f0+0x124>
    c840:	72003c5f 	tst	w2, #0xffff
    c844:	54fef3c1 	b.ne	a6bc <f0+0x128>  // b.any
    c848:	17fff799 	b	a6ac <f0+0x118>
    c84c:	72003c3f 	tst	w1, #0xffff
    c850:	54ff8b01 	b.ne	b9b0 <f0+0x141c>  // b.any
    c854:	17fffc52 	b	b99c <f0+0x1408>
    c858:	72003c3f 	tst	w1, #0xffff
    c85c:	54ff84e1 	b.ne	b8f8 <f0+0x1364>  // b.any
    c860:	17fffc21 	b	b8e4 <f0+0x1350>
    c864:	72003c3f 	tst	w1, #0xffff
    c868:	54ff7ec1 	b.ne	b840 <f0+0x12ac>  // b.any
    c86c:	17fffbf0 	b	b82c <f0+0x1298>
    c870:	72003c3f 	tst	w1, #0xffff
    c874:	54ff79c1 	b.ne	b7ac <f0+0x1218>  // b.any
    c878:	17fffbc8 	b	b798 <f0+0x1204>
    c87c:	72003c3f 	tst	w1, #0xffff
    c880:	54ff6f41 	b.ne	b668 <f0+0x10d4>  // b.any
    c884:	17fffb74 	b	b654 <f0+0x10c0>
    c888:	72003c3f 	tst	w1, #0xffff
    c88c:	54ff6761 	b.ne	b578 <f0+0xfe4>  // b.any
    c890:	17fffb35 	b	b564 <f0+0xfd0>
    c894:	72003c3f 	tst	w1, #0xffff
    c898:	54ff57a1 	b.ne	b38c <f0+0xdf8>  // b.any
    c89c:	17fffab7 	b	b378 <f0+0xde4>
    c8a0:	72003c3f 	tst	w1, #0xffff
    c8a4:	54ff5281 	b.ne	b2f4 <f0+0xd60>  // b.any
    c8a8:	17fffa8e 	b	b2e0 <f0+0xd4c>
    c8ac:	72003c3f 	tst	w1, #0xffff
    c8b0:	54ff02c1 	b.ne	a908 <f0+0x374>  // b.any
    c8b4:	17fff810 	b	a8f4 <f0+0x360>
    c8b8:	72003c3f 	tst	w1, #0xffff
    c8bc:	54fefce1 	b.ne	a858 <f0+0x2c4>  // b.any
    c8c0:	17fff7e1 	b	a844 <f0+0x2b0>
    c8c4:	72003c3f 	tst	w1, #0xffff
    c8c8:	54fef7e1 	b.ne	a7c4 <f0+0x230>  // b.any
    c8cc:	17fff7b9 	b	a7b0 <f0+0x21c>
    c8d0:	72003c3f 	tst	w1, #0xffff
    c8d4:	54ff1b61 	b.ne	ac40 <f0+0x6ac>  // b.any
    c8d8:	17fff8d5 	b	ac2c <f0+0x698>
    c8dc:	72003c3f 	tst	w1, #0xffff
    c8e0:	54ff1401 	b.ne	ab60 <f0+0x5cc>  // b.any
    c8e4:	17fff89a 	b	ab4c <f0+0x5b8>
    c8e8:	72003c3f 	tst	w1, #0xffff
    c8ec:	54ff0e21 	b.ne	aab0 <f0+0x51c>  // b.any
    c8f0:	17fff86b 	b	aa9c <f0+0x508>
    c8f4:	72003c3f 	tst	w1, #0xffff
    c8f8:	54ff0601 	b.ne	a9b8 <f0+0x424>  // b.any
    c8fc:	17fff82a 	b	a9a4 <f0+0x410>
    c900:	72003c3f 	tst	w1, #0xffff
    c904:	54ff49c1 	b.ne	b23c <f0+0xca8>  // b.any
    c908:	17fffa48 	b	b228 <f0+0xc94>
    c90c:	72003c3f 	tst	w1, #0xffff
    c910:	54ff43a1 	b.ne	b184 <f0+0xbf0>  // b.any
    c914:	17fffa17 	b	b170 <f0+0xbdc>
    c918:	72003c3f 	tst	w1, #0xffff
    c91c:	54ff3d81 	b.ne	b0cc <f0+0xb38>  // b.any
    c920:	17fff9e6 	b	b0b8 <f0+0xb24>
    c924:	72003c3f 	tst	w1, #0xffff
    c928:	54ff3881 	b.ne	b038 <f0+0xaa4>  // b.any
    c92c:	17fff9be 	b	b024 <f0+0xa90>
    c930:	72003c3f 	tst	w1, #0xffff
    c934:	54ff2e01 	b.ne	aef4 <f0+0x960>  // b.any
    c938:	17fff96a 	b	aee0 <f0+0x94c>
    c93c:	72003c3f 	tst	w1, #0xffff
    c940:	54ff2921 	b.ne	ae64 <f0+0x8d0>  // b.any
    c944:	17fff943 	b	ae50 <f0+0x8bc>
    c948:	72003c3f 	tst	w1, #0xffff
    c94c:	54ff2421 	b.ne	add0 <f0+0x83c>  // b.any
    c950:	17fff91b 	b	adbc <f0+0x828>
    c954:	72003c3f 	tst	w1, #0xffff
    c958:	54ff1e41 	b.ne	ad20 <f0+0x78c>  // b.any
    c95c:	17fff8ec 	b	ad0c <f0+0x778>
    c960:	72003c3f 	tst	w1, #0xffff
    c964:	54ffed21 	b.ne	c708 <f0+0x2174>  // b.any
    c968:	17ffff63 	b	c6f4 <f0+0x2160>
    c96c:	72003c3f 	tst	w1, #0xffff
    c970:	54ffe1c1 	b.ne	c5a8 <f0+0x2014>  // b.any
    c974:	17ffff08 	b	c594 <f0+0x2000>
    c978:	72003c3f 	tst	w1, #0xffff
    c97c:	54ffd741 	b.ne	c464 <f0+0x1ed0>  // b.any
    c980:	17fffeb4 	b	c450 <f0+0x1ebc>
    c984:	72003c3f 	tst	w1, #0xffff
    c988:	54ffd221 	b.ne	c3cc <f0+0x1e38>  // b.any
    c98c:	17fffe8b 	b	c3b8 <f0+0x1e24>
    c990:	72003c3f 	tst	w1, #0xffff
    c994:	54ffcc01 	b.ne	c314 <f0+0x1d80>  // b.any
    c998:	17fffe5a 	b	c300 <f0+0x1d6c>
    c99c:	72003c3f 	tst	w1, #0xffff
    c9a0:	54ffc421 	b.ne	c224 <f0+0x1c90>  // b.any
    c9a4:	17fffe1b 	b	c210 <f0+0x1c7c>
    c9a8:	72003c3f 	tst	w1, #0xffff
    c9ac:	54ffbf21 	b.ne	c190 <f0+0x1bfc>  // b.any
    c9b0:	17fffdf3 	b	c17c <f0+0x1be8>
    c9b4:	72003c3f 	tst	w1, #0xffff
    c9b8:	54ffb661 	b.ne	c084 <f0+0x1af0>  // b.any
    c9bc:	17fffdad 	b	c070 <f0+0x1adc>
    c9c0:	72003c3f 	tst	w1, #0xffff
    c9c4:	54ffb041 	b.ne	bfcc <f0+0x1a38>  // b.any
    c9c8:	17fffd7c 	b	bfb8 <f0+0x1a24>
    c9cc:	72003c3f 	tst	w1, #0xffff
    c9d0:	54ffab41 	b.ne	bf38 <f0+0x19a4>  // b.any
    c9d4:	17fffd54 	b	bf24 <f0+0x1990>
    c9d8:	72003c3f 	tst	w1, #0xffff
    c9dc:	54ffa621 	b.ne	bea0 <f0+0x190c>  // b.any
    c9e0:	17fffd2b 	b	be8c <f0+0x18f8>
    c9e4:	72003c3f 	tst	w1, #0xffff
    c9e8:	54ffa001 	b.ne	bde8 <f0+0x1854>  // b.any
    c9ec:	17fffcfa 	b	bdd4 <f0+0x1840>
    c9f0:	72003c3f 	tst	w1, #0xffff
    c9f4:	54ff9821 	b.ne	bcf8 <f0+0x1764>  // b.any
    c9f8:	17fffcbb 	b	bce4 <f0+0x1750>
    c9fc:	72003c3f 	tst	w1, #0xffff
    ca00:	54ff9321 	b.ne	bc64 <f0+0x16d0>  // b.any
    ca04:	17fffc93 	b	bc50 <f0+0x16bc>
    ca08:	72003c3f 	tst	w1, #0xffff
    ca0c:	54ff8c21 	b.ne	bb90 <f0+0x15fc>  // b.any
    ca10:	17fffc5b 	b	bb7c <f0+0x15e8>
    ca14:	72003c3f 	tst	w1, #0xffff
    ca18:	54ff8441 	b.ne	baa0 <f0+0x150c>  // b.any
    ca1c:	17fffc1c 	b	ba8c <f0+0x14f8>
    ca20:	aa1403e0 	mov	x0, x20
    ca24:	97ffdfdb 	bl	4990 <fwp_rc_forget_slot>
    ca28:	17ffff36 	b	c700 <f0+0x216c>
    ca2c:	aa1703e0 	mov	x0, x23
    ca30:	97ffdfd8 	bl	4990 <fwp_rc_forget_slot>
    ca34:	17fff762 	b	a7bc <f0+0x228>
    ca38:	aa1703e0 	mov	x0, x23
    ca3c:	97ffdfd5 	bl	4990 <fwp_rc_forget_slot>
    ca40:	17fff784 	b	a850 <f0+0x2bc>
    ca44:	aa1703e0 	mov	x0, x23
    ca48:	97ffdfd2 	bl	4990 <fwp_rc_forget_slot>
    ca4c:	17fff7ad 	b	a900 <f0+0x36c>
    ca50:	aa1703e0 	mov	x0, x23
    ca54:	97ffdfcf 	bl	4990 <fwp_rc_forget_slot>
    ca58:	17fff7d6 	b	a9b0 <f0+0x41c>
    ca5c:	aa1703e0 	mov	x0, x23
    ca60:	97ffdfcc 	bl	4990 <fwp_rc_forget_slot>
    ca64:	17fff811 	b	aaa8 <f0+0x514>
    ca68:	aa1703e0 	mov	x0, x23
    ca6c:	97ffdfc9 	bl	4990 <fwp_rc_forget_slot>
    ca70:	17fff83a 	b	ab58 <f0+0x5c4>
    ca74:	aa1703e0 	mov	x0, x23
    ca78:	97ffdfc6 	bl	4990 <fwp_rc_forget_slot>
    ca7c:	17fff86f 	b	ac38 <f0+0x6a4>
    ca80:	aa1703e0 	mov	x0, x23
    ca84:	97ffdfc3 	bl	4990 <fwp_rc_forget_slot>
    ca88:	17fff8a4 	b	ad18 <f0+0x784>
    ca8c:	aa1703e0 	mov	x0, x23
    ca90:	97ffdfc0 	bl	4990 <fwp_rc_forget_slot>
    ca94:	17fff8cd 	b	adc8 <f0+0x834>
    ca98:	aa1703e0 	mov	x0, x23
    ca9c:	97ffdfbd 	bl	4990 <fwp_rc_forget_slot>
    caa0:	17fff8ef 	b	ae5c <f0+0x8c8>
    caa4:	aa1503e0 	mov	x0, x21
    caa8:	97ffdfba 	bl	4990 <fwp_rc_forget_slot>
    caac:	17fff910 	b	aeec <f0+0x958>
    cab0:	aa1703e0 	mov	x0, x23
    cab4:	97ffdfb7 	bl	4990 <fwp_rc_forget_slot>
    cab8:	17fff95e 	b	b030 <f0+0xa9c>
    cabc:	aa1703e0 	mov	x0, x23
    cac0:	97ffdfb4 	bl	4990 <fwp_rc_forget_slot>
    cac4:	17fff980 	b	b0c4 <f0+0xb30>
    cac8:	aa1703e0 	mov	x0, x23
    cacc:	97ffdfb1 	bl	4990 <fwp_rc_forget_slot>
    cad0:	17fff9ab 	b	b17c <f0+0xbe8>
    cad4:	aa1703e0 	mov	x0, x23
    cad8:	97ffdfae 	bl	4990 <fwp_rc_forget_slot>
    cadc:	17fff9d6 	b	b234 <f0+0xca0>
    cae0:	aa1703e0 	mov	x0, x23
    cae4:	97ffdfab 	bl	4990 <fwp_rc_forget_slot>
    cae8:	17fffa01 	b	b2ec <f0+0xd58>
    caec:	aa1503e0 	mov	x0, x21
    caf0:	97ffdfa8 	bl	4990 <fwp_rc_forget_slot>
    caf4:	17fffa24 	b	b384 <f0+0xdf0>
    caf8:	aa1703e0 	mov	x0, x23
    cafc:	97ffdfa5 	bl	4990 <fwp_rc_forget_slot>
    cb00:	17fffa9c 	b	b570 <f0+0xfdc>
    cb04:	aa1503e0 	mov	x0, x21
    cb08:	97ffdfa2 	bl	4990 <fwp_rc_forget_slot>
    cb0c:	17fffad5 	b	b660 <f0+0x10cc>
    cb10:	aa1703e0 	mov	x0, x23
    cb14:	97ffdf9f 	bl	4990 <fwp_rc_forget_slot>
    cb18:	17fffb23 	b	b7a4 <f0+0x1210>
    cb1c:	aa1703e0 	mov	x0, x23
    cb20:	97ffdf9c 	bl	4990 <fwp_rc_forget_slot>
    cb24:	17fffb45 	b	b838 <f0+0x12a4>
    cb28:	aa1703e0 	mov	x0, x23
    cb2c:	97ffdf99 	bl	4990 <fwp_rc_forget_slot>
    cb30:	17fffb70 	b	b8f0 <f0+0x135c>
    cb34:	aa1703e0 	mov	x0, x23
    cb38:	97ffdf96 	bl	4990 <fwp_rc_forget_slot>
    cb3c:	17fffb9b 	b	b9a8 <f0+0x1414>
    cb40:	aa1703e0 	mov	x0, x23
    cb44:	97ffdf93 	bl	4990 <fwp_rc_forget_slot>
    cb48:	17fffbd4 	b	ba98 <f0+0x1504>
    cb4c:	aa1703e0 	mov	x0, x23
    cb50:	97ffdf90 	bl	4990 <fwp_rc_forget_slot>
    cb54:	17fffc0d 	b	bb88 <f0+0x15f4>
    cb58:	aa1703e0 	mov	x0, x23
    cb5c:	97ffdf8d 	bl	4990 <fwp_rc_forget_slot>
    cb60:	17fffc3f 	b	bc5c <f0+0x16c8>
    cb64:	aa1703e0 	mov	x0, x23
    cb68:	97ffdf8a 	bl	4990 <fwp_rc_forget_slot>
    cb6c:	17fffc61 	b	bcf0 <f0+0x175c>
    cb70:	aa1703e0 	mov	x0, x23
    cb74:	97ffdf87 	bl	4990 <fwp_rc_forget_slot>
    cb78:	17fffc9a 	b	bde0 <f0+0x184c>
    cb7c:	aa1703e0 	mov	x0, x23
    cb80:	97ffdf84 	bl	4990 <fwp_rc_forget_slot>
    cb84:	17fffcc5 	b	be98 <f0+0x1904>
    cb88:	aa1703e0 	mov	x0, x23
    cb8c:	97ffdf81 	bl	4990 <fwp_rc_forget_slot>
    cb90:	17fffce8 	b	bf30 <f0+0x199c>
    cb94:	aa1703e0 	mov	x0, x23
    cb98:	97ffdf7e 	bl	4990 <fwp_rc_forget_slot>
    cb9c:	17fffd0a 	b	bfc4 <f0+0x1a30>
    cba0:	aa1703e0 	mov	x0, x23
    cba4:	97ffdf7b 	bl	4990 <fwp_rc_forget_slot>
    cba8:	17fffd35 	b	c07c <f0+0x1ae8>
    cbac:	aa1703e0 	mov	x0, x23
    cbb0:	97ffdf78 	bl	4990 <fwp_rc_forget_slot>
    cbb4:	17fffd75 	b	c188 <f0+0x1bf4>
    cbb8:	aa1703e0 	mov	x0, x23
    cbbc:	97ffdf75 	bl	4990 <fwp_rc_forget_slot>
    cbc0:	17fffd97 	b	c21c <f0+0x1c88>
    cbc4:	aa1703e0 	mov	x0, x23
    cbc8:	97ffdf72 	bl	4990 <fwp_rc_forget_slot>
    cbcc:	17fffdd0 	b	c30c <f0+0x1d78>
    cbd0:	aa1703e0 	mov	x0, x23
    cbd4:	97ffdf6f 	bl	4990 <fwp_rc_forget_slot>
    cbd8:	17fffdfb 	b	c3c4 <f0+0x1e30>
    cbdc:	aa1503e0 	mov	x0, x21
    cbe0:	97ffdf6c 	bl	4990 <fwp_rc_forget_slot>
    cbe4:	17fffe1e 	b	c45c <f0+0x1ec8>
    cbe8:	aa1703e0 	mov	x0, x23
    cbec:	97ffdf69 	bl	4990 <fwp_rc_forget_slot>
    cbf0:	17fffe6c 	b	c5a0 <f0+0x200c>
    cbf4:	97ffd707 	bl	2810 <__stack_chk_fail@plt>
    cbf8:	d503201f 	nop
    cbfc:	d503201f 	nop

000000000000cc00 <fwp_main_thread>:
    cc00:	d10443ff 	sub	sp, sp, #0x110
    cc04:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    cc08:	f947f400 	ldr	x0, [x0, #4072]
    cc0c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cc10:	910303fd 	add	x29, sp, #0xc0
    cc14:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cc18:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xba0>
    cc1c:	911902c1 	add	x1, x22, #0x640
    cc20:	a90d53f3 	stp	x19, x20, [sp, #208]
    cc24:	a90f63f7 	stp	x23, x24, [sp, #240]
    cc28:	b953a421 	ldr	w1, [x1, #5028]
    cc2c:	a9106bf9 	stp	x25, x26, [sp, #256]
    cc30:	f9400002 	ldr	x2, [x0]
    cc34:	f9005fe2 	str	x2, [sp, #184]
    cc38:	d2800002 	mov	x2, #0x0                   	// #0
    cc3c:	34002961 	cbz	w1, d168 <fwp_main_thread+0x568>
    cc40:	911902c0 	add	x0, x22, #0x640
    cc44:	b953a800 	ldr	w0, [x0, #5032]
    cc48:	35002880 	cbnz	w0, d158 <fwp_main_thread+0x558>
    cc4c:	91001fe2 	add	x2, sp, #0x7
    cc50:	900000b5 	adrp	x21, 20000 <__data_start>
    cc54:	900000a3 	adrp	x3, 20000 <__data_start>
    cc58:	910182b3 	add	x19, x21, #0x60
    cc5c:	91118063 	add	x3, x3, #0x460
    cc60:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cc64:	d2a00025 	mov	x5, #0x10000               	// #65536
    cc68:	910023e0 	add	x0, sp, #0x8
    cc6c:	d2800001 	mov	x1, #0x0                   	// #0
    cc70:	f90007e3 	str	x3, [sp, #8]
    cc74:	b90013ff 	str	wzr, [sp, #16]
    cc78:	f9000fe5 	str	x5, [sp, #24]
    cc7c:	a90a1262 	stp	x2, x4, [x19, #160]
    cc80:	97ffd67c 	bl	2670 <sigaltstack@plt>
    cc84:	350028a0 	cbnz	w0, d198 <fwp_main_thread+0x598>
    cc88:	4f000400 	movi	v0.4s, #0x0
    cc8c:	9100a3e0 	add	x0, sp, #0x28
    cc90:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0xc>
    cc94:	52800082 	mov	w2, #0x4                   	// #4
    cc98:	9100c021 	add	x1, x1, #0x30
    cc9c:	72a10002 	movk	w2, #0x800, lsl #16
    cca0:	910083f4 	add	x20, sp, #0x20
    cca4:	f90013e1 	str	x1, [sp, #32]
    cca8:	3d802000 	str	q0, [x0, #128]
    ccac:	b900abe2 	str	w2, [sp, #168]
    ccb0:	ad000000 	stp	q0, q0, [x0]
    ccb4:	ad010000 	stp	q0, q0, [x0, #32]
    ccb8:	ad020000 	stp	q0, q0, [x0, #64]
    ccbc:	ad030000 	stp	q0, q0, [x0, #96]
    ccc0:	97ffd6c4 	bl	27d0 <sigemptyset@plt>
    ccc4:	350026a0 	cbnz	w0, d198 <fwp_main_thread+0x598>
    ccc8:	aa1403e1 	mov	x1, x20
    cccc:	d2800002 	mov	x2, #0x0                   	// #0
    ccd0:	52800160 	mov	w0, #0xb                   	// #11
    ccd4:	97ffd6d7 	bl	2830 <sigaction@plt>
    ccd8:	35002600 	cbnz	w0, d198 <fwp_main_thread+0x598>
    ccdc:	aa1403e1 	mov	x1, x20
    cce0:	d2800002 	mov	x2, #0x0                   	// #0
    cce4:	528000e0 	mov	w0, #0x7                   	// #7
    cce8:	97ffd6d2 	bl	2830 <sigaction@plt>
    ccec:	35002560 	cbnz	w0, d198 <fwp_main_thread+0x598>
    ccf0:	911902c1 	add	x1, x22, #0x640
    ccf4:	52800034 	mov	w20, #0x1                   	// #1
    ccf8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    ccfc:	910cc000 	add	x0, x0, #0x330
    cd00:	b9013274 	str	w20, [x19, #304]
    cd04:	fd4a1020 	ldr	d0, [x1, #5152]
    cd08:	7e61d800 	ucvtf	d0, d0
    cd0c:	fd00a660 	str	d0, [x19, #328]
    cd10:	940002e8 	bl	d8b0 <atexit>
    cd14:	35002480 	cbnz	w0, d1a4 <fwp_main_thread+0x5a4>
    cd18:	b943ca60 	ldr	w0, [x19, #968]
    cd1c:	340022a0 	cbz	w0, d170 <fwp_main_thread+0x570>
    cd20:	910182ba 	add	x26, x21, #0x60
    cd24:	f9404f54 	ldr	x20, [x26, #152]
    cd28:	b40010b4 	cbz	x20, cf3c <fwp_main_thread+0x33c>
    cd2c:	aa1403f3 	mov	x19, x20
    cd30:	91010297 	add	x23, x20, #0x40
    cd34:	39414a99 	ldrb	w25, [x20, #82]
    cd38:	52800038 	mov	w24, #0x1                   	// #1
    cd3c:	39014a98 	strb	w24, [x20, #82]
    cd40:	f9401680 	ldr	x0, [x20, #40]
    cd44:	b4000620 	cbz	x0, ce08 <fwp_main_thread+0x208>
    cd48:	f9403281 	ldr	x1, [x20, #96]
    cd4c:	39414680 	ldrb	w0, [x20, #81]
    cd50:	b4000b41 	cbz	x1, ceb8 <fwp_main_thread+0x2b8>
    cd54:	36000a80 	tbz	w0, #0, cea4 <fwp_main_thread+0x2a4>
    cd58:	39414a62 	ldrb	w2, [x19, #82]
    cd5c:	f9402280 	ldr	x0, [x20, #64]
    cd60:	37000d62 	tbnz	w2, #0, cf0c <fwp_main_thread+0x30c>
    cd64:	f9403261 	ldr	x1, [x19, #96]
    cd68:	a911fe77 	stp	x23, xzr, [x19, #280]
    cd6c:	f9009660 	str	x0, [x19, #296]
    cd70:	b4000040 	cbz	x0, cd78 <fwp_main_thread+0x178>
    cd74:	f9009013 	str	x19, [x0, #288]
    cd78:	f9002293 	str	x19, [x20, #64]
    cd7c:	b4000101 	cbz	x1, cd9c <fwp_main_thread+0x19c>
    cd80:	f9409740 	ldr	x0, [x26, #296]
    cd84:	39015678 	strb	w24, [x19, #85]
    cd88:	f9003661 	str	x1, [x19, #104]
    cd8c:	a910827f 	stp	xzr, x0, [x19, #264]
    cd90:	b4000040 	cbz	x0, cd98 <fwp_main_thread+0x198>
    cd94:	f9008413 	str	x19, [x0, #264]
    cd98:	f9009753 	str	x19, [x26, #296]
    cd9c:	39015a7f 	strb	wzr, [x19, #86]
    cda0:	97ffe6e5 	bl	6934 <fwp_block>
    cda4:	f9408e62 	ldr	x2, [x19, #280]
    cda8:	b4000142 	cbz	x2, cdd0 <fwp_main_thread+0x1d0>
    cdac:	a9520261 	ldp	x1, x0, [x19, #288]
    cdb0:	b4000ba1 	cbz	x1, cf24 <fwp_main_thread+0x324>
    cdb4:	f9009420 	str	x0, [x1, #296]
    cdb8:	f9409660 	ldr	x0, [x19, #296]
    cdbc:	b4000040 	cbz	x0, cdc4 <fwp_main_thread+0x1c4>
    cdc0:	f9009001 	str	x1, [x0, #288]
    cdc4:	91080260 	add	x0, x19, #0x200
    cdc8:	f900967f 	str	xzr, [x19, #296]
    cdcc:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cdd0:	39415660 	ldrb	w0, [x19, #85]
    cdd4:	f9404f42 	ldr	x2, [x26, #152]
    cdd8:	36000960 	tbz	w0, #0, cf04 <fwp_main_thread+0x304>
    cddc:	a9508261 	ldp	x1, x0, [x19, #264]
    cde0:	b4000a61 	cbz	x1, cf2c <fwp_main_thread+0x32c>
    cde4:	f9008820 	str	x0, [x1, #272]
    cde8:	b4000040 	cbz	x0, cdf0 <fwp_main_thread+0x1f0>
    cdec:	f9008401 	str	x1, [x0, #264]
    cdf0:	91080260 	add	x0, x19, #0x200
    cdf4:	3901567f 	strb	wzr, [x19, #85]
    cdf8:	aa0203f3 	mov	x19, x2
    cdfc:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    ce00:	f9401680 	ldr	x0, [x20, #40]
    ce04:	b5fffa20 	cbnz	x0, cd48 <fwp_main_thread+0x148>
    ce08:	910182a0 	add	x0, x21, #0x60
    ce0c:	39014a99 	strb	w25, [x20, #82]
    ce10:	f941d400 	ldr	x0, [x0, #936]
    ce14:	b4001840 	cbz	x0, d11c <fwp_main_thread+0x51c>
    ce18:	910182a0 	add	x0, x21, #0x60
    ce1c:	f941f001 	ldr	x1, [x0, #992]
    ce20:	b903d81f 	str	wzr, [x0, #984]
    ce24:	eb13003f 	cmp	x1, x19
    ce28:	54001961 	b.ne	d154 <fwp_main_thread+0x554>  // b.any
    ce2c:	b4000933 	cbz	x19, cf50 <fwp_main_thread+0x350>
    ce30:	910182a0 	add	x0, x21, #0x60
    ce34:	52800021 	mov	w1, #0x1                   	// #1
    ce38:	39014a61 	strb	w1, [x19, #82]
    ce3c:	f941c005 	ldr	x5, [x0, #896]
    ce40:	b4000885 	cbz	x5, cf50 <fwp_main_thread+0x350>
    ce44:	d503201f 	nop
    ce48:	394140a0 	ldrb	w0, [x5, #80]
    ce4c:	37000060 	tbnz	w0, #0, ce58 <fwp_main_thread+0x258>
    ce50:	aa0503e0 	mov	x0, x5
    ce54:	97ffda07 	bl	3670 <fwp_cancel_tree.part.0>
    ce58:	f9409ca5 	ldr	x5, [x5, #312]
    ce5c:	b5ffff65 	cbnz	x5, ce48 <fwp_main_thread+0x248>
    ce60:	910182b4 	add	x20, x21, #0x60
    ce64:	52800037 	mov	w23, #0x1                   	// #1
    ce68:	f9402a60 	ldr	x0, [x19, #80]
    ce6c:	f2001c1f 	tst	x0, #0xff000000ff
    ce70:	540000e1 	b.ne	ce8c <fwp_main_thread+0x28c>  // b.any
    ce74:	f9406280 	ldr	x0, [x20, #192]
    ce78:	39015277 	strb	w23, [x19, #84]
    ce7c:	f900827f 	str	xzr, [x19, #256]
    ce80:	b40005a0 	cbz	x0, cf34 <fwp_main_thread+0x334>
    ce84:	f9008013 	str	x19, [x0, #256]
    ce88:	f9006293 	str	x19, [x20, #192]
    ce8c:	97ffe6aa 	bl	6934 <fwp_block>
    ce90:	97ffe63c 	bl	6780 <fwp_free_zombie>
    ce94:	f941c280 	ldr	x0, [x20, #896]
    ce98:	b40005c0 	cbz	x0, cf50 <fwp_main_thread+0x350>
    ce9c:	f941f293 	ldr	x19, [x20, #992]
    cea0:	17fffff2 	b	ce68 <fwp_main_thread+0x268>
    cea4:	97ffda97 	bl	3900 <fwp_now_ns>
    cea8:	f9403281 	ldr	x1, [x20, #96]
    ceac:	eb01001f 	cmp	x0, x1
    ceb0:	5400128a 	b.ge	d100 <fwp_main_thread+0x500>  // b.tcont
    ceb4:	39414680 	ldrb	w0, [x20, #81]
    ceb8:	39414a62 	ldrb	w2, [x19, #82]
    cebc:	3707f500 	tbnz	w0, #0, cd5c <fwp_main_thread+0x15c>
    cec0:	f9403281 	ldr	x1, [x20, #96]
    cec4:	370001c2 	tbnz	w2, #0, cefc <fwp_main_thread+0x2fc>
    cec8:	f9403260 	ldr	x0, [x19, #96]
    cecc:	b4000180 	cbz	x0, cefc <fwp_main_thread+0x2fc>
    ced0:	b4000061 	cbz	x1, cedc <fwp_main_thread+0x2dc>
    ced4:	eb01001f 	cmp	x0, x1
    ced8:	9a81d000 	csel	x0, x0, x1, le
    cedc:	f9402281 	ldr	x1, [x20, #64]
    cee0:	a911fe77 	stp	x23, xzr, [x19, #280]
    cee4:	f9009661 	str	x1, [x19, #296]
    cee8:	b40014c1 	cbz	x1, d180 <fwp_main_thread+0x580>
    ceec:	f9009033 	str	x19, [x1, #288]
    cef0:	aa0003e1 	mov	x1, x0
    cef4:	f9002293 	str	x19, [x20, #64]
    cef8:	17ffffa2 	b	cd80 <fwp_main_thread+0x180>
    cefc:	f9402280 	ldr	x0, [x20, #64]
    cf00:	17ffff9a 	b	cd68 <fwp_main_thread+0x168>
    cf04:	aa0203f3 	mov	x19, x2
    cf08:	17ffff8e 	b	cd40 <fwp_main_thread+0x140>
    cf0c:	a911fe77 	stp	x23, xzr, [x19, #280]
    cf10:	f9009660 	str	x0, [x19, #296]
    cf14:	b4000040 	cbz	x0, cf1c <fwp_main_thread+0x31c>
    cf18:	f9009013 	str	x19, [x0, #288]
    cf1c:	f9002293 	str	x19, [x20, #64]
    cf20:	17ffff9f 	b	cd9c <fwp_main_thread+0x19c>
    cf24:	f9000040 	str	x0, [x2]
    cf28:	17ffffa5 	b	cdbc <fwp_main_thread+0x1bc>
    cf2c:	f9009740 	str	x0, [x26, #296]
    cf30:	17ffffae 	b	cde8 <fwp_main_thread+0x1e8>
    cf34:	f9006693 	str	x19, [x20, #200]
    cf38:	17ffffd4 	b	ce88 <fwp_main_thread+0x288>
    cf3c:	f941d740 	ldr	x0, [x26, #936]
    cf40:	b4000ec0 	cbz	x0, d118 <fwp_main_thread+0x518>
    cf44:	f941f340 	ldr	x0, [x26, #992]
    cf48:	b903db5f 	str	wzr, [x26, #984]
    cf4c:	b5001040 	cbnz	x0, d154 <fwp_main_thread+0x554>
    cf50:	910182b4 	add	x20, x21, #0x60
    cf54:	97ffe60b 	bl	6780 <fwp_free_zombie>
    cf58:	f9406680 	ldr	x0, [x20, #200]
    cf5c:	b5000fc0 	cbnz	x0, d154 <fwp_main_thread+0x554>
    cf60:	f9409680 	ldr	x0, [x20, #296]
    cf64:	b5000f80 	cbnz	x0, d154 <fwp_main_thread+0x554>
    cf68:	b9417293 	ldr	w19, [x20, #368]
    cf6c:	340001d3 	cbz	w19, cfa4 <fwp_main_thread+0x3a4>
    cf70:	93407e77 	sxtw	x23, w19
    cf74:	51000673 	sub	w19, w19, #0x1
    cf78:	d1000af7 	sub	x23, x23, #0x2
    cf7c:	91060298 	add	x24, x20, #0x180
    cf80:	cb3342f7 	sub	x23, x23, w19, uxtw
    cf84:	93407e73 	sxtw	x19, w19
    cf88:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    cf8c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cf90:	b9017293 	str	w19, [x20, #368]
    cf94:	d1000673 	sub	x19, x19, #0x1
    cf98:	97ffd666 	bl	2930 <munmap@plt>
    cf9c:	eb1302ff 	cmp	x23, x19
    cfa0:	54ffff41 	b.ne	cf88 <fwp_main_thread+0x388>  // b.any
    cfa4:	900000b3 	adrp	x19, 20000 <__data_start>
    cfa8:	91004260 	add	x0, x19, #0x10
    cfac:	b9403000 	ldr	w0, [x0, #48]
    cfb0:	37f80040 	tbnz	w0, #31, cfb8 <fwp_main_thread+0x3b8>
    cfb4:	97ffd61b 	bl	2820 <close@plt>
    cfb8:	910182a0 	add	x0, x21, #0x60
    cfbc:	91004261 	add	x1, x19, #0x10
    cfc0:	12800002 	mov	w2, #0xffffffff            	// #-1
    cfc4:	d2800013 	mov	x19, #0x0                   	// #0
    cfc8:	f941f417 	ldr	x23, [x0, #1000]
    cfcc:	b9003022 	str	w2, [x1, #48]
    cfd0:	f941f814 	ldr	x20, [x0, #1008]
    cfd4:	b4000177 	cbz	x23, d000 <fwp_main_thread+0x400>
    cfd8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cfdc:	b40000c0 	cbz	x0, cff4 <fwp_main_thread+0x3f4>
    cfe0:	f9400001 	ldr	x1, [x0]
    cfe4:	b5000b81 	cbnz	x1, d154 <fwp_main_thread+0x554>
    cfe8:	f9400401 	ldr	x1, [x0, #8]
    cfec:	b5000b41 	cbnz	x1, d154 <fwp_main_thread+0x554>
    cff0:	97ffdf08 	bl	4c10 <fwp_mem_free>
    cff4:	91000673 	add	x19, x19, #0x1
    cff8:	eb1302ff 	cmp	x23, x19
    cffc:	54fffee1 	b.ne	cfd8 <fwp_main_thread+0x3d8>  // b.any
    d000:	aa1403e0 	mov	x0, x20
    d004:	97ffdf03 	bl	4c10 <fwp_mem_free>
    d008:	910182a0 	add	x0, x21, #0x60
    d00c:	f941f013 	ldr	x19, [x0, #992]
    d010:	f901f41f 	str	xzr, [x0, #1000]
    d014:	f901f81f 	str	xzr, [x0, #1008]
    d018:	b40001f3 	cbz	x19, d054 <fwp_main_thread+0x454>
    d01c:	f9401661 	ldr	x1, [x19, #40]
    d020:	b50009a1 	cbnz	x1, d154 <fwp_main_thread+0x554>
    d024:	f9405661 	ldr	x1, [x19, #168]
    d028:	b5000961 	cbnz	x1, d154 <fwp_main_thread+0x554>
    d02c:	f941d401 	ldr	x1, [x0, #936]
    d030:	b5000921 	cbnz	x1, d154 <fwp_main_thread+0x554>
    d034:	f941dc00 	ldr	x0, [x0, #952]
    d038:	b50008e0 	cbnz	x0, d154 <fwp_main_thread+0x554>
    d03c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d040:	f0000340 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    d044:	91118000 	add	x0, x0, #0x460
    d048:	97ffd5e6 	bl	27e0 <memset@plt>
    d04c:	aa1303e0 	mov	x0, x19
    d050:	97ffdef0 	bl	4c10 <fwp_mem_free>
    d054:	910182a6 	add	x6, x21, #0x60
    d058:	911902d6 	add	x22, x22, #0x640
    d05c:	3dc01aa1 	ldr	q1, [x21, #96]
    d060:	52800041 	mov	w1, #0x2                   	// #2
    d064:	3dc004c2 	ldr	q2, [x6, #16]
    d068:	b0000002 	adrp	x2, e000 <_IO_stdin_used+0x720>
    d06c:	fd4a12c0 	ldr	d0, [x22, #5152]
    d070:	91046042 	add	x2, x2, #0x118
    d074:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    d078:	fd40a4c1 	ldr	d1, [x6, #328]
    d07c:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d080:	f947e800 	ldr	x0, [x0, #4048]
    d084:	7e61d800 	ucvtf	d0, d0
    d088:	a95390c3 	ldp	x3, x4, [x6, #312]
    d08c:	f9004cdf 	str	xzr, [x6, #152]
    d090:	f9400000 	ldr	x0, [x0]
    d094:	1e613801 	fsub	d1, d0, d1
    d098:	f940acc5 	ldr	x5, [x6, #344]
    d09c:	b90130df 	str	wzr, [x6, #304]
    d0a0:	5ef1b842 	addp	d2, v2.2d
    d0a4:	fd40a8c0 	ldr	d0, [x6, #336]
    d0a8:	f901f0df 	str	xzr, [x6, #992]
    d0ac:	fd0058c2 	str	d2, [x6, #176]
    d0b0:	97ffd5f4 	bl	2880 <__fprintf_chk@plt>
    d0b4:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d0b8:	f947ec00 	ldr	x0, [x0, #4056]
    d0bc:	f9400000 	ldr	x0, [x0]
    d0c0:	97ffd620 	bl	2940 <fflush@plt>
    d0c4:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d0c8:	f947f400 	ldr	x0, [x0, #4072]
    d0cc:	f9405fe2 	ldr	x2, [sp, #184]
    d0d0:	f9400001 	ldr	x1, [x0]
    d0d4:	eb010042 	subs	x2, x2, x1
    d0d8:	d2800001 	mov	x1, #0x0                   	// #0
    d0dc:	540006a1 	b.ne	d1b0 <fwp_main_thread+0x5b0>  // b.any
    d0e0:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d0e4:	d2800000 	mov	x0, #0x0                   	// #0
    d0e8:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d0ec:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d0f0:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d0f4:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d0f8:	910443ff 	add	sp, sp, #0x110
    d0fc:	d65f03c0 	ret
    d100:	39414280 	ldrb	w0, [x20, #80]
    d104:	3707ed80 	tbnz	w0, #0, ceb4 <fwp_main_thread+0x2b4>
    d108:	aa1403e0 	mov	x0, x20
    d10c:	97ffd959 	bl	3670 <fwp_cancel_tree.part.0>
    d110:	39414680 	ldrb	w0, [x20, #81]
    d114:	17ffff69 	b	ceb8 <fwp_main_thread+0x2b8>
    d118:	d2800013 	mov	x19, #0x0                   	// #0
    d11c:	910182b4 	add	x20, x21, #0x60
    d120:	f941de80 	ldr	x0, [x20, #952]
    d124:	b5ffe7a0 	cbnz	x0, ce18 <fwp_main_thread+0x218>
    d128:	f941d280 	ldr	x0, [x20, #928]
    d12c:	97ffdeb9 	bl	4c10 <fwp_mem_free>
    d130:	f901d29f 	str	xzr, [x20, #928]
    d134:	f901da9f 	str	xzr, [x20, #944]
    d138:	f941f280 	ldr	x0, [x20, #992]
    d13c:	b4000293 	cbz	x19, d18c <fwp_main_thread+0x58c>
    d140:	f900567f 	str	xzr, [x19, #168]
    d144:	f9005e7f 	str	xzr, [x19, #184]
    d148:	b903da9f 	str	wzr, [x20, #984]
    d14c:	eb13001f 	cmp	x0, x19
    d150:	54ffe700 	b.eq	ce30 <fwp_main_thread+0x230>  // b.none
    d154:	97ffd5c3 	bl	2860 <abort@plt>
    d158:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d15c:	913c8000 	add	x0, x0, #0xf20
    d160:	940001d4 	bl	d8b0 <atexit>
    d164:	17fffeba 	b	cc4c <fwp_main_thread+0x4c>
    d168:	97ffdbc7 	bl	4084 <fwp_heap_init>
    d16c:	17fffeb5 	b	cc40 <fwp_main_thread+0x40>
    d170:	97fff509 	bl	a594 <f0>
    d174:	b903ca74 	str	w20, [x19, #968]
    d178:	f901ea60 	str	x0, [x19, #976]
    d17c:	17fffee9 	b	cd20 <fwp_main_thread+0x120>
    d180:	aa0003e1 	mov	x1, x0
    d184:	f9002293 	str	x19, [x20, #64]
    d188:	17fffefe 	b	cd80 <fwp_main_thread+0x180>
    d18c:	b903da9f 	str	wzr, [x20, #984]
    d190:	b4ffee00 	cbz	x0, cf50 <fwp_main_thread+0x350>
    d194:	97ffd5b3 	bl	2860 <abort@plt>
    d198:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x720>
    d19c:	91034000 	add	x0, x0, #0xd0
    d1a0:	97ffd978 	bl	3780 <fwp_trap>
    d1a4:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x720>
    d1a8:	9103e000 	add	x0, x0, #0xf8
    d1ac:	97ffd855 	bl	3300 <ad_raw_fail>
    d1b0:	97ffd598 	bl	2810 <__stack_chk_fail@plt>
    d1b4:	d503201f 	nop
    d1b8:	d503201f 	nop
    d1bc:	d503201f 	nop

000000000000d1c0 <__divti3>:
    d1c0:	d503245f 	bti	c
    d1c4:	d2800004 	mov	x4, #0x0                   	// #0
    d1c8:	b7f80721 	tbnz	x1, #63, d2ac <__divti3+0xec>
    d1cc:	b6f80083 	tbz	x3, #63, d1dc <__divti3+0x1c>
    d1d0:	eb0203e2 	negs	x2, x2
    d1d4:	aa2403e4 	mvn	x4, x4
    d1d8:	da0303e3 	ngc	x3, x3
    d1dc:	aa0203e6 	mov	x6, x2
    d1e0:	aa0003e7 	mov	x7, x0
    d1e4:	aa0103e5 	mov	x5, x1
    d1e8:	b5000583 	cbnz	x3, d298 <__divti3+0xd8>
    d1ec:	eb01005f 	cmp	x2, x1
    d1f0:	54000e69 	b.ls	d3bc <__divti3+0x1fc>  // b.plast
    d1f4:	dac01040 	clz	x0, x2
    d1f8:	b40000e0 	cbz	x0, d214 <__divti3+0x54>
    d1fc:	4b0003e1 	neg	w1, w0
    d200:	9ac020a5 	lsl	x5, x5, x0
    d204:	9ac02046 	lsl	x6, x2, x0
    d208:	9ac124e1 	lsr	x1, x7, x1
    d20c:	aa050025 	orr	x5, x1, x5
    d210:	9ac020e7 	lsl	x7, x7, x0
    d214:	d360fcc8 	lsr	x8, x6, #32
    d218:	92407cc2 	and	x2, x6, #0xffffffff
    d21c:	9ac808a3 	udiv	x3, x5, x8
    d220:	9b089465 	msub	x5, x3, x8, x5
    d224:	aa0303e0 	mov	x0, x3
    d228:	9b037c41 	mul	x1, x2, x3
    d22c:	93c780a5 	extr	x5, x5, x7, #32
    d230:	eb05003f 	cmp	x1, x5
    d234:	540000a9 	b.ls	d248 <__divti3+0x88>  // b.plast
    d238:	ab0500c5 	adds	x5, x6, x5
    d23c:	d1000460 	sub	x0, x3, #0x1
    d240:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d244:	540015a8 	b.hi	d4f8 <__divti3+0x338>  // b.pmore
    d248:	cb0100a5 	sub	x5, x5, x1
    d24c:	9ac808a3 	udiv	x3, x5, x8
    d250:	9b089465 	msub	x5, x3, x8, x5
    d254:	aa0303e1 	mov	x1, x3
    d258:	9b037c42 	mul	x2, x2, x3
    d25c:	aa0703e3 	mov	x3, x7
    d260:	b3607ca3 	bfi	x3, x5, #32, #32
    d264:	eb03005f 	cmp	x2, x3
    d268:	540000c9 	b.ls	d280 <__divti3+0xc0>  // b.plast
    d26c:	ab0300c3 	adds	x3, x6, x3
    d270:	d1000425 	sub	x5, x1, #0x1
    d274:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d278:	d1000821 	sub	x1, x1, #0x2
    d27c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d280:	aa008020 	orr	x0, x1, x0, lsl #32
    d284:	d2800001 	mov	x1, #0x0                   	// #0
    d288:	b4000064 	cbz	x4, d294 <__divti3+0xd4>
    d28c:	eb0003e0 	negs	x0, x0
    d290:	da0103e1 	ngc	x1, x1
    d294:	d65f03c0 	ret
    d298:	eb01007f 	cmp	x3, x1
    d29c:	54000109 	b.ls	d2bc <__divti3+0xfc>  // b.plast
    d2a0:	d2800001 	mov	x1, #0x0                   	// #0
    d2a4:	d2800000 	mov	x0, #0x0                   	// #0
    d2a8:	17fffff8 	b	d288 <__divti3+0xc8>
    d2ac:	eb0003e0 	negs	x0, x0
    d2b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d2b4:	da0103e1 	ngc	x1, x1
    d2b8:	17ffffc5 	b	d1cc <__divti3+0xc>
    d2bc:	dac01067 	clz	x7, x3
    d2c0:	b40010e7 	cbz	x7, d4dc <__divti3+0x31c>
    d2c4:	d2800805 	mov	x5, #0x40                  	// #64
    d2c8:	cb0700a5 	sub	x5, x5, x7
    d2cc:	9ac72063 	lsl	x3, x3, x7
    d2d0:	9ac52448 	lsr	x8, x2, x5
    d2d4:	aa030108 	orr	x8, x8, x3
    d2d8:	9ac52426 	lsr	x6, x1, x5
    d2dc:	92407d0a 	and	x10, x8, #0xffffffff
    d2e0:	d360fd09 	lsr	x9, x8, #32
    d2e4:	9ac52403 	lsr	x3, x0, x5
    d2e8:	9ac72021 	lsl	x1, x1, x7
    d2ec:	aa010063 	orr	x3, x3, x1
    d2f0:	9ac72042 	lsl	x2, x2, x7
    d2f4:	9ac908cb 	udiv	x11, x6, x9
    d2f8:	9b099965 	msub	x5, x11, x9, x6
    d2fc:	aa0b03e1 	mov	x1, x11
    d300:	9b0b7d46 	mul	x6, x10, x11
    d304:	93c380a5 	extr	x5, x5, x3, #32
    d308:	eb0500df 	cmp	x6, x5
    d30c:	540000a9 	b.ls	d320 <__divti3+0x160>  // b.plast
    d310:	ab050105 	adds	x5, x8, x5
    d314:	d1000561 	sub	x1, x11, #0x1
    d318:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d31c:	54000f48 	b.hi	d504 <__divti3+0x344>  // b.pmore
    d320:	cb0600a6 	sub	x6, x5, x6
    d324:	9ac908cb 	udiv	x11, x6, x9
    d328:	9b099969 	msub	x9, x11, x9, x6
    d32c:	aa0b03e5 	mov	x5, x11
    d330:	9b0b7d4a 	mul	x10, x10, x11
    d334:	b3607d23 	bfi	x3, x9, #32, #32
    d338:	eb03015f 	cmp	x10, x3
    d33c:	540000a9 	b.ls	d350 <__divti3+0x190>  // b.plast
    d340:	ab030103 	adds	x3, x8, x3
    d344:	d1000565 	sub	x5, x11, #0x1
    d348:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d34c:	54000e28 	b.hi	d510 <__divti3+0x350>  // b.pmore
    d350:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d354:	92407c48 	and	x8, x2, #0xffffffff
    d358:	2a0503e5 	mov	w5, w5
    d35c:	d360fc42 	lsr	x2, x2, #32
    d360:	d360fc26 	lsr	x6, x1, #32
    d364:	cb0a0063 	sub	x3, x3, x10
    d368:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d36c:	9b087caa 	mul	x10, x5, x8
    d370:	9b087cc8 	mul	x8, x6, x8
    d374:	9b0220a5 	madd	x5, x5, x2, x8
    d378:	9b027cc6 	mul	x6, x6, x2
    d37c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d380:	8b0900c5 	add	x5, x6, x9
    d384:	eb02011f 	cmp	x8, x2
    d388:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d38c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d390:	eb06007f 	cmp	x3, x6
    d394:	540000e3 	b.cc	d3b0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d398:	92407d4a 	and	x10, x10, #0xffffffff
    d39c:	9ac72000 	lsl	x0, x0, x7
    d3a0:	8b028142 	add	x2, x10, x2, lsl #32
    d3a4:	eb02001f 	cmp	x0, x2
    d3a8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d3ac:	54000a01 	b.ne	d4ec <__divti3+0x32c>  // b.any
    d3b0:	d1000420 	sub	x0, x1, #0x1
    d3b4:	d2800001 	mov	x1, #0x0                   	// #0
    d3b8:	17ffffb4 	b	d288 <__divti3+0xc8>
    d3bc:	b5000062 	cbnz	x2, d3c8 <__divti3+0x208>
    d3c0:	d2800022 	mov	x2, #0x1                   	// #1
    d3c4:	9ac30846 	udiv	x6, x2, x3
    d3c8:	dac010c8 	clz	x8, x6
    d3cc:	b5000408 	cbnz	x8, d44c <__divti3+0x28c>
    d3d0:	d360fcc9 	lsr	x9, x6, #32
    d3d4:	92407cc5 	and	x5, x6, #0xffffffff
    d3d8:	cb060023 	sub	x3, x1, x6
    d3dc:	d2800021 	mov	x1, #0x1                   	// #1
    d3e0:	9ac90868 	udiv	x8, x3, x9
    d3e4:	9b098d03 	msub	x3, x8, x9, x3
    d3e8:	aa0803e0 	mov	x0, x8
    d3ec:	9b057d02 	mul	x2, x8, x5
    d3f0:	93c78063 	extr	x3, x3, x7, #32
    d3f4:	eb03005f 	cmp	x2, x3
    d3f8:	540000a9 	b.ls	d40c <__divti3+0x24c>  // b.plast
    d3fc:	ab0300c3 	adds	x3, x6, x3
    d400:	d1000500 	sub	x0, x8, #0x1
    d404:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d408:	54000968 	b.hi	d534 <__divti3+0x374>  // b.pmore
    d40c:	cb020063 	sub	x3, x3, x2
    d410:	9ac90862 	udiv	x2, x3, x9
    d414:	aa0203e8 	mov	x8, x2
    d418:	9b098c42 	msub	x2, x2, x9, x3
    d41c:	aa0703e3 	mov	x3, x7
    d420:	9b057d05 	mul	x5, x8, x5
    d424:	b3607c43 	bfi	x3, x2, #32, #32
    d428:	eb0300bf 	cmp	x5, x3
    d42c:	540000c9 	b.ls	d444 <__divti3+0x284>  // b.plast
    d430:	ab0300c2 	adds	x2, x6, x3
    d434:	d1000503 	sub	x3, x8, #0x1
    d438:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d43c:	d1000908 	sub	x8, x8, #0x2
    d440:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d444:	aa008100 	orr	x0, x8, x0, lsl #32
    d448:	17ffff90 	b	d288 <__divti3+0xc8>
    d44c:	9ac820c6 	lsl	x6, x6, x8
    d450:	d2800803 	mov	x3, #0x40                  	// #64
    d454:	cb080063 	sub	x3, x3, x8
    d458:	d360fcc9 	lsr	x9, x6, #32
    d45c:	9ac82027 	lsl	x7, x1, x8
    d460:	92407cc5 	and	x5, x6, #0xffffffff
    d464:	9ac32422 	lsr	x2, x1, x3
    d468:	9ac32403 	lsr	x3, x0, x3
    d46c:	aa070063 	orr	x3, x3, x7
    d470:	9ac9084a 	udiv	x10, x2, x9
    d474:	9ac82007 	lsl	x7, x0, x8
    d478:	9b098940 	msub	x0, x10, x9, x2
    d47c:	aa0a03e1 	mov	x1, x10
    d480:	9b0a7ca2 	mul	x2, x5, x10
    d484:	93c38000 	extr	x0, x0, x3, #32
    d488:	eb00005f 	cmp	x2, x0
    d48c:	540000a9 	b.ls	d4a0 <__divti3+0x2e0>  // b.plast
    d490:	ab0000c0 	adds	x0, x6, x0
    d494:	d1000541 	sub	x1, x10, #0x1
    d498:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d49c:	54000468 	b.hi	d528 <__divti3+0x368>  // b.pmore
    d4a0:	cb020000 	sub	x0, x0, x2
    d4a4:	9ac9080a 	udiv	x10, x0, x9
    d4a8:	9b098140 	msub	x0, x10, x9, x0
    d4ac:	aa0a03e2 	mov	x2, x10
    d4b0:	9b0a7ca8 	mul	x8, x5, x10
    d4b4:	b3607c03 	bfi	x3, x0, #32, #32
    d4b8:	eb03011f 	cmp	x8, x3
    d4bc:	540000a9 	b.ls	d4d0 <__divti3+0x310>  // b.plast
    d4c0:	ab0300c3 	adds	x3, x6, x3
    d4c4:	d1000542 	sub	x2, x10, #0x1
    d4c8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d4cc:	54000288 	b.hi	d51c <__divti3+0x35c>  // b.pmore
    d4d0:	cb080063 	sub	x3, x3, x8
    d4d4:	aa018041 	orr	x1, x2, x1, lsl #32
    d4d8:	17ffffc2 	b	d3e0 <__divti3+0x220>
    d4dc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d4e0:	d2800001 	mov	x1, #0x0                   	// #0
    d4e4:	9a9f87e0 	cset	x0, ls	// ls = plast
    d4e8:	17ffff68 	b	d288 <__divti3+0xc8>
    d4ec:	aa0103e0 	mov	x0, x1
    d4f0:	d2800001 	mov	x1, #0x0                   	// #0
    d4f4:	17ffff65 	b	d288 <__divti3+0xc8>
    d4f8:	d1000860 	sub	x0, x3, #0x2
    d4fc:	8b0600a5 	add	x5, x5, x6
    d500:	17ffff52 	b	d248 <__divti3+0x88>
    d504:	d1000961 	sub	x1, x11, #0x2
    d508:	8b0800a5 	add	x5, x5, x8
    d50c:	17ffff85 	b	d320 <__divti3+0x160>
    d510:	d1000965 	sub	x5, x11, #0x2
    d514:	8b080063 	add	x3, x3, x8
    d518:	17ffff8e 	b	d350 <__divti3+0x190>
    d51c:	d1000942 	sub	x2, x10, #0x2
    d520:	8b060063 	add	x3, x3, x6
    d524:	17ffffeb 	b	d4d0 <__divti3+0x310>
    d528:	d1000941 	sub	x1, x10, #0x2
    d52c:	8b060000 	add	x0, x0, x6
    d530:	17ffffdc 	b	d4a0 <__divti3+0x2e0>
    d534:	d1000900 	sub	x0, x8, #0x2
    d538:	8b060063 	add	x3, x3, x6
    d53c:	17ffffb4 	b	d40c <__divti3+0x24c>

000000000000d540 <__modti3>:
    d540:	d503245f 	bti	c
    d544:	d2800004 	mov	x4, #0x0                   	// #0
    d548:	b6f80081 	tbz	x1, #63, d558 <__modti3+0x18>
    d54c:	eb0003e0 	negs	x0, x0
    d550:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d554:	da0103e1 	ngc	x1, x1
    d558:	f100007f 	cmp	x3, #0x0
    d55c:	5400128b 	b.lt	d7ac <__modti3+0x26c>  // b.tstop
    d560:	aa0003e7 	mov	x7, x0
    d564:	aa0103e6 	mov	x6, x1
    d568:	540004e1 	b.ne	d604 <__modti3+0xc4>  // b.any
    d56c:	eb02003f 	cmp	x1, x2
    d570:	54000dc2 	b.cs	d728 <__modti3+0x1e8>  // b.hs, b.nlast
    d574:	dac01043 	clz	x3, x2
    d578:	aa0303e5 	mov	x5, x3
    d57c:	b40000e3 	cbz	x3, d598 <__modti3+0x58>
    d580:	4b0303e6 	neg	w6, w3
    d584:	9ac32021 	lsl	x1, x1, x3
    d588:	9ac32042 	lsl	x2, x2, x3
    d58c:	9ac62406 	lsr	x6, x0, x6
    d590:	aa0100c6 	orr	x6, x6, x1
    d594:	9ac32007 	lsl	x7, x0, x3
    d598:	d360fc40 	lsr	x0, x2, #32
    d59c:	92407c43 	and	x3, x2, #0xffffffff
    d5a0:	9ac008c1 	udiv	x1, x6, x0
    d5a4:	9b009826 	msub	x6, x1, x0, x6
    d5a8:	9b017c61 	mul	x1, x3, x1
    d5ac:	93c780c6 	extr	x6, x6, x7, #32
    d5b0:	eb06003f 	cmp	x1, x6
    d5b4:	540000a9 	b.ls	d5c8 <__modti3+0x88>  // b.plast
    d5b8:	ab060046 	adds	x6, x2, x6
    d5bc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d5c0:	8b0200c8 	add	x8, x6, x2
    d5c4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d5c8:	cb0100c6 	sub	x6, x6, x1
    d5cc:	9ac008c8 	udiv	x8, x6, x0
    d5d0:	9b009901 	msub	x1, x8, x0, x6
    d5d4:	aa0703e0 	mov	x0, x7
    d5d8:	9b087c63 	mul	x3, x3, x8
    d5dc:	b3607c20 	bfi	x0, x1, #32, #32
    d5e0:	eb00007f 	cmp	x3, x0
    d5e4:	54001088 	b.hi	d7f4 <__modti3+0x2b4>  // b.pmore
    d5e8:	cb030000 	sub	x0, x0, x3
    d5ec:	9ac52400 	lsr	x0, x0, x5
    d5f0:	d2800001 	mov	x1, #0x0                   	// #0
    d5f4:	b4000064 	cbz	x4, d600 <__modti3+0xc0>
    d5f8:	eb0003e0 	negs	x0, x0
    d5fc:	da0103e1 	ngc	x1, x1
    d600:	d65f03c0 	ret
    d604:	dac01066 	clz	x6, x3
    d608:	eb03003f 	cmp	x1, x3
    d60c:	54ffff43 	b.cc	d5f4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d610:	93407cc5 	sxtw	x5, w6
    d614:	d2800808 	mov	x8, #0x40                  	// #64
    d618:	cb050108 	sub	x8, x8, x5
    d61c:	9ac62063 	lsl	x3, x3, x6
    d620:	9ac62025 	lsl	x5, x1, x6
    d624:	9ac82447 	lsr	x7, x2, x8
    d628:	aa0300e7 	orr	x7, x7, x3
    d62c:	9ac82423 	lsr	x3, x1, x8
    d630:	92407cec 	and	x12, x7, #0xffffffff
    d634:	d360fcea 	lsr	x10, x7, #32
    d638:	9ac82401 	lsr	x1, x0, x8
    d63c:	aa050021 	orr	x1, x1, x5
    d640:	9ac62042 	lsl	x2, x2, x6
    d644:	9ac62000 	lsl	x0, x0, x6
    d648:	9aca086b 	udiv	x11, x3, x10
    d64c:	9b0a8d63 	msub	x3, x11, x10, x3
    d650:	aa0b03e5 	mov	x5, x11
    d654:	9b0b7d89 	mul	x9, x12, x11
    d658:	93c18063 	extr	x3, x3, x1, #32
    d65c:	eb03013f 	cmp	x9, x3
    d660:	540000a9 	b.ls	d674 <__modti3+0x134>  // b.plast
    d664:	ab0300e3 	adds	x3, x7, x3
    d668:	d1000565 	sub	x5, x11, #0x1
    d66c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d670:	54001168 	b.hi	d89c <__modti3+0x35c>  // b.pmore
    d674:	cb090063 	sub	x3, x3, x9
    d678:	9aca086b 	udiv	x11, x3, x10
    d67c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d680:	aa0b03e9 	mov	x9, x11
    d684:	9b0b7d8c 	mul	x12, x12, x11
    d688:	b3607d41 	bfi	x1, x10, #32, #32
    d68c:	eb01019f 	cmp	x12, x1
    d690:	540000a9 	b.ls	d6a4 <__modti3+0x164>  // b.plast
    d694:	ab0100e1 	adds	x1, x7, x1
    d698:	d1000569 	sub	x9, x11, #0x1
    d69c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d6a0:	54000f88 	b.hi	d890 <__modti3+0x350>  // b.pmore
    d6a4:	aa058123 	orr	x3, x9, x5, lsl #32
    d6a8:	92407c4b 	and	x11, x2, #0xffffffff
    d6ac:	2a0903e9 	mov	w9, w9
    d6b0:	d360fc4a 	lsr	x10, x2, #32
    d6b4:	d360fc63 	lsr	x3, x3, #32
    d6b8:	cb0c0021 	sub	x1, x1, x12
    d6bc:	aa0a03ec 	mov	x12, x10
    d6c0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d6c4:	9b0b7d25 	mul	x5, x9, x11
    d6c8:	9b0b7c6b 	mul	x11, x3, x11
    d6cc:	9b0a2d29 	madd	x9, x9, x10, x11
    d6d0:	92407caa 	and	x10, x5, #0xffffffff
    d6d4:	9b0c7c63 	mul	x3, x3, x12
    d6d8:	8b458125 	add	x5, x9, x5, lsr #32
    d6dc:	8b0d0069 	add	x9, x3, x13
    d6e0:	eb05017f 	cmp	x11, x5
    d6e4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d6e8:	8b058149 	add	x9, x10, x5, lsl #32
    d6ec:	8b458063 	add	x3, x3, x5, lsr #32
    d6f0:	eb03003f 	cmp	x1, x3
    d6f4:	54000063 	b.cc	d700 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d6f8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d6fc:	54000082 	b.cs	d70c <__modti3+0x1cc>  // b.hs, b.nlast
    d700:	eb020129 	subs	x9, x9, x2
    d704:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d708:	cb070063 	sub	x3, x3, x7
    d70c:	eb090000 	subs	x0, x0, x9
    d710:	da030021 	sbc	x1, x1, x3
    d714:	9ac62400 	lsr	x0, x0, x6
    d718:	9ac82028 	lsl	x8, x1, x8
    d71c:	aa000100 	orr	x0, x8, x0
    d720:	9ac62421 	lsr	x1, x1, x6
    d724:	17ffffb4 	b	d5f4 <__modti3+0xb4>
    d728:	b5000062 	cbnz	x2, d734 <__modti3+0x1f4>
    d72c:	d2800023 	mov	x3, #0x1                   	// #1
    d730:	9ac20862 	udiv	x2, x3, x2
    d734:	dac01048 	clz	x8, x2
    d738:	aa0803e5 	mov	x5, x8
    d73c:	b5000668 	cbnz	x8, d808 <__modti3+0x2c8>
    d740:	cb020020 	sub	x0, x1, x2
    d744:	d360fc49 	lsr	x9, x2, #32
    d748:	92407c4a 	and	x10, x2, #0xffffffff
    d74c:	9ac90801 	udiv	x1, x0, x9
    d750:	9b098020 	msub	x0, x1, x9, x0
    d754:	9b0a7c21 	mul	x1, x1, x10
    d758:	93c78000 	extr	x0, x0, x7, #32
    d75c:	eb00003f 	cmp	x1, x0
    d760:	540000a9 	b.ls	d774 <__modti3+0x234>  // b.plast
    d764:	ab000040 	adds	x0, x2, x0
    d768:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d76c:	8b020003 	add	x3, x0, x2
    d770:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d774:	cb010001 	sub	x1, x0, x1
    d778:	9ac90820 	udiv	x0, x1, x9
    d77c:	9b098403 	msub	x3, x0, x9, x1
    d780:	aa0703e1 	mov	x1, x7
    d784:	9b0a7c00 	mul	x0, x0, x10
    d788:	b3607c61 	bfi	x1, x3, #32, #32
    d78c:	eb01001f 	cmp	x0, x1
    d790:	540000a9 	b.ls	d7a4 <__modti3+0x264>  // b.plast
    d794:	ab010041 	adds	x1, x2, x1
    d798:	8b020022 	add	x2, x1, x2
    d79c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d7a0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d7a4:	cb000020 	sub	x0, x1, x0
    d7a8:	17ffff91 	b	d5ec <__modti3+0xac>
    d7ac:	eb0203e5 	negs	x5, x2
    d7b0:	aa0003e7 	mov	x7, x0
    d7b4:	da0303e8 	ngc	x8, x3
    d7b8:	aa0503e2 	mov	x2, x5
    d7bc:	aa0803e3 	mov	x3, x8
    d7c0:	aa0103e6 	mov	x6, x1
    d7c4:	b4ffed48 	cbz	x8, d56c <__modti3+0x2c>
    d7c8:	eb01011f 	cmp	x8, x1
    d7cc:	54fff148 	b.hi	d5f4 <__modti3+0xb4>  // b.pmore
    d7d0:	dac01109 	clz	x9, x8
    d7d4:	2a0903e6 	mov	w6, w9
    d7d8:	b5fff1c9 	cbnz	x9, d610 <__modti3+0xd0>
    d7dc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d7e0:	54000068 	b.hi	d7ec <__modti3+0x2ac>  // b.pmore
    d7e4:	eb050007 	subs	x7, x0, x5
    d7e8:	da080021 	sbc	x1, x1, x8
    d7ec:	aa0703e0 	mov	x0, x7
    d7f0:	17ffff81 	b	d5f4 <__modti3+0xb4>
    d7f4:	ab000040 	adds	x0, x2, x0
    d7f8:	8b020002 	add	x2, x0, x2
    d7fc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d800:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d804:	17ffff79 	b	d5e8 <__modti3+0xa8>
    d808:	9ac82042 	lsl	x2, x2, x8
    d80c:	d2800803 	mov	x3, #0x40                  	// #64
    d810:	cb080063 	sub	x3, x3, x8
    d814:	d360fc49 	lsr	x9, x2, #32
    d818:	9ac82027 	lsl	x7, x1, x8
    d81c:	92407c4a 	and	x10, x2, #0xffffffff
    d820:	9ac32426 	lsr	x6, x1, x3
    d824:	9ac32403 	lsr	x3, x0, x3
    d828:	aa070063 	orr	x3, x3, x7
    d82c:	9ac908c1 	udiv	x1, x6, x9
    d830:	9ac82007 	lsl	x7, x0, x8
    d834:	9b099820 	msub	x0, x1, x9, x6
    d838:	9b017d41 	mul	x1, x10, x1
    d83c:	93c38000 	extr	x0, x0, x3, #32
    d840:	eb00003f 	cmp	x1, x0
    d844:	540000a9 	b.ls	d858 <__modti3+0x318>  // b.plast
    d848:	ab000040 	adds	x0, x2, x0
    d84c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d850:	8b020006 	add	x6, x0, x2
    d854:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d858:	cb010000 	sub	x0, x0, x1
    d85c:	9ac90801 	udiv	x1, x0, x9
    d860:	9b098026 	msub	x6, x1, x9, x0
    d864:	aa0303e0 	mov	x0, x3
    d868:	9b017d41 	mul	x1, x10, x1
    d86c:	b3607cc0 	bfi	x0, x6, #32, #32
    d870:	eb00003f 	cmp	x1, x0
    d874:	540000a9 	b.ls	d888 <__modti3+0x348>  // b.plast
    d878:	ab000040 	adds	x0, x2, x0
    d87c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d880:	8b020003 	add	x3, x0, x2
    d884:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d888:	cb010000 	sub	x0, x0, x1
    d88c:	17ffffb0 	b	d74c <__modti3+0x20c>
    d890:	d1000969 	sub	x9, x11, #0x2
    d894:	8b070021 	add	x1, x1, x7
    d898:	17ffff83 	b	d6a4 <__modti3+0x164>
    d89c:	d1000965 	sub	x5, x11, #0x2
    d8a0:	8b070063 	add	x3, x3, x7
    d8a4:	17ffff74 	b	d674 <__modti3+0x134>
    d8a8:	d503201f 	nop
    d8ac:	d503201f 	nop

000000000000d8b0 <atexit>:
    d8b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d8b4:	f0000082 	adrp	x2, 20000 <__data_start>
    d8b8:	d2800001 	mov	x1, #0x0                   	// #0
    d8bc:	910003fd 	mov	x29, sp
    d8c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d8c4:	f9400442 	ldr	x2, [x2, #8]
    d8c8:	17ffd392 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d8cc <_fini>:
    d8cc:	d503201f 	nop
    d8d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d8d4:	910003fd 	mov	x29, sp
    d8d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d8dc:	d65f03c0 	ret
