
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__divti3+0x1b0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9120a0a5 	add	x5, x5, #0x828
    2aa0:	f0000044 	adrp	x4, d000 <__divti3+0x1b0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9120c084 	add	x4, x4, #0x830
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe788>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__divti3+0x1b0>
    2b34:	91302000 	add	x0, x0, #0xc08
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1da0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91234042 	add	x2, x2, #0x8d0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435a60 	ldr	w0, [x19, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__divti3+0x1b0>
    2c7c:	91306000 	add	x0, x0, #0xc18
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__divti3+0x1b0>
    2c8c:	9132e000 	add	x0, x0, #0xcb8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__divti3+0x1b0>
    2ca4:	91324000 	add	x0, x0, #0xc90
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__divti3+0x1b0>
    2cb0:	91318000 	add	x0, x0, #0xc60
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__divti3+0x1b0>
    2cbc:	9130e000 	add	x0, x0, #0xc38
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xa90>
    2eb4:	910c8021 	add	x1, x1, #0x320
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3050:	9115e000 	add	x0, x0, #0x578
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xa90>
    3118:	910c0021 	add	x1, x1, #0x300
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3150:	91164000 	add	x0, x0, #0x590
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <__divti3+0x1b0>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <__divti3+0x1b0>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	f0000058 	adrp	x24, e000 <_IO_stdin_used+0xa90>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	91176042 	add	x2, x2, #0x5d8
    31e0:	9118c2d6 	add	x22, x22, #0x630
    31e4:	91022318 	add	x24, x24, #0x88
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <__divti3+0x1b0>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	9118a323 	add	x3, x25, #0x628
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91190000 	add	x0, x0, #0x640
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3570:	9115e000 	add	x0, x0, #0x578
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__divti3+0x1b0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91192021 	add	x1, x1, #0x648
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__divti3+0x1b0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91194021 	add	x1, x1, #0x650
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__divti3+0x1b0>
    37e0:	91196021 	add	x1, x1, #0x658
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__divti3+0x1b0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91198042 	add	x2, x2, #0x660
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3950:	9115e000 	add	x0, x0, #0x578
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3970:	9119c000 	add	x0, x0, #0x670
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3a08:	911a4000 	add	x0, x0, #0x690
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3a18:	911ac000 	add	x0, x0, #0x6b0
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xa90>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0cc20 	ldr	q0, [x1, #816]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3b18:	911b6000 	add	x0, x0, #0x6d8
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3b88:	911c2000 	add	x0, x0, #0x708
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__divti3+0x1b0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	911d6084 	add	x4, x4, #0x758
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__divti3+0x1b0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	911dc084 	add	x4, x4, #0x770
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__divti3+0x1b0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	911d8084 	add	x4, x4, #0x760
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3fa8:	91174042 	add	x2, x2, #0x5d0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__divti3+0x1b0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__divti3+0x1b0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	911de021 	add	x1, x1, #0x778
    4004:	911e0000 	add	x0, x0, #0x780
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__divti3+0x1b0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911e8042 	add	x2, x2, #0x7a0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    410c:	91134061 	add	x1, x3, #0x4d0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    411c:	91174262 	add	x2, x19, #0x5d0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xa90>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    414c:	91144021 	add	x1, x1, #0x510
    4150:	3dc0d043 	ldr	q3, [x2, #832]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    417c:	91134063 	add	x3, x3, #0x4d0
    4180:	9115c084 	add	x4, x4, #0x570
    4184:	91174266 	add	x6, x19, #0x5d0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91174275 	add	x21, x19, #0x5d0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    4268:	91214000 	add	x0, x0, #0x850
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91174273 	add	x19, x19, #0x5d0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	9101c122 	add	x2, x9, #0x70
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9403c46 	ldr	x6, [x2, #120]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	9101c120 	add	x0, x9, #0x70
    4354:	f900400b 	str	x11, [x0, #128]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	9101c129 	add	x9, x9, #0x70
    4360:	f9003d26 	str	x6, [x9, #120]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <fwp_tape_buffers_release>:
    4380:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4384:	910003fd 	mov	x29, sp
    4388:	a90153f3 	stp	x19, x20, [sp, #16]
    438c:	aa0003f3 	mov	x19, x0
    4390:	f9401400 	ldr	x0, [x0, #40]
    4394:	b7f80760 	tbnz	x0, #63, 4480 <fwp_tape_buffers_release+0x100>
    4398:	f9401a61 	ldr	x1, [x19, #48]
    439c:	b7f80301 	tbnz	x1, #63, 43fc <fwp_tape_buffers_release+0x7c>
    43a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43a4:	eb02001f 	cmp	x0, x2
    43a8:	540002a8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43ac:	8b000400 	add	x0, x0, x0, lsl #1
    43b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    43b4:	d37df000 	lsl	x0, x0, #3
    43b8:	cb000042 	sub	x2, x2, x0
    43bc:	eb420c3f 	cmp	x1, x2, lsr #3
    43c0:	540001e8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43c4:	8b010c14 	add	x20, x0, x1, lsl #3
    43c8:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    43cc:	91218000 	add	x0, x0, #0x860
    43d0:	97fff990 	bl	2a10 <getenv@plt>
    43d4:	b4000240 	cbz	x0, 441c <fwp_tape_buffers_release+0x9c>
    43d8:	39400001 	ldrb	w1, [x0]
    43dc:	7100c03f 	cmp	w1, #0x30
    43e0:	540001e1 	b.ne	441c <fwp_tape_buffers_release+0x9c>  // b.any
    43e4:	39400400 	ldrb	w0, [x0, #1]
    43e8:	350001a0 	cbnz	w0, 441c <fwp_tape_buffers_release+0x9c>
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f8:	17fffc22 	b	3480 <fwp_tape_buffers_dispose>
    43fc:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    4400:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4404:	91218000 	add	x0, x0, #0x860
    4408:	97fff982 	bl	2a10 <getenv@plt>
    440c:	b4ffff00 	cbz	x0, 43ec <fwp_tape_buffers_release+0x6c>
    4410:	39400001 	ldrb	w1, [x0]
    4414:	7100c03f 	cmp	w1, #0x30
    4418:	54fffe60 	b.eq	43e4 <fwp_tape_buffers_release+0x64>  // b.none
    441c:	d1000681 	sub	x1, x20, #0x1
    4420:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4424:	eb00003f 	cmp	x1, x0
    4428:	54fffe28 	b.hi	43ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    442c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4430:	900000f6 	adrp	x22, 20000 <__data_start>
    4434:	9101c2d6 	add	x22, x22, #0x70
    4438:	910262d5 	add	x21, x22, #0x98
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fffc10 	bl	3480 <fwp_tape_buffers_dispose>
    4444:	ad400a61 	ldp	q1, q2, [x19]
    4448:	f9006ad4 	str	x20, [x22, #208]
    444c:	4f000400 	movi	v0.4s, #0x0
    4450:	ad000aa1 	stp	q1, q2, [x21]
    4454:	3dc00a61 	ldr	q1, [x19, #32]
    4458:	3d800aa1 	str	q1, [x21, #32]
    445c:	f9401a60 	ldr	x0, [x19, #48]
    4460:	f9001aa0 	str	x0, [x21, #48]
    4464:	f9001a7f 	str	xzr, [x19, #48]
    4468:	ad000260 	stp	q0, q0, [x19]
    446c:	3d800a60 	str	q0, [x19, #32]
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4478:	a8c37bfd 	ldp	x29, x30, [sp], #48
    447c:	d65f03c0 	ret
    4480:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    4484:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4488:	91218000 	add	x0, x0, #0x860
    448c:	97fff961 	bl	2a10 <getenv@plt>
    4490:	b5fffa40 	cbnz	x0, 43d8 <fwp_tape_buffers_release+0x58>
    4494:	17ffffd6 	b	43ec <fwp_tape_buffers_release+0x6c>
    4498:	d503201f 	nop
    449c:	d503201f 	nop

00000000000044a0 <fwp_poll_events>:
    44a0:	d10103ff 	sub	sp, sp, #0x40
    44a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44a8:	f947f400 	ldr	x0, [x0, #4072]
    44ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    44b0:	910083fd 	add	x29, sp, #0x20
    44b4:	a90353f3 	stp	x19, x20, [sp, #48]
    44b8:	900000f4 	adrp	x20, 20000 <__data_start>
    44bc:	f9400001 	ldr	x1, [x0]
    44c0:	f9000fe1 	str	x1, [sp, #24]
    44c4:	d2800001 	mov	x1, #0x0                   	// #0
    44c8:	97fffd2e 	bl	3980 <fwp_now_ns>
    44cc:	9101c281 	add	x1, x20, #0x70
    44d0:	f9406c33 	ldr	x19, [x1, #216]
    44d4:	b4000e93 	cbz	x19, 46a4 <fwp_poll_events+0x204>
    44d8:	aa1303e1 	mov	x1, x19
    44dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    44e0:	14000005 	b	44f4 <fwp_poll_events+0x54>
    44e4:	f9408821 	ldr	x1, [x1, #272]
    44e8:	eb03005f 	cmp	x2, x3
    44ec:	9a83d042 	csel	x2, x2, x3, le
    44f0:	b40000c1 	cbz	x1, 4508 <fwp_poll_events+0x68>
    44f4:	f9403423 	ldr	x3, [x1, #104]
    44f8:	b6ffff62 	tbz	x2, #63, 44e4 <fwp_poll_events+0x44>
    44fc:	f9408821 	ldr	x1, [x1, #272]
    4500:	aa0303e2 	mov	x2, x3
    4504:	b5ffff81 	cbnz	x1, 44f4 <fwp_poll_events+0x54>
    4508:	b7f80ce2 	tbnz	x2, #63, 46a4 <fwp_poll_events+0x204>
    450c:	cb000042 	sub	x2, x2, x0
    4510:	f100005f 	cmp	x2, #0x0
    4514:	540005cd 	b.le	45cc <fwp_poll_events+0x12c>
    4518:	d2869b60 	mov	x0, #0x34db                	// #13531
    451c:	d2884801 	mov	x1, #0x4240                	// #16960
    4520:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4524:	f2a001e1 	movk	x1, #0xf, lsl #16
    4528:	f2dbd040 	movk	x0, #0xde82, lsl #32
    452c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4530:	f2e86360 	movk	x0, #0x431b, lsl #48
    4534:	9b407c40 	smulh	x0, x2, x0
    4538:	9352fc00 	asr	x0, x0, #18
    453c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4540:	9b018802 	msub	x2, x0, x1, x2
    4544:	f100005f 	cmp	x2, #0x0
    4548:	9a800400 	cinc	x0, x0, ne	// ne = any
    454c:	eb03001f 	cmp	x0, x3
    4550:	54000a0c 	b.gt	4690 <fwp_poll_events+0x1f0>
    4554:	340003c0 	cbz	w0, 45cc <fwp_poll_events+0x12c>
    4558:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    455c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4560:	72a20c42 	movk	w2, #0x1062, lsl #16
    4564:	9ba27c02 	umull	x2, w0, w2
    4568:	d366fc43 	lsr	x3, x2, #38
    456c:	aa0303e2 	mov	x2, x3
    4570:	1b048063 	msub	w3, w3, w4, w0
    4574:	9b217c63 	smull	x3, w3, w1
    4578:	d2800001 	mov	x1, #0x0                   	// #0
    457c:	910023e0 	add	x0, sp, #0x8
    4580:	a9008fe2 	stp	x2, x3, [sp, #8]
    4584:	97fff8f3 	bl	2950 <nanosleep@plt>
    4588:	9101c280 	add	x0, x20, #0x70
    458c:	f9406c13 	ldr	x19, [x0, #216]
    4590:	97fffcfc 	bl	3980 <fwp_now_ns>
    4594:	aa0003e6 	mov	x6, x0
    4598:	b50001f3 	cbnz	x19, 45d4 <fwp_poll_events+0x134>
    459c:	d503201f 	nop
    45a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45a4:	f947f400 	ldr	x0, [x0, #4072]
    45a8:	f9400fe2 	ldr	x2, [sp, #24]
    45ac:	f9400001 	ldr	x1, [x0]
    45b0:	eb010042 	subs	x2, x2, x1
    45b4:	d2800001 	mov	x1, #0x0                   	// #0
    45b8:	540008c1 	b.ne	46d0 <fwp_poll_events+0x230>  // b.any
    45bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    45c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    45c4:	910103ff 	add	sp, sp, #0x40
    45c8:	d65f03c0 	ret
    45cc:	97fffced 	bl	3980 <fwp_now_ns>
    45d0:	aa0003e6 	mov	x6, x0
    45d4:	4f000400 	movi	v0.4s, #0x0
    45d8:	9101c288 	add	x8, x20, #0x70
    45dc:	52800027 	mov	w7, #0x1                   	// #1
    45e0:	f9403661 	ldr	x1, [x19, #104]
    45e4:	aa1303e5 	mov	x5, x19
    45e8:	f9408a73 	ldr	x19, [x19, #272]
    45ec:	eb06003f 	cmp	x1, x6
    45f0:	5400032c 	b.gt	4654 <fwp_poll_events+0x1b4>
    45f4:	394154a0 	ldrb	w0, [x5, #85]
    45f8:	36000120 	tbz	w0, #0, 461c <fwp_poll_events+0x17c>
    45fc:	f94084a0 	ldr	x0, [x5, #264]
    4600:	b40003c0 	cbz	x0, 4678 <fwp_poll_events+0x1d8>
    4604:	f9008813 	str	x19, [x0, #272]
    4608:	b4000053 	cbz	x19, 4610 <fwp_poll_events+0x170>
    460c:	f9008660 	str	x0, [x19, #264]
    4610:	910800a0 	add	x0, x5, #0x200
    4614:	390154bf 	strb	wzr, [x5, #85]
    4618:	3c908000 	stur	q0, [x0, #-248]
    461c:	f94030a0 	ldr	x0, [x5, #96]
    4620:	390158a7 	strb	w7, [x5, #86]
    4624:	f100001f 	cmp	x0, #0x0
    4628:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    462c:	5400018d 	b.le	465c <fwp_poll_events+0x1bc>
    4630:	f94028a0 	ldr	x0, [x5, #80]
    4634:	f2001c1f 	tst	x0, #0xff000000ff
    4638:	540000e1 	b.ne	4654 <fwp_poll_events+0x1b4>  // b.any
    463c:	f9403d00 	ldr	x0, [x8, #120]
    4640:	390150a7 	strb	w7, [x5, #84]
    4644:	f90080bf 	str	xzr, [x5, #256]
    4648:	b40001e0 	cbz	x0, 4684 <fwp_poll_events+0x1e4>
    464c:	f9003d05 	str	x5, [x8, #120]
    4650:	f9008005 	str	x5, [x0, #256]
    4654:	b5fffc73 	cbnz	x19, 45e0 <fwp_poll_events+0x140>
    4658:	17ffffd2 	b	45a0 <fwp_poll_events+0x100>
    465c:	394144a0 	ldrb	w0, [x5, #81]
    4660:	3707fe80 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    4664:	394140a0 	ldrb	w0, [x5, #80]
    4668:	3707fe40 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    466c:	aa0503e0 	mov	x0, x5
    4670:	97fffc20 	bl	36f0 <fwp_cancel_tree.part.0>
    4674:	17ffffef 	b	4630 <fwp_poll_events+0x190>
    4678:	9101c281 	add	x1, x20, #0x70
    467c:	f9006c33 	str	x19, [x1, #216]
    4680:	17ffffe2 	b	4608 <fwp_poll_events+0x168>
    4684:	f9003d05 	str	x5, [x8, #120]
    4688:	f9004105 	str	x5, [x8, #128]
    468c:	17fffff2 	b	4654 <fwp_poll_events+0x1b4>
    4690:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4694:	d2989362 	mov	x2, #0xc49b                	// #50331
    4698:	f2a4d203 	movk	x3, #0x2690, lsl #16
    469c:	f2a00402 	movk	x2, #0x20, lsl #16
    46a0:	17ffffb6 	b	4578 <fwp_poll_events+0xd8>
    46a4:	97fffa53 	bl	2ff0 <fwp_flush>
    46a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46ac:	f947e863 	ldr	x3, [x3, #4048]
    46b0:	d2800562 	mov	x2, #0x2b                  	// #43
    46b4:	d2800021 	mov	x1, #0x1                   	// #1
    46b8:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    46bc:	9121e000 	add	x0, x0, #0x878
    46c0:	f9400063 	ldr	x3, [x3]
    46c4:	97fff8af 	bl	2980 <fwrite@plt>
    46c8:	52800ca0 	mov	w0, #0x65                  	// #101
    46cc:	97fff819 	bl	2730 <exit@plt>
    46d0:	97fff86c 	bl	2880 <__stack_chk_fail@plt>

00000000000046d4 <fwp_rc_wide_dup>:
    46d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    46d8:	910003fd 	mov	x29, sp
    46dc:	a90153f3 	stp	x19, x20, [sp, #16]
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	ca404400 	eor	x0, x0, x0, lsr #17
    46e8:	f90013f5 	str	x21, [sp, #32]
    46ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    46f0:	ca402400 	eor	x0, x0, x0, lsr #9
    46f4:	911742a2 	add	x2, x21, #0x5d0
    46f8:	92401c00 	and	x0, x0, #0xff
    46fc:	910a2403 	add	x3, x0, #0x289
    4700:	8b000c40 	add	x0, x2, x0, lsl #3
    4704:	8b030c54 	add	x20, x2, x3, lsl #3
    4708:	f94a2401 	ldr	x1, [x0, #5192]
    470c:	b50000a1 	cbnz	x1, 4720 <fwp_rc_wide_dup+0x4c>
    4710:	1400002d 	b	47c4 <fwp_rc_wide_dup+0xf0>
    4714:	91004034 	add	x20, x1, #0x10
    4718:	f9400821 	ldr	x1, [x1, #16]
    471c:	b4000241 	cbz	x1, 4764 <fwp_rc_wide_dup+0x90>
    4720:	f9400022 	ldr	x2, [x1]
    4724:	eb02027f 	cmp	x19, x2
    4728:	54ffff61 	b.ne	4714 <fwp_rc_wide_dup+0x40>  // b.any
    472c:	f9400281 	ldr	x1, [x20]
    4730:	39400260 	ldrb	w0, [x19]
    4734:	7103f81f 	cmp	w0, #0xfe
    4738:	54000220 	b.eq	477c <fwp_rc_wide_dup+0xa8>  // b.none
    473c:	b40001a1 	cbz	x1, 4770 <fwp_rc_wide_dup+0x9c>
    4740:	f9400420 	ldr	x0, [x1, #8]
    4744:	b100041f 	cmn	x0, #0x1
    4748:	540004a0 	b.eq	47dc <fwp_rc_wide_dup+0x108>  // b.none
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f9000420 	str	x0, [x1, #8]
    4754:	a94153f3 	ldp	x19, x20, [sp, #16]
    4758:	f94013f5 	ldr	x21, [sp, #32]
    475c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4760:	d65f03c0 	ret
    4764:	39400260 	ldrb	w0, [x19]
    4768:	7103f81f 	cmp	w0, #0xfe
    476c:	540000a0 	b.eq	4780 <fwp_rc_wide_dup+0xac>  // b.none
    4770:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    4774:	91234000 	add	x0, x0, #0x8d0
    4778:	97fffc22 	bl	3800 <fwp_trap>
    477c:	b5000281 	cbnz	x1, 47cc <fwp_rc_wide_dup+0xf8>
    4780:	d2800300 	mov	x0, #0x18                  	// #24
    4784:	97fff827 	bl	2820 <malloc@plt>
    4788:	b4000280 	cbz	x0, 47d8 <fwp_rc_wide_dup+0x104>
    478c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4790:	a9000413 	stp	x19, x1, [x0]
    4794:	911742b5 	add	x21, x21, #0x5d0
    4798:	f900081f 	str	xzr, [x0, #16]
    479c:	12800001 	mov	w1, #0xffffffff            	// #-1
    47a0:	f9000280 	str	x0, [x20]
    47a4:	39000261 	strb	w1, [x19]
    47a8:	f94e26a0 	ldr	x0, [x21, #7240]
    47ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b0:	91000400 	add	x0, x0, #0x1
    47b4:	f90e26a0 	str	x0, [x21, #7240]
    47b8:	f94013f5 	ldr	x21, [sp, #32]
    47bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47c0:	d65f03c0 	ret
    47c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    47c8:	17ffffda 	b	4730 <fwp_rc_wide_dup+0x5c>
    47cc:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    47d0:	9122a000 	add	x0, x0, #0x8a8
    47d4:	97fffc0b 	bl	3800 <fwp_trap>
    47d8:	97fffa16 	bl	3030 <fwp_heap_oom>
    47dc:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    47e0:	9123e000 	add	x0, x0, #0x8f8
    47e4:	97fffc07 	bl	3800 <fwp_trap>
    47e8:	d503201f 	nop
    47ec:	d503201f 	nop

00000000000047f0 <fwp_rc_forget_slot>:
    47f0:	aa0003e1 	mov	x1, x0
    47f4:	39400000 	ldrb	w0, [x0]
    47f8:	7103fc1f 	cmp	w0, #0xff
    47fc:	54000040 	b.eq	4804 <fwp_rc_forget_slot+0x14>  // b.none
    4800:	d65f03c0 	ret
    4804:	ca414420 	eor	x0, x1, x1, lsr #17
    4808:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    480c:	ca402400 	eor	x0, x0, x0, lsr #9
    4810:	910003fd 	mov	x29, sp
    4814:	92401c00 	and	x0, x0, #0xff
    4818:	f9000bf3 	str	x19, [sp, #16]
    481c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4820:	91174262 	add	x2, x19, #0x5d0
    4824:	910a2403 	add	x3, x0, #0x289
    4828:	8b000c40 	add	x0, x2, x0, lsl #3
    482c:	8b030c43 	add	x3, x2, x3, lsl #3
    4830:	f94a2400 	ldr	x0, [x0, #5192]
    4834:	b50000a0 	cbnz	x0, 4848 <fwp_rc_forget_slot+0x58>
    4838:	14000011 	b	487c <fwp_rc_forget_slot+0x8c>
    483c:	91004003 	add	x3, x0, #0x10
    4840:	f9400800 	ldr	x0, [x0, #16]
    4844:	b40001c0 	cbz	x0, 487c <fwp_rc_forget_slot+0x8c>
    4848:	f9400002 	ldr	x2, [x0]
    484c:	eb02003f 	cmp	x1, x2
    4850:	54ffff61 	b.ne	483c <fwp_rc_forget_slot+0x4c>  // b.any
    4854:	f9400801 	ldr	x1, [x0, #16]
    4858:	91174273 	add	x19, x19, #0x5d0
    485c:	f9000061 	str	x1, [x3]
    4860:	97fff838 	bl	2940 <free@plt>
    4864:	f94e2660 	ldr	x0, [x19, #7240]
    4868:	d1000400 	sub	x0, x0, #0x1
    486c:	f90e2660 	str	x0, [x19, #7240]
    4870:	f9400bf3 	ldr	x19, [sp, #16]
    4874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4878:	d65f03c0 	ret
    487c:	b0000040 	adrp	x0, d000 <__divti3+0x1b0>
    4880:	91234000 	add	x0, x0, #0x8d0
    4884:	97fffbdf 	bl	3800 <fwp_trap>
    4888:	d503201f 	nop
    488c:	d503201f 	nop

0000000000004890 <fwp_rc_prepare_chunk>:
    4890:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4894:	910003fd 	mov	x29, sp
    4898:	a9025bf5 	stp	x21, x22, [sp, #32]
    489c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    48a0:	911742c2 	add	x2, x22, #0x5d0
    48a4:	b9401c03 	ldr	w3, [x0, #28]
    48a8:	aa0103f5 	mov	x21, x1
    48ac:	a90153f3 	stp	x19, x20, [sp, #16]
    48b0:	aa0003f4 	mov	x20, x0
    48b4:	f94e2440 	ldr	x0, [x2, #7240]
    48b8:	b4000440 	cbz	x0, 4940 <fwp_rc_prepare_chunk+0xb0>
    48bc:	d2800013 	mov	x19, #0x0                   	// #0
    48c0:	35000203 	cbnz	w3, 4900 <fwp_rc_prepare_chunk+0x70>
    48c4:	b4000361 	cbz	x1, 4930 <fwp_rc_prepare_chunk+0xa0>
    48c8:	f9401280 	ldr	x0, [x20, #32]
    48cc:	97fff81d 	bl	2940 <free@plt>
    48d0:	aa1503e0 	mov	x0, x21
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	97fff7e2 	bl	2860 <calloc@plt>
    48dc:	f9001280 	str	x0, [x20, #32]
    48e0:	b5000460 	cbnz	x0, 496c <fwp_rc_prepare_chunk+0xdc>
    48e4:	97fff9d3 	bl	3030 <fwp_heap_oom>
    48e8:	97ffffc2 	bl	47f0 <fwp_rc_forget_slot>
    48ec:	91000673 	add	x19, x19, #0x1
    48f0:	b9401e83 	ldr	w3, [x20, #28]
    48f4:	eb13007f 	cmp	x3, x19
    48f8:	54000169 	b.ls	4924 <fwp_rc_prepare_chunk+0x94>  // b.plast
    48fc:	d503201f 	nop
    4900:	f9401283 	ldr	x3, [x20, #32]
    4904:	8b130060 	add	x0, x3, x19
    4908:	38736863 	ldrb	w3, [x3, x19]
    490c:	7103fc7f 	cmp	w3, #0xff
    4910:	54fffec0 	b.eq	48e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4914:	b9401e83 	ldr	w3, [x20, #28]
    4918:	91000673 	add	x19, x19, #0x1
    491c:	eb13007f 	cmp	x3, x19
    4920:	54ffff08 	b.hi	4900 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4924:	eb0302bf 	cmp	x21, x3
    4928:	54000121 	b.ne	494c <fwp_rc_prepare_chunk+0xbc>  // b.any
    492c:	b5000335 	cbnz	x21, 4990 <fwp_rc_prepare_chunk+0x100>
    4930:	a94153f3 	ldp	x19, x20, [sp, #16]
    4934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    493c:	d65f03c0 	ret
    4940:	2a0303e3 	mov	w3, w3
    4944:	eb0302bf 	cmp	x21, x3
    4948:	54ffff20 	b.eq	492c <fwp_rc_prepare_chunk+0x9c>  // b.none
    494c:	911742c2 	add	x2, x22, #0x5d0
    4950:	f9401280 	ldr	x0, [x20, #32]
    4954:	f94e2841 	ldr	x1, [x2, #7248]
    4958:	cb030021 	sub	x1, x1, x3
    495c:	f90e2841 	str	x1, [x2, #7248]
    4960:	97fff7f8 	bl	2940 <free@plt>
    4964:	b5fffb75 	cbnz	x21, 48d0 <fwp_rc_prepare_chunk+0x40>
    4968:	f900129f 	str	xzr, [x20, #32]
    496c:	911742d6 	add	x22, x22, #0x5d0
    4970:	f94e2ac0 	ldr	x0, [x22, #7248]
    4974:	b9001e95 	str	w21, [x20, #28]
    4978:	a94153f3 	ldp	x19, x20, [sp, #16]
    497c:	8b150000 	add	x0, x0, x21
    4980:	f90e2ac0 	str	x0, [x22, #7248]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	f9401280 	ldr	x0, [x20, #32]
    4994:	aa1503e2 	mov	x2, x21
    4998:	a94153f3 	ldp	x19, x20, [sp, #16]
    499c:	52800001 	mov	w1, #0x0                   	// #0
    49a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49a8:	17fff7aa 	b	2850 <memset@plt>
    49ac:	d503201f 	nop

00000000000049b0 <fwp_heap_refill>:
    49b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49b4:	910003fd 	mov	x29, sp
    49b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    49bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    49c0:	911742b5 	add	x21, x21, #0x5d0
    49c4:	aa0003f6 	mov	x22, x0
    49c8:	d2800020 	mov	x0, #0x1                   	// #1
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a90363f7 	stp	x23, x24, [sp, #48]
    49d4:	2a0103f7 	mov	w23, w1
    49d8:	2a0203f8 	mov	w24, w2
    49dc:	97fffa35 	bl	32b0 <fwp_heap_chunks>
    49e0:	aa0003f3 	mov	x19, x0
    49e4:	f949fea2 	ldr	x2, [x21, #5112]
    49e8:	8b000800 	add	x0, x0, x0, lsl #2
    49ec:	2a1703e1 	mov	w1, w23
    49f0:	52800025 	mov	w5, #0x1                   	// #1
    49f4:	d37df000 	lsl	x0, x0, #3
    49f8:	910f0021 	add	x1, x1, #0x3c0
    49fc:	8b000054 	add	x20, x2, x0
    4a00:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a04:	52a00024 	mov	w4, #0x10000               	// #65536
    4a08:	38206845 	strb	w5, [x2, x0]
    4a0c:	aa1403e0 	mov	x0, x20
    4a10:	39000698 	strb	w24, [x20, #1]
    4a14:	39000a97 	strb	w23, [x20, #2]
    4a18:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a1c:	b9000681 	str	w1, [x20, #4]
    4a20:	2a0103e5 	mov	w5, w1
    4a24:	8b0300a2 	add	x2, x5, x3
    4a28:	1ac10881 	udiv	w1, w4, w1
    4a2c:	9ac50842 	udiv	x2, x2, x5
    4a30:	b9000a81 	str	w1, [x20, #8]
    4a34:	92404021 	and	x1, x1, #0x1ffff
    4a38:	b9001a82 	str	w2, [x20, #24]
    4a3c:	97ffff95 	bl	4890 <fwp_rc_prepare_chunk>
    4a40:	f949daa0 	ldr	x0, [x21, #5040]
    4a44:	29408a81 	ldp	w1, w2, [x20, #4]
    4a48:	8b134000 	add	x0, x0, x19, lsl #16
    4a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a50:	8b214003 	add	x3, x0, w1, uxtw
    4a54:	9ba20021 	umaddl	x1, w1, w2, x0
    4a58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a5c:	a90086c3 	stp	x3, x1, [x22, #8]
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a68:	d65f03c0 	ret
    4a6c:	d503201f 	nop

0000000000004a70 <fwp_mem_free>:
    4a70:	b40003c0 	cbz	x0, 4ae8 <fwp_mem_free+0x78>
    4a74:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a80:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a84:	911742a1 	add	x1, x21, #0x5d0
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	aa0003f3 	mov	x19, x0
    4a90:	f949d823 	ldr	x3, [x1, #5040]
    4a94:	f949ec22 	ldr	x2, [x1, #5080]
    4a98:	cb030000 	sub	x0, x0, x3
    4a9c:	eb02401f 	cmp	x0, x2, lsl #16
    4aa0:	540001c2 	b.cs	4ad8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4aa4:	d350fc16 	lsr	x22, x0, #16
    4aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    4aac:	f949fc22 	ldr	x2, [x1, #5112]
    4ab0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ab4:	d37df294 	lsl	x20, x20, #3
    4ab8:	ab140057 	adds	x23, x2, x20
    4abc:	540000c0 	b.eq	4ad4 <fwp_mem_free+0x64>  // b.none
    4ac0:	38746842 	ldrb	w2, [x2, x20]
    4ac4:	7100045f 	cmp	w2, #0x1
    4ac8:	54000120 	b.eq	4aec <fwp_mem_free+0x7c>  // b.none
    4acc:	7100085f 	cmp	w2, #0x2
    4ad0:	540005e0 	b.eq	4b8c <fwp_mem_free+0x11c>  // b.none
    4ad4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ae4:	d65f03c0 	ret
    4ae8:	d65f03c0 	ret
    4aec:	f94012f8 	ldr	x24, [x23, #32]
    4af0:	b94006e1 	ldr	w1, [x23, #4]
    4af4:	f90023f9 	str	x25, [sp, #64]
    4af8:	2a0103e2 	mov	w2, w1
    4afc:	394006f9 	ldrb	w25, [x23, #1]
    4b00:	39400af4 	ldrb	w20, [x23, #2]
    4b04:	b4000158 	cbz	x24, 4b2c <fwp_mem_free+0xbc>
    4b08:	92403e76 	and	x22, x19, #0xffff
    4b0c:	9ac20ad6 	udiv	x22, x22, x2
    4b10:	38766b01 	ldrb	w1, [x24, x22]
    4b14:	8b160300 	add	x0, x24, x22
    4b18:	7103fc3f 	cmp	w1, #0xff
    4b1c:	54000980 	b.eq	4c4c <fwp_mem_free+0x1dc>  // b.none
    4b20:	38366b1f 	strb	wzr, [x24, x22]
    4b24:	b94006e1 	ldr	w1, [x23, #4]
    4b28:	2a0103e2 	mov	w2, w1
    4b2c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b30:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b34:	cb390000 	sub	x0, x0, w25, uxtb
    4b38:	8b340074 	add	x20, x3, w20, uxtb
    4b3c:	911742b5 	add	x21, x21, #0x5d0
    4b40:	1e630021 	ucvtf	d1, w1
    4b44:	d37ae400 	lsl	x0, x0, #6
    4b48:	8b140c14 	add	x20, x0, x20, lsl #3
    4b4c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b50:	f8746aa0 	ldr	x0, [x21, x20]
    4b54:	f94023f9 	ldr	x25, [sp, #64]
    4b58:	aa2003e0 	mvn	x0, x0
    4b5c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4b60:	f9000260 	str	x0, [x19]
    4b64:	f8346ab3 	str	x19, [x21, x20]
    4b68:	f94a12a0 	ldr	x0, [x21, #5152]
    4b6c:	1e612800 	fadd	d0, d0, d1
    4b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b74:	cb020000 	sub	x0, x0, x2
    4b78:	f90a12a0 	str	x0, [x21, #5152]
    4b7c:	fd0a22a0 	str	d0, [x21, #5184]
    4b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b84:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b88:	d65f03c0 	ret
    4b8c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4b90:	8b000063 	add	x3, x3, x0
    4b94:	eb03027f 	cmp	x19, x3
    4b98:	54fff9e1 	b.ne	4ad4 <fwp_mem_free+0x64>  // b.any
    4b9c:	fd400ae1 	ldr	d1, [x23, #16]
    4ba0:	fd4a2020 	ldr	d0, [x1, #5184]
    4ba4:	f9400ae0 	ldr	x0, [x23, #16]
    4ba8:	7e61d821 	ucvtf	d1, d1
    4bac:	f94a1022 	ldr	x2, [x1, #5152]
    4bb0:	f94012f3 	ldr	x19, [x23, #32]
    4bb4:	1e612800 	fadd	d0, d0, d1
    4bb8:	cb000042 	sub	x2, x2, x0
    4bbc:	f90a1022 	str	x2, [x1, #5152]
    4bc0:	fd0a2020 	str	d0, [x1, #5184]
    4bc4:	b40000b3 	cbz	x19, 4bd8 <fwp_mem_free+0x168>
    4bc8:	39400260 	ldrb	w0, [x19]
    4bcc:	7103fc1f 	cmp	w0, #0xff
    4bd0:	54000380 	b.eq	4c40 <fwp_mem_free+0x1d0>  // b.none
    4bd4:	3900027f 	strb	wzr, [x19]
    4bd8:	b9400ee2 	ldr	w2, [x23, #12]
    4bdc:	b4000142 	cbz	x2, 4c04 <fwp_mem_free+0x194>
    4be0:	911742a1 	add	x1, x21, #0x5d0
    4be4:	8b160040 	add	x0, x2, x22
    4be8:	8b000800 	add	x0, x0, x0, lsl #2
    4bec:	f949fc21 	ldr	x1, [x1, #5112]
    4bf0:	8b140034 	add	x20, x1, x20
    4bf4:	8b000c20 	add	x0, x1, x0, lsl #3
    4bf8:	3802869f 	strb	wzr, [x20], #40
    4bfc:	eb00029f 	cmp	x20, x0
    4c00:	54ffffc1 	b.ne	4bf8 <fwp_mem_free+0x188>  // b.any
    4c04:	911742a0 	add	x0, x21, #0x5d0
    4c08:	f94a1801 	ldr	x1, [x0, #5168]
    4c0c:	f949f803 	ldr	x3, [x0, #5104]
    4c10:	8b020021 	add	x1, x1, x2
    4c14:	f90a1801 	str	x1, [x0, #5168]
    4c18:	eb16007f 	cmp	x3, x22
    4c1c:	54000049 	b.ls	4c24 <fwp_mem_free+0x1b4>  // b.plast
    4c20:	f909f816 	str	x22, [x0, #5104]
    4c24:	911742b5 	add	x21, x21, #0x5d0
    4c28:	f949f6a0 	ldr	x0, [x21, #5096]
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54fff529 	b.ls	4ad4 <fwp_mem_free+0x64>  // b.plast
    4c34:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c38:	f909f6b6 	str	x22, [x21, #5096]
    4c3c:	17ffffa7 	b	4ad8 <fwp_mem_free+0x68>
    4c40:	aa1303e0 	mov	x0, x19
    4c44:	97fffeeb 	bl	47f0 <fwp_rc_forget_slot>
    4c48:	17ffffe3 	b	4bd4 <fwp_mem_free+0x164>
    4c4c:	97fffee9 	bl	47f0 <fwp_rc_forget_slot>
    4c50:	17ffffb4 	b	4b20 <fwp_mem_free+0xb0>

0000000000004c54 <fwp_heap_alloc_big>:
    4c54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c58:	910003fd 	mov	x29, sp
    4c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c60:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c64:	a90363f7 	stp	x23, x24, [sp, #48]
    4c68:	aa0003f7 	mov	x23, x0
    4c6c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c70:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c74:	eb0002ff 	cmp	x23, x0
    4c78:	54000888 	b.hi	4d88 <fwp_heap_alloc_big+0x134>  // b.pmore
    4c7c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c80:	8b0002f4 	add	x20, x23, x0
    4c84:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c88:	91174359 	add	x25, x26, #0x5d0
    4c8c:	d350fe94 	lsr	x20, x20, #16
    4c90:	2a0103f5 	mov	w21, w1
    4c94:	aa1403e0 	mov	x0, x20
    4c98:	97fff986 	bl	32b0 <fwp_heap_chunks>
    4c9c:	f949ff22 	ldr	x2, [x25, #5112]
    4ca0:	8b000813 	add	x19, x0, x0, lsl #2
    4ca4:	aa0003f8 	mov	x24, x0
    4ca8:	52800043 	mov	w3, #0x2                   	// #2
    4cac:	d37df273 	lsl	x19, x19, #3
    4cb0:	d2800021 	mov	x1, #0x1                   	// #1
    4cb4:	8b130040 	add	x0, x2, x19
    4cb8:	38336843 	strb	w3, [x2, x19]
    4cbc:	39000415 	strb	w21, [x0, #1]
    4cc0:	b9000c14 	str	w20, [x0, #12]
    4cc4:	f9000817 	str	x23, [x0, #16]
    4cc8:	97fffef2 	bl	4890 <fwp_rc_prepare_chunk>
    4ccc:	f100069f 	cmp	x20, #0x1
    4cd0:	54000269 	b.ls	4d1c <fwp_heap_alloc_big+0xc8>  // b.plast
    4cd4:	8b180294 	add	x20, x20, x24
    4cd8:	9100a273 	add	x19, x19, #0x28
    4cdc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ce0:	5280007b 	mov	w27, #0x3                   	// #3
    4ce4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce8:	2a1803fc 	mov	w28, w24
    4cec:	9adb2296 	lsl	x22, x20, x27
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffee4 	bl	4890 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0x9c>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x104>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffca4 	bl	4104 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff70 	b	4c54 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffeb5 	bl	49b0 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94046e0 	ldr	x0, [x23, #136]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_p_ad_push>:
    5224:	f100001f 	cmp	x0, #0x0
    5228:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    522c:	5400118b 	b.lt	545c <fwp_p_ad_push+0x238>  // b.tstop
    5230:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5234:	910003fd 	mov	x29, sp
    5238:	a90153f3 	stp	x19, x20, [sp, #16]
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	aa0403f6 	mov	x22, x4
    5244:	aa0003f5 	mov	x21, x0
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	aa0203f8 	mov	x24, x2
    5250:	6d0627e8 	stp	d8, d9, [sp, #96]
    5254:	9e670029 	fmov	d9, x1
    5258:	9e670068 	fmov	d8, x3
    525c:	aa020001 	orr	x1, x0, x2
    5260:	b6f80dc1 	tbz	x1, #63, 5418 <fwp_p_ad_push+0x1f4>
    5264:	9360fc14 	asr	x20, x0, #32
    5268:	b6f800c0 	tbz	x0, #63, 5280 <fwp_p_ad_push+0x5c>
    526c:	1e604109 	fmov	d9, d8
    5270:	2f00e408 	movi	d8, #0x0
    5274:	9360fc54 	asr	x20, x2, #32
    5278:	aa0203f5 	mov	x21, x2
    527c:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5280:	b4001136 	cbz	x22, 54a4 <fwp_p_ad_push+0x280>
    5284:	f94002c0 	ldr	x0, [x22]
    5288:	eb14001f 	cmp	x0, x20
    528c:	54000e40 	b.eq	5454 <fwp_p_ad_push+0x230>  // b.none
    5290:	aa1403e0 	mov	x0, x20
    5294:	97fffa27 	bl	3b30 <fwp_tape_of>
    5298:	aa0003f3 	mov	x19, x0
    529c:	f9403000 	ldr	x0, [x0, #96]
    52a0:	b50010c0 	cbnz	x0, 54b8 <fwp_p_ad_push+0x294>
    52a4:	a9004ed4 	stp	x20, x19, [x22]
    52a8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    52ac:	f9400a77 	ldr	x23, [x19, #16]
    52b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b4:	eb0002ff 	cmp	x23, x0
    52b8:	540013ec 	b.gt	5534 <fwp_p_ad_push+0x310>
    52bc:	eb3542ff 	cmp	x23, w21, uxtw
    52c0:	5400132d 	b.le	5524 <fwp_p_ad_push+0x300>
    52c4:	b7f80078 	tbnz	x24, #63, 52d0 <fwp_p_ad_push+0xac>
    52c8:	eb3842ff 	cmp	x23, w24, uxtw
    52cc:	540012cd 	b.le	5524 <fwp_p_ad_push+0x300>
    52d0:	f9400676 	ldr	x22, [x19, #8]
    52d4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52d8:	cb1602f6 	sub	x22, x23, x22
    52dc:	910006c1 	add	x1, x22, #0x1
    52e0:	aa1603f9 	mov	x25, x22
    52e4:	eb00003f 	cmp	x1, x0
    52e8:	54001268 	b.hi	5534 <fwp_p_ad_push+0x310>  // b.pmore
    52ec:	a9418274 	ldp	x20, x0, [x19, #24]
    52f0:	eb14003f 	cmp	x1, x20
    52f4:	54000a6d 	b.le	5440 <fwp_p_ad_push+0x21c>
    52f8:	f100029f 	cmp	x20, #0x0
    52fc:	d2800803 	mov	x3, #0x40                  	// #64
    5300:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5304:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5308:	a90573fb 	stp	x27, x28, [sp, #80]
    530c:	eb14003f 	cmp	x1, x20
    5310:	5400008d 	b.le	5320 <fwp_p_ad_push+0xfc>
    5314:	eb02029f 	cmp	x20, x2
    5318:	5400090d 	b.le	5438 <fwp_p_ad_push+0x214>
    531c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5320:	d37df29a 	lsl	x26, x20, #3
    5324:	f940327b 	ldr	x27, [x19, #96]
    5328:	aa1a03e1 	mov	x1, x26
    532c:	97fff551 	bl	2870 <realloc@plt>
    5330:	b40010a0 	cbz	x0, 5544 <fwp_p_ad_push+0x320>
    5334:	f9400e61 	ldr	x1, [x19, #24]
    5338:	8b010801 	add	x1, x0, x1, lsl #2
    533c:	a9020660 	stp	x0, x1, [x19, #32]
    5340:	b400093b 	cbz	x27, 5464 <fwp_p_ad_push+0x240>
    5344:	f9403363 	ldr	x3, [x27, #96]
    5348:	f9003be3 	str	x3, [sp, #112]
    534c:	eb03029f 	cmp	x20, x3
    5350:	5400034d 	b.le	53b8 <fwp_p_ad_push+0x194>
    5354:	f940237c 	ldr	x28, [x27, #64]
    5358:	d37cee82 	lsl	x2, x20, #4
    535c:	aa0203e0 	mov	x0, x2
    5360:	52800041 	mov	w1, #0x2                   	// #2
    5364:	f9003fe2 	str	x2, [sp, #120]
    5368:	97fffee2 	bl	4ef0 <fwp_heap_alloc>
    536c:	aa0003fa 	mov	x26, x0
    5370:	b400013c 	cbz	x28, 5394 <fwp_p_ad_push+0x170>
    5374:	a9470be3 	ldp	x3, x2, [sp, #112]
    5378:	aa1c03e1 	mov	x1, x28
    537c:	d37cec63 	lsl	x3, x3, #4
    5380:	eb02007f 	cmp	x3, x2
    5384:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5388:	97fff4d2 	bl	26d0 <memcpy@plt>
    538c:	aa1c03e0 	mov	x0, x28
    5390:	97fffdb8 	bl	4a70 <fwp_mem_free>
    5394:	f9403360 	ldr	x0, [x27, #96]
    5398:	52800001 	mov	w1, #0x0                   	// #0
    539c:	cb000282 	sub	x2, x20, x0
    53a0:	8b001340 	add	x0, x26, x0, lsl #4
    53a4:	d37cec42 	lsl	x2, x2, #4
    53a8:	97fff52a 	bl	2850 <memset@plt>
    53ac:	f9401260 	ldr	x0, [x19, #32]
    53b0:	f900237a 	str	x26, [x27, #64]
    53b4:	f9003374 	str	x20, [x27, #96]
    53b8:	b50008b6 	cbnz	x22, 54cc <fwp_p_ad_push+0x2a8>
    53bc:	a9431263 	ldp	x3, x4, [x19, #48]
    53c0:	d37ef69a 	lsl	x26, x20, #2
    53c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    53c8:	8b1a0002 	add	x2, x0, x26
    53cc:	f9000e74 	str	x20, [x19, #24]
    53d0:	f9001662 	str	x2, [x19, #40]
    53d4:	b8366815 	str	w21, [x0, x22]
    53d8:	f100031f 	cmp	x24, #0x0
    53dc:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    53e0:	92607eb5 	and	x21, x21, #0xffffffff00000000
    53e4:	fc396869 	str	d9, [x3, x25]
    53e8:	aa1702a0 	orr	x0, x21, x23
    53ec:	b8366841 	str	w1, [x2, x22]
    53f0:	910006e1 	add	x1, x23, #0x1
    53f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f8:	fc396888 	str	d8, [x4, x25]
    53fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    5400:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5404:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5408:	f9000a61 	str	x1, [x19, #16]
    540c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5410:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5414:	d65f03c0 	ret
    5418:	9360fc54 	asr	x20, x2, #32
    541c:	eb80829f 	cmp	x20, x0, asr #32
    5420:	54fff300 	b.eq	5280 <fwp_p_ad_push+0x5c>  // b.none
    5424:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    5428:	91246000 	add	x0, x0, #0x918
    542c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5430:	a90573fb 	stp	x27, x28, [sp, #80]
    5434:	97fff8f3 	bl	3800 <fwp_trap>
    5438:	d37ffa94 	lsl	x20, x20, #1
    543c:	17ffffb4 	b	530c <fwp_p_ad_push+0xe8>
    5440:	a9428e62 	ldp	x2, x3, [x19, #40]
    5444:	d37ef6d6 	lsl	x22, x22, #2
    5448:	f9401e64 	ldr	x4, [x19, #56]
    544c:	d37df339 	lsl	x25, x25, #3
    5450:	17ffffe1 	b	53d4 <fwp_p_ad_push+0x1b0>
    5454:	f94006d3 	ldr	x19, [x22, #8]
    5458:	17ffff94 	b	52a8 <fwp_p_ad_push+0x84>
    545c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5460:	d65f03c0 	ret
    5464:	f9401a60 	ldr	x0, [x19, #48]
    5468:	d37cee9b 	lsl	x27, x20, #4
    546c:	aa1b03e1 	mov	x1, x27
    5470:	97fff500 	bl	2870 <realloc@plt>
    5474:	aa0003e3 	mov	x3, x0
    5478:	b4000660 	cbz	x0, 5544 <fwp_p_ad_push+0x320>
    547c:	8b1a0004 	add	x4, x0, x26
    5480:	f9400e60 	ldr	x0, [x19, #24]
    5484:	8b000c61 	add	x1, x3, x0, lsl #3
    5488:	a9030663 	stp	x3, x1, [x19, #48]
    548c:	b5000356 	cbnz	x22, 54f4 <fwp_p_ad_push+0x2d0>
    5490:	f9401260 	ldr	x0, [x19, #32]
    5494:	d37ef69a 	lsl	x26, x20, #2
    5498:	d2800016 	mov	x22, #0x0                   	// #0
    549c:	f9001e64 	str	x4, [x19, #56]
    54a0:	17ffffc9 	b	53c4 <fwp_p_ad_push+0x1a0>
    54a4:	aa1403e0 	mov	x0, x20
    54a8:	97fff9a2 	bl	3b30 <fwp_tape_of>
    54ac:	aa0003f3 	mov	x19, x0
    54b0:	f9403000 	ldr	x0, [x0, #96]
    54b4:	b4ffefa0 	cbz	x0, 52a8 <fwp_p_ad_push+0x84>
    54b8:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    54bc:	91258000 	add	x0, x0, #0x960
    54c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    54c4:	a90573fb 	stp	x27, x28, [sp, #80]
    54c8:	97fff8ce 	bl	3800 <fwp_trap>
    54cc:	d37df2d9 	lsl	x25, x22, #3
    54d0:	f9401661 	ldr	x1, [x19, #40]
    54d4:	d37ef6d6 	lsl	x22, x22, #2
    54d8:	d37ef69a 	lsl	x26, x20, #2
    54dc:	aa1603e2 	mov	x2, x22
    54e0:	8b1a0000 	add	x0, x0, x26
    54e4:	97fff483 	bl	26f0 <memmove@plt>
    54e8:	f9401260 	ldr	x0, [x19, #32]
    54ec:	a9431263 	ldp	x3, x4, [x19, #48]
    54f0:	17ffffb5 	b	53c4 <fwp_p_ad_push+0x1a0>
    54f4:	eb1b035f 	cmp	x26, x27
    54f8:	d37df2d9 	lsl	x25, x22, #3
    54fc:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5500:	aa0403e0 	mov	x0, x4
    5504:	cb1a0063 	sub	x3, x3, x26
    5508:	aa1903e2 	mov	x2, x25
    550c:	97fff545 	bl	2a20 <__memmove_chk@plt>
    5510:	f9401a61 	ldr	x1, [x19, #48]
    5514:	f9401260 	ldr	x0, [x19, #32]
    5518:	8b1a0021 	add	x1, x1, x26
    551c:	f9001e61 	str	x1, [x19, #56]
    5520:	17ffffec 	b	54d0 <fwp_p_ad_push+0x2ac>
    5524:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    5528:	9126c000 	add	x0, x0, #0x9b0
    552c:	a90573fb 	stp	x27, x28, [sp, #80]
    5530:	97fff8b4 	bl	3800 <fwp_trap>
    5534:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    5538:	91264000 	add	x0, x0, #0x990
    553c:	a90573fb 	stp	x27, x28, [sp, #80]
    5540:	97fff8b0 	bl	3800 <fwp_trap>
    5544:	aa1303e0 	mov	x0, x19
    5548:	97fff692 	bl	2f90 <fwp_tape_unlink_scope>
    554c:	f9401260 	ldr	x0, [x19, #32]
    5550:	97fff4fc 	bl	2940 <free@plt>
    5554:	f9401a60 	ldr	x0, [x19, #48]
    5558:	97fff4fa 	bl	2940 <free@plt>
    555c:	f9402260 	ldr	x0, [x19, #64]
    5560:	97fff4f8 	bl	2940 <free@plt>
    5564:	f9000e7f 	str	xzr, [x19, #24]
    5568:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    556c:	f947e821 	ldr	x1, [x1, #4048]
    5570:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5574:	d2800262 	mov	x2, #0x13                  	// #19
    5578:	4f000400 	movi	v0.4s, #0x0
    557c:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    5580:	f9400023 	ldr	x3, [x1]
    5584:	b900067f 	str	wzr, [x19, #4]
    5588:	d2800021 	mov	x1, #0x1                   	// #1
    558c:	9115e000 	add	x0, x0, #0x578
    5590:	3c808260 	stur	q0, [x19, #8]
    5594:	ad010260 	stp	q0, q0, [x19, #32]
    5598:	97fff4fa 	bl	2980 <fwrite@plt>
    559c:	d2800000 	mov	x0, #0x0                   	// #0
    55a0:	97fff504 	bl	29b0 <fflush@plt>
    55a4:	52800cc0 	mov	w0, #0x66                  	// #102
    55a8:	97fff512 	bl	29f0 <_Exit@plt>
    55ac:	d503201f 	nop

00000000000055b0 <w107>:
    55b0:	d10203ff 	sub	sp, sp, #0x80
    55b4:	9e660003 	fmov	x3, d0
    55b8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    55bc:	f947f442 	ldr	x2, [x2, #4072]
    55c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    55c4:	910083fd 	add	x29, sp, #0x20
    55c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    55cc:	1e604009 	fmov	d9, d0
    55d0:	1e604028 	fmov	d8, d1
    55d4:	fd003bea 	str	d10, [sp, #112]
    55d8:	1e60080a 	fmul	d10, d0, d0
    55dc:	a90353f3 	stp	x19, x20, [sp, #48]
    55e0:	910023f3 	add	x19, sp, #0x8
    55e4:	aa0003f4 	mov	x20, x0
    55e8:	a9045bf5 	stp	x21, x22, [sp, #64]
    55ec:	aa0103f6 	mov	x22, x1
    55f0:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    55f4:	a90563f7 	stp	x23, x24, [sp, #80]
    55f8:	aa0303e1 	mov	x1, x3
    55fc:	f9400044 	ldr	x4, [x2]
    5600:	f9000fe4 	str	x4, [sp, #24]
    5604:	d2800004 	mov	x4, #0x0                   	// #0
    5608:	aa0003e2 	mov	x2, x0
    560c:	aa1303e4 	mov	x4, x19
    5610:	a900fff5 	stp	x21, xzr, [sp, #8]
    5614:	97ffff04 	bl	5224 <fwp_p_ad_push>
    5618:	1e6a3908 	fsub	d8, d8, d10
    561c:	aa1603e2 	mov	x2, x22
    5620:	aa1303e4 	mov	x4, x19
    5624:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5628:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    562c:	9e660118 	fmov	x24, d8
    5630:	97fffefd 	bl	5224 <fwp_p_ad_push>
    5634:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5638:	aa0003f6 	mov	x22, x0
    563c:	aa1303e4 	mov	x4, x19
    5640:	aa1403e0 	mov	x0, x20
    5644:	1e69394a 	fsub	d10, d10, d9
    5648:	aa1503e2 	mov	x2, x21
    564c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5650:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5654:	9e660157 	fmov	x23, d10
    5658:	97fffef3 	bl	5224 <fwp_p_ad_push>
    565c:	1e680908 	fmul	d8, d8, d8
    5660:	aa0003f4 	mov	x20, x0
    5664:	aa1303e4 	mov	x4, x19
    5668:	aa1803e3 	mov	x3, x24
    566c:	aa1803e1 	mov	x1, x24
    5670:	aa1603e2 	mov	x2, x22
    5674:	aa1603e0 	mov	x0, x22
    5678:	97fffeeb 	bl	5224 <fwp_p_ad_push>
    567c:	aa0003e2 	mov	x2, x0
    5680:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5684:	9e670029 	fmov	d9, x1
    5688:	9e660101 	fmov	x1, d8
    568c:	aa1303e4 	mov	x4, x19
    5690:	1e690909 	fmul	d9, d8, d9
    5694:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5698:	aa1503e0 	mov	x0, x21
    569c:	97fffee2 	bl	5224 <fwp_p_ad_push>
    56a0:	1e6a094a 	fmul	d10, d10, d10
    56a4:	aa1303e4 	mov	x4, x19
    56a8:	aa1703e3 	mov	x3, x23
    56ac:	aa0003f3 	mov	x19, x0
    56b0:	aa1703e1 	mov	x1, x23
    56b4:	aa1403e2 	mov	x2, x20
    56b8:	aa1403e0 	mov	x0, x20
    56bc:	97fffeda 	bl	5224 <fwp_p_ad_push>
    56c0:	1e6a2929 	fadd	d9, d9, d10
    56c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    56c8:	d2800004 	mov	x4, #0x0                   	// #0
    56cc:	aa0303e1 	mov	x1, x3
    56d0:	aa1303e2 	mov	x2, x19
    56d4:	97fffed4 	bl	5224 <fwp_p_ad_push>
    56d8:	aa0003e1 	mov	x1, x0
    56dc:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    56e0:	f947f463 	ldr	x3, [x3, #4072]
    56e4:	f9400fe0 	ldr	x0, [sp, #24]
    56e8:	f9400064 	ldr	x4, [x3]
    56ec:	eb040000 	subs	x0, x0, x4
    56f0:	d2800004 	mov	x4, #0x0                   	// #0
    56f4:	54000161 	b.ne	5720 <w107+0x170>  // b.any
    56f8:	9e660122 	fmov	x2, d9
    56fc:	fd403bea 	ldr	d10, [sp, #112]
    5700:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5704:	a94353f3 	ldp	x19, x20, [sp, #48]
    5708:	aa0203e0 	mov	x0, x2
    570c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5710:	a94563f7 	ldp	x23, x24, [sp, #80]
    5714:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5718:	910203ff 	add	sp, sp, #0x80
    571c:	d65f03c0 	ret
    5720:	97fff458 	bl	2880 <__stack_chk_fail@plt>

0000000000005724 <w164.constprop.0>:
    5724:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5728:	910003fd 	mov	x29, sp
    572c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5730:	fd001be8 	str	d8, [sp, #48]
    5734:	f9400015 	ldr	x21, [x0]
    5738:	b4000355 	cbz	x21, 57a0 <w164.constprop.0+0x7c>
    573c:	2f00e408 	movi	d8, #0x0
    5740:	91002016 	add	x22, x0, #0x8
    5744:	a90153f3 	stp	x19, x20, [sp, #16]
    5748:	91004014 	add	x20, x0, #0x10
    574c:	d2800013 	mov	x19, #0x0                   	// #0
    5750:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5754:	d503201f 	nop
    5758:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    575c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5760:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5764:	aa0303e1 	mov	x1, x3
    5768:	1e602908 	fadd	d8, d8, d0
    576c:	d2800004 	mov	x4, #0x0                   	// #0
    5770:	91000a73 	add	x19, x19, #0x2
    5774:	97fffeac 	bl	5224 <fwp_p_ad_push>
    5778:	eb1302bf 	cmp	x21, x19
    577c:	54fffee8 	b.hi	5758 <w164.constprop.0+0x34>  // b.pmore
    5780:	9e660102 	fmov	x2, d8
    5784:	fd401be8 	ldr	d8, [sp, #48]
    5788:	a94153f3 	ldp	x19, x20, [sp, #16]
    578c:	aa0003e1 	mov	x1, x0
    5790:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5794:	aa0203e0 	mov	x0, x2
    5798:	a8c47bfd 	ldp	x29, x30, [sp], #64
    579c:	d65f03c0 	ret
    57a0:	2f00e408 	movi	d8, #0x0
    57a4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57ac:	aa0003e1 	mov	x1, x0
    57b0:	9e660102 	fmov	x2, d8
    57b4:	fd401be8 	ldr	d8, [sp, #48]
    57b8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57bc:	aa0203e0 	mov	x0, x2
    57c0:	d65f03c0 	ret

00000000000057c4 <fwp_data.part.0.constprop.0>:
    57c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    57c8:	910003fd 	mov	x29, sp
    57cc:	a90153f3 	stp	x19, x20, [sp, #16]
    57d0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    57d4:	91174283 	add	x3, x20, #0x5d0
    57d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    57dc:	aa0103f5 	mov	x21, x1
    57e0:	b953a461 	ldr	w1, [x3, #5028]
    57e4:	a90363f7 	stp	x23, x24, [sp, #48]
    57e8:	2a0003f8 	mov	w24, w0
    57ec:	34000701 	cbz	w1, 58cc <fwp_data.part.0.constprop.0+0x108>
    57f0:	397e8862 	ldrb	w2, [x3, #4002]
    57f4:	910f0040 	add	x0, x2, #0x3c0
    57f8:	8b020442 	add	x2, x2, x2, lsl #1
    57fc:	d37df042 	lsl	x2, x2, #3
    5800:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5804:	2a1703f6 	mov	w22, w23
    5808:	f8626873 	ldr	x19, [x3, x2]
    580c:	b40004d3 	cbz	x19, 58a4 <fwp_data.part.0.constprop.0+0xe0>
    5810:	f9400260 	ldr	x0, [x19]
    5814:	aa2003e0 	mvn	x0, x0
    5818:	f8226860 	str	x0, [x3, x2]
    581c:	f10062df 	cmp	x22, #0x18
    5820:	540000e9 	b.ls	583c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5824:	d10066c2 	sub	x2, x22, #0x19
    5828:	91006260 	add	x0, x19, #0x18
    582c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5830:	52800001 	mov	w1, #0x0                   	// #0
    5834:	91002042 	add	x2, x2, #0x8
    5838:	97fff406 	bl	2850 <memset@plt>
    583c:	91174282 	add	x2, x20, #0x5d0
    5840:	f94a1041 	ldr	x1, [x2, #5152]
    5844:	ab160021 	adds	x1, x1, x22
    5848:	540004c2 	b.cs	58e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    584c:	f94a1440 	ldr	x0, [x2, #5160]
    5850:	f90a1041 	str	x1, [x2, #5152]
    5854:	eb00003f 	cmp	x1, x0
    5858:	54000049 	b.ls	5860 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    585c:	f90a1441 	str	x1, [x2, #5160]
    5860:	91174294 	add	x20, x20, #0x5d0
    5864:	1e6302e1 	ucvtf	d1, w23
    5868:	fd4a1e80 	ldr	d0, [x20, #5176]
    586c:	1e612800 	fadd	d0, d0, d1
    5870:	fd0a1e80 	str	d0, [x20, #5176]
    5874:	52800041 	mov	w1, #0x2                   	// #2
    5878:	29000678 	stp	w24, w1, [x19]
    587c:	aa1303e0 	mov	x0, x19
    5880:	f94002a1 	ldr	x1, [x21]
    5884:	f9000661 	str	x1, [x19, #8]
    5888:	f94006a1 	ldr	x1, [x21, #8]
    588c:	f9000a61 	str	x1, [x19, #16]
    5890:	a94153f3 	ldp	x19, x20, [sp, #16]
    5894:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5898:	a94363f7 	ldp	x23, x24, [sp, #48]
    589c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58a0:	d65f03c0 	ret
    58a4:	8b020063 	add	x3, x3, x2
    58a8:	f9400473 	ldr	x19, [x3, #8]
    58ac:	b4000113 	cbz	x19, 58cc <fwp_data.part.0.constprop.0+0x108>
    58b0:	f9400860 	ldr	x0, [x3, #16]
    58b4:	cb130000 	sub	x0, x0, x19
    58b8:	eb0002df 	cmp	x22, x0
    58bc:	54000088 	b.hi	58cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    58c0:	8b160260 	add	x0, x19, x22
    58c4:	f9000460 	str	x0, [x3, #8]
    58c8:	17ffffd5 	b	581c <fwp_data.part.0.constprop.0+0x58>
    58cc:	52800001 	mov	w1, #0x0                   	// #0
    58d0:	d2800300 	mov	x0, #0x18                  	// #24
    58d4:	97fffd87 	bl	4ef0 <fwp_heap_alloc>
    58d8:	aa0003f3 	mov	x19, x0
    58dc:	17ffffe6 	b	5874 <fwp_data.part.0.constprop.0+0xb0>
    58e0:	97fff5d4 	bl	3030 <fwp_heap_oom>

00000000000058e4 <fwp_rc_share>:
    58e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    58e8:	91174042 	add	x2, x2, #0x5d0
    58ec:	f949d843 	ldr	x3, [x2, #5040]
    58f0:	f949ec41 	ldr	x1, [x2, #5080]
    58f4:	cb030000 	sub	x0, x0, x3
    58f8:	eb01401f 	cmp	x0, x1, lsl #16
    58fc:	540002c2 	b.cs	5954 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5900:	d350fc01 	lsr	x1, x0, #16
    5904:	f949fc44 	ldr	x4, [x2, #5112]
    5908:	8b010821 	add	x1, x1, x1, lsl #2
    590c:	d37df021 	lsl	x1, x1, #3
    5910:	8b010083 	add	x3, x4, x1
    5914:	f9401062 	ldr	x2, [x3, #32]
    5918:	b40001e2 	cbz	x2, 5954 <fwp_rc_share+0x70>
    591c:	38616881 	ldrb	w1, [x4, x1]
    5920:	7100083f 	cmp	w1, #0x2
    5924:	540001a0 	b.eq	5958 <fwp_rc_share+0x74>  // b.none
    5928:	7100043f 	cmp	w1, #0x1
    592c:	54000141 	b.ne	5954 <fwp_rc_share+0x70>  // b.any
    5930:	29430464 	ldp	w4, w1, [x3, #24]
    5934:	92403c00 	and	x0, x0, #0xffff
    5938:	9b047c00 	mul	x0, x0, x4
    593c:	d360fc00 	lsr	x0, x0, #32
    5940:	eb01001f 	cmp	x0, x1
    5944:	54000082 	b.cs	5954 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5948:	8b000042 	add	x2, x2, x0
    594c:	39400040 	ldrb	w0, [x2]
    5950:	350000a0 	cbnz	w0, 5964 <fwp_rc_share+0x80>
    5954:	d65f03c0 	ret
    5958:	72003c1f 	tst	w0, #0xffff
    595c:	54ffff80 	b.eq	594c <fwp_rc_share+0x68>  // b.none
    5960:	d65f03c0 	ret
    5964:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5968:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    596c:	91274000 	add	x0, x0, #0x9d0
    5970:	910003fd 	mov	x29, sp
    5974:	97fff7a3 	bl	3800 <fwp_trap>
    5978:	d503201f 	nop
    597c:	d503201f 	nop

0000000000005980 <fwp_rc_fresh>:
    5980:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5984:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5988:	91174063 	add	x3, x3, #0x5d0
    598c:	910003fd 	mov	x29, sp
    5990:	a90153f3 	stp	x19, x20, [sp, #16]
    5994:	aa0003f3 	mov	x19, x0
    5998:	f949d861 	ldr	x1, [x3, #5040]
    599c:	f949ec60 	ldr	x0, [x3, #5080]
    59a0:	cb010261 	sub	x1, x19, x1
    59a4:	eb00403f 	cmp	x1, x0, lsl #16
    59a8:	54000322 	b.cs	5a0c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    59ac:	d350fc22 	lsr	x2, x1, #16
    59b0:	f949fc63 	ldr	x3, [x3, #5112]
    59b4:	8b020842 	add	x2, x2, x2, lsl #2
    59b8:	d37df042 	lsl	x2, x2, #3
    59bc:	8b020060 	add	x0, x3, x2
    59c0:	f9401014 	ldr	x20, [x0, #32]
    59c4:	b4000254 	cbz	x20, 5a0c <fwp_rc_fresh+0x8c>
    59c8:	38626862 	ldrb	w2, [x3, x2]
    59cc:	7100085f 	cmp	w2, #0x2
    59d0:	54000260 	b.eq	5a1c <fwp_rc_fresh+0x9c>  // b.none
    59d4:	7100045f 	cmp	w2, #0x1
    59d8:	540001a1 	b.ne	5a0c <fwp_rc_fresh+0x8c>  // b.any
    59dc:	29430002 	ldp	w2, w0, [x0, #24]
    59e0:	92403c21 	and	x1, x1, #0xffff
    59e4:	9b027c21 	mul	x1, x1, x2
    59e8:	d360fc21 	lsr	x1, x1, #32
    59ec:	eb00003f 	cmp	x1, x0
    59f0:	540000e2 	b.cs	5a0c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    59f4:	8b010294 	add	x20, x20, x1
    59f8:	39400280 	ldrb	w0, [x20]
    59fc:	7103fc1f 	cmp	w0, #0xff
    5a00:	540001a0 	b.eq	5a34 <fwp_rc_fresh+0xb4>  // b.none
    5a04:	52800020 	mov	w0, #0x1                   	// #1
    5a08:	39000280 	strb	w0, [x20]
    5a0c:	aa1303e0 	mov	x0, x19
    5a10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a18:	d65f03c0 	ret
    5a1c:	72003c3f 	tst	w1, #0xffff
    5a20:	54fffec0 	b.eq	59f8 <fwp_rc_fresh+0x78>  // b.none
    5a24:	aa1303e0 	mov	x0, x19
    5a28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a30:	d65f03c0 	ret
    5a34:	aa1403e0 	mov	x0, x20
    5a38:	97fffb6e 	bl	47f0 <fwp_rc_forget_slot>
    5a3c:	17fffff2 	b	5a04 <fwp_rc_fresh+0x84>

0000000000005a40 <fwp_rc_free_arr>:
    5a40:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5a44:	91174063 	add	x3, x3, #0x5d0
    5a48:	f949d861 	ldr	x1, [x3, #5040]
    5a4c:	f949ec62 	ldr	x2, [x3, #5080]
    5a50:	cb010001 	sub	x1, x0, x1
    5a54:	eb02403f 	cmp	x1, x2, lsl #16
    5a58:	54000342 	b.cs	5ac0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a5c:	d350fc22 	lsr	x2, x1, #16
    5a60:	f949fc65 	ldr	x5, [x3, #5112]
    5a64:	8b020842 	add	x2, x2, x2, lsl #2
    5a68:	d37df042 	lsl	x2, x2, #3
    5a6c:	8b0200a4 	add	x4, x5, x2
    5a70:	f9401083 	ldr	x3, [x4, #32]
    5a74:	b4000263 	cbz	x3, 5ac0 <fwp_rc_free_arr+0x80>
    5a78:	386268a2 	ldrb	w2, [x5, x2]
    5a7c:	7100085f 	cmp	w2, #0x2
    5a80:	540001c0 	b.eq	5ab8 <fwp_rc_free_arr+0x78>  // b.none
    5a84:	7100045f 	cmp	w2, #0x1
    5a88:	540001c1 	b.ne	5ac0 <fwp_rc_free_arr+0x80>  // b.any
    5a8c:	29430885 	ldp	w5, w2, [x4, #24]
    5a90:	92403c21 	and	x1, x1, #0xffff
    5a94:	9b057c21 	mul	x1, x1, x5
    5a98:	d360fc21 	lsr	x1, x1, #32
    5a9c:	eb02003f 	cmp	x1, x2
    5aa0:	54000102 	b.cs	5ac0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5aa4:	8b010063 	add	x3, x3, x1
    5aa8:	39400061 	ldrb	w1, [x3]
    5aac:	7100043f 	cmp	w1, #0x1
    5ab0:	54000081 	b.ne	5ac0 <fwp_rc_free_arr+0x80>  // b.any
    5ab4:	17fffbef 	b	4a70 <fwp_mem_free>
    5ab8:	72003c3f 	tst	w1, #0xffff
    5abc:	54ffff60 	b.eq	5aa8 <fwp_rc_free_arr+0x68>  // b.none
    5ac0:	d65f03c0 	ret

0000000000005ac4 <fwp_rc_dup>:
    5ac4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5ac8:	91174042 	add	x2, x2, #0x5d0
    5acc:	f949d841 	ldr	x1, [x2, #5040]
    5ad0:	f949ec43 	ldr	x3, [x2, #5080]
    5ad4:	cb010001 	sub	x1, x0, x1
    5ad8:	eb03403f 	cmp	x1, x3, lsl #16
    5adc:	54000342 	b.cs	5b44 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ae0:	d350fc20 	lsr	x0, x1, #16
    5ae4:	f949fc44 	ldr	x4, [x2, #5112]
    5ae8:	8b000800 	add	x0, x0, x0, lsl #2
    5aec:	d37df002 	lsl	x2, x0, #3
    5af0:	8b020083 	add	x3, x4, x2
    5af4:	f9401060 	ldr	x0, [x3, #32]
    5af8:	b4000260 	cbz	x0, 5b44 <fwp_rc_dup+0x80>
    5afc:	38626882 	ldrb	w2, [x4, x2]
    5b00:	7100085f 	cmp	w2, #0x2
    5b04:	54000220 	b.eq	5b48 <fwp_rc_dup+0x84>  // b.none
    5b08:	7100045f 	cmp	w2, #0x1
    5b0c:	540001c1 	b.ne	5b44 <fwp_rc_dup+0x80>  // b.any
    5b10:	29430864 	ldp	w4, w2, [x3, #24]
    5b14:	92403c21 	and	x1, x1, #0xffff
    5b18:	9b047c21 	mul	x1, x1, x4
    5b1c:	d360fc21 	lsr	x1, x1, #32
    5b20:	eb02003f 	cmp	x1, x2
    5b24:	54000102 	b.cs	5b44 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5b28:	8b010000 	add	x0, x0, x1
    5b2c:	39400001 	ldrb	w1, [x0]
    5b30:	340000a1 	cbz	w1, 5b44 <fwp_rc_dup+0x80>
    5b34:	7103f43f 	cmp	w1, #0xfd
    5b38:	540000e8 	b.hi	5b54 <fwp_rc_dup+0x90>  // b.pmore
    5b3c:	11000421 	add	w1, w1, #0x1
    5b40:	39000001 	strb	w1, [x0]
    5b44:	d65f03c0 	ret
    5b48:	72003c3f 	tst	w1, #0xffff
    5b4c:	54ffff00 	b.eq	5b2c <fwp_rc_dup+0x68>  // b.none
    5b50:	d65f03c0 	ret
    5b54:	17fffae0 	b	46d4 <fwp_rc_wide_dup>
    5b58:	d503201f 	nop
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_owned_entry161>:
    5b60:	d10103ff 	sub	sp, sp, #0x40
    5b64:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5b68:	f947f442 	ldr	x2, [x2, #4072]
    5b6c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b70:	910083fd 	add	x29, sp, #0x20
    5b74:	a90353f3 	stp	x19, x20, [sp, #48]
    5b78:	f9400043 	ldr	x3, [x2]
    5b7c:	f9000fe3 	str	x3, [sp, #24]
    5b80:	d2800003 	mov	x3, #0x0                   	// #0
    5b84:	a9400c01 	ldp	x1, x3, [x0]
    5b88:	f9400802 	ldr	x2, [x0, #16]
    5b8c:	ab020022 	adds	x2, x1, x2
    5b90:	540006e6 	b.vs	5c6c <fwp_owned_entry161+0x10c>
    5b94:	910023e1 	add	x1, sp, #0x8
    5b98:	52800000 	mov	w0, #0x0                   	// #0
    5b9c:	a9008be3 	stp	x3, x2, [sp, #8]
    5ba0:	97ffff09 	bl	57c4 <fwp_data.part.0.constprop.0>
    5ba4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5ba8:	91174063 	add	x3, x3, #0x5d0
    5bac:	aa0003f3 	mov	x19, x0
    5bb0:	f949d861 	ldr	x1, [x3, #5040]
    5bb4:	f949ec60 	ldr	x0, [x3, #5080]
    5bb8:	cb010261 	sub	x1, x19, x1
    5bbc:	eb00403f 	cmp	x1, x0, lsl #16
    5bc0:	54000322 	b.cs	5c24 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5bc4:	d350fc22 	lsr	x2, x1, #16
    5bc8:	f949fc63 	ldr	x3, [x3, #5112]
    5bcc:	8b020842 	add	x2, x2, x2, lsl #2
    5bd0:	d37df042 	lsl	x2, x2, #3
    5bd4:	8b020060 	add	x0, x3, x2
    5bd8:	f9401014 	ldr	x20, [x0, #32]
    5bdc:	b4000254 	cbz	x20, 5c24 <fwp_owned_entry161+0xc4>
    5be0:	38626862 	ldrb	w2, [x3, x2]
    5be4:	7100085f 	cmp	w2, #0x2
    5be8:	54000360 	b.eq	5c54 <fwp_owned_entry161+0xf4>  // b.none
    5bec:	7100045f 	cmp	w2, #0x1
    5bf0:	540001a1 	b.ne	5c24 <fwp_owned_entry161+0xc4>  // b.any
    5bf4:	29430002 	ldp	w2, w0, [x0, #24]
    5bf8:	92403c21 	and	x1, x1, #0xffff
    5bfc:	9b027c21 	mul	x1, x1, x2
    5c00:	d360fc21 	lsr	x1, x1, #32
    5c04:	eb00003f 	cmp	x1, x0
    5c08:	540000e2 	b.cs	5c24 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5c0c:	8b010294 	add	x20, x20, x1
    5c10:	39400280 	ldrb	w0, [x20]
    5c14:	7103fc1f 	cmp	w0, #0xff
    5c18:	54000240 	b.eq	5c60 <fwp_owned_entry161+0x100>  // b.none
    5c1c:	52800020 	mov	w0, #0x1                   	// #1
    5c20:	39000280 	strb	w0, [x20]
    5c24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5c28:	f947f400 	ldr	x0, [x0, #4072]
    5c2c:	f9400fe2 	ldr	x2, [sp, #24]
    5c30:	f9400001 	ldr	x1, [x0]
    5c34:	eb010042 	subs	x2, x2, x1
    5c38:	d2800001 	mov	x1, #0x0                   	// #0
    5c3c:	540001a1 	b.ne	5c70 <fwp_owned_entry161+0x110>  // b.any
    5c40:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c44:	aa1303e0 	mov	x0, x19
    5c48:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c4c:	910103ff 	add	sp, sp, #0x40
    5c50:	d65f03c0 	ret
    5c54:	72003c3f 	tst	w1, #0xffff
    5c58:	54fffe61 	b.ne	5c24 <fwp_owned_entry161+0xc4>  // b.any
    5c5c:	17ffffed 	b	5c10 <fwp_owned_entry161+0xb0>
    5c60:	aa1403e0 	mov	x0, x20
    5c64:	97fffae3 	bl	47f0 <fwp_rc_forget_slot>
    5c68:	17ffffed 	b	5c1c <fwp_owned_entry161+0xbc>
    5c6c:	97fff385 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5c70:	97fff304 	bl	2880 <__stack_chk_fail@plt>

0000000000005c74 <e161>:
    5c74:	d10103ff 	sub	sp, sp, #0x40
    5c78:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5c7c:	f947f442 	ldr	x2, [x2, #4072]
    5c80:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c84:	910083fd 	add	x29, sp, #0x20
    5c88:	a90353f3 	stp	x19, x20, [sp, #48]
    5c8c:	f9400043 	ldr	x3, [x2]
    5c90:	f9000fe3 	str	x3, [sp, #24]
    5c94:	d2800003 	mov	x3, #0x0                   	// #0
    5c98:	a9400c01 	ldp	x1, x3, [x0]
    5c9c:	f9400802 	ldr	x2, [x0, #16]
    5ca0:	ab020022 	adds	x2, x1, x2
    5ca4:	54000726 	b.vs	5d88 <e161+0x114>
    5ca8:	910023e1 	add	x1, sp, #0x8
    5cac:	52800000 	mov	w0, #0x0                   	// #0
    5cb0:	a9008be3 	stp	x3, x2, [sp, #8]
    5cb4:	97fffec4 	bl	57c4 <fwp_data.part.0.constprop.0>
    5cb8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5cbc:	91174063 	add	x3, x3, #0x5d0
    5cc0:	aa0003f3 	mov	x19, x0
    5cc4:	f949d861 	ldr	x1, [x3, #5040]
    5cc8:	f949ec60 	ldr	x0, [x3, #5080]
    5ccc:	cb010261 	sub	x1, x19, x1
    5cd0:	eb00403f 	cmp	x1, x0, lsl #16
    5cd4:	54000322 	b.cs	5d38 <e161+0xc4>  // b.hs, b.nlast
    5cd8:	d350fc22 	lsr	x2, x1, #16
    5cdc:	f949fc63 	ldr	x3, [x3, #5112]
    5ce0:	8b020842 	add	x2, x2, x2, lsl #2
    5ce4:	d37df042 	lsl	x2, x2, #3
    5ce8:	8b020060 	add	x0, x3, x2
    5cec:	f9401014 	ldr	x20, [x0, #32]
    5cf0:	b4000254 	cbz	x20, 5d38 <e161+0xc4>
    5cf4:	38626862 	ldrb	w2, [x3, x2]
    5cf8:	7100085f 	cmp	w2, #0x2
    5cfc:	540003a0 	b.eq	5d70 <e161+0xfc>  // b.none
    5d00:	7100045f 	cmp	w2, #0x1
    5d04:	540001a1 	b.ne	5d38 <e161+0xc4>  // b.any
    5d08:	29430002 	ldp	w2, w0, [x0, #24]
    5d0c:	92403c21 	and	x1, x1, #0xffff
    5d10:	9b027c21 	mul	x1, x1, x2
    5d14:	d360fc21 	lsr	x1, x1, #32
    5d18:	eb00003f 	cmp	x1, x0
    5d1c:	540000e2 	b.cs	5d38 <e161+0xc4>  // b.hs, b.nlast
    5d20:	8b010294 	add	x20, x20, x1
    5d24:	39400280 	ldrb	w0, [x20]
    5d28:	7103fc1f 	cmp	w0, #0xff
    5d2c:	54000280 	b.eq	5d7c <e161+0x108>  // b.none
    5d30:	52800020 	mov	w0, #0x1                   	// #1
    5d34:	39000280 	strb	w0, [x20]
    5d38:	aa1303e0 	mov	x0, x19
    5d3c:	97fffeea 	bl	58e4 <fwp_rc_share>
    5d40:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5d44:	f947f400 	ldr	x0, [x0, #4072]
    5d48:	f9400fe2 	ldr	x2, [sp, #24]
    5d4c:	f9400001 	ldr	x1, [x0]
    5d50:	eb010042 	subs	x2, x2, x1
    5d54:	d2800001 	mov	x1, #0x0                   	// #0
    5d58:	540001a1 	b.ne	5d8c <e161+0x118>  // b.any
    5d5c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d60:	aa1303e0 	mov	x0, x19
    5d64:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d68:	910103ff 	add	sp, sp, #0x40
    5d6c:	d65f03c0 	ret
    5d70:	72003c3f 	tst	w1, #0xffff
    5d74:	54fffe21 	b.ne	5d38 <e161+0xc4>  // b.any
    5d78:	17ffffeb 	b	5d24 <e161+0xb0>
    5d7c:	aa1403e0 	mov	x0, x20
    5d80:	97fffa9c 	bl	47f0 <fwp_rc_forget_slot>
    5d84:	17ffffeb 	b	5d30 <e161+0xbc>
    5d88:	97fff33e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5d8c:	97fff2bd 	bl	2880 <__stack_chk_fail@plt>

0000000000005d90 <fwp_drop1>:
    5d90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d94:	910003fd 	mov	x29, sp
    5d98:	a90153f3 	stp	x19, x20, [sp, #16]
    5d9c:	f90013f5 	str	x21, [sp, #32]
    5da0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5da4:	911742b4 	add	x20, x21, #0x5d0
    5da8:	f949da81 	ldr	x1, [x20, #5040]
    5dac:	f949ee82 	ldr	x2, [x20, #5080]
    5db0:	cb010001 	sub	x1, x0, x1
    5db4:	eb02403f 	cmp	x1, x2, lsl #16
    5db8:	54000382 	b.cs	5e28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5dbc:	d350fc22 	lsr	x2, x1, #16
    5dc0:	f949fe84 	ldr	x4, [x20, #5112]
    5dc4:	8b020842 	add	x2, x2, x2, lsl #2
    5dc8:	d37df042 	lsl	x2, x2, #3
    5dcc:	8b020083 	add	x3, x4, x2
    5dd0:	f9401073 	ldr	x19, [x3, #32]
    5dd4:	b40002b3 	cbz	x19, 5e28 <fwp_drop1+0x98>
    5dd8:	38626882 	ldrb	w2, [x4, x2]
    5ddc:	7100085f 	cmp	w2, #0x2
    5de0:	540002c0 	b.eq	5e38 <fwp_drop1+0xa8>  // b.none
    5de4:	7100045f 	cmp	w2, #0x1
    5de8:	54000201 	b.ne	5e28 <fwp_drop1+0x98>  // b.any
    5dec:	29430864 	ldp	w4, w2, [x3, #24]
    5df0:	92403c21 	and	x1, x1, #0xffff
    5df4:	9b047c21 	mul	x1, x1, x4
    5df8:	d360fc21 	lsr	x1, x1, #32
    5dfc:	eb02003f 	cmp	x1, x2
    5e00:	54000142 	b.cs	5e28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e04:	8b010273 	add	x19, x19, x1
    5e08:	39400261 	ldrb	w1, [x19]
    5e0c:	340000e1 	cbz	w1, 5e28 <fwp_drop1+0x98>
    5e10:	7100043f 	cmp	w1, #0x1
    5e14:	540001e0 	b.eq	5e50 <fwp_drop1+0xc0>  // b.none
    5e18:	7103fc3f 	cmp	w1, #0xff
    5e1c:	540002e0 	b.eq	5e78 <fwp_drop1+0xe8>  // b.none
    5e20:	51000421 	sub	w1, w1, #0x1
    5e24:	39000261 	strb	w1, [x19]
    5e28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e2c:	f94013f5 	ldr	x21, [sp, #32]
    5e30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e34:	d65f03c0 	ret
    5e38:	72003c3f 	tst	w1, #0xffff
    5e3c:	54fffe60 	b.eq	5e08 <fwp_drop1+0x78>  // b.none
    5e40:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e44:	f94013f5 	ldr	x21, [sp, #32]
    5e48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e4c:	d65f03c0 	ret
    5e50:	f9400813 	ldr	x19, [x0, #16]
    5e54:	97fffefb 	bl	5a40 <fwp_rc_free_arr>
    5e58:	911742a0 	add	x0, x21, #0x5d0
    5e5c:	f949d801 	ldr	x1, [x0, #5040]
    5e60:	f949ec00 	ldr	x0, [x0, #5080]
    5e64:	cb010261 	sub	x1, x19, x1
    5e68:	eb00403f 	cmp	x1, x0, lsl #16
    5e6c:	54fffde2 	b.cs	5e28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e70:	aa1303e0 	mov	x0, x19
    5e74:	17ffffd2 	b	5dbc <fwp_drop1+0x2c>
    5e78:	ca534660 	eor	x0, x19, x19, lsr #17
    5e7c:	911742b5 	add	x21, x21, #0x5d0
    5e80:	ca402400 	eor	x0, x0, x0, lsr #9
    5e84:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e88:	f94a2400 	ldr	x0, [x0, #5192]
    5e8c:	b5000080 	cbnz	x0, 5e9c <fwp_drop1+0x10c>
    5e90:	14000010 	b	5ed0 <fwp_drop1+0x140>
    5e94:	f9400800 	ldr	x0, [x0, #16]
    5e98:	b40001c0 	cbz	x0, 5ed0 <fwp_drop1+0x140>
    5e9c:	f9400001 	ldr	x1, [x0]
    5ea0:	eb13003f 	cmp	x1, x19
    5ea4:	54ffff81 	b.ne	5e94 <fwp_drop1+0x104>  // b.any
    5ea8:	f9400401 	ldr	x1, [x0, #8]
    5eac:	d1000421 	sub	x1, x1, #0x1
    5eb0:	f9000401 	str	x1, [x0, #8]
    5eb4:	f103f83f 	cmp	x1, #0xfe
    5eb8:	54fffb81 	b.ne	5e28 <fwp_drop1+0x98>  // b.any
    5ebc:	aa1303e0 	mov	x0, x19
    5ec0:	97fffa4c 	bl	47f0 <fwp_rc_forget_slot>
    5ec4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ec8:	39000260 	strb	w0, [x19]
    5ecc:	17ffffd7 	b	5e28 <fwp_drop1+0x98>
    5ed0:	90000040 	adrp	x0, d000 <__divti3+0x1b0>
    5ed4:	91234000 	add	x0, x0, #0x8d0
    5ed8:	97fff64a 	bl	3800 <fwp_trap>
    5edc:	d503201f 	nop

0000000000005ee0 <fwp_drop0>:
    5ee0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ee4:	910003fd 	mov	x29, sp
    5ee8:	a90153f3 	stp	x19, x20, [sp, #16]
    5eec:	f90013f5 	str	x21, [sp, #32]
    5ef0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5ef4:	911742b4 	add	x20, x21, #0x5d0
    5ef8:	f949da81 	ldr	x1, [x20, #5040]
    5efc:	f949ee82 	ldr	x2, [x20, #5080]
    5f00:	cb010001 	sub	x1, x0, x1
    5f04:	eb02403f 	cmp	x1, x2, lsl #16
    5f08:	54000382 	b.cs	5f78 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f0c:	d350fc22 	lsr	x2, x1, #16
    5f10:	f949fe84 	ldr	x4, [x20, #5112]
    5f14:	8b020842 	add	x2, x2, x2, lsl #2
    5f18:	d37df042 	lsl	x2, x2, #3
    5f1c:	8b020083 	add	x3, x4, x2
    5f20:	f9401073 	ldr	x19, [x3, #32]
    5f24:	b40002b3 	cbz	x19, 5f78 <fwp_drop0+0x98>
    5f28:	38626882 	ldrb	w2, [x4, x2]
    5f2c:	7100085f 	cmp	w2, #0x2
    5f30:	540002c0 	b.eq	5f88 <fwp_drop0+0xa8>  // b.none
    5f34:	7100045f 	cmp	w2, #0x1
    5f38:	54000201 	b.ne	5f78 <fwp_drop0+0x98>  // b.any
    5f3c:	29430864 	ldp	w4, w2, [x3, #24]
    5f40:	92403c21 	and	x1, x1, #0xffff
    5f44:	9b047c21 	mul	x1, x1, x4
    5f48:	d360fc21 	lsr	x1, x1, #32
    5f4c:	eb02003f 	cmp	x1, x2
    5f50:	54000142 	b.cs	5f78 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f54:	8b010273 	add	x19, x19, x1
    5f58:	39400261 	ldrb	w1, [x19]
    5f5c:	340000e1 	cbz	w1, 5f78 <fwp_drop0+0x98>
    5f60:	7100043f 	cmp	w1, #0x1
    5f64:	540001e0 	b.eq	5fa0 <fwp_drop0+0xc0>  // b.none
    5f68:	7103fc3f 	cmp	w1, #0xff
    5f6c:	540002e0 	b.eq	5fc8 <fwp_drop0+0xe8>  // b.none
    5f70:	51000421 	sub	w1, w1, #0x1
    5f74:	39000261 	strb	w1, [x19]
    5f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f7c:	f94013f5 	ldr	x21, [sp, #32]
    5f80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f84:	d65f03c0 	ret
    5f88:	72003c3f 	tst	w1, #0xffff
    5f8c:	54fffe60 	b.eq	5f58 <fwp_drop0+0x78>  // b.none
    5f90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f94:	f94013f5 	ldr	x21, [sp, #32]
    5f98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f9c:	d65f03c0 	ret
    5fa0:	f9400813 	ldr	x19, [x0, #16]
    5fa4:	97fffea7 	bl	5a40 <fwp_rc_free_arr>
    5fa8:	911742a0 	add	x0, x21, #0x5d0
    5fac:	f949d801 	ldr	x1, [x0, #5040]
    5fb0:	f949ec00 	ldr	x0, [x0, #5080]
    5fb4:	cb010261 	sub	x1, x19, x1
    5fb8:	eb00403f 	cmp	x1, x0, lsl #16
    5fbc:	54fffde2 	b.cs	5f78 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fc0:	aa1303e0 	mov	x0, x19
    5fc4:	17ffffd2 	b	5f0c <fwp_drop0+0x2c>
    5fc8:	ca534660 	eor	x0, x19, x19, lsr #17
    5fcc:	911742b5 	add	x21, x21, #0x5d0
    5fd0:	ca402400 	eor	x0, x0, x0, lsr #9
    5fd4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5fd8:	f94a2400 	ldr	x0, [x0, #5192]
    5fdc:	b5000080 	cbnz	x0, 5fec <fwp_drop0+0x10c>
    5fe0:	14000010 	b	6020 <fwp_drop0+0x140>
    5fe4:	f9400800 	ldr	x0, [x0, #16]
    5fe8:	b40001c0 	cbz	x0, 6020 <fwp_drop0+0x140>
    5fec:	f9400001 	ldr	x1, [x0]
    5ff0:	eb13003f 	cmp	x1, x19
    5ff4:	54ffff81 	b.ne	5fe4 <fwp_drop0+0x104>  // b.any
    5ff8:	f9400401 	ldr	x1, [x0, #8]
    5ffc:	d1000421 	sub	x1, x1, #0x1
    6000:	f9000401 	str	x1, [x0, #8]
    6004:	f103f83f 	cmp	x1, #0xfe
    6008:	54fffb81 	b.ne	5f78 <fwp_drop0+0x98>  // b.any
    600c:	aa1303e0 	mov	x0, x19
    6010:	97fff9f8 	bl	47f0 <fwp_rc_forget_slot>
    6014:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6018:	39000260 	strb	w0, [x19]
    601c:	17ffffd7 	b	5f78 <fwp_drop0+0x98>
    6020:	f0000020 	adrp	x0, d000 <__divti3+0x1b0>
    6024:	91234000 	add	x0, x0, #0x8d0
    6028:	97fff5f6 	bl	3800 <fwp_trap>
    602c:	d503201f 	nop

0000000000006030 <fwp_arg_drop12>:
    6030:	7100003f 	cmp	w1, #0x0
    6034:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6038:	54000041 	b.ne	6040 <fwp_arg_drop12+0x10>  // b.any
    603c:	d65f03c0 	ret
    6040:	f9400000 	ldr	x0, [x0]
    6044:	17ffffa7 	b	5ee0 <fwp_drop0>
    6048:	d503201f 	nop
    604c:	d503201f 	nop

0000000000006050 <fwp_closure_drop>:
    6050:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    6054:	911740a4 	add	x4, x5, #0x5d0
    6058:	aa0003e1 	mov	x1, x0
    605c:	f949d882 	ldr	x2, [x4, #5040]
    6060:	f949ec80 	ldr	x0, [x4, #5080]
    6064:	cb020022 	sub	x2, x1, x2
    6068:	eb00405f 	cmp	x2, x0, lsl #16
    606c:	54000662 	b.cs	6138 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6074:	d350fc43 	lsr	x3, x2, #16
    6078:	910003fd 	mov	x29, sp
    607c:	8b030863 	add	x3, x3, x3, lsl #2
    6080:	f949fc84 	ldr	x4, [x4, #5112]
    6084:	d37df063 	lsl	x3, x3, #3
    6088:	f9000bf3 	str	x19, [sp, #16]
    608c:	8b030080 	add	x0, x4, x3
    6090:	f9401013 	ldr	x19, [x0, #32]
    6094:	b40002b3 	cbz	x19, 60e8 <fwp_closure_drop+0x98>
    6098:	38636883 	ldrb	w3, [x4, x3]
    609c:	7100087f 	cmp	w3, #0x2
    60a0:	54000420 	b.eq	6124 <fwp_closure_drop+0xd4>  // b.none
    60a4:	7100047f 	cmp	w3, #0x1
    60a8:	54000201 	b.ne	60e8 <fwp_closure_drop+0x98>  // b.any
    60ac:	29430003 	ldp	w3, w0, [x0, #24]
    60b0:	92403c42 	and	x2, x2, #0xffff
    60b4:	9b037c42 	mul	x2, x2, x3
    60b8:	d360fc42 	lsr	x2, x2, #32
    60bc:	eb00005f 	cmp	x2, x0
    60c0:	54000142 	b.cs	60e8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    60c4:	8b020273 	add	x19, x19, x2
    60c8:	39400260 	ldrb	w0, [x19]
    60cc:	340000e0 	cbz	w0, 60e8 <fwp_closure_drop+0x98>
    60d0:	7100041f 	cmp	w0, #0x1
    60d4:	54000100 	b.eq	60f4 <fwp_closure_drop+0xa4>  // b.none
    60d8:	7103fc1f 	cmp	w0, #0xff
    60dc:	54000300 	b.eq	613c <fwp_closure_drop+0xec>  // b.none
    60e0:	51000400 	sub	w0, w0, #0x1
    60e4:	39000260 	strb	w0, [x19]
    60e8:	f9400bf3 	ldr	x19, [sp, #16]
    60ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60f0:	d65f03c0 	ret
    60f4:	d53bd040 	mrs	x0, tpidr_el0
    60f8:	91400000 	add	x0, x0, #0x0, lsl #12
    60fc:	91004000 	add	x0, x0, #0x10
    6100:	f9400000 	ldr	x0, [x0]
    6104:	b4000080 	cbz	x0, 6114 <fwp_closure_drop+0xc4>
    6108:	f9400bf3 	ldr	x19, [sp, #16]
    610c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6110:	17fff5d5 	b	3864 <fwp_closure_drop_push>
    6114:	f9400bf3 	ldr	x19, [sp, #16]
    6118:	aa0103e0 	mov	x0, x1
    611c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6120:	17fff640 	b	3a20 <fwp_closure_drop.part.0>
    6124:	72003c5f 	tst	w2, #0xffff
    6128:	54fffd00 	b.eq	60c8 <fwp_closure_drop+0x78>  // b.none
    612c:	f9400bf3 	ldr	x19, [sp, #16]
    6130:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6134:	d65f03c0 	ret
    6138:	d65f03c0 	ret
    613c:	ca534660 	eor	x0, x19, x19, lsr #17
    6140:	911740a5 	add	x5, x5, #0x5d0
    6144:	ca402400 	eor	x0, x0, x0, lsr #9
    6148:	8b200ca0 	add	x0, x5, w0, uxtb #3
    614c:	f94a2400 	ldr	x0, [x0, #5192]
    6150:	b5000080 	cbnz	x0, 6160 <fwp_closure_drop+0x110>
    6154:	14000010 	b	6194 <fwp_closure_drop+0x144>
    6158:	f9400800 	ldr	x0, [x0, #16]
    615c:	b40001c0 	cbz	x0, 6194 <fwp_closure_drop+0x144>
    6160:	f9400001 	ldr	x1, [x0]
    6164:	eb13003f 	cmp	x1, x19
    6168:	54ffff81 	b.ne	6158 <fwp_closure_drop+0x108>  // b.any
    616c:	f9400401 	ldr	x1, [x0, #8]
    6170:	d1000421 	sub	x1, x1, #0x1
    6174:	f9000401 	str	x1, [x0, #8]
    6178:	f103f83f 	cmp	x1, #0xfe
    617c:	54fffb61 	b.ne	60e8 <fwp_closure_drop+0x98>  // b.any
    6180:	aa1303e0 	mov	x0, x19
    6184:	97fff99b 	bl	47f0 <fwp_rc_forget_slot>
    6188:	12800020 	mov	w0, #0xfffffffe            	// #-2
    618c:	39000260 	strb	w0, [x19]
    6190:	17ffffd6 	b	60e8 <fwp_closure_drop+0x98>
    6194:	f0000020 	adrp	x0, d000 <__divti3+0x1b0>
    6198:	91234000 	add	x0, x0, #0x8d0
    619c:	97fff599 	bl	3800 <fwp_trap>

00000000000061a0 <fwp_owned_tape_release>:
    61a0:	b4000940 	cbz	x0, 62c8 <fwp_owned_tape_release+0x128>
    61a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    61a8:	910003fd 	mov	x29, sp
    61ac:	a90153f3 	stp	x19, x20, [sp, #16]
    61b0:	aa0003f3 	mov	x19, x0
    61b4:	f9400000 	ldr	x0, [x0]
    61b8:	b4000060 	cbz	x0, 61c4 <fwp_owned_tape_release+0x24>
    61bc:	f9400661 	ldr	x1, [x19, #8]
    61c0:	f9000401 	str	x1, [x0, #8]
    61c4:	f9400661 	ldr	x1, [x19, #8]
    61c8:	b4000041 	cbz	x1, 61d0 <fwp_owned_tape_release+0x30>
    61cc:	f9000020 	str	x0, [x1]
    61d0:	f9400a60 	ldr	x0, [x19, #16]
    61d4:	f9403401 	ldr	x1, [x0, #104]
    61d8:	b40005c1 	cbz	x1, 6290 <fwp_owned_tape_release+0xf0>
    61dc:	a9450a60 	ldp	x0, x2, [x19, #80]
    61e0:	eb00005f 	cmp	x2, x0
    61e4:	540002ed 	b.le	6240 <fwp_owned_tape_release+0xa0>
    61e8:	d2800014 	mov	x20, #0x0                   	// #0
    61ec:	f90013f5 	str	x21, [sp, #32]
    61f0:	d2800015 	mov	x21, #0x0                   	// #0
    61f4:	d503201f 	nop
    61f8:	f9402260 	ldr	x0, [x19, #64]
    61fc:	910006b5 	add	x21, x21, #0x1
    6200:	f8746800 	ldr	x0, [x0, x20]
    6204:	d63f0020 	blr	x1
    6208:	f9402260 	ldr	x0, [x19, #64]
    620c:	f9400a61 	ldr	x1, [x19, #16]
    6210:	8b140000 	add	x0, x0, x20
    6214:	91004294 	add	x20, x20, #0x10
    6218:	f9400400 	ldr	x0, [x0, #8]
    621c:	f9403421 	ldr	x1, [x1, #104]
    6220:	d63f0020 	blr	x1
    6224:	a9450261 	ldp	x1, x0, [x19, #80]
    6228:	cb010000 	sub	x0, x0, x1
    622c:	eb15001f 	cmp	x0, x21
    6230:	f9400a60 	ldr	x0, [x19, #16]
    6234:	f9403401 	ldr	x1, [x0, #104]
    6238:	54fffe0c 	b.gt	61f8 <fwp_owned_tape_release+0x58>
    623c:	f94013f5 	ldr	x21, [sp, #32]
    6240:	f9403663 	ldr	x3, [x19, #104]
    6244:	f9401262 	ldr	x2, [x19, #32]
    6248:	f100007f 	cmp	x3, #0x0
    624c:	540001ed 	b.le	6288 <fwp_owned_tape_release+0xe8>
    6250:	d2800014 	mov	x20, #0x0                   	// #0
    6254:	d503201f 	nop
    6258:	f9402660 	ldr	x0, [x19, #72]
    625c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6260:	eb02001f 	cmp	x0, x2
    6264:	540000c0 	b.eq	627c <fwp_owned_tape_release+0xdc>  // b.none
    6268:	d63f0020 	blr	x1
    626c:	f9400a60 	ldr	x0, [x19, #16]
    6270:	f9401262 	ldr	x2, [x19, #32]
    6274:	f9403663 	ldr	x3, [x19, #104]
    6278:	f9403401 	ldr	x1, [x0, #104]
    627c:	91000694 	add	x20, x20, #0x1
    6280:	eb14007f 	cmp	x3, x20
    6284:	54fffeac 	b.gt	6258 <fwp_owned_tape_release+0xb8>
    6288:	aa0203e0 	mov	x0, x2
    628c:	d63f0020 	blr	x1
    6290:	f9401660 	ldr	x0, [x19, #40]
    6294:	97ffff6f 	bl	6050 <fwp_closure_drop>
    6298:	f9401a60 	ldr	x0, [x19, #48]
    629c:	97ffff6d 	bl	6050 <fwp_closure_drop>
    62a0:	f9401e60 	ldr	x0, [x19, #56]
    62a4:	97ffff6b 	bl	6050 <fwp_closure_drop>
    62a8:	f9402260 	ldr	x0, [x19, #64]
    62ac:	97fff9f1 	bl	4a70 <fwp_mem_free>
    62b0:	f9402660 	ldr	x0, [x19, #72]
    62b4:	97fff9ef 	bl	4a70 <fwp_mem_free>
    62b8:	aa1303e0 	mov	x0, x19
    62bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62c4:	17fff9eb 	b	4a70 <fwp_mem_free>
    62c8:	d65f03c0 	ret
    62cc:	d503201f 	nop

00000000000062d0 <fwp_tape_finish>:
    62d0:	d10203ff 	sub	sp, sp, #0x80
    62d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    62d8:	f947f421 	ldr	x1, [x1, #4072]
    62dc:	a9047bfd 	stp	x29, x30, [sp, #64]
    62e0:	910103fd 	add	x29, sp, #0x40
    62e4:	a90553f3 	stp	x19, x20, [sp, #80]
    62e8:	a9065bf5 	stp	x21, x22, [sp, #96]
    62ec:	a90763f7 	stp	x23, x24, [sp, #112]
    62f0:	d00000d8 	adrp	x24, 20000 <__data_start>
    62f4:	9101c316 	add	x22, x24, #0x70
    62f8:	f9400022 	ldr	x2, [x1]
    62fc:	f9001fe2 	str	x2, [sp, #56]
    6300:	d2800002 	mov	x2, #0x0                   	// #0
    6304:	910262c0 	add	x0, x22, #0x98
    6308:	97fff45e 	bl	3480 <fwp_tape_buffers_dispose>
    630c:	f9006adf 	str	xzr, [x22, #208]
    6310:	f9404ac0 	ldr	x0, [x22, #144]
    6314:	f100001f 	cmp	x0, #0x0
    6318:	5400030d 	b.le	6378 <fwp_tape_finish+0xa8>
    631c:	910003f7 	mov	x23, sp
    6320:	d2800015 	mov	x21, #0x0                   	// #0
    6324:	d2800014 	mov	x20, #0x0                   	// #0
    6328:	f94002d3 	ldr	x19, [x22]
    632c:	91000694 	add	x20, x20, #0x1
    6330:	8b150273 	add	x19, x19, x21
    6334:	9101a2b5 	add	x21, x21, #0x68
    6338:	aa1303e0 	mov	x0, x19
    633c:	97fff315 	bl	2f90 <fwp_tape_unlink_scope>
    6340:	aa1703e0 	mov	x0, x23
    6344:	f9401261 	ldr	x1, [x19, #32]
    6348:	f90003e1 	str	x1, [sp]
    634c:	f9401a62 	ldr	x2, [x19, #48]
    6350:	f9000be2 	str	x2, [sp, #16]
    6354:	f9402261 	ldr	x1, [x19, #64]
    6358:	f90013e1 	str	x1, [sp, #32]
    635c:	97fff449 	bl	3480 <fwp_tape_buffers_dispose>
    6360:	f9403260 	ldr	x0, [x19, #96]
    6364:	97ffff8f 	bl	61a0 <fwp_owned_tape_release>
    6368:	f900327f 	str	xzr, [x19, #96]
    636c:	f9404ac0 	ldr	x0, [x22, #144]
    6370:	eb14001f 	cmp	x0, x20
    6374:	54fffdac 	b.gt	6328 <fwp_tape_finish+0x58>
    6378:	f9403b00 	ldr	x0, [x24, #112]
    637c:	9101c313 	add	x19, x24, #0x70
    6380:	97fff170 	bl	2940 <free@plt>
    6384:	f9003b1f 	str	xzr, [x24, #112]
    6388:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    638c:	f947f400 	ldr	x0, [x0, #4072]
    6390:	f9004a7f 	str	xzr, [x19, #144]
    6394:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6398:	f9401fe2 	ldr	x2, [sp, #56]
    639c:	f9400001 	ldr	x1, [x0]
    63a0:	eb010042 	subs	x2, x2, x1
    63a4:	d2800001 	mov	x1, #0x0                   	// #0
    63a8:	540000e1 	b.ne	63c4 <fwp_tape_finish+0xf4>  // b.any
    63ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    63b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    63bc:	910203ff 	add	sp, sp, #0x80
    63c0:	d65f03c0 	ret
    63c4:	97fff12f 	bl	2880 <__stack_chk_fail@plt>
    63c8:	d503201f 	nop
    63cc:	d503201f 	nop

00000000000063d0 <fwp_tape_scope_release>:
    63d0:	d10243ff 	sub	sp, sp, #0x90
    63d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    63d8:	910103fd 	add	x29, sp, #0x40
    63dc:	a90553f3 	stp	x19, x20, [sp, #80]
    63e0:	aa0003f4 	mov	x20, x0
    63e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    63e8:	f947f400 	ldr	x0, [x0, #4072]
    63ec:	b9400285 	ldr	w5, [x20]
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	f9001fe1 	str	x1, [sp, #56]
    63f8:	d2800001 	mov	x1, #0x0                   	// #0
    63fc:	37f806c5 	tbnz	w5, #31, 64d4 <fwp_tape_scope_release+0x104>
    6400:	a90763f7 	stp	x23, x24, [sp, #112]
    6404:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6408:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    640c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6410:	d00000d3 	adrp	x19, 20000 <__data_start>
    6414:	910003f7 	mov	x23, sp
    6418:	9101c273 	add	x19, x19, #0x70
    641c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6420:	a9065bf5 	stp	x21, x22, [sp, #96]
    6424:	52800d16 	mov	w22, #0x68                  	// #104
    6428:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    642c:	f90043f9 	str	x25, [sp, #128]
    6430:	14000006 	b	6448 <fwp_tape_scope_release+0x78>
    6434:	97fff413 	bl	3480 <fwp_tape_buffers_dispose>
    6438:	aa1903e0 	mov	x0, x25
    643c:	97ffff59 	bl	61a0 <fwp_owned_tape_release>
    6440:	b9400285 	ldr	w5, [x20]
    6444:	37f80425 	tbnz	w5, #31, 64c8 <fwp_tape_scope_release+0xf8>
    6448:	f9400266 	ldr	x6, [x19]
    644c:	9b367ca5 	smull	x5, w5, w22
    6450:	8b0500c0 	add	x0, x6, x5
    6454:	97fff2cf 	bl	2f90 <fwp_tape_unlink_scope>
    6458:	ad410001 	ldp	q1, q0, [x0, #32]
    645c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6460:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6464:	f9400c03 	ldr	x3, [x0, #24]
    6468:	ad0003e1 	stp	q1, q0, [sp]
    646c:	b86568c1 	ldr	w1, [x6, x5]
    6470:	a9440804 	ldp	x4, x2, [x0, #64]
    6474:	b900041f 	str	wzr, [x0, #4]
    6478:	f9403019 	ldr	x25, [x0, #96]
    647c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6480:	f9000c1f 	str	xzr, [x0, #24]
    6484:	a9020fe4 	stp	x4, x3, [sp, #32]
    6488:	f9001be2 	str	x2, [sp, #48]
    648c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6490:	f900301f 	str	xzr, [x0, #96]
    6494:	6b15003f 	cmp	w1, w21
    6498:	540000e8 	b.hi	64b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    649c:	9343fca5 	asr	x5, x5, #3
    64a0:	f9407660 	ldr	x0, [x19, #232]
    64a4:	9b187ca5 	mul	x5, x5, x24
    64a8:	eb0000bf 	cmp	x5, x0
    64ac:	5400004a 	b.ge	64b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    64b0:	f9007665 	str	x5, [x19, #232]
    64b4:	aa1703e0 	mov	x0, x23
    64b8:	b5fffbf9 	cbnz	x25, 6434 <fwp_tape_scope_release+0x64>
    64bc:	97fff7b1 	bl	4380 <fwp_tape_buffers_release>
    64c0:	b9400285 	ldr	w5, [x20]
    64c4:	36fffc25 	tbz	w5, #31, 6448 <fwp_tape_scope_release+0x78>
    64c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    64cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    64d0:	f94043f9 	ldr	x25, [sp, #128]
    64d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    64d8:	f947f400 	ldr	x0, [x0, #4072]
    64dc:	f9401fe2 	ldr	x2, [sp, #56]
    64e0:	f9400001 	ldr	x1, [x0]
    64e4:	eb010042 	subs	x2, x2, x1
    64e8:	d2800001 	mov	x1, #0x0                   	// #0
    64ec:	540000a1 	b.ne	6500 <fwp_tape_scope_release+0x130>  // b.any
    64f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    64f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    64f8:	910243ff 	add	sp, sp, #0x90
    64fc:	d65f03c0 	ret
    6500:	a9065bf5 	stp	x21, x22, [sp, #96]
    6504:	a90763f7 	stp	x23, x24, [sp, #112]
    6508:	f90043f9 	str	x25, [sp, #128]
    650c:	97fff0dd 	bl	2880 <__stack_chk_fail@plt>

0000000000006510 <fwp_task_dispose>:
    6510:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6514:	910003fd 	mov	x29, sp
    6518:	f9000bf3 	str	x19, [sp, #16]
    651c:	aa0003f3 	mov	x19, x0
    6520:	39414000 	ldrb	w0, [x0, #80]
    6524:	36000720 	tbz	w0, #0, 6608 <fwp_task_dispose+0xf8>
    6528:	f9400a60 	ldr	x0, [x19, #16]
    652c:	b50006e0 	cbnz	x0, 6608 <fwp_task_dispose+0xf8>
    6530:	a9478660 	ldp	x0, x1, [x19, #120]
    6534:	39014e7f 	strb	wzr, [x19, #83]
    6538:	f9003e7f 	str	xzr, [x19, #120]
    653c:	f100003f 	cmp	x1, #0x0
    6540:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6544:	54000040 	b.eq	654c <fwp_task_dispose+0x3c>  // b.none
    6548:	d63f0020 	blr	x1
    654c:	f9405660 	ldr	x0, [x19, #168]
    6550:	97fff948 	bl	4a70 <fwp_mem_free>
    6554:	f900567f 	str	xzr, [x19, #168]
    6558:	b9405e60 	ldr	w0, [x19, #92]
    655c:	7100041f 	cmp	w0, #0x1
    6560:	54000420 	b.eq	65e4 <fwp_task_dispose+0xd4>  // b.none
    6564:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6568:	91174042 	add	x2, x2, #0x5d0
    656c:	f949d840 	ldr	x0, [x2, #5040]
    6570:	f949ec41 	ldr	x1, [x2, #5080]
    6574:	cb000260 	sub	x0, x19, x0
    6578:	eb01401f 	cmp	x0, x1, lsl #16
    657c:	540002e2 	b.cs	65d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6580:	d350fc01 	lsr	x1, x0, #16
    6584:	f949fc44 	ldr	x4, [x2, #5112]
    6588:	8b010821 	add	x1, x1, x1, lsl #2
    658c:	d37df021 	lsl	x1, x1, #3
    6590:	8b010083 	add	x3, x4, x1
    6594:	f9401062 	ldr	x2, [x3, #32]
    6598:	b4000202 	cbz	x2, 65d8 <fwp_task_dispose+0xc8>
    659c:	38616881 	ldrb	w1, [x4, x1]
    65a0:	7100083f 	cmp	w1, #0x2
    65a4:	54000280 	b.eq	65f4 <fwp_task_dispose+0xe4>  // b.none
    65a8:	7100043f 	cmp	w1, #0x1
    65ac:	54000161 	b.ne	65d8 <fwp_task_dispose+0xc8>  // b.any
    65b0:	29430464 	ldp	w4, w1, [x3, #24]
    65b4:	92403c00 	and	x0, x0, #0xffff
    65b8:	9b047c00 	mul	x0, x0, x4
    65bc:	d360fc00 	lsr	x0, x0, #32
    65c0:	eb01001f 	cmp	x0, x1
    65c4:	540000a2 	b.cs	65d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65c8:	8b000042 	add	x2, x2, x0
    65cc:	39400040 	ldrb	w0, [x2]
    65d0:	7100041f 	cmp	w0, #0x1
    65d4:	54000080 	b.eq	65e4 <fwp_task_dispose+0xd4>  // b.none
    65d8:	f9400bf3 	ldr	x19, [sp, #16]
    65dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65e0:	d65f03c0 	ret
    65e4:	aa1303e0 	mov	x0, x19
    65e8:	f9400bf3 	ldr	x19, [sp, #16]
    65ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65f0:	17fff920 	b	4a70 <fwp_mem_free>
    65f4:	72003c1f 	tst	w0, #0xffff
    65f8:	54fffea0 	b.eq	65cc <fwp_task_dispose+0xbc>  // b.none
    65fc:	f9400bf3 	ldr	x19, [sp, #16]
    6600:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6604:	d65f03c0 	ret
    6608:	97fff0b2 	bl	28d0 <abort@plt>
    660c:	d503201f 	nop

0000000000006610 <fwp_free_zombie>:
    6610:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6614:	910003fd 	mov	x29, sp
    6618:	a90153f3 	stp	x19, x20, [sp, #16]
    661c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6620:	9101c281 	add	x1, x20, #0x70
    6624:	f9407833 	ldr	x19, [x1, #240]
    6628:	b4000333 	cbz	x19, 668c <fwp_free_zombie+0x7c>
    662c:	f9400820 	ldr	x0, [x1, #16]
    6630:	eb00027f 	cmp	x19, x0
    6634:	540002c0 	b.eq	668c <fwp_free_zombie+0x7c>  // b.none
    6638:	b940f822 	ldr	w2, [x1, #248]
    663c:	f9400a60 	ldr	x0, [x19, #16]
    6640:	7100fc5f 	cmp	w2, #0x3f
    6644:	5400078c 	b.gt	6734 <fwp_free_zombie+0x124>
    6648:	91040023 	add	x3, x1, #0x100
    664c:	11000444 	add	w4, w2, #0x1
    6650:	b900f824 	str	w4, [x1, #248]
    6654:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6658:	f822d860 	str	x0, [x3, w2, sxtw #3]
    665c:	a9530261 	ldp	x1, x0, [x19, #304]
    6660:	b4000741 	cbz	x1, 6748 <fwp_free_zombie+0x138>
    6664:	f9009c20 	str	x0, [x1, #312]
    6668:	b4000040 	cbz	x0, 6670 <fwp_free_zombie+0x60>
    666c:	f9009801 	str	x1, [x0, #304]
    6670:	9101c294 	add	x20, x20, #0x70
    6674:	b9405e60 	ldr	w0, [x19, #92]
    6678:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    667c:	f9007a9f 	str	xzr, [x20, #240]
    6680:	34000140 	cbz	w0, 66a8 <fwp_free_zombie+0x98>
    6684:	7100041f 	cmp	w0, #0x1
    6688:	54000080 	b.eq	6698 <fwp_free_zombie+0x88>  // b.none
    668c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6690:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6694:	d65f03c0 	ret
    6698:	aa1303e0 	mov	x0, x19
    669c:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66a4:	17ffff9b 	b	6510 <fwp_task_dispose>
    66a8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    66ac:	91174082 	add	x2, x4, #0x5d0
    66b0:	f949d841 	ldr	x1, [x2, #5040]
    66b4:	f949ec40 	ldr	x0, [x2, #5080]
    66b8:	cb010261 	sub	x1, x19, x1
    66bc:	eb00403f 	cmp	x1, x0, lsl #16
    66c0:	54fffe62 	b.cs	668c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    66c4:	d350fc20 	lsr	x0, x1, #16
    66c8:	f949fc43 	ldr	x3, [x2, #5112]
    66cc:	8b000800 	add	x0, x0, x0, lsl #2
    66d0:	d37df000 	lsl	x0, x0, #3
    66d4:	8b000062 	add	x2, x3, x0
    66d8:	f9401054 	ldr	x20, [x2, #32]
    66dc:	b4fffd94 	cbz	x20, 668c <fwp_free_zombie+0x7c>
    66e0:	38606860 	ldrb	w0, [x3, x0]
    66e4:	7100081f 	cmp	w0, #0x2
    66e8:	54000360 	b.eq	6754 <fwp_free_zombie+0x144>  // b.none
    66ec:	7100041f 	cmp	w0, #0x1
    66f0:	54fffce1 	b.ne	668c <fwp_free_zombie+0x7c>  // b.any
    66f4:	29430043 	ldp	w3, w0, [x2, #24]
    66f8:	92403c21 	and	x1, x1, #0xffff
    66fc:	9b037c21 	mul	x1, x1, x3
    6700:	d360fc21 	lsr	x1, x1, #32
    6704:	eb00003f 	cmp	x1, x0
    6708:	54fffc22 	b.cs	668c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    670c:	8b010294 	add	x20, x20, x1
    6710:	39400280 	ldrb	w0, [x20]
    6714:	34fffbc0 	cbz	w0, 668c <fwp_free_zombie+0x7c>
    6718:	7100041f 	cmp	w0, #0x1
    671c:	54fffbe0 	b.eq	6698 <fwp_free_zombie+0x88>  // b.none
    6720:	7103fc1f 	cmp	w0, #0xff
    6724:	540001e0 	b.eq	6760 <fwp_free_zombie+0x150>  // b.none
    6728:	51000400 	sub	w0, w0, #0x1
    672c:	39000280 	strb	w0, [x20]
    6730:	17ffffd7 	b	668c <fwp_free_zombie+0x7c>
    6734:	f9400e61 	ldr	x1, [x19, #24]
    6738:	97fff09a 	bl	29a0 <munmap@plt>
    673c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6740:	a9530261 	ldp	x1, x0, [x19, #304]
    6744:	b5fff901 	cbnz	x1, 6664 <fwp_free_zombie+0x54>
    6748:	9101c282 	add	x2, x20, #0x70
    674c:	f9018040 	str	x0, [x2, #768]
    6750:	17ffffc6 	b	6668 <fwp_free_zombie+0x58>
    6754:	72003c3f 	tst	w1, #0xffff
    6758:	54fff9a1 	b.ne	668c <fwp_free_zombie+0x7c>  // b.any
    675c:	17ffffed 	b	6710 <fwp_free_zombie+0x100>
    6760:	ca544680 	eor	x0, x20, x20, lsr #17
    6764:	91174084 	add	x4, x4, #0x5d0
    6768:	ca402400 	eor	x0, x0, x0, lsr #9
    676c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6770:	f94a2400 	ldr	x0, [x0, #5192]
    6774:	b5000080 	cbnz	x0, 6784 <fwp_free_zombie+0x174>
    6778:	14000010 	b	67b8 <fwp_free_zombie+0x1a8>
    677c:	f9400800 	ldr	x0, [x0, #16]
    6780:	b40001c0 	cbz	x0, 67b8 <fwp_free_zombie+0x1a8>
    6784:	f9400001 	ldr	x1, [x0]
    6788:	eb14003f 	cmp	x1, x20
    678c:	54ffff81 	b.ne	677c <fwp_free_zombie+0x16c>  // b.any
    6790:	f9400401 	ldr	x1, [x0, #8]
    6794:	d1000421 	sub	x1, x1, #0x1
    6798:	f9000401 	str	x1, [x0, #8]
    679c:	f103f83f 	cmp	x1, #0xfe
    67a0:	54fff761 	b.ne	668c <fwp_free_zombie+0x7c>  // b.any
    67a4:	aa1403e0 	mov	x0, x20
    67a8:	97fff812 	bl	47f0 <fwp_rc_forget_slot>
    67ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67b0:	39000280 	strb	w0, [x20]
    67b4:	17ffffb6 	b	668c <fwp_free_zombie+0x7c>
    67b8:	f0000020 	adrp	x0, d000 <__divti3+0x1b0>
    67bc:	91234000 	add	x0, x0, #0x8d0
    67c0:	97fff410 	bl	3800 <fwp_trap>

00000000000067c4 <fwp_block>:
    67c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67c8:	910003fd 	mov	x29, sp
    67cc:	a90153f3 	stp	x19, x20, [sp, #16]
    67d0:	d00000d3 	adrp	x19, 20000 <__data_start>
    67d4:	9101c274 	add	x20, x19, #0x70
    67d8:	f9404282 	ldr	x2, [x20, #128]
    67dc:	b4000622 	cbz	x2, 68a0 <fwp_block+0xdc>
    67e0:	9101c261 	add	x1, x19, #0x70
    67e4:	f9408040 	ldr	x0, [x2, #256]
    67e8:	f9004020 	str	x0, [x1, #128]
    67ec:	b4000680 	cbz	x0, 68bc <fwp_block+0xf8>
    67f0:	9101c263 	add	x3, x19, #0x70
    67f4:	3901505f 	strb	wzr, [x2, #84]
    67f8:	f9400864 	ldr	x4, [x3, #16]
    67fc:	eb02009f 	cmp	x4, x2
    6800:	54000440 	b.eq	6888 <fwp_block+0xc4>  // b.none
    6804:	f9418465 	ldr	x5, [x3, #776]
    6808:	f9000862 	str	x2, [x3, #16]
    680c:	f9400441 	ldr	x1, [x2, #8]
    6810:	f9004885 	str	x5, [x4, #144]
    6814:	f9418865 	ldr	x5, [x3, #784]
    6818:	f9004c85 	str	x5, [x4, #152]
    681c:	f9418c65 	ldr	x5, [x3, #792]
    6820:	f9005085 	str	x5, [x4, #160]
    6824:	f9419065 	ldr	x5, [x3, #800]
    6828:	f9005485 	str	x5, [x4, #168]
    682c:	f9419465 	ldr	x5, [x3, #808]
    6830:	f9005885 	str	x5, [x4, #176]
    6834:	f9419865 	ldr	x5, [x3, #816]
    6838:	f9005c85 	str	x5, [x4, #184]
    683c:	f9419c65 	ldr	x5, [x3, #824]
    6840:	f9006085 	str	x5, [x4, #192]
    6844:	f9400480 	ldr	x0, [x4, #8]
    6848:	f9404844 	ldr	x4, [x2, #144]
    684c:	f9018464 	str	x4, [x3, #776]
    6850:	f9404c44 	ldr	x4, [x2, #152]
    6854:	f9018864 	str	x4, [x3, #784]
    6858:	f9405044 	ldr	x4, [x2, #160]
    685c:	f9018c64 	str	x4, [x3, #792]
    6860:	f9405444 	ldr	x4, [x2, #168]
    6864:	f9019064 	str	x4, [x3, #800]
    6868:	f9405844 	ldr	x4, [x2, #176]
    686c:	f9019464 	str	x4, [x3, #808]
    6870:	a94b8844 	ldp	x4, x2, [x2, #184]
    6874:	f9019864 	str	x4, [x3, #816]
    6878:	f9019c62 	str	x2, [x3, #824]
    687c:	97fff019 	bl	28e0 <swapcontext@plt>
    6880:	97ffff64 	bl	6610 <fwp_free_zombie>
    6884:	d503201f 	nop
    6888:	9101c260 	add	x0, x19, #0x70
    688c:	b9434000 	ldr	w0, [x0, #832]
    6890:	340001a0 	cbz	w0, 68c4 <fwp_block+0x100>
    6894:	a94153f3 	ldp	x19, x20, [sp, #16]
    6898:	a8c27bfd 	ldp	x29, x30, [sp], #32
    689c:	d65f03c0 	ret
    68a0:	97fff700 	bl	44a0 <fwp_poll_events>
    68a4:	f9404282 	ldr	x2, [x20, #128]
    68a8:	b4ffffc2 	cbz	x2, 68a0 <fwp_block+0xdc>
    68ac:	9101c261 	add	x1, x19, #0x70
    68b0:	f9408040 	ldr	x0, [x2, #256]
    68b4:	f9004020 	str	x0, [x1, #128]
    68b8:	b5fff9c0 	cbnz	x0, 67f0 <fwp_block+0x2c>
    68bc:	f9003c3f 	str	xzr, [x1, #120]
    68c0:	17ffffcc 	b	67f0 <fwp_block+0x2c>
    68c4:	f0000020 	adrp	x0, d000 <__divti3+0x1b0>
    68c8:	91280000 	add	x0, x0, #0xa00
    68cc:	97fff051 	bl	2a10 <getenv@plt>
    68d0:	5284e202 	mov	w2, #0x2710                	// #10000
    68d4:	b4000060 	cbz	x0, 68e0 <fwp_block+0x11c>
    68d8:	39400001 	ldrb	w1, [x0]
    68dc:	350000c1 	cbnz	w1, 68f4 <fwp_block+0x130>
    68e0:	9101c273 	add	x19, x19, #0x70
    68e4:	b9034262 	str	w2, [x19, #832]
    68e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    68ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68f0:	d65f03c0 	ret
    68f4:	52800142 	mov	w2, #0xa                   	// #10
    68f8:	d2800001 	mov	x1, #0x0                   	// #0
    68fc:	97ffef95 	bl	2750 <strtoll@plt>
    6900:	d1000403 	sub	x3, x0, #0x1
    6904:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6908:	eb02007f 	cmp	x3, x2
    690c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6910:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6914:	17fffff3 	b	68e0 <fwp_block+0x11c>
    6918:	d503201f 	nop
    691c:	d503201f 	nop

0000000000006920 <fwp_drop4>:
    6920:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6924:	910003fd 	mov	x29, sp
    6928:	a90153f3 	stp	x19, x20, [sp, #16]
    692c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6930:	f90013f5 	str	x21, [sp, #32]
    6934:	91174275 	add	x21, x19, #0x5d0
    6938:	f949daa1 	ldr	x1, [x21, #5040]
    693c:	f949eea2 	ldr	x2, [x21, #5080]
    6940:	cb010001 	sub	x1, x0, x1
    6944:	eb02403f 	cmp	x1, x2, lsl #16
    6948:	54000382 	b.cs	69b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    694c:	d350fc22 	lsr	x2, x1, #16
    6950:	f949fea3 	ldr	x3, [x21, #5112]
    6954:	8b020842 	add	x2, x2, x2, lsl #2
    6958:	d37df042 	lsl	x2, x2, #3
    695c:	8b020064 	add	x4, x3, x2
    6960:	f9401094 	ldr	x20, [x4, #32]
    6964:	b40002b4 	cbz	x20, 69b8 <fwp_drop4+0x98>
    6968:	38626862 	ldrb	w2, [x3, x2]
    696c:	7100085f 	cmp	w2, #0x2
    6970:	540007a0 	b.eq	6a64 <fwp_drop4+0x144>  // b.none
    6974:	7100045f 	cmp	w2, #0x1
    6978:	54000201 	b.ne	69b8 <fwp_drop4+0x98>  // b.any
    697c:	29430885 	ldp	w5, w2, [x4, #24]
    6980:	92403c21 	and	x1, x1, #0xffff
    6984:	9b057c21 	mul	x1, x1, x5
    6988:	d360fc21 	lsr	x1, x1, #32
    698c:	eb02003f 	cmp	x1, x2
    6990:	54000142 	b.cs	69b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6994:	8b010294 	add	x20, x20, x1
    6998:	39400281 	ldrb	w1, [x20]
    699c:	340000e1 	cbz	w1, 69b8 <fwp_drop4+0x98>
    69a0:	7100043f 	cmp	w1, #0x1
    69a4:	54000120 	b.eq	69c8 <fwp_drop4+0xa8>  // b.none
    69a8:	7103fc3f 	cmp	w1, #0xff
    69ac:	540007c0 	b.eq	6aa4 <fwp_drop4+0x184>  // b.none
    69b0:	51000421 	sub	w1, w1, #0x1
    69b4:	39000281 	strb	w1, [x20]
    69b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69bc:	f94013f5 	ldr	x21, [sp, #32]
    69c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69c4:	d65f03c0 	ret
    69c8:	f9400001 	ldr	x1, [x0]
    69cc:	b7f80581 	tbnz	x1, #63, 6a7c <fwp_drop4+0x15c>
    69d0:	91174273 	add	x19, x19, #0x5d0
    69d4:	f949da61 	ldr	x1, [x19, #5040]
    69d8:	f949ee62 	ldr	x2, [x19, #5080]
    69dc:	cb010001 	sub	x1, x0, x1
    69e0:	eb02403f 	cmp	x1, x2, lsl #16
    69e4:	54fffea2 	b.cs	69b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    69e8:	d350fc22 	lsr	x2, x1, #16
    69ec:	8b020842 	add	x2, x2, x2, lsl #2
    69f0:	d37df042 	lsl	x2, x2, #3
    69f4:	8b020065 	add	x5, x3, x2
    69f8:	f94010a4 	ldr	x4, [x5, #32]
    69fc:	b4fffde4 	cbz	x4, 69b8 <fwp_drop4+0x98>
    6a00:	38626862 	ldrb	w2, [x3, x2]
    6a04:	7100085f 	cmp	w2, #0x2
    6a08:	54000220 	b.eq	6a4c <fwp_drop4+0x12c>  // b.none
    6a0c:	7100045f 	cmp	w2, #0x1
    6a10:	54fffd41 	b.ne	69b8 <fwp_drop4+0x98>  // b.any
    6a14:	294308a3 	ldp	w3, w2, [x5, #24]
    6a18:	92403c21 	and	x1, x1, #0xffff
    6a1c:	9b037c21 	mul	x1, x1, x3
    6a20:	d360fc21 	lsr	x1, x1, #32
    6a24:	eb02003f 	cmp	x1, x2
    6a28:	54fffc82 	b.cs	69b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a2c:	8b010084 	add	x4, x4, x1
    6a30:	39400081 	ldrb	w1, [x4]
    6a34:	7100043f 	cmp	w1, #0x1
    6a38:	54fffc01 	b.ne	69b8 <fwp_drop4+0x98>  // b.any
    6a3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a40:	f94013f5 	ldr	x21, [sp, #32]
    6a44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a48:	17fff80a 	b	4a70 <fwp_mem_free>
    6a4c:	72003c3f 	tst	w1, #0xffff
    6a50:	54ffff00 	b.eq	6a30 <fwp_drop4+0x110>  // b.none
    6a54:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a58:	f94013f5 	ldr	x21, [sp, #32]
    6a5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a60:	d65f03c0 	ret
    6a64:	72003c3f 	tst	w1, #0xffff
    6a68:	54fff980 	b.eq	6998 <fwp_drop4+0x78>  // b.none
    6a6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a70:	f94013f5 	ldr	x21, [sp, #32]
    6a74:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a78:	d65f03c0 	ret
    6a7c:	f9400414 	ldr	x20, [x0, #8]
    6a80:	97fffbf0 	bl	5a40 <fwp_rc_free_arr>
    6a84:	91174260 	add	x0, x19, #0x5d0
    6a88:	f949d801 	ldr	x1, [x0, #5040]
    6a8c:	f949ec00 	ldr	x0, [x0, #5080]
    6a90:	cb010281 	sub	x1, x20, x1
    6a94:	eb00403f 	cmp	x1, x0, lsl #16
    6a98:	54fff902 	b.cs	69b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a9c:	aa1403e0 	mov	x0, x20
    6aa0:	17ffffab 	b	694c <fwp_drop4+0x2c>
    6aa4:	ca544680 	eor	x0, x20, x20, lsr #17
    6aa8:	91174273 	add	x19, x19, #0x5d0
    6aac:	ca402400 	eor	x0, x0, x0, lsr #9
    6ab0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6ab4:	f94a2400 	ldr	x0, [x0, #5192]
    6ab8:	b5000080 	cbnz	x0, 6ac8 <fwp_drop4+0x1a8>
    6abc:	14000010 	b	6afc <fwp_drop4+0x1dc>
    6ac0:	f9400800 	ldr	x0, [x0, #16]
    6ac4:	b40001c0 	cbz	x0, 6afc <fwp_drop4+0x1dc>
    6ac8:	f9400001 	ldr	x1, [x0]
    6acc:	eb14003f 	cmp	x1, x20
    6ad0:	54ffff81 	b.ne	6ac0 <fwp_drop4+0x1a0>  // b.any
    6ad4:	f9400401 	ldr	x1, [x0, #8]
    6ad8:	d1000421 	sub	x1, x1, #0x1
    6adc:	f9000401 	str	x1, [x0, #8]
    6ae0:	f103f83f 	cmp	x1, #0xfe
    6ae4:	54fff6a1 	b.ne	69b8 <fwp_drop4+0x98>  // b.any
    6ae8:	aa1403e0 	mov	x0, x20
    6aec:	97fff741 	bl	47f0 <fwp_rc_forget_slot>
    6af0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6af4:	39000280 	strb	w0, [x20]
    6af8:	17ffffb0 	b	69b8 <fwp_drop4+0x98>
    6afc:	f0000020 	adrp	x0, d000 <__divti3+0x1b0>
    6b00:	91234000 	add	x0, x0, #0x8d0
    6b04:	97fff33f 	bl	3800 <fwp_trap>
    6b08:	d503201f 	nop
    6b0c:	d503201f 	nop

0000000000006b10 <fwp_caps161>:
    6b10:	34000041 	cbz	w1, 6b18 <fwp_caps161+0x8>
    6b14:	d65f03c0 	ret
    6b18:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6b1c:	91174063 	add	x3, x3, #0x5d0
    6b20:	f949d861 	ldr	x1, [x3, #5040]
    6b24:	f949ec62 	ldr	x2, [x3, #5080]
    6b28:	cb010001 	sub	x1, x0, x1
    6b2c:	eb02403f 	cmp	x1, x2, lsl #16
    6b30:	54ffff22 	b.cs	6b14 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b34:	d350fc22 	lsr	x2, x1, #16
    6b38:	f949fc65 	ldr	x5, [x3, #5112]
    6b3c:	8b020842 	add	x2, x2, x2, lsl #2
    6b40:	d37df042 	lsl	x2, x2, #3
    6b44:	8b0200a4 	add	x4, x5, x2
    6b48:	f9401083 	ldr	x3, [x4, #32]
    6b4c:	b4fffe43 	cbz	x3, 6b14 <fwp_caps161+0x4>
    6b50:	386268a2 	ldrb	w2, [x5, x2]
    6b54:	7100085f 	cmp	w2, #0x2
    6b58:	540001c0 	b.eq	6b90 <fwp_caps161+0x80>  // b.none
    6b5c:	7100045f 	cmp	w2, #0x1
    6b60:	54fffda1 	b.ne	6b14 <fwp_caps161+0x4>  // b.any
    6b64:	29430885 	ldp	w5, w2, [x4, #24]
    6b68:	92403c21 	and	x1, x1, #0xffff
    6b6c:	9b057c21 	mul	x1, x1, x5
    6b70:	d360fc21 	lsr	x1, x1, #32
    6b74:	eb02003f 	cmp	x1, x2
    6b78:	54fffce2 	b.cs	6b14 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b7c:	8b010063 	add	x3, x3, x1
    6b80:	39400061 	ldrb	w1, [x3]
    6b84:	7100043f 	cmp	w1, #0x1
    6b88:	54fffc61 	b.ne	6b14 <fwp_caps161+0x4>  // b.any
    6b8c:	17fff7b9 	b	4a70 <fwp_mem_free>
    6b90:	72003c3f 	tst	w1, #0xffff
    6b94:	54ffff60 	b.eq	6b80 <fwp_caps161+0x70>  // b.none
    6b98:	d65f03c0 	ret
    6b9c:	d503201f 	nop

0000000000006ba0 <fwp_args12>:
    6ba0:	7100003f 	cmp	w1, #0x0
    6ba4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ba8:	54000041 	b.ne	6bb0 <fwp_args12+0x10>  // b.any
    6bac:	d65f03c0 	ret
    6bb0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6bb4:	91174042 	add	x2, x2, #0x5d0
    6bb8:	f9400001 	ldr	x1, [x0]
    6bbc:	f949d843 	ldr	x3, [x2, #5040]
    6bc0:	f949ec40 	ldr	x0, [x2, #5080]
    6bc4:	cb030021 	sub	x1, x1, x3
    6bc8:	eb00403f 	cmp	x1, x0, lsl #16
    6bcc:	54ffff02 	b.cs	6bac <fwp_args12+0xc>  // b.hs, b.nlast
    6bd0:	d350fc20 	lsr	x0, x1, #16
    6bd4:	f949fc44 	ldr	x4, [x2, #5112]
    6bd8:	8b000800 	add	x0, x0, x0, lsl #2
    6bdc:	d37df002 	lsl	x2, x0, #3
    6be0:	8b020083 	add	x3, x4, x2
    6be4:	f9401060 	ldr	x0, [x3, #32]
    6be8:	b4fffe20 	cbz	x0, 6bac <fwp_args12+0xc>
    6bec:	38626882 	ldrb	w2, [x4, x2]
    6bf0:	7100085f 	cmp	w2, #0x2
    6bf4:	54000220 	b.eq	6c38 <fwp_args12+0x98>  // b.none
    6bf8:	7100045f 	cmp	w2, #0x1
    6bfc:	54fffd81 	b.ne	6bac <fwp_args12+0xc>  // b.any
    6c00:	29430864 	ldp	w4, w2, [x3, #24]
    6c04:	92403c21 	and	x1, x1, #0xffff
    6c08:	9b047c21 	mul	x1, x1, x4
    6c0c:	d360fc21 	lsr	x1, x1, #32
    6c10:	eb02003f 	cmp	x1, x2
    6c14:	54fffcc2 	b.cs	6bac <fwp_args12+0xc>  // b.hs, b.nlast
    6c18:	8b010000 	add	x0, x0, x1
    6c1c:	39400001 	ldrb	w1, [x0]
    6c20:	34fffc61 	cbz	w1, 6bac <fwp_args12+0xc>
    6c24:	7103f43f 	cmp	w1, #0xfd
    6c28:	540000e8 	b.hi	6c44 <fwp_args12+0xa4>  // b.pmore
    6c2c:	11000421 	add	w1, w1, #0x1
    6c30:	39000001 	strb	w1, [x0]
    6c34:	d65f03c0 	ret
    6c38:	72003c3f 	tst	w1, #0xffff
    6c3c:	54ffff00 	b.eq	6c1c <fwp_args12+0x7c>  // b.none
    6c40:	d65f03c0 	ret
    6c44:	17fff6a4 	b	46d4 <fwp_rc_wide_dup>
    6c48:	d503201f 	nop
    6c4c:	d503201f 	nop

0000000000006c50 <fwp_args23>:
    6c50:	7100003f 	cmp	w1, #0x0
    6c54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c58:	54000041 	b.ne	6c60 <fwp_args23+0x10>  // b.any
    6c5c:	d65f03c0 	ret
    6c60:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6c64:	91174042 	add	x2, x2, #0x5d0
    6c68:	f9400001 	ldr	x1, [x0]
    6c6c:	f949d843 	ldr	x3, [x2, #5040]
    6c70:	f949ec40 	ldr	x0, [x2, #5080]
    6c74:	cb030021 	sub	x1, x1, x3
    6c78:	eb00403f 	cmp	x1, x0, lsl #16
    6c7c:	54ffff02 	b.cs	6c5c <fwp_args23+0xc>  // b.hs, b.nlast
    6c80:	d350fc20 	lsr	x0, x1, #16
    6c84:	f949fc44 	ldr	x4, [x2, #5112]
    6c88:	8b000800 	add	x0, x0, x0, lsl #2
    6c8c:	d37df002 	lsl	x2, x0, #3
    6c90:	8b020083 	add	x3, x4, x2
    6c94:	f9401060 	ldr	x0, [x3, #32]
    6c98:	b4fffe20 	cbz	x0, 6c5c <fwp_args23+0xc>
    6c9c:	38626882 	ldrb	w2, [x4, x2]
    6ca0:	7100085f 	cmp	w2, #0x2
    6ca4:	54000220 	b.eq	6ce8 <fwp_args23+0x98>  // b.none
    6ca8:	7100045f 	cmp	w2, #0x1
    6cac:	54fffd81 	b.ne	6c5c <fwp_args23+0xc>  // b.any
    6cb0:	29430864 	ldp	w4, w2, [x3, #24]
    6cb4:	92403c21 	and	x1, x1, #0xffff
    6cb8:	9b047c21 	mul	x1, x1, x4
    6cbc:	d360fc21 	lsr	x1, x1, #32
    6cc0:	eb02003f 	cmp	x1, x2
    6cc4:	54fffcc2 	b.cs	6c5c <fwp_args23+0xc>  // b.hs, b.nlast
    6cc8:	8b010000 	add	x0, x0, x1
    6ccc:	39400001 	ldrb	w1, [x0]
    6cd0:	34fffc61 	cbz	w1, 6c5c <fwp_args23+0xc>
    6cd4:	7103f43f 	cmp	w1, #0xfd
    6cd8:	540000e8 	b.hi	6cf4 <fwp_args23+0xa4>  // b.pmore
    6cdc:	11000421 	add	w1, w1, #0x1
    6ce0:	39000001 	strb	w1, [x0]
    6ce4:	d65f03c0 	ret
    6ce8:	72003c3f 	tst	w1, #0xffff
    6cec:	54ffff00 	b.eq	6ccc <fwp_args23+0x7c>  // b.none
    6cf0:	d65f03c0 	ret
    6cf4:	17fff678 	b	46d4 <fwp_rc_wide_dup>
    6cf8:	d503201f 	nop
    6cfc:	d503201f 	nop

0000000000006d00 <fwp_caps12>:
    6d00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d04:	910003fd 	mov	x29, sp
    6d08:	f9000bf3 	str	x19, [sp, #16]
    6d0c:	aa0003f3 	mov	x19, x0
    6d10:	b9400400 	ldr	w0, [x0, #4]
    6d14:	340004a0 	cbz	w0, 6da8 <fwp_caps12+0xa8>
    6d18:	f9400660 	ldr	x0, [x19, #8]
    6d1c:	350004e1 	cbnz	w1, 6db8 <fwp_caps12+0xb8>
    6d20:	97fffc70 	bl	5ee0 <fwp_drop0>
    6d24:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6d28:	91174042 	add	x2, x2, #0x5d0
    6d2c:	f949d840 	ldr	x0, [x2, #5040]
    6d30:	f949ec41 	ldr	x1, [x2, #5080]
    6d34:	cb000260 	sub	x0, x19, x0
    6d38:	eb01401f 	cmp	x0, x1, lsl #16
    6d3c:	54000382 	b.cs	6dac <fwp_caps12+0xac>  // b.hs, b.nlast
    6d40:	d350fc01 	lsr	x1, x0, #16
    6d44:	f949fc44 	ldr	x4, [x2, #5112]
    6d48:	8b010821 	add	x1, x1, x1, lsl #2
    6d4c:	d37df021 	lsl	x1, x1, #3
    6d50:	8b010083 	add	x3, x4, x1
    6d54:	f9401062 	ldr	x2, [x3, #32]
    6d58:	b40002a2 	cbz	x2, 6dac <fwp_caps12+0xac>
    6d5c:	38616881 	ldrb	w1, [x4, x1]
    6d60:	7100083f 	cmp	w1, #0x2
    6d64:	540006c0 	b.eq	6e3c <fwp_caps12+0x13c>  // b.none
    6d68:	7100043f 	cmp	w1, #0x1
    6d6c:	54000201 	b.ne	6dac <fwp_caps12+0xac>  // b.any
    6d70:	29430464 	ldp	w4, w1, [x3, #24]
    6d74:	92403c00 	and	x0, x0, #0xffff
    6d78:	9b047c00 	mul	x0, x0, x4
    6d7c:	d360fc00 	lsr	x0, x0, #32
    6d80:	eb01001f 	cmp	x0, x1
    6d84:	54000142 	b.cs	6dac <fwp_caps12+0xac>  // b.hs, b.nlast
    6d88:	8b000042 	add	x2, x2, x0
    6d8c:	39400040 	ldrb	w0, [x2]
    6d90:	7100041f 	cmp	w0, #0x1
    6d94:	540000c1 	b.ne	6dac <fwp_caps12+0xac>  // b.any
    6d98:	aa1303e0 	mov	x0, x19
    6d9c:	f9400bf3 	ldr	x19, [sp, #16]
    6da0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6da4:	17fff733 	b	4a70 <fwp_mem_free>
    6da8:	34fffbe1 	cbz	w1, 6d24 <fwp_caps12+0x24>
    6dac:	f9400bf3 	ldr	x19, [sp, #16]
    6db0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6db4:	d65f03c0 	ret
    6db8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6dbc:	91174042 	add	x2, x2, #0x5d0
    6dc0:	f949d843 	ldr	x3, [x2, #5040]
    6dc4:	f949ec41 	ldr	x1, [x2, #5080]
    6dc8:	cb030000 	sub	x0, x0, x3
    6dcc:	eb01401f 	cmp	x0, x1, lsl #16
    6dd0:	54fffee2 	b.cs	6dac <fwp_caps12+0xac>  // b.hs, b.nlast
    6dd4:	d350fc01 	lsr	x1, x0, #16
    6dd8:	f949fc44 	ldr	x4, [x2, #5112]
    6ddc:	8b010821 	add	x1, x1, x1, lsl #2
    6de0:	d37df021 	lsl	x1, x1, #3
    6de4:	8b010083 	add	x3, x4, x1
    6de8:	f9401062 	ldr	x2, [x3, #32]
    6dec:	b4fffe02 	cbz	x2, 6dac <fwp_caps12+0xac>
    6df0:	38616881 	ldrb	w1, [x4, x1]
    6df4:	7100083f 	cmp	w1, #0x2
    6df8:	54000280 	b.eq	6e48 <fwp_caps12+0x148>  // b.none
    6dfc:	7100043f 	cmp	w1, #0x1
    6e00:	54fffd61 	b.ne	6dac <fwp_caps12+0xac>  // b.any
    6e04:	92403c01 	and	x1, x0, #0xffff
    6e08:	29430064 	ldp	w4, w0, [x3, #24]
    6e0c:	9b047c21 	mul	x1, x1, x4
    6e10:	d360fc21 	lsr	x1, x1, #32
    6e14:	eb00003f 	cmp	x1, x0
    6e18:	54fffca2 	b.cs	6dac <fwp_caps12+0xac>  // b.hs, b.nlast
    6e1c:	8b010042 	add	x2, x2, x1
    6e20:	39400040 	ldrb	w0, [x2]
    6e24:	34fffc40 	cbz	w0, 6dac <fwp_caps12+0xac>
    6e28:	7103f41f 	cmp	w0, #0xfd
    6e2c:	54000148 	b.hi	6e54 <fwp_caps12+0x154>  // b.pmore
    6e30:	11000400 	add	w0, w0, #0x1
    6e34:	39000040 	strb	w0, [x2]
    6e38:	17ffffdd 	b	6dac <fwp_caps12+0xac>
    6e3c:	72003c1f 	tst	w0, #0xffff
    6e40:	54fffb61 	b.ne	6dac <fwp_caps12+0xac>  // b.any
    6e44:	17ffffd2 	b	6d8c <fwp_caps12+0x8c>
    6e48:	72003c1f 	tst	w0, #0xffff
    6e4c:	54fffb01 	b.ne	6dac <fwp_caps12+0xac>  // b.any
    6e50:	17fffff4 	b	6e20 <fwp_caps12+0x120>
    6e54:	f9400bf3 	ldr	x19, [sp, #16]
    6e58:	aa0203e0 	mov	x0, x2
    6e5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e60:	17fff61d 	b	46d4 <fwp_rc_wide_dup>

0000000000006e64 <fwp_drop2>:
    6e64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6e68:	910003fd 	mov	x29, sp
    6e6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6e70:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6e74:	911742d5 	add	x21, x22, #0x5d0
    6e78:	a90153f3 	stp	x19, x20, [sp, #16]
    6e7c:	aa0003f3 	mov	x19, x0
    6e80:	f949daa1 	ldr	x1, [x21, #5040]
    6e84:	f949eea0 	ldr	x0, [x21, #5080]
    6e88:	cb010261 	sub	x1, x19, x1
    6e8c:	eb00403f 	cmp	x1, x0, lsl #16
    6e90:	54000382 	b.cs	6f00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e94:	d350fc22 	lsr	x2, x1, #16
    6e98:	f949fea3 	ldr	x3, [x21, #5112]
    6e9c:	8b020842 	add	x2, x2, x2, lsl #2
    6ea0:	d37df042 	lsl	x2, x2, #3
    6ea4:	8b020060 	add	x0, x3, x2
    6ea8:	f9401014 	ldr	x20, [x0, #32]
    6eac:	b40002b4 	cbz	x20, 6f00 <fwp_drop2+0x9c>
    6eb0:	38626862 	ldrb	w2, [x3, x2]
    6eb4:	7100085f 	cmp	w2, #0x2
    6eb8:	540002c0 	b.eq	6f10 <fwp_drop2+0xac>  // b.none
    6ebc:	7100045f 	cmp	w2, #0x1
    6ec0:	54000201 	b.ne	6f00 <fwp_drop2+0x9c>  // b.any
    6ec4:	29430002 	ldp	w2, w0, [x0, #24]
    6ec8:	92403c21 	and	x1, x1, #0xffff
    6ecc:	9b027c21 	mul	x1, x1, x2
    6ed0:	d360fc21 	lsr	x1, x1, #32
    6ed4:	eb00003f 	cmp	x1, x0
    6ed8:	54000142 	b.cs	6f00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6edc:	8b010294 	add	x20, x20, x1
    6ee0:	39400280 	ldrb	w0, [x20]
    6ee4:	340000e0 	cbz	w0, 6f00 <fwp_drop2+0x9c>
    6ee8:	7100041f 	cmp	w0, #0x1
    6eec:	540001e0 	b.eq	6f28 <fwp_drop2+0xc4>  // b.none
    6ef0:	7103fc1f 	cmp	w0, #0xff
    6ef4:	540007e0 	b.eq	6ff0 <fwp_drop2+0x18c>  // b.none
    6ef8:	51000400 	sub	w0, w0, #0x1
    6efc:	39000280 	strb	w0, [x20]
    6f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6f08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f0c:	d65f03c0 	ret
    6f10:	72003c3f 	tst	w1, #0xffff
    6f14:	54fffe60 	b.eq	6ee0 <fwp_drop2+0x7c>  // b.none
    6f18:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f1c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6f20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f24:	d65f03c0 	ret
    6f28:	911742c2 	add	x2, x22, #0x5d0
    6f2c:	f9400660 	ldr	x0, [x19, #8]
    6f30:	f949d841 	ldr	x1, [x2, #5040]
    6f34:	f949ec42 	ldr	x2, [x2, #5080]
    6f38:	cb010001 	sub	x1, x0, x1
    6f3c:	eb02403f 	cmp	x1, x2, lsl #16
    6f40:	54000382 	b.cs	6fb0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6f44:	d350fc22 	lsr	x2, x1, #16
    6f48:	8b020842 	add	x2, x2, x2, lsl #2
    6f4c:	d37df042 	lsl	x2, x2, #3
    6f50:	8b020064 	add	x4, x3, x2
    6f54:	f9401094 	ldr	x20, [x4, #32]
    6f58:	b40002d4 	cbz	x20, 6fb0 <fwp_drop2+0x14c>
    6f5c:	38626862 	ldrb	w2, [x3, x2]
    6f60:	7100085f 	cmp	w2, #0x2
    6f64:	54000400 	b.eq	6fe4 <fwp_drop2+0x180>  // b.none
    6f68:	7100045f 	cmp	w2, #0x1
    6f6c:	54000221 	b.ne	6fb0 <fwp_drop2+0x14c>  // b.any
    6f70:	29430883 	ldp	w3, w2, [x4, #24]
    6f74:	92403c21 	and	x1, x1, #0xffff
    6f78:	9b037c21 	mul	x1, x1, x3
    6f7c:	d360fc21 	lsr	x1, x1, #32
    6f80:	eb02003f 	cmp	x1, x2
    6f84:	54000162 	b.cs	6fb0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6f88:	8b010294 	add	x20, x20, x1
    6f8c:	39400281 	ldrb	w1, [x20]
    6f90:	34000101 	cbz	w1, 6fb0 <fwp_drop2+0x14c>
    6f94:	7100043f 	cmp	w1, #0x1
    6f98:	54000220 	b.eq	6fdc <fwp_drop2+0x178>  // b.none
    6f9c:	7103fc3f 	cmp	w1, #0xff
    6fa0:	540005a0 	b.eq	7054 <fwp_drop2+0x1f0>  // b.none
    6fa4:	51000421 	sub	w1, w1, #0x1
    6fa8:	39000281 	strb	w1, [x20]
    6fac:	d503201f 	nop
    6fb0:	f9400a74 	ldr	x20, [x19, #16]
    6fb4:	aa1303e0 	mov	x0, x19
    6fb8:	97fffaa2 	bl	5a40 <fwp_rc_free_arr>
    6fbc:	911742c0 	add	x0, x22, #0x5d0
    6fc0:	f949d801 	ldr	x1, [x0, #5040]
    6fc4:	f949ec00 	ldr	x0, [x0, #5080]
    6fc8:	cb010281 	sub	x1, x20, x1
    6fcc:	eb00403f 	cmp	x1, x0, lsl #16
    6fd0:	54fff982 	b.cs	6f00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6fd4:	aa1403f3 	mov	x19, x20
    6fd8:	17ffffaf 	b	6e94 <fwp_drop2+0x30>
    6fdc:	97fffa99 	bl	5a40 <fwp_rc_free_arr>
    6fe0:	17fffff4 	b	6fb0 <fwp_drop2+0x14c>
    6fe4:	72003c3f 	tst	w1, #0xffff
    6fe8:	54fffe41 	b.ne	6fb0 <fwp_drop2+0x14c>  // b.any
    6fec:	17ffffe8 	b	6f8c <fwp_drop2+0x128>
    6ff0:	ca544681 	eor	x1, x20, x20, lsr #17
    6ff4:	911742c0 	add	x0, x22, #0x5d0
    6ff8:	ca412421 	eor	x1, x1, x1, lsr #9
    6ffc:	8b210c01 	add	x1, x0, w1, uxtb #3
    7000:	f94a2420 	ldr	x0, [x1, #5192]
    7004:	b5000080 	cbnz	x0, 7014 <fwp_drop2+0x1b0>
    7008:	14000010 	b	7048 <fwp_drop2+0x1e4>
    700c:	f9400800 	ldr	x0, [x0, #16]
    7010:	b40001c0 	cbz	x0, 7048 <fwp_drop2+0x1e4>
    7014:	f9400001 	ldr	x1, [x0]
    7018:	eb14003f 	cmp	x1, x20
    701c:	54ffff81 	b.ne	700c <fwp_drop2+0x1a8>  // b.any
    7020:	f9400401 	ldr	x1, [x0, #8]
    7024:	d1000421 	sub	x1, x1, #0x1
    7028:	f9000401 	str	x1, [x0, #8]
    702c:	f103f83f 	cmp	x1, #0xfe
    7030:	54fff681 	b.ne	6f00 <fwp_drop2+0x9c>  // b.any
    7034:	aa1403e0 	mov	x0, x20
    7038:	97fff5ee 	bl	47f0 <fwp_rc_forget_slot>
    703c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7040:	39000280 	strb	w0, [x20]
    7044:	17ffffaf 	b	6f00 <fwp_drop2+0x9c>
    7048:	d0000020 	adrp	x0, d000 <__divti3+0x1b0>
    704c:	91234000 	add	x0, x0, #0x8d0
    7050:	97fff1ec 	bl	3800 <fwp_trap>
    7054:	ca544680 	eor	x0, x20, x20, lsr #17
    7058:	911742c1 	add	x1, x22, #0x5d0
    705c:	ca402400 	eor	x0, x0, x0, lsr #9
    7060:	8b200c20 	add	x0, x1, w0, uxtb #3
    7064:	f94a2400 	ldr	x0, [x0, #5192]
    7068:	b5000080 	cbnz	x0, 7078 <fwp_drop2+0x214>
    706c:	17fffff7 	b	7048 <fwp_drop2+0x1e4>
    7070:	f9400800 	ldr	x0, [x0, #16]
    7074:	b4fffea0 	cbz	x0, 7048 <fwp_drop2+0x1e4>
    7078:	f9400001 	ldr	x1, [x0]
    707c:	eb14003f 	cmp	x1, x20
    7080:	54ffff81 	b.ne	7070 <fwp_drop2+0x20c>  // b.any
    7084:	f9400401 	ldr	x1, [x0, #8]
    7088:	d1000421 	sub	x1, x1, #0x1
    708c:	f9000401 	str	x1, [x0, #8]
    7090:	f103f83f 	cmp	x1, #0xfe
    7094:	54fff8e1 	b.ne	6fb0 <fwp_drop2+0x14c>  // b.any
    7098:	aa1403e0 	mov	x0, x20
    709c:	97fff5d5 	bl	47f0 <fwp_rc_forget_slot>
    70a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    70a4:	39000280 	strb	w0, [x20]
    70a8:	17ffffc2 	b	6fb0 <fwp_drop2+0x14c>
    70ac:	d503201f 	nop

00000000000070b0 <fwp_arg_drop23>:
    70b0:	7100003f 	cmp	w1, #0x0
    70b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70b8:	54000041 	b.ne	70c0 <fwp_arg_drop23+0x10>  // b.any
    70bc:	d65f03c0 	ret
    70c0:	f9400000 	ldr	x0, [x0]
    70c4:	17ffff68 	b	6e64 <fwp_drop2>
    70c8:	d503201f 	nop
    70cc:	d503201f 	nop

00000000000070d0 <fwp_caps23>:
    70d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    70d4:	910003fd 	mov	x29, sp
    70d8:	f9000bf3 	str	x19, [sp, #16]
    70dc:	aa0003f3 	mov	x19, x0
    70e0:	b9400400 	ldr	w0, [x0, #4]
    70e4:	340004a0 	cbz	w0, 7178 <fwp_caps23+0xa8>
    70e8:	f9400660 	ldr	x0, [x19, #8]
    70ec:	350004e1 	cbnz	w1, 7188 <fwp_caps23+0xb8>
    70f0:	97ffff5d 	bl	6e64 <fwp_drop2>
    70f4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    70f8:	91174042 	add	x2, x2, #0x5d0
    70fc:	f949d840 	ldr	x0, [x2, #5040]
    7100:	f949ec41 	ldr	x1, [x2, #5080]
    7104:	cb000260 	sub	x0, x19, x0
    7108:	eb01401f 	cmp	x0, x1, lsl #16
    710c:	54000382 	b.cs	717c <fwp_caps23+0xac>  // b.hs, b.nlast
    7110:	d350fc01 	lsr	x1, x0, #16
    7114:	f949fc44 	ldr	x4, [x2, #5112]
    7118:	8b010821 	add	x1, x1, x1, lsl #2
    711c:	d37df021 	lsl	x1, x1, #3
    7120:	8b010083 	add	x3, x4, x1
    7124:	f9401062 	ldr	x2, [x3, #32]
    7128:	b40002a2 	cbz	x2, 717c <fwp_caps23+0xac>
    712c:	38616881 	ldrb	w1, [x4, x1]
    7130:	7100083f 	cmp	w1, #0x2
    7134:	540006c0 	b.eq	720c <fwp_caps23+0x13c>  // b.none
    7138:	7100043f 	cmp	w1, #0x1
    713c:	54000201 	b.ne	717c <fwp_caps23+0xac>  // b.any
    7140:	29430464 	ldp	w4, w1, [x3, #24]
    7144:	92403c00 	and	x0, x0, #0xffff
    7148:	9b047c00 	mul	x0, x0, x4
    714c:	d360fc00 	lsr	x0, x0, #32
    7150:	eb01001f 	cmp	x0, x1
    7154:	54000142 	b.cs	717c <fwp_caps23+0xac>  // b.hs, b.nlast
    7158:	8b000042 	add	x2, x2, x0
    715c:	39400040 	ldrb	w0, [x2]
    7160:	7100041f 	cmp	w0, #0x1
    7164:	540000c1 	b.ne	717c <fwp_caps23+0xac>  // b.any
    7168:	aa1303e0 	mov	x0, x19
    716c:	f9400bf3 	ldr	x19, [sp, #16]
    7170:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7174:	17fff63f 	b	4a70 <fwp_mem_free>
    7178:	34fffbe1 	cbz	w1, 70f4 <fwp_caps23+0x24>
    717c:	f9400bf3 	ldr	x19, [sp, #16]
    7180:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7184:	d65f03c0 	ret
    7188:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    718c:	91174042 	add	x2, x2, #0x5d0
    7190:	f949d843 	ldr	x3, [x2, #5040]
    7194:	f949ec41 	ldr	x1, [x2, #5080]
    7198:	cb030000 	sub	x0, x0, x3
    719c:	eb01401f 	cmp	x0, x1, lsl #16
    71a0:	54fffee2 	b.cs	717c <fwp_caps23+0xac>  // b.hs, b.nlast
    71a4:	d350fc01 	lsr	x1, x0, #16
    71a8:	f949fc44 	ldr	x4, [x2, #5112]
    71ac:	8b010821 	add	x1, x1, x1, lsl #2
    71b0:	d37df021 	lsl	x1, x1, #3
    71b4:	8b010083 	add	x3, x4, x1
    71b8:	f9401062 	ldr	x2, [x3, #32]
    71bc:	b4fffe02 	cbz	x2, 717c <fwp_caps23+0xac>
    71c0:	38616881 	ldrb	w1, [x4, x1]
    71c4:	7100083f 	cmp	w1, #0x2
    71c8:	54000280 	b.eq	7218 <fwp_caps23+0x148>  // b.none
    71cc:	7100043f 	cmp	w1, #0x1
    71d0:	54fffd61 	b.ne	717c <fwp_caps23+0xac>  // b.any
    71d4:	92403c01 	and	x1, x0, #0xffff
    71d8:	29430064 	ldp	w4, w0, [x3, #24]
    71dc:	9b047c21 	mul	x1, x1, x4
    71e0:	d360fc21 	lsr	x1, x1, #32
    71e4:	eb00003f 	cmp	x1, x0
    71e8:	54fffca2 	b.cs	717c <fwp_caps23+0xac>  // b.hs, b.nlast
    71ec:	8b010042 	add	x2, x2, x1
    71f0:	39400040 	ldrb	w0, [x2]
    71f4:	34fffc40 	cbz	w0, 717c <fwp_caps23+0xac>
    71f8:	7103f41f 	cmp	w0, #0xfd
    71fc:	54000148 	b.hi	7224 <fwp_caps23+0x154>  // b.pmore
    7200:	11000400 	add	w0, w0, #0x1
    7204:	39000040 	strb	w0, [x2]
    7208:	17ffffdd 	b	717c <fwp_caps23+0xac>
    720c:	72003c1f 	tst	w0, #0xffff
    7210:	54fffb61 	b.ne	717c <fwp_caps23+0xac>  // b.any
    7214:	17ffffd2 	b	715c <fwp_caps23+0x8c>
    7218:	72003c1f 	tst	w0, #0xffff
    721c:	54fffb01 	b.ne	717c <fwp_caps23+0xac>  // b.any
    7220:	17fffff4 	b	71f0 <fwp_caps23+0x120>
    7224:	f9400bf3 	ldr	x19, [sp, #16]
    7228:	aa0203e0 	mov	x0, x2
    722c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7230:	17fff529 	b	46d4 <fwp_rc_wide_dup>

0000000000007234 <f23>:
    7234:	d101c3ff 	sub	sp, sp, #0x70
    7238:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    723c:	f947f421 	ldr	x1, [x1, #4072]
    7240:	a9027bfd 	stp	x29, x30, [sp, #32]
    7244:	910083fd 	add	x29, sp, #0x20
    7248:	a90563f7 	stp	x23, x24, [sp, #80]
    724c:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    7250:	911742e3 	add	x3, x23, #0x5d0
    7254:	a90353f3 	stp	x19, x20, [sp, #48]
    7258:	a9045bf5 	stp	x21, x22, [sp, #64]
    725c:	aa0003f6 	mov	x22, x0
    7260:	a9066bf9 	stp	x25, x26, [sp, #96]
    7264:	f949ec62 	ldr	x2, [x3, #5080]
    7268:	f9400024 	ldr	x4, [x1]
    726c:	f9000fe4 	str	x4, [sp, #24]
    7270:	d2800004 	mov	x4, #0x0                   	// #0
    7274:	f949d861 	ldr	x1, [x3, #5040]
    7278:	d370bc42 	lsl	x2, x2, #16
    727c:	b40015a0 	cbz	x0, 7530 <f23+0x2fc>
    7280:	f9400818 	ldr	x24, [x0, #16]
    7284:	cb010301 	sub	x1, x24, x1
    7288:	eb02003f 	cmp	x1, x2
    728c:	54000362 	b.cs	72f8 <f23+0xc4>  // b.hs, b.nlast
    7290:	f949fc60 	ldr	x0, [x3, #5112]
    7294:	d350fc22 	lsr	x2, x1, #16
    7298:	8b020842 	add	x2, x2, x2, lsl #2
    729c:	8b020c02 	add	x2, x0, x2, lsl #3
    72a0:	f9401040 	ldr	x0, [x2, #32]
    72a4:	b40002a0 	cbz	x0, 72f8 <f23+0xc4>
    72a8:	39400043 	ldrb	w3, [x2]
    72ac:	7100087f 	cmp	w3, #0x2
    72b0:	540013a0 	b.eq	7524 <f23+0x2f0>  // b.none
    72b4:	7100047f 	cmp	w3, #0x1
    72b8:	540001c1 	b.ne	72f0 <f23+0xbc>  // b.any
    72bc:	29430843 	ldp	w3, w2, [x2, #24]
    72c0:	92403c21 	and	x1, x1, #0xffff
    72c4:	9b037c21 	mul	x1, x1, x3
    72c8:	d360fc21 	lsr	x1, x1, #32
    72cc:	eb02003f 	cmp	x1, x2
    72d0:	54000102 	b.cs	72f0 <f23+0xbc>  // b.hs, b.nlast
    72d4:	8b010000 	add	x0, x0, x1
    72d8:	39400001 	ldrb	w1, [x0]
    72dc:	340000a1 	cbz	w1, 72f0 <f23+0xbc>
    72e0:	7103f43f 	cmp	w1, #0xfd
    72e4:	54001688 	b.hi	75b4 <f23+0x380>  // b.pmore
    72e8:	11000421 	add	w1, w1, #0x1
    72ec:	39000001 	strb	w1, [x0]
    72f0:	d2800000 	mov	x0, #0x0                   	// #0
    72f4:	b40000d6 	cbz	x22, 730c <f23+0xd8>
    72f8:	aa1603e1 	mov	x1, x22
    72fc:	d2800000 	mov	x0, #0x0                   	// #0
    7300:	f9400821 	ldr	x1, [x1, #16]
    7304:	91000400 	add	x0, x0, #0x1
    7308:	b5ffffc1 	cbnz	x1, 7300 <f23+0xcc>
    730c:	b40011b8 	cbz	x24, 7540 <f23+0x30c>
    7310:	aa1803e1 	mov	x1, x24
    7314:	d2800002 	mov	x2, #0x0                   	// #0
    7318:	f9400821 	ldr	x1, [x1, #16]
    731c:	91000442 	add	x2, x2, #0x1
    7320:	b5ffffc1 	cbnz	x1, 7318 <f23+0xe4>
    7324:	eb00005f 	cmp	x2, x0
    7328:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    732c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7330:	eb01033f 	cmp	x25, x1
    7334:	54001468 	b.hi	75c0 <f23+0x38c>  // b.pmore
    7338:	d37ffb33 	lsl	x19, x25, #1
    733c:	52800041 	mov	w1, #0x2                   	// #2
    7340:	91000660 	add	x0, x19, #0x1
    7344:	d37df000 	lsl	x0, x0, #3
    7348:	97fff6ea 	bl	4ef0 <fwp_heap_alloc>
    734c:	911742e1 	add	x1, x23, #0x5d0
    7350:	aa0003fa 	mov	x26, x0
    7354:	f9000013 	str	x19, [x0]
    7358:	aa0103e0 	mov	x0, x1
    735c:	f949d821 	ldr	x1, [x1, #5040]
    7360:	f949ec00 	ldr	x0, [x0, #5080]
    7364:	cb010341 	sub	x1, x26, x1
    7368:	eb00403f 	cmp	x1, x0, lsl #16
    736c:	54000342 	b.cs	73d4 <f23+0x1a0>  // b.hs, b.nlast
    7370:	911742e2 	add	x2, x23, #0x5d0
    7374:	d350fc20 	lsr	x0, x1, #16
    7378:	8b000800 	add	x0, x0, x0, lsl #2
    737c:	f949fc43 	ldr	x3, [x2, #5112]
    7380:	d37df002 	lsl	x2, x0, #3
    7384:	8b020060 	add	x0, x3, x2
    7388:	f9401013 	ldr	x19, [x0, #32]
    738c:	b4000253 	cbz	x19, 73d4 <f23+0x1a0>
    7390:	38626862 	ldrb	w2, [x3, x2]
    7394:	7100085f 	cmp	w2, #0x2
    7398:	54000c00 	b.eq	7518 <f23+0x2e4>  // b.none
    739c:	7100045f 	cmp	w2, #0x1
    73a0:	540001a1 	b.ne	73d4 <f23+0x1a0>  // b.any
    73a4:	29430002 	ldp	w2, w0, [x0, #24]
    73a8:	92403c21 	and	x1, x1, #0xffff
    73ac:	9b027c21 	mul	x1, x1, x2
    73b0:	d360fc21 	lsr	x1, x1, #32
    73b4:	eb00003f 	cmp	x1, x0
    73b8:	540000e2 	b.cs	73d4 <f23+0x1a0>  // b.hs, b.nlast
    73bc:	8b010273 	add	x19, x19, x1
    73c0:	39400260 	ldrb	w0, [x19]
    73c4:	7103fc1f 	cmp	w0, #0xff
    73c8:	54000da0 	b.eq	757c <f23+0x348>  // b.none
    73cc:	52800020 	mov	w0, #0x1                   	// #1
    73d0:	39000260 	strb	w0, [x19]
    73d4:	b4000259 	cbz	x25, 741c <f23+0x1e8>
    73d8:	8b191359 	add	x25, x26, x25, lsl #4
    73dc:	aa1a03f3 	mov	x19, x26
    73e0:	aa1603f5 	mov	x21, x22
    73e4:	aa1803f4 	mov	x20, x24
    73e8:	f9400683 	ldr	x3, [x20, #8]
    73ec:	f94006a2 	ldr	x2, [x21, #8]
    73f0:	f9400861 	ldr	x1, [x3, #16]
    73f4:	f9400840 	ldr	x0, [x2, #16]
    73f8:	fd400461 	ldr	d1, [x3, #8]
    73fc:	fd400440 	ldr	d0, [x2, #8]
    7400:	97fff86c 	bl	55b0 <w107>
    7404:	f9000660 	str	x0, [x19, #8]
    7408:	f8010e61 	str	x1, [x19, #16]!
    740c:	f9400a94 	ldr	x20, [x20, #16]
    7410:	f9400ab5 	ldr	x21, [x21, #16]
    7414:	eb13033f 	cmp	x25, x19
    7418:	54fffe81 	b.ne	73e8 <f23+0x1b4>  // b.any
    741c:	aa1803e0 	mov	x0, x24
    7420:	97fffe91 	bl	6e64 <fwp_drop2>
    7424:	aa1603e0 	mov	x0, x22
    7428:	97fffe8f 	bl	6e64 <fwp_drop2>
    742c:	911742f7 	add	x23, x23, #0x5d0
    7430:	aa1a03e0 	mov	x0, x26
    7434:	97fff8bc 	bl	5724 <w164.constprop.0>
    7438:	aa0103f3 	mov	x19, x1
    743c:	aa0003f4 	mov	x20, x0
    7440:	aa1a03e0 	mov	x0, x26
    7444:	97fffd37 	bl	6920 <fwp_drop4>
    7448:	a900cff4 	stp	x20, x19, [sp, #8]
    744c:	910023e1 	add	x1, sp, #0x8
    7450:	52800000 	mov	w0, #0x0                   	// #0
    7454:	97fff8dc 	bl	57c4 <fwp_data.part.0.constprop.0>
    7458:	f949dae1 	ldr	x1, [x23, #5040]
    745c:	aa0003f3 	mov	x19, x0
    7460:	f949eee0 	ldr	x0, [x23, #5080]
    7464:	cb010261 	sub	x1, x19, x1
    7468:	eb00403f 	cmp	x1, x0, lsl #16
    746c:	54000322 	b.cs	74d0 <f23+0x29c>  // b.hs, b.nlast
    7470:	d350fc22 	lsr	x2, x1, #16
    7474:	f949fee3 	ldr	x3, [x23, #5112]
    7478:	8b020842 	add	x2, x2, x2, lsl #2
    747c:	d37df042 	lsl	x2, x2, #3
    7480:	8b020060 	add	x0, x3, x2
    7484:	f9401014 	ldr	x20, [x0, #32]
    7488:	b4000254 	cbz	x20, 74d0 <f23+0x29c>
    748c:	38626862 	ldrb	w2, [x3, x2]
    7490:	7100085f 	cmp	w2, #0x2
    7494:	540003c0 	b.eq	750c <f23+0x2d8>  // b.none
    7498:	7100045f 	cmp	w2, #0x1
    749c:	540001a1 	b.ne	74d0 <f23+0x29c>  // b.any
    74a0:	29430002 	ldp	w2, w0, [x0, #24]
    74a4:	92403c21 	and	x1, x1, #0xffff
    74a8:	9b027c21 	mul	x1, x1, x2
    74ac:	d360fc21 	lsr	x1, x1, #32
    74b0:	eb00003f 	cmp	x1, x0
    74b4:	540000e2 	b.cs	74d0 <f23+0x29c>  // b.hs, b.nlast
    74b8:	8b010294 	add	x20, x20, x1
    74bc:	39400280 	ldrb	w0, [x20]
    74c0:	7103fc1f 	cmp	w0, #0xff
    74c4:	54000620 	b.eq	7588 <f23+0x354>  // b.none
    74c8:	52800020 	mov	w0, #0x1                   	// #1
    74cc:	39000280 	strb	w0, [x20]
    74d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    74d4:	f947f400 	ldr	x0, [x0, #4072]
    74d8:	f9400fe2 	ldr	x2, [sp, #24]
    74dc:	f9400001 	ldr	x1, [x0]
    74e0:	eb010042 	subs	x2, x2, x1
    74e4:	d2800001 	mov	x1, #0x0                   	// #0
    74e8:	540006a1 	b.ne	75bc <f23+0x388>  // b.any
    74ec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    74f0:	aa1303e0 	mov	x0, x19
    74f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    74f8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    74fc:	a94563f7 	ldp	x23, x24, [sp, #80]
    7500:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7504:	9101c3ff 	add	sp, sp, #0x70
    7508:	d65f03c0 	ret
    750c:	72003c3f 	tst	w1, #0xffff
    7510:	54fffe01 	b.ne	74d0 <f23+0x29c>  // b.any
    7514:	17ffffea 	b	74bc <f23+0x288>
    7518:	72003c3f 	tst	w1, #0xffff
    751c:	54fff5c1 	b.ne	73d4 <f23+0x1a0>  // b.any
    7520:	17ffffa8 	b	73c0 <f23+0x18c>
    7524:	72003c3f 	tst	w1, #0xffff
    7528:	54ffee41 	b.ne	72f0 <f23+0xbc>  // b.any
    752c:	17ffff6b 	b	72d8 <f23+0xa4>
    7530:	cb0103e1 	neg	x1, x1
    7534:	eb02003f 	cmp	x1, x2
    7538:	540002e3 	b.cc	7594 <f23+0x360>  // b.lo, b.ul, b.last
    753c:	d503201f 	nop
    7540:	52800041 	mov	w1, #0x2                   	// #2
    7544:	d2800100 	mov	x0, #0x8                   	// #8
    7548:	97fff66a 	bl	4ef0 <fwp_heap_alloc>
    754c:	aa0003e1 	mov	x1, x0
    7550:	911742e0 	add	x0, x23, #0x5d0
    7554:	aa0103fa 	mov	x26, x1
    7558:	d2800018 	mov	x24, #0x0                   	// #0
    755c:	f900003f 	str	xzr, [x1]
    7560:	f949d801 	ldr	x1, [x0, #5040]
    7564:	f949ec00 	ldr	x0, [x0, #5080]
    7568:	cb010341 	sub	x1, x26, x1
    756c:	eb00403f 	cmp	x1, x0, lsl #16
    7570:	54fff562 	b.cs	741c <f23+0x1e8>  // b.hs, b.nlast
    7574:	d2800019 	mov	x25, #0x0                   	// #0
    7578:	17ffff7e 	b	7370 <f23+0x13c>
    757c:	aa1303e0 	mov	x0, x19
    7580:	97fff49c 	bl	47f0 <fwp_rc_forget_slot>
    7584:	17ffff92 	b	73cc <f23+0x198>
    7588:	aa1403e0 	mov	x0, x20
    758c:	97fff499 	bl	47f0 <fwp_rc_forget_slot>
    7590:	17ffffce 	b	74c8 <f23+0x294>
    7594:	f949fc62 	ldr	x2, [x3, #5112]
    7598:	d350fc20 	lsr	x0, x1, #16
    759c:	8b000800 	add	x0, x0, x0, lsl #2
    75a0:	8b000c42 	add	x2, x2, x0, lsl #3
    75a4:	f9401040 	ldr	x0, [x2, #32]
    75a8:	b4fffcc0 	cbz	x0, 7540 <f23+0x30c>
    75ac:	d2800018 	mov	x24, #0x0                   	// #0
    75b0:	17ffff3e 	b	72a8 <f23+0x74>
    75b4:	97fff448 	bl	46d4 <fwp_rc_wide_dup>
    75b8:	17ffff4e 	b	72f0 <f23+0xbc>
    75bc:	97ffecb1 	bl	2880 <__stack_chk_fail@plt>
    75c0:	d0000020 	adrp	x0, d000 <__divti3+0x1b0>
    75c4:	91284000 	add	x0, x0, #0xa10
    75c8:	97fff08e 	bl	3800 <fwp_trap>
    75cc:	d503201f 	nop

00000000000075d0 <fwp_owned_entry23>:
    75d0:	f9400000 	ldr	x0, [x0]
    75d4:	17ffff18 	b	7234 <f23>
    75d8:	d503201f 	nop
    75dc:	d503201f 	nop

00000000000075e0 <e23>:
    75e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    75e4:	910003fd 	mov	x29, sp
    75e8:	f9000bf3 	str	x19, [sp, #16]
    75ec:	f9400013 	ldr	x19, [x0]
    75f0:	aa1303e0 	mov	x0, x19
    75f4:	97fff8bc 	bl	58e4 <fwp_rc_share>
    75f8:	aa1303e0 	mov	x0, x19
    75fc:	97ffff0e 	bl	7234 <f23>
    7600:	aa0003f3 	mov	x19, x0
    7604:	97fff8b8 	bl	58e4 <fwp_rc_share>
    7608:	aa1303e0 	mov	x0, x19
    760c:	f9400bf3 	ldr	x19, [sp, #16]
    7610:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7614:	d65f03c0 	ret
    7618:	d503201f 	nop
    761c:	d503201f 	nop

0000000000007620 <f12>:
    7620:	d10483ff 	sub	sp, sp, #0x120
    7624:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7628:	f947f442 	ldr	x2, [x2, #4072]
    762c:	910103e8 	add	x8, sp, #0x40
    7630:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7634:	910303fd 	add	x29, sp, #0xc0
    7638:	9100e3e9 	add	x9, sp, #0x38
    763c:	a90d53f3 	stp	x19, x20, [sp, #208]
    7640:	d0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    7644:	91174263 	add	x3, x19, #0x5d0
    7648:	b00000d4 	adrp	x20, 20000 <__data_start>
    764c:	9101c284 	add	x4, x20, #0x70
    7650:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7654:	f0fffff6 	adrp	x22, 6000 <fwp_drop0+0x120>
    7658:	aa0003f5 	mov	x21, x0
    765c:	f949d861 	ldr	x1, [x3, #5040]
    7660:	a90f63f7 	stp	x23, x24, [sp, #240]
    7664:	b00000d7 	adrp	x23, 20000 <__data_start>
    7668:	f949ec65 	ldr	x5, [x3, #5080]
    766c:	a9106bf9 	stp	x25, x26, [sp, #256]
    7670:	910042f7 	add	x23, x23, #0x10
    7674:	a91173fb 	stp	x27, x28, [sp, #272]
    7678:	9100e2f7 	add	x23, x23, #0x38
    767c:	cb0102e1 	sub	x1, x23, x1
    7680:	f9418886 	ldr	x6, [x4, #784]
    7684:	f9400047 	ldr	x7, [x2]
    7688:	f9005fe7 	str	x7, [sp, #184]
    768c:	d2800007 	mov	x7, #0x0                   	// #0
    7690:	12800007 	mov	w7, #0xffffffff            	// #-1
    7694:	910f42c2 	add	x2, x22, #0x3d0
    7698:	a901a3e9 	stp	x9, x8, [sp, #24]
    769c:	b9003be7 	str	w7, [sp, #56]
    76a0:	a9040be6 	stp	x6, x2, [sp, #64]
    76a4:	f9002be9 	str	x9, [sp, #80]
    76a8:	f9018888 	str	x8, [x4, #784]
    76ac:	eb05403f 	cmp	x1, x5, lsl #16
    76b0:	54000342 	b.cs	7718 <f12+0xf8>  // b.hs, b.nlast
    76b4:	d350fc20 	lsr	x0, x1, #16
    76b8:	f949fc64 	ldr	x4, [x3, #5112]
    76bc:	8b000800 	add	x0, x0, x0, lsl #2
    76c0:	d37df002 	lsl	x2, x0, #3
    76c4:	8b020083 	add	x3, x4, x2
    76c8:	f9401060 	ldr	x0, [x3, #32]
    76cc:	b4000260 	cbz	x0, 7718 <f12+0xf8>
    76d0:	38626882 	ldrb	w2, [x4, x2]
    76d4:	7100085f 	cmp	w2, #0x2
    76d8:	54006dc0 	b.eq	8490 <f12+0xe70>  // b.none
    76dc:	7100045f 	cmp	w2, #0x1
    76e0:	540001c1 	b.ne	7718 <f12+0xf8>  // b.any
    76e4:	29430864 	ldp	w4, w2, [x3, #24]
    76e8:	92403c21 	and	x1, x1, #0xffff
    76ec:	9b047c21 	mul	x1, x1, x4
    76f0:	d360fc21 	lsr	x1, x1, #32
    76f4:	eb02003f 	cmp	x1, x2
    76f8:	54000102 	b.cs	7718 <f12+0xf8>  // b.hs, b.nlast
    76fc:	8b010000 	add	x0, x0, x1
    7700:	39400001 	ldrb	w1, [x0]
    7704:	340000a1 	cbz	w1, 7718 <f12+0xf8>
    7708:	7103f43f 	cmp	w1, #0xfd
    770c:	54007568 	b.hi	85b8 <f12+0xf98>  // b.pmore
    7710:	11000421 	add	w1, w1, #0x1
    7714:	39000001 	strb	w1, [x0]
    7718:	aa1703e0 	mov	x0, x23
    771c:	97fffa4d 	bl	6050 <fwp_closure_drop>
    7720:	b4006c35 	cbz	x21, 84a4 <f12+0xe84>
    7724:	aa1503e0 	mov	x0, x21
    7728:	d2800017 	mov	x23, #0x0                   	// #0
    772c:	d503201f 	nop
    7730:	f9400800 	ldr	x0, [x0, #16]
    7734:	910006f7 	add	x23, x23, #0x1
    7738:	b5ffffc0 	cbnz	x0, 7730 <f12+0x110>
    773c:	52800000 	mov	w0, #0x0                   	// #0
    7740:	97ffefac 	bl	35f0 <descent_phase_step>
    7744:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7748:	eb0002ff 	cmp	x23, x0
    774c:	540076a8 	b.hi	8620 <f12+0x1000>  // b.pmore
    7750:	9101c298 	add	x24, x20, #0x70
    7754:	b9434700 	ldr	w0, [x24, #836]
    7758:	34006880 	cbz	w0, 8468 <f12+0xe48>
    775c:	9101c280 	add	x0, x20, #0x70
    7760:	f9404819 	ldr	x25, [x0, #144]
    7764:	f9407401 	ldr	x1, [x0, #232]
    7768:	eb19003f 	cmp	x1, x25
    776c:	540066aa 	b.ge	8440 <f12+0xe20>  // b.tcont
    7770:	f9403a82 	ldr	x2, [x20, #112]
    7774:	8b010420 	add	x0, x1, x1, lsl #1
    7778:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    777c:	8b000820 	add	x0, x1, x0, lsl #2
    7780:	8b000c40 	add	x0, x2, x0, lsl #3
    7784:	d503201f 	nop
    7788:	b9400402 	ldr	w2, [x0, #4]
    778c:	35000082 	cbnz	w2, 779c <f12+0x17c>
    7790:	b9400002 	ldr	w2, [x0]
    7794:	6b03005f 	cmp	w2, w3
    7798:	54006549 	b.ls	8440 <f12+0xe20>  // b.plast
    779c:	91000421 	add	x1, x1, #0x1
    77a0:	9101a000 	add	x0, x0, #0x68
    77a4:	eb19003f 	cmp	x1, x25
    77a8:	54ffff01 	b.ne	7788 <f12+0x168>  // b.any
    77ac:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    77b0:	eb00033f 	cmp	x25, x0
    77b4:	540073cc 	b.gt	862c <f12+0x100c>
    77b8:	9101c280 	add	x0, x20, #0x70
    77bc:	f9403a9a 	ldr	x26, [x20, #112]
    77c0:	f9407000 	ldr	x0, [x0, #224]
    77c4:	eb19001f 	cmp	x0, x25
    77c8:	54000161 	b.ne	77f4 <f12+0x1d4>  // b.any
    77cc:	b50069d9 	cbnz	x25, 8504 <f12+0xee4>
    77d0:	d2800d01 	mov	x1, #0x68                  	// #104
    77d4:	d2800038 	mov	x24, #0x1                   	// #1
    77d8:	aa1a03e0 	mov	x0, x26
    77dc:	97ffec25 	bl	2870 <realloc@plt>
    77e0:	aa0003fa 	mov	x26, x0
    77e4:	b4006160 	cbz	x0, 8410 <f12+0xdf0>
    77e8:	9101c280 	add	x0, x20, #0x70
    77ec:	f9003a9a 	str	x26, [x20, #112]
    77f0:	f9007018 	str	x24, [x0, #224]
    77f4:	d37ffb21 	lsl	x1, x25, #1
    77f8:	9101c280 	add	x0, x20, #0x70
    77fc:	8b190022 	add	x2, x1, x25
    7800:	9100073b 	add	x27, x25, #0x1
    7804:	4f000400 	movi	v0.4s, #0x0
    7808:	8b020b22 	add	x2, x25, x2, lsl #2
    780c:	f900481b 	str	x27, [x0, #144]
    7810:	8b020f42 	add	x2, x26, x2, lsl #3
    7814:	f900305f 	str	xzr, [x2, #96]
    7818:	ad000040 	stp	q0, q0, [x2]
    781c:	ad010040 	stp	q0, q0, [x2, #32]
    7820:	ad020040 	stp	q0, q0, [x2, #64]
    7824:	8b190021 	add	x1, x1, x25
    7828:	d0000020 	adrp	x0, d000 <__divti3+0x1b0>
    782c:	91218000 	add	x0, x0, #0x860
    7830:	8b010b21 	add	x1, x25, x1, lsl #2
    7834:	8b010f58 	add	x24, x26, x1, lsl #3
    7838:	f900331f 	str	xzr, [x24, #96]
    783c:	97ffec75 	bl	2a10 <getenv@plt>
    7840:	b4000080 	cbz	x0, 7850 <f12+0x230>
    7844:	39400001 	ldrb	w1, [x0]
    7848:	7100c03f 	cmp	w1, #0x30
    784c:	54003080 	b.eq	7e5c <f12+0x83c>  // b.none
    7850:	9101c280 	add	x0, x20, #0x70
    7854:	f9406801 	ldr	x1, [x0, #208]
    7858:	b5006381 	cbnz	x1, 84c8 <f12+0xea8>
    785c:	9101c282 	add	x2, x20, #0x70
    7860:	2f000400 	mvni	v0.2s, #0x0
    7864:	b9400303 	ldr	w3, [x24]
    7868:	52800020 	mov	w0, #0x1                   	// #1
    786c:	a900df17 	stp	x23, x23, [x24, #8]
    7870:	0b000063 	add	w3, w3, w0
    7874:	f9418841 	ldr	x1, [x2, #784]
    7878:	29000303 	stp	w3, w0, [x24]
    787c:	f9002b1f 	str	xzr, [x24, #80]
    7880:	f900745b 	str	x27, [x2, #232]
    7884:	fd002f00 	str	d0, [x24, #88]
    7888:	b4006be1 	cbz	x1, 8604 <f12+0xfe4>
    788c:	910f42d6 	add	x22, x22, #0x3d0
    7890:	14000003 	b	789c <f12+0x27c>
    7894:	f9400021 	ldr	x1, [x1]
    7898:	b4006b61 	cbz	x1, 8604 <f12+0xfe4>
    789c:	f9400422 	ldr	x2, [x1, #8]
    78a0:	eb16005f 	cmp	x2, x22
    78a4:	54ffff81 	b.ne	7894 <f12+0x274>  // b.any
    78a8:	f9400820 	ldr	x0, [x1, #16]
    78ac:	2a1903e2 	mov	w2, w25
    78b0:	b9400001 	ldr	w1, [x0]
    78b4:	f9002b00 	str	x0, [x24, #80]
    78b8:	b9005f01 	str	w1, [x24, #92]
    78bc:	37f80081 	tbnz	w1, #31, 78cc <f12+0x2ac>
    78c0:	52800d05 	mov	w5, #0x68                  	// #104
    78c4:	9b256821 	smaddl	x1, w1, w5, x26
    78c8:	b9005839 	str	w25, [x1, #88]
    78cc:	b9000002 	str	w2, [x0]
    78d0:	d3707c77 	ubfiz	x23, x3, #16, #32
    78d4:	52800020 	mov	w0, #0x1                   	// #1
    78d8:	aa1b02f7 	orr	x23, x23, x27
    78dc:	97ffef45 	bl	35f0 <descent_phase_step>
    78e0:	aa1503e0 	mov	x0, x21
    78e4:	d2800002 	mov	x2, #0x0                   	// #0
    78e8:	b4005655 	cbz	x21, 83b0 <f12+0xd90>
    78ec:	d503201f 	nop
    78f0:	f9400800 	ldr	x0, [x0, #16]
    78f4:	91000442 	add	x2, x2, #0x1
    78f8:	b5ffffc0 	cbnz	x0, 78f0 <f12+0x2d0>
    78fc:	aa1503e1 	mov	x1, x21
    7900:	f9400821 	ldr	x1, [x1, #16]
    7904:	91000400 	add	x0, x0, #0x1
    7908:	b5ffffc1 	cbnz	x1, 7900 <f12+0x2e0>
    790c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7910:	eb01001f 	cmp	x0, x1
    7914:	540066c8 	b.hi	85ec <f12+0xfcc>  // b.pmore
    7918:	f100005f 	cmp	x2, #0x0
    791c:	540054ad 	b.le	83b0 <f12+0xd90>
    7920:	eb00005f 	cmp	x2, x0
    7924:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7928:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    792c:	eb0102df 	cmp	x22, x1
    7930:	540065e8 	b.hi	85ec <f12+0xfcc>  // b.pmore
    7934:	d37ffad9 	lsl	x25, x22, #1
    7938:	52800041 	mov	w1, #0x2                   	// #2
    793c:	91000720 	add	x0, x25, #0x1
    7940:	d37df000 	lsl	x0, x0, #3
    7944:	97fff56b 	bl	4ef0 <fwp_heap_alloc>
    7948:	aa0003f8 	mov	x24, x0
    794c:	91174261 	add	x1, x19, #0x5d0
    7950:	aa0103e0 	mov	x0, x1
    7954:	f9000319 	str	x25, [x24]
    7958:	f949d821 	ldr	x1, [x1, #5040]
    795c:	f949ec00 	ldr	x0, [x0, #5080]
    7960:	cb010301 	sub	x1, x24, x1
    7964:	eb00403f 	cmp	x1, x0, lsl #16
    7968:	540057a2 	b.cs	845c <f12+0xe3c>  // b.hs, b.nlast
    796c:	91174262 	add	x2, x19, #0x5d0
    7970:	d350fc20 	lsr	x0, x1, #16
    7974:	8b000800 	add	x0, x0, x0, lsl #2
    7978:	f949fc43 	ldr	x3, [x2, #5112]
    797c:	d37df002 	lsl	x2, x0, #3
    7980:	8b020060 	add	x0, x3, x2
    7984:	f9401019 	ldr	x25, [x0, #32]
    7988:	b4000259 	cbz	x25, 79d0 <f12+0x3b0>
    798c:	38626862 	ldrb	w2, [x3, x2]
    7990:	7100085f 	cmp	w2, #0x2
    7994:	54005780 	b.eq	8484 <f12+0xe64>  // b.none
    7998:	7100045f 	cmp	w2, #0x1
    799c:	540001a1 	b.ne	79d0 <f12+0x3b0>  // b.any
    79a0:	29430002 	ldp	w2, w0, [x0, #24]
    79a4:	92403c21 	and	x1, x1, #0xffff
    79a8:	9b027c21 	mul	x1, x1, x2
    79ac:	d360fc21 	lsr	x1, x1, #32
    79b0:	eb00003f 	cmp	x1, x0
    79b4:	540000e2 	b.cs	79d0 <f12+0x3b0>  // b.hs, b.nlast
    79b8:	8b010339 	add	x25, x25, x1
    79bc:	39400320 	ldrb	w0, [x25]
    79c0:	7103fc1f 	cmp	w0, #0xff
    79c4:	54005e80 	b.eq	8594 <f12+0xf74>  // b.none
    79c8:	52800020 	mov	w0, #0x1                   	// #1
    79cc:	39000320 	strb	w0, [x25]
    79d0:	b4000236 	cbz	x22, 7a14 <f12+0x3f4>
    79d4:	d3607ee4 	lsl	x4, x23, #32
    79d8:	aa1503e2 	mov	x2, x21
    79dc:	f94006a5 	ldr	x5, [x21, #8]
    79e0:	aa0403e3 	mov	x3, x4
    79e4:	91002300 	add	x0, x24, #0x8
    79e8:	d2800001 	mov	x1, #0x0                   	// #0
    79ec:	14000005 	b	7a00 <f12+0x3e0>
    79f0:	f9400445 	ldr	x5, [x2, #8]
    79f4:	ab040023 	adds	x3, x1, x4
    79f8:	91004000 	add	x0, x0, #0x10
    79fc:	54006266 	b.vs	8648 <f12+0x1028>
    7a00:	a9000c05 	stp	x5, x3, [x0]
    7a04:	91000421 	add	x1, x1, #0x1
    7a08:	f9400842 	ldr	x2, [x2, #16]
    7a0c:	eb0102df 	cmp	x22, x1
    7a10:	54ffff08 	b.hi	79f0 <f12+0x3d0>  // b.pmore
    7a14:	f9400300 	ldr	x0, [x24]
    7a18:	f100041f 	cmp	x0, #0x1
    7a1c:	54005229 	b.ls	8460 <f12+0xe40>  // b.plast
    7a20:	d341fc00 	lsr	x0, x0, #1
    7a24:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7a28:	d1000401 	sub	x1, x0, #0x1
    7a2c:	eb02003f 	cmp	x1, x2
    7a30:	54005de8 	b.hi	85ec <f12+0xfcc>  // b.pmore
    7a34:	d37ff83a 	lsl	x26, x1, #1
    7a38:	b4005141 	cbz	x1, 8460 <f12+0xe40>
    7a3c:	d1002301 	sub	x1, x24, #0x8
    7a40:	91002316 	add	x22, x24, #0x8
    7a44:	8b001039 	add	x25, x1, x0, lsl #4
    7a48:	f94006c0 	ldr	x0, [x22, #8]
    7a4c:	f9400ec1 	ldr	x1, [x22, #24]
    7a50:	fd4002c0 	ldr	d0, [x22]
    7a54:	fd400ac1 	ldr	d1, [x22, #16]
    7a58:	97fff6d6 	bl	55b0 <w107>
    7a5c:	a90006c0 	stp	x0, x1, [x22]
    7a60:	910042d6 	add	x22, x22, #0x10
    7a64:	eb1902df 	cmp	x22, x25
    7a68:	54ffff01 	b.ne	7a48 <f12+0x428>  // b.any
    7a6c:	f900031a 	str	x26, [x24]
    7a70:	aa1803e0 	mov	x0, x24
    7a74:	93407efc 	sxtw	x28, w23
    7a78:	97fff72b 	bl	5724 <w164.constprop.0>
    7a7c:	aa1803e0 	mov	x0, x24
    7a80:	aa0103f8 	mov	x24, x1
    7a84:	97fffba7 	bl	6920 <fwp_drop4>
    7a88:	52800040 	mov	w0, #0x2                   	// #2
    7a8c:	97ffeed9 	bl	35f0 <descent_phase_step>
    7a90:	aa1c03e0 	mov	x0, x28
    7a94:	97fff027 	bl	3b30 <fwp_tape_of>
    7a98:	f9403002 	ldr	x2, [x0, #96]
    7a9c:	aa0003e7 	mov	x7, x0
    7aa0:	b5005ba2 	cbnz	x2, 8614 <f12+0xff4>
    7aa4:	97ffed3b 	bl	2f90 <fwp_tape_unlink_scope>
    7aa8:	b9400008 	ldr	w8, [x0]
    7aac:	a94284f7 	ldp	x23, x1, [x7, #40]
    7ab0:	f90007e1 	str	x1, [sp, #8]
    7ab4:	a940801b 	ldp	x27, x0, [x0, #8]
    7ab8:	b90004ff 	str	wzr, [x7, #4]
    7abc:	a941d8ea 	ldp	x10, x22, [x7, #24]
    7ac0:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    7ac4:	a943e8f9 	ldp	x25, x26, [x7, #56]
    7ac8:	f94024e2 	ldr	x2, [x7, #72]
    7acc:	6b03011f 	cmp	w8, w3
    7ad0:	54000108 	b.hi	7af0 <f12+0x4d0>  // b.pmore
    7ad4:	9101c288 	add	x8, x20, #0x70
    7ad8:	92403f83 	and	x3, x28, #0xffff
    7adc:	d1000463 	sub	x3, x3, #0x1
    7ae0:	f9407509 	ldr	x9, [x8, #232]
    7ae4:	eb09007f 	cmp	x3, x9
    7ae8:	5400004a 	b.ge	7af0 <f12+0x4d0>  // b.tcont
    7aec:	f9007503 	str	x3, [x8, #232]
    7af0:	4f000400 	movi	v0.4s, #0x0
    7af4:	9101c289 	add	x9, x20, #0x70
    7af8:	9101c3e1 	add	x1, sp, #0x70
    7afc:	f9000be1 	str	x1, [sp, #16]
    7b00:	f9000cff 	str	xzr, [x7, #24]
    7b04:	910163e3 	add	x3, sp, #0x58
    7b08:	f941892b 	ldr	x11, [x9, #784]
    7b0c:	3c8080e0 	stur	q0, [x7, #8]
    7b10:	b0ffffe8 	adrp	x8, 4000 <fwp_heap_report+0x60>
    7b14:	ad0100e0 	stp	q0, q0, [x7, #32]
    7b18:	910e0108 	add	x8, x8, #0x380
    7b1c:	a906dbe1 	stp	x1, x22, [sp, #104]
    7b20:	f94007e1 	ldr	x1, [sp, #8]
    7b24:	a9047cff 	stp	xzr, xzr, [x7, #64]
    7b28:	a905a3eb 	stp	x11, x8, [sp, #88]
    7b2c:	f9003ff7 	str	x23, [sp, #120]
    7b30:	f90043e1 	str	x1, [sp, #128]
    7b34:	a908ebf9 	stp	x25, x26, [sp, #136]
    7b38:	a9098bea 	stp	x10, x2, [sp, #152]
    7b3c:	f9018923 	str	x3, [x9, #784]
    7b40:	b7f84bb8 	tbnz	x24, #63, 84b4 <f12+0xe94>
    7b44:	eb98839f 	cmp	x28, x24, asr #32
    7b48:	540054c1 	b.ne	85e0 <f12+0xfc0>  // b.any
    7b4c:	92407f03 	and	x3, x24, #0xffffffff
    7b50:	eb38401f 	cmp	x0, w24, uxtw
    7b54:	5400540d 	b.le	85d4 <f12+0xfb4>
    7b58:	eb03037f 	cmp	x27, x3
    7b5c:	9a83c77c 	csinc	x28, x27, x3, gt
    7b60:	eb1c005f 	cmp	x2, x28
    7b64:	5400446a 	b.ge	83f0 <f12+0xdd0>  // b.tcont
    7b68:	f100005f 	cmp	x2, #0x0
    7b6c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7b70:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    7b74:	14000004 	b	7b84 <f12+0x564>
    7b78:	eb01005f 	cmp	x2, x1
    7b7c:	d37ff842 	lsl	x2, x2, #1
    7b80:	9a9cd042 	csel	x2, x2, x28, le
    7b84:	eb1c005f 	cmp	x2, x28
    7b88:	54ffff8b 	b.lt	7b78 <f12+0x558>  // b.tstop
    7b8c:	b4004e1a 	cbz	x26, 854c <f12+0xf2c>
    7b90:	aa1a03e0 	mov	x0, x26
    7b94:	d37df041 	lsl	x1, x2, #3
    7b98:	f90017e2 	str	x2, [sp, #40]
    7b9c:	97ffeb35 	bl	2870 <realloc@plt>
    7ba0:	f94017e2 	ldr	x2, [sp, #40]
    7ba4:	aa0003fa 	mov	x26, x0
    7ba8:	b400425a 	cbz	x26, 83f0 <f12+0xdd0>
    7bac:	f9004bfa 	str	x26, [sp, #144]
    7bb0:	f90053e2 	str	x2, [sp, #160]
    7bb4:	b50015bc 	cbnz	x28, 7e68 <f12+0x848>
    7bb8:	b7f800d8 	tbnz	x24, #63, 7bd0 <f12+0x5b0>
    7bbc:	92407f04 	and	x4, x24, #0xffffffff
    7bc0:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7bc4:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    7bc8:	1e612800 	fadd	d0, d0, d1
    7bcc:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7bd0:	9101c281 	add	x1, x20, #0x70
    7bd4:	cb1b0384 	sub	x4, x28, x27
    7bd8:	52800060 	mov	w0, #0x3                   	// #3
    7bdc:	a9428827 	ldp	x7, x2, [x1, #40]
    7be0:	8b070084 	add	x4, x4, x7
    7be4:	8b1b0042 	add	x2, x2, x27
    7be8:	a9028824 	stp	x4, x2, [x1, #40]
    7bec:	97ffee81 	bl	35f0 <descent_phase_step>
    7bf0:	d1000783 	sub	x3, x28, #0x1
    7bf4:	d1000764 	sub	x4, x27, #0x1
    7bf8:	eb03037f 	cmp	x27, x3
    7bfc:	540003cc 	b.gt	7c74 <f12+0x654>
    7c00:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    7c04:	1e602008 	fcmp	d0, #0.0
    7c08:	54000300 	b.eq	7c68 <f12+0x648>  // b.none
    7c0c:	cb1b0be0 	neg	x0, x27, lsl #2
    7c10:	cb1b03e2 	neg	x2, x27
    7c14:	8b0002c1 	add	x1, x22, x0
    7c18:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    7c1c:	37f80121 	tbnz	w1, #31, 7c40 <f12+0x620>
    7c20:	f94007e5 	ldr	x5, [sp, #8]
    7c24:	93407c21 	sxtw	x1, w1
    7c28:	8b020ca7 	add	x7, x5, x2, lsl #3
    7c2c:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    7c30:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    7c34:	1e620802 	fmul	d2, d0, d2
    7c38:	1e622821 	fadd	d1, d1, d2
    7c3c:	fc217b41 	str	d1, [x26, x1, lsl #3]
    7c40:	8b0002e0 	add	x0, x23, x0
    7c44:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    7c48:	37f80100 	tbnz	w0, #31, 7c68 <f12+0x648>
    7c4c:	8b020f22 	add	x2, x25, x2, lsl #3
    7c50:	93407c00 	sxtw	x0, w0
    7c54:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    7c58:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    7c5c:	1e620800 	fmul	d0, d0, d2
    7c60:	1e602820 	fadd	d0, d1, d0
    7c64:	fc207b40 	str	d0, [x26, x0, lsl #3]
    7c68:	d1000463 	sub	x3, x3, #0x1
    7c6c:	eb03009f 	cmp	x4, x3
    7c70:	54fffc81 	b.ne	7c00 <f12+0x5e0>  // b.any
    7c74:	52800080 	mov	w0, #0x4                   	// #4
    7c78:	97ffee5e 	bl	35f0 <descent_phase_step>
    7c7c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7c80:	eb00037f 	cmp	x27, x0
    7c84:	54004da8 	b.hi	8638 <f12+0x1018>  // b.pmore
    7c88:	91000760 	add	x0, x27, #0x1
    7c8c:	52800041 	mov	w1, #0x2                   	// #2
    7c90:	d37df000 	lsl	x0, x0, #3
    7c94:	97fff497 	bl	4ef0 <fwp_heap_alloc>
    7c98:	aa0003e2 	mov	x2, x0
    7c9c:	aa0003f6 	mov	x22, x0
    7ca0:	d2800001 	mov	x1, #0x0                   	// #0
    7ca4:	f800845b 	str	x27, [x2], #8
    7ca8:	b40000fb 	cbz	x27, 7cc4 <f12+0x6a4>
    7cac:	d503201f 	nop
    7cb0:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    7cb4:	f8217840 	str	x0, [x2, x1, lsl #3]
    7cb8:	91000421 	add	x1, x1, #0x1
    7cbc:	eb01037f 	cmp	x27, x1
    7cc0:	54ffff81 	b.ne	7cb0 <f12+0x690>  // b.any
    7cc4:	528000a0 	mov	w0, #0x5                   	// #5
    7cc8:	97ffee4a 	bl	35f0 <descent_phase_step>
    7ccc:	f9400be0 	ldr	x0, [sp, #16]
    7cd0:	9101c281 	add	x1, x20, #0x70
    7cd4:	f9402ff8 	ldr	x24, [sp, #88]
    7cd8:	f9018838 	str	x24, [x1, #784]
    7cdc:	97fff1a9 	bl	4380 <fwp_tape_buffers_release>
    7ce0:	528000c0 	mov	w0, #0x6                   	// #6
    7ce4:	97ffee43 	bl	35f0 <descent_phase_step>
    7ce8:	91174262 	add	x2, x19, #0x5d0
    7cec:	f949d841 	ldr	x1, [x2, #5040]
    7cf0:	f949ec40 	ldr	x0, [x2, #5080]
    7cf4:	cb0102c1 	sub	x1, x22, x1
    7cf8:	eb00403f 	cmp	x1, x0, lsl #16
    7cfc:	54000322 	b.cs	7d60 <f12+0x740>  // b.hs, b.nlast
    7d00:	d350fc20 	lsr	x0, x1, #16
    7d04:	f949fc43 	ldr	x3, [x2, #5112]
    7d08:	8b000800 	add	x0, x0, x0, lsl #2
    7d0c:	d37df002 	lsl	x2, x0, #3
    7d10:	8b020060 	add	x0, x3, x2
    7d14:	f9401017 	ldr	x23, [x0, #32]
    7d18:	b4000257 	cbz	x23, 7d60 <f12+0x740>
    7d1c:	38626862 	ldrb	w2, [x3, x2]
    7d20:	7100085f 	cmp	w2, #0x2
    7d24:	54003cc0 	b.eq	84bc <f12+0xe9c>  // b.none
    7d28:	7100045f 	cmp	w2, #0x1
    7d2c:	540001a1 	b.ne	7d60 <f12+0x740>  // b.any
    7d30:	29430002 	ldp	w2, w0, [x0, #24]
    7d34:	92403c21 	and	x1, x1, #0xffff
    7d38:	9b027c21 	mul	x1, x1, x2
    7d3c:	d360fc21 	lsr	x1, x1, #32
    7d40:	eb00003f 	cmp	x1, x0
    7d44:	540000e2 	b.cs	7d60 <f12+0x740>  // b.hs, b.nlast
    7d48:	8b0102f7 	add	x23, x23, x1
    7d4c:	394002e0 	ldrb	w0, [x23]
    7d50:	7103fc1f 	cmp	w0, #0xff
    7d54:	54004260 	b.eq	85a0 <f12+0xf80>  // b.none
    7d58:	52800020 	mov	w0, #0x1                   	// #1
    7d5c:	390002e0 	strb	w0, [x23]
    7d60:	f94013e0 	ldr	x0, [sp, #32]
    7d64:	eb00031f 	cmp	x24, x0
    7d68:	540046e1 	b.ne	8644 <f12+0x1024>  // b.any
    7d6c:	f9400fe0 	ldr	x0, [sp, #24]
    7d70:	9101c294 	add	x20, x20, #0x70
    7d74:	f94023e1 	ldr	x1, [sp, #64]
    7d78:	f9018a81 	str	x1, [x20, #784]
    7d7c:	97fff995 	bl	63d0 <fwp_tape_scope_release>
    7d80:	f94002c0 	ldr	x0, [x22]
    7d84:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7d88:	b7f82c00 	tbnz	x0, #63, 8308 <f12+0xce8>
    7d8c:	91174262 	add	x2, x19, #0x5d0
    7d90:	f949d840 	ldr	x0, [x2, #5040]
    7d94:	f949ec41 	ldr	x1, [x2, #5080]
    7d98:	cb0002c0 	sub	x0, x22, x0
    7d9c:	eb01401f 	cmp	x0, x1, lsl #16
    7da0:	54002b42 	b.cs	8308 <f12+0xce8>  // b.hs, b.nlast
    7da4:	d350fc01 	lsr	x1, x0, #16
    7da8:	f949fc44 	ldr	x4, [x2, #5112]
    7dac:	8b010821 	add	x1, x1, x1, lsl #2
    7db0:	d37df021 	lsl	x1, x1, #3
    7db4:	8b010083 	add	x3, x4, x1
    7db8:	f9401062 	ldr	x2, [x3, #32]
    7dbc:	b4002a62 	cbz	x2, 8308 <f12+0xce8>
    7dc0:	38616881 	ldrb	w1, [x4, x1]
    7dc4:	7100083f 	cmp	w1, #0x2
    7dc8:	540029a0 	b.eq	82fc <f12+0xcdc>  // b.none
    7dcc:	7100043f 	cmp	w1, #0x1
    7dd0:	540029c1 	b.ne	8308 <f12+0xce8>  // b.any
    7dd4:	29430464 	ldp	w4, w1, [x3, #24]
    7dd8:	92403c00 	and	x0, x0, #0xffff
    7ddc:	9b047c00 	mul	x0, x0, x4
    7de0:	d360fc00 	lsr	x0, x0, #32
    7de4:	eb01001f 	cmp	x0, x1
    7de8:	54002902 	b.cs	8308 <f12+0xce8>  // b.hs, b.nlast
    7dec:	8b000042 	add	x2, x2, x0
    7df0:	39400040 	ldrb	w0, [x2]
    7df4:	7100041f 	cmp	w0, #0x1
    7df8:	54002881 	b.ne	8308 <f12+0xce8>  // b.any
    7dfc:	aa1603fa 	mov	x26, x22
    7e00:	d2800000 	mov	x0, #0x0                   	// #0
    7e04:	f90007f6 	str	x22, [sp, #8]
    7e08:	f94007e1 	ldr	x1, [sp, #8]
    7e0c:	91002023 	add	x3, x1, #0x8
    7e10:	d2800001 	mov	x1, #0x0                   	// #0
    7e14:	b4000354 	cbz	x20, 7e7c <f12+0x85c>
    7e18:	f0000022 	adrp	x2, e000 <_IO_stdin_used+0xa90>
    7e1c:	910022c5 	add	x5, x22, #0x8
    7e20:	fd41b041 	ldr	d1, [x2, #864]
    7e24:	14000009 	b	7e48 <f12+0x828>
    7e28:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7e2c:	f9400342 	ldr	x2, [x26]
    7e30:	1e600820 	fmul	d0, d1, d0
    7e34:	b7f83e22 	tbnz	x2, #63, 85f8 <f12+0xfd8>
    7e38:	91000421 	add	x1, x1, #0x1
    7e3c:	fc008460 	str	d0, [x3], #8
    7e40:	eb01029f 	cmp	x20, x1
    7e44:	540001c0 	b.eq	7e7c <f12+0x85c>  // b.none
    7e48:	f94002c4 	ldr	x4, [x22]
    7e4c:	aa0503e2 	mov	x2, x5
    7e50:	b6fffec4 	tbz	x4, #63, 7e28 <f12+0x808>
    7e54:	f9400ac2 	ldr	x2, [x22, #16]
    7e58:	17fffff4 	b	7e28 <f12+0x808>
    7e5c:	39400400 	ldrb	w0, [x0, #1]
    7e60:	34ffcfe0 	cbz	w0, 785c <f12+0x23c>
    7e64:	17fffe7b 	b	7850 <f12+0x230>
    7e68:	d37df382 	lsl	x2, x28, #3
    7e6c:	aa1a03e0 	mov	x0, x26
    7e70:	52800001 	mov	w1, #0x0                   	// #0
    7e74:	97ffea77 	bl	2850 <memset@plt>
    7e78:	17ffff50 	b	7bb8 <f12+0x598>
    7e7c:	97fffaa9 	bl	6920 <fwp_drop4>
    7e80:	aa1503e1 	mov	x1, x21
    7e84:	d2800002 	mov	x2, #0x0                   	// #0
    7e88:	b4003715 	cbz	x21, 8568 <f12+0xf48>
    7e8c:	d503201f 	nop
    7e90:	f9400821 	ldr	x1, [x1, #16]
    7e94:	91000442 	add	x2, x2, #0x1
    7e98:	b5ffffc1 	cbnz	x1, 7e90 <f12+0x870>
    7e9c:	f9400343 	ldr	x3, [x26]
    7ea0:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7ea4:	b7f81f43 	tbnz	x3, #63, 828c <f12+0xc6c>
    7ea8:	91174261 	add	x1, x19, #0x5d0
    7eac:	f94007e4 	ldr	x4, [sp, #8]
    7eb0:	f949d820 	ldr	x0, [x1, #5040]
    7eb4:	f949ec21 	ldr	x1, [x1, #5080]
    7eb8:	cb000080 	sub	x0, x4, x0
    7ebc:	eb01401f 	cmp	x0, x1, lsl #16
    7ec0:	54001e62 	b.cs	828c <f12+0xc6c>  // b.hs, b.nlast
    7ec4:	91174264 	add	x4, x19, #0x5d0
    7ec8:	d350fc01 	lsr	x1, x0, #16
    7ecc:	8b010821 	add	x1, x1, x1, lsl #2
    7ed0:	f949fc86 	ldr	x6, [x4, #5112]
    7ed4:	d37df021 	lsl	x1, x1, #3
    7ed8:	8b0100c5 	add	x5, x6, x1
    7edc:	f94010a4 	ldr	x4, [x5, #32]
    7ee0:	b4001d44 	cbz	x4, 8288 <f12+0xc68>
    7ee4:	386168c1 	ldrb	w1, [x6, x1]
    7ee8:	7100083f 	cmp	w1, #0x2
    7eec:	54001ca0 	b.eq	8280 <f12+0xc60>  // b.none
    7ef0:	7100043f 	cmp	w1, #0x1
    7ef4:	54001ca1 	b.ne	8288 <f12+0xc68>  // b.any
    7ef8:	294304a6 	ldp	w6, w1, [x5, #24]
    7efc:	92403c00 	and	x0, x0, #0xffff
    7f00:	9b067c00 	mul	x0, x0, x6
    7f04:	d360fc00 	lsr	x0, x0, #32
    7f08:	eb01001f 	cmp	x0, x1
    7f0c:	54001be2 	b.cs	8288 <f12+0xc68>  // b.hs, b.nlast
    7f10:	8b000084 	add	x4, x4, x0
    7f14:	39400098 	ldrb	w24, [x4]
    7f18:	7100071f 	cmp	w24, #0x1
    7f1c:	54001b61 	b.ne	8288 <f12+0xc68>  // b.any
    7f20:	b90013f8 	str	w24, [sp, #16]
    7f24:	eb1c005f 	cmp	x2, x28
    7f28:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7f2c:	91002359 	add	x25, x26, #0x8
    7f30:	b40034dc 	cbz	x28, 85c8 <f12+0xfa8>
    7f34:	f94007e0 	ldr	x0, [sp, #8]
    7f38:	d37df385 	lsl	x5, x28, #3
    7f3c:	aa1503e2 	mov	x2, x21
    7f40:	d2800001 	mov	x1, #0x0                   	// #0
    7f44:	91002000 	add	x0, x0, #0x8
    7f48:	1400000a 	b	7f70 <f12+0x950>
    7f4c:	fc616881 	ldr	d1, [x4, x1]
    7f50:	fd400440 	ldr	d0, [x2, #8]
    7f54:	1e613800 	fsub	d0, d0, d1
    7f58:	fc216b20 	str	d0, [x25, x1]
    7f5c:	91002021 	add	x1, x1, #0x8
    7f60:	f9400842 	ldr	x2, [x2, #16]
    7f64:	eb05003f 	cmp	x1, x5
    7f68:	540001c0 	b.eq	7fa0 <f12+0x980>  // b.none
    7f6c:	f9400343 	ldr	x3, [x26]
    7f70:	aa0003e4 	mov	x4, x0
    7f74:	b6fffec3 	tbz	x3, #63, 7f4c <f12+0x92c>
    7f78:	f94007e3 	ldr	x3, [sp, #8]
    7f7c:	fd400440 	ldr	d0, [x2, #8]
    7f80:	f9400864 	ldr	x4, [x3, #16]
    7f84:	fc616881 	ldr	d1, [x4, x1]
    7f88:	1e613800 	fsub	d0, d0, d1
    7f8c:	fc216b20 	str	d0, [x25, x1]
    7f90:	91002021 	add	x1, x1, #0x8
    7f94:	f9400842 	ldr	x2, [x2, #16]
    7f98:	eb05003f 	cmp	x1, x5
    7f9c:	54fffe81 	b.ne	7f6c <f12+0x94c>  // b.any
    7fa0:	b4003115 	cbz	x21, 85c0 <f12+0xfa0>
    7fa4:	91174260 	add	x0, x19, #0x5d0
    7fa8:	aa1503e2 	mov	x2, x21
    7fac:	d280001a 	mov	x26, #0x0                   	// #0
    7fb0:	f949ec06 	ldr	x6, [x0, #5080]
    7fb4:	f949d807 	ldr	x7, [x0, #5040]
    7fb8:	f949fc05 	ldr	x5, [x0, #5112]
    7fbc:	d370bcc6 	lsl	x6, x6, #16
    7fc0:	14000006 	b	7fd8 <f12+0x9b8>
    7fc4:	f9400842 	ldr	x2, [x2, #16]
    7fc8:	9100075a 	add	x26, x26, #0x1
    7fcc:	f100005f 	cmp	x2, #0x0
    7fd0:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7fd4:	54000329 	b.ls	8038 <f12+0xa18>  // b.plast
    7fd8:	cb070040 	sub	x0, x2, x7
    7fdc:	eb06001f 	cmp	x0, x6
    7fe0:	540002c2 	b.cs	8038 <f12+0xa18>  // b.hs, b.nlast
    7fe4:	d350fc01 	lsr	x1, x0, #16
    7fe8:	8b010821 	add	x1, x1, x1, lsl #2
    7fec:	d37df021 	lsl	x1, x1, #3
    7ff0:	8b0100a4 	add	x4, x5, x1
    7ff4:	f9401083 	ldr	x3, [x4, #32]
    7ff8:	b4000203 	cbz	x3, 8038 <f12+0xa18>
    7ffc:	386168a1 	ldrb	w1, [x5, x1]
    8000:	7100083f 	cmp	w1, #0x2
    8004:	54000de0 	b.eq	81c0 <f12+0xba0>  // b.none
    8008:	7100043f 	cmp	w1, #0x1
    800c:	54000161 	b.ne	8038 <f12+0xa18>  // b.any
    8010:	29430488 	ldp	w8, w1, [x4, #24]
    8014:	92403c00 	and	x0, x0, #0xffff
    8018:	9b087c00 	mul	x0, x0, x8
    801c:	d360fc00 	lsr	x0, x0, #32
    8020:	eb01001f 	cmp	x0, x1
    8024:	540000a2 	b.cs	8038 <f12+0xa18>  // b.hs, b.nlast
    8028:	8b000063 	add	x3, x3, x0
    802c:	39400060 	ldrb	w0, [x3]
    8030:	7100041f 	cmp	w0, #0x1
    8034:	54fffc80 	b.eq	7fc4 <f12+0x9a4>  // b.none
    8038:	eb1a039f 	cmp	x28, x26
    803c:	54000ca9 	b.ls	81d0 <f12+0xbb0>  // b.plast
    8040:	d1002337 	sub	x23, x25, #0x8
    8044:	9102a3f6 	add	x22, sp, #0xa8
    8048:	91174278 	add	x24, x19, #0x5d0
    804c:	d2800014 	mov	x20, #0x0                   	// #0
    8050:	14000012 	b	8098 <f12+0xa78>
    8054:	7100045f 	cmp	w2, #0x1
    8058:	540001a1 	b.ne	808c <f12+0xa6c>  // b.any
    805c:	29430002 	ldp	w2, w0, [x0, #24]
    8060:	92403c21 	and	x1, x1, #0xffff
    8064:	9b027c21 	mul	x1, x1, x2
    8068:	d360fc21 	lsr	x1, x1, #32
    806c:	eb00003f 	cmp	x1, x0
    8070:	540000e2 	b.cs	808c <f12+0xa6c>  // b.hs, b.nlast
    8074:	8b01037b 	add	x27, x27, x1
    8078:	39400360 	ldrb	w0, [x27]
    807c:	7103fc1f 	cmp	w0, #0xff
    8080:	54001b20 	b.eq	83e4 <f12+0xdc4>  // b.none
    8084:	52800020 	mov	w0, #0x1                   	// #1
    8088:	39000360 	strb	w0, [x27]
    808c:	d100079c 	sub	x28, x28, #0x1
    8090:	eb1c035f 	cmp	x26, x28
    8094:	54000362 	b.cs	8100 <f12+0xae0>  // b.hs, b.nlast
    8098:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    809c:	aa1603e1 	mov	x1, x22
    80a0:	52800020 	mov	w0, #0x1                   	// #1
    80a4:	a90ad3e2 	stp	x2, x20, [sp, #168]
    80a8:	97fff5c7 	bl	57c4 <fwp_data.part.0.constprop.0>
    80ac:	aa0003f4 	mov	x20, x0
    80b0:	f949db01 	ldr	x1, [x24, #5040]
    80b4:	f949ef00 	ldr	x0, [x24, #5080]
    80b8:	cb010281 	sub	x1, x20, x1
    80bc:	eb00403f 	cmp	x1, x0, lsl #16
    80c0:	54fffe62 	b.cs	808c <f12+0xa6c>  // b.hs, b.nlast
    80c4:	d350fc22 	lsr	x2, x1, #16
    80c8:	f949ff03 	ldr	x3, [x24, #5112]
    80cc:	8b020842 	add	x2, x2, x2, lsl #2
    80d0:	d37df042 	lsl	x2, x2, #3
    80d4:	8b020060 	add	x0, x3, x2
    80d8:	f940101b 	ldr	x27, [x0, #32]
    80dc:	b4fffd9b 	cbz	x27, 808c <f12+0xa6c>
    80e0:	38626862 	ldrb	w2, [x3, x2]
    80e4:	7100085f 	cmp	w2, #0x2
    80e8:	54fffb61 	b.ne	8054 <f12+0xa34>  // b.any
    80ec:	72003c3f 	tst	w1, #0xffff
    80f0:	54fffc40 	b.eq	8078 <f12+0xa58>  // b.none
    80f4:	d100079c 	sub	x28, x28, #0x1
    80f8:	eb1c035f 	cmp	x26, x28
    80fc:	54fffce3 	b.cc	8098 <f12+0xa78>  // b.lo, b.ul, b.last
    8100:	b50006ba 	cbnz	x26, 81d4 <f12+0xbb4>
    8104:	b94013e0 	ldr	w0, [sp, #16]
    8108:	d2800038 	mov	x24, #0x1                   	// #1
    810c:	d280001b 	mov	x27, #0x0                   	// #0
    8110:	7100001f 	cmp	w0, #0x0
    8114:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    8118:	b40007db 	cbz	x27, 8210 <f12+0xbf0>
    811c:	d100077b 	sub	x27, x27, #0x1
    8120:	91174273 	add	x19, x19, #0x5d0
    8124:	d503201f 	nop
    8128:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    812c:	aa1603e1 	mov	x1, x22
    8130:	52800020 	mov	w0, #0x1                   	// #1
    8134:	a90ad3e2 	stp	x2, x20, [sp, #168]
    8138:	97fff5a3 	bl	57c4 <fwp_data.part.0.constprop.0>
    813c:	aa0003f4 	mov	x20, x0
    8140:	f949da61 	ldr	x1, [x19, #5040]
    8144:	f949ee60 	ldr	x0, [x19, #5080]
    8148:	cb010281 	sub	x1, x20, x1
    814c:	eb00403f 	cmp	x1, x0, lsl #16
    8150:	54000302 	b.cs	81b0 <f12+0xb90>  // b.hs, b.nlast
    8154:	d350fc22 	lsr	x2, x1, #16
    8158:	f949fe63 	ldr	x3, [x19, #5112]
    815c:	8b020842 	add	x2, x2, x2, lsl #2
    8160:	d37df042 	lsl	x2, x2, #3
    8164:	8b020060 	add	x0, x3, x2
    8168:	f940101a 	ldr	x26, [x0, #32]
    816c:	b400023a 	cbz	x26, 81b0 <f12+0xb90>
    8170:	38626862 	ldrb	w2, [x3, x2]
    8174:	7100085f 	cmp	w2, #0x2
    8178:	540007e0 	b.eq	8274 <f12+0xc54>  // b.none
    817c:	7100045f 	cmp	w2, #0x1
    8180:	54000181 	b.ne	81b0 <f12+0xb90>  // b.any
    8184:	29430002 	ldp	w2, w0, [x0, #24]
    8188:	92403c21 	and	x1, x1, #0xffff
    818c:	9b027c21 	mul	x1, x1, x2
    8190:	d360fc21 	lsr	x1, x1, #32
    8194:	eb00003f 	cmp	x1, x0
    8198:	540000c2 	b.cs	81b0 <f12+0xb90>  // b.hs, b.nlast
    819c:	8b01035a 	add	x26, x26, x1
    81a0:	39400340 	ldrb	w0, [x26]
    81a4:	7103fc1f 	cmp	w0, #0xff
    81a8:	54000600 	b.eq	8268 <f12+0xc48>  // b.none
    81ac:	39000358 	strb	w24, [x26]
    81b0:	d100077b 	sub	x27, x27, #0x1
    81b4:	b100077f 	cmn	x27, #0x1
    81b8:	54fffb81 	b.ne	8128 <f12+0xb08>  // b.any
    81bc:	14000015 	b	8210 <f12+0xbf0>
    81c0:	72003c1f 	tst	w0, #0xffff
    81c4:	54fff340 	b.eq	802c <f12+0xa0c>  // b.none
    81c8:	eb1a039f 	cmp	x28, x26
    81cc:	54fff3a8 	b.hi	8040 <f12+0xa20>  // b.pmore
    81d0:	d2800014 	mov	x20, #0x0                   	// #0
    81d4:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    81d8:	aa1903e1 	mov	x1, x25
    81dc:	aa1503e0 	mov	x0, x21
    81e0:	f8408422 	ldr	x2, [x1], #8
    81e4:	f9000402 	str	x2, [x0, #8]
    81e8:	aa0003e2 	mov	x2, x0
    81ec:	f9400800 	ldr	x0, [x0, #16]
    81f0:	eb1a003f 	cmp	x1, x26
    81f4:	54ffff61 	b.ne	81e0 <f12+0xbc0>  // b.any
    81f8:	b94013e1 	ldr	w1, [sp, #16]
    81fc:	f9000854 	str	x20, [x2, #16]
    8200:	aa1503f4 	mov	x20, x21
    8204:	aa0003f5 	mov	x21, x0
    8208:	34000041 	cbz	w1, 8210 <f12+0xbf0>
    820c:	d2800019 	mov	x25, #0x0                   	// #0
    8210:	aa1903e0 	mov	x0, x25
    8214:	97fff217 	bl	4a70 <fwp_mem_free>
    8218:	f94007e0 	ldr	x0, [sp, #8]
    821c:	97fff9c1 	bl	6920 <fwp_drop4>
    8220:	aa1503e0 	mov	x0, x21
    8224:	97fff72f 	bl	5ee0 <fwp_drop0>
    8228:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    822c:	f947f400 	ldr	x0, [x0, #4072]
    8230:	f9405fe2 	ldr	x2, [sp, #184]
    8234:	f9400001 	ldr	x1, [x0]
    8238:	eb010042 	subs	x2, x2, x1
    823c:	d2800001 	mov	x1, #0x0                   	// #0
    8240:	54001e81 	b.ne	8610 <f12+0xff0>  // b.any
    8244:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8248:	aa1403e0 	mov	x0, x20
    824c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8250:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8254:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8258:	a9506bf9 	ldp	x25, x26, [sp, #256]
    825c:	a95173fb 	ldp	x27, x28, [sp, #272]
    8260:	910483ff 	add	sp, sp, #0x120
    8264:	d65f03c0 	ret
    8268:	aa1a03e0 	mov	x0, x26
    826c:	97fff161 	bl	47f0 <fwp_rc_forget_slot>
    8270:	17ffffcf 	b	81ac <f12+0xb8c>
    8274:	72003c3f 	tst	w1, #0xffff
    8278:	54fff9c1 	b.ne	81b0 <f12+0xb90>  // b.any
    827c:	17ffffc9 	b	81a0 <f12+0xb80>
    8280:	72003c1f 	tst	w0, #0xffff
    8284:	54ffe480 	b.eq	7f14 <f12+0x8f4>  // b.none
    8288:	b40014f5 	cbz	x21, 8524 <f12+0xf04>
    828c:	aa1503f4 	mov	x20, x21
    8290:	d2800016 	mov	x22, #0x0                   	// #0
    8294:	d503201f 	nop
    8298:	f9400a94 	ldr	x20, [x20, #16]
    829c:	aa1603e0 	mov	x0, x22
    82a0:	910006d6 	add	x22, x22, #0x1
    82a4:	b5ffffb4 	cbnz	x20, 8298 <f12+0xc78>
    82a8:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    82ac:	eb0102df 	cmp	x22, x1
    82b0:	540019e8 	b.hi	85ec <f12+0xfcc>  // b.pmore
    82b4:	91000800 	add	x0, x0, #0x2
    82b8:	52800041 	mov	w1, #0x2                   	// #2
    82bc:	d37df000 	lsl	x0, x0, #3
    82c0:	97fff30c 	bl	4ef0 <fwp_heap_alloc>
    82c4:	eb16039f 	cmp	x28, x22
    82c8:	aa0003f9 	mov	x25, x0
    82cc:	9a96939c 	csel	x28, x28, x22, ls	// ls = plast
    82d0:	aa1503e1 	mov	x1, x21
    82d4:	d503201f 	nop
    82d8:	f9400420 	ldr	x0, [x1, #8]
    82dc:	f8347b20 	str	x0, [x25, x20, lsl #3]
    82e0:	91000694 	add	x20, x20, #0x1
    82e4:	f9400821 	ldr	x1, [x1, #16]
    82e8:	b5ffff81 	cbnz	x1, 82d8 <f12+0xcb8>
    82ec:	b400125c 	cbz	x28, 8534 <f12+0xf14>
    82f0:	f9400343 	ldr	x3, [x26]
    82f4:	b90013ff 	str	wzr, [sp, #16]
    82f8:	17ffff0f 	b	7f34 <f12+0x914>
    82fc:	72003c1f 	tst	w0, #0xffff
    8300:	54ffd780 	b.eq	7df0 <f12+0x7d0>  // b.none
    8304:	d503201f 	nop
    8308:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    830c:	eb00029f 	cmp	x20, x0
    8310:	54001948 	b.hi	8638 <f12+0x1018>  // b.pmore
    8314:	91000680 	add	x0, x20, #0x1
    8318:	52800021 	mov	w1, #0x1                   	// #1
    831c:	d37df000 	lsl	x0, x0, #3
    8320:	97fff2f4 	bl	4ef0 <fwp_heap_alloc>
    8324:	91174262 	add	x2, x19, #0x5d0
    8328:	f9000014 	str	x20, [x0]
    832c:	aa0003fa 	mov	x26, x0
    8330:	f90007fa 	str	x26, [sp, #8]
    8334:	f949d841 	ldr	x1, [x2, #5040]
    8338:	f949ec40 	ldr	x0, [x2, #5080]
    833c:	cb010341 	sub	x1, x26, x1
    8340:	eb00403f 	cmp	x1, x0, lsl #16
    8344:	54000322 	b.cs	83a8 <f12+0xd88>  // b.hs, b.nlast
    8348:	d350fc20 	lsr	x0, x1, #16
    834c:	f949fc43 	ldr	x3, [x2, #5112]
    8350:	8b000800 	add	x0, x0, x0, lsl #2
    8354:	d37df002 	lsl	x2, x0, #3
    8358:	8b020060 	add	x0, x3, x2
    835c:	f9401018 	ldr	x24, [x0, #32]
    8360:	b4000258 	cbz	x24, 83a8 <f12+0xd88>
    8364:	38626862 	ldrb	w2, [x3, x2]
    8368:	7100085f 	cmp	w2, #0x2
    836c:	54000e80 	b.eq	853c <f12+0xf1c>  // b.none
    8370:	7100045f 	cmp	w2, #0x1
    8374:	540001a1 	b.ne	83a8 <f12+0xd88>  // b.any
    8378:	29430002 	ldp	w2, w0, [x0, #24]
    837c:	92403c21 	and	x1, x1, #0xffff
    8380:	9b027c21 	mul	x1, x1, x2
    8384:	d360fc21 	lsr	x1, x1, #32
    8388:	eb00003f 	cmp	x1, x0
    838c:	540000e2 	b.cs	83a8 <f12+0xd88>  // b.hs, b.nlast
    8390:	8b010318 	add	x24, x24, x1
    8394:	39400300 	ldrb	w0, [x24]
    8398:	7103fc1f 	cmp	w0, #0xff
    839c:	54001080 	b.eq	85ac <f12+0xf8c>  // b.none
    83a0:	52800020 	mov	w0, #0x1                   	// #1
    83a4:	39000300 	strb	w0, [x24]
    83a8:	aa1603e0 	mov	x0, x22
    83ac:	17fffe97 	b	7e08 <f12+0x7e8>
    83b0:	52800041 	mov	w1, #0x2                   	// #2
    83b4:	d2800100 	mov	x0, #0x8                   	// #8
    83b8:	97fff2ce 	bl	4ef0 <fwp_heap_alloc>
    83bc:	aa0003f8 	mov	x24, x0
    83c0:	91174260 	add	x0, x19, #0x5d0
    83c4:	f900031f 	str	xzr, [x24]
    83c8:	f949d801 	ldr	x1, [x0, #5040]
    83cc:	f949ec00 	ldr	x0, [x0, #5080]
    83d0:	cb010301 	sub	x1, x24, x1
    83d4:	eb00403f 	cmp	x1, x0, lsl #16
    83d8:	54000442 	b.cs	8460 <f12+0xe40>  // b.hs, b.nlast
    83dc:	d2800016 	mov	x22, #0x0                   	// #0
    83e0:	17fffd63 	b	796c <f12+0x34c>
    83e4:	aa1b03e0 	mov	x0, x27
    83e8:	97fff102 	bl	47f0 <fwp_rc_forget_slot>
    83ec:	17ffff26 	b	8084 <f12+0xa64>
    83f0:	f100039f 	cmp	x28, #0x0
    83f4:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    83f8:	54ffbde1 	b.ne	7bb4 <f12+0x594>  // b.any
    83fc:	f9400be0 	ldr	x0, [sp, #16]
    8400:	9101c294 	add	x20, x20, #0x70
    8404:	f9402fe1 	ldr	x1, [sp, #88]
    8408:	f9018a81 	str	x1, [x20, #784]
    840c:	97ffefdd 	bl	4380 <fwp_tape_buffers_release>
    8410:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8414:	f947e863 	ldr	x3, [x3, #4048]
    8418:	d2800262 	mov	x2, #0x13                  	// #19
    841c:	d2800021 	mov	x1, #0x1                   	// #1
    8420:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    8424:	9115e000 	add	x0, x0, #0x578
    8428:	f9400063 	ldr	x3, [x3]
    842c:	97ffe955 	bl	2980 <fwrite@plt>
    8430:	d2800000 	mov	x0, #0x0                   	// #0
    8434:	97ffe95f 	bl	29b0 <fflush@plt>
    8438:	52800cc0 	mov	w0, #0x66                  	// #102
    843c:	97ffe96d 	bl	29f0 <_Exit@plt>
    8440:	eb01033f 	cmp	x25, x1
    8444:	54ff9b40 	b.eq	77ac <f12+0x18c>  // b.none
    8448:	aa0103f9 	mov	x25, x1
    844c:	9100043b 	add	x27, x1, #0x1
    8450:	f9403a9a 	ldr	x26, [x20, #112]
    8454:	d37ff821 	lsl	x1, x1, #1
    8458:	17fffcf3 	b	7824 <f12+0x204>
    845c:	b5ffabd6 	cbnz	x22, 79d4 <f12+0x3b4>
    8460:	d280001a 	mov	x26, #0x0                   	// #0
    8464:	17fffd82 	b	7a6c <f12+0x44c>
    8468:	d0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x120>
    846c:	910b4000 	add	x0, x0, #0x2d0
    8470:	94001434 	bl	d540 <atexit>
    8474:	35fffce0 	cbnz	w0, 8410 <f12+0xdf0>
    8478:	52800020 	mov	w0, #0x1                   	// #1
    847c:	b9034700 	str	w0, [x24, #836]
    8480:	17fffcb7 	b	775c <f12+0x13c>
    8484:	72003c3f 	tst	w1, #0xffff
    8488:	54ffaa41 	b.ne	79d0 <f12+0x3b0>  // b.any
    848c:	17fffd4c 	b	79bc <f12+0x39c>
    8490:	72003c3f 	tst	w1, #0xffff
    8494:	54ff9360 	b.eq	7700 <f12+0xe0>  // b.none
    8498:	aa1703e0 	mov	x0, x23
    849c:	97fff6ed 	bl	6050 <fwp_closure_drop>
    84a0:	b5ff9435 	cbnz	x21, 7724 <f12+0x104>
    84a4:	52800000 	mov	w0, #0x0                   	// #0
    84a8:	d2800017 	mov	x23, #0x0                   	// #0
    84ac:	97ffec51 	bl	35f0 <descent_phase_step>
    84b0:	17fffca8 	b	7750 <f12+0x130>
    84b4:	aa1b03fc 	mov	x28, x27
    84b8:	17fffdaa 	b	7b60 <f12+0x540>
    84bc:	72003c3f 	tst	w1, #0xffff
    84c0:	54ffc501 	b.ne	7d60 <f12+0x740>  // b.any
    84c4:	17fffe22 	b	7d4c <f12+0x72c>
    84c8:	3cc98002 	ldur	q2, [x0, #152]
    84cc:	91026001 	add	x1, x0, #0x98
    84d0:	3cca8001 	ldur	q1, [x0, #168]
    84d4:	f900681f 	str	xzr, [x0, #208]
    84d8:	4f000400 	movi	v0.4s, #0x0
    84dc:	ad010702 	stp	q2, q1, [x24, #32]
    84e0:	a94b8002 	ldp	x2, x0, [x0, #184]
    84e4:	f9000f00 	str	x0, [x24, #24]
    84e8:	f9401820 	ldr	x0, [x1, #48]
    84ec:	f9002302 	str	x2, [x24, #64]
    84f0:	f9002700 	str	x0, [x24, #72]
    84f4:	ad000020 	stp	q0, q0, [x1]
    84f8:	3d800820 	str	q0, [x1, #32]
    84fc:	f900183f 	str	xzr, [x1, #48]
    8500:	17fffcd7 	b	785c <f12+0x23c>
    8504:	d37ffb38 	lsl	x24, x25, #1
    8508:	d29fffe0 	mov	x0, #0xffff                	// #65535
    850c:	eb00031f 	cmp	x24, x0
    8510:	9a80d318 	csel	x24, x24, x0, le
    8514:	8b180701 	add	x1, x24, x24, lsl #1
    8518:	8b010b01 	add	x1, x24, x1, lsl #2
    851c:	d37df021 	lsl	x1, x1, #3
    8520:	17fffcae 	b	77d8 <f12+0x1b8>
    8524:	52800041 	mov	w1, #0x2                   	// #2
    8528:	d2800100 	mov	x0, #0x8                   	// #8
    852c:	97fff271 	bl	4ef0 <fwp_heap_alloc>
    8530:	aa0003f9 	mov	x25, x0
    8534:	d2800014 	mov	x20, #0x0                   	// #0
    8538:	17ffff36 	b	8210 <f12+0xbf0>
    853c:	72003c3f 	tst	w1, #0xffff
    8540:	54fff2a0 	b.eq	8394 <f12+0xd74>  // b.none
    8544:	aa1603e0 	mov	x0, x22
    8548:	17fffe30 	b	7e08 <f12+0x7e8>
    854c:	aa0203e0 	mov	x0, x2
    8550:	d2800101 	mov	x1, #0x8                   	// #8
    8554:	f90017e2 	str	x2, [sp, #40]
    8558:	97ffe8c2 	bl	2860 <calloc@plt>
    855c:	f94017e2 	ldr	x2, [sp, #40]
    8560:	aa0003fa 	mov	x26, x0
    8564:	17fffd91 	b	7ba8 <f12+0x588>
    8568:	f9400343 	ldr	x3, [x26]
    856c:	b7fffdc3 	tbnz	x3, #63, 8524 <f12+0xf04>
    8570:	91174261 	add	x1, x19, #0x5d0
    8574:	f94007e4 	ldr	x4, [sp, #8]
    8578:	f949d820 	ldr	x0, [x1, #5040]
    857c:	f949ec21 	ldr	x1, [x1, #5080]
    8580:	cb000080 	sub	x0, x4, x0
    8584:	eb01401f 	cmp	x0, x1, lsl #16
    8588:	54fffce2 	b.cs	8524 <f12+0xf04>  // b.hs, b.nlast
    858c:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8590:	17fffe4d 	b	7ec4 <f12+0x8a4>
    8594:	aa1903e0 	mov	x0, x25
    8598:	97fff096 	bl	47f0 <fwp_rc_forget_slot>
    859c:	17fffd0b 	b	79c8 <f12+0x3a8>
    85a0:	aa1703e0 	mov	x0, x23
    85a4:	97fff093 	bl	47f0 <fwp_rc_forget_slot>
    85a8:	17fffdec 	b	7d58 <f12+0x738>
    85ac:	aa1803e0 	mov	x0, x24
    85b0:	97fff090 	bl	47f0 <fwp_rc_forget_slot>
    85b4:	17ffff7b 	b	83a0 <f12+0xd80>
    85b8:	97fff047 	bl	46d4 <fwp_rc_wide_dup>
    85bc:	17fffc57 	b	7718 <f12+0xf8>
    85c0:	d280001a 	mov	x26, #0x0                   	// #0
    85c4:	17fffe9f 	b	8040 <f12+0xa20>
    85c8:	d2800019 	mov	x25, #0x0                   	// #0
    85cc:	d2800014 	mov	x20, #0x0                   	// #0
    85d0:	17ffff10 	b	8210 <f12+0xbf0>
    85d4:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    85d8:	9126c000 	add	x0, x0, #0x9b0
    85dc:	97ffec89 	bl	3800 <fwp_trap>
    85e0:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    85e4:	91246000 	add	x0, x0, #0x918
    85e8:	97ffec86 	bl	3800 <fwp_trap>
    85ec:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    85f0:	91284000 	add	x0, x0, #0xa10
    85f4:	97ffec83 	bl	3800 <fwp_trap>
    85f8:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    85fc:	912ac000 	add	x0, x0, #0xab0
    8600:	97ffec80 	bl	3800 <fwp_trap>
    8604:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    8608:	9129c000 	add	x0, x0, #0xa70
    860c:	97ffec7d 	bl	3800 <fwp_trap>
    8610:	97ffe89c 	bl	2880 <__stack_chk_fail@plt>
    8614:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    8618:	91258000 	add	x0, x0, #0x960
    861c:	97ffec79 	bl	3800 <fwp_trap>
    8620:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    8624:	91288000 	add	x0, x0, #0xa20
    8628:	97ffec76 	bl	3800 <fwp_trap>
    862c:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    8630:	91290000 	add	x0, x0, #0xa40
    8634:	97ffec73 	bl	3800 <fwp_trap>
    8638:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    863c:	912a8000 	add	x0, x0, #0xaa0
    8640:	97ffec70 	bl	3800 <fwp_trap>
    8644:	97ffe8a3 	bl	28d0 <abort@plt>
    8648:	97ffe90e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    864c:	d503201f 	nop

0000000000008650 <fwp_owned_entry12>:
    8650:	f9400000 	ldr	x0, [x0]
    8654:	17fffbf3 	b	7620 <f12>
    8658:	d503201f 	nop
    865c:	d503201f 	nop

0000000000008660 <e12>:
    8660:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8664:	910003fd 	mov	x29, sp
    8668:	f9000bf3 	str	x19, [sp, #16]
    866c:	f9400013 	ldr	x19, [x0]
    8670:	aa1303e0 	mov	x0, x19
    8674:	97fff49c 	bl	58e4 <fwp_rc_share>
    8678:	aa1303e0 	mov	x0, x19
    867c:	97fffbe9 	bl	7620 <f12>
    8680:	aa0003f3 	mov	x19, x0
    8684:	97fff498 	bl	58e4 <fwp_rc_share>
    8688:	aa1303e0 	mov	x0, x19
    868c:	f9400bf3 	ldr	x19, [sp, #16]
    8690:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8694:	d65f03c0 	ret
    8698:	d503201f 	nop
    869c:	d503201f 	nop

00000000000086a0 <fwp_write>:
    86a0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    86a4:	910003fd 	mov	x29, sp
    86a8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    86ac:	f947f484 	ldr	x4, [x4, #4072]
    86b0:	a90153f3 	stp	x19, x20, [sp, #16]
    86b4:	d10943ff 	sub	sp, sp, #0x250
    86b8:	b9400045 	ldr	w5, [x2]
    86bc:	aa0003f4 	mov	x20, x0
    86c0:	f9400080 	ldr	x0, [x4]
    86c4:	f90127e0 	str	x0, [sp, #584]
    86c8:	d2800000 	mov	x0, #0x0                   	// #0
    86cc:	710064bf 	cmp	w5, #0x19
    86d0:	54000408 	b.hi	8750 <fwp_write+0xb0>  // b.pmore
    86d4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xa90>
    86d8:	aa0103f3 	mov	x19, x1
    86dc:	910b0000 	add	x0, x0, #0x2c0
    86e0:	f9013bf5 	str	x21, [sp, #624]
    86e4:	f9013ff6 	str	x22, [sp, #632]
    86e8:	f90153fb 	str	x27, [sp, #672]
    86ec:	f90157fc 	str	x28, [sp, #680]
    86f0:	aa0203fc 	mov	x28, x2
    86f4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    86f8:	10000061 	adr	x1, 8704 <fwp_write+0x64>
    86fc:	8b20a820 	add	x0, x1, w0, sxth #2
    8700:	d61f0000 	br	x0
    8704:	910123e0 	add	x0, sp, #0x48
    8708:	aa1303e5 	mov	x5, x19
    870c:	b0000024 	adrp	x4, d000 <__divti3+0x1b0>
    8710:	aa0003f3 	mov	x19, x0
    8714:	912c4084 	add	x4, x4, #0xb10
    8718:	d2804003 	mov	x3, #0x200                 	// #512
    871c:	aa0303e1 	mov	x1, x3
    8720:	52800042 	mov	w2, #0x2                   	// #2
    8724:	97ffe833 	bl	27f0 <__snprintf_chk@plt>
    8728:	aa1303e0 	mov	x0, x19
    872c:	97ffe7f9 	bl	2710 <strlen@plt>
    8730:	aa1303e1 	mov	x1, x19
    8734:	aa0003e2 	mov	x2, x0
    8738:	aa1403e0 	mov	x0, x20
    873c:	97ffeb95 	bl	3590 <buf_put>
    8740:	f9413bf5 	ldr	x21, [sp, #624]
    8744:	f9413ff6 	ldr	x22, [sp, #632]
    8748:	f94153fb 	ldr	x27, [sp, #672]
    874c:	f94157fc 	ldr	x28, [sp, #680]
    8750:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8754:	f947f400 	ldr	x0, [x0, #4072]
    8758:	f94127e2 	ldr	x2, [sp, #584]
    875c:	f9400001 	ldr	x1, [x0]
    8760:	eb010042 	subs	x2, x2, x1
    8764:	d2800001 	mov	x1, #0x0                   	// #0
    8768:	540077c1 	b.ne	9660 <fwp_write+0xfc0>  // b.any
    876c:	910943ff 	add	sp, sp, #0x250
    8770:	a94153f3 	ldp	x19, x20, [sp, #16]
    8774:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8778:	d65f03c0 	ret
    877c:	910123e0 	add	x0, sp, #0x48
    8780:	aa1303e5 	mov	x5, x19
    8784:	b0000024 	adrp	x4, d000 <__divti3+0x1b0>
    8788:	aa0003f3 	mov	x19, x0
    878c:	912c2084 	add	x4, x4, #0xb08
    8790:	d2804003 	mov	x3, #0x200                 	// #512
    8794:	17ffffe2 	b	871c <fwp_write+0x7c>
    8798:	71004cbf 	cmp	w5, #0x13
    879c:	b0000020 	adrp	x0, d000 <__divti3+0x1b0>
    87a0:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    87a4:	912be000 	add	x0, x0, #0xaf8
    87a8:	912c0021 	add	x1, x1, #0xb00
    87ac:	d2800082 	mov	x2, #0x4                   	// #4
    87b0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    87b4:	aa1403e0 	mov	x0, x20
    87b8:	f90143f7 	str	x23, [sp, #640]
    87bc:	d2800016 	mov	x22, #0x0                   	// #0
    87c0:	f90147f8 	str	x24, [sp, #648]
    87c4:	97ffeb73 	bl	3590 <buf_put>
    87c8:	f9400260 	ldr	x0, [x19]
    87cc:	b0000037 	adrp	x23, d000 <__divti3+0x1b0>
    87d0:	d2800015 	mov	x21, #0x0                   	// #0
    87d4:	912e02f7 	add	x23, x23, #0xb80
    87d8:	b40047a0 	cbz	x0, 90cc <fwp_write+0xa2c>
    87dc:	b9400380 	ldr	w0, [x28]
    87e0:	52800003 	mov	w3, #0x0                   	// #0
    87e4:	f9401f82 	ldr	x2, [x28, #56]
    87e8:	71004c1f 	cmp	w0, #0x13
    87ec:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    87f0:	aa1403e0 	mov	x0, x20
    87f4:	8b010e61 	add	x1, x19, x1, lsl #3
    87f8:	f9400421 	ldr	x1, [x1, #8]
    87fc:	97ffffa9 	bl	86a0 <fwp_write>
    8800:	b9400380 	ldr	w0, [x28]
    8804:	7100481f 	cmp	w0, #0x12
    8808:	54004b40 	b.eq	9170 <fwp_write+0xad0>  // b.none
    880c:	f9400260 	ldr	x0, [x19]
    8810:	910006b5 	add	x21, x21, #0x1
    8814:	91000ad6 	add	x22, x22, #0x2
    8818:	eb15001f 	cmp	x0, x21
    881c:	54004589 	b.ls	90cc <fwp_write+0xa2c>  // b.plast
    8820:	aa1703e1 	mov	x1, x23
    8824:	aa1403e0 	mov	x0, x20
    8828:	d2800042 	mov	x2, #0x2                   	// #2
    882c:	97ffeb59 	bl	3590 <buf_put>
    8830:	17ffffeb 	b	87dc <fwp_write+0x13c>
    8834:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8838:	912ce021 	add	x1, x1, #0xb38
    883c:	d28000c2 	mov	x2, #0x6                   	// #6
    8840:	aa1403e0 	mov	x0, x20
    8844:	91004273 	add	x19, x19, #0x10
    8848:	97ffeb52 	bl	3590 <buf_put>
    884c:	aa1303e0 	mov	x0, x19
    8850:	97ffe7b0 	bl	2710 <strlen@plt>
    8854:	aa1303e1 	mov	x1, x19
    8858:	aa0003e2 	mov	x2, x0
    885c:	aa1403e0 	mov	x0, x20
    8860:	97ffeb4c 	bl	3590 <buf_put>
    8864:	528007c3 	mov	w3, #0x3e                  	// #62
    8868:	aa1403e0 	mov	x0, x20
    886c:	91001fe1 	add	x1, sp, #0x7
    8870:	d2800022 	mov	x2, #0x1                   	// #1
    8874:	39001fe3 	strb	w3, [sp, #7]
    8878:	17ffffb1 	b	873c <fwp_write+0x9c>
    887c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8880:	f947f400 	ldr	x0, [x0, #4072]
    8884:	f94127e2 	ldr	x2, [sp, #584]
    8888:	f9400001 	ldr	x1, [x0]
    888c:	eb010042 	subs	x2, x2, x1
    8890:	d2800001 	mov	x1, #0x0                   	// #0
    8894:	540034e1 	b.ne	8f30 <fwp_write+0x890>  // b.any
    8898:	f9413bf5 	ldr	x21, [sp, #624]
    889c:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    88a0:	f9413ff6 	ldr	x22, [sp, #632]
    88a4:	aa1403e0 	mov	x0, x20
    88a8:	912c6021 	add	x1, x1, #0xb18
    88ac:	d2800142 	mov	x2, #0xa                   	// #10
    88b0:	f94153fb 	ldr	x27, [sp, #672]
    88b4:	f94157fc 	ldr	x28, [sp, #680]
    88b8:	910943ff 	add	sp, sp, #0x250
    88bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    88c0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    88c4:	17ffeb33 	b	3590 <buf_put>
    88c8:	f9400456 	ldr	x22, [x2, #8]
    88cc:	f90143f7 	str	x23, [sp, #640]
    88d0:	f90147f8 	str	x24, [sp, #648]
    88d4:	b4005b16 	cbz	x22, 9434 <fwp_write+0xd94>
    88d8:	aa1603e0 	mov	x0, x22
    88dc:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    88e0:	912e6021 	add	x1, x1, #0xb98
    88e4:	97ffe807 	bl	2900 <strcmp@plt>
    88e8:	2a0003f5 	mov	w21, w0
    88ec:	34005fe0 	cbz	w0, 94e8 <fwp_write+0xe48>
    88f0:	aa1603e0 	mov	x0, x22
    88f4:	97ffe787 	bl	2710 <strlen@plt>
    88f8:	aa1603e1 	mov	x1, x22
    88fc:	aa0003e2 	mov	x2, x0
    8900:	aa1403e0 	mov	x0, x20
    8904:	97ffeb23 	bl	3590 <buf_put>
    8908:	52800403 	mov	w3, #0x20                  	// #32
    890c:	91001ff5 	add	x21, sp, #0x7
    8910:	aa1503e1 	mov	x1, x21
    8914:	aa1403e0 	mov	x0, x20
    8918:	d2800022 	mov	x2, #0x1                   	// #1
    891c:	39001fe3 	strb	w3, [sp, #7]
    8920:	97ffeb1c 	bl	3590 <buf_put>
    8924:	52800f63 	mov	w3, #0x7b                  	// #123
    8928:	aa1403e0 	mov	x0, x20
    892c:	aa1503e1 	mov	x1, x21
    8930:	d2800022 	mov	x2, #0x1                   	// #1
    8934:	39001fe3 	strb	w3, [sp, #7]
    8938:	97ffeb16 	bl	3590 <buf_put>
    893c:	b9401380 	ldr	w0, [x28, #16]
    8940:	52800018 	mov	w24, #0x0                   	// #0
    8944:	7100001f 	cmp	w0, #0x0
    8948:	54003aad 	b.le	909c <fwp_write+0x9fc>
    894c:	f9014bf9 	str	x25, [sp, #656]
    8950:	b0000039 	adrp	x25, d000 <__divti3+0x1b0>
    8954:	912f0339 	add	x25, x25, #0xbc0
    8958:	f9014ffa 	str	x26, [sp, #664]
    895c:	b000003a 	adrp	x26, d000 <__divti3+0x1b0>
    8960:	912e035a 	add	x26, x26, #0xb80
    8964:	91002276 	add	x22, x19, #0x8
    8968:	d2800013 	mov	x19, #0x0                   	// #0
    896c:	b5003e93 	cbnz	x19, 913c <fwp_write+0xa9c>
    8970:	d37df277 	lsl	x23, x19, #3
    8974:	34003cb8 	cbz	w24, 9108 <fwp_write+0xa68>
    8978:	f9401382 	ldr	x2, [x28, #32]
    897c:	aa1403e0 	mov	x0, x20
    8980:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8984:	52800003 	mov	w3, #0x0                   	// #0
    8988:	f8776842 	ldr	x2, [x2, x23]
    898c:	91000673 	add	x19, x19, #0x1
    8990:	97ffff44 	bl	86a0 <fwp_write>
    8994:	b9401380 	ldr	w0, [x28, #16]
    8998:	6b13001f 	cmp	w0, w19
    899c:	54fffe8c 	b.gt	896c <fwp_write+0x2cc>
    89a0:	f9414bf9 	ldr	x25, [sp, #656]
    89a4:	f9414ffa 	ldr	x26, [sp, #664]
    89a8:	340037b8 	cbz	w24, 909c <fwp_write+0x9fc>
    89ac:	52800523 	mov	w3, #0x29                  	// #41
    89b0:	aa1503e1 	mov	x1, x21
    89b4:	aa1403e0 	mov	x0, x20
    89b8:	d2800022 	mov	x2, #0x1                   	// #1
    89bc:	39001fe3 	strb	w3, [sp, #7]
    89c0:	97ffeaf4 	bl	3590 <buf_put>
    89c4:	f9413bf5 	ldr	x21, [sp, #624]
    89c8:	f9413ff6 	ldr	x22, [sp, #632]
    89cc:	f94143f7 	ldr	x23, [sp, #640]
    89d0:	f94147f8 	ldr	x24, [sp, #648]
    89d4:	f94153fb 	ldr	x27, [sp, #672]
    89d8:	f94157fc 	ldr	x28, [sp, #680]
    89dc:	17ffff5d 	b	8750 <fwp_write+0xb0>
    89e0:	b9404855 	ldr	w21, [x2, #72]
    89e4:	aa1403e0 	mov	x0, x20
    89e8:	93407eb6 	sxtw	x22, w21
    89ec:	91000ac1 	add	x1, x22, #0x2
    89f0:	97ffeab5 	bl	34c4 <buf_grow>
    89f4:	a9400281 	ldp	x1, x0, [x20]
    89f8:	528e8603 	mov	w3, #0x7430                	// #29744
    89fc:	78206823 	strh	w3, [x1, x0]
    8a00:	8b000022 	add	x2, x1, x0
    8a04:	710002bf 	cmp	w21, #0x0
    8a08:	540036cd 	b.le	90e0 <fwp_write+0xa40>
    8a0c:	110006a3 	add	w3, w21, #0x1
    8a10:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8a14:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8a18:	91000449 	add	x9, x2, #0x1
    8a1c:	8b23c043 	add	x3, x2, w3, sxtw
    8a20:	f28aaac6 	movk	x6, #0x5556
    8a24:	f2955568 	movk	x8, #0xaaab
    8a28:	1400000d 	b	8a5c <fwp_write+0x3bc>
    8a2c:	d2800021 	mov	x1, #0x1                   	// #1
    8a30:	528005a5 	mov	w5, #0x2d                  	// #45
    8a34:	f100001f 	cmp	x0, #0x0
    8a38:	9b467e60 	smulh	x0, x19, x6
    8a3c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8a40:	381ff465 	strb	w5, [x3], #-1
    8a44:	cb040000 	sub	x0, x0, x4
    8a48:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8a4c:	cb020000 	sub	x0, x0, x2
    8a50:	8b010013 	add	x19, x0, x1
    8a54:	eb03013f 	cmp	x9, x3
    8a58:	54003440 	b.eq	90e0 <fwp_write+0xa40>  // b.none
    8a5c:	9b467e60 	smulh	x0, x19, x6
    8a60:	937ffe64 	asr	x4, x19, #63
    8a64:	52800605 	mov	w5, #0x30                  	// #48
    8a68:	cb040000 	sub	x0, x0, x4
    8a6c:	8b000400 	add	x0, x0, x0, lsl #1
    8a70:	cb000260 	sub	x0, x19, x0
    8a74:	91000c01 	add	x1, x0, #0x3
    8a78:	9bc87c22 	umulh	x2, x1, x8
    8a7c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8a80:	8b4204e2 	add	x2, x7, x2, lsr #1
    8a84:	eb020021 	subs	x1, x1, x2
    8a88:	54fffd60 	b.eq	8a34 <fwp_write+0x394>  // b.none
    8a8c:	f100043f 	cmp	x1, #0x1
    8a90:	54fffce1 	b.ne	8a2c <fwp_write+0x38c>  // b.any
    8a94:	d2800001 	mov	x1, #0x0                   	// #0
    8a98:	52800565 	mov	w5, #0x2b                  	// #43
    8a9c:	17ffffe6 	b	8a34 <fwp_write+0x394>
    8aa0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8aa4:	f947f400 	ldr	x0, [x0, #4072]
    8aa8:	f94127e2 	ldr	x2, [sp, #584]
    8aac:	f9400001 	ldr	x1, [x0]
    8ab0:	eb010042 	subs	x2, x2, x1
    8ab4:	d2800001 	mov	x1, #0x0                   	// #0
    8ab8:	540023c1 	b.ne	8f30 <fwp_write+0x890>  // b.any
    8abc:	f9413bf5 	ldr	x21, [sp, #624]
    8ac0:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8ac4:	f9413ff6 	ldr	x22, [sp, #632]
    8ac8:	aa1403e0 	mov	x0, x20
    8acc:	912ca021 	add	x1, x1, #0xb28
    8ad0:	d2800102 	mov	x2, #0x8                   	// #8
    8ad4:	17ffff77 	b	88b0 <fwp_write+0x210>
    8ad8:	aa1403e0 	mov	x0, x20
    8adc:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8ae0:	d28000c2 	mov	x2, #0x6                   	// #6
    8ae4:	912e2021 	add	x1, x1, #0xb88
    8ae8:	97ffeaaa 	bl	3590 <buf_put>
    8aec:	d2800015 	mov	x21, #0x0                   	// #0
    8af0:	f9400263 	ldr	x3, [x19]
    8af4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8af8:	54002c60 	b.eq	9084 <fwp_write+0x9e4>  // b.none
    8afc:	f9401f82 	ldr	x2, [x28, #56]
    8b00:	f90143f7 	str	x23, [sp, #640]
    8b04:	f90147f8 	str	x24, [sp, #648]
    8b08:	d2800857 	mov	x23, #0x42                  	// #66
    8b0c:	f9014bf9 	str	x25, [sp, #656]
    8b10:	b0000036 	adrp	x22, d000 <__divti3+0x1b0>
    8b14:	f9014ffa 	str	x26, [sp, #664]
    8b18:	912e02d6 	add	x22, x22, #0xb80
    8b1c:	d2800038 	mov	x24, #0x1                   	// #1
    8b20:	f2a18017 	movk	x23, #0xc00, lsl #16
    8b24:	d2809099 	mov	x25, #0x484                 	// #1156
    8b28:	b40004a2 	cbz	x2, 8bbc <fwp_write+0x51c>
    8b2c:	b9400040 	ldr	w0, [x2]
    8b30:	7100701f 	cmp	w0, #0x1c
    8b34:	540042c0 	b.eq	938c <fwp_write+0xcec>  // b.none
    8b38:	71006c1f 	cmp	w0, #0x1b
    8b3c:	54000408 	b.hi	8bbc <fwp_write+0x51c>  // b.pmore
    8b40:	9ac02301 	lsl	x1, x24, x0
    8b44:	ea17003f 	tst	x1, x23
    8b48:	540036a1 	b.ne	921c <fwp_write+0xb7c>  // b.any
    8b4c:	ea19003f 	tst	x1, x25
    8b50:	54003521 	b.ne	91f4 <fwp_write+0xb54>  // b.any
    8b54:	d2800424 	mov	x4, #0x21                  	// #33
    8b58:	ea04003f 	tst	x1, x4
    8b5c:	54000300 	b.eq	8bbc <fwp_write+0x51c>  // b.none
    8b60:	b7f849c3 	tbnz	x3, #63, 9498 <fwp_write+0xdf8>
    8b64:	91002261 	add	x1, x19, #0x8
    8b68:	8b150021 	add	x1, x1, x21
    8b6c:	39400021 	ldrb	w1, [x1]
    8b70:	7100001f 	cmp	w0, #0x0
    8b74:	93401c23 	sxtb	x3, w1
    8b78:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8b7c:	d503201f 	nop
    8b80:	aa1403e0 	mov	x0, x20
    8b84:	52800003 	mov	w3, #0x0                   	// #0
    8b88:	97fffec6 	bl	86a0 <fwp_write>
    8b8c:	910006b5 	add	x21, x21, #0x1
    8b90:	f9400260 	ldr	x0, [x19]
    8b94:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8b98:	eb0002bf 	cmp	x21, x0
    8b9c:	540026c2 	b.cs	9074 <fwp_write+0x9d4>  // b.hs, b.nlast
    8ba0:	d2800042 	mov	x2, #0x2                   	// #2
    8ba4:	aa1603e1 	mov	x1, x22
    8ba8:	aa1403e0 	mov	x0, x20
    8bac:	97ffea79 	bl	3590 <buf_put>
    8bb0:	f9401f82 	ldr	x2, [x28, #56]
    8bb4:	f9400263 	ldr	x3, [x19]
    8bb8:	b5fffba2 	cbnz	x2, 8b2c <fwp_write+0x48c>
    8bbc:	d37df2a0 	lsl	x0, x21, #3
    8bc0:	b7f83f03 	tbnz	x3, #63, 93a0 <fwp_write+0xd00>
    8bc4:	91002261 	add	x1, x19, #0x8
    8bc8:	8b000020 	add	x0, x1, x0
    8bcc:	f9400001 	ldr	x1, [x0]
    8bd0:	17ffffec 	b	8b80 <fwp_write+0x4e0>
    8bd4:	a9400e62 	ldp	x2, x3, [x19]
    8bd8:	b7f83ca3 	tbnz	x3, #63, 936c <fwp_write+0xccc>
    8bdc:	910123f5 	add	x21, sp, #0x48
    8be0:	aa1503e0 	mov	x0, x21
    8be4:	97ffe88f 	bl	2e20 <fwp_fmt_u128>
    8be8:	aa1503e0 	mov	x0, x21
    8bec:	97ffe6c9 	bl	2710 <strlen@plt>
    8bf0:	aa1503e1 	mov	x1, x21
    8bf4:	aa0003e2 	mov	x2, x0
    8bf8:	17fffed0 	b	8738 <fwp_write+0x98>
    8bfc:	fd015be8 	str	d8, [sp, #688]
    8c00:	1e270268 	fmov	s8, w19
    8c04:	fd015fe9 	str	d9, [sp, #696]
    8c08:	1e282100 	fcmp	s8, s8
    8c0c:	54004d26 	b.vs	95b0 <fwp_write+0xf10>
    8c10:	1e20c101 	fabs	s1, s8
    8c14:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8c18:	1e270000 	fmov	s0, w0
    8c1c:	1e202020 	fcmp	s1, s0
    8c20:	54002c0d 	b.le	91a0 <fwp_write+0xb00>
    8c24:	1e202118 	fcmpe	s8, #0.0
    8c28:	b0000022 	adrp	x2, d000 <__divti3+0x1b0>
    8c2c:	91192042 	add	x2, x2, #0x648
    8c30:	910123f5 	add	x21, sp, #0x48
    8c34:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8c38:	912b6021 	add	x1, x1, #0xad8
    8c3c:	aa1503e0 	mov	x0, x21
    8c40:	9a81c041 	csel	x1, x2, x1, gt
    8c44:	97ffe75f 	bl	29c0 <strcpy@plt>
    8c48:	aa1503e0 	mov	x0, x21
    8c4c:	97ffe6b1 	bl	2710 <strlen@plt>
    8c50:	aa1503e1 	mov	x1, x21
    8c54:	aa0003e2 	mov	x2, x0
    8c58:	aa1403e0 	mov	x0, x20
    8c5c:	97ffea4d 	bl	3590 <buf_put>
    8c60:	f9413bf5 	ldr	x21, [sp, #624]
    8c64:	f9413ff6 	ldr	x22, [sp, #632]
    8c68:	f94153fb 	ldr	x27, [sp, #672]
    8c6c:	f94157fc 	ldr	x28, [sp, #680]
    8c70:	fd415be8 	ldr	d8, [sp, #688]
    8c74:	fd415fe9 	ldr	d9, [sp, #696]
    8c78:	17fffeb6 	b	8750 <fwp_write+0xb0>
    8c7c:	f9400276 	ldr	x22, [x19]
    8c80:	34002e03 	cbz	w3, 9240 <fwp_write+0xba0>
    8c84:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8c88:	f947f400 	ldr	x0, [x0, #4072]
    8c8c:	f94127e2 	ldr	x2, [sp, #584]
    8c90:	f9400001 	ldr	x1, [x0]
    8c94:	eb010042 	subs	x2, x2, x1
    8c98:	d2800001 	mov	x1, #0x0                   	// #0
    8c9c:	540014a1 	b.ne	8f30 <fwp_write+0x890>  // b.any
    8ca0:	aa1603e2 	mov	x2, x22
    8ca4:	91002261 	add	x1, x19, #0x8
    8ca8:	f9413bf5 	ldr	x21, [sp, #624]
    8cac:	aa1403e0 	mov	x0, x20
    8cb0:	f9413ff6 	ldr	x22, [sp, #632]
    8cb4:	17fffeff 	b	88b0 <fwp_write+0x210>
    8cb8:	fd015be8 	str	d8, [sp, #688]
    8cbc:	9e670268 	fmov	d8, x19
    8cc0:	fd015fe9 	str	d9, [sp, #696]
    8cc4:	1e682100 	fcmp	d8, d8
    8cc8:	54004746 	b.vs	95b0 <fwp_write+0xf10>
    8ccc:	1e60c101 	fabs	d1, d8
    8cd0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8cd4:	9e670000 	fmov	d0, x0
    8cd8:	910123f5 	add	x21, sp, #0x48
    8cdc:	52800033 	mov	w19, #0x1                   	// #1
    8ce0:	1e602020 	fcmp	d1, d0
    8ce4:	540001ad 	b.le	8d18 <fwp_write+0x678>
    8ce8:	1e602118 	fcmpe	d8, #0.0
    8cec:	b0000022 	adrp	x2, d000 <__divti3+0x1b0>
    8cf0:	91192042 	add	x2, x2, #0x648
    8cf4:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8cf8:	912b6021 	add	x1, x1, #0xad8
    8cfc:	aa1503e0 	mov	x0, x21
    8d00:	9a81c041 	csel	x1, x2, x1, gt
    8d04:	97ffe72f 	bl	29c0 <strcpy@plt>
    8d08:	17ffffd0 	b	8c48 <fwp_write+0x5a8>
    8d0c:	11000673 	add	w19, w19, #0x1
    8d10:	71004a7f 	cmp	w19, #0x12
    8d14:	54003860 	b.eq	9420 <fwp_write+0xd80>  // b.none
    8d18:	1e604100 	fmov	d0, d8
    8d1c:	2a1303e1 	mov	w1, w19
    8d20:	aa1503e0 	mov	x0, x21
    8d24:	97ffeb9c 	bl	3b94 <fwp_format_g.constprop.0>
    8d28:	aa1503e0 	mov	x0, x21
    8d2c:	d2800001 	mov	x1, #0x0                   	// #0
    8d30:	97ffe68c 	bl	2760 <strtod@plt>
    8d34:	1e602100 	fcmp	d8, d0
    8d38:	54fffea1 	b.ne	8d0c <fwp_write+0x66c>  // b.any
    8d3c:	aa1503e0 	mov	x0, x21
    8d40:	97ffea8d 	bl	3774 <fwp_finish_float>
    8d44:	17ffffc1 	b	8c48 <fwp_write+0x5a8>
    8d48:	a9400e62 	ldp	x2, x3, [x19]
    8d4c:	910123f3 	add	x19, sp, #0x48
    8d50:	aa1303e0 	mov	x0, x19
    8d54:	97ffe833 	bl	2e20 <fwp_fmt_u128>
    8d58:	17fffe74 	b	8728 <fwp_write+0x88>
    8d5c:	f90143f7 	str	x23, [sp, #640]
    8d60:	f90147f8 	str	x24, [sp, #648]
    8d64:	2a1303f8 	mov	w24, w19
    8d68:	f9014bf9 	str	x25, [sp, #656]
    8d6c:	f9014ffa 	str	x26, [sp, #664]
    8d70:	f13ffe7f 	cmp	x19, #0xfff
    8d74:	54000049 	b.ls	8d7c <fwp_write+0x6dc>  // b.plast
    8d78:	b9400278 	ldr	w24, [x19]
    8d7c:	f9400f80 	ldr	x0, [x28, #24]
    8d80:	2a1803f5 	mov	w21, w24
    8d84:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8d88:	d37ef6b9 	lsl	x25, x21, #2
    8d8c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8d90:	aa1603e0 	mov	x0, x22
    8d94:	97ffe65f 	bl	2710 <strlen@plt>
    8d98:	aa1603e1 	mov	x1, x22
    8d9c:	aa0003e2 	mov	x2, x0
    8da0:	aa1403e0 	mov	x0, x20
    8da4:	97ffe9fb 	bl	3590 <buf_put>
    8da8:	f9401780 	ldr	x0, [x28, #40]
    8dac:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8db0:	7100001f 	cmp	w0, #0x0
    8db4:	5400068d 	b.le	8e84 <fwp_write+0x7e4>
    8db8:	91002276 	add	x22, x19, #0x8
    8dbc:	91001ff5 	add	x21, sp, #0x7
    8dc0:	d280001b 	mov	x27, #0x0                   	// #0
    8dc4:	5280041a 	mov	w26, #0x20                  	// #32
    8dc8:	f9401b80 	ldr	x0, [x28, #48]
    8dcc:	aa1503e1 	mov	x1, x21
    8dd0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8dd4:	d2800022 	mov	x2, #0x1                   	// #1
    8dd8:	f8786803 	ldr	x3, [x0, x24]
    8ddc:	aa1403e0 	mov	x0, x20
    8de0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8de4:	39001ffa 	strb	w26, [sp, #7]
    8de8:	97ffe9ea 	bl	3590 <buf_put>
    8dec:	f13ffeff 	cmp	x23, #0xfff
    8df0:	b9400261 	ldr	w1, [x19]
    8df4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8df8:	7100383f 	cmp	w1, #0xe
    8dfc:	54000160 	b.eq	8e28 <fwp_write+0x788>  // b.none
    8e00:	7100403f 	cmp	w1, #0x10
    8e04:	54001a60 	b.eq	9150 <fwp_write+0xab0>  // b.none
    8e08:	7100283f 	cmp	w1, #0xa
    8e0c:	54002aa0 	b.eq	9360 <fwp_write+0xcc0>  // b.none
    8e10:	540014ac 	b.gt	90a4 <fwp_write+0xa04>
    8e14:	71000c3f 	cmp	w1, #0x3
    8e18:	540029ac 	b.gt	934c <fwp_write+0xcac>
    8e1c:	d37ffee0 	lsr	x0, x23, #63
    8e20:	37f814a1 	tbnz	w1, #31, 90b4 <fwp_write+0xa14>
    8e24:	d503201f 	nop
    8e28:	34001460 	cbz	w0, 90b4 <fwp_write+0xa14>
    8e2c:	52800503 	mov	w3, #0x28                  	// #40
    8e30:	aa1503e1 	mov	x1, x21
    8e34:	aa1403e0 	mov	x0, x20
    8e38:	d2800022 	mov	x2, #0x1                   	// #1
    8e3c:	39001fe3 	strb	w3, [sp, #7]
    8e40:	97ffe9d4 	bl	3590 <buf_put>
    8e44:	aa1303e2 	mov	x2, x19
    8e48:	aa1703e1 	mov	x1, x23
    8e4c:	aa1403e0 	mov	x0, x20
    8e50:	52800003 	mov	w3, #0x0                   	// #0
    8e54:	97fffe13 	bl	86a0 <fwp_write>
    8e58:	52800523 	mov	w3, #0x29                  	// #41
    8e5c:	aa1503e1 	mov	x1, x21
    8e60:	aa1403e0 	mov	x0, x20
    8e64:	d2800022 	mov	x2, #0x1                   	// #1
    8e68:	39001fe3 	strb	w3, [sp, #7]
    8e6c:	97ffe9c9 	bl	3590 <buf_put>
    8e70:	f9401780 	ldr	x0, [x28, #40]
    8e74:	9100077b 	add	x27, x27, #0x1
    8e78:	b8796800 	ldr	w0, [x0, x25]
    8e7c:	6b1b001f 	cmp	w0, w27
    8e80:	54fffa4c 	b.gt	8dc8 <fwp_write+0x728>
    8e84:	f9413bf5 	ldr	x21, [sp, #624]
    8e88:	f9413ff6 	ldr	x22, [sp, #632]
    8e8c:	f94143f7 	ldr	x23, [sp, #640]
    8e90:	f94147f8 	ldr	x24, [sp, #648]
    8e94:	f9414bf9 	ldr	x25, [sp, #656]
    8e98:	f9414ffa 	ldr	x26, [sp, #664]
    8e9c:	f94153fb 	ldr	x27, [sp, #672]
    8ea0:	f94157fc 	ldr	x28, [sp, #680]
    8ea4:	17fffe2b 	b	8750 <fwp_write+0xb0>
    8ea8:	52800783 	mov	w3, #0x3c                  	// #60
    8eac:	91001ff3 	add	x19, sp, #0x7
    8eb0:	aa1303e1 	mov	x1, x19
    8eb4:	d2800022 	mov	x2, #0x1                   	// #1
    8eb8:	aa1403e0 	mov	x0, x20
    8ebc:	39001fe3 	strb	w3, [sp, #7]
    8ec0:	97ffe9b4 	bl	3590 <buf_put>
    8ec4:	f9400795 	ldr	x21, [x28, #8]
    8ec8:	aa1503e0 	mov	x0, x21
    8ecc:	97ffe611 	bl	2710 <strlen@plt>
    8ed0:	aa1503e1 	mov	x1, x21
    8ed4:	aa0003e2 	mov	x2, x0
    8ed8:	aa1403e0 	mov	x0, x20
    8edc:	97ffe9ad 	bl	3590 <buf_put>
    8ee0:	528007c3 	mov	w3, #0x3e                  	// #62
    8ee4:	aa1303e1 	mov	x1, x19
    8ee8:	aa1403e0 	mov	x0, x20
    8eec:	d2800022 	mov	x2, #0x1                   	// #1
    8ef0:	39001fe3 	strb	w3, [sp, #7]
    8ef4:	17fffe12 	b	873c <fwp_write+0x9c>
    8ef8:	f100067f 	cmp	x19, #0x1
    8efc:	540025a0 	b.eq	93b0 <fwp_write+0xd10>  // b.none
    8f00:	b100067f 	cmn	x19, #0x1
    8f04:	54002bc0 	b.eq	947c <fwp_write+0xddc>  // b.none
    8f08:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8f0c:	912b8021 	add	x1, x1, #0xae0
    8f10:	d2800022 	mov	x2, #0x1                   	// #1
    8f14:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8f18:	f947f400 	ldr	x0, [x0, #4072]
    8f1c:	f94127e4 	ldr	x4, [sp, #584]
    8f20:	f9400003 	ldr	x3, [x0]
    8f24:	eb030084 	subs	x4, x4, x3
    8f28:	d2800003 	mov	x3, #0x0                   	// #0
    8f2c:	54ffebe0 	b.eq	8ca8 <fwp_write+0x608>  // b.none
    8f30:	f90143f7 	str	x23, [sp, #640]
    8f34:	f90147f8 	str	x24, [sp, #648]
    8f38:	f9014bf9 	str	x25, [sp, #656]
    8f3c:	f9014ffa 	str	x26, [sp, #664]
    8f40:	fd015be8 	str	d8, [sp, #688]
    8f44:	fd015fe9 	str	d9, [sp, #696]
    8f48:	97ffe64e 	bl	2880 <__stack_chk_fail@plt>
    8f4c:	52800b63 	mov	w3, #0x5b                  	// #91
    8f50:	91001ff5 	add	x21, sp, #0x7
    8f54:	aa1503e1 	mov	x1, x21
    8f58:	aa1403e0 	mov	x0, x20
    8f5c:	d2800022 	mov	x2, #0x1                   	// #1
    8f60:	b0000036 	adrp	x22, d000 <__divti3+0x1b0>
    8f64:	912e02d6 	add	x22, x22, #0xb80
    8f68:	39001fe3 	strb	w3, [sp, #7]
    8f6c:	97ffe989 	bl	3590 <buf_put>
    8f70:	b4000273 	cbz	x19, 8fbc <fwp_write+0x91c>
    8f74:	f9400661 	ldr	x1, [x19, #8]
    8f78:	aa1403e0 	mov	x0, x20
    8f7c:	f9401f82 	ldr	x2, [x28, #56]
    8f80:	52800003 	mov	w3, #0x0                   	// #0
    8f84:	97fffdc7 	bl	86a0 <fwp_write>
    8f88:	f9400a73 	ldr	x19, [x19, #16]
    8f8c:	b4000193 	cbz	x19, 8fbc <fwp_write+0x91c>
    8f90:	aa1603e1 	mov	x1, x22
    8f94:	aa1403e0 	mov	x0, x20
    8f98:	d2800042 	mov	x2, #0x2                   	// #2
    8f9c:	97ffe97d 	bl	3590 <buf_put>
    8fa0:	f9400661 	ldr	x1, [x19, #8]
    8fa4:	aa1403e0 	mov	x0, x20
    8fa8:	f9401f82 	ldr	x2, [x28, #56]
    8fac:	52800003 	mov	w3, #0x0                   	// #0
    8fb0:	97fffdbc 	bl	86a0 <fwp_write>
    8fb4:	f9400a73 	ldr	x19, [x19, #16]
    8fb8:	b5fffed3 	cbnz	x19, 8f90 <fwp_write+0x8f0>
    8fbc:	52800ba3 	mov	w3, #0x5d                  	// #93
    8fc0:	aa1503e1 	mov	x1, x21
    8fc4:	aa1403e0 	mov	x0, x20
    8fc8:	d2800022 	mov	x2, #0x1                   	// #1
    8fcc:	39001fe3 	strb	w3, [sp, #7]
    8fd0:	17fffddb 	b	873c <fwp_write+0x9c>
    8fd4:	aa1403e0 	mov	x0, x20
    8fd8:	b0000021 	adrp	x1, d000 <__divti3+0x1b0>
    8fdc:	d28000c2 	mov	x2, #0x6                   	// #6
    8fe0:	912dc021 	add	x1, x1, #0xb70
    8fe4:	97ffe96b 	bl	3590 <buf_put>
    8fe8:	f9400260 	ldr	x0, [x19]
    8fec:	b40004c0 	cbz	x0, 9084 <fwp_write+0x9e4>
    8ff0:	910123f5 	add	x21, sp, #0x48
    8ff4:	91002276 	add	x22, x19, #0x8
    8ff8:	f90143f7 	str	x23, [sp, #640]
    8ffc:	d2800017 	mov	x23, #0x0                   	// #0
    9000:	f90147f8 	str	x24, [sp, #648]
    9004:	90000038 	adrp	x24, d000 <__divti3+0x1b0>
    9008:	912de318 	add	x24, x24, #0xb78
    900c:	f9014bf9 	str	x25, [sp, #656]
    9010:	90000039 	adrp	x25, d000 <__divti3+0x1b0>
    9014:	912e0339 	add	x25, x25, #0xb80
    9018:	f9014ffa 	str	x26, [sp, #664]
    901c:	14000005 	b	9030 <fwp_write+0x990>
    9020:	aa1903e1 	mov	x1, x25
    9024:	aa1403e0 	mov	x0, x20
    9028:	d2800042 	mov	x2, #0x2                   	// #2
    902c:	97ffe959 	bl	3590 <buf_put>
    9030:	38776ac5 	ldrb	w5, [x22, x23]
    9034:	d2804003 	mov	x3, #0x200                 	// #512
    9038:	aa1803e4 	mov	x4, x24
    903c:	aa0303e1 	mov	x1, x3
    9040:	52800042 	mov	w2, #0x2                   	// #2
    9044:	aa1503e0 	mov	x0, x21
    9048:	910006f7 	add	x23, x23, #0x1
    904c:	97ffe5e9 	bl	27f0 <__snprintf_chk@plt>
    9050:	aa1503e0 	mov	x0, x21
    9054:	97ffe5af 	bl	2710 <strlen@plt>
    9058:	aa1503e1 	mov	x1, x21
    905c:	aa0003e2 	mov	x2, x0
    9060:	aa1403e0 	mov	x0, x20
    9064:	97ffe94b 	bl	3590 <buf_put>
    9068:	f9400260 	ldr	x0, [x19]
    906c:	eb17001f 	cmp	x0, x23
    9070:	54fffd88 	b.hi	9020 <fwp_write+0x980>  // b.pmore
    9074:	f94143f7 	ldr	x23, [sp, #640]
    9078:	f94147f8 	ldr	x24, [sp, #648]
    907c:	f9414bf9 	ldr	x25, [sp, #656]
    9080:	f9414ffa 	ldr	x26, [sp, #664]
    9084:	52800ba3 	mov	w3, #0x5d                  	// #93
    9088:	aa1403e0 	mov	x0, x20
    908c:	91001fe1 	add	x1, sp, #0x7
    9090:	d2800022 	mov	x2, #0x1                   	// #1
    9094:	39001fe3 	strb	w3, [sp, #7]
    9098:	17fffda9 	b	873c <fwp_write+0x9c>
    909c:	52800fa3 	mov	w3, #0x7d                  	// #125
    90a0:	17fffe44 	b	89b0 <fwp_write+0x310>
    90a4:	f10002ff 	cmp	x23, #0x0
    90a8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    90ac:	71002c3f 	cmp	w1, #0xb
    90b0:	54ffebc0 	b.eq	8e28 <fwp_write+0x788>  // b.none
    90b4:	aa1303e2 	mov	x2, x19
    90b8:	aa1703e1 	mov	x1, x23
    90bc:	aa1403e0 	mov	x0, x20
    90c0:	52800003 	mov	w3, #0x0                   	// #0
    90c4:	97fffd77 	bl	86a0 <fwp_write>
    90c8:	17ffff6a 	b	8e70 <fwp_write+0x7d0>
    90cc:	aa1403e0 	mov	x0, x20
    90d0:	91001fe1 	add	x1, sp, #0x7
    90d4:	52800fa3 	mov	w3, #0x7d                  	// #125
    90d8:	d2800022 	mov	x2, #0x1                   	// #1
    90dc:	17fffe38 	b	89bc <fwp_write+0x31c>
    90e0:	a9400281 	ldp	x1, x0, [x20]
    90e4:	91000800 	add	x0, x0, #0x2
    90e8:	8b160000 	add	x0, x0, x22
    90ec:	f9000680 	str	x0, [x20, #8]
    90f0:	3820683f 	strb	wzr, [x1, x0]
    90f4:	f9413bf5 	ldr	x21, [sp, #624]
    90f8:	f9413ff6 	ldr	x22, [sp, #632]
    90fc:	f94153fb 	ldr	x27, [sp, #672]
    9100:	f94157fc 	ldr	x28, [sp, #680]
    9104:	17fffd93 	b	8750 <fwp_write+0xb0>
    9108:	f9400f80 	ldr	x0, [x28, #24]
    910c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9110:	aa1b03e0 	mov	x0, x27
    9114:	97ffe57f 	bl	2710 <strlen@plt>
    9118:	aa1b03e1 	mov	x1, x27
    911c:	aa0003e2 	mov	x2, x0
    9120:	aa1403e0 	mov	x0, x20
    9124:	97ffe91b 	bl	3590 <buf_put>
    9128:	aa1903e1 	mov	x1, x25
    912c:	aa1403e0 	mov	x0, x20
    9130:	d2800062 	mov	x2, #0x3                   	// #3
    9134:	97ffe917 	bl	3590 <buf_put>
    9138:	17fffe10 	b	8978 <fwp_write+0x2d8>
    913c:	aa1a03e1 	mov	x1, x26
    9140:	aa1403e0 	mov	x0, x20
    9144:	d2800042 	mov	x2, #0x2                   	// #2
    9148:	97ffe912 	bl	3590 <buf_put>
    914c:	17fffe09 	b	8970 <fwp_write+0x2d0>
    9150:	f9400660 	ldr	x0, [x19, #8]
    9154:	b4fffb00 	cbz	x0, 90b4 <fwp_write+0xa14>
    9158:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    915c:	912e6021 	add	x1, x1, #0xb98
    9160:	97ffe5e8 	bl	2900 <strcmp@plt>
    9164:	7100001f 	cmp	w0, #0x0
    9168:	1a9f07e0 	cset	w0, ne	// ne = any
    916c:	17ffff2f 	b	8e28 <fwp_write+0x788>
    9170:	aa1403e0 	mov	x0, x20
    9174:	d2800042 	mov	x2, #0x2                   	// #2
    9178:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    917c:	912e4021 	add	x1, x1, #0xb90
    9180:	97ffe904 	bl	3590 <buf_put>
    9184:	91004261 	add	x1, x19, #0x10
    9188:	aa1403e0 	mov	x0, x20
    918c:	f9402382 	ldr	x2, [x28, #64]
    9190:	52800003 	mov	w3, #0x0                   	// #0
    9194:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9198:	97fffd42 	bl	86a0 <fwp_write>
    919c:	17fffd9c 	b	880c <fwp_write+0x16c>
    91a0:	1e22c109 	fcvt	d9, s8
    91a4:	910123f5 	add	x21, sp, #0x48
    91a8:	52800033 	mov	w19, #0x1                   	// #1
    91ac:	d503201f 	nop
    91b0:	1e604120 	fmov	d0, d9
    91b4:	2a1303e1 	mov	w1, w19
    91b8:	aa1503e0 	mov	x0, x21
    91bc:	97ffea76 	bl	3b94 <fwp_format_g.constprop.0>
    91c0:	aa1503e0 	mov	x0, x21
    91c4:	d2800001 	mov	x1, #0x0                   	// #0
    91c8:	97ffe5da 	bl	2930 <strtof@plt>
    91cc:	1e202100 	fcmp	s8, s0
    91d0:	54ffdb60 	b.eq	8d3c <fwp_write+0x69c>  // b.none
    91d4:	11000673 	add	w19, w19, #0x1
    91d8:	71002a7f 	cmp	w19, #0xa
    91dc:	54fffea1 	b.ne	91b0 <fwp_write+0xb10>  // b.any
    91e0:	1e604120 	fmov	d0, d9
    91e4:	aa1503e0 	mov	x0, x21
    91e8:	52800121 	mov	w1, #0x9                   	// #9
    91ec:	97ffea6a 	bl	3b94 <fwp_format_g.constprop.0>
    91f0:	17fffed3 	b	8d3c <fwp_write+0x69c>
    91f4:	d37ef6a1 	lsl	x1, x21, #2
    91f8:	b7f81563 	tbnz	x3, #63, 94a4 <fwp_write+0xe04>
    91fc:	91002263 	add	x3, x19, #0x8
    9200:	8b010061 	add	x1, x3, x1
    9204:	b9400023 	ldr	w3, [x1]
    9208:	7100081f 	cmp	w0, #0x2
    920c:	2a0303e1 	mov	w1, w3
    9210:	93407c63 	sxtw	x3, w3
    9214:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9218:	17fffe5a 	b	8b80 <fwp_write+0x4e0>
    921c:	d37ffaa1 	lsl	x1, x21, #1
    9220:	b7f81363 	tbnz	x3, #63, 948c <fwp_write+0xdec>
    9224:	91002263 	add	x3, x19, #0x8
    9228:	8b010061 	add	x1, x3, x1
    922c:	79400021 	ldrh	w1, [x1]
    9230:	7100041f 	cmp	w0, #0x1
    9234:	93403c23 	sxth	x3, w1
    9238:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    923c:	17fffe51 	b	8b80 <fwp_write+0x4e0>
    9240:	52800443 	mov	w3, #0x22                  	// #34
    9244:	91001ff5 	add	x21, sp, #0x7
    9248:	91002273 	add	x19, x19, #0x8
    924c:	aa1503e1 	mov	x1, x21
    9250:	aa1403e0 	mov	x0, x20
    9254:	d2800022 	mov	x2, #0x1                   	// #1
    9258:	39001fe3 	strb	w3, [sp, #7]
    925c:	f90143f7 	str	x23, [sp, #640]
    9260:	8b160277 	add	x23, x19, x22
    9264:	f90147f8 	str	x24, [sp, #648]
    9268:	97ffe8ca 	bl	3590 <buf_put>
    926c:	b4000696 	cbz	x22, 933c <fwp_write+0xc9c>
    9270:	90000038 	adrp	x24, d000 <__divti3+0x1b0>
    9274:	912d0318 	add	x24, x24, #0xb40
    9278:	f9014bf9 	str	x25, [sp, #656]
    927c:	90000039 	adrp	x25, d000 <__divti3+0x1b0>
    9280:	912d8339 	add	x25, x25, #0xb60
    9284:	f9014ffa 	str	x26, [sp, #664]
    9288:	1400000d 	b	92bc <fwp_write+0xc1c>
    928c:	710024bf 	cmp	w5, #0x9
    9290:	54000460 	b.eq	931c <fwp_write+0xc7c>  // b.none
    9294:	710028bf 	cmp	w5, #0xa
    9298:	54000a61 	b.ne	93e4 <fwp_write+0xd44>  // b.any
    929c:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    92a0:	aa1403e0 	mov	x0, x20
    92a4:	912d4021 	add	x1, x1, #0xb50
    92a8:	d2800042 	mov	x2, #0x2                   	// #2
    92ac:	97ffe8b9 	bl	3590 <buf_put>
    92b0:	91000673 	add	x19, x19, #0x1
    92b4:	eb17027f 	cmp	x19, x23
    92b8:	540003e0 	b.eq	9334 <fwp_write+0xc94>  // b.none
    92bc:	39400265 	ldrb	w5, [x19]
    92c0:	710034bf 	cmp	w5, #0xd
    92c4:	54000180 	b.eq	92f4 <fwp_write+0xc54>  // b.none
    92c8:	54fffe29 	b.ls	928c <fwp_write+0xbec>  // b.plast
    92cc:	710088bf 	cmp	w5, #0x22
    92d0:	540001c0 	b.eq	9308 <fwp_write+0xc68>  // b.none
    92d4:	710170bf 	cmp	w5, #0x5c
    92d8:	54000741 	b.ne	93c0 <fwp_write+0xd20>  // b.any
    92dc:	aa1403e0 	mov	x0, x20
    92e0:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    92e4:	d2800042 	mov	x2, #0x2                   	// #2
    92e8:	912d2021 	add	x1, x1, #0xb48
    92ec:	97ffe8a9 	bl	3590 <buf_put>
    92f0:	17fffff0 	b	92b0 <fwp_write+0xc10>
    92f4:	aa1903e1 	mov	x1, x25
    92f8:	aa1403e0 	mov	x0, x20
    92fc:	d2800042 	mov	x2, #0x2                   	// #2
    9300:	97ffe8a4 	bl	3590 <buf_put>
    9304:	17ffffeb 	b	92b0 <fwp_write+0xc10>
    9308:	aa1803e1 	mov	x1, x24
    930c:	aa1403e0 	mov	x0, x20
    9310:	d2800042 	mov	x2, #0x2                   	// #2
    9314:	97ffe89f 	bl	3590 <buf_put>
    9318:	17ffffe6 	b	92b0 <fwp_write+0xc10>
    931c:	aa1403e0 	mov	x0, x20
    9320:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    9324:	d2800042 	mov	x2, #0x2                   	// #2
    9328:	912d6021 	add	x1, x1, #0xb58
    932c:	97ffe899 	bl	3590 <buf_put>
    9330:	17ffffe0 	b	92b0 <fwp_write+0xc10>
    9334:	f9414bf9 	ldr	x25, [sp, #656]
    9338:	f9414ffa 	ldr	x26, [sp, #664]
    933c:	aa1503e1 	mov	x1, x21
    9340:	aa1403e0 	mov	x0, x20
    9344:	52800443 	mov	w3, #0x22                  	// #34
    9348:	17fffd9c 	b	89b8 <fwp_write+0x318>
    934c:	7100103f 	cmp	w1, #0x4
    9350:	54ffeb21 	b.ne	90b4 <fwp_write+0xa14>  // b.any
    9354:	f94006e0 	ldr	x0, [x23, #8]
    9358:	d37ffc00 	lsr	x0, x0, #63
    935c:	17fffeb3 	b	8e28 <fwp_write+0x788>
    9360:	710002ff 	cmp	w23, #0x0
    9364:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9368:	17fffeb0 	b	8e28 <fwp_write+0x788>
    936c:	528005a1 	mov	w1, #0x2d                  	// #45
    9370:	eb0203e2 	negs	x2, x2
    9374:	da0303e3 	ngc	x3, x3
    9378:	910127e0 	add	x0, sp, #0x49
    937c:	910123f5 	add	x21, sp, #0x48
    9380:	390123e1 	strb	w1, [sp, #72]
    9384:	97ffe6a7 	bl	2e20 <fwp_fmt_u128>
    9388:	17fffe18 	b	8be8 <fwp_write+0x548>
    938c:	d37ceea1 	lsl	x1, x21, #4
    9390:	b7f810a3 	tbnz	x3, #63, 95a4 <fwp_write+0xf04>
    9394:	91002260 	add	x0, x19, #0x8
    9398:	8b010001 	add	x1, x0, x1
    939c:	17fffdf9 	b	8b80 <fwp_write+0x4e0>
    93a0:	f9400a61 	ldr	x1, [x19, #16]
    93a4:	8b010000 	add	x0, x0, x1
    93a8:	f9400001 	ldr	x1, [x0]
    93ac:	17fffdf5 	b	8b80 <fwp_write+0x4e0>
    93b0:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    93b4:	d2800042 	mov	x2, #0x2                   	// #2
    93b8:	912ba021 	add	x1, x1, #0xae8
    93bc:	17fffed6 	b	8f14 <fwp_write+0x874>
    93c0:	7101fcbf 	cmp	w5, #0x7f
    93c4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    93c8:	540000e9 	b.ls	93e4 <fwp_write+0xd44>  // b.plast
    93cc:	aa1503e1 	mov	x1, x21
    93d0:	aa1403e0 	mov	x0, x20
    93d4:	d2800022 	mov	x2, #0x1                   	// #1
    93d8:	39001fe5 	strb	w5, [sp, #7]
    93dc:	97ffe86d 	bl	3590 <buf_put>
    93e0:	17ffffb4 	b	92b0 <fwp_write+0xc10>
    93e4:	d2800203 	mov	x3, #0x10                  	// #16
    93e8:	90000024 	adrp	x4, d000 <__divti3+0x1b0>
    93ec:	aa0303e1 	mov	x1, x3
    93f0:	912da084 	add	x4, x4, #0xb68
    93f4:	910123f6 	add	x22, sp, #0x48
    93f8:	52800042 	mov	w2, #0x2                   	// #2
    93fc:	aa1603e0 	mov	x0, x22
    9400:	97ffe4fc 	bl	27f0 <__snprintf_chk@plt>
    9404:	aa1603e0 	mov	x0, x22
    9408:	97ffe4c2 	bl	2710 <strlen@plt>
    940c:	aa1603e1 	mov	x1, x22
    9410:	aa0003e2 	mov	x2, x0
    9414:	aa1403e0 	mov	x0, x20
    9418:	97ffe85e 	bl	3590 <buf_put>
    941c:	17ffffa5 	b	92b0 <fwp_write+0xc10>
    9420:	1e604100 	fmov	d0, d8
    9424:	aa1503e0 	mov	x0, x21
    9428:	52800221 	mov	w1, #0x11                  	// #17
    942c:	97ffe9da 	bl	3b94 <fwp_format_g.constprop.0>
    9430:	17fffe43 	b	8d3c <fwp_write+0x69c>
    9434:	b9401040 	ldr	w0, [x2, #16]
    9438:	350003c0 	cbnz	w0, 94b0 <fwp_write+0xe10>
    943c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9440:	f947f400 	ldr	x0, [x0, #4072]
    9444:	f94127e2 	ldr	x2, [sp, #584]
    9448:	f9400001 	ldr	x1, [x0]
    944c:	eb010042 	subs	x2, x2, x1
    9450:	d2800001 	mov	x1, #0x0                   	// #0
    9454:	54ffd721 	b.ne	8f38 <fwp_write+0x898>  // b.any
    9458:	f9413bf5 	ldr	x21, [sp, #624]
    945c:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    9460:	f9413ff6 	ldr	x22, [sp, #632]
    9464:	aa1403e0 	mov	x0, x20
    9468:	f94143f7 	ldr	x23, [sp, #640]
    946c:	912ee021 	add	x1, x1, #0xbb8
    9470:	f94147f8 	ldr	x24, [sp, #648]
    9474:	d2800042 	mov	x2, #0x2                   	// #2
    9478:	17fffd0e 	b	88b0 <fwp_write+0x210>
    947c:	90000021 	adrp	x1, d000 <__divti3+0x1b0>
    9480:	d2800042 	mov	x2, #0x2                   	// #2
    9484:	912bc021 	add	x1, x1, #0xaf0
    9488:	17fffea3 	b	8f14 <fwp_write+0x874>
    948c:	f9400a63 	ldr	x3, [x19, #16]
    9490:	8b030021 	add	x1, x1, x3
    9494:	17ffff66 	b	922c <fwp_write+0xb8c>
    9498:	f9400a61 	ldr	x1, [x19, #16]
    949c:	8b0102a1 	add	x1, x21, x1
    94a0:	17fffdb3 	b	8b6c <fwp_write+0x4cc>
    94a4:	f9400a63 	ldr	x3, [x19, #16]
    94a8:	8b030021 	add	x1, x1, x3
    94ac:	17ffff56 	b	9204 <fwp_write+0xb64>
    94b0:	b9404840 	ldr	w0, [x2, #72]
    94b4:	91001ff5 	add	x21, sp, #0x7
    94b8:	34ffa360 	cbz	w0, 8924 <fwp_write+0x284>
    94bc:	52800503 	mov	w3, #0x28                  	// #40
    94c0:	aa1403e0 	mov	x0, x20
    94c4:	aa1503e1 	mov	x1, x21
    94c8:	d2800022 	mov	x2, #0x1                   	// #1
    94cc:	39001fe3 	strb	w3, [sp, #7]
    94d0:	97ffe830 	bl	3590 <buf_put>
    94d4:	b9401380 	ldr	w0, [x28, #16]
    94d8:	52800038 	mov	w24, #0x1                   	// #1
    94dc:	7100001f 	cmp	w0, #0x0
    94e0:	54ffa36c 	b.gt	894c <fwp_write+0x2ac>
    94e4:	17fffd32 	b	89ac <fwp_write+0x30c>
    94e8:	f9014bf9 	str	x25, [sp, #656]
    94ec:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe788>
    94f0:	f9014ffa 	str	x26, [sp, #664]
    94f4:	f9400676 	ldr	x22, [x19, #8]
    94f8:	91102333 	add	x19, x25, #0x408
    94fc:	91002273 	add	x19, x19, #0x8
    9500:	937ffed8 	asr	x24, x22, #63
    9504:	aa1802c0 	orr	x0, x22, x24
    9508:	b5000320 	cbnz	x0, 956c <fwp_write+0xecc>
    950c:	110006b5 	add	w21, w21, #0x1
    9510:	710016bf 	cmp	w21, #0x5
    9514:	54ffffc1 	b.ne	950c <fwp_write+0xe6c>  // b.any
    9518:	b7f80578 	tbnz	x24, #63, 95c4 <fwp_write+0xf24>
    951c:	910023f3 	add	x19, sp, #0x8
    9520:	aa1603e2 	mov	x2, x22
    9524:	aa1303e0 	mov	x0, x19
    9528:	d2800003 	mov	x3, #0x0                   	// #0
    952c:	97ffe63d 	bl	2e20 <fwp_fmt_u128>
    9530:	910123f5 	add	x21, sp, #0x48
    9534:	90000023 	adrp	x3, d000 <__divti3+0x1b0>
    9538:	aa1303e4 	mov	x4, x19
    953c:	aa1503e0 	mov	x0, x21
    9540:	912ec063 	add	x3, x3, #0xbb0
    9544:	d2804002 	mov	x2, #0x200                 	// #512
    9548:	52800041 	mov	w1, #0x2                   	// #2
    954c:	97ffe475 	bl	2720 <__sprintf_chk@plt>
    9550:	aa1503e0 	mov	x0, x21
    9554:	97ffe46f 	bl	2710 <strlen@plt>
    9558:	aa1503e1 	mov	x1, x21
    955c:	aa0003e2 	mov	x2, x0
    9560:	aa1403e0 	mov	x0, x20
    9564:	97ffe80b 	bl	3590 <buf_put>
    9568:	17fffe47 	b	8e84 <fwp_write+0x7e4>
    956c:	f9400277 	ldr	x23, [x19]
    9570:	aa1603e0 	mov	x0, x22
    9574:	aa1803e1 	mov	x1, x24
    9578:	aa1703e2 	mov	x2, x23
    957c:	937ffefa 	asr	x26, x23, #63
    9580:	aa1a03e3 	mov	x3, x26
    9584:	94000f13 	bl	d1d0 <__modti3>
    9588:	aa010000 	orr	x0, x0, x1
    958c:	b40002c0 	cbz	x0, 95e4 <fwp_write+0xf44>
    9590:	110006b5 	add	w21, w21, #0x1
    9594:	91004273 	add	x19, x19, #0x10
    9598:	710016bf 	cmp	w21, #0x5
    959c:	54fffe81 	b.ne	956c <fwp_write+0xecc>  // b.any
    95a0:	17ffffde 	b	9518 <fwp_write+0xe78>
    95a4:	f9400a60 	ldr	x0, [x19, #16]
    95a8:	8b000021 	add	x1, x1, x0
    95ac:	17fffd75 	b	8b80 <fwp_write+0x4e0>
    95b0:	528c29c0 	mov	w0, #0x614e                	// #24910
    95b4:	910123f5 	add	x21, sp, #0x48
    95b8:	72a009c0 	movk	w0, #0x4e, lsl #16
    95bc:	b9004be0 	str	w0, [sp, #72]
    95c0:	17fffda2 	b	8c48 <fwp_write+0x5a8>
    95c4:	528005a1 	mov	w1, #0x2d                  	// #45
    95c8:	eb1603e2 	negs	x2, x22
    95cc:	da1803e3 	ngc	x3, x24
    95d0:	910027e0 	add	x0, sp, #0x9
    95d4:	910023f3 	add	x19, sp, #0x8
    95d8:	390023e1 	strb	w1, [sp, #8]
    95dc:	97ffe611 	bl	2e20 <fwp_fmt_u128>
    95e0:	17ffffd4 	b	9530 <fwp_write+0xe90>
    95e4:	aa1703e2 	mov	x2, x23
    95e8:	aa1a03e3 	mov	x3, x26
    95ec:	aa1603e0 	mov	x0, x22
    95f0:	aa1803e1 	mov	x1, x24
    95f4:	94000e17 	bl	ce50 <__divti3>
    95f8:	aa0003e2 	mov	x2, x0
    95fc:	aa0103e3 	mov	x3, x1
    9600:	b7f80201 	tbnz	x1, #63, 9640 <fwp_write+0xfa0>
    9604:	910023f3 	add	x19, sp, #0x8
    9608:	aa1303e0 	mov	x0, x19
    960c:	97ffe605 	bl	2e20 <fwp_fmt_u128>
    9610:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9614:	91102339 	add	x25, x25, #0x408
    9618:	910123f5 	add	x21, sp, #0x48
    961c:	aa1303e4 	mov	x4, x19
    9620:	aa1503e0 	mov	x0, x21
    9624:	90000023 	adrp	x3, d000 <__divti3+0x1b0>
    9628:	f8616b25 	ldr	x5, [x25, x1]
    962c:	912ea063 	add	x3, x3, #0xba8
    9630:	d2804002 	mov	x2, #0x200                 	// #512
    9634:	52800041 	mov	w1, #0x2                   	// #2
    9638:	97ffe43a 	bl	2720 <__sprintf_chk@plt>
    963c:	17ffffc5 	b	9550 <fwp_write+0xeb0>
    9640:	528005a4 	mov	w4, #0x2d                  	// #45
    9644:	eb0003e2 	negs	x2, x0
    9648:	da0103e3 	ngc	x3, x1
    964c:	910027e0 	add	x0, sp, #0x9
    9650:	910023f3 	add	x19, sp, #0x8
    9654:	390023e4 	strb	w4, [sp, #8]
    9658:	97ffe5f2 	bl	2e20 <fwp_fmt_u128>
    965c:	17ffffed 	b	9610 <fwp_write+0xf70>
    9660:	f9013bf5 	str	x21, [sp, #624]
    9664:	f9013ff6 	str	x22, [sp, #632]
    9668:	f90143f7 	str	x23, [sp, #640]
    966c:	f90147f8 	str	x24, [sp, #648]
    9670:	f9014bf9 	str	x25, [sp, #656]
    9674:	f9014ffa 	str	x26, [sp, #664]
    9678:	f90153fb 	str	x27, [sp, #672]
    967c:	f90157fc 	str	x28, [sp, #680]
    9680:	fd015be8 	str	d8, [sp, #688]
    9684:	fd015fe9 	str	d9, [sp, #696]
    9688:	97ffe47e 	bl	2880 <__stack_chk_fail@plt>
    968c:	d503201f 	nop

0000000000009690 <fwp_hof0.constprop.0>:
    9690:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9694:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9698:	f947f442 	ldr	x2, [x2, #4072]
    969c:	910003fd 	mov	x29, sp
    96a0:	a90153f3 	stp	x19, x20, [sp, #16]
    96a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    96a8:	a90363f7 	stp	x23, x24, [sp, #48]
    96ac:	aa0003f7 	mov	x23, x0
    96b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    96b4:	a90573fb 	stp	x27, x28, [sp, #80]
    96b8:	d10243ff 	sub	sp, sp, #0x90
    96bc:	f9400040 	ldr	x0, [x2]
    96c0:	f81f83a0 	stur	x0, [x29, #-8]
    96c4:	d2800000 	mov	x0, #0x0                   	// #0
    96c8:	b4002da1 	cbz	x1, 9c7c <fwp_hof0.constprop.0+0x5ec>
    96cc:	f00000a0 	adrp	x0, 20000 <__data_start>
    96d0:	9100401c 	add	x28, x0, #0x10
    96d4:	9101039c 	add	x28, x28, #0x40
    96d8:	f00000a0 	adrp	x0, 20000 <__data_start>
    96dc:	aa0103fa 	mov	x26, x1
    96e0:	d10083b4 	sub	x20, x29, #0x20
    96e4:	9101c015 	add	x21, x0, #0x70
    96e8:	aa1c03f8 	mov	x24, x28
    96ec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    96f0:	91174002 	add	x2, x0, #0x5d0
    96f4:	f949d841 	ldr	x1, [x2, #5040]
    96f8:	f949ec40 	ldr	x0, [x2, #5080]
    96fc:	cb0102e1 	sub	x1, x23, x1
    9700:	eb00403f 	cmp	x1, x0, lsl #16
    9704:	54000342 	b.cs	976c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9708:	d350fc20 	lsr	x0, x1, #16
    970c:	f949fc44 	ldr	x4, [x2, #5112]
    9710:	8b000800 	add	x0, x0, x0, lsl #2
    9714:	d37df002 	lsl	x2, x0, #3
    9718:	8b020083 	add	x3, x4, x2
    971c:	f9401060 	ldr	x0, [x3, #32]
    9720:	b4000260 	cbz	x0, 976c <fwp_hof0.constprop.0+0xdc>
    9724:	38626882 	ldrb	w2, [x4, x2]
    9728:	7100085f 	cmp	w2, #0x2
    972c:	54005240 	b.eq	a174 <fwp_hof0.constprop.0+0xae4>  // b.none
    9730:	7100045f 	cmp	w2, #0x1
    9734:	540001c1 	b.ne	976c <fwp_hof0.constprop.0+0xdc>  // b.any
    9738:	29430864 	ldp	w4, w2, [x3, #24]
    973c:	92403c21 	and	x1, x1, #0xffff
    9740:	9b047c21 	mul	x1, x1, x4
    9744:	d360fc21 	lsr	x1, x1, #32
    9748:	eb02003f 	cmp	x1, x2
    974c:	54000102 	b.cs	976c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9750:	8b010000 	add	x0, x0, x1
    9754:	39400001 	ldrb	w1, [x0]
    9758:	340000a1 	cbz	w1, 976c <fwp_hof0.constprop.0+0xdc>
    975c:	7103f43f 	cmp	w1, #0xfd
    9760:	54005728 	b.hi	a244 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    9764:	11000421 	add	w1, w1, #0x1
    9768:	39000001 	strb	w1, [x0]
    976c:	aa1703f9 	mov	x25, x23
    9770:	a938dfba 	stp	x26, x23, [x29, #-120]
    9774:	aa1803fa 	mov	x26, x24
    9778:	d28018f3 	mov	x19, #0xc7                  	// #199
    977c:	f81983b3 	stur	x19, [x29, #-104]
    9780:	f00000a0 	adrp	x0, 20000 <__data_start>
    9784:	91004000 	add	x0, x0, #0x10
    9788:	f94046a3 	ldr	x3, [x21, #136]
    978c:	91010005 	add	x5, x0, #0x40
    9790:	b9404002 	ldr	w2, [x0, #64]
    9794:	d37be842 	lsl	x2, x2, #5
    9798:	8b02007b 	add	x27, x3, x2
    979c:	f9400f61 	ldr	x1, [x27, #24]
    97a0:	f81e03b9 	stur	x25, [x29, #-32]
    97a4:	b4004ee1 	cbz	x1, a180 <fwp_hof0.constprop.0+0xaf0>
    97a8:	f9400c20 	ldr	x0, [x1, #24]
    97ac:	b40042a0 	cbz	x0, a000 <fwp_hof0.constprop.0+0x970>
    97b0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    97b4:	91174002 	add	x2, x0, #0x5d0
    97b8:	f949d841 	ldr	x1, [x2, #5040]
    97bc:	f949ec40 	ldr	x0, [x2, #5080]
    97c0:	cb010341 	sub	x1, x26, x1
    97c4:	eb00403f 	cmp	x1, x0, lsl #16
    97c8:	54000342 	b.cs	9830 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    97cc:	d350fc20 	lsr	x0, x1, #16
    97d0:	f949fc45 	ldr	x5, [x2, #5112]
    97d4:	8b000800 	add	x0, x0, x0, lsl #2
    97d8:	d37df002 	lsl	x2, x0, #3
    97dc:	8b0200a3 	add	x3, x5, x2
    97e0:	f9401060 	ldr	x0, [x3, #32]
    97e4:	b4000260 	cbz	x0, 9830 <fwp_hof0.constprop.0+0x1a0>
    97e8:	386268a2 	ldrb	w2, [x5, x2]
    97ec:	7100085f 	cmp	w2, #0x2
    97f0:	54004700 	b.eq	a0d0 <fwp_hof0.constprop.0+0xa40>  // b.none
    97f4:	7100045f 	cmp	w2, #0x1
    97f8:	540001c1 	b.ne	9830 <fwp_hof0.constprop.0+0x1a0>  // b.any
    97fc:	29430865 	ldp	w5, w2, [x3, #24]
    9800:	92403c21 	and	x1, x1, #0xffff
    9804:	9b057c21 	mul	x1, x1, x5
    9808:	d360fc21 	lsr	x1, x1, #32
    980c:	eb02003f 	cmp	x1, x2
    9810:	54000102 	b.cs	9830 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    9814:	8b010000 	add	x0, x0, x1
    9818:	39400001 	ldrb	w1, [x0]
    981c:	340000a1 	cbz	w1, 9830 <fwp_hof0.constprop.0+0x1a0>
    9820:	7103f43f 	cmp	w1, #0xfd
    9824:	54004988 	b.hi	a154 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    9828:	11000421 	add	w1, w1, #0x1
    982c:	39000001 	strb	w1, [x0]
    9830:	aa1a03f9 	mov	x25, x26
    9834:	aa1a03e0 	mov	x0, x26
    9838:	aa1b03e3 	mov	x3, x27
    983c:	52800037 	mov	w23, #0x1                   	// #1
    9840:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9844:	91174036 	add	x22, x1, #0x5d0
    9848:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    984c:	f81b03b6 	stur	x22, [x29, #-80]
    9850:	b81cc3b7 	stur	w23, [x29, #-52]
    9854:	f81d03b4 	stur	x20, [x29, #-48]
    9858:	b9400401 	ldr	w1, [x0, #4]
    985c:	b9400078 	ldr	w24, [x3]
    9860:	b85cc3a0 	ldur	w0, [x29, #-52]
    9864:	4b010318 	sub	w24, w24, w1
    9868:	6b17031f 	cmp	w24, w23
    986c:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9870:	6b0000ff 	cmp	w7, w0
    9874:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9878:	b81c83a0 	stur	w0, [x29, #-56]
    987c:	6b0000e2 	subs	w2, w7, w0
    9880:	54000120 	b.eq	98a4 <fwp_hof0.constprop.0+0x214>  // b.none
    9884:	f9400c63 	ldr	x3, [x3, #24]
    9888:	0b000021 	add	w1, w1, w0
    988c:	f85d03a4 	ldur	x4, [x29, #-48]
    9890:	b81d83a7 	stur	w7, [x29, #-40]
    9894:	f9400863 	ldr	x3, [x3, #16]
    9898:	8b204c80 	add	x0, x4, w0, uxtw #3
    989c:	d63f0060 	blr	x3
    98a0:	b85d83a7 	ldur	w7, [x29, #-40]
    98a4:	f94046a0 	ldr	x0, [x21, #136]
    98a8:	aa1903e6 	mov	x6, x25
    98ac:	b9400323 	ldr	w3, [x25]
    98b0:	2a0703f4 	mov	w20, w7
    98b4:	f85d03bb 	ldur	x27, [x29, #-48]
    98b8:	aa1903fc 	mov	x28, x25
    98bc:	8b03141a 	add	x26, x0, x3, lsl #5
    98c0:	f9400f40 	ldr	x0, [x26, #24]
    98c4:	b40020e0 	cbz	x0, 9ce0 <fwp_hof0.constprop.0+0x650>
    98c8:	f85b03bc 	ldur	x28, [x29, #-80]
    98cc:	29371fb7 	stp	w23, w7, [x29, #-72]
    98d0:	aa1a03f7 	mov	x23, x26
    98d4:	b81c03b8 	stur	w24, [x29, #-64]
    98d8:	aa1b03f8 	mov	x24, x27
    98dc:	14000012 	b	9924 <fwp_hof0.constprop.0+0x294>
    98e0:	f9400001 	ldr	x1, [x0]
    98e4:	aa1803e0 	mov	x0, x24
    98e8:	d63f0020 	blr	x1
    98ec:	aa0003fb 	mov	x27, x0
    98f0:	aa1903e0 	mov	x0, x25
    98f4:	97fff1d7 	bl	6050 <fwp_closure_drop>
    98f8:	6b13029f 	cmp	w20, w19
    98fc:	54000ca0 	b.eq	9a90 <fwp_hof0.constprop.0+0x400>  // b.none
    9900:	f94046a0 	ldr	x0, [x21, #136]
    9904:	8b334f18 	add	x24, x24, w19, uxtw #3
    9908:	b9400363 	ldr	w3, [x27]
    990c:	4b1a02d4 	sub	w20, w22, w26
    9910:	aa1b03e6 	mov	x6, x27
    9914:	8b031417 	add	x23, x0, x3, lsl #5
    9918:	f9400ee0 	ldr	x0, [x23, #24]
    991c:	b4001da0 	cbz	x0, 9cd0 <fwp_hof0.constprop.0+0x640>
    9920:	aa1b03f9 	mov	x25, x27
    9924:	b94004c1 	ldr	w1, [x6, #4]
    9928:	b94002fa 	ldr	w26, [x23]
    992c:	0b010296 	add	w22, w20, w1
    9930:	6b16035f 	cmp	w26, w22
    9934:	54002488 	b.hi	9dc4 <fwp_hof0.constprop.0+0x734>  // b.pmore
    9938:	7100003f 	cmp	w1, #0x0
    993c:	4b010353 	sub	w19, w26, w1
    9940:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9944:	54fffce1 	b.ne	98e0 <fwp_hof0.constprop.0+0x250>  // b.any
    9948:	7100035f 	cmp	w26, #0x0
    994c:	910003e2 	mov	x2, sp
    9950:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9954:	f81d83a2 	stur	x2, [x29, #-40]
    9958:	d37df084 	lsl	x4, x4, #3
    995c:	91003c84 	add	x4, x4, #0xf
    9960:	92704c87 	and	x7, x4, #0xfffff0000
    9964:	927c7c84 	and	x4, x4, #0xffffffff0
    9968:	cb2763e7 	sub	x7, sp, x7
    996c:	eb2763ff 	cmp	sp, x7
    9970:	540000a0 	b.eq	9984 <fwp_hof0.constprop.0+0x2f4>  // b.none
    9974:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9978:	f90203ff 	str	xzr, [sp, #1024]
    997c:	eb2763ff 	cmp	sp, x7
    9980:	54ffffa1 	b.ne	9974 <fwp_hof0.constprop.0+0x2e4>  // b.any
    9984:	92403c84 	and	x4, x4, #0xffff
    9988:	cb2463ff 	sub	sp, sp, x4
    998c:	f90003ff 	str	xzr, [sp]
    9990:	f110009f 	cmp	x4, #0x400
    9994:	54000043 	b.cc	999c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9998:	f90203ff 	str	xzr, [sp, #1024]
    999c:	910043fb 	add	x27, sp, #0x10
    99a0:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    99a4:	910020c9 	add	x9, x6, #0x8
    99a8:	d2800004 	mov	x4, #0x0                   	// #0
    99ac:	340000c1 	cbz	w1, 99c4 <fwp_hof0.constprop.0+0x334>
    99b0:	f8646922 	ldr	x2, [x9, x4]
    99b4:	f8246b62 	str	x2, [x27, x4]
    99b8:	91002084 	add	x4, x4, #0x8
    99bc:	eb04015f 	cmp	x10, x4
    99c0:	54ffff81 	b.ne	99b0 <fwp_hof0.constprop.0+0x320>  // b.any
    99c4:	2a1303ea 	mov	w10, w19
    99c8:	d2800004 	mov	x4, #0x0                   	// #0
    99cc:	340000f3 	cbz	w19, 99e8 <fwp_hof0.constprop.0+0x358>
    99d0:	0b040022 	add	w2, w1, w4
    99d4:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    99d8:	91000484 	add	x4, x4, #0x1
    99dc:	f8227b63 	str	x3, [x27, x2, lsl #3]
    99e0:	eb04015f 	cmp	x10, x4
    99e4:	54ffff61 	b.ne	99d0 <fwp_hof0.constprop.0+0x340>  // b.any
    99e8:	f949db81 	ldr	x1, [x28, #5040]
    99ec:	f949ef84 	ldr	x4, [x28, #5080]
    99f0:	cb010321 	sub	x1, x25, x1
    99f4:	eb04403f 	cmp	x1, x4, lsl #16
    99f8:	540002e2 	b.cs	9a54 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    99fc:	d350fc24 	lsr	x4, x1, #16
    9a00:	f949ff8a 	ldr	x10, [x28, #5112]
    9a04:	8b040884 	add	x4, x4, x4, lsl #2
    9a08:	d37df084 	lsl	x4, x4, #3
    9a0c:	8b040149 	add	x9, x10, x4
    9a10:	f9401128 	ldr	x8, [x9, #32]
    9a14:	b4000208 	cbz	x8, 9a54 <fwp_hof0.constprop.0+0x3c4>
    9a18:	38646944 	ldrb	w4, [x10, x4]
    9a1c:	7100089f 	cmp	w4, #0x2
    9a20:	54001520 	b.eq	9cc4 <fwp_hof0.constprop.0+0x634>  // b.none
    9a24:	7100049f 	cmp	w4, #0x1
    9a28:	54000161 	b.ne	9a54 <fwp_hof0.constprop.0+0x3c4>  // b.any
    9a2c:	2943112a 	ldp	w10, w4, [x9, #24]
    9a30:	92403c21 	and	x1, x1, #0xffff
    9a34:	9b0a7c21 	mul	x1, x1, x10
    9a38:	d360fc21 	lsr	x1, x1, #32
    9a3c:	eb04003f 	cmp	x1, x4
    9a40:	540000a2 	b.cs	9a54 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    9a44:	8b010108 	add	x8, x8, x1
    9a48:	39400101 	ldrb	w1, [x8]
    9a4c:	7100043f 	cmp	w1, #0x1
    9a50:	54001360 	b.eq	9cbc <fwp_hof0.constprop.0+0x62c>  // b.none
    9a54:	f9400404 	ldr	x4, [x0, #8]
    9a58:	52800021 	mov	w1, #0x1                   	// #1
    9a5c:	aa1903e0 	mov	x0, x25
    9a60:	d63f0080 	blr	x4
    9a64:	f9400ee1 	ldr	x1, [x23, #24]
    9a68:	aa1b03e0 	mov	x0, x27
    9a6c:	f9400021 	ldr	x1, [x1]
    9a70:	d63f0020 	blr	x1
    9a74:	aa0003fb 	mov	x27, x0
    9a78:	f85d83a0 	ldur	x0, [x29, #-40]
    9a7c:	9100001f 	mov	sp, x0
    9a80:	aa1903e0 	mov	x0, x25
    9a84:	97fff173 	bl	6050 <fwp_closure_drop>
    9a88:	6b13029f 	cmp	w20, w19
    9a8c:	54fff3a1 	b.ne	9900 <fwp_hof0.constprop.0+0x270>  // b.any
    9a90:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9a94:	aa1b03f9 	mov	x25, x27
    9a98:	b85c03b8 	ldur	w24, [x29, #-64]
    9a9c:	6b17031f 	cmp	w24, w23
    9aa0:	540014c3 	b.cc	9d38 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9aa4:	f85983a0 	ldur	x0, [x29, #-104]
    9aa8:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9aac:	f1000400 	subs	x0, x0, #0x1
    9ab0:	f81983a0 	stur	x0, [x29, #-104]
    9ab4:	54ffe661 	b.ne	9780 <fwp_hof0.constprop.0+0xf0>  // b.any
    9ab8:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe788>
    9abc:	91102042 	add	x2, x2, #0x408
    9ac0:	aa1903e1 	mov	x1, x25
    9ac4:	aa1403e0 	mov	x0, x20
    9ac8:	aa1a03f8 	mov	x24, x26
    9acc:	aa1903fb 	mov	x27, x25
    9ad0:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9ad4:	91014042 	add	x2, x2, #0x50
    9ad8:	52800023 	mov	w3, #0x1                   	// #1
    9adc:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9ae0:	f81f03bf 	stur	xzr, [x29, #-16]
    9ae4:	97fffaef 	bl	86a0 <fwp_write>
    9ae8:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    9aec:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0xa90>
    9af0:	91022000 	add	x0, x0, #0x88
    9af4:	f10002df 	cmp	x22, #0x0
    9af8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9afc:	b1002b3f 	cmn	x25, #0xa
    9b00:	540039c8 	b.hi	a238 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    9b04:	91002720 	add	x0, x25, #0x9
    9b08:	52800021 	mov	w1, #0x1                   	// #1
    9b0c:	97ffecf9 	bl	4ef0 <fwp_heap_alloc>
    9b10:	aa0003f3 	mov	x19, x0
    9b14:	aa1603e1 	mov	x1, x22
    9b18:	aa0003f6 	mov	x22, x0
    9b1c:	aa1903e2 	mov	x2, x25
    9b20:	f80086d9 	str	x25, [x22], #8
    9b24:	8b190279 	add	x25, x19, x25
    9b28:	aa1603e0 	mov	x0, x22
    9b2c:	97ffe2e9 	bl	26d0 <memcpy@plt>
    9b30:	3900233f 	strb	wzr, [x25, #8]
    9b34:	f85e03a0 	ldur	x0, [x29, #-32]
    9b38:	97ffe382 	bl	2940 <free@plt>
    9b3c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9b40:	91174002 	add	x2, x0, #0x5d0
    9b44:	f949d841 	ldr	x1, [x2, #5040]
    9b48:	f949ec40 	ldr	x0, [x2, #5080]
    9b4c:	cb010261 	sub	x1, x19, x1
    9b50:	eb00403f 	cmp	x1, x0, lsl #16
    9b54:	54000322 	b.cs	9bb8 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9b58:	d350fc20 	lsr	x0, x1, #16
    9b5c:	f949fc43 	ldr	x3, [x2, #5112]
    9b60:	8b000800 	add	x0, x0, x0, lsl #2
    9b64:	d37df002 	lsl	x2, x0, #3
    9b68:	8b020060 	add	x0, x3, x2
    9b6c:	f9401019 	ldr	x25, [x0, #32]
    9b70:	b4000259 	cbz	x25, 9bb8 <fwp_hof0.constprop.0+0x528>
    9b74:	38626862 	ldrb	w2, [x3, x2]
    9b78:	7100085f 	cmp	w2, #0x2
    9b7c:	54003220 	b.eq	a1c0 <fwp_hof0.constprop.0+0xb30>  // b.none
    9b80:	7100045f 	cmp	w2, #0x1
    9b84:	540001a1 	b.ne	9bb8 <fwp_hof0.constprop.0+0x528>  // b.any
    9b88:	29430002 	ldp	w2, w0, [x0, #24]
    9b8c:	92403c21 	and	x1, x1, #0xffff
    9b90:	9b027c21 	mul	x1, x1, x2
    9b94:	d360fc21 	lsr	x1, x1, #32
    9b98:	eb00003f 	cmp	x1, x0
    9b9c:	540000e2 	b.cs	9bb8 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9ba0:	8b010339 	add	x25, x25, x1
    9ba4:	39400320 	ldrb	w0, [x25]
    9ba8:	7103fc1f 	cmp	w0, #0xff
    9bac:	54003520 	b.eq	a250 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9bb0:	52800020 	mov	w0, #0x1                   	// #1
    9bb4:	39000320 	strb	w0, [x25]
    9bb8:	aa1b03e0 	mov	x0, x27
    9bbc:	97fff0c9 	bl	5ee0 <fwp_drop0>
    9bc0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9bc4:	9101c003 	add	x3, x0, #0x70
    9bc8:	f9400262 	ldr	x2, [x19]
    9bcc:	aa1603e0 	mov	x0, x22
    9bd0:	aa0303f6 	mov	x22, x3
    9bd4:	d2800021 	mov	x1, #0x1                   	// #1
    9bd8:	f9400463 	ldr	x3, [x3, #8]
    9bdc:	97ffe369 	bl	2980 <fwrite@plt>
    9be0:	f94006c1 	ldr	x1, [x22, #8]
    9be4:	52800140 	mov	w0, #0xa                   	// #10
    9be8:	97ffe2ee 	bl	27a0 <fputc@plt>
    9bec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9bf0:	91174002 	add	x2, x0, #0x5d0
    9bf4:	f949d841 	ldr	x1, [x2, #5040]
    9bf8:	f949ec40 	ldr	x0, [x2, #5080]
    9bfc:	cb010261 	sub	x1, x19, x1
    9c00:	eb00403f 	cmp	x1, x0, lsl #16
    9c04:	54000382 	b.cs	9c74 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9c08:	d350fc20 	lsr	x0, x1, #16
    9c0c:	f949fc43 	ldr	x3, [x2, #5112]
    9c10:	8b000800 	add	x0, x0, x0, lsl #2
    9c14:	d37df000 	lsl	x0, x0, #3
    9c18:	8b000062 	add	x2, x3, x0
    9c1c:	f9401056 	ldr	x22, [x2, #32]
    9c20:	b40002b6 	cbz	x22, 9c74 <fwp_hof0.constprop.0+0x5e4>
    9c24:	38606860 	ldrb	w0, [x3, x0]
    9c28:	7100081f 	cmp	w0, #0x2
    9c2c:	54002c40 	b.eq	a1b4 <fwp_hof0.constprop.0+0xb24>  // b.none
    9c30:	7100041f 	cmp	w0, #0x1
    9c34:	54000201 	b.ne	9c74 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9c38:	29430043 	ldp	w3, w0, [x2, #24]
    9c3c:	92403c21 	and	x1, x1, #0xffff
    9c40:	9b037c21 	mul	x1, x1, x3
    9c44:	d360fc21 	lsr	x1, x1, #32
    9c48:	eb00003f 	cmp	x1, x0
    9c4c:	54000142 	b.cs	9c74 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9c50:	8b0102d6 	add	x22, x22, x1
    9c54:	394002c0 	ldrb	w0, [x22]
    9c58:	340000e0 	cbz	w0, 9c74 <fwp_hof0.constprop.0+0x5e4>
    9c5c:	7100041f 	cmp	w0, #0x1
    9c60:	54002a00 	b.eq	a1a0 <fwp_hof0.constprop.0+0xb10>  // b.none
    9c64:	7103fc1f 	cmp	w0, #0xff
    9c68:	54002b20 	b.eq	a1cc <fwp_hof0.constprop.0+0xb3c>  // b.none
    9c6c:	51000400 	sub	w0, w0, #0x1
    9c70:	390002c0 	strb	w0, [x22]
    9c74:	f9400b5a 	ldr	x26, [x26, #16]
    9c78:	b5ffd3ba 	cbnz	x26, 96ec <fwp_hof0.constprop.0+0x5c>
    9c7c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9c80:	f947f400 	ldr	x0, [x0, #4072]
    9c84:	f85f83a2 	ldur	x2, [x29, #-8]
    9c88:	f9400001 	ldr	x1, [x0]
    9c8c:	eb010042 	subs	x2, x2, x1
    9c90:	d2800001 	mov	x1, #0x0                   	// #0
    9c94:	54002dc1 	b.ne	a24c <fwp_hof0.constprop.0+0xbbc>  // b.any
    9c98:	910003bf 	mov	sp, x29
    9c9c:	d2800000 	mov	x0, #0x0                   	// #0
    9ca0:	a94153f3 	ldp	x19, x20, [sp, #16]
    9ca4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9ca8:	a94363f7 	ldp	x23, x24, [sp, #48]
    9cac:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9cb0:	a94573fb 	ldp	x27, x28, [sp, #80]
    9cb4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9cb8:	d65f03c0 	ret
    9cbc:	b90004df 	str	wzr, [x6, #4]
    9cc0:	17ffff69 	b	9a64 <fwp_hof0.constprop.0+0x3d4>
    9cc4:	72003c3f 	tst	w1, #0xffff
    9cc8:	54ffec61 	b.ne	9a54 <fwp_hof0.constprop.0+0x3c4>  // b.any
    9ccc:	17ffff5f 	b	9a48 <fwp_hof0.constprop.0+0x3b8>
    9cd0:	aa1b03fc 	mov	x28, x27
    9cd4:	aa1803fb 	mov	x27, x24
    9cd8:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9cdc:	b85c03b8 	ldur	w24, [x29, #-64]
    9ce0:	aa1c03e0 	mov	x0, x28
    9ce4:	b81d83a7 	stur	w7, [x29, #-40]
    9ce8:	97ffeeff 	bl	58e4 <fwp_rc_share>
    9cec:	b85d83a7 	ldur	w7, [x29, #-40]
    9cf0:	34000134 	cbz	w20, 9d14 <fwp_hof0.constprop.0+0x684>
    9cf4:	aa1b03f6 	mov	x22, x27
    9cf8:	8b344f73 	add	x19, x27, w20, uxtw #3
    9cfc:	2a0703f9 	mov	w25, w7
    9d00:	f84086c0 	ldr	x0, [x22], #8
    9d04:	97ffeef8 	bl	58e4 <fwp_rc_share>
    9d08:	eb16027f 	cmp	x19, x22
    9d0c:	54ffffa1 	b.ne	9d00 <fwp_hof0.constprop.0+0x670>  // b.any
    9d10:	2a1903e7 	mov	w7, w25
    9d14:	aa1b03e2 	mov	x2, x27
    9d18:	2a1403e1 	mov	w1, w20
    9d1c:	aa1c03e0 	mov	x0, x28
    9d20:	b81d83a7 	stur	w7, [x29, #-40]
    9d24:	97ffecb8 	bl	5004 <fwp_apply>
    9d28:	aa0003f9 	mov	x25, x0
    9d2c:	b85d83a7 	ldur	w7, [x29, #-40]
    9d30:	6b17031f 	cmp	w24, w23
    9d34:	54ffeb82 	b.cs	9aa4 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    9d38:	f94046a1 	ldr	x1, [x21, #136]
    9d3c:	4b0702f7 	sub	w23, w23, w7
    9d40:	b9400323 	ldr	w3, [x25]
    9d44:	f85d03a0 	ldur	x0, [x29, #-48]
    9d48:	8b031423 	add	x3, x1, x3, lsl #5
    9d4c:	b85c83a2 	ldur	w2, [x29, #-56]
    9d50:	8b274c00 	add	x0, x0, w7, uxtw #3
    9d54:	f81d03a0 	stur	x0, [x29, #-48]
    9d58:	f9400c61 	ldr	x1, [x3, #24]
    9d5c:	b85cc3a0 	ldur	w0, [x29, #-52]
    9d60:	4b020000 	sub	w0, w0, w2
    9d64:	b81cc3a0 	stur	w0, [x29, #-52]
    9d68:	aa1903e0 	mov	x0, x25
    9d6c:	b5ffd761 	cbnz	x1, 9858 <fwp_hof0.constprop.0+0x1c8>
    9d70:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9d74:	aa1903e0 	mov	x0, x25
    9d78:	97ffeedb 	bl	58e4 <fwp_rc_share>
    9d7c:	34000117 	cbz	w23, 9d9c <fwp_hof0.constprop.0+0x70c>
    9d80:	f85d03b8 	ldur	x24, [x29, #-48]
    9d84:	d2800016 	mov	x22, #0x0                   	// #0
    9d88:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    9d8c:	910006d6 	add	x22, x22, #0x1
    9d90:	97ffeed5 	bl	58e4 <fwp_rc_share>
    9d94:	6b1602ff 	cmp	w23, w22
    9d98:	54ffff88 	b.hi	9d88 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    9d9c:	f85d03a2 	ldur	x2, [x29, #-48]
    9da0:	aa1903e0 	mov	x0, x25
    9da4:	2a1703e1 	mov	w1, w23
    9da8:	97ffec97 	bl	5004 <fwp_apply>
    9dac:	aa0003f9 	mov	x25, x0
    9db0:	f85983a0 	ldur	x0, [x29, #-104]
    9db4:	f1000400 	subs	x0, x0, #0x1
    9db8:	f81983a0 	stur	x0, [x29, #-104]
    9dbc:	54ffce21 	b.ne	9780 <fwp_hof0.constprop.0+0xf0>  // b.any
    9dc0:	17ffff3e 	b	9ab8 <fwp_hof0.constprop.0+0x428>
    9dc4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9dc8:	9117400a 	add	x10, x0, #0x5d0
    9dcc:	2a0103fc 	mov	w28, w1
    9dd0:	110006c0 	add	w0, w22, #0x1
    9dd4:	f120001f 	cmp	x0, #0x800
    9dd8:	aa1703fa 	mov	x26, x23
    9ddc:	b953a541 	ldr	w1, [x10, #5028]
    9de0:	aa1803fb 	mov	x27, x24
    9de4:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9de8:	d37df000 	lsl	x0, x0, #3
    9dec:	b85c03b8 	ldur	w24, [x29, #-64]
    9df0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9df4:	54001860 	b.eq	a100 <fwp_hof0.constprop.0+0xa70>  // b.none
    9df8:	91003c01 	add	x1, x0, #0xf
    9dfc:	8b411141 	add	x1, x10, x1, lsr #4
    9e00:	397e8021 	ldrb	w1, [x1, #4000]
    9e04:	910f002b 	add	x11, x1, #0x3c0
    9e08:	8b010429 	add	x9, x1, x1, lsl #1
    9e0c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9e10:	8b090d4c 	add	x12, x10, x9, lsl #3
    9e14:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9e18:	2a0b03e1 	mov	w1, w11
    9e1c:	b4001613 	cbz	x19, a0dc <fwp_hof0.constprop.0+0xa4c>
    9e20:	f940026c 	ldr	x12, [x19]
    9e24:	aa2c03ec 	mvn	x12, x12
    9e28:	f829794c 	str	x12, [x10, x9, lsl #3]
    9e2c:	eb01001f 	cmp	x0, x1
    9e30:	540000c2 	b.cs	9e48 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    9e34:	d503201f 	nop
    9e38:	f8206a7f 	str	xzr, [x19, x0]
    9e3c:	91002000 	add	x0, x0, #0x8
    9e40:	eb00003f 	cmp	x1, x0
    9e44:	54ffffa8 	b.hi	9e38 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    9e48:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9e4c:	91174009 	add	x9, x0, #0x5d0
    9e50:	f94a1120 	ldr	x0, [x9, #5152]
    9e54:	ab010000 	adds	x0, x0, x1
    9e58:	54001e82 	b.cs	a228 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    9e5c:	f94a1521 	ldr	x1, [x9, #5160]
    9e60:	f90a1120 	str	x0, [x9, #5152]
    9e64:	eb01001f 	cmp	x0, x1
    9e68:	54000049 	b.ls	9e70 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    9e6c:	f90a1520 	str	x0, [x9, #5160]
    9e70:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9e74:	91174000 	add	x0, x0, #0x5d0
    9e78:	1e630161 	ucvtf	d1, w11
    9e7c:	fd4a1c00 	ldr	d0, [x0, #5176]
    9e80:	1e612800 	fadd	d0, d0, d1
    9e84:	fd0a1c00 	str	d0, [x0, #5176]
    9e88:	b94000c0 	ldr	w0, [x6]
    9e8c:	29005a60 	stp	w0, w22, [x19]
    9e90:	3400013c 	cbz	w28, 9eb4 <fwp_hof0.constprop.0+0x824>
    9e94:	910020c1 	add	x1, x6, #0x8
    9e98:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9e9c:	91002260 	add	x0, x19, #0x8
    9ea0:	b81c03a7 	stur	w7, [x29, #-64]
    9ea4:	f81d83a6 	stur	x6, [x29, #-40]
    9ea8:	97ffe212 	bl	26f0 <memmove@plt>
    9eac:	f85d83a6 	ldur	x6, [x29, #-40]
    9eb0:	b85c03a7 	ldur	w7, [x29, #-64]
    9eb4:	2a1403e9 	mov	w9, w20
    9eb8:	d2800001 	mov	x1, #0x0                   	// #0
    9ebc:	34000114 	cbz	w20, 9edc <fwp_hof0.constprop.0+0x84c>
    9ec0:	0b010380 	add	w0, w28, w1
    9ec4:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9ec8:	8b000e60 	add	x0, x19, x0, lsl #3
    9ecc:	91000421 	add	x1, x1, #0x1
    9ed0:	f9000402 	str	x2, [x0, #8]
    9ed4:	eb01013f 	cmp	x9, x1
    9ed8:	54ffff41 	b.ne	9ec0 <fwp_hof0.constprop.0+0x830>  // b.any
    9edc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ee0:	91174002 	add	x2, x0, #0x5d0
    9ee4:	f949d840 	ldr	x0, [x2, #5040]
    9ee8:	f949ec41 	ldr	x1, [x2, #5080]
    9eec:	cb000320 	sub	x0, x25, x0
    9ef0:	eb01401f 	cmp	x0, x1, lsl #16
    9ef4:	540002e2 	b.cs	9f50 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9ef8:	d350fc01 	lsr	x1, x0, #16
    9efc:	f949fc45 	ldr	x5, [x2, #5112]
    9f00:	8b010821 	add	x1, x1, x1, lsl #2
    9f04:	d37df021 	lsl	x1, x1, #3
    9f08:	8b0100a4 	add	x4, x5, x1
    9f0c:	f9401082 	ldr	x2, [x4, #32]
    9f10:	b4000202 	cbz	x2, 9f50 <fwp_hof0.constprop.0+0x8c0>
    9f14:	386168a1 	ldrb	w1, [x5, x1]
    9f18:	7100083f 	cmp	w1, #0x2
    9f1c:	54001020 	b.eq	a120 <fwp_hof0.constprop.0+0xa90>  // b.none
    9f20:	7100043f 	cmp	w1, #0x1
    9f24:	54000161 	b.ne	9f50 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9f28:	29430485 	ldp	w5, w1, [x4, #24]
    9f2c:	92403c00 	and	x0, x0, #0xffff
    9f30:	9b057c00 	mul	x0, x0, x5
    9f34:	d360fc00 	lsr	x0, x0, #32
    9f38:	eb01001f 	cmp	x0, x1
    9f3c:	540000a2 	b.cs	9f50 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9f40:	8b000042 	add	x2, x2, x0
    9f44:	39400040 	ldrb	w0, [x2]
    9f48:	7100041f 	cmp	w0, #0x1
    9f4c:	54000be0 	b.eq	a0c8 <fwp_hof0.constprop.0+0xa38>  // b.none
    9f50:	f9400f42 	ldr	x2, [x26, #24]
    9f54:	aa1903e0 	mov	x0, x25
    9f58:	52800021 	mov	w1, #0x1                   	// #1
    9f5c:	b81d83a7 	stur	w7, [x29, #-40]
    9f60:	f9400442 	ldr	x2, [x2, #8]
    9f64:	d63f0040 	blr	x2
    9f68:	b85d83a7 	ldur	w7, [x29, #-40]
    9f6c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9f70:	91174002 	add	x2, x0, #0x5d0
    9f74:	f949d841 	ldr	x1, [x2, #5040]
    9f78:	f949ec40 	ldr	x0, [x2, #5080]
    9f7c:	cb010261 	sub	x1, x19, x1
    9f80:	eb00403f 	cmp	x1, x0, lsl #16
    9f84:	54000322 	b.cs	9fe8 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9f88:	d350fc20 	lsr	x0, x1, #16
    9f8c:	f949fc43 	ldr	x3, [x2, #5112]
    9f90:	8b000800 	add	x0, x0, x0, lsl #2
    9f94:	d37df002 	lsl	x2, x0, #3
    9f98:	8b020060 	add	x0, x3, x2
    9f9c:	f9401014 	ldr	x20, [x0, #32]
    9fa0:	b4000254 	cbz	x20, 9fe8 <fwp_hof0.constprop.0+0x958>
    9fa4:	38626862 	ldrb	w2, [x3, x2]
    9fa8:	7100085f 	cmp	w2, #0x2
    9fac:	54000c00 	b.eq	a12c <fwp_hof0.constprop.0+0xa9c>  // b.none
    9fb0:	7100045f 	cmp	w2, #0x1
    9fb4:	540001a1 	b.ne	9fe8 <fwp_hof0.constprop.0+0x958>  // b.any
    9fb8:	29430002 	ldp	w2, w0, [x0, #24]
    9fbc:	92403c21 	and	x1, x1, #0xffff
    9fc0:	9b027c21 	mul	x1, x1, x2
    9fc4:	d360fc21 	lsr	x1, x1, #32
    9fc8:	eb00003f 	cmp	x1, x0
    9fcc:	540000e2 	b.cs	9fe8 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9fd0:	8b010294 	add	x20, x20, x1
    9fd4:	39400280 	ldrb	w0, [x20]
    9fd8:	7103fc1f 	cmp	w0, #0xff
    9fdc:	54000b20 	b.eq	a140 <fwp_hof0.constprop.0+0xab0>  // b.none
    9fe0:	52800020 	mov	w0, #0x1                   	// #1
    9fe4:	39000280 	strb	w0, [x20]
    9fe8:	aa1903e0 	mov	x0, x25
    9fec:	b81d83a7 	stur	w7, [x29, #-40]
    9ff0:	97fff018 	bl	6050 <fwp_closure_drop>
    9ff4:	aa1303f9 	mov	x25, x19
    9ff8:	b85d83a7 	ldur	w7, [x29, #-40]
    9ffc:	17ffff4d 	b	9d30 <fwp_hof0.constprop.0+0x6a0>
    a000:	b8626860 	ldr	w0, [x3, x2]
    a004:	b94004a2 	ldr	w2, [x5, #4]
    a008:	4b020003 	sub	w3, w0, w2
    a00c:	7100047f 	cmp	w3, #0x1
    a010:	54ffbd01 	b.ne	97b0 <fwp_hof0.constprop.0+0x120>  // b.any
    a014:	910003f6 	mov	x22, sp
    a018:	34000a22 	cbz	w2, a15c <fwp_hof0.constprop.0+0xacc>
    a01c:	7100001f 	cmp	w0, #0x0
    a020:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a024:	d2800101 	mov	x1, #0x8                   	// #8
    a028:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a02c:	91003ee0 	add	x0, x23, #0xf
    a030:	92704c01 	and	x1, x0, #0xfffff0000
    a034:	927c7c00 	and	x0, x0, #0xffffffff0
    a038:	cb2163e1 	sub	x1, sp, x1
    a03c:	eb2163ff 	cmp	sp, x1
    a040:	540000a0 	b.eq	a054 <fwp_hof0.constprop.0+0x9c4>  // b.none
    a044:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a048:	f90203ff 	str	xzr, [sp, #1024]
    a04c:	eb2163ff 	cmp	sp, x1
    a050:	54ffffa1 	b.ne	a044 <fwp_hof0.constprop.0+0x9b4>  // b.any
    a054:	92403c00 	and	x0, x0, #0xffff
    a058:	cb2063ff 	sub	sp, sp, x0
    a05c:	f90003ff 	str	xzr, [sp]
    a060:	f110001f 	cmp	x0, #0x400
    a064:	54000043 	b.cc	a06c <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    a068:	f90203ff 	str	xzr, [sp, #1024]
    a06c:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    a070:	910043f8 	add	x24, sp, #0x10
    a074:	d00000a0 	adrp	x0, 20000 <__data_start>
    a078:	91004001 	add	x1, x0, #0x10
    a07c:	aa1c03e2 	mov	x2, x28
    a080:	91012021 	add	x1, x1, #0x48
    a084:	aa1703e3 	mov	x3, x23
    a088:	aa1803e0 	mov	x0, x24
    a08c:	97ffe1d1 	bl	27d0 <__memcpy_chk@plt>
    a090:	eb1c02ff 	cmp	x23, x28
    a094:	aa1403e1 	mov	x1, x20
    a098:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    a09c:	d2800102 	mov	x2, #0x8                   	// #8
    a0a0:	cb1c0063 	sub	x3, x3, x28
    a0a4:	8b1c0300 	add	x0, x24, x28
    a0a8:	97ffe1ca 	bl	27d0 <__memcpy_chk@plt>
    a0ac:	f9400f61 	ldr	x1, [x27, #24]
    a0b0:	aa1803e0 	mov	x0, x24
    a0b4:	f9400021 	ldr	x1, [x1]
    a0b8:	d63f0020 	blr	x1
    a0bc:	aa0003f9 	mov	x25, x0
    a0c0:	910002df 	mov	sp, x22
    a0c4:	17ffff3b 	b	9db0 <fwp_hof0.constprop.0+0x720>
    a0c8:	b90004df 	str	wzr, [x6, #4]
    a0cc:	17ffffa8 	b	9f6c <fwp_hof0.constprop.0+0x8dc>
    a0d0:	72003c3f 	tst	w1, #0xffff
    a0d4:	54ffbae1 	b.ne	9830 <fwp_hof0.constprop.0+0x1a0>  // b.any
    a0d8:	17fffdd0 	b	9818 <fwp_hof0.constprop.0+0x188>
    a0dc:	f9400593 	ldr	x19, [x12, #8]
    a0e0:	b4000113 	cbz	x19, a100 <fwp_hof0.constprop.0+0xa70>
    a0e4:	f9400989 	ldr	x9, [x12, #16]
    a0e8:	cb130129 	sub	x9, x9, x19
    a0ec:	eb09003f 	cmp	x1, x9
    a0f0:	54000088 	b.hi	a100 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    a0f4:	8b010269 	add	x9, x19, x1
    a0f8:	f9000589 	str	x9, [x12, #8]
    a0fc:	17ffff4c 	b	9e2c <fwp_hof0.constprop.0+0x79c>
    a100:	52800001 	mov	w1, #0x0                   	// #0
    a104:	f81c03a6 	stur	x6, [x29, #-64]
    a108:	b81d83a7 	stur	w7, [x29, #-40]
    a10c:	97ffeb79 	bl	4ef0 <fwp_heap_alloc>
    a110:	f85c03a6 	ldur	x6, [x29, #-64]
    a114:	aa0003f3 	mov	x19, x0
    a118:	b85d83a7 	ldur	w7, [x29, #-40]
    a11c:	17ffff5b 	b	9e88 <fwp_hof0.constprop.0+0x7f8>
    a120:	72003c1f 	tst	w0, #0xffff
    a124:	54fff161 	b.ne	9f50 <fwp_hof0.constprop.0+0x8c0>  // b.any
    a128:	17ffff87 	b	9f44 <fwp_hof0.constprop.0+0x8b4>
    a12c:	72003c3f 	tst	w1, #0xffff
    a130:	54fff5c1 	b.ne	9fe8 <fwp_hof0.constprop.0+0x958>  // b.any
    a134:	39400280 	ldrb	w0, [x20]
    a138:	7103fc1f 	cmp	w0, #0xff
    a13c:	54fff521 	b.ne	9fe0 <fwp_hof0.constprop.0+0x950>  // b.any
    a140:	aa1403e0 	mov	x0, x20
    a144:	b81d83a7 	stur	w7, [x29, #-40]
    a148:	97ffe9aa 	bl	47f0 <fwp_rc_forget_slot>
    a14c:	b85d83a7 	ldur	w7, [x29, #-40]
    a150:	17ffffa4 	b	9fe0 <fwp_hof0.constprop.0+0x950>
    a154:	97ffe960 	bl	46d4 <fwp_rc_wide_dup>
    a158:	17fffdb6 	b	9830 <fwp_hof0.constprop.0+0x1a0>
    a15c:	f9400021 	ldr	x1, [x1]
    a160:	aa1403e0 	mov	x0, x20
    a164:	d63f0020 	blr	x1
    a168:	aa0003f9 	mov	x25, x0
    a16c:	910002df 	mov	sp, x22
    a170:	17ffff10 	b	9db0 <fwp_hof0.constprop.0+0x720>
    a174:	72003c3f 	tst	w1, #0xffff
    a178:	54ffafa1 	b.ne	976c <fwp_hof0.constprop.0+0xdc>  // b.any
    a17c:	17fffd76 	b	9754 <fwp_hof0.constprop.0+0xc4>
    a180:	aa1a03e0 	mov	x0, x26
    a184:	97ffedd8 	bl	58e4 <fwp_rc_share>
    a188:	aa1903e0 	mov	x0, x25
    a18c:	52800037 	mov	w23, #0x1                   	// #1
    a190:	97ffedd5 	bl	58e4 <fwp_rc_share>
    a194:	aa1a03f9 	mov	x25, x26
    a198:	f81d03b4 	stur	x20, [x29, #-48]
    a19c:	17ffff00 	b	9d9c <fwp_hof0.constprop.0+0x70c>
    a1a0:	aa1303e0 	mov	x0, x19
    a1a4:	97ffee27 	bl	5a40 <fwp_rc_free_arr>
    a1a8:	f9400b5a 	ldr	x26, [x26, #16]
    a1ac:	b5ffaa1a 	cbnz	x26, 96ec <fwp_hof0.constprop.0+0x5c>
    a1b0:	17fffeb3 	b	9c7c <fwp_hof0.constprop.0+0x5ec>
    a1b4:	72003c3f 	tst	w1, #0xffff
    a1b8:	54ffd5e1 	b.ne	9c74 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a1bc:	17fffea6 	b	9c54 <fwp_hof0.constprop.0+0x5c4>
    a1c0:	72003c3f 	tst	w1, #0xffff
    a1c4:	54ffcfa1 	b.ne	9bb8 <fwp_hof0.constprop.0+0x528>  // b.any
    a1c8:	17fffe77 	b	9ba4 <fwp_hof0.constprop.0+0x514>
    a1cc:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a1d0:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a1d4:	91174021 	add	x1, x1, #0x5d0
    a1d8:	ca402400 	eor	x0, x0, x0, lsr #9
    a1dc:	8b200c20 	add	x0, x1, w0, uxtb #3
    a1e0:	f94a2400 	ldr	x0, [x0, #5192]
    a1e4:	b5000080 	cbnz	x0, a1f4 <fwp_hof0.constprop.0+0xb64>
    a1e8:	14000011 	b	a22c <fwp_hof0.constprop.0+0xb9c>
    a1ec:	f9400800 	ldr	x0, [x0, #16]
    a1f0:	b40001e0 	cbz	x0, a22c <fwp_hof0.constprop.0+0xb9c>
    a1f4:	f9400001 	ldr	x1, [x0]
    a1f8:	eb0102df 	cmp	x22, x1
    a1fc:	54ffff81 	b.ne	a1ec <fwp_hof0.constprop.0+0xb5c>  // b.any
    a200:	f9400401 	ldr	x1, [x0, #8]
    a204:	d1000421 	sub	x1, x1, #0x1
    a208:	f9000401 	str	x1, [x0, #8]
    a20c:	f103f83f 	cmp	x1, #0xfe
    a210:	54ffd321 	b.ne	9c74 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a214:	aa1603e0 	mov	x0, x22
    a218:	97ffe976 	bl	47f0 <fwp_rc_forget_slot>
    a21c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a220:	390002c0 	strb	w0, [x22]
    a224:	17fffe94 	b	9c74 <fwp_hof0.constprop.0+0x5e4>
    a228:	97ffe382 	bl	3030 <fwp_heap_oom>
    a22c:	f0000000 	adrp	x0, d000 <__divti3+0x1b0>
    a230:	91234000 	add	x0, x0, #0x8d0
    a234:	97ffe573 	bl	3800 <fwp_trap>
    a238:	f0000000 	adrp	x0, d000 <__divti3+0x1b0>
    a23c:	912f2000 	add	x0, x0, #0xbc8
    a240:	97ffe570 	bl	3800 <fwp_trap>
    a244:	97ffe924 	bl	46d4 <fwp_rc_wide_dup>
    a248:	17fffd49 	b	976c <fwp_hof0.constprop.0+0xdc>
    a24c:	97ffe18d 	bl	2880 <__stack_chk_fail@plt>
    a250:	aa1903e0 	mov	x0, x25
    a254:	97ffe967 	bl	47f0 <fwp_rc_forget_slot>
    a258:	17fffe56 	b	9bb0 <fwp_hof0.constprop.0+0x520>
    a25c:	d503201f 	nop

000000000000a260 <f0>:
    a260:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a264:	910003fd 	mov	x29, sp
    a268:	a90153f3 	stp	x19, x20, [sp, #16]
    a26c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a270:	a90363f7 	stp	x23, x24, [sp, #48]
    a274:	a9046bf9 	stp	x25, x26, [sp, #64]
    a278:	a90573fb 	stp	x27, x28, [sp, #80]
    a27c:	d12183ff 	sub	sp, sp, #0x860
    a280:	f90203ff 	str	xzr, [sp, #1024]
    a284:	d00000a0 	adrp	x0, 20000 <__data_start>
    a288:	9101c005 	add	x5, x0, #0x70
    a28c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a290:	f947f400 	ldr	x0, [x0, #4072]
    a294:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a298:	f94188a6 	ldr	x6, [x5, #784]
    a29c:	f9400001 	ldr	x1, [x0]
    a2a0:	f9042fe1 	str	x1, [sp, #2136]
    a2a4:	d2800001 	mov	x1, #0x0                   	// #0
    a2a8:	91174298 	add	x24, x20, #0x5d0
    a2ac:	912123f6 	add	x22, sp, #0x848
    a2b0:	910023e0 	add	x0, sp, #0x8
    a2b4:	910083e2 	add	x2, sp, #0x20
    a2b8:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    a2bc:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a2c0:	91364021 	add	x1, x1, #0xd90
    a2c4:	913d4084 	add	x4, x4, #0xf50
    a2c8:	d2800013 	mov	x19, #0x0                   	// #0
    a2cc:	d2800119 	mov	x25, #0x8                   	// #8
    a2d0:	d2800015 	mov	x21, #0x0                   	// #0
    a2d4:	52800037 	mov	w23, #0x1                   	// #1
    a2d8:	a90093e6 	stp	x6, x4, [sp, #8]
    a2dc:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a2e0:	a90307ff 	stp	xzr, x1, [sp, #48]
    a2e4:	f90188a0 	str	x0, [x5, #784]
    a2e8:	f100073a 	subs	x26, x25, #0x1
    a2ec:	aa1603e1 	mov	x1, x22
    a2f0:	da1f02bc 	sbc	x28, x21, xzr
    a2f4:	52800020 	mov	w0, #0x1                   	// #1
    a2f8:	f90017fa 	str	x26, [sp, #40]
    a2fc:	aa1a03f9 	mov	x25, x26
    a300:	f90427fa 	str	x26, [sp, #2120]
    a304:	aa1c03f5 	mov	x21, x28
    a308:	f9042bf3 	str	x19, [sp, #2128]
    a30c:	97ffed2e 	bl	57c4 <fwp_data.part.0.constprop.0>
    a310:	f949db02 	ldr	x2, [x24, #5040]
    a314:	aa0003f3 	mov	x19, x0
    a318:	f949ef00 	ldr	x0, [x24, #5080]
    a31c:	cb020262 	sub	x2, x19, x2
    a320:	eb00405f 	cmp	x2, x0, lsl #16
    a324:	54000302 	b.cs	a384 <f0+0x124>  // b.hs, b.nlast
    a328:	d350fc40 	lsr	x0, x2, #16
    a32c:	f949ff04 	ldr	x4, [x24, #5112]
    a330:	8b000800 	add	x0, x0, x0, lsl #2
    a334:	d37df001 	lsl	x1, x0, #3
    a338:	8b010080 	add	x0, x4, x1
    a33c:	f940101b 	ldr	x27, [x0, #32]
    a340:	b400023b 	cbz	x27, a384 <f0+0x124>
    a344:	38616881 	ldrb	w1, [x4, x1]
    a348:	7100083f 	cmp	w1, #0x2
    a34c:	54010e60 	b.eq	c518 <f0+0x22b8>  // b.none
    a350:	7100043f 	cmp	w1, #0x1
    a354:	54000181 	b.ne	a384 <f0+0x124>  // b.any
    a358:	29430001 	ldp	w1, w0, [x0, #24]
    a35c:	92403c42 	and	x2, x2, #0xffff
    a360:	9b017c42 	mul	x2, x2, x1
    a364:	d360fc42 	lsr	x2, x2, #32
    a368:	eb00005f 	cmp	x2, x0
    a36c:	540000c2 	b.cs	a384 <f0+0x124>  // b.hs, b.nlast
    a370:	8b02037b 	add	x27, x27, x2
    a374:	39400360 	ldrb	w0, [x27]
    a378:	7103fc1f 	cmp	w0, #0xff
    a37c:	54010c80 	b.eq	c50c <f0+0x22ac>  // b.none
    a380:	39000377 	strb	w23, [x27]
    a384:	f90013f3 	str	x19, [sp, #32]
    a388:	aa1c035a 	orr	x26, x26, x28
    a38c:	b5fffafa 	cbnz	x26, a2e8 <f0+0x88>
    a390:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xa90>
    a394:	910103e1 	add	x1, sp, #0x40
    a398:	f94007e2 	ldr	x2, [sp, #8]
    a39c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a3a0:	3dc0d400 	ldr	q0, [x0, #848]
    a3a4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a3a8:	9101c018 	add	x24, x0, #0x70
    a3ac:	52800020 	mov	w0, #0x1                   	// #1
    a3b0:	3d8013e0 	str	q0, [sp, #64]
    a3b4:	f9018b02 	str	x2, [x24, #784]
    a3b8:	97ffed03 	bl	57c4 <fwp_data.part.0.constprop.0>
    a3bc:	97ffed71 	bl	5980 <fwp_rc_fresh>
    a3c0:	aa0003e2 	mov	x2, x0
    a3c4:	910163e1 	add	x1, sp, #0x58
    a3c8:	52800020 	mov	w0, #0x1                   	// #1
    a3cc:	a9058bf5 	stp	x21, x2, [sp, #88]
    a3d0:	97ffecfd 	bl	57c4 <fwp_data.part.0.constprop.0>
    a3d4:	97ffed6b 	bl	5980 <fwp_rc_fresh>
    a3d8:	aa0003e2 	mov	x2, x0
    a3dc:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xa90>
    a3e0:	9101a3e1 	add	x1, sp, #0x68
    a3e4:	52800020 	mov	w0, #0x1                   	// #1
    a3e8:	f9003be2 	str	x2, [sp, #112]
    a3ec:	3dc0d460 	ldr	q0, [x3, #848]
    a3f0:	fd0037e0 	str	d0, [sp, #104]
    a3f4:	97ffecf4 	bl	57c4 <fwp_data.part.0.constprop.0>
    a3f8:	97ffed62 	bl	5980 <fwp_rc_fresh>
    a3fc:	aa0003e2 	mov	x2, x0
    a400:	9101e3e1 	add	x1, sp, #0x78
    a404:	52800020 	mov	w0, #0x1                   	// #1
    a408:	a9078bf5 	stp	x21, x2, [sp, #120]
    a40c:	97ffecee 	bl	57c4 <fwp_data.part.0.constprop.0>
    a410:	97ffed5c 	bl	5980 <fwp_rc_fresh>
    a414:	aa0003e2 	mov	x2, x0
    a418:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xa90>
    a41c:	910223e1 	add	x1, sp, #0x88
    a420:	52800020 	mov	w0, #0x1                   	// #1
    a424:	f9004be2 	str	x2, [sp, #144]
    a428:	3dc0d460 	ldr	q0, [x3, #848]
    a42c:	fd0047e0 	str	d0, [sp, #136]
    a430:	97ffece5 	bl	57c4 <fwp_data.part.0.constprop.0>
    a434:	97ffed53 	bl	5980 <fwp_rc_fresh>
    a438:	aa0003e2 	mov	x2, x0
    a43c:	910263e1 	add	x1, sp, #0x98
    a440:	52800020 	mov	w0, #0x1                   	// #1
    a444:	a9098bf5 	stp	x21, x2, [sp, #152]
    a448:	97ffecdf 	bl	57c4 <fwp_data.part.0.constprop.0>
    a44c:	91174283 	add	x3, x20, #0x5d0
    a450:	aa0003f5 	mov	x21, x0
    a454:	f949d861 	ldr	x1, [x3, #5040]
    a458:	f949ec60 	ldr	x0, [x3, #5080]
    a45c:	cb0102a1 	sub	x1, x21, x1
    a460:	eb00403f 	cmp	x1, x0, lsl #16
    a464:	54000322 	b.cs	a4c8 <f0+0x268>  // b.hs, b.nlast
    a468:	d350fc22 	lsr	x2, x1, #16
    a46c:	f949fc63 	ldr	x3, [x3, #5112]
    a470:	8b020842 	add	x2, x2, x2, lsl #2
    a474:	d37df042 	lsl	x2, x2, #3
    a478:	8b020060 	add	x0, x3, x2
    a47c:	f9401017 	ldr	x23, [x0, #32]
    a480:	b4000257 	cbz	x23, a4c8 <f0+0x268>
    a484:	38626862 	ldrb	w2, [x3, x2]
    a488:	7100085f 	cmp	w2, #0x2
    a48c:	54010880 	b.eq	c59c <f0+0x233c>  // b.none
    a490:	7100045f 	cmp	w2, #0x1
    a494:	540001a1 	b.ne	a4c8 <f0+0x268>  // b.any
    a498:	29430002 	ldp	w2, w0, [x0, #24]
    a49c:	92403c21 	and	x1, x1, #0xffff
    a4a0:	9b027c21 	mul	x1, x1, x2
    a4a4:	d360fc21 	lsr	x1, x1, #32
    a4a8:	eb00003f 	cmp	x1, x0
    a4ac:	540000e2 	b.cs	a4c8 <f0+0x268>  // b.hs, b.nlast
    a4b0:	8b0102f7 	add	x23, x23, x1
    a4b4:	394002e0 	ldrb	w0, [x23]
    a4b8:	7103fc1f 	cmp	w0, #0xff
    a4bc:	54011240 	b.eq	c704 <f0+0x24a4>  // b.none
    a4c0:	52800020 	mov	w0, #0x1                   	// #1
    a4c4:	390002e0 	strb	w0, [x23]
    a4c8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4cc:	9102a3e1 	add	x1, sp, #0xa8
    a4d0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4d4:	52800020 	mov	w0, #0x1                   	// #1
    a4d8:	a90ad7e2 	stp	x2, x21, [sp, #168]
    a4dc:	97ffecba 	bl	57c4 <fwp_data.part.0.constprop.0>
    a4e0:	91174283 	add	x3, x20, #0x5d0
    a4e4:	aa0003f5 	mov	x21, x0
    a4e8:	f949d861 	ldr	x1, [x3, #5040]
    a4ec:	f949ec60 	ldr	x0, [x3, #5080]
    a4f0:	cb0102a1 	sub	x1, x21, x1
    a4f4:	eb00403f 	cmp	x1, x0, lsl #16
    a4f8:	54000322 	b.cs	a55c <f0+0x2fc>  // b.hs, b.nlast
    a4fc:	d350fc22 	lsr	x2, x1, #16
    a500:	f949fc63 	ldr	x3, [x3, #5112]
    a504:	8b020842 	add	x2, x2, x2, lsl #2
    a508:	d37df042 	lsl	x2, x2, #3
    a50c:	8b020060 	add	x0, x3, x2
    a510:	f9401017 	ldr	x23, [x0, #32]
    a514:	b4000257 	cbz	x23, a55c <f0+0x2fc>
    a518:	38626862 	ldrb	w2, [x3, x2]
    a51c:	7100085f 	cmp	w2, #0x2
    a520:	54010380 	b.eq	c590 <f0+0x2330>  // b.none
    a524:	7100045f 	cmp	w2, #0x1
    a528:	540001a1 	b.ne	a55c <f0+0x2fc>  // b.any
    a52c:	29430002 	ldp	w2, w0, [x0, #24]
    a530:	92403c21 	and	x1, x1, #0xffff
    a534:	9b027c21 	mul	x1, x1, x2
    a538:	d360fc21 	lsr	x1, x1, #32
    a53c:	eb00003f 	cmp	x1, x0
    a540:	540000e2 	b.cs	a55c <f0+0x2fc>  // b.hs, b.nlast
    a544:	8b0102f7 	add	x23, x23, x1
    a548:	394002e0 	ldrb	w0, [x23]
    a54c:	7103fc1f 	cmp	w0, #0xff
    a550:	54010e00 	b.eq	c710 <f0+0x24b0>  // b.none
    a554:	52800020 	mov	w0, #0x1                   	// #1
    a558:	390002e0 	strb	w0, [x23]
    a55c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a560:	9102e3e1 	add	x1, sp, #0xb8
    a564:	52800020 	mov	w0, #0x1                   	// #1
    a568:	a90bd7e2 	stp	x2, x21, [sp, #184]
    a56c:	97ffec96 	bl	57c4 <fwp_data.part.0.constprop.0>
    a570:	91174283 	add	x3, x20, #0x5d0
    a574:	aa0003f5 	mov	x21, x0
    a578:	f949d861 	ldr	x1, [x3, #5040]
    a57c:	f949ec60 	ldr	x0, [x3, #5080]
    a580:	cb0102a1 	sub	x1, x21, x1
    a584:	eb00403f 	cmp	x1, x0, lsl #16
    a588:	54000322 	b.cs	a5ec <f0+0x38c>  // b.hs, b.nlast
    a58c:	d350fc22 	lsr	x2, x1, #16
    a590:	f949fc63 	ldr	x3, [x3, #5112]
    a594:	8b020842 	add	x2, x2, x2, lsl #2
    a598:	d37df042 	lsl	x2, x2, #3
    a59c:	8b020060 	add	x0, x3, x2
    a5a0:	f9401017 	ldr	x23, [x0, #32]
    a5a4:	b4000257 	cbz	x23, a5ec <f0+0x38c>
    a5a8:	38626862 	ldrb	w2, [x3, x2]
    a5ac:	7100085f 	cmp	w2, #0x2
    a5b0:	5400fea0 	b.eq	c584 <f0+0x2324>  // b.none
    a5b4:	7100045f 	cmp	w2, #0x1
    a5b8:	540001a1 	b.ne	a5ec <f0+0x38c>  // b.any
    a5bc:	29430002 	ldp	w2, w0, [x0, #24]
    a5c0:	92403c21 	and	x1, x1, #0xffff
    a5c4:	9b027c21 	mul	x1, x1, x2
    a5c8:	d360fc21 	lsr	x1, x1, #32
    a5cc:	eb00003f 	cmp	x1, x0
    a5d0:	540000e2 	b.cs	a5ec <f0+0x38c>  // b.hs, b.nlast
    a5d4:	8b0102f7 	add	x23, x23, x1
    a5d8:	394002e0 	ldrb	w0, [x23]
    a5dc:	7103fc1f 	cmp	w0, #0xff
    a5e0:	540109e0 	b.eq	c71c <f0+0x24bc>  // b.none
    a5e4:	52800020 	mov	w0, #0x1                   	// #1
    a5e8:	390002e0 	strb	w0, [x23]
    a5ec:	910323e1 	add	x1, sp, #0xc8
    a5f0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a5f4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a5f8:	52800020 	mov	w0, #0x1                   	// #1
    a5fc:	a90cd7f7 	stp	x23, x21, [sp, #200]
    a600:	97ffec71 	bl	57c4 <fwp_data.part.0.constprop.0>
    a604:	97ffecdf 	bl	5980 <fwp_rc_fresh>
    a608:	aa0003e2 	mov	x2, x0
    a60c:	910363e1 	add	x1, sp, #0xd8
    a610:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a614:	52800020 	mov	w0, #0x1                   	// #1
    a618:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a61c:	97ffec6a 	bl	57c4 <fwp_data.part.0.constprop.0>
    a620:	97ffecd8 	bl	5980 <fwp_rc_fresh>
    a624:	aa0003e2 	mov	x2, x0
    a628:	9103a3e1 	add	x1, sp, #0xe8
    a62c:	52800020 	mov	w0, #0x1                   	// #1
    a630:	a90e8bf7 	stp	x23, x2, [sp, #232]
    a634:	97ffec64 	bl	57c4 <fwp_data.part.0.constprop.0>
    a638:	97ffecd2 	bl	5980 <fwp_rc_fresh>
    a63c:	aa0003e2 	mov	x2, x0
    a640:	9103e3e1 	add	x1, sp, #0xf8
    a644:	52800020 	mov	w0, #0x1                   	// #1
    a648:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a64c:	97ffec5e 	bl	57c4 <fwp_data.part.0.constprop.0>
    a650:	97ffeccc 	bl	5980 <fwp_rc_fresh>
    a654:	aa0003e2 	mov	x2, x0
    a658:	910423e1 	add	x1, sp, #0x108
    a65c:	52800020 	mov	w0, #0x1                   	// #1
    a660:	a9108bf7 	stp	x23, x2, [sp, #264]
    a664:	97ffec58 	bl	57c4 <fwp_data.part.0.constprop.0>
    a668:	91174283 	add	x3, x20, #0x5d0
    a66c:	aa0003f5 	mov	x21, x0
    a670:	f949d861 	ldr	x1, [x3, #5040]
    a674:	f949ec60 	ldr	x0, [x3, #5080]
    a678:	cb0102a1 	sub	x1, x21, x1
    a67c:	eb00403f 	cmp	x1, x0, lsl #16
    a680:	54000322 	b.cs	a6e4 <f0+0x484>  // b.hs, b.nlast
    a684:	d350fc22 	lsr	x2, x1, #16
    a688:	f949fc63 	ldr	x3, [x3, #5112]
    a68c:	8b020842 	add	x2, x2, x2, lsl #2
    a690:	d37df042 	lsl	x2, x2, #3
    a694:	8b020060 	add	x0, x3, x2
    a698:	f9401017 	ldr	x23, [x0, #32]
    a69c:	b4000257 	cbz	x23, a6e4 <f0+0x484>
    a6a0:	38626862 	ldrb	w2, [x3, x2]
    a6a4:	7100085f 	cmp	w2, #0x2
    a6a8:	5400f920 	b.eq	c5cc <f0+0x236c>  // b.none
    a6ac:	7100045f 	cmp	w2, #0x1
    a6b0:	540001a1 	b.ne	a6e4 <f0+0x484>  // b.any
    a6b4:	29430002 	ldp	w2, w0, [x0, #24]
    a6b8:	92403c21 	and	x1, x1, #0xffff
    a6bc:	9b027c21 	mul	x1, x1, x2
    a6c0:	d360fc21 	lsr	x1, x1, #32
    a6c4:	eb00003f 	cmp	x1, x0
    a6c8:	540000e2 	b.cs	a6e4 <f0+0x484>  // b.hs, b.nlast
    a6cc:	8b0102f7 	add	x23, x23, x1
    a6d0:	394002e0 	ldrb	w0, [x23]
    a6d4:	7103fc1f 	cmp	w0, #0xff
    a6d8:	54010280 	b.eq	c728 <f0+0x24c8>  // b.none
    a6dc:	52800020 	mov	w0, #0x1                   	// #1
    a6e0:	390002e0 	strb	w0, [x23]
    a6e4:	910463e1 	add	x1, sp, #0x118
    a6e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a6ec:	52800020 	mov	w0, #0x1                   	// #1
    a6f0:	a911d7f7 	stp	x23, x21, [sp, #280]
    a6f4:	97ffec34 	bl	57c4 <fwp_data.part.0.constprop.0>
    a6f8:	97ffeca2 	bl	5980 <fwp_rc_fresh>
    a6fc:	aa0003e2 	mov	x2, x0
    a700:	9104a3e1 	add	x1, sp, #0x128
    a704:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a708:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a70c:	52800020 	mov	w0, #0x1                   	// #1
    a710:	a9128bf5 	stp	x21, x2, [sp, #296]
    a714:	97ffec2c 	bl	57c4 <fwp_data.part.0.constprop.0>
    a718:	97ffec9a 	bl	5980 <fwp_rc_fresh>
    a71c:	aa0003e2 	mov	x2, x0
    a720:	9104e3e1 	add	x1, sp, #0x138
    a724:	52800020 	mov	w0, #0x1                   	// #1
    a728:	a9138bf7 	stp	x23, x2, [sp, #312]
    a72c:	97ffec26 	bl	57c4 <fwp_data.part.0.constprop.0>
    a730:	97ffec94 	bl	5980 <fwp_rc_fresh>
    a734:	aa0003e2 	mov	x2, x0
    a738:	910523e1 	add	x1, sp, #0x148
    a73c:	52800020 	mov	w0, #0x1                   	// #1
    a740:	a9148bf5 	stp	x21, x2, [sp, #328]
    a744:	97ffec20 	bl	57c4 <fwp_data.part.0.constprop.0>
    a748:	91174283 	add	x3, x20, #0x5d0
    a74c:	aa0003f5 	mov	x21, x0
    a750:	f949d861 	ldr	x1, [x3, #5040]
    a754:	f949ec60 	ldr	x0, [x3, #5080]
    a758:	cb0102a1 	sub	x1, x21, x1
    a75c:	eb00403f 	cmp	x1, x0, lsl #16
    a760:	54000322 	b.cs	a7c4 <f0+0x564>  // b.hs, b.nlast
    a764:	d350fc22 	lsr	x2, x1, #16
    a768:	f949fc63 	ldr	x3, [x3, #5112]
    a76c:	8b020842 	add	x2, x2, x2, lsl #2
    a770:	d37df042 	lsl	x2, x2, #3
    a774:	8b020060 	add	x0, x3, x2
    a778:	f9401017 	ldr	x23, [x0, #32]
    a77c:	b4000257 	cbz	x23, a7c4 <f0+0x564>
    a780:	38626862 	ldrb	w2, [x3, x2]
    a784:	7100085f 	cmp	w2, #0x2
    a788:	5400f1c0 	b.eq	c5c0 <f0+0x2360>  // b.none
    a78c:	7100045f 	cmp	w2, #0x1
    a790:	540001a1 	b.ne	a7c4 <f0+0x564>  // b.any
    a794:	29430002 	ldp	w2, w0, [x0, #24]
    a798:	92403c21 	and	x1, x1, #0xffff
    a79c:	9b027c21 	mul	x1, x1, x2
    a7a0:	d360fc21 	lsr	x1, x1, #32
    a7a4:	eb00003f 	cmp	x1, x0
    a7a8:	540000e2 	b.cs	a7c4 <f0+0x564>  // b.hs, b.nlast
    a7ac:	8b0102f7 	add	x23, x23, x1
    a7b0:	394002e0 	ldrb	w0, [x23]
    a7b4:	7103fc1f 	cmp	w0, #0xff
    a7b8:	5400fbe0 	b.eq	c734 <f0+0x24d4>  // b.none
    a7bc:	52800020 	mov	w0, #0x1                   	// #1
    a7c0:	390002e0 	strb	w0, [x23]
    a7c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7c8:	910563e1 	add	x1, sp, #0x158
    a7cc:	52800020 	mov	w0, #0x1                   	// #1
    a7d0:	a915d7e2 	stp	x2, x21, [sp, #344]
    a7d4:	97ffebfc 	bl	57c4 <fwp_data.part.0.constprop.0>
    a7d8:	91174283 	add	x3, x20, #0x5d0
    a7dc:	aa0003f5 	mov	x21, x0
    a7e0:	f949d861 	ldr	x1, [x3, #5040]
    a7e4:	f949ec60 	ldr	x0, [x3, #5080]
    a7e8:	cb0102a1 	sub	x1, x21, x1
    a7ec:	eb00403f 	cmp	x1, x0, lsl #16
    a7f0:	54000322 	b.cs	a854 <f0+0x5f4>  // b.hs, b.nlast
    a7f4:	d350fc22 	lsr	x2, x1, #16
    a7f8:	f949fc63 	ldr	x3, [x3, #5112]
    a7fc:	8b020842 	add	x2, x2, x2, lsl #2
    a800:	d37df042 	lsl	x2, x2, #3
    a804:	8b020060 	add	x0, x3, x2
    a808:	f9401017 	ldr	x23, [x0, #32]
    a80c:	b4000257 	cbz	x23, a854 <f0+0x5f4>
    a810:	38626862 	ldrb	w2, [x3, x2]
    a814:	7100085f 	cmp	w2, #0x2
    a818:	5400ece0 	b.eq	c5b4 <f0+0x2354>  // b.none
    a81c:	7100045f 	cmp	w2, #0x1
    a820:	540001a1 	b.ne	a854 <f0+0x5f4>  // b.any
    a824:	29430002 	ldp	w2, w0, [x0, #24]
    a828:	92403c21 	and	x1, x1, #0xffff
    a82c:	9b027c21 	mul	x1, x1, x2
    a830:	d360fc21 	lsr	x1, x1, #32
    a834:	eb00003f 	cmp	x1, x0
    a838:	540000e2 	b.cs	a854 <f0+0x5f4>  // b.hs, b.nlast
    a83c:	8b0102f7 	add	x23, x23, x1
    a840:	394002e0 	ldrb	w0, [x23]
    a844:	7103fc1f 	cmp	w0, #0xff
    a848:	5400f7c0 	b.eq	c740 <f0+0x24e0>  // b.none
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	390002e0 	strb	w0, [x23]
    a854:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a858:	9105a3e1 	add	x1, sp, #0x168
    a85c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a860:	52800020 	mov	w0, #0x1                   	// #1
    a864:	a916d7e2 	stp	x2, x21, [sp, #360]
    a868:	97ffebd7 	bl	57c4 <fwp_data.part.0.constprop.0>
    a86c:	91174283 	add	x3, x20, #0x5d0
    a870:	aa0003f5 	mov	x21, x0
    a874:	f949d861 	ldr	x1, [x3, #5040]
    a878:	f949ec60 	ldr	x0, [x3, #5080]
    a87c:	cb0102a1 	sub	x1, x21, x1
    a880:	eb00403f 	cmp	x1, x0, lsl #16
    a884:	54000322 	b.cs	a8e8 <f0+0x688>  // b.hs, b.nlast
    a888:	d350fc22 	lsr	x2, x1, #16
    a88c:	f949fc63 	ldr	x3, [x3, #5112]
    a890:	8b020842 	add	x2, x2, x2, lsl #2
    a894:	d37df042 	lsl	x2, x2, #3
    a898:	8b020060 	add	x0, x3, x2
    a89c:	f9401017 	ldr	x23, [x0, #32]
    a8a0:	b4000257 	cbz	x23, a8e8 <f0+0x688>
    a8a4:	38626862 	ldrb	w2, [x3, x2]
    a8a8:	7100085f 	cmp	w2, #0x2
    a8ac:	5400e7e0 	b.eq	c5a8 <f0+0x2348>  // b.none
    a8b0:	7100045f 	cmp	w2, #0x1
    a8b4:	540001a1 	b.ne	a8e8 <f0+0x688>  // b.any
    a8b8:	29430002 	ldp	w2, w0, [x0, #24]
    a8bc:	92403c21 	and	x1, x1, #0xffff
    a8c0:	9b027c21 	mul	x1, x1, x2
    a8c4:	d360fc21 	lsr	x1, x1, #32
    a8c8:	eb00003f 	cmp	x1, x0
    a8cc:	540000e2 	b.cs	a8e8 <f0+0x688>  // b.hs, b.nlast
    a8d0:	8b0102f7 	add	x23, x23, x1
    a8d4:	394002e0 	ldrb	w0, [x23]
    a8d8:	7103fc1f 	cmp	w0, #0xff
    a8dc:	5400f380 	b.eq	c74c <f0+0x24ec>  // b.none
    a8e0:	52800020 	mov	w0, #0x1                   	// #1
    a8e4:	390002e0 	strb	w0, [x23]
    a8e8:	9105e3e1 	add	x1, sp, #0x178
    a8ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a8f0:	52800020 	mov	w0, #0x1                   	// #1
    a8f4:	a917d7e2 	stp	x2, x21, [sp, #376]
    a8f8:	97ffebb3 	bl	57c4 <fwp_data.part.0.constprop.0>
    a8fc:	97ffec21 	bl	5980 <fwp_rc_fresh>
    a900:	aa0003e2 	mov	x2, x0
    a904:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a908:	910623e1 	add	x1, sp, #0x188
    a90c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a910:	52800020 	mov	w0, #0x1                   	// #1
    a914:	a9188be3 	stp	x3, x2, [sp, #392]
    a918:	97ffebab 	bl	57c4 <fwp_data.part.0.constprop.0>
    a91c:	91174283 	add	x3, x20, #0x5d0
    a920:	aa0003f5 	mov	x21, x0
    a924:	f949d861 	ldr	x1, [x3, #5040]
    a928:	f949ec60 	ldr	x0, [x3, #5080]
    a92c:	cb0102a1 	sub	x1, x21, x1
    a930:	eb00403f 	cmp	x1, x0, lsl #16
    a934:	54000322 	b.cs	a998 <f0+0x738>  // b.hs, b.nlast
    a938:	d350fc22 	lsr	x2, x1, #16
    a93c:	f949fc63 	ldr	x3, [x3, #5112]
    a940:	8b020842 	add	x2, x2, x2, lsl #2
    a944:	d37df042 	lsl	x2, x2, #3
    a948:	8b020060 	add	x0, x3, x2
    a94c:	f9401017 	ldr	x23, [x0, #32]
    a950:	b4000257 	cbz	x23, a998 <f0+0x738>
    a954:	38626862 	ldrb	w2, [x3, x2]
    a958:	7100085f 	cmp	w2, #0x2
    a95c:	5400e680 	b.eq	c62c <f0+0x23cc>  // b.none
    a960:	7100045f 	cmp	w2, #0x1
    a964:	540001a1 	b.ne	a998 <f0+0x738>  // b.any
    a968:	29430002 	ldp	w2, w0, [x0, #24]
    a96c:	92403c21 	and	x1, x1, #0xffff
    a970:	9b027c21 	mul	x1, x1, x2
    a974:	d360fc21 	lsr	x1, x1, #32
    a978:	eb00003f 	cmp	x1, x0
    a97c:	540000e2 	b.cs	a998 <f0+0x738>  // b.hs, b.nlast
    a980:	8b0102f7 	add	x23, x23, x1
    a984:	394002e0 	ldrb	w0, [x23]
    a988:	7103fc1f 	cmp	w0, #0xff
    a98c:	5400ee60 	b.eq	c758 <f0+0x24f8>  // b.none
    a990:	52800020 	mov	w0, #0x1                   	// #1
    a994:	390002e0 	strb	w0, [x23]
    a998:	910663e1 	add	x1, sp, #0x198
    a99c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9a0:	52800020 	mov	w0, #0x1                   	// #1
    a9a4:	a919d7e2 	stp	x2, x21, [sp, #408]
    a9a8:	97ffeb87 	bl	57c4 <fwp_data.part.0.constprop.0>
    a9ac:	97ffebf5 	bl	5980 <fwp_rc_fresh>
    a9b0:	aa0003e2 	mov	x2, x0
    a9b4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9b8:	9106a3e1 	add	x1, sp, #0x1a8
    a9bc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a9c0:	52800020 	mov	w0, #0x1                   	// #1
    a9c4:	a91a8be3 	stp	x3, x2, [sp, #424]
    a9c8:	97ffeb7f 	bl	57c4 <fwp_data.part.0.constprop.0>
    a9cc:	91174283 	add	x3, x20, #0x5d0
    a9d0:	aa0003f5 	mov	x21, x0
    a9d4:	f949d861 	ldr	x1, [x3, #5040]
    a9d8:	f949ec60 	ldr	x0, [x3, #5080]
    a9dc:	cb0102a1 	sub	x1, x21, x1
    a9e0:	eb00403f 	cmp	x1, x0, lsl #16
    a9e4:	54000322 	b.cs	aa48 <f0+0x7e8>  // b.hs, b.nlast
    a9e8:	d350fc22 	lsr	x2, x1, #16
    a9ec:	f949fc63 	ldr	x3, [x3, #5112]
    a9f0:	8b020842 	add	x2, x2, x2, lsl #2
    a9f4:	d37df042 	lsl	x2, x2, #3
    a9f8:	8b020060 	add	x0, x3, x2
    a9fc:	f9401017 	ldr	x23, [x0, #32]
    aa00:	b4000257 	cbz	x23, aa48 <f0+0x7e8>
    aa04:	38626862 	ldrb	w2, [x3, x2]
    aa08:	7100085f 	cmp	w2, #0x2
    aa0c:	5400e0a0 	b.eq	c620 <f0+0x23c0>  // b.none
    aa10:	7100045f 	cmp	w2, #0x1
    aa14:	540001a1 	b.ne	aa48 <f0+0x7e8>  // b.any
    aa18:	29430002 	ldp	w2, w0, [x0, #24]
    aa1c:	92403c21 	and	x1, x1, #0xffff
    aa20:	9b027c21 	mul	x1, x1, x2
    aa24:	d360fc21 	lsr	x1, x1, #32
    aa28:	eb00003f 	cmp	x1, x0
    aa2c:	540000e2 	b.cs	aa48 <f0+0x7e8>  // b.hs, b.nlast
    aa30:	8b0102f7 	add	x23, x23, x1
    aa34:	394002e0 	ldrb	w0, [x23]
    aa38:	7103fc1f 	cmp	w0, #0xff
    aa3c:	5400e940 	b.eq	c764 <f0+0x2504>  // b.none
    aa40:	52800020 	mov	w0, #0x1                   	// #1
    aa44:	390002e0 	strb	w0, [x23]
    aa48:	9106e3e1 	add	x1, sp, #0x1b8
    aa4c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa50:	52800020 	mov	w0, #0x1                   	// #1
    aa54:	a91bd7e2 	stp	x2, x21, [sp, #440]
    aa58:	97ffeb5b 	bl	57c4 <fwp_data.part.0.constprop.0>
    aa5c:	97ffebc9 	bl	5980 <fwp_rc_fresh>
    aa60:	aa0003e2 	mov	x2, x0
    aa64:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa68:	910723e1 	add	x1, sp, #0x1c8
    aa6c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa70:	52800020 	mov	w0, #0x1                   	// #1
    aa74:	a91c8be3 	stp	x3, x2, [sp, #456]
    aa78:	97ffeb53 	bl	57c4 <fwp_data.part.0.constprop.0>
    aa7c:	91174283 	add	x3, x20, #0x5d0
    aa80:	aa0003f5 	mov	x21, x0
    aa84:	f949d861 	ldr	x1, [x3, #5040]
    aa88:	f949ec60 	ldr	x0, [x3, #5080]
    aa8c:	cb0102a1 	sub	x1, x21, x1
    aa90:	eb00403f 	cmp	x1, x0, lsl #16
    aa94:	54000322 	b.cs	aaf8 <f0+0x898>  // b.hs, b.nlast
    aa98:	d350fc22 	lsr	x2, x1, #16
    aa9c:	f949fc63 	ldr	x3, [x3, #5112]
    aaa0:	8b020842 	add	x2, x2, x2, lsl #2
    aaa4:	d37df042 	lsl	x2, x2, #3
    aaa8:	8b020060 	add	x0, x3, x2
    aaac:	f9401017 	ldr	x23, [x0, #32]
    aab0:	b4000257 	cbz	x23, aaf8 <f0+0x898>
    aab4:	38626862 	ldrb	w2, [x3, x2]
    aab8:	7100085f 	cmp	w2, #0x2
    aabc:	5400dac0 	b.eq	c614 <f0+0x23b4>  // b.none
    aac0:	7100045f 	cmp	w2, #0x1
    aac4:	540001a1 	b.ne	aaf8 <f0+0x898>  // b.any
    aac8:	29430002 	ldp	w2, w0, [x0, #24]
    aacc:	92403c21 	and	x1, x1, #0xffff
    aad0:	9b027c21 	mul	x1, x1, x2
    aad4:	d360fc21 	lsr	x1, x1, #32
    aad8:	eb00003f 	cmp	x1, x0
    aadc:	540000e2 	b.cs	aaf8 <f0+0x898>  // b.hs, b.nlast
    aae0:	8b0102f7 	add	x23, x23, x1
    aae4:	394002e0 	ldrb	w0, [x23]
    aae8:	7103fc1f 	cmp	w0, #0xff
    aaec:	5400e420 	b.eq	c770 <f0+0x2510>  // b.none
    aaf0:	52800020 	mov	w0, #0x1                   	// #1
    aaf4:	390002e0 	strb	w0, [x23]
    aaf8:	910763e1 	add	x1, sp, #0x1d8
    aafc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ab00:	52800020 	mov	w0, #0x1                   	// #1
    ab04:	a91dd7f7 	stp	x23, x21, [sp, #472]
    ab08:	97ffeb2f 	bl	57c4 <fwp_data.part.0.constprop.0>
    ab0c:	97ffeb9d 	bl	5980 <fwp_rc_fresh>
    ab10:	aa0003e2 	mov	x2, x0
    ab14:	9107a3e1 	add	x1, sp, #0x1e8
    ab18:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ab1c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ab20:	52800020 	mov	w0, #0x1                   	// #1
    ab24:	a91e8bf5 	stp	x21, x2, [sp, #488]
    ab28:	97ffeb27 	bl	57c4 <fwp_data.part.0.constprop.0>
    ab2c:	97ffeb95 	bl	5980 <fwp_rc_fresh>
    ab30:	aa0003e2 	mov	x2, x0
    ab34:	9107e3e1 	add	x1, sp, #0x1f8
    ab38:	52800020 	mov	w0, #0x1                   	// #1
    ab3c:	a91f8bf7 	stp	x23, x2, [sp, #504]
    ab40:	97ffeb21 	bl	57c4 <fwp_data.part.0.constprop.0>
    ab44:	97ffeb8f 	bl	5980 <fwp_rc_fresh>
    ab48:	aa0003e2 	mov	x2, x0
    ab4c:	910823e1 	add	x1, sp, #0x208
    ab50:	52800020 	mov	w0, #0x1                   	// #1
    ab54:	f90107f5 	str	x21, [sp, #520]
    ab58:	f9010be2 	str	x2, [sp, #528]
    ab5c:	97ffeb1a 	bl	57c4 <fwp_data.part.0.constprop.0>
    ab60:	91174283 	add	x3, x20, #0x5d0
    ab64:	aa0003f5 	mov	x21, x0
    ab68:	f949d861 	ldr	x1, [x3, #5040]
    ab6c:	f949ec60 	ldr	x0, [x3, #5080]
    ab70:	cb0102a1 	sub	x1, x21, x1
    ab74:	eb00403f 	cmp	x1, x0, lsl #16
    ab78:	54000322 	b.cs	abdc <f0+0x97c>  // b.hs, b.nlast
    ab7c:	d350fc22 	lsr	x2, x1, #16
    ab80:	f949fc63 	ldr	x3, [x3, #5112]
    ab84:	8b020842 	add	x2, x2, x2, lsl #2
    ab88:	d37df042 	lsl	x2, x2, #3
    ab8c:	8b020060 	add	x0, x3, x2
    ab90:	f9401017 	ldr	x23, [x0, #32]
    ab94:	b4000257 	cbz	x23, abdc <f0+0x97c>
    ab98:	38626862 	ldrb	w2, [x3, x2]
    ab9c:	7100085f 	cmp	w2, #0x2
    aba0:	5400d340 	b.eq	c608 <f0+0x23a8>  // b.none
    aba4:	7100045f 	cmp	w2, #0x1
    aba8:	540001a1 	b.ne	abdc <f0+0x97c>  // b.any
    abac:	29430002 	ldp	w2, w0, [x0, #24]
    abb0:	92403c21 	and	x1, x1, #0xffff
    abb4:	9b027c21 	mul	x1, x1, x2
    abb8:	d360fc21 	lsr	x1, x1, #32
    abbc:	eb00003f 	cmp	x1, x0
    abc0:	540000e2 	b.cs	abdc <f0+0x97c>  // b.hs, b.nlast
    abc4:	8b0102f7 	add	x23, x23, x1
    abc8:	394002e0 	ldrb	w0, [x23]
    abcc:	7103fc1f 	cmp	w0, #0xff
    abd0:	5400dd60 	b.eq	c77c <f0+0x251c>  // b.none
    abd4:	52800020 	mov	w0, #0x1                   	// #1
    abd8:	390002e0 	strb	w0, [x23]
    abdc:	910863e1 	add	x1, sp, #0x218
    abe0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    abe4:	52800020 	mov	w0, #0x1                   	// #1
    abe8:	f9010fe2 	str	x2, [sp, #536]
    abec:	f90113f5 	str	x21, [sp, #544]
    abf0:	97ffeaf5 	bl	57c4 <fwp_data.part.0.constprop.0>
    abf4:	97ffeb63 	bl	5980 <fwp_rc_fresh>
    abf8:	aa0003e2 	mov	x2, x0
    abfc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac00:	9108a3e1 	add	x1, sp, #0x228
    ac04:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac08:	52800020 	mov	w0, #0x1                   	// #1
    ac0c:	f90117e3 	str	x3, [sp, #552]
    ac10:	f9011be2 	str	x2, [sp, #560]
    ac14:	97ffeaec 	bl	57c4 <fwp_data.part.0.constprop.0>
    ac18:	91174283 	add	x3, x20, #0x5d0
    ac1c:	aa0003f5 	mov	x21, x0
    ac20:	f949d861 	ldr	x1, [x3, #5040]
    ac24:	f949ec60 	ldr	x0, [x3, #5080]
    ac28:	cb0102a1 	sub	x1, x21, x1
    ac2c:	eb00403f 	cmp	x1, x0, lsl #16
    ac30:	54000322 	b.cs	ac94 <f0+0xa34>  // b.hs, b.nlast
    ac34:	d350fc22 	lsr	x2, x1, #16
    ac38:	f949fc63 	ldr	x3, [x3, #5112]
    ac3c:	8b020842 	add	x2, x2, x2, lsl #2
    ac40:	d37df042 	lsl	x2, x2, #3
    ac44:	8b020060 	add	x0, x3, x2
    ac48:	f9401017 	ldr	x23, [x0, #32]
    ac4c:	b4000257 	cbz	x23, ac94 <f0+0xa34>
    ac50:	38626862 	ldrb	w2, [x3, x2]
    ac54:	7100085f 	cmp	w2, #0x2
    ac58:	5400cd20 	b.eq	c5fc <f0+0x239c>  // b.none
    ac5c:	7100045f 	cmp	w2, #0x1
    ac60:	540001a1 	b.ne	ac94 <f0+0xa34>  // b.any
    ac64:	29430002 	ldp	w2, w0, [x0, #24]
    ac68:	92403c21 	and	x1, x1, #0xffff
    ac6c:	9b027c21 	mul	x1, x1, x2
    ac70:	d360fc21 	lsr	x1, x1, #32
    ac74:	eb00003f 	cmp	x1, x0
    ac78:	540000e2 	b.cs	ac94 <f0+0xa34>  // b.hs, b.nlast
    ac7c:	8b0102f7 	add	x23, x23, x1
    ac80:	394002e0 	ldrb	w0, [x23]
    ac84:	7103fc1f 	cmp	w0, #0xff
    ac88:	5400d800 	b.eq	c788 <f0+0x2528>  // b.none
    ac8c:	52800020 	mov	w0, #0x1                   	// #1
    ac90:	390002e0 	strb	w0, [x23]
    ac94:	9108e3e1 	add	x1, sp, #0x238
    ac98:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac9c:	52800020 	mov	w0, #0x1                   	// #1
    aca0:	f9011ff7 	str	x23, [sp, #568]
    aca4:	f90123f5 	str	x21, [sp, #576]
    aca8:	97ffeac7 	bl	57c4 <fwp_data.part.0.constprop.0>
    acac:	97ffeb35 	bl	5980 <fwp_rc_fresh>
    acb0:	aa0003e2 	mov	x2, x0
    acb4:	910923e1 	add	x1, sp, #0x248
    acb8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    acbc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    acc0:	52800020 	mov	w0, #0x1                   	// #1
    acc4:	f90127f5 	str	x21, [sp, #584]
    acc8:	f9012be2 	str	x2, [sp, #592]
    accc:	97ffeabe 	bl	57c4 <fwp_data.part.0.constprop.0>
    acd0:	97ffeb2c 	bl	5980 <fwp_rc_fresh>
    acd4:	aa0003e2 	mov	x2, x0
    acd8:	910963e1 	add	x1, sp, #0x258
    acdc:	52800020 	mov	w0, #0x1                   	// #1
    ace0:	f9012ff7 	str	x23, [sp, #600]
    ace4:	f90133e2 	str	x2, [sp, #608]
    ace8:	97ffeab7 	bl	57c4 <fwp_data.part.0.constprop.0>
    acec:	97ffeb25 	bl	5980 <fwp_rc_fresh>
    acf0:	aa0003e2 	mov	x2, x0
    acf4:	9109a3e1 	add	x1, sp, #0x268
    acf8:	52800020 	mov	w0, #0x1                   	// #1
    acfc:	f90137f5 	str	x21, [sp, #616]
    ad00:	f9013be2 	str	x2, [sp, #624]
    ad04:	97ffeab0 	bl	57c4 <fwp_data.part.0.constprop.0>
    ad08:	91174283 	add	x3, x20, #0x5d0
    ad0c:	aa0003f5 	mov	x21, x0
    ad10:	f949d861 	ldr	x1, [x3, #5040]
    ad14:	f949ec60 	ldr	x0, [x3, #5080]
    ad18:	cb0102a1 	sub	x1, x21, x1
    ad1c:	eb00403f 	cmp	x1, x0, lsl #16
    ad20:	54000322 	b.cs	ad84 <f0+0xb24>  // b.hs, b.nlast
    ad24:	d350fc22 	lsr	x2, x1, #16
    ad28:	f949fc63 	ldr	x3, [x3, #5112]
    ad2c:	8b020842 	add	x2, x2, x2, lsl #2
    ad30:	d37df042 	lsl	x2, x2, #3
    ad34:	8b020060 	add	x0, x3, x2
    ad38:	f9401017 	ldr	x23, [x0, #32]
    ad3c:	b4000257 	cbz	x23, ad84 <f0+0xb24>
    ad40:	38626862 	ldrb	w2, [x3, x2]
    ad44:	7100085f 	cmp	w2, #0x2
    ad48:	5400c540 	b.eq	c5f0 <f0+0x2390>  // b.none
    ad4c:	7100045f 	cmp	w2, #0x1
    ad50:	540001a1 	b.ne	ad84 <f0+0xb24>  // b.any
    ad54:	29430002 	ldp	w2, w0, [x0, #24]
    ad58:	92403c21 	and	x1, x1, #0xffff
    ad5c:	9b027c21 	mul	x1, x1, x2
    ad60:	d360fc21 	lsr	x1, x1, #32
    ad64:	eb00003f 	cmp	x1, x0
    ad68:	540000e2 	b.cs	ad84 <f0+0xb24>  // b.hs, b.nlast
    ad6c:	8b0102f7 	add	x23, x23, x1
    ad70:	394002e0 	ldrb	w0, [x23]
    ad74:	7103fc1f 	cmp	w0, #0xff
    ad78:	5400d0e0 	b.eq	c794 <f0+0x2534>  // b.none
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	390002e0 	strb	w0, [x23]
    ad84:	9109e3e1 	add	x1, sp, #0x278
    ad88:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad8c:	52800020 	mov	w0, #0x1                   	// #1
    ad90:	f9013fe2 	str	x2, [sp, #632]
    ad94:	f90143f5 	str	x21, [sp, #640]
    ad98:	97ffea8b 	bl	57c4 <fwp_data.part.0.constprop.0>
    ad9c:	97ffeaf9 	bl	5980 <fwp_rc_fresh>
    ada0:	aa0003e2 	mov	x2, x0
    ada4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ada8:	910a23e1 	add	x1, sp, #0x288
    adac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adb0:	52800020 	mov	w0, #0x1                   	// #1
    adb4:	f90147e3 	str	x3, [sp, #648]
    adb8:	f9014be2 	str	x2, [sp, #656]
    adbc:	97ffea82 	bl	57c4 <fwp_data.part.0.constprop.0>
    adc0:	91174283 	add	x3, x20, #0x5d0
    adc4:	aa0003f5 	mov	x21, x0
    adc8:	f949d861 	ldr	x1, [x3, #5040]
    adcc:	f949ec60 	ldr	x0, [x3, #5080]
    add0:	cb0102a1 	sub	x1, x21, x1
    add4:	eb00403f 	cmp	x1, x0, lsl #16
    add8:	54000322 	b.cs	ae3c <f0+0xbdc>  // b.hs, b.nlast
    addc:	d350fc22 	lsr	x2, x1, #16
    ade0:	f949fc63 	ldr	x3, [x3, #5112]
    ade4:	8b020842 	add	x2, x2, x2, lsl #2
    ade8:	d37df042 	lsl	x2, x2, #3
    adec:	8b020060 	add	x0, x3, x2
    adf0:	f9401017 	ldr	x23, [x0, #32]
    adf4:	b4000257 	cbz	x23, ae3c <f0+0xbdc>
    adf8:	38626862 	ldrb	w2, [x3, x2]
    adfc:	7100085f 	cmp	w2, #0x2
    ae00:	5400bf20 	b.eq	c5e4 <f0+0x2384>  // b.none
    ae04:	7100045f 	cmp	w2, #0x1
    ae08:	540001a1 	b.ne	ae3c <f0+0xbdc>  // b.any
    ae0c:	29430002 	ldp	w2, w0, [x0, #24]
    ae10:	92403c21 	and	x1, x1, #0xffff
    ae14:	9b027c21 	mul	x1, x1, x2
    ae18:	d360fc21 	lsr	x1, x1, #32
    ae1c:	eb00003f 	cmp	x1, x0
    ae20:	540000e2 	b.cs	ae3c <f0+0xbdc>  // b.hs, b.nlast
    ae24:	8b0102f7 	add	x23, x23, x1
    ae28:	394002e0 	ldrb	w0, [x23]
    ae2c:	7103fc1f 	cmp	w0, #0xff
    ae30:	5400cb80 	b.eq	c7a0 <f0+0x2540>  // b.none
    ae34:	52800020 	mov	w0, #0x1                   	// #1
    ae38:	390002e0 	strb	w0, [x23]
    ae3c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae40:	910a63e1 	add	x1, sp, #0x298
    ae44:	52800020 	mov	w0, #0x1                   	// #1
    ae48:	f9014fe2 	str	x2, [sp, #664]
    ae4c:	f90153f5 	str	x21, [sp, #672]
    ae50:	97ffea5d 	bl	57c4 <fwp_data.part.0.constprop.0>
    ae54:	91174283 	add	x3, x20, #0x5d0
    ae58:	aa0003f5 	mov	x21, x0
    ae5c:	f949d861 	ldr	x1, [x3, #5040]
    ae60:	f949ec60 	ldr	x0, [x3, #5080]
    ae64:	cb0102a1 	sub	x1, x21, x1
    ae68:	eb00403f 	cmp	x1, x0, lsl #16
    ae6c:	54000322 	b.cs	aed0 <f0+0xc70>  // b.hs, b.nlast
    ae70:	d350fc22 	lsr	x2, x1, #16
    ae74:	f949fc63 	ldr	x3, [x3, #5112]
    ae78:	8b020842 	add	x2, x2, x2, lsl #2
    ae7c:	d37df042 	lsl	x2, x2, #3
    ae80:	8b020060 	add	x0, x3, x2
    ae84:	f9401017 	ldr	x23, [x0, #32]
    ae88:	b4000257 	cbz	x23, aed0 <f0+0xc70>
    ae8c:	38626862 	ldrb	w2, [x3, x2]
    ae90:	7100085f 	cmp	w2, #0x2
    ae94:	5400ba20 	b.eq	c5d8 <f0+0x2378>  // b.none
    ae98:	7100045f 	cmp	w2, #0x1
    ae9c:	540001a1 	b.ne	aed0 <f0+0xc70>  // b.any
    aea0:	29430002 	ldp	w2, w0, [x0, #24]
    aea4:	92403c21 	and	x1, x1, #0xffff
    aea8:	9b027c21 	mul	x1, x1, x2
    aeac:	d360fc21 	lsr	x1, x1, #32
    aeb0:	eb00003f 	cmp	x1, x0
    aeb4:	540000e2 	b.cs	aed0 <f0+0xc70>  // b.hs, b.nlast
    aeb8:	8b0102f7 	add	x23, x23, x1
    aebc:	394002e0 	ldrb	w0, [x23]
    aec0:	7103fc1f 	cmp	w0, #0xff
    aec4:	5400c740 	b.eq	c7ac <f0+0x254c>  // b.none
    aec8:	52800020 	mov	w0, #0x1                   	// #1
    aecc:	390002e0 	strb	w0, [x23]
    aed0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aed4:	910aa3e1 	add	x1, sp, #0x2a8
    aed8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aedc:	52800020 	mov	w0, #0x1                   	// #1
    aee0:	f90157e2 	str	x2, [sp, #680]
    aee4:	f9015bf5 	str	x21, [sp, #688]
    aee8:	97ffea37 	bl	57c4 <fwp_data.part.0.constprop.0>
    aeec:	91174283 	add	x3, x20, #0x5d0
    aef0:	aa0003f5 	mov	x21, x0
    aef4:	f949d861 	ldr	x1, [x3, #5040]
    aef8:	f949ec60 	ldr	x0, [x3, #5080]
    aefc:	cb0102a1 	sub	x1, x21, x1
    af00:	eb00403f 	cmp	x1, x0, lsl #16
    af04:	54000322 	b.cs	af68 <f0+0xd08>  // b.hs, b.nlast
    af08:	d350fc22 	lsr	x2, x1, #16
    af0c:	f949fc63 	ldr	x3, [x3, #5112]
    af10:	8b020842 	add	x2, x2, x2, lsl #2
    af14:	d37df042 	lsl	x2, x2, #3
    af18:	8b020060 	add	x0, x3, x2
    af1c:	f9401017 	ldr	x23, [x0, #32]
    af20:	b4000257 	cbz	x23, af68 <f0+0xd08>
    af24:	38626862 	ldrb	w2, [x3, x2]
    af28:	7100085f 	cmp	w2, #0x2
    af2c:	5400b260 	b.eq	c578 <f0+0x2318>  // b.none
    af30:	7100045f 	cmp	w2, #0x1
    af34:	540001a1 	b.ne	af68 <f0+0xd08>  // b.any
    af38:	29430002 	ldp	w2, w0, [x0, #24]
    af3c:	92403c21 	and	x1, x1, #0xffff
    af40:	9b027c21 	mul	x1, x1, x2
    af44:	d360fc21 	lsr	x1, x1, #32
    af48:	eb00003f 	cmp	x1, x0
    af4c:	540000e2 	b.cs	af68 <f0+0xd08>  // b.hs, b.nlast
    af50:	8b0102f7 	add	x23, x23, x1
    af54:	394002e0 	ldrb	w0, [x23]
    af58:	7103fc1f 	cmp	w0, #0xff
    af5c:	5400c2e0 	b.eq	c7b8 <f0+0x2558>  // b.none
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	390002e0 	strb	w0, [x23]
    af68:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af6c:	910ae3e1 	add	x1, sp, #0x2b8
    af70:	52800020 	mov	w0, #0x1                   	// #1
    af74:	f9015fe2 	str	x2, [sp, #696]
    af78:	f90163f5 	str	x21, [sp, #704]
    af7c:	97ffea12 	bl	57c4 <fwp_data.part.0.constprop.0>
    af80:	91174283 	add	x3, x20, #0x5d0
    af84:	aa0003f5 	mov	x21, x0
    af88:	f949d861 	ldr	x1, [x3, #5040]
    af8c:	f949ec60 	ldr	x0, [x3, #5080]
    af90:	cb0102a1 	sub	x1, x21, x1
    af94:	eb00403f 	cmp	x1, x0, lsl #16
    af98:	54000322 	b.cs	affc <f0+0xd9c>  // b.hs, b.nlast
    af9c:	d350fc22 	lsr	x2, x1, #16
    afa0:	f949fc63 	ldr	x3, [x3, #5112]
    afa4:	8b020842 	add	x2, x2, x2, lsl #2
    afa8:	d37df042 	lsl	x2, x2, #3
    afac:	8b020060 	add	x0, x3, x2
    afb0:	f9401017 	ldr	x23, [x0, #32]
    afb4:	b4000257 	cbz	x23, affc <f0+0xd9c>
    afb8:	38626862 	ldrb	w2, [x3, x2]
    afbc:	7100085f 	cmp	w2, #0x2
    afc0:	5400ad60 	b.eq	c56c <f0+0x230c>  // b.none
    afc4:	7100045f 	cmp	w2, #0x1
    afc8:	540001a1 	b.ne	affc <f0+0xd9c>  // b.any
    afcc:	29430002 	ldp	w2, w0, [x0, #24]
    afd0:	92403c21 	and	x1, x1, #0xffff
    afd4:	9b027c21 	mul	x1, x1, x2
    afd8:	d360fc21 	lsr	x1, x1, #32
    afdc:	eb00003f 	cmp	x1, x0
    afe0:	540000e2 	b.cs	affc <f0+0xd9c>  // b.hs, b.nlast
    afe4:	8b0102f7 	add	x23, x23, x1
    afe8:	394002e0 	ldrb	w0, [x23]
    afec:	7103fc1f 	cmp	w0, #0xff
    aff0:	5400bea0 	b.eq	c7c4 <f0+0x2564>  // b.none
    aff4:	52800020 	mov	w0, #0x1                   	// #1
    aff8:	390002e0 	strb	w0, [x23]
    affc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b000:	910b23e1 	add	x1, sp, #0x2c8
    b004:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b008:	52800020 	mov	w0, #0x1                   	// #1
    b00c:	f90167e2 	str	x2, [sp, #712]
    b010:	f9016bf5 	str	x21, [sp, #720]
    b014:	97ffe9ec 	bl	57c4 <fwp_data.part.0.constprop.0>
    b018:	97ffea5a 	bl	5980 <fwp_rc_fresh>
    b01c:	aa0003e2 	mov	x2, x0
    b020:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b024:	910b63e1 	add	x1, sp, #0x2d8
    b028:	52800020 	mov	w0, #0x1                   	// #1
    b02c:	f9016fe3 	str	x3, [sp, #728]
    b030:	f90173e2 	str	x2, [sp, #736]
    b034:	97ffe9e4 	bl	57c4 <fwp_data.part.0.constprop.0>
    b038:	91174283 	add	x3, x20, #0x5d0
    b03c:	aa0003f5 	mov	x21, x0
    b040:	f949d861 	ldr	x1, [x3, #5040]
    b044:	f949ec60 	ldr	x0, [x3, #5080]
    b048:	cb0102a1 	sub	x1, x21, x1
    b04c:	eb00403f 	cmp	x1, x0, lsl #16
    b050:	54000322 	b.cs	b0b4 <f0+0xe54>  // b.hs, b.nlast
    b054:	d350fc22 	lsr	x2, x1, #16
    b058:	f949fc63 	ldr	x3, [x3, #5112]
    b05c:	8b020842 	add	x2, x2, x2, lsl #2
    b060:	d37df042 	lsl	x2, x2, #3
    b064:	8b020060 	add	x0, x3, x2
    b068:	f9401017 	ldr	x23, [x0, #32]
    b06c:	b4000257 	cbz	x23, b0b4 <f0+0xe54>
    b070:	38626862 	ldrb	w2, [x3, x2]
    b074:	7100085f 	cmp	w2, #0x2
    b078:	5400a740 	b.eq	c560 <f0+0x2300>  // b.none
    b07c:	7100045f 	cmp	w2, #0x1
    b080:	540001a1 	b.ne	b0b4 <f0+0xe54>  // b.any
    b084:	29430002 	ldp	w2, w0, [x0, #24]
    b088:	92403c21 	and	x1, x1, #0xffff
    b08c:	9b027c21 	mul	x1, x1, x2
    b090:	d360fc21 	lsr	x1, x1, #32
    b094:	eb00003f 	cmp	x1, x0
    b098:	540000e2 	b.cs	b0b4 <f0+0xe54>  // b.hs, b.nlast
    b09c:	8b0102f7 	add	x23, x23, x1
    b0a0:	394002e0 	ldrb	w0, [x23]
    b0a4:	7103fc1f 	cmp	w0, #0xff
    b0a8:	5400b940 	b.eq	c7d0 <f0+0x2570>  // b.none
    b0ac:	52800020 	mov	w0, #0x1                   	// #1
    b0b0:	390002e0 	strb	w0, [x23]
    b0b4:	910ba3e1 	add	x1, sp, #0x2e8
    b0b8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b0bc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b0c0:	52800020 	mov	w0, #0x1                   	// #1
    b0c4:	f90177f7 	str	x23, [sp, #744]
    b0c8:	f9017bf5 	str	x21, [sp, #752]
    b0cc:	97ffe9be 	bl	57c4 <fwp_data.part.0.constprop.0>
    b0d0:	97ffea2c 	bl	5980 <fwp_rc_fresh>
    b0d4:	aa0003e2 	mov	x2, x0
    b0d8:	910be3e1 	add	x1, sp, #0x2f8
    b0dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0e0:	52800020 	mov	w0, #0x1                   	// #1
    b0e4:	f9017ff5 	str	x21, [sp, #760]
    b0e8:	f90183e2 	str	x2, [sp, #768]
    b0ec:	97ffe9b6 	bl	57c4 <fwp_data.part.0.constprop.0>
    b0f0:	97ffea24 	bl	5980 <fwp_rc_fresh>
    b0f4:	aa0003e2 	mov	x2, x0
    b0f8:	910c23e1 	add	x1, sp, #0x308
    b0fc:	52800020 	mov	w0, #0x1                   	// #1
    b100:	f90187f7 	str	x23, [sp, #776]
    b104:	f9018be2 	str	x2, [sp, #784]
    b108:	97ffe9af 	bl	57c4 <fwp_data.part.0.constprop.0>
    b10c:	97ffea1d 	bl	5980 <fwp_rc_fresh>
    b110:	aa0003e2 	mov	x2, x0
    b114:	910c63e1 	add	x1, sp, #0x318
    b118:	52800020 	mov	w0, #0x1                   	// #1
    b11c:	f9018ff5 	str	x21, [sp, #792]
    b120:	f90193e2 	str	x2, [sp, #800]
    b124:	97ffe9a8 	bl	57c4 <fwp_data.part.0.constprop.0>
    b128:	97ffea16 	bl	5980 <fwp_rc_fresh>
    b12c:	aa0003e2 	mov	x2, x0
    b130:	910ca3e1 	add	x1, sp, #0x328
    b134:	52800020 	mov	w0, #0x1                   	// #1
    b138:	f90197f7 	str	x23, [sp, #808]
    b13c:	f9019be2 	str	x2, [sp, #816]
    b140:	97ffe9a1 	bl	57c4 <fwp_data.part.0.constprop.0>
    b144:	91174283 	add	x3, x20, #0x5d0
    b148:	aa0003f5 	mov	x21, x0
    b14c:	f949d861 	ldr	x1, [x3, #5040]
    b150:	f949ec60 	ldr	x0, [x3, #5080]
    b154:	cb0102a1 	sub	x1, x21, x1
    b158:	eb00403f 	cmp	x1, x0, lsl #16
    b15c:	54000322 	b.cs	b1c0 <f0+0xf60>  // b.hs, b.nlast
    b160:	d350fc22 	lsr	x2, x1, #16
    b164:	f949fc63 	ldr	x3, [x3, #5112]
    b168:	8b020842 	add	x2, x2, x2, lsl #2
    b16c:	d37df042 	lsl	x2, x2, #3
    b170:	8b020060 	add	x0, x3, x2
    b174:	f9401017 	ldr	x23, [x0, #32]
    b178:	b4000257 	cbz	x23, b1c0 <f0+0xf60>
    b17c:	38626862 	ldrb	w2, [x3, x2]
    b180:	7100085f 	cmp	w2, #0x2
    b184:	54009e80 	b.eq	c554 <f0+0x22f4>  // b.none
    b188:	7100045f 	cmp	w2, #0x1
    b18c:	540001a1 	b.ne	b1c0 <f0+0xf60>  // b.any
    b190:	29430002 	ldp	w2, w0, [x0, #24]
    b194:	92403c21 	and	x1, x1, #0xffff
    b198:	9b027c21 	mul	x1, x1, x2
    b19c:	d360fc21 	lsr	x1, x1, #32
    b1a0:	eb00003f 	cmp	x1, x0
    b1a4:	540000e2 	b.cs	b1c0 <f0+0xf60>  // b.hs, b.nlast
    b1a8:	8b0102f7 	add	x23, x23, x1
    b1ac:	394002e0 	ldrb	w0, [x23]
    b1b0:	7103fc1f 	cmp	w0, #0xff
    b1b4:	5400b140 	b.eq	c7dc <f0+0x257c>  // b.none
    b1b8:	52800020 	mov	w0, #0x1                   	// #1
    b1bc:	390002e0 	strb	w0, [x23]
    b1c0:	910ce3e1 	add	x1, sp, #0x338
    b1c4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b1c8:	52800020 	mov	w0, #0x1                   	// #1
    b1cc:	f9019ff7 	str	x23, [sp, #824]
    b1d0:	f901a3f5 	str	x21, [sp, #832]
    b1d4:	97ffe97c 	bl	57c4 <fwp_data.part.0.constprop.0>
    b1d8:	97ffe9ea 	bl	5980 <fwp_rc_fresh>
    b1dc:	aa0003e2 	mov	x2, x0
    b1e0:	910d23e1 	add	x1, sp, #0x348
    b1e4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b1e8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b1ec:	52800020 	mov	w0, #0x1                   	// #1
    b1f0:	f901a7f5 	str	x21, [sp, #840]
    b1f4:	f901abe2 	str	x2, [sp, #848]
    b1f8:	97ffe973 	bl	57c4 <fwp_data.part.0.constprop.0>
    b1fc:	97ffe9e1 	bl	5980 <fwp_rc_fresh>
    b200:	aa0003e2 	mov	x2, x0
    b204:	910d63e1 	add	x1, sp, #0x358
    b208:	52800020 	mov	w0, #0x1                   	// #1
    b20c:	f901aff7 	str	x23, [sp, #856]
    b210:	f901b3e2 	str	x2, [sp, #864]
    b214:	97ffe96c 	bl	57c4 <fwp_data.part.0.constprop.0>
    b218:	97ffe9da 	bl	5980 <fwp_rc_fresh>
    b21c:	aa0003e2 	mov	x2, x0
    b220:	910da3e1 	add	x1, sp, #0x368
    b224:	52800020 	mov	w0, #0x1                   	// #1
    b228:	f901b7f5 	str	x21, [sp, #872]
    b22c:	f901bbe2 	str	x2, [sp, #880]
    b230:	97ffe965 	bl	57c4 <fwp_data.part.0.constprop.0>
    b234:	91174283 	add	x3, x20, #0x5d0
    b238:	aa0003f5 	mov	x21, x0
    b23c:	f949d861 	ldr	x1, [x3, #5040]
    b240:	f949ec60 	ldr	x0, [x3, #5080]
    b244:	cb0102a1 	sub	x1, x21, x1
    b248:	eb00403f 	cmp	x1, x0, lsl #16
    b24c:	54000322 	b.cs	b2b0 <f0+0x1050>  // b.hs, b.nlast
    b250:	d350fc22 	lsr	x2, x1, #16
    b254:	f949fc63 	ldr	x3, [x3, #5112]
    b258:	8b020842 	add	x2, x2, x2, lsl #2
    b25c:	d37df042 	lsl	x2, x2, #3
    b260:	8b020060 	add	x0, x3, x2
    b264:	f9401017 	ldr	x23, [x0, #32]
    b268:	b4000257 	cbz	x23, b2b0 <f0+0x1050>
    b26c:	38626862 	ldrb	w2, [x3, x2]
    b270:	7100085f 	cmp	w2, #0x2
    b274:	540096a0 	b.eq	c548 <f0+0x22e8>  // b.none
    b278:	7100045f 	cmp	w2, #0x1
    b27c:	540001a1 	b.ne	b2b0 <f0+0x1050>  // b.any
    b280:	29430002 	ldp	w2, w0, [x0, #24]
    b284:	92403c21 	and	x1, x1, #0xffff
    b288:	9b027c21 	mul	x1, x1, x2
    b28c:	d360fc21 	lsr	x1, x1, #32
    b290:	eb00003f 	cmp	x1, x0
    b294:	540000e2 	b.cs	b2b0 <f0+0x1050>  // b.hs, b.nlast
    b298:	8b0102f7 	add	x23, x23, x1
    b29c:	394002e0 	ldrb	w0, [x23]
    b2a0:	7103fc1f 	cmp	w0, #0xff
    b2a4:	5400aa20 	b.eq	c7e8 <f0+0x2588>  // b.none
    b2a8:	52800020 	mov	w0, #0x1                   	// #1
    b2ac:	390002e0 	strb	w0, [x23]
    b2b0:	910de3e1 	add	x1, sp, #0x378
    b2b4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b2b8:	52800020 	mov	w0, #0x1                   	// #1
    b2bc:	f901bff7 	str	x23, [sp, #888]
    b2c0:	f901c3f5 	str	x21, [sp, #896]
    b2c4:	97ffe940 	bl	57c4 <fwp_data.part.0.constprop.0>
    b2c8:	97ffe9ae 	bl	5980 <fwp_rc_fresh>
    b2cc:	aa0003e2 	mov	x2, x0
    b2d0:	910e23e1 	add	x1, sp, #0x388
    b2d4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b2d8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b2dc:	52800020 	mov	w0, #0x1                   	// #1
    b2e0:	f901c7f5 	str	x21, [sp, #904]
    b2e4:	f901cbe2 	str	x2, [sp, #912]
    b2e8:	97ffe937 	bl	57c4 <fwp_data.part.0.constprop.0>
    b2ec:	97ffe9a5 	bl	5980 <fwp_rc_fresh>
    b2f0:	aa0003e2 	mov	x2, x0
    b2f4:	910e63e1 	add	x1, sp, #0x398
    b2f8:	52800020 	mov	w0, #0x1                   	// #1
    b2fc:	f901cff7 	str	x23, [sp, #920]
    b300:	f901d3e2 	str	x2, [sp, #928]
    b304:	97ffe930 	bl	57c4 <fwp_data.part.0.constprop.0>
    b308:	97ffe99e 	bl	5980 <fwp_rc_fresh>
    b30c:	aa0003e2 	mov	x2, x0
    b310:	910ea3e1 	add	x1, sp, #0x3a8
    b314:	52800020 	mov	w0, #0x1                   	// #1
    b318:	f901d7f5 	str	x21, [sp, #936]
    b31c:	f901dbe2 	str	x2, [sp, #944]
    b320:	97ffe929 	bl	57c4 <fwp_data.part.0.constprop.0>
    b324:	91174283 	add	x3, x20, #0x5d0
    b328:	aa0003f5 	mov	x21, x0
    b32c:	f949d861 	ldr	x1, [x3, #5040]
    b330:	f949ec60 	ldr	x0, [x3, #5080]
    b334:	cb0102a1 	sub	x1, x21, x1
    b338:	eb00403f 	cmp	x1, x0, lsl #16
    b33c:	54000322 	b.cs	b3a0 <f0+0x1140>  // b.hs, b.nlast
    b340:	d350fc22 	lsr	x2, x1, #16
    b344:	f949fc63 	ldr	x3, [x3, #5112]
    b348:	8b020842 	add	x2, x2, x2, lsl #2
    b34c:	d37df042 	lsl	x2, x2, #3
    b350:	8b020060 	add	x0, x3, x2
    b354:	f9401017 	ldr	x23, [x0, #32]
    b358:	b4000257 	cbz	x23, b3a0 <f0+0x1140>
    b35c:	38626862 	ldrb	w2, [x3, x2]
    b360:	7100085f 	cmp	w2, #0x2
    b364:	54008ec0 	b.eq	c53c <f0+0x22dc>  // b.none
    b368:	7100045f 	cmp	w2, #0x1
    b36c:	540001a1 	b.ne	b3a0 <f0+0x1140>  // b.any
    b370:	29430002 	ldp	w2, w0, [x0, #24]
    b374:	92403c21 	and	x1, x1, #0xffff
    b378:	9b027c21 	mul	x1, x1, x2
    b37c:	d360fc21 	lsr	x1, x1, #32
    b380:	eb00003f 	cmp	x1, x0
    b384:	540000e2 	b.cs	b3a0 <f0+0x1140>  // b.hs, b.nlast
    b388:	8b0102f7 	add	x23, x23, x1
    b38c:	394002e0 	ldrb	w0, [x23]
    b390:	7103fc1f 	cmp	w0, #0xff
    b394:	5400a300 	b.eq	c7f4 <f0+0x2594>  // b.none
    b398:	52800020 	mov	w0, #0x1                   	// #1
    b39c:	390002e0 	strb	w0, [x23]
    b3a0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b3a4:	910ee3e1 	add	x1, sp, #0x3b8
    b3a8:	52800020 	mov	w0, #0x1                   	// #1
    b3ac:	f901dfe2 	str	x2, [sp, #952]
    b3b0:	f901e3f5 	str	x21, [sp, #960]
    b3b4:	97ffe904 	bl	57c4 <fwp_data.part.0.constprop.0>
    b3b8:	91174283 	add	x3, x20, #0x5d0
    b3bc:	aa0003f5 	mov	x21, x0
    b3c0:	f949d861 	ldr	x1, [x3, #5040]
    b3c4:	f949ec60 	ldr	x0, [x3, #5080]
    b3c8:	cb0102a1 	sub	x1, x21, x1
    b3cc:	eb00403f 	cmp	x1, x0, lsl #16
    b3d0:	54000322 	b.cs	b434 <f0+0x11d4>  // b.hs, b.nlast
    b3d4:	d350fc22 	lsr	x2, x1, #16
    b3d8:	f949fc63 	ldr	x3, [x3, #5112]
    b3dc:	8b020842 	add	x2, x2, x2, lsl #2
    b3e0:	d37df042 	lsl	x2, x2, #3
    b3e4:	8b020060 	add	x0, x3, x2
    b3e8:	f9401017 	ldr	x23, [x0, #32]
    b3ec:	b4000257 	cbz	x23, b434 <f0+0x11d4>
    b3f0:	38626862 	ldrb	w2, [x3, x2]
    b3f4:	7100085f 	cmp	w2, #0x2
    b3f8:	540089c0 	b.eq	c530 <f0+0x22d0>  // b.none
    b3fc:	7100045f 	cmp	w2, #0x1
    b400:	540001a1 	b.ne	b434 <f0+0x11d4>  // b.any
    b404:	29430002 	ldp	w2, w0, [x0, #24]
    b408:	92403c21 	and	x1, x1, #0xffff
    b40c:	9b027c21 	mul	x1, x1, x2
    b410:	d360fc21 	lsr	x1, x1, #32
    b414:	eb00003f 	cmp	x1, x0
    b418:	540000e2 	b.cs	b434 <f0+0x11d4>  // b.hs, b.nlast
    b41c:	8b0102f7 	add	x23, x23, x1
    b420:	394002e0 	ldrb	w0, [x23]
    b424:	7103fc1f 	cmp	w0, #0xff
    b428:	54009ec0 	b.eq	c800 <f0+0x25a0>  // b.none
    b42c:	52800020 	mov	w0, #0x1                   	// #1
    b430:	390002e0 	strb	w0, [x23]
    b434:	910f23e1 	add	x1, sp, #0x3c8
    b438:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b43c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b440:	52800020 	mov	w0, #0x1                   	// #1
    b444:	f901e7f7 	str	x23, [sp, #968]
    b448:	f901ebf5 	str	x21, [sp, #976]
    b44c:	97ffe8de 	bl	57c4 <fwp_data.part.0.constprop.0>
    b450:	97ffe94c 	bl	5980 <fwp_rc_fresh>
    b454:	aa0003e2 	mov	x2, x0
    b458:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b45c:	910f63e1 	add	x1, sp, #0x3d8
    b460:	52800020 	mov	w0, #0x1                   	// #1
    b464:	f901efe3 	str	x3, [sp, #984]
    b468:	f901f3e2 	str	x2, [sp, #992]
    b46c:	97ffe8d6 	bl	57c4 <fwp_data.part.0.constprop.0>
    b470:	97ffe944 	bl	5980 <fwp_rc_fresh>
    b474:	aa0003e2 	mov	x2, x0
    b478:	910fa3e1 	add	x1, sp, #0x3e8
    b47c:	52800020 	mov	w0, #0x1                   	// #1
    b480:	f901f7f7 	str	x23, [sp, #1000]
    b484:	f901fbe2 	str	x2, [sp, #1008]
    b488:	97ffe8cf 	bl	57c4 <fwp_data.part.0.constprop.0>
    b48c:	91174283 	add	x3, x20, #0x5d0
    b490:	aa0003f5 	mov	x21, x0
    b494:	f949d861 	ldr	x1, [x3, #5040]
    b498:	f949ec60 	ldr	x0, [x3, #5080]
    b49c:	cb0102a1 	sub	x1, x21, x1
    b4a0:	eb00403f 	cmp	x1, x0, lsl #16
    b4a4:	54000322 	b.cs	b508 <f0+0x12a8>  // b.hs, b.nlast
    b4a8:	d350fc22 	lsr	x2, x1, #16
    b4ac:	f949fc63 	ldr	x3, [x3, #5112]
    b4b0:	8b020842 	add	x2, x2, x2, lsl #2
    b4b4:	d37df042 	lsl	x2, x2, #3
    b4b8:	8b020060 	add	x0, x3, x2
    b4bc:	f9401017 	ldr	x23, [x0, #32]
    b4c0:	b4000257 	cbz	x23, b508 <f0+0x12a8>
    b4c4:	38626862 	ldrb	w2, [x3, x2]
    b4c8:	7100085f 	cmp	w2, #0x2
    b4cc:	540082c0 	b.eq	c524 <f0+0x22c4>  // b.none
    b4d0:	7100045f 	cmp	w2, #0x1
    b4d4:	540001a1 	b.ne	b508 <f0+0x12a8>  // b.any
    b4d8:	29430002 	ldp	w2, w0, [x0, #24]
    b4dc:	92403c21 	and	x1, x1, #0xffff
    b4e0:	9b027c21 	mul	x1, x1, x2
    b4e4:	d360fc21 	lsr	x1, x1, #32
    b4e8:	eb00003f 	cmp	x1, x0
    b4ec:	540000e2 	b.cs	b508 <f0+0x12a8>  // b.hs, b.nlast
    b4f0:	8b0102f7 	add	x23, x23, x1
    b4f4:	394002e0 	ldrb	w0, [x23]
    b4f8:	7103fc1f 	cmp	w0, #0xff
    b4fc:	54009880 	b.eq	c80c <f0+0x25ac>  // b.none
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	390002e0 	strb	w0, [x23]
    b508:	910fe3e1 	add	x1, sp, #0x3f8
    b50c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b510:	52800020 	mov	w0, #0x1                   	// #1
    b514:	f901fff7 	str	x23, [sp, #1016]
    b518:	f90203f5 	str	x21, [sp, #1024]
    b51c:	97ffe8aa 	bl	57c4 <fwp_data.part.0.constprop.0>
    b520:	97ffe918 	bl	5980 <fwp_rc_fresh>
    b524:	aa0003e2 	mov	x2, x0
    b528:	911023e1 	add	x1, sp, #0x408
    b52c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b530:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	f90207f5 	str	x21, [sp, #1032]
    b53c:	f9020be2 	str	x2, [sp, #1040]
    b540:	97ffe8a1 	bl	57c4 <fwp_data.part.0.constprop.0>
    b544:	97ffe90f 	bl	5980 <fwp_rc_fresh>
    b548:	aa0003e2 	mov	x2, x0
    b54c:	911063e1 	add	x1, sp, #0x418
    b550:	52800020 	mov	w0, #0x1                   	// #1
    b554:	f9020ff7 	str	x23, [sp, #1048]
    b558:	f90213e2 	str	x2, [sp, #1056]
    b55c:	97ffe89a 	bl	57c4 <fwp_data.part.0.constprop.0>
    b560:	97ffe908 	bl	5980 <fwp_rc_fresh>
    b564:	aa0003e2 	mov	x2, x0
    b568:	9110a3e1 	add	x1, sp, #0x428
    b56c:	52800020 	mov	w0, #0x1                   	// #1
    b570:	f90217f5 	str	x21, [sp, #1064]
    b574:	f9021be2 	str	x2, [sp, #1072]
    b578:	97ffe893 	bl	57c4 <fwp_data.part.0.constprop.0>
    b57c:	91174283 	add	x3, x20, #0x5d0
    b580:	aa0003f5 	mov	x21, x0
    b584:	f949d861 	ldr	x1, [x3, #5040]
    b588:	f949ec60 	ldr	x0, [x3, #5080]
    b58c:	cb0102a1 	sub	x1, x21, x1
    b590:	eb00403f 	cmp	x1, x0, lsl #16
    b594:	54000322 	b.cs	b5f8 <f0+0x1398>  // b.hs, b.nlast
    b598:	d350fc22 	lsr	x2, x1, #16
    b59c:	f949fc63 	ldr	x3, [x3, #5112]
    b5a0:	8b020842 	add	x2, x2, x2, lsl #2
    b5a4:	d37df042 	lsl	x2, x2, #3
    b5a8:	8b020060 	add	x0, x3, x2
    b5ac:	f9401017 	ldr	x23, [x0, #32]
    b5b0:	b4000257 	cbz	x23, b5f8 <f0+0x1398>
    b5b4:	38626862 	ldrb	w2, [x3, x2]
    b5b8:	7100085f 	cmp	w2, #0x2
    b5bc:	54008980 	b.eq	c6ec <f0+0x248c>  // b.none
    b5c0:	7100045f 	cmp	w2, #0x1
    b5c4:	540001a1 	b.ne	b5f8 <f0+0x1398>  // b.any
    b5c8:	29430002 	ldp	w2, w0, [x0, #24]
    b5cc:	92403c21 	and	x1, x1, #0xffff
    b5d0:	9b027c21 	mul	x1, x1, x2
    b5d4:	d360fc21 	lsr	x1, x1, #32
    b5d8:	eb00003f 	cmp	x1, x0
    b5dc:	540000e2 	b.cs	b5f8 <f0+0x1398>  // b.hs, b.nlast
    b5e0:	8b0102f7 	add	x23, x23, x1
    b5e4:	394002e0 	ldrb	w0, [x23]
    b5e8:	7103fc1f 	cmp	w0, #0xff
    b5ec:	54009160 	b.eq	c818 <f0+0x25b8>  // b.none
    b5f0:	52800020 	mov	w0, #0x1                   	// #1
    b5f4:	390002e0 	strb	w0, [x23]
    b5f8:	9110e3e1 	add	x1, sp, #0x438
    b5fc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b600:	52800020 	mov	w0, #0x1                   	// #1
    b604:	f9021ff7 	str	x23, [sp, #1080]
    b608:	f90223f5 	str	x21, [sp, #1088]
    b60c:	97ffe86e 	bl	57c4 <fwp_data.part.0.constprop.0>
    b610:	97ffe8dc 	bl	5980 <fwp_rc_fresh>
    b614:	aa0003e2 	mov	x2, x0
    b618:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b61c:	911123e1 	add	x1, sp, #0x448
    b620:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b624:	52800020 	mov	w0, #0x1                   	// #1
    b628:	f90227e3 	str	x3, [sp, #1096]
    b62c:	f9022be2 	str	x2, [sp, #1104]
    b630:	97ffe865 	bl	57c4 <fwp_data.part.0.constprop.0>
    b634:	97ffe8d3 	bl	5980 <fwp_rc_fresh>
    b638:	aa0003e2 	mov	x2, x0
    b63c:	911163e1 	add	x1, sp, #0x458
    b640:	52800020 	mov	w0, #0x1                   	// #1
    b644:	f9022ff7 	str	x23, [sp, #1112]
    b648:	f90233e2 	str	x2, [sp, #1120]
    b64c:	97ffe85e 	bl	57c4 <fwp_data.part.0.constprop.0>
    b650:	91174283 	add	x3, x20, #0x5d0
    b654:	aa0003f5 	mov	x21, x0
    b658:	f949d861 	ldr	x1, [x3, #5040]
    b65c:	f949ec60 	ldr	x0, [x3, #5080]
    b660:	cb0102a1 	sub	x1, x21, x1
    b664:	eb00403f 	cmp	x1, x0, lsl #16
    b668:	54000322 	b.cs	b6cc <f0+0x146c>  // b.hs, b.nlast
    b66c:	d350fc22 	lsr	x2, x1, #16
    b670:	f949fc63 	ldr	x3, [x3, #5112]
    b674:	8b020842 	add	x2, x2, x2, lsl #2
    b678:	d37df042 	lsl	x2, x2, #3
    b67c:	8b020060 	add	x0, x3, x2
    b680:	f9401017 	ldr	x23, [x0, #32]
    b684:	b4000257 	cbz	x23, b6cc <f0+0x146c>
    b688:	38626862 	ldrb	w2, [x3, x2]
    b68c:	7100085f 	cmp	w2, #0x2
    b690:	54008280 	b.eq	c6e0 <f0+0x2480>  // b.none
    b694:	7100045f 	cmp	w2, #0x1
    b698:	540001a1 	b.ne	b6cc <f0+0x146c>  // b.any
    b69c:	29430002 	ldp	w2, w0, [x0, #24]
    b6a0:	92403c21 	and	x1, x1, #0xffff
    b6a4:	9b027c21 	mul	x1, x1, x2
    b6a8:	d360fc21 	lsr	x1, x1, #32
    b6ac:	eb00003f 	cmp	x1, x0
    b6b0:	540000e2 	b.cs	b6cc <f0+0x146c>  // b.hs, b.nlast
    b6b4:	8b0102f7 	add	x23, x23, x1
    b6b8:	394002e0 	ldrb	w0, [x23]
    b6bc:	7103fc1f 	cmp	w0, #0xff
    b6c0:	54008b20 	b.eq	c824 <f0+0x25c4>  // b.none
    b6c4:	52800020 	mov	w0, #0x1                   	// #1
    b6c8:	390002e0 	strb	w0, [x23]
    b6cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b6d0:	9111a3e1 	add	x1, sp, #0x468
    b6d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b6d8:	52800020 	mov	w0, #0x1                   	// #1
    b6dc:	f90237e2 	str	x2, [sp, #1128]
    b6e0:	f9023bf5 	str	x21, [sp, #1136]
    b6e4:	97ffe838 	bl	57c4 <fwp_data.part.0.constprop.0>
    b6e8:	91174283 	add	x3, x20, #0x5d0
    b6ec:	aa0003f5 	mov	x21, x0
    b6f0:	f949d861 	ldr	x1, [x3, #5040]
    b6f4:	f949ec60 	ldr	x0, [x3, #5080]
    b6f8:	cb0102a1 	sub	x1, x21, x1
    b6fc:	eb00403f 	cmp	x1, x0, lsl #16
    b700:	54000322 	b.cs	b764 <f0+0x1504>  // b.hs, b.nlast
    b704:	d350fc22 	lsr	x2, x1, #16
    b708:	f949fc63 	ldr	x3, [x3, #5112]
    b70c:	8b020842 	add	x2, x2, x2, lsl #2
    b710:	d37df042 	lsl	x2, x2, #3
    b714:	8b020060 	add	x0, x3, x2
    b718:	f9401017 	ldr	x23, [x0, #32]
    b71c:	b4000257 	cbz	x23, b764 <f0+0x1504>
    b720:	38626862 	ldrb	w2, [x3, x2]
    b724:	7100085f 	cmp	w2, #0x2
    b728:	54007d60 	b.eq	c6d4 <f0+0x2474>  // b.none
    b72c:	7100045f 	cmp	w2, #0x1
    b730:	540001a1 	b.ne	b764 <f0+0x1504>  // b.any
    b734:	29430002 	ldp	w2, w0, [x0, #24]
    b738:	92403c21 	and	x1, x1, #0xffff
    b73c:	9b027c21 	mul	x1, x1, x2
    b740:	d360fc21 	lsr	x1, x1, #32
    b744:	eb00003f 	cmp	x1, x0
    b748:	540000e2 	b.cs	b764 <f0+0x1504>  // b.hs, b.nlast
    b74c:	8b0102f7 	add	x23, x23, x1
    b750:	394002e0 	ldrb	w0, [x23]
    b754:	7103fc1f 	cmp	w0, #0xff
    b758:	540086c0 	b.eq	c830 <f0+0x25d0>  // b.none
    b75c:	52800020 	mov	w0, #0x1                   	// #1
    b760:	390002e0 	strb	w0, [x23]
    b764:	9111e3e1 	add	x1, sp, #0x478
    b768:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b76c:	52800020 	mov	w0, #0x1                   	// #1
    b770:	f9023ff7 	str	x23, [sp, #1144]
    b774:	f90243f5 	str	x21, [sp, #1152]
    b778:	97ffe813 	bl	57c4 <fwp_data.part.0.constprop.0>
    b77c:	97ffe881 	bl	5980 <fwp_rc_fresh>
    b780:	aa0003e2 	mov	x2, x0
    b784:	911223e1 	add	x1, sp, #0x488
    b788:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b78c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b790:	52800020 	mov	w0, #0x1                   	// #1
    b794:	f90247f5 	str	x21, [sp, #1160]
    b798:	f9024be2 	str	x2, [sp, #1168]
    b79c:	97ffe80a 	bl	57c4 <fwp_data.part.0.constprop.0>
    b7a0:	97ffe878 	bl	5980 <fwp_rc_fresh>
    b7a4:	aa0003e2 	mov	x2, x0
    b7a8:	911263e1 	add	x1, sp, #0x498
    b7ac:	52800020 	mov	w0, #0x1                   	// #1
    b7b0:	f9024ff7 	str	x23, [sp, #1176]
    b7b4:	f90253e2 	str	x2, [sp, #1184]
    b7b8:	97ffe803 	bl	57c4 <fwp_data.part.0.constprop.0>
    b7bc:	97ffe871 	bl	5980 <fwp_rc_fresh>
    b7c0:	aa0003e2 	mov	x2, x0
    b7c4:	9112a3e1 	add	x1, sp, #0x4a8
    b7c8:	52800020 	mov	w0, #0x1                   	// #1
    b7cc:	f90257f5 	str	x21, [sp, #1192]
    b7d0:	f9025be2 	str	x2, [sp, #1200]
    b7d4:	97ffe7fc 	bl	57c4 <fwp_data.part.0.constprop.0>
    b7d8:	91174283 	add	x3, x20, #0x5d0
    b7dc:	aa0003f5 	mov	x21, x0
    b7e0:	f949d861 	ldr	x1, [x3, #5040]
    b7e4:	f949ec60 	ldr	x0, [x3, #5080]
    b7e8:	cb0102a1 	sub	x1, x21, x1
    b7ec:	eb00403f 	cmp	x1, x0, lsl #16
    b7f0:	54000322 	b.cs	b854 <f0+0x15f4>  // b.hs, b.nlast
    b7f4:	d350fc22 	lsr	x2, x1, #16
    b7f8:	f949fc63 	ldr	x3, [x3, #5112]
    b7fc:	8b020842 	add	x2, x2, x2, lsl #2
    b800:	d37df042 	lsl	x2, x2, #3
    b804:	8b020060 	add	x0, x3, x2
    b808:	f9401017 	ldr	x23, [x0, #32]
    b80c:	b4000257 	cbz	x23, b854 <f0+0x15f4>
    b810:	38626862 	ldrb	w2, [x3, x2]
    b814:	7100085f 	cmp	w2, #0x2
    b818:	54007580 	b.eq	c6c8 <f0+0x2468>  // b.none
    b81c:	7100045f 	cmp	w2, #0x1
    b820:	540001a1 	b.ne	b854 <f0+0x15f4>  // b.any
    b824:	29430002 	ldp	w2, w0, [x0, #24]
    b828:	92403c21 	and	x1, x1, #0xffff
    b82c:	9b027c21 	mul	x1, x1, x2
    b830:	d360fc21 	lsr	x1, x1, #32
    b834:	eb00003f 	cmp	x1, x0
    b838:	540000e2 	b.cs	b854 <f0+0x15f4>  // b.hs, b.nlast
    b83c:	8b0102f7 	add	x23, x23, x1
    b840:	394002e0 	ldrb	w0, [x23]
    b844:	7103fc1f 	cmp	w0, #0xff
    b848:	54007fa0 	b.eq	c83c <f0+0x25dc>  // b.none
    b84c:	52800020 	mov	w0, #0x1                   	// #1
    b850:	390002e0 	strb	w0, [x23]
    b854:	9112e3e1 	add	x1, sp, #0x4b8
    b858:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b85c:	52800020 	mov	w0, #0x1                   	// #1
    b860:	f9025ff7 	str	x23, [sp, #1208]
    b864:	f90263f5 	str	x21, [sp, #1216]
    b868:	97ffe7d7 	bl	57c4 <fwp_data.part.0.constprop.0>
    b86c:	97ffe845 	bl	5980 <fwp_rc_fresh>
    b870:	aa0003e2 	mov	x2, x0
    b874:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b878:	911323e1 	add	x1, sp, #0x4c8
    b87c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b880:	52800020 	mov	w0, #0x1                   	// #1
    b884:	f90267e3 	str	x3, [sp, #1224]
    b888:	f9026be2 	str	x2, [sp, #1232]
    b88c:	97ffe7ce 	bl	57c4 <fwp_data.part.0.constprop.0>
    b890:	97ffe83c 	bl	5980 <fwp_rc_fresh>
    b894:	aa0003e2 	mov	x2, x0
    b898:	911363e1 	add	x1, sp, #0x4d8
    b89c:	52800020 	mov	w0, #0x1                   	// #1
    b8a0:	f9026ff7 	str	x23, [sp, #1240]
    b8a4:	f90273e2 	str	x2, [sp, #1248]
    b8a8:	97ffe7c7 	bl	57c4 <fwp_data.part.0.constprop.0>
    b8ac:	91174283 	add	x3, x20, #0x5d0
    b8b0:	aa0003f5 	mov	x21, x0
    b8b4:	f949d861 	ldr	x1, [x3, #5040]
    b8b8:	f949ec60 	ldr	x0, [x3, #5080]
    b8bc:	cb0102a1 	sub	x1, x21, x1
    b8c0:	eb00403f 	cmp	x1, x0, lsl #16
    b8c4:	54000322 	b.cs	b928 <f0+0x16c8>  // b.hs, b.nlast
    b8c8:	d350fc22 	lsr	x2, x1, #16
    b8cc:	f949fc63 	ldr	x3, [x3, #5112]
    b8d0:	8b020842 	add	x2, x2, x2, lsl #2
    b8d4:	d37df042 	lsl	x2, x2, #3
    b8d8:	8b020060 	add	x0, x3, x2
    b8dc:	f9401017 	ldr	x23, [x0, #32]
    b8e0:	b4000257 	cbz	x23, b928 <f0+0x16c8>
    b8e4:	38626862 	ldrb	w2, [x3, x2]
    b8e8:	7100085f 	cmp	w2, #0x2
    b8ec:	54006e80 	b.eq	c6bc <f0+0x245c>  // b.none
    b8f0:	7100045f 	cmp	w2, #0x1
    b8f4:	540001a1 	b.ne	b928 <f0+0x16c8>  // b.any
    b8f8:	29430002 	ldp	w2, w0, [x0, #24]
    b8fc:	92403c21 	and	x1, x1, #0xffff
    b900:	9b027c21 	mul	x1, x1, x2
    b904:	d360fc21 	lsr	x1, x1, #32
    b908:	eb00003f 	cmp	x1, x0
    b90c:	540000e2 	b.cs	b928 <f0+0x16c8>  // b.hs, b.nlast
    b910:	8b0102f7 	add	x23, x23, x1
    b914:	394002e0 	ldrb	w0, [x23]
    b918:	7103fc1f 	cmp	w0, #0xff
    b91c:	54007960 	b.eq	c848 <f0+0x25e8>  // b.none
    b920:	52800020 	mov	w0, #0x1                   	// #1
    b924:	390002e0 	strb	w0, [x23]
    b928:	9113a3e1 	add	x1, sp, #0x4e8
    b92c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b930:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b934:	52800020 	mov	w0, #0x1                   	// #1
    b938:	f90277f7 	str	x23, [sp, #1256]
    b93c:	f9027bf5 	str	x21, [sp, #1264]
    b940:	97ffe7a1 	bl	57c4 <fwp_data.part.0.constprop.0>
    b944:	97ffe80f 	bl	5980 <fwp_rc_fresh>
    b948:	aa0003e2 	mov	x2, x0
    b94c:	9113e3e1 	add	x1, sp, #0x4f8
    b950:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b954:	52800020 	mov	w0, #0x1                   	// #1
    b958:	f9027ff5 	str	x21, [sp, #1272]
    b95c:	f90283e2 	str	x2, [sp, #1280]
    b960:	97ffe799 	bl	57c4 <fwp_data.part.0.constprop.0>
    b964:	97ffe807 	bl	5980 <fwp_rc_fresh>
    b968:	aa0003e2 	mov	x2, x0
    b96c:	911423e1 	add	x1, sp, #0x508
    b970:	52800020 	mov	w0, #0x1                   	// #1
    b974:	f90287f7 	str	x23, [sp, #1288]
    b978:	f9028be2 	str	x2, [sp, #1296]
    b97c:	97ffe792 	bl	57c4 <fwp_data.part.0.constprop.0>
    b980:	97ffe800 	bl	5980 <fwp_rc_fresh>
    b984:	aa0003e2 	mov	x2, x0
    b988:	911463e1 	add	x1, sp, #0x518
    b98c:	52800020 	mov	w0, #0x1                   	// #1
    b990:	f9028ff5 	str	x21, [sp, #1304]
    b994:	f90293e2 	str	x2, [sp, #1312]
    b998:	97ffe78b 	bl	57c4 <fwp_data.part.0.constprop.0>
    b99c:	97ffe7f9 	bl	5980 <fwp_rc_fresh>
    b9a0:	aa0003e2 	mov	x2, x0
    b9a4:	9114a3e1 	add	x1, sp, #0x528
    b9a8:	52800020 	mov	w0, #0x1                   	// #1
    b9ac:	f90297f7 	str	x23, [sp, #1320]
    b9b0:	f9029be2 	str	x2, [sp, #1328]
    b9b4:	97ffe784 	bl	57c4 <fwp_data.part.0.constprop.0>
    b9b8:	91174283 	add	x3, x20, #0x5d0
    b9bc:	aa0003f5 	mov	x21, x0
    b9c0:	f949d861 	ldr	x1, [x3, #5040]
    b9c4:	f949ec60 	ldr	x0, [x3, #5080]
    b9c8:	cb0102a1 	sub	x1, x21, x1
    b9cc:	eb00403f 	cmp	x1, x0, lsl #16
    b9d0:	54000322 	b.cs	ba34 <f0+0x17d4>  // b.hs, b.nlast
    b9d4:	d350fc22 	lsr	x2, x1, #16
    b9d8:	f949fc63 	ldr	x3, [x3, #5112]
    b9dc:	8b020842 	add	x2, x2, x2, lsl #2
    b9e0:	d37df042 	lsl	x2, x2, #3
    b9e4:	8b020060 	add	x0, x3, x2
    b9e8:	f9401017 	ldr	x23, [x0, #32]
    b9ec:	b4000257 	cbz	x23, ba34 <f0+0x17d4>
    b9f0:	38626862 	ldrb	w2, [x3, x2]
    b9f4:	7100085f 	cmp	w2, #0x2
    b9f8:	540065c0 	b.eq	c6b0 <f0+0x2450>  // b.none
    b9fc:	7100045f 	cmp	w2, #0x1
    ba00:	540001a1 	b.ne	ba34 <f0+0x17d4>  // b.any
    ba04:	29430002 	ldp	w2, w0, [x0, #24]
    ba08:	92403c21 	and	x1, x1, #0xffff
    ba0c:	9b027c21 	mul	x1, x1, x2
    ba10:	d360fc21 	lsr	x1, x1, #32
    ba14:	eb00003f 	cmp	x1, x0
    ba18:	540000e2 	b.cs	ba34 <f0+0x17d4>  // b.hs, b.nlast
    ba1c:	8b0102f7 	add	x23, x23, x1
    ba20:	394002e0 	ldrb	w0, [x23]
    ba24:	7103fc1f 	cmp	w0, #0xff
    ba28:	54007160 	b.eq	c854 <f0+0x25f4>  // b.none
    ba2c:	52800020 	mov	w0, #0x1                   	// #1
    ba30:	390002e0 	strb	w0, [x23]
    ba34:	9114e3e1 	add	x1, sp, #0x538
    ba38:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba3c:	52800020 	mov	w0, #0x1                   	// #1
    ba40:	f9029ff7 	str	x23, [sp, #1336]
    ba44:	f902a3f5 	str	x21, [sp, #1344]
    ba48:	97ffe75f 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba4c:	97ffe7cd 	bl	5980 <fwp_rc_fresh>
    ba50:	aa0003e2 	mov	x2, x0
    ba54:	911523e1 	add	x1, sp, #0x548
    ba58:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ba5c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ba60:	52800020 	mov	w0, #0x1                   	// #1
    ba64:	f902a7f5 	str	x21, [sp, #1352]
    ba68:	f902abe2 	str	x2, [sp, #1360]
    ba6c:	97ffe756 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba70:	97ffe7c4 	bl	5980 <fwp_rc_fresh>
    ba74:	aa0003e2 	mov	x2, x0
    ba78:	911563e1 	add	x1, sp, #0x558
    ba7c:	52800020 	mov	w0, #0x1                   	// #1
    ba80:	f902aff7 	str	x23, [sp, #1368]
    ba84:	f902b3e2 	str	x2, [sp, #1376]
    ba88:	97ffe74f 	bl	57c4 <fwp_data.part.0.constprop.0>
    ba8c:	97ffe7bd 	bl	5980 <fwp_rc_fresh>
    ba90:	aa0003e2 	mov	x2, x0
    ba94:	9115a3e1 	add	x1, sp, #0x568
    ba98:	52800020 	mov	w0, #0x1                   	// #1
    ba9c:	f902b7f5 	str	x21, [sp, #1384]
    baa0:	f902bbe2 	str	x2, [sp, #1392]
    baa4:	97ffe748 	bl	57c4 <fwp_data.part.0.constprop.0>
    baa8:	97ffe7b6 	bl	5980 <fwp_rc_fresh>
    baac:	aa0003e2 	mov	x2, x0
    bab0:	9115e3e1 	add	x1, sp, #0x578
    bab4:	52800020 	mov	w0, #0x1                   	// #1
    bab8:	f902bff7 	str	x23, [sp, #1400]
    babc:	f902c3e2 	str	x2, [sp, #1408]
    bac0:	97ffe741 	bl	57c4 <fwp_data.part.0.constprop.0>
    bac4:	97ffe7af 	bl	5980 <fwp_rc_fresh>
    bac8:	aa0003e2 	mov	x2, x0
    bacc:	911623e1 	add	x1, sp, #0x588
    bad0:	52800020 	mov	w0, #0x1                   	// #1
    bad4:	f902c7f5 	str	x21, [sp, #1416]
    bad8:	f902cbe2 	str	x2, [sp, #1424]
    badc:	97ffe73a 	bl	57c4 <fwp_data.part.0.constprop.0>
    bae0:	97ffe7a8 	bl	5980 <fwp_rc_fresh>
    bae4:	aa0003e2 	mov	x2, x0
    bae8:	911663e1 	add	x1, sp, #0x598
    baec:	52800020 	mov	w0, #0x1                   	// #1
    baf0:	f902cff7 	str	x23, [sp, #1432]
    baf4:	f902d3e2 	str	x2, [sp, #1440]
    baf8:	97ffe733 	bl	57c4 <fwp_data.part.0.constprop.0>
    bafc:	97ffe7a1 	bl	5980 <fwp_rc_fresh>
    bb00:	aa0003e2 	mov	x2, x0
    bb04:	9116a3e1 	add	x1, sp, #0x5a8
    bb08:	52800020 	mov	w0, #0x1                   	// #1
    bb0c:	f902d7f5 	str	x21, [sp, #1448]
    bb10:	f902dbe2 	str	x2, [sp, #1456]
    bb14:	97ffe72c 	bl	57c4 <fwp_data.part.0.constprop.0>
    bb18:	91174283 	add	x3, x20, #0x5d0
    bb1c:	aa0003f5 	mov	x21, x0
    bb20:	f949d861 	ldr	x1, [x3, #5040]
    bb24:	f949ec60 	ldr	x0, [x3, #5080]
    bb28:	cb0102a1 	sub	x1, x21, x1
    bb2c:	eb00403f 	cmp	x1, x0, lsl #16
    bb30:	54000322 	b.cs	bb94 <f0+0x1934>  // b.hs, b.nlast
    bb34:	d350fc22 	lsr	x2, x1, #16
    bb38:	f949fc63 	ldr	x3, [x3, #5112]
    bb3c:	8b020842 	add	x2, x2, x2, lsl #2
    bb40:	d37df042 	lsl	x2, x2, #3
    bb44:	8b020060 	add	x0, x3, x2
    bb48:	f9401017 	ldr	x23, [x0, #32]
    bb4c:	b4000257 	cbz	x23, bb94 <f0+0x1934>
    bb50:	38626862 	ldrb	w2, [x3, x2]
    bb54:	7100085f 	cmp	w2, #0x2
    bb58:	54005a60 	b.eq	c6a4 <f0+0x2444>  // b.none
    bb5c:	7100045f 	cmp	w2, #0x1
    bb60:	540001a1 	b.ne	bb94 <f0+0x1934>  // b.any
    bb64:	29430002 	ldp	w2, w0, [x0, #24]
    bb68:	92403c21 	and	x1, x1, #0xffff
    bb6c:	9b027c21 	mul	x1, x1, x2
    bb70:	d360fc21 	lsr	x1, x1, #32
    bb74:	eb00003f 	cmp	x1, x0
    bb78:	540000e2 	b.cs	bb94 <f0+0x1934>  // b.hs, b.nlast
    bb7c:	8b0102f7 	add	x23, x23, x1
    bb80:	394002e0 	ldrb	w0, [x23]
    bb84:	7103fc1f 	cmp	w0, #0xff
    bb88:	540066c0 	b.eq	c860 <f0+0x2600>  // b.none
    bb8c:	52800020 	mov	w0, #0x1                   	// #1
    bb90:	390002e0 	strb	w0, [x23]
    bb94:	9116e3e1 	add	x1, sp, #0x5b8
    bb98:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	f902dff7 	str	x23, [sp, #1464]
    bba4:	f902e3f5 	str	x21, [sp, #1472]
    bba8:	97ffe707 	bl	57c4 <fwp_data.part.0.constprop.0>
    bbac:	97ffe775 	bl	5980 <fwp_rc_fresh>
    bbb0:	aa0003e2 	mov	x2, x0
    bbb4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bbb8:	911723e1 	add	x1, sp, #0x5c8
    bbbc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bbc0:	52800020 	mov	w0, #0x1                   	// #1
    bbc4:	f902e7e3 	str	x3, [sp, #1480]
    bbc8:	f902ebe2 	str	x2, [sp, #1488]
    bbcc:	97ffe6fe 	bl	57c4 <fwp_data.part.0.constprop.0>
    bbd0:	97ffe76c 	bl	5980 <fwp_rc_fresh>
    bbd4:	aa0003e2 	mov	x2, x0
    bbd8:	911763e1 	add	x1, sp, #0x5d8
    bbdc:	52800020 	mov	w0, #0x1                   	// #1
    bbe0:	f902eff7 	str	x23, [sp, #1496]
    bbe4:	f902f3e2 	str	x2, [sp, #1504]
    bbe8:	97ffe6f7 	bl	57c4 <fwp_data.part.0.constprop.0>
    bbec:	91174283 	add	x3, x20, #0x5d0
    bbf0:	aa0003f5 	mov	x21, x0
    bbf4:	f949d861 	ldr	x1, [x3, #5040]
    bbf8:	f949ec60 	ldr	x0, [x3, #5080]
    bbfc:	cb0102a1 	sub	x1, x21, x1
    bc00:	eb00403f 	cmp	x1, x0, lsl #16
    bc04:	54000322 	b.cs	bc68 <f0+0x1a08>  // b.hs, b.nlast
    bc08:	d350fc22 	lsr	x2, x1, #16
    bc0c:	f949fc63 	ldr	x3, [x3, #5112]
    bc10:	8b020842 	add	x2, x2, x2, lsl #2
    bc14:	d37df042 	lsl	x2, x2, #3
    bc18:	8b020060 	add	x0, x3, x2
    bc1c:	f9401017 	ldr	x23, [x0, #32]
    bc20:	b4000257 	cbz	x23, bc68 <f0+0x1a08>
    bc24:	38626862 	ldrb	w2, [x3, x2]
    bc28:	7100085f 	cmp	w2, #0x2
    bc2c:	54005360 	b.eq	c698 <f0+0x2438>  // b.none
    bc30:	7100045f 	cmp	w2, #0x1
    bc34:	540001a1 	b.ne	bc68 <f0+0x1a08>  // b.any
    bc38:	29430002 	ldp	w2, w0, [x0, #24]
    bc3c:	92403c21 	and	x1, x1, #0xffff
    bc40:	9b027c21 	mul	x1, x1, x2
    bc44:	d360fc21 	lsr	x1, x1, #32
    bc48:	eb00003f 	cmp	x1, x0
    bc4c:	540000e2 	b.cs	bc68 <f0+0x1a08>  // b.hs, b.nlast
    bc50:	8b0102f7 	add	x23, x23, x1
    bc54:	394002e0 	ldrb	w0, [x23]
    bc58:	7103fc1f 	cmp	w0, #0xff
    bc5c:	54006080 	b.eq	c86c <f0+0x260c>  // b.none
    bc60:	52800020 	mov	w0, #0x1                   	// #1
    bc64:	390002e0 	strb	w0, [x23]
    bc68:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc6c:	9117a3e1 	add	x1, sp, #0x5e8
    bc70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc74:	52800020 	mov	w0, #0x1                   	// #1
    bc78:	f902f7e2 	str	x2, [sp, #1512]
    bc7c:	f902fbf5 	str	x21, [sp, #1520]
    bc80:	97ffe6d1 	bl	57c4 <fwp_data.part.0.constprop.0>
    bc84:	91174283 	add	x3, x20, #0x5d0
    bc88:	aa0003f7 	mov	x23, x0
    bc8c:	f949d861 	ldr	x1, [x3, #5040]
    bc90:	f949ec60 	ldr	x0, [x3, #5080]
    bc94:	cb0102e1 	sub	x1, x23, x1
    bc98:	eb00403f 	cmp	x1, x0, lsl #16
    bc9c:	54000322 	b.cs	bd00 <f0+0x1aa0>  // b.hs, b.nlast
    bca0:	d350fc22 	lsr	x2, x1, #16
    bca4:	f949fc63 	ldr	x3, [x3, #5112]
    bca8:	8b020842 	add	x2, x2, x2, lsl #2
    bcac:	d37df042 	lsl	x2, x2, #3
    bcb0:	8b020060 	add	x0, x3, x2
    bcb4:	f9401015 	ldr	x21, [x0, #32]
    bcb8:	b4000255 	cbz	x21, bd00 <f0+0x1aa0>
    bcbc:	38626862 	ldrb	w2, [x3, x2]
    bcc0:	7100085f 	cmp	w2, #0x2
    bcc4:	54004e40 	b.eq	c68c <f0+0x242c>  // b.none
    bcc8:	7100045f 	cmp	w2, #0x1
    bccc:	540001a1 	b.ne	bd00 <f0+0x1aa0>  // b.any
    bcd0:	29430002 	ldp	w2, w0, [x0, #24]
    bcd4:	92403c21 	and	x1, x1, #0xffff
    bcd8:	9b027c21 	mul	x1, x1, x2
    bcdc:	d360fc21 	lsr	x1, x1, #32
    bce0:	eb00003f 	cmp	x1, x0
    bce4:	540000e2 	b.cs	bd00 <f0+0x1aa0>  // b.hs, b.nlast
    bce8:	8b0102b5 	add	x21, x21, x1
    bcec:	394002a0 	ldrb	w0, [x21]
    bcf0:	7103fc1f 	cmp	w0, #0xff
    bcf4:	54005c20 	b.eq	c878 <f0+0x2618>  // b.none
    bcf8:	52800020 	mov	w0, #0x1                   	// #1
    bcfc:	390002a0 	strb	w0, [x21]
    bd00:	9117e3e1 	add	x1, sp, #0x5f8
    bd04:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bd08:	52800020 	mov	w0, #0x1                   	// #1
    bd0c:	f902fff5 	str	x21, [sp, #1528]
    bd10:	f90303f7 	str	x23, [sp, #1536]
    bd14:	97ffe6ac 	bl	57c4 <fwp_data.part.0.constprop.0>
    bd18:	97ffe71a 	bl	5980 <fwp_rc_fresh>
    bd1c:	aa0003e2 	mov	x2, x0
    bd20:	911823e1 	add	x1, sp, #0x608
    bd24:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd28:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd2c:	52800020 	mov	w0, #0x1                   	// #1
    bd30:	f90307f7 	str	x23, [sp, #1544]
    bd34:	f9030be2 	str	x2, [sp, #1552]
    bd38:	97ffe6a3 	bl	57c4 <fwp_data.part.0.constprop.0>
    bd3c:	97ffe711 	bl	5980 <fwp_rc_fresh>
    bd40:	aa0003e2 	mov	x2, x0
    bd44:	911863e1 	add	x1, sp, #0x618
    bd48:	52800020 	mov	w0, #0x1                   	// #1
    bd4c:	f9030ff5 	str	x21, [sp, #1560]
    bd50:	f90313e2 	str	x2, [sp, #1568]
    bd54:	97ffe69c 	bl	57c4 <fwp_data.part.0.constprop.0>
    bd58:	97ffe70a 	bl	5980 <fwp_rc_fresh>
    bd5c:	aa0003e2 	mov	x2, x0
    bd60:	9118a3e1 	add	x1, sp, #0x628
    bd64:	52800020 	mov	w0, #0x1                   	// #1
    bd68:	f90317f7 	str	x23, [sp, #1576]
    bd6c:	f9031be2 	str	x2, [sp, #1584]
    bd70:	97ffe695 	bl	57c4 <fwp_data.part.0.constprop.0>
    bd74:	97ffe703 	bl	5980 <fwp_rc_fresh>
    bd78:	aa0003e2 	mov	x2, x0
    bd7c:	9118e3e1 	add	x1, sp, #0x638
    bd80:	52800020 	mov	w0, #0x1                   	// #1
    bd84:	f9031ff5 	str	x21, [sp, #1592]
    bd88:	f90323e2 	str	x2, [sp, #1600]
    bd8c:	97ffe68e 	bl	57c4 <fwp_data.part.0.constprop.0>
    bd90:	97ffe6fc 	bl	5980 <fwp_rc_fresh>
    bd94:	aa0003e2 	mov	x2, x0
    bd98:	911923e1 	add	x1, sp, #0x648
    bd9c:	52800020 	mov	w0, #0x1                   	// #1
    bda0:	f90327f7 	str	x23, [sp, #1608]
    bda4:	f9032be2 	str	x2, [sp, #1616]
    bda8:	97ffe687 	bl	57c4 <fwp_data.part.0.constprop.0>
    bdac:	97ffe6f5 	bl	5980 <fwp_rc_fresh>
    bdb0:	aa0003e2 	mov	x2, x0
    bdb4:	911963e1 	add	x1, sp, #0x658
    bdb8:	52800020 	mov	w0, #0x1                   	// #1
    bdbc:	f9032ff5 	str	x21, [sp, #1624]
    bdc0:	f90333e2 	str	x2, [sp, #1632]
    bdc4:	97ffe680 	bl	57c4 <fwp_data.part.0.constprop.0>
    bdc8:	91174283 	add	x3, x20, #0x5d0
    bdcc:	aa0003f5 	mov	x21, x0
    bdd0:	f949d861 	ldr	x1, [x3, #5040]
    bdd4:	f949ec60 	ldr	x0, [x3, #5080]
    bdd8:	cb0102a1 	sub	x1, x21, x1
    bddc:	eb00403f 	cmp	x1, x0, lsl #16
    bde0:	54000322 	b.cs	be44 <f0+0x1be4>  // b.hs, b.nlast
    bde4:	d350fc22 	lsr	x2, x1, #16
    bde8:	f949fc63 	ldr	x3, [x3, #5112]
    bdec:	8b020842 	add	x2, x2, x2, lsl #2
    bdf0:	d37df042 	lsl	x2, x2, #3
    bdf4:	8b020060 	add	x0, x3, x2
    bdf8:	f9401017 	ldr	x23, [x0, #32]
    bdfc:	b4000257 	cbz	x23, be44 <f0+0x1be4>
    be00:	38626862 	ldrb	w2, [x3, x2]
    be04:	7100085f 	cmp	w2, #0x2
    be08:	540043c0 	b.eq	c680 <f0+0x2420>  // b.none
    be0c:	7100045f 	cmp	w2, #0x1
    be10:	540001a1 	b.ne	be44 <f0+0x1be4>  // b.any
    be14:	29430002 	ldp	w2, w0, [x0, #24]
    be18:	92403c21 	and	x1, x1, #0xffff
    be1c:	9b027c21 	mul	x1, x1, x2
    be20:	d360fc21 	lsr	x1, x1, #32
    be24:	eb00003f 	cmp	x1, x0
    be28:	540000e2 	b.cs	be44 <f0+0x1be4>  // b.hs, b.nlast
    be2c:	8b0102f7 	add	x23, x23, x1
    be30:	394002e0 	ldrb	w0, [x23]
    be34:	7103fc1f 	cmp	w0, #0xff
    be38:	54005260 	b.eq	c884 <f0+0x2624>  // b.none
    be3c:	52800020 	mov	w0, #0x1                   	// #1
    be40:	390002e0 	strb	w0, [x23]
    be44:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be48:	9119a3e1 	add	x1, sp, #0x668
    be4c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be50:	52800020 	mov	w0, #0x1                   	// #1
    be54:	f90337e2 	str	x2, [sp, #1640]
    be58:	f9033bf5 	str	x21, [sp, #1648]
    be5c:	97ffe65a 	bl	57c4 <fwp_data.part.0.constprop.0>
    be60:	91174283 	add	x3, x20, #0x5d0
    be64:	aa0003f5 	mov	x21, x0
    be68:	f949d861 	ldr	x1, [x3, #5040]
    be6c:	f949ec60 	ldr	x0, [x3, #5080]
    be70:	cb0102a1 	sub	x1, x21, x1
    be74:	eb00403f 	cmp	x1, x0, lsl #16
    be78:	54000322 	b.cs	bedc <f0+0x1c7c>  // b.hs, b.nlast
    be7c:	d350fc22 	lsr	x2, x1, #16
    be80:	f949fc63 	ldr	x3, [x3, #5112]
    be84:	8b020842 	add	x2, x2, x2, lsl #2
    be88:	d37df042 	lsl	x2, x2, #3
    be8c:	8b020060 	add	x0, x3, x2
    be90:	f9401017 	ldr	x23, [x0, #32]
    be94:	b4000257 	cbz	x23, bedc <f0+0x1c7c>
    be98:	38626862 	ldrb	w2, [x3, x2]
    be9c:	7100085f 	cmp	w2, #0x2
    bea0:	54003ea0 	b.eq	c674 <f0+0x2414>  // b.none
    bea4:	7100045f 	cmp	w2, #0x1
    bea8:	540001a1 	b.ne	bedc <f0+0x1c7c>  // b.any
    beac:	29430002 	ldp	w2, w0, [x0, #24]
    beb0:	92403c21 	and	x1, x1, #0xffff
    beb4:	9b027c21 	mul	x1, x1, x2
    beb8:	d360fc21 	lsr	x1, x1, #32
    bebc:	eb00003f 	cmp	x1, x0
    bec0:	540000e2 	b.cs	bedc <f0+0x1c7c>  // b.hs, b.nlast
    bec4:	8b0102f7 	add	x23, x23, x1
    bec8:	394002e0 	ldrb	w0, [x23]
    becc:	7103fc1f 	cmp	w0, #0xff
    bed0:	54004e00 	b.eq	c890 <f0+0x2630>  // b.none
    bed4:	52800020 	mov	w0, #0x1                   	// #1
    bed8:	390002e0 	strb	w0, [x23]
    bedc:	9119e3e1 	add	x1, sp, #0x678
    bee0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bee4:	52800020 	mov	w0, #0x1                   	// #1
    bee8:	f9033ff7 	str	x23, [sp, #1656]
    beec:	f90343f5 	str	x21, [sp, #1664]
    bef0:	97ffe635 	bl	57c4 <fwp_data.part.0.constprop.0>
    bef4:	97ffe6a3 	bl	5980 <fwp_rc_fresh>
    bef8:	aa0003e2 	mov	x2, x0
    befc:	911a23e1 	add	x1, sp, #0x688
    bf00:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bf04:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bf08:	52800020 	mov	w0, #0x1                   	// #1
    bf0c:	f90347f5 	str	x21, [sp, #1672]
    bf10:	f9034be2 	str	x2, [sp, #1680]
    bf14:	97ffe62c 	bl	57c4 <fwp_data.part.0.constprop.0>
    bf18:	97ffe69a 	bl	5980 <fwp_rc_fresh>
    bf1c:	aa0003e2 	mov	x2, x0
    bf20:	911a63e1 	add	x1, sp, #0x698
    bf24:	52800020 	mov	w0, #0x1                   	// #1
    bf28:	f9034ff7 	str	x23, [sp, #1688]
    bf2c:	f90353e2 	str	x2, [sp, #1696]
    bf30:	97ffe625 	bl	57c4 <fwp_data.part.0.constprop.0>
    bf34:	97ffe693 	bl	5980 <fwp_rc_fresh>
    bf38:	aa0003e2 	mov	x2, x0
    bf3c:	911aa3e1 	add	x1, sp, #0x6a8
    bf40:	52800020 	mov	w0, #0x1                   	// #1
    bf44:	f90357f5 	str	x21, [sp, #1704]
    bf48:	f9035be2 	str	x2, [sp, #1712]
    bf4c:	97ffe61e 	bl	57c4 <fwp_data.part.0.constprop.0>
    bf50:	91174283 	add	x3, x20, #0x5d0
    bf54:	aa0003f5 	mov	x21, x0
    bf58:	f949d861 	ldr	x1, [x3, #5040]
    bf5c:	f949ec60 	ldr	x0, [x3, #5080]
    bf60:	cb0102a1 	sub	x1, x21, x1
    bf64:	eb00403f 	cmp	x1, x0, lsl #16
    bf68:	54000322 	b.cs	bfcc <f0+0x1d6c>  // b.hs, b.nlast
    bf6c:	d350fc22 	lsr	x2, x1, #16
    bf70:	f949fc63 	ldr	x3, [x3, #5112]
    bf74:	8b020842 	add	x2, x2, x2, lsl #2
    bf78:	d37df042 	lsl	x2, x2, #3
    bf7c:	8b020060 	add	x0, x3, x2
    bf80:	f9401017 	ldr	x23, [x0, #32]
    bf84:	b4000257 	cbz	x23, bfcc <f0+0x1d6c>
    bf88:	38626862 	ldrb	w2, [x3, x2]
    bf8c:	7100085f 	cmp	w2, #0x2
    bf90:	540036c0 	b.eq	c668 <f0+0x2408>  // b.none
    bf94:	7100045f 	cmp	w2, #0x1
    bf98:	540001a1 	b.ne	bfcc <f0+0x1d6c>  // b.any
    bf9c:	29430002 	ldp	w2, w0, [x0, #24]
    bfa0:	92403c21 	and	x1, x1, #0xffff
    bfa4:	9b027c21 	mul	x1, x1, x2
    bfa8:	d360fc21 	lsr	x1, x1, #32
    bfac:	eb00003f 	cmp	x1, x0
    bfb0:	540000e2 	b.cs	bfcc <f0+0x1d6c>  // b.hs, b.nlast
    bfb4:	8b0102f7 	add	x23, x23, x1
    bfb8:	394002e0 	ldrb	w0, [x23]
    bfbc:	7103fc1f 	cmp	w0, #0xff
    bfc0:	540046e0 	b.eq	c89c <f0+0x263c>  // b.none
    bfc4:	52800020 	mov	w0, #0x1                   	// #1
    bfc8:	390002e0 	strb	w0, [x23]
    bfcc:	911ae3e1 	add	x1, sp, #0x6b8
    bfd0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bfd4:	52800020 	mov	w0, #0x1                   	// #1
    bfd8:	f9035ff7 	str	x23, [sp, #1720]
    bfdc:	f90363f5 	str	x21, [sp, #1728]
    bfe0:	97ffe5f9 	bl	57c4 <fwp_data.part.0.constprop.0>
    bfe4:	97ffe667 	bl	5980 <fwp_rc_fresh>
    bfe8:	aa0003e2 	mov	x2, x0
    bfec:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bff0:	911b23e1 	add	x1, sp, #0x6c8
    bff4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bff8:	52800020 	mov	w0, #0x1                   	// #1
    bffc:	f90367e3 	str	x3, [sp, #1736]
    c000:	f9036be2 	str	x2, [sp, #1744]
    c004:	97ffe5f0 	bl	57c4 <fwp_data.part.0.constprop.0>
    c008:	97ffe65e 	bl	5980 <fwp_rc_fresh>
    c00c:	aa0003e2 	mov	x2, x0
    c010:	911b63e1 	add	x1, sp, #0x6d8
    c014:	52800020 	mov	w0, #0x1                   	// #1
    c018:	f9036ff7 	str	x23, [sp, #1752]
    c01c:	f90373e2 	str	x2, [sp, #1760]
    c020:	97ffe5e9 	bl	57c4 <fwp_data.part.0.constprop.0>
    c024:	91174283 	add	x3, x20, #0x5d0
    c028:	aa0003f5 	mov	x21, x0
    c02c:	f949d861 	ldr	x1, [x3, #5040]
    c030:	f949ec60 	ldr	x0, [x3, #5080]
    c034:	cb0102a1 	sub	x1, x21, x1
    c038:	eb00403f 	cmp	x1, x0, lsl #16
    c03c:	54000322 	b.cs	c0a0 <f0+0x1e40>  // b.hs, b.nlast
    c040:	d350fc22 	lsr	x2, x1, #16
    c044:	f949fc63 	ldr	x3, [x3, #5112]
    c048:	8b020842 	add	x2, x2, x2, lsl #2
    c04c:	d37df042 	lsl	x2, x2, #3
    c050:	8b020060 	add	x0, x3, x2
    c054:	f9401017 	ldr	x23, [x0, #32]
    c058:	b4000257 	cbz	x23, c0a0 <f0+0x1e40>
    c05c:	38626862 	ldrb	w2, [x3, x2]
    c060:	7100085f 	cmp	w2, #0x2
    c064:	54002fc0 	b.eq	c65c <f0+0x23fc>  // b.none
    c068:	7100045f 	cmp	w2, #0x1
    c06c:	540001a1 	b.ne	c0a0 <f0+0x1e40>  // b.any
    c070:	29430002 	ldp	w2, w0, [x0, #24]
    c074:	92403c21 	and	x1, x1, #0xffff
    c078:	9b027c21 	mul	x1, x1, x2
    c07c:	d360fc21 	lsr	x1, x1, #32
    c080:	eb00003f 	cmp	x1, x0
    c084:	540000e2 	b.cs	c0a0 <f0+0x1e40>  // b.hs, b.nlast
    c088:	8b0102f7 	add	x23, x23, x1
    c08c:	394002e0 	ldrb	w0, [x23]
    c090:	7103fc1f 	cmp	w0, #0xff
    c094:	540040a0 	b.eq	c8a8 <f0+0x2648>  // b.none
    c098:	52800020 	mov	w0, #0x1                   	// #1
    c09c:	390002e0 	strb	w0, [x23]
    c0a0:	911ba3e1 	add	x1, sp, #0x6e8
    c0a4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c0a8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c0ac:	52800020 	mov	w0, #0x1                   	// #1
    c0b0:	f90377f7 	str	x23, [sp, #1768]
    c0b4:	f9037bf5 	str	x21, [sp, #1776]
    c0b8:	97ffe5c3 	bl	57c4 <fwp_data.part.0.constprop.0>
    c0bc:	97ffe631 	bl	5980 <fwp_rc_fresh>
    c0c0:	aa0003e2 	mov	x2, x0
    c0c4:	911be3e1 	add	x1, sp, #0x6f8
    c0c8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c0cc:	52800020 	mov	w0, #0x1                   	// #1
    c0d0:	f9037ff5 	str	x21, [sp, #1784]
    c0d4:	f90383e2 	str	x2, [sp, #1792]
    c0d8:	97ffe5bb 	bl	57c4 <fwp_data.part.0.constprop.0>
    c0dc:	97ffe629 	bl	5980 <fwp_rc_fresh>
    c0e0:	aa0003e2 	mov	x2, x0
    c0e4:	911c23e1 	add	x1, sp, #0x708
    c0e8:	52800020 	mov	w0, #0x1                   	// #1
    c0ec:	f90387f7 	str	x23, [sp, #1800]
    c0f0:	f9038be2 	str	x2, [sp, #1808]
    c0f4:	97ffe5b4 	bl	57c4 <fwp_data.part.0.constprop.0>
    c0f8:	97ffe622 	bl	5980 <fwp_rc_fresh>
    c0fc:	aa0003e2 	mov	x2, x0
    c100:	911c63e1 	add	x1, sp, #0x718
    c104:	52800020 	mov	w0, #0x1                   	// #1
    c108:	f9038ff5 	str	x21, [sp, #1816]
    c10c:	f90393e2 	str	x2, [sp, #1824]
    c110:	97ffe5ad 	bl	57c4 <fwp_data.part.0.constprop.0>
    c114:	97ffe61b 	bl	5980 <fwp_rc_fresh>
    c118:	aa0003e2 	mov	x2, x0
    c11c:	911ca3e1 	add	x1, sp, #0x728
    c120:	52800020 	mov	w0, #0x1                   	// #1
    c124:	f90397f7 	str	x23, [sp, #1832]
    c128:	f9039be2 	str	x2, [sp, #1840]
    c12c:	97ffe5a6 	bl	57c4 <fwp_data.part.0.constprop.0>
    c130:	91174283 	add	x3, x20, #0x5d0
    c134:	aa0003f5 	mov	x21, x0
    c138:	f949d861 	ldr	x1, [x3, #5040]
    c13c:	f949ec60 	ldr	x0, [x3, #5080]
    c140:	cb0102a1 	sub	x1, x21, x1
    c144:	eb00403f 	cmp	x1, x0, lsl #16
    c148:	54000322 	b.cs	c1ac <f0+0x1f4c>  // b.hs, b.nlast
    c14c:	d350fc22 	lsr	x2, x1, #16
    c150:	f949fc63 	ldr	x3, [x3, #5112]
    c154:	8b020842 	add	x2, x2, x2, lsl #2
    c158:	d37df042 	lsl	x2, x2, #3
    c15c:	8b020060 	add	x0, x3, x2
    c160:	f9401017 	ldr	x23, [x0, #32]
    c164:	b4000257 	cbz	x23, c1ac <f0+0x1f4c>
    c168:	38626862 	ldrb	w2, [x3, x2]
    c16c:	7100085f 	cmp	w2, #0x2
    c170:	54002700 	b.eq	c650 <f0+0x23f0>  // b.none
    c174:	7100045f 	cmp	w2, #0x1
    c178:	540001a1 	b.ne	c1ac <f0+0x1f4c>  // b.any
    c17c:	29430002 	ldp	w2, w0, [x0, #24]
    c180:	92403c21 	and	x1, x1, #0xffff
    c184:	9b027c21 	mul	x1, x1, x2
    c188:	d360fc21 	lsr	x1, x1, #32
    c18c:	eb00003f 	cmp	x1, x0
    c190:	540000e2 	b.cs	c1ac <f0+0x1f4c>  // b.hs, b.nlast
    c194:	8b0102f7 	add	x23, x23, x1
    c198:	394002e0 	ldrb	w0, [x23]
    c19c:	7103fc1f 	cmp	w0, #0xff
    c1a0:	540038a0 	b.eq	c8b4 <f0+0x2654>  // b.none
    c1a4:	52800020 	mov	w0, #0x1                   	// #1
    c1a8:	390002e0 	strb	w0, [x23]
    c1ac:	911ce3e1 	add	x1, sp, #0x738
    c1b0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c1b4:	52800020 	mov	w0, #0x1                   	// #1
    c1b8:	f9039ff7 	str	x23, [sp, #1848]
    c1bc:	f903a3f5 	str	x21, [sp, #1856]
    c1c0:	97ffe581 	bl	57c4 <fwp_data.part.0.constprop.0>
    c1c4:	97ffe5ef 	bl	5980 <fwp_rc_fresh>
    c1c8:	aa0003e2 	mov	x2, x0
    c1cc:	911d23e1 	add	x1, sp, #0x748
    c1d0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c1d4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c1d8:	52800020 	mov	w0, #0x1                   	// #1
    c1dc:	f903a7f5 	str	x21, [sp, #1864]
    c1e0:	f903abe2 	str	x2, [sp, #1872]
    c1e4:	97ffe578 	bl	57c4 <fwp_data.part.0.constprop.0>
    c1e8:	97ffe5e6 	bl	5980 <fwp_rc_fresh>
    c1ec:	aa0003e2 	mov	x2, x0
    c1f0:	911d63e1 	add	x1, sp, #0x758
    c1f4:	52800020 	mov	w0, #0x1                   	// #1
    c1f8:	f903aff7 	str	x23, [sp, #1880]
    c1fc:	f903b3e2 	str	x2, [sp, #1888]
    c200:	97ffe571 	bl	57c4 <fwp_data.part.0.constprop.0>
    c204:	97ffe5df 	bl	5980 <fwp_rc_fresh>
    c208:	aa0003e2 	mov	x2, x0
    c20c:	911da3e1 	add	x1, sp, #0x768
    c210:	52800020 	mov	w0, #0x1                   	// #1
    c214:	f903b7f5 	str	x21, [sp, #1896]
    c218:	f903bbe2 	str	x2, [sp, #1904]
    c21c:	97ffe56a 	bl	57c4 <fwp_data.part.0.constprop.0>
    c220:	91174283 	add	x3, x20, #0x5d0
    c224:	aa0003f5 	mov	x21, x0
    c228:	f949d861 	ldr	x1, [x3, #5040]
    c22c:	f949ec60 	ldr	x0, [x3, #5080]
    c230:	cb0102a1 	sub	x1, x21, x1
    c234:	eb00403f 	cmp	x1, x0, lsl #16
    c238:	54000322 	b.cs	c29c <f0+0x203c>  // b.hs, b.nlast
    c23c:	d350fc22 	lsr	x2, x1, #16
    c240:	f949fc63 	ldr	x3, [x3, #5112]
    c244:	8b020842 	add	x2, x2, x2, lsl #2
    c248:	d37df042 	lsl	x2, x2, #3
    c24c:	8b020060 	add	x0, x3, x2
    c250:	f9401017 	ldr	x23, [x0, #32]
    c254:	b4000257 	cbz	x23, c29c <f0+0x203c>
    c258:	38626862 	ldrb	w2, [x3, x2]
    c25c:	7100085f 	cmp	w2, #0x2
    c260:	54001f20 	b.eq	c644 <f0+0x23e4>  // b.none
    c264:	7100045f 	cmp	w2, #0x1
    c268:	540001a1 	b.ne	c29c <f0+0x203c>  // b.any
    c26c:	29430002 	ldp	w2, w0, [x0, #24]
    c270:	92403c21 	and	x1, x1, #0xffff
    c274:	9b027c21 	mul	x1, x1, x2
    c278:	d360fc21 	lsr	x1, x1, #32
    c27c:	eb00003f 	cmp	x1, x0
    c280:	540000e2 	b.cs	c29c <f0+0x203c>  // b.hs, b.nlast
    c284:	8b0102f7 	add	x23, x23, x1
    c288:	394002e0 	ldrb	w0, [x23]
    c28c:	7103fc1f 	cmp	w0, #0xff
    c290:	54003180 	b.eq	c8c0 <f0+0x2660>  // b.none
    c294:	52800020 	mov	w0, #0x1                   	// #1
    c298:	390002e0 	strb	w0, [x23]
    c29c:	911de3e1 	add	x1, sp, #0x778
    c2a0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c2a4:	52800020 	mov	w0, #0x1                   	// #1
    c2a8:	f903bff7 	str	x23, [sp, #1912]
    c2ac:	f903c3f5 	str	x21, [sp, #1920]
    c2b0:	97ffe545 	bl	57c4 <fwp_data.part.0.constprop.0>
    c2b4:	97ffe5b3 	bl	5980 <fwp_rc_fresh>
    c2b8:	aa0003e2 	mov	x2, x0
    c2bc:	911e23e1 	add	x1, sp, #0x788
    c2c0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c2c4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c2c8:	52800020 	mov	w0, #0x1                   	// #1
    c2cc:	f903c7f5 	str	x21, [sp, #1928]
    c2d0:	91174294 	add	x20, x20, #0x5d0
    c2d4:	f903cbe2 	str	x2, [sp, #1936]
    c2d8:	97ffe53b 	bl	57c4 <fwp_data.part.0.constprop.0>
    c2dc:	97ffe5a9 	bl	5980 <fwp_rc_fresh>
    c2e0:	aa0003e2 	mov	x2, x0
    c2e4:	911e63e1 	add	x1, sp, #0x798
    c2e8:	52800020 	mov	w0, #0x1                   	// #1
    c2ec:	f903cff7 	str	x23, [sp, #1944]
    c2f0:	f903d3e2 	str	x2, [sp, #1952]
    c2f4:	97ffe534 	bl	57c4 <fwp_data.part.0.constprop.0>
    c2f8:	97ffe5a2 	bl	5980 <fwp_rc_fresh>
    c2fc:	aa0003e2 	mov	x2, x0
    c300:	911ea3e1 	add	x1, sp, #0x7a8
    c304:	52800020 	mov	w0, #0x1                   	// #1
    c308:	f903d7f5 	str	x21, [sp, #1960]
    c30c:	f903dbe2 	str	x2, [sp, #1968]
    c310:	97ffe52d 	bl	57c4 <fwp_data.part.0.constprop.0>
    c314:	f949da81 	ldr	x1, [x20, #5040]
    c318:	aa0003f7 	mov	x23, x0
    c31c:	f949ee80 	ldr	x0, [x20, #5080]
    c320:	cb0102e1 	sub	x1, x23, x1
    c324:	eb00403f 	cmp	x1, x0, lsl #16
    c328:	54000322 	b.cs	c38c <f0+0x212c>  // b.hs, b.nlast
    c32c:	d350fc22 	lsr	x2, x1, #16
    c330:	f949fe83 	ldr	x3, [x20, #5112]
    c334:	8b020842 	add	x2, x2, x2, lsl #2
    c338:	d37df042 	lsl	x2, x2, #3
    c33c:	8b020060 	add	x0, x3, x2
    c340:	f9401014 	ldr	x20, [x0, #32]
    c344:	b4000254 	cbz	x20, c38c <f0+0x212c>
    c348:	38626862 	ldrb	w2, [x3, x2]
    c34c:	7100085f 	cmp	w2, #0x2
    c350:	54001740 	b.eq	c638 <f0+0x23d8>  // b.none
    c354:	7100045f 	cmp	w2, #0x1
    c358:	540001a1 	b.ne	c38c <f0+0x212c>  // b.any
    c35c:	29430002 	ldp	w2, w0, [x0, #24]
    c360:	92403c21 	and	x1, x1, #0xffff
    c364:	9b027c21 	mul	x1, x1, x2
    c368:	d360fc21 	lsr	x1, x1, #32
    c36c:	eb00003f 	cmp	x1, x0
    c370:	540000e2 	b.cs	c38c <f0+0x212c>  // b.hs, b.nlast
    c374:	8b010294 	add	x20, x20, x1
    c378:	39400280 	ldrb	w0, [x20]
    c37c:	7103fc1f 	cmp	w0, #0xff
    c380:	54001bc0 	b.eq	c6f8 <f0+0x2498>  // b.none
    c384:	52800020 	mov	w0, #0x1                   	// #1
    c388:	39000280 	strb	w0, [x20]
    c38c:	911ee3e1 	add	x1, sp, #0x7b8
    c390:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c394:	52800020 	mov	w0, #0x1                   	// #1
    c398:	f903dff5 	str	x21, [sp, #1976]
    c39c:	f903e3f7 	str	x23, [sp, #1984]
    c3a0:	97ffe509 	bl	57c4 <fwp_data.part.0.constprop.0>
    c3a4:	97ffe577 	bl	5980 <fwp_rc_fresh>
    c3a8:	aa0003e2 	mov	x2, x0
    c3ac:	911f23e1 	add	x1, sp, #0x7c8
    c3b0:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c3b4:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c3b8:	52800020 	mov	w0, #0x1                   	// #1
    c3bc:	f903e7f4 	str	x20, [sp, #1992]
    c3c0:	f903ebe2 	str	x2, [sp, #2000]
    c3c4:	97ffe500 	bl	57c4 <fwp_data.part.0.constprop.0>
    c3c8:	97ffe56e 	bl	5980 <fwp_rc_fresh>
    c3cc:	aa0003e2 	mov	x2, x0
    c3d0:	911f63e1 	add	x1, sp, #0x7d8
    c3d4:	52800020 	mov	w0, #0x1                   	// #1
    c3d8:	f903eff5 	str	x21, [sp, #2008]
    c3dc:	f903f3e2 	str	x2, [sp, #2016]
    c3e0:	97ffe4f9 	bl	57c4 <fwp_data.part.0.constprop.0>
    c3e4:	97ffe567 	bl	5980 <fwp_rc_fresh>
    c3e8:	aa0003e2 	mov	x2, x0
    c3ec:	911fa3e1 	add	x1, sp, #0x7e8
    c3f0:	52800020 	mov	w0, #0x1                   	// #1
    c3f4:	f903f7f4 	str	x20, [sp, #2024]
    c3f8:	f903fbe2 	str	x2, [sp, #2032]
    c3fc:	97ffe4f2 	bl	57c4 <fwp_data.part.0.constprop.0>
    c400:	97ffe560 	bl	5980 <fwp_rc_fresh>
    c404:	aa0003e2 	mov	x2, x0
    c408:	911fe3e1 	add	x1, sp, #0x7f8
    c40c:	52800020 	mov	w0, #0x1                   	// #1
    c410:	f903fff5 	str	x21, [sp, #2040]
    c414:	f90403e2 	str	x2, [sp, #2048]
    c418:	97ffe4eb 	bl	57c4 <fwp_data.part.0.constprop.0>
    c41c:	97ffe559 	bl	5980 <fwp_rc_fresh>
    c420:	aa0003e2 	mov	x2, x0
    c424:	912023e1 	add	x1, sp, #0x808
    c428:	52800020 	mov	w0, #0x1                   	// #1
    c42c:	f90407f4 	str	x20, [sp, #2056]
    c430:	f9040be2 	str	x2, [sp, #2064]
    c434:	97ffe4e4 	bl	57c4 <fwp_data.part.0.constprop.0>
    c438:	97ffe552 	bl	5980 <fwp_rc_fresh>
    c43c:	aa0003e2 	mov	x2, x0
    c440:	912063e1 	add	x1, sp, #0x818
    c444:	52800020 	mov	w0, #0x1                   	// #1
    c448:	f9040ff5 	str	x21, [sp, #2072]
    c44c:	f90413e2 	str	x2, [sp, #2080]
    c450:	97ffe4dd 	bl	57c4 <fwp_data.part.0.constprop.0>
    c454:	97ffe54b 	bl	5980 <fwp_rc_fresh>
    c458:	aa0003e2 	mov	x2, x0
    c45c:	9120a3e1 	add	x1, sp, #0x828
    c460:	52800020 	mov	w0, #0x1                   	// #1
    c464:	f90417f4 	str	x20, [sp, #2088]
    c468:	f9041be2 	str	x2, [sp, #2096]
    c46c:	97ffe4d6 	bl	57c4 <fwp_data.part.0.constprop.0>
    c470:	97ffe544 	bl	5980 <fwp_rc_fresh>
    c474:	aa0003e2 	mov	x2, x0
    c478:	9120e3e1 	add	x1, sp, #0x838
    c47c:	52800020 	mov	w0, #0x1                   	// #1
    c480:	f9041ff5 	str	x21, [sp, #2104]
    c484:	f90423e2 	str	x2, [sp, #2112]
    c488:	97ffe4cf 	bl	57c4 <fwp_data.part.0.constprop.0>
    c48c:	97ffe53d 	bl	5980 <fwp_rc_fresh>
    c490:	aa0003e2 	mov	x2, x0
    c494:	aa1603e1 	mov	x1, x22
    c498:	52800020 	mov	w0, #0x1                   	// #1
    c49c:	f90427f4 	str	x20, [sp, #2120]
    c4a0:	f9042be2 	str	x2, [sp, #2128]
    c4a4:	97ffe4c8 	bl	57c4 <fwp_data.part.0.constprop.0>
    c4a8:	97ffe536 	bl	5980 <fwp_rc_fresh>
    c4ac:	aa0003f5 	mov	x21, x0
    c4b0:	aa1303e1 	mov	x1, x19
    c4b4:	97fff477 	bl	9690 <fwp_hof0.constprop.0>
    c4b8:	aa0003f4 	mov	x20, x0
    c4bc:	aa1503e0 	mov	x0, x21
    c4c0:	97ffe688 	bl	5ee0 <fwp_drop0>
    c4c4:	aa1303e0 	mov	x0, x19
    c4c8:	97ffe686 	bl	5ee0 <fwp_drop0>
    c4cc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c4d0:	f947f400 	ldr	x0, [x0, #4072]
    c4d4:	f9442fe2 	ldr	x2, [sp, #2136]
    c4d8:	f9400001 	ldr	x1, [x0]
    c4dc:	eb010042 	subs	x2, x2, x1
    c4e0:	d2800001 	mov	x1, #0x0                   	// #0
    c4e4:	54001f41 	b.ne	c8cc <f0+0x266c>  // b.any
    c4e8:	912183ff 	add	sp, sp, #0x860
    c4ec:	aa1403e0 	mov	x0, x20
    c4f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    c4f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c4f8:	a94363f7 	ldp	x23, x24, [sp, #48]
    c4fc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c500:	a94573fb 	ldp	x27, x28, [sp, #80]
    c504:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c508:	d65f03c0 	ret
    c50c:	aa1b03e0 	mov	x0, x27
    c510:	97ffe0b8 	bl	47f0 <fwp_rc_forget_slot>
    c514:	17fff79b 	b	a380 <f0+0x120>
    c518:	72003c5f 	tst	w2, #0xffff
    c51c:	54fef341 	b.ne	a384 <f0+0x124>  // b.any
    c520:	17fff795 	b	a374 <f0+0x114>
    c524:	72003c3f 	tst	w1, #0xffff
    c528:	54ff7f01 	b.ne	b508 <f0+0x12a8>  // b.any
    c52c:	17fffbf2 	b	b4f4 <f0+0x1294>
    c530:	72003c3f 	tst	w1, #0xffff
    c534:	54ff7801 	b.ne	b434 <f0+0x11d4>  // b.any
    c538:	17fffbba 	b	b420 <f0+0x11c0>
    c53c:	72003c3f 	tst	w1, #0xffff
    c540:	54ff7301 	b.ne	b3a0 <f0+0x1140>  // b.any
    c544:	17fffb92 	b	b38c <f0+0x112c>
    c548:	72003c3f 	tst	w1, #0xffff
    c54c:	54ff6b21 	b.ne	b2b0 <f0+0x1050>  // b.any
    c550:	17fffb53 	b	b29c <f0+0x103c>
    c554:	72003c3f 	tst	w1, #0xffff
    c558:	54ff6341 	b.ne	b1c0 <f0+0xf60>  // b.any
    c55c:	17fffb14 	b	b1ac <f0+0xf4c>
    c560:	72003c3f 	tst	w1, #0xffff
    c564:	54ff5a81 	b.ne	b0b4 <f0+0xe54>  // b.any
    c568:	17ffface 	b	b0a0 <f0+0xe40>
    c56c:	72003c3f 	tst	w1, #0xffff
    c570:	54ff5461 	b.ne	affc <f0+0xd9c>  // b.any
    c574:	17fffa9d 	b	afe8 <f0+0xd88>
    c578:	72003c3f 	tst	w1, #0xffff
    c57c:	54ff4f61 	b.ne	af68 <f0+0xd08>  // b.any
    c580:	17fffa75 	b	af54 <f0+0xcf4>
    c584:	72003c3f 	tst	w1, #0xffff
    c588:	54ff0321 	b.ne	a5ec <f0+0x38c>  // b.any
    c58c:	17fff813 	b	a5d8 <f0+0x378>
    c590:	72003c3f 	tst	w1, #0xffff
    c594:	54fefe41 	b.ne	a55c <f0+0x2fc>  // b.any
    c598:	17fff7ec 	b	a548 <f0+0x2e8>
    c59c:	72003c3f 	tst	w1, #0xffff
    c5a0:	54fef941 	b.ne	a4c8 <f0+0x268>  // b.any
    c5a4:	17fff7c4 	b	a4b4 <f0+0x254>
    c5a8:	72003c3f 	tst	w1, #0xffff
    c5ac:	54ff19e1 	b.ne	a8e8 <f0+0x688>  // b.any
    c5b0:	17fff8c9 	b	a8d4 <f0+0x674>
    c5b4:	72003c3f 	tst	w1, #0xffff
    c5b8:	54ff14e1 	b.ne	a854 <f0+0x5f4>  // b.any
    c5bc:	17fff8a1 	b	a840 <f0+0x5e0>
    c5c0:	72003c3f 	tst	w1, #0xffff
    c5c4:	54ff1001 	b.ne	a7c4 <f0+0x564>  // b.any
    c5c8:	17fff87a 	b	a7b0 <f0+0x550>
    c5cc:	72003c3f 	tst	w1, #0xffff
    c5d0:	54ff08a1 	b.ne	a6e4 <f0+0x484>  // b.any
    c5d4:	17fff83f 	b	a6d0 <f0+0x470>
    c5d8:	72003c3f 	tst	w1, #0xffff
    c5dc:	54ff47a1 	b.ne	aed0 <f0+0xc70>  // b.any
    c5e0:	17fffa37 	b	aebc <f0+0xc5c>
    c5e4:	72003c3f 	tst	w1, #0xffff
    c5e8:	54ff42a1 	b.ne	ae3c <f0+0xbdc>  // b.any
    c5ec:	17fffa0f 	b	ae28 <f0+0xbc8>
    c5f0:	72003c3f 	tst	w1, #0xffff
    c5f4:	54ff3c81 	b.ne	ad84 <f0+0xb24>  // b.any
    c5f8:	17fff9de 	b	ad70 <f0+0xb10>
    c5fc:	72003c3f 	tst	w1, #0xffff
    c600:	54ff34a1 	b.ne	ac94 <f0+0xa34>  // b.any
    c604:	17fff99f 	b	ac80 <f0+0xa20>
    c608:	72003c3f 	tst	w1, #0xffff
    c60c:	54ff2e81 	b.ne	abdc <f0+0x97c>  // b.any
    c610:	17fff96e 	b	abc8 <f0+0x968>
    c614:	72003c3f 	tst	w1, #0xffff
    c618:	54ff2701 	b.ne	aaf8 <f0+0x898>  // b.any
    c61c:	17fff932 	b	aae4 <f0+0x884>
    c620:	72003c3f 	tst	w1, #0xffff
    c624:	54ff2121 	b.ne	aa48 <f0+0x7e8>  // b.any
    c628:	17fff903 	b	aa34 <f0+0x7d4>
    c62c:	72003c3f 	tst	w1, #0xffff
    c630:	54ff1b41 	b.ne	a998 <f0+0x738>  // b.any
    c634:	17fff8d4 	b	a984 <f0+0x724>
    c638:	72003c3f 	tst	w1, #0xffff
    c63c:	54ffea81 	b.ne	c38c <f0+0x212c>  // b.any
    c640:	17ffff4e 	b	c378 <f0+0x2118>
    c644:	72003c3f 	tst	w1, #0xffff
    c648:	54ffe2a1 	b.ne	c29c <f0+0x203c>  // b.any
    c64c:	17ffff0f 	b	c288 <f0+0x2028>
    c650:	72003c3f 	tst	w1, #0xffff
    c654:	54ffdac1 	b.ne	c1ac <f0+0x1f4c>  // b.any
    c658:	17fffed0 	b	c198 <f0+0x1f38>
    c65c:	72003c3f 	tst	w1, #0xffff
    c660:	54ffd201 	b.ne	c0a0 <f0+0x1e40>  // b.any
    c664:	17fffe8a 	b	c08c <f0+0x1e2c>
    c668:	72003c3f 	tst	w1, #0xffff
    c66c:	54ffcb01 	b.ne	bfcc <f0+0x1d6c>  // b.any
    c670:	17fffe52 	b	bfb8 <f0+0x1d58>
    c674:	72003c3f 	tst	w1, #0xffff
    c678:	54ffc321 	b.ne	bedc <f0+0x1c7c>  // b.any
    c67c:	17fffe13 	b	bec8 <f0+0x1c68>
    c680:	72003c3f 	tst	w1, #0xffff
    c684:	54ffbe01 	b.ne	be44 <f0+0x1be4>  // b.any
    c688:	17fffdea 	b	be30 <f0+0x1bd0>
    c68c:	72003c3f 	tst	w1, #0xffff
    c690:	54ffb381 	b.ne	bd00 <f0+0x1aa0>  // b.any
    c694:	17fffd96 	b	bcec <f0+0x1a8c>
    c698:	72003c3f 	tst	w1, #0xffff
    c69c:	54ffae61 	b.ne	bc68 <f0+0x1a08>  // b.any
    c6a0:	17fffd6d 	b	bc54 <f0+0x19f4>
    c6a4:	72003c3f 	tst	w1, #0xffff
    c6a8:	54ffa761 	b.ne	bb94 <f0+0x1934>  // b.any
    c6ac:	17fffd35 	b	bb80 <f0+0x1920>
    c6b0:	72003c3f 	tst	w1, #0xffff
    c6b4:	54ff9c01 	b.ne	ba34 <f0+0x17d4>  // b.any
    c6b8:	17fffcda 	b	ba20 <f0+0x17c0>
    c6bc:	72003c3f 	tst	w1, #0xffff
    c6c0:	54ff9341 	b.ne	b928 <f0+0x16c8>  // b.any
    c6c4:	17fffc94 	b	b914 <f0+0x16b4>
    c6c8:	72003c3f 	tst	w1, #0xffff
    c6cc:	54ff8c41 	b.ne	b854 <f0+0x15f4>  // b.any
    c6d0:	17fffc5c 	b	b840 <f0+0x15e0>
    c6d4:	72003c3f 	tst	w1, #0xffff
    c6d8:	54ff8461 	b.ne	b764 <f0+0x1504>  // b.any
    c6dc:	17fffc1d 	b	b750 <f0+0x14f0>
    c6e0:	72003c3f 	tst	w1, #0xffff
    c6e4:	54ff7f41 	b.ne	b6cc <f0+0x146c>  // b.any
    c6e8:	17fffbf4 	b	b6b8 <f0+0x1458>
    c6ec:	72003c3f 	tst	w1, #0xffff
    c6f0:	54ff7841 	b.ne	b5f8 <f0+0x1398>  // b.any
    c6f4:	17fffbbc 	b	b5e4 <f0+0x1384>
    c6f8:	aa1403e0 	mov	x0, x20
    c6fc:	97ffe03d 	bl	47f0 <fwp_rc_forget_slot>
    c700:	17ffff21 	b	c384 <f0+0x2124>
    c704:	aa1703e0 	mov	x0, x23
    c708:	97ffe03a 	bl	47f0 <fwp_rc_forget_slot>
    c70c:	17fff76d 	b	a4c0 <f0+0x260>
    c710:	aa1703e0 	mov	x0, x23
    c714:	97ffe037 	bl	47f0 <fwp_rc_forget_slot>
    c718:	17fff78f 	b	a554 <f0+0x2f4>
    c71c:	aa1703e0 	mov	x0, x23
    c720:	97ffe034 	bl	47f0 <fwp_rc_forget_slot>
    c724:	17fff7b0 	b	a5e4 <f0+0x384>
    c728:	aa1703e0 	mov	x0, x23
    c72c:	97ffe031 	bl	47f0 <fwp_rc_forget_slot>
    c730:	17fff7eb 	b	a6dc <f0+0x47c>
    c734:	aa1703e0 	mov	x0, x23
    c738:	97ffe02e 	bl	47f0 <fwp_rc_forget_slot>
    c73c:	17fff820 	b	a7bc <f0+0x55c>
    c740:	aa1703e0 	mov	x0, x23
    c744:	97ffe02b 	bl	47f0 <fwp_rc_forget_slot>
    c748:	17fff841 	b	a84c <f0+0x5ec>
    c74c:	aa1703e0 	mov	x0, x23
    c750:	97ffe028 	bl	47f0 <fwp_rc_forget_slot>
    c754:	17fff863 	b	a8e0 <f0+0x680>
    c758:	aa1703e0 	mov	x0, x23
    c75c:	97ffe025 	bl	47f0 <fwp_rc_forget_slot>
    c760:	17fff88c 	b	a990 <f0+0x730>
    c764:	aa1703e0 	mov	x0, x23
    c768:	97ffe022 	bl	47f0 <fwp_rc_forget_slot>
    c76c:	17fff8b5 	b	aa40 <f0+0x7e0>
    c770:	aa1703e0 	mov	x0, x23
    c774:	97ffe01f 	bl	47f0 <fwp_rc_forget_slot>
    c778:	17fff8de 	b	aaf0 <f0+0x890>
    c77c:	aa1703e0 	mov	x0, x23
    c780:	97ffe01c 	bl	47f0 <fwp_rc_forget_slot>
    c784:	17fff914 	b	abd4 <f0+0x974>
    c788:	aa1703e0 	mov	x0, x23
    c78c:	97ffe019 	bl	47f0 <fwp_rc_forget_slot>
    c790:	17fff93f 	b	ac8c <f0+0xa2c>
    c794:	aa1703e0 	mov	x0, x23
    c798:	97ffe016 	bl	47f0 <fwp_rc_forget_slot>
    c79c:	17fff978 	b	ad7c <f0+0xb1c>
    c7a0:	aa1703e0 	mov	x0, x23
    c7a4:	97ffe013 	bl	47f0 <fwp_rc_forget_slot>
    c7a8:	17fff9a3 	b	ae34 <f0+0xbd4>
    c7ac:	aa1703e0 	mov	x0, x23
    c7b0:	97ffe010 	bl	47f0 <fwp_rc_forget_slot>
    c7b4:	17fff9c5 	b	aec8 <f0+0xc68>
    c7b8:	aa1703e0 	mov	x0, x23
    c7bc:	97ffe00d 	bl	47f0 <fwp_rc_forget_slot>
    c7c0:	17fff9e8 	b	af60 <f0+0xd00>
    c7c4:	aa1703e0 	mov	x0, x23
    c7c8:	97ffe00a 	bl	47f0 <fwp_rc_forget_slot>
    c7cc:	17fffa0a 	b	aff4 <f0+0xd94>
    c7d0:	aa1703e0 	mov	x0, x23
    c7d4:	97ffe007 	bl	47f0 <fwp_rc_forget_slot>
    c7d8:	17fffa35 	b	b0ac <f0+0xe4c>
    c7dc:	aa1703e0 	mov	x0, x23
    c7e0:	97ffe004 	bl	47f0 <fwp_rc_forget_slot>
    c7e4:	17fffa75 	b	b1b8 <f0+0xf58>
    c7e8:	aa1703e0 	mov	x0, x23
    c7ec:	97ffe001 	bl	47f0 <fwp_rc_forget_slot>
    c7f0:	17fffaae 	b	b2a8 <f0+0x1048>
    c7f4:	aa1703e0 	mov	x0, x23
    c7f8:	97ffdffe 	bl	47f0 <fwp_rc_forget_slot>
    c7fc:	17fffae7 	b	b398 <f0+0x1138>
    c800:	aa1703e0 	mov	x0, x23
    c804:	97ffdffb 	bl	47f0 <fwp_rc_forget_slot>
    c808:	17fffb09 	b	b42c <f0+0x11cc>
    c80c:	aa1703e0 	mov	x0, x23
    c810:	97ffdff8 	bl	47f0 <fwp_rc_forget_slot>
    c814:	17fffb3b 	b	b500 <f0+0x12a0>
    c818:	aa1703e0 	mov	x0, x23
    c81c:	97ffdff5 	bl	47f0 <fwp_rc_forget_slot>
    c820:	17fffb74 	b	b5f0 <f0+0x1390>
    c824:	aa1703e0 	mov	x0, x23
    c828:	97ffdff2 	bl	47f0 <fwp_rc_forget_slot>
    c82c:	17fffba6 	b	b6c4 <f0+0x1464>
    c830:	aa1703e0 	mov	x0, x23
    c834:	97ffdfef 	bl	47f0 <fwp_rc_forget_slot>
    c838:	17fffbc9 	b	b75c <f0+0x14fc>
    c83c:	aa1703e0 	mov	x0, x23
    c840:	97ffdfec 	bl	47f0 <fwp_rc_forget_slot>
    c844:	17fffc02 	b	b84c <f0+0x15ec>
    c848:	aa1703e0 	mov	x0, x23
    c84c:	97ffdfe9 	bl	47f0 <fwp_rc_forget_slot>
    c850:	17fffc34 	b	b920 <f0+0x16c0>
    c854:	aa1703e0 	mov	x0, x23
    c858:	97ffdfe6 	bl	47f0 <fwp_rc_forget_slot>
    c85c:	17fffc74 	b	ba2c <f0+0x17cc>
    c860:	aa1703e0 	mov	x0, x23
    c864:	97ffdfe3 	bl	47f0 <fwp_rc_forget_slot>
    c868:	17fffcc9 	b	bb8c <f0+0x192c>
    c86c:	aa1703e0 	mov	x0, x23
    c870:	97ffdfe0 	bl	47f0 <fwp_rc_forget_slot>
    c874:	17fffcfb 	b	bc60 <f0+0x1a00>
    c878:	aa1503e0 	mov	x0, x21
    c87c:	97ffdfdd 	bl	47f0 <fwp_rc_forget_slot>
    c880:	17fffd1e 	b	bcf8 <f0+0x1a98>
    c884:	aa1703e0 	mov	x0, x23
    c888:	97ffdfda 	bl	47f0 <fwp_rc_forget_slot>
    c88c:	17fffd6c 	b	be3c <f0+0x1bdc>
    c890:	aa1703e0 	mov	x0, x23
    c894:	97ffdfd7 	bl	47f0 <fwp_rc_forget_slot>
    c898:	17fffd8f 	b	bed4 <f0+0x1c74>
    c89c:	aa1703e0 	mov	x0, x23
    c8a0:	97ffdfd4 	bl	47f0 <fwp_rc_forget_slot>
    c8a4:	17fffdc8 	b	bfc4 <f0+0x1d64>
    c8a8:	aa1703e0 	mov	x0, x23
    c8ac:	97ffdfd1 	bl	47f0 <fwp_rc_forget_slot>
    c8b0:	17fffdfa 	b	c098 <f0+0x1e38>
    c8b4:	aa1703e0 	mov	x0, x23
    c8b8:	97ffdfce 	bl	47f0 <fwp_rc_forget_slot>
    c8bc:	17fffe3a 	b	c1a4 <f0+0x1f44>
    c8c0:	aa1703e0 	mov	x0, x23
    c8c4:	97ffdfcb 	bl	47f0 <fwp_rc_forget_slot>
    c8c8:	17fffe73 	b	c294 <f0+0x2034>
    c8cc:	97ffd7ed 	bl	2880 <__stack_chk_fail@plt>

000000000000c8d0 <fwp_main_thread>:
    c8d0:	d10443ff 	sub	sp, sp, #0x110
    c8d4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c8d8:	f947f400 	ldr	x0, [x0, #4072]
    c8dc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c8e0:	910303fd 	add	x29, sp, #0xc0
    c8e4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c8e8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c8ec:	91174261 	add	x1, x19, #0x5d0
    c8f0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c8f4:	b953a421 	ldr	w1, [x1, #5028]
    c8f8:	f9400002 	ldr	x2, [x0]
    c8fc:	f9005fe2 	str	x2, [sp, #184]
    c900:	d2800002 	mov	x2, #0x0                   	// #0
    c904:	34002821 	cbz	w1, ce08 <fwp_main_thread+0x538>
    c908:	91174273 	add	x19, x19, #0x5d0
    c90c:	b953aa60 	ldr	w0, [x19, #5032]
    c910:	35002740 	cbnz	w0, cdf8 <fwp_main_thread+0x528>
    c914:	91001fe2 	add	x2, sp, #0x7
    c918:	900000b5 	adrp	x21, 20000 <__data_start>
    c91c:	900000a3 	adrp	x3, 20000 <__data_start>
    c920:	9101c2b3 	add	x19, x21, #0x70
    c924:	910fc063 	add	x3, x3, #0x3f0
    c928:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c92c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c930:	910023e0 	add	x0, sp, #0x8
    c934:	d2800001 	mov	x1, #0x0                   	// #0
    c938:	f90007e3 	str	x3, [sp, #8]
    c93c:	b90013ff 	str	wzr, [sp, #16]
    c940:	a9019262 	stp	x2, x4, [x19, #24]
    c944:	f9000fe5 	str	x5, [sp, #24]
    c948:	97ffd766 	bl	26e0 <sigaltstack@plt>
    c94c:	350026e0 	cbnz	w0, ce28 <fwp_main_thread+0x558>
    c950:	4f000400 	movi	v0.4s, #0x0
    c954:	9100a3e0 	add	x0, sp, #0x28
    c958:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c95c:	52800082 	mov	w2, #0x4                   	// #4
    c960:	9101c021 	add	x1, x1, #0x70
    c964:	72a10002 	movk	w2, #0x800, lsl #16
    c968:	910083f4 	add	x20, sp, #0x20
    c96c:	f90013e1 	str	x1, [sp, #32]
    c970:	3d802000 	str	q0, [x0, #128]
    c974:	b900abe2 	str	w2, [sp, #168]
    c978:	ad000000 	stp	q0, q0, [x0]
    c97c:	ad010000 	stp	q0, q0, [x0, #32]
    c980:	ad020000 	stp	q0, q0, [x0, #64]
    c984:	ad030000 	stp	q0, q0, [x0, #96]
    c988:	97ffd7ae 	bl	2840 <sigemptyset@plt>
    c98c:	350024e0 	cbnz	w0, ce28 <fwp_main_thread+0x558>
    c990:	aa1403e1 	mov	x1, x20
    c994:	d2800002 	mov	x2, #0x0                   	// #0
    c998:	52800160 	mov	w0, #0xb                   	// #11
    c99c:	97ffd7c1 	bl	28a0 <sigaction@plt>
    c9a0:	35002440 	cbnz	w0, ce28 <fwp_main_thread+0x558>
    c9a4:	aa1403e1 	mov	x1, x20
    c9a8:	d2800002 	mov	x2, #0x0                   	// #0
    c9ac:	528000e0 	mov	w0, #0x7                   	// #7
    c9b0:	97ffd7bc 	bl	28a0 <sigaction@plt>
    c9b4:	350023a0 	cbnz	w0, ce28 <fwp_main_thread+0x558>
    c9b8:	b9434a60 	ldr	w0, [x19, #840]
    c9bc:	34002000 	cbz	w0, cdbc <fwp_main_thread+0x4ec>
    c9c0:	9101c2b3 	add	x19, x21, #0x70
    c9c4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c9c8:	b9434e60 	ldr	w0, [x19, #844]
    c9cc:	340020c0 	cbz	w0, cde4 <fwp_main_thread+0x514>
    c9d0:	9101c2b6 	add	x22, x21, #0x70
    c9d4:	f9400ad4 	ldr	x20, [x22, #16]
    c9d8:	b40010f4 	cbz	x20, cbf4 <fwp_main_thread+0x324>
    c9dc:	aa1403f3 	mov	x19, x20
    c9e0:	91010297 	add	x23, x20, #0x40
    c9e4:	f90083f9 	str	x25, [sp, #256]
    c9e8:	52800038 	mov	w24, #0x1                   	// #1
    c9ec:	39414a99 	ldrb	w25, [x20, #82]
    c9f0:	39014a98 	strb	w24, [x20, #82]
    c9f4:	f9401680 	ldr	x0, [x20, #40]
    c9f8:	b4000620 	cbz	x0, cabc <fwp_main_thread+0x1ec>
    c9fc:	f9403281 	ldr	x1, [x20, #96]
    ca00:	39414680 	ldrb	w0, [x20, #81]
    ca04:	b4000b61 	cbz	x1, cb70 <fwp_main_thread+0x2a0>
    ca08:	36000aa0 	tbz	w0, #0, cb5c <fwp_main_thread+0x28c>
    ca0c:	39414a62 	ldrb	w2, [x19, #82]
    ca10:	f9402280 	ldr	x0, [x20, #64]
    ca14:	37000d82 	tbnz	w2, #0, cbc4 <fwp_main_thread+0x2f4>
    ca18:	f9403261 	ldr	x1, [x19, #96]
    ca1c:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca20:	f9009660 	str	x0, [x19, #296]
    ca24:	b4000040 	cbz	x0, ca2c <fwp_main_thread+0x15c>
    ca28:	f9009013 	str	x19, [x0, #288]
    ca2c:	f9002293 	str	x19, [x20, #64]
    ca30:	b4000101 	cbz	x1, ca50 <fwp_main_thread+0x180>
    ca34:	f9406ec0 	ldr	x0, [x22, #216]
    ca38:	39015678 	strb	w24, [x19, #85]
    ca3c:	f9003661 	str	x1, [x19, #104]
    ca40:	a910827f 	stp	xzr, x0, [x19, #264]
    ca44:	b4000040 	cbz	x0, ca4c <fwp_main_thread+0x17c>
    ca48:	f9008413 	str	x19, [x0, #264]
    ca4c:	f9006ed3 	str	x19, [x22, #216]
    ca50:	39015a7f 	strb	wzr, [x19, #86]
    ca54:	97ffe75c 	bl	67c4 <fwp_block>
    ca58:	f9408e62 	ldr	x2, [x19, #280]
    ca5c:	b4000142 	cbz	x2, ca84 <fwp_main_thread+0x1b4>
    ca60:	a9520261 	ldp	x1, x0, [x19, #288]
    ca64:	b4000bc1 	cbz	x1, cbdc <fwp_main_thread+0x30c>
    ca68:	f9009420 	str	x0, [x1, #296]
    ca6c:	f9409660 	ldr	x0, [x19, #296]
    ca70:	b4000040 	cbz	x0, ca78 <fwp_main_thread+0x1a8>
    ca74:	f9009001 	str	x1, [x0, #288]
    ca78:	91080260 	add	x0, x19, #0x200
    ca7c:	f900967f 	str	xzr, [x19, #296]
    ca80:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    ca84:	39415660 	ldrb	w0, [x19, #85]
    ca88:	f9400ac2 	ldr	x2, [x22, #16]
    ca8c:	36000980 	tbz	w0, #0, cbbc <fwp_main_thread+0x2ec>
    ca90:	a9508261 	ldp	x1, x0, [x19, #264]
    ca94:	b4000a81 	cbz	x1, cbe4 <fwp_main_thread+0x314>
    ca98:	f9008820 	str	x0, [x1, #272]
    ca9c:	b4000040 	cbz	x0, caa4 <fwp_main_thread+0x1d4>
    caa0:	f9008401 	str	x1, [x0, #264]
    caa4:	91080260 	add	x0, x19, #0x200
    caa8:	3901567f 	strb	wzr, [x19, #85]
    caac:	aa0203f3 	mov	x19, x2
    cab0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cab4:	f9401680 	ldr	x0, [x20, #40]
    cab8:	b5fffa20 	cbnz	x0, c9fc <fwp_main_thread+0x12c>
    cabc:	9101c2a0 	add	x0, x21, #0x70
    cac0:	39014a99 	strb	w25, [x20, #82]
    cac4:	f94083f9 	ldr	x25, [sp, #256]
    cac8:	f9419400 	ldr	x0, [x0, #808]
    cacc:	b4001580 	cbz	x0, cd7c <fwp_main_thread+0x4ac>
    cad0:	9101c2a0 	add	x0, x21, #0x70
    cad4:	f941b001 	ldr	x1, [x0, #864]
    cad8:	b903581f 	str	wzr, [x0, #856]
    cadc:	eb13003f 	cmp	x1, x19
    cae0:	540016a1 	b.ne	cdb4 <fwp_main_thread+0x4e4>  // b.any
    cae4:	b4000933 	cbz	x19, cc08 <fwp_main_thread+0x338>
    cae8:	9101c2a0 	add	x0, x21, #0x70
    caec:	52800021 	mov	w1, #0x1                   	// #1
    caf0:	39014a61 	strb	w1, [x19, #82]
    caf4:	f9418005 	ldr	x5, [x0, #768]
    caf8:	b4000885 	cbz	x5, cc08 <fwp_main_thread+0x338>
    cafc:	d503201f 	nop
    cb00:	394140a0 	ldrb	w0, [x5, #80]
    cb04:	37000060 	tbnz	w0, #0, cb10 <fwp_main_thread+0x240>
    cb08:	aa0503e0 	mov	x0, x5
    cb0c:	97ffdaf9 	bl	36f0 <fwp_cancel_tree.part.0>
    cb10:	f9409ca5 	ldr	x5, [x5, #312]
    cb14:	b5ffff65 	cbnz	x5, cb00 <fwp_main_thread+0x230>
    cb18:	9101c2b4 	add	x20, x21, #0x70
    cb1c:	52800036 	mov	w22, #0x1                   	// #1
    cb20:	f9402a60 	ldr	x0, [x19, #80]
    cb24:	f2001c1f 	tst	x0, #0xff000000ff
    cb28:	540000e1 	b.ne	cb44 <fwp_main_thread+0x274>  // b.any
    cb2c:	f9403e80 	ldr	x0, [x20, #120]
    cb30:	39015276 	strb	w22, [x19, #84]
    cb34:	f900827f 	str	xzr, [x19, #256]
    cb38:	b40005a0 	cbz	x0, cbec <fwp_main_thread+0x31c>
    cb3c:	f9008013 	str	x19, [x0, #256]
    cb40:	f9003e93 	str	x19, [x20, #120]
    cb44:	97ffe720 	bl	67c4 <fwp_block>
    cb48:	97ffe6b2 	bl	6610 <fwp_free_zombie>
    cb4c:	f9418280 	ldr	x0, [x20, #768]
    cb50:	b40005c0 	cbz	x0, cc08 <fwp_main_thread+0x338>
    cb54:	f941b293 	ldr	x19, [x20, #864]
    cb58:	17fffff2 	b	cb20 <fwp_main_thread+0x250>
    cb5c:	97ffdb89 	bl	3980 <fwp_now_ns>
    cb60:	f9403281 	ldr	x1, [x20, #96]
    cb64:	eb01001f 	cmp	x0, x1
    cb68:	54000fca 	b.ge	cd60 <fwp_main_thread+0x490>  // b.tcont
    cb6c:	39414680 	ldrb	w0, [x20, #81]
    cb70:	39414a62 	ldrb	w2, [x19, #82]
    cb74:	3707f4e0 	tbnz	w0, #0, ca10 <fwp_main_thread+0x140>
    cb78:	f9403281 	ldr	x1, [x20, #96]
    cb7c:	370001c2 	tbnz	w2, #0, cbb4 <fwp_main_thread+0x2e4>
    cb80:	f9403260 	ldr	x0, [x19, #96]
    cb84:	b4000180 	cbz	x0, cbb4 <fwp_main_thread+0x2e4>
    cb88:	b4000061 	cbz	x1, cb94 <fwp_main_thread+0x2c4>
    cb8c:	eb01001f 	cmp	x0, x1
    cb90:	9a81d000 	csel	x0, x0, x1, le
    cb94:	f9402281 	ldr	x1, [x20, #64]
    cb98:	a911fe77 	stp	x23, xzr, [x19, #280]
    cb9c:	f9009661 	str	x1, [x19, #296]
    cba0:	b4001381 	cbz	x1, ce10 <fwp_main_thread+0x540>
    cba4:	f9009033 	str	x19, [x1, #288]
    cba8:	aa0003e1 	mov	x1, x0
    cbac:	f9002293 	str	x19, [x20, #64]
    cbb0:	17ffffa1 	b	ca34 <fwp_main_thread+0x164>
    cbb4:	f9402280 	ldr	x0, [x20, #64]
    cbb8:	17ffff99 	b	ca1c <fwp_main_thread+0x14c>
    cbbc:	aa0203f3 	mov	x19, x2
    cbc0:	17ffff8d 	b	c9f4 <fwp_main_thread+0x124>
    cbc4:	a911fe77 	stp	x23, xzr, [x19, #280]
    cbc8:	f9009660 	str	x0, [x19, #296]
    cbcc:	b4000040 	cbz	x0, cbd4 <fwp_main_thread+0x304>
    cbd0:	f9009013 	str	x19, [x0, #288]
    cbd4:	f9002293 	str	x19, [x20, #64]
    cbd8:	17ffff9e 	b	ca50 <fwp_main_thread+0x180>
    cbdc:	f9000040 	str	x0, [x2]
    cbe0:	17ffffa4 	b	ca70 <fwp_main_thread+0x1a0>
    cbe4:	f9006ec0 	str	x0, [x22, #216]
    cbe8:	17ffffad 	b	ca9c <fwp_main_thread+0x1cc>
    cbec:	f9004293 	str	x19, [x20, #128]
    cbf0:	17ffffd4 	b	cb40 <fwp_main_thread+0x270>
    cbf4:	f94196c0 	ldr	x0, [x22, #808]
    cbf8:	b4000c00 	cbz	x0, cd78 <fwp_main_thread+0x4a8>
    cbfc:	f941b2c0 	ldr	x0, [x22, #864]
    cc00:	b9035adf 	str	wzr, [x22, #856]
    cc04:	b5000d80 	cbnz	x0, cdb4 <fwp_main_thread+0x4e4>
    cc08:	9101c2b4 	add	x20, x21, #0x70
    cc0c:	97ffe681 	bl	6610 <fwp_free_zombie>
    cc10:	f9404280 	ldr	x0, [x20, #128]
    cc14:	b5000d00 	cbnz	x0, cdb4 <fwp_main_thread+0x4e4>
    cc18:	f9406e80 	ldr	x0, [x20, #216]
    cc1c:	b5000cc0 	cbnz	x0, cdb4 <fwp_main_thread+0x4e4>
    cc20:	b940fa93 	ldr	w19, [x20, #248]
    cc24:	340001d3 	cbz	w19, cc5c <fwp_main_thread+0x38c>
    cc28:	93407e76 	sxtw	x22, w19
    cc2c:	51000673 	sub	w19, w19, #0x1
    cc30:	d1000ad6 	sub	x22, x22, #0x2
    cc34:	91040297 	add	x23, x20, #0x100
    cc38:	cb3342d6 	sub	x22, x22, w19, uxtw
    cc3c:	93407e73 	sxtw	x19, w19
    cc40:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cc44:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cc48:	b900fa93 	str	w19, [x20, #248]
    cc4c:	d1000673 	sub	x19, x19, #0x1
    cc50:	97ffd754 	bl	29a0 <munmap@plt>
    cc54:	eb16027f 	cmp	x19, x22
    cc58:	54ffff41 	b.ne	cc40 <fwp_main_thread+0x370>  // b.any
    cc5c:	900000b3 	adrp	x19, 20000 <__data_start>
    cc60:	91004260 	add	x0, x19, #0x10
    cc64:	b9404800 	ldr	w0, [x0, #72]
    cc68:	37f80040 	tbnz	w0, #31, cc70 <fwp_main_thread+0x3a0>
    cc6c:	97ffd709 	bl	2890 <close@plt>
    cc70:	9101c2a0 	add	x0, x21, #0x70
    cc74:	91004261 	add	x1, x19, #0x10
    cc78:	12800002 	mov	w2, #0xffffffff            	// #-1
    cc7c:	d2800013 	mov	x19, #0x0                   	// #0
    cc80:	f941b416 	ldr	x22, [x0, #872]
    cc84:	b9004822 	str	w2, [x1, #72]
    cc88:	f941b814 	ldr	x20, [x0, #880]
    cc8c:	b4000176 	cbz	x22, ccb8 <fwp_main_thread+0x3e8>
    cc90:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cc94:	b40000c0 	cbz	x0, ccac <fwp_main_thread+0x3dc>
    cc98:	f9400001 	ldr	x1, [x0]
    cc9c:	b50008c1 	cbnz	x1, cdb4 <fwp_main_thread+0x4e4>
    cca0:	f9400401 	ldr	x1, [x0, #8]
    cca4:	b5000881 	cbnz	x1, cdb4 <fwp_main_thread+0x4e4>
    cca8:	97ffdf72 	bl	4a70 <fwp_mem_free>
    ccac:	91000673 	add	x19, x19, #0x1
    ccb0:	eb16027f 	cmp	x19, x22
    ccb4:	54fffee1 	b.ne	cc90 <fwp_main_thread+0x3c0>  // b.any
    ccb8:	aa1403e0 	mov	x0, x20
    ccbc:	97ffdf6d 	bl	4a70 <fwp_mem_free>
    ccc0:	9101c2a0 	add	x0, x21, #0x70
    ccc4:	f941b013 	ldr	x19, [x0, #864]
    ccc8:	f901b41f 	str	xzr, [x0, #872]
    cccc:	f901b81f 	str	xzr, [x0, #880]
    ccd0:	b40001f3 	cbz	x19, cd0c <fwp_main_thread+0x43c>
    ccd4:	f9401661 	ldr	x1, [x19, #40]
    ccd8:	b50006e1 	cbnz	x1, cdb4 <fwp_main_thread+0x4e4>
    ccdc:	f9405661 	ldr	x1, [x19, #168]
    cce0:	b50006a1 	cbnz	x1, cdb4 <fwp_main_thread+0x4e4>
    cce4:	f9419401 	ldr	x1, [x0, #808]
    cce8:	b5000661 	cbnz	x1, cdb4 <fwp_main_thread+0x4e4>
    ccec:	f9419c00 	ldr	x0, [x0, #824]
    ccf0:	b5000620 	cbnz	x0, cdb4 <fwp_main_thread+0x4e4>
    ccf4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    ccf8:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    ccfc:	910fc000 	add	x0, x0, #0x3f0
    cd00:	97ffd6d4 	bl	2850 <memset@plt>
    cd04:	aa1303e0 	mov	x0, x19
    cd08:	97ffdf5a 	bl	4a70 <fwp_mem_free>
    cd0c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cd10:	f947ec00 	ldr	x0, [x0, #4056]
    cd14:	9101c2b5 	add	x21, x21, #0x70
    cd18:	f9400000 	ldr	x0, [x0]
    cd1c:	f9000abf 	str	xzr, [x21, #16]
    cd20:	f901b2bf 	str	xzr, [x21, #864]
    cd24:	97ffd723 	bl	29b0 <fflush@plt>
    cd28:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cd2c:	f947f400 	ldr	x0, [x0, #4072]
    cd30:	f9405fe2 	ldr	x2, [sp, #184]
    cd34:	f9400001 	ldr	x1, [x0]
    cd38:	eb010042 	subs	x2, x2, x1
    cd3c:	d2800001 	mov	x1, #0x0                   	// #0
    cd40:	54000821 	b.ne	ce44 <fwp_main_thread+0x574>  // b.any
    cd44:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cd48:	d2800000 	mov	x0, #0x0                   	// #0
    cd4c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cd50:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cd54:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cd58:	910443ff 	add	sp, sp, #0x110
    cd5c:	d65f03c0 	ret
    cd60:	39414280 	ldrb	w0, [x20, #80]
    cd64:	3707f040 	tbnz	w0, #0, cb6c <fwp_main_thread+0x29c>
    cd68:	aa1403e0 	mov	x0, x20
    cd6c:	97ffda61 	bl	36f0 <fwp_cancel_tree.part.0>
    cd70:	39414680 	ldrb	w0, [x20, #81]
    cd74:	17ffff7f 	b	cb70 <fwp_main_thread+0x2a0>
    cd78:	d2800013 	mov	x19, #0x0                   	// #0
    cd7c:	9101c2b4 	add	x20, x21, #0x70
    cd80:	f9419e80 	ldr	x0, [x20, #824]
    cd84:	b5ffea60 	cbnz	x0, cad0 <fwp_main_thread+0x200>
    cd88:	f9419280 	ldr	x0, [x20, #800]
    cd8c:	97ffdf39 	bl	4a70 <fwp_mem_free>
    cd90:	f901929f 	str	xzr, [x20, #800]
    cd94:	f9019a9f 	str	xzr, [x20, #816]
    cd98:	f941b280 	ldr	x0, [x20, #864]
    cd9c:	b4000413 	cbz	x19, ce1c <fwp_main_thread+0x54c>
    cda0:	f900567f 	str	xzr, [x19, #168]
    cda4:	f9005e7f 	str	xzr, [x19, #184]
    cda8:	b9035a9f 	str	wzr, [x20, #856]
    cdac:	eb00027f 	cmp	x19, x0
    cdb0:	54ffe9c0 	b.eq	cae8 <fwp_main_thread+0x218>  // b.none
    cdb4:	f90083f9 	str	x25, [sp, #256]
    cdb8:	97ffd6c6 	bl	28d0 <abort@plt>
    cdbc:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cdc0:	91058000 	add	x0, x0, #0x160
    cdc4:	940001df 	bl	d540 <atexit>
    cdc8:	a90f63f7 	stp	x23, x24, [sp, #240]
    cdcc:	35000380 	cbnz	w0, ce3c <fwp_main_thread+0x56c>
    cdd0:	52800020 	mov	w0, #0x1                   	// #1
    cdd4:	b9034a60 	str	w0, [x19, #840]
    cdd8:	9101c2b3 	add	x19, x21, #0x70
    cddc:	b9434e60 	ldr	w0, [x19, #844]
    cde0:	35ffdf80 	cbnz	w0, c9d0 <fwp_main_thread+0x100>
    cde4:	97fff51f 	bl	a260 <f0>
    cde8:	f901aa60 	str	x0, [x19, #848]
    cdec:	52800021 	mov	w1, #0x1                   	// #1
    cdf0:	b9034e61 	str	w1, [x19, #844]
    cdf4:	17fffef7 	b	c9d0 <fwp_main_thread+0x100>
    cdf8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cdfc:	913e8000 	add	x0, x0, #0xfa0
    ce00:	940001d0 	bl	d540 <atexit>
    ce04:	17fffec4 	b	c914 <fwp_main_thread+0x44>
    ce08:	97ffdcbf 	bl	4104 <fwp_heap_init>
    ce0c:	17fffebf 	b	c908 <fwp_main_thread+0x38>
    ce10:	aa0003e1 	mov	x1, x0
    ce14:	f9002293 	str	x19, [x20, #64]
    ce18:	17ffff07 	b	ca34 <fwp_main_thread+0x164>
    ce1c:	b9035a9f 	str	wzr, [x20, #856]
    ce20:	b4ffef40 	cbz	x0, cc08 <fwp_main_thread+0x338>
    ce24:	17ffffe4 	b	cdb4 <fwp_main_thread+0x4e4>
    ce28:	b0000000 	adrp	x0, d000 <__divti3+0x1b0>
    ce2c:	912f8000 	add	x0, x0, #0xbe0
    ce30:	a90f63f7 	stp	x23, x24, [sp, #240]
    ce34:	f90083f9 	str	x25, [sp, #256]
    ce38:	97ffda72 	bl	3800 <fwp_trap>
    ce3c:	f90083f9 	str	x25, [sp, #256]
    ce40:	97ffd8bc 	bl	3130 <descent_phase_fail>
    ce44:	f90083f9 	str	x25, [sp, #256]
    ce48:	97ffd68e 	bl	2880 <__stack_chk_fail@plt>
    ce4c:	d503201f 	nop

000000000000ce50 <__divti3>:
    ce50:	d503245f 	bti	c
    ce54:	d2800004 	mov	x4, #0x0                   	// #0
    ce58:	b7f80721 	tbnz	x1, #63, cf3c <__divti3+0xec>
    ce5c:	b6f80083 	tbz	x3, #63, ce6c <__divti3+0x1c>
    ce60:	eb0203e2 	negs	x2, x2
    ce64:	aa2403e4 	mvn	x4, x4
    ce68:	da0303e3 	ngc	x3, x3
    ce6c:	aa0203e6 	mov	x6, x2
    ce70:	aa0003e7 	mov	x7, x0
    ce74:	aa0103e5 	mov	x5, x1
    ce78:	b5000583 	cbnz	x3, cf28 <__divti3+0xd8>
    ce7c:	eb01005f 	cmp	x2, x1
    ce80:	54000e69 	b.ls	d04c <__divti3+0x1fc>  // b.plast
    ce84:	dac01040 	clz	x0, x2
    ce88:	b40000e0 	cbz	x0, cea4 <__divti3+0x54>
    ce8c:	4b0003e1 	neg	w1, w0
    ce90:	9ac020a5 	lsl	x5, x5, x0
    ce94:	9ac02046 	lsl	x6, x2, x0
    ce98:	9ac124e1 	lsr	x1, x7, x1
    ce9c:	aa050025 	orr	x5, x1, x5
    cea0:	9ac020e7 	lsl	x7, x7, x0
    cea4:	d360fcc8 	lsr	x8, x6, #32
    cea8:	92407cc2 	and	x2, x6, #0xffffffff
    ceac:	9ac808a3 	udiv	x3, x5, x8
    ceb0:	9b089465 	msub	x5, x3, x8, x5
    ceb4:	aa0303e0 	mov	x0, x3
    ceb8:	9b037c41 	mul	x1, x2, x3
    cebc:	93c780a5 	extr	x5, x5, x7, #32
    cec0:	eb05003f 	cmp	x1, x5
    cec4:	540000a9 	b.ls	ced8 <__divti3+0x88>  // b.plast
    cec8:	ab0500c5 	adds	x5, x6, x5
    cecc:	d1000460 	sub	x0, x3, #0x1
    ced0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ced4:	540015a8 	b.hi	d188 <__divti3+0x338>  // b.pmore
    ced8:	cb0100a5 	sub	x5, x5, x1
    cedc:	9ac808a3 	udiv	x3, x5, x8
    cee0:	9b089465 	msub	x5, x3, x8, x5
    cee4:	aa0303e1 	mov	x1, x3
    cee8:	9b037c42 	mul	x2, x2, x3
    ceec:	aa0703e3 	mov	x3, x7
    cef0:	b3607ca3 	bfi	x3, x5, #32, #32
    cef4:	eb03005f 	cmp	x2, x3
    cef8:	540000c9 	b.ls	cf10 <__divti3+0xc0>  // b.plast
    cefc:	ab0300c3 	adds	x3, x6, x3
    cf00:	d1000425 	sub	x5, x1, #0x1
    cf04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cf08:	d1000821 	sub	x1, x1, #0x2
    cf0c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cf10:	aa008020 	orr	x0, x1, x0, lsl #32
    cf14:	d2800001 	mov	x1, #0x0                   	// #0
    cf18:	b4000064 	cbz	x4, cf24 <__divti3+0xd4>
    cf1c:	eb0003e0 	negs	x0, x0
    cf20:	da0103e1 	ngc	x1, x1
    cf24:	d65f03c0 	ret
    cf28:	eb01007f 	cmp	x3, x1
    cf2c:	54000109 	b.ls	cf4c <__divti3+0xfc>  // b.plast
    cf30:	d2800001 	mov	x1, #0x0                   	// #0
    cf34:	d2800000 	mov	x0, #0x0                   	// #0
    cf38:	17fffff8 	b	cf18 <__divti3+0xc8>
    cf3c:	eb0003e0 	negs	x0, x0
    cf40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cf44:	da0103e1 	ngc	x1, x1
    cf48:	17ffffc5 	b	ce5c <__divti3+0xc>
    cf4c:	dac01067 	clz	x7, x3
    cf50:	b40010e7 	cbz	x7, d16c <__divti3+0x31c>
    cf54:	d2800805 	mov	x5, #0x40                  	// #64
    cf58:	cb0700a5 	sub	x5, x5, x7
    cf5c:	9ac72063 	lsl	x3, x3, x7
    cf60:	9ac52448 	lsr	x8, x2, x5
    cf64:	aa030108 	orr	x8, x8, x3
    cf68:	9ac52426 	lsr	x6, x1, x5
    cf6c:	92407d0a 	and	x10, x8, #0xffffffff
    cf70:	d360fd09 	lsr	x9, x8, #32
    cf74:	9ac52403 	lsr	x3, x0, x5
    cf78:	9ac72021 	lsl	x1, x1, x7
    cf7c:	aa010063 	orr	x3, x3, x1
    cf80:	9ac72042 	lsl	x2, x2, x7
    cf84:	9ac908cb 	udiv	x11, x6, x9
    cf88:	9b099965 	msub	x5, x11, x9, x6
    cf8c:	aa0b03e1 	mov	x1, x11
    cf90:	9b0b7d46 	mul	x6, x10, x11
    cf94:	93c380a5 	extr	x5, x5, x3, #32
    cf98:	eb0500df 	cmp	x6, x5
    cf9c:	540000a9 	b.ls	cfb0 <__divti3+0x160>  // b.plast
    cfa0:	ab050105 	adds	x5, x8, x5
    cfa4:	d1000561 	sub	x1, x11, #0x1
    cfa8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cfac:	54000f48 	b.hi	d194 <__divti3+0x344>  // b.pmore
    cfb0:	cb0600a6 	sub	x6, x5, x6
    cfb4:	9ac908cb 	udiv	x11, x6, x9
    cfb8:	9b099969 	msub	x9, x11, x9, x6
    cfbc:	aa0b03e5 	mov	x5, x11
    cfc0:	9b0b7d4a 	mul	x10, x10, x11
    cfc4:	b3607d23 	bfi	x3, x9, #32, #32
    cfc8:	eb03015f 	cmp	x10, x3
    cfcc:	540000a9 	b.ls	cfe0 <__divti3+0x190>  // b.plast
    cfd0:	ab030103 	adds	x3, x8, x3
    cfd4:	d1000565 	sub	x5, x11, #0x1
    cfd8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cfdc:	54000e28 	b.hi	d1a0 <__divti3+0x350>  // b.pmore
    cfe0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cfe4:	92407c48 	and	x8, x2, #0xffffffff
    cfe8:	2a0503e5 	mov	w5, w5
    cfec:	d360fc42 	lsr	x2, x2, #32
    cff0:	d360fc26 	lsr	x6, x1, #32
    cff4:	cb0a0063 	sub	x3, x3, x10
    cff8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cffc:	9b087caa 	mul	x10, x5, x8
    d000:	9b087cc8 	mul	x8, x6, x8
    d004:	9b0220a5 	madd	x5, x5, x2, x8
    d008:	9b027cc6 	mul	x6, x6, x2
    d00c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d010:	8b0900c5 	add	x5, x6, x9
    d014:	eb02011f 	cmp	x8, x2
    d018:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d01c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d020:	eb06007f 	cmp	x3, x6
    d024:	540000e3 	b.cc	d040 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d028:	92407d4a 	and	x10, x10, #0xffffffff
    d02c:	9ac72000 	lsl	x0, x0, x7
    d030:	8b028142 	add	x2, x10, x2, lsl #32
    d034:	eb02001f 	cmp	x0, x2
    d038:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d03c:	54000a01 	b.ne	d17c <__divti3+0x32c>  // b.any
    d040:	d1000420 	sub	x0, x1, #0x1
    d044:	d2800001 	mov	x1, #0x0                   	// #0
    d048:	17ffffb4 	b	cf18 <__divti3+0xc8>
    d04c:	b5000062 	cbnz	x2, d058 <__divti3+0x208>
    d050:	d2800022 	mov	x2, #0x1                   	// #1
    d054:	9ac30846 	udiv	x6, x2, x3
    d058:	dac010c8 	clz	x8, x6
    d05c:	b5000408 	cbnz	x8, d0dc <__divti3+0x28c>
    d060:	d360fcc9 	lsr	x9, x6, #32
    d064:	92407cc5 	and	x5, x6, #0xffffffff
    d068:	cb060023 	sub	x3, x1, x6
    d06c:	d2800021 	mov	x1, #0x1                   	// #1
    d070:	9ac90868 	udiv	x8, x3, x9
    d074:	9b098d03 	msub	x3, x8, x9, x3
    d078:	aa0803e0 	mov	x0, x8
    d07c:	9b057d02 	mul	x2, x8, x5
    d080:	93c78063 	extr	x3, x3, x7, #32
    d084:	eb03005f 	cmp	x2, x3
    d088:	540000a9 	b.ls	d09c <__divti3+0x24c>  // b.plast
    d08c:	ab0300c3 	adds	x3, x6, x3
    d090:	d1000500 	sub	x0, x8, #0x1
    d094:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d098:	54000968 	b.hi	d1c4 <__divti3+0x374>  // b.pmore
    d09c:	cb020063 	sub	x3, x3, x2
    d0a0:	9ac90862 	udiv	x2, x3, x9
    d0a4:	aa0203e8 	mov	x8, x2
    d0a8:	9b098c42 	msub	x2, x2, x9, x3
    d0ac:	aa0703e3 	mov	x3, x7
    d0b0:	9b057d05 	mul	x5, x8, x5
    d0b4:	b3607c43 	bfi	x3, x2, #32, #32
    d0b8:	eb0300bf 	cmp	x5, x3
    d0bc:	540000c9 	b.ls	d0d4 <__divti3+0x284>  // b.plast
    d0c0:	ab0300c2 	adds	x2, x6, x3
    d0c4:	d1000503 	sub	x3, x8, #0x1
    d0c8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d0cc:	d1000908 	sub	x8, x8, #0x2
    d0d0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d0d4:	aa008100 	orr	x0, x8, x0, lsl #32
    d0d8:	17ffff90 	b	cf18 <__divti3+0xc8>
    d0dc:	9ac820c6 	lsl	x6, x6, x8
    d0e0:	d2800803 	mov	x3, #0x40                  	// #64
    d0e4:	cb080063 	sub	x3, x3, x8
    d0e8:	d360fcc9 	lsr	x9, x6, #32
    d0ec:	9ac82027 	lsl	x7, x1, x8
    d0f0:	92407cc5 	and	x5, x6, #0xffffffff
    d0f4:	9ac32422 	lsr	x2, x1, x3
    d0f8:	9ac32403 	lsr	x3, x0, x3
    d0fc:	aa070063 	orr	x3, x3, x7
    d100:	9ac9084a 	udiv	x10, x2, x9
    d104:	9ac82007 	lsl	x7, x0, x8
    d108:	9b098940 	msub	x0, x10, x9, x2
    d10c:	aa0a03e1 	mov	x1, x10
    d110:	9b0a7ca2 	mul	x2, x5, x10
    d114:	93c38000 	extr	x0, x0, x3, #32
    d118:	eb00005f 	cmp	x2, x0
    d11c:	540000a9 	b.ls	d130 <__divti3+0x2e0>  // b.plast
    d120:	ab0000c0 	adds	x0, x6, x0
    d124:	d1000541 	sub	x1, x10, #0x1
    d128:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d12c:	54000468 	b.hi	d1b8 <__divti3+0x368>  // b.pmore
    d130:	cb020000 	sub	x0, x0, x2
    d134:	9ac9080a 	udiv	x10, x0, x9
    d138:	9b098140 	msub	x0, x10, x9, x0
    d13c:	aa0a03e2 	mov	x2, x10
    d140:	9b0a7ca8 	mul	x8, x5, x10
    d144:	b3607c03 	bfi	x3, x0, #32, #32
    d148:	eb03011f 	cmp	x8, x3
    d14c:	540000a9 	b.ls	d160 <__divti3+0x310>  // b.plast
    d150:	ab0300c3 	adds	x3, x6, x3
    d154:	d1000542 	sub	x2, x10, #0x1
    d158:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d15c:	54000288 	b.hi	d1ac <__divti3+0x35c>  // b.pmore
    d160:	cb080063 	sub	x3, x3, x8
    d164:	aa018041 	orr	x1, x2, x1, lsl #32
    d168:	17ffffc2 	b	d070 <__divti3+0x220>
    d16c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d170:	d2800001 	mov	x1, #0x0                   	// #0
    d174:	9a9f87e0 	cset	x0, ls	// ls = plast
    d178:	17ffff68 	b	cf18 <__divti3+0xc8>
    d17c:	aa0103e0 	mov	x0, x1
    d180:	d2800001 	mov	x1, #0x0                   	// #0
    d184:	17ffff65 	b	cf18 <__divti3+0xc8>
    d188:	d1000860 	sub	x0, x3, #0x2
    d18c:	8b0600a5 	add	x5, x5, x6
    d190:	17ffff52 	b	ced8 <__divti3+0x88>
    d194:	d1000961 	sub	x1, x11, #0x2
    d198:	8b0800a5 	add	x5, x5, x8
    d19c:	17ffff85 	b	cfb0 <__divti3+0x160>
    d1a0:	d1000965 	sub	x5, x11, #0x2
    d1a4:	8b080063 	add	x3, x3, x8
    d1a8:	17ffff8e 	b	cfe0 <__divti3+0x190>
    d1ac:	d1000942 	sub	x2, x10, #0x2
    d1b0:	8b060063 	add	x3, x3, x6
    d1b4:	17ffffeb 	b	d160 <__divti3+0x310>
    d1b8:	d1000941 	sub	x1, x10, #0x2
    d1bc:	8b060000 	add	x0, x0, x6
    d1c0:	17ffffdc 	b	d130 <__divti3+0x2e0>
    d1c4:	d1000900 	sub	x0, x8, #0x2
    d1c8:	8b060063 	add	x3, x3, x6
    d1cc:	17ffffb4 	b	d09c <__divti3+0x24c>

000000000000d1d0 <__modti3>:
    d1d0:	d503245f 	bti	c
    d1d4:	d2800004 	mov	x4, #0x0                   	// #0
    d1d8:	b6f80081 	tbz	x1, #63, d1e8 <__modti3+0x18>
    d1dc:	eb0003e0 	negs	x0, x0
    d1e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d1e4:	da0103e1 	ngc	x1, x1
    d1e8:	f100007f 	cmp	x3, #0x0
    d1ec:	5400128b 	b.lt	d43c <__modti3+0x26c>  // b.tstop
    d1f0:	aa0003e7 	mov	x7, x0
    d1f4:	aa0103e6 	mov	x6, x1
    d1f8:	540004e1 	b.ne	d294 <__modti3+0xc4>  // b.any
    d1fc:	eb02003f 	cmp	x1, x2
    d200:	54000dc2 	b.cs	d3b8 <__modti3+0x1e8>  // b.hs, b.nlast
    d204:	dac01043 	clz	x3, x2
    d208:	aa0303e5 	mov	x5, x3
    d20c:	b40000e3 	cbz	x3, d228 <__modti3+0x58>
    d210:	4b0303e6 	neg	w6, w3
    d214:	9ac32021 	lsl	x1, x1, x3
    d218:	9ac32042 	lsl	x2, x2, x3
    d21c:	9ac62406 	lsr	x6, x0, x6
    d220:	aa0100c6 	orr	x6, x6, x1
    d224:	9ac32007 	lsl	x7, x0, x3
    d228:	d360fc40 	lsr	x0, x2, #32
    d22c:	92407c43 	and	x3, x2, #0xffffffff
    d230:	9ac008c1 	udiv	x1, x6, x0
    d234:	9b009826 	msub	x6, x1, x0, x6
    d238:	9b017c61 	mul	x1, x3, x1
    d23c:	93c780c6 	extr	x6, x6, x7, #32
    d240:	eb06003f 	cmp	x1, x6
    d244:	540000a9 	b.ls	d258 <__modti3+0x88>  // b.plast
    d248:	ab060046 	adds	x6, x2, x6
    d24c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d250:	8b0200c8 	add	x8, x6, x2
    d254:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d258:	cb0100c6 	sub	x6, x6, x1
    d25c:	9ac008c8 	udiv	x8, x6, x0
    d260:	9b009901 	msub	x1, x8, x0, x6
    d264:	aa0703e0 	mov	x0, x7
    d268:	9b087c63 	mul	x3, x3, x8
    d26c:	b3607c20 	bfi	x0, x1, #32, #32
    d270:	eb00007f 	cmp	x3, x0
    d274:	54001088 	b.hi	d484 <__modti3+0x2b4>  // b.pmore
    d278:	cb030000 	sub	x0, x0, x3
    d27c:	9ac52400 	lsr	x0, x0, x5
    d280:	d2800001 	mov	x1, #0x0                   	// #0
    d284:	b4000064 	cbz	x4, d290 <__modti3+0xc0>
    d288:	eb0003e0 	negs	x0, x0
    d28c:	da0103e1 	ngc	x1, x1
    d290:	d65f03c0 	ret
    d294:	dac01066 	clz	x6, x3
    d298:	eb03003f 	cmp	x1, x3
    d29c:	54ffff43 	b.cc	d284 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d2a0:	93407cc5 	sxtw	x5, w6
    d2a4:	d2800808 	mov	x8, #0x40                  	// #64
    d2a8:	cb050108 	sub	x8, x8, x5
    d2ac:	9ac62063 	lsl	x3, x3, x6
    d2b0:	9ac62025 	lsl	x5, x1, x6
    d2b4:	9ac82447 	lsr	x7, x2, x8
    d2b8:	aa0300e7 	orr	x7, x7, x3
    d2bc:	9ac82423 	lsr	x3, x1, x8
    d2c0:	92407cec 	and	x12, x7, #0xffffffff
    d2c4:	d360fcea 	lsr	x10, x7, #32
    d2c8:	9ac82401 	lsr	x1, x0, x8
    d2cc:	aa050021 	orr	x1, x1, x5
    d2d0:	9ac62042 	lsl	x2, x2, x6
    d2d4:	9ac62000 	lsl	x0, x0, x6
    d2d8:	9aca086b 	udiv	x11, x3, x10
    d2dc:	9b0a8d63 	msub	x3, x11, x10, x3
    d2e0:	aa0b03e5 	mov	x5, x11
    d2e4:	9b0b7d89 	mul	x9, x12, x11
    d2e8:	93c18063 	extr	x3, x3, x1, #32
    d2ec:	eb03013f 	cmp	x9, x3
    d2f0:	540000a9 	b.ls	d304 <__modti3+0x134>  // b.plast
    d2f4:	ab0300e3 	adds	x3, x7, x3
    d2f8:	d1000565 	sub	x5, x11, #0x1
    d2fc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d300:	54001168 	b.hi	d52c <__modti3+0x35c>  // b.pmore
    d304:	cb090063 	sub	x3, x3, x9
    d308:	9aca086b 	udiv	x11, x3, x10
    d30c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d310:	aa0b03e9 	mov	x9, x11
    d314:	9b0b7d8c 	mul	x12, x12, x11
    d318:	b3607d41 	bfi	x1, x10, #32, #32
    d31c:	eb01019f 	cmp	x12, x1
    d320:	540000a9 	b.ls	d334 <__modti3+0x164>  // b.plast
    d324:	ab0100e1 	adds	x1, x7, x1
    d328:	d1000569 	sub	x9, x11, #0x1
    d32c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d330:	54000f88 	b.hi	d520 <__modti3+0x350>  // b.pmore
    d334:	aa058123 	orr	x3, x9, x5, lsl #32
    d338:	92407c4b 	and	x11, x2, #0xffffffff
    d33c:	2a0903e9 	mov	w9, w9
    d340:	d360fc4a 	lsr	x10, x2, #32
    d344:	d360fc63 	lsr	x3, x3, #32
    d348:	cb0c0021 	sub	x1, x1, x12
    d34c:	aa0a03ec 	mov	x12, x10
    d350:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d354:	9b0b7d25 	mul	x5, x9, x11
    d358:	9b0b7c6b 	mul	x11, x3, x11
    d35c:	9b0a2d29 	madd	x9, x9, x10, x11
    d360:	92407caa 	and	x10, x5, #0xffffffff
    d364:	9b0c7c63 	mul	x3, x3, x12
    d368:	8b458125 	add	x5, x9, x5, lsr #32
    d36c:	8b0d0069 	add	x9, x3, x13
    d370:	eb05017f 	cmp	x11, x5
    d374:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d378:	8b058149 	add	x9, x10, x5, lsl #32
    d37c:	8b458063 	add	x3, x3, x5, lsr #32
    d380:	eb03003f 	cmp	x1, x3
    d384:	54000063 	b.cc	d390 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d388:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d38c:	54000082 	b.cs	d39c <__modti3+0x1cc>  // b.hs, b.nlast
    d390:	eb020129 	subs	x9, x9, x2
    d394:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d398:	cb070063 	sub	x3, x3, x7
    d39c:	eb090000 	subs	x0, x0, x9
    d3a0:	da030021 	sbc	x1, x1, x3
    d3a4:	9ac62400 	lsr	x0, x0, x6
    d3a8:	9ac82028 	lsl	x8, x1, x8
    d3ac:	aa000100 	orr	x0, x8, x0
    d3b0:	9ac62421 	lsr	x1, x1, x6
    d3b4:	17ffffb4 	b	d284 <__modti3+0xb4>
    d3b8:	b5000062 	cbnz	x2, d3c4 <__modti3+0x1f4>
    d3bc:	d2800023 	mov	x3, #0x1                   	// #1
    d3c0:	9ac20862 	udiv	x2, x3, x2
    d3c4:	dac01048 	clz	x8, x2
    d3c8:	aa0803e5 	mov	x5, x8
    d3cc:	b5000668 	cbnz	x8, d498 <__modti3+0x2c8>
    d3d0:	cb020020 	sub	x0, x1, x2
    d3d4:	d360fc49 	lsr	x9, x2, #32
    d3d8:	92407c4a 	and	x10, x2, #0xffffffff
    d3dc:	9ac90801 	udiv	x1, x0, x9
    d3e0:	9b098020 	msub	x0, x1, x9, x0
    d3e4:	9b0a7c21 	mul	x1, x1, x10
    d3e8:	93c78000 	extr	x0, x0, x7, #32
    d3ec:	eb00003f 	cmp	x1, x0
    d3f0:	540000a9 	b.ls	d404 <__modti3+0x234>  // b.plast
    d3f4:	ab000040 	adds	x0, x2, x0
    d3f8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3fc:	8b020003 	add	x3, x0, x2
    d400:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d404:	cb010001 	sub	x1, x0, x1
    d408:	9ac90820 	udiv	x0, x1, x9
    d40c:	9b098403 	msub	x3, x0, x9, x1
    d410:	aa0703e1 	mov	x1, x7
    d414:	9b0a7c00 	mul	x0, x0, x10
    d418:	b3607c61 	bfi	x1, x3, #32, #32
    d41c:	eb01001f 	cmp	x0, x1
    d420:	540000a9 	b.ls	d434 <__modti3+0x264>  // b.plast
    d424:	ab010041 	adds	x1, x2, x1
    d428:	8b020022 	add	x2, x1, x2
    d42c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d430:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d434:	cb000020 	sub	x0, x1, x0
    d438:	17ffff91 	b	d27c <__modti3+0xac>
    d43c:	eb0203e5 	negs	x5, x2
    d440:	aa0003e7 	mov	x7, x0
    d444:	da0303e8 	ngc	x8, x3
    d448:	aa0503e2 	mov	x2, x5
    d44c:	aa0803e3 	mov	x3, x8
    d450:	aa0103e6 	mov	x6, x1
    d454:	b4ffed48 	cbz	x8, d1fc <__modti3+0x2c>
    d458:	eb01011f 	cmp	x8, x1
    d45c:	54fff148 	b.hi	d284 <__modti3+0xb4>  // b.pmore
    d460:	dac01109 	clz	x9, x8
    d464:	2a0903e6 	mov	w6, w9
    d468:	b5fff1c9 	cbnz	x9, d2a0 <__modti3+0xd0>
    d46c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d470:	54000068 	b.hi	d47c <__modti3+0x2ac>  // b.pmore
    d474:	eb050007 	subs	x7, x0, x5
    d478:	da080021 	sbc	x1, x1, x8
    d47c:	aa0703e0 	mov	x0, x7
    d480:	17ffff81 	b	d284 <__modti3+0xb4>
    d484:	ab000040 	adds	x0, x2, x0
    d488:	8b020002 	add	x2, x0, x2
    d48c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d490:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d494:	17ffff79 	b	d278 <__modti3+0xa8>
    d498:	9ac82042 	lsl	x2, x2, x8
    d49c:	d2800803 	mov	x3, #0x40                  	// #64
    d4a0:	cb080063 	sub	x3, x3, x8
    d4a4:	d360fc49 	lsr	x9, x2, #32
    d4a8:	9ac82027 	lsl	x7, x1, x8
    d4ac:	92407c4a 	and	x10, x2, #0xffffffff
    d4b0:	9ac32426 	lsr	x6, x1, x3
    d4b4:	9ac32403 	lsr	x3, x0, x3
    d4b8:	aa070063 	orr	x3, x3, x7
    d4bc:	9ac908c1 	udiv	x1, x6, x9
    d4c0:	9ac82007 	lsl	x7, x0, x8
    d4c4:	9b099820 	msub	x0, x1, x9, x6
    d4c8:	9b017d41 	mul	x1, x10, x1
    d4cc:	93c38000 	extr	x0, x0, x3, #32
    d4d0:	eb00003f 	cmp	x1, x0
    d4d4:	540000a9 	b.ls	d4e8 <__modti3+0x318>  // b.plast
    d4d8:	ab000040 	adds	x0, x2, x0
    d4dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d4e0:	8b020006 	add	x6, x0, x2
    d4e4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d4e8:	cb010000 	sub	x0, x0, x1
    d4ec:	9ac90801 	udiv	x1, x0, x9
    d4f0:	9b098026 	msub	x6, x1, x9, x0
    d4f4:	aa0303e0 	mov	x0, x3
    d4f8:	9b017d41 	mul	x1, x10, x1
    d4fc:	b3607cc0 	bfi	x0, x6, #32, #32
    d500:	eb00003f 	cmp	x1, x0
    d504:	540000a9 	b.ls	d518 <__modti3+0x348>  // b.plast
    d508:	ab000040 	adds	x0, x2, x0
    d50c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d510:	8b020003 	add	x3, x0, x2
    d514:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d518:	cb010000 	sub	x0, x0, x1
    d51c:	17ffffb0 	b	d3dc <__modti3+0x20c>
    d520:	d1000969 	sub	x9, x11, #0x2
    d524:	8b070021 	add	x1, x1, x7
    d528:	17ffff83 	b	d334 <__modti3+0x164>
    d52c:	d1000965 	sub	x5, x11, #0x2
    d530:	8b070063 	add	x3, x3, x7
    d534:	17ffff74 	b	d304 <__modti3+0x134>
    d538:	d503201f 	nop
    d53c:	d503201f 	nop

000000000000d540 <atexit>:
    d540:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d544:	f0000082 	adrp	x2, 20000 <__data_start>
    d548:	d2800001 	mov	x1, #0x0                   	// #0
    d54c:	910003fd 	mov	x29, sp
    d550:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d554:	f9400442 	ldr	x2, [x2, #8]
    d558:	17ffd48a 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d55c <_fini>:
    d55c:	d503201f 	nop
    d560:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d564:	910003fd 	mov	x29, sp
    d568:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d56c:	d65f03c0 	ret
