
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__divti3+0x2d0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911c20a5 	add	x5, x5, #0x708
    2aa0:	f0000044 	adrp	x4, d000 <__divti3+0x2d0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911c4084 	add	x4, x4, #0x710
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe8d0>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__divti3+0x2d0>
    2b34:	912ba000 	add	x0, x0, #0xae8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1ec0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911ec042 	add	x2, x2, #0x7b0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435a60 	ldr	w0, [x19, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__divti3+0x2d0>
    2c7c:	912be000 	add	x0, x0, #0xaf8
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__divti3+0x2d0>
    2c8c:	912e6000 	add	x0, x0, #0xb98
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__divti3+0x2d0>
    2ca4:	912dc000 	add	x0, x0, #0xb70
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__divti3+0x2d0>
    2cb0:	912d0000 	add	x0, x0, #0xb40
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__divti3+0x2d0>
    2cbc:	912c6000 	add	x0, x0, #0xb18
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xbb0>
    2eb4:	91080021 	add	x1, x1, #0x200
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3050:	91116000 	add	x0, x0, #0x458
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xbb0>
    3118:	91078021 	add	x1, x1, #0x1e0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3150:	9111c000 	add	x0, x0, #0x470
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <__divti3+0x2d0>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <__divti3+0x2d0>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	d0000058 	adrp	x24, d000 <__divti3+0x2d0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	9112e042 	add	x2, x2, #0x4b8
    31e0:	911442d6 	add	x22, x22, #0x510
    31e4:	913da318 	add	x24, x24, #0xf68
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <__divti3+0x2d0>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	91142323 	add	x3, x25, #0x508
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91148000 	add	x0, x0, #0x520
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3570:	91116000 	add	x0, x0, #0x458
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__divti3+0x2d0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9114a021 	add	x1, x1, #0x528
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__divti3+0x2d0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	9114c021 	add	x1, x1, #0x530
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__divti3+0x2d0>
    37e0:	9114e021 	add	x1, x1, #0x538
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__divti3+0x2d0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91150042 	add	x2, x2, #0x540
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3950:	91116000 	add	x0, x0, #0x458
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3970:	91154000 	add	x0, x0, #0x550
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3a08:	9115c000 	add	x0, x0, #0x570
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3a18:	91164000 	add	x0, x0, #0x590
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xbb0>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc08420 	ldr	q0, [x1, #528]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3b18:	9116e000 	add	x0, x0, #0x5b8
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3b88:	9117a000 	add	x0, x0, #0x5e8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__divti3+0x2d0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	9118e084 	add	x4, x4, #0x638
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__divti3+0x2d0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91194084 	add	x4, x4, #0x650
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__divti3+0x2d0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91190084 	add	x4, x4, #0x640
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3fa8:	91174042 	add	x2, x2, #0x5d0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__divti3+0x2d0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__divti3+0x2d0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	91196021 	add	x1, x1, #0x658
    4004:	91198000 	add	x0, x0, #0x660
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__divti3+0x2d0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911a0042 	add	x2, x2, #0x680
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    410c:	91134061 	add	x1, x3, #0x4d0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    411c:	91174262 	add	x2, x19, #0x5d0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xbb0>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    414c:	91144021 	add	x1, x1, #0x510
    4150:	3dc08843 	ldr	q3, [x2, #544]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    417c:	91134063 	add	x3, x3, #0x4d0
    4180:	9115c084 	add	x4, x4, #0x570
    4184:	91174266 	add	x6, x19, #0x5d0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91174275 	add	x21, x19, #0x5d0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    4268:	911cc000 	add	x0, x0, #0x730
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91174273 	add	x19, x19, #0x5d0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	9101c122 	add	x2, x9, #0x70
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9403c46 	ldr	x6, [x2, #120]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	9101c120 	add	x0, x9, #0x70
    4354:	f900400b 	str	x11, [x0, #128]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	9101c129 	add	x9, x9, #0x70
    4360:	f9003d26 	str	x6, [x9, #120]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <fwp_tape_buffers_release>:
    4380:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4384:	910003fd 	mov	x29, sp
    4388:	a90153f3 	stp	x19, x20, [sp, #16]
    438c:	aa0003f3 	mov	x19, x0
    4390:	f9401400 	ldr	x0, [x0, #40]
    4394:	b7f80760 	tbnz	x0, #63, 4480 <fwp_tape_buffers_release+0x100>
    4398:	f9401a61 	ldr	x1, [x19, #48]
    439c:	b7f80301 	tbnz	x1, #63, 43fc <fwp_tape_buffers_release+0x7c>
    43a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43a4:	eb02001f 	cmp	x0, x2
    43a8:	540002a8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43ac:	8b000400 	add	x0, x0, x0, lsl #1
    43b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    43b4:	d37df000 	lsl	x0, x0, #3
    43b8:	cb000042 	sub	x2, x2, x0
    43bc:	eb420c3f 	cmp	x1, x2, lsr #3
    43c0:	540001e8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43c4:	8b010c14 	add	x20, x0, x1, lsl #3
    43c8:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    43cc:	911d0000 	add	x0, x0, #0x740
    43d0:	97fff990 	bl	2a10 <getenv@plt>
    43d4:	b4000240 	cbz	x0, 441c <fwp_tape_buffers_release+0x9c>
    43d8:	39400001 	ldrb	w1, [x0]
    43dc:	7100c03f 	cmp	w1, #0x30
    43e0:	540001e1 	b.ne	441c <fwp_tape_buffers_release+0x9c>  // b.any
    43e4:	39400400 	ldrb	w0, [x0, #1]
    43e8:	350001a0 	cbnz	w0, 441c <fwp_tape_buffers_release+0x9c>
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f8:	17fffc22 	b	3480 <fwp_tape_buffers_dispose>
    43fc:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    4400:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4404:	911d0000 	add	x0, x0, #0x740
    4408:	97fff982 	bl	2a10 <getenv@plt>
    440c:	b4ffff00 	cbz	x0, 43ec <fwp_tape_buffers_release+0x6c>
    4410:	39400001 	ldrb	w1, [x0]
    4414:	7100c03f 	cmp	w1, #0x30
    4418:	54fffe60 	b.eq	43e4 <fwp_tape_buffers_release+0x64>  // b.none
    441c:	d1000681 	sub	x1, x20, #0x1
    4420:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4424:	eb00003f 	cmp	x1, x0
    4428:	54fffe28 	b.hi	43ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    442c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4430:	900000f6 	adrp	x22, 20000 <__data_start>
    4434:	9101c2d6 	add	x22, x22, #0x70
    4438:	910262d5 	add	x21, x22, #0x98
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fffc10 	bl	3480 <fwp_tape_buffers_dispose>
    4444:	ad400a61 	ldp	q1, q2, [x19]
    4448:	f9006ad4 	str	x20, [x22, #208]
    444c:	4f000400 	movi	v0.4s, #0x0
    4450:	ad000aa1 	stp	q1, q2, [x21]
    4454:	3dc00a61 	ldr	q1, [x19, #32]
    4458:	3d800aa1 	str	q1, [x21, #32]
    445c:	f9401a60 	ldr	x0, [x19, #48]
    4460:	f9001aa0 	str	x0, [x21, #48]
    4464:	f9001a7f 	str	xzr, [x19, #48]
    4468:	ad000260 	stp	q0, q0, [x19]
    446c:	3d800a60 	str	q0, [x19, #32]
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4478:	a8c37bfd 	ldp	x29, x30, [sp], #48
    447c:	d65f03c0 	ret
    4480:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    4484:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4488:	911d0000 	add	x0, x0, #0x740
    448c:	97fff961 	bl	2a10 <getenv@plt>
    4490:	b5fffa40 	cbnz	x0, 43d8 <fwp_tape_buffers_release+0x58>
    4494:	17ffffd6 	b	43ec <fwp_tape_buffers_release+0x6c>
    4498:	d503201f 	nop
    449c:	d503201f 	nop

00000000000044a0 <fwp_poll_events>:
    44a0:	d10103ff 	sub	sp, sp, #0x40
    44a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44a8:	f947f400 	ldr	x0, [x0, #4072]
    44ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    44b0:	910083fd 	add	x29, sp, #0x20
    44b4:	a90353f3 	stp	x19, x20, [sp, #48]
    44b8:	900000f4 	adrp	x20, 20000 <__data_start>
    44bc:	f9400001 	ldr	x1, [x0]
    44c0:	f9000fe1 	str	x1, [sp, #24]
    44c4:	d2800001 	mov	x1, #0x0                   	// #0
    44c8:	97fffd2e 	bl	3980 <fwp_now_ns>
    44cc:	9101c281 	add	x1, x20, #0x70
    44d0:	f9406c33 	ldr	x19, [x1, #216]
    44d4:	b4000e93 	cbz	x19, 46a4 <fwp_poll_events+0x204>
    44d8:	aa1303e1 	mov	x1, x19
    44dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    44e0:	14000005 	b	44f4 <fwp_poll_events+0x54>
    44e4:	f9408821 	ldr	x1, [x1, #272]
    44e8:	eb03005f 	cmp	x2, x3
    44ec:	9a83d042 	csel	x2, x2, x3, le
    44f0:	b40000c1 	cbz	x1, 4508 <fwp_poll_events+0x68>
    44f4:	f9403423 	ldr	x3, [x1, #104]
    44f8:	b6ffff62 	tbz	x2, #63, 44e4 <fwp_poll_events+0x44>
    44fc:	f9408821 	ldr	x1, [x1, #272]
    4500:	aa0303e2 	mov	x2, x3
    4504:	b5ffff81 	cbnz	x1, 44f4 <fwp_poll_events+0x54>
    4508:	b7f80ce2 	tbnz	x2, #63, 46a4 <fwp_poll_events+0x204>
    450c:	cb000042 	sub	x2, x2, x0
    4510:	f100005f 	cmp	x2, #0x0
    4514:	540005cd 	b.le	45cc <fwp_poll_events+0x12c>
    4518:	d2869b60 	mov	x0, #0x34db                	// #13531
    451c:	d2884801 	mov	x1, #0x4240                	// #16960
    4520:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4524:	f2a001e1 	movk	x1, #0xf, lsl #16
    4528:	f2dbd040 	movk	x0, #0xde82, lsl #32
    452c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4530:	f2e86360 	movk	x0, #0x431b, lsl #48
    4534:	9b407c40 	smulh	x0, x2, x0
    4538:	9352fc00 	asr	x0, x0, #18
    453c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4540:	9b018802 	msub	x2, x0, x1, x2
    4544:	f100005f 	cmp	x2, #0x0
    4548:	9a800400 	cinc	x0, x0, ne	// ne = any
    454c:	eb03001f 	cmp	x0, x3
    4550:	54000a0c 	b.gt	4690 <fwp_poll_events+0x1f0>
    4554:	340003c0 	cbz	w0, 45cc <fwp_poll_events+0x12c>
    4558:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    455c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4560:	72a20c42 	movk	w2, #0x1062, lsl #16
    4564:	9ba27c02 	umull	x2, w0, w2
    4568:	d366fc43 	lsr	x3, x2, #38
    456c:	aa0303e2 	mov	x2, x3
    4570:	1b048063 	msub	w3, w3, w4, w0
    4574:	9b217c63 	smull	x3, w3, w1
    4578:	d2800001 	mov	x1, #0x0                   	// #0
    457c:	910023e0 	add	x0, sp, #0x8
    4580:	a9008fe2 	stp	x2, x3, [sp, #8]
    4584:	97fff8f3 	bl	2950 <nanosleep@plt>
    4588:	9101c280 	add	x0, x20, #0x70
    458c:	f9406c13 	ldr	x19, [x0, #216]
    4590:	97fffcfc 	bl	3980 <fwp_now_ns>
    4594:	aa0003e6 	mov	x6, x0
    4598:	b50001f3 	cbnz	x19, 45d4 <fwp_poll_events+0x134>
    459c:	d503201f 	nop
    45a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45a4:	f947f400 	ldr	x0, [x0, #4072]
    45a8:	f9400fe2 	ldr	x2, [sp, #24]
    45ac:	f9400001 	ldr	x1, [x0]
    45b0:	eb010042 	subs	x2, x2, x1
    45b4:	d2800001 	mov	x1, #0x0                   	// #0
    45b8:	540008c1 	b.ne	46d0 <fwp_poll_events+0x230>  // b.any
    45bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    45c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    45c4:	910103ff 	add	sp, sp, #0x40
    45c8:	d65f03c0 	ret
    45cc:	97fffced 	bl	3980 <fwp_now_ns>
    45d0:	aa0003e6 	mov	x6, x0
    45d4:	4f000400 	movi	v0.4s, #0x0
    45d8:	9101c288 	add	x8, x20, #0x70
    45dc:	52800027 	mov	w7, #0x1                   	// #1
    45e0:	f9403661 	ldr	x1, [x19, #104]
    45e4:	aa1303e5 	mov	x5, x19
    45e8:	f9408a73 	ldr	x19, [x19, #272]
    45ec:	eb06003f 	cmp	x1, x6
    45f0:	5400032c 	b.gt	4654 <fwp_poll_events+0x1b4>
    45f4:	394154a0 	ldrb	w0, [x5, #85]
    45f8:	36000120 	tbz	w0, #0, 461c <fwp_poll_events+0x17c>
    45fc:	f94084a0 	ldr	x0, [x5, #264]
    4600:	b40003c0 	cbz	x0, 4678 <fwp_poll_events+0x1d8>
    4604:	f9008813 	str	x19, [x0, #272]
    4608:	b4000053 	cbz	x19, 4610 <fwp_poll_events+0x170>
    460c:	f9008660 	str	x0, [x19, #264]
    4610:	910800a0 	add	x0, x5, #0x200
    4614:	390154bf 	strb	wzr, [x5, #85]
    4618:	3c908000 	stur	q0, [x0, #-248]
    461c:	f94030a0 	ldr	x0, [x5, #96]
    4620:	390158a7 	strb	w7, [x5, #86]
    4624:	f100001f 	cmp	x0, #0x0
    4628:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    462c:	5400018d 	b.le	465c <fwp_poll_events+0x1bc>
    4630:	f94028a0 	ldr	x0, [x5, #80]
    4634:	f2001c1f 	tst	x0, #0xff000000ff
    4638:	540000e1 	b.ne	4654 <fwp_poll_events+0x1b4>  // b.any
    463c:	f9403d00 	ldr	x0, [x8, #120]
    4640:	390150a7 	strb	w7, [x5, #84]
    4644:	f90080bf 	str	xzr, [x5, #256]
    4648:	b40001e0 	cbz	x0, 4684 <fwp_poll_events+0x1e4>
    464c:	f9003d05 	str	x5, [x8, #120]
    4650:	f9008005 	str	x5, [x0, #256]
    4654:	b5fffc73 	cbnz	x19, 45e0 <fwp_poll_events+0x140>
    4658:	17ffffd2 	b	45a0 <fwp_poll_events+0x100>
    465c:	394144a0 	ldrb	w0, [x5, #81]
    4660:	3707fe80 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    4664:	394140a0 	ldrb	w0, [x5, #80]
    4668:	3707fe40 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    466c:	aa0503e0 	mov	x0, x5
    4670:	97fffc20 	bl	36f0 <fwp_cancel_tree.part.0>
    4674:	17ffffef 	b	4630 <fwp_poll_events+0x190>
    4678:	9101c281 	add	x1, x20, #0x70
    467c:	f9006c33 	str	x19, [x1, #216]
    4680:	17ffffe2 	b	4608 <fwp_poll_events+0x168>
    4684:	f9003d05 	str	x5, [x8, #120]
    4688:	f9004105 	str	x5, [x8, #128]
    468c:	17fffff2 	b	4654 <fwp_poll_events+0x1b4>
    4690:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4694:	d2989362 	mov	x2, #0xc49b                	// #50331
    4698:	f2a4d203 	movk	x3, #0x2690, lsl #16
    469c:	f2a00402 	movk	x2, #0x20, lsl #16
    46a0:	17ffffb6 	b	4578 <fwp_poll_events+0xd8>
    46a4:	97fffa53 	bl	2ff0 <fwp_flush>
    46a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46ac:	f947e863 	ldr	x3, [x3, #4048]
    46b0:	d2800562 	mov	x2, #0x2b                  	// #43
    46b4:	d2800021 	mov	x1, #0x1                   	// #1
    46b8:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    46bc:	911d6000 	add	x0, x0, #0x758
    46c0:	f9400063 	ldr	x3, [x3]
    46c4:	97fff8af 	bl	2980 <fwrite@plt>
    46c8:	52800ca0 	mov	w0, #0x65                  	// #101
    46cc:	97fff819 	bl	2730 <exit@plt>
    46d0:	97fff86c 	bl	2880 <__stack_chk_fail@plt>

00000000000046d4 <fwp_rc_wide_dup>:
    46d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    46d8:	910003fd 	mov	x29, sp
    46dc:	a90153f3 	stp	x19, x20, [sp, #16]
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	ca404400 	eor	x0, x0, x0, lsr #17
    46e8:	f90013f5 	str	x21, [sp, #32]
    46ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    46f0:	ca402400 	eor	x0, x0, x0, lsr #9
    46f4:	911742a2 	add	x2, x21, #0x5d0
    46f8:	92401c00 	and	x0, x0, #0xff
    46fc:	910a2403 	add	x3, x0, #0x289
    4700:	8b000c40 	add	x0, x2, x0, lsl #3
    4704:	8b030c54 	add	x20, x2, x3, lsl #3
    4708:	f94a2401 	ldr	x1, [x0, #5192]
    470c:	b50000a1 	cbnz	x1, 4720 <fwp_rc_wide_dup+0x4c>
    4710:	1400002d 	b	47c4 <fwp_rc_wide_dup+0xf0>
    4714:	91004034 	add	x20, x1, #0x10
    4718:	f9400821 	ldr	x1, [x1, #16]
    471c:	b4000241 	cbz	x1, 4764 <fwp_rc_wide_dup+0x90>
    4720:	f9400022 	ldr	x2, [x1]
    4724:	eb02027f 	cmp	x19, x2
    4728:	54ffff61 	b.ne	4714 <fwp_rc_wide_dup+0x40>  // b.any
    472c:	f9400281 	ldr	x1, [x20]
    4730:	39400260 	ldrb	w0, [x19]
    4734:	7103f81f 	cmp	w0, #0xfe
    4738:	54000220 	b.eq	477c <fwp_rc_wide_dup+0xa8>  // b.none
    473c:	b40001a1 	cbz	x1, 4770 <fwp_rc_wide_dup+0x9c>
    4740:	f9400420 	ldr	x0, [x1, #8]
    4744:	b100041f 	cmn	x0, #0x1
    4748:	540004a0 	b.eq	47dc <fwp_rc_wide_dup+0x108>  // b.none
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f9000420 	str	x0, [x1, #8]
    4754:	a94153f3 	ldp	x19, x20, [sp, #16]
    4758:	f94013f5 	ldr	x21, [sp, #32]
    475c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4760:	d65f03c0 	ret
    4764:	39400260 	ldrb	w0, [x19]
    4768:	7103f81f 	cmp	w0, #0xfe
    476c:	540000a0 	b.eq	4780 <fwp_rc_wide_dup+0xac>  // b.none
    4770:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    4774:	911ec000 	add	x0, x0, #0x7b0
    4778:	97fffc22 	bl	3800 <fwp_trap>
    477c:	b5000281 	cbnz	x1, 47cc <fwp_rc_wide_dup+0xf8>
    4780:	d2800300 	mov	x0, #0x18                  	// #24
    4784:	97fff827 	bl	2820 <malloc@plt>
    4788:	b4000280 	cbz	x0, 47d8 <fwp_rc_wide_dup+0x104>
    478c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4790:	a9000413 	stp	x19, x1, [x0]
    4794:	911742b5 	add	x21, x21, #0x5d0
    4798:	f900081f 	str	xzr, [x0, #16]
    479c:	12800001 	mov	w1, #0xffffffff            	// #-1
    47a0:	f9000280 	str	x0, [x20]
    47a4:	39000261 	strb	w1, [x19]
    47a8:	f94e26a0 	ldr	x0, [x21, #7240]
    47ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b0:	91000400 	add	x0, x0, #0x1
    47b4:	f90e26a0 	str	x0, [x21, #7240]
    47b8:	f94013f5 	ldr	x21, [sp, #32]
    47bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47c0:	d65f03c0 	ret
    47c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    47c8:	17ffffda 	b	4730 <fwp_rc_wide_dup+0x5c>
    47cc:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    47d0:	911e2000 	add	x0, x0, #0x788
    47d4:	97fffc0b 	bl	3800 <fwp_trap>
    47d8:	97fffa16 	bl	3030 <fwp_heap_oom>
    47dc:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    47e0:	911f6000 	add	x0, x0, #0x7d8
    47e4:	97fffc07 	bl	3800 <fwp_trap>
    47e8:	d503201f 	nop
    47ec:	d503201f 	nop

00000000000047f0 <fwp_rc_forget_slot>:
    47f0:	aa0003e1 	mov	x1, x0
    47f4:	39400000 	ldrb	w0, [x0]
    47f8:	7103fc1f 	cmp	w0, #0xff
    47fc:	54000040 	b.eq	4804 <fwp_rc_forget_slot+0x14>  // b.none
    4800:	d65f03c0 	ret
    4804:	ca414420 	eor	x0, x1, x1, lsr #17
    4808:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    480c:	ca402400 	eor	x0, x0, x0, lsr #9
    4810:	910003fd 	mov	x29, sp
    4814:	92401c00 	and	x0, x0, #0xff
    4818:	f9000bf3 	str	x19, [sp, #16]
    481c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4820:	91174262 	add	x2, x19, #0x5d0
    4824:	910a2403 	add	x3, x0, #0x289
    4828:	8b000c40 	add	x0, x2, x0, lsl #3
    482c:	8b030c43 	add	x3, x2, x3, lsl #3
    4830:	f94a2400 	ldr	x0, [x0, #5192]
    4834:	b50000a0 	cbnz	x0, 4848 <fwp_rc_forget_slot+0x58>
    4838:	14000011 	b	487c <fwp_rc_forget_slot+0x8c>
    483c:	91004003 	add	x3, x0, #0x10
    4840:	f9400800 	ldr	x0, [x0, #16]
    4844:	b40001c0 	cbz	x0, 487c <fwp_rc_forget_slot+0x8c>
    4848:	f9400002 	ldr	x2, [x0]
    484c:	eb02003f 	cmp	x1, x2
    4850:	54ffff61 	b.ne	483c <fwp_rc_forget_slot+0x4c>  // b.any
    4854:	f9400801 	ldr	x1, [x0, #16]
    4858:	91174273 	add	x19, x19, #0x5d0
    485c:	f9000061 	str	x1, [x3]
    4860:	97fff838 	bl	2940 <free@plt>
    4864:	f94e2660 	ldr	x0, [x19, #7240]
    4868:	d1000400 	sub	x0, x0, #0x1
    486c:	f90e2660 	str	x0, [x19, #7240]
    4870:	f9400bf3 	ldr	x19, [sp, #16]
    4874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4878:	d65f03c0 	ret
    487c:	b0000040 	adrp	x0, d000 <__divti3+0x2d0>
    4880:	911ec000 	add	x0, x0, #0x7b0
    4884:	97fffbdf 	bl	3800 <fwp_trap>
    4888:	d503201f 	nop
    488c:	d503201f 	nop

0000000000004890 <fwp_rc_prepare_chunk>:
    4890:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4894:	910003fd 	mov	x29, sp
    4898:	a9025bf5 	stp	x21, x22, [sp, #32]
    489c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    48a0:	911742c2 	add	x2, x22, #0x5d0
    48a4:	b9401c03 	ldr	w3, [x0, #28]
    48a8:	aa0103f5 	mov	x21, x1
    48ac:	a90153f3 	stp	x19, x20, [sp, #16]
    48b0:	aa0003f4 	mov	x20, x0
    48b4:	f94e2440 	ldr	x0, [x2, #7240]
    48b8:	b4000440 	cbz	x0, 4940 <fwp_rc_prepare_chunk+0xb0>
    48bc:	d2800013 	mov	x19, #0x0                   	// #0
    48c0:	35000203 	cbnz	w3, 4900 <fwp_rc_prepare_chunk+0x70>
    48c4:	b4000361 	cbz	x1, 4930 <fwp_rc_prepare_chunk+0xa0>
    48c8:	f9401280 	ldr	x0, [x20, #32]
    48cc:	97fff81d 	bl	2940 <free@plt>
    48d0:	aa1503e0 	mov	x0, x21
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	97fff7e2 	bl	2860 <calloc@plt>
    48dc:	f9001280 	str	x0, [x20, #32]
    48e0:	b5000460 	cbnz	x0, 496c <fwp_rc_prepare_chunk+0xdc>
    48e4:	97fff9d3 	bl	3030 <fwp_heap_oom>
    48e8:	97ffffc2 	bl	47f0 <fwp_rc_forget_slot>
    48ec:	91000673 	add	x19, x19, #0x1
    48f0:	b9401e83 	ldr	w3, [x20, #28]
    48f4:	eb13007f 	cmp	x3, x19
    48f8:	54000169 	b.ls	4924 <fwp_rc_prepare_chunk+0x94>  // b.plast
    48fc:	d503201f 	nop
    4900:	f9401283 	ldr	x3, [x20, #32]
    4904:	8b130060 	add	x0, x3, x19
    4908:	38736863 	ldrb	w3, [x3, x19]
    490c:	7103fc7f 	cmp	w3, #0xff
    4910:	54fffec0 	b.eq	48e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4914:	b9401e83 	ldr	w3, [x20, #28]
    4918:	91000673 	add	x19, x19, #0x1
    491c:	eb13007f 	cmp	x3, x19
    4920:	54ffff08 	b.hi	4900 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4924:	eb0302bf 	cmp	x21, x3
    4928:	54000121 	b.ne	494c <fwp_rc_prepare_chunk+0xbc>  // b.any
    492c:	b5000335 	cbnz	x21, 4990 <fwp_rc_prepare_chunk+0x100>
    4930:	a94153f3 	ldp	x19, x20, [sp, #16]
    4934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    493c:	d65f03c0 	ret
    4940:	2a0303e3 	mov	w3, w3
    4944:	eb0302bf 	cmp	x21, x3
    4948:	54ffff20 	b.eq	492c <fwp_rc_prepare_chunk+0x9c>  // b.none
    494c:	911742c2 	add	x2, x22, #0x5d0
    4950:	f9401280 	ldr	x0, [x20, #32]
    4954:	f94e2841 	ldr	x1, [x2, #7248]
    4958:	cb030021 	sub	x1, x1, x3
    495c:	f90e2841 	str	x1, [x2, #7248]
    4960:	97fff7f8 	bl	2940 <free@plt>
    4964:	b5fffb75 	cbnz	x21, 48d0 <fwp_rc_prepare_chunk+0x40>
    4968:	f900129f 	str	xzr, [x20, #32]
    496c:	911742d6 	add	x22, x22, #0x5d0
    4970:	f94e2ac0 	ldr	x0, [x22, #7248]
    4974:	b9001e95 	str	w21, [x20, #28]
    4978:	a94153f3 	ldp	x19, x20, [sp, #16]
    497c:	8b150000 	add	x0, x0, x21
    4980:	f90e2ac0 	str	x0, [x22, #7248]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	f9401280 	ldr	x0, [x20, #32]
    4994:	aa1503e2 	mov	x2, x21
    4998:	a94153f3 	ldp	x19, x20, [sp, #16]
    499c:	52800001 	mov	w1, #0x0                   	// #0
    49a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49a8:	17fff7aa 	b	2850 <memset@plt>
    49ac:	d503201f 	nop

00000000000049b0 <fwp_heap_refill>:
    49b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49b4:	910003fd 	mov	x29, sp
    49b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    49bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    49c0:	911742b5 	add	x21, x21, #0x5d0
    49c4:	aa0003f6 	mov	x22, x0
    49c8:	d2800020 	mov	x0, #0x1                   	// #1
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a90363f7 	stp	x23, x24, [sp, #48]
    49d4:	2a0103f7 	mov	w23, w1
    49d8:	2a0203f8 	mov	w24, w2
    49dc:	97fffa35 	bl	32b0 <fwp_heap_chunks>
    49e0:	aa0003f3 	mov	x19, x0
    49e4:	f949fea2 	ldr	x2, [x21, #5112]
    49e8:	8b000800 	add	x0, x0, x0, lsl #2
    49ec:	2a1703e1 	mov	w1, w23
    49f0:	52800025 	mov	w5, #0x1                   	// #1
    49f4:	d37df000 	lsl	x0, x0, #3
    49f8:	910f0021 	add	x1, x1, #0x3c0
    49fc:	8b000054 	add	x20, x2, x0
    4a00:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a04:	52a00024 	mov	w4, #0x10000               	// #65536
    4a08:	38206845 	strb	w5, [x2, x0]
    4a0c:	aa1403e0 	mov	x0, x20
    4a10:	39000698 	strb	w24, [x20, #1]
    4a14:	39000a97 	strb	w23, [x20, #2]
    4a18:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a1c:	b9000681 	str	w1, [x20, #4]
    4a20:	2a0103e5 	mov	w5, w1
    4a24:	8b0300a2 	add	x2, x5, x3
    4a28:	1ac10881 	udiv	w1, w4, w1
    4a2c:	9ac50842 	udiv	x2, x2, x5
    4a30:	b9000a81 	str	w1, [x20, #8]
    4a34:	92404021 	and	x1, x1, #0x1ffff
    4a38:	b9001a82 	str	w2, [x20, #24]
    4a3c:	97ffff95 	bl	4890 <fwp_rc_prepare_chunk>
    4a40:	f949daa0 	ldr	x0, [x21, #5040]
    4a44:	29408a81 	ldp	w1, w2, [x20, #4]
    4a48:	8b134000 	add	x0, x0, x19, lsl #16
    4a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a50:	8b214003 	add	x3, x0, w1, uxtw
    4a54:	9ba20021 	umaddl	x1, w1, w2, x0
    4a58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a5c:	a90086c3 	stp	x3, x1, [x22, #8]
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a68:	d65f03c0 	ret
    4a6c:	d503201f 	nop

0000000000004a70 <fwp_mem_free>:
    4a70:	b40003c0 	cbz	x0, 4ae8 <fwp_mem_free+0x78>
    4a74:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a80:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a84:	911742a1 	add	x1, x21, #0x5d0
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	aa0003f3 	mov	x19, x0
    4a90:	f949d823 	ldr	x3, [x1, #5040]
    4a94:	f949ec22 	ldr	x2, [x1, #5080]
    4a98:	cb030000 	sub	x0, x0, x3
    4a9c:	eb02401f 	cmp	x0, x2, lsl #16
    4aa0:	540001c2 	b.cs	4ad8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4aa4:	d350fc16 	lsr	x22, x0, #16
    4aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    4aac:	f949fc22 	ldr	x2, [x1, #5112]
    4ab0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ab4:	d37df294 	lsl	x20, x20, #3
    4ab8:	ab140057 	adds	x23, x2, x20
    4abc:	540000c0 	b.eq	4ad4 <fwp_mem_free+0x64>  // b.none
    4ac0:	38746842 	ldrb	w2, [x2, x20]
    4ac4:	7100045f 	cmp	w2, #0x1
    4ac8:	54000120 	b.eq	4aec <fwp_mem_free+0x7c>  // b.none
    4acc:	7100085f 	cmp	w2, #0x2
    4ad0:	540005e0 	b.eq	4b8c <fwp_mem_free+0x11c>  // b.none
    4ad4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ae4:	d65f03c0 	ret
    4ae8:	d65f03c0 	ret
    4aec:	f94012f8 	ldr	x24, [x23, #32]
    4af0:	b94006e1 	ldr	w1, [x23, #4]
    4af4:	f90023f9 	str	x25, [sp, #64]
    4af8:	2a0103e2 	mov	w2, w1
    4afc:	394006f9 	ldrb	w25, [x23, #1]
    4b00:	39400af4 	ldrb	w20, [x23, #2]
    4b04:	b4000158 	cbz	x24, 4b2c <fwp_mem_free+0xbc>
    4b08:	92403e76 	and	x22, x19, #0xffff
    4b0c:	9ac20ad6 	udiv	x22, x22, x2
    4b10:	38766b01 	ldrb	w1, [x24, x22]
    4b14:	8b160300 	add	x0, x24, x22
    4b18:	7103fc3f 	cmp	w1, #0xff
    4b1c:	54000980 	b.eq	4c4c <fwp_mem_free+0x1dc>  // b.none
    4b20:	38366b1f 	strb	wzr, [x24, x22]
    4b24:	b94006e1 	ldr	w1, [x23, #4]
    4b28:	2a0103e2 	mov	w2, w1
    4b2c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b30:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b34:	cb390000 	sub	x0, x0, w25, uxtb
    4b38:	8b340074 	add	x20, x3, w20, uxtb
    4b3c:	911742b5 	add	x21, x21, #0x5d0
    4b40:	1e630021 	ucvtf	d1, w1
    4b44:	d37ae400 	lsl	x0, x0, #6
    4b48:	8b140c14 	add	x20, x0, x20, lsl #3
    4b4c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b50:	f8746aa0 	ldr	x0, [x21, x20]
    4b54:	f94023f9 	ldr	x25, [sp, #64]
    4b58:	aa2003e0 	mvn	x0, x0
    4b5c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4b60:	f9000260 	str	x0, [x19]
    4b64:	f8346ab3 	str	x19, [x21, x20]
    4b68:	f94a12a0 	ldr	x0, [x21, #5152]
    4b6c:	1e612800 	fadd	d0, d0, d1
    4b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b74:	cb020000 	sub	x0, x0, x2
    4b78:	f90a12a0 	str	x0, [x21, #5152]
    4b7c:	fd0a22a0 	str	d0, [x21, #5184]
    4b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b84:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b88:	d65f03c0 	ret
    4b8c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4b90:	8b000063 	add	x3, x3, x0
    4b94:	eb03027f 	cmp	x19, x3
    4b98:	54fff9e1 	b.ne	4ad4 <fwp_mem_free+0x64>  // b.any
    4b9c:	fd400ae1 	ldr	d1, [x23, #16]
    4ba0:	fd4a2020 	ldr	d0, [x1, #5184]
    4ba4:	f9400ae0 	ldr	x0, [x23, #16]
    4ba8:	7e61d821 	ucvtf	d1, d1
    4bac:	f94a1022 	ldr	x2, [x1, #5152]
    4bb0:	f94012f3 	ldr	x19, [x23, #32]
    4bb4:	1e612800 	fadd	d0, d0, d1
    4bb8:	cb000042 	sub	x2, x2, x0
    4bbc:	f90a1022 	str	x2, [x1, #5152]
    4bc0:	fd0a2020 	str	d0, [x1, #5184]
    4bc4:	b40000b3 	cbz	x19, 4bd8 <fwp_mem_free+0x168>
    4bc8:	39400260 	ldrb	w0, [x19]
    4bcc:	7103fc1f 	cmp	w0, #0xff
    4bd0:	54000380 	b.eq	4c40 <fwp_mem_free+0x1d0>  // b.none
    4bd4:	3900027f 	strb	wzr, [x19]
    4bd8:	b9400ee2 	ldr	w2, [x23, #12]
    4bdc:	b4000142 	cbz	x2, 4c04 <fwp_mem_free+0x194>
    4be0:	911742a1 	add	x1, x21, #0x5d0
    4be4:	8b160040 	add	x0, x2, x22
    4be8:	8b000800 	add	x0, x0, x0, lsl #2
    4bec:	f949fc21 	ldr	x1, [x1, #5112]
    4bf0:	8b140034 	add	x20, x1, x20
    4bf4:	8b000c20 	add	x0, x1, x0, lsl #3
    4bf8:	3802869f 	strb	wzr, [x20], #40
    4bfc:	eb00029f 	cmp	x20, x0
    4c00:	54ffffc1 	b.ne	4bf8 <fwp_mem_free+0x188>  // b.any
    4c04:	911742a0 	add	x0, x21, #0x5d0
    4c08:	f94a1801 	ldr	x1, [x0, #5168]
    4c0c:	f949f803 	ldr	x3, [x0, #5104]
    4c10:	8b020021 	add	x1, x1, x2
    4c14:	f90a1801 	str	x1, [x0, #5168]
    4c18:	eb16007f 	cmp	x3, x22
    4c1c:	54000049 	b.ls	4c24 <fwp_mem_free+0x1b4>  // b.plast
    4c20:	f909f816 	str	x22, [x0, #5104]
    4c24:	911742b5 	add	x21, x21, #0x5d0
    4c28:	f949f6a0 	ldr	x0, [x21, #5096]
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54fff529 	b.ls	4ad4 <fwp_mem_free+0x64>  // b.plast
    4c34:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c38:	f909f6b6 	str	x22, [x21, #5096]
    4c3c:	17ffffa7 	b	4ad8 <fwp_mem_free+0x68>
    4c40:	aa1303e0 	mov	x0, x19
    4c44:	97fffeeb 	bl	47f0 <fwp_rc_forget_slot>
    4c48:	17ffffe3 	b	4bd4 <fwp_mem_free+0x164>
    4c4c:	97fffee9 	bl	47f0 <fwp_rc_forget_slot>
    4c50:	17ffffb4 	b	4b20 <fwp_mem_free+0xb0>

0000000000004c54 <fwp_heap_alloc_big>:
    4c54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c58:	910003fd 	mov	x29, sp
    4c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c60:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c64:	a90363f7 	stp	x23, x24, [sp, #48]
    4c68:	aa0003f7 	mov	x23, x0
    4c6c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c70:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c74:	eb0002ff 	cmp	x23, x0
    4c78:	54000888 	b.hi	4d88 <fwp_heap_alloc_big+0x134>  // b.pmore
    4c7c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c80:	8b0002f4 	add	x20, x23, x0
    4c84:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c88:	91174359 	add	x25, x26, #0x5d0
    4c8c:	d350fe94 	lsr	x20, x20, #16
    4c90:	2a0103f5 	mov	w21, w1
    4c94:	aa1403e0 	mov	x0, x20
    4c98:	97fff986 	bl	32b0 <fwp_heap_chunks>
    4c9c:	f949ff22 	ldr	x2, [x25, #5112]
    4ca0:	8b000813 	add	x19, x0, x0, lsl #2
    4ca4:	aa0003f8 	mov	x24, x0
    4ca8:	52800043 	mov	w3, #0x2                   	// #2
    4cac:	d37df273 	lsl	x19, x19, #3
    4cb0:	d2800021 	mov	x1, #0x1                   	// #1
    4cb4:	8b130040 	add	x0, x2, x19
    4cb8:	38336843 	strb	w3, [x2, x19]
    4cbc:	39000415 	strb	w21, [x0, #1]
    4cc0:	b9000c14 	str	w20, [x0, #12]
    4cc4:	f9000817 	str	x23, [x0, #16]
    4cc8:	97fffef2 	bl	4890 <fwp_rc_prepare_chunk>
    4ccc:	f100069f 	cmp	x20, #0x1
    4cd0:	54000269 	b.ls	4d1c <fwp_heap_alloc_big+0xc8>  // b.plast
    4cd4:	8b180294 	add	x20, x20, x24
    4cd8:	9100a273 	add	x19, x19, #0x28
    4cdc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ce0:	5280007b 	mov	w27, #0x3                   	// #3
    4ce4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce8:	2a1803fc 	mov	w28, w24
    4cec:	9adb2296 	lsl	x22, x20, x27
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffee4 	bl	4890 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0x9c>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x104>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffca4 	bl	4104 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff70 	b	4c54 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffeb5 	bl	49b0 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94046e0 	ldr	x0, [x23, #136]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_p_ad_push.constprop.0>:
    5224:	f100001f 	cmp	x0, #0x0
    5228:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    522c:	54000e8b 	b.lt	53fc <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    5230:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5234:	aa0003e4 	mov	x4, x0
    5238:	910003fd 	mov	x29, sp
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	aa0003f5 	mov	x21, x0
    5244:	aa020000 	orr	x0, x0, x2
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	aa0203f7 	mov	x23, x2
    5250:	6d0627e8 	stp	d8, d9, [sp, #96]
    5254:	9e670029 	fmov	d9, x1
    5258:	9e670068 	fmov	d8, x3
    525c:	b6f80900 	tbz	x0, #63, 537c <fwp_p_ad_push.constprop.0+0x158>
    5260:	a90153f3 	stp	x19, x20, [sp, #16]
    5264:	9360fc80 	asr	x0, x4, #32
    5268:	b6f800c4 	tbz	x4, #63, 5280 <fwp_p_ad_push.constprop.0+0x5c>
    526c:	1e604109 	fmov	d9, d8
    5270:	2f00e408 	movi	d8, #0x0
    5274:	9360fc40 	asr	x0, x2, #32
    5278:	aa0203f5 	mov	x21, x2
    527c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5280:	97fffa2c 	bl	3b30 <fwp_tape_of>
    5284:	aa0003f3 	mov	x19, x0
    5288:	f9403000 	ldr	x0, [x0, #96]
    528c:	b5001280 	cbnz	x0, 54dc <fwp_p_ad_push.constprop.0+0x2b8>
    5290:	f9400a76 	ldr	x22, [x19, #16]
    5294:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5298:	eb0002df 	cmp	x22, x0
    529c:	54000e2c 	b.gt	5460 <fwp_p_ad_push.constprop.0+0x23c>
    52a0:	eb3542df 	cmp	x22, w21, uxtw
    52a4:	54000d4d 	b.le	544c <fwp_p_ad_push.constprop.0+0x228>
    52a8:	b7f80077 	tbnz	x23, #63, 52b4 <fwp_p_ad_push.constprop.0+0x90>
    52ac:	eb3742df 	cmp	x22, w23, uxtw
    52b0:	54000ced 	b.le	544c <fwp_p_ad_push.constprop.0+0x228>
    52b4:	f9400678 	ldr	x24, [x19, #8]
    52b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52bc:	cb1802d8 	sub	x24, x22, x24
    52c0:	91000701 	add	x1, x24, #0x1
    52c4:	eb00003f 	cmp	x1, x0
    52c8:	54000cc8 	b.hi	5460 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    52cc:	a9418274 	ldp	x20, x0, [x19, #24]
    52d0:	a90573fb 	stp	x27, x28, [sp, #80]
    52d4:	eb14003f 	cmp	x1, x20
    52d8:	5400068d 	b.le	53a8 <fwp_p_ad_push.constprop.0+0x184>
    52dc:	f100029f 	cmp	x20, #0x0
    52e0:	d2800803 	mov	x3, #0x40                  	// #64
    52e4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52e8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    52f0:	eb14003f 	cmp	x1, x20
    52f4:	5400008d 	b.le	5304 <fwp_p_ad_push.constprop.0+0xe0>
    52f8:	eb02029f 	cmp	x20, x2
    52fc:	5400052d 	b.le	53a0 <fwp_p_ad_push.constprop.0+0x17c>
    5300:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5304:	d37df299 	lsl	x25, x20, #3
    5308:	aa1903e1 	mov	x1, x25
    530c:	97fff559 	bl	2870 <realloc@plt>
    5310:	aa0003e1 	mov	x1, x0
    5314:	b4000b00 	cbz	x0, 5474 <fwp_p_ad_push.constprop.0+0x250>
    5318:	f9400e62 	ldr	x2, [x19, #24]
    531c:	f9001261 	str	x1, [x19, #32]
    5320:	f9401a60 	ldr	x0, [x19, #48]
    5324:	d37cee9a 	lsl	x26, x20, #4
    5328:	8b020821 	add	x1, x1, x2, lsl #2
    532c:	f9001661 	str	x1, [x19, #40]
    5330:	aa1a03e1 	mov	x1, x26
    5334:	97fff54f 	bl	2870 <realloc@plt>
    5338:	aa0003e2 	mov	x2, x0
    533c:	b40009c0 	cbz	x0, 5474 <fwp_p_ad_push.constprop.0+0x250>
    5340:	f9400e61 	ldr	x1, [x19, #24]
    5344:	d37df31b 	lsl	x27, x24, #3
    5348:	d37ef685 	lsl	x5, x20, #2
    534c:	d37ef71c 	lsl	x28, x24, #2
    5350:	8b190004 	add	x4, x0, x25
    5354:	8b010c01 	add	x1, x0, x1, lsl #3
    5358:	a9030660 	stp	x0, x1, [x19, #48]
    535c:	b5000558 	cbnz	x24, 5404 <fwp_p_ad_push.constprop.0+0x1e0>
    5360:	f9001e64 	str	x4, [x19, #56]
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	a9446bf9 	ldp	x25, x26, [sp, #64]
    536c:	8b050001 	add	x1, x0, x5
    5370:	f9000e74 	str	x20, [x19, #24]
    5374:	f9001661 	str	x1, [x19, #40]
    5378:	14000010 	b	53b8 <fwp_p_ad_push.constprop.0+0x194>
    537c:	9360fc40 	asr	x0, x2, #32
    5380:	a90153f3 	stp	x19, x20, [sp, #16]
    5384:	eb84801f 	cmp	x0, x4, asr #32
    5388:	54fff7c0 	b.eq	5280 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    538c:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    5390:	911fe000 	add	x0, x0, #0x7f8
    5394:	a9046bf9 	stp	x25, x26, [sp, #64]
    5398:	a90573fb 	stp	x27, x28, [sp, #80]
    539c:	97fff919 	bl	3800 <fwp_trap>
    53a0:	d37ffa94 	lsl	x20, x20, #1
    53a4:	17ffffd3 	b	52f0 <fwp_p_ad_push.constprop.0+0xcc>
    53a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    53ac:	d37ef71c 	lsl	x28, x24, #2
    53b0:	f9401e64 	ldr	x4, [x19, #56]
    53b4:	d37df31b 	lsl	x27, x24, #3
    53b8:	b83c6815 	str	w21, [x0, x28]
    53bc:	f10002ff 	cmp	x23, #0x0
    53c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    53c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    53c8:	fc3b6849 	str	d9, [x2, x27]
    53cc:	aa1602a0 	orr	x0, x21, x22
    53d0:	b83c6837 	str	w23, [x1, x28]
    53d4:	910006d6 	add	x22, x22, #0x1
    53d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53dc:	fc3b6888 	str	d8, [x4, x27]
    53e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53e8:	f9000a76 	str	x22, [x19, #16]
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53f8:	d65f03c0 	ret
    53fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5400:	d65f03c0 	ret
    5404:	eb1a033f 	cmp	x25, x26
    5408:	aa0403e0 	mov	x0, x4
    540c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5410:	aa1b03e2 	mov	x2, x27
    5414:	cb190063 	sub	x3, x3, x25
    5418:	f9003fe5 	str	x5, [sp, #120]
    541c:	97fff581 	bl	2a20 <__memmove_chk@plt>
    5420:	a9420660 	ldp	x0, x1, [x19, #32]
    5424:	aa1c03e2 	mov	x2, x28
    5428:	f9401a63 	ldr	x3, [x19, #48]
    542c:	f9403fe5 	ldr	x5, [sp, #120]
    5430:	8b190063 	add	x3, x3, x25
    5434:	f9001e63 	str	x3, [x19, #56]
    5438:	8b050000 	add	x0, x0, x5
    543c:	97fff4ad 	bl	26f0 <memmove@plt>
    5440:	a9431262 	ldp	x2, x4, [x19, #48]
    5444:	f9403fe5 	ldr	x5, [sp, #120]
    5448:	17ffffc7 	b	5364 <fwp_p_ad_push.constprop.0+0x140>
    544c:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    5450:	91224000 	add	x0, x0, #0x890
    5454:	a9046bf9 	stp	x25, x26, [sp, #64]
    5458:	a90573fb 	stp	x27, x28, [sp, #80]
    545c:	97fff8e9 	bl	3800 <fwp_trap>
    5460:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    5464:	9121c000 	add	x0, x0, #0x870
    5468:	a9046bf9 	stp	x25, x26, [sp, #64]
    546c:	a90573fb 	stp	x27, x28, [sp, #80]
    5470:	97fff8e4 	bl	3800 <fwp_trap>
    5474:	aa1303e0 	mov	x0, x19
    5478:	97fff6c6 	bl	2f90 <fwp_tape_unlink_scope>
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	97fff530 	bl	2940 <free@plt>
    5484:	f9401a60 	ldr	x0, [x19, #48]
    5488:	97fff52e 	bl	2940 <free@plt>
    548c:	f9402260 	ldr	x0, [x19, #64]
    5490:	97fff52c 	bl	2940 <free@plt>
    5494:	f9000e7f 	str	xzr, [x19, #24]
    5498:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    549c:	f947e821 	ldr	x1, [x1, #4048]
    54a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54a4:	d2800262 	mov	x2, #0x13                  	// #19
    54a8:	4f000400 	movi	v0.4s, #0x0
    54ac:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    54b0:	f9400023 	ldr	x3, [x1]
    54b4:	b900067f 	str	wzr, [x19, #4]
    54b8:	d2800021 	mov	x1, #0x1                   	// #1
    54bc:	91116000 	add	x0, x0, #0x458
    54c0:	3c808260 	stur	q0, [x19, #8]
    54c4:	ad010260 	stp	q0, q0, [x19, #32]
    54c8:	97fff52e 	bl	2980 <fwrite@plt>
    54cc:	d2800000 	mov	x0, #0x0                   	// #0
    54d0:	97fff538 	bl	29b0 <fflush@plt>
    54d4:	52800cc0 	mov	w0, #0x66                  	// #102
    54d8:	97fff546 	bl	29f0 <_Exit@plt>
    54dc:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    54e0:	91210000 	add	x0, x0, #0x840
    54e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54e8:	a90573fb 	stp	x27, x28, [sp, #80]
    54ec:	97fff8c5 	bl	3800 <fwp_trap>

00000000000054f0 <w107>:
    54f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54f4:	9e660003 	fmov	x3, d0
    54f8:	aa0003e2 	mov	x2, x0
    54fc:	910003fd 	mov	x29, sp
    5500:	6d0327e8 	stp	d8, d9, [sp, #48]
    5504:	1e604028 	fmov	d8, d1
    5508:	1e600809 	fmul	d9, d0, d0
    550c:	fd0023ea 	str	d10, [sp, #64]
    5510:	1e60400a 	fmov	d10, d0
    5514:	a90153f3 	stp	x19, x20, [sp, #16]
    5518:	aa0003f3 	mov	x19, x0
    551c:	aa0103f4 	mov	x20, x1
    5520:	aa0303e1 	mov	x1, x3
    5524:	a9025bf5 	stp	x21, x22, [sp, #32]
    5528:	97ffff3f 	bl	5224 <fwp_p_ad_push.constprop.0>
    552c:	1e693908 	fsub	d8, d8, d9
    5530:	aa1403e2 	mov	x2, x20
    5534:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5538:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    553c:	9e660116 	fmov	x22, d8
    5540:	97ffff39 	bl	5224 <fwp_p_ad_push.constprop.0>
    5544:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5548:	aa0003e1 	mov	x1, x0
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa1303e0 	mov	x0, x19
    5554:	1e6a3929 	fsub	d9, d9, d10
    5558:	aa0103f3 	mov	x19, x1
    555c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5560:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5564:	9e660135 	fmov	x21, d9
    5568:	97ffff2f 	bl	5224 <fwp_p_ad_push.constprop.0>
    556c:	1e680908 	fmul	d8, d8, d8
    5570:	aa0003f4 	mov	x20, x0
    5574:	aa1603e3 	mov	x3, x22
    5578:	aa1603e1 	mov	x1, x22
    557c:	aa1303e2 	mov	x2, x19
    5580:	aa1303e0 	mov	x0, x19
    5584:	97ffff28 	bl	5224 <fwp_p_ad_push.constprop.0>
    5588:	aa0003e2 	mov	x2, x0
    558c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5590:	9e670020 	fmov	d0, x1
    5594:	9e660101 	fmov	x1, d8
    5598:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    559c:	1e600908 	fmul	d8, d8, d0
    55a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55a4:	97ffff20 	bl	5224 <fwp_p_ad_push.constprop.0>
    55a8:	1e690929 	fmul	d9, d9, d9
    55ac:	aa0003f3 	mov	x19, x0
    55b0:	aa1503e3 	mov	x3, x21
    55b4:	aa1503e1 	mov	x1, x21
    55b8:	aa1403e2 	mov	x2, x20
    55bc:	aa1403e0 	mov	x0, x20
    55c0:	97ffff19 	bl	5224 <fwp_p_ad_push.constprop.0>
    55c4:	1e692908 	fadd	d8, d8, d9
    55c8:	aa1303e2 	mov	x2, x19
    55cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55d0:	aa0303e1 	mov	x1, x3
    55d4:	97ffff14 	bl	5224 <fwp_p_ad_push.constprop.0>
    55d8:	aa0003e1 	mov	x1, x0
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	9e660100 	fmov	x0, d8
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    55ec:	fd4023ea 	ldr	d10, [sp, #64]
    55f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55f4:	d65f03c0 	ret
    55f8:	d503201f 	nop
    55fc:	d503201f 	nop

0000000000005600 <w164.constprop.0>:
    5600:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5604:	910003fd 	mov	x29, sp
    5608:	a9025bf5 	stp	x21, x22, [sp, #32]
    560c:	fd001be8 	str	d8, [sp, #48]
    5610:	f9400015 	ldr	x21, [x0]
    5614:	b4000315 	cbz	x21, 5674 <w164.constprop.0+0x74>
    5618:	2f00e408 	movi	d8, #0x0
    561c:	91002016 	add	x22, x0, #0x8
    5620:	a90153f3 	stp	x19, x20, [sp, #16]
    5624:	91004014 	add	x20, x0, #0x10
    5628:	d2800013 	mov	x19, #0x0                   	// #0
    562c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5630:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5634:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5638:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    563c:	aa0303e1 	mov	x1, x3
    5640:	1e602908 	fadd	d8, d8, d0
    5644:	91000a73 	add	x19, x19, #0x2
    5648:	97fffef7 	bl	5224 <fwp_p_ad_push.constprop.0>
    564c:	eb1302bf 	cmp	x21, x19
    5650:	54ffff08 	b.hi	5630 <w164.constprop.0+0x30>  // b.pmore
    5654:	9e660102 	fmov	x2, d8
    5658:	fd401be8 	ldr	d8, [sp, #48]
    565c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5660:	aa0003e1 	mov	x1, x0
    5664:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5668:	aa0203e0 	mov	x0, x2
    566c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5670:	d65f03c0 	ret
    5674:	2f00e408 	movi	d8, #0x0
    5678:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    567c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5680:	aa0003e1 	mov	x1, x0
    5684:	9e660102 	fmov	x2, d8
    5688:	fd401be8 	ldr	d8, [sp, #48]
    568c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5690:	aa0203e0 	mov	x0, x2
    5694:	d65f03c0 	ret
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <fwp_data.part.0.constprop.0>:
    56a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56a4:	910003fd 	mov	x29, sp
    56a8:	a90153f3 	stp	x19, x20, [sp, #16]
    56ac:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    56b0:	91174283 	add	x3, x20, #0x5d0
    56b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56b8:	aa0103f5 	mov	x21, x1
    56bc:	b953a461 	ldr	w1, [x3, #5028]
    56c0:	a90363f7 	stp	x23, x24, [sp, #48]
    56c4:	2a0003f8 	mov	w24, w0
    56c8:	34000701 	cbz	w1, 57a8 <fwp_data.part.0.constprop.0+0x108>
    56cc:	397e8862 	ldrb	w2, [x3, #4002]
    56d0:	910f0040 	add	x0, x2, #0x3c0
    56d4:	8b020442 	add	x2, x2, x2, lsl #1
    56d8:	d37df042 	lsl	x2, x2, #3
    56dc:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    56e0:	2a1703f6 	mov	w22, w23
    56e4:	f8626873 	ldr	x19, [x3, x2]
    56e8:	b40004d3 	cbz	x19, 5780 <fwp_data.part.0.constprop.0+0xe0>
    56ec:	f9400260 	ldr	x0, [x19]
    56f0:	aa2003e0 	mvn	x0, x0
    56f4:	f8226860 	str	x0, [x3, x2]
    56f8:	f10062df 	cmp	x22, #0x18
    56fc:	540000e9 	b.ls	5718 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5700:	d10066c2 	sub	x2, x22, #0x19
    5704:	91006260 	add	x0, x19, #0x18
    5708:	927df042 	and	x2, x2, #0xfffffffffffffff8
    570c:	52800001 	mov	w1, #0x0                   	// #0
    5710:	91002042 	add	x2, x2, #0x8
    5714:	97fff44f 	bl	2850 <memset@plt>
    5718:	91174282 	add	x2, x20, #0x5d0
    571c:	f94a1041 	ldr	x1, [x2, #5152]
    5720:	ab160021 	adds	x1, x1, x22
    5724:	540004c2 	b.cs	57bc <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5728:	f94a1440 	ldr	x0, [x2, #5160]
    572c:	f90a1041 	str	x1, [x2, #5152]
    5730:	eb00003f 	cmp	x1, x0
    5734:	54000049 	b.ls	573c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5738:	f90a1441 	str	x1, [x2, #5160]
    573c:	91174294 	add	x20, x20, #0x5d0
    5740:	1e6302e1 	ucvtf	d1, w23
    5744:	fd4a1e80 	ldr	d0, [x20, #5176]
    5748:	1e612800 	fadd	d0, d0, d1
    574c:	fd0a1e80 	str	d0, [x20, #5176]
    5750:	52800041 	mov	w1, #0x2                   	// #2
    5754:	29000678 	stp	w24, w1, [x19]
    5758:	aa1303e0 	mov	x0, x19
    575c:	f94002a1 	ldr	x1, [x21]
    5760:	f9000661 	str	x1, [x19, #8]
    5764:	f94006a1 	ldr	x1, [x21, #8]
    5768:	f9000a61 	str	x1, [x19, #16]
    576c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5770:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5774:	a94363f7 	ldp	x23, x24, [sp, #48]
    5778:	a8c47bfd 	ldp	x29, x30, [sp], #64
    577c:	d65f03c0 	ret
    5780:	8b020063 	add	x3, x3, x2
    5784:	f9400473 	ldr	x19, [x3, #8]
    5788:	b4000113 	cbz	x19, 57a8 <fwp_data.part.0.constprop.0+0x108>
    578c:	f9400860 	ldr	x0, [x3, #16]
    5790:	cb130000 	sub	x0, x0, x19
    5794:	eb0002df 	cmp	x22, x0
    5798:	54000088 	b.hi	57a8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    579c:	8b160260 	add	x0, x19, x22
    57a0:	f9000460 	str	x0, [x3, #8]
    57a4:	17ffffd5 	b	56f8 <fwp_data.part.0.constprop.0+0x58>
    57a8:	52800001 	mov	w1, #0x0                   	// #0
    57ac:	d2800300 	mov	x0, #0x18                  	// #24
    57b0:	97fffdd0 	bl	4ef0 <fwp_heap_alloc>
    57b4:	aa0003f3 	mov	x19, x0
    57b8:	17ffffe6 	b	5750 <fwp_data.part.0.constprop.0+0xb0>
    57bc:	97fff61d 	bl	3030 <fwp_heap_oom>

00000000000057c0 <fwp_rc_share>:
    57c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    57c4:	91174042 	add	x2, x2, #0x5d0
    57c8:	f949d843 	ldr	x3, [x2, #5040]
    57cc:	f949ec41 	ldr	x1, [x2, #5080]
    57d0:	cb030000 	sub	x0, x0, x3
    57d4:	eb01401f 	cmp	x0, x1, lsl #16
    57d8:	540002c2 	b.cs	5830 <fwp_rc_share+0x70>  // b.hs, b.nlast
    57dc:	d350fc01 	lsr	x1, x0, #16
    57e0:	f949fc44 	ldr	x4, [x2, #5112]
    57e4:	8b010821 	add	x1, x1, x1, lsl #2
    57e8:	d37df021 	lsl	x1, x1, #3
    57ec:	8b010083 	add	x3, x4, x1
    57f0:	f9401062 	ldr	x2, [x3, #32]
    57f4:	b40001e2 	cbz	x2, 5830 <fwp_rc_share+0x70>
    57f8:	38616881 	ldrb	w1, [x4, x1]
    57fc:	7100083f 	cmp	w1, #0x2
    5800:	540001a0 	b.eq	5834 <fwp_rc_share+0x74>  // b.none
    5804:	7100043f 	cmp	w1, #0x1
    5808:	54000141 	b.ne	5830 <fwp_rc_share+0x70>  // b.any
    580c:	29430464 	ldp	w4, w1, [x3, #24]
    5810:	92403c00 	and	x0, x0, #0xffff
    5814:	9b047c00 	mul	x0, x0, x4
    5818:	d360fc00 	lsr	x0, x0, #32
    581c:	eb01001f 	cmp	x0, x1
    5820:	54000082 	b.cs	5830 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5824:	8b000042 	add	x2, x2, x0
    5828:	39400040 	ldrb	w0, [x2]
    582c:	350000a0 	cbnz	w0, 5840 <fwp_rc_share+0x80>
    5830:	d65f03c0 	ret
    5834:	72003c1f 	tst	w0, #0xffff
    5838:	54ffff80 	b.eq	5828 <fwp_rc_share+0x68>  // b.none
    583c:	d65f03c0 	ret
    5840:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5844:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    5848:	9122c000 	add	x0, x0, #0x8b0
    584c:	910003fd 	mov	x29, sp
    5850:	97fff7ec 	bl	3800 <fwp_trap>

0000000000005854 <fwp_rc_fresh>:
    5854:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5858:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    585c:	91174063 	add	x3, x3, #0x5d0
    5860:	910003fd 	mov	x29, sp
    5864:	a90153f3 	stp	x19, x20, [sp, #16]
    5868:	aa0003f3 	mov	x19, x0
    586c:	f949d861 	ldr	x1, [x3, #5040]
    5870:	f949ec60 	ldr	x0, [x3, #5080]
    5874:	cb010261 	sub	x1, x19, x1
    5878:	eb00403f 	cmp	x1, x0, lsl #16
    587c:	54000322 	b.cs	58e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5880:	d350fc22 	lsr	x2, x1, #16
    5884:	f949fc63 	ldr	x3, [x3, #5112]
    5888:	8b020842 	add	x2, x2, x2, lsl #2
    588c:	d37df042 	lsl	x2, x2, #3
    5890:	8b020060 	add	x0, x3, x2
    5894:	f9401014 	ldr	x20, [x0, #32]
    5898:	b4000254 	cbz	x20, 58e0 <fwp_rc_fresh+0x8c>
    589c:	38626862 	ldrb	w2, [x3, x2]
    58a0:	7100085f 	cmp	w2, #0x2
    58a4:	54000260 	b.eq	58f0 <fwp_rc_fresh+0x9c>  // b.none
    58a8:	7100045f 	cmp	w2, #0x1
    58ac:	540001a1 	b.ne	58e0 <fwp_rc_fresh+0x8c>  // b.any
    58b0:	29430002 	ldp	w2, w0, [x0, #24]
    58b4:	92403c21 	and	x1, x1, #0xffff
    58b8:	9b027c21 	mul	x1, x1, x2
    58bc:	d360fc21 	lsr	x1, x1, #32
    58c0:	eb00003f 	cmp	x1, x0
    58c4:	540000e2 	b.cs	58e0 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    58c8:	8b010294 	add	x20, x20, x1
    58cc:	39400280 	ldrb	w0, [x20]
    58d0:	7103fc1f 	cmp	w0, #0xff
    58d4:	540001a0 	b.eq	5908 <fwp_rc_fresh+0xb4>  // b.none
    58d8:	52800020 	mov	w0, #0x1                   	// #1
    58dc:	39000280 	strb	w0, [x20]
    58e0:	aa1303e0 	mov	x0, x19
    58e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    58e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    58ec:	d65f03c0 	ret
    58f0:	72003c3f 	tst	w1, #0xffff
    58f4:	54fffec0 	b.eq	58cc <fwp_rc_fresh+0x78>  // b.none
    58f8:	aa1303e0 	mov	x0, x19
    58fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5900:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5904:	d65f03c0 	ret
    5908:	aa1403e0 	mov	x0, x20
    590c:	97fffbb9 	bl	47f0 <fwp_rc_forget_slot>
    5910:	17fffff2 	b	58d8 <fwp_rc_fresh+0x84>

0000000000005914 <fwp_rc_free_arr>:
    5914:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5918:	91174063 	add	x3, x3, #0x5d0
    591c:	f949d861 	ldr	x1, [x3, #5040]
    5920:	f949ec62 	ldr	x2, [x3, #5080]
    5924:	cb010001 	sub	x1, x0, x1
    5928:	eb02403f 	cmp	x1, x2, lsl #16
    592c:	54000342 	b.cs	5994 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5930:	d350fc22 	lsr	x2, x1, #16
    5934:	f949fc65 	ldr	x5, [x3, #5112]
    5938:	8b020842 	add	x2, x2, x2, lsl #2
    593c:	d37df042 	lsl	x2, x2, #3
    5940:	8b0200a4 	add	x4, x5, x2
    5944:	f9401083 	ldr	x3, [x4, #32]
    5948:	b4000263 	cbz	x3, 5994 <fwp_rc_free_arr+0x80>
    594c:	386268a2 	ldrb	w2, [x5, x2]
    5950:	7100085f 	cmp	w2, #0x2
    5954:	540001c0 	b.eq	598c <fwp_rc_free_arr+0x78>  // b.none
    5958:	7100045f 	cmp	w2, #0x1
    595c:	540001c1 	b.ne	5994 <fwp_rc_free_arr+0x80>  // b.any
    5960:	29430885 	ldp	w5, w2, [x4, #24]
    5964:	92403c21 	and	x1, x1, #0xffff
    5968:	9b057c21 	mul	x1, x1, x5
    596c:	d360fc21 	lsr	x1, x1, #32
    5970:	eb02003f 	cmp	x1, x2
    5974:	54000102 	b.cs	5994 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5978:	8b010063 	add	x3, x3, x1
    597c:	39400061 	ldrb	w1, [x3]
    5980:	7100043f 	cmp	w1, #0x1
    5984:	54000081 	b.ne	5994 <fwp_rc_free_arr+0x80>  // b.any
    5988:	17fffc3a 	b	4a70 <fwp_mem_free>
    598c:	72003c3f 	tst	w1, #0xffff
    5990:	54ffff60 	b.eq	597c <fwp_rc_free_arr+0x68>  // b.none
    5994:	d65f03c0 	ret
    5998:	d503201f 	nop
    599c:	d503201f 	nop

00000000000059a0 <fwp_rc_dup>:
    59a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    59a4:	91174042 	add	x2, x2, #0x5d0
    59a8:	f949d841 	ldr	x1, [x2, #5040]
    59ac:	f949ec43 	ldr	x3, [x2, #5080]
    59b0:	cb010001 	sub	x1, x0, x1
    59b4:	eb03403f 	cmp	x1, x3, lsl #16
    59b8:	54000342 	b.cs	5a20 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    59bc:	d350fc20 	lsr	x0, x1, #16
    59c0:	f949fc44 	ldr	x4, [x2, #5112]
    59c4:	8b000800 	add	x0, x0, x0, lsl #2
    59c8:	d37df002 	lsl	x2, x0, #3
    59cc:	8b020083 	add	x3, x4, x2
    59d0:	f9401060 	ldr	x0, [x3, #32]
    59d4:	b4000260 	cbz	x0, 5a20 <fwp_rc_dup+0x80>
    59d8:	38626882 	ldrb	w2, [x4, x2]
    59dc:	7100085f 	cmp	w2, #0x2
    59e0:	54000220 	b.eq	5a24 <fwp_rc_dup+0x84>  // b.none
    59e4:	7100045f 	cmp	w2, #0x1
    59e8:	540001c1 	b.ne	5a20 <fwp_rc_dup+0x80>  // b.any
    59ec:	29430864 	ldp	w4, w2, [x3, #24]
    59f0:	92403c21 	and	x1, x1, #0xffff
    59f4:	9b047c21 	mul	x1, x1, x4
    59f8:	d360fc21 	lsr	x1, x1, #32
    59fc:	eb02003f 	cmp	x1, x2
    5a00:	54000102 	b.cs	5a20 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a04:	8b010000 	add	x0, x0, x1
    5a08:	39400001 	ldrb	w1, [x0]
    5a0c:	340000a1 	cbz	w1, 5a20 <fwp_rc_dup+0x80>
    5a10:	7103f43f 	cmp	w1, #0xfd
    5a14:	540000e8 	b.hi	5a30 <fwp_rc_dup+0x90>  // b.pmore
    5a18:	11000421 	add	w1, w1, #0x1
    5a1c:	39000001 	strb	w1, [x0]
    5a20:	d65f03c0 	ret
    5a24:	72003c3f 	tst	w1, #0xffff
    5a28:	54ffff00 	b.eq	5a08 <fwp_rc_dup+0x68>  // b.none
    5a2c:	d65f03c0 	ret
    5a30:	17fffb29 	b	46d4 <fwp_rc_wide_dup>

0000000000005a34 <fwp_owned_entry161>:
    5a34:	d10103ff 	sub	sp, sp, #0x40
    5a38:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5a3c:	f947f442 	ldr	x2, [x2, #4072]
    5a40:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a44:	910083fd 	add	x29, sp, #0x20
    5a48:	a90353f3 	stp	x19, x20, [sp, #48]
    5a4c:	f9400043 	ldr	x3, [x2]
    5a50:	f9000fe3 	str	x3, [sp, #24]
    5a54:	d2800003 	mov	x3, #0x0                   	// #0
    5a58:	a9400c01 	ldp	x1, x3, [x0]
    5a5c:	f9400802 	ldr	x2, [x0, #16]
    5a60:	ab020022 	adds	x2, x1, x2
    5a64:	540006e6 	b.vs	5b40 <fwp_owned_entry161+0x10c>
    5a68:	910023e1 	add	x1, sp, #0x8
    5a6c:	52800000 	mov	w0, #0x0                   	// #0
    5a70:	a9008be3 	stp	x3, x2, [sp, #8]
    5a74:	97ffff0b 	bl	56a0 <fwp_data.part.0.constprop.0>
    5a78:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5a7c:	91174063 	add	x3, x3, #0x5d0
    5a80:	aa0003f3 	mov	x19, x0
    5a84:	f949d861 	ldr	x1, [x3, #5040]
    5a88:	f949ec60 	ldr	x0, [x3, #5080]
    5a8c:	cb010261 	sub	x1, x19, x1
    5a90:	eb00403f 	cmp	x1, x0, lsl #16
    5a94:	54000322 	b.cs	5af8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5a98:	d350fc22 	lsr	x2, x1, #16
    5a9c:	f949fc63 	ldr	x3, [x3, #5112]
    5aa0:	8b020842 	add	x2, x2, x2, lsl #2
    5aa4:	d37df042 	lsl	x2, x2, #3
    5aa8:	8b020060 	add	x0, x3, x2
    5aac:	f9401014 	ldr	x20, [x0, #32]
    5ab0:	b4000254 	cbz	x20, 5af8 <fwp_owned_entry161+0xc4>
    5ab4:	38626862 	ldrb	w2, [x3, x2]
    5ab8:	7100085f 	cmp	w2, #0x2
    5abc:	54000360 	b.eq	5b28 <fwp_owned_entry161+0xf4>  // b.none
    5ac0:	7100045f 	cmp	w2, #0x1
    5ac4:	540001a1 	b.ne	5af8 <fwp_owned_entry161+0xc4>  // b.any
    5ac8:	29430002 	ldp	w2, w0, [x0, #24]
    5acc:	92403c21 	and	x1, x1, #0xffff
    5ad0:	9b027c21 	mul	x1, x1, x2
    5ad4:	d360fc21 	lsr	x1, x1, #32
    5ad8:	eb00003f 	cmp	x1, x0
    5adc:	540000e2 	b.cs	5af8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5ae0:	8b010294 	add	x20, x20, x1
    5ae4:	39400280 	ldrb	w0, [x20]
    5ae8:	7103fc1f 	cmp	w0, #0xff
    5aec:	54000240 	b.eq	5b34 <fwp_owned_entry161+0x100>  // b.none
    5af0:	52800020 	mov	w0, #0x1                   	// #1
    5af4:	39000280 	strb	w0, [x20]
    5af8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5afc:	f947f400 	ldr	x0, [x0, #4072]
    5b00:	f9400fe2 	ldr	x2, [sp, #24]
    5b04:	f9400001 	ldr	x1, [x0]
    5b08:	eb010042 	subs	x2, x2, x1
    5b0c:	d2800001 	mov	x1, #0x0                   	// #0
    5b10:	540001a1 	b.ne	5b44 <fwp_owned_entry161+0x110>  // b.any
    5b14:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b18:	aa1303e0 	mov	x0, x19
    5b1c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b20:	910103ff 	add	sp, sp, #0x40
    5b24:	d65f03c0 	ret
    5b28:	72003c3f 	tst	w1, #0xffff
    5b2c:	54fffe61 	b.ne	5af8 <fwp_owned_entry161+0xc4>  // b.any
    5b30:	17ffffed 	b	5ae4 <fwp_owned_entry161+0xb0>
    5b34:	aa1403e0 	mov	x0, x20
    5b38:	97fffb2e 	bl	47f0 <fwp_rc_forget_slot>
    5b3c:	17ffffed 	b	5af0 <fwp_owned_entry161+0xbc>
    5b40:	97fff3d0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5b44:	97fff34f 	bl	2880 <__stack_chk_fail@plt>
    5b48:	d503201f 	nop
    5b4c:	d503201f 	nop

0000000000005b50 <e161>:
    5b50:	d10103ff 	sub	sp, sp, #0x40
    5b54:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5b58:	f947f442 	ldr	x2, [x2, #4072]
    5b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b60:	910083fd 	add	x29, sp, #0x20
    5b64:	a90353f3 	stp	x19, x20, [sp, #48]
    5b68:	f9400043 	ldr	x3, [x2]
    5b6c:	f9000fe3 	str	x3, [sp, #24]
    5b70:	d2800003 	mov	x3, #0x0                   	// #0
    5b74:	a9400c01 	ldp	x1, x3, [x0]
    5b78:	f9400802 	ldr	x2, [x0, #16]
    5b7c:	ab020022 	adds	x2, x1, x2
    5b80:	54000726 	b.vs	5c64 <e161+0x114>
    5b84:	910023e1 	add	x1, sp, #0x8
    5b88:	52800000 	mov	w0, #0x0                   	// #0
    5b8c:	a9008be3 	stp	x3, x2, [sp, #8]
    5b90:	97fffec4 	bl	56a0 <fwp_data.part.0.constprop.0>
    5b94:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5b98:	91174063 	add	x3, x3, #0x5d0
    5b9c:	aa0003f3 	mov	x19, x0
    5ba0:	f949d861 	ldr	x1, [x3, #5040]
    5ba4:	f949ec60 	ldr	x0, [x3, #5080]
    5ba8:	cb010261 	sub	x1, x19, x1
    5bac:	eb00403f 	cmp	x1, x0, lsl #16
    5bb0:	54000322 	b.cs	5c14 <e161+0xc4>  // b.hs, b.nlast
    5bb4:	d350fc22 	lsr	x2, x1, #16
    5bb8:	f949fc63 	ldr	x3, [x3, #5112]
    5bbc:	8b020842 	add	x2, x2, x2, lsl #2
    5bc0:	d37df042 	lsl	x2, x2, #3
    5bc4:	8b020060 	add	x0, x3, x2
    5bc8:	f9401014 	ldr	x20, [x0, #32]
    5bcc:	b4000254 	cbz	x20, 5c14 <e161+0xc4>
    5bd0:	38626862 	ldrb	w2, [x3, x2]
    5bd4:	7100085f 	cmp	w2, #0x2
    5bd8:	540003a0 	b.eq	5c4c <e161+0xfc>  // b.none
    5bdc:	7100045f 	cmp	w2, #0x1
    5be0:	540001a1 	b.ne	5c14 <e161+0xc4>  // b.any
    5be4:	29430002 	ldp	w2, w0, [x0, #24]
    5be8:	92403c21 	and	x1, x1, #0xffff
    5bec:	9b027c21 	mul	x1, x1, x2
    5bf0:	d360fc21 	lsr	x1, x1, #32
    5bf4:	eb00003f 	cmp	x1, x0
    5bf8:	540000e2 	b.cs	5c14 <e161+0xc4>  // b.hs, b.nlast
    5bfc:	8b010294 	add	x20, x20, x1
    5c00:	39400280 	ldrb	w0, [x20]
    5c04:	7103fc1f 	cmp	w0, #0xff
    5c08:	54000280 	b.eq	5c58 <e161+0x108>  // b.none
    5c0c:	52800020 	mov	w0, #0x1                   	// #1
    5c10:	39000280 	strb	w0, [x20]
    5c14:	aa1303e0 	mov	x0, x19
    5c18:	97fffeea 	bl	57c0 <fwp_rc_share>
    5c1c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5c20:	f947f400 	ldr	x0, [x0, #4072]
    5c24:	f9400fe2 	ldr	x2, [sp, #24]
    5c28:	f9400001 	ldr	x1, [x0]
    5c2c:	eb010042 	subs	x2, x2, x1
    5c30:	d2800001 	mov	x1, #0x0                   	// #0
    5c34:	540001a1 	b.ne	5c68 <e161+0x118>  // b.any
    5c38:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c3c:	aa1303e0 	mov	x0, x19
    5c40:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c44:	910103ff 	add	sp, sp, #0x40
    5c48:	d65f03c0 	ret
    5c4c:	72003c3f 	tst	w1, #0xffff
    5c50:	54fffe21 	b.ne	5c14 <e161+0xc4>  // b.any
    5c54:	17ffffeb 	b	5c00 <e161+0xb0>
    5c58:	aa1403e0 	mov	x0, x20
    5c5c:	97fffae5 	bl	47f0 <fwp_rc_forget_slot>
    5c60:	17ffffeb 	b	5c0c <e161+0xbc>
    5c64:	97fff387 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5c68:	97fff306 	bl	2880 <__stack_chk_fail@plt>
    5c6c:	d503201f 	nop

0000000000005c70 <fwp_drop1>:
    5c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c74:	910003fd 	mov	x29, sp
    5c78:	a90153f3 	stp	x19, x20, [sp, #16]
    5c7c:	f90013f5 	str	x21, [sp, #32]
    5c80:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5c84:	911742b4 	add	x20, x21, #0x5d0
    5c88:	f949da81 	ldr	x1, [x20, #5040]
    5c8c:	f949ee82 	ldr	x2, [x20, #5080]
    5c90:	cb010001 	sub	x1, x0, x1
    5c94:	eb02403f 	cmp	x1, x2, lsl #16
    5c98:	54000382 	b.cs	5d08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c9c:	d350fc22 	lsr	x2, x1, #16
    5ca0:	f949fe84 	ldr	x4, [x20, #5112]
    5ca4:	8b020842 	add	x2, x2, x2, lsl #2
    5ca8:	d37df042 	lsl	x2, x2, #3
    5cac:	8b020083 	add	x3, x4, x2
    5cb0:	f9401073 	ldr	x19, [x3, #32]
    5cb4:	b40002b3 	cbz	x19, 5d08 <fwp_drop1+0x98>
    5cb8:	38626882 	ldrb	w2, [x4, x2]
    5cbc:	7100085f 	cmp	w2, #0x2
    5cc0:	540002c0 	b.eq	5d18 <fwp_drop1+0xa8>  // b.none
    5cc4:	7100045f 	cmp	w2, #0x1
    5cc8:	54000201 	b.ne	5d08 <fwp_drop1+0x98>  // b.any
    5ccc:	29430864 	ldp	w4, w2, [x3, #24]
    5cd0:	92403c21 	and	x1, x1, #0xffff
    5cd4:	9b047c21 	mul	x1, x1, x4
    5cd8:	d360fc21 	lsr	x1, x1, #32
    5cdc:	eb02003f 	cmp	x1, x2
    5ce0:	54000142 	b.cs	5d08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ce4:	8b010273 	add	x19, x19, x1
    5ce8:	39400261 	ldrb	w1, [x19]
    5cec:	340000e1 	cbz	w1, 5d08 <fwp_drop1+0x98>
    5cf0:	7100043f 	cmp	w1, #0x1
    5cf4:	540001e0 	b.eq	5d30 <fwp_drop1+0xc0>  // b.none
    5cf8:	7103fc3f 	cmp	w1, #0xff
    5cfc:	540002e0 	b.eq	5d58 <fwp_drop1+0xe8>  // b.none
    5d00:	51000421 	sub	w1, w1, #0x1
    5d04:	39000261 	strb	w1, [x19]
    5d08:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d0c:	f94013f5 	ldr	x21, [sp, #32]
    5d10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d14:	d65f03c0 	ret
    5d18:	72003c3f 	tst	w1, #0xffff
    5d1c:	54fffe60 	b.eq	5ce8 <fwp_drop1+0x78>  // b.none
    5d20:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d24:	f94013f5 	ldr	x21, [sp, #32]
    5d28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d2c:	d65f03c0 	ret
    5d30:	f9400813 	ldr	x19, [x0, #16]
    5d34:	97fffef8 	bl	5914 <fwp_rc_free_arr>
    5d38:	911742a0 	add	x0, x21, #0x5d0
    5d3c:	f949d801 	ldr	x1, [x0, #5040]
    5d40:	f949ec00 	ldr	x0, [x0, #5080]
    5d44:	cb010261 	sub	x1, x19, x1
    5d48:	eb00403f 	cmp	x1, x0, lsl #16
    5d4c:	54fffde2 	b.cs	5d08 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d50:	aa1303e0 	mov	x0, x19
    5d54:	17ffffd2 	b	5c9c <fwp_drop1+0x2c>
    5d58:	ca534660 	eor	x0, x19, x19, lsr #17
    5d5c:	911742b5 	add	x21, x21, #0x5d0
    5d60:	ca402400 	eor	x0, x0, x0, lsr #9
    5d64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5d68:	f94a2400 	ldr	x0, [x0, #5192]
    5d6c:	b5000080 	cbnz	x0, 5d7c <fwp_drop1+0x10c>
    5d70:	14000010 	b	5db0 <fwp_drop1+0x140>
    5d74:	f9400800 	ldr	x0, [x0, #16]
    5d78:	b40001c0 	cbz	x0, 5db0 <fwp_drop1+0x140>
    5d7c:	f9400001 	ldr	x1, [x0]
    5d80:	eb13003f 	cmp	x1, x19
    5d84:	54ffff81 	b.ne	5d74 <fwp_drop1+0x104>  // b.any
    5d88:	f9400401 	ldr	x1, [x0, #8]
    5d8c:	d1000421 	sub	x1, x1, #0x1
    5d90:	f9000401 	str	x1, [x0, #8]
    5d94:	f103f83f 	cmp	x1, #0xfe
    5d98:	54fffb81 	b.ne	5d08 <fwp_drop1+0x98>  // b.any
    5d9c:	aa1303e0 	mov	x0, x19
    5da0:	97fffa94 	bl	47f0 <fwp_rc_forget_slot>
    5da4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5da8:	39000260 	strb	w0, [x19]
    5dac:	17ffffd7 	b	5d08 <fwp_drop1+0x98>
    5db0:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    5db4:	911ec000 	add	x0, x0, #0x7b0
    5db8:	97fff692 	bl	3800 <fwp_trap>
    5dbc:	d503201f 	nop

0000000000005dc0 <fwp_drop0>:
    5dc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5dc4:	910003fd 	mov	x29, sp
    5dc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5dcc:	f90013f5 	str	x21, [sp, #32]
    5dd0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5dd4:	911742b4 	add	x20, x21, #0x5d0
    5dd8:	f949da81 	ldr	x1, [x20, #5040]
    5ddc:	f949ee82 	ldr	x2, [x20, #5080]
    5de0:	cb010001 	sub	x1, x0, x1
    5de4:	eb02403f 	cmp	x1, x2, lsl #16
    5de8:	54000382 	b.cs	5e58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5dec:	d350fc22 	lsr	x2, x1, #16
    5df0:	f949fe84 	ldr	x4, [x20, #5112]
    5df4:	8b020842 	add	x2, x2, x2, lsl #2
    5df8:	d37df042 	lsl	x2, x2, #3
    5dfc:	8b020083 	add	x3, x4, x2
    5e00:	f9401073 	ldr	x19, [x3, #32]
    5e04:	b40002b3 	cbz	x19, 5e58 <fwp_drop0+0x98>
    5e08:	38626882 	ldrb	w2, [x4, x2]
    5e0c:	7100085f 	cmp	w2, #0x2
    5e10:	540002c0 	b.eq	5e68 <fwp_drop0+0xa8>  // b.none
    5e14:	7100045f 	cmp	w2, #0x1
    5e18:	54000201 	b.ne	5e58 <fwp_drop0+0x98>  // b.any
    5e1c:	29430864 	ldp	w4, w2, [x3, #24]
    5e20:	92403c21 	and	x1, x1, #0xffff
    5e24:	9b047c21 	mul	x1, x1, x4
    5e28:	d360fc21 	lsr	x1, x1, #32
    5e2c:	eb02003f 	cmp	x1, x2
    5e30:	54000142 	b.cs	5e58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e34:	8b010273 	add	x19, x19, x1
    5e38:	39400261 	ldrb	w1, [x19]
    5e3c:	340000e1 	cbz	w1, 5e58 <fwp_drop0+0x98>
    5e40:	7100043f 	cmp	w1, #0x1
    5e44:	540001e0 	b.eq	5e80 <fwp_drop0+0xc0>  // b.none
    5e48:	7103fc3f 	cmp	w1, #0xff
    5e4c:	540002e0 	b.eq	5ea8 <fwp_drop0+0xe8>  // b.none
    5e50:	51000421 	sub	w1, w1, #0x1
    5e54:	39000261 	strb	w1, [x19]
    5e58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e5c:	f94013f5 	ldr	x21, [sp, #32]
    5e60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e64:	d65f03c0 	ret
    5e68:	72003c3f 	tst	w1, #0xffff
    5e6c:	54fffe60 	b.eq	5e38 <fwp_drop0+0x78>  // b.none
    5e70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e74:	f94013f5 	ldr	x21, [sp, #32]
    5e78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e7c:	d65f03c0 	ret
    5e80:	f9400813 	ldr	x19, [x0, #16]
    5e84:	97fffea4 	bl	5914 <fwp_rc_free_arr>
    5e88:	911742a0 	add	x0, x21, #0x5d0
    5e8c:	f949d801 	ldr	x1, [x0, #5040]
    5e90:	f949ec00 	ldr	x0, [x0, #5080]
    5e94:	cb010261 	sub	x1, x19, x1
    5e98:	eb00403f 	cmp	x1, x0, lsl #16
    5e9c:	54fffde2 	b.cs	5e58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ea0:	aa1303e0 	mov	x0, x19
    5ea4:	17ffffd2 	b	5dec <fwp_drop0+0x2c>
    5ea8:	ca534660 	eor	x0, x19, x19, lsr #17
    5eac:	911742b5 	add	x21, x21, #0x5d0
    5eb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5eb4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5eb8:	f94a2400 	ldr	x0, [x0, #5192]
    5ebc:	b5000080 	cbnz	x0, 5ecc <fwp_drop0+0x10c>
    5ec0:	14000010 	b	5f00 <fwp_drop0+0x140>
    5ec4:	f9400800 	ldr	x0, [x0, #16]
    5ec8:	b40001c0 	cbz	x0, 5f00 <fwp_drop0+0x140>
    5ecc:	f9400001 	ldr	x1, [x0]
    5ed0:	eb13003f 	cmp	x1, x19
    5ed4:	54ffff81 	b.ne	5ec4 <fwp_drop0+0x104>  // b.any
    5ed8:	f9400401 	ldr	x1, [x0, #8]
    5edc:	d1000421 	sub	x1, x1, #0x1
    5ee0:	f9000401 	str	x1, [x0, #8]
    5ee4:	f103f83f 	cmp	x1, #0xfe
    5ee8:	54fffb81 	b.ne	5e58 <fwp_drop0+0x98>  // b.any
    5eec:	aa1303e0 	mov	x0, x19
    5ef0:	97fffa40 	bl	47f0 <fwp_rc_forget_slot>
    5ef4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ef8:	39000260 	strb	w0, [x19]
    5efc:	17ffffd7 	b	5e58 <fwp_drop0+0x98>
    5f00:	90000040 	adrp	x0, d000 <__divti3+0x2d0>
    5f04:	911ec000 	add	x0, x0, #0x7b0
    5f08:	97fff63e 	bl	3800 <fwp_trap>
    5f0c:	d503201f 	nop

0000000000005f10 <fwp_arg_drop12>:
    5f10:	7100003f 	cmp	w1, #0x0
    5f14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5f18:	54000041 	b.ne	5f20 <fwp_arg_drop12+0x10>  // b.any
    5f1c:	d65f03c0 	ret
    5f20:	f9400000 	ldr	x0, [x0]
    5f24:	17ffffa7 	b	5dc0 <fwp_drop0>
    5f28:	d503201f 	nop
    5f2c:	d503201f 	nop

0000000000005f30 <fwp_closure_drop>:
    5f30:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5f34:	911740a4 	add	x4, x5, #0x5d0
    5f38:	aa0003e1 	mov	x1, x0
    5f3c:	f949d882 	ldr	x2, [x4, #5040]
    5f40:	f949ec80 	ldr	x0, [x4, #5080]
    5f44:	cb020022 	sub	x2, x1, x2
    5f48:	eb00405f 	cmp	x2, x0, lsl #16
    5f4c:	54000662 	b.cs	6018 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5f54:	d350fc43 	lsr	x3, x2, #16
    5f58:	910003fd 	mov	x29, sp
    5f5c:	8b030863 	add	x3, x3, x3, lsl #2
    5f60:	f949fc84 	ldr	x4, [x4, #5112]
    5f64:	d37df063 	lsl	x3, x3, #3
    5f68:	f9000bf3 	str	x19, [sp, #16]
    5f6c:	8b030080 	add	x0, x4, x3
    5f70:	f9401013 	ldr	x19, [x0, #32]
    5f74:	b40002b3 	cbz	x19, 5fc8 <fwp_closure_drop+0x98>
    5f78:	38636883 	ldrb	w3, [x4, x3]
    5f7c:	7100087f 	cmp	w3, #0x2
    5f80:	54000420 	b.eq	6004 <fwp_closure_drop+0xd4>  // b.none
    5f84:	7100047f 	cmp	w3, #0x1
    5f88:	54000201 	b.ne	5fc8 <fwp_closure_drop+0x98>  // b.any
    5f8c:	29430003 	ldp	w3, w0, [x0, #24]
    5f90:	92403c42 	and	x2, x2, #0xffff
    5f94:	9b037c42 	mul	x2, x2, x3
    5f98:	d360fc42 	lsr	x2, x2, #32
    5f9c:	eb00005f 	cmp	x2, x0
    5fa0:	54000142 	b.cs	5fc8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5fa4:	8b020273 	add	x19, x19, x2
    5fa8:	39400260 	ldrb	w0, [x19]
    5fac:	340000e0 	cbz	w0, 5fc8 <fwp_closure_drop+0x98>
    5fb0:	7100041f 	cmp	w0, #0x1
    5fb4:	54000100 	b.eq	5fd4 <fwp_closure_drop+0xa4>  // b.none
    5fb8:	7103fc1f 	cmp	w0, #0xff
    5fbc:	54000300 	b.eq	601c <fwp_closure_drop+0xec>  // b.none
    5fc0:	51000400 	sub	w0, w0, #0x1
    5fc4:	39000260 	strb	w0, [x19]
    5fc8:	f9400bf3 	ldr	x19, [sp, #16]
    5fcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fd0:	d65f03c0 	ret
    5fd4:	d53bd040 	mrs	x0, tpidr_el0
    5fd8:	91400000 	add	x0, x0, #0x0, lsl #12
    5fdc:	91004000 	add	x0, x0, #0x10
    5fe0:	f9400000 	ldr	x0, [x0]
    5fe4:	b4000080 	cbz	x0, 5ff4 <fwp_closure_drop+0xc4>
    5fe8:	f9400bf3 	ldr	x19, [sp, #16]
    5fec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ff0:	17fff61d 	b	3864 <fwp_closure_drop_push>
    5ff4:	f9400bf3 	ldr	x19, [sp, #16]
    5ff8:	aa0103e0 	mov	x0, x1
    5ffc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6000:	17fff688 	b	3a20 <fwp_closure_drop.part.0>
    6004:	72003c5f 	tst	w2, #0xffff
    6008:	54fffd00 	b.eq	5fa8 <fwp_closure_drop+0x78>  // b.none
    600c:	f9400bf3 	ldr	x19, [sp, #16]
    6010:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6014:	d65f03c0 	ret
    6018:	d65f03c0 	ret
    601c:	ca534660 	eor	x0, x19, x19, lsr #17
    6020:	911740a5 	add	x5, x5, #0x5d0
    6024:	ca402400 	eor	x0, x0, x0, lsr #9
    6028:	8b200ca0 	add	x0, x5, w0, uxtb #3
    602c:	f94a2400 	ldr	x0, [x0, #5192]
    6030:	b5000080 	cbnz	x0, 6040 <fwp_closure_drop+0x110>
    6034:	14000010 	b	6074 <fwp_closure_drop+0x144>
    6038:	f9400800 	ldr	x0, [x0, #16]
    603c:	b40001c0 	cbz	x0, 6074 <fwp_closure_drop+0x144>
    6040:	f9400001 	ldr	x1, [x0]
    6044:	eb13003f 	cmp	x1, x19
    6048:	54ffff81 	b.ne	6038 <fwp_closure_drop+0x108>  // b.any
    604c:	f9400401 	ldr	x1, [x0, #8]
    6050:	d1000421 	sub	x1, x1, #0x1
    6054:	f9000401 	str	x1, [x0, #8]
    6058:	f103f83f 	cmp	x1, #0xfe
    605c:	54fffb61 	b.ne	5fc8 <fwp_closure_drop+0x98>  // b.any
    6060:	aa1303e0 	mov	x0, x19
    6064:	97fff9e3 	bl	47f0 <fwp_rc_forget_slot>
    6068:	12800020 	mov	w0, #0xfffffffe            	// #-2
    606c:	39000260 	strb	w0, [x19]
    6070:	17ffffd6 	b	5fc8 <fwp_closure_drop+0x98>
    6074:	f0000020 	adrp	x0, d000 <__divti3+0x2d0>
    6078:	911ec000 	add	x0, x0, #0x7b0
    607c:	97fff5e1 	bl	3800 <fwp_trap>

0000000000006080 <fwp_owned_tape_release>:
    6080:	b4000940 	cbz	x0, 61a8 <fwp_owned_tape_release+0x128>
    6084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6088:	910003fd 	mov	x29, sp
    608c:	a90153f3 	stp	x19, x20, [sp, #16]
    6090:	aa0003f3 	mov	x19, x0
    6094:	f9400000 	ldr	x0, [x0]
    6098:	b4000060 	cbz	x0, 60a4 <fwp_owned_tape_release+0x24>
    609c:	f9400661 	ldr	x1, [x19, #8]
    60a0:	f9000401 	str	x1, [x0, #8]
    60a4:	f9400661 	ldr	x1, [x19, #8]
    60a8:	b4000041 	cbz	x1, 60b0 <fwp_owned_tape_release+0x30>
    60ac:	f9000020 	str	x0, [x1]
    60b0:	f9400a60 	ldr	x0, [x19, #16]
    60b4:	f9403401 	ldr	x1, [x0, #104]
    60b8:	b40005c1 	cbz	x1, 6170 <fwp_owned_tape_release+0xf0>
    60bc:	a9450a60 	ldp	x0, x2, [x19, #80]
    60c0:	eb00005f 	cmp	x2, x0
    60c4:	540002ed 	b.le	6120 <fwp_owned_tape_release+0xa0>
    60c8:	d2800014 	mov	x20, #0x0                   	// #0
    60cc:	f90013f5 	str	x21, [sp, #32]
    60d0:	d2800015 	mov	x21, #0x0                   	// #0
    60d4:	d503201f 	nop
    60d8:	f9402260 	ldr	x0, [x19, #64]
    60dc:	910006b5 	add	x21, x21, #0x1
    60e0:	f8746800 	ldr	x0, [x0, x20]
    60e4:	d63f0020 	blr	x1
    60e8:	f9402260 	ldr	x0, [x19, #64]
    60ec:	f9400a61 	ldr	x1, [x19, #16]
    60f0:	8b140000 	add	x0, x0, x20
    60f4:	91004294 	add	x20, x20, #0x10
    60f8:	f9400400 	ldr	x0, [x0, #8]
    60fc:	f9403421 	ldr	x1, [x1, #104]
    6100:	d63f0020 	blr	x1
    6104:	a9450261 	ldp	x1, x0, [x19, #80]
    6108:	cb010000 	sub	x0, x0, x1
    610c:	eb15001f 	cmp	x0, x21
    6110:	f9400a60 	ldr	x0, [x19, #16]
    6114:	f9403401 	ldr	x1, [x0, #104]
    6118:	54fffe0c 	b.gt	60d8 <fwp_owned_tape_release+0x58>
    611c:	f94013f5 	ldr	x21, [sp, #32]
    6120:	f9403663 	ldr	x3, [x19, #104]
    6124:	f9401262 	ldr	x2, [x19, #32]
    6128:	f100007f 	cmp	x3, #0x0
    612c:	540001ed 	b.le	6168 <fwp_owned_tape_release+0xe8>
    6130:	d2800014 	mov	x20, #0x0                   	// #0
    6134:	d503201f 	nop
    6138:	f9402660 	ldr	x0, [x19, #72]
    613c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6140:	eb02001f 	cmp	x0, x2
    6144:	540000c0 	b.eq	615c <fwp_owned_tape_release+0xdc>  // b.none
    6148:	d63f0020 	blr	x1
    614c:	f9400a60 	ldr	x0, [x19, #16]
    6150:	f9401262 	ldr	x2, [x19, #32]
    6154:	f9403663 	ldr	x3, [x19, #104]
    6158:	f9403401 	ldr	x1, [x0, #104]
    615c:	91000694 	add	x20, x20, #0x1
    6160:	eb14007f 	cmp	x3, x20
    6164:	54fffeac 	b.gt	6138 <fwp_owned_tape_release+0xb8>
    6168:	aa0203e0 	mov	x0, x2
    616c:	d63f0020 	blr	x1
    6170:	f9401660 	ldr	x0, [x19, #40]
    6174:	97ffff6f 	bl	5f30 <fwp_closure_drop>
    6178:	f9401a60 	ldr	x0, [x19, #48]
    617c:	97ffff6d 	bl	5f30 <fwp_closure_drop>
    6180:	f9401e60 	ldr	x0, [x19, #56]
    6184:	97ffff6b 	bl	5f30 <fwp_closure_drop>
    6188:	f9402260 	ldr	x0, [x19, #64]
    618c:	97fffa39 	bl	4a70 <fwp_mem_free>
    6190:	f9402660 	ldr	x0, [x19, #72]
    6194:	97fffa37 	bl	4a70 <fwp_mem_free>
    6198:	aa1303e0 	mov	x0, x19
    619c:	a94153f3 	ldp	x19, x20, [sp, #16]
    61a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61a4:	17fffa33 	b	4a70 <fwp_mem_free>
    61a8:	d65f03c0 	ret
    61ac:	d503201f 	nop

00000000000061b0 <fwp_tape_finish>:
    61b0:	d10203ff 	sub	sp, sp, #0x80
    61b4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    61b8:	f947f421 	ldr	x1, [x1, #4072]
    61bc:	a9047bfd 	stp	x29, x30, [sp, #64]
    61c0:	910103fd 	add	x29, sp, #0x40
    61c4:	a90553f3 	stp	x19, x20, [sp, #80]
    61c8:	a9065bf5 	stp	x21, x22, [sp, #96]
    61cc:	a90763f7 	stp	x23, x24, [sp, #112]
    61d0:	d00000d8 	adrp	x24, 20000 <__data_start>
    61d4:	9101c316 	add	x22, x24, #0x70
    61d8:	f9400022 	ldr	x2, [x1]
    61dc:	f9001fe2 	str	x2, [sp, #56]
    61e0:	d2800002 	mov	x2, #0x0                   	// #0
    61e4:	910262c0 	add	x0, x22, #0x98
    61e8:	97fff4a6 	bl	3480 <fwp_tape_buffers_dispose>
    61ec:	f9006adf 	str	xzr, [x22, #208]
    61f0:	f9404ac0 	ldr	x0, [x22, #144]
    61f4:	f100001f 	cmp	x0, #0x0
    61f8:	5400030d 	b.le	6258 <fwp_tape_finish+0xa8>
    61fc:	910003f7 	mov	x23, sp
    6200:	d2800015 	mov	x21, #0x0                   	// #0
    6204:	d2800014 	mov	x20, #0x0                   	// #0
    6208:	f94002d3 	ldr	x19, [x22]
    620c:	91000694 	add	x20, x20, #0x1
    6210:	8b150273 	add	x19, x19, x21
    6214:	9101a2b5 	add	x21, x21, #0x68
    6218:	aa1303e0 	mov	x0, x19
    621c:	97fff35d 	bl	2f90 <fwp_tape_unlink_scope>
    6220:	aa1703e0 	mov	x0, x23
    6224:	f9401261 	ldr	x1, [x19, #32]
    6228:	f90003e1 	str	x1, [sp]
    622c:	f9401a62 	ldr	x2, [x19, #48]
    6230:	f9000be2 	str	x2, [sp, #16]
    6234:	f9402261 	ldr	x1, [x19, #64]
    6238:	f90013e1 	str	x1, [sp, #32]
    623c:	97fff491 	bl	3480 <fwp_tape_buffers_dispose>
    6240:	f9403260 	ldr	x0, [x19, #96]
    6244:	97ffff8f 	bl	6080 <fwp_owned_tape_release>
    6248:	f900327f 	str	xzr, [x19, #96]
    624c:	f9404ac0 	ldr	x0, [x22, #144]
    6250:	eb14001f 	cmp	x0, x20
    6254:	54fffdac 	b.gt	6208 <fwp_tape_finish+0x58>
    6258:	f9403b00 	ldr	x0, [x24, #112]
    625c:	9101c313 	add	x19, x24, #0x70
    6260:	97fff1b8 	bl	2940 <free@plt>
    6264:	f9003b1f 	str	xzr, [x24, #112]
    6268:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    626c:	f947f400 	ldr	x0, [x0, #4072]
    6270:	f9004a7f 	str	xzr, [x19, #144]
    6274:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6278:	f9401fe2 	ldr	x2, [sp, #56]
    627c:	f9400001 	ldr	x1, [x0]
    6280:	eb010042 	subs	x2, x2, x1
    6284:	d2800001 	mov	x1, #0x0                   	// #0
    6288:	540000e1 	b.ne	62a4 <fwp_tape_finish+0xf4>  // b.any
    628c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6290:	a94553f3 	ldp	x19, x20, [sp, #80]
    6294:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6298:	a94763f7 	ldp	x23, x24, [sp, #112]
    629c:	910203ff 	add	sp, sp, #0x80
    62a0:	d65f03c0 	ret
    62a4:	97fff177 	bl	2880 <__stack_chk_fail@plt>
    62a8:	d503201f 	nop
    62ac:	d503201f 	nop

00000000000062b0 <fwp_tape_scope_release>:
    62b0:	d10243ff 	sub	sp, sp, #0x90
    62b4:	a9047bfd 	stp	x29, x30, [sp, #64]
    62b8:	910103fd 	add	x29, sp, #0x40
    62bc:	a90553f3 	stp	x19, x20, [sp, #80]
    62c0:	aa0003f4 	mov	x20, x0
    62c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    62c8:	f947f400 	ldr	x0, [x0, #4072]
    62cc:	b9400285 	ldr	w5, [x20]
    62d0:	f9400001 	ldr	x1, [x0]
    62d4:	f9001fe1 	str	x1, [sp, #56]
    62d8:	d2800001 	mov	x1, #0x0                   	// #0
    62dc:	37f806c5 	tbnz	w5, #31, 63b4 <fwp_tape_scope_release+0x104>
    62e0:	a90763f7 	stp	x23, x24, [sp, #112]
    62e4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    62e8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    62ec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    62f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    62f4:	910003f7 	mov	x23, sp
    62f8:	9101c273 	add	x19, x19, #0x70
    62fc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6300:	a9065bf5 	stp	x21, x22, [sp, #96]
    6304:	52800d16 	mov	w22, #0x68                  	// #104
    6308:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    630c:	f90043f9 	str	x25, [sp, #128]
    6310:	14000006 	b	6328 <fwp_tape_scope_release+0x78>
    6314:	97fff45b 	bl	3480 <fwp_tape_buffers_dispose>
    6318:	aa1903e0 	mov	x0, x25
    631c:	97ffff59 	bl	6080 <fwp_owned_tape_release>
    6320:	b9400285 	ldr	w5, [x20]
    6324:	37f80425 	tbnz	w5, #31, 63a8 <fwp_tape_scope_release+0xf8>
    6328:	f9400266 	ldr	x6, [x19]
    632c:	9b367ca5 	smull	x5, w5, w22
    6330:	8b0500c0 	add	x0, x6, x5
    6334:	97fff317 	bl	2f90 <fwp_tape_unlink_scope>
    6338:	ad410001 	ldp	q1, q0, [x0, #32]
    633c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6340:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6344:	f9400c03 	ldr	x3, [x0, #24]
    6348:	ad0003e1 	stp	q1, q0, [sp]
    634c:	b86568c1 	ldr	w1, [x6, x5]
    6350:	a9440804 	ldp	x4, x2, [x0, #64]
    6354:	b900041f 	str	wzr, [x0, #4]
    6358:	f9403019 	ldr	x25, [x0, #96]
    635c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6360:	f9000c1f 	str	xzr, [x0, #24]
    6364:	a9020fe4 	stp	x4, x3, [sp, #32]
    6368:	f9001be2 	str	x2, [sp, #48]
    636c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6370:	f900301f 	str	xzr, [x0, #96]
    6374:	6b15003f 	cmp	w1, w21
    6378:	540000e8 	b.hi	6394 <fwp_tape_scope_release+0xe4>  // b.pmore
    637c:	9343fca5 	asr	x5, x5, #3
    6380:	f9407660 	ldr	x0, [x19, #232]
    6384:	9b187ca5 	mul	x5, x5, x24
    6388:	eb0000bf 	cmp	x5, x0
    638c:	5400004a 	b.ge	6394 <fwp_tape_scope_release+0xe4>  // b.tcont
    6390:	f9007665 	str	x5, [x19, #232]
    6394:	aa1703e0 	mov	x0, x23
    6398:	b5fffbf9 	cbnz	x25, 6314 <fwp_tape_scope_release+0x64>
    639c:	97fff7f9 	bl	4380 <fwp_tape_buffers_release>
    63a0:	b9400285 	ldr	w5, [x20]
    63a4:	36fffc25 	tbz	w5, #31, 6328 <fwp_tape_scope_release+0x78>
    63a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    63b0:	f94043f9 	ldr	x25, [sp, #128]
    63b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    63b8:	f947f400 	ldr	x0, [x0, #4072]
    63bc:	f9401fe2 	ldr	x2, [sp, #56]
    63c0:	f9400001 	ldr	x1, [x0]
    63c4:	eb010042 	subs	x2, x2, x1
    63c8:	d2800001 	mov	x1, #0x0                   	// #0
    63cc:	540000a1 	b.ne	63e0 <fwp_tape_scope_release+0x130>  // b.any
    63d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    63d8:	910243ff 	add	sp, sp, #0x90
    63dc:	d65f03c0 	ret
    63e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63e4:	a90763f7 	stp	x23, x24, [sp, #112]
    63e8:	f90043f9 	str	x25, [sp, #128]
    63ec:	97fff125 	bl	2880 <__stack_chk_fail@plt>

00000000000063f0 <fwp_task_dispose>:
    63f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63f4:	910003fd 	mov	x29, sp
    63f8:	f9000bf3 	str	x19, [sp, #16]
    63fc:	aa0003f3 	mov	x19, x0
    6400:	39414000 	ldrb	w0, [x0, #80]
    6404:	36000720 	tbz	w0, #0, 64e8 <fwp_task_dispose+0xf8>
    6408:	f9400a60 	ldr	x0, [x19, #16]
    640c:	b50006e0 	cbnz	x0, 64e8 <fwp_task_dispose+0xf8>
    6410:	a9478660 	ldp	x0, x1, [x19, #120]
    6414:	39014e7f 	strb	wzr, [x19, #83]
    6418:	f9003e7f 	str	xzr, [x19, #120]
    641c:	f100003f 	cmp	x1, #0x0
    6420:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6424:	54000040 	b.eq	642c <fwp_task_dispose+0x3c>  // b.none
    6428:	d63f0020 	blr	x1
    642c:	f9405660 	ldr	x0, [x19, #168]
    6430:	97fff990 	bl	4a70 <fwp_mem_free>
    6434:	f900567f 	str	xzr, [x19, #168]
    6438:	b9405e60 	ldr	w0, [x19, #92]
    643c:	7100041f 	cmp	w0, #0x1
    6440:	54000420 	b.eq	64c4 <fwp_task_dispose+0xd4>  // b.none
    6444:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6448:	91174042 	add	x2, x2, #0x5d0
    644c:	f949d840 	ldr	x0, [x2, #5040]
    6450:	f949ec41 	ldr	x1, [x2, #5080]
    6454:	cb000260 	sub	x0, x19, x0
    6458:	eb01401f 	cmp	x0, x1, lsl #16
    645c:	540002e2 	b.cs	64b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6460:	d350fc01 	lsr	x1, x0, #16
    6464:	f949fc44 	ldr	x4, [x2, #5112]
    6468:	8b010821 	add	x1, x1, x1, lsl #2
    646c:	d37df021 	lsl	x1, x1, #3
    6470:	8b010083 	add	x3, x4, x1
    6474:	f9401062 	ldr	x2, [x3, #32]
    6478:	b4000202 	cbz	x2, 64b8 <fwp_task_dispose+0xc8>
    647c:	38616881 	ldrb	w1, [x4, x1]
    6480:	7100083f 	cmp	w1, #0x2
    6484:	54000280 	b.eq	64d4 <fwp_task_dispose+0xe4>  // b.none
    6488:	7100043f 	cmp	w1, #0x1
    648c:	54000161 	b.ne	64b8 <fwp_task_dispose+0xc8>  // b.any
    6490:	29430464 	ldp	w4, w1, [x3, #24]
    6494:	92403c00 	and	x0, x0, #0xffff
    6498:	9b047c00 	mul	x0, x0, x4
    649c:	d360fc00 	lsr	x0, x0, #32
    64a0:	eb01001f 	cmp	x0, x1
    64a4:	540000a2 	b.cs	64b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    64a8:	8b000042 	add	x2, x2, x0
    64ac:	39400040 	ldrb	w0, [x2]
    64b0:	7100041f 	cmp	w0, #0x1
    64b4:	54000080 	b.eq	64c4 <fwp_task_dispose+0xd4>  // b.none
    64b8:	f9400bf3 	ldr	x19, [sp, #16]
    64bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64c0:	d65f03c0 	ret
    64c4:	aa1303e0 	mov	x0, x19
    64c8:	f9400bf3 	ldr	x19, [sp, #16]
    64cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64d0:	17fff968 	b	4a70 <fwp_mem_free>
    64d4:	72003c1f 	tst	w0, #0xffff
    64d8:	54fffea0 	b.eq	64ac <fwp_task_dispose+0xbc>  // b.none
    64dc:	f9400bf3 	ldr	x19, [sp, #16]
    64e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64e4:	d65f03c0 	ret
    64e8:	97fff0fa 	bl	28d0 <abort@plt>
    64ec:	d503201f 	nop

00000000000064f0 <fwp_free_zombie>:
    64f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64f4:	910003fd 	mov	x29, sp
    64f8:	a90153f3 	stp	x19, x20, [sp, #16]
    64fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6500:	9101c281 	add	x1, x20, #0x70
    6504:	f9407833 	ldr	x19, [x1, #240]
    6508:	b4000333 	cbz	x19, 656c <fwp_free_zombie+0x7c>
    650c:	f9400820 	ldr	x0, [x1, #16]
    6510:	eb00027f 	cmp	x19, x0
    6514:	540002c0 	b.eq	656c <fwp_free_zombie+0x7c>  // b.none
    6518:	b940f822 	ldr	w2, [x1, #248]
    651c:	f9400a60 	ldr	x0, [x19, #16]
    6520:	7100fc5f 	cmp	w2, #0x3f
    6524:	5400078c 	b.gt	6614 <fwp_free_zombie+0x124>
    6528:	91040023 	add	x3, x1, #0x100
    652c:	11000444 	add	w4, w2, #0x1
    6530:	b900f824 	str	w4, [x1, #248]
    6534:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6538:	f822d860 	str	x0, [x3, w2, sxtw #3]
    653c:	a9530261 	ldp	x1, x0, [x19, #304]
    6540:	b4000741 	cbz	x1, 6628 <fwp_free_zombie+0x138>
    6544:	f9009c20 	str	x0, [x1, #312]
    6548:	b4000040 	cbz	x0, 6550 <fwp_free_zombie+0x60>
    654c:	f9009801 	str	x1, [x0, #304]
    6550:	9101c294 	add	x20, x20, #0x70
    6554:	b9405e60 	ldr	w0, [x19, #92]
    6558:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    655c:	f9007a9f 	str	xzr, [x20, #240]
    6560:	34000140 	cbz	w0, 6588 <fwp_free_zombie+0x98>
    6564:	7100041f 	cmp	w0, #0x1
    6568:	54000080 	b.eq	6578 <fwp_free_zombie+0x88>  // b.none
    656c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6570:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6574:	d65f03c0 	ret
    6578:	aa1303e0 	mov	x0, x19
    657c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6580:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6584:	17ffff9b 	b	63f0 <fwp_task_dispose>
    6588:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    658c:	91174082 	add	x2, x4, #0x5d0
    6590:	f949d841 	ldr	x1, [x2, #5040]
    6594:	f949ec40 	ldr	x0, [x2, #5080]
    6598:	cb010261 	sub	x1, x19, x1
    659c:	eb00403f 	cmp	x1, x0, lsl #16
    65a0:	54fffe62 	b.cs	656c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    65a4:	d350fc20 	lsr	x0, x1, #16
    65a8:	f949fc43 	ldr	x3, [x2, #5112]
    65ac:	8b000800 	add	x0, x0, x0, lsl #2
    65b0:	d37df000 	lsl	x0, x0, #3
    65b4:	8b000062 	add	x2, x3, x0
    65b8:	f9401054 	ldr	x20, [x2, #32]
    65bc:	b4fffd94 	cbz	x20, 656c <fwp_free_zombie+0x7c>
    65c0:	38606860 	ldrb	w0, [x3, x0]
    65c4:	7100081f 	cmp	w0, #0x2
    65c8:	54000360 	b.eq	6634 <fwp_free_zombie+0x144>  // b.none
    65cc:	7100041f 	cmp	w0, #0x1
    65d0:	54fffce1 	b.ne	656c <fwp_free_zombie+0x7c>  // b.any
    65d4:	29430043 	ldp	w3, w0, [x2, #24]
    65d8:	92403c21 	and	x1, x1, #0xffff
    65dc:	9b037c21 	mul	x1, x1, x3
    65e0:	d360fc21 	lsr	x1, x1, #32
    65e4:	eb00003f 	cmp	x1, x0
    65e8:	54fffc22 	b.cs	656c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    65ec:	8b010294 	add	x20, x20, x1
    65f0:	39400280 	ldrb	w0, [x20]
    65f4:	34fffbc0 	cbz	w0, 656c <fwp_free_zombie+0x7c>
    65f8:	7100041f 	cmp	w0, #0x1
    65fc:	54fffbe0 	b.eq	6578 <fwp_free_zombie+0x88>  // b.none
    6600:	7103fc1f 	cmp	w0, #0xff
    6604:	540001e0 	b.eq	6640 <fwp_free_zombie+0x150>  // b.none
    6608:	51000400 	sub	w0, w0, #0x1
    660c:	39000280 	strb	w0, [x20]
    6610:	17ffffd7 	b	656c <fwp_free_zombie+0x7c>
    6614:	f9400e61 	ldr	x1, [x19, #24]
    6618:	97fff0e2 	bl	29a0 <munmap@plt>
    661c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6620:	a9530261 	ldp	x1, x0, [x19, #304]
    6624:	b5fff901 	cbnz	x1, 6544 <fwp_free_zombie+0x54>
    6628:	9101c282 	add	x2, x20, #0x70
    662c:	f9018040 	str	x0, [x2, #768]
    6630:	17ffffc6 	b	6548 <fwp_free_zombie+0x58>
    6634:	72003c3f 	tst	w1, #0xffff
    6638:	54fff9a1 	b.ne	656c <fwp_free_zombie+0x7c>  // b.any
    663c:	17ffffed 	b	65f0 <fwp_free_zombie+0x100>
    6640:	ca544680 	eor	x0, x20, x20, lsr #17
    6644:	91174084 	add	x4, x4, #0x5d0
    6648:	ca402400 	eor	x0, x0, x0, lsr #9
    664c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6650:	f94a2400 	ldr	x0, [x0, #5192]
    6654:	b5000080 	cbnz	x0, 6664 <fwp_free_zombie+0x174>
    6658:	14000010 	b	6698 <fwp_free_zombie+0x1a8>
    665c:	f9400800 	ldr	x0, [x0, #16]
    6660:	b40001c0 	cbz	x0, 6698 <fwp_free_zombie+0x1a8>
    6664:	f9400001 	ldr	x1, [x0]
    6668:	eb14003f 	cmp	x1, x20
    666c:	54ffff81 	b.ne	665c <fwp_free_zombie+0x16c>  // b.any
    6670:	f9400401 	ldr	x1, [x0, #8]
    6674:	d1000421 	sub	x1, x1, #0x1
    6678:	f9000401 	str	x1, [x0, #8]
    667c:	f103f83f 	cmp	x1, #0xfe
    6680:	54fff761 	b.ne	656c <fwp_free_zombie+0x7c>  // b.any
    6684:	aa1403e0 	mov	x0, x20
    6688:	97fff85a 	bl	47f0 <fwp_rc_forget_slot>
    668c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6690:	39000280 	strb	w0, [x20]
    6694:	17ffffb6 	b	656c <fwp_free_zombie+0x7c>
    6698:	f0000020 	adrp	x0, d000 <__divti3+0x2d0>
    669c:	911ec000 	add	x0, x0, #0x7b0
    66a0:	97fff458 	bl	3800 <fwp_trap>

00000000000066a4 <fwp_block>:
    66a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66a8:	910003fd 	mov	x29, sp
    66ac:	a90153f3 	stp	x19, x20, [sp, #16]
    66b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    66b4:	9101c274 	add	x20, x19, #0x70
    66b8:	f9404282 	ldr	x2, [x20, #128]
    66bc:	b4000622 	cbz	x2, 6780 <fwp_block+0xdc>
    66c0:	9101c261 	add	x1, x19, #0x70
    66c4:	f9408040 	ldr	x0, [x2, #256]
    66c8:	f9004020 	str	x0, [x1, #128]
    66cc:	b4000680 	cbz	x0, 679c <fwp_block+0xf8>
    66d0:	9101c263 	add	x3, x19, #0x70
    66d4:	3901505f 	strb	wzr, [x2, #84]
    66d8:	f9400864 	ldr	x4, [x3, #16]
    66dc:	eb02009f 	cmp	x4, x2
    66e0:	54000440 	b.eq	6768 <fwp_block+0xc4>  // b.none
    66e4:	f9418465 	ldr	x5, [x3, #776]
    66e8:	f9000862 	str	x2, [x3, #16]
    66ec:	f9400441 	ldr	x1, [x2, #8]
    66f0:	f9004885 	str	x5, [x4, #144]
    66f4:	f9418865 	ldr	x5, [x3, #784]
    66f8:	f9004c85 	str	x5, [x4, #152]
    66fc:	f9418c65 	ldr	x5, [x3, #792]
    6700:	f9005085 	str	x5, [x4, #160]
    6704:	f9419065 	ldr	x5, [x3, #800]
    6708:	f9005485 	str	x5, [x4, #168]
    670c:	f9419465 	ldr	x5, [x3, #808]
    6710:	f9005885 	str	x5, [x4, #176]
    6714:	f9419865 	ldr	x5, [x3, #816]
    6718:	f9005c85 	str	x5, [x4, #184]
    671c:	f9419c65 	ldr	x5, [x3, #824]
    6720:	f9006085 	str	x5, [x4, #192]
    6724:	f9400480 	ldr	x0, [x4, #8]
    6728:	f9404844 	ldr	x4, [x2, #144]
    672c:	f9018464 	str	x4, [x3, #776]
    6730:	f9404c44 	ldr	x4, [x2, #152]
    6734:	f9018864 	str	x4, [x3, #784]
    6738:	f9405044 	ldr	x4, [x2, #160]
    673c:	f9018c64 	str	x4, [x3, #792]
    6740:	f9405444 	ldr	x4, [x2, #168]
    6744:	f9019064 	str	x4, [x3, #800]
    6748:	f9405844 	ldr	x4, [x2, #176]
    674c:	f9019464 	str	x4, [x3, #808]
    6750:	a94b8844 	ldp	x4, x2, [x2, #184]
    6754:	f9019864 	str	x4, [x3, #816]
    6758:	f9019c62 	str	x2, [x3, #824]
    675c:	97fff061 	bl	28e0 <swapcontext@plt>
    6760:	97ffff64 	bl	64f0 <fwp_free_zombie>
    6764:	d503201f 	nop
    6768:	9101c260 	add	x0, x19, #0x70
    676c:	b9434000 	ldr	w0, [x0, #832]
    6770:	340001a0 	cbz	w0, 67a4 <fwp_block+0x100>
    6774:	a94153f3 	ldp	x19, x20, [sp, #16]
    6778:	a8c27bfd 	ldp	x29, x30, [sp], #32
    677c:	d65f03c0 	ret
    6780:	97fff748 	bl	44a0 <fwp_poll_events>
    6784:	f9404282 	ldr	x2, [x20, #128]
    6788:	b4ffffc2 	cbz	x2, 6780 <fwp_block+0xdc>
    678c:	9101c261 	add	x1, x19, #0x70
    6790:	f9408040 	ldr	x0, [x2, #256]
    6794:	f9004020 	str	x0, [x1, #128]
    6798:	b5fff9c0 	cbnz	x0, 66d0 <fwp_block+0x2c>
    679c:	f9003c3f 	str	xzr, [x1, #120]
    67a0:	17ffffcc 	b	66d0 <fwp_block+0x2c>
    67a4:	f0000020 	adrp	x0, d000 <__divti3+0x2d0>
    67a8:	91238000 	add	x0, x0, #0x8e0
    67ac:	97fff099 	bl	2a10 <getenv@plt>
    67b0:	5284e202 	mov	w2, #0x2710                	// #10000
    67b4:	b4000060 	cbz	x0, 67c0 <fwp_block+0x11c>
    67b8:	39400001 	ldrb	w1, [x0]
    67bc:	350000c1 	cbnz	w1, 67d4 <fwp_block+0x130>
    67c0:	9101c273 	add	x19, x19, #0x70
    67c4:	b9034262 	str	w2, [x19, #832]
    67c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67d0:	d65f03c0 	ret
    67d4:	52800142 	mov	w2, #0xa                   	// #10
    67d8:	d2800001 	mov	x1, #0x0                   	// #0
    67dc:	97ffefdd 	bl	2750 <strtoll@plt>
    67e0:	d1000403 	sub	x3, x0, #0x1
    67e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    67e8:	eb02007f 	cmp	x3, x2
    67ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    67f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    67f4:	17fffff3 	b	67c0 <fwp_block+0x11c>
    67f8:	d503201f 	nop
    67fc:	d503201f 	nop

0000000000006800 <fwp_drop4>:
    6800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6804:	910003fd 	mov	x29, sp
    6808:	a90153f3 	stp	x19, x20, [sp, #16]
    680c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6810:	f90013f5 	str	x21, [sp, #32]
    6814:	91174275 	add	x21, x19, #0x5d0
    6818:	f949daa1 	ldr	x1, [x21, #5040]
    681c:	f949eea2 	ldr	x2, [x21, #5080]
    6820:	cb010001 	sub	x1, x0, x1
    6824:	eb02403f 	cmp	x1, x2, lsl #16
    6828:	54000382 	b.cs	6898 <fwp_drop4+0x98>  // b.hs, b.nlast
    682c:	d350fc22 	lsr	x2, x1, #16
    6830:	f949fea3 	ldr	x3, [x21, #5112]
    6834:	8b020842 	add	x2, x2, x2, lsl #2
    6838:	d37df042 	lsl	x2, x2, #3
    683c:	8b020064 	add	x4, x3, x2
    6840:	f9401094 	ldr	x20, [x4, #32]
    6844:	b40002b4 	cbz	x20, 6898 <fwp_drop4+0x98>
    6848:	38626862 	ldrb	w2, [x3, x2]
    684c:	7100085f 	cmp	w2, #0x2
    6850:	540007a0 	b.eq	6944 <fwp_drop4+0x144>  // b.none
    6854:	7100045f 	cmp	w2, #0x1
    6858:	54000201 	b.ne	6898 <fwp_drop4+0x98>  // b.any
    685c:	29430885 	ldp	w5, w2, [x4, #24]
    6860:	92403c21 	and	x1, x1, #0xffff
    6864:	9b057c21 	mul	x1, x1, x5
    6868:	d360fc21 	lsr	x1, x1, #32
    686c:	eb02003f 	cmp	x1, x2
    6870:	54000142 	b.cs	6898 <fwp_drop4+0x98>  // b.hs, b.nlast
    6874:	8b010294 	add	x20, x20, x1
    6878:	39400281 	ldrb	w1, [x20]
    687c:	340000e1 	cbz	w1, 6898 <fwp_drop4+0x98>
    6880:	7100043f 	cmp	w1, #0x1
    6884:	54000120 	b.eq	68a8 <fwp_drop4+0xa8>  // b.none
    6888:	7103fc3f 	cmp	w1, #0xff
    688c:	540007c0 	b.eq	6984 <fwp_drop4+0x184>  // b.none
    6890:	51000421 	sub	w1, w1, #0x1
    6894:	39000281 	strb	w1, [x20]
    6898:	a94153f3 	ldp	x19, x20, [sp, #16]
    689c:	f94013f5 	ldr	x21, [sp, #32]
    68a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    68a4:	d65f03c0 	ret
    68a8:	f9400001 	ldr	x1, [x0]
    68ac:	b7f80581 	tbnz	x1, #63, 695c <fwp_drop4+0x15c>
    68b0:	91174273 	add	x19, x19, #0x5d0
    68b4:	f949da61 	ldr	x1, [x19, #5040]
    68b8:	f949ee62 	ldr	x2, [x19, #5080]
    68bc:	cb010001 	sub	x1, x0, x1
    68c0:	eb02403f 	cmp	x1, x2, lsl #16
    68c4:	54fffea2 	b.cs	6898 <fwp_drop4+0x98>  // b.hs, b.nlast
    68c8:	d350fc22 	lsr	x2, x1, #16
    68cc:	8b020842 	add	x2, x2, x2, lsl #2
    68d0:	d37df042 	lsl	x2, x2, #3
    68d4:	8b020065 	add	x5, x3, x2
    68d8:	f94010a4 	ldr	x4, [x5, #32]
    68dc:	b4fffde4 	cbz	x4, 6898 <fwp_drop4+0x98>
    68e0:	38626862 	ldrb	w2, [x3, x2]
    68e4:	7100085f 	cmp	w2, #0x2
    68e8:	54000220 	b.eq	692c <fwp_drop4+0x12c>  // b.none
    68ec:	7100045f 	cmp	w2, #0x1
    68f0:	54fffd41 	b.ne	6898 <fwp_drop4+0x98>  // b.any
    68f4:	294308a3 	ldp	w3, w2, [x5, #24]
    68f8:	92403c21 	and	x1, x1, #0xffff
    68fc:	9b037c21 	mul	x1, x1, x3
    6900:	d360fc21 	lsr	x1, x1, #32
    6904:	eb02003f 	cmp	x1, x2
    6908:	54fffc82 	b.cs	6898 <fwp_drop4+0x98>  // b.hs, b.nlast
    690c:	8b010084 	add	x4, x4, x1
    6910:	39400081 	ldrb	w1, [x4]
    6914:	7100043f 	cmp	w1, #0x1
    6918:	54fffc01 	b.ne	6898 <fwp_drop4+0x98>  // b.any
    691c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6920:	f94013f5 	ldr	x21, [sp, #32]
    6924:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6928:	17fff852 	b	4a70 <fwp_mem_free>
    692c:	72003c3f 	tst	w1, #0xffff
    6930:	54ffff00 	b.eq	6910 <fwp_drop4+0x110>  // b.none
    6934:	a94153f3 	ldp	x19, x20, [sp, #16]
    6938:	f94013f5 	ldr	x21, [sp, #32]
    693c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6940:	d65f03c0 	ret
    6944:	72003c3f 	tst	w1, #0xffff
    6948:	54fff980 	b.eq	6878 <fwp_drop4+0x78>  // b.none
    694c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6950:	f94013f5 	ldr	x21, [sp, #32]
    6954:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6958:	d65f03c0 	ret
    695c:	f9400414 	ldr	x20, [x0, #8]
    6960:	97fffbed 	bl	5914 <fwp_rc_free_arr>
    6964:	91174260 	add	x0, x19, #0x5d0
    6968:	f949d801 	ldr	x1, [x0, #5040]
    696c:	f949ec00 	ldr	x0, [x0, #5080]
    6970:	cb010281 	sub	x1, x20, x1
    6974:	eb00403f 	cmp	x1, x0, lsl #16
    6978:	54fff902 	b.cs	6898 <fwp_drop4+0x98>  // b.hs, b.nlast
    697c:	aa1403e0 	mov	x0, x20
    6980:	17ffffab 	b	682c <fwp_drop4+0x2c>
    6984:	ca544680 	eor	x0, x20, x20, lsr #17
    6988:	91174273 	add	x19, x19, #0x5d0
    698c:	ca402400 	eor	x0, x0, x0, lsr #9
    6990:	8b200e60 	add	x0, x19, w0, uxtb #3
    6994:	f94a2400 	ldr	x0, [x0, #5192]
    6998:	b5000080 	cbnz	x0, 69a8 <fwp_drop4+0x1a8>
    699c:	14000010 	b	69dc <fwp_drop4+0x1dc>
    69a0:	f9400800 	ldr	x0, [x0, #16]
    69a4:	b40001c0 	cbz	x0, 69dc <fwp_drop4+0x1dc>
    69a8:	f9400001 	ldr	x1, [x0]
    69ac:	eb14003f 	cmp	x1, x20
    69b0:	54ffff81 	b.ne	69a0 <fwp_drop4+0x1a0>  // b.any
    69b4:	f9400401 	ldr	x1, [x0, #8]
    69b8:	d1000421 	sub	x1, x1, #0x1
    69bc:	f9000401 	str	x1, [x0, #8]
    69c0:	f103f83f 	cmp	x1, #0xfe
    69c4:	54fff6a1 	b.ne	6898 <fwp_drop4+0x98>  // b.any
    69c8:	aa1403e0 	mov	x0, x20
    69cc:	97fff789 	bl	47f0 <fwp_rc_forget_slot>
    69d0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69d4:	39000280 	strb	w0, [x20]
    69d8:	17ffffb0 	b	6898 <fwp_drop4+0x98>
    69dc:	f0000020 	adrp	x0, d000 <__divti3+0x2d0>
    69e0:	911ec000 	add	x0, x0, #0x7b0
    69e4:	97fff387 	bl	3800 <fwp_trap>
    69e8:	d503201f 	nop
    69ec:	d503201f 	nop

00000000000069f0 <fwp_caps161>:
    69f0:	34000041 	cbz	w1, 69f8 <fwp_caps161+0x8>
    69f4:	d65f03c0 	ret
    69f8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    69fc:	91174063 	add	x3, x3, #0x5d0
    6a00:	f949d861 	ldr	x1, [x3, #5040]
    6a04:	f949ec62 	ldr	x2, [x3, #5080]
    6a08:	cb010001 	sub	x1, x0, x1
    6a0c:	eb02403f 	cmp	x1, x2, lsl #16
    6a10:	54ffff22 	b.cs	69f4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6a14:	d350fc22 	lsr	x2, x1, #16
    6a18:	f949fc65 	ldr	x5, [x3, #5112]
    6a1c:	8b020842 	add	x2, x2, x2, lsl #2
    6a20:	d37df042 	lsl	x2, x2, #3
    6a24:	8b0200a4 	add	x4, x5, x2
    6a28:	f9401083 	ldr	x3, [x4, #32]
    6a2c:	b4fffe43 	cbz	x3, 69f4 <fwp_caps161+0x4>
    6a30:	386268a2 	ldrb	w2, [x5, x2]
    6a34:	7100085f 	cmp	w2, #0x2
    6a38:	540001c0 	b.eq	6a70 <fwp_caps161+0x80>  // b.none
    6a3c:	7100045f 	cmp	w2, #0x1
    6a40:	54fffda1 	b.ne	69f4 <fwp_caps161+0x4>  // b.any
    6a44:	29430885 	ldp	w5, w2, [x4, #24]
    6a48:	92403c21 	and	x1, x1, #0xffff
    6a4c:	9b057c21 	mul	x1, x1, x5
    6a50:	d360fc21 	lsr	x1, x1, #32
    6a54:	eb02003f 	cmp	x1, x2
    6a58:	54fffce2 	b.cs	69f4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6a5c:	8b010063 	add	x3, x3, x1
    6a60:	39400061 	ldrb	w1, [x3]
    6a64:	7100043f 	cmp	w1, #0x1
    6a68:	54fffc61 	b.ne	69f4 <fwp_caps161+0x4>  // b.any
    6a6c:	17fff801 	b	4a70 <fwp_mem_free>
    6a70:	72003c3f 	tst	w1, #0xffff
    6a74:	54ffff60 	b.eq	6a60 <fwp_caps161+0x70>  // b.none
    6a78:	d65f03c0 	ret
    6a7c:	d503201f 	nop

0000000000006a80 <fwp_args12>:
    6a80:	7100003f 	cmp	w1, #0x0
    6a84:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6a88:	54000041 	b.ne	6a90 <fwp_args12+0x10>  // b.any
    6a8c:	d65f03c0 	ret
    6a90:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6a94:	91174042 	add	x2, x2, #0x5d0
    6a98:	f9400001 	ldr	x1, [x0]
    6a9c:	f949d843 	ldr	x3, [x2, #5040]
    6aa0:	f949ec40 	ldr	x0, [x2, #5080]
    6aa4:	cb030021 	sub	x1, x1, x3
    6aa8:	eb00403f 	cmp	x1, x0, lsl #16
    6aac:	54ffff02 	b.cs	6a8c <fwp_args12+0xc>  // b.hs, b.nlast
    6ab0:	d350fc20 	lsr	x0, x1, #16
    6ab4:	f949fc44 	ldr	x4, [x2, #5112]
    6ab8:	8b000800 	add	x0, x0, x0, lsl #2
    6abc:	d37df002 	lsl	x2, x0, #3
    6ac0:	8b020083 	add	x3, x4, x2
    6ac4:	f9401060 	ldr	x0, [x3, #32]
    6ac8:	b4fffe20 	cbz	x0, 6a8c <fwp_args12+0xc>
    6acc:	38626882 	ldrb	w2, [x4, x2]
    6ad0:	7100085f 	cmp	w2, #0x2
    6ad4:	54000220 	b.eq	6b18 <fwp_args12+0x98>  // b.none
    6ad8:	7100045f 	cmp	w2, #0x1
    6adc:	54fffd81 	b.ne	6a8c <fwp_args12+0xc>  // b.any
    6ae0:	29430864 	ldp	w4, w2, [x3, #24]
    6ae4:	92403c21 	and	x1, x1, #0xffff
    6ae8:	9b047c21 	mul	x1, x1, x4
    6aec:	d360fc21 	lsr	x1, x1, #32
    6af0:	eb02003f 	cmp	x1, x2
    6af4:	54fffcc2 	b.cs	6a8c <fwp_args12+0xc>  // b.hs, b.nlast
    6af8:	8b010000 	add	x0, x0, x1
    6afc:	39400001 	ldrb	w1, [x0]
    6b00:	34fffc61 	cbz	w1, 6a8c <fwp_args12+0xc>
    6b04:	7103f43f 	cmp	w1, #0xfd
    6b08:	540000e8 	b.hi	6b24 <fwp_args12+0xa4>  // b.pmore
    6b0c:	11000421 	add	w1, w1, #0x1
    6b10:	39000001 	strb	w1, [x0]
    6b14:	d65f03c0 	ret
    6b18:	72003c3f 	tst	w1, #0xffff
    6b1c:	54ffff00 	b.eq	6afc <fwp_args12+0x7c>  // b.none
    6b20:	d65f03c0 	ret
    6b24:	17fff6ec 	b	46d4 <fwp_rc_wide_dup>
    6b28:	d503201f 	nop
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_args23>:
    6b30:	7100003f 	cmp	w1, #0x0
    6b34:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b38:	54000041 	b.ne	6b40 <fwp_args23+0x10>  // b.any
    6b3c:	d65f03c0 	ret
    6b40:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6b44:	91174042 	add	x2, x2, #0x5d0
    6b48:	f9400001 	ldr	x1, [x0]
    6b4c:	f949d843 	ldr	x3, [x2, #5040]
    6b50:	f949ec40 	ldr	x0, [x2, #5080]
    6b54:	cb030021 	sub	x1, x1, x3
    6b58:	eb00403f 	cmp	x1, x0, lsl #16
    6b5c:	54ffff02 	b.cs	6b3c <fwp_args23+0xc>  // b.hs, b.nlast
    6b60:	d350fc20 	lsr	x0, x1, #16
    6b64:	f949fc44 	ldr	x4, [x2, #5112]
    6b68:	8b000800 	add	x0, x0, x0, lsl #2
    6b6c:	d37df002 	lsl	x2, x0, #3
    6b70:	8b020083 	add	x3, x4, x2
    6b74:	f9401060 	ldr	x0, [x3, #32]
    6b78:	b4fffe20 	cbz	x0, 6b3c <fwp_args23+0xc>
    6b7c:	38626882 	ldrb	w2, [x4, x2]
    6b80:	7100085f 	cmp	w2, #0x2
    6b84:	54000220 	b.eq	6bc8 <fwp_args23+0x98>  // b.none
    6b88:	7100045f 	cmp	w2, #0x1
    6b8c:	54fffd81 	b.ne	6b3c <fwp_args23+0xc>  // b.any
    6b90:	29430864 	ldp	w4, w2, [x3, #24]
    6b94:	92403c21 	and	x1, x1, #0xffff
    6b98:	9b047c21 	mul	x1, x1, x4
    6b9c:	d360fc21 	lsr	x1, x1, #32
    6ba0:	eb02003f 	cmp	x1, x2
    6ba4:	54fffcc2 	b.cs	6b3c <fwp_args23+0xc>  // b.hs, b.nlast
    6ba8:	8b010000 	add	x0, x0, x1
    6bac:	39400001 	ldrb	w1, [x0]
    6bb0:	34fffc61 	cbz	w1, 6b3c <fwp_args23+0xc>
    6bb4:	7103f43f 	cmp	w1, #0xfd
    6bb8:	540000e8 	b.hi	6bd4 <fwp_args23+0xa4>  // b.pmore
    6bbc:	11000421 	add	w1, w1, #0x1
    6bc0:	39000001 	strb	w1, [x0]
    6bc4:	d65f03c0 	ret
    6bc8:	72003c3f 	tst	w1, #0xffff
    6bcc:	54ffff00 	b.eq	6bac <fwp_args23+0x7c>  // b.none
    6bd0:	d65f03c0 	ret
    6bd4:	17fff6c0 	b	46d4 <fwp_rc_wide_dup>
    6bd8:	d503201f 	nop
    6bdc:	d503201f 	nop

0000000000006be0 <fwp_caps12>:
    6be0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6be4:	910003fd 	mov	x29, sp
    6be8:	f9000bf3 	str	x19, [sp, #16]
    6bec:	aa0003f3 	mov	x19, x0
    6bf0:	b9400400 	ldr	w0, [x0, #4]
    6bf4:	340004a0 	cbz	w0, 6c88 <fwp_caps12+0xa8>
    6bf8:	f9400660 	ldr	x0, [x19, #8]
    6bfc:	350004e1 	cbnz	w1, 6c98 <fwp_caps12+0xb8>
    6c00:	97fffc70 	bl	5dc0 <fwp_drop0>
    6c04:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6c08:	91174042 	add	x2, x2, #0x5d0
    6c0c:	f949d840 	ldr	x0, [x2, #5040]
    6c10:	f949ec41 	ldr	x1, [x2, #5080]
    6c14:	cb000260 	sub	x0, x19, x0
    6c18:	eb01401f 	cmp	x0, x1, lsl #16
    6c1c:	54000382 	b.cs	6c8c <fwp_caps12+0xac>  // b.hs, b.nlast
    6c20:	d350fc01 	lsr	x1, x0, #16
    6c24:	f949fc44 	ldr	x4, [x2, #5112]
    6c28:	8b010821 	add	x1, x1, x1, lsl #2
    6c2c:	d37df021 	lsl	x1, x1, #3
    6c30:	8b010083 	add	x3, x4, x1
    6c34:	f9401062 	ldr	x2, [x3, #32]
    6c38:	b40002a2 	cbz	x2, 6c8c <fwp_caps12+0xac>
    6c3c:	38616881 	ldrb	w1, [x4, x1]
    6c40:	7100083f 	cmp	w1, #0x2
    6c44:	540006c0 	b.eq	6d1c <fwp_caps12+0x13c>  // b.none
    6c48:	7100043f 	cmp	w1, #0x1
    6c4c:	54000201 	b.ne	6c8c <fwp_caps12+0xac>  // b.any
    6c50:	29430464 	ldp	w4, w1, [x3, #24]
    6c54:	92403c00 	and	x0, x0, #0xffff
    6c58:	9b047c00 	mul	x0, x0, x4
    6c5c:	d360fc00 	lsr	x0, x0, #32
    6c60:	eb01001f 	cmp	x0, x1
    6c64:	54000142 	b.cs	6c8c <fwp_caps12+0xac>  // b.hs, b.nlast
    6c68:	8b000042 	add	x2, x2, x0
    6c6c:	39400040 	ldrb	w0, [x2]
    6c70:	7100041f 	cmp	w0, #0x1
    6c74:	540000c1 	b.ne	6c8c <fwp_caps12+0xac>  // b.any
    6c78:	aa1303e0 	mov	x0, x19
    6c7c:	f9400bf3 	ldr	x19, [sp, #16]
    6c80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c84:	17fff77b 	b	4a70 <fwp_mem_free>
    6c88:	34fffbe1 	cbz	w1, 6c04 <fwp_caps12+0x24>
    6c8c:	f9400bf3 	ldr	x19, [sp, #16]
    6c90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c94:	d65f03c0 	ret
    6c98:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6c9c:	91174042 	add	x2, x2, #0x5d0
    6ca0:	f949d843 	ldr	x3, [x2, #5040]
    6ca4:	f949ec41 	ldr	x1, [x2, #5080]
    6ca8:	cb030000 	sub	x0, x0, x3
    6cac:	eb01401f 	cmp	x0, x1, lsl #16
    6cb0:	54fffee2 	b.cs	6c8c <fwp_caps12+0xac>  // b.hs, b.nlast
    6cb4:	d350fc01 	lsr	x1, x0, #16
    6cb8:	f949fc44 	ldr	x4, [x2, #5112]
    6cbc:	8b010821 	add	x1, x1, x1, lsl #2
    6cc0:	d37df021 	lsl	x1, x1, #3
    6cc4:	8b010083 	add	x3, x4, x1
    6cc8:	f9401062 	ldr	x2, [x3, #32]
    6ccc:	b4fffe02 	cbz	x2, 6c8c <fwp_caps12+0xac>
    6cd0:	38616881 	ldrb	w1, [x4, x1]
    6cd4:	7100083f 	cmp	w1, #0x2
    6cd8:	54000280 	b.eq	6d28 <fwp_caps12+0x148>  // b.none
    6cdc:	7100043f 	cmp	w1, #0x1
    6ce0:	54fffd61 	b.ne	6c8c <fwp_caps12+0xac>  // b.any
    6ce4:	92403c01 	and	x1, x0, #0xffff
    6ce8:	29430064 	ldp	w4, w0, [x3, #24]
    6cec:	9b047c21 	mul	x1, x1, x4
    6cf0:	d360fc21 	lsr	x1, x1, #32
    6cf4:	eb00003f 	cmp	x1, x0
    6cf8:	54fffca2 	b.cs	6c8c <fwp_caps12+0xac>  // b.hs, b.nlast
    6cfc:	8b010042 	add	x2, x2, x1
    6d00:	39400040 	ldrb	w0, [x2]
    6d04:	34fffc40 	cbz	w0, 6c8c <fwp_caps12+0xac>
    6d08:	7103f41f 	cmp	w0, #0xfd
    6d0c:	54000148 	b.hi	6d34 <fwp_caps12+0x154>  // b.pmore
    6d10:	11000400 	add	w0, w0, #0x1
    6d14:	39000040 	strb	w0, [x2]
    6d18:	17ffffdd 	b	6c8c <fwp_caps12+0xac>
    6d1c:	72003c1f 	tst	w0, #0xffff
    6d20:	54fffb61 	b.ne	6c8c <fwp_caps12+0xac>  // b.any
    6d24:	17ffffd2 	b	6c6c <fwp_caps12+0x8c>
    6d28:	72003c1f 	tst	w0, #0xffff
    6d2c:	54fffb01 	b.ne	6c8c <fwp_caps12+0xac>  // b.any
    6d30:	17fffff4 	b	6d00 <fwp_caps12+0x120>
    6d34:	f9400bf3 	ldr	x19, [sp, #16]
    6d38:	aa0203e0 	mov	x0, x2
    6d3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d40:	17fff665 	b	46d4 <fwp_rc_wide_dup>

0000000000006d44 <fwp_drop2>:
    6d44:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6d48:	910003fd 	mov	x29, sp
    6d4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6d50:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6d54:	911742d5 	add	x21, x22, #0x5d0
    6d58:	a90153f3 	stp	x19, x20, [sp, #16]
    6d5c:	aa0003f3 	mov	x19, x0
    6d60:	f949daa1 	ldr	x1, [x21, #5040]
    6d64:	f949eea0 	ldr	x0, [x21, #5080]
    6d68:	cb010261 	sub	x1, x19, x1
    6d6c:	eb00403f 	cmp	x1, x0, lsl #16
    6d70:	54000382 	b.cs	6de0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6d74:	d350fc22 	lsr	x2, x1, #16
    6d78:	f949fea3 	ldr	x3, [x21, #5112]
    6d7c:	8b020842 	add	x2, x2, x2, lsl #2
    6d80:	d37df042 	lsl	x2, x2, #3
    6d84:	8b020060 	add	x0, x3, x2
    6d88:	f9401014 	ldr	x20, [x0, #32]
    6d8c:	b40002b4 	cbz	x20, 6de0 <fwp_drop2+0x9c>
    6d90:	38626862 	ldrb	w2, [x3, x2]
    6d94:	7100085f 	cmp	w2, #0x2
    6d98:	540002c0 	b.eq	6df0 <fwp_drop2+0xac>  // b.none
    6d9c:	7100045f 	cmp	w2, #0x1
    6da0:	54000201 	b.ne	6de0 <fwp_drop2+0x9c>  // b.any
    6da4:	29430002 	ldp	w2, w0, [x0, #24]
    6da8:	92403c21 	and	x1, x1, #0xffff
    6dac:	9b027c21 	mul	x1, x1, x2
    6db0:	d360fc21 	lsr	x1, x1, #32
    6db4:	eb00003f 	cmp	x1, x0
    6db8:	54000142 	b.cs	6de0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6dbc:	8b010294 	add	x20, x20, x1
    6dc0:	39400280 	ldrb	w0, [x20]
    6dc4:	340000e0 	cbz	w0, 6de0 <fwp_drop2+0x9c>
    6dc8:	7100041f 	cmp	w0, #0x1
    6dcc:	540001e0 	b.eq	6e08 <fwp_drop2+0xc4>  // b.none
    6dd0:	7103fc1f 	cmp	w0, #0xff
    6dd4:	540007e0 	b.eq	6ed0 <fwp_drop2+0x18c>  // b.none
    6dd8:	51000400 	sub	w0, w0, #0x1
    6ddc:	39000280 	strb	w0, [x20]
    6de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6de4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6de8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6dec:	d65f03c0 	ret
    6df0:	72003c3f 	tst	w1, #0xffff
    6df4:	54fffe60 	b.eq	6dc0 <fwp_drop2+0x7c>  // b.none
    6df8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6e00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e04:	d65f03c0 	ret
    6e08:	911742c2 	add	x2, x22, #0x5d0
    6e0c:	f9400660 	ldr	x0, [x19, #8]
    6e10:	f949d841 	ldr	x1, [x2, #5040]
    6e14:	f949ec42 	ldr	x2, [x2, #5080]
    6e18:	cb010001 	sub	x1, x0, x1
    6e1c:	eb02403f 	cmp	x1, x2, lsl #16
    6e20:	54000382 	b.cs	6e90 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6e24:	d350fc22 	lsr	x2, x1, #16
    6e28:	8b020842 	add	x2, x2, x2, lsl #2
    6e2c:	d37df042 	lsl	x2, x2, #3
    6e30:	8b020064 	add	x4, x3, x2
    6e34:	f9401094 	ldr	x20, [x4, #32]
    6e38:	b40002d4 	cbz	x20, 6e90 <fwp_drop2+0x14c>
    6e3c:	38626862 	ldrb	w2, [x3, x2]
    6e40:	7100085f 	cmp	w2, #0x2
    6e44:	54000400 	b.eq	6ec4 <fwp_drop2+0x180>  // b.none
    6e48:	7100045f 	cmp	w2, #0x1
    6e4c:	54000221 	b.ne	6e90 <fwp_drop2+0x14c>  // b.any
    6e50:	29430883 	ldp	w3, w2, [x4, #24]
    6e54:	92403c21 	and	x1, x1, #0xffff
    6e58:	9b037c21 	mul	x1, x1, x3
    6e5c:	d360fc21 	lsr	x1, x1, #32
    6e60:	eb02003f 	cmp	x1, x2
    6e64:	54000162 	b.cs	6e90 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6e68:	8b010294 	add	x20, x20, x1
    6e6c:	39400281 	ldrb	w1, [x20]
    6e70:	34000101 	cbz	w1, 6e90 <fwp_drop2+0x14c>
    6e74:	7100043f 	cmp	w1, #0x1
    6e78:	54000220 	b.eq	6ebc <fwp_drop2+0x178>  // b.none
    6e7c:	7103fc3f 	cmp	w1, #0xff
    6e80:	540005a0 	b.eq	6f34 <fwp_drop2+0x1f0>  // b.none
    6e84:	51000421 	sub	w1, w1, #0x1
    6e88:	39000281 	strb	w1, [x20]
    6e8c:	d503201f 	nop
    6e90:	f9400a74 	ldr	x20, [x19, #16]
    6e94:	aa1303e0 	mov	x0, x19
    6e98:	97fffa9f 	bl	5914 <fwp_rc_free_arr>
    6e9c:	911742c0 	add	x0, x22, #0x5d0
    6ea0:	f949d801 	ldr	x1, [x0, #5040]
    6ea4:	f949ec00 	ldr	x0, [x0, #5080]
    6ea8:	cb010281 	sub	x1, x20, x1
    6eac:	eb00403f 	cmp	x1, x0, lsl #16
    6eb0:	54fff982 	b.cs	6de0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6eb4:	aa1403f3 	mov	x19, x20
    6eb8:	17ffffaf 	b	6d74 <fwp_drop2+0x30>
    6ebc:	97fffa96 	bl	5914 <fwp_rc_free_arr>
    6ec0:	17fffff4 	b	6e90 <fwp_drop2+0x14c>
    6ec4:	72003c3f 	tst	w1, #0xffff
    6ec8:	54fffe41 	b.ne	6e90 <fwp_drop2+0x14c>  // b.any
    6ecc:	17ffffe8 	b	6e6c <fwp_drop2+0x128>
    6ed0:	ca544681 	eor	x1, x20, x20, lsr #17
    6ed4:	911742c0 	add	x0, x22, #0x5d0
    6ed8:	ca412421 	eor	x1, x1, x1, lsr #9
    6edc:	8b210c01 	add	x1, x0, w1, uxtb #3
    6ee0:	f94a2420 	ldr	x0, [x1, #5192]
    6ee4:	b5000080 	cbnz	x0, 6ef4 <fwp_drop2+0x1b0>
    6ee8:	14000010 	b	6f28 <fwp_drop2+0x1e4>
    6eec:	f9400800 	ldr	x0, [x0, #16]
    6ef0:	b40001c0 	cbz	x0, 6f28 <fwp_drop2+0x1e4>
    6ef4:	f9400001 	ldr	x1, [x0]
    6ef8:	eb14003f 	cmp	x1, x20
    6efc:	54ffff81 	b.ne	6eec <fwp_drop2+0x1a8>  // b.any
    6f00:	f9400401 	ldr	x1, [x0, #8]
    6f04:	d1000421 	sub	x1, x1, #0x1
    6f08:	f9000401 	str	x1, [x0, #8]
    6f0c:	f103f83f 	cmp	x1, #0xfe
    6f10:	54fff681 	b.ne	6de0 <fwp_drop2+0x9c>  // b.any
    6f14:	aa1403e0 	mov	x0, x20
    6f18:	97fff636 	bl	47f0 <fwp_rc_forget_slot>
    6f1c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f20:	39000280 	strb	w0, [x20]
    6f24:	17ffffaf 	b	6de0 <fwp_drop2+0x9c>
    6f28:	f0000020 	adrp	x0, d000 <__divti3+0x2d0>
    6f2c:	911ec000 	add	x0, x0, #0x7b0
    6f30:	97fff234 	bl	3800 <fwp_trap>
    6f34:	ca544680 	eor	x0, x20, x20, lsr #17
    6f38:	911742c1 	add	x1, x22, #0x5d0
    6f3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6f40:	8b200c20 	add	x0, x1, w0, uxtb #3
    6f44:	f94a2400 	ldr	x0, [x0, #5192]
    6f48:	b5000080 	cbnz	x0, 6f58 <fwp_drop2+0x214>
    6f4c:	17fffff7 	b	6f28 <fwp_drop2+0x1e4>
    6f50:	f9400800 	ldr	x0, [x0, #16]
    6f54:	b4fffea0 	cbz	x0, 6f28 <fwp_drop2+0x1e4>
    6f58:	f9400001 	ldr	x1, [x0]
    6f5c:	eb14003f 	cmp	x1, x20
    6f60:	54ffff81 	b.ne	6f50 <fwp_drop2+0x20c>  // b.any
    6f64:	f9400401 	ldr	x1, [x0, #8]
    6f68:	d1000421 	sub	x1, x1, #0x1
    6f6c:	f9000401 	str	x1, [x0, #8]
    6f70:	f103f83f 	cmp	x1, #0xfe
    6f74:	54fff8e1 	b.ne	6e90 <fwp_drop2+0x14c>  // b.any
    6f78:	aa1403e0 	mov	x0, x20
    6f7c:	97fff61d 	bl	47f0 <fwp_rc_forget_slot>
    6f80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f84:	39000280 	strb	w0, [x20]
    6f88:	17ffffc2 	b	6e90 <fwp_drop2+0x14c>
    6f8c:	d503201f 	nop

0000000000006f90 <fwp_arg_drop23>:
    6f90:	7100003f 	cmp	w1, #0x0
    6f94:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f98:	54000041 	b.ne	6fa0 <fwp_arg_drop23+0x10>  // b.any
    6f9c:	d65f03c0 	ret
    6fa0:	f9400000 	ldr	x0, [x0]
    6fa4:	17ffff68 	b	6d44 <fwp_drop2>
    6fa8:	d503201f 	nop
    6fac:	d503201f 	nop

0000000000006fb0 <fwp_caps23>:
    6fb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6fb4:	910003fd 	mov	x29, sp
    6fb8:	f9000bf3 	str	x19, [sp, #16]
    6fbc:	aa0003f3 	mov	x19, x0
    6fc0:	b9400400 	ldr	w0, [x0, #4]
    6fc4:	340004a0 	cbz	w0, 7058 <fwp_caps23+0xa8>
    6fc8:	f9400660 	ldr	x0, [x19, #8]
    6fcc:	350004e1 	cbnz	w1, 7068 <fwp_caps23+0xb8>
    6fd0:	97ffff5d 	bl	6d44 <fwp_drop2>
    6fd4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6fd8:	91174042 	add	x2, x2, #0x5d0
    6fdc:	f949d840 	ldr	x0, [x2, #5040]
    6fe0:	f949ec41 	ldr	x1, [x2, #5080]
    6fe4:	cb000260 	sub	x0, x19, x0
    6fe8:	eb01401f 	cmp	x0, x1, lsl #16
    6fec:	54000382 	b.cs	705c <fwp_caps23+0xac>  // b.hs, b.nlast
    6ff0:	d350fc01 	lsr	x1, x0, #16
    6ff4:	f949fc44 	ldr	x4, [x2, #5112]
    6ff8:	8b010821 	add	x1, x1, x1, lsl #2
    6ffc:	d37df021 	lsl	x1, x1, #3
    7000:	8b010083 	add	x3, x4, x1
    7004:	f9401062 	ldr	x2, [x3, #32]
    7008:	b40002a2 	cbz	x2, 705c <fwp_caps23+0xac>
    700c:	38616881 	ldrb	w1, [x4, x1]
    7010:	7100083f 	cmp	w1, #0x2
    7014:	540006c0 	b.eq	70ec <fwp_caps23+0x13c>  // b.none
    7018:	7100043f 	cmp	w1, #0x1
    701c:	54000201 	b.ne	705c <fwp_caps23+0xac>  // b.any
    7020:	29430464 	ldp	w4, w1, [x3, #24]
    7024:	92403c00 	and	x0, x0, #0xffff
    7028:	9b047c00 	mul	x0, x0, x4
    702c:	d360fc00 	lsr	x0, x0, #32
    7030:	eb01001f 	cmp	x0, x1
    7034:	54000142 	b.cs	705c <fwp_caps23+0xac>  // b.hs, b.nlast
    7038:	8b000042 	add	x2, x2, x0
    703c:	39400040 	ldrb	w0, [x2]
    7040:	7100041f 	cmp	w0, #0x1
    7044:	540000c1 	b.ne	705c <fwp_caps23+0xac>  // b.any
    7048:	aa1303e0 	mov	x0, x19
    704c:	f9400bf3 	ldr	x19, [sp, #16]
    7050:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7054:	17fff687 	b	4a70 <fwp_mem_free>
    7058:	34fffbe1 	cbz	w1, 6fd4 <fwp_caps23+0x24>
    705c:	f9400bf3 	ldr	x19, [sp, #16]
    7060:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7064:	d65f03c0 	ret
    7068:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    706c:	91174042 	add	x2, x2, #0x5d0
    7070:	f949d843 	ldr	x3, [x2, #5040]
    7074:	f949ec41 	ldr	x1, [x2, #5080]
    7078:	cb030000 	sub	x0, x0, x3
    707c:	eb01401f 	cmp	x0, x1, lsl #16
    7080:	54fffee2 	b.cs	705c <fwp_caps23+0xac>  // b.hs, b.nlast
    7084:	d350fc01 	lsr	x1, x0, #16
    7088:	f949fc44 	ldr	x4, [x2, #5112]
    708c:	8b010821 	add	x1, x1, x1, lsl #2
    7090:	d37df021 	lsl	x1, x1, #3
    7094:	8b010083 	add	x3, x4, x1
    7098:	f9401062 	ldr	x2, [x3, #32]
    709c:	b4fffe02 	cbz	x2, 705c <fwp_caps23+0xac>
    70a0:	38616881 	ldrb	w1, [x4, x1]
    70a4:	7100083f 	cmp	w1, #0x2
    70a8:	54000280 	b.eq	70f8 <fwp_caps23+0x148>  // b.none
    70ac:	7100043f 	cmp	w1, #0x1
    70b0:	54fffd61 	b.ne	705c <fwp_caps23+0xac>  // b.any
    70b4:	92403c01 	and	x1, x0, #0xffff
    70b8:	29430064 	ldp	w4, w0, [x3, #24]
    70bc:	9b047c21 	mul	x1, x1, x4
    70c0:	d360fc21 	lsr	x1, x1, #32
    70c4:	eb00003f 	cmp	x1, x0
    70c8:	54fffca2 	b.cs	705c <fwp_caps23+0xac>  // b.hs, b.nlast
    70cc:	8b010042 	add	x2, x2, x1
    70d0:	39400040 	ldrb	w0, [x2]
    70d4:	34fffc40 	cbz	w0, 705c <fwp_caps23+0xac>
    70d8:	7103f41f 	cmp	w0, #0xfd
    70dc:	54000148 	b.hi	7104 <fwp_caps23+0x154>  // b.pmore
    70e0:	11000400 	add	w0, w0, #0x1
    70e4:	39000040 	strb	w0, [x2]
    70e8:	17ffffdd 	b	705c <fwp_caps23+0xac>
    70ec:	72003c1f 	tst	w0, #0xffff
    70f0:	54fffb61 	b.ne	705c <fwp_caps23+0xac>  // b.any
    70f4:	17ffffd2 	b	703c <fwp_caps23+0x8c>
    70f8:	72003c1f 	tst	w0, #0xffff
    70fc:	54fffb01 	b.ne	705c <fwp_caps23+0xac>  // b.any
    7100:	17fffff4 	b	70d0 <fwp_caps23+0x120>
    7104:	f9400bf3 	ldr	x19, [sp, #16]
    7108:	aa0203e0 	mov	x0, x2
    710c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7110:	17fff571 	b	46d4 <fwp_rc_wide_dup>

0000000000007114 <f23>:
    7114:	d101c3ff 	sub	sp, sp, #0x70
    7118:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    711c:	f947f421 	ldr	x1, [x1, #4072]
    7120:	a9027bfd 	stp	x29, x30, [sp, #32]
    7124:	910083fd 	add	x29, sp, #0x20
    7128:	a90563f7 	stp	x23, x24, [sp, #80]
    712c:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    7130:	911742e3 	add	x3, x23, #0x5d0
    7134:	a90353f3 	stp	x19, x20, [sp, #48]
    7138:	a9045bf5 	stp	x21, x22, [sp, #64]
    713c:	aa0003f6 	mov	x22, x0
    7140:	a9066bf9 	stp	x25, x26, [sp, #96]
    7144:	f949ec62 	ldr	x2, [x3, #5080]
    7148:	f9400024 	ldr	x4, [x1]
    714c:	f9000fe4 	str	x4, [sp, #24]
    7150:	d2800004 	mov	x4, #0x0                   	// #0
    7154:	f949d861 	ldr	x1, [x3, #5040]
    7158:	d370bc42 	lsl	x2, x2, #16
    715c:	b40015a0 	cbz	x0, 7410 <f23+0x2fc>
    7160:	f9400818 	ldr	x24, [x0, #16]
    7164:	cb010301 	sub	x1, x24, x1
    7168:	eb02003f 	cmp	x1, x2
    716c:	54000362 	b.cs	71d8 <f23+0xc4>  // b.hs, b.nlast
    7170:	f949fc60 	ldr	x0, [x3, #5112]
    7174:	d350fc22 	lsr	x2, x1, #16
    7178:	8b020842 	add	x2, x2, x2, lsl #2
    717c:	8b020c02 	add	x2, x0, x2, lsl #3
    7180:	f9401040 	ldr	x0, [x2, #32]
    7184:	b40002a0 	cbz	x0, 71d8 <f23+0xc4>
    7188:	39400043 	ldrb	w3, [x2]
    718c:	7100087f 	cmp	w3, #0x2
    7190:	540013a0 	b.eq	7404 <f23+0x2f0>  // b.none
    7194:	7100047f 	cmp	w3, #0x1
    7198:	540001c1 	b.ne	71d0 <f23+0xbc>  // b.any
    719c:	29430843 	ldp	w3, w2, [x2, #24]
    71a0:	92403c21 	and	x1, x1, #0xffff
    71a4:	9b037c21 	mul	x1, x1, x3
    71a8:	d360fc21 	lsr	x1, x1, #32
    71ac:	eb02003f 	cmp	x1, x2
    71b0:	54000102 	b.cs	71d0 <f23+0xbc>  // b.hs, b.nlast
    71b4:	8b010000 	add	x0, x0, x1
    71b8:	39400001 	ldrb	w1, [x0]
    71bc:	340000a1 	cbz	w1, 71d0 <f23+0xbc>
    71c0:	7103f43f 	cmp	w1, #0xfd
    71c4:	54001688 	b.hi	7494 <f23+0x380>  // b.pmore
    71c8:	11000421 	add	w1, w1, #0x1
    71cc:	39000001 	strb	w1, [x0]
    71d0:	d2800000 	mov	x0, #0x0                   	// #0
    71d4:	b40000d6 	cbz	x22, 71ec <f23+0xd8>
    71d8:	aa1603e1 	mov	x1, x22
    71dc:	d2800000 	mov	x0, #0x0                   	// #0
    71e0:	f9400821 	ldr	x1, [x1, #16]
    71e4:	91000400 	add	x0, x0, #0x1
    71e8:	b5ffffc1 	cbnz	x1, 71e0 <f23+0xcc>
    71ec:	b40011b8 	cbz	x24, 7420 <f23+0x30c>
    71f0:	aa1803e1 	mov	x1, x24
    71f4:	d2800002 	mov	x2, #0x0                   	// #0
    71f8:	f9400821 	ldr	x1, [x1, #16]
    71fc:	91000442 	add	x2, x2, #0x1
    7200:	b5ffffc1 	cbnz	x1, 71f8 <f23+0xe4>
    7204:	eb00005f 	cmp	x2, x0
    7208:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    720c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7210:	eb01033f 	cmp	x25, x1
    7214:	54001468 	b.hi	74a0 <f23+0x38c>  // b.pmore
    7218:	d37ffb33 	lsl	x19, x25, #1
    721c:	52800041 	mov	w1, #0x2                   	// #2
    7220:	91000660 	add	x0, x19, #0x1
    7224:	d37df000 	lsl	x0, x0, #3
    7228:	97fff732 	bl	4ef0 <fwp_heap_alloc>
    722c:	911742e1 	add	x1, x23, #0x5d0
    7230:	aa0003fa 	mov	x26, x0
    7234:	f9000013 	str	x19, [x0]
    7238:	aa0103e0 	mov	x0, x1
    723c:	f949d821 	ldr	x1, [x1, #5040]
    7240:	f949ec00 	ldr	x0, [x0, #5080]
    7244:	cb010341 	sub	x1, x26, x1
    7248:	eb00403f 	cmp	x1, x0, lsl #16
    724c:	54000342 	b.cs	72b4 <f23+0x1a0>  // b.hs, b.nlast
    7250:	911742e2 	add	x2, x23, #0x5d0
    7254:	d350fc20 	lsr	x0, x1, #16
    7258:	8b000800 	add	x0, x0, x0, lsl #2
    725c:	f949fc43 	ldr	x3, [x2, #5112]
    7260:	d37df002 	lsl	x2, x0, #3
    7264:	8b020060 	add	x0, x3, x2
    7268:	f9401013 	ldr	x19, [x0, #32]
    726c:	b4000253 	cbz	x19, 72b4 <f23+0x1a0>
    7270:	38626862 	ldrb	w2, [x3, x2]
    7274:	7100085f 	cmp	w2, #0x2
    7278:	54000c00 	b.eq	73f8 <f23+0x2e4>  // b.none
    727c:	7100045f 	cmp	w2, #0x1
    7280:	540001a1 	b.ne	72b4 <f23+0x1a0>  // b.any
    7284:	29430002 	ldp	w2, w0, [x0, #24]
    7288:	92403c21 	and	x1, x1, #0xffff
    728c:	9b027c21 	mul	x1, x1, x2
    7290:	d360fc21 	lsr	x1, x1, #32
    7294:	eb00003f 	cmp	x1, x0
    7298:	540000e2 	b.cs	72b4 <f23+0x1a0>  // b.hs, b.nlast
    729c:	8b010273 	add	x19, x19, x1
    72a0:	39400260 	ldrb	w0, [x19]
    72a4:	7103fc1f 	cmp	w0, #0xff
    72a8:	54000da0 	b.eq	745c <f23+0x348>  // b.none
    72ac:	52800020 	mov	w0, #0x1                   	// #1
    72b0:	39000260 	strb	w0, [x19]
    72b4:	b4000259 	cbz	x25, 72fc <f23+0x1e8>
    72b8:	8b191359 	add	x25, x26, x25, lsl #4
    72bc:	aa1a03f3 	mov	x19, x26
    72c0:	aa1603f5 	mov	x21, x22
    72c4:	aa1803f4 	mov	x20, x24
    72c8:	f9400683 	ldr	x3, [x20, #8]
    72cc:	f94006a2 	ldr	x2, [x21, #8]
    72d0:	f9400861 	ldr	x1, [x3, #16]
    72d4:	f9400840 	ldr	x0, [x2, #16]
    72d8:	fd400461 	ldr	d1, [x3, #8]
    72dc:	fd400440 	ldr	d0, [x2, #8]
    72e0:	97fff884 	bl	54f0 <w107>
    72e4:	f9000660 	str	x0, [x19, #8]
    72e8:	f8010e61 	str	x1, [x19, #16]!
    72ec:	f9400a94 	ldr	x20, [x20, #16]
    72f0:	f9400ab5 	ldr	x21, [x21, #16]
    72f4:	eb13033f 	cmp	x25, x19
    72f8:	54fffe81 	b.ne	72c8 <f23+0x1b4>  // b.any
    72fc:	aa1803e0 	mov	x0, x24
    7300:	97fffe91 	bl	6d44 <fwp_drop2>
    7304:	aa1603e0 	mov	x0, x22
    7308:	97fffe8f 	bl	6d44 <fwp_drop2>
    730c:	911742f7 	add	x23, x23, #0x5d0
    7310:	aa1a03e0 	mov	x0, x26
    7314:	97fff8bb 	bl	5600 <w164.constprop.0>
    7318:	aa0103f3 	mov	x19, x1
    731c:	aa0003f4 	mov	x20, x0
    7320:	aa1a03e0 	mov	x0, x26
    7324:	97fffd37 	bl	6800 <fwp_drop4>
    7328:	a900cff4 	stp	x20, x19, [sp, #8]
    732c:	910023e1 	add	x1, sp, #0x8
    7330:	52800000 	mov	w0, #0x0                   	// #0
    7334:	97fff8db 	bl	56a0 <fwp_data.part.0.constprop.0>
    7338:	f949dae1 	ldr	x1, [x23, #5040]
    733c:	aa0003f3 	mov	x19, x0
    7340:	f949eee0 	ldr	x0, [x23, #5080]
    7344:	cb010261 	sub	x1, x19, x1
    7348:	eb00403f 	cmp	x1, x0, lsl #16
    734c:	54000322 	b.cs	73b0 <f23+0x29c>  // b.hs, b.nlast
    7350:	d350fc22 	lsr	x2, x1, #16
    7354:	f949fee3 	ldr	x3, [x23, #5112]
    7358:	8b020842 	add	x2, x2, x2, lsl #2
    735c:	d37df042 	lsl	x2, x2, #3
    7360:	8b020060 	add	x0, x3, x2
    7364:	f9401014 	ldr	x20, [x0, #32]
    7368:	b4000254 	cbz	x20, 73b0 <f23+0x29c>
    736c:	38626862 	ldrb	w2, [x3, x2]
    7370:	7100085f 	cmp	w2, #0x2
    7374:	540003c0 	b.eq	73ec <f23+0x2d8>  // b.none
    7378:	7100045f 	cmp	w2, #0x1
    737c:	540001a1 	b.ne	73b0 <f23+0x29c>  // b.any
    7380:	29430002 	ldp	w2, w0, [x0, #24]
    7384:	92403c21 	and	x1, x1, #0xffff
    7388:	9b027c21 	mul	x1, x1, x2
    738c:	d360fc21 	lsr	x1, x1, #32
    7390:	eb00003f 	cmp	x1, x0
    7394:	540000e2 	b.cs	73b0 <f23+0x29c>  // b.hs, b.nlast
    7398:	8b010294 	add	x20, x20, x1
    739c:	39400280 	ldrb	w0, [x20]
    73a0:	7103fc1f 	cmp	w0, #0xff
    73a4:	54000620 	b.eq	7468 <f23+0x354>  // b.none
    73a8:	52800020 	mov	w0, #0x1                   	// #1
    73ac:	39000280 	strb	w0, [x20]
    73b0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    73b4:	f947f400 	ldr	x0, [x0, #4072]
    73b8:	f9400fe2 	ldr	x2, [sp, #24]
    73bc:	f9400001 	ldr	x1, [x0]
    73c0:	eb010042 	subs	x2, x2, x1
    73c4:	d2800001 	mov	x1, #0x0                   	// #0
    73c8:	540006a1 	b.ne	749c <f23+0x388>  // b.any
    73cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    73d0:	aa1303e0 	mov	x0, x19
    73d4:	a94353f3 	ldp	x19, x20, [sp, #48]
    73d8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    73dc:	a94563f7 	ldp	x23, x24, [sp, #80]
    73e0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    73e4:	9101c3ff 	add	sp, sp, #0x70
    73e8:	d65f03c0 	ret
    73ec:	72003c3f 	tst	w1, #0xffff
    73f0:	54fffe01 	b.ne	73b0 <f23+0x29c>  // b.any
    73f4:	17ffffea 	b	739c <f23+0x288>
    73f8:	72003c3f 	tst	w1, #0xffff
    73fc:	54fff5c1 	b.ne	72b4 <f23+0x1a0>  // b.any
    7400:	17ffffa8 	b	72a0 <f23+0x18c>
    7404:	72003c3f 	tst	w1, #0xffff
    7408:	54ffee41 	b.ne	71d0 <f23+0xbc>  // b.any
    740c:	17ffff6b 	b	71b8 <f23+0xa4>
    7410:	cb0103e1 	neg	x1, x1
    7414:	eb02003f 	cmp	x1, x2
    7418:	540002e3 	b.cc	7474 <f23+0x360>  // b.lo, b.ul, b.last
    741c:	d503201f 	nop
    7420:	52800041 	mov	w1, #0x2                   	// #2
    7424:	d2800100 	mov	x0, #0x8                   	// #8
    7428:	97fff6b2 	bl	4ef0 <fwp_heap_alloc>
    742c:	aa0003e1 	mov	x1, x0
    7430:	911742e0 	add	x0, x23, #0x5d0
    7434:	aa0103fa 	mov	x26, x1
    7438:	d2800018 	mov	x24, #0x0                   	// #0
    743c:	f900003f 	str	xzr, [x1]
    7440:	f949d801 	ldr	x1, [x0, #5040]
    7444:	f949ec00 	ldr	x0, [x0, #5080]
    7448:	cb010341 	sub	x1, x26, x1
    744c:	eb00403f 	cmp	x1, x0, lsl #16
    7450:	54fff562 	b.cs	72fc <f23+0x1e8>  // b.hs, b.nlast
    7454:	d2800019 	mov	x25, #0x0                   	// #0
    7458:	17ffff7e 	b	7250 <f23+0x13c>
    745c:	aa1303e0 	mov	x0, x19
    7460:	97fff4e4 	bl	47f0 <fwp_rc_forget_slot>
    7464:	17ffff92 	b	72ac <f23+0x198>
    7468:	aa1403e0 	mov	x0, x20
    746c:	97fff4e1 	bl	47f0 <fwp_rc_forget_slot>
    7470:	17ffffce 	b	73a8 <f23+0x294>
    7474:	f949fc62 	ldr	x2, [x3, #5112]
    7478:	d350fc20 	lsr	x0, x1, #16
    747c:	8b000800 	add	x0, x0, x0, lsl #2
    7480:	8b000c42 	add	x2, x2, x0, lsl #3
    7484:	f9401040 	ldr	x0, [x2, #32]
    7488:	b4fffcc0 	cbz	x0, 7420 <f23+0x30c>
    748c:	d2800018 	mov	x24, #0x0                   	// #0
    7490:	17ffff3e 	b	7188 <f23+0x74>
    7494:	97fff490 	bl	46d4 <fwp_rc_wide_dup>
    7498:	17ffff4e 	b	71d0 <f23+0xbc>
    749c:	97ffecf9 	bl	2880 <__stack_chk_fail@plt>
    74a0:	d0000020 	adrp	x0, d000 <__divti3+0x2d0>
    74a4:	9123c000 	add	x0, x0, #0x8f0
    74a8:	97fff0d6 	bl	3800 <fwp_trap>
    74ac:	d503201f 	nop

00000000000074b0 <fwp_owned_entry23>:
    74b0:	f9400000 	ldr	x0, [x0]
    74b4:	17ffff18 	b	7114 <f23>
    74b8:	d503201f 	nop
    74bc:	d503201f 	nop

00000000000074c0 <e23>:
    74c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    74c4:	910003fd 	mov	x29, sp
    74c8:	f9000bf3 	str	x19, [sp, #16]
    74cc:	f9400013 	ldr	x19, [x0]
    74d0:	aa1303e0 	mov	x0, x19
    74d4:	97fff8bb 	bl	57c0 <fwp_rc_share>
    74d8:	aa1303e0 	mov	x0, x19
    74dc:	97ffff0e 	bl	7114 <f23>
    74e0:	aa0003f3 	mov	x19, x0
    74e4:	97fff8b7 	bl	57c0 <fwp_rc_share>
    74e8:	aa1303e0 	mov	x0, x19
    74ec:	f9400bf3 	ldr	x19, [sp, #16]
    74f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74f4:	d65f03c0 	ret
    74f8:	d503201f 	nop
    74fc:	d503201f 	nop

0000000000007500 <f12>:
    7500:	d10483ff 	sub	sp, sp, #0x120
    7504:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7508:	f947f442 	ldr	x2, [x2, #4072]
    750c:	910103e8 	add	x8, sp, #0x40
    7510:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7514:	910303fd 	add	x29, sp, #0xc0
    7518:	9100e3e9 	add	x9, sp, #0x38
    751c:	a90d53f3 	stp	x19, x20, [sp, #208]
    7520:	d0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    7524:	91174263 	add	x3, x19, #0x5d0
    7528:	b00000d4 	adrp	x20, 20000 <__data_start>
    752c:	9101c284 	add	x4, x20, #0x70
    7530:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7534:	f0fffff6 	adrp	x22, 6000 <fwp_closure_drop+0xd0>
    7538:	aa0003f5 	mov	x21, x0
    753c:	f949d861 	ldr	x1, [x3, #5040]
    7540:	a90f63f7 	stp	x23, x24, [sp, #240]
    7544:	b00000d7 	adrp	x23, 20000 <__data_start>
    7548:	f949ec65 	ldr	x5, [x3, #5080]
    754c:	a9106bf9 	stp	x25, x26, [sp, #256]
    7550:	910042f7 	add	x23, x23, #0x10
    7554:	a91173fb 	stp	x27, x28, [sp, #272]
    7558:	9100e2f7 	add	x23, x23, #0x38
    755c:	cb0102e1 	sub	x1, x23, x1
    7560:	f9418886 	ldr	x6, [x4, #784]
    7564:	f9400047 	ldr	x7, [x2]
    7568:	f9005fe7 	str	x7, [sp, #184]
    756c:	d2800007 	mov	x7, #0x0                   	// #0
    7570:	12800007 	mov	w7, #0xffffffff            	// #-1
    7574:	910ac2c2 	add	x2, x22, #0x2b0
    7578:	a901a3e9 	stp	x9, x8, [sp, #24]
    757c:	b9003be7 	str	w7, [sp, #56]
    7580:	a9040be6 	stp	x6, x2, [sp, #64]
    7584:	f9002be9 	str	x9, [sp, #80]
    7588:	f9018888 	str	x8, [x4, #784]
    758c:	eb05403f 	cmp	x1, x5, lsl #16
    7590:	54000342 	b.cs	75f8 <f12+0xf8>  // b.hs, b.nlast
    7594:	d350fc20 	lsr	x0, x1, #16
    7598:	f949fc64 	ldr	x4, [x3, #5112]
    759c:	8b000800 	add	x0, x0, x0, lsl #2
    75a0:	d37df002 	lsl	x2, x0, #3
    75a4:	8b020083 	add	x3, x4, x2
    75a8:	f9401060 	ldr	x0, [x3, #32]
    75ac:	b4000260 	cbz	x0, 75f8 <f12+0xf8>
    75b0:	38626882 	ldrb	w2, [x4, x2]
    75b4:	7100085f 	cmp	w2, #0x2
    75b8:	54006dc0 	b.eq	8370 <f12+0xe70>  // b.none
    75bc:	7100045f 	cmp	w2, #0x1
    75c0:	540001c1 	b.ne	75f8 <f12+0xf8>  // b.any
    75c4:	29430864 	ldp	w4, w2, [x3, #24]
    75c8:	92403c21 	and	x1, x1, #0xffff
    75cc:	9b047c21 	mul	x1, x1, x4
    75d0:	d360fc21 	lsr	x1, x1, #32
    75d4:	eb02003f 	cmp	x1, x2
    75d8:	54000102 	b.cs	75f8 <f12+0xf8>  // b.hs, b.nlast
    75dc:	8b010000 	add	x0, x0, x1
    75e0:	39400001 	ldrb	w1, [x0]
    75e4:	340000a1 	cbz	w1, 75f8 <f12+0xf8>
    75e8:	7103f43f 	cmp	w1, #0xfd
    75ec:	54007568 	b.hi	8498 <f12+0xf98>  // b.pmore
    75f0:	11000421 	add	w1, w1, #0x1
    75f4:	39000001 	strb	w1, [x0]
    75f8:	aa1703e0 	mov	x0, x23
    75fc:	97fffa4d 	bl	5f30 <fwp_closure_drop>
    7600:	b4006c35 	cbz	x21, 8384 <f12+0xe84>
    7604:	aa1503e0 	mov	x0, x21
    7608:	d2800017 	mov	x23, #0x0                   	// #0
    760c:	d503201f 	nop
    7610:	f9400800 	ldr	x0, [x0, #16]
    7614:	910006f7 	add	x23, x23, #0x1
    7618:	b5ffffc0 	cbnz	x0, 7610 <f12+0x110>
    761c:	52800000 	mov	w0, #0x0                   	// #0
    7620:	97ffeff4 	bl	35f0 <descent_phase_step>
    7624:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7628:	eb0002ff 	cmp	x23, x0
    762c:	540076a8 	b.hi	8500 <f12+0x1000>  // b.pmore
    7630:	9101c298 	add	x24, x20, #0x70
    7634:	b9434700 	ldr	w0, [x24, #836]
    7638:	34006880 	cbz	w0, 8348 <f12+0xe48>
    763c:	9101c280 	add	x0, x20, #0x70
    7640:	f9404819 	ldr	x25, [x0, #144]
    7644:	f9407401 	ldr	x1, [x0, #232]
    7648:	eb19003f 	cmp	x1, x25
    764c:	540066aa 	b.ge	8320 <f12+0xe20>  // b.tcont
    7650:	f9403a82 	ldr	x2, [x20, #112]
    7654:	8b010420 	add	x0, x1, x1, lsl #1
    7658:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    765c:	8b000820 	add	x0, x1, x0, lsl #2
    7660:	8b000c40 	add	x0, x2, x0, lsl #3
    7664:	d503201f 	nop
    7668:	b9400402 	ldr	w2, [x0, #4]
    766c:	35000082 	cbnz	w2, 767c <f12+0x17c>
    7670:	b9400002 	ldr	w2, [x0]
    7674:	6b03005f 	cmp	w2, w3
    7678:	54006549 	b.ls	8320 <f12+0xe20>  // b.plast
    767c:	91000421 	add	x1, x1, #0x1
    7680:	9101a000 	add	x0, x0, #0x68
    7684:	eb19003f 	cmp	x1, x25
    7688:	54ffff01 	b.ne	7668 <f12+0x168>  // b.any
    768c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7690:	eb00033f 	cmp	x25, x0
    7694:	540073cc 	b.gt	850c <f12+0x100c>
    7698:	9101c280 	add	x0, x20, #0x70
    769c:	f9403a9a 	ldr	x26, [x20, #112]
    76a0:	f9407000 	ldr	x0, [x0, #224]
    76a4:	eb19001f 	cmp	x0, x25
    76a8:	54000161 	b.ne	76d4 <f12+0x1d4>  // b.any
    76ac:	b50069d9 	cbnz	x25, 83e4 <f12+0xee4>
    76b0:	d2800d01 	mov	x1, #0x68                  	// #104
    76b4:	d2800038 	mov	x24, #0x1                   	// #1
    76b8:	aa1a03e0 	mov	x0, x26
    76bc:	97ffec6d 	bl	2870 <realloc@plt>
    76c0:	aa0003fa 	mov	x26, x0
    76c4:	b4006160 	cbz	x0, 82f0 <f12+0xdf0>
    76c8:	9101c280 	add	x0, x20, #0x70
    76cc:	f9003a9a 	str	x26, [x20, #112]
    76d0:	f9007018 	str	x24, [x0, #224]
    76d4:	d37ffb21 	lsl	x1, x25, #1
    76d8:	9101c280 	add	x0, x20, #0x70
    76dc:	8b190022 	add	x2, x1, x25
    76e0:	9100073b 	add	x27, x25, #0x1
    76e4:	4f000400 	movi	v0.4s, #0x0
    76e8:	8b020b22 	add	x2, x25, x2, lsl #2
    76ec:	f900481b 	str	x27, [x0, #144]
    76f0:	8b020f42 	add	x2, x26, x2, lsl #3
    76f4:	f900305f 	str	xzr, [x2, #96]
    76f8:	ad000040 	stp	q0, q0, [x2]
    76fc:	ad010040 	stp	q0, q0, [x2, #32]
    7700:	ad020040 	stp	q0, q0, [x2, #64]
    7704:	8b190021 	add	x1, x1, x25
    7708:	d0000020 	adrp	x0, d000 <__divti3+0x2d0>
    770c:	911d0000 	add	x0, x0, #0x740
    7710:	8b010b21 	add	x1, x25, x1, lsl #2
    7714:	8b010f58 	add	x24, x26, x1, lsl #3
    7718:	f900331f 	str	xzr, [x24, #96]
    771c:	97ffecbd 	bl	2a10 <getenv@plt>
    7720:	b4000080 	cbz	x0, 7730 <f12+0x230>
    7724:	39400001 	ldrb	w1, [x0]
    7728:	7100c03f 	cmp	w1, #0x30
    772c:	54003080 	b.eq	7d3c <f12+0x83c>  // b.none
    7730:	9101c280 	add	x0, x20, #0x70
    7734:	f9406801 	ldr	x1, [x0, #208]
    7738:	b5006381 	cbnz	x1, 83a8 <f12+0xea8>
    773c:	9101c282 	add	x2, x20, #0x70
    7740:	2f000400 	mvni	v0.2s, #0x0
    7744:	b9400303 	ldr	w3, [x24]
    7748:	52800020 	mov	w0, #0x1                   	// #1
    774c:	a900df17 	stp	x23, x23, [x24, #8]
    7750:	0b000063 	add	w3, w3, w0
    7754:	f9418841 	ldr	x1, [x2, #784]
    7758:	29000303 	stp	w3, w0, [x24]
    775c:	f9002b1f 	str	xzr, [x24, #80]
    7760:	f900745b 	str	x27, [x2, #232]
    7764:	fd002f00 	str	d0, [x24, #88]
    7768:	b4006be1 	cbz	x1, 84e4 <f12+0xfe4>
    776c:	910ac2d6 	add	x22, x22, #0x2b0
    7770:	14000003 	b	777c <f12+0x27c>
    7774:	f9400021 	ldr	x1, [x1]
    7778:	b4006b61 	cbz	x1, 84e4 <f12+0xfe4>
    777c:	f9400422 	ldr	x2, [x1, #8]
    7780:	eb16005f 	cmp	x2, x22
    7784:	54ffff81 	b.ne	7774 <f12+0x274>  // b.any
    7788:	f9400820 	ldr	x0, [x1, #16]
    778c:	2a1903e2 	mov	w2, w25
    7790:	b9400001 	ldr	w1, [x0]
    7794:	f9002b00 	str	x0, [x24, #80]
    7798:	b9005f01 	str	w1, [x24, #92]
    779c:	37f80081 	tbnz	w1, #31, 77ac <f12+0x2ac>
    77a0:	52800d05 	mov	w5, #0x68                  	// #104
    77a4:	9b256821 	smaddl	x1, w1, w5, x26
    77a8:	b9005839 	str	w25, [x1, #88]
    77ac:	b9000002 	str	w2, [x0]
    77b0:	d3707c77 	ubfiz	x23, x3, #16, #32
    77b4:	52800020 	mov	w0, #0x1                   	// #1
    77b8:	aa1b02f7 	orr	x23, x23, x27
    77bc:	97ffef8d 	bl	35f0 <descent_phase_step>
    77c0:	aa1503e0 	mov	x0, x21
    77c4:	d2800002 	mov	x2, #0x0                   	// #0
    77c8:	b4005655 	cbz	x21, 8290 <f12+0xd90>
    77cc:	d503201f 	nop
    77d0:	f9400800 	ldr	x0, [x0, #16]
    77d4:	91000442 	add	x2, x2, #0x1
    77d8:	b5ffffc0 	cbnz	x0, 77d0 <f12+0x2d0>
    77dc:	aa1503e1 	mov	x1, x21
    77e0:	f9400821 	ldr	x1, [x1, #16]
    77e4:	91000400 	add	x0, x0, #0x1
    77e8:	b5ffffc1 	cbnz	x1, 77e0 <f12+0x2e0>
    77ec:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    77f0:	eb01001f 	cmp	x0, x1
    77f4:	540066c8 	b.hi	84cc <f12+0xfcc>  // b.pmore
    77f8:	f100005f 	cmp	x2, #0x0
    77fc:	540054ad 	b.le	8290 <f12+0xd90>
    7800:	eb00005f 	cmp	x2, x0
    7804:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7808:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    780c:	eb0102df 	cmp	x22, x1
    7810:	540065e8 	b.hi	84cc <f12+0xfcc>  // b.pmore
    7814:	d37ffad9 	lsl	x25, x22, #1
    7818:	52800041 	mov	w1, #0x2                   	// #2
    781c:	91000720 	add	x0, x25, #0x1
    7820:	d37df000 	lsl	x0, x0, #3
    7824:	97fff5b3 	bl	4ef0 <fwp_heap_alloc>
    7828:	aa0003f8 	mov	x24, x0
    782c:	91174261 	add	x1, x19, #0x5d0
    7830:	aa0103e0 	mov	x0, x1
    7834:	f9000319 	str	x25, [x24]
    7838:	f949d821 	ldr	x1, [x1, #5040]
    783c:	f949ec00 	ldr	x0, [x0, #5080]
    7840:	cb010301 	sub	x1, x24, x1
    7844:	eb00403f 	cmp	x1, x0, lsl #16
    7848:	540057a2 	b.cs	833c <f12+0xe3c>  // b.hs, b.nlast
    784c:	91174262 	add	x2, x19, #0x5d0
    7850:	d350fc20 	lsr	x0, x1, #16
    7854:	8b000800 	add	x0, x0, x0, lsl #2
    7858:	f949fc43 	ldr	x3, [x2, #5112]
    785c:	d37df002 	lsl	x2, x0, #3
    7860:	8b020060 	add	x0, x3, x2
    7864:	f9401019 	ldr	x25, [x0, #32]
    7868:	b4000259 	cbz	x25, 78b0 <f12+0x3b0>
    786c:	38626862 	ldrb	w2, [x3, x2]
    7870:	7100085f 	cmp	w2, #0x2
    7874:	54005780 	b.eq	8364 <f12+0xe64>  // b.none
    7878:	7100045f 	cmp	w2, #0x1
    787c:	540001a1 	b.ne	78b0 <f12+0x3b0>  // b.any
    7880:	29430002 	ldp	w2, w0, [x0, #24]
    7884:	92403c21 	and	x1, x1, #0xffff
    7888:	9b027c21 	mul	x1, x1, x2
    788c:	d360fc21 	lsr	x1, x1, #32
    7890:	eb00003f 	cmp	x1, x0
    7894:	540000e2 	b.cs	78b0 <f12+0x3b0>  // b.hs, b.nlast
    7898:	8b010339 	add	x25, x25, x1
    789c:	39400320 	ldrb	w0, [x25]
    78a0:	7103fc1f 	cmp	w0, #0xff
    78a4:	54005e80 	b.eq	8474 <f12+0xf74>  // b.none
    78a8:	52800020 	mov	w0, #0x1                   	// #1
    78ac:	39000320 	strb	w0, [x25]
    78b0:	b4000236 	cbz	x22, 78f4 <f12+0x3f4>
    78b4:	d3607ee4 	lsl	x4, x23, #32
    78b8:	aa1503e2 	mov	x2, x21
    78bc:	f94006a5 	ldr	x5, [x21, #8]
    78c0:	aa0403e3 	mov	x3, x4
    78c4:	91002300 	add	x0, x24, #0x8
    78c8:	d2800001 	mov	x1, #0x0                   	// #0
    78cc:	14000005 	b	78e0 <f12+0x3e0>
    78d0:	f9400445 	ldr	x5, [x2, #8]
    78d4:	ab040023 	adds	x3, x1, x4
    78d8:	91004000 	add	x0, x0, #0x10
    78dc:	54006266 	b.vs	8528 <f12+0x1028>
    78e0:	a9000c05 	stp	x5, x3, [x0]
    78e4:	91000421 	add	x1, x1, #0x1
    78e8:	f9400842 	ldr	x2, [x2, #16]
    78ec:	eb0102df 	cmp	x22, x1
    78f0:	54ffff08 	b.hi	78d0 <f12+0x3d0>  // b.pmore
    78f4:	f9400300 	ldr	x0, [x24]
    78f8:	f100041f 	cmp	x0, #0x1
    78fc:	54005229 	b.ls	8340 <f12+0xe40>  // b.plast
    7900:	d341fc00 	lsr	x0, x0, #1
    7904:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7908:	d1000401 	sub	x1, x0, #0x1
    790c:	eb02003f 	cmp	x1, x2
    7910:	54005de8 	b.hi	84cc <f12+0xfcc>  // b.pmore
    7914:	d37ff83a 	lsl	x26, x1, #1
    7918:	b4005141 	cbz	x1, 8340 <f12+0xe40>
    791c:	d1002301 	sub	x1, x24, #0x8
    7920:	91002316 	add	x22, x24, #0x8
    7924:	8b001039 	add	x25, x1, x0, lsl #4
    7928:	f94006c0 	ldr	x0, [x22, #8]
    792c:	f9400ec1 	ldr	x1, [x22, #24]
    7930:	fd4002c0 	ldr	d0, [x22]
    7934:	fd400ac1 	ldr	d1, [x22, #16]
    7938:	97fff6ee 	bl	54f0 <w107>
    793c:	a90006c0 	stp	x0, x1, [x22]
    7940:	910042d6 	add	x22, x22, #0x10
    7944:	eb1902df 	cmp	x22, x25
    7948:	54ffff01 	b.ne	7928 <f12+0x428>  // b.any
    794c:	f900031a 	str	x26, [x24]
    7950:	aa1803e0 	mov	x0, x24
    7954:	93407efc 	sxtw	x28, w23
    7958:	97fff72a 	bl	5600 <w164.constprop.0>
    795c:	aa1803e0 	mov	x0, x24
    7960:	aa0103f8 	mov	x24, x1
    7964:	97fffba7 	bl	6800 <fwp_drop4>
    7968:	52800040 	mov	w0, #0x2                   	// #2
    796c:	97ffef21 	bl	35f0 <descent_phase_step>
    7970:	aa1c03e0 	mov	x0, x28
    7974:	97fff06f 	bl	3b30 <fwp_tape_of>
    7978:	f9403002 	ldr	x2, [x0, #96]
    797c:	aa0003e7 	mov	x7, x0
    7980:	b5005ba2 	cbnz	x2, 84f4 <f12+0xff4>
    7984:	97ffed83 	bl	2f90 <fwp_tape_unlink_scope>
    7988:	b9400008 	ldr	w8, [x0]
    798c:	a94284f7 	ldp	x23, x1, [x7, #40]
    7990:	f90007e1 	str	x1, [sp, #8]
    7994:	a940801b 	ldp	x27, x0, [x0, #8]
    7998:	b90004ff 	str	wzr, [x7, #4]
    799c:	a941d8ea 	ldp	x10, x22, [x7, #24]
    79a0:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    79a4:	a943e8f9 	ldp	x25, x26, [x7, #56]
    79a8:	f94024e2 	ldr	x2, [x7, #72]
    79ac:	6b03011f 	cmp	w8, w3
    79b0:	54000108 	b.hi	79d0 <f12+0x4d0>  // b.pmore
    79b4:	9101c288 	add	x8, x20, #0x70
    79b8:	92403f83 	and	x3, x28, #0xffff
    79bc:	d1000463 	sub	x3, x3, #0x1
    79c0:	f9407509 	ldr	x9, [x8, #232]
    79c4:	eb09007f 	cmp	x3, x9
    79c8:	5400004a 	b.ge	79d0 <f12+0x4d0>  // b.tcont
    79cc:	f9007503 	str	x3, [x8, #232]
    79d0:	4f000400 	movi	v0.4s, #0x0
    79d4:	9101c289 	add	x9, x20, #0x70
    79d8:	9101c3e1 	add	x1, sp, #0x70
    79dc:	f9000be1 	str	x1, [sp, #16]
    79e0:	f9000cff 	str	xzr, [x7, #24]
    79e4:	910163e3 	add	x3, sp, #0x58
    79e8:	f941892b 	ldr	x11, [x9, #784]
    79ec:	3c8080e0 	stur	q0, [x7, #8]
    79f0:	b0ffffe8 	adrp	x8, 4000 <fwp_heap_report+0x60>
    79f4:	ad0100e0 	stp	q0, q0, [x7, #32]
    79f8:	910e0108 	add	x8, x8, #0x380
    79fc:	a906dbe1 	stp	x1, x22, [sp, #104]
    7a00:	f94007e1 	ldr	x1, [sp, #8]
    7a04:	a9047cff 	stp	xzr, xzr, [x7, #64]
    7a08:	a905a3eb 	stp	x11, x8, [sp, #88]
    7a0c:	f9003ff7 	str	x23, [sp, #120]
    7a10:	f90043e1 	str	x1, [sp, #128]
    7a14:	a908ebf9 	stp	x25, x26, [sp, #136]
    7a18:	a9098bea 	stp	x10, x2, [sp, #152]
    7a1c:	f9018923 	str	x3, [x9, #784]
    7a20:	b7f84bb8 	tbnz	x24, #63, 8394 <f12+0xe94>
    7a24:	eb98839f 	cmp	x28, x24, asr #32
    7a28:	540054c1 	b.ne	84c0 <f12+0xfc0>  // b.any
    7a2c:	92407f03 	and	x3, x24, #0xffffffff
    7a30:	eb38401f 	cmp	x0, w24, uxtw
    7a34:	5400540d 	b.le	84b4 <f12+0xfb4>
    7a38:	eb03037f 	cmp	x27, x3
    7a3c:	9a83c77c 	csinc	x28, x27, x3, gt
    7a40:	eb1c005f 	cmp	x2, x28
    7a44:	5400446a 	b.ge	82d0 <f12+0xdd0>  // b.tcont
    7a48:	f100005f 	cmp	x2, #0x0
    7a4c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7a50:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    7a54:	14000004 	b	7a64 <f12+0x564>
    7a58:	eb01005f 	cmp	x2, x1
    7a5c:	d37ff842 	lsl	x2, x2, #1
    7a60:	9a9cd042 	csel	x2, x2, x28, le
    7a64:	eb1c005f 	cmp	x2, x28
    7a68:	54ffff8b 	b.lt	7a58 <f12+0x558>  // b.tstop
    7a6c:	b4004e1a 	cbz	x26, 842c <f12+0xf2c>
    7a70:	aa1a03e0 	mov	x0, x26
    7a74:	d37df041 	lsl	x1, x2, #3
    7a78:	f90017e2 	str	x2, [sp, #40]
    7a7c:	97ffeb7d 	bl	2870 <realloc@plt>
    7a80:	f94017e2 	ldr	x2, [sp, #40]
    7a84:	aa0003fa 	mov	x26, x0
    7a88:	b400425a 	cbz	x26, 82d0 <f12+0xdd0>
    7a8c:	f9004bfa 	str	x26, [sp, #144]
    7a90:	f90053e2 	str	x2, [sp, #160]
    7a94:	b50015bc 	cbnz	x28, 7d48 <f12+0x848>
    7a98:	b7f800d8 	tbnz	x24, #63, 7ab0 <f12+0x5b0>
    7a9c:	92407f04 	and	x4, x24, #0xffffffff
    7aa0:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7aa4:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    7aa8:	1e612800 	fadd	d0, d0, d1
    7aac:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7ab0:	9101c281 	add	x1, x20, #0x70
    7ab4:	cb1b0384 	sub	x4, x28, x27
    7ab8:	52800060 	mov	w0, #0x3                   	// #3
    7abc:	a9428827 	ldp	x7, x2, [x1, #40]
    7ac0:	8b070084 	add	x4, x4, x7
    7ac4:	8b1b0042 	add	x2, x2, x27
    7ac8:	a9028824 	stp	x4, x2, [x1, #40]
    7acc:	97ffeec9 	bl	35f0 <descent_phase_step>
    7ad0:	d1000783 	sub	x3, x28, #0x1
    7ad4:	d1000764 	sub	x4, x27, #0x1
    7ad8:	eb03037f 	cmp	x27, x3
    7adc:	540003cc 	b.gt	7b54 <f12+0x654>
    7ae0:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    7ae4:	1e602008 	fcmp	d0, #0.0
    7ae8:	54000300 	b.eq	7b48 <f12+0x648>  // b.none
    7aec:	cb1b0be0 	neg	x0, x27, lsl #2
    7af0:	cb1b03e2 	neg	x2, x27
    7af4:	8b0002c1 	add	x1, x22, x0
    7af8:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    7afc:	37f80121 	tbnz	w1, #31, 7b20 <f12+0x620>
    7b00:	f94007e5 	ldr	x5, [sp, #8]
    7b04:	93407c21 	sxtw	x1, w1
    7b08:	8b020ca7 	add	x7, x5, x2, lsl #3
    7b0c:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    7b10:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    7b14:	1e620802 	fmul	d2, d0, d2
    7b18:	1e622821 	fadd	d1, d1, d2
    7b1c:	fc217b41 	str	d1, [x26, x1, lsl #3]
    7b20:	8b0002e0 	add	x0, x23, x0
    7b24:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    7b28:	37f80100 	tbnz	w0, #31, 7b48 <f12+0x648>
    7b2c:	8b020f22 	add	x2, x25, x2, lsl #3
    7b30:	93407c00 	sxtw	x0, w0
    7b34:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    7b38:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    7b3c:	1e620800 	fmul	d0, d0, d2
    7b40:	1e602820 	fadd	d0, d1, d0
    7b44:	fc207b40 	str	d0, [x26, x0, lsl #3]
    7b48:	d1000463 	sub	x3, x3, #0x1
    7b4c:	eb03009f 	cmp	x4, x3
    7b50:	54fffc81 	b.ne	7ae0 <f12+0x5e0>  // b.any
    7b54:	52800080 	mov	w0, #0x4                   	// #4
    7b58:	97ffeea6 	bl	35f0 <descent_phase_step>
    7b5c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7b60:	eb00037f 	cmp	x27, x0
    7b64:	54004da8 	b.hi	8518 <f12+0x1018>  // b.pmore
    7b68:	91000760 	add	x0, x27, #0x1
    7b6c:	52800041 	mov	w1, #0x2                   	// #2
    7b70:	d37df000 	lsl	x0, x0, #3
    7b74:	97fff4df 	bl	4ef0 <fwp_heap_alloc>
    7b78:	aa0003e2 	mov	x2, x0
    7b7c:	aa0003f6 	mov	x22, x0
    7b80:	d2800001 	mov	x1, #0x0                   	// #0
    7b84:	f800845b 	str	x27, [x2], #8
    7b88:	b40000fb 	cbz	x27, 7ba4 <f12+0x6a4>
    7b8c:	d503201f 	nop
    7b90:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    7b94:	f8217840 	str	x0, [x2, x1, lsl #3]
    7b98:	91000421 	add	x1, x1, #0x1
    7b9c:	eb01037f 	cmp	x27, x1
    7ba0:	54ffff81 	b.ne	7b90 <f12+0x690>  // b.any
    7ba4:	528000a0 	mov	w0, #0x5                   	// #5
    7ba8:	97ffee92 	bl	35f0 <descent_phase_step>
    7bac:	f9400be0 	ldr	x0, [sp, #16]
    7bb0:	9101c281 	add	x1, x20, #0x70
    7bb4:	f9402ff8 	ldr	x24, [sp, #88]
    7bb8:	f9018838 	str	x24, [x1, #784]
    7bbc:	97fff1f1 	bl	4380 <fwp_tape_buffers_release>
    7bc0:	528000c0 	mov	w0, #0x6                   	// #6
    7bc4:	97ffee8b 	bl	35f0 <descent_phase_step>
    7bc8:	91174262 	add	x2, x19, #0x5d0
    7bcc:	f949d841 	ldr	x1, [x2, #5040]
    7bd0:	f949ec40 	ldr	x0, [x2, #5080]
    7bd4:	cb0102c1 	sub	x1, x22, x1
    7bd8:	eb00403f 	cmp	x1, x0, lsl #16
    7bdc:	54000322 	b.cs	7c40 <f12+0x740>  // b.hs, b.nlast
    7be0:	d350fc20 	lsr	x0, x1, #16
    7be4:	f949fc43 	ldr	x3, [x2, #5112]
    7be8:	8b000800 	add	x0, x0, x0, lsl #2
    7bec:	d37df002 	lsl	x2, x0, #3
    7bf0:	8b020060 	add	x0, x3, x2
    7bf4:	f9401017 	ldr	x23, [x0, #32]
    7bf8:	b4000257 	cbz	x23, 7c40 <f12+0x740>
    7bfc:	38626862 	ldrb	w2, [x3, x2]
    7c00:	7100085f 	cmp	w2, #0x2
    7c04:	54003cc0 	b.eq	839c <f12+0xe9c>  // b.none
    7c08:	7100045f 	cmp	w2, #0x1
    7c0c:	540001a1 	b.ne	7c40 <f12+0x740>  // b.any
    7c10:	29430002 	ldp	w2, w0, [x0, #24]
    7c14:	92403c21 	and	x1, x1, #0xffff
    7c18:	9b027c21 	mul	x1, x1, x2
    7c1c:	d360fc21 	lsr	x1, x1, #32
    7c20:	eb00003f 	cmp	x1, x0
    7c24:	540000e2 	b.cs	7c40 <f12+0x740>  // b.hs, b.nlast
    7c28:	8b0102f7 	add	x23, x23, x1
    7c2c:	394002e0 	ldrb	w0, [x23]
    7c30:	7103fc1f 	cmp	w0, #0xff
    7c34:	54004260 	b.eq	8480 <f12+0xf80>  // b.none
    7c38:	52800020 	mov	w0, #0x1                   	// #1
    7c3c:	390002e0 	strb	w0, [x23]
    7c40:	f94013e0 	ldr	x0, [sp, #32]
    7c44:	eb00031f 	cmp	x24, x0
    7c48:	540046e1 	b.ne	8524 <f12+0x1024>  // b.any
    7c4c:	f9400fe0 	ldr	x0, [sp, #24]
    7c50:	9101c294 	add	x20, x20, #0x70
    7c54:	f94023e1 	ldr	x1, [sp, #64]
    7c58:	f9018a81 	str	x1, [x20, #784]
    7c5c:	97fff995 	bl	62b0 <fwp_tape_scope_release>
    7c60:	f94002c0 	ldr	x0, [x22]
    7c64:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7c68:	b7f82c00 	tbnz	x0, #63, 81e8 <f12+0xce8>
    7c6c:	91174262 	add	x2, x19, #0x5d0
    7c70:	f949d840 	ldr	x0, [x2, #5040]
    7c74:	f949ec41 	ldr	x1, [x2, #5080]
    7c78:	cb0002c0 	sub	x0, x22, x0
    7c7c:	eb01401f 	cmp	x0, x1, lsl #16
    7c80:	54002b42 	b.cs	81e8 <f12+0xce8>  // b.hs, b.nlast
    7c84:	d350fc01 	lsr	x1, x0, #16
    7c88:	f949fc44 	ldr	x4, [x2, #5112]
    7c8c:	8b010821 	add	x1, x1, x1, lsl #2
    7c90:	d37df021 	lsl	x1, x1, #3
    7c94:	8b010083 	add	x3, x4, x1
    7c98:	f9401062 	ldr	x2, [x3, #32]
    7c9c:	b4002a62 	cbz	x2, 81e8 <f12+0xce8>
    7ca0:	38616881 	ldrb	w1, [x4, x1]
    7ca4:	7100083f 	cmp	w1, #0x2
    7ca8:	540029a0 	b.eq	81dc <f12+0xcdc>  // b.none
    7cac:	7100043f 	cmp	w1, #0x1
    7cb0:	540029c1 	b.ne	81e8 <f12+0xce8>  // b.any
    7cb4:	29430464 	ldp	w4, w1, [x3, #24]
    7cb8:	92403c00 	and	x0, x0, #0xffff
    7cbc:	9b047c00 	mul	x0, x0, x4
    7cc0:	d360fc00 	lsr	x0, x0, #32
    7cc4:	eb01001f 	cmp	x0, x1
    7cc8:	54002902 	b.cs	81e8 <f12+0xce8>  // b.hs, b.nlast
    7ccc:	8b000042 	add	x2, x2, x0
    7cd0:	39400040 	ldrb	w0, [x2]
    7cd4:	7100041f 	cmp	w0, #0x1
    7cd8:	54002881 	b.ne	81e8 <f12+0xce8>  // b.any
    7cdc:	aa1603fa 	mov	x26, x22
    7ce0:	d2800000 	mov	x0, #0x0                   	// #0
    7ce4:	f90007f6 	str	x22, [sp, #8]
    7ce8:	f94007e1 	ldr	x1, [sp, #8]
    7cec:	91002023 	add	x3, x1, #0x8
    7cf0:	d2800001 	mov	x1, #0x0                   	// #0
    7cf4:	b4000354 	cbz	x20, 7d5c <f12+0x85c>
    7cf8:	f0000022 	adrp	x2, e000 <_IO_stdin_used+0xbb0>
    7cfc:	910022c5 	add	x5, x22, #0x8
    7d00:	fd412041 	ldr	d1, [x2, #576]
    7d04:	14000009 	b	7d28 <f12+0x828>
    7d08:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7d0c:	f9400342 	ldr	x2, [x26]
    7d10:	1e600820 	fmul	d0, d1, d0
    7d14:	b7f83e22 	tbnz	x2, #63, 84d8 <f12+0xfd8>
    7d18:	91000421 	add	x1, x1, #0x1
    7d1c:	fc008460 	str	d0, [x3], #8
    7d20:	eb01029f 	cmp	x20, x1
    7d24:	540001c0 	b.eq	7d5c <f12+0x85c>  // b.none
    7d28:	f94002c4 	ldr	x4, [x22]
    7d2c:	aa0503e2 	mov	x2, x5
    7d30:	b6fffec4 	tbz	x4, #63, 7d08 <f12+0x808>
    7d34:	f9400ac2 	ldr	x2, [x22, #16]
    7d38:	17fffff4 	b	7d08 <f12+0x808>
    7d3c:	39400400 	ldrb	w0, [x0, #1]
    7d40:	34ffcfe0 	cbz	w0, 773c <f12+0x23c>
    7d44:	17fffe7b 	b	7730 <f12+0x230>
    7d48:	d37df382 	lsl	x2, x28, #3
    7d4c:	aa1a03e0 	mov	x0, x26
    7d50:	52800001 	mov	w1, #0x0                   	// #0
    7d54:	97ffeabf 	bl	2850 <memset@plt>
    7d58:	17ffff50 	b	7a98 <f12+0x598>
    7d5c:	97fffaa9 	bl	6800 <fwp_drop4>
    7d60:	aa1503e1 	mov	x1, x21
    7d64:	d2800002 	mov	x2, #0x0                   	// #0
    7d68:	b4003715 	cbz	x21, 8448 <f12+0xf48>
    7d6c:	d503201f 	nop
    7d70:	f9400821 	ldr	x1, [x1, #16]
    7d74:	91000442 	add	x2, x2, #0x1
    7d78:	b5ffffc1 	cbnz	x1, 7d70 <f12+0x870>
    7d7c:	f9400343 	ldr	x3, [x26]
    7d80:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7d84:	b7f81f43 	tbnz	x3, #63, 816c <f12+0xc6c>
    7d88:	91174261 	add	x1, x19, #0x5d0
    7d8c:	f94007e4 	ldr	x4, [sp, #8]
    7d90:	f949d820 	ldr	x0, [x1, #5040]
    7d94:	f949ec21 	ldr	x1, [x1, #5080]
    7d98:	cb000080 	sub	x0, x4, x0
    7d9c:	eb01401f 	cmp	x0, x1, lsl #16
    7da0:	54001e62 	b.cs	816c <f12+0xc6c>  // b.hs, b.nlast
    7da4:	91174264 	add	x4, x19, #0x5d0
    7da8:	d350fc01 	lsr	x1, x0, #16
    7dac:	8b010821 	add	x1, x1, x1, lsl #2
    7db0:	f949fc86 	ldr	x6, [x4, #5112]
    7db4:	d37df021 	lsl	x1, x1, #3
    7db8:	8b0100c5 	add	x5, x6, x1
    7dbc:	f94010a4 	ldr	x4, [x5, #32]
    7dc0:	b4001d44 	cbz	x4, 8168 <f12+0xc68>
    7dc4:	386168c1 	ldrb	w1, [x6, x1]
    7dc8:	7100083f 	cmp	w1, #0x2
    7dcc:	54001ca0 	b.eq	8160 <f12+0xc60>  // b.none
    7dd0:	7100043f 	cmp	w1, #0x1
    7dd4:	54001ca1 	b.ne	8168 <f12+0xc68>  // b.any
    7dd8:	294304a6 	ldp	w6, w1, [x5, #24]
    7ddc:	92403c00 	and	x0, x0, #0xffff
    7de0:	9b067c00 	mul	x0, x0, x6
    7de4:	d360fc00 	lsr	x0, x0, #32
    7de8:	eb01001f 	cmp	x0, x1
    7dec:	54001be2 	b.cs	8168 <f12+0xc68>  // b.hs, b.nlast
    7df0:	8b000084 	add	x4, x4, x0
    7df4:	39400098 	ldrb	w24, [x4]
    7df8:	7100071f 	cmp	w24, #0x1
    7dfc:	54001b61 	b.ne	8168 <f12+0xc68>  // b.any
    7e00:	b90013f8 	str	w24, [sp, #16]
    7e04:	eb1c005f 	cmp	x2, x28
    7e08:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7e0c:	91002359 	add	x25, x26, #0x8
    7e10:	b40034dc 	cbz	x28, 84a8 <f12+0xfa8>
    7e14:	f94007e0 	ldr	x0, [sp, #8]
    7e18:	d37df385 	lsl	x5, x28, #3
    7e1c:	aa1503e2 	mov	x2, x21
    7e20:	d2800001 	mov	x1, #0x0                   	// #0
    7e24:	91002000 	add	x0, x0, #0x8
    7e28:	1400000a 	b	7e50 <f12+0x950>
    7e2c:	fc616881 	ldr	d1, [x4, x1]
    7e30:	fd400440 	ldr	d0, [x2, #8]
    7e34:	1e613800 	fsub	d0, d0, d1
    7e38:	fc216b20 	str	d0, [x25, x1]
    7e3c:	91002021 	add	x1, x1, #0x8
    7e40:	f9400842 	ldr	x2, [x2, #16]
    7e44:	eb05003f 	cmp	x1, x5
    7e48:	540001c0 	b.eq	7e80 <f12+0x980>  // b.none
    7e4c:	f9400343 	ldr	x3, [x26]
    7e50:	aa0003e4 	mov	x4, x0
    7e54:	b6fffec3 	tbz	x3, #63, 7e2c <f12+0x92c>
    7e58:	f94007e3 	ldr	x3, [sp, #8]
    7e5c:	fd400440 	ldr	d0, [x2, #8]
    7e60:	f9400864 	ldr	x4, [x3, #16]
    7e64:	fc616881 	ldr	d1, [x4, x1]
    7e68:	1e613800 	fsub	d0, d0, d1
    7e6c:	fc216b20 	str	d0, [x25, x1]
    7e70:	91002021 	add	x1, x1, #0x8
    7e74:	f9400842 	ldr	x2, [x2, #16]
    7e78:	eb05003f 	cmp	x1, x5
    7e7c:	54fffe81 	b.ne	7e4c <f12+0x94c>  // b.any
    7e80:	b4003115 	cbz	x21, 84a0 <f12+0xfa0>
    7e84:	91174260 	add	x0, x19, #0x5d0
    7e88:	aa1503e2 	mov	x2, x21
    7e8c:	d280001a 	mov	x26, #0x0                   	// #0
    7e90:	f949ec06 	ldr	x6, [x0, #5080]
    7e94:	f949d807 	ldr	x7, [x0, #5040]
    7e98:	f949fc05 	ldr	x5, [x0, #5112]
    7e9c:	d370bcc6 	lsl	x6, x6, #16
    7ea0:	14000006 	b	7eb8 <f12+0x9b8>
    7ea4:	f9400842 	ldr	x2, [x2, #16]
    7ea8:	9100075a 	add	x26, x26, #0x1
    7eac:	f100005f 	cmp	x2, #0x0
    7eb0:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7eb4:	54000329 	b.ls	7f18 <f12+0xa18>  // b.plast
    7eb8:	cb070040 	sub	x0, x2, x7
    7ebc:	eb06001f 	cmp	x0, x6
    7ec0:	540002c2 	b.cs	7f18 <f12+0xa18>  // b.hs, b.nlast
    7ec4:	d350fc01 	lsr	x1, x0, #16
    7ec8:	8b010821 	add	x1, x1, x1, lsl #2
    7ecc:	d37df021 	lsl	x1, x1, #3
    7ed0:	8b0100a4 	add	x4, x5, x1
    7ed4:	f9401083 	ldr	x3, [x4, #32]
    7ed8:	b4000203 	cbz	x3, 7f18 <f12+0xa18>
    7edc:	386168a1 	ldrb	w1, [x5, x1]
    7ee0:	7100083f 	cmp	w1, #0x2
    7ee4:	54000de0 	b.eq	80a0 <f12+0xba0>  // b.none
    7ee8:	7100043f 	cmp	w1, #0x1
    7eec:	54000161 	b.ne	7f18 <f12+0xa18>  // b.any
    7ef0:	29430488 	ldp	w8, w1, [x4, #24]
    7ef4:	92403c00 	and	x0, x0, #0xffff
    7ef8:	9b087c00 	mul	x0, x0, x8
    7efc:	d360fc00 	lsr	x0, x0, #32
    7f00:	eb01001f 	cmp	x0, x1
    7f04:	540000a2 	b.cs	7f18 <f12+0xa18>  // b.hs, b.nlast
    7f08:	8b000063 	add	x3, x3, x0
    7f0c:	39400060 	ldrb	w0, [x3]
    7f10:	7100041f 	cmp	w0, #0x1
    7f14:	54fffc80 	b.eq	7ea4 <f12+0x9a4>  // b.none
    7f18:	eb1a039f 	cmp	x28, x26
    7f1c:	54000ca9 	b.ls	80b0 <f12+0xbb0>  // b.plast
    7f20:	d1002337 	sub	x23, x25, #0x8
    7f24:	9102a3f6 	add	x22, sp, #0xa8
    7f28:	91174278 	add	x24, x19, #0x5d0
    7f2c:	d2800014 	mov	x20, #0x0                   	// #0
    7f30:	14000012 	b	7f78 <f12+0xa78>
    7f34:	7100045f 	cmp	w2, #0x1
    7f38:	540001a1 	b.ne	7f6c <f12+0xa6c>  // b.any
    7f3c:	29430002 	ldp	w2, w0, [x0, #24]
    7f40:	92403c21 	and	x1, x1, #0xffff
    7f44:	9b027c21 	mul	x1, x1, x2
    7f48:	d360fc21 	lsr	x1, x1, #32
    7f4c:	eb00003f 	cmp	x1, x0
    7f50:	540000e2 	b.cs	7f6c <f12+0xa6c>  // b.hs, b.nlast
    7f54:	8b01037b 	add	x27, x27, x1
    7f58:	39400360 	ldrb	w0, [x27]
    7f5c:	7103fc1f 	cmp	w0, #0xff
    7f60:	54001b20 	b.eq	82c4 <f12+0xdc4>  // b.none
    7f64:	52800020 	mov	w0, #0x1                   	// #1
    7f68:	39000360 	strb	w0, [x27]
    7f6c:	d100079c 	sub	x28, x28, #0x1
    7f70:	eb1c035f 	cmp	x26, x28
    7f74:	54000362 	b.cs	7fe0 <f12+0xae0>  // b.hs, b.nlast
    7f78:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    7f7c:	aa1603e1 	mov	x1, x22
    7f80:	52800020 	mov	w0, #0x1                   	// #1
    7f84:	a90ad3e2 	stp	x2, x20, [sp, #168]
    7f88:	97fff5c6 	bl	56a0 <fwp_data.part.0.constprop.0>
    7f8c:	aa0003f4 	mov	x20, x0
    7f90:	f949db01 	ldr	x1, [x24, #5040]
    7f94:	f949ef00 	ldr	x0, [x24, #5080]
    7f98:	cb010281 	sub	x1, x20, x1
    7f9c:	eb00403f 	cmp	x1, x0, lsl #16
    7fa0:	54fffe62 	b.cs	7f6c <f12+0xa6c>  // b.hs, b.nlast
    7fa4:	d350fc22 	lsr	x2, x1, #16
    7fa8:	f949ff03 	ldr	x3, [x24, #5112]
    7fac:	8b020842 	add	x2, x2, x2, lsl #2
    7fb0:	d37df042 	lsl	x2, x2, #3
    7fb4:	8b020060 	add	x0, x3, x2
    7fb8:	f940101b 	ldr	x27, [x0, #32]
    7fbc:	b4fffd9b 	cbz	x27, 7f6c <f12+0xa6c>
    7fc0:	38626862 	ldrb	w2, [x3, x2]
    7fc4:	7100085f 	cmp	w2, #0x2
    7fc8:	54fffb61 	b.ne	7f34 <f12+0xa34>  // b.any
    7fcc:	72003c3f 	tst	w1, #0xffff
    7fd0:	54fffc40 	b.eq	7f58 <f12+0xa58>  // b.none
    7fd4:	d100079c 	sub	x28, x28, #0x1
    7fd8:	eb1c035f 	cmp	x26, x28
    7fdc:	54fffce3 	b.cc	7f78 <f12+0xa78>  // b.lo, b.ul, b.last
    7fe0:	b50006ba 	cbnz	x26, 80b4 <f12+0xbb4>
    7fe4:	b94013e0 	ldr	w0, [sp, #16]
    7fe8:	d2800038 	mov	x24, #0x1                   	// #1
    7fec:	d280001b 	mov	x27, #0x0                   	// #0
    7ff0:	7100001f 	cmp	w0, #0x0
    7ff4:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7ff8:	b40007db 	cbz	x27, 80f0 <f12+0xbf0>
    7ffc:	d100077b 	sub	x27, x27, #0x1
    8000:	91174273 	add	x19, x19, #0x5d0
    8004:	d503201f 	nop
    8008:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    800c:	aa1603e1 	mov	x1, x22
    8010:	52800020 	mov	w0, #0x1                   	// #1
    8014:	a90ad3e2 	stp	x2, x20, [sp, #168]
    8018:	97fff5a2 	bl	56a0 <fwp_data.part.0.constprop.0>
    801c:	aa0003f4 	mov	x20, x0
    8020:	f949da61 	ldr	x1, [x19, #5040]
    8024:	f949ee60 	ldr	x0, [x19, #5080]
    8028:	cb010281 	sub	x1, x20, x1
    802c:	eb00403f 	cmp	x1, x0, lsl #16
    8030:	54000302 	b.cs	8090 <f12+0xb90>  // b.hs, b.nlast
    8034:	d350fc22 	lsr	x2, x1, #16
    8038:	f949fe63 	ldr	x3, [x19, #5112]
    803c:	8b020842 	add	x2, x2, x2, lsl #2
    8040:	d37df042 	lsl	x2, x2, #3
    8044:	8b020060 	add	x0, x3, x2
    8048:	f940101a 	ldr	x26, [x0, #32]
    804c:	b400023a 	cbz	x26, 8090 <f12+0xb90>
    8050:	38626862 	ldrb	w2, [x3, x2]
    8054:	7100085f 	cmp	w2, #0x2
    8058:	540007e0 	b.eq	8154 <f12+0xc54>  // b.none
    805c:	7100045f 	cmp	w2, #0x1
    8060:	54000181 	b.ne	8090 <f12+0xb90>  // b.any
    8064:	29430002 	ldp	w2, w0, [x0, #24]
    8068:	92403c21 	and	x1, x1, #0xffff
    806c:	9b027c21 	mul	x1, x1, x2
    8070:	d360fc21 	lsr	x1, x1, #32
    8074:	eb00003f 	cmp	x1, x0
    8078:	540000c2 	b.cs	8090 <f12+0xb90>  // b.hs, b.nlast
    807c:	8b01035a 	add	x26, x26, x1
    8080:	39400340 	ldrb	w0, [x26]
    8084:	7103fc1f 	cmp	w0, #0xff
    8088:	54000600 	b.eq	8148 <f12+0xc48>  // b.none
    808c:	39000358 	strb	w24, [x26]
    8090:	d100077b 	sub	x27, x27, #0x1
    8094:	b100077f 	cmn	x27, #0x1
    8098:	54fffb81 	b.ne	8008 <f12+0xb08>  // b.any
    809c:	14000015 	b	80f0 <f12+0xbf0>
    80a0:	72003c1f 	tst	w0, #0xffff
    80a4:	54fff340 	b.eq	7f0c <f12+0xa0c>  // b.none
    80a8:	eb1a039f 	cmp	x28, x26
    80ac:	54fff3a8 	b.hi	7f20 <f12+0xa20>  // b.pmore
    80b0:	d2800014 	mov	x20, #0x0                   	// #0
    80b4:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    80b8:	aa1903e1 	mov	x1, x25
    80bc:	aa1503e0 	mov	x0, x21
    80c0:	f8408422 	ldr	x2, [x1], #8
    80c4:	f9000402 	str	x2, [x0, #8]
    80c8:	aa0003e2 	mov	x2, x0
    80cc:	f9400800 	ldr	x0, [x0, #16]
    80d0:	eb1a003f 	cmp	x1, x26
    80d4:	54ffff61 	b.ne	80c0 <f12+0xbc0>  // b.any
    80d8:	b94013e1 	ldr	w1, [sp, #16]
    80dc:	f9000854 	str	x20, [x2, #16]
    80e0:	aa1503f4 	mov	x20, x21
    80e4:	aa0003f5 	mov	x21, x0
    80e8:	34000041 	cbz	w1, 80f0 <f12+0xbf0>
    80ec:	d2800019 	mov	x25, #0x0                   	// #0
    80f0:	aa1903e0 	mov	x0, x25
    80f4:	97fff25f 	bl	4a70 <fwp_mem_free>
    80f8:	f94007e0 	ldr	x0, [sp, #8]
    80fc:	97fff9c1 	bl	6800 <fwp_drop4>
    8100:	aa1503e0 	mov	x0, x21
    8104:	97fff72f 	bl	5dc0 <fwp_drop0>
    8108:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    810c:	f947f400 	ldr	x0, [x0, #4072]
    8110:	f9405fe2 	ldr	x2, [sp, #184]
    8114:	f9400001 	ldr	x1, [x0]
    8118:	eb010042 	subs	x2, x2, x1
    811c:	d2800001 	mov	x1, #0x0                   	// #0
    8120:	54001e81 	b.ne	84f0 <f12+0xff0>  // b.any
    8124:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8128:	aa1403e0 	mov	x0, x20
    812c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8130:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8134:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8138:	a9506bf9 	ldp	x25, x26, [sp, #256]
    813c:	a95173fb 	ldp	x27, x28, [sp, #272]
    8140:	910483ff 	add	sp, sp, #0x120
    8144:	d65f03c0 	ret
    8148:	aa1a03e0 	mov	x0, x26
    814c:	97fff1a9 	bl	47f0 <fwp_rc_forget_slot>
    8150:	17ffffcf 	b	808c <f12+0xb8c>
    8154:	72003c3f 	tst	w1, #0xffff
    8158:	54fff9c1 	b.ne	8090 <f12+0xb90>  // b.any
    815c:	17ffffc9 	b	8080 <f12+0xb80>
    8160:	72003c1f 	tst	w0, #0xffff
    8164:	54ffe480 	b.eq	7df4 <f12+0x8f4>  // b.none
    8168:	b40014f5 	cbz	x21, 8404 <f12+0xf04>
    816c:	aa1503f4 	mov	x20, x21
    8170:	d2800016 	mov	x22, #0x0                   	// #0
    8174:	d503201f 	nop
    8178:	f9400a94 	ldr	x20, [x20, #16]
    817c:	aa1603e0 	mov	x0, x22
    8180:	910006d6 	add	x22, x22, #0x1
    8184:	b5ffffb4 	cbnz	x20, 8178 <f12+0xc78>
    8188:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    818c:	eb0102df 	cmp	x22, x1
    8190:	540019e8 	b.hi	84cc <f12+0xfcc>  // b.pmore
    8194:	91000800 	add	x0, x0, #0x2
    8198:	52800041 	mov	w1, #0x2                   	// #2
    819c:	d37df000 	lsl	x0, x0, #3
    81a0:	97fff354 	bl	4ef0 <fwp_heap_alloc>
    81a4:	eb16039f 	cmp	x28, x22
    81a8:	aa0003f9 	mov	x25, x0
    81ac:	9a96939c 	csel	x28, x28, x22, ls	// ls = plast
    81b0:	aa1503e1 	mov	x1, x21
    81b4:	d503201f 	nop
    81b8:	f9400420 	ldr	x0, [x1, #8]
    81bc:	f8347b20 	str	x0, [x25, x20, lsl #3]
    81c0:	91000694 	add	x20, x20, #0x1
    81c4:	f9400821 	ldr	x1, [x1, #16]
    81c8:	b5ffff81 	cbnz	x1, 81b8 <f12+0xcb8>
    81cc:	b400125c 	cbz	x28, 8414 <f12+0xf14>
    81d0:	f9400343 	ldr	x3, [x26]
    81d4:	b90013ff 	str	wzr, [sp, #16]
    81d8:	17ffff0f 	b	7e14 <f12+0x914>
    81dc:	72003c1f 	tst	w0, #0xffff
    81e0:	54ffd780 	b.eq	7cd0 <f12+0x7d0>  // b.none
    81e4:	d503201f 	nop
    81e8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    81ec:	eb00029f 	cmp	x20, x0
    81f0:	54001948 	b.hi	8518 <f12+0x1018>  // b.pmore
    81f4:	91000680 	add	x0, x20, #0x1
    81f8:	52800021 	mov	w1, #0x1                   	// #1
    81fc:	d37df000 	lsl	x0, x0, #3
    8200:	97fff33c 	bl	4ef0 <fwp_heap_alloc>
    8204:	91174262 	add	x2, x19, #0x5d0
    8208:	f9000014 	str	x20, [x0]
    820c:	aa0003fa 	mov	x26, x0
    8210:	f90007fa 	str	x26, [sp, #8]
    8214:	f949d841 	ldr	x1, [x2, #5040]
    8218:	f949ec40 	ldr	x0, [x2, #5080]
    821c:	cb010341 	sub	x1, x26, x1
    8220:	eb00403f 	cmp	x1, x0, lsl #16
    8224:	54000322 	b.cs	8288 <f12+0xd88>  // b.hs, b.nlast
    8228:	d350fc20 	lsr	x0, x1, #16
    822c:	f949fc43 	ldr	x3, [x2, #5112]
    8230:	8b000800 	add	x0, x0, x0, lsl #2
    8234:	d37df002 	lsl	x2, x0, #3
    8238:	8b020060 	add	x0, x3, x2
    823c:	f9401018 	ldr	x24, [x0, #32]
    8240:	b4000258 	cbz	x24, 8288 <f12+0xd88>
    8244:	38626862 	ldrb	w2, [x3, x2]
    8248:	7100085f 	cmp	w2, #0x2
    824c:	54000e80 	b.eq	841c <f12+0xf1c>  // b.none
    8250:	7100045f 	cmp	w2, #0x1
    8254:	540001a1 	b.ne	8288 <f12+0xd88>  // b.any
    8258:	29430002 	ldp	w2, w0, [x0, #24]
    825c:	92403c21 	and	x1, x1, #0xffff
    8260:	9b027c21 	mul	x1, x1, x2
    8264:	d360fc21 	lsr	x1, x1, #32
    8268:	eb00003f 	cmp	x1, x0
    826c:	540000e2 	b.cs	8288 <f12+0xd88>  // b.hs, b.nlast
    8270:	8b010318 	add	x24, x24, x1
    8274:	39400300 	ldrb	w0, [x24]
    8278:	7103fc1f 	cmp	w0, #0xff
    827c:	54001080 	b.eq	848c <f12+0xf8c>  // b.none
    8280:	52800020 	mov	w0, #0x1                   	// #1
    8284:	39000300 	strb	w0, [x24]
    8288:	aa1603e0 	mov	x0, x22
    828c:	17fffe97 	b	7ce8 <f12+0x7e8>
    8290:	52800041 	mov	w1, #0x2                   	// #2
    8294:	d2800100 	mov	x0, #0x8                   	// #8
    8298:	97fff316 	bl	4ef0 <fwp_heap_alloc>
    829c:	aa0003f8 	mov	x24, x0
    82a0:	91174260 	add	x0, x19, #0x5d0
    82a4:	f900031f 	str	xzr, [x24]
    82a8:	f949d801 	ldr	x1, [x0, #5040]
    82ac:	f949ec00 	ldr	x0, [x0, #5080]
    82b0:	cb010301 	sub	x1, x24, x1
    82b4:	eb00403f 	cmp	x1, x0, lsl #16
    82b8:	54000442 	b.cs	8340 <f12+0xe40>  // b.hs, b.nlast
    82bc:	d2800016 	mov	x22, #0x0                   	// #0
    82c0:	17fffd63 	b	784c <f12+0x34c>
    82c4:	aa1b03e0 	mov	x0, x27
    82c8:	97fff14a 	bl	47f0 <fwp_rc_forget_slot>
    82cc:	17ffff26 	b	7f64 <f12+0xa64>
    82d0:	f100039f 	cmp	x28, #0x0
    82d4:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    82d8:	54ffbde1 	b.ne	7a94 <f12+0x594>  // b.any
    82dc:	f9400be0 	ldr	x0, [sp, #16]
    82e0:	9101c294 	add	x20, x20, #0x70
    82e4:	f9402fe1 	ldr	x1, [sp, #88]
    82e8:	f9018a81 	str	x1, [x20, #784]
    82ec:	97fff025 	bl	4380 <fwp_tape_buffers_release>
    82f0:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    82f4:	f947e863 	ldr	x3, [x3, #4048]
    82f8:	d2800262 	mov	x2, #0x13                  	// #19
    82fc:	d2800021 	mov	x1, #0x1                   	// #1
    8300:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    8304:	91116000 	add	x0, x0, #0x458
    8308:	f9400063 	ldr	x3, [x3]
    830c:	97ffe99d 	bl	2980 <fwrite@plt>
    8310:	d2800000 	mov	x0, #0x0                   	// #0
    8314:	97ffe9a7 	bl	29b0 <fflush@plt>
    8318:	52800cc0 	mov	w0, #0x66                  	// #102
    831c:	97ffe9b5 	bl	29f0 <_Exit@plt>
    8320:	eb01033f 	cmp	x25, x1
    8324:	54ff9b40 	b.eq	768c <f12+0x18c>  // b.none
    8328:	aa0103f9 	mov	x25, x1
    832c:	9100043b 	add	x27, x1, #0x1
    8330:	f9403a9a 	ldr	x26, [x20, #112]
    8334:	d37ff821 	lsl	x1, x1, #1
    8338:	17fffcf3 	b	7704 <f12+0x204>
    833c:	b5ffabd6 	cbnz	x22, 78b4 <f12+0x3b4>
    8340:	d280001a 	mov	x26, #0x0                   	// #0
    8344:	17fffd82 	b	794c <f12+0x44c>
    8348:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0xd0>
    834c:	9106c000 	add	x0, x0, #0x1b0
    8350:	94001434 	bl	d420 <atexit>
    8354:	35fffce0 	cbnz	w0, 82f0 <f12+0xdf0>
    8358:	52800020 	mov	w0, #0x1                   	// #1
    835c:	b9034700 	str	w0, [x24, #836]
    8360:	17fffcb7 	b	763c <f12+0x13c>
    8364:	72003c3f 	tst	w1, #0xffff
    8368:	54ffaa41 	b.ne	78b0 <f12+0x3b0>  // b.any
    836c:	17fffd4c 	b	789c <f12+0x39c>
    8370:	72003c3f 	tst	w1, #0xffff
    8374:	54ff9360 	b.eq	75e0 <f12+0xe0>  // b.none
    8378:	aa1703e0 	mov	x0, x23
    837c:	97fff6ed 	bl	5f30 <fwp_closure_drop>
    8380:	b5ff9435 	cbnz	x21, 7604 <f12+0x104>
    8384:	52800000 	mov	w0, #0x0                   	// #0
    8388:	d2800017 	mov	x23, #0x0                   	// #0
    838c:	97ffec99 	bl	35f0 <descent_phase_step>
    8390:	17fffca8 	b	7630 <f12+0x130>
    8394:	aa1b03fc 	mov	x28, x27
    8398:	17fffdaa 	b	7a40 <f12+0x540>
    839c:	72003c3f 	tst	w1, #0xffff
    83a0:	54ffc501 	b.ne	7c40 <f12+0x740>  // b.any
    83a4:	17fffe22 	b	7c2c <f12+0x72c>
    83a8:	3cc98002 	ldur	q2, [x0, #152]
    83ac:	91026001 	add	x1, x0, #0x98
    83b0:	3cca8001 	ldur	q1, [x0, #168]
    83b4:	f900681f 	str	xzr, [x0, #208]
    83b8:	4f000400 	movi	v0.4s, #0x0
    83bc:	ad010702 	stp	q2, q1, [x24, #32]
    83c0:	a94b8002 	ldp	x2, x0, [x0, #184]
    83c4:	f9000f00 	str	x0, [x24, #24]
    83c8:	f9401820 	ldr	x0, [x1, #48]
    83cc:	f9002302 	str	x2, [x24, #64]
    83d0:	f9002700 	str	x0, [x24, #72]
    83d4:	ad000020 	stp	q0, q0, [x1]
    83d8:	3d800820 	str	q0, [x1, #32]
    83dc:	f900183f 	str	xzr, [x1, #48]
    83e0:	17fffcd7 	b	773c <f12+0x23c>
    83e4:	d37ffb38 	lsl	x24, x25, #1
    83e8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    83ec:	eb00031f 	cmp	x24, x0
    83f0:	9a80d318 	csel	x24, x24, x0, le
    83f4:	8b180701 	add	x1, x24, x24, lsl #1
    83f8:	8b010b01 	add	x1, x24, x1, lsl #2
    83fc:	d37df021 	lsl	x1, x1, #3
    8400:	17fffcae 	b	76b8 <f12+0x1b8>
    8404:	52800041 	mov	w1, #0x2                   	// #2
    8408:	d2800100 	mov	x0, #0x8                   	// #8
    840c:	97fff2b9 	bl	4ef0 <fwp_heap_alloc>
    8410:	aa0003f9 	mov	x25, x0
    8414:	d2800014 	mov	x20, #0x0                   	// #0
    8418:	17ffff36 	b	80f0 <f12+0xbf0>
    841c:	72003c3f 	tst	w1, #0xffff
    8420:	54fff2a0 	b.eq	8274 <f12+0xd74>  // b.none
    8424:	aa1603e0 	mov	x0, x22
    8428:	17fffe30 	b	7ce8 <f12+0x7e8>
    842c:	aa0203e0 	mov	x0, x2
    8430:	d2800101 	mov	x1, #0x8                   	// #8
    8434:	f90017e2 	str	x2, [sp, #40]
    8438:	97ffe90a 	bl	2860 <calloc@plt>
    843c:	f94017e2 	ldr	x2, [sp, #40]
    8440:	aa0003fa 	mov	x26, x0
    8444:	17fffd91 	b	7a88 <f12+0x588>
    8448:	f9400343 	ldr	x3, [x26]
    844c:	b7fffdc3 	tbnz	x3, #63, 8404 <f12+0xf04>
    8450:	91174261 	add	x1, x19, #0x5d0
    8454:	f94007e4 	ldr	x4, [sp, #8]
    8458:	f949d820 	ldr	x0, [x1, #5040]
    845c:	f949ec21 	ldr	x1, [x1, #5080]
    8460:	cb000080 	sub	x0, x4, x0
    8464:	eb01401f 	cmp	x0, x1, lsl #16
    8468:	54fffce2 	b.cs	8404 <f12+0xf04>  // b.hs, b.nlast
    846c:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8470:	17fffe4d 	b	7da4 <f12+0x8a4>
    8474:	aa1903e0 	mov	x0, x25
    8478:	97fff0de 	bl	47f0 <fwp_rc_forget_slot>
    847c:	17fffd0b 	b	78a8 <f12+0x3a8>
    8480:	aa1703e0 	mov	x0, x23
    8484:	97fff0db 	bl	47f0 <fwp_rc_forget_slot>
    8488:	17fffdec 	b	7c38 <f12+0x738>
    848c:	aa1803e0 	mov	x0, x24
    8490:	97fff0d8 	bl	47f0 <fwp_rc_forget_slot>
    8494:	17ffff7b 	b	8280 <f12+0xd80>
    8498:	97fff08f 	bl	46d4 <fwp_rc_wide_dup>
    849c:	17fffc57 	b	75f8 <f12+0xf8>
    84a0:	d280001a 	mov	x26, #0x0                   	// #0
    84a4:	17fffe9f 	b	7f20 <f12+0xa20>
    84a8:	d2800019 	mov	x25, #0x0                   	// #0
    84ac:	d2800014 	mov	x20, #0x0                   	// #0
    84b0:	17ffff10 	b	80f0 <f12+0xbf0>
    84b4:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    84b8:	91224000 	add	x0, x0, #0x890
    84bc:	97ffecd1 	bl	3800 <fwp_trap>
    84c0:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    84c4:	911fe000 	add	x0, x0, #0x7f8
    84c8:	97ffecce 	bl	3800 <fwp_trap>
    84cc:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    84d0:	9123c000 	add	x0, x0, #0x8f0
    84d4:	97ffeccb 	bl	3800 <fwp_trap>
    84d8:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    84dc:	91264000 	add	x0, x0, #0x990
    84e0:	97ffecc8 	bl	3800 <fwp_trap>
    84e4:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    84e8:	91254000 	add	x0, x0, #0x950
    84ec:	97ffecc5 	bl	3800 <fwp_trap>
    84f0:	97ffe8e4 	bl	2880 <__stack_chk_fail@plt>
    84f4:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    84f8:	91210000 	add	x0, x0, #0x840
    84fc:	97ffecc1 	bl	3800 <fwp_trap>
    8500:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    8504:	91240000 	add	x0, x0, #0x900
    8508:	97ffecbe 	bl	3800 <fwp_trap>
    850c:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    8510:	91248000 	add	x0, x0, #0x920
    8514:	97ffecbb 	bl	3800 <fwp_trap>
    8518:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    851c:	91260000 	add	x0, x0, #0x980
    8520:	97ffecb8 	bl	3800 <fwp_trap>
    8524:	97ffe8eb 	bl	28d0 <abort@plt>
    8528:	97ffe956 	bl	2a80 <fwp_trap_overflow.constprop.0>
    852c:	d503201f 	nop

0000000000008530 <fwp_owned_entry12>:
    8530:	f9400000 	ldr	x0, [x0]
    8534:	17fffbf3 	b	7500 <f12>
    8538:	d503201f 	nop
    853c:	d503201f 	nop

0000000000008540 <e12>:
    8540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8544:	910003fd 	mov	x29, sp
    8548:	f9000bf3 	str	x19, [sp, #16]
    854c:	f9400013 	ldr	x19, [x0]
    8550:	aa1303e0 	mov	x0, x19
    8554:	97fff49b 	bl	57c0 <fwp_rc_share>
    8558:	aa1303e0 	mov	x0, x19
    855c:	97fffbe9 	bl	7500 <f12>
    8560:	aa0003f3 	mov	x19, x0
    8564:	97fff497 	bl	57c0 <fwp_rc_share>
    8568:	aa1303e0 	mov	x0, x19
    856c:	f9400bf3 	ldr	x19, [sp, #16]
    8570:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8574:	d65f03c0 	ret
    8578:	d503201f 	nop
    857c:	d503201f 	nop

0000000000008580 <fwp_write>:
    8580:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8584:	910003fd 	mov	x29, sp
    8588:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    858c:	f947f484 	ldr	x4, [x4, #4072]
    8590:	a90153f3 	stp	x19, x20, [sp, #16]
    8594:	d10943ff 	sub	sp, sp, #0x250
    8598:	b9400045 	ldr	w5, [x2]
    859c:	aa0003f4 	mov	x20, x0
    85a0:	f9400080 	ldr	x0, [x4]
    85a4:	f90127e0 	str	x0, [sp, #584]
    85a8:	d2800000 	mov	x0, #0x0                   	// #0
    85ac:	710064bf 	cmp	w5, #0x19
    85b0:	54000408 	b.hi	8630 <fwp_write+0xb0>  // b.pmore
    85b4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xbb0>
    85b8:	aa0103f3 	mov	x19, x1
    85bc:	91068000 	add	x0, x0, #0x1a0
    85c0:	f9013bf5 	str	x21, [sp, #624]
    85c4:	f9013ff6 	str	x22, [sp, #632]
    85c8:	f90153fb 	str	x27, [sp, #672]
    85cc:	f90157fc 	str	x28, [sp, #680]
    85d0:	aa0203fc 	mov	x28, x2
    85d4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    85d8:	10000061 	adr	x1, 85e4 <fwp_write+0x64>
    85dc:	8b20a820 	add	x0, x1, w0, sxth #2
    85e0:	d61f0000 	br	x0
    85e4:	910123e0 	add	x0, sp, #0x48
    85e8:	aa1303e5 	mov	x5, x19
    85ec:	b0000024 	adrp	x4, d000 <__divti3+0x2d0>
    85f0:	aa0003f3 	mov	x19, x0
    85f4:	9127c084 	add	x4, x4, #0x9f0
    85f8:	d2804003 	mov	x3, #0x200                 	// #512
    85fc:	aa0303e1 	mov	x1, x3
    8600:	52800042 	mov	w2, #0x2                   	// #2
    8604:	97ffe87b 	bl	27f0 <__snprintf_chk@plt>
    8608:	aa1303e0 	mov	x0, x19
    860c:	97ffe841 	bl	2710 <strlen@plt>
    8610:	aa1303e1 	mov	x1, x19
    8614:	aa0003e2 	mov	x2, x0
    8618:	aa1403e0 	mov	x0, x20
    861c:	97ffebdd 	bl	3590 <buf_put>
    8620:	f9413bf5 	ldr	x21, [sp, #624]
    8624:	f9413ff6 	ldr	x22, [sp, #632]
    8628:	f94153fb 	ldr	x27, [sp, #672]
    862c:	f94157fc 	ldr	x28, [sp, #680]
    8630:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8634:	f947f400 	ldr	x0, [x0, #4072]
    8638:	f94127e2 	ldr	x2, [sp, #584]
    863c:	f9400001 	ldr	x1, [x0]
    8640:	eb010042 	subs	x2, x2, x1
    8644:	d2800001 	mov	x1, #0x0                   	// #0
    8648:	540077c1 	b.ne	9540 <fwp_write+0xfc0>  // b.any
    864c:	910943ff 	add	sp, sp, #0x250
    8650:	a94153f3 	ldp	x19, x20, [sp, #16]
    8654:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8658:	d65f03c0 	ret
    865c:	910123e0 	add	x0, sp, #0x48
    8660:	aa1303e5 	mov	x5, x19
    8664:	b0000024 	adrp	x4, d000 <__divti3+0x2d0>
    8668:	aa0003f3 	mov	x19, x0
    866c:	9127a084 	add	x4, x4, #0x9e8
    8670:	d2804003 	mov	x3, #0x200                 	// #512
    8674:	17ffffe2 	b	85fc <fwp_write+0x7c>
    8678:	71004cbf 	cmp	w5, #0x13
    867c:	b0000020 	adrp	x0, d000 <__divti3+0x2d0>
    8680:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8684:	91276000 	add	x0, x0, #0x9d8
    8688:	91278021 	add	x1, x1, #0x9e0
    868c:	d2800082 	mov	x2, #0x4                   	// #4
    8690:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8694:	aa1403e0 	mov	x0, x20
    8698:	f90143f7 	str	x23, [sp, #640]
    869c:	d2800016 	mov	x22, #0x0                   	// #0
    86a0:	f90147f8 	str	x24, [sp, #648]
    86a4:	97ffebbb 	bl	3590 <buf_put>
    86a8:	f9400260 	ldr	x0, [x19]
    86ac:	b0000037 	adrp	x23, d000 <__divti3+0x2d0>
    86b0:	d2800015 	mov	x21, #0x0                   	// #0
    86b4:	912982f7 	add	x23, x23, #0xa60
    86b8:	b40047a0 	cbz	x0, 8fac <fwp_write+0xa2c>
    86bc:	b9400380 	ldr	w0, [x28]
    86c0:	52800003 	mov	w3, #0x0                   	// #0
    86c4:	f9401f82 	ldr	x2, [x28, #56]
    86c8:	71004c1f 	cmp	w0, #0x13
    86cc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    86d0:	aa1403e0 	mov	x0, x20
    86d4:	8b010e61 	add	x1, x19, x1, lsl #3
    86d8:	f9400421 	ldr	x1, [x1, #8]
    86dc:	97ffffa9 	bl	8580 <fwp_write>
    86e0:	b9400380 	ldr	w0, [x28]
    86e4:	7100481f 	cmp	w0, #0x12
    86e8:	54004b40 	b.eq	9050 <fwp_write+0xad0>  // b.none
    86ec:	f9400260 	ldr	x0, [x19]
    86f0:	910006b5 	add	x21, x21, #0x1
    86f4:	91000ad6 	add	x22, x22, #0x2
    86f8:	eb15001f 	cmp	x0, x21
    86fc:	54004589 	b.ls	8fac <fwp_write+0xa2c>  // b.plast
    8700:	aa1703e1 	mov	x1, x23
    8704:	aa1403e0 	mov	x0, x20
    8708:	d2800042 	mov	x2, #0x2                   	// #2
    870c:	97ffeba1 	bl	3590 <buf_put>
    8710:	17ffffeb 	b	86bc <fwp_write+0x13c>
    8714:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8718:	91286021 	add	x1, x1, #0xa18
    871c:	d28000c2 	mov	x2, #0x6                   	// #6
    8720:	aa1403e0 	mov	x0, x20
    8724:	91004273 	add	x19, x19, #0x10
    8728:	97ffeb9a 	bl	3590 <buf_put>
    872c:	aa1303e0 	mov	x0, x19
    8730:	97ffe7f8 	bl	2710 <strlen@plt>
    8734:	aa1303e1 	mov	x1, x19
    8738:	aa0003e2 	mov	x2, x0
    873c:	aa1403e0 	mov	x0, x20
    8740:	97ffeb94 	bl	3590 <buf_put>
    8744:	528007c3 	mov	w3, #0x3e                  	// #62
    8748:	aa1403e0 	mov	x0, x20
    874c:	91001fe1 	add	x1, sp, #0x7
    8750:	d2800022 	mov	x2, #0x1                   	// #1
    8754:	39001fe3 	strb	w3, [sp, #7]
    8758:	17ffffb1 	b	861c <fwp_write+0x9c>
    875c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8760:	f947f400 	ldr	x0, [x0, #4072]
    8764:	f94127e2 	ldr	x2, [sp, #584]
    8768:	f9400001 	ldr	x1, [x0]
    876c:	eb010042 	subs	x2, x2, x1
    8770:	d2800001 	mov	x1, #0x0                   	// #0
    8774:	540034e1 	b.ne	8e10 <fwp_write+0x890>  // b.any
    8778:	f9413bf5 	ldr	x21, [sp, #624]
    877c:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8780:	f9413ff6 	ldr	x22, [sp, #632]
    8784:	aa1403e0 	mov	x0, x20
    8788:	9127e021 	add	x1, x1, #0x9f8
    878c:	d2800142 	mov	x2, #0xa                   	// #10
    8790:	f94153fb 	ldr	x27, [sp, #672]
    8794:	f94157fc 	ldr	x28, [sp, #680]
    8798:	910943ff 	add	sp, sp, #0x250
    879c:	a94153f3 	ldp	x19, x20, [sp, #16]
    87a0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    87a4:	17ffeb7b 	b	3590 <buf_put>
    87a8:	f9400456 	ldr	x22, [x2, #8]
    87ac:	f90143f7 	str	x23, [sp, #640]
    87b0:	f90147f8 	str	x24, [sp, #648]
    87b4:	b4005b16 	cbz	x22, 9314 <fwp_write+0xd94>
    87b8:	aa1603e0 	mov	x0, x22
    87bc:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    87c0:	9129e021 	add	x1, x1, #0xa78
    87c4:	97ffe84f 	bl	2900 <strcmp@plt>
    87c8:	2a0003f5 	mov	w21, w0
    87cc:	34005fe0 	cbz	w0, 93c8 <fwp_write+0xe48>
    87d0:	aa1603e0 	mov	x0, x22
    87d4:	97ffe7cf 	bl	2710 <strlen@plt>
    87d8:	aa1603e1 	mov	x1, x22
    87dc:	aa0003e2 	mov	x2, x0
    87e0:	aa1403e0 	mov	x0, x20
    87e4:	97ffeb6b 	bl	3590 <buf_put>
    87e8:	52800403 	mov	w3, #0x20                  	// #32
    87ec:	91001ff5 	add	x21, sp, #0x7
    87f0:	aa1503e1 	mov	x1, x21
    87f4:	aa1403e0 	mov	x0, x20
    87f8:	d2800022 	mov	x2, #0x1                   	// #1
    87fc:	39001fe3 	strb	w3, [sp, #7]
    8800:	97ffeb64 	bl	3590 <buf_put>
    8804:	52800f63 	mov	w3, #0x7b                  	// #123
    8808:	aa1403e0 	mov	x0, x20
    880c:	aa1503e1 	mov	x1, x21
    8810:	d2800022 	mov	x2, #0x1                   	// #1
    8814:	39001fe3 	strb	w3, [sp, #7]
    8818:	97ffeb5e 	bl	3590 <buf_put>
    881c:	b9401380 	ldr	w0, [x28, #16]
    8820:	52800018 	mov	w24, #0x0                   	// #0
    8824:	7100001f 	cmp	w0, #0x0
    8828:	54003aad 	b.le	8f7c <fwp_write+0x9fc>
    882c:	f9014bf9 	str	x25, [sp, #656]
    8830:	b0000039 	adrp	x25, d000 <__divti3+0x2d0>
    8834:	912a8339 	add	x25, x25, #0xaa0
    8838:	f9014ffa 	str	x26, [sp, #664]
    883c:	b000003a 	adrp	x26, d000 <__divti3+0x2d0>
    8840:	9129835a 	add	x26, x26, #0xa60
    8844:	91002276 	add	x22, x19, #0x8
    8848:	d2800013 	mov	x19, #0x0                   	// #0
    884c:	b5003e93 	cbnz	x19, 901c <fwp_write+0xa9c>
    8850:	d37df277 	lsl	x23, x19, #3
    8854:	34003cb8 	cbz	w24, 8fe8 <fwp_write+0xa68>
    8858:	f9401382 	ldr	x2, [x28, #32]
    885c:	aa1403e0 	mov	x0, x20
    8860:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8864:	52800003 	mov	w3, #0x0                   	// #0
    8868:	f8776842 	ldr	x2, [x2, x23]
    886c:	91000673 	add	x19, x19, #0x1
    8870:	97ffff44 	bl	8580 <fwp_write>
    8874:	b9401380 	ldr	w0, [x28, #16]
    8878:	6b13001f 	cmp	w0, w19
    887c:	54fffe8c 	b.gt	884c <fwp_write+0x2cc>
    8880:	f9414bf9 	ldr	x25, [sp, #656]
    8884:	f9414ffa 	ldr	x26, [sp, #664]
    8888:	340037b8 	cbz	w24, 8f7c <fwp_write+0x9fc>
    888c:	52800523 	mov	w3, #0x29                  	// #41
    8890:	aa1503e1 	mov	x1, x21
    8894:	aa1403e0 	mov	x0, x20
    8898:	d2800022 	mov	x2, #0x1                   	// #1
    889c:	39001fe3 	strb	w3, [sp, #7]
    88a0:	97ffeb3c 	bl	3590 <buf_put>
    88a4:	f9413bf5 	ldr	x21, [sp, #624]
    88a8:	f9413ff6 	ldr	x22, [sp, #632]
    88ac:	f94143f7 	ldr	x23, [sp, #640]
    88b0:	f94147f8 	ldr	x24, [sp, #648]
    88b4:	f94153fb 	ldr	x27, [sp, #672]
    88b8:	f94157fc 	ldr	x28, [sp, #680]
    88bc:	17ffff5d 	b	8630 <fwp_write+0xb0>
    88c0:	b9404855 	ldr	w21, [x2, #72]
    88c4:	aa1403e0 	mov	x0, x20
    88c8:	93407eb6 	sxtw	x22, w21
    88cc:	91000ac1 	add	x1, x22, #0x2
    88d0:	97ffeafd 	bl	34c4 <buf_grow>
    88d4:	a9400281 	ldp	x1, x0, [x20]
    88d8:	528e8603 	mov	w3, #0x7430                	// #29744
    88dc:	78206823 	strh	w3, [x1, x0]
    88e0:	8b000022 	add	x2, x1, x0
    88e4:	710002bf 	cmp	w21, #0x0
    88e8:	540036cd 	b.le	8fc0 <fwp_write+0xa40>
    88ec:	110006a3 	add	w3, w21, #0x1
    88f0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    88f4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    88f8:	91000449 	add	x9, x2, #0x1
    88fc:	8b23c043 	add	x3, x2, w3, sxtw
    8900:	f28aaac6 	movk	x6, #0x5556
    8904:	f2955568 	movk	x8, #0xaaab
    8908:	1400000d 	b	893c <fwp_write+0x3bc>
    890c:	d2800021 	mov	x1, #0x1                   	// #1
    8910:	528005a5 	mov	w5, #0x2d                  	// #45
    8914:	f100001f 	cmp	x0, #0x0
    8918:	9b467e60 	smulh	x0, x19, x6
    891c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8920:	381ff465 	strb	w5, [x3], #-1
    8924:	cb040000 	sub	x0, x0, x4
    8928:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    892c:	cb020000 	sub	x0, x0, x2
    8930:	8b010013 	add	x19, x0, x1
    8934:	eb03013f 	cmp	x9, x3
    8938:	54003440 	b.eq	8fc0 <fwp_write+0xa40>  // b.none
    893c:	9b467e60 	smulh	x0, x19, x6
    8940:	937ffe64 	asr	x4, x19, #63
    8944:	52800605 	mov	w5, #0x30                  	// #48
    8948:	cb040000 	sub	x0, x0, x4
    894c:	8b000400 	add	x0, x0, x0, lsl #1
    8950:	cb000260 	sub	x0, x19, x0
    8954:	91000c01 	add	x1, x0, #0x3
    8958:	9bc87c22 	umulh	x2, x1, x8
    895c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8960:	8b4204e2 	add	x2, x7, x2, lsr #1
    8964:	eb020021 	subs	x1, x1, x2
    8968:	54fffd60 	b.eq	8914 <fwp_write+0x394>  // b.none
    896c:	f100043f 	cmp	x1, #0x1
    8970:	54fffce1 	b.ne	890c <fwp_write+0x38c>  // b.any
    8974:	d2800001 	mov	x1, #0x0                   	// #0
    8978:	52800565 	mov	w5, #0x2b                  	// #43
    897c:	17ffffe6 	b	8914 <fwp_write+0x394>
    8980:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8984:	f947f400 	ldr	x0, [x0, #4072]
    8988:	f94127e2 	ldr	x2, [sp, #584]
    898c:	f9400001 	ldr	x1, [x0]
    8990:	eb010042 	subs	x2, x2, x1
    8994:	d2800001 	mov	x1, #0x0                   	// #0
    8998:	540023c1 	b.ne	8e10 <fwp_write+0x890>  // b.any
    899c:	f9413bf5 	ldr	x21, [sp, #624]
    89a0:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    89a4:	f9413ff6 	ldr	x22, [sp, #632]
    89a8:	aa1403e0 	mov	x0, x20
    89ac:	91282021 	add	x1, x1, #0xa08
    89b0:	d2800102 	mov	x2, #0x8                   	// #8
    89b4:	17ffff77 	b	8790 <fwp_write+0x210>
    89b8:	aa1403e0 	mov	x0, x20
    89bc:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    89c0:	d28000c2 	mov	x2, #0x6                   	// #6
    89c4:	9129a021 	add	x1, x1, #0xa68
    89c8:	97ffeaf2 	bl	3590 <buf_put>
    89cc:	d2800015 	mov	x21, #0x0                   	// #0
    89d0:	f9400263 	ldr	x3, [x19]
    89d4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    89d8:	54002c60 	b.eq	8f64 <fwp_write+0x9e4>  // b.none
    89dc:	f9401f82 	ldr	x2, [x28, #56]
    89e0:	f90143f7 	str	x23, [sp, #640]
    89e4:	f90147f8 	str	x24, [sp, #648]
    89e8:	d2800857 	mov	x23, #0x42                  	// #66
    89ec:	f9014bf9 	str	x25, [sp, #656]
    89f0:	b0000036 	adrp	x22, d000 <__divti3+0x2d0>
    89f4:	f9014ffa 	str	x26, [sp, #664]
    89f8:	912982d6 	add	x22, x22, #0xa60
    89fc:	d2800038 	mov	x24, #0x1                   	// #1
    8a00:	f2a18017 	movk	x23, #0xc00, lsl #16
    8a04:	d2809099 	mov	x25, #0x484                 	// #1156
    8a08:	b40004a2 	cbz	x2, 8a9c <fwp_write+0x51c>
    8a0c:	b9400040 	ldr	w0, [x2]
    8a10:	7100701f 	cmp	w0, #0x1c
    8a14:	540042c0 	b.eq	926c <fwp_write+0xcec>  // b.none
    8a18:	71006c1f 	cmp	w0, #0x1b
    8a1c:	54000408 	b.hi	8a9c <fwp_write+0x51c>  // b.pmore
    8a20:	9ac02301 	lsl	x1, x24, x0
    8a24:	ea17003f 	tst	x1, x23
    8a28:	540036a1 	b.ne	90fc <fwp_write+0xb7c>  // b.any
    8a2c:	ea19003f 	tst	x1, x25
    8a30:	54003521 	b.ne	90d4 <fwp_write+0xb54>  // b.any
    8a34:	d2800424 	mov	x4, #0x21                  	// #33
    8a38:	ea04003f 	tst	x1, x4
    8a3c:	54000300 	b.eq	8a9c <fwp_write+0x51c>  // b.none
    8a40:	b7f849c3 	tbnz	x3, #63, 9378 <fwp_write+0xdf8>
    8a44:	91002261 	add	x1, x19, #0x8
    8a48:	8b150021 	add	x1, x1, x21
    8a4c:	39400021 	ldrb	w1, [x1]
    8a50:	7100001f 	cmp	w0, #0x0
    8a54:	93401c23 	sxtb	x3, w1
    8a58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8a5c:	d503201f 	nop
    8a60:	aa1403e0 	mov	x0, x20
    8a64:	52800003 	mov	w3, #0x0                   	// #0
    8a68:	97fffec6 	bl	8580 <fwp_write>
    8a6c:	910006b5 	add	x21, x21, #0x1
    8a70:	f9400260 	ldr	x0, [x19]
    8a74:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8a78:	eb0002bf 	cmp	x21, x0
    8a7c:	540026c2 	b.cs	8f54 <fwp_write+0x9d4>  // b.hs, b.nlast
    8a80:	d2800042 	mov	x2, #0x2                   	// #2
    8a84:	aa1603e1 	mov	x1, x22
    8a88:	aa1403e0 	mov	x0, x20
    8a8c:	97ffeac1 	bl	3590 <buf_put>
    8a90:	f9401f82 	ldr	x2, [x28, #56]
    8a94:	f9400263 	ldr	x3, [x19]
    8a98:	b5fffba2 	cbnz	x2, 8a0c <fwp_write+0x48c>
    8a9c:	d37df2a0 	lsl	x0, x21, #3
    8aa0:	b7f83f03 	tbnz	x3, #63, 9280 <fwp_write+0xd00>
    8aa4:	91002261 	add	x1, x19, #0x8
    8aa8:	8b000020 	add	x0, x1, x0
    8aac:	f9400001 	ldr	x1, [x0]
    8ab0:	17ffffec 	b	8a60 <fwp_write+0x4e0>
    8ab4:	a9400e62 	ldp	x2, x3, [x19]
    8ab8:	b7f83ca3 	tbnz	x3, #63, 924c <fwp_write+0xccc>
    8abc:	910123f5 	add	x21, sp, #0x48
    8ac0:	aa1503e0 	mov	x0, x21
    8ac4:	97ffe8d7 	bl	2e20 <fwp_fmt_u128>
    8ac8:	aa1503e0 	mov	x0, x21
    8acc:	97ffe711 	bl	2710 <strlen@plt>
    8ad0:	aa1503e1 	mov	x1, x21
    8ad4:	aa0003e2 	mov	x2, x0
    8ad8:	17fffed0 	b	8618 <fwp_write+0x98>
    8adc:	fd015be8 	str	d8, [sp, #688]
    8ae0:	1e270268 	fmov	s8, w19
    8ae4:	fd015fe9 	str	d9, [sp, #696]
    8ae8:	1e282100 	fcmp	s8, s8
    8aec:	54004d26 	b.vs	9490 <fwp_write+0xf10>
    8af0:	1e20c101 	fabs	s1, s8
    8af4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8af8:	1e270000 	fmov	s0, w0
    8afc:	1e202020 	fcmp	s1, s0
    8b00:	54002c0d 	b.le	9080 <fwp_write+0xb00>
    8b04:	1e202118 	fcmpe	s8, #0.0
    8b08:	b0000022 	adrp	x2, d000 <__divti3+0x2d0>
    8b0c:	9114a042 	add	x2, x2, #0x528
    8b10:	910123f5 	add	x21, sp, #0x48
    8b14:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8b18:	9126e021 	add	x1, x1, #0x9b8
    8b1c:	aa1503e0 	mov	x0, x21
    8b20:	9a81c041 	csel	x1, x2, x1, gt
    8b24:	97ffe7a7 	bl	29c0 <strcpy@plt>
    8b28:	aa1503e0 	mov	x0, x21
    8b2c:	97ffe6f9 	bl	2710 <strlen@plt>
    8b30:	aa1503e1 	mov	x1, x21
    8b34:	aa0003e2 	mov	x2, x0
    8b38:	aa1403e0 	mov	x0, x20
    8b3c:	97ffea95 	bl	3590 <buf_put>
    8b40:	f9413bf5 	ldr	x21, [sp, #624]
    8b44:	f9413ff6 	ldr	x22, [sp, #632]
    8b48:	f94153fb 	ldr	x27, [sp, #672]
    8b4c:	f94157fc 	ldr	x28, [sp, #680]
    8b50:	fd415be8 	ldr	d8, [sp, #688]
    8b54:	fd415fe9 	ldr	d9, [sp, #696]
    8b58:	17fffeb6 	b	8630 <fwp_write+0xb0>
    8b5c:	f9400276 	ldr	x22, [x19]
    8b60:	34002e03 	cbz	w3, 9120 <fwp_write+0xba0>
    8b64:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8b68:	f947f400 	ldr	x0, [x0, #4072]
    8b6c:	f94127e2 	ldr	x2, [sp, #584]
    8b70:	f9400001 	ldr	x1, [x0]
    8b74:	eb010042 	subs	x2, x2, x1
    8b78:	d2800001 	mov	x1, #0x0                   	// #0
    8b7c:	540014a1 	b.ne	8e10 <fwp_write+0x890>  // b.any
    8b80:	aa1603e2 	mov	x2, x22
    8b84:	91002261 	add	x1, x19, #0x8
    8b88:	f9413bf5 	ldr	x21, [sp, #624]
    8b8c:	aa1403e0 	mov	x0, x20
    8b90:	f9413ff6 	ldr	x22, [sp, #632]
    8b94:	17fffeff 	b	8790 <fwp_write+0x210>
    8b98:	fd015be8 	str	d8, [sp, #688]
    8b9c:	9e670268 	fmov	d8, x19
    8ba0:	fd015fe9 	str	d9, [sp, #696]
    8ba4:	1e682100 	fcmp	d8, d8
    8ba8:	54004746 	b.vs	9490 <fwp_write+0xf10>
    8bac:	1e60c101 	fabs	d1, d8
    8bb0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8bb4:	9e670000 	fmov	d0, x0
    8bb8:	910123f5 	add	x21, sp, #0x48
    8bbc:	52800033 	mov	w19, #0x1                   	// #1
    8bc0:	1e602020 	fcmp	d1, d0
    8bc4:	540001ad 	b.le	8bf8 <fwp_write+0x678>
    8bc8:	1e602118 	fcmpe	d8, #0.0
    8bcc:	b0000022 	adrp	x2, d000 <__divti3+0x2d0>
    8bd0:	9114a042 	add	x2, x2, #0x528
    8bd4:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8bd8:	9126e021 	add	x1, x1, #0x9b8
    8bdc:	aa1503e0 	mov	x0, x21
    8be0:	9a81c041 	csel	x1, x2, x1, gt
    8be4:	97ffe777 	bl	29c0 <strcpy@plt>
    8be8:	17ffffd0 	b	8b28 <fwp_write+0x5a8>
    8bec:	11000673 	add	w19, w19, #0x1
    8bf0:	71004a7f 	cmp	w19, #0x12
    8bf4:	54003860 	b.eq	9300 <fwp_write+0xd80>  // b.none
    8bf8:	1e604100 	fmov	d0, d8
    8bfc:	2a1303e1 	mov	w1, w19
    8c00:	aa1503e0 	mov	x0, x21
    8c04:	97ffebe4 	bl	3b94 <fwp_format_g.constprop.0>
    8c08:	aa1503e0 	mov	x0, x21
    8c0c:	d2800001 	mov	x1, #0x0                   	// #0
    8c10:	97ffe6d4 	bl	2760 <strtod@plt>
    8c14:	1e602100 	fcmp	d8, d0
    8c18:	54fffea1 	b.ne	8bec <fwp_write+0x66c>  // b.any
    8c1c:	aa1503e0 	mov	x0, x21
    8c20:	97ffead5 	bl	3774 <fwp_finish_float>
    8c24:	17ffffc1 	b	8b28 <fwp_write+0x5a8>
    8c28:	a9400e62 	ldp	x2, x3, [x19]
    8c2c:	910123f3 	add	x19, sp, #0x48
    8c30:	aa1303e0 	mov	x0, x19
    8c34:	97ffe87b 	bl	2e20 <fwp_fmt_u128>
    8c38:	17fffe74 	b	8608 <fwp_write+0x88>
    8c3c:	f90143f7 	str	x23, [sp, #640]
    8c40:	f90147f8 	str	x24, [sp, #648]
    8c44:	2a1303f8 	mov	w24, w19
    8c48:	f9014bf9 	str	x25, [sp, #656]
    8c4c:	f9014ffa 	str	x26, [sp, #664]
    8c50:	f13ffe7f 	cmp	x19, #0xfff
    8c54:	54000049 	b.ls	8c5c <fwp_write+0x6dc>  // b.plast
    8c58:	b9400278 	ldr	w24, [x19]
    8c5c:	f9400f80 	ldr	x0, [x28, #24]
    8c60:	2a1803f5 	mov	w21, w24
    8c64:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8c68:	d37ef6b9 	lsl	x25, x21, #2
    8c6c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8c70:	aa1603e0 	mov	x0, x22
    8c74:	97ffe6a7 	bl	2710 <strlen@plt>
    8c78:	aa1603e1 	mov	x1, x22
    8c7c:	aa0003e2 	mov	x2, x0
    8c80:	aa1403e0 	mov	x0, x20
    8c84:	97ffea43 	bl	3590 <buf_put>
    8c88:	f9401780 	ldr	x0, [x28, #40]
    8c8c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8c90:	7100001f 	cmp	w0, #0x0
    8c94:	5400068d 	b.le	8d64 <fwp_write+0x7e4>
    8c98:	91002276 	add	x22, x19, #0x8
    8c9c:	91001ff5 	add	x21, sp, #0x7
    8ca0:	d280001b 	mov	x27, #0x0                   	// #0
    8ca4:	5280041a 	mov	w26, #0x20                  	// #32
    8ca8:	f9401b80 	ldr	x0, [x28, #48]
    8cac:	aa1503e1 	mov	x1, x21
    8cb0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8cb4:	d2800022 	mov	x2, #0x1                   	// #1
    8cb8:	f8786803 	ldr	x3, [x0, x24]
    8cbc:	aa1403e0 	mov	x0, x20
    8cc0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8cc4:	39001ffa 	strb	w26, [sp, #7]
    8cc8:	97ffea32 	bl	3590 <buf_put>
    8ccc:	f13ffeff 	cmp	x23, #0xfff
    8cd0:	b9400261 	ldr	w1, [x19]
    8cd4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8cd8:	7100383f 	cmp	w1, #0xe
    8cdc:	54000160 	b.eq	8d08 <fwp_write+0x788>  // b.none
    8ce0:	7100403f 	cmp	w1, #0x10
    8ce4:	54001a60 	b.eq	9030 <fwp_write+0xab0>  // b.none
    8ce8:	7100283f 	cmp	w1, #0xa
    8cec:	54002aa0 	b.eq	9240 <fwp_write+0xcc0>  // b.none
    8cf0:	540014ac 	b.gt	8f84 <fwp_write+0xa04>
    8cf4:	71000c3f 	cmp	w1, #0x3
    8cf8:	540029ac 	b.gt	922c <fwp_write+0xcac>
    8cfc:	d37ffee0 	lsr	x0, x23, #63
    8d00:	37f814a1 	tbnz	w1, #31, 8f94 <fwp_write+0xa14>
    8d04:	d503201f 	nop
    8d08:	34001460 	cbz	w0, 8f94 <fwp_write+0xa14>
    8d0c:	52800503 	mov	w3, #0x28                  	// #40
    8d10:	aa1503e1 	mov	x1, x21
    8d14:	aa1403e0 	mov	x0, x20
    8d18:	d2800022 	mov	x2, #0x1                   	// #1
    8d1c:	39001fe3 	strb	w3, [sp, #7]
    8d20:	97ffea1c 	bl	3590 <buf_put>
    8d24:	aa1303e2 	mov	x2, x19
    8d28:	aa1703e1 	mov	x1, x23
    8d2c:	aa1403e0 	mov	x0, x20
    8d30:	52800003 	mov	w3, #0x0                   	// #0
    8d34:	97fffe13 	bl	8580 <fwp_write>
    8d38:	52800523 	mov	w3, #0x29                  	// #41
    8d3c:	aa1503e1 	mov	x1, x21
    8d40:	aa1403e0 	mov	x0, x20
    8d44:	d2800022 	mov	x2, #0x1                   	// #1
    8d48:	39001fe3 	strb	w3, [sp, #7]
    8d4c:	97ffea11 	bl	3590 <buf_put>
    8d50:	f9401780 	ldr	x0, [x28, #40]
    8d54:	9100077b 	add	x27, x27, #0x1
    8d58:	b8796800 	ldr	w0, [x0, x25]
    8d5c:	6b1b001f 	cmp	w0, w27
    8d60:	54fffa4c 	b.gt	8ca8 <fwp_write+0x728>
    8d64:	f9413bf5 	ldr	x21, [sp, #624]
    8d68:	f9413ff6 	ldr	x22, [sp, #632]
    8d6c:	f94143f7 	ldr	x23, [sp, #640]
    8d70:	f94147f8 	ldr	x24, [sp, #648]
    8d74:	f9414bf9 	ldr	x25, [sp, #656]
    8d78:	f9414ffa 	ldr	x26, [sp, #664]
    8d7c:	f94153fb 	ldr	x27, [sp, #672]
    8d80:	f94157fc 	ldr	x28, [sp, #680]
    8d84:	17fffe2b 	b	8630 <fwp_write+0xb0>
    8d88:	52800783 	mov	w3, #0x3c                  	// #60
    8d8c:	91001ff3 	add	x19, sp, #0x7
    8d90:	aa1303e1 	mov	x1, x19
    8d94:	d2800022 	mov	x2, #0x1                   	// #1
    8d98:	aa1403e0 	mov	x0, x20
    8d9c:	39001fe3 	strb	w3, [sp, #7]
    8da0:	97ffe9fc 	bl	3590 <buf_put>
    8da4:	f9400795 	ldr	x21, [x28, #8]
    8da8:	aa1503e0 	mov	x0, x21
    8dac:	97ffe659 	bl	2710 <strlen@plt>
    8db0:	aa1503e1 	mov	x1, x21
    8db4:	aa0003e2 	mov	x2, x0
    8db8:	aa1403e0 	mov	x0, x20
    8dbc:	97ffe9f5 	bl	3590 <buf_put>
    8dc0:	528007c3 	mov	w3, #0x3e                  	// #62
    8dc4:	aa1303e1 	mov	x1, x19
    8dc8:	aa1403e0 	mov	x0, x20
    8dcc:	d2800022 	mov	x2, #0x1                   	// #1
    8dd0:	39001fe3 	strb	w3, [sp, #7]
    8dd4:	17fffe12 	b	861c <fwp_write+0x9c>
    8dd8:	f100067f 	cmp	x19, #0x1
    8ddc:	540025a0 	b.eq	9290 <fwp_write+0xd10>  // b.none
    8de0:	b100067f 	cmn	x19, #0x1
    8de4:	54002bc0 	b.eq	935c <fwp_write+0xddc>  // b.none
    8de8:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8dec:	91270021 	add	x1, x1, #0x9c0
    8df0:	d2800022 	mov	x2, #0x1                   	// #1
    8df4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8df8:	f947f400 	ldr	x0, [x0, #4072]
    8dfc:	f94127e4 	ldr	x4, [sp, #584]
    8e00:	f9400003 	ldr	x3, [x0]
    8e04:	eb030084 	subs	x4, x4, x3
    8e08:	d2800003 	mov	x3, #0x0                   	// #0
    8e0c:	54ffebe0 	b.eq	8b88 <fwp_write+0x608>  // b.none
    8e10:	f90143f7 	str	x23, [sp, #640]
    8e14:	f90147f8 	str	x24, [sp, #648]
    8e18:	f9014bf9 	str	x25, [sp, #656]
    8e1c:	f9014ffa 	str	x26, [sp, #664]
    8e20:	fd015be8 	str	d8, [sp, #688]
    8e24:	fd015fe9 	str	d9, [sp, #696]
    8e28:	97ffe696 	bl	2880 <__stack_chk_fail@plt>
    8e2c:	52800b63 	mov	w3, #0x5b                  	// #91
    8e30:	91001ff5 	add	x21, sp, #0x7
    8e34:	aa1503e1 	mov	x1, x21
    8e38:	aa1403e0 	mov	x0, x20
    8e3c:	d2800022 	mov	x2, #0x1                   	// #1
    8e40:	b0000036 	adrp	x22, d000 <__divti3+0x2d0>
    8e44:	912982d6 	add	x22, x22, #0xa60
    8e48:	39001fe3 	strb	w3, [sp, #7]
    8e4c:	97ffe9d1 	bl	3590 <buf_put>
    8e50:	b4000273 	cbz	x19, 8e9c <fwp_write+0x91c>
    8e54:	f9400661 	ldr	x1, [x19, #8]
    8e58:	aa1403e0 	mov	x0, x20
    8e5c:	f9401f82 	ldr	x2, [x28, #56]
    8e60:	52800003 	mov	w3, #0x0                   	// #0
    8e64:	97fffdc7 	bl	8580 <fwp_write>
    8e68:	f9400a73 	ldr	x19, [x19, #16]
    8e6c:	b4000193 	cbz	x19, 8e9c <fwp_write+0x91c>
    8e70:	aa1603e1 	mov	x1, x22
    8e74:	aa1403e0 	mov	x0, x20
    8e78:	d2800042 	mov	x2, #0x2                   	// #2
    8e7c:	97ffe9c5 	bl	3590 <buf_put>
    8e80:	f9400661 	ldr	x1, [x19, #8]
    8e84:	aa1403e0 	mov	x0, x20
    8e88:	f9401f82 	ldr	x2, [x28, #56]
    8e8c:	52800003 	mov	w3, #0x0                   	// #0
    8e90:	97fffdbc 	bl	8580 <fwp_write>
    8e94:	f9400a73 	ldr	x19, [x19, #16]
    8e98:	b5fffed3 	cbnz	x19, 8e70 <fwp_write+0x8f0>
    8e9c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8ea0:	aa1503e1 	mov	x1, x21
    8ea4:	aa1403e0 	mov	x0, x20
    8ea8:	d2800022 	mov	x2, #0x1                   	// #1
    8eac:	39001fe3 	strb	w3, [sp, #7]
    8eb0:	17fffddb 	b	861c <fwp_write+0x9c>
    8eb4:	aa1403e0 	mov	x0, x20
    8eb8:	b0000021 	adrp	x1, d000 <__divti3+0x2d0>
    8ebc:	d28000c2 	mov	x2, #0x6                   	// #6
    8ec0:	91294021 	add	x1, x1, #0xa50
    8ec4:	97ffe9b3 	bl	3590 <buf_put>
    8ec8:	f9400260 	ldr	x0, [x19]
    8ecc:	b40004c0 	cbz	x0, 8f64 <fwp_write+0x9e4>
    8ed0:	910123f5 	add	x21, sp, #0x48
    8ed4:	91002276 	add	x22, x19, #0x8
    8ed8:	f90143f7 	str	x23, [sp, #640]
    8edc:	d2800017 	mov	x23, #0x0                   	// #0
    8ee0:	f90147f8 	str	x24, [sp, #648]
    8ee4:	b0000038 	adrp	x24, d000 <__divti3+0x2d0>
    8ee8:	91296318 	add	x24, x24, #0xa58
    8eec:	f9014bf9 	str	x25, [sp, #656]
    8ef0:	b0000039 	adrp	x25, d000 <__divti3+0x2d0>
    8ef4:	91298339 	add	x25, x25, #0xa60
    8ef8:	f9014ffa 	str	x26, [sp, #664]
    8efc:	14000005 	b	8f10 <fwp_write+0x990>
    8f00:	aa1903e1 	mov	x1, x25
    8f04:	aa1403e0 	mov	x0, x20
    8f08:	d2800042 	mov	x2, #0x2                   	// #2
    8f0c:	97ffe9a1 	bl	3590 <buf_put>
    8f10:	38776ac5 	ldrb	w5, [x22, x23]
    8f14:	d2804003 	mov	x3, #0x200                 	// #512
    8f18:	aa1803e4 	mov	x4, x24
    8f1c:	aa0303e1 	mov	x1, x3
    8f20:	52800042 	mov	w2, #0x2                   	// #2
    8f24:	aa1503e0 	mov	x0, x21
    8f28:	910006f7 	add	x23, x23, #0x1
    8f2c:	97ffe631 	bl	27f0 <__snprintf_chk@plt>
    8f30:	aa1503e0 	mov	x0, x21
    8f34:	97ffe5f7 	bl	2710 <strlen@plt>
    8f38:	aa1503e1 	mov	x1, x21
    8f3c:	aa0003e2 	mov	x2, x0
    8f40:	aa1403e0 	mov	x0, x20
    8f44:	97ffe993 	bl	3590 <buf_put>
    8f48:	f9400260 	ldr	x0, [x19]
    8f4c:	eb17001f 	cmp	x0, x23
    8f50:	54fffd88 	b.hi	8f00 <fwp_write+0x980>  // b.pmore
    8f54:	f94143f7 	ldr	x23, [sp, #640]
    8f58:	f94147f8 	ldr	x24, [sp, #648]
    8f5c:	f9414bf9 	ldr	x25, [sp, #656]
    8f60:	f9414ffa 	ldr	x26, [sp, #664]
    8f64:	52800ba3 	mov	w3, #0x5d                  	// #93
    8f68:	aa1403e0 	mov	x0, x20
    8f6c:	91001fe1 	add	x1, sp, #0x7
    8f70:	d2800022 	mov	x2, #0x1                   	// #1
    8f74:	39001fe3 	strb	w3, [sp, #7]
    8f78:	17fffda9 	b	861c <fwp_write+0x9c>
    8f7c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8f80:	17fffe44 	b	8890 <fwp_write+0x310>
    8f84:	f10002ff 	cmp	x23, #0x0
    8f88:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8f8c:	71002c3f 	cmp	w1, #0xb
    8f90:	54ffebc0 	b.eq	8d08 <fwp_write+0x788>  // b.none
    8f94:	aa1303e2 	mov	x2, x19
    8f98:	aa1703e1 	mov	x1, x23
    8f9c:	aa1403e0 	mov	x0, x20
    8fa0:	52800003 	mov	w3, #0x0                   	// #0
    8fa4:	97fffd77 	bl	8580 <fwp_write>
    8fa8:	17ffff6a 	b	8d50 <fwp_write+0x7d0>
    8fac:	aa1403e0 	mov	x0, x20
    8fb0:	91001fe1 	add	x1, sp, #0x7
    8fb4:	52800fa3 	mov	w3, #0x7d                  	// #125
    8fb8:	d2800022 	mov	x2, #0x1                   	// #1
    8fbc:	17fffe38 	b	889c <fwp_write+0x31c>
    8fc0:	a9400281 	ldp	x1, x0, [x20]
    8fc4:	91000800 	add	x0, x0, #0x2
    8fc8:	8b160000 	add	x0, x0, x22
    8fcc:	f9000680 	str	x0, [x20, #8]
    8fd0:	3820683f 	strb	wzr, [x1, x0]
    8fd4:	f9413bf5 	ldr	x21, [sp, #624]
    8fd8:	f9413ff6 	ldr	x22, [sp, #632]
    8fdc:	f94153fb 	ldr	x27, [sp, #672]
    8fe0:	f94157fc 	ldr	x28, [sp, #680]
    8fe4:	17fffd93 	b	8630 <fwp_write+0xb0>
    8fe8:	f9400f80 	ldr	x0, [x28, #24]
    8fec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8ff0:	aa1b03e0 	mov	x0, x27
    8ff4:	97ffe5c7 	bl	2710 <strlen@plt>
    8ff8:	aa1b03e1 	mov	x1, x27
    8ffc:	aa0003e2 	mov	x2, x0
    9000:	aa1403e0 	mov	x0, x20
    9004:	97ffe963 	bl	3590 <buf_put>
    9008:	aa1903e1 	mov	x1, x25
    900c:	aa1403e0 	mov	x0, x20
    9010:	d2800062 	mov	x2, #0x3                   	// #3
    9014:	97ffe95f 	bl	3590 <buf_put>
    9018:	17fffe10 	b	8858 <fwp_write+0x2d8>
    901c:	aa1a03e1 	mov	x1, x26
    9020:	aa1403e0 	mov	x0, x20
    9024:	d2800042 	mov	x2, #0x2                   	// #2
    9028:	97ffe95a 	bl	3590 <buf_put>
    902c:	17fffe09 	b	8850 <fwp_write+0x2d0>
    9030:	f9400660 	ldr	x0, [x19, #8]
    9034:	b4fffb00 	cbz	x0, 8f94 <fwp_write+0xa14>
    9038:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    903c:	9129e021 	add	x1, x1, #0xa78
    9040:	97ffe630 	bl	2900 <strcmp@plt>
    9044:	7100001f 	cmp	w0, #0x0
    9048:	1a9f07e0 	cset	w0, ne	// ne = any
    904c:	17ffff2f 	b	8d08 <fwp_write+0x788>
    9050:	aa1403e0 	mov	x0, x20
    9054:	d2800042 	mov	x2, #0x2                   	// #2
    9058:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    905c:	9129c021 	add	x1, x1, #0xa70
    9060:	97ffe94c 	bl	3590 <buf_put>
    9064:	91004261 	add	x1, x19, #0x10
    9068:	aa1403e0 	mov	x0, x20
    906c:	f9402382 	ldr	x2, [x28, #64]
    9070:	52800003 	mov	w3, #0x0                   	// #0
    9074:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9078:	97fffd42 	bl	8580 <fwp_write>
    907c:	17fffd9c 	b	86ec <fwp_write+0x16c>
    9080:	1e22c109 	fcvt	d9, s8
    9084:	910123f5 	add	x21, sp, #0x48
    9088:	52800033 	mov	w19, #0x1                   	// #1
    908c:	d503201f 	nop
    9090:	1e604120 	fmov	d0, d9
    9094:	2a1303e1 	mov	w1, w19
    9098:	aa1503e0 	mov	x0, x21
    909c:	97ffeabe 	bl	3b94 <fwp_format_g.constprop.0>
    90a0:	aa1503e0 	mov	x0, x21
    90a4:	d2800001 	mov	x1, #0x0                   	// #0
    90a8:	97ffe622 	bl	2930 <strtof@plt>
    90ac:	1e202100 	fcmp	s8, s0
    90b0:	54ffdb60 	b.eq	8c1c <fwp_write+0x69c>  // b.none
    90b4:	11000673 	add	w19, w19, #0x1
    90b8:	71002a7f 	cmp	w19, #0xa
    90bc:	54fffea1 	b.ne	9090 <fwp_write+0xb10>  // b.any
    90c0:	1e604120 	fmov	d0, d9
    90c4:	aa1503e0 	mov	x0, x21
    90c8:	52800121 	mov	w1, #0x9                   	// #9
    90cc:	97ffeab2 	bl	3b94 <fwp_format_g.constprop.0>
    90d0:	17fffed3 	b	8c1c <fwp_write+0x69c>
    90d4:	d37ef6a1 	lsl	x1, x21, #2
    90d8:	b7f81563 	tbnz	x3, #63, 9384 <fwp_write+0xe04>
    90dc:	91002263 	add	x3, x19, #0x8
    90e0:	8b010061 	add	x1, x3, x1
    90e4:	b9400023 	ldr	w3, [x1]
    90e8:	7100081f 	cmp	w0, #0x2
    90ec:	2a0303e1 	mov	w1, w3
    90f0:	93407c63 	sxtw	x3, w3
    90f4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    90f8:	17fffe5a 	b	8a60 <fwp_write+0x4e0>
    90fc:	d37ffaa1 	lsl	x1, x21, #1
    9100:	b7f81363 	tbnz	x3, #63, 936c <fwp_write+0xdec>
    9104:	91002263 	add	x3, x19, #0x8
    9108:	8b010061 	add	x1, x3, x1
    910c:	79400021 	ldrh	w1, [x1]
    9110:	7100041f 	cmp	w0, #0x1
    9114:	93403c23 	sxth	x3, w1
    9118:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    911c:	17fffe51 	b	8a60 <fwp_write+0x4e0>
    9120:	52800443 	mov	w3, #0x22                  	// #34
    9124:	91001ff5 	add	x21, sp, #0x7
    9128:	91002273 	add	x19, x19, #0x8
    912c:	aa1503e1 	mov	x1, x21
    9130:	aa1403e0 	mov	x0, x20
    9134:	d2800022 	mov	x2, #0x1                   	// #1
    9138:	39001fe3 	strb	w3, [sp, #7]
    913c:	f90143f7 	str	x23, [sp, #640]
    9140:	8b160277 	add	x23, x19, x22
    9144:	f90147f8 	str	x24, [sp, #648]
    9148:	97ffe912 	bl	3590 <buf_put>
    914c:	b4000696 	cbz	x22, 921c <fwp_write+0xc9c>
    9150:	90000038 	adrp	x24, d000 <__divti3+0x2d0>
    9154:	91288318 	add	x24, x24, #0xa20
    9158:	f9014bf9 	str	x25, [sp, #656]
    915c:	90000039 	adrp	x25, d000 <__divti3+0x2d0>
    9160:	91290339 	add	x25, x25, #0xa40
    9164:	f9014ffa 	str	x26, [sp, #664]
    9168:	1400000d 	b	919c <fwp_write+0xc1c>
    916c:	710024bf 	cmp	w5, #0x9
    9170:	54000460 	b.eq	91fc <fwp_write+0xc7c>  // b.none
    9174:	710028bf 	cmp	w5, #0xa
    9178:	54000a61 	b.ne	92c4 <fwp_write+0xd44>  // b.any
    917c:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    9180:	aa1403e0 	mov	x0, x20
    9184:	9128c021 	add	x1, x1, #0xa30
    9188:	d2800042 	mov	x2, #0x2                   	// #2
    918c:	97ffe901 	bl	3590 <buf_put>
    9190:	91000673 	add	x19, x19, #0x1
    9194:	eb17027f 	cmp	x19, x23
    9198:	540003e0 	b.eq	9214 <fwp_write+0xc94>  // b.none
    919c:	39400265 	ldrb	w5, [x19]
    91a0:	710034bf 	cmp	w5, #0xd
    91a4:	54000180 	b.eq	91d4 <fwp_write+0xc54>  // b.none
    91a8:	54fffe29 	b.ls	916c <fwp_write+0xbec>  // b.plast
    91ac:	710088bf 	cmp	w5, #0x22
    91b0:	540001c0 	b.eq	91e8 <fwp_write+0xc68>  // b.none
    91b4:	710170bf 	cmp	w5, #0x5c
    91b8:	54000741 	b.ne	92a0 <fwp_write+0xd20>  // b.any
    91bc:	aa1403e0 	mov	x0, x20
    91c0:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    91c4:	d2800042 	mov	x2, #0x2                   	// #2
    91c8:	9128a021 	add	x1, x1, #0xa28
    91cc:	97ffe8f1 	bl	3590 <buf_put>
    91d0:	17fffff0 	b	9190 <fwp_write+0xc10>
    91d4:	aa1903e1 	mov	x1, x25
    91d8:	aa1403e0 	mov	x0, x20
    91dc:	d2800042 	mov	x2, #0x2                   	// #2
    91e0:	97ffe8ec 	bl	3590 <buf_put>
    91e4:	17ffffeb 	b	9190 <fwp_write+0xc10>
    91e8:	aa1803e1 	mov	x1, x24
    91ec:	aa1403e0 	mov	x0, x20
    91f0:	d2800042 	mov	x2, #0x2                   	// #2
    91f4:	97ffe8e7 	bl	3590 <buf_put>
    91f8:	17ffffe6 	b	9190 <fwp_write+0xc10>
    91fc:	aa1403e0 	mov	x0, x20
    9200:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    9204:	d2800042 	mov	x2, #0x2                   	// #2
    9208:	9128e021 	add	x1, x1, #0xa38
    920c:	97ffe8e1 	bl	3590 <buf_put>
    9210:	17ffffe0 	b	9190 <fwp_write+0xc10>
    9214:	f9414bf9 	ldr	x25, [sp, #656]
    9218:	f9414ffa 	ldr	x26, [sp, #664]
    921c:	aa1503e1 	mov	x1, x21
    9220:	aa1403e0 	mov	x0, x20
    9224:	52800443 	mov	w3, #0x22                  	// #34
    9228:	17fffd9c 	b	8898 <fwp_write+0x318>
    922c:	7100103f 	cmp	w1, #0x4
    9230:	54ffeb21 	b.ne	8f94 <fwp_write+0xa14>  // b.any
    9234:	f94006e0 	ldr	x0, [x23, #8]
    9238:	d37ffc00 	lsr	x0, x0, #63
    923c:	17fffeb3 	b	8d08 <fwp_write+0x788>
    9240:	710002ff 	cmp	w23, #0x0
    9244:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9248:	17fffeb0 	b	8d08 <fwp_write+0x788>
    924c:	528005a1 	mov	w1, #0x2d                  	// #45
    9250:	eb0203e2 	negs	x2, x2
    9254:	da0303e3 	ngc	x3, x3
    9258:	910127e0 	add	x0, sp, #0x49
    925c:	910123f5 	add	x21, sp, #0x48
    9260:	390123e1 	strb	w1, [sp, #72]
    9264:	97ffe6ef 	bl	2e20 <fwp_fmt_u128>
    9268:	17fffe18 	b	8ac8 <fwp_write+0x548>
    926c:	d37ceea1 	lsl	x1, x21, #4
    9270:	b7f810a3 	tbnz	x3, #63, 9484 <fwp_write+0xf04>
    9274:	91002260 	add	x0, x19, #0x8
    9278:	8b010001 	add	x1, x0, x1
    927c:	17fffdf9 	b	8a60 <fwp_write+0x4e0>
    9280:	f9400a61 	ldr	x1, [x19, #16]
    9284:	8b010000 	add	x0, x0, x1
    9288:	f9400001 	ldr	x1, [x0]
    928c:	17fffdf5 	b	8a60 <fwp_write+0x4e0>
    9290:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    9294:	d2800042 	mov	x2, #0x2                   	// #2
    9298:	91272021 	add	x1, x1, #0x9c8
    929c:	17fffed6 	b	8df4 <fwp_write+0x874>
    92a0:	7101fcbf 	cmp	w5, #0x7f
    92a4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    92a8:	540000e9 	b.ls	92c4 <fwp_write+0xd44>  // b.plast
    92ac:	aa1503e1 	mov	x1, x21
    92b0:	aa1403e0 	mov	x0, x20
    92b4:	d2800022 	mov	x2, #0x1                   	// #1
    92b8:	39001fe5 	strb	w5, [sp, #7]
    92bc:	97ffe8b5 	bl	3590 <buf_put>
    92c0:	17ffffb4 	b	9190 <fwp_write+0xc10>
    92c4:	d2800203 	mov	x3, #0x10                  	// #16
    92c8:	90000024 	adrp	x4, d000 <__divti3+0x2d0>
    92cc:	aa0303e1 	mov	x1, x3
    92d0:	91292084 	add	x4, x4, #0xa48
    92d4:	910123f6 	add	x22, sp, #0x48
    92d8:	52800042 	mov	w2, #0x2                   	// #2
    92dc:	aa1603e0 	mov	x0, x22
    92e0:	97ffe544 	bl	27f0 <__snprintf_chk@plt>
    92e4:	aa1603e0 	mov	x0, x22
    92e8:	97ffe50a 	bl	2710 <strlen@plt>
    92ec:	aa1603e1 	mov	x1, x22
    92f0:	aa0003e2 	mov	x2, x0
    92f4:	aa1403e0 	mov	x0, x20
    92f8:	97ffe8a6 	bl	3590 <buf_put>
    92fc:	17ffffa5 	b	9190 <fwp_write+0xc10>
    9300:	1e604100 	fmov	d0, d8
    9304:	aa1503e0 	mov	x0, x21
    9308:	52800221 	mov	w1, #0x11                  	// #17
    930c:	97ffea22 	bl	3b94 <fwp_format_g.constprop.0>
    9310:	17fffe43 	b	8c1c <fwp_write+0x69c>
    9314:	b9401040 	ldr	w0, [x2, #16]
    9318:	350003c0 	cbnz	w0, 9390 <fwp_write+0xe10>
    931c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9320:	f947f400 	ldr	x0, [x0, #4072]
    9324:	f94127e2 	ldr	x2, [sp, #584]
    9328:	f9400001 	ldr	x1, [x0]
    932c:	eb010042 	subs	x2, x2, x1
    9330:	d2800001 	mov	x1, #0x0                   	// #0
    9334:	54ffd721 	b.ne	8e18 <fwp_write+0x898>  // b.any
    9338:	f9413bf5 	ldr	x21, [sp, #624]
    933c:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    9340:	f9413ff6 	ldr	x22, [sp, #632]
    9344:	aa1403e0 	mov	x0, x20
    9348:	f94143f7 	ldr	x23, [sp, #640]
    934c:	912a6021 	add	x1, x1, #0xa98
    9350:	f94147f8 	ldr	x24, [sp, #648]
    9354:	d2800042 	mov	x2, #0x2                   	// #2
    9358:	17fffd0e 	b	8790 <fwp_write+0x210>
    935c:	90000021 	adrp	x1, d000 <__divti3+0x2d0>
    9360:	d2800042 	mov	x2, #0x2                   	// #2
    9364:	91274021 	add	x1, x1, #0x9d0
    9368:	17fffea3 	b	8df4 <fwp_write+0x874>
    936c:	f9400a63 	ldr	x3, [x19, #16]
    9370:	8b030021 	add	x1, x1, x3
    9374:	17ffff66 	b	910c <fwp_write+0xb8c>
    9378:	f9400a61 	ldr	x1, [x19, #16]
    937c:	8b0102a1 	add	x1, x21, x1
    9380:	17fffdb3 	b	8a4c <fwp_write+0x4cc>
    9384:	f9400a63 	ldr	x3, [x19, #16]
    9388:	8b030021 	add	x1, x1, x3
    938c:	17ffff56 	b	90e4 <fwp_write+0xb64>
    9390:	b9404840 	ldr	w0, [x2, #72]
    9394:	91001ff5 	add	x21, sp, #0x7
    9398:	34ffa360 	cbz	w0, 8804 <fwp_write+0x284>
    939c:	52800503 	mov	w3, #0x28                  	// #40
    93a0:	aa1403e0 	mov	x0, x20
    93a4:	aa1503e1 	mov	x1, x21
    93a8:	d2800022 	mov	x2, #0x1                   	// #1
    93ac:	39001fe3 	strb	w3, [sp, #7]
    93b0:	97ffe878 	bl	3590 <buf_put>
    93b4:	b9401380 	ldr	w0, [x28, #16]
    93b8:	52800038 	mov	w24, #0x1                   	// #1
    93bc:	7100001f 	cmp	w0, #0x0
    93c0:	54ffa36c 	b.gt	882c <fwp_write+0x2ac>
    93c4:	17fffd32 	b	888c <fwp_write+0x30c>
    93c8:	f9014bf9 	str	x25, [sp, #656]
    93cc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe8d0>
    93d0:	f9014ffa 	str	x26, [sp, #664]
    93d4:	f9400676 	ldr	x22, [x19, #8]
    93d8:	91102333 	add	x19, x25, #0x408
    93dc:	91002273 	add	x19, x19, #0x8
    93e0:	937ffed8 	asr	x24, x22, #63
    93e4:	aa1802c0 	orr	x0, x22, x24
    93e8:	b5000320 	cbnz	x0, 944c <fwp_write+0xecc>
    93ec:	110006b5 	add	w21, w21, #0x1
    93f0:	710016bf 	cmp	w21, #0x5
    93f4:	54ffffc1 	b.ne	93ec <fwp_write+0xe6c>  // b.any
    93f8:	b7f80578 	tbnz	x24, #63, 94a4 <fwp_write+0xf24>
    93fc:	910023f3 	add	x19, sp, #0x8
    9400:	aa1603e2 	mov	x2, x22
    9404:	aa1303e0 	mov	x0, x19
    9408:	d2800003 	mov	x3, #0x0                   	// #0
    940c:	97ffe685 	bl	2e20 <fwp_fmt_u128>
    9410:	910123f5 	add	x21, sp, #0x48
    9414:	90000023 	adrp	x3, d000 <__divti3+0x2d0>
    9418:	aa1303e4 	mov	x4, x19
    941c:	aa1503e0 	mov	x0, x21
    9420:	912a4063 	add	x3, x3, #0xa90
    9424:	d2804002 	mov	x2, #0x200                 	// #512
    9428:	52800041 	mov	w1, #0x2                   	// #2
    942c:	97ffe4bd 	bl	2720 <__sprintf_chk@plt>
    9430:	aa1503e0 	mov	x0, x21
    9434:	97ffe4b7 	bl	2710 <strlen@plt>
    9438:	aa1503e1 	mov	x1, x21
    943c:	aa0003e2 	mov	x2, x0
    9440:	aa1403e0 	mov	x0, x20
    9444:	97ffe853 	bl	3590 <buf_put>
    9448:	17fffe47 	b	8d64 <fwp_write+0x7e4>
    944c:	f9400277 	ldr	x23, [x19]
    9450:	aa1603e0 	mov	x0, x22
    9454:	aa1803e1 	mov	x1, x24
    9458:	aa1703e2 	mov	x2, x23
    945c:	937ffefa 	asr	x26, x23, #63
    9460:	aa1a03e3 	mov	x3, x26
    9464:	94000f13 	bl	d0b0 <__modti3>
    9468:	aa010000 	orr	x0, x0, x1
    946c:	b40002c0 	cbz	x0, 94c4 <fwp_write+0xf44>
    9470:	110006b5 	add	w21, w21, #0x1
    9474:	91004273 	add	x19, x19, #0x10
    9478:	710016bf 	cmp	w21, #0x5
    947c:	54fffe81 	b.ne	944c <fwp_write+0xecc>  // b.any
    9480:	17ffffde 	b	93f8 <fwp_write+0xe78>
    9484:	f9400a60 	ldr	x0, [x19, #16]
    9488:	8b000021 	add	x1, x1, x0
    948c:	17fffd75 	b	8a60 <fwp_write+0x4e0>
    9490:	528c29c0 	mov	w0, #0x614e                	// #24910
    9494:	910123f5 	add	x21, sp, #0x48
    9498:	72a009c0 	movk	w0, #0x4e, lsl #16
    949c:	b9004be0 	str	w0, [sp, #72]
    94a0:	17fffda2 	b	8b28 <fwp_write+0x5a8>
    94a4:	528005a1 	mov	w1, #0x2d                  	// #45
    94a8:	eb1603e2 	negs	x2, x22
    94ac:	da1803e3 	ngc	x3, x24
    94b0:	910027e0 	add	x0, sp, #0x9
    94b4:	910023f3 	add	x19, sp, #0x8
    94b8:	390023e1 	strb	w1, [sp, #8]
    94bc:	97ffe659 	bl	2e20 <fwp_fmt_u128>
    94c0:	17ffffd4 	b	9410 <fwp_write+0xe90>
    94c4:	aa1703e2 	mov	x2, x23
    94c8:	aa1a03e3 	mov	x3, x26
    94cc:	aa1603e0 	mov	x0, x22
    94d0:	aa1803e1 	mov	x1, x24
    94d4:	94000e17 	bl	cd30 <__divti3>
    94d8:	aa0003e2 	mov	x2, x0
    94dc:	aa0103e3 	mov	x3, x1
    94e0:	b7f80201 	tbnz	x1, #63, 9520 <fwp_write+0xfa0>
    94e4:	910023f3 	add	x19, sp, #0x8
    94e8:	aa1303e0 	mov	x0, x19
    94ec:	97ffe64d 	bl	2e20 <fwp_fmt_u128>
    94f0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    94f4:	91102339 	add	x25, x25, #0x408
    94f8:	910123f5 	add	x21, sp, #0x48
    94fc:	aa1303e4 	mov	x4, x19
    9500:	aa1503e0 	mov	x0, x21
    9504:	90000023 	adrp	x3, d000 <__divti3+0x2d0>
    9508:	f8616b25 	ldr	x5, [x25, x1]
    950c:	912a2063 	add	x3, x3, #0xa88
    9510:	d2804002 	mov	x2, #0x200                 	// #512
    9514:	52800041 	mov	w1, #0x2                   	// #2
    9518:	97ffe482 	bl	2720 <__sprintf_chk@plt>
    951c:	17ffffc5 	b	9430 <fwp_write+0xeb0>
    9520:	528005a4 	mov	w4, #0x2d                  	// #45
    9524:	eb0003e2 	negs	x2, x0
    9528:	da0103e3 	ngc	x3, x1
    952c:	910027e0 	add	x0, sp, #0x9
    9530:	910023f3 	add	x19, sp, #0x8
    9534:	390023e4 	strb	w4, [sp, #8]
    9538:	97ffe63a 	bl	2e20 <fwp_fmt_u128>
    953c:	17ffffed 	b	94f0 <fwp_write+0xf70>
    9540:	f9013bf5 	str	x21, [sp, #624]
    9544:	f9013ff6 	str	x22, [sp, #632]
    9548:	f90143f7 	str	x23, [sp, #640]
    954c:	f90147f8 	str	x24, [sp, #648]
    9550:	f9014bf9 	str	x25, [sp, #656]
    9554:	f9014ffa 	str	x26, [sp, #664]
    9558:	f90153fb 	str	x27, [sp, #672]
    955c:	f90157fc 	str	x28, [sp, #680]
    9560:	fd015be8 	str	d8, [sp, #688]
    9564:	fd015fe9 	str	d9, [sp, #696]
    9568:	97ffe4c6 	bl	2880 <__stack_chk_fail@plt>
    956c:	d503201f 	nop

0000000000009570 <fwp_hof0.constprop.0>:
    9570:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9574:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9578:	f947f442 	ldr	x2, [x2, #4072]
    957c:	910003fd 	mov	x29, sp
    9580:	a90153f3 	stp	x19, x20, [sp, #16]
    9584:	a9025bf5 	stp	x21, x22, [sp, #32]
    9588:	a90363f7 	stp	x23, x24, [sp, #48]
    958c:	aa0003f7 	mov	x23, x0
    9590:	a9046bf9 	stp	x25, x26, [sp, #64]
    9594:	a90573fb 	stp	x27, x28, [sp, #80]
    9598:	d10243ff 	sub	sp, sp, #0x90
    959c:	f9400040 	ldr	x0, [x2]
    95a0:	f81f83a0 	stur	x0, [x29, #-8]
    95a4:	d2800000 	mov	x0, #0x0                   	// #0
    95a8:	b4002da1 	cbz	x1, 9b5c <fwp_hof0.constprop.0+0x5ec>
    95ac:	f00000a0 	adrp	x0, 20000 <__data_start>
    95b0:	9100401c 	add	x28, x0, #0x10
    95b4:	9101039c 	add	x28, x28, #0x40
    95b8:	f00000a0 	adrp	x0, 20000 <__data_start>
    95bc:	aa0103fa 	mov	x26, x1
    95c0:	d10083b4 	sub	x20, x29, #0x20
    95c4:	9101c015 	add	x21, x0, #0x70
    95c8:	aa1c03f8 	mov	x24, x28
    95cc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    95d0:	91174002 	add	x2, x0, #0x5d0
    95d4:	f949d841 	ldr	x1, [x2, #5040]
    95d8:	f949ec40 	ldr	x0, [x2, #5080]
    95dc:	cb0102e1 	sub	x1, x23, x1
    95e0:	eb00403f 	cmp	x1, x0, lsl #16
    95e4:	54000342 	b.cs	964c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    95e8:	d350fc20 	lsr	x0, x1, #16
    95ec:	f949fc44 	ldr	x4, [x2, #5112]
    95f0:	8b000800 	add	x0, x0, x0, lsl #2
    95f4:	d37df002 	lsl	x2, x0, #3
    95f8:	8b020083 	add	x3, x4, x2
    95fc:	f9401060 	ldr	x0, [x3, #32]
    9600:	b4000260 	cbz	x0, 964c <fwp_hof0.constprop.0+0xdc>
    9604:	38626882 	ldrb	w2, [x4, x2]
    9608:	7100085f 	cmp	w2, #0x2
    960c:	54005240 	b.eq	a054 <fwp_hof0.constprop.0+0xae4>  // b.none
    9610:	7100045f 	cmp	w2, #0x1
    9614:	540001c1 	b.ne	964c <fwp_hof0.constprop.0+0xdc>  // b.any
    9618:	29430864 	ldp	w4, w2, [x3, #24]
    961c:	92403c21 	and	x1, x1, #0xffff
    9620:	9b047c21 	mul	x1, x1, x4
    9624:	d360fc21 	lsr	x1, x1, #32
    9628:	eb02003f 	cmp	x1, x2
    962c:	54000102 	b.cs	964c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9630:	8b010000 	add	x0, x0, x1
    9634:	39400001 	ldrb	w1, [x0]
    9638:	340000a1 	cbz	w1, 964c <fwp_hof0.constprop.0+0xdc>
    963c:	7103f43f 	cmp	w1, #0xfd
    9640:	54005728 	b.hi	a124 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    9644:	11000421 	add	w1, w1, #0x1
    9648:	39000001 	strb	w1, [x0]
    964c:	aa1703f9 	mov	x25, x23
    9650:	a938dfba 	stp	x26, x23, [x29, #-120]
    9654:	aa1803fa 	mov	x26, x24
    9658:	d28018f3 	mov	x19, #0xc7                  	// #199
    965c:	f81983b3 	stur	x19, [x29, #-104]
    9660:	f00000a0 	adrp	x0, 20000 <__data_start>
    9664:	91004000 	add	x0, x0, #0x10
    9668:	f94046a3 	ldr	x3, [x21, #136]
    966c:	91010005 	add	x5, x0, #0x40
    9670:	b9404002 	ldr	w2, [x0, #64]
    9674:	d37be842 	lsl	x2, x2, #5
    9678:	8b02007b 	add	x27, x3, x2
    967c:	f9400f61 	ldr	x1, [x27, #24]
    9680:	f81e03b9 	stur	x25, [x29, #-32]
    9684:	b4004ee1 	cbz	x1, a060 <fwp_hof0.constprop.0+0xaf0>
    9688:	f9400c20 	ldr	x0, [x1, #24]
    968c:	b40042a0 	cbz	x0, 9ee0 <fwp_hof0.constprop.0+0x970>
    9690:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9694:	91174002 	add	x2, x0, #0x5d0
    9698:	f949d841 	ldr	x1, [x2, #5040]
    969c:	f949ec40 	ldr	x0, [x2, #5080]
    96a0:	cb010341 	sub	x1, x26, x1
    96a4:	eb00403f 	cmp	x1, x0, lsl #16
    96a8:	54000342 	b.cs	9710 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    96ac:	d350fc20 	lsr	x0, x1, #16
    96b0:	f949fc45 	ldr	x5, [x2, #5112]
    96b4:	8b000800 	add	x0, x0, x0, lsl #2
    96b8:	d37df002 	lsl	x2, x0, #3
    96bc:	8b0200a3 	add	x3, x5, x2
    96c0:	f9401060 	ldr	x0, [x3, #32]
    96c4:	b4000260 	cbz	x0, 9710 <fwp_hof0.constprop.0+0x1a0>
    96c8:	386268a2 	ldrb	w2, [x5, x2]
    96cc:	7100085f 	cmp	w2, #0x2
    96d0:	54004700 	b.eq	9fb0 <fwp_hof0.constprop.0+0xa40>  // b.none
    96d4:	7100045f 	cmp	w2, #0x1
    96d8:	540001c1 	b.ne	9710 <fwp_hof0.constprop.0+0x1a0>  // b.any
    96dc:	29430865 	ldp	w5, w2, [x3, #24]
    96e0:	92403c21 	and	x1, x1, #0xffff
    96e4:	9b057c21 	mul	x1, x1, x5
    96e8:	d360fc21 	lsr	x1, x1, #32
    96ec:	eb02003f 	cmp	x1, x2
    96f0:	54000102 	b.cs	9710 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    96f4:	8b010000 	add	x0, x0, x1
    96f8:	39400001 	ldrb	w1, [x0]
    96fc:	340000a1 	cbz	w1, 9710 <fwp_hof0.constprop.0+0x1a0>
    9700:	7103f43f 	cmp	w1, #0xfd
    9704:	54004988 	b.hi	a034 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    9708:	11000421 	add	w1, w1, #0x1
    970c:	39000001 	strb	w1, [x0]
    9710:	aa1a03f9 	mov	x25, x26
    9714:	aa1a03e0 	mov	x0, x26
    9718:	aa1b03e3 	mov	x3, x27
    971c:	52800037 	mov	w23, #0x1                   	// #1
    9720:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9724:	91174036 	add	x22, x1, #0x5d0
    9728:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    972c:	f81b03b6 	stur	x22, [x29, #-80]
    9730:	b81cc3b7 	stur	w23, [x29, #-52]
    9734:	f81d03b4 	stur	x20, [x29, #-48]
    9738:	b9400401 	ldr	w1, [x0, #4]
    973c:	b9400078 	ldr	w24, [x3]
    9740:	b85cc3a0 	ldur	w0, [x29, #-52]
    9744:	4b010318 	sub	w24, w24, w1
    9748:	6b17031f 	cmp	w24, w23
    974c:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9750:	6b0000ff 	cmp	w7, w0
    9754:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9758:	b81c83a0 	stur	w0, [x29, #-56]
    975c:	6b0000e2 	subs	w2, w7, w0
    9760:	54000120 	b.eq	9784 <fwp_hof0.constprop.0+0x214>  // b.none
    9764:	f9400c63 	ldr	x3, [x3, #24]
    9768:	0b000021 	add	w1, w1, w0
    976c:	f85d03a4 	ldur	x4, [x29, #-48]
    9770:	b81d83a7 	stur	w7, [x29, #-40]
    9774:	f9400863 	ldr	x3, [x3, #16]
    9778:	8b204c80 	add	x0, x4, w0, uxtw #3
    977c:	d63f0060 	blr	x3
    9780:	b85d83a7 	ldur	w7, [x29, #-40]
    9784:	f94046a0 	ldr	x0, [x21, #136]
    9788:	aa1903e6 	mov	x6, x25
    978c:	b9400323 	ldr	w3, [x25]
    9790:	2a0703f4 	mov	w20, w7
    9794:	f85d03bb 	ldur	x27, [x29, #-48]
    9798:	aa1903fc 	mov	x28, x25
    979c:	8b03141a 	add	x26, x0, x3, lsl #5
    97a0:	f9400f40 	ldr	x0, [x26, #24]
    97a4:	b40020e0 	cbz	x0, 9bc0 <fwp_hof0.constprop.0+0x650>
    97a8:	f85b03bc 	ldur	x28, [x29, #-80]
    97ac:	29371fb7 	stp	w23, w7, [x29, #-72]
    97b0:	aa1a03f7 	mov	x23, x26
    97b4:	b81c03b8 	stur	w24, [x29, #-64]
    97b8:	aa1b03f8 	mov	x24, x27
    97bc:	14000012 	b	9804 <fwp_hof0.constprop.0+0x294>
    97c0:	f9400001 	ldr	x1, [x0]
    97c4:	aa1803e0 	mov	x0, x24
    97c8:	d63f0020 	blr	x1
    97cc:	aa0003fb 	mov	x27, x0
    97d0:	aa1903e0 	mov	x0, x25
    97d4:	97fff1d7 	bl	5f30 <fwp_closure_drop>
    97d8:	6b13029f 	cmp	w20, w19
    97dc:	54000ca0 	b.eq	9970 <fwp_hof0.constprop.0+0x400>  // b.none
    97e0:	f94046a0 	ldr	x0, [x21, #136]
    97e4:	8b334f18 	add	x24, x24, w19, uxtw #3
    97e8:	b9400363 	ldr	w3, [x27]
    97ec:	4b1a02d4 	sub	w20, w22, w26
    97f0:	aa1b03e6 	mov	x6, x27
    97f4:	8b031417 	add	x23, x0, x3, lsl #5
    97f8:	f9400ee0 	ldr	x0, [x23, #24]
    97fc:	b4001da0 	cbz	x0, 9bb0 <fwp_hof0.constprop.0+0x640>
    9800:	aa1b03f9 	mov	x25, x27
    9804:	b94004c1 	ldr	w1, [x6, #4]
    9808:	b94002fa 	ldr	w26, [x23]
    980c:	0b010296 	add	w22, w20, w1
    9810:	6b16035f 	cmp	w26, w22
    9814:	54002488 	b.hi	9ca4 <fwp_hof0.constprop.0+0x734>  // b.pmore
    9818:	7100003f 	cmp	w1, #0x0
    981c:	4b010353 	sub	w19, w26, w1
    9820:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9824:	54fffce1 	b.ne	97c0 <fwp_hof0.constprop.0+0x250>  // b.any
    9828:	7100035f 	cmp	w26, #0x0
    982c:	910003e2 	mov	x2, sp
    9830:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9834:	f81d83a2 	stur	x2, [x29, #-40]
    9838:	d37df084 	lsl	x4, x4, #3
    983c:	91003c84 	add	x4, x4, #0xf
    9840:	92704c87 	and	x7, x4, #0xfffff0000
    9844:	927c7c84 	and	x4, x4, #0xffffffff0
    9848:	cb2763e7 	sub	x7, sp, x7
    984c:	eb2763ff 	cmp	sp, x7
    9850:	540000a0 	b.eq	9864 <fwp_hof0.constprop.0+0x2f4>  // b.none
    9854:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9858:	f90203ff 	str	xzr, [sp, #1024]
    985c:	eb2763ff 	cmp	sp, x7
    9860:	54ffffa1 	b.ne	9854 <fwp_hof0.constprop.0+0x2e4>  // b.any
    9864:	92403c84 	and	x4, x4, #0xffff
    9868:	cb2463ff 	sub	sp, sp, x4
    986c:	f90003ff 	str	xzr, [sp]
    9870:	f110009f 	cmp	x4, #0x400
    9874:	54000043 	b.cc	987c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9878:	f90203ff 	str	xzr, [sp, #1024]
    987c:	910043fb 	add	x27, sp, #0x10
    9880:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9884:	910020c9 	add	x9, x6, #0x8
    9888:	d2800004 	mov	x4, #0x0                   	// #0
    988c:	340000c1 	cbz	w1, 98a4 <fwp_hof0.constprop.0+0x334>
    9890:	f8646922 	ldr	x2, [x9, x4]
    9894:	f8246b62 	str	x2, [x27, x4]
    9898:	91002084 	add	x4, x4, #0x8
    989c:	eb04015f 	cmp	x10, x4
    98a0:	54ffff81 	b.ne	9890 <fwp_hof0.constprop.0+0x320>  // b.any
    98a4:	2a1303ea 	mov	w10, w19
    98a8:	d2800004 	mov	x4, #0x0                   	// #0
    98ac:	340000f3 	cbz	w19, 98c8 <fwp_hof0.constprop.0+0x358>
    98b0:	0b040022 	add	w2, w1, w4
    98b4:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    98b8:	91000484 	add	x4, x4, #0x1
    98bc:	f8227b63 	str	x3, [x27, x2, lsl #3]
    98c0:	eb04015f 	cmp	x10, x4
    98c4:	54ffff61 	b.ne	98b0 <fwp_hof0.constprop.0+0x340>  // b.any
    98c8:	f949db81 	ldr	x1, [x28, #5040]
    98cc:	f949ef84 	ldr	x4, [x28, #5080]
    98d0:	cb010321 	sub	x1, x25, x1
    98d4:	eb04403f 	cmp	x1, x4, lsl #16
    98d8:	540002e2 	b.cs	9934 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    98dc:	d350fc24 	lsr	x4, x1, #16
    98e0:	f949ff8a 	ldr	x10, [x28, #5112]
    98e4:	8b040884 	add	x4, x4, x4, lsl #2
    98e8:	d37df084 	lsl	x4, x4, #3
    98ec:	8b040149 	add	x9, x10, x4
    98f0:	f9401128 	ldr	x8, [x9, #32]
    98f4:	b4000208 	cbz	x8, 9934 <fwp_hof0.constprop.0+0x3c4>
    98f8:	38646944 	ldrb	w4, [x10, x4]
    98fc:	7100089f 	cmp	w4, #0x2
    9900:	54001520 	b.eq	9ba4 <fwp_hof0.constprop.0+0x634>  // b.none
    9904:	7100049f 	cmp	w4, #0x1
    9908:	54000161 	b.ne	9934 <fwp_hof0.constprop.0+0x3c4>  // b.any
    990c:	2943112a 	ldp	w10, w4, [x9, #24]
    9910:	92403c21 	and	x1, x1, #0xffff
    9914:	9b0a7c21 	mul	x1, x1, x10
    9918:	d360fc21 	lsr	x1, x1, #32
    991c:	eb04003f 	cmp	x1, x4
    9920:	540000a2 	b.cs	9934 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    9924:	8b010108 	add	x8, x8, x1
    9928:	39400101 	ldrb	w1, [x8]
    992c:	7100043f 	cmp	w1, #0x1
    9930:	54001360 	b.eq	9b9c <fwp_hof0.constprop.0+0x62c>  // b.none
    9934:	f9400404 	ldr	x4, [x0, #8]
    9938:	52800021 	mov	w1, #0x1                   	// #1
    993c:	aa1903e0 	mov	x0, x25
    9940:	d63f0080 	blr	x4
    9944:	f9400ee1 	ldr	x1, [x23, #24]
    9948:	aa1b03e0 	mov	x0, x27
    994c:	f9400021 	ldr	x1, [x1]
    9950:	d63f0020 	blr	x1
    9954:	aa0003fb 	mov	x27, x0
    9958:	f85d83a0 	ldur	x0, [x29, #-40]
    995c:	9100001f 	mov	sp, x0
    9960:	aa1903e0 	mov	x0, x25
    9964:	97fff173 	bl	5f30 <fwp_closure_drop>
    9968:	6b13029f 	cmp	w20, w19
    996c:	54fff3a1 	b.ne	97e0 <fwp_hof0.constprop.0+0x270>  // b.any
    9970:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9974:	aa1b03f9 	mov	x25, x27
    9978:	b85c03b8 	ldur	w24, [x29, #-64]
    997c:	6b17031f 	cmp	w24, w23
    9980:	540014c3 	b.cc	9c18 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9984:	f85983a0 	ldur	x0, [x29, #-104]
    9988:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    998c:	f1000400 	subs	x0, x0, #0x1
    9990:	f81983a0 	stur	x0, [x29, #-104]
    9994:	54ffe661 	b.ne	9660 <fwp_hof0.constprop.0+0xf0>  // b.any
    9998:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe8d0>
    999c:	91102042 	add	x2, x2, #0x408
    99a0:	aa1903e1 	mov	x1, x25
    99a4:	aa1403e0 	mov	x0, x20
    99a8:	aa1a03f8 	mov	x24, x26
    99ac:	aa1903fb 	mov	x27, x25
    99b0:	a978dfba 	ldp	x26, x23, [x29, #-120]
    99b4:	91014042 	add	x2, x2, #0x50
    99b8:	52800023 	mov	w3, #0x1                   	// #1
    99bc:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    99c0:	f81f03bf 	stur	xzr, [x29, #-16]
    99c4:	97fffaef 	bl	8580 <fwp_write>
    99c8:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    99cc:	90000020 	adrp	x0, d000 <__divti3+0x2d0>
    99d0:	913da000 	add	x0, x0, #0xf68
    99d4:	f10002df 	cmp	x22, #0x0
    99d8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    99dc:	b1002b3f 	cmn	x25, #0xa
    99e0:	540039c8 	b.hi	a118 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    99e4:	91002720 	add	x0, x25, #0x9
    99e8:	52800021 	mov	w1, #0x1                   	// #1
    99ec:	97ffed41 	bl	4ef0 <fwp_heap_alloc>
    99f0:	aa0003f3 	mov	x19, x0
    99f4:	aa1603e1 	mov	x1, x22
    99f8:	aa0003f6 	mov	x22, x0
    99fc:	aa1903e2 	mov	x2, x25
    9a00:	f80086d9 	str	x25, [x22], #8
    9a04:	8b190279 	add	x25, x19, x25
    9a08:	aa1603e0 	mov	x0, x22
    9a0c:	97ffe331 	bl	26d0 <memcpy@plt>
    9a10:	3900233f 	strb	wzr, [x25, #8]
    9a14:	f85e03a0 	ldur	x0, [x29, #-32]
    9a18:	97ffe3ca 	bl	2940 <free@plt>
    9a1c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9a20:	91174002 	add	x2, x0, #0x5d0
    9a24:	f949d841 	ldr	x1, [x2, #5040]
    9a28:	f949ec40 	ldr	x0, [x2, #5080]
    9a2c:	cb010261 	sub	x1, x19, x1
    9a30:	eb00403f 	cmp	x1, x0, lsl #16
    9a34:	54000322 	b.cs	9a98 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9a38:	d350fc20 	lsr	x0, x1, #16
    9a3c:	f949fc43 	ldr	x3, [x2, #5112]
    9a40:	8b000800 	add	x0, x0, x0, lsl #2
    9a44:	d37df002 	lsl	x2, x0, #3
    9a48:	8b020060 	add	x0, x3, x2
    9a4c:	f9401019 	ldr	x25, [x0, #32]
    9a50:	b4000259 	cbz	x25, 9a98 <fwp_hof0.constprop.0+0x528>
    9a54:	38626862 	ldrb	w2, [x3, x2]
    9a58:	7100085f 	cmp	w2, #0x2
    9a5c:	54003220 	b.eq	a0a0 <fwp_hof0.constprop.0+0xb30>  // b.none
    9a60:	7100045f 	cmp	w2, #0x1
    9a64:	540001a1 	b.ne	9a98 <fwp_hof0.constprop.0+0x528>  // b.any
    9a68:	29430002 	ldp	w2, w0, [x0, #24]
    9a6c:	92403c21 	and	x1, x1, #0xffff
    9a70:	9b027c21 	mul	x1, x1, x2
    9a74:	d360fc21 	lsr	x1, x1, #32
    9a78:	eb00003f 	cmp	x1, x0
    9a7c:	540000e2 	b.cs	9a98 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9a80:	8b010339 	add	x25, x25, x1
    9a84:	39400320 	ldrb	w0, [x25]
    9a88:	7103fc1f 	cmp	w0, #0xff
    9a8c:	54003520 	b.eq	a130 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9a90:	52800020 	mov	w0, #0x1                   	// #1
    9a94:	39000320 	strb	w0, [x25]
    9a98:	aa1b03e0 	mov	x0, x27
    9a9c:	97fff0c9 	bl	5dc0 <fwp_drop0>
    9aa0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9aa4:	9101c003 	add	x3, x0, #0x70
    9aa8:	f9400262 	ldr	x2, [x19]
    9aac:	aa1603e0 	mov	x0, x22
    9ab0:	aa0303f6 	mov	x22, x3
    9ab4:	d2800021 	mov	x1, #0x1                   	// #1
    9ab8:	f9400463 	ldr	x3, [x3, #8]
    9abc:	97ffe3b1 	bl	2980 <fwrite@plt>
    9ac0:	f94006c1 	ldr	x1, [x22, #8]
    9ac4:	52800140 	mov	w0, #0xa                   	// #10
    9ac8:	97ffe336 	bl	27a0 <fputc@plt>
    9acc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ad0:	91174002 	add	x2, x0, #0x5d0
    9ad4:	f949d841 	ldr	x1, [x2, #5040]
    9ad8:	f949ec40 	ldr	x0, [x2, #5080]
    9adc:	cb010261 	sub	x1, x19, x1
    9ae0:	eb00403f 	cmp	x1, x0, lsl #16
    9ae4:	54000382 	b.cs	9b54 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9ae8:	d350fc20 	lsr	x0, x1, #16
    9aec:	f949fc43 	ldr	x3, [x2, #5112]
    9af0:	8b000800 	add	x0, x0, x0, lsl #2
    9af4:	d37df000 	lsl	x0, x0, #3
    9af8:	8b000062 	add	x2, x3, x0
    9afc:	f9401056 	ldr	x22, [x2, #32]
    9b00:	b40002b6 	cbz	x22, 9b54 <fwp_hof0.constprop.0+0x5e4>
    9b04:	38606860 	ldrb	w0, [x3, x0]
    9b08:	7100081f 	cmp	w0, #0x2
    9b0c:	54002c40 	b.eq	a094 <fwp_hof0.constprop.0+0xb24>  // b.none
    9b10:	7100041f 	cmp	w0, #0x1
    9b14:	54000201 	b.ne	9b54 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9b18:	29430043 	ldp	w3, w0, [x2, #24]
    9b1c:	92403c21 	and	x1, x1, #0xffff
    9b20:	9b037c21 	mul	x1, x1, x3
    9b24:	d360fc21 	lsr	x1, x1, #32
    9b28:	eb00003f 	cmp	x1, x0
    9b2c:	54000142 	b.cs	9b54 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9b30:	8b0102d6 	add	x22, x22, x1
    9b34:	394002c0 	ldrb	w0, [x22]
    9b38:	340000e0 	cbz	w0, 9b54 <fwp_hof0.constprop.0+0x5e4>
    9b3c:	7100041f 	cmp	w0, #0x1
    9b40:	54002a00 	b.eq	a080 <fwp_hof0.constprop.0+0xb10>  // b.none
    9b44:	7103fc1f 	cmp	w0, #0xff
    9b48:	54002b20 	b.eq	a0ac <fwp_hof0.constprop.0+0xb3c>  // b.none
    9b4c:	51000400 	sub	w0, w0, #0x1
    9b50:	390002c0 	strb	w0, [x22]
    9b54:	f9400b5a 	ldr	x26, [x26, #16]
    9b58:	b5ffd3ba 	cbnz	x26, 95cc <fwp_hof0.constprop.0+0x5c>
    9b5c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9b60:	f947f400 	ldr	x0, [x0, #4072]
    9b64:	f85f83a2 	ldur	x2, [x29, #-8]
    9b68:	f9400001 	ldr	x1, [x0]
    9b6c:	eb010042 	subs	x2, x2, x1
    9b70:	d2800001 	mov	x1, #0x0                   	// #0
    9b74:	54002dc1 	b.ne	a12c <fwp_hof0.constprop.0+0xbbc>  // b.any
    9b78:	910003bf 	mov	sp, x29
    9b7c:	d2800000 	mov	x0, #0x0                   	// #0
    9b80:	a94153f3 	ldp	x19, x20, [sp, #16]
    9b84:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9b88:	a94363f7 	ldp	x23, x24, [sp, #48]
    9b8c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9b90:	a94573fb 	ldp	x27, x28, [sp, #80]
    9b94:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9b98:	d65f03c0 	ret
    9b9c:	b90004df 	str	wzr, [x6, #4]
    9ba0:	17ffff69 	b	9944 <fwp_hof0.constprop.0+0x3d4>
    9ba4:	72003c3f 	tst	w1, #0xffff
    9ba8:	54ffec61 	b.ne	9934 <fwp_hof0.constprop.0+0x3c4>  // b.any
    9bac:	17ffff5f 	b	9928 <fwp_hof0.constprop.0+0x3b8>
    9bb0:	aa1b03fc 	mov	x28, x27
    9bb4:	aa1803fb 	mov	x27, x24
    9bb8:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9bbc:	b85c03b8 	ldur	w24, [x29, #-64]
    9bc0:	aa1c03e0 	mov	x0, x28
    9bc4:	b81d83a7 	stur	w7, [x29, #-40]
    9bc8:	97ffeefe 	bl	57c0 <fwp_rc_share>
    9bcc:	b85d83a7 	ldur	w7, [x29, #-40]
    9bd0:	34000134 	cbz	w20, 9bf4 <fwp_hof0.constprop.0+0x684>
    9bd4:	aa1b03f6 	mov	x22, x27
    9bd8:	8b344f73 	add	x19, x27, w20, uxtw #3
    9bdc:	2a0703f9 	mov	w25, w7
    9be0:	f84086c0 	ldr	x0, [x22], #8
    9be4:	97ffeef7 	bl	57c0 <fwp_rc_share>
    9be8:	eb16027f 	cmp	x19, x22
    9bec:	54ffffa1 	b.ne	9be0 <fwp_hof0.constprop.0+0x670>  // b.any
    9bf0:	2a1903e7 	mov	w7, w25
    9bf4:	aa1b03e2 	mov	x2, x27
    9bf8:	2a1403e1 	mov	w1, w20
    9bfc:	aa1c03e0 	mov	x0, x28
    9c00:	b81d83a7 	stur	w7, [x29, #-40]
    9c04:	97ffed00 	bl	5004 <fwp_apply>
    9c08:	aa0003f9 	mov	x25, x0
    9c0c:	b85d83a7 	ldur	w7, [x29, #-40]
    9c10:	6b17031f 	cmp	w24, w23
    9c14:	54ffeb82 	b.cs	9984 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    9c18:	f94046a1 	ldr	x1, [x21, #136]
    9c1c:	4b0702f7 	sub	w23, w23, w7
    9c20:	b9400323 	ldr	w3, [x25]
    9c24:	f85d03a0 	ldur	x0, [x29, #-48]
    9c28:	8b031423 	add	x3, x1, x3, lsl #5
    9c2c:	b85c83a2 	ldur	w2, [x29, #-56]
    9c30:	8b274c00 	add	x0, x0, w7, uxtw #3
    9c34:	f81d03a0 	stur	x0, [x29, #-48]
    9c38:	f9400c61 	ldr	x1, [x3, #24]
    9c3c:	b85cc3a0 	ldur	w0, [x29, #-52]
    9c40:	4b020000 	sub	w0, w0, w2
    9c44:	b81cc3a0 	stur	w0, [x29, #-52]
    9c48:	aa1903e0 	mov	x0, x25
    9c4c:	b5ffd761 	cbnz	x1, 9738 <fwp_hof0.constprop.0+0x1c8>
    9c50:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9c54:	aa1903e0 	mov	x0, x25
    9c58:	97ffeeda 	bl	57c0 <fwp_rc_share>
    9c5c:	34000117 	cbz	w23, 9c7c <fwp_hof0.constprop.0+0x70c>
    9c60:	f85d03b8 	ldur	x24, [x29, #-48]
    9c64:	d2800016 	mov	x22, #0x0                   	// #0
    9c68:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    9c6c:	910006d6 	add	x22, x22, #0x1
    9c70:	97ffeed4 	bl	57c0 <fwp_rc_share>
    9c74:	6b1602ff 	cmp	w23, w22
    9c78:	54ffff88 	b.hi	9c68 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    9c7c:	f85d03a2 	ldur	x2, [x29, #-48]
    9c80:	aa1903e0 	mov	x0, x25
    9c84:	2a1703e1 	mov	w1, w23
    9c88:	97ffecdf 	bl	5004 <fwp_apply>
    9c8c:	aa0003f9 	mov	x25, x0
    9c90:	f85983a0 	ldur	x0, [x29, #-104]
    9c94:	f1000400 	subs	x0, x0, #0x1
    9c98:	f81983a0 	stur	x0, [x29, #-104]
    9c9c:	54ffce21 	b.ne	9660 <fwp_hof0.constprop.0+0xf0>  // b.any
    9ca0:	17ffff3e 	b	9998 <fwp_hof0.constprop.0+0x428>
    9ca4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ca8:	9117400a 	add	x10, x0, #0x5d0
    9cac:	2a0103fc 	mov	w28, w1
    9cb0:	110006c0 	add	w0, w22, #0x1
    9cb4:	f120001f 	cmp	x0, #0x800
    9cb8:	aa1703fa 	mov	x26, x23
    9cbc:	b953a541 	ldr	w1, [x10, #5028]
    9cc0:	aa1803fb 	mov	x27, x24
    9cc4:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9cc8:	d37df000 	lsl	x0, x0, #3
    9ccc:	b85c03b8 	ldur	w24, [x29, #-64]
    9cd0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9cd4:	54001860 	b.eq	9fe0 <fwp_hof0.constprop.0+0xa70>  // b.none
    9cd8:	91003c01 	add	x1, x0, #0xf
    9cdc:	8b411141 	add	x1, x10, x1, lsr #4
    9ce0:	397e8021 	ldrb	w1, [x1, #4000]
    9ce4:	910f002b 	add	x11, x1, #0x3c0
    9ce8:	8b010429 	add	x9, x1, x1, lsl #1
    9cec:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9cf0:	8b090d4c 	add	x12, x10, x9, lsl #3
    9cf4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9cf8:	2a0b03e1 	mov	w1, w11
    9cfc:	b4001613 	cbz	x19, 9fbc <fwp_hof0.constprop.0+0xa4c>
    9d00:	f940026c 	ldr	x12, [x19]
    9d04:	aa2c03ec 	mvn	x12, x12
    9d08:	f829794c 	str	x12, [x10, x9, lsl #3]
    9d0c:	eb01001f 	cmp	x0, x1
    9d10:	540000c2 	b.cs	9d28 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    9d14:	d503201f 	nop
    9d18:	f8206a7f 	str	xzr, [x19, x0]
    9d1c:	91002000 	add	x0, x0, #0x8
    9d20:	eb00003f 	cmp	x1, x0
    9d24:	54ffffa8 	b.hi	9d18 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    9d28:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9d2c:	91174009 	add	x9, x0, #0x5d0
    9d30:	f94a1120 	ldr	x0, [x9, #5152]
    9d34:	ab010000 	adds	x0, x0, x1
    9d38:	54001e82 	b.cs	a108 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    9d3c:	f94a1521 	ldr	x1, [x9, #5160]
    9d40:	f90a1120 	str	x0, [x9, #5152]
    9d44:	eb01001f 	cmp	x0, x1
    9d48:	54000049 	b.ls	9d50 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    9d4c:	f90a1520 	str	x0, [x9, #5160]
    9d50:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9d54:	91174000 	add	x0, x0, #0x5d0
    9d58:	1e630161 	ucvtf	d1, w11
    9d5c:	fd4a1c00 	ldr	d0, [x0, #5176]
    9d60:	1e612800 	fadd	d0, d0, d1
    9d64:	fd0a1c00 	str	d0, [x0, #5176]
    9d68:	b94000c0 	ldr	w0, [x6]
    9d6c:	29005a60 	stp	w0, w22, [x19]
    9d70:	3400013c 	cbz	w28, 9d94 <fwp_hof0.constprop.0+0x824>
    9d74:	910020c1 	add	x1, x6, #0x8
    9d78:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9d7c:	91002260 	add	x0, x19, #0x8
    9d80:	b81c03a7 	stur	w7, [x29, #-64]
    9d84:	f81d83a6 	stur	x6, [x29, #-40]
    9d88:	97ffe25a 	bl	26f0 <memmove@plt>
    9d8c:	f85d83a6 	ldur	x6, [x29, #-40]
    9d90:	b85c03a7 	ldur	w7, [x29, #-64]
    9d94:	2a1403e9 	mov	w9, w20
    9d98:	d2800001 	mov	x1, #0x0                   	// #0
    9d9c:	34000114 	cbz	w20, 9dbc <fwp_hof0.constprop.0+0x84c>
    9da0:	0b010380 	add	w0, w28, w1
    9da4:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9da8:	8b000e60 	add	x0, x19, x0, lsl #3
    9dac:	91000421 	add	x1, x1, #0x1
    9db0:	f9000402 	str	x2, [x0, #8]
    9db4:	eb01013f 	cmp	x9, x1
    9db8:	54ffff41 	b.ne	9da0 <fwp_hof0.constprop.0+0x830>  // b.any
    9dbc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9dc0:	91174002 	add	x2, x0, #0x5d0
    9dc4:	f949d840 	ldr	x0, [x2, #5040]
    9dc8:	f949ec41 	ldr	x1, [x2, #5080]
    9dcc:	cb000320 	sub	x0, x25, x0
    9dd0:	eb01401f 	cmp	x0, x1, lsl #16
    9dd4:	540002e2 	b.cs	9e30 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9dd8:	d350fc01 	lsr	x1, x0, #16
    9ddc:	f949fc45 	ldr	x5, [x2, #5112]
    9de0:	8b010821 	add	x1, x1, x1, lsl #2
    9de4:	d37df021 	lsl	x1, x1, #3
    9de8:	8b0100a4 	add	x4, x5, x1
    9dec:	f9401082 	ldr	x2, [x4, #32]
    9df0:	b4000202 	cbz	x2, 9e30 <fwp_hof0.constprop.0+0x8c0>
    9df4:	386168a1 	ldrb	w1, [x5, x1]
    9df8:	7100083f 	cmp	w1, #0x2
    9dfc:	54001020 	b.eq	a000 <fwp_hof0.constprop.0+0xa90>  // b.none
    9e00:	7100043f 	cmp	w1, #0x1
    9e04:	54000161 	b.ne	9e30 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9e08:	29430485 	ldp	w5, w1, [x4, #24]
    9e0c:	92403c00 	and	x0, x0, #0xffff
    9e10:	9b057c00 	mul	x0, x0, x5
    9e14:	d360fc00 	lsr	x0, x0, #32
    9e18:	eb01001f 	cmp	x0, x1
    9e1c:	540000a2 	b.cs	9e30 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9e20:	8b000042 	add	x2, x2, x0
    9e24:	39400040 	ldrb	w0, [x2]
    9e28:	7100041f 	cmp	w0, #0x1
    9e2c:	54000be0 	b.eq	9fa8 <fwp_hof0.constprop.0+0xa38>  // b.none
    9e30:	f9400f42 	ldr	x2, [x26, #24]
    9e34:	aa1903e0 	mov	x0, x25
    9e38:	52800021 	mov	w1, #0x1                   	// #1
    9e3c:	b81d83a7 	stur	w7, [x29, #-40]
    9e40:	f9400442 	ldr	x2, [x2, #8]
    9e44:	d63f0040 	blr	x2
    9e48:	b85d83a7 	ldur	w7, [x29, #-40]
    9e4c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9e50:	91174002 	add	x2, x0, #0x5d0
    9e54:	f949d841 	ldr	x1, [x2, #5040]
    9e58:	f949ec40 	ldr	x0, [x2, #5080]
    9e5c:	cb010261 	sub	x1, x19, x1
    9e60:	eb00403f 	cmp	x1, x0, lsl #16
    9e64:	54000322 	b.cs	9ec8 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9e68:	d350fc20 	lsr	x0, x1, #16
    9e6c:	f949fc43 	ldr	x3, [x2, #5112]
    9e70:	8b000800 	add	x0, x0, x0, lsl #2
    9e74:	d37df002 	lsl	x2, x0, #3
    9e78:	8b020060 	add	x0, x3, x2
    9e7c:	f9401014 	ldr	x20, [x0, #32]
    9e80:	b4000254 	cbz	x20, 9ec8 <fwp_hof0.constprop.0+0x958>
    9e84:	38626862 	ldrb	w2, [x3, x2]
    9e88:	7100085f 	cmp	w2, #0x2
    9e8c:	54000c00 	b.eq	a00c <fwp_hof0.constprop.0+0xa9c>  // b.none
    9e90:	7100045f 	cmp	w2, #0x1
    9e94:	540001a1 	b.ne	9ec8 <fwp_hof0.constprop.0+0x958>  // b.any
    9e98:	29430002 	ldp	w2, w0, [x0, #24]
    9e9c:	92403c21 	and	x1, x1, #0xffff
    9ea0:	9b027c21 	mul	x1, x1, x2
    9ea4:	d360fc21 	lsr	x1, x1, #32
    9ea8:	eb00003f 	cmp	x1, x0
    9eac:	540000e2 	b.cs	9ec8 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9eb0:	8b010294 	add	x20, x20, x1
    9eb4:	39400280 	ldrb	w0, [x20]
    9eb8:	7103fc1f 	cmp	w0, #0xff
    9ebc:	54000b20 	b.eq	a020 <fwp_hof0.constprop.0+0xab0>  // b.none
    9ec0:	52800020 	mov	w0, #0x1                   	// #1
    9ec4:	39000280 	strb	w0, [x20]
    9ec8:	aa1903e0 	mov	x0, x25
    9ecc:	b81d83a7 	stur	w7, [x29, #-40]
    9ed0:	97fff018 	bl	5f30 <fwp_closure_drop>
    9ed4:	aa1303f9 	mov	x25, x19
    9ed8:	b85d83a7 	ldur	w7, [x29, #-40]
    9edc:	17ffff4d 	b	9c10 <fwp_hof0.constprop.0+0x6a0>
    9ee0:	b8626860 	ldr	w0, [x3, x2]
    9ee4:	b94004a2 	ldr	w2, [x5, #4]
    9ee8:	4b020003 	sub	w3, w0, w2
    9eec:	7100047f 	cmp	w3, #0x1
    9ef0:	54ffbd01 	b.ne	9690 <fwp_hof0.constprop.0+0x120>  // b.any
    9ef4:	910003f6 	mov	x22, sp
    9ef8:	34000a22 	cbz	w2, a03c <fwp_hof0.constprop.0+0xacc>
    9efc:	7100001f 	cmp	w0, #0x0
    9f00:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9f04:	d2800101 	mov	x1, #0x8                   	// #8
    9f08:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9f0c:	91003ee0 	add	x0, x23, #0xf
    9f10:	92704c01 	and	x1, x0, #0xfffff0000
    9f14:	927c7c00 	and	x0, x0, #0xffffffff0
    9f18:	cb2163e1 	sub	x1, sp, x1
    9f1c:	eb2163ff 	cmp	sp, x1
    9f20:	540000a0 	b.eq	9f34 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9f24:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9f28:	f90203ff 	str	xzr, [sp, #1024]
    9f2c:	eb2163ff 	cmp	sp, x1
    9f30:	54ffffa1 	b.ne	9f24 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9f34:	92403c00 	and	x0, x0, #0xffff
    9f38:	cb2063ff 	sub	sp, sp, x0
    9f3c:	f90003ff 	str	xzr, [sp]
    9f40:	f110001f 	cmp	x0, #0x400
    9f44:	54000043 	b.cc	9f4c <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9f48:	f90203ff 	str	xzr, [sp, #1024]
    9f4c:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9f50:	910043f8 	add	x24, sp, #0x10
    9f54:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f58:	91004001 	add	x1, x0, #0x10
    9f5c:	aa1c03e2 	mov	x2, x28
    9f60:	91012021 	add	x1, x1, #0x48
    9f64:	aa1703e3 	mov	x3, x23
    9f68:	aa1803e0 	mov	x0, x24
    9f6c:	97ffe219 	bl	27d0 <__memcpy_chk@plt>
    9f70:	eb1c02ff 	cmp	x23, x28
    9f74:	aa1403e1 	mov	x1, x20
    9f78:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    9f7c:	d2800102 	mov	x2, #0x8                   	// #8
    9f80:	cb1c0063 	sub	x3, x3, x28
    9f84:	8b1c0300 	add	x0, x24, x28
    9f88:	97ffe212 	bl	27d0 <__memcpy_chk@plt>
    9f8c:	f9400f61 	ldr	x1, [x27, #24]
    9f90:	aa1803e0 	mov	x0, x24
    9f94:	f9400021 	ldr	x1, [x1]
    9f98:	d63f0020 	blr	x1
    9f9c:	aa0003f9 	mov	x25, x0
    9fa0:	910002df 	mov	sp, x22
    9fa4:	17ffff3b 	b	9c90 <fwp_hof0.constprop.0+0x720>
    9fa8:	b90004df 	str	wzr, [x6, #4]
    9fac:	17ffffa8 	b	9e4c <fwp_hof0.constprop.0+0x8dc>
    9fb0:	72003c3f 	tst	w1, #0xffff
    9fb4:	54ffbae1 	b.ne	9710 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9fb8:	17fffdd0 	b	96f8 <fwp_hof0.constprop.0+0x188>
    9fbc:	f9400593 	ldr	x19, [x12, #8]
    9fc0:	b4000113 	cbz	x19, 9fe0 <fwp_hof0.constprop.0+0xa70>
    9fc4:	f9400989 	ldr	x9, [x12, #16]
    9fc8:	cb130129 	sub	x9, x9, x19
    9fcc:	eb09003f 	cmp	x1, x9
    9fd0:	54000088 	b.hi	9fe0 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    9fd4:	8b010269 	add	x9, x19, x1
    9fd8:	f9000589 	str	x9, [x12, #8]
    9fdc:	17ffff4c 	b	9d0c <fwp_hof0.constprop.0+0x79c>
    9fe0:	52800001 	mov	w1, #0x0                   	// #0
    9fe4:	f81c03a6 	stur	x6, [x29, #-64]
    9fe8:	b81d83a7 	stur	w7, [x29, #-40]
    9fec:	97ffebc1 	bl	4ef0 <fwp_heap_alloc>
    9ff0:	f85c03a6 	ldur	x6, [x29, #-64]
    9ff4:	aa0003f3 	mov	x19, x0
    9ff8:	b85d83a7 	ldur	w7, [x29, #-40]
    9ffc:	17ffff5b 	b	9d68 <fwp_hof0.constprop.0+0x7f8>
    a000:	72003c1f 	tst	w0, #0xffff
    a004:	54fff161 	b.ne	9e30 <fwp_hof0.constprop.0+0x8c0>  // b.any
    a008:	17ffff87 	b	9e24 <fwp_hof0.constprop.0+0x8b4>
    a00c:	72003c3f 	tst	w1, #0xffff
    a010:	54fff5c1 	b.ne	9ec8 <fwp_hof0.constprop.0+0x958>  // b.any
    a014:	39400280 	ldrb	w0, [x20]
    a018:	7103fc1f 	cmp	w0, #0xff
    a01c:	54fff521 	b.ne	9ec0 <fwp_hof0.constprop.0+0x950>  // b.any
    a020:	aa1403e0 	mov	x0, x20
    a024:	b81d83a7 	stur	w7, [x29, #-40]
    a028:	97ffe9f2 	bl	47f0 <fwp_rc_forget_slot>
    a02c:	b85d83a7 	ldur	w7, [x29, #-40]
    a030:	17ffffa4 	b	9ec0 <fwp_hof0.constprop.0+0x950>
    a034:	97ffe9a8 	bl	46d4 <fwp_rc_wide_dup>
    a038:	17fffdb6 	b	9710 <fwp_hof0.constprop.0+0x1a0>
    a03c:	f9400021 	ldr	x1, [x1]
    a040:	aa1403e0 	mov	x0, x20
    a044:	d63f0020 	blr	x1
    a048:	aa0003f9 	mov	x25, x0
    a04c:	910002df 	mov	sp, x22
    a050:	17ffff10 	b	9c90 <fwp_hof0.constprop.0+0x720>
    a054:	72003c3f 	tst	w1, #0xffff
    a058:	54ffafa1 	b.ne	964c <fwp_hof0.constprop.0+0xdc>  // b.any
    a05c:	17fffd76 	b	9634 <fwp_hof0.constprop.0+0xc4>
    a060:	aa1a03e0 	mov	x0, x26
    a064:	97ffedd7 	bl	57c0 <fwp_rc_share>
    a068:	aa1903e0 	mov	x0, x25
    a06c:	52800037 	mov	w23, #0x1                   	// #1
    a070:	97ffedd4 	bl	57c0 <fwp_rc_share>
    a074:	aa1a03f9 	mov	x25, x26
    a078:	f81d03b4 	stur	x20, [x29, #-48]
    a07c:	17ffff00 	b	9c7c <fwp_hof0.constprop.0+0x70c>
    a080:	aa1303e0 	mov	x0, x19
    a084:	97ffee24 	bl	5914 <fwp_rc_free_arr>
    a088:	f9400b5a 	ldr	x26, [x26, #16]
    a08c:	b5ffaa1a 	cbnz	x26, 95cc <fwp_hof0.constprop.0+0x5c>
    a090:	17fffeb3 	b	9b5c <fwp_hof0.constprop.0+0x5ec>
    a094:	72003c3f 	tst	w1, #0xffff
    a098:	54ffd5e1 	b.ne	9b54 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a09c:	17fffea6 	b	9b34 <fwp_hof0.constprop.0+0x5c4>
    a0a0:	72003c3f 	tst	w1, #0xffff
    a0a4:	54ffcfa1 	b.ne	9a98 <fwp_hof0.constprop.0+0x528>  // b.any
    a0a8:	17fffe77 	b	9a84 <fwp_hof0.constprop.0+0x514>
    a0ac:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a0b0:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a0b4:	91174021 	add	x1, x1, #0x5d0
    a0b8:	ca402400 	eor	x0, x0, x0, lsr #9
    a0bc:	8b200c20 	add	x0, x1, w0, uxtb #3
    a0c0:	f94a2400 	ldr	x0, [x0, #5192]
    a0c4:	b5000080 	cbnz	x0, a0d4 <fwp_hof0.constprop.0+0xb64>
    a0c8:	14000011 	b	a10c <fwp_hof0.constprop.0+0xb9c>
    a0cc:	f9400800 	ldr	x0, [x0, #16]
    a0d0:	b40001e0 	cbz	x0, a10c <fwp_hof0.constprop.0+0xb9c>
    a0d4:	f9400001 	ldr	x1, [x0]
    a0d8:	eb0102df 	cmp	x22, x1
    a0dc:	54ffff81 	b.ne	a0cc <fwp_hof0.constprop.0+0xb5c>  // b.any
    a0e0:	f9400401 	ldr	x1, [x0, #8]
    a0e4:	d1000421 	sub	x1, x1, #0x1
    a0e8:	f9000401 	str	x1, [x0, #8]
    a0ec:	f103f83f 	cmp	x1, #0xfe
    a0f0:	54ffd321 	b.ne	9b54 <fwp_hof0.constprop.0+0x5e4>  // b.any
    a0f4:	aa1603e0 	mov	x0, x22
    a0f8:	97ffe9be 	bl	47f0 <fwp_rc_forget_slot>
    a0fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a100:	390002c0 	strb	w0, [x22]
    a104:	17fffe94 	b	9b54 <fwp_hof0.constprop.0+0x5e4>
    a108:	97ffe3ca 	bl	3030 <fwp_heap_oom>
    a10c:	f0000000 	adrp	x0, d000 <__divti3+0x2d0>
    a110:	911ec000 	add	x0, x0, #0x7b0
    a114:	97ffe5bb 	bl	3800 <fwp_trap>
    a118:	f0000000 	adrp	x0, d000 <__divti3+0x2d0>
    a11c:	912aa000 	add	x0, x0, #0xaa8
    a120:	97ffe5b8 	bl	3800 <fwp_trap>
    a124:	97ffe96c 	bl	46d4 <fwp_rc_wide_dup>
    a128:	17fffd49 	b	964c <fwp_hof0.constprop.0+0xdc>
    a12c:	97ffe1d5 	bl	2880 <__stack_chk_fail@plt>
    a130:	aa1903e0 	mov	x0, x25
    a134:	97ffe9af 	bl	47f0 <fwp_rc_forget_slot>
    a138:	17fffe56 	b	9a90 <fwp_hof0.constprop.0+0x520>
    a13c:	d503201f 	nop

000000000000a140 <f0>:
    a140:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a144:	910003fd 	mov	x29, sp
    a148:	a90153f3 	stp	x19, x20, [sp, #16]
    a14c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a150:	a90363f7 	stp	x23, x24, [sp, #48]
    a154:	a9046bf9 	stp	x25, x26, [sp, #64]
    a158:	a90573fb 	stp	x27, x28, [sp, #80]
    a15c:	d12183ff 	sub	sp, sp, #0x860
    a160:	f90203ff 	str	xzr, [sp, #1024]
    a164:	d00000a0 	adrp	x0, 20000 <__data_start>
    a168:	9101c005 	add	x5, x0, #0x70
    a16c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a170:	f947f400 	ldr	x0, [x0, #4072]
    a174:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a178:	f94188a6 	ldr	x6, [x5, #784]
    a17c:	f9400001 	ldr	x1, [x0]
    a180:	f9042fe1 	str	x1, [sp, #2136]
    a184:	d2800001 	mov	x1, #0x0                   	// #0
    a188:	91174298 	add	x24, x20, #0x5d0
    a18c:	912123f6 	add	x22, sp, #0x848
    a190:	910023e0 	add	x0, sp, #0x8
    a194:	910083e2 	add	x2, sp, #0x20
    a198:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    a19c:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a1a0:	9131c021 	add	x1, x1, #0xc70
    a1a4:	913d4084 	add	x4, x4, #0xf50
    a1a8:	d2800013 	mov	x19, #0x0                   	// #0
    a1ac:	d2800119 	mov	x25, #0x8                   	// #8
    a1b0:	d2800015 	mov	x21, #0x0                   	// #0
    a1b4:	52800037 	mov	w23, #0x1                   	// #1
    a1b8:	a90093e6 	stp	x6, x4, [sp, #8]
    a1bc:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a1c0:	a90307ff 	stp	xzr, x1, [sp, #48]
    a1c4:	f90188a0 	str	x0, [x5, #784]
    a1c8:	f100073a 	subs	x26, x25, #0x1
    a1cc:	aa1603e1 	mov	x1, x22
    a1d0:	da1f02bc 	sbc	x28, x21, xzr
    a1d4:	52800020 	mov	w0, #0x1                   	// #1
    a1d8:	f90017fa 	str	x26, [sp, #40]
    a1dc:	aa1a03f9 	mov	x25, x26
    a1e0:	f90427fa 	str	x26, [sp, #2120]
    a1e4:	aa1c03f5 	mov	x21, x28
    a1e8:	f9042bf3 	str	x19, [sp, #2128]
    a1ec:	97ffed2d 	bl	56a0 <fwp_data.part.0.constprop.0>
    a1f0:	f949db02 	ldr	x2, [x24, #5040]
    a1f4:	aa0003f3 	mov	x19, x0
    a1f8:	f949ef00 	ldr	x0, [x24, #5080]
    a1fc:	cb020262 	sub	x2, x19, x2
    a200:	eb00405f 	cmp	x2, x0, lsl #16
    a204:	54000302 	b.cs	a264 <f0+0x124>  // b.hs, b.nlast
    a208:	d350fc40 	lsr	x0, x2, #16
    a20c:	f949ff04 	ldr	x4, [x24, #5112]
    a210:	8b000800 	add	x0, x0, x0, lsl #2
    a214:	d37df001 	lsl	x1, x0, #3
    a218:	8b010080 	add	x0, x4, x1
    a21c:	f940101b 	ldr	x27, [x0, #32]
    a220:	b400023b 	cbz	x27, a264 <f0+0x124>
    a224:	38616881 	ldrb	w1, [x4, x1]
    a228:	7100083f 	cmp	w1, #0x2
    a22c:	54010e20 	b.eq	c3f0 <f0+0x22b0>  // b.none
    a230:	7100043f 	cmp	w1, #0x1
    a234:	54000181 	b.ne	a264 <f0+0x124>  // b.any
    a238:	29430001 	ldp	w1, w0, [x0, #24]
    a23c:	92403c42 	and	x2, x2, #0xffff
    a240:	9b017c42 	mul	x2, x2, x1
    a244:	d360fc42 	lsr	x2, x2, #32
    a248:	eb00005f 	cmp	x2, x0
    a24c:	540000c2 	b.cs	a264 <f0+0x124>  // b.hs, b.nlast
    a250:	8b02037b 	add	x27, x27, x2
    a254:	39400360 	ldrb	w0, [x27]
    a258:	7103fc1f 	cmp	w0, #0xff
    a25c:	54010c40 	b.eq	c3e4 <f0+0x22a4>  // b.none
    a260:	39000377 	strb	w23, [x27]
    a264:	f90013f3 	str	x19, [sp, #32]
    a268:	aa1c035a 	orr	x26, x26, x28
    a26c:	b5fffafa 	cbnz	x26, a1c8 <f0+0x88>
    a270:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xbb0>
    a274:	910103e1 	add	x1, sp, #0x40
    a278:	f94007e2 	ldr	x2, [sp, #8]
    a27c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a280:	3dc08c00 	ldr	q0, [x0, #560]
    a284:	d00000a0 	adrp	x0, 20000 <__data_start>
    a288:	9101c018 	add	x24, x0, #0x70
    a28c:	52800020 	mov	w0, #0x1                   	// #1
    a290:	3d8013e0 	str	q0, [sp, #64]
    a294:	f9018b02 	str	x2, [x24, #784]
    a298:	97ffed02 	bl	56a0 <fwp_data.part.0.constprop.0>
    a29c:	97ffed6e 	bl	5854 <fwp_rc_fresh>
    a2a0:	aa0003e2 	mov	x2, x0
    a2a4:	910163e1 	add	x1, sp, #0x58
    a2a8:	52800020 	mov	w0, #0x1                   	// #1
    a2ac:	a9058bf5 	stp	x21, x2, [sp, #88]
    a2b0:	97ffecfc 	bl	56a0 <fwp_data.part.0.constprop.0>
    a2b4:	97ffed68 	bl	5854 <fwp_rc_fresh>
    a2b8:	aa0003e2 	mov	x2, x0
    a2bc:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xbb0>
    a2c0:	9101a3e1 	add	x1, sp, #0x68
    a2c4:	52800020 	mov	w0, #0x1                   	// #1
    a2c8:	f9003be2 	str	x2, [sp, #112]
    a2cc:	3dc08c60 	ldr	q0, [x3, #560]
    a2d0:	fd0037e0 	str	d0, [sp, #104]
    a2d4:	97ffecf3 	bl	56a0 <fwp_data.part.0.constprop.0>
    a2d8:	97ffed5f 	bl	5854 <fwp_rc_fresh>
    a2dc:	aa0003e2 	mov	x2, x0
    a2e0:	9101e3e1 	add	x1, sp, #0x78
    a2e4:	52800020 	mov	w0, #0x1                   	// #1
    a2e8:	a9078bf5 	stp	x21, x2, [sp, #120]
    a2ec:	97ffeced 	bl	56a0 <fwp_data.part.0.constprop.0>
    a2f0:	91174283 	add	x3, x20, #0x5d0
    a2f4:	aa0003f5 	mov	x21, x0
    a2f8:	f949d861 	ldr	x1, [x3, #5040]
    a2fc:	f949ec60 	ldr	x0, [x3, #5080]
    a300:	cb0102a1 	sub	x1, x21, x1
    a304:	eb00403f 	cmp	x1, x0, lsl #16
    a308:	54000322 	b.cs	a36c <f0+0x22c>  // b.hs, b.nlast
    a30c:	d350fc22 	lsr	x2, x1, #16
    a310:	f949fc63 	ldr	x3, [x3, #5112]
    a314:	8b020842 	add	x2, x2, x2, lsl #2
    a318:	d37df042 	lsl	x2, x2, #3
    a31c:	8b020060 	add	x0, x3, x2
    a320:	f9401017 	ldr	x23, [x0, #32]
    a324:	b4000257 	cbz	x23, a36c <f0+0x22c>
    a328:	38626862 	ldrb	w2, [x3, x2]
    a32c:	7100085f 	cmp	w2, #0x2
    a330:	54010a20 	b.eq	c474 <f0+0x2334>  // b.none
    a334:	7100045f 	cmp	w2, #0x1
    a338:	540001a1 	b.ne	a36c <f0+0x22c>  // b.any
    a33c:	29430002 	ldp	w2, w0, [x0, #24]
    a340:	92403c21 	and	x1, x1, #0xffff
    a344:	9b027c21 	mul	x1, x1, x2
    a348:	d360fc21 	lsr	x1, x1, #32
    a34c:	eb00003f 	cmp	x1, x0
    a350:	540000e2 	b.cs	a36c <f0+0x22c>  // b.hs, b.nlast
    a354:	8b0102f7 	add	x23, x23, x1
    a358:	394002e0 	ldrb	w0, [x23]
    a35c:	7103fc1f 	cmp	w0, #0xff
    a360:	540113e0 	b.eq	c5dc <f0+0x249c>  // b.none
    a364:	52800020 	mov	w0, #0x1                   	// #1
    a368:	390002e0 	strb	w0, [x23]
    a36c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a370:	910223e1 	add	x1, sp, #0x88
    a374:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a378:	52800020 	mov	w0, #0x1                   	// #1
    a37c:	a908d7e2 	stp	x2, x21, [sp, #136]
    a380:	97ffecc8 	bl	56a0 <fwp_data.part.0.constprop.0>
    a384:	97ffed34 	bl	5854 <fwp_rc_fresh>
    a388:	aa0003e2 	mov	x2, x0
    a38c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a390:	910263e1 	add	x1, sp, #0x98
    a394:	52800020 	mov	w0, #0x1                   	// #1
    a398:	a9098be3 	stp	x3, x2, [sp, #152]
    a39c:	97ffecc1 	bl	56a0 <fwp_data.part.0.constprop.0>
    a3a0:	91174283 	add	x3, x20, #0x5d0
    a3a4:	aa0003f7 	mov	x23, x0
    a3a8:	f949d861 	ldr	x1, [x3, #5040]
    a3ac:	f949ec60 	ldr	x0, [x3, #5080]
    a3b0:	cb0102e1 	sub	x1, x23, x1
    a3b4:	eb00403f 	cmp	x1, x0, lsl #16
    a3b8:	54000322 	b.cs	a41c <f0+0x2dc>  // b.hs, b.nlast
    a3bc:	d350fc22 	lsr	x2, x1, #16
    a3c0:	f949fc63 	ldr	x3, [x3, #5112]
    a3c4:	8b020842 	add	x2, x2, x2, lsl #2
    a3c8:	d37df042 	lsl	x2, x2, #3
    a3cc:	8b020060 	add	x0, x3, x2
    a3d0:	f9401015 	ldr	x21, [x0, #32]
    a3d4:	b4000255 	cbz	x21, a41c <f0+0x2dc>
    a3d8:	38626862 	ldrb	w2, [x3, x2]
    a3dc:	7100085f 	cmp	w2, #0x2
    a3e0:	54010440 	b.eq	c468 <f0+0x2328>  // b.none
    a3e4:	7100045f 	cmp	w2, #0x1
    a3e8:	540001a1 	b.ne	a41c <f0+0x2dc>  // b.any
    a3ec:	29430002 	ldp	w2, w0, [x0, #24]
    a3f0:	92403c21 	and	x1, x1, #0xffff
    a3f4:	9b027c21 	mul	x1, x1, x2
    a3f8:	d360fc21 	lsr	x1, x1, #32
    a3fc:	eb00003f 	cmp	x1, x0
    a400:	540000e2 	b.cs	a41c <f0+0x2dc>  // b.hs, b.nlast
    a404:	8b0102b5 	add	x21, x21, x1
    a408:	394002a0 	ldrb	w0, [x21]
    a40c:	7103fc1f 	cmp	w0, #0xff
    a410:	54010ec0 	b.eq	c5e8 <f0+0x24a8>  // b.none
    a414:	52800020 	mov	w0, #0x1                   	// #1
    a418:	390002a0 	strb	w0, [x21]
    a41c:	9102a3e1 	add	x1, sp, #0xa8
    a420:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a424:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a428:	52800020 	mov	w0, #0x1                   	// #1
    a42c:	a90adff5 	stp	x21, x23, [sp, #168]
    a430:	97ffec9c 	bl	56a0 <fwp_data.part.0.constprop.0>
    a434:	97ffed08 	bl	5854 <fwp_rc_fresh>
    a438:	aa0003e2 	mov	x2, x0
    a43c:	9102e3e1 	add	x1, sp, #0xb8
    a440:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a444:	52800020 	mov	w0, #0x1                   	// #1
    a448:	a90b8bf7 	stp	x23, x2, [sp, #184]
    a44c:	97ffec95 	bl	56a0 <fwp_data.part.0.constprop.0>
    a450:	97ffed01 	bl	5854 <fwp_rc_fresh>
    a454:	aa0003e2 	mov	x2, x0
    a458:	910323e1 	add	x1, sp, #0xc8
    a45c:	52800020 	mov	w0, #0x1                   	// #1
    a460:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a464:	97ffec8f 	bl	56a0 <fwp_data.part.0.constprop.0>
    a468:	97ffecfb 	bl	5854 <fwp_rc_fresh>
    a46c:	aa0003e2 	mov	x2, x0
    a470:	910363e1 	add	x1, sp, #0xd8
    a474:	52800020 	mov	w0, #0x1                   	// #1
    a478:	a90d8bf7 	stp	x23, x2, [sp, #216]
    a47c:	97ffec89 	bl	56a0 <fwp_data.part.0.constprop.0>
    a480:	97ffecf5 	bl	5854 <fwp_rc_fresh>
    a484:	aa0003e2 	mov	x2, x0
    a488:	9103a3e1 	add	x1, sp, #0xe8
    a48c:	52800020 	mov	w0, #0x1                   	// #1
    a490:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a494:	97ffec83 	bl	56a0 <fwp_data.part.0.constprop.0>
    a498:	97ffecef 	bl	5854 <fwp_rc_fresh>
    a49c:	aa0003e2 	mov	x2, x0
    a4a0:	9103e3e1 	add	x1, sp, #0xf8
    a4a4:	52800020 	mov	w0, #0x1                   	// #1
    a4a8:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a4ac:	97ffec7d 	bl	56a0 <fwp_data.part.0.constprop.0>
    a4b0:	97ffece9 	bl	5854 <fwp_rc_fresh>
    a4b4:	aa0003e2 	mov	x2, x0
    a4b8:	910423e1 	add	x1, sp, #0x108
    a4bc:	52800020 	mov	w0, #0x1                   	// #1
    a4c0:	a9108bf5 	stp	x21, x2, [sp, #264]
    a4c4:	97ffec77 	bl	56a0 <fwp_data.part.0.constprop.0>
    a4c8:	91174283 	add	x3, x20, #0x5d0
    a4cc:	aa0003f5 	mov	x21, x0
    a4d0:	f949d861 	ldr	x1, [x3, #5040]
    a4d4:	f949ec60 	ldr	x0, [x3, #5080]
    a4d8:	cb0102a1 	sub	x1, x21, x1
    a4dc:	eb00403f 	cmp	x1, x0, lsl #16
    a4e0:	54000322 	b.cs	a544 <f0+0x404>  // b.hs, b.nlast
    a4e4:	d350fc22 	lsr	x2, x1, #16
    a4e8:	f949fc63 	ldr	x3, [x3, #5112]
    a4ec:	8b020842 	add	x2, x2, x2, lsl #2
    a4f0:	d37df042 	lsl	x2, x2, #3
    a4f4:	8b020060 	add	x0, x3, x2
    a4f8:	f9401017 	ldr	x23, [x0, #32]
    a4fc:	b4000257 	cbz	x23, a544 <f0+0x404>
    a500:	38626862 	ldrb	w2, [x3, x2]
    a504:	7100085f 	cmp	w2, #0x2
    a508:	5400faa0 	b.eq	c45c <f0+0x231c>  // b.none
    a50c:	7100045f 	cmp	w2, #0x1
    a510:	540001a1 	b.ne	a544 <f0+0x404>  // b.any
    a514:	29430002 	ldp	w2, w0, [x0, #24]
    a518:	92403c21 	and	x1, x1, #0xffff
    a51c:	9b027c21 	mul	x1, x1, x2
    a520:	d360fc21 	lsr	x1, x1, #32
    a524:	eb00003f 	cmp	x1, x0
    a528:	540000e2 	b.cs	a544 <f0+0x404>  // b.hs, b.nlast
    a52c:	8b0102f7 	add	x23, x23, x1
    a530:	394002e0 	ldrb	w0, [x23]
    a534:	7103fc1f 	cmp	w0, #0xff
    a538:	540105e0 	b.eq	c5f4 <f0+0x24b4>  // b.none
    a53c:	52800020 	mov	w0, #0x1                   	// #1
    a540:	390002e0 	strb	w0, [x23]
    a544:	910463e1 	add	x1, sp, #0x118
    a548:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a54c:	52800020 	mov	w0, #0x1                   	// #1
    a550:	a911d7e2 	stp	x2, x21, [sp, #280]
    a554:	97ffec53 	bl	56a0 <fwp_data.part.0.constprop.0>
    a558:	97ffecbf 	bl	5854 <fwp_rc_fresh>
    a55c:	aa0003e2 	mov	x2, x0
    a560:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a564:	9104a3e1 	add	x1, sp, #0x128
    a568:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a56c:	52800020 	mov	w0, #0x1                   	// #1
    a570:	a9128be3 	stp	x3, x2, [sp, #296]
    a574:	97ffec4b 	bl	56a0 <fwp_data.part.0.constprop.0>
    a578:	91174283 	add	x3, x20, #0x5d0
    a57c:	aa0003f5 	mov	x21, x0
    a580:	f949d861 	ldr	x1, [x3, #5040]
    a584:	f949ec60 	ldr	x0, [x3, #5080]
    a588:	cb0102a1 	sub	x1, x21, x1
    a58c:	eb00403f 	cmp	x1, x0, lsl #16
    a590:	54000322 	b.cs	a5f4 <f0+0x4b4>  // b.hs, b.nlast
    a594:	d350fc22 	lsr	x2, x1, #16
    a598:	f949fc63 	ldr	x3, [x3, #5112]
    a59c:	8b020842 	add	x2, x2, x2, lsl #2
    a5a0:	d37df042 	lsl	x2, x2, #3
    a5a4:	8b020060 	add	x0, x3, x2
    a5a8:	f9401017 	ldr	x23, [x0, #32]
    a5ac:	b4000257 	cbz	x23, a5f4 <f0+0x4b4>
    a5b0:	38626862 	ldrb	w2, [x3, x2]
    a5b4:	7100085f 	cmp	w2, #0x2
    a5b8:	5400f760 	b.eq	c4a4 <f0+0x2364>  // b.none
    a5bc:	7100045f 	cmp	w2, #0x1
    a5c0:	540001a1 	b.ne	a5f4 <f0+0x4b4>  // b.any
    a5c4:	29430002 	ldp	w2, w0, [x0, #24]
    a5c8:	92403c21 	and	x1, x1, #0xffff
    a5cc:	9b027c21 	mul	x1, x1, x2
    a5d0:	d360fc21 	lsr	x1, x1, #32
    a5d4:	eb00003f 	cmp	x1, x0
    a5d8:	540000e2 	b.cs	a5f4 <f0+0x4b4>  // b.hs, b.nlast
    a5dc:	8b0102f7 	add	x23, x23, x1
    a5e0:	394002e0 	ldrb	w0, [x23]
    a5e4:	7103fc1f 	cmp	w0, #0xff
    a5e8:	540100c0 	b.eq	c600 <f0+0x24c0>  // b.none
    a5ec:	52800020 	mov	w0, #0x1                   	// #1
    a5f0:	390002e0 	strb	w0, [x23]
    a5f4:	9104e3e1 	add	x1, sp, #0x138
    a5f8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a5fc:	52800020 	mov	w0, #0x1                   	// #1
    a600:	a913d7e2 	stp	x2, x21, [sp, #312]
    a604:	97ffec27 	bl	56a0 <fwp_data.part.0.constprop.0>
    a608:	97ffec93 	bl	5854 <fwp_rc_fresh>
    a60c:	aa0003e2 	mov	x2, x0
    a610:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a614:	910523e1 	add	x1, sp, #0x148
    a618:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a61c:	52800020 	mov	w0, #0x1                   	// #1
    a620:	a9148be3 	stp	x3, x2, [sp, #328]
    a624:	97ffec1f 	bl	56a0 <fwp_data.part.0.constprop.0>
    a628:	91174283 	add	x3, x20, #0x5d0
    a62c:	aa0003f5 	mov	x21, x0
    a630:	f949d861 	ldr	x1, [x3, #5040]
    a634:	f949ec60 	ldr	x0, [x3, #5080]
    a638:	cb0102a1 	sub	x1, x21, x1
    a63c:	eb00403f 	cmp	x1, x0, lsl #16
    a640:	54000322 	b.cs	a6a4 <f0+0x564>  // b.hs, b.nlast
    a644:	d350fc22 	lsr	x2, x1, #16
    a648:	f949fc63 	ldr	x3, [x3, #5112]
    a64c:	8b020842 	add	x2, x2, x2, lsl #2
    a650:	d37df042 	lsl	x2, x2, #3
    a654:	8b020060 	add	x0, x3, x2
    a658:	f9401017 	ldr	x23, [x0, #32]
    a65c:	b4000257 	cbz	x23, a6a4 <f0+0x564>
    a660:	38626862 	ldrb	w2, [x3, x2]
    a664:	7100085f 	cmp	w2, #0x2
    a668:	5400f180 	b.eq	c498 <f0+0x2358>  // b.none
    a66c:	7100045f 	cmp	w2, #0x1
    a670:	540001a1 	b.ne	a6a4 <f0+0x564>  // b.any
    a674:	29430002 	ldp	w2, w0, [x0, #24]
    a678:	92403c21 	and	x1, x1, #0xffff
    a67c:	9b027c21 	mul	x1, x1, x2
    a680:	d360fc21 	lsr	x1, x1, #32
    a684:	eb00003f 	cmp	x1, x0
    a688:	540000e2 	b.cs	a6a4 <f0+0x564>  // b.hs, b.nlast
    a68c:	8b0102f7 	add	x23, x23, x1
    a690:	394002e0 	ldrb	w0, [x23]
    a694:	7103fc1f 	cmp	w0, #0xff
    a698:	5400fba0 	b.eq	c60c <f0+0x24cc>  // b.none
    a69c:	52800020 	mov	w0, #0x1                   	// #1
    a6a0:	390002e0 	strb	w0, [x23]
    a6a4:	910563e1 	add	x1, sp, #0x158
    a6a8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a6ac:	52800020 	mov	w0, #0x1                   	// #1
    a6b0:	a915d7e2 	stp	x2, x21, [sp, #344]
    a6b4:	97ffebfb 	bl	56a0 <fwp_data.part.0.constprop.0>
    a6b8:	97ffec67 	bl	5854 <fwp_rc_fresh>
    a6bc:	aa0003e2 	mov	x2, x0
    a6c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a6c4:	9105a3e1 	add	x1, sp, #0x168
    a6c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a6cc:	52800020 	mov	w0, #0x1                   	// #1
    a6d0:	a9168be3 	stp	x3, x2, [sp, #360]
    a6d4:	97ffebf3 	bl	56a0 <fwp_data.part.0.constprop.0>
    a6d8:	91174283 	add	x3, x20, #0x5d0
    a6dc:	aa0003f5 	mov	x21, x0
    a6e0:	f949d861 	ldr	x1, [x3, #5040]
    a6e4:	f949ec60 	ldr	x0, [x3, #5080]
    a6e8:	cb0102a1 	sub	x1, x21, x1
    a6ec:	eb00403f 	cmp	x1, x0, lsl #16
    a6f0:	54000322 	b.cs	a754 <f0+0x614>  // b.hs, b.nlast
    a6f4:	d350fc22 	lsr	x2, x1, #16
    a6f8:	f949fc63 	ldr	x3, [x3, #5112]
    a6fc:	8b020842 	add	x2, x2, x2, lsl #2
    a700:	d37df042 	lsl	x2, x2, #3
    a704:	8b020060 	add	x0, x3, x2
    a708:	f9401017 	ldr	x23, [x0, #32]
    a70c:	b4000257 	cbz	x23, a754 <f0+0x614>
    a710:	38626862 	ldrb	w2, [x3, x2]
    a714:	7100085f 	cmp	w2, #0x2
    a718:	5400eba0 	b.eq	c48c <f0+0x234c>  // b.none
    a71c:	7100045f 	cmp	w2, #0x1
    a720:	540001a1 	b.ne	a754 <f0+0x614>  // b.any
    a724:	29430002 	ldp	w2, w0, [x0, #24]
    a728:	92403c21 	and	x1, x1, #0xffff
    a72c:	9b027c21 	mul	x1, x1, x2
    a730:	d360fc21 	lsr	x1, x1, #32
    a734:	eb00003f 	cmp	x1, x0
    a738:	540000e2 	b.cs	a754 <f0+0x614>  // b.hs, b.nlast
    a73c:	8b0102f7 	add	x23, x23, x1
    a740:	394002e0 	ldrb	w0, [x23]
    a744:	7103fc1f 	cmp	w0, #0xff
    a748:	5400f680 	b.eq	c618 <f0+0x24d8>  // b.none
    a74c:	52800020 	mov	w0, #0x1                   	// #1
    a750:	390002e0 	strb	w0, [x23]
    a754:	9105e3e1 	add	x1, sp, #0x178
    a758:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a75c:	52800020 	mov	w0, #0x1                   	// #1
    a760:	a917d7e2 	stp	x2, x21, [sp, #376]
    a764:	97ffebcf 	bl	56a0 <fwp_data.part.0.constprop.0>
    a768:	97ffec3b 	bl	5854 <fwp_rc_fresh>
    a76c:	aa0003e2 	mov	x2, x0
    a770:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a774:	910623e1 	add	x1, sp, #0x188
    a778:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a77c:	52800020 	mov	w0, #0x1                   	// #1
    a780:	a9188be3 	stp	x3, x2, [sp, #392]
    a784:	97ffebc7 	bl	56a0 <fwp_data.part.0.constprop.0>
    a788:	91174283 	add	x3, x20, #0x5d0
    a78c:	aa0003f5 	mov	x21, x0
    a790:	f949d861 	ldr	x1, [x3, #5040]
    a794:	f949ec60 	ldr	x0, [x3, #5080]
    a798:	cb0102a1 	sub	x1, x21, x1
    a79c:	eb00403f 	cmp	x1, x0, lsl #16
    a7a0:	54000322 	b.cs	a804 <f0+0x6c4>  // b.hs, b.nlast
    a7a4:	d350fc22 	lsr	x2, x1, #16
    a7a8:	f949fc63 	ldr	x3, [x3, #5112]
    a7ac:	8b020842 	add	x2, x2, x2, lsl #2
    a7b0:	d37df042 	lsl	x2, x2, #3
    a7b4:	8b020060 	add	x0, x3, x2
    a7b8:	f9401017 	ldr	x23, [x0, #32]
    a7bc:	b4000257 	cbz	x23, a804 <f0+0x6c4>
    a7c0:	38626862 	ldrb	w2, [x3, x2]
    a7c4:	7100085f 	cmp	w2, #0x2
    a7c8:	5400e5c0 	b.eq	c480 <f0+0x2340>  // b.none
    a7cc:	7100045f 	cmp	w2, #0x1
    a7d0:	540001a1 	b.ne	a804 <f0+0x6c4>  // b.any
    a7d4:	29430002 	ldp	w2, w0, [x0, #24]
    a7d8:	92403c21 	and	x1, x1, #0xffff
    a7dc:	9b027c21 	mul	x1, x1, x2
    a7e0:	d360fc21 	lsr	x1, x1, #32
    a7e4:	eb00003f 	cmp	x1, x0
    a7e8:	540000e2 	b.cs	a804 <f0+0x6c4>  // b.hs, b.nlast
    a7ec:	8b0102f7 	add	x23, x23, x1
    a7f0:	394002e0 	ldrb	w0, [x23]
    a7f4:	7103fc1f 	cmp	w0, #0xff
    a7f8:	5400f160 	b.eq	c624 <f0+0x24e4>  // b.none
    a7fc:	52800020 	mov	w0, #0x1                   	// #1
    a800:	390002e0 	strb	w0, [x23]
    a804:	910663e1 	add	x1, sp, #0x198
    a808:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a80c:	52800020 	mov	w0, #0x1                   	// #1
    a810:	a919d7f7 	stp	x23, x21, [sp, #408]
    a814:	97ffeba3 	bl	56a0 <fwp_data.part.0.constprop.0>
    a818:	97ffec0f 	bl	5854 <fwp_rc_fresh>
    a81c:	aa0003e2 	mov	x2, x0
    a820:	9106a3e1 	add	x1, sp, #0x1a8
    a824:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a828:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a82c:	52800020 	mov	w0, #0x1                   	// #1
    a830:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a834:	97ffeb9b 	bl	56a0 <fwp_data.part.0.constprop.0>
    a838:	97ffec07 	bl	5854 <fwp_rc_fresh>
    a83c:	aa0003e2 	mov	x2, x0
    a840:	9106e3e1 	add	x1, sp, #0x1b8
    a844:	52800020 	mov	w0, #0x1                   	// #1
    a848:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a84c:	97ffeb95 	bl	56a0 <fwp_data.part.0.constprop.0>
    a850:	97ffec01 	bl	5854 <fwp_rc_fresh>
    a854:	aa0003e2 	mov	x2, x0
    a858:	910723e1 	add	x1, sp, #0x1c8
    a85c:	52800020 	mov	w0, #0x1                   	// #1
    a860:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a864:	97ffeb8f 	bl	56a0 <fwp_data.part.0.constprop.0>
    a868:	91174283 	add	x3, x20, #0x5d0
    a86c:	aa0003f5 	mov	x21, x0
    a870:	f949d861 	ldr	x1, [x3, #5040]
    a874:	f949ec60 	ldr	x0, [x3, #5080]
    a878:	cb0102a1 	sub	x1, x21, x1
    a87c:	eb00403f 	cmp	x1, x0, lsl #16
    a880:	54000322 	b.cs	a8e4 <f0+0x7a4>  // b.hs, b.nlast
    a884:	d350fc22 	lsr	x2, x1, #16
    a888:	f949fc63 	ldr	x3, [x3, #5112]
    a88c:	8b020842 	add	x2, x2, x2, lsl #2
    a890:	d37df042 	lsl	x2, x2, #3
    a894:	8b020060 	add	x0, x3, x2
    a898:	f9401017 	ldr	x23, [x0, #32]
    a89c:	b4000257 	cbz	x23, a8e4 <f0+0x7a4>
    a8a0:	38626862 	ldrb	w2, [x3, x2]
    a8a4:	7100085f 	cmp	w2, #0x2
    a8a8:	5400e2e0 	b.eq	c504 <f0+0x23c4>  // b.none
    a8ac:	7100045f 	cmp	w2, #0x1
    a8b0:	540001a1 	b.ne	a8e4 <f0+0x7a4>  // b.any
    a8b4:	29430002 	ldp	w2, w0, [x0, #24]
    a8b8:	92403c21 	and	x1, x1, #0xffff
    a8bc:	9b027c21 	mul	x1, x1, x2
    a8c0:	d360fc21 	lsr	x1, x1, #32
    a8c4:	eb00003f 	cmp	x1, x0
    a8c8:	540000e2 	b.cs	a8e4 <f0+0x7a4>  // b.hs, b.nlast
    a8cc:	8b0102f7 	add	x23, x23, x1
    a8d0:	394002e0 	ldrb	w0, [x23]
    a8d4:	7103fc1f 	cmp	w0, #0xff
    a8d8:	5400eac0 	b.eq	c630 <f0+0x24f0>  // b.none
    a8dc:	52800020 	mov	w0, #0x1                   	// #1
    a8e0:	390002e0 	strb	w0, [x23]
    a8e4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a8e8:	910763e1 	add	x1, sp, #0x1d8
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a8f4:	97ffeb6b 	bl	56a0 <fwp_data.part.0.constprop.0>
    a8f8:	91174283 	add	x3, x20, #0x5d0
    a8fc:	aa0003f5 	mov	x21, x0
    a900:	f949d861 	ldr	x1, [x3, #5040]
    a904:	f949ec60 	ldr	x0, [x3, #5080]
    a908:	cb0102a1 	sub	x1, x21, x1
    a90c:	eb00403f 	cmp	x1, x0, lsl #16
    a910:	54000322 	b.cs	a974 <f0+0x834>  // b.hs, b.nlast
    a914:	d350fc22 	lsr	x2, x1, #16
    a918:	f949fc63 	ldr	x3, [x3, #5112]
    a91c:	8b020842 	add	x2, x2, x2, lsl #2
    a920:	d37df042 	lsl	x2, x2, #3
    a924:	8b020060 	add	x0, x3, x2
    a928:	f9401017 	ldr	x23, [x0, #32]
    a92c:	b4000257 	cbz	x23, a974 <f0+0x834>
    a930:	38626862 	ldrb	w2, [x3, x2]
    a934:	7100085f 	cmp	w2, #0x2
    a938:	5400de00 	b.eq	c4f8 <f0+0x23b8>  // b.none
    a93c:	7100045f 	cmp	w2, #0x1
    a940:	540001a1 	b.ne	a974 <f0+0x834>  // b.any
    a944:	29430002 	ldp	w2, w0, [x0, #24]
    a948:	92403c21 	and	x1, x1, #0xffff
    a94c:	9b027c21 	mul	x1, x1, x2
    a950:	d360fc21 	lsr	x1, x1, #32
    a954:	eb00003f 	cmp	x1, x0
    a958:	540000e2 	b.cs	a974 <f0+0x834>  // b.hs, b.nlast
    a95c:	8b0102f7 	add	x23, x23, x1
    a960:	394002e0 	ldrb	w0, [x23]
    a964:	7103fc1f 	cmp	w0, #0xff
    a968:	5400e6a0 	b.eq	c63c <f0+0x24fc>  // b.none
    a96c:	52800020 	mov	w0, #0x1                   	// #1
    a970:	390002e0 	strb	w0, [x23]
    a974:	9107a3e1 	add	x1, sp, #0x1e8
    a978:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a97c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a980:	52800020 	mov	w0, #0x1                   	// #1
    a984:	a91ed7f7 	stp	x23, x21, [sp, #488]
    a988:	97ffeb46 	bl	56a0 <fwp_data.part.0.constprop.0>
    a98c:	97ffebb2 	bl	5854 <fwp_rc_fresh>
    a990:	aa0003e2 	mov	x2, x0
    a994:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a998:	9107e3e1 	add	x1, sp, #0x1f8
    a99c:	52800020 	mov	w0, #0x1                   	// #1
    a9a0:	a91f8be3 	stp	x3, x2, [sp, #504]
    a9a4:	97ffeb3f 	bl	56a0 <fwp_data.part.0.constprop.0>
    a9a8:	97ffebab 	bl	5854 <fwp_rc_fresh>
    a9ac:	aa0003e2 	mov	x2, x0
    a9b0:	910823e1 	add	x1, sp, #0x208
    a9b4:	52800020 	mov	w0, #0x1                   	// #1
    a9b8:	f90107f7 	str	x23, [sp, #520]
    a9bc:	f9010be2 	str	x2, [sp, #528]
    a9c0:	97ffeb38 	bl	56a0 <fwp_data.part.0.constprop.0>
    a9c4:	91174283 	add	x3, x20, #0x5d0
    a9c8:	aa0003f5 	mov	x21, x0
    a9cc:	f949d861 	ldr	x1, [x3, #5040]
    a9d0:	f949ec60 	ldr	x0, [x3, #5080]
    a9d4:	cb0102a1 	sub	x1, x21, x1
    a9d8:	eb00403f 	cmp	x1, x0, lsl #16
    a9dc:	54000322 	b.cs	aa40 <f0+0x900>  // b.hs, b.nlast
    a9e0:	d350fc22 	lsr	x2, x1, #16
    a9e4:	f949fc63 	ldr	x3, [x3, #5112]
    a9e8:	8b020842 	add	x2, x2, x2, lsl #2
    a9ec:	d37df042 	lsl	x2, x2, #3
    a9f0:	8b020060 	add	x0, x3, x2
    a9f4:	f9401017 	ldr	x23, [x0, #32]
    a9f8:	b4000257 	cbz	x23, aa40 <f0+0x900>
    a9fc:	38626862 	ldrb	w2, [x3, x2]
    aa00:	7100085f 	cmp	w2, #0x2
    aa04:	5400d740 	b.eq	c4ec <f0+0x23ac>  // b.none
    aa08:	7100045f 	cmp	w2, #0x1
    aa0c:	540001a1 	b.ne	aa40 <f0+0x900>  // b.any
    aa10:	29430002 	ldp	w2, w0, [x0, #24]
    aa14:	92403c21 	and	x1, x1, #0xffff
    aa18:	9b027c21 	mul	x1, x1, x2
    aa1c:	d360fc21 	lsr	x1, x1, #32
    aa20:	eb00003f 	cmp	x1, x0
    aa24:	540000e2 	b.cs	aa40 <f0+0x900>  // b.hs, b.nlast
    aa28:	8b0102f7 	add	x23, x23, x1
    aa2c:	394002e0 	ldrb	w0, [x23]
    aa30:	7103fc1f 	cmp	w0, #0xff
    aa34:	5400e0a0 	b.eq	c648 <f0+0x2508>  // b.none
    aa38:	52800020 	mov	w0, #0x1                   	// #1
    aa3c:	390002e0 	strb	w0, [x23]
    aa40:	910863e1 	add	x1, sp, #0x218
    aa44:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aa48:	52800020 	mov	w0, #0x1                   	// #1
    aa4c:	f9010ff7 	str	x23, [sp, #536]
    aa50:	f90113f5 	str	x21, [sp, #544]
    aa54:	97ffeb13 	bl	56a0 <fwp_data.part.0.constprop.0>
    aa58:	97ffeb7f 	bl	5854 <fwp_rc_fresh>
    aa5c:	aa0003e2 	mov	x2, x0
    aa60:	9108a3e1 	add	x1, sp, #0x228
    aa64:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    aa68:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    aa6c:	52800020 	mov	w0, #0x1                   	// #1
    aa70:	f90117f5 	str	x21, [sp, #552]
    aa74:	f9011be2 	str	x2, [sp, #560]
    aa78:	97ffeb0a 	bl	56a0 <fwp_data.part.0.constprop.0>
    aa7c:	97ffeb76 	bl	5854 <fwp_rc_fresh>
    aa80:	aa0003e2 	mov	x2, x0
    aa84:	9108e3e1 	add	x1, sp, #0x238
    aa88:	52800020 	mov	w0, #0x1                   	// #1
    aa8c:	f9011ff7 	str	x23, [sp, #568]
    aa90:	f90123e2 	str	x2, [sp, #576]
    aa94:	97ffeb03 	bl	56a0 <fwp_data.part.0.constprop.0>
    aa98:	97ffeb6f 	bl	5854 <fwp_rc_fresh>
    aa9c:	aa0003e2 	mov	x2, x0
    aaa0:	910923e1 	add	x1, sp, #0x248
    aaa4:	52800020 	mov	w0, #0x1                   	// #1
    aaa8:	f90127f5 	str	x21, [sp, #584]
    aaac:	f9012be2 	str	x2, [sp, #592]
    aab0:	97ffeafc 	bl	56a0 <fwp_data.part.0.constprop.0>
    aab4:	97ffeb68 	bl	5854 <fwp_rc_fresh>
    aab8:	aa0003e2 	mov	x2, x0
    aabc:	910963e1 	add	x1, sp, #0x258
    aac0:	52800020 	mov	w0, #0x1                   	// #1
    aac4:	f9012ff7 	str	x23, [sp, #600]
    aac8:	f90133e2 	str	x2, [sp, #608]
    aacc:	97ffeaf5 	bl	56a0 <fwp_data.part.0.constprop.0>
    aad0:	91174283 	add	x3, x20, #0x5d0
    aad4:	aa0003f5 	mov	x21, x0
    aad8:	f949d861 	ldr	x1, [x3, #5040]
    aadc:	f949ec60 	ldr	x0, [x3, #5080]
    aae0:	cb0102a1 	sub	x1, x21, x1
    aae4:	eb00403f 	cmp	x1, x0, lsl #16
    aae8:	54000322 	b.cs	ab4c <f0+0xa0c>  // b.hs, b.nlast
    aaec:	d350fc22 	lsr	x2, x1, #16
    aaf0:	f949fc63 	ldr	x3, [x3, #5112]
    aaf4:	8b020842 	add	x2, x2, x2, lsl #2
    aaf8:	d37df042 	lsl	x2, x2, #3
    aafc:	8b020060 	add	x0, x3, x2
    ab00:	f9401017 	ldr	x23, [x0, #32]
    ab04:	b4000257 	cbz	x23, ab4c <f0+0xa0c>
    ab08:	38626862 	ldrb	w2, [x3, x2]
    ab0c:	7100085f 	cmp	w2, #0x2
    ab10:	5400ce80 	b.eq	c4e0 <f0+0x23a0>  // b.none
    ab14:	7100045f 	cmp	w2, #0x1
    ab18:	540001a1 	b.ne	ab4c <f0+0xa0c>  // b.any
    ab1c:	29430002 	ldp	w2, w0, [x0, #24]
    ab20:	92403c21 	and	x1, x1, #0xffff
    ab24:	9b027c21 	mul	x1, x1, x2
    ab28:	d360fc21 	lsr	x1, x1, #32
    ab2c:	eb00003f 	cmp	x1, x0
    ab30:	540000e2 	b.cs	ab4c <f0+0xa0c>  // b.hs, b.nlast
    ab34:	8b0102f7 	add	x23, x23, x1
    ab38:	394002e0 	ldrb	w0, [x23]
    ab3c:	7103fc1f 	cmp	w0, #0xff
    ab40:	5400d8a0 	b.eq	c654 <f0+0x2514>  // b.none
    ab44:	52800020 	mov	w0, #0x1                   	// #1
    ab48:	390002e0 	strb	w0, [x23]
    ab4c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ab50:	9109a3e1 	add	x1, sp, #0x268
    ab54:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ab58:	52800020 	mov	w0, #0x1                   	// #1
    ab5c:	f90137e2 	str	x2, [sp, #616]
    ab60:	f9013bf5 	str	x21, [sp, #624]
    ab64:	97ffeacf 	bl	56a0 <fwp_data.part.0.constprop.0>
    ab68:	91174283 	add	x3, x20, #0x5d0
    ab6c:	aa0003f5 	mov	x21, x0
    ab70:	f949d861 	ldr	x1, [x3, #5040]
    ab74:	f949ec60 	ldr	x0, [x3, #5080]
    ab78:	cb0102a1 	sub	x1, x21, x1
    ab7c:	eb00403f 	cmp	x1, x0, lsl #16
    ab80:	54000322 	b.cs	abe4 <f0+0xaa4>  // b.hs, b.nlast
    ab84:	d350fc22 	lsr	x2, x1, #16
    ab88:	f949fc63 	ldr	x3, [x3, #5112]
    ab8c:	8b020842 	add	x2, x2, x2, lsl #2
    ab90:	d37df042 	lsl	x2, x2, #3
    ab94:	8b020060 	add	x0, x3, x2
    ab98:	f9401017 	ldr	x23, [x0, #32]
    ab9c:	b4000257 	cbz	x23, abe4 <f0+0xaa4>
    aba0:	38626862 	ldrb	w2, [x3, x2]
    aba4:	7100085f 	cmp	w2, #0x2
    aba8:	5400c960 	b.eq	c4d4 <f0+0x2394>  // b.none
    abac:	7100045f 	cmp	w2, #0x1
    abb0:	540001a1 	b.ne	abe4 <f0+0xaa4>  // b.any
    abb4:	29430002 	ldp	w2, w0, [x0, #24]
    abb8:	92403c21 	and	x1, x1, #0xffff
    abbc:	9b027c21 	mul	x1, x1, x2
    abc0:	d360fc21 	lsr	x1, x1, #32
    abc4:	eb00003f 	cmp	x1, x0
    abc8:	540000e2 	b.cs	abe4 <f0+0xaa4>  // b.hs, b.nlast
    abcc:	8b0102f7 	add	x23, x23, x1
    abd0:	394002e0 	ldrb	w0, [x23]
    abd4:	7103fc1f 	cmp	w0, #0xff
    abd8:	5400d440 	b.eq	c660 <f0+0x2520>  // b.none
    abdc:	52800020 	mov	w0, #0x1                   	// #1
    abe0:	390002e0 	strb	w0, [x23]
    abe4:	9109e3e1 	add	x1, sp, #0x278
    abe8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    abec:	52800020 	mov	w0, #0x1                   	// #1
    abf0:	f9013fe2 	str	x2, [sp, #632]
    abf4:	f90143f5 	str	x21, [sp, #640]
    abf8:	97ffeaaa 	bl	56a0 <fwp_data.part.0.constprop.0>
    abfc:	97ffeb16 	bl	5854 <fwp_rc_fresh>
    ac00:	aa0003e2 	mov	x2, x0
    ac04:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac08:	910a23e1 	add	x1, sp, #0x288
    ac0c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac10:	52800020 	mov	w0, #0x1                   	// #1
    ac14:	f90147e3 	str	x3, [sp, #648]
    ac18:	f9014be2 	str	x2, [sp, #656]
    ac1c:	97ffeaa1 	bl	56a0 <fwp_data.part.0.constprop.0>
    ac20:	91174283 	add	x3, x20, #0x5d0
    ac24:	aa0003f5 	mov	x21, x0
    ac28:	f949d861 	ldr	x1, [x3, #5040]
    ac2c:	f949ec60 	ldr	x0, [x3, #5080]
    ac30:	cb0102a1 	sub	x1, x21, x1
    ac34:	eb00403f 	cmp	x1, x0, lsl #16
    ac38:	54000322 	b.cs	ac9c <f0+0xb5c>  // b.hs, b.nlast
    ac3c:	d350fc22 	lsr	x2, x1, #16
    ac40:	f949fc63 	ldr	x3, [x3, #5112]
    ac44:	8b020842 	add	x2, x2, x2, lsl #2
    ac48:	d37df042 	lsl	x2, x2, #3
    ac4c:	8b020060 	add	x0, x3, x2
    ac50:	f9401017 	ldr	x23, [x0, #32]
    ac54:	b4000257 	cbz	x23, ac9c <f0+0xb5c>
    ac58:	38626862 	ldrb	w2, [x3, x2]
    ac5c:	7100085f 	cmp	w2, #0x2
    ac60:	5400c340 	b.eq	c4c8 <f0+0x2388>  // b.none
    ac64:	7100045f 	cmp	w2, #0x1
    ac68:	540001a1 	b.ne	ac9c <f0+0xb5c>  // b.any
    ac6c:	29430002 	ldp	w2, w0, [x0, #24]
    ac70:	92403c21 	and	x1, x1, #0xffff
    ac74:	9b027c21 	mul	x1, x1, x2
    ac78:	d360fc21 	lsr	x1, x1, #32
    ac7c:	eb00003f 	cmp	x1, x0
    ac80:	540000e2 	b.cs	ac9c <f0+0xb5c>  // b.hs, b.nlast
    ac84:	8b0102f7 	add	x23, x23, x1
    ac88:	394002e0 	ldrb	w0, [x23]
    ac8c:	7103fc1f 	cmp	w0, #0xff
    ac90:	5400cee0 	b.eq	c66c <f0+0x252c>  // b.none
    ac94:	52800020 	mov	w0, #0x1                   	// #1
    ac98:	390002e0 	strb	w0, [x23]
    ac9c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aca0:	910a63e1 	add	x1, sp, #0x298
    aca4:	52800020 	mov	w0, #0x1                   	// #1
    aca8:	f9014fe2 	str	x2, [sp, #664]
    acac:	f90153f5 	str	x21, [sp, #672]
    acb0:	97ffea7c 	bl	56a0 <fwp_data.part.0.constprop.0>
    acb4:	91174283 	add	x3, x20, #0x5d0
    acb8:	aa0003f5 	mov	x21, x0
    acbc:	f949d861 	ldr	x1, [x3, #5040]
    acc0:	f949ec60 	ldr	x0, [x3, #5080]
    acc4:	cb0102a1 	sub	x1, x21, x1
    acc8:	eb00403f 	cmp	x1, x0, lsl #16
    accc:	54000322 	b.cs	ad30 <f0+0xbf0>  // b.hs, b.nlast
    acd0:	d350fc22 	lsr	x2, x1, #16
    acd4:	f949fc63 	ldr	x3, [x3, #5112]
    acd8:	8b020842 	add	x2, x2, x2, lsl #2
    acdc:	d37df042 	lsl	x2, x2, #3
    ace0:	8b020060 	add	x0, x3, x2
    ace4:	f9401017 	ldr	x23, [x0, #32]
    ace8:	b4000257 	cbz	x23, ad30 <f0+0xbf0>
    acec:	38626862 	ldrb	w2, [x3, x2]
    acf0:	7100085f 	cmp	w2, #0x2
    acf4:	5400be40 	b.eq	c4bc <f0+0x237c>  // b.none
    acf8:	7100045f 	cmp	w2, #0x1
    acfc:	540001a1 	b.ne	ad30 <f0+0xbf0>  // b.any
    ad00:	29430002 	ldp	w2, w0, [x0, #24]
    ad04:	92403c21 	and	x1, x1, #0xffff
    ad08:	9b027c21 	mul	x1, x1, x2
    ad0c:	d360fc21 	lsr	x1, x1, #32
    ad10:	eb00003f 	cmp	x1, x0
    ad14:	540000e2 	b.cs	ad30 <f0+0xbf0>  // b.hs, b.nlast
    ad18:	8b0102f7 	add	x23, x23, x1
    ad1c:	394002e0 	ldrb	w0, [x23]
    ad20:	7103fc1f 	cmp	w0, #0xff
    ad24:	5400caa0 	b.eq	c678 <f0+0x2538>  // b.none
    ad28:	52800020 	mov	w0, #0x1                   	// #1
    ad2c:	390002e0 	strb	w0, [x23]
    ad30:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad34:	910aa3e1 	add	x1, sp, #0x2a8
    ad38:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad3c:	52800020 	mov	w0, #0x1                   	// #1
    ad40:	f90157e2 	str	x2, [sp, #680]
    ad44:	f9015bf5 	str	x21, [sp, #688]
    ad48:	97ffea56 	bl	56a0 <fwp_data.part.0.constprop.0>
    ad4c:	91174283 	add	x3, x20, #0x5d0
    ad50:	aa0003f5 	mov	x21, x0
    ad54:	f949d861 	ldr	x1, [x3, #5040]
    ad58:	f949ec60 	ldr	x0, [x3, #5080]
    ad5c:	cb0102a1 	sub	x1, x21, x1
    ad60:	eb00403f 	cmp	x1, x0, lsl #16
    ad64:	54000322 	b.cs	adc8 <f0+0xc88>  // b.hs, b.nlast
    ad68:	d350fc22 	lsr	x2, x1, #16
    ad6c:	f949fc63 	ldr	x3, [x3, #5112]
    ad70:	8b020842 	add	x2, x2, x2, lsl #2
    ad74:	d37df042 	lsl	x2, x2, #3
    ad78:	8b020060 	add	x0, x3, x2
    ad7c:	f9401017 	ldr	x23, [x0, #32]
    ad80:	b4000257 	cbz	x23, adc8 <f0+0xc88>
    ad84:	38626862 	ldrb	w2, [x3, x2]
    ad88:	7100085f 	cmp	w2, #0x2
    ad8c:	5400b920 	b.eq	c4b0 <f0+0x2370>  // b.none
    ad90:	7100045f 	cmp	w2, #0x1
    ad94:	540001a1 	b.ne	adc8 <f0+0xc88>  // b.any
    ad98:	29430002 	ldp	w2, w0, [x0, #24]
    ad9c:	92403c21 	and	x1, x1, #0xffff
    ada0:	9b027c21 	mul	x1, x1, x2
    ada4:	d360fc21 	lsr	x1, x1, #32
    ada8:	eb00003f 	cmp	x1, x0
    adac:	540000e2 	b.cs	adc8 <f0+0xc88>  // b.hs, b.nlast
    adb0:	8b0102f7 	add	x23, x23, x1
    adb4:	394002e0 	ldrb	w0, [x23]
    adb8:	7103fc1f 	cmp	w0, #0xff
    adbc:	5400c640 	b.eq	c684 <f0+0x2544>  // b.none
    adc0:	52800020 	mov	w0, #0x1                   	// #1
    adc4:	390002e0 	strb	w0, [x23]
    adc8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    adcc:	910ae3e1 	add	x1, sp, #0x2b8
    add0:	52800020 	mov	w0, #0x1                   	// #1
    add4:	f9015fe2 	str	x2, [sp, #696]
    add8:	f90163f5 	str	x21, [sp, #704]
    addc:	97ffea31 	bl	56a0 <fwp_data.part.0.constprop.0>
    ade0:	91174283 	add	x3, x20, #0x5d0
    ade4:	aa0003f5 	mov	x21, x0
    ade8:	f949d861 	ldr	x1, [x3, #5040]
    adec:	f949ec60 	ldr	x0, [x3, #5080]
    adf0:	cb0102a1 	sub	x1, x21, x1
    adf4:	eb00403f 	cmp	x1, x0, lsl #16
    adf8:	54000322 	b.cs	ae5c <f0+0xd1c>  // b.hs, b.nlast
    adfc:	d350fc22 	lsr	x2, x1, #16
    ae00:	f949fc63 	ldr	x3, [x3, #5112]
    ae04:	8b020842 	add	x2, x2, x2, lsl #2
    ae08:	d37df042 	lsl	x2, x2, #3
    ae0c:	8b020060 	add	x0, x3, x2
    ae10:	f9401017 	ldr	x23, [x0, #32]
    ae14:	b4000257 	cbz	x23, ae5c <f0+0xd1c>
    ae18:	38626862 	ldrb	w2, [x3, x2]
    ae1c:	7100085f 	cmp	w2, #0x2
    ae20:	5400b180 	b.eq	c450 <f0+0x2310>  // b.none
    ae24:	7100045f 	cmp	w2, #0x1
    ae28:	540001a1 	b.ne	ae5c <f0+0xd1c>  // b.any
    ae2c:	29430002 	ldp	w2, w0, [x0, #24]
    ae30:	92403c21 	and	x1, x1, #0xffff
    ae34:	9b027c21 	mul	x1, x1, x2
    ae38:	d360fc21 	lsr	x1, x1, #32
    ae3c:	eb00003f 	cmp	x1, x0
    ae40:	540000e2 	b.cs	ae5c <f0+0xd1c>  // b.hs, b.nlast
    ae44:	8b0102f7 	add	x23, x23, x1
    ae48:	394002e0 	ldrb	w0, [x23]
    ae4c:	7103fc1f 	cmp	w0, #0xff
    ae50:	5400c200 	b.eq	c690 <f0+0x2550>  // b.none
    ae54:	52800020 	mov	w0, #0x1                   	// #1
    ae58:	390002e0 	strb	w0, [x23]
    ae5c:	910b23e1 	add	x1, sp, #0x2c8
    ae60:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae64:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae68:	52800020 	mov	w0, #0x1                   	// #1
    ae6c:	f90167f7 	str	x23, [sp, #712]
    ae70:	f9016bf5 	str	x21, [sp, #720]
    ae74:	97ffea0b 	bl	56a0 <fwp_data.part.0.constprop.0>
    ae78:	97ffea77 	bl	5854 <fwp_rc_fresh>
    ae7c:	aa0003e2 	mov	x2, x0
    ae80:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae84:	910b63e1 	add	x1, sp, #0x2d8
    ae88:	52800020 	mov	w0, #0x1                   	// #1
    ae8c:	f9016fe3 	str	x3, [sp, #728]
    ae90:	f90173e2 	str	x2, [sp, #736]
    ae94:	97ffea03 	bl	56a0 <fwp_data.part.0.constprop.0>
    ae98:	97ffea6f 	bl	5854 <fwp_rc_fresh>
    ae9c:	aa0003e2 	mov	x2, x0
    aea0:	910ba3e1 	add	x1, sp, #0x2e8
    aea4:	52800020 	mov	w0, #0x1                   	// #1
    aea8:	f90177f7 	str	x23, [sp, #744]
    aeac:	f9017be2 	str	x2, [sp, #752]
    aeb0:	97ffe9fc 	bl	56a0 <fwp_data.part.0.constprop.0>
    aeb4:	91174283 	add	x3, x20, #0x5d0
    aeb8:	aa0003f5 	mov	x21, x0
    aebc:	f949d861 	ldr	x1, [x3, #5040]
    aec0:	f949ec60 	ldr	x0, [x3, #5080]
    aec4:	cb0102a1 	sub	x1, x21, x1
    aec8:	eb00403f 	cmp	x1, x0, lsl #16
    aecc:	54000322 	b.cs	af30 <f0+0xdf0>  // b.hs, b.nlast
    aed0:	d350fc22 	lsr	x2, x1, #16
    aed4:	f949fc63 	ldr	x3, [x3, #5112]
    aed8:	8b020842 	add	x2, x2, x2, lsl #2
    aedc:	d37df042 	lsl	x2, x2, #3
    aee0:	8b020060 	add	x0, x3, x2
    aee4:	f9401017 	ldr	x23, [x0, #32]
    aee8:	b4000257 	cbz	x23, af30 <f0+0xdf0>
    aeec:	38626862 	ldrb	w2, [x3, x2]
    aef0:	7100085f 	cmp	w2, #0x2
    aef4:	5400aa80 	b.eq	c444 <f0+0x2304>  // b.none
    aef8:	7100045f 	cmp	w2, #0x1
    aefc:	540001a1 	b.ne	af30 <f0+0xdf0>  // b.any
    af00:	29430002 	ldp	w2, w0, [x0, #24]
    af04:	92403c21 	and	x1, x1, #0xffff
    af08:	9b027c21 	mul	x1, x1, x2
    af0c:	d360fc21 	lsr	x1, x1, #32
    af10:	eb00003f 	cmp	x1, x0
    af14:	540000e2 	b.cs	af30 <f0+0xdf0>  // b.hs, b.nlast
    af18:	8b0102f7 	add	x23, x23, x1
    af1c:	394002e0 	ldrb	w0, [x23]
    af20:	7103fc1f 	cmp	w0, #0xff
    af24:	5400bbc0 	b.eq	c69c <f0+0x255c>  // b.none
    af28:	52800020 	mov	w0, #0x1                   	// #1
    af2c:	390002e0 	strb	w0, [x23]
    af30:	910be3e1 	add	x1, sp, #0x2f8
    af34:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af38:	52800020 	mov	w0, #0x1                   	// #1
    af3c:	f9017ff7 	str	x23, [sp, #760]
    af40:	f90183f5 	str	x21, [sp, #768]
    af44:	97ffe9d7 	bl	56a0 <fwp_data.part.0.constprop.0>
    af48:	97ffea43 	bl	5854 <fwp_rc_fresh>
    af4c:	aa0003e2 	mov	x2, x0
    af50:	910c23e1 	add	x1, sp, #0x308
    af54:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    af58:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    af5c:	52800020 	mov	w0, #0x1                   	// #1
    af60:	f90187f5 	str	x21, [sp, #776]
    af64:	f9018be2 	str	x2, [sp, #784]
    af68:	97ffe9ce 	bl	56a0 <fwp_data.part.0.constprop.0>
    af6c:	97ffea3a 	bl	5854 <fwp_rc_fresh>
    af70:	aa0003e2 	mov	x2, x0
    af74:	910c63e1 	add	x1, sp, #0x318
    af78:	52800020 	mov	w0, #0x1                   	// #1
    af7c:	f9018ff7 	str	x23, [sp, #792]
    af80:	f90193e2 	str	x2, [sp, #800]
    af84:	97ffe9c7 	bl	56a0 <fwp_data.part.0.constprop.0>
    af88:	97ffea33 	bl	5854 <fwp_rc_fresh>
    af8c:	aa0003e2 	mov	x2, x0
    af90:	910ca3e1 	add	x1, sp, #0x328
    af94:	52800020 	mov	w0, #0x1                   	// #1
    af98:	f90197f5 	str	x21, [sp, #808]
    af9c:	f9019be2 	str	x2, [sp, #816]
    afa0:	97ffe9c0 	bl	56a0 <fwp_data.part.0.constprop.0>
    afa4:	97ffea2c 	bl	5854 <fwp_rc_fresh>
    afa8:	aa0003e2 	mov	x2, x0
    afac:	910ce3e1 	add	x1, sp, #0x338
    afb0:	52800020 	mov	w0, #0x1                   	// #1
    afb4:	f9019ff7 	str	x23, [sp, #824]
    afb8:	f901a3e2 	str	x2, [sp, #832]
    afbc:	97ffe9b9 	bl	56a0 <fwp_data.part.0.constprop.0>
    afc0:	97ffea25 	bl	5854 <fwp_rc_fresh>
    afc4:	aa0003e2 	mov	x2, x0
    afc8:	910d23e1 	add	x1, sp, #0x348
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f901a7f5 	str	x21, [sp, #840]
    afd4:	f901abe2 	str	x2, [sp, #848]
    afd8:	97ffe9b2 	bl	56a0 <fwp_data.part.0.constprop.0>
    afdc:	97ffea1e 	bl	5854 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	910d63e1 	add	x1, sp, #0x358
    afe8:	52800020 	mov	w0, #0x1                   	// #1
    afec:	f901aff7 	str	x23, [sp, #856]
    aff0:	f901b3e2 	str	x2, [sp, #864]
    aff4:	97ffe9ab 	bl	56a0 <fwp_data.part.0.constprop.0>
    aff8:	97ffea17 	bl	5854 <fwp_rc_fresh>
    affc:	aa0003e2 	mov	x2, x0
    b000:	910da3e1 	add	x1, sp, #0x368
    b004:	52800020 	mov	w0, #0x1                   	// #1
    b008:	f901b7f5 	str	x21, [sp, #872]
    b00c:	f901bbe2 	str	x2, [sp, #880]
    b010:	97ffe9a4 	bl	56a0 <fwp_data.part.0.constprop.0>
    b014:	97ffea10 	bl	5854 <fwp_rc_fresh>
    b018:	aa0003e2 	mov	x2, x0
    b01c:	910de3e1 	add	x1, sp, #0x378
    b020:	52800020 	mov	w0, #0x1                   	// #1
    b024:	f901bff7 	str	x23, [sp, #888]
    b028:	f901c3e2 	str	x2, [sp, #896]
    b02c:	97ffe99d 	bl	56a0 <fwp_data.part.0.constprop.0>
    b030:	97ffea09 	bl	5854 <fwp_rc_fresh>
    b034:	aa0003e2 	mov	x2, x0
    b038:	910e23e1 	add	x1, sp, #0x388
    b03c:	52800020 	mov	w0, #0x1                   	// #1
    b040:	f901c7f5 	str	x21, [sp, #904]
    b044:	f901cbe2 	str	x2, [sp, #912]
    b048:	97ffe996 	bl	56a0 <fwp_data.part.0.constprop.0>
    b04c:	97ffea02 	bl	5854 <fwp_rc_fresh>
    b050:	aa0003e2 	mov	x2, x0
    b054:	910e63e1 	add	x1, sp, #0x398
    b058:	52800020 	mov	w0, #0x1                   	// #1
    b05c:	f901cff7 	str	x23, [sp, #920]
    b060:	f901d3e2 	str	x2, [sp, #928]
    b064:	97ffe98f 	bl	56a0 <fwp_data.part.0.constprop.0>
    b068:	97ffe9fb 	bl	5854 <fwp_rc_fresh>
    b06c:	aa0003e2 	mov	x2, x0
    b070:	910ea3e1 	add	x1, sp, #0x3a8
    b074:	52800020 	mov	w0, #0x1                   	// #1
    b078:	f901d7f5 	str	x21, [sp, #936]
    b07c:	f901dbe2 	str	x2, [sp, #944]
    b080:	97ffe988 	bl	56a0 <fwp_data.part.0.constprop.0>
    b084:	91174283 	add	x3, x20, #0x5d0
    b088:	aa0003f5 	mov	x21, x0
    b08c:	f949d861 	ldr	x1, [x3, #5040]
    b090:	f949ec60 	ldr	x0, [x3, #5080]
    b094:	cb0102a1 	sub	x1, x21, x1
    b098:	eb00403f 	cmp	x1, x0, lsl #16
    b09c:	54000322 	b.cs	b100 <f0+0xfc0>  // b.hs, b.nlast
    b0a0:	d350fc22 	lsr	x2, x1, #16
    b0a4:	f949fc63 	ldr	x3, [x3, #5112]
    b0a8:	8b020842 	add	x2, x2, x2, lsl #2
    b0ac:	d37df042 	lsl	x2, x2, #3
    b0b0:	8b020060 	add	x0, x3, x2
    b0b4:	f9401017 	ldr	x23, [x0, #32]
    b0b8:	b4000257 	cbz	x23, b100 <f0+0xfc0>
    b0bc:	38626862 	ldrb	w2, [x3, x2]
    b0c0:	7100085f 	cmp	w2, #0x2
    b0c4:	54009ba0 	b.eq	c438 <f0+0x22f8>  // b.none
    b0c8:	7100045f 	cmp	w2, #0x1
    b0cc:	540001a1 	b.ne	b100 <f0+0xfc0>  // b.any
    b0d0:	29430002 	ldp	w2, w0, [x0, #24]
    b0d4:	92403c21 	and	x1, x1, #0xffff
    b0d8:	9b027c21 	mul	x1, x1, x2
    b0dc:	d360fc21 	lsr	x1, x1, #32
    b0e0:	eb00003f 	cmp	x1, x0
    b0e4:	540000e2 	b.cs	b100 <f0+0xfc0>  // b.hs, b.nlast
    b0e8:	8b0102f7 	add	x23, x23, x1
    b0ec:	394002e0 	ldrb	w0, [x23]
    b0f0:	7103fc1f 	cmp	w0, #0xff
    b0f4:	5400ada0 	b.eq	c6a8 <f0+0x2568>  // b.none
    b0f8:	52800020 	mov	w0, #0x1                   	// #1
    b0fc:	390002e0 	strb	w0, [x23]
    b100:	910ee3e1 	add	x1, sp, #0x3b8
    b104:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b108:	52800020 	mov	w0, #0x1                   	// #1
    b10c:	f901dff7 	str	x23, [sp, #952]
    b110:	f901e3f5 	str	x21, [sp, #960]
    b114:	97ffe963 	bl	56a0 <fwp_data.part.0.constprop.0>
    b118:	97ffe9cf 	bl	5854 <fwp_rc_fresh>
    b11c:	aa0003e2 	mov	x2, x0
    b120:	910f23e1 	add	x1, sp, #0x3c8
    b124:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b128:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b12c:	52800020 	mov	w0, #0x1                   	// #1
    b130:	f901e7f5 	str	x21, [sp, #968]
    b134:	f901ebe2 	str	x2, [sp, #976]
    b138:	97ffe95a 	bl	56a0 <fwp_data.part.0.constprop.0>
    b13c:	97ffe9c6 	bl	5854 <fwp_rc_fresh>
    b140:	aa0003e2 	mov	x2, x0
    b144:	910f63e1 	add	x1, sp, #0x3d8
    b148:	52800020 	mov	w0, #0x1                   	// #1
    b14c:	f901eff7 	str	x23, [sp, #984]
    b150:	f901f3e2 	str	x2, [sp, #992]
    b154:	97ffe953 	bl	56a0 <fwp_data.part.0.constprop.0>
    b158:	97ffe9bf 	bl	5854 <fwp_rc_fresh>
    b15c:	aa0003e2 	mov	x2, x0
    b160:	910fa3e1 	add	x1, sp, #0x3e8
    b164:	52800020 	mov	w0, #0x1                   	// #1
    b168:	f901f7f5 	str	x21, [sp, #1000]
    b16c:	f901fbe2 	str	x2, [sp, #1008]
    b170:	97ffe94c 	bl	56a0 <fwp_data.part.0.constprop.0>
    b174:	91174283 	add	x3, x20, #0x5d0
    b178:	aa0003f5 	mov	x21, x0
    b17c:	f949d861 	ldr	x1, [x3, #5040]
    b180:	f949ec60 	ldr	x0, [x3, #5080]
    b184:	cb0102a1 	sub	x1, x21, x1
    b188:	eb00403f 	cmp	x1, x0, lsl #16
    b18c:	54000322 	b.cs	b1f0 <f0+0x10b0>  // b.hs, b.nlast
    b190:	d350fc22 	lsr	x2, x1, #16
    b194:	f949fc63 	ldr	x3, [x3, #5112]
    b198:	8b020842 	add	x2, x2, x2, lsl #2
    b19c:	d37df042 	lsl	x2, x2, #3
    b1a0:	8b020060 	add	x0, x3, x2
    b1a4:	f9401017 	ldr	x23, [x0, #32]
    b1a8:	b4000257 	cbz	x23, b1f0 <f0+0x10b0>
    b1ac:	38626862 	ldrb	w2, [x3, x2]
    b1b0:	7100085f 	cmp	w2, #0x2
    b1b4:	540093c0 	b.eq	c42c <f0+0x22ec>  // b.none
    b1b8:	7100045f 	cmp	w2, #0x1
    b1bc:	540001a1 	b.ne	b1f0 <f0+0x10b0>  // b.any
    b1c0:	29430002 	ldp	w2, w0, [x0, #24]
    b1c4:	92403c21 	and	x1, x1, #0xffff
    b1c8:	9b027c21 	mul	x1, x1, x2
    b1cc:	d360fc21 	lsr	x1, x1, #32
    b1d0:	eb00003f 	cmp	x1, x0
    b1d4:	540000e2 	b.cs	b1f0 <f0+0x10b0>  // b.hs, b.nlast
    b1d8:	8b0102f7 	add	x23, x23, x1
    b1dc:	394002e0 	ldrb	w0, [x23]
    b1e0:	7103fc1f 	cmp	w0, #0xff
    b1e4:	5400a680 	b.eq	c6b4 <f0+0x2574>  // b.none
    b1e8:	52800020 	mov	w0, #0x1                   	// #1
    b1ec:	390002e0 	strb	w0, [x23]
    b1f0:	910fe3e1 	add	x1, sp, #0x3f8
    b1f4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b1f8:	52800020 	mov	w0, #0x1                   	// #1
    b1fc:	f901fff7 	str	x23, [sp, #1016]
    b200:	f90203f5 	str	x21, [sp, #1024]
    b204:	97ffe927 	bl	56a0 <fwp_data.part.0.constprop.0>
    b208:	97ffe993 	bl	5854 <fwp_rc_fresh>
    b20c:	aa0003e2 	mov	x2, x0
    b210:	911023e1 	add	x1, sp, #0x408
    b214:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b218:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b21c:	52800020 	mov	w0, #0x1                   	// #1
    b220:	f90207f5 	str	x21, [sp, #1032]
    b224:	f9020be2 	str	x2, [sp, #1040]
    b228:	97ffe91e 	bl	56a0 <fwp_data.part.0.constprop.0>
    b22c:	97ffe98a 	bl	5854 <fwp_rc_fresh>
    b230:	aa0003e2 	mov	x2, x0
    b234:	911063e1 	add	x1, sp, #0x418
    b238:	52800020 	mov	w0, #0x1                   	// #1
    b23c:	f9020ff7 	str	x23, [sp, #1048]
    b240:	f90213e2 	str	x2, [sp, #1056]
    b244:	97ffe917 	bl	56a0 <fwp_data.part.0.constprop.0>
    b248:	97ffe983 	bl	5854 <fwp_rc_fresh>
    b24c:	aa0003e2 	mov	x2, x0
    b250:	9110a3e1 	add	x1, sp, #0x428
    b254:	52800020 	mov	w0, #0x1                   	// #1
    b258:	f90217f5 	str	x21, [sp, #1064]
    b25c:	f9021be2 	str	x2, [sp, #1072]
    b260:	97ffe910 	bl	56a0 <fwp_data.part.0.constprop.0>
    b264:	91174283 	add	x3, x20, #0x5d0
    b268:	aa0003f5 	mov	x21, x0
    b26c:	f949d861 	ldr	x1, [x3, #5040]
    b270:	f949ec60 	ldr	x0, [x3, #5080]
    b274:	cb0102a1 	sub	x1, x21, x1
    b278:	eb00403f 	cmp	x1, x0, lsl #16
    b27c:	54000322 	b.cs	b2e0 <f0+0x11a0>  // b.hs, b.nlast
    b280:	d350fc22 	lsr	x2, x1, #16
    b284:	f949fc63 	ldr	x3, [x3, #5112]
    b288:	8b020842 	add	x2, x2, x2, lsl #2
    b28c:	d37df042 	lsl	x2, x2, #3
    b290:	8b020060 	add	x0, x3, x2
    b294:	f9401017 	ldr	x23, [x0, #32]
    b298:	b4000257 	cbz	x23, b2e0 <f0+0x11a0>
    b29c:	38626862 	ldrb	w2, [x3, x2]
    b2a0:	7100085f 	cmp	w2, #0x2
    b2a4:	54008be0 	b.eq	c420 <f0+0x22e0>  // b.none
    b2a8:	7100045f 	cmp	w2, #0x1
    b2ac:	540001a1 	b.ne	b2e0 <f0+0x11a0>  // b.any
    b2b0:	29430002 	ldp	w2, w0, [x0, #24]
    b2b4:	92403c21 	and	x1, x1, #0xffff
    b2b8:	9b027c21 	mul	x1, x1, x2
    b2bc:	d360fc21 	lsr	x1, x1, #32
    b2c0:	eb00003f 	cmp	x1, x0
    b2c4:	540000e2 	b.cs	b2e0 <f0+0x11a0>  // b.hs, b.nlast
    b2c8:	8b0102f7 	add	x23, x23, x1
    b2cc:	394002e0 	ldrb	w0, [x23]
    b2d0:	7103fc1f 	cmp	w0, #0xff
    b2d4:	54009f60 	b.eq	c6c0 <f0+0x2580>  // b.none
    b2d8:	52800020 	mov	w0, #0x1                   	// #1
    b2dc:	390002e0 	strb	w0, [x23]
    b2e0:	9110e3e1 	add	x1, sp, #0x438
    b2e4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b2e8:	52800020 	mov	w0, #0x1                   	// #1
    b2ec:	f9021ff7 	str	x23, [sp, #1080]
    b2f0:	f90223f5 	str	x21, [sp, #1088]
    b2f4:	97ffe8eb 	bl	56a0 <fwp_data.part.0.constprop.0>
    b2f8:	97ffe957 	bl	5854 <fwp_rc_fresh>
    b2fc:	aa0003e2 	mov	x2, x0
    b300:	911123e1 	add	x1, sp, #0x448
    b304:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b308:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b30c:	52800020 	mov	w0, #0x1                   	// #1
    b310:	f90227f5 	str	x21, [sp, #1096]
    b314:	f9022be2 	str	x2, [sp, #1104]
    b318:	97ffe8e2 	bl	56a0 <fwp_data.part.0.constprop.0>
    b31c:	97ffe94e 	bl	5854 <fwp_rc_fresh>
    b320:	aa0003e2 	mov	x2, x0
    b324:	911163e1 	add	x1, sp, #0x458
    b328:	52800020 	mov	w0, #0x1                   	// #1
    b32c:	f9022ff7 	str	x23, [sp, #1112]
    b330:	f90233e2 	str	x2, [sp, #1120]
    b334:	97ffe8db 	bl	56a0 <fwp_data.part.0.constprop.0>
    b338:	97ffe947 	bl	5854 <fwp_rc_fresh>
    b33c:	aa0003e2 	mov	x2, x0
    b340:	9111a3e1 	add	x1, sp, #0x468
    b344:	52800020 	mov	w0, #0x1                   	// #1
    b348:	f90237f5 	str	x21, [sp, #1128]
    b34c:	f9023be2 	str	x2, [sp, #1136]
    b350:	97ffe8d4 	bl	56a0 <fwp_data.part.0.constprop.0>
    b354:	91174283 	add	x3, x20, #0x5d0
    b358:	aa0003f5 	mov	x21, x0
    b35c:	f949d861 	ldr	x1, [x3, #5040]
    b360:	f949ec60 	ldr	x0, [x3, #5080]
    b364:	cb0102a1 	sub	x1, x21, x1
    b368:	eb00403f 	cmp	x1, x0, lsl #16
    b36c:	54000322 	b.cs	b3d0 <f0+0x1290>  // b.hs, b.nlast
    b370:	d350fc22 	lsr	x2, x1, #16
    b374:	f949fc63 	ldr	x3, [x3, #5112]
    b378:	8b020842 	add	x2, x2, x2, lsl #2
    b37c:	d37df042 	lsl	x2, x2, #3
    b380:	8b020060 	add	x0, x3, x2
    b384:	f9401017 	ldr	x23, [x0, #32]
    b388:	b4000257 	cbz	x23, b3d0 <f0+0x1290>
    b38c:	38626862 	ldrb	w2, [x3, x2]
    b390:	7100085f 	cmp	w2, #0x2
    b394:	54008400 	b.eq	c414 <f0+0x22d4>  // b.none
    b398:	7100045f 	cmp	w2, #0x1
    b39c:	540001a1 	b.ne	b3d0 <f0+0x1290>  // b.any
    b3a0:	29430002 	ldp	w2, w0, [x0, #24]
    b3a4:	92403c21 	and	x1, x1, #0xffff
    b3a8:	9b027c21 	mul	x1, x1, x2
    b3ac:	d360fc21 	lsr	x1, x1, #32
    b3b0:	eb00003f 	cmp	x1, x0
    b3b4:	540000e2 	b.cs	b3d0 <f0+0x1290>  // b.hs, b.nlast
    b3b8:	8b0102f7 	add	x23, x23, x1
    b3bc:	394002e0 	ldrb	w0, [x23]
    b3c0:	7103fc1f 	cmp	w0, #0xff
    b3c4:	54009840 	b.eq	c6cc <f0+0x258c>  // b.none
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	390002e0 	strb	w0, [x23]
    b3d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b3d4:	9111e3e1 	add	x1, sp, #0x478
    b3d8:	52800020 	mov	w0, #0x1                   	// #1
    b3dc:	f9023fe2 	str	x2, [sp, #1144]
    b3e0:	f90243f5 	str	x21, [sp, #1152]
    b3e4:	97ffe8af 	bl	56a0 <fwp_data.part.0.constprop.0>
    b3e8:	91174283 	add	x3, x20, #0x5d0
    b3ec:	aa0003f5 	mov	x21, x0
    b3f0:	f949d861 	ldr	x1, [x3, #5040]
    b3f4:	f949ec60 	ldr	x0, [x3, #5080]
    b3f8:	cb0102a1 	sub	x1, x21, x1
    b3fc:	eb00403f 	cmp	x1, x0, lsl #16
    b400:	54000322 	b.cs	b464 <f0+0x1324>  // b.hs, b.nlast
    b404:	d350fc22 	lsr	x2, x1, #16
    b408:	f949fc63 	ldr	x3, [x3, #5112]
    b40c:	8b020842 	add	x2, x2, x2, lsl #2
    b410:	d37df042 	lsl	x2, x2, #3
    b414:	8b020060 	add	x0, x3, x2
    b418:	f9401017 	ldr	x23, [x0, #32]
    b41c:	b4000257 	cbz	x23, b464 <f0+0x1324>
    b420:	38626862 	ldrb	w2, [x3, x2]
    b424:	7100085f 	cmp	w2, #0x2
    b428:	54007f00 	b.eq	c408 <f0+0x22c8>  // b.none
    b42c:	7100045f 	cmp	w2, #0x1
    b430:	540001a1 	b.ne	b464 <f0+0x1324>  // b.any
    b434:	29430002 	ldp	w2, w0, [x0, #24]
    b438:	92403c21 	and	x1, x1, #0xffff
    b43c:	9b027c21 	mul	x1, x1, x2
    b440:	d360fc21 	lsr	x1, x1, #32
    b444:	eb00003f 	cmp	x1, x0
    b448:	540000e2 	b.cs	b464 <f0+0x1324>  // b.hs, b.nlast
    b44c:	8b0102f7 	add	x23, x23, x1
    b450:	394002e0 	ldrb	w0, [x23]
    b454:	7103fc1f 	cmp	w0, #0xff
    b458:	54009400 	b.eq	c6d8 <f0+0x2598>  // b.none
    b45c:	52800020 	mov	w0, #0x1                   	// #1
    b460:	390002e0 	strb	w0, [x23]
    b464:	911223e1 	add	x1, sp, #0x488
    b468:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b46c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b470:	52800020 	mov	w0, #0x1                   	// #1
    b474:	f90247f7 	str	x23, [sp, #1160]
    b478:	f9024bf5 	str	x21, [sp, #1168]
    b47c:	97ffe889 	bl	56a0 <fwp_data.part.0.constprop.0>
    b480:	97ffe8f5 	bl	5854 <fwp_rc_fresh>
    b484:	aa0003e2 	mov	x2, x0
    b488:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b48c:	911263e1 	add	x1, sp, #0x498
    b490:	52800020 	mov	w0, #0x1                   	// #1
    b494:	f9024fe3 	str	x3, [sp, #1176]
    b498:	f90253e2 	str	x2, [sp, #1184]
    b49c:	97ffe881 	bl	56a0 <fwp_data.part.0.constprop.0>
    b4a0:	97ffe8ed 	bl	5854 <fwp_rc_fresh>
    b4a4:	aa0003e2 	mov	x2, x0
    b4a8:	9112a3e1 	add	x1, sp, #0x4a8
    b4ac:	52800020 	mov	w0, #0x1                   	// #1
    b4b0:	f90257f7 	str	x23, [sp, #1192]
    b4b4:	f9025be2 	str	x2, [sp, #1200]
    b4b8:	97ffe87a 	bl	56a0 <fwp_data.part.0.constprop.0>
    b4bc:	91174283 	add	x3, x20, #0x5d0
    b4c0:	aa0003f5 	mov	x21, x0
    b4c4:	f949d861 	ldr	x1, [x3, #5040]
    b4c8:	f949ec60 	ldr	x0, [x3, #5080]
    b4cc:	cb0102a1 	sub	x1, x21, x1
    b4d0:	eb00403f 	cmp	x1, x0, lsl #16
    b4d4:	54000322 	b.cs	b538 <f0+0x13f8>  // b.hs, b.nlast
    b4d8:	d350fc22 	lsr	x2, x1, #16
    b4dc:	f949fc63 	ldr	x3, [x3, #5112]
    b4e0:	8b020842 	add	x2, x2, x2, lsl #2
    b4e4:	d37df042 	lsl	x2, x2, #3
    b4e8:	8b020060 	add	x0, x3, x2
    b4ec:	f9401017 	ldr	x23, [x0, #32]
    b4f0:	b4000257 	cbz	x23, b538 <f0+0x13f8>
    b4f4:	38626862 	ldrb	w2, [x3, x2]
    b4f8:	7100085f 	cmp	w2, #0x2
    b4fc:	54007800 	b.eq	c3fc <f0+0x22bc>  // b.none
    b500:	7100045f 	cmp	w2, #0x1
    b504:	540001a1 	b.ne	b538 <f0+0x13f8>  // b.any
    b508:	29430002 	ldp	w2, w0, [x0, #24]
    b50c:	92403c21 	and	x1, x1, #0xffff
    b510:	9b027c21 	mul	x1, x1, x2
    b514:	d360fc21 	lsr	x1, x1, #32
    b518:	eb00003f 	cmp	x1, x0
    b51c:	540000e2 	b.cs	b538 <f0+0x13f8>  // b.hs, b.nlast
    b520:	8b0102f7 	add	x23, x23, x1
    b524:	394002e0 	ldrb	w0, [x23]
    b528:	7103fc1f 	cmp	w0, #0xff
    b52c:	54008dc0 	b.eq	c6e4 <f0+0x25a4>  // b.none
    b530:	52800020 	mov	w0, #0x1                   	// #1
    b534:	390002e0 	strb	w0, [x23]
    b538:	9112e3e1 	add	x1, sp, #0x4b8
    b53c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b540:	52800020 	mov	w0, #0x1                   	// #1
    b544:	f9025ff7 	str	x23, [sp, #1208]
    b548:	f90263f5 	str	x21, [sp, #1216]
    b54c:	97ffe855 	bl	56a0 <fwp_data.part.0.constprop.0>
    b550:	97ffe8c1 	bl	5854 <fwp_rc_fresh>
    b554:	aa0003e2 	mov	x2, x0
    b558:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b55c:	911323e1 	add	x1, sp, #0x4c8
    b560:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b564:	52800020 	mov	w0, #0x1                   	// #1
    b568:	f90267e3 	str	x3, [sp, #1224]
    b56c:	f9026be2 	str	x2, [sp, #1232]
    b570:	97ffe84c 	bl	56a0 <fwp_data.part.0.constprop.0>
    b574:	97ffe8b8 	bl	5854 <fwp_rc_fresh>
    b578:	aa0003e2 	mov	x2, x0
    b57c:	911363e1 	add	x1, sp, #0x4d8
    b580:	52800020 	mov	w0, #0x1                   	// #1
    b584:	f9026ff7 	str	x23, [sp, #1240]
    b588:	f90273e2 	str	x2, [sp, #1248]
    b58c:	97ffe845 	bl	56a0 <fwp_data.part.0.constprop.0>
    b590:	91174283 	add	x3, x20, #0x5d0
    b594:	aa0003f5 	mov	x21, x0
    b598:	f949d861 	ldr	x1, [x3, #5040]
    b59c:	f949ec60 	ldr	x0, [x3, #5080]
    b5a0:	cb0102a1 	sub	x1, x21, x1
    b5a4:	eb00403f 	cmp	x1, x0, lsl #16
    b5a8:	54000322 	b.cs	b60c <f0+0x14cc>  // b.hs, b.nlast
    b5ac:	d350fc22 	lsr	x2, x1, #16
    b5b0:	f949fc63 	ldr	x3, [x3, #5112]
    b5b4:	8b020842 	add	x2, x2, x2, lsl #2
    b5b8:	d37df042 	lsl	x2, x2, #3
    b5bc:	8b020060 	add	x0, x3, x2
    b5c0:	f9401017 	ldr	x23, [x0, #32]
    b5c4:	b4000257 	cbz	x23, b60c <f0+0x14cc>
    b5c8:	38626862 	ldrb	w2, [x3, x2]
    b5cc:	7100085f 	cmp	w2, #0x2
    b5d0:	54007fa0 	b.eq	c5c4 <f0+0x2484>  // b.none
    b5d4:	7100045f 	cmp	w2, #0x1
    b5d8:	540001a1 	b.ne	b60c <f0+0x14cc>  // b.any
    b5dc:	29430002 	ldp	w2, w0, [x0, #24]
    b5e0:	92403c21 	and	x1, x1, #0xffff
    b5e4:	9b027c21 	mul	x1, x1, x2
    b5e8:	d360fc21 	lsr	x1, x1, #32
    b5ec:	eb00003f 	cmp	x1, x0
    b5f0:	540000e2 	b.cs	b60c <f0+0x14cc>  // b.hs, b.nlast
    b5f4:	8b0102f7 	add	x23, x23, x1
    b5f8:	394002e0 	ldrb	w0, [x23]
    b5fc:	7103fc1f 	cmp	w0, #0xff
    b600:	54008780 	b.eq	c6f0 <f0+0x25b0>  // b.none
    b604:	52800020 	mov	w0, #0x1                   	// #1
    b608:	390002e0 	strb	w0, [x23]
    b60c:	9113a3e1 	add	x1, sp, #0x4e8
    b610:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b614:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b618:	52800020 	mov	w0, #0x1                   	// #1
    b61c:	f90277f7 	str	x23, [sp, #1256]
    b620:	f9027bf5 	str	x21, [sp, #1264]
    b624:	97ffe81f 	bl	56a0 <fwp_data.part.0.constprop.0>
    b628:	97ffe88b 	bl	5854 <fwp_rc_fresh>
    b62c:	aa0003e2 	mov	x2, x0
    b630:	9113e3e1 	add	x1, sp, #0x4f8
    b634:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b638:	52800020 	mov	w0, #0x1                   	// #1
    b63c:	f9027ff5 	str	x21, [sp, #1272]
    b640:	f90283e2 	str	x2, [sp, #1280]
    b644:	97ffe817 	bl	56a0 <fwp_data.part.0.constprop.0>
    b648:	97ffe883 	bl	5854 <fwp_rc_fresh>
    b64c:	aa0003e2 	mov	x2, x0
    b650:	911423e1 	add	x1, sp, #0x508
    b654:	52800020 	mov	w0, #0x1                   	// #1
    b658:	f90287f7 	str	x23, [sp, #1288]
    b65c:	f9028be2 	str	x2, [sp, #1296]
    b660:	97ffe810 	bl	56a0 <fwp_data.part.0.constprop.0>
    b664:	97ffe87c 	bl	5854 <fwp_rc_fresh>
    b668:	aa0003e2 	mov	x2, x0
    b66c:	911463e1 	add	x1, sp, #0x518
    b670:	52800020 	mov	w0, #0x1                   	// #1
    b674:	f9028ff5 	str	x21, [sp, #1304]
    b678:	f90293e2 	str	x2, [sp, #1312]
    b67c:	97ffe809 	bl	56a0 <fwp_data.part.0.constprop.0>
    b680:	97ffe875 	bl	5854 <fwp_rc_fresh>
    b684:	aa0003e2 	mov	x2, x0
    b688:	9114a3e1 	add	x1, sp, #0x528
    b68c:	52800020 	mov	w0, #0x1                   	// #1
    b690:	f90297f7 	str	x23, [sp, #1320]
    b694:	f9029be2 	str	x2, [sp, #1328]
    b698:	97ffe802 	bl	56a0 <fwp_data.part.0.constprop.0>
    b69c:	91174283 	add	x3, x20, #0x5d0
    b6a0:	aa0003f5 	mov	x21, x0
    b6a4:	f949d861 	ldr	x1, [x3, #5040]
    b6a8:	f949ec60 	ldr	x0, [x3, #5080]
    b6ac:	cb0102a1 	sub	x1, x21, x1
    b6b0:	eb00403f 	cmp	x1, x0, lsl #16
    b6b4:	54000322 	b.cs	b718 <f0+0x15d8>  // b.hs, b.nlast
    b6b8:	d350fc22 	lsr	x2, x1, #16
    b6bc:	f949fc63 	ldr	x3, [x3, #5112]
    b6c0:	8b020842 	add	x2, x2, x2, lsl #2
    b6c4:	d37df042 	lsl	x2, x2, #3
    b6c8:	8b020060 	add	x0, x3, x2
    b6cc:	f9401017 	ldr	x23, [x0, #32]
    b6d0:	b4000257 	cbz	x23, b718 <f0+0x15d8>
    b6d4:	38626862 	ldrb	w2, [x3, x2]
    b6d8:	7100085f 	cmp	w2, #0x2
    b6dc:	540076e0 	b.eq	c5b8 <f0+0x2478>  // b.none
    b6e0:	7100045f 	cmp	w2, #0x1
    b6e4:	540001a1 	b.ne	b718 <f0+0x15d8>  // b.any
    b6e8:	29430002 	ldp	w2, w0, [x0, #24]
    b6ec:	92403c21 	and	x1, x1, #0xffff
    b6f0:	9b027c21 	mul	x1, x1, x2
    b6f4:	d360fc21 	lsr	x1, x1, #32
    b6f8:	eb00003f 	cmp	x1, x0
    b6fc:	540000e2 	b.cs	b718 <f0+0x15d8>  // b.hs, b.nlast
    b700:	8b0102f7 	add	x23, x23, x1
    b704:	394002e0 	ldrb	w0, [x23]
    b708:	7103fc1f 	cmp	w0, #0xff
    b70c:	54007f80 	b.eq	c6fc <f0+0x25bc>  // b.none
    b710:	52800020 	mov	w0, #0x1                   	// #1
    b714:	390002e0 	strb	w0, [x23]
    b718:	9114e3e1 	add	x1, sp, #0x538
    b71c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b720:	52800020 	mov	w0, #0x1                   	// #1
    b724:	f9029ff7 	str	x23, [sp, #1336]
    b728:	f902a3f5 	str	x21, [sp, #1344]
    b72c:	97ffe7dd 	bl	56a0 <fwp_data.part.0.constprop.0>
    b730:	97ffe849 	bl	5854 <fwp_rc_fresh>
    b734:	aa0003e2 	mov	x2, x0
    b738:	911523e1 	add	x1, sp, #0x548
    b73c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b740:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b744:	52800020 	mov	w0, #0x1                   	// #1
    b748:	f902a7f5 	str	x21, [sp, #1352]
    b74c:	f902abe2 	str	x2, [sp, #1360]
    b750:	97ffe7d4 	bl	56a0 <fwp_data.part.0.constprop.0>
    b754:	97ffe840 	bl	5854 <fwp_rc_fresh>
    b758:	aa0003e2 	mov	x2, x0
    b75c:	911563e1 	add	x1, sp, #0x558
    b760:	52800020 	mov	w0, #0x1                   	// #1
    b764:	f902aff7 	str	x23, [sp, #1368]
    b768:	f902b3e2 	str	x2, [sp, #1376]
    b76c:	97ffe7cd 	bl	56a0 <fwp_data.part.0.constprop.0>
    b770:	97ffe839 	bl	5854 <fwp_rc_fresh>
    b774:	aa0003e2 	mov	x2, x0
    b778:	9115a3e1 	add	x1, sp, #0x568
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f902b7f5 	str	x21, [sp, #1384]
    b784:	f902bbe2 	str	x2, [sp, #1392]
    b788:	97ffe7c6 	bl	56a0 <fwp_data.part.0.constprop.0>
    b78c:	97ffe832 	bl	5854 <fwp_rc_fresh>
    b790:	aa0003e2 	mov	x2, x0
    b794:	9115e3e1 	add	x1, sp, #0x578
    b798:	52800020 	mov	w0, #0x1                   	// #1
    b79c:	f902bff7 	str	x23, [sp, #1400]
    b7a0:	f902c3e2 	str	x2, [sp, #1408]
    b7a4:	97ffe7bf 	bl	56a0 <fwp_data.part.0.constprop.0>
    b7a8:	97ffe82b 	bl	5854 <fwp_rc_fresh>
    b7ac:	aa0003e2 	mov	x2, x0
    b7b0:	911623e1 	add	x1, sp, #0x588
    b7b4:	52800020 	mov	w0, #0x1                   	// #1
    b7b8:	f902c7f5 	str	x21, [sp, #1416]
    b7bc:	f902cbe2 	str	x2, [sp, #1424]
    b7c0:	97ffe7b8 	bl	56a0 <fwp_data.part.0.constprop.0>
    b7c4:	97ffe824 	bl	5854 <fwp_rc_fresh>
    b7c8:	aa0003e2 	mov	x2, x0
    b7cc:	911663e1 	add	x1, sp, #0x598
    b7d0:	52800020 	mov	w0, #0x1                   	// #1
    b7d4:	f902cff7 	str	x23, [sp, #1432]
    b7d8:	f902d3e2 	str	x2, [sp, #1440]
    b7dc:	97ffe7b1 	bl	56a0 <fwp_data.part.0.constprop.0>
    b7e0:	97ffe81d 	bl	5854 <fwp_rc_fresh>
    b7e4:	aa0003e2 	mov	x2, x0
    b7e8:	9116a3e1 	add	x1, sp, #0x5a8
    b7ec:	52800020 	mov	w0, #0x1                   	// #1
    b7f0:	f902d7f5 	str	x21, [sp, #1448]
    b7f4:	f902dbe2 	str	x2, [sp, #1456]
    b7f8:	97ffe7aa 	bl	56a0 <fwp_data.part.0.constprop.0>
    b7fc:	91174283 	add	x3, x20, #0x5d0
    b800:	aa0003f5 	mov	x21, x0
    b804:	f949d861 	ldr	x1, [x3, #5040]
    b808:	f949ec60 	ldr	x0, [x3, #5080]
    b80c:	cb0102a1 	sub	x1, x21, x1
    b810:	eb00403f 	cmp	x1, x0, lsl #16
    b814:	54000322 	b.cs	b878 <f0+0x1738>  // b.hs, b.nlast
    b818:	d350fc22 	lsr	x2, x1, #16
    b81c:	f949fc63 	ldr	x3, [x3, #5112]
    b820:	8b020842 	add	x2, x2, x2, lsl #2
    b824:	d37df042 	lsl	x2, x2, #3
    b828:	8b020060 	add	x0, x3, x2
    b82c:	f9401017 	ldr	x23, [x0, #32]
    b830:	b4000257 	cbz	x23, b878 <f0+0x1738>
    b834:	38626862 	ldrb	w2, [x3, x2]
    b838:	7100085f 	cmp	w2, #0x2
    b83c:	54006b80 	b.eq	c5ac <f0+0x246c>  // b.none
    b840:	7100045f 	cmp	w2, #0x1
    b844:	540001a1 	b.ne	b878 <f0+0x1738>  // b.any
    b848:	29430002 	ldp	w2, w0, [x0, #24]
    b84c:	92403c21 	and	x1, x1, #0xffff
    b850:	9b027c21 	mul	x1, x1, x2
    b854:	d360fc21 	lsr	x1, x1, #32
    b858:	eb00003f 	cmp	x1, x0
    b85c:	540000e2 	b.cs	b878 <f0+0x1738>  // b.hs, b.nlast
    b860:	8b0102f7 	add	x23, x23, x1
    b864:	394002e0 	ldrb	w0, [x23]
    b868:	7103fc1f 	cmp	w0, #0xff
    b86c:	540074e0 	b.eq	c708 <f0+0x25c8>  // b.none
    b870:	52800020 	mov	w0, #0x1                   	// #1
    b874:	390002e0 	strb	w0, [x23]
    b878:	9116e3e1 	add	x1, sp, #0x5b8
    b87c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b880:	52800020 	mov	w0, #0x1                   	// #1
    b884:	f902dff7 	str	x23, [sp, #1464]
    b888:	f902e3f5 	str	x21, [sp, #1472]
    b88c:	97ffe785 	bl	56a0 <fwp_data.part.0.constprop.0>
    b890:	97ffe7f1 	bl	5854 <fwp_rc_fresh>
    b894:	aa0003e2 	mov	x2, x0
    b898:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b89c:	911723e1 	add	x1, sp, #0x5c8
    b8a0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b8a4:	52800020 	mov	w0, #0x1                   	// #1
    b8a8:	f902e7e3 	str	x3, [sp, #1480]
    b8ac:	f902ebe2 	str	x2, [sp, #1488]
    b8b0:	97ffe77c 	bl	56a0 <fwp_data.part.0.constprop.0>
    b8b4:	97ffe7e8 	bl	5854 <fwp_rc_fresh>
    b8b8:	aa0003e2 	mov	x2, x0
    b8bc:	911763e1 	add	x1, sp, #0x5d8
    b8c0:	52800020 	mov	w0, #0x1                   	// #1
    b8c4:	f902eff7 	str	x23, [sp, #1496]
    b8c8:	f902f3e2 	str	x2, [sp, #1504]
    b8cc:	97ffe775 	bl	56a0 <fwp_data.part.0.constprop.0>
    b8d0:	91174283 	add	x3, x20, #0x5d0
    b8d4:	aa0003f5 	mov	x21, x0
    b8d8:	f949d861 	ldr	x1, [x3, #5040]
    b8dc:	f949ec60 	ldr	x0, [x3, #5080]
    b8e0:	cb0102a1 	sub	x1, x21, x1
    b8e4:	eb00403f 	cmp	x1, x0, lsl #16
    b8e8:	54000322 	b.cs	b94c <f0+0x180c>  // b.hs, b.nlast
    b8ec:	d350fc22 	lsr	x2, x1, #16
    b8f0:	f949fc63 	ldr	x3, [x3, #5112]
    b8f4:	8b020842 	add	x2, x2, x2, lsl #2
    b8f8:	d37df042 	lsl	x2, x2, #3
    b8fc:	8b020060 	add	x0, x3, x2
    b900:	f9401017 	ldr	x23, [x0, #32]
    b904:	b4000257 	cbz	x23, b94c <f0+0x180c>
    b908:	38626862 	ldrb	w2, [x3, x2]
    b90c:	7100085f 	cmp	w2, #0x2
    b910:	54006480 	b.eq	c5a0 <f0+0x2460>  // b.none
    b914:	7100045f 	cmp	w2, #0x1
    b918:	540001a1 	b.ne	b94c <f0+0x180c>  // b.any
    b91c:	29430002 	ldp	w2, w0, [x0, #24]
    b920:	92403c21 	and	x1, x1, #0xffff
    b924:	9b027c21 	mul	x1, x1, x2
    b928:	d360fc21 	lsr	x1, x1, #32
    b92c:	eb00003f 	cmp	x1, x0
    b930:	540000e2 	b.cs	b94c <f0+0x180c>  // b.hs, b.nlast
    b934:	8b0102f7 	add	x23, x23, x1
    b938:	394002e0 	ldrb	w0, [x23]
    b93c:	7103fc1f 	cmp	w0, #0xff
    b940:	54006ea0 	b.eq	c714 <f0+0x25d4>  // b.none
    b944:	52800020 	mov	w0, #0x1                   	// #1
    b948:	390002e0 	strb	w0, [x23]
    b94c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b950:	9117a3e1 	add	x1, sp, #0x5e8
    b954:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	f902f7e2 	str	x2, [sp, #1512]
    b960:	f902fbf5 	str	x21, [sp, #1520]
    b964:	97ffe74f 	bl	56a0 <fwp_data.part.0.constprop.0>
    b968:	91174283 	add	x3, x20, #0x5d0
    b96c:	aa0003f5 	mov	x21, x0
    b970:	f949d861 	ldr	x1, [x3, #5040]
    b974:	f949ec60 	ldr	x0, [x3, #5080]
    b978:	cb0102a1 	sub	x1, x21, x1
    b97c:	eb00403f 	cmp	x1, x0, lsl #16
    b980:	54000322 	b.cs	b9e4 <f0+0x18a4>  // b.hs, b.nlast
    b984:	d350fc22 	lsr	x2, x1, #16
    b988:	f949fc63 	ldr	x3, [x3, #5112]
    b98c:	8b020842 	add	x2, x2, x2, lsl #2
    b990:	d37df042 	lsl	x2, x2, #3
    b994:	8b020060 	add	x0, x3, x2
    b998:	f9401017 	ldr	x23, [x0, #32]
    b99c:	b4000257 	cbz	x23, b9e4 <f0+0x18a4>
    b9a0:	38626862 	ldrb	w2, [x3, x2]
    b9a4:	7100085f 	cmp	w2, #0x2
    b9a8:	54005f60 	b.eq	c594 <f0+0x2454>  // b.none
    b9ac:	7100045f 	cmp	w2, #0x1
    b9b0:	540001a1 	b.ne	b9e4 <f0+0x18a4>  // b.any
    b9b4:	29430002 	ldp	w2, w0, [x0, #24]
    b9b8:	92403c21 	and	x1, x1, #0xffff
    b9bc:	9b027c21 	mul	x1, x1, x2
    b9c0:	d360fc21 	lsr	x1, x1, #32
    b9c4:	eb00003f 	cmp	x1, x0
    b9c8:	540000e2 	b.cs	b9e4 <f0+0x18a4>  // b.hs, b.nlast
    b9cc:	8b0102f7 	add	x23, x23, x1
    b9d0:	394002e0 	ldrb	w0, [x23]
    b9d4:	7103fc1f 	cmp	w0, #0xff
    b9d8:	54006a40 	b.eq	c720 <f0+0x25e0>  // b.none
    b9dc:	52800020 	mov	w0, #0x1                   	// #1
    b9e0:	390002e0 	strb	w0, [x23]
    b9e4:	9117e3e1 	add	x1, sp, #0x5f8
    b9e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b9ec:	52800020 	mov	w0, #0x1                   	// #1
    b9f0:	f902fff7 	str	x23, [sp, #1528]
    b9f4:	f90303f5 	str	x21, [sp, #1536]
    b9f8:	97ffe72a 	bl	56a0 <fwp_data.part.0.constprop.0>
    b9fc:	97ffe796 	bl	5854 <fwp_rc_fresh>
    ba00:	aa0003e2 	mov	x2, x0
    ba04:	911823e1 	add	x1, sp, #0x608
    ba08:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ba0c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ba10:	52800020 	mov	w0, #0x1                   	// #1
    ba14:	f90307f5 	str	x21, [sp, #1544]
    ba18:	f9030be2 	str	x2, [sp, #1552]
    ba1c:	97ffe721 	bl	56a0 <fwp_data.part.0.constprop.0>
    ba20:	97ffe78d 	bl	5854 <fwp_rc_fresh>
    ba24:	aa0003e2 	mov	x2, x0
    ba28:	911863e1 	add	x1, sp, #0x618
    ba2c:	52800020 	mov	w0, #0x1                   	// #1
    ba30:	f9030ff7 	str	x23, [sp, #1560]
    ba34:	f90313e2 	str	x2, [sp, #1568]
    ba38:	97ffe71a 	bl	56a0 <fwp_data.part.0.constprop.0>
    ba3c:	97ffe786 	bl	5854 <fwp_rc_fresh>
    ba40:	aa0003e2 	mov	x2, x0
    ba44:	9118a3e1 	add	x1, sp, #0x628
    ba48:	52800020 	mov	w0, #0x1                   	// #1
    ba4c:	f90317f5 	str	x21, [sp, #1576]
    ba50:	f9031be2 	str	x2, [sp, #1584]
    ba54:	97ffe713 	bl	56a0 <fwp_data.part.0.constprop.0>
    ba58:	97ffe77f 	bl	5854 <fwp_rc_fresh>
    ba5c:	aa0003e2 	mov	x2, x0
    ba60:	9118e3e1 	add	x1, sp, #0x638
    ba64:	52800020 	mov	w0, #0x1                   	// #1
    ba68:	f9031ff7 	str	x23, [sp, #1592]
    ba6c:	f90323e2 	str	x2, [sp, #1600]
    ba70:	97ffe70c 	bl	56a0 <fwp_data.part.0.constprop.0>
    ba74:	97ffe778 	bl	5854 <fwp_rc_fresh>
    ba78:	aa0003e2 	mov	x2, x0
    ba7c:	911923e1 	add	x1, sp, #0x648
    ba80:	52800020 	mov	w0, #0x1                   	// #1
    ba84:	f90327f5 	str	x21, [sp, #1608]
    ba88:	f9032be2 	str	x2, [sp, #1616]
    ba8c:	97ffe705 	bl	56a0 <fwp_data.part.0.constprop.0>
    ba90:	97ffe771 	bl	5854 <fwp_rc_fresh>
    ba94:	aa0003e2 	mov	x2, x0
    ba98:	911963e1 	add	x1, sp, #0x658
    ba9c:	52800020 	mov	w0, #0x1                   	// #1
    baa0:	f9032ff7 	str	x23, [sp, #1624]
    baa4:	f90333e2 	str	x2, [sp, #1632]
    baa8:	97ffe6fe 	bl	56a0 <fwp_data.part.0.constprop.0>
    baac:	97ffe76a 	bl	5854 <fwp_rc_fresh>
    bab0:	aa0003e2 	mov	x2, x0
    bab4:	9119a3e1 	add	x1, sp, #0x668
    bab8:	52800020 	mov	w0, #0x1                   	// #1
    babc:	f90337f5 	str	x21, [sp, #1640]
    bac0:	f9033be2 	str	x2, [sp, #1648]
    bac4:	97ffe6f7 	bl	56a0 <fwp_data.part.0.constprop.0>
    bac8:	91174283 	add	x3, x20, #0x5d0
    bacc:	aa0003f5 	mov	x21, x0
    bad0:	f949d861 	ldr	x1, [x3, #5040]
    bad4:	f949ec60 	ldr	x0, [x3, #5080]
    bad8:	cb0102a1 	sub	x1, x21, x1
    badc:	eb00403f 	cmp	x1, x0, lsl #16
    bae0:	54000322 	b.cs	bb44 <f0+0x1a04>  // b.hs, b.nlast
    bae4:	d350fc22 	lsr	x2, x1, #16
    bae8:	f949fc63 	ldr	x3, [x3, #5112]
    baec:	8b020842 	add	x2, x2, x2, lsl #2
    baf0:	d37df042 	lsl	x2, x2, #3
    baf4:	8b020060 	add	x0, x3, x2
    baf8:	f9401017 	ldr	x23, [x0, #32]
    bafc:	b4000257 	cbz	x23, bb44 <f0+0x1a04>
    bb00:	38626862 	ldrb	w2, [x3, x2]
    bb04:	7100085f 	cmp	w2, #0x2
    bb08:	54005400 	b.eq	c588 <f0+0x2448>  // b.none
    bb0c:	7100045f 	cmp	w2, #0x1
    bb10:	540001a1 	b.ne	bb44 <f0+0x1a04>  // b.any
    bb14:	29430002 	ldp	w2, w0, [x0, #24]
    bb18:	92403c21 	and	x1, x1, #0xffff
    bb1c:	9b027c21 	mul	x1, x1, x2
    bb20:	d360fc21 	lsr	x1, x1, #32
    bb24:	eb00003f 	cmp	x1, x0
    bb28:	540000e2 	b.cs	bb44 <f0+0x1a04>  // b.hs, b.nlast
    bb2c:	8b0102f7 	add	x23, x23, x1
    bb30:	394002e0 	ldrb	w0, [x23]
    bb34:	7103fc1f 	cmp	w0, #0xff
    bb38:	54005fa0 	b.eq	c72c <f0+0x25ec>  // b.none
    bb3c:	52800020 	mov	w0, #0x1                   	// #1
    bb40:	390002e0 	strb	w0, [x23]
    bb44:	9119e3e1 	add	x1, sp, #0x678
    bb48:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb4c:	52800020 	mov	w0, #0x1                   	// #1
    bb50:	f9033fe2 	str	x2, [sp, #1656]
    bb54:	f90343f5 	str	x21, [sp, #1664]
    bb58:	97ffe6d2 	bl	56a0 <fwp_data.part.0.constprop.0>
    bb5c:	97ffe73e 	bl	5854 <fwp_rc_fresh>
    bb60:	aa0003e2 	mov	x2, x0
    bb64:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bb68:	911a23e1 	add	x1, sp, #0x688
    bb6c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bb70:	52800020 	mov	w0, #0x1                   	// #1
    bb74:	f90347e3 	str	x3, [sp, #1672]
    bb78:	f9034be2 	str	x2, [sp, #1680]
    bb7c:	97ffe6c9 	bl	56a0 <fwp_data.part.0.constprop.0>
    bb80:	91174283 	add	x3, x20, #0x5d0
    bb84:	aa0003f5 	mov	x21, x0
    bb88:	f949d861 	ldr	x1, [x3, #5040]
    bb8c:	f949ec60 	ldr	x0, [x3, #5080]
    bb90:	cb0102a1 	sub	x1, x21, x1
    bb94:	eb00403f 	cmp	x1, x0, lsl #16
    bb98:	54000322 	b.cs	bbfc <f0+0x1abc>  // b.hs, b.nlast
    bb9c:	d350fc22 	lsr	x2, x1, #16
    bba0:	f949fc63 	ldr	x3, [x3, #5112]
    bba4:	8b020842 	add	x2, x2, x2, lsl #2
    bba8:	d37df042 	lsl	x2, x2, #3
    bbac:	8b020060 	add	x0, x3, x2
    bbb0:	f9401017 	ldr	x23, [x0, #32]
    bbb4:	b4000257 	cbz	x23, bbfc <f0+0x1abc>
    bbb8:	38626862 	ldrb	w2, [x3, x2]
    bbbc:	7100085f 	cmp	w2, #0x2
    bbc0:	54004de0 	b.eq	c57c <f0+0x243c>  // b.none
    bbc4:	7100045f 	cmp	w2, #0x1
    bbc8:	540001a1 	b.ne	bbfc <f0+0x1abc>  // b.any
    bbcc:	29430002 	ldp	w2, w0, [x0, #24]
    bbd0:	92403c21 	and	x1, x1, #0xffff
    bbd4:	9b027c21 	mul	x1, x1, x2
    bbd8:	d360fc21 	lsr	x1, x1, #32
    bbdc:	eb00003f 	cmp	x1, x0
    bbe0:	540000e2 	b.cs	bbfc <f0+0x1abc>  // b.hs, b.nlast
    bbe4:	8b0102f7 	add	x23, x23, x1
    bbe8:	394002e0 	ldrb	w0, [x23]
    bbec:	7103fc1f 	cmp	w0, #0xff
    bbf0:	54005a40 	b.eq	c738 <f0+0x25f8>  // b.none
    bbf4:	52800020 	mov	w0, #0x1                   	// #1
    bbf8:	390002e0 	strb	w0, [x23]
    bbfc:	911a63e1 	add	x1, sp, #0x698
    bc00:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc04:	52800020 	mov	w0, #0x1                   	// #1
    bc08:	f9034fe2 	str	x2, [sp, #1688]
    bc0c:	f90353f5 	str	x21, [sp, #1696]
    bc10:	97ffe6a4 	bl	56a0 <fwp_data.part.0.constprop.0>
    bc14:	97ffe710 	bl	5854 <fwp_rc_fresh>
    bc18:	aa0003e2 	mov	x2, x0
    bc1c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bc20:	911aa3e1 	add	x1, sp, #0x6a8
    bc24:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bc28:	52800020 	mov	w0, #0x1                   	// #1
    bc2c:	f90357e3 	str	x3, [sp, #1704]
    bc30:	f9035be2 	str	x2, [sp, #1712]
    bc34:	97ffe69b 	bl	56a0 <fwp_data.part.0.constprop.0>
    bc38:	91174283 	add	x3, x20, #0x5d0
    bc3c:	aa0003f5 	mov	x21, x0
    bc40:	f949d861 	ldr	x1, [x3, #5040]
    bc44:	f949ec60 	ldr	x0, [x3, #5080]
    bc48:	cb0102a1 	sub	x1, x21, x1
    bc4c:	eb00403f 	cmp	x1, x0, lsl #16
    bc50:	54000322 	b.cs	bcb4 <f0+0x1b74>  // b.hs, b.nlast
    bc54:	d350fc22 	lsr	x2, x1, #16
    bc58:	f949fc63 	ldr	x3, [x3, #5112]
    bc5c:	8b020842 	add	x2, x2, x2, lsl #2
    bc60:	d37df042 	lsl	x2, x2, #3
    bc64:	8b020060 	add	x0, x3, x2
    bc68:	f9401017 	ldr	x23, [x0, #32]
    bc6c:	b4000257 	cbz	x23, bcb4 <f0+0x1b74>
    bc70:	38626862 	ldrb	w2, [x3, x2]
    bc74:	7100085f 	cmp	w2, #0x2
    bc78:	540047c0 	b.eq	c570 <f0+0x2430>  // b.none
    bc7c:	7100045f 	cmp	w2, #0x1
    bc80:	540001a1 	b.ne	bcb4 <f0+0x1b74>  // b.any
    bc84:	29430002 	ldp	w2, w0, [x0, #24]
    bc88:	92403c21 	and	x1, x1, #0xffff
    bc8c:	9b027c21 	mul	x1, x1, x2
    bc90:	d360fc21 	lsr	x1, x1, #32
    bc94:	eb00003f 	cmp	x1, x0
    bc98:	540000e2 	b.cs	bcb4 <f0+0x1b74>  // b.hs, b.nlast
    bc9c:	8b0102f7 	add	x23, x23, x1
    bca0:	394002e0 	ldrb	w0, [x23]
    bca4:	7103fc1f 	cmp	w0, #0xff
    bca8:	540054e0 	b.eq	c744 <f0+0x2604>  // b.none
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	390002e0 	strb	w0, [x23]
    bcb4:	911ae3e1 	add	x1, sp, #0x6b8
    bcb8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bcbc:	52800020 	mov	w0, #0x1                   	// #1
    bcc0:	f9035fe2 	str	x2, [sp, #1720]
    bcc4:	f90363f5 	str	x21, [sp, #1728]
    bcc8:	97ffe676 	bl	56a0 <fwp_data.part.0.constprop.0>
    bccc:	97ffe6e2 	bl	5854 <fwp_rc_fresh>
    bcd0:	aa0003e2 	mov	x2, x0
    bcd4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bcd8:	911b23e1 	add	x1, sp, #0x6c8
    bcdc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bce0:	52800020 	mov	w0, #0x1                   	// #1
    bce4:	f90367e3 	str	x3, [sp, #1736]
    bce8:	f9036be2 	str	x2, [sp, #1744]
    bcec:	97ffe66d 	bl	56a0 <fwp_data.part.0.constprop.0>
    bcf0:	91174283 	add	x3, x20, #0x5d0
    bcf4:	aa0003f5 	mov	x21, x0
    bcf8:	f949d861 	ldr	x1, [x3, #5040]
    bcfc:	f949ec60 	ldr	x0, [x3, #5080]
    bd00:	cb0102a1 	sub	x1, x21, x1
    bd04:	eb00403f 	cmp	x1, x0, lsl #16
    bd08:	54000322 	b.cs	bd6c <f0+0x1c2c>  // b.hs, b.nlast
    bd0c:	d350fc22 	lsr	x2, x1, #16
    bd10:	f949fc63 	ldr	x3, [x3, #5112]
    bd14:	8b020842 	add	x2, x2, x2, lsl #2
    bd18:	d37df042 	lsl	x2, x2, #3
    bd1c:	8b020060 	add	x0, x3, x2
    bd20:	f9401017 	ldr	x23, [x0, #32]
    bd24:	b4000257 	cbz	x23, bd6c <f0+0x1c2c>
    bd28:	38626862 	ldrb	w2, [x3, x2]
    bd2c:	7100085f 	cmp	w2, #0x2
    bd30:	540041a0 	b.eq	c564 <f0+0x2424>  // b.none
    bd34:	7100045f 	cmp	w2, #0x1
    bd38:	540001a1 	b.ne	bd6c <f0+0x1c2c>  // b.any
    bd3c:	29430002 	ldp	w2, w0, [x0, #24]
    bd40:	92403c21 	and	x1, x1, #0xffff
    bd44:	9b027c21 	mul	x1, x1, x2
    bd48:	d360fc21 	lsr	x1, x1, #32
    bd4c:	eb00003f 	cmp	x1, x0
    bd50:	540000e2 	b.cs	bd6c <f0+0x1c2c>  // b.hs, b.nlast
    bd54:	8b0102f7 	add	x23, x23, x1
    bd58:	394002e0 	ldrb	w0, [x23]
    bd5c:	7103fc1f 	cmp	w0, #0xff
    bd60:	54004f80 	b.eq	c750 <f0+0x2610>  // b.none
    bd64:	52800020 	mov	w0, #0x1                   	// #1
    bd68:	390002e0 	strb	w0, [x23]
    bd6c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bd70:	911b63e1 	add	x1, sp, #0x6d8
    bd74:	52800020 	mov	w0, #0x1                   	// #1
    bd78:	f9036fe2 	str	x2, [sp, #1752]
    bd7c:	f90373f5 	str	x21, [sp, #1760]
    bd80:	97ffe648 	bl	56a0 <fwp_data.part.0.constprop.0>
    bd84:	91174283 	add	x3, x20, #0x5d0
    bd88:	aa0003f5 	mov	x21, x0
    bd8c:	f949d861 	ldr	x1, [x3, #5040]
    bd90:	f949ec60 	ldr	x0, [x3, #5080]
    bd94:	cb0102a1 	sub	x1, x21, x1
    bd98:	eb00403f 	cmp	x1, x0, lsl #16
    bd9c:	54000322 	b.cs	be00 <f0+0x1cc0>  // b.hs, b.nlast
    bda0:	d350fc22 	lsr	x2, x1, #16
    bda4:	f949fc63 	ldr	x3, [x3, #5112]
    bda8:	8b020842 	add	x2, x2, x2, lsl #2
    bdac:	d37df042 	lsl	x2, x2, #3
    bdb0:	8b020060 	add	x0, x3, x2
    bdb4:	f9401017 	ldr	x23, [x0, #32]
    bdb8:	b4000257 	cbz	x23, be00 <f0+0x1cc0>
    bdbc:	38626862 	ldrb	w2, [x3, x2]
    bdc0:	7100085f 	cmp	w2, #0x2
    bdc4:	54003ca0 	b.eq	c558 <f0+0x2418>  // b.none
    bdc8:	7100045f 	cmp	w2, #0x1
    bdcc:	540001a1 	b.ne	be00 <f0+0x1cc0>  // b.any
    bdd0:	29430002 	ldp	w2, w0, [x0, #24]
    bdd4:	92403c21 	and	x1, x1, #0xffff
    bdd8:	9b027c21 	mul	x1, x1, x2
    bddc:	d360fc21 	lsr	x1, x1, #32
    bde0:	eb00003f 	cmp	x1, x0
    bde4:	540000e2 	b.cs	be00 <f0+0x1cc0>  // b.hs, b.nlast
    bde8:	8b0102f7 	add	x23, x23, x1
    bdec:	394002e0 	ldrb	w0, [x23]
    bdf0:	7103fc1f 	cmp	w0, #0xff
    bdf4:	54004b40 	b.eq	c75c <f0+0x261c>  // b.none
    bdf8:	52800020 	mov	w0, #0x1                   	// #1
    bdfc:	390002e0 	strb	w0, [x23]
    be00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be04:	911ba3e1 	add	x1, sp, #0x6e8
    be08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be0c:	52800020 	mov	w0, #0x1                   	// #1
    be10:	f90377e2 	str	x2, [sp, #1768]
    be14:	f9037bf5 	str	x21, [sp, #1776]
    be18:	97ffe622 	bl	56a0 <fwp_data.part.0.constprop.0>
    be1c:	91174283 	add	x3, x20, #0x5d0
    be20:	aa0003f5 	mov	x21, x0
    be24:	f949d861 	ldr	x1, [x3, #5040]
    be28:	f949ec60 	ldr	x0, [x3, #5080]
    be2c:	cb0102a1 	sub	x1, x21, x1
    be30:	eb00403f 	cmp	x1, x0, lsl #16
    be34:	54000322 	b.cs	be98 <f0+0x1d58>  // b.hs, b.nlast
    be38:	d350fc22 	lsr	x2, x1, #16
    be3c:	f949fc63 	ldr	x3, [x3, #5112]
    be40:	8b020842 	add	x2, x2, x2, lsl #2
    be44:	d37df042 	lsl	x2, x2, #3
    be48:	8b020060 	add	x0, x3, x2
    be4c:	f9401017 	ldr	x23, [x0, #32]
    be50:	b4000257 	cbz	x23, be98 <f0+0x1d58>
    be54:	38626862 	ldrb	w2, [x3, x2]
    be58:	7100085f 	cmp	w2, #0x2
    be5c:	54003780 	b.eq	c54c <f0+0x240c>  // b.none
    be60:	7100045f 	cmp	w2, #0x1
    be64:	540001a1 	b.ne	be98 <f0+0x1d58>  // b.any
    be68:	29430002 	ldp	w2, w0, [x0, #24]
    be6c:	92403c21 	and	x1, x1, #0xffff
    be70:	9b027c21 	mul	x1, x1, x2
    be74:	d360fc21 	lsr	x1, x1, #32
    be78:	eb00003f 	cmp	x1, x0
    be7c:	540000e2 	b.cs	be98 <f0+0x1d58>  // b.hs, b.nlast
    be80:	8b0102f7 	add	x23, x23, x1
    be84:	394002e0 	ldrb	w0, [x23]
    be88:	7103fc1f 	cmp	w0, #0xff
    be8c:	540046e0 	b.eq	c768 <f0+0x2628>  // b.none
    be90:	52800020 	mov	w0, #0x1                   	// #1
    be94:	390002e0 	strb	w0, [x23]
    be98:	911be3e1 	add	x1, sp, #0x6f8
    be9c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bea0:	52800020 	mov	w0, #0x1                   	// #1
    bea4:	f9037ff7 	str	x23, [sp, #1784]
    bea8:	f90383f5 	str	x21, [sp, #1792]
    beac:	97ffe5fd 	bl	56a0 <fwp_data.part.0.constprop.0>
    beb0:	97ffe669 	bl	5854 <fwp_rc_fresh>
    beb4:	aa0003e2 	mov	x2, x0
    beb8:	911c23e1 	add	x1, sp, #0x708
    bebc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bec0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bec4:	52800020 	mov	w0, #0x1                   	// #1
    bec8:	f90387f5 	str	x21, [sp, #1800]
    becc:	f9038be2 	str	x2, [sp, #1808]
    bed0:	97ffe5f4 	bl	56a0 <fwp_data.part.0.constprop.0>
    bed4:	97ffe660 	bl	5854 <fwp_rc_fresh>
    bed8:	aa0003e2 	mov	x2, x0
    bedc:	911c63e1 	add	x1, sp, #0x718
    bee0:	52800020 	mov	w0, #0x1                   	// #1
    bee4:	f9038ff7 	str	x23, [sp, #1816]
    bee8:	f90393e2 	str	x2, [sp, #1824]
    beec:	97ffe5ed 	bl	56a0 <fwp_data.part.0.constprop.0>
    bef0:	97ffe659 	bl	5854 <fwp_rc_fresh>
    bef4:	aa0003e2 	mov	x2, x0
    bef8:	911ca3e1 	add	x1, sp, #0x728
    befc:	52800020 	mov	w0, #0x1                   	// #1
    bf00:	f90397f5 	str	x21, [sp, #1832]
    bf04:	f9039be2 	str	x2, [sp, #1840]
    bf08:	97ffe5e6 	bl	56a0 <fwp_data.part.0.constprop.0>
    bf0c:	91174283 	add	x3, x20, #0x5d0
    bf10:	aa0003f5 	mov	x21, x0
    bf14:	f949d861 	ldr	x1, [x3, #5040]
    bf18:	f949ec60 	ldr	x0, [x3, #5080]
    bf1c:	cb0102a1 	sub	x1, x21, x1
    bf20:	eb00403f 	cmp	x1, x0, lsl #16
    bf24:	54000322 	b.cs	bf88 <f0+0x1e48>  // b.hs, b.nlast
    bf28:	d350fc22 	lsr	x2, x1, #16
    bf2c:	f949fc63 	ldr	x3, [x3, #5112]
    bf30:	8b020842 	add	x2, x2, x2, lsl #2
    bf34:	d37df042 	lsl	x2, x2, #3
    bf38:	8b020060 	add	x0, x3, x2
    bf3c:	f9401017 	ldr	x23, [x0, #32]
    bf40:	b4000257 	cbz	x23, bf88 <f0+0x1e48>
    bf44:	38626862 	ldrb	w2, [x3, x2]
    bf48:	7100085f 	cmp	w2, #0x2
    bf4c:	54002fa0 	b.eq	c540 <f0+0x2400>  // b.none
    bf50:	7100045f 	cmp	w2, #0x1
    bf54:	540001a1 	b.ne	bf88 <f0+0x1e48>  // b.any
    bf58:	29430002 	ldp	w2, w0, [x0, #24]
    bf5c:	92403c21 	and	x1, x1, #0xffff
    bf60:	9b027c21 	mul	x1, x1, x2
    bf64:	d360fc21 	lsr	x1, x1, #32
    bf68:	eb00003f 	cmp	x1, x0
    bf6c:	540000e2 	b.cs	bf88 <f0+0x1e48>  // b.hs, b.nlast
    bf70:	8b0102f7 	add	x23, x23, x1
    bf74:	394002e0 	ldrb	w0, [x23]
    bf78:	7103fc1f 	cmp	w0, #0xff
    bf7c:	54003fc0 	b.eq	c774 <f0+0x2634>  // b.none
    bf80:	52800020 	mov	w0, #0x1                   	// #1
    bf84:	390002e0 	strb	w0, [x23]
    bf88:	911ce3e1 	add	x1, sp, #0x738
    bf8c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bf90:	52800020 	mov	w0, #0x1                   	// #1
    bf94:	f9039ff7 	str	x23, [sp, #1848]
    bf98:	f903a3f5 	str	x21, [sp, #1856]
    bf9c:	97ffe5c1 	bl	56a0 <fwp_data.part.0.constprop.0>
    bfa0:	97ffe62d 	bl	5854 <fwp_rc_fresh>
    bfa4:	aa0003e2 	mov	x2, x0
    bfa8:	911d23e1 	add	x1, sp, #0x748
    bfac:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bfb0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bfb4:	52800020 	mov	w0, #0x1                   	// #1
    bfb8:	f903a7f5 	str	x21, [sp, #1864]
    bfbc:	f903abe2 	str	x2, [sp, #1872]
    bfc0:	97ffe5b8 	bl	56a0 <fwp_data.part.0.constprop.0>
    bfc4:	97ffe624 	bl	5854 <fwp_rc_fresh>
    bfc8:	aa0003e2 	mov	x2, x0
    bfcc:	911d63e1 	add	x1, sp, #0x758
    bfd0:	52800020 	mov	w0, #0x1                   	// #1
    bfd4:	f903aff7 	str	x23, [sp, #1880]
    bfd8:	f903b3e2 	str	x2, [sp, #1888]
    bfdc:	97ffe5b1 	bl	56a0 <fwp_data.part.0.constprop.0>
    bfe0:	97ffe61d 	bl	5854 <fwp_rc_fresh>
    bfe4:	aa0003e2 	mov	x2, x0
    bfe8:	911da3e1 	add	x1, sp, #0x768
    bfec:	52800020 	mov	w0, #0x1                   	// #1
    bff0:	f903b7f5 	str	x21, [sp, #1896]
    bff4:	f903bbe2 	str	x2, [sp, #1904]
    bff8:	97ffe5aa 	bl	56a0 <fwp_data.part.0.constprop.0>
    bffc:	97ffe616 	bl	5854 <fwp_rc_fresh>
    c000:	aa0003e2 	mov	x2, x0
    c004:	911de3e1 	add	x1, sp, #0x778
    c008:	52800020 	mov	w0, #0x1                   	// #1
    c00c:	f903bff7 	str	x23, [sp, #1912]
    c010:	f903c3e2 	str	x2, [sp, #1920]
    c014:	97ffe5a3 	bl	56a0 <fwp_data.part.0.constprop.0>
    c018:	97ffe60f 	bl	5854 <fwp_rc_fresh>
    c01c:	aa0003e2 	mov	x2, x0
    c020:	911e23e1 	add	x1, sp, #0x788
    c024:	52800020 	mov	w0, #0x1                   	// #1
    c028:	f903c7f5 	str	x21, [sp, #1928]
    c02c:	f903cbe2 	str	x2, [sp, #1936]
    c030:	97ffe59c 	bl	56a0 <fwp_data.part.0.constprop.0>
    c034:	97ffe608 	bl	5854 <fwp_rc_fresh>
    c038:	aa0003e2 	mov	x2, x0
    c03c:	911e63e1 	add	x1, sp, #0x798
    c040:	52800020 	mov	w0, #0x1                   	// #1
    c044:	f903cff7 	str	x23, [sp, #1944]
    c048:	f903d3e2 	str	x2, [sp, #1952]
    c04c:	97ffe595 	bl	56a0 <fwp_data.part.0.constprop.0>
    c050:	97ffe601 	bl	5854 <fwp_rc_fresh>
    c054:	aa0003e2 	mov	x2, x0
    c058:	911ea3e1 	add	x1, sp, #0x7a8
    c05c:	52800020 	mov	w0, #0x1                   	// #1
    c060:	f903d7f5 	str	x21, [sp, #1960]
    c064:	f903dbe2 	str	x2, [sp, #1968]
    c068:	97ffe58e 	bl	56a0 <fwp_data.part.0.constprop.0>
    c06c:	91174283 	add	x3, x20, #0x5d0
    c070:	aa0003f5 	mov	x21, x0
    c074:	f949d861 	ldr	x1, [x3, #5040]
    c078:	f949ec60 	ldr	x0, [x3, #5080]
    c07c:	cb0102a1 	sub	x1, x21, x1
    c080:	eb00403f 	cmp	x1, x0, lsl #16
    c084:	54000322 	b.cs	c0e8 <f0+0x1fa8>  // b.hs, b.nlast
    c088:	d350fc22 	lsr	x2, x1, #16
    c08c:	f949fc63 	ldr	x3, [x3, #5112]
    c090:	8b020842 	add	x2, x2, x2, lsl #2
    c094:	d37df042 	lsl	x2, x2, #3
    c098:	8b020060 	add	x0, x3, x2
    c09c:	f9401017 	ldr	x23, [x0, #32]
    c0a0:	b4000257 	cbz	x23, c0e8 <f0+0x1fa8>
    c0a4:	38626862 	ldrb	w2, [x3, x2]
    c0a8:	7100085f 	cmp	w2, #0x2
    c0ac:	54002440 	b.eq	c534 <f0+0x23f4>  // b.none
    c0b0:	7100045f 	cmp	w2, #0x1
    c0b4:	540001a1 	b.ne	c0e8 <f0+0x1fa8>  // b.any
    c0b8:	29430002 	ldp	w2, w0, [x0, #24]
    c0bc:	92403c21 	and	x1, x1, #0xffff
    c0c0:	9b027c21 	mul	x1, x1, x2
    c0c4:	d360fc21 	lsr	x1, x1, #32
    c0c8:	eb00003f 	cmp	x1, x0
    c0cc:	540000e2 	b.cs	c0e8 <f0+0x1fa8>  // b.hs, b.nlast
    c0d0:	8b0102f7 	add	x23, x23, x1
    c0d4:	394002e0 	ldrb	w0, [x23]
    c0d8:	7103fc1f 	cmp	w0, #0xff
    c0dc:	54003520 	b.eq	c780 <f0+0x2640>  // b.none
    c0e0:	52800020 	mov	w0, #0x1                   	// #1
    c0e4:	390002e0 	strb	w0, [x23]
    c0e8:	911ee3e1 	add	x1, sp, #0x7b8
    c0ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c0f0:	52800020 	mov	w0, #0x1                   	// #1
    c0f4:	f903dfe2 	str	x2, [sp, #1976]
    c0f8:	f903e3f5 	str	x21, [sp, #1984]
    c0fc:	97ffe569 	bl	56a0 <fwp_data.part.0.constprop.0>
    c100:	97ffe5d5 	bl	5854 <fwp_rc_fresh>
    c104:	aa0003e2 	mov	x2, x0
    c108:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c10c:	911f23e1 	add	x1, sp, #0x7c8
    c110:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c114:	52800020 	mov	w0, #0x1                   	// #1
    c118:	f903e7e3 	str	x3, [sp, #1992]
    c11c:	f903ebe2 	str	x2, [sp, #2000]
    c120:	97ffe560 	bl	56a0 <fwp_data.part.0.constprop.0>
    c124:	91174283 	add	x3, x20, #0x5d0
    c128:	aa0003f5 	mov	x21, x0
    c12c:	f949d861 	ldr	x1, [x3, #5040]
    c130:	f949ec60 	ldr	x0, [x3, #5080]
    c134:	cb0102a1 	sub	x1, x21, x1
    c138:	eb00403f 	cmp	x1, x0, lsl #16
    c13c:	54000322 	b.cs	c1a0 <f0+0x2060>  // b.hs, b.nlast
    c140:	d350fc22 	lsr	x2, x1, #16
    c144:	f949fc63 	ldr	x3, [x3, #5112]
    c148:	8b020842 	add	x2, x2, x2, lsl #2
    c14c:	d37df042 	lsl	x2, x2, #3
    c150:	8b020060 	add	x0, x3, x2
    c154:	f9401017 	ldr	x23, [x0, #32]
    c158:	b4000257 	cbz	x23, c1a0 <f0+0x2060>
    c15c:	38626862 	ldrb	w2, [x3, x2]
    c160:	7100085f 	cmp	w2, #0x2
    c164:	54001e20 	b.eq	c528 <f0+0x23e8>  // b.none
    c168:	7100045f 	cmp	w2, #0x1
    c16c:	540001a1 	b.ne	c1a0 <f0+0x2060>  // b.any
    c170:	29430002 	ldp	w2, w0, [x0, #24]
    c174:	92403c21 	and	x1, x1, #0xffff
    c178:	9b027c21 	mul	x1, x1, x2
    c17c:	d360fc21 	lsr	x1, x1, #32
    c180:	eb00003f 	cmp	x1, x0
    c184:	540000e2 	b.cs	c1a0 <f0+0x2060>  // b.hs, b.nlast
    c188:	8b0102f7 	add	x23, x23, x1
    c18c:	394002e0 	ldrb	w0, [x23]
    c190:	7103fc1f 	cmp	w0, #0xff
    c194:	54002fc0 	b.eq	c78c <f0+0x264c>  // b.none
    c198:	52800020 	mov	w0, #0x1                   	// #1
    c19c:	390002e0 	strb	w0, [x23]
    c1a0:	911f63e1 	add	x1, sp, #0x7d8
    c1a4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c1a8:	52800020 	mov	w0, #0x1                   	// #1
    c1ac:	f903efe2 	str	x2, [sp, #2008]
    c1b0:	f903f3f5 	str	x21, [sp, #2016]
    c1b4:	97ffe53b 	bl	56a0 <fwp_data.part.0.constprop.0>
    c1b8:	97ffe5a7 	bl	5854 <fwp_rc_fresh>
    c1bc:	aa0003e2 	mov	x2, x0
    c1c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c1c4:	911fa3e1 	add	x1, sp, #0x7e8
    c1c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c1cc:	52800020 	mov	w0, #0x1                   	// #1
    c1d0:	f903f7e3 	str	x3, [sp, #2024]
    c1d4:	f903fbe2 	str	x2, [sp, #2032]
    c1d8:	97ffe532 	bl	56a0 <fwp_data.part.0.constprop.0>
    c1dc:	91174283 	add	x3, x20, #0x5d0
    c1e0:	aa0003f5 	mov	x21, x0
    c1e4:	f949d861 	ldr	x1, [x3, #5040]
    c1e8:	f949ec60 	ldr	x0, [x3, #5080]
    c1ec:	cb0102a1 	sub	x1, x21, x1
    c1f0:	eb00403f 	cmp	x1, x0, lsl #16
    c1f4:	54000322 	b.cs	c258 <f0+0x2118>  // b.hs, b.nlast
    c1f8:	d350fc22 	lsr	x2, x1, #16
    c1fc:	f949fc63 	ldr	x3, [x3, #5112]
    c200:	8b020842 	add	x2, x2, x2, lsl #2
    c204:	d37df042 	lsl	x2, x2, #3
    c208:	8b020060 	add	x0, x3, x2
    c20c:	f9401017 	ldr	x23, [x0, #32]
    c210:	b4000257 	cbz	x23, c258 <f0+0x2118>
    c214:	38626862 	ldrb	w2, [x3, x2]
    c218:	7100085f 	cmp	w2, #0x2
    c21c:	54001800 	b.eq	c51c <f0+0x23dc>  // b.none
    c220:	7100045f 	cmp	w2, #0x1
    c224:	540001a1 	b.ne	c258 <f0+0x2118>  // b.any
    c228:	29430002 	ldp	w2, w0, [x0, #24]
    c22c:	92403c21 	and	x1, x1, #0xffff
    c230:	9b027c21 	mul	x1, x1, x2
    c234:	d360fc21 	lsr	x1, x1, #32
    c238:	eb00003f 	cmp	x1, x0
    c23c:	540000e2 	b.cs	c258 <f0+0x2118>  // b.hs, b.nlast
    c240:	8b0102f7 	add	x23, x23, x1
    c244:	394002e0 	ldrb	w0, [x23]
    c248:	7103fc1f 	cmp	w0, #0xff
    c24c:	54002a60 	b.eq	c798 <f0+0x2658>  // b.none
    c250:	52800020 	mov	w0, #0x1                   	// #1
    c254:	390002e0 	strb	w0, [x23]
    c258:	911fe3e1 	add	x1, sp, #0x7f8
    c25c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c260:	52800020 	mov	w0, #0x1                   	// #1
    c264:	f903fff7 	str	x23, [sp, #2040]
    c268:	f90403f5 	str	x21, [sp, #2048]
    c26c:	97ffe50d 	bl	56a0 <fwp_data.part.0.constprop.0>
    c270:	97ffe579 	bl	5854 <fwp_rc_fresh>
    c274:	aa0003e2 	mov	x2, x0
    c278:	912023e1 	add	x1, sp, #0x808
    c27c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c280:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c284:	52800020 	mov	w0, #0x1                   	// #1
    c288:	f90407f5 	str	x21, [sp, #2056]
    c28c:	91174294 	add	x20, x20, #0x5d0
    c290:	f9040be2 	str	x2, [sp, #2064]
    c294:	97ffe503 	bl	56a0 <fwp_data.part.0.constprop.0>
    c298:	97ffe56f 	bl	5854 <fwp_rc_fresh>
    c29c:	aa0003e2 	mov	x2, x0
    c2a0:	912063e1 	add	x1, sp, #0x818
    c2a4:	52800020 	mov	w0, #0x1                   	// #1
    c2a8:	f9040ff7 	str	x23, [sp, #2072]
    c2ac:	f90413e2 	str	x2, [sp, #2080]
    c2b0:	97ffe4fc 	bl	56a0 <fwp_data.part.0.constprop.0>
    c2b4:	97ffe568 	bl	5854 <fwp_rc_fresh>
    c2b8:	aa0003e2 	mov	x2, x0
    c2bc:	9120a3e1 	add	x1, sp, #0x828
    c2c0:	52800020 	mov	w0, #0x1                   	// #1
    c2c4:	f90417f5 	str	x21, [sp, #2088]
    c2c8:	f9041be2 	str	x2, [sp, #2096]
    c2cc:	97ffe4f5 	bl	56a0 <fwp_data.part.0.constprop.0>
    c2d0:	97ffe561 	bl	5854 <fwp_rc_fresh>
    c2d4:	aa0003e2 	mov	x2, x0
    c2d8:	9120e3e1 	add	x1, sp, #0x838
    c2dc:	52800020 	mov	w0, #0x1                   	// #1
    c2e0:	f9041ff7 	str	x23, [sp, #2104]
    c2e4:	f90423e2 	str	x2, [sp, #2112]
    c2e8:	97ffe4ee 	bl	56a0 <fwp_data.part.0.constprop.0>
    c2ec:	f949da81 	ldr	x1, [x20, #5040]
    c2f0:	aa0003f5 	mov	x21, x0
    c2f4:	f949ee80 	ldr	x0, [x20, #5080]
    c2f8:	cb0102a1 	sub	x1, x21, x1
    c2fc:	eb00403f 	cmp	x1, x0, lsl #16
    c300:	54000322 	b.cs	c364 <f0+0x2224>  // b.hs, b.nlast
    c304:	d350fc22 	lsr	x2, x1, #16
    c308:	f949fe83 	ldr	x3, [x20, #5112]
    c30c:	8b020842 	add	x2, x2, x2, lsl #2
    c310:	d37df042 	lsl	x2, x2, #3
    c314:	8b020060 	add	x0, x3, x2
    c318:	f9401014 	ldr	x20, [x0, #32]
    c31c:	b4000254 	cbz	x20, c364 <f0+0x2224>
    c320:	38626862 	ldrb	w2, [x3, x2]
    c324:	7100085f 	cmp	w2, #0x2
    c328:	54000f40 	b.eq	c510 <f0+0x23d0>  // b.none
    c32c:	7100045f 	cmp	w2, #0x1
    c330:	540001a1 	b.ne	c364 <f0+0x2224>  // b.any
    c334:	29430002 	ldp	w2, w0, [x0, #24]
    c338:	92403c21 	and	x1, x1, #0xffff
    c33c:	9b027c21 	mul	x1, x1, x2
    c340:	d360fc21 	lsr	x1, x1, #32
    c344:	eb00003f 	cmp	x1, x0
    c348:	540000e2 	b.cs	c364 <f0+0x2224>  // b.hs, b.nlast
    c34c:	8b010294 	add	x20, x20, x1
    c350:	39400280 	ldrb	w0, [x20]
    c354:	7103fc1f 	cmp	w0, #0xff
    c358:	540013c0 	b.eq	c5d0 <f0+0x2490>  // b.none
    c35c:	52800020 	mov	w0, #0x1                   	// #1
    c360:	39000280 	strb	w0, [x20]
    c364:	aa1603e1 	mov	x1, x22
    c368:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c36c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c370:	52800020 	mov	w0, #0x1                   	// #1
    c374:	f90427e2 	str	x2, [sp, #2120]
    c378:	f9042bf5 	str	x21, [sp, #2128]
    c37c:	97ffe4c9 	bl	56a0 <fwp_data.part.0.constprop.0>
    c380:	97ffe535 	bl	5854 <fwp_rc_fresh>
    c384:	aa0003f5 	mov	x21, x0
    c388:	aa1303e1 	mov	x1, x19
    c38c:	97fff479 	bl	9570 <fwp_hof0.constprop.0>
    c390:	aa0003f4 	mov	x20, x0
    c394:	aa1503e0 	mov	x0, x21
    c398:	97ffe68a 	bl	5dc0 <fwp_drop0>
    c39c:	aa1303e0 	mov	x0, x19
    c3a0:	97ffe688 	bl	5dc0 <fwp_drop0>
    c3a4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c3a8:	f947f400 	ldr	x0, [x0, #4072]
    c3ac:	f9442fe2 	ldr	x2, [sp, #2136]
    c3b0:	f9400001 	ldr	x1, [x0]
    c3b4:	eb010042 	subs	x2, x2, x1
    c3b8:	d2800001 	mov	x1, #0x0                   	// #0
    c3bc:	54001f41 	b.ne	c7a4 <f0+0x2664>  // b.any
    c3c0:	912183ff 	add	sp, sp, #0x860
    c3c4:	aa1403e0 	mov	x0, x20
    c3c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    c3cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c3d0:	a94363f7 	ldp	x23, x24, [sp, #48]
    c3d4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c3d8:	a94573fb 	ldp	x27, x28, [sp, #80]
    c3dc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c3e0:	d65f03c0 	ret
    c3e4:	aa1b03e0 	mov	x0, x27
    c3e8:	97ffe102 	bl	47f0 <fwp_rc_forget_slot>
    c3ec:	17fff79d 	b	a260 <f0+0x120>
    c3f0:	72003c5f 	tst	w2, #0xffff
    c3f4:	54fef381 	b.ne	a264 <f0+0x124>  // b.any
    c3f8:	17fff797 	b	a254 <f0+0x114>
    c3fc:	72003c3f 	tst	w1, #0xffff
    c400:	54ff89c1 	b.ne	b538 <f0+0x13f8>  // b.any
    c404:	17fffc48 	b	b524 <f0+0x13e4>
    c408:	72003c3f 	tst	w1, #0xffff
    c40c:	54ff82c1 	b.ne	b464 <f0+0x1324>  // b.any
    c410:	17fffc10 	b	b450 <f0+0x1310>
    c414:	72003c3f 	tst	w1, #0xffff
    c418:	54ff7dc1 	b.ne	b3d0 <f0+0x1290>  // b.any
    c41c:	17fffbe8 	b	b3bc <f0+0x127c>
    c420:	72003c3f 	tst	w1, #0xffff
    c424:	54ff75e1 	b.ne	b2e0 <f0+0x11a0>  // b.any
    c428:	17fffba9 	b	b2cc <f0+0x118c>
    c42c:	72003c3f 	tst	w1, #0xffff
    c430:	54ff6e01 	b.ne	b1f0 <f0+0x10b0>  // b.any
    c434:	17fffb6a 	b	b1dc <f0+0x109c>
    c438:	72003c3f 	tst	w1, #0xffff
    c43c:	54ff6621 	b.ne	b100 <f0+0xfc0>  // b.any
    c440:	17fffb2b 	b	b0ec <f0+0xfac>
    c444:	72003c3f 	tst	w1, #0xffff
    c448:	54ff5741 	b.ne	af30 <f0+0xdf0>  // b.any
    c44c:	17fffab4 	b	af1c <f0+0xddc>
    c450:	72003c3f 	tst	w1, #0xffff
    c454:	54ff5041 	b.ne	ae5c <f0+0xd1c>  // b.any
    c458:	17fffa7c 	b	ae48 <f0+0xd08>
    c45c:	72003c3f 	tst	w1, #0xffff
    c460:	54ff0721 	b.ne	a544 <f0+0x404>  // b.any
    c464:	17fff833 	b	a530 <f0+0x3f0>
    c468:	72003c3f 	tst	w1, #0xffff
    c46c:	54fefd81 	b.ne	a41c <f0+0x2dc>  // b.any
    c470:	17fff7e6 	b	a408 <f0+0x2c8>
    c474:	72003c3f 	tst	w1, #0xffff
    c478:	54fef7a1 	b.ne	a36c <f0+0x22c>  // b.any
    c47c:	17fff7b7 	b	a358 <f0+0x218>
    c480:	72003c3f 	tst	w1, #0xffff
    c484:	54ff1c01 	b.ne	a804 <f0+0x6c4>  // b.any
    c488:	17fff8da 	b	a7f0 <f0+0x6b0>
    c48c:	72003c3f 	tst	w1, #0xffff
    c490:	54ff1621 	b.ne	a754 <f0+0x614>  // b.any
    c494:	17fff8ab 	b	a740 <f0+0x600>
    c498:	72003c3f 	tst	w1, #0xffff
    c49c:	54ff1041 	b.ne	a6a4 <f0+0x564>  // b.any
    c4a0:	17fff87c 	b	a690 <f0+0x550>
    c4a4:	72003c3f 	tst	w1, #0xffff
    c4a8:	54ff0a61 	b.ne	a5f4 <f0+0x4b4>  // b.any
    c4ac:	17fff84d 	b	a5e0 <f0+0x4a0>
    c4b0:	72003c3f 	tst	w1, #0xffff
    c4b4:	54ff48a1 	b.ne	adc8 <f0+0xc88>  // b.any
    c4b8:	17fffa3f 	b	adb4 <f0+0xc74>
    c4bc:	72003c3f 	tst	w1, #0xffff
    c4c0:	54ff4381 	b.ne	ad30 <f0+0xbf0>  // b.any
    c4c4:	17fffa16 	b	ad1c <f0+0xbdc>
    c4c8:	72003c3f 	tst	w1, #0xffff
    c4cc:	54ff3e81 	b.ne	ac9c <f0+0xb5c>  // b.any
    c4d0:	17fff9ee 	b	ac88 <f0+0xb48>
    c4d4:	72003c3f 	tst	w1, #0xffff
    c4d8:	54ff3861 	b.ne	abe4 <f0+0xaa4>  // b.any
    c4dc:	17fff9bd 	b	abd0 <f0+0xa90>
    c4e0:	72003c3f 	tst	w1, #0xffff
    c4e4:	54ff3341 	b.ne	ab4c <f0+0xa0c>  // b.any
    c4e8:	17fff994 	b	ab38 <f0+0x9f8>
    c4ec:	72003c3f 	tst	w1, #0xffff
    c4f0:	54ff2a81 	b.ne	aa40 <f0+0x900>  // b.any
    c4f4:	17fff94e 	b	aa2c <f0+0x8ec>
    c4f8:	72003c3f 	tst	w1, #0xffff
    c4fc:	54ff23c1 	b.ne	a974 <f0+0x834>  // b.any
    c500:	17fff918 	b	a960 <f0+0x820>
    c504:	72003c3f 	tst	w1, #0xffff
    c508:	54ff1ee1 	b.ne	a8e4 <f0+0x7a4>  // b.any
    c50c:	17fff8f1 	b	a8d0 <f0+0x790>
    c510:	72003c3f 	tst	w1, #0xffff
    c514:	54fff281 	b.ne	c364 <f0+0x2224>  // b.any
    c518:	17ffff8e 	b	c350 <f0+0x2210>
    c51c:	72003c3f 	tst	w1, #0xffff
    c520:	54ffe9c1 	b.ne	c258 <f0+0x2118>  // b.any
    c524:	17ffff48 	b	c244 <f0+0x2104>
    c528:	72003c3f 	tst	w1, #0xffff
    c52c:	54ffe3a1 	b.ne	c1a0 <f0+0x2060>  // b.any
    c530:	17ffff17 	b	c18c <f0+0x204c>
    c534:	72003c3f 	tst	w1, #0xffff
    c538:	54ffdd81 	b.ne	c0e8 <f0+0x1fa8>  // b.any
    c53c:	17fffee6 	b	c0d4 <f0+0x1f94>
    c540:	72003c3f 	tst	w1, #0xffff
    c544:	54ffd221 	b.ne	bf88 <f0+0x1e48>  // b.any
    c548:	17fffe8b 	b	bf74 <f0+0x1e34>
    c54c:	72003c3f 	tst	w1, #0xffff
    c550:	54ffca41 	b.ne	be98 <f0+0x1d58>  // b.any
    c554:	17fffe4c 	b	be84 <f0+0x1d44>
    c558:	72003c3f 	tst	w1, #0xffff
    c55c:	54ffc521 	b.ne	be00 <f0+0x1cc0>  // b.any
    c560:	17fffe23 	b	bdec <f0+0x1cac>
    c564:	72003c3f 	tst	w1, #0xffff
    c568:	54ffc021 	b.ne	bd6c <f0+0x1c2c>  // b.any
    c56c:	17fffdfb 	b	bd58 <f0+0x1c18>
    c570:	72003c3f 	tst	w1, #0xffff
    c574:	54ffba01 	b.ne	bcb4 <f0+0x1b74>  // b.any
    c578:	17fffdca 	b	bca0 <f0+0x1b60>
    c57c:	72003c3f 	tst	w1, #0xffff
    c580:	54ffb3e1 	b.ne	bbfc <f0+0x1abc>  // b.any
    c584:	17fffd99 	b	bbe8 <f0+0x1aa8>
    c588:	72003c3f 	tst	w1, #0xffff
    c58c:	54ffadc1 	b.ne	bb44 <f0+0x1a04>  // b.any
    c590:	17fffd68 	b	bb30 <f0+0x19f0>
    c594:	72003c3f 	tst	w1, #0xffff
    c598:	54ffa261 	b.ne	b9e4 <f0+0x18a4>  // b.any
    c59c:	17fffd0d 	b	b9d0 <f0+0x1890>
    c5a0:	72003c3f 	tst	w1, #0xffff
    c5a4:	54ff9d41 	b.ne	b94c <f0+0x180c>  // b.any
    c5a8:	17fffce4 	b	b938 <f0+0x17f8>
    c5ac:	72003c3f 	tst	w1, #0xffff
    c5b0:	54ff9641 	b.ne	b878 <f0+0x1738>  // b.any
    c5b4:	17fffcac 	b	b864 <f0+0x1724>
    c5b8:	72003c3f 	tst	w1, #0xffff
    c5bc:	54ff8ae1 	b.ne	b718 <f0+0x15d8>  // b.any
    c5c0:	17fffc51 	b	b704 <f0+0x15c4>
    c5c4:	72003c3f 	tst	w1, #0xffff
    c5c8:	54ff8221 	b.ne	b60c <f0+0x14cc>  // b.any
    c5cc:	17fffc0b 	b	b5f8 <f0+0x14b8>
    c5d0:	aa1403e0 	mov	x0, x20
    c5d4:	97ffe087 	bl	47f0 <fwp_rc_forget_slot>
    c5d8:	17ffff61 	b	c35c <f0+0x221c>
    c5dc:	aa1703e0 	mov	x0, x23
    c5e0:	97ffe084 	bl	47f0 <fwp_rc_forget_slot>
    c5e4:	17fff760 	b	a364 <f0+0x224>
    c5e8:	aa1503e0 	mov	x0, x21
    c5ec:	97ffe081 	bl	47f0 <fwp_rc_forget_slot>
    c5f0:	17fff789 	b	a414 <f0+0x2d4>
    c5f4:	aa1703e0 	mov	x0, x23
    c5f8:	97ffe07e 	bl	47f0 <fwp_rc_forget_slot>
    c5fc:	17fff7d0 	b	a53c <f0+0x3fc>
    c600:	aa1703e0 	mov	x0, x23
    c604:	97ffe07b 	bl	47f0 <fwp_rc_forget_slot>
    c608:	17fff7f9 	b	a5ec <f0+0x4ac>
    c60c:	aa1703e0 	mov	x0, x23
    c610:	97ffe078 	bl	47f0 <fwp_rc_forget_slot>
    c614:	17fff822 	b	a69c <f0+0x55c>
    c618:	aa1703e0 	mov	x0, x23
    c61c:	97ffe075 	bl	47f0 <fwp_rc_forget_slot>
    c620:	17fff84b 	b	a74c <f0+0x60c>
    c624:	aa1703e0 	mov	x0, x23
    c628:	97ffe072 	bl	47f0 <fwp_rc_forget_slot>
    c62c:	17fff874 	b	a7fc <f0+0x6bc>
    c630:	aa1703e0 	mov	x0, x23
    c634:	97ffe06f 	bl	47f0 <fwp_rc_forget_slot>
    c638:	17fff8a9 	b	a8dc <f0+0x79c>
    c63c:	aa1703e0 	mov	x0, x23
    c640:	97ffe06c 	bl	47f0 <fwp_rc_forget_slot>
    c644:	17fff8ca 	b	a96c <f0+0x82c>
    c648:	aa1703e0 	mov	x0, x23
    c64c:	97ffe069 	bl	47f0 <fwp_rc_forget_slot>
    c650:	17fff8fa 	b	aa38 <f0+0x8f8>
    c654:	aa1703e0 	mov	x0, x23
    c658:	97ffe066 	bl	47f0 <fwp_rc_forget_slot>
    c65c:	17fff93a 	b	ab44 <f0+0xa04>
    c660:	aa1703e0 	mov	x0, x23
    c664:	97ffe063 	bl	47f0 <fwp_rc_forget_slot>
    c668:	17fff95d 	b	abdc <f0+0xa9c>
    c66c:	aa1703e0 	mov	x0, x23
    c670:	97ffe060 	bl	47f0 <fwp_rc_forget_slot>
    c674:	17fff988 	b	ac94 <f0+0xb54>
    c678:	aa1703e0 	mov	x0, x23
    c67c:	97ffe05d 	bl	47f0 <fwp_rc_forget_slot>
    c680:	17fff9aa 	b	ad28 <f0+0xbe8>
    c684:	aa1703e0 	mov	x0, x23
    c688:	97ffe05a 	bl	47f0 <fwp_rc_forget_slot>
    c68c:	17fff9cd 	b	adc0 <f0+0xc80>
    c690:	aa1703e0 	mov	x0, x23
    c694:	97ffe057 	bl	47f0 <fwp_rc_forget_slot>
    c698:	17fff9ef 	b	ae54 <f0+0xd14>
    c69c:	aa1703e0 	mov	x0, x23
    c6a0:	97ffe054 	bl	47f0 <fwp_rc_forget_slot>
    c6a4:	17fffa21 	b	af28 <f0+0xde8>
    c6a8:	aa1703e0 	mov	x0, x23
    c6ac:	97ffe051 	bl	47f0 <fwp_rc_forget_slot>
    c6b0:	17fffa92 	b	b0f8 <f0+0xfb8>
    c6b4:	aa1703e0 	mov	x0, x23
    c6b8:	97ffe04e 	bl	47f0 <fwp_rc_forget_slot>
    c6bc:	17fffacb 	b	b1e8 <f0+0x10a8>
    c6c0:	aa1703e0 	mov	x0, x23
    c6c4:	97ffe04b 	bl	47f0 <fwp_rc_forget_slot>
    c6c8:	17fffb04 	b	b2d8 <f0+0x1198>
    c6cc:	aa1703e0 	mov	x0, x23
    c6d0:	97ffe048 	bl	47f0 <fwp_rc_forget_slot>
    c6d4:	17fffb3d 	b	b3c8 <f0+0x1288>
    c6d8:	aa1703e0 	mov	x0, x23
    c6dc:	97ffe045 	bl	47f0 <fwp_rc_forget_slot>
    c6e0:	17fffb5f 	b	b45c <f0+0x131c>
    c6e4:	aa1703e0 	mov	x0, x23
    c6e8:	97ffe042 	bl	47f0 <fwp_rc_forget_slot>
    c6ec:	17fffb91 	b	b530 <f0+0x13f0>
    c6f0:	aa1703e0 	mov	x0, x23
    c6f4:	97ffe03f 	bl	47f0 <fwp_rc_forget_slot>
    c6f8:	17fffbc3 	b	b604 <f0+0x14c4>
    c6fc:	aa1703e0 	mov	x0, x23
    c700:	97ffe03c 	bl	47f0 <fwp_rc_forget_slot>
    c704:	17fffc03 	b	b710 <f0+0x15d0>
    c708:	aa1703e0 	mov	x0, x23
    c70c:	97ffe039 	bl	47f0 <fwp_rc_forget_slot>
    c710:	17fffc58 	b	b870 <f0+0x1730>
    c714:	aa1703e0 	mov	x0, x23
    c718:	97ffe036 	bl	47f0 <fwp_rc_forget_slot>
    c71c:	17fffc8a 	b	b944 <f0+0x1804>
    c720:	aa1703e0 	mov	x0, x23
    c724:	97ffe033 	bl	47f0 <fwp_rc_forget_slot>
    c728:	17fffcad 	b	b9dc <f0+0x189c>
    c72c:	aa1703e0 	mov	x0, x23
    c730:	97ffe030 	bl	47f0 <fwp_rc_forget_slot>
    c734:	17fffd02 	b	bb3c <f0+0x19fc>
    c738:	aa1703e0 	mov	x0, x23
    c73c:	97ffe02d 	bl	47f0 <fwp_rc_forget_slot>
    c740:	17fffd2d 	b	bbf4 <f0+0x1ab4>
    c744:	aa1703e0 	mov	x0, x23
    c748:	97ffe02a 	bl	47f0 <fwp_rc_forget_slot>
    c74c:	17fffd58 	b	bcac <f0+0x1b6c>
    c750:	aa1703e0 	mov	x0, x23
    c754:	97ffe027 	bl	47f0 <fwp_rc_forget_slot>
    c758:	17fffd83 	b	bd64 <f0+0x1c24>
    c75c:	aa1703e0 	mov	x0, x23
    c760:	97ffe024 	bl	47f0 <fwp_rc_forget_slot>
    c764:	17fffda5 	b	bdf8 <f0+0x1cb8>
    c768:	aa1703e0 	mov	x0, x23
    c76c:	97ffe021 	bl	47f0 <fwp_rc_forget_slot>
    c770:	17fffdc8 	b	be90 <f0+0x1d50>
    c774:	aa1703e0 	mov	x0, x23
    c778:	97ffe01e 	bl	47f0 <fwp_rc_forget_slot>
    c77c:	17fffe01 	b	bf80 <f0+0x1e40>
    c780:	aa1703e0 	mov	x0, x23
    c784:	97ffe01b 	bl	47f0 <fwp_rc_forget_slot>
    c788:	17fffe56 	b	c0e0 <f0+0x1fa0>
    c78c:	aa1703e0 	mov	x0, x23
    c790:	97ffe018 	bl	47f0 <fwp_rc_forget_slot>
    c794:	17fffe81 	b	c198 <f0+0x2058>
    c798:	aa1703e0 	mov	x0, x23
    c79c:	97ffe015 	bl	47f0 <fwp_rc_forget_slot>
    c7a0:	17fffeac 	b	c250 <f0+0x2110>
    c7a4:	97ffd837 	bl	2880 <__stack_chk_fail@plt>
    c7a8:	d503201f 	nop
    c7ac:	d503201f 	nop

000000000000c7b0 <fwp_main_thread>:
    c7b0:	d10443ff 	sub	sp, sp, #0x110
    c7b4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c7b8:	f947f400 	ldr	x0, [x0, #4072]
    c7bc:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c7c0:	910303fd 	add	x29, sp, #0xc0
    c7c4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c7c8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c7cc:	91174261 	add	x1, x19, #0x5d0
    c7d0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c7d4:	b953a421 	ldr	w1, [x1, #5028]
    c7d8:	f9400002 	ldr	x2, [x0]
    c7dc:	f9005fe2 	str	x2, [sp, #184]
    c7e0:	d2800002 	mov	x2, #0x0                   	// #0
    c7e4:	34002821 	cbz	w1, cce8 <fwp_main_thread+0x538>
    c7e8:	91174273 	add	x19, x19, #0x5d0
    c7ec:	b953aa60 	ldr	w0, [x19, #5032]
    c7f0:	35002740 	cbnz	w0, ccd8 <fwp_main_thread+0x528>
    c7f4:	91001fe2 	add	x2, sp, #0x7
    c7f8:	900000b5 	adrp	x21, 20000 <__data_start>
    c7fc:	900000a3 	adrp	x3, 20000 <__data_start>
    c800:	9101c2b3 	add	x19, x21, #0x70
    c804:	910fc063 	add	x3, x3, #0x3f0
    c808:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c80c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c810:	910023e0 	add	x0, sp, #0x8
    c814:	d2800001 	mov	x1, #0x0                   	// #0
    c818:	f90007e3 	str	x3, [sp, #8]
    c81c:	b90013ff 	str	wzr, [sp, #16]
    c820:	a9019262 	stp	x2, x4, [x19, #24]
    c824:	f9000fe5 	str	x5, [sp, #24]
    c828:	97ffd7ae 	bl	26e0 <sigaltstack@plt>
    c82c:	350026e0 	cbnz	w0, cd08 <fwp_main_thread+0x558>
    c830:	4f000400 	movi	v0.4s, #0x0
    c834:	9100a3e0 	add	x0, sp, #0x28
    c838:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c83c:	52800082 	mov	w2, #0x4                   	// #4
    c840:	9101c021 	add	x1, x1, #0x70
    c844:	72a10002 	movk	w2, #0x800, lsl #16
    c848:	910083f4 	add	x20, sp, #0x20
    c84c:	f90013e1 	str	x1, [sp, #32]
    c850:	3d802000 	str	q0, [x0, #128]
    c854:	b900abe2 	str	w2, [sp, #168]
    c858:	ad000000 	stp	q0, q0, [x0]
    c85c:	ad010000 	stp	q0, q0, [x0, #32]
    c860:	ad020000 	stp	q0, q0, [x0, #64]
    c864:	ad030000 	stp	q0, q0, [x0, #96]
    c868:	97ffd7f6 	bl	2840 <sigemptyset@plt>
    c86c:	350024e0 	cbnz	w0, cd08 <fwp_main_thread+0x558>
    c870:	aa1403e1 	mov	x1, x20
    c874:	d2800002 	mov	x2, #0x0                   	// #0
    c878:	52800160 	mov	w0, #0xb                   	// #11
    c87c:	97ffd809 	bl	28a0 <sigaction@plt>
    c880:	35002440 	cbnz	w0, cd08 <fwp_main_thread+0x558>
    c884:	aa1403e1 	mov	x1, x20
    c888:	d2800002 	mov	x2, #0x0                   	// #0
    c88c:	528000e0 	mov	w0, #0x7                   	// #7
    c890:	97ffd804 	bl	28a0 <sigaction@plt>
    c894:	350023a0 	cbnz	w0, cd08 <fwp_main_thread+0x558>
    c898:	b9434a60 	ldr	w0, [x19, #840]
    c89c:	34002000 	cbz	w0, cc9c <fwp_main_thread+0x4ec>
    c8a0:	9101c2b3 	add	x19, x21, #0x70
    c8a4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c8a8:	b9434e60 	ldr	w0, [x19, #844]
    c8ac:	340020c0 	cbz	w0, ccc4 <fwp_main_thread+0x514>
    c8b0:	9101c2b6 	add	x22, x21, #0x70
    c8b4:	f9400ad4 	ldr	x20, [x22, #16]
    c8b8:	b40010f4 	cbz	x20, cad4 <fwp_main_thread+0x324>
    c8bc:	aa1403f3 	mov	x19, x20
    c8c0:	91010297 	add	x23, x20, #0x40
    c8c4:	f90083f9 	str	x25, [sp, #256]
    c8c8:	52800038 	mov	w24, #0x1                   	// #1
    c8cc:	39414a99 	ldrb	w25, [x20, #82]
    c8d0:	39014a98 	strb	w24, [x20, #82]
    c8d4:	f9401680 	ldr	x0, [x20, #40]
    c8d8:	b4000620 	cbz	x0, c99c <fwp_main_thread+0x1ec>
    c8dc:	f9403281 	ldr	x1, [x20, #96]
    c8e0:	39414680 	ldrb	w0, [x20, #81]
    c8e4:	b4000b61 	cbz	x1, ca50 <fwp_main_thread+0x2a0>
    c8e8:	36000aa0 	tbz	w0, #0, ca3c <fwp_main_thread+0x28c>
    c8ec:	39414a62 	ldrb	w2, [x19, #82]
    c8f0:	f9402280 	ldr	x0, [x20, #64]
    c8f4:	37000d82 	tbnz	w2, #0, caa4 <fwp_main_thread+0x2f4>
    c8f8:	f9403261 	ldr	x1, [x19, #96]
    c8fc:	a911fe77 	stp	x23, xzr, [x19, #280]
    c900:	f9009660 	str	x0, [x19, #296]
    c904:	b4000040 	cbz	x0, c90c <fwp_main_thread+0x15c>
    c908:	f9009013 	str	x19, [x0, #288]
    c90c:	f9002293 	str	x19, [x20, #64]
    c910:	b4000101 	cbz	x1, c930 <fwp_main_thread+0x180>
    c914:	f9406ec0 	ldr	x0, [x22, #216]
    c918:	39015678 	strb	w24, [x19, #85]
    c91c:	f9003661 	str	x1, [x19, #104]
    c920:	a910827f 	stp	xzr, x0, [x19, #264]
    c924:	b4000040 	cbz	x0, c92c <fwp_main_thread+0x17c>
    c928:	f9008413 	str	x19, [x0, #264]
    c92c:	f9006ed3 	str	x19, [x22, #216]
    c930:	39015a7f 	strb	wzr, [x19, #86]
    c934:	97ffe75c 	bl	66a4 <fwp_block>
    c938:	f9408e62 	ldr	x2, [x19, #280]
    c93c:	b4000142 	cbz	x2, c964 <fwp_main_thread+0x1b4>
    c940:	a9520261 	ldp	x1, x0, [x19, #288]
    c944:	b4000bc1 	cbz	x1, cabc <fwp_main_thread+0x30c>
    c948:	f9009420 	str	x0, [x1, #296]
    c94c:	f9409660 	ldr	x0, [x19, #296]
    c950:	b4000040 	cbz	x0, c958 <fwp_main_thread+0x1a8>
    c954:	f9009001 	str	x1, [x0, #288]
    c958:	91080260 	add	x0, x19, #0x200
    c95c:	f900967f 	str	xzr, [x19, #296]
    c960:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c964:	39415660 	ldrb	w0, [x19, #85]
    c968:	f9400ac2 	ldr	x2, [x22, #16]
    c96c:	36000980 	tbz	w0, #0, ca9c <fwp_main_thread+0x2ec>
    c970:	a9508261 	ldp	x1, x0, [x19, #264]
    c974:	b4000a81 	cbz	x1, cac4 <fwp_main_thread+0x314>
    c978:	f9008820 	str	x0, [x1, #272]
    c97c:	b4000040 	cbz	x0, c984 <fwp_main_thread+0x1d4>
    c980:	f9008401 	str	x1, [x0, #264]
    c984:	91080260 	add	x0, x19, #0x200
    c988:	3901567f 	strb	wzr, [x19, #85]
    c98c:	aa0203f3 	mov	x19, x2
    c990:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c994:	f9401680 	ldr	x0, [x20, #40]
    c998:	b5fffa20 	cbnz	x0, c8dc <fwp_main_thread+0x12c>
    c99c:	9101c2a0 	add	x0, x21, #0x70
    c9a0:	39014a99 	strb	w25, [x20, #82]
    c9a4:	f94083f9 	ldr	x25, [sp, #256]
    c9a8:	f9419400 	ldr	x0, [x0, #808]
    c9ac:	b4001580 	cbz	x0, cc5c <fwp_main_thread+0x4ac>
    c9b0:	9101c2a0 	add	x0, x21, #0x70
    c9b4:	f941b001 	ldr	x1, [x0, #864]
    c9b8:	b903581f 	str	wzr, [x0, #856]
    c9bc:	eb13003f 	cmp	x1, x19
    c9c0:	540016a1 	b.ne	cc94 <fwp_main_thread+0x4e4>  // b.any
    c9c4:	b4000933 	cbz	x19, cae8 <fwp_main_thread+0x338>
    c9c8:	9101c2a0 	add	x0, x21, #0x70
    c9cc:	52800021 	mov	w1, #0x1                   	// #1
    c9d0:	39014a61 	strb	w1, [x19, #82]
    c9d4:	f9418005 	ldr	x5, [x0, #768]
    c9d8:	b4000885 	cbz	x5, cae8 <fwp_main_thread+0x338>
    c9dc:	d503201f 	nop
    c9e0:	394140a0 	ldrb	w0, [x5, #80]
    c9e4:	37000060 	tbnz	w0, #0, c9f0 <fwp_main_thread+0x240>
    c9e8:	aa0503e0 	mov	x0, x5
    c9ec:	97ffdb41 	bl	36f0 <fwp_cancel_tree.part.0>
    c9f0:	f9409ca5 	ldr	x5, [x5, #312]
    c9f4:	b5ffff65 	cbnz	x5, c9e0 <fwp_main_thread+0x230>
    c9f8:	9101c2b4 	add	x20, x21, #0x70
    c9fc:	52800036 	mov	w22, #0x1                   	// #1
    ca00:	f9402a60 	ldr	x0, [x19, #80]
    ca04:	f2001c1f 	tst	x0, #0xff000000ff
    ca08:	540000e1 	b.ne	ca24 <fwp_main_thread+0x274>  // b.any
    ca0c:	f9403e80 	ldr	x0, [x20, #120]
    ca10:	39015276 	strb	w22, [x19, #84]
    ca14:	f900827f 	str	xzr, [x19, #256]
    ca18:	b40005a0 	cbz	x0, cacc <fwp_main_thread+0x31c>
    ca1c:	f9008013 	str	x19, [x0, #256]
    ca20:	f9003e93 	str	x19, [x20, #120]
    ca24:	97ffe720 	bl	66a4 <fwp_block>
    ca28:	97ffe6b2 	bl	64f0 <fwp_free_zombie>
    ca2c:	f9418280 	ldr	x0, [x20, #768]
    ca30:	b40005c0 	cbz	x0, cae8 <fwp_main_thread+0x338>
    ca34:	f941b293 	ldr	x19, [x20, #864]
    ca38:	17fffff2 	b	ca00 <fwp_main_thread+0x250>
    ca3c:	97ffdbd1 	bl	3980 <fwp_now_ns>
    ca40:	f9403281 	ldr	x1, [x20, #96]
    ca44:	eb01001f 	cmp	x0, x1
    ca48:	54000fca 	b.ge	cc40 <fwp_main_thread+0x490>  // b.tcont
    ca4c:	39414680 	ldrb	w0, [x20, #81]
    ca50:	39414a62 	ldrb	w2, [x19, #82]
    ca54:	3707f4e0 	tbnz	w0, #0, c8f0 <fwp_main_thread+0x140>
    ca58:	f9403281 	ldr	x1, [x20, #96]
    ca5c:	370001c2 	tbnz	w2, #0, ca94 <fwp_main_thread+0x2e4>
    ca60:	f9403260 	ldr	x0, [x19, #96]
    ca64:	b4000180 	cbz	x0, ca94 <fwp_main_thread+0x2e4>
    ca68:	b4000061 	cbz	x1, ca74 <fwp_main_thread+0x2c4>
    ca6c:	eb01001f 	cmp	x0, x1
    ca70:	9a81d000 	csel	x0, x0, x1, le
    ca74:	f9402281 	ldr	x1, [x20, #64]
    ca78:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca7c:	f9009661 	str	x1, [x19, #296]
    ca80:	b4001381 	cbz	x1, ccf0 <fwp_main_thread+0x540>
    ca84:	f9009033 	str	x19, [x1, #288]
    ca88:	aa0003e1 	mov	x1, x0
    ca8c:	f9002293 	str	x19, [x20, #64]
    ca90:	17ffffa1 	b	c914 <fwp_main_thread+0x164>
    ca94:	f9402280 	ldr	x0, [x20, #64]
    ca98:	17ffff99 	b	c8fc <fwp_main_thread+0x14c>
    ca9c:	aa0203f3 	mov	x19, x2
    caa0:	17ffff8d 	b	c8d4 <fwp_main_thread+0x124>
    caa4:	a911fe77 	stp	x23, xzr, [x19, #280]
    caa8:	f9009660 	str	x0, [x19, #296]
    caac:	b4000040 	cbz	x0, cab4 <fwp_main_thread+0x304>
    cab0:	f9009013 	str	x19, [x0, #288]
    cab4:	f9002293 	str	x19, [x20, #64]
    cab8:	17ffff9e 	b	c930 <fwp_main_thread+0x180>
    cabc:	f9000040 	str	x0, [x2]
    cac0:	17ffffa4 	b	c950 <fwp_main_thread+0x1a0>
    cac4:	f9006ec0 	str	x0, [x22, #216]
    cac8:	17ffffad 	b	c97c <fwp_main_thread+0x1cc>
    cacc:	f9004293 	str	x19, [x20, #128]
    cad0:	17ffffd4 	b	ca20 <fwp_main_thread+0x270>
    cad4:	f94196c0 	ldr	x0, [x22, #808]
    cad8:	b4000c00 	cbz	x0, cc58 <fwp_main_thread+0x4a8>
    cadc:	f941b2c0 	ldr	x0, [x22, #864]
    cae0:	b9035adf 	str	wzr, [x22, #856]
    cae4:	b5000d80 	cbnz	x0, cc94 <fwp_main_thread+0x4e4>
    cae8:	9101c2b4 	add	x20, x21, #0x70
    caec:	97ffe681 	bl	64f0 <fwp_free_zombie>
    caf0:	f9404280 	ldr	x0, [x20, #128]
    caf4:	b5000d00 	cbnz	x0, cc94 <fwp_main_thread+0x4e4>
    caf8:	f9406e80 	ldr	x0, [x20, #216]
    cafc:	b5000cc0 	cbnz	x0, cc94 <fwp_main_thread+0x4e4>
    cb00:	b940fa93 	ldr	w19, [x20, #248]
    cb04:	340001d3 	cbz	w19, cb3c <fwp_main_thread+0x38c>
    cb08:	93407e76 	sxtw	x22, w19
    cb0c:	51000673 	sub	w19, w19, #0x1
    cb10:	d1000ad6 	sub	x22, x22, #0x2
    cb14:	91040297 	add	x23, x20, #0x100
    cb18:	cb3342d6 	sub	x22, x22, w19, uxtw
    cb1c:	93407e73 	sxtw	x19, w19
    cb20:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cb24:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cb28:	b900fa93 	str	w19, [x20, #248]
    cb2c:	d1000673 	sub	x19, x19, #0x1
    cb30:	97ffd79c 	bl	29a0 <munmap@plt>
    cb34:	eb16027f 	cmp	x19, x22
    cb38:	54ffff41 	b.ne	cb20 <fwp_main_thread+0x370>  // b.any
    cb3c:	900000b3 	adrp	x19, 20000 <__data_start>
    cb40:	91004260 	add	x0, x19, #0x10
    cb44:	b9404800 	ldr	w0, [x0, #72]
    cb48:	37f80040 	tbnz	w0, #31, cb50 <fwp_main_thread+0x3a0>
    cb4c:	97ffd751 	bl	2890 <close@plt>
    cb50:	9101c2a0 	add	x0, x21, #0x70
    cb54:	91004261 	add	x1, x19, #0x10
    cb58:	12800002 	mov	w2, #0xffffffff            	// #-1
    cb5c:	d2800013 	mov	x19, #0x0                   	// #0
    cb60:	f941b416 	ldr	x22, [x0, #872]
    cb64:	b9004822 	str	w2, [x1, #72]
    cb68:	f941b814 	ldr	x20, [x0, #880]
    cb6c:	b4000176 	cbz	x22, cb98 <fwp_main_thread+0x3e8>
    cb70:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cb74:	b40000c0 	cbz	x0, cb8c <fwp_main_thread+0x3dc>
    cb78:	f9400001 	ldr	x1, [x0]
    cb7c:	b50008c1 	cbnz	x1, cc94 <fwp_main_thread+0x4e4>
    cb80:	f9400401 	ldr	x1, [x0, #8]
    cb84:	b5000881 	cbnz	x1, cc94 <fwp_main_thread+0x4e4>
    cb88:	97ffdfba 	bl	4a70 <fwp_mem_free>
    cb8c:	91000673 	add	x19, x19, #0x1
    cb90:	eb16027f 	cmp	x19, x22
    cb94:	54fffee1 	b.ne	cb70 <fwp_main_thread+0x3c0>  // b.any
    cb98:	aa1403e0 	mov	x0, x20
    cb9c:	97ffdfb5 	bl	4a70 <fwp_mem_free>
    cba0:	9101c2a0 	add	x0, x21, #0x70
    cba4:	f941b013 	ldr	x19, [x0, #864]
    cba8:	f901b41f 	str	xzr, [x0, #872]
    cbac:	f901b81f 	str	xzr, [x0, #880]
    cbb0:	b40001f3 	cbz	x19, cbec <fwp_main_thread+0x43c>
    cbb4:	f9401661 	ldr	x1, [x19, #40]
    cbb8:	b50006e1 	cbnz	x1, cc94 <fwp_main_thread+0x4e4>
    cbbc:	f9405661 	ldr	x1, [x19, #168]
    cbc0:	b50006a1 	cbnz	x1, cc94 <fwp_main_thread+0x4e4>
    cbc4:	f9419401 	ldr	x1, [x0, #808]
    cbc8:	b5000661 	cbnz	x1, cc94 <fwp_main_thread+0x4e4>
    cbcc:	f9419c00 	ldr	x0, [x0, #824]
    cbd0:	b5000620 	cbnz	x0, cc94 <fwp_main_thread+0x4e4>
    cbd4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cbd8:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    cbdc:	910fc000 	add	x0, x0, #0x3f0
    cbe0:	97ffd71c 	bl	2850 <memset@plt>
    cbe4:	aa1303e0 	mov	x0, x19
    cbe8:	97ffdfa2 	bl	4a70 <fwp_mem_free>
    cbec:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cbf0:	f947ec00 	ldr	x0, [x0, #4056]
    cbf4:	9101c2b5 	add	x21, x21, #0x70
    cbf8:	f9400000 	ldr	x0, [x0]
    cbfc:	f9000abf 	str	xzr, [x21, #16]
    cc00:	f901b2bf 	str	xzr, [x21, #864]
    cc04:	97ffd76b 	bl	29b0 <fflush@plt>
    cc08:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    cc0c:	f947f400 	ldr	x0, [x0, #4072]
    cc10:	f9405fe2 	ldr	x2, [sp, #184]
    cc14:	f9400001 	ldr	x1, [x0]
    cc18:	eb010042 	subs	x2, x2, x1
    cc1c:	d2800001 	mov	x1, #0x0                   	// #0
    cc20:	54000821 	b.ne	cd24 <fwp_main_thread+0x574>  // b.any
    cc24:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cc28:	d2800000 	mov	x0, #0x0                   	// #0
    cc2c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cc30:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cc34:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cc38:	910443ff 	add	sp, sp, #0x110
    cc3c:	d65f03c0 	ret
    cc40:	39414280 	ldrb	w0, [x20, #80]
    cc44:	3707f040 	tbnz	w0, #0, ca4c <fwp_main_thread+0x29c>
    cc48:	aa1403e0 	mov	x0, x20
    cc4c:	97ffdaa9 	bl	36f0 <fwp_cancel_tree.part.0>
    cc50:	39414680 	ldrb	w0, [x20, #81]
    cc54:	17ffff7f 	b	ca50 <fwp_main_thread+0x2a0>
    cc58:	d2800013 	mov	x19, #0x0                   	// #0
    cc5c:	9101c2b4 	add	x20, x21, #0x70
    cc60:	f9419e80 	ldr	x0, [x20, #824]
    cc64:	b5ffea60 	cbnz	x0, c9b0 <fwp_main_thread+0x200>
    cc68:	f9419280 	ldr	x0, [x20, #800]
    cc6c:	97ffdf81 	bl	4a70 <fwp_mem_free>
    cc70:	f901929f 	str	xzr, [x20, #800]
    cc74:	f9019a9f 	str	xzr, [x20, #816]
    cc78:	f941b280 	ldr	x0, [x20, #864]
    cc7c:	b4000413 	cbz	x19, ccfc <fwp_main_thread+0x54c>
    cc80:	f900567f 	str	xzr, [x19, #168]
    cc84:	f9005e7f 	str	xzr, [x19, #184]
    cc88:	b9035a9f 	str	wzr, [x20, #856]
    cc8c:	eb00027f 	cmp	x19, x0
    cc90:	54ffe9c0 	b.eq	c9c8 <fwp_main_thread+0x218>  // b.none
    cc94:	f90083f9 	str	x25, [sp, #256]
    cc98:	97ffd70e 	bl	28d0 <abort@plt>
    cc9c:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    cca0:	91058000 	add	x0, x0, #0x160
    cca4:	940001df 	bl	d420 <atexit>
    cca8:	a90f63f7 	stp	x23, x24, [sp, #240]
    ccac:	35000380 	cbnz	w0, cd1c <fwp_main_thread+0x56c>
    ccb0:	52800020 	mov	w0, #0x1                   	// #1
    ccb4:	b9034a60 	str	w0, [x19, #840]
    ccb8:	9101c2b3 	add	x19, x21, #0x70
    ccbc:	b9434e60 	ldr	w0, [x19, #844]
    ccc0:	35ffdf80 	cbnz	w0, c8b0 <fwp_main_thread+0x100>
    ccc4:	97fff51f 	bl	a140 <f0>
    ccc8:	f901aa60 	str	x0, [x19, #848]
    cccc:	52800021 	mov	w1, #0x1                   	// #1
    ccd0:	b9034e61 	str	w1, [x19, #844]
    ccd4:	17fffef7 	b	c8b0 <fwp_main_thread+0x100>
    ccd8:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    ccdc:	913e8000 	add	x0, x0, #0xfa0
    cce0:	940001d0 	bl	d420 <atexit>
    cce4:	17fffec4 	b	c7f4 <fwp_main_thread+0x44>
    cce8:	97ffdd07 	bl	4104 <fwp_heap_init>
    ccec:	17fffebf 	b	c7e8 <fwp_main_thread+0x38>
    ccf0:	aa0003e1 	mov	x1, x0
    ccf4:	f9002293 	str	x19, [x20, #64]
    ccf8:	17ffff07 	b	c914 <fwp_main_thread+0x164>
    ccfc:	b9035a9f 	str	wzr, [x20, #856]
    cd00:	b4ffef40 	cbz	x0, cae8 <fwp_main_thread+0x338>
    cd04:	17ffffe4 	b	cc94 <fwp_main_thread+0x4e4>
    cd08:	b0000000 	adrp	x0, d000 <__divti3+0x2d0>
    cd0c:	912b0000 	add	x0, x0, #0xac0
    cd10:	a90f63f7 	stp	x23, x24, [sp, #240]
    cd14:	f90083f9 	str	x25, [sp, #256]
    cd18:	97ffdaba 	bl	3800 <fwp_trap>
    cd1c:	f90083f9 	str	x25, [sp, #256]
    cd20:	97ffd904 	bl	3130 <descent_phase_fail>
    cd24:	f90083f9 	str	x25, [sp, #256]
    cd28:	97ffd6d6 	bl	2880 <__stack_chk_fail@plt>
    cd2c:	d503201f 	nop

000000000000cd30 <__divti3>:
    cd30:	d503245f 	bti	c
    cd34:	d2800004 	mov	x4, #0x0                   	// #0
    cd38:	b7f80721 	tbnz	x1, #63, ce1c <__divti3+0xec>
    cd3c:	b6f80083 	tbz	x3, #63, cd4c <__divti3+0x1c>
    cd40:	eb0203e2 	negs	x2, x2
    cd44:	aa2403e4 	mvn	x4, x4
    cd48:	da0303e3 	ngc	x3, x3
    cd4c:	aa0203e6 	mov	x6, x2
    cd50:	aa0003e7 	mov	x7, x0
    cd54:	aa0103e5 	mov	x5, x1
    cd58:	b5000583 	cbnz	x3, ce08 <__divti3+0xd8>
    cd5c:	eb01005f 	cmp	x2, x1
    cd60:	54000e69 	b.ls	cf2c <__divti3+0x1fc>  // b.plast
    cd64:	dac01040 	clz	x0, x2
    cd68:	b40000e0 	cbz	x0, cd84 <__divti3+0x54>
    cd6c:	4b0003e1 	neg	w1, w0
    cd70:	9ac020a5 	lsl	x5, x5, x0
    cd74:	9ac02046 	lsl	x6, x2, x0
    cd78:	9ac124e1 	lsr	x1, x7, x1
    cd7c:	aa050025 	orr	x5, x1, x5
    cd80:	9ac020e7 	lsl	x7, x7, x0
    cd84:	d360fcc8 	lsr	x8, x6, #32
    cd88:	92407cc2 	and	x2, x6, #0xffffffff
    cd8c:	9ac808a3 	udiv	x3, x5, x8
    cd90:	9b089465 	msub	x5, x3, x8, x5
    cd94:	aa0303e0 	mov	x0, x3
    cd98:	9b037c41 	mul	x1, x2, x3
    cd9c:	93c780a5 	extr	x5, x5, x7, #32
    cda0:	eb05003f 	cmp	x1, x5
    cda4:	540000a9 	b.ls	cdb8 <__divti3+0x88>  // b.plast
    cda8:	ab0500c5 	adds	x5, x6, x5
    cdac:	d1000460 	sub	x0, x3, #0x1
    cdb0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cdb4:	540015a8 	b.hi	d068 <__divti3+0x338>  // b.pmore
    cdb8:	cb0100a5 	sub	x5, x5, x1
    cdbc:	9ac808a3 	udiv	x3, x5, x8
    cdc0:	9b089465 	msub	x5, x3, x8, x5
    cdc4:	aa0303e1 	mov	x1, x3
    cdc8:	9b037c42 	mul	x2, x2, x3
    cdcc:	aa0703e3 	mov	x3, x7
    cdd0:	b3607ca3 	bfi	x3, x5, #32, #32
    cdd4:	eb03005f 	cmp	x2, x3
    cdd8:	540000c9 	b.ls	cdf0 <__divti3+0xc0>  // b.plast
    cddc:	ab0300c3 	adds	x3, x6, x3
    cde0:	d1000425 	sub	x5, x1, #0x1
    cde4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cde8:	d1000821 	sub	x1, x1, #0x2
    cdec:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cdf0:	aa008020 	orr	x0, x1, x0, lsl #32
    cdf4:	d2800001 	mov	x1, #0x0                   	// #0
    cdf8:	b4000064 	cbz	x4, ce04 <__divti3+0xd4>
    cdfc:	eb0003e0 	negs	x0, x0
    ce00:	da0103e1 	ngc	x1, x1
    ce04:	d65f03c0 	ret
    ce08:	eb01007f 	cmp	x3, x1
    ce0c:	54000109 	b.ls	ce2c <__divti3+0xfc>  // b.plast
    ce10:	d2800001 	mov	x1, #0x0                   	// #0
    ce14:	d2800000 	mov	x0, #0x0                   	// #0
    ce18:	17fffff8 	b	cdf8 <__divti3+0xc8>
    ce1c:	eb0003e0 	negs	x0, x0
    ce20:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ce24:	da0103e1 	ngc	x1, x1
    ce28:	17ffffc5 	b	cd3c <__divti3+0xc>
    ce2c:	dac01067 	clz	x7, x3
    ce30:	b40010e7 	cbz	x7, d04c <__divti3+0x31c>
    ce34:	d2800805 	mov	x5, #0x40                  	// #64
    ce38:	cb0700a5 	sub	x5, x5, x7
    ce3c:	9ac72063 	lsl	x3, x3, x7
    ce40:	9ac52448 	lsr	x8, x2, x5
    ce44:	aa030108 	orr	x8, x8, x3
    ce48:	9ac52426 	lsr	x6, x1, x5
    ce4c:	92407d0a 	and	x10, x8, #0xffffffff
    ce50:	d360fd09 	lsr	x9, x8, #32
    ce54:	9ac52403 	lsr	x3, x0, x5
    ce58:	9ac72021 	lsl	x1, x1, x7
    ce5c:	aa010063 	orr	x3, x3, x1
    ce60:	9ac72042 	lsl	x2, x2, x7
    ce64:	9ac908cb 	udiv	x11, x6, x9
    ce68:	9b099965 	msub	x5, x11, x9, x6
    ce6c:	aa0b03e1 	mov	x1, x11
    ce70:	9b0b7d46 	mul	x6, x10, x11
    ce74:	93c380a5 	extr	x5, x5, x3, #32
    ce78:	eb0500df 	cmp	x6, x5
    ce7c:	540000a9 	b.ls	ce90 <__divti3+0x160>  // b.plast
    ce80:	ab050105 	adds	x5, x8, x5
    ce84:	d1000561 	sub	x1, x11, #0x1
    ce88:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ce8c:	54000f48 	b.hi	d074 <__divti3+0x344>  // b.pmore
    ce90:	cb0600a6 	sub	x6, x5, x6
    ce94:	9ac908cb 	udiv	x11, x6, x9
    ce98:	9b099969 	msub	x9, x11, x9, x6
    ce9c:	aa0b03e5 	mov	x5, x11
    cea0:	9b0b7d4a 	mul	x10, x10, x11
    cea4:	b3607d23 	bfi	x3, x9, #32, #32
    cea8:	eb03015f 	cmp	x10, x3
    ceac:	540000a9 	b.ls	cec0 <__divti3+0x190>  // b.plast
    ceb0:	ab030103 	adds	x3, x8, x3
    ceb4:	d1000565 	sub	x5, x11, #0x1
    ceb8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cebc:	54000e28 	b.hi	d080 <__divti3+0x350>  // b.pmore
    cec0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cec4:	92407c48 	and	x8, x2, #0xffffffff
    cec8:	2a0503e5 	mov	w5, w5
    cecc:	d360fc42 	lsr	x2, x2, #32
    ced0:	d360fc26 	lsr	x6, x1, #32
    ced4:	cb0a0063 	sub	x3, x3, x10
    ced8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cedc:	9b087caa 	mul	x10, x5, x8
    cee0:	9b087cc8 	mul	x8, x6, x8
    cee4:	9b0220a5 	madd	x5, x5, x2, x8
    cee8:	9b027cc6 	mul	x6, x6, x2
    ceec:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cef0:	8b0900c5 	add	x5, x6, x9
    cef4:	eb02011f 	cmp	x8, x2
    cef8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cefc:	8b4280c6 	add	x6, x6, x2, lsr #32
    cf00:	eb06007f 	cmp	x3, x6
    cf04:	540000e3 	b.cc	cf20 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cf08:	92407d4a 	and	x10, x10, #0xffffffff
    cf0c:	9ac72000 	lsl	x0, x0, x7
    cf10:	8b028142 	add	x2, x10, x2, lsl #32
    cf14:	eb02001f 	cmp	x0, x2
    cf18:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cf1c:	54000a01 	b.ne	d05c <__divti3+0x32c>  // b.any
    cf20:	d1000420 	sub	x0, x1, #0x1
    cf24:	d2800001 	mov	x1, #0x0                   	// #0
    cf28:	17ffffb4 	b	cdf8 <__divti3+0xc8>
    cf2c:	b5000062 	cbnz	x2, cf38 <__divti3+0x208>
    cf30:	d2800022 	mov	x2, #0x1                   	// #1
    cf34:	9ac30846 	udiv	x6, x2, x3
    cf38:	dac010c8 	clz	x8, x6
    cf3c:	b5000408 	cbnz	x8, cfbc <__divti3+0x28c>
    cf40:	d360fcc9 	lsr	x9, x6, #32
    cf44:	92407cc5 	and	x5, x6, #0xffffffff
    cf48:	cb060023 	sub	x3, x1, x6
    cf4c:	d2800021 	mov	x1, #0x1                   	// #1
    cf50:	9ac90868 	udiv	x8, x3, x9
    cf54:	9b098d03 	msub	x3, x8, x9, x3
    cf58:	aa0803e0 	mov	x0, x8
    cf5c:	9b057d02 	mul	x2, x8, x5
    cf60:	93c78063 	extr	x3, x3, x7, #32
    cf64:	eb03005f 	cmp	x2, x3
    cf68:	540000a9 	b.ls	cf7c <__divti3+0x24c>  // b.plast
    cf6c:	ab0300c3 	adds	x3, x6, x3
    cf70:	d1000500 	sub	x0, x8, #0x1
    cf74:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cf78:	54000968 	b.hi	d0a4 <__divti3+0x374>  // b.pmore
    cf7c:	cb020063 	sub	x3, x3, x2
    cf80:	9ac90862 	udiv	x2, x3, x9
    cf84:	aa0203e8 	mov	x8, x2
    cf88:	9b098c42 	msub	x2, x2, x9, x3
    cf8c:	aa0703e3 	mov	x3, x7
    cf90:	9b057d05 	mul	x5, x8, x5
    cf94:	b3607c43 	bfi	x3, x2, #32, #32
    cf98:	eb0300bf 	cmp	x5, x3
    cf9c:	540000c9 	b.ls	cfb4 <__divti3+0x284>  // b.plast
    cfa0:	ab0300c2 	adds	x2, x6, x3
    cfa4:	d1000503 	sub	x3, x8, #0x1
    cfa8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cfac:	d1000908 	sub	x8, x8, #0x2
    cfb0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cfb4:	aa008100 	orr	x0, x8, x0, lsl #32
    cfb8:	17ffff90 	b	cdf8 <__divti3+0xc8>
    cfbc:	9ac820c6 	lsl	x6, x6, x8
    cfc0:	d2800803 	mov	x3, #0x40                  	// #64
    cfc4:	cb080063 	sub	x3, x3, x8
    cfc8:	d360fcc9 	lsr	x9, x6, #32
    cfcc:	9ac82027 	lsl	x7, x1, x8
    cfd0:	92407cc5 	and	x5, x6, #0xffffffff
    cfd4:	9ac32422 	lsr	x2, x1, x3
    cfd8:	9ac32403 	lsr	x3, x0, x3
    cfdc:	aa070063 	orr	x3, x3, x7
    cfe0:	9ac9084a 	udiv	x10, x2, x9
    cfe4:	9ac82007 	lsl	x7, x0, x8
    cfe8:	9b098940 	msub	x0, x10, x9, x2
    cfec:	aa0a03e1 	mov	x1, x10
    cff0:	9b0a7ca2 	mul	x2, x5, x10
    cff4:	93c38000 	extr	x0, x0, x3, #32
    cff8:	eb00005f 	cmp	x2, x0
    cffc:	540000a9 	b.ls	d010 <__divti3+0x2e0>  // b.plast
    d000:	ab0000c0 	adds	x0, x6, x0
    d004:	d1000541 	sub	x1, x10, #0x1
    d008:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d00c:	54000468 	b.hi	d098 <__divti3+0x368>  // b.pmore
    d010:	cb020000 	sub	x0, x0, x2
    d014:	9ac9080a 	udiv	x10, x0, x9
    d018:	9b098140 	msub	x0, x10, x9, x0
    d01c:	aa0a03e2 	mov	x2, x10
    d020:	9b0a7ca8 	mul	x8, x5, x10
    d024:	b3607c03 	bfi	x3, x0, #32, #32
    d028:	eb03011f 	cmp	x8, x3
    d02c:	540000a9 	b.ls	d040 <__divti3+0x310>  // b.plast
    d030:	ab0300c3 	adds	x3, x6, x3
    d034:	d1000542 	sub	x2, x10, #0x1
    d038:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d03c:	54000288 	b.hi	d08c <__divti3+0x35c>  // b.pmore
    d040:	cb080063 	sub	x3, x3, x8
    d044:	aa018041 	orr	x1, x2, x1, lsl #32
    d048:	17ffffc2 	b	cf50 <__divti3+0x220>
    d04c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d050:	d2800001 	mov	x1, #0x0                   	// #0
    d054:	9a9f87e0 	cset	x0, ls	// ls = plast
    d058:	17ffff68 	b	cdf8 <__divti3+0xc8>
    d05c:	aa0103e0 	mov	x0, x1
    d060:	d2800001 	mov	x1, #0x0                   	// #0
    d064:	17ffff65 	b	cdf8 <__divti3+0xc8>
    d068:	d1000860 	sub	x0, x3, #0x2
    d06c:	8b0600a5 	add	x5, x5, x6
    d070:	17ffff52 	b	cdb8 <__divti3+0x88>
    d074:	d1000961 	sub	x1, x11, #0x2
    d078:	8b0800a5 	add	x5, x5, x8
    d07c:	17ffff85 	b	ce90 <__divti3+0x160>
    d080:	d1000965 	sub	x5, x11, #0x2
    d084:	8b080063 	add	x3, x3, x8
    d088:	17ffff8e 	b	cec0 <__divti3+0x190>
    d08c:	d1000942 	sub	x2, x10, #0x2
    d090:	8b060063 	add	x3, x3, x6
    d094:	17ffffeb 	b	d040 <__divti3+0x310>
    d098:	d1000941 	sub	x1, x10, #0x2
    d09c:	8b060000 	add	x0, x0, x6
    d0a0:	17ffffdc 	b	d010 <__divti3+0x2e0>
    d0a4:	d1000900 	sub	x0, x8, #0x2
    d0a8:	8b060063 	add	x3, x3, x6
    d0ac:	17ffffb4 	b	cf7c <__divti3+0x24c>

000000000000d0b0 <__modti3>:
    d0b0:	d503245f 	bti	c
    d0b4:	d2800004 	mov	x4, #0x0                   	// #0
    d0b8:	b6f80081 	tbz	x1, #63, d0c8 <__modti3+0x18>
    d0bc:	eb0003e0 	negs	x0, x0
    d0c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d0c4:	da0103e1 	ngc	x1, x1
    d0c8:	f100007f 	cmp	x3, #0x0
    d0cc:	5400128b 	b.lt	d31c <__modti3+0x26c>  // b.tstop
    d0d0:	aa0003e7 	mov	x7, x0
    d0d4:	aa0103e6 	mov	x6, x1
    d0d8:	540004e1 	b.ne	d174 <__modti3+0xc4>  // b.any
    d0dc:	eb02003f 	cmp	x1, x2
    d0e0:	54000dc2 	b.cs	d298 <__modti3+0x1e8>  // b.hs, b.nlast
    d0e4:	dac01043 	clz	x3, x2
    d0e8:	aa0303e5 	mov	x5, x3
    d0ec:	b40000e3 	cbz	x3, d108 <__modti3+0x58>
    d0f0:	4b0303e6 	neg	w6, w3
    d0f4:	9ac32021 	lsl	x1, x1, x3
    d0f8:	9ac32042 	lsl	x2, x2, x3
    d0fc:	9ac62406 	lsr	x6, x0, x6
    d100:	aa0100c6 	orr	x6, x6, x1
    d104:	9ac32007 	lsl	x7, x0, x3
    d108:	d360fc40 	lsr	x0, x2, #32
    d10c:	92407c43 	and	x3, x2, #0xffffffff
    d110:	9ac008c1 	udiv	x1, x6, x0
    d114:	9b009826 	msub	x6, x1, x0, x6
    d118:	9b017c61 	mul	x1, x3, x1
    d11c:	93c780c6 	extr	x6, x6, x7, #32
    d120:	eb06003f 	cmp	x1, x6
    d124:	540000a9 	b.ls	d138 <__modti3+0x88>  // b.plast
    d128:	ab060046 	adds	x6, x2, x6
    d12c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d130:	8b0200c8 	add	x8, x6, x2
    d134:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d138:	cb0100c6 	sub	x6, x6, x1
    d13c:	9ac008c8 	udiv	x8, x6, x0
    d140:	9b009901 	msub	x1, x8, x0, x6
    d144:	aa0703e0 	mov	x0, x7
    d148:	9b087c63 	mul	x3, x3, x8
    d14c:	b3607c20 	bfi	x0, x1, #32, #32
    d150:	eb00007f 	cmp	x3, x0
    d154:	54001088 	b.hi	d364 <__modti3+0x2b4>  // b.pmore
    d158:	cb030000 	sub	x0, x0, x3
    d15c:	9ac52400 	lsr	x0, x0, x5
    d160:	d2800001 	mov	x1, #0x0                   	// #0
    d164:	b4000064 	cbz	x4, d170 <__modti3+0xc0>
    d168:	eb0003e0 	negs	x0, x0
    d16c:	da0103e1 	ngc	x1, x1
    d170:	d65f03c0 	ret
    d174:	dac01066 	clz	x6, x3
    d178:	eb03003f 	cmp	x1, x3
    d17c:	54ffff43 	b.cc	d164 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d180:	93407cc5 	sxtw	x5, w6
    d184:	d2800808 	mov	x8, #0x40                  	// #64
    d188:	cb050108 	sub	x8, x8, x5
    d18c:	9ac62063 	lsl	x3, x3, x6
    d190:	9ac62025 	lsl	x5, x1, x6
    d194:	9ac82447 	lsr	x7, x2, x8
    d198:	aa0300e7 	orr	x7, x7, x3
    d19c:	9ac82423 	lsr	x3, x1, x8
    d1a0:	92407cec 	and	x12, x7, #0xffffffff
    d1a4:	d360fcea 	lsr	x10, x7, #32
    d1a8:	9ac82401 	lsr	x1, x0, x8
    d1ac:	aa050021 	orr	x1, x1, x5
    d1b0:	9ac62042 	lsl	x2, x2, x6
    d1b4:	9ac62000 	lsl	x0, x0, x6
    d1b8:	9aca086b 	udiv	x11, x3, x10
    d1bc:	9b0a8d63 	msub	x3, x11, x10, x3
    d1c0:	aa0b03e5 	mov	x5, x11
    d1c4:	9b0b7d89 	mul	x9, x12, x11
    d1c8:	93c18063 	extr	x3, x3, x1, #32
    d1cc:	eb03013f 	cmp	x9, x3
    d1d0:	540000a9 	b.ls	d1e4 <__modti3+0x134>  // b.plast
    d1d4:	ab0300e3 	adds	x3, x7, x3
    d1d8:	d1000565 	sub	x5, x11, #0x1
    d1dc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d1e0:	54001168 	b.hi	d40c <__modti3+0x35c>  // b.pmore
    d1e4:	cb090063 	sub	x3, x3, x9
    d1e8:	9aca086b 	udiv	x11, x3, x10
    d1ec:	9b0a8d6a 	msub	x10, x11, x10, x3
    d1f0:	aa0b03e9 	mov	x9, x11
    d1f4:	9b0b7d8c 	mul	x12, x12, x11
    d1f8:	b3607d41 	bfi	x1, x10, #32, #32
    d1fc:	eb01019f 	cmp	x12, x1
    d200:	540000a9 	b.ls	d214 <__modti3+0x164>  // b.plast
    d204:	ab0100e1 	adds	x1, x7, x1
    d208:	d1000569 	sub	x9, x11, #0x1
    d20c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d210:	54000f88 	b.hi	d400 <__modti3+0x350>  // b.pmore
    d214:	aa058123 	orr	x3, x9, x5, lsl #32
    d218:	92407c4b 	and	x11, x2, #0xffffffff
    d21c:	2a0903e9 	mov	w9, w9
    d220:	d360fc4a 	lsr	x10, x2, #32
    d224:	d360fc63 	lsr	x3, x3, #32
    d228:	cb0c0021 	sub	x1, x1, x12
    d22c:	aa0a03ec 	mov	x12, x10
    d230:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d234:	9b0b7d25 	mul	x5, x9, x11
    d238:	9b0b7c6b 	mul	x11, x3, x11
    d23c:	9b0a2d29 	madd	x9, x9, x10, x11
    d240:	92407caa 	and	x10, x5, #0xffffffff
    d244:	9b0c7c63 	mul	x3, x3, x12
    d248:	8b458125 	add	x5, x9, x5, lsr #32
    d24c:	8b0d0069 	add	x9, x3, x13
    d250:	eb05017f 	cmp	x11, x5
    d254:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d258:	8b058149 	add	x9, x10, x5, lsl #32
    d25c:	8b458063 	add	x3, x3, x5, lsr #32
    d260:	eb03003f 	cmp	x1, x3
    d264:	54000063 	b.cc	d270 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d268:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d26c:	54000082 	b.cs	d27c <__modti3+0x1cc>  // b.hs, b.nlast
    d270:	eb020129 	subs	x9, x9, x2
    d274:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d278:	cb070063 	sub	x3, x3, x7
    d27c:	eb090000 	subs	x0, x0, x9
    d280:	da030021 	sbc	x1, x1, x3
    d284:	9ac62400 	lsr	x0, x0, x6
    d288:	9ac82028 	lsl	x8, x1, x8
    d28c:	aa000100 	orr	x0, x8, x0
    d290:	9ac62421 	lsr	x1, x1, x6
    d294:	17ffffb4 	b	d164 <__modti3+0xb4>
    d298:	b5000062 	cbnz	x2, d2a4 <__modti3+0x1f4>
    d29c:	d2800023 	mov	x3, #0x1                   	// #1
    d2a0:	9ac20862 	udiv	x2, x3, x2
    d2a4:	dac01048 	clz	x8, x2
    d2a8:	aa0803e5 	mov	x5, x8
    d2ac:	b5000668 	cbnz	x8, d378 <__modti3+0x2c8>
    d2b0:	cb020020 	sub	x0, x1, x2
    d2b4:	d360fc49 	lsr	x9, x2, #32
    d2b8:	92407c4a 	and	x10, x2, #0xffffffff
    d2bc:	9ac90801 	udiv	x1, x0, x9
    d2c0:	9b098020 	msub	x0, x1, x9, x0
    d2c4:	9b0a7c21 	mul	x1, x1, x10
    d2c8:	93c78000 	extr	x0, x0, x7, #32
    d2cc:	eb00003f 	cmp	x1, x0
    d2d0:	540000a9 	b.ls	d2e4 <__modti3+0x234>  // b.plast
    d2d4:	ab000040 	adds	x0, x2, x0
    d2d8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d2dc:	8b020003 	add	x3, x0, x2
    d2e0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d2e4:	cb010001 	sub	x1, x0, x1
    d2e8:	9ac90820 	udiv	x0, x1, x9
    d2ec:	9b098403 	msub	x3, x0, x9, x1
    d2f0:	aa0703e1 	mov	x1, x7
    d2f4:	9b0a7c00 	mul	x0, x0, x10
    d2f8:	b3607c61 	bfi	x1, x3, #32, #32
    d2fc:	eb01001f 	cmp	x0, x1
    d300:	540000a9 	b.ls	d314 <__modti3+0x264>  // b.plast
    d304:	ab010041 	adds	x1, x2, x1
    d308:	8b020022 	add	x2, x1, x2
    d30c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d310:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d314:	cb000020 	sub	x0, x1, x0
    d318:	17ffff91 	b	d15c <__modti3+0xac>
    d31c:	eb0203e5 	negs	x5, x2
    d320:	aa0003e7 	mov	x7, x0
    d324:	da0303e8 	ngc	x8, x3
    d328:	aa0503e2 	mov	x2, x5
    d32c:	aa0803e3 	mov	x3, x8
    d330:	aa0103e6 	mov	x6, x1
    d334:	b4ffed48 	cbz	x8, d0dc <__modti3+0x2c>
    d338:	eb01011f 	cmp	x8, x1
    d33c:	54fff148 	b.hi	d164 <__modti3+0xb4>  // b.pmore
    d340:	dac01109 	clz	x9, x8
    d344:	2a0903e6 	mov	w6, w9
    d348:	b5fff1c9 	cbnz	x9, d180 <__modti3+0xd0>
    d34c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d350:	54000068 	b.hi	d35c <__modti3+0x2ac>  // b.pmore
    d354:	eb050007 	subs	x7, x0, x5
    d358:	da080021 	sbc	x1, x1, x8
    d35c:	aa0703e0 	mov	x0, x7
    d360:	17ffff81 	b	d164 <__modti3+0xb4>
    d364:	ab000040 	adds	x0, x2, x0
    d368:	8b020002 	add	x2, x0, x2
    d36c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d370:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d374:	17ffff79 	b	d158 <__modti3+0xa8>
    d378:	9ac82042 	lsl	x2, x2, x8
    d37c:	d2800803 	mov	x3, #0x40                  	// #64
    d380:	cb080063 	sub	x3, x3, x8
    d384:	d360fc49 	lsr	x9, x2, #32
    d388:	9ac82027 	lsl	x7, x1, x8
    d38c:	92407c4a 	and	x10, x2, #0xffffffff
    d390:	9ac32426 	lsr	x6, x1, x3
    d394:	9ac32403 	lsr	x3, x0, x3
    d398:	aa070063 	orr	x3, x3, x7
    d39c:	9ac908c1 	udiv	x1, x6, x9
    d3a0:	9ac82007 	lsl	x7, x0, x8
    d3a4:	9b099820 	msub	x0, x1, x9, x6
    d3a8:	9b017d41 	mul	x1, x10, x1
    d3ac:	93c38000 	extr	x0, x0, x3, #32
    d3b0:	eb00003f 	cmp	x1, x0
    d3b4:	540000a9 	b.ls	d3c8 <__modti3+0x318>  // b.plast
    d3b8:	ab000040 	adds	x0, x2, x0
    d3bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3c0:	8b020006 	add	x6, x0, x2
    d3c4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d3c8:	cb010000 	sub	x0, x0, x1
    d3cc:	9ac90801 	udiv	x1, x0, x9
    d3d0:	9b098026 	msub	x6, x1, x9, x0
    d3d4:	aa0303e0 	mov	x0, x3
    d3d8:	9b017d41 	mul	x1, x10, x1
    d3dc:	b3607cc0 	bfi	x0, x6, #32, #32
    d3e0:	eb00003f 	cmp	x1, x0
    d3e4:	540000a9 	b.ls	d3f8 <__modti3+0x348>  // b.plast
    d3e8:	ab000040 	adds	x0, x2, x0
    d3ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3f0:	8b020003 	add	x3, x0, x2
    d3f4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d3f8:	cb010000 	sub	x0, x0, x1
    d3fc:	17ffffb0 	b	d2bc <__modti3+0x20c>
    d400:	d1000969 	sub	x9, x11, #0x2
    d404:	8b070021 	add	x1, x1, x7
    d408:	17ffff83 	b	d214 <__modti3+0x164>
    d40c:	d1000965 	sub	x5, x11, #0x2
    d410:	8b070063 	add	x3, x3, x7
    d414:	17ffff74 	b	d1e4 <__modti3+0x134>
    d418:	d503201f 	nop
    d41c:	d503201f 	nop

000000000000d420 <atexit>:
    d420:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d424:	f0000082 	adrp	x2, 20000 <__data_start>
    d428:	d2800001 	mov	x1, #0x0                   	// #0
    d42c:	910003fd 	mov	x29, sp
    d430:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d434:	f9400442 	ldr	x2, [x2, #8]
    d438:	17ffd4d2 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d43c <_fini>:
    d43c:	d503201f 	nop
    d440:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d444:	910003fd 	mov	x29, sp
    d448:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d44c:	d65f03c0 	ret
