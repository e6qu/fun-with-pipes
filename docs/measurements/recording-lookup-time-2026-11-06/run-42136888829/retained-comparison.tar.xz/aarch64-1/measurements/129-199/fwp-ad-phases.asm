
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000045 	adrp	x5, d000 <__modti3+0x320>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	910ce0a5 	add	x5, x5, #0x338
    2b20:	f0000044 	adrp	x4, d000 <__modti3+0x320>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	910d0084 	add	x4, x4, #0x340
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xed60>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2bb4:	911c6000 	add	x0, x0, #0x718
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000042 	adrp	x2, c000 <f0+0x22b0>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	910f8042 	add	x2, x2, #0x3e0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2cfc:	911ca000 	add	x0, x0, #0x728
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2d0c:	911f2000 	add	x0, x0, #0x7c8
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2d24:	911e8000 	add	x0, x0, #0x7a0
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2d30:	911dc000 	add	x0, x0, #0x770
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	f0000040 	adrp	x0, d000 <__modti3+0x320>
    2d3c:	911d2000 	add	x0, x0, #0x748
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	f0000041 	adrp	x1, d000 <__modti3+0x320>
    2f34:	91394021 	add	x1, x1, #0xe50
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    30d0:	91022000 	add	x0, x0, #0x88
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3198:	9138c021 	add	x1, x1, #0xe30
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    31d0:	91028000 	add	x0, x0, #0xa0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000042 	adrp	x2, d000 <__modti3+0x320>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000056 	adrp	x22, d000 <__modti3+0x320>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000058 	adrp	x24, d000 <__modti3+0x320>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	9103a042 	add	x2, x2, #0xe8
    3260:	910502d6 	add	x22, x22, #0x140
    3264:	912f4318 	add	x24, x24, #0xbd0
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000059 	adrp	x25, d000 <__modti3+0x320>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	9104e323 	add	x3, x25, #0x138
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	91054000 	add	x0, x0, #0x150
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    35f0:	91022000 	add	x0, x0, #0x88
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3830:	aa1303e0 	mov	x0, x19
    3834:	91056021 	add	x1, x1, #0x158
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91058021 	add	x1, x1, #0x160
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3860:	9105a021 	add	x1, x1, #0x168
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	d0000042 	adrp	x2, d000 <__modti3+0x320>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	9105c042 	add	x2, x2, #0x170
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    39d0:	91022000 	add	x0, x0, #0x88
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    39f0:	91060000 	add	x0, x0, #0x180
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3a88:	91068000 	add	x0, x0, #0x1a0
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3a98:	91070000 	add	x0, x0, #0x1c0
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	d0000041 	adrp	x1, d000 <__modti3+0x320>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc39820 	ldr	q0, [x1, #3680]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3b98:	9107a000 	add	x0, x0, #0x1e8
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	d0000040 	adrp	x0, d000 <__modti3+0x320>
    3c08:	91086000 	add	x0, x0, #0x218
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	d0000044 	adrp	x4, d000 <__modti3+0x320>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	9109a084 	add	x4, x4, #0x268
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	d0000044 	adrp	x4, d000 <__modti3+0x320>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	910a0084 	add	x4, x4, #0x280
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	d0000044 	adrp	x4, d000 <__modti3+0x320>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	9109c084 	add	x4, x4, #0x270
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    4028:	91174042 	add	x2, x2, #0x5d0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	b0000041 	adrp	x1, d000 <__modti3+0x320>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	910a2021 	add	x1, x1, #0x288
    4084:	910a4000 	add	x0, x0, #0x290
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	b0000042 	adrp	x2, d000 <__modti3+0x320>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	910ac042 	add	x2, x2, #0x2b0
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    418c:	91134061 	add	x1, x3, #0x4d0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    419c:	91174262 	add	x2, x19, #0x5d0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	b0000042 	adrp	x2, d000 <__modti3+0x320>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    41cc:	91144021 	add	x1, x1, #0x510
    41d0:	3dc39c43 	ldr	q3, [x2, #3696]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    41fc:	91134063 	add	x3, x3, #0x4d0
    4200:	9115c084 	add	x4, x4, #0x570
    4204:	91174266 	add	x6, x19, #0x5d0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91174275 	add	x21, x19, #0x5d0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    42e8:	910d8000 	add	x0, x0, #0x360
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91174273 	add	x19, x19, #0x5d0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	9101c122 	add	x2, x9, #0x70
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	9101c120 	add	x0, x9, #0x70
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	9101c129 	add	x9, x9, #0x70
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    444c:	910dc000 	add	x0, x0, #0x370
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	910dc000 	add	x0, x0, #0x370
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	9101c2d6 	add	x22, x22, #0x70
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	910dc000 	add	x0, x0, #0x370
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	9101c281 	add	x1, x20, #0x70
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	9101c280 	add	x0, x20, #0x70
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	9101c288 	add	x8, x20, #0x70
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	9101c281 	add	x1, x20, #0x70
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    473c:	910e2000 	add	x0, x0, #0x388
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911742a2 	add	x2, x21, #0x5d0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    47f4:	910f8000 	add	x0, x0, #0x3e0
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911742b5 	add	x21, x21, #0x5d0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4850:	910ee000 	add	x0, x0, #0x3b8
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4860:	91102000 	add	x0, x0, #0x408
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    48a0:	91174262 	add	x2, x19, #0x5d0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91174273 	add	x19, x19, #0x5d0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	b0000040 	adrp	x0, d000 <__modti3+0x320>
    4900:	910f8000 	add	x0, x0, #0x3e0
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4920:	911742c2 	add	x2, x22, #0x5d0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911742c2 	add	x2, x22, #0x5d0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911742d6 	add	x22, x22, #0x5d0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a40:	911742b5 	add	x21, x21, #0x5d0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4b04:	911742a1 	add	x1, x21, #0x5d0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911742b5 	add	x21, x21, #0x5d0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911742a1 	add	x1, x21, #0x5d0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911742a0 	add	x0, x21, #0x5d0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911742b5 	add	x21, x21, #0x5d0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d08:	91174359 	add	x25, x26, #0x5d0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	5400118b 	b.lt	53dc <fwp_p_ad_push+0x238>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	910003fd 	mov	x29, sp
    51b8:	a90153f3 	stp	x19, x20, [sp, #16]
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0403f6 	mov	x22, x4
    51c4:	aa0003f5 	mov	x21, x0
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f8 	mov	x24, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	aa020001 	orr	x1, x0, x2
    51e0:	b6f80dc1 	tbz	x1, #63, 5398 <fwp_p_ad_push+0x1f4>
    51e4:	9360fc14 	asr	x20, x0, #32
    51e8:	b6f800c0 	tbz	x0, #63, 5200 <fwp_p_ad_push+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc54 	asr	x20, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5200:	b4001136 	cbz	x22, 5424 <fwp_p_ad_push+0x280>
    5204:	f94002c0 	ldr	x0, [x22]
    5208:	eb14001f 	cmp	x0, x20
    520c:	54000e40 	b.eq	53d4 <fwp_p_ad_push+0x230>  // b.none
    5210:	aa1403e0 	mov	x0, x20
    5214:	97fffa67 	bl	3bb0 <fwp_tape_of>
    5218:	aa0003f3 	mov	x19, x0
    521c:	f9403000 	ldr	x0, [x0, #96]
    5220:	b50010c0 	cbnz	x0, 5438 <fwp_p_ad_push+0x294>
    5224:	a9004ed4 	stp	x20, x19, [x22]
    5228:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    522c:	f9400a77 	ldr	x23, [x19, #16]
    5230:	a9046bf9 	stp	x25, x26, [sp, #64]
    5234:	eb0002ff 	cmp	x23, x0
    5238:	540013ec 	b.gt	54b4 <fwp_p_ad_push+0x310>
    523c:	eb3542ff 	cmp	x23, w21, uxtw
    5240:	5400132d 	b.le	54a4 <fwp_p_ad_push+0x300>
    5244:	b7f80078 	tbnz	x24, #63, 5250 <fwp_p_ad_push+0xac>
    5248:	eb3842ff 	cmp	x23, w24, uxtw
    524c:	540012cd 	b.le	54a4 <fwp_p_ad_push+0x300>
    5250:	f9400676 	ldr	x22, [x19, #8]
    5254:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5258:	cb1602f6 	sub	x22, x23, x22
    525c:	910006c1 	add	x1, x22, #0x1
    5260:	aa1603f9 	mov	x25, x22
    5264:	eb00003f 	cmp	x1, x0
    5268:	54001268 	b.hi	54b4 <fwp_p_ad_push+0x310>  // b.pmore
    526c:	a9418274 	ldp	x20, x0, [x19, #24]
    5270:	eb14003f 	cmp	x1, x20
    5274:	54000a6d 	b.le	53c0 <fwp_p_ad_push+0x21c>
    5278:	f100029f 	cmp	x20, #0x0
    527c:	d2800803 	mov	x3, #0x40                  	// #64
    5280:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5284:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5288:	a90573fb 	stp	x27, x28, [sp, #80]
    528c:	eb14003f 	cmp	x1, x20
    5290:	5400008d 	b.le	52a0 <fwp_p_ad_push+0xfc>
    5294:	eb02029f 	cmp	x20, x2
    5298:	5400090d 	b.le	53b8 <fwp_p_ad_push+0x214>
    529c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    52a0:	d37df29a 	lsl	x26, x20, #3
    52a4:	f940327b 	ldr	x27, [x19, #96]
    52a8:	aa1a03e1 	mov	x1, x26
    52ac:	97fff595 	bl	2900 <realloc@plt>
    52b0:	b40010a0 	cbz	x0, 54c4 <fwp_p_ad_push+0x320>
    52b4:	f9400e61 	ldr	x1, [x19, #24]
    52b8:	8b010801 	add	x1, x0, x1, lsl #2
    52bc:	a9020660 	stp	x0, x1, [x19, #32]
    52c0:	b400093b 	cbz	x27, 53e4 <fwp_p_ad_push+0x240>
    52c4:	f9403363 	ldr	x3, [x27, #96]
    52c8:	f9003be3 	str	x3, [sp, #112]
    52cc:	eb03029f 	cmp	x20, x3
    52d0:	5400034d 	b.le	5338 <fwp_p_ad_push+0x194>
    52d4:	f940237c 	ldr	x28, [x27, #64]
    52d8:	d37cee82 	lsl	x2, x20, #4
    52dc:	aa0203e0 	mov	x0, x2
    52e0:	52800041 	mov	w1, #0x2                   	// #2
    52e4:	f9003fe2 	str	x2, [sp, #120]
    52e8:	97ffff22 	bl	4f70 <fwp_heap_alloc>
    52ec:	aa0003fa 	mov	x26, x0
    52f0:	b400013c 	cbz	x28, 5314 <fwp_p_ad_push+0x170>
    52f4:	a9470be3 	ldp	x3, x2, [sp, #112]
    52f8:	aa1c03e1 	mov	x1, x28
    52fc:	d37cec63 	lsl	x3, x3, #4
    5300:	eb02007f 	cmp	x3, x2
    5304:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5308:	97fff516 	bl	2760 <memcpy@plt>
    530c:	aa1c03e0 	mov	x0, x28
    5310:	97fffdf8 	bl	4af0 <fwp_mem_free>
    5314:	f9403360 	ldr	x0, [x27, #96]
    5318:	52800001 	mov	w1, #0x0                   	// #0
    531c:	cb000282 	sub	x2, x20, x0
    5320:	8b001340 	add	x0, x26, x0, lsl #4
    5324:	d37cec42 	lsl	x2, x2, #4
    5328:	97fff56e 	bl	28e0 <memset@plt>
    532c:	f9401260 	ldr	x0, [x19, #32]
    5330:	f900237a 	str	x26, [x27, #64]
    5334:	f9003374 	str	x20, [x27, #96]
    5338:	b50008b6 	cbnz	x22, 544c <fwp_p_ad_push+0x2a8>
    533c:	a9431263 	ldp	x3, x4, [x19, #48]
    5340:	d37ef69a 	lsl	x26, x20, #2
    5344:	a94573fb 	ldp	x27, x28, [sp, #80]
    5348:	8b1a0002 	add	x2, x0, x26
    534c:	f9000e74 	str	x20, [x19, #24]
    5350:	f9001662 	str	x2, [x19, #40]
    5354:	b8366815 	str	w21, [x0, x22]
    5358:	f100031f 	cmp	x24, #0x0
    535c:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    5360:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5364:	fc396869 	str	d9, [x3, x25]
    5368:	aa1702a0 	orr	x0, x21, x23
    536c:	b8366841 	str	w1, [x2, x22]
    5370:	910006e1 	add	x1, x23, #0x1
    5374:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5378:	fc396888 	str	d8, [x4, x25]
    537c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5380:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5384:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5388:	f9000a61 	str	x1, [x19, #16]
    538c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5390:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5394:	d65f03c0 	ret
    5398:	9360fc54 	asr	x20, x2, #32
    539c:	eb80829f 	cmp	x20, x0, asr #32
    53a0:	54fff300 	b.eq	5200 <fwp_p_ad_push+0x5c>  // b.none
    53a4:	90000040 	adrp	x0, d000 <__modti3+0x320>
    53a8:	9110a000 	add	x0, x0, #0x428
    53ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    53b0:	a90573fb 	stp	x27, x28, [sp, #80]
    53b4:	97fff933 	bl	3880 <fwp_trap>
    53b8:	d37ffa94 	lsl	x20, x20, #1
    53bc:	17ffffb4 	b	528c <fwp_p_ad_push+0xe8>
    53c0:	a9428e62 	ldp	x2, x3, [x19, #40]
    53c4:	d37ef6d6 	lsl	x22, x22, #2
    53c8:	f9401e64 	ldr	x4, [x19, #56]
    53cc:	d37df339 	lsl	x25, x25, #3
    53d0:	17ffffe1 	b	5354 <fwp_p_ad_push+0x1b0>
    53d4:	f94006d3 	ldr	x19, [x22, #8]
    53d8:	17ffff94 	b	5228 <fwp_p_ad_push+0x84>
    53dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53e0:	d65f03c0 	ret
    53e4:	f9401a60 	ldr	x0, [x19, #48]
    53e8:	d37cee9b 	lsl	x27, x20, #4
    53ec:	aa1b03e1 	mov	x1, x27
    53f0:	97fff544 	bl	2900 <realloc@plt>
    53f4:	aa0003e3 	mov	x3, x0
    53f8:	b4000660 	cbz	x0, 54c4 <fwp_p_ad_push+0x320>
    53fc:	8b1a0004 	add	x4, x0, x26
    5400:	f9400e60 	ldr	x0, [x19, #24]
    5404:	8b000c61 	add	x1, x3, x0, lsl #3
    5408:	a9030663 	stp	x3, x1, [x19, #48]
    540c:	b5000356 	cbnz	x22, 5474 <fwp_p_ad_push+0x2d0>
    5410:	f9401260 	ldr	x0, [x19, #32]
    5414:	d37ef69a 	lsl	x26, x20, #2
    5418:	d2800016 	mov	x22, #0x0                   	// #0
    541c:	f9001e64 	str	x4, [x19, #56]
    5420:	17ffffc9 	b	5344 <fwp_p_ad_push+0x1a0>
    5424:	aa1403e0 	mov	x0, x20
    5428:	97fff9e2 	bl	3bb0 <fwp_tape_of>
    542c:	aa0003f3 	mov	x19, x0
    5430:	f9403000 	ldr	x0, [x0, #96]
    5434:	b4ffefa0 	cbz	x0, 5228 <fwp_p_ad_push+0x84>
    5438:	90000040 	adrp	x0, d000 <__modti3+0x320>
    543c:	9111c000 	add	x0, x0, #0x470
    5440:	a9046bf9 	stp	x25, x26, [sp, #64]
    5444:	a90573fb 	stp	x27, x28, [sp, #80]
    5448:	97fff90e 	bl	3880 <fwp_trap>
    544c:	d37df2d9 	lsl	x25, x22, #3
    5450:	f9401661 	ldr	x1, [x19, #40]
    5454:	d37ef6d6 	lsl	x22, x22, #2
    5458:	d37ef69a 	lsl	x26, x20, #2
    545c:	aa1603e2 	mov	x2, x22
    5460:	8b1a0000 	add	x0, x0, x26
    5464:	97fff4c7 	bl	2780 <memmove@plt>
    5468:	f9401260 	ldr	x0, [x19, #32]
    546c:	a9431263 	ldp	x3, x4, [x19, #48]
    5470:	17ffffb5 	b	5344 <fwp_p_ad_push+0x1a0>
    5474:	eb1b035f 	cmp	x26, x27
    5478:	d37df2d9 	lsl	x25, x22, #3
    547c:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5480:	aa0403e0 	mov	x0, x4
    5484:	cb1a0063 	sub	x3, x3, x26
    5488:	aa1903e2 	mov	x2, x25
    548c:	97fff589 	bl	2ab0 <__memmove_chk@plt>
    5490:	f9401a61 	ldr	x1, [x19, #48]
    5494:	f9401260 	ldr	x0, [x19, #32]
    5498:	8b1a0021 	add	x1, x1, x26
    549c:	f9001e61 	str	x1, [x19, #56]
    54a0:	17ffffec 	b	5450 <fwp_p_ad_push+0x2ac>
    54a4:	90000040 	adrp	x0, d000 <__modti3+0x320>
    54a8:	91130000 	add	x0, x0, #0x4c0
    54ac:	a90573fb 	stp	x27, x28, [sp, #80]
    54b0:	97fff8f4 	bl	3880 <fwp_trap>
    54b4:	90000040 	adrp	x0, d000 <__modti3+0x320>
    54b8:	91128000 	add	x0, x0, #0x4a0
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	97fff8f0 	bl	3880 <fwp_trap>
    54c4:	aa1303e0 	mov	x0, x19
    54c8:	97fff6d2 	bl	3010 <fwp_tape_unlink_scope>
    54cc:	f9401260 	ldr	x0, [x19, #32]
    54d0:	97fff540 	bl	29d0 <free@plt>
    54d4:	f9401a60 	ldr	x0, [x19, #48]
    54d8:	97fff53e 	bl	29d0 <free@plt>
    54dc:	f9402260 	ldr	x0, [x19, #64]
    54e0:	97fff53c 	bl	29d0 <free@plt>
    54e4:	f9000e7f 	str	xzr, [x19, #24]
    54e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    54ec:	f947e821 	ldr	x1, [x1, #4048]
    54f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54f4:	d2800262 	mov	x2, #0x13                  	// #19
    54f8:	4f000400 	movi	v0.4s, #0x0
    54fc:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5500:	f9400023 	ldr	x3, [x1]
    5504:	b900067f 	str	wzr, [x19, #4]
    5508:	d2800021 	mov	x1, #0x1                   	// #1
    550c:	91022000 	add	x0, x0, #0x88
    5510:	3c808260 	stur	q0, [x19, #8]
    5514:	ad010260 	stp	q0, q0, [x19, #32]
    5518:	97fff53e 	bl	2a10 <fwrite@plt>
    551c:	d2800000 	mov	x0, #0x0                   	// #0
    5520:	97fff548 	bl	2a40 <fflush@plt>
    5524:	52800cc0 	mov	w0, #0x66                  	// #102
    5528:	97fff556 	bl	2a80 <_Exit@plt>
    552c:	d503201f 	nop

0000000000005530 <w120>:
    5530:	d10203ff 	sub	sp, sp, #0x80
    5534:	9e660003 	fmov	x3, d0
    5538:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    553c:	f947f442 	ldr	x2, [x2, #4072]
    5540:	a9027bfd 	stp	x29, x30, [sp, #32]
    5544:	910083fd 	add	x29, sp, #0x20
    5548:	6d0627e8 	stp	d8, d9, [sp, #96]
    554c:	1e604009 	fmov	d9, d0
    5550:	1e604028 	fmov	d8, d1
    5554:	fd003bea 	str	d10, [sp, #112]
    5558:	1e60080a 	fmul	d10, d0, d0
    555c:	a90353f3 	stp	x19, x20, [sp, #48]
    5560:	910023f3 	add	x19, sp, #0x8
    5564:	aa0003f4 	mov	x20, x0
    5568:	a9045bf5 	stp	x21, x22, [sp, #64]
    556c:	aa0103f6 	mov	x22, x1
    5570:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5574:	a90563f7 	stp	x23, x24, [sp, #80]
    5578:	aa0303e1 	mov	x1, x3
    557c:	f9400044 	ldr	x4, [x2]
    5580:	f9000fe4 	str	x4, [sp, #24]
    5584:	d2800004 	mov	x4, #0x0                   	// #0
    5588:	aa0003e2 	mov	x2, x0
    558c:	aa1303e4 	mov	x4, x19
    5590:	a900fff5 	stp	x21, xzr, [sp, #8]
    5594:	97ffff04 	bl	51a4 <fwp_p_ad_push>
    5598:	1e6a3908 	fsub	d8, d8, d10
    559c:	aa1603e2 	mov	x2, x22
    55a0:	aa1303e4 	mov	x4, x19
    55a4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55a8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    55ac:	9e660118 	fmov	x24, d8
    55b0:	97fffefd 	bl	51a4 <fwp_p_ad_push>
    55b4:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    55b8:	aa0003f6 	mov	x22, x0
    55bc:	aa1303e4 	mov	x4, x19
    55c0:	aa1403e0 	mov	x0, x20
    55c4:	1e69394a 	fsub	d10, d10, d9
    55c8:	aa1503e2 	mov	x2, x21
    55cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55d0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    55d4:	9e660157 	fmov	x23, d10
    55d8:	97fffef3 	bl	51a4 <fwp_p_ad_push>
    55dc:	1e680908 	fmul	d8, d8, d8
    55e0:	aa0003f4 	mov	x20, x0
    55e4:	aa1303e4 	mov	x4, x19
    55e8:	aa1803e3 	mov	x3, x24
    55ec:	aa1803e1 	mov	x1, x24
    55f0:	aa1603e2 	mov	x2, x22
    55f4:	aa1603e0 	mov	x0, x22
    55f8:	97fffeeb 	bl	51a4 <fwp_p_ad_push>
    55fc:	aa0003e2 	mov	x2, x0
    5600:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5604:	9e670029 	fmov	d9, x1
    5608:	9e660101 	fmov	x1, d8
    560c:	aa1303e4 	mov	x4, x19
    5610:	1e690909 	fmul	d9, d8, d9
    5614:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5618:	aa1503e0 	mov	x0, x21
    561c:	97fffee2 	bl	51a4 <fwp_p_ad_push>
    5620:	1e6a094a 	fmul	d10, d10, d10
    5624:	aa1303e4 	mov	x4, x19
    5628:	aa1703e3 	mov	x3, x23
    562c:	aa0003f3 	mov	x19, x0
    5630:	aa1703e1 	mov	x1, x23
    5634:	aa1403e2 	mov	x2, x20
    5638:	aa1403e0 	mov	x0, x20
    563c:	97fffeda 	bl	51a4 <fwp_p_ad_push>
    5640:	1e6a2929 	fadd	d9, d9, d10
    5644:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5648:	d2800004 	mov	x4, #0x0                   	// #0
    564c:	aa0303e1 	mov	x1, x3
    5650:	aa1303e2 	mov	x2, x19
    5654:	97fffed4 	bl	51a4 <fwp_p_ad_push>
    5658:	aa0003e1 	mov	x1, x0
    565c:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    5660:	f947f463 	ldr	x3, [x3, #4072]
    5664:	f9400fe0 	ldr	x0, [sp, #24]
    5668:	f9400064 	ldr	x4, [x3]
    566c:	eb040000 	subs	x0, x0, x4
    5670:	d2800004 	mov	x4, #0x0                   	// #0
    5674:	54000161 	b.ne	56a0 <w120+0x170>  // b.any
    5678:	9e660122 	fmov	x2, d9
    567c:	fd403bea 	ldr	d10, [sp, #112]
    5680:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5684:	a94353f3 	ldp	x19, x20, [sp, #48]
    5688:	aa0203e0 	mov	x0, x2
    568c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5690:	a94563f7 	ldp	x23, x24, [sp, #80]
    5694:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5698:	910203ff 	add	sp, sp, #0x80
    569c:	d65f03c0 	ret
    56a0:	97fff49c 	bl	2910 <__stack_chk_fail@plt>

00000000000056a4 <w176.constprop.0>:
    56a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56a8:	910003fd 	mov	x29, sp
    56ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    56b0:	fd001be8 	str	d8, [sp, #48]
    56b4:	f9400015 	ldr	x21, [x0]
    56b8:	b4000355 	cbz	x21, 5720 <w176.constprop.0+0x7c>
    56bc:	2f00e408 	movi	d8, #0x0
    56c0:	91002016 	add	x22, x0, #0x8
    56c4:	a90153f3 	stp	x19, x20, [sp, #16]
    56c8:	91004014 	add	x20, x0, #0x10
    56cc:	d2800013 	mov	x19, #0x0                   	// #0
    56d0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    56d4:	d503201f 	nop
    56d8:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    56dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    56e0:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    56e4:	aa0303e1 	mov	x1, x3
    56e8:	1e602908 	fadd	d8, d8, d0
    56ec:	d2800004 	mov	x4, #0x0                   	// #0
    56f0:	91000a73 	add	x19, x19, #0x2
    56f4:	97fffeac 	bl	51a4 <fwp_p_ad_push>
    56f8:	eb1302bf 	cmp	x21, x19
    56fc:	54fffee8 	b.hi	56d8 <w176.constprop.0+0x34>  // b.pmore
    5700:	9e660102 	fmov	x2, d8
    5704:	fd401be8 	ldr	d8, [sp, #48]
    5708:	a94153f3 	ldp	x19, x20, [sp, #16]
    570c:	aa0003e1 	mov	x1, x0
    5710:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5714:	aa0203e0 	mov	x0, x2
    5718:	a8c47bfd 	ldp	x29, x30, [sp], #64
    571c:	d65f03c0 	ret
    5720:	2f00e408 	movi	d8, #0x0
    5724:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5728:	a9425bf5 	ldp	x21, x22, [sp, #32]
    572c:	aa0003e1 	mov	x1, x0
    5730:	9e660102 	fmov	x2, d8
    5734:	fd401be8 	ldr	d8, [sp, #48]
    5738:	a8c47bfd 	ldp	x29, x30, [sp], #64
    573c:	aa0203e0 	mov	x0, x2
    5740:	d65f03c0 	ret

0000000000005744 <fwp_rc_share>:
    5744:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5748:	91174042 	add	x2, x2, #0x5d0
    574c:	f949d843 	ldr	x3, [x2, #5040]
    5750:	f949ec41 	ldr	x1, [x2, #5080]
    5754:	cb030000 	sub	x0, x0, x3
    5758:	eb01401f 	cmp	x0, x1, lsl #16
    575c:	540002c2 	b.cs	57b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5760:	d350fc01 	lsr	x1, x0, #16
    5764:	f949fc44 	ldr	x4, [x2, #5112]
    5768:	8b010821 	add	x1, x1, x1, lsl #2
    576c:	d37df021 	lsl	x1, x1, #3
    5770:	8b010083 	add	x3, x4, x1
    5774:	f9401062 	ldr	x2, [x3, #32]
    5778:	b40001e2 	cbz	x2, 57b4 <fwp_rc_share+0x70>
    577c:	38616881 	ldrb	w1, [x4, x1]
    5780:	7100083f 	cmp	w1, #0x2
    5784:	540001a0 	b.eq	57b8 <fwp_rc_share+0x74>  // b.none
    5788:	7100043f 	cmp	w1, #0x1
    578c:	54000141 	b.ne	57b4 <fwp_rc_share+0x70>  // b.any
    5790:	29430464 	ldp	w4, w1, [x3, #24]
    5794:	92403c00 	and	x0, x0, #0xffff
    5798:	9b047c00 	mul	x0, x0, x4
    579c:	d360fc00 	lsr	x0, x0, #32
    57a0:	eb01001f 	cmp	x0, x1
    57a4:	54000082 	b.cs	57b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    57a8:	8b000042 	add	x2, x2, x0
    57ac:	39400040 	ldrb	w0, [x2]
    57b0:	350000a0 	cbnz	w0, 57c4 <fwp_rc_share+0x80>
    57b4:	d65f03c0 	ret
    57b8:	72003c1f 	tst	w0, #0xffff
    57bc:	54ffff80 	b.eq	57ac <fwp_rc_share+0x68>  // b.none
    57c0:	d65f03c0 	ret
    57c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57c8:	90000040 	adrp	x0, d000 <__modti3+0x320>
    57cc:	91138000 	add	x0, x0, #0x4e0
    57d0:	910003fd 	mov	x29, sp
    57d4:	97fff82b 	bl	3880 <fwp_trap>
    57d8:	d503201f 	nop
    57dc:	d503201f 	nop

00000000000057e0 <fwp_rc_fresh>:
    57e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    57e4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    57e8:	91174063 	add	x3, x3, #0x5d0
    57ec:	910003fd 	mov	x29, sp
    57f0:	a90153f3 	stp	x19, x20, [sp, #16]
    57f4:	aa0003f3 	mov	x19, x0
    57f8:	f949d861 	ldr	x1, [x3, #5040]
    57fc:	f949ec60 	ldr	x0, [x3, #5080]
    5800:	cb010261 	sub	x1, x19, x1
    5804:	eb00403f 	cmp	x1, x0, lsl #16
    5808:	54000322 	b.cs	586c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    580c:	d350fc22 	lsr	x2, x1, #16
    5810:	f949fc63 	ldr	x3, [x3, #5112]
    5814:	8b020842 	add	x2, x2, x2, lsl #2
    5818:	d37df042 	lsl	x2, x2, #3
    581c:	8b020060 	add	x0, x3, x2
    5820:	f9401014 	ldr	x20, [x0, #32]
    5824:	b4000254 	cbz	x20, 586c <fwp_rc_fresh+0x8c>
    5828:	38626862 	ldrb	w2, [x3, x2]
    582c:	7100085f 	cmp	w2, #0x2
    5830:	54000260 	b.eq	587c <fwp_rc_fresh+0x9c>  // b.none
    5834:	7100045f 	cmp	w2, #0x1
    5838:	540001a1 	b.ne	586c <fwp_rc_fresh+0x8c>  // b.any
    583c:	29430002 	ldp	w2, w0, [x0, #24]
    5840:	92403c21 	and	x1, x1, #0xffff
    5844:	9b027c21 	mul	x1, x1, x2
    5848:	d360fc21 	lsr	x1, x1, #32
    584c:	eb00003f 	cmp	x1, x0
    5850:	540000e2 	b.cs	586c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5854:	8b010294 	add	x20, x20, x1
    5858:	39400280 	ldrb	w0, [x20]
    585c:	7103fc1f 	cmp	w0, #0xff
    5860:	540001a0 	b.eq	5894 <fwp_rc_fresh+0xb4>  // b.none
    5864:	52800020 	mov	w0, #0x1                   	// #1
    5868:	39000280 	strb	w0, [x20]
    586c:	aa1303e0 	mov	x0, x19
    5870:	a94153f3 	ldp	x19, x20, [sp, #16]
    5874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5878:	d65f03c0 	ret
    587c:	72003c3f 	tst	w1, #0xffff
    5880:	54fffec0 	b.eq	5858 <fwp_rc_fresh+0x78>  // b.none
    5884:	aa1303e0 	mov	x0, x19
    5888:	a94153f3 	ldp	x19, x20, [sp, #16]
    588c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5890:	d65f03c0 	ret
    5894:	aa1403e0 	mov	x0, x20
    5898:	97fffbf6 	bl	4870 <fwp_rc_forget_slot>
    589c:	17fffff2 	b	5864 <fwp_rc_fresh+0x84>

00000000000058a0 <fwp_rc_free_arr>:
    58a0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    58a4:	91174063 	add	x3, x3, #0x5d0
    58a8:	f949d861 	ldr	x1, [x3, #5040]
    58ac:	f949ec62 	ldr	x2, [x3, #5080]
    58b0:	cb010001 	sub	x1, x0, x1
    58b4:	eb02403f 	cmp	x1, x2, lsl #16
    58b8:	54000342 	b.cs	5920 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58bc:	d350fc22 	lsr	x2, x1, #16
    58c0:	f949fc65 	ldr	x5, [x3, #5112]
    58c4:	8b020842 	add	x2, x2, x2, lsl #2
    58c8:	d37df042 	lsl	x2, x2, #3
    58cc:	8b0200a4 	add	x4, x5, x2
    58d0:	f9401083 	ldr	x3, [x4, #32]
    58d4:	b4000263 	cbz	x3, 5920 <fwp_rc_free_arr+0x80>
    58d8:	386268a2 	ldrb	w2, [x5, x2]
    58dc:	7100085f 	cmp	w2, #0x2
    58e0:	540001c0 	b.eq	5918 <fwp_rc_free_arr+0x78>  // b.none
    58e4:	7100045f 	cmp	w2, #0x1
    58e8:	540001c1 	b.ne	5920 <fwp_rc_free_arr+0x80>  // b.any
    58ec:	29430885 	ldp	w5, w2, [x4, #24]
    58f0:	92403c21 	and	x1, x1, #0xffff
    58f4:	9b057c21 	mul	x1, x1, x5
    58f8:	d360fc21 	lsr	x1, x1, #32
    58fc:	eb02003f 	cmp	x1, x2
    5900:	54000102 	b.cs	5920 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5904:	8b010063 	add	x3, x3, x1
    5908:	39400061 	ldrb	w1, [x3]
    590c:	7100043f 	cmp	w1, #0x1
    5910:	54000081 	b.ne	5920 <fwp_rc_free_arr+0x80>  // b.any
    5914:	17fffc77 	b	4af0 <fwp_mem_free>
    5918:	72003c3f 	tst	w1, #0xffff
    591c:	54ffff60 	b.eq	5908 <fwp_rc_free_arr+0x68>  // b.none
    5920:	d65f03c0 	ret

0000000000005924 <fwp_rc_dup>:
    5924:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5928:	91174042 	add	x2, x2, #0x5d0
    592c:	f949d841 	ldr	x1, [x2, #5040]
    5930:	f949ec43 	ldr	x3, [x2, #5080]
    5934:	cb010001 	sub	x1, x0, x1
    5938:	eb03403f 	cmp	x1, x3, lsl #16
    593c:	54000342 	b.cs	59a4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5940:	d350fc20 	lsr	x0, x1, #16
    5944:	f949fc44 	ldr	x4, [x2, #5112]
    5948:	8b000800 	add	x0, x0, x0, lsl #2
    594c:	d37df002 	lsl	x2, x0, #3
    5950:	8b020083 	add	x3, x4, x2
    5954:	f9401060 	ldr	x0, [x3, #32]
    5958:	b4000260 	cbz	x0, 59a4 <fwp_rc_dup+0x80>
    595c:	38626882 	ldrb	w2, [x4, x2]
    5960:	7100085f 	cmp	w2, #0x2
    5964:	54000220 	b.eq	59a8 <fwp_rc_dup+0x84>  // b.none
    5968:	7100045f 	cmp	w2, #0x1
    596c:	540001c1 	b.ne	59a4 <fwp_rc_dup+0x80>  // b.any
    5970:	29430864 	ldp	w4, w2, [x3, #24]
    5974:	92403c21 	and	x1, x1, #0xffff
    5978:	9b047c21 	mul	x1, x1, x4
    597c:	d360fc21 	lsr	x1, x1, #32
    5980:	eb02003f 	cmp	x1, x2
    5984:	54000102 	b.cs	59a4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5988:	8b010000 	add	x0, x0, x1
    598c:	39400001 	ldrb	w1, [x0]
    5990:	340000a1 	cbz	w1, 59a4 <fwp_rc_dup+0x80>
    5994:	7103f43f 	cmp	w1, #0xfd
    5998:	540000e8 	b.hi	59b4 <fwp_rc_dup+0x90>  // b.pmore
    599c:	11000421 	add	w1, w1, #0x1
    59a0:	39000001 	strb	w1, [x0]
    59a4:	d65f03c0 	ret
    59a8:	72003c3f 	tst	w1, #0xffff
    59ac:	54ffff00 	b.eq	598c <fwp_rc_dup+0x68>  // b.none
    59b0:	d65f03c0 	ret
    59b4:	17fffb68 	b	4754 <fwp_rc_wide_dup>
    59b8:	d503201f 	nop
    59bc:	d503201f 	nop

00000000000059c0 <fwp_owned_entry173>:
    59c0:	d10103ff 	sub	sp, sp, #0x40
    59c4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    59c8:	f947f442 	ldr	x2, [x2, #4072]
    59cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    59d0:	910083fd 	add	x29, sp, #0x20
    59d4:	a90353f3 	stp	x19, x20, [sp, #48]
    59d8:	f9400043 	ldr	x3, [x2]
    59dc:	f9000fe3 	str	x3, [sp, #24]
    59e0:	d2800003 	mov	x3, #0x0                   	// #0
    59e4:	a9400c01 	ldp	x1, x3, [x0]
    59e8:	f9400802 	ldr	x2, [x0, #16]
    59ec:	ab020022 	adds	x2, x1, x2
    59f0:	540006e6 	b.vs	5acc <fwp_owned_entry173+0x10c>
    59f4:	910023e1 	add	x1, sp, #0x8
    59f8:	52800000 	mov	w0, #0x0                   	// #0
    59fc:	a9008be3 	stp	x3, x2, [sp, #8]
    5a00:	97fffda1 	bl	5084 <fwp_data.part.0.constprop.0>
    5a04:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5a08:	91174063 	add	x3, x3, #0x5d0
    5a0c:	aa0003f3 	mov	x19, x0
    5a10:	f949d861 	ldr	x1, [x3, #5040]
    5a14:	f949ec60 	ldr	x0, [x3, #5080]
    5a18:	cb010261 	sub	x1, x19, x1
    5a1c:	eb00403f 	cmp	x1, x0, lsl #16
    5a20:	54000322 	b.cs	5a84 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a24:	d350fc22 	lsr	x2, x1, #16
    5a28:	f949fc63 	ldr	x3, [x3, #5112]
    5a2c:	8b020842 	add	x2, x2, x2, lsl #2
    5a30:	d37df042 	lsl	x2, x2, #3
    5a34:	8b020060 	add	x0, x3, x2
    5a38:	f9401014 	ldr	x20, [x0, #32]
    5a3c:	b4000254 	cbz	x20, 5a84 <fwp_owned_entry173+0xc4>
    5a40:	38626862 	ldrb	w2, [x3, x2]
    5a44:	7100085f 	cmp	w2, #0x2
    5a48:	54000360 	b.eq	5ab4 <fwp_owned_entry173+0xf4>  // b.none
    5a4c:	7100045f 	cmp	w2, #0x1
    5a50:	540001a1 	b.ne	5a84 <fwp_owned_entry173+0xc4>  // b.any
    5a54:	29430002 	ldp	w2, w0, [x0, #24]
    5a58:	92403c21 	and	x1, x1, #0xffff
    5a5c:	9b027c21 	mul	x1, x1, x2
    5a60:	d360fc21 	lsr	x1, x1, #32
    5a64:	eb00003f 	cmp	x1, x0
    5a68:	540000e2 	b.cs	5a84 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a6c:	8b010294 	add	x20, x20, x1
    5a70:	39400280 	ldrb	w0, [x20]
    5a74:	7103fc1f 	cmp	w0, #0xff
    5a78:	54000240 	b.eq	5ac0 <fwp_owned_entry173+0x100>  // b.none
    5a7c:	52800020 	mov	w0, #0x1                   	// #1
    5a80:	39000280 	strb	w0, [x20]
    5a84:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5a88:	f947f400 	ldr	x0, [x0, #4072]
    5a8c:	f9400fe2 	ldr	x2, [sp, #24]
    5a90:	f9400001 	ldr	x1, [x0]
    5a94:	eb010042 	subs	x2, x2, x1
    5a98:	d2800001 	mov	x1, #0x0                   	// #0
    5a9c:	540001a1 	b.ne	5ad0 <fwp_owned_entry173+0x110>  // b.any
    5aa0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5aa4:	aa1303e0 	mov	x0, x19
    5aa8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5aac:	910103ff 	add	sp, sp, #0x40
    5ab0:	d65f03c0 	ret
    5ab4:	72003c3f 	tst	w1, #0xffff
    5ab8:	54fffe61 	b.ne	5a84 <fwp_owned_entry173+0xc4>  // b.any
    5abc:	17ffffed 	b	5a70 <fwp_owned_entry173+0xb0>
    5ac0:	aa1403e0 	mov	x0, x20
    5ac4:	97fffb6b 	bl	4870 <fwp_rc_forget_slot>
    5ac8:	17ffffed 	b	5a7c <fwp_owned_entry173+0xbc>
    5acc:	97fff40d 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5ad0:	97fff390 	bl	2910 <__stack_chk_fail@plt>

0000000000005ad4 <e173>:
    5ad4:	d10103ff 	sub	sp, sp, #0x40
    5ad8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5adc:	f947f442 	ldr	x2, [x2, #4072]
    5ae0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ae4:	910083fd 	add	x29, sp, #0x20
    5ae8:	a90353f3 	stp	x19, x20, [sp, #48]
    5aec:	f9400043 	ldr	x3, [x2]
    5af0:	f9000fe3 	str	x3, [sp, #24]
    5af4:	d2800003 	mov	x3, #0x0                   	// #0
    5af8:	a9400c01 	ldp	x1, x3, [x0]
    5afc:	f9400802 	ldr	x2, [x0, #16]
    5b00:	ab020022 	adds	x2, x1, x2
    5b04:	54000726 	b.vs	5be8 <e173+0x114>
    5b08:	910023e1 	add	x1, sp, #0x8
    5b0c:	52800000 	mov	w0, #0x0                   	// #0
    5b10:	a9008be3 	stp	x3, x2, [sp, #8]
    5b14:	97fffd5c 	bl	5084 <fwp_data.part.0.constprop.0>
    5b18:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5b1c:	91174063 	add	x3, x3, #0x5d0
    5b20:	aa0003f3 	mov	x19, x0
    5b24:	f949d861 	ldr	x1, [x3, #5040]
    5b28:	f949ec60 	ldr	x0, [x3, #5080]
    5b2c:	cb010261 	sub	x1, x19, x1
    5b30:	eb00403f 	cmp	x1, x0, lsl #16
    5b34:	54000322 	b.cs	5b98 <e173+0xc4>  // b.hs, b.nlast
    5b38:	d350fc22 	lsr	x2, x1, #16
    5b3c:	f949fc63 	ldr	x3, [x3, #5112]
    5b40:	8b020842 	add	x2, x2, x2, lsl #2
    5b44:	d37df042 	lsl	x2, x2, #3
    5b48:	8b020060 	add	x0, x3, x2
    5b4c:	f9401014 	ldr	x20, [x0, #32]
    5b50:	b4000254 	cbz	x20, 5b98 <e173+0xc4>
    5b54:	38626862 	ldrb	w2, [x3, x2]
    5b58:	7100085f 	cmp	w2, #0x2
    5b5c:	540003a0 	b.eq	5bd0 <e173+0xfc>  // b.none
    5b60:	7100045f 	cmp	w2, #0x1
    5b64:	540001a1 	b.ne	5b98 <e173+0xc4>  // b.any
    5b68:	29430002 	ldp	w2, w0, [x0, #24]
    5b6c:	92403c21 	and	x1, x1, #0xffff
    5b70:	9b027c21 	mul	x1, x1, x2
    5b74:	d360fc21 	lsr	x1, x1, #32
    5b78:	eb00003f 	cmp	x1, x0
    5b7c:	540000e2 	b.cs	5b98 <e173+0xc4>  // b.hs, b.nlast
    5b80:	8b010294 	add	x20, x20, x1
    5b84:	39400280 	ldrb	w0, [x20]
    5b88:	7103fc1f 	cmp	w0, #0xff
    5b8c:	54000280 	b.eq	5bdc <e173+0x108>  // b.none
    5b90:	52800020 	mov	w0, #0x1                   	// #1
    5b94:	39000280 	strb	w0, [x20]
    5b98:	aa1303e0 	mov	x0, x19
    5b9c:	97fffeea 	bl	5744 <fwp_rc_share>
    5ba0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ba4:	f947f400 	ldr	x0, [x0, #4072]
    5ba8:	f9400fe2 	ldr	x2, [sp, #24]
    5bac:	f9400001 	ldr	x1, [x0]
    5bb0:	eb010042 	subs	x2, x2, x1
    5bb4:	d2800001 	mov	x1, #0x0                   	// #0
    5bb8:	540001a1 	b.ne	5bec <e173+0x118>  // b.any
    5bbc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5bc0:	aa1303e0 	mov	x0, x19
    5bc4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5bc8:	910103ff 	add	sp, sp, #0x40
    5bcc:	d65f03c0 	ret
    5bd0:	72003c3f 	tst	w1, #0xffff
    5bd4:	54fffe21 	b.ne	5b98 <e173+0xc4>  // b.any
    5bd8:	17ffffeb 	b	5b84 <e173+0xb0>
    5bdc:	aa1403e0 	mov	x0, x20
    5be0:	97fffb24 	bl	4870 <fwp_rc_forget_slot>
    5be4:	17ffffeb 	b	5b90 <e173+0xbc>
    5be8:	97fff3c6 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5bec:	97fff349 	bl	2910 <__stack_chk_fail@plt>

0000000000005bf0 <fwp_drop0>:
    5bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bf4:	910003fd 	mov	x29, sp
    5bf8:	a90153f3 	stp	x19, x20, [sp, #16]
    5bfc:	f90013f5 	str	x21, [sp, #32]
    5c00:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5c04:	911742b4 	add	x20, x21, #0x5d0
    5c08:	f949da81 	ldr	x1, [x20, #5040]
    5c0c:	f949ee82 	ldr	x2, [x20, #5080]
    5c10:	cb010001 	sub	x1, x0, x1
    5c14:	eb02403f 	cmp	x1, x2, lsl #16
    5c18:	54000382 	b.cs	5c88 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c1c:	d350fc22 	lsr	x2, x1, #16
    5c20:	f949fe84 	ldr	x4, [x20, #5112]
    5c24:	8b020842 	add	x2, x2, x2, lsl #2
    5c28:	d37df042 	lsl	x2, x2, #3
    5c2c:	8b020083 	add	x3, x4, x2
    5c30:	f9401073 	ldr	x19, [x3, #32]
    5c34:	b40002b3 	cbz	x19, 5c88 <fwp_drop0+0x98>
    5c38:	38626882 	ldrb	w2, [x4, x2]
    5c3c:	7100085f 	cmp	w2, #0x2
    5c40:	540002c0 	b.eq	5c98 <fwp_drop0+0xa8>  // b.none
    5c44:	7100045f 	cmp	w2, #0x1
    5c48:	54000201 	b.ne	5c88 <fwp_drop0+0x98>  // b.any
    5c4c:	29430864 	ldp	w4, w2, [x3, #24]
    5c50:	92403c21 	and	x1, x1, #0xffff
    5c54:	9b047c21 	mul	x1, x1, x4
    5c58:	d360fc21 	lsr	x1, x1, #32
    5c5c:	eb02003f 	cmp	x1, x2
    5c60:	54000142 	b.cs	5c88 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c64:	8b010273 	add	x19, x19, x1
    5c68:	39400261 	ldrb	w1, [x19]
    5c6c:	340000e1 	cbz	w1, 5c88 <fwp_drop0+0x98>
    5c70:	7100043f 	cmp	w1, #0x1
    5c74:	540001e0 	b.eq	5cb0 <fwp_drop0+0xc0>  // b.none
    5c78:	7103fc3f 	cmp	w1, #0xff
    5c7c:	540002e0 	b.eq	5cd8 <fwp_drop0+0xe8>  // b.none
    5c80:	51000421 	sub	w1, w1, #0x1
    5c84:	39000261 	strb	w1, [x19]
    5c88:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c8c:	f94013f5 	ldr	x21, [sp, #32]
    5c90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c94:	d65f03c0 	ret
    5c98:	72003c3f 	tst	w1, #0xffff
    5c9c:	54fffe60 	b.eq	5c68 <fwp_drop0+0x78>  // b.none
    5ca0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ca4:	f94013f5 	ldr	x21, [sp, #32]
    5ca8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cac:	d65f03c0 	ret
    5cb0:	f9400813 	ldr	x19, [x0, #16]
    5cb4:	97fffefb 	bl	58a0 <fwp_rc_free_arr>
    5cb8:	911742a0 	add	x0, x21, #0x5d0
    5cbc:	f949d801 	ldr	x1, [x0, #5040]
    5cc0:	f949ec00 	ldr	x0, [x0, #5080]
    5cc4:	cb010261 	sub	x1, x19, x1
    5cc8:	eb00403f 	cmp	x1, x0, lsl #16
    5ccc:	54fffde2 	b.cs	5c88 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cd0:	aa1303e0 	mov	x0, x19
    5cd4:	17ffffd2 	b	5c1c <fwp_drop0+0x2c>
    5cd8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cdc:	911742b5 	add	x21, x21, #0x5d0
    5ce0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ce4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ce8:	f94a2400 	ldr	x0, [x0, #5192]
    5cec:	b5000080 	cbnz	x0, 5cfc <fwp_drop0+0x10c>
    5cf0:	14000010 	b	5d30 <fwp_drop0+0x140>
    5cf4:	f9400800 	ldr	x0, [x0, #16]
    5cf8:	b40001c0 	cbz	x0, 5d30 <fwp_drop0+0x140>
    5cfc:	f9400001 	ldr	x1, [x0]
    5d00:	eb13003f 	cmp	x1, x19
    5d04:	54ffff81 	b.ne	5cf4 <fwp_drop0+0x104>  // b.any
    5d08:	f9400401 	ldr	x1, [x0, #8]
    5d0c:	d1000421 	sub	x1, x1, #0x1
    5d10:	f9000401 	str	x1, [x0, #8]
    5d14:	f103f83f 	cmp	x1, #0xfe
    5d18:	54fffb81 	b.ne	5c88 <fwp_drop0+0x98>  // b.any
    5d1c:	aa1303e0 	mov	x0, x19
    5d20:	97fffad4 	bl	4870 <fwp_rc_forget_slot>
    5d24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d28:	39000260 	strb	w0, [x19]
    5d2c:	17ffffd7 	b	5c88 <fwp_drop0+0x98>
    5d30:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5d34:	910f8000 	add	x0, x0, #0x3e0
    5d38:	97fff6d2 	bl	3880 <fwp_trap>
    5d3c:	d503201f 	nop

0000000000005d40 <fwp_drop1>:
    5d40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d44:	910003fd 	mov	x29, sp
    5d48:	a90153f3 	stp	x19, x20, [sp, #16]
    5d4c:	f90013f5 	str	x21, [sp, #32]
    5d50:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5d54:	911742b4 	add	x20, x21, #0x5d0
    5d58:	f949da81 	ldr	x1, [x20, #5040]
    5d5c:	f949ee82 	ldr	x2, [x20, #5080]
    5d60:	cb010001 	sub	x1, x0, x1
    5d64:	eb02403f 	cmp	x1, x2, lsl #16
    5d68:	54000382 	b.cs	5dd8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d6c:	d350fc22 	lsr	x2, x1, #16
    5d70:	f949fe84 	ldr	x4, [x20, #5112]
    5d74:	8b020842 	add	x2, x2, x2, lsl #2
    5d78:	d37df042 	lsl	x2, x2, #3
    5d7c:	8b020083 	add	x3, x4, x2
    5d80:	f9401073 	ldr	x19, [x3, #32]
    5d84:	b40002b3 	cbz	x19, 5dd8 <fwp_drop1+0x98>
    5d88:	38626882 	ldrb	w2, [x4, x2]
    5d8c:	7100085f 	cmp	w2, #0x2
    5d90:	540002c0 	b.eq	5de8 <fwp_drop1+0xa8>  // b.none
    5d94:	7100045f 	cmp	w2, #0x1
    5d98:	54000201 	b.ne	5dd8 <fwp_drop1+0x98>  // b.any
    5d9c:	29430864 	ldp	w4, w2, [x3, #24]
    5da0:	92403c21 	and	x1, x1, #0xffff
    5da4:	9b047c21 	mul	x1, x1, x4
    5da8:	d360fc21 	lsr	x1, x1, #32
    5dac:	eb02003f 	cmp	x1, x2
    5db0:	54000142 	b.cs	5dd8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5db4:	8b010273 	add	x19, x19, x1
    5db8:	39400261 	ldrb	w1, [x19]
    5dbc:	340000e1 	cbz	w1, 5dd8 <fwp_drop1+0x98>
    5dc0:	7100043f 	cmp	w1, #0x1
    5dc4:	540001e0 	b.eq	5e00 <fwp_drop1+0xc0>  // b.none
    5dc8:	7103fc3f 	cmp	w1, #0xff
    5dcc:	540002e0 	b.eq	5e28 <fwp_drop1+0xe8>  // b.none
    5dd0:	51000421 	sub	w1, w1, #0x1
    5dd4:	39000261 	strb	w1, [x19]
    5dd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ddc:	f94013f5 	ldr	x21, [sp, #32]
    5de0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5de4:	d65f03c0 	ret
    5de8:	72003c3f 	tst	w1, #0xffff
    5dec:	54fffe60 	b.eq	5db8 <fwp_drop1+0x78>  // b.none
    5df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5df4:	f94013f5 	ldr	x21, [sp, #32]
    5df8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5dfc:	d65f03c0 	ret
    5e00:	f9400813 	ldr	x19, [x0, #16]
    5e04:	97fffea7 	bl	58a0 <fwp_rc_free_arr>
    5e08:	911742a0 	add	x0, x21, #0x5d0
    5e0c:	f949d801 	ldr	x1, [x0, #5040]
    5e10:	f949ec00 	ldr	x0, [x0, #5080]
    5e14:	cb010261 	sub	x1, x19, x1
    5e18:	eb00403f 	cmp	x1, x0, lsl #16
    5e1c:	54fffde2 	b.cs	5dd8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e20:	aa1303e0 	mov	x0, x19
    5e24:	17ffffd2 	b	5d6c <fwp_drop1+0x2c>
    5e28:	ca534660 	eor	x0, x19, x19, lsr #17
    5e2c:	911742b5 	add	x21, x21, #0x5d0
    5e30:	ca402400 	eor	x0, x0, x0, lsr #9
    5e34:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5e38:	f94a2400 	ldr	x0, [x0, #5192]
    5e3c:	b5000080 	cbnz	x0, 5e4c <fwp_drop1+0x10c>
    5e40:	14000010 	b	5e80 <fwp_drop1+0x140>
    5e44:	f9400800 	ldr	x0, [x0, #16]
    5e48:	b40001c0 	cbz	x0, 5e80 <fwp_drop1+0x140>
    5e4c:	f9400001 	ldr	x1, [x0]
    5e50:	eb13003f 	cmp	x1, x19
    5e54:	54ffff81 	b.ne	5e44 <fwp_drop1+0x104>  // b.any
    5e58:	f9400401 	ldr	x1, [x0, #8]
    5e5c:	d1000421 	sub	x1, x1, #0x1
    5e60:	f9000401 	str	x1, [x0, #8]
    5e64:	f103f83f 	cmp	x1, #0xfe
    5e68:	54fffb81 	b.ne	5dd8 <fwp_drop1+0x98>  // b.any
    5e6c:	aa1303e0 	mov	x0, x19
    5e70:	97fffa80 	bl	4870 <fwp_rc_forget_slot>
    5e74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e78:	39000260 	strb	w0, [x19]
    5e7c:	17ffffd7 	b	5dd8 <fwp_drop1+0x98>
    5e80:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5e84:	910f8000 	add	x0, x0, #0x3e0
    5e88:	97fff67e 	bl	3880 <fwp_trap>
    5e8c:	d503201f 	nop

0000000000005e90 <fwp_closure_drop>:
    5e90:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5e94:	911740a4 	add	x4, x5, #0x5d0
    5e98:	aa0003e1 	mov	x1, x0
    5e9c:	f949d882 	ldr	x2, [x4, #5040]
    5ea0:	f949ec80 	ldr	x0, [x4, #5080]
    5ea4:	cb020022 	sub	x2, x1, x2
    5ea8:	eb00405f 	cmp	x2, x0, lsl #16
    5eac:	54000662 	b.cs	5f78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5eb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5eb4:	d350fc43 	lsr	x3, x2, #16
    5eb8:	910003fd 	mov	x29, sp
    5ebc:	8b030863 	add	x3, x3, x3, lsl #2
    5ec0:	f949fc84 	ldr	x4, [x4, #5112]
    5ec4:	d37df063 	lsl	x3, x3, #3
    5ec8:	f9000bf3 	str	x19, [sp, #16]
    5ecc:	8b030080 	add	x0, x4, x3
    5ed0:	f9401013 	ldr	x19, [x0, #32]
    5ed4:	b40002b3 	cbz	x19, 5f28 <fwp_closure_drop+0x98>
    5ed8:	38636883 	ldrb	w3, [x4, x3]
    5edc:	7100087f 	cmp	w3, #0x2
    5ee0:	54000420 	b.eq	5f64 <fwp_closure_drop+0xd4>  // b.none
    5ee4:	7100047f 	cmp	w3, #0x1
    5ee8:	54000201 	b.ne	5f28 <fwp_closure_drop+0x98>  // b.any
    5eec:	29430003 	ldp	w3, w0, [x0, #24]
    5ef0:	92403c42 	and	x2, x2, #0xffff
    5ef4:	9b037c42 	mul	x2, x2, x3
    5ef8:	d360fc42 	lsr	x2, x2, #32
    5efc:	eb00005f 	cmp	x2, x0
    5f00:	54000142 	b.cs	5f28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5f04:	8b020273 	add	x19, x19, x2
    5f08:	39400260 	ldrb	w0, [x19]
    5f0c:	340000e0 	cbz	w0, 5f28 <fwp_closure_drop+0x98>
    5f10:	7100041f 	cmp	w0, #0x1
    5f14:	54000100 	b.eq	5f34 <fwp_closure_drop+0xa4>  // b.none
    5f18:	7103fc1f 	cmp	w0, #0xff
    5f1c:	54000300 	b.eq	5f7c <fwp_closure_drop+0xec>  // b.none
    5f20:	51000400 	sub	w0, w0, #0x1
    5f24:	39000260 	strb	w0, [x19]
    5f28:	f9400bf3 	ldr	x19, [sp, #16]
    5f2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f30:	d65f03c0 	ret
    5f34:	d53bd040 	mrs	x0, tpidr_el0
    5f38:	91400000 	add	x0, x0, #0x0, lsl #12
    5f3c:	91004000 	add	x0, x0, #0x10
    5f40:	f9400000 	ldr	x0, [x0]
    5f44:	b4000080 	cbz	x0, 5f54 <fwp_closure_drop+0xc4>
    5f48:	f9400bf3 	ldr	x19, [sp, #16]
    5f4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f50:	17fff665 	b	38e4 <fwp_closure_drop_push>
    5f54:	f9400bf3 	ldr	x19, [sp, #16]
    5f58:	aa0103e0 	mov	x0, x1
    5f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f60:	17fff6d0 	b	3aa0 <fwp_closure_drop.part.0>
    5f64:	72003c5f 	tst	w2, #0xffff
    5f68:	54fffd00 	b.eq	5f08 <fwp_closure_drop+0x78>  // b.none
    5f6c:	f9400bf3 	ldr	x19, [sp, #16]
    5f70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f74:	d65f03c0 	ret
    5f78:	d65f03c0 	ret
    5f7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5f80:	911740a5 	add	x5, x5, #0x5d0
    5f84:	ca402400 	eor	x0, x0, x0, lsr #9
    5f88:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5f8c:	f94a2400 	ldr	x0, [x0, #5192]
    5f90:	b5000080 	cbnz	x0, 5fa0 <fwp_closure_drop+0x110>
    5f94:	14000010 	b	5fd4 <fwp_closure_drop+0x144>
    5f98:	f9400800 	ldr	x0, [x0, #16]
    5f9c:	b40001c0 	cbz	x0, 5fd4 <fwp_closure_drop+0x144>
    5fa0:	f9400001 	ldr	x1, [x0]
    5fa4:	eb13003f 	cmp	x1, x19
    5fa8:	54ffff81 	b.ne	5f98 <fwp_closure_drop+0x108>  // b.any
    5fac:	f9400401 	ldr	x1, [x0, #8]
    5fb0:	d1000421 	sub	x1, x1, #0x1
    5fb4:	f9000401 	str	x1, [x0, #8]
    5fb8:	f103f83f 	cmp	x1, #0xfe
    5fbc:	54fffb61 	b.ne	5f28 <fwp_closure_drop+0x98>  // b.any
    5fc0:	aa1303e0 	mov	x0, x19
    5fc4:	97fffa2b 	bl	4870 <fwp_rc_forget_slot>
    5fc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fcc:	39000260 	strb	w0, [x19]
    5fd0:	17ffffd6 	b	5f28 <fwp_closure_drop+0x98>
    5fd4:	90000040 	adrp	x0, d000 <__modti3+0x320>
    5fd8:	910f8000 	add	x0, x0, #0x3e0
    5fdc:	97fff629 	bl	3880 <fwp_trap>

0000000000005fe0 <fwp_owned_tape_release>:
    5fe0:	b4000940 	cbz	x0, 6108 <fwp_owned_tape_release+0x128>
    5fe4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fe8:	910003fd 	mov	x29, sp
    5fec:	a90153f3 	stp	x19, x20, [sp, #16]
    5ff0:	aa0003f3 	mov	x19, x0
    5ff4:	f9400000 	ldr	x0, [x0]
    5ff8:	b4000060 	cbz	x0, 6004 <fwp_owned_tape_release+0x24>
    5ffc:	f9400661 	ldr	x1, [x19, #8]
    6000:	f9000401 	str	x1, [x0, #8]
    6004:	f9400661 	ldr	x1, [x19, #8]
    6008:	b4000041 	cbz	x1, 6010 <fwp_owned_tape_release+0x30>
    600c:	f9000020 	str	x0, [x1]
    6010:	f9400a60 	ldr	x0, [x19, #16]
    6014:	f9403401 	ldr	x1, [x0, #104]
    6018:	b40005c1 	cbz	x1, 60d0 <fwp_owned_tape_release+0xf0>
    601c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6020:	eb00005f 	cmp	x2, x0
    6024:	540002ed 	b.le	6080 <fwp_owned_tape_release+0xa0>
    6028:	d2800014 	mov	x20, #0x0                   	// #0
    602c:	f90013f5 	str	x21, [sp, #32]
    6030:	d2800015 	mov	x21, #0x0                   	// #0
    6034:	d503201f 	nop
    6038:	f9402260 	ldr	x0, [x19, #64]
    603c:	910006b5 	add	x21, x21, #0x1
    6040:	f8746800 	ldr	x0, [x0, x20]
    6044:	d63f0020 	blr	x1
    6048:	f9402260 	ldr	x0, [x19, #64]
    604c:	f9400a61 	ldr	x1, [x19, #16]
    6050:	8b140000 	add	x0, x0, x20
    6054:	91004294 	add	x20, x20, #0x10
    6058:	f9400400 	ldr	x0, [x0, #8]
    605c:	f9403421 	ldr	x1, [x1, #104]
    6060:	d63f0020 	blr	x1
    6064:	a9450261 	ldp	x1, x0, [x19, #80]
    6068:	cb010000 	sub	x0, x0, x1
    606c:	eb15001f 	cmp	x0, x21
    6070:	f9400a60 	ldr	x0, [x19, #16]
    6074:	f9403401 	ldr	x1, [x0, #104]
    6078:	54fffe0c 	b.gt	6038 <fwp_owned_tape_release+0x58>
    607c:	f94013f5 	ldr	x21, [sp, #32]
    6080:	f9403663 	ldr	x3, [x19, #104]
    6084:	f9401262 	ldr	x2, [x19, #32]
    6088:	f100007f 	cmp	x3, #0x0
    608c:	540001ed 	b.le	60c8 <fwp_owned_tape_release+0xe8>
    6090:	d2800014 	mov	x20, #0x0                   	// #0
    6094:	d503201f 	nop
    6098:	f9402660 	ldr	x0, [x19, #72]
    609c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    60a0:	eb02001f 	cmp	x0, x2
    60a4:	540000c0 	b.eq	60bc <fwp_owned_tape_release+0xdc>  // b.none
    60a8:	d63f0020 	blr	x1
    60ac:	f9400a60 	ldr	x0, [x19, #16]
    60b0:	f9401262 	ldr	x2, [x19, #32]
    60b4:	f9403663 	ldr	x3, [x19, #104]
    60b8:	f9403401 	ldr	x1, [x0, #104]
    60bc:	91000694 	add	x20, x20, #0x1
    60c0:	eb14007f 	cmp	x3, x20
    60c4:	54fffeac 	b.gt	6098 <fwp_owned_tape_release+0xb8>
    60c8:	aa0203e0 	mov	x0, x2
    60cc:	d63f0020 	blr	x1
    60d0:	f9401660 	ldr	x0, [x19, #40]
    60d4:	97ffff6f 	bl	5e90 <fwp_closure_drop>
    60d8:	f9401a60 	ldr	x0, [x19, #48]
    60dc:	97ffff6d 	bl	5e90 <fwp_closure_drop>
    60e0:	f9401e60 	ldr	x0, [x19, #56]
    60e4:	97ffff6b 	bl	5e90 <fwp_closure_drop>
    60e8:	f9402260 	ldr	x0, [x19, #64]
    60ec:	97fffa81 	bl	4af0 <fwp_mem_free>
    60f0:	f9402660 	ldr	x0, [x19, #72]
    60f4:	97fffa7f 	bl	4af0 <fwp_mem_free>
    60f8:	aa1303e0 	mov	x0, x19
    60fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6100:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6104:	17fffa7b 	b	4af0 <fwp_mem_free>
    6108:	d65f03c0 	ret
    610c:	d503201f 	nop

0000000000006110 <fwp_tape_finish>:
    6110:	d10203ff 	sub	sp, sp, #0x80
    6114:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6118:	f947f421 	ldr	x1, [x1, #4072]
    611c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6120:	910103fd 	add	x29, sp, #0x40
    6124:	a90553f3 	stp	x19, x20, [sp, #80]
    6128:	a9065bf5 	stp	x21, x22, [sp, #96]
    612c:	a90763f7 	stp	x23, x24, [sp, #112]
    6130:	d00000d8 	adrp	x24, 20000 <__data_start>
    6134:	9101c316 	add	x22, x24, #0x70
    6138:	f9400022 	ldr	x2, [x1]
    613c:	f9001fe2 	str	x2, [sp, #56]
    6140:	d2800002 	mov	x2, #0x0                   	// #0
    6144:	910262c0 	add	x0, x22, #0x98
    6148:	97fff4ee 	bl	3500 <fwp_tape_buffers_dispose>
    614c:	f9006adf 	str	xzr, [x22, #208]
    6150:	f9404ac0 	ldr	x0, [x22, #144]
    6154:	f100001f 	cmp	x0, #0x0
    6158:	5400030d 	b.le	61b8 <fwp_tape_finish+0xa8>
    615c:	910003f7 	mov	x23, sp
    6160:	d2800015 	mov	x21, #0x0                   	// #0
    6164:	d2800014 	mov	x20, #0x0                   	// #0
    6168:	f94002d3 	ldr	x19, [x22]
    616c:	91000694 	add	x20, x20, #0x1
    6170:	8b150273 	add	x19, x19, x21
    6174:	9101a2b5 	add	x21, x21, #0x68
    6178:	aa1303e0 	mov	x0, x19
    617c:	97fff3a5 	bl	3010 <fwp_tape_unlink_scope>
    6180:	aa1703e0 	mov	x0, x23
    6184:	f9401261 	ldr	x1, [x19, #32]
    6188:	f90003e1 	str	x1, [sp]
    618c:	f9401a62 	ldr	x2, [x19, #48]
    6190:	f9000be2 	str	x2, [sp, #16]
    6194:	f9402261 	ldr	x1, [x19, #64]
    6198:	f90013e1 	str	x1, [sp, #32]
    619c:	97fff4d9 	bl	3500 <fwp_tape_buffers_dispose>
    61a0:	f9403260 	ldr	x0, [x19, #96]
    61a4:	97ffff8f 	bl	5fe0 <fwp_owned_tape_release>
    61a8:	f900327f 	str	xzr, [x19, #96]
    61ac:	f9404ac0 	ldr	x0, [x22, #144]
    61b0:	eb14001f 	cmp	x0, x20
    61b4:	54fffdac 	b.gt	6168 <fwp_tape_finish+0x58>
    61b8:	f9403b00 	ldr	x0, [x24, #112]
    61bc:	9101c313 	add	x19, x24, #0x70
    61c0:	97fff204 	bl	29d0 <free@plt>
    61c4:	f9003b1f 	str	xzr, [x24, #112]
    61c8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61cc:	f947f400 	ldr	x0, [x0, #4072]
    61d0:	f9004a7f 	str	xzr, [x19, #144]
    61d4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    61d8:	f9401fe2 	ldr	x2, [sp, #56]
    61dc:	f9400001 	ldr	x1, [x0]
    61e0:	eb010042 	subs	x2, x2, x1
    61e4:	d2800001 	mov	x1, #0x0                   	// #0
    61e8:	540000e1 	b.ne	6204 <fwp_tape_finish+0xf4>  // b.any
    61ec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    61f0:	a94553f3 	ldp	x19, x20, [sp, #80]
    61f4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    61fc:	910203ff 	add	sp, sp, #0x80
    6200:	d65f03c0 	ret
    6204:	97fff1c3 	bl	2910 <__stack_chk_fail@plt>
    6208:	d503201f 	nop
    620c:	d503201f 	nop

0000000000006210 <fwp_tape_scope_release>:
    6210:	d10243ff 	sub	sp, sp, #0x90
    6214:	a9047bfd 	stp	x29, x30, [sp, #64]
    6218:	910103fd 	add	x29, sp, #0x40
    621c:	a90553f3 	stp	x19, x20, [sp, #80]
    6220:	aa0003f4 	mov	x20, x0
    6224:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6228:	f947f400 	ldr	x0, [x0, #4072]
    622c:	b9400285 	ldr	w5, [x20]
    6230:	f9400001 	ldr	x1, [x0]
    6234:	f9001fe1 	str	x1, [sp, #56]
    6238:	d2800001 	mov	x1, #0x0                   	// #0
    623c:	37f806c5 	tbnz	w5, #31, 6314 <fwp_tape_scope_release+0x104>
    6240:	a90763f7 	stp	x23, x24, [sp, #112]
    6244:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6248:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    624c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6250:	d00000d3 	adrp	x19, 20000 <__data_start>
    6254:	910003f7 	mov	x23, sp
    6258:	9101c273 	add	x19, x19, #0x70
    625c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6260:	a9065bf5 	stp	x21, x22, [sp, #96]
    6264:	52800d16 	mov	w22, #0x68                  	// #104
    6268:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    626c:	f90043f9 	str	x25, [sp, #128]
    6270:	14000006 	b	6288 <fwp_tape_scope_release+0x78>
    6274:	97fff4a3 	bl	3500 <fwp_tape_buffers_dispose>
    6278:	aa1903e0 	mov	x0, x25
    627c:	97ffff59 	bl	5fe0 <fwp_owned_tape_release>
    6280:	b9400285 	ldr	w5, [x20]
    6284:	37f80425 	tbnz	w5, #31, 6308 <fwp_tape_scope_release+0xf8>
    6288:	f9400266 	ldr	x6, [x19]
    628c:	9b367ca5 	smull	x5, w5, w22
    6290:	8b0500c0 	add	x0, x6, x5
    6294:	97fff35f 	bl	3010 <fwp_tape_unlink_scope>
    6298:	ad410001 	ldp	q1, q0, [x0, #32]
    629c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    62a0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    62a4:	f9400c03 	ldr	x3, [x0, #24]
    62a8:	ad0003e1 	stp	q1, q0, [sp]
    62ac:	b86568c1 	ldr	w1, [x6, x5]
    62b0:	a9440804 	ldp	x4, x2, [x0, #64]
    62b4:	b900041f 	str	wzr, [x0, #4]
    62b8:	f9403019 	ldr	x25, [x0, #96]
    62bc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    62c0:	f9000c1f 	str	xzr, [x0, #24]
    62c4:	a9020fe4 	stp	x4, x3, [sp, #32]
    62c8:	f9001be2 	str	x2, [sp, #48]
    62cc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    62d0:	f900301f 	str	xzr, [x0, #96]
    62d4:	6b15003f 	cmp	w1, w21
    62d8:	540000e8 	b.hi	62f4 <fwp_tape_scope_release+0xe4>  // b.pmore
    62dc:	9343fca5 	asr	x5, x5, #3
    62e0:	f9407660 	ldr	x0, [x19, #232]
    62e4:	9b187ca5 	mul	x5, x5, x24
    62e8:	eb0000bf 	cmp	x5, x0
    62ec:	5400004a 	b.ge	62f4 <fwp_tape_scope_release+0xe4>  // b.tcont
    62f0:	f9007665 	str	x5, [x19, #232]
    62f4:	aa1703e0 	mov	x0, x23
    62f8:	b5fffbf9 	cbnz	x25, 6274 <fwp_tape_scope_release+0x64>
    62fc:	97fff841 	bl	4400 <fwp_tape_buffers_release>
    6300:	b9400285 	ldr	w5, [x20]
    6304:	36fffc25 	tbz	w5, #31, 6288 <fwp_tape_scope_release+0x78>
    6308:	a9465bf5 	ldp	x21, x22, [sp, #96]
    630c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6310:	f94043f9 	ldr	x25, [sp, #128]
    6314:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6318:	f947f400 	ldr	x0, [x0, #4072]
    631c:	f9401fe2 	ldr	x2, [sp, #56]
    6320:	f9400001 	ldr	x1, [x0]
    6324:	eb010042 	subs	x2, x2, x1
    6328:	d2800001 	mov	x1, #0x0                   	// #0
    632c:	540000a1 	b.ne	6340 <fwp_tape_scope_release+0x130>  // b.any
    6330:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6334:	a94553f3 	ldp	x19, x20, [sp, #80]
    6338:	910243ff 	add	sp, sp, #0x90
    633c:	d65f03c0 	ret
    6340:	a9065bf5 	stp	x21, x22, [sp, #96]
    6344:	a90763f7 	stp	x23, x24, [sp, #112]
    6348:	f90043f9 	str	x25, [sp, #128]
    634c:	97fff171 	bl	2910 <__stack_chk_fail@plt>

0000000000006350 <fwp_drop4>:
    6350:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6354:	910003fd 	mov	x29, sp
    6358:	a9025bf5 	stp	x21, x22, [sp, #32]
    635c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6360:	911742d5 	add	x21, x22, #0x5d0
    6364:	a90153f3 	stp	x19, x20, [sp, #16]
    6368:	aa0003f3 	mov	x19, x0
    636c:	f949daa1 	ldr	x1, [x21, #5040]
    6370:	f949eea0 	ldr	x0, [x21, #5080]
    6374:	cb010261 	sub	x1, x19, x1
    6378:	eb00403f 	cmp	x1, x0, lsl #16
    637c:	54000382 	b.cs	63ec <fwp_drop4+0x9c>  // b.hs, b.nlast
    6380:	d350fc22 	lsr	x2, x1, #16
    6384:	f949fea3 	ldr	x3, [x21, #5112]
    6388:	8b020842 	add	x2, x2, x2, lsl #2
    638c:	d37df042 	lsl	x2, x2, #3
    6390:	8b020060 	add	x0, x3, x2
    6394:	f9401014 	ldr	x20, [x0, #32]
    6398:	b40002b4 	cbz	x20, 63ec <fwp_drop4+0x9c>
    639c:	38626862 	ldrb	w2, [x3, x2]
    63a0:	7100085f 	cmp	w2, #0x2
    63a4:	540002c0 	b.eq	63fc <fwp_drop4+0xac>  // b.none
    63a8:	7100045f 	cmp	w2, #0x1
    63ac:	54000201 	b.ne	63ec <fwp_drop4+0x9c>  // b.any
    63b0:	29430002 	ldp	w2, w0, [x0, #24]
    63b4:	92403c21 	and	x1, x1, #0xffff
    63b8:	9b027c21 	mul	x1, x1, x2
    63bc:	d360fc21 	lsr	x1, x1, #32
    63c0:	eb00003f 	cmp	x1, x0
    63c4:	54000142 	b.cs	63ec <fwp_drop4+0x9c>  // b.hs, b.nlast
    63c8:	8b010294 	add	x20, x20, x1
    63cc:	39400280 	ldrb	w0, [x20]
    63d0:	340000e0 	cbz	w0, 63ec <fwp_drop4+0x9c>
    63d4:	7100041f 	cmp	w0, #0x1
    63d8:	540001e0 	b.eq	6414 <fwp_drop4+0xc4>  // b.none
    63dc:	7103fc1f 	cmp	w0, #0xff
    63e0:	540007c0 	b.eq	64d8 <fwp_drop4+0x188>  // b.none
    63e4:	51000400 	sub	w0, w0, #0x1
    63e8:	39000280 	strb	w0, [x20]
    63ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    63f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63f8:	d65f03c0 	ret
    63fc:	72003c3f 	tst	w1, #0xffff
    6400:	54fffe60 	b.eq	63cc <fwp_drop4+0x7c>  // b.none
    6404:	a94153f3 	ldp	x19, x20, [sp, #16]
    6408:	a9425bf5 	ldp	x21, x22, [sp, #32]
    640c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6410:	d65f03c0 	ret
    6414:	911742c2 	add	x2, x22, #0x5d0
    6418:	f9400660 	ldr	x0, [x19, #8]
    641c:	f949d841 	ldr	x1, [x2, #5040]
    6420:	f949ec42 	ldr	x2, [x2, #5080]
    6424:	cb010001 	sub	x1, x0, x1
    6428:	eb02403f 	cmp	x1, x2, lsl #16
    642c:	54000362 	b.cs	6498 <fwp_drop4+0x148>  // b.hs, b.nlast
    6430:	d350fc22 	lsr	x2, x1, #16
    6434:	8b020842 	add	x2, x2, x2, lsl #2
    6438:	d37df042 	lsl	x2, x2, #3
    643c:	8b020064 	add	x4, x3, x2
    6440:	f9401094 	ldr	x20, [x4, #32]
    6444:	b40002b4 	cbz	x20, 6498 <fwp_drop4+0x148>
    6448:	38626862 	ldrb	w2, [x3, x2]
    644c:	7100085f 	cmp	w2, #0x2
    6450:	540003e0 	b.eq	64cc <fwp_drop4+0x17c>  // b.none
    6454:	7100045f 	cmp	w2, #0x1
    6458:	54000201 	b.ne	6498 <fwp_drop4+0x148>  // b.any
    645c:	29430883 	ldp	w3, w2, [x4, #24]
    6460:	92403c21 	and	x1, x1, #0xffff
    6464:	9b037c21 	mul	x1, x1, x3
    6468:	d360fc21 	lsr	x1, x1, #32
    646c:	eb02003f 	cmp	x1, x2
    6470:	54000142 	b.cs	6498 <fwp_drop4+0x148>  // b.hs, b.nlast
    6474:	8b010294 	add	x20, x20, x1
    6478:	39400281 	ldrb	w1, [x20]
    647c:	340000e1 	cbz	w1, 6498 <fwp_drop4+0x148>
    6480:	7100043f 	cmp	w1, #0x1
    6484:	54000200 	b.eq	64c4 <fwp_drop4+0x174>  // b.none
    6488:	7103fc3f 	cmp	w1, #0xff
    648c:	54000580 	b.eq	653c <fwp_drop4+0x1ec>  // b.none
    6490:	51000421 	sub	w1, w1, #0x1
    6494:	39000281 	strb	w1, [x20]
    6498:	f9400a74 	ldr	x20, [x19, #16]
    649c:	aa1303e0 	mov	x0, x19
    64a0:	97fffd00 	bl	58a0 <fwp_rc_free_arr>
    64a4:	911742c0 	add	x0, x22, #0x5d0
    64a8:	f949d801 	ldr	x1, [x0, #5040]
    64ac:	f949ec00 	ldr	x0, [x0, #5080]
    64b0:	cb010281 	sub	x1, x20, x1
    64b4:	eb00403f 	cmp	x1, x0, lsl #16
    64b8:	54fff9a2 	b.cs	63ec <fwp_drop4+0x9c>  // b.hs, b.nlast
    64bc:	aa1403f3 	mov	x19, x20
    64c0:	17ffffb0 	b	6380 <fwp_drop4+0x30>
    64c4:	97fffcf7 	bl	58a0 <fwp_rc_free_arr>
    64c8:	17fffff4 	b	6498 <fwp_drop4+0x148>
    64cc:	72003c3f 	tst	w1, #0xffff
    64d0:	54fffe41 	b.ne	6498 <fwp_drop4+0x148>  // b.any
    64d4:	17ffffe9 	b	6478 <fwp_drop4+0x128>
    64d8:	ca544681 	eor	x1, x20, x20, lsr #17
    64dc:	911742c0 	add	x0, x22, #0x5d0
    64e0:	ca412421 	eor	x1, x1, x1, lsr #9
    64e4:	8b210c01 	add	x1, x0, w1, uxtb #3
    64e8:	f94a2420 	ldr	x0, [x1, #5192]
    64ec:	b5000080 	cbnz	x0, 64fc <fwp_drop4+0x1ac>
    64f0:	14000010 	b	6530 <fwp_drop4+0x1e0>
    64f4:	f9400800 	ldr	x0, [x0, #16]
    64f8:	b40001c0 	cbz	x0, 6530 <fwp_drop4+0x1e0>
    64fc:	f9400001 	ldr	x1, [x0]
    6500:	eb14003f 	cmp	x1, x20
    6504:	54ffff81 	b.ne	64f4 <fwp_drop4+0x1a4>  // b.any
    6508:	f9400401 	ldr	x1, [x0, #8]
    650c:	d1000421 	sub	x1, x1, #0x1
    6510:	f9000401 	str	x1, [x0, #8]
    6514:	f103f83f 	cmp	x1, #0xfe
    6518:	54fff6a1 	b.ne	63ec <fwp_drop4+0x9c>  // b.any
    651c:	aa1403e0 	mov	x0, x20
    6520:	97fff8d4 	bl	4870 <fwp_rc_forget_slot>
    6524:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6528:	39000280 	strb	w0, [x20]
    652c:	17ffffb0 	b	63ec <fwp_drop4+0x9c>
    6530:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    6534:	910f8000 	add	x0, x0, #0x3e0
    6538:	97fff4d2 	bl	3880 <fwp_trap>
    653c:	ca544680 	eor	x0, x20, x20, lsr #17
    6540:	911742c1 	add	x1, x22, #0x5d0
    6544:	ca402400 	eor	x0, x0, x0, lsr #9
    6548:	8b200c20 	add	x0, x1, w0, uxtb #3
    654c:	f94a2400 	ldr	x0, [x0, #5192]
    6550:	b5000080 	cbnz	x0, 6560 <fwp_drop4+0x210>
    6554:	17fffff7 	b	6530 <fwp_drop4+0x1e0>
    6558:	f9400800 	ldr	x0, [x0, #16]
    655c:	b4fffea0 	cbz	x0, 6530 <fwp_drop4+0x1e0>
    6560:	f9400001 	ldr	x1, [x0]
    6564:	eb14003f 	cmp	x1, x20
    6568:	54ffff81 	b.ne	6558 <fwp_drop4+0x208>  // b.any
    656c:	f9400401 	ldr	x1, [x0, #8]
    6570:	d1000421 	sub	x1, x1, #0x1
    6574:	f9000401 	str	x1, [x0, #8]
    6578:	f103f83f 	cmp	x1, #0xfe
    657c:	54fff8e1 	b.ne	6498 <fwp_drop4+0x148>  // b.any
    6580:	aa1403e0 	mov	x0, x20
    6584:	97fff8bb 	bl	4870 <fwp_rc_forget_slot>
    6588:	12800020 	mov	w0, #0xfffffffe            	// #-2
    658c:	39000280 	strb	w0, [x20]
    6590:	17ffffc2 	b	6498 <fwp_drop4+0x148>

0000000000006594 <fwp_arg_drop37>:
    6594:	7100003f 	cmp	w1, #0x0
    6598:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    659c:	54000041 	b.ne	65a4 <fwp_arg_drop37+0x10>  // b.any
    65a0:	d65f03c0 	ret
    65a4:	f9400000 	ldr	x0, [x0]
    65a8:	17ffff6a 	b	6350 <fwp_drop4>
    65ac:	d503201f 	nop

00000000000065b0 <fwp_task_dispose>:
    65b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65b4:	910003fd 	mov	x29, sp
    65b8:	f9000bf3 	str	x19, [sp, #16]
    65bc:	aa0003f3 	mov	x19, x0
    65c0:	39414000 	ldrb	w0, [x0, #80]
    65c4:	36000720 	tbz	w0, #0, 66a8 <fwp_task_dispose+0xf8>
    65c8:	f9400a60 	ldr	x0, [x19, #16]
    65cc:	b50006e0 	cbnz	x0, 66a8 <fwp_task_dispose+0xf8>
    65d0:	a9478660 	ldp	x0, x1, [x19, #120]
    65d4:	39014e7f 	strb	wzr, [x19, #83]
    65d8:	f9003e7f 	str	xzr, [x19, #120]
    65dc:	f100003f 	cmp	x1, #0x0
    65e0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65e4:	54000040 	b.eq	65ec <fwp_task_dispose+0x3c>  // b.none
    65e8:	d63f0020 	blr	x1
    65ec:	f9405660 	ldr	x0, [x19, #168]
    65f0:	97fff940 	bl	4af0 <fwp_mem_free>
    65f4:	f900567f 	str	xzr, [x19, #168]
    65f8:	b9405e60 	ldr	w0, [x19, #92]
    65fc:	7100041f 	cmp	w0, #0x1
    6600:	54000420 	b.eq	6684 <fwp_task_dispose+0xd4>  // b.none
    6604:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6608:	91174042 	add	x2, x2, #0x5d0
    660c:	f949d840 	ldr	x0, [x2, #5040]
    6610:	f949ec41 	ldr	x1, [x2, #5080]
    6614:	cb000260 	sub	x0, x19, x0
    6618:	eb01401f 	cmp	x0, x1, lsl #16
    661c:	540002e2 	b.cs	6678 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6620:	d350fc01 	lsr	x1, x0, #16
    6624:	f949fc44 	ldr	x4, [x2, #5112]
    6628:	8b010821 	add	x1, x1, x1, lsl #2
    662c:	d37df021 	lsl	x1, x1, #3
    6630:	8b010083 	add	x3, x4, x1
    6634:	f9401062 	ldr	x2, [x3, #32]
    6638:	b4000202 	cbz	x2, 6678 <fwp_task_dispose+0xc8>
    663c:	38616881 	ldrb	w1, [x4, x1]
    6640:	7100083f 	cmp	w1, #0x2
    6644:	54000280 	b.eq	6694 <fwp_task_dispose+0xe4>  // b.none
    6648:	7100043f 	cmp	w1, #0x1
    664c:	54000161 	b.ne	6678 <fwp_task_dispose+0xc8>  // b.any
    6650:	29430464 	ldp	w4, w1, [x3, #24]
    6654:	92403c00 	and	x0, x0, #0xffff
    6658:	9b047c00 	mul	x0, x0, x4
    665c:	d360fc00 	lsr	x0, x0, #32
    6660:	eb01001f 	cmp	x0, x1
    6664:	540000a2 	b.cs	6678 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6668:	8b000042 	add	x2, x2, x0
    666c:	39400040 	ldrb	w0, [x2]
    6670:	7100041f 	cmp	w0, #0x1
    6674:	54000080 	b.eq	6684 <fwp_task_dispose+0xd4>  // b.none
    6678:	f9400bf3 	ldr	x19, [sp, #16]
    667c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6680:	d65f03c0 	ret
    6684:	aa1303e0 	mov	x0, x19
    6688:	f9400bf3 	ldr	x19, [sp, #16]
    668c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6690:	17fff918 	b	4af0 <fwp_mem_free>
    6694:	72003c1f 	tst	w0, #0xffff
    6698:	54fffea0 	b.eq	666c <fwp_task_dispose+0xbc>  // b.none
    669c:	f9400bf3 	ldr	x19, [sp, #16]
    66a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66a4:	d65f03c0 	ret
    66a8:	97fff0ae 	bl	2960 <abort@plt>
    66ac:	d503201f 	nop

00000000000066b0 <fwp_free_zombie>:
    66b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66b4:	910003fd 	mov	x29, sp
    66b8:	a90153f3 	stp	x19, x20, [sp, #16]
    66bc:	d00000d4 	adrp	x20, 20000 <__data_start>
    66c0:	9101c281 	add	x1, x20, #0x70
    66c4:	f9407833 	ldr	x19, [x1, #240]
    66c8:	b4000333 	cbz	x19, 672c <fwp_free_zombie+0x7c>
    66cc:	f9400820 	ldr	x0, [x1, #16]
    66d0:	eb00027f 	cmp	x19, x0
    66d4:	540002c0 	b.eq	672c <fwp_free_zombie+0x7c>  // b.none
    66d8:	b940f822 	ldr	w2, [x1, #248]
    66dc:	f9400a60 	ldr	x0, [x19, #16]
    66e0:	7100fc5f 	cmp	w2, #0x3f
    66e4:	5400078c 	b.gt	67d4 <fwp_free_zombie+0x124>
    66e8:	91040023 	add	x3, x1, #0x100
    66ec:	11000444 	add	w4, w2, #0x1
    66f0:	b900f824 	str	w4, [x1, #248]
    66f4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66f8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66fc:	a9530261 	ldp	x1, x0, [x19, #304]
    6700:	b4000741 	cbz	x1, 67e8 <fwp_free_zombie+0x138>
    6704:	f9009c20 	str	x0, [x1, #312]
    6708:	b4000040 	cbz	x0, 6710 <fwp_free_zombie+0x60>
    670c:	f9009801 	str	x1, [x0, #304]
    6710:	9101c294 	add	x20, x20, #0x70
    6714:	b9405e60 	ldr	w0, [x19, #92]
    6718:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    671c:	f9007a9f 	str	xzr, [x20, #240]
    6720:	34000140 	cbz	w0, 6748 <fwp_free_zombie+0x98>
    6724:	7100041f 	cmp	w0, #0x1
    6728:	54000080 	b.eq	6738 <fwp_free_zombie+0x88>  // b.none
    672c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6730:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6734:	d65f03c0 	ret
    6738:	aa1303e0 	mov	x0, x19
    673c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6744:	17ffff9b 	b	65b0 <fwp_task_dispose>
    6748:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    674c:	91174082 	add	x2, x4, #0x5d0
    6750:	f949d841 	ldr	x1, [x2, #5040]
    6754:	f949ec40 	ldr	x0, [x2, #5080]
    6758:	cb010261 	sub	x1, x19, x1
    675c:	eb00403f 	cmp	x1, x0, lsl #16
    6760:	54fffe62 	b.cs	672c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6764:	d350fc20 	lsr	x0, x1, #16
    6768:	f949fc43 	ldr	x3, [x2, #5112]
    676c:	8b000800 	add	x0, x0, x0, lsl #2
    6770:	d37df000 	lsl	x0, x0, #3
    6774:	8b000062 	add	x2, x3, x0
    6778:	f9401054 	ldr	x20, [x2, #32]
    677c:	b4fffd94 	cbz	x20, 672c <fwp_free_zombie+0x7c>
    6780:	38606860 	ldrb	w0, [x3, x0]
    6784:	7100081f 	cmp	w0, #0x2
    6788:	54000360 	b.eq	67f4 <fwp_free_zombie+0x144>  // b.none
    678c:	7100041f 	cmp	w0, #0x1
    6790:	54fffce1 	b.ne	672c <fwp_free_zombie+0x7c>  // b.any
    6794:	29430043 	ldp	w3, w0, [x2, #24]
    6798:	92403c21 	and	x1, x1, #0xffff
    679c:	9b037c21 	mul	x1, x1, x3
    67a0:	d360fc21 	lsr	x1, x1, #32
    67a4:	eb00003f 	cmp	x1, x0
    67a8:	54fffc22 	b.cs	672c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    67ac:	8b010294 	add	x20, x20, x1
    67b0:	39400280 	ldrb	w0, [x20]
    67b4:	34fffbc0 	cbz	w0, 672c <fwp_free_zombie+0x7c>
    67b8:	7100041f 	cmp	w0, #0x1
    67bc:	54fffbe0 	b.eq	6738 <fwp_free_zombie+0x88>  // b.none
    67c0:	7103fc1f 	cmp	w0, #0xff
    67c4:	540001e0 	b.eq	6800 <fwp_free_zombie+0x150>  // b.none
    67c8:	51000400 	sub	w0, w0, #0x1
    67cc:	39000280 	strb	w0, [x20]
    67d0:	17ffffd7 	b	672c <fwp_free_zombie+0x7c>
    67d4:	f9400e61 	ldr	x1, [x19, #24]
    67d8:	97fff096 	bl	2a30 <munmap@plt>
    67dc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67e0:	a9530261 	ldp	x1, x0, [x19, #304]
    67e4:	b5fff901 	cbnz	x1, 6704 <fwp_free_zombie+0x54>
    67e8:	9101c282 	add	x2, x20, #0x70
    67ec:	f9018040 	str	x0, [x2, #768]
    67f0:	17ffffc6 	b	6708 <fwp_free_zombie+0x58>
    67f4:	72003c3f 	tst	w1, #0xffff
    67f8:	54fff9a1 	b.ne	672c <fwp_free_zombie+0x7c>  // b.any
    67fc:	17ffffed 	b	67b0 <fwp_free_zombie+0x100>
    6800:	ca544680 	eor	x0, x20, x20, lsr #17
    6804:	91174084 	add	x4, x4, #0x5d0
    6808:	ca402400 	eor	x0, x0, x0, lsr #9
    680c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6810:	f94a2400 	ldr	x0, [x0, #5192]
    6814:	b5000080 	cbnz	x0, 6824 <fwp_free_zombie+0x174>
    6818:	14000010 	b	6858 <fwp_free_zombie+0x1a8>
    681c:	f9400800 	ldr	x0, [x0, #16]
    6820:	b40001c0 	cbz	x0, 6858 <fwp_free_zombie+0x1a8>
    6824:	f9400001 	ldr	x1, [x0]
    6828:	eb14003f 	cmp	x1, x20
    682c:	54ffff81 	b.ne	681c <fwp_free_zombie+0x16c>  // b.any
    6830:	f9400401 	ldr	x1, [x0, #8]
    6834:	d1000421 	sub	x1, x1, #0x1
    6838:	f9000401 	str	x1, [x0, #8]
    683c:	f103f83f 	cmp	x1, #0xfe
    6840:	54fff761 	b.ne	672c <fwp_free_zombie+0x7c>  // b.any
    6844:	aa1403e0 	mov	x0, x20
    6848:	97fff80a 	bl	4870 <fwp_rc_forget_slot>
    684c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6850:	39000280 	strb	w0, [x20]
    6854:	17ffffb6 	b	672c <fwp_free_zombie+0x7c>
    6858:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    685c:	910f8000 	add	x0, x0, #0x3e0
    6860:	97fff408 	bl	3880 <fwp_trap>

0000000000006864 <fwp_block>:
    6864:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6868:	910003fd 	mov	x29, sp
    686c:	a90153f3 	stp	x19, x20, [sp, #16]
    6870:	d00000d3 	adrp	x19, 20000 <__data_start>
    6874:	9101c274 	add	x20, x19, #0x70
    6878:	f9404282 	ldr	x2, [x20, #128]
    687c:	b4000622 	cbz	x2, 6940 <fwp_block+0xdc>
    6880:	9101c261 	add	x1, x19, #0x70
    6884:	f9408040 	ldr	x0, [x2, #256]
    6888:	f9004020 	str	x0, [x1, #128]
    688c:	b4000680 	cbz	x0, 695c <fwp_block+0xf8>
    6890:	9101c263 	add	x3, x19, #0x70
    6894:	3901505f 	strb	wzr, [x2, #84]
    6898:	f9400864 	ldr	x4, [x3, #16]
    689c:	eb02009f 	cmp	x4, x2
    68a0:	54000440 	b.eq	6928 <fwp_block+0xc4>  // b.none
    68a4:	f9418465 	ldr	x5, [x3, #776]
    68a8:	f9000862 	str	x2, [x3, #16]
    68ac:	f9400441 	ldr	x1, [x2, #8]
    68b0:	f9004885 	str	x5, [x4, #144]
    68b4:	f9418865 	ldr	x5, [x3, #784]
    68b8:	f9004c85 	str	x5, [x4, #152]
    68bc:	f9418c65 	ldr	x5, [x3, #792]
    68c0:	f9005085 	str	x5, [x4, #160]
    68c4:	f9419065 	ldr	x5, [x3, #800]
    68c8:	f9005485 	str	x5, [x4, #168]
    68cc:	f9419465 	ldr	x5, [x3, #808]
    68d0:	f9005885 	str	x5, [x4, #176]
    68d4:	f9419865 	ldr	x5, [x3, #816]
    68d8:	f9005c85 	str	x5, [x4, #184]
    68dc:	f9419c65 	ldr	x5, [x3, #824]
    68e0:	f9006085 	str	x5, [x4, #192]
    68e4:	f9400480 	ldr	x0, [x4, #8]
    68e8:	f9404844 	ldr	x4, [x2, #144]
    68ec:	f9018464 	str	x4, [x3, #776]
    68f0:	f9404c44 	ldr	x4, [x2, #152]
    68f4:	f9018864 	str	x4, [x3, #784]
    68f8:	f9405044 	ldr	x4, [x2, #160]
    68fc:	f9018c64 	str	x4, [x3, #792]
    6900:	f9405444 	ldr	x4, [x2, #168]
    6904:	f9019064 	str	x4, [x3, #800]
    6908:	f9405844 	ldr	x4, [x2, #176]
    690c:	f9019464 	str	x4, [x3, #808]
    6910:	a94b8844 	ldp	x4, x2, [x2, #184]
    6914:	f9019864 	str	x4, [x3, #816]
    6918:	f9019c62 	str	x2, [x3, #824]
    691c:	97fff015 	bl	2970 <swapcontext@plt>
    6920:	97ffff64 	bl	66b0 <fwp_free_zombie>
    6924:	d503201f 	nop
    6928:	9101c260 	add	x0, x19, #0x70
    692c:	b9434000 	ldr	w0, [x0, #832]
    6930:	340001a0 	cbz	w0, 6964 <fwp_block+0x100>
    6934:	a94153f3 	ldp	x19, x20, [sp, #16]
    6938:	a8c27bfd 	ldp	x29, x30, [sp], #32
    693c:	d65f03c0 	ret
    6940:	97fff6f8 	bl	4520 <fwp_poll_events>
    6944:	f9404282 	ldr	x2, [x20, #128]
    6948:	b4ffffc2 	cbz	x2, 6940 <fwp_block+0xdc>
    694c:	9101c261 	add	x1, x19, #0x70
    6950:	f9408040 	ldr	x0, [x2, #256]
    6954:	f9004020 	str	x0, [x1, #128]
    6958:	b5fff9c0 	cbnz	x0, 6890 <fwp_block+0x2c>
    695c:	f9003c3f 	str	xzr, [x1, #120]
    6960:	17ffffcc 	b	6890 <fwp_block+0x2c>
    6964:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    6968:	91144000 	add	x0, x0, #0x510
    696c:	97fff04d 	bl	2aa0 <getenv@plt>
    6970:	5284e202 	mov	w2, #0x2710                	// #10000
    6974:	b4000060 	cbz	x0, 6980 <fwp_block+0x11c>
    6978:	39400001 	ldrb	w1, [x0]
    697c:	350000c1 	cbnz	w1, 6994 <fwp_block+0x130>
    6980:	9101c273 	add	x19, x19, #0x70
    6984:	b9034262 	str	w2, [x19, #832]
    6988:	a94153f3 	ldp	x19, x20, [sp, #16]
    698c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6990:	d65f03c0 	ret
    6994:	52800142 	mov	w2, #0xa                   	// #10
    6998:	d2800001 	mov	x1, #0x0                   	// #0
    699c:	97ffef91 	bl	27e0 <strtoll@plt>
    69a0:	d1000403 	sub	x3, x0, #0x1
    69a4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69a8:	eb02007f 	cmp	x3, x2
    69ac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69b0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69b4:	17fffff3 	b	6980 <fwp_block+0x11c>
    69b8:	d503201f 	nop
    69bc:	d503201f 	nop

00000000000069c0 <fwp_drop10>:
    69c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69c4:	910003fd 	mov	x29, sp
    69c8:	a90153f3 	stp	x19, x20, [sp, #16]
    69cc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    69d0:	f90013f5 	str	x21, [sp, #32]
    69d4:	91174275 	add	x21, x19, #0x5d0
    69d8:	f949daa1 	ldr	x1, [x21, #5040]
    69dc:	f949eea2 	ldr	x2, [x21, #5080]
    69e0:	cb010001 	sub	x1, x0, x1
    69e4:	eb02403f 	cmp	x1, x2, lsl #16
    69e8:	54000382 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    69ec:	d350fc22 	lsr	x2, x1, #16
    69f0:	f949fea3 	ldr	x3, [x21, #5112]
    69f4:	8b020842 	add	x2, x2, x2, lsl #2
    69f8:	d37df042 	lsl	x2, x2, #3
    69fc:	8b020064 	add	x4, x3, x2
    6a00:	f9401094 	ldr	x20, [x4, #32]
    6a04:	b40002b4 	cbz	x20, 6a58 <fwp_drop10+0x98>
    6a08:	38626862 	ldrb	w2, [x3, x2]
    6a0c:	7100085f 	cmp	w2, #0x2
    6a10:	540007a0 	b.eq	6b04 <fwp_drop10+0x144>  // b.none
    6a14:	7100045f 	cmp	w2, #0x1
    6a18:	54000201 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6a1c:	29430885 	ldp	w5, w2, [x4, #24]
    6a20:	92403c21 	and	x1, x1, #0xffff
    6a24:	9b057c21 	mul	x1, x1, x5
    6a28:	d360fc21 	lsr	x1, x1, #32
    6a2c:	eb02003f 	cmp	x1, x2
    6a30:	54000142 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a34:	8b010294 	add	x20, x20, x1
    6a38:	39400281 	ldrb	w1, [x20]
    6a3c:	340000e1 	cbz	w1, 6a58 <fwp_drop10+0x98>
    6a40:	7100043f 	cmp	w1, #0x1
    6a44:	54000120 	b.eq	6a68 <fwp_drop10+0xa8>  // b.none
    6a48:	7103fc3f 	cmp	w1, #0xff
    6a4c:	540007c0 	b.eq	6b44 <fwp_drop10+0x184>  // b.none
    6a50:	51000421 	sub	w1, w1, #0x1
    6a54:	39000281 	strb	w1, [x20]
    6a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a5c:	f94013f5 	ldr	x21, [sp, #32]
    6a60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a64:	d65f03c0 	ret
    6a68:	f9400001 	ldr	x1, [x0]
    6a6c:	b7f80581 	tbnz	x1, #63, 6b1c <fwp_drop10+0x15c>
    6a70:	91174273 	add	x19, x19, #0x5d0
    6a74:	f949da61 	ldr	x1, [x19, #5040]
    6a78:	f949ee62 	ldr	x2, [x19, #5080]
    6a7c:	cb010001 	sub	x1, x0, x1
    6a80:	eb02403f 	cmp	x1, x2, lsl #16
    6a84:	54fffea2 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a88:	d350fc22 	lsr	x2, x1, #16
    6a8c:	8b020842 	add	x2, x2, x2, lsl #2
    6a90:	d37df042 	lsl	x2, x2, #3
    6a94:	8b020065 	add	x5, x3, x2
    6a98:	f94010a4 	ldr	x4, [x5, #32]
    6a9c:	b4fffde4 	cbz	x4, 6a58 <fwp_drop10+0x98>
    6aa0:	38626862 	ldrb	w2, [x3, x2]
    6aa4:	7100085f 	cmp	w2, #0x2
    6aa8:	54000220 	b.eq	6aec <fwp_drop10+0x12c>  // b.none
    6aac:	7100045f 	cmp	w2, #0x1
    6ab0:	54fffd41 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6ab4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ab8:	92403c21 	and	x1, x1, #0xffff
    6abc:	9b037c21 	mul	x1, x1, x3
    6ac0:	d360fc21 	lsr	x1, x1, #32
    6ac4:	eb02003f 	cmp	x1, x2
    6ac8:	54fffc82 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6acc:	8b010084 	add	x4, x4, x1
    6ad0:	39400081 	ldrb	w1, [x4]
    6ad4:	7100043f 	cmp	w1, #0x1
    6ad8:	54fffc01 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6adc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ae0:	f94013f5 	ldr	x21, [sp, #32]
    6ae4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ae8:	17fff802 	b	4af0 <fwp_mem_free>
    6aec:	72003c3f 	tst	w1, #0xffff
    6af0:	54ffff00 	b.eq	6ad0 <fwp_drop10+0x110>  // b.none
    6af4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6af8:	f94013f5 	ldr	x21, [sp, #32]
    6afc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b00:	d65f03c0 	ret
    6b04:	72003c3f 	tst	w1, #0xffff
    6b08:	54fff980 	b.eq	6a38 <fwp_drop10+0x78>  // b.none
    6b0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b10:	f94013f5 	ldr	x21, [sp, #32]
    6b14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b18:	d65f03c0 	ret
    6b1c:	f9400414 	ldr	x20, [x0, #8]
    6b20:	97fffb60 	bl	58a0 <fwp_rc_free_arr>
    6b24:	91174260 	add	x0, x19, #0x5d0
    6b28:	f949d801 	ldr	x1, [x0, #5040]
    6b2c:	f949ec00 	ldr	x0, [x0, #5080]
    6b30:	cb010281 	sub	x1, x20, x1
    6b34:	eb00403f 	cmp	x1, x0, lsl #16
    6b38:	54fff902 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b3c:	aa1403e0 	mov	x0, x20
    6b40:	17ffffab 	b	69ec <fwp_drop10+0x2c>
    6b44:	ca544680 	eor	x0, x20, x20, lsr #17
    6b48:	91174273 	add	x19, x19, #0x5d0
    6b4c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b50:	8b200e60 	add	x0, x19, w0, uxtb #3
    6b54:	f94a2400 	ldr	x0, [x0, #5192]
    6b58:	b5000080 	cbnz	x0, 6b68 <fwp_drop10+0x1a8>
    6b5c:	14000010 	b	6b9c <fwp_drop10+0x1dc>
    6b60:	f9400800 	ldr	x0, [x0, #16]
    6b64:	b40001c0 	cbz	x0, 6b9c <fwp_drop10+0x1dc>
    6b68:	f9400001 	ldr	x1, [x0]
    6b6c:	eb14003f 	cmp	x1, x20
    6b70:	54ffff81 	b.ne	6b60 <fwp_drop10+0x1a0>  // b.any
    6b74:	f9400401 	ldr	x1, [x0, #8]
    6b78:	d1000421 	sub	x1, x1, #0x1
    6b7c:	f9000401 	str	x1, [x0, #8]
    6b80:	f103f83f 	cmp	x1, #0xfe
    6b84:	54fff6a1 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6b88:	aa1403e0 	mov	x0, x20
    6b8c:	97fff739 	bl	4870 <fwp_rc_forget_slot>
    6b90:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b94:	39000280 	strb	w0, [x20]
    6b98:	17ffffb0 	b	6a58 <fwp_drop10+0x98>
    6b9c:	f0000020 	adrp	x0, d000 <__modti3+0x320>
    6ba0:	910f8000 	add	x0, x0, #0x3e0
    6ba4:	97fff337 	bl	3880 <fwp_trap>
    6ba8:	d503201f 	nop
    6bac:	d503201f 	nop

0000000000006bb0 <fwp_caps173>:
    6bb0:	34000041 	cbz	w1, 6bb8 <fwp_caps173+0x8>
    6bb4:	d65f03c0 	ret
    6bb8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6bbc:	91174063 	add	x3, x3, #0x5d0
    6bc0:	f949d861 	ldr	x1, [x3, #5040]
    6bc4:	f949ec62 	ldr	x2, [x3, #5080]
    6bc8:	cb010001 	sub	x1, x0, x1
    6bcc:	eb02403f 	cmp	x1, x2, lsl #16
    6bd0:	54ffff22 	b.cs	6bb4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6bd4:	d350fc22 	lsr	x2, x1, #16
    6bd8:	f949fc65 	ldr	x5, [x3, #5112]
    6bdc:	8b020842 	add	x2, x2, x2, lsl #2
    6be0:	d37df042 	lsl	x2, x2, #3
    6be4:	8b0200a4 	add	x4, x5, x2
    6be8:	f9401083 	ldr	x3, [x4, #32]
    6bec:	b4fffe43 	cbz	x3, 6bb4 <fwp_caps173+0x4>
    6bf0:	386268a2 	ldrb	w2, [x5, x2]
    6bf4:	7100085f 	cmp	w2, #0x2
    6bf8:	540001c0 	b.eq	6c30 <fwp_caps173+0x80>  // b.none
    6bfc:	7100045f 	cmp	w2, #0x1
    6c00:	54fffda1 	b.ne	6bb4 <fwp_caps173+0x4>  // b.any
    6c04:	29430885 	ldp	w5, w2, [x4, #24]
    6c08:	92403c21 	and	x1, x1, #0xffff
    6c0c:	9b057c21 	mul	x1, x1, x5
    6c10:	d360fc21 	lsr	x1, x1, #32
    6c14:	eb02003f 	cmp	x1, x2
    6c18:	54fffce2 	b.cs	6bb4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c1c:	8b010063 	add	x3, x3, x1
    6c20:	39400061 	ldrb	w1, [x3]
    6c24:	7100043f 	cmp	w1, #0x1
    6c28:	54fffc61 	b.ne	6bb4 <fwp_caps173+0x4>  // b.any
    6c2c:	17fff7b1 	b	4af0 <fwp_mem_free>
    6c30:	72003c3f 	tst	w1, #0xffff
    6c34:	54ffff60 	b.eq	6c20 <fwp_caps173+0x70>  // b.none
    6c38:	d65f03c0 	ret
    6c3c:	d503201f 	nop

0000000000006c40 <fwp_args37>:
    6c40:	7100003f 	cmp	w1, #0x0
    6c44:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c48:	54000041 	b.ne	6c50 <fwp_args37+0x10>  // b.any
    6c4c:	d65f03c0 	ret
    6c50:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6c54:	91174042 	add	x2, x2, #0x5d0
    6c58:	f9400001 	ldr	x1, [x0]
    6c5c:	f949d843 	ldr	x3, [x2, #5040]
    6c60:	f949ec40 	ldr	x0, [x2, #5080]
    6c64:	cb030021 	sub	x1, x1, x3
    6c68:	eb00403f 	cmp	x1, x0, lsl #16
    6c6c:	54ffff02 	b.cs	6c4c <fwp_args37+0xc>  // b.hs, b.nlast
    6c70:	d350fc20 	lsr	x0, x1, #16
    6c74:	f949fc44 	ldr	x4, [x2, #5112]
    6c78:	8b000800 	add	x0, x0, x0, lsl #2
    6c7c:	d37df002 	lsl	x2, x0, #3
    6c80:	8b020083 	add	x3, x4, x2
    6c84:	f9401060 	ldr	x0, [x3, #32]
    6c88:	b4fffe20 	cbz	x0, 6c4c <fwp_args37+0xc>
    6c8c:	38626882 	ldrb	w2, [x4, x2]
    6c90:	7100085f 	cmp	w2, #0x2
    6c94:	54000220 	b.eq	6cd8 <fwp_args37+0x98>  // b.none
    6c98:	7100045f 	cmp	w2, #0x1
    6c9c:	54fffd81 	b.ne	6c4c <fwp_args37+0xc>  // b.any
    6ca0:	29430864 	ldp	w4, w2, [x3, #24]
    6ca4:	92403c21 	and	x1, x1, #0xffff
    6ca8:	9b047c21 	mul	x1, x1, x4
    6cac:	d360fc21 	lsr	x1, x1, #32
    6cb0:	eb02003f 	cmp	x1, x2
    6cb4:	54fffcc2 	b.cs	6c4c <fwp_args37+0xc>  // b.hs, b.nlast
    6cb8:	8b010000 	add	x0, x0, x1
    6cbc:	39400001 	ldrb	w1, [x0]
    6cc0:	34fffc61 	cbz	w1, 6c4c <fwp_args37+0xc>
    6cc4:	7103f43f 	cmp	w1, #0xfd
    6cc8:	540000e8 	b.hi	6ce4 <fwp_args37+0xa4>  // b.pmore
    6ccc:	11000421 	add	w1, w1, #0x1
    6cd0:	39000001 	strb	w1, [x0]
    6cd4:	d65f03c0 	ret
    6cd8:	72003c3f 	tst	w1, #0xffff
    6cdc:	54ffff00 	b.eq	6cbc <fwp_args37+0x7c>  // b.none
    6ce0:	d65f03c0 	ret
    6ce4:	17fff69c 	b	4754 <fwp_rc_wide_dup>
    6ce8:	d503201f 	nop
    6cec:	d503201f 	nop

0000000000006cf0 <fwp_caps37>:
    6cf0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6cf4:	910003fd 	mov	x29, sp
    6cf8:	f9000bf3 	str	x19, [sp, #16]
    6cfc:	aa0003f3 	mov	x19, x0
    6d00:	b9400400 	ldr	w0, [x0, #4]
    6d04:	340004a0 	cbz	w0, 6d98 <fwp_caps37+0xa8>
    6d08:	f9400660 	ldr	x0, [x19, #8]
    6d0c:	350004e1 	cbnz	w1, 6da8 <fwp_caps37+0xb8>
    6d10:	97fffd90 	bl	6350 <fwp_drop4>
    6d14:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6d18:	91174042 	add	x2, x2, #0x5d0
    6d1c:	f949d840 	ldr	x0, [x2, #5040]
    6d20:	f949ec41 	ldr	x1, [x2, #5080]
    6d24:	cb000260 	sub	x0, x19, x0
    6d28:	eb01401f 	cmp	x0, x1, lsl #16
    6d2c:	54000382 	b.cs	6d9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6d30:	d350fc01 	lsr	x1, x0, #16
    6d34:	f949fc44 	ldr	x4, [x2, #5112]
    6d38:	8b010821 	add	x1, x1, x1, lsl #2
    6d3c:	d37df021 	lsl	x1, x1, #3
    6d40:	8b010083 	add	x3, x4, x1
    6d44:	f9401062 	ldr	x2, [x3, #32]
    6d48:	b40002a2 	cbz	x2, 6d9c <fwp_caps37+0xac>
    6d4c:	38616881 	ldrb	w1, [x4, x1]
    6d50:	7100083f 	cmp	w1, #0x2
    6d54:	540006c0 	b.eq	6e2c <fwp_caps37+0x13c>  // b.none
    6d58:	7100043f 	cmp	w1, #0x1
    6d5c:	54000201 	b.ne	6d9c <fwp_caps37+0xac>  // b.any
    6d60:	29430464 	ldp	w4, w1, [x3, #24]
    6d64:	92403c00 	and	x0, x0, #0xffff
    6d68:	9b047c00 	mul	x0, x0, x4
    6d6c:	d360fc00 	lsr	x0, x0, #32
    6d70:	eb01001f 	cmp	x0, x1
    6d74:	54000142 	b.cs	6d9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6d78:	8b000042 	add	x2, x2, x0
    6d7c:	39400040 	ldrb	w0, [x2]
    6d80:	7100041f 	cmp	w0, #0x1
    6d84:	540000c1 	b.ne	6d9c <fwp_caps37+0xac>  // b.any
    6d88:	aa1303e0 	mov	x0, x19
    6d8c:	f9400bf3 	ldr	x19, [sp, #16]
    6d90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d94:	17fff757 	b	4af0 <fwp_mem_free>
    6d98:	34fffbe1 	cbz	w1, 6d14 <fwp_caps37+0x24>
    6d9c:	f9400bf3 	ldr	x19, [sp, #16]
    6da0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6da4:	d65f03c0 	ret
    6da8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6dac:	91174042 	add	x2, x2, #0x5d0
    6db0:	f949d843 	ldr	x3, [x2, #5040]
    6db4:	f949ec41 	ldr	x1, [x2, #5080]
    6db8:	cb030000 	sub	x0, x0, x3
    6dbc:	eb01401f 	cmp	x0, x1, lsl #16
    6dc0:	54fffee2 	b.cs	6d9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6dc4:	d350fc01 	lsr	x1, x0, #16
    6dc8:	f949fc44 	ldr	x4, [x2, #5112]
    6dcc:	8b010821 	add	x1, x1, x1, lsl #2
    6dd0:	d37df021 	lsl	x1, x1, #3
    6dd4:	8b010083 	add	x3, x4, x1
    6dd8:	f9401062 	ldr	x2, [x3, #32]
    6ddc:	b4fffe02 	cbz	x2, 6d9c <fwp_caps37+0xac>
    6de0:	38616881 	ldrb	w1, [x4, x1]
    6de4:	7100083f 	cmp	w1, #0x2
    6de8:	54000280 	b.eq	6e38 <fwp_caps37+0x148>  // b.none
    6dec:	7100043f 	cmp	w1, #0x1
    6df0:	54fffd61 	b.ne	6d9c <fwp_caps37+0xac>  // b.any
    6df4:	92403c01 	and	x1, x0, #0xffff
    6df8:	29430064 	ldp	w4, w0, [x3, #24]
    6dfc:	9b047c21 	mul	x1, x1, x4
    6e00:	d360fc21 	lsr	x1, x1, #32
    6e04:	eb00003f 	cmp	x1, x0
    6e08:	54fffca2 	b.cs	6d9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6e0c:	8b010042 	add	x2, x2, x1
    6e10:	39400040 	ldrb	w0, [x2]
    6e14:	34fffc40 	cbz	w0, 6d9c <fwp_caps37+0xac>
    6e18:	7103f41f 	cmp	w0, #0xfd
    6e1c:	54000148 	b.hi	6e44 <fwp_caps37+0x154>  // b.pmore
    6e20:	11000400 	add	w0, w0, #0x1
    6e24:	39000040 	strb	w0, [x2]
    6e28:	17ffffdd 	b	6d9c <fwp_caps37+0xac>
    6e2c:	72003c1f 	tst	w0, #0xffff
    6e30:	54fffb61 	b.ne	6d9c <fwp_caps37+0xac>  // b.any
    6e34:	17ffffd2 	b	6d7c <fwp_caps37+0x8c>
    6e38:	72003c1f 	tst	w0, #0xffff
    6e3c:	54fffb01 	b.ne	6d9c <fwp_caps37+0xac>  // b.any
    6e40:	17fffff4 	b	6e10 <fwp_caps37+0x120>
    6e44:	f9400bf3 	ldr	x19, [sp, #16]
    6e48:	aa0203e0 	mov	x0, x2
    6e4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e50:	17fff641 	b	4754 <fwp_rc_wide_dup>

0000000000006e54 <f37>:
    6e54:	d101c3ff 	sub	sp, sp, #0x70
    6e58:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6e5c:	f947f421 	ldr	x1, [x1, #4072]
    6e60:	a9027bfd 	stp	x29, x30, [sp, #32]
    6e64:	910083fd 	add	x29, sp, #0x20
    6e68:	a90563f7 	stp	x23, x24, [sp, #80]
    6e6c:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    6e70:	911742e3 	add	x3, x23, #0x5d0
    6e74:	a90353f3 	stp	x19, x20, [sp, #48]
    6e78:	a9045bf5 	stp	x21, x22, [sp, #64]
    6e7c:	aa0003f6 	mov	x22, x0
    6e80:	a9066bf9 	stp	x25, x26, [sp, #96]
    6e84:	f949ec62 	ldr	x2, [x3, #5080]
    6e88:	f9400024 	ldr	x4, [x1]
    6e8c:	f9000fe4 	str	x4, [sp, #24]
    6e90:	d2800004 	mov	x4, #0x0                   	// #0
    6e94:	f949d861 	ldr	x1, [x3, #5040]
    6e98:	d370bc42 	lsl	x2, x2, #16
    6e9c:	b40015a0 	cbz	x0, 7150 <f37+0x2fc>
    6ea0:	f9400818 	ldr	x24, [x0, #16]
    6ea4:	cb010301 	sub	x1, x24, x1
    6ea8:	eb02003f 	cmp	x1, x2
    6eac:	54000362 	b.cs	6f18 <f37+0xc4>  // b.hs, b.nlast
    6eb0:	f949fc60 	ldr	x0, [x3, #5112]
    6eb4:	d350fc22 	lsr	x2, x1, #16
    6eb8:	8b020842 	add	x2, x2, x2, lsl #2
    6ebc:	8b020c02 	add	x2, x0, x2, lsl #3
    6ec0:	f9401040 	ldr	x0, [x2, #32]
    6ec4:	b40002a0 	cbz	x0, 6f18 <f37+0xc4>
    6ec8:	39400043 	ldrb	w3, [x2]
    6ecc:	7100087f 	cmp	w3, #0x2
    6ed0:	540013a0 	b.eq	7144 <f37+0x2f0>  // b.none
    6ed4:	7100047f 	cmp	w3, #0x1
    6ed8:	540001c1 	b.ne	6f10 <f37+0xbc>  // b.any
    6edc:	29430843 	ldp	w3, w2, [x2, #24]
    6ee0:	92403c21 	and	x1, x1, #0xffff
    6ee4:	9b037c21 	mul	x1, x1, x3
    6ee8:	d360fc21 	lsr	x1, x1, #32
    6eec:	eb02003f 	cmp	x1, x2
    6ef0:	54000102 	b.cs	6f10 <f37+0xbc>  // b.hs, b.nlast
    6ef4:	8b010000 	add	x0, x0, x1
    6ef8:	39400001 	ldrb	w1, [x0]
    6efc:	340000a1 	cbz	w1, 6f10 <f37+0xbc>
    6f00:	7103f43f 	cmp	w1, #0xfd
    6f04:	54001688 	b.hi	71d4 <f37+0x380>  // b.pmore
    6f08:	11000421 	add	w1, w1, #0x1
    6f0c:	39000001 	strb	w1, [x0]
    6f10:	d2800000 	mov	x0, #0x0                   	// #0
    6f14:	b40000d6 	cbz	x22, 6f2c <f37+0xd8>
    6f18:	aa1603e1 	mov	x1, x22
    6f1c:	d2800000 	mov	x0, #0x0                   	// #0
    6f20:	f9400821 	ldr	x1, [x1, #16]
    6f24:	91000400 	add	x0, x0, #0x1
    6f28:	b5ffffc1 	cbnz	x1, 6f20 <f37+0xcc>
    6f2c:	b40011b8 	cbz	x24, 7160 <f37+0x30c>
    6f30:	aa1803e1 	mov	x1, x24
    6f34:	d2800002 	mov	x2, #0x0                   	// #0
    6f38:	f9400821 	ldr	x1, [x1, #16]
    6f3c:	91000442 	add	x2, x2, #0x1
    6f40:	b5ffffc1 	cbnz	x1, 6f38 <f37+0xe4>
    6f44:	eb00005f 	cmp	x2, x0
    6f48:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6f4c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6f50:	eb01033f 	cmp	x25, x1
    6f54:	54001468 	b.hi	71e0 <f37+0x38c>  // b.pmore
    6f58:	d37ffb33 	lsl	x19, x25, #1
    6f5c:	52800041 	mov	w1, #0x2                   	// #2
    6f60:	91000660 	add	x0, x19, #0x1
    6f64:	d37df000 	lsl	x0, x0, #3
    6f68:	97fff802 	bl	4f70 <fwp_heap_alloc>
    6f6c:	911742e1 	add	x1, x23, #0x5d0
    6f70:	aa0003fa 	mov	x26, x0
    6f74:	f9000013 	str	x19, [x0]
    6f78:	aa0103e0 	mov	x0, x1
    6f7c:	f949d821 	ldr	x1, [x1, #5040]
    6f80:	f949ec00 	ldr	x0, [x0, #5080]
    6f84:	cb010341 	sub	x1, x26, x1
    6f88:	eb00403f 	cmp	x1, x0, lsl #16
    6f8c:	54000342 	b.cs	6ff4 <f37+0x1a0>  // b.hs, b.nlast
    6f90:	911742e2 	add	x2, x23, #0x5d0
    6f94:	d350fc20 	lsr	x0, x1, #16
    6f98:	8b000800 	add	x0, x0, x0, lsl #2
    6f9c:	f949fc43 	ldr	x3, [x2, #5112]
    6fa0:	d37df002 	lsl	x2, x0, #3
    6fa4:	8b020060 	add	x0, x3, x2
    6fa8:	f9401013 	ldr	x19, [x0, #32]
    6fac:	b4000253 	cbz	x19, 6ff4 <f37+0x1a0>
    6fb0:	38626862 	ldrb	w2, [x3, x2]
    6fb4:	7100085f 	cmp	w2, #0x2
    6fb8:	54000c00 	b.eq	7138 <f37+0x2e4>  // b.none
    6fbc:	7100045f 	cmp	w2, #0x1
    6fc0:	540001a1 	b.ne	6ff4 <f37+0x1a0>  // b.any
    6fc4:	29430002 	ldp	w2, w0, [x0, #24]
    6fc8:	92403c21 	and	x1, x1, #0xffff
    6fcc:	9b027c21 	mul	x1, x1, x2
    6fd0:	d360fc21 	lsr	x1, x1, #32
    6fd4:	eb00003f 	cmp	x1, x0
    6fd8:	540000e2 	b.cs	6ff4 <f37+0x1a0>  // b.hs, b.nlast
    6fdc:	8b010273 	add	x19, x19, x1
    6fe0:	39400260 	ldrb	w0, [x19]
    6fe4:	7103fc1f 	cmp	w0, #0xff
    6fe8:	54000da0 	b.eq	719c <f37+0x348>  // b.none
    6fec:	52800020 	mov	w0, #0x1                   	// #1
    6ff0:	39000260 	strb	w0, [x19]
    6ff4:	b4000259 	cbz	x25, 703c <f37+0x1e8>
    6ff8:	8b191359 	add	x25, x26, x25, lsl #4
    6ffc:	aa1a03f3 	mov	x19, x26
    7000:	aa1603f5 	mov	x21, x22
    7004:	aa1803f4 	mov	x20, x24
    7008:	f9400683 	ldr	x3, [x20, #8]
    700c:	f94006a2 	ldr	x2, [x21, #8]
    7010:	f9400861 	ldr	x1, [x3, #16]
    7014:	f9400840 	ldr	x0, [x2, #16]
    7018:	fd400461 	ldr	d1, [x3, #8]
    701c:	fd400440 	ldr	d0, [x2, #8]
    7020:	97fff944 	bl	5530 <w120>
    7024:	f9000660 	str	x0, [x19, #8]
    7028:	f8010e61 	str	x1, [x19, #16]!
    702c:	f9400a94 	ldr	x20, [x20, #16]
    7030:	f9400ab5 	ldr	x21, [x21, #16]
    7034:	eb13033f 	cmp	x25, x19
    7038:	54fffe81 	b.ne	7008 <f37+0x1b4>  // b.any
    703c:	aa1803e0 	mov	x0, x24
    7040:	97fffcc4 	bl	6350 <fwp_drop4>
    7044:	aa1603e0 	mov	x0, x22
    7048:	97fffcc2 	bl	6350 <fwp_drop4>
    704c:	911742f7 	add	x23, x23, #0x5d0
    7050:	aa1a03e0 	mov	x0, x26
    7054:	97fff994 	bl	56a4 <w176.constprop.0>
    7058:	aa0103f3 	mov	x19, x1
    705c:	aa0003f4 	mov	x20, x0
    7060:	aa1a03e0 	mov	x0, x26
    7064:	97fffe57 	bl	69c0 <fwp_drop10>
    7068:	a900cff4 	stp	x20, x19, [sp, #8]
    706c:	910023e1 	add	x1, sp, #0x8
    7070:	52800000 	mov	w0, #0x0                   	// #0
    7074:	97fff804 	bl	5084 <fwp_data.part.0.constprop.0>
    7078:	f949dae1 	ldr	x1, [x23, #5040]
    707c:	aa0003f3 	mov	x19, x0
    7080:	f949eee0 	ldr	x0, [x23, #5080]
    7084:	cb010261 	sub	x1, x19, x1
    7088:	eb00403f 	cmp	x1, x0, lsl #16
    708c:	54000322 	b.cs	70f0 <f37+0x29c>  // b.hs, b.nlast
    7090:	d350fc22 	lsr	x2, x1, #16
    7094:	f949fee3 	ldr	x3, [x23, #5112]
    7098:	8b020842 	add	x2, x2, x2, lsl #2
    709c:	d37df042 	lsl	x2, x2, #3
    70a0:	8b020060 	add	x0, x3, x2
    70a4:	f9401014 	ldr	x20, [x0, #32]
    70a8:	b4000254 	cbz	x20, 70f0 <f37+0x29c>
    70ac:	38626862 	ldrb	w2, [x3, x2]
    70b0:	7100085f 	cmp	w2, #0x2
    70b4:	540003c0 	b.eq	712c <f37+0x2d8>  // b.none
    70b8:	7100045f 	cmp	w2, #0x1
    70bc:	540001a1 	b.ne	70f0 <f37+0x29c>  // b.any
    70c0:	29430002 	ldp	w2, w0, [x0, #24]
    70c4:	92403c21 	and	x1, x1, #0xffff
    70c8:	9b027c21 	mul	x1, x1, x2
    70cc:	d360fc21 	lsr	x1, x1, #32
    70d0:	eb00003f 	cmp	x1, x0
    70d4:	540000e2 	b.cs	70f0 <f37+0x29c>  // b.hs, b.nlast
    70d8:	8b010294 	add	x20, x20, x1
    70dc:	39400280 	ldrb	w0, [x20]
    70e0:	7103fc1f 	cmp	w0, #0xff
    70e4:	54000620 	b.eq	71a8 <f37+0x354>  // b.none
    70e8:	52800020 	mov	w0, #0x1                   	// #1
    70ec:	39000280 	strb	w0, [x20]
    70f0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    70f4:	f947f400 	ldr	x0, [x0, #4072]
    70f8:	f9400fe2 	ldr	x2, [sp, #24]
    70fc:	f9400001 	ldr	x1, [x0]
    7100:	eb010042 	subs	x2, x2, x1
    7104:	d2800001 	mov	x1, #0x0                   	// #0
    7108:	540006a1 	b.ne	71dc <f37+0x388>  // b.any
    710c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7110:	aa1303e0 	mov	x0, x19
    7114:	a94353f3 	ldp	x19, x20, [sp, #48]
    7118:	a9445bf5 	ldp	x21, x22, [sp, #64]
    711c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7120:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7124:	9101c3ff 	add	sp, sp, #0x70
    7128:	d65f03c0 	ret
    712c:	72003c3f 	tst	w1, #0xffff
    7130:	54fffe01 	b.ne	70f0 <f37+0x29c>  // b.any
    7134:	17ffffea 	b	70dc <f37+0x288>
    7138:	72003c3f 	tst	w1, #0xffff
    713c:	54fff5c1 	b.ne	6ff4 <f37+0x1a0>  // b.any
    7140:	17ffffa8 	b	6fe0 <f37+0x18c>
    7144:	72003c3f 	tst	w1, #0xffff
    7148:	54ffee41 	b.ne	6f10 <f37+0xbc>  // b.any
    714c:	17ffff6b 	b	6ef8 <f37+0xa4>
    7150:	cb0103e1 	neg	x1, x1
    7154:	eb02003f 	cmp	x1, x2
    7158:	540002e3 	b.cc	71b4 <f37+0x360>  // b.lo, b.ul, b.last
    715c:	d503201f 	nop
    7160:	52800041 	mov	w1, #0x2                   	// #2
    7164:	d2800100 	mov	x0, #0x8                   	// #8
    7168:	97fff782 	bl	4f70 <fwp_heap_alloc>
    716c:	aa0003e1 	mov	x1, x0
    7170:	911742e0 	add	x0, x23, #0x5d0
    7174:	aa0103fa 	mov	x26, x1
    7178:	d2800018 	mov	x24, #0x0                   	// #0
    717c:	f900003f 	str	xzr, [x1]
    7180:	f949d801 	ldr	x1, [x0, #5040]
    7184:	f949ec00 	ldr	x0, [x0, #5080]
    7188:	cb010341 	sub	x1, x26, x1
    718c:	eb00403f 	cmp	x1, x0, lsl #16
    7190:	54fff562 	b.cs	703c <f37+0x1e8>  // b.hs, b.nlast
    7194:	d2800019 	mov	x25, #0x0                   	// #0
    7198:	17ffff7e 	b	6f90 <f37+0x13c>
    719c:	aa1303e0 	mov	x0, x19
    71a0:	97fff5b4 	bl	4870 <fwp_rc_forget_slot>
    71a4:	17ffff92 	b	6fec <f37+0x198>
    71a8:	aa1403e0 	mov	x0, x20
    71ac:	97fff5b1 	bl	4870 <fwp_rc_forget_slot>
    71b0:	17ffffce 	b	70e8 <f37+0x294>
    71b4:	f949fc62 	ldr	x2, [x3, #5112]
    71b8:	d350fc20 	lsr	x0, x1, #16
    71bc:	8b000800 	add	x0, x0, x0, lsl #2
    71c0:	8b000c42 	add	x2, x2, x0, lsl #3
    71c4:	f9401040 	ldr	x0, [x2, #32]
    71c8:	b4fffcc0 	cbz	x0, 7160 <f37+0x30c>
    71cc:	d2800018 	mov	x24, #0x0                   	// #0
    71d0:	17ffff3e 	b	6ec8 <f37+0x74>
    71d4:	97fff560 	bl	4754 <fwp_rc_wide_dup>
    71d8:	17ffff4e 	b	6f10 <f37+0xbc>
    71dc:	97ffedcd 	bl	2910 <__stack_chk_fail@plt>
    71e0:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    71e4:	91148000 	add	x0, x0, #0x520
    71e8:	97fff1a6 	bl	3880 <fwp_trap>
    71ec:	d503201f 	nop

00000000000071f0 <fwp_owned_entry37>:
    71f0:	f9400000 	ldr	x0, [x0]
    71f4:	17ffff18 	b	6e54 <f37>
    71f8:	d503201f 	nop
    71fc:	d503201f 	nop

0000000000007200 <e37>:
    7200:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7204:	910003fd 	mov	x29, sp
    7208:	f9000bf3 	str	x19, [sp, #16]
    720c:	f9400013 	ldr	x19, [x0]
    7210:	aa1303e0 	mov	x0, x19
    7214:	97fff94c 	bl	5744 <fwp_rc_share>
    7218:	aa1303e0 	mov	x0, x19
    721c:	97ffff0e 	bl	6e54 <f37>
    7220:	aa0003f3 	mov	x19, x0
    7224:	97fff948 	bl	5744 <fwp_rc_share>
    7228:	aa1303e0 	mov	x0, x19
    722c:	f9400bf3 	ldr	x19, [sp, #16]
    7230:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7234:	d65f03c0 	ret
    7238:	d503201f 	nop
    723c:	d503201f 	nop

0000000000007240 <fwp_write>:
    7240:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7244:	910003fd 	mov	x29, sp
    7248:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    724c:	f947f484 	ldr	x4, [x4, #4072]
    7250:	a90153f3 	stp	x19, x20, [sp, #16]
    7254:	d10943ff 	sub	sp, sp, #0x250
    7258:	b9400045 	ldr	w5, [x2]
    725c:	aa0003f4 	mov	x20, x0
    7260:	f9400080 	ldr	x0, [x4]
    7264:	f90127e0 	str	x0, [sp, #584]
    7268:	d2800000 	mov	x0, #0x0                   	// #0
    726c:	710064bf 	cmp	w5, #0x19
    7270:	54000408 	b.hi	72f0 <fwp_write+0xb0>  // b.pmore
    7274:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    7278:	aa0103f3 	mov	x19, x1
    727c:	9137c000 	add	x0, x0, #0xdf0
    7280:	f9013bf5 	str	x21, [sp, #624]
    7284:	f9013ff6 	str	x22, [sp, #632]
    7288:	f90153fb 	str	x27, [sp, #672]
    728c:	f90157fc 	str	x28, [sp, #680]
    7290:	aa0203fc 	mov	x28, x2
    7294:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7298:	10000061 	adr	x1, 72a4 <fwp_write+0x64>
    729c:	8b20a820 	add	x0, x1, w0, sxth #2
    72a0:	d61f0000 	br	x0
    72a4:	910123e0 	add	x0, sp, #0x48
    72a8:	aa1303e5 	mov	x5, x19
    72ac:	d0000024 	adrp	x4, d000 <__modti3+0x320>
    72b0:	aa0003f3 	mov	x19, x0
    72b4:	9115a084 	add	x4, x4, #0x568
    72b8:	d2804003 	mov	x3, #0x200                 	// #512
    72bc:	aa0303e1 	mov	x1, x3
    72c0:	52800042 	mov	w2, #0x2                   	// #2
    72c4:	97ffed6f 	bl	2880 <__snprintf_chk@plt>
    72c8:	aa1303e0 	mov	x0, x19
    72cc:	97ffed35 	bl	27a0 <strlen@plt>
    72d0:	aa1303e1 	mov	x1, x19
    72d4:	aa0003e2 	mov	x2, x0
    72d8:	aa1403e0 	mov	x0, x20
    72dc:	97fff0cd 	bl	3610 <buf_put>
    72e0:	f9413bf5 	ldr	x21, [sp, #624]
    72e4:	f9413ff6 	ldr	x22, [sp, #632]
    72e8:	f94153fb 	ldr	x27, [sp, #672]
    72ec:	f94157fc 	ldr	x28, [sp, #680]
    72f0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    72f4:	f947f400 	ldr	x0, [x0, #4072]
    72f8:	f94127e2 	ldr	x2, [sp, #584]
    72fc:	f9400001 	ldr	x1, [x0]
    7300:	eb010042 	subs	x2, x2, x1
    7304:	d2800001 	mov	x1, #0x0                   	// #0
    7308:	540077c1 	b.ne	8200 <fwp_write+0xfc0>  // b.any
    730c:	910943ff 	add	sp, sp, #0x250
    7310:	a94153f3 	ldp	x19, x20, [sp, #16]
    7314:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7318:	d65f03c0 	ret
    731c:	910123e0 	add	x0, sp, #0x48
    7320:	aa1303e5 	mov	x5, x19
    7324:	d0000024 	adrp	x4, d000 <__modti3+0x320>
    7328:	aa0003f3 	mov	x19, x0
    732c:	91158084 	add	x4, x4, #0x560
    7330:	d2804003 	mov	x3, #0x200                 	// #512
    7334:	17ffffe2 	b	72bc <fwp_write+0x7c>
    7338:	71004cbf 	cmp	w5, #0x13
    733c:	d0000020 	adrp	x0, d000 <__modti3+0x320>
    7340:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7344:	91154000 	add	x0, x0, #0x550
    7348:	91156021 	add	x1, x1, #0x558
    734c:	d2800082 	mov	x2, #0x4                   	// #4
    7350:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7354:	aa1403e0 	mov	x0, x20
    7358:	f90143f7 	str	x23, [sp, #640]
    735c:	d2800016 	mov	x22, #0x0                   	// #0
    7360:	f90147f8 	str	x24, [sp, #648]
    7364:	97fff0ab 	bl	3610 <buf_put>
    7368:	f9400260 	ldr	x0, [x19]
    736c:	d0000037 	adrp	x23, d000 <__modti3+0x320>
    7370:	d2800015 	mov	x21, #0x0                   	// #0
    7374:	911762f7 	add	x23, x23, #0x5d8
    7378:	b40047a0 	cbz	x0, 7c6c <fwp_write+0xa2c>
    737c:	b9400380 	ldr	w0, [x28]
    7380:	52800003 	mov	w3, #0x0                   	// #0
    7384:	f9401f82 	ldr	x2, [x28, #56]
    7388:	71004c1f 	cmp	w0, #0x13
    738c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7390:	aa1403e0 	mov	x0, x20
    7394:	8b010e61 	add	x1, x19, x1, lsl #3
    7398:	f9400421 	ldr	x1, [x1, #8]
    739c:	97ffffa9 	bl	7240 <fwp_write>
    73a0:	b9400380 	ldr	w0, [x28]
    73a4:	7100481f 	cmp	w0, #0x12
    73a8:	54004b40 	b.eq	7d10 <fwp_write+0xad0>  // b.none
    73ac:	f9400260 	ldr	x0, [x19]
    73b0:	910006b5 	add	x21, x21, #0x1
    73b4:	91000ad6 	add	x22, x22, #0x2
    73b8:	eb15001f 	cmp	x0, x21
    73bc:	54004589 	b.ls	7c6c <fwp_write+0xa2c>  // b.plast
    73c0:	aa1703e1 	mov	x1, x23
    73c4:	aa1403e0 	mov	x0, x20
    73c8:	d2800042 	mov	x2, #0x2                   	// #2
    73cc:	97fff091 	bl	3610 <buf_put>
    73d0:	17ffffeb 	b	737c <fwp_write+0x13c>
    73d4:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    73d8:	91164021 	add	x1, x1, #0x590
    73dc:	d28000c2 	mov	x2, #0x6                   	// #6
    73e0:	aa1403e0 	mov	x0, x20
    73e4:	91004273 	add	x19, x19, #0x10
    73e8:	97fff08a 	bl	3610 <buf_put>
    73ec:	aa1303e0 	mov	x0, x19
    73f0:	97ffecec 	bl	27a0 <strlen@plt>
    73f4:	aa1303e1 	mov	x1, x19
    73f8:	aa0003e2 	mov	x2, x0
    73fc:	aa1403e0 	mov	x0, x20
    7400:	97fff084 	bl	3610 <buf_put>
    7404:	528007c3 	mov	w3, #0x3e                  	// #62
    7408:	aa1403e0 	mov	x0, x20
    740c:	91001fe1 	add	x1, sp, #0x7
    7410:	d2800022 	mov	x2, #0x1                   	// #1
    7414:	39001fe3 	strb	w3, [sp, #7]
    7418:	17ffffb1 	b	72dc <fwp_write+0x9c>
    741c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7420:	f947f400 	ldr	x0, [x0, #4072]
    7424:	f94127e2 	ldr	x2, [sp, #584]
    7428:	f9400001 	ldr	x1, [x0]
    742c:	eb010042 	subs	x2, x2, x1
    7430:	d2800001 	mov	x1, #0x0                   	// #0
    7434:	540034e1 	b.ne	7ad0 <fwp_write+0x890>  // b.any
    7438:	f9413bf5 	ldr	x21, [sp, #624]
    743c:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7440:	f9413ff6 	ldr	x22, [sp, #632]
    7444:	aa1403e0 	mov	x0, x20
    7448:	9115c021 	add	x1, x1, #0x570
    744c:	d2800142 	mov	x2, #0xa                   	// #10
    7450:	f94153fb 	ldr	x27, [sp, #672]
    7454:	f94157fc 	ldr	x28, [sp, #680]
    7458:	910943ff 	add	sp, sp, #0x250
    745c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7460:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7464:	17fff06b 	b	3610 <buf_put>
    7468:	f9400456 	ldr	x22, [x2, #8]
    746c:	f90143f7 	str	x23, [sp, #640]
    7470:	f90147f8 	str	x24, [sp, #648]
    7474:	b4005b16 	cbz	x22, 7fd4 <fwp_write+0xd94>
    7478:	aa1603e0 	mov	x0, x22
    747c:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7480:	9117c021 	add	x1, x1, #0x5f0
    7484:	97ffed43 	bl	2990 <strcmp@plt>
    7488:	2a0003f5 	mov	w21, w0
    748c:	34005fe0 	cbz	w0, 8088 <fwp_write+0xe48>
    7490:	aa1603e0 	mov	x0, x22
    7494:	97ffecc3 	bl	27a0 <strlen@plt>
    7498:	aa1603e1 	mov	x1, x22
    749c:	aa0003e2 	mov	x2, x0
    74a0:	aa1403e0 	mov	x0, x20
    74a4:	97fff05b 	bl	3610 <buf_put>
    74a8:	52800403 	mov	w3, #0x20                  	// #32
    74ac:	91001ff5 	add	x21, sp, #0x7
    74b0:	aa1503e1 	mov	x1, x21
    74b4:	aa1403e0 	mov	x0, x20
    74b8:	d2800022 	mov	x2, #0x1                   	// #1
    74bc:	39001fe3 	strb	w3, [sp, #7]
    74c0:	97fff054 	bl	3610 <buf_put>
    74c4:	52800f63 	mov	w3, #0x7b                  	// #123
    74c8:	aa1403e0 	mov	x0, x20
    74cc:	aa1503e1 	mov	x1, x21
    74d0:	d2800022 	mov	x2, #0x1                   	// #1
    74d4:	39001fe3 	strb	w3, [sp, #7]
    74d8:	97fff04e 	bl	3610 <buf_put>
    74dc:	b9401380 	ldr	w0, [x28, #16]
    74e0:	52800018 	mov	w24, #0x0                   	// #0
    74e4:	7100001f 	cmp	w0, #0x0
    74e8:	54003aad 	b.le	7c3c <fwp_write+0x9fc>
    74ec:	f9014bf9 	str	x25, [sp, #656]
    74f0:	d0000039 	adrp	x25, d000 <__modti3+0x320>
    74f4:	91186339 	add	x25, x25, #0x618
    74f8:	f9014ffa 	str	x26, [sp, #664]
    74fc:	d000003a 	adrp	x26, d000 <__modti3+0x320>
    7500:	9117635a 	add	x26, x26, #0x5d8
    7504:	91002276 	add	x22, x19, #0x8
    7508:	d2800013 	mov	x19, #0x0                   	// #0
    750c:	b5003e93 	cbnz	x19, 7cdc <fwp_write+0xa9c>
    7510:	d37df277 	lsl	x23, x19, #3
    7514:	34003cb8 	cbz	w24, 7ca8 <fwp_write+0xa68>
    7518:	f9401382 	ldr	x2, [x28, #32]
    751c:	aa1403e0 	mov	x0, x20
    7520:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7524:	52800003 	mov	w3, #0x0                   	// #0
    7528:	f8776842 	ldr	x2, [x2, x23]
    752c:	91000673 	add	x19, x19, #0x1
    7530:	97ffff44 	bl	7240 <fwp_write>
    7534:	b9401380 	ldr	w0, [x28, #16]
    7538:	6b13001f 	cmp	w0, w19
    753c:	54fffe8c 	b.gt	750c <fwp_write+0x2cc>
    7540:	f9414bf9 	ldr	x25, [sp, #656]
    7544:	f9414ffa 	ldr	x26, [sp, #664]
    7548:	340037b8 	cbz	w24, 7c3c <fwp_write+0x9fc>
    754c:	52800523 	mov	w3, #0x29                  	// #41
    7550:	aa1503e1 	mov	x1, x21
    7554:	aa1403e0 	mov	x0, x20
    7558:	d2800022 	mov	x2, #0x1                   	// #1
    755c:	39001fe3 	strb	w3, [sp, #7]
    7560:	97fff02c 	bl	3610 <buf_put>
    7564:	f9413bf5 	ldr	x21, [sp, #624]
    7568:	f9413ff6 	ldr	x22, [sp, #632]
    756c:	f94143f7 	ldr	x23, [sp, #640]
    7570:	f94147f8 	ldr	x24, [sp, #648]
    7574:	f94153fb 	ldr	x27, [sp, #672]
    7578:	f94157fc 	ldr	x28, [sp, #680]
    757c:	17ffff5d 	b	72f0 <fwp_write+0xb0>
    7580:	b9404855 	ldr	w21, [x2, #72]
    7584:	aa1403e0 	mov	x0, x20
    7588:	93407eb6 	sxtw	x22, w21
    758c:	91000ac1 	add	x1, x22, #0x2
    7590:	97ffefed 	bl	3544 <buf_grow>
    7594:	a9400281 	ldp	x1, x0, [x20]
    7598:	528e8603 	mov	w3, #0x7430                	// #29744
    759c:	78206823 	strh	w3, [x1, x0]
    75a0:	8b000022 	add	x2, x1, x0
    75a4:	710002bf 	cmp	w21, #0x0
    75a8:	540036cd 	b.le	7c80 <fwp_write+0xa40>
    75ac:	110006a3 	add	w3, w21, #0x1
    75b0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    75b4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    75b8:	91000449 	add	x9, x2, #0x1
    75bc:	8b23c043 	add	x3, x2, w3, sxtw
    75c0:	f28aaac6 	movk	x6, #0x5556
    75c4:	f2955568 	movk	x8, #0xaaab
    75c8:	1400000d 	b	75fc <fwp_write+0x3bc>
    75cc:	d2800021 	mov	x1, #0x1                   	// #1
    75d0:	528005a5 	mov	w5, #0x2d                  	// #45
    75d4:	f100001f 	cmp	x0, #0x0
    75d8:	9b467e60 	smulh	x0, x19, x6
    75dc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    75e0:	381ff465 	strb	w5, [x3], #-1
    75e4:	cb040000 	sub	x0, x0, x4
    75e8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    75ec:	cb020000 	sub	x0, x0, x2
    75f0:	8b010013 	add	x19, x0, x1
    75f4:	eb03013f 	cmp	x9, x3
    75f8:	54003440 	b.eq	7c80 <fwp_write+0xa40>  // b.none
    75fc:	9b467e60 	smulh	x0, x19, x6
    7600:	937ffe64 	asr	x4, x19, #63
    7604:	52800605 	mov	w5, #0x30                  	// #48
    7608:	cb040000 	sub	x0, x0, x4
    760c:	8b000400 	add	x0, x0, x0, lsl #1
    7610:	cb000260 	sub	x0, x19, x0
    7614:	91000c01 	add	x1, x0, #0x3
    7618:	9bc87c22 	umulh	x2, x1, x8
    761c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7620:	8b4204e2 	add	x2, x7, x2, lsr #1
    7624:	eb020021 	subs	x1, x1, x2
    7628:	54fffd60 	b.eq	75d4 <fwp_write+0x394>  // b.none
    762c:	f100043f 	cmp	x1, #0x1
    7630:	54fffce1 	b.ne	75cc <fwp_write+0x38c>  // b.any
    7634:	d2800001 	mov	x1, #0x0                   	// #0
    7638:	52800565 	mov	w5, #0x2b                  	// #43
    763c:	17ffffe6 	b	75d4 <fwp_write+0x394>
    7640:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7644:	f947f400 	ldr	x0, [x0, #4072]
    7648:	f94127e2 	ldr	x2, [sp, #584]
    764c:	f9400001 	ldr	x1, [x0]
    7650:	eb010042 	subs	x2, x2, x1
    7654:	d2800001 	mov	x1, #0x0                   	// #0
    7658:	540023c1 	b.ne	7ad0 <fwp_write+0x890>  // b.any
    765c:	f9413bf5 	ldr	x21, [sp, #624]
    7660:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7664:	f9413ff6 	ldr	x22, [sp, #632]
    7668:	aa1403e0 	mov	x0, x20
    766c:	91160021 	add	x1, x1, #0x580
    7670:	d2800102 	mov	x2, #0x8                   	// #8
    7674:	17ffff77 	b	7450 <fwp_write+0x210>
    7678:	aa1403e0 	mov	x0, x20
    767c:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7680:	d28000c2 	mov	x2, #0x6                   	// #6
    7684:	91178021 	add	x1, x1, #0x5e0
    7688:	97ffefe2 	bl	3610 <buf_put>
    768c:	d2800015 	mov	x21, #0x0                   	// #0
    7690:	f9400263 	ldr	x3, [x19]
    7694:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7698:	54002c60 	b.eq	7c24 <fwp_write+0x9e4>  // b.none
    769c:	f9401f82 	ldr	x2, [x28, #56]
    76a0:	f90143f7 	str	x23, [sp, #640]
    76a4:	f90147f8 	str	x24, [sp, #648]
    76a8:	d2800857 	mov	x23, #0x42                  	// #66
    76ac:	f9014bf9 	str	x25, [sp, #656]
    76b0:	d0000036 	adrp	x22, d000 <__modti3+0x320>
    76b4:	f9014ffa 	str	x26, [sp, #664]
    76b8:	911762d6 	add	x22, x22, #0x5d8
    76bc:	d2800038 	mov	x24, #0x1                   	// #1
    76c0:	f2a18017 	movk	x23, #0xc00, lsl #16
    76c4:	d2809099 	mov	x25, #0x484                 	// #1156
    76c8:	b40004a2 	cbz	x2, 775c <fwp_write+0x51c>
    76cc:	b9400040 	ldr	w0, [x2]
    76d0:	7100701f 	cmp	w0, #0x1c
    76d4:	540042c0 	b.eq	7f2c <fwp_write+0xcec>  // b.none
    76d8:	71006c1f 	cmp	w0, #0x1b
    76dc:	54000408 	b.hi	775c <fwp_write+0x51c>  // b.pmore
    76e0:	9ac02301 	lsl	x1, x24, x0
    76e4:	ea17003f 	tst	x1, x23
    76e8:	540036a1 	b.ne	7dbc <fwp_write+0xb7c>  // b.any
    76ec:	ea19003f 	tst	x1, x25
    76f0:	54003521 	b.ne	7d94 <fwp_write+0xb54>  // b.any
    76f4:	d2800424 	mov	x4, #0x21                  	// #33
    76f8:	ea04003f 	tst	x1, x4
    76fc:	54000300 	b.eq	775c <fwp_write+0x51c>  // b.none
    7700:	b7f849c3 	tbnz	x3, #63, 8038 <fwp_write+0xdf8>
    7704:	91002261 	add	x1, x19, #0x8
    7708:	8b150021 	add	x1, x1, x21
    770c:	39400021 	ldrb	w1, [x1]
    7710:	7100001f 	cmp	w0, #0x0
    7714:	93401c23 	sxtb	x3, w1
    7718:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    771c:	d503201f 	nop
    7720:	aa1403e0 	mov	x0, x20
    7724:	52800003 	mov	w3, #0x0                   	// #0
    7728:	97fffec6 	bl	7240 <fwp_write>
    772c:	910006b5 	add	x21, x21, #0x1
    7730:	f9400260 	ldr	x0, [x19]
    7734:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7738:	eb0002bf 	cmp	x21, x0
    773c:	540026c2 	b.cs	7c14 <fwp_write+0x9d4>  // b.hs, b.nlast
    7740:	d2800042 	mov	x2, #0x2                   	// #2
    7744:	aa1603e1 	mov	x1, x22
    7748:	aa1403e0 	mov	x0, x20
    774c:	97ffefb1 	bl	3610 <buf_put>
    7750:	f9401f82 	ldr	x2, [x28, #56]
    7754:	f9400263 	ldr	x3, [x19]
    7758:	b5fffba2 	cbnz	x2, 76cc <fwp_write+0x48c>
    775c:	d37df2a0 	lsl	x0, x21, #3
    7760:	b7f83f03 	tbnz	x3, #63, 7f40 <fwp_write+0xd00>
    7764:	91002261 	add	x1, x19, #0x8
    7768:	8b000020 	add	x0, x1, x0
    776c:	f9400001 	ldr	x1, [x0]
    7770:	17ffffec 	b	7720 <fwp_write+0x4e0>
    7774:	a9400e62 	ldp	x2, x3, [x19]
    7778:	b7f83ca3 	tbnz	x3, #63, 7f0c <fwp_write+0xccc>
    777c:	910123f5 	add	x21, sp, #0x48
    7780:	aa1503e0 	mov	x0, x21
    7784:	97ffedc7 	bl	2ea0 <fwp_fmt_u128>
    7788:	aa1503e0 	mov	x0, x21
    778c:	97ffec05 	bl	27a0 <strlen@plt>
    7790:	aa1503e1 	mov	x1, x21
    7794:	aa0003e2 	mov	x2, x0
    7798:	17fffed0 	b	72d8 <fwp_write+0x98>
    779c:	fd015be8 	str	d8, [sp, #688]
    77a0:	1e270268 	fmov	s8, w19
    77a4:	fd015fe9 	str	d9, [sp, #696]
    77a8:	1e282100 	fcmp	s8, s8
    77ac:	54004d26 	b.vs	8150 <fwp_write+0xf10>
    77b0:	1e20c101 	fabs	s1, s8
    77b4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    77b8:	1e270000 	fmov	s0, w0
    77bc:	1e202020 	fcmp	s1, s0
    77c0:	54002c0d 	b.le	7d40 <fwp_write+0xb00>
    77c4:	1e202118 	fcmpe	s8, #0.0
    77c8:	d0000022 	adrp	x2, d000 <__modti3+0x320>
    77cc:	91056042 	add	x2, x2, #0x158
    77d0:	910123f5 	add	x21, sp, #0x48
    77d4:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    77d8:	9114c021 	add	x1, x1, #0x530
    77dc:	aa1503e0 	mov	x0, x21
    77e0:	9a81c041 	csel	x1, x2, x1, gt
    77e4:	97ffec9b 	bl	2a50 <strcpy@plt>
    77e8:	aa1503e0 	mov	x0, x21
    77ec:	97ffebed 	bl	27a0 <strlen@plt>
    77f0:	aa1503e1 	mov	x1, x21
    77f4:	aa0003e2 	mov	x2, x0
    77f8:	aa1403e0 	mov	x0, x20
    77fc:	97ffef85 	bl	3610 <buf_put>
    7800:	f9413bf5 	ldr	x21, [sp, #624]
    7804:	f9413ff6 	ldr	x22, [sp, #632]
    7808:	f94153fb 	ldr	x27, [sp, #672]
    780c:	f94157fc 	ldr	x28, [sp, #680]
    7810:	fd415be8 	ldr	d8, [sp, #688]
    7814:	fd415fe9 	ldr	d9, [sp, #696]
    7818:	17fffeb6 	b	72f0 <fwp_write+0xb0>
    781c:	f9400276 	ldr	x22, [x19]
    7820:	34002e03 	cbz	w3, 7de0 <fwp_write+0xba0>
    7824:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7828:	f947f400 	ldr	x0, [x0, #4072]
    782c:	f94127e2 	ldr	x2, [sp, #584]
    7830:	f9400001 	ldr	x1, [x0]
    7834:	eb010042 	subs	x2, x2, x1
    7838:	d2800001 	mov	x1, #0x0                   	// #0
    783c:	540014a1 	b.ne	7ad0 <fwp_write+0x890>  // b.any
    7840:	aa1603e2 	mov	x2, x22
    7844:	91002261 	add	x1, x19, #0x8
    7848:	f9413bf5 	ldr	x21, [sp, #624]
    784c:	aa1403e0 	mov	x0, x20
    7850:	f9413ff6 	ldr	x22, [sp, #632]
    7854:	17fffeff 	b	7450 <fwp_write+0x210>
    7858:	fd015be8 	str	d8, [sp, #688]
    785c:	9e670268 	fmov	d8, x19
    7860:	fd015fe9 	str	d9, [sp, #696]
    7864:	1e682100 	fcmp	d8, d8
    7868:	54004746 	b.vs	8150 <fwp_write+0xf10>
    786c:	1e60c101 	fabs	d1, d8
    7870:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7874:	9e670000 	fmov	d0, x0
    7878:	910123f5 	add	x21, sp, #0x48
    787c:	52800033 	mov	w19, #0x1                   	// #1
    7880:	1e602020 	fcmp	d1, d0
    7884:	540001ad 	b.le	78b8 <fwp_write+0x678>
    7888:	1e602118 	fcmpe	d8, #0.0
    788c:	d0000022 	adrp	x2, d000 <__modti3+0x320>
    7890:	91056042 	add	x2, x2, #0x158
    7894:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7898:	9114c021 	add	x1, x1, #0x530
    789c:	aa1503e0 	mov	x0, x21
    78a0:	9a81c041 	csel	x1, x2, x1, gt
    78a4:	97ffec6b 	bl	2a50 <strcpy@plt>
    78a8:	17ffffd0 	b	77e8 <fwp_write+0x5a8>
    78ac:	11000673 	add	w19, w19, #0x1
    78b0:	71004a7f 	cmp	w19, #0x12
    78b4:	54003860 	b.eq	7fc0 <fwp_write+0xd80>  // b.none
    78b8:	1e604100 	fmov	d0, d8
    78bc:	2a1303e1 	mov	w1, w19
    78c0:	aa1503e0 	mov	x0, x21
    78c4:	97fff0d4 	bl	3c14 <fwp_format_g.constprop.0>
    78c8:	aa1503e0 	mov	x0, x21
    78cc:	d2800001 	mov	x1, #0x0                   	// #0
    78d0:	97ffebc8 	bl	27f0 <strtod@plt>
    78d4:	1e602100 	fcmp	d8, d0
    78d8:	54fffea1 	b.ne	78ac <fwp_write+0x66c>  // b.any
    78dc:	aa1503e0 	mov	x0, x21
    78e0:	97ffefc5 	bl	37f4 <fwp_finish_float>
    78e4:	17ffffc1 	b	77e8 <fwp_write+0x5a8>
    78e8:	a9400e62 	ldp	x2, x3, [x19]
    78ec:	910123f3 	add	x19, sp, #0x48
    78f0:	aa1303e0 	mov	x0, x19
    78f4:	97ffed6b 	bl	2ea0 <fwp_fmt_u128>
    78f8:	17fffe74 	b	72c8 <fwp_write+0x88>
    78fc:	f90143f7 	str	x23, [sp, #640]
    7900:	f90147f8 	str	x24, [sp, #648]
    7904:	2a1303f8 	mov	w24, w19
    7908:	f9014bf9 	str	x25, [sp, #656]
    790c:	f9014ffa 	str	x26, [sp, #664]
    7910:	f13ffe7f 	cmp	x19, #0xfff
    7914:	54000049 	b.ls	791c <fwp_write+0x6dc>  // b.plast
    7918:	b9400278 	ldr	w24, [x19]
    791c:	f9400f80 	ldr	x0, [x28, #24]
    7920:	2a1803f5 	mov	w21, w24
    7924:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7928:	d37ef6b9 	lsl	x25, x21, #2
    792c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7930:	aa1603e0 	mov	x0, x22
    7934:	97ffeb9b 	bl	27a0 <strlen@plt>
    7938:	aa1603e1 	mov	x1, x22
    793c:	aa0003e2 	mov	x2, x0
    7940:	aa1403e0 	mov	x0, x20
    7944:	97ffef33 	bl	3610 <buf_put>
    7948:	f9401780 	ldr	x0, [x28, #40]
    794c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7950:	7100001f 	cmp	w0, #0x0
    7954:	5400068d 	b.le	7a24 <fwp_write+0x7e4>
    7958:	91002276 	add	x22, x19, #0x8
    795c:	91001ff5 	add	x21, sp, #0x7
    7960:	d280001b 	mov	x27, #0x0                   	// #0
    7964:	5280041a 	mov	w26, #0x20                  	// #32
    7968:	f9401b80 	ldr	x0, [x28, #48]
    796c:	aa1503e1 	mov	x1, x21
    7970:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7974:	d2800022 	mov	x2, #0x1                   	// #1
    7978:	f8786803 	ldr	x3, [x0, x24]
    797c:	aa1403e0 	mov	x0, x20
    7980:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7984:	39001ffa 	strb	w26, [sp, #7]
    7988:	97ffef22 	bl	3610 <buf_put>
    798c:	f13ffeff 	cmp	x23, #0xfff
    7990:	b9400261 	ldr	w1, [x19]
    7994:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7998:	7100383f 	cmp	w1, #0xe
    799c:	54000160 	b.eq	79c8 <fwp_write+0x788>  // b.none
    79a0:	7100403f 	cmp	w1, #0x10
    79a4:	54001a60 	b.eq	7cf0 <fwp_write+0xab0>  // b.none
    79a8:	7100283f 	cmp	w1, #0xa
    79ac:	54002aa0 	b.eq	7f00 <fwp_write+0xcc0>  // b.none
    79b0:	540014ac 	b.gt	7c44 <fwp_write+0xa04>
    79b4:	71000c3f 	cmp	w1, #0x3
    79b8:	540029ac 	b.gt	7eec <fwp_write+0xcac>
    79bc:	d37ffee0 	lsr	x0, x23, #63
    79c0:	37f814a1 	tbnz	w1, #31, 7c54 <fwp_write+0xa14>
    79c4:	d503201f 	nop
    79c8:	34001460 	cbz	w0, 7c54 <fwp_write+0xa14>
    79cc:	52800503 	mov	w3, #0x28                  	// #40
    79d0:	aa1503e1 	mov	x1, x21
    79d4:	aa1403e0 	mov	x0, x20
    79d8:	d2800022 	mov	x2, #0x1                   	// #1
    79dc:	39001fe3 	strb	w3, [sp, #7]
    79e0:	97ffef0c 	bl	3610 <buf_put>
    79e4:	aa1303e2 	mov	x2, x19
    79e8:	aa1703e1 	mov	x1, x23
    79ec:	aa1403e0 	mov	x0, x20
    79f0:	52800003 	mov	w3, #0x0                   	// #0
    79f4:	97fffe13 	bl	7240 <fwp_write>
    79f8:	52800523 	mov	w3, #0x29                  	// #41
    79fc:	aa1503e1 	mov	x1, x21
    7a00:	aa1403e0 	mov	x0, x20
    7a04:	d2800022 	mov	x2, #0x1                   	// #1
    7a08:	39001fe3 	strb	w3, [sp, #7]
    7a0c:	97ffef01 	bl	3610 <buf_put>
    7a10:	f9401780 	ldr	x0, [x28, #40]
    7a14:	9100077b 	add	x27, x27, #0x1
    7a18:	b8796800 	ldr	w0, [x0, x25]
    7a1c:	6b1b001f 	cmp	w0, w27
    7a20:	54fffa4c 	b.gt	7968 <fwp_write+0x728>
    7a24:	f9413bf5 	ldr	x21, [sp, #624]
    7a28:	f9413ff6 	ldr	x22, [sp, #632]
    7a2c:	f94143f7 	ldr	x23, [sp, #640]
    7a30:	f94147f8 	ldr	x24, [sp, #648]
    7a34:	f9414bf9 	ldr	x25, [sp, #656]
    7a38:	f9414ffa 	ldr	x26, [sp, #664]
    7a3c:	f94153fb 	ldr	x27, [sp, #672]
    7a40:	f94157fc 	ldr	x28, [sp, #680]
    7a44:	17fffe2b 	b	72f0 <fwp_write+0xb0>
    7a48:	52800783 	mov	w3, #0x3c                  	// #60
    7a4c:	91001ff3 	add	x19, sp, #0x7
    7a50:	aa1303e1 	mov	x1, x19
    7a54:	d2800022 	mov	x2, #0x1                   	// #1
    7a58:	aa1403e0 	mov	x0, x20
    7a5c:	39001fe3 	strb	w3, [sp, #7]
    7a60:	97ffeeec 	bl	3610 <buf_put>
    7a64:	f9400795 	ldr	x21, [x28, #8]
    7a68:	aa1503e0 	mov	x0, x21
    7a6c:	97ffeb4d 	bl	27a0 <strlen@plt>
    7a70:	aa1503e1 	mov	x1, x21
    7a74:	aa0003e2 	mov	x2, x0
    7a78:	aa1403e0 	mov	x0, x20
    7a7c:	97ffeee5 	bl	3610 <buf_put>
    7a80:	528007c3 	mov	w3, #0x3e                  	// #62
    7a84:	aa1303e1 	mov	x1, x19
    7a88:	aa1403e0 	mov	x0, x20
    7a8c:	d2800022 	mov	x2, #0x1                   	// #1
    7a90:	39001fe3 	strb	w3, [sp, #7]
    7a94:	17fffe12 	b	72dc <fwp_write+0x9c>
    7a98:	f100067f 	cmp	x19, #0x1
    7a9c:	540025a0 	b.eq	7f50 <fwp_write+0xd10>  // b.none
    7aa0:	b100067f 	cmn	x19, #0x1
    7aa4:	54002bc0 	b.eq	801c <fwp_write+0xddc>  // b.none
    7aa8:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7aac:	9114e021 	add	x1, x1, #0x538
    7ab0:	d2800022 	mov	x2, #0x1                   	// #1
    7ab4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ab8:	f947f400 	ldr	x0, [x0, #4072]
    7abc:	f94127e4 	ldr	x4, [sp, #584]
    7ac0:	f9400003 	ldr	x3, [x0]
    7ac4:	eb030084 	subs	x4, x4, x3
    7ac8:	d2800003 	mov	x3, #0x0                   	// #0
    7acc:	54ffebe0 	b.eq	7848 <fwp_write+0x608>  // b.none
    7ad0:	f90143f7 	str	x23, [sp, #640]
    7ad4:	f90147f8 	str	x24, [sp, #648]
    7ad8:	f9014bf9 	str	x25, [sp, #656]
    7adc:	f9014ffa 	str	x26, [sp, #664]
    7ae0:	fd015be8 	str	d8, [sp, #688]
    7ae4:	fd015fe9 	str	d9, [sp, #696]
    7ae8:	97ffeb8a 	bl	2910 <__stack_chk_fail@plt>
    7aec:	52800b63 	mov	w3, #0x5b                  	// #91
    7af0:	91001ff5 	add	x21, sp, #0x7
    7af4:	aa1503e1 	mov	x1, x21
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	d2800022 	mov	x2, #0x1                   	// #1
    7b00:	d0000036 	adrp	x22, d000 <__modti3+0x320>
    7b04:	911762d6 	add	x22, x22, #0x5d8
    7b08:	39001fe3 	strb	w3, [sp, #7]
    7b0c:	97ffeec1 	bl	3610 <buf_put>
    7b10:	b4000273 	cbz	x19, 7b5c <fwp_write+0x91c>
    7b14:	f9400661 	ldr	x1, [x19, #8]
    7b18:	aa1403e0 	mov	x0, x20
    7b1c:	f9401f82 	ldr	x2, [x28, #56]
    7b20:	52800003 	mov	w3, #0x0                   	// #0
    7b24:	97fffdc7 	bl	7240 <fwp_write>
    7b28:	f9400a73 	ldr	x19, [x19, #16]
    7b2c:	b4000193 	cbz	x19, 7b5c <fwp_write+0x91c>
    7b30:	aa1603e1 	mov	x1, x22
    7b34:	aa1403e0 	mov	x0, x20
    7b38:	d2800042 	mov	x2, #0x2                   	// #2
    7b3c:	97ffeeb5 	bl	3610 <buf_put>
    7b40:	f9400661 	ldr	x1, [x19, #8]
    7b44:	aa1403e0 	mov	x0, x20
    7b48:	f9401f82 	ldr	x2, [x28, #56]
    7b4c:	52800003 	mov	w3, #0x0                   	// #0
    7b50:	97fffdbc 	bl	7240 <fwp_write>
    7b54:	f9400a73 	ldr	x19, [x19, #16]
    7b58:	b5fffed3 	cbnz	x19, 7b30 <fwp_write+0x8f0>
    7b5c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7b60:	aa1503e1 	mov	x1, x21
    7b64:	aa1403e0 	mov	x0, x20
    7b68:	d2800022 	mov	x2, #0x1                   	// #1
    7b6c:	39001fe3 	strb	w3, [sp, #7]
    7b70:	17fffddb 	b	72dc <fwp_write+0x9c>
    7b74:	aa1403e0 	mov	x0, x20
    7b78:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7b7c:	d28000c2 	mov	x2, #0x6                   	// #6
    7b80:	91172021 	add	x1, x1, #0x5c8
    7b84:	97ffeea3 	bl	3610 <buf_put>
    7b88:	f9400260 	ldr	x0, [x19]
    7b8c:	b40004c0 	cbz	x0, 7c24 <fwp_write+0x9e4>
    7b90:	910123f5 	add	x21, sp, #0x48
    7b94:	91002276 	add	x22, x19, #0x8
    7b98:	f90143f7 	str	x23, [sp, #640]
    7b9c:	d2800017 	mov	x23, #0x0                   	// #0
    7ba0:	f90147f8 	str	x24, [sp, #648]
    7ba4:	d0000038 	adrp	x24, d000 <__modti3+0x320>
    7ba8:	91174318 	add	x24, x24, #0x5d0
    7bac:	f9014bf9 	str	x25, [sp, #656]
    7bb0:	d0000039 	adrp	x25, d000 <__modti3+0x320>
    7bb4:	91176339 	add	x25, x25, #0x5d8
    7bb8:	f9014ffa 	str	x26, [sp, #664]
    7bbc:	14000005 	b	7bd0 <fwp_write+0x990>
    7bc0:	aa1903e1 	mov	x1, x25
    7bc4:	aa1403e0 	mov	x0, x20
    7bc8:	d2800042 	mov	x2, #0x2                   	// #2
    7bcc:	97ffee91 	bl	3610 <buf_put>
    7bd0:	38776ac5 	ldrb	w5, [x22, x23]
    7bd4:	d2804003 	mov	x3, #0x200                 	// #512
    7bd8:	aa1803e4 	mov	x4, x24
    7bdc:	aa0303e1 	mov	x1, x3
    7be0:	52800042 	mov	w2, #0x2                   	// #2
    7be4:	aa1503e0 	mov	x0, x21
    7be8:	910006f7 	add	x23, x23, #0x1
    7bec:	97ffeb25 	bl	2880 <__snprintf_chk@plt>
    7bf0:	aa1503e0 	mov	x0, x21
    7bf4:	97ffeaeb 	bl	27a0 <strlen@plt>
    7bf8:	aa1503e1 	mov	x1, x21
    7bfc:	aa0003e2 	mov	x2, x0
    7c00:	aa1403e0 	mov	x0, x20
    7c04:	97ffee83 	bl	3610 <buf_put>
    7c08:	f9400260 	ldr	x0, [x19]
    7c0c:	eb17001f 	cmp	x0, x23
    7c10:	54fffd88 	b.hi	7bc0 <fwp_write+0x980>  // b.pmore
    7c14:	f94143f7 	ldr	x23, [sp, #640]
    7c18:	f94147f8 	ldr	x24, [sp, #648]
    7c1c:	f9414bf9 	ldr	x25, [sp, #656]
    7c20:	f9414ffa 	ldr	x26, [sp, #664]
    7c24:	52800ba3 	mov	w3, #0x5d                  	// #93
    7c28:	aa1403e0 	mov	x0, x20
    7c2c:	91001fe1 	add	x1, sp, #0x7
    7c30:	d2800022 	mov	x2, #0x1                   	// #1
    7c34:	39001fe3 	strb	w3, [sp, #7]
    7c38:	17fffda9 	b	72dc <fwp_write+0x9c>
    7c3c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7c40:	17fffe44 	b	7550 <fwp_write+0x310>
    7c44:	f10002ff 	cmp	x23, #0x0
    7c48:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7c4c:	71002c3f 	cmp	w1, #0xb
    7c50:	54ffebc0 	b.eq	79c8 <fwp_write+0x788>  // b.none
    7c54:	aa1303e2 	mov	x2, x19
    7c58:	aa1703e1 	mov	x1, x23
    7c5c:	aa1403e0 	mov	x0, x20
    7c60:	52800003 	mov	w3, #0x0                   	// #0
    7c64:	97fffd77 	bl	7240 <fwp_write>
    7c68:	17ffff6a 	b	7a10 <fwp_write+0x7d0>
    7c6c:	aa1403e0 	mov	x0, x20
    7c70:	91001fe1 	add	x1, sp, #0x7
    7c74:	52800fa3 	mov	w3, #0x7d                  	// #125
    7c78:	d2800022 	mov	x2, #0x1                   	// #1
    7c7c:	17fffe38 	b	755c <fwp_write+0x31c>
    7c80:	a9400281 	ldp	x1, x0, [x20]
    7c84:	91000800 	add	x0, x0, #0x2
    7c88:	8b160000 	add	x0, x0, x22
    7c8c:	f9000680 	str	x0, [x20, #8]
    7c90:	3820683f 	strb	wzr, [x1, x0]
    7c94:	f9413bf5 	ldr	x21, [sp, #624]
    7c98:	f9413ff6 	ldr	x22, [sp, #632]
    7c9c:	f94153fb 	ldr	x27, [sp, #672]
    7ca0:	f94157fc 	ldr	x28, [sp, #680]
    7ca4:	17fffd93 	b	72f0 <fwp_write+0xb0>
    7ca8:	f9400f80 	ldr	x0, [x28, #24]
    7cac:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7cb0:	aa1b03e0 	mov	x0, x27
    7cb4:	97ffeabb 	bl	27a0 <strlen@plt>
    7cb8:	aa1b03e1 	mov	x1, x27
    7cbc:	aa0003e2 	mov	x2, x0
    7cc0:	aa1403e0 	mov	x0, x20
    7cc4:	97ffee53 	bl	3610 <buf_put>
    7cc8:	aa1903e1 	mov	x1, x25
    7ccc:	aa1403e0 	mov	x0, x20
    7cd0:	d2800062 	mov	x2, #0x3                   	// #3
    7cd4:	97ffee4f 	bl	3610 <buf_put>
    7cd8:	17fffe10 	b	7518 <fwp_write+0x2d8>
    7cdc:	aa1a03e1 	mov	x1, x26
    7ce0:	aa1403e0 	mov	x0, x20
    7ce4:	d2800042 	mov	x2, #0x2                   	// #2
    7ce8:	97ffee4a 	bl	3610 <buf_put>
    7cec:	17fffe09 	b	7510 <fwp_write+0x2d0>
    7cf0:	f9400660 	ldr	x0, [x19, #8]
    7cf4:	b4fffb00 	cbz	x0, 7c54 <fwp_write+0xa14>
    7cf8:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7cfc:	9117c021 	add	x1, x1, #0x5f0
    7d00:	97ffeb24 	bl	2990 <strcmp@plt>
    7d04:	7100001f 	cmp	w0, #0x0
    7d08:	1a9f07e0 	cset	w0, ne	// ne = any
    7d0c:	17ffff2f 	b	79c8 <fwp_write+0x788>
    7d10:	aa1403e0 	mov	x0, x20
    7d14:	d2800042 	mov	x2, #0x2                   	// #2
    7d18:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7d1c:	9117a021 	add	x1, x1, #0x5e8
    7d20:	97ffee3c 	bl	3610 <buf_put>
    7d24:	91004261 	add	x1, x19, #0x10
    7d28:	aa1403e0 	mov	x0, x20
    7d2c:	f9402382 	ldr	x2, [x28, #64]
    7d30:	52800003 	mov	w3, #0x0                   	// #0
    7d34:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7d38:	97fffd42 	bl	7240 <fwp_write>
    7d3c:	17fffd9c 	b	73ac <fwp_write+0x16c>
    7d40:	1e22c109 	fcvt	d9, s8
    7d44:	910123f5 	add	x21, sp, #0x48
    7d48:	52800033 	mov	w19, #0x1                   	// #1
    7d4c:	d503201f 	nop
    7d50:	1e604120 	fmov	d0, d9
    7d54:	2a1303e1 	mov	w1, w19
    7d58:	aa1503e0 	mov	x0, x21
    7d5c:	97ffefae 	bl	3c14 <fwp_format_g.constprop.0>
    7d60:	aa1503e0 	mov	x0, x21
    7d64:	d2800001 	mov	x1, #0x0                   	// #0
    7d68:	97ffeb16 	bl	29c0 <strtof@plt>
    7d6c:	1e202100 	fcmp	s8, s0
    7d70:	54ffdb60 	b.eq	78dc <fwp_write+0x69c>  // b.none
    7d74:	11000673 	add	w19, w19, #0x1
    7d78:	71002a7f 	cmp	w19, #0xa
    7d7c:	54fffea1 	b.ne	7d50 <fwp_write+0xb10>  // b.any
    7d80:	1e604120 	fmov	d0, d9
    7d84:	aa1503e0 	mov	x0, x21
    7d88:	52800121 	mov	w1, #0x9                   	// #9
    7d8c:	97ffefa2 	bl	3c14 <fwp_format_g.constprop.0>
    7d90:	17fffed3 	b	78dc <fwp_write+0x69c>
    7d94:	d37ef6a1 	lsl	x1, x21, #2
    7d98:	b7f81563 	tbnz	x3, #63, 8044 <fwp_write+0xe04>
    7d9c:	91002263 	add	x3, x19, #0x8
    7da0:	8b010061 	add	x1, x3, x1
    7da4:	b9400023 	ldr	w3, [x1]
    7da8:	7100081f 	cmp	w0, #0x2
    7dac:	2a0303e1 	mov	w1, w3
    7db0:	93407c63 	sxtw	x3, w3
    7db4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7db8:	17fffe5a 	b	7720 <fwp_write+0x4e0>
    7dbc:	d37ffaa1 	lsl	x1, x21, #1
    7dc0:	b7f81363 	tbnz	x3, #63, 802c <fwp_write+0xdec>
    7dc4:	91002263 	add	x3, x19, #0x8
    7dc8:	8b010061 	add	x1, x3, x1
    7dcc:	79400021 	ldrh	w1, [x1]
    7dd0:	7100041f 	cmp	w0, #0x1
    7dd4:	93403c23 	sxth	x3, w1
    7dd8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ddc:	17fffe51 	b	7720 <fwp_write+0x4e0>
    7de0:	52800443 	mov	w3, #0x22                  	// #34
    7de4:	91001ff5 	add	x21, sp, #0x7
    7de8:	91002273 	add	x19, x19, #0x8
    7dec:	aa1503e1 	mov	x1, x21
    7df0:	aa1403e0 	mov	x0, x20
    7df4:	d2800022 	mov	x2, #0x1                   	// #1
    7df8:	39001fe3 	strb	w3, [sp, #7]
    7dfc:	f90143f7 	str	x23, [sp, #640]
    7e00:	8b160277 	add	x23, x19, x22
    7e04:	f90147f8 	str	x24, [sp, #648]
    7e08:	97ffee02 	bl	3610 <buf_put>
    7e0c:	b4000696 	cbz	x22, 7edc <fwp_write+0xc9c>
    7e10:	d0000038 	adrp	x24, d000 <__modti3+0x320>
    7e14:	91166318 	add	x24, x24, #0x598
    7e18:	f9014bf9 	str	x25, [sp, #656]
    7e1c:	d0000039 	adrp	x25, d000 <__modti3+0x320>
    7e20:	9116e339 	add	x25, x25, #0x5b8
    7e24:	f9014ffa 	str	x26, [sp, #664]
    7e28:	1400000d 	b	7e5c <fwp_write+0xc1c>
    7e2c:	710024bf 	cmp	w5, #0x9
    7e30:	54000460 	b.eq	7ebc <fwp_write+0xc7c>  // b.none
    7e34:	710028bf 	cmp	w5, #0xa
    7e38:	54000a61 	b.ne	7f84 <fwp_write+0xd44>  // b.any
    7e3c:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7e40:	aa1403e0 	mov	x0, x20
    7e44:	9116a021 	add	x1, x1, #0x5a8
    7e48:	d2800042 	mov	x2, #0x2                   	// #2
    7e4c:	97ffedf1 	bl	3610 <buf_put>
    7e50:	91000673 	add	x19, x19, #0x1
    7e54:	eb17027f 	cmp	x19, x23
    7e58:	540003e0 	b.eq	7ed4 <fwp_write+0xc94>  // b.none
    7e5c:	39400265 	ldrb	w5, [x19]
    7e60:	710034bf 	cmp	w5, #0xd
    7e64:	54000180 	b.eq	7e94 <fwp_write+0xc54>  // b.none
    7e68:	54fffe29 	b.ls	7e2c <fwp_write+0xbec>  // b.plast
    7e6c:	710088bf 	cmp	w5, #0x22
    7e70:	540001c0 	b.eq	7ea8 <fwp_write+0xc68>  // b.none
    7e74:	710170bf 	cmp	w5, #0x5c
    7e78:	54000741 	b.ne	7f60 <fwp_write+0xd20>  // b.any
    7e7c:	aa1403e0 	mov	x0, x20
    7e80:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7e84:	d2800042 	mov	x2, #0x2                   	// #2
    7e88:	91168021 	add	x1, x1, #0x5a0
    7e8c:	97ffede1 	bl	3610 <buf_put>
    7e90:	17fffff0 	b	7e50 <fwp_write+0xc10>
    7e94:	aa1903e1 	mov	x1, x25
    7e98:	aa1403e0 	mov	x0, x20
    7e9c:	d2800042 	mov	x2, #0x2                   	// #2
    7ea0:	97ffeddc 	bl	3610 <buf_put>
    7ea4:	17ffffeb 	b	7e50 <fwp_write+0xc10>
    7ea8:	aa1803e1 	mov	x1, x24
    7eac:	aa1403e0 	mov	x0, x20
    7eb0:	d2800042 	mov	x2, #0x2                   	// #2
    7eb4:	97ffedd7 	bl	3610 <buf_put>
    7eb8:	17ffffe6 	b	7e50 <fwp_write+0xc10>
    7ebc:	aa1403e0 	mov	x0, x20
    7ec0:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7ec4:	d2800042 	mov	x2, #0x2                   	// #2
    7ec8:	9116c021 	add	x1, x1, #0x5b0
    7ecc:	97ffedd1 	bl	3610 <buf_put>
    7ed0:	17ffffe0 	b	7e50 <fwp_write+0xc10>
    7ed4:	f9414bf9 	ldr	x25, [sp, #656]
    7ed8:	f9414ffa 	ldr	x26, [sp, #664]
    7edc:	aa1503e1 	mov	x1, x21
    7ee0:	aa1403e0 	mov	x0, x20
    7ee4:	52800443 	mov	w3, #0x22                  	// #34
    7ee8:	17fffd9c 	b	7558 <fwp_write+0x318>
    7eec:	7100103f 	cmp	w1, #0x4
    7ef0:	54ffeb21 	b.ne	7c54 <fwp_write+0xa14>  // b.any
    7ef4:	f94006e0 	ldr	x0, [x23, #8]
    7ef8:	d37ffc00 	lsr	x0, x0, #63
    7efc:	17fffeb3 	b	79c8 <fwp_write+0x788>
    7f00:	710002ff 	cmp	w23, #0x0
    7f04:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7f08:	17fffeb0 	b	79c8 <fwp_write+0x788>
    7f0c:	528005a1 	mov	w1, #0x2d                  	// #45
    7f10:	eb0203e2 	negs	x2, x2
    7f14:	da0303e3 	ngc	x3, x3
    7f18:	910127e0 	add	x0, sp, #0x49
    7f1c:	910123f5 	add	x21, sp, #0x48
    7f20:	390123e1 	strb	w1, [sp, #72]
    7f24:	97ffebdf 	bl	2ea0 <fwp_fmt_u128>
    7f28:	17fffe18 	b	7788 <fwp_write+0x548>
    7f2c:	d37ceea1 	lsl	x1, x21, #4
    7f30:	b7f810a3 	tbnz	x3, #63, 8144 <fwp_write+0xf04>
    7f34:	91002260 	add	x0, x19, #0x8
    7f38:	8b010001 	add	x1, x0, x1
    7f3c:	17fffdf9 	b	7720 <fwp_write+0x4e0>
    7f40:	f9400a61 	ldr	x1, [x19, #16]
    7f44:	8b010000 	add	x0, x0, x1
    7f48:	f9400001 	ldr	x1, [x0]
    7f4c:	17fffdf5 	b	7720 <fwp_write+0x4e0>
    7f50:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    7f54:	d2800042 	mov	x2, #0x2                   	// #2
    7f58:	91150021 	add	x1, x1, #0x540
    7f5c:	17fffed6 	b	7ab4 <fwp_write+0x874>
    7f60:	7101fcbf 	cmp	w5, #0x7f
    7f64:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7f68:	540000e9 	b.ls	7f84 <fwp_write+0xd44>  // b.plast
    7f6c:	aa1503e1 	mov	x1, x21
    7f70:	aa1403e0 	mov	x0, x20
    7f74:	d2800022 	mov	x2, #0x1                   	// #1
    7f78:	39001fe5 	strb	w5, [sp, #7]
    7f7c:	97ffeda5 	bl	3610 <buf_put>
    7f80:	17ffffb4 	b	7e50 <fwp_write+0xc10>
    7f84:	d2800203 	mov	x3, #0x10                  	// #16
    7f88:	d0000024 	adrp	x4, d000 <__modti3+0x320>
    7f8c:	aa0303e1 	mov	x1, x3
    7f90:	91170084 	add	x4, x4, #0x5c0
    7f94:	910123f6 	add	x22, sp, #0x48
    7f98:	52800042 	mov	w2, #0x2                   	// #2
    7f9c:	aa1603e0 	mov	x0, x22
    7fa0:	97ffea38 	bl	2880 <__snprintf_chk@plt>
    7fa4:	aa1603e0 	mov	x0, x22
    7fa8:	97ffe9fe 	bl	27a0 <strlen@plt>
    7fac:	aa1603e1 	mov	x1, x22
    7fb0:	aa0003e2 	mov	x2, x0
    7fb4:	aa1403e0 	mov	x0, x20
    7fb8:	97ffed96 	bl	3610 <buf_put>
    7fbc:	17ffffa5 	b	7e50 <fwp_write+0xc10>
    7fc0:	1e604100 	fmov	d0, d8
    7fc4:	aa1503e0 	mov	x0, x21
    7fc8:	52800221 	mov	w1, #0x11                  	// #17
    7fcc:	97ffef12 	bl	3c14 <fwp_format_g.constprop.0>
    7fd0:	17fffe43 	b	78dc <fwp_write+0x69c>
    7fd4:	b9401040 	ldr	w0, [x2, #16]
    7fd8:	350003c0 	cbnz	w0, 8050 <fwp_write+0xe10>
    7fdc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7fe0:	f947f400 	ldr	x0, [x0, #4072]
    7fe4:	f94127e2 	ldr	x2, [sp, #584]
    7fe8:	f9400001 	ldr	x1, [x0]
    7fec:	eb010042 	subs	x2, x2, x1
    7ff0:	d2800001 	mov	x1, #0x0                   	// #0
    7ff4:	54ffd721 	b.ne	7ad8 <fwp_write+0x898>  // b.any
    7ff8:	f9413bf5 	ldr	x21, [sp, #624]
    7ffc:	d0000021 	adrp	x1, d000 <__modti3+0x320>
    8000:	f9413ff6 	ldr	x22, [sp, #632]
    8004:	aa1403e0 	mov	x0, x20
    8008:	f94143f7 	ldr	x23, [sp, #640]
    800c:	91184021 	add	x1, x1, #0x610
    8010:	f94147f8 	ldr	x24, [sp, #648]
    8014:	d2800042 	mov	x2, #0x2                   	// #2
    8018:	17fffd0e 	b	7450 <fwp_write+0x210>
    801c:	b0000021 	adrp	x1, d000 <__modti3+0x320>
    8020:	d2800042 	mov	x2, #0x2                   	// #2
    8024:	91152021 	add	x1, x1, #0x548
    8028:	17fffea3 	b	7ab4 <fwp_write+0x874>
    802c:	f9400a63 	ldr	x3, [x19, #16]
    8030:	8b030021 	add	x1, x1, x3
    8034:	17ffff66 	b	7dcc <fwp_write+0xb8c>
    8038:	f9400a61 	ldr	x1, [x19, #16]
    803c:	8b0102a1 	add	x1, x21, x1
    8040:	17fffdb3 	b	770c <fwp_write+0x4cc>
    8044:	f9400a63 	ldr	x3, [x19, #16]
    8048:	8b030021 	add	x1, x1, x3
    804c:	17ffff56 	b	7da4 <fwp_write+0xb64>
    8050:	b9404840 	ldr	w0, [x2, #72]
    8054:	91001ff5 	add	x21, sp, #0x7
    8058:	34ffa360 	cbz	w0, 74c4 <fwp_write+0x284>
    805c:	52800503 	mov	w3, #0x28                  	// #40
    8060:	aa1403e0 	mov	x0, x20
    8064:	aa1503e1 	mov	x1, x21
    8068:	d2800022 	mov	x2, #0x1                   	// #1
    806c:	39001fe3 	strb	w3, [sp, #7]
    8070:	97ffed68 	bl	3610 <buf_put>
    8074:	b9401380 	ldr	w0, [x28, #16]
    8078:	52800038 	mov	w24, #0x1                   	// #1
    807c:	7100001f 	cmp	w0, #0x0
    8080:	54ffa36c 	b.gt	74ec <fwp_write+0x2ac>
    8084:	17fffd32 	b	754c <fwp_write+0x30c>
    8088:	f9014bf9 	str	x25, [sp, #656]
    808c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xed60>
    8090:	f9014ffa 	str	x26, [sp, #664]
    8094:	f9400676 	ldr	x22, [x19, #8]
    8098:	910aa333 	add	x19, x25, #0x2a8
    809c:	91002273 	add	x19, x19, #0x8
    80a0:	937ffed8 	asr	x24, x22, #63
    80a4:	aa1802c0 	orr	x0, x22, x24
    80a8:	b5000320 	cbnz	x0, 810c <fwp_write+0xecc>
    80ac:	110006b5 	add	w21, w21, #0x1
    80b0:	710016bf 	cmp	w21, #0x5
    80b4:	54ffffc1 	b.ne	80ac <fwp_write+0xe6c>  // b.any
    80b8:	b7f80578 	tbnz	x24, #63, 8164 <fwp_write+0xf24>
    80bc:	910023f3 	add	x19, sp, #0x8
    80c0:	aa1603e2 	mov	x2, x22
    80c4:	aa1303e0 	mov	x0, x19
    80c8:	d2800003 	mov	x3, #0x0                   	// #0
    80cc:	97ffeb75 	bl	2ea0 <fwp_fmt_u128>
    80d0:	910123f5 	add	x21, sp, #0x48
    80d4:	b0000023 	adrp	x3, d000 <__modti3+0x320>
    80d8:	aa1303e4 	mov	x4, x19
    80dc:	aa1503e0 	mov	x0, x21
    80e0:	91182063 	add	x3, x3, #0x608
    80e4:	d2804002 	mov	x2, #0x200                 	// #512
    80e8:	52800041 	mov	w1, #0x2                   	// #2
    80ec:	97ffe9b1 	bl	27b0 <__sprintf_chk@plt>
    80f0:	aa1503e0 	mov	x0, x21
    80f4:	97ffe9ab 	bl	27a0 <strlen@plt>
    80f8:	aa1503e1 	mov	x1, x21
    80fc:	aa0003e2 	mov	x2, x0
    8100:	aa1403e0 	mov	x0, x20
    8104:	97ffed43 	bl	3610 <buf_put>
    8108:	17fffe47 	b	7a24 <fwp_write+0x7e4>
    810c:	f9400277 	ldr	x23, [x19]
    8110:	aa1603e0 	mov	x0, x22
    8114:	aa1803e1 	mov	x1, x24
    8118:	aa1703e2 	mov	x2, x23
    811c:	937ffefa 	asr	x26, x23, #63
    8120:	aa1a03e3 	mov	x3, x26
    8124:	940012ef 	bl	cce0 <__modti3>
    8128:	aa010000 	orr	x0, x0, x1
    812c:	b40002c0 	cbz	x0, 8184 <fwp_write+0xf44>
    8130:	110006b5 	add	w21, w21, #0x1
    8134:	91004273 	add	x19, x19, #0x10
    8138:	710016bf 	cmp	w21, #0x5
    813c:	54fffe81 	b.ne	810c <fwp_write+0xecc>  // b.any
    8140:	17ffffde 	b	80b8 <fwp_write+0xe78>
    8144:	f9400a60 	ldr	x0, [x19, #16]
    8148:	8b000021 	add	x1, x1, x0
    814c:	17fffd75 	b	7720 <fwp_write+0x4e0>
    8150:	528c29c0 	mov	w0, #0x614e                	// #24910
    8154:	910123f5 	add	x21, sp, #0x48
    8158:	72a009c0 	movk	w0, #0x4e, lsl #16
    815c:	b9004be0 	str	w0, [sp, #72]
    8160:	17fffda2 	b	77e8 <fwp_write+0x5a8>
    8164:	528005a1 	mov	w1, #0x2d                  	// #45
    8168:	eb1603e2 	negs	x2, x22
    816c:	da1803e3 	ngc	x3, x24
    8170:	910027e0 	add	x0, sp, #0x9
    8174:	910023f3 	add	x19, sp, #0x8
    8178:	390023e1 	strb	w1, [sp, #8]
    817c:	97ffeb49 	bl	2ea0 <fwp_fmt_u128>
    8180:	17ffffd4 	b	80d0 <fwp_write+0xe90>
    8184:	aa1703e2 	mov	x2, x23
    8188:	aa1a03e3 	mov	x3, x26
    818c:	aa1603e0 	mov	x0, x22
    8190:	aa1803e1 	mov	x1, x24
    8194:	940011f3 	bl	c960 <__divti3>
    8198:	aa0003e2 	mov	x2, x0
    819c:	aa0103e3 	mov	x3, x1
    81a0:	b7f80201 	tbnz	x1, #63, 81e0 <fwp_write+0xfa0>
    81a4:	910023f3 	add	x19, sp, #0x8
    81a8:	aa1303e0 	mov	x0, x19
    81ac:	97ffeb3d 	bl	2ea0 <fwp_fmt_u128>
    81b0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    81b4:	910aa339 	add	x25, x25, #0x2a8
    81b8:	910123f5 	add	x21, sp, #0x48
    81bc:	aa1303e4 	mov	x4, x19
    81c0:	aa1503e0 	mov	x0, x21
    81c4:	b0000023 	adrp	x3, d000 <__modti3+0x320>
    81c8:	f8616b25 	ldr	x5, [x25, x1]
    81cc:	91180063 	add	x3, x3, #0x600
    81d0:	d2804002 	mov	x2, #0x200                 	// #512
    81d4:	52800041 	mov	w1, #0x2                   	// #2
    81d8:	97ffe976 	bl	27b0 <__sprintf_chk@plt>
    81dc:	17ffffc5 	b	80f0 <fwp_write+0xeb0>
    81e0:	528005a4 	mov	w4, #0x2d                  	// #45
    81e4:	eb0003e2 	negs	x2, x0
    81e8:	da0103e3 	ngc	x3, x1
    81ec:	910027e0 	add	x0, sp, #0x9
    81f0:	910023f3 	add	x19, sp, #0x8
    81f4:	390023e4 	strb	w4, [sp, #8]
    81f8:	97ffeb2a 	bl	2ea0 <fwp_fmt_u128>
    81fc:	17ffffed 	b	81b0 <fwp_write+0xf70>
    8200:	f9013bf5 	str	x21, [sp, #624]
    8204:	f9013ff6 	str	x22, [sp, #632]
    8208:	f90143f7 	str	x23, [sp, #640]
    820c:	f90147f8 	str	x24, [sp, #648]
    8210:	f9014bf9 	str	x25, [sp, #656]
    8214:	f9014ffa 	str	x26, [sp, #664]
    8218:	f90153fb 	str	x27, [sp, #672]
    821c:	f90157fc 	str	x28, [sp, #680]
    8220:	fd015be8 	str	d8, [sp, #688]
    8224:	fd015fe9 	str	d9, [sp, #696]
    8228:	97ffe9ba 	bl	2910 <__stack_chk_fail@plt>
    822c:	d503201f 	nop

0000000000008230 <fwp_hof0.constprop.0>:
    8230:	d10543ff 	sub	sp, sp, #0x150
    8234:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    8238:	f947f442 	ldr	x2, [x2, #4072]
    823c:	a90e7bfd 	stp	x29, x30, [sp, #224]
    8240:	910383fd 	add	x29, sp, #0xe0
    8244:	f90023e0 	str	x0, [sp, #64]
    8248:	f9400040 	ldr	x0, [x2]
    824c:	f9006fe0 	str	x0, [sp, #216]
    8250:	d2800000 	mov	x0, #0x0                   	// #0
    8254:	f90027e1 	str	x1, [sp, #72]
    8258:	b400a641 	cbz	x1, 9720 <fwp_hof0.constprop.0+0x14f0>
    825c:	900000c0 	adrp	x0, 20000 <__data_start>
    8260:	91004000 	add	x0, x0, #0x10
    8264:	9100e000 	add	x0, x0, #0x38
    8268:	f90017e0 	str	x0, [sp, #40]
    826c:	910163e0 	add	x0, sp, #0x58
    8270:	f9000fe0 	str	x0, [sp, #24]
    8274:	910183e0 	add	x0, sp, #0x60
    8278:	f90013e0 	str	x0, [sp, #32]
    827c:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8280:	fd00a3e8 	str	d8, [sp, #320]
    8284:	a90f53f3 	stp	x19, x20, [sp, #240]
    8288:	b0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    828c:	fd474808 	ldr	d8, [x0, #3728]
    8290:	a9105bf5 	stp	x21, x22, [sp, #256]
    8294:	900000d5 	adrp	x21, 20000 <__data_start>
    8298:	a91163f7 	stp	x23, x24, [sp, #272]
    829c:	a9126bf9 	stp	x25, x26, [sp, #288]
    82a0:	a91373fb 	stp	x27, x28, [sp, #304]
    82a4:	91174282 	add	x2, x20, #0x5d0
    82a8:	f94023e0 	ldr	x0, [sp, #64]
    82ac:	f949ec43 	ldr	x3, [x2, #5080]
    82b0:	f949d841 	ldr	x1, [x2, #5040]
    82b4:	d370bc63 	lsl	x3, x3, #16
    82b8:	cb010004 	sub	x4, x0, x1
    82bc:	eb03009f 	cmp	x4, x3
    82c0:	540003e2 	b.cs	833c <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    82c4:	d350fc80 	lsr	x0, x4, #16
    82c8:	f949fc46 	ldr	x6, [x2, #5112]
    82cc:	8b000800 	add	x0, x0, x0, lsl #2
    82d0:	d37df002 	lsl	x2, x0, #3
    82d4:	8b0200c5 	add	x5, x6, x2
    82d8:	f94010a0 	ldr	x0, [x5, #32]
    82dc:	b4000300 	cbz	x0, 833c <fwp_hof0.constprop.0+0x10c>
    82e0:	386268c2 	ldrb	w2, [x6, x2]
    82e4:	7100085f 	cmp	w2, #0x2
    82e8:	5400bbc0 	b.eq	9a60 <fwp_hof0.constprop.0+0x1830>  // b.none
    82ec:	7100045f 	cmp	w2, #0x1
    82f0:	54000261 	b.ne	833c <fwp_hof0.constprop.0+0x10c>  // b.any
    82f4:	92403c82 	and	x2, x4, #0xffff
    82f8:	294310a6 	ldp	w6, w4, [x5, #24]
    82fc:	9b067c42 	mul	x2, x2, x6
    8300:	d360fc42 	lsr	x2, x2, #32
    8304:	eb04005f 	cmp	x2, x4
    8308:	540001a2 	b.cs	833c <fwp_hof0.constprop.0+0x10c>  // b.hs, b.nlast
    830c:	8b020000 	add	x0, x0, x2
    8310:	39400002 	ldrb	w2, [x0]
    8314:	34000142 	cbz	w2, 833c <fwp_hof0.constprop.0+0x10c>
    8318:	7103f45f 	cmp	w2, #0xfd
    831c:	5400cc68 	b.hi	9ca8 <fwp_hof0.constprop.0+0x1a78>  // b.pmore
    8320:	91174281 	add	x1, x20, #0x5d0
    8324:	11000442 	add	w2, w2, #0x1
    8328:	39000002 	strb	w2, [x0]
    832c:	aa0103e0 	mov	x0, x1
    8330:	f949d821 	ldr	x1, [x1, #5040]
    8334:	f949ec03 	ldr	x3, [x0, #5080]
    8338:	d370bc63 	lsl	x3, x3, #16
    833c:	f94023f6 	ldr	x22, [sp, #64]
    8340:	d28018c0 	mov	x0, #0xc6                  	// #198
    8344:	f90007e0 	str	x0, [sp, #8]
    8348:	f94017e0 	ldr	x0, [sp, #40]
    834c:	9101c2a2 	add	x2, x21, #0x70
    8350:	12800004 	mov	w4, #0xffffffff            	// #-1
    8354:	b9005be4 	str	w4, [sp, #88]
    8358:	cb010001 	sub	x1, x0, x1
    835c:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x20>
    8360:	91084000 	add	x0, x0, #0x210
    8364:	f90037e0 	str	x0, [sp, #104]
    8368:	f9418840 	ldr	x0, [x2, #784]
    836c:	f90033e0 	str	x0, [sp, #96]
    8370:	f9400fe0 	ldr	x0, [sp, #24]
    8374:	f9003be0 	str	x0, [sp, #112]
    8378:	f94013e0 	ldr	x0, [sp, #32]
    837c:	f9018840 	str	x0, [x2, #784]
    8380:	eb03003f 	cmp	x1, x3
    8384:	540007a2 	b.cs	8478 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8388:	91174282 	add	x2, x20, #0x5d0
    838c:	d350fc20 	lsr	x0, x1, #16
    8390:	8b000800 	add	x0, x0, x0, lsl #2
    8394:	f949fc44 	ldr	x4, [x2, #5112]
    8398:	d37df003 	lsl	x3, x0, #3
    839c:	8b030082 	add	x2, x4, x3
    83a0:	f9401053 	ldr	x19, [x2, #32]
    83a4:	b40006b3 	cbz	x19, 8478 <fwp_hof0.constprop.0+0x248>
    83a8:	38636880 	ldrb	w0, [x4, x3]
    83ac:	7100081f 	cmp	w0, #0x2
    83b0:	5400a880 	b.eq	98c0 <fwp_hof0.constprop.0+0x1690>  // b.none
    83b4:	7100041f 	cmp	w0, #0x1
    83b8:	54000601 	b.ne	8478 <fwp_hof0.constprop.0+0x248>  // b.any
    83bc:	29430c44 	ldp	w4, w3, [x2, #24]
    83c0:	92403c20 	and	x0, x1, #0xffff
    83c4:	9b047c00 	mul	x0, x0, x4
    83c8:	d360fc00 	lsr	x0, x0, #32
    83cc:	eb03001f 	cmp	x0, x3
    83d0:	540002a2 	b.cs	8424 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    83d4:	8b000260 	add	x0, x19, x0
    83d8:	39400003 	ldrb	w3, [x0]
    83dc:	34000243 	cbz	w3, 8424 <fwp_hof0.constprop.0+0x1f4>
    83e0:	7103f47f 	cmp	w3, #0xfd
    83e4:	5400c228 	b.hi	9c28 <fwp_hof0.constprop.0+0x19f8>  // b.pmore
    83e8:	11000463 	add	w3, w3, #0x1
    83ec:	39000003 	strb	w3, [x0]
    83f0:	91174280 	add	x0, x20, #0x5d0
    83f4:	f94017e3 	ldr	x3, [sp, #40]
    83f8:	f949d801 	ldr	x1, [x0, #5040]
    83fc:	f949ec02 	ldr	x2, [x0, #5080]
    8400:	cb010061 	sub	x1, x3, x1
    8404:	eb02403f 	cmp	x1, x2, lsl #16
    8408:	54000382 	b.cs	8478 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    840c:	f949fc00 	ldr	x0, [x0, #5112]
    8410:	d350fc22 	lsr	x2, x1, #16
    8414:	8b020842 	add	x2, x2, x2, lsl #2
    8418:	8b020c02 	add	x2, x0, x2, lsl #3
    841c:	f9401053 	ldr	x19, [x2, #32]
    8420:	b40002d3 	cbz	x19, 8478 <fwp_hof0.constprop.0+0x248>
    8424:	39400040 	ldrb	w0, [x2]
    8428:	7100081f 	cmp	w0, #0x2
    842c:	5400a520 	b.eq	98d0 <fwp_hof0.constprop.0+0x16a0>  // b.none
    8430:	7100041f 	cmp	w0, #0x1
    8434:	54000221 	b.ne	8478 <fwp_hof0.constprop.0+0x248>  // b.any
    8438:	29430043 	ldp	w3, w0, [x2, #24]
    843c:	92403c21 	and	x1, x1, #0xffff
    8440:	9b037c21 	mul	x1, x1, x3
    8444:	d360fc21 	lsr	x1, x1, #32
    8448:	eb00003f 	cmp	x1, x0
    844c:	54000162 	b.cs	8478 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8450:	8b010273 	add	x19, x19, x1
    8454:	39400261 	ldrb	w1, [x19]
    8458:	34000101 	cbz	w1, 8478 <fwp_hof0.constprop.0+0x248>
    845c:	7100043f 	cmp	w1, #0x1
    8460:	54007820 	b.eq	9364 <fwp_hof0.constprop.0+0x1134>  // b.none
    8464:	7103fc3f 	cmp	w1, #0xff
    8468:	5400bb40 	b.eq	9bd0 <fwp_hof0.constprop.0+0x19a0>  // b.none
    846c:	51000421 	sub	w1, w1, #0x1
    8470:	39000261 	strb	w1, [x19]
    8474:	d503201f 	nop
    8478:	b4007876 	cbz	x22, 9384 <fwp_hof0.constprop.0+0x1154>
    847c:	aa1603e0 	mov	x0, x22
    8480:	d2800013 	mov	x19, #0x0                   	// #0
    8484:	d503201f 	nop
    8488:	f9400800 	ldr	x0, [x0, #16]
    848c:	91000673 	add	x19, x19, #0x1
    8490:	b5ffffc0 	cbnz	x0, 8488 <fwp_hof0.constprop.0+0x258>
    8494:	52800000 	mov	w0, #0x0                   	// #0
    8498:	97ffec76 	bl	3670 <descent_phase_step>
    849c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    84a0:	eb00027f 	cmp	x19, x0
    84a4:	5400c368 	b.hi	9d10 <fwp_hof0.constprop.0+0x1ae0>  // b.pmore
    84a8:	9101c2b7 	add	x23, x21, #0x70
    84ac:	b94346e0 	ldr	w0, [x23, #836]
    84b0:	34007780 	cbz	w0, 93a0 <fwp_hof0.constprop.0+0x1170>
    84b4:	9101c2a0 	add	x0, x21, #0x70
    84b8:	f9404817 	ldr	x23, [x0, #144]
    84bc:	f9407418 	ldr	x24, [x0, #232]
    84c0:	eb17031f 	cmp	x24, x23
    84c4:	5400786a 	b.ge	93d0 <fwp_hof0.constprop.0+0x11a0>  // b.tcont
    84c8:	f9403aa1 	ldr	x1, [x21, #112]
    84cc:	8b180700 	add	x0, x24, x24, lsl #1
    84d0:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    84d4:	8b000b00 	add	x0, x24, x0, lsl #2
    84d8:	8b000c20 	add	x0, x1, x0, lsl #3
    84dc:	d503201f 	nop
    84e0:	b9400401 	ldr	w1, [x0, #4]
    84e4:	35000081 	cbnz	w1, 84f4 <fwp_hof0.constprop.0+0x2c4>
    84e8:	b9400001 	ldr	w1, [x0]
    84ec:	6b02003f 	cmp	w1, w2
    84f0:	54007709 	b.ls	93d0 <fwp_hof0.constprop.0+0x11a0>  // b.plast
    84f4:	91000718 	add	x24, x24, #0x1
    84f8:	9101a000 	add	x0, x0, #0x68
    84fc:	eb17031f 	cmp	x24, x23
    8500:	54ffff01 	b.ne	84e0 <fwp_hof0.constprop.0+0x2b0>  // b.any
    8504:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8508:	eb0002ff 	cmp	x23, x0
    850c:	5400bfcc 	b.gt	9d04 <fwp_hof0.constprop.0+0x1ad4>
    8510:	9101c2a0 	add	x0, x21, #0x70
    8514:	f9403abb 	ldr	x27, [x21, #112]
    8518:	f9407000 	ldr	x0, [x0, #224]
    851c:	eb17001f 	cmp	x0, x23
    8520:	54000201 	b.ne	8560 <fwp_hof0.constprop.0+0x330>  // b.any
    8524:	b400a6b7 	cbz	x23, 99f8 <fwp_hof0.constprop.0+0x17c8>
    8528:	d37ffafc 	lsl	x28, x23, #1
    852c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8530:	eb00039f 	cmp	x28, x0
    8534:	9a80d39c 	csel	x28, x28, x0, le
    8538:	8b1c0781 	add	x1, x28, x28, lsl #1
    853c:	8b010b81 	add	x1, x28, x1, lsl #2
    8540:	d37df021 	lsl	x1, x1, #3
    8544:	aa1b03e0 	mov	x0, x27
    8548:	97ffe8ee 	bl	2900 <realloc@plt>
    854c:	aa0003fb 	mov	x27, x0
    8550:	b4003980 	cbz	x0, 8c80 <fwp_hof0.constprop.0+0xa50>
    8554:	9101c2a0 	add	x0, x21, #0x70
    8558:	f9003abb 	str	x27, [x21, #112]
    855c:	f900701c 	str	x28, [x0, #224]
    8560:	8b1706e1 	add	x1, x23, x23, lsl #1
    8564:	910006e2 	add	x2, x23, #0x1
    8568:	4f000400 	movi	v0.4s, #0x0
    856c:	9101c2a0 	add	x0, x21, #0x70
    8570:	8b010ae1 	add	x1, x23, x1, lsl #2
    8574:	8b180717 	add	x23, x24, x24, lsl #1
    8578:	8b170b17 	add	x23, x24, x23, lsl #2
    857c:	8b010f61 	add	x1, x27, x1, lsl #3
    8580:	f9004802 	str	x2, [x0, #144]
    8584:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8588:	8b170f77 	add	x23, x27, x23, lsl #3
    858c:	910dc000 	add	x0, x0, #0x370
    8590:	ad000020 	stp	q0, q0, [x1]
    8594:	ad010020 	stp	q0, q0, [x1, #32]
    8598:	ad020020 	stp	q0, q0, [x1, #64]
    859c:	f900303f 	str	xzr, [x1, #96]
    85a0:	f90032ff 	str	xzr, [x23, #96]
    85a4:	97ffe93f 	bl	2aa0 <getenv@plt>
    85a8:	b40072a0 	cbz	x0, 93fc <fwp_hof0.constprop.0+0x11cc>
    85ac:	39400001 	ldrb	w1, [x0]
    85b0:	7100c03f 	cmp	w1, #0x30
    85b4:	54007241 	b.ne	93fc <fwp_hof0.constprop.0+0x11cc>  // b.any
    85b8:	39400400 	ldrb	w0, [x0, #1]
    85bc:	35007200 	cbnz	w0, 93fc <fwp_hof0.constprop.0+0x11cc>
    85c0:	9101c2a0 	add	x0, x21, #0x70
    85c4:	2f000400 	mvni	v0.2s, #0x0
    85c8:	b94002e4 	ldr	w4, [x23]
    85cc:	52800022 	mov	w2, #0x1                   	// #1
    85d0:	91000705 	add	x5, x24, #0x1
    85d4:	a900cef3 	stp	x19, x19, [x23, #8]
    85d8:	0b020084 	add	w4, w4, w2
    85dc:	f9418801 	ldr	x1, [x0, #784]
    85e0:	29000ae4 	stp	w4, w2, [x23]
    85e4:	f9002aff 	str	xzr, [x23, #80]
    85e8:	f9007405 	str	x5, [x0, #232]
    85ec:	fd002ee0 	str	d0, [x23, #88]
    85f0:	b400b961 	cbz	x1, 9d1c <fwp_hof0.constprop.0+0x1aec>
    85f4:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x20>
    85f8:	91084003 	add	x3, x0, #0x210
    85fc:	14000003 	b	8608 <fwp_hof0.constprop.0+0x3d8>
    8600:	f9400021 	ldr	x1, [x1]
    8604:	b400b8c1 	cbz	x1, 9d1c <fwp_hof0.constprop.0+0x1aec>
    8608:	f9400422 	ldr	x2, [x1, #8]
    860c:	eb03005f 	cmp	x2, x3
    8610:	54ffff81 	b.ne	8600 <fwp_hof0.constprop.0+0x3d0>  // b.any
    8614:	f9400820 	ldr	x0, [x1, #16]
    8618:	2a1803e2 	mov	w2, w24
    861c:	b9400001 	ldr	w1, [x0]
    8620:	f9002ae0 	str	x0, [x23, #80]
    8624:	b9005ee1 	str	w1, [x23, #92]
    8628:	37f80081 	tbnz	w1, #31, 8638 <fwp_hof0.constprop.0+0x408>
    862c:	52800d03 	mov	w3, #0x68                  	// #104
    8630:	9b236c21 	smaddl	x1, w1, w3, x27
    8634:	b9005838 	str	w24, [x1, #88]
    8638:	b9000002 	str	w2, [x0]
    863c:	d3707c93 	ubfiz	x19, x4, #16, #32
    8640:	52800020 	mov	w0, #0x1                   	// #1
    8644:	aa050273 	orr	x19, x19, x5
    8648:	97ffec0a 	bl	3670 <descent_phase_step>
    864c:	aa1603e0 	mov	x0, x22
    8650:	d2800002 	mov	x2, #0x0                   	// #0
    8654:	b40075f6 	cbz	x22, 9510 <fwp_hof0.constprop.0+0x12e0>
    8658:	f9400800 	ldr	x0, [x0, #16]
    865c:	91000442 	add	x2, x2, #0x1
    8660:	b5ffffc0 	cbnz	x0, 8658 <fwp_hof0.constprop.0+0x428>
    8664:	aa1603e1 	mov	x1, x22
    8668:	f9400821 	ldr	x1, [x1, #16]
    866c:	91000400 	add	x0, x0, #0x1
    8670:	b5ffffc1 	cbnz	x1, 8668 <fwp_hof0.constprop.0+0x438>
    8674:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8678:	eb01001f 	cmp	x0, x1
    867c:	5400b288 	b.hi	9ccc <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    8680:	f100005f 	cmp	x2, #0x0
    8684:	5400746d 	b.le	9510 <fwp_hof0.constprop.0+0x12e0>
    8688:	eb00005f 	cmp	x2, x0
    868c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8690:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8694:	eb0102ff 	cmp	x23, x1
    8698:	5400b1a8 	b.hi	9ccc <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    869c:	d37ffafc 	lsl	x28, x23, #1
    86a0:	52800041 	mov	w1, #0x2                   	// #2
    86a4:	91000780 	add	x0, x28, #0x1
    86a8:	d37df000 	lsl	x0, x0, #3
    86ac:	97fff231 	bl	4f70 <fwp_heap_alloc>
    86b0:	aa0003f8 	mov	x24, x0
    86b4:	91174281 	add	x1, x20, #0x5d0
    86b8:	aa0003fb 	mov	x27, x0
    86bc:	aa0103e0 	mov	x0, x1
    86c0:	f900031c 	str	x28, [x24]
    86c4:	f949d821 	ldr	x1, [x1, #5040]
    86c8:	f949ec00 	ldr	x0, [x0, #5080]
    86cc:	cb010301 	sub	x1, x24, x1
    86d0:	eb00403f 	cmp	x1, x0, lsl #16
    86d4:	540083c2 	b.cs	974c <fwp_hof0.constprop.0+0x151c>  // b.hs, b.nlast
    86d8:	91174282 	add	x2, x20, #0x5d0
    86dc:	d350fc20 	lsr	x0, x1, #16
    86e0:	8b000800 	add	x0, x0, x0, lsl #2
    86e4:	f949fc43 	ldr	x3, [x2, #5112]
    86e8:	d37df002 	lsl	x2, x0, #3
    86ec:	8b020060 	add	x0, x3, x2
    86f0:	f940101c 	ldr	x28, [x0, #32]
    86f4:	b400025c 	cbz	x28, 873c <fwp_hof0.constprop.0+0x50c>
    86f8:	38626862 	ldrb	w2, [x3, x2]
    86fc:	7100085f 	cmp	w2, #0x2
    8700:	54008d00 	b.eq	98a0 <fwp_hof0.constprop.0+0x1670>  // b.none
    8704:	7100045f 	cmp	w2, #0x1
    8708:	540001a1 	b.ne	873c <fwp_hof0.constprop.0+0x50c>  // b.any
    870c:	29430002 	ldp	w2, w0, [x0, #24]
    8710:	92403c21 	and	x1, x1, #0xffff
    8714:	9b027c21 	mul	x1, x1, x2
    8718:	d360fc21 	lsr	x1, x1, #32
    871c:	eb00003f 	cmp	x1, x0
    8720:	540000e2 	b.cs	873c <fwp_hof0.constprop.0+0x50c>  // b.hs, b.nlast
    8724:	8b01039c 	add	x28, x28, x1
    8728:	39400380 	ldrb	w0, [x28]
    872c:	7103fc1f 	cmp	w0, #0xff
    8730:	54008c20 	b.eq	98b4 <fwp_hof0.constprop.0+0x1684>  // b.none
    8734:	52800020 	mov	w0, #0x1                   	// #1
    8738:	39000380 	strb	w0, [x28]
    873c:	b4000237 	cbz	x23, 8780 <fwp_hof0.constprop.0+0x550>
    8740:	d3607e64 	lsl	x4, x19, #32
    8744:	aa1603e1 	mov	x1, x22
    8748:	f94006c5 	ldr	x5, [x22, #8]
    874c:	aa0403e3 	mov	x3, x4
    8750:	91002302 	add	x2, x24, #0x8
    8754:	d2800000 	mov	x0, #0x0                   	// #0
    8758:	14000005 	b	876c <fwp_hof0.constprop.0+0x53c>
    875c:	f9400425 	ldr	x5, [x1, #8]
    8760:	ab000083 	adds	x3, x4, x0
    8764:	91004042 	add	x2, x2, #0x10
    8768:	5400aee6 	b.vs	9d44 <fwp_hof0.constprop.0+0x1b14>
    876c:	a9000c45 	stp	x5, x3, [x2]
    8770:	91000400 	add	x0, x0, #0x1
    8774:	f9400821 	ldr	x1, [x1, #16]
    8778:	eb17001f 	cmp	x0, x23
    877c:	54ffff03 	b.cc	875c <fwp_hof0.constprop.0+0x52c>  // b.lo, b.ul, b.last
    8780:	f9400300 	ldr	x0, [x24]
    8784:	f100041f 	cmp	x0, #0x1
    8788:	54007e49 	b.ls	9750 <fwp_hof0.constprop.0+0x1520>  // b.plast
    878c:	d341fc00 	lsr	x0, x0, #1
    8790:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8794:	d1000401 	sub	x1, x0, #0x1
    8798:	eb02003f 	cmp	x1, x2
    879c:	5400a988 	b.hi	9ccc <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    87a0:	d37ff83c 	lsl	x28, x1, #1
    87a4:	b4007d61 	cbz	x1, 9750 <fwp_hof0.constprop.0+0x1520>
    87a8:	d1002301 	sub	x1, x24, #0x8
    87ac:	91002319 	add	x25, x24, #0x8
    87b0:	8b001037 	add	x23, x1, x0, lsl #4
    87b4:	d503201f 	nop
    87b8:	f9400720 	ldr	x0, [x25, #8]
    87bc:	f9400f21 	ldr	x1, [x25, #24]
    87c0:	fd400320 	ldr	d0, [x25]
    87c4:	fd400b21 	ldr	d1, [x25, #16]
    87c8:	97fff35a 	bl	5530 <w120>
    87cc:	a9000720 	stp	x0, x1, [x25]
    87d0:	91004339 	add	x25, x25, #0x10
    87d4:	eb17033f 	cmp	x25, x23
    87d8:	54ffff01 	b.ne	87b8 <fwp_hof0.constprop.0+0x588>  // b.any
    87dc:	91174297 	add	x23, x20, #0x5d0
    87e0:	f900031c 	str	x28, [x24]
    87e4:	aa1803e0 	mov	x0, x24
    87e8:	97fff3af 	bl	56a4 <w176.constprop.0>
    87ec:	aa0103e5 	mov	x5, x1
    87f0:	f949dae1 	ldr	x1, [x23, #5040]
    87f4:	f949eee0 	ldr	x0, [x23, #5080]
    87f8:	cb010301 	sub	x1, x24, x1
    87fc:	eb00403f 	cmp	x1, x0, lsl #16
    8800:	54000382 	b.cs	8870 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    8804:	d350fc20 	lsr	x0, x1, #16
    8808:	f949fee4 	ldr	x4, [x23, #5112]
    880c:	8b000800 	add	x0, x0, x0, lsl #2
    8810:	d37df000 	lsl	x0, x0, #3
    8814:	8b000082 	add	x2, x4, x0
    8818:	f9401058 	ldr	x24, [x2, #32]
    881c:	b40002b8 	cbz	x24, 8870 <fwp_hof0.constprop.0+0x640>
    8820:	38606880 	ldrb	w0, [x4, x0]
    8824:	7100081f 	cmp	w0, #0x2
    8828:	54007980 	b.eq	9758 <fwp_hof0.constprop.0+0x1528>  // b.none
    882c:	7100041f 	cmp	w0, #0x1
    8830:	54000201 	b.ne	8870 <fwp_hof0.constprop.0+0x640>  // b.any
    8834:	29430043 	ldp	w3, w0, [x2, #24]
    8838:	92403c21 	and	x1, x1, #0xffff
    883c:	9b037c21 	mul	x1, x1, x3
    8840:	d360fc21 	lsr	x1, x1, #32
    8844:	eb00003f 	cmp	x1, x0
    8848:	54000142 	b.cs	8870 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    884c:	8b010318 	add	x24, x24, x1
    8850:	39400300 	ldrb	w0, [x24]
    8854:	340000e0 	cbz	w0, 8870 <fwp_hof0.constprop.0+0x640>
    8858:	7100041f 	cmp	w0, #0x1
    885c:	540022a0 	b.eq	8cb0 <fwp_hof0.constprop.0+0xa80>  // b.none
    8860:	7103fc1f 	cmp	w0, #0xff
    8864:	54009040 	b.eq	9a6c <fwp_hof0.constprop.0+0x183c>  // b.none
    8868:	51000400 	sub	w0, w0, #0x1
    886c:	39000300 	strb	w0, [x24]
    8870:	52800040 	mov	w0, #0x2                   	// #2
    8874:	93407e7c 	sxtw	x28, w19
    8878:	f90003e5 	str	x5, [sp]
    887c:	97ffeb7d 	bl	3670 <descent_phase_step>
    8880:	aa1c03e0 	mov	x0, x28
    8884:	97ffeccb 	bl	3bb0 <fwp_tape_of>
    8888:	f9403002 	ldr	x2, [x0, #96]
    888c:	aa0003e7 	mov	x7, x0
    8890:	f94003e5 	ldr	x5, [sp]
    8894:	b500a222 	cbnz	x2, 9cd8 <fwp_hof0.constprop.0+0x1aa8>
    8898:	97ffe9de 	bl	3010 <fwp_tape_unlink_scope>
    889c:	b9400008 	ldr	w8, [x0]
    88a0:	a9408019 	ldp	x25, x0, [x0, #8]
    88a4:	b90004ff 	str	wzr, [x7, #4]
    88a8:	a941dcea 	ldp	x10, x23, [x7, #24]
    88ac:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    88b0:	a942ecf8 	ldp	x24, x27, [x7, #40]
    88b4:	a943e8f3 	ldp	x19, x26, [x7, #56]
    88b8:	f94024e2 	ldr	x2, [x7, #72]
    88bc:	6b03011f 	cmp	w8, w3
    88c0:	54000108 	b.hi	88e0 <fwp_hof0.constprop.0+0x6b0>  // b.pmore
    88c4:	9101c2a8 	add	x8, x21, #0x70
    88c8:	92403f83 	and	x3, x28, #0xffff
    88cc:	d1000463 	sub	x3, x3, #0x1
    88d0:	f9407509 	ldr	x9, [x8, #232]
    88d4:	eb09007f 	cmp	x3, x9
    88d8:	5400004a 	b.ge	88e0 <fwp_hof0.constprop.0+0x6b0>  // b.tcont
    88dc:	f9007503 	str	x3, [x8, #232]
    88e0:	4f000400 	movi	v0.4s, #0x0
    88e4:	9101c2a9 	add	x9, x21, #0x70
    88e8:	f9000cff 	str	xzr, [x7, #24]
    88ec:	910243e1 	add	x1, sp, #0x90
    88f0:	a9047cff 	stp	xzr, xzr, [x7, #64]
    88f4:	9101e3e3 	add	x3, sp, #0x78
    88f8:	90ffffe8 	adrp	x8, 4000 <fwp_format_g.constprop.0+0x3ec>
    88fc:	f941892b 	ldr	x11, [x9, #784]
    8900:	3c8080e0 	stur	q0, [x7, #8]
    8904:	91100108 	add	x8, x8, #0x400
    8908:	ad0100e0 	stp	q0, q0, [x7, #32]
    890c:	f9000be1 	str	x1, [sp, #16]
    8910:	a907a3eb 	stp	x11, x8, [sp, #120]
    8914:	a908dfe1 	stp	x1, x23, [sp, #136]
    8918:	a909eff8 	stp	x24, x27, [sp, #152]
    891c:	a90aebf3 	stp	x19, x26, [sp, #168]
    8920:	a90b8bea 	stp	x10, x2, [sp, #184]
    8924:	f9018923 	str	x3, [x9, #784]
    8928:	b7f87da5 	tbnz	x5, #63, 98dc <fwp_hof0.constprop.0+0x16ac>
    892c:	eb85839f 	cmp	x28, x5, asr #32
    8930:	540098a1 	b.ne	9c44 <fwp_hof0.constprop.0+0x1a14>  // b.any
    8934:	92407ca3 	and	x3, x5, #0xffffffff
    8938:	eb25401f 	cmp	x0, w5, uxtw
    893c:	540097ed 	b.le	9c38 <fwp_hof0.constprop.0+0x1a08>
    8940:	eb03033f 	cmp	x25, x3
    8944:	9a83c73c 	csinc	x28, x25, x3, gt
    8948:	eb1c005f 	cmp	x2, x28
    894c:	5400186a 	b.ge	8c58 <fwp_hof0.constprop.0+0xa28>  // b.tcont
    8950:	f100005f 	cmp	x2, #0x0
    8954:	9a9c1042 	csel	x2, x2, x28, ne	// ne = any
    8958:	14000005 	b	896c <fwp_hof0.constprop.0+0x73c>
    895c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8960:	eb00005f 	cmp	x2, x0
    8964:	d37ff842 	lsl	x2, x2, #1
    8968:	9a9cd042 	csel	x2, x2, x28, le
    896c:	eb1c005f 	cmp	x2, x28
    8970:	54ffff6b 	b.lt	895c <fwp_hof0.constprop.0+0x72c>  // b.tstop
    8974:	f9001be5 	str	x5, [sp, #48]
    8978:	b400831a 	cbz	x26, 99d8 <fwp_hof0.constprop.0+0x17a8>
    897c:	aa1a03e0 	mov	x0, x26
    8980:	d37df041 	lsl	x1, x2, #3
    8984:	f90003e2 	str	x2, [sp]
    8988:	97ffe7de 	bl	2900 <realloc@plt>
    898c:	f94003e2 	ldr	x2, [sp]
    8990:	aa0003fa 	mov	x26, x0
    8994:	f9401be5 	ldr	x5, [sp, #48]
    8998:	b4009b3a 	cbz	x26, 9cfc <fwp_hof0.constprop.0+0x1acc>
    899c:	f9005bfa 	str	x26, [sp, #176]
    89a0:	f90063e2 	str	x2, [sp, #192]
    89a4:	b50014dc 	cbnz	x28, 8c3c <fwp_hof0.constprop.0+0xa0c>
    89a8:	b7f800c5 	tbnz	x5, #63, 89c0 <fwp_hof0.constprop.0+0x790>
    89ac:	92407ca1 	and	x1, x5, #0xffffffff
    89b0:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    89b4:	fc617b40 	ldr	d0, [x26, x1, lsl #3]
    89b8:	1e612800 	fadd	d0, d0, d1
    89bc:	fc217b40 	str	d0, [x26, x1, lsl #3]
    89c0:	9101c2a1 	add	x1, x21, #0x70
    89c4:	cb190385 	sub	x5, x28, x25
    89c8:	52800060 	mov	w0, #0x3                   	// #3
    89cc:	a9428827 	ldp	x7, x2, [x1, #40]
    89d0:	8b0700a5 	add	x5, x5, x7
    89d4:	8b190042 	add	x2, x2, x25
    89d8:	a9028825 	stp	x5, x2, [x1, #40]
    89dc:	97ffeb25 	bl	3670 <descent_phase_step>
    89e0:	d1000783 	sub	x3, x28, #0x1
    89e4:	d1000725 	sub	x5, x25, #0x1
    89e8:	eb03033f 	cmp	x25, x3
    89ec:	540003ac 	b.gt	8a60 <fwp_hof0.constprop.0+0x830>
    89f0:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    89f4:	1e602008 	fcmp	d0, #0.0
    89f8:	540002e0 	b.eq	8a54 <fwp_hof0.constprop.0+0x824>  // b.none
    89fc:	cb190be0 	neg	x0, x25, lsl #2
    8a00:	cb1903e2 	neg	x2, x25
    8a04:	8b0002e1 	add	x1, x23, x0
    8a08:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    8a0c:	37f80101 	tbnz	w1, #31, 8a2c <fwp_hof0.constprop.0+0x7fc>
    8a10:	8b020f67 	add	x7, x27, x2, lsl #3
    8a14:	93407c21 	sxtw	x1, w1
    8a18:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    8a1c:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    8a20:	1e620802 	fmul	d2, d0, d2
    8a24:	1e622821 	fadd	d1, d1, d2
    8a28:	fc217b41 	str	d1, [x26, x1, lsl #3]
    8a2c:	8b000300 	add	x0, x24, x0
    8a30:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    8a34:	37f80100 	tbnz	w0, #31, 8a54 <fwp_hof0.constprop.0+0x824>
    8a38:	8b020e62 	add	x2, x19, x2, lsl #3
    8a3c:	93407c00 	sxtw	x0, w0
    8a40:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    8a44:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    8a48:	1e620800 	fmul	d0, d0, d2
    8a4c:	1e602820 	fadd	d0, d1, d0
    8a50:	fc207b40 	str	d0, [x26, x0, lsl #3]
    8a54:	d1000463 	sub	x3, x3, #0x1
    8a58:	eb0300bf 	cmp	x5, x3
    8a5c:	54fffca1 	b.ne	89f0 <fwp_hof0.constprop.0+0x7c0>  // b.any
    8a60:	52800080 	mov	w0, #0x4                   	// #4
    8a64:	97ffeb03 	bl	3670 <descent_phase_step>
    8a68:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8a6c:	eb00033f 	cmp	x25, x0
    8a70:	54009408 	b.hi	9cf0 <fwp_hof0.constprop.0+0x1ac0>  // b.pmore
    8a74:	91000720 	add	x0, x25, #0x1
    8a78:	52800041 	mov	w1, #0x2                   	// #2
    8a7c:	d37df000 	lsl	x0, x0, #3
    8a80:	97fff13c 	bl	4f70 <fwp_heap_alloc>
    8a84:	aa0003e2 	mov	x2, x0
    8a88:	aa0003f3 	mov	x19, x0
    8a8c:	d2800001 	mov	x1, #0x0                   	// #0
    8a90:	f8008459 	str	x25, [x2], #8
    8a94:	b40000d9 	cbz	x25, 8aac <fwp_hof0.constprop.0+0x87c>
    8a98:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    8a9c:	f8217840 	str	x0, [x2, x1, lsl #3]
    8aa0:	91000421 	add	x1, x1, #0x1
    8aa4:	eb01033f 	cmp	x25, x1
    8aa8:	54ffff81 	b.ne	8a98 <fwp_hof0.constprop.0+0x868>  // b.any
    8aac:	528000a0 	mov	w0, #0x5                   	// #5
    8ab0:	97ffeaf0 	bl	3670 <descent_phase_step>
    8ab4:	f9400be0 	ldr	x0, [sp, #16]
    8ab8:	9101c2a1 	add	x1, x21, #0x70
    8abc:	f9403ff8 	ldr	x24, [sp, #120]
    8ac0:	f9018838 	str	x24, [x1, #784]
    8ac4:	97ffee4f 	bl	4400 <fwp_tape_buffers_release>
    8ac8:	528000c0 	mov	w0, #0x6                   	// #6
    8acc:	97ffeae9 	bl	3670 <descent_phase_step>
    8ad0:	91174282 	add	x2, x20, #0x5d0
    8ad4:	f949d841 	ldr	x1, [x2, #5040]
    8ad8:	f949ec40 	ldr	x0, [x2, #5080]
    8adc:	cb010261 	sub	x1, x19, x1
    8ae0:	eb00403f 	cmp	x1, x0, lsl #16
    8ae4:	54000322 	b.cs	8b48 <fwp_hof0.constprop.0+0x918>  // b.hs, b.nlast
    8ae8:	d350fc20 	lsr	x0, x1, #16
    8aec:	f949fc43 	ldr	x3, [x2, #5112]
    8af0:	8b000800 	add	x0, x0, x0, lsl #2
    8af4:	d37df002 	lsl	x2, x0, #3
    8af8:	8b020060 	add	x0, x3, x2
    8afc:	f9401017 	ldr	x23, [x0, #32]
    8b00:	b4000257 	cbz	x23, 8b48 <fwp_hof0.constprop.0+0x918>
    8b04:	38626862 	ldrb	w2, [x3, x2]
    8b08:	7100085f 	cmp	w2, #0x2
    8b0c:	54006ec0 	b.eq	98e4 <fwp_hof0.constprop.0+0x16b4>  // b.none
    8b10:	7100045f 	cmp	w2, #0x1
    8b14:	540001a1 	b.ne	8b48 <fwp_hof0.constprop.0+0x918>  // b.any
    8b18:	29430002 	ldp	w2, w0, [x0, #24]
    8b1c:	92403c21 	and	x1, x1, #0xffff
    8b20:	9b027c21 	mul	x1, x1, x2
    8b24:	d360fc21 	lsr	x1, x1, #32
    8b28:	eb00003f 	cmp	x1, x0
    8b2c:	540000e2 	b.cs	8b48 <fwp_hof0.constprop.0+0x918>  // b.hs, b.nlast
    8b30:	8b0102f7 	add	x23, x23, x1
    8b34:	394002e0 	ldrb	w0, [x23]
    8b38:	7103fc1f 	cmp	w0, #0xff
    8b3c:	54006de0 	b.eq	98f8 <fwp_hof0.constprop.0+0x16c8>  // b.none
    8b40:	52800020 	mov	w0, #0x1                   	// #1
    8b44:	390002e0 	strb	w0, [x23]
    8b48:	f94013e0 	ldr	x0, [sp, #32]
    8b4c:	eb00031f 	cmp	x24, x0
    8b50:	54008fc1 	b.ne	9d48 <fwp_hof0.constprop.0+0x1b18>  // b.any
    8b54:	f9400fe0 	ldr	x0, [sp, #24]
    8b58:	9101c2a1 	add	x1, x21, #0x70
    8b5c:	f94033e2 	ldr	x2, [sp, #96]
    8b60:	f9018822 	str	x2, [x1, #784]
    8b64:	97fff5ab 	bl	6210 <fwp_tape_scope_release>
    8b68:	f9400260 	ldr	x0, [x19]
    8b6c:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8b70:	b7f84700 	tbnz	x0, #63, 9450 <fwp_hof0.constprop.0+0x1220>
    8b74:	91174282 	add	x2, x20, #0x5d0
    8b78:	f949d840 	ldr	x0, [x2, #5040]
    8b7c:	f949ec41 	ldr	x1, [x2, #5080]
    8b80:	cb000260 	sub	x0, x19, x0
    8b84:	eb01401f 	cmp	x0, x1, lsl #16
    8b88:	54004642 	b.cs	9450 <fwp_hof0.constprop.0+0x1220>  // b.hs, b.nlast
    8b8c:	d350fc01 	lsr	x1, x0, #16
    8b90:	f949fc44 	ldr	x4, [x2, #5112]
    8b94:	8b010821 	add	x1, x1, x1, lsl #2
    8b98:	d37df021 	lsl	x1, x1, #3
    8b9c:	8b010083 	add	x3, x4, x1
    8ba0:	f9401062 	ldr	x2, [x3, #32]
    8ba4:	b4004562 	cbz	x2, 9450 <fwp_hof0.constprop.0+0x1220>
    8ba8:	38616881 	ldrb	w1, [x4, x1]
    8bac:	7100083f 	cmp	w1, #0x2
    8bb0:	540044a0 	b.eq	9444 <fwp_hof0.constprop.0+0x1214>  // b.none
    8bb4:	7100043f 	cmp	w1, #0x1
    8bb8:	540044c1 	b.ne	9450 <fwp_hof0.constprop.0+0x1220>  // b.any
    8bbc:	29430464 	ldp	w4, w1, [x3, #24]
    8bc0:	92403c00 	and	x0, x0, #0xffff
    8bc4:	9b047c00 	mul	x0, x0, x4
    8bc8:	d360fc00 	lsr	x0, x0, #32
    8bcc:	eb01001f 	cmp	x0, x1
    8bd0:	54004402 	b.cs	9450 <fwp_hof0.constprop.0+0x1220>  // b.hs, b.nlast
    8bd4:	8b000042 	add	x2, x2, x0
    8bd8:	39400040 	ldrb	w0, [x2]
    8bdc:	7100041f 	cmp	w0, #0x1
    8be0:	54004381 	b.ne	9450 <fwp_hof0.constprop.0+0x1220>  // b.any
    8be4:	aa1303fb 	mov	x27, x19
    8be8:	d2800000 	mov	x0, #0x0                   	// #0
    8bec:	f90003f3 	str	x19, [sp]
    8bf0:	f94003e1 	ldr	x1, [sp]
    8bf4:	91002265 	add	x5, x19, #0x8
    8bf8:	91002023 	add	x3, x1, #0x8
    8bfc:	d2800001 	mov	x1, #0x0                   	// #0
    8c00:	b5000158 	cbnz	x24, 8c28 <fwp_hof0.constprop.0+0x9f8>
    8c04:	1400004e 	b	8d3c <fwp_hof0.constprop.0+0xb0c>
    8c08:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8c0c:	f9400362 	ldr	x2, [x27]
    8c10:	1e600900 	fmul	d0, d8, d0
    8c14:	b7f88562 	tbnz	x2, #63, 9cc0 <fwp_hof0.constprop.0+0x1a90>
    8c18:	91000421 	add	x1, x1, #0x1
    8c1c:	fc008460 	str	d0, [x3], #8
    8c20:	eb01031f 	cmp	x24, x1
    8c24:	540008c0 	b.eq	8d3c <fwp_hof0.constprop.0+0xb0c>  // b.none
    8c28:	f9400264 	ldr	x4, [x19]
    8c2c:	aa0503e2 	mov	x2, x5
    8c30:	b6fffec4 	tbz	x4, #63, 8c08 <fwp_hof0.constprop.0+0x9d8>
    8c34:	f9400a62 	ldr	x2, [x19, #16]
    8c38:	17fffff4 	b	8c08 <fwp_hof0.constprop.0+0x9d8>
    8c3c:	d37df382 	lsl	x2, x28, #3
    8c40:	aa1a03e0 	mov	x0, x26
    8c44:	52800001 	mov	w1, #0x0                   	// #0
    8c48:	f90003e5 	str	x5, [sp]
    8c4c:	97ffe725 	bl	28e0 <memset@plt>
    8c50:	f94003e5 	ldr	x5, [sp]
    8c54:	17ffff55 	b	89a8 <fwp_hof0.constprop.0+0x778>
    8c58:	f100035f 	cmp	x26, #0x0
    8c5c:	1a9f17e0 	cset	w0, eq	// eq = none
    8c60:	f100039f 	cmp	x28, #0x0
    8c64:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8c68:	54ffe9e0 	b.eq	89a4 <fwp_hof0.constprop.0+0x774>  // b.none
    8c6c:	f9400be0 	ldr	x0, [sp, #16]
    8c70:	9101c2b5 	add	x21, x21, #0x70
    8c74:	f9403fe1 	ldr	x1, [sp, #120]
    8c78:	f9018aa1 	str	x1, [x21, #784]
    8c7c:	97ffede1 	bl	4400 <fwp_tape_buffers_release>
    8c80:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8c84:	f947e863 	ldr	x3, [x3, #4048]
    8c88:	d2800262 	mov	x2, #0x13                  	// #19
    8c8c:	d2800021 	mov	x1, #0x1                   	// #1
    8c90:	b0000020 	adrp	x0, d000 <__modti3+0x320>
    8c94:	91022000 	add	x0, x0, #0x88
    8c98:	f9400063 	ldr	x3, [x3]
    8c9c:	97ffe75d 	bl	2a10 <fwrite@plt>
    8ca0:	d2800000 	mov	x0, #0x0                   	// #0
    8ca4:	97ffe767 	bl	2a40 <fflush@plt>
    8ca8:	52800cc0 	mov	w0, #0x66                  	// #102
    8cac:	97ffe775 	bl	2a80 <_Exit@plt>
    8cb0:	f9400366 	ldr	x6, [x27]
    8cb4:	aa1b03e0 	mov	x0, x27
    8cb8:	f949eee3 	ldr	x3, [x23, #5080]
    8cbc:	f949dae1 	ldr	x1, [x23, #5040]
    8cc0:	d370bc63 	lsl	x3, x3, #16
    8cc4:	cb010362 	sub	x2, x27, x1
    8cc8:	b7f85546 	tbnz	x6, #63, 9770 <fwp_hof0.constprop.0+0x1540>
    8ccc:	eb02007f 	cmp	x3, x2
    8cd0:	54ffdd09 	b.ls	8870 <fwp_hof0.constprop.0+0x640>  // b.plast
    8cd4:	d350fc40 	lsr	x0, x2, #16
    8cd8:	8b000800 	add	x0, x0, x0, lsl #2
    8cdc:	d37df000 	lsl	x0, x0, #3
    8ce0:	8b000083 	add	x3, x4, x0
    8ce4:	f9401061 	ldr	x1, [x3, #32]
    8ce8:	b4ffdc41 	cbz	x1, 8870 <fwp_hof0.constprop.0+0x640>
    8cec:	38606880 	ldrb	w0, [x4, x0]
    8cf0:	7100081f 	cmp	w0, #0x2
    8cf4:	54006080 	b.eq	9904 <fwp_hof0.constprop.0+0x16d4>  // b.none
    8cf8:	7100041f 	cmp	w0, #0x1
    8cfc:	54ffdba1 	b.ne	8870 <fwp_hof0.constprop.0+0x640>  // b.any
    8d00:	92403c40 	and	x0, x2, #0xffff
    8d04:	29430864 	ldp	w4, w2, [x3, #24]
    8d08:	9b047c00 	mul	x0, x0, x4
    8d0c:	d360fc00 	lsr	x0, x0, #32
    8d10:	eb02001f 	cmp	x0, x2
    8d14:	54ffdae2 	b.cs	8870 <fwp_hof0.constprop.0+0x640>  // b.hs, b.nlast
    8d18:	8b000021 	add	x1, x1, x0
    8d1c:	39400020 	ldrb	w0, [x1]
    8d20:	7100041f 	cmp	w0, #0x1
    8d24:	54ffda61 	b.ne	8870 <fwp_hof0.constprop.0+0x640>  // b.any
    8d28:	aa1b03e0 	mov	x0, x27
    8d2c:	f90003e5 	str	x5, [sp]
    8d30:	97ffef70 	bl	4af0 <fwp_mem_free>
    8d34:	f94003e5 	ldr	x5, [sp]
    8d38:	17fffece 	b	8870 <fwp_hof0.constprop.0+0x640>
    8d3c:	97fff721 	bl	69c0 <fwp_drop10>
    8d40:	aa1603e1 	mov	x1, x22
    8d44:	d2800002 	mov	x2, #0x0                   	// #0
    8d48:	b40065f6 	cbz	x22, 9a04 <fwp_hof0.constprop.0+0x17d4>
    8d4c:	d503201f 	nop
    8d50:	f9400821 	ldr	x1, [x1, #16]
    8d54:	91000442 	add	x2, x2, #0x1
    8d58:	b5ffffc1 	cbnz	x1, 8d50 <fwp_hof0.constprop.0+0xb20>
    8d5c:	f9400360 	ldr	x0, [x27]
    8d60:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    8d64:	b7f82c40 	tbnz	x0, #63, 92ec <fwp_hof0.constprop.0+0x10bc>
    8d68:	91174283 	add	x3, x20, #0x5d0
    8d6c:	f94003e4 	ldr	x4, [sp]
    8d70:	f949d861 	ldr	x1, [x3, #5040]
    8d74:	f949ec63 	ldr	x3, [x3, #5080]
    8d78:	cb010081 	sub	x1, x4, x1
    8d7c:	eb03403f 	cmp	x1, x3, lsl #16
    8d80:	54002b62 	b.cs	92ec <fwp_hof0.constprop.0+0x10bc>  // b.hs, b.nlast
    8d84:	91174284 	add	x4, x20, #0x5d0
    8d88:	d350fc23 	lsr	x3, x1, #16
    8d8c:	8b030863 	add	x3, x3, x3, lsl #2
    8d90:	f949fc87 	ldr	x7, [x4, #5112]
    8d94:	d37df063 	lsl	x3, x3, #3
    8d98:	8b0300e6 	add	x6, x7, x3
    8d9c:	f94010c4 	ldr	x4, [x6, #32]
    8da0:	b4002a44 	cbz	x4, 92e8 <fwp_hof0.constprop.0+0x10b8>
    8da4:	386368e3 	ldrb	w3, [x7, x3]
    8da8:	7100087f 	cmp	w3, #0x2
    8dac:	540029a0 	b.eq	92e0 <fwp_hof0.constprop.0+0x10b0>  // b.none
    8db0:	7100047f 	cmp	w3, #0x1
    8db4:	540029a1 	b.ne	92e8 <fwp_hof0.constprop.0+0x10b8>  // b.any
    8db8:	29430cc7 	ldp	w7, w3, [x6, #24]
    8dbc:	92403c21 	and	x1, x1, #0xffff
    8dc0:	9b077c21 	mul	x1, x1, x7
    8dc4:	d360fc21 	lsr	x1, x1, #32
    8dc8:	eb03003f 	cmp	x1, x3
    8dcc:	540028e2 	b.cs	92e8 <fwp_hof0.constprop.0+0x10b8>  // b.hs, b.nlast
    8dd0:	8b010084 	add	x4, x4, x1
    8dd4:	39400081 	ldrb	w1, [x4]
    8dd8:	7100043f 	cmp	w1, #0x1
    8ddc:	54002861 	b.ne	92e8 <fwp_hof0.constprop.0+0x10b8>  // b.any
    8de0:	b90033e1 	str	w1, [sp, #48]
    8de4:	eb05005f 	cmp	x2, x5
    8de8:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8dec:	9100237c 	add	x28, x27, #0x8
    8df0:	b4006ea5 	cbz	x5, 9bc4 <fwp_hof0.constprop.0+0x1994>
    8df4:	f94003e1 	ldr	x1, [sp]
    8df8:	d37df0a7 	lsl	x7, x5, #3
    8dfc:	aa1603e2 	mov	x2, x22
    8e00:	91002026 	add	x6, x1, #0x8
    8e04:	d2800001 	mov	x1, #0x0                   	// #0
    8e08:	1400000a 	b	8e30 <fwp_hof0.constprop.0+0xc00>
    8e0c:	fc616881 	ldr	d1, [x4, x1]
    8e10:	fd400440 	ldr	d0, [x2, #8]
    8e14:	1e613800 	fsub	d0, d0, d1
    8e18:	fc216b80 	str	d0, [x28, x1]
    8e1c:	91002021 	add	x1, x1, #0x8
    8e20:	f9400842 	ldr	x2, [x2, #16]
    8e24:	eb07003f 	cmp	x1, x7
    8e28:	540001c0 	b.eq	8e60 <fwp_hof0.constprop.0+0xc30>  // b.none
    8e2c:	f9400360 	ldr	x0, [x27]
    8e30:	aa0603e4 	mov	x4, x6
    8e34:	b6fffec0 	tbz	x0, #63, 8e0c <fwp_hof0.constprop.0+0xbdc>
    8e38:	f94003e0 	ldr	x0, [sp]
    8e3c:	fd400440 	ldr	d0, [x2, #8]
    8e40:	f9400804 	ldr	x4, [x0, #16]
    8e44:	fc616881 	ldr	d1, [x4, x1]
    8e48:	1e613800 	fsub	d0, d0, d1
    8e4c:	fc216b80 	str	d0, [x28, x1]
    8e50:	91002021 	add	x1, x1, #0x8
    8e54:	f9400842 	ldr	x2, [x2, #16]
    8e58:	eb07003f 	cmp	x1, x7
    8e5c:	54fffe81 	b.ne	8e2c <fwp_hof0.constprop.0+0xbfc>  // b.any
    8e60:	b4006e96 	cbz	x22, 9c30 <fwp_hof0.constprop.0+0x1a00>
    8e64:	91174280 	add	x0, x20, #0x5d0
    8e68:	aa1603e7 	mov	x7, x22
    8e6c:	d2800018 	mov	x24, #0x0                   	// #0
    8e70:	f949ec09 	ldr	x9, [x0, #5080]
    8e74:	f949d80a 	ldr	x10, [x0, #5040]
    8e78:	f949fc08 	ldr	x8, [x0, #5112]
    8e7c:	d370bd29 	lsl	x9, x9, #16
    8e80:	14000006 	b	8e98 <fwp_hof0.constprop.0+0xc68>
    8e84:	f94008e7 	ldr	x7, [x7, #16]
    8e88:	91000718 	add	x24, x24, #0x1
    8e8c:	f10000ff 	cmp	x7, #0x0
    8e90:	fa5810a0 	ccmp	x5, x24, #0x0, ne	// ne = any
    8e94:	54000329 	b.ls	8ef8 <fwp_hof0.constprop.0+0xcc8>  // b.plast
    8e98:	cb0a00e0 	sub	x0, x7, x10
    8e9c:	eb09001f 	cmp	x0, x9
    8ea0:	540002c2 	b.cs	8ef8 <fwp_hof0.constprop.0+0xcc8>  // b.hs, b.nlast
    8ea4:	d350fc01 	lsr	x1, x0, #16
    8ea8:	8b010821 	add	x1, x1, x1, lsl #2
    8eac:	d37df021 	lsl	x1, x1, #3
    8eb0:	8b010106 	add	x6, x8, x1
    8eb4:	f94010c2 	ldr	x2, [x6, #32]
    8eb8:	b4000202 	cbz	x2, 8ef8 <fwp_hof0.constprop.0+0xcc8>
    8ebc:	38616901 	ldrb	w1, [x8, x1]
    8ec0:	7100083f 	cmp	w1, #0x2
    8ec4:	54000e20 	b.eq	9088 <fwp_hof0.constprop.0+0xe58>  // b.none
    8ec8:	7100043f 	cmp	w1, #0x1
    8ecc:	54000161 	b.ne	8ef8 <fwp_hof0.constprop.0+0xcc8>  // b.any
    8ed0:	294304cb 	ldp	w11, w1, [x6, #24]
    8ed4:	92403c00 	and	x0, x0, #0xffff
    8ed8:	9b0b7c00 	mul	x0, x0, x11
    8edc:	d360fc00 	lsr	x0, x0, #32
    8ee0:	eb01001f 	cmp	x0, x1
    8ee4:	540000a2 	b.cs	8ef8 <fwp_hof0.constprop.0+0xcc8>  // b.hs, b.nlast
    8ee8:	8b000042 	add	x2, x2, x0
    8eec:	39400040 	ldrb	w0, [x2]
    8ef0:	7100041f 	cmp	w0, #0x1
    8ef4:	54fffc80 	b.eq	8e84 <fwp_hof0.constprop.0+0xc54>  // b.none
    8ef8:	eb1800bf 	cmp	x5, x24
    8efc:	54000ce9 	b.ls	9098 <fwp_hof0.constprop.0+0xe68>  // b.plast
    8f00:	aa0503f7 	mov	x23, x5
    8f04:	d1002399 	sub	x25, x28, #0x8
    8f08:	910323f3 	add	x19, sp, #0xc8
    8f0c:	9117429a 	add	x26, x20, #0x5d0
    8f10:	d280001b 	mov	x27, #0x0                   	// #0
    8f14:	14000012 	b	8f5c <fwp_hof0.constprop.0+0xd2c>
    8f18:	7100045f 	cmp	w2, #0x1
    8f1c:	540001a1 	b.ne	8f50 <fwp_hof0.constprop.0+0xd20>  // b.any
    8f20:	29430909 	ldp	w9, w2, [x8, #24]
    8f24:	92403c21 	and	x1, x1, #0xffff
    8f28:	9b097c21 	mul	x1, x1, x9
    8f2c:	d360fc21 	lsr	x1, x1, #32
    8f30:	eb02003f 	cmp	x1, x2
    8f34:	540000e2 	b.cs	8f50 <fwp_hof0.constprop.0+0xd20>  // b.hs, b.nlast
    8f38:	8b010000 	add	x0, x0, x1
    8f3c:	39400001 	ldrb	w1, [x0]
    8f40:	7103fc3f 	cmp	w1, #0xff
    8f44:	54003020 	b.eq	9548 <fwp_hof0.constprop.0+0x1318>  // b.none
    8f48:	52800021 	mov	w1, #0x1                   	// #1
    8f4c:	39000001 	strb	w1, [x0]
    8f50:	d10006f7 	sub	x23, x23, #0x1
    8f54:	eb1802ff 	cmp	x23, x24
    8f58:	54000389 	b.ls	8fc8 <fwp_hof0.constprop.0+0xd98>  // b.plast
    8f5c:	f8777b22 	ldr	x2, [x25, x23, lsl #3]
    8f60:	aa1303e1 	mov	x1, x19
    8f64:	52800020 	mov	w0, #0x1                   	// #1
    8f68:	a90cefe2 	stp	x2, x27, [sp, #200]
    8f6c:	97fff046 	bl	5084 <fwp_data.part.0.constprop.0>
    8f70:	aa0003fb 	mov	x27, x0
    8f74:	f949db41 	ldr	x1, [x26, #5040]
    8f78:	f949ef40 	ldr	x0, [x26, #5080]
    8f7c:	cb010361 	sub	x1, x27, x1
    8f80:	eb00403f 	cmp	x1, x0, lsl #16
    8f84:	54fffe62 	b.cs	8f50 <fwp_hof0.constprop.0+0xd20>  // b.hs, b.nlast
    8f88:	d350fc20 	lsr	x0, x1, #16
    8f8c:	f949ff49 	ldr	x9, [x26, #5112]
    8f90:	8b000800 	add	x0, x0, x0, lsl #2
    8f94:	d37df002 	lsl	x2, x0, #3
    8f98:	8b020128 	add	x8, x9, x2
    8f9c:	f9401100 	ldr	x0, [x8, #32]
    8fa0:	b4fffd80 	cbz	x0, 8f50 <fwp_hof0.constprop.0+0xd20>
    8fa4:	38626922 	ldrb	w2, [x9, x2]
    8fa8:	7100085f 	cmp	w2, #0x2
    8fac:	54fffb61 	b.ne	8f18 <fwp_hof0.constprop.0+0xce8>  // b.any
    8fb0:	72003c3f 	tst	w1, #0xffff
    8fb4:	54fffc40 	b.eq	8f3c <fwp_hof0.constprop.0+0xd0c>  // b.none
    8fb8:	d10006f7 	sub	x23, x23, #0x1
    8fbc:	eb1802ff 	cmp	x23, x24
    8fc0:	54fffce8 	b.hi	8f5c <fwp_hof0.constprop.0+0xd2c>  // b.pmore
    8fc4:	d503201f 	nop
    8fc8:	b50006b8 	cbnz	x24, 909c <fwp_hof0.constprop.0+0xe6c>
    8fcc:	b94033e0 	ldr	w0, [sp, #48]
    8fd0:	d2800004 	mov	x4, #0x0                   	// #0
    8fd4:	7100001f 	cmp	w0, #0x0
    8fd8:	d2800020 	mov	x0, #0x1                   	// #1
    8fdc:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    8fe0:	b40007c4 	cbz	x4, 90d8 <fwp_hof0.constprop.0+0xea8>
    8fe4:	d1000498 	sub	x24, x4, #0x1
    8fe8:	2a0003f9 	mov	w25, w0
    8fec:	9117429a 	add	x26, x20, #0x5d0
    8ff0:	f8787b82 	ldr	x2, [x28, x24, lsl #3]
    8ff4:	aa1303e1 	mov	x1, x19
    8ff8:	52800020 	mov	w0, #0x1                   	// #1
    8ffc:	a90cefe2 	stp	x2, x27, [sp, #200]
    9000:	97fff021 	bl	5084 <fwp_data.part.0.constprop.0>
    9004:	aa0003fb 	mov	x27, x0
    9008:	f949db41 	ldr	x1, [x26, #5040]
    900c:	f949ef40 	ldr	x0, [x26, #5080]
    9010:	cb010361 	sub	x1, x27, x1
    9014:	eb00403f 	cmp	x1, x0, lsl #16
    9018:	54000302 	b.cs	9078 <fwp_hof0.constprop.0+0xe48>  // b.hs, b.nlast
    901c:	d350fc22 	lsr	x2, x1, #16
    9020:	f949ff47 	ldr	x7, [x26, #5112]
    9024:	8b020842 	add	x2, x2, x2, lsl #2
    9028:	d37df042 	lsl	x2, x2, #3
    902c:	8b0200e6 	add	x6, x7, x2
    9030:	f94010d7 	ldr	x23, [x6, #32]
    9034:	b4000237 	cbz	x23, 9078 <fwp_hof0.constprop.0+0xe48>
    9038:	386268e2 	ldrb	w2, [x7, x2]
    903c:	7100085f 	cmp	w2, #0x2
    9040:	540014a0 	b.eq	92d4 <fwp_hof0.constprop.0+0x10a4>  // b.none
    9044:	7100045f 	cmp	w2, #0x1
    9048:	54000181 	b.ne	9078 <fwp_hof0.constprop.0+0xe48>  // b.any
    904c:	294308c7 	ldp	w7, w2, [x6, #24]
    9050:	92403c21 	and	x1, x1, #0xffff
    9054:	9b077c21 	mul	x1, x1, x7
    9058:	d360fc21 	lsr	x1, x1, #32
    905c:	eb02003f 	cmp	x1, x2
    9060:	540000c2 	b.cs	9078 <fwp_hof0.constprop.0+0xe48>  // b.hs, b.nlast
    9064:	8b0102f7 	add	x23, x23, x1
    9068:	394002e1 	ldrb	w1, [x23]
    906c:	7103fc3f 	cmp	w1, #0xff
    9070:	540012c0 	b.eq	92c8 <fwp_hof0.constprop.0+0x1098>  // b.none
    9074:	390002f9 	strb	w25, [x23]
    9078:	d1000718 	sub	x24, x24, #0x1
    907c:	b100071f 	cmn	x24, #0x1
    9080:	54fffb81 	b.ne	8ff0 <fwp_hof0.constprop.0+0xdc0>  // b.any
    9084:	14000015 	b	90d8 <fwp_hof0.constprop.0+0xea8>
    9088:	72003c1f 	tst	w0, #0xffff
    908c:	54fff300 	b.eq	8eec <fwp_hof0.constprop.0+0xcbc>  // b.none
    9090:	eb1800bf 	cmp	x5, x24
    9094:	54fff368 	b.hi	8f00 <fwp_hof0.constprop.0+0xcd0>  // b.pmore
    9098:	d280001b 	mov	x27, #0x0                   	// #0
    909c:	8b180f84 	add	x4, x28, x24, lsl #3
    90a0:	aa1c03e1 	mov	x1, x28
    90a4:	aa1603e0 	mov	x0, x22
    90a8:	f8408422 	ldr	x2, [x1], #8
    90ac:	f9000402 	str	x2, [x0, #8]
    90b0:	aa0003e2 	mov	x2, x0
    90b4:	f9400800 	ldr	x0, [x0, #16]
    90b8:	eb04003f 	cmp	x1, x4
    90bc:	54ffff61 	b.ne	90a8 <fwp_hof0.constprop.0+0xe78>  // b.any
    90c0:	b94033e1 	ldr	w1, [sp, #48]
    90c4:	f900085b 	str	x27, [x2, #16]
    90c8:	aa1603fb 	mov	x27, x22
    90cc:	aa0003f6 	mov	x22, x0
    90d0:	34000041 	cbz	w1, 90d8 <fwp_hof0.constprop.0+0xea8>
    90d4:	d280001c 	mov	x28, #0x0                   	// #0
    90d8:	91174293 	add	x19, x20, #0x5d0
    90dc:	aa1c03e0 	mov	x0, x28
    90e0:	97ffee84 	bl	4af0 <fwp_mem_free>
    90e4:	f94003e0 	ldr	x0, [sp]
    90e8:	f949ee62 	ldr	x2, [x19, #5080]
    90ec:	f949da61 	ldr	x1, [x19, #5040]
    90f0:	d370bc42 	lsl	x2, x2, #16
    90f4:	cb010003 	sub	x3, x0, x1
    90f8:	eb02007f 	cmp	x3, x2
    90fc:	54000422 	b.cs	9180 <fwp_hof0.constprop.0+0xf50>  // b.hs, b.nlast
    9100:	d350fc60 	lsr	x0, x3, #16
    9104:	f949fe65 	ldr	x5, [x19, #5112]
    9108:	8b000800 	add	x0, x0, x0, lsl #2
    910c:	d37df000 	lsl	x0, x0, #3
    9110:	8b0000a2 	add	x2, x5, x0
    9114:	f9401058 	ldr	x24, [x2, #32]
    9118:	b4000cf8 	cbz	x24, 92b4 <fwp_hof0.constprop.0+0x1084>
    911c:	386068a1 	ldrb	w1, [x5, x0]
    9120:	7100083f 	cmp	w1, #0x2
    9124:	54003200 	b.eq	9764 <fwp_hof0.constprop.0+0x1534>  // b.none
    9128:	7100043f 	cmp	w1, #0x1
    912c:	54000c41 	b.ne	92b4 <fwp_hof0.constprop.0+0x1084>  // b.any
    9130:	29430844 	ldp	w4, w2, [x2, #24]
    9134:	92403c61 	and	x1, x3, #0xffff
    9138:	9b047c21 	mul	x1, x1, x4
    913c:	d360fc21 	lsr	x1, x1, #32
    9140:	eb02003f 	cmp	x1, x2
    9144:	54000b82 	b.cs	92b4 <fwp_hof0.constprop.0+0x1084>  // b.hs, b.nlast
    9148:	8b010318 	add	x24, x24, x1
    914c:	39400301 	ldrb	w1, [x24]
    9150:	34000b21 	cbz	w1, 92b4 <fwp_hof0.constprop.0+0x1084>
    9154:	7100043f 	cmp	w1, #0x1
    9158:	540006c0 	b.eq	9230 <fwp_hof0.constprop.0+0x1000>  // b.none
    915c:	7103fc3f 	cmp	w1, #0xff
    9160:	54004bc0 	b.eq	9ad8 <fwp_hof0.constprop.0+0x18a8>  // b.none
    9164:	91174280 	add	x0, x20, #0x5d0
    9168:	51000421 	sub	w1, w1, #0x1
    916c:	39000301 	strb	w1, [x24]
    9170:	f949ec02 	ldr	x2, [x0, #5080]
    9174:	f949d801 	ldr	x1, [x0, #5040]
    9178:	d370bc42 	lsl	x2, x2, #16
    917c:	d503201f 	nop
    9180:	cb0102c1 	sub	x1, x22, x1
    9184:	eb02003f 	cmp	x1, x2
    9188:	540003c2 	b.cs	9200 <fwp_hof0.constprop.0+0xfd0>  // b.hs, b.nlast
    918c:	91174297 	add	x23, x20, #0x5d0
    9190:	d350fc20 	lsr	x0, x1, #16
    9194:	f949fee3 	ldr	x3, [x23, #5112]
    9198:	8b000800 	add	x0, x0, x0, lsl #2
    919c:	d37df000 	lsl	x0, x0, #3
    91a0:	8b000062 	add	x2, x3, x0
    91a4:	f9401053 	ldr	x19, [x2, #32]
    91a8:	b40002d3 	cbz	x19, 9200 <fwp_hof0.constprop.0+0xfd0>
    91ac:	38606860 	ldrb	w0, [x3, x0]
    91b0:	7100081f 	cmp	w0, #0x2
    91b4:	54003240 	b.eq	97fc <fwp_hof0.constprop.0+0x15cc>  // b.none
    91b8:	7100041f 	cmp	w0, #0x1
    91bc:	54000221 	b.ne	9200 <fwp_hof0.constprop.0+0xfd0>  // b.any
    91c0:	29430044 	ldp	w4, w0, [x2, #24]
    91c4:	92403c21 	and	x1, x1, #0xffff
    91c8:	9b047c21 	mul	x1, x1, x4
    91cc:	d360fc21 	lsr	x1, x1, #32
    91d0:	eb00003f 	cmp	x1, x0
    91d4:	54000162 	b.cs	9200 <fwp_hof0.constprop.0+0xfd0>  // b.hs, b.nlast
    91d8:	8b010273 	add	x19, x19, x1
    91dc:	39400260 	ldrb	w0, [x19]
    91e0:	34000100 	cbz	w0, 9200 <fwp_hof0.constprop.0+0xfd0>
    91e4:	7100041f 	cmp	w0, #0x1
    91e8:	54003940 	b.eq	9910 <fwp_hof0.constprop.0+0x16e0>  // b.none
    91ec:	7103fc1f 	cmp	w0, #0xff
    91f0:	54004a80 	b.eq	9b40 <fwp_hof0.constprop.0+0x1910>  // b.none
    91f4:	51000400 	sub	w0, w0, #0x1
    91f8:	39000260 	strb	w0, [x19]
    91fc:	d503201f 	nop
    9200:	f94007e0 	ldr	x0, [sp, #8]
    9204:	b4001aa0 	cbz	x0, 9558 <fwp_hof0.constprop.0+0x1328>
    9208:	f94007e0 	ldr	x0, [sp, #8]
    920c:	f100041a 	subs	x26, x0, #0x1
    9210:	f90007fa 	str	x26, [sp, #8]
    9214:	54005986 	b.vs	9d44 <fwp_hof0.constprop.0+0x1b14>
    9218:	91174280 	add	x0, x20, #0x5d0
    921c:	aa1b03f6 	mov	x22, x27
    9220:	f949ec03 	ldr	x3, [x0, #5080]
    9224:	f949d801 	ldr	x1, [x0, #5040]
    9228:	d370bc63 	lsl	x3, x3, #16
    922c:	17fffc47 	b	8348 <fwp_hof0.constprop.0+0x118>
    9230:	f94003e4 	ldr	x4, [sp]
    9234:	f949ee62 	ldr	x2, [x19, #5080]
    9238:	aa0403e0 	mov	x0, x4
    923c:	f9400083 	ldr	x3, [x4]
    9240:	f949da61 	ldr	x1, [x19, #5040]
    9244:	d370bc42 	lsl	x2, x2, #16
    9248:	cb010087 	sub	x7, x4, x1
    924c:	b7f82de3 	tbnz	x3, #63, 9808 <fwp_hof0.constprop.0+0x15d8>
    9250:	eb0200ff 	cmp	x7, x2
    9254:	54fff962 	b.cs	9180 <fwp_hof0.constprop.0+0xf50>  // b.hs, b.nlast
    9258:	d350fce3 	lsr	x3, x7, #16
    925c:	8b030863 	add	x3, x3, x3, lsl #2
    9260:	d37df063 	lsl	x3, x3, #3
    9264:	8b0300a6 	add	x6, x5, x3
    9268:	f94010c4 	ldr	x4, [x6, #32]
    926c:	b4fff8a4 	cbz	x4, 9180 <fwp_hof0.constprop.0+0xf50>
    9270:	386368a3 	ldrb	w3, [x5, x3]
    9274:	7100087f 	cmp	w3, #0x2
    9278:	540039c0 	b.eq	99b0 <fwp_hof0.constprop.0+0x1780>  // b.none
    927c:	7100047f 	cmp	w3, #0x1
    9280:	54fff801 	b.ne	9180 <fwp_hof0.constprop.0+0xf50>  // b.any
    9284:	29430cc5 	ldp	w5, w3, [x6, #24]
    9288:	92403ce0 	and	x0, x7, #0xffff
    928c:	9b057c00 	mul	x0, x0, x5
    9290:	d360fc00 	lsr	x0, x0, #32
    9294:	eb03001f 	cmp	x0, x3
    9298:	54fff742 	b.cs	9180 <fwp_hof0.constprop.0+0xf50>  // b.hs, b.nlast
    929c:	8b000084 	add	x4, x4, x0
    92a0:	39400080 	ldrb	w0, [x4]
    92a4:	7100041f 	cmp	w0, #0x1
    92a8:	54fff6c1 	b.ne	9180 <fwp_hof0.constprop.0+0xf50>  // b.any
    92ac:	f94003e0 	ldr	x0, [sp]
    92b0:	97ffee10 	bl	4af0 <fwp_mem_free>
    92b4:	91174280 	add	x0, x20, #0x5d0
    92b8:	f949ec02 	ldr	x2, [x0, #5080]
    92bc:	f949d801 	ldr	x1, [x0, #5040]
    92c0:	d370bc42 	lsl	x2, x2, #16
    92c4:	17ffffaf 	b	9180 <fwp_hof0.constprop.0+0xf50>
    92c8:	aa1703e0 	mov	x0, x23
    92cc:	97ffed69 	bl	4870 <fwp_rc_forget_slot>
    92d0:	17ffff69 	b	9074 <fwp_hof0.constprop.0+0xe44>
    92d4:	72003c3f 	tst	w1, #0xffff
    92d8:	54ffed01 	b.ne	9078 <fwp_hof0.constprop.0+0xe48>  // b.any
    92dc:	17ffff63 	b	9068 <fwp_hof0.constprop.0+0xe38>
    92e0:	72003c3f 	tst	w1, #0xffff
    92e4:	54ffd780 	b.eq	8dd4 <fwp_hof0.constprop.0+0xba4>  // b.none
    92e8:	b4001096 	cbz	x22, 94f8 <fwp_hof0.constprop.0+0x12c8>
    92ec:	aa1603f3 	mov	x19, x22
    92f0:	d2800018 	mov	x24, #0x0                   	// #0
    92f4:	d503201f 	nop
    92f8:	f9400a73 	ldr	x19, [x19, #16]
    92fc:	aa1803e0 	mov	x0, x24
    9300:	91000718 	add	x24, x24, #0x1
    9304:	b5ffffb3 	cbnz	x19, 92f8 <fwp_hof0.constprop.0+0x10c8>
    9308:	f9001be5 	str	x5, [sp, #48]
    930c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9310:	eb01031f 	cmp	x24, x1
    9314:	54004dc8 	b.hi	9ccc <fwp_hof0.constprop.0+0x1a9c>  // b.pmore
    9318:	91000800 	add	x0, x0, #0x2
    931c:	52800041 	mov	w1, #0x2                   	// #2
    9320:	d37df000 	lsl	x0, x0, #3
    9324:	97ffef13 	bl	4f70 <fwp_heap_alloc>
    9328:	f9401be5 	ldr	x5, [sp, #48]
    932c:	aa0003fc 	mov	x28, x0
    9330:	aa1603e1 	mov	x1, x22
    9334:	eb05031f 	cmp	x24, x5
    9338:	9a859305 	csel	x5, x24, x5, ls	// ls = plast
    933c:	d503201f 	nop
    9340:	f9400420 	ldr	x0, [x1, #8]
    9344:	f8337b80 	str	x0, [x28, x19, lsl #3]
    9348:	91000673 	add	x19, x19, #0x1
    934c:	f9400821 	ldr	x1, [x1, #16]
    9350:	b5ffff81 	cbnz	x1, 9340 <fwp_hof0.constprop.0+0x1110>
    9354:	b4000da5 	cbz	x5, 9508 <fwp_hof0.constprop.0+0x12d8>
    9358:	f9400360 	ldr	x0, [x27]
    935c:	b90033ff 	str	wzr, [sp, #48]
    9360:	17fffea5 	b	8df4 <fwp_hof0.constprop.0+0xbc4>
    9364:	d53bd040 	mrs	x0, tpidr_el0
    9368:	91400000 	add	x0, x0, #0x0, lsl #12
    936c:	91004000 	add	x0, x0, #0x10
    9370:	f9400000 	ldr	x0, [x0]
    9374:	b4002900 	cbz	x0, 9894 <fwp_hof0.constprop.0+0x1664>
    9378:	f94017e1 	ldr	x1, [sp, #40]
    937c:	97ffe95a 	bl	38e4 <fwp_closure_drop_push>
    9380:	b5ff87f6 	cbnz	x22, 847c <fwp_hof0.constprop.0+0x24c>
    9384:	9101c2b7 	add	x23, x21, #0x70
    9388:	52800000 	mov	w0, #0x0                   	// #0
    938c:	97ffe8b9 	bl	3670 <descent_phase_step>
    9390:	d2800013 	mov	x19, #0x0                   	// #0
    9394:	b94346e0 	ldr	w0, [x23, #836]
    9398:	35ff88e0 	cbnz	w0, 84b4 <fwp_hof0.constprop.0+0x284>
    939c:	d503201f 	nop
    93a0:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x20>
    93a4:	91044000 	add	x0, x0, #0x110
    93a8:	94000f2a 	bl	d050 <atexit>
    93ac:	35ffc6a0 	cbnz	w0, 8c80 <fwp_hof0.constprop.0+0xa50>
    93b0:	52800020 	mov	w0, #0x1                   	// #1
    93b4:	b90346e0 	str	w0, [x23, #836]
    93b8:	9101c2a0 	add	x0, x21, #0x70
    93bc:	f9404817 	ldr	x23, [x0, #144]
    93c0:	f9407418 	ldr	x24, [x0, #232]
    93c4:	eb17031f 	cmp	x24, x23
    93c8:	54ff880b 	b.lt	84c8 <fwp_hof0.constprop.0+0x298>  // b.tstop
    93cc:	d503201f 	nop
    93d0:	eb17031f 	cmp	x24, x23
    93d4:	54ff8980 	b.eq	8504 <fwp_hof0.constprop.0+0x2d4>  // b.none
    93d8:	f9403abb 	ldr	x27, [x21, #112]
    93dc:	8b180717 	add	x23, x24, x24, lsl #1
    93e0:	90000020 	adrp	x0, d000 <__modti3+0x320>
    93e4:	910dc000 	add	x0, x0, #0x370
    93e8:	8b170b17 	add	x23, x24, x23, lsl #2
    93ec:	8b170f77 	add	x23, x27, x23, lsl #3
    93f0:	f90032ff 	str	xzr, [x23, #96]
    93f4:	97ffe5ab 	bl	2aa0 <getenv@plt>
    93f8:	b5ff8da0 	cbnz	x0, 85ac <fwp_hof0.constprop.0+0x37c>
    93fc:	9101c2a0 	add	x0, x21, #0x70
    9400:	f9406801 	ldr	x1, [x0, #208]
    9404:	b4ff8de1 	cbz	x1, 85c0 <fwp_hof0.constprop.0+0x390>
    9408:	3cc98002 	ldur	q2, [x0, #152]
    940c:	91026001 	add	x1, x0, #0x98
    9410:	3cca8001 	ldur	q1, [x0, #168]
    9414:	f900681f 	str	xzr, [x0, #208]
    9418:	4f000400 	movi	v0.4s, #0x0
    941c:	ad0106e2 	stp	q2, q1, [x23, #32]
    9420:	a94b8002 	ldp	x2, x0, [x0, #184]
    9424:	f9000ee0 	str	x0, [x23, #24]
    9428:	f9401820 	ldr	x0, [x1, #48]
    942c:	f90022e2 	str	x2, [x23, #64]
    9430:	f90026e0 	str	x0, [x23, #72]
    9434:	ad000020 	stp	q0, q0, [x1]
    9438:	3d800820 	str	q0, [x1, #32]
    943c:	f900183f 	str	xzr, [x1, #48]
    9440:	17fffc60 	b	85c0 <fwp_hof0.constprop.0+0x390>
    9444:	72003c1f 	tst	w0, #0xffff
    9448:	54ffbc80 	b.eq	8bd8 <fwp_hof0.constprop.0+0x9a8>  // b.none
    944c:	d503201f 	nop
    9450:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9454:	eb00031f 	cmp	x24, x0
    9458:	540044c8 	b.hi	9cf0 <fwp_hof0.constprop.0+0x1ac0>  // b.pmore
    945c:	91000700 	add	x0, x24, #0x1
    9460:	52800021 	mov	w1, #0x1                   	// #1
    9464:	d37df000 	lsl	x0, x0, #3
    9468:	97ffeec2 	bl	4f70 <fwp_heap_alloc>
    946c:	91174282 	add	x2, x20, #0x5d0
    9470:	f9000018 	str	x24, [x0]
    9474:	aa0003fb 	mov	x27, x0
    9478:	f90003fb 	str	x27, [sp]
    947c:	f949d841 	ldr	x1, [x2, #5040]
    9480:	f949ec40 	ldr	x0, [x2, #5080]
    9484:	cb010361 	sub	x1, x27, x1
    9488:	eb00403f 	cmp	x1, x0, lsl #16
    948c:	54000322 	b.cs	94f0 <fwp_hof0.constprop.0+0x12c0>  // b.hs, b.nlast
    9490:	d350fc20 	lsr	x0, x1, #16
    9494:	f949fc44 	ldr	x4, [x2, #5112]
    9498:	8b000800 	add	x0, x0, x0, lsl #2
    949c:	d37df002 	lsl	x2, x0, #3
    94a0:	8b020083 	add	x3, x4, x2
    94a4:	f9401077 	ldr	x23, [x3, #32]
    94a8:	b4000257 	cbz	x23, 94f0 <fwp_hof0.constprop.0+0x12c0>
    94ac:	38626882 	ldrb	w2, [x4, x2]
    94b0:	7100085f 	cmp	w2, #0x2
    94b4:	54002840 	b.eq	99bc <fwp_hof0.constprop.0+0x178c>  // b.none
    94b8:	7100045f 	cmp	w2, #0x1
    94bc:	540001a1 	b.ne	94f0 <fwp_hof0.constprop.0+0x12c0>  // b.any
    94c0:	29430864 	ldp	w4, w2, [x3, #24]
    94c4:	92403c21 	and	x1, x1, #0xffff
    94c8:	9b047c21 	mul	x1, x1, x4
    94cc:	d360fc21 	lsr	x1, x1, #32
    94d0:	eb02003f 	cmp	x1, x2
    94d4:	540000e2 	b.cs	94f0 <fwp_hof0.constprop.0+0x12c0>  // b.hs, b.nlast
    94d8:	8b0102f7 	add	x23, x23, x1
    94dc:	394002e1 	ldrb	w1, [x23]
    94e0:	7103fc3f 	cmp	w1, #0xff
    94e4:	54002740 	b.eq	99cc <fwp_hof0.constprop.0+0x179c>  // b.none
    94e8:	52800021 	mov	w1, #0x1                   	// #1
    94ec:	390002e1 	strb	w1, [x23]
    94f0:	aa1303e0 	mov	x0, x19
    94f4:	17fffdbf 	b	8bf0 <fwp_hof0.constprop.0+0x9c0>
    94f8:	52800041 	mov	w1, #0x2                   	// #2
    94fc:	d2800100 	mov	x0, #0x8                   	// #8
    9500:	97ffee9c 	bl	4f70 <fwp_heap_alloc>
    9504:	aa0003fc 	mov	x28, x0
    9508:	d280001b 	mov	x27, #0x0                   	// #0
    950c:	17fffef3 	b	90d8 <fwp_hof0.constprop.0+0xea8>
    9510:	52800041 	mov	w1, #0x2                   	// #2
    9514:	d2800100 	mov	x0, #0x8                   	// #8
    9518:	97ffee96 	bl	4f70 <fwp_heap_alloc>
    951c:	aa0003f8 	mov	x24, x0
    9520:	91174280 	add	x0, x20, #0x5d0
    9524:	aa1803fb 	mov	x27, x24
    9528:	f900031f 	str	xzr, [x24]
    952c:	f949d801 	ldr	x1, [x0, #5040]
    9530:	f949ec00 	ldr	x0, [x0, #5080]
    9534:	cb010301 	sub	x1, x24, x1
    9538:	eb00403f 	cmp	x1, x0, lsl #16
    953c:	540010a2 	b.cs	9750 <fwp_hof0.constprop.0+0x1520>  // b.hs, b.nlast
    9540:	d2800017 	mov	x23, #0x0                   	// #0
    9544:	17fffc65 	b	86d8 <fwp_hof0.constprop.0+0x4a8>
    9548:	f9001fe0 	str	x0, [sp, #56]
    954c:	97ffecc9 	bl	4870 <fwp_rc_forget_slot>
    9550:	f9401fe0 	ldr	x0, [sp, #56]
    9554:	17fffe7d 	b	8f48 <fwp_hof0.constprop.0+0xd18>
    9558:	f9400be0 	ldr	x0, [sp, #16]
    955c:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xed60>
    9560:	910aa042 	add	x2, x2, #0x2a8
    9564:	aa1b03e1 	mov	x1, x27
    9568:	91014042 	add	x2, x2, #0x50
    956c:	52800023 	mov	w3, #0x1                   	// #1
    9570:	a9097fff 	stp	xzr, xzr, [sp, #144]
    9574:	f90053ff 	str	xzr, [sp, #160]
    9578:	97fff732 	bl	7240 <fwp_write>
    957c:	a9495ff6 	ldp	x22, x23, [sp, #144]
    9580:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9584:	912f4000 	add	x0, x0, #0xbd0
    9588:	f10002df 	cmp	x22, #0x0
    958c:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9590:	b1002aff 	cmn	x23, #0xa
    9594:	54003a88 	b.hi	9ce4 <fwp_hof0.constprop.0+0x1ab4>  // b.pmore
    9598:	910026e0 	add	x0, x23, #0x9
    959c:	52800021 	mov	w1, #0x1                   	// #1
    95a0:	97ffee74 	bl	4f70 <fwp_heap_alloc>
    95a4:	aa0003f8 	mov	x24, x0
    95a8:	aa0003f3 	mov	x19, x0
    95ac:	aa1703e2 	mov	x2, x23
    95b0:	aa1603e1 	mov	x1, x22
    95b4:	f8008717 	str	x23, [x24], #8
    95b8:	8b170277 	add	x23, x19, x23
    95bc:	aa1803e0 	mov	x0, x24
    95c0:	97ffe468 	bl	2760 <memcpy@plt>
    95c4:	390022ff 	strb	wzr, [x23, #8]
    95c8:	f9404be0 	ldr	x0, [sp, #144]
    95cc:	97ffe501 	bl	29d0 <free@plt>
    95d0:	91174281 	add	x1, x20, #0x5d0
    95d4:	f949d822 	ldr	x2, [x1, #5040]
    95d8:	f949ec20 	ldr	x0, [x1, #5080]
    95dc:	cb020262 	sub	x2, x19, x2
    95e0:	eb00405f 	cmp	x2, x0, lsl #16
    95e4:	54000322 	b.cs	9648 <fwp_hof0.constprop.0+0x1418>  // b.hs, b.nlast
    95e8:	d350fc40 	lsr	x0, x2, #16
    95ec:	f949fc23 	ldr	x3, [x1, #5112]
    95f0:	8b000800 	add	x0, x0, x0, lsl #2
    95f4:	d37df001 	lsl	x1, x0, #3
    95f8:	8b010060 	add	x0, x3, x1
    95fc:	f9401016 	ldr	x22, [x0, #32]
    9600:	b4000256 	cbz	x22, 9648 <fwp_hof0.constprop.0+0x1418>
    9604:	38616861 	ldrb	w1, [x3, x1]
    9608:	7100083f 	cmp	w1, #0x2
    960c:	54002cc0 	b.eq	9ba4 <fwp_hof0.constprop.0+0x1974>  // b.none
    9610:	7100043f 	cmp	w1, #0x1
    9614:	540001a1 	b.ne	9648 <fwp_hof0.constprop.0+0x1418>  // b.any
    9618:	29430003 	ldp	w3, w0, [x0, #24]
    961c:	92403c41 	and	x1, x2, #0xffff
    9620:	9b037c21 	mul	x1, x1, x3
    9624:	d360fc21 	lsr	x1, x1, #32
    9628:	eb00003f 	cmp	x1, x0
    962c:	540000e2 	b.cs	9648 <fwp_hof0.constprop.0+0x1418>  // b.hs, b.nlast
    9630:	8b0102d6 	add	x22, x22, x1
    9634:	394002c0 	ldrb	w0, [x22]
    9638:	7103fc1f 	cmp	w0, #0xff
    963c:	54002be0 	b.eq	9bb8 <fwp_hof0.constprop.0+0x1988>  // b.none
    9640:	52800020 	mov	w0, #0x1                   	// #1
    9644:	390002c0 	strb	w0, [x22]
    9648:	9101c2b6 	add	x22, x21, #0x70
    964c:	aa1b03e0 	mov	x0, x27
    9650:	97fff168 	bl	5bf0 <fwp_drop0>
    9654:	f9400262 	ldr	x2, [x19]
    9658:	d2800021 	mov	x1, #0x1                   	// #1
    965c:	f94006c3 	ldr	x3, [x22, #8]
    9660:	aa1803e0 	mov	x0, x24
    9664:	97ffe4eb 	bl	2a10 <fwrite@plt>
    9668:	f94006c1 	ldr	x1, [x22, #8]
    966c:	52800140 	mov	w0, #0xa                   	// #10
    9670:	97ffe470 	bl	2830 <fputc@plt>
    9674:	91174281 	add	x1, x20, #0x5d0
    9678:	f949d822 	ldr	x2, [x1, #5040]
    967c:	f949ec20 	ldr	x0, [x1, #5080]
    9680:	cb020262 	sub	x2, x19, x2
    9684:	eb00405f 	cmp	x2, x0, lsl #16
    9688:	54000382 	b.cs	96f8 <fwp_hof0.constprop.0+0x14c8>  // b.hs, b.nlast
    968c:	d350fc40 	lsr	x0, x2, #16
    9690:	f949fc23 	ldr	x3, [x1, #5112]
    9694:	8b000800 	add	x0, x0, x0, lsl #2
    9698:	d37df001 	lsl	x1, x0, #3
    969c:	8b010060 	add	x0, x3, x1
    96a0:	f9401016 	ldr	x22, [x0, #32]
    96a4:	b40002b6 	cbz	x22, 96f8 <fwp_hof0.constprop.0+0x14c8>
    96a8:	38616861 	ldrb	w1, [x3, x1]
    96ac:	7100083f 	cmp	w1, #0x2
    96b0:	54002740 	b.eq	9b98 <fwp_hof0.constprop.0+0x1968>  // b.none
    96b4:	7100043f 	cmp	w1, #0x1
    96b8:	54000201 	b.ne	96f8 <fwp_hof0.constprop.0+0x14c8>  // b.any
    96bc:	29430003 	ldp	w3, w0, [x0, #24]
    96c0:	92403c41 	and	x1, x2, #0xffff
    96c4:	9b037c21 	mul	x1, x1, x3
    96c8:	d360fc21 	lsr	x1, x1, #32
    96cc:	eb00003f 	cmp	x1, x0
    96d0:	54000142 	b.cs	96f8 <fwp_hof0.constprop.0+0x14c8>  // b.hs, b.nlast
    96d4:	8b0102d6 	add	x22, x22, x1
    96d8:	394002c0 	ldrb	w0, [x22]
    96dc:	340000e0 	cbz	w0, 96f8 <fwp_hof0.constprop.0+0x14c8>
    96e0:	7100041f 	cmp	w0, #0x1
    96e4:	54001b20 	b.eq	9a48 <fwp_hof0.constprop.0+0x1818>  // b.none
    96e8:	7103fc1f 	cmp	w0, #0xff
    96ec:	54002b20 	b.eq	9c50 <fwp_hof0.constprop.0+0x1a20>  // b.none
    96f0:	51000400 	sub	w0, w0, #0x1
    96f4:	390002c0 	strb	w0, [x22]
    96f8:	f94027e0 	ldr	x0, [sp, #72]
    96fc:	f9400800 	ldr	x0, [x0, #16]
    9700:	f90027e0 	str	x0, [sp, #72]
    9704:	b5ff5d00 	cbnz	x0, 82a4 <fwp_hof0.constprop.0+0x74>
    9708:	a94f53f3 	ldp	x19, x20, [sp, #240]
    970c:	a9505bf5 	ldp	x21, x22, [sp, #256]
    9710:	a95163f7 	ldp	x23, x24, [sp, #272]
    9714:	a9526bf9 	ldp	x25, x26, [sp, #288]
    9718:	a95373fb 	ldp	x27, x28, [sp, #304]
    971c:	fd40a3e8 	ldr	d8, [sp, #320]
    9720:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9724:	f947f400 	ldr	x0, [x0, #4072]
    9728:	f9406fe2 	ldr	x2, [sp, #216]
    972c:	f9400001 	ldr	x1, [x0]
    9730:	eb010042 	subs	x2, x2, x1
    9734:	d2800001 	mov	x1, #0x0                   	// #0
    9738:	54002f81 	b.ne	9d28 <fwp_hof0.constprop.0+0x1af8>  // b.any
    973c:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    9740:	d2800000 	mov	x0, #0x0                   	// #0
    9744:	910543ff 	add	sp, sp, #0x150
    9748:	d65f03c0 	ret
    974c:	b5ff7fb7 	cbnz	x23, 8740 <fwp_hof0.constprop.0+0x510>
    9750:	d280001c 	mov	x28, #0x0                   	// #0
    9754:	17fffc22 	b	87dc <fwp_hof0.constprop.0+0x5ac>
    9758:	72003c3f 	tst	w1, #0xffff
    975c:	54ff88a1 	b.ne	8870 <fwp_hof0.constprop.0+0x640>  // b.any
    9760:	17fffc3c 	b	8850 <fwp_hof0.constprop.0+0x620>
    9764:	72003c7f 	tst	w3, #0xffff
    9768:	54ffda61 	b.ne	92b4 <fwp_hof0.constprop.0+0x1084>  // b.any
    976c:	17fffe78 	b	914c <fwp_hof0.constprop.0+0xf1c>
    9770:	f940077b 	ldr	x27, [x27, #8]
    9774:	eb02007f 	cmp	x3, x2
    9778:	540003a9 	b.ls	97ec <fwp_hof0.constprop.0+0x15bc>  // b.plast
    977c:	d350fc46 	lsr	x6, x2, #16
    9780:	8b0608c6 	add	x6, x6, x6, lsl #2
    9784:	d37df0c6 	lsl	x6, x6, #3
    9788:	8b060088 	add	x8, x4, x6
    978c:	f9401107 	ldr	x7, [x8, #32]
    9790:	b40002e7 	cbz	x7, 97ec <fwp_hof0.constprop.0+0x15bc>
    9794:	38666884 	ldrb	w4, [x4, x6]
    9798:	7100089f 	cmp	w4, #0x2
    979c:	540014a0 	b.eq	9a30 <fwp_hof0.constprop.0+0x1800>  // b.none
    97a0:	7100049f 	cmp	w4, #0x1
    97a4:	54000241 	b.ne	97ec <fwp_hof0.constprop.0+0x15bc>  // b.any
    97a8:	29431106 	ldp	w6, w4, [x8, #24]
    97ac:	92403c42 	and	x2, x2, #0xffff
    97b0:	9b067c42 	mul	x2, x2, x6
    97b4:	d360fc42 	lsr	x2, x2, #32
    97b8:	eb04005f 	cmp	x2, x4
    97bc:	54000182 	b.cs	97ec <fwp_hof0.constprop.0+0x15bc>  // b.hs, b.nlast
    97c0:	8b0200e7 	add	x7, x7, x2
    97c4:	394000e2 	ldrb	w2, [x7]
    97c8:	7100045f 	cmp	w2, #0x1
    97cc:	54000101 	b.ne	97ec <fwp_hof0.constprop.0+0x15bc>  // b.any
    97d0:	f90003e5 	str	x5, [sp]
    97d4:	97ffecc7 	bl	4af0 <fwp_mem_free>
    97d8:	91174280 	add	x0, x20, #0x5d0
    97dc:	f94003e5 	ldr	x5, [sp]
    97e0:	f949ec03 	ldr	x3, [x0, #5080]
    97e4:	f949d801 	ldr	x1, [x0, #5040]
    97e8:	d370bc63 	lsl	x3, x3, #16
    97ec:	cb010361 	sub	x1, x27, x1
    97f0:	eb03003f 	cmp	x1, x3
    97f4:	54ff8083 	b.cc	8804 <fwp_hof0.constprop.0+0x5d4>  // b.lo, b.ul, b.last
    97f8:	17fffc1e 	b	8870 <fwp_hof0.constprop.0+0x640>
    97fc:	72003c3f 	tst	w1, #0xffff
    9800:	54ffd001 	b.ne	9200 <fwp_hof0.constprop.0+0xfd0>  // b.any
    9804:	17fffe76 	b	91dc <fwp_hof0.constprop.0+0xfac>
    9808:	f9400483 	ldr	x3, [x4, #8]
    980c:	f90003e3 	str	x3, [sp]
    9810:	eb0200ff 	cmp	x7, x2
    9814:	54000362 	b.cs	9880 <fwp_hof0.constprop.0+0x1650>  // b.hs, b.nlast
    9818:	d350fce3 	lsr	x3, x7, #16
    981c:	8b030863 	add	x3, x3, x3, lsl #2
    9820:	d37df063 	lsl	x3, x3, #3
    9824:	8b0300a6 	add	x6, x5, x3
    9828:	f94010c4 	ldr	x4, [x6, #32]
    982c:	b40002a4 	cbz	x4, 9880 <fwp_hof0.constprop.0+0x1650>
    9830:	386368a3 	ldrb	w3, [x5, x3]
    9834:	7100087f 	cmp	w3, #0x2
    9838:	54001020 	b.eq	9a3c <fwp_hof0.constprop.0+0x180c>  // b.none
    983c:	7100047f 	cmp	w3, #0x1
    9840:	54000201 	b.ne	9880 <fwp_hof0.constprop.0+0x1650>  // b.any
    9844:	294314c8 	ldp	w8, w5, [x6, #24]
    9848:	92403ce3 	and	x3, x7, #0xffff
    984c:	9b087c63 	mul	x3, x3, x8
    9850:	d360fc63 	lsr	x3, x3, #32
    9854:	eb05007f 	cmp	x3, x5
    9858:	54000142 	b.cs	9880 <fwp_hof0.constprop.0+0x1650>  // b.hs, b.nlast
    985c:	8b030084 	add	x4, x4, x3
    9860:	39400083 	ldrb	w3, [x4]
    9864:	7100047f 	cmp	w3, #0x1
    9868:	540000c1 	b.ne	9880 <fwp_hof0.constprop.0+0x1650>  // b.any
    986c:	97ffeca1 	bl	4af0 <fwp_mem_free>
    9870:	91174280 	add	x0, x20, #0x5d0
    9874:	f949ec02 	ldr	x2, [x0, #5080]
    9878:	f949d801 	ldr	x1, [x0, #5040]
    987c:	d370bc42 	lsl	x2, x2, #16
    9880:	f94003e0 	ldr	x0, [sp]
    9884:	cb010003 	sub	x3, x0, x1
    9888:	eb03005f 	cmp	x2, x3
    988c:	54ffc3a8 	b.hi	9100 <fwp_hof0.constprop.0+0xed0>  // b.pmore
    9890:	17fffe3c 	b	9180 <fwp_hof0.constprop.0+0xf50>
    9894:	f94017e0 	ldr	x0, [sp, #40]
    9898:	97ffe882 	bl	3aa0 <fwp_closure_drop.part.0>
    989c:	17fffaf7 	b	8478 <fwp_hof0.constprop.0+0x248>
    98a0:	72003c3f 	tst	w1, #0xffff
    98a4:	54ff74c1 	b.ne	873c <fwp_hof0.constprop.0+0x50c>  // b.any
    98a8:	39400380 	ldrb	w0, [x28]
    98ac:	7103fc1f 	cmp	w0, #0xff
    98b0:	54ff7421 	b.ne	8734 <fwp_hof0.constprop.0+0x504>  // b.any
    98b4:	aa1c03e0 	mov	x0, x28
    98b8:	97ffebee 	bl	4870 <fwp_rc_forget_slot>
    98bc:	17fffb9e 	b	8734 <fwp_hof0.constprop.0+0x504>
    98c0:	72003c3f 	tst	w1, #0xffff
    98c4:	54ff5b01 	b.ne	8424 <fwp_hof0.constprop.0+0x1f4>  // b.any
    98c8:	aa1303e0 	mov	x0, x19
    98cc:	17fffac3 	b	83d8 <fwp_hof0.constprop.0+0x1a8>
    98d0:	72003c3f 	tst	w1, #0xffff
    98d4:	54ff5d21 	b.ne	8478 <fwp_hof0.constprop.0+0x248>  // b.any
    98d8:	17fffadf 	b	8454 <fwp_hof0.constprop.0+0x224>
    98dc:	aa1903fc 	mov	x28, x25
    98e0:	17fffc1a 	b	8948 <fwp_hof0.constprop.0+0x718>
    98e4:	72003c3f 	tst	w1, #0xffff
    98e8:	54ff9301 	b.ne	8b48 <fwp_hof0.constprop.0+0x918>  // b.any
    98ec:	394002e0 	ldrb	w0, [x23]
    98f0:	7103fc1f 	cmp	w0, #0xff
    98f4:	54ff9261 	b.ne	8b40 <fwp_hof0.constprop.0+0x910>  // b.any
    98f8:	aa1703e0 	mov	x0, x23
    98fc:	97ffebdd 	bl	4870 <fwp_rc_forget_slot>
    9900:	17fffc90 	b	8b40 <fwp_hof0.constprop.0+0x910>
    9904:	72003c5f 	tst	w2, #0xffff
    9908:	54ff7b41 	b.ne	8870 <fwp_hof0.constprop.0+0x640>  // b.any
    990c:	17fffd04 	b	8d1c <fwp_hof0.constprop.0+0xaec>
    9910:	91174280 	add	x0, x20, #0x5d0
    9914:	f9400ad3 	ldr	x19, [x22, #16]
    9918:	f949ec04 	ldr	x4, [x0, #5080]
    991c:	f949d801 	ldr	x1, [x0, #5040]
    9920:	d370bc84 	lsl	x4, x4, #16
    9924:	cb0102c0 	sub	x0, x22, x1
    9928:	eb04001f 	cmp	x0, x4
    992c:	54000382 	b.cs	999c <fwp_hof0.constprop.0+0x176c>  // b.hs, b.nlast
    9930:	d350fc02 	lsr	x2, x0, #16
    9934:	8b020842 	add	x2, x2, x2, lsl #2
    9938:	d37df042 	lsl	x2, x2, #3
    993c:	8b020066 	add	x6, x3, x2
    9940:	f94010c5 	ldr	x5, [x6, #32]
    9944:	b40002c5 	cbz	x5, 999c <fwp_hof0.constprop.0+0x176c>
    9948:	38626862 	ldrb	w2, [x3, x2]
    994c:	7100085f 	cmp	w2, #0x2
    9950:	54000820 	b.eq	9a54 <fwp_hof0.constprop.0+0x1824>  // b.none
    9954:	7100045f 	cmp	w2, #0x1
    9958:	54000221 	b.ne	999c <fwp_hof0.constprop.0+0x176c>  // b.any
    995c:	294308c3 	ldp	w3, w2, [x6, #24]
    9960:	92403c00 	and	x0, x0, #0xffff
    9964:	9b037c00 	mul	x0, x0, x3
    9968:	d360fc00 	lsr	x0, x0, #32
    996c:	eb02001f 	cmp	x0, x2
    9970:	54000162 	b.cs	999c <fwp_hof0.constprop.0+0x176c>  // b.hs, b.nlast
    9974:	8b0000a5 	add	x5, x5, x0
    9978:	394000a0 	ldrb	w0, [x5]
    997c:	7100041f 	cmp	w0, #0x1
    9980:	540000e1 	b.ne	999c <fwp_hof0.constprop.0+0x176c>  // b.any
    9984:	aa1603e0 	mov	x0, x22
    9988:	97ffec5a 	bl	4af0 <fwp_mem_free>
    998c:	91174280 	add	x0, x20, #0x5d0
    9990:	f949ec04 	ldr	x4, [x0, #5080]
    9994:	f949d801 	ldr	x1, [x0, #5040]
    9998:	d370bc84 	lsl	x4, x4, #16
    999c:	cb010261 	sub	x1, x19, x1
    99a0:	eb01009f 	cmp	x4, x1
    99a4:	54ffc2e9 	b.ls	9200 <fwp_hof0.constprop.0+0xfd0>  // b.plast
    99a8:	aa1303f6 	mov	x22, x19
    99ac:	17fffdf9 	b	9190 <fwp_hof0.constprop.0+0xf60>
    99b0:	72003cff 	tst	w7, #0xffff
    99b4:	54ffbe61 	b.ne	9180 <fwp_hof0.constprop.0+0xf50>  // b.any
    99b8:	17fffe3a 	b	92a0 <fwp_hof0.constprop.0+0x1070>
    99bc:	72003c3f 	tst	w1, #0xffff
    99c0:	54ffd8e0 	b.eq	94dc <fwp_hof0.constprop.0+0x12ac>  // b.none
    99c4:	aa1303e0 	mov	x0, x19
    99c8:	17fffc8a 	b	8bf0 <fwp_hof0.constprop.0+0x9c0>
    99cc:	aa1703e0 	mov	x0, x23
    99d0:	97ffeba8 	bl	4870 <fwp_rc_forget_slot>
    99d4:	17fffec5 	b	94e8 <fwp_hof0.constprop.0+0x12b8>
    99d8:	aa0203e0 	mov	x0, x2
    99dc:	d2800101 	mov	x1, #0x8                   	// #8
    99e0:	f90003e2 	str	x2, [sp]
    99e4:	97ffe3c3 	bl	28f0 <calloc@plt>
    99e8:	f94003e2 	ldr	x2, [sp]
    99ec:	aa0003fa 	mov	x26, x0
    99f0:	f9401be5 	ldr	x5, [sp, #48]
    99f4:	17fffbe9 	b	8998 <fwp_hof0.constprop.0+0x768>
    99f8:	d2800d01 	mov	x1, #0x68                  	// #104
    99fc:	d280003c 	mov	x28, #0x1                   	// #1
    9a00:	17fffad1 	b	8544 <fwp_hof0.constprop.0+0x314>
    9a04:	f9400360 	ldr	x0, [x27]
    9a08:	b7ffd780 	tbnz	x0, #63, 94f8 <fwp_hof0.constprop.0+0x12c8>
    9a0c:	91174283 	add	x3, x20, #0x5d0
    9a10:	f94003e4 	ldr	x4, [sp]
    9a14:	f949d861 	ldr	x1, [x3, #5040]
    9a18:	f949ec63 	ldr	x3, [x3, #5080]
    9a1c:	cb010081 	sub	x1, x4, x1
    9a20:	eb03403f 	cmp	x1, x3, lsl #16
    9a24:	54ffd6a2 	b.cs	94f8 <fwp_hof0.constprop.0+0x12c8>  // b.hs, b.nlast
    9a28:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    9a2c:	17fffcd6 	b	8d84 <fwp_hof0.constprop.0+0xb54>
    9a30:	72003c5f 	tst	w2, #0xffff
    9a34:	54ffedc1 	b.ne	97ec <fwp_hof0.constprop.0+0x15bc>  // b.any
    9a38:	17ffff63 	b	97c4 <fwp_hof0.constprop.0+0x1594>
    9a3c:	72003cff 	tst	w7, #0xffff
    9a40:	54fff201 	b.ne	9880 <fwp_hof0.constprop.0+0x1650>  // b.any
    9a44:	17ffff87 	b	9860 <fwp_hof0.constprop.0+0x1630>
    9a48:	aa1303e0 	mov	x0, x19
    9a4c:	97ffef95 	bl	58a0 <fwp_rc_free_arr>
    9a50:	17ffff2a 	b	96f8 <fwp_hof0.constprop.0+0x14c8>
    9a54:	72003c1f 	tst	w0, #0xffff
    9a58:	54fffa21 	b.ne	999c <fwp_hof0.constprop.0+0x176c>  // b.any
    9a5c:	17ffffc7 	b	9978 <fwp_hof0.constprop.0+0x1748>
    9a60:	72003c9f 	tst	w4, #0xffff
    9a64:	54ff46c1 	b.ne	833c <fwp_hof0.constprop.0+0x10c>  // b.any
    9a68:	17fffa2a 	b	8310 <fwp_hof0.constprop.0+0xe0>
    9a6c:	ca584700 	eor	x0, x24, x24, lsr #17
    9a70:	91174281 	add	x1, x20, #0x5d0
    9a74:	ca402400 	eor	x0, x0, x0, lsr #9
    9a78:	8b200c20 	add	x0, x1, w0, uxtb #3
    9a7c:	f94a2400 	ldr	x0, [x0, #5192]
    9a80:	b5000080 	cbnz	x0, 9a90 <fwp_hof0.constprop.0+0x1860>
    9a84:	14000012 	b	9acc <fwp_hof0.constprop.0+0x189c>
    9a88:	f9400800 	ldr	x0, [x0, #16]
    9a8c:	b4000200 	cbz	x0, 9acc <fwp_hof0.constprop.0+0x189c>
    9a90:	f9400001 	ldr	x1, [x0]
    9a94:	eb18003f 	cmp	x1, x24
    9a98:	54ffff81 	b.ne	9a88 <fwp_hof0.constprop.0+0x1858>  // b.any
    9a9c:	f9400401 	ldr	x1, [x0, #8]
    9aa0:	d1000421 	sub	x1, x1, #0x1
    9aa4:	f9000401 	str	x1, [x0, #8]
    9aa8:	f103f83f 	cmp	x1, #0xfe
    9aac:	54ff6e21 	b.ne	8870 <fwp_hof0.constprop.0+0x640>  // b.any
    9ab0:	aa1803e0 	mov	x0, x24
    9ab4:	f90003e5 	str	x5, [sp]
    9ab8:	97ffeb6e 	bl	4870 <fwp_rc_forget_slot>
    9abc:	f94003e5 	ldr	x5, [sp]
    9ac0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ac4:	39000300 	strb	w0, [x24]
    9ac8:	17fffb6a 	b	8870 <fwp_hof0.constprop.0+0x640>
    9acc:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9ad0:	910f8000 	add	x0, x0, #0x3e0
    9ad4:	97ffe76b 	bl	3880 <fwp_trap>
    9ad8:	ca584700 	eor	x0, x24, x24, lsr #17
    9adc:	91174281 	add	x1, x20, #0x5d0
    9ae0:	ca402400 	eor	x0, x0, x0, lsr #9
    9ae4:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ae8:	f94a2401 	ldr	x1, [x0, #5192]
    9aec:	b5000081 	cbnz	x1, 9afc <fwp_hof0.constprop.0+0x18cc>
    9af0:	17fffff7 	b	9acc <fwp_hof0.constprop.0+0x189c>
    9af4:	f9400821 	ldr	x1, [x1, #16]
    9af8:	b4fffea1 	cbz	x1, 9acc <fwp_hof0.constprop.0+0x189c>
    9afc:	f9400020 	ldr	x0, [x1]
    9b00:	eb18001f 	cmp	x0, x24
    9b04:	54ffff81 	b.ne	9af4 <fwp_hof0.constprop.0+0x18c4>  // b.any
    9b08:	f9400420 	ldr	x0, [x1, #8]
    9b0c:	d1000400 	sub	x0, x0, #0x1
    9b10:	f9000420 	str	x0, [x1, #8]
    9b14:	f103f81f 	cmp	x0, #0xfe
    9b18:	54ffbce1 	b.ne	92b4 <fwp_hof0.constprop.0+0x1084>  // b.any
    9b1c:	aa1803e0 	mov	x0, x24
    9b20:	97ffeb54 	bl	4870 <fwp_rc_forget_slot>
    9b24:	91174280 	add	x0, x20, #0x5d0
    9b28:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9b2c:	39000301 	strb	w1, [x24]
    9b30:	f949ec02 	ldr	x2, [x0, #5080]
    9b34:	f949d801 	ldr	x1, [x0, #5040]
    9b38:	d370bc42 	lsl	x2, x2, #16
    9b3c:	17fffd91 	b	9180 <fwp_hof0.constprop.0+0xf50>
    9b40:	ca534660 	eor	x0, x19, x19, lsr #17
    9b44:	91174281 	add	x1, x20, #0x5d0
    9b48:	ca402400 	eor	x0, x0, x0, lsr #9
    9b4c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9b50:	f94a2400 	ldr	x0, [x0, #5192]
    9b54:	b5000080 	cbnz	x0, 9b64 <fwp_hof0.constprop.0+0x1934>
    9b58:	17ffffdd 	b	9acc <fwp_hof0.constprop.0+0x189c>
    9b5c:	f9400800 	ldr	x0, [x0, #16]
    9b60:	b4fffb60 	cbz	x0, 9acc <fwp_hof0.constprop.0+0x189c>
    9b64:	f9400001 	ldr	x1, [x0]
    9b68:	eb01027f 	cmp	x19, x1
    9b6c:	54ffff81 	b.ne	9b5c <fwp_hof0.constprop.0+0x192c>  // b.any
    9b70:	f9400401 	ldr	x1, [x0, #8]
    9b74:	d1000421 	sub	x1, x1, #0x1
    9b78:	f9000401 	str	x1, [x0, #8]
    9b7c:	f103f83f 	cmp	x1, #0xfe
    9b80:	54ffb401 	b.ne	9200 <fwp_hof0.constprop.0+0xfd0>  // b.any
    9b84:	aa1303e0 	mov	x0, x19
    9b88:	97ffeb3a 	bl	4870 <fwp_rc_forget_slot>
    9b8c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b90:	39000260 	strb	w0, [x19]
    9b94:	17fffd9b 	b	9200 <fwp_hof0.constprop.0+0xfd0>
    9b98:	72003c5f 	tst	w2, #0xffff
    9b9c:	54ffdae1 	b.ne	96f8 <fwp_hof0.constprop.0+0x14c8>  // b.any
    9ba0:	17fffece 	b	96d8 <fwp_hof0.constprop.0+0x14a8>
    9ba4:	72003c5f 	tst	w2, #0xffff
    9ba8:	54ffd501 	b.ne	9648 <fwp_hof0.constprop.0+0x1418>  // b.any
    9bac:	394002c0 	ldrb	w0, [x22]
    9bb0:	7103fc1f 	cmp	w0, #0xff
    9bb4:	54ffd461 	b.ne	9640 <fwp_hof0.constprop.0+0x1410>  // b.any
    9bb8:	aa1603e0 	mov	x0, x22
    9bbc:	97ffeb2d 	bl	4870 <fwp_rc_forget_slot>
    9bc0:	17fffea0 	b	9640 <fwp_hof0.constprop.0+0x1410>
    9bc4:	d280001c 	mov	x28, #0x0                   	// #0
    9bc8:	d280001b 	mov	x27, #0x0                   	// #0
    9bcc:	17fffd43 	b	90d8 <fwp_hof0.constprop.0+0xea8>
    9bd0:	ca534660 	eor	x0, x19, x19, lsr #17
    9bd4:	91174281 	add	x1, x20, #0x5d0
    9bd8:	ca402400 	eor	x0, x0, x0, lsr #9
    9bdc:	8b200c20 	add	x0, x1, w0, uxtb #3
    9be0:	f94a2400 	ldr	x0, [x0, #5192]
    9be4:	b5000080 	cbnz	x0, 9bf4 <fwp_hof0.constprop.0+0x19c4>
    9be8:	17ffffb9 	b	9acc <fwp_hof0.constprop.0+0x189c>
    9bec:	f9400800 	ldr	x0, [x0, #16]
    9bf0:	b4fff6e0 	cbz	x0, 9acc <fwp_hof0.constprop.0+0x189c>
    9bf4:	f9400001 	ldr	x1, [x0]
    9bf8:	eb13003f 	cmp	x1, x19
    9bfc:	54ffff81 	b.ne	9bec <fwp_hof0.constprop.0+0x19bc>  // b.any
    9c00:	f9400401 	ldr	x1, [x0, #8]
    9c04:	d1000421 	sub	x1, x1, #0x1
    9c08:	f9000401 	str	x1, [x0, #8]
    9c0c:	f103f83f 	cmp	x1, #0xfe
    9c10:	54ff4341 	b.ne	8478 <fwp_hof0.constprop.0+0x248>  // b.any
    9c14:	aa1303e0 	mov	x0, x19
    9c18:	97ffeb16 	bl	4870 <fwp_rc_forget_slot>
    9c1c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9c20:	39000260 	strb	w0, [x19]
    9c24:	17fffa15 	b	8478 <fwp_hof0.constprop.0+0x248>
    9c28:	97ffeacb 	bl	4754 <fwp_rc_wide_dup>
    9c2c:	17fff9f1 	b	83f0 <fwp_hof0.constprop.0+0x1c0>
    9c30:	d2800018 	mov	x24, #0x0                   	// #0
    9c34:	17fffcb3 	b	8f00 <fwp_hof0.constprop.0+0xcd0>
    9c38:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9c3c:	91130000 	add	x0, x0, #0x4c0
    9c40:	97ffe710 	bl	3880 <fwp_trap>
    9c44:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9c48:	9110a000 	add	x0, x0, #0x428
    9c4c:	97ffe70d 	bl	3880 <fwp_trap>
    9c50:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9c54:	91174281 	add	x1, x20, #0x5d0
    9c58:	ca402400 	eor	x0, x0, x0, lsr #9
    9c5c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9c60:	f94a2400 	ldr	x0, [x0, #5192]
    9c64:	b5000080 	cbnz	x0, 9c74 <fwp_hof0.constprop.0+0x1a44>
    9c68:	17ffff99 	b	9acc <fwp_hof0.constprop.0+0x189c>
    9c6c:	f9400800 	ldr	x0, [x0, #16]
    9c70:	b4fff2e0 	cbz	x0, 9acc <fwp_hof0.constprop.0+0x189c>
    9c74:	f9400001 	ldr	x1, [x0]
    9c78:	eb16003f 	cmp	x1, x22
    9c7c:	54ffff81 	b.ne	9c6c <fwp_hof0.constprop.0+0x1a3c>  // b.any
    9c80:	f9400401 	ldr	x1, [x0, #8]
    9c84:	d1000421 	sub	x1, x1, #0x1
    9c88:	f9000401 	str	x1, [x0, #8]
    9c8c:	f103f83f 	cmp	x1, #0xfe
    9c90:	54ffd341 	b.ne	96f8 <fwp_hof0.constprop.0+0x14c8>  // b.any
    9c94:	aa1603e0 	mov	x0, x22
    9c98:	97ffeaf6 	bl	4870 <fwp_rc_forget_slot>
    9c9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ca0:	390002c0 	strb	w0, [x22]
    9ca4:	17fffe95 	b	96f8 <fwp_hof0.constprop.0+0x14c8>
    9ca8:	97ffeaab 	bl	4754 <fwp_rc_wide_dup>
    9cac:	91174280 	add	x0, x20, #0x5d0
    9cb0:	f949ec03 	ldr	x3, [x0, #5080]
    9cb4:	f949d801 	ldr	x1, [x0, #5040]
    9cb8:	d370bc63 	lsl	x3, x3, #16
    9cbc:	17fff9a0 	b	833c <fwp_hof0.constprop.0+0x10c>
    9cc0:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9cc4:	911a0000 	add	x0, x0, #0x680
    9cc8:	97ffe6ee 	bl	3880 <fwp_trap>
    9ccc:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9cd0:	91148000 	add	x0, x0, #0x520
    9cd4:	97ffe6eb 	bl	3880 <fwp_trap>
    9cd8:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9cdc:	9111c000 	add	x0, x0, #0x470
    9ce0:	97ffe6e8 	bl	3880 <fwp_trap>
    9ce4:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9ce8:	911aa000 	add	x0, x0, #0x6a8
    9cec:	97ffe6e5 	bl	3880 <fwp_trap>
    9cf0:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9cf4:	9119c000 	add	x0, x0, #0x670
    9cf8:	97ffe6e2 	bl	3880 <fwp_trap>
    9cfc:	52800020 	mov	w0, #0x1                   	// #1
    9d00:	17fffbd8 	b	8c60 <fwp_hof0.constprop.0+0xa30>
    9d04:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9d08:	91190000 	add	x0, x0, #0x640
    9d0c:	97ffe6dd 	bl	3880 <fwp_trap>
    9d10:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9d14:	91188000 	add	x0, x0, #0x620
    9d18:	97ffe6da 	bl	3880 <fwp_trap>
    9d1c:	90000020 	adrp	x0, d000 <__modti3+0x320>
    9d20:	911b0000 	add	x0, x0, #0x6c0
    9d24:	97ffe6d7 	bl	3880 <fwp_trap>
    9d28:	a90f53f3 	stp	x19, x20, [sp, #240]
    9d2c:	a9105bf5 	stp	x21, x22, [sp, #256]
    9d30:	a91163f7 	stp	x23, x24, [sp, #272]
    9d34:	a9126bf9 	stp	x25, x26, [sp, #288]
    9d38:	a91373fb 	stp	x27, x28, [sp, #304]
    9d3c:	fd00a3e8 	str	d8, [sp, #320]
    9d40:	97ffe2f4 	bl	2910 <__stack_chk_fail@plt>
    9d44:	97ffe36f 	bl	2b00 <fwp_trap_overflow.constprop.0>
    9d48:	97ffe306 	bl	2960 <abort@plt>
    9d4c:	d503201f 	nop

0000000000009d50 <f0>:
    9d50:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9d54:	910003fd 	mov	x29, sp
    9d58:	a90153f3 	stp	x19, x20, [sp, #16]
    9d5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9d60:	a90363f7 	stp	x23, x24, [sp, #48]
    9d64:	a9046bf9 	stp	x25, x26, [sp, #64]
    9d68:	a90573fb 	stp	x27, x28, [sp, #80]
    9d6c:	d12183ff 	sub	sp, sp, #0x860
    9d70:	f90203ff 	str	xzr, [sp, #1024]
    9d74:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d78:	9101c005 	add	x5, x0, #0x70
    9d7c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9d80:	f947f400 	ldr	x0, [x0, #4072]
    9d84:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    9d88:	f94188a6 	ldr	x6, [x5, #784]
    9d8c:	f9400001 	ldr	x1, [x0]
    9d90:	f9042fe1 	str	x1, [sp, #2136]
    9d94:	d2800001 	mov	x1, #0x0                   	// #0
    9d98:	91174298 	add	x24, x20, #0x5d0
    9d9c:	912123f6 	add	x22, sp, #0x848
    9da0:	910023e0 	add	x0, sp, #0x8
    9da4:	910083e2 	add	x2, sp, #0x20
    9da8:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    9dac:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9db0:	91350021 	add	x1, x1, #0xd40
    9db4:	913f4084 	add	x4, x4, #0xfd0
    9db8:	d2800013 	mov	x19, #0x0                   	// #0
    9dbc:	d2800119 	mov	x25, #0x8                   	// #8
    9dc0:	d2800015 	mov	x21, #0x0                   	// #0
    9dc4:	52800037 	mov	w23, #0x1                   	// #1
    9dc8:	a90093e6 	stp	x6, x4, [sp, #8]
    9dcc:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9dd0:	a90307ff 	stp	xzr, x1, [sp, #48]
    9dd4:	f90188a0 	str	x0, [x5, #784]
    9dd8:	f100073a 	subs	x26, x25, #0x1
    9ddc:	aa1603e1 	mov	x1, x22
    9de0:	da1f02bc 	sbc	x28, x21, xzr
    9de4:	52800020 	mov	w0, #0x1                   	// #1
    9de8:	f90017fa 	str	x26, [sp, #40]
    9dec:	aa1a03f9 	mov	x25, x26
    9df0:	f90427fa 	str	x26, [sp, #2120]
    9df4:	aa1c03f5 	mov	x21, x28
    9df8:	f9042bf3 	str	x19, [sp, #2128]
    9dfc:	97ffeca2 	bl	5084 <fwp_data.part.0.constprop.0>
    9e00:	f949db02 	ldr	x2, [x24, #5040]
    9e04:	aa0003f3 	mov	x19, x0
    9e08:	f949ef00 	ldr	x0, [x24, #5080]
    9e0c:	cb020262 	sub	x2, x19, x2
    9e10:	eb00405f 	cmp	x2, x0, lsl #16
    9e14:	54000302 	b.cs	9e74 <f0+0x124>  // b.hs, b.nlast
    9e18:	d350fc40 	lsr	x0, x2, #16
    9e1c:	f949ff04 	ldr	x4, [x24, #5112]
    9e20:	8b000800 	add	x0, x0, x0, lsl #2
    9e24:	d37df001 	lsl	x1, x0, #3
    9e28:	8b010080 	add	x0, x4, x1
    9e2c:	f940101b 	ldr	x27, [x0, #32]
    9e30:	b400023b 	cbz	x27, 9e74 <f0+0x124>
    9e34:	38616881 	ldrb	w1, [x4, x1]
    9e38:	7100083f 	cmp	w1, #0x2
    9e3c:	54010f20 	b.eq	c020 <f0+0x22d0>  // b.none
    9e40:	7100043f 	cmp	w1, #0x1
    9e44:	54000181 	b.ne	9e74 <f0+0x124>  // b.any
    9e48:	29430001 	ldp	w1, w0, [x0, #24]
    9e4c:	92403c42 	and	x2, x2, #0xffff
    9e50:	9b017c42 	mul	x2, x2, x1
    9e54:	d360fc42 	lsr	x2, x2, #32
    9e58:	eb00005f 	cmp	x2, x0
    9e5c:	540000c2 	b.cs	9e74 <f0+0x124>  // b.hs, b.nlast
    9e60:	8b02037b 	add	x27, x27, x2
    9e64:	39400360 	ldrb	w0, [x27]
    9e68:	7103fc1f 	cmp	w0, #0xff
    9e6c:	54010d40 	b.eq	c014 <f0+0x22c4>  // b.none
    9e70:	39000377 	strb	w23, [x27]
    9e74:	f90013f3 	str	x19, [sp, #32]
    9e78:	aa1c035a 	orr	x26, x26, x28
    9e7c:	b5fffafa 	cbnz	x26, 9dd8 <f0+0x88>
    9e80:	90000023 	adrp	x3, d000 <__modti3+0x320>
    9e84:	910103e1 	add	x1, sp, #0x40
    9e88:	f94007e2 	ldr	x2, [sp, #8]
    9e8c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e90:	3dc3a060 	ldr	q0, [x3, #3712]
    9e94:	9101c018 	add	x24, x0, #0x70
    9e98:	52800020 	mov	w0, #0x1                   	// #1
    9e9c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9ea0:	3d8013e0 	str	q0, [sp, #64]
    9ea4:	f9018b02 	str	x2, [x24, #784]
    9ea8:	97ffec77 	bl	5084 <fwp_data.part.0.constprop.0>
    9eac:	97ffee4d 	bl	57e0 <fwp_rc_fresh>
    9eb0:	aa0003e2 	mov	x2, x0
    9eb4:	910163e1 	add	x1, sp, #0x58
    9eb8:	52800020 	mov	w0, #0x1                   	// #1
    9ebc:	a9058bf5 	stp	x21, x2, [sp, #88]
    9ec0:	97ffec71 	bl	5084 <fwp_data.part.0.constprop.0>
    9ec4:	97ffee47 	bl	57e0 <fwp_rc_fresh>
    9ec8:	aa0003e2 	mov	x2, x0
    9ecc:	9101a3e1 	add	x1, sp, #0x68
    9ed0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9ed4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9ed8:	52800020 	mov	w0, #0x1                   	// #1
    9edc:	a9068be3 	stp	x3, x2, [sp, #104]
    9ee0:	97ffec69 	bl	5084 <fwp_data.part.0.constprop.0>
    9ee4:	97ffee3f 	bl	57e0 <fwp_rc_fresh>
    9ee8:	aa0003e2 	mov	x2, x0
    9eec:	9101e3e1 	add	x1, sp, #0x78
    9ef0:	52800020 	mov	w0, #0x1                   	// #1
    9ef4:	a9078bf5 	stp	x21, x2, [sp, #120]
    9ef8:	97ffec63 	bl	5084 <fwp_data.part.0.constprop.0>
    9efc:	97ffee39 	bl	57e0 <fwp_rc_fresh>
    9f00:	aa0003e2 	mov	x2, x0
    9f04:	910223e1 	add	x1, sp, #0x88
    9f08:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9f0c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9f10:	52800020 	mov	w0, #0x1                   	// #1
    9f14:	a9088be3 	stp	x3, x2, [sp, #136]
    9f18:	97ffec5b 	bl	5084 <fwp_data.part.0.constprop.0>
    9f1c:	97ffee31 	bl	57e0 <fwp_rc_fresh>
    9f20:	aa0003e2 	mov	x2, x0
    9f24:	910263e1 	add	x1, sp, #0x98
    9f28:	52800020 	mov	w0, #0x1                   	// #1
    9f2c:	a9098bf5 	stp	x21, x2, [sp, #152]
    9f30:	97ffec55 	bl	5084 <fwp_data.part.0.constprop.0>
    9f34:	97ffee2b 	bl	57e0 <fwp_rc_fresh>
    9f38:	aa0003e2 	mov	x2, x0
    9f3c:	9102a3e1 	add	x1, sp, #0xa8
    9f40:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9f44:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9f48:	52800020 	mov	w0, #0x1                   	// #1
    9f4c:	a90a8be3 	stp	x3, x2, [sp, #168]
    9f50:	97ffec4d 	bl	5084 <fwp_data.part.0.constprop.0>
    9f54:	97ffee23 	bl	57e0 <fwp_rc_fresh>
    9f58:	aa0003e2 	mov	x2, x0
    9f5c:	9102e3e1 	add	x1, sp, #0xb8
    9f60:	52800020 	mov	w0, #0x1                   	// #1
    9f64:	a90b8bf5 	stp	x21, x2, [sp, #184]
    9f68:	97ffec47 	bl	5084 <fwp_data.part.0.constprop.0>
    9f6c:	97ffee1d 	bl	57e0 <fwp_rc_fresh>
    9f70:	aa0003e2 	mov	x2, x0
    9f74:	910323e1 	add	x1, sp, #0xc8
    9f78:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9f7c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9f80:	52800020 	mov	w0, #0x1                   	// #1
    9f84:	a90c8be3 	stp	x3, x2, [sp, #200]
    9f88:	97ffec3f 	bl	5084 <fwp_data.part.0.constprop.0>
    9f8c:	97ffee15 	bl	57e0 <fwp_rc_fresh>
    9f90:	aa0003e2 	mov	x2, x0
    9f94:	910363e1 	add	x1, sp, #0xd8
    9f98:	52800020 	mov	w0, #0x1                   	// #1
    9f9c:	a90d8bf5 	stp	x21, x2, [sp, #216]
    9fa0:	97ffec39 	bl	5084 <fwp_data.part.0.constprop.0>
    9fa4:	97ffee0f 	bl	57e0 <fwp_rc_fresh>
    9fa8:	aa0003e2 	mov	x2, x0
    9fac:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9fb0:	9103a3e1 	add	x1, sp, #0xe8
    9fb4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9fb8:	52800020 	mov	w0, #0x1                   	// #1
    9fbc:	a90e8be3 	stp	x3, x2, [sp, #232]
    9fc0:	97ffec31 	bl	5084 <fwp_data.part.0.constprop.0>
    9fc4:	97ffee07 	bl	57e0 <fwp_rc_fresh>
    9fc8:	aa0003e2 	mov	x2, x0
    9fcc:	9103e3e1 	add	x1, sp, #0xf8
    9fd0:	52800020 	mov	w0, #0x1                   	// #1
    9fd4:	a90f8bf5 	stp	x21, x2, [sp, #248]
    9fd8:	97ffec2b 	bl	5084 <fwp_data.part.0.constprop.0>
    9fdc:	91174283 	add	x3, x20, #0x5d0
    9fe0:	aa0003f5 	mov	x21, x0
    9fe4:	f949d861 	ldr	x1, [x3, #5040]
    9fe8:	f949ec60 	ldr	x0, [x3, #5080]
    9fec:	cb0102a1 	sub	x1, x21, x1
    9ff0:	eb00403f 	cmp	x1, x0, lsl #16
    9ff4:	54000322 	b.cs	a058 <f0+0x308>  // b.hs, b.nlast
    9ff8:	d350fc22 	lsr	x2, x1, #16
    9ffc:	f949fc63 	ldr	x3, [x3, #5112]
    a000:	8b020842 	add	x2, x2, x2, lsl #2
    a004:	d37df042 	lsl	x2, x2, #3
    a008:	8b020060 	add	x0, x3, x2
    a00c:	f9401017 	ldr	x23, [x0, #32]
    a010:	b4000257 	cbz	x23, a058 <f0+0x308>
    a014:	38626862 	ldrb	w2, [x3, x2]
    a018:	7100085f 	cmp	w2, #0x2
    a01c:	54010440 	b.eq	c0a4 <f0+0x2354>  // b.none
    a020:	7100045f 	cmp	w2, #0x1
    a024:	540001a1 	b.ne	a058 <f0+0x308>  // b.any
    a028:	29430002 	ldp	w2, w0, [x0, #24]
    a02c:	92403c21 	and	x1, x1, #0xffff
    a030:	9b027c21 	mul	x1, x1, x2
    a034:	d360fc21 	lsr	x1, x1, #32
    a038:	eb00003f 	cmp	x1, x0
    a03c:	540000e2 	b.cs	a058 <f0+0x308>  // b.hs, b.nlast
    a040:	8b0102f7 	add	x23, x23, x1
    a044:	394002e0 	ldrb	w0, [x23]
    a048:	7103fc1f 	cmp	w0, #0xff
    a04c:	54010e00 	b.eq	c20c <f0+0x24bc>  // b.none
    a050:	52800020 	mov	w0, #0x1                   	// #1
    a054:	390002e0 	strb	w0, [x23]
    a058:	910423e1 	add	x1, sp, #0x108
    a05c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a060:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a064:	52800020 	mov	w0, #0x1                   	// #1
    a068:	a910d7f7 	stp	x23, x21, [sp, #264]
    a06c:	97ffec06 	bl	5084 <fwp_data.part.0.constprop.0>
    a070:	97ffeddc 	bl	57e0 <fwp_rc_fresh>
    a074:	aa0003e2 	mov	x2, x0
    a078:	910463e1 	add	x1, sp, #0x118
    a07c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a080:	52800020 	mov	w0, #0x1                   	// #1
    a084:	a9118bf5 	stp	x21, x2, [sp, #280]
    a088:	97ffebff 	bl	5084 <fwp_data.part.0.constprop.0>
    a08c:	97ffedd5 	bl	57e0 <fwp_rc_fresh>
    a090:	aa0003e2 	mov	x2, x0
    a094:	9104a3e1 	add	x1, sp, #0x128
    a098:	52800020 	mov	w0, #0x1                   	// #1
    a09c:	a9128bf7 	stp	x23, x2, [sp, #296]
    a0a0:	97ffebf9 	bl	5084 <fwp_data.part.0.constprop.0>
    a0a4:	97ffedcf 	bl	57e0 <fwp_rc_fresh>
    a0a8:	aa0003e2 	mov	x2, x0
    a0ac:	9104e3e1 	add	x1, sp, #0x138
    a0b0:	52800020 	mov	w0, #0x1                   	// #1
    a0b4:	a9138bf5 	stp	x21, x2, [sp, #312]
    a0b8:	97ffebf3 	bl	5084 <fwp_data.part.0.constprop.0>
    a0bc:	97ffedc9 	bl	57e0 <fwp_rc_fresh>
    a0c0:	aa0003e2 	mov	x2, x0
    a0c4:	910523e1 	add	x1, sp, #0x148
    a0c8:	52800020 	mov	w0, #0x1                   	// #1
    a0cc:	a9148bf7 	stp	x23, x2, [sp, #328]
    a0d0:	97ffebed 	bl	5084 <fwp_data.part.0.constprop.0>
    a0d4:	91174283 	add	x3, x20, #0x5d0
    a0d8:	aa0003f5 	mov	x21, x0
    a0dc:	f949d861 	ldr	x1, [x3, #5040]
    a0e0:	f949ec60 	ldr	x0, [x3, #5080]
    a0e4:	cb0102a1 	sub	x1, x21, x1
    a0e8:	eb00403f 	cmp	x1, x0, lsl #16
    a0ec:	54000322 	b.cs	a150 <f0+0x400>  // b.hs, b.nlast
    a0f0:	d350fc22 	lsr	x2, x1, #16
    a0f4:	f949fc63 	ldr	x3, [x3, #5112]
    a0f8:	8b020842 	add	x2, x2, x2, lsl #2
    a0fc:	d37df042 	lsl	x2, x2, #3
    a100:	8b020060 	add	x0, x3, x2
    a104:	f9401017 	ldr	x23, [x0, #32]
    a108:	b4000257 	cbz	x23, a150 <f0+0x400>
    a10c:	38626862 	ldrb	w2, [x3, x2]
    a110:	7100085f 	cmp	w2, #0x2
    a114:	5400fc20 	b.eq	c098 <f0+0x2348>  // b.none
    a118:	7100045f 	cmp	w2, #0x1
    a11c:	540001a1 	b.ne	a150 <f0+0x400>  // b.any
    a120:	29430002 	ldp	w2, w0, [x0, #24]
    a124:	92403c21 	and	x1, x1, #0xffff
    a128:	9b027c21 	mul	x1, x1, x2
    a12c:	d360fc21 	lsr	x1, x1, #32
    a130:	eb00003f 	cmp	x1, x0
    a134:	540000e2 	b.cs	a150 <f0+0x400>  // b.hs, b.nlast
    a138:	8b0102f7 	add	x23, x23, x1
    a13c:	394002e0 	ldrb	w0, [x23]
    a140:	7103fc1f 	cmp	w0, #0xff
    a144:	540106a0 	b.eq	c218 <f0+0x24c8>  // b.none
    a148:	52800020 	mov	w0, #0x1                   	// #1
    a14c:	390002e0 	strb	w0, [x23]
    a150:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a154:	910563e1 	add	x1, sp, #0x158
    a158:	52800020 	mov	w0, #0x1                   	// #1
    a15c:	a915d7e2 	stp	x2, x21, [sp, #344]
    a160:	97ffebc9 	bl	5084 <fwp_data.part.0.constprop.0>
    a164:	91174283 	add	x3, x20, #0x5d0
    a168:	aa0003f5 	mov	x21, x0
    a16c:	f949d861 	ldr	x1, [x3, #5040]
    a170:	f949ec60 	ldr	x0, [x3, #5080]
    a174:	cb0102a1 	sub	x1, x21, x1
    a178:	eb00403f 	cmp	x1, x0, lsl #16
    a17c:	54000322 	b.cs	a1e0 <f0+0x490>  // b.hs, b.nlast
    a180:	d350fc22 	lsr	x2, x1, #16
    a184:	f949fc63 	ldr	x3, [x3, #5112]
    a188:	8b020842 	add	x2, x2, x2, lsl #2
    a18c:	d37df042 	lsl	x2, x2, #3
    a190:	8b020060 	add	x0, x3, x2
    a194:	f9401017 	ldr	x23, [x0, #32]
    a198:	b4000257 	cbz	x23, a1e0 <f0+0x490>
    a19c:	38626862 	ldrb	w2, [x3, x2]
    a1a0:	7100085f 	cmp	w2, #0x2
    a1a4:	5400f740 	b.eq	c08c <f0+0x233c>  // b.none
    a1a8:	7100045f 	cmp	w2, #0x1
    a1ac:	540001a1 	b.ne	a1e0 <f0+0x490>  // b.any
    a1b0:	29430002 	ldp	w2, w0, [x0, #24]
    a1b4:	92403c21 	and	x1, x1, #0xffff
    a1b8:	9b027c21 	mul	x1, x1, x2
    a1bc:	d360fc21 	lsr	x1, x1, #32
    a1c0:	eb00003f 	cmp	x1, x0
    a1c4:	540000e2 	b.cs	a1e0 <f0+0x490>  // b.hs, b.nlast
    a1c8:	8b0102f7 	add	x23, x23, x1
    a1cc:	394002e0 	ldrb	w0, [x23]
    a1d0:	7103fc1f 	cmp	w0, #0xff
    a1d4:	54010280 	b.eq	c224 <f0+0x24d4>  // b.none
    a1d8:	52800020 	mov	w0, #0x1                   	// #1
    a1dc:	390002e0 	strb	w0, [x23]
    a1e0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a1e4:	9105a3e1 	add	x1, sp, #0x168
    a1e8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a1ec:	52800020 	mov	w0, #0x1                   	// #1
    a1f0:	a916d7e2 	stp	x2, x21, [sp, #360]
    a1f4:	97ffeba4 	bl	5084 <fwp_data.part.0.constprop.0>
    a1f8:	97ffed7a 	bl	57e0 <fwp_rc_fresh>
    a1fc:	aa0003e2 	mov	x2, x0
    a200:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a204:	9105e3e1 	add	x1, sp, #0x178
    a208:	52800020 	mov	w0, #0x1                   	// #1
    a20c:	a9178be3 	stp	x3, x2, [sp, #376]
    a210:	97ffeb9d 	bl	5084 <fwp_data.part.0.constprop.0>
    a214:	91174283 	add	x3, x20, #0x5d0
    a218:	aa0003f5 	mov	x21, x0
    a21c:	f949d861 	ldr	x1, [x3, #5040]
    a220:	f949ec60 	ldr	x0, [x3, #5080]
    a224:	cb0102a1 	sub	x1, x21, x1
    a228:	eb00403f 	cmp	x1, x0, lsl #16
    a22c:	54000322 	b.cs	a290 <f0+0x540>  // b.hs, b.nlast
    a230:	d350fc22 	lsr	x2, x1, #16
    a234:	f949fc63 	ldr	x3, [x3, #5112]
    a238:	8b020842 	add	x2, x2, x2, lsl #2
    a23c:	d37df042 	lsl	x2, x2, #3
    a240:	8b020060 	add	x0, x3, x2
    a244:	f9401017 	ldr	x23, [x0, #32]
    a248:	b4000257 	cbz	x23, a290 <f0+0x540>
    a24c:	38626862 	ldrb	w2, [x3, x2]
    a250:	7100085f 	cmp	w2, #0x2
    a254:	5400f400 	b.eq	c0d4 <f0+0x2384>  // b.none
    a258:	7100045f 	cmp	w2, #0x1
    a25c:	540001a1 	b.ne	a290 <f0+0x540>  // b.any
    a260:	29430002 	ldp	w2, w0, [x0, #24]
    a264:	92403c21 	and	x1, x1, #0xffff
    a268:	9b027c21 	mul	x1, x1, x2
    a26c:	d360fc21 	lsr	x1, x1, #32
    a270:	eb00003f 	cmp	x1, x0
    a274:	540000e2 	b.cs	a290 <f0+0x540>  // b.hs, b.nlast
    a278:	8b0102f7 	add	x23, x23, x1
    a27c:	394002e0 	ldrb	w0, [x23]
    a280:	7103fc1f 	cmp	w0, #0xff
    a284:	5400fd60 	b.eq	c230 <f0+0x24e0>  // b.none
    a288:	52800020 	mov	w0, #0x1                   	// #1
    a28c:	390002e0 	strb	w0, [x23]
    a290:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a294:	910623e1 	add	x1, sp, #0x188
    a298:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a29c:	52800020 	mov	w0, #0x1                   	// #1
    a2a0:	a918d7e2 	stp	x2, x21, [sp, #392]
    a2a4:	97ffeb78 	bl	5084 <fwp_data.part.0.constprop.0>
    a2a8:	97ffed4e 	bl	57e0 <fwp_rc_fresh>
    a2ac:	aa0003e2 	mov	x2, x0
    a2b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a2b4:	910663e1 	add	x1, sp, #0x198
    a2b8:	52800020 	mov	w0, #0x1                   	// #1
    a2bc:	a9198be3 	stp	x3, x2, [sp, #408]
    a2c0:	97ffeb71 	bl	5084 <fwp_data.part.0.constprop.0>
    a2c4:	91174283 	add	x3, x20, #0x5d0
    a2c8:	aa0003f5 	mov	x21, x0
    a2cc:	f949d861 	ldr	x1, [x3, #5040]
    a2d0:	f949ec60 	ldr	x0, [x3, #5080]
    a2d4:	cb0102a1 	sub	x1, x21, x1
    a2d8:	eb00403f 	cmp	x1, x0, lsl #16
    a2dc:	54000322 	b.cs	a340 <f0+0x5f0>  // b.hs, b.nlast
    a2e0:	d350fc22 	lsr	x2, x1, #16
    a2e4:	f949fc63 	ldr	x3, [x3, #5112]
    a2e8:	8b020842 	add	x2, x2, x2, lsl #2
    a2ec:	d37df042 	lsl	x2, x2, #3
    a2f0:	8b020060 	add	x0, x3, x2
    a2f4:	f9401017 	ldr	x23, [x0, #32]
    a2f8:	b4000257 	cbz	x23, a340 <f0+0x5f0>
    a2fc:	38626862 	ldrb	w2, [x3, x2]
    a300:	7100085f 	cmp	w2, #0x2
    a304:	5400ee20 	b.eq	c0c8 <f0+0x2378>  // b.none
    a308:	7100045f 	cmp	w2, #0x1
    a30c:	540001a1 	b.ne	a340 <f0+0x5f0>  // b.any
    a310:	29430002 	ldp	w2, w0, [x0, #24]
    a314:	92403c21 	and	x1, x1, #0xffff
    a318:	9b027c21 	mul	x1, x1, x2
    a31c:	d360fc21 	lsr	x1, x1, #32
    a320:	eb00003f 	cmp	x1, x0
    a324:	540000e2 	b.cs	a340 <f0+0x5f0>  // b.hs, b.nlast
    a328:	8b0102f7 	add	x23, x23, x1
    a32c:	394002e0 	ldrb	w0, [x23]
    a330:	7103fc1f 	cmp	w0, #0xff
    a334:	5400f840 	b.eq	c23c <f0+0x24ec>  // b.none
    a338:	52800020 	mov	w0, #0x1                   	// #1
    a33c:	390002e0 	strb	w0, [x23]
    a340:	9106a3e1 	add	x1, sp, #0x1a8
    a344:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a348:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a34c:	52800020 	mov	w0, #0x1                   	// #1
    a350:	a91ad7f7 	stp	x23, x21, [sp, #424]
    a354:	97ffeb4c 	bl	5084 <fwp_data.part.0.constprop.0>
    a358:	97ffed22 	bl	57e0 <fwp_rc_fresh>
    a35c:	aa0003e2 	mov	x2, x0
    a360:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a364:	9106e3e1 	add	x1, sp, #0x1b8
    a368:	52800020 	mov	w0, #0x1                   	// #1
    a36c:	a91b8be3 	stp	x3, x2, [sp, #440]
    a370:	97ffeb45 	bl	5084 <fwp_data.part.0.constprop.0>
    a374:	97ffed1b 	bl	57e0 <fwp_rc_fresh>
    a378:	aa0003e2 	mov	x2, x0
    a37c:	910723e1 	add	x1, sp, #0x1c8
    a380:	52800020 	mov	w0, #0x1                   	// #1
    a384:	a91c8bf7 	stp	x23, x2, [sp, #456]
    a388:	97ffeb3f 	bl	5084 <fwp_data.part.0.constprop.0>
    a38c:	91174283 	add	x3, x20, #0x5d0
    a390:	aa0003f5 	mov	x21, x0
    a394:	f949d861 	ldr	x1, [x3, #5040]
    a398:	f949ec60 	ldr	x0, [x3, #5080]
    a39c:	cb0102a1 	sub	x1, x21, x1
    a3a0:	eb00403f 	cmp	x1, x0, lsl #16
    a3a4:	54000322 	b.cs	a408 <f0+0x6b8>  // b.hs, b.nlast
    a3a8:	d350fc22 	lsr	x2, x1, #16
    a3ac:	f949fc63 	ldr	x3, [x3, #5112]
    a3b0:	8b020842 	add	x2, x2, x2, lsl #2
    a3b4:	d37df042 	lsl	x2, x2, #3
    a3b8:	8b020060 	add	x0, x3, x2
    a3bc:	f9401017 	ldr	x23, [x0, #32]
    a3c0:	b4000257 	cbz	x23, a408 <f0+0x6b8>
    a3c4:	38626862 	ldrb	w2, [x3, x2]
    a3c8:	7100085f 	cmp	w2, #0x2
    a3cc:	5400e780 	b.eq	c0bc <f0+0x236c>  // b.none
    a3d0:	7100045f 	cmp	w2, #0x1
    a3d4:	540001a1 	b.ne	a408 <f0+0x6b8>  // b.any
    a3d8:	29430002 	ldp	w2, w0, [x0, #24]
    a3dc:	92403c21 	and	x1, x1, #0xffff
    a3e0:	9b027c21 	mul	x1, x1, x2
    a3e4:	d360fc21 	lsr	x1, x1, #32
    a3e8:	eb00003f 	cmp	x1, x0
    a3ec:	540000e2 	b.cs	a408 <f0+0x6b8>  // b.hs, b.nlast
    a3f0:	8b0102f7 	add	x23, x23, x1
    a3f4:	394002e0 	ldrb	w0, [x23]
    a3f8:	7103fc1f 	cmp	w0, #0xff
    a3fc:	5400f260 	b.eq	c248 <f0+0x24f8>  // b.none
    a400:	52800020 	mov	w0, #0x1                   	// #1
    a404:	390002e0 	strb	w0, [x23]
    a408:	910763e1 	add	x1, sp, #0x1d8
    a40c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a410:	52800020 	mov	w0, #0x1                   	// #1
    a414:	a91dd7f7 	stp	x23, x21, [sp, #472]
    a418:	97ffeb1b 	bl	5084 <fwp_data.part.0.constprop.0>
    a41c:	97ffecf1 	bl	57e0 <fwp_rc_fresh>
    a420:	aa0003e2 	mov	x2, x0
    a424:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a428:	9107a3e1 	add	x1, sp, #0x1e8
    a42c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a430:	52800020 	mov	w0, #0x1                   	// #1
    a434:	a91e8be3 	stp	x3, x2, [sp, #488]
    a438:	97ffeb13 	bl	5084 <fwp_data.part.0.constprop.0>
    a43c:	97ffece9 	bl	57e0 <fwp_rc_fresh>
    a440:	aa0003e2 	mov	x2, x0
    a444:	9107e3e1 	add	x1, sp, #0x1f8
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	a91f8bf7 	stp	x23, x2, [sp, #504]
    a450:	97ffeb0d 	bl	5084 <fwp_data.part.0.constprop.0>
    a454:	91174283 	add	x3, x20, #0x5d0
    a458:	aa0003f5 	mov	x21, x0
    a45c:	f949d861 	ldr	x1, [x3, #5040]
    a460:	f949ec60 	ldr	x0, [x3, #5080]
    a464:	cb0102a1 	sub	x1, x21, x1
    a468:	eb00403f 	cmp	x1, x0, lsl #16
    a46c:	54000322 	b.cs	a4d0 <f0+0x780>  // b.hs, b.nlast
    a470:	d350fc22 	lsr	x2, x1, #16
    a474:	f949fc63 	ldr	x3, [x3, #5112]
    a478:	8b020842 	add	x2, x2, x2, lsl #2
    a47c:	d37df042 	lsl	x2, x2, #3
    a480:	8b020060 	add	x0, x3, x2
    a484:	f9401017 	ldr	x23, [x0, #32]
    a488:	b4000257 	cbz	x23, a4d0 <f0+0x780>
    a48c:	38626862 	ldrb	w2, [x3, x2]
    a490:	7100085f 	cmp	w2, #0x2
    a494:	5400e0e0 	b.eq	c0b0 <f0+0x2360>  // b.none
    a498:	7100045f 	cmp	w2, #0x1
    a49c:	540001a1 	b.ne	a4d0 <f0+0x780>  // b.any
    a4a0:	29430002 	ldp	w2, w0, [x0, #24]
    a4a4:	92403c21 	and	x1, x1, #0xffff
    a4a8:	9b027c21 	mul	x1, x1, x2
    a4ac:	d360fc21 	lsr	x1, x1, #32
    a4b0:	eb00003f 	cmp	x1, x0
    a4b4:	540000e2 	b.cs	a4d0 <f0+0x780>  // b.hs, b.nlast
    a4b8:	8b0102f7 	add	x23, x23, x1
    a4bc:	394002e0 	ldrb	w0, [x23]
    a4c0:	7103fc1f 	cmp	w0, #0xff
    a4c4:	5400ec80 	b.eq	c254 <f0+0x2504>  // b.none
    a4c8:	52800020 	mov	w0, #0x1                   	// #1
    a4cc:	390002e0 	strb	w0, [x23]
    a4d0:	910823e1 	add	x1, sp, #0x208
    a4d4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a4d8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a4dc:	52800020 	mov	w0, #0x1                   	// #1
    a4e0:	f90107f7 	str	x23, [sp, #520]
    a4e4:	f9010bf5 	str	x21, [sp, #528]
    a4e8:	97ffeae7 	bl	5084 <fwp_data.part.0.constprop.0>
    a4ec:	97ffecbd 	bl	57e0 <fwp_rc_fresh>
    a4f0:	aa0003e2 	mov	x2, x0
    a4f4:	910863e1 	add	x1, sp, #0x218
    a4f8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a4fc:	52800020 	mov	w0, #0x1                   	// #1
    a500:	f9010ff5 	str	x21, [sp, #536]
    a504:	f90113e2 	str	x2, [sp, #544]
    a508:	97ffeadf 	bl	5084 <fwp_data.part.0.constprop.0>
    a50c:	97ffecb5 	bl	57e0 <fwp_rc_fresh>
    a510:	aa0003e2 	mov	x2, x0
    a514:	9108a3e1 	add	x1, sp, #0x228
    a518:	52800020 	mov	w0, #0x1                   	// #1
    a51c:	f90117f7 	str	x23, [sp, #552]
    a520:	f9011be2 	str	x2, [sp, #560]
    a524:	97ffead8 	bl	5084 <fwp_data.part.0.constprop.0>
    a528:	97ffecae 	bl	57e0 <fwp_rc_fresh>
    a52c:	aa0003e2 	mov	x2, x0
    a530:	9108e3e1 	add	x1, sp, #0x238
    a534:	52800020 	mov	w0, #0x1                   	// #1
    a538:	f9011ff5 	str	x21, [sp, #568]
    a53c:	f90123e2 	str	x2, [sp, #576]
    a540:	97ffead1 	bl	5084 <fwp_data.part.0.constprop.0>
    a544:	97ffeca7 	bl	57e0 <fwp_rc_fresh>
    a548:	aa0003e2 	mov	x2, x0
    a54c:	910923e1 	add	x1, sp, #0x248
    a550:	52800020 	mov	w0, #0x1                   	// #1
    a554:	f90127f7 	str	x23, [sp, #584]
    a558:	f9012be2 	str	x2, [sp, #592]
    a55c:	97ffeaca 	bl	5084 <fwp_data.part.0.constprop.0>
    a560:	91174283 	add	x3, x20, #0x5d0
    a564:	aa0003f5 	mov	x21, x0
    a568:	f949d861 	ldr	x1, [x3, #5040]
    a56c:	f949ec60 	ldr	x0, [x3, #5080]
    a570:	cb0102a1 	sub	x1, x21, x1
    a574:	eb00403f 	cmp	x1, x0, lsl #16
    a578:	54000322 	b.cs	a5dc <f0+0x88c>  // b.hs, b.nlast
    a57c:	d350fc22 	lsr	x2, x1, #16
    a580:	f949fc63 	ldr	x3, [x3, #5112]
    a584:	8b020842 	add	x2, x2, x2, lsl #2
    a588:	d37df042 	lsl	x2, x2, #3
    a58c:	8b020060 	add	x0, x3, x2
    a590:	f9401017 	ldr	x23, [x0, #32]
    a594:	b4000257 	cbz	x23, a5dc <f0+0x88c>
    a598:	38626862 	ldrb	w2, [x3, x2]
    a59c:	7100085f 	cmp	w2, #0x2
    a5a0:	5400dca0 	b.eq	c134 <f0+0x23e4>  // b.none
    a5a4:	7100045f 	cmp	w2, #0x1
    a5a8:	540001a1 	b.ne	a5dc <f0+0x88c>  // b.any
    a5ac:	29430002 	ldp	w2, w0, [x0, #24]
    a5b0:	92403c21 	and	x1, x1, #0xffff
    a5b4:	9b027c21 	mul	x1, x1, x2
    a5b8:	d360fc21 	lsr	x1, x1, #32
    a5bc:	eb00003f 	cmp	x1, x0
    a5c0:	540000e2 	b.cs	a5dc <f0+0x88c>  // b.hs, b.nlast
    a5c4:	8b0102f7 	add	x23, x23, x1
    a5c8:	394002e0 	ldrb	w0, [x23]
    a5cc:	7103fc1f 	cmp	w0, #0xff
    a5d0:	5400e480 	b.eq	c260 <f0+0x2510>  // b.none
    a5d4:	52800020 	mov	w0, #0x1                   	// #1
    a5d8:	390002e0 	strb	w0, [x23]
    a5dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a5e0:	910963e1 	add	x1, sp, #0x258
    a5e4:	52800020 	mov	w0, #0x1                   	// #1
    a5e8:	f9012fe2 	str	x2, [sp, #600]
    a5ec:	f90133f5 	str	x21, [sp, #608]
    a5f0:	97ffeaa5 	bl	5084 <fwp_data.part.0.constprop.0>
    a5f4:	91174283 	add	x3, x20, #0x5d0
    a5f8:	aa0003f5 	mov	x21, x0
    a5fc:	f949d861 	ldr	x1, [x3, #5040]
    a600:	f949ec60 	ldr	x0, [x3, #5080]
    a604:	cb0102a1 	sub	x1, x21, x1
    a608:	eb00403f 	cmp	x1, x0, lsl #16
    a60c:	54000322 	b.cs	a670 <f0+0x920>  // b.hs, b.nlast
    a610:	d350fc22 	lsr	x2, x1, #16
    a614:	f949fc63 	ldr	x3, [x3, #5112]
    a618:	8b020842 	add	x2, x2, x2, lsl #2
    a61c:	d37df042 	lsl	x2, x2, #3
    a620:	8b020060 	add	x0, x3, x2
    a624:	f9401017 	ldr	x23, [x0, #32]
    a628:	b4000257 	cbz	x23, a670 <f0+0x920>
    a62c:	38626862 	ldrb	w2, [x3, x2]
    a630:	7100085f 	cmp	w2, #0x2
    a634:	5400d7a0 	b.eq	c128 <f0+0x23d8>  // b.none
    a638:	7100045f 	cmp	w2, #0x1
    a63c:	540001a1 	b.ne	a670 <f0+0x920>  // b.any
    a640:	29430002 	ldp	w2, w0, [x0, #24]
    a644:	92403c21 	and	x1, x1, #0xffff
    a648:	9b027c21 	mul	x1, x1, x2
    a64c:	d360fc21 	lsr	x1, x1, #32
    a650:	eb00003f 	cmp	x1, x0
    a654:	540000e2 	b.cs	a670 <f0+0x920>  // b.hs, b.nlast
    a658:	8b0102f7 	add	x23, x23, x1
    a65c:	394002e0 	ldrb	w0, [x23]
    a660:	7103fc1f 	cmp	w0, #0xff
    a664:	5400e040 	b.eq	c26c <f0+0x251c>  // b.none
    a668:	52800020 	mov	w0, #0x1                   	// #1
    a66c:	390002e0 	strb	w0, [x23]
    a670:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a674:	9109a3e1 	add	x1, sp, #0x268
    a678:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a67c:	52800020 	mov	w0, #0x1                   	// #1
    a680:	f90137e2 	str	x2, [sp, #616]
    a684:	f9013bf5 	str	x21, [sp, #624]
    a688:	97ffea7f 	bl	5084 <fwp_data.part.0.constprop.0>
    a68c:	97ffec55 	bl	57e0 <fwp_rc_fresh>
    a690:	aa0003e2 	mov	x2, x0
    a694:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a698:	9109e3e1 	add	x1, sp, #0x278
    a69c:	52800020 	mov	w0, #0x1                   	// #1
    a6a0:	f9013fe3 	str	x3, [sp, #632]
    a6a4:	f90143e2 	str	x2, [sp, #640]
    a6a8:	97ffea77 	bl	5084 <fwp_data.part.0.constprop.0>
    a6ac:	91174283 	add	x3, x20, #0x5d0
    a6b0:	aa0003f5 	mov	x21, x0
    a6b4:	f949d861 	ldr	x1, [x3, #5040]
    a6b8:	f949ec60 	ldr	x0, [x3, #5080]
    a6bc:	cb0102a1 	sub	x1, x21, x1
    a6c0:	eb00403f 	cmp	x1, x0, lsl #16
    a6c4:	54000322 	b.cs	a728 <f0+0x9d8>  // b.hs, b.nlast
    a6c8:	d350fc22 	lsr	x2, x1, #16
    a6cc:	f949fc63 	ldr	x3, [x3, #5112]
    a6d0:	8b020842 	add	x2, x2, x2, lsl #2
    a6d4:	d37df042 	lsl	x2, x2, #3
    a6d8:	8b020060 	add	x0, x3, x2
    a6dc:	f9401017 	ldr	x23, [x0, #32]
    a6e0:	b4000257 	cbz	x23, a728 <f0+0x9d8>
    a6e4:	38626862 	ldrb	w2, [x3, x2]
    a6e8:	7100085f 	cmp	w2, #0x2
    a6ec:	5400d180 	b.eq	c11c <f0+0x23cc>  // b.none
    a6f0:	7100045f 	cmp	w2, #0x1
    a6f4:	540001a1 	b.ne	a728 <f0+0x9d8>  // b.any
    a6f8:	29430002 	ldp	w2, w0, [x0, #24]
    a6fc:	92403c21 	and	x1, x1, #0xffff
    a700:	9b027c21 	mul	x1, x1, x2
    a704:	d360fc21 	lsr	x1, x1, #32
    a708:	eb00003f 	cmp	x1, x0
    a70c:	540000e2 	b.cs	a728 <f0+0x9d8>  // b.hs, b.nlast
    a710:	8b0102f7 	add	x23, x23, x1
    a714:	394002e0 	ldrb	w0, [x23]
    a718:	7103fc1f 	cmp	w0, #0xff
    a71c:	5400dae0 	b.eq	c278 <f0+0x2528>  // b.none
    a720:	52800020 	mov	w0, #0x1                   	// #1
    a724:	390002e0 	strb	w0, [x23]
    a728:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a72c:	910a23e1 	add	x1, sp, #0x288
    a730:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a734:	52800020 	mov	w0, #0x1                   	// #1
    a738:	f90147e2 	str	x2, [sp, #648]
    a73c:	f9014bf5 	str	x21, [sp, #656]
    a740:	97ffea51 	bl	5084 <fwp_data.part.0.constprop.0>
    a744:	97ffec27 	bl	57e0 <fwp_rc_fresh>
    a748:	aa0003e2 	mov	x2, x0
    a74c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a750:	910a63e1 	add	x1, sp, #0x298
    a754:	52800020 	mov	w0, #0x1                   	// #1
    a758:	f9014fe3 	str	x3, [sp, #664]
    a75c:	f90153e2 	str	x2, [sp, #672]
    a760:	97ffea49 	bl	5084 <fwp_data.part.0.constprop.0>
    a764:	91174283 	add	x3, x20, #0x5d0
    a768:	aa0003f5 	mov	x21, x0
    a76c:	f949d861 	ldr	x1, [x3, #5040]
    a770:	f949ec60 	ldr	x0, [x3, #5080]
    a774:	cb0102a1 	sub	x1, x21, x1
    a778:	eb00403f 	cmp	x1, x0, lsl #16
    a77c:	54000322 	b.cs	a7e0 <f0+0xa90>  // b.hs, b.nlast
    a780:	d350fc22 	lsr	x2, x1, #16
    a784:	f949fc63 	ldr	x3, [x3, #5112]
    a788:	8b020842 	add	x2, x2, x2, lsl #2
    a78c:	d37df042 	lsl	x2, x2, #3
    a790:	8b020060 	add	x0, x3, x2
    a794:	f9401017 	ldr	x23, [x0, #32]
    a798:	b4000257 	cbz	x23, a7e0 <f0+0xa90>
    a79c:	38626862 	ldrb	w2, [x3, x2]
    a7a0:	7100085f 	cmp	w2, #0x2
    a7a4:	5400cb60 	b.eq	c110 <f0+0x23c0>  // b.none
    a7a8:	7100045f 	cmp	w2, #0x1
    a7ac:	540001a1 	b.ne	a7e0 <f0+0xa90>  // b.any
    a7b0:	29430002 	ldp	w2, w0, [x0, #24]
    a7b4:	92403c21 	and	x1, x1, #0xffff
    a7b8:	9b027c21 	mul	x1, x1, x2
    a7bc:	d360fc21 	lsr	x1, x1, #32
    a7c0:	eb00003f 	cmp	x1, x0
    a7c4:	540000e2 	b.cs	a7e0 <f0+0xa90>  // b.hs, b.nlast
    a7c8:	8b0102f7 	add	x23, x23, x1
    a7cc:	394002e0 	ldrb	w0, [x23]
    a7d0:	7103fc1f 	cmp	w0, #0xff
    a7d4:	5400d580 	b.eq	c284 <f0+0x2534>  // b.none
    a7d8:	52800020 	mov	w0, #0x1                   	// #1
    a7dc:	390002e0 	strb	w0, [x23]
    a7e0:	910aa3e1 	add	x1, sp, #0x2a8
    a7e4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a7e8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a7ec:	52800020 	mov	w0, #0x1                   	// #1
    a7f0:	f90157f7 	str	x23, [sp, #680]
    a7f4:	f9015bf5 	str	x21, [sp, #688]
    a7f8:	97ffea23 	bl	5084 <fwp_data.part.0.constprop.0>
    a7fc:	97ffebf9 	bl	57e0 <fwp_rc_fresh>
    a800:	aa0003e2 	mov	x2, x0
    a804:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a808:	910ae3e1 	add	x1, sp, #0x2b8
    a80c:	52800020 	mov	w0, #0x1                   	// #1
    a810:	f9015fe3 	str	x3, [sp, #696]
    a814:	f90163e2 	str	x2, [sp, #704]
    a818:	97ffea1b 	bl	5084 <fwp_data.part.0.constprop.0>
    a81c:	97ffebf1 	bl	57e0 <fwp_rc_fresh>
    a820:	aa0003e2 	mov	x2, x0
    a824:	910b23e1 	add	x1, sp, #0x2c8
    a828:	52800020 	mov	w0, #0x1                   	// #1
    a82c:	f90167f7 	str	x23, [sp, #712]
    a830:	f9016be2 	str	x2, [sp, #720]
    a834:	97ffea14 	bl	5084 <fwp_data.part.0.constprop.0>
    a838:	91174283 	add	x3, x20, #0x5d0
    a83c:	aa0003f5 	mov	x21, x0
    a840:	f949d861 	ldr	x1, [x3, #5040]
    a844:	f949ec60 	ldr	x0, [x3, #5080]
    a848:	cb0102a1 	sub	x1, x21, x1
    a84c:	eb00403f 	cmp	x1, x0, lsl #16
    a850:	54000322 	b.cs	a8b4 <f0+0xb64>  // b.hs, b.nlast
    a854:	d350fc22 	lsr	x2, x1, #16
    a858:	f949fc63 	ldr	x3, [x3, #5112]
    a85c:	8b020842 	add	x2, x2, x2, lsl #2
    a860:	d37df042 	lsl	x2, x2, #3
    a864:	8b020060 	add	x0, x3, x2
    a868:	f9401017 	ldr	x23, [x0, #32]
    a86c:	b4000257 	cbz	x23, a8b4 <f0+0xb64>
    a870:	38626862 	ldrb	w2, [x3, x2]
    a874:	7100085f 	cmp	w2, #0x2
    a878:	5400c460 	b.eq	c104 <f0+0x23b4>  // b.none
    a87c:	7100045f 	cmp	w2, #0x1
    a880:	540001a1 	b.ne	a8b4 <f0+0xb64>  // b.any
    a884:	29430002 	ldp	w2, w0, [x0, #24]
    a888:	92403c21 	and	x1, x1, #0xffff
    a88c:	9b027c21 	mul	x1, x1, x2
    a890:	d360fc21 	lsr	x1, x1, #32
    a894:	eb00003f 	cmp	x1, x0
    a898:	540000e2 	b.cs	a8b4 <f0+0xb64>  // b.hs, b.nlast
    a89c:	8b0102f7 	add	x23, x23, x1
    a8a0:	394002e0 	ldrb	w0, [x23]
    a8a4:	7103fc1f 	cmp	w0, #0xff
    a8a8:	5400cf40 	b.eq	c290 <f0+0x2540>  // b.none
    a8ac:	52800020 	mov	w0, #0x1                   	// #1
    a8b0:	390002e0 	strb	w0, [x23]
    a8b4:	910b63e1 	add	x1, sp, #0x2d8
    a8b8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a8bc:	52800020 	mov	w0, #0x1                   	// #1
    a8c0:	f9016ff7 	str	x23, [sp, #728]
    a8c4:	f90173f5 	str	x21, [sp, #736]
    a8c8:	97ffe9ef 	bl	5084 <fwp_data.part.0.constprop.0>
    a8cc:	97ffebc5 	bl	57e0 <fwp_rc_fresh>
    a8d0:	aa0003e2 	mov	x2, x0
    a8d4:	910ba3e1 	add	x1, sp, #0x2e8
    a8d8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a8dc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a8e0:	52800020 	mov	w0, #0x1                   	// #1
    a8e4:	f90177f5 	str	x21, [sp, #744]
    a8e8:	f9017be2 	str	x2, [sp, #752]
    a8ec:	97ffe9e6 	bl	5084 <fwp_data.part.0.constprop.0>
    a8f0:	97ffebbc 	bl	57e0 <fwp_rc_fresh>
    a8f4:	aa0003e2 	mov	x2, x0
    a8f8:	910be3e1 	add	x1, sp, #0x2f8
    a8fc:	52800020 	mov	w0, #0x1                   	// #1
    a900:	f9017ff7 	str	x23, [sp, #760]
    a904:	f90183e2 	str	x2, [sp, #768]
    a908:	97ffe9df 	bl	5084 <fwp_data.part.0.constprop.0>
    a90c:	97ffebb5 	bl	57e0 <fwp_rc_fresh>
    a910:	aa0003e2 	mov	x2, x0
    a914:	910c23e1 	add	x1, sp, #0x308
    a918:	52800020 	mov	w0, #0x1                   	// #1
    a91c:	f90187f5 	str	x21, [sp, #776]
    a920:	f9018be2 	str	x2, [sp, #784]
    a924:	97ffe9d8 	bl	5084 <fwp_data.part.0.constprop.0>
    a928:	97ffebae 	bl	57e0 <fwp_rc_fresh>
    a92c:	aa0003e2 	mov	x2, x0
    a930:	910c63e1 	add	x1, sp, #0x318
    a934:	52800020 	mov	w0, #0x1                   	// #1
    a938:	f9018ff7 	str	x23, [sp, #792]
    a93c:	f90193e2 	str	x2, [sp, #800]
    a940:	97ffe9d1 	bl	5084 <fwp_data.part.0.constprop.0>
    a944:	91174283 	add	x3, x20, #0x5d0
    a948:	aa0003f5 	mov	x21, x0
    a94c:	f949d861 	ldr	x1, [x3, #5040]
    a950:	f949ec60 	ldr	x0, [x3, #5080]
    a954:	cb0102a1 	sub	x1, x21, x1
    a958:	eb00403f 	cmp	x1, x0, lsl #16
    a95c:	54000322 	b.cs	a9c0 <f0+0xc70>  // b.hs, b.nlast
    a960:	d350fc22 	lsr	x2, x1, #16
    a964:	f949fc63 	ldr	x3, [x3, #5112]
    a968:	8b020842 	add	x2, x2, x2, lsl #2
    a96c:	d37df042 	lsl	x2, x2, #3
    a970:	8b020060 	add	x0, x3, x2
    a974:	f9401017 	ldr	x23, [x0, #32]
    a978:	b4000257 	cbz	x23, a9c0 <f0+0xc70>
    a97c:	38626862 	ldrb	w2, [x3, x2]
    a980:	7100085f 	cmp	w2, #0x2
    a984:	5400bba0 	b.eq	c0f8 <f0+0x23a8>  // b.none
    a988:	7100045f 	cmp	w2, #0x1
    a98c:	540001a1 	b.ne	a9c0 <f0+0xc70>  // b.any
    a990:	29430002 	ldp	w2, w0, [x0, #24]
    a994:	92403c21 	and	x1, x1, #0xffff
    a998:	9b027c21 	mul	x1, x1, x2
    a99c:	d360fc21 	lsr	x1, x1, #32
    a9a0:	eb00003f 	cmp	x1, x0
    a9a4:	540000e2 	b.cs	a9c0 <f0+0xc70>  // b.hs, b.nlast
    a9a8:	8b0102f7 	add	x23, x23, x1
    a9ac:	394002e0 	ldrb	w0, [x23]
    a9b0:	7103fc1f 	cmp	w0, #0xff
    a9b4:	5400c740 	b.eq	c29c <f0+0x254c>  // b.none
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	390002e0 	strb	w0, [x23]
    a9c0:	910ca3e1 	add	x1, sp, #0x328
    a9c4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a9c8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a9cc:	52800020 	mov	w0, #0x1                   	// #1
    a9d0:	f90197f7 	str	x23, [sp, #808]
    a9d4:	f9019bf5 	str	x21, [sp, #816]
    a9d8:	97ffe9ab 	bl	5084 <fwp_data.part.0.constprop.0>
    a9dc:	97ffeb81 	bl	57e0 <fwp_rc_fresh>
    a9e0:	aa0003e2 	mov	x2, x0
    a9e4:	910ce3e1 	add	x1, sp, #0x338
    a9e8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a9ec:	52800020 	mov	w0, #0x1                   	// #1
    a9f0:	f9019ff5 	str	x21, [sp, #824]
    a9f4:	f901a3e2 	str	x2, [sp, #832]
    a9f8:	97ffe9a3 	bl	5084 <fwp_data.part.0.constprop.0>
    a9fc:	97ffeb79 	bl	57e0 <fwp_rc_fresh>
    aa00:	aa0003e2 	mov	x2, x0
    aa04:	910d23e1 	add	x1, sp, #0x348
    aa08:	52800020 	mov	w0, #0x1                   	// #1
    aa0c:	f901a7f7 	str	x23, [sp, #840]
    aa10:	f901abe2 	str	x2, [sp, #848]
    aa14:	97ffe99c 	bl	5084 <fwp_data.part.0.constprop.0>
    aa18:	97ffeb72 	bl	57e0 <fwp_rc_fresh>
    aa1c:	aa0003e2 	mov	x2, x0
    aa20:	910d63e1 	add	x1, sp, #0x358
    aa24:	52800020 	mov	w0, #0x1                   	// #1
    aa28:	f901aff5 	str	x21, [sp, #856]
    aa2c:	f901b3e2 	str	x2, [sp, #864]
    aa30:	97ffe995 	bl	5084 <fwp_data.part.0.constprop.0>
    aa34:	91174283 	add	x3, x20, #0x5d0
    aa38:	aa0003f5 	mov	x21, x0
    aa3c:	f949d861 	ldr	x1, [x3, #5040]
    aa40:	f949ec60 	ldr	x0, [x3, #5080]
    aa44:	cb0102a1 	sub	x1, x21, x1
    aa48:	eb00403f 	cmp	x1, x0, lsl #16
    aa4c:	54000322 	b.cs	aab0 <f0+0xd60>  // b.hs, b.nlast
    aa50:	d350fc22 	lsr	x2, x1, #16
    aa54:	f949fc63 	ldr	x3, [x3, #5112]
    aa58:	8b020842 	add	x2, x2, x2, lsl #2
    aa5c:	d37df042 	lsl	x2, x2, #3
    aa60:	8b020060 	add	x0, x3, x2
    aa64:	f9401017 	ldr	x23, [x0, #32]
    aa68:	b4000257 	cbz	x23, aab0 <f0+0xd60>
    aa6c:	38626862 	ldrb	w2, [x3, x2]
    aa70:	7100085f 	cmp	w2, #0x2
    aa74:	5400b3c0 	b.eq	c0ec <f0+0x239c>  // b.none
    aa78:	7100045f 	cmp	w2, #0x1
    aa7c:	540001a1 	b.ne	aab0 <f0+0xd60>  // b.any
    aa80:	29430002 	ldp	w2, w0, [x0, #24]
    aa84:	92403c21 	and	x1, x1, #0xffff
    aa88:	9b027c21 	mul	x1, x1, x2
    aa8c:	d360fc21 	lsr	x1, x1, #32
    aa90:	eb00003f 	cmp	x1, x0
    aa94:	540000e2 	b.cs	aab0 <f0+0xd60>  // b.hs, b.nlast
    aa98:	8b0102f7 	add	x23, x23, x1
    aa9c:	394002e0 	ldrb	w0, [x23]
    aaa0:	7103fc1f 	cmp	w0, #0xff
    aaa4:	5400c020 	b.eq	c2a8 <f0+0x2558>  // b.none
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	390002e0 	strb	w0, [x23]
    aab0:	910da3e1 	add	x1, sp, #0x368
    aab4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aab8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	f901b7f7 	str	x23, [sp, #872]
    aac4:	f901bbf5 	str	x21, [sp, #880]
    aac8:	97ffe96f 	bl	5084 <fwp_data.part.0.constprop.0>
    aacc:	97ffeb45 	bl	57e0 <fwp_rc_fresh>
    aad0:	aa0003e2 	mov	x2, x0
    aad4:	910de3e1 	add	x1, sp, #0x378
    aad8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aadc:	52800020 	mov	w0, #0x1                   	// #1
    aae0:	f901bff5 	str	x21, [sp, #888]
    aae4:	f901c3e2 	str	x2, [sp, #896]
    aae8:	97ffe967 	bl	5084 <fwp_data.part.0.constprop.0>
    aaec:	97ffeb3d 	bl	57e0 <fwp_rc_fresh>
    aaf0:	aa0003e2 	mov	x2, x0
    aaf4:	910e23e1 	add	x1, sp, #0x388
    aaf8:	52800020 	mov	w0, #0x1                   	// #1
    aafc:	f901c7f7 	str	x23, [sp, #904]
    ab00:	f901cbe2 	str	x2, [sp, #912]
    ab04:	97ffe960 	bl	5084 <fwp_data.part.0.constprop.0>
    ab08:	97ffeb36 	bl	57e0 <fwp_rc_fresh>
    ab0c:	aa0003e2 	mov	x2, x0
    ab10:	910e63e1 	add	x1, sp, #0x398
    ab14:	52800020 	mov	w0, #0x1                   	// #1
    ab18:	f901cff5 	str	x21, [sp, #920]
    ab1c:	f901d3e2 	str	x2, [sp, #928]
    ab20:	97ffe959 	bl	5084 <fwp_data.part.0.constprop.0>
    ab24:	91174283 	add	x3, x20, #0x5d0
    ab28:	aa0003f5 	mov	x21, x0
    ab2c:	f949d861 	ldr	x1, [x3, #5040]
    ab30:	f949ec60 	ldr	x0, [x3, #5080]
    ab34:	cb0102a1 	sub	x1, x21, x1
    ab38:	eb00403f 	cmp	x1, x0, lsl #16
    ab3c:	54000322 	b.cs	aba0 <f0+0xe50>  // b.hs, b.nlast
    ab40:	d350fc22 	lsr	x2, x1, #16
    ab44:	f949fc63 	ldr	x3, [x3, #5112]
    ab48:	8b020842 	add	x2, x2, x2, lsl #2
    ab4c:	d37df042 	lsl	x2, x2, #3
    ab50:	8b020060 	add	x0, x3, x2
    ab54:	f9401017 	ldr	x23, [x0, #32]
    ab58:	b4000257 	cbz	x23, aba0 <f0+0xe50>
    ab5c:	38626862 	ldrb	w2, [x3, x2]
    ab60:	7100085f 	cmp	w2, #0x2
    ab64:	5400abe0 	b.eq	c0e0 <f0+0x2390>  // b.none
    ab68:	7100045f 	cmp	w2, #0x1
    ab6c:	540001a1 	b.ne	aba0 <f0+0xe50>  // b.any
    ab70:	29430002 	ldp	w2, w0, [x0, #24]
    ab74:	92403c21 	and	x1, x1, #0xffff
    ab78:	9b027c21 	mul	x1, x1, x2
    ab7c:	d360fc21 	lsr	x1, x1, #32
    ab80:	eb00003f 	cmp	x1, x0
    ab84:	540000e2 	b.cs	aba0 <f0+0xe50>  // b.hs, b.nlast
    ab88:	8b0102f7 	add	x23, x23, x1
    ab8c:	394002e0 	ldrb	w0, [x23]
    ab90:	7103fc1f 	cmp	w0, #0xff
    ab94:	5400b900 	b.eq	c2b4 <f0+0x2564>  // b.none
    ab98:	52800020 	mov	w0, #0x1                   	// #1
    ab9c:	390002e0 	strb	w0, [x23]
    aba0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aba4:	910ea3e1 	add	x1, sp, #0x3a8
    aba8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    abac:	52800020 	mov	w0, #0x1                   	// #1
    abb0:	f901d7e2 	str	x2, [sp, #936]
    abb4:	f901dbf5 	str	x21, [sp, #944]
    abb8:	97ffe933 	bl	5084 <fwp_data.part.0.constprop.0>
    abbc:	97ffeb09 	bl	57e0 <fwp_rc_fresh>
    abc0:	aa0003e2 	mov	x2, x0
    abc4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    abc8:	910ee3e1 	add	x1, sp, #0x3b8
    abcc:	52800020 	mov	w0, #0x1                   	// #1
    abd0:	f901dfe3 	str	x3, [sp, #952]
    abd4:	f901e3e2 	str	x2, [sp, #960]
    abd8:	97ffe92b 	bl	5084 <fwp_data.part.0.constprop.0>
    abdc:	91174283 	add	x3, x20, #0x5d0
    abe0:	aa0003f5 	mov	x21, x0
    abe4:	f949d861 	ldr	x1, [x3, #5040]
    abe8:	f949ec60 	ldr	x0, [x3, #5080]
    abec:	cb0102a1 	sub	x1, x21, x1
    abf0:	eb00403f 	cmp	x1, x0, lsl #16
    abf4:	54000322 	b.cs	ac58 <f0+0xf08>  // b.hs, b.nlast
    abf8:	d350fc22 	lsr	x2, x1, #16
    abfc:	f949fc63 	ldr	x3, [x3, #5112]
    ac00:	8b020842 	add	x2, x2, x2, lsl #2
    ac04:	d37df042 	lsl	x2, x2, #3
    ac08:	8b020060 	add	x0, x3, x2
    ac0c:	f9401017 	ldr	x23, [x0, #32]
    ac10:	b4000257 	cbz	x23, ac58 <f0+0xf08>
    ac14:	38626862 	ldrb	w2, [x3, x2]
    ac18:	7100085f 	cmp	w2, #0x2
    ac1c:	5400a320 	b.eq	c080 <f0+0x2330>  // b.none
    ac20:	7100045f 	cmp	w2, #0x1
    ac24:	540001a1 	b.ne	ac58 <f0+0xf08>  // b.any
    ac28:	29430002 	ldp	w2, w0, [x0, #24]
    ac2c:	92403c21 	and	x1, x1, #0xffff
    ac30:	9b027c21 	mul	x1, x1, x2
    ac34:	d360fc21 	lsr	x1, x1, #32
    ac38:	eb00003f 	cmp	x1, x0
    ac3c:	540000e2 	b.cs	ac58 <f0+0xf08>  // b.hs, b.nlast
    ac40:	8b0102f7 	add	x23, x23, x1
    ac44:	394002e0 	ldrb	w0, [x23]
    ac48:	7103fc1f 	cmp	w0, #0xff
    ac4c:	5400b3a0 	b.eq	c2c0 <f0+0x2570>  // b.none
    ac50:	52800020 	mov	w0, #0x1                   	// #1
    ac54:	390002e0 	strb	w0, [x23]
    ac58:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ac5c:	910f23e1 	add	x1, sp, #0x3c8
    ac60:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ac64:	52800020 	mov	w0, #0x1                   	// #1
    ac68:	f901e7e2 	str	x2, [sp, #968]
    ac6c:	f901ebf5 	str	x21, [sp, #976]
    ac70:	97ffe905 	bl	5084 <fwp_data.part.0.constprop.0>
    ac74:	97ffeadb 	bl	57e0 <fwp_rc_fresh>
    ac78:	aa0003e2 	mov	x2, x0
    ac7c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ac80:	910f63e1 	add	x1, sp, #0x3d8
    ac84:	52800020 	mov	w0, #0x1                   	// #1
    ac88:	f901efe3 	str	x3, [sp, #984]
    ac8c:	f901f3e2 	str	x2, [sp, #992]
    ac90:	97ffe8fd 	bl	5084 <fwp_data.part.0.constprop.0>
    ac94:	91174283 	add	x3, x20, #0x5d0
    ac98:	aa0003f5 	mov	x21, x0
    ac9c:	f949d861 	ldr	x1, [x3, #5040]
    aca0:	f949ec60 	ldr	x0, [x3, #5080]
    aca4:	cb0102a1 	sub	x1, x21, x1
    aca8:	eb00403f 	cmp	x1, x0, lsl #16
    acac:	54000322 	b.cs	ad10 <f0+0xfc0>  // b.hs, b.nlast
    acb0:	d350fc22 	lsr	x2, x1, #16
    acb4:	f949fc63 	ldr	x3, [x3, #5112]
    acb8:	8b020842 	add	x2, x2, x2, lsl #2
    acbc:	d37df042 	lsl	x2, x2, #3
    acc0:	8b020060 	add	x0, x3, x2
    acc4:	f9401017 	ldr	x23, [x0, #32]
    acc8:	b4000257 	cbz	x23, ad10 <f0+0xfc0>
    accc:	38626862 	ldrb	w2, [x3, x2]
    acd0:	7100085f 	cmp	w2, #0x2
    acd4:	54009d00 	b.eq	c074 <f0+0x2324>  // b.none
    acd8:	7100045f 	cmp	w2, #0x1
    acdc:	540001a1 	b.ne	ad10 <f0+0xfc0>  // b.any
    ace0:	29430002 	ldp	w2, w0, [x0, #24]
    ace4:	92403c21 	and	x1, x1, #0xffff
    ace8:	9b027c21 	mul	x1, x1, x2
    acec:	d360fc21 	lsr	x1, x1, #32
    acf0:	eb00003f 	cmp	x1, x0
    acf4:	540000e2 	b.cs	ad10 <f0+0xfc0>  // b.hs, b.nlast
    acf8:	8b0102f7 	add	x23, x23, x1
    acfc:	394002e0 	ldrb	w0, [x23]
    ad00:	7103fc1f 	cmp	w0, #0xff
    ad04:	5400ae40 	b.eq	c2cc <f0+0x257c>  // b.none
    ad08:	52800020 	mov	w0, #0x1                   	// #1
    ad0c:	390002e0 	strb	w0, [x23]
    ad10:	910fa3e1 	add	x1, sp, #0x3e8
    ad14:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ad18:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ad1c:	52800020 	mov	w0, #0x1                   	// #1
    ad20:	f901f7f7 	str	x23, [sp, #1000]
    ad24:	f901fbf5 	str	x21, [sp, #1008]
    ad28:	97ffe8d7 	bl	5084 <fwp_data.part.0.constprop.0>
    ad2c:	97ffeaad 	bl	57e0 <fwp_rc_fresh>
    ad30:	aa0003e2 	mov	x2, x0
    ad34:	910fe3e1 	add	x1, sp, #0x3f8
    ad38:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ad3c:	52800020 	mov	w0, #0x1                   	// #1
    ad40:	f901fff5 	str	x21, [sp, #1016]
    ad44:	f90203e2 	str	x2, [sp, #1024]
    ad48:	97ffe8cf 	bl	5084 <fwp_data.part.0.constprop.0>
    ad4c:	97ffeaa5 	bl	57e0 <fwp_rc_fresh>
    ad50:	aa0003e2 	mov	x2, x0
    ad54:	911023e1 	add	x1, sp, #0x408
    ad58:	52800020 	mov	w0, #0x1                   	// #1
    ad5c:	f90207f7 	str	x23, [sp, #1032]
    ad60:	f9020be2 	str	x2, [sp, #1040]
    ad64:	97ffe8c8 	bl	5084 <fwp_data.part.0.constprop.0>
    ad68:	97ffea9e 	bl	57e0 <fwp_rc_fresh>
    ad6c:	aa0003e2 	mov	x2, x0
    ad70:	911063e1 	add	x1, sp, #0x418
    ad74:	52800020 	mov	w0, #0x1                   	// #1
    ad78:	f9020ff5 	str	x21, [sp, #1048]
    ad7c:	f90213e2 	str	x2, [sp, #1056]
    ad80:	97ffe8c1 	bl	5084 <fwp_data.part.0.constprop.0>
    ad84:	97ffea97 	bl	57e0 <fwp_rc_fresh>
    ad88:	aa0003e2 	mov	x2, x0
    ad8c:	9110a3e1 	add	x1, sp, #0x428
    ad90:	52800020 	mov	w0, #0x1                   	// #1
    ad94:	f90217f7 	str	x23, [sp, #1064]
    ad98:	f9021be2 	str	x2, [sp, #1072]
    ad9c:	97ffe8ba 	bl	5084 <fwp_data.part.0.constprop.0>
    ada0:	97ffea90 	bl	57e0 <fwp_rc_fresh>
    ada4:	aa0003e2 	mov	x2, x0
    ada8:	9110e3e1 	add	x1, sp, #0x438
    adac:	52800020 	mov	w0, #0x1                   	// #1
    adb0:	f9021ff5 	str	x21, [sp, #1080]
    adb4:	f90223e2 	str	x2, [sp, #1088]
    adb8:	97ffe8b3 	bl	5084 <fwp_data.part.0.constprop.0>
    adbc:	97ffea89 	bl	57e0 <fwp_rc_fresh>
    adc0:	aa0003e2 	mov	x2, x0
    adc4:	911123e1 	add	x1, sp, #0x448
    adc8:	52800020 	mov	w0, #0x1                   	// #1
    adcc:	f90227f7 	str	x23, [sp, #1096]
    add0:	f9022be2 	str	x2, [sp, #1104]
    add4:	97ffe8ac 	bl	5084 <fwp_data.part.0.constprop.0>
    add8:	97ffea82 	bl	57e0 <fwp_rc_fresh>
    addc:	aa0003e2 	mov	x2, x0
    ade0:	911163e1 	add	x1, sp, #0x458
    ade4:	52800020 	mov	w0, #0x1                   	// #1
    ade8:	f9022ff5 	str	x21, [sp, #1112]
    adec:	f90233e2 	str	x2, [sp, #1120]
    adf0:	97ffe8a5 	bl	5084 <fwp_data.part.0.constprop.0>
    adf4:	91174283 	add	x3, x20, #0x5d0
    adf8:	aa0003f5 	mov	x21, x0
    adfc:	f949d861 	ldr	x1, [x3, #5040]
    ae00:	f949ec60 	ldr	x0, [x3, #5080]
    ae04:	cb0102a1 	sub	x1, x21, x1
    ae08:	eb00403f 	cmp	x1, x0, lsl #16
    ae0c:	54000322 	b.cs	ae70 <f0+0x1120>  // b.hs, b.nlast
    ae10:	d350fc22 	lsr	x2, x1, #16
    ae14:	f949fc63 	ldr	x3, [x3, #5112]
    ae18:	8b020842 	add	x2, x2, x2, lsl #2
    ae1c:	d37df042 	lsl	x2, x2, #3
    ae20:	8b020060 	add	x0, x3, x2
    ae24:	f9401017 	ldr	x23, [x0, #32]
    ae28:	b4000257 	cbz	x23, ae70 <f0+0x1120>
    ae2c:	38626862 	ldrb	w2, [x3, x2]
    ae30:	7100085f 	cmp	w2, #0x2
    ae34:	540091a0 	b.eq	c068 <f0+0x2318>  // b.none
    ae38:	7100045f 	cmp	w2, #0x1
    ae3c:	540001a1 	b.ne	ae70 <f0+0x1120>  // b.any
    ae40:	29430002 	ldp	w2, w0, [x0, #24]
    ae44:	92403c21 	and	x1, x1, #0xffff
    ae48:	9b027c21 	mul	x1, x1, x2
    ae4c:	d360fc21 	lsr	x1, x1, #32
    ae50:	eb00003f 	cmp	x1, x0
    ae54:	540000e2 	b.cs	ae70 <f0+0x1120>  // b.hs, b.nlast
    ae58:	8b0102f7 	add	x23, x23, x1
    ae5c:	394002e0 	ldrb	w0, [x23]
    ae60:	7103fc1f 	cmp	w0, #0xff
    ae64:	5400a3a0 	b.eq	c2d8 <f0+0x2588>  // b.none
    ae68:	52800020 	mov	w0, #0x1                   	// #1
    ae6c:	390002e0 	strb	w0, [x23]
    ae70:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae74:	9111a3e1 	add	x1, sp, #0x468
    ae78:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae7c:	52800020 	mov	w0, #0x1                   	// #1
    ae80:	f90237e2 	str	x2, [sp, #1128]
    ae84:	f9023bf5 	str	x21, [sp, #1136]
    ae88:	97ffe87f 	bl	5084 <fwp_data.part.0.constprop.0>
    ae8c:	97ffea55 	bl	57e0 <fwp_rc_fresh>
    ae90:	aa0003e2 	mov	x2, x0
    ae94:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae98:	9111e3e1 	add	x1, sp, #0x478
    ae9c:	52800020 	mov	w0, #0x1                   	// #1
    aea0:	f9023fe3 	str	x3, [sp, #1144]
    aea4:	f90243e2 	str	x2, [sp, #1152]
    aea8:	97ffe877 	bl	5084 <fwp_data.part.0.constprop.0>
    aeac:	91174283 	add	x3, x20, #0x5d0
    aeb0:	aa0003f5 	mov	x21, x0
    aeb4:	f949d861 	ldr	x1, [x3, #5040]
    aeb8:	f949ec60 	ldr	x0, [x3, #5080]
    aebc:	cb0102a1 	sub	x1, x21, x1
    aec0:	eb00403f 	cmp	x1, x0, lsl #16
    aec4:	54000322 	b.cs	af28 <f0+0x11d8>  // b.hs, b.nlast
    aec8:	d350fc22 	lsr	x2, x1, #16
    aecc:	f949fc63 	ldr	x3, [x3, #5112]
    aed0:	8b020842 	add	x2, x2, x2, lsl #2
    aed4:	d37df042 	lsl	x2, x2, #3
    aed8:	8b020060 	add	x0, x3, x2
    aedc:	f9401017 	ldr	x23, [x0, #32]
    aee0:	b4000257 	cbz	x23, af28 <f0+0x11d8>
    aee4:	38626862 	ldrb	w2, [x3, x2]
    aee8:	7100085f 	cmp	w2, #0x2
    aeec:	54008b80 	b.eq	c05c <f0+0x230c>  // b.none
    aef0:	7100045f 	cmp	w2, #0x1
    aef4:	540001a1 	b.ne	af28 <f0+0x11d8>  // b.any
    aef8:	29430002 	ldp	w2, w0, [x0, #24]
    aefc:	92403c21 	and	x1, x1, #0xffff
    af00:	9b027c21 	mul	x1, x1, x2
    af04:	d360fc21 	lsr	x1, x1, #32
    af08:	eb00003f 	cmp	x1, x0
    af0c:	540000e2 	b.cs	af28 <f0+0x11d8>  // b.hs, b.nlast
    af10:	8b0102f7 	add	x23, x23, x1
    af14:	394002e0 	ldrb	w0, [x23]
    af18:	7103fc1f 	cmp	w0, #0xff
    af1c:	54009e40 	b.eq	c2e4 <f0+0x2594>  // b.none
    af20:	52800020 	mov	w0, #0x1                   	// #1
    af24:	390002e0 	strb	w0, [x23]
    af28:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af2c:	911223e1 	add	x1, sp, #0x488
    af30:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af34:	52800020 	mov	w0, #0x1                   	// #1
    af38:	f90247e2 	str	x2, [sp, #1160]
    af3c:	f9024bf5 	str	x21, [sp, #1168]
    af40:	97ffe851 	bl	5084 <fwp_data.part.0.constprop.0>
    af44:	97ffea27 	bl	57e0 <fwp_rc_fresh>
    af48:	aa0003e2 	mov	x2, x0
    af4c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    af50:	911263e1 	add	x1, sp, #0x498
    af54:	52800020 	mov	w0, #0x1                   	// #1
    af58:	f9024fe3 	str	x3, [sp, #1176]
    af5c:	f90253e2 	str	x2, [sp, #1184]
    af60:	97ffe849 	bl	5084 <fwp_data.part.0.constprop.0>
    af64:	91174283 	add	x3, x20, #0x5d0
    af68:	aa0003f5 	mov	x21, x0
    af6c:	f949d861 	ldr	x1, [x3, #5040]
    af70:	f949ec60 	ldr	x0, [x3, #5080]
    af74:	cb0102a1 	sub	x1, x21, x1
    af78:	eb00403f 	cmp	x1, x0, lsl #16
    af7c:	54000322 	b.cs	afe0 <f0+0x1290>  // b.hs, b.nlast
    af80:	d350fc22 	lsr	x2, x1, #16
    af84:	f949fc63 	ldr	x3, [x3, #5112]
    af88:	8b020842 	add	x2, x2, x2, lsl #2
    af8c:	d37df042 	lsl	x2, x2, #3
    af90:	8b020060 	add	x0, x3, x2
    af94:	f9401017 	ldr	x23, [x0, #32]
    af98:	b4000257 	cbz	x23, afe0 <f0+0x1290>
    af9c:	38626862 	ldrb	w2, [x3, x2]
    afa0:	7100085f 	cmp	w2, #0x2
    afa4:	54008560 	b.eq	c050 <f0+0x2300>  // b.none
    afa8:	7100045f 	cmp	w2, #0x1
    afac:	540001a1 	b.ne	afe0 <f0+0x1290>  // b.any
    afb0:	29430002 	ldp	w2, w0, [x0, #24]
    afb4:	92403c21 	and	x1, x1, #0xffff
    afb8:	9b027c21 	mul	x1, x1, x2
    afbc:	d360fc21 	lsr	x1, x1, #32
    afc0:	eb00003f 	cmp	x1, x0
    afc4:	540000e2 	b.cs	afe0 <f0+0x1290>  // b.hs, b.nlast
    afc8:	8b0102f7 	add	x23, x23, x1
    afcc:	394002e0 	ldrb	w0, [x23]
    afd0:	7103fc1f 	cmp	w0, #0xff
    afd4:	540098e0 	b.eq	c2f0 <f0+0x25a0>  // b.none
    afd8:	52800020 	mov	w0, #0x1                   	// #1
    afdc:	390002e0 	strb	w0, [x23]
    afe0:	9112a3e1 	add	x1, sp, #0x4a8
    afe4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    afe8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	f90257f7 	str	x23, [sp, #1192]
    aff4:	f9025bf5 	str	x21, [sp, #1200]
    aff8:	97ffe823 	bl	5084 <fwp_data.part.0.constprop.0>
    affc:	97ffe9f9 	bl	57e0 <fwp_rc_fresh>
    b000:	aa0003e2 	mov	x2, x0
    b004:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b008:	9112e3e1 	add	x1, sp, #0x4b8
    b00c:	52800020 	mov	w0, #0x1                   	// #1
    b010:	f9025fe3 	str	x3, [sp, #1208]
    b014:	f90263e2 	str	x2, [sp, #1216]
    b018:	97ffe81b 	bl	5084 <fwp_data.part.0.constprop.0>
    b01c:	97ffe9f1 	bl	57e0 <fwp_rc_fresh>
    b020:	aa0003e2 	mov	x2, x0
    b024:	911323e1 	add	x1, sp, #0x4c8
    b028:	52800020 	mov	w0, #0x1                   	// #1
    b02c:	f90267f7 	str	x23, [sp, #1224]
    b030:	f9026be2 	str	x2, [sp, #1232]
    b034:	97ffe814 	bl	5084 <fwp_data.part.0.constprop.0>
    b038:	91174283 	add	x3, x20, #0x5d0
    b03c:	aa0003f5 	mov	x21, x0
    b040:	f949d861 	ldr	x1, [x3, #5040]
    b044:	f949ec60 	ldr	x0, [x3, #5080]
    b048:	cb0102a1 	sub	x1, x21, x1
    b04c:	eb00403f 	cmp	x1, x0, lsl #16
    b050:	54000322 	b.cs	b0b4 <f0+0x1364>  // b.hs, b.nlast
    b054:	d350fc22 	lsr	x2, x1, #16
    b058:	f949fc63 	ldr	x3, [x3, #5112]
    b05c:	8b020842 	add	x2, x2, x2, lsl #2
    b060:	d37df042 	lsl	x2, x2, #3
    b064:	8b020060 	add	x0, x3, x2
    b068:	f9401017 	ldr	x23, [x0, #32]
    b06c:	b4000257 	cbz	x23, b0b4 <f0+0x1364>
    b070:	38626862 	ldrb	w2, [x3, x2]
    b074:	7100085f 	cmp	w2, #0x2
    b078:	54007e60 	b.eq	c044 <f0+0x22f4>  // b.none
    b07c:	7100045f 	cmp	w2, #0x1
    b080:	540001a1 	b.ne	b0b4 <f0+0x1364>  // b.any
    b084:	29430002 	ldp	w2, w0, [x0, #24]
    b088:	92403c21 	and	x1, x1, #0xffff
    b08c:	9b027c21 	mul	x1, x1, x2
    b090:	d360fc21 	lsr	x1, x1, #32
    b094:	eb00003f 	cmp	x1, x0
    b098:	540000e2 	b.cs	b0b4 <f0+0x1364>  // b.hs, b.nlast
    b09c:	8b0102f7 	add	x23, x23, x1
    b0a0:	394002e0 	ldrb	w0, [x23]
    b0a4:	7103fc1f 	cmp	w0, #0xff
    b0a8:	540092a0 	b.eq	c2fc <f0+0x25ac>  // b.none
    b0ac:	52800020 	mov	w0, #0x1                   	// #1
    b0b0:	390002e0 	strb	w0, [x23]
    b0b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b0b8:	911363e1 	add	x1, sp, #0x4d8
    b0bc:	52800020 	mov	w0, #0x1                   	// #1
    b0c0:	f9026fe2 	str	x2, [sp, #1240]
    b0c4:	f90273f5 	str	x21, [sp, #1248]
    b0c8:	97ffe7ef 	bl	5084 <fwp_data.part.0.constprop.0>
    b0cc:	91174283 	add	x3, x20, #0x5d0
    b0d0:	aa0003f5 	mov	x21, x0
    b0d4:	f949d861 	ldr	x1, [x3, #5040]
    b0d8:	f949ec60 	ldr	x0, [x3, #5080]
    b0dc:	cb0102a1 	sub	x1, x21, x1
    b0e0:	eb00403f 	cmp	x1, x0, lsl #16
    b0e4:	54000322 	b.cs	b148 <f0+0x13f8>  // b.hs, b.nlast
    b0e8:	d350fc22 	lsr	x2, x1, #16
    b0ec:	f949fc63 	ldr	x3, [x3, #5112]
    b0f0:	8b020842 	add	x2, x2, x2, lsl #2
    b0f4:	d37df042 	lsl	x2, x2, #3
    b0f8:	8b020060 	add	x0, x3, x2
    b0fc:	f9401017 	ldr	x23, [x0, #32]
    b100:	b4000257 	cbz	x23, b148 <f0+0x13f8>
    b104:	38626862 	ldrb	w2, [x3, x2]
    b108:	7100085f 	cmp	w2, #0x2
    b10c:	54007960 	b.eq	c038 <f0+0x22e8>  // b.none
    b110:	7100045f 	cmp	w2, #0x1
    b114:	540001a1 	b.ne	b148 <f0+0x13f8>  // b.any
    b118:	29430002 	ldp	w2, w0, [x0, #24]
    b11c:	92403c21 	and	x1, x1, #0xffff
    b120:	9b027c21 	mul	x1, x1, x2
    b124:	d360fc21 	lsr	x1, x1, #32
    b128:	eb00003f 	cmp	x1, x0
    b12c:	540000e2 	b.cs	b148 <f0+0x13f8>  // b.hs, b.nlast
    b130:	8b0102f7 	add	x23, x23, x1
    b134:	394002e0 	ldrb	w0, [x23]
    b138:	7103fc1f 	cmp	w0, #0xff
    b13c:	54008e60 	b.eq	c308 <f0+0x25b8>  // b.none
    b140:	52800020 	mov	w0, #0x1                   	// #1
    b144:	390002e0 	strb	w0, [x23]
    b148:	9113a3e1 	add	x1, sp, #0x4e8
    b14c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b150:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b154:	52800020 	mov	w0, #0x1                   	// #1
    b158:	f90277f7 	str	x23, [sp, #1256]
    b15c:	f9027bf5 	str	x21, [sp, #1264]
    b160:	97ffe7c9 	bl	5084 <fwp_data.part.0.constprop.0>
    b164:	97ffe99f 	bl	57e0 <fwp_rc_fresh>
    b168:	aa0003e2 	mov	x2, x0
    b16c:	9113e3e1 	add	x1, sp, #0x4f8
    b170:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b174:	52800020 	mov	w0, #0x1                   	// #1
    b178:	f9027ff5 	str	x21, [sp, #1272]
    b17c:	f90283e2 	str	x2, [sp, #1280]
    b180:	97ffe7c1 	bl	5084 <fwp_data.part.0.constprop.0>
    b184:	97ffe997 	bl	57e0 <fwp_rc_fresh>
    b188:	aa0003e2 	mov	x2, x0
    b18c:	911423e1 	add	x1, sp, #0x508
    b190:	52800020 	mov	w0, #0x1                   	// #1
    b194:	f90287f7 	str	x23, [sp, #1288]
    b198:	f9028be2 	str	x2, [sp, #1296]
    b19c:	97ffe7ba 	bl	5084 <fwp_data.part.0.constprop.0>
    b1a0:	97ffe990 	bl	57e0 <fwp_rc_fresh>
    b1a4:	aa0003e2 	mov	x2, x0
    b1a8:	911463e1 	add	x1, sp, #0x518
    b1ac:	52800020 	mov	w0, #0x1                   	// #1
    b1b0:	f9028ff5 	str	x21, [sp, #1304]
    b1b4:	f90293e2 	str	x2, [sp, #1312]
    b1b8:	97ffe7b3 	bl	5084 <fwp_data.part.0.constprop.0>
    b1bc:	91174283 	add	x3, x20, #0x5d0
    b1c0:	aa0003f5 	mov	x21, x0
    b1c4:	f949d861 	ldr	x1, [x3, #5040]
    b1c8:	f949ec60 	ldr	x0, [x3, #5080]
    b1cc:	cb0102a1 	sub	x1, x21, x1
    b1d0:	eb00403f 	cmp	x1, x0, lsl #16
    b1d4:	54000322 	b.cs	b238 <f0+0x14e8>  // b.hs, b.nlast
    b1d8:	d350fc22 	lsr	x2, x1, #16
    b1dc:	f949fc63 	ldr	x3, [x3, #5112]
    b1e0:	8b020842 	add	x2, x2, x2, lsl #2
    b1e4:	d37df042 	lsl	x2, x2, #3
    b1e8:	8b020060 	add	x0, x3, x2
    b1ec:	f9401017 	ldr	x23, [x0, #32]
    b1f0:	b4000257 	cbz	x23, b238 <f0+0x14e8>
    b1f4:	38626862 	ldrb	w2, [x3, x2]
    b1f8:	7100085f 	cmp	w2, #0x2
    b1fc:	54007180 	b.eq	c02c <f0+0x22dc>  // b.none
    b200:	7100045f 	cmp	w2, #0x1
    b204:	540001a1 	b.ne	b238 <f0+0x14e8>  // b.any
    b208:	29430002 	ldp	w2, w0, [x0, #24]
    b20c:	92403c21 	and	x1, x1, #0xffff
    b210:	9b027c21 	mul	x1, x1, x2
    b214:	d360fc21 	lsr	x1, x1, #32
    b218:	eb00003f 	cmp	x1, x0
    b21c:	540000e2 	b.cs	b238 <f0+0x14e8>  // b.hs, b.nlast
    b220:	8b0102f7 	add	x23, x23, x1
    b224:	394002e0 	ldrb	w0, [x23]
    b228:	7103fc1f 	cmp	w0, #0xff
    b22c:	54008740 	b.eq	c314 <f0+0x25c4>  // b.none
    b230:	52800020 	mov	w0, #0x1                   	// #1
    b234:	390002e0 	strb	w0, [x23]
    b238:	9114a3e1 	add	x1, sp, #0x528
    b23c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b240:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b244:	52800020 	mov	w0, #0x1                   	// #1
    b248:	f90297f7 	str	x23, [sp, #1320]
    b24c:	f9029bf5 	str	x21, [sp, #1328]
    b250:	97ffe78d 	bl	5084 <fwp_data.part.0.constprop.0>
    b254:	97ffe963 	bl	57e0 <fwp_rc_fresh>
    b258:	aa0003e2 	mov	x2, x0
    b25c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b260:	9114e3e1 	add	x1, sp, #0x538
    b264:	52800020 	mov	w0, #0x1                   	// #1
    b268:	f9029fe3 	str	x3, [sp, #1336]
    b26c:	f902a3e2 	str	x2, [sp, #1344]
    b270:	97ffe785 	bl	5084 <fwp_data.part.0.constprop.0>
    b274:	97ffe95b 	bl	57e0 <fwp_rc_fresh>
    b278:	aa0003e2 	mov	x2, x0
    b27c:	911523e1 	add	x1, sp, #0x548
    b280:	52800020 	mov	w0, #0x1                   	// #1
    b284:	f902a7f7 	str	x23, [sp, #1352]
    b288:	f902abe2 	str	x2, [sp, #1360]
    b28c:	97ffe77e 	bl	5084 <fwp_data.part.0.constprop.0>
    b290:	91174283 	add	x3, x20, #0x5d0
    b294:	aa0003f5 	mov	x21, x0
    b298:	f949d861 	ldr	x1, [x3, #5040]
    b29c:	f949ec60 	ldr	x0, [x3, #5080]
    b2a0:	cb0102a1 	sub	x1, x21, x1
    b2a4:	eb00403f 	cmp	x1, x0, lsl #16
    b2a8:	54000322 	b.cs	b30c <f0+0x15bc>  // b.hs, b.nlast
    b2ac:	d350fc22 	lsr	x2, x1, #16
    b2b0:	f949fc63 	ldr	x3, [x3, #5112]
    b2b4:	8b020842 	add	x2, x2, x2, lsl #2
    b2b8:	d37df042 	lsl	x2, x2, #3
    b2bc:	8b020060 	add	x0, x3, x2
    b2c0:	f9401017 	ldr	x23, [x0, #32]
    b2c4:	b4000257 	cbz	x23, b30c <f0+0x15bc>
    b2c8:	38626862 	ldrb	w2, [x3, x2]
    b2cc:	7100085f 	cmp	w2, #0x2
    b2d0:	54007920 	b.eq	c1f4 <f0+0x24a4>  // b.none
    b2d4:	7100045f 	cmp	w2, #0x1
    b2d8:	540001a1 	b.ne	b30c <f0+0x15bc>  // b.any
    b2dc:	29430002 	ldp	w2, w0, [x0, #24]
    b2e0:	92403c21 	and	x1, x1, #0xffff
    b2e4:	9b027c21 	mul	x1, x1, x2
    b2e8:	d360fc21 	lsr	x1, x1, #32
    b2ec:	eb00003f 	cmp	x1, x0
    b2f0:	540000e2 	b.cs	b30c <f0+0x15bc>  // b.hs, b.nlast
    b2f4:	8b0102f7 	add	x23, x23, x1
    b2f8:	394002e0 	ldrb	w0, [x23]
    b2fc:	7103fc1f 	cmp	w0, #0xff
    b300:	54008100 	b.eq	c320 <f0+0x25d0>  // b.none
    b304:	52800020 	mov	w0, #0x1                   	// #1
    b308:	390002e0 	strb	w0, [x23]
    b30c:	911563e1 	add	x1, sp, #0x558
    b310:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b314:	52800020 	mov	w0, #0x1                   	// #1
    b318:	f902aff7 	str	x23, [sp, #1368]
    b31c:	f902b3f5 	str	x21, [sp, #1376]
    b320:	97ffe759 	bl	5084 <fwp_data.part.0.constprop.0>
    b324:	97ffe92f 	bl	57e0 <fwp_rc_fresh>
    b328:	aa0003e2 	mov	x2, x0
    b32c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b330:	9115a3e1 	add	x1, sp, #0x568
    b334:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b338:	52800020 	mov	w0, #0x1                   	// #1
    b33c:	f902b7e3 	str	x3, [sp, #1384]
    b340:	f902bbe2 	str	x2, [sp, #1392]
    b344:	97ffe750 	bl	5084 <fwp_data.part.0.constprop.0>
    b348:	97ffe926 	bl	57e0 <fwp_rc_fresh>
    b34c:	aa0003e2 	mov	x2, x0
    b350:	9115e3e1 	add	x1, sp, #0x578
    b354:	52800020 	mov	w0, #0x1                   	// #1
    b358:	f902bff7 	str	x23, [sp, #1400]
    b35c:	f902c3e2 	str	x2, [sp, #1408]
    b360:	97ffe749 	bl	5084 <fwp_data.part.0.constprop.0>
    b364:	91174283 	add	x3, x20, #0x5d0
    b368:	aa0003f5 	mov	x21, x0
    b36c:	f949d861 	ldr	x1, [x3, #5040]
    b370:	f949ec60 	ldr	x0, [x3, #5080]
    b374:	cb0102a1 	sub	x1, x21, x1
    b378:	eb00403f 	cmp	x1, x0, lsl #16
    b37c:	54000322 	b.cs	b3e0 <f0+0x1690>  // b.hs, b.nlast
    b380:	d350fc22 	lsr	x2, x1, #16
    b384:	f949fc63 	ldr	x3, [x3, #5112]
    b388:	8b020842 	add	x2, x2, x2, lsl #2
    b38c:	d37df042 	lsl	x2, x2, #3
    b390:	8b020060 	add	x0, x3, x2
    b394:	f9401017 	ldr	x23, [x0, #32]
    b398:	b4000257 	cbz	x23, b3e0 <f0+0x1690>
    b39c:	38626862 	ldrb	w2, [x3, x2]
    b3a0:	7100085f 	cmp	w2, #0x2
    b3a4:	54007220 	b.eq	c1e8 <f0+0x2498>  // b.none
    b3a8:	7100045f 	cmp	w2, #0x1
    b3ac:	540001a1 	b.ne	b3e0 <f0+0x1690>  // b.any
    b3b0:	29430002 	ldp	w2, w0, [x0, #24]
    b3b4:	92403c21 	and	x1, x1, #0xffff
    b3b8:	9b027c21 	mul	x1, x1, x2
    b3bc:	d360fc21 	lsr	x1, x1, #32
    b3c0:	eb00003f 	cmp	x1, x0
    b3c4:	540000e2 	b.cs	b3e0 <f0+0x1690>  // b.hs, b.nlast
    b3c8:	8b0102f7 	add	x23, x23, x1
    b3cc:	394002e0 	ldrb	w0, [x23]
    b3d0:	7103fc1f 	cmp	w0, #0xff
    b3d4:	54007ac0 	b.eq	c32c <f0+0x25dc>  // b.none
    b3d8:	52800020 	mov	w0, #0x1                   	// #1
    b3dc:	390002e0 	strb	w0, [x23]
    b3e0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b3e4:	911623e1 	add	x1, sp, #0x588
    b3e8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b3ec:	52800020 	mov	w0, #0x1                   	// #1
    b3f0:	f902c7e2 	str	x2, [sp, #1416]
    b3f4:	f902cbf5 	str	x21, [sp, #1424]
    b3f8:	97ffe723 	bl	5084 <fwp_data.part.0.constprop.0>
    b3fc:	97ffe8f9 	bl	57e0 <fwp_rc_fresh>
    b400:	aa0003e2 	mov	x2, x0
    b404:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b408:	911663e1 	add	x1, sp, #0x598
    b40c:	52800020 	mov	w0, #0x1                   	// #1
    b410:	f902cfe3 	str	x3, [sp, #1432]
    b414:	f902d3e2 	str	x2, [sp, #1440]
    b418:	97ffe71b 	bl	5084 <fwp_data.part.0.constprop.0>
    b41c:	91174283 	add	x3, x20, #0x5d0
    b420:	aa0003f5 	mov	x21, x0
    b424:	f949d861 	ldr	x1, [x3, #5040]
    b428:	f949ec60 	ldr	x0, [x3, #5080]
    b42c:	cb0102a1 	sub	x1, x21, x1
    b430:	eb00403f 	cmp	x1, x0, lsl #16
    b434:	54000322 	b.cs	b498 <f0+0x1748>  // b.hs, b.nlast
    b438:	d350fc22 	lsr	x2, x1, #16
    b43c:	f949fc63 	ldr	x3, [x3, #5112]
    b440:	8b020842 	add	x2, x2, x2, lsl #2
    b444:	d37df042 	lsl	x2, x2, #3
    b448:	8b020060 	add	x0, x3, x2
    b44c:	f9401017 	ldr	x23, [x0, #32]
    b450:	b4000257 	cbz	x23, b498 <f0+0x1748>
    b454:	38626862 	ldrb	w2, [x3, x2]
    b458:	7100085f 	cmp	w2, #0x2
    b45c:	54006c00 	b.eq	c1dc <f0+0x248c>  // b.none
    b460:	7100045f 	cmp	w2, #0x1
    b464:	540001a1 	b.ne	b498 <f0+0x1748>  // b.any
    b468:	29430002 	ldp	w2, w0, [x0, #24]
    b46c:	92403c21 	and	x1, x1, #0xffff
    b470:	9b027c21 	mul	x1, x1, x2
    b474:	d360fc21 	lsr	x1, x1, #32
    b478:	eb00003f 	cmp	x1, x0
    b47c:	540000e2 	b.cs	b498 <f0+0x1748>  // b.hs, b.nlast
    b480:	8b0102f7 	add	x23, x23, x1
    b484:	394002e0 	ldrb	w0, [x23]
    b488:	7103fc1f 	cmp	w0, #0xff
    b48c:	54007560 	b.eq	c338 <f0+0x25e8>  // b.none
    b490:	52800020 	mov	w0, #0x1                   	// #1
    b494:	390002e0 	strb	w0, [x23]
    b498:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b49c:	9116a3e1 	add	x1, sp, #0x5a8
    b4a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b4a4:	52800020 	mov	w0, #0x1                   	// #1
    b4a8:	f902d7e2 	str	x2, [sp, #1448]
    b4ac:	f902dbf5 	str	x21, [sp, #1456]
    b4b0:	97ffe6f5 	bl	5084 <fwp_data.part.0.constprop.0>
    b4b4:	97ffe8cb 	bl	57e0 <fwp_rc_fresh>
    b4b8:	aa0003e2 	mov	x2, x0
    b4bc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4c0:	9116e3e1 	add	x1, sp, #0x5b8
    b4c4:	52800020 	mov	w0, #0x1                   	// #1
    b4c8:	f902dfe3 	str	x3, [sp, #1464]
    b4cc:	f902e3e2 	str	x2, [sp, #1472]
    b4d0:	97ffe6ed 	bl	5084 <fwp_data.part.0.constprop.0>
    b4d4:	91174283 	add	x3, x20, #0x5d0
    b4d8:	aa0003f5 	mov	x21, x0
    b4dc:	f949d861 	ldr	x1, [x3, #5040]
    b4e0:	f949ec60 	ldr	x0, [x3, #5080]
    b4e4:	cb0102a1 	sub	x1, x21, x1
    b4e8:	eb00403f 	cmp	x1, x0, lsl #16
    b4ec:	54000322 	b.cs	b550 <f0+0x1800>  // b.hs, b.nlast
    b4f0:	d350fc22 	lsr	x2, x1, #16
    b4f4:	f949fc63 	ldr	x3, [x3, #5112]
    b4f8:	8b020842 	add	x2, x2, x2, lsl #2
    b4fc:	d37df042 	lsl	x2, x2, #3
    b500:	8b020060 	add	x0, x3, x2
    b504:	f9401017 	ldr	x23, [x0, #32]
    b508:	b4000257 	cbz	x23, b550 <f0+0x1800>
    b50c:	38626862 	ldrb	w2, [x3, x2]
    b510:	7100085f 	cmp	w2, #0x2
    b514:	540065e0 	b.eq	c1d0 <f0+0x2480>  // b.none
    b518:	7100045f 	cmp	w2, #0x1
    b51c:	540001a1 	b.ne	b550 <f0+0x1800>  // b.any
    b520:	29430002 	ldp	w2, w0, [x0, #24]
    b524:	92403c21 	and	x1, x1, #0xffff
    b528:	9b027c21 	mul	x1, x1, x2
    b52c:	d360fc21 	lsr	x1, x1, #32
    b530:	eb00003f 	cmp	x1, x0
    b534:	540000e2 	b.cs	b550 <f0+0x1800>  // b.hs, b.nlast
    b538:	8b0102f7 	add	x23, x23, x1
    b53c:	394002e0 	ldrb	w0, [x23]
    b540:	7103fc1f 	cmp	w0, #0xff
    b544:	54007000 	b.eq	c344 <f0+0x25f4>  // b.none
    b548:	52800020 	mov	w0, #0x1                   	// #1
    b54c:	390002e0 	strb	w0, [x23]
    b550:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b554:	911723e1 	add	x1, sp, #0x5c8
    b558:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b55c:	52800020 	mov	w0, #0x1                   	// #1
    b560:	f902e7e2 	str	x2, [sp, #1480]
    b564:	f902ebf5 	str	x21, [sp, #1488]
    b568:	97ffe6c7 	bl	5084 <fwp_data.part.0.constprop.0>
    b56c:	91174283 	add	x3, x20, #0x5d0
    b570:	aa0003f5 	mov	x21, x0
    b574:	f949d861 	ldr	x1, [x3, #5040]
    b578:	f949ec60 	ldr	x0, [x3, #5080]
    b57c:	cb0102a1 	sub	x1, x21, x1
    b580:	eb00403f 	cmp	x1, x0, lsl #16
    b584:	54000322 	b.cs	b5e8 <f0+0x1898>  // b.hs, b.nlast
    b588:	d350fc22 	lsr	x2, x1, #16
    b58c:	f949fc63 	ldr	x3, [x3, #5112]
    b590:	8b020842 	add	x2, x2, x2, lsl #2
    b594:	d37df042 	lsl	x2, x2, #3
    b598:	8b020060 	add	x0, x3, x2
    b59c:	f9401017 	ldr	x23, [x0, #32]
    b5a0:	b4000257 	cbz	x23, b5e8 <f0+0x1898>
    b5a4:	38626862 	ldrb	w2, [x3, x2]
    b5a8:	7100085f 	cmp	w2, #0x2
    b5ac:	540060c0 	b.eq	c1c4 <f0+0x2474>  // b.none
    b5b0:	7100045f 	cmp	w2, #0x1
    b5b4:	540001a1 	b.ne	b5e8 <f0+0x1898>  // b.any
    b5b8:	29430002 	ldp	w2, w0, [x0, #24]
    b5bc:	92403c21 	and	x1, x1, #0xffff
    b5c0:	9b027c21 	mul	x1, x1, x2
    b5c4:	d360fc21 	lsr	x1, x1, #32
    b5c8:	eb00003f 	cmp	x1, x0
    b5cc:	540000e2 	b.cs	b5e8 <f0+0x1898>  // b.hs, b.nlast
    b5d0:	8b0102f7 	add	x23, x23, x1
    b5d4:	394002e0 	ldrb	w0, [x23]
    b5d8:	7103fc1f 	cmp	w0, #0xff
    b5dc:	54006ba0 	b.eq	c350 <f0+0x2600>  // b.none
    b5e0:	52800020 	mov	w0, #0x1                   	// #1
    b5e4:	390002e0 	strb	w0, [x23]
    b5e8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b5ec:	911763e1 	add	x1, sp, #0x5d8
    b5f0:	52800020 	mov	w0, #0x1                   	// #1
    b5f4:	f902efe2 	str	x2, [sp, #1496]
    b5f8:	f902f3f5 	str	x21, [sp, #1504]
    b5fc:	97ffe6a2 	bl	5084 <fwp_data.part.0.constprop.0>
    b600:	91174283 	add	x3, x20, #0x5d0
    b604:	aa0003f5 	mov	x21, x0
    b608:	f949d861 	ldr	x1, [x3, #5040]
    b60c:	f949ec60 	ldr	x0, [x3, #5080]
    b610:	cb0102a1 	sub	x1, x21, x1
    b614:	eb00403f 	cmp	x1, x0, lsl #16
    b618:	54000322 	b.cs	b67c <f0+0x192c>  // b.hs, b.nlast
    b61c:	d350fc22 	lsr	x2, x1, #16
    b620:	f949fc63 	ldr	x3, [x3, #5112]
    b624:	8b020842 	add	x2, x2, x2, lsl #2
    b628:	d37df042 	lsl	x2, x2, #3
    b62c:	8b020060 	add	x0, x3, x2
    b630:	f9401017 	ldr	x23, [x0, #32]
    b634:	b4000257 	cbz	x23, b67c <f0+0x192c>
    b638:	38626862 	ldrb	w2, [x3, x2]
    b63c:	7100085f 	cmp	w2, #0x2
    b640:	54005bc0 	b.eq	c1b8 <f0+0x2468>  // b.none
    b644:	7100045f 	cmp	w2, #0x1
    b648:	540001a1 	b.ne	b67c <f0+0x192c>  // b.any
    b64c:	29430002 	ldp	w2, w0, [x0, #24]
    b650:	92403c21 	and	x1, x1, #0xffff
    b654:	9b027c21 	mul	x1, x1, x2
    b658:	d360fc21 	lsr	x1, x1, #32
    b65c:	eb00003f 	cmp	x1, x0
    b660:	540000e2 	b.cs	b67c <f0+0x192c>  // b.hs, b.nlast
    b664:	8b0102f7 	add	x23, x23, x1
    b668:	394002e0 	ldrb	w0, [x23]
    b66c:	7103fc1f 	cmp	w0, #0xff
    b670:	54006760 	b.eq	c35c <f0+0x260c>  // b.none
    b674:	52800020 	mov	w0, #0x1                   	// #1
    b678:	390002e0 	strb	w0, [x23]
    b67c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b680:	9117a3e1 	add	x1, sp, #0x5e8
    b684:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b688:	52800020 	mov	w0, #0x1                   	// #1
    b68c:	f902f7e2 	str	x2, [sp, #1512]
    b690:	f902fbf5 	str	x21, [sp, #1520]
    b694:	97ffe67c 	bl	5084 <fwp_data.part.0.constprop.0>
    b698:	97ffe852 	bl	57e0 <fwp_rc_fresh>
    b69c:	aa0003e2 	mov	x2, x0
    b6a0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b6a4:	9117e3e1 	add	x1, sp, #0x5f8
    b6a8:	52800020 	mov	w0, #0x1                   	// #1
    b6ac:	f902ffe3 	str	x3, [sp, #1528]
    b6b0:	f90303e2 	str	x2, [sp, #1536]
    b6b4:	97ffe674 	bl	5084 <fwp_data.part.0.constprop.0>
    b6b8:	91174283 	add	x3, x20, #0x5d0
    b6bc:	aa0003f5 	mov	x21, x0
    b6c0:	f949d861 	ldr	x1, [x3, #5040]
    b6c4:	f949ec60 	ldr	x0, [x3, #5080]
    b6c8:	cb0102a1 	sub	x1, x21, x1
    b6cc:	eb00403f 	cmp	x1, x0, lsl #16
    b6d0:	54000322 	b.cs	b734 <f0+0x19e4>  // b.hs, b.nlast
    b6d4:	d350fc22 	lsr	x2, x1, #16
    b6d8:	f949fc63 	ldr	x3, [x3, #5112]
    b6dc:	8b020842 	add	x2, x2, x2, lsl #2
    b6e0:	d37df042 	lsl	x2, x2, #3
    b6e4:	8b020060 	add	x0, x3, x2
    b6e8:	f9401017 	ldr	x23, [x0, #32]
    b6ec:	b4000257 	cbz	x23, b734 <f0+0x19e4>
    b6f0:	38626862 	ldrb	w2, [x3, x2]
    b6f4:	7100085f 	cmp	w2, #0x2
    b6f8:	540055a0 	b.eq	c1ac <f0+0x245c>  // b.none
    b6fc:	7100045f 	cmp	w2, #0x1
    b700:	540001a1 	b.ne	b734 <f0+0x19e4>  // b.any
    b704:	29430002 	ldp	w2, w0, [x0, #24]
    b708:	92403c21 	and	x1, x1, #0xffff
    b70c:	9b027c21 	mul	x1, x1, x2
    b710:	d360fc21 	lsr	x1, x1, #32
    b714:	eb00003f 	cmp	x1, x0
    b718:	540000e2 	b.cs	b734 <f0+0x19e4>  // b.hs, b.nlast
    b71c:	8b0102f7 	add	x23, x23, x1
    b720:	394002e0 	ldrb	w0, [x23]
    b724:	7103fc1f 	cmp	w0, #0xff
    b728:	54006200 	b.eq	c368 <f0+0x2618>  // b.none
    b72c:	52800020 	mov	w0, #0x1                   	// #1
    b730:	390002e0 	strb	w0, [x23]
    b734:	911823e1 	add	x1, sp, #0x608
    b738:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b73c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b740:	52800020 	mov	w0, #0x1                   	// #1
    b744:	f90307f7 	str	x23, [sp, #1544]
    b748:	f9030bf5 	str	x21, [sp, #1552]
    b74c:	97ffe64e 	bl	5084 <fwp_data.part.0.constprop.0>
    b750:	97ffe824 	bl	57e0 <fwp_rc_fresh>
    b754:	aa0003e2 	mov	x2, x0
    b758:	911863e1 	add	x1, sp, #0x618
    b75c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b760:	52800020 	mov	w0, #0x1                   	// #1
    b764:	f9030ff5 	str	x21, [sp, #1560]
    b768:	f90313e2 	str	x2, [sp, #1568]
    b76c:	97ffe646 	bl	5084 <fwp_data.part.0.constprop.0>
    b770:	97ffe81c 	bl	57e0 <fwp_rc_fresh>
    b774:	aa0003e2 	mov	x2, x0
    b778:	9118a3e1 	add	x1, sp, #0x628
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	f90317f7 	str	x23, [sp, #1576]
    b784:	f9031be2 	str	x2, [sp, #1584]
    b788:	97ffe63f 	bl	5084 <fwp_data.part.0.constprop.0>
    b78c:	97ffe815 	bl	57e0 <fwp_rc_fresh>
    b790:	aa0003e2 	mov	x2, x0
    b794:	9118e3e1 	add	x1, sp, #0x638
    b798:	52800020 	mov	w0, #0x1                   	// #1
    b79c:	f9031ff5 	str	x21, [sp, #1592]
    b7a0:	f90323e2 	str	x2, [sp, #1600]
    b7a4:	97ffe638 	bl	5084 <fwp_data.part.0.constprop.0>
    b7a8:	97ffe80e 	bl	57e0 <fwp_rc_fresh>
    b7ac:	aa0003e2 	mov	x2, x0
    b7b0:	911923e1 	add	x1, sp, #0x648
    b7b4:	52800020 	mov	w0, #0x1                   	// #1
    b7b8:	f90327f7 	str	x23, [sp, #1608]
    b7bc:	f9032be2 	str	x2, [sp, #1616]
    b7c0:	97ffe631 	bl	5084 <fwp_data.part.0.constprop.0>
    b7c4:	91174283 	add	x3, x20, #0x5d0
    b7c8:	aa0003f5 	mov	x21, x0
    b7cc:	f949d861 	ldr	x1, [x3, #5040]
    b7d0:	f949ec60 	ldr	x0, [x3, #5080]
    b7d4:	cb0102a1 	sub	x1, x21, x1
    b7d8:	eb00403f 	cmp	x1, x0, lsl #16
    b7dc:	54000322 	b.cs	b840 <f0+0x1af0>  // b.hs, b.nlast
    b7e0:	d350fc22 	lsr	x2, x1, #16
    b7e4:	f949fc63 	ldr	x3, [x3, #5112]
    b7e8:	8b020842 	add	x2, x2, x2, lsl #2
    b7ec:	d37df042 	lsl	x2, x2, #3
    b7f0:	8b020060 	add	x0, x3, x2
    b7f4:	f9401017 	ldr	x23, [x0, #32]
    b7f8:	b4000257 	cbz	x23, b840 <f0+0x1af0>
    b7fc:	38626862 	ldrb	w2, [x3, x2]
    b800:	7100085f 	cmp	w2, #0x2
    b804:	54004ce0 	b.eq	c1a0 <f0+0x2450>  // b.none
    b808:	7100045f 	cmp	w2, #0x1
    b80c:	540001a1 	b.ne	b840 <f0+0x1af0>  // b.any
    b810:	29430002 	ldp	w2, w0, [x0, #24]
    b814:	92403c21 	and	x1, x1, #0xffff
    b818:	9b027c21 	mul	x1, x1, x2
    b81c:	d360fc21 	lsr	x1, x1, #32
    b820:	eb00003f 	cmp	x1, x0
    b824:	540000e2 	b.cs	b840 <f0+0x1af0>  // b.hs, b.nlast
    b828:	8b0102f7 	add	x23, x23, x1
    b82c:	394002e0 	ldrb	w0, [x23]
    b830:	7103fc1f 	cmp	w0, #0xff
    b834:	54005a00 	b.eq	c374 <f0+0x2624>  // b.none
    b838:	52800020 	mov	w0, #0x1                   	// #1
    b83c:	390002e0 	strb	w0, [x23]
    b840:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b844:	911963e1 	add	x1, sp, #0x658
    b848:	52800020 	mov	w0, #0x1                   	// #1
    b84c:	f9032fe2 	str	x2, [sp, #1624]
    b850:	f90333f5 	str	x21, [sp, #1632]
    b854:	97ffe60c 	bl	5084 <fwp_data.part.0.constprop.0>
    b858:	91174283 	add	x3, x20, #0x5d0
    b85c:	aa0003f5 	mov	x21, x0
    b860:	f949d861 	ldr	x1, [x3, #5040]
    b864:	f949ec60 	ldr	x0, [x3, #5080]
    b868:	cb0102a1 	sub	x1, x21, x1
    b86c:	eb00403f 	cmp	x1, x0, lsl #16
    b870:	54000322 	b.cs	b8d4 <f0+0x1b84>  // b.hs, b.nlast
    b874:	d350fc22 	lsr	x2, x1, #16
    b878:	f949fc63 	ldr	x3, [x3, #5112]
    b87c:	8b020842 	add	x2, x2, x2, lsl #2
    b880:	d37df042 	lsl	x2, x2, #3
    b884:	8b020060 	add	x0, x3, x2
    b888:	f9401017 	ldr	x23, [x0, #32]
    b88c:	b4000257 	cbz	x23, b8d4 <f0+0x1b84>
    b890:	38626862 	ldrb	w2, [x3, x2]
    b894:	7100085f 	cmp	w2, #0x2
    b898:	540047e0 	b.eq	c194 <f0+0x2444>  // b.none
    b89c:	7100045f 	cmp	w2, #0x1
    b8a0:	540001a1 	b.ne	b8d4 <f0+0x1b84>  // b.any
    b8a4:	29430002 	ldp	w2, w0, [x0, #24]
    b8a8:	92403c21 	and	x1, x1, #0xffff
    b8ac:	9b027c21 	mul	x1, x1, x2
    b8b0:	d360fc21 	lsr	x1, x1, #32
    b8b4:	eb00003f 	cmp	x1, x0
    b8b8:	540000e2 	b.cs	b8d4 <f0+0x1b84>  // b.hs, b.nlast
    b8bc:	8b0102f7 	add	x23, x23, x1
    b8c0:	394002e0 	ldrb	w0, [x23]
    b8c4:	7103fc1f 	cmp	w0, #0xff
    b8c8:	540055c0 	b.eq	c380 <f0+0x2630>  // b.none
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	390002e0 	strb	w0, [x23]
    b8d4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b8d8:	9119a3e1 	add	x1, sp, #0x668
    b8dc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b8e0:	52800020 	mov	w0, #0x1                   	// #1
    b8e4:	f90337e2 	str	x2, [sp, #1640]
    b8e8:	f9033bf5 	str	x21, [sp, #1648]
    b8ec:	97ffe5e6 	bl	5084 <fwp_data.part.0.constprop.0>
    b8f0:	97ffe7bc 	bl	57e0 <fwp_rc_fresh>
    b8f4:	aa0003e2 	mov	x2, x0
    b8f8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b8fc:	9119e3e1 	add	x1, sp, #0x678
    b900:	52800020 	mov	w0, #0x1                   	// #1
    b904:	f9033fe3 	str	x3, [sp, #1656]
    b908:	f90343e2 	str	x2, [sp, #1664]
    b90c:	97ffe5de 	bl	5084 <fwp_data.part.0.constprop.0>
    b910:	91174283 	add	x3, x20, #0x5d0
    b914:	aa0003f5 	mov	x21, x0
    b918:	f949d861 	ldr	x1, [x3, #5040]
    b91c:	f949ec60 	ldr	x0, [x3, #5080]
    b920:	cb0102a1 	sub	x1, x21, x1
    b924:	eb00403f 	cmp	x1, x0, lsl #16
    b928:	54000322 	b.cs	b98c <f0+0x1c3c>  // b.hs, b.nlast
    b92c:	d350fc22 	lsr	x2, x1, #16
    b930:	f949fc63 	ldr	x3, [x3, #5112]
    b934:	8b020842 	add	x2, x2, x2, lsl #2
    b938:	d37df042 	lsl	x2, x2, #3
    b93c:	8b020060 	add	x0, x3, x2
    b940:	f9401017 	ldr	x23, [x0, #32]
    b944:	b4000257 	cbz	x23, b98c <f0+0x1c3c>
    b948:	38626862 	ldrb	w2, [x3, x2]
    b94c:	7100085f 	cmp	w2, #0x2
    b950:	540041c0 	b.eq	c188 <f0+0x2438>  // b.none
    b954:	7100045f 	cmp	w2, #0x1
    b958:	540001a1 	b.ne	b98c <f0+0x1c3c>  // b.any
    b95c:	29430002 	ldp	w2, w0, [x0, #24]
    b960:	92403c21 	and	x1, x1, #0xffff
    b964:	9b027c21 	mul	x1, x1, x2
    b968:	d360fc21 	lsr	x1, x1, #32
    b96c:	eb00003f 	cmp	x1, x0
    b970:	540000e2 	b.cs	b98c <f0+0x1c3c>  // b.hs, b.nlast
    b974:	8b0102f7 	add	x23, x23, x1
    b978:	394002e0 	ldrb	w0, [x23]
    b97c:	7103fc1f 	cmp	w0, #0xff
    b980:	54005060 	b.eq	c38c <f0+0x263c>  // b.none
    b984:	52800020 	mov	w0, #0x1                   	// #1
    b988:	390002e0 	strb	w0, [x23]
    b98c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b990:	911a23e1 	add	x1, sp, #0x688
    b994:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b998:	52800020 	mov	w0, #0x1                   	// #1
    b99c:	f90347e2 	str	x2, [sp, #1672]
    b9a0:	f9034bf5 	str	x21, [sp, #1680]
    b9a4:	97ffe5b8 	bl	5084 <fwp_data.part.0.constprop.0>
    b9a8:	97ffe78e 	bl	57e0 <fwp_rc_fresh>
    b9ac:	aa0003e2 	mov	x2, x0
    b9b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b9b4:	911a63e1 	add	x1, sp, #0x698
    b9b8:	52800020 	mov	w0, #0x1                   	// #1
    b9bc:	f9034fe3 	str	x3, [sp, #1688]
    b9c0:	f90353e2 	str	x2, [sp, #1696]
    b9c4:	97ffe5b0 	bl	5084 <fwp_data.part.0.constprop.0>
    b9c8:	91174283 	add	x3, x20, #0x5d0
    b9cc:	aa0003f5 	mov	x21, x0
    b9d0:	f949d861 	ldr	x1, [x3, #5040]
    b9d4:	f949ec60 	ldr	x0, [x3, #5080]
    b9d8:	cb0102a1 	sub	x1, x21, x1
    b9dc:	eb00403f 	cmp	x1, x0, lsl #16
    b9e0:	54000322 	b.cs	ba44 <f0+0x1cf4>  // b.hs, b.nlast
    b9e4:	d350fc22 	lsr	x2, x1, #16
    b9e8:	f949fc63 	ldr	x3, [x3, #5112]
    b9ec:	8b020842 	add	x2, x2, x2, lsl #2
    b9f0:	d37df042 	lsl	x2, x2, #3
    b9f4:	8b020060 	add	x0, x3, x2
    b9f8:	f9401017 	ldr	x23, [x0, #32]
    b9fc:	b4000257 	cbz	x23, ba44 <f0+0x1cf4>
    ba00:	38626862 	ldrb	w2, [x3, x2]
    ba04:	7100085f 	cmp	w2, #0x2
    ba08:	54003ba0 	b.eq	c17c <f0+0x242c>  // b.none
    ba0c:	7100045f 	cmp	w2, #0x1
    ba10:	540001a1 	b.ne	ba44 <f0+0x1cf4>  // b.any
    ba14:	29430002 	ldp	w2, w0, [x0, #24]
    ba18:	92403c21 	and	x1, x1, #0xffff
    ba1c:	9b027c21 	mul	x1, x1, x2
    ba20:	d360fc21 	lsr	x1, x1, #32
    ba24:	eb00003f 	cmp	x1, x0
    ba28:	540000e2 	b.cs	ba44 <f0+0x1cf4>  // b.hs, b.nlast
    ba2c:	8b0102f7 	add	x23, x23, x1
    ba30:	394002e0 	ldrb	w0, [x23]
    ba34:	7103fc1f 	cmp	w0, #0xff
    ba38:	54004b00 	b.eq	c398 <f0+0x2648>  // b.none
    ba3c:	52800020 	mov	w0, #0x1                   	// #1
    ba40:	390002e0 	strb	w0, [x23]
    ba44:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ba48:	911aa3e1 	add	x1, sp, #0x6a8
    ba4c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ba50:	52800020 	mov	w0, #0x1                   	// #1
    ba54:	f90357e2 	str	x2, [sp, #1704]
    ba58:	f9035bf5 	str	x21, [sp, #1712]
    ba5c:	97ffe58a 	bl	5084 <fwp_data.part.0.constprop.0>
    ba60:	97ffe760 	bl	57e0 <fwp_rc_fresh>
    ba64:	aa0003e2 	mov	x2, x0
    ba68:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ba6c:	911ae3e1 	add	x1, sp, #0x6b8
    ba70:	52800020 	mov	w0, #0x1                   	// #1
    ba74:	f9035fe3 	str	x3, [sp, #1720]
    ba78:	f90363e2 	str	x2, [sp, #1728]
    ba7c:	97ffe582 	bl	5084 <fwp_data.part.0.constprop.0>
    ba80:	91174283 	add	x3, x20, #0x5d0
    ba84:	aa0003f5 	mov	x21, x0
    ba88:	f949d861 	ldr	x1, [x3, #5040]
    ba8c:	f949ec60 	ldr	x0, [x3, #5080]
    ba90:	cb0102a1 	sub	x1, x21, x1
    ba94:	eb00403f 	cmp	x1, x0, lsl #16
    ba98:	54000322 	b.cs	bafc <f0+0x1dac>  // b.hs, b.nlast
    ba9c:	d350fc22 	lsr	x2, x1, #16
    baa0:	f949fc63 	ldr	x3, [x3, #5112]
    baa4:	8b020842 	add	x2, x2, x2, lsl #2
    baa8:	d37df042 	lsl	x2, x2, #3
    baac:	8b020060 	add	x0, x3, x2
    bab0:	f9401017 	ldr	x23, [x0, #32]
    bab4:	b4000257 	cbz	x23, bafc <f0+0x1dac>
    bab8:	38626862 	ldrb	w2, [x3, x2]
    babc:	7100085f 	cmp	w2, #0x2
    bac0:	54003580 	b.eq	c170 <f0+0x2420>  // b.none
    bac4:	7100045f 	cmp	w2, #0x1
    bac8:	540001a1 	b.ne	bafc <f0+0x1dac>  // b.any
    bacc:	29430002 	ldp	w2, w0, [x0, #24]
    bad0:	92403c21 	and	x1, x1, #0xffff
    bad4:	9b027c21 	mul	x1, x1, x2
    bad8:	d360fc21 	lsr	x1, x1, #32
    badc:	eb00003f 	cmp	x1, x0
    bae0:	540000e2 	b.cs	bafc <f0+0x1dac>  // b.hs, b.nlast
    bae4:	8b0102f7 	add	x23, x23, x1
    bae8:	394002e0 	ldrb	w0, [x23]
    baec:	7103fc1f 	cmp	w0, #0xff
    baf0:	540045a0 	b.eq	c3a4 <f0+0x2654>  // b.none
    baf4:	52800020 	mov	w0, #0x1                   	// #1
    baf8:	390002e0 	strb	w0, [x23]
    bafc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bb00:	911b23e1 	add	x1, sp, #0x6c8
    bb04:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bb08:	52800020 	mov	w0, #0x1                   	// #1
    bb0c:	f90367e2 	str	x2, [sp, #1736]
    bb10:	f9036bf5 	str	x21, [sp, #1744]
    bb14:	97ffe55c 	bl	5084 <fwp_data.part.0.constprop.0>
    bb18:	91174283 	add	x3, x20, #0x5d0
    bb1c:	aa0003f5 	mov	x21, x0
    bb20:	f949d861 	ldr	x1, [x3, #5040]
    bb24:	f949ec60 	ldr	x0, [x3, #5080]
    bb28:	cb0102a1 	sub	x1, x21, x1
    bb2c:	eb00403f 	cmp	x1, x0, lsl #16
    bb30:	54000322 	b.cs	bb94 <f0+0x1e44>  // b.hs, b.nlast
    bb34:	d350fc22 	lsr	x2, x1, #16
    bb38:	f949fc63 	ldr	x3, [x3, #5112]
    bb3c:	8b020842 	add	x2, x2, x2, lsl #2
    bb40:	d37df042 	lsl	x2, x2, #3
    bb44:	8b020060 	add	x0, x3, x2
    bb48:	f9401017 	ldr	x23, [x0, #32]
    bb4c:	b4000257 	cbz	x23, bb94 <f0+0x1e44>
    bb50:	38626862 	ldrb	w2, [x3, x2]
    bb54:	7100085f 	cmp	w2, #0x2
    bb58:	54003060 	b.eq	c164 <f0+0x2414>  // b.none
    bb5c:	7100045f 	cmp	w2, #0x1
    bb60:	540001a1 	b.ne	bb94 <f0+0x1e44>  // b.any
    bb64:	29430002 	ldp	w2, w0, [x0, #24]
    bb68:	92403c21 	and	x1, x1, #0xffff
    bb6c:	9b027c21 	mul	x1, x1, x2
    bb70:	d360fc21 	lsr	x1, x1, #32
    bb74:	eb00003f 	cmp	x1, x0
    bb78:	540000e2 	b.cs	bb94 <f0+0x1e44>  // b.hs, b.nlast
    bb7c:	8b0102f7 	add	x23, x23, x1
    bb80:	394002e0 	ldrb	w0, [x23]
    bb84:	7103fc1f 	cmp	w0, #0xff
    bb88:	54004140 	b.eq	c3b0 <f0+0x2660>  // b.none
    bb8c:	52800020 	mov	w0, #0x1                   	// #1
    bb90:	390002e0 	strb	w0, [x23]
    bb94:	911b63e1 	add	x1, sp, #0x6d8
    bb98:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	f9036ff7 	str	x23, [sp, #1752]
    bba4:	f90373f5 	str	x21, [sp, #1760]
    bba8:	97ffe537 	bl	5084 <fwp_data.part.0.constprop.0>
    bbac:	97ffe70d 	bl	57e0 <fwp_rc_fresh>
    bbb0:	aa0003e2 	mov	x2, x0
    bbb4:	911ba3e1 	add	x1, sp, #0x6e8
    bbb8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bbbc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bbc0:	52800020 	mov	w0, #0x1                   	// #1
    bbc4:	f90377f5 	str	x21, [sp, #1768]
    bbc8:	f9037be2 	str	x2, [sp, #1776]
    bbcc:	97ffe52e 	bl	5084 <fwp_data.part.0.constprop.0>
    bbd0:	97ffe704 	bl	57e0 <fwp_rc_fresh>
    bbd4:	aa0003e2 	mov	x2, x0
    bbd8:	911be3e1 	add	x1, sp, #0x6f8
    bbdc:	52800020 	mov	w0, #0x1                   	// #1
    bbe0:	f9037ff7 	str	x23, [sp, #1784]
    bbe4:	f90383e2 	str	x2, [sp, #1792]
    bbe8:	97ffe527 	bl	5084 <fwp_data.part.0.constprop.0>
    bbec:	97ffe6fd 	bl	57e0 <fwp_rc_fresh>
    bbf0:	aa0003e2 	mov	x2, x0
    bbf4:	911c23e1 	add	x1, sp, #0x708
    bbf8:	52800020 	mov	w0, #0x1                   	// #1
    bbfc:	f90387f5 	str	x21, [sp, #1800]
    bc00:	f9038be2 	str	x2, [sp, #1808]
    bc04:	97ffe520 	bl	5084 <fwp_data.part.0.constprop.0>
    bc08:	97ffe6f6 	bl	57e0 <fwp_rc_fresh>
    bc0c:	aa0003e2 	mov	x2, x0
    bc10:	911c63e1 	add	x1, sp, #0x718
    bc14:	52800020 	mov	w0, #0x1                   	// #1
    bc18:	f9038ff7 	str	x23, [sp, #1816]
    bc1c:	f90393e2 	str	x2, [sp, #1824]
    bc20:	97ffe519 	bl	5084 <fwp_data.part.0.constprop.0>
    bc24:	97ffe6ef 	bl	57e0 <fwp_rc_fresh>
    bc28:	aa0003e2 	mov	x2, x0
    bc2c:	911ca3e1 	add	x1, sp, #0x728
    bc30:	52800020 	mov	w0, #0x1                   	// #1
    bc34:	f90397f5 	str	x21, [sp, #1832]
    bc38:	f9039be2 	str	x2, [sp, #1840]
    bc3c:	97ffe512 	bl	5084 <fwp_data.part.0.constprop.0>
    bc40:	97ffe6e8 	bl	57e0 <fwp_rc_fresh>
    bc44:	aa0003e2 	mov	x2, x0
    bc48:	911ce3e1 	add	x1, sp, #0x738
    bc4c:	52800020 	mov	w0, #0x1                   	// #1
    bc50:	f9039ff7 	str	x23, [sp, #1848]
    bc54:	f903a3e2 	str	x2, [sp, #1856]
    bc58:	97ffe50b 	bl	5084 <fwp_data.part.0.constprop.0>
    bc5c:	97ffe6e1 	bl	57e0 <fwp_rc_fresh>
    bc60:	aa0003e2 	mov	x2, x0
    bc64:	911d23e1 	add	x1, sp, #0x748
    bc68:	52800020 	mov	w0, #0x1                   	// #1
    bc6c:	f903a7f5 	str	x21, [sp, #1864]
    bc70:	f903abe2 	str	x2, [sp, #1872]
    bc74:	97ffe504 	bl	5084 <fwp_data.part.0.constprop.0>
    bc78:	97ffe6da 	bl	57e0 <fwp_rc_fresh>
    bc7c:	aa0003e2 	mov	x2, x0
    bc80:	911d63e1 	add	x1, sp, #0x758
    bc84:	52800020 	mov	w0, #0x1                   	// #1
    bc88:	f903aff7 	str	x23, [sp, #1880]
    bc8c:	f903b3e2 	str	x2, [sp, #1888]
    bc90:	97ffe4fd 	bl	5084 <fwp_data.part.0.constprop.0>
    bc94:	97ffe6d3 	bl	57e0 <fwp_rc_fresh>
    bc98:	aa0003e2 	mov	x2, x0
    bc9c:	911da3e1 	add	x1, sp, #0x768
    bca0:	52800020 	mov	w0, #0x1                   	// #1
    bca4:	f903b7f5 	str	x21, [sp, #1896]
    bca8:	f903bbe2 	str	x2, [sp, #1904]
    bcac:	97ffe4f6 	bl	5084 <fwp_data.part.0.constprop.0>
    bcb0:	91174283 	add	x3, x20, #0x5d0
    bcb4:	aa0003f5 	mov	x21, x0
    bcb8:	f949d861 	ldr	x1, [x3, #5040]
    bcbc:	f949ec60 	ldr	x0, [x3, #5080]
    bcc0:	cb0102a1 	sub	x1, x21, x1
    bcc4:	eb00403f 	cmp	x1, x0, lsl #16
    bcc8:	54000322 	b.cs	bd2c <f0+0x1fdc>  // b.hs, b.nlast
    bccc:	d350fc22 	lsr	x2, x1, #16
    bcd0:	f949fc63 	ldr	x3, [x3, #5112]
    bcd4:	8b020842 	add	x2, x2, x2, lsl #2
    bcd8:	d37df042 	lsl	x2, x2, #3
    bcdc:	8b020060 	add	x0, x3, x2
    bce0:	f9401017 	ldr	x23, [x0, #32]
    bce4:	b4000257 	cbz	x23, bd2c <f0+0x1fdc>
    bce8:	38626862 	ldrb	w2, [x3, x2]
    bcec:	7100085f 	cmp	w2, #0x2
    bcf0:	54002340 	b.eq	c158 <f0+0x2408>  // b.none
    bcf4:	7100045f 	cmp	w2, #0x1
    bcf8:	540001a1 	b.ne	bd2c <f0+0x1fdc>  // b.any
    bcfc:	29430002 	ldp	w2, w0, [x0, #24]
    bd00:	92403c21 	and	x1, x1, #0xffff
    bd04:	9b027c21 	mul	x1, x1, x2
    bd08:	d360fc21 	lsr	x1, x1, #32
    bd0c:	eb00003f 	cmp	x1, x0
    bd10:	540000e2 	b.cs	bd2c <f0+0x1fdc>  // b.hs, b.nlast
    bd14:	8b0102f7 	add	x23, x23, x1
    bd18:	394002e0 	ldrb	w0, [x23]
    bd1c:	7103fc1f 	cmp	w0, #0xff
    bd20:	540034e0 	b.eq	c3bc <f0+0x266c>  // b.none
    bd24:	52800020 	mov	w0, #0x1                   	// #1
    bd28:	390002e0 	strb	w0, [x23]
    bd2c:	911de3e1 	add	x1, sp, #0x778
    bd30:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd34:	52800020 	mov	w0, #0x1                   	// #1
    bd38:	f903bff7 	str	x23, [sp, #1912]
    bd3c:	f903c3f5 	str	x21, [sp, #1920]
    bd40:	97ffe4d1 	bl	5084 <fwp_data.part.0.constprop.0>
    bd44:	97ffe6a7 	bl	57e0 <fwp_rc_fresh>
    bd48:	aa0003e2 	mov	x2, x0
    bd4c:	911e23e1 	add	x1, sp, #0x788
    bd50:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bd54:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bd58:	52800020 	mov	w0, #0x1                   	// #1
    bd5c:	f903c7f5 	str	x21, [sp, #1928]
    bd60:	f903cbe2 	str	x2, [sp, #1936]
    bd64:	97ffe4c8 	bl	5084 <fwp_data.part.0.constprop.0>
    bd68:	97ffe69e 	bl	57e0 <fwp_rc_fresh>
    bd6c:	aa0003e2 	mov	x2, x0
    bd70:	911e63e1 	add	x1, sp, #0x798
    bd74:	52800020 	mov	w0, #0x1                   	// #1
    bd78:	f903cff7 	str	x23, [sp, #1944]
    bd7c:	f903d3e2 	str	x2, [sp, #1952]
    bd80:	97ffe4c1 	bl	5084 <fwp_data.part.0.constprop.0>
    bd84:	97ffe697 	bl	57e0 <fwp_rc_fresh>
    bd88:	aa0003e2 	mov	x2, x0
    bd8c:	911ea3e1 	add	x1, sp, #0x7a8
    bd90:	52800020 	mov	w0, #0x1                   	// #1
    bd94:	f903d7f5 	str	x21, [sp, #1960]
    bd98:	f903dbe2 	str	x2, [sp, #1968]
    bd9c:	97ffe4ba 	bl	5084 <fwp_data.part.0.constprop.0>
    bda0:	97ffe690 	bl	57e0 <fwp_rc_fresh>
    bda4:	aa0003e2 	mov	x2, x0
    bda8:	911ee3e1 	add	x1, sp, #0x7b8
    bdac:	52800020 	mov	w0, #0x1                   	// #1
    bdb0:	f903dff7 	str	x23, [sp, #1976]
    bdb4:	f903e3e2 	str	x2, [sp, #1984]
    bdb8:	97ffe4b3 	bl	5084 <fwp_data.part.0.constprop.0>
    bdbc:	97ffe689 	bl	57e0 <fwp_rc_fresh>
    bdc0:	aa0003e2 	mov	x2, x0
    bdc4:	911f23e1 	add	x1, sp, #0x7c8
    bdc8:	52800020 	mov	w0, #0x1                   	// #1
    bdcc:	f903e7f5 	str	x21, [sp, #1992]
    bdd0:	f903ebe2 	str	x2, [sp, #2000]
    bdd4:	97ffe4ac 	bl	5084 <fwp_data.part.0.constprop.0>
    bdd8:	97ffe682 	bl	57e0 <fwp_rc_fresh>
    bddc:	aa0003e2 	mov	x2, x0
    bde0:	911f63e1 	add	x1, sp, #0x7d8
    bde4:	52800020 	mov	w0, #0x1                   	// #1
    bde8:	f903eff7 	str	x23, [sp, #2008]
    bdec:	f903f3e2 	str	x2, [sp, #2016]
    bdf0:	97ffe4a5 	bl	5084 <fwp_data.part.0.constprop.0>
    bdf4:	97ffe67b 	bl	57e0 <fwp_rc_fresh>
    bdf8:	aa0003e2 	mov	x2, x0
    bdfc:	911fa3e1 	add	x1, sp, #0x7e8
    be00:	52800020 	mov	w0, #0x1                   	// #1
    be04:	f903f7f5 	str	x21, [sp, #2024]
    be08:	f903fbe2 	str	x2, [sp, #2032]
    be0c:	97ffe49e 	bl	5084 <fwp_data.part.0.constprop.0>
    be10:	91174283 	add	x3, x20, #0x5d0
    be14:	aa0003f5 	mov	x21, x0
    be18:	f949d861 	ldr	x1, [x3, #5040]
    be1c:	f949ec60 	ldr	x0, [x3, #5080]
    be20:	cb0102a1 	sub	x1, x21, x1
    be24:	eb00403f 	cmp	x1, x0, lsl #16
    be28:	54000322 	b.cs	be8c <f0+0x213c>  // b.hs, b.nlast
    be2c:	d350fc22 	lsr	x2, x1, #16
    be30:	f949fc63 	ldr	x3, [x3, #5112]
    be34:	8b020842 	add	x2, x2, x2, lsl #2
    be38:	d37df042 	lsl	x2, x2, #3
    be3c:	8b020060 	add	x0, x3, x2
    be40:	f9401017 	ldr	x23, [x0, #32]
    be44:	b4000257 	cbz	x23, be8c <f0+0x213c>
    be48:	38626862 	ldrb	w2, [x3, x2]
    be4c:	7100085f 	cmp	w2, #0x2
    be50:	540017e0 	b.eq	c14c <f0+0x23fc>  // b.none
    be54:	7100045f 	cmp	w2, #0x1
    be58:	540001a1 	b.ne	be8c <f0+0x213c>  // b.any
    be5c:	29430002 	ldp	w2, w0, [x0, #24]
    be60:	92403c21 	and	x1, x1, #0xffff
    be64:	9b027c21 	mul	x1, x1, x2
    be68:	d360fc21 	lsr	x1, x1, #32
    be6c:	eb00003f 	cmp	x1, x0
    be70:	540000e2 	b.cs	be8c <f0+0x213c>  // b.hs, b.nlast
    be74:	8b0102f7 	add	x23, x23, x1
    be78:	394002e0 	ldrb	w0, [x23]
    be7c:	7103fc1f 	cmp	w0, #0xff
    be80:	54002a40 	b.eq	c3c8 <f0+0x2678>  // b.none
    be84:	52800020 	mov	w0, #0x1                   	// #1
    be88:	390002e0 	strb	w0, [x23]
    be8c:	911fe3e1 	add	x1, sp, #0x7f8
    be90:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    be94:	52800020 	mov	w0, #0x1                   	// #1
    be98:	f903fff7 	str	x23, [sp, #2040]
    be9c:	f90403f5 	str	x21, [sp, #2048]
    bea0:	97ffe479 	bl	5084 <fwp_data.part.0.constprop.0>
    bea4:	97ffe64f 	bl	57e0 <fwp_rc_fresh>
    bea8:	aa0003e2 	mov	x2, x0
    beac:	912023e1 	add	x1, sp, #0x808
    beb0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    beb4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    beb8:	52800020 	mov	w0, #0x1                   	// #1
    bebc:	f90407f5 	str	x21, [sp, #2056]
    bec0:	91174294 	add	x20, x20, #0x5d0
    bec4:	f9040be2 	str	x2, [sp, #2064]
    bec8:	97ffe46f 	bl	5084 <fwp_data.part.0.constprop.0>
    becc:	97ffe645 	bl	57e0 <fwp_rc_fresh>
    bed0:	aa0003e2 	mov	x2, x0
    bed4:	912063e1 	add	x1, sp, #0x818
    bed8:	52800020 	mov	w0, #0x1                   	// #1
    bedc:	f9040ff7 	str	x23, [sp, #2072]
    bee0:	f90413e2 	str	x2, [sp, #2080]
    bee4:	97ffe468 	bl	5084 <fwp_data.part.0.constprop.0>
    bee8:	97ffe63e 	bl	57e0 <fwp_rc_fresh>
    beec:	aa0003e2 	mov	x2, x0
    bef0:	9120a3e1 	add	x1, sp, #0x828
    bef4:	52800020 	mov	w0, #0x1                   	// #1
    bef8:	f90417f5 	str	x21, [sp, #2088]
    befc:	f9041be2 	str	x2, [sp, #2096]
    bf00:	97ffe461 	bl	5084 <fwp_data.part.0.constprop.0>
    bf04:	97ffe637 	bl	57e0 <fwp_rc_fresh>
    bf08:	aa0003e2 	mov	x2, x0
    bf0c:	9120e3e1 	add	x1, sp, #0x838
    bf10:	52800020 	mov	w0, #0x1                   	// #1
    bf14:	f9041ff7 	str	x23, [sp, #2104]
    bf18:	f90423e2 	str	x2, [sp, #2112]
    bf1c:	97ffe45a 	bl	5084 <fwp_data.part.0.constprop.0>
    bf20:	97ffe630 	bl	57e0 <fwp_rc_fresh>
    bf24:	aa0003e2 	mov	x2, x0
    bf28:	aa1603e1 	mov	x1, x22
    bf2c:	52800020 	mov	w0, #0x1                   	// #1
    bf30:	f90427f5 	str	x21, [sp, #2120]
    bf34:	f9042be2 	str	x2, [sp, #2128]
    bf38:	97ffe453 	bl	5084 <fwp_data.part.0.constprop.0>
    bf3c:	f949da81 	ldr	x1, [x20, #5040]
    bf40:	aa0003f5 	mov	x21, x0
    bf44:	f949ee80 	ldr	x0, [x20, #5080]
    bf48:	cb0102a1 	sub	x1, x21, x1
    bf4c:	eb00403f 	cmp	x1, x0, lsl #16
    bf50:	54000322 	b.cs	bfb4 <f0+0x2264>  // b.hs, b.nlast
    bf54:	d350fc22 	lsr	x2, x1, #16
    bf58:	f949fe83 	ldr	x3, [x20, #5112]
    bf5c:	8b020842 	add	x2, x2, x2, lsl #2
    bf60:	d37df042 	lsl	x2, x2, #3
    bf64:	8b020060 	add	x0, x3, x2
    bf68:	f9401014 	ldr	x20, [x0, #32]
    bf6c:	b4000254 	cbz	x20, bfb4 <f0+0x2264>
    bf70:	38626862 	ldrb	w2, [x3, x2]
    bf74:	7100085f 	cmp	w2, #0x2
    bf78:	54000e40 	b.eq	c140 <f0+0x23f0>  // b.none
    bf7c:	7100045f 	cmp	w2, #0x1
    bf80:	540001a1 	b.ne	bfb4 <f0+0x2264>  // b.any
    bf84:	29430002 	ldp	w2, w0, [x0, #24]
    bf88:	92403c21 	and	x1, x1, #0xffff
    bf8c:	9b027c21 	mul	x1, x1, x2
    bf90:	d360fc21 	lsr	x1, x1, #32
    bf94:	eb00003f 	cmp	x1, x0
    bf98:	540000e2 	b.cs	bfb4 <f0+0x2264>  // b.hs, b.nlast
    bf9c:	8b010294 	add	x20, x20, x1
    bfa0:	39400280 	ldrb	w0, [x20]
    bfa4:	7103fc1f 	cmp	w0, #0xff
    bfa8:	540012c0 	b.eq	c200 <f0+0x24b0>  // b.none
    bfac:	52800020 	mov	w0, #0x1                   	// #1
    bfb0:	39000280 	strb	w0, [x20]
    bfb4:	aa1303e1 	mov	x1, x19
    bfb8:	aa1503e0 	mov	x0, x21
    bfbc:	97fff09d 	bl	8230 <fwp_hof0.constprop.0>
    bfc0:	aa0003f4 	mov	x20, x0
    bfc4:	aa1503e0 	mov	x0, x21
    bfc8:	97ffe70a 	bl	5bf0 <fwp_drop0>
    bfcc:	aa1303e0 	mov	x0, x19
    bfd0:	97ffe708 	bl	5bf0 <fwp_drop0>
    bfd4:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bfd8:	f947f400 	ldr	x0, [x0, #4072]
    bfdc:	f9442fe2 	ldr	x2, [sp, #2136]
    bfe0:	f9400001 	ldr	x1, [x0]
    bfe4:	eb010042 	subs	x2, x2, x1
    bfe8:	d2800001 	mov	x1, #0x0                   	// #0
    bfec:	54001f41 	b.ne	c3d4 <f0+0x2684>  // b.any
    bff0:	912183ff 	add	sp, sp, #0x860
    bff4:	aa1403e0 	mov	x0, x20
    bff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    bffc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c000:	a94363f7 	ldp	x23, x24, [sp, #48]
    c004:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c008:	a94573fb 	ldp	x27, x28, [sp, #80]
    c00c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c010:	d65f03c0 	ret
    c014:	aa1b03e0 	mov	x0, x27
    c018:	97ffe216 	bl	4870 <fwp_rc_forget_slot>
    c01c:	17fff795 	b	9e70 <f0+0x120>
    c020:	72003c5f 	tst	w2, #0xffff
    c024:	54fef281 	b.ne	9e74 <f0+0x124>  // b.any
    c028:	17fff78f 	b	9e64 <f0+0x114>
    c02c:	72003c3f 	tst	w1, #0xffff
    c030:	54ff9041 	b.ne	b238 <f0+0x14e8>  // b.any
    c034:	17fffc7c 	b	b224 <f0+0x14d4>
    c038:	72003c3f 	tst	w1, #0xffff
    c03c:	54ff8861 	b.ne	b148 <f0+0x13f8>  // b.any
    c040:	17fffc3d 	b	b134 <f0+0x13e4>
    c044:	72003c3f 	tst	w1, #0xffff
    c048:	54ff8361 	b.ne	b0b4 <f0+0x1364>  // b.any
    c04c:	17fffc15 	b	b0a0 <f0+0x1350>
    c050:	72003c3f 	tst	w1, #0xffff
    c054:	54ff7c61 	b.ne	afe0 <f0+0x1290>  // b.any
    c058:	17fffbdd 	b	afcc <f0+0x127c>
    c05c:	72003c3f 	tst	w1, #0xffff
    c060:	54ff7641 	b.ne	af28 <f0+0x11d8>  // b.any
    c064:	17fffbac 	b	af14 <f0+0x11c4>
    c068:	72003c3f 	tst	w1, #0xffff
    c06c:	54ff7021 	b.ne	ae70 <f0+0x1120>  // b.any
    c070:	17fffb7b 	b	ae5c <f0+0x110c>
    c074:	72003c3f 	tst	w1, #0xffff
    c078:	54ff64c1 	b.ne	ad10 <f0+0xfc0>  // b.any
    c07c:	17fffb20 	b	acfc <f0+0xfac>
    c080:	72003c3f 	tst	w1, #0xffff
    c084:	54ff5ea1 	b.ne	ac58 <f0+0xf08>  // b.any
    c088:	17fffaef 	b	ac44 <f0+0xef4>
    c08c:	72003c3f 	tst	w1, #0xffff
    c090:	54ff0a81 	b.ne	a1e0 <f0+0x490>  // b.any
    c094:	17fff84e 	b	a1cc <f0+0x47c>
    c098:	72003c3f 	tst	w1, #0xffff
    c09c:	54ff05a1 	b.ne	a150 <f0+0x400>  // b.any
    c0a0:	17fff827 	b	a13c <f0+0x3ec>
    c0a4:	72003c3f 	tst	w1, #0xffff
    c0a8:	54fefd81 	b.ne	a058 <f0+0x308>  // b.any
    c0ac:	17fff7e6 	b	a044 <f0+0x2f4>
    c0b0:	72003c3f 	tst	w1, #0xffff
    c0b4:	54ff20e1 	b.ne	a4d0 <f0+0x780>  // b.any
    c0b8:	17fff901 	b	a4bc <f0+0x76c>
    c0bc:	72003c3f 	tst	w1, #0xffff
    c0c0:	54ff1a41 	b.ne	a408 <f0+0x6b8>  // b.any
    c0c4:	17fff8cc 	b	a3f4 <f0+0x6a4>
    c0c8:	72003c3f 	tst	w1, #0xffff
    c0cc:	54ff13a1 	b.ne	a340 <f0+0x5f0>  // b.any
    c0d0:	17fff897 	b	a32c <f0+0x5dc>
    c0d4:	72003c3f 	tst	w1, #0xffff
    c0d8:	54ff0dc1 	b.ne	a290 <f0+0x540>  // b.any
    c0dc:	17fff868 	b	a27c <f0+0x52c>
    c0e0:	72003c3f 	tst	w1, #0xffff
    c0e4:	54ff55e1 	b.ne	aba0 <f0+0xe50>  // b.any
    c0e8:	17fffaa9 	b	ab8c <f0+0xe3c>
    c0ec:	72003c3f 	tst	w1, #0xffff
    c0f0:	54ff4e01 	b.ne	aab0 <f0+0xd60>  // b.any
    c0f4:	17fffa6a 	b	aa9c <f0+0xd4c>
    c0f8:	72003c3f 	tst	w1, #0xffff
    c0fc:	54ff4621 	b.ne	a9c0 <f0+0xc70>  // b.any
    c100:	17fffa2b 	b	a9ac <f0+0xc5c>
    c104:	72003c3f 	tst	w1, #0xffff
    c108:	54ff3d61 	b.ne	a8b4 <f0+0xb64>  // b.any
    c10c:	17fff9e5 	b	a8a0 <f0+0xb50>
    c110:	72003c3f 	tst	w1, #0xffff
    c114:	54ff3661 	b.ne	a7e0 <f0+0xa90>  // b.any
    c118:	17fff9ad 	b	a7cc <f0+0xa7c>
    c11c:	72003c3f 	tst	w1, #0xffff
    c120:	54ff3041 	b.ne	a728 <f0+0x9d8>  // b.any
    c124:	17fff97c 	b	a714 <f0+0x9c4>
    c128:	72003c3f 	tst	w1, #0xffff
    c12c:	54ff2a21 	b.ne	a670 <f0+0x920>  // b.any
    c130:	17fff94b 	b	a65c <f0+0x90c>
    c134:	72003c3f 	tst	w1, #0xffff
    c138:	54ff2521 	b.ne	a5dc <f0+0x88c>  // b.any
    c13c:	17fff923 	b	a5c8 <f0+0x878>
    c140:	72003c3f 	tst	w1, #0xffff
    c144:	54fff381 	b.ne	bfb4 <f0+0x2264>  // b.any
    c148:	17ffff96 	b	bfa0 <f0+0x2250>
    c14c:	72003c3f 	tst	w1, #0xffff
    c150:	54ffe9e1 	b.ne	be8c <f0+0x213c>  // b.any
    c154:	17ffff49 	b	be78 <f0+0x2128>
    c158:	72003c3f 	tst	w1, #0xffff
    c15c:	54ffde81 	b.ne	bd2c <f0+0x1fdc>  // b.any
    c160:	17fffeee 	b	bd18 <f0+0x1fc8>
    c164:	72003c3f 	tst	w1, #0xffff
    c168:	54ffd161 	b.ne	bb94 <f0+0x1e44>  // b.any
    c16c:	17fffe85 	b	bb80 <f0+0x1e30>
    c170:	72003c3f 	tst	w1, #0xffff
    c174:	54ffcc41 	b.ne	bafc <f0+0x1dac>  // b.any
    c178:	17fffe5c 	b	bae8 <f0+0x1d98>
    c17c:	72003c3f 	tst	w1, #0xffff
    c180:	54ffc621 	b.ne	ba44 <f0+0x1cf4>  // b.any
    c184:	17fffe2b 	b	ba30 <f0+0x1ce0>
    c188:	72003c3f 	tst	w1, #0xffff
    c18c:	54ffc001 	b.ne	b98c <f0+0x1c3c>  // b.any
    c190:	17fffdfa 	b	b978 <f0+0x1c28>
    c194:	72003c3f 	tst	w1, #0xffff
    c198:	54ffb9e1 	b.ne	b8d4 <f0+0x1b84>  // b.any
    c19c:	17fffdc9 	b	b8c0 <f0+0x1b70>
    c1a0:	72003c3f 	tst	w1, #0xffff
    c1a4:	54ffb4e1 	b.ne	b840 <f0+0x1af0>  // b.any
    c1a8:	17fffda1 	b	b82c <f0+0x1adc>
    c1ac:	72003c3f 	tst	w1, #0xffff
    c1b0:	54ffac21 	b.ne	b734 <f0+0x19e4>  // b.any
    c1b4:	17fffd5b 	b	b720 <f0+0x19d0>
    c1b8:	72003c3f 	tst	w1, #0xffff
    c1bc:	54ffa601 	b.ne	b67c <f0+0x192c>  // b.any
    c1c0:	17fffd2a 	b	b668 <f0+0x1918>
    c1c4:	72003c3f 	tst	w1, #0xffff
    c1c8:	54ffa101 	b.ne	b5e8 <f0+0x1898>  // b.any
    c1cc:	17fffd02 	b	b5d4 <f0+0x1884>
    c1d0:	72003c3f 	tst	w1, #0xffff
    c1d4:	54ff9be1 	b.ne	b550 <f0+0x1800>  // b.any
    c1d8:	17fffcd9 	b	b53c <f0+0x17ec>
    c1dc:	72003c3f 	tst	w1, #0xffff
    c1e0:	54ff95c1 	b.ne	b498 <f0+0x1748>  // b.any
    c1e4:	17fffca8 	b	b484 <f0+0x1734>
    c1e8:	72003c3f 	tst	w1, #0xffff
    c1ec:	54ff8fa1 	b.ne	b3e0 <f0+0x1690>  // b.any
    c1f0:	17fffc77 	b	b3cc <f0+0x167c>
    c1f4:	72003c3f 	tst	w1, #0xffff
    c1f8:	54ff88a1 	b.ne	b30c <f0+0x15bc>  // b.any
    c1fc:	17fffc3f 	b	b2f8 <f0+0x15a8>
    c200:	aa1403e0 	mov	x0, x20
    c204:	97ffe19b 	bl	4870 <fwp_rc_forget_slot>
    c208:	17ffff69 	b	bfac <f0+0x225c>
    c20c:	aa1703e0 	mov	x0, x23
    c210:	97ffe198 	bl	4870 <fwp_rc_forget_slot>
    c214:	17fff78f 	b	a050 <f0+0x300>
    c218:	aa1703e0 	mov	x0, x23
    c21c:	97ffe195 	bl	4870 <fwp_rc_forget_slot>
    c220:	17fff7ca 	b	a148 <f0+0x3f8>
    c224:	aa1703e0 	mov	x0, x23
    c228:	97ffe192 	bl	4870 <fwp_rc_forget_slot>
    c22c:	17fff7eb 	b	a1d8 <f0+0x488>
    c230:	aa1703e0 	mov	x0, x23
    c234:	97ffe18f 	bl	4870 <fwp_rc_forget_slot>
    c238:	17fff814 	b	a288 <f0+0x538>
    c23c:	aa1703e0 	mov	x0, x23
    c240:	97ffe18c 	bl	4870 <fwp_rc_forget_slot>
    c244:	17fff83d 	b	a338 <f0+0x5e8>
    c248:	aa1703e0 	mov	x0, x23
    c24c:	97ffe189 	bl	4870 <fwp_rc_forget_slot>
    c250:	17fff86c 	b	a400 <f0+0x6b0>
    c254:	aa1703e0 	mov	x0, x23
    c258:	97ffe186 	bl	4870 <fwp_rc_forget_slot>
    c25c:	17fff89b 	b	a4c8 <f0+0x778>
    c260:	aa1703e0 	mov	x0, x23
    c264:	97ffe183 	bl	4870 <fwp_rc_forget_slot>
    c268:	17fff8db 	b	a5d4 <f0+0x884>
    c26c:	aa1703e0 	mov	x0, x23
    c270:	97ffe180 	bl	4870 <fwp_rc_forget_slot>
    c274:	17fff8fd 	b	a668 <f0+0x918>
    c278:	aa1703e0 	mov	x0, x23
    c27c:	97ffe17d 	bl	4870 <fwp_rc_forget_slot>
    c280:	17fff928 	b	a720 <f0+0x9d0>
    c284:	aa1703e0 	mov	x0, x23
    c288:	97ffe17a 	bl	4870 <fwp_rc_forget_slot>
    c28c:	17fff953 	b	a7d8 <f0+0xa88>
    c290:	aa1703e0 	mov	x0, x23
    c294:	97ffe177 	bl	4870 <fwp_rc_forget_slot>
    c298:	17fff985 	b	a8ac <f0+0xb5c>
    c29c:	aa1703e0 	mov	x0, x23
    c2a0:	97ffe174 	bl	4870 <fwp_rc_forget_slot>
    c2a4:	17fff9c5 	b	a9b8 <f0+0xc68>
    c2a8:	aa1703e0 	mov	x0, x23
    c2ac:	97ffe171 	bl	4870 <fwp_rc_forget_slot>
    c2b0:	17fff9fe 	b	aaa8 <f0+0xd58>
    c2b4:	aa1703e0 	mov	x0, x23
    c2b8:	97ffe16e 	bl	4870 <fwp_rc_forget_slot>
    c2bc:	17fffa37 	b	ab98 <f0+0xe48>
    c2c0:	aa1703e0 	mov	x0, x23
    c2c4:	97ffe16b 	bl	4870 <fwp_rc_forget_slot>
    c2c8:	17fffa62 	b	ac50 <f0+0xf00>
    c2cc:	aa1703e0 	mov	x0, x23
    c2d0:	97ffe168 	bl	4870 <fwp_rc_forget_slot>
    c2d4:	17fffa8d 	b	ad08 <f0+0xfb8>
    c2d8:	aa1703e0 	mov	x0, x23
    c2dc:	97ffe165 	bl	4870 <fwp_rc_forget_slot>
    c2e0:	17fffae2 	b	ae68 <f0+0x1118>
    c2e4:	aa1703e0 	mov	x0, x23
    c2e8:	97ffe162 	bl	4870 <fwp_rc_forget_slot>
    c2ec:	17fffb0d 	b	af20 <f0+0x11d0>
    c2f0:	aa1703e0 	mov	x0, x23
    c2f4:	97ffe15f 	bl	4870 <fwp_rc_forget_slot>
    c2f8:	17fffb38 	b	afd8 <f0+0x1288>
    c2fc:	aa1703e0 	mov	x0, x23
    c300:	97ffe15c 	bl	4870 <fwp_rc_forget_slot>
    c304:	17fffb6a 	b	b0ac <f0+0x135c>
    c308:	aa1703e0 	mov	x0, x23
    c30c:	97ffe159 	bl	4870 <fwp_rc_forget_slot>
    c310:	17fffb8c 	b	b140 <f0+0x13f0>
    c314:	aa1703e0 	mov	x0, x23
    c318:	97ffe156 	bl	4870 <fwp_rc_forget_slot>
    c31c:	17fffbc5 	b	b230 <f0+0x14e0>
    c320:	aa1703e0 	mov	x0, x23
    c324:	97ffe153 	bl	4870 <fwp_rc_forget_slot>
    c328:	17fffbf7 	b	b304 <f0+0x15b4>
    c32c:	aa1703e0 	mov	x0, x23
    c330:	97ffe150 	bl	4870 <fwp_rc_forget_slot>
    c334:	17fffc29 	b	b3d8 <f0+0x1688>
    c338:	aa1703e0 	mov	x0, x23
    c33c:	97ffe14d 	bl	4870 <fwp_rc_forget_slot>
    c340:	17fffc54 	b	b490 <f0+0x1740>
    c344:	aa1703e0 	mov	x0, x23
    c348:	97ffe14a 	bl	4870 <fwp_rc_forget_slot>
    c34c:	17fffc7f 	b	b548 <f0+0x17f8>
    c350:	aa1703e0 	mov	x0, x23
    c354:	97ffe147 	bl	4870 <fwp_rc_forget_slot>
    c358:	17fffca2 	b	b5e0 <f0+0x1890>
    c35c:	aa1703e0 	mov	x0, x23
    c360:	97ffe144 	bl	4870 <fwp_rc_forget_slot>
    c364:	17fffcc4 	b	b674 <f0+0x1924>
    c368:	aa1703e0 	mov	x0, x23
    c36c:	97ffe141 	bl	4870 <fwp_rc_forget_slot>
    c370:	17fffcef 	b	b72c <f0+0x19dc>
    c374:	aa1703e0 	mov	x0, x23
    c378:	97ffe13e 	bl	4870 <fwp_rc_forget_slot>
    c37c:	17fffd2f 	b	b838 <f0+0x1ae8>
    c380:	aa1703e0 	mov	x0, x23
    c384:	97ffe13b 	bl	4870 <fwp_rc_forget_slot>
    c388:	17fffd51 	b	b8cc <f0+0x1b7c>
    c38c:	aa1703e0 	mov	x0, x23
    c390:	97ffe138 	bl	4870 <fwp_rc_forget_slot>
    c394:	17fffd7c 	b	b984 <f0+0x1c34>
    c398:	aa1703e0 	mov	x0, x23
    c39c:	97ffe135 	bl	4870 <fwp_rc_forget_slot>
    c3a0:	17fffda7 	b	ba3c <f0+0x1cec>
    c3a4:	aa1703e0 	mov	x0, x23
    c3a8:	97ffe132 	bl	4870 <fwp_rc_forget_slot>
    c3ac:	17fffdd2 	b	baf4 <f0+0x1da4>
    c3b0:	aa1703e0 	mov	x0, x23
    c3b4:	97ffe12f 	bl	4870 <fwp_rc_forget_slot>
    c3b8:	17fffdf5 	b	bb8c <f0+0x1e3c>
    c3bc:	aa1703e0 	mov	x0, x23
    c3c0:	97ffe12c 	bl	4870 <fwp_rc_forget_slot>
    c3c4:	17fffe58 	b	bd24 <f0+0x1fd4>
    c3c8:	aa1703e0 	mov	x0, x23
    c3cc:	97ffe129 	bl	4870 <fwp_rc_forget_slot>
    c3d0:	17fffead 	b	be84 <f0+0x2134>
    c3d4:	97ffd94f 	bl	2910 <__stack_chk_fail@plt>
    c3d8:	d503201f 	nop
    c3dc:	d503201f 	nop

000000000000c3e0 <fwp_main_thread>:
    c3e0:	d10443ff 	sub	sp, sp, #0x110
    c3e4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c3e8:	f947f400 	ldr	x0, [x0, #4072]
    c3ec:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c3f0:	910303fd 	add	x29, sp, #0xc0
    c3f4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c3f8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c3fc:	91174261 	add	x1, x19, #0x5d0
    c400:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c404:	b953a421 	ldr	w1, [x1, #5028]
    c408:	f9400002 	ldr	x2, [x0]
    c40c:	f9005fe2 	str	x2, [sp, #184]
    c410:	d2800002 	mov	x2, #0x0                   	// #0
    c414:	34002821 	cbz	w1, c918 <fwp_main_thread+0x538>
    c418:	91174273 	add	x19, x19, #0x5d0
    c41c:	b953aa60 	ldr	w0, [x19, #5032]
    c420:	35002740 	cbnz	w0, c908 <fwp_main_thread+0x528>
    c424:	91001fe2 	add	x2, sp, #0x7
    c428:	900000b5 	adrp	x21, 20000 <__data_start>
    c42c:	900000a3 	adrp	x3, 20000 <__data_start>
    c430:	9101c2b3 	add	x19, x21, #0x70
    c434:	910fc063 	add	x3, x3, #0x3f0
    c438:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c43c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c440:	910023e0 	add	x0, sp, #0x8
    c444:	d2800001 	mov	x1, #0x0                   	// #0
    c448:	f90007e3 	str	x3, [sp, #8]
    c44c:	b90013ff 	str	wzr, [sp, #16]
    c450:	a9019262 	stp	x2, x4, [x19, #24]
    c454:	f9000fe5 	str	x5, [sp, #24]
    c458:	97ffd8c6 	bl	2770 <sigaltstack@plt>
    c45c:	350026e0 	cbnz	w0, c938 <fwp_main_thread+0x558>
    c460:	4f000400 	movi	v0.4s, #0x0
    c464:	9100a3e0 	add	x0, sp, #0x28
    c468:	f0ffffa1 	adrp	x1, 3000 <fwp_range_release+0x30>
    c46c:	52800082 	mov	w2, #0x4                   	// #4
    c470:	9103c021 	add	x1, x1, #0xf0
    c474:	72a10002 	movk	w2, #0x800, lsl #16
    c478:	910083f4 	add	x20, sp, #0x20
    c47c:	f90013e1 	str	x1, [sp, #32]
    c480:	3d802000 	str	q0, [x0, #128]
    c484:	b900abe2 	str	w2, [sp, #168]
    c488:	ad000000 	stp	q0, q0, [x0]
    c48c:	ad010000 	stp	q0, q0, [x0, #32]
    c490:	ad020000 	stp	q0, q0, [x0, #64]
    c494:	ad030000 	stp	q0, q0, [x0, #96]
    c498:	97ffd90e 	bl	28d0 <sigemptyset@plt>
    c49c:	350024e0 	cbnz	w0, c938 <fwp_main_thread+0x558>
    c4a0:	aa1403e1 	mov	x1, x20
    c4a4:	d2800002 	mov	x2, #0x0                   	// #0
    c4a8:	52800160 	mov	w0, #0xb                   	// #11
    c4ac:	97ffd921 	bl	2930 <sigaction@plt>
    c4b0:	35002440 	cbnz	w0, c938 <fwp_main_thread+0x558>
    c4b4:	aa1403e1 	mov	x1, x20
    c4b8:	d2800002 	mov	x2, #0x0                   	// #0
    c4bc:	528000e0 	mov	w0, #0x7                   	// #7
    c4c0:	97ffd91c 	bl	2930 <sigaction@plt>
    c4c4:	350023a0 	cbnz	w0, c938 <fwp_main_thread+0x558>
    c4c8:	b9434a60 	ldr	w0, [x19, #840]
    c4cc:	34002000 	cbz	w0, c8cc <fwp_main_thread+0x4ec>
    c4d0:	9101c2b3 	add	x19, x21, #0x70
    c4d4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c4d8:	b9434e60 	ldr	w0, [x19, #844]
    c4dc:	340020c0 	cbz	w0, c8f4 <fwp_main_thread+0x514>
    c4e0:	9101c2b6 	add	x22, x21, #0x70
    c4e4:	f9400ad4 	ldr	x20, [x22, #16]
    c4e8:	b40010f4 	cbz	x20, c704 <fwp_main_thread+0x324>
    c4ec:	aa1403f3 	mov	x19, x20
    c4f0:	91010297 	add	x23, x20, #0x40
    c4f4:	f90083f9 	str	x25, [sp, #256]
    c4f8:	52800038 	mov	w24, #0x1                   	// #1
    c4fc:	39414a99 	ldrb	w25, [x20, #82]
    c500:	39014a98 	strb	w24, [x20, #82]
    c504:	f9401680 	ldr	x0, [x20, #40]
    c508:	b4000620 	cbz	x0, c5cc <fwp_main_thread+0x1ec>
    c50c:	f9403281 	ldr	x1, [x20, #96]
    c510:	39414680 	ldrb	w0, [x20, #81]
    c514:	b4000b61 	cbz	x1, c680 <fwp_main_thread+0x2a0>
    c518:	36000aa0 	tbz	w0, #0, c66c <fwp_main_thread+0x28c>
    c51c:	39414a62 	ldrb	w2, [x19, #82]
    c520:	f9402280 	ldr	x0, [x20, #64]
    c524:	37000d82 	tbnz	w2, #0, c6d4 <fwp_main_thread+0x2f4>
    c528:	f9403261 	ldr	x1, [x19, #96]
    c52c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c530:	f9009660 	str	x0, [x19, #296]
    c534:	b4000040 	cbz	x0, c53c <fwp_main_thread+0x15c>
    c538:	f9009013 	str	x19, [x0, #288]
    c53c:	f9002293 	str	x19, [x20, #64]
    c540:	b4000101 	cbz	x1, c560 <fwp_main_thread+0x180>
    c544:	f9406ec0 	ldr	x0, [x22, #216]
    c548:	39015678 	strb	w24, [x19, #85]
    c54c:	f9003661 	str	x1, [x19, #104]
    c550:	a910827f 	stp	xzr, x0, [x19, #264]
    c554:	b4000040 	cbz	x0, c55c <fwp_main_thread+0x17c>
    c558:	f9008413 	str	x19, [x0, #264]
    c55c:	f9006ed3 	str	x19, [x22, #216]
    c560:	39015a7f 	strb	wzr, [x19, #86]
    c564:	97ffe8c0 	bl	6864 <fwp_block>
    c568:	f9408e62 	ldr	x2, [x19, #280]
    c56c:	b4000142 	cbz	x2, c594 <fwp_main_thread+0x1b4>
    c570:	a9520261 	ldp	x1, x0, [x19, #288]
    c574:	b4000bc1 	cbz	x1, c6ec <fwp_main_thread+0x30c>
    c578:	f9009420 	str	x0, [x1, #296]
    c57c:	f9409660 	ldr	x0, [x19, #296]
    c580:	b4000040 	cbz	x0, c588 <fwp_main_thread+0x1a8>
    c584:	f9009001 	str	x1, [x0, #288]
    c588:	91080260 	add	x0, x19, #0x200
    c58c:	f900967f 	str	xzr, [x19, #296]
    c590:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c594:	39415660 	ldrb	w0, [x19, #85]
    c598:	f9400ac2 	ldr	x2, [x22, #16]
    c59c:	36000980 	tbz	w0, #0, c6cc <fwp_main_thread+0x2ec>
    c5a0:	a9508261 	ldp	x1, x0, [x19, #264]
    c5a4:	b4000a81 	cbz	x1, c6f4 <fwp_main_thread+0x314>
    c5a8:	f9008820 	str	x0, [x1, #272]
    c5ac:	b4000040 	cbz	x0, c5b4 <fwp_main_thread+0x1d4>
    c5b0:	f9008401 	str	x1, [x0, #264]
    c5b4:	91080260 	add	x0, x19, #0x200
    c5b8:	3901567f 	strb	wzr, [x19, #85]
    c5bc:	aa0203f3 	mov	x19, x2
    c5c0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c5c4:	f9401680 	ldr	x0, [x20, #40]
    c5c8:	b5fffa20 	cbnz	x0, c50c <fwp_main_thread+0x12c>
    c5cc:	9101c2a0 	add	x0, x21, #0x70
    c5d0:	39014a99 	strb	w25, [x20, #82]
    c5d4:	f94083f9 	ldr	x25, [sp, #256]
    c5d8:	f9419400 	ldr	x0, [x0, #808]
    c5dc:	b4001580 	cbz	x0, c88c <fwp_main_thread+0x4ac>
    c5e0:	9101c2a0 	add	x0, x21, #0x70
    c5e4:	f941b001 	ldr	x1, [x0, #864]
    c5e8:	b903581f 	str	wzr, [x0, #856]
    c5ec:	eb13003f 	cmp	x1, x19
    c5f0:	540016a1 	b.ne	c8c4 <fwp_main_thread+0x4e4>  // b.any
    c5f4:	b4000933 	cbz	x19, c718 <fwp_main_thread+0x338>
    c5f8:	9101c2a0 	add	x0, x21, #0x70
    c5fc:	52800021 	mov	w1, #0x1                   	// #1
    c600:	39014a61 	strb	w1, [x19, #82]
    c604:	f9418005 	ldr	x5, [x0, #768]
    c608:	b4000885 	cbz	x5, c718 <fwp_main_thread+0x338>
    c60c:	d503201f 	nop
    c610:	394140a0 	ldrb	w0, [x5, #80]
    c614:	37000060 	tbnz	w0, #0, c620 <fwp_main_thread+0x240>
    c618:	aa0503e0 	mov	x0, x5
    c61c:	97ffdc55 	bl	3770 <fwp_cancel_tree.part.0>
    c620:	f9409ca5 	ldr	x5, [x5, #312]
    c624:	b5ffff65 	cbnz	x5, c610 <fwp_main_thread+0x230>
    c628:	9101c2b4 	add	x20, x21, #0x70
    c62c:	52800036 	mov	w22, #0x1                   	// #1
    c630:	f9402a60 	ldr	x0, [x19, #80]
    c634:	f2001c1f 	tst	x0, #0xff000000ff
    c638:	540000e1 	b.ne	c654 <fwp_main_thread+0x274>  // b.any
    c63c:	f9403e80 	ldr	x0, [x20, #120]
    c640:	39015276 	strb	w22, [x19, #84]
    c644:	f900827f 	str	xzr, [x19, #256]
    c648:	b40005a0 	cbz	x0, c6fc <fwp_main_thread+0x31c>
    c64c:	f9008013 	str	x19, [x0, #256]
    c650:	f9003e93 	str	x19, [x20, #120]
    c654:	97ffe884 	bl	6864 <fwp_block>
    c658:	97ffe816 	bl	66b0 <fwp_free_zombie>
    c65c:	f9418280 	ldr	x0, [x20, #768]
    c660:	b40005c0 	cbz	x0, c718 <fwp_main_thread+0x338>
    c664:	f941b293 	ldr	x19, [x20, #864]
    c668:	17fffff2 	b	c630 <fwp_main_thread+0x250>
    c66c:	97ffdce5 	bl	3a00 <fwp_now_ns>
    c670:	f9403281 	ldr	x1, [x20, #96]
    c674:	eb01001f 	cmp	x0, x1
    c678:	54000fca 	b.ge	c870 <fwp_main_thread+0x490>  // b.tcont
    c67c:	39414680 	ldrb	w0, [x20, #81]
    c680:	39414a62 	ldrb	w2, [x19, #82]
    c684:	3707f4e0 	tbnz	w0, #0, c520 <fwp_main_thread+0x140>
    c688:	f9403281 	ldr	x1, [x20, #96]
    c68c:	370001c2 	tbnz	w2, #0, c6c4 <fwp_main_thread+0x2e4>
    c690:	f9403260 	ldr	x0, [x19, #96]
    c694:	b4000180 	cbz	x0, c6c4 <fwp_main_thread+0x2e4>
    c698:	b4000061 	cbz	x1, c6a4 <fwp_main_thread+0x2c4>
    c69c:	eb01001f 	cmp	x0, x1
    c6a0:	9a81d000 	csel	x0, x0, x1, le
    c6a4:	f9402281 	ldr	x1, [x20, #64]
    c6a8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c6ac:	f9009661 	str	x1, [x19, #296]
    c6b0:	b4001381 	cbz	x1, c920 <fwp_main_thread+0x540>
    c6b4:	f9009033 	str	x19, [x1, #288]
    c6b8:	aa0003e1 	mov	x1, x0
    c6bc:	f9002293 	str	x19, [x20, #64]
    c6c0:	17ffffa1 	b	c544 <fwp_main_thread+0x164>
    c6c4:	f9402280 	ldr	x0, [x20, #64]
    c6c8:	17ffff99 	b	c52c <fwp_main_thread+0x14c>
    c6cc:	aa0203f3 	mov	x19, x2
    c6d0:	17ffff8d 	b	c504 <fwp_main_thread+0x124>
    c6d4:	a911fe77 	stp	x23, xzr, [x19, #280]
    c6d8:	f9009660 	str	x0, [x19, #296]
    c6dc:	b4000040 	cbz	x0, c6e4 <fwp_main_thread+0x304>
    c6e0:	f9009013 	str	x19, [x0, #288]
    c6e4:	f9002293 	str	x19, [x20, #64]
    c6e8:	17ffff9e 	b	c560 <fwp_main_thread+0x180>
    c6ec:	f9000040 	str	x0, [x2]
    c6f0:	17ffffa4 	b	c580 <fwp_main_thread+0x1a0>
    c6f4:	f9006ec0 	str	x0, [x22, #216]
    c6f8:	17ffffad 	b	c5ac <fwp_main_thread+0x1cc>
    c6fc:	f9004293 	str	x19, [x20, #128]
    c700:	17ffffd4 	b	c650 <fwp_main_thread+0x270>
    c704:	f94196c0 	ldr	x0, [x22, #808]
    c708:	b4000c00 	cbz	x0, c888 <fwp_main_thread+0x4a8>
    c70c:	f941b2c0 	ldr	x0, [x22, #864]
    c710:	b9035adf 	str	wzr, [x22, #856]
    c714:	b5000d80 	cbnz	x0, c8c4 <fwp_main_thread+0x4e4>
    c718:	9101c2b4 	add	x20, x21, #0x70
    c71c:	97ffe7e5 	bl	66b0 <fwp_free_zombie>
    c720:	f9404280 	ldr	x0, [x20, #128]
    c724:	b5000d00 	cbnz	x0, c8c4 <fwp_main_thread+0x4e4>
    c728:	f9406e80 	ldr	x0, [x20, #216]
    c72c:	b5000cc0 	cbnz	x0, c8c4 <fwp_main_thread+0x4e4>
    c730:	b940fa93 	ldr	w19, [x20, #248]
    c734:	340001d3 	cbz	w19, c76c <fwp_main_thread+0x38c>
    c738:	93407e76 	sxtw	x22, w19
    c73c:	51000673 	sub	w19, w19, #0x1
    c740:	d1000ad6 	sub	x22, x22, #0x2
    c744:	91040297 	add	x23, x20, #0x100
    c748:	cb3342d6 	sub	x22, x22, w19, uxtw
    c74c:	93407e73 	sxtw	x19, w19
    c750:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c754:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c758:	b900fa93 	str	w19, [x20, #248]
    c75c:	d1000673 	sub	x19, x19, #0x1
    c760:	97ffd8b4 	bl	2a30 <munmap@plt>
    c764:	eb16027f 	cmp	x19, x22
    c768:	54ffff41 	b.ne	c750 <fwp_main_thread+0x370>  // b.any
    c76c:	900000b3 	adrp	x19, 20000 <__data_start>
    c770:	91004260 	add	x0, x19, #0x10
    c774:	b9404000 	ldr	w0, [x0, #64]
    c778:	37f80040 	tbnz	w0, #31, c780 <fwp_main_thread+0x3a0>
    c77c:	97ffd869 	bl	2920 <close@plt>
    c780:	9101c2a0 	add	x0, x21, #0x70
    c784:	91004261 	add	x1, x19, #0x10
    c788:	12800002 	mov	w2, #0xffffffff            	// #-1
    c78c:	d2800013 	mov	x19, #0x0                   	// #0
    c790:	f941b416 	ldr	x22, [x0, #872]
    c794:	b9004022 	str	w2, [x1, #64]
    c798:	f941b814 	ldr	x20, [x0, #880]
    c79c:	b4000176 	cbz	x22, c7c8 <fwp_main_thread+0x3e8>
    c7a0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c7a4:	b40000c0 	cbz	x0, c7bc <fwp_main_thread+0x3dc>
    c7a8:	f9400001 	ldr	x1, [x0]
    c7ac:	b50008c1 	cbnz	x1, c8c4 <fwp_main_thread+0x4e4>
    c7b0:	f9400401 	ldr	x1, [x0, #8]
    c7b4:	b5000881 	cbnz	x1, c8c4 <fwp_main_thread+0x4e4>
    c7b8:	97ffe0ce 	bl	4af0 <fwp_mem_free>
    c7bc:	91000673 	add	x19, x19, #0x1
    c7c0:	eb16027f 	cmp	x19, x22
    c7c4:	54fffee1 	b.ne	c7a0 <fwp_main_thread+0x3c0>  // b.any
    c7c8:	aa1403e0 	mov	x0, x20
    c7cc:	97ffe0c9 	bl	4af0 <fwp_mem_free>
    c7d0:	9101c2a0 	add	x0, x21, #0x70
    c7d4:	f941b013 	ldr	x19, [x0, #864]
    c7d8:	f901b41f 	str	xzr, [x0, #872]
    c7dc:	f901b81f 	str	xzr, [x0, #880]
    c7e0:	b40001f3 	cbz	x19, c81c <fwp_main_thread+0x43c>
    c7e4:	f9401661 	ldr	x1, [x19, #40]
    c7e8:	b50006e1 	cbnz	x1, c8c4 <fwp_main_thread+0x4e4>
    c7ec:	f9405661 	ldr	x1, [x19, #168]
    c7f0:	b50006a1 	cbnz	x1, c8c4 <fwp_main_thread+0x4e4>
    c7f4:	f9419401 	ldr	x1, [x0, #808]
    c7f8:	b5000661 	cbnz	x1, c8c4 <fwp_main_thread+0x4e4>
    c7fc:	f9419c00 	ldr	x0, [x0, #824]
    c800:	b5000620 	cbnz	x0, c8c4 <fwp_main_thread+0x4e4>
    c804:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c808:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    c80c:	910fc000 	add	x0, x0, #0x3f0
    c810:	97ffd834 	bl	28e0 <memset@plt>
    c814:	aa1303e0 	mov	x0, x19
    c818:	97ffe0b6 	bl	4af0 <fwp_mem_free>
    c81c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c820:	f947ec00 	ldr	x0, [x0, #4056]
    c824:	9101c2b5 	add	x21, x21, #0x70
    c828:	f9400000 	ldr	x0, [x0]
    c82c:	f9000abf 	str	xzr, [x21, #16]
    c830:	f901b2bf 	str	xzr, [x21, #864]
    c834:	97ffd883 	bl	2a40 <fflush@plt>
    c838:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c83c:	f947f400 	ldr	x0, [x0, #4072]
    c840:	f9405fe2 	ldr	x2, [sp, #184]
    c844:	f9400001 	ldr	x1, [x0]
    c848:	eb010042 	subs	x2, x2, x1
    c84c:	d2800001 	mov	x1, #0x0                   	// #0
    c850:	54000821 	b.ne	c954 <fwp_main_thread+0x574>  // b.any
    c854:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c858:	d2800000 	mov	x0, #0x0                   	// #0
    c85c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c860:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c864:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c868:	910443ff 	add	sp, sp, #0x110
    c86c:	d65f03c0 	ret
    c870:	39414280 	ldrb	w0, [x20, #80]
    c874:	3707f040 	tbnz	w0, #0, c67c <fwp_main_thread+0x29c>
    c878:	aa1403e0 	mov	x0, x20
    c87c:	97ffdbbd 	bl	3770 <fwp_cancel_tree.part.0>
    c880:	39414680 	ldrb	w0, [x20, #81]
    c884:	17ffff7f 	b	c680 <fwp_main_thread+0x2a0>
    c888:	d2800013 	mov	x19, #0x0                   	// #0
    c88c:	9101c2b4 	add	x20, x21, #0x70
    c890:	f9419e80 	ldr	x0, [x20, #824]
    c894:	b5ffea60 	cbnz	x0, c5e0 <fwp_main_thread+0x200>
    c898:	f9419280 	ldr	x0, [x20, #800]
    c89c:	97ffe095 	bl	4af0 <fwp_mem_free>
    c8a0:	f901929f 	str	xzr, [x20, #800]
    c8a4:	f9019a9f 	str	xzr, [x20, #816]
    c8a8:	f941b280 	ldr	x0, [x20, #864]
    c8ac:	b4000413 	cbz	x19, c92c <fwp_main_thread+0x54c>
    c8b0:	f900567f 	str	xzr, [x19, #168]
    c8b4:	f9005e7f 	str	xzr, [x19, #184]
    c8b8:	b9035a9f 	str	wzr, [x20, #856]
    c8bc:	eb00027f 	cmp	x19, x0
    c8c0:	54ffe9c0 	b.eq	c5f8 <fwp_main_thread+0x218>  // b.none
    c8c4:	f90083f9 	str	x25, [sp, #256]
    c8c8:	97ffd826 	bl	2960 <abort@plt>
    c8cc:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    c8d0:	91078000 	add	x0, x0, #0x1e0
    c8d4:	940001df 	bl	d050 <atexit>
    c8d8:	a90f63f7 	stp	x23, x24, [sp, #240]
    c8dc:	35000380 	cbnz	w0, c94c <fwp_main_thread+0x56c>
    c8e0:	52800020 	mov	w0, #0x1                   	// #1
    c8e4:	b9034a60 	str	w0, [x19, #840]
    c8e8:	9101c2b3 	add	x19, x21, #0x70
    c8ec:	b9434e60 	ldr	w0, [x19, #844]
    c8f0:	35ffdf80 	cbnz	w0, c4e0 <fwp_main_thread+0x100>
    c8f4:	97fff517 	bl	9d50 <f0>
    c8f8:	f901aa60 	str	x0, [x19, #848]
    c8fc:	52800021 	mov	w1, #0x1                   	// #1
    c900:	b9034e61 	str	w1, [x19, #844]
    c904:	17fffef7 	b	c4e0 <fwp_main_thread+0x100>
    c908:	90ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    c90c:	91008000 	add	x0, x0, #0x20
    c910:	940001d0 	bl	d050 <atexit>
    c914:	17fffec4 	b	c424 <fwp_main_thread+0x44>
    c918:	97ffde1b 	bl	4184 <fwp_heap_init>
    c91c:	17fffebf 	b	c418 <fwp_main_thread+0x38>
    c920:	aa0003e1 	mov	x1, x0
    c924:	f9002293 	str	x19, [x20, #64]
    c928:	17ffff07 	b	c544 <fwp_main_thread+0x164>
    c92c:	b9035a9f 	str	wzr, [x20, #856]
    c930:	b4ffef40 	cbz	x0, c718 <fwp_main_thread+0x338>
    c934:	17ffffe4 	b	c8c4 <fwp_main_thread+0x4e4>
    c938:	b0000000 	adrp	x0, d000 <__modti3+0x320>
    c93c:	911bc000 	add	x0, x0, #0x6f0
    c940:	a90f63f7 	stp	x23, x24, [sp, #240]
    c944:	f90083f9 	str	x25, [sp, #256]
    c948:	97ffdbce 	bl	3880 <fwp_trap>
    c94c:	f90083f9 	str	x25, [sp, #256]
    c950:	97ffda18 	bl	31b0 <descent_phase_fail>
    c954:	f90083f9 	str	x25, [sp, #256]
    c958:	97ffd7ee 	bl	2910 <__stack_chk_fail@plt>
    c95c:	d503201f 	nop

000000000000c960 <__divti3>:
    c960:	d503245f 	bti	c
    c964:	d2800004 	mov	x4, #0x0                   	// #0
    c968:	b7f80721 	tbnz	x1, #63, ca4c <__divti3+0xec>
    c96c:	b6f80083 	tbz	x3, #63, c97c <__divti3+0x1c>
    c970:	eb0203e2 	negs	x2, x2
    c974:	aa2403e4 	mvn	x4, x4
    c978:	da0303e3 	ngc	x3, x3
    c97c:	aa0203e6 	mov	x6, x2
    c980:	aa0003e7 	mov	x7, x0
    c984:	aa0103e5 	mov	x5, x1
    c988:	b5000583 	cbnz	x3, ca38 <__divti3+0xd8>
    c98c:	eb01005f 	cmp	x2, x1
    c990:	54000e69 	b.ls	cb5c <__divti3+0x1fc>  // b.plast
    c994:	dac01040 	clz	x0, x2
    c998:	b40000e0 	cbz	x0, c9b4 <__divti3+0x54>
    c99c:	4b0003e1 	neg	w1, w0
    c9a0:	9ac020a5 	lsl	x5, x5, x0
    c9a4:	9ac02046 	lsl	x6, x2, x0
    c9a8:	9ac124e1 	lsr	x1, x7, x1
    c9ac:	aa050025 	orr	x5, x1, x5
    c9b0:	9ac020e7 	lsl	x7, x7, x0
    c9b4:	d360fcc8 	lsr	x8, x6, #32
    c9b8:	92407cc2 	and	x2, x6, #0xffffffff
    c9bc:	9ac808a3 	udiv	x3, x5, x8
    c9c0:	9b089465 	msub	x5, x3, x8, x5
    c9c4:	aa0303e0 	mov	x0, x3
    c9c8:	9b037c41 	mul	x1, x2, x3
    c9cc:	93c780a5 	extr	x5, x5, x7, #32
    c9d0:	eb05003f 	cmp	x1, x5
    c9d4:	540000a9 	b.ls	c9e8 <__divti3+0x88>  // b.plast
    c9d8:	ab0500c5 	adds	x5, x6, x5
    c9dc:	d1000460 	sub	x0, x3, #0x1
    c9e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c9e4:	540015a8 	b.hi	cc98 <__divti3+0x338>  // b.pmore
    c9e8:	cb0100a5 	sub	x5, x5, x1
    c9ec:	9ac808a3 	udiv	x3, x5, x8
    c9f0:	9b089465 	msub	x5, x3, x8, x5
    c9f4:	aa0303e1 	mov	x1, x3
    c9f8:	9b037c42 	mul	x2, x2, x3
    c9fc:	aa0703e3 	mov	x3, x7
    ca00:	b3607ca3 	bfi	x3, x5, #32, #32
    ca04:	eb03005f 	cmp	x2, x3
    ca08:	540000c9 	b.ls	ca20 <__divti3+0xc0>  // b.plast
    ca0c:	ab0300c3 	adds	x3, x6, x3
    ca10:	d1000425 	sub	x5, x1, #0x1
    ca14:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca18:	d1000821 	sub	x1, x1, #0x2
    ca1c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ca20:	aa008020 	orr	x0, x1, x0, lsl #32
    ca24:	d2800001 	mov	x1, #0x0                   	// #0
    ca28:	b4000064 	cbz	x4, ca34 <__divti3+0xd4>
    ca2c:	eb0003e0 	negs	x0, x0
    ca30:	da0103e1 	ngc	x1, x1
    ca34:	d65f03c0 	ret
    ca38:	eb01007f 	cmp	x3, x1
    ca3c:	54000109 	b.ls	ca5c <__divti3+0xfc>  // b.plast
    ca40:	d2800001 	mov	x1, #0x0                   	// #0
    ca44:	d2800000 	mov	x0, #0x0                   	// #0
    ca48:	17fffff8 	b	ca28 <__divti3+0xc8>
    ca4c:	eb0003e0 	negs	x0, x0
    ca50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ca54:	da0103e1 	ngc	x1, x1
    ca58:	17ffffc5 	b	c96c <__divti3+0xc>
    ca5c:	dac01067 	clz	x7, x3
    ca60:	b40010e7 	cbz	x7, cc7c <__divti3+0x31c>
    ca64:	d2800805 	mov	x5, #0x40                  	// #64
    ca68:	cb0700a5 	sub	x5, x5, x7
    ca6c:	9ac72063 	lsl	x3, x3, x7
    ca70:	9ac52448 	lsr	x8, x2, x5
    ca74:	aa030108 	orr	x8, x8, x3
    ca78:	9ac52426 	lsr	x6, x1, x5
    ca7c:	92407d0a 	and	x10, x8, #0xffffffff
    ca80:	d360fd09 	lsr	x9, x8, #32
    ca84:	9ac52403 	lsr	x3, x0, x5
    ca88:	9ac72021 	lsl	x1, x1, x7
    ca8c:	aa010063 	orr	x3, x3, x1
    ca90:	9ac72042 	lsl	x2, x2, x7
    ca94:	9ac908cb 	udiv	x11, x6, x9
    ca98:	9b099965 	msub	x5, x11, x9, x6
    ca9c:	aa0b03e1 	mov	x1, x11
    caa0:	9b0b7d46 	mul	x6, x10, x11
    caa4:	93c380a5 	extr	x5, x5, x3, #32
    caa8:	eb0500df 	cmp	x6, x5
    caac:	540000a9 	b.ls	cac0 <__divti3+0x160>  // b.plast
    cab0:	ab050105 	adds	x5, x8, x5
    cab4:	d1000561 	sub	x1, x11, #0x1
    cab8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cabc:	54000f48 	b.hi	cca4 <__divti3+0x344>  // b.pmore
    cac0:	cb0600a6 	sub	x6, x5, x6
    cac4:	9ac908cb 	udiv	x11, x6, x9
    cac8:	9b099969 	msub	x9, x11, x9, x6
    cacc:	aa0b03e5 	mov	x5, x11
    cad0:	9b0b7d4a 	mul	x10, x10, x11
    cad4:	b3607d23 	bfi	x3, x9, #32, #32
    cad8:	eb03015f 	cmp	x10, x3
    cadc:	540000a9 	b.ls	caf0 <__divti3+0x190>  // b.plast
    cae0:	ab030103 	adds	x3, x8, x3
    cae4:	d1000565 	sub	x5, x11, #0x1
    cae8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    caec:	54000e28 	b.hi	ccb0 <__divti3+0x350>  // b.pmore
    caf0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    caf4:	92407c48 	and	x8, x2, #0xffffffff
    caf8:	2a0503e5 	mov	w5, w5
    cafc:	d360fc42 	lsr	x2, x2, #32
    cb00:	d360fc26 	lsr	x6, x1, #32
    cb04:	cb0a0063 	sub	x3, x3, x10
    cb08:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cb0c:	9b087caa 	mul	x10, x5, x8
    cb10:	9b087cc8 	mul	x8, x6, x8
    cb14:	9b0220a5 	madd	x5, x5, x2, x8
    cb18:	9b027cc6 	mul	x6, x6, x2
    cb1c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cb20:	8b0900c5 	add	x5, x6, x9
    cb24:	eb02011f 	cmp	x8, x2
    cb28:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cb2c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cb30:	eb06007f 	cmp	x3, x6
    cb34:	540000e3 	b.cc	cb50 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cb38:	92407d4a 	and	x10, x10, #0xffffffff
    cb3c:	9ac72000 	lsl	x0, x0, x7
    cb40:	8b028142 	add	x2, x10, x2, lsl #32
    cb44:	eb02001f 	cmp	x0, x2
    cb48:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cb4c:	54000a01 	b.ne	cc8c <__divti3+0x32c>  // b.any
    cb50:	d1000420 	sub	x0, x1, #0x1
    cb54:	d2800001 	mov	x1, #0x0                   	// #0
    cb58:	17ffffb4 	b	ca28 <__divti3+0xc8>
    cb5c:	b5000062 	cbnz	x2, cb68 <__divti3+0x208>
    cb60:	d2800022 	mov	x2, #0x1                   	// #1
    cb64:	9ac30846 	udiv	x6, x2, x3
    cb68:	dac010c8 	clz	x8, x6
    cb6c:	b5000408 	cbnz	x8, cbec <__divti3+0x28c>
    cb70:	d360fcc9 	lsr	x9, x6, #32
    cb74:	92407cc5 	and	x5, x6, #0xffffffff
    cb78:	cb060023 	sub	x3, x1, x6
    cb7c:	d2800021 	mov	x1, #0x1                   	// #1
    cb80:	9ac90868 	udiv	x8, x3, x9
    cb84:	9b098d03 	msub	x3, x8, x9, x3
    cb88:	aa0803e0 	mov	x0, x8
    cb8c:	9b057d02 	mul	x2, x8, x5
    cb90:	93c78063 	extr	x3, x3, x7, #32
    cb94:	eb03005f 	cmp	x2, x3
    cb98:	540000a9 	b.ls	cbac <__divti3+0x24c>  // b.plast
    cb9c:	ab0300c3 	adds	x3, x6, x3
    cba0:	d1000500 	sub	x0, x8, #0x1
    cba4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cba8:	54000968 	b.hi	ccd4 <__divti3+0x374>  // b.pmore
    cbac:	cb020063 	sub	x3, x3, x2
    cbb0:	9ac90862 	udiv	x2, x3, x9
    cbb4:	aa0203e8 	mov	x8, x2
    cbb8:	9b098c42 	msub	x2, x2, x9, x3
    cbbc:	aa0703e3 	mov	x3, x7
    cbc0:	9b057d05 	mul	x5, x8, x5
    cbc4:	b3607c43 	bfi	x3, x2, #32, #32
    cbc8:	eb0300bf 	cmp	x5, x3
    cbcc:	540000c9 	b.ls	cbe4 <__divti3+0x284>  // b.plast
    cbd0:	ab0300c2 	adds	x2, x6, x3
    cbd4:	d1000503 	sub	x3, x8, #0x1
    cbd8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cbdc:	d1000908 	sub	x8, x8, #0x2
    cbe0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cbe4:	aa008100 	orr	x0, x8, x0, lsl #32
    cbe8:	17ffff90 	b	ca28 <__divti3+0xc8>
    cbec:	9ac820c6 	lsl	x6, x6, x8
    cbf0:	d2800803 	mov	x3, #0x40                  	// #64
    cbf4:	cb080063 	sub	x3, x3, x8
    cbf8:	d360fcc9 	lsr	x9, x6, #32
    cbfc:	9ac82027 	lsl	x7, x1, x8
    cc00:	92407cc5 	and	x5, x6, #0xffffffff
    cc04:	9ac32422 	lsr	x2, x1, x3
    cc08:	9ac32403 	lsr	x3, x0, x3
    cc0c:	aa070063 	orr	x3, x3, x7
    cc10:	9ac9084a 	udiv	x10, x2, x9
    cc14:	9ac82007 	lsl	x7, x0, x8
    cc18:	9b098940 	msub	x0, x10, x9, x2
    cc1c:	aa0a03e1 	mov	x1, x10
    cc20:	9b0a7ca2 	mul	x2, x5, x10
    cc24:	93c38000 	extr	x0, x0, x3, #32
    cc28:	eb00005f 	cmp	x2, x0
    cc2c:	540000a9 	b.ls	cc40 <__divti3+0x2e0>  // b.plast
    cc30:	ab0000c0 	adds	x0, x6, x0
    cc34:	d1000541 	sub	x1, x10, #0x1
    cc38:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cc3c:	54000468 	b.hi	ccc8 <__divti3+0x368>  // b.pmore
    cc40:	cb020000 	sub	x0, x0, x2
    cc44:	9ac9080a 	udiv	x10, x0, x9
    cc48:	9b098140 	msub	x0, x10, x9, x0
    cc4c:	aa0a03e2 	mov	x2, x10
    cc50:	9b0a7ca8 	mul	x8, x5, x10
    cc54:	b3607c03 	bfi	x3, x0, #32, #32
    cc58:	eb03011f 	cmp	x8, x3
    cc5c:	540000a9 	b.ls	cc70 <__divti3+0x310>  // b.plast
    cc60:	ab0300c3 	adds	x3, x6, x3
    cc64:	d1000542 	sub	x2, x10, #0x1
    cc68:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cc6c:	54000288 	b.hi	ccbc <__divti3+0x35c>  // b.pmore
    cc70:	cb080063 	sub	x3, x3, x8
    cc74:	aa018041 	orr	x1, x2, x1, lsl #32
    cc78:	17ffffc2 	b	cb80 <__divti3+0x220>
    cc7c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cc80:	d2800001 	mov	x1, #0x0                   	// #0
    cc84:	9a9f87e0 	cset	x0, ls	// ls = plast
    cc88:	17ffff68 	b	ca28 <__divti3+0xc8>
    cc8c:	aa0103e0 	mov	x0, x1
    cc90:	d2800001 	mov	x1, #0x0                   	// #0
    cc94:	17ffff65 	b	ca28 <__divti3+0xc8>
    cc98:	d1000860 	sub	x0, x3, #0x2
    cc9c:	8b0600a5 	add	x5, x5, x6
    cca0:	17ffff52 	b	c9e8 <__divti3+0x88>
    cca4:	d1000961 	sub	x1, x11, #0x2
    cca8:	8b0800a5 	add	x5, x5, x8
    ccac:	17ffff85 	b	cac0 <__divti3+0x160>
    ccb0:	d1000965 	sub	x5, x11, #0x2
    ccb4:	8b080063 	add	x3, x3, x8
    ccb8:	17ffff8e 	b	caf0 <__divti3+0x190>
    ccbc:	d1000942 	sub	x2, x10, #0x2
    ccc0:	8b060063 	add	x3, x3, x6
    ccc4:	17ffffeb 	b	cc70 <__divti3+0x310>
    ccc8:	d1000941 	sub	x1, x10, #0x2
    cccc:	8b060000 	add	x0, x0, x6
    ccd0:	17ffffdc 	b	cc40 <__divti3+0x2e0>
    ccd4:	d1000900 	sub	x0, x8, #0x2
    ccd8:	8b060063 	add	x3, x3, x6
    ccdc:	17ffffb4 	b	cbac <__divti3+0x24c>

000000000000cce0 <__modti3>:
    cce0:	d503245f 	bti	c
    cce4:	d2800004 	mov	x4, #0x0                   	// #0
    cce8:	b6f80081 	tbz	x1, #63, ccf8 <__modti3+0x18>
    ccec:	eb0003e0 	negs	x0, x0
    ccf0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ccf4:	da0103e1 	ngc	x1, x1
    ccf8:	f100007f 	cmp	x3, #0x0
    ccfc:	5400128b 	b.lt	cf4c <__modti3+0x26c>  // b.tstop
    cd00:	aa0003e7 	mov	x7, x0
    cd04:	aa0103e6 	mov	x6, x1
    cd08:	540004e1 	b.ne	cda4 <__modti3+0xc4>  // b.any
    cd0c:	eb02003f 	cmp	x1, x2
    cd10:	54000dc2 	b.cs	cec8 <__modti3+0x1e8>  // b.hs, b.nlast
    cd14:	dac01043 	clz	x3, x2
    cd18:	aa0303e5 	mov	x5, x3
    cd1c:	b40000e3 	cbz	x3, cd38 <__modti3+0x58>
    cd20:	4b0303e6 	neg	w6, w3
    cd24:	9ac32021 	lsl	x1, x1, x3
    cd28:	9ac32042 	lsl	x2, x2, x3
    cd2c:	9ac62406 	lsr	x6, x0, x6
    cd30:	aa0100c6 	orr	x6, x6, x1
    cd34:	9ac32007 	lsl	x7, x0, x3
    cd38:	d360fc40 	lsr	x0, x2, #32
    cd3c:	92407c43 	and	x3, x2, #0xffffffff
    cd40:	9ac008c1 	udiv	x1, x6, x0
    cd44:	9b009826 	msub	x6, x1, x0, x6
    cd48:	9b017c61 	mul	x1, x3, x1
    cd4c:	93c780c6 	extr	x6, x6, x7, #32
    cd50:	eb06003f 	cmp	x1, x6
    cd54:	540000a9 	b.ls	cd68 <__modti3+0x88>  // b.plast
    cd58:	ab060046 	adds	x6, x2, x6
    cd5c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cd60:	8b0200c8 	add	x8, x6, x2
    cd64:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cd68:	cb0100c6 	sub	x6, x6, x1
    cd6c:	9ac008c8 	udiv	x8, x6, x0
    cd70:	9b009901 	msub	x1, x8, x0, x6
    cd74:	aa0703e0 	mov	x0, x7
    cd78:	9b087c63 	mul	x3, x3, x8
    cd7c:	b3607c20 	bfi	x0, x1, #32, #32
    cd80:	eb00007f 	cmp	x3, x0
    cd84:	54001088 	b.hi	cf94 <__modti3+0x2b4>  // b.pmore
    cd88:	cb030000 	sub	x0, x0, x3
    cd8c:	9ac52400 	lsr	x0, x0, x5
    cd90:	d2800001 	mov	x1, #0x0                   	// #0
    cd94:	b4000064 	cbz	x4, cda0 <__modti3+0xc0>
    cd98:	eb0003e0 	negs	x0, x0
    cd9c:	da0103e1 	ngc	x1, x1
    cda0:	d65f03c0 	ret
    cda4:	dac01066 	clz	x6, x3
    cda8:	eb03003f 	cmp	x1, x3
    cdac:	54ffff43 	b.cc	cd94 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cdb0:	93407cc5 	sxtw	x5, w6
    cdb4:	d2800808 	mov	x8, #0x40                  	// #64
    cdb8:	cb050108 	sub	x8, x8, x5
    cdbc:	9ac62063 	lsl	x3, x3, x6
    cdc0:	9ac62025 	lsl	x5, x1, x6
    cdc4:	9ac82447 	lsr	x7, x2, x8
    cdc8:	aa0300e7 	orr	x7, x7, x3
    cdcc:	9ac82423 	lsr	x3, x1, x8
    cdd0:	92407cec 	and	x12, x7, #0xffffffff
    cdd4:	d360fcea 	lsr	x10, x7, #32
    cdd8:	9ac82401 	lsr	x1, x0, x8
    cddc:	aa050021 	orr	x1, x1, x5
    cde0:	9ac62042 	lsl	x2, x2, x6
    cde4:	9ac62000 	lsl	x0, x0, x6
    cde8:	9aca086b 	udiv	x11, x3, x10
    cdec:	9b0a8d63 	msub	x3, x11, x10, x3
    cdf0:	aa0b03e5 	mov	x5, x11
    cdf4:	9b0b7d89 	mul	x9, x12, x11
    cdf8:	93c18063 	extr	x3, x3, x1, #32
    cdfc:	eb03013f 	cmp	x9, x3
    ce00:	540000a9 	b.ls	ce14 <__modti3+0x134>  // b.plast
    ce04:	ab0300e3 	adds	x3, x7, x3
    ce08:	d1000565 	sub	x5, x11, #0x1
    ce0c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ce10:	54001168 	b.hi	d03c <__modti3+0x35c>  // b.pmore
    ce14:	cb090063 	sub	x3, x3, x9
    ce18:	9aca086b 	udiv	x11, x3, x10
    ce1c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ce20:	aa0b03e9 	mov	x9, x11
    ce24:	9b0b7d8c 	mul	x12, x12, x11
    ce28:	b3607d41 	bfi	x1, x10, #32, #32
    ce2c:	eb01019f 	cmp	x12, x1
    ce30:	540000a9 	b.ls	ce44 <__modti3+0x164>  // b.plast
    ce34:	ab0100e1 	adds	x1, x7, x1
    ce38:	d1000569 	sub	x9, x11, #0x1
    ce3c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ce40:	54000f88 	b.hi	d030 <__modti3+0x350>  // b.pmore
    ce44:	aa058123 	orr	x3, x9, x5, lsl #32
    ce48:	92407c4b 	and	x11, x2, #0xffffffff
    ce4c:	2a0903e9 	mov	w9, w9
    ce50:	d360fc4a 	lsr	x10, x2, #32
    ce54:	d360fc63 	lsr	x3, x3, #32
    ce58:	cb0c0021 	sub	x1, x1, x12
    ce5c:	aa0a03ec 	mov	x12, x10
    ce60:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ce64:	9b0b7d25 	mul	x5, x9, x11
    ce68:	9b0b7c6b 	mul	x11, x3, x11
    ce6c:	9b0a2d29 	madd	x9, x9, x10, x11
    ce70:	92407caa 	and	x10, x5, #0xffffffff
    ce74:	9b0c7c63 	mul	x3, x3, x12
    ce78:	8b458125 	add	x5, x9, x5, lsr #32
    ce7c:	8b0d0069 	add	x9, x3, x13
    ce80:	eb05017f 	cmp	x11, x5
    ce84:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ce88:	8b058149 	add	x9, x10, x5, lsl #32
    ce8c:	8b458063 	add	x3, x3, x5, lsr #32
    ce90:	eb03003f 	cmp	x1, x3
    ce94:	54000063 	b.cc	cea0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ce98:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ce9c:	54000082 	b.cs	ceac <__modti3+0x1cc>  // b.hs, b.nlast
    cea0:	eb020129 	subs	x9, x9, x2
    cea4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cea8:	cb070063 	sub	x3, x3, x7
    ceac:	eb090000 	subs	x0, x0, x9
    ceb0:	da030021 	sbc	x1, x1, x3
    ceb4:	9ac62400 	lsr	x0, x0, x6
    ceb8:	9ac82028 	lsl	x8, x1, x8
    cebc:	aa000100 	orr	x0, x8, x0
    cec0:	9ac62421 	lsr	x1, x1, x6
    cec4:	17ffffb4 	b	cd94 <__modti3+0xb4>
    cec8:	b5000062 	cbnz	x2, ced4 <__modti3+0x1f4>
    cecc:	d2800023 	mov	x3, #0x1                   	// #1
    ced0:	9ac20862 	udiv	x2, x3, x2
    ced4:	dac01048 	clz	x8, x2
    ced8:	aa0803e5 	mov	x5, x8
    cedc:	b5000668 	cbnz	x8, cfa8 <__modti3+0x2c8>
    cee0:	cb020020 	sub	x0, x1, x2
    cee4:	d360fc49 	lsr	x9, x2, #32
    cee8:	92407c4a 	and	x10, x2, #0xffffffff
    ceec:	9ac90801 	udiv	x1, x0, x9
    cef0:	9b098020 	msub	x0, x1, x9, x0
    cef4:	9b0a7c21 	mul	x1, x1, x10
    cef8:	93c78000 	extr	x0, x0, x7, #32
    cefc:	eb00003f 	cmp	x1, x0
    cf00:	540000a9 	b.ls	cf14 <__modti3+0x234>  // b.plast
    cf04:	ab000040 	adds	x0, x2, x0
    cf08:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf0c:	8b020003 	add	x3, x0, x2
    cf10:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cf14:	cb010001 	sub	x1, x0, x1
    cf18:	9ac90820 	udiv	x0, x1, x9
    cf1c:	9b098403 	msub	x3, x0, x9, x1
    cf20:	aa0703e1 	mov	x1, x7
    cf24:	9b0a7c00 	mul	x0, x0, x10
    cf28:	b3607c61 	bfi	x1, x3, #32, #32
    cf2c:	eb01001f 	cmp	x0, x1
    cf30:	540000a9 	b.ls	cf44 <__modti3+0x264>  // b.plast
    cf34:	ab010041 	adds	x1, x2, x1
    cf38:	8b020022 	add	x2, x1, x2
    cf3c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cf40:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cf44:	cb000020 	sub	x0, x1, x0
    cf48:	17ffff91 	b	cd8c <__modti3+0xac>
    cf4c:	eb0203e5 	negs	x5, x2
    cf50:	aa0003e7 	mov	x7, x0
    cf54:	da0303e8 	ngc	x8, x3
    cf58:	aa0503e2 	mov	x2, x5
    cf5c:	aa0803e3 	mov	x3, x8
    cf60:	aa0103e6 	mov	x6, x1
    cf64:	b4ffed48 	cbz	x8, cd0c <__modti3+0x2c>
    cf68:	eb01011f 	cmp	x8, x1
    cf6c:	54fff148 	b.hi	cd94 <__modti3+0xb4>  // b.pmore
    cf70:	dac01109 	clz	x9, x8
    cf74:	2a0903e6 	mov	w6, w9
    cf78:	b5fff1c9 	cbnz	x9, cdb0 <__modti3+0xd0>
    cf7c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cf80:	54000068 	b.hi	cf8c <__modti3+0x2ac>  // b.pmore
    cf84:	eb050007 	subs	x7, x0, x5
    cf88:	da080021 	sbc	x1, x1, x8
    cf8c:	aa0703e0 	mov	x0, x7
    cf90:	17ffff81 	b	cd94 <__modti3+0xb4>
    cf94:	ab000040 	adds	x0, x2, x0
    cf98:	8b020002 	add	x2, x0, x2
    cf9c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cfa0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cfa4:	17ffff79 	b	cd88 <__modti3+0xa8>
    cfa8:	9ac82042 	lsl	x2, x2, x8
    cfac:	d2800803 	mov	x3, #0x40                  	// #64
    cfb0:	cb080063 	sub	x3, x3, x8
    cfb4:	d360fc49 	lsr	x9, x2, #32
    cfb8:	9ac82027 	lsl	x7, x1, x8
    cfbc:	92407c4a 	and	x10, x2, #0xffffffff
    cfc0:	9ac32426 	lsr	x6, x1, x3
    cfc4:	9ac32403 	lsr	x3, x0, x3
    cfc8:	aa070063 	orr	x3, x3, x7
    cfcc:	9ac908c1 	udiv	x1, x6, x9
    cfd0:	9ac82007 	lsl	x7, x0, x8
    cfd4:	9b099820 	msub	x0, x1, x9, x6
    cfd8:	9b017d41 	mul	x1, x10, x1
    cfdc:	93c38000 	extr	x0, x0, x3, #32
    cfe0:	eb00003f 	cmp	x1, x0
    cfe4:	540000a9 	b.ls	cff8 <__modti3+0x318>  // b.plast
    cfe8:	ab000040 	adds	x0, x2, x0
    cfec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cff0:	8b020006 	add	x6, x0, x2
    cff4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cff8:	cb010000 	sub	x0, x0, x1
    cffc:	9ac90801 	udiv	x1, x0, x9
    d000:	9b098026 	msub	x6, x1, x9, x0
    d004:	aa0303e0 	mov	x0, x3
    d008:	9b017d41 	mul	x1, x10, x1
    d00c:	b3607cc0 	bfi	x0, x6, #32, #32
    d010:	eb00003f 	cmp	x1, x0
    d014:	540000a9 	b.ls	d028 <__modti3+0x348>  // b.plast
    d018:	ab000040 	adds	x0, x2, x0
    d01c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d020:	8b020003 	add	x3, x0, x2
    d024:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d028:	cb010000 	sub	x0, x0, x1
    d02c:	17ffffb0 	b	ceec <__modti3+0x20c>
    d030:	d1000969 	sub	x9, x11, #0x2
    d034:	8b070021 	add	x1, x1, x7
    d038:	17ffff83 	b	ce44 <__modti3+0x164>
    d03c:	d1000965 	sub	x5, x11, #0x2
    d040:	8b070063 	add	x3, x3, x7
    d044:	17ffff74 	b	ce14 <__modti3+0x134>
    d048:	d503201f 	nop
    d04c:	d503201f 	nop

000000000000d050 <atexit>:
    d050:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d054:	f0000082 	adrp	x2, 20000 <__data_start>
    d058:	d2800001 	mov	x1, #0x0                   	// #0
    d05c:	910003fd 	mov	x29, sp
    d060:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d064:	f9400442 	ldr	x2, [x2, #8]
    d068:	17ffd5ea 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d06c <_fini>:
    d06c:	d503201f 	nop
    d070:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d074:	910003fd 	mov	x29, sp
    d078:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d07c:	d65f03c0 	ret
