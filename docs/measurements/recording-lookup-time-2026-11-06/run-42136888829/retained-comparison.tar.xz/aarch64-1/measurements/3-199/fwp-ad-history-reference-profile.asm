
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-199/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__divti3+0x110>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9125a0a5 	add	x5, x5, #0x968
    2a20:	b0000044 	adrp	x4, b000 <__divti3+0x110>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9125c084 	add	x4, x4, #0x970
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10600>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__divti3+0x110>
    2ab4:	913ae000 	add	x0, x0, #0xeb8
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x770>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91220042 	add	x2, x2, #0x880
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943da60 	ldr	w0, [x19, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <__divti3+0x110>
    2bfc:	913b2000 	add	x0, x0, #0xec8
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	b0000040 	adrp	x0, b000 <__divti3+0x110>
    2c0c:	913da000 	add	x0, x0, #0xf68
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <__divti3+0x110>
    2c24:	913d0000 	add	x0, x0, #0xf40
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <__divti3+0x110>
    2c30:	913c4000 	add	x0, x0, #0xf10
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <__divti3+0x110>
    2c3c:	913ba000 	add	x0, x0, #0xee8
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0x9f0>
    2e34:	91168021 	add	x1, x1, #0x5a0
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x9f0>
    30d8:	91160021 	add	x1, x1, #0x580
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3110:	91186000 	add	x0, x0, #0x618
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	90000042 	adrp	x2, b000 <__divti3+0x110>
    331c:	9118c042 	add	x2, x2, #0x630
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	90000042 	adrp	x2, b000 <__divti3+0x110>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	911a2042 	add	x2, x2, #0x688
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	90000059 	adrp	x25, b000 <__divti3+0x110>
    33a8:	9000005a 	adrp	x26, b000 <__divti3+0x110>
    33ac:	911ba339 	add	x25, x25, #0x6e8
    33b0:	9119435a 	add	x26, x26, #0x650
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	9000005b 	adrp	x27, b000 <__divti3+0x110>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	91196377 	add	x23, x27, #0x658
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	911ca000 	add	x0, x0, #0x728
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfba0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfba0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfba0>
    347c:	90000043 	adrp	x3, b000 <__divti3+0x110>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	90000055 	adrp	x21, b000 <__divti3+0x110>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	91194063 	add	x3, x3, #0x650
    34a0:	911d02b5 	add	x21, x21, #0x740
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	90000040 	adrp	x0, b000 <__divti3+0x110>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	911e0000 	add	x0, x0, #0x780
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	90000040 	adrp	x0, b000 <__divti3+0x110>
    352c:	91198000 	add	x0, x0, #0x660
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	90000040 	adrp	x0, b000 <__divti3+0x110>
    35ec:	91186000 	add	x0, x0, #0x618
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	90000041 	adrp	x1, b000 <__divti3+0x110>
    3730:	aa1303e0 	mov	x0, x19
    3734:	911e2021 	add	x1, x1, #0x788
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	90000041 	adrp	x1, b000 <__divti3+0x110>
    3744:	aa1303e0 	mov	x0, x19
    3748:	911e4021 	add	x1, x1, #0x790
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	90000041 	adrp	x1, b000 <__divti3+0x110>
    3760:	911e6021 	add	x1, x1, #0x798
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	90000042 	adrp	x2, b000 <__divti3+0x110>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	911e8042 	add	x2, x2, #0x7a0
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	90000040 	adrp	x0, b000 <__divti3+0x110>
    38d0:	91186000 	add	x0, x0, #0x618
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	90000040 	adrp	x0, b000 <__divti3+0x110>
    38f0:	911ec000 	add	x0, x0, #0x7b0
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3988:	911f4000 	add	x0, x0, #0x7d0
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3998:	911fc000 	add	x0, x0, #0x7f0
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x9f0>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc16c20 	ldr	q0, [x1, #1456]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3a98:	91206000 	add	x0, x0, #0x818
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3b08:	91212000 	add	x0, x0, #0x848
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	90000044 	adrp	x4, b000 <__divti3+0x110>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	91226084 	add	x4, x4, #0x898
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	90000044 	adrp	x4, b000 <__divti3+0x110>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	9122c084 	add	x4, x4, #0x8b0
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	90000044 	adrp	x4, b000 <__divti3+0x110>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	91228084 	add	x4, x4, #0x8a0
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3f28:	91190042 	add	x2, x2, #0x640
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	90000041 	adrp	x1, b000 <__divti3+0x110>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	90000040 	adrp	x0, b000 <__divti3+0x110>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	9122e021 	add	x1, x1, #0x8b8
    3f84:	91230000 	add	x0, x0, #0x8c0
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	f0000022 	adrp	x2, b000 <__divti3+0x110>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	91238042 	add	x2, x2, #0x8e0
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    408c:	91150061 	add	x1, x3, #0x540
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    409c:	91190262 	add	x2, x19, #0x640
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	90000042 	adrp	x2, c000 <_IO_stdin_used+0x9f0>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    40cc:	91160021 	add	x1, x1, #0x580
    40d0:	3dc17043 	ldr	q3, [x2, #1472]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    40fc:	91150063 	add	x3, x3, #0x540
    4100:	91178084 	add	x4, x4, #0x5e0
    4104:	91190266 	add	x6, x19, #0x640
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91190275 	add	x21, x19, #0x640
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    41e8:	91264000 	add	x0, x0, #0x990
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91190273 	add	x19, x19, #0x640
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <fwp_wake_io>:
    4244:	900000e9 	adrp	x9, 20000 <__data_start>
    4248:	91018122 	add	x2, x9, #0x60
    424c:	f9400001 	ldr	x1, [x0]
    4250:	5280000a 	mov	w10, #0x0                   	// #0
    4254:	f9406046 	ldr	x6, [x2, #192]
    4258:	52800008 	mov	w8, #0x0                   	// #0
    425c:	4f000400 	movi	v0.4s, #0x0
    4260:	52800027 	mov	w7, #0x1                   	// #1
    4264:	aa0103e2 	mov	x2, x1
    4268:	b4000321 	cbz	x1, 42cc <fwp_wake_io+0x88>
    426c:	f9408c25 	ldr	x5, [x1, #280]
    4270:	39015c27 	strb	w7, [x1, #87]
    4274:	b4000165 	cbz	x5, 42a0 <fwp_wake_io+0x5c>
    4278:	a9520c24 	ldp	x4, x3, [x1, #288]
    427c:	b4000364 	cbz	x4, 42e8 <fwp_wake_io+0xa4>
    4280:	f9009483 	str	x3, [x4, #296]
    4284:	f9409423 	ldr	x3, [x1, #296]
    4288:	b4000043 	cbz	x3, 4290 <fwp_wake_io+0x4c>
    428c:	f9009064 	str	x4, [x3, #288]
    4290:	91080023 	add	x3, x1, #0x200
    4294:	f900943f 	str	xzr, [x1, #296]
    4298:	3c918060 	stur	q0, [x3, #-232]
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	f9402843 	ldr	x3, [x2, #80]
    42a4:	f2001c7f 	tst	x3, #0xff000000ff
    42a8:	54fffde1 	b.ne	4264 <fwp_wake_io+0x20>  // b.any
    42ac:	39015047 	strb	w7, [x2, #84]
    42b0:	f900805f 	str	xzr, [x2, #256]
    42b4:	b40001e6 	cbz	x6, 42f0 <fwp_wake_io+0xac>
    42b8:	f90080c2 	str	x2, [x6, #256]
    42bc:	aa0203e6 	mov	x6, x2
    42c0:	52800028 	mov	w8, #0x1                   	// #1
    42c4:	aa0103e2 	mov	x2, x1
    42c8:	b5fffd21 	cbnz	x1, 426c <fwp_wake_io+0x28>
    42cc:	3400006a 	cbz	w10, 42d8 <fwp_wake_io+0x94>
    42d0:	91018120 	add	x0, x9, #0x60
    42d4:	f900640b 	str	x11, [x0, #200]
    42d8:	34000068 	cbz	w8, 42e4 <fwp_wake_io+0xa0>
    42dc:	91018129 	add	x9, x9, #0x60
    42e0:	f9006126 	str	x6, [x9, #192]
    42e4:	d65f03c0 	ret
    42e8:	f90000a3 	str	x3, [x5]
    42ec:	17ffffe7 	b	4288 <fwp_wake_io+0x44>
    42f0:	aa0203eb 	mov	x11, x2
    42f4:	5280002a 	mov	w10, #0x1                   	// #1
    42f8:	17fffff1 	b	42bc <fwp_wake_io+0x78>
    42fc:	d503201f 	nop

0000000000004300 <ad_raw_free.part.0>:
    4300:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	91118082 	add	x2, x4, #0x460
    430c:	14000005 	b	4320 <ad_raw_free.part.0+0x20>
    4310:	91000421 	add	x1, x1, #0x1
    4314:	91006042 	add	x2, x2, #0x18
    4318:	f140043f 	cmp	x1, #0x1, lsl #12
    431c:	54000220 	b.eq	4360 <ad_raw_free.part.0+0x60>  // b.none
    4320:	f9400043 	ldr	x3, [x2]
    4324:	eb03001f 	cmp	x0, x3
    4328:	54ffff41 	b.ne	4310 <ad_raw_free.part.0+0x10>  // b.any
    432c:	8b010421 	add	x1, x1, x1, lsl #1
    4330:	91118084 	add	x4, x4, #0x460
    4334:	900000e2 	adrp	x2, 20000 <__data_start>
    4338:	91018042 	add	x2, x2, #0x60
    433c:	8b010c81 	add	x1, x4, x1, lsl #3
    4340:	b9401024 	ldr	w4, [x1, #16]
    4344:	f9400425 	ldr	x5, [x1, #8]
    4348:	a9007c3f 	stp	xzr, xzr, [x1]
    434c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4350:	f900083f 	str	xzr, [x1, #16]
    4354:	cb050061 	sub	x1, x3, x5
    4358:	f8247841 	str	x1, [x2, x4, lsl #3]
    435c:	17fff95d 	b	28d0 <free@plt>
    4360:	f100001f 	cmp	x0, #0x0
    4364:	f0000021 	adrp	x1, b000 <__divti3+0x110>
    4368:	9126e021 	add	x1, x1, #0x9b8
    436c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4370:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4374:	91268000 	add	x0, x0, #0x9a0
    4378:	910003fd 	mov	x29, sp
    437c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4380:	97fffbe0 	bl	3300 <ad_raw_fail>

0000000000004384 <fwp_tape_buffers_dispose>:
    4384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4388:	910003fd 	mov	x29, sp
    438c:	f9000bf3 	str	x19, [sp, #16]
    4390:	aa0003f3 	mov	x19, x0
    4394:	f9400000 	ldr	x0, [x0]
    4398:	b4000040 	cbz	x0, 43a0 <fwp_tape_buffers_dispose+0x1c>
    439c:	97ffffd9 	bl	4300 <ad_raw_free.part.0>
    43a0:	f9400a60 	ldr	x0, [x19, #16]
    43a4:	b4000040 	cbz	x0, 43ac <fwp_tape_buffers_dispose+0x28>
    43a8:	97ffffd6 	bl	4300 <ad_raw_free.part.0>
    43ac:	f9401260 	ldr	x0, [x19, #32]
    43b0:	b4000040 	cbz	x0, 43b8 <fwp_tape_buffers_dispose+0x34>
    43b4:	97ffffd3 	bl	4300 <ad_raw_free.part.0>
    43b8:	4f000400 	movi	v0.4s, #0x0
    43bc:	f9001a7f 	str	xzr, [x19, #48]
    43c0:	ad000260 	stp	q0, q0, [x19]
    43c4:	3d800a60 	str	q0, [x19, #32]
    43c8:	f9400bf3 	ldr	x19, [sp, #16]
    43cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43d0:	d65f03c0 	ret

00000000000043d4 <ad_raw_realloc>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	f90013f5 	str	x21, [sp, #32]
    43e4:	b40005a1 	cbz	x1, 4498 <ad_raw_realloc+0xc4>
    43e8:	aa0103f4 	mov	x20, x1
    43ec:	2a0203f5 	mov	w21, w2
    43f0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    43f4:	d2800004 	mov	x4, #0x0                   	// #0
    43f8:	91118025 	add	x5, x1, #0x460
    43fc:	14000005 	b	4410 <ad_raw_realloc+0x3c>
    4400:	91000484 	add	x4, x4, #0x1
    4404:	910060a5 	add	x5, x5, #0x18
    4408:	f140049f 	cmp	x4, #0x1, lsl #12
    440c:	54000320 	b.eq	4470 <ad_raw_realloc+0x9c>  // b.none
    4410:	f94000a6 	ldr	x6, [x5]
    4414:	eb06001f 	cmp	x0, x6
    4418:	54ffff41 	b.ne	4400 <ad_raw_realloc+0x2c>  // b.any
    441c:	8b040484 	add	x4, x4, x4, lsl #1
    4420:	91118021 	add	x1, x1, #0x460
    4424:	8b040c33 	add	x19, x1, x4, lsl #3
    4428:	b4000080 	cbz	x0, 4438 <ad_raw_realloc+0x64>
    442c:	b9401261 	ldr	w1, [x19, #16]
    4430:	6b15003f 	cmp	w1, w21
    4434:	540002c1 	b.ne	448c <ad_raw_realloc+0xb8>  // b.any
    4438:	aa1403e1 	mov	x1, x20
    443c:	97fff8f1 	bl	2800 <realloc@plt>
    4440:	aa0003ed 	mov	x13, x0
    4444:	b40000c0 	cbz	x0, 445c <ad_raw_realloc+0x88>
    4448:	2a1503e3 	mov	w3, w21
    444c:	aa1403e2 	mov	x2, x20
    4450:	aa1303e0 	mov	x0, x19
    4454:	aa0d03e1 	mov	x1, x13
    4458:	97fffaae 	bl	2f10 <ad_raw_record>
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	aa0d03e0 	mov	x0, x13
    4464:	f94013f5 	ldr	x21, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	f100001f 	cmp	x0, #0x0
    4474:	f0000021 	adrp	x1, b000 <__divti3+0x110>
    4478:	9126e021 	add	x1, x1, #0x9b8
    447c:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4480:	91268000 	add	x0, x0, #0x9a0
    4484:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4488:	97fffb9e 	bl	3300 <ad_raw_fail>
    448c:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4490:	9127e000 	add	x0, x0, #0x9f8
    4494:	97fffb9b 	bl	3300 <ad_raw_fail>
    4498:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    449c:	91276000 	add	x0, x0, #0x9d8
    44a0:	97fffb98 	bl	3300 <ad_raw_fail>

00000000000044a4 <fwp_tape_buffers_release>:
    44a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f4 	mov	x20, x0
    44b4:	f9401400 	ldr	x0, [x0, #40]
    44b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44bc:	b7f80560 	tbnz	x0, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c0:	f9401a93 	ldr	x19, [x20, #48]
    44c4:	b7f80533 	tbnz	x19, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    44cc:	eb01001f 	cmp	x0, x1
    44d0:	540004c8 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44d4:	8b000400 	add	x0, x0, x0, lsl #1
    44d8:	d2a00101 	mov	x1, #0x80000               	// #524288
    44dc:	d37df000 	lsl	x0, x0, #3
    44e0:	cb000021 	sub	x1, x1, x0
    44e4:	eb410e7f 	cmp	x19, x1, lsr #3
    44e8:	54000408 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44ec:	8b130c13 	add	x19, x0, x19, lsl #3
    44f0:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    44f4:	91284000 	add	x0, x0, #0xa10
    44f8:	97fff92a 	bl	29a0 <getenv@plt>
    44fc:	b4000080 	cbz	x0, 450c <fwp_tape_buffers_release+0x68>
    4500:	39400001 	ldrb	w1, [x0]
    4504:	7100c03f 	cmp	w1, #0x30
    4508:	54000880 	b.eq	4618 <fwp_tape_buffers_release+0x174>  // b.none
    450c:	d1000661 	sub	x1, x19, #0x1
    4510:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4514:	eb00003f 	cmp	x1, x0
    4518:	54000328 	b.hi	457c <fwp_tape_buffers_release+0xd8>  // b.pmore
    451c:	900000f5 	adrp	x21, 20000 <__data_start>
    4520:	f9001bf7 	str	x23, [sp, #48]
    4524:	910182b7 	add	x23, x21, #0x60
    4528:	910382f6 	add	x22, x23, #0xe0
    452c:	aa1603e0 	mov	x0, x22
    4530:	97ffff95 	bl	4384 <fwp_tape_buffers_dispose>
    4534:	ad400a81 	ldp	q1, q2, [x20]
    4538:	f9008ef3 	str	x19, [x23, #280]
    453c:	4f000400 	movi	v0.4s, #0x0
    4540:	ad000ac1 	stp	q1, q2, [x22]
    4544:	3dc00a81 	ldr	q1, [x20, #32]
    4548:	3d800ac1 	str	q1, [x22, #32]
    454c:	f9401a80 	ldr	x0, [x20, #48]
    4550:	f9001ac0 	str	x0, [x22, #48]
    4554:	f9001a9f 	str	xzr, [x20, #48]
    4558:	ad000280 	stp	q0, q0, [x20]
    455c:	3d800a80 	str	q0, [x20, #32]
    4560:	f9401bf7 	ldr	x23, [sp, #48]
    4564:	1400000b 	b	4590 <fwp_tape_buffers_release+0xec>
    4568:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    456c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4570:	91284000 	add	x0, x0, #0xa10
    4574:	97fff90b 	bl	29a0 <getenv@plt>
    4578:	b5fffc40 	cbnz	x0, 4500 <fwp_tape_buffers_release+0x5c>
    457c:	aa1403e0 	mov	x0, x20
    4580:	97ffff81 	bl	4384 <fwp_tape_buffers_dispose>
    4584:	900000f5 	adrp	x21, 20000 <__data_start>
    4588:	910182a0 	add	x0, x21, #0x60
    458c:	f9408c13 	ldr	x19, [x0, #280]
    4590:	910182a2 	add	x2, x21, #0x60
    4594:	f9409044 	ldr	x4, [x2, #288]
    4598:	a9400c45 	ldp	x5, x3, [x2]
    459c:	8b040481 	add	x1, x4, x4, lsl #1
    45a0:	f9400840 	ldr	x0, [x2, #16]
    45a4:	8b010881 	add	x1, x4, x1, lsl #2
    45a8:	f9400c44 	ldr	x4, [x2, #24]
    45ac:	8b0300a3 	add	x3, x5, x3
    45b0:	d37df021 	lsl	x1, x1, #3
    45b4:	8b040000 	add	x0, x0, x4
    45b8:	8b030000 	add	x0, x0, x3
    45bc:	eb05003f 	cmp	x1, x5
    45c0:	54000321 	b.ne	4624 <fwp_tape_buffers_release+0x180>  // b.any
    45c4:	8b130023 	add	x3, x1, x19
    45c8:	eb00007f 	cmp	x3, x0
    45cc:	540002c8 	b.hi	4624 <fwp_tape_buffers_release+0x180>  // b.pmore
    45d0:	f9405c43 	ldr	x3, [x2, #184]
    45d4:	f140087f 	cmp	x3, #0x2, lsl #12
    45d8:	540002e0 	b.eq	4634 <fwp_tape_buffers_release+0x190>  // b.none
    45dc:	8b030464 	add	x4, x3, x3, lsl #1
    45e0:	90000165 	adrp	x5, 30000 <alt.5+0xfba0>
    45e4:	911180a5 	add	x5, x5, #0x460
    45e8:	cb010000 	sub	x0, x0, x1
    45ec:	d37df084 	lsl	x4, x4, #3
    45f0:	cb130000 	sub	x0, x0, x19
    45f4:	8b0400a6 	add	x6, x5, x4
    45f8:	91000463 	add	x3, x3, #0x1
    45fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4600:	f82468a1 	str	x1, [x5, x4]
    4604:	a90080d3 	stp	x19, x0, [x6, #8]
    4608:	f9005c43 	str	x3, [x2, #184]
    460c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4610:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4614:	d65f03c0 	ret
    4618:	39400400 	ldrb	w0, [x0, #1]
    461c:	34fffb00 	cbz	w0, 457c <fwp_tape_buffers_release+0xd8>
    4620:	17ffffbb 	b	450c <fwp_tape_buffers_release+0x68>
    4624:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4628:	9128a000 	add	x0, x0, #0xa28
    462c:	f9001bf7 	str	x23, [sp, #48]
    4630:	97fffb34 	bl	3300 <ad_raw_fail>
    4634:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4638:	91296000 	add	x0, x0, #0xa58
    463c:	f9001bf7 	str	x23, [sp, #48]
    4640:	97fffb30 	bl	3300 <ad_raw_fail>

0000000000004644 <fwp_poll_events>:
    4644:	d10103ff 	sub	sp, sp, #0x40
    4648:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    464c:	f947f400 	ldr	x0, [x0, #4072]
    4650:	a9027bfd 	stp	x29, x30, [sp, #32]
    4654:	910083fd 	add	x29, sp, #0x20
    4658:	a90353f3 	stp	x19, x20, [sp, #48]
    465c:	900000f4 	adrp	x20, 20000 <__data_start>
    4660:	f9400001 	ldr	x1, [x0]
    4664:	f9000fe1 	str	x1, [sp, #24]
    4668:	d2800001 	mov	x1, #0x0                   	// #0
    466c:	97fffca5 	bl	3900 <fwp_now_ns>
    4670:	91018281 	add	x1, x20, #0x60
    4674:	f9409433 	ldr	x19, [x1, #296]
    4678:	b4000e73 	cbz	x19, 4844 <fwp_poll_events+0x200>
    467c:	aa1303e1 	mov	x1, x19
    4680:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4684:	14000005 	b	4698 <fwp_poll_events+0x54>
    4688:	f9408821 	ldr	x1, [x1, #272]
    468c:	eb03005f 	cmp	x2, x3
    4690:	9a83d042 	csel	x2, x2, x3, le
    4694:	b40000c1 	cbz	x1, 46ac <fwp_poll_events+0x68>
    4698:	f9403423 	ldr	x3, [x1, #104]
    469c:	b6ffff62 	tbz	x2, #63, 4688 <fwp_poll_events+0x44>
    46a0:	f9408821 	ldr	x1, [x1, #272]
    46a4:	aa0303e2 	mov	x2, x3
    46a8:	b5ffff81 	cbnz	x1, 4698 <fwp_poll_events+0x54>
    46ac:	b7f80cc2 	tbnz	x2, #63, 4844 <fwp_poll_events+0x200>
    46b0:	cb000042 	sub	x2, x2, x0
    46b4:	f100005f 	cmp	x2, #0x0
    46b8:	540005ad 	b.le	476c <fwp_poll_events+0x128>
    46bc:	d2869b60 	mov	x0, #0x34db                	// #13531
    46c0:	d2884801 	mov	x1, #0x4240                	// #16960
    46c4:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    46c8:	f2a001e1 	movk	x1, #0xf, lsl #16
    46cc:	f2dbd040 	movk	x0, #0xde82, lsl #32
    46d0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    46d4:	f2e86360 	movk	x0, #0x431b, lsl #48
    46d8:	9b407c40 	smulh	x0, x2, x0
    46dc:	9352fc00 	asr	x0, x0, #18
    46e0:	cb82fc00 	sub	x0, x0, x2, asr #63
    46e4:	9b018802 	msub	x2, x0, x1, x2
    46e8:	f100005f 	cmp	x2, #0x0
    46ec:	9a800400 	cinc	x0, x0, ne	// ne = any
    46f0:	eb03001f 	cmp	x0, x3
    46f4:	540009ec 	b.gt	4830 <fwp_poll_events+0x1ec>
    46f8:	340003a0 	cbz	w0, 476c <fwp_poll_events+0x128>
    46fc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4700:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4704:	72a20c42 	movk	w2, #0x1062, lsl #16
    4708:	9ba27c02 	umull	x2, w0, w2
    470c:	d366fc43 	lsr	x3, x2, #38
    4710:	aa0303e2 	mov	x2, x3
    4714:	1b048063 	msub	w3, w3, w4, w0
    4718:	9b217c63 	smull	x3, w3, w1
    471c:	d2800001 	mov	x1, #0x0                   	// #0
    4720:	910023e0 	add	x0, sp, #0x8
    4724:	a9008fe2 	stp	x2, x3, [sp, #8]
    4728:	97fff86e 	bl	28e0 <nanosleep@plt>
    472c:	91018280 	add	x0, x20, #0x60
    4730:	f9409413 	ldr	x19, [x0, #296]
    4734:	97fffc73 	bl	3900 <fwp_now_ns>
    4738:	aa0003e6 	mov	x6, x0
    473c:	b50001d3 	cbnz	x19, 4774 <fwp_poll_events+0x130>
    4740:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4744:	f947f400 	ldr	x0, [x0, #4072]
    4748:	f9400fe2 	ldr	x2, [sp, #24]
    474c:	f9400001 	ldr	x1, [x0]
    4750:	eb010042 	subs	x2, x2, x1
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	540008c1 	b.ne	4870 <fwp_poll_events+0x22c>  // b.any
    475c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4760:	a94353f3 	ldp	x19, x20, [sp, #48]
    4764:	910103ff 	add	sp, sp, #0x40
    4768:	d65f03c0 	ret
    476c:	97fffc65 	bl	3900 <fwp_now_ns>
    4770:	aa0003e6 	mov	x6, x0
    4774:	4f000400 	movi	v0.4s, #0x0
    4778:	91018288 	add	x8, x20, #0x60
    477c:	52800027 	mov	w7, #0x1                   	// #1
    4780:	f9403661 	ldr	x1, [x19, #104]
    4784:	aa1303e5 	mov	x5, x19
    4788:	f9408a73 	ldr	x19, [x19, #272]
    478c:	eb06003f 	cmp	x1, x6
    4790:	5400032c 	b.gt	47f4 <fwp_poll_events+0x1b0>
    4794:	394154a0 	ldrb	w0, [x5, #85]
    4798:	36000120 	tbz	w0, #0, 47bc <fwp_poll_events+0x178>
    479c:	f94084a0 	ldr	x0, [x5, #264]
    47a0:	b40003c0 	cbz	x0, 4818 <fwp_poll_events+0x1d4>
    47a4:	f9008813 	str	x19, [x0, #272]
    47a8:	b4000053 	cbz	x19, 47b0 <fwp_poll_events+0x16c>
    47ac:	f9008660 	str	x0, [x19, #264]
    47b0:	910800a0 	add	x0, x5, #0x200
    47b4:	390154bf 	strb	wzr, [x5, #85]
    47b8:	3c908000 	stur	q0, [x0, #-248]
    47bc:	f94030a0 	ldr	x0, [x5, #96]
    47c0:	390158a7 	strb	w7, [x5, #86]
    47c4:	f100001f 	cmp	x0, #0x0
    47c8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    47cc:	5400018d 	b.le	47fc <fwp_poll_events+0x1b8>
    47d0:	f94028a0 	ldr	x0, [x5, #80]
    47d4:	f2001c1f 	tst	x0, #0xff000000ff
    47d8:	540000e1 	b.ne	47f4 <fwp_poll_events+0x1b0>  // b.any
    47dc:	f9406100 	ldr	x0, [x8, #192]
    47e0:	390150a7 	strb	w7, [x5, #84]
    47e4:	f90080bf 	str	xzr, [x5, #256]
    47e8:	b40001e0 	cbz	x0, 4824 <fwp_poll_events+0x1e0>
    47ec:	f9006105 	str	x5, [x8, #192]
    47f0:	f9008005 	str	x5, [x0, #256]
    47f4:	b5fffc73 	cbnz	x19, 4780 <fwp_poll_events+0x13c>
    47f8:	17ffffd2 	b	4740 <fwp_poll_events+0xfc>
    47fc:	394144a0 	ldrb	w0, [x5, #81]
    4800:	3707fe80 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    4804:	394140a0 	ldrb	w0, [x5, #80]
    4808:	3707fe40 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    480c:	aa0503e0 	mov	x0, x5
    4810:	97fffb98 	bl	3670 <fwp_cancel_tree.part.0>
    4814:	17ffffef 	b	47d0 <fwp_poll_events+0x18c>
    4818:	91018281 	add	x1, x20, #0x60
    481c:	f9009433 	str	x19, [x1, #296]
    4820:	17ffffe2 	b	47a8 <fwp_poll_events+0x164>
    4824:	f9006105 	str	x5, [x8, #192]
    4828:	f9006505 	str	x5, [x8, #200]
    482c:	17fffff2 	b	47f4 <fwp_poll_events+0x1b0>
    4830:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4834:	d2989362 	mov	x2, #0xc49b                	// #50331
    4838:	f2a4d203 	movk	x3, #0x2690, lsl #16
    483c:	f2a00402 	movk	x2, #0x20, lsl #16
    4840:	17ffffb7 	b	471c <fwp_poll_events+0xd8>
    4844:	97fff9ec 	bl	2ff4 <fwp_flush>
    4848:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    484c:	f947e863 	ldr	x3, [x3, #4048]
    4850:	d2800562 	mov	x2, #0x2b                  	// #43
    4854:	d2800021 	mov	x1, #0x1                   	// #1
    4858:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    485c:	9129e000 	add	x0, x0, #0xa78
    4860:	f9400063 	ldr	x3, [x3]
    4864:	97fff82b 	bl	2910 <fwrite@plt>
    4868:	52800ca0 	mov	w0, #0x65                  	// #101
    486c:	97fff795 	bl	26c0 <exit@plt>
    4870:	97fff7e8 	bl	2810 <__stack_chk_fail@plt>

0000000000004874 <fwp_rc_wide_dup>:
    4874:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4878:	910003fd 	mov	x29, sp
    487c:	a90153f3 	stp	x19, x20, [sp, #16]
    4880:	aa0003f3 	mov	x19, x0
    4884:	ca404400 	eor	x0, x0, x0, lsr #17
    4888:	f90013f5 	str	x21, [sp, #32]
    488c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4890:	ca402400 	eor	x0, x0, x0, lsr #9
    4894:	911902a2 	add	x2, x21, #0x640
    4898:	92401c00 	and	x0, x0, #0xff
    489c:	910a2403 	add	x3, x0, #0x289
    48a0:	8b000c40 	add	x0, x2, x0, lsl #3
    48a4:	8b030c54 	add	x20, x2, x3, lsl #3
    48a8:	f94a2401 	ldr	x1, [x0, #5192]
    48ac:	b50000a1 	cbnz	x1, 48c0 <fwp_rc_wide_dup+0x4c>
    48b0:	1400002d 	b	4964 <fwp_rc_wide_dup+0xf0>
    48b4:	91004034 	add	x20, x1, #0x10
    48b8:	f9400821 	ldr	x1, [x1, #16]
    48bc:	b4000241 	cbz	x1, 4904 <fwp_rc_wide_dup+0x90>
    48c0:	f9400022 	ldr	x2, [x1]
    48c4:	eb02027f 	cmp	x19, x2
    48c8:	54ffff61 	b.ne	48b4 <fwp_rc_wide_dup+0x40>  // b.any
    48cc:	f9400281 	ldr	x1, [x20]
    48d0:	39400260 	ldrb	w0, [x19]
    48d4:	7103f81f 	cmp	w0, #0xfe
    48d8:	54000220 	b.eq	491c <fwp_rc_wide_dup+0xa8>  // b.none
    48dc:	b40001a1 	cbz	x1, 4910 <fwp_rc_wide_dup+0x9c>
    48e0:	f9400420 	ldr	x0, [x1, #8]
    48e4:	b100041f 	cmn	x0, #0x1
    48e8:	540004a0 	b.eq	497c <fwp_rc_wide_dup+0x108>  // b.none
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f9000420 	str	x0, [x1, #8]
    48f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f8:	f94013f5 	ldr	x21, [sp, #32]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	39400260 	ldrb	w0, [x19]
    4908:	7103f81f 	cmp	w0, #0xfe
    490c:	540000a0 	b.eq	4920 <fwp_rc_wide_dup+0xac>  // b.none
    4910:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4914:	912b4000 	add	x0, x0, #0xad0
    4918:	97fffb9a 	bl	3780 <fwp_trap>
    491c:	b5000281 	cbnz	x1, 496c <fwp_rc_wide_dup+0xf8>
    4920:	d2800300 	mov	x0, #0x18                  	// #24
    4924:	97fff7a3 	bl	27b0 <malloc@plt>
    4928:	b4000280 	cbz	x0, 4978 <fwp_rc_wide_dup+0x104>
    492c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4930:	a9000413 	stp	x19, x1, [x0]
    4934:	911902b5 	add	x21, x21, #0x640
    4938:	f900081f 	str	xzr, [x0, #16]
    493c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4940:	f9000280 	str	x0, [x20]
    4944:	39000261 	strb	w1, [x19]
    4948:	f94e26a0 	ldr	x0, [x21, #7240]
    494c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4950:	91000400 	add	x0, x0, #0x1
    4954:	f90e26a0 	str	x0, [x21, #7240]
    4958:	f94013f5 	ldr	x21, [sp, #32]
    495c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4960:	d65f03c0 	ret
    4964:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4968:	17ffffda 	b	48d0 <fwp_rc_wide_dup+0x5c>
    496c:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4970:	912aa000 	add	x0, x0, #0xaa8
    4974:	97fffb83 	bl	3780 <fwp_trap>
    4978:	97fff9de 	bl	30f0 <fwp_heap_oom>
    497c:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4980:	912be000 	add	x0, x0, #0xaf8
    4984:	97fffb7f 	bl	3780 <fwp_trap>
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_rc_forget_slot>:
    4990:	aa0003e1 	mov	x1, x0
    4994:	39400000 	ldrb	w0, [x0]
    4998:	7103fc1f 	cmp	w0, #0xff
    499c:	54000040 	b.eq	49a4 <fwp_rc_forget_slot+0x14>  // b.none
    49a0:	d65f03c0 	ret
    49a4:	ca414420 	eor	x0, x1, x1, lsr #17
    49a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49ac:	ca402400 	eor	x0, x0, x0, lsr #9
    49b0:	910003fd 	mov	x29, sp
    49b4:	92401c00 	and	x0, x0, #0xff
    49b8:	f9000bf3 	str	x19, [sp, #16]
    49bc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    49c0:	91190262 	add	x2, x19, #0x640
    49c4:	910a2403 	add	x3, x0, #0x289
    49c8:	8b000c40 	add	x0, x2, x0, lsl #3
    49cc:	8b030c43 	add	x3, x2, x3, lsl #3
    49d0:	f94a2400 	ldr	x0, [x0, #5192]
    49d4:	b50000a0 	cbnz	x0, 49e8 <fwp_rc_forget_slot+0x58>
    49d8:	14000011 	b	4a1c <fwp_rc_forget_slot+0x8c>
    49dc:	91004003 	add	x3, x0, #0x10
    49e0:	f9400800 	ldr	x0, [x0, #16]
    49e4:	b40001c0 	cbz	x0, 4a1c <fwp_rc_forget_slot+0x8c>
    49e8:	f9400002 	ldr	x2, [x0]
    49ec:	eb02003f 	cmp	x1, x2
    49f0:	54ffff61 	b.ne	49dc <fwp_rc_forget_slot+0x4c>  // b.any
    49f4:	f9400801 	ldr	x1, [x0, #16]
    49f8:	91190273 	add	x19, x19, #0x640
    49fc:	f9000061 	str	x1, [x3]
    4a00:	97fff7b4 	bl	28d0 <free@plt>
    4a04:	f94e2660 	ldr	x0, [x19, #7240]
    4a08:	d1000400 	sub	x0, x0, #0x1
    4a0c:	f90e2660 	str	x0, [x19, #7240]
    4a10:	f9400bf3 	ldr	x19, [sp, #16]
    4a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a18:	d65f03c0 	ret
    4a1c:	f0000020 	adrp	x0, b000 <__divti3+0x110>
    4a20:	912b4000 	add	x0, x0, #0xad0
    4a24:	97fffb57 	bl	3780 <fwp_trap>
    4a28:	d503201f 	nop
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_rc_prepare_chunk>:
    4a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    4a40:	911902c2 	add	x2, x22, #0x640
    4a44:	b9401c03 	ldr	w3, [x0, #28]
    4a48:	aa0103f5 	mov	x21, x1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	aa0003f4 	mov	x20, x0
    4a54:	f94e2440 	ldr	x0, [x2, #7240]
    4a58:	b4000440 	cbz	x0, 4ae0 <fwp_rc_prepare_chunk+0xb0>
    4a5c:	d2800013 	mov	x19, #0x0                   	// #0
    4a60:	35000203 	cbnz	w3, 4aa0 <fwp_rc_prepare_chunk+0x70>
    4a64:	b4000361 	cbz	x1, 4ad0 <fwp_rc_prepare_chunk+0xa0>
    4a68:	f9401280 	ldr	x0, [x20, #32]
    4a6c:	97fff799 	bl	28d0 <free@plt>
    4a70:	aa1503e0 	mov	x0, x21
    4a74:	d2800021 	mov	x1, #0x1                   	// #1
    4a78:	97fff75e 	bl	27f0 <calloc@plt>
    4a7c:	f9001280 	str	x0, [x20, #32]
    4a80:	b5000460 	cbnz	x0, 4b0c <fwp_rc_prepare_chunk+0xdc>
    4a84:	97fff99b 	bl	30f0 <fwp_heap_oom>
    4a88:	97ffffc2 	bl	4990 <fwp_rc_forget_slot>
    4a8c:	91000673 	add	x19, x19, #0x1
    4a90:	b9401e83 	ldr	w3, [x20, #28]
    4a94:	eb13007f 	cmp	x3, x19
    4a98:	54000169 	b.ls	4ac4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4a9c:	d503201f 	nop
    4aa0:	f9401283 	ldr	x3, [x20, #32]
    4aa4:	8b130060 	add	x0, x3, x19
    4aa8:	38736863 	ldrb	w3, [x3, x19]
    4aac:	7103fc7f 	cmp	w3, #0xff
    4ab0:	54fffec0 	b.eq	4a88 <fwp_rc_prepare_chunk+0x58>  // b.none
    4ab4:	b9401e83 	ldr	w3, [x20, #28]
    4ab8:	91000673 	add	x19, x19, #0x1
    4abc:	eb13007f 	cmp	x3, x19
    4ac0:	54ffff08 	b.hi	4aa0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4ac4:	eb0302bf 	cmp	x21, x3
    4ac8:	54000121 	b.ne	4aec <fwp_rc_prepare_chunk+0xbc>  // b.any
    4acc:	b5000335 	cbnz	x21, 4b30 <fwp_rc_prepare_chunk+0x100>
    4ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4adc:	d65f03c0 	ret
    4ae0:	2a0303e3 	mov	w3, w3
    4ae4:	eb0302bf 	cmp	x21, x3
    4ae8:	54ffff20 	b.eq	4acc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4aec:	911902c2 	add	x2, x22, #0x640
    4af0:	f9401280 	ldr	x0, [x20, #32]
    4af4:	f94e2841 	ldr	x1, [x2, #7248]
    4af8:	cb030021 	sub	x1, x1, x3
    4afc:	f90e2841 	str	x1, [x2, #7248]
    4b00:	97fff774 	bl	28d0 <free@plt>
    4b04:	b5fffb75 	cbnz	x21, 4a70 <fwp_rc_prepare_chunk+0x40>
    4b08:	f900129f 	str	xzr, [x20, #32]
    4b0c:	911902d6 	add	x22, x22, #0x640
    4b10:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b14:	b9001e95 	str	w21, [x20, #28]
    4b18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b1c:	8b150000 	add	x0, x0, x21
    4b20:	f90e2ac0 	str	x0, [x22, #7248]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	f9401280 	ldr	x0, [x20, #32]
    4b34:	aa1503e2 	mov	x2, x21
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	52800001 	mov	w1, #0x0                   	// #0
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b48:	17fff726 	b	27e0 <memset@plt>
    4b4c:	d503201f 	nop

0000000000004b50 <fwp_heap_refill>:
    4b50:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b54:	910003fd 	mov	x29, sp
    4b58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b5c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4b60:	911902b5 	add	x21, x21, #0x640
    4b64:	aa0003f6 	mov	x22, x0
    4b68:	d2800020 	mov	x0, #0x1                   	// #1
    4b6c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b70:	a90363f7 	stp	x23, x24, [sp, #48]
    4b74:	2a0103f7 	mov	w23, w1
    4b78:	2a0203f8 	mov	w24, w2
    4b7c:	97fff96d 	bl	3130 <fwp_heap_chunks>
    4b80:	aa0003f3 	mov	x19, x0
    4b84:	f949fea2 	ldr	x2, [x21, #5112]
    4b88:	8b000800 	add	x0, x0, x0, lsl #2
    4b8c:	2a1703e1 	mov	w1, w23
    4b90:	52800025 	mov	w5, #0x1                   	// #1
    4b94:	d37df000 	lsl	x0, x0, #3
    4b98:	910f0021 	add	x1, x1, #0x3c0
    4b9c:	8b000054 	add	x20, x2, x0
    4ba0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ba4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ba8:	38206845 	strb	w5, [x2, x0]
    4bac:	aa1403e0 	mov	x0, x20
    4bb0:	39000698 	strb	w24, [x20, #1]
    4bb4:	39000a97 	strb	w23, [x20, #2]
    4bb8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4bbc:	b9000681 	str	w1, [x20, #4]
    4bc0:	2a0103e5 	mov	w5, w1
    4bc4:	8b0300a2 	add	x2, x5, x3
    4bc8:	1ac10881 	udiv	w1, w4, w1
    4bcc:	9ac50842 	udiv	x2, x2, x5
    4bd0:	b9000a81 	str	w1, [x20, #8]
    4bd4:	92404021 	and	x1, x1, #0x1ffff
    4bd8:	b9001a82 	str	w2, [x20, #24]
    4bdc:	97ffff95 	bl	4a30 <fwp_rc_prepare_chunk>
    4be0:	f949daa0 	ldr	x0, [x21, #5040]
    4be4:	29408a81 	ldp	w1, w2, [x20, #4]
    4be8:	8b134000 	add	x0, x0, x19, lsl #16
    4bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf0:	8b214003 	add	x3, x0, w1, uxtw
    4bf4:	9ba20021 	umaddl	x1, w1, w2, x0
    4bf8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bfc:	a90086c3 	stp	x3, x1, [x22, #8]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c08:	d65f03c0 	ret
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_mem_free>:
    4c10:	b40003c0 	cbz	x0, 4c88 <fwp_mem_free+0x78>
    4c14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c18:	910003fd 	mov	x29, sp
    4c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c20:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4c24:	911902a1 	add	x1, x21, #0x640
    4c28:	a90153f3 	stp	x19, x20, [sp, #16]
    4c2c:	aa0003f3 	mov	x19, x0
    4c30:	f949d823 	ldr	x3, [x1, #5040]
    4c34:	f949ec22 	ldr	x2, [x1, #5080]
    4c38:	cb030000 	sub	x0, x0, x3
    4c3c:	eb02401f 	cmp	x0, x2, lsl #16
    4c40:	540001c2 	b.cs	4c78 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c44:	d350fc16 	lsr	x22, x0, #16
    4c48:	a90363f7 	stp	x23, x24, [sp, #48]
    4c4c:	f949fc22 	ldr	x2, [x1, #5112]
    4c50:	8b160ad4 	add	x20, x22, x22, lsl #2
    4c54:	d37df294 	lsl	x20, x20, #3
    4c58:	ab140057 	adds	x23, x2, x20
    4c5c:	540000c0 	b.eq	4c74 <fwp_mem_free+0x64>  // b.none
    4c60:	38746842 	ldrb	w2, [x2, x20]
    4c64:	7100045f 	cmp	w2, #0x1
    4c68:	54000120 	b.eq	4c8c <fwp_mem_free+0x7c>  // b.none
    4c6c:	7100085f 	cmp	w2, #0x2
    4c70:	540005e0 	b.eq	4d2c <fwp_mem_free+0x11c>  // b.none
    4c74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c80:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c84:	d65f03c0 	ret
    4c88:	d65f03c0 	ret
    4c8c:	f94012f8 	ldr	x24, [x23, #32]
    4c90:	b94006e1 	ldr	w1, [x23, #4]
    4c94:	f90023f9 	str	x25, [sp, #64]
    4c98:	2a0103e2 	mov	w2, w1
    4c9c:	394006f9 	ldrb	w25, [x23, #1]
    4ca0:	39400af4 	ldrb	w20, [x23, #2]
    4ca4:	b4000158 	cbz	x24, 4ccc <fwp_mem_free+0xbc>
    4ca8:	92403e76 	and	x22, x19, #0xffff
    4cac:	9ac20ad6 	udiv	x22, x22, x2
    4cb0:	38766b01 	ldrb	w1, [x24, x22]
    4cb4:	8b160300 	add	x0, x24, x22
    4cb8:	7103fc3f 	cmp	w1, #0xff
    4cbc:	54000980 	b.eq	4dec <fwp_mem_free+0x1dc>  // b.none
    4cc0:	38366b1f 	strb	wzr, [x24, x22]
    4cc4:	b94006e1 	ldr	w1, [x23, #4]
    4cc8:	2a0103e2 	mov	w2, w1
    4ccc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4cd0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4cd4:	cb390000 	sub	x0, x0, w25, uxtb
    4cd8:	8b340074 	add	x20, x3, w20, uxtb
    4cdc:	911902b5 	add	x21, x21, #0x640
    4ce0:	1e630021 	ucvtf	d1, w1
    4ce4:	d37ae400 	lsl	x0, x0, #6
    4ce8:	8b140c14 	add	x20, x0, x20, lsl #3
    4cec:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf0:	f8746aa0 	ldr	x0, [x21, x20]
    4cf4:	f94023f9 	ldr	x25, [sp, #64]
    4cf8:	aa2003e0 	mvn	x0, x0
    4cfc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d00:	f9000260 	str	x0, [x19]
    4d04:	f8346ab3 	str	x19, [x21, x20]
    4d08:	f94a12a0 	ldr	x0, [x21, #5152]
    4d0c:	1e612800 	fadd	d0, d0, d1
    4d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d14:	cb020000 	sub	x0, x0, x2
    4d18:	f90a12a0 	str	x0, [x21, #5152]
    4d1c:	fd0a22a0 	str	d0, [x21, #5184]
    4d20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d24:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d28:	d65f03c0 	ret
    4d2c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d30:	8b000063 	add	x3, x3, x0
    4d34:	eb03027f 	cmp	x19, x3
    4d38:	54fff9e1 	b.ne	4c74 <fwp_mem_free+0x64>  // b.any
    4d3c:	fd400ae1 	ldr	d1, [x23, #16]
    4d40:	fd4a2020 	ldr	d0, [x1, #5184]
    4d44:	f9400ae0 	ldr	x0, [x23, #16]
    4d48:	7e61d821 	ucvtf	d1, d1
    4d4c:	f94a1022 	ldr	x2, [x1, #5152]
    4d50:	f94012f3 	ldr	x19, [x23, #32]
    4d54:	1e612800 	fadd	d0, d0, d1
    4d58:	cb000042 	sub	x2, x2, x0
    4d5c:	f90a1022 	str	x2, [x1, #5152]
    4d60:	fd0a2020 	str	d0, [x1, #5184]
    4d64:	b40000b3 	cbz	x19, 4d78 <fwp_mem_free+0x168>
    4d68:	39400260 	ldrb	w0, [x19]
    4d6c:	7103fc1f 	cmp	w0, #0xff
    4d70:	54000380 	b.eq	4de0 <fwp_mem_free+0x1d0>  // b.none
    4d74:	3900027f 	strb	wzr, [x19]
    4d78:	b9400ee2 	ldr	w2, [x23, #12]
    4d7c:	b4000142 	cbz	x2, 4da4 <fwp_mem_free+0x194>
    4d80:	911902a1 	add	x1, x21, #0x640
    4d84:	8b160040 	add	x0, x2, x22
    4d88:	8b000800 	add	x0, x0, x0, lsl #2
    4d8c:	f949fc21 	ldr	x1, [x1, #5112]
    4d90:	8b140034 	add	x20, x1, x20
    4d94:	8b000c20 	add	x0, x1, x0, lsl #3
    4d98:	3802869f 	strb	wzr, [x20], #40
    4d9c:	eb00029f 	cmp	x20, x0
    4da0:	54ffffc1 	b.ne	4d98 <fwp_mem_free+0x188>  // b.any
    4da4:	911902a0 	add	x0, x21, #0x640
    4da8:	f94a1801 	ldr	x1, [x0, #5168]
    4dac:	f949f803 	ldr	x3, [x0, #5104]
    4db0:	8b020021 	add	x1, x1, x2
    4db4:	f90a1801 	str	x1, [x0, #5168]
    4db8:	eb16007f 	cmp	x3, x22
    4dbc:	54000049 	b.ls	4dc4 <fwp_mem_free+0x1b4>  // b.plast
    4dc0:	f909f816 	str	x22, [x0, #5104]
    4dc4:	911902b5 	add	x21, x21, #0x640
    4dc8:	f949f6a0 	ldr	x0, [x21, #5096]
    4dcc:	eb16001f 	cmp	x0, x22
    4dd0:	54fff529 	b.ls	4c74 <fwp_mem_free+0x64>  // b.plast
    4dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dd8:	f909f6b6 	str	x22, [x21, #5096]
    4ddc:	17ffffa7 	b	4c78 <fwp_mem_free+0x68>
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	97fffeeb 	bl	4990 <fwp_rc_forget_slot>
    4de8:	17ffffe3 	b	4d74 <fwp_mem_free+0x164>
    4dec:	97fffee9 	bl	4990 <fwp_rc_forget_slot>
    4df0:	17ffffb4 	b	4cc0 <fwp_mem_free+0xb0>

0000000000004df4 <fwp_heap_alloc_big>:
    4df4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df8:	910003fd 	mov	x29, sp
    4dfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4e00:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e04:	a90363f7 	stp	x23, x24, [sp, #48]
    4e08:	aa0003f7 	mov	x23, x0
    4e0c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e10:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e14:	eb0002ff 	cmp	x23, x0
    4e18:	54000888 	b.hi	4f28 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e1c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e20:	8b0002f4 	add	x20, x23, x0
    4e24:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4e28:	91190359 	add	x25, x26, #0x640
    4e2c:	d350fe94 	lsr	x20, x20, #16
    4e30:	2a0103f5 	mov	w21, w1
    4e34:	aa1403e0 	mov	x0, x20
    4e38:	97fff8be 	bl	3130 <fwp_heap_chunks>
    4e3c:	f949ff22 	ldr	x2, [x25, #5112]
    4e40:	8b000813 	add	x19, x0, x0, lsl #2
    4e44:	aa0003f8 	mov	x24, x0
    4e48:	52800043 	mov	w3, #0x2                   	// #2
    4e4c:	d37df273 	lsl	x19, x19, #3
    4e50:	d2800021 	mov	x1, #0x1                   	// #1
    4e54:	8b130040 	add	x0, x2, x19
    4e58:	38336843 	strb	w3, [x2, x19]
    4e5c:	39000415 	strb	w21, [x0, #1]
    4e60:	b9000c14 	str	w20, [x0, #12]
    4e64:	f9000817 	str	x23, [x0, #16]
    4e68:	97fffef2 	bl	4a30 <fwp_rc_prepare_chunk>
    4e6c:	f100069f 	cmp	x20, #0x1
    4e70:	54000269 	b.ls	4ebc <fwp_heap_alloc_big+0xc8>  // b.plast
    4e74:	8b180294 	add	x20, x20, x24
    4e78:	9100a273 	add	x19, x19, #0x28
    4e7c:	a90573fb 	stp	x27, x28, [sp, #80]
    4e80:	5280007b 	mov	w27, #0x3                   	// #3
    4e84:	8b140a94 	add	x20, x20, x20, lsl #2
    4e88:	2a1803fc 	mov	w28, w24
    4e8c:	9adb2296 	lsl	x22, x20, x27
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffee4 	bl	4a30 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0x9c>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffc1c 	bl	4084 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff70 	b	4df4 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffeb5 	bl	4b50 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	54000861 	b.ne	51c4 <fwp_heap_alloc+0x134>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	540006e2 	b.cs	5210 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	540002cc 	b.gt	51d8 <fwp_heap_alloc+0x148>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000209 	b.ls	51f4 <fwp_heap_alloc+0x164>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	17ffffe8 	b	5160 <fwp_heap_alloc+0xd0>
    51c4:	a9538c44 	ldp	x4, x3, [x2, #312]
    51c8:	91000484 	add	x4, x4, #0x1
    51cc:	8b000063 	add	x3, x3, x0
    51d0:	a9138c44 	stp	x4, x3, [x2, #312]
    51d4:	17ffffba 	b	50bc <fwp_heap_alloc+0x2c>
    51d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51dc:	fd00a800 	str	d0, [x0, #336]
    51e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f0:	d65f03c0 	ret
    51f4:	7100043f 	cmp	w1, #0x1
    51f8:	8b140085 	add	x5, x4, x20
    51fc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5200:	52800001 	mov	w1, #0x0                   	// #0
    5204:	aa0403e0 	mov	x0, x4
    5208:	f9000465 	str	x5, [x3, #8]
    520c:	17ffffc6 	b	5124 <fwp_heap_alloc+0x94>
    5210:	97fff7b8 	bl	30f0 <fwp_heap_oom>

0000000000005214 <fwp_apply>:
    5214:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5218:	aa0003e6 	mov	x6, x0
    521c:	910003fd 	mov	x29, sp
    5220:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5224:	f947f463 	ldr	x3, [x3, #4072]
    5228:	a90153f3 	stp	x19, x20, [sp, #16]
    522c:	aa0203f4 	mov	x20, x2
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	2a0103f5 	mov	w21, w1
    5238:	52800033 	mov	w19, #0x1                   	// #1
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	f00000d7 	adrp	x23, 20000 <__data_start>
    5244:	910182f7 	add	x23, x23, #0x60
    5248:	a9046bf9 	stp	x25, x26, [sp, #64]
    524c:	d100c3ff 	sub	sp, sp, #0x30
    5250:	f9400060 	ldr	x0, [x3]
    5254:	f81f83a0 	stur	x0, [x29, #-8]
    5258:	d2800000 	mov	x0, #0x0                   	// #0
    525c:	294058c3 	ldp	w3, w22, [x6]
    5260:	910003f8 	mov	x24, sp
    5264:	f9406ae0 	ldr	x0, [x23, #208]
    5268:	710002df 	cmp	w22, #0x0
    526c:	d37be863 	lsl	x3, x3, #5
    5270:	8b030007 	add	x7, x0, x3
    5274:	b8636819 	ldr	w25, [x0, x3]
    5278:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    527c:	54000163 	b.cc	52a8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5280:	f94004e3 	ldr	x3, [x7, #8]
    5284:	34000bd9 	cbz	w25, 53fc <fwp_apply+0x1e8>
    5288:	aa1403e0 	mov	x0, x20
    528c:	d63f0060 	blr	x3
    5290:	aa0003e6 	mov	x6, x0
    5294:	6b1902bf 	cmp	w21, w25
    5298:	54000940 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    529c:	8b394e94 	add	x20, x20, w25, uxtw #3
    52a0:	4b1902b5 	sub	w21, w21, w25
    52a4:	17ffffee 	b	525c <fwp_apply+0x48>
    52a8:	0b1602ba 	add	w26, w21, w22
    52ac:	6b19035f 	cmp	w26, w25
    52b0:	54000543 	b.cc	5358 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    52b4:	7100033f 	cmp	w25, #0x0
    52b8:	4b16033a 	sub	w26, w25, w22
    52bc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52c0:	d37df000 	lsl	x0, x0, #3
    52c4:	91003c00 	add	x0, x0, #0xf
    52c8:	92704c01 	and	x1, x0, #0xfffff0000
    52cc:	927c7c00 	and	x0, x0, #0xffffffff0
    52d0:	cb2163e1 	sub	x1, sp, x1
    52d4:	eb2163ff 	cmp	sp, x1
    52d8:	540000a0 	b.eq	52ec <fwp_apply+0xd8>  // b.none
    52dc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52e0:	f90203ff 	str	xzr, [sp, #1024]
    52e4:	eb2163ff 	cmp	sp, x1
    52e8:	54ffffa1 	b.ne	52dc <fwp_apply+0xc8>  // b.any
    52ec:	92403c00 	and	x0, x0, #0xffff
    52f0:	cb2063ff 	sub	sp, sp, x0
    52f4:	f90003ff 	str	xzr, [sp]
    52f8:	f110001f 	cmp	x0, #0x400
    52fc:	54000962 	b.cs	5428 <fwp_apply+0x214>  // b.hs, b.nlast
    5300:	910020c6 	add	x6, x6, #0x8
    5304:	910043e0 	add	x0, sp, #0x10
    5308:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    530c:	d2800003 	mov	x3, #0x0                   	// #0
    5310:	340000f6 	cbz	w22, 532c <fwp_apply+0x118>
    5314:	d503201f 	nop
    5318:	f86368c4 	ldr	x4, [x6, x3]
    531c:	f8236804 	str	x4, [x0, x3]
    5320:	91002063 	add	x3, x3, #0x8
    5324:	eb0300bf 	cmp	x5, x3
    5328:	54ffff81 	b.ne	5318 <fwp_apply+0x104>  // b.any
    532c:	3400013a 	cbz	w26, 5350 <fwp_apply+0x13c>
    5330:	2a1a03e6 	mov	w6, w26
    5334:	d2800003 	mov	x3, #0x0                   	// #0
    5338:	0b0302c4 	add	w4, w22, w3
    533c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5340:	91000463 	add	x3, x3, #0x1
    5344:	f8247805 	str	x5, [x0, x4, lsl #3]
    5348:	eb0300df 	cmp	x6, x3
    534c:	54ffff61 	b.ne	5338 <fwp_apply+0x124>  // b.any
    5350:	f94004e3 	ldr	x3, [x7, #8]
    5354:	1400002c 	b	5404 <fwp_apply+0x1f0>
    5358:	11000740 	add	w0, w26, #0x1
    535c:	52800041 	mov	w1, #0x2                   	// #2
    5360:	f81e83a6 	stur	x6, [x29, #-24]
    5364:	d37df000 	lsl	x0, x0, #3
    5368:	97ffff4a 	bl	5090 <fwp_heap_alloc>
    536c:	f85e83a6 	ldur	x6, [x29, #-24]
    5370:	aa0003f3 	mov	x19, x0
    5374:	b94000c1 	ldr	w1, [x6]
    5378:	29006801 	stp	w1, w26, [x0]
    537c:	340000b6 	cbz	w22, 5390 <fwp_apply+0x17c>
    5380:	910020c1 	add	x1, x6, #0x8
    5384:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5388:	91002000 	add	x0, x0, #0x8
    538c:	97fff4bd 	bl	2680 <memmove@plt>
    5390:	2a1503e3 	mov	w3, w21
    5394:	d2800000 	mov	x0, #0x0                   	// #0
    5398:	34000135 	cbz	w21, 53bc <fwp_apply+0x1a8>
    539c:	d503201f 	nop
    53a0:	0b0002c1 	add	w1, w22, w0
    53a4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53a8:	8b010e61 	add	x1, x19, x1, lsl #3
    53ac:	91000400 	add	x0, x0, #0x1
    53b0:	f9000422 	str	x2, [x1, #8]
    53b4:	eb00007f 	cmp	x3, x0
    53b8:	54ffff41 	b.ne	53a0 <fwp_apply+0x18c>  // b.any
    53bc:	aa1303e6 	mov	x6, x19
    53c0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53c4:	f947f400 	ldr	x0, [x0, #4072]
    53c8:	f85f83a2 	ldur	x2, [x29, #-8]
    53cc:	f9400001 	ldr	x1, [x0]
    53d0:	eb010042 	subs	x2, x2, x1
    53d4:	d2800001 	mov	x1, #0x0                   	// #0
    53d8:	540002c1 	b.ne	5430 <fwp_apply+0x21c>  // b.any
    53dc:	910003bf 	mov	sp, x29
    53e0:	aa0603e0 	mov	x0, x6
    53e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53f4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53f8:	d65f03c0 	ret
    53fc:	d10043a0 	sub	x0, x29, #0x10
    5400:	5280001a 	mov	w26, #0x0                   	// #0
    5404:	d63f0060 	blr	x3
    5408:	aa0003e6 	mov	x6, x0
    540c:	6b1a02bf 	cmp	w21, w26
    5410:	54fffd80 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    5414:	0b1602b6 	add	w22, w21, w22
    5418:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    541c:	4b1902d5 	sub	w21, w22, w25
    5420:	9100031f 	mov	sp, x24
    5424:	17ffff8e 	b	525c <fwp_apply+0x48>
    5428:	f90203ff 	str	xzr, [sp, #1024]
    542c:	17ffffb5 	b	5300 <fwp_apply+0xec>
    5430:	97fff4f8 	bl	2810 <__stack_chk_fail@plt>

0000000000005434 <fwp_p_ad_push.constprop.0>:
    5434:	f100001f 	cmp	x0, #0x0
    5438:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    543c:	54000eab 	b.lt	5610 <fwp_p_ad_push.constprop.0+0x1dc>  // b.tstop
    5440:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5444:	aa0003e4 	mov	x4, x0
    5448:	910003fd 	mov	x29, sp
    544c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5450:	aa0003f5 	mov	x21, x0
    5454:	aa020000 	orr	x0, x0, x2
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0203f7 	mov	x23, x2
    5460:	6d0627e8 	stp	d8, d9, [sp, #96]
    5464:	9e670029 	fmov	d9, x1
    5468:	9e670068 	fmov	d8, x3
    546c:	b6f80920 	tbz	x0, #63, 5590 <fwp_p_ad_push.constprop.0+0x15c>
    5470:	a90153f3 	stp	x19, x20, [sp, #16]
    5474:	9360fc80 	asr	x0, x4, #32
    5478:	b6f800c4 	tbz	x4, #63, 5490 <fwp_p_ad_push.constprop.0+0x5c>
    547c:	1e604109 	fmov	d9, d8
    5480:	2f00e408 	movi	d8, #0x0
    5484:	9360fc40 	asr	x0, x2, #32
    5488:	aa0203f5 	mov	x21, x2
    548c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5490:	97fff988 	bl	3ab0 <fwp_tape_of>
    5494:	aa0003f3 	mov	x19, x0
    5498:	f9403000 	ldr	x0, [x0, #96]
    549c:	b5001240 	cbnz	x0, 56e4 <fwp_p_ad_push.constprop.0+0x2b0>
    54a0:	f9400a76 	ldr	x22, [x19, #16]
    54a4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54a8:	eb0002df 	cmp	x22, x0
    54ac:	54000d8c 	b.gt	565c <fwp_p_ad_push.constprop.0+0x228>
    54b0:	eb3542df 	cmp	x22, w21, uxtw
    54b4:	54000cad 	b.le	5648 <fwp_p_ad_push.constprop.0+0x214>
    54b8:	b7f80077 	tbnz	x23, #63, 54c4 <fwp_p_ad_push.constprop.0+0x90>
    54bc:	eb3742df 	cmp	x22, w23, uxtw
    54c0:	54000c4d 	b.le	5648 <fwp_p_ad_push.constprop.0+0x214>
    54c4:	f9400678 	ldr	x24, [x19, #8]
    54c8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54cc:	cb1802d8 	sub	x24, x22, x24
    54d0:	91000701 	add	x1, x24, #0x1
    54d4:	eb00003f 	cmp	x1, x0
    54d8:	54000c28 	b.hi	565c <fwp_p_ad_push.constprop.0+0x228>  // b.pmore
    54dc:	a9418274 	ldp	x20, x0, [x19, #24]
    54e0:	a90573fb 	stp	x27, x28, [sp, #80]
    54e4:	eb14003f 	cmp	x1, x20
    54e8:	540006ad 	b.le	55bc <fwp_p_ad_push.constprop.0+0x188>
    54ec:	f100029f 	cmp	x20, #0x0
    54f0:	d2800803 	mov	x3, #0x40                  	// #64
    54f4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54f8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54fc:	a9046bf9 	stp	x25, x26, [sp, #64]
    5500:	eb14003f 	cmp	x1, x20
    5504:	5400008d 	b.le	5514 <fwp_p_ad_push.constprop.0+0xe0>
    5508:	eb02029f 	cmp	x20, x2
    550c:	5400054d 	b.le	55b4 <fwp_p_ad_push.constprop.0+0x180>
    5510:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5514:	d37df299 	lsl	x25, x20, #3
    5518:	52800022 	mov	w2, #0x1                   	// #1
    551c:	aa1903e1 	mov	x1, x25
    5520:	97fffbad 	bl	43d4 <ad_raw_realloc>
    5524:	aa0003e1 	mov	x1, x0
    5528:	b4000a40 	cbz	x0, 5670 <fwp_p_ad_push.constprop.0+0x23c>
    552c:	f9400e63 	ldr	x3, [x19, #24]
    5530:	f9001261 	str	x1, [x19, #32]
    5534:	f9401a60 	ldr	x0, [x19, #48]
    5538:	52800042 	mov	w2, #0x2                   	// #2
    553c:	8b030821 	add	x1, x1, x3, lsl #2
    5540:	f9001661 	str	x1, [x19, #40]
    5544:	d37cee81 	lsl	x1, x20, #4
    5548:	97fffba3 	bl	43d4 <ad_raw_realloc>
    554c:	aa0003e2 	mov	x2, x0
    5550:	b4000900 	cbz	x0, 5670 <fwp_p_ad_push.constprop.0+0x23c>
    5554:	f9400e61 	ldr	x1, [x19, #24]
    5558:	d37df31b 	lsl	x27, x24, #3
    555c:	d37ef69a 	lsl	x26, x20, #2
    5560:	d37ef71c 	lsl	x28, x24, #2
    5564:	8b190003 	add	x3, x0, x25
    5568:	8b010c01 	add	x1, x0, x1, lsl #3
    556c:	a9030660 	stp	x0, x1, [x19, #48]
    5570:	b5000558 	cbnz	x24, 5618 <fwp_p_ad_push.constprop.0+0x1e4>
    5574:	f9001e63 	str	x3, [x19, #56]
    5578:	f9401260 	ldr	x0, [x19, #32]
    557c:	8b1a0001 	add	x1, x0, x26
    5580:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5584:	f9000e74 	str	x20, [x19, #24]
    5588:	f9001661 	str	x1, [x19, #40]
    558c:	14000010 	b	55cc <fwp_p_ad_push.constprop.0+0x198>
    5590:	9360fc40 	asr	x0, x2, #32
    5594:	a90153f3 	stp	x19, x20, [sp, #16]
    5598:	eb84801f 	cmp	x0, x4, asr #32
    559c:	54fff7a0 	b.eq	5490 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    55a0:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    55a4:	912c6000 	add	x0, x0, #0xb18
    55a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    55ac:	a90573fb 	stp	x27, x28, [sp, #80]
    55b0:	97fff874 	bl	3780 <fwp_trap>
    55b4:	d37ffa94 	lsl	x20, x20, #1
    55b8:	17ffffd2 	b	5500 <fwp_p_ad_push.constprop.0+0xcc>
    55bc:	a9428a61 	ldp	x1, x2, [x19, #40]
    55c0:	d37ef71c 	lsl	x28, x24, #2
    55c4:	f9401e63 	ldr	x3, [x19, #56]
    55c8:	d37df31b 	lsl	x27, x24, #3
    55cc:	b83c6815 	str	w21, [x0, x28]
    55d0:	f10002ff 	cmp	x23, #0x0
    55d4:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55d8:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55dc:	fc3b6849 	str	d9, [x2, x27]
    55e0:	aa1602a0 	orr	x0, x21, x22
    55e4:	b83c6837 	str	w23, [x1, x28]
    55e8:	910006d6 	add	x22, x22, #0x1
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	fc3b6868 	str	d8, [x3, x27]
    55f4:	a94573fb 	ldp	x27, x28, [sp, #80]
    55f8:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55fc:	f9000a76 	str	x22, [x19, #16]
    5600:	a94153f3 	ldp	x19, x20, [sp, #16]
    5604:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5608:	a8c77bfd 	ldp	x29, x30, [sp], #112
    560c:	d65f03c0 	ret
    5610:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5614:	d65f03c0 	ret
    5618:	aa0303e0 	mov	x0, x3
    561c:	aa1b03e2 	mov	x2, x27
    5620:	97fff418 	bl	2680 <memmove@plt>
    5624:	a9420660 	ldp	x0, x1, [x19, #32]
    5628:	aa1c03e2 	mov	x2, x28
    562c:	f9401a63 	ldr	x3, [x19, #48]
    5630:	8b190063 	add	x3, x3, x25
    5634:	f9001e63 	str	x3, [x19, #56]
    5638:	8b1a0000 	add	x0, x0, x26
    563c:	97fff411 	bl	2680 <memmove@plt>
    5640:	a9430e62 	ldp	x2, x3, [x19, #48]
    5644:	17ffffcd 	b	5578 <fwp_p_ad_push.constprop.0+0x144>
    5648:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    564c:	912ec000 	add	x0, x0, #0xbb0
    5650:	a9046bf9 	stp	x25, x26, [sp, #64]
    5654:	a90573fb 	stp	x27, x28, [sp, #80]
    5658:	97fff84a 	bl	3780 <fwp_trap>
    565c:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    5660:	912e4000 	add	x0, x0, #0xb90
    5664:	a9046bf9 	stp	x25, x26, [sp, #64]
    5668:	a90573fb 	stp	x27, x28, [sp, #80]
    566c:	97fff845 	bl	3780 <fwp_trap>
    5670:	aa1303e0 	mov	x0, x19
    5674:	97fff648 	bl	2f94 <fwp_tape_unlink_scope>
    5678:	f9401260 	ldr	x0, [x19, #32]
    567c:	b4000040 	cbz	x0, 5684 <fwp_p_ad_push.constprop.0+0x250>
    5680:	97fffb20 	bl	4300 <ad_raw_free.part.0>
    5684:	f9401a60 	ldr	x0, [x19, #48]
    5688:	b4000040 	cbz	x0, 5690 <fwp_p_ad_push.constprop.0+0x25c>
    568c:	97fffb1d 	bl	4300 <ad_raw_free.part.0>
    5690:	f9402260 	ldr	x0, [x19, #64]
    5694:	b4000040 	cbz	x0, 569c <fwp_p_ad_push.constprop.0+0x268>
    5698:	97fffb1a 	bl	4300 <ad_raw_free.part.0>
    569c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    56a0:	f947e821 	ldr	x1, [x1, #4048]
    56a4:	f9000e7f 	str	xzr, [x19, #24]
    56a8:	4f000400 	movi	v0.4s, #0x0
    56ac:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    56b0:	d2800262 	mov	x2, #0x13                  	// #19
    56b4:	f9400023 	ldr	x3, [x1]
    56b8:	b900067f 	str	wzr, [x19, #4]
    56bc:	d2800021 	mov	x1, #0x1                   	// #1
    56c0:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    56c4:	91186000 	add	x0, x0, #0x618
    56c8:	3c808260 	stur	q0, [x19, #8]
    56cc:	ad010260 	stp	q0, q0, [x19, #32]
    56d0:	97fff490 	bl	2910 <fwrite@plt>
    56d4:	d2800000 	mov	x0, #0x0                   	// #0
    56d8:	97fff49a 	bl	2940 <fflush@plt>
    56dc:	52800cc0 	mov	w0, #0x66                  	// #102
    56e0:	97fff4a8 	bl	2980 <_Exit@plt>
    56e4:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    56e8:	912d8000 	add	x0, x0, #0xb60
    56ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    56f0:	a90573fb 	stp	x27, x28, [sp, #80]
    56f4:	97fff823 	bl	3780 <fwp_trap>
    56f8:	d503201f 	nop
    56fc:	d503201f 	nop

0000000000005700 <w107>:
    5700:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5704:	9e660003 	fmov	x3, d0
    5708:	aa0003e2 	mov	x2, x0
    570c:	910003fd 	mov	x29, sp
    5710:	6d0327e8 	stp	d8, d9, [sp, #48]
    5714:	1e604028 	fmov	d8, d1
    5718:	1e600809 	fmul	d9, d0, d0
    571c:	fd0023ea 	str	d10, [sp, #64]
    5720:	1e60400a 	fmov	d10, d0
    5724:	a90153f3 	stp	x19, x20, [sp, #16]
    5728:	aa0003f3 	mov	x19, x0
    572c:	aa0103f4 	mov	x20, x1
    5730:	aa0303e1 	mov	x1, x3
    5734:	a9025bf5 	stp	x21, x22, [sp, #32]
    5738:	97ffff3f 	bl	5434 <fwp_p_ad_push.constprop.0>
    573c:	1e693908 	fsub	d8, d8, d9
    5740:	aa1403e2 	mov	x2, x20
    5744:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5748:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    574c:	9e660116 	fmov	x22, d8
    5750:	97ffff39 	bl	5434 <fwp_p_ad_push.constprop.0>
    5754:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5758:	aa0003e1 	mov	x1, x0
    575c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5760:	aa1303e0 	mov	x0, x19
    5764:	1e6a3929 	fsub	d9, d9, d10
    5768:	aa0103f3 	mov	x19, x1
    576c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5770:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5774:	9e660135 	fmov	x21, d9
    5778:	97ffff2f 	bl	5434 <fwp_p_ad_push.constprop.0>
    577c:	1e680908 	fmul	d8, d8, d8
    5780:	aa0003f4 	mov	x20, x0
    5784:	aa1603e3 	mov	x3, x22
    5788:	aa1603e1 	mov	x1, x22
    578c:	aa1303e2 	mov	x2, x19
    5790:	aa1303e0 	mov	x0, x19
    5794:	97ffff28 	bl	5434 <fwp_p_ad_push.constprop.0>
    5798:	aa0003e2 	mov	x2, x0
    579c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    57a0:	9e670020 	fmov	d0, x1
    57a4:	9e660101 	fmov	x1, d8
    57a8:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    57ac:	1e600908 	fmul	d8, d8, d0
    57b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57b4:	97ffff20 	bl	5434 <fwp_p_ad_push.constprop.0>
    57b8:	1e690929 	fmul	d9, d9, d9
    57bc:	aa0003f3 	mov	x19, x0
    57c0:	aa1503e3 	mov	x3, x21
    57c4:	aa1503e1 	mov	x1, x21
    57c8:	aa1403e2 	mov	x2, x20
    57cc:	aa1403e0 	mov	x0, x20
    57d0:	97ffff19 	bl	5434 <fwp_p_ad_push.constprop.0>
    57d4:	1e692908 	fadd	d8, d8, d9
    57d8:	aa1303e2 	mov	x2, x19
    57dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57e0:	aa0303e1 	mov	x1, x3
    57e4:	97ffff14 	bl	5434 <fwp_p_ad_push.constprop.0>
    57e8:	aa0003e1 	mov	x1, x0
    57ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    57f0:	9e660100 	fmov	x0, d8
    57f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57f8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57fc:	fd4023ea 	ldr	d10, [sp, #64]
    5800:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5804:	d65f03c0 	ret
    5808:	d503201f 	nop
    580c:	d503201f 	nop

0000000000005810 <w164.constprop.0>:
    5810:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5814:	910003fd 	mov	x29, sp
    5818:	a9025bf5 	stp	x21, x22, [sp, #32]
    581c:	fd001be8 	str	d8, [sp, #48]
    5820:	f9400015 	ldr	x21, [x0]
    5824:	b4000315 	cbz	x21, 5884 <w164.constprop.0+0x74>
    5828:	2f00e408 	movi	d8, #0x0
    582c:	91002016 	add	x22, x0, #0x8
    5830:	a90153f3 	stp	x19, x20, [sp, #16]
    5834:	91004014 	add	x20, x0, #0x10
    5838:	d2800013 	mov	x19, #0x0                   	// #0
    583c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5840:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5844:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5848:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    584c:	aa0303e1 	mov	x1, x3
    5850:	1e602908 	fadd	d8, d8, d0
    5854:	91000a73 	add	x19, x19, #0x2
    5858:	97fffef7 	bl	5434 <fwp_p_ad_push.constprop.0>
    585c:	eb1302bf 	cmp	x21, x19
    5860:	54ffff08 	b.hi	5840 <w164.constprop.0+0x30>  // b.pmore
    5864:	9e660102 	fmov	x2, d8
    5868:	fd401be8 	ldr	d8, [sp, #48]
    586c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5870:	aa0003e1 	mov	x1, x0
    5874:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5878:	aa0203e0 	mov	x0, x2
    587c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5880:	d65f03c0 	ret
    5884:	2f00e408 	movi	d8, #0x0
    5888:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    588c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5890:	aa0003e1 	mov	x1, x0
    5894:	9e660102 	fmov	x2, d8
    5898:	fd401be8 	ldr	d8, [sp, #48]
    589c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58a0:	aa0203e0 	mov	x0, x2
    58a4:	d65f03c0 	ret
    58a8:	d503201f 	nop
    58ac:	d503201f 	nop

00000000000058b0 <fwp_data.part.0.constprop.0>:
    58b0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    58b4:	910003fd 	mov	x29, sp
    58b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    58bc:	f00000d6 	adrp	x22, 20000 <__data_start>
    58c0:	910182c2 	add	x2, x22, #0x60
    58c4:	a9046bf9 	stp	x25, x26, [sp, #64]
    58c8:	b9413059 	ldr	w25, [x2, #304]
    58cc:	a90153f3 	stp	x19, x20, [sp, #16]
    58d0:	aa0103f4 	mov	x20, x1
    58d4:	a90363f7 	stp	x23, x24, [sp, #48]
    58d8:	2a0003f7 	mov	w23, w0
    58dc:	340000b9 	cbz	w25, 58f0 <fwp_data.part.0.constprop.0+0x40>
    58e0:	a9538041 	ldp	x1, x0, [x2, #312]
    58e4:	91000421 	add	x1, x1, #0x1
    58e8:	91006000 	add	x0, x0, #0x18
    58ec:	a9138041 	stp	x1, x0, [x2, #312]
    58f0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    58f4:	911902a3 	add	x3, x21, #0x640
    58f8:	b953a460 	ldr	w0, [x3, #5028]
    58fc:	34000840 	cbz	w0, 5a04 <fwp_data.part.0.constprop.0+0x154>
    5900:	397e8862 	ldrb	w2, [x3, #4002]
    5904:	910f0040 	add	x0, x2, #0x3c0
    5908:	8b020442 	add	x2, x2, x2, lsl #1
    590c:	d37df042 	lsl	x2, x2, #3
    5910:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5914:	2a1a03f8 	mov	w24, w26
    5918:	f8626873 	ldr	x19, [x3, x2]
    591c:	b4000613 	cbz	x19, 59dc <fwp_data.part.0.constprop.0+0x12c>
    5920:	f9400260 	ldr	x0, [x19]
    5924:	aa2003e0 	mvn	x0, x0
    5928:	f8226860 	str	x0, [x3, x2]
    592c:	f100631f 	cmp	x24, #0x18
    5930:	540000e9 	b.ls	594c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5934:	d1006702 	sub	x2, x24, #0x19
    5938:	91006260 	add	x0, x19, #0x18
    593c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5940:	52800001 	mov	w1, #0x0                   	// #0
    5944:	91002042 	add	x2, x2, #0x8
    5948:	97fff3a6 	bl	27e0 <memset@plt>
    594c:	911902a0 	add	x0, x21, #0x640
    5950:	f94a1001 	ldr	x1, [x0, #5152]
    5954:	ab180021 	adds	x1, x1, x24
    5958:	54000642 	b.cs	5a20 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    595c:	f94a1402 	ldr	x2, [x0, #5160]
    5960:	f90a1001 	str	x1, [x0, #5152]
    5964:	eb02003f 	cmp	x1, x2
    5968:	54000049 	b.ls	5970 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    596c:	f90a1401 	str	x1, [x0, #5160]
    5970:	911902a0 	add	x0, x21, #0x640
    5974:	1e630341 	ucvtf	d1, w26
    5978:	fd4a1c00 	ldr	d0, [x0, #5176]
    597c:	1e612800 	fadd	d0, d0, d1
    5980:	fd0a1c00 	str	d0, [x0, #5176]
    5984:	34000139 	cbz	w25, 59a8 <fwp_data.part.0.constprop.0+0xf8>
    5988:	911902b5 	add	x21, x21, #0x640
    598c:	910182d6 	add	x22, x22, #0x60
    5990:	fd4a12a0 	ldr	d0, [x21, #5152]
    5994:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5998:	7e61d800 	ucvtf	d0, d0
    599c:	1e623800 	fsub	d0, d0, d2
    59a0:	1e612010 	fcmpe	d0, d1
    59a4:	540003ac 	b.gt	5a18 <fwp_data.part.0.constprop.0+0x168>
    59a8:	52800040 	mov	w0, #0x2                   	// #2
    59ac:	29000277 	stp	w23, w0, [x19]
    59b0:	aa1303e0 	mov	x0, x19
    59b4:	f9400281 	ldr	x1, [x20]
    59b8:	f9000661 	str	x1, [x19, #8]
    59bc:	f9400681 	ldr	x1, [x20, #8]
    59c0:	f9000a61 	str	x1, [x19, #16]
    59c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    59c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    59d0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    59d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    59d8:	d65f03c0 	ret
    59dc:	8b020063 	add	x3, x3, x2
    59e0:	f9400473 	ldr	x19, [x3, #8]
    59e4:	b4000113 	cbz	x19, 5a04 <fwp_data.part.0.constprop.0+0x154>
    59e8:	f9400860 	ldr	x0, [x3, #16]
    59ec:	cb130000 	sub	x0, x0, x19
    59f0:	eb00031f 	cmp	x24, x0
    59f4:	54000088 	b.hi	5a04 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    59f8:	8b180260 	add	x0, x19, x24
    59fc:	f9000460 	str	x0, [x3, #8]
    5a00:	17ffffcb 	b	592c <fwp_data.part.0.constprop.0+0x7c>
    5a04:	52800001 	mov	w1, #0x0                   	// #0
    5a08:	d2800300 	mov	x0, #0x18                  	// #24
    5a0c:	97fffda1 	bl	5090 <fwp_heap_alloc>
    5a10:	aa0003f3 	mov	x19, x0
    5a14:	17ffffdc 	b	5984 <fwp_data.part.0.constprop.0+0xd4>
    5a18:	fd00aac0 	str	d0, [x22, #336]
    5a1c:	17ffffe3 	b	59a8 <fwp_data.part.0.constprop.0+0xf8>
    5a20:	97fff5b4 	bl	30f0 <fwp_heap_oom>

0000000000005a24 <fwp_rc_share>:
    5a24:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5a28:	91190042 	add	x2, x2, #0x640
    5a2c:	f949d843 	ldr	x3, [x2, #5040]
    5a30:	f949ec41 	ldr	x1, [x2, #5080]
    5a34:	cb030000 	sub	x0, x0, x3
    5a38:	eb01401f 	cmp	x0, x1, lsl #16
    5a3c:	540002c2 	b.cs	5a94 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5a40:	d350fc01 	lsr	x1, x0, #16
    5a44:	f949fc44 	ldr	x4, [x2, #5112]
    5a48:	8b010821 	add	x1, x1, x1, lsl #2
    5a4c:	d37df021 	lsl	x1, x1, #3
    5a50:	8b010083 	add	x3, x4, x1
    5a54:	f9401062 	ldr	x2, [x3, #32]
    5a58:	b40001e2 	cbz	x2, 5a94 <fwp_rc_share+0x70>
    5a5c:	38616881 	ldrb	w1, [x4, x1]
    5a60:	7100083f 	cmp	w1, #0x2
    5a64:	540001a0 	b.eq	5a98 <fwp_rc_share+0x74>  // b.none
    5a68:	7100043f 	cmp	w1, #0x1
    5a6c:	54000141 	b.ne	5a94 <fwp_rc_share+0x70>  // b.any
    5a70:	29430464 	ldp	w4, w1, [x3, #24]
    5a74:	92403c00 	and	x0, x0, #0xffff
    5a78:	9b047c00 	mul	x0, x0, x4
    5a7c:	d360fc00 	lsr	x0, x0, #32
    5a80:	eb01001f 	cmp	x0, x1
    5a84:	54000082 	b.cs	5a94 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5a88:	8b000042 	add	x2, x2, x0
    5a8c:	39400040 	ldrb	w0, [x2]
    5a90:	350000a0 	cbnz	w0, 5aa4 <fwp_rc_share+0x80>
    5a94:	d65f03c0 	ret
    5a98:	72003c1f 	tst	w0, #0xffff
    5a9c:	54ffff80 	b.eq	5a8c <fwp_rc_share+0x68>  // b.none
    5aa0:	d65f03c0 	ret
    5aa4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5aa8:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    5aac:	912f4000 	add	x0, x0, #0xbd0
    5ab0:	910003fd 	mov	x29, sp
    5ab4:	97fff733 	bl	3780 <fwp_trap>
    5ab8:	d503201f 	nop
    5abc:	d503201f 	nop

0000000000005ac0 <fwp_rc_free_arr>:
    5ac0:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5ac4:	91190063 	add	x3, x3, #0x640
    5ac8:	f949d861 	ldr	x1, [x3, #5040]
    5acc:	f949ec62 	ldr	x2, [x3, #5080]
    5ad0:	cb010001 	sub	x1, x0, x1
    5ad4:	eb02403f 	cmp	x1, x2, lsl #16
    5ad8:	54000342 	b.cs	5b40 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5adc:	d350fc22 	lsr	x2, x1, #16
    5ae0:	f949fc65 	ldr	x5, [x3, #5112]
    5ae4:	8b020842 	add	x2, x2, x2, lsl #2
    5ae8:	d37df042 	lsl	x2, x2, #3
    5aec:	8b0200a4 	add	x4, x5, x2
    5af0:	f9401083 	ldr	x3, [x4, #32]
    5af4:	b4000263 	cbz	x3, 5b40 <fwp_rc_free_arr+0x80>
    5af8:	386268a2 	ldrb	w2, [x5, x2]
    5afc:	7100085f 	cmp	w2, #0x2
    5b00:	540001c0 	b.eq	5b38 <fwp_rc_free_arr+0x78>  // b.none
    5b04:	7100045f 	cmp	w2, #0x1
    5b08:	540001c1 	b.ne	5b40 <fwp_rc_free_arr+0x80>  // b.any
    5b0c:	29430885 	ldp	w5, w2, [x4, #24]
    5b10:	92403c21 	and	x1, x1, #0xffff
    5b14:	9b057c21 	mul	x1, x1, x5
    5b18:	d360fc21 	lsr	x1, x1, #32
    5b1c:	eb02003f 	cmp	x1, x2
    5b20:	54000102 	b.cs	5b40 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b24:	8b010063 	add	x3, x3, x1
    5b28:	39400061 	ldrb	w1, [x3]
    5b2c:	7100043f 	cmp	w1, #0x1
    5b30:	54000081 	b.ne	5b40 <fwp_rc_free_arr+0x80>  // b.any
    5b34:	17fffc37 	b	4c10 <fwp_mem_free>
    5b38:	72003c3f 	tst	w1, #0xffff
    5b3c:	54ffff60 	b.eq	5b28 <fwp_rc_free_arr+0x68>  // b.none
    5b40:	d65f03c0 	ret

0000000000005b44 <fwp_rc_dup>:
    5b44:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5b48:	91190042 	add	x2, x2, #0x640
    5b4c:	f949d841 	ldr	x1, [x2, #5040]
    5b50:	f949ec43 	ldr	x3, [x2, #5080]
    5b54:	cb010001 	sub	x1, x0, x1
    5b58:	eb03403f 	cmp	x1, x3, lsl #16
    5b5c:	540003c2 	b.cs	5bd4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5b60:	d350fc20 	lsr	x0, x1, #16
    5b64:	f949fc44 	ldr	x4, [x2, #5112]
    5b68:	8b000800 	add	x0, x0, x0, lsl #2
    5b6c:	d37df002 	lsl	x2, x0, #3
    5b70:	8b020083 	add	x3, x4, x2
    5b74:	f9401060 	ldr	x0, [x3, #32]
    5b78:	b40002e0 	cbz	x0, 5bd4 <fwp_rc_dup+0x90>
    5b7c:	38626882 	ldrb	w2, [x4, x2]
    5b80:	7100085f 	cmp	w2, #0x2
    5b84:	540002a0 	b.eq	5bd8 <fwp_rc_dup+0x94>  // b.none
    5b88:	7100045f 	cmp	w2, #0x1
    5b8c:	54000241 	b.ne	5bd4 <fwp_rc_dup+0x90>  // b.any
    5b90:	29430864 	ldp	w4, w2, [x3, #24]
    5b94:	92403c21 	and	x1, x1, #0xffff
    5b98:	9b047c21 	mul	x1, x1, x4
    5b9c:	d360fc21 	lsr	x1, x1, #32
    5ba0:	eb02003f 	cmp	x1, x2
    5ba4:	54000182 	b.cs	5bd4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5ba8:	8b010000 	add	x0, x0, x1
    5bac:	39400001 	ldrb	w1, [x0]
    5bb0:	34000121 	cbz	w1, 5bd4 <fwp_rc_dup+0x90>
    5bb4:	f00000c2 	adrp	x2, 20000 <__data_start>
    5bb8:	91018042 	add	x2, x2, #0x60
    5bbc:	b9413043 	ldr	w3, [x2, #304]
    5bc0:	35000123 	cbnz	w3, 5be4 <fwp_rc_dup+0xa0>
    5bc4:	7103f43f 	cmp	w1, #0xfd
    5bc8:	54000168 	b.hi	5bf4 <fwp_rc_dup+0xb0>  // b.pmore
    5bcc:	11000421 	add	w1, w1, #0x1
    5bd0:	39000001 	strb	w1, [x0]
    5bd4:	d65f03c0 	ret
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54fffe80 	b.eq	5bac <fwp_rc_dup+0x68>  // b.none
    5be0:	d65f03c0 	ret
    5be4:	f940ac43 	ldr	x3, [x2, #344]
    5be8:	91000463 	add	x3, x3, #0x1
    5bec:	f900ac43 	str	x3, [x2, #344]
    5bf0:	17fffff5 	b	5bc4 <fwp_rc_dup+0x80>
    5bf4:	17fffb20 	b	4874 <fwp_rc_wide_dup>
    5bf8:	d503201f 	nop
    5bfc:	d503201f 	nop

0000000000005c00 <fwp_owned_entry161>:
    5c00:	d10103ff 	sub	sp, sp, #0x40
    5c04:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5c08:	f947f442 	ldr	x2, [x2, #4072]
    5c0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c10:	910083fd 	add	x29, sp, #0x20
    5c14:	a90353f3 	stp	x19, x20, [sp, #48]
    5c18:	f9400043 	ldr	x3, [x2]
    5c1c:	f9000fe3 	str	x3, [sp, #24]
    5c20:	d2800003 	mov	x3, #0x0                   	// #0
    5c24:	a9400c01 	ldp	x1, x3, [x0]
    5c28:	f9400802 	ldr	x2, [x0, #16]
    5c2c:	ab020022 	adds	x2, x1, x2
    5c30:	540006e6 	b.vs	5d0c <fwp_owned_entry161+0x10c>
    5c34:	910023e1 	add	x1, sp, #0x8
    5c38:	52800000 	mov	w0, #0x0                   	// #0
    5c3c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c40:	97ffff1c 	bl	58b0 <fwp_data.part.0.constprop.0>
    5c44:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5c48:	91190063 	add	x3, x3, #0x640
    5c4c:	aa0003f3 	mov	x19, x0
    5c50:	f949d861 	ldr	x1, [x3, #5040]
    5c54:	f949ec60 	ldr	x0, [x3, #5080]
    5c58:	cb010261 	sub	x1, x19, x1
    5c5c:	eb00403f 	cmp	x1, x0, lsl #16
    5c60:	54000322 	b.cs	5cc4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5c64:	d350fc22 	lsr	x2, x1, #16
    5c68:	f949fc63 	ldr	x3, [x3, #5112]
    5c6c:	8b020842 	add	x2, x2, x2, lsl #2
    5c70:	d37df042 	lsl	x2, x2, #3
    5c74:	8b020060 	add	x0, x3, x2
    5c78:	f9401014 	ldr	x20, [x0, #32]
    5c7c:	b4000254 	cbz	x20, 5cc4 <fwp_owned_entry161+0xc4>
    5c80:	38626862 	ldrb	w2, [x3, x2]
    5c84:	7100085f 	cmp	w2, #0x2
    5c88:	54000360 	b.eq	5cf4 <fwp_owned_entry161+0xf4>  // b.none
    5c8c:	7100045f 	cmp	w2, #0x1
    5c90:	540001a1 	b.ne	5cc4 <fwp_owned_entry161+0xc4>  // b.any
    5c94:	29430002 	ldp	w2, w0, [x0, #24]
    5c98:	92403c21 	and	x1, x1, #0xffff
    5c9c:	9b027c21 	mul	x1, x1, x2
    5ca0:	d360fc21 	lsr	x1, x1, #32
    5ca4:	eb00003f 	cmp	x1, x0
    5ca8:	540000e2 	b.cs	5cc4 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5cac:	8b010294 	add	x20, x20, x1
    5cb0:	39400280 	ldrb	w0, [x20]
    5cb4:	7103fc1f 	cmp	w0, #0xff
    5cb8:	54000240 	b.eq	5d00 <fwp_owned_entry161+0x100>  // b.none
    5cbc:	52800020 	mov	w0, #0x1                   	// #1
    5cc0:	39000280 	strb	w0, [x20]
    5cc4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5cc8:	f947f400 	ldr	x0, [x0, #4072]
    5ccc:	f9400fe2 	ldr	x2, [sp, #24]
    5cd0:	f9400001 	ldr	x1, [x0]
    5cd4:	eb010042 	subs	x2, x2, x1
    5cd8:	d2800001 	mov	x1, #0x0                   	// #0
    5cdc:	540001a1 	b.ne	5d10 <fwp_owned_entry161+0x110>  // b.any
    5ce0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ce4:	aa1303e0 	mov	x0, x19
    5ce8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5cec:	910103ff 	add	sp, sp, #0x40
    5cf0:	d65f03c0 	ret
    5cf4:	72003c3f 	tst	w1, #0xffff
    5cf8:	54fffe61 	b.ne	5cc4 <fwp_owned_entry161+0xc4>  // b.any
    5cfc:	17ffffed 	b	5cb0 <fwp_owned_entry161+0xb0>
    5d00:	aa1403e0 	mov	x0, x20
    5d04:	97fffb23 	bl	4990 <fwp_rc_forget_slot>
    5d08:	17ffffed 	b	5cbc <fwp_owned_entry161+0xbc>
    5d0c:	97fff33d 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5d10:	97fff2c0 	bl	2810 <__stack_chk_fail@plt>

0000000000005d14 <e161>:
    5d14:	d10103ff 	sub	sp, sp, #0x40
    5d18:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5d1c:	f947f442 	ldr	x2, [x2, #4072]
    5d20:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d24:	910083fd 	add	x29, sp, #0x20
    5d28:	a90353f3 	stp	x19, x20, [sp, #48]
    5d2c:	f9400043 	ldr	x3, [x2]
    5d30:	f9000fe3 	str	x3, [sp, #24]
    5d34:	d2800003 	mov	x3, #0x0                   	// #0
    5d38:	a9400c01 	ldp	x1, x3, [x0]
    5d3c:	f9400802 	ldr	x2, [x0, #16]
    5d40:	ab020022 	adds	x2, x1, x2
    5d44:	54000726 	b.vs	5e28 <e161+0x114>
    5d48:	910023e1 	add	x1, sp, #0x8
    5d4c:	52800000 	mov	w0, #0x0                   	// #0
    5d50:	a9008be3 	stp	x3, x2, [sp, #8]
    5d54:	97fffed7 	bl	58b0 <fwp_data.part.0.constprop.0>
    5d58:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5d5c:	91190063 	add	x3, x3, #0x640
    5d60:	aa0003f3 	mov	x19, x0
    5d64:	f949d861 	ldr	x1, [x3, #5040]
    5d68:	f949ec60 	ldr	x0, [x3, #5080]
    5d6c:	cb010261 	sub	x1, x19, x1
    5d70:	eb00403f 	cmp	x1, x0, lsl #16
    5d74:	54000322 	b.cs	5dd8 <e161+0xc4>  // b.hs, b.nlast
    5d78:	d350fc22 	lsr	x2, x1, #16
    5d7c:	f949fc63 	ldr	x3, [x3, #5112]
    5d80:	8b020842 	add	x2, x2, x2, lsl #2
    5d84:	d37df042 	lsl	x2, x2, #3
    5d88:	8b020060 	add	x0, x3, x2
    5d8c:	f9401014 	ldr	x20, [x0, #32]
    5d90:	b4000254 	cbz	x20, 5dd8 <e161+0xc4>
    5d94:	38626862 	ldrb	w2, [x3, x2]
    5d98:	7100085f 	cmp	w2, #0x2
    5d9c:	540003a0 	b.eq	5e10 <e161+0xfc>  // b.none
    5da0:	7100045f 	cmp	w2, #0x1
    5da4:	540001a1 	b.ne	5dd8 <e161+0xc4>  // b.any
    5da8:	29430002 	ldp	w2, w0, [x0, #24]
    5dac:	92403c21 	and	x1, x1, #0xffff
    5db0:	9b027c21 	mul	x1, x1, x2
    5db4:	d360fc21 	lsr	x1, x1, #32
    5db8:	eb00003f 	cmp	x1, x0
    5dbc:	540000e2 	b.cs	5dd8 <e161+0xc4>  // b.hs, b.nlast
    5dc0:	8b010294 	add	x20, x20, x1
    5dc4:	39400280 	ldrb	w0, [x20]
    5dc8:	7103fc1f 	cmp	w0, #0xff
    5dcc:	54000280 	b.eq	5e1c <e161+0x108>  // b.none
    5dd0:	52800020 	mov	w0, #0x1                   	// #1
    5dd4:	39000280 	strb	w0, [x20]
    5dd8:	aa1303e0 	mov	x0, x19
    5ddc:	97ffff12 	bl	5a24 <fwp_rc_share>
    5de0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5de4:	f947f400 	ldr	x0, [x0, #4072]
    5de8:	f9400fe2 	ldr	x2, [sp, #24]
    5dec:	f9400001 	ldr	x1, [x0]
    5df0:	eb010042 	subs	x2, x2, x1
    5df4:	d2800001 	mov	x1, #0x0                   	// #0
    5df8:	540001a1 	b.ne	5e2c <e161+0x118>  // b.any
    5dfc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e00:	aa1303e0 	mov	x0, x19
    5e04:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e08:	910103ff 	add	sp, sp, #0x40
    5e0c:	d65f03c0 	ret
    5e10:	72003c3f 	tst	w1, #0xffff
    5e14:	54fffe21 	b.ne	5dd8 <e161+0xc4>  // b.any
    5e18:	17ffffeb 	b	5dc4 <e161+0xb0>
    5e1c:	aa1403e0 	mov	x0, x20
    5e20:	97fffadc 	bl	4990 <fwp_rc_forget_slot>
    5e24:	17ffffeb 	b	5dd0 <e161+0xbc>
    5e28:	97fff2f6 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5e2c:	97fff279 	bl	2810 <__stack_chk_fail@plt>

0000000000005e30 <fwp_drop0>:
    5e30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e34:	910003fd 	mov	x29, sp
    5e38:	a90153f3 	stp	x19, x20, [sp, #16]
    5e3c:	f90013f5 	str	x21, [sp, #32]
    5e40:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5e44:	911902b4 	add	x20, x21, #0x640
    5e48:	f949da81 	ldr	x1, [x20, #5040]
    5e4c:	f949ee82 	ldr	x2, [x20, #5080]
    5e50:	cb010001 	sub	x1, x0, x1
    5e54:	eb02403f 	cmp	x1, x2, lsl #16
    5e58:	54000382 	b.cs	5ec8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e5c:	d350fc22 	lsr	x2, x1, #16
    5e60:	f949fe84 	ldr	x4, [x20, #5112]
    5e64:	8b020842 	add	x2, x2, x2, lsl #2
    5e68:	d37df042 	lsl	x2, x2, #3
    5e6c:	8b020083 	add	x3, x4, x2
    5e70:	f9401073 	ldr	x19, [x3, #32]
    5e74:	b40002b3 	cbz	x19, 5ec8 <fwp_drop0+0x98>
    5e78:	38626882 	ldrb	w2, [x4, x2]
    5e7c:	7100085f 	cmp	w2, #0x2
    5e80:	540002c0 	b.eq	5ed8 <fwp_drop0+0xa8>  // b.none
    5e84:	7100045f 	cmp	w2, #0x1
    5e88:	54000201 	b.ne	5ec8 <fwp_drop0+0x98>  // b.any
    5e8c:	29430864 	ldp	w4, w2, [x3, #24]
    5e90:	92403c21 	and	x1, x1, #0xffff
    5e94:	9b047c21 	mul	x1, x1, x4
    5e98:	d360fc21 	lsr	x1, x1, #32
    5e9c:	eb02003f 	cmp	x1, x2
    5ea0:	54000142 	b.cs	5ec8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ea4:	8b010273 	add	x19, x19, x1
    5ea8:	39400261 	ldrb	w1, [x19]
    5eac:	340000e1 	cbz	w1, 5ec8 <fwp_drop0+0x98>
    5eb0:	7100043f 	cmp	w1, #0x1
    5eb4:	540001e0 	b.eq	5ef0 <fwp_drop0+0xc0>  // b.none
    5eb8:	7103fc3f 	cmp	w1, #0xff
    5ebc:	540002e0 	b.eq	5f18 <fwp_drop0+0xe8>  // b.none
    5ec0:	51000421 	sub	w1, w1, #0x1
    5ec4:	39000261 	strb	w1, [x19]
    5ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ecc:	f94013f5 	ldr	x21, [sp, #32]
    5ed0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ed4:	d65f03c0 	ret
    5ed8:	72003c3f 	tst	w1, #0xffff
    5edc:	54fffe60 	b.eq	5ea8 <fwp_drop0+0x78>  // b.none
    5ee0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ee4:	f94013f5 	ldr	x21, [sp, #32]
    5ee8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5eec:	d65f03c0 	ret
    5ef0:	f9400813 	ldr	x19, [x0, #16]
    5ef4:	97fffef3 	bl	5ac0 <fwp_rc_free_arr>
    5ef8:	911902a0 	add	x0, x21, #0x640
    5efc:	f949d801 	ldr	x1, [x0, #5040]
    5f00:	f949ec00 	ldr	x0, [x0, #5080]
    5f04:	cb010261 	sub	x1, x19, x1
    5f08:	eb00403f 	cmp	x1, x0, lsl #16
    5f0c:	54fffde2 	b.cs	5ec8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f10:	aa1303e0 	mov	x0, x19
    5f14:	17ffffd2 	b	5e5c <fwp_drop0+0x2c>
    5f18:	ca534660 	eor	x0, x19, x19, lsr #17
    5f1c:	911902b5 	add	x21, x21, #0x640
    5f20:	ca402400 	eor	x0, x0, x0, lsr #9
    5f24:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5f28:	f94a2400 	ldr	x0, [x0, #5192]
    5f2c:	b5000080 	cbnz	x0, 5f3c <fwp_drop0+0x10c>
    5f30:	14000010 	b	5f70 <fwp_drop0+0x140>
    5f34:	f9400800 	ldr	x0, [x0, #16]
    5f38:	b40001c0 	cbz	x0, 5f70 <fwp_drop0+0x140>
    5f3c:	f9400001 	ldr	x1, [x0]
    5f40:	eb13003f 	cmp	x1, x19
    5f44:	54ffff81 	b.ne	5f34 <fwp_drop0+0x104>  // b.any
    5f48:	f9400401 	ldr	x1, [x0, #8]
    5f4c:	d1000421 	sub	x1, x1, #0x1
    5f50:	f9000401 	str	x1, [x0, #8]
    5f54:	f103f83f 	cmp	x1, #0xfe
    5f58:	54fffb81 	b.ne	5ec8 <fwp_drop0+0x98>  // b.any
    5f5c:	aa1303e0 	mov	x0, x19
    5f60:	97fffa8c 	bl	4990 <fwp_rc_forget_slot>
    5f64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f68:	39000260 	strb	w0, [x19]
    5f6c:	17ffffd7 	b	5ec8 <fwp_drop0+0x98>
    5f70:	d0000020 	adrp	x0, b000 <__divti3+0x110>
    5f74:	912b4000 	add	x0, x0, #0xad0
    5f78:	97fff602 	bl	3780 <fwp_trap>
    5f7c:	d503201f 	nop

0000000000005f80 <fwp_arg_drop12>:
    5f80:	7100003f 	cmp	w1, #0x0
    5f84:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5f88:	54000041 	b.ne	5f90 <fwp_arg_drop12+0x10>  // b.any
    5f8c:	d65f03c0 	ret
    5f90:	f9400000 	ldr	x0, [x0]
    5f94:	17ffffa7 	b	5e30 <fwp_drop0>
    5f98:	d503201f 	nop
    5f9c:	d503201f 	nop

0000000000005fa0 <fwp_drop1>:
    5fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fa4:	910003fd 	mov	x29, sp
    5fa8:	a90153f3 	stp	x19, x20, [sp, #16]
    5fac:	f90013f5 	str	x21, [sp, #32]
    5fb0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5fb4:	911902b4 	add	x20, x21, #0x640
    5fb8:	f949da81 	ldr	x1, [x20, #5040]
    5fbc:	f949ee82 	ldr	x2, [x20, #5080]
    5fc0:	cb010001 	sub	x1, x0, x1
    5fc4:	eb02403f 	cmp	x1, x2, lsl #16
    5fc8:	54000382 	b.cs	6038 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fcc:	d350fc22 	lsr	x2, x1, #16
    5fd0:	f949fe84 	ldr	x4, [x20, #5112]
    5fd4:	8b020842 	add	x2, x2, x2, lsl #2
    5fd8:	d37df042 	lsl	x2, x2, #3
    5fdc:	8b020083 	add	x3, x4, x2
    5fe0:	f9401073 	ldr	x19, [x3, #32]
    5fe4:	b40002b3 	cbz	x19, 6038 <fwp_drop1+0x98>
    5fe8:	38626882 	ldrb	w2, [x4, x2]
    5fec:	7100085f 	cmp	w2, #0x2
    5ff0:	540002c0 	b.eq	6048 <fwp_drop1+0xa8>  // b.none
    5ff4:	7100045f 	cmp	w2, #0x1
    5ff8:	54000201 	b.ne	6038 <fwp_drop1+0x98>  // b.any
    5ffc:	29430864 	ldp	w4, w2, [x3, #24]
    6000:	92403c21 	and	x1, x1, #0xffff
    6004:	9b047c21 	mul	x1, x1, x4
    6008:	d360fc21 	lsr	x1, x1, #32
    600c:	eb02003f 	cmp	x1, x2
    6010:	54000142 	b.cs	6038 <fwp_drop1+0x98>  // b.hs, b.nlast
    6014:	8b010273 	add	x19, x19, x1
    6018:	39400261 	ldrb	w1, [x19]
    601c:	340000e1 	cbz	w1, 6038 <fwp_drop1+0x98>
    6020:	7100043f 	cmp	w1, #0x1
    6024:	540001e0 	b.eq	6060 <fwp_drop1+0xc0>  // b.none
    6028:	7103fc3f 	cmp	w1, #0xff
    602c:	540002e0 	b.eq	6088 <fwp_drop1+0xe8>  // b.none
    6030:	51000421 	sub	w1, w1, #0x1
    6034:	39000261 	strb	w1, [x19]
    6038:	a94153f3 	ldp	x19, x20, [sp, #16]
    603c:	f94013f5 	ldr	x21, [sp, #32]
    6040:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6044:	d65f03c0 	ret
    6048:	72003c3f 	tst	w1, #0xffff
    604c:	54fffe60 	b.eq	6018 <fwp_drop1+0x78>  // b.none
    6050:	a94153f3 	ldp	x19, x20, [sp, #16]
    6054:	f94013f5 	ldr	x21, [sp, #32]
    6058:	a8c37bfd 	ldp	x29, x30, [sp], #48
    605c:	d65f03c0 	ret
    6060:	f9400813 	ldr	x19, [x0, #16]
    6064:	97fffe97 	bl	5ac0 <fwp_rc_free_arr>
    6068:	911902a0 	add	x0, x21, #0x640
    606c:	f949d801 	ldr	x1, [x0, #5040]
    6070:	f949ec00 	ldr	x0, [x0, #5080]
    6074:	cb010261 	sub	x1, x19, x1
    6078:	eb00403f 	cmp	x1, x0, lsl #16
    607c:	54fffde2 	b.cs	6038 <fwp_drop1+0x98>  // b.hs, b.nlast
    6080:	aa1303e0 	mov	x0, x19
    6084:	17ffffd2 	b	5fcc <fwp_drop1+0x2c>
    6088:	ca534660 	eor	x0, x19, x19, lsr #17
    608c:	911902b5 	add	x21, x21, #0x640
    6090:	ca402400 	eor	x0, x0, x0, lsr #9
    6094:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6098:	f94a2400 	ldr	x0, [x0, #5192]
    609c:	b5000080 	cbnz	x0, 60ac <fwp_drop1+0x10c>
    60a0:	14000010 	b	60e0 <fwp_drop1+0x140>
    60a4:	f9400800 	ldr	x0, [x0, #16]
    60a8:	b40001c0 	cbz	x0, 60e0 <fwp_drop1+0x140>
    60ac:	f9400001 	ldr	x1, [x0]
    60b0:	eb13003f 	cmp	x1, x19
    60b4:	54ffff81 	b.ne	60a4 <fwp_drop1+0x104>  // b.any
    60b8:	f9400401 	ldr	x1, [x0, #8]
    60bc:	d1000421 	sub	x1, x1, #0x1
    60c0:	f9000401 	str	x1, [x0, #8]
    60c4:	f103f83f 	cmp	x1, #0xfe
    60c8:	54fffb81 	b.ne	6038 <fwp_drop1+0x98>  // b.any
    60cc:	aa1303e0 	mov	x0, x19
    60d0:	97fffa30 	bl	4990 <fwp_rc_forget_slot>
    60d4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60d8:	39000260 	strb	w0, [x19]
    60dc:	17ffffd7 	b	6038 <fwp_drop1+0x98>
    60e0:	b0000020 	adrp	x0, b000 <__divti3+0x110>
    60e4:	912b4000 	add	x0, x0, #0xad0
    60e8:	97fff5a6 	bl	3780 <fwp_trap>
    60ec:	d503201f 	nop

00000000000060f0 <fwp_closure_drop>:
    60f0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xba0>
    60f4:	911900a4 	add	x4, x5, #0x640
    60f8:	aa0003e1 	mov	x1, x0
    60fc:	f949d882 	ldr	x2, [x4, #5040]
    6100:	f949ec80 	ldr	x0, [x4, #5080]
    6104:	cb020022 	sub	x2, x1, x2
    6108:	eb00405f 	cmp	x2, x0, lsl #16
    610c:	54000662 	b.cs	61d8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6114:	d350fc43 	lsr	x3, x2, #16
    6118:	910003fd 	mov	x29, sp
    611c:	8b030863 	add	x3, x3, x3, lsl #2
    6120:	f949fc84 	ldr	x4, [x4, #5112]
    6124:	d37df063 	lsl	x3, x3, #3
    6128:	f9000bf3 	str	x19, [sp, #16]
    612c:	8b030080 	add	x0, x4, x3
    6130:	f9401013 	ldr	x19, [x0, #32]
    6134:	b40002b3 	cbz	x19, 6188 <fwp_closure_drop+0x98>
    6138:	38636883 	ldrb	w3, [x4, x3]
    613c:	7100087f 	cmp	w3, #0x2
    6140:	54000420 	b.eq	61c4 <fwp_closure_drop+0xd4>  // b.none
    6144:	7100047f 	cmp	w3, #0x1
    6148:	54000201 	b.ne	6188 <fwp_closure_drop+0x98>  // b.any
    614c:	29430003 	ldp	w3, w0, [x0, #24]
    6150:	92403c42 	and	x2, x2, #0xffff
    6154:	9b037c42 	mul	x2, x2, x3
    6158:	d360fc42 	lsr	x2, x2, #32
    615c:	eb00005f 	cmp	x2, x0
    6160:	54000142 	b.cs	6188 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6164:	8b020273 	add	x19, x19, x2
    6168:	39400260 	ldrb	w0, [x19]
    616c:	340000e0 	cbz	w0, 6188 <fwp_closure_drop+0x98>
    6170:	7100041f 	cmp	w0, #0x1
    6174:	54000100 	b.eq	6194 <fwp_closure_drop+0xa4>  // b.none
    6178:	7103fc1f 	cmp	w0, #0xff
    617c:	54000300 	b.eq	61dc <fwp_closure_drop+0xec>  // b.none
    6180:	51000400 	sub	w0, w0, #0x1
    6184:	39000260 	strb	w0, [x19]
    6188:	f9400bf3 	ldr	x19, [sp, #16]
    618c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6190:	d65f03c0 	ret
    6194:	d53bd040 	mrs	x0, tpidr_el0
    6198:	91400000 	add	x0, x0, #0x0, lsl #12
    619c:	91004000 	add	x0, x0, #0x10
    61a0:	f9400000 	ldr	x0, [x0]
    61a4:	b4000080 	cbz	x0, 61b4 <fwp_closure_drop+0xc4>
    61a8:	f9400bf3 	ldr	x19, [sp, #16]
    61ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61b0:	17fff58d 	b	37e4 <fwp_closure_drop_push>
    61b4:	f9400bf3 	ldr	x19, [sp, #16]
    61b8:	aa0103e0 	mov	x0, x1
    61bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c0:	17fff5f8 	b	39a0 <fwp_closure_drop.part.0>
    61c4:	72003c5f 	tst	w2, #0xffff
    61c8:	54fffd00 	b.eq	6168 <fwp_closure_drop+0x78>  // b.none
    61cc:	f9400bf3 	ldr	x19, [sp, #16]
    61d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d4:	d65f03c0 	ret
    61d8:	d65f03c0 	ret
    61dc:	ca534660 	eor	x0, x19, x19, lsr #17
    61e0:	911900a5 	add	x5, x5, #0x640
    61e4:	ca402400 	eor	x0, x0, x0, lsr #9
    61e8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    61ec:	f94a2400 	ldr	x0, [x0, #5192]
    61f0:	b5000080 	cbnz	x0, 6200 <fwp_closure_drop+0x110>
    61f4:	14000010 	b	6234 <fwp_closure_drop+0x144>
    61f8:	f9400800 	ldr	x0, [x0, #16]
    61fc:	b40001c0 	cbz	x0, 6234 <fwp_closure_drop+0x144>
    6200:	f9400001 	ldr	x1, [x0]
    6204:	eb13003f 	cmp	x1, x19
    6208:	54ffff81 	b.ne	61f8 <fwp_closure_drop+0x108>  // b.any
    620c:	f9400401 	ldr	x1, [x0, #8]
    6210:	d1000421 	sub	x1, x1, #0x1
    6214:	f9000401 	str	x1, [x0, #8]
    6218:	f103f83f 	cmp	x1, #0xfe
    621c:	54fffb61 	b.ne	6188 <fwp_closure_drop+0x98>  // b.any
    6220:	aa1303e0 	mov	x0, x19
    6224:	97fff9db 	bl	4990 <fwp_rc_forget_slot>
    6228:	12800020 	mov	w0, #0xfffffffe            	// #-2
    622c:	39000260 	strb	w0, [x19]
    6230:	17ffffd6 	b	6188 <fwp_closure_drop+0x98>
    6234:	b0000020 	adrp	x0, b000 <__divti3+0x110>
    6238:	912b4000 	add	x0, x0, #0xad0
    623c:	97fff551 	bl	3780 <fwp_trap>

0000000000006240 <fwp_owned_tape_release>:
    6240:	b4000940 	cbz	x0, 6368 <fwp_owned_tape_release+0x128>
    6244:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6248:	910003fd 	mov	x29, sp
    624c:	a90153f3 	stp	x19, x20, [sp, #16]
    6250:	aa0003f3 	mov	x19, x0
    6254:	f9400000 	ldr	x0, [x0]
    6258:	b4000060 	cbz	x0, 6264 <fwp_owned_tape_release+0x24>
    625c:	f9400661 	ldr	x1, [x19, #8]
    6260:	f9000401 	str	x1, [x0, #8]
    6264:	f9400661 	ldr	x1, [x19, #8]
    6268:	b4000041 	cbz	x1, 6270 <fwp_owned_tape_release+0x30>
    626c:	f9000020 	str	x0, [x1]
    6270:	f9400a60 	ldr	x0, [x19, #16]
    6274:	f9403401 	ldr	x1, [x0, #104]
    6278:	b40005c1 	cbz	x1, 6330 <fwp_owned_tape_release+0xf0>
    627c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6280:	eb00005f 	cmp	x2, x0
    6284:	540002ed 	b.le	62e0 <fwp_owned_tape_release+0xa0>
    6288:	d2800014 	mov	x20, #0x0                   	// #0
    628c:	f90013f5 	str	x21, [sp, #32]
    6290:	d2800015 	mov	x21, #0x0                   	// #0
    6294:	d503201f 	nop
    6298:	f9402260 	ldr	x0, [x19, #64]
    629c:	910006b5 	add	x21, x21, #0x1
    62a0:	f8746800 	ldr	x0, [x0, x20]
    62a4:	d63f0020 	blr	x1
    62a8:	f9402260 	ldr	x0, [x19, #64]
    62ac:	f9400a61 	ldr	x1, [x19, #16]
    62b0:	8b140000 	add	x0, x0, x20
    62b4:	91004294 	add	x20, x20, #0x10
    62b8:	f9400400 	ldr	x0, [x0, #8]
    62bc:	f9403421 	ldr	x1, [x1, #104]
    62c0:	d63f0020 	blr	x1
    62c4:	a9450261 	ldp	x1, x0, [x19, #80]
    62c8:	cb010000 	sub	x0, x0, x1
    62cc:	eb15001f 	cmp	x0, x21
    62d0:	f9400a60 	ldr	x0, [x19, #16]
    62d4:	f9403401 	ldr	x1, [x0, #104]
    62d8:	54fffe0c 	b.gt	6298 <fwp_owned_tape_release+0x58>
    62dc:	f94013f5 	ldr	x21, [sp, #32]
    62e0:	f9403663 	ldr	x3, [x19, #104]
    62e4:	f9401262 	ldr	x2, [x19, #32]
    62e8:	f100007f 	cmp	x3, #0x0
    62ec:	540001ed 	b.le	6328 <fwp_owned_tape_release+0xe8>
    62f0:	d2800014 	mov	x20, #0x0                   	// #0
    62f4:	d503201f 	nop
    62f8:	f9402660 	ldr	x0, [x19, #72]
    62fc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6300:	eb02001f 	cmp	x0, x2
    6304:	540000c0 	b.eq	631c <fwp_owned_tape_release+0xdc>  // b.none
    6308:	d63f0020 	blr	x1
    630c:	f9400a60 	ldr	x0, [x19, #16]
    6310:	f9401262 	ldr	x2, [x19, #32]
    6314:	f9403663 	ldr	x3, [x19, #104]
    6318:	f9403401 	ldr	x1, [x0, #104]
    631c:	91000694 	add	x20, x20, #0x1
    6320:	eb14007f 	cmp	x3, x20
    6324:	54fffeac 	b.gt	62f8 <fwp_owned_tape_release+0xb8>
    6328:	aa0203e0 	mov	x0, x2
    632c:	d63f0020 	blr	x1
    6330:	f9401660 	ldr	x0, [x19, #40]
    6334:	97ffff6f 	bl	60f0 <fwp_closure_drop>
    6338:	f9401a60 	ldr	x0, [x19, #48]
    633c:	97ffff6d 	bl	60f0 <fwp_closure_drop>
    6340:	f9401e60 	ldr	x0, [x19, #56]
    6344:	97ffff6b 	bl	60f0 <fwp_closure_drop>
    6348:	f9402260 	ldr	x0, [x19, #64]
    634c:	97fffa31 	bl	4c10 <fwp_mem_free>
    6350:	f9402660 	ldr	x0, [x19, #72]
    6354:	97fffa2f 	bl	4c10 <fwp_mem_free>
    6358:	aa1303e0 	mov	x0, x19
    635c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6360:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6364:	17fffa2b 	b	4c10 <fwp_mem_free>
    6368:	d65f03c0 	ret
    636c:	d503201f 	nop

0000000000006370 <fwp_tape_finish>:
    6370:	d10203ff 	sub	sp, sp, #0x80
    6374:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6378:	f947f421 	ldr	x1, [x1, #4072]
    637c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6380:	910103fd 	add	x29, sp, #0x40
    6384:	a9065bf5 	stp	x21, x22, [sp, #96]
    6388:	a90763f7 	stp	x23, x24, [sp, #112]
    638c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6390:	910182f6 	add	x22, x23, #0x60
    6394:	f9400022 	ldr	x2, [x1]
    6398:	f9001fe2 	str	x2, [sp, #56]
    639c:	d2800002 	mov	x2, #0x0                   	// #0
    63a0:	910382c0 	add	x0, x22, #0xe0
    63a4:	97fff7f8 	bl	4384 <fwp_tape_buffers_dispose>
    63a8:	f9008edf 	str	xzr, [x22, #280]
    63ac:	f9406ec0 	ldr	x0, [x22, #216]
    63b0:	f100001f 	cmp	x0, #0x0
    63b4:	5400034d 	b.le	641c <fwp_tape_finish+0xac>
    63b8:	910003f8 	mov	x24, sp
    63bc:	d2800015 	mov	x21, #0x0                   	// #0
    63c0:	a90553f3 	stp	x19, x20, [sp, #80]
    63c4:	d2800014 	mov	x20, #0x0                   	// #0
    63c8:	91000694 	add	x20, x20, #0x1
    63cc:	f94046d3 	ldr	x19, [x22, #136]
    63d0:	8b150273 	add	x19, x19, x21
    63d4:	9101a2b5 	add	x21, x21, #0x68
    63d8:	aa1303e0 	mov	x0, x19
    63dc:	97fff2ee 	bl	2f94 <fwp_tape_unlink_scope>
    63e0:	aa1803e0 	mov	x0, x24
    63e4:	a9440663 	ldp	x3, x1, [x19, #64]
    63e8:	f9001be1 	str	x1, [sp, #48]
    63ec:	f9400e62 	ldr	x2, [x19, #24]
    63f0:	a9020be3 	stp	x3, x2, [sp, #32]
    63f4:	ad410261 	ldp	q1, q0, [x19, #32]
    63f8:	ad0003e1 	stp	q1, q0, [sp]
    63fc:	97fff7e2 	bl	4384 <fwp_tape_buffers_dispose>
    6400:	f9403260 	ldr	x0, [x19, #96]
    6404:	97ffff8f 	bl	6240 <fwp_owned_tape_release>
    6408:	f900327f 	str	xzr, [x19, #96]
    640c:	f9406ec0 	ldr	x0, [x22, #216]
    6410:	eb14001f 	cmp	x0, x20
    6414:	54fffdac 	b.gt	63c8 <fwp_tape_finish+0x58>
    6418:	a94553f3 	ldp	x19, x20, [sp, #80]
    641c:	910182e0 	add	x0, x23, #0x60
    6420:	f9404400 	ldr	x0, [x0, #136]
    6424:	b4000040 	cbz	x0, 642c <fwp_tape_finish+0xbc>
    6428:	97fff7b6 	bl	4300 <ad_raw_free.part.0>
    642c:	910182f7 	add	x23, x23, #0x60
    6430:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6434:	f947f400 	ldr	x0, [x0, #4072]
    6438:	f90046ff 	str	xzr, [x23, #136]
    643c:	f9006eff 	str	xzr, [x23, #216]
    6440:	f90092ff 	str	xzr, [x23, #288]
    6444:	f900b2ff 	str	xzr, [x23, #352]
    6448:	f9401fe2 	ldr	x2, [sp, #56]
    644c:	f9400001 	ldr	x1, [x0]
    6450:	eb010042 	subs	x2, x2, x1
    6454:	d2800001 	mov	x1, #0x0                   	// #0
    6458:	540000c1 	b.ne	6470 <fwp_tape_finish+0x100>  // b.any
    645c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6460:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6464:	a94763f7 	ldp	x23, x24, [sp, #112]
    6468:	910203ff 	add	sp, sp, #0x80
    646c:	d65f03c0 	ret
    6470:	a90553f3 	stp	x19, x20, [sp, #80]
    6474:	97fff0e7 	bl	2810 <__stack_chk_fail@plt>
    6478:	d503201f 	nop
    647c:	d503201f 	nop

0000000000006480 <fwp_tape_scope_release>:
    6480:	d10243ff 	sub	sp, sp, #0x90
    6484:	a9047bfd 	stp	x29, x30, [sp, #64]
    6488:	910103fd 	add	x29, sp, #0x40
    648c:	a90553f3 	stp	x19, x20, [sp, #80]
    6490:	aa0003f4 	mov	x20, x0
    6494:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6498:	f947f400 	ldr	x0, [x0, #4072]
    649c:	b9400285 	ldr	w5, [x20]
    64a0:	f9400001 	ldr	x1, [x0]
    64a4:	f9001fe1 	str	x1, [sp, #56]
    64a8:	d2800001 	mov	x1, #0x0                   	// #0
    64ac:	37f806c5 	tbnz	w5, #31, 6584 <fwp_tape_scope_release+0x104>
    64b0:	a90763f7 	stp	x23, x24, [sp, #112]
    64b4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    64b8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    64bc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    64c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64c4:	910003f7 	mov	x23, sp
    64c8:	91018273 	add	x19, x19, #0x60
    64cc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    64d0:	a9065bf5 	stp	x21, x22, [sp, #96]
    64d4:	52800d16 	mov	w22, #0x68                  	// #104
    64d8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    64dc:	f90043f9 	str	x25, [sp, #128]
    64e0:	14000006 	b	64f8 <fwp_tape_scope_release+0x78>
    64e4:	97fff7a8 	bl	4384 <fwp_tape_buffers_dispose>
    64e8:	aa1903e0 	mov	x0, x25
    64ec:	97ffff55 	bl	6240 <fwp_owned_tape_release>
    64f0:	b9400285 	ldr	w5, [x20]
    64f4:	37f80425 	tbnz	w5, #31, 6578 <fwp_tape_scope_release+0xf8>
    64f8:	f9404666 	ldr	x6, [x19, #136]
    64fc:	9b367ca5 	smull	x5, w5, w22
    6500:	8b0500c0 	add	x0, x6, x5
    6504:	97fff2a4 	bl	2f94 <fwp_tape_unlink_scope>
    6508:	ad410001 	ldp	q1, q0, [x0, #32]
    650c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6510:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6514:	f9400c03 	ldr	x3, [x0, #24]
    6518:	ad0003e1 	stp	q1, q0, [sp]
    651c:	b86568c1 	ldr	w1, [x6, x5]
    6520:	a9440804 	ldp	x4, x2, [x0, #64]
    6524:	b900041f 	str	wzr, [x0, #4]
    6528:	f9403019 	ldr	x25, [x0, #96]
    652c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6530:	f9000c1f 	str	xzr, [x0, #24]
    6534:	a9020fe4 	stp	x4, x3, [sp, #32]
    6538:	f9001be2 	str	x2, [sp, #48]
    653c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6540:	f900301f 	str	xzr, [x0, #96]
    6544:	6b15003f 	cmp	w1, w21
    6548:	540000e8 	b.hi	6564 <fwp_tape_scope_release+0xe4>  // b.pmore
    654c:	9343fca5 	asr	x5, x5, #3
    6550:	f940b260 	ldr	x0, [x19, #352]
    6554:	9b187ca5 	mul	x5, x5, x24
    6558:	eb0000bf 	cmp	x5, x0
    655c:	5400004a 	b.ge	6564 <fwp_tape_scope_release+0xe4>  // b.tcont
    6560:	f900b265 	str	x5, [x19, #352]
    6564:	aa1703e0 	mov	x0, x23
    6568:	b5fffbf9 	cbnz	x25, 64e4 <fwp_tape_scope_release+0x64>
    656c:	97fff7ce 	bl	44a4 <fwp_tape_buffers_release>
    6570:	b9400285 	ldr	w5, [x20]
    6574:	36fffc25 	tbz	w5, #31, 64f8 <fwp_tape_scope_release+0x78>
    6578:	a9465bf5 	ldp	x21, x22, [sp, #96]
    657c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6580:	f94043f9 	ldr	x25, [sp, #128]
    6584:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6588:	f947f400 	ldr	x0, [x0, #4072]
    658c:	f9401fe2 	ldr	x2, [sp, #56]
    6590:	f9400001 	ldr	x1, [x0]
    6594:	eb010042 	subs	x2, x2, x1
    6598:	d2800001 	mov	x1, #0x0                   	// #0
    659c:	540000a1 	b.ne	65b0 <fwp_tape_scope_release+0x130>  // b.any
    65a0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    65a4:	a94553f3 	ldp	x19, x20, [sp, #80]
    65a8:	910243ff 	add	sp, sp, #0x90
    65ac:	d65f03c0 	ret
    65b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    65b4:	a90763f7 	stp	x23, x24, [sp, #112]
    65b8:	f90043f9 	str	x25, [sp, #128]
    65bc:	97fff095 	bl	2810 <__stack_chk_fail@plt>

00000000000065c0 <fwp_task_dispose>:
    65c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65c4:	910003fd 	mov	x29, sp
    65c8:	f9000bf3 	str	x19, [sp, #16]
    65cc:	aa0003f3 	mov	x19, x0
    65d0:	39414000 	ldrb	w0, [x0, #80]
    65d4:	36000720 	tbz	w0, #0, 66b8 <fwp_task_dispose+0xf8>
    65d8:	f9400a60 	ldr	x0, [x19, #16]
    65dc:	b50006e0 	cbnz	x0, 66b8 <fwp_task_dispose+0xf8>
    65e0:	a9478660 	ldp	x0, x1, [x19, #120]
    65e4:	39014e7f 	strb	wzr, [x19, #83]
    65e8:	f9003e7f 	str	xzr, [x19, #120]
    65ec:	f100003f 	cmp	x1, #0x0
    65f0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65f4:	54000040 	b.eq	65fc <fwp_task_dispose+0x3c>  // b.none
    65f8:	d63f0020 	blr	x1
    65fc:	f9405660 	ldr	x0, [x19, #168]
    6600:	97fff984 	bl	4c10 <fwp_mem_free>
    6604:	f900567f 	str	xzr, [x19, #168]
    6608:	b9405e60 	ldr	w0, [x19, #92]
    660c:	7100041f 	cmp	w0, #0x1
    6610:	54000420 	b.eq	6694 <fwp_task_dispose+0xd4>  // b.none
    6614:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6618:	91190042 	add	x2, x2, #0x640
    661c:	f949d840 	ldr	x0, [x2, #5040]
    6620:	f949ec41 	ldr	x1, [x2, #5080]
    6624:	cb000260 	sub	x0, x19, x0
    6628:	eb01401f 	cmp	x0, x1, lsl #16
    662c:	540002e2 	b.cs	6688 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6630:	d350fc01 	lsr	x1, x0, #16
    6634:	f949fc44 	ldr	x4, [x2, #5112]
    6638:	8b010821 	add	x1, x1, x1, lsl #2
    663c:	d37df021 	lsl	x1, x1, #3
    6640:	8b010083 	add	x3, x4, x1
    6644:	f9401062 	ldr	x2, [x3, #32]
    6648:	b4000202 	cbz	x2, 6688 <fwp_task_dispose+0xc8>
    664c:	38616881 	ldrb	w1, [x4, x1]
    6650:	7100083f 	cmp	w1, #0x2
    6654:	54000280 	b.eq	66a4 <fwp_task_dispose+0xe4>  // b.none
    6658:	7100043f 	cmp	w1, #0x1
    665c:	54000161 	b.ne	6688 <fwp_task_dispose+0xc8>  // b.any
    6660:	29430464 	ldp	w4, w1, [x3, #24]
    6664:	92403c00 	and	x0, x0, #0xffff
    6668:	9b047c00 	mul	x0, x0, x4
    666c:	d360fc00 	lsr	x0, x0, #32
    6670:	eb01001f 	cmp	x0, x1
    6674:	540000a2 	b.cs	6688 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6678:	8b000042 	add	x2, x2, x0
    667c:	39400040 	ldrb	w0, [x2]
    6680:	7100041f 	cmp	w0, #0x1
    6684:	54000080 	b.eq	6694 <fwp_task_dispose+0xd4>  // b.none
    6688:	f9400bf3 	ldr	x19, [sp, #16]
    668c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6690:	d65f03c0 	ret
    6694:	aa1303e0 	mov	x0, x19
    6698:	f9400bf3 	ldr	x19, [sp, #16]
    669c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66a0:	17fff95c 	b	4c10 <fwp_mem_free>
    66a4:	72003c1f 	tst	w0, #0xffff
    66a8:	54fffea0 	b.eq	667c <fwp_task_dispose+0xbc>  // b.none
    66ac:	f9400bf3 	ldr	x19, [sp, #16]
    66b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66b4:	d65f03c0 	ret
    66b8:	97fff06a 	bl	2860 <abort@plt>
    66bc:	d503201f 	nop

00000000000066c0 <fwp_free_zombie>:
    66c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66c4:	910003fd 	mov	x29, sp
    66c8:	a90153f3 	stp	x19, x20, [sp, #16]
    66cc:	d00000d4 	adrp	x20, 20000 <__data_start>
    66d0:	91018281 	add	x1, x20, #0x60
    66d4:	f940b433 	ldr	x19, [x1, #360]
    66d8:	b4000333 	cbz	x19, 673c <fwp_free_zombie+0x7c>
    66dc:	f9404c20 	ldr	x0, [x1, #152]
    66e0:	eb00027f 	cmp	x19, x0
    66e4:	540002c0 	b.eq	673c <fwp_free_zombie+0x7c>  // b.none
    66e8:	b9417022 	ldr	w2, [x1, #368]
    66ec:	f9400a60 	ldr	x0, [x19, #16]
    66f0:	7100fc5f 	cmp	w2, #0x3f
    66f4:	5400078c 	b.gt	67e4 <fwp_free_zombie+0x124>
    66f8:	91060023 	add	x3, x1, #0x180
    66fc:	11000444 	add	w4, w2, #0x1
    6700:	b9017024 	str	w4, [x1, #368]
    6704:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6708:	f822d860 	str	x0, [x3, w2, sxtw #3]
    670c:	a9530261 	ldp	x1, x0, [x19, #304]
    6710:	b4000741 	cbz	x1, 67f8 <fwp_free_zombie+0x138>
    6714:	f9009c20 	str	x0, [x1, #312]
    6718:	b4000040 	cbz	x0, 6720 <fwp_free_zombie+0x60>
    671c:	f9009801 	str	x1, [x0, #304]
    6720:	91018294 	add	x20, x20, #0x60
    6724:	b9405e60 	ldr	w0, [x19, #92]
    6728:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    672c:	f900b69f 	str	xzr, [x20, #360]
    6730:	34000140 	cbz	w0, 6758 <fwp_free_zombie+0x98>
    6734:	7100041f 	cmp	w0, #0x1
    6738:	54000080 	b.eq	6748 <fwp_free_zombie+0x88>  // b.none
    673c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6744:	d65f03c0 	ret
    6748:	aa1303e0 	mov	x0, x19
    674c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6754:	17ffff9b 	b	65c0 <fwp_task_dispose>
    6758:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    675c:	91190082 	add	x2, x4, #0x640
    6760:	f949d841 	ldr	x1, [x2, #5040]
    6764:	f949ec40 	ldr	x0, [x2, #5080]
    6768:	cb010261 	sub	x1, x19, x1
    676c:	eb00403f 	cmp	x1, x0, lsl #16
    6770:	54fffe62 	b.cs	673c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6774:	d350fc20 	lsr	x0, x1, #16
    6778:	f949fc43 	ldr	x3, [x2, #5112]
    677c:	8b000800 	add	x0, x0, x0, lsl #2
    6780:	d37df000 	lsl	x0, x0, #3
    6784:	8b000062 	add	x2, x3, x0
    6788:	f9401054 	ldr	x20, [x2, #32]
    678c:	b4fffd94 	cbz	x20, 673c <fwp_free_zombie+0x7c>
    6790:	38606860 	ldrb	w0, [x3, x0]
    6794:	7100081f 	cmp	w0, #0x2
    6798:	54000360 	b.eq	6804 <fwp_free_zombie+0x144>  // b.none
    679c:	7100041f 	cmp	w0, #0x1
    67a0:	54fffce1 	b.ne	673c <fwp_free_zombie+0x7c>  // b.any
    67a4:	29430043 	ldp	w3, w0, [x2, #24]
    67a8:	92403c21 	and	x1, x1, #0xffff
    67ac:	9b037c21 	mul	x1, x1, x3
    67b0:	d360fc21 	lsr	x1, x1, #32
    67b4:	eb00003f 	cmp	x1, x0
    67b8:	54fffc22 	b.cs	673c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    67bc:	8b010294 	add	x20, x20, x1
    67c0:	39400280 	ldrb	w0, [x20]
    67c4:	34fffbc0 	cbz	w0, 673c <fwp_free_zombie+0x7c>
    67c8:	7100041f 	cmp	w0, #0x1
    67cc:	54fffbe0 	b.eq	6748 <fwp_free_zombie+0x88>  // b.none
    67d0:	7103fc1f 	cmp	w0, #0xff
    67d4:	540001e0 	b.eq	6810 <fwp_free_zombie+0x150>  // b.none
    67d8:	51000400 	sub	w0, w0, #0x1
    67dc:	39000280 	strb	w0, [x20]
    67e0:	17ffffd7 	b	673c <fwp_free_zombie+0x7c>
    67e4:	f9400e61 	ldr	x1, [x19, #24]
    67e8:	97fff052 	bl	2930 <munmap@plt>
    67ec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67f0:	a9530261 	ldp	x1, x0, [x19, #304]
    67f4:	b5fff901 	cbnz	x1, 6714 <fwp_free_zombie+0x54>
    67f8:	91018282 	add	x2, x20, #0x60
    67fc:	f901c040 	str	x0, [x2, #896]
    6800:	17ffffc6 	b	6718 <fwp_free_zombie+0x58>
    6804:	72003c3f 	tst	w1, #0xffff
    6808:	54fff9a1 	b.ne	673c <fwp_free_zombie+0x7c>  // b.any
    680c:	17ffffed 	b	67c0 <fwp_free_zombie+0x100>
    6810:	ca544680 	eor	x0, x20, x20, lsr #17
    6814:	91190084 	add	x4, x4, #0x640
    6818:	ca402400 	eor	x0, x0, x0, lsr #9
    681c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6820:	f94a2400 	ldr	x0, [x0, #5192]
    6824:	b5000080 	cbnz	x0, 6834 <fwp_free_zombie+0x174>
    6828:	14000010 	b	6868 <fwp_free_zombie+0x1a8>
    682c:	f9400800 	ldr	x0, [x0, #16]
    6830:	b40001c0 	cbz	x0, 6868 <fwp_free_zombie+0x1a8>
    6834:	f9400001 	ldr	x1, [x0]
    6838:	eb14003f 	cmp	x1, x20
    683c:	54ffff81 	b.ne	682c <fwp_free_zombie+0x16c>  // b.any
    6840:	f9400401 	ldr	x1, [x0, #8]
    6844:	d1000421 	sub	x1, x1, #0x1
    6848:	f9000401 	str	x1, [x0, #8]
    684c:	f103f83f 	cmp	x1, #0xfe
    6850:	54fff761 	b.ne	673c <fwp_free_zombie+0x7c>  // b.any
    6854:	aa1403e0 	mov	x0, x20
    6858:	97fff84e 	bl	4990 <fwp_rc_forget_slot>
    685c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6860:	39000280 	strb	w0, [x20]
    6864:	17ffffb6 	b	673c <fwp_free_zombie+0x7c>
    6868:	b0000020 	adrp	x0, b000 <__divti3+0x110>
    686c:	912b4000 	add	x0, x0, #0xad0
    6870:	97fff3c4 	bl	3780 <fwp_trap>

0000000000006874 <fwp_block>:
    6874:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6878:	910003fd 	mov	x29, sp
    687c:	a90153f3 	stp	x19, x20, [sp, #16]
    6880:	d00000d3 	adrp	x19, 20000 <__data_start>
    6884:	91018274 	add	x20, x19, #0x60
    6888:	f9406682 	ldr	x2, [x20, #200]
    688c:	b4000622 	cbz	x2, 6950 <fwp_block+0xdc>
    6890:	91018261 	add	x1, x19, #0x60
    6894:	f9408040 	ldr	x0, [x2, #256]
    6898:	f9006420 	str	x0, [x1, #200]
    689c:	b4000680 	cbz	x0, 696c <fwp_block+0xf8>
    68a0:	91018263 	add	x3, x19, #0x60
    68a4:	3901505f 	strb	wzr, [x2, #84]
    68a8:	f9404c64 	ldr	x4, [x3, #152]
    68ac:	eb02009f 	cmp	x4, x2
    68b0:	54000440 	b.eq	6938 <fwp_block+0xc4>  // b.none
    68b4:	f941c465 	ldr	x5, [x3, #904]
    68b8:	f9004c62 	str	x2, [x3, #152]
    68bc:	f9400441 	ldr	x1, [x2, #8]
    68c0:	f9004885 	str	x5, [x4, #144]
    68c4:	f941c865 	ldr	x5, [x3, #912]
    68c8:	f9004c85 	str	x5, [x4, #152]
    68cc:	f941cc65 	ldr	x5, [x3, #920]
    68d0:	f9005085 	str	x5, [x4, #160]
    68d4:	f941d065 	ldr	x5, [x3, #928]
    68d8:	f9005485 	str	x5, [x4, #168]
    68dc:	f941d465 	ldr	x5, [x3, #936]
    68e0:	f9005885 	str	x5, [x4, #176]
    68e4:	f941d865 	ldr	x5, [x3, #944]
    68e8:	f9005c85 	str	x5, [x4, #184]
    68ec:	f941dc65 	ldr	x5, [x3, #952]
    68f0:	f9006085 	str	x5, [x4, #192]
    68f4:	f9400480 	ldr	x0, [x4, #8]
    68f8:	f9404844 	ldr	x4, [x2, #144]
    68fc:	f901c464 	str	x4, [x3, #904]
    6900:	f9404c44 	ldr	x4, [x2, #152]
    6904:	f901c864 	str	x4, [x3, #912]
    6908:	f9405044 	ldr	x4, [x2, #160]
    690c:	f901cc64 	str	x4, [x3, #920]
    6910:	f9405444 	ldr	x4, [x2, #168]
    6914:	f901d064 	str	x4, [x3, #928]
    6918:	f9405844 	ldr	x4, [x2, #176]
    691c:	f901d464 	str	x4, [x3, #936]
    6920:	a94b8844 	ldp	x4, x2, [x2, #184]
    6924:	f901d864 	str	x4, [x3, #944]
    6928:	f901dc62 	str	x2, [x3, #952]
    692c:	97ffefd1 	bl	2870 <swapcontext@plt>
    6930:	97ffff64 	bl	66c0 <fwp_free_zombie>
    6934:	d503201f 	nop
    6938:	91018260 	add	x0, x19, #0x60
    693c:	b943c000 	ldr	w0, [x0, #960]
    6940:	340001a0 	cbz	w0, 6974 <fwp_block+0x100>
    6944:	a94153f3 	ldp	x19, x20, [sp, #16]
    6948:	a8c27bfd 	ldp	x29, x30, [sp], #32
    694c:	d65f03c0 	ret
    6950:	97fff73d 	bl	4644 <fwp_poll_events>
    6954:	f9406682 	ldr	x2, [x20, #200]
    6958:	b4ffffc2 	cbz	x2, 6950 <fwp_block+0xdc>
    695c:	91018261 	add	x1, x19, #0x60
    6960:	f9408040 	ldr	x0, [x2, #256]
    6964:	f9006420 	str	x0, [x1, #200]
    6968:	b5fff9c0 	cbnz	x0, 68a0 <fwp_block+0x2c>
    696c:	f900603f 	str	xzr, [x1, #192]
    6970:	17ffffcc 	b	68a0 <fwp_block+0x2c>
    6974:	b0000020 	adrp	x0, b000 <__divti3+0x110>
    6978:	91300000 	add	x0, x0, #0xc00
    697c:	97fff009 	bl	29a0 <getenv@plt>
    6980:	5284e202 	mov	w2, #0x2710                	// #10000
    6984:	b4000060 	cbz	x0, 6990 <fwp_block+0x11c>
    6988:	39400001 	ldrb	w1, [x0]
    698c:	350000c1 	cbnz	w1, 69a4 <fwp_block+0x130>
    6990:	91018273 	add	x19, x19, #0x60
    6994:	b903c262 	str	w2, [x19, #960]
    6998:	a94153f3 	ldp	x19, x20, [sp, #16]
    699c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69a0:	d65f03c0 	ret
    69a4:	52800142 	mov	w2, #0xa                   	// #10
    69a8:	d2800001 	mov	x1, #0x0                   	// #0
    69ac:	97ffef4d 	bl	26e0 <strtoll@plt>
    69b0:	d1000403 	sub	x3, x0, #0x1
    69b4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69b8:	eb02007f 	cmp	x3, x2
    69bc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69c0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69c4:	17fffff3 	b	6990 <fwp_block+0x11c>
    69c8:	d503201f 	nop
    69cc:	d503201f 	nop

00000000000069d0 <fwp_drop4>:
    69d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69d4:	910003fd 	mov	x29, sp
    69d8:	a90153f3 	stp	x19, x20, [sp, #16]
    69dc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    69e0:	f90013f5 	str	x21, [sp, #32]
    69e4:	91190275 	add	x21, x19, #0x640
    69e8:	f949daa1 	ldr	x1, [x21, #5040]
    69ec:	f949eea2 	ldr	x2, [x21, #5080]
    69f0:	cb010001 	sub	x1, x0, x1
    69f4:	eb02403f 	cmp	x1, x2, lsl #16
    69f8:	54000382 	b.cs	6a68 <fwp_drop4+0x98>  // b.hs, b.nlast
    69fc:	d350fc22 	lsr	x2, x1, #16
    6a00:	f949fea3 	ldr	x3, [x21, #5112]
    6a04:	8b020842 	add	x2, x2, x2, lsl #2
    6a08:	d37df042 	lsl	x2, x2, #3
    6a0c:	8b020064 	add	x4, x3, x2
    6a10:	f9401094 	ldr	x20, [x4, #32]
    6a14:	b40002b4 	cbz	x20, 6a68 <fwp_drop4+0x98>
    6a18:	38626862 	ldrb	w2, [x3, x2]
    6a1c:	7100085f 	cmp	w2, #0x2
    6a20:	540007a0 	b.eq	6b14 <fwp_drop4+0x144>  // b.none
    6a24:	7100045f 	cmp	w2, #0x1
    6a28:	54000201 	b.ne	6a68 <fwp_drop4+0x98>  // b.any
    6a2c:	29430885 	ldp	w5, w2, [x4, #24]
    6a30:	92403c21 	and	x1, x1, #0xffff
    6a34:	9b057c21 	mul	x1, x1, x5
    6a38:	d360fc21 	lsr	x1, x1, #32
    6a3c:	eb02003f 	cmp	x1, x2
    6a40:	54000142 	b.cs	6a68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a44:	8b010294 	add	x20, x20, x1
    6a48:	39400281 	ldrb	w1, [x20]
    6a4c:	340000e1 	cbz	w1, 6a68 <fwp_drop4+0x98>
    6a50:	7100043f 	cmp	w1, #0x1
    6a54:	54000120 	b.eq	6a78 <fwp_drop4+0xa8>  // b.none
    6a58:	7103fc3f 	cmp	w1, #0xff
    6a5c:	540007c0 	b.eq	6b54 <fwp_drop4+0x184>  // b.none
    6a60:	51000421 	sub	w1, w1, #0x1
    6a64:	39000281 	strb	w1, [x20]
    6a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a6c:	f94013f5 	ldr	x21, [sp, #32]
    6a70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a74:	d65f03c0 	ret
    6a78:	f9400001 	ldr	x1, [x0]
    6a7c:	b7f80581 	tbnz	x1, #63, 6b2c <fwp_drop4+0x15c>
    6a80:	91190273 	add	x19, x19, #0x640
    6a84:	f949da61 	ldr	x1, [x19, #5040]
    6a88:	f949ee62 	ldr	x2, [x19, #5080]
    6a8c:	cb010001 	sub	x1, x0, x1
    6a90:	eb02403f 	cmp	x1, x2, lsl #16
    6a94:	54fffea2 	b.cs	6a68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a98:	d350fc22 	lsr	x2, x1, #16
    6a9c:	8b020842 	add	x2, x2, x2, lsl #2
    6aa0:	d37df042 	lsl	x2, x2, #3
    6aa4:	8b020065 	add	x5, x3, x2
    6aa8:	f94010a4 	ldr	x4, [x5, #32]
    6aac:	b4fffde4 	cbz	x4, 6a68 <fwp_drop4+0x98>
    6ab0:	38626862 	ldrb	w2, [x3, x2]
    6ab4:	7100085f 	cmp	w2, #0x2
    6ab8:	54000220 	b.eq	6afc <fwp_drop4+0x12c>  // b.none
    6abc:	7100045f 	cmp	w2, #0x1
    6ac0:	54fffd41 	b.ne	6a68 <fwp_drop4+0x98>  // b.any
    6ac4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ac8:	92403c21 	and	x1, x1, #0xffff
    6acc:	9b037c21 	mul	x1, x1, x3
    6ad0:	d360fc21 	lsr	x1, x1, #32
    6ad4:	eb02003f 	cmp	x1, x2
    6ad8:	54fffc82 	b.cs	6a68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6adc:	8b010084 	add	x4, x4, x1
    6ae0:	39400081 	ldrb	w1, [x4]
    6ae4:	7100043f 	cmp	w1, #0x1
    6ae8:	54fffc01 	b.ne	6a68 <fwp_drop4+0x98>  // b.any
    6aec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6af0:	f94013f5 	ldr	x21, [sp, #32]
    6af4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6af8:	17fff846 	b	4c10 <fwp_mem_free>
    6afc:	72003c3f 	tst	w1, #0xffff
    6b00:	54ffff00 	b.eq	6ae0 <fwp_drop4+0x110>  // b.none
    6b04:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b08:	f94013f5 	ldr	x21, [sp, #32]
    6b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b10:	d65f03c0 	ret
    6b14:	72003c3f 	tst	w1, #0xffff
    6b18:	54fff980 	b.eq	6a48 <fwp_drop4+0x78>  // b.none
    6b1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b20:	f94013f5 	ldr	x21, [sp, #32]
    6b24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b28:	d65f03c0 	ret
    6b2c:	f9400414 	ldr	x20, [x0, #8]
    6b30:	97fffbe4 	bl	5ac0 <fwp_rc_free_arr>
    6b34:	91190260 	add	x0, x19, #0x640
    6b38:	f949d801 	ldr	x1, [x0, #5040]
    6b3c:	f949ec00 	ldr	x0, [x0, #5080]
    6b40:	cb010281 	sub	x1, x20, x1
    6b44:	eb00403f 	cmp	x1, x0, lsl #16
    6b48:	54fff902 	b.cs	6a68 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b4c:	aa1403e0 	mov	x0, x20
    6b50:	17ffffab 	b	69fc <fwp_drop4+0x2c>
    6b54:	ca544680 	eor	x0, x20, x20, lsr #17
    6b58:	91190273 	add	x19, x19, #0x640
    6b5c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b60:	8b200e60 	add	x0, x19, w0, uxtb #3
    6b64:	f94a2400 	ldr	x0, [x0, #5192]
    6b68:	b5000080 	cbnz	x0, 6b78 <fwp_drop4+0x1a8>
    6b6c:	14000010 	b	6bac <fwp_drop4+0x1dc>
    6b70:	f9400800 	ldr	x0, [x0, #16]
    6b74:	b40001c0 	cbz	x0, 6bac <fwp_drop4+0x1dc>
    6b78:	f9400001 	ldr	x1, [x0]
    6b7c:	eb14003f 	cmp	x1, x20
    6b80:	54ffff81 	b.ne	6b70 <fwp_drop4+0x1a0>  // b.any
    6b84:	f9400401 	ldr	x1, [x0, #8]
    6b88:	d1000421 	sub	x1, x1, #0x1
    6b8c:	f9000401 	str	x1, [x0, #8]
    6b90:	f103f83f 	cmp	x1, #0xfe
    6b94:	54fff6a1 	b.ne	6a68 <fwp_drop4+0x98>  // b.any
    6b98:	aa1403e0 	mov	x0, x20
    6b9c:	97fff77d 	bl	4990 <fwp_rc_forget_slot>
    6ba0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ba4:	39000280 	strb	w0, [x20]
    6ba8:	17ffffb0 	b	6a68 <fwp_drop4+0x98>
    6bac:	b0000020 	adrp	x0, b000 <__divti3+0x110>
    6bb0:	912b4000 	add	x0, x0, #0xad0
    6bb4:	97fff2f3 	bl	3780 <fwp_trap>
    6bb8:	d503201f 	nop
    6bbc:	d503201f 	nop

0000000000006bc0 <fwp_caps161>:
    6bc0:	34000041 	cbz	w1, 6bc8 <fwp_caps161+0x8>
    6bc4:	d65f03c0 	ret
    6bc8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6bcc:	91190063 	add	x3, x3, #0x640
    6bd0:	f949d861 	ldr	x1, [x3, #5040]
    6bd4:	f949ec62 	ldr	x2, [x3, #5080]
    6bd8:	cb010001 	sub	x1, x0, x1
    6bdc:	eb02403f 	cmp	x1, x2, lsl #16
    6be0:	54ffff22 	b.cs	6bc4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6be4:	d350fc22 	lsr	x2, x1, #16
    6be8:	f949fc65 	ldr	x5, [x3, #5112]
    6bec:	8b020842 	add	x2, x2, x2, lsl #2
    6bf0:	d37df042 	lsl	x2, x2, #3
    6bf4:	8b0200a4 	add	x4, x5, x2
    6bf8:	f9401083 	ldr	x3, [x4, #32]
    6bfc:	b4fffe43 	cbz	x3, 6bc4 <fwp_caps161+0x4>
    6c00:	386268a2 	ldrb	w2, [x5, x2]
    6c04:	7100085f 	cmp	w2, #0x2
    6c08:	540001c0 	b.eq	6c40 <fwp_caps161+0x80>  // b.none
    6c0c:	7100045f 	cmp	w2, #0x1
    6c10:	54fffda1 	b.ne	6bc4 <fwp_caps161+0x4>  // b.any
    6c14:	29430885 	ldp	w5, w2, [x4, #24]
    6c18:	92403c21 	and	x1, x1, #0xffff
    6c1c:	9b057c21 	mul	x1, x1, x5
    6c20:	d360fc21 	lsr	x1, x1, #32
    6c24:	eb02003f 	cmp	x1, x2
    6c28:	54fffce2 	b.cs	6bc4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c2c:	8b010063 	add	x3, x3, x1
    6c30:	39400061 	ldrb	w1, [x3]
    6c34:	7100043f 	cmp	w1, #0x1
    6c38:	54fffc61 	b.ne	6bc4 <fwp_caps161+0x4>  // b.any
    6c3c:	17fff7f5 	b	4c10 <fwp_mem_free>
    6c40:	72003c3f 	tst	w1, #0xffff
    6c44:	54ffff60 	b.eq	6c30 <fwp_caps161+0x70>  // b.none
    6c48:	d65f03c0 	ret
    6c4c:	d503201f 	nop

0000000000006c50 <f12>:
    6c50:	d10483ff 	sub	sp, sp, #0x120
    6c54:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    6c58:	f947f442 	ldr	x2, [x2, #4072]
    6c5c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    6c60:	910303fd 	add	x29, sp, #0xc0
    6c64:	a90f63f7 	stp	x23, x24, [sp, #240]
    6c68:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    6c6c:	911902e3 	add	x3, x23, #0x640
    6c70:	a90e5bf5 	stp	x21, x22, [sp, #224]
    6c74:	d00000d5 	adrp	x21, 20000 <__data_start>
    6c78:	910182a4 	add	x4, x21, #0x60
    6c7c:	f949d861 	ldr	x1, [x3, #5040]
    6c80:	a90d53f3 	stp	x19, x20, [sp, #208]
    6c84:	910103f8 	add	x24, sp, #0x40
    6c88:	f949ec65 	ldr	x5, [x3, #5080]
    6c8c:	a9106bf9 	stp	x25, x26, [sp, #256]
    6c90:	d00000d9 	adrp	x25, 20000 <__data_start>
    6c94:	a91173fb 	stp	x27, x28, [sp, #272]
    6c98:	91004339 	add	x25, x25, #0x10
    6c9c:	91008339 	add	x25, x25, #0x20
    6ca0:	f941c886 	ldr	x6, [x4, #912]
    6ca4:	f9400047 	ldr	x7, [x2]
    6ca8:	f9005fe7 	str	x7, [sp, #184]
    6cac:	d2800007 	mov	x7, #0x0                   	// #0
    6cb0:	9100e3f6 	add	x22, sp, #0x38
    6cb4:	90000013 	adrp	x19, 6000 <fwp_drop1+0x60>
    6cb8:	12800007 	mov	w7, #0xffffffff            	// #-1
    6cbc:	91120262 	add	x2, x19, #0x480
    6cc0:	cb010321 	sub	x1, x25, x1
    6cc4:	b9003be7 	str	w7, [sp, #56]
    6cc8:	a9040be6 	stp	x6, x2, [sp, #64]
    6ccc:	aa0003f4 	mov	x20, x0
    6cd0:	f9002bf6 	str	x22, [sp, #80]
    6cd4:	f901c898 	str	x24, [x4, #912]
    6cd8:	eb05403f 	cmp	x1, x5, lsl #16
    6cdc:	540003a2 	b.cs	6d50 <f12+0x100>  // b.hs, b.nlast
    6ce0:	d350fc20 	lsr	x0, x1, #16
    6ce4:	f949fc64 	ldr	x4, [x3, #5112]
    6ce8:	8b000800 	add	x0, x0, x0, lsl #2
    6cec:	d37df002 	lsl	x2, x0, #3
    6cf0:	8b020083 	add	x3, x4, x2
    6cf4:	f9401060 	ldr	x0, [x3, #32]
    6cf8:	b40002c0 	cbz	x0, 6d50 <f12+0x100>
    6cfc:	38626882 	ldrb	w2, [x4, x2]
    6d00:	7100085f 	cmp	w2, #0x2
    6d04:	54006de0 	b.eq	7ac0 <f12+0xe70>  // b.none
    6d08:	7100045f 	cmp	w2, #0x1
    6d0c:	54000221 	b.ne	6d50 <f12+0x100>  // b.any
    6d10:	29430864 	ldp	w4, w2, [x3, #24]
    6d14:	92403c21 	and	x1, x1, #0xffff
    6d18:	9b047c21 	mul	x1, x1, x4
    6d1c:	d360fc21 	lsr	x1, x1, #32
    6d20:	eb02003f 	cmp	x1, x2
    6d24:	54000162 	b.cs	6d50 <f12+0x100>  // b.hs, b.nlast
    6d28:	8b010000 	add	x0, x0, x1
    6d2c:	39400001 	ldrb	w1, [x0]
    6d30:	34000101 	cbz	w1, 6d50 <f12+0x100>
    6d34:	910182a2 	add	x2, x21, #0x60
    6d38:	b9413043 	ldr	w3, [x2, #304]
    6d3c:	35006f63 	cbnz	w3, 7b28 <f12+0xed8>
    6d40:	7103f43f 	cmp	w1, #0xfd
    6d44:	54007948 	b.hi	7c6c <f12+0x101c>  // b.pmore
    6d48:	11000421 	add	w1, w1, #0x1
    6d4c:	39000001 	strb	w1, [x0]
    6d50:	aa1903e0 	mov	x0, x25
    6d54:	97fffce7 	bl	60f0 <fwp_closure_drop>
    6d58:	b4006bf4 	cbz	x20, 7ad4 <f12+0xe84>
    6d5c:	aa1403e0 	mov	x0, x20
    6d60:	d2800001 	mov	x1, #0x0                   	// #0
    6d64:	d503201f 	nop
    6d68:	f9400800 	ldr	x0, [x0, #16]
    6d6c:	91000421 	add	x1, x1, #0x1
    6d70:	b5ffffc0 	cbnz	x0, 6d68 <f12+0x118>
    6d74:	aa0103fa 	mov	x26, x1
    6d78:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6d7c:	eb00003f 	cmp	x1, x0
    6d80:	54007b48 	b.hi	7ce8 <f12+0x1098>  // b.pmore
    6d84:	910182b9 	add	x25, x21, #0x60
    6d88:	b943c720 	ldr	w0, [x25, #964]
    6d8c:	34006860 	cbz	w0, 7a98 <f12+0xe48>
    6d90:	910182a0 	add	x0, x21, #0x60
    6d94:	f9406c1b 	ldr	x27, [x0, #216]
    6d98:	f940b019 	ldr	x25, [x0, #352]
    6d9c:	eb1b033f 	cmp	x25, x27
    6da0:	5400358a 	b.ge	7450 <f12+0x800>  // b.tcont
    6da4:	f9404401 	ldr	x1, [x0, #136]
    6da8:	8b190720 	add	x0, x25, x25, lsl #1
    6dac:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6db0:	8b000b20 	add	x0, x25, x0, lsl #2
    6db4:	8b000c20 	add	x0, x1, x0, lsl #3
    6db8:	b9400401 	ldr	w1, [x0, #4]
    6dbc:	35000081 	cbnz	w1, 6dcc <f12+0x17c>
    6dc0:	b9400001 	ldr	w1, [x0]
    6dc4:	6b02003f 	cmp	w1, w2
    6dc8:	54003449 	b.ls	7450 <f12+0x800>  // b.plast
    6dcc:	91000739 	add	x25, x25, #0x1
    6dd0:	9101a000 	add	x0, x0, #0x68
    6dd4:	eb1b033f 	cmp	x25, x27
    6dd8:	54ffff01 	b.ne	6db8 <f12+0x168>  // b.any
    6ddc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6de0:	eb00037f 	cmp	x27, x0
    6de4:	540078ec 	b.gt	7d00 <f12+0x10b0>
    6de8:	910182a0 	add	x0, x21, #0x60
    6dec:	f9409001 	ldr	x1, [x0, #288]
    6df0:	f940441c 	ldr	x28, [x0, #136]
    6df4:	eb1b003f 	cmp	x1, x27
    6df8:	54000221 	b.ne	6e3c <f12+0x1ec>  // b.any
    6dfc:	b400721b 	cbz	x27, 7c3c <f12+0xfec>
    6e00:	d37ffb79 	lsl	x25, x27, #1
    6e04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6e08:	eb00033f 	cmp	x25, x0
    6e0c:	9a80d339 	csel	x25, x25, x0, le
    6e10:	8b190721 	add	x1, x25, x25, lsl #1
    6e14:	8b010b21 	add	x1, x25, x1, lsl #2
    6e18:	d37df021 	lsl	x1, x1, #3
    6e1c:	aa1c03e0 	mov	x0, x28
    6e20:	52800002 	mov	w2, #0x0                   	// #0
    6e24:	97fff56c 	bl	43d4 <ad_raw_realloc>
    6e28:	aa0003fc 	mov	x28, x0
    6e2c:	b40035e0 	cbz	x0, 74e8 <f12+0x898>
    6e30:	910182a0 	add	x0, x21, #0x60
    6e34:	f900441c 	str	x28, [x0, #136]
    6e38:	f9009019 	str	x25, [x0, #288]
    6e3c:	8b1b0761 	add	x1, x27, x27, lsl #1
    6e40:	910182a0 	add	x0, x21, #0x60
    6e44:	4f000400 	movi	v0.4s, #0x0
    6e48:	aa1b03f9 	mov	x25, x27
    6e4c:	8b010b61 	add	x1, x27, x1, lsl #2
    6e50:	9100077b 	add	x27, x27, #0x1
    6e54:	f9006c1b 	str	x27, [x0, #216]
    6e58:	8b19073b 	add	x27, x25, x25, lsl #1
    6e5c:	8b010f81 	add	x1, x28, x1, lsl #3
    6e60:	b0000020 	adrp	x0, b000 <__divti3+0x110>
    6e64:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    6e68:	91284000 	add	x0, x0, #0xa10
    6e6c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6e70:	ad000020 	stp	q0, q0, [x1]
    6e74:	ad010020 	stp	q0, q0, [x1, #32]
    6e78:	ad020020 	stp	q0, q0, [x1, #64]
    6e7c:	f900303f 	str	xzr, [x1, #96]
    6e80:	f900337f 	str	xzr, [x27, #96]
    6e84:	97ffeec7 	bl	29a0 <getenv@plt>
    6e88:	b5002fc0 	cbnz	x0, 7480 <f12+0x830>
    6e8c:	d503201f 	nop
    6e90:	910182a0 	add	x0, x21, #0x60
    6e94:	f9408c01 	ldr	x1, [x0, #280]
    6e98:	b50062c1 	cbnz	x1, 7af0 <f12+0xea0>
    6e9c:	910182a2 	add	x2, x21, #0x60
    6ea0:	2f000400 	mvni	v0.2s, #0x0
    6ea4:	b9400363 	ldr	w3, [x27]
    6ea8:	52800024 	mov	w4, #0x1                   	// #1
    6eac:	91000720 	add	x0, x25, #0x1
    6eb0:	a900eb7a 	stp	x26, x26, [x27, #8]
    6eb4:	0b040063 	add	w3, w3, w4
    6eb8:	f941c841 	ldr	x1, [x2, #912]
    6ebc:	29001363 	stp	w3, w4, [x27]
    6ec0:	f9002b7f 	str	xzr, [x27, #80]
    6ec4:	f900b040 	str	x0, [x2, #352]
    6ec8:	fd002f60 	str	d0, [x27, #88]
    6ecc:	b4007081 	cbz	x1, 7cdc <f12+0x108c>
    6ed0:	91120273 	add	x19, x19, #0x480
    6ed4:	14000003 	b	6ee0 <f12+0x290>
    6ed8:	f9400021 	ldr	x1, [x1]
    6edc:	b4007001 	cbz	x1, 7cdc <f12+0x108c>
    6ee0:	f9400422 	ldr	x2, [x1, #8]
    6ee4:	eb13005f 	cmp	x2, x19
    6ee8:	54ffff81 	b.ne	6ed8 <f12+0x288>  // b.any
    6eec:	f9400821 	ldr	x1, [x1, #16]
    6ef0:	2a1903e4 	mov	w4, w25
    6ef4:	b9400022 	ldr	w2, [x1]
    6ef8:	f9002b61 	str	x1, [x27, #80]
    6efc:	b9005f62 	str	w2, [x27, #92]
    6f00:	37f80082 	tbnz	w2, #31, 6f10 <f12+0x2c0>
    6f04:	52800d05 	mov	w5, #0x68                  	// #104
    6f08:	9b257042 	smaddl	x2, w2, w5, x28
    6f0c:	b9005859 	str	w25, [x2, #88]
    6f10:	b9000024 	str	w4, [x1]
    6f14:	d3707c79 	ubfiz	x25, x3, #16, #32
    6f18:	aa000339 	orr	x25, x25, x0
    6f1c:	d2800002 	mov	x2, #0x0                   	// #0
    6f20:	aa1403e0 	mov	x0, x20
    6f24:	b4005934 	cbz	x20, 7a48 <f12+0xdf8>
    6f28:	f9400800 	ldr	x0, [x0, #16]
    6f2c:	91000442 	add	x2, x2, #0x1
    6f30:	b5ffffc0 	cbnz	x0, 6f28 <f12+0x2d8>
    6f34:	aa1403e1 	mov	x1, x20
    6f38:	f9400821 	ldr	x1, [x1, #16]
    6f3c:	91000400 	add	x0, x0, #0x1
    6f40:	b5ffffc1 	cbnz	x1, 6f38 <f12+0x2e8>
    6f44:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6f48:	eb01001f 	cmp	x0, x1
    6f4c:	54006b68 	b.hi	7cb8 <f12+0x1068>  // b.pmore
    6f50:	f100005f 	cmp	x2, #0x0
    6f54:	540057ad 	b.le	7a48 <f12+0xdf8>
    6f58:	eb00005f 	cmp	x2, x0
    6f5c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6f60:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6f64:	eb01027f 	cmp	x19, x1
    6f68:	54006a88 	b.hi	7cb8 <f12+0x1068>  // b.pmore
    6f6c:	d37ffa7a 	lsl	x26, x19, #1
    6f70:	52800041 	mov	w1, #0x2                   	// #2
    6f74:	91000740 	add	x0, x26, #0x1
    6f78:	d37df000 	lsl	x0, x0, #3
    6f7c:	97fff845 	bl	5090 <fwp_heap_alloc>
    6f80:	aa0003fb 	mov	x27, x0
    6f84:	911902e1 	add	x1, x23, #0x640
    6f88:	aa0103e0 	mov	x0, x1
    6f8c:	f900037a 	str	x26, [x27]
    6f90:	f949d821 	ldr	x1, [x1, #5040]
    6f94:	f949ec00 	ldr	x0, [x0, #5080]
    6f98:	cb010361 	sub	x1, x27, x1
    6f9c:	eb00403f 	cmp	x1, x0, lsl #16
    6fa0:	54005742 	b.cs	7a88 <f12+0xe38>  // b.hs, b.nlast
    6fa4:	911902e2 	add	x2, x23, #0x640
    6fa8:	d350fc20 	lsr	x0, x1, #16
    6fac:	8b000800 	add	x0, x0, x0, lsl #2
    6fb0:	f949fc43 	ldr	x3, [x2, #5112]
    6fb4:	d37df002 	lsl	x2, x0, #3
    6fb8:	8b020060 	add	x0, x3, x2
    6fbc:	f940101a 	ldr	x26, [x0, #32]
    6fc0:	b400025a 	cbz	x26, 7008 <f12+0x3b8>
    6fc4:	38626862 	ldrb	w2, [x3, x2]
    6fc8:	7100085f 	cmp	w2, #0x2
    6fcc:	54005740 	b.eq	7ab4 <f12+0xe64>  // b.none
    6fd0:	7100045f 	cmp	w2, #0x1
    6fd4:	540001a1 	b.ne	7008 <f12+0x3b8>  // b.any
    6fd8:	29430002 	ldp	w2, w0, [x0, #24]
    6fdc:	92403c21 	and	x1, x1, #0xffff
    6fe0:	9b027c21 	mul	x1, x1, x2
    6fe4:	d360fc21 	lsr	x1, x1, #32
    6fe8:	eb00003f 	cmp	x1, x0
    6fec:	540000e2 	b.cs	7008 <f12+0x3b8>  // b.hs, b.nlast
    6ff0:	8b01035a 	add	x26, x26, x1
    6ff4:	39400340 	ldrb	w0, [x26]
    6ff8:	7103fc1f 	cmp	w0, #0xff
    6ffc:	54006260 	b.eq	7c48 <f12+0xff8>  // b.none
    7000:	52800020 	mov	w0, #0x1                   	// #1
    7004:	39000340 	strb	w0, [x26]
    7008:	b4000233 	cbz	x19, 704c <f12+0x3fc>
    700c:	d3607f24 	lsl	x4, x25, #32
    7010:	aa1403e2 	mov	x2, x20
    7014:	f9400685 	ldr	x5, [x20, #8]
    7018:	aa0403e3 	mov	x3, x4
    701c:	91002360 	add	x0, x27, #0x8
    7020:	d2800001 	mov	x1, #0x0                   	// #0
    7024:	14000005 	b	7038 <f12+0x3e8>
    7028:	f9400445 	ldr	x5, [x2, #8]
    702c:	ab040023 	adds	x3, x1, x4
    7030:	91004000 	add	x0, x0, #0x10
    7034:	54006706 	b.vs	7d14 <f12+0x10c4>
    7038:	a9000c05 	stp	x5, x3, [x0]
    703c:	91000421 	add	x1, x1, #0x1
    7040:	f9400842 	ldr	x2, [x2, #16]
    7044:	eb01027f 	cmp	x19, x1
    7048:	54ffff08 	b.hi	7028 <f12+0x3d8>  // b.pmore
    704c:	f9400360 	ldr	x0, [x27]
    7050:	f100041f 	cmp	x0, #0x1
    7054:	540051e9 	b.ls	7a90 <f12+0xe40>  // b.plast
    7058:	d341fc00 	lsr	x0, x0, #1
    705c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7060:	d1000401 	sub	x1, x0, #0x1
    7064:	eb02003f 	cmp	x1, x2
    7068:	54006288 	b.hi	7cb8 <f12+0x1068>  // b.pmore
    706c:	d37ff83c 	lsl	x28, x1, #1
    7070:	b4005101 	cbz	x1, 7a90 <f12+0xe40>
    7074:	d1002361 	sub	x1, x27, #0x8
    7078:	91002373 	add	x19, x27, #0x8
    707c:	8b00103a 	add	x26, x1, x0, lsl #4
    7080:	f9400660 	ldr	x0, [x19, #8]
    7084:	f9400e61 	ldr	x1, [x19, #24]
    7088:	fd400260 	ldr	d0, [x19]
    708c:	fd400a61 	ldr	d1, [x19, #16]
    7090:	97fff99c 	bl	5700 <w107>
    7094:	a9000660 	stp	x0, x1, [x19]
    7098:	91004273 	add	x19, x19, #0x10
    709c:	eb1a027f 	cmp	x19, x26
    70a0:	54ffff01 	b.ne	7080 <f12+0x430>  // b.any
    70a4:	f900037c 	str	x28, [x27]
    70a8:	aa1b03e0 	mov	x0, x27
    70ac:	93407f33 	sxtw	x19, w25
    70b0:	97fff9d8 	bl	5810 <w164.constprop.0>
    70b4:	aa0103fa 	mov	x26, x1
    70b8:	aa1b03e0 	mov	x0, x27
    70bc:	97fffe45 	bl	69d0 <fwp_drop4>
    70c0:	aa1303e0 	mov	x0, x19
    70c4:	97fff27b 	bl	3ab0 <fwp_tape_of>
    70c8:	f9403001 	ldr	x1, [x0, #96]
    70cc:	aa0003ea 	mov	x10, x0
    70d0:	b5006121 	cbnz	x1, 7cf4 <f12+0x10a4>
    70d4:	97ffefb0 	bl	2f94 <fwp_tape_unlink_scope>
    70d8:	b9400002 	ldr	w2, [x0]
    70dc:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    70e0:	a940801c 	ldp	x28, x0, [x0, #8]
    70e4:	b900055f 	str	wzr, [x10, #4]
    70e8:	a941994b 	ldp	x11, x6, [x10, #24]
    70ec:	a942a147 	ldp	x7, x8, [x10, #40]
    70f0:	a9439549 	ldp	x9, x5, [x10, #56]
    70f4:	f940255b 	ldr	x27, [x10, #72]
    70f8:	6b01005f 	cmp	w2, w1
    70fc:	54000108 	b.hi	711c <f12+0x4cc>  // b.pmore
    7100:	910182a2 	add	x2, x21, #0x60
    7104:	92403e61 	and	x1, x19, #0xffff
    7108:	d1000421 	sub	x1, x1, #0x1
    710c:	f940b043 	ldr	x3, [x2, #352]
    7110:	eb03003f 	cmp	x1, x3
    7114:	5400004a 	b.ge	711c <f12+0x4cc>  // b.tcont
    7118:	f900b041 	str	x1, [x2, #352]
    711c:	4f000400 	movi	v0.4s, #0x0
    7120:	910182a3 	add	x3, x21, #0x60
    7124:	f9000d5f 	str	xzr, [x10, #24]
    7128:	910163e1 	add	x1, sp, #0x58
    712c:	9101c3f9 	add	x25, sp, #0x70
    7130:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    7134:	f941c86c 	ldr	x12, [x3, #912]
    7138:	3c808140 	stur	q0, [x10, #8]
    713c:	91129042 	add	x2, x2, #0x4a4
    7140:	ad010140 	stp	q0, q0, [x10, #32]
    7144:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    7148:	a9058bec 	stp	x12, x2, [sp, #88]
    714c:	a9069bf9 	stp	x25, x6, [sp, #104]
    7150:	a907a3e7 	stp	x7, x8, [sp, #120]
    7154:	a90897e9 	stp	x9, x5, [sp, #136]
    7158:	a909efeb 	stp	x11, x27, [sp, #152]
    715c:	f901c861 	str	x1, [x3, #912]
    7160:	b7f84bfa 	tbnz	x26, #63, 7adc <f12+0xe8c>
    7164:	eb9a827f 	cmp	x19, x26, asr #32
    7168:	54005961 	b.ne	7c94 <f12+0x1044>  // b.any
    716c:	92407f53 	and	x19, x26, #0xffffffff
    7170:	eb3a401f 	cmp	x0, w26, uxtw
    7174:	5400596d 	b.le	7ca0 <f12+0x1050>
    7178:	eb13039f 	cmp	x28, x19
    717c:	9a93c793 	csinc	x19, x28, x19, gt
    7180:	eb13037f 	cmp	x27, x19
    7184:	540019ea 	b.ge	74c0 <f12+0x870>  // b.tcont
    7188:	f100037f 	cmp	x27, #0x0
    718c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7190:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7194:	14000004 	b	71a4 <f12+0x554>
    7198:	eb01037f 	cmp	x27, x1
    719c:	d37ffb7b 	lsl	x27, x27, #1
    71a0:	9a93d37b 	csel	x27, x27, x19, le
    71a4:	eb13037f 	cmp	x27, x19
    71a8:	54ffff8b 	b.lt	7198 <f12+0x548>  // b.tstop
    71ac:	b4004e05 	cbz	x5, 7b6c <f12+0xf1c>
    71b0:	aa0503e0 	mov	x0, x5
    71b4:	d37df361 	lsl	x1, x27, #3
    71b8:	52800062 	mov	w2, #0x3                   	// #3
    71bc:	a9009fe6 	stp	x6, x7, [sp, #8]
    71c0:	a901a7e8 	stp	x8, x9, [sp, #24]
    71c4:	97fff484 	bl	43d4 <ad_raw_realloc>
    71c8:	aa0003e5 	mov	x5, x0
    71cc:	a9409fe6 	ldp	x6, x7, [sp, #8]
    71d0:	a941a7e8 	ldp	x8, x9, [sp, #24]
    71d4:	b4004b20 	cbz	x0, 7b38 <f12+0xee8>
    71d8:	f9004be5 	str	x5, [sp, #144]
    71dc:	f90053fb 	str	x27, [sp, #160]
    71e0:	b50015d3 	cbnz	x19, 7498 <f12+0x848>
    71e4:	b7f800da 	tbnz	x26, #63, 71fc <f12+0x5ac>
    71e8:	92407f41 	and	x1, x26, #0xffffffff
    71ec:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    71f0:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    71f4:	1e612800 	fadd	d0, d0, d1
    71f8:	fc2178a0 	str	d0, [x5, x1, lsl #3]
    71fc:	d1000673 	sub	x19, x19, #0x1
    7200:	d1000783 	sub	x3, x28, #0x1
    7204:	eb13039f 	cmp	x28, x19
    7208:	540003ac 	b.gt	727c <f12+0x62c>
    720c:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7210:	1e602008 	fcmp	d0, #0.0
    7214:	540002e0 	b.eq	7270 <f12+0x620>  // b.none
    7218:	cb1c0be0 	neg	x0, x28, lsl #2
    721c:	cb1c03e2 	neg	x2, x28
    7220:	8b0000c1 	add	x1, x6, x0
    7224:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7228:	37f80101 	tbnz	w1, #31, 7248 <f12+0x5f8>
    722c:	8b020d0a 	add	x10, x8, x2, lsl #3
    7230:	93407c21 	sxtw	x1, w1
    7234:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    7238:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    723c:	1e620802 	fmul	d2, d0, d2
    7240:	1e622821 	fadd	d1, d1, d2
    7244:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    7248:	8b0000e0 	add	x0, x7, x0
    724c:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    7250:	37f80100 	tbnz	w0, #31, 7270 <f12+0x620>
    7254:	8b020d22 	add	x2, x9, x2, lsl #3
    7258:	93407c00 	sxtw	x0, w0
    725c:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7260:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7264:	1e620800 	fmul	d0, d0, d2
    7268:	1e602820 	fadd	d0, d1, d0
    726c:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7270:	d1000673 	sub	x19, x19, #0x1
    7274:	eb13007f 	cmp	x3, x19
    7278:	54fffca1 	b.ne	720c <f12+0x5bc>  // b.any
    727c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7280:	eb00039f 	cmp	x28, x0
    7284:	54005208 	b.hi	7cc4 <f12+0x1074>  // b.pmore
    7288:	91000780 	add	x0, x28, #0x1
    728c:	52800041 	mov	w1, #0x2                   	// #2
    7290:	f90007e5 	str	x5, [sp, #8]
    7294:	d37df000 	lsl	x0, x0, #3
    7298:	97fff77e 	bl	5090 <fwp_heap_alloc>
    729c:	aa0003e2 	mov	x2, x0
    72a0:	aa0003f3 	mov	x19, x0
    72a4:	f94007e5 	ldr	x5, [sp, #8]
    72a8:	d2800001 	mov	x1, #0x0                   	// #0
    72ac:	f800845c 	str	x28, [x2], #8
    72b0:	b40000fc 	cbz	x28, 72cc <f12+0x67c>
    72b4:	d503201f 	nop
    72b8:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    72bc:	f8217840 	str	x0, [x2, x1, lsl #3]
    72c0:	91000421 	add	x1, x1, #0x1
    72c4:	eb01039f 	cmp	x28, x1
    72c8:	54ffff81 	b.ne	72b8 <f12+0x668>  // b.any
    72cc:	910182a1 	add	x1, x21, #0x60
    72d0:	aa1903e0 	mov	x0, x25
    72d4:	f9402ffa 	ldr	x26, [sp, #88]
    72d8:	f901c83a 	str	x26, [x1, #912]
    72dc:	97fff472 	bl	44a4 <fwp_tape_buffers_release>
    72e0:	911902e2 	add	x2, x23, #0x640
    72e4:	f949d841 	ldr	x1, [x2, #5040]
    72e8:	f949ec40 	ldr	x0, [x2, #5080]
    72ec:	cb010261 	sub	x1, x19, x1
    72f0:	eb00403f 	cmp	x1, x0, lsl #16
    72f4:	54000322 	b.cs	7358 <f12+0x708>  // b.hs, b.nlast
    72f8:	d350fc20 	lsr	x0, x1, #16
    72fc:	f949fc43 	ldr	x3, [x2, #5112]
    7300:	8b000800 	add	x0, x0, x0, lsl #2
    7304:	d37df002 	lsl	x2, x0, #3
    7308:	8b020060 	add	x0, x3, x2
    730c:	f9401019 	ldr	x25, [x0, #32]
    7310:	b4000259 	cbz	x25, 7358 <f12+0x708>
    7314:	38626862 	ldrb	w2, [x3, x2]
    7318:	7100085f 	cmp	w2, #0x2
    731c:	54003e40 	b.eq	7ae4 <f12+0xe94>  // b.none
    7320:	7100045f 	cmp	w2, #0x1
    7324:	540001a1 	b.ne	7358 <f12+0x708>  // b.any
    7328:	29430002 	ldp	w2, w0, [x0, #24]
    732c:	92403c21 	and	x1, x1, #0xffff
    7330:	9b027c21 	mul	x1, x1, x2
    7334:	d360fc21 	lsr	x1, x1, #32
    7338:	eb00003f 	cmp	x1, x0
    733c:	540000e2 	b.cs	7358 <f12+0x708>  // b.hs, b.nlast
    7340:	8b010339 	add	x25, x25, x1
    7344:	39400320 	ldrb	w0, [x25]
    7348:	7103fc1f 	cmp	w0, #0xff
    734c:	54004840 	b.eq	7c54 <f12+0x1004>  // b.none
    7350:	52800020 	mov	w0, #0x1                   	// #1
    7354:	39000320 	strb	w0, [x25]
    7358:	eb18035f 	cmp	x26, x24
    735c:	54004da1 	b.ne	7d10 <f12+0x10c0>  // b.any
    7360:	f94023e1 	ldr	x1, [sp, #64]
    7364:	910182b5 	add	x21, x21, #0x60
    7368:	aa1603e0 	mov	x0, x22
    736c:	f901caa1 	str	x1, [x21, #912]
    7370:	97fffc44 	bl	6480 <fwp_tape_scope_release>
    7374:	f9400260 	ldr	x0, [x19]
    7378:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    737c:	b7f83120 	tbnz	x0, #63, 79a0 <f12+0xd50>
    7380:	911902e2 	add	x2, x23, #0x640
    7384:	f949d840 	ldr	x0, [x2, #5040]
    7388:	f949ec41 	ldr	x1, [x2, #5080]
    738c:	cb000260 	sub	x0, x19, x0
    7390:	eb01401f 	cmp	x0, x1, lsl #16
    7394:	54003062 	b.cs	79a0 <f12+0xd50>  // b.hs, b.nlast
    7398:	d350fc01 	lsr	x1, x0, #16
    739c:	f949fc44 	ldr	x4, [x2, #5112]
    73a0:	8b010821 	add	x1, x1, x1, lsl #2
    73a4:	d37df021 	lsl	x1, x1, #3
    73a8:	8b010083 	add	x3, x4, x1
    73ac:	f9401062 	ldr	x2, [x3, #32]
    73b0:	b4002f82 	cbz	x2, 79a0 <f12+0xd50>
    73b4:	38616881 	ldrb	w1, [x4, x1]
    73b8:	7100083f 	cmp	w1, #0x2
    73bc:	54002ec0 	b.eq	7994 <f12+0xd44>  // b.none
    73c0:	7100043f 	cmp	w1, #0x1
    73c4:	54002ee1 	b.ne	79a0 <f12+0xd50>  // b.any
    73c8:	29430464 	ldp	w4, w1, [x3, #24]
    73cc:	92403c00 	and	x0, x0, #0xffff
    73d0:	9b047c00 	mul	x0, x0, x4
    73d4:	d360fc00 	lsr	x0, x0, #32
    73d8:	eb01001f 	cmp	x0, x1
    73dc:	54002e22 	b.cs	79a0 <f12+0xd50>  // b.hs, b.nlast
    73e0:	8b000042 	add	x2, x2, x0
    73e4:	39400040 	ldrb	w0, [x2]
    73e8:	7100041f 	cmp	w0, #0x1
    73ec:	54002da1 	b.ne	79a0 <f12+0xd50>  // b.any
    73f0:	aa1303f5 	mov	x21, x19
    73f4:	d2800000 	mov	x0, #0x0                   	// #0
    73f8:	f90007f3 	str	x19, [sp, #8]
    73fc:	f94007e1 	ldr	x1, [sp, #8]
    7400:	91002023 	add	x3, x1, #0x8
    7404:	d2800001 	mov	x1, #0x0                   	// #0
    7408:	b4000898 	cbz	x24, 7518 <f12+0x8c8>
    740c:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0x9f0>
    7410:	91002265 	add	x5, x19, #0x8
    7414:	fd42f041 	ldr	d1, [x2, #1504]
    7418:	14000009 	b	743c <f12+0x7ec>
    741c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7420:	f94002a2 	ldr	x2, [x21]
    7424:	1e600820 	fmul	d0, d1, d0
    7428:	b7f84422 	tbnz	x2, #63, 7cac <f12+0x105c>
    742c:	91000421 	add	x1, x1, #0x1
    7430:	fc008460 	str	d0, [x3], #8
    7434:	eb01031f 	cmp	x24, x1
    7438:	54000700 	b.eq	7518 <f12+0x8c8>  // b.none
    743c:	f9400264 	ldr	x4, [x19]
    7440:	aa0503e2 	mov	x2, x5
    7444:	b6fffec4 	tbz	x4, #63, 741c <f12+0x7cc>
    7448:	f9400a62 	ldr	x2, [x19, #16]
    744c:	17fffff4 	b	741c <f12+0x7cc>
    7450:	eb19037f 	cmp	x27, x25
    7454:	54ffcc40 	b.eq	6ddc <f12+0x18c>  // b.none
    7458:	910182a0 	add	x0, x21, #0x60
    745c:	8b19073b 	add	x27, x25, x25, lsl #1
    7460:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    7464:	f940441c 	ldr	x28, [x0, #136]
    7468:	90000020 	adrp	x0, b000 <__divti3+0x110>
    746c:	91284000 	add	x0, x0, #0xa10
    7470:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7474:	f900337f 	str	xzr, [x27, #96]
    7478:	97ffed4a 	bl	29a0 <getenv@plt>
    747c:	b4ffd0a0 	cbz	x0, 6e90 <f12+0x240>
    7480:	39400001 	ldrb	w1, [x0]
    7484:	7100c03f 	cmp	w1, #0x30
    7488:	54ffd041 	b.ne	6e90 <f12+0x240>  // b.any
    748c:	39400400 	ldrb	w0, [x0, #1]
    7490:	34ffd060 	cbz	w0, 6e9c <f12+0x24c>
    7494:	17fffe7f 	b	6e90 <f12+0x240>
    7498:	aa0503e0 	mov	x0, x5
    749c:	d37df262 	lsl	x2, x19, #3
    74a0:	52800001 	mov	w1, #0x0                   	// #0
    74a4:	a9009fe6 	stp	x6, x7, [sp, #8]
    74a8:	a901a7e8 	stp	x8, x9, [sp, #24]
    74ac:	97ffeccd 	bl	27e0 <memset@plt>
    74b0:	aa0003e5 	mov	x5, x0
    74b4:	a9409fe6 	ldp	x6, x7, [sp, #8]
    74b8:	a941a7e8 	ldp	x8, x9, [sp, #24]
    74bc:	17ffff4a 	b	71e4 <f12+0x594>
    74c0:	f10000bf 	cmp	x5, #0x0
    74c4:	1a9f17e0 	cset	w0, eq	// eq = none
    74c8:	f100027f 	cmp	x19, #0x0
    74cc:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    74d0:	54ffe880 	b.eq	71e0 <f12+0x590>  // b.none
    74d4:	f9402fe1 	ldr	x1, [sp, #88]
    74d8:	910182b5 	add	x21, x21, #0x60
    74dc:	aa1903e0 	mov	x0, x25
    74e0:	f901caa1 	str	x1, [x21, #912]
    74e4:	97fff3f0 	bl	44a4 <fwp_tape_buffers_release>
    74e8:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    74ec:	f947e863 	ldr	x3, [x3, #4048]
    74f0:	d2800262 	mov	x2, #0x13                  	// #19
    74f4:	d2800021 	mov	x1, #0x1                   	// #1
    74f8:	90000020 	adrp	x0, b000 <__divti3+0x110>
    74fc:	91186000 	add	x0, x0, #0x618
    7500:	f9400063 	ldr	x3, [x3]
    7504:	97ffed03 	bl	2910 <fwrite@plt>
    7508:	d2800000 	mov	x0, #0x0                   	// #0
    750c:	97ffed0d 	bl	2940 <fflush@plt>
    7510:	52800cc0 	mov	w0, #0x66                  	// #102
    7514:	97ffed1b 	bl	2980 <_Exit@plt>
    7518:	97fffd2e 	bl	69d0 <fwp_drop4>
    751c:	aa1403e1 	mov	x1, x20
    7520:	d2800002 	mov	x2, #0x0                   	// #0
    7524:	b4003774 	cbz	x20, 7c10 <f12+0xfc0>
    7528:	f9400821 	ldr	x1, [x1, #16]
    752c:	91000442 	add	x2, x2, #0x1
    7530:	b5ffffc1 	cbnz	x1, 7528 <f12+0x8d8>
    7534:	f94002a3 	ldr	x3, [x21]
    7538:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    753c:	b7f81f43 	tbnz	x3, #63, 7924 <f12+0xcd4>
    7540:	911902e1 	add	x1, x23, #0x640
    7544:	f94007e4 	ldr	x4, [sp, #8]
    7548:	f949d820 	ldr	x0, [x1, #5040]
    754c:	f949ec21 	ldr	x1, [x1, #5080]
    7550:	cb000080 	sub	x0, x4, x0
    7554:	eb01401f 	cmp	x0, x1, lsl #16
    7558:	54001e62 	b.cs	7924 <f12+0xcd4>  // b.hs, b.nlast
    755c:	911902e4 	add	x4, x23, #0x640
    7560:	d350fc01 	lsr	x1, x0, #16
    7564:	8b010821 	add	x1, x1, x1, lsl #2
    7568:	f949fc86 	ldr	x6, [x4, #5112]
    756c:	d37df021 	lsl	x1, x1, #3
    7570:	8b0100c5 	add	x5, x6, x1
    7574:	f94010a4 	ldr	x4, [x5, #32]
    7578:	b4001d44 	cbz	x4, 7920 <f12+0xcd0>
    757c:	386168c1 	ldrb	w1, [x6, x1]
    7580:	7100083f 	cmp	w1, #0x2
    7584:	54001ca0 	b.eq	7918 <f12+0xcc8>  // b.none
    7588:	7100043f 	cmp	w1, #0x1
    758c:	54001ca1 	b.ne	7920 <f12+0xcd0>  // b.any
    7590:	294304a6 	ldp	w6, w1, [x5, #24]
    7594:	92403c00 	and	x0, x0, #0xffff
    7598:	9b067c00 	mul	x0, x0, x6
    759c:	d360fc00 	lsr	x0, x0, #32
    75a0:	eb01001f 	cmp	x0, x1
    75a4:	54001be2 	b.cs	7920 <f12+0xcd0>  // b.hs, b.nlast
    75a8:	8b000084 	add	x4, x4, x0
    75ac:	39400098 	ldrb	w24, [x4]
    75b0:	7100071f 	cmp	w24, #0x1
    75b4:	54001b61 	b.ne	7920 <f12+0xcd0>  // b.any
    75b8:	b90013f8 	str	w24, [sp, #16]
    75bc:	eb1c005f 	cmp	x2, x28
    75c0:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    75c4:	910022b9 	add	x25, x21, #0x8
    75c8:	b400361c 	cbz	x28, 7c88 <f12+0x1038>
    75cc:	f94007e0 	ldr	x0, [sp, #8]
    75d0:	d37df385 	lsl	x5, x28, #3
    75d4:	aa1403e2 	mov	x2, x20
    75d8:	d2800001 	mov	x1, #0x0                   	// #0
    75dc:	91002000 	add	x0, x0, #0x8
    75e0:	1400000a 	b	7608 <f12+0x9b8>
    75e4:	fc616881 	ldr	d1, [x4, x1]
    75e8:	fd400440 	ldr	d0, [x2, #8]
    75ec:	1e613800 	fsub	d0, d0, d1
    75f0:	fc216b20 	str	d0, [x25, x1]
    75f4:	91002021 	add	x1, x1, #0x8
    75f8:	f9400842 	ldr	x2, [x2, #16]
    75fc:	eb05003f 	cmp	x1, x5
    7600:	540001c0 	b.eq	7638 <f12+0x9e8>  // b.none
    7604:	f94002a3 	ldr	x3, [x21]
    7608:	aa0003e4 	mov	x4, x0
    760c:	b6fffec3 	tbz	x3, #63, 75e4 <f12+0x994>
    7610:	f94007e3 	ldr	x3, [sp, #8]
    7614:	fd400440 	ldr	d0, [x2, #8]
    7618:	f9400864 	ldr	x4, [x3, #16]
    761c:	fc616881 	ldr	d1, [x4, x1]
    7620:	1e613800 	fsub	d0, d0, d1
    7624:	fc216b20 	str	d0, [x25, x1]
    7628:	91002021 	add	x1, x1, #0x8
    762c:	f9400842 	ldr	x2, [x2, #16]
    7630:	eb05003f 	cmp	x1, x5
    7634:	54fffe81 	b.ne	7604 <f12+0x9b4>  // b.any
    7638:	b4003254 	cbz	x20, 7c80 <f12+0x1030>
    763c:	911902e0 	add	x0, x23, #0x640
    7640:	aa1403e2 	mov	x2, x20
    7644:	d280001a 	mov	x26, #0x0                   	// #0
    7648:	f949ec06 	ldr	x6, [x0, #5080]
    764c:	f949d807 	ldr	x7, [x0, #5040]
    7650:	f949fc05 	ldr	x5, [x0, #5112]
    7654:	d370bcc6 	lsl	x6, x6, #16
    7658:	14000006 	b	7670 <f12+0xa20>
    765c:	f9400842 	ldr	x2, [x2, #16]
    7660:	9100075a 	add	x26, x26, #0x1
    7664:	f100005f 	cmp	x2, #0x0
    7668:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    766c:	54000329 	b.ls	76d0 <f12+0xa80>  // b.plast
    7670:	cb070040 	sub	x0, x2, x7
    7674:	eb06001f 	cmp	x0, x6
    7678:	540002c2 	b.cs	76d0 <f12+0xa80>  // b.hs, b.nlast
    767c:	d350fc01 	lsr	x1, x0, #16
    7680:	8b010821 	add	x1, x1, x1, lsl #2
    7684:	d37df021 	lsl	x1, x1, #3
    7688:	8b0100a4 	add	x4, x5, x1
    768c:	f9401083 	ldr	x3, [x4, #32]
    7690:	b4000203 	cbz	x3, 76d0 <f12+0xa80>
    7694:	386168a1 	ldrb	w1, [x5, x1]
    7698:	7100083f 	cmp	w1, #0x2
    769c:	54000de0 	b.eq	7858 <f12+0xc08>  // b.none
    76a0:	7100043f 	cmp	w1, #0x1
    76a4:	54000161 	b.ne	76d0 <f12+0xa80>  // b.any
    76a8:	29430488 	ldp	w8, w1, [x4, #24]
    76ac:	92403c00 	and	x0, x0, #0xffff
    76b0:	9b087c00 	mul	x0, x0, x8
    76b4:	d360fc00 	lsr	x0, x0, #32
    76b8:	eb01001f 	cmp	x0, x1
    76bc:	540000a2 	b.cs	76d0 <f12+0xa80>  // b.hs, b.nlast
    76c0:	8b000063 	add	x3, x3, x0
    76c4:	39400060 	ldrb	w0, [x3]
    76c8:	7100041f 	cmp	w0, #0x1
    76cc:	54fffc80 	b.eq	765c <f12+0xa0c>  // b.none
    76d0:	eb1a039f 	cmp	x28, x26
    76d4:	54000ca9 	b.ls	7868 <f12+0xc18>  // b.plast
    76d8:	d1002336 	sub	x22, x25, #0x8
    76dc:	9102a3f5 	add	x21, sp, #0xa8
    76e0:	911902f8 	add	x24, x23, #0x640
    76e4:	d2800013 	mov	x19, #0x0                   	// #0
    76e8:	14000012 	b	7730 <f12+0xae0>
    76ec:	7100045f 	cmp	w2, #0x1
    76f0:	540001a1 	b.ne	7724 <f12+0xad4>  // b.any
    76f4:	29430002 	ldp	w2, w0, [x0, #24]
    76f8:	92403c21 	and	x1, x1, #0xffff
    76fc:	9b027c21 	mul	x1, x1, x2
    7700:	d360fc21 	lsr	x1, x1, #32
    7704:	eb00003f 	cmp	x1, x0
    7708:	540000e2 	b.cs	7724 <f12+0xad4>  // b.hs, b.nlast
    770c:	8b01037b 	add	x27, x27, x1
    7710:	39400360 	ldrb	w0, [x27]
    7714:	7103fc1f 	cmp	w0, #0xff
    7718:	54001b20 	b.eq	7a7c <f12+0xe2c>  // b.none
    771c:	52800020 	mov	w0, #0x1                   	// #1
    7720:	39000360 	strb	w0, [x27]
    7724:	d100079c 	sub	x28, x28, #0x1
    7728:	eb1c035f 	cmp	x26, x28
    772c:	54000362 	b.cs	7798 <f12+0xb48>  // b.hs, b.nlast
    7730:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    7734:	aa1503e1 	mov	x1, x21
    7738:	52800020 	mov	w0, #0x1                   	// #1
    773c:	a90acfe2 	stp	x2, x19, [sp, #168]
    7740:	97fff85c 	bl	58b0 <fwp_data.part.0.constprop.0>
    7744:	aa0003f3 	mov	x19, x0
    7748:	f949db01 	ldr	x1, [x24, #5040]
    774c:	f949ef00 	ldr	x0, [x24, #5080]
    7750:	cb010261 	sub	x1, x19, x1
    7754:	eb00403f 	cmp	x1, x0, lsl #16
    7758:	54fffe62 	b.cs	7724 <f12+0xad4>  // b.hs, b.nlast
    775c:	d350fc22 	lsr	x2, x1, #16
    7760:	f949ff03 	ldr	x3, [x24, #5112]
    7764:	8b020842 	add	x2, x2, x2, lsl #2
    7768:	d37df042 	lsl	x2, x2, #3
    776c:	8b020060 	add	x0, x3, x2
    7770:	f940101b 	ldr	x27, [x0, #32]
    7774:	b4fffd9b 	cbz	x27, 7724 <f12+0xad4>
    7778:	38626862 	ldrb	w2, [x3, x2]
    777c:	7100085f 	cmp	w2, #0x2
    7780:	54fffb61 	b.ne	76ec <f12+0xa9c>  // b.any
    7784:	72003c3f 	tst	w1, #0xffff
    7788:	54fffc40 	b.eq	7710 <f12+0xac0>  // b.none
    778c:	d100079c 	sub	x28, x28, #0x1
    7790:	eb1c035f 	cmp	x26, x28
    7794:	54fffce3 	b.cc	7730 <f12+0xae0>  // b.lo, b.ul, b.last
    7798:	b50006ba 	cbnz	x26, 786c <f12+0xc1c>
    779c:	b94013e0 	ldr	w0, [sp, #16]
    77a0:	d2800038 	mov	x24, #0x1                   	// #1
    77a4:	d280001b 	mov	x27, #0x0                   	// #0
    77a8:	7100001f 	cmp	w0, #0x0
    77ac:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    77b0:	b40007db 	cbz	x27, 78a8 <f12+0xc58>
    77b4:	d100077b 	sub	x27, x27, #0x1
    77b8:	911902f7 	add	x23, x23, #0x640
    77bc:	d503201f 	nop
    77c0:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    77c4:	aa1503e1 	mov	x1, x21
    77c8:	52800020 	mov	w0, #0x1                   	// #1
    77cc:	a90acfe2 	stp	x2, x19, [sp, #168]
    77d0:	97fff838 	bl	58b0 <fwp_data.part.0.constprop.0>
    77d4:	aa0003f3 	mov	x19, x0
    77d8:	f949dae1 	ldr	x1, [x23, #5040]
    77dc:	f949eee0 	ldr	x0, [x23, #5080]
    77e0:	cb010261 	sub	x1, x19, x1
    77e4:	eb00403f 	cmp	x1, x0, lsl #16
    77e8:	54000302 	b.cs	7848 <f12+0xbf8>  // b.hs, b.nlast
    77ec:	d350fc22 	lsr	x2, x1, #16
    77f0:	f949fee3 	ldr	x3, [x23, #5112]
    77f4:	8b020842 	add	x2, x2, x2, lsl #2
    77f8:	d37df042 	lsl	x2, x2, #3
    77fc:	8b020060 	add	x0, x3, x2
    7800:	f940101a 	ldr	x26, [x0, #32]
    7804:	b400023a 	cbz	x26, 7848 <f12+0xbf8>
    7808:	38626862 	ldrb	w2, [x3, x2]
    780c:	7100085f 	cmp	w2, #0x2
    7810:	540007e0 	b.eq	790c <f12+0xcbc>  // b.none
    7814:	7100045f 	cmp	w2, #0x1
    7818:	54000181 	b.ne	7848 <f12+0xbf8>  // b.any
    781c:	29430002 	ldp	w2, w0, [x0, #24]
    7820:	92403c21 	and	x1, x1, #0xffff
    7824:	9b027c21 	mul	x1, x1, x2
    7828:	d360fc21 	lsr	x1, x1, #32
    782c:	eb00003f 	cmp	x1, x0
    7830:	540000c2 	b.cs	7848 <f12+0xbf8>  // b.hs, b.nlast
    7834:	8b01035a 	add	x26, x26, x1
    7838:	39400340 	ldrb	w0, [x26]
    783c:	7103fc1f 	cmp	w0, #0xff
    7840:	54000600 	b.eq	7900 <f12+0xcb0>  // b.none
    7844:	39000358 	strb	w24, [x26]
    7848:	d100077b 	sub	x27, x27, #0x1
    784c:	b100077f 	cmn	x27, #0x1
    7850:	54fffb81 	b.ne	77c0 <f12+0xb70>  // b.any
    7854:	14000015 	b	78a8 <f12+0xc58>
    7858:	72003c1f 	tst	w0, #0xffff
    785c:	54fff340 	b.eq	76c4 <f12+0xa74>  // b.none
    7860:	eb1a039f 	cmp	x28, x26
    7864:	54fff3a8 	b.hi	76d8 <f12+0xa88>  // b.pmore
    7868:	d2800013 	mov	x19, #0x0                   	// #0
    786c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    7870:	aa1903e1 	mov	x1, x25
    7874:	aa1403e0 	mov	x0, x20
    7878:	f8408422 	ldr	x2, [x1], #8
    787c:	f9000402 	str	x2, [x0, #8]
    7880:	aa0003e2 	mov	x2, x0
    7884:	f9400800 	ldr	x0, [x0, #16]
    7888:	eb01035f 	cmp	x26, x1
    788c:	54ffff61 	b.ne	7878 <f12+0xc28>  // b.any
    7890:	b94013e1 	ldr	w1, [sp, #16]
    7894:	f9000853 	str	x19, [x2, #16]
    7898:	aa1403f3 	mov	x19, x20
    789c:	aa0003f4 	mov	x20, x0
    78a0:	34000041 	cbz	w1, 78a8 <f12+0xc58>
    78a4:	d2800019 	mov	x25, #0x0                   	// #0
    78a8:	aa1903e0 	mov	x0, x25
    78ac:	97fff4d9 	bl	4c10 <fwp_mem_free>
    78b0:	f94007e0 	ldr	x0, [sp, #8]
    78b4:	97fffc47 	bl	69d0 <fwp_drop4>
    78b8:	aa1403e0 	mov	x0, x20
    78bc:	97fff95d 	bl	5e30 <fwp_drop0>
    78c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    78c4:	f947f400 	ldr	x0, [x0, #4072]
    78c8:	f9405fe2 	ldr	x2, [sp, #184]
    78cc:	f9400001 	ldr	x1, [x0]
    78d0:	eb010042 	subs	x2, x2, x1
    78d4:	d2800001 	mov	x1, #0x0                   	// #0
    78d8:	540021a1 	b.ne	7d0c <f12+0x10bc>  // b.any
    78dc:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    78e0:	aa1303e0 	mov	x0, x19
    78e4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    78e8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    78ec:	a94f63f7 	ldp	x23, x24, [sp, #240]
    78f0:	a9506bf9 	ldp	x25, x26, [sp, #256]
    78f4:	a95173fb 	ldp	x27, x28, [sp, #272]
    78f8:	910483ff 	add	sp, sp, #0x120
    78fc:	d65f03c0 	ret
    7900:	aa1a03e0 	mov	x0, x26
    7904:	97fff423 	bl	4990 <fwp_rc_forget_slot>
    7908:	17ffffcf 	b	7844 <f12+0xbf4>
    790c:	72003c3f 	tst	w1, #0xffff
    7910:	54fff9c1 	b.ne	7848 <f12+0xbf8>  // b.any
    7914:	17ffffc9 	b	7838 <f12+0xbe8>
    7918:	72003c1f 	tst	w0, #0xffff
    791c:	54ffe480 	b.eq	75ac <f12+0x95c>  // b.none
    7920:	b4001134 	cbz	x20, 7b44 <f12+0xef4>
    7924:	aa1403f3 	mov	x19, x20
    7928:	d2800018 	mov	x24, #0x0                   	// #0
    792c:	d503201f 	nop
    7930:	f9400a73 	ldr	x19, [x19, #16]
    7934:	aa1803e0 	mov	x0, x24
    7938:	91000718 	add	x24, x24, #0x1
    793c:	b5ffffb3 	cbnz	x19, 7930 <f12+0xce0>
    7940:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7944:	eb01031f 	cmp	x24, x1
    7948:	54001b88 	b.hi	7cb8 <f12+0x1068>  // b.pmore
    794c:	91000800 	add	x0, x0, #0x2
    7950:	52800041 	mov	w1, #0x2                   	// #2
    7954:	d37df000 	lsl	x0, x0, #3
    7958:	97fff5ce 	bl	5090 <fwp_heap_alloc>
    795c:	eb1c031f 	cmp	x24, x28
    7960:	aa0003f9 	mov	x25, x0
    7964:	9a9c931c 	csel	x28, x24, x28, ls	// ls = plast
    7968:	aa1403e1 	mov	x1, x20
    796c:	d503201f 	nop
    7970:	f9400420 	ldr	x0, [x1, #8]
    7974:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7978:	91000673 	add	x19, x19, #0x1
    797c:	f9400821 	ldr	x1, [x1, #16]
    7980:	b5ffff81 	cbnz	x1, 7970 <f12+0xd20>
    7984:	b4000e9c 	cbz	x28, 7b54 <f12+0xf04>
    7988:	f94002a3 	ldr	x3, [x21]
    798c:	b90013ff 	str	wzr, [sp, #16]
    7990:	17ffff0f 	b	75cc <f12+0x97c>
    7994:	72003c1f 	tst	w0, #0xffff
    7998:	54ffd260 	b.eq	73e4 <f12+0x794>  // b.none
    799c:	d503201f 	nop
    79a0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    79a4:	eb00031f 	cmp	x24, x0
    79a8:	540018e8 	b.hi	7cc4 <f12+0x1074>  // b.pmore
    79ac:	91000700 	add	x0, x24, #0x1
    79b0:	52800021 	mov	w1, #0x1                   	// #1
    79b4:	d37df000 	lsl	x0, x0, #3
    79b8:	97fff5b6 	bl	5090 <fwp_heap_alloc>
    79bc:	911902e2 	add	x2, x23, #0x640
    79c0:	f9000018 	str	x24, [x0]
    79c4:	aa0003f5 	mov	x21, x0
    79c8:	f90007f5 	str	x21, [sp, #8]
    79cc:	f949d841 	ldr	x1, [x2, #5040]
    79d0:	f949ec40 	ldr	x0, [x2, #5080]
    79d4:	cb0102a1 	sub	x1, x21, x1
    79d8:	eb00403f 	cmp	x1, x0, lsl #16
    79dc:	54000322 	b.cs	7a40 <f12+0xdf0>  // b.hs, b.nlast
    79e0:	d350fc20 	lsr	x0, x1, #16
    79e4:	f949fc43 	ldr	x3, [x2, #5112]
    79e8:	8b000800 	add	x0, x0, x0, lsl #2
    79ec:	d37df002 	lsl	x2, x0, #3
    79f0:	8b020060 	add	x0, x3, x2
    79f4:	f9401019 	ldr	x25, [x0, #32]
    79f8:	b4000259 	cbz	x25, 7a40 <f12+0xdf0>
    79fc:	38626862 	ldrb	w2, [x3, x2]
    7a00:	7100085f 	cmp	w2, #0x2
    7a04:	54000ac0 	b.eq	7b5c <f12+0xf0c>  // b.none
    7a08:	7100045f 	cmp	w2, #0x1
    7a0c:	540001a1 	b.ne	7a40 <f12+0xdf0>  // b.any
    7a10:	29430002 	ldp	w2, w0, [x0, #24]
    7a14:	92403c21 	and	x1, x1, #0xffff
    7a18:	9b027c21 	mul	x1, x1, x2
    7a1c:	d360fc21 	lsr	x1, x1, #32
    7a20:	eb00003f 	cmp	x1, x0
    7a24:	540000e2 	b.cs	7a40 <f12+0xdf0>  // b.hs, b.nlast
    7a28:	8b010339 	add	x25, x25, x1
    7a2c:	39400320 	ldrb	w0, [x25]
    7a30:	7103fc1f 	cmp	w0, #0xff
    7a34:	54001160 	b.eq	7c60 <f12+0x1010>  // b.none
    7a38:	52800020 	mov	w0, #0x1                   	// #1
    7a3c:	39000320 	strb	w0, [x25]
    7a40:	aa1303e0 	mov	x0, x19
    7a44:	17fffe6e 	b	73fc <f12+0x7ac>
    7a48:	52800041 	mov	w1, #0x2                   	// #2
    7a4c:	d2800100 	mov	x0, #0x8                   	// #8
    7a50:	97fff590 	bl	5090 <fwp_heap_alloc>
    7a54:	aa0003fb 	mov	x27, x0
    7a58:	911902e0 	add	x0, x23, #0x640
    7a5c:	f900037f 	str	xzr, [x27]
    7a60:	f949d801 	ldr	x1, [x0, #5040]
    7a64:	f949ec00 	ldr	x0, [x0, #5080]
    7a68:	cb010361 	sub	x1, x27, x1
    7a6c:	eb00403f 	cmp	x1, x0, lsl #16
    7a70:	54000102 	b.cs	7a90 <f12+0xe40>  // b.hs, b.nlast
    7a74:	d2800013 	mov	x19, #0x0                   	// #0
    7a78:	17fffd4b 	b	6fa4 <f12+0x354>
    7a7c:	aa1b03e0 	mov	x0, x27
    7a80:	97fff3c4 	bl	4990 <fwp_rc_forget_slot>
    7a84:	17ffff26 	b	771c <f12+0xacc>
    7a88:	b5ffac33 	cbnz	x19, 700c <f12+0x3bc>
    7a8c:	d503201f 	nop
    7a90:	d280001c 	mov	x28, #0x0                   	// #0
    7a94:	17fffd84 	b	70a4 <f12+0x454>
    7a98:	f0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x60>
    7a9c:	910dc000 	add	x0, x0, #0x370
    7aa0:	94000ed0 	bl	b5e0 <atexit>
    7aa4:	35ffd220 	cbnz	w0, 74e8 <f12+0x898>
    7aa8:	52800020 	mov	w0, #0x1                   	// #1
    7aac:	b903c720 	str	w0, [x25, #964]
    7ab0:	17fffcb8 	b	6d90 <f12+0x140>
    7ab4:	72003c3f 	tst	w1, #0xffff
    7ab8:	54ffaa81 	b.ne	7008 <f12+0x3b8>  // b.any
    7abc:	17fffd4e 	b	6ff4 <f12+0x3a4>
    7ac0:	72003c3f 	tst	w1, #0xffff
    7ac4:	54ff9340 	b.eq	6d2c <f12+0xdc>  // b.none
    7ac8:	aa1903e0 	mov	x0, x25
    7acc:	97fff989 	bl	60f0 <fwp_closure_drop>
    7ad0:	b5ff9474 	cbnz	x20, 6d5c <f12+0x10c>
    7ad4:	d280001a 	mov	x26, #0x0                   	// #0
    7ad8:	17fffcab 	b	6d84 <f12+0x134>
    7adc:	aa1c03f3 	mov	x19, x28
    7ae0:	17fffda8 	b	7180 <f12+0x530>
    7ae4:	72003c3f 	tst	w1, #0xffff
    7ae8:	54ffc381 	b.ne	7358 <f12+0x708>  // b.any
    7aec:	17fffe16 	b	7344 <f12+0x6f4>
    7af0:	ad470402 	ldp	q2, q1, [x0, #224]
    7af4:	91038001 	add	x1, x0, #0xe0
    7af8:	4f000400 	movi	v0.4s, #0x0
    7afc:	f9008c1f 	str	xzr, [x0, #280]
    7b00:	ad010762 	stp	q2, q1, [x27, #32]
    7b04:	a9500002 	ldp	x2, x0, [x0, #256]
    7b08:	f9000f60 	str	x0, [x27, #24]
    7b0c:	f9401820 	ldr	x0, [x1, #48]
    7b10:	f9002362 	str	x2, [x27, #64]
    7b14:	f9002760 	str	x0, [x27, #72]
    7b18:	ad000020 	stp	q0, q0, [x1]
    7b1c:	3d800820 	str	q0, [x1, #32]
    7b20:	f900183f 	str	xzr, [x1, #48]
    7b24:	17fffcde 	b	6e9c <f12+0x24c>
    7b28:	f940ac43 	ldr	x3, [x2, #344]
    7b2c:	91000463 	add	x3, x3, #0x1
    7b30:	f900ac43 	str	x3, [x2, #344]
    7b34:	17fffc83 	b	6d40 <f12+0xf0>
    7b38:	d2800005 	mov	x5, #0x0                   	// #0
    7b3c:	52800020 	mov	w0, #0x1                   	// #1
    7b40:	17fffe62 	b	74c8 <f12+0x878>
    7b44:	52800041 	mov	w1, #0x2                   	// #2
    7b48:	d2800100 	mov	x0, #0x8                   	// #8
    7b4c:	97fff551 	bl	5090 <fwp_heap_alloc>
    7b50:	aa0003f9 	mov	x25, x0
    7b54:	d2800013 	mov	x19, #0x0                   	// #0
    7b58:	17ffff54 	b	78a8 <f12+0xc58>
    7b5c:	72003c3f 	tst	w1, #0xffff
    7b60:	54fff660 	b.eq	7a2c <f12+0xddc>  // b.none
    7b64:	aa1303e0 	mov	x0, x19
    7b68:	17fffe25 	b	73fc <f12+0x7ac>
    7b6c:	d1000761 	sub	x1, x27, #0x1
    7b70:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7b74:	eb00003f 	cmp	x1, x0
    7b78:	54000ac8 	b.hi	7cd0 <f12+0x1080>  // b.pmore
    7b7c:	b00002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fba0>
    7b80:	d2800000 	mov	x0, #0x0                   	// #0
    7b84:	91118061 	add	x1, x3, #0x460
    7b88:	14000005 	b	7b9c <f12+0xf4c>
    7b8c:	91000400 	add	x0, x0, #0x1
    7b90:	91006021 	add	x1, x1, #0x18
    7b94:	f140041f 	cmp	x0, #0x1, lsl #12
    7b98:	540006e0 	b.eq	7c74 <f12+0x1024>  // b.none
    7b9c:	f9400022 	ldr	x2, [x1]
    7ba0:	b5ffff62 	cbnz	x2, 7b8c <f12+0xf3c>
    7ba4:	8b000402 	add	x2, x0, x0, lsl #1
    7ba8:	91118063 	add	x3, x3, #0x460
    7bac:	aa1b03e0 	mov	x0, x27
    7bb0:	d2800101 	mov	x1, #0x8                   	// #8
    7bb4:	8b020c62 	add	x2, x3, x2, lsl #3
    7bb8:	a9009be2 	stp	x2, x6, [sp, #8]
    7bbc:	a901a3e7 	stp	x7, x8, [sp, #24]
    7bc0:	f90017e9 	str	x9, [sp, #40]
    7bc4:	97ffeb0b 	bl	27f0 <calloc@plt>
    7bc8:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7bcc:	aa0003e5 	mov	x5, x0
    7bd0:	a94227e8 	ldp	x8, x9, [sp, #32]
    7bd4:	b4fffb20 	cbz	x0, 7b38 <f12+0xee8>
    7bd8:	aa0003e1 	mov	x1, x0
    7bdc:	d37df362 	lsl	x2, x27, #3
    7be0:	f94007e0 	ldr	x0, [sp, #8]
    7be4:	52800063 	mov	w3, #0x3                   	// #3
    7be8:	a9009be5 	stp	x5, x6, [sp, #8]
    7bec:	a901a3e7 	stp	x7, x8, [sp, #24]
    7bf0:	f90017e9 	str	x9, [sp, #40]
    7bf4:	97ffecc7 	bl	2f10 <ad_raw_record>
    7bf8:	a9409be5 	ldp	x5, x6, [sp, #8]
    7bfc:	f9004be5 	str	x5, [sp, #144]
    7c00:	a941a3e7 	ldp	x7, x8, [sp, #24]
    7c04:	f90053fb 	str	x27, [sp, #160]
    7c08:	f94017e9 	ldr	x9, [sp, #40]
    7c0c:	17fffd75 	b	71e0 <f12+0x590>
    7c10:	f94002a3 	ldr	x3, [x21]
    7c14:	b7fff983 	tbnz	x3, #63, 7b44 <f12+0xef4>
    7c18:	911902e1 	add	x1, x23, #0x640
    7c1c:	f94007e4 	ldr	x4, [sp, #8]
    7c20:	f949d820 	ldr	x0, [x1, #5040]
    7c24:	f949ec21 	ldr	x1, [x1, #5080]
    7c28:	cb000080 	sub	x0, x4, x0
    7c2c:	eb01401f 	cmp	x0, x1, lsl #16
    7c30:	54fff8a2 	b.cs	7b44 <f12+0xef4>  // b.hs, b.nlast
    7c34:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7c38:	17fffe49 	b	755c <f12+0x90c>
    7c3c:	d2800d01 	mov	x1, #0x68                  	// #104
    7c40:	d2800039 	mov	x25, #0x1                   	// #1
    7c44:	17fffc76 	b	6e1c <f12+0x1cc>
    7c48:	aa1a03e0 	mov	x0, x26
    7c4c:	97fff351 	bl	4990 <fwp_rc_forget_slot>
    7c50:	17fffcec 	b	7000 <f12+0x3b0>
    7c54:	aa1903e0 	mov	x0, x25
    7c58:	97fff34e 	bl	4990 <fwp_rc_forget_slot>
    7c5c:	17fffdbd 	b	7350 <f12+0x700>
    7c60:	aa1903e0 	mov	x0, x25
    7c64:	97fff34b 	bl	4990 <fwp_rc_forget_slot>
    7c68:	17ffff74 	b	7a38 <f12+0xde8>
    7c6c:	97fff302 	bl	4874 <fwp_rc_wide_dup>
    7c70:	17fffc38 	b	6d50 <f12+0x100>
    7c74:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7c78:	9126e000 	add	x0, x0, #0x9b8
    7c7c:	97ffeda1 	bl	3300 <ad_raw_fail>
    7c80:	d280001a 	mov	x26, #0x0                   	// #0
    7c84:	17fffe95 	b	76d8 <f12+0xa88>
    7c88:	d2800019 	mov	x25, #0x0                   	// #0
    7c8c:	d2800013 	mov	x19, #0x0                   	// #0
    7c90:	17ffff06 	b	78a8 <f12+0xc58>
    7c94:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7c98:	912c6000 	add	x0, x0, #0xb18
    7c9c:	97ffeeb9 	bl	3780 <fwp_trap>
    7ca0:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7ca4:	912ec000 	add	x0, x0, #0xbb0
    7ca8:	97ffeeb6 	bl	3780 <fwp_trap>
    7cac:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7cb0:	91334000 	add	x0, x0, #0xcd0
    7cb4:	97ffeeb3 	bl	3780 <fwp_trap>
    7cb8:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7cbc:	91324000 	add	x0, x0, #0xc90
    7cc0:	97ffeeb0 	bl	3780 <fwp_trap>
    7cc4:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7cc8:	91330000 	add	x0, x0, #0xcc0
    7ccc:	97ffeead 	bl	3780 <fwp_trap>
    7cd0:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7cd4:	91328000 	add	x0, x0, #0xca0
    7cd8:	97ffed8a 	bl	3300 <ad_raw_fail>
    7cdc:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7ce0:	91318000 	add	x0, x0, #0xc60
    7ce4:	97ffeea7 	bl	3780 <fwp_trap>
    7ce8:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7cec:	91304000 	add	x0, x0, #0xc10
    7cf0:	97ffeea4 	bl	3780 <fwp_trap>
    7cf4:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7cf8:	912d8000 	add	x0, x0, #0xb60
    7cfc:	97ffeea1 	bl	3780 <fwp_trap>
    7d00:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7d04:	9130c000 	add	x0, x0, #0xc30
    7d08:	97ffee9e 	bl	3780 <fwp_trap>
    7d0c:	97ffeac1 	bl	2810 <__stack_chk_fail@plt>
    7d10:	97ffead4 	bl	2860 <abort@plt>
    7d14:	97ffeb3b 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7d18:	d503201f 	nop
    7d1c:	d503201f 	nop

0000000000007d20 <fwp_owned_entry12>:
    7d20:	f9400000 	ldr	x0, [x0]
    7d24:	17fffbcb 	b	6c50 <f12>
    7d28:	d503201f 	nop
    7d2c:	d503201f 	nop

0000000000007d30 <e12>:
    7d30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7d34:	910003fd 	mov	x29, sp
    7d38:	f9000bf3 	str	x19, [sp, #16]
    7d3c:	f9400013 	ldr	x19, [x0]
    7d40:	aa1303e0 	mov	x0, x19
    7d44:	97fff738 	bl	5a24 <fwp_rc_share>
    7d48:	aa1303e0 	mov	x0, x19
    7d4c:	97fffbc1 	bl	6c50 <f12>
    7d50:	aa0003f3 	mov	x19, x0
    7d54:	97fff734 	bl	5a24 <fwp_rc_share>
    7d58:	aa1303e0 	mov	x0, x19
    7d5c:	f9400bf3 	ldr	x19, [sp, #16]
    7d60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7d64:	d65f03c0 	ret
    7d68:	d503201f 	nop
    7d6c:	d503201f 	nop

0000000000007d70 <fwp_drop2>:
    7d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7d74:	910003fd 	mov	x29, sp
    7d78:	a9025bf5 	stp	x21, x22, [sp, #32]
    7d7c:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    7d80:	911902d5 	add	x21, x22, #0x640
    7d84:	a90153f3 	stp	x19, x20, [sp, #16]
    7d88:	aa0003f3 	mov	x19, x0
    7d8c:	f949daa1 	ldr	x1, [x21, #5040]
    7d90:	f949eea0 	ldr	x0, [x21, #5080]
    7d94:	cb010261 	sub	x1, x19, x1
    7d98:	eb00403f 	cmp	x1, x0, lsl #16
    7d9c:	54000382 	b.cs	7e0c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7da0:	d350fc22 	lsr	x2, x1, #16
    7da4:	f949fea3 	ldr	x3, [x21, #5112]
    7da8:	8b020842 	add	x2, x2, x2, lsl #2
    7dac:	d37df042 	lsl	x2, x2, #3
    7db0:	8b020060 	add	x0, x3, x2
    7db4:	f9401014 	ldr	x20, [x0, #32]
    7db8:	b40002b4 	cbz	x20, 7e0c <fwp_drop2+0x9c>
    7dbc:	38626862 	ldrb	w2, [x3, x2]
    7dc0:	7100085f 	cmp	w2, #0x2
    7dc4:	540002c0 	b.eq	7e1c <fwp_drop2+0xac>  // b.none
    7dc8:	7100045f 	cmp	w2, #0x1
    7dcc:	54000201 	b.ne	7e0c <fwp_drop2+0x9c>  // b.any
    7dd0:	29430002 	ldp	w2, w0, [x0, #24]
    7dd4:	92403c21 	and	x1, x1, #0xffff
    7dd8:	9b027c21 	mul	x1, x1, x2
    7ddc:	d360fc21 	lsr	x1, x1, #32
    7de0:	eb00003f 	cmp	x1, x0
    7de4:	54000142 	b.cs	7e0c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7de8:	8b010294 	add	x20, x20, x1
    7dec:	39400280 	ldrb	w0, [x20]
    7df0:	340000e0 	cbz	w0, 7e0c <fwp_drop2+0x9c>
    7df4:	7100041f 	cmp	w0, #0x1
    7df8:	540001e0 	b.eq	7e34 <fwp_drop2+0xc4>  // b.none
    7dfc:	7103fc1f 	cmp	w0, #0xff
    7e00:	540007c0 	b.eq	7ef8 <fwp_drop2+0x188>  // b.none
    7e04:	51000400 	sub	w0, w0, #0x1
    7e08:	39000280 	strb	w0, [x20]
    7e0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7e10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7e14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7e18:	d65f03c0 	ret
    7e1c:	72003c3f 	tst	w1, #0xffff
    7e20:	54fffe60 	b.eq	7dec <fwp_drop2+0x7c>  // b.none
    7e24:	a94153f3 	ldp	x19, x20, [sp, #16]
    7e28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7e2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7e30:	d65f03c0 	ret
    7e34:	911902c2 	add	x2, x22, #0x640
    7e38:	f9400660 	ldr	x0, [x19, #8]
    7e3c:	f949d841 	ldr	x1, [x2, #5040]
    7e40:	f949ec42 	ldr	x2, [x2, #5080]
    7e44:	cb010001 	sub	x1, x0, x1
    7e48:	eb02403f 	cmp	x1, x2, lsl #16
    7e4c:	54000362 	b.cs	7eb8 <fwp_drop2+0x148>  // b.hs, b.nlast
    7e50:	d350fc22 	lsr	x2, x1, #16
    7e54:	8b020842 	add	x2, x2, x2, lsl #2
    7e58:	d37df042 	lsl	x2, x2, #3
    7e5c:	8b020064 	add	x4, x3, x2
    7e60:	f9401094 	ldr	x20, [x4, #32]
    7e64:	b40002b4 	cbz	x20, 7eb8 <fwp_drop2+0x148>
    7e68:	38626862 	ldrb	w2, [x3, x2]
    7e6c:	7100085f 	cmp	w2, #0x2
    7e70:	540003e0 	b.eq	7eec <fwp_drop2+0x17c>  // b.none
    7e74:	7100045f 	cmp	w2, #0x1
    7e78:	54000201 	b.ne	7eb8 <fwp_drop2+0x148>  // b.any
    7e7c:	29430883 	ldp	w3, w2, [x4, #24]
    7e80:	92403c21 	and	x1, x1, #0xffff
    7e84:	9b037c21 	mul	x1, x1, x3
    7e88:	d360fc21 	lsr	x1, x1, #32
    7e8c:	eb02003f 	cmp	x1, x2
    7e90:	54000142 	b.cs	7eb8 <fwp_drop2+0x148>  // b.hs, b.nlast
    7e94:	8b010294 	add	x20, x20, x1
    7e98:	39400281 	ldrb	w1, [x20]
    7e9c:	340000e1 	cbz	w1, 7eb8 <fwp_drop2+0x148>
    7ea0:	7100043f 	cmp	w1, #0x1
    7ea4:	54000200 	b.eq	7ee4 <fwp_drop2+0x174>  // b.none
    7ea8:	7103fc3f 	cmp	w1, #0xff
    7eac:	54000580 	b.eq	7f5c <fwp_drop2+0x1ec>  // b.none
    7eb0:	51000421 	sub	w1, w1, #0x1
    7eb4:	39000281 	strb	w1, [x20]
    7eb8:	f9400a74 	ldr	x20, [x19, #16]
    7ebc:	aa1303e0 	mov	x0, x19
    7ec0:	97fff700 	bl	5ac0 <fwp_rc_free_arr>
    7ec4:	911902c0 	add	x0, x22, #0x640
    7ec8:	f949d801 	ldr	x1, [x0, #5040]
    7ecc:	f949ec00 	ldr	x0, [x0, #5080]
    7ed0:	cb010281 	sub	x1, x20, x1
    7ed4:	eb00403f 	cmp	x1, x0, lsl #16
    7ed8:	54fff9a2 	b.cs	7e0c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7edc:	aa1403f3 	mov	x19, x20
    7ee0:	17ffffb0 	b	7da0 <fwp_drop2+0x30>
    7ee4:	97fff6f7 	bl	5ac0 <fwp_rc_free_arr>
    7ee8:	17fffff4 	b	7eb8 <fwp_drop2+0x148>
    7eec:	72003c3f 	tst	w1, #0xffff
    7ef0:	54fffe41 	b.ne	7eb8 <fwp_drop2+0x148>  // b.any
    7ef4:	17ffffe9 	b	7e98 <fwp_drop2+0x128>
    7ef8:	ca544681 	eor	x1, x20, x20, lsr #17
    7efc:	911902c0 	add	x0, x22, #0x640
    7f00:	ca412421 	eor	x1, x1, x1, lsr #9
    7f04:	8b210c01 	add	x1, x0, w1, uxtb #3
    7f08:	f94a2420 	ldr	x0, [x1, #5192]
    7f0c:	b5000080 	cbnz	x0, 7f1c <fwp_drop2+0x1ac>
    7f10:	14000010 	b	7f50 <fwp_drop2+0x1e0>
    7f14:	f9400800 	ldr	x0, [x0, #16]
    7f18:	b40001c0 	cbz	x0, 7f50 <fwp_drop2+0x1e0>
    7f1c:	f9400001 	ldr	x1, [x0]
    7f20:	eb14003f 	cmp	x1, x20
    7f24:	54ffff81 	b.ne	7f14 <fwp_drop2+0x1a4>  // b.any
    7f28:	f9400401 	ldr	x1, [x0, #8]
    7f2c:	d1000421 	sub	x1, x1, #0x1
    7f30:	f9000401 	str	x1, [x0, #8]
    7f34:	f103f83f 	cmp	x1, #0xfe
    7f38:	54fff6a1 	b.ne	7e0c <fwp_drop2+0x9c>  // b.any
    7f3c:	aa1403e0 	mov	x0, x20
    7f40:	97fff294 	bl	4990 <fwp_rc_forget_slot>
    7f44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7f48:	39000280 	strb	w0, [x20]
    7f4c:	17ffffb0 	b	7e0c <fwp_drop2+0x9c>
    7f50:	90000020 	adrp	x0, b000 <__divti3+0x110>
    7f54:	912b4000 	add	x0, x0, #0xad0
    7f58:	97ffee0a 	bl	3780 <fwp_trap>
    7f5c:	ca544680 	eor	x0, x20, x20, lsr #17
    7f60:	911902c1 	add	x1, x22, #0x640
    7f64:	ca402400 	eor	x0, x0, x0, lsr #9
    7f68:	8b200c20 	add	x0, x1, w0, uxtb #3
    7f6c:	f94a2400 	ldr	x0, [x0, #5192]
    7f70:	b5000080 	cbnz	x0, 7f80 <fwp_drop2+0x210>
    7f74:	17fffff7 	b	7f50 <fwp_drop2+0x1e0>
    7f78:	f9400800 	ldr	x0, [x0, #16]
    7f7c:	b4fffea0 	cbz	x0, 7f50 <fwp_drop2+0x1e0>
    7f80:	f9400001 	ldr	x1, [x0]
    7f84:	eb14003f 	cmp	x1, x20
    7f88:	54ffff81 	b.ne	7f78 <fwp_drop2+0x208>  // b.any
    7f8c:	f9400401 	ldr	x1, [x0, #8]
    7f90:	d1000421 	sub	x1, x1, #0x1
    7f94:	f9000401 	str	x1, [x0, #8]
    7f98:	f103f83f 	cmp	x1, #0xfe
    7f9c:	54fff8e1 	b.ne	7eb8 <fwp_drop2+0x148>  // b.any
    7fa0:	aa1403e0 	mov	x0, x20
    7fa4:	97fff27b 	bl	4990 <fwp_rc_forget_slot>
    7fa8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7fac:	39000280 	strb	w0, [x20]
    7fb0:	17ffffc2 	b	7eb8 <fwp_drop2+0x148>

0000000000007fb4 <fwp_arg_drop23>:
    7fb4:	7100003f 	cmp	w1, #0x0
    7fb8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7fbc:	54000041 	b.ne	7fc4 <fwp_arg_drop23+0x10>  // b.any
    7fc0:	d65f03c0 	ret
    7fc4:	f9400000 	ldr	x0, [x0]
    7fc8:	17ffff6a 	b	7d70 <fwp_drop2>
    7fcc:	d503201f 	nop

0000000000007fd0 <f23>:
    7fd0:	d101c3ff 	sub	sp, sp, #0x70
    7fd4:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    7fd8:	f947f421 	ldr	x1, [x1, #4072]
    7fdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    7fe0:	910083fd 	add	x29, sp, #0x20
    7fe4:	a90563f7 	stp	x23, x24, [sp, #80]
    7fe8:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    7fec:	911902e3 	add	x3, x23, #0x640
    7ff0:	a90353f3 	stp	x19, x20, [sp, #48]
    7ff4:	a9045bf5 	stp	x21, x22, [sp, #64]
    7ff8:	aa0003f6 	mov	x22, x0
    7ffc:	a9066bf9 	stp	x25, x26, [sp, #96]
    8000:	f949ec62 	ldr	x2, [x3, #5080]
    8004:	f9400024 	ldr	x4, [x1]
    8008:	f9000fe4 	str	x4, [sp, #24]
    800c:	d2800004 	mov	x4, #0x0                   	// #0
    8010:	f949d861 	ldr	x1, [x3, #5040]
    8014:	d370bc42 	lsl	x2, x2, #16
    8018:	b40016c0 	cbz	x0, 82f0 <f23+0x320>
    801c:	f9400818 	ldr	x24, [x0, #16]
    8020:	cb010301 	sub	x1, x24, x1
    8024:	eb02003f 	cmp	x1, x2
    8028:	540003e2 	b.cs	80a4 <f23+0xd4>  // b.hs, b.nlast
    802c:	f949fc60 	ldr	x0, [x3, #5112]
    8030:	d350fc22 	lsr	x2, x1, #16
    8034:	8b020842 	add	x2, x2, x2, lsl #2
    8038:	8b020c02 	add	x2, x0, x2, lsl #3
    803c:	f9401040 	ldr	x0, [x2, #32]
    8040:	b4000320 	cbz	x0, 80a4 <f23+0xd4>
    8044:	39400043 	ldrb	w3, [x2]
    8048:	7100087f 	cmp	w3, #0x2
    804c:	54001440 	b.eq	82d4 <f23+0x304>  // b.none
    8050:	7100047f 	cmp	w3, #0x1
    8054:	54000241 	b.ne	809c <f23+0xcc>  // b.any
    8058:	29430843 	ldp	w3, w2, [x2, #24]
    805c:	92403c21 	and	x1, x1, #0xffff
    8060:	9b037c21 	mul	x1, x1, x3
    8064:	d360fc21 	lsr	x1, x1, #32
    8068:	eb02003f 	cmp	x1, x2
    806c:	54000182 	b.cs	809c <f23+0xcc>  // b.hs, b.nlast
    8070:	8b010000 	add	x0, x0, x1
    8074:	39400001 	ldrb	w1, [x0]
    8078:	34000121 	cbz	w1, 809c <f23+0xcc>
    807c:	900000c2 	adrp	x2, 20000 <__data_start>
    8080:	91018042 	add	x2, x2, #0x60
    8084:	b9413043 	ldr	w3, [x2, #304]
    8088:	350012c3 	cbnz	w3, 82e0 <f23+0x310>
    808c:	7103f43f 	cmp	w1, #0xfd
    8090:	54001728 	b.hi	8374 <f23+0x3a4>  // b.pmore
    8094:	11000421 	add	w1, w1, #0x1
    8098:	39000001 	strb	w1, [x0]
    809c:	d2800000 	mov	x0, #0x0                   	// #0
    80a0:	b40000f6 	cbz	x22, 80bc <f23+0xec>
    80a4:	aa1603e1 	mov	x1, x22
    80a8:	d2800000 	mov	x0, #0x0                   	// #0
    80ac:	d503201f 	nop
    80b0:	f9400821 	ldr	x1, [x1, #16]
    80b4:	91000400 	add	x0, x0, #0x1
    80b8:	b5ffffc1 	cbnz	x1, 80b0 <f23+0xe0>
    80bc:	b4001238 	cbz	x24, 8300 <f23+0x330>
    80c0:	aa1803e1 	mov	x1, x24
    80c4:	d2800002 	mov	x2, #0x0                   	// #0
    80c8:	f9400821 	ldr	x1, [x1, #16]
    80cc:	91000442 	add	x2, x2, #0x1
    80d0:	b5ffffc1 	cbnz	x1, 80c8 <f23+0xf8>
    80d4:	eb00005f 	cmp	x2, x0
    80d8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    80dc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    80e0:	eb01033f 	cmp	x25, x1
    80e4:	540014e8 	b.hi	8380 <f23+0x3b0>  // b.pmore
    80e8:	d37ffb33 	lsl	x19, x25, #1
    80ec:	52800041 	mov	w1, #0x2                   	// #2
    80f0:	91000660 	add	x0, x19, #0x1
    80f4:	d37df000 	lsl	x0, x0, #3
    80f8:	97fff3e6 	bl	5090 <fwp_heap_alloc>
    80fc:	911902e1 	add	x1, x23, #0x640
    8100:	aa0003fa 	mov	x26, x0
    8104:	f9000013 	str	x19, [x0]
    8108:	aa0103e0 	mov	x0, x1
    810c:	f949d821 	ldr	x1, [x1, #5040]
    8110:	f949ec00 	ldr	x0, [x0, #5080]
    8114:	cb010341 	sub	x1, x26, x1
    8118:	eb00403f 	cmp	x1, x0, lsl #16
    811c:	54000342 	b.cs	8184 <f23+0x1b4>  // b.hs, b.nlast
    8120:	911902e2 	add	x2, x23, #0x640
    8124:	d350fc20 	lsr	x0, x1, #16
    8128:	8b000800 	add	x0, x0, x0, lsl #2
    812c:	f949fc43 	ldr	x3, [x2, #5112]
    8130:	d37df002 	lsl	x2, x0, #3
    8134:	8b020060 	add	x0, x3, x2
    8138:	f9401013 	ldr	x19, [x0, #32]
    813c:	b4000253 	cbz	x19, 8184 <f23+0x1b4>
    8140:	38626862 	ldrb	w2, [x3, x2]
    8144:	7100085f 	cmp	w2, #0x2
    8148:	54000c00 	b.eq	82c8 <f23+0x2f8>  // b.none
    814c:	7100045f 	cmp	w2, #0x1
    8150:	540001a1 	b.ne	8184 <f23+0x1b4>  // b.any
    8154:	29430002 	ldp	w2, w0, [x0, #24]
    8158:	92403c21 	and	x1, x1, #0xffff
    815c:	9b027c21 	mul	x1, x1, x2
    8160:	d360fc21 	lsr	x1, x1, #32
    8164:	eb00003f 	cmp	x1, x0
    8168:	540000e2 	b.cs	8184 <f23+0x1b4>  // b.hs, b.nlast
    816c:	8b010273 	add	x19, x19, x1
    8170:	39400260 	ldrb	w0, [x19]
    8174:	7103fc1f 	cmp	w0, #0xff
    8178:	54000e80 	b.eq	8348 <f23+0x378>  // b.none
    817c:	52800020 	mov	w0, #0x1                   	// #1
    8180:	39000260 	strb	w0, [x19]
    8184:	b4000259 	cbz	x25, 81cc <f23+0x1fc>
    8188:	8b191359 	add	x25, x26, x25, lsl #4
    818c:	aa1a03f3 	mov	x19, x26
    8190:	aa1603f5 	mov	x21, x22
    8194:	aa1803f4 	mov	x20, x24
    8198:	f9400683 	ldr	x3, [x20, #8]
    819c:	f94006a2 	ldr	x2, [x21, #8]
    81a0:	f9400861 	ldr	x1, [x3, #16]
    81a4:	f9400840 	ldr	x0, [x2, #16]
    81a8:	fd400461 	ldr	d1, [x3, #8]
    81ac:	fd400440 	ldr	d0, [x2, #8]
    81b0:	97fff554 	bl	5700 <w107>
    81b4:	f9000660 	str	x0, [x19, #8]
    81b8:	f8010e61 	str	x1, [x19, #16]!
    81bc:	f9400a94 	ldr	x20, [x20, #16]
    81c0:	f9400ab5 	ldr	x21, [x21, #16]
    81c4:	eb13033f 	cmp	x25, x19
    81c8:	54fffe81 	b.ne	8198 <f23+0x1c8>  // b.any
    81cc:	aa1803e0 	mov	x0, x24
    81d0:	97fffee8 	bl	7d70 <fwp_drop2>
    81d4:	aa1603e0 	mov	x0, x22
    81d8:	97fffee6 	bl	7d70 <fwp_drop2>
    81dc:	911902f7 	add	x23, x23, #0x640
    81e0:	aa1a03e0 	mov	x0, x26
    81e4:	97fff58b 	bl	5810 <w164.constprop.0>
    81e8:	aa0103f3 	mov	x19, x1
    81ec:	aa0003f4 	mov	x20, x0
    81f0:	aa1a03e0 	mov	x0, x26
    81f4:	97fff9f7 	bl	69d0 <fwp_drop4>
    81f8:	a900cff4 	stp	x20, x19, [sp, #8]
    81fc:	910023e1 	add	x1, sp, #0x8
    8200:	52800000 	mov	w0, #0x0                   	// #0
    8204:	97fff5ab 	bl	58b0 <fwp_data.part.0.constprop.0>
    8208:	f949dae1 	ldr	x1, [x23, #5040]
    820c:	aa0003f3 	mov	x19, x0
    8210:	f949eee0 	ldr	x0, [x23, #5080]
    8214:	cb010261 	sub	x1, x19, x1
    8218:	eb00403f 	cmp	x1, x0, lsl #16
    821c:	54000322 	b.cs	8280 <f23+0x2b0>  // b.hs, b.nlast
    8220:	d350fc22 	lsr	x2, x1, #16
    8224:	f949fee3 	ldr	x3, [x23, #5112]
    8228:	8b020842 	add	x2, x2, x2, lsl #2
    822c:	d37df042 	lsl	x2, x2, #3
    8230:	8b020060 	add	x0, x3, x2
    8234:	f9401014 	ldr	x20, [x0, #32]
    8238:	b4000254 	cbz	x20, 8280 <f23+0x2b0>
    823c:	38626862 	ldrb	w2, [x3, x2]
    8240:	7100085f 	cmp	w2, #0x2
    8244:	540003c0 	b.eq	82bc <f23+0x2ec>  // b.none
    8248:	7100045f 	cmp	w2, #0x1
    824c:	540001a1 	b.ne	8280 <f23+0x2b0>  // b.any
    8250:	29430002 	ldp	w2, w0, [x0, #24]
    8254:	92403c21 	and	x1, x1, #0xffff
    8258:	9b027c21 	mul	x1, x1, x2
    825c:	d360fc21 	lsr	x1, x1, #32
    8260:	eb00003f 	cmp	x1, x0
    8264:	540000e2 	b.cs	8280 <f23+0x2b0>  // b.hs, b.nlast
    8268:	8b010294 	add	x20, x20, x1
    826c:	39400280 	ldrb	w0, [x20]
    8270:	7103fc1f 	cmp	w0, #0xff
    8274:	54000640 	b.eq	833c <f23+0x36c>  // b.none
    8278:	52800020 	mov	w0, #0x1                   	// #1
    827c:	39000280 	strb	w0, [x20]
    8280:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8284:	f947f400 	ldr	x0, [x0, #4072]
    8288:	f9400fe2 	ldr	x2, [sp, #24]
    828c:	f9400001 	ldr	x1, [x0]
    8290:	eb010042 	subs	x2, x2, x1
    8294:	d2800001 	mov	x1, #0x0                   	// #0
    8298:	54000721 	b.ne	837c <f23+0x3ac>  // b.any
    829c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    82a0:	aa1303e0 	mov	x0, x19
    82a4:	a94353f3 	ldp	x19, x20, [sp, #48]
    82a8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    82ac:	a94563f7 	ldp	x23, x24, [sp, #80]
    82b0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    82b4:	9101c3ff 	add	sp, sp, #0x70
    82b8:	d65f03c0 	ret
    82bc:	72003c3f 	tst	w1, #0xffff
    82c0:	54fffe01 	b.ne	8280 <f23+0x2b0>  // b.any
    82c4:	17ffffea 	b	826c <f23+0x29c>
    82c8:	72003c3f 	tst	w1, #0xffff
    82cc:	54fff5c1 	b.ne	8184 <f23+0x1b4>  // b.any
    82d0:	17ffffa8 	b	8170 <f23+0x1a0>
    82d4:	72003c3f 	tst	w1, #0xffff
    82d8:	54ffee21 	b.ne	809c <f23+0xcc>  // b.any
    82dc:	17ffff66 	b	8074 <f23+0xa4>
    82e0:	f940ac43 	ldr	x3, [x2, #344]
    82e4:	91000463 	add	x3, x3, #0x1
    82e8:	f900ac43 	str	x3, [x2, #344]
    82ec:	17ffff68 	b	808c <f23+0xbc>
    82f0:	cb0103e1 	neg	x1, x1
    82f4:	eb02003f 	cmp	x1, x2
    82f8:	540002e3 	b.cc	8354 <f23+0x384>  // b.lo, b.ul, b.last
    82fc:	d503201f 	nop
    8300:	52800041 	mov	w1, #0x2                   	// #2
    8304:	d2800100 	mov	x0, #0x8                   	// #8
    8308:	97fff362 	bl	5090 <fwp_heap_alloc>
    830c:	aa0003e1 	mov	x1, x0
    8310:	911902e0 	add	x0, x23, #0x640
    8314:	aa0103fa 	mov	x26, x1
    8318:	d2800018 	mov	x24, #0x0                   	// #0
    831c:	f900003f 	str	xzr, [x1]
    8320:	f949d801 	ldr	x1, [x0, #5040]
    8324:	f949ec00 	ldr	x0, [x0, #5080]
    8328:	cb010341 	sub	x1, x26, x1
    832c:	eb00403f 	cmp	x1, x0, lsl #16
    8330:	54fff4e2 	b.cs	81cc <f23+0x1fc>  // b.hs, b.nlast
    8334:	d2800019 	mov	x25, #0x0                   	// #0
    8338:	17ffff7a 	b	8120 <f23+0x150>
    833c:	aa1403e0 	mov	x0, x20
    8340:	97fff194 	bl	4990 <fwp_rc_forget_slot>
    8344:	17ffffcd 	b	8278 <f23+0x2a8>
    8348:	aa1303e0 	mov	x0, x19
    834c:	97fff191 	bl	4990 <fwp_rc_forget_slot>
    8350:	17ffff8b 	b	817c <f23+0x1ac>
    8354:	f949fc62 	ldr	x2, [x3, #5112]
    8358:	d350fc20 	lsr	x0, x1, #16
    835c:	8b000800 	add	x0, x0, x0, lsl #2
    8360:	8b000c42 	add	x2, x2, x0, lsl #3
    8364:	f9401040 	ldr	x0, [x2, #32]
    8368:	b4fffcc0 	cbz	x0, 8300 <f23+0x330>
    836c:	d2800018 	mov	x24, #0x0                   	// #0
    8370:	17ffff35 	b	8044 <f23+0x74>
    8374:	97fff140 	bl	4874 <fwp_rc_wide_dup>
    8378:	17ffff49 	b	809c <f23+0xcc>
    837c:	97ffe925 	bl	2810 <__stack_chk_fail@plt>
    8380:	f0000000 	adrp	x0, b000 <__divti3+0x110>
    8384:	91324000 	add	x0, x0, #0xc90
    8388:	97ffecfe 	bl	3780 <fwp_trap>
    838c:	d503201f 	nop

0000000000008390 <fwp_owned_entry23>:
    8390:	f9400000 	ldr	x0, [x0]
    8394:	17ffff0f 	b	7fd0 <f23>
    8398:	d503201f 	nop
    839c:	d503201f 	nop

00000000000083a0 <e23>:
    83a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    83a4:	910003fd 	mov	x29, sp
    83a8:	f9000bf3 	str	x19, [sp, #16]
    83ac:	f9400013 	ldr	x19, [x0]
    83b0:	aa1303e0 	mov	x0, x19
    83b4:	97fff59c 	bl	5a24 <fwp_rc_share>
    83b8:	aa1303e0 	mov	x0, x19
    83bc:	97ffff05 	bl	7fd0 <f23>
    83c0:	aa0003f3 	mov	x19, x0
    83c4:	97fff598 	bl	5a24 <fwp_rc_share>
    83c8:	aa1303e0 	mov	x0, x19
    83cc:	f9400bf3 	ldr	x19, [sp, #16]
    83d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83d4:	d65f03c0 	ret
    83d8:	d503201f 	nop
    83dc:	d503201f 	nop

00000000000083e0 <fwp_args23>:
    83e0:	7100003f 	cmp	w1, #0x0
    83e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    83e8:	54000041 	b.ne	83f0 <fwp_args23+0x10>  // b.any
    83ec:	d65f03c0 	ret
    83f0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    83f4:	91190042 	add	x2, x2, #0x640
    83f8:	f9400001 	ldr	x1, [x0]
    83fc:	f949d843 	ldr	x3, [x2, #5040]
    8400:	f949ec40 	ldr	x0, [x2, #5080]
    8404:	cb030021 	sub	x1, x1, x3
    8408:	eb00403f 	cmp	x1, x0, lsl #16
    840c:	54ffff02 	b.cs	83ec <fwp_args23+0xc>  // b.hs, b.nlast
    8410:	d350fc20 	lsr	x0, x1, #16
    8414:	f949fc44 	ldr	x4, [x2, #5112]
    8418:	8b000800 	add	x0, x0, x0, lsl #2
    841c:	d37df002 	lsl	x2, x0, #3
    8420:	8b020083 	add	x3, x4, x2
    8424:	f9401060 	ldr	x0, [x3, #32]
    8428:	b4fffe20 	cbz	x0, 83ec <fwp_args23+0xc>
    842c:	38626882 	ldrb	w2, [x4, x2]
    8430:	7100085f 	cmp	w2, #0x2
    8434:	54000320 	b.eq	8498 <fwp_args23+0xb8>  // b.none
    8438:	7100045f 	cmp	w2, #0x1
    843c:	54fffd81 	b.ne	83ec <fwp_args23+0xc>  // b.any
    8440:	29430864 	ldp	w4, w2, [x3, #24]
    8444:	92403c21 	and	x1, x1, #0xffff
    8448:	9b047c21 	mul	x1, x1, x4
    844c:	d360fc21 	lsr	x1, x1, #32
    8450:	eb02003f 	cmp	x1, x2
    8454:	54fffcc2 	b.cs	83ec <fwp_args23+0xc>  // b.hs, b.nlast
    8458:	8b010000 	add	x0, x0, x1
    845c:	39400001 	ldrb	w1, [x0]
    8460:	34fffc61 	cbz	w1, 83ec <fwp_args23+0xc>
    8464:	900000c2 	adrp	x2, 20000 <__data_start>
    8468:	91018042 	add	x2, x2, #0x60
    846c:	b9413043 	ldr	w3, [x2, #304]
    8470:	350000c3 	cbnz	w3, 8488 <fwp_args23+0xa8>
    8474:	7103f43f 	cmp	w1, #0xfd
    8478:	54000168 	b.hi	84a4 <fwp_args23+0xc4>  // b.pmore
    847c:	11000421 	add	w1, w1, #0x1
    8480:	39000001 	strb	w1, [x0]
    8484:	d65f03c0 	ret
    8488:	f940ac43 	ldr	x3, [x2, #344]
    848c:	91000463 	add	x3, x3, #0x1
    8490:	f900ac43 	str	x3, [x2, #344]
    8494:	17fffff8 	b	8474 <fwp_args23+0x94>
    8498:	72003c3f 	tst	w1, #0xffff
    849c:	54fffe00 	b.eq	845c <fwp_args23+0x7c>  // b.none
    84a0:	d65f03c0 	ret
    84a4:	17fff0f4 	b	4874 <fwp_rc_wide_dup>
    84a8:	d503201f 	nop
    84ac:	d503201f 	nop

00000000000084b0 <fwp_args12>:
    84b0:	7100003f 	cmp	w1, #0x0
    84b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    84b8:	54000041 	b.ne	84c0 <fwp_args12+0x10>  // b.any
    84bc:	d65f03c0 	ret
    84c0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    84c4:	91190042 	add	x2, x2, #0x640
    84c8:	f9400001 	ldr	x1, [x0]
    84cc:	f949d843 	ldr	x3, [x2, #5040]
    84d0:	f949ec40 	ldr	x0, [x2, #5080]
    84d4:	cb030021 	sub	x1, x1, x3
    84d8:	eb00403f 	cmp	x1, x0, lsl #16
    84dc:	54ffff02 	b.cs	84bc <fwp_args12+0xc>  // b.hs, b.nlast
    84e0:	d350fc20 	lsr	x0, x1, #16
    84e4:	f949fc44 	ldr	x4, [x2, #5112]
    84e8:	8b000800 	add	x0, x0, x0, lsl #2
    84ec:	d37df002 	lsl	x2, x0, #3
    84f0:	8b020083 	add	x3, x4, x2
    84f4:	f9401060 	ldr	x0, [x3, #32]
    84f8:	b4fffe20 	cbz	x0, 84bc <fwp_args12+0xc>
    84fc:	38626882 	ldrb	w2, [x4, x2]
    8500:	7100085f 	cmp	w2, #0x2
    8504:	54000320 	b.eq	8568 <fwp_args12+0xb8>  // b.none
    8508:	7100045f 	cmp	w2, #0x1
    850c:	54fffd81 	b.ne	84bc <fwp_args12+0xc>  // b.any
    8510:	29430864 	ldp	w4, w2, [x3, #24]
    8514:	92403c21 	and	x1, x1, #0xffff
    8518:	9b047c21 	mul	x1, x1, x4
    851c:	d360fc21 	lsr	x1, x1, #32
    8520:	eb02003f 	cmp	x1, x2
    8524:	54fffcc2 	b.cs	84bc <fwp_args12+0xc>  // b.hs, b.nlast
    8528:	8b010000 	add	x0, x0, x1
    852c:	39400001 	ldrb	w1, [x0]
    8530:	34fffc61 	cbz	w1, 84bc <fwp_args12+0xc>
    8534:	900000c2 	adrp	x2, 20000 <__data_start>
    8538:	91018042 	add	x2, x2, #0x60
    853c:	b9413043 	ldr	w3, [x2, #304]
    8540:	350000c3 	cbnz	w3, 8558 <fwp_args12+0xa8>
    8544:	7103f43f 	cmp	w1, #0xfd
    8548:	54000168 	b.hi	8574 <fwp_args12+0xc4>  // b.pmore
    854c:	11000421 	add	w1, w1, #0x1
    8550:	39000001 	strb	w1, [x0]
    8554:	d65f03c0 	ret
    8558:	f940ac43 	ldr	x3, [x2, #344]
    855c:	91000463 	add	x3, x3, #0x1
    8560:	f900ac43 	str	x3, [x2, #344]
    8564:	17fffff8 	b	8544 <fwp_args12+0x94>
    8568:	72003c3f 	tst	w1, #0xffff
    856c:	54fffe00 	b.eq	852c <fwp_args12+0x7c>  // b.none
    8570:	d65f03c0 	ret
    8574:	17fff0c0 	b	4874 <fwp_rc_wide_dup>
    8578:	d503201f 	nop
    857c:	d503201f 	nop

0000000000008580 <fwp_caps12>:
    8580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8584:	910003fd 	mov	x29, sp
    8588:	f9000bf3 	str	x19, [sp, #16]
    858c:	aa0003f3 	mov	x19, x0
    8590:	b9400400 	ldr	w0, [x0, #4]
    8594:	340004a0 	cbz	w0, 8628 <fwp_caps12+0xa8>
    8598:	f9400660 	ldr	x0, [x19, #8]
    859c:	350004e1 	cbnz	w1, 8638 <fwp_caps12+0xb8>
    85a0:	97fff624 	bl	5e30 <fwp_drop0>
    85a4:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    85a8:	91190042 	add	x2, x2, #0x640
    85ac:	f949d840 	ldr	x0, [x2, #5040]
    85b0:	f949ec41 	ldr	x1, [x2, #5080]
    85b4:	cb000260 	sub	x0, x19, x0
    85b8:	eb01401f 	cmp	x0, x1, lsl #16
    85bc:	54000382 	b.cs	862c <fwp_caps12+0xac>  // b.hs, b.nlast
    85c0:	d350fc01 	lsr	x1, x0, #16
    85c4:	f949fc44 	ldr	x4, [x2, #5112]
    85c8:	8b010821 	add	x1, x1, x1, lsl #2
    85cc:	d37df021 	lsl	x1, x1, #3
    85d0:	8b010083 	add	x3, x4, x1
    85d4:	f9401062 	ldr	x2, [x3, #32]
    85d8:	b40002a2 	cbz	x2, 862c <fwp_caps12+0xac>
    85dc:	38616881 	ldrb	w1, [x4, x1]
    85e0:	7100083f 	cmp	w1, #0x2
    85e4:	54000740 	b.eq	86cc <fwp_caps12+0x14c>  // b.none
    85e8:	7100043f 	cmp	w1, #0x1
    85ec:	54000201 	b.ne	862c <fwp_caps12+0xac>  // b.any
    85f0:	29430464 	ldp	w4, w1, [x3, #24]
    85f4:	92403c00 	and	x0, x0, #0xffff
    85f8:	9b047c00 	mul	x0, x0, x4
    85fc:	d360fc00 	lsr	x0, x0, #32
    8600:	eb01001f 	cmp	x0, x1
    8604:	54000142 	b.cs	862c <fwp_caps12+0xac>  // b.hs, b.nlast
    8608:	8b000042 	add	x2, x2, x0
    860c:	39400040 	ldrb	w0, [x2]
    8610:	7100041f 	cmp	w0, #0x1
    8614:	540000c1 	b.ne	862c <fwp_caps12+0xac>  // b.any
    8618:	aa1303e0 	mov	x0, x19
    861c:	f9400bf3 	ldr	x19, [sp, #16]
    8620:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8624:	17fff17b 	b	4c10 <fwp_mem_free>
    8628:	34fffbe1 	cbz	w1, 85a4 <fwp_caps12+0x24>
    862c:	f9400bf3 	ldr	x19, [sp, #16]
    8630:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8634:	d65f03c0 	ret
    8638:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    863c:	91190042 	add	x2, x2, #0x640
    8640:	f949d843 	ldr	x3, [x2, #5040]
    8644:	f949ec41 	ldr	x1, [x2, #5080]
    8648:	cb030000 	sub	x0, x0, x3
    864c:	eb01401f 	cmp	x0, x1, lsl #16
    8650:	54fffee2 	b.cs	862c <fwp_caps12+0xac>  // b.hs, b.nlast
    8654:	d350fc01 	lsr	x1, x0, #16
    8658:	f949fc44 	ldr	x4, [x2, #5112]
    865c:	8b010821 	add	x1, x1, x1, lsl #2
    8660:	d37df021 	lsl	x1, x1, #3
    8664:	8b010083 	add	x3, x4, x1
    8668:	f9401062 	ldr	x2, [x3, #32]
    866c:	b4fffe02 	cbz	x2, 862c <fwp_caps12+0xac>
    8670:	38616881 	ldrb	w1, [x4, x1]
    8674:	7100083f 	cmp	w1, #0x2
    8678:	54000300 	b.eq	86d8 <fwp_caps12+0x158>  // b.none
    867c:	7100043f 	cmp	w1, #0x1
    8680:	54fffd61 	b.ne	862c <fwp_caps12+0xac>  // b.any
    8684:	92403c01 	and	x1, x0, #0xffff
    8688:	29430064 	ldp	w4, w0, [x3, #24]
    868c:	9b047c21 	mul	x1, x1, x4
    8690:	d360fc21 	lsr	x1, x1, #32
    8694:	eb00003f 	cmp	x1, x0
    8698:	54fffca2 	b.cs	862c <fwp_caps12+0xac>  // b.hs, b.nlast
    869c:	8b010042 	add	x2, x2, x1
    86a0:	39400040 	ldrb	w0, [x2]
    86a4:	34fffc40 	cbz	w0, 862c <fwp_caps12+0xac>
    86a8:	900000c1 	adrp	x1, 20000 <__data_start>
    86ac:	91018021 	add	x1, x1, #0x60
    86b0:	b9413023 	ldr	w3, [x1, #304]
    86b4:	35000183 	cbnz	w3, 86e4 <fwp_caps12+0x164>
    86b8:	7103f41f 	cmp	w0, #0xfd
    86bc:	540001c8 	b.hi	86f4 <fwp_caps12+0x174>  // b.pmore
    86c0:	11000400 	add	w0, w0, #0x1
    86c4:	39000040 	strb	w0, [x2]
    86c8:	17ffffd9 	b	862c <fwp_caps12+0xac>
    86cc:	72003c1f 	tst	w0, #0xffff
    86d0:	54fffae1 	b.ne	862c <fwp_caps12+0xac>  // b.any
    86d4:	17ffffce 	b	860c <fwp_caps12+0x8c>
    86d8:	72003c1f 	tst	w0, #0xffff
    86dc:	54fffa81 	b.ne	862c <fwp_caps12+0xac>  // b.any
    86e0:	17fffff0 	b	86a0 <fwp_caps12+0x120>
    86e4:	f940ac23 	ldr	x3, [x1, #344]
    86e8:	91000463 	add	x3, x3, #0x1
    86ec:	f900ac23 	str	x3, [x1, #344]
    86f0:	17fffff2 	b	86b8 <fwp_caps12+0x138>
    86f4:	f9400bf3 	ldr	x19, [sp, #16]
    86f8:	aa0203e0 	mov	x0, x2
    86fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8700:	17fff05d 	b	4874 <fwp_rc_wide_dup>

0000000000008704 <fwp_caps23>:
    8704:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8708:	910003fd 	mov	x29, sp
    870c:	f9000bf3 	str	x19, [sp, #16]
    8710:	aa0003f3 	mov	x19, x0
    8714:	b9400400 	ldr	w0, [x0, #4]
    8718:	340004a0 	cbz	w0, 87ac <fwp_caps23+0xa8>
    871c:	f9400660 	ldr	x0, [x19, #8]
    8720:	350004e1 	cbnz	w1, 87bc <fwp_caps23+0xb8>
    8724:	97fffd93 	bl	7d70 <fwp_drop2>
    8728:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    872c:	91190042 	add	x2, x2, #0x640
    8730:	f949d840 	ldr	x0, [x2, #5040]
    8734:	f949ec41 	ldr	x1, [x2, #5080]
    8738:	cb000260 	sub	x0, x19, x0
    873c:	eb01401f 	cmp	x0, x1, lsl #16
    8740:	54000382 	b.cs	87b0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8744:	d350fc01 	lsr	x1, x0, #16
    8748:	f949fc44 	ldr	x4, [x2, #5112]
    874c:	8b010821 	add	x1, x1, x1, lsl #2
    8750:	d37df021 	lsl	x1, x1, #3
    8754:	8b010083 	add	x3, x4, x1
    8758:	f9401062 	ldr	x2, [x3, #32]
    875c:	b40002a2 	cbz	x2, 87b0 <fwp_caps23+0xac>
    8760:	38616881 	ldrb	w1, [x4, x1]
    8764:	7100083f 	cmp	w1, #0x2
    8768:	54000740 	b.eq	8850 <fwp_caps23+0x14c>  // b.none
    876c:	7100043f 	cmp	w1, #0x1
    8770:	54000201 	b.ne	87b0 <fwp_caps23+0xac>  // b.any
    8774:	29430464 	ldp	w4, w1, [x3, #24]
    8778:	92403c00 	and	x0, x0, #0xffff
    877c:	9b047c00 	mul	x0, x0, x4
    8780:	d360fc00 	lsr	x0, x0, #32
    8784:	eb01001f 	cmp	x0, x1
    8788:	54000142 	b.cs	87b0 <fwp_caps23+0xac>  // b.hs, b.nlast
    878c:	8b000042 	add	x2, x2, x0
    8790:	39400040 	ldrb	w0, [x2]
    8794:	7100041f 	cmp	w0, #0x1
    8798:	540000c1 	b.ne	87b0 <fwp_caps23+0xac>  // b.any
    879c:	aa1303e0 	mov	x0, x19
    87a0:	f9400bf3 	ldr	x19, [sp, #16]
    87a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    87a8:	17fff11a 	b	4c10 <fwp_mem_free>
    87ac:	34fffbe1 	cbz	w1, 8728 <fwp_caps23+0x24>
    87b0:	f9400bf3 	ldr	x19, [sp, #16]
    87b4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    87b8:	d65f03c0 	ret
    87bc:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    87c0:	91190042 	add	x2, x2, #0x640
    87c4:	f949d843 	ldr	x3, [x2, #5040]
    87c8:	f949ec41 	ldr	x1, [x2, #5080]
    87cc:	cb030000 	sub	x0, x0, x3
    87d0:	eb01401f 	cmp	x0, x1, lsl #16
    87d4:	54fffee2 	b.cs	87b0 <fwp_caps23+0xac>  // b.hs, b.nlast
    87d8:	d350fc01 	lsr	x1, x0, #16
    87dc:	f949fc44 	ldr	x4, [x2, #5112]
    87e0:	8b010821 	add	x1, x1, x1, lsl #2
    87e4:	d37df021 	lsl	x1, x1, #3
    87e8:	8b010083 	add	x3, x4, x1
    87ec:	f9401062 	ldr	x2, [x3, #32]
    87f0:	b4fffe02 	cbz	x2, 87b0 <fwp_caps23+0xac>
    87f4:	38616881 	ldrb	w1, [x4, x1]
    87f8:	7100083f 	cmp	w1, #0x2
    87fc:	54000300 	b.eq	885c <fwp_caps23+0x158>  // b.none
    8800:	7100043f 	cmp	w1, #0x1
    8804:	54fffd61 	b.ne	87b0 <fwp_caps23+0xac>  // b.any
    8808:	92403c01 	and	x1, x0, #0xffff
    880c:	29430064 	ldp	w4, w0, [x3, #24]
    8810:	9b047c21 	mul	x1, x1, x4
    8814:	d360fc21 	lsr	x1, x1, #32
    8818:	eb00003f 	cmp	x1, x0
    881c:	54fffca2 	b.cs	87b0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8820:	8b010042 	add	x2, x2, x1
    8824:	39400040 	ldrb	w0, [x2]
    8828:	34fffc40 	cbz	w0, 87b0 <fwp_caps23+0xac>
    882c:	900000c1 	adrp	x1, 20000 <__data_start>
    8830:	91018021 	add	x1, x1, #0x60
    8834:	b9413023 	ldr	w3, [x1, #304]
    8838:	35000183 	cbnz	w3, 8868 <fwp_caps23+0x164>
    883c:	7103f41f 	cmp	w0, #0xfd
    8840:	540001c8 	b.hi	8878 <fwp_caps23+0x174>  // b.pmore
    8844:	11000400 	add	w0, w0, #0x1
    8848:	39000040 	strb	w0, [x2]
    884c:	17ffffd9 	b	87b0 <fwp_caps23+0xac>
    8850:	72003c1f 	tst	w0, #0xffff
    8854:	54fffae1 	b.ne	87b0 <fwp_caps23+0xac>  // b.any
    8858:	17ffffce 	b	8790 <fwp_caps23+0x8c>
    885c:	72003c1f 	tst	w0, #0xffff
    8860:	54fffa81 	b.ne	87b0 <fwp_caps23+0xac>  // b.any
    8864:	17fffff0 	b	8824 <fwp_caps23+0x120>
    8868:	f940ac23 	ldr	x3, [x1, #344]
    886c:	91000463 	add	x3, x3, #0x1
    8870:	f900ac23 	str	x3, [x1, #344]
    8874:	17fffff2 	b	883c <fwp_caps23+0x138>
    8878:	f9400bf3 	ldr	x19, [sp, #16]
    887c:	aa0203e0 	mov	x0, x2
    8880:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8884:	17ffeffc 	b	4874 <fwp_rc_wide_dup>
    8888:	d503201f 	nop
    888c:	d503201f 	nop

0000000000008890 <fwp_write>:
    8890:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8894:	910003fd 	mov	x29, sp
    8898:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    889c:	f947f484 	ldr	x4, [x4, #4072]
    88a0:	a90153f3 	stp	x19, x20, [sp, #16]
    88a4:	d10943ff 	sub	sp, sp, #0x250
    88a8:	b9400045 	ldr	w5, [x2]
    88ac:	aa0003f4 	mov	x20, x0
    88b0:	f9400080 	ldr	x0, [x4]
    88b4:	f90127e0 	str	x0, [sp, #584]
    88b8:	d2800000 	mov	x0, #0x0                   	// #0
    88bc:	710064bf 	cmp	w5, #0x19
    88c0:	54000408 	b.hi	8940 <fwp_write+0xb0>  // b.pmore
    88c4:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x9f0>
    88c8:	aa0103f3 	mov	x19, x1
    88cc:	91150000 	add	x0, x0, #0x540
    88d0:	f9013bf5 	str	x21, [sp, #624]
    88d4:	f9013ff6 	str	x22, [sp, #632]
    88d8:	f90153fb 	str	x27, [sp, #672]
    88dc:	f90157fc 	str	x28, [sp, #680]
    88e0:	aa0203fc 	mov	x28, x2
    88e4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    88e8:	10000061 	adr	x1, 88f4 <fwp_write+0x64>
    88ec:	8b20a820 	add	x0, x1, w0, sxth #2
    88f0:	d61f0000 	br	x0
    88f4:	910123e0 	add	x0, sp, #0x48
    88f8:	aa1303e5 	mov	x5, x19
    88fc:	f0000004 	adrp	x4, b000 <__divti3+0x110>
    8900:	aa0003f3 	mov	x19, x0
    8904:	9134c084 	add	x4, x4, #0xd30
    8908:	d2804003 	mov	x3, #0x200                 	// #512
    890c:	aa0303e1 	mov	x1, x3
    8910:	52800042 	mov	w2, #0x2                   	// #2
    8914:	97ffe79b 	bl	2780 <__snprintf_chk@plt>
    8918:	aa1303e0 	mov	x0, x19
    891c:	97ffe761 	bl	26a0 <strlen@plt>
    8920:	aa1303e1 	mov	x1, x19
    8924:	aa0003e2 	mov	x2, x0
    8928:	aa1403e0 	mov	x0, x20
    892c:	97ffeb39 	bl	3610 <buf_put>
    8930:	f9413bf5 	ldr	x21, [sp, #624]
    8934:	f9413ff6 	ldr	x22, [sp, #632]
    8938:	f94153fb 	ldr	x27, [sp, #672]
    893c:	f94157fc 	ldr	x28, [sp, #680]
    8940:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8944:	f947f400 	ldr	x0, [x0, #4072]
    8948:	f94127e2 	ldr	x2, [sp, #584]
    894c:	f9400001 	ldr	x1, [x0]
    8950:	eb010042 	subs	x2, x2, x1
    8954:	d2800001 	mov	x1, #0x0                   	// #0
    8958:	540077c1 	b.ne	9850 <fwp_write+0xfc0>  // b.any
    895c:	910943ff 	add	sp, sp, #0x250
    8960:	a94153f3 	ldp	x19, x20, [sp, #16]
    8964:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8968:	d65f03c0 	ret
    896c:	910123e0 	add	x0, sp, #0x48
    8970:	aa1303e5 	mov	x5, x19
    8974:	f0000004 	adrp	x4, b000 <__divti3+0x110>
    8978:	aa0003f3 	mov	x19, x0
    897c:	9134a084 	add	x4, x4, #0xd28
    8980:	d2804003 	mov	x3, #0x200                 	// #512
    8984:	17ffffe2 	b	890c <fwp_write+0x7c>
    8988:	71004cbf 	cmp	w5, #0x13
    898c:	f0000000 	adrp	x0, b000 <__divti3+0x110>
    8990:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8994:	91346000 	add	x0, x0, #0xd18
    8998:	91348021 	add	x1, x1, #0xd20
    899c:	d2800082 	mov	x2, #0x4                   	// #4
    89a0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    89a4:	aa1403e0 	mov	x0, x20
    89a8:	f90143f7 	str	x23, [sp, #640]
    89ac:	d2800016 	mov	x22, #0x0                   	// #0
    89b0:	f90147f8 	str	x24, [sp, #648]
    89b4:	97ffeb17 	bl	3610 <buf_put>
    89b8:	f9400260 	ldr	x0, [x19]
    89bc:	f0000017 	adrp	x23, b000 <__divti3+0x110>
    89c0:	d2800015 	mov	x21, #0x0                   	// #0
    89c4:	913682f7 	add	x23, x23, #0xda0
    89c8:	b40047a0 	cbz	x0, 92bc <fwp_write+0xa2c>
    89cc:	b9400380 	ldr	w0, [x28]
    89d0:	52800003 	mov	w3, #0x0                   	// #0
    89d4:	f9401f82 	ldr	x2, [x28, #56]
    89d8:	71004c1f 	cmp	w0, #0x13
    89dc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    89e0:	aa1403e0 	mov	x0, x20
    89e4:	8b010e61 	add	x1, x19, x1, lsl #3
    89e8:	f9400421 	ldr	x1, [x1, #8]
    89ec:	97ffffa9 	bl	8890 <fwp_write>
    89f0:	b9400380 	ldr	w0, [x28]
    89f4:	7100481f 	cmp	w0, #0x12
    89f8:	54004b40 	b.eq	9360 <fwp_write+0xad0>  // b.none
    89fc:	f9400260 	ldr	x0, [x19]
    8a00:	910006b5 	add	x21, x21, #0x1
    8a04:	91000ad6 	add	x22, x22, #0x2
    8a08:	eb15001f 	cmp	x0, x21
    8a0c:	54004589 	b.ls	92bc <fwp_write+0xa2c>  // b.plast
    8a10:	aa1703e1 	mov	x1, x23
    8a14:	aa1403e0 	mov	x0, x20
    8a18:	d2800042 	mov	x2, #0x2                   	// #2
    8a1c:	97ffeafd 	bl	3610 <buf_put>
    8a20:	17ffffeb 	b	89cc <fwp_write+0x13c>
    8a24:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8a28:	91356021 	add	x1, x1, #0xd58
    8a2c:	d28000c2 	mov	x2, #0x6                   	// #6
    8a30:	aa1403e0 	mov	x0, x20
    8a34:	91004273 	add	x19, x19, #0x10
    8a38:	97ffeaf6 	bl	3610 <buf_put>
    8a3c:	aa1303e0 	mov	x0, x19
    8a40:	97ffe718 	bl	26a0 <strlen@plt>
    8a44:	aa1303e1 	mov	x1, x19
    8a48:	aa0003e2 	mov	x2, x0
    8a4c:	aa1403e0 	mov	x0, x20
    8a50:	97ffeaf0 	bl	3610 <buf_put>
    8a54:	528007c3 	mov	w3, #0x3e                  	// #62
    8a58:	aa1403e0 	mov	x0, x20
    8a5c:	91001fe1 	add	x1, sp, #0x7
    8a60:	d2800022 	mov	x2, #0x1                   	// #1
    8a64:	39001fe3 	strb	w3, [sp, #7]
    8a68:	17ffffb1 	b	892c <fwp_write+0x9c>
    8a6c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8a70:	f947f400 	ldr	x0, [x0, #4072]
    8a74:	f94127e2 	ldr	x2, [sp, #584]
    8a78:	f9400001 	ldr	x1, [x0]
    8a7c:	eb010042 	subs	x2, x2, x1
    8a80:	d2800001 	mov	x1, #0x0                   	// #0
    8a84:	540034e1 	b.ne	9120 <fwp_write+0x890>  // b.any
    8a88:	f9413bf5 	ldr	x21, [sp, #624]
    8a8c:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8a90:	f9413ff6 	ldr	x22, [sp, #632]
    8a94:	aa1403e0 	mov	x0, x20
    8a98:	9134e021 	add	x1, x1, #0xd38
    8a9c:	d2800142 	mov	x2, #0xa                   	// #10
    8aa0:	f94153fb 	ldr	x27, [sp, #672]
    8aa4:	f94157fc 	ldr	x28, [sp, #680]
    8aa8:	910943ff 	add	sp, sp, #0x250
    8aac:	a94153f3 	ldp	x19, x20, [sp, #16]
    8ab0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8ab4:	17ffead7 	b	3610 <buf_put>
    8ab8:	f9400456 	ldr	x22, [x2, #8]
    8abc:	f90143f7 	str	x23, [sp, #640]
    8ac0:	f90147f8 	str	x24, [sp, #648]
    8ac4:	b4005b16 	cbz	x22, 9624 <fwp_write+0xd94>
    8ac8:	aa1603e0 	mov	x0, x22
    8acc:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8ad0:	9136e021 	add	x1, x1, #0xdb8
    8ad4:	97ffe76f 	bl	2890 <strcmp@plt>
    8ad8:	2a0003f5 	mov	w21, w0
    8adc:	34005fe0 	cbz	w0, 96d8 <fwp_write+0xe48>
    8ae0:	aa1603e0 	mov	x0, x22
    8ae4:	97ffe6ef 	bl	26a0 <strlen@plt>
    8ae8:	aa1603e1 	mov	x1, x22
    8aec:	aa0003e2 	mov	x2, x0
    8af0:	aa1403e0 	mov	x0, x20
    8af4:	97ffeac7 	bl	3610 <buf_put>
    8af8:	52800403 	mov	w3, #0x20                  	// #32
    8afc:	91001ff5 	add	x21, sp, #0x7
    8b00:	aa1503e1 	mov	x1, x21
    8b04:	aa1403e0 	mov	x0, x20
    8b08:	d2800022 	mov	x2, #0x1                   	// #1
    8b0c:	39001fe3 	strb	w3, [sp, #7]
    8b10:	97ffeac0 	bl	3610 <buf_put>
    8b14:	52800f63 	mov	w3, #0x7b                  	// #123
    8b18:	aa1403e0 	mov	x0, x20
    8b1c:	aa1503e1 	mov	x1, x21
    8b20:	d2800022 	mov	x2, #0x1                   	// #1
    8b24:	39001fe3 	strb	w3, [sp, #7]
    8b28:	97ffeaba 	bl	3610 <buf_put>
    8b2c:	b9401380 	ldr	w0, [x28, #16]
    8b30:	52800018 	mov	w24, #0x0                   	// #0
    8b34:	7100001f 	cmp	w0, #0x0
    8b38:	54003aad 	b.le	928c <fwp_write+0x9fc>
    8b3c:	f9014bf9 	str	x25, [sp, #656]
    8b40:	f0000019 	adrp	x25, b000 <__divti3+0x110>
    8b44:	91378339 	add	x25, x25, #0xde0
    8b48:	f9014ffa 	str	x26, [sp, #664]
    8b4c:	f000001a 	adrp	x26, b000 <__divti3+0x110>
    8b50:	9136835a 	add	x26, x26, #0xda0
    8b54:	91002276 	add	x22, x19, #0x8
    8b58:	d2800013 	mov	x19, #0x0                   	// #0
    8b5c:	b5003e93 	cbnz	x19, 932c <fwp_write+0xa9c>
    8b60:	d37df277 	lsl	x23, x19, #3
    8b64:	34003cb8 	cbz	w24, 92f8 <fwp_write+0xa68>
    8b68:	f9401382 	ldr	x2, [x28, #32]
    8b6c:	aa1403e0 	mov	x0, x20
    8b70:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8b74:	52800003 	mov	w3, #0x0                   	// #0
    8b78:	f8776842 	ldr	x2, [x2, x23]
    8b7c:	91000673 	add	x19, x19, #0x1
    8b80:	97ffff44 	bl	8890 <fwp_write>
    8b84:	b9401380 	ldr	w0, [x28, #16]
    8b88:	6b13001f 	cmp	w0, w19
    8b8c:	54fffe8c 	b.gt	8b5c <fwp_write+0x2cc>
    8b90:	f9414bf9 	ldr	x25, [sp, #656]
    8b94:	f9414ffa 	ldr	x26, [sp, #664]
    8b98:	340037b8 	cbz	w24, 928c <fwp_write+0x9fc>
    8b9c:	52800523 	mov	w3, #0x29                  	// #41
    8ba0:	aa1503e1 	mov	x1, x21
    8ba4:	aa1403e0 	mov	x0, x20
    8ba8:	d2800022 	mov	x2, #0x1                   	// #1
    8bac:	39001fe3 	strb	w3, [sp, #7]
    8bb0:	97ffea98 	bl	3610 <buf_put>
    8bb4:	f9413bf5 	ldr	x21, [sp, #624]
    8bb8:	f9413ff6 	ldr	x22, [sp, #632]
    8bbc:	f94143f7 	ldr	x23, [sp, #640]
    8bc0:	f94147f8 	ldr	x24, [sp, #648]
    8bc4:	f94153fb 	ldr	x27, [sp, #672]
    8bc8:	f94157fc 	ldr	x28, [sp, #680]
    8bcc:	17ffff5d 	b	8940 <fwp_write+0xb0>
    8bd0:	b9404855 	ldr	w21, [x2, #72]
    8bd4:	aa1403e0 	mov	x0, x20
    8bd8:	93407eb6 	sxtw	x22, w21
    8bdc:	91000ac1 	add	x1, x22, #0x2
    8be0:	97ffea58 	bl	3540 <buf_grow>
    8be4:	a9400281 	ldp	x1, x0, [x20]
    8be8:	528e8603 	mov	w3, #0x7430                	// #29744
    8bec:	78206823 	strh	w3, [x1, x0]
    8bf0:	8b000022 	add	x2, x1, x0
    8bf4:	710002bf 	cmp	w21, #0x0
    8bf8:	540036cd 	b.le	92d0 <fwp_write+0xa40>
    8bfc:	110006a3 	add	w3, w21, #0x1
    8c00:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8c04:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8c08:	91000449 	add	x9, x2, #0x1
    8c0c:	8b23c043 	add	x3, x2, w3, sxtw
    8c10:	f28aaac6 	movk	x6, #0x5556
    8c14:	f2955568 	movk	x8, #0xaaab
    8c18:	1400000d 	b	8c4c <fwp_write+0x3bc>
    8c1c:	d2800021 	mov	x1, #0x1                   	// #1
    8c20:	528005a5 	mov	w5, #0x2d                  	// #45
    8c24:	f100001f 	cmp	x0, #0x0
    8c28:	9b467e60 	smulh	x0, x19, x6
    8c2c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8c30:	381ff465 	strb	w5, [x3], #-1
    8c34:	cb040000 	sub	x0, x0, x4
    8c38:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8c3c:	cb020000 	sub	x0, x0, x2
    8c40:	8b010013 	add	x19, x0, x1
    8c44:	eb03013f 	cmp	x9, x3
    8c48:	54003440 	b.eq	92d0 <fwp_write+0xa40>  // b.none
    8c4c:	9b467e60 	smulh	x0, x19, x6
    8c50:	937ffe64 	asr	x4, x19, #63
    8c54:	52800605 	mov	w5, #0x30                  	// #48
    8c58:	cb040000 	sub	x0, x0, x4
    8c5c:	8b000400 	add	x0, x0, x0, lsl #1
    8c60:	cb000260 	sub	x0, x19, x0
    8c64:	91000c01 	add	x1, x0, #0x3
    8c68:	9bc87c22 	umulh	x2, x1, x8
    8c6c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8c70:	8b4204e2 	add	x2, x7, x2, lsr #1
    8c74:	eb020021 	subs	x1, x1, x2
    8c78:	54fffd60 	b.eq	8c24 <fwp_write+0x394>  // b.none
    8c7c:	f100043f 	cmp	x1, #0x1
    8c80:	54fffce1 	b.ne	8c1c <fwp_write+0x38c>  // b.any
    8c84:	d2800001 	mov	x1, #0x0                   	// #0
    8c88:	52800565 	mov	w5, #0x2b                  	// #43
    8c8c:	17ffffe6 	b	8c24 <fwp_write+0x394>
    8c90:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8c94:	f947f400 	ldr	x0, [x0, #4072]
    8c98:	f94127e2 	ldr	x2, [sp, #584]
    8c9c:	f9400001 	ldr	x1, [x0]
    8ca0:	eb010042 	subs	x2, x2, x1
    8ca4:	d2800001 	mov	x1, #0x0                   	// #0
    8ca8:	540023c1 	b.ne	9120 <fwp_write+0x890>  // b.any
    8cac:	f9413bf5 	ldr	x21, [sp, #624]
    8cb0:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8cb4:	f9413ff6 	ldr	x22, [sp, #632]
    8cb8:	aa1403e0 	mov	x0, x20
    8cbc:	91352021 	add	x1, x1, #0xd48
    8cc0:	d2800102 	mov	x2, #0x8                   	// #8
    8cc4:	17ffff77 	b	8aa0 <fwp_write+0x210>
    8cc8:	aa1403e0 	mov	x0, x20
    8ccc:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8cd0:	d28000c2 	mov	x2, #0x6                   	// #6
    8cd4:	9136a021 	add	x1, x1, #0xda8
    8cd8:	97ffea4e 	bl	3610 <buf_put>
    8cdc:	d2800015 	mov	x21, #0x0                   	// #0
    8ce0:	f9400263 	ldr	x3, [x19]
    8ce4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8ce8:	54002c60 	b.eq	9274 <fwp_write+0x9e4>  // b.none
    8cec:	f9401f82 	ldr	x2, [x28, #56]
    8cf0:	f90143f7 	str	x23, [sp, #640]
    8cf4:	f90147f8 	str	x24, [sp, #648]
    8cf8:	d2800857 	mov	x23, #0x42                  	// #66
    8cfc:	f9014bf9 	str	x25, [sp, #656]
    8d00:	f0000016 	adrp	x22, b000 <__divti3+0x110>
    8d04:	f9014ffa 	str	x26, [sp, #664]
    8d08:	913682d6 	add	x22, x22, #0xda0
    8d0c:	d2800038 	mov	x24, #0x1                   	// #1
    8d10:	f2a18017 	movk	x23, #0xc00, lsl #16
    8d14:	d2809099 	mov	x25, #0x484                 	// #1156
    8d18:	b40004a2 	cbz	x2, 8dac <fwp_write+0x51c>
    8d1c:	b9400040 	ldr	w0, [x2]
    8d20:	7100701f 	cmp	w0, #0x1c
    8d24:	540042c0 	b.eq	957c <fwp_write+0xcec>  // b.none
    8d28:	71006c1f 	cmp	w0, #0x1b
    8d2c:	54000408 	b.hi	8dac <fwp_write+0x51c>  // b.pmore
    8d30:	9ac02301 	lsl	x1, x24, x0
    8d34:	ea17003f 	tst	x1, x23
    8d38:	540036a1 	b.ne	940c <fwp_write+0xb7c>  // b.any
    8d3c:	ea19003f 	tst	x1, x25
    8d40:	54003521 	b.ne	93e4 <fwp_write+0xb54>  // b.any
    8d44:	d2800424 	mov	x4, #0x21                  	// #33
    8d48:	ea04003f 	tst	x1, x4
    8d4c:	54000300 	b.eq	8dac <fwp_write+0x51c>  // b.none
    8d50:	b7f849c3 	tbnz	x3, #63, 9688 <fwp_write+0xdf8>
    8d54:	91002261 	add	x1, x19, #0x8
    8d58:	8b150021 	add	x1, x1, x21
    8d5c:	39400021 	ldrb	w1, [x1]
    8d60:	7100001f 	cmp	w0, #0x0
    8d64:	93401c23 	sxtb	x3, w1
    8d68:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8d6c:	d503201f 	nop
    8d70:	aa1403e0 	mov	x0, x20
    8d74:	52800003 	mov	w3, #0x0                   	// #0
    8d78:	97fffec6 	bl	8890 <fwp_write>
    8d7c:	910006b5 	add	x21, x21, #0x1
    8d80:	f9400260 	ldr	x0, [x19]
    8d84:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8d88:	eb0002bf 	cmp	x21, x0
    8d8c:	540026c2 	b.cs	9264 <fwp_write+0x9d4>  // b.hs, b.nlast
    8d90:	d2800042 	mov	x2, #0x2                   	// #2
    8d94:	aa1603e1 	mov	x1, x22
    8d98:	aa1403e0 	mov	x0, x20
    8d9c:	97ffea1d 	bl	3610 <buf_put>
    8da0:	f9401f82 	ldr	x2, [x28, #56]
    8da4:	f9400263 	ldr	x3, [x19]
    8da8:	b5fffba2 	cbnz	x2, 8d1c <fwp_write+0x48c>
    8dac:	d37df2a0 	lsl	x0, x21, #3
    8db0:	b7f83f03 	tbnz	x3, #63, 9590 <fwp_write+0xd00>
    8db4:	91002261 	add	x1, x19, #0x8
    8db8:	8b000020 	add	x0, x1, x0
    8dbc:	f9400001 	ldr	x1, [x0]
    8dc0:	17ffffec 	b	8d70 <fwp_write+0x4e0>
    8dc4:	a9400e62 	ldp	x2, x3, [x19]
    8dc8:	b7f83ca3 	tbnz	x3, #63, 955c <fwp_write+0xccc>
    8dcc:	910123f5 	add	x21, sp, #0x48
    8dd0:	aa1503e0 	mov	x0, x21
    8dd4:	97ffe7f3 	bl	2da0 <fwp_fmt_u128>
    8dd8:	aa1503e0 	mov	x0, x21
    8ddc:	97ffe631 	bl	26a0 <strlen@plt>
    8de0:	aa1503e1 	mov	x1, x21
    8de4:	aa0003e2 	mov	x2, x0
    8de8:	17fffed0 	b	8928 <fwp_write+0x98>
    8dec:	fd015be8 	str	d8, [sp, #688]
    8df0:	1e270268 	fmov	s8, w19
    8df4:	fd015fe9 	str	d9, [sp, #696]
    8df8:	1e282100 	fcmp	s8, s8
    8dfc:	54004d26 	b.vs	97a0 <fwp_write+0xf10>
    8e00:	1e20c101 	fabs	s1, s8
    8e04:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8e08:	1e270000 	fmov	s0, w0
    8e0c:	1e202020 	fcmp	s1, s0
    8e10:	54002c0d 	b.le	9390 <fwp_write+0xb00>
    8e14:	1e202118 	fcmpe	s8, #0.0
    8e18:	f0000002 	adrp	x2, b000 <__divti3+0x110>
    8e1c:	911e2042 	add	x2, x2, #0x788
    8e20:	910123f5 	add	x21, sp, #0x48
    8e24:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8e28:	9133e021 	add	x1, x1, #0xcf8
    8e2c:	aa1503e0 	mov	x0, x21
    8e30:	9a81c041 	csel	x1, x2, x1, gt
    8e34:	97ffe6c7 	bl	2950 <strcpy@plt>
    8e38:	aa1503e0 	mov	x0, x21
    8e3c:	97ffe619 	bl	26a0 <strlen@plt>
    8e40:	aa1503e1 	mov	x1, x21
    8e44:	aa0003e2 	mov	x2, x0
    8e48:	aa1403e0 	mov	x0, x20
    8e4c:	97ffe9f1 	bl	3610 <buf_put>
    8e50:	f9413bf5 	ldr	x21, [sp, #624]
    8e54:	f9413ff6 	ldr	x22, [sp, #632]
    8e58:	f94153fb 	ldr	x27, [sp, #672]
    8e5c:	f94157fc 	ldr	x28, [sp, #680]
    8e60:	fd415be8 	ldr	d8, [sp, #688]
    8e64:	fd415fe9 	ldr	d9, [sp, #696]
    8e68:	17fffeb6 	b	8940 <fwp_write+0xb0>
    8e6c:	f9400276 	ldr	x22, [x19]
    8e70:	34002e03 	cbz	w3, 9430 <fwp_write+0xba0>
    8e74:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8e78:	f947f400 	ldr	x0, [x0, #4072]
    8e7c:	f94127e2 	ldr	x2, [sp, #584]
    8e80:	f9400001 	ldr	x1, [x0]
    8e84:	eb010042 	subs	x2, x2, x1
    8e88:	d2800001 	mov	x1, #0x0                   	// #0
    8e8c:	540014a1 	b.ne	9120 <fwp_write+0x890>  // b.any
    8e90:	aa1603e2 	mov	x2, x22
    8e94:	91002261 	add	x1, x19, #0x8
    8e98:	f9413bf5 	ldr	x21, [sp, #624]
    8e9c:	aa1403e0 	mov	x0, x20
    8ea0:	f9413ff6 	ldr	x22, [sp, #632]
    8ea4:	17fffeff 	b	8aa0 <fwp_write+0x210>
    8ea8:	fd015be8 	str	d8, [sp, #688]
    8eac:	9e670268 	fmov	d8, x19
    8eb0:	fd015fe9 	str	d9, [sp, #696]
    8eb4:	1e682100 	fcmp	d8, d8
    8eb8:	54004746 	b.vs	97a0 <fwp_write+0xf10>
    8ebc:	1e60c101 	fabs	d1, d8
    8ec0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8ec4:	9e670000 	fmov	d0, x0
    8ec8:	910123f5 	add	x21, sp, #0x48
    8ecc:	52800033 	mov	w19, #0x1                   	// #1
    8ed0:	1e602020 	fcmp	d1, d0
    8ed4:	540001ad 	b.le	8f08 <fwp_write+0x678>
    8ed8:	1e602118 	fcmpe	d8, #0.0
    8edc:	f0000002 	adrp	x2, b000 <__divti3+0x110>
    8ee0:	911e2042 	add	x2, x2, #0x788
    8ee4:	f0000001 	adrp	x1, b000 <__divti3+0x110>
    8ee8:	9133e021 	add	x1, x1, #0xcf8
    8eec:	aa1503e0 	mov	x0, x21
    8ef0:	9a81c041 	csel	x1, x2, x1, gt
    8ef4:	97ffe697 	bl	2950 <strcpy@plt>
    8ef8:	17ffffd0 	b	8e38 <fwp_write+0x5a8>
    8efc:	11000673 	add	w19, w19, #0x1
    8f00:	71004a7f 	cmp	w19, #0x12
    8f04:	54003860 	b.eq	9610 <fwp_write+0xd80>  // b.none
    8f08:	1e604100 	fmov	d0, d8
    8f0c:	2a1303e1 	mov	w1, w19
    8f10:	aa1503e0 	mov	x0, x21
    8f14:	97ffeb00 	bl	3b14 <fwp_format_g.constprop.0>
    8f18:	aa1503e0 	mov	x0, x21
    8f1c:	d2800001 	mov	x1, #0x0                   	// #0
    8f20:	97ffe5f4 	bl	26f0 <strtod@plt>
    8f24:	1e602100 	fcmp	d8, d0
    8f28:	54fffea1 	b.ne	8efc <fwp_write+0x66c>  // b.any
    8f2c:	aa1503e0 	mov	x0, x21
    8f30:	97ffe9f1 	bl	36f4 <fwp_finish_float>
    8f34:	17ffffc1 	b	8e38 <fwp_write+0x5a8>
    8f38:	a9400e62 	ldp	x2, x3, [x19]
    8f3c:	910123f3 	add	x19, sp, #0x48
    8f40:	aa1303e0 	mov	x0, x19
    8f44:	97ffe797 	bl	2da0 <fwp_fmt_u128>
    8f48:	17fffe74 	b	8918 <fwp_write+0x88>
    8f4c:	f90143f7 	str	x23, [sp, #640]
    8f50:	f90147f8 	str	x24, [sp, #648]
    8f54:	2a1303f8 	mov	w24, w19
    8f58:	f9014bf9 	str	x25, [sp, #656]
    8f5c:	f9014ffa 	str	x26, [sp, #664]
    8f60:	f13ffe7f 	cmp	x19, #0xfff
    8f64:	54000049 	b.ls	8f6c <fwp_write+0x6dc>  // b.plast
    8f68:	b9400278 	ldr	w24, [x19]
    8f6c:	f9400f80 	ldr	x0, [x28, #24]
    8f70:	2a1803f5 	mov	w21, w24
    8f74:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8f78:	d37ef6b9 	lsl	x25, x21, #2
    8f7c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8f80:	aa1603e0 	mov	x0, x22
    8f84:	97ffe5c7 	bl	26a0 <strlen@plt>
    8f88:	aa1603e1 	mov	x1, x22
    8f8c:	aa0003e2 	mov	x2, x0
    8f90:	aa1403e0 	mov	x0, x20
    8f94:	97ffe99f 	bl	3610 <buf_put>
    8f98:	f9401780 	ldr	x0, [x28, #40]
    8f9c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8fa0:	7100001f 	cmp	w0, #0x0
    8fa4:	5400068d 	b.le	9074 <fwp_write+0x7e4>
    8fa8:	91002276 	add	x22, x19, #0x8
    8fac:	91001ff5 	add	x21, sp, #0x7
    8fb0:	d280001b 	mov	x27, #0x0                   	// #0
    8fb4:	5280041a 	mov	w26, #0x20                  	// #32
    8fb8:	f9401b80 	ldr	x0, [x28, #48]
    8fbc:	aa1503e1 	mov	x1, x21
    8fc0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8fc4:	d2800022 	mov	x2, #0x1                   	// #1
    8fc8:	f8786803 	ldr	x3, [x0, x24]
    8fcc:	aa1403e0 	mov	x0, x20
    8fd0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8fd4:	39001ffa 	strb	w26, [sp, #7]
    8fd8:	97ffe98e 	bl	3610 <buf_put>
    8fdc:	f13ffeff 	cmp	x23, #0xfff
    8fe0:	b9400261 	ldr	w1, [x19]
    8fe4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8fe8:	7100383f 	cmp	w1, #0xe
    8fec:	54000160 	b.eq	9018 <fwp_write+0x788>  // b.none
    8ff0:	7100403f 	cmp	w1, #0x10
    8ff4:	54001a60 	b.eq	9340 <fwp_write+0xab0>  // b.none
    8ff8:	7100283f 	cmp	w1, #0xa
    8ffc:	54002aa0 	b.eq	9550 <fwp_write+0xcc0>  // b.none
    9000:	540014ac 	b.gt	9294 <fwp_write+0xa04>
    9004:	71000c3f 	cmp	w1, #0x3
    9008:	540029ac 	b.gt	953c <fwp_write+0xcac>
    900c:	d37ffee0 	lsr	x0, x23, #63
    9010:	37f814a1 	tbnz	w1, #31, 92a4 <fwp_write+0xa14>
    9014:	d503201f 	nop
    9018:	34001460 	cbz	w0, 92a4 <fwp_write+0xa14>
    901c:	52800503 	mov	w3, #0x28                  	// #40
    9020:	aa1503e1 	mov	x1, x21
    9024:	aa1403e0 	mov	x0, x20
    9028:	d2800022 	mov	x2, #0x1                   	// #1
    902c:	39001fe3 	strb	w3, [sp, #7]
    9030:	97ffe978 	bl	3610 <buf_put>
    9034:	aa1303e2 	mov	x2, x19
    9038:	aa1703e1 	mov	x1, x23
    903c:	aa1403e0 	mov	x0, x20
    9040:	52800003 	mov	w3, #0x0                   	// #0
    9044:	97fffe13 	bl	8890 <fwp_write>
    9048:	52800523 	mov	w3, #0x29                  	// #41
    904c:	aa1503e1 	mov	x1, x21
    9050:	aa1403e0 	mov	x0, x20
    9054:	d2800022 	mov	x2, #0x1                   	// #1
    9058:	39001fe3 	strb	w3, [sp, #7]
    905c:	97ffe96d 	bl	3610 <buf_put>
    9060:	f9401780 	ldr	x0, [x28, #40]
    9064:	9100077b 	add	x27, x27, #0x1
    9068:	b8796800 	ldr	w0, [x0, x25]
    906c:	6b1b001f 	cmp	w0, w27
    9070:	54fffa4c 	b.gt	8fb8 <fwp_write+0x728>
    9074:	f9413bf5 	ldr	x21, [sp, #624]
    9078:	f9413ff6 	ldr	x22, [sp, #632]
    907c:	f94143f7 	ldr	x23, [sp, #640]
    9080:	f94147f8 	ldr	x24, [sp, #648]
    9084:	f9414bf9 	ldr	x25, [sp, #656]
    9088:	f9414ffa 	ldr	x26, [sp, #664]
    908c:	f94153fb 	ldr	x27, [sp, #672]
    9090:	f94157fc 	ldr	x28, [sp, #680]
    9094:	17fffe2b 	b	8940 <fwp_write+0xb0>
    9098:	52800783 	mov	w3, #0x3c                  	// #60
    909c:	91001ff3 	add	x19, sp, #0x7
    90a0:	aa1303e1 	mov	x1, x19
    90a4:	d2800022 	mov	x2, #0x1                   	// #1
    90a8:	aa1403e0 	mov	x0, x20
    90ac:	39001fe3 	strb	w3, [sp, #7]
    90b0:	97ffe958 	bl	3610 <buf_put>
    90b4:	f9400795 	ldr	x21, [x28, #8]
    90b8:	aa1503e0 	mov	x0, x21
    90bc:	97ffe579 	bl	26a0 <strlen@plt>
    90c0:	aa1503e1 	mov	x1, x21
    90c4:	aa0003e2 	mov	x2, x0
    90c8:	aa1403e0 	mov	x0, x20
    90cc:	97ffe951 	bl	3610 <buf_put>
    90d0:	528007c3 	mov	w3, #0x3e                  	// #62
    90d4:	aa1303e1 	mov	x1, x19
    90d8:	aa1403e0 	mov	x0, x20
    90dc:	d2800022 	mov	x2, #0x1                   	// #1
    90e0:	39001fe3 	strb	w3, [sp, #7]
    90e4:	17fffe12 	b	892c <fwp_write+0x9c>
    90e8:	f100067f 	cmp	x19, #0x1
    90ec:	540025a0 	b.eq	95a0 <fwp_write+0xd10>  // b.none
    90f0:	b100067f 	cmn	x19, #0x1
    90f4:	54002bc0 	b.eq	966c <fwp_write+0xddc>  // b.none
    90f8:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    90fc:	91340021 	add	x1, x1, #0xd00
    9100:	d2800022 	mov	x2, #0x1                   	// #1
    9104:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9108:	f947f400 	ldr	x0, [x0, #4072]
    910c:	f94127e4 	ldr	x4, [sp, #584]
    9110:	f9400003 	ldr	x3, [x0]
    9114:	eb030084 	subs	x4, x4, x3
    9118:	d2800003 	mov	x3, #0x0                   	// #0
    911c:	54ffebe0 	b.eq	8e98 <fwp_write+0x608>  // b.none
    9120:	f90143f7 	str	x23, [sp, #640]
    9124:	f90147f8 	str	x24, [sp, #648]
    9128:	f9014bf9 	str	x25, [sp, #656]
    912c:	f9014ffa 	str	x26, [sp, #664]
    9130:	fd015be8 	str	d8, [sp, #688]
    9134:	fd015fe9 	str	d9, [sp, #696]
    9138:	97ffe5b6 	bl	2810 <__stack_chk_fail@plt>
    913c:	52800b63 	mov	w3, #0x5b                  	// #91
    9140:	91001ff5 	add	x21, sp, #0x7
    9144:	aa1503e1 	mov	x1, x21
    9148:	aa1403e0 	mov	x0, x20
    914c:	d2800022 	mov	x2, #0x1                   	// #1
    9150:	d0000016 	adrp	x22, b000 <__divti3+0x110>
    9154:	913682d6 	add	x22, x22, #0xda0
    9158:	39001fe3 	strb	w3, [sp, #7]
    915c:	97ffe92d 	bl	3610 <buf_put>
    9160:	b4000273 	cbz	x19, 91ac <fwp_write+0x91c>
    9164:	f9400661 	ldr	x1, [x19, #8]
    9168:	aa1403e0 	mov	x0, x20
    916c:	f9401f82 	ldr	x2, [x28, #56]
    9170:	52800003 	mov	w3, #0x0                   	// #0
    9174:	97fffdc7 	bl	8890 <fwp_write>
    9178:	f9400a73 	ldr	x19, [x19, #16]
    917c:	b4000193 	cbz	x19, 91ac <fwp_write+0x91c>
    9180:	aa1603e1 	mov	x1, x22
    9184:	aa1403e0 	mov	x0, x20
    9188:	d2800042 	mov	x2, #0x2                   	// #2
    918c:	97ffe921 	bl	3610 <buf_put>
    9190:	f9400661 	ldr	x1, [x19, #8]
    9194:	aa1403e0 	mov	x0, x20
    9198:	f9401f82 	ldr	x2, [x28, #56]
    919c:	52800003 	mov	w3, #0x0                   	// #0
    91a0:	97fffdbc 	bl	8890 <fwp_write>
    91a4:	f9400a73 	ldr	x19, [x19, #16]
    91a8:	b5fffed3 	cbnz	x19, 9180 <fwp_write+0x8f0>
    91ac:	52800ba3 	mov	w3, #0x5d                  	// #93
    91b0:	aa1503e1 	mov	x1, x21
    91b4:	aa1403e0 	mov	x0, x20
    91b8:	d2800022 	mov	x2, #0x1                   	// #1
    91bc:	39001fe3 	strb	w3, [sp, #7]
    91c0:	17fffddb 	b	892c <fwp_write+0x9c>
    91c4:	aa1403e0 	mov	x0, x20
    91c8:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    91cc:	d28000c2 	mov	x2, #0x6                   	// #6
    91d0:	91364021 	add	x1, x1, #0xd90
    91d4:	97ffe90f 	bl	3610 <buf_put>
    91d8:	f9400260 	ldr	x0, [x19]
    91dc:	b40004c0 	cbz	x0, 9274 <fwp_write+0x9e4>
    91e0:	910123f5 	add	x21, sp, #0x48
    91e4:	91002276 	add	x22, x19, #0x8
    91e8:	f90143f7 	str	x23, [sp, #640]
    91ec:	d2800017 	mov	x23, #0x0                   	// #0
    91f0:	f90147f8 	str	x24, [sp, #648]
    91f4:	d0000018 	adrp	x24, b000 <__divti3+0x110>
    91f8:	91366318 	add	x24, x24, #0xd98
    91fc:	f9014bf9 	str	x25, [sp, #656]
    9200:	d0000019 	adrp	x25, b000 <__divti3+0x110>
    9204:	91368339 	add	x25, x25, #0xda0
    9208:	f9014ffa 	str	x26, [sp, #664]
    920c:	14000005 	b	9220 <fwp_write+0x990>
    9210:	aa1903e1 	mov	x1, x25
    9214:	aa1403e0 	mov	x0, x20
    9218:	d2800042 	mov	x2, #0x2                   	// #2
    921c:	97ffe8fd 	bl	3610 <buf_put>
    9220:	38776ac5 	ldrb	w5, [x22, x23]
    9224:	d2804003 	mov	x3, #0x200                 	// #512
    9228:	aa1803e4 	mov	x4, x24
    922c:	aa0303e1 	mov	x1, x3
    9230:	52800042 	mov	w2, #0x2                   	// #2
    9234:	aa1503e0 	mov	x0, x21
    9238:	910006f7 	add	x23, x23, #0x1
    923c:	97ffe551 	bl	2780 <__snprintf_chk@plt>
    9240:	aa1503e0 	mov	x0, x21
    9244:	97ffe517 	bl	26a0 <strlen@plt>
    9248:	aa1503e1 	mov	x1, x21
    924c:	aa0003e2 	mov	x2, x0
    9250:	aa1403e0 	mov	x0, x20
    9254:	97ffe8ef 	bl	3610 <buf_put>
    9258:	f9400260 	ldr	x0, [x19]
    925c:	eb17001f 	cmp	x0, x23
    9260:	54fffd88 	b.hi	9210 <fwp_write+0x980>  // b.pmore
    9264:	f94143f7 	ldr	x23, [sp, #640]
    9268:	f94147f8 	ldr	x24, [sp, #648]
    926c:	f9414bf9 	ldr	x25, [sp, #656]
    9270:	f9414ffa 	ldr	x26, [sp, #664]
    9274:	52800ba3 	mov	w3, #0x5d                  	// #93
    9278:	aa1403e0 	mov	x0, x20
    927c:	91001fe1 	add	x1, sp, #0x7
    9280:	d2800022 	mov	x2, #0x1                   	// #1
    9284:	39001fe3 	strb	w3, [sp, #7]
    9288:	17fffda9 	b	892c <fwp_write+0x9c>
    928c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9290:	17fffe44 	b	8ba0 <fwp_write+0x310>
    9294:	f10002ff 	cmp	x23, #0x0
    9298:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    929c:	71002c3f 	cmp	w1, #0xb
    92a0:	54ffebc0 	b.eq	9018 <fwp_write+0x788>  // b.none
    92a4:	aa1303e2 	mov	x2, x19
    92a8:	aa1703e1 	mov	x1, x23
    92ac:	aa1403e0 	mov	x0, x20
    92b0:	52800003 	mov	w3, #0x0                   	// #0
    92b4:	97fffd77 	bl	8890 <fwp_write>
    92b8:	17ffff6a 	b	9060 <fwp_write+0x7d0>
    92bc:	aa1403e0 	mov	x0, x20
    92c0:	91001fe1 	add	x1, sp, #0x7
    92c4:	52800fa3 	mov	w3, #0x7d                  	// #125
    92c8:	d2800022 	mov	x2, #0x1                   	// #1
    92cc:	17fffe38 	b	8bac <fwp_write+0x31c>
    92d0:	a9400281 	ldp	x1, x0, [x20]
    92d4:	91000800 	add	x0, x0, #0x2
    92d8:	8b160000 	add	x0, x0, x22
    92dc:	f9000680 	str	x0, [x20, #8]
    92e0:	3820683f 	strb	wzr, [x1, x0]
    92e4:	f9413bf5 	ldr	x21, [sp, #624]
    92e8:	f9413ff6 	ldr	x22, [sp, #632]
    92ec:	f94153fb 	ldr	x27, [sp, #672]
    92f0:	f94157fc 	ldr	x28, [sp, #680]
    92f4:	17fffd93 	b	8940 <fwp_write+0xb0>
    92f8:	f9400f80 	ldr	x0, [x28, #24]
    92fc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9300:	aa1b03e0 	mov	x0, x27
    9304:	97ffe4e7 	bl	26a0 <strlen@plt>
    9308:	aa1b03e1 	mov	x1, x27
    930c:	aa0003e2 	mov	x2, x0
    9310:	aa1403e0 	mov	x0, x20
    9314:	97ffe8bf 	bl	3610 <buf_put>
    9318:	aa1903e1 	mov	x1, x25
    931c:	aa1403e0 	mov	x0, x20
    9320:	d2800062 	mov	x2, #0x3                   	// #3
    9324:	97ffe8bb 	bl	3610 <buf_put>
    9328:	17fffe10 	b	8b68 <fwp_write+0x2d8>
    932c:	aa1a03e1 	mov	x1, x26
    9330:	aa1403e0 	mov	x0, x20
    9334:	d2800042 	mov	x2, #0x2                   	// #2
    9338:	97ffe8b6 	bl	3610 <buf_put>
    933c:	17fffe09 	b	8b60 <fwp_write+0x2d0>
    9340:	f9400660 	ldr	x0, [x19, #8]
    9344:	b4fffb00 	cbz	x0, 92a4 <fwp_write+0xa14>
    9348:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    934c:	9136e021 	add	x1, x1, #0xdb8
    9350:	97ffe550 	bl	2890 <strcmp@plt>
    9354:	7100001f 	cmp	w0, #0x0
    9358:	1a9f07e0 	cset	w0, ne	// ne = any
    935c:	17ffff2f 	b	9018 <fwp_write+0x788>
    9360:	aa1403e0 	mov	x0, x20
    9364:	d2800042 	mov	x2, #0x2                   	// #2
    9368:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    936c:	9136c021 	add	x1, x1, #0xdb0
    9370:	97ffe8a8 	bl	3610 <buf_put>
    9374:	91004261 	add	x1, x19, #0x10
    9378:	aa1403e0 	mov	x0, x20
    937c:	f9402382 	ldr	x2, [x28, #64]
    9380:	52800003 	mov	w3, #0x0                   	// #0
    9384:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9388:	97fffd42 	bl	8890 <fwp_write>
    938c:	17fffd9c 	b	89fc <fwp_write+0x16c>
    9390:	1e22c109 	fcvt	d9, s8
    9394:	910123f5 	add	x21, sp, #0x48
    9398:	52800033 	mov	w19, #0x1                   	// #1
    939c:	d503201f 	nop
    93a0:	1e604120 	fmov	d0, d9
    93a4:	2a1303e1 	mov	w1, w19
    93a8:	aa1503e0 	mov	x0, x21
    93ac:	97ffe9da 	bl	3b14 <fwp_format_g.constprop.0>
    93b0:	aa1503e0 	mov	x0, x21
    93b4:	d2800001 	mov	x1, #0x0                   	// #0
    93b8:	97ffe542 	bl	28c0 <strtof@plt>
    93bc:	1e202100 	fcmp	s8, s0
    93c0:	54ffdb60 	b.eq	8f2c <fwp_write+0x69c>  // b.none
    93c4:	11000673 	add	w19, w19, #0x1
    93c8:	71002a7f 	cmp	w19, #0xa
    93cc:	54fffea1 	b.ne	93a0 <fwp_write+0xb10>  // b.any
    93d0:	1e604120 	fmov	d0, d9
    93d4:	aa1503e0 	mov	x0, x21
    93d8:	52800121 	mov	w1, #0x9                   	// #9
    93dc:	97ffe9ce 	bl	3b14 <fwp_format_g.constprop.0>
    93e0:	17fffed3 	b	8f2c <fwp_write+0x69c>
    93e4:	d37ef6a1 	lsl	x1, x21, #2
    93e8:	b7f81563 	tbnz	x3, #63, 9694 <fwp_write+0xe04>
    93ec:	91002263 	add	x3, x19, #0x8
    93f0:	8b010061 	add	x1, x3, x1
    93f4:	b9400023 	ldr	w3, [x1]
    93f8:	7100081f 	cmp	w0, #0x2
    93fc:	2a0303e1 	mov	w1, w3
    9400:	93407c63 	sxtw	x3, w3
    9404:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9408:	17fffe5a 	b	8d70 <fwp_write+0x4e0>
    940c:	d37ffaa1 	lsl	x1, x21, #1
    9410:	b7f81363 	tbnz	x3, #63, 967c <fwp_write+0xdec>
    9414:	91002263 	add	x3, x19, #0x8
    9418:	8b010061 	add	x1, x3, x1
    941c:	79400021 	ldrh	w1, [x1]
    9420:	7100041f 	cmp	w0, #0x1
    9424:	93403c23 	sxth	x3, w1
    9428:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    942c:	17fffe51 	b	8d70 <fwp_write+0x4e0>
    9430:	52800443 	mov	w3, #0x22                  	// #34
    9434:	91001ff5 	add	x21, sp, #0x7
    9438:	91002273 	add	x19, x19, #0x8
    943c:	aa1503e1 	mov	x1, x21
    9440:	aa1403e0 	mov	x0, x20
    9444:	d2800022 	mov	x2, #0x1                   	// #1
    9448:	39001fe3 	strb	w3, [sp, #7]
    944c:	f90143f7 	str	x23, [sp, #640]
    9450:	8b160277 	add	x23, x19, x22
    9454:	f90147f8 	str	x24, [sp, #648]
    9458:	97ffe86e 	bl	3610 <buf_put>
    945c:	b4000696 	cbz	x22, 952c <fwp_write+0xc9c>
    9460:	d0000018 	adrp	x24, b000 <__divti3+0x110>
    9464:	91358318 	add	x24, x24, #0xd60
    9468:	f9014bf9 	str	x25, [sp, #656]
    946c:	d0000019 	adrp	x25, b000 <__divti3+0x110>
    9470:	91360339 	add	x25, x25, #0xd80
    9474:	f9014ffa 	str	x26, [sp, #664]
    9478:	1400000d 	b	94ac <fwp_write+0xc1c>
    947c:	710024bf 	cmp	w5, #0x9
    9480:	54000460 	b.eq	950c <fwp_write+0xc7c>  // b.none
    9484:	710028bf 	cmp	w5, #0xa
    9488:	54000a61 	b.ne	95d4 <fwp_write+0xd44>  // b.any
    948c:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    9490:	aa1403e0 	mov	x0, x20
    9494:	9135c021 	add	x1, x1, #0xd70
    9498:	d2800042 	mov	x2, #0x2                   	// #2
    949c:	97ffe85d 	bl	3610 <buf_put>
    94a0:	91000673 	add	x19, x19, #0x1
    94a4:	eb17027f 	cmp	x19, x23
    94a8:	540003e0 	b.eq	9524 <fwp_write+0xc94>  // b.none
    94ac:	39400265 	ldrb	w5, [x19]
    94b0:	710034bf 	cmp	w5, #0xd
    94b4:	54000180 	b.eq	94e4 <fwp_write+0xc54>  // b.none
    94b8:	54fffe29 	b.ls	947c <fwp_write+0xbec>  // b.plast
    94bc:	710088bf 	cmp	w5, #0x22
    94c0:	540001c0 	b.eq	94f8 <fwp_write+0xc68>  // b.none
    94c4:	710170bf 	cmp	w5, #0x5c
    94c8:	54000741 	b.ne	95b0 <fwp_write+0xd20>  // b.any
    94cc:	aa1403e0 	mov	x0, x20
    94d0:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    94d4:	d2800042 	mov	x2, #0x2                   	// #2
    94d8:	9135a021 	add	x1, x1, #0xd68
    94dc:	97ffe84d 	bl	3610 <buf_put>
    94e0:	17fffff0 	b	94a0 <fwp_write+0xc10>
    94e4:	aa1903e1 	mov	x1, x25
    94e8:	aa1403e0 	mov	x0, x20
    94ec:	d2800042 	mov	x2, #0x2                   	// #2
    94f0:	97ffe848 	bl	3610 <buf_put>
    94f4:	17ffffeb 	b	94a0 <fwp_write+0xc10>
    94f8:	aa1803e1 	mov	x1, x24
    94fc:	aa1403e0 	mov	x0, x20
    9500:	d2800042 	mov	x2, #0x2                   	// #2
    9504:	97ffe843 	bl	3610 <buf_put>
    9508:	17ffffe6 	b	94a0 <fwp_write+0xc10>
    950c:	aa1403e0 	mov	x0, x20
    9510:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    9514:	d2800042 	mov	x2, #0x2                   	// #2
    9518:	9135e021 	add	x1, x1, #0xd78
    951c:	97ffe83d 	bl	3610 <buf_put>
    9520:	17ffffe0 	b	94a0 <fwp_write+0xc10>
    9524:	f9414bf9 	ldr	x25, [sp, #656]
    9528:	f9414ffa 	ldr	x26, [sp, #664]
    952c:	aa1503e1 	mov	x1, x21
    9530:	aa1403e0 	mov	x0, x20
    9534:	52800443 	mov	w3, #0x22                  	// #34
    9538:	17fffd9c 	b	8ba8 <fwp_write+0x318>
    953c:	7100103f 	cmp	w1, #0x4
    9540:	54ffeb21 	b.ne	92a4 <fwp_write+0xa14>  // b.any
    9544:	f94006e0 	ldr	x0, [x23, #8]
    9548:	d37ffc00 	lsr	x0, x0, #63
    954c:	17fffeb3 	b	9018 <fwp_write+0x788>
    9550:	710002ff 	cmp	w23, #0x0
    9554:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9558:	17fffeb0 	b	9018 <fwp_write+0x788>
    955c:	528005a1 	mov	w1, #0x2d                  	// #45
    9560:	eb0203e2 	negs	x2, x2
    9564:	da0303e3 	ngc	x3, x3
    9568:	910127e0 	add	x0, sp, #0x49
    956c:	910123f5 	add	x21, sp, #0x48
    9570:	390123e1 	strb	w1, [sp, #72]
    9574:	97ffe60b 	bl	2da0 <fwp_fmt_u128>
    9578:	17fffe18 	b	8dd8 <fwp_write+0x548>
    957c:	d37ceea1 	lsl	x1, x21, #4
    9580:	b7f810a3 	tbnz	x3, #63, 9794 <fwp_write+0xf04>
    9584:	91002260 	add	x0, x19, #0x8
    9588:	8b010001 	add	x1, x0, x1
    958c:	17fffdf9 	b	8d70 <fwp_write+0x4e0>
    9590:	f9400a61 	ldr	x1, [x19, #16]
    9594:	8b010000 	add	x0, x0, x1
    9598:	f9400001 	ldr	x1, [x0]
    959c:	17fffdf5 	b	8d70 <fwp_write+0x4e0>
    95a0:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    95a4:	d2800042 	mov	x2, #0x2                   	// #2
    95a8:	91342021 	add	x1, x1, #0xd08
    95ac:	17fffed6 	b	9104 <fwp_write+0x874>
    95b0:	7101fcbf 	cmp	w5, #0x7f
    95b4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    95b8:	540000e9 	b.ls	95d4 <fwp_write+0xd44>  // b.plast
    95bc:	aa1503e1 	mov	x1, x21
    95c0:	aa1403e0 	mov	x0, x20
    95c4:	d2800022 	mov	x2, #0x1                   	// #1
    95c8:	39001fe5 	strb	w5, [sp, #7]
    95cc:	97ffe811 	bl	3610 <buf_put>
    95d0:	17ffffb4 	b	94a0 <fwp_write+0xc10>
    95d4:	d2800203 	mov	x3, #0x10                  	// #16
    95d8:	d0000004 	adrp	x4, b000 <__divti3+0x110>
    95dc:	aa0303e1 	mov	x1, x3
    95e0:	91362084 	add	x4, x4, #0xd88
    95e4:	910123f6 	add	x22, sp, #0x48
    95e8:	52800042 	mov	w2, #0x2                   	// #2
    95ec:	aa1603e0 	mov	x0, x22
    95f0:	97ffe464 	bl	2780 <__snprintf_chk@plt>
    95f4:	aa1603e0 	mov	x0, x22
    95f8:	97ffe42a 	bl	26a0 <strlen@plt>
    95fc:	aa1603e1 	mov	x1, x22
    9600:	aa0003e2 	mov	x2, x0
    9604:	aa1403e0 	mov	x0, x20
    9608:	97ffe802 	bl	3610 <buf_put>
    960c:	17ffffa5 	b	94a0 <fwp_write+0xc10>
    9610:	1e604100 	fmov	d0, d8
    9614:	aa1503e0 	mov	x0, x21
    9618:	52800221 	mov	w1, #0x11                  	// #17
    961c:	97ffe93e 	bl	3b14 <fwp_format_g.constprop.0>
    9620:	17fffe43 	b	8f2c <fwp_write+0x69c>
    9624:	b9401040 	ldr	w0, [x2, #16]
    9628:	350003c0 	cbnz	w0, 96a0 <fwp_write+0xe10>
    962c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9630:	f947f400 	ldr	x0, [x0, #4072]
    9634:	f94127e2 	ldr	x2, [sp, #584]
    9638:	f9400001 	ldr	x1, [x0]
    963c:	eb010042 	subs	x2, x2, x1
    9640:	d2800001 	mov	x1, #0x0                   	// #0
    9644:	54ffd721 	b.ne	9128 <fwp_write+0x898>  // b.any
    9648:	f9413bf5 	ldr	x21, [sp, #624]
    964c:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    9650:	f9413ff6 	ldr	x22, [sp, #632]
    9654:	aa1403e0 	mov	x0, x20
    9658:	f94143f7 	ldr	x23, [sp, #640]
    965c:	91376021 	add	x1, x1, #0xdd8
    9660:	f94147f8 	ldr	x24, [sp, #648]
    9664:	d2800042 	mov	x2, #0x2                   	// #2
    9668:	17fffd0e 	b	8aa0 <fwp_write+0x210>
    966c:	d0000001 	adrp	x1, b000 <__divti3+0x110>
    9670:	d2800042 	mov	x2, #0x2                   	// #2
    9674:	91344021 	add	x1, x1, #0xd10
    9678:	17fffea3 	b	9104 <fwp_write+0x874>
    967c:	f9400a63 	ldr	x3, [x19, #16]
    9680:	8b030021 	add	x1, x1, x3
    9684:	17ffff66 	b	941c <fwp_write+0xb8c>
    9688:	f9400a61 	ldr	x1, [x19, #16]
    968c:	8b0102a1 	add	x1, x21, x1
    9690:	17fffdb3 	b	8d5c <fwp_write+0x4cc>
    9694:	f9400a63 	ldr	x3, [x19, #16]
    9698:	8b030021 	add	x1, x1, x3
    969c:	17ffff56 	b	93f4 <fwp_write+0xb64>
    96a0:	b9404840 	ldr	w0, [x2, #72]
    96a4:	91001ff5 	add	x21, sp, #0x7
    96a8:	34ffa360 	cbz	w0, 8b14 <fwp_write+0x284>
    96ac:	52800503 	mov	w3, #0x28                  	// #40
    96b0:	aa1403e0 	mov	x0, x20
    96b4:	aa1503e1 	mov	x1, x21
    96b8:	d2800022 	mov	x2, #0x1                   	// #1
    96bc:	39001fe3 	strb	w3, [sp, #7]
    96c0:	97ffe7d4 	bl	3610 <buf_put>
    96c4:	b9401380 	ldr	w0, [x28, #16]
    96c8:	52800038 	mov	w24, #0x1                   	// #1
    96cc:	7100001f 	cmp	w0, #0x0
    96d0:	54ffa36c 	b.gt	8b3c <fwp_write+0x2ac>
    96d4:	17fffd32 	b	8b9c <fwp_write+0x30c>
    96d8:	f9014bf9 	str	x25, [sp, #656]
    96dc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10600>
    96e0:	f9014ffa 	str	x26, [sp, #664]
    96e4:	f9400676 	ldr	x22, [x19, #8]
    96e8:	91104333 	add	x19, x25, #0x410
    96ec:	91002273 	add	x19, x19, #0x8
    96f0:	937ffed8 	asr	x24, x22, #63
    96f4:	aa1802c0 	orr	x0, x22, x24
    96f8:	b5000320 	cbnz	x0, 975c <fwp_write+0xecc>
    96fc:	110006b5 	add	w21, w21, #0x1
    9700:	710016bf 	cmp	w21, #0x5
    9704:	54ffffc1 	b.ne	96fc <fwp_write+0xe6c>  // b.any
    9708:	b7f80578 	tbnz	x24, #63, 97b4 <fwp_write+0xf24>
    970c:	910023f3 	add	x19, sp, #0x8
    9710:	aa1603e2 	mov	x2, x22
    9714:	aa1303e0 	mov	x0, x19
    9718:	d2800003 	mov	x3, #0x0                   	// #0
    971c:	97ffe5a1 	bl	2da0 <fwp_fmt_u128>
    9720:	910123f5 	add	x21, sp, #0x48
    9724:	d0000003 	adrp	x3, b000 <__divti3+0x110>
    9728:	aa1303e4 	mov	x4, x19
    972c:	aa1503e0 	mov	x0, x21
    9730:	91374063 	add	x3, x3, #0xdd0
    9734:	d2804002 	mov	x2, #0x200                 	// #512
    9738:	52800041 	mov	w1, #0x2                   	// #2
    973c:	97ffe3dd 	bl	26b0 <__sprintf_chk@plt>
    9740:	aa1503e0 	mov	x0, x21
    9744:	97ffe3d7 	bl	26a0 <strlen@plt>
    9748:	aa1503e1 	mov	x1, x21
    974c:	aa0003e2 	mov	x2, x0
    9750:	aa1403e0 	mov	x0, x20
    9754:	97ffe7af 	bl	3610 <buf_put>
    9758:	17fffe47 	b	9074 <fwp_write+0x7e4>
    975c:	f9400277 	ldr	x23, [x19]
    9760:	aa1603e0 	mov	x0, x22
    9764:	aa1803e1 	mov	x1, x24
    9768:	aa1703e2 	mov	x2, x23
    976c:	937ffefa 	asr	x26, x23, #63
    9770:	aa1a03e3 	mov	x3, x26
    9774:	940006bf 	bl	b270 <__modti3>
    9778:	aa010000 	orr	x0, x0, x1
    977c:	b40002c0 	cbz	x0, 97d4 <fwp_write+0xf44>
    9780:	110006b5 	add	w21, w21, #0x1
    9784:	91004273 	add	x19, x19, #0x10
    9788:	710016bf 	cmp	w21, #0x5
    978c:	54fffe81 	b.ne	975c <fwp_write+0xecc>  // b.any
    9790:	17ffffde 	b	9708 <fwp_write+0xe78>
    9794:	f9400a60 	ldr	x0, [x19, #16]
    9798:	8b000021 	add	x1, x1, x0
    979c:	17fffd75 	b	8d70 <fwp_write+0x4e0>
    97a0:	528c29c0 	mov	w0, #0x614e                	// #24910
    97a4:	910123f5 	add	x21, sp, #0x48
    97a8:	72a009c0 	movk	w0, #0x4e, lsl #16
    97ac:	b9004be0 	str	w0, [sp, #72]
    97b0:	17fffda2 	b	8e38 <fwp_write+0x5a8>
    97b4:	528005a1 	mov	w1, #0x2d                  	// #45
    97b8:	eb1603e2 	negs	x2, x22
    97bc:	da1803e3 	ngc	x3, x24
    97c0:	910027e0 	add	x0, sp, #0x9
    97c4:	910023f3 	add	x19, sp, #0x8
    97c8:	390023e1 	strb	w1, [sp, #8]
    97cc:	97ffe575 	bl	2da0 <fwp_fmt_u128>
    97d0:	17ffffd4 	b	9720 <fwp_write+0xe90>
    97d4:	aa1703e2 	mov	x2, x23
    97d8:	aa1a03e3 	mov	x3, x26
    97dc:	aa1603e0 	mov	x0, x22
    97e0:	aa1803e1 	mov	x1, x24
    97e4:	940005c3 	bl	aef0 <__divti3>
    97e8:	aa0003e2 	mov	x2, x0
    97ec:	aa0103e3 	mov	x3, x1
    97f0:	b7f80201 	tbnz	x1, #63, 9830 <fwp_write+0xfa0>
    97f4:	910023f3 	add	x19, sp, #0x8
    97f8:	aa1303e0 	mov	x0, x19
    97fc:	97ffe569 	bl	2da0 <fwp_fmt_u128>
    9800:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9804:	91104339 	add	x25, x25, #0x410
    9808:	910123f5 	add	x21, sp, #0x48
    980c:	aa1303e4 	mov	x4, x19
    9810:	aa1503e0 	mov	x0, x21
    9814:	d0000003 	adrp	x3, b000 <__divti3+0x110>
    9818:	f8616b25 	ldr	x5, [x25, x1]
    981c:	91372063 	add	x3, x3, #0xdc8
    9820:	d2804002 	mov	x2, #0x200                 	// #512
    9824:	52800041 	mov	w1, #0x2                   	// #2
    9828:	97ffe3a2 	bl	26b0 <__sprintf_chk@plt>
    982c:	17ffffc5 	b	9740 <fwp_write+0xeb0>
    9830:	528005a4 	mov	w4, #0x2d                  	// #45
    9834:	eb0003e2 	negs	x2, x0
    9838:	da0103e3 	ngc	x3, x1
    983c:	910027e0 	add	x0, sp, #0x9
    9840:	910023f3 	add	x19, sp, #0x8
    9844:	390023e4 	strb	w4, [sp, #8]
    9848:	97ffe556 	bl	2da0 <fwp_fmt_u128>
    984c:	17ffffed 	b	9800 <fwp_write+0xf70>
    9850:	f9013bf5 	str	x21, [sp, #624]
    9854:	f9013ff6 	str	x22, [sp, #632]
    9858:	f90143f7 	str	x23, [sp, #640]
    985c:	f90147f8 	str	x24, [sp, #648]
    9860:	f9014bf9 	str	x25, [sp, #656]
    9864:	f9014ffa 	str	x26, [sp, #664]
    9868:	f90153fb 	str	x27, [sp, #672]
    986c:	f90157fc 	str	x28, [sp, #680]
    9870:	fd015be8 	str	d8, [sp, #688]
    9874:	fd015fe9 	str	d9, [sp, #696]
    9878:	97ffe3e6 	bl	2810 <__stack_chk_fail@plt>
    987c:	d503201f 	nop

0000000000009880 <fwp_main_thread>:
    9880:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9884:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9888:	91190001 	add	x1, x0, #0x640
    988c:	910003fd 	mov	x29, sp
    9890:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9894:	f947f400 	ldr	x0, [x0, #4072]
    9898:	a90153f3 	stp	x19, x20, [sp, #16]
    989c:	a9025bf5 	stp	x21, x22, [sp, #32]
    98a0:	a90363f7 	stp	x23, x24, [sp, #48]
    98a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    98a8:	a90573fb 	stp	x27, x28, [sp, #80]
    98ac:	d10603ff 	sub	sp, sp, #0x180
    98b0:	b953a421 	ldr	w1, [x1, #5028]
    98b4:	f9400002 	ldr	x2, [x0]
    98b8:	f81f83a2 	stur	x2, [x29, #-8]
    98bc:	d2800002 	mov	x2, #0x0                   	// #0
    98c0:	340076a1 	cbz	w1, a794 <fwp_main_thread+0xf14>
    98c4:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    98c8:	91190000 	add	x0, x0, #0x640
    98cc:	b953a800 	ldr	w0, [x0, #5032]
    98d0:	350075a0 	cbnz	w0, a784 <fwp_main_thread+0xf04>
    98d4:	f00000a0 	adrp	x0, 20000 <__data_start>
    98d8:	f00000a2 	adrp	x2, 20000 <__data_start>
    98dc:	9101801a 	add	x26, x0, #0x60
    98e0:	91118042 	add	x2, x2, #0x460
    98e4:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    98e8:	d2a00024 	mov	x4, #0x10000               	// #65536
    98ec:	d10383b4 	sub	x20, x29, #0xe0
    98f0:	d103e3b9 	sub	x25, x29, #0xf8
    98f4:	aa1403e0 	mov	x0, x20
    98f8:	d2800001 	mov	x1, #0x0                   	// #0
    98fc:	f81203a2 	stur	x2, [x29, #-224]
    9900:	b81283bf 	stur	wzr, [x29, #-216]
    9904:	f81303a4 	stur	x4, [x29, #-208]
    9908:	a90a0f59 	stp	x25, x3, [x26, #160]
    990c:	97ffe359 	bl	2670 <sigaltstack@plt>
    9910:	3500a8a0 	cbnz	w0, ae24 <fwp_main_thread+0x15a4>
    9914:	4f000400 	movi	v0.4s, #0x0
    9918:	d10263a0 	sub	x0, x29, #0x98
    991c:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0xc>
    9920:	9100c021 	add	x1, x1, #0x30
    9924:	f81603a1 	stur	x1, [x29, #-160]
    9928:	52800082 	mov	w2, #0x4                   	// #4
    992c:	72a10002 	movk	w2, #0x800, lsl #16
    9930:	d10283b3 	sub	x19, x29, #0xa0
    9934:	3d802000 	str	q0, [x0, #128]
    9938:	b81e83a2 	stur	w2, [x29, #-24]
    993c:	ad000000 	stp	q0, q0, [x0]
    9940:	ad010000 	stp	q0, q0, [x0, #32]
    9944:	ad020000 	stp	q0, q0, [x0, #64]
    9948:	ad030000 	stp	q0, q0, [x0, #96]
    994c:	97ffe3a1 	bl	27d0 <sigemptyset@plt>
    9950:	3500a6a0 	cbnz	w0, ae24 <fwp_main_thread+0x15a4>
    9954:	aa1303e1 	mov	x1, x19
    9958:	d2800002 	mov	x2, #0x0                   	// #0
    995c:	52800160 	mov	w0, #0xb                   	// #11
    9960:	97ffe3b4 	bl	2830 <sigaction@plt>
    9964:	3500a600 	cbnz	w0, ae24 <fwp_main_thread+0x15a4>
    9968:	aa1303e1 	mov	x1, x19
    996c:	d2800002 	mov	x2, #0x0                   	// #0
    9970:	528000e0 	mov	w0, #0x7                   	// #7
    9974:	97ffe3af 	bl	2830 <sigaction@plt>
    9978:	3500a560 	cbnz	w0, ae24 <fwp_main_thread+0x15a4>
    997c:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9980:	9119001b 	add	x27, x0, #0x640
    9984:	52800037 	mov	w23, #0x1                   	// #1
    9988:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    998c:	910cc000 	add	x0, x0, #0x330
    9990:	b9013357 	str	w23, [x26, #304]
    9994:	fd4a1360 	ldr	d0, [x27, #5152]
    9998:	7e61d800 	ucvtf	d0, d0
    999c:	fd00a740 	str	d0, [x26, #328]
    99a0:	94000710 	bl	b5e0 <atexit>
    99a4:	3500a3a0 	cbnz	w0, ae18 <fwp_main_thread+0x1598>
    99a8:	b943cb40 	ldr	w0, [x26, #968]
    99ac:	34002360 	cbz	w0, 9e18 <fwp_main_thread+0x598>
    99b0:	f00000a0 	adrp	x0, 20000 <__data_start>
    99b4:	91018015 	add	x21, x0, #0x60
    99b8:	f9404eb4 	ldr	x20, [x21, #152]
    99bc:	b4000c54 	cbz	x20, 9b44 <fwp_main_thread+0x2c4>
    99c0:	aa1403f3 	mov	x19, x20
    99c4:	91010297 	add	x23, x20, #0x40
    99c8:	39414a98 	ldrb	w24, [x20, #82]
    99cc:	52800036 	mov	w22, #0x1                   	// #1
    99d0:	39014a96 	strb	w22, [x20, #82]
    99d4:	f9401680 	ldr	x0, [x20, #40]
    99d8:	b4000620 	cbz	x0, 9a9c <fwp_main_thread+0x21c>
    99dc:	f9403281 	ldr	x1, [x20, #96]
    99e0:	39414680 	ldrb	w0, [x20, #81]
    99e4:	b4000e81 	cbz	x1, 9bb4 <fwp_main_thread+0x334>
    99e8:	36000d40 	tbz	w0, #0, 9b90 <fwp_main_thread+0x310>
    99ec:	39414a62 	ldrb	w2, [x19, #82]
    99f0:	f9402281 	ldr	x1, [x20, #64]
    99f4:	370010c2 	tbnz	w2, #0, 9c0c <fwp_main_thread+0x38c>
    99f8:	f9403260 	ldr	x0, [x19, #96]
    99fc:	a911fe77 	stp	x23, xzr, [x19, #280]
    9a00:	f9009661 	str	x1, [x19, #296]
    9a04:	b4000041 	cbz	x1, 9a0c <fwp_main_thread+0x18c>
    9a08:	f9009033 	str	x19, [x1, #288]
    9a0c:	f9002293 	str	x19, [x20, #64]
    9a10:	b4000100 	cbz	x0, 9a30 <fwp_main_thread+0x1b0>
    9a14:	f94096a1 	ldr	x1, [x21, #296]
    9a18:	39015676 	strb	w22, [x19, #85]
    9a1c:	f9003660 	str	x0, [x19, #104]
    9a20:	a910867f 	stp	xzr, x1, [x19, #264]
    9a24:	b4000041 	cbz	x1, 9a2c <fwp_main_thread+0x1ac>
    9a28:	f9008433 	str	x19, [x1, #264]
    9a2c:	f90096b3 	str	x19, [x21, #296]
    9a30:	39015a7f 	strb	wzr, [x19, #86]
    9a34:	97fff390 	bl	6874 <fwp_block>
    9a38:	f9408e62 	ldr	x2, [x19, #280]
    9a3c:	b4000142 	cbz	x2, 9a64 <fwp_main_thread+0x1e4>
    9a40:	a9520261 	ldp	x1, x0, [x19, #288]
    9a44:	b4000e01 	cbz	x1, 9c04 <fwp_main_thread+0x384>
    9a48:	f9009420 	str	x0, [x1, #296]
    9a4c:	f9409660 	ldr	x0, [x19, #296]
    9a50:	b4000040 	cbz	x0, 9a58 <fwp_main_thread+0x1d8>
    9a54:	f9009001 	str	x1, [x0, #288]
    9a58:	91080260 	add	x0, x19, #0x200
    9a5c:	f900967f 	str	xzr, [x19, #296]
    9a60:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9a64:	39415660 	ldrb	w0, [x19, #85]
    9a68:	f9404ea1 	ldr	x1, [x21, #152]
    9a6c:	36000c80 	tbz	w0, #0, 9bfc <fwp_main_thread+0x37c>
    9a70:	a9508262 	ldp	x2, x0, [x19, #264]
    9a74:	b4000d82 	cbz	x2, 9c24 <fwp_main_thread+0x3a4>
    9a78:	f9008840 	str	x0, [x2, #272]
    9a7c:	b4000040 	cbz	x0, 9a84 <fwp_main_thread+0x204>
    9a80:	f9008402 	str	x2, [x0, #264]
    9a84:	91080260 	add	x0, x19, #0x200
    9a88:	3901567f 	strb	wzr, [x19, #85]
    9a8c:	aa0103f3 	mov	x19, x1
    9a90:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9a94:	f9401680 	ldr	x0, [x20, #40]
    9a98:	b5fffa20 	cbnz	x0, 99dc <fwp_main_thread+0x15c>
    9a9c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9aa0:	91018000 	add	x0, x0, #0x60
    9aa4:	39014a98 	strb	w24, [x20, #82]
    9aa8:	f941d400 	ldr	x0, [x0, #936]
    9aac:	b4000520 	cbz	x0, 9b50 <fwp_main_thread+0x2d0>
    9ab0:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ab4:	91018000 	add	x0, x0, #0x60
    9ab8:	f941f001 	ldr	x1, [x0, #992]
    9abc:	b903d81f 	str	wzr, [x0, #984]
    9ac0:	eb13003f 	cmp	x1, x19
    9ac4:	54000641 	b.ne	9b8c <fwp_main_thread+0x30c>  // b.any
    9ac8:	b4000bd3 	cbz	x19, 9c40 <fwp_main_thread+0x3c0>
    9acc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ad0:	91018000 	add	x0, x0, #0x60
    9ad4:	52800021 	mov	w1, #0x1                   	// #1
    9ad8:	39014a61 	strb	w1, [x19, #82]
    9adc:	f941c005 	ldr	x5, [x0, #896]
    9ae0:	b4000b05 	cbz	x5, 9c40 <fwp_main_thread+0x3c0>
    9ae4:	394140a0 	ldrb	w0, [x5, #80]
    9ae8:	37000060 	tbnz	w0, #0, 9af4 <fwp_main_thread+0x274>
    9aec:	aa0503e0 	mov	x0, x5
    9af0:	97ffe6e0 	bl	3670 <fwp_cancel_tree.part.0>
    9af4:	f9409ca5 	ldr	x5, [x5, #312]
    9af8:	b5ffff65 	cbnz	x5, 9ae4 <fwp_main_thread+0x264>
    9afc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b00:	91018014 	add	x20, x0, #0x60
    9b04:	52800035 	mov	w21, #0x1                   	// #1
    9b08:	f9402a60 	ldr	x0, [x19, #80]
    9b0c:	f2001c1f 	tst	x0, #0xff000000ff
    9b10:	540000e1 	b.ne	9b2c <fwp_main_thread+0x2ac>  // b.any
    9b14:	f9406280 	ldr	x0, [x20, #192]
    9b18:	39015275 	strb	w21, [x19, #84]
    9b1c:	f900827f 	str	xzr, [x19, #256]
    9b20:	b4000860 	cbz	x0, 9c2c <fwp_main_thread+0x3ac>
    9b24:	f9008013 	str	x19, [x0, #256]
    9b28:	f9006293 	str	x19, [x20, #192]
    9b2c:	97fff352 	bl	6874 <fwp_block>
    9b30:	97fff2e4 	bl	66c0 <fwp_free_zombie>
    9b34:	f941c280 	ldr	x0, [x20, #896]
    9b38:	b4000840 	cbz	x0, 9c40 <fwp_main_thread+0x3c0>
    9b3c:	f941f293 	ldr	x19, [x20, #992]
    9b40:	17fffff2 	b	9b08 <fwp_main_thread+0x288>
    9b44:	f941d6a0 	ldr	x0, [x21, #936]
    9b48:	b5000760 	cbnz	x0, 9c34 <fwp_main_thread+0x3b4>
    9b4c:	d2800013 	mov	x19, #0x0                   	// #0
    9b50:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b54:	91018014 	add	x20, x0, #0x60
    9b58:	f941de80 	ldr	x0, [x20, #952]
    9b5c:	b5fffaa0 	cbnz	x0, 9ab0 <fwp_main_thread+0x230>
    9b60:	f941d280 	ldr	x0, [x20, #928]
    9b64:	97ffec2b 	bl	4c10 <fwp_mem_free>
    9b68:	f901d29f 	str	xzr, [x20, #928]
    9b6c:	f901da9f 	str	xzr, [x20, #944]
    9b70:	f941f280 	ldr	x0, [x20, #992]
    9b74:	b4009a93 	cbz	x19, aec4 <fwp_main_thread+0x1644>
    9b78:	f900567f 	str	xzr, [x19, #168]
    9b7c:	f9005e7f 	str	xzr, [x19, #184]
    9b80:	b903da9f 	str	wzr, [x20, #984]
    9b84:	eb00027f 	cmp	x19, x0
    9b88:	54fffa20 	b.eq	9acc <fwp_main_thread+0x24c>  // b.none
    9b8c:	97ffe335 	bl	2860 <abort@plt>
    9b90:	97ffe75c 	bl	3900 <fwp_now_ns>
    9b94:	f9403281 	ldr	x1, [x20, #96]
    9b98:	eb01001f 	cmp	x0, x1
    9b9c:	540000ab 	b.lt	9bb0 <fwp_main_thread+0x330>  // b.tstop
    9ba0:	39414280 	ldrb	w0, [x20, #80]
    9ba4:	37000060 	tbnz	w0, #0, 9bb0 <fwp_main_thread+0x330>
    9ba8:	aa1403e0 	mov	x0, x20
    9bac:	97ffe6b1 	bl	3670 <fwp_cancel_tree.part.0>
    9bb0:	39414680 	ldrb	w0, [x20, #81]
    9bb4:	39414a62 	ldrb	w2, [x19, #82]
    9bb8:	3707f1c0 	tbnz	w0, #0, 99f0 <fwp_main_thread+0x170>
    9bbc:	f9403280 	ldr	x0, [x20, #96]
    9bc0:	370001a2 	tbnz	w2, #0, 9bf4 <fwp_main_thread+0x374>
    9bc4:	f9403261 	ldr	x1, [x19, #96]
    9bc8:	b4000161 	cbz	x1, 9bf4 <fwp_main_thread+0x374>
    9bcc:	b4008f40 	cbz	x0, adb4 <fwp_main_thread+0x1534>
    9bd0:	eb01001f 	cmp	x0, x1
    9bd4:	9a81d000 	csel	x0, x0, x1, le
    9bd8:	f9402281 	ldr	x1, [x20, #64]
    9bdc:	a911fe77 	stp	x23, xzr, [x19, #280]
    9be0:	f9009661 	str	x1, [x19, #296]
    9be4:	b4000041 	cbz	x1, 9bec <fwp_main_thread+0x36c>
    9be8:	f9009033 	str	x19, [x1, #288]
    9bec:	f9002293 	str	x19, [x20, #64]
    9bf0:	17ffff89 	b	9a14 <fwp_main_thread+0x194>
    9bf4:	f9402281 	ldr	x1, [x20, #64]
    9bf8:	17ffff81 	b	99fc <fwp_main_thread+0x17c>
    9bfc:	aa0103f3 	mov	x19, x1
    9c00:	17ffff75 	b	99d4 <fwp_main_thread+0x154>
    9c04:	f9000040 	str	x0, [x2]
    9c08:	17ffff92 	b	9a50 <fwp_main_thread+0x1d0>
    9c0c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9c10:	f9009661 	str	x1, [x19, #296]
    9c14:	b4000041 	cbz	x1, 9c1c <fwp_main_thread+0x39c>
    9c18:	f9009033 	str	x19, [x1, #288]
    9c1c:	f9002293 	str	x19, [x20, #64]
    9c20:	17ffff84 	b	9a30 <fwp_main_thread+0x1b0>
    9c24:	f90096a0 	str	x0, [x21, #296]
    9c28:	17ffff95 	b	9a7c <fwp_main_thread+0x1fc>
    9c2c:	f9006693 	str	x19, [x20, #200]
    9c30:	17ffffbe 	b	9b28 <fwp_main_thread+0x2a8>
    9c34:	f941f2a0 	ldr	x0, [x21, #992]
    9c38:	b903dabf 	str	wzr, [x21, #984]
    9c3c:	b5fffa80 	cbnz	x0, 9b8c <fwp_main_thread+0x30c>
    9c40:	97fff2a0 	bl	66c0 <fwp_free_zombie>
    9c44:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c48:	91018015 	add	x21, x0, #0x60
    9c4c:	f94066a0 	ldr	x0, [x21, #200]
    9c50:	b5fff9e0 	cbnz	x0, 9b8c <fwp_main_thread+0x30c>
    9c54:	f94096a0 	ldr	x0, [x21, #296]
    9c58:	b5fff9a0 	cbnz	x0, 9b8c <fwp_main_thread+0x30c>
    9c5c:	b94172a0 	ldr	w0, [x21, #368]
    9c60:	340001c0 	cbz	w0, 9c98 <fwp_main_thread+0x418>
    9c64:	93407c14 	sxtw	x20, w0
    9c68:	51000400 	sub	w0, w0, #0x1
    9c6c:	d1000a94 	sub	x20, x20, #0x2
    9c70:	910602b6 	add	x22, x21, #0x180
    9c74:	cb204294 	sub	x20, x20, w0, uxtw
    9c78:	93407c13 	sxtw	x19, w0
    9c7c:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    9c80:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9c84:	b90172b3 	str	w19, [x21, #368]
    9c88:	d1000673 	sub	x19, x19, #0x1
    9c8c:	97ffe329 	bl	2930 <munmap@plt>
    9c90:	eb14027f 	cmp	x19, x20
    9c94:	54ffff41 	b.ne	9c7c <fwp_main_thread+0x3fc>  // b.any
    9c98:	f00000a4 	adrp	x4, 20000 <__data_start>
    9c9c:	91004080 	add	x0, x4, #0x10
    9ca0:	b9403000 	ldr	w0, [x0, #48]
    9ca4:	37f800c0 	tbnz	w0, #31, 9cbc <fwp_main_thread+0x43c>
    9ca8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9cac:	f91f7c24 	str	x4, [x1, #16120]
    9cb0:	97ffe2dc 	bl	2820 <close@plt>
    9cb4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9cb8:	f95f7c04 	ldr	x4, [x0, #16120]
    9cbc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9cc0:	91018000 	add	x0, x0, #0x60
    9cc4:	91004084 	add	x4, x4, #0x10
    9cc8:	12800001 	mov	w1, #0xffffffff            	// #-1
    9ccc:	d2800013 	mov	x19, #0x0                   	// #0
    9cd0:	f941f415 	ldr	x21, [x0, #1000]
    9cd4:	b9003081 	str	w1, [x4, #48]
    9cd8:	f941f814 	ldr	x20, [x0, #1008]
    9cdc:	b4000175 	cbz	x21, 9d08 <fwp_main_thread+0x488>
    9ce0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    9ce4:	b40000c0 	cbz	x0, 9cfc <fwp_main_thread+0x47c>
    9ce8:	f9400001 	ldr	x1, [x0]
    9cec:	b5fff501 	cbnz	x1, 9b8c <fwp_main_thread+0x30c>
    9cf0:	f9400401 	ldr	x1, [x0, #8]
    9cf4:	b5fff4c1 	cbnz	x1, 9b8c <fwp_main_thread+0x30c>
    9cf8:	97ffebc6 	bl	4c10 <fwp_mem_free>
    9cfc:	91000673 	add	x19, x19, #0x1
    9d00:	eb1302bf 	cmp	x21, x19
    9d04:	54fffee1 	b.ne	9ce0 <fwp_main_thread+0x460>  // b.any
    9d08:	aa1403e0 	mov	x0, x20
    9d0c:	97ffebc1 	bl	4c10 <fwp_mem_free>
    9d10:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d14:	91018000 	add	x0, x0, #0x60
    9d18:	f941f013 	ldr	x19, [x0, #992]
    9d1c:	f901f41f 	str	xzr, [x0, #1000]
    9d20:	f901f81f 	str	xzr, [x0, #1008]
    9d24:	b40001f3 	cbz	x19, 9d60 <fwp_main_thread+0x4e0>
    9d28:	f9401661 	ldr	x1, [x19, #40]
    9d2c:	b5fff301 	cbnz	x1, 9b8c <fwp_main_thread+0x30c>
    9d30:	f9405661 	ldr	x1, [x19, #168]
    9d34:	b5fff2c1 	cbnz	x1, 9b8c <fwp_main_thread+0x30c>
    9d38:	f941d401 	ldr	x1, [x0, #936]
    9d3c:	b5fff281 	cbnz	x1, 9b8c <fwp_main_thread+0x30c>
    9d40:	f941dc00 	ldr	x0, [x0, #952]
    9d44:	b5fff240 	cbnz	x0, 9b8c <fwp_main_thread+0x30c>
    9d48:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9d4c:	f0000360 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    9d50:	91118000 	add	x0, x0, #0x460
    9d54:	97ffe2a3 	bl	27e0 <memset@plt>
    9d58:	aa1303e0 	mov	x0, x19
    9d5c:	97ffebad 	bl	4c10 <fwp_mem_free>
    9d60:	f00000a1 	adrp	x1, 20000 <__data_start>
    9d64:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9d68:	91018026 	add	x6, x1, #0x60
    9d6c:	91190000 	add	x0, x0, #0x640
    9d70:	3dc01821 	ldr	q1, [x1, #96]
    9d74:	d0000002 	adrp	x2, b000 <__divti3+0x110>
    9d78:	3dc004c2 	ldr	q2, [x6, #16]
    9d7c:	91392042 	add	x2, x2, #0xe48
    9d80:	fd4a1000 	ldr	d0, [x0, #5152]
    9d84:	52800041 	mov	w1, #0x2                   	// #2
    9d88:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    9d8c:	fd40a4c1 	ldr	d1, [x6, #328]
    9d90:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9d94:	f947e800 	ldr	x0, [x0, #4048]
    9d98:	7e61d800 	ucvtf	d0, d0
    9d9c:	a95390c3 	ldp	x3, x4, [x6, #312]
    9da0:	f9004cdf 	str	xzr, [x6, #152]
    9da4:	f9400000 	ldr	x0, [x0]
    9da8:	1e613801 	fsub	d1, d0, d1
    9dac:	f940acc5 	ldr	x5, [x6, #344]
    9db0:	b90130df 	str	wzr, [x6, #304]
    9db4:	5ef1b842 	addp	d2, v2.2d
    9db8:	fd40a8c0 	ldr	d0, [x6, #336]
    9dbc:	f901f0df 	str	xzr, [x6, #992]
    9dc0:	fd0058c2 	str	d2, [x6, #176]
    9dc4:	97ffe2af 	bl	2880 <__fprintf_chk@plt>
    9dc8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9dcc:	f947ec00 	ldr	x0, [x0, #4056]
    9dd0:	f9400000 	ldr	x0, [x0]
    9dd4:	97ffe2db 	bl	2940 <fflush@plt>
    9dd8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9ddc:	f947f400 	ldr	x0, [x0, #4072]
    9de0:	f85f83a2 	ldur	x2, [x29, #-8]
    9de4:	f9400001 	ldr	x1, [x0]
    9de8:	eb010042 	subs	x2, x2, x1
    9dec:	d2800001 	mov	x1, #0x0                   	// #0
    9df0:	54008281 	b.ne	ae40 <fwp_main_thread+0x15c0>  // b.any
    9df4:	910003bf 	mov	sp, x29
    9df8:	d2800000 	mov	x0, #0x0                   	// #0
    9dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    9e00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9e04:	a94363f7 	ldp	x23, x24, [sp, #48]
    9e08:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9e0c:	a94573fb 	ldp	x27, x28, [sp, #80]
    9e10:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9e14:	d65f03c0 	ret
    9e18:	f941cb42 	ldr	x2, [x26, #912]
    9e1c:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0xd0>
    9e20:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9e24:	913e8000 	add	x0, x0, #0xfa0
    9e28:	913b4021 	add	x1, x1, #0xed0
    9e2c:	d2800015 	mov	x21, #0x0                   	// #0
    9e30:	d2800418 	mov	x24, #0x20                  	// #32
    9e34:	d2800016 	mov	x22, #0x0                   	// #0
    9e38:	a93087a2 	stp	x2, x1, [x29, #-248]
    9e3c:	a931ffb4 	stp	x20, xzr, [x29, #-232]
    9e40:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9e44:	f901cb59 	str	x25, [x26, #912]
    9e48:	f100071a 	subs	x26, x24, #0x1
    9e4c:	aa1303e1 	mov	x1, x19
    9e50:	da1f02dc 	sbc	x28, x22, xzr
    9e54:	52800020 	mov	w0, #0x1                   	// #1
    9e58:	f81283ba 	stur	x26, [x29, #-216]
    9e5c:	aa1a03f8 	mov	x24, x26
    9e60:	a93657ba 	stp	x26, x21, [x29, #-160]
    9e64:	97ffee93 	bl	58b0 <fwp_data.part.0.constprop.0>
    9e68:	aa0003f5 	mov	x21, x0
    9e6c:	f949db62 	ldr	x2, [x27, #5040]
    9e70:	aa1c03f6 	mov	x22, x28
    9e74:	f949ef60 	ldr	x0, [x27, #5080]
    9e78:	cb0202a2 	sub	x2, x21, x2
    9e7c:	eb00405f 	cmp	x2, x0, lsl #16
    9e80:	54000302 	b.cs	9ee0 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9e84:	d350fc40 	lsr	x0, x2, #16
    9e88:	f949ff63 	ldr	x3, [x27, #5112]
    9e8c:	8b000800 	add	x0, x0, x0, lsl #2
    9e90:	d37df001 	lsl	x1, x0, #3
    9e94:	8b010060 	add	x0, x3, x1
    9e98:	f9401019 	ldr	x25, [x0, #32]
    9e9c:	b4000239 	cbz	x25, 9ee0 <fwp_main_thread+0x660>
    9ea0:	38616861 	ldrb	w1, [x3, x1]
    9ea4:	7100083f 	cmp	w1, #0x2
    9ea8:	540045e0 	b.eq	a764 <fwp_main_thread+0xee4>  // b.none
    9eac:	7100043f 	cmp	w1, #0x1
    9eb0:	54000181 	b.ne	9ee0 <fwp_main_thread+0x660>  // b.any
    9eb4:	29430003 	ldp	w3, w0, [x0, #24]
    9eb8:	92403c41 	and	x1, x2, #0xffff
    9ebc:	9b037c21 	mul	x1, x1, x3
    9ec0:	d360fc21 	lsr	x1, x1, #32
    9ec4:	eb00003f 	cmp	x1, x0
    9ec8:	540000c2 	b.cs	9ee0 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9ecc:	8b010339 	add	x25, x25, x1
    9ed0:	39400320 	ldrb	w0, [x25]
    9ed4:	7103fc1f 	cmp	w0, #0xff
    9ed8:	54004500 	b.eq	a778 <fwp_main_thread+0xef8>  // b.none
    9edc:	39000337 	strb	w23, [x25]
    9ee0:	f81203b5 	stur	x21, [x29, #-224]
    9ee4:	aa1c0340 	orr	x0, x26, x28
    9ee8:	b5fffb00 	cbnz	x0, 9e48 <fwp_main_thread+0x5c8>
    9eec:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0x9f0>
    9ef0:	d10303a1 	sub	x1, x29, #0xc0
    9ef4:	f85083a3 	ldur	x3, [x29, #-248]
    9ef8:	3dc17400 	ldr	q0, [x0, #1488]
    9efc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f00:	91018002 	add	x2, x0, #0x60
    9f04:	52800020 	mov	w0, #0x1                   	// #1
    9f08:	3c9403a0 	stur	q0, [x29, #-192]
    9f0c:	f901c843 	str	x3, [x2, #912]
    9f10:	97ffee68 	bl	58b0 <fwp_data.part.0.constprop.0>
    9f14:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9f18:	91190022 	add	x2, x1, #0x640
    9f1c:	aa0003f7 	mov	x23, x0
    9f20:	f949d841 	ldr	x1, [x2, #5040]
    9f24:	f949ec40 	ldr	x0, [x2, #5080]
    9f28:	cb0102e1 	sub	x1, x23, x1
    9f2c:	eb00403f 	cmp	x1, x0, lsl #16
    9f30:	54000322 	b.cs	9f94 <fwp_main_thread+0x714>  // b.hs, b.nlast
    9f34:	d350fc20 	lsr	x0, x1, #16
    9f38:	f949fc43 	ldr	x3, [x2, #5112]
    9f3c:	8b000800 	add	x0, x0, x0, lsl #2
    9f40:	d37df002 	lsl	x2, x0, #3
    9f44:	8b020060 	add	x0, x3, x2
    9f48:	f9401016 	ldr	x22, [x0, #32]
    9f4c:	b4000256 	cbz	x22, 9f94 <fwp_main_thread+0x714>
    9f50:	38626862 	ldrb	w2, [x3, x2]
    9f54:	7100085f 	cmp	w2, #0x2
    9f58:	540071c0 	b.eq	ad90 <fwp_main_thread+0x1510>  // b.none
    9f5c:	7100045f 	cmp	w2, #0x1
    9f60:	540001a1 	b.ne	9f94 <fwp_main_thread+0x714>  // b.any
    9f64:	29430002 	ldp	w2, w0, [x0, #24]
    9f68:	92403c21 	and	x1, x1, #0xffff
    9f6c:	9b027c21 	mul	x1, x1, x2
    9f70:	d360fc21 	lsr	x1, x1, #32
    9f74:	eb00003f 	cmp	x1, x0
    9f78:	540000e2 	b.cs	9f94 <fwp_main_thread+0x714>  // b.hs, b.nlast
    9f7c:	8b0102d6 	add	x22, x22, x1
    9f80:	394002c0 	ldrb	w0, [x22]
    9f84:	7103fc1f 	cmp	w0, #0xff
    9f88:	54007320 	b.eq	adec <fwp_main_thread+0x156c>  // b.none
    9f8c:	52800020 	mov	w0, #0x1                   	// #1
    9f90:	390002c0 	strb	w0, [x22]
    9f94:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9f98:	aa1303e1 	mov	x1, x19
    9f9c:	52800020 	mov	w0, #0x1                   	// #1
    9fa0:	a9365fa2 	stp	x2, x23, [x29, #-160]
    9fa4:	97ffee43 	bl	58b0 <fwp_data.part.0.constprop.0>
    9fa8:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9fac:	91190022 	add	x2, x1, #0x640
    9fb0:	aa0003f6 	mov	x22, x0
    9fb4:	f949d841 	ldr	x1, [x2, #5040]
    9fb8:	f949ec40 	ldr	x0, [x2, #5080]
    9fbc:	cb0102c1 	sub	x1, x22, x1
    9fc0:	eb00403f 	cmp	x1, x0, lsl #16
    9fc4:	54000322 	b.cs	a028 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    9fc8:	d350fc20 	lsr	x0, x1, #16
    9fcc:	f949fc43 	ldr	x3, [x2, #5112]
    9fd0:	8b000800 	add	x0, x0, x0, lsl #2
    9fd4:	d37df002 	lsl	x2, x0, #3
    9fd8:	8b020060 	add	x0, x3, x2
    9fdc:	f9401013 	ldr	x19, [x0, #32]
    9fe0:	b4000253 	cbz	x19, a028 <fwp_main_thread+0x7a8>
    9fe4:	38626862 	ldrb	w2, [x3, x2]
    9fe8:	7100085f 	cmp	w2, #0x2
    9fec:	54006cc0 	b.eq	ad84 <fwp_main_thread+0x1504>  // b.none
    9ff0:	7100045f 	cmp	w2, #0x1
    9ff4:	540001a1 	b.ne	a028 <fwp_main_thread+0x7a8>  // b.any
    9ff8:	29430002 	ldp	w2, w0, [x0, #24]
    9ffc:	92403c21 	and	x1, x1, #0xffff
    a000:	9b027c21 	mul	x1, x1, x2
    a004:	d360fc21 	lsr	x1, x1, #32
    a008:	eb00003f 	cmp	x1, x0
    a00c:	540000e2 	b.cs	a028 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    a010:	8b010273 	add	x19, x19, x1
    a014:	39400260 	ldrb	w0, [x19]
    a018:	7103fc1f 	cmp	w0, #0xff
    a01c:	54006f20 	b.eq	ae00 <fwp_main_thread+0x1580>  // b.none
    a020:	52800020 	mov	w0, #0x1                   	// #1
    a024:	39000260 	strb	w0, [x19]
    a028:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a02c:	d102c3a1 	sub	x1, x29, #0xb0
    a030:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a034:	52800020 	mov	w0, #0x1                   	// #1
    a038:	a9355ba2 	stp	x2, x22, [x29, #-176]
    a03c:	97ffee1d 	bl	58b0 <fwp_data.part.0.constprop.0>
    a040:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a044:	91190022 	add	x2, x1, #0x640
    a048:	aa0003f8 	mov	x24, x0
    a04c:	f949d841 	ldr	x1, [x2, #5040]
    a050:	f949ec40 	ldr	x0, [x2, #5080]
    a054:	cb010301 	sub	x1, x24, x1
    a058:	eb00403f 	cmp	x1, x0, lsl #16
    a05c:	54000322 	b.cs	a0c0 <fwp_main_thread+0x840>  // b.hs, b.nlast
    a060:	d350fc20 	lsr	x0, x1, #16
    a064:	f949fc43 	ldr	x3, [x2, #5112]
    a068:	8b000800 	add	x0, x0, x0, lsl #2
    a06c:	d37df002 	lsl	x2, x0, #3
    a070:	8b020060 	add	x0, x3, x2
    a074:	f9401013 	ldr	x19, [x0, #32]
    a078:	b4000253 	cbz	x19, a0c0 <fwp_main_thread+0x840>
    a07c:	38626862 	ldrb	w2, [x3, x2]
    a080:	7100085f 	cmp	w2, #0x2
    a084:	540068c0 	b.eq	ad9c <fwp_main_thread+0x151c>  // b.none
    a088:	7100045f 	cmp	w2, #0x1
    a08c:	540001a1 	b.ne	a0c0 <fwp_main_thread+0x840>  // b.any
    a090:	29430002 	ldp	w2, w0, [x0, #24]
    a094:	92403c21 	and	x1, x1, #0xffff
    a098:	9b027c21 	mul	x1, x1, x2
    a09c:	d360fc21 	lsr	x1, x1, #32
    a0a0:	eb00003f 	cmp	x1, x0
    a0a4:	540000e2 	b.cs	a0c0 <fwp_main_thread+0x840>  // b.hs, b.nlast
    a0a8:	8b010273 	add	x19, x19, x1
    a0ac:	39400260 	ldrb	w0, [x19]
    a0b0:	7103fc1f 	cmp	w0, #0xff
    a0b4:	54006ac0 	b.eq	ae0c <fwp_main_thread+0x158c>  // b.none
    a0b8:	52800020 	mov	w0, #0x1                   	// #1
    a0bc:	39000260 	strb	w0, [x19]
    a0c0:	b40033f5 	cbz	x21, a73c <fwp_main_thread+0xebc>
    a0c4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a0c8:	d00000a4 	adrp	x4, 20000 <__data_start>
    a0cc:	9101801c 	add	x28, x0, #0x60
    a0d0:	9100409b 	add	x27, x4, #0x10
    a0d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0d8:	9100a37b 	add	x27, x27, #0x28
    a0dc:	aa1b03f6 	mov	x22, x27
    a0e0:	aa1503f7 	mov	x23, x21
    a0e4:	aa1c03fb 	mov	x27, x28
    a0e8:	aa0403f3 	mov	x19, x4
    a0ec:	f91f5415 	str	x21, [x0, #16040]
    a0f0:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a0f4:	91190002 	add	x2, x0, #0x640
    a0f8:	f949d841 	ldr	x1, [x2, #5040]
    a0fc:	f949ec40 	ldr	x0, [x2, #5080]
    a100:	cb010301 	sub	x1, x24, x1
    a104:	eb00403f 	cmp	x1, x0, lsl #16
    a108:	54000422 	b.cs	a18c <fwp_main_thread+0x90c>  // b.hs, b.nlast
    a10c:	d350fc20 	lsr	x0, x1, #16
    a110:	f949fc44 	ldr	x4, [x2, #5112]
    a114:	8b000800 	add	x0, x0, x0, lsl #2
    a118:	d37df002 	lsl	x2, x0, #3
    a11c:	8b020083 	add	x3, x4, x2
    a120:	f9401060 	ldr	x0, [x3, #32]
    a124:	b4000340 	cbz	x0, a18c <fwp_main_thread+0x90c>
    a128:	38626882 	ldrb	w2, [x4, x2]
    a12c:	7100085f 	cmp	w2, #0x2
    a130:	540063c0 	b.eq	ada8 <fwp_main_thread+0x1528>  // b.none
    a134:	7100045f 	cmp	w2, #0x1
    a138:	540002a1 	b.ne	a18c <fwp_main_thread+0x90c>  // b.any
    a13c:	29430864 	ldp	w4, w2, [x3, #24]
    a140:	92403c21 	and	x1, x1, #0xffff
    a144:	9b047c21 	mul	x1, x1, x4
    a148:	d360fc21 	lsr	x1, x1, #32
    a14c:	eb02003f 	cmp	x1, x2
    a150:	540001e2 	b.cs	a18c <fwp_main_thread+0x90c>  // b.hs, b.nlast
    a154:	8b010000 	add	x0, x0, x1
    a158:	39400001 	ldrb	w1, [x0]
    a15c:	34000181 	cbz	w1, a18c <fwp_main_thread+0x90c>
    a160:	d00000a2 	adrp	x2, 20000 <__data_start>
    a164:	91018042 	add	x2, x2, #0x60
    a168:	b9413043 	ldr	w3, [x2, #304]
    a16c:	34000083 	cbz	w3, a17c <fwp_main_thread+0x8fc>
    a170:	f940ac43 	ldr	x3, [x2, #344]
    a174:	91000463 	add	x3, x3, #0x1
    a178:	f900ac43 	str	x3, [x2, #344]
    a17c:	7103f43f 	cmp	w1, #0xfd
    a180:	540063c8 	b.hi	adf8 <fwp_main_thread+0x1578>  // b.pmore
    a184:	11000421 	add	w1, w1, #0x1
    a188:	39000001 	strb	w1, [x0]
    a18c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a190:	aa1603e6 	mov	x6, x22
    a194:	aa1303f9 	mov	x25, x19
    a198:	d28018fc 	mov	x28, #0xc7                  	// #199
    a19c:	f91f4c17 	str	x23, [x0, #16024]
    a1a0:	aa1803f7 	mov	x23, x24
    a1a4:	f91f5018 	str	x24, [x0, #16032]
    a1a8:	f91f581c 	str	x28, [x0, #16048]
    a1ac:	91004320 	add	x0, x25, #0x10
    a1b0:	f9406b63 	ldr	x3, [x27, #208]
    a1b4:	9100a005 	add	x5, x0, #0x28
    a1b8:	b9402802 	ldr	w2, [x0, #40]
    a1bc:	d37be842 	lsl	x2, x2, #5
    a1c0:	8b020064 	add	x4, x3, x2
    a1c4:	f9400c81 	ldr	x1, [x4, #24]
    a1c8:	f81203b7 	stur	x23, [x29, #-224]
    a1cc:	b4005f81 	cbz	x1, adbc <fwp_main_thread+0x153c>
    a1d0:	f9400c20 	ldr	x0, [x1, #24]
    a1d4:	b4004ea0 	cbz	x0, aba8 <fwp_main_thread+0x1328>
    a1d8:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a1dc:	91190002 	add	x2, x0, #0x640
    a1e0:	f949d841 	ldr	x1, [x2, #5040]
    a1e4:	f949ec40 	ldr	x0, [x2, #5080]
    a1e8:	cb0100c1 	sub	x1, x6, x1
    a1ec:	eb00403f 	cmp	x1, x0, lsl #16
    a1f0:	540003e2 	b.cs	a26c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    a1f4:	d350fc20 	lsr	x0, x1, #16
    a1f8:	f949fc45 	ldr	x5, [x2, #5112]
    a1fc:	8b000800 	add	x0, x0, x0, lsl #2
    a200:	d37df002 	lsl	x2, x0, #3
    a204:	8b0200a3 	add	x3, x5, x2
    a208:	f9401060 	ldr	x0, [x3, #32]
    a20c:	b4000300 	cbz	x0, a26c <fwp_main_thread+0x9ec>
    a210:	386268a2 	ldrb	w2, [x5, x2]
    a214:	7100085f 	cmp	w2, #0x2
    a218:	540053c0 	b.eq	ac90 <fwp_main_thread+0x1410>  // b.none
    a21c:	7100045f 	cmp	w2, #0x1
    a220:	54000261 	b.ne	a26c <fwp_main_thread+0x9ec>  // b.any
    a224:	29430865 	ldp	w5, w2, [x3, #24]
    a228:	92403c21 	and	x1, x1, #0xffff
    a22c:	9b057c21 	mul	x1, x1, x5
    a230:	d360fc21 	lsr	x1, x1, #32
    a234:	eb02003f 	cmp	x1, x2
    a238:	540001a2 	b.cs	a26c <fwp_main_thread+0x9ec>  // b.hs, b.nlast
    a23c:	8b010000 	add	x0, x0, x1
    a240:	39400001 	ldrb	w1, [x0]
    a244:	34000141 	cbz	w1, a26c <fwp_main_thread+0x9ec>
    a248:	b9413362 	ldr	w2, [x27, #304]
    a24c:	34000082 	cbz	w2, a25c <fwp_main_thread+0x9dc>
    a250:	f940af62 	ldr	x2, [x27, #344]
    a254:	91000442 	add	x2, x2, #0x1
    a258:	f900af62 	str	x2, [x27, #344]
    a25c:	7103f43f 	cmp	w1, #0xfd
    a260:	540056e8 	b.hi	ad3c <fwp_main_thread+0x14bc>  // b.pmore
    a264:	11000421 	add	w1, w1, #0x1
    a268:	39000001 	strb	w1, [x0]
    a26c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a270:	52800020 	mov	w0, #0x1                   	// #1
    a274:	2a0003f8 	mov	w24, w0
    a278:	aa0603f7 	mov	x23, x6
    a27c:	aa1903fc 	mov	x28, x25
    a280:	b93ee820 	str	w0, [x1, #16104]
    a284:	aa0103e0 	mov	x0, x1
    a288:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a28c:	91190035 	add	x21, x1, #0x640
    a290:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a294:	f91f7814 	str	x20, [x0, #16112]
    a298:	aa0603e0 	mov	x0, x6
    a29c:	f91f5c34 	str	x20, [x1, #16056]
    a2a0:	f91f6026 	str	x6, [x1, #16064]
    a2a4:	b93eec38 	str	w24, [x1, #16108]
    a2a8:	b9400401 	ldr	w1, [x0, #4]
    a2ac:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2b0:	b9400096 	ldr	w22, [x4]
    a2b4:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a2b8:	b97eec00 	ldr	w0, [x0, #16108]
    a2bc:	4b0102d6 	sub	w22, w22, w1
    a2c0:	6b0002df 	cmp	w22, w0
    a2c4:	1a8092c7 	csel	w7, w22, w0, ls	// ls = plast
    a2c8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2cc:	b97ee800 	ldr	w0, [x0, #16104]
    a2d0:	6b0000ff 	cmp	w7, w0
    a2d4:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    a2d8:	b93ee440 	str	w0, [x2, #16100]
    a2dc:	6b0000e2 	subs	w2, w7, w0
    a2e0:	54000180 	b.eq	a310 <fwp_main_thread+0xa90>  // b.none
    a2e4:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a2e8:	0b000021 	add	w1, w1, w0
    a2ec:	b93ef867 	str	w7, [x3, #16120]
    a2f0:	f9400c83 	ldr	x3, [x4, #24]
    a2f4:	d14013a4 	sub	x4, x29, #0x4, lsl #12
    a2f8:	f9400863 	ldr	x3, [x3, #16]
    a2fc:	f95f7884 	ldr	x4, [x4, #16112]
    a300:	8b204c80 	add	x0, x4, w0, uxtw #3
    a304:	d63f0060 	blr	x3
    a308:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a30c:	b97ef807 	ldr	w7, [x0, #16120]
    a310:	f9406b60 	ldr	x0, [x27, #208]
    a314:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a318:	b94002e3 	ldr	w3, [x23]
    a31c:	aa1703e5 	mov	x5, x23
    a320:	2a0703f4 	mov	w20, w7
    a324:	aa1703f9 	mov	x25, x23
    a328:	f95f7838 	ldr	x24, [x1, #16112]
    a32c:	8b031403 	add	x3, x0, x3, lsl #5
    a330:	f9400c60 	ldr	x0, [x3, #24]
    a334:	b4002460 	cbz	x0, a7c0 <fwp_main_thread+0xf40>
    a338:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a33c:	f91f643c 	str	x28, [x1, #16072]
    a340:	b93ed027 	str	w7, [x1, #16080]
    a344:	b93ed836 	str	w22, [x1, #16088]
    a348:	aa0303f6 	mov	x22, x3
    a34c:	14000012 	b	a394 <fwp_main_thread+0xb14>
    a350:	f9400001 	ldr	x1, [x0]
    a354:	aa1803e0 	mov	x0, x24
    a358:	d63f0020 	blr	x1
    a35c:	aa0003f9 	mov	x25, x0
    a360:	aa1703e0 	mov	x0, x23
    a364:	97ffef63 	bl	60f0 <fwp_closure_drop>
    a368:	6b13029f 	cmp	w20, w19
    a36c:	54000d00 	b.eq	a50c <fwp_main_thread+0xc8c>  // b.none
    a370:	f9406b60 	ldr	x0, [x27, #208]
    a374:	8b334f18 	add	x24, x24, w19, uxtw #3
    a378:	b9400323 	ldr	w3, [x25]
    a37c:	4b1c0354 	sub	w20, w26, w28
    a380:	aa1903e5 	mov	x5, x25
    a384:	8b031416 	add	x22, x0, x3, lsl #5
    a388:	f9400ec0 	ldr	x0, [x22, #24]
    a38c:	b4002120 	cbz	x0, a7b0 <fwp_main_thread+0xf30>
    a390:	aa1903f7 	mov	x23, x25
    a394:	b94004a1 	ldr	w1, [x5, #4]
    a398:	b94002dc 	ldr	w28, [x22]
    a39c:	0b01029a 	add	w26, w20, w1
    a3a0:	6b1a039f 	cmp	w28, w26
    a3a4:	54002b28 	b.hi	a908 <fwp_main_thread+0x1088>  // b.pmore
    a3a8:	7100003f 	cmp	w1, #0x0
    a3ac:	4b010393 	sub	w19, w28, w1
    a3b0:	7a400b84 	ccmp	w28, #0x0, #0x4, eq	// eq = none
    a3b4:	54fffce1 	b.ne	a350 <fwp_main_thread+0xad0>  // b.any
    a3b8:	7100039f 	cmp	w28, #0x0
    a3bc:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a3c0:	1a9f1784 	csinc	w4, w28, wzr, ne	// ne = any
    a3c4:	910003e2 	mov	x2, sp
    a3c8:	d37df084 	lsl	x4, x4, #3
    a3cc:	f91f7c62 	str	x2, [x3, #16120]
    a3d0:	91003c84 	add	x4, x4, #0xf
    a3d4:	92704c86 	and	x6, x4, #0xfffff0000
    a3d8:	927c7c84 	and	x4, x4, #0xffffffff0
    a3dc:	cb2663e6 	sub	x6, sp, x6
    a3e0:	eb2663ff 	cmp	sp, x6
    a3e4:	540000a0 	b.eq	a3f8 <fwp_main_thread+0xb78>  // b.none
    a3e8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a3ec:	f90203ff 	str	xzr, [sp, #1024]
    a3f0:	eb2663ff 	cmp	sp, x6
    a3f4:	54ffffa1 	b.ne	a3e8 <fwp_main_thread+0xb68>  // b.any
    a3f8:	92403c84 	and	x4, x4, #0xffff
    a3fc:	cb2463ff 	sub	sp, sp, x4
    a400:	f90003ff 	str	xzr, [sp]
    a404:	f110009f 	cmp	x4, #0x400
    a408:	54000043 	b.cc	a410 <fwp_main_thread+0xb90>  // b.lo, b.ul, b.last
    a40c:	f90203ff 	str	xzr, [sp, #1024]
    a410:	910043f9 	add	x25, sp, #0x10
    a414:	d37d7c27 	ubfiz	x7, x1, #3, #32
    a418:	910020a6 	add	x6, x5, #0x8
    a41c:	d2800004 	mov	x4, #0x0                   	// #0
    a420:	340000e1 	cbz	w1, a43c <fwp_main_thread+0xbbc>
    a424:	d503201f 	nop
    a428:	f86468c2 	ldr	x2, [x6, x4]
    a42c:	f8246b22 	str	x2, [x25, x4]
    a430:	91002084 	add	x4, x4, #0x8
    a434:	eb07009f 	cmp	x4, x7
    a438:	54ffff81 	b.ne	a428 <fwp_main_thread+0xba8>  // b.any
    a43c:	2a1303e6 	mov	w6, w19
    a440:	d2800004 	mov	x4, #0x0                   	// #0
    a444:	340000f3 	cbz	w19, a460 <fwp_main_thread+0xbe0>
    a448:	0b040022 	add	w2, w1, w4
    a44c:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    a450:	91000484 	add	x4, x4, #0x1
    a454:	f8227b23 	str	x3, [x25, x2, lsl #3]
    a458:	eb06009f 	cmp	x4, x6
    a45c:	54ffff61 	b.ne	a448 <fwp_main_thread+0xbc8>  // b.any
    a460:	f949daa1 	ldr	x1, [x21, #5040]
    a464:	f949eea4 	ldr	x4, [x21, #5080]
    a468:	cb0102e1 	sub	x1, x23, x1
    a46c:	eb04403f 	cmp	x1, x4, lsl #16
    a470:	540002e2 	b.cs	a4cc <fwp_main_thread+0xc4c>  // b.hs, b.nlast
    a474:	d350fc24 	lsr	x4, x1, #16
    a478:	f949fea8 	ldr	x8, [x21, #5112]
    a47c:	8b040884 	add	x4, x4, x4, lsl #2
    a480:	d37df084 	lsl	x4, x4, #3
    a484:	8b040107 	add	x7, x8, x4
    a488:	f94010e6 	ldr	x6, [x7, #32]
    a48c:	b4000206 	cbz	x6, a4cc <fwp_main_thread+0xc4c>
    a490:	38646904 	ldrb	w4, [x8, x4]
    a494:	7100089f 	cmp	w4, #0x2
    a498:	54001860 	b.eq	a7a4 <fwp_main_thread+0xf24>  // b.none
    a49c:	7100049f 	cmp	w4, #0x1
    a4a0:	54000161 	b.ne	a4cc <fwp_main_thread+0xc4c>  // b.any
    a4a4:	294310e8 	ldp	w8, w4, [x7, #24]
    a4a8:	92403c21 	and	x1, x1, #0xffff
    a4ac:	9b087c21 	mul	x1, x1, x8
    a4b0:	d360fc21 	lsr	x1, x1, #32
    a4b4:	eb04003f 	cmp	x1, x4
    a4b8:	540000a2 	b.cs	a4cc <fwp_main_thread+0xc4c>  // b.hs, b.nlast
    a4bc:	8b0100c6 	add	x6, x6, x1
    a4c0:	394000c1 	ldrb	w1, [x6]
    a4c4:	7100043f 	cmp	w1, #0x1
    a4c8:	540016a0 	b.eq	a79c <fwp_main_thread+0xf1c>  // b.none
    a4cc:	f9400404 	ldr	x4, [x0, #8]
    a4d0:	52800021 	mov	w1, #0x1                   	// #1
    a4d4:	aa1703e0 	mov	x0, x23
    a4d8:	d63f0080 	blr	x4
    a4dc:	f9400ec1 	ldr	x1, [x22, #24]
    a4e0:	aa1903e0 	mov	x0, x25
    a4e4:	f9400021 	ldr	x1, [x1]
    a4e8:	d63f0020 	blr	x1
    a4ec:	aa0003f9 	mov	x25, x0
    a4f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4f4:	f95f7c00 	ldr	x0, [x0, #16120]
    a4f8:	9100001f 	mov	sp, x0
    a4fc:	aa1703e0 	mov	x0, x23
    a500:	97ffeefc 	bl	60f0 <fwp_closure_drop>
    a504:	6b13029f 	cmp	w20, w19
    a508:	54fff341 	b.ne	a370 <fwp_main_thread+0xaf0>  // b.any
    a50c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a510:	aa1903f7 	mov	x23, x25
    a514:	f95f641c 	ldr	x28, [x0, #16072]
    a518:	b97ed007 	ldr	w7, [x0, #16080]
    a51c:	b97ed816 	ldr	w22, [x0, #16088]
    a520:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a524:	b97eec00 	ldr	w0, [x0, #16108]
    a528:	6b0002df 	cmp	w22, w0
    a52c:	54001823 	b.cc	a830 <fwp_main_thread+0xfb0>  // b.lo, b.ul, b.last
    a530:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a534:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a538:	aa1c03f9 	mov	x25, x28
    a53c:	f95f5c14 	ldr	x20, [x0, #16056]
    a540:	f95f6006 	ldr	x6, [x0, #16064]
    a544:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a548:	f95f5800 	ldr	x0, [x0, #16048]
    a54c:	f1000400 	subs	x0, x0, #0x1
    a550:	f91f5820 	str	x0, [x1, #16048]
    a554:	54ffe2c1 	b.ne	a1ac <fwp_main_thread+0x92c>  // b.any
    a558:	aa0103e0 	mov	x0, x1
    a55c:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10600>
    a560:	91104042 	add	x2, x2, #0x410
    a564:	aa1703e1 	mov	x1, x23
    a568:	aa0603f6 	mov	x22, x6
    a56c:	aa1903f3 	mov	x19, x25
    a570:	f95f5018 	ldr	x24, [x0, #16032]
    a574:	aa1703f9 	mov	x25, x23
    a578:	f95f4c17 	ldr	x23, [x0, #16024]
    a57c:	91014042 	add	x2, x2, #0x50
    a580:	aa1403e0 	mov	x0, x20
    a584:	52800023 	mov	w3, #0x1                   	// #1
    a588:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a58c:	f81303bf 	stur	xzr, [x29, #-208]
    a590:	97fff8c0 	bl	8890 <fwp_write>
    a594:	a97273ba 	ldp	x26, x28, [x29, #-224]
    a598:	b0000000 	adrp	x0, b000 <__divti3+0x110>
    a59c:	91194000 	add	x0, x0, #0x650
    a5a0:	f100035f 	cmp	x26, #0x0
    a5a4:	9a9a001a 	csel	x26, x0, x26, eq	// eq = none
    a5a8:	b1002b9f 	cmn	x28, #0xa
    a5ac:	54004448 	b.hi	ae34 <fwp_main_thread+0x15b4>  // b.pmore
    a5b0:	91002780 	add	x0, x28, #0x9
    a5b4:	52800021 	mov	w1, #0x1                   	// #1
    a5b8:	97ffeab6 	bl	5090 <fwp_heap_alloc>
    a5bc:	aa0003f5 	mov	x21, x0
    a5c0:	aa1a03e1 	mov	x1, x26
    a5c4:	aa0003fa 	mov	x26, x0
    a5c8:	aa1c03e2 	mov	x2, x28
    a5cc:	f800875c 	str	x28, [x26], #8
    a5d0:	8b1c02bc 	add	x28, x21, x28
    a5d4:	aa1a03e0 	mov	x0, x26
    a5d8:	97ffe022 	bl	2660 <memcpy@plt>
    a5dc:	3900239f 	strb	wzr, [x28, #8]
    a5e0:	f85203a0 	ldur	x0, [x29, #-224]
    a5e4:	97ffe0bb 	bl	28d0 <free@plt>
    a5e8:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a5ec:	91190002 	add	x2, x0, #0x640
    a5f0:	f949d841 	ldr	x1, [x2, #5040]
    a5f4:	f949ec40 	ldr	x0, [x2, #5080]
    a5f8:	cb0102a1 	sub	x1, x21, x1
    a5fc:	eb00403f 	cmp	x1, x0, lsl #16
    a600:	54000322 	b.cs	a664 <fwp_main_thread+0xde4>  // b.hs, b.nlast
    a604:	d350fc20 	lsr	x0, x1, #16
    a608:	f949fc43 	ldr	x3, [x2, #5112]
    a60c:	8b000800 	add	x0, x0, x0, lsl #2
    a610:	d37df002 	lsl	x2, x0, #3
    a614:	8b020060 	add	x0, x3, x2
    a618:	f940101c 	ldr	x28, [x0, #32]
    a61c:	b400025c 	cbz	x28, a664 <fwp_main_thread+0xde4>
    a620:	38626862 	ldrb	w2, [x3, x2]
    a624:	7100085f 	cmp	w2, #0x2
    a628:	54004140 	b.eq	ae50 <fwp_main_thread+0x15d0>  // b.none
    a62c:	7100045f 	cmp	w2, #0x1
    a630:	540001a1 	b.ne	a664 <fwp_main_thread+0xde4>  // b.any
    a634:	29430002 	ldp	w2, w0, [x0, #24]
    a638:	92403c21 	and	x1, x1, #0xffff
    a63c:	9b027c21 	mul	x1, x1, x2
    a640:	d360fc21 	lsr	x1, x1, #32
    a644:	eb00003f 	cmp	x1, x0
    a648:	540000e2 	b.cs	a664 <fwp_main_thread+0xde4>  // b.hs, b.nlast
    a64c:	8b01039c 	add	x28, x28, x1
    a650:	39400380 	ldrb	w0, [x28]
    a654:	7103fc1f 	cmp	w0, #0xff
    a658:	540043c0 	b.eq	aed0 <fwp_main_thread+0x1650>  // b.none
    a65c:	52800020 	mov	w0, #0x1                   	// #1
    a660:	39000380 	strb	w0, [x28]
    a664:	aa1903e0 	mov	x0, x25
    a668:	97ffedf2 	bl	5e30 <fwp_drop0>
    a66c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a670:	91018003 	add	x3, x0, #0x60
    a674:	f94002a2 	ldr	x2, [x21]
    a678:	aa1a03e0 	mov	x0, x26
    a67c:	aa0303fa 	mov	x26, x3
    a680:	d2800021 	mov	x1, #0x1                   	// #1
    a684:	f9404863 	ldr	x3, [x3, #144]
    a688:	97ffe0a2 	bl	2910 <fwrite@plt>
    a68c:	f9404b41 	ldr	x1, [x26, #144]
    a690:	52800140 	mov	w0, #0xa                   	// #10
    a694:	97ffe027 	bl	2730 <fputc@plt>
    a698:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a69c:	91190002 	add	x2, x0, #0x640
    a6a0:	f949d841 	ldr	x1, [x2, #5040]
    a6a4:	f949ec40 	ldr	x0, [x2, #5080]
    a6a8:	cb0102a1 	sub	x1, x21, x1
    a6ac:	eb00403f 	cmp	x1, x0, lsl #16
    a6b0:	54000382 	b.cs	a720 <fwp_main_thread+0xea0>  // b.hs, b.nlast
    a6b4:	d350fc20 	lsr	x0, x1, #16
    a6b8:	f949fc43 	ldr	x3, [x2, #5112]
    a6bc:	8b000800 	add	x0, x0, x0, lsl #2
    a6c0:	d37df000 	lsl	x0, x0, #3
    a6c4:	8b000062 	add	x2, x3, x0
    a6c8:	f940105a 	ldr	x26, [x2, #32]
    a6cc:	b40002ba 	cbz	x26, a720 <fwp_main_thread+0xea0>
    a6d0:	38606860 	ldrb	w0, [x3, x0]
    a6d4:	7100081f 	cmp	w0, #0x2
    a6d8:	54003b60 	b.eq	ae44 <fwp_main_thread+0x15c4>  // b.none
    a6dc:	7100041f 	cmp	w0, #0x1
    a6e0:	54000201 	b.ne	a720 <fwp_main_thread+0xea0>  // b.any
    a6e4:	29430043 	ldp	w3, w0, [x2, #24]
    a6e8:	92403c21 	and	x1, x1, #0xffff
    a6ec:	9b037c21 	mul	x1, x1, x3
    a6f0:	d360fc21 	lsr	x1, x1, #32
    a6f4:	eb00003f 	cmp	x1, x0
    a6f8:	54000142 	b.cs	a720 <fwp_main_thread+0xea0>  // b.hs, b.nlast
    a6fc:	8b01035a 	add	x26, x26, x1
    a700:	39400340 	ldrb	w0, [x26]
    a704:	340000e0 	cbz	w0, a720 <fwp_main_thread+0xea0>
    a708:	7100041f 	cmp	w0, #0x1
    a70c:	54003d60 	b.eq	aeb8 <fwp_main_thread+0x1638>  // b.none
    a710:	7103fc1f 	cmp	w0, #0xff
    a714:	54003a40 	b.eq	ae5c <fwp_main_thread+0x15dc>  // b.none
    a718:	51000400 	sub	w0, w0, #0x1
    a71c:	39000340 	strb	w0, [x26]
    a720:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a724:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a728:	f95f5400 	ldr	x0, [x0, #16040]
    a72c:	f9400800 	ldr	x0, [x0, #16]
    a730:	f91f5420 	str	x0, [x1, #16040]
    a734:	b5ffcde0 	cbnz	x0, a0f0 <fwp_main_thread+0x870>
    a738:	aa1703f5 	mov	x21, x23
    a73c:	aa1803e0 	mov	x0, x24
    a740:	97ffedbc 	bl	5e30 <fwp_drop0>
    a744:	aa1503e0 	mov	x0, x21
    a748:	97ffedba 	bl	5e30 <fwp_drop0>
    a74c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a750:	91018000 	add	x0, x0, #0x60
    a754:	52800021 	mov	w1, #0x1                   	// #1
    a758:	b903c801 	str	w1, [x0, #968]
    a75c:	f901e81f 	str	xzr, [x0, #976]
    a760:	17fffc94 	b	99b0 <fwp_main_thread+0x130>
    a764:	72003c5f 	tst	w2, #0xffff
    a768:	54ffbbc1 	b.ne	9ee0 <fwp_main_thread+0x660>  // b.any
    a76c:	39400320 	ldrb	w0, [x25]
    a770:	7103fc1f 	cmp	w0, #0xff
    a774:	54ffbb41 	b.ne	9edc <fwp_main_thread+0x65c>  // b.any
    a778:	aa1903e0 	mov	x0, x25
    a77c:	97ffe885 	bl	4990 <fwp_rc_forget_slot>
    a780:	17fffdd7 	b	9edc <fwp_main_thread+0x65c>
    a784:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    a788:	913c8000 	add	x0, x0, #0xf20
    a78c:	94000395 	bl	b5e0 <atexit>
    a790:	17fffc51 	b	98d4 <fwp_main_thread+0x54>
    a794:	97ffe63c 	bl	4084 <fwp_heap_init>
    a798:	17fffc4b 	b	98c4 <fwp_main_thread+0x44>
    a79c:	b90004bf 	str	wzr, [x5, #4]
    a7a0:	17ffff4f 	b	a4dc <fwp_main_thread+0xc5c>
    a7a4:	72003c3f 	tst	w1, #0xffff
    a7a8:	54ffe921 	b.ne	a4cc <fwp_main_thread+0xc4c>  // b.any
    a7ac:	17ffff45 	b	a4c0 <fwp_main_thread+0xc40>
    a7b0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7b4:	f95f641c 	ldr	x28, [x0, #16072]
    a7b8:	b97ed007 	ldr	w7, [x0, #16080]
    a7bc:	b97ed816 	ldr	w22, [x0, #16088]
    a7c0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7c4:	b93ef807 	str	w7, [x0, #16120]
    a7c8:	aa1903e0 	mov	x0, x25
    a7cc:	97ffec96 	bl	5a24 <fwp_rc_share>
    a7d0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7d4:	b97ef807 	ldr	w7, [x0, #16120]
    a7d8:	34000134 	cbz	w20, a7fc <fwp_main_thread+0xf7c>
    a7dc:	aa1803f7 	mov	x23, x24
    a7e0:	8b344f13 	add	x19, x24, w20, uxtw #3
    a7e4:	2a0703fa 	mov	w26, w7
    a7e8:	f84086e0 	ldr	x0, [x23], #8
    a7ec:	97ffec8e 	bl	5a24 <fwp_rc_share>
    a7f0:	eb1302ff 	cmp	x23, x19
    a7f4:	54ffffa1 	b.ne	a7e8 <fwp_main_thread+0xf68>  // b.any
    a7f8:	2a1a03e7 	mov	w7, w26
    a7fc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a800:	aa1803e2 	mov	x2, x24
    a804:	2a1403e1 	mov	w1, w20
    a808:	b93ef807 	str	w7, [x0, #16120]
    a80c:	aa1903e0 	mov	x0, x25
    a810:	97ffea81 	bl	5214 <fwp_apply>
    a814:	aa0003f7 	mov	x23, x0
    a818:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a81c:	b97ef807 	ldr	w7, [x0, #16120]
    a820:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a824:	b97eec00 	ldr	w0, [x0, #16108]
    a828:	6b0002df 	cmp	w22, w0
    a82c:	54ffe822 	b.cs	a530 <fwp_main_thread+0xcb0>  // b.hs, b.nlast
    a830:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a834:	b94002e4 	ldr	w4, [x23]
    a838:	f9406b61 	ldr	x1, [x27, #208]
    a83c:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a840:	f95f7842 	ldr	x2, [x2, #16112]
    a844:	4b070000 	sub	w0, w0, w7
    a848:	8b041424 	add	x4, x1, x4, lsl #5
    a84c:	b93eec60 	str	w0, [x3, #16108]
    a850:	b97ee860 	ldr	w0, [x3, #16104]
    a854:	8b274c42 	add	x2, x2, w7, uxtw #3
    a858:	f91f7862 	str	x2, [x3, #16112]
    a85c:	f9400c81 	ldr	x1, [x4, #24]
    a860:	b97ee462 	ldr	w2, [x3, #16100]
    a864:	4b020000 	sub	w0, w0, w2
    a868:	b93ee860 	str	w0, [x3, #16104]
    a86c:	aa1703e0 	mov	x0, x23
    a870:	b5ffd1c1 	cbnz	x1, a2a8 <fwp_main_thread+0xa28>
    a874:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a878:	aa1c03f9 	mov	x25, x28
    a87c:	f95f6006 	ldr	x6, [x0, #16064]
    a880:	f91f7c06 	str	x6, [x0, #16120]
    a884:	f95f5c14 	ldr	x20, [x0, #16056]
    a888:	b97eec18 	ldr	w24, [x0, #16108]
    a88c:	aa1703e0 	mov	x0, x23
    a890:	97ffec65 	bl	5a24 <fwp_rc_share>
    a894:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a898:	f95f7c06 	ldr	x6, [x0, #16120]
    a89c:	34000178 	cbz	w24, a8c8 <fwp_main_thread+0x1048>
    a8a0:	f95f7816 	ldr	x22, [x0, #16112]
    a8a4:	aa0603fa 	mov	x26, x6
    a8a8:	d2800015 	mov	x21, #0x0                   	// #0
    a8ac:	d503201f 	nop
    a8b0:	f8757ac0 	ldr	x0, [x22, x21, lsl #3]
    a8b4:	910006b5 	add	x21, x21, #0x1
    a8b8:	97ffec5b 	bl	5a24 <fwp_rc_share>
    a8bc:	6b15031f 	cmp	w24, w21
    a8c0:	54ffff88 	b.hi	a8b0 <fwp_main_thread+0x1030>  // b.pmore
    a8c4:	aa1a03e6 	mov	x6, x26
    a8c8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8cc:	2a1803e1 	mov	w1, w24
    a8d0:	f95f7802 	ldr	x2, [x0, #16112]
    a8d4:	f91f7c06 	str	x6, [x0, #16120]
    a8d8:	aa1703e0 	mov	x0, x23
    a8dc:	97ffea4e 	bl	5214 <fwp_apply>
    a8e0:	aa0003f7 	mov	x23, x0
    a8e4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8e8:	f95f7c06 	ldr	x6, [x0, #16120]
    a8ec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8f0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a8f4:	f95f5800 	ldr	x0, [x0, #16048]
    a8f8:	f1000400 	subs	x0, x0, #0x1
    a8fc:	f91f5820 	str	x0, [x1, #16048]
    a900:	54ffc561 	b.ne	a1ac <fwp_main_thread+0x92c>  // b.any
    a904:	17ffff15 	b	a558 <fwp_main_thread+0xcd8>
    a908:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a90c:	b941336b 	ldr	w11, [x27, #304]
    a910:	aa1603e3 	mov	x3, x22
    a914:	2a0103f9 	mov	w25, w1
    a918:	f95f641c 	ldr	x28, [x0, #16072]
    a91c:	b97ed007 	ldr	w7, [x0, #16080]
    a920:	b97ed816 	ldr	w22, [x0, #16088]
    a924:	11000740 	add	w0, w26, #0x1
    a928:	d37df000 	lsl	x0, x0, #3
    a92c:	340000ab 	cbz	w11, a940 <fwp_main_thread+0x10c0>
    a930:	a9538769 	ldp	x9, x1, [x27, #312]
    a934:	91000529 	add	x9, x9, #0x1
    a938:	8b000021 	add	x1, x1, x0
    a93c:	a9138769 	stp	x9, x1, [x27, #312]
    a940:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a944:	9119002a 	add	x10, x1, #0x640
    a948:	f140101f 	cmp	x0, #0x4, lsl #12
    a94c:	b953a541 	ldr	w1, [x10, #5028]
    a950:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a954:	54001b60 	b.eq	acc0 <fwp_main_thread+0x1440>  // b.none
    a958:	91003c01 	add	x1, x0, #0xf
    a95c:	8b411141 	add	x1, x10, x1, lsr #4
    a960:	397e8021 	ldrb	w1, [x1, #4000]
    a964:	910f002c 	add	x12, x1, #0x3c0
    a968:	8b010429 	add	x9, x1, x1, lsl #1
    a96c:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a970:	8b090d4d 	add	x13, x10, x9, lsl #3
    a974:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    a978:	2a0c03e1 	mov	w1, w12
    a97c:	b4001913 	cbz	x19, ac9c <fwp_main_thread+0x141c>
    a980:	f940026d 	ldr	x13, [x19]
    a984:	aa2d03ed 	mvn	x13, x13
    a988:	f829794d 	str	x13, [x10, x9, lsl #3]
    a98c:	eb01001f 	cmp	x0, x1
    a990:	540000c2 	b.cs	a9a8 <fwp_main_thread+0x1128>  // b.hs, b.nlast
    a994:	d503201f 	nop
    a998:	f8206a7f 	str	xzr, [x19, x0]
    a99c:	91002000 	add	x0, x0, #0x8
    a9a0:	eb00003f 	cmp	x1, x0
    a9a4:	54ffffa8 	b.hi	a998 <fwp_main_thread+0x1118>  // b.pmore
    a9a8:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a9ac:	91190009 	add	x9, x0, #0x640
    a9b0:	f94a1120 	ldr	x0, [x9, #5152]
    a9b4:	ab010000 	adds	x0, x0, x1
    a9b8:	540023c2 	b.cs	ae30 <fwp_main_thread+0x15b0>  // b.hs, b.nlast
    a9bc:	f94a1521 	ldr	x1, [x9, #5160]
    a9c0:	f90a1120 	str	x0, [x9, #5152]
    a9c4:	eb01001f 	cmp	x0, x1
    a9c8:	54000049 	b.ls	a9d0 <fwp_main_thread+0x1150>  // b.plast
    a9cc:	f90a1520 	str	x0, [x9, #5160]
    a9d0:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a9d4:	91190000 	add	x0, x0, #0x640
    a9d8:	1e630181 	ucvtf	d1, w12
    a9dc:	fd4a1c00 	ldr	d0, [x0, #5176]
    a9e0:	1e612800 	fadd	d0, d0, d1
    a9e4:	fd0a1c00 	str	d0, [x0, #5176]
    a9e8:	3400012b 	cbz	w11, aa0c <fwp_main_thread+0x118c>
    a9ec:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a9f0:	91190000 	add	x0, x0, #0x640
    a9f4:	6d548762 	ldp	d2, d1, [x27, #328]
    a9f8:	fd4a1000 	ldr	d0, [x0, #5152]
    a9fc:	7e61d800 	ucvtf	d0, d0
    aa00:	1e623800 	fsub	d0, d0, d2
    aa04:	1e612010 	fcmpe	d0, d1
    aa08:	5400196c 	b.gt	ad34 <fwp_main_thread+0x14b4>
    aa0c:	b94000a0 	ldr	w0, [x5]
    aa10:	29006a60 	stp	w0, w26, [x19]
    aa14:	340001b9 	cbz	w25, aa48 <fwp_main_thread+0x11c8>
    aa18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa1c:	910020a1 	add	x1, x5, #0x8
    aa20:	d37d7f22 	ubfiz	x2, x25, #3, #32
    aa24:	b93ed007 	str	w7, [x0, #16080]
    aa28:	f91f6c03 	str	x3, [x0, #16088]
    aa2c:	f91f7c05 	str	x5, [x0, #16120]
    aa30:	91002260 	add	x0, x19, #0x8
    aa34:	97ffdf13 	bl	2680 <memmove@plt>
    aa38:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa3c:	f95f6c03 	ldr	x3, [x0, #16088]
    aa40:	f95f7c05 	ldr	x5, [x0, #16120]
    aa44:	b97ed007 	ldr	w7, [x0, #16080]
    aa48:	2a1403e9 	mov	w9, w20
    aa4c:	d2800001 	mov	x1, #0x0                   	// #0
    aa50:	34000134 	cbz	w20, aa74 <fwp_main_thread+0x11f4>
    aa54:	d503201f 	nop
    aa58:	0b010320 	add	w0, w25, w1
    aa5c:	f8617b02 	ldr	x2, [x24, x1, lsl #3]
    aa60:	8b000e60 	add	x0, x19, x0, lsl #3
    aa64:	91000421 	add	x1, x1, #0x1
    aa68:	f9000402 	str	x2, [x0, #8]
    aa6c:	eb09003f 	cmp	x1, x9
    aa70:	54ffff41 	b.ne	aa58 <fwp_main_thread+0x11d8>  // b.any
    aa74:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    aa78:	91190002 	add	x2, x0, #0x640
    aa7c:	f949d840 	ldr	x0, [x2, #5040]
    aa80:	f949ec41 	ldr	x1, [x2, #5080]
    aa84:	cb0002e0 	sub	x0, x23, x0
    aa88:	eb01401f 	cmp	x0, x1, lsl #16
    aa8c:	540002e2 	b.cs	aae8 <fwp_main_thread+0x1268>  // b.hs, b.nlast
    aa90:	d350fc01 	lsr	x1, x0, #16
    aa94:	f949fc46 	ldr	x6, [x2, #5112]
    aa98:	8b010821 	add	x1, x1, x1, lsl #2
    aa9c:	d37df021 	lsl	x1, x1, #3
    aaa0:	8b0100c4 	add	x4, x6, x1
    aaa4:	f9401082 	ldr	x2, [x4, #32]
    aaa8:	b4000202 	cbz	x2, aae8 <fwp_main_thread+0x1268>
    aaac:	386168c1 	ldrb	w1, [x6, x1]
    aab0:	7100083f 	cmp	w1, #0x2
    aab4:	54001220 	b.eq	acf8 <fwp_main_thread+0x1478>  // b.none
    aab8:	7100043f 	cmp	w1, #0x1
    aabc:	54000161 	b.ne	aae8 <fwp_main_thread+0x1268>  // b.any
    aac0:	29430486 	ldp	w6, w1, [x4, #24]
    aac4:	92403c00 	and	x0, x0, #0xffff
    aac8:	9b067c00 	mul	x0, x0, x6
    aacc:	d360fc00 	lsr	x0, x0, #32
    aad0:	eb01001f 	cmp	x0, x1
    aad4:	540000a2 	b.cs	aae8 <fwp_main_thread+0x1268>  // b.hs, b.nlast
    aad8:	8b000042 	add	x2, x2, x0
    aadc:	39400040 	ldrb	w0, [x2]
    aae0:	7100041f 	cmp	w0, #0x1
    aae4:	54000d20 	b.eq	ac88 <fwp_main_thread+0x1408>  // b.none
    aae8:	f9400c62 	ldr	x2, [x3, #24]
    aaec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aaf0:	52800021 	mov	w1, #0x1                   	// #1
    aaf4:	f9400442 	ldr	x2, [x2, #8]
    aaf8:	b93ef807 	str	w7, [x0, #16120]
    aafc:	aa1703e0 	mov	x0, x23
    ab00:	d63f0040 	blr	x2
    ab04:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab08:	b97ef807 	ldr	w7, [x0, #16120]
    ab0c:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    ab10:	91190002 	add	x2, x0, #0x640
    ab14:	f949d841 	ldr	x1, [x2, #5040]
    ab18:	f949ec40 	ldr	x0, [x2, #5080]
    ab1c:	cb010261 	sub	x1, x19, x1
    ab20:	eb00403f 	cmp	x1, x0, lsl #16
    ab24:	54000322 	b.cs	ab88 <fwp_main_thread+0x1308>  // b.hs, b.nlast
    ab28:	d350fc20 	lsr	x0, x1, #16
    ab2c:	f949fc43 	ldr	x3, [x2, #5112]
    ab30:	8b000800 	add	x0, x0, x0, lsl #2
    ab34:	d37df002 	lsl	x2, x0, #3
    ab38:	8b020060 	add	x0, x3, x2
    ab3c:	f9401014 	ldr	x20, [x0, #32]
    ab40:	b4000254 	cbz	x20, ab88 <fwp_main_thread+0x1308>
    ab44:	38626862 	ldrb	w2, [x3, x2]
    ab48:	7100085f 	cmp	w2, #0x2
    ab4c:	54000dc0 	b.eq	ad04 <fwp_main_thread+0x1484>  // b.none
    ab50:	7100045f 	cmp	w2, #0x1
    ab54:	540001a1 	b.ne	ab88 <fwp_main_thread+0x1308>  // b.any
    ab58:	29430002 	ldp	w2, w0, [x0, #24]
    ab5c:	92403c21 	and	x1, x1, #0xffff
    ab60:	9b027c21 	mul	x1, x1, x2
    ab64:	d360fc21 	lsr	x1, x1, #32
    ab68:	eb00003f 	cmp	x1, x0
    ab6c:	540000e2 	b.cs	ab88 <fwp_main_thread+0x1308>  // b.hs, b.nlast
    ab70:	8b010294 	add	x20, x20, x1
    ab74:	39400280 	ldrb	w0, [x20]
    ab78:	7103fc1f 	cmp	w0, #0xff
    ab7c:	54000ce0 	b.eq	ad18 <fwp_main_thread+0x1498>  // b.none
    ab80:	52800020 	mov	w0, #0x1                   	// #1
    ab84:	39000280 	strb	w0, [x20]
    ab88:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab8c:	b93ef807 	str	w7, [x0, #16120]
    ab90:	aa1703e0 	mov	x0, x23
    ab94:	97ffed57 	bl	60f0 <fwp_closure_drop>
    ab98:	aa1303f7 	mov	x23, x19
    ab9c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aba0:	b97ef807 	ldr	w7, [x0, #16120]
    aba4:	17ffff1f 	b	a820 <fwp_main_thread+0xfa0>
    aba8:	b8626860 	ldr	w0, [x3, x2]
    abac:	b94004a2 	ldr	w2, [x5, #4]
    abb0:	4b020003 	sub	w3, w0, w2
    abb4:	7100047f 	cmp	w3, #0x1
    abb8:	54ffb101 	b.ne	a1d8 <fwp_main_thread+0x958>  // b.any
    abbc:	910003f5 	mov	x21, sp
    abc0:	34000ce2 	cbz	w2, ad5c <fwp_main_thread+0x14dc>
    abc4:	7100001f 	cmp	w0, #0x0
    abc8:	d37d7c00 	ubfiz	x0, x0, #3, #32
    abcc:	d2800101 	mov	x1, #0x8                   	// #8
    abd0:	9a811018 	csel	x24, x0, x1, ne	// ne = any
    abd4:	91003f00 	add	x0, x24, #0xf
    abd8:	92704c01 	and	x1, x0, #0xfffff0000
    abdc:	927c7c00 	and	x0, x0, #0xffffffff0
    abe0:	cb2163e1 	sub	x1, sp, x1
    abe4:	eb2163ff 	cmp	sp, x1
    abe8:	540000a0 	b.eq	abfc <fwp_main_thread+0x137c>  // b.none
    abec:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    abf0:	f90203ff 	str	xzr, [sp, #1024]
    abf4:	eb2163ff 	cmp	sp, x1
    abf8:	54ffffa1 	b.ne	abec <fwp_main_thread+0x136c>  // b.any
    abfc:	92403c00 	and	x0, x0, #0xffff
    ac00:	cb2063ff 	sub	sp, sp, x0
    ac04:	f90003ff 	str	xzr, [sp]
    ac08:	f110001f 	cmp	x0, #0x400
    ac0c:	54000043 	b.cc	ac14 <fwp_main_thread+0x1394>  // b.lo, b.ul, b.last
    ac10:	f90203ff 	str	xzr, [sp, #1024]
    ac14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac18:	d37d7c5a 	ubfiz	x26, x2, #3, #32
    ac1c:	910043f6 	add	x22, sp, #0x10
    ac20:	91004321 	add	x1, x25, #0x10
    ac24:	aa1a03e2 	mov	x2, x26
    ac28:	9100c021 	add	x1, x1, #0x30
    ac2c:	aa1803e3 	mov	x3, x24
    ac30:	f91f7806 	str	x6, [x0, #16112]
    ac34:	f91f7c04 	str	x4, [x0, #16120]
    ac38:	aa1603e0 	mov	x0, x22
    ac3c:	97ffdec9 	bl	2760 <__memcpy_chk@plt>
    ac40:	eb1a031f 	cmp	x24, x26
    ac44:	aa1403e1 	mov	x1, x20
    ac48:	9a9a2303 	csel	x3, x24, x26, cs	// cs = hs, nlast
    ac4c:	d2800102 	mov	x2, #0x8                   	// #8
    ac50:	cb1a0063 	sub	x3, x3, x26
    ac54:	8b1a02c0 	add	x0, x22, x26
    ac58:	97ffdec2 	bl	2760 <__memcpy_chk@plt>
    ac5c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ac60:	aa1603e0 	mov	x0, x22
    ac64:	f95f7c24 	ldr	x4, [x1, #16120]
    ac68:	f9400c81 	ldr	x1, [x4, #24]
    ac6c:	f9400021 	ldr	x1, [x1]
    ac70:	d63f0020 	blr	x1
    ac74:	aa0003f7 	mov	x23, x0
    ac78:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac7c:	f95f7806 	ldr	x6, [x0, #16112]
    ac80:	910002bf 	mov	sp, x21
    ac84:	17ffff1a 	b	a8ec <fwp_main_thread+0x106c>
    ac88:	b90004bf 	str	wzr, [x5, #4]
    ac8c:	17ffffa0 	b	ab0c <fwp_main_thread+0x128c>
    ac90:	72003c3f 	tst	w1, #0xffff
    ac94:	54ffaec1 	b.ne	a26c <fwp_main_thread+0x9ec>  // b.any
    ac98:	17fffd6a 	b	a240 <fwp_main_thread+0x9c0>
    ac9c:	f94005b3 	ldr	x19, [x13, #8]
    aca0:	b4000113 	cbz	x19, acc0 <fwp_main_thread+0x1440>
    aca4:	f94009a9 	ldr	x9, [x13, #16]
    aca8:	cb130129 	sub	x9, x9, x19
    acac:	eb09003f 	cmp	x1, x9
    acb0:	54000088 	b.hi	acc0 <fwp_main_thread+0x1440>  // b.pmore
    acb4:	8b010269 	add	x9, x19, x1
    acb8:	f90005a9 	str	x9, [x13, #8]
    acbc:	17ffff34 	b	a98c <fwp_main_thread+0x110c>
    acc0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    acc4:	b93ec82b 	str	w11, [x1, #16072]
    acc8:	f91f6825 	str	x5, [x1, #16080]
    accc:	b93ed827 	str	w7, [x1, #16088]
    acd0:	f91f7c23 	str	x3, [x1, #16120]
    acd4:	52800001 	mov	w1, #0x0                   	// #0
    acd8:	97ffe8ee 	bl	5090 <fwp_heap_alloc>
    acdc:	aa0003f3 	mov	x19, x0
    ace0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ace4:	f95f6805 	ldr	x5, [x0, #16080]
    ace8:	f95f7c03 	ldr	x3, [x0, #16120]
    acec:	b97ec80b 	ldr	w11, [x0, #16072]
    acf0:	b97ed807 	ldr	w7, [x0, #16088]
    acf4:	17ffff3d 	b	a9e8 <fwp_main_thread+0x1168>
    acf8:	72003c1f 	tst	w0, #0xffff
    acfc:	54ffef61 	b.ne	aae8 <fwp_main_thread+0x1268>  // b.any
    ad00:	17ffff77 	b	aadc <fwp_main_thread+0x125c>
    ad04:	72003c3f 	tst	w1, #0xffff
    ad08:	54fff401 	b.ne	ab88 <fwp_main_thread+0x1308>  // b.any
    ad0c:	39400280 	ldrb	w0, [x20]
    ad10:	7103fc1f 	cmp	w0, #0xff
    ad14:	54fff361 	b.ne	ab80 <fwp_main_thread+0x1300>  // b.any
    ad18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad1c:	b93ef807 	str	w7, [x0, #16120]
    ad20:	aa1403e0 	mov	x0, x20
    ad24:	97ffe71b 	bl	4990 <fwp_rc_forget_slot>
    ad28:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad2c:	b97ef807 	ldr	w7, [x0, #16120]
    ad30:	17ffff94 	b	ab80 <fwp_main_thread+0x1300>
    ad34:	fd00ab60 	str	d0, [x27, #336]
    ad38:	17ffff35 	b	aa0c <fwp_main_thread+0x118c>
    ad3c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad40:	f91f7826 	str	x6, [x1, #16112]
    ad44:	f91f7c24 	str	x4, [x1, #16120]
    ad48:	97ffe6cb 	bl	4874 <fwp_rc_wide_dup>
    ad4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad50:	f95f7806 	ldr	x6, [x0, #16112]
    ad54:	f95f7c04 	ldr	x4, [x0, #16120]
    ad58:	17fffd45 	b	a26c <fwp_main_thread+0x9ec>
    ad5c:	f9400021 	ldr	x1, [x1]
    ad60:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad64:	f91f7c06 	str	x6, [x0, #16120]
    ad68:	aa1403e0 	mov	x0, x20
    ad6c:	d63f0020 	blr	x1
    ad70:	aa0003f7 	mov	x23, x0
    ad74:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad78:	f95f7c06 	ldr	x6, [x0, #16120]
    ad7c:	910002bf 	mov	sp, x21
    ad80:	17fffedb 	b	a8ec <fwp_main_thread+0x106c>
    ad84:	72003c3f 	tst	w1, #0xffff
    ad88:	54ff9501 	b.ne	a028 <fwp_main_thread+0x7a8>  // b.any
    ad8c:	17fffca2 	b	a014 <fwp_main_thread+0x794>
    ad90:	72003c3f 	tst	w1, #0xffff
    ad94:	54ff9001 	b.ne	9f94 <fwp_main_thread+0x714>  // b.any
    ad98:	17fffc7a 	b	9f80 <fwp_main_thread+0x700>
    ad9c:	72003c3f 	tst	w1, #0xffff
    ada0:	54ff9901 	b.ne	a0c0 <fwp_main_thread+0x840>  // b.any
    ada4:	17fffcc2 	b	a0ac <fwp_main_thread+0x82c>
    ada8:	72003c3f 	tst	w1, #0xffff
    adac:	54ff9f01 	b.ne	a18c <fwp_main_thread+0x90c>  // b.any
    adb0:	17fffcea 	b	a158 <fwp_main_thread+0x8d8>
    adb4:	aa0103e0 	mov	x0, x1
    adb8:	17fffb88 	b	9bd8 <fwp_main_thread+0x358>
    adbc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    adc0:	aa0603e0 	mov	x0, x6
    adc4:	52800038 	mov	w24, #0x1                   	// #1
    adc8:	f91f7c26 	str	x6, [x1, #16120]
    adcc:	97ffeb16 	bl	5a24 <fwp_rc_share>
    add0:	aa1703e0 	mov	x0, x23
    add4:	97ffeb14 	bl	5a24 <fwp_rc_share>
    add8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    addc:	f95f7c06 	ldr	x6, [x0, #16120]
    ade0:	f91f7814 	str	x20, [x0, #16112]
    ade4:	aa0603f7 	mov	x23, x6
    ade8:	17fffeb8 	b	a8c8 <fwp_main_thread+0x1048>
    adec:	aa1603e0 	mov	x0, x22
    adf0:	97ffe6e8 	bl	4990 <fwp_rc_forget_slot>
    adf4:	17fffc66 	b	9f8c <fwp_main_thread+0x70c>
    adf8:	97ffe69f 	bl	4874 <fwp_rc_wide_dup>
    adfc:	17fffce4 	b	a18c <fwp_main_thread+0x90c>
    ae00:	aa1303e0 	mov	x0, x19
    ae04:	97ffe6e3 	bl	4990 <fwp_rc_forget_slot>
    ae08:	17fffc86 	b	a020 <fwp_main_thread+0x7a0>
    ae0c:	aa1303e0 	mov	x0, x19
    ae10:	97ffe6e0 	bl	4990 <fwp_rc_forget_slot>
    ae14:	17fffca9 	b	a0b8 <fwp_main_thread+0x838>
    ae18:	b0000000 	adrp	x0, b000 <__divti3+0x110>
    ae1c:	91384000 	add	x0, x0, #0xe10
    ae20:	97ffe138 	bl	3300 <ad_raw_fail>
    ae24:	b0000000 	adrp	x0, b000 <__divti3+0x110>
    ae28:	9137a000 	add	x0, x0, #0xde8
    ae2c:	97ffe255 	bl	3780 <fwp_trap>
    ae30:	97ffe0b0 	bl	30f0 <fwp_heap_oom>
    ae34:	b0000000 	adrp	x0, b000 <__divti3+0x110>
    ae38:	9138c000 	add	x0, x0, #0xe30
    ae3c:	97ffe251 	bl	3780 <fwp_trap>
    ae40:	97ffde74 	bl	2810 <__stack_chk_fail@plt>
    ae44:	72003c3f 	tst	w1, #0xffff
    ae48:	54ffc6c1 	b.ne	a720 <fwp_main_thread+0xea0>  // b.any
    ae4c:	17fffe2d 	b	a700 <fwp_main_thread+0xe80>
    ae50:	72003c3f 	tst	w1, #0xffff
    ae54:	54ffc081 	b.ne	a664 <fwp_main_thread+0xde4>  // b.any
    ae58:	17fffdfe 	b	a650 <fwp_main_thread+0xdd0>
    ae5c:	ca5a4740 	eor	x0, x26, x26, lsr #17
    ae60:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    ae64:	91190021 	add	x1, x1, #0x640
    ae68:	ca402400 	eor	x0, x0, x0, lsr #9
    ae6c:	8b200c20 	add	x0, x1, w0, uxtb #3
    ae70:	f94a2400 	ldr	x0, [x0, #5192]
    ae74:	b5000080 	cbnz	x0, ae84 <fwp_main_thread+0x1604>
    ae78:	14000019 	b	aedc <fwp_main_thread+0x165c>
    ae7c:	f9400800 	ldr	x0, [x0, #16]
    ae80:	b40002e0 	cbz	x0, aedc <fwp_main_thread+0x165c>
    ae84:	f9400001 	ldr	x1, [x0]
    ae88:	eb01035f 	cmp	x26, x1
    ae8c:	54ffff81 	b.ne	ae7c <fwp_main_thread+0x15fc>  // b.any
    ae90:	f9400401 	ldr	x1, [x0, #8]
    ae94:	d1000421 	sub	x1, x1, #0x1
    ae98:	f9000401 	str	x1, [x0, #8]
    ae9c:	f103f83f 	cmp	x1, #0xfe
    aea0:	54ffc401 	b.ne	a720 <fwp_main_thread+0xea0>  // b.any
    aea4:	aa1a03e0 	mov	x0, x26
    aea8:	97ffe6ba 	bl	4990 <fwp_rc_forget_slot>
    aeac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aeb0:	39000340 	strb	w0, [x26]
    aeb4:	17fffe1b 	b	a720 <fwp_main_thread+0xea0>
    aeb8:	aa1503e0 	mov	x0, x21
    aebc:	97ffeb01 	bl	5ac0 <fwp_rc_free_arr>
    aec0:	17fffe18 	b	a720 <fwp_main_thread+0xea0>
    aec4:	b903da9f 	str	wzr, [x20, #984]
    aec8:	b4ff6bc0 	cbz	x0, 9c40 <fwp_main_thread+0x3c0>
    aecc:	97ffde65 	bl	2860 <abort@plt>
    aed0:	aa1c03e0 	mov	x0, x28
    aed4:	97ffe6af 	bl	4990 <fwp_rc_forget_slot>
    aed8:	17fffde1 	b	a65c <fwp_main_thread+0xddc>
    aedc:	b0000000 	adrp	x0, b000 <__divti3+0x110>
    aee0:	912b4000 	add	x0, x0, #0xad0
    aee4:	97ffe227 	bl	3780 <fwp_trap>
    aee8:	d503201f 	nop
    aeec:	d503201f 	nop

000000000000aef0 <__divti3>:
    aef0:	d503245f 	bti	c
    aef4:	d2800004 	mov	x4, #0x0                   	// #0
    aef8:	b7f80721 	tbnz	x1, #63, afdc <__divti3+0xec>
    aefc:	b6f80083 	tbz	x3, #63, af0c <__divti3+0x1c>
    af00:	eb0203e2 	negs	x2, x2
    af04:	aa2403e4 	mvn	x4, x4
    af08:	da0303e3 	ngc	x3, x3
    af0c:	aa0203e6 	mov	x6, x2
    af10:	aa0003e7 	mov	x7, x0
    af14:	aa0103e5 	mov	x5, x1
    af18:	b5000583 	cbnz	x3, afc8 <__divti3+0xd8>
    af1c:	eb01005f 	cmp	x2, x1
    af20:	54000e69 	b.ls	b0ec <__divti3+0x1fc>  // b.plast
    af24:	dac01040 	clz	x0, x2
    af28:	b40000e0 	cbz	x0, af44 <__divti3+0x54>
    af2c:	4b0003e1 	neg	w1, w0
    af30:	9ac020a5 	lsl	x5, x5, x0
    af34:	9ac02046 	lsl	x6, x2, x0
    af38:	9ac124e1 	lsr	x1, x7, x1
    af3c:	aa050025 	orr	x5, x1, x5
    af40:	9ac020e7 	lsl	x7, x7, x0
    af44:	d360fcc8 	lsr	x8, x6, #32
    af48:	92407cc2 	and	x2, x6, #0xffffffff
    af4c:	9ac808a3 	udiv	x3, x5, x8
    af50:	9b089465 	msub	x5, x3, x8, x5
    af54:	aa0303e0 	mov	x0, x3
    af58:	9b037c41 	mul	x1, x2, x3
    af5c:	93c780a5 	extr	x5, x5, x7, #32
    af60:	eb05003f 	cmp	x1, x5
    af64:	540000a9 	b.ls	af78 <__divti3+0x88>  // b.plast
    af68:	ab0500c5 	adds	x5, x6, x5
    af6c:	d1000460 	sub	x0, x3, #0x1
    af70:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    af74:	540015a8 	b.hi	b228 <__divti3+0x338>  // b.pmore
    af78:	cb0100a5 	sub	x5, x5, x1
    af7c:	9ac808a3 	udiv	x3, x5, x8
    af80:	9b089465 	msub	x5, x3, x8, x5
    af84:	aa0303e1 	mov	x1, x3
    af88:	9b037c42 	mul	x2, x2, x3
    af8c:	aa0703e3 	mov	x3, x7
    af90:	b3607ca3 	bfi	x3, x5, #32, #32
    af94:	eb03005f 	cmp	x2, x3
    af98:	540000c9 	b.ls	afb0 <__divti3+0xc0>  // b.plast
    af9c:	ab0300c3 	adds	x3, x6, x3
    afa0:	d1000425 	sub	x5, x1, #0x1
    afa4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    afa8:	d1000821 	sub	x1, x1, #0x2
    afac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    afb0:	aa008020 	orr	x0, x1, x0, lsl #32
    afb4:	d2800001 	mov	x1, #0x0                   	// #0
    afb8:	b4000064 	cbz	x4, afc4 <__divti3+0xd4>
    afbc:	eb0003e0 	negs	x0, x0
    afc0:	da0103e1 	ngc	x1, x1
    afc4:	d65f03c0 	ret
    afc8:	eb01007f 	cmp	x3, x1
    afcc:	54000109 	b.ls	afec <__divti3+0xfc>  // b.plast
    afd0:	d2800001 	mov	x1, #0x0                   	// #0
    afd4:	d2800000 	mov	x0, #0x0                   	// #0
    afd8:	17fffff8 	b	afb8 <__divti3+0xc8>
    afdc:	eb0003e0 	negs	x0, x0
    afe0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    afe4:	da0103e1 	ngc	x1, x1
    afe8:	17ffffc5 	b	aefc <__divti3+0xc>
    afec:	dac01067 	clz	x7, x3
    aff0:	b40010e7 	cbz	x7, b20c <__divti3+0x31c>
    aff4:	d2800805 	mov	x5, #0x40                  	// #64
    aff8:	cb0700a5 	sub	x5, x5, x7
    affc:	9ac72063 	lsl	x3, x3, x7
    b000:	9ac52448 	lsr	x8, x2, x5
    b004:	aa030108 	orr	x8, x8, x3
    b008:	9ac52426 	lsr	x6, x1, x5
    b00c:	92407d0a 	and	x10, x8, #0xffffffff
    b010:	d360fd09 	lsr	x9, x8, #32
    b014:	9ac52403 	lsr	x3, x0, x5
    b018:	9ac72021 	lsl	x1, x1, x7
    b01c:	aa010063 	orr	x3, x3, x1
    b020:	9ac72042 	lsl	x2, x2, x7
    b024:	9ac908cb 	udiv	x11, x6, x9
    b028:	9b099965 	msub	x5, x11, x9, x6
    b02c:	aa0b03e1 	mov	x1, x11
    b030:	9b0b7d46 	mul	x6, x10, x11
    b034:	93c380a5 	extr	x5, x5, x3, #32
    b038:	eb0500df 	cmp	x6, x5
    b03c:	540000a9 	b.ls	b050 <__divti3+0x160>  // b.plast
    b040:	ab050105 	adds	x5, x8, x5
    b044:	d1000561 	sub	x1, x11, #0x1
    b048:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    b04c:	54000f48 	b.hi	b234 <__divti3+0x344>  // b.pmore
    b050:	cb0600a6 	sub	x6, x5, x6
    b054:	9ac908cb 	udiv	x11, x6, x9
    b058:	9b099969 	msub	x9, x11, x9, x6
    b05c:	aa0b03e5 	mov	x5, x11
    b060:	9b0b7d4a 	mul	x10, x10, x11
    b064:	b3607d23 	bfi	x3, x9, #32, #32
    b068:	eb03015f 	cmp	x10, x3
    b06c:	540000a9 	b.ls	b080 <__divti3+0x190>  // b.plast
    b070:	ab030103 	adds	x3, x8, x3
    b074:	d1000565 	sub	x5, x11, #0x1
    b078:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b07c:	54000e28 	b.hi	b240 <__divti3+0x350>  // b.pmore
    b080:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b084:	92407c48 	and	x8, x2, #0xffffffff
    b088:	2a0503e5 	mov	w5, w5
    b08c:	d360fc42 	lsr	x2, x2, #32
    b090:	d360fc26 	lsr	x6, x1, #32
    b094:	cb0a0063 	sub	x3, x3, x10
    b098:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b09c:	9b087caa 	mul	x10, x5, x8
    b0a0:	9b087cc8 	mul	x8, x6, x8
    b0a4:	9b0220a5 	madd	x5, x5, x2, x8
    b0a8:	9b027cc6 	mul	x6, x6, x2
    b0ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b0b0:	8b0900c5 	add	x5, x6, x9
    b0b4:	eb02011f 	cmp	x8, x2
    b0b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b0bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    b0c0:	eb06007f 	cmp	x3, x6
    b0c4:	540000e3 	b.cc	b0e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b0c8:	92407d4a 	and	x10, x10, #0xffffffff
    b0cc:	9ac72000 	lsl	x0, x0, x7
    b0d0:	8b028142 	add	x2, x10, x2, lsl #32
    b0d4:	eb02001f 	cmp	x0, x2
    b0d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b0dc:	54000a01 	b.ne	b21c <__divti3+0x32c>  // b.any
    b0e0:	d1000420 	sub	x0, x1, #0x1
    b0e4:	d2800001 	mov	x1, #0x0                   	// #0
    b0e8:	17ffffb4 	b	afb8 <__divti3+0xc8>
    b0ec:	b5000062 	cbnz	x2, b0f8 <__divti3+0x208>
    b0f0:	d2800022 	mov	x2, #0x1                   	// #1
    b0f4:	9ac30846 	udiv	x6, x2, x3
    b0f8:	dac010c8 	clz	x8, x6
    b0fc:	b5000408 	cbnz	x8, b17c <__divti3+0x28c>
    b100:	d360fcc9 	lsr	x9, x6, #32
    b104:	92407cc5 	and	x5, x6, #0xffffffff
    b108:	cb060023 	sub	x3, x1, x6
    b10c:	d2800021 	mov	x1, #0x1                   	// #1
    b110:	9ac90868 	udiv	x8, x3, x9
    b114:	9b098d03 	msub	x3, x8, x9, x3
    b118:	aa0803e0 	mov	x0, x8
    b11c:	9b057d02 	mul	x2, x8, x5
    b120:	93c78063 	extr	x3, x3, x7, #32
    b124:	eb03005f 	cmp	x2, x3
    b128:	540000a9 	b.ls	b13c <__divti3+0x24c>  // b.plast
    b12c:	ab0300c3 	adds	x3, x6, x3
    b130:	d1000500 	sub	x0, x8, #0x1
    b134:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b138:	54000968 	b.hi	b264 <__divti3+0x374>  // b.pmore
    b13c:	cb020063 	sub	x3, x3, x2
    b140:	9ac90862 	udiv	x2, x3, x9
    b144:	aa0203e8 	mov	x8, x2
    b148:	9b098c42 	msub	x2, x2, x9, x3
    b14c:	aa0703e3 	mov	x3, x7
    b150:	9b057d05 	mul	x5, x8, x5
    b154:	b3607c43 	bfi	x3, x2, #32, #32
    b158:	eb0300bf 	cmp	x5, x3
    b15c:	540000c9 	b.ls	b174 <__divti3+0x284>  // b.plast
    b160:	ab0300c2 	adds	x2, x6, x3
    b164:	d1000503 	sub	x3, x8, #0x1
    b168:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b16c:	d1000908 	sub	x8, x8, #0x2
    b170:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b174:	aa008100 	orr	x0, x8, x0, lsl #32
    b178:	17ffff90 	b	afb8 <__divti3+0xc8>
    b17c:	9ac820c6 	lsl	x6, x6, x8
    b180:	d2800803 	mov	x3, #0x40                  	// #64
    b184:	cb080063 	sub	x3, x3, x8
    b188:	d360fcc9 	lsr	x9, x6, #32
    b18c:	9ac82027 	lsl	x7, x1, x8
    b190:	92407cc5 	and	x5, x6, #0xffffffff
    b194:	9ac32422 	lsr	x2, x1, x3
    b198:	9ac32403 	lsr	x3, x0, x3
    b19c:	aa070063 	orr	x3, x3, x7
    b1a0:	9ac9084a 	udiv	x10, x2, x9
    b1a4:	9ac82007 	lsl	x7, x0, x8
    b1a8:	9b098940 	msub	x0, x10, x9, x2
    b1ac:	aa0a03e1 	mov	x1, x10
    b1b0:	9b0a7ca2 	mul	x2, x5, x10
    b1b4:	93c38000 	extr	x0, x0, x3, #32
    b1b8:	eb00005f 	cmp	x2, x0
    b1bc:	540000a9 	b.ls	b1d0 <__divti3+0x2e0>  // b.plast
    b1c0:	ab0000c0 	adds	x0, x6, x0
    b1c4:	d1000541 	sub	x1, x10, #0x1
    b1c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b1cc:	54000468 	b.hi	b258 <__divti3+0x368>  // b.pmore
    b1d0:	cb020000 	sub	x0, x0, x2
    b1d4:	9ac9080a 	udiv	x10, x0, x9
    b1d8:	9b098140 	msub	x0, x10, x9, x0
    b1dc:	aa0a03e2 	mov	x2, x10
    b1e0:	9b0a7ca8 	mul	x8, x5, x10
    b1e4:	b3607c03 	bfi	x3, x0, #32, #32
    b1e8:	eb03011f 	cmp	x8, x3
    b1ec:	540000a9 	b.ls	b200 <__divti3+0x310>  // b.plast
    b1f0:	ab0300c3 	adds	x3, x6, x3
    b1f4:	d1000542 	sub	x2, x10, #0x1
    b1f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b1fc:	54000288 	b.hi	b24c <__divti3+0x35c>  // b.pmore
    b200:	cb080063 	sub	x3, x3, x8
    b204:	aa018041 	orr	x1, x2, x1, lsl #32
    b208:	17ffffc2 	b	b110 <__divti3+0x220>
    b20c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b210:	d2800001 	mov	x1, #0x0                   	// #0
    b214:	9a9f87e0 	cset	x0, ls	// ls = plast
    b218:	17ffff68 	b	afb8 <__divti3+0xc8>
    b21c:	aa0103e0 	mov	x0, x1
    b220:	d2800001 	mov	x1, #0x0                   	// #0
    b224:	17ffff65 	b	afb8 <__divti3+0xc8>
    b228:	d1000860 	sub	x0, x3, #0x2
    b22c:	8b0600a5 	add	x5, x5, x6
    b230:	17ffff52 	b	af78 <__divti3+0x88>
    b234:	d1000961 	sub	x1, x11, #0x2
    b238:	8b0800a5 	add	x5, x5, x8
    b23c:	17ffff85 	b	b050 <__divti3+0x160>
    b240:	d1000965 	sub	x5, x11, #0x2
    b244:	8b080063 	add	x3, x3, x8
    b248:	17ffff8e 	b	b080 <__divti3+0x190>
    b24c:	d1000942 	sub	x2, x10, #0x2
    b250:	8b060063 	add	x3, x3, x6
    b254:	17ffffeb 	b	b200 <__divti3+0x310>
    b258:	d1000941 	sub	x1, x10, #0x2
    b25c:	8b060000 	add	x0, x0, x6
    b260:	17ffffdc 	b	b1d0 <__divti3+0x2e0>
    b264:	d1000900 	sub	x0, x8, #0x2
    b268:	8b060063 	add	x3, x3, x6
    b26c:	17ffffb4 	b	b13c <__divti3+0x24c>

000000000000b270 <__modti3>:
    b270:	d503245f 	bti	c
    b274:	d2800004 	mov	x4, #0x0                   	// #0
    b278:	b6f80081 	tbz	x1, #63, b288 <__modti3+0x18>
    b27c:	eb0003e0 	negs	x0, x0
    b280:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b284:	da0103e1 	ngc	x1, x1
    b288:	f100007f 	cmp	x3, #0x0
    b28c:	5400128b 	b.lt	b4dc <__modti3+0x26c>  // b.tstop
    b290:	aa0003e7 	mov	x7, x0
    b294:	aa0103e6 	mov	x6, x1
    b298:	540004e1 	b.ne	b334 <__modti3+0xc4>  // b.any
    b29c:	eb02003f 	cmp	x1, x2
    b2a0:	54000dc2 	b.cs	b458 <__modti3+0x1e8>  // b.hs, b.nlast
    b2a4:	dac01043 	clz	x3, x2
    b2a8:	aa0303e5 	mov	x5, x3
    b2ac:	b40000e3 	cbz	x3, b2c8 <__modti3+0x58>
    b2b0:	4b0303e6 	neg	w6, w3
    b2b4:	9ac32021 	lsl	x1, x1, x3
    b2b8:	9ac32042 	lsl	x2, x2, x3
    b2bc:	9ac62406 	lsr	x6, x0, x6
    b2c0:	aa0100c6 	orr	x6, x6, x1
    b2c4:	9ac32007 	lsl	x7, x0, x3
    b2c8:	d360fc40 	lsr	x0, x2, #32
    b2cc:	92407c43 	and	x3, x2, #0xffffffff
    b2d0:	9ac008c1 	udiv	x1, x6, x0
    b2d4:	9b009826 	msub	x6, x1, x0, x6
    b2d8:	9b017c61 	mul	x1, x3, x1
    b2dc:	93c780c6 	extr	x6, x6, x7, #32
    b2e0:	eb06003f 	cmp	x1, x6
    b2e4:	540000a9 	b.ls	b2f8 <__modti3+0x88>  // b.plast
    b2e8:	ab060046 	adds	x6, x2, x6
    b2ec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b2f0:	8b0200c8 	add	x8, x6, x2
    b2f4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b2f8:	cb0100c6 	sub	x6, x6, x1
    b2fc:	9ac008c8 	udiv	x8, x6, x0
    b300:	9b009901 	msub	x1, x8, x0, x6
    b304:	aa0703e0 	mov	x0, x7
    b308:	9b087c63 	mul	x3, x3, x8
    b30c:	b3607c20 	bfi	x0, x1, #32, #32
    b310:	eb00007f 	cmp	x3, x0
    b314:	54001088 	b.hi	b524 <__modti3+0x2b4>  // b.pmore
    b318:	cb030000 	sub	x0, x0, x3
    b31c:	9ac52400 	lsr	x0, x0, x5
    b320:	d2800001 	mov	x1, #0x0                   	// #0
    b324:	b4000064 	cbz	x4, b330 <__modti3+0xc0>
    b328:	eb0003e0 	negs	x0, x0
    b32c:	da0103e1 	ngc	x1, x1
    b330:	d65f03c0 	ret
    b334:	dac01066 	clz	x6, x3
    b338:	eb03003f 	cmp	x1, x3
    b33c:	54ffff43 	b.cc	b324 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b340:	93407cc5 	sxtw	x5, w6
    b344:	d2800808 	mov	x8, #0x40                  	// #64
    b348:	cb050108 	sub	x8, x8, x5
    b34c:	9ac62063 	lsl	x3, x3, x6
    b350:	9ac62025 	lsl	x5, x1, x6
    b354:	9ac82447 	lsr	x7, x2, x8
    b358:	aa0300e7 	orr	x7, x7, x3
    b35c:	9ac82423 	lsr	x3, x1, x8
    b360:	92407cec 	and	x12, x7, #0xffffffff
    b364:	d360fcea 	lsr	x10, x7, #32
    b368:	9ac82401 	lsr	x1, x0, x8
    b36c:	aa050021 	orr	x1, x1, x5
    b370:	9ac62042 	lsl	x2, x2, x6
    b374:	9ac62000 	lsl	x0, x0, x6
    b378:	9aca086b 	udiv	x11, x3, x10
    b37c:	9b0a8d63 	msub	x3, x11, x10, x3
    b380:	aa0b03e5 	mov	x5, x11
    b384:	9b0b7d89 	mul	x9, x12, x11
    b388:	93c18063 	extr	x3, x3, x1, #32
    b38c:	eb03013f 	cmp	x9, x3
    b390:	540000a9 	b.ls	b3a4 <__modti3+0x134>  // b.plast
    b394:	ab0300e3 	adds	x3, x7, x3
    b398:	d1000565 	sub	x5, x11, #0x1
    b39c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b3a0:	54001168 	b.hi	b5cc <__modti3+0x35c>  // b.pmore
    b3a4:	cb090063 	sub	x3, x3, x9
    b3a8:	9aca086b 	udiv	x11, x3, x10
    b3ac:	9b0a8d6a 	msub	x10, x11, x10, x3
    b3b0:	aa0b03e9 	mov	x9, x11
    b3b4:	9b0b7d8c 	mul	x12, x12, x11
    b3b8:	b3607d41 	bfi	x1, x10, #32, #32
    b3bc:	eb01019f 	cmp	x12, x1
    b3c0:	540000a9 	b.ls	b3d4 <__modti3+0x164>  // b.plast
    b3c4:	ab0100e1 	adds	x1, x7, x1
    b3c8:	d1000569 	sub	x9, x11, #0x1
    b3cc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b3d0:	54000f88 	b.hi	b5c0 <__modti3+0x350>  // b.pmore
    b3d4:	aa058123 	orr	x3, x9, x5, lsl #32
    b3d8:	92407c4b 	and	x11, x2, #0xffffffff
    b3dc:	2a0903e9 	mov	w9, w9
    b3e0:	d360fc4a 	lsr	x10, x2, #32
    b3e4:	d360fc63 	lsr	x3, x3, #32
    b3e8:	cb0c0021 	sub	x1, x1, x12
    b3ec:	aa0a03ec 	mov	x12, x10
    b3f0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b3f4:	9b0b7d25 	mul	x5, x9, x11
    b3f8:	9b0b7c6b 	mul	x11, x3, x11
    b3fc:	9b0a2d29 	madd	x9, x9, x10, x11
    b400:	92407caa 	and	x10, x5, #0xffffffff
    b404:	9b0c7c63 	mul	x3, x3, x12
    b408:	8b458125 	add	x5, x9, x5, lsr #32
    b40c:	8b0d0069 	add	x9, x3, x13
    b410:	eb05017f 	cmp	x11, x5
    b414:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b418:	8b058149 	add	x9, x10, x5, lsl #32
    b41c:	8b458063 	add	x3, x3, x5, lsr #32
    b420:	eb03003f 	cmp	x1, x3
    b424:	54000063 	b.cc	b430 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b428:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b42c:	54000082 	b.cs	b43c <__modti3+0x1cc>  // b.hs, b.nlast
    b430:	eb020129 	subs	x9, x9, x2
    b434:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b438:	cb070063 	sub	x3, x3, x7
    b43c:	eb090000 	subs	x0, x0, x9
    b440:	da030021 	sbc	x1, x1, x3
    b444:	9ac62400 	lsr	x0, x0, x6
    b448:	9ac82028 	lsl	x8, x1, x8
    b44c:	aa000100 	orr	x0, x8, x0
    b450:	9ac62421 	lsr	x1, x1, x6
    b454:	17ffffb4 	b	b324 <__modti3+0xb4>
    b458:	b5000062 	cbnz	x2, b464 <__modti3+0x1f4>
    b45c:	d2800023 	mov	x3, #0x1                   	// #1
    b460:	9ac20862 	udiv	x2, x3, x2
    b464:	dac01048 	clz	x8, x2
    b468:	aa0803e5 	mov	x5, x8
    b46c:	b5000668 	cbnz	x8, b538 <__modti3+0x2c8>
    b470:	cb020020 	sub	x0, x1, x2
    b474:	d360fc49 	lsr	x9, x2, #32
    b478:	92407c4a 	and	x10, x2, #0xffffffff
    b47c:	9ac90801 	udiv	x1, x0, x9
    b480:	9b098020 	msub	x0, x1, x9, x0
    b484:	9b0a7c21 	mul	x1, x1, x10
    b488:	93c78000 	extr	x0, x0, x7, #32
    b48c:	eb00003f 	cmp	x1, x0
    b490:	540000a9 	b.ls	b4a4 <__modti3+0x234>  // b.plast
    b494:	ab000040 	adds	x0, x2, x0
    b498:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b49c:	8b020003 	add	x3, x0, x2
    b4a0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b4a4:	cb010001 	sub	x1, x0, x1
    b4a8:	9ac90820 	udiv	x0, x1, x9
    b4ac:	9b098403 	msub	x3, x0, x9, x1
    b4b0:	aa0703e1 	mov	x1, x7
    b4b4:	9b0a7c00 	mul	x0, x0, x10
    b4b8:	b3607c61 	bfi	x1, x3, #32, #32
    b4bc:	eb01001f 	cmp	x0, x1
    b4c0:	540000a9 	b.ls	b4d4 <__modti3+0x264>  // b.plast
    b4c4:	ab010041 	adds	x1, x2, x1
    b4c8:	8b020022 	add	x2, x1, x2
    b4cc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b4d0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b4d4:	cb000020 	sub	x0, x1, x0
    b4d8:	17ffff91 	b	b31c <__modti3+0xac>
    b4dc:	eb0203e5 	negs	x5, x2
    b4e0:	aa0003e7 	mov	x7, x0
    b4e4:	da0303e8 	ngc	x8, x3
    b4e8:	aa0503e2 	mov	x2, x5
    b4ec:	aa0803e3 	mov	x3, x8
    b4f0:	aa0103e6 	mov	x6, x1
    b4f4:	b4ffed48 	cbz	x8, b29c <__modti3+0x2c>
    b4f8:	eb01011f 	cmp	x8, x1
    b4fc:	54fff148 	b.hi	b324 <__modti3+0xb4>  // b.pmore
    b500:	dac01109 	clz	x9, x8
    b504:	2a0903e6 	mov	w6, w9
    b508:	b5fff1c9 	cbnz	x9, b340 <__modti3+0xd0>
    b50c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b510:	54000068 	b.hi	b51c <__modti3+0x2ac>  // b.pmore
    b514:	eb050007 	subs	x7, x0, x5
    b518:	da080021 	sbc	x1, x1, x8
    b51c:	aa0703e0 	mov	x0, x7
    b520:	17ffff81 	b	b324 <__modti3+0xb4>
    b524:	ab000040 	adds	x0, x2, x0
    b528:	8b020002 	add	x2, x0, x2
    b52c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b530:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b534:	17ffff79 	b	b318 <__modti3+0xa8>
    b538:	9ac82042 	lsl	x2, x2, x8
    b53c:	d2800803 	mov	x3, #0x40                  	// #64
    b540:	cb080063 	sub	x3, x3, x8
    b544:	d360fc49 	lsr	x9, x2, #32
    b548:	9ac82027 	lsl	x7, x1, x8
    b54c:	92407c4a 	and	x10, x2, #0xffffffff
    b550:	9ac32426 	lsr	x6, x1, x3
    b554:	9ac32403 	lsr	x3, x0, x3
    b558:	aa070063 	orr	x3, x3, x7
    b55c:	9ac908c1 	udiv	x1, x6, x9
    b560:	9ac82007 	lsl	x7, x0, x8
    b564:	9b099820 	msub	x0, x1, x9, x6
    b568:	9b017d41 	mul	x1, x10, x1
    b56c:	93c38000 	extr	x0, x0, x3, #32
    b570:	eb00003f 	cmp	x1, x0
    b574:	540000a9 	b.ls	b588 <__modti3+0x318>  // b.plast
    b578:	ab000040 	adds	x0, x2, x0
    b57c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b580:	8b020006 	add	x6, x0, x2
    b584:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b588:	cb010000 	sub	x0, x0, x1
    b58c:	9ac90801 	udiv	x1, x0, x9
    b590:	9b098026 	msub	x6, x1, x9, x0
    b594:	aa0303e0 	mov	x0, x3
    b598:	9b017d41 	mul	x1, x10, x1
    b59c:	b3607cc0 	bfi	x0, x6, #32, #32
    b5a0:	eb00003f 	cmp	x1, x0
    b5a4:	540000a9 	b.ls	b5b8 <__modti3+0x348>  // b.plast
    b5a8:	ab000040 	adds	x0, x2, x0
    b5ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b5b0:	8b020003 	add	x3, x0, x2
    b5b4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b5b8:	cb010000 	sub	x0, x0, x1
    b5bc:	17ffffb0 	b	b47c <__modti3+0x20c>
    b5c0:	d1000969 	sub	x9, x11, #0x2
    b5c4:	8b070021 	add	x1, x1, x7
    b5c8:	17ffff83 	b	b3d4 <__modti3+0x164>
    b5cc:	d1000965 	sub	x5, x11, #0x2
    b5d0:	8b070063 	add	x3, x3, x7
    b5d4:	17ffff74 	b	b3a4 <__modti3+0x134>
    b5d8:	d503201f 	nop
    b5dc:	d503201f 	nop

000000000000b5e0 <atexit>:
    b5e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b5e4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b5e8:	d2800001 	mov	x1, #0x0                   	// #0
    b5ec:	910003fd 	mov	x29, sp
    b5f0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b5f4:	f9400442 	ldr	x2, [x2, #8]
    b5f8:	17ffdc46 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b5fc <_fini>:
    b5fc:	d503201f 	nop
    b600:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b604:	910003fd 	mov	x29, sp
    b608:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b60c:	d65f03c0 	ret
