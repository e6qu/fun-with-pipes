
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-199/fwp-ad-history-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__divti3+0x100>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912360a5 	add	x5, x5, #0x8d8
    2aa0:	b0000044 	adrp	x4, b000 <__divti3+0x100>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91238084 	add	x4, x4, #0x8e0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x107b0>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__divti3+0x100>
    2b34:	9132e000 	add	x0, x0, #0xcb8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	f0000022 	adrp	x2, 9000 <fwp_write+0x710>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91238042 	add	x2, x2, #0x8e0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435a60 	ldr	w0, [x19, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	b0000040 	adrp	x0, b000 <__divti3+0x100>
    2c7c:	91332000 	add	x0, x0, #0xcc8
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	b0000040 	adrp	x0, b000 <__divti3+0x100>
    2c8c:	9135a000 	add	x0, x0, #0xd68
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	b0000040 	adrp	x0, b000 <__divti3+0x100>
    2ca4:	91350000 	add	x0, x0, #0xd40
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	b0000040 	adrp	x0, b000 <__divti3+0x100>
    2cb0:	91344000 	add	x0, x0, #0xd10
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	b0000040 	adrp	x0, b000 <__divti3+0x100>
    2cbc:	9133a000 	add	x0, x0, #0xce8
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0x9e0>
    2eb4:	910f4021 	add	x1, x1, #0x3d0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3050:	9118a000 	add	x0, x0, #0x628
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x9e0>
    3118:	910ec021 	add	x1, x1, #0x3b0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3150:	91190000 	add	x0, x0, #0x640
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	90000042 	adrp	x2, b000 <__divti3+0x100>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	90000056 	adrp	x22, b000 <__divti3+0x100>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	b0000058 	adrp	x24, c000 <_IO_stdin_used+0x9e0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	911a2042 	add	x2, x2, #0x688
    31e0:	911b82d6 	add	x22, x22, #0x6e0
    31e4:	9104e318 	add	x24, x24, #0x138
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	90000059 	adrp	x25, b000 <__divti3+0x100>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	911b6323 	add	x3, x25, #0x6d8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	911bc000 	add	x0, x0, #0x6f0
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3570:	9118a000 	add	x0, x0, #0x628
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__divti3+0x100>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	911be021 	add	x1, x1, #0x6f8
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__divti3+0x100>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	911c0021 	add	x1, x1, #0x700
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__divti3+0x100>
    37e0:	911c2021 	add	x1, x1, #0x708
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	90000042 	adrp	x2, b000 <__divti3+0x100>
    3838:	aa1303e3 	mov	x3, x19
    383c:	911c4042 	add	x2, x2, #0x710
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3950:	9118a000 	add	x0, x0, #0x628
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3970:	911c8000 	add	x0, x0, #0x720
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3a08:	911d0000 	add	x0, x0, #0x740
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3a18:	911d8000 	add	x0, x0, #0x760
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x9e0>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0f820 	ldr	q0, [x1, #992]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3b18:	911e2000 	add	x0, x0, #0x788
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3b88:	911ee000 	add	x0, x0, #0x7b8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	90000044 	adrp	x4, b000 <__divti3+0x100>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	91202084 	add	x4, x4, #0x808
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	90000044 	adrp	x4, b000 <__divti3+0x100>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91208084 	add	x4, x4, #0x820
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	90000044 	adrp	x4, b000 <__divti3+0x100>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91204084 	add	x4, x4, #0x810
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3fa8:	91174042 	add	x2, x2, #0x5d0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	90000041 	adrp	x1, b000 <__divti3+0x100>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	90000040 	adrp	x0, b000 <__divti3+0x100>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	9120a021 	add	x1, x1, #0x828
    4004:	9120c000 	add	x0, x0, #0x830
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	f0000022 	adrp	x2, b000 <__divti3+0x100>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91214042 	add	x2, x2, #0x850
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    410c:	91134061 	add	x1, x3, #0x4d0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    411c:	91174262 	add	x2, x19, #0x5d0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	90000042 	adrp	x2, c000 <_IO_stdin_used+0x9e0>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    414c:	91144021 	add	x1, x1, #0x510
    4150:	3dc0fc43 	ldr	q3, [x2, #1008]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    417c:	91134063 	add	x3, x3, #0x4d0
    4180:	9115c084 	add	x4, x4, #0x570
    4184:	91174266 	add	x6, x19, #0x5d0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91174275 	add	x21, x19, #0x5d0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    4268:	91240000 	add	x0, x0, #0x900
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91174273 	add	x19, x19, #0x5d0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	9101c122 	add	x2, x9, #0x70
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9403c46 	ldr	x6, [x2, #120]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	9101c120 	add	x0, x9, #0x70
    4354:	f900400b 	str	x11, [x0, #128]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	9101c129 	add	x9, x9, #0x70
    4360:	f9003d26 	str	x6, [x9, #120]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <fwp_tape_buffers_release>:
    4380:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4384:	910003fd 	mov	x29, sp
    4388:	a90153f3 	stp	x19, x20, [sp, #16]
    438c:	aa0003f3 	mov	x19, x0
    4390:	f9401400 	ldr	x0, [x0, #40]
    4394:	b7f80760 	tbnz	x0, #63, 4480 <fwp_tape_buffers_release+0x100>
    4398:	f9401a61 	ldr	x1, [x19, #48]
    439c:	b7f80301 	tbnz	x1, #63, 43fc <fwp_tape_buffers_release+0x7c>
    43a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43a4:	eb02001f 	cmp	x0, x2
    43a8:	540002a8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43ac:	8b000400 	add	x0, x0, x0, lsl #1
    43b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    43b4:	d37df000 	lsl	x0, x0, #3
    43b8:	cb000042 	sub	x2, x2, x0
    43bc:	eb420c3f 	cmp	x1, x2, lsr #3
    43c0:	540001e8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43c4:	8b010c14 	add	x20, x0, x1, lsl #3
    43c8:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    43cc:	91244000 	add	x0, x0, #0x910
    43d0:	97fff990 	bl	2a10 <getenv@plt>
    43d4:	b4000240 	cbz	x0, 441c <fwp_tape_buffers_release+0x9c>
    43d8:	39400001 	ldrb	w1, [x0]
    43dc:	7100c03f 	cmp	w1, #0x30
    43e0:	540001e1 	b.ne	441c <fwp_tape_buffers_release+0x9c>  // b.any
    43e4:	39400400 	ldrb	w0, [x0, #1]
    43e8:	350001a0 	cbnz	w0, 441c <fwp_tape_buffers_release+0x9c>
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f8:	17fffc22 	b	3480 <fwp_tape_buffers_dispose>
    43fc:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    4400:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4404:	91244000 	add	x0, x0, #0x910
    4408:	97fff982 	bl	2a10 <getenv@plt>
    440c:	b4ffff00 	cbz	x0, 43ec <fwp_tape_buffers_release+0x6c>
    4410:	39400001 	ldrb	w1, [x0]
    4414:	7100c03f 	cmp	w1, #0x30
    4418:	54fffe60 	b.eq	43e4 <fwp_tape_buffers_release+0x64>  // b.none
    441c:	d1000681 	sub	x1, x20, #0x1
    4420:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4424:	eb00003f 	cmp	x1, x0
    4428:	54fffe28 	b.hi	43ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    442c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4430:	900000f6 	adrp	x22, 20000 <__data_start>
    4434:	9101c2d6 	add	x22, x22, #0x70
    4438:	910262d5 	add	x21, x22, #0x98
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fffc10 	bl	3480 <fwp_tape_buffers_dispose>
    4444:	ad400a61 	ldp	q1, q2, [x19]
    4448:	f9006ad4 	str	x20, [x22, #208]
    444c:	4f000400 	movi	v0.4s, #0x0
    4450:	ad000aa1 	stp	q1, q2, [x21]
    4454:	3dc00a61 	ldr	q1, [x19, #32]
    4458:	3d800aa1 	str	q1, [x21, #32]
    445c:	f9401a60 	ldr	x0, [x19, #48]
    4460:	f9001aa0 	str	x0, [x21, #48]
    4464:	f9001a7f 	str	xzr, [x19, #48]
    4468:	ad000260 	stp	q0, q0, [x19]
    446c:	3d800a60 	str	q0, [x19, #32]
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4478:	a8c37bfd 	ldp	x29, x30, [sp], #48
    447c:	d65f03c0 	ret
    4480:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    4484:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4488:	91244000 	add	x0, x0, #0x910
    448c:	97fff961 	bl	2a10 <getenv@plt>
    4490:	b5fffa40 	cbnz	x0, 43d8 <fwp_tape_buffers_release+0x58>
    4494:	17ffffd6 	b	43ec <fwp_tape_buffers_release+0x6c>
    4498:	d503201f 	nop
    449c:	d503201f 	nop

00000000000044a0 <fwp_poll_events>:
    44a0:	d10103ff 	sub	sp, sp, #0x40
    44a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44a8:	f947f400 	ldr	x0, [x0, #4072]
    44ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    44b0:	910083fd 	add	x29, sp, #0x20
    44b4:	a90353f3 	stp	x19, x20, [sp, #48]
    44b8:	900000f4 	adrp	x20, 20000 <__data_start>
    44bc:	f9400001 	ldr	x1, [x0]
    44c0:	f9000fe1 	str	x1, [sp, #24]
    44c4:	d2800001 	mov	x1, #0x0                   	// #0
    44c8:	97fffd2e 	bl	3980 <fwp_now_ns>
    44cc:	9101c281 	add	x1, x20, #0x70
    44d0:	f9406c33 	ldr	x19, [x1, #216]
    44d4:	b4000e93 	cbz	x19, 46a4 <fwp_poll_events+0x204>
    44d8:	aa1303e1 	mov	x1, x19
    44dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    44e0:	14000005 	b	44f4 <fwp_poll_events+0x54>
    44e4:	f9408821 	ldr	x1, [x1, #272]
    44e8:	eb03005f 	cmp	x2, x3
    44ec:	9a83d042 	csel	x2, x2, x3, le
    44f0:	b40000c1 	cbz	x1, 4508 <fwp_poll_events+0x68>
    44f4:	f9403423 	ldr	x3, [x1, #104]
    44f8:	b6ffff62 	tbz	x2, #63, 44e4 <fwp_poll_events+0x44>
    44fc:	f9408821 	ldr	x1, [x1, #272]
    4500:	aa0303e2 	mov	x2, x3
    4504:	b5ffff81 	cbnz	x1, 44f4 <fwp_poll_events+0x54>
    4508:	b7f80ce2 	tbnz	x2, #63, 46a4 <fwp_poll_events+0x204>
    450c:	cb000042 	sub	x2, x2, x0
    4510:	f100005f 	cmp	x2, #0x0
    4514:	540005cd 	b.le	45cc <fwp_poll_events+0x12c>
    4518:	d2869b60 	mov	x0, #0x34db                	// #13531
    451c:	d2884801 	mov	x1, #0x4240                	// #16960
    4520:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4524:	f2a001e1 	movk	x1, #0xf, lsl #16
    4528:	f2dbd040 	movk	x0, #0xde82, lsl #32
    452c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4530:	f2e86360 	movk	x0, #0x431b, lsl #48
    4534:	9b407c40 	smulh	x0, x2, x0
    4538:	9352fc00 	asr	x0, x0, #18
    453c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4540:	9b018802 	msub	x2, x0, x1, x2
    4544:	f100005f 	cmp	x2, #0x0
    4548:	9a800400 	cinc	x0, x0, ne	// ne = any
    454c:	eb03001f 	cmp	x0, x3
    4550:	54000a0c 	b.gt	4690 <fwp_poll_events+0x1f0>
    4554:	340003c0 	cbz	w0, 45cc <fwp_poll_events+0x12c>
    4558:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    455c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4560:	72a20c42 	movk	w2, #0x1062, lsl #16
    4564:	9ba27c02 	umull	x2, w0, w2
    4568:	d366fc43 	lsr	x3, x2, #38
    456c:	aa0303e2 	mov	x2, x3
    4570:	1b048063 	msub	w3, w3, w4, w0
    4574:	9b217c63 	smull	x3, w3, w1
    4578:	d2800001 	mov	x1, #0x0                   	// #0
    457c:	910023e0 	add	x0, sp, #0x8
    4580:	a9008fe2 	stp	x2, x3, [sp, #8]
    4584:	97fff8f3 	bl	2950 <nanosleep@plt>
    4588:	9101c280 	add	x0, x20, #0x70
    458c:	f9406c13 	ldr	x19, [x0, #216]
    4590:	97fffcfc 	bl	3980 <fwp_now_ns>
    4594:	aa0003e6 	mov	x6, x0
    4598:	b50001f3 	cbnz	x19, 45d4 <fwp_poll_events+0x134>
    459c:	d503201f 	nop
    45a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45a4:	f947f400 	ldr	x0, [x0, #4072]
    45a8:	f9400fe2 	ldr	x2, [sp, #24]
    45ac:	f9400001 	ldr	x1, [x0]
    45b0:	eb010042 	subs	x2, x2, x1
    45b4:	d2800001 	mov	x1, #0x0                   	// #0
    45b8:	540008c1 	b.ne	46d0 <fwp_poll_events+0x230>  // b.any
    45bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    45c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    45c4:	910103ff 	add	sp, sp, #0x40
    45c8:	d65f03c0 	ret
    45cc:	97fffced 	bl	3980 <fwp_now_ns>
    45d0:	aa0003e6 	mov	x6, x0
    45d4:	4f000400 	movi	v0.4s, #0x0
    45d8:	9101c288 	add	x8, x20, #0x70
    45dc:	52800027 	mov	w7, #0x1                   	// #1
    45e0:	f9403661 	ldr	x1, [x19, #104]
    45e4:	aa1303e5 	mov	x5, x19
    45e8:	f9408a73 	ldr	x19, [x19, #272]
    45ec:	eb06003f 	cmp	x1, x6
    45f0:	5400032c 	b.gt	4654 <fwp_poll_events+0x1b4>
    45f4:	394154a0 	ldrb	w0, [x5, #85]
    45f8:	36000120 	tbz	w0, #0, 461c <fwp_poll_events+0x17c>
    45fc:	f94084a0 	ldr	x0, [x5, #264]
    4600:	b40003c0 	cbz	x0, 4678 <fwp_poll_events+0x1d8>
    4604:	f9008813 	str	x19, [x0, #272]
    4608:	b4000053 	cbz	x19, 4610 <fwp_poll_events+0x170>
    460c:	f9008660 	str	x0, [x19, #264]
    4610:	910800a0 	add	x0, x5, #0x200
    4614:	390154bf 	strb	wzr, [x5, #85]
    4618:	3c908000 	stur	q0, [x0, #-248]
    461c:	f94030a0 	ldr	x0, [x5, #96]
    4620:	390158a7 	strb	w7, [x5, #86]
    4624:	f100001f 	cmp	x0, #0x0
    4628:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    462c:	5400018d 	b.le	465c <fwp_poll_events+0x1bc>
    4630:	f94028a0 	ldr	x0, [x5, #80]
    4634:	f2001c1f 	tst	x0, #0xff000000ff
    4638:	540000e1 	b.ne	4654 <fwp_poll_events+0x1b4>  // b.any
    463c:	f9403d00 	ldr	x0, [x8, #120]
    4640:	390150a7 	strb	w7, [x5, #84]
    4644:	f90080bf 	str	xzr, [x5, #256]
    4648:	b40001e0 	cbz	x0, 4684 <fwp_poll_events+0x1e4>
    464c:	f9003d05 	str	x5, [x8, #120]
    4650:	f9008005 	str	x5, [x0, #256]
    4654:	b5fffc73 	cbnz	x19, 45e0 <fwp_poll_events+0x140>
    4658:	17ffffd2 	b	45a0 <fwp_poll_events+0x100>
    465c:	394144a0 	ldrb	w0, [x5, #81]
    4660:	3707fe80 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    4664:	394140a0 	ldrb	w0, [x5, #80]
    4668:	3707fe40 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    466c:	aa0503e0 	mov	x0, x5
    4670:	97fffc20 	bl	36f0 <fwp_cancel_tree.part.0>
    4674:	17ffffef 	b	4630 <fwp_poll_events+0x190>
    4678:	9101c281 	add	x1, x20, #0x70
    467c:	f9006c33 	str	x19, [x1, #216]
    4680:	17ffffe2 	b	4608 <fwp_poll_events+0x168>
    4684:	f9003d05 	str	x5, [x8, #120]
    4688:	f9004105 	str	x5, [x8, #128]
    468c:	17fffff2 	b	4654 <fwp_poll_events+0x1b4>
    4690:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4694:	d2989362 	mov	x2, #0xc49b                	// #50331
    4698:	f2a4d203 	movk	x3, #0x2690, lsl #16
    469c:	f2a00402 	movk	x2, #0x20, lsl #16
    46a0:	17ffffb6 	b	4578 <fwp_poll_events+0xd8>
    46a4:	97fffa53 	bl	2ff0 <fwp_flush>
    46a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46ac:	f947e863 	ldr	x3, [x3, #4048]
    46b0:	d2800562 	mov	x2, #0x2b                  	// #43
    46b4:	d2800021 	mov	x1, #0x1                   	// #1
    46b8:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    46bc:	9124a000 	add	x0, x0, #0x928
    46c0:	f9400063 	ldr	x3, [x3]
    46c4:	97fff8af 	bl	2980 <fwrite@plt>
    46c8:	52800ca0 	mov	w0, #0x65                  	// #101
    46cc:	97fff819 	bl	2730 <exit@plt>
    46d0:	97fff86c 	bl	2880 <__stack_chk_fail@plt>

00000000000046d4 <fwp_rc_wide_dup>:
    46d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    46d8:	910003fd 	mov	x29, sp
    46dc:	a90153f3 	stp	x19, x20, [sp, #16]
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	ca404400 	eor	x0, x0, x0, lsr #17
    46e8:	f90013f5 	str	x21, [sp, #32]
    46ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    46f0:	ca402400 	eor	x0, x0, x0, lsr #9
    46f4:	911742a2 	add	x2, x21, #0x5d0
    46f8:	92401c00 	and	x0, x0, #0xff
    46fc:	910a2403 	add	x3, x0, #0x289
    4700:	8b000c40 	add	x0, x2, x0, lsl #3
    4704:	8b030c54 	add	x20, x2, x3, lsl #3
    4708:	f94a2401 	ldr	x1, [x0, #5192]
    470c:	b50000a1 	cbnz	x1, 4720 <fwp_rc_wide_dup+0x4c>
    4710:	1400002d 	b	47c4 <fwp_rc_wide_dup+0xf0>
    4714:	91004034 	add	x20, x1, #0x10
    4718:	f9400821 	ldr	x1, [x1, #16]
    471c:	b4000241 	cbz	x1, 4764 <fwp_rc_wide_dup+0x90>
    4720:	f9400022 	ldr	x2, [x1]
    4724:	eb02027f 	cmp	x19, x2
    4728:	54ffff61 	b.ne	4714 <fwp_rc_wide_dup+0x40>  // b.any
    472c:	f9400281 	ldr	x1, [x20]
    4730:	39400260 	ldrb	w0, [x19]
    4734:	7103f81f 	cmp	w0, #0xfe
    4738:	54000220 	b.eq	477c <fwp_rc_wide_dup+0xa8>  // b.none
    473c:	b40001a1 	cbz	x1, 4770 <fwp_rc_wide_dup+0x9c>
    4740:	f9400420 	ldr	x0, [x1, #8]
    4744:	b100041f 	cmn	x0, #0x1
    4748:	540004a0 	b.eq	47dc <fwp_rc_wide_dup+0x108>  // b.none
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f9000420 	str	x0, [x1, #8]
    4754:	a94153f3 	ldp	x19, x20, [sp, #16]
    4758:	f94013f5 	ldr	x21, [sp, #32]
    475c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4760:	d65f03c0 	ret
    4764:	39400260 	ldrb	w0, [x19]
    4768:	7103f81f 	cmp	w0, #0xfe
    476c:	540000a0 	b.eq	4780 <fwp_rc_wide_dup+0xac>  // b.none
    4770:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    4774:	91260000 	add	x0, x0, #0x980
    4778:	97fffc22 	bl	3800 <fwp_trap>
    477c:	b5000281 	cbnz	x1, 47cc <fwp_rc_wide_dup+0xf8>
    4780:	d2800300 	mov	x0, #0x18                  	// #24
    4784:	97fff827 	bl	2820 <malloc@plt>
    4788:	b4000280 	cbz	x0, 47d8 <fwp_rc_wide_dup+0x104>
    478c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4790:	a9000413 	stp	x19, x1, [x0]
    4794:	911742b5 	add	x21, x21, #0x5d0
    4798:	f900081f 	str	xzr, [x0, #16]
    479c:	12800001 	mov	w1, #0xffffffff            	// #-1
    47a0:	f9000280 	str	x0, [x20]
    47a4:	39000261 	strb	w1, [x19]
    47a8:	f94e26a0 	ldr	x0, [x21, #7240]
    47ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b0:	91000400 	add	x0, x0, #0x1
    47b4:	f90e26a0 	str	x0, [x21, #7240]
    47b8:	f94013f5 	ldr	x21, [sp, #32]
    47bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47c0:	d65f03c0 	ret
    47c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    47c8:	17ffffda 	b	4730 <fwp_rc_wide_dup+0x5c>
    47cc:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    47d0:	91256000 	add	x0, x0, #0x958
    47d4:	97fffc0b 	bl	3800 <fwp_trap>
    47d8:	97fffa16 	bl	3030 <fwp_heap_oom>
    47dc:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    47e0:	9126a000 	add	x0, x0, #0x9a8
    47e4:	97fffc07 	bl	3800 <fwp_trap>
    47e8:	d503201f 	nop
    47ec:	d503201f 	nop

00000000000047f0 <fwp_rc_forget_slot>:
    47f0:	aa0003e1 	mov	x1, x0
    47f4:	39400000 	ldrb	w0, [x0]
    47f8:	7103fc1f 	cmp	w0, #0xff
    47fc:	54000040 	b.eq	4804 <fwp_rc_forget_slot+0x14>  // b.none
    4800:	d65f03c0 	ret
    4804:	ca414420 	eor	x0, x1, x1, lsr #17
    4808:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    480c:	ca402400 	eor	x0, x0, x0, lsr #9
    4810:	910003fd 	mov	x29, sp
    4814:	92401c00 	and	x0, x0, #0xff
    4818:	f9000bf3 	str	x19, [sp, #16]
    481c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4820:	91174262 	add	x2, x19, #0x5d0
    4824:	910a2403 	add	x3, x0, #0x289
    4828:	8b000c40 	add	x0, x2, x0, lsl #3
    482c:	8b030c43 	add	x3, x2, x3, lsl #3
    4830:	f94a2400 	ldr	x0, [x0, #5192]
    4834:	b50000a0 	cbnz	x0, 4848 <fwp_rc_forget_slot+0x58>
    4838:	14000011 	b	487c <fwp_rc_forget_slot+0x8c>
    483c:	91004003 	add	x3, x0, #0x10
    4840:	f9400800 	ldr	x0, [x0, #16]
    4844:	b40001c0 	cbz	x0, 487c <fwp_rc_forget_slot+0x8c>
    4848:	f9400002 	ldr	x2, [x0]
    484c:	eb02003f 	cmp	x1, x2
    4850:	54ffff61 	b.ne	483c <fwp_rc_forget_slot+0x4c>  // b.any
    4854:	f9400801 	ldr	x1, [x0, #16]
    4858:	91174273 	add	x19, x19, #0x5d0
    485c:	f9000061 	str	x1, [x3]
    4860:	97fff838 	bl	2940 <free@plt>
    4864:	f94e2660 	ldr	x0, [x19, #7240]
    4868:	d1000400 	sub	x0, x0, #0x1
    486c:	f90e2660 	str	x0, [x19, #7240]
    4870:	f9400bf3 	ldr	x19, [sp, #16]
    4874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4878:	d65f03c0 	ret
    487c:	f0000020 	adrp	x0, b000 <__divti3+0x100>
    4880:	91260000 	add	x0, x0, #0x980
    4884:	97fffbdf 	bl	3800 <fwp_trap>
    4888:	d503201f 	nop
    488c:	d503201f 	nop

0000000000004890 <fwp_rc_prepare_chunk>:
    4890:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4894:	910003fd 	mov	x29, sp
    4898:	a9025bf5 	stp	x21, x22, [sp, #32]
    489c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    48a0:	911742c2 	add	x2, x22, #0x5d0
    48a4:	b9401c03 	ldr	w3, [x0, #28]
    48a8:	aa0103f5 	mov	x21, x1
    48ac:	a90153f3 	stp	x19, x20, [sp, #16]
    48b0:	aa0003f4 	mov	x20, x0
    48b4:	f94e2440 	ldr	x0, [x2, #7240]
    48b8:	b4000440 	cbz	x0, 4940 <fwp_rc_prepare_chunk+0xb0>
    48bc:	d2800013 	mov	x19, #0x0                   	// #0
    48c0:	35000203 	cbnz	w3, 4900 <fwp_rc_prepare_chunk+0x70>
    48c4:	b4000361 	cbz	x1, 4930 <fwp_rc_prepare_chunk+0xa0>
    48c8:	f9401280 	ldr	x0, [x20, #32]
    48cc:	97fff81d 	bl	2940 <free@plt>
    48d0:	aa1503e0 	mov	x0, x21
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	97fff7e2 	bl	2860 <calloc@plt>
    48dc:	f9001280 	str	x0, [x20, #32]
    48e0:	b5000460 	cbnz	x0, 496c <fwp_rc_prepare_chunk+0xdc>
    48e4:	97fff9d3 	bl	3030 <fwp_heap_oom>
    48e8:	97ffffc2 	bl	47f0 <fwp_rc_forget_slot>
    48ec:	91000673 	add	x19, x19, #0x1
    48f0:	b9401e83 	ldr	w3, [x20, #28]
    48f4:	eb13007f 	cmp	x3, x19
    48f8:	54000169 	b.ls	4924 <fwp_rc_prepare_chunk+0x94>  // b.plast
    48fc:	d503201f 	nop
    4900:	f9401283 	ldr	x3, [x20, #32]
    4904:	8b130060 	add	x0, x3, x19
    4908:	38736863 	ldrb	w3, [x3, x19]
    490c:	7103fc7f 	cmp	w3, #0xff
    4910:	54fffec0 	b.eq	48e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4914:	b9401e83 	ldr	w3, [x20, #28]
    4918:	91000673 	add	x19, x19, #0x1
    491c:	eb13007f 	cmp	x3, x19
    4920:	54ffff08 	b.hi	4900 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4924:	eb0302bf 	cmp	x21, x3
    4928:	54000121 	b.ne	494c <fwp_rc_prepare_chunk+0xbc>  // b.any
    492c:	b5000335 	cbnz	x21, 4990 <fwp_rc_prepare_chunk+0x100>
    4930:	a94153f3 	ldp	x19, x20, [sp, #16]
    4934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    493c:	d65f03c0 	ret
    4940:	2a0303e3 	mov	w3, w3
    4944:	eb0302bf 	cmp	x21, x3
    4948:	54ffff20 	b.eq	492c <fwp_rc_prepare_chunk+0x9c>  // b.none
    494c:	911742c2 	add	x2, x22, #0x5d0
    4950:	f9401280 	ldr	x0, [x20, #32]
    4954:	f94e2841 	ldr	x1, [x2, #7248]
    4958:	cb030021 	sub	x1, x1, x3
    495c:	f90e2841 	str	x1, [x2, #7248]
    4960:	97fff7f8 	bl	2940 <free@plt>
    4964:	b5fffb75 	cbnz	x21, 48d0 <fwp_rc_prepare_chunk+0x40>
    4968:	f900129f 	str	xzr, [x20, #32]
    496c:	911742d6 	add	x22, x22, #0x5d0
    4970:	f94e2ac0 	ldr	x0, [x22, #7248]
    4974:	b9001e95 	str	w21, [x20, #28]
    4978:	a94153f3 	ldp	x19, x20, [sp, #16]
    497c:	8b150000 	add	x0, x0, x21
    4980:	f90e2ac0 	str	x0, [x22, #7248]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	f9401280 	ldr	x0, [x20, #32]
    4994:	aa1503e2 	mov	x2, x21
    4998:	a94153f3 	ldp	x19, x20, [sp, #16]
    499c:	52800001 	mov	w1, #0x0                   	// #0
    49a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49a8:	17fff7aa 	b	2850 <memset@plt>
    49ac:	d503201f 	nop

00000000000049b0 <fwp_heap_refill>:
    49b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49b4:	910003fd 	mov	x29, sp
    49b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    49bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    49c0:	911742b5 	add	x21, x21, #0x5d0
    49c4:	aa0003f6 	mov	x22, x0
    49c8:	d2800020 	mov	x0, #0x1                   	// #1
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a90363f7 	stp	x23, x24, [sp, #48]
    49d4:	2a0103f7 	mov	w23, w1
    49d8:	2a0203f8 	mov	w24, w2
    49dc:	97fffa35 	bl	32b0 <fwp_heap_chunks>
    49e0:	aa0003f3 	mov	x19, x0
    49e4:	f949fea2 	ldr	x2, [x21, #5112]
    49e8:	8b000800 	add	x0, x0, x0, lsl #2
    49ec:	2a1703e1 	mov	w1, w23
    49f0:	52800025 	mov	w5, #0x1                   	// #1
    49f4:	d37df000 	lsl	x0, x0, #3
    49f8:	910f0021 	add	x1, x1, #0x3c0
    49fc:	8b000054 	add	x20, x2, x0
    4a00:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a04:	52a00024 	mov	w4, #0x10000               	// #65536
    4a08:	38206845 	strb	w5, [x2, x0]
    4a0c:	aa1403e0 	mov	x0, x20
    4a10:	39000698 	strb	w24, [x20, #1]
    4a14:	39000a97 	strb	w23, [x20, #2]
    4a18:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a1c:	b9000681 	str	w1, [x20, #4]
    4a20:	2a0103e5 	mov	w5, w1
    4a24:	8b0300a2 	add	x2, x5, x3
    4a28:	1ac10881 	udiv	w1, w4, w1
    4a2c:	9ac50842 	udiv	x2, x2, x5
    4a30:	b9000a81 	str	w1, [x20, #8]
    4a34:	92404021 	and	x1, x1, #0x1ffff
    4a38:	b9001a82 	str	w2, [x20, #24]
    4a3c:	97ffff95 	bl	4890 <fwp_rc_prepare_chunk>
    4a40:	f949daa0 	ldr	x0, [x21, #5040]
    4a44:	29408a81 	ldp	w1, w2, [x20, #4]
    4a48:	8b134000 	add	x0, x0, x19, lsl #16
    4a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a50:	8b214003 	add	x3, x0, w1, uxtw
    4a54:	9ba20021 	umaddl	x1, w1, w2, x0
    4a58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a5c:	a90086c3 	stp	x3, x1, [x22, #8]
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a68:	d65f03c0 	ret
    4a6c:	d503201f 	nop

0000000000004a70 <fwp_mem_free>:
    4a70:	b40003c0 	cbz	x0, 4ae8 <fwp_mem_free+0x78>
    4a74:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a80:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a84:	911742a1 	add	x1, x21, #0x5d0
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	aa0003f3 	mov	x19, x0
    4a90:	f949d823 	ldr	x3, [x1, #5040]
    4a94:	f949ec22 	ldr	x2, [x1, #5080]
    4a98:	cb030000 	sub	x0, x0, x3
    4a9c:	eb02401f 	cmp	x0, x2, lsl #16
    4aa0:	540001c2 	b.cs	4ad8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4aa4:	d350fc16 	lsr	x22, x0, #16
    4aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    4aac:	f949fc22 	ldr	x2, [x1, #5112]
    4ab0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ab4:	d37df294 	lsl	x20, x20, #3
    4ab8:	ab140057 	adds	x23, x2, x20
    4abc:	540000c0 	b.eq	4ad4 <fwp_mem_free+0x64>  // b.none
    4ac0:	38746842 	ldrb	w2, [x2, x20]
    4ac4:	7100045f 	cmp	w2, #0x1
    4ac8:	54000120 	b.eq	4aec <fwp_mem_free+0x7c>  // b.none
    4acc:	7100085f 	cmp	w2, #0x2
    4ad0:	540005e0 	b.eq	4b8c <fwp_mem_free+0x11c>  // b.none
    4ad4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ae4:	d65f03c0 	ret
    4ae8:	d65f03c0 	ret
    4aec:	f94012f8 	ldr	x24, [x23, #32]
    4af0:	b94006e1 	ldr	w1, [x23, #4]
    4af4:	f90023f9 	str	x25, [sp, #64]
    4af8:	2a0103e2 	mov	w2, w1
    4afc:	394006f9 	ldrb	w25, [x23, #1]
    4b00:	39400af4 	ldrb	w20, [x23, #2]
    4b04:	b4000158 	cbz	x24, 4b2c <fwp_mem_free+0xbc>
    4b08:	92403e76 	and	x22, x19, #0xffff
    4b0c:	9ac20ad6 	udiv	x22, x22, x2
    4b10:	38766b01 	ldrb	w1, [x24, x22]
    4b14:	8b160300 	add	x0, x24, x22
    4b18:	7103fc3f 	cmp	w1, #0xff
    4b1c:	54000980 	b.eq	4c4c <fwp_mem_free+0x1dc>  // b.none
    4b20:	38366b1f 	strb	wzr, [x24, x22]
    4b24:	b94006e1 	ldr	w1, [x23, #4]
    4b28:	2a0103e2 	mov	w2, w1
    4b2c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b30:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b34:	cb390000 	sub	x0, x0, w25, uxtb
    4b38:	8b340074 	add	x20, x3, w20, uxtb
    4b3c:	911742b5 	add	x21, x21, #0x5d0
    4b40:	1e630021 	ucvtf	d1, w1
    4b44:	d37ae400 	lsl	x0, x0, #6
    4b48:	8b140c14 	add	x20, x0, x20, lsl #3
    4b4c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b50:	f8746aa0 	ldr	x0, [x21, x20]
    4b54:	f94023f9 	ldr	x25, [sp, #64]
    4b58:	aa2003e0 	mvn	x0, x0
    4b5c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4b60:	f9000260 	str	x0, [x19]
    4b64:	f8346ab3 	str	x19, [x21, x20]
    4b68:	f94a12a0 	ldr	x0, [x21, #5152]
    4b6c:	1e612800 	fadd	d0, d0, d1
    4b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b74:	cb020000 	sub	x0, x0, x2
    4b78:	f90a12a0 	str	x0, [x21, #5152]
    4b7c:	fd0a22a0 	str	d0, [x21, #5184]
    4b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b84:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b88:	d65f03c0 	ret
    4b8c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4b90:	8b000063 	add	x3, x3, x0
    4b94:	eb03027f 	cmp	x19, x3
    4b98:	54fff9e1 	b.ne	4ad4 <fwp_mem_free+0x64>  // b.any
    4b9c:	fd400ae1 	ldr	d1, [x23, #16]
    4ba0:	fd4a2020 	ldr	d0, [x1, #5184]
    4ba4:	f9400ae0 	ldr	x0, [x23, #16]
    4ba8:	7e61d821 	ucvtf	d1, d1
    4bac:	f94a1022 	ldr	x2, [x1, #5152]
    4bb0:	f94012f3 	ldr	x19, [x23, #32]
    4bb4:	1e612800 	fadd	d0, d0, d1
    4bb8:	cb000042 	sub	x2, x2, x0
    4bbc:	f90a1022 	str	x2, [x1, #5152]
    4bc0:	fd0a2020 	str	d0, [x1, #5184]
    4bc4:	b40000b3 	cbz	x19, 4bd8 <fwp_mem_free+0x168>
    4bc8:	39400260 	ldrb	w0, [x19]
    4bcc:	7103fc1f 	cmp	w0, #0xff
    4bd0:	54000380 	b.eq	4c40 <fwp_mem_free+0x1d0>  // b.none
    4bd4:	3900027f 	strb	wzr, [x19]
    4bd8:	b9400ee2 	ldr	w2, [x23, #12]
    4bdc:	b4000142 	cbz	x2, 4c04 <fwp_mem_free+0x194>
    4be0:	911742a1 	add	x1, x21, #0x5d0
    4be4:	8b160040 	add	x0, x2, x22
    4be8:	8b000800 	add	x0, x0, x0, lsl #2
    4bec:	f949fc21 	ldr	x1, [x1, #5112]
    4bf0:	8b140034 	add	x20, x1, x20
    4bf4:	8b000c20 	add	x0, x1, x0, lsl #3
    4bf8:	3802869f 	strb	wzr, [x20], #40
    4bfc:	eb00029f 	cmp	x20, x0
    4c00:	54ffffc1 	b.ne	4bf8 <fwp_mem_free+0x188>  // b.any
    4c04:	911742a0 	add	x0, x21, #0x5d0
    4c08:	f94a1801 	ldr	x1, [x0, #5168]
    4c0c:	f949f803 	ldr	x3, [x0, #5104]
    4c10:	8b020021 	add	x1, x1, x2
    4c14:	f90a1801 	str	x1, [x0, #5168]
    4c18:	eb16007f 	cmp	x3, x22
    4c1c:	54000049 	b.ls	4c24 <fwp_mem_free+0x1b4>  // b.plast
    4c20:	f909f816 	str	x22, [x0, #5104]
    4c24:	911742b5 	add	x21, x21, #0x5d0
    4c28:	f949f6a0 	ldr	x0, [x21, #5096]
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54fff529 	b.ls	4ad4 <fwp_mem_free+0x64>  // b.plast
    4c34:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c38:	f909f6b6 	str	x22, [x21, #5096]
    4c3c:	17ffffa7 	b	4ad8 <fwp_mem_free+0x68>
    4c40:	aa1303e0 	mov	x0, x19
    4c44:	97fffeeb 	bl	47f0 <fwp_rc_forget_slot>
    4c48:	17ffffe3 	b	4bd4 <fwp_mem_free+0x164>
    4c4c:	97fffee9 	bl	47f0 <fwp_rc_forget_slot>
    4c50:	17ffffb4 	b	4b20 <fwp_mem_free+0xb0>

0000000000004c54 <fwp_heap_alloc_big>:
    4c54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c58:	910003fd 	mov	x29, sp
    4c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c60:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c64:	a90363f7 	stp	x23, x24, [sp, #48]
    4c68:	aa0003f7 	mov	x23, x0
    4c6c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c70:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c74:	eb0002ff 	cmp	x23, x0
    4c78:	54000888 	b.hi	4d88 <fwp_heap_alloc_big+0x134>  // b.pmore
    4c7c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c80:	8b0002f4 	add	x20, x23, x0
    4c84:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c88:	91174359 	add	x25, x26, #0x5d0
    4c8c:	d350fe94 	lsr	x20, x20, #16
    4c90:	2a0103f5 	mov	w21, w1
    4c94:	aa1403e0 	mov	x0, x20
    4c98:	97fff986 	bl	32b0 <fwp_heap_chunks>
    4c9c:	f949ff22 	ldr	x2, [x25, #5112]
    4ca0:	8b000813 	add	x19, x0, x0, lsl #2
    4ca4:	aa0003f8 	mov	x24, x0
    4ca8:	52800043 	mov	w3, #0x2                   	// #2
    4cac:	d37df273 	lsl	x19, x19, #3
    4cb0:	d2800021 	mov	x1, #0x1                   	// #1
    4cb4:	8b130040 	add	x0, x2, x19
    4cb8:	38336843 	strb	w3, [x2, x19]
    4cbc:	39000415 	strb	w21, [x0, #1]
    4cc0:	b9000c14 	str	w20, [x0, #12]
    4cc4:	f9000817 	str	x23, [x0, #16]
    4cc8:	97fffef2 	bl	4890 <fwp_rc_prepare_chunk>
    4ccc:	f100069f 	cmp	x20, #0x1
    4cd0:	54000269 	b.ls	4d1c <fwp_heap_alloc_big+0xc8>  // b.plast
    4cd4:	8b180294 	add	x20, x20, x24
    4cd8:	9100a273 	add	x19, x19, #0x28
    4cdc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ce0:	5280007b 	mov	w27, #0x3                   	// #3
    4ce4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce8:	2a1803fc 	mov	w28, w24
    4cec:	9adb2296 	lsl	x22, x20, x27
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffee4 	bl	4890 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0x9c>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x104>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffca4 	bl	4104 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff70 	b	4c54 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffeb5 	bl	49b0 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94046e0 	ldr	x0, [x23, #136]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_p_ad_push>:
    5224:	f100001f 	cmp	x0, #0x0
    5228:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    522c:	5400118b 	b.lt	545c <fwp_p_ad_push+0x238>  // b.tstop
    5230:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5234:	910003fd 	mov	x29, sp
    5238:	a90153f3 	stp	x19, x20, [sp, #16]
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	aa0403f6 	mov	x22, x4
    5244:	aa0003f5 	mov	x21, x0
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	aa0203f8 	mov	x24, x2
    5250:	6d0627e8 	stp	d8, d9, [sp, #96]
    5254:	9e670029 	fmov	d9, x1
    5258:	9e670068 	fmov	d8, x3
    525c:	aa020001 	orr	x1, x0, x2
    5260:	b6f80dc1 	tbz	x1, #63, 5418 <fwp_p_ad_push+0x1f4>
    5264:	9360fc14 	asr	x20, x0, #32
    5268:	b6f800c0 	tbz	x0, #63, 5280 <fwp_p_ad_push+0x5c>
    526c:	1e604109 	fmov	d9, d8
    5270:	2f00e408 	movi	d8, #0x0
    5274:	9360fc54 	asr	x20, x2, #32
    5278:	aa0203f5 	mov	x21, x2
    527c:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5280:	b4001136 	cbz	x22, 54a4 <fwp_p_ad_push+0x280>
    5284:	f94002c0 	ldr	x0, [x22]
    5288:	eb14001f 	cmp	x0, x20
    528c:	54000e40 	b.eq	5454 <fwp_p_ad_push+0x230>  // b.none
    5290:	aa1403e0 	mov	x0, x20
    5294:	97fffa27 	bl	3b30 <fwp_tape_of>
    5298:	aa0003f3 	mov	x19, x0
    529c:	f9403000 	ldr	x0, [x0, #96]
    52a0:	b50010c0 	cbnz	x0, 54b8 <fwp_p_ad_push+0x294>
    52a4:	a9004ed4 	stp	x20, x19, [x22]
    52a8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    52ac:	f9400a77 	ldr	x23, [x19, #16]
    52b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b4:	eb0002ff 	cmp	x23, x0
    52b8:	540013ec 	b.gt	5534 <fwp_p_ad_push+0x310>
    52bc:	eb3542ff 	cmp	x23, w21, uxtw
    52c0:	5400132d 	b.le	5524 <fwp_p_ad_push+0x300>
    52c4:	b7f80078 	tbnz	x24, #63, 52d0 <fwp_p_ad_push+0xac>
    52c8:	eb3842ff 	cmp	x23, w24, uxtw
    52cc:	540012cd 	b.le	5524 <fwp_p_ad_push+0x300>
    52d0:	f9400676 	ldr	x22, [x19, #8]
    52d4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52d8:	cb1602f6 	sub	x22, x23, x22
    52dc:	910006c1 	add	x1, x22, #0x1
    52e0:	aa1603f9 	mov	x25, x22
    52e4:	eb00003f 	cmp	x1, x0
    52e8:	54001268 	b.hi	5534 <fwp_p_ad_push+0x310>  // b.pmore
    52ec:	a9418274 	ldp	x20, x0, [x19, #24]
    52f0:	eb14003f 	cmp	x1, x20
    52f4:	54000a6d 	b.le	5440 <fwp_p_ad_push+0x21c>
    52f8:	f100029f 	cmp	x20, #0x0
    52fc:	d2800803 	mov	x3, #0x40                  	// #64
    5300:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5304:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5308:	a90573fb 	stp	x27, x28, [sp, #80]
    530c:	eb14003f 	cmp	x1, x20
    5310:	5400008d 	b.le	5320 <fwp_p_ad_push+0xfc>
    5314:	eb02029f 	cmp	x20, x2
    5318:	5400090d 	b.le	5438 <fwp_p_ad_push+0x214>
    531c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5320:	d37df29a 	lsl	x26, x20, #3
    5324:	f940327b 	ldr	x27, [x19, #96]
    5328:	aa1a03e1 	mov	x1, x26
    532c:	97fff551 	bl	2870 <realloc@plt>
    5330:	b40010a0 	cbz	x0, 5544 <fwp_p_ad_push+0x320>
    5334:	f9400e61 	ldr	x1, [x19, #24]
    5338:	8b010801 	add	x1, x0, x1, lsl #2
    533c:	a9020660 	stp	x0, x1, [x19, #32]
    5340:	b400093b 	cbz	x27, 5464 <fwp_p_ad_push+0x240>
    5344:	f9403363 	ldr	x3, [x27, #96]
    5348:	f9003be3 	str	x3, [sp, #112]
    534c:	eb03029f 	cmp	x20, x3
    5350:	5400034d 	b.le	53b8 <fwp_p_ad_push+0x194>
    5354:	f940237c 	ldr	x28, [x27, #64]
    5358:	d37cee82 	lsl	x2, x20, #4
    535c:	aa0203e0 	mov	x0, x2
    5360:	52800041 	mov	w1, #0x2                   	// #2
    5364:	f9003fe2 	str	x2, [sp, #120]
    5368:	97fffee2 	bl	4ef0 <fwp_heap_alloc>
    536c:	aa0003fa 	mov	x26, x0
    5370:	b400013c 	cbz	x28, 5394 <fwp_p_ad_push+0x170>
    5374:	a9470be3 	ldp	x3, x2, [sp, #112]
    5378:	aa1c03e1 	mov	x1, x28
    537c:	d37cec63 	lsl	x3, x3, #4
    5380:	eb02007f 	cmp	x3, x2
    5384:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5388:	97fff4d2 	bl	26d0 <memcpy@plt>
    538c:	aa1c03e0 	mov	x0, x28
    5390:	97fffdb8 	bl	4a70 <fwp_mem_free>
    5394:	f9403360 	ldr	x0, [x27, #96]
    5398:	52800001 	mov	w1, #0x0                   	// #0
    539c:	cb000282 	sub	x2, x20, x0
    53a0:	8b001340 	add	x0, x26, x0, lsl #4
    53a4:	d37cec42 	lsl	x2, x2, #4
    53a8:	97fff52a 	bl	2850 <memset@plt>
    53ac:	f9401260 	ldr	x0, [x19, #32]
    53b0:	f900237a 	str	x26, [x27, #64]
    53b4:	f9003374 	str	x20, [x27, #96]
    53b8:	b50008b6 	cbnz	x22, 54cc <fwp_p_ad_push+0x2a8>
    53bc:	a9431263 	ldp	x3, x4, [x19, #48]
    53c0:	d37ef69a 	lsl	x26, x20, #2
    53c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    53c8:	8b1a0002 	add	x2, x0, x26
    53cc:	f9000e74 	str	x20, [x19, #24]
    53d0:	f9001662 	str	x2, [x19, #40]
    53d4:	b8366815 	str	w21, [x0, x22]
    53d8:	f100031f 	cmp	x24, #0x0
    53dc:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    53e0:	92607eb5 	and	x21, x21, #0xffffffff00000000
    53e4:	fc396869 	str	d9, [x3, x25]
    53e8:	aa1702a0 	orr	x0, x21, x23
    53ec:	b8366841 	str	w1, [x2, x22]
    53f0:	910006e1 	add	x1, x23, #0x1
    53f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f8:	fc396888 	str	d8, [x4, x25]
    53fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    5400:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5404:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5408:	f9000a61 	str	x1, [x19, #16]
    540c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5410:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5414:	d65f03c0 	ret
    5418:	9360fc54 	asr	x20, x2, #32
    541c:	eb80829f 	cmp	x20, x0, asr #32
    5420:	54fff300 	b.eq	5280 <fwp_p_ad_push+0x5c>  // b.none
    5424:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5428:	91272000 	add	x0, x0, #0x9c8
    542c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5430:	a90573fb 	stp	x27, x28, [sp, #80]
    5434:	97fff8f3 	bl	3800 <fwp_trap>
    5438:	d37ffa94 	lsl	x20, x20, #1
    543c:	17ffffb4 	b	530c <fwp_p_ad_push+0xe8>
    5440:	a9428e62 	ldp	x2, x3, [x19, #40]
    5444:	d37ef6d6 	lsl	x22, x22, #2
    5448:	f9401e64 	ldr	x4, [x19, #56]
    544c:	d37df339 	lsl	x25, x25, #3
    5450:	17ffffe1 	b	53d4 <fwp_p_ad_push+0x1b0>
    5454:	f94006d3 	ldr	x19, [x22, #8]
    5458:	17ffff94 	b	52a8 <fwp_p_ad_push+0x84>
    545c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5460:	d65f03c0 	ret
    5464:	f9401a60 	ldr	x0, [x19, #48]
    5468:	d37cee9b 	lsl	x27, x20, #4
    546c:	aa1b03e1 	mov	x1, x27
    5470:	97fff500 	bl	2870 <realloc@plt>
    5474:	aa0003e3 	mov	x3, x0
    5478:	b4000660 	cbz	x0, 5544 <fwp_p_ad_push+0x320>
    547c:	8b1a0004 	add	x4, x0, x26
    5480:	f9400e60 	ldr	x0, [x19, #24]
    5484:	8b000c61 	add	x1, x3, x0, lsl #3
    5488:	a9030663 	stp	x3, x1, [x19, #48]
    548c:	b5000356 	cbnz	x22, 54f4 <fwp_p_ad_push+0x2d0>
    5490:	f9401260 	ldr	x0, [x19, #32]
    5494:	d37ef69a 	lsl	x26, x20, #2
    5498:	d2800016 	mov	x22, #0x0                   	// #0
    549c:	f9001e64 	str	x4, [x19, #56]
    54a0:	17ffffc9 	b	53c4 <fwp_p_ad_push+0x1a0>
    54a4:	aa1403e0 	mov	x0, x20
    54a8:	97fff9a2 	bl	3b30 <fwp_tape_of>
    54ac:	aa0003f3 	mov	x19, x0
    54b0:	f9403000 	ldr	x0, [x0, #96]
    54b4:	b4ffefa0 	cbz	x0, 52a8 <fwp_p_ad_push+0x84>
    54b8:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    54bc:	91284000 	add	x0, x0, #0xa10
    54c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    54c4:	a90573fb 	stp	x27, x28, [sp, #80]
    54c8:	97fff8ce 	bl	3800 <fwp_trap>
    54cc:	d37df2d9 	lsl	x25, x22, #3
    54d0:	f9401661 	ldr	x1, [x19, #40]
    54d4:	d37ef6d6 	lsl	x22, x22, #2
    54d8:	d37ef69a 	lsl	x26, x20, #2
    54dc:	aa1603e2 	mov	x2, x22
    54e0:	8b1a0000 	add	x0, x0, x26
    54e4:	97fff483 	bl	26f0 <memmove@plt>
    54e8:	f9401260 	ldr	x0, [x19, #32]
    54ec:	a9431263 	ldp	x3, x4, [x19, #48]
    54f0:	17ffffb5 	b	53c4 <fwp_p_ad_push+0x1a0>
    54f4:	eb1b035f 	cmp	x26, x27
    54f8:	d37df2d9 	lsl	x25, x22, #3
    54fc:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5500:	aa0403e0 	mov	x0, x4
    5504:	cb1a0063 	sub	x3, x3, x26
    5508:	aa1903e2 	mov	x2, x25
    550c:	97fff545 	bl	2a20 <__memmove_chk@plt>
    5510:	f9401a61 	ldr	x1, [x19, #48]
    5514:	f9401260 	ldr	x0, [x19, #32]
    5518:	8b1a0021 	add	x1, x1, x26
    551c:	f9001e61 	str	x1, [x19, #56]
    5520:	17ffffec 	b	54d0 <fwp_p_ad_push+0x2ac>
    5524:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5528:	91298000 	add	x0, x0, #0xa60
    552c:	a90573fb 	stp	x27, x28, [sp, #80]
    5530:	97fff8b4 	bl	3800 <fwp_trap>
    5534:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5538:	91290000 	add	x0, x0, #0xa40
    553c:	a90573fb 	stp	x27, x28, [sp, #80]
    5540:	97fff8b0 	bl	3800 <fwp_trap>
    5544:	aa1303e0 	mov	x0, x19
    5548:	97fff692 	bl	2f90 <fwp_tape_unlink_scope>
    554c:	f9401260 	ldr	x0, [x19, #32]
    5550:	97fff4fc 	bl	2940 <free@plt>
    5554:	f9401a60 	ldr	x0, [x19, #48]
    5558:	97fff4fa 	bl	2940 <free@plt>
    555c:	f9402260 	ldr	x0, [x19, #64]
    5560:	97fff4f8 	bl	2940 <free@plt>
    5564:	f9000e7f 	str	xzr, [x19, #24]
    5568:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    556c:	f947e821 	ldr	x1, [x1, #4048]
    5570:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5574:	d2800262 	mov	x2, #0x13                  	// #19
    5578:	4f000400 	movi	v0.4s, #0x0
    557c:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5580:	f9400023 	ldr	x3, [x1]
    5584:	b900067f 	str	wzr, [x19, #4]
    5588:	d2800021 	mov	x1, #0x1                   	// #1
    558c:	9118a000 	add	x0, x0, #0x628
    5590:	3c808260 	stur	q0, [x19, #8]
    5594:	ad010260 	stp	q0, q0, [x19, #32]
    5598:	97fff4fa 	bl	2980 <fwrite@plt>
    559c:	d2800000 	mov	x0, #0x0                   	// #0
    55a0:	97fff504 	bl	29b0 <fflush@plt>
    55a4:	52800cc0 	mov	w0, #0x66                  	// #102
    55a8:	97fff512 	bl	29f0 <_Exit@plt>
    55ac:	d503201f 	nop

00000000000055b0 <w107>:
    55b0:	d10203ff 	sub	sp, sp, #0x80
    55b4:	9e660003 	fmov	x3, d0
    55b8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    55bc:	f947f442 	ldr	x2, [x2, #4072]
    55c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    55c4:	910083fd 	add	x29, sp, #0x20
    55c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    55cc:	1e604009 	fmov	d9, d0
    55d0:	1e604028 	fmov	d8, d1
    55d4:	fd003bea 	str	d10, [sp, #112]
    55d8:	1e60080a 	fmul	d10, d0, d0
    55dc:	a90353f3 	stp	x19, x20, [sp, #48]
    55e0:	910023f3 	add	x19, sp, #0x8
    55e4:	aa0003f4 	mov	x20, x0
    55e8:	a9045bf5 	stp	x21, x22, [sp, #64]
    55ec:	aa0103f6 	mov	x22, x1
    55f0:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    55f4:	a90563f7 	stp	x23, x24, [sp, #80]
    55f8:	aa0303e1 	mov	x1, x3
    55fc:	f9400044 	ldr	x4, [x2]
    5600:	f9000fe4 	str	x4, [sp, #24]
    5604:	d2800004 	mov	x4, #0x0                   	// #0
    5608:	aa0003e2 	mov	x2, x0
    560c:	aa1303e4 	mov	x4, x19
    5610:	a900fff5 	stp	x21, xzr, [sp, #8]
    5614:	97ffff04 	bl	5224 <fwp_p_ad_push>
    5618:	1e6a3908 	fsub	d8, d8, d10
    561c:	aa1603e2 	mov	x2, x22
    5620:	aa1303e4 	mov	x4, x19
    5624:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5628:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    562c:	9e660118 	fmov	x24, d8
    5630:	97fffefd 	bl	5224 <fwp_p_ad_push>
    5634:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5638:	aa0003f6 	mov	x22, x0
    563c:	aa1303e4 	mov	x4, x19
    5640:	aa1403e0 	mov	x0, x20
    5644:	1e69394a 	fsub	d10, d10, d9
    5648:	aa1503e2 	mov	x2, x21
    564c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5650:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5654:	9e660157 	fmov	x23, d10
    5658:	97fffef3 	bl	5224 <fwp_p_ad_push>
    565c:	1e680908 	fmul	d8, d8, d8
    5660:	aa0003f4 	mov	x20, x0
    5664:	aa1303e4 	mov	x4, x19
    5668:	aa1803e3 	mov	x3, x24
    566c:	aa1803e1 	mov	x1, x24
    5670:	aa1603e2 	mov	x2, x22
    5674:	aa1603e0 	mov	x0, x22
    5678:	97fffeeb 	bl	5224 <fwp_p_ad_push>
    567c:	aa0003e2 	mov	x2, x0
    5680:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5684:	9e670029 	fmov	d9, x1
    5688:	9e660101 	fmov	x1, d8
    568c:	aa1303e4 	mov	x4, x19
    5690:	1e690909 	fmul	d9, d8, d9
    5694:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5698:	aa1503e0 	mov	x0, x21
    569c:	97fffee2 	bl	5224 <fwp_p_ad_push>
    56a0:	1e6a094a 	fmul	d10, d10, d10
    56a4:	aa1303e4 	mov	x4, x19
    56a8:	aa1703e3 	mov	x3, x23
    56ac:	aa0003f3 	mov	x19, x0
    56b0:	aa1703e1 	mov	x1, x23
    56b4:	aa1403e2 	mov	x2, x20
    56b8:	aa1403e0 	mov	x0, x20
    56bc:	97fffeda 	bl	5224 <fwp_p_ad_push>
    56c0:	1e6a2929 	fadd	d9, d9, d10
    56c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    56c8:	d2800004 	mov	x4, #0x0                   	// #0
    56cc:	aa0303e1 	mov	x1, x3
    56d0:	aa1303e2 	mov	x2, x19
    56d4:	97fffed4 	bl	5224 <fwp_p_ad_push>
    56d8:	aa0003e1 	mov	x1, x0
    56dc:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    56e0:	f947f463 	ldr	x3, [x3, #4072]
    56e4:	f9400fe0 	ldr	x0, [sp, #24]
    56e8:	f9400064 	ldr	x4, [x3]
    56ec:	eb040000 	subs	x0, x0, x4
    56f0:	d2800004 	mov	x4, #0x0                   	// #0
    56f4:	54000161 	b.ne	5720 <w107+0x170>  // b.any
    56f8:	9e660122 	fmov	x2, d9
    56fc:	fd403bea 	ldr	d10, [sp, #112]
    5700:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5704:	a94353f3 	ldp	x19, x20, [sp, #48]
    5708:	aa0203e0 	mov	x0, x2
    570c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5710:	a94563f7 	ldp	x23, x24, [sp, #80]
    5714:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5718:	910203ff 	add	sp, sp, #0x80
    571c:	d65f03c0 	ret
    5720:	97fff458 	bl	2880 <__stack_chk_fail@plt>

0000000000005724 <w164.constprop.0>:
    5724:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5728:	910003fd 	mov	x29, sp
    572c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5730:	fd001be8 	str	d8, [sp, #48]
    5734:	f9400015 	ldr	x21, [x0]
    5738:	b4000355 	cbz	x21, 57a0 <w164.constprop.0+0x7c>
    573c:	2f00e408 	movi	d8, #0x0
    5740:	91002016 	add	x22, x0, #0x8
    5744:	a90153f3 	stp	x19, x20, [sp, #16]
    5748:	91004014 	add	x20, x0, #0x10
    574c:	d2800013 	mov	x19, #0x0                   	// #0
    5750:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5754:	d503201f 	nop
    5758:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    575c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5760:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5764:	aa0303e1 	mov	x1, x3
    5768:	1e602908 	fadd	d8, d8, d0
    576c:	d2800004 	mov	x4, #0x0                   	// #0
    5770:	91000a73 	add	x19, x19, #0x2
    5774:	97fffeac 	bl	5224 <fwp_p_ad_push>
    5778:	eb1302bf 	cmp	x21, x19
    577c:	54fffee8 	b.hi	5758 <w164.constprop.0+0x34>  // b.pmore
    5780:	9e660102 	fmov	x2, d8
    5784:	fd401be8 	ldr	d8, [sp, #48]
    5788:	a94153f3 	ldp	x19, x20, [sp, #16]
    578c:	aa0003e1 	mov	x1, x0
    5790:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5794:	aa0203e0 	mov	x0, x2
    5798:	a8c47bfd 	ldp	x29, x30, [sp], #64
    579c:	d65f03c0 	ret
    57a0:	2f00e408 	movi	d8, #0x0
    57a4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57ac:	aa0003e1 	mov	x1, x0
    57b0:	9e660102 	fmov	x2, d8
    57b4:	fd401be8 	ldr	d8, [sp, #48]
    57b8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57bc:	aa0203e0 	mov	x0, x2
    57c0:	d65f03c0 	ret

00000000000057c4 <fwp_data.part.0.constprop.0>:
    57c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    57c8:	910003fd 	mov	x29, sp
    57cc:	a90153f3 	stp	x19, x20, [sp, #16]
    57d0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    57d4:	91174283 	add	x3, x20, #0x5d0
    57d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    57dc:	aa0103f5 	mov	x21, x1
    57e0:	b953a461 	ldr	w1, [x3, #5028]
    57e4:	a90363f7 	stp	x23, x24, [sp, #48]
    57e8:	2a0003f8 	mov	w24, w0
    57ec:	34000701 	cbz	w1, 58cc <fwp_data.part.0.constprop.0+0x108>
    57f0:	397e8862 	ldrb	w2, [x3, #4002]
    57f4:	910f0040 	add	x0, x2, #0x3c0
    57f8:	8b020442 	add	x2, x2, x2, lsl #1
    57fc:	d37df042 	lsl	x2, x2, #3
    5800:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5804:	2a1703f6 	mov	w22, w23
    5808:	f8626873 	ldr	x19, [x3, x2]
    580c:	b40004d3 	cbz	x19, 58a4 <fwp_data.part.0.constprop.0+0xe0>
    5810:	f9400260 	ldr	x0, [x19]
    5814:	aa2003e0 	mvn	x0, x0
    5818:	f8226860 	str	x0, [x3, x2]
    581c:	f10062df 	cmp	x22, #0x18
    5820:	540000e9 	b.ls	583c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5824:	d10066c2 	sub	x2, x22, #0x19
    5828:	91006260 	add	x0, x19, #0x18
    582c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5830:	52800001 	mov	w1, #0x0                   	// #0
    5834:	91002042 	add	x2, x2, #0x8
    5838:	97fff406 	bl	2850 <memset@plt>
    583c:	91174282 	add	x2, x20, #0x5d0
    5840:	f94a1041 	ldr	x1, [x2, #5152]
    5844:	ab160021 	adds	x1, x1, x22
    5848:	540004c2 	b.cs	58e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    584c:	f94a1440 	ldr	x0, [x2, #5160]
    5850:	f90a1041 	str	x1, [x2, #5152]
    5854:	eb00003f 	cmp	x1, x0
    5858:	54000049 	b.ls	5860 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    585c:	f90a1441 	str	x1, [x2, #5160]
    5860:	91174294 	add	x20, x20, #0x5d0
    5864:	1e6302e1 	ucvtf	d1, w23
    5868:	fd4a1e80 	ldr	d0, [x20, #5176]
    586c:	1e612800 	fadd	d0, d0, d1
    5870:	fd0a1e80 	str	d0, [x20, #5176]
    5874:	52800041 	mov	w1, #0x2                   	// #2
    5878:	29000678 	stp	w24, w1, [x19]
    587c:	aa1303e0 	mov	x0, x19
    5880:	f94002a1 	ldr	x1, [x21]
    5884:	f9000661 	str	x1, [x19, #8]
    5888:	f94006a1 	ldr	x1, [x21, #8]
    588c:	f9000a61 	str	x1, [x19, #16]
    5890:	a94153f3 	ldp	x19, x20, [sp, #16]
    5894:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5898:	a94363f7 	ldp	x23, x24, [sp, #48]
    589c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    58a0:	d65f03c0 	ret
    58a4:	8b020063 	add	x3, x3, x2
    58a8:	f9400473 	ldr	x19, [x3, #8]
    58ac:	b4000113 	cbz	x19, 58cc <fwp_data.part.0.constprop.0+0x108>
    58b0:	f9400860 	ldr	x0, [x3, #16]
    58b4:	cb130000 	sub	x0, x0, x19
    58b8:	eb0002df 	cmp	x22, x0
    58bc:	54000088 	b.hi	58cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    58c0:	8b160260 	add	x0, x19, x22
    58c4:	f9000460 	str	x0, [x3, #8]
    58c8:	17ffffd5 	b	581c <fwp_data.part.0.constprop.0+0x58>
    58cc:	52800001 	mov	w1, #0x0                   	// #0
    58d0:	d2800300 	mov	x0, #0x18                  	// #24
    58d4:	97fffd87 	bl	4ef0 <fwp_heap_alloc>
    58d8:	aa0003f3 	mov	x19, x0
    58dc:	17ffffe6 	b	5874 <fwp_data.part.0.constprop.0+0xb0>
    58e0:	97fff5d4 	bl	3030 <fwp_heap_oom>

00000000000058e4 <fwp_rc_share>:
    58e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    58e8:	91174042 	add	x2, x2, #0x5d0
    58ec:	f949d843 	ldr	x3, [x2, #5040]
    58f0:	f949ec41 	ldr	x1, [x2, #5080]
    58f4:	cb030000 	sub	x0, x0, x3
    58f8:	eb01401f 	cmp	x0, x1, lsl #16
    58fc:	540002c2 	b.cs	5954 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5900:	d350fc01 	lsr	x1, x0, #16
    5904:	f949fc44 	ldr	x4, [x2, #5112]
    5908:	8b010821 	add	x1, x1, x1, lsl #2
    590c:	d37df021 	lsl	x1, x1, #3
    5910:	8b010083 	add	x3, x4, x1
    5914:	f9401062 	ldr	x2, [x3, #32]
    5918:	b40001e2 	cbz	x2, 5954 <fwp_rc_share+0x70>
    591c:	38616881 	ldrb	w1, [x4, x1]
    5920:	7100083f 	cmp	w1, #0x2
    5924:	540001a0 	b.eq	5958 <fwp_rc_share+0x74>  // b.none
    5928:	7100043f 	cmp	w1, #0x1
    592c:	54000141 	b.ne	5954 <fwp_rc_share+0x70>  // b.any
    5930:	29430464 	ldp	w4, w1, [x3, #24]
    5934:	92403c00 	and	x0, x0, #0xffff
    5938:	9b047c00 	mul	x0, x0, x4
    593c:	d360fc00 	lsr	x0, x0, #32
    5940:	eb01001f 	cmp	x0, x1
    5944:	54000082 	b.cs	5954 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5948:	8b000042 	add	x2, x2, x0
    594c:	39400040 	ldrb	w0, [x2]
    5950:	350000a0 	cbnz	w0, 5964 <fwp_rc_share+0x80>
    5954:	d65f03c0 	ret
    5958:	72003c1f 	tst	w0, #0xffff
    595c:	54ffff80 	b.eq	594c <fwp_rc_share+0x68>  // b.none
    5960:	d65f03c0 	ret
    5964:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5968:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    596c:	912a0000 	add	x0, x0, #0xa80
    5970:	910003fd 	mov	x29, sp
    5974:	97fff7a3 	bl	3800 <fwp_trap>
    5978:	d503201f 	nop
    597c:	d503201f 	nop

0000000000005980 <fwp_rc_free_arr>:
    5980:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5984:	91174063 	add	x3, x3, #0x5d0
    5988:	f949d861 	ldr	x1, [x3, #5040]
    598c:	f949ec62 	ldr	x2, [x3, #5080]
    5990:	cb010001 	sub	x1, x0, x1
    5994:	eb02403f 	cmp	x1, x2, lsl #16
    5998:	54000342 	b.cs	5a00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    599c:	d350fc22 	lsr	x2, x1, #16
    59a0:	f949fc65 	ldr	x5, [x3, #5112]
    59a4:	8b020842 	add	x2, x2, x2, lsl #2
    59a8:	d37df042 	lsl	x2, x2, #3
    59ac:	8b0200a4 	add	x4, x5, x2
    59b0:	f9401083 	ldr	x3, [x4, #32]
    59b4:	b4000263 	cbz	x3, 5a00 <fwp_rc_free_arr+0x80>
    59b8:	386268a2 	ldrb	w2, [x5, x2]
    59bc:	7100085f 	cmp	w2, #0x2
    59c0:	540001c0 	b.eq	59f8 <fwp_rc_free_arr+0x78>  // b.none
    59c4:	7100045f 	cmp	w2, #0x1
    59c8:	540001c1 	b.ne	5a00 <fwp_rc_free_arr+0x80>  // b.any
    59cc:	29430885 	ldp	w5, w2, [x4, #24]
    59d0:	92403c21 	and	x1, x1, #0xffff
    59d4:	9b057c21 	mul	x1, x1, x5
    59d8:	d360fc21 	lsr	x1, x1, #32
    59dc:	eb02003f 	cmp	x1, x2
    59e0:	54000102 	b.cs	5a00 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    59e4:	8b010063 	add	x3, x3, x1
    59e8:	39400061 	ldrb	w1, [x3]
    59ec:	7100043f 	cmp	w1, #0x1
    59f0:	54000081 	b.ne	5a00 <fwp_rc_free_arr+0x80>  // b.any
    59f4:	17fffc1f 	b	4a70 <fwp_mem_free>
    59f8:	72003c3f 	tst	w1, #0xffff
    59fc:	54ffff60 	b.eq	59e8 <fwp_rc_free_arr+0x68>  // b.none
    5a00:	d65f03c0 	ret

0000000000005a04 <fwp_rc_dup>:
    5a04:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5a08:	91174042 	add	x2, x2, #0x5d0
    5a0c:	f949d841 	ldr	x1, [x2, #5040]
    5a10:	f949ec43 	ldr	x3, [x2, #5080]
    5a14:	cb010001 	sub	x1, x0, x1
    5a18:	eb03403f 	cmp	x1, x3, lsl #16
    5a1c:	54000342 	b.cs	5a84 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a20:	d350fc20 	lsr	x0, x1, #16
    5a24:	f949fc44 	ldr	x4, [x2, #5112]
    5a28:	8b000800 	add	x0, x0, x0, lsl #2
    5a2c:	d37df002 	lsl	x2, x0, #3
    5a30:	8b020083 	add	x3, x4, x2
    5a34:	f9401060 	ldr	x0, [x3, #32]
    5a38:	b4000260 	cbz	x0, 5a84 <fwp_rc_dup+0x80>
    5a3c:	38626882 	ldrb	w2, [x4, x2]
    5a40:	7100085f 	cmp	w2, #0x2
    5a44:	54000220 	b.eq	5a88 <fwp_rc_dup+0x84>  // b.none
    5a48:	7100045f 	cmp	w2, #0x1
    5a4c:	540001c1 	b.ne	5a84 <fwp_rc_dup+0x80>  // b.any
    5a50:	29430864 	ldp	w4, w2, [x3, #24]
    5a54:	92403c21 	and	x1, x1, #0xffff
    5a58:	9b047c21 	mul	x1, x1, x4
    5a5c:	d360fc21 	lsr	x1, x1, #32
    5a60:	eb02003f 	cmp	x1, x2
    5a64:	54000102 	b.cs	5a84 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5a68:	8b010000 	add	x0, x0, x1
    5a6c:	39400001 	ldrb	w1, [x0]
    5a70:	340000a1 	cbz	w1, 5a84 <fwp_rc_dup+0x80>
    5a74:	7103f43f 	cmp	w1, #0xfd
    5a78:	540000e8 	b.hi	5a94 <fwp_rc_dup+0x90>  // b.pmore
    5a7c:	11000421 	add	w1, w1, #0x1
    5a80:	39000001 	strb	w1, [x0]
    5a84:	d65f03c0 	ret
    5a88:	72003c3f 	tst	w1, #0xffff
    5a8c:	54ffff00 	b.eq	5a6c <fwp_rc_dup+0x68>  // b.none
    5a90:	d65f03c0 	ret
    5a94:	17fffb10 	b	46d4 <fwp_rc_wide_dup>
    5a98:	d503201f 	nop
    5a9c:	d503201f 	nop

0000000000005aa0 <fwp_drop0>:
    5aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5aa4:	910003fd 	mov	x29, sp
    5aa8:	a90153f3 	stp	x19, x20, [sp, #16]
    5aac:	f90013f5 	str	x21, [sp, #32]
    5ab0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5ab4:	911742b4 	add	x20, x21, #0x5d0
    5ab8:	f949da81 	ldr	x1, [x20, #5040]
    5abc:	f949ee82 	ldr	x2, [x20, #5080]
    5ac0:	cb010001 	sub	x1, x0, x1
    5ac4:	eb02403f 	cmp	x1, x2, lsl #16
    5ac8:	54000382 	b.cs	5b38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5acc:	d350fc22 	lsr	x2, x1, #16
    5ad0:	f949fe84 	ldr	x4, [x20, #5112]
    5ad4:	8b020842 	add	x2, x2, x2, lsl #2
    5ad8:	d37df042 	lsl	x2, x2, #3
    5adc:	8b020083 	add	x3, x4, x2
    5ae0:	f9401073 	ldr	x19, [x3, #32]
    5ae4:	b40002b3 	cbz	x19, 5b38 <fwp_drop0+0x98>
    5ae8:	38626882 	ldrb	w2, [x4, x2]
    5aec:	7100085f 	cmp	w2, #0x2
    5af0:	540002c0 	b.eq	5b48 <fwp_drop0+0xa8>  // b.none
    5af4:	7100045f 	cmp	w2, #0x1
    5af8:	54000201 	b.ne	5b38 <fwp_drop0+0x98>  // b.any
    5afc:	29430864 	ldp	w4, w2, [x3, #24]
    5b00:	92403c21 	and	x1, x1, #0xffff
    5b04:	9b047c21 	mul	x1, x1, x4
    5b08:	d360fc21 	lsr	x1, x1, #32
    5b0c:	eb02003f 	cmp	x1, x2
    5b10:	54000142 	b.cs	5b38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b14:	8b010273 	add	x19, x19, x1
    5b18:	39400261 	ldrb	w1, [x19]
    5b1c:	340000e1 	cbz	w1, 5b38 <fwp_drop0+0x98>
    5b20:	7100043f 	cmp	w1, #0x1
    5b24:	540001e0 	b.eq	5b60 <fwp_drop0+0xc0>  // b.none
    5b28:	7103fc3f 	cmp	w1, #0xff
    5b2c:	540002e0 	b.eq	5b88 <fwp_drop0+0xe8>  // b.none
    5b30:	51000421 	sub	w1, w1, #0x1
    5b34:	39000261 	strb	w1, [x19]
    5b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b3c:	f94013f5 	ldr	x21, [sp, #32]
    5b40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b44:	d65f03c0 	ret
    5b48:	72003c3f 	tst	w1, #0xffff
    5b4c:	54fffe60 	b.eq	5b18 <fwp_drop0+0x78>  // b.none
    5b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b54:	f94013f5 	ldr	x21, [sp, #32]
    5b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b5c:	d65f03c0 	ret
    5b60:	f9400813 	ldr	x19, [x0, #16]
    5b64:	97ffff87 	bl	5980 <fwp_rc_free_arr>
    5b68:	911742a0 	add	x0, x21, #0x5d0
    5b6c:	f949d801 	ldr	x1, [x0, #5040]
    5b70:	f949ec00 	ldr	x0, [x0, #5080]
    5b74:	cb010261 	sub	x1, x19, x1
    5b78:	eb00403f 	cmp	x1, x0, lsl #16
    5b7c:	54fffde2 	b.cs	5b38 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b80:	aa1303e0 	mov	x0, x19
    5b84:	17ffffd2 	b	5acc <fwp_drop0+0x2c>
    5b88:	ca534660 	eor	x0, x19, x19, lsr #17
    5b8c:	911742b5 	add	x21, x21, #0x5d0
    5b90:	ca402400 	eor	x0, x0, x0, lsr #9
    5b94:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b98:	f94a2400 	ldr	x0, [x0, #5192]
    5b9c:	b5000080 	cbnz	x0, 5bac <fwp_drop0+0x10c>
    5ba0:	14000010 	b	5be0 <fwp_drop0+0x140>
    5ba4:	f9400800 	ldr	x0, [x0, #16]
    5ba8:	b40001c0 	cbz	x0, 5be0 <fwp_drop0+0x140>
    5bac:	f9400001 	ldr	x1, [x0]
    5bb0:	eb13003f 	cmp	x1, x19
    5bb4:	54ffff81 	b.ne	5ba4 <fwp_drop0+0x104>  // b.any
    5bb8:	f9400401 	ldr	x1, [x0, #8]
    5bbc:	d1000421 	sub	x1, x1, #0x1
    5bc0:	f9000401 	str	x1, [x0, #8]
    5bc4:	f103f83f 	cmp	x1, #0xfe
    5bc8:	54fffb81 	b.ne	5b38 <fwp_drop0+0x98>  // b.any
    5bcc:	aa1303e0 	mov	x0, x19
    5bd0:	97fffb08 	bl	47f0 <fwp_rc_forget_slot>
    5bd4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bd8:	39000260 	strb	w0, [x19]
    5bdc:	17ffffd7 	b	5b38 <fwp_drop0+0x98>
    5be0:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5be4:	91260000 	add	x0, x0, #0x980
    5be8:	97fff706 	bl	3800 <fwp_trap>
    5bec:	d503201f 	nop

0000000000005bf0 <fwp_arg_drop12>:
    5bf0:	7100003f 	cmp	w1, #0x0
    5bf4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5bf8:	54000041 	b.ne	5c00 <fwp_arg_drop12+0x10>  // b.any
    5bfc:	d65f03c0 	ret
    5c00:	f9400000 	ldr	x0, [x0]
    5c04:	17ffffa7 	b	5aa0 <fwp_drop0>
    5c08:	d503201f 	nop
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_drop1>:
    5c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c14:	910003fd 	mov	x29, sp
    5c18:	a90153f3 	stp	x19, x20, [sp, #16]
    5c1c:	f90013f5 	str	x21, [sp, #32]
    5c20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5c24:	911742b4 	add	x20, x21, #0x5d0
    5c28:	f949da81 	ldr	x1, [x20, #5040]
    5c2c:	f949ee82 	ldr	x2, [x20, #5080]
    5c30:	cb010001 	sub	x1, x0, x1
    5c34:	eb02403f 	cmp	x1, x2, lsl #16
    5c38:	54000382 	b.cs	5ca8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c3c:	d350fc22 	lsr	x2, x1, #16
    5c40:	f949fe84 	ldr	x4, [x20, #5112]
    5c44:	8b020842 	add	x2, x2, x2, lsl #2
    5c48:	d37df042 	lsl	x2, x2, #3
    5c4c:	8b020083 	add	x3, x4, x2
    5c50:	f9401073 	ldr	x19, [x3, #32]
    5c54:	b40002b3 	cbz	x19, 5ca8 <fwp_drop1+0x98>
    5c58:	38626882 	ldrb	w2, [x4, x2]
    5c5c:	7100085f 	cmp	w2, #0x2
    5c60:	540002c0 	b.eq	5cb8 <fwp_drop1+0xa8>  // b.none
    5c64:	7100045f 	cmp	w2, #0x1
    5c68:	54000201 	b.ne	5ca8 <fwp_drop1+0x98>  // b.any
    5c6c:	29430864 	ldp	w4, w2, [x3, #24]
    5c70:	92403c21 	and	x1, x1, #0xffff
    5c74:	9b047c21 	mul	x1, x1, x4
    5c78:	d360fc21 	lsr	x1, x1, #32
    5c7c:	eb02003f 	cmp	x1, x2
    5c80:	54000142 	b.cs	5ca8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c84:	8b010273 	add	x19, x19, x1
    5c88:	39400261 	ldrb	w1, [x19]
    5c8c:	340000e1 	cbz	w1, 5ca8 <fwp_drop1+0x98>
    5c90:	7100043f 	cmp	w1, #0x1
    5c94:	540001e0 	b.eq	5cd0 <fwp_drop1+0xc0>  // b.none
    5c98:	7103fc3f 	cmp	w1, #0xff
    5c9c:	540002e0 	b.eq	5cf8 <fwp_drop1+0xe8>  // b.none
    5ca0:	51000421 	sub	w1, w1, #0x1
    5ca4:	39000261 	strb	w1, [x19]
    5ca8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cac:	f94013f5 	ldr	x21, [sp, #32]
    5cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cb4:	d65f03c0 	ret
    5cb8:	72003c3f 	tst	w1, #0xffff
    5cbc:	54fffe60 	b.eq	5c88 <fwp_drop1+0x78>  // b.none
    5cc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cc4:	f94013f5 	ldr	x21, [sp, #32]
    5cc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ccc:	d65f03c0 	ret
    5cd0:	f9400813 	ldr	x19, [x0, #16]
    5cd4:	97ffff2b 	bl	5980 <fwp_rc_free_arr>
    5cd8:	911742a0 	add	x0, x21, #0x5d0
    5cdc:	f949d801 	ldr	x1, [x0, #5040]
    5ce0:	f949ec00 	ldr	x0, [x0, #5080]
    5ce4:	cb010261 	sub	x1, x19, x1
    5ce8:	eb00403f 	cmp	x1, x0, lsl #16
    5cec:	54fffde2 	b.cs	5ca8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cf0:	aa1303e0 	mov	x0, x19
    5cf4:	17ffffd2 	b	5c3c <fwp_drop1+0x2c>
    5cf8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cfc:	911742b5 	add	x21, x21, #0x5d0
    5d00:	ca402400 	eor	x0, x0, x0, lsr #9
    5d04:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5d08:	f94a2400 	ldr	x0, [x0, #5192]
    5d0c:	b5000080 	cbnz	x0, 5d1c <fwp_drop1+0x10c>
    5d10:	14000010 	b	5d50 <fwp_drop1+0x140>
    5d14:	f9400800 	ldr	x0, [x0, #16]
    5d18:	b40001c0 	cbz	x0, 5d50 <fwp_drop1+0x140>
    5d1c:	f9400001 	ldr	x1, [x0]
    5d20:	eb13003f 	cmp	x1, x19
    5d24:	54ffff81 	b.ne	5d14 <fwp_drop1+0x104>  // b.any
    5d28:	f9400401 	ldr	x1, [x0, #8]
    5d2c:	d1000421 	sub	x1, x1, #0x1
    5d30:	f9000401 	str	x1, [x0, #8]
    5d34:	f103f83f 	cmp	x1, #0xfe
    5d38:	54fffb81 	b.ne	5ca8 <fwp_drop1+0x98>  // b.any
    5d3c:	aa1303e0 	mov	x0, x19
    5d40:	97fffaac 	bl	47f0 <fwp_rc_forget_slot>
    5d44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d48:	39000260 	strb	w0, [x19]
    5d4c:	17ffffd7 	b	5ca8 <fwp_drop1+0x98>
    5d50:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5d54:	91260000 	add	x0, x0, #0x980
    5d58:	97fff6aa 	bl	3800 <fwp_trap>
    5d5c:	d503201f 	nop

0000000000005d60 <fwp_closure_drop>:
    5d60:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5d64:	911740a4 	add	x4, x5, #0x5d0
    5d68:	aa0003e1 	mov	x1, x0
    5d6c:	f949d882 	ldr	x2, [x4, #5040]
    5d70:	f949ec80 	ldr	x0, [x4, #5080]
    5d74:	cb020022 	sub	x2, x1, x2
    5d78:	eb00405f 	cmp	x2, x0, lsl #16
    5d7c:	54000662 	b.cs	5e48 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5d80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d84:	d350fc43 	lsr	x3, x2, #16
    5d88:	910003fd 	mov	x29, sp
    5d8c:	8b030863 	add	x3, x3, x3, lsl #2
    5d90:	f949fc84 	ldr	x4, [x4, #5112]
    5d94:	d37df063 	lsl	x3, x3, #3
    5d98:	f9000bf3 	str	x19, [sp, #16]
    5d9c:	8b030080 	add	x0, x4, x3
    5da0:	f9401013 	ldr	x19, [x0, #32]
    5da4:	b40002b3 	cbz	x19, 5df8 <fwp_closure_drop+0x98>
    5da8:	38636883 	ldrb	w3, [x4, x3]
    5dac:	7100087f 	cmp	w3, #0x2
    5db0:	54000420 	b.eq	5e34 <fwp_closure_drop+0xd4>  // b.none
    5db4:	7100047f 	cmp	w3, #0x1
    5db8:	54000201 	b.ne	5df8 <fwp_closure_drop+0x98>  // b.any
    5dbc:	29430003 	ldp	w3, w0, [x0, #24]
    5dc0:	92403c42 	and	x2, x2, #0xffff
    5dc4:	9b037c42 	mul	x2, x2, x3
    5dc8:	d360fc42 	lsr	x2, x2, #32
    5dcc:	eb00005f 	cmp	x2, x0
    5dd0:	54000142 	b.cs	5df8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5dd4:	8b020273 	add	x19, x19, x2
    5dd8:	39400260 	ldrb	w0, [x19]
    5ddc:	340000e0 	cbz	w0, 5df8 <fwp_closure_drop+0x98>
    5de0:	7100041f 	cmp	w0, #0x1
    5de4:	54000100 	b.eq	5e04 <fwp_closure_drop+0xa4>  // b.none
    5de8:	7103fc1f 	cmp	w0, #0xff
    5dec:	54000300 	b.eq	5e4c <fwp_closure_drop+0xec>  // b.none
    5df0:	51000400 	sub	w0, w0, #0x1
    5df4:	39000260 	strb	w0, [x19]
    5df8:	f9400bf3 	ldr	x19, [sp, #16]
    5dfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e00:	d65f03c0 	ret
    5e04:	d53bd040 	mrs	x0, tpidr_el0
    5e08:	91400000 	add	x0, x0, #0x0, lsl #12
    5e0c:	91004000 	add	x0, x0, #0x10
    5e10:	f9400000 	ldr	x0, [x0]
    5e14:	b4000080 	cbz	x0, 5e24 <fwp_closure_drop+0xc4>
    5e18:	f9400bf3 	ldr	x19, [sp, #16]
    5e1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e20:	17fff691 	b	3864 <fwp_closure_drop_push>
    5e24:	f9400bf3 	ldr	x19, [sp, #16]
    5e28:	aa0103e0 	mov	x0, x1
    5e2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e30:	17fff6fc 	b	3a20 <fwp_closure_drop.part.0>
    5e34:	72003c5f 	tst	w2, #0xffff
    5e38:	54fffd00 	b.eq	5dd8 <fwp_closure_drop+0x78>  // b.none
    5e3c:	f9400bf3 	ldr	x19, [sp, #16]
    5e40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e44:	d65f03c0 	ret
    5e48:	d65f03c0 	ret
    5e4c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e50:	911740a5 	add	x5, x5, #0x5d0
    5e54:	ca402400 	eor	x0, x0, x0, lsr #9
    5e58:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5e5c:	f94a2400 	ldr	x0, [x0, #5192]
    5e60:	b5000080 	cbnz	x0, 5e70 <fwp_closure_drop+0x110>
    5e64:	14000010 	b	5ea4 <fwp_closure_drop+0x144>
    5e68:	f9400800 	ldr	x0, [x0, #16]
    5e6c:	b40001c0 	cbz	x0, 5ea4 <fwp_closure_drop+0x144>
    5e70:	f9400001 	ldr	x1, [x0]
    5e74:	eb13003f 	cmp	x1, x19
    5e78:	54ffff81 	b.ne	5e68 <fwp_closure_drop+0x108>  // b.any
    5e7c:	f9400401 	ldr	x1, [x0, #8]
    5e80:	d1000421 	sub	x1, x1, #0x1
    5e84:	f9000401 	str	x1, [x0, #8]
    5e88:	f103f83f 	cmp	x1, #0xfe
    5e8c:	54fffb61 	b.ne	5df8 <fwp_closure_drop+0x98>  // b.any
    5e90:	aa1303e0 	mov	x0, x19
    5e94:	97fffa57 	bl	47f0 <fwp_rc_forget_slot>
    5e98:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e9c:	39000260 	strb	w0, [x19]
    5ea0:	17ffffd6 	b	5df8 <fwp_closure_drop+0x98>
    5ea4:	d0000020 	adrp	x0, b000 <__divti3+0x100>
    5ea8:	91260000 	add	x0, x0, #0x980
    5eac:	97fff655 	bl	3800 <fwp_trap>

0000000000005eb0 <fwp_owned_tape_release>:
    5eb0:	b4000940 	cbz	x0, 5fd8 <fwp_owned_tape_release+0x128>
    5eb4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5eb8:	910003fd 	mov	x29, sp
    5ebc:	a90153f3 	stp	x19, x20, [sp, #16]
    5ec0:	aa0003f3 	mov	x19, x0
    5ec4:	f9400000 	ldr	x0, [x0]
    5ec8:	b4000060 	cbz	x0, 5ed4 <fwp_owned_tape_release+0x24>
    5ecc:	f9400661 	ldr	x1, [x19, #8]
    5ed0:	f9000401 	str	x1, [x0, #8]
    5ed4:	f9400661 	ldr	x1, [x19, #8]
    5ed8:	b4000041 	cbz	x1, 5ee0 <fwp_owned_tape_release+0x30>
    5edc:	f9000020 	str	x0, [x1]
    5ee0:	f9400a60 	ldr	x0, [x19, #16]
    5ee4:	f9403401 	ldr	x1, [x0, #104]
    5ee8:	b40005c1 	cbz	x1, 5fa0 <fwp_owned_tape_release+0xf0>
    5eec:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ef0:	eb00005f 	cmp	x2, x0
    5ef4:	540002ed 	b.le	5f50 <fwp_owned_tape_release+0xa0>
    5ef8:	d2800014 	mov	x20, #0x0                   	// #0
    5efc:	f90013f5 	str	x21, [sp, #32]
    5f00:	d2800015 	mov	x21, #0x0                   	// #0
    5f04:	d503201f 	nop
    5f08:	f9402260 	ldr	x0, [x19, #64]
    5f0c:	910006b5 	add	x21, x21, #0x1
    5f10:	f8746800 	ldr	x0, [x0, x20]
    5f14:	d63f0020 	blr	x1
    5f18:	f9402260 	ldr	x0, [x19, #64]
    5f1c:	f9400a61 	ldr	x1, [x19, #16]
    5f20:	8b140000 	add	x0, x0, x20
    5f24:	91004294 	add	x20, x20, #0x10
    5f28:	f9400400 	ldr	x0, [x0, #8]
    5f2c:	f9403421 	ldr	x1, [x1, #104]
    5f30:	d63f0020 	blr	x1
    5f34:	a9450261 	ldp	x1, x0, [x19, #80]
    5f38:	cb010000 	sub	x0, x0, x1
    5f3c:	eb15001f 	cmp	x0, x21
    5f40:	f9400a60 	ldr	x0, [x19, #16]
    5f44:	f9403401 	ldr	x1, [x0, #104]
    5f48:	54fffe0c 	b.gt	5f08 <fwp_owned_tape_release+0x58>
    5f4c:	f94013f5 	ldr	x21, [sp, #32]
    5f50:	f9403663 	ldr	x3, [x19, #104]
    5f54:	f9401262 	ldr	x2, [x19, #32]
    5f58:	f100007f 	cmp	x3, #0x0
    5f5c:	540001ed 	b.le	5f98 <fwp_owned_tape_release+0xe8>
    5f60:	d2800014 	mov	x20, #0x0                   	// #0
    5f64:	d503201f 	nop
    5f68:	f9402660 	ldr	x0, [x19, #72]
    5f6c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5f70:	eb02001f 	cmp	x0, x2
    5f74:	540000c0 	b.eq	5f8c <fwp_owned_tape_release+0xdc>  // b.none
    5f78:	d63f0020 	blr	x1
    5f7c:	f9400a60 	ldr	x0, [x19, #16]
    5f80:	f9401262 	ldr	x2, [x19, #32]
    5f84:	f9403663 	ldr	x3, [x19, #104]
    5f88:	f9403401 	ldr	x1, [x0, #104]
    5f8c:	91000694 	add	x20, x20, #0x1
    5f90:	eb14007f 	cmp	x3, x20
    5f94:	54fffeac 	b.gt	5f68 <fwp_owned_tape_release+0xb8>
    5f98:	aa0203e0 	mov	x0, x2
    5f9c:	d63f0020 	blr	x1
    5fa0:	f9401660 	ldr	x0, [x19, #40]
    5fa4:	97ffff6f 	bl	5d60 <fwp_closure_drop>
    5fa8:	f9401a60 	ldr	x0, [x19, #48]
    5fac:	97ffff6d 	bl	5d60 <fwp_closure_drop>
    5fb0:	f9401e60 	ldr	x0, [x19, #56]
    5fb4:	97ffff6b 	bl	5d60 <fwp_closure_drop>
    5fb8:	f9402260 	ldr	x0, [x19, #64]
    5fbc:	97fffaad 	bl	4a70 <fwp_mem_free>
    5fc0:	f9402660 	ldr	x0, [x19, #72]
    5fc4:	97fffaab 	bl	4a70 <fwp_mem_free>
    5fc8:	aa1303e0 	mov	x0, x19
    5fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fd4:	17fffaa7 	b	4a70 <fwp_mem_free>
    5fd8:	d65f03c0 	ret
    5fdc:	d503201f 	nop

0000000000005fe0 <fwp_tape_finish>:
    5fe0:	d10203ff 	sub	sp, sp, #0x80
    5fe4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5fe8:	f947f421 	ldr	x1, [x1, #4072]
    5fec:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ff0:	910103fd 	add	x29, sp, #0x40
    5ff4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ff8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5ffc:	a90763f7 	stp	x23, x24, [sp, #112]
    6000:	d00000d8 	adrp	x24, 20000 <__data_start>
    6004:	9101c316 	add	x22, x24, #0x70
    6008:	f9400022 	ldr	x2, [x1]
    600c:	f9001fe2 	str	x2, [sp, #56]
    6010:	d2800002 	mov	x2, #0x0                   	// #0
    6014:	910262c0 	add	x0, x22, #0x98
    6018:	97fff51a 	bl	3480 <fwp_tape_buffers_dispose>
    601c:	f9006adf 	str	xzr, [x22, #208]
    6020:	f9404ac0 	ldr	x0, [x22, #144]
    6024:	f100001f 	cmp	x0, #0x0
    6028:	5400030d 	b.le	6088 <fwp_tape_finish+0xa8>
    602c:	910003f7 	mov	x23, sp
    6030:	d2800015 	mov	x21, #0x0                   	// #0
    6034:	d2800014 	mov	x20, #0x0                   	// #0
    6038:	f94002d3 	ldr	x19, [x22]
    603c:	91000694 	add	x20, x20, #0x1
    6040:	8b150273 	add	x19, x19, x21
    6044:	9101a2b5 	add	x21, x21, #0x68
    6048:	aa1303e0 	mov	x0, x19
    604c:	97fff3d1 	bl	2f90 <fwp_tape_unlink_scope>
    6050:	aa1703e0 	mov	x0, x23
    6054:	f9401261 	ldr	x1, [x19, #32]
    6058:	f90003e1 	str	x1, [sp]
    605c:	f9401a62 	ldr	x2, [x19, #48]
    6060:	f9000be2 	str	x2, [sp, #16]
    6064:	f9402261 	ldr	x1, [x19, #64]
    6068:	f90013e1 	str	x1, [sp, #32]
    606c:	97fff505 	bl	3480 <fwp_tape_buffers_dispose>
    6070:	f9403260 	ldr	x0, [x19, #96]
    6074:	97ffff8f 	bl	5eb0 <fwp_owned_tape_release>
    6078:	f900327f 	str	xzr, [x19, #96]
    607c:	f9404ac0 	ldr	x0, [x22, #144]
    6080:	eb14001f 	cmp	x0, x20
    6084:	54fffdac 	b.gt	6038 <fwp_tape_finish+0x58>
    6088:	f9403b00 	ldr	x0, [x24, #112]
    608c:	9101c313 	add	x19, x24, #0x70
    6090:	97fff22c 	bl	2940 <free@plt>
    6094:	f9003b1f 	str	xzr, [x24, #112]
    6098:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    609c:	f947f400 	ldr	x0, [x0, #4072]
    60a0:	f9004a7f 	str	xzr, [x19, #144]
    60a4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    60a8:	f9401fe2 	ldr	x2, [sp, #56]
    60ac:	f9400001 	ldr	x1, [x0]
    60b0:	eb010042 	subs	x2, x2, x1
    60b4:	d2800001 	mov	x1, #0x0                   	// #0
    60b8:	540000e1 	b.ne	60d4 <fwp_tape_finish+0xf4>  // b.any
    60bc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60c0:	a94553f3 	ldp	x19, x20, [sp, #80]
    60c4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60c8:	a94763f7 	ldp	x23, x24, [sp, #112]
    60cc:	910203ff 	add	sp, sp, #0x80
    60d0:	d65f03c0 	ret
    60d4:	97fff1eb 	bl	2880 <__stack_chk_fail@plt>
    60d8:	d503201f 	nop
    60dc:	d503201f 	nop

00000000000060e0 <fwp_tape_scope_release>:
    60e0:	d10243ff 	sub	sp, sp, #0x90
    60e4:	a9047bfd 	stp	x29, x30, [sp, #64]
    60e8:	910103fd 	add	x29, sp, #0x40
    60ec:	a90553f3 	stp	x19, x20, [sp, #80]
    60f0:	aa0003f4 	mov	x20, x0
    60f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    60f8:	f947f400 	ldr	x0, [x0, #4072]
    60fc:	b9400285 	ldr	w5, [x20]
    6100:	f9400001 	ldr	x1, [x0]
    6104:	f9001fe1 	str	x1, [sp, #56]
    6108:	d2800001 	mov	x1, #0x0                   	// #0
    610c:	37f806c5 	tbnz	w5, #31, 61e4 <fwp_tape_scope_release+0x104>
    6110:	a90763f7 	stp	x23, x24, [sp, #112]
    6114:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6118:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    611c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6120:	d00000d3 	adrp	x19, 20000 <__data_start>
    6124:	910003f7 	mov	x23, sp
    6128:	9101c273 	add	x19, x19, #0x70
    612c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6130:	a9065bf5 	stp	x21, x22, [sp, #96]
    6134:	52800d16 	mov	w22, #0x68                  	// #104
    6138:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    613c:	f90043f9 	str	x25, [sp, #128]
    6140:	14000006 	b	6158 <fwp_tape_scope_release+0x78>
    6144:	97fff4cf 	bl	3480 <fwp_tape_buffers_dispose>
    6148:	aa1903e0 	mov	x0, x25
    614c:	97ffff59 	bl	5eb0 <fwp_owned_tape_release>
    6150:	b9400285 	ldr	w5, [x20]
    6154:	37f80425 	tbnz	w5, #31, 61d8 <fwp_tape_scope_release+0xf8>
    6158:	f9400266 	ldr	x6, [x19]
    615c:	9b367ca5 	smull	x5, w5, w22
    6160:	8b0500c0 	add	x0, x6, x5
    6164:	97fff38b 	bl	2f90 <fwp_tape_unlink_scope>
    6168:	ad410001 	ldp	q1, q0, [x0, #32]
    616c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6170:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6174:	f9400c03 	ldr	x3, [x0, #24]
    6178:	ad0003e1 	stp	q1, q0, [sp]
    617c:	b86568c1 	ldr	w1, [x6, x5]
    6180:	a9440804 	ldp	x4, x2, [x0, #64]
    6184:	b900041f 	str	wzr, [x0, #4]
    6188:	f9403019 	ldr	x25, [x0, #96]
    618c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6190:	f9000c1f 	str	xzr, [x0, #24]
    6194:	a9020fe4 	stp	x4, x3, [sp, #32]
    6198:	f9001be2 	str	x2, [sp, #48]
    619c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    61a0:	f900301f 	str	xzr, [x0, #96]
    61a4:	6b15003f 	cmp	w1, w21
    61a8:	540000e8 	b.hi	61c4 <fwp_tape_scope_release+0xe4>  // b.pmore
    61ac:	9343fca5 	asr	x5, x5, #3
    61b0:	f9407660 	ldr	x0, [x19, #232]
    61b4:	9b187ca5 	mul	x5, x5, x24
    61b8:	eb0000bf 	cmp	x5, x0
    61bc:	5400004a 	b.ge	61c4 <fwp_tape_scope_release+0xe4>  // b.tcont
    61c0:	f9007665 	str	x5, [x19, #232]
    61c4:	aa1703e0 	mov	x0, x23
    61c8:	b5fffbf9 	cbnz	x25, 6144 <fwp_tape_scope_release+0x64>
    61cc:	97fff86d 	bl	4380 <fwp_tape_buffers_release>
    61d0:	b9400285 	ldr	w5, [x20]
    61d4:	36fffc25 	tbz	w5, #31, 6158 <fwp_tape_scope_release+0x78>
    61d8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61dc:	a94763f7 	ldp	x23, x24, [sp, #112]
    61e0:	f94043f9 	ldr	x25, [sp, #128]
    61e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    61e8:	f947f400 	ldr	x0, [x0, #4072]
    61ec:	f9401fe2 	ldr	x2, [sp, #56]
    61f0:	f9400001 	ldr	x1, [x0]
    61f4:	eb010042 	subs	x2, x2, x1
    61f8:	d2800001 	mov	x1, #0x0                   	// #0
    61fc:	540000a1 	b.ne	6210 <fwp_tape_scope_release+0x130>  // b.any
    6200:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6204:	a94553f3 	ldp	x19, x20, [sp, #80]
    6208:	910243ff 	add	sp, sp, #0x90
    620c:	d65f03c0 	ret
    6210:	a9065bf5 	stp	x21, x22, [sp, #96]
    6214:	a90763f7 	stp	x23, x24, [sp, #112]
    6218:	f90043f9 	str	x25, [sp, #128]
    621c:	97fff199 	bl	2880 <__stack_chk_fail@plt>

0000000000006220 <fwp_task_dispose>:
    6220:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6224:	910003fd 	mov	x29, sp
    6228:	f9000bf3 	str	x19, [sp, #16]
    622c:	aa0003f3 	mov	x19, x0
    6230:	39414000 	ldrb	w0, [x0, #80]
    6234:	36000720 	tbz	w0, #0, 6318 <fwp_task_dispose+0xf8>
    6238:	f9400a60 	ldr	x0, [x19, #16]
    623c:	b50006e0 	cbnz	x0, 6318 <fwp_task_dispose+0xf8>
    6240:	a9478660 	ldp	x0, x1, [x19, #120]
    6244:	39014e7f 	strb	wzr, [x19, #83]
    6248:	f9003e7f 	str	xzr, [x19, #120]
    624c:	f100003f 	cmp	x1, #0x0
    6250:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6254:	54000040 	b.eq	625c <fwp_task_dispose+0x3c>  // b.none
    6258:	d63f0020 	blr	x1
    625c:	f9405660 	ldr	x0, [x19, #168]
    6260:	97fffa04 	bl	4a70 <fwp_mem_free>
    6264:	f900567f 	str	xzr, [x19, #168]
    6268:	b9405e60 	ldr	w0, [x19, #92]
    626c:	7100041f 	cmp	w0, #0x1
    6270:	54000420 	b.eq	62f4 <fwp_task_dispose+0xd4>  // b.none
    6274:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6278:	91174042 	add	x2, x2, #0x5d0
    627c:	f949d840 	ldr	x0, [x2, #5040]
    6280:	f949ec41 	ldr	x1, [x2, #5080]
    6284:	cb000260 	sub	x0, x19, x0
    6288:	eb01401f 	cmp	x0, x1, lsl #16
    628c:	540002e2 	b.cs	62e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6290:	d350fc01 	lsr	x1, x0, #16
    6294:	f949fc44 	ldr	x4, [x2, #5112]
    6298:	8b010821 	add	x1, x1, x1, lsl #2
    629c:	d37df021 	lsl	x1, x1, #3
    62a0:	8b010083 	add	x3, x4, x1
    62a4:	f9401062 	ldr	x2, [x3, #32]
    62a8:	b4000202 	cbz	x2, 62e8 <fwp_task_dispose+0xc8>
    62ac:	38616881 	ldrb	w1, [x4, x1]
    62b0:	7100083f 	cmp	w1, #0x2
    62b4:	54000280 	b.eq	6304 <fwp_task_dispose+0xe4>  // b.none
    62b8:	7100043f 	cmp	w1, #0x1
    62bc:	54000161 	b.ne	62e8 <fwp_task_dispose+0xc8>  // b.any
    62c0:	29430464 	ldp	w4, w1, [x3, #24]
    62c4:	92403c00 	and	x0, x0, #0xffff
    62c8:	9b047c00 	mul	x0, x0, x4
    62cc:	d360fc00 	lsr	x0, x0, #32
    62d0:	eb01001f 	cmp	x0, x1
    62d4:	540000a2 	b.cs	62e8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    62d8:	8b000042 	add	x2, x2, x0
    62dc:	39400040 	ldrb	w0, [x2]
    62e0:	7100041f 	cmp	w0, #0x1
    62e4:	54000080 	b.eq	62f4 <fwp_task_dispose+0xd4>  // b.none
    62e8:	f9400bf3 	ldr	x19, [sp, #16]
    62ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62f0:	d65f03c0 	ret
    62f4:	aa1303e0 	mov	x0, x19
    62f8:	f9400bf3 	ldr	x19, [sp, #16]
    62fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6300:	17fff9dc 	b	4a70 <fwp_mem_free>
    6304:	72003c1f 	tst	w0, #0xffff
    6308:	54fffea0 	b.eq	62dc <fwp_task_dispose+0xbc>  // b.none
    630c:	f9400bf3 	ldr	x19, [sp, #16]
    6310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6314:	d65f03c0 	ret
    6318:	97fff16e 	bl	28d0 <abort@plt>
    631c:	d503201f 	nop

0000000000006320 <fwp_free_zombie>:
    6320:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6324:	910003fd 	mov	x29, sp
    6328:	a90153f3 	stp	x19, x20, [sp, #16]
    632c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6330:	9101c281 	add	x1, x20, #0x70
    6334:	f9407833 	ldr	x19, [x1, #240]
    6338:	b4000333 	cbz	x19, 639c <fwp_free_zombie+0x7c>
    633c:	f9400820 	ldr	x0, [x1, #16]
    6340:	eb00027f 	cmp	x19, x0
    6344:	540002c0 	b.eq	639c <fwp_free_zombie+0x7c>  // b.none
    6348:	b940f822 	ldr	w2, [x1, #248]
    634c:	f9400a60 	ldr	x0, [x19, #16]
    6350:	7100fc5f 	cmp	w2, #0x3f
    6354:	5400078c 	b.gt	6444 <fwp_free_zombie+0x124>
    6358:	91040023 	add	x3, x1, #0x100
    635c:	11000444 	add	w4, w2, #0x1
    6360:	b900f824 	str	w4, [x1, #248]
    6364:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6368:	f822d860 	str	x0, [x3, w2, sxtw #3]
    636c:	a9530261 	ldp	x1, x0, [x19, #304]
    6370:	b4000741 	cbz	x1, 6458 <fwp_free_zombie+0x138>
    6374:	f9009c20 	str	x0, [x1, #312]
    6378:	b4000040 	cbz	x0, 6380 <fwp_free_zombie+0x60>
    637c:	f9009801 	str	x1, [x0, #304]
    6380:	9101c294 	add	x20, x20, #0x70
    6384:	b9405e60 	ldr	w0, [x19, #92]
    6388:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    638c:	f9007a9f 	str	xzr, [x20, #240]
    6390:	34000140 	cbz	w0, 63b8 <fwp_free_zombie+0x98>
    6394:	7100041f 	cmp	w0, #0x1
    6398:	54000080 	b.eq	63a8 <fwp_free_zombie+0x88>  // b.none
    639c:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63a4:	d65f03c0 	ret
    63a8:	aa1303e0 	mov	x0, x19
    63ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    63b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63b4:	17ffff9b 	b	6220 <fwp_task_dispose>
    63b8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    63bc:	91174082 	add	x2, x4, #0x5d0
    63c0:	f949d841 	ldr	x1, [x2, #5040]
    63c4:	f949ec40 	ldr	x0, [x2, #5080]
    63c8:	cb010261 	sub	x1, x19, x1
    63cc:	eb00403f 	cmp	x1, x0, lsl #16
    63d0:	54fffe62 	b.cs	639c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    63d4:	d350fc20 	lsr	x0, x1, #16
    63d8:	f949fc43 	ldr	x3, [x2, #5112]
    63dc:	8b000800 	add	x0, x0, x0, lsl #2
    63e0:	d37df000 	lsl	x0, x0, #3
    63e4:	8b000062 	add	x2, x3, x0
    63e8:	f9401054 	ldr	x20, [x2, #32]
    63ec:	b4fffd94 	cbz	x20, 639c <fwp_free_zombie+0x7c>
    63f0:	38606860 	ldrb	w0, [x3, x0]
    63f4:	7100081f 	cmp	w0, #0x2
    63f8:	54000360 	b.eq	6464 <fwp_free_zombie+0x144>  // b.none
    63fc:	7100041f 	cmp	w0, #0x1
    6400:	54fffce1 	b.ne	639c <fwp_free_zombie+0x7c>  // b.any
    6404:	29430043 	ldp	w3, w0, [x2, #24]
    6408:	92403c21 	and	x1, x1, #0xffff
    640c:	9b037c21 	mul	x1, x1, x3
    6410:	d360fc21 	lsr	x1, x1, #32
    6414:	eb00003f 	cmp	x1, x0
    6418:	54fffc22 	b.cs	639c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    641c:	8b010294 	add	x20, x20, x1
    6420:	39400280 	ldrb	w0, [x20]
    6424:	34fffbc0 	cbz	w0, 639c <fwp_free_zombie+0x7c>
    6428:	7100041f 	cmp	w0, #0x1
    642c:	54fffbe0 	b.eq	63a8 <fwp_free_zombie+0x88>  // b.none
    6430:	7103fc1f 	cmp	w0, #0xff
    6434:	540001e0 	b.eq	6470 <fwp_free_zombie+0x150>  // b.none
    6438:	51000400 	sub	w0, w0, #0x1
    643c:	39000280 	strb	w0, [x20]
    6440:	17ffffd7 	b	639c <fwp_free_zombie+0x7c>
    6444:	f9400e61 	ldr	x1, [x19, #24]
    6448:	97fff156 	bl	29a0 <munmap@plt>
    644c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6450:	a9530261 	ldp	x1, x0, [x19, #304]
    6454:	b5fff901 	cbnz	x1, 6374 <fwp_free_zombie+0x54>
    6458:	9101c282 	add	x2, x20, #0x70
    645c:	f9018040 	str	x0, [x2, #768]
    6460:	17ffffc6 	b	6378 <fwp_free_zombie+0x58>
    6464:	72003c3f 	tst	w1, #0xffff
    6468:	54fff9a1 	b.ne	639c <fwp_free_zombie+0x7c>  // b.any
    646c:	17ffffed 	b	6420 <fwp_free_zombie+0x100>
    6470:	ca544680 	eor	x0, x20, x20, lsr #17
    6474:	91174084 	add	x4, x4, #0x5d0
    6478:	ca402400 	eor	x0, x0, x0, lsr #9
    647c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6480:	f94a2400 	ldr	x0, [x0, #5192]
    6484:	b5000080 	cbnz	x0, 6494 <fwp_free_zombie+0x174>
    6488:	14000010 	b	64c8 <fwp_free_zombie+0x1a8>
    648c:	f9400800 	ldr	x0, [x0, #16]
    6490:	b40001c0 	cbz	x0, 64c8 <fwp_free_zombie+0x1a8>
    6494:	f9400001 	ldr	x1, [x0]
    6498:	eb14003f 	cmp	x1, x20
    649c:	54ffff81 	b.ne	648c <fwp_free_zombie+0x16c>  // b.any
    64a0:	f9400401 	ldr	x1, [x0, #8]
    64a4:	d1000421 	sub	x1, x1, #0x1
    64a8:	f9000401 	str	x1, [x0, #8]
    64ac:	f103f83f 	cmp	x1, #0xfe
    64b0:	54fff761 	b.ne	639c <fwp_free_zombie+0x7c>  // b.any
    64b4:	aa1403e0 	mov	x0, x20
    64b8:	97fff8ce 	bl	47f0 <fwp_rc_forget_slot>
    64bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64c0:	39000280 	strb	w0, [x20]
    64c4:	17ffffb6 	b	639c <fwp_free_zombie+0x7c>
    64c8:	b0000020 	adrp	x0, b000 <__divti3+0x100>
    64cc:	91260000 	add	x0, x0, #0x980
    64d0:	97fff4cc 	bl	3800 <fwp_trap>

00000000000064d4 <fwp_block>:
    64d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64d8:	910003fd 	mov	x29, sp
    64dc:	a90153f3 	stp	x19, x20, [sp, #16]
    64e0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64e4:	9101c274 	add	x20, x19, #0x70
    64e8:	f9404282 	ldr	x2, [x20, #128]
    64ec:	b4000622 	cbz	x2, 65b0 <fwp_block+0xdc>
    64f0:	9101c261 	add	x1, x19, #0x70
    64f4:	f9408040 	ldr	x0, [x2, #256]
    64f8:	f9004020 	str	x0, [x1, #128]
    64fc:	b4000680 	cbz	x0, 65cc <fwp_block+0xf8>
    6500:	9101c263 	add	x3, x19, #0x70
    6504:	3901505f 	strb	wzr, [x2, #84]
    6508:	f9400864 	ldr	x4, [x3, #16]
    650c:	eb02009f 	cmp	x4, x2
    6510:	54000440 	b.eq	6598 <fwp_block+0xc4>  // b.none
    6514:	f9418465 	ldr	x5, [x3, #776]
    6518:	f9000862 	str	x2, [x3, #16]
    651c:	f9400441 	ldr	x1, [x2, #8]
    6520:	f9004885 	str	x5, [x4, #144]
    6524:	f9418865 	ldr	x5, [x3, #784]
    6528:	f9004c85 	str	x5, [x4, #152]
    652c:	f9418c65 	ldr	x5, [x3, #792]
    6530:	f9005085 	str	x5, [x4, #160]
    6534:	f9419065 	ldr	x5, [x3, #800]
    6538:	f9005485 	str	x5, [x4, #168]
    653c:	f9419465 	ldr	x5, [x3, #808]
    6540:	f9005885 	str	x5, [x4, #176]
    6544:	f9419865 	ldr	x5, [x3, #816]
    6548:	f9005c85 	str	x5, [x4, #184]
    654c:	f9419c65 	ldr	x5, [x3, #824]
    6550:	f9006085 	str	x5, [x4, #192]
    6554:	f9400480 	ldr	x0, [x4, #8]
    6558:	f9404844 	ldr	x4, [x2, #144]
    655c:	f9018464 	str	x4, [x3, #776]
    6560:	f9404c44 	ldr	x4, [x2, #152]
    6564:	f9018864 	str	x4, [x3, #784]
    6568:	f9405044 	ldr	x4, [x2, #160]
    656c:	f9018c64 	str	x4, [x3, #792]
    6570:	f9405444 	ldr	x4, [x2, #168]
    6574:	f9019064 	str	x4, [x3, #800]
    6578:	f9405844 	ldr	x4, [x2, #176]
    657c:	f9019464 	str	x4, [x3, #808]
    6580:	a94b8844 	ldp	x4, x2, [x2, #184]
    6584:	f9019864 	str	x4, [x3, #816]
    6588:	f9019c62 	str	x2, [x3, #824]
    658c:	97fff0d5 	bl	28e0 <swapcontext@plt>
    6590:	97ffff64 	bl	6320 <fwp_free_zombie>
    6594:	d503201f 	nop
    6598:	9101c260 	add	x0, x19, #0x70
    659c:	b9434000 	ldr	w0, [x0, #832]
    65a0:	340001a0 	cbz	w0, 65d4 <fwp_block+0x100>
    65a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    65a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65ac:	d65f03c0 	ret
    65b0:	97fff7bc 	bl	44a0 <fwp_poll_events>
    65b4:	f9404282 	ldr	x2, [x20, #128]
    65b8:	b4ffffc2 	cbz	x2, 65b0 <fwp_block+0xdc>
    65bc:	9101c261 	add	x1, x19, #0x70
    65c0:	f9408040 	ldr	x0, [x2, #256]
    65c4:	f9004020 	str	x0, [x1, #128]
    65c8:	b5fff9c0 	cbnz	x0, 6500 <fwp_block+0x2c>
    65cc:	f9003c3f 	str	xzr, [x1, #120]
    65d0:	17ffffcc 	b	6500 <fwp_block+0x2c>
    65d4:	b0000020 	adrp	x0, b000 <__divti3+0x100>
    65d8:	912ac000 	add	x0, x0, #0xab0
    65dc:	97fff10d 	bl	2a10 <getenv@plt>
    65e0:	5284e202 	mov	w2, #0x2710                	// #10000
    65e4:	b4000060 	cbz	x0, 65f0 <fwp_block+0x11c>
    65e8:	39400001 	ldrb	w1, [x0]
    65ec:	350000c1 	cbnz	w1, 6604 <fwp_block+0x130>
    65f0:	9101c273 	add	x19, x19, #0x70
    65f4:	b9034262 	str	w2, [x19, #832]
    65f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    65fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6600:	d65f03c0 	ret
    6604:	52800142 	mov	w2, #0xa                   	// #10
    6608:	d2800001 	mov	x1, #0x0                   	// #0
    660c:	97fff051 	bl	2750 <strtoll@plt>
    6610:	d1000403 	sub	x3, x0, #0x1
    6614:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6618:	eb02007f 	cmp	x3, x2
    661c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6620:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6624:	17fffff3 	b	65f0 <fwp_block+0x11c>
    6628:	d503201f 	nop
    662c:	d503201f 	nop

0000000000006630 <fwp_owned_entry161>:
    6630:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6634:	910003fd 	mov	x29, sp
    6638:	a90363f7 	stp	x23, x24, [sp, #48]
    663c:	a9406002 	ldp	x2, x24, [x0]
    6640:	a90153f3 	stp	x19, x20, [sp, #16]
    6644:	f9400801 	ldr	x1, [x0, #16]
    6648:	a9025bf5 	stp	x21, x22, [sp, #32]
    664c:	ab010055 	adds	x21, x2, x1
    6650:	54000d06 	b.vs	67f0 <fwp_owned_entry161+0x1c0>
    6654:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6658:	91174281 	add	x1, x20, #0x5d0
    665c:	b953a420 	ldr	w0, [x1, #5028]
    6660:	34000a80 	cbz	w0, 67b0 <fwp_owned_entry161+0x180>
    6664:	397e8820 	ldrb	w0, [x1, #4002]
    6668:	910f0002 	add	x2, x0, #0x3c0
    666c:	8b000400 	add	x0, x0, x0, lsl #1
    6670:	d37df000 	lsl	x0, x0, #3
    6674:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6678:	2a1703f6 	mov	w22, w23
    667c:	f8606833 	ldr	x19, [x1, x0]
    6680:	b4000853 	cbz	x19, 6788 <fwp_owned_entry161+0x158>
    6684:	f9400262 	ldr	x2, [x19]
    6688:	aa2203e2 	mvn	x2, x2
    668c:	f8206822 	str	x2, [x1, x0]
    6690:	f10062df 	cmp	x22, #0x18
    6694:	540000e9 	b.ls	66b0 <fwp_owned_entry161+0x80>  // b.plast
    6698:	d10066c2 	sub	x2, x22, #0x19
    669c:	91006260 	add	x0, x19, #0x18
    66a0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    66a4:	52800001 	mov	w1, #0x0                   	// #0
    66a8:	91002042 	add	x2, x2, #0x8
    66ac:	97fff069 	bl	2850 <memset@plt>
    66b0:	91174281 	add	x1, x20, #0x5d0
    66b4:	f94a1020 	ldr	x0, [x1, #5152]
    66b8:	ab160000 	adds	x0, x0, x22
    66bc:	540009c2 	b.cs	67f4 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    66c0:	f94a1422 	ldr	x2, [x1, #5160]
    66c4:	f90a1020 	str	x0, [x1, #5152]
    66c8:	eb02001f 	cmp	x0, x2
    66cc:	54000049 	b.ls	66d4 <fwp_owned_entry161+0xa4>  // b.plast
    66d0:	f90a1420 	str	x0, [x1, #5160]
    66d4:	91174280 	add	x0, x20, #0x5d0
    66d8:	1e6302e1 	ucvtf	d1, w23
    66dc:	fd4a1c00 	ldr	d0, [x0, #5176]
    66e0:	1e612800 	fadd	d0, d0, d1
    66e4:	fd0a1c00 	str	d0, [x0, #5176]
    66e8:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    66ec:	91174294 	add	x20, x20, #0x5d0
    66f0:	a900d678 	stp	x24, x21, [x19, #8]
    66f4:	fd420800 	ldr	d0, [x0, #1040]
    66f8:	fd000260 	str	d0, [x19]
    66fc:	f949da81 	ldr	x1, [x20, #5040]
    6700:	f949ee80 	ldr	x0, [x20, #5080]
    6704:	cb010261 	sub	x1, x19, x1
    6708:	eb00403f 	cmp	x1, x0, lsl #16
    670c:	54000322 	b.cs	6770 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6710:	d350fc20 	lsr	x0, x1, #16
    6714:	f949fe83 	ldr	x3, [x20, #5112]
    6718:	8b000800 	add	x0, x0, x0, lsl #2
    671c:	d37df002 	lsl	x2, x0, #3
    6720:	8b020060 	add	x0, x3, x2
    6724:	f9401014 	ldr	x20, [x0, #32]
    6728:	b4000254 	cbz	x20, 6770 <fwp_owned_entry161+0x140>
    672c:	38626862 	ldrb	w2, [x3, x2]
    6730:	7100085f 	cmp	w2, #0x2
    6734:	54000480 	b.eq	67c4 <fwp_owned_entry161+0x194>  // b.none
    6738:	7100045f 	cmp	w2, #0x1
    673c:	540001a1 	b.ne	6770 <fwp_owned_entry161+0x140>  // b.any
    6740:	29430002 	ldp	w2, w0, [x0, #24]
    6744:	92403c21 	and	x1, x1, #0xffff
    6748:	9b027c21 	mul	x1, x1, x2
    674c:	d360fc21 	lsr	x1, x1, #32
    6750:	eb00003f 	cmp	x1, x0
    6754:	540000e2 	b.cs	6770 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6758:	8b010294 	add	x20, x20, x1
    675c:	39400280 	ldrb	w0, [x20]
    6760:	7103fc1f 	cmp	w0, #0xff
    6764:	54000400 	b.eq	67e4 <fwp_owned_entry161+0x1b4>  // b.none
    6768:	52800020 	mov	w0, #0x1                   	// #1
    676c:	39000280 	strb	w0, [x20]
    6770:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6774:	aa1303e0 	mov	x0, x19
    6778:	a94153f3 	ldp	x19, x20, [sp, #16]
    677c:	a94363f7 	ldp	x23, x24, [sp, #48]
    6780:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6784:	d65f03c0 	ret
    6788:	8b000021 	add	x1, x1, x0
    678c:	f9400433 	ldr	x19, [x1, #8]
    6790:	b4000113 	cbz	x19, 67b0 <fwp_owned_entry161+0x180>
    6794:	f9400820 	ldr	x0, [x1, #16]
    6798:	cb130000 	sub	x0, x0, x19
    679c:	eb0002df 	cmp	x22, x0
    67a0:	54000088 	b.hi	67b0 <fwp_owned_entry161+0x180>  // b.pmore
    67a4:	8b160260 	add	x0, x19, x22
    67a8:	f9000420 	str	x0, [x1, #8]
    67ac:	17ffffb9 	b	6690 <fwp_owned_entry161+0x60>
    67b0:	52800001 	mov	w1, #0x0                   	// #0
    67b4:	d2800300 	mov	x0, #0x18                  	// #24
    67b8:	97fff9ce 	bl	4ef0 <fwp_heap_alloc>
    67bc:	aa0003f3 	mov	x19, x0
    67c0:	17ffffca 	b	66e8 <fwp_owned_entry161+0xb8>
    67c4:	72003c3f 	tst	w1, #0xffff
    67c8:	54fffca0 	b.eq	675c <fwp_owned_entry161+0x12c>  // b.none
    67cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    67d0:	aa1303e0 	mov	x0, x19
    67d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    67d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    67dc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    67e0:	d65f03c0 	ret
    67e4:	aa1403e0 	mov	x0, x20
    67e8:	97fff802 	bl	47f0 <fwp_rc_forget_slot>
    67ec:	17ffffdf 	b	6768 <fwp_owned_entry161+0x138>
    67f0:	97fff0a4 	bl	2a80 <fwp_trap_overflow.constprop.0>
    67f4:	97fff20f 	bl	3030 <fwp_heap_oom>
    67f8:	d503201f 	nop
    67fc:	d503201f 	nop

0000000000006800 <e161>:
    6800:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6804:	910003fd 	mov	x29, sp
    6808:	a90363f7 	stp	x23, x24, [sp, #48]
    680c:	a9406002 	ldp	x2, x24, [x0]
    6810:	a90153f3 	stp	x19, x20, [sp, #16]
    6814:	f9400801 	ldr	x1, [x0, #16]
    6818:	a9025bf5 	stp	x21, x22, [sp, #32]
    681c:	ab010055 	adds	x21, x2, x1
    6820:	54000d86 	b.vs	69d0 <e161+0x1d0>
    6824:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6828:	91174281 	add	x1, x20, #0x5d0
    682c:	b953a420 	ldr	w0, [x1, #5028]
    6830:	34000ac0 	cbz	w0, 6988 <e161+0x188>
    6834:	397e8820 	ldrb	w0, [x1, #4002]
    6838:	910f0002 	add	x2, x0, #0x3c0
    683c:	8b000400 	add	x0, x0, x0, lsl #1
    6840:	d37df000 	lsl	x0, x0, #3
    6844:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6848:	2a1703f6 	mov	w22, w23
    684c:	f8606833 	ldr	x19, [x1, x0]
    6850:	b4000893 	cbz	x19, 6960 <e161+0x160>
    6854:	f9400262 	ldr	x2, [x19]
    6858:	aa2203e2 	mvn	x2, x2
    685c:	f8206822 	str	x2, [x1, x0]
    6860:	f10062df 	cmp	x22, #0x18
    6864:	540000e9 	b.ls	6880 <e161+0x80>  // b.plast
    6868:	d10066c2 	sub	x2, x22, #0x19
    686c:	91006260 	add	x0, x19, #0x18
    6870:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6874:	52800001 	mov	w1, #0x0                   	// #0
    6878:	91002042 	add	x2, x2, #0x8
    687c:	97ffeff5 	bl	2850 <memset@plt>
    6880:	91174281 	add	x1, x20, #0x5d0
    6884:	f94a1020 	ldr	x0, [x1, #5152]
    6888:	ab160000 	adds	x0, x0, x22
    688c:	54000a42 	b.cs	69d4 <e161+0x1d4>  // b.hs, b.nlast
    6890:	f94a1422 	ldr	x2, [x1, #5160]
    6894:	f90a1020 	str	x0, [x1, #5152]
    6898:	eb02001f 	cmp	x0, x2
    689c:	54000049 	b.ls	68a4 <e161+0xa4>  // b.plast
    68a0:	f90a1420 	str	x0, [x1, #5160]
    68a4:	91174280 	add	x0, x20, #0x5d0
    68a8:	1e6302e1 	ucvtf	d1, w23
    68ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    68b0:	1e612800 	fadd	d0, d0, d1
    68b4:	fd0a1c00 	str	d0, [x0, #5176]
    68b8:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    68bc:	91174294 	add	x20, x20, #0x5d0
    68c0:	a900d678 	stp	x24, x21, [x19, #8]
    68c4:	fd420800 	ldr	d0, [x0, #1040]
    68c8:	fd000260 	str	d0, [x19]
    68cc:	f949da81 	ldr	x1, [x20, #5040]
    68d0:	f949ee80 	ldr	x0, [x20, #5080]
    68d4:	cb010261 	sub	x1, x19, x1
    68d8:	eb00403f 	cmp	x1, x0, lsl #16
    68dc:	54000322 	b.cs	6940 <e161+0x140>  // b.hs, b.nlast
    68e0:	d350fc20 	lsr	x0, x1, #16
    68e4:	f949fe83 	ldr	x3, [x20, #5112]
    68e8:	8b000800 	add	x0, x0, x0, lsl #2
    68ec:	d37df002 	lsl	x2, x0, #3
    68f0:	8b020060 	add	x0, x3, x2
    68f4:	f9401014 	ldr	x20, [x0, #32]
    68f8:	b4000254 	cbz	x20, 6940 <e161+0x140>
    68fc:	38626862 	ldrb	w2, [x3, x2]
    6900:	7100085f 	cmp	w2, #0x2
    6904:	540004c0 	b.eq	699c <e161+0x19c>  // b.none
    6908:	7100045f 	cmp	w2, #0x1
    690c:	540001a1 	b.ne	6940 <e161+0x140>  // b.any
    6910:	29430002 	ldp	w2, w0, [x0, #24]
    6914:	92403c21 	and	x1, x1, #0xffff
    6918:	9b027c21 	mul	x1, x1, x2
    691c:	d360fc21 	lsr	x1, x1, #32
    6920:	eb00003f 	cmp	x1, x0
    6924:	540000e2 	b.cs	6940 <e161+0x140>  // b.hs, b.nlast
    6928:	8b010294 	add	x20, x20, x1
    692c:	39400280 	ldrb	w0, [x20]
    6930:	7103fc1f 	cmp	w0, #0xff
    6934:	54000480 	b.eq	69c4 <e161+0x1c4>  // b.none
    6938:	52800020 	mov	w0, #0x1                   	// #1
    693c:	39000280 	strb	w0, [x20]
    6940:	aa1303e0 	mov	x0, x19
    6944:	97fffbe8 	bl	58e4 <fwp_rc_share>
    6948:	a9425bf5 	ldp	x21, x22, [sp, #32]
    694c:	aa1303e0 	mov	x0, x19
    6950:	a94153f3 	ldp	x19, x20, [sp, #16]
    6954:	a94363f7 	ldp	x23, x24, [sp, #48]
    6958:	a8c47bfd 	ldp	x29, x30, [sp], #64
    695c:	d65f03c0 	ret
    6960:	8b000021 	add	x1, x1, x0
    6964:	f9400433 	ldr	x19, [x1, #8]
    6968:	b4000113 	cbz	x19, 6988 <e161+0x188>
    696c:	f9400820 	ldr	x0, [x1, #16]
    6970:	cb130000 	sub	x0, x0, x19
    6974:	eb0002df 	cmp	x22, x0
    6978:	54000088 	b.hi	6988 <e161+0x188>  // b.pmore
    697c:	8b160260 	add	x0, x19, x22
    6980:	f9000420 	str	x0, [x1, #8]
    6984:	17ffffb7 	b	6860 <e161+0x60>
    6988:	52800001 	mov	w1, #0x0                   	// #0
    698c:	d2800300 	mov	x0, #0x18                  	// #24
    6990:	97fff958 	bl	4ef0 <fwp_heap_alloc>
    6994:	aa0003f3 	mov	x19, x0
    6998:	17ffffc8 	b	68b8 <e161+0xb8>
    699c:	72003c3f 	tst	w1, #0xffff
    69a0:	54fffc60 	b.eq	692c <e161+0x12c>  // b.none
    69a4:	aa1303e0 	mov	x0, x19
    69a8:	97fffbcf 	bl	58e4 <fwp_rc_share>
    69ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    69b0:	aa1303e0 	mov	x0, x19
    69b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    69bc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    69c0:	d65f03c0 	ret
    69c4:	aa1403e0 	mov	x0, x20
    69c8:	97fff78a 	bl	47f0 <fwp_rc_forget_slot>
    69cc:	17ffffdb 	b	6938 <e161+0x138>
    69d0:	97fff02c 	bl	2a80 <fwp_trap_overflow.constprop.0>
    69d4:	97fff197 	bl	3030 <fwp_heap_oom>
    69d8:	d503201f 	nop
    69dc:	d503201f 	nop

00000000000069e0 <fwp_drop4>:
    69e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69e4:	910003fd 	mov	x29, sp
    69e8:	a90153f3 	stp	x19, x20, [sp, #16]
    69ec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    69f0:	f90013f5 	str	x21, [sp, #32]
    69f4:	91174275 	add	x21, x19, #0x5d0
    69f8:	f949daa1 	ldr	x1, [x21, #5040]
    69fc:	f949eea2 	ldr	x2, [x21, #5080]
    6a00:	cb010001 	sub	x1, x0, x1
    6a04:	eb02403f 	cmp	x1, x2, lsl #16
    6a08:	54000382 	b.cs	6a78 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a0c:	d350fc22 	lsr	x2, x1, #16
    6a10:	f949fea3 	ldr	x3, [x21, #5112]
    6a14:	8b020842 	add	x2, x2, x2, lsl #2
    6a18:	d37df042 	lsl	x2, x2, #3
    6a1c:	8b020064 	add	x4, x3, x2
    6a20:	f9401094 	ldr	x20, [x4, #32]
    6a24:	b40002b4 	cbz	x20, 6a78 <fwp_drop4+0x98>
    6a28:	38626862 	ldrb	w2, [x3, x2]
    6a2c:	7100085f 	cmp	w2, #0x2
    6a30:	540007a0 	b.eq	6b24 <fwp_drop4+0x144>  // b.none
    6a34:	7100045f 	cmp	w2, #0x1
    6a38:	54000201 	b.ne	6a78 <fwp_drop4+0x98>  // b.any
    6a3c:	29430885 	ldp	w5, w2, [x4, #24]
    6a40:	92403c21 	and	x1, x1, #0xffff
    6a44:	9b057c21 	mul	x1, x1, x5
    6a48:	d360fc21 	lsr	x1, x1, #32
    6a4c:	eb02003f 	cmp	x1, x2
    6a50:	54000142 	b.cs	6a78 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a54:	8b010294 	add	x20, x20, x1
    6a58:	39400281 	ldrb	w1, [x20]
    6a5c:	340000e1 	cbz	w1, 6a78 <fwp_drop4+0x98>
    6a60:	7100043f 	cmp	w1, #0x1
    6a64:	54000120 	b.eq	6a88 <fwp_drop4+0xa8>  // b.none
    6a68:	7103fc3f 	cmp	w1, #0xff
    6a6c:	540007c0 	b.eq	6b64 <fwp_drop4+0x184>  // b.none
    6a70:	51000421 	sub	w1, w1, #0x1
    6a74:	39000281 	strb	w1, [x20]
    6a78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a7c:	f94013f5 	ldr	x21, [sp, #32]
    6a80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a84:	d65f03c0 	ret
    6a88:	f9400001 	ldr	x1, [x0]
    6a8c:	b7f80581 	tbnz	x1, #63, 6b3c <fwp_drop4+0x15c>
    6a90:	91174273 	add	x19, x19, #0x5d0
    6a94:	f949da61 	ldr	x1, [x19, #5040]
    6a98:	f949ee62 	ldr	x2, [x19, #5080]
    6a9c:	cb010001 	sub	x1, x0, x1
    6aa0:	eb02403f 	cmp	x1, x2, lsl #16
    6aa4:	54fffea2 	b.cs	6a78 <fwp_drop4+0x98>  // b.hs, b.nlast
    6aa8:	d350fc22 	lsr	x2, x1, #16
    6aac:	8b020842 	add	x2, x2, x2, lsl #2
    6ab0:	d37df042 	lsl	x2, x2, #3
    6ab4:	8b020065 	add	x5, x3, x2
    6ab8:	f94010a4 	ldr	x4, [x5, #32]
    6abc:	b4fffde4 	cbz	x4, 6a78 <fwp_drop4+0x98>
    6ac0:	38626862 	ldrb	w2, [x3, x2]
    6ac4:	7100085f 	cmp	w2, #0x2
    6ac8:	54000220 	b.eq	6b0c <fwp_drop4+0x12c>  // b.none
    6acc:	7100045f 	cmp	w2, #0x1
    6ad0:	54fffd41 	b.ne	6a78 <fwp_drop4+0x98>  // b.any
    6ad4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ad8:	92403c21 	and	x1, x1, #0xffff
    6adc:	9b037c21 	mul	x1, x1, x3
    6ae0:	d360fc21 	lsr	x1, x1, #32
    6ae4:	eb02003f 	cmp	x1, x2
    6ae8:	54fffc82 	b.cs	6a78 <fwp_drop4+0x98>  // b.hs, b.nlast
    6aec:	8b010084 	add	x4, x4, x1
    6af0:	39400081 	ldrb	w1, [x4]
    6af4:	7100043f 	cmp	w1, #0x1
    6af8:	54fffc01 	b.ne	6a78 <fwp_drop4+0x98>  // b.any
    6afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b00:	f94013f5 	ldr	x21, [sp, #32]
    6b04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b08:	17fff7da 	b	4a70 <fwp_mem_free>
    6b0c:	72003c3f 	tst	w1, #0xffff
    6b10:	54ffff00 	b.eq	6af0 <fwp_drop4+0x110>  // b.none
    6b14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b18:	f94013f5 	ldr	x21, [sp, #32]
    6b1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b20:	d65f03c0 	ret
    6b24:	72003c3f 	tst	w1, #0xffff
    6b28:	54fff980 	b.eq	6a58 <fwp_drop4+0x78>  // b.none
    6b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b30:	f94013f5 	ldr	x21, [sp, #32]
    6b34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b38:	d65f03c0 	ret
    6b3c:	f9400414 	ldr	x20, [x0, #8]
    6b40:	97fffb90 	bl	5980 <fwp_rc_free_arr>
    6b44:	91174260 	add	x0, x19, #0x5d0
    6b48:	f949d801 	ldr	x1, [x0, #5040]
    6b4c:	f949ec00 	ldr	x0, [x0, #5080]
    6b50:	cb010281 	sub	x1, x20, x1
    6b54:	eb00403f 	cmp	x1, x0, lsl #16
    6b58:	54fff902 	b.cs	6a78 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b5c:	aa1403e0 	mov	x0, x20
    6b60:	17ffffab 	b	6a0c <fwp_drop4+0x2c>
    6b64:	ca544680 	eor	x0, x20, x20, lsr #17
    6b68:	91174273 	add	x19, x19, #0x5d0
    6b6c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b70:	8b200e60 	add	x0, x19, w0, uxtb #3
    6b74:	f94a2400 	ldr	x0, [x0, #5192]
    6b78:	b5000080 	cbnz	x0, 6b88 <fwp_drop4+0x1a8>
    6b7c:	14000010 	b	6bbc <fwp_drop4+0x1dc>
    6b80:	f9400800 	ldr	x0, [x0, #16]
    6b84:	b40001c0 	cbz	x0, 6bbc <fwp_drop4+0x1dc>
    6b88:	f9400001 	ldr	x1, [x0]
    6b8c:	eb14003f 	cmp	x1, x20
    6b90:	54ffff81 	b.ne	6b80 <fwp_drop4+0x1a0>  // b.any
    6b94:	f9400401 	ldr	x1, [x0, #8]
    6b98:	d1000421 	sub	x1, x1, #0x1
    6b9c:	f9000401 	str	x1, [x0, #8]
    6ba0:	f103f83f 	cmp	x1, #0xfe
    6ba4:	54fff6a1 	b.ne	6a78 <fwp_drop4+0x98>  // b.any
    6ba8:	aa1403e0 	mov	x0, x20
    6bac:	97fff711 	bl	47f0 <fwp_rc_forget_slot>
    6bb0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bb4:	39000280 	strb	w0, [x20]
    6bb8:	17ffffb0 	b	6a78 <fwp_drop4+0x98>
    6bbc:	b0000020 	adrp	x0, b000 <__divti3+0x100>
    6bc0:	91260000 	add	x0, x0, #0x980
    6bc4:	97fff30f 	bl	3800 <fwp_trap>
    6bc8:	d503201f 	nop
    6bcc:	d503201f 	nop

0000000000006bd0 <fwp_caps161>:
    6bd0:	34000041 	cbz	w1, 6bd8 <fwp_caps161+0x8>
    6bd4:	d65f03c0 	ret
    6bd8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6bdc:	91174063 	add	x3, x3, #0x5d0
    6be0:	f949d861 	ldr	x1, [x3, #5040]
    6be4:	f949ec62 	ldr	x2, [x3, #5080]
    6be8:	cb010001 	sub	x1, x0, x1
    6bec:	eb02403f 	cmp	x1, x2, lsl #16
    6bf0:	54ffff22 	b.cs	6bd4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6bf4:	d350fc22 	lsr	x2, x1, #16
    6bf8:	f949fc65 	ldr	x5, [x3, #5112]
    6bfc:	8b020842 	add	x2, x2, x2, lsl #2
    6c00:	d37df042 	lsl	x2, x2, #3
    6c04:	8b0200a4 	add	x4, x5, x2
    6c08:	f9401083 	ldr	x3, [x4, #32]
    6c0c:	b4fffe43 	cbz	x3, 6bd4 <fwp_caps161+0x4>
    6c10:	386268a2 	ldrb	w2, [x5, x2]
    6c14:	7100085f 	cmp	w2, #0x2
    6c18:	540001c0 	b.eq	6c50 <fwp_caps161+0x80>  // b.none
    6c1c:	7100045f 	cmp	w2, #0x1
    6c20:	54fffda1 	b.ne	6bd4 <fwp_caps161+0x4>  // b.any
    6c24:	29430885 	ldp	w5, w2, [x4, #24]
    6c28:	92403c21 	and	x1, x1, #0xffff
    6c2c:	9b057c21 	mul	x1, x1, x5
    6c30:	d360fc21 	lsr	x1, x1, #32
    6c34:	eb02003f 	cmp	x1, x2
    6c38:	54fffce2 	b.cs	6bd4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c3c:	8b010063 	add	x3, x3, x1
    6c40:	39400061 	ldrb	w1, [x3]
    6c44:	7100043f 	cmp	w1, #0x1
    6c48:	54fffc61 	b.ne	6bd4 <fwp_caps161+0x4>  // b.any
    6c4c:	17fff789 	b	4a70 <fwp_mem_free>
    6c50:	72003c3f 	tst	w1, #0xffff
    6c54:	54ffff60 	b.eq	6c40 <fwp_caps161+0x70>  // b.none
    6c58:	d65f03c0 	ret
    6c5c:	d503201f 	nop

0000000000006c60 <f12>:
    6c60:	d10483ff 	sub	sp, sp, #0x120
    6c64:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6c68:	f947f442 	ldr	x2, [x2, #4072]
    6c6c:	910103e8 	add	x8, sp, #0x40
    6c70:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6c74:	9102c3fd 	add	x29, sp, #0xb0
    6c78:	9100e3e9 	add	x9, sp, #0x38
    6c7c:	a90c53f3 	stp	x19, x20, [sp, #192]
    6c80:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6c84:	91174263 	add	x3, x19, #0x5d0
    6c88:	d00000d4 	adrp	x20, 20000 <__data_start>
    6c8c:	9101c284 	add	x4, x20, #0x70
    6c90:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6c94:	90000016 	adrp	x22, 6000 <fwp_tape_finish+0x20>
    6c98:	aa0003f5 	mov	x21, x0
    6c9c:	f949d861 	ldr	x1, [x3, #5040]
    6ca0:	a90e63f7 	stp	x23, x24, [sp, #224]
    6ca4:	d00000d7 	adrp	x23, 20000 <__data_start>
    6ca8:	f949ec65 	ldr	x5, [x3, #5080]
    6cac:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6cb0:	910042f7 	add	x23, x23, #0x10
    6cb4:	a91073fb 	stp	x27, x28, [sp, #256]
    6cb8:	9100e2f7 	add	x23, x23, #0x38
    6cbc:	cb0102e1 	sub	x1, x23, x1
    6cc0:	f9418886 	ldr	x6, [x4, #784]
    6cc4:	fd008be8 	str	d8, [sp, #272]
    6cc8:	f9400047 	ldr	x7, [x2]
    6ccc:	f90057e7 	str	x7, [sp, #168]
    6cd0:	d2800007 	mov	x7, #0x0                   	// #0
    6cd4:	910382c2 	add	x2, x22, #0xe0
    6cd8:	12800007 	mov	w7, #0xffffffff            	// #-1
    6cdc:	a90123e9 	stp	x9, x8, [sp, #16]
    6ce0:	b9003be7 	str	w7, [sp, #56]
    6ce4:	a9040be6 	stp	x6, x2, [sp, #64]
    6ce8:	f9002be9 	str	x9, [sp, #80]
    6cec:	f9018888 	str	x8, [x4, #784]
    6cf0:	eb05403f 	cmp	x1, x5, lsl #16
    6cf4:	54000342 	b.cs	6d5c <f12+0xfc>  // b.hs, b.nlast
    6cf8:	d350fc20 	lsr	x0, x1, #16
    6cfc:	f949fc64 	ldr	x4, [x3, #5112]
    6d00:	8b000800 	add	x0, x0, x0, lsl #2
    6d04:	d37df002 	lsl	x2, x0, #3
    6d08:	8b020083 	add	x3, x4, x2
    6d0c:	f9401060 	ldr	x0, [x3, #32]
    6d10:	b4000260 	cbz	x0, 6d5c <f12+0xfc>
    6d14:	38626882 	ldrb	w2, [x4, x2]
    6d18:	7100085f 	cmp	w2, #0x2
    6d1c:	54007840 	b.eq	7c24 <f12+0xfc4>  // b.none
    6d20:	7100045f 	cmp	w2, #0x1
    6d24:	540001c1 	b.ne	6d5c <f12+0xfc>  // b.any
    6d28:	29430864 	ldp	w4, w2, [x3, #24]
    6d2c:	92403c21 	and	x1, x1, #0xffff
    6d30:	9b047c21 	mul	x1, x1, x4
    6d34:	d360fc21 	lsr	x1, x1, #32
    6d38:	eb02003f 	cmp	x1, x2
    6d3c:	54000102 	b.cs	6d5c <f12+0xfc>  // b.hs, b.nlast
    6d40:	8b010000 	add	x0, x0, x1
    6d44:	39400001 	ldrb	w1, [x0]
    6d48:	340000a1 	cbz	w1, 6d5c <f12+0xfc>
    6d4c:	7103f43f 	cmp	w1, #0xfd
    6d50:	54007fe8 	b.hi	7d4c <f12+0x10ec>  // b.pmore
    6d54:	11000421 	add	w1, w1, #0x1
    6d58:	39000001 	strb	w1, [x0]
    6d5c:	aa1703e0 	mov	x0, x23
    6d60:	97fffc00 	bl	5d60 <fwp_closure_drop>
    6d64:	b40076b5 	cbz	x21, 7c38 <f12+0xfd8>
    6d68:	aa1503e0 	mov	x0, x21
    6d6c:	d2800017 	mov	x23, #0x0                   	// #0
    6d70:	f9400800 	ldr	x0, [x0, #16]
    6d74:	910006f7 	add	x23, x23, #0x1
    6d78:	b5ffffc0 	cbnz	x0, 6d70 <f12+0x110>
    6d7c:	52800000 	mov	w0, #0x0                   	// #0
    6d80:	97fff21c 	bl	35f0 <descent_phase_step>
    6d84:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6d88:	eb0002ff 	cmp	x23, x0
    6d8c:	54008208 	b.hi	7dcc <f12+0x116c>  // b.pmore
    6d90:	9101c298 	add	x24, x20, #0x70
    6d94:	b9434700 	ldr	w0, [x24, #836]
    6d98:	34007320 	cbz	w0, 7bfc <f12+0xf9c>
    6d9c:	9101c280 	add	x0, x20, #0x70
    6da0:	f9404818 	ldr	x24, [x0, #144]
    6da4:	f9407419 	ldr	x25, [x0, #232]
    6da8:	eb18033f 	cmp	x25, x24
    6dac:	540071aa 	b.ge	7be0 <f12+0xf80>  // b.tcont
    6db0:	f9403a81 	ldr	x1, [x20, #112]
    6db4:	8b190720 	add	x0, x25, x25, lsl #1
    6db8:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6dbc:	8b000b20 	add	x0, x25, x0, lsl #2
    6dc0:	8b000c20 	add	x0, x1, x0, lsl #3
    6dc4:	d503201f 	nop
    6dc8:	b9400401 	ldr	w1, [x0, #4]
    6dcc:	35000081 	cbnz	w1, 6ddc <f12+0x17c>
    6dd0:	b9400001 	ldr	w1, [x0]
    6dd4:	6b02003f 	cmp	w1, w2
    6dd8:	54007049 	b.ls	7be0 <f12+0xf80>  // b.plast
    6ddc:	91000739 	add	x25, x25, #0x1
    6de0:	9101a000 	add	x0, x0, #0x68
    6de4:	eb18033f 	cmp	x25, x24
    6de8:	54ffff01 	b.ne	6dc8 <f12+0x168>  // b.any
    6dec:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6df0:	eb00031f 	cmp	x24, x0
    6df4:	54007f2c 	b.gt	7dd8 <f12+0x1178>
    6df8:	9101c280 	add	x0, x20, #0x70
    6dfc:	f9403a9c 	ldr	x28, [x20, #112]
    6e00:	f9407000 	ldr	x0, [x0, #224]
    6e04:	eb18001f 	cmp	x0, x24
    6e08:	54000161 	b.ne	6e34 <f12+0x1d4>  // b.any
    6e0c:	b5007478 	cbnz	x24, 7c98 <f12+0x1038>
    6e10:	d2800d01 	mov	x1, #0x68                  	// #104
    6e14:	d280003a 	mov	x26, #0x1                   	// #1
    6e18:	aa1c03e0 	mov	x0, x28
    6e1c:	97ffee95 	bl	2870 <realloc@plt>
    6e20:	aa0003fc 	mov	x28, x0
    6e24:	b4006c60 	cbz	x0, 7bb0 <f12+0xf50>
    6e28:	9101c280 	add	x0, x20, #0x70
    6e2c:	f9003a9c 	str	x28, [x20, #112]
    6e30:	f900701a 	str	x26, [x0, #224]
    6e34:	8b180700 	add	x0, x24, x24, lsl #1
    6e38:	9101c281 	add	x1, x20, #0x70
    6e3c:	4f000400 	movi	v0.4s, #0x0
    6e40:	91000702 	add	x2, x24, #0x1
    6e44:	8b000b00 	add	x0, x24, x0, lsl #2
    6e48:	f9004822 	str	x2, [x1, #144]
    6e4c:	8b000f80 	add	x0, x28, x0, lsl #3
    6e50:	f900301f 	str	xzr, [x0, #96]
    6e54:	ad000000 	stp	q0, q0, [x0]
    6e58:	ad010000 	stp	q0, q0, [x0, #32]
    6e5c:	ad020000 	stp	q0, q0, [x0, #64]
    6e60:	8b190721 	add	x1, x25, x25, lsl #1
    6e64:	b0000020 	adrp	x0, b000 <__divti3+0x100>
    6e68:	91244000 	add	x0, x0, #0x910
    6e6c:	8b010b38 	add	x24, x25, x1, lsl #2
    6e70:	8b180f98 	add	x24, x28, x24, lsl #3
    6e74:	f900331f 	str	xzr, [x24, #96]
    6e78:	97ffeee6 	bl	2a10 <getenv@plt>
    6e7c:	b4000080 	cbz	x0, 6e8c <f12+0x22c>
    6e80:	39400001 	ldrb	w1, [x0]
    6e84:	7100c03f 	cmp	w1, #0x30
    6e88:	540030a0 	b.eq	749c <f12+0x83c>  // b.none
    6e8c:	9101c280 	add	x0, x20, #0x70
    6e90:	f9406801 	ldr	x1, [x0, #208]
    6e94:	b5006e41 	cbnz	x1, 7c5c <f12+0xffc>
    6e98:	9101c281 	add	x1, x20, #0x70
    6e9c:	2f000400 	mvni	v0.2s, #0x0
    6ea0:	b9400302 	ldr	w2, [x24]
    6ea4:	52800024 	mov	w4, #0x1                   	// #1
    6ea8:	91000723 	add	x3, x25, #0x1
    6eac:	a900df17 	stp	x23, x23, [x24, #8]
    6eb0:	0b040042 	add	w2, w2, w4
    6eb4:	f9418820 	ldr	x0, [x1, #784]
    6eb8:	29001302 	stp	w2, w4, [x24]
    6ebc:	f9002b1f 	str	xzr, [x24, #80]
    6ec0:	f9007423 	str	x3, [x1, #232]
    6ec4:	fd002f00 	str	d0, [x24, #88]
    6ec8:	b40078e0 	cbz	x0, 7de4 <f12+0x1184>
    6ecc:	910382d6 	add	x22, x22, #0xe0
    6ed0:	14000003 	b	6edc <f12+0x27c>
    6ed4:	f9400000 	ldr	x0, [x0]
    6ed8:	b4007860 	cbz	x0, 7de4 <f12+0x1184>
    6edc:	f9400401 	ldr	x1, [x0, #8]
    6ee0:	eb16003f 	cmp	x1, x22
    6ee4:	54ffff81 	b.ne	6ed4 <f12+0x274>  // b.any
    6ee8:	f9400800 	ldr	x0, [x0, #16]
    6eec:	2a1903e4 	mov	w4, w25
    6ef0:	b9400001 	ldr	w1, [x0]
    6ef4:	f9002b00 	str	x0, [x24, #80]
    6ef8:	b9005f01 	str	w1, [x24, #92]
    6efc:	37f80081 	tbnz	w1, #31, 6f0c <f12+0x2ac>
    6f00:	52800d05 	mov	w5, #0x68                  	// #104
    6f04:	9b257021 	smaddl	x1, w1, w5, x28
    6f08:	b9005839 	str	w25, [x1, #88]
    6f0c:	d3707c42 	ubfiz	x2, x2, #16, #32
    6f10:	b9000004 	str	w4, [x0]
    6f14:	aa030057 	orr	x23, x2, x3
    6f18:	52800020 	mov	w0, #0x1                   	// #1
    6f1c:	97fff1b5 	bl	35f0 <descent_phase_step>
    6f20:	aa1503e0 	mov	x0, x21
    6f24:	d2800002 	mov	x2, #0x0                   	// #0
    6f28:	b4006155 	cbz	x21, 7b50 <f12+0xef0>
    6f2c:	d503201f 	nop
    6f30:	f9400800 	ldr	x0, [x0, #16]
    6f34:	91000442 	add	x2, x2, #0x1
    6f38:	b5ffffc0 	cbnz	x0, 6f30 <f12+0x2d0>
    6f3c:	aa1503e1 	mov	x1, x21
    6f40:	f9400821 	ldr	x1, [x1, #16]
    6f44:	91000400 	add	x0, x0, #0x1
    6f48:	b5ffffc1 	cbnz	x1, 6f40 <f12+0x2e0>
    6f4c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6f50:	eb01001f 	cmp	x0, x1
    6f54:	540074e8 	b.hi	7df0 <f12+0x1190>  // b.pmore
    6f58:	f100005f 	cmp	x2, #0x0
    6f5c:	54005fad 	b.le	7b50 <f12+0xef0>
    6f60:	eb00005f 	cmp	x2, x0
    6f64:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6f68:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    6f6c:	eb0102df 	cmp	x22, x1
    6f70:	54007408 	b.hi	7df0 <f12+0x1190>  // b.pmore
    6f74:	d37ffad9 	lsl	x25, x22, #1
    6f78:	52800041 	mov	w1, #0x2                   	// #2
    6f7c:	91000720 	add	x0, x25, #0x1
    6f80:	d37df000 	lsl	x0, x0, #3
    6f84:	97fff7db 	bl	4ef0 <fwp_heap_alloc>
    6f88:	aa0003f8 	mov	x24, x0
    6f8c:	91174261 	add	x1, x19, #0x5d0
    6f90:	aa0103e0 	mov	x0, x1
    6f94:	f9000319 	str	x25, [x24]
    6f98:	f949d821 	ldr	x1, [x1, #5040]
    6f9c:	f949ec00 	ldr	x0, [x0, #5080]
    6fa0:	cb010301 	sub	x1, x24, x1
    6fa4:	eb00403f 	cmp	x1, x0, lsl #16
    6fa8:	54006242 	b.cs	7bf0 <f12+0xf90>  // b.hs, b.nlast
    6fac:	91174262 	add	x2, x19, #0x5d0
    6fb0:	d350fc20 	lsr	x0, x1, #16
    6fb4:	8b000800 	add	x0, x0, x0, lsl #2
    6fb8:	f949fc43 	ldr	x3, [x2, #5112]
    6fbc:	d37df002 	lsl	x2, x0, #3
    6fc0:	8b020060 	add	x0, x3, x2
    6fc4:	f9401019 	ldr	x25, [x0, #32]
    6fc8:	b4000259 	cbz	x25, 7010 <f12+0x3b0>
    6fcc:	38626862 	ldrb	w2, [x3, x2]
    6fd0:	7100085f 	cmp	w2, #0x2
    6fd4:	54006220 	b.eq	7c18 <f12+0xfb8>  // b.none
    6fd8:	7100045f 	cmp	w2, #0x1
    6fdc:	540001a1 	b.ne	7010 <f12+0x3b0>  // b.any
    6fe0:	29430002 	ldp	w2, w0, [x0, #24]
    6fe4:	92403c21 	and	x1, x1, #0xffff
    6fe8:	9b027c21 	mul	x1, x1, x2
    6fec:	d360fc21 	lsr	x1, x1, #32
    6ff0:	eb00003f 	cmp	x1, x0
    6ff4:	540000e2 	b.cs	7010 <f12+0x3b0>  // b.hs, b.nlast
    6ff8:	8b010339 	add	x25, x25, x1
    6ffc:	39400320 	ldrb	w0, [x25]
    7000:	7103fc1f 	cmp	w0, #0xff
    7004:	54006920 	b.eq	7d28 <f12+0x10c8>  // b.none
    7008:	52800020 	mov	w0, #0x1                   	// #1
    700c:	39000320 	strb	w0, [x25]
    7010:	b4000236 	cbz	x22, 7054 <f12+0x3f4>
    7014:	d3607ee4 	lsl	x4, x23, #32
    7018:	aa1503e2 	mov	x2, x21
    701c:	f94006a5 	ldr	x5, [x21, #8]
    7020:	aa0403e3 	mov	x3, x4
    7024:	91002300 	add	x0, x24, #0x8
    7028:	d2800001 	mov	x1, #0x0                   	// #0
    702c:	14000005 	b	7040 <f12+0x3e0>
    7030:	f9400445 	ldr	x5, [x2, #8]
    7034:	ab040023 	adds	x3, x1, x4
    7038:	91004000 	add	x0, x0, #0x10
    703c:	54006f06 	b.vs	7e1c <f12+0x11bc>
    7040:	a9000c05 	stp	x5, x3, [x0]
    7044:	91000421 	add	x1, x1, #0x1
    7048:	f9400842 	ldr	x2, [x2, #16]
    704c:	eb0102df 	cmp	x22, x1
    7050:	54ffff08 	b.hi	7030 <f12+0x3d0>  // b.pmore
    7054:	f9400300 	ldr	x0, [x24]
    7058:	f100041f 	cmp	x0, #0x1
    705c:	54005cc9 	b.ls	7bf4 <f12+0xf94>  // b.plast
    7060:	d341fc00 	lsr	x0, x0, #1
    7064:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7068:	d1000401 	sub	x1, x0, #0x1
    706c:	eb02003f 	cmp	x1, x2
    7070:	54006c08 	b.hi	7df0 <f12+0x1190>  // b.pmore
    7074:	d37ff83c 	lsl	x28, x1, #1
    7078:	b4005be1 	cbz	x1, 7bf4 <f12+0xf94>
    707c:	d1002301 	sub	x1, x24, #0x8
    7080:	91002316 	add	x22, x24, #0x8
    7084:	8b001039 	add	x25, x1, x0, lsl #4
    7088:	f94006c0 	ldr	x0, [x22, #8]
    708c:	f9400ec1 	ldr	x1, [x22, #24]
    7090:	fd4002c0 	ldr	d0, [x22]
    7094:	fd400ac1 	ldr	d1, [x22, #16]
    7098:	97fff946 	bl	55b0 <w107>
    709c:	a90006c0 	stp	x0, x1, [x22]
    70a0:	910042d6 	add	x22, x22, #0x10
    70a4:	eb1902df 	cmp	x22, x25
    70a8:	54ffff01 	b.ne	7088 <f12+0x428>  // b.any
    70ac:	f900031c 	str	x28, [x24]
    70b0:	aa1803e0 	mov	x0, x24
    70b4:	93407efb 	sxtw	x27, w23
    70b8:	97fff99b 	bl	5724 <w164.constprop.0>
    70bc:	aa1803e0 	mov	x0, x24
    70c0:	aa0103f8 	mov	x24, x1
    70c4:	97fffe47 	bl	69e0 <fwp_drop4>
    70c8:	52800040 	mov	w0, #0x2                   	// #2
    70cc:	97fff149 	bl	35f0 <descent_phase_step>
    70d0:	aa1b03e0 	mov	x0, x27
    70d4:	97fff297 	bl	3b30 <fwp_tape_of>
    70d8:	f9403002 	ldr	x2, [x0, #96]
    70dc:	aa0003e8 	mov	x8, x0
    70e0:	b5006702 	cbnz	x2, 7dc0 <f12+0x1160>
    70e4:	97ffefab 	bl	2f90 <fwp_tape_unlink_scope>
    70e8:	b900051f 	str	wzr, [x8, #4]
    70ec:	a9428517 	ldp	x23, x1, [x8, #40]
    70f0:	f90007e1 	str	x1, [sp, #8]
    70f4:	b9400103 	ldr	w3, [x8]
    70f8:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    70fc:	a9409d1c 	ldp	x28, x7, [x8, #8]
    7100:	a941d90a 	ldp	x10, x22, [x8, #24]
    7104:	a943e919 	ldp	x25, x26, [x8, #56]
    7108:	f9402502 	ldr	x2, [x8, #72]
    710c:	6b00007f 	cmp	w3, w0
    7110:	54000108 	b.hi	7130 <f12+0x4d0>  // b.pmore
    7114:	9101c283 	add	x3, x20, #0x70
    7118:	92403f60 	and	x0, x27, #0xffff
    711c:	d1000400 	sub	x0, x0, #0x1
    7120:	f9407469 	ldr	x9, [x3, #232]
    7124:	eb09001f 	cmp	x0, x9
    7128:	5400004a 	b.ge	7130 <f12+0x4d0>  // b.tcont
    712c:	f9007460 	str	x0, [x3, #232]
    7130:	4f000400 	movi	v0.4s, #0x0
    7134:	9101c289 	add	x9, x20, #0x70
    7138:	9101c3e1 	add	x1, sp, #0x70
    713c:	f9000d1f 	str	xzr, [x8, #24]
    7140:	f90013e1 	str	x1, [sp, #32]
    7144:	910163e0 	add	x0, sp, #0x58
    7148:	f941892b 	ldr	x11, [x9, #784]
    714c:	3c808100 	stur	q0, [x8, #8]
    7150:	b0ffffe3 	adrp	x3, 4000 <fwp_heap_report+0x60>
    7154:	ad010100 	stp	q0, q0, [x8, #32]
    7158:	910e0063 	add	x3, x3, #0x380
    715c:	a906dbe1 	stp	x1, x22, [sp, #104]
    7160:	f94007e1 	ldr	x1, [sp, #8]
    7164:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    7168:	a9058feb 	stp	x11, x3, [sp, #88]
    716c:	f9003ff7 	str	x23, [sp, #120]
    7170:	f90043e1 	str	x1, [sp, #128]
    7174:	a908ebf9 	stp	x25, x26, [sp, #136]
    7178:	a9098bea 	stp	x10, x2, [sp, #152]
    717c:	f9018920 	str	x0, [x9, #784]
    7180:	b7f85658 	tbnz	x24, #63, 7c48 <f12+0xfe8>
    7184:	eb98837f 	cmp	x27, x24, asr #32
    7188:	540060e1 	b.ne	7da4 <f12+0x1144>  // b.any
    718c:	92407f03 	and	x3, x24, #0xffffffff
    7190:	eb3840ff 	cmp	x7, w24, uxtw
    7194:	540060ed 	b.le	7db0 <f12+0x1150>
    7198:	eb1c007f 	cmp	x3, x28
    719c:	9a83b79b 	csinc	x27, x28, x3, lt	// lt = tstop
    71a0:	eb1b005f 	cmp	x2, x27
    71a4:	54004f6a 	b.ge	7b90 <f12+0xf30>  // b.tcont
    71a8:	f100005f 	cmp	x2, #0x0
    71ac:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    71b0:	9a9b1042 	csel	x2, x2, x27, ne	// ne = any
    71b4:	14000004 	b	71c4 <f12+0x564>
    71b8:	eb01005f 	cmp	x2, x1
    71bc:	d37ff842 	lsl	x2, x2, #1
    71c0:	9a9bd042 	csel	x2, x2, x27, le
    71c4:	eb1b005f 	cmp	x2, x27
    71c8:	54ffff8b 	b.lt	71b8 <f12+0x558>  // b.tstop
    71cc:	b40058ba 	cbz	x26, 7ce0 <f12+0x1080>
    71d0:	aa1a03e0 	mov	x0, x26
    71d4:	d37df041 	lsl	x1, x2, #3
    71d8:	f90017e2 	str	x2, [sp, #40]
    71dc:	97ffeda5 	bl	2870 <realloc@plt>
    71e0:	f94017e2 	ldr	x2, [sp, #40]
    71e4:	aa0003fa 	mov	x26, x0
    71e8:	b4004d5a 	cbz	x26, 7b90 <f12+0xf30>
    71ec:	f9004bfa 	str	x26, [sp, #144]
    71f0:	f90053e2 	str	x2, [sp, #160]
    71f4:	b50015bb 	cbnz	x27, 74a8 <f12+0x848>
    71f8:	b7f800d8 	tbnz	x24, #63, 7210 <f12+0x5b0>
    71fc:	92407f04 	and	x4, x24, #0xffffffff
    7200:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7204:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    7208:	1e612800 	fadd	d0, d0, d1
    720c:	fc247b40 	str	d0, [x26, x4, lsl #3]
    7210:	9101c281 	add	x1, x20, #0x70
    7214:	cb1c0364 	sub	x4, x27, x28
    7218:	52800060 	mov	w0, #0x3                   	// #3
    721c:	a9428827 	ldp	x7, x2, [x1, #40]
    7220:	8b070084 	add	x4, x4, x7
    7224:	8b1c0042 	add	x2, x2, x28
    7228:	a9028824 	stp	x4, x2, [x1, #40]
    722c:	97fff0f1 	bl	35f0 <descent_phase_step>
    7230:	d1000763 	sub	x3, x27, #0x1
    7234:	d1000784 	sub	x4, x28, #0x1
    7238:	eb03039f 	cmp	x28, x3
    723c:	540003cc 	b.gt	72b4 <f12+0x654>
    7240:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    7244:	1e602008 	fcmp	d0, #0.0
    7248:	54000300 	b.eq	72a8 <f12+0x648>  // b.none
    724c:	cb1c0be0 	neg	x0, x28, lsl #2
    7250:	cb1c03e2 	neg	x2, x28
    7254:	8b0002c1 	add	x1, x22, x0
    7258:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    725c:	37f80121 	tbnz	w1, #31, 7280 <f12+0x620>
    7260:	f94007e5 	ldr	x5, [sp, #8]
    7264:	93407c21 	sxtw	x1, w1
    7268:	8b020ca7 	add	x7, x5, x2, lsl #3
    726c:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    7270:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    7274:	1e620802 	fmul	d2, d0, d2
    7278:	1e622821 	fadd	d1, d1, d2
    727c:	fc217b41 	str	d1, [x26, x1, lsl #3]
    7280:	8b0002e0 	add	x0, x23, x0
    7284:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    7288:	37f80100 	tbnz	w0, #31, 72a8 <f12+0x648>
    728c:	8b020f22 	add	x2, x25, x2, lsl #3
    7290:	93407c00 	sxtw	x0, w0
    7294:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    7298:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    729c:	1e620800 	fmul	d0, d0, d2
    72a0:	1e602820 	fadd	d0, d1, d0
    72a4:	fc207b40 	str	d0, [x26, x0, lsl #3]
    72a8:	d1000463 	sub	x3, x3, #0x1
    72ac:	eb04007f 	cmp	x3, x4
    72b0:	54fffc81 	b.ne	7240 <f12+0x5e0>  // b.any
    72b4:	52800080 	mov	w0, #0x4                   	// #4
    72b8:	97fff0ce 	bl	35f0 <descent_phase_step>
    72bc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    72c0:	eb00039f 	cmp	x28, x0
    72c4:	540059e8 	b.hi	7e00 <f12+0x11a0>  // b.pmore
    72c8:	91000780 	add	x0, x28, #0x1
    72cc:	52800041 	mov	w1, #0x2                   	// #2
    72d0:	d37df000 	lsl	x0, x0, #3
    72d4:	97fff707 	bl	4ef0 <fwp_heap_alloc>
    72d8:	aa0003e2 	mov	x2, x0
    72dc:	aa0003f6 	mov	x22, x0
    72e0:	d2800001 	mov	x1, #0x0                   	// #0
    72e4:	f800845c 	str	x28, [x2], #8
    72e8:	b40000fc 	cbz	x28, 7304 <f12+0x6a4>
    72ec:	d503201f 	nop
    72f0:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    72f4:	f8217840 	str	x0, [x2, x1, lsl #3]
    72f8:	91000421 	add	x1, x1, #0x1
    72fc:	eb01039f 	cmp	x28, x1
    7300:	54ffff81 	b.ne	72f0 <f12+0x690>  // b.any
    7304:	528000a0 	mov	w0, #0x5                   	// #5
    7308:	97fff0ba 	bl	35f0 <descent_phase_step>
    730c:	f94013e0 	ldr	x0, [sp, #32]
    7310:	9101c281 	add	x1, x20, #0x70
    7314:	f9402ff8 	ldr	x24, [sp, #88]
    7318:	f9018838 	str	x24, [x1, #784]
    731c:	97fff419 	bl	4380 <fwp_tape_buffers_release>
    7320:	528000c0 	mov	w0, #0x6                   	// #6
    7324:	97fff0b3 	bl	35f0 <descent_phase_step>
    7328:	91174262 	add	x2, x19, #0x5d0
    732c:	f949d841 	ldr	x1, [x2, #5040]
    7330:	f949ec40 	ldr	x0, [x2, #5080]
    7334:	cb0102c1 	sub	x1, x22, x1
    7338:	eb00403f 	cmp	x1, x0, lsl #16
    733c:	54000322 	b.cs	73a0 <f12+0x740>  // b.hs, b.nlast
    7340:	d350fc20 	lsr	x0, x1, #16
    7344:	f949fc43 	ldr	x3, [x2, #5112]
    7348:	8b000800 	add	x0, x0, x0, lsl #2
    734c:	d37df002 	lsl	x2, x0, #3
    7350:	8b020060 	add	x0, x3, x2
    7354:	f9401017 	ldr	x23, [x0, #32]
    7358:	b4000257 	cbz	x23, 73a0 <f12+0x740>
    735c:	38626862 	ldrb	w2, [x3, x2]
    7360:	7100085f 	cmp	w2, #0x2
    7364:	54004760 	b.eq	7c50 <f12+0xff0>  // b.none
    7368:	7100045f 	cmp	w2, #0x1
    736c:	540001a1 	b.ne	73a0 <f12+0x740>  // b.any
    7370:	29430002 	ldp	w2, w0, [x0, #24]
    7374:	92403c21 	and	x1, x1, #0xffff
    7378:	9b027c21 	mul	x1, x1, x2
    737c:	d360fc21 	lsr	x1, x1, #32
    7380:	eb00003f 	cmp	x1, x0
    7384:	540000e2 	b.cs	73a0 <f12+0x740>  // b.hs, b.nlast
    7388:	8b0102f7 	add	x23, x23, x1
    738c:	394002e0 	ldrb	w0, [x23]
    7390:	7103fc1f 	cmp	w0, #0xff
    7394:	54004d00 	b.eq	7d34 <f12+0x10d4>  // b.none
    7398:	52800020 	mov	w0, #0x1                   	// #1
    739c:	390002e0 	strb	w0, [x23]
    73a0:	f9400fe0 	ldr	x0, [sp, #24]
    73a4:	eb00031f 	cmp	x24, x0
    73a8:	54005381 	b.ne	7e18 <f12+0x11b8>  // b.any
    73ac:	f9400be0 	ldr	x0, [sp, #16]
    73b0:	9101c294 	add	x20, x20, #0x70
    73b4:	f94023e1 	ldr	x1, [sp, #64]
    73b8:	f9018a81 	str	x1, [x20, #784]
    73bc:	97fffb49 	bl	60e0 <fwp_tape_scope_release>
    73c0:	f94002c0 	ldr	x0, [x22]
    73c4:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    73c8:	b7f83700 	tbnz	x0, #63, 7aa8 <f12+0xe48>
    73cc:	91174262 	add	x2, x19, #0x5d0
    73d0:	f949d840 	ldr	x0, [x2, #5040]
    73d4:	f949ec41 	ldr	x1, [x2, #5080]
    73d8:	cb0002c0 	sub	x0, x22, x0
    73dc:	eb01401f 	cmp	x0, x1, lsl #16
    73e0:	54003642 	b.cs	7aa8 <f12+0xe48>  // b.hs, b.nlast
    73e4:	d350fc01 	lsr	x1, x0, #16
    73e8:	f949fc44 	ldr	x4, [x2, #5112]
    73ec:	8b010821 	add	x1, x1, x1, lsl #2
    73f0:	d37df021 	lsl	x1, x1, #3
    73f4:	8b010083 	add	x3, x4, x1
    73f8:	f9401062 	ldr	x2, [x3, #32]
    73fc:	b4003562 	cbz	x2, 7aa8 <f12+0xe48>
    7400:	38616881 	ldrb	w1, [x4, x1]
    7404:	7100083f 	cmp	w1, #0x2
    7408:	540034a0 	b.eq	7a9c <f12+0xe3c>  // b.none
    740c:	7100043f 	cmp	w1, #0x1
    7410:	540034c1 	b.ne	7aa8 <f12+0xe48>  // b.any
    7414:	29430464 	ldp	w4, w1, [x3, #24]
    7418:	92403c00 	and	x0, x0, #0xffff
    741c:	9b047c00 	mul	x0, x0, x4
    7420:	d360fc00 	lsr	x0, x0, #32
    7424:	eb01001f 	cmp	x0, x1
    7428:	54003402 	b.cs	7aa8 <f12+0xe48>  // b.hs, b.nlast
    742c:	8b000042 	add	x2, x2, x0
    7430:	39400040 	ldrb	w0, [x2]
    7434:	7100041f 	cmp	w0, #0x1
    7438:	54003381 	b.ne	7aa8 <f12+0xe48>  // b.any
    743c:	aa1603fa 	mov	x26, x22
    7440:	d2800000 	mov	x0, #0x0                   	// #0
    7444:	f9000ff6 	str	x22, [sp, #24]
    7448:	f9400fe1 	ldr	x1, [sp, #24]
    744c:	91002023 	add	x3, x1, #0x8
    7450:	d2800001 	mov	x1, #0x0                   	// #0
    7454:	b4000357 	cbz	x23, 74bc <f12+0x85c>
    7458:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0x9e0>
    745c:	910022c5 	add	x5, x22, #0x8
    7460:	fd420c41 	ldr	d1, [x2, #1048]
    7464:	14000009 	b	7488 <f12+0x828>
    7468:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    746c:	f9400342 	ldr	x2, [x26]
    7470:	1e600820 	fmul	d0, d1, d0
    7474:	b7f84cc2 	tbnz	x2, #63, 7e0c <f12+0x11ac>
    7478:	91000421 	add	x1, x1, #0x1
    747c:	fc008460 	str	d0, [x3], #8
    7480:	eb0102ff 	cmp	x23, x1
    7484:	540001c0 	b.eq	74bc <f12+0x85c>  // b.none
    7488:	f94002c4 	ldr	x4, [x22]
    748c:	aa0503e2 	mov	x2, x5
    7490:	b6fffec4 	tbz	x4, #63, 7468 <f12+0x808>
    7494:	f9400ac2 	ldr	x2, [x22, #16]
    7498:	17fffff4 	b	7468 <f12+0x808>
    749c:	39400400 	ldrb	w0, [x0, #1]
    74a0:	34ffcfc0 	cbz	w0, 6e98 <f12+0x238>
    74a4:	17fffe7a 	b	6e8c <f12+0x22c>
    74a8:	d37df362 	lsl	x2, x27, #3
    74ac:	aa1a03e0 	mov	x0, x26
    74b0:	52800001 	mov	w1, #0x0                   	// #0
    74b4:	97ffece7 	bl	2850 <memset@plt>
    74b8:	17ffff50 	b	71f8 <f12+0x598>
    74bc:	97fffd49 	bl	69e0 <fwp_drop4>
    74c0:	aa1503e1 	mov	x1, x21
    74c4:	d2800002 	mov	x2, #0x0                   	// #0
    74c8:	b40041b5 	cbz	x21, 7cfc <f12+0x109c>
    74cc:	d503201f 	nop
    74d0:	f9400821 	ldr	x1, [x1, #16]
    74d4:	91000442 	add	x2, x2, #0x1
    74d8:	b5ffffc1 	cbnz	x1, 74d0 <f12+0x870>
    74dc:	f9400343 	ldr	x3, [x26]
    74e0:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    74e4:	b7f82a63 	tbnz	x3, #63, 7a30 <f12+0xdd0>
    74e8:	91174261 	add	x1, x19, #0x5d0
    74ec:	f9400fe4 	ldr	x4, [sp, #24]
    74f0:	f949d820 	ldr	x0, [x1, #5040]
    74f4:	f949ec21 	ldr	x1, [x1, #5080]
    74f8:	cb000080 	sub	x0, x4, x0
    74fc:	eb01401f 	cmp	x0, x1, lsl #16
    7500:	54002982 	b.cs	7a30 <f12+0xdd0>  // b.hs, b.nlast
    7504:	91174264 	add	x4, x19, #0x5d0
    7508:	d350fc01 	lsr	x1, x0, #16
    750c:	8b010821 	add	x1, x1, x1, lsl #2
    7510:	f949fc86 	ldr	x6, [x4, #5112]
    7514:	d37df021 	lsl	x1, x1, #3
    7518:	8b0100c5 	add	x5, x6, x1
    751c:	f94010a4 	ldr	x4, [x5, #32]
    7520:	b4002864 	cbz	x4, 7a2c <f12+0xdcc>
    7524:	386168c1 	ldrb	w1, [x6, x1]
    7528:	7100083f 	cmp	w1, #0x2
    752c:	540027c0 	b.eq	7a24 <f12+0xdc4>  // b.none
    7530:	7100043f 	cmp	w1, #0x1
    7534:	540027c1 	b.ne	7a2c <f12+0xdcc>  // b.any
    7538:	294304a6 	ldp	w6, w1, [x5, #24]
    753c:	92403c00 	and	x0, x0, #0xffff
    7540:	9b067c00 	mul	x0, x0, x6
    7544:	d360fc00 	lsr	x0, x0, #32
    7548:	eb01001f 	cmp	x0, x1
    754c:	54002702 	b.cs	7a2c <f12+0xdcc>  // b.hs, b.nlast
    7550:	8b000084 	add	x4, x4, x0
    7554:	39400096 	ldrb	w22, [x4]
    7558:	710006df 	cmp	w22, #0x1
    755c:	54002681 	b.ne	7a2c <f12+0xdcc>  // b.any
    7560:	b90023f6 	str	w22, [sp, #32]
    7564:	eb17005f 	cmp	x2, x23
    7568:	9a979057 	csel	x23, x2, x23, ls	// ls = plast
    756c:	91002359 	add	x25, x26, #0x8
    7570:	b4003f77 	cbz	x23, 7d5c <f12+0x10fc>
    7574:	f9400fe0 	ldr	x0, [sp, #24]
    7578:	d37df2e5 	lsl	x5, x23, #3
    757c:	aa1503e2 	mov	x2, x21
    7580:	d2800001 	mov	x1, #0x0                   	// #0
    7584:	91002000 	add	x0, x0, #0x8
    7588:	1400000a 	b	75b0 <f12+0x950>
    758c:	fc616881 	ldr	d1, [x4, x1]
    7590:	fd400440 	ldr	d0, [x2, #8]
    7594:	1e613800 	fsub	d0, d0, d1
    7598:	fc216b20 	str	d0, [x25, x1]
    759c:	91002021 	add	x1, x1, #0x8
    75a0:	f9400842 	ldr	x2, [x2, #16]
    75a4:	eb05003f 	cmp	x1, x5
    75a8:	540001c0 	b.eq	75e0 <f12+0x980>  // b.none
    75ac:	f9400343 	ldr	x3, [x26]
    75b0:	aa0003e4 	mov	x4, x0
    75b4:	b6fffec3 	tbz	x3, #63, 758c <f12+0x92c>
    75b8:	f9400fe3 	ldr	x3, [sp, #24]
    75bc:	fd400440 	ldr	d0, [x2, #8]
    75c0:	f9400864 	ldr	x4, [x3, #16]
    75c4:	fc616881 	ldr	d1, [x4, x1]
    75c8:	1e613800 	fsub	d0, d0, d1
    75cc:	fc216b20 	str	d0, [x25, x1]
    75d0:	91002021 	add	x1, x1, #0x8
    75d4:	f9400842 	ldr	x2, [x2, #16]
    75d8:	eb05003f 	cmp	x1, x5
    75dc:	54fffe81 	b.ne	75ac <f12+0x94c>  // b.any
    75e0:	b4003bb5 	cbz	x21, 7d54 <f12+0x10f4>
    75e4:	91174260 	add	x0, x19, #0x5d0
    75e8:	aa1503e2 	mov	x2, x21
    75ec:	d280001b 	mov	x27, #0x0                   	// #0
    75f0:	f949ec06 	ldr	x6, [x0, #5080]
    75f4:	f949d807 	ldr	x7, [x0, #5040]
    75f8:	f949fc05 	ldr	x5, [x0, #5112]
    75fc:	d370bcc6 	lsl	x6, x6, #16
    7600:	14000006 	b	7618 <f12+0x9b8>
    7604:	f9400842 	ldr	x2, [x2, #16]
    7608:	9100077b 	add	x27, x27, #0x1
    760c:	f100005f 	cmp	x2, #0x0
    7610:	fa571362 	ccmp	x27, x23, #0x2, ne	// ne = any
    7614:	54000322 	b.cs	7678 <f12+0xa18>  // b.hs, b.nlast
    7618:	cb070040 	sub	x0, x2, x7
    761c:	eb06001f 	cmp	x0, x6
    7620:	540002c2 	b.cs	7678 <f12+0xa18>  // b.hs, b.nlast
    7624:	d350fc01 	lsr	x1, x0, #16
    7628:	8b010821 	add	x1, x1, x1, lsl #2
    762c:	d37df021 	lsl	x1, x1, #3
    7630:	8b0100a4 	add	x4, x5, x1
    7634:	f9401083 	ldr	x3, [x4, #32]
    7638:	b4000203 	cbz	x3, 7678 <f12+0xa18>
    763c:	386168a1 	ldrb	w1, [x5, x1]
    7640:	7100083f 	cmp	w1, #0x2
    7644:	54000e00 	b.eq	7804 <f12+0xba4>  // b.none
    7648:	7100043f 	cmp	w1, #0x1
    764c:	54000161 	b.ne	7678 <f12+0xa18>  // b.any
    7650:	29430488 	ldp	w8, w1, [x4, #24]
    7654:	92403c00 	and	x0, x0, #0xffff
    7658:	9b087c00 	mul	x0, x0, x8
    765c:	d360fc00 	lsr	x0, x0, #32
    7660:	eb01001f 	cmp	x0, x1
    7664:	540000a2 	b.cs	7678 <f12+0xa18>  // b.hs, b.nlast
    7668:	8b000063 	add	x3, x3, x0
    766c:	39400060 	ldrb	w0, [x3]
    7670:	7100041f 	cmp	w0, #0x1
    7674:	54fffc80 	b.eq	7604 <f12+0x9a4>  // b.none
    7678:	d2800018 	mov	x24, #0x0                   	// #0
    767c:	eb17037f 	cmp	x27, x23
    7680:	54000cc2 	b.cs	7818 <f12+0xbb8>  // b.hs, b.nlast
    7684:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    7688:	d1002336 	sub	x22, x25, #0x8
    768c:	9117427a 	add	x26, x19, #0x5d0
    7690:	d2800018 	mov	x24, #0x0                   	// #0
    7694:	fd41f808 	ldr	d8, [x0, #1008]
    7698:	14000042 	b	77a0 <f12+0xb40>
    769c:	f9400381 	ldr	x1, [x28]
    76a0:	aa2103e1 	mvn	x1, x1
    76a4:	f8207b41 	str	x1, [x26, x0, lsl #3]
    76a8:	f100609f 	cmp	x4, #0x18
    76ac:	54000169 	b.ls	76d8 <f12+0xa78>  // b.plast
    76b0:	d1006482 	sub	x2, x4, #0x19
    76b4:	91006380 	add	x0, x28, #0x18
    76b8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    76bc:	52800001 	mov	w1, #0x0                   	// #0
    76c0:	91002042 	add	x2, x2, #0x8
    76c4:	f90007e4 	str	x4, [sp, #8]
    76c8:	b90013e5 	str	w5, [sp, #16]
    76cc:	97ffec61 	bl	2850 <memset@plt>
    76d0:	f94007e4 	ldr	x4, [sp, #8]
    76d4:	b94013e5 	ldr	w5, [sp, #16]
    76d8:	91174262 	add	x2, x19, #0x5d0
    76dc:	f94a1041 	ldr	x1, [x2, #5152]
    76e0:	ab040021 	adds	x1, x1, x4
    76e4:	540036c2 	b.cs	7dbc <f12+0x115c>  // b.hs, b.nlast
    76e8:	f94a1440 	ldr	x0, [x2, #5160]
    76ec:	f90a1041 	str	x1, [x2, #5152]
    76f0:	eb00003f 	cmp	x1, x0
    76f4:	54000049 	b.ls	76fc <f12+0xa9c>  // b.plast
    76f8:	f90a1441 	str	x1, [x2, #5160]
    76fc:	91174260 	add	x0, x19, #0x5d0
    7700:	1e6300a1 	ucvtf	d1, w5
    7704:	fd4a1c00 	ldr	d0, [x0, #5176]
    7708:	1e612800 	fadd	d0, d0, d1
    770c:	fd0a1c00 	str	d0, [x0, #5176]
    7710:	a900e394 	stp	x20, x24, [x28, #8]
    7714:	aa1c03f8 	mov	x24, x28
    7718:	fd000388 	str	d8, [x28]
    771c:	f949db41 	ldr	x1, [x26, #5040]
    7720:	f949ef40 	ldr	x0, [x26, #5080]
    7724:	cb010381 	sub	x1, x28, x1
    7728:	eb00403f 	cmp	x1, x0, lsl #16
    772c:	54000322 	b.cs	7790 <f12+0xb30>  // b.hs, b.nlast
    7730:	d350fc22 	lsr	x2, x1, #16
    7734:	f949ff44 	ldr	x4, [x26, #5112]
    7738:	8b020842 	add	x2, x2, x2, lsl #2
    773c:	d37df042 	lsl	x2, x2, #3
    7740:	8b020080 	add	x0, x4, x2
    7744:	f940101c 	ldr	x28, [x0, #32]
    7748:	b400025c 	cbz	x28, 7790 <f12+0xb30>
    774c:	38626882 	ldrb	w2, [x4, x2]
    7750:	7100085f 	cmp	w2, #0x2
    7754:	54000b00 	b.eq	78b4 <f12+0xc54>  // b.none
    7758:	7100045f 	cmp	w2, #0x1
    775c:	540001a1 	b.ne	7790 <f12+0xb30>  // b.any
    7760:	29430002 	ldp	w2, w0, [x0, #24]
    7764:	92403c21 	and	x1, x1, #0xffff
    7768:	9b027c21 	mul	x1, x1, x2
    776c:	d360fc21 	lsr	x1, x1, #32
    7770:	eb00003f 	cmp	x1, x0
    7774:	540000e2 	b.cs	7790 <f12+0xb30>  // b.hs, b.nlast
    7778:	8b01039c 	add	x28, x28, x1
    777c:	39400380 	ldrb	w0, [x28]
    7780:	7103fc1f 	cmp	w0, #0xff
    7784:	54002000 	b.eq	7b84 <f12+0xf24>  // b.none
    7788:	52800020 	mov	w0, #0x1                   	// #1
    778c:	39000380 	strb	w0, [x28]
    7790:	d10006e0 	sub	x0, x23, #0x1
    7794:	eb00037f 	cmp	x27, x0
    7798:	54000982 	b.cs	78c8 <f12+0xc68>  // b.hs, b.nlast
    779c:	aa0003f7 	mov	x23, x0
    77a0:	b953a740 	ldr	w0, [x26, #5028]
    77a4:	f8777ad4 	ldr	x20, [x22, x23, lsl #3]
    77a8:	34000240 	cbz	w0, 77f0 <f12+0xb90>
    77ac:	397e8b40 	ldrb	w0, [x26, #4002]
    77b0:	910f0001 	add	x1, x0, #0x3c0
    77b4:	8b000400 	add	x0, x0, x0, lsl #1
    77b8:	b8617b45 	ldr	w5, [x26, x1, lsl #2]
    77bc:	8b000f41 	add	x1, x26, x0, lsl #3
    77c0:	f8607b5c 	ldr	x28, [x26, x0, lsl #3]
    77c4:	2a0503e4 	mov	w4, w5
    77c8:	b5fff6bc 	cbnz	x28, 769c <f12+0xa3c>
    77cc:	f940043c 	ldr	x28, [x1, #8]
    77d0:	b400011c 	cbz	x28, 77f0 <f12+0xb90>
    77d4:	f9400820 	ldr	x0, [x1, #16]
    77d8:	cb1c0000 	sub	x0, x0, x28
    77dc:	eb00009f 	cmp	x4, x0
    77e0:	54000088 	b.hi	77f0 <f12+0xb90>  // b.pmore
    77e4:	8b040380 	add	x0, x28, x4
    77e8:	f9000420 	str	x0, [x1, #8]
    77ec:	17ffffaf 	b	76a8 <f12+0xa48>
    77f0:	52800001 	mov	w1, #0x0                   	// #0
    77f4:	d2800300 	mov	x0, #0x18                  	// #24
    77f8:	97fff5be 	bl	4ef0 <fwp_heap_alloc>
    77fc:	aa0003fc 	mov	x28, x0
    7800:	17ffffc4 	b	7710 <f12+0xab0>
    7804:	72003c1f 	tst	w0, #0xffff
    7808:	54fff320 	b.eq	766c <f12+0xa0c>  // b.none
    780c:	d2800018 	mov	x24, #0x0                   	// #0
    7810:	eb17037f 	cmp	x27, x23
    7814:	54fff383 	b.cc	7684 <f12+0xa24>  // b.lo, b.ul, b.last
    7818:	8b1b0f3b 	add	x27, x25, x27, lsl #3
    781c:	aa1903e1 	mov	x1, x25
    7820:	aa1503e0 	mov	x0, x21
    7824:	d503201f 	nop
    7828:	f8408422 	ldr	x2, [x1], #8
    782c:	f9000402 	str	x2, [x0, #8]
    7830:	aa0003e2 	mov	x2, x0
    7834:	f9400800 	ldr	x0, [x0, #16]
    7838:	eb1b003f 	cmp	x1, x27
    783c:	54ffff61 	b.ne	7828 <f12+0xbc8>  // b.any
    7840:	b94023e1 	ldr	w1, [sp, #32]
    7844:	f9000858 	str	x24, [x2, #16]
    7848:	aa1503f8 	mov	x24, x21
    784c:	aa0003f5 	mov	x21, x0
    7850:	34000041 	cbz	w1, 7858 <f12+0xbf8>
    7854:	d2800019 	mov	x25, #0x0                   	// #0
    7858:	aa1903e0 	mov	x0, x25
    785c:	97fff485 	bl	4a70 <fwp_mem_free>
    7860:	f9400fe0 	ldr	x0, [sp, #24]
    7864:	97fffc5f 	bl	69e0 <fwp_drop4>
    7868:	aa1503e0 	mov	x0, x21
    786c:	97fff88d 	bl	5aa0 <fwp_drop0>
    7870:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7874:	f947f400 	ldr	x0, [x0, #4072]
    7878:	f94057e2 	ldr	x2, [sp, #168]
    787c:	f9400001 	ldr	x1, [x0]
    7880:	eb010042 	subs	x2, x2, x1
    7884:	d2800001 	mov	x1, #0x0                   	// #0
    7888:	54002ba1 	b.ne	7dfc <f12+0x119c>  // b.any
    788c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7890:	aa1803e0 	mov	x0, x24
    7894:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7898:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    789c:	a94e63f7 	ldp	x23, x24, [sp, #224]
    78a0:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    78a4:	a95073fb 	ldp	x27, x28, [sp, #256]
    78a8:	fd408be8 	ldr	d8, [sp, #272]
    78ac:	910483ff 	add	sp, sp, #0x120
    78b0:	d65f03c0 	ret
    78b4:	72003c3f 	tst	w1, #0xffff
    78b8:	54fff620 	b.eq	777c <f12+0xb1c>  // b.none
    78bc:	d10006e0 	sub	x0, x23, #0x1
    78c0:	eb00037f 	cmp	x27, x0
    78c4:	54fff6c3 	b.cc	779c <f12+0xb3c>  // b.lo, b.ul, b.last
    78c8:	b5fffa9b 	cbnz	x27, 7818 <f12+0xbb8>
    78cc:	b94023e1 	ldr	w1, [sp, #32]
    78d0:	7100003f 	cmp	w1, #0x0
    78d4:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    78d8:	b4fffc00 	cbz	x0, 7858 <f12+0xbf8>
    78dc:	91174273 	add	x19, x19, #0x5d0
    78e0:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    78e4:	d1000afa 	sub	x26, x23, #0x2
    78e8:	52800034 	mov	w20, #0x1                   	// #1
    78ec:	fd41f808 	ldr	d8, [x0, #1008]
    78f0:	b953a660 	ldr	w0, [x19, #5028]
    78f4:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    78f8:	340008c0 	cbz	w0, 7a10 <f12+0xdb0>
    78fc:	d503201f 	nop
    7900:	397e8a60 	ldrb	w0, [x19, #4002]
    7904:	910f0001 	add	x1, x0, #0x3c0
    7908:	8b000400 	add	x0, x0, x0, lsl #1
    790c:	b8617a7c 	ldr	w28, [x19, x1, lsl #2]
    7910:	8b000e61 	add	x1, x19, x0, lsl #3
    7914:	f8607a76 	ldr	x22, [x19, x0, lsl #3]
    7918:	2a1c03fb 	mov	w27, w28
    791c:	b40022d6 	cbz	x22, 7d74 <f12+0x1114>
    7920:	f94002c1 	ldr	x1, [x22]
    7924:	aa2103e1 	mvn	x1, x1
    7928:	f8207a61 	str	x1, [x19, x0, lsl #3]
    792c:	f100637f 	cmp	x27, #0x18
    7930:	540000e9 	b.ls	794c <f12+0xcec>  // b.plast
    7934:	d1006762 	sub	x2, x27, #0x19
    7938:	910062c0 	add	x0, x22, #0x18
    793c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7940:	52800001 	mov	w1, #0x0                   	// #0
    7944:	91002042 	add	x2, x2, #0x8
    7948:	97ffebc2 	bl	2850 <memset@plt>
    794c:	f94a1260 	ldr	x0, [x19, #5152]
    7950:	ab1b0000 	adds	x0, x0, x27
    7954:	54002342 	b.cs	7dbc <f12+0x115c>  // b.hs, b.nlast
    7958:	f94a1661 	ldr	x1, [x19, #5160]
    795c:	f90a1260 	str	x0, [x19, #5152]
    7960:	eb01001f 	cmp	x0, x1
    7964:	54000049 	b.ls	796c <f12+0xd0c>  // b.plast
    7968:	f90a1660 	str	x0, [x19, #5160]
    796c:	1e630381 	ucvtf	d1, w28
    7970:	fd4a1e60 	ldr	d0, [x19, #5176]
    7974:	1e612800 	fadd	d0, d0, d1
    7978:	fd0a1e60 	str	d0, [x19, #5176]
    797c:	a900e2d7 	stp	x23, x24, [x22, #8]
    7980:	aa1603f8 	mov	x24, x22
    7984:	fd0002c8 	str	d8, [x22]
    7988:	f949da61 	ldr	x1, [x19, #5040]
    798c:	f949ee60 	ldr	x0, [x19, #5080]
    7990:	cb0102c1 	sub	x1, x22, x1
    7994:	eb00403f 	cmp	x1, x0, lsl #16
    7998:	54000302 	b.cs	79f8 <f12+0xd98>  // b.hs, b.nlast
    799c:	d350fc22 	lsr	x2, x1, #16
    79a0:	f949fe63 	ldr	x3, [x19, #5112]
    79a4:	8b020842 	add	x2, x2, x2, lsl #2
    79a8:	d37df042 	lsl	x2, x2, #3
    79ac:	8b020060 	add	x0, x3, x2
    79b0:	f9401016 	ldr	x22, [x0, #32]
    79b4:	b4000236 	cbz	x22, 79f8 <f12+0xd98>
    79b8:	38626862 	ldrb	w2, [x3, x2]
    79bc:	7100085f 	cmp	w2, #0x2
    79c0:	54001ec0 	b.eq	7d98 <f12+0x1138>  // b.none
    79c4:	7100045f 	cmp	w2, #0x1
    79c8:	54000181 	b.ne	79f8 <f12+0xd98>  // b.any
    79cc:	29430002 	ldp	w2, w0, [x0, #24]
    79d0:	92403c21 	and	x1, x1, #0xffff
    79d4:	9b027c21 	mul	x1, x1, x2
    79d8:	d360fc21 	lsr	x1, x1, #32
    79dc:	eb00003f 	cmp	x1, x0
    79e0:	540000c2 	b.cs	79f8 <f12+0xd98>  // b.hs, b.nlast
    79e4:	8b0102d6 	add	x22, x22, x1
    79e8:	394002c0 	ldrb	w0, [x22]
    79ec:	7103fc1f 	cmp	w0, #0xff
    79f0:	54001bc0 	b.eq	7d68 <f12+0x1108>  // b.none
    79f4:	390002d4 	strb	w20, [x22]
    79f8:	d100075a 	sub	x26, x26, #0x1
    79fc:	b100075f 	cmn	x26, #0x1
    7a00:	54fff2c0 	b.eq	7858 <f12+0xbf8>  // b.none
    7a04:	b953a660 	ldr	w0, [x19, #5028]
    7a08:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    7a0c:	35fff7a0 	cbnz	w0, 7900 <f12+0xca0>
    7a10:	52800001 	mov	w1, #0x0                   	// #0
    7a14:	d2800300 	mov	x0, #0x18                  	// #24
    7a18:	97fff536 	bl	4ef0 <fwp_heap_alloc>
    7a1c:	aa0003f6 	mov	x22, x0
    7a20:	17ffffd7 	b	797c <f12+0xd1c>
    7a24:	72003c1f 	tst	w0, #0xffff
    7a28:	54ffd960 	b.eq	7554 <f12+0x8f4>  // b.none
    7a2c:	b4001475 	cbz	x21, 7cb8 <f12+0x1058>
    7a30:	aa1503f6 	mov	x22, x21
    7a34:	d2800018 	mov	x24, #0x0                   	// #0
    7a38:	f9400ad6 	ldr	x22, [x22, #16]
    7a3c:	aa1803e0 	mov	x0, x24
    7a40:	91000718 	add	x24, x24, #0x1
    7a44:	b5ffffb6 	cbnz	x22, 7a38 <f12+0xdd8>
    7a48:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7a4c:	eb01031f 	cmp	x24, x1
    7a50:	54001d08 	b.hi	7df0 <f12+0x1190>  // b.pmore
    7a54:	91000800 	add	x0, x0, #0x2
    7a58:	52800041 	mov	w1, #0x2                   	// #2
    7a5c:	d37df000 	lsl	x0, x0, #3
    7a60:	97fff524 	bl	4ef0 <fwp_heap_alloc>
    7a64:	eb17031f 	cmp	x24, x23
    7a68:	aa0003f9 	mov	x25, x0
    7a6c:	9a979317 	csel	x23, x24, x23, ls	// ls = plast
    7a70:	aa1503e1 	mov	x1, x21
    7a74:	d503201f 	nop
    7a78:	f9400420 	ldr	x0, [x1, #8]
    7a7c:	f8367b20 	str	x0, [x25, x22, lsl #3]
    7a80:	910006d6 	add	x22, x22, #0x1
    7a84:	f9400821 	ldr	x1, [x1, #16]
    7a88:	b5ffff81 	cbnz	x1, 7a78 <f12+0xe18>
    7a8c:	b40011f7 	cbz	x23, 7cc8 <f12+0x1068>
    7a90:	f9400343 	ldr	x3, [x26]
    7a94:	b90023ff 	str	wzr, [sp, #32]
    7a98:	17fffeb7 	b	7574 <f12+0x914>
    7a9c:	72003c1f 	tst	w0, #0xffff
    7aa0:	54ffcc80 	b.eq	7430 <f12+0x7d0>  // b.none
    7aa4:	d503201f 	nop
    7aa8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7aac:	eb0002ff 	cmp	x23, x0
    7ab0:	54001a88 	b.hi	7e00 <f12+0x11a0>  // b.pmore
    7ab4:	910006e0 	add	x0, x23, #0x1
    7ab8:	52800021 	mov	w1, #0x1                   	// #1
    7abc:	d37df000 	lsl	x0, x0, #3
    7ac0:	97fff50c 	bl	4ef0 <fwp_heap_alloc>
    7ac4:	91174262 	add	x2, x19, #0x5d0
    7ac8:	f9000017 	str	x23, [x0]
    7acc:	aa0003fa 	mov	x26, x0
    7ad0:	f9000ffa 	str	x26, [sp, #24]
    7ad4:	f949d841 	ldr	x1, [x2, #5040]
    7ad8:	f949ec40 	ldr	x0, [x2, #5080]
    7adc:	cb010341 	sub	x1, x26, x1
    7ae0:	eb00403f 	cmp	x1, x0, lsl #16
    7ae4:	54000322 	b.cs	7b48 <f12+0xee8>  // b.hs, b.nlast
    7ae8:	d350fc20 	lsr	x0, x1, #16
    7aec:	f949fc43 	ldr	x3, [x2, #5112]
    7af0:	8b000800 	add	x0, x0, x0, lsl #2
    7af4:	d37df002 	lsl	x2, x0, #3
    7af8:	8b020060 	add	x0, x3, x2
    7afc:	f9401018 	ldr	x24, [x0, #32]
    7b00:	b4000258 	cbz	x24, 7b48 <f12+0xee8>
    7b04:	38626862 	ldrb	w2, [x3, x2]
    7b08:	7100085f 	cmp	w2, #0x2
    7b0c:	54000e20 	b.eq	7cd0 <f12+0x1070>  // b.none
    7b10:	7100045f 	cmp	w2, #0x1
    7b14:	540001a1 	b.ne	7b48 <f12+0xee8>  // b.any
    7b18:	29430002 	ldp	w2, w0, [x0, #24]
    7b1c:	92403c21 	and	x1, x1, #0xffff
    7b20:	9b027c21 	mul	x1, x1, x2
    7b24:	d360fc21 	lsr	x1, x1, #32
    7b28:	eb00003f 	cmp	x1, x0
    7b2c:	540000e2 	b.cs	7b48 <f12+0xee8>  // b.hs, b.nlast
    7b30:	8b010318 	add	x24, x24, x1
    7b34:	39400300 	ldrb	w0, [x24]
    7b38:	7103fc1f 	cmp	w0, #0xff
    7b3c:	54001020 	b.eq	7d40 <f12+0x10e0>  // b.none
    7b40:	52800020 	mov	w0, #0x1                   	// #1
    7b44:	39000300 	strb	w0, [x24]
    7b48:	aa1603e0 	mov	x0, x22
    7b4c:	17fffe3f 	b	7448 <f12+0x7e8>
    7b50:	52800041 	mov	w1, #0x2                   	// #2
    7b54:	d2800100 	mov	x0, #0x8                   	// #8
    7b58:	97fff4e6 	bl	4ef0 <fwp_heap_alloc>
    7b5c:	aa0003f8 	mov	x24, x0
    7b60:	91174260 	add	x0, x19, #0x5d0
    7b64:	f900031f 	str	xzr, [x24]
    7b68:	f949d801 	ldr	x1, [x0, #5040]
    7b6c:	f949ec00 	ldr	x0, [x0, #5080]
    7b70:	cb010301 	sub	x1, x24, x1
    7b74:	eb00403f 	cmp	x1, x0, lsl #16
    7b78:	540003e2 	b.cs	7bf4 <f12+0xf94>  // b.hs, b.nlast
    7b7c:	d2800016 	mov	x22, #0x0                   	// #0
    7b80:	17fffd0b 	b	6fac <f12+0x34c>
    7b84:	aa1c03e0 	mov	x0, x28
    7b88:	97fff31a 	bl	47f0 <fwp_rc_forget_slot>
    7b8c:	17fffeff 	b	7788 <f12+0xb28>
    7b90:	f100037f 	cmp	x27, #0x0
    7b94:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    7b98:	54ffb2e1 	b.ne	71f4 <f12+0x594>  // b.any
    7b9c:	f94013e0 	ldr	x0, [sp, #32]
    7ba0:	9101c294 	add	x20, x20, #0x70
    7ba4:	f9402fe1 	ldr	x1, [sp, #88]
    7ba8:	f9018a81 	str	x1, [x20, #784]
    7bac:	97fff1f5 	bl	4380 <fwp_tape_buffers_release>
    7bb0:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7bb4:	f947e863 	ldr	x3, [x3, #4048]
    7bb8:	d2800262 	mov	x2, #0x13                  	// #19
    7bbc:	d2800021 	mov	x1, #0x1                   	// #1
    7bc0:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7bc4:	9118a000 	add	x0, x0, #0x628
    7bc8:	f9400063 	ldr	x3, [x3]
    7bcc:	97ffeb6d 	bl	2980 <fwrite@plt>
    7bd0:	d2800000 	mov	x0, #0x0                   	// #0
    7bd4:	97ffeb77 	bl	29b0 <fflush@plt>
    7bd8:	52800cc0 	mov	w0, #0x66                  	// #102
    7bdc:	97ffeb85 	bl	29f0 <_Exit@plt>
    7be0:	eb18033f 	cmp	x25, x24
    7be4:	54ff9040 	b.eq	6dec <f12+0x18c>  // b.none
    7be8:	f9403a9c 	ldr	x28, [x20, #112]
    7bec:	17fffc9d 	b	6e60 <f12+0x200>
    7bf0:	b5ffa136 	cbnz	x22, 7014 <f12+0x3b4>
    7bf4:	d280001c 	mov	x28, #0x0                   	// #0
    7bf8:	17fffd2d 	b	70ac <f12+0x44c>
    7bfc:	d0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x110>
    7c00:	913f8000 	add	x0, x0, #0xfe0
    7c04:	94000e7b 	bl	b5f0 <atexit>
    7c08:	35fffd40 	cbnz	w0, 7bb0 <f12+0xf50>
    7c0c:	52800020 	mov	w0, #0x1                   	// #1
    7c10:	b9034700 	str	w0, [x24, #836]
    7c14:	17fffc62 	b	6d9c <f12+0x13c>
    7c18:	72003c3f 	tst	w1, #0xffff
    7c1c:	54ff9fa1 	b.ne	7010 <f12+0x3b0>  // b.any
    7c20:	17fffcf7 	b	6ffc <f12+0x39c>
    7c24:	72003c3f 	tst	w1, #0xffff
    7c28:	54ff88e0 	b.eq	6d44 <f12+0xe4>  // b.none
    7c2c:	aa1703e0 	mov	x0, x23
    7c30:	97fff84c 	bl	5d60 <fwp_closure_drop>
    7c34:	b5ff89b5 	cbnz	x21, 6d68 <f12+0x108>
    7c38:	52800000 	mov	w0, #0x0                   	// #0
    7c3c:	d2800017 	mov	x23, #0x0                   	// #0
    7c40:	97ffee6c 	bl	35f0 <descent_phase_step>
    7c44:	17fffc53 	b	6d90 <f12+0x130>
    7c48:	aa1c03fb 	mov	x27, x28
    7c4c:	17fffd55 	b	71a0 <f12+0x540>
    7c50:	72003c3f 	tst	w1, #0xffff
    7c54:	54ffba61 	b.ne	73a0 <f12+0x740>  // b.any
    7c58:	17fffdcd 	b	738c <f12+0x72c>
    7c5c:	3cc98002 	ldur	q2, [x0, #152]
    7c60:	91026001 	add	x1, x0, #0x98
    7c64:	3cca8001 	ldur	q1, [x0, #168]
    7c68:	f900681f 	str	xzr, [x0, #208]
    7c6c:	4f000400 	movi	v0.4s, #0x0
    7c70:	ad010702 	stp	q2, q1, [x24, #32]
    7c74:	a94b8002 	ldp	x2, x0, [x0, #184]
    7c78:	f9000f00 	str	x0, [x24, #24]
    7c7c:	f9401820 	ldr	x0, [x1, #48]
    7c80:	f9002302 	str	x2, [x24, #64]
    7c84:	f9002700 	str	x0, [x24, #72]
    7c88:	ad000020 	stp	q0, q0, [x1]
    7c8c:	3d800820 	str	q0, [x1, #32]
    7c90:	f900183f 	str	xzr, [x1, #48]
    7c94:	17fffc81 	b	6e98 <f12+0x238>
    7c98:	d37ffb1a 	lsl	x26, x24, #1
    7c9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7ca0:	eb00035f 	cmp	x26, x0
    7ca4:	9a80d35a 	csel	x26, x26, x0, le
    7ca8:	8b1a0741 	add	x1, x26, x26, lsl #1
    7cac:	8b010b41 	add	x1, x26, x1, lsl #2
    7cb0:	d37df021 	lsl	x1, x1, #3
    7cb4:	17fffc59 	b	6e18 <f12+0x1b8>
    7cb8:	52800041 	mov	w1, #0x2                   	// #2
    7cbc:	d2800100 	mov	x0, #0x8                   	// #8
    7cc0:	97fff48c 	bl	4ef0 <fwp_heap_alloc>
    7cc4:	aa0003f9 	mov	x25, x0
    7cc8:	d2800018 	mov	x24, #0x0                   	// #0
    7ccc:	17fffee3 	b	7858 <f12+0xbf8>
    7cd0:	72003c3f 	tst	w1, #0xffff
    7cd4:	54fff300 	b.eq	7b34 <f12+0xed4>  // b.none
    7cd8:	aa1603e0 	mov	x0, x22
    7cdc:	17fffddb 	b	7448 <f12+0x7e8>
    7ce0:	aa0203e0 	mov	x0, x2
    7ce4:	d2800101 	mov	x1, #0x8                   	// #8
    7ce8:	f90017e2 	str	x2, [sp, #40]
    7cec:	97ffeadd 	bl	2860 <calloc@plt>
    7cf0:	f94017e2 	ldr	x2, [sp, #40]
    7cf4:	aa0003fa 	mov	x26, x0
    7cf8:	17fffd3c 	b	71e8 <f12+0x588>
    7cfc:	f9400343 	ldr	x3, [x26]
    7d00:	b7fffdc3 	tbnz	x3, #63, 7cb8 <f12+0x1058>
    7d04:	91174261 	add	x1, x19, #0x5d0
    7d08:	f9400fe4 	ldr	x4, [sp, #24]
    7d0c:	f949d820 	ldr	x0, [x1, #5040]
    7d10:	f949ec21 	ldr	x1, [x1, #5080]
    7d14:	cb000080 	sub	x0, x4, x0
    7d18:	eb01401f 	cmp	x0, x1, lsl #16
    7d1c:	54fffce2 	b.cs	7cb8 <f12+0x1058>  // b.hs, b.nlast
    7d20:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    7d24:	17fffdf8 	b	7504 <f12+0x8a4>
    7d28:	aa1903e0 	mov	x0, x25
    7d2c:	97fff2b1 	bl	47f0 <fwp_rc_forget_slot>
    7d30:	17fffcb6 	b	7008 <f12+0x3a8>
    7d34:	aa1703e0 	mov	x0, x23
    7d38:	97fff2ae 	bl	47f0 <fwp_rc_forget_slot>
    7d3c:	17fffd97 	b	7398 <f12+0x738>
    7d40:	aa1803e0 	mov	x0, x24
    7d44:	97fff2ab 	bl	47f0 <fwp_rc_forget_slot>
    7d48:	17ffff7e 	b	7b40 <f12+0xee0>
    7d4c:	97fff262 	bl	46d4 <fwp_rc_wide_dup>
    7d50:	17fffc03 	b	6d5c <f12+0xfc>
    7d54:	d280001b 	mov	x27, #0x0                   	// #0
    7d58:	17fffe4b 	b	7684 <f12+0xa24>
    7d5c:	d2800019 	mov	x25, #0x0                   	// #0
    7d60:	d2800018 	mov	x24, #0x0                   	// #0
    7d64:	17fffebd 	b	7858 <f12+0xbf8>
    7d68:	aa1603e0 	mov	x0, x22
    7d6c:	97fff2a1 	bl	47f0 <fwp_rc_forget_slot>
    7d70:	17ffff21 	b	79f4 <f12+0xd94>
    7d74:	f9400436 	ldr	x22, [x1, #8]
    7d78:	b4ffe4d6 	cbz	x22, 7a10 <f12+0xdb0>
    7d7c:	f9400820 	ldr	x0, [x1, #16]
    7d80:	cb160000 	sub	x0, x0, x22
    7d84:	eb00037f 	cmp	x27, x0
    7d88:	54ffe448 	b.hi	7a10 <f12+0xdb0>  // b.pmore
    7d8c:	8b1b02c0 	add	x0, x22, x27
    7d90:	f9000420 	str	x0, [x1, #8]
    7d94:	17fffee6 	b	792c <f12+0xccc>
    7d98:	72003c3f 	tst	w1, #0xffff
    7d9c:	54ffe2e1 	b.ne	79f8 <f12+0xd98>  // b.any
    7da0:	17ffff12 	b	79e8 <f12+0xd88>
    7da4:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7da8:	91272000 	add	x0, x0, #0x9c8
    7dac:	97ffee95 	bl	3800 <fwp_trap>
    7db0:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7db4:	91298000 	add	x0, x0, #0xa60
    7db8:	97ffee92 	bl	3800 <fwp_trap>
    7dbc:	97ffec9d 	bl	3030 <fwp_heap_oom>
    7dc0:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7dc4:	91284000 	add	x0, x0, #0xa10
    7dc8:	97ffee8e 	bl	3800 <fwp_trap>
    7dcc:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7dd0:	912b0000 	add	x0, x0, #0xac0
    7dd4:	97ffee8b 	bl	3800 <fwp_trap>
    7dd8:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7ddc:	912b8000 	add	x0, x0, #0xae0
    7de0:	97ffee88 	bl	3800 <fwp_trap>
    7de4:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7de8:	912c4000 	add	x0, x0, #0xb10
    7dec:	97ffee85 	bl	3800 <fwp_trap>
    7df0:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7df4:	912d0000 	add	x0, x0, #0xb40
    7df8:	97ffee82 	bl	3800 <fwp_trap>
    7dfc:	97ffeaa1 	bl	2880 <__stack_chk_fail@plt>
    7e00:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7e04:	912d4000 	add	x0, x0, #0xb50
    7e08:	97ffee7e 	bl	3800 <fwp_trap>
    7e0c:	90000020 	adrp	x0, b000 <__divti3+0x100>
    7e10:	912d8000 	add	x0, x0, #0xb60
    7e14:	97ffee7b 	bl	3800 <fwp_trap>
    7e18:	97ffeaae 	bl	28d0 <abort@plt>
    7e1c:	97ffeb19 	bl	2a80 <fwp_trap_overflow.constprop.0>

0000000000007e20 <fwp_owned_entry12>:
    7e20:	f9400000 	ldr	x0, [x0]
    7e24:	17fffb8f 	b	6c60 <f12>
    7e28:	d503201f 	nop
    7e2c:	d503201f 	nop

0000000000007e30 <e12>:
    7e30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7e34:	910003fd 	mov	x29, sp
    7e38:	f9000bf3 	str	x19, [sp, #16]
    7e3c:	f9400013 	ldr	x19, [x0]
    7e40:	aa1303e0 	mov	x0, x19
    7e44:	97fff6a8 	bl	58e4 <fwp_rc_share>
    7e48:	aa1303e0 	mov	x0, x19
    7e4c:	97fffb85 	bl	6c60 <f12>
    7e50:	aa0003f3 	mov	x19, x0
    7e54:	97fff6a4 	bl	58e4 <fwp_rc_share>
    7e58:	aa1303e0 	mov	x0, x19
    7e5c:	f9400bf3 	ldr	x19, [sp, #16]
    7e60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7e64:	d65f03c0 	ret
    7e68:	d503201f 	nop
    7e6c:	d503201f 	nop

0000000000007e70 <fwp_args23>:
    7e70:	7100003f 	cmp	w1, #0x0
    7e74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7e78:	54000041 	b.ne	7e80 <fwp_args23+0x10>  // b.any
    7e7c:	d65f03c0 	ret
    7e80:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7e84:	91174042 	add	x2, x2, #0x5d0
    7e88:	f9400001 	ldr	x1, [x0]
    7e8c:	f949d843 	ldr	x3, [x2, #5040]
    7e90:	f949ec40 	ldr	x0, [x2, #5080]
    7e94:	cb030021 	sub	x1, x1, x3
    7e98:	eb00403f 	cmp	x1, x0, lsl #16
    7e9c:	54ffff02 	b.cs	7e7c <fwp_args23+0xc>  // b.hs, b.nlast
    7ea0:	d350fc20 	lsr	x0, x1, #16
    7ea4:	f949fc44 	ldr	x4, [x2, #5112]
    7ea8:	8b000800 	add	x0, x0, x0, lsl #2
    7eac:	d37df002 	lsl	x2, x0, #3
    7eb0:	8b020083 	add	x3, x4, x2
    7eb4:	f9401060 	ldr	x0, [x3, #32]
    7eb8:	b4fffe20 	cbz	x0, 7e7c <fwp_args23+0xc>
    7ebc:	38626882 	ldrb	w2, [x4, x2]
    7ec0:	7100085f 	cmp	w2, #0x2
    7ec4:	54000220 	b.eq	7f08 <fwp_args23+0x98>  // b.none
    7ec8:	7100045f 	cmp	w2, #0x1
    7ecc:	54fffd81 	b.ne	7e7c <fwp_args23+0xc>  // b.any
    7ed0:	29430864 	ldp	w4, w2, [x3, #24]
    7ed4:	92403c21 	and	x1, x1, #0xffff
    7ed8:	9b047c21 	mul	x1, x1, x4
    7edc:	d360fc21 	lsr	x1, x1, #32
    7ee0:	eb02003f 	cmp	x1, x2
    7ee4:	54fffcc2 	b.cs	7e7c <fwp_args23+0xc>  // b.hs, b.nlast
    7ee8:	8b010000 	add	x0, x0, x1
    7eec:	39400001 	ldrb	w1, [x0]
    7ef0:	34fffc61 	cbz	w1, 7e7c <fwp_args23+0xc>
    7ef4:	7103f43f 	cmp	w1, #0xfd
    7ef8:	540000e8 	b.hi	7f14 <fwp_args23+0xa4>  // b.pmore
    7efc:	11000421 	add	w1, w1, #0x1
    7f00:	39000001 	strb	w1, [x0]
    7f04:	d65f03c0 	ret
    7f08:	72003c3f 	tst	w1, #0xffff
    7f0c:	54ffff00 	b.eq	7eec <fwp_args23+0x7c>  // b.none
    7f10:	d65f03c0 	ret
    7f14:	17fff1f0 	b	46d4 <fwp_rc_wide_dup>
    7f18:	d503201f 	nop
    7f1c:	d503201f 	nop

0000000000007f20 <fwp_args12>:
    7f20:	7100003f 	cmp	w1, #0x0
    7f24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7f28:	54000041 	b.ne	7f30 <fwp_args12+0x10>  // b.any
    7f2c:	d65f03c0 	ret
    7f30:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7f34:	91174042 	add	x2, x2, #0x5d0
    7f38:	f9400001 	ldr	x1, [x0]
    7f3c:	f949d843 	ldr	x3, [x2, #5040]
    7f40:	f949ec40 	ldr	x0, [x2, #5080]
    7f44:	cb030021 	sub	x1, x1, x3
    7f48:	eb00403f 	cmp	x1, x0, lsl #16
    7f4c:	54ffff02 	b.cs	7f2c <fwp_args12+0xc>  // b.hs, b.nlast
    7f50:	d350fc20 	lsr	x0, x1, #16
    7f54:	f949fc44 	ldr	x4, [x2, #5112]
    7f58:	8b000800 	add	x0, x0, x0, lsl #2
    7f5c:	d37df002 	lsl	x2, x0, #3
    7f60:	8b020083 	add	x3, x4, x2
    7f64:	f9401060 	ldr	x0, [x3, #32]
    7f68:	b4fffe20 	cbz	x0, 7f2c <fwp_args12+0xc>
    7f6c:	38626882 	ldrb	w2, [x4, x2]
    7f70:	7100085f 	cmp	w2, #0x2
    7f74:	54000220 	b.eq	7fb8 <fwp_args12+0x98>  // b.none
    7f78:	7100045f 	cmp	w2, #0x1
    7f7c:	54fffd81 	b.ne	7f2c <fwp_args12+0xc>  // b.any
    7f80:	29430864 	ldp	w4, w2, [x3, #24]
    7f84:	92403c21 	and	x1, x1, #0xffff
    7f88:	9b047c21 	mul	x1, x1, x4
    7f8c:	d360fc21 	lsr	x1, x1, #32
    7f90:	eb02003f 	cmp	x1, x2
    7f94:	54fffcc2 	b.cs	7f2c <fwp_args12+0xc>  // b.hs, b.nlast
    7f98:	8b010000 	add	x0, x0, x1
    7f9c:	39400001 	ldrb	w1, [x0]
    7fa0:	34fffc61 	cbz	w1, 7f2c <fwp_args12+0xc>
    7fa4:	7103f43f 	cmp	w1, #0xfd
    7fa8:	540000e8 	b.hi	7fc4 <fwp_args12+0xa4>  // b.pmore
    7fac:	11000421 	add	w1, w1, #0x1
    7fb0:	39000001 	strb	w1, [x0]
    7fb4:	d65f03c0 	ret
    7fb8:	72003c3f 	tst	w1, #0xffff
    7fbc:	54ffff00 	b.eq	7f9c <fwp_args12+0x7c>  // b.none
    7fc0:	d65f03c0 	ret
    7fc4:	17fff1c4 	b	46d4 <fwp_rc_wide_dup>
    7fc8:	d503201f 	nop
    7fcc:	d503201f 	nop

0000000000007fd0 <fwp_caps12>:
    7fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7fd4:	910003fd 	mov	x29, sp
    7fd8:	f9000bf3 	str	x19, [sp, #16]
    7fdc:	aa0003f3 	mov	x19, x0
    7fe0:	b9400400 	ldr	w0, [x0, #4]
    7fe4:	340004a0 	cbz	w0, 8078 <fwp_caps12+0xa8>
    7fe8:	f9400660 	ldr	x0, [x19, #8]
    7fec:	350004e1 	cbnz	w1, 8088 <fwp_caps12+0xb8>
    7ff0:	97fff6ac 	bl	5aa0 <fwp_drop0>
    7ff4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7ff8:	91174042 	add	x2, x2, #0x5d0
    7ffc:	f949d840 	ldr	x0, [x2, #5040]
    8000:	f949ec41 	ldr	x1, [x2, #5080]
    8004:	cb000260 	sub	x0, x19, x0
    8008:	eb01401f 	cmp	x0, x1, lsl #16
    800c:	54000382 	b.cs	807c <fwp_caps12+0xac>  // b.hs, b.nlast
    8010:	d350fc01 	lsr	x1, x0, #16
    8014:	f949fc44 	ldr	x4, [x2, #5112]
    8018:	8b010821 	add	x1, x1, x1, lsl #2
    801c:	d37df021 	lsl	x1, x1, #3
    8020:	8b010083 	add	x3, x4, x1
    8024:	f9401062 	ldr	x2, [x3, #32]
    8028:	b40002a2 	cbz	x2, 807c <fwp_caps12+0xac>
    802c:	38616881 	ldrb	w1, [x4, x1]
    8030:	7100083f 	cmp	w1, #0x2
    8034:	540006c0 	b.eq	810c <fwp_caps12+0x13c>  // b.none
    8038:	7100043f 	cmp	w1, #0x1
    803c:	54000201 	b.ne	807c <fwp_caps12+0xac>  // b.any
    8040:	29430464 	ldp	w4, w1, [x3, #24]
    8044:	92403c00 	and	x0, x0, #0xffff
    8048:	9b047c00 	mul	x0, x0, x4
    804c:	d360fc00 	lsr	x0, x0, #32
    8050:	eb01001f 	cmp	x0, x1
    8054:	54000142 	b.cs	807c <fwp_caps12+0xac>  // b.hs, b.nlast
    8058:	8b000042 	add	x2, x2, x0
    805c:	39400040 	ldrb	w0, [x2]
    8060:	7100041f 	cmp	w0, #0x1
    8064:	540000c1 	b.ne	807c <fwp_caps12+0xac>  // b.any
    8068:	aa1303e0 	mov	x0, x19
    806c:	f9400bf3 	ldr	x19, [sp, #16]
    8070:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8074:	17fff27f 	b	4a70 <fwp_mem_free>
    8078:	34fffbe1 	cbz	w1, 7ff4 <fwp_caps12+0x24>
    807c:	f9400bf3 	ldr	x19, [sp, #16]
    8080:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8084:	d65f03c0 	ret
    8088:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    808c:	91174042 	add	x2, x2, #0x5d0
    8090:	f949d843 	ldr	x3, [x2, #5040]
    8094:	f949ec41 	ldr	x1, [x2, #5080]
    8098:	cb030000 	sub	x0, x0, x3
    809c:	eb01401f 	cmp	x0, x1, lsl #16
    80a0:	54fffee2 	b.cs	807c <fwp_caps12+0xac>  // b.hs, b.nlast
    80a4:	d350fc01 	lsr	x1, x0, #16
    80a8:	f949fc44 	ldr	x4, [x2, #5112]
    80ac:	8b010821 	add	x1, x1, x1, lsl #2
    80b0:	d37df021 	lsl	x1, x1, #3
    80b4:	8b010083 	add	x3, x4, x1
    80b8:	f9401062 	ldr	x2, [x3, #32]
    80bc:	b4fffe02 	cbz	x2, 807c <fwp_caps12+0xac>
    80c0:	38616881 	ldrb	w1, [x4, x1]
    80c4:	7100083f 	cmp	w1, #0x2
    80c8:	54000280 	b.eq	8118 <fwp_caps12+0x148>  // b.none
    80cc:	7100043f 	cmp	w1, #0x1
    80d0:	54fffd61 	b.ne	807c <fwp_caps12+0xac>  // b.any
    80d4:	92403c01 	and	x1, x0, #0xffff
    80d8:	29430064 	ldp	w4, w0, [x3, #24]
    80dc:	9b047c21 	mul	x1, x1, x4
    80e0:	d360fc21 	lsr	x1, x1, #32
    80e4:	eb00003f 	cmp	x1, x0
    80e8:	54fffca2 	b.cs	807c <fwp_caps12+0xac>  // b.hs, b.nlast
    80ec:	8b010042 	add	x2, x2, x1
    80f0:	39400040 	ldrb	w0, [x2]
    80f4:	34fffc40 	cbz	w0, 807c <fwp_caps12+0xac>
    80f8:	7103f41f 	cmp	w0, #0xfd
    80fc:	54000148 	b.hi	8124 <fwp_caps12+0x154>  // b.pmore
    8100:	11000400 	add	w0, w0, #0x1
    8104:	39000040 	strb	w0, [x2]
    8108:	17ffffdd 	b	807c <fwp_caps12+0xac>
    810c:	72003c1f 	tst	w0, #0xffff
    8110:	54fffb61 	b.ne	807c <fwp_caps12+0xac>  // b.any
    8114:	17ffffd2 	b	805c <fwp_caps12+0x8c>
    8118:	72003c1f 	tst	w0, #0xffff
    811c:	54fffb01 	b.ne	807c <fwp_caps12+0xac>  // b.any
    8120:	17fffff4 	b	80f0 <fwp_caps12+0x120>
    8124:	f9400bf3 	ldr	x19, [sp, #16]
    8128:	aa0203e0 	mov	x0, x2
    812c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8130:	17fff169 	b	46d4 <fwp_rc_wide_dup>

0000000000008134 <fwp_drop2>:
    8134:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    8138:	910003fd 	mov	x29, sp
    813c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8140:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    8144:	911742d5 	add	x21, x22, #0x5d0
    8148:	a90153f3 	stp	x19, x20, [sp, #16]
    814c:	aa0003f3 	mov	x19, x0
    8150:	f949daa1 	ldr	x1, [x21, #5040]
    8154:	f949eea0 	ldr	x0, [x21, #5080]
    8158:	cb010261 	sub	x1, x19, x1
    815c:	eb00403f 	cmp	x1, x0, lsl #16
    8160:	54000382 	b.cs	81d0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8164:	d350fc22 	lsr	x2, x1, #16
    8168:	f949fea3 	ldr	x3, [x21, #5112]
    816c:	8b020842 	add	x2, x2, x2, lsl #2
    8170:	d37df042 	lsl	x2, x2, #3
    8174:	8b020060 	add	x0, x3, x2
    8178:	f9401014 	ldr	x20, [x0, #32]
    817c:	b40002b4 	cbz	x20, 81d0 <fwp_drop2+0x9c>
    8180:	38626862 	ldrb	w2, [x3, x2]
    8184:	7100085f 	cmp	w2, #0x2
    8188:	540002c0 	b.eq	81e0 <fwp_drop2+0xac>  // b.none
    818c:	7100045f 	cmp	w2, #0x1
    8190:	54000201 	b.ne	81d0 <fwp_drop2+0x9c>  // b.any
    8194:	29430002 	ldp	w2, w0, [x0, #24]
    8198:	92403c21 	and	x1, x1, #0xffff
    819c:	9b027c21 	mul	x1, x1, x2
    81a0:	d360fc21 	lsr	x1, x1, #32
    81a4:	eb00003f 	cmp	x1, x0
    81a8:	54000142 	b.cs	81d0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    81ac:	8b010294 	add	x20, x20, x1
    81b0:	39400280 	ldrb	w0, [x20]
    81b4:	340000e0 	cbz	w0, 81d0 <fwp_drop2+0x9c>
    81b8:	7100041f 	cmp	w0, #0x1
    81bc:	540001e0 	b.eq	81f8 <fwp_drop2+0xc4>  // b.none
    81c0:	7103fc1f 	cmp	w0, #0xff
    81c4:	540007e0 	b.eq	82c0 <fwp_drop2+0x18c>  // b.none
    81c8:	51000400 	sub	w0, w0, #0x1
    81cc:	39000280 	strb	w0, [x20]
    81d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    81d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    81d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    81dc:	d65f03c0 	ret
    81e0:	72003c3f 	tst	w1, #0xffff
    81e4:	54fffe60 	b.eq	81b0 <fwp_drop2+0x7c>  // b.none
    81e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    81ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    81f0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    81f4:	d65f03c0 	ret
    81f8:	911742c2 	add	x2, x22, #0x5d0
    81fc:	f9400660 	ldr	x0, [x19, #8]
    8200:	f949d841 	ldr	x1, [x2, #5040]
    8204:	f949ec42 	ldr	x2, [x2, #5080]
    8208:	cb010001 	sub	x1, x0, x1
    820c:	eb02403f 	cmp	x1, x2, lsl #16
    8210:	54000382 	b.cs	8280 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8214:	d350fc22 	lsr	x2, x1, #16
    8218:	8b020842 	add	x2, x2, x2, lsl #2
    821c:	d37df042 	lsl	x2, x2, #3
    8220:	8b020064 	add	x4, x3, x2
    8224:	f9401094 	ldr	x20, [x4, #32]
    8228:	b40002d4 	cbz	x20, 8280 <fwp_drop2+0x14c>
    822c:	38626862 	ldrb	w2, [x3, x2]
    8230:	7100085f 	cmp	w2, #0x2
    8234:	54000400 	b.eq	82b4 <fwp_drop2+0x180>  // b.none
    8238:	7100045f 	cmp	w2, #0x1
    823c:	54000221 	b.ne	8280 <fwp_drop2+0x14c>  // b.any
    8240:	29430883 	ldp	w3, w2, [x4, #24]
    8244:	92403c21 	and	x1, x1, #0xffff
    8248:	9b037c21 	mul	x1, x1, x3
    824c:	d360fc21 	lsr	x1, x1, #32
    8250:	eb02003f 	cmp	x1, x2
    8254:	54000162 	b.cs	8280 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8258:	8b010294 	add	x20, x20, x1
    825c:	39400281 	ldrb	w1, [x20]
    8260:	34000101 	cbz	w1, 8280 <fwp_drop2+0x14c>
    8264:	7100043f 	cmp	w1, #0x1
    8268:	54000220 	b.eq	82ac <fwp_drop2+0x178>  // b.none
    826c:	7103fc3f 	cmp	w1, #0xff
    8270:	540005a0 	b.eq	8324 <fwp_drop2+0x1f0>  // b.none
    8274:	51000421 	sub	w1, w1, #0x1
    8278:	39000281 	strb	w1, [x20]
    827c:	d503201f 	nop
    8280:	f9400a74 	ldr	x20, [x19, #16]
    8284:	aa1303e0 	mov	x0, x19
    8288:	97fff5be 	bl	5980 <fwp_rc_free_arr>
    828c:	911742c0 	add	x0, x22, #0x5d0
    8290:	f949d801 	ldr	x1, [x0, #5040]
    8294:	f949ec00 	ldr	x0, [x0, #5080]
    8298:	cb010281 	sub	x1, x20, x1
    829c:	eb00403f 	cmp	x1, x0, lsl #16
    82a0:	54fff982 	b.cs	81d0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    82a4:	aa1403f3 	mov	x19, x20
    82a8:	17ffffaf 	b	8164 <fwp_drop2+0x30>
    82ac:	97fff5b5 	bl	5980 <fwp_rc_free_arr>
    82b0:	17fffff4 	b	8280 <fwp_drop2+0x14c>
    82b4:	72003c3f 	tst	w1, #0xffff
    82b8:	54fffe41 	b.ne	8280 <fwp_drop2+0x14c>  // b.any
    82bc:	17ffffe8 	b	825c <fwp_drop2+0x128>
    82c0:	ca544681 	eor	x1, x20, x20, lsr #17
    82c4:	911742c0 	add	x0, x22, #0x5d0
    82c8:	ca412421 	eor	x1, x1, x1, lsr #9
    82cc:	8b210c01 	add	x1, x0, w1, uxtb #3
    82d0:	f94a2420 	ldr	x0, [x1, #5192]
    82d4:	b5000080 	cbnz	x0, 82e4 <fwp_drop2+0x1b0>
    82d8:	14000010 	b	8318 <fwp_drop2+0x1e4>
    82dc:	f9400800 	ldr	x0, [x0, #16]
    82e0:	b40001c0 	cbz	x0, 8318 <fwp_drop2+0x1e4>
    82e4:	f9400001 	ldr	x1, [x0]
    82e8:	eb14003f 	cmp	x1, x20
    82ec:	54ffff81 	b.ne	82dc <fwp_drop2+0x1a8>  // b.any
    82f0:	f9400401 	ldr	x1, [x0, #8]
    82f4:	d1000421 	sub	x1, x1, #0x1
    82f8:	f9000401 	str	x1, [x0, #8]
    82fc:	f103f83f 	cmp	x1, #0xfe
    8300:	54fff681 	b.ne	81d0 <fwp_drop2+0x9c>  // b.any
    8304:	aa1403e0 	mov	x0, x20
    8308:	97fff13a 	bl	47f0 <fwp_rc_forget_slot>
    830c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8310:	39000280 	strb	w0, [x20]
    8314:	17ffffaf 	b	81d0 <fwp_drop2+0x9c>
    8318:	f0000000 	adrp	x0, b000 <__divti3+0x100>
    831c:	91260000 	add	x0, x0, #0x980
    8320:	97ffed38 	bl	3800 <fwp_trap>
    8324:	ca544680 	eor	x0, x20, x20, lsr #17
    8328:	911742c1 	add	x1, x22, #0x5d0
    832c:	ca402400 	eor	x0, x0, x0, lsr #9
    8330:	8b200c20 	add	x0, x1, w0, uxtb #3
    8334:	f94a2400 	ldr	x0, [x0, #5192]
    8338:	b5000080 	cbnz	x0, 8348 <fwp_drop2+0x214>
    833c:	17fffff7 	b	8318 <fwp_drop2+0x1e4>
    8340:	f9400800 	ldr	x0, [x0, #16]
    8344:	b4fffea0 	cbz	x0, 8318 <fwp_drop2+0x1e4>
    8348:	f9400001 	ldr	x1, [x0]
    834c:	eb14003f 	cmp	x1, x20
    8350:	54ffff81 	b.ne	8340 <fwp_drop2+0x20c>  // b.any
    8354:	f9400401 	ldr	x1, [x0, #8]
    8358:	d1000421 	sub	x1, x1, #0x1
    835c:	f9000401 	str	x1, [x0, #8]
    8360:	f103f83f 	cmp	x1, #0xfe
    8364:	54fff8e1 	b.ne	8280 <fwp_drop2+0x14c>  // b.any
    8368:	aa1403e0 	mov	x0, x20
    836c:	97fff121 	bl	47f0 <fwp_rc_forget_slot>
    8370:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8374:	39000280 	strb	w0, [x20]
    8378:	17ffffc2 	b	8280 <fwp_drop2+0x14c>
    837c:	d503201f 	nop

0000000000008380 <fwp_arg_drop23>:
    8380:	7100003f 	cmp	w1, #0x0
    8384:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8388:	54000041 	b.ne	8390 <fwp_arg_drop23+0x10>  // b.any
    838c:	d65f03c0 	ret
    8390:	f9400000 	ldr	x0, [x0]
    8394:	17ffff68 	b	8134 <fwp_drop2>
    8398:	d503201f 	nop
    839c:	d503201f 	nop

00000000000083a0 <fwp_caps23>:
    83a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    83a4:	910003fd 	mov	x29, sp
    83a8:	f9000bf3 	str	x19, [sp, #16]
    83ac:	aa0003f3 	mov	x19, x0
    83b0:	b9400400 	ldr	w0, [x0, #4]
    83b4:	340004a0 	cbz	w0, 8448 <fwp_caps23+0xa8>
    83b8:	f9400660 	ldr	x0, [x19, #8]
    83bc:	350004e1 	cbnz	w1, 8458 <fwp_caps23+0xb8>
    83c0:	97ffff5d 	bl	8134 <fwp_drop2>
    83c4:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    83c8:	91174042 	add	x2, x2, #0x5d0
    83cc:	f949d840 	ldr	x0, [x2, #5040]
    83d0:	f949ec41 	ldr	x1, [x2, #5080]
    83d4:	cb000260 	sub	x0, x19, x0
    83d8:	eb01401f 	cmp	x0, x1, lsl #16
    83dc:	54000382 	b.cs	844c <fwp_caps23+0xac>  // b.hs, b.nlast
    83e0:	d350fc01 	lsr	x1, x0, #16
    83e4:	f949fc44 	ldr	x4, [x2, #5112]
    83e8:	8b010821 	add	x1, x1, x1, lsl #2
    83ec:	d37df021 	lsl	x1, x1, #3
    83f0:	8b010083 	add	x3, x4, x1
    83f4:	f9401062 	ldr	x2, [x3, #32]
    83f8:	b40002a2 	cbz	x2, 844c <fwp_caps23+0xac>
    83fc:	38616881 	ldrb	w1, [x4, x1]
    8400:	7100083f 	cmp	w1, #0x2
    8404:	540006c0 	b.eq	84dc <fwp_caps23+0x13c>  // b.none
    8408:	7100043f 	cmp	w1, #0x1
    840c:	54000201 	b.ne	844c <fwp_caps23+0xac>  // b.any
    8410:	29430464 	ldp	w4, w1, [x3, #24]
    8414:	92403c00 	and	x0, x0, #0xffff
    8418:	9b047c00 	mul	x0, x0, x4
    841c:	d360fc00 	lsr	x0, x0, #32
    8420:	eb01001f 	cmp	x0, x1
    8424:	54000142 	b.cs	844c <fwp_caps23+0xac>  // b.hs, b.nlast
    8428:	8b000042 	add	x2, x2, x0
    842c:	39400040 	ldrb	w0, [x2]
    8430:	7100041f 	cmp	w0, #0x1
    8434:	540000c1 	b.ne	844c <fwp_caps23+0xac>  // b.any
    8438:	aa1303e0 	mov	x0, x19
    843c:	f9400bf3 	ldr	x19, [sp, #16]
    8440:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8444:	17fff18b 	b	4a70 <fwp_mem_free>
    8448:	34fffbe1 	cbz	w1, 83c4 <fwp_caps23+0x24>
    844c:	f9400bf3 	ldr	x19, [sp, #16]
    8450:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8454:	d65f03c0 	ret
    8458:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    845c:	91174042 	add	x2, x2, #0x5d0
    8460:	f949d843 	ldr	x3, [x2, #5040]
    8464:	f949ec41 	ldr	x1, [x2, #5080]
    8468:	cb030000 	sub	x0, x0, x3
    846c:	eb01401f 	cmp	x0, x1, lsl #16
    8470:	54fffee2 	b.cs	844c <fwp_caps23+0xac>  // b.hs, b.nlast
    8474:	d350fc01 	lsr	x1, x0, #16
    8478:	f949fc44 	ldr	x4, [x2, #5112]
    847c:	8b010821 	add	x1, x1, x1, lsl #2
    8480:	d37df021 	lsl	x1, x1, #3
    8484:	8b010083 	add	x3, x4, x1
    8488:	f9401062 	ldr	x2, [x3, #32]
    848c:	b4fffe02 	cbz	x2, 844c <fwp_caps23+0xac>
    8490:	38616881 	ldrb	w1, [x4, x1]
    8494:	7100083f 	cmp	w1, #0x2
    8498:	54000280 	b.eq	84e8 <fwp_caps23+0x148>  // b.none
    849c:	7100043f 	cmp	w1, #0x1
    84a0:	54fffd61 	b.ne	844c <fwp_caps23+0xac>  // b.any
    84a4:	92403c01 	and	x1, x0, #0xffff
    84a8:	29430064 	ldp	w4, w0, [x3, #24]
    84ac:	9b047c21 	mul	x1, x1, x4
    84b0:	d360fc21 	lsr	x1, x1, #32
    84b4:	eb00003f 	cmp	x1, x0
    84b8:	54fffca2 	b.cs	844c <fwp_caps23+0xac>  // b.hs, b.nlast
    84bc:	8b010042 	add	x2, x2, x1
    84c0:	39400040 	ldrb	w0, [x2]
    84c4:	34fffc40 	cbz	w0, 844c <fwp_caps23+0xac>
    84c8:	7103f41f 	cmp	w0, #0xfd
    84cc:	54000148 	b.hi	84f4 <fwp_caps23+0x154>  // b.pmore
    84d0:	11000400 	add	w0, w0, #0x1
    84d4:	39000040 	strb	w0, [x2]
    84d8:	17ffffdd 	b	844c <fwp_caps23+0xac>
    84dc:	72003c1f 	tst	w0, #0xffff
    84e0:	54fffb61 	b.ne	844c <fwp_caps23+0xac>  // b.any
    84e4:	17ffffd2 	b	842c <fwp_caps23+0x8c>
    84e8:	72003c1f 	tst	w0, #0xffff
    84ec:	54fffb01 	b.ne	844c <fwp_caps23+0xac>  // b.any
    84f0:	17fffff4 	b	84c0 <fwp_caps23+0x120>
    84f4:	f9400bf3 	ldr	x19, [sp, #16]
    84f8:	aa0203e0 	mov	x0, x2
    84fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8500:	17fff075 	b	46d4 <fwp_rc_wide_dup>

0000000000008504 <f23>:
    8504:	d101c3ff 	sub	sp, sp, #0x70
    8508:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    850c:	f947f421 	ldr	x1, [x1, #4072]
    8510:	a9027bfd 	stp	x29, x30, [sp, #32]
    8514:	910083fd 	add	x29, sp, #0x20
    8518:	a90563f7 	stp	x23, x24, [sp, #80]
    851c:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    8520:	911742e3 	add	x3, x23, #0x5d0
    8524:	a90353f3 	stp	x19, x20, [sp, #48]
    8528:	a9045bf5 	stp	x21, x22, [sp, #64]
    852c:	aa0003f6 	mov	x22, x0
    8530:	a9066bf9 	stp	x25, x26, [sp, #96]
    8534:	f949ec62 	ldr	x2, [x3, #5080]
    8538:	f9400024 	ldr	x4, [x1]
    853c:	f9000fe4 	str	x4, [sp, #24]
    8540:	d2800004 	mov	x4, #0x0                   	// #0
    8544:	f949d861 	ldr	x1, [x3, #5040]
    8548:	d370bc42 	lsl	x2, x2, #16
    854c:	b40015a0 	cbz	x0, 8800 <f23+0x2fc>
    8550:	f9400818 	ldr	x24, [x0, #16]
    8554:	cb010301 	sub	x1, x24, x1
    8558:	eb02003f 	cmp	x1, x2
    855c:	54000362 	b.cs	85c8 <f23+0xc4>  // b.hs, b.nlast
    8560:	f949fc60 	ldr	x0, [x3, #5112]
    8564:	d350fc22 	lsr	x2, x1, #16
    8568:	8b020842 	add	x2, x2, x2, lsl #2
    856c:	8b020c02 	add	x2, x0, x2, lsl #3
    8570:	f9401040 	ldr	x0, [x2, #32]
    8574:	b40002a0 	cbz	x0, 85c8 <f23+0xc4>
    8578:	39400043 	ldrb	w3, [x2]
    857c:	7100087f 	cmp	w3, #0x2
    8580:	540013a0 	b.eq	87f4 <f23+0x2f0>  // b.none
    8584:	7100047f 	cmp	w3, #0x1
    8588:	540001c1 	b.ne	85c0 <f23+0xbc>  // b.any
    858c:	29430843 	ldp	w3, w2, [x2, #24]
    8590:	92403c21 	and	x1, x1, #0xffff
    8594:	9b037c21 	mul	x1, x1, x3
    8598:	d360fc21 	lsr	x1, x1, #32
    859c:	eb02003f 	cmp	x1, x2
    85a0:	54000102 	b.cs	85c0 <f23+0xbc>  // b.hs, b.nlast
    85a4:	8b010000 	add	x0, x0, x1
    85a8:	39400001 	ldrb	w1, [x0]
    85ac:	340000a1 	cbz	w1, 85c0 <f23+0xbc>
    85b0:	7103f43f 	cmp	w1, #0xfd
    85b4:	54001688 	b.hi	8884 <f23+0x380>  // b.pmore
    85b8:	11000421 	add	w1, w1, #0x1
    85bc:	39000001 	strb	w1, [x0]
    85c0:	d2800000 	mov	x0, #0x0                   	// #0
    85c4:	b40000d6 	cbz	x22, 85dc <f23+0xd8>
    85c8:	aa1603e1 	mov	x1, x22
    85cc:	d2800000 	mov	x0, #0x0                   	// #0
    85d0:	f9400821 	ldr	x1, [x1, #16]
    85d4:	91000400 	add	x0, x0, #0x1
    85d8:	b5ffffc1 	cbnz	x1, 85d0 <f23+0xcc>
    85dc:	b40011b8 	cbz	x24, 8810 <f23+0x30c>
    85e0:	aa1803e1 	mov	x1, x24
    85e4:	d2800002 	mov	x2, #0x0                   	// #0
    85e8:	f9400821 	ldr	x1, [x1, #16]
    85ec:	91000442 	add	x2, x2, #0x1
    85f0:	b5ffffc1 	cbnz	x1, 85e8 <f23+0xe4>
    85f4:	eb00005f 	cmp	x2, x0
    85f8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    85fc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    8600:	eb01033f 	cmp	x25, x1
    8604:	54001468 	b.hi	8890 <f23+0x38c>  // b.pmore
    8608:	d37ffb33 	lsl	x19, x25, #1
    860c:	52800041 	mov	w1, #0x2                   	// #2
    8610:	91000660 	add	x0, x19, #0x1
    8614:	d37df000 	lsl	x0, x0, #3
    8618:	97fff236 	bl	4ef0 <fwp_heap_alloc>
    861c:	911742e1 	add	x1, x23, #0x5d0
    8620:	aa0003fa 	mov	x26, x0
    8624:	f9000013 	str	x19, [x0]
    8628:	aa0103e0 	mov	x0, x1
    862c:	f949d821 	ldr	x1, [x1, #5040]
    8630:	f949ec00 	ldr	x0, [x0, #5080]
    8634:	cb010341 	sub	x1, x26, x1
    8638:	eb00403f 	cmp	x1, x0, lsl #16
    863c:	54000342 	b.cs	86a4 <f23+0x1a0>  // b.hs, b.nlast
    8640:	911742e2 	add	x2, x23, #0x5d0
    8644:	d350fc20 	lsr	x0, x1, #16
    8648:	8b000800 	add	x0, x0, x0, lsl #2
    864c:	f949fc43 	ldr	x3, [x2, #5112]
    8650:	d37df002 	lsl	x2, x0, #3
    8654:	8b020060 	add	x0, x3, x2
    8658:	f9401013 	ldr	x19, [x0, #32]
    865c:	b4000253 	cbz	x19, 86a4 <f23+0x1a0>
    8660:	38626862 	ldrb	w2, [x3, x2]
    8664:	7100085f 	cmp	w2, #0x2
    8668:	54000c00 	b.eq	87e8 <f23+0x2e4>  // b.none
    866c:	7100045f 	cmp	w2, #0x1
    8670:	540001a1 	b.ne	86a4 <f23+0x1a0>  // b.any
    8674:	29430002 	ldp	w2, w0, [x0, #24]
    8678:	92403c21 	and	x1, x1, #0xffff
    867c:	9b027c21 	mul	x1, x1, x2
    8680:	d360fc21 	lsr	x1, x1, #32
    8684:	eb00003f 	cmp	x1, x0
    8688:	540000e2 	b.cs	86a4 <f23+0x1a0>  // b.hs, b.nlast
    868c:	8b010273 	add	x19, x19, x1
    8690:	39400260 	ldrb	w0, [x19]
    8694:	7103fc1f 	cmp	w0, #0xff
    8698:	54000da0 	b.eq	884c <f23+0x348>  // b.none
    869c:	52800020 	mov	w0, #0x1                   	// #1
    86a0:	39000260 	strb	w0, [x19]
    86a4:	b4000259 	cbz	x25, 86ec <f23+0x1e8>
    86a8:	8b191359 	add	x25, x26, x25, lsl #4
    86ac:	aa1a03f3 	mov	x19, x26
    86b0:	aa1603f5 	mov	x21, x22
    86b4:	aa1803f4 	mov	x20, x24
    86b8:	f9400683 	ldr	x3, [x20, #8]
    86bc:	f94006a2 	ldr	x2, [x21, #8]
    86c0:	f9400861 	ldr	x1, [x3, #16]
    86c4:	f9400840 	ldr	x0, [x2, #16]
    86c8:	fd400461 	ldr	d1, [x3, #8]
    86cc:	fd400440 	ldr	d0, [x2, #8]
    86d0:	97fff3b8 	bl	55b0 <w107>
    86d4:	f9000660 	str	x0, [x19, #8]
    86d8:	f8010e61 	str	x1, [x19, #16]!
    86dc:	f9400a94 	ldr	x20, [x20, #16]
    86e0:	f9400ab5 	ldr	x21, [x21, #16]
    86e4:	eb13033f 	cmp	x25, x19
    86e8:	54fffe81 	b.ne	86b8 <f23+0x1b4>  // b.any
    86ec:	aa1803e0 	mov	x0, x24
    86f0:	97fffe91 	bl	8134 <fwp_drop2>
    86f4:	aa1603e0 	mov	x0, x22
    86f8:	97fffe8f 	bl	8134 <fwp_drop2>
    86fc:	911742f7 	add	x23, x23, #0x5d0
    8700:	aa1a03e0 	mov	x0, x26
    8704:	97fff408 	bl	5724 <w164.constprop.0>
    8708:	aa0103f3 	mov	x19, x1
    870c:	aa0003f4 	mov	x20, x0
    8710:	aa1a03e0 	mov	x0, x26
    8714:	97fff8b3 	bl	69e0 <fwp_drop4>
    8718:	a900cff4 	stp	x20, x19, [sp, #8]
    871c:	910023e1 	add	x1, sp, #0x8
    8720:	52800000 	mov	w0, #0x0                   	// #0
    8724:	97fff428 	bl	57c4 <fwp_data.part.0.constprop.0>
    8728:	f949dae1 	ldr	x1, [x23, #5040]
    872c:	aa0003f3 	mov	x19, x0
    8730:	f949eee0 	ldr	x0, [x23, #5080]
    8734:	cb010261 	sub	x1, x19, x1
    8738:	eb00403f 	cmp	x1, x0, lsl #16
    873c:	54000322 	b.cs	87a0 <f23+0x29c>  // b.hs, b.nlast
    8740:	d350fc22 	lsr	x2, x1, #16
    8744:	f949fee3 	ldr	x3, [x23, #5112]
    8748:	8b020842 	add	x2, x2, x2, lsl #2
    874c:	d37df042 	lsl	x2, x2, #3
    8750:	8b020060 	add	x0, x3, x2
    8754:	f9401014 	ldr	x20, [x0, #32]
    8758:	b4000254 	cbz	x20, 87a0 <f23+0x29c>
    875c:	38626862 	ldrb	w2, [x3, x2]
    8760:	7100085f 	cmp	w2, #0x2
    8764:	540003c0 	b.eq	87dc <f23+0x2d8>  // b.none
    8768:	7100045f 	cmp	w2, #0x1
    876c:	540001a1 	b.ne	87a0 <f23+0x29c>  // b.any
    8770:	29430002 	ldp	w2, w0, [x0, #24]
    8774:	92403c21 	and	x1, x1, #0xffff
    8778:	9b027c21 	mul	x1, x1, x2
    877c:	d360fc21 	lsr	x1, x1, #32
    8780:	eb00003f 	cmp	x1, x0
    8784:	540000e2 	b.cs	87a0 <f23+0x29c>  // b.hs, b.nlast
    8788:	8b010294 	add	x20, x20, x1
    878c:	39400280 	ldrb	w0, [x20]
    8790:	7103fc1f 	cmp	w0, #0xff
    8794:	54000620 	b.eq	8858 <f23+0x354>  // b.none
    8798:	52800020 	mov	w0, #0x1                   	// #1
    879c:	39000280 	strb	w0, [x20]
    87a0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    87a4:	f947f400 	ldr	x0, [x0, #4072]
    87a8:	f9400fe2 	ldr	x2, [sp, #24]
    87ac:	f9400001 	ldr	x1, [x0]
    87b0:	eb010042 	subs	x2, x2, x1
    87b4:	d2800001 	mov	x1, #0x0                   	// #0
    87b8:	540006a1 	b.ne	888c <f23+0x388>  // b.any
    87bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    87c0:	aa1303e0 	mov	x0, x19
    87c4:	a94353f3 	ldp	x19, x20, [sp, #48]
    87c8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    87cc:	a94563f7 	ldp	x23, x24, [sp, #80]
    87d0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    87d4:	9101c3ff 	add	sp, sp, #0x70
    87d8:	d65f03c0 	ret
    87dc:	72003c3f 	tst	w1, #0xffff
    87e0:	54fffe01 	b.ne	87a0 <f23+0x29c>  // b.any
    87e4:	17ffffea 	b	878c <f23+0x288>
    87e8:	72003c3f 	tst	w1, #0xffff
    87ec:	54fff5c1 	b.ne	86a4 <f23+0x1a0>  // b.any
    87f0:	17ffffa8 	b	8690 <f23+0x18c>
    87f4:	72003c3f 	tst	w1, #0xffff
    87f8:	54ffee41 	b.ne	85c0 <f23+0xbc>  // b.any
    87fc:	17ffff6b 	b	85a8 <f23+0xa4>
    8800:	cb0103e1 	neg	x1, x1
    8804:	eb02003f 	cmp	x1, x2
    8808:	540002e3 	b.cc	8864 <f23+0x360>  // b.lo, b.ul, b.last
    880c:	d503201f 	nop
    8810:	52800041 	mov	w1, #0x2                   	// #2
    8814:	d2800100 	mov	x0, #0x8                   	// #8
    8818:	97fff1b6 	bl	4ef0 <fwp_heap_alloc>
    881c:	aa0003e1 	mov	x1, x0
    8820:	911742e0 	add	x0, x23, #0x5d0
    8824:	aa0103fa 	mov	x26, x1
    8828:	d2800018 	mov	x24, #0x0                   	// #0
    882c:	f900003f 	str	xzr, [x1]
    8830:	f949d801 	ldr	x1, [x0, #5040]
    8834:	f949ec00 	ldr	x0, [x0, #5080]
    8838:	cb010341 	sub	x1, x26, x1
    883c:	eb00403f 	cmp	x1, x0, lsl #16
    8840:	54fff562 	b.cs	86ec <f23+0x1e8>  // b.hs, b.nlast
    8844:	d2800019 	mov	x25, #0x0                   	// #0
    8848:	17ffff7e 	b	8640 <f23+0x13c>
    884c:	aa1303e0 	mov	x0, x19
    8850:	97ffefe8 	bl	47f0 <fwp_rc_forget_slot>
    8854:	17ffff92 	b	869c <f23+0x198>
    8858:	aa1403e0 	mov	x0, x20
    885c:	97ffefe5 	bl	47f0 <fwp_rc_forget_slot>
    8860:	17ffffce 	b	8798 <f23+0x294>
    8864:	f949fc62 	ldr	x2, [x3, #5112]
    8868:	d350fc20 	lsr	x0, x1, #16
    886c:	8b000800 	add	x0, x0, x0, lsl #2
    8870:	8b000c42 	add	x2, x2, x0, lsl #3
    8874:	f9401040 	ldr	x0, [x2, #32]
    8878:	b4fffcc0 	cbz	x0, 8810 <f23+0x30c>
    887c:	d2800018 	mov	x24, #0x0                   	// #0
    8880:	17ffff3e 	b	8578 <f23+0x74>
    8884:	97ffef94 	bl	46d4 <fwp_rc_wide_dup>
    8888:	17ffff4e 	b	85c0 <f23+0xbc>
    888c:	97ffe7fd 	bl	2880 <__stack_chk_fail@plt>
    8890:	f0000000 	adrp	x0, b000 <__divti3+0x100>
    8894:	912d0000 	add	x0, x0, #0xb40
    8898:	97ffebda 	bl	3800 <fwp_trap>
    889c:	d503201f 	nop

00000000000088a0 <fwp_owned_entry23>:
    88a0:	f9400000 	ldr	x0, [x0]
    88a4:	17ffff18 	b	8504 <f23>
    88a8:	d503201f 	nop
    88ac:	d503201f 	nop

00000000000088b0 <e23>:
    88b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    88b4:	910003fd 	mov	x29, sp
    88b8:	f9000bf3 	str	x19, [sp, #16]
    88bc:	f9400013 	ldr	x19, [x0]
    88c0:	aa1303e0 	mov	x0, x19
    88c4:	97fff408 	bl	58e4 <fwp_rc_share>
    88c8:	aa1303e0 	mov	x0, x19
    88cc:	97ffff0e 	bl	8504 <f23>
    88d0:	aa0003f3 	mov	x19, x0
    88d4:	97fff404 	bl	58e4 <fwp_rc_share>
    88d8:	aa1303e0 	mov	x0, x19
    88dc:	f9400bf3 	ldr	x19, [sp, #16]
    88e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    88e4:	d65f03c0 	ret
    88e8:	d503201f 	nop
    88ec:	d503201f 	nop

00000000000088f0 <fwp_write>:
    88f0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    88f4:	910003fd 	mov	x29, sp
    88f8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    88fc:	f947f484 	ldr	x4, [x4, #4072]
    8900:	a90153f3 	stp	x19, x20, [sp, #16]
    8904:	d10943ff 	sub	sp, sp, #0x250
    8908:	b9400045 	ldr	w5, [x2]
    890c:	aa0003f4 	mov	x20, x0
    8910:	f9400080 	ldr	x0, [x4]
    8914:	f90127e0 	str	x0, [sp, #584]
    8918:	d2800000 	mov	x0, #0x0                   	// #0
    891c:	710064bf 	cmp	w5, #0x19
    8920:	54000408 	b.hi	89a0 <fwp_write+0xb0>  // b.pmore
    8924:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    8928:	aa0103f3 	mov	x19, x1
    892c:	910dc000 	add	x0, x0, #0x370
    8930:	f9013bf5 	str	x21, [sp, #624]
    8934:	f9013ff6 	str	x22, [sp, #632]
    8938:	f90153fb 	str	x27, [sp, #672]
    893c:	f90157fc 	str	x28, [sp, #680]
    8940:	aa0203fc 	mov	x28, x2
    8944:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8948:	10000061 	adr	x1, 8954 <fwp_write+0x64>
    894c:	8b20a820 	add	x0, x1, w0, sxth #2
    8950:	d61f0000 	br	x0
    8954:	910123e0 	add	x0, sp, #0x48
    8958:	aa1303e5 	mov	x5, x19
    895c:	f0000004 	adrp	x4, b000 <__divti3+0x100>
    8960:	aa0003f3 	mov	x19, x0
    8964:	912f0084 	add	x4, x4, #0xbc0
    8968:	d2804003 	mov	x3, #0x200                 	// #512
    896c:	aa0303e1 	mov	x1, x3
    8970:	52800042 	mov	w2, #0x2                   	// #2
    8974:	97ffe79f 	bl	27f0 <__snprintf_chk@plt>
    8978:	aa1303e0 	mov	x0, x19
    897c:	97ffe765 	bl	2710 <strlen@plt>
    8980:	aa1303e1 	mov	x1, x19
    8984:	aa0003e2 	mov	x2, x0
    8988:	aa1403e0 	mov	x0, x20
    898c:	97ffeb01 	bl	3590 <buf_put>
    8990:	f9413bf5 	ldr	x21, [sp, #624]
    8994:	f9413ff6 	ldr	x22, [sp, #632]
    8998:	f94153fb 	ldr	x27, [sp, #672]
    899c:	f94157fc 	ldr	x28, [sp, #680]
    89a0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    89a4:	f947f400 	ldr	x0, [x0, #4072]
    89a8:	f94127e2 	ldr	x2, [sp, #584]
    89ac:	f9400001 	ldr	x1, [x0]
    89b0:	eb010042 	subs	x2, x2, x1
    89b4:	d2800001 	mov	x1, #0x0                   	// #0
    89b8:	540077c1 	b.ne	98b0 <fwp_write+0xfc0>  // b.any
    89bc:	910943ff 	add	sp, sp, #0x250
    89c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    89c4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    89c8:	d65f03c0 	ret
    89cc:	910123e0 	add	x0, sp, #0x48
    89d0:	aa1303e5 	mov	x5, x19
    89d4:	f0000004 	adrp	x4, b000 <__divti3+0x100>
    89d8:	aa0003f3 	mov	x19, x0
    89dc:	912ee084 	add	x4, x4, #0xbb8
    89e0:	d2804003 	mov	x3, #0x200                 	// #512
    89e4:	17ffffe2 	b	896c <fwp_write+0x7c>
    89e8:	71004cbf 	cmp	w5, #0x13
    89ec:	f0000000 	adrp	x0, b000 <__divti3+0x100>
    89f0:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    89f4:	912ea000 	add	x0, x0, #0xba8
    89f8:	912ec021 	add	x1, x1, #0xbb0
    89fc:	d2800082 	mov	x2, #0x4                   	// #4
    8a00:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8a04:	aa1403e0 	mov	x0, x20
    8a08:	f90143f7 	str	x23, [sp, #640]
    8a0c:	d2800016 	mov	x22, #0x0                   	// #0
    8a10:	f90147f8 	str	x24, [sp, #648]
    8a14:	97ffeadf 	bl	3590 <buf_put>
    8a18:	f9400260 	ldr	x0, [x19]
    8a1c:	f0000017 	adrp	x23, b000 <__divti3+0x100>
    8a20:	d2800015 	mov	x21, #0x0                   	// #0
    8a24:	9130c2f7 	add	x23, x23, #0xc30
    8a28:	b40047a0 	cbz	x0, 931c <fwp_write+0xa2c>
    8a2c:	b9400380 	ldr	w0, [x28]
    8a30:	52800003 	mov	w3, #0x0                   	// #0
    8a34:	f9401f82 	ldr	x2, [x28, #56]
    8a38:	71004c1f 	cmp	w0, #0x13
    8a3c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8a40:	aa1403e0 	mov	x0, x20
    8a44:	8b010e61 	add	x1, x19, x1, lsl #3
    8a48:	f9400421 	ldr	x1, [x1, #8]
    8a4c:	97ffffa9 	bl	88f0 <fwp_write>
    8a50:	b9400380 	ldr	w0, [x28]
    8a54:	7100481f 	cmp	w0, #0x12
    8a58:	54004b40 	b.eq	93c0 <fwp_write+0xad0>  // b.none
    8a5c:	f9400260 	ldr	x0, [x19]
    8a60:	910006b5 	add	x21, x21, #0x1
    8a64:	91000ad6 	add	x22, x22, #0x2
    8a68:	eb15001f 	cmp	x0, x21
    8a6c:	54004589 	b.ls	931c <fwp_write+0xa2c>  // b.plast
    8a70:	aa1703e1 	mov	x1, x23
    8a74:	aa1403e0 	mov	x0, x20
    8a78:	d2800042 	mov	x2, #0x2                   	// #2
    8a7c:	97ffeac5 	bl	3590 <buf_put>
    8a80:	17ffffeb 	b	8a2c <fwp_write+0x13c>
    8a84:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8a88:	912fa021 	add	x1, x1, #0xbe8
    8a8c:	d28000c2 	mov	x2, #0x6                   	// #6
    8a90:	aa1403e0 	mov	x0, x20
    8a94:	91004273 	add	x19, x19, #0x10
    8a98:	97ffeabe 	bl	3590 <buf_put>
    8a9c:	aa1303e0 	mov	x0, x19
    8aa0:	97ffe71c 	bl	2710 <strlen@plt>
    8aa4:	aa1303e1 	mov	x1, x19
    8aa8:	aa0003e2 	mov	x2, x0
    8aac:	aa1403e0 	mov	x0, x20
    8ab0:	97ffeab8 	bl	3590 <buf_put>
    8ab4:	528007c3 	mov	w3, #0x3e                  	// #62
    8ab8:	aa1403e0 	mov	x0, x20
    8abc:	91001fe1 	add	x1, sp, #0x7
    8ac0:	d2800022 	mov	x2, #0x1                   	// #1
    8ac4:	39001fe3 	strb	w3, [sp, #7]
    8ac8:	17ffffb1 	b	898c <fwp_write+0x9c>
    8acc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ad0:	f947f400 	ldr	x0, [x0, #4072]
    8ad4:	f94127e2 	ldr	x2, [sp, #584]
    8ad8:	f9400001 	ldr	x1, [x0]
    8adc:	eb010042 	subs	x2, x2, x1
    8ae0:	d2800001 	mov	x1, #0x0                   	// #0
    8ae4:	540034e1 	b.ne	9180 <fwp_write+0x890>  // b.any
    8ae8:	f9413bf5 	ldr	x21, [sp, #624]
    8aec:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8af0:	f9413ff6 	ldr	x22, [sp, #632]
    8af4:	aa1403e0 	mov	x0, x20
    8af8:	912f2021 	add	x1, x1, #0xbc8
    8afc:	d2800142 	mov	x2, #0xa                   	// #10
    8b00:	f94153fb 	ldr	x27, [sp, #672]
    8b04:	f94157fc 	ldr	x28, [sp, #680]
    8b08:	910943ff 	add	sp, sp, #0x250
    8b0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b10:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b14:	17ffea9f 	b	3590 <buf_put>
    8b18:	f9400456 	ldr	x22, [x2, #8]
    8b1c:	f90143f7 	str	x23, [sp, #640]
    8b20:	f90147f8 	str	x24, [sp, #648]
    8b24:	b4005b16 	cbz	x22, 9684 <fwp_write+0xd94>
    8b28:	aa1603e0 	mov	x0, x22
    8b2c:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8b30:	91312021 	add	x1, x1, #0xc48
    8b34:	97ffe773 	bl	2900 <strcmp@plt>
    8b38:	2a0003f5 	mov	w21, w0
    8b3c:	34005fe0 	cbz	w0, 9738 <fwp_write+0xe48>
    8b40:	aa1603e0 	mov	x0, x22
    8b44:	97ffe6f3 	bl	2710 <strlen@plt>
    8b48:	aa1603e1 	mov	x1, x22
    8b4c:	aa0003e2 	mov	x2, x0
    8b50:	aa1403e0 	mov	x0, x20
    8b54:	97ffea8f 	bl	3590 <buf_put>
    8b58:	52800403 	mov	w3, #0x20                  	// #32
    8b5c:	91001ff5 	add	x21, sp, #0x7
    8b60:	aa1503e1 	mov	x1, x21
    8b64:	aa1403e0 	mov	x0, x20
    8b68:	d2800022 	mov	x2, #0x1                   	// #1
    8b6c:	39001fe3 	strb	w3, [sp, #7]
    8b70:	97ffea88 	bl	3590 <buf_put>
    8b74:	52800f63 	mov	w3, #0x7b                  	// #123
    8b78:	aa1403e0 	mov	x0, x20
    8b7c:	aa1503e1 	mov	x1, x21
    8b80:	d2800022 	mov	x2, #0x1                   	// #1
    8b84:	39001fe3 	strb	w3, [sp, #7]
    8b88:	97ffea82 	bl	3590 <buf_put>
    8b8c:	b9401380 	ldr	w0, [x28, #16]
    8b90:	52800018 	mov	w24, #0x0                   	// #0
    8b94:	7100001f 	cmp	w0, #0x0
    8b98:	54003aad 	b.le	92ec <fwp_write+0x9fc>
    8b9c:	f9014bf9 	str	x25, [sp, #656]
    8ba0:	f0000019 	adrp	x25, b000 <__divti3+0x100>
    8ba4:	9131c339 	add	x25, x25, #0xc70
    8ba8:	f9014ffa 	str	x26, [sp, #664]
    8bac:	f000001a 	adrp	x26, b000 <__divti3+0x100>
    8bb0:	9130c35a 	add	x26, x26, #0xc30
    8bb4:	91002276 	add	x22, x19, #0x8
    8bb8:	d2800013 	mov	x19, #0x0                   	// #0
    8bbc:	b5003e93 	cbnz	x19, 938c <fwp_write+0xa9c>
    8bc0:	d37df277 	lsl	x23, x19, #3
    8bc4:	34003cb8 	cbz	w24, 9358 <fwp_write+0xa68>
    8bc8:	f9401382 	ldr	x2, [x28, #32]
    8bcc:	aa1403e0 	mov	x0, x20
    8bd0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8bd4:	52800003 	mov	w3, #0x0                   	// #0
    8bd8:	f8776842 	ldr	x2, [x2, x23]
    8bdc:	91000673 	add	x19, x19, #0x1
    8be0:	97ffff44 	bl	88f0 <fwp_write>
    8be4:	b9401380 	ldr	w0, [x28, #16]
    8be8:	6b13001f 	cmp	w0, w19
    8bec:	54fffe8c 	b.gt	8bbc <fwp_write+0x2cc>
    8bf0:	f9414bf9 	ldr	x25, [sp, #656]
    8bf4:	f9414ffa 	ldr	x26, [sp, #664]
    8bf8:	340037b8 	cbz	w24, 92ec <fwp_write+0x9fc>
    8bfc:	52800523 	mov	w3, #0x29                  	// #41
    8c00:	aa1503e1 	mov	x1, x21
    8c04:	aa1403e0 	mov	x0, x20
    8c08:	d2800022 	mov	x2, #0x1                   	// #1
    8c0c:	39001fe3 	strb	w3, [sp, #7]
    8c10:	97ffea60 	bl	3590 <buf_put>
    8c14:	f9413bf5 	ldr	x21, [sp, #624]
    8c18:	f9413ff6 	ldr	x22, [sp, #632]
    8c1c:	f94143f7 	ldr	x23, [sp, #640]
    8c20:	f94147f8 	ldr	x24, [sp, #648]
    8c24:	f94153fb 	ldr	x27, [sp, #672]
    8c28:	f94157fc 	ldr	x28, [sp, #680]
    8c2c:	17ffff5d 	b	89a0 <fwp_write+0xb0>
    8c30:	b9404855 	ldr	w21, [x2, #72]
    8c34:	aa1403e0 	mov	x0, x20
    8c38:	93407eb6 	sxtw	x22, w21
    8c3c:	91000ac1 	add	x1, x22, #0x2
    8c40:	97ffea21 	bl	34c4 <buf_grow>
    8c44:	a9400281 	ldp	x1, x0, [x20]
    8c48:	528e8603 	mov	w3, #0x7430                	// #29744
    8c4c:	78206823 	strh	w3, [x1, x0]
    8c50:	8b000022 	add	x2, x1, x0
    8c54:	710002bf 	cmp	w21, #0x0
    8c58:	540036cd 	b.le	9330 <fwp_write+0xa40>
    8c5c:	110006a3 	add	w3, w21, #0x1
    8c60:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8c64:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8c68:	91000449 	add	x9, x2, #0x1
    8c6c:	8b23c043 	add	x3, x2, w3, sxtw
    8c70:	f28aaac6 	movk	x6, #0x5556
    8c74:	f2955568 	movk	x8, #0xaaab
    8c78:	1400000d 	b	8cac <fwp_write+0x3bc>
    8c7c:	d2800021 	mov	x1, #0x1                   	// #1
    8c80:	528005a5 	mov	w5, #0x2d                  	// #45
    8c84:	f100001f 	cmp	x0, #0x0
    8c88:	9b467e60 	smulh	x0, x19, x6
    8c8c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8c90:	381ff465 	strb	w5, [x3], #-1
    8c94:	cb040000 	sub	x0, x0, x4
    8c98:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8c9c:	cb020000 	sub	x0, x0, x2
    8ca0:	8b010013 	add	x19, x0, x1
    8ca4:	eb03013f 	cmp	x9, x3
    8ca8:	54003440 	b.eq	9330 <fwp_write+0xa40>  // b.none
    8cac:	9b467e60 	smulh	x0, x19, x6
    8cb0:	937ffe64 	asr	x4, x19, #63
    8cb4:	52800605 	mov	w5, #0x30                  	// #48
    8cb8:	cb040000 	sub	x0, x0, x4
    8cbc:	8b000400 	add	x0, x0, x0, lsl #1
    8cc0:	cb000260 	sub	x0, x19, x0
    8cc4:	91000c01 	add	x1, x0, #0x3
    8cc8:	9bc87c22 	umulh	x2, x1, x8
    8ccc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8cd0:	8b4204e2 	add	x2, x7, x2, lsr #1
    8cd4:	eb020021 	subs	x1, x1, x2
    8cd8:	54fffd60 	b.eq	8c84 <fwp_write+0x394>  // b.none
    8cdc:	f100043f 	cmp	x1, #0x1
    8ce0:	54fffce1 	b.ne	8c7c <fwp_write+0x38c>  // b.any
    8ce4:	d2800001 	mov	x1, #0x0                   	// #0
    8ce8:	52800565 	mov	w5, #0x2b                  	// #43
    8cec:	17ffffe6 	b	8c84 <fwp_write+0x394>
    8cf0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8cf4:	f947f400 	ldr	x0, [x0, #4072]
    8cf8:	f94127e2 	ldr	x2, [sp, #584]
    8cfc:	f9400001 	ldr	x1, [x0]
    8d00:	eb010042 	subs	x2, x2, x1
    8d04:	d2800001 	mov	x1, #0x0                   	// #0
    8d08:	540023c1 	b.ne	9180 <fwp_write+0x890>  // b.any
    8d0c:	f9413bf5 	ldr	x21, [sp, #624]
    8d10:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8d14:	f9413ff6 	ldr	x22, [sp, #632]
    8d18:	aa1403e0 	mov	x0, x20
    8d1c:	912f6021 	add	x1, x1, #0xbd8
    8d20:	d2800102 	mov	x2, #0x8                   	// #8
    8d24:	17ffff77 	b	8b00 <fwp_write+0x210>
    8d28:	aa1403e0 	mov	x0, x20
    8d2c:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8d30:	d28000c2 	mov	x2, #0x6                   	// #6
    8d34:	9130e021 	add	x1, x1, #0xc38
    8d38:	97ffea16 	bl	3590 <buf_put>
    8d3c:	d2800015 	mov	x21, #0x0                   	// #0
    8d40:	f9400263 	ldr	x3, [x19]
    8d44:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8d48:	54002c60 	b.eq	92d4 <fwp_write+0x9e4>  // b.none
    8d4c:	f9401f82 	ldr	x2, [x28, #56]
    8d50:	f90143f7 	str	x23, [sp, #640]
    8d54:	f90147f8 	str	x24, [sp, #648]
    8d58:	d2800857 	mov	x23, #0x42                  	// #66
    8d5c:	f9014bf9 	str	x25, [sp, #656]
    8d60:	f0000016 	adrp	x22, b000 <__divti3+0x100>
    8d64:	f9014ffa 	str	x26, [sp, #664]
    8d68:	9130c2d6 	add	x22, x22, #0xc30
    8d6c:	d2800038 	mov	x24, #0x1                   	// #1
    8d70:	f2a18017 	movk	x23, #0xc00, lsl #16
    8d74:	d2809099 	mov	x25, #0x484                 	// #1156
    8d78:	b40004a2 	cbz	x2, 8e0c <fwp_write+0x51c>
    8d7c:	b9400040 	ldr	w0, [x2]
    8d80:	7100701f 	cmp	w0, #0x1c
    8d84:	540042c0 	b.eq	95dc <fwp_write+0xcec>  // b.none
    8d88:	71006c1f 	cmp	w0, #0x1b
    8d8c:	54000408 	b.hi	8e0c <fwp_write+0x51c>  // b.pmore
    8d90:	9ac02301 	lsl	x1, x24, x0
    8d94:	ea17003f 	tst	x1, x23
    8d98:	540036a1 	b.ne	946c <fwp_write+0xb7c>  // b.any
    8d9c:	ea19003f 	tst	x1, x25
    8da0:	54003521 	b.ne	9444 <fwp_write+0xb54>  // b.any
    8da4:	d2800424 	mov	x4, #0x21                  	// #33
    8da8:	ea04003f 	tst	x1, x4
    8dac:	54000300 	b.eq	8e0c <fwp_write+0x51c>  // b.none
    8db0:	b7f849c3 	tbnz	x3, #63, 96e8 <fwp_write+0xdf8>
    8db4:	91002261 	add	x1, x19, #0x8
    8db8:	8b150021 	add	x1, x1, x21
    8dbc:	39400021 	ldrb	w1, [x1]
    8dc0:	7100001f 	cmp	w0, #0x0
    8dc4:	93401c23 	sxtb	x3, w1
    8dc8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8dcc:	d503201f 	nop
    8dd0:	aa1403e0 	mov	x0, x20
    8dd4:	52800003 	mov	w3, #0x0                   	// #0
    8dd8:	97fffec6 	bl	88f0 <fwp_write>
    8ddc:	910006b5 	add	x21, x21, #0x1
    8de0:	f9400260 	ldr	x0, [x19]
    8de4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8de8:	eb0002bf 	cmp	x21, x0
    8dec:	540026c2 	b.cs	92c4 <fwp_write+0x9d4>  // b.hs, b.nlast
    8df0:	d2800042 	mov	x2, #0x2                   	// #2
    8df4:	aa1603e1 	mov	x1, x22
    8df8:	aa1403e0 	mov	x0, x20
    8dfc:	97ffe9e5 	bl	3590 <buf_put>
    8e00:	f9401f82 	ldr	x2, [x28, #56]
    8e04:	f9400263 	ldr	x3, [x19]
    8e08:	b5fffba2 	cbnz	x2, 8d7c <fwp_write+0x48c>
    8e0c:	d37df2a0 	lsl	x0, x21, #3
    8e10:	b7f83f03 	tbnz	x3, #63, 95f0 <fwp_write+0xd00>
    8e14:	91002261 	add	x1, x19, #0x8
    8e18:	8b000020 	add	x0, x1, x0
    8e1c:	f9400001 	ldr	x1, [x0]
    8e20:	17ffffec 	b	8dd0 <fwp_write+0x4e0>
    8e24:	a9400e62 	ldp	x2, x3, [x19]
    8e28:	b7f83ca3 	tbnz	x3, #63, 95bc <fwp_write+0xccc>
    8e2c:	910123f5 	add	x21, sp, #0x48
    8e30:	aa1503e0 	mov	x0, x21
    8e34:	97ffe7fb 	bl	2e20 <fwp_fmt_u128>
    8e38:	aa1503e0 	mov	x0, x21
    8e3c:	97ffe635 	bl	2710 <strlen@plt>
    8e40:	aa1503e1 	mov	x1, x21
    8e44:	aa0003e2 	mov	x2, x0
    8e48:	17fffed0 	b	8988 <fwp_write+0x98>
    8e4c:	fd015be8 	str	d8, [sp, #688]
    8e50:	1e270268 	fmov	s8, w19
    8e54:	fd015fe9 	str	d9, [sp, #696]
    8e58:	1e282100 	fcmp	s8, s8
    8e5c:	54004d26 	b.vs	9800 <fwp_write+0xf10>
    8e60:	1e20c101 	fabs	s1, s8
    8e64:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8e68:	1e270000 	fmov	s0, w0
    8e6c:	1e202020 	fcmp	s1, s0
    8e70:	54002c0d 	b.le	93f0 <fwp_write+0xb00>
    8e74:	1e202118 	fcmpe	s8, #0.0
    8e78:	f0000002 	adrp	x2, b000 <__divti3+0x100>
    8e7c:	911be042 	add	x2, x2, #0x6f8
    8e80:	910123f5 	add	x21, sp, #0x48
    8e84:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8e88:	912e2021 	add	x1, x1, #0xb88
    8e8c:	aa1503e0 	mov	x0, x21
    8e90:	9a81c041 	csel	x1, x2, x1, gt
    8e94:	97ffe6cb 	bl	29c0 <strcpy@plt>
    8e98:	aa1503e0 	mov	x0, x21
    8e9c:	97ffe61d 	bl	2710 <strlen@plt>
    8ea0:	aa1503e1 	mov	x1, x21
    8ea4:	aa0003e2 	mov	x2, x0
    8ea8:	aa1403e0 	mov	x0, x20
    8eac:	97ffe9b9 	bl	3590 <buf_put>
    8eb0:	f9413bf5 	ldr	x21, [sp, #624]
    8eb4:	f9413ff6 	ldr	x22, [sp, #632]
    8eb8:	f94153fb 	ldr	x27, [sp, #672]
    8ebc:	f94157fc 	ldr	x28, [sp, #680]
    8ec0:	fd415be8 	ldr	d8, [sp, #688]
    8ec4:	fd415fe9 	ldr	d9, [sp, #696]
    8ec8:	17fffeb6 	b	89a0 <fwp_write+0xb0>
    8ecc:	f9400276 	ldr	x22, [x19]
    8ed0:	34002e03 	cbz	w3, 9490 <fwp_write+0xba0>
    8ed4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ed8:	f947f400 	ldr	x0, [x0, #4072]
    8edc:	f94127e2 	ldr	x2, [sp, #584]
    8ee0:	f9400001 	ldr	x1, [x0]
    8ee4:	eb010042 	subs	x2, x2, x1
    8ee8:	d2800001 	mov	x1, #0x0                   	// #0
    8eec:	540014a1 	b.ne	9180 <fwp_write+0x890>  // b.any
    8ef0:	aa1603e2 	mov	x2, x22
    8ef4:	91002261 	add	x1, x19, #0x8
    8ef8:	f9413bf5 	ldr	x21, [sp, #624]
    8efc:	aa1403e0 	mov	x0, x20
    8f00:	f9413ff6 	ldr	x22, [sp, #632]
    8f04:	17fffeff 	b	8b00 <fwp_write+0x210>
    8f08:	fd015be8 	str	d8, [sp, #688]
    8f0c:	9e670268 	fmov	d8, x19
    8f10:	fd015fe9 	str	d9, [sp, #696]
    8f14:	1e682100 	fcmp	d8, d8
    8f18:	54004746 	b.vs	9800 <fwp_write+0xf10>
    8f1c:	1e60c101 	fabs	d1, d8
    8f20:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8f24:	9e670000 	fmov	d0, x0
    8f28:	910123f5 	add	x21, sp, #0x48
    8f2c:	52800033 	mov	w19, #0x1                   	// #1
    8f30:	1e602020 	fcmp	d1, d0
    8f34:	540001ad 	b.le	8f68 <fwp_write+0x678>
    8f38:	1e602118 	fcmpe	d8, #0.0
    8f3c:	f0000002 	adrp	x2, b000 <__divti3+0x100>
    8f40:	911be042 	add	x2, x2, #0x6f8
    8f44:	f0000001 	adrp	x1, b000 <__divti3+0x100>
    8f48:	912e2021 	add	x1, x1, #0xb88
    8f4c:	aa1503e0 	mov	x0, x21
    8f50:	9a81c041 	csel	x1, x2, x1, gt
    8f54:	97ffe69b 	bl	29c0 <strcpy@plt>
    8f58:	17ffffd0 	b	8e98 <fwp_write+0x5a8>
    8f5c:	11000673 	add	w19, w19, #0x1
    8f60:	71004a7f 	cmp	w19, #0x12
    8f64:	54003860 	b.eq	9670 <fwp_write+0xd80>  // b.none
    8f68:	1e604100 	fmov	d0, d8
    8f6c:	2a1303e1 	mov	w1, w19
    8f70:	aa1503e0 	mov	x0, x21
    8f74:	97ffeb08 	bl	3b94 <fwp_format_g.constprop.0>
    8f78:	aa1503e0 	mov	x0, x21
    8f7c:	d2800001 	mov	x1, #0x0                   	// #0
    8f80:	97ffe5f8 	bl	2760 <strtod@plt>
    8f84:	1e602100 	fcmp	d8, d0
    8f88:	54fffea1 	b.ne	8f5c <fwp_write+0x66c>  // b.any
    8f8c:	aa1503e0 	mov	x0, x21
    8f90:	97ffe9f9 	bl	3774 <fwp_finish_float>
    8f94:	17ffffc1 	b	8e98 <fwp_write+0x5a8>
    8f98:	a9400e62 	ldp	x2, x3, [x19]
    8f9c:	910123f3 	add	x19, sp, #0x48
    8fa0:	aa1303e0 	mov	x0, x19
    8fa4:	97ffe79f 	bl	2e20 <fwp_fmt_u128>
    8fa8:	17fffe74 	b	8978 <fwp_write+0x88>
    8fac:	f90143f7 	str	x23, [sp, #640]
    8fb0:	f90147f8 	str	x24, [sp, #648]
    8fb4:	2a1303f8 	mov	w24, w19
    8fb8:	f9014bf9 	str	x25, [sp, #656]
    8fbc:	f9014ffa 	str	x26, [sp, #664]
    8fc0:	f13ffe7f 	cmp	x19, #0xfff
    8fc4:	54000049 	b.ls	8fcc <fwp_write+0x6dc>  // b.plast
    8fc8:	b9400278 	ldr	w24, [x19]
    8fcc:	f9400f80 	ldr	x0, [x28, #24]
    8fd0:	2a1803f5 	mov	w21, w24
    8fd4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8fd8:	d37ef6b9 	lsl	x25, x21, #2
    8fdc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8fe0:	aa1603e0 	mov	x0, x22
    8fe4:	97ffe5cb 	bl	2710 <strlen@plt>
    8fe8:	aa1603e1 	mov	x1, x22
    8fec:	aa0003e2 	mov	x2, x0
    8ff0:	aa1403e0 	mov	x0, x20
    8ff4:	97ffe967 	bl	3590 <buf_put>
    8ff8:	f9401780 	ldr	x0, [x28, #40]
    8ffc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9000:	7100001f 	cmp	w0, #0x0
    9004:	5400068d 	b.le	90d4 <fwp_write+0x7e4>
    9008:	91002276 	add	x22, x19, #0x8
    900c:	91001ff5 	add	x21, sp, #0x7
    9010:	d280001b 	mov	x27, #0x0                   	// #0
    9014:	5280041a 	mov	w26, #0x20                  	// #32
    9018:	f9401b80 	ldr	x0, [x28, #48]
    901c:	aa1503e1 	mov	x1, x21
    9020:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9024:	d2800022 	mov	x2, #0x1                   	// #1
    9028:	f8786803 	ldr	x3, [x0, x24]
    902c:	aa1403e0 	mov	x0, x20
    9030:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9034:	39001ffa 	strb	w26, [sp, #7]
    9038:	97ffe956 	bl	3590 <buf_put>
    903c:	f13ffeff 	cmp	x23, #0xfff
    9040:	b9400261 	ldr	w1, [x19]
    9044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9048:	7100383f 	cmp	w1, #0xe
    904c:	54000160 	b.eq	9078 <fwp_write+0x788>  // b.none
    9050:	7100403f 	cmp	w1, #0x10
    9054:	54001a60 	b.eq	93a0 <fwp_write+0xab0>  // b.none
    9058:	7100283f 	cmp	w1, #0xa
    905c:	54002aa0 	b.eq	95b0 <fwp_write+0xcc0>  // b.none
    9060:	540014ac 	b.gt	92f4 <fwp_write+0xa04>
    9064:	71000c3f 	cmp	w1, #0x3
    9068:	540029ac 	b.gt	959c <fwp_write+0xcac>
    906c:	d37ffee0 	lsr	x0, x23, #63
    9070:	37f814a1 	tbnz	w1, #31, 9304 <fwp_write+0xa14>
    9074:	d503201f 	nop
    9078:	34001460 	cbz	w0, 9304 <fwp_write+0xa14>
    907c:	52800503 	mov	w3, #0x28                  	// #40
    9080:	aa1503e1 	mov	x1, x21
    9084:	aa1403e0 	mov	x0, x20
    9088:	d2800022 	mov	x2, #0x1                   	// #1
    908c:	39001fe3 	strb	w3, [sp, #7]
    9090:	97ffe940 	bl	3590 <buf_put>
    9094:	aa1303e2 	mov	x2, x19
    9098:	aa1703e1 	mov	x1, x23
    909c:	aa1403e0 	mov	x0, x20
    90a0:	52800003 	mov	w3, #0x0                   	// #0
    90a4:	97fffe13 	bl	88f0 <fwp_write>
    90a8:	52800523 	mov	w3, #0x29                  	// #41
    90ac:	aa1503e1 	mov	x1, x21
    90b0:	aa1403e0 	mov	x0, x20
    90b4:	d2800022 	mov	x2, #0x1                   	// #1
    90b8:	39001fe3 	strb	w3, [sp, #7]
    90bc:	97ffe935 	bl	3590 <buf_put>
    90c0:	f9401780 	ldr	x0, [x28, #40]
    90c4:	9100077b 	add	x27, x27, #0x1
    90c8:	b8796800 	ldr	w0, [x0, x25]
    90cc:	6b1b001f 	cmp	w0, w27
    90d0:	54fffa4c 	b.gt	9018 <fwp_write+0x728>
    90d4:	f9413bf5 	ldr	x21, [sp, #624]
    90d8:	f9413ff6 	ldr	x22, [sp, #632]
    90dc:	f94143f7 	ldr	x23, [sp, #640]
    90e0:	f94147f8 	ldr	x24, [sp, #648]
    90e4:	f9414bf9 	ldr	x25, [sp, #656]
    90e8:	f9414ffa 	ldr	x26, [sp, #664]
    90ec:	f94153fb 	ldr	x27, [sp, #672]
    90f0:	f94157fc 	ldr	x28, [sp, #680]
    90f4:	17fffe2b 	b	89a0 <fwp_write+0xb0>
    90f8:	52800783 	mov	w3, #0x3c                  	// #60
    90fc:	91001ff3 	add	x19, sp, #0x7
    9100:	aa1303e1 	mov	x1, x19
    9104:	d2800022 	mov	x2, #0x1                   	// #1
    9108:	aa1403e0 	mov	x0, x20
    910c:	39001fe3 	strb	w3, [sp, #7]
    9110:	97ffe920 	bl	3590 <buf_put>
    9114:	f9400795 	ldr	x21, [x28, #8]
    9118:	aa1503e0 	mov	x0, x21
    911c:	97ffe57d 	bl	2710 <strlen@plt>
    9120:	aa1503e1 	mov	x1, x21
    9124:	aa0003e2 	mov	x2, x0
    9128:	aa1403e0 	mov	x0, x20
    912c:	97ffe919 	bl	3590 <buf_put>
    9130:	528007c3 	mov	w3, #0x3e                  	// #62
    9134:	aa1303e1 	mov	x1, x19
    9138:	aa1403e0 	mov	x0, x20
    913c:	d2800022 	mov	x2, #0x1                   	// #1
    9140:	39001fe3 	strb	w3, [sp, #7]
    9144:	17fffe12 	b	898c <fwp_write+0x9c>
    9148:	f100067f 	cmp	x19, #0x1
    914c:	540025a0 	b.eq	9600 <fwp_write+0xd10>  // b.none
    9150:	b100067f 	cmn	x19, #0x1
    9154:	54002bc0 	b.eq	96cc <fwp_write+0xddc>  // b.none
    9158:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    915c:	912e4021 	add	x1, x1, #0xb90
    9160:	d2800022 	mov	x2, #0x1                   	// #1
    9164:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9168:	f947f400 	ldr	x0, [x0, #4072]
    916c:	f94127e4 	ldr	x4, [sp, #584]
    9170:	f9400003 	ldr	x3, [x0]
    9174:	eb030084 	subs	x4, x4, x3
    9178:	d2800003 	mov	x3, #0x0                   	// #0
    917c:	54ffebe0 	b.eq	8ef8 <fwp_write+0x608>  // b.none
    9180:	f90143f7 	str	x23, [sp, #640]
    9184:	f90147f8 	str	x24, [sp, #648]
    9188:	f9014bf9 	str	x25, [sp, #656]
    918c:	f9014ffa 	str	x26, [sp, #664]
    9190:	fd015be8 	str	d8, [sp, #688]
    9194:	fd015fe9 	str	d9, [sp, #696]
    9198:	97ffe5ba 	bl	2880 <__stack_chk_fail@plt>
    919c:	52800b63 	mov	w3, #0x5b                  	// #91
    91a0:	91001ff5 	add	x21, sp, #0x7
    91a4:	aa1503e1 	mov	x1, x21
    91a8:	aa1403e0 	mov	x0, x20
    91ac:	d2800022 	mov	x2, #0x1                   	// #1
    91b0:	d0000016 	adrp	x22, b000 <__divti3+0x100>
    91b4:	9130c2d6 	add	x22, x22, #0xc30
    91b8:	39001fe3 	strb	w3, [sp, #7]
    91bc:	97ffe8f5 	bl	3590 <buf_put>
    91c0:	b4000273 	cbz	x19, 920c <fwp_write+0x91c>
    91c4:	f9400661 	ldr	x1, [x19, #8]
    91c8:	aa1403e0 	mov	x0, x20
    91cc:	f9401f82 	ldr	x2, [x28, #56]
    91d0:	52800003 	mov	w3, #0x0                   	// #0
    91d4:	97fffdc7 	bl	88f0 <fwp_write>
    91d8:	f9400a73 	ldr	x19, [x19, #16]
    91dc:	b4000193 	cbz	x19, 920c <fwp_write+0x91c>
    91e0:	aa1603e1 	mov	x1, x22
    91e4:	aa1403e0 	mov	x0, x20
    91e8:	d2800042 	mov	x2, #0x2                   	// #2
    91ec:	97ffe8e9 	bl	3590 <buf_put>
    91f0:	f9400661 	ldr	x1, [x19, #8]
    91f4:	aa1403e0 	mov	x0, x20
    91f8:	f9401f82 	ldr	x2, [x28, #56]
    91fc:	52800003 	mov	w3, #0x0                   	// #0
    9200:	97fffdbc 	bl	88f0 <fwp_write>
    9204:	f9400a73 	ldr	x19, [x19, #16]
    9208:	b5fffed3 	cbnz	x19, 91e0 <fwp_write+0x8f0>
    920c:	52800ba3 	mov	w3, #0x5d                  	// #93
    9210:	aa1503e1 	mov	x1, x21
    9214:	aa1403e0 	mov	x0, x20
    9218:	d2800022 	mov	x2, #0x1                   	// #1
    921c:	39001fe3 	strb	w3, [sp, #7]
    9220:	17fffddb 	b	898c <fwp_write+0x9c>
    9224:	aa1403e0 	mov	x0, x20
    9228:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    922c:	d28000c2 	mov	x2, #0x6                   	// #6
    9230:	91308021 	add	x1, x1, #0xc20
    9234:	97ffe8d7 	bl	3590 <buf_put>
    9238:	f9400260 	ldr	x0, [x19]
    923c:	b40004c0 	cbz	x0, 92d4 <fwp_write+0x9e4>
    9240:	910123f5 	add	x21, sp, #0x48
    9244:	91002276 	add	x22, x19, #0x8
    9248:	f90143f7 	str	x23, [sp, #640]
    924c:	d2800017 	mov	x23, #0x0                   	// #0
    9250:	f90147f8 	str	x24, [sp, #648]
    9254:	d0000018 	adrp	x24, b000 <__divti3+0x100>
    9258:	9130a318 	add	x24, x24, #0xc28
    925c:	f9014bf9 	str	x25, [sp, #656]
    9260:	d0000019 	adrp	x25, b000 <__divti3+0x100>
    9264:	9130c339 	add	x25, x25, #0xc30
    9268:	f9014ffa 	str	x26, [sp, #664]
    926c:	14000005 	b	9280 <fwp_write+0x990>
    9270:	aa1903e1 	mov	x1, x25
    9274:	aa1403e0 	mov	x0, x20
    9278:	d2800042 	mov	x2, #0x2                   	// #2
    927c:	97ffe8c5 	bl	3590 <buf_put>
    9280:	38776ac5 	ldrb	w5, [x22, x23]
    9284:	d2804003 	mov	x3, #0x200                 	// #512
    9288:	aa1803e4 	mov	x4, x24
    928c:	aa0303e1 	mov	x1, x3
    9290:	52800042 	mov	w2, #0x2                   	// #2
    9294:	aa1503e0 	mov	x0, x21
    9298:	910006f7 	add	x23, x23, #0x1
    929c:	97ffe555 	bl	27f0 <__snprintf_chk@plt>
    92a0:	aa1503e0 	mov	x0, x21
    92a4:	97ffe51b 	bl	2710 <strlen@plt>
    92a8:	aa1503e1 	mov	x1, x21
    92ac:	aa0003e2 	mov	x2, x0
    92b0:	aa1403e0 	mov	x0, x20
    92b4:	97ffe8b7 	bl	3590 <buf_put>
    92b8:	f9400260 	ldr	x0, [x19]
    92bc:	eb17001f 	cmp	x0, x23
    92c0:	54fffd88 	b.hi	9270 <fwp_write+0x980>  // b.pmore
    92c4:	f94143f7 	ldr	x23, [sp, #640]
    92c8:	f94147f8 	ldr	x24, [sp, #648]
    92cc:	f9414bf9 	ldr	x25, [sp, #656]
    92d0:	f9414ffa 	ldr	x26, [sp, #664]
    92d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    92d8:	aa1403e0 	mov	x0, x20
    92dc:	91001fe1 	add	x1, sp, #0x7
    92e0:	d2800022 	mov	x2, #0x1                   	// #1
    92e4:	39001fe3 	strb	w3, [sp, #7]
    92e8:	17fffda9 	b	898c <fwp_write+0x9c>
    92ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    92f0:	17fffe44 	b	8c00 <fwp_write+0x310>
    92f4:	f10002ff 	cmp	x23, #0x0
    92f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    92fc:	71002c3f 	cmp	w1, #0xb
    9300:	54ffebc0 	b.eq	9078 <fwp_write+0x788>  // b.none
    9304:	aa1303e2 	mov	x2, x19
    9308:	aa1703e1 	mov	x1, x23
    930c:	aa1403e0 	mov	x0, x20
    9310:	52800003 	mov	w3, #0x0                   	// #0
    9314:	97fffd77 	bl	88f0 <fwp_write>
    9318:	17ffff6a 	b	90c0 <fwp_write+0x7d0>
    931c:	aa1403e0 	mov	x0, x20
    9320:	91001fe1 	add	x1, sp, #0x7
    9324:	52800fa3 	mov	w3, #0x7d                  	// #125
    9328:	d2800022 	mov	x2, #0x1                   	// #1
    932c:	17fffe38 	b	8c0c <fwp_write+0x31c>
    9330:	a9400281 	ldp	x1, x0, [x20]
    9334:	91000800 	add	x0, x0, #0x2
    9338:	8b160000 	add	x0, x0, x22
    933c:	f9000680 	str	x0, [x20, #8]
    9340:	3820683f 	strb	wzr, [x1, x0]
    9344:	f9413bf5 	ldr	x21, [sp, #624]
    9348:	f9413ff6 	ldr	x22, [sp, #632]
    934c:	f94153fb 	ldr	x27, [sp, #672]
    9350:	f94157fc 	ldr	x28, [sp, #680]
    9354:	17fffd93 	b	89a0 <fwp_write+0xb0>
    9358:	f9400f80 	ldr	x0, [x28, #24]
    935c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9360:	aa1b03e0 	mov	x0, x27
    9364:	97ffe4eb 	bl	2710 <strlen@plt>
    9368:	aa1b03e1 	mov	x1, x27
    936c:	aa0003e2 	mov	x2, x0
    9370:	aa1403e0 	mov	x0, x20
    9374:	97ffe887 	bl	3590 <buf_put>
    9378:	aa1903e1 	mov	x1, x25
    937c:	aa1403e0 	mov	x0, x20
    9380:	d2800062 	mov	x2, #0x3                   	// #3
    9384:	97ffe883 	bl	3590 <buf_put>
    9388:	17fffe10 	b	8bc8 <fwp_write+0x2d8>
    938c:	aa1a03e1 	mov	x1, x26
    9390:	aa1403e0 	mov	x0, x20
    9394:	d2800042 	mov	x2, #0x2                   	// #2
    9398:	97ffe87e 	bl	3590 <buf_put>
    939c:	17fffe09 	b	8bc0 <fwp_write+0x2d0>
    93a0:	f9400660 	ldr	x0, [x19, #8]
    93a4:	b4fffb00 	cbz	x0, 9304 <fwp_write+0xa14>
    93a8:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    93ac:	91312021 	add	x1, x1, #0xc48
    93b0:	97ffe554 	bl	2900 <strcmp@plt>
    93b4:	7100001f 	cmp	w0, #0x0
    93b8:	1a9f07e0 	cset	w0, ne	// ne = any
    93bc:	17ffff2f 	b	9078 <fwp_write+0x788>
    93c0:	aa1403e0 	mov	x0, x20
    93c4:	d2800042 	mov	x2, #0x2                   	// #2
    93c8:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    93cc:	91310021 	add	x1, x1, #0xc40
    93d0:	97ffe870 	bl	3590 <buf_put>
    93d4:	91004261 	add	x1, x19, #0x10
    93d8:	aa1403e0 	mov	x0, x20
    93dc:	f9402382 	ldr	x2, [x28, #64]
    93e0:	52800003 	mov	w3, #0x0                   	// #0
    93e4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    93e8:	97fffd42 	bl	88f0 <fwp_write>
    93ec:	17fffd9c 	b	8a5c <fwp_write+0x16c>
    93f0:	1e22c109 	fcvt	d9, s8
    93f4:	910123f5 	add	x21, sp, #0x48
    93f8:	52800033 	mov	w19, #0x1                   	// #1
    93fc:	d503201f 	nop
    9400:	1e604120 	fmov	d0, d9
    9404:	2a1303e1 	mov	w1, w19
    9408:	aa1503e0 	mov	x0, x21
    940c:	97ffe9e2 	bl	3b94 <fwp_format_g.constprop.0>
    9410:	aa1503e0 	mov	x0, x21
    9414:	d2800001 	mov	x1, #0x0                   	// #0
    9418:	97ffe546 	bl	2930 <strtof@plt>
    941c:	1e202100 	fcmp	s8, s0
    9420:	54ffdb60 	b.eq	8f8c <fwp_write+0x69c>  // b.none
    9424:	11000673 	add	w19, w19, #0x1
    9428:	71002a7f 	cmp	w19, #0xa
    942c:	54fffea1 	b.ne	9400 <fwp_write+0xb10>  // b.any
    9430:	1e604120 	fmov	d0, d9
    9434:	aa1503e0 	mov	x0, x21
    9438:	52800121 	mov	w1, #0x9                   	// #9
    943c:	97ffe9d6 	bl	3b94 <fwp_format_g.constprop.0>
    9440:	17fffed3 	b	8f8c <fwp_write+0x69c>
    9444:	d37ef6a1 	lsl	x1, x21, #2
    9448:	b7f81563 	tbnz	x3, #63, 96f4 <fwp_write+0xe04>
    944c:	91002263 	add	x3, x19, #0x8
    9450:	8b010061 	add	x1, x3, x1
    9454:	b9400023 	ldr	w3, [x1]
    9458:	7100081f 	cmp	w0, #0x2
    945c:	2a0303e1 	mov	w1, w3
    9460:	93407c63 	sxtw	x3, w3
    9464:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9468:	17fffe5a 	b	8dd0 <fwp_write+0x4e0>
    946c:	d37ffaa1 	lsl	x1, x21, #1
    9470:	b7f81363 	tbnz	x3, #63, 96dc <fwp_write+0xdec>
    9474:	91002263 	add	x3, x19, #0x8
    9478:	8b010061 	add	x1, x3, x1
    947c:	79400021 	ldrh	w1, [x1]
    9480:	7100041f 	cmp	w0, #0x1
    9484:	93403c23 	sxth	x3, w1
    9488:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    948c:	17fffe51 	b	8dd0 <fwp_write+0x4e0>
    9490:	52800443 	mov	w3, #0x22                  	// #34
    9494:	91001ff5 	add	x21, sp, #0x7
    9498:	91002273 	add	x19, x19, #0x8
    949c:	aa1503e1 	mov	x1, x21
    94a0:	aa1403e0 	mov	x0, x20
    94a4:	d2800022 	mov	x2, #0x1                   	// #1
    94a8:	39001fe3 	strb	w3, [sp, #7]
    94ac:	f90143f7 	str	x23, [sp, #640]
    94b0:	8b160277 	add	x23, x19, x22
    94b4:	f90147f8 	str	x24, [sp, #648]
    94b8:	97ffe836 	bl	3590 <buf_put>
    94bc:	b4000696 	cbz	x22, 958c <fwp_write+0xc9c>
    94c0:	d0000018 	adrp	x24, b000 <__divti3+0x100>
    94c4:	912fc318 	add	x24, x24, #0xbf0
    94c8:	f9014bf9 	str	x25, [sp, #656]
    94cc:	d0000019 	adrp	x25, b000 <__divti3+0x100>
    94d0:	91304339 	add	x25, x25, #0xc10
    94d4:	f9014ffa 	str	x26, [sp, #664]
    94d8:	1400000d 	b	950c <fwp_write+0xc1c>
    94dc:	710024bf 	cmp	w5, #0x9
    94e0:	54000460 	b.eq	956c <fwp_write+0xc7c>  // b.none
    94e4:	710028bf 	cmp	w5, #0xa
    94e8:	54000a61 	b.ne	9634 <fwp_write+0xd44>  // b.any
    94ec:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    94f0:	aa1403e0 	mov	x0, x20
    94f4:	91300021 	add	x1, x1, #0xc00
    94f8:	d2800042 	mov	x2, #0x2                   	// #2
    94fc:	97ffe825 	bl	3590 <buf_put>
    9500:	91000673 	add	x19, x19, #0x1
    9504:	eb17027f 	cmp	x19, x23
    9508:	540003e0 	b.eq	9584 <fwp_write+0xc94>  // b.none
    950c:	39400265 	ldrb	w5, [x19]
    9510:	710034bf 	cmp	w5, #0xd
    9514:	54000180 	b.eq	9544 <fwp_write+0xc54>  // b.none
    9518:	54fffe29 	b.ls	94dc <fwp_write+0xbec>  // b.plast
    951c:	710088bf 	cmp	w5, #0x22
    9520:	540001c0 	b.eq	9558 <fwp_write+0xc68>  // b.none
    9524:	710170bf 	cmp	w5, #0x5c
    9528:	54000741 	b.ne	9610 <fwp_write+0xd20>  // b.any
    952c:	aa1403e0 	mov	x0, x20
    9530:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    9534:	d2800042 	mov	x2, #0x2                   	// #2
    9538:	912fe021 	add	x1, x1, #0xbf8
    953c:	97ffe815 	bl	3590 <buf_put>
    9540:	17fffff0 	b	9500 <fwp_write+0xc10>
    9544:	aa1903e1 	mov	x1, x25
    9548:	aa1403e0 	mov	x0, x20
    954c:	d2800042 	mov	x2, #0x2                   	// #2
    9550:	97ffe810 	bl	3590 <buf_put>
    9554:	17ffffeb 	b	9500 <fwp_write+0xc10>
    9558:	aa1803e1 	mov	x1, x24
    955c:	aa1403e0 	mov	x0, x20
    9560:	d2800042 	mov	x2, #0x2                   	// #2
    9564:	97ffe80b 	bl	3590 <buf_put>
    9568:	17ffffe6 	b	9500 <fwp_write+0xc10>
    956c:	aa1403e0 	mov	x0, x20
    9570:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    9574:	d2800042 	mov	x2, #0x2                   	// #2
    9578:	91302021 	add	x1, x1, #0xc08
    957c:	97ffe805 	bl	3590 <buf_put>
    9580:	17ffffe0 	b	9500 <fwp_write+0xc10>
    9584:	f9414bf9 	ldr	x25, [sp, #656]
    9588:	f9414ffa 	ldr	x26, [sp, #664]
    958c:	aa1503e1 	mov	x1, x21
    9590:	aa1403e0 	mov	x0, x20
    9594:	52800443 	mov	w3, #0x22                  	// #34
    9598:	17fffd9c 	b	8c08 <fwp_write+0x318>
    959c:	7100103f 	cmp	w1, #0x4
    95a0:	54ffeb21 	b.ne	9304 <fwp_write+0xa14>  // b.any
    95a4:	f94006e0 	ldr	x0, [x23, #8]
    95a8:	d37ffc00 	lsr	x0, x0, #63
    95ac:	17fffeb3 	b	9078 <fwp_write+0x788>
    95b0:	710002ff 	cmp	w23, #0x0
    95b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    95b8:	17fffeb0 	b	9078 <fwp_write+0x788>
    95bc:	528005a1 	mov	w1, #0x2d                  	// #45
    95c0:	eb0203e2 	negs	x2, x2
    95c4:	da0303e3 	ngc	x3, x3
    95c8:	910127e0 	add	x0, sp, #0x49
    95cc:	910123f5 	add	x21, sp, #0x48
    95d0:	390123e1 	strb	w1, [sp, #72]
    95d4:	97ffe613 	bl	2e20 <fwp_fmt_u128>
    95d8:	17fffe18 	b	8e38 <fwp_write+0x548>
    95dc:	d37ceea1 	lsl	x1, x21, #4
    95e0:	b7f810a3 	tbnz	x3, #63, 97f4 <fwp_write+0xf04>
    95e4:	91002260 	add	x0, x19, #0x8
    95e8:	8b010001 	add	x1, x0, x1
    95ec:	17fffdf9 	b	8dd0 <fwp_write+0x4e0>
    95f0:	f9400a61 	ldr	x1, [x19, #16]
    95f4:	8b010000 	add	x0, x0, x1
    95f8:	f9400001 	ldr	x1, [x0]
    95fc:	17fffdf5 	b	8dd0 <fwp_write+0x4e0>
    9600:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    9604:	d2800042 	mov	x2, #0x2                   	// #2
    9608:	912e6021 	add	x1, x1, #0xb98
    960c:	17fffed6 	b	9164 <fwp_write+0x874>
    9610:	7101fcbf 	cmp	w5, #0x7f
    9614:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9618:	540000e9 	b.ls	9634 <fwp_write+0xd44>  // b.plast
    961c:	aa1503e1 	mov	x1, x21
    9620:	aa1403e0 	mov	x0, x20
    9624:	d2800022 	mov	x2, #0x1                   	// #1
    9628:	39001fe5 	strb	w5, [sp, #7]
    962c:	97ffe7d9 	bl	3590 <buf_put>
    9630:	17ffffb4 	b	9500 <fwp_write+0xc10>
    9634:	d2800203 	mov	x3, #0x10                  	// #16
    9638:	d0000004 	adrp	x4, b000 <__divti3+0x100>
    963c:	aa0303e1 	mov	x1, x3
    9640:	91306084 	add	x4, x4, #0xc18
    9644:	910123f6 	add	x22, sp, #0x48
    9648:	52800042 	mov	w2, #0x2                   	// #2
    964c:	aa1603e0 	mov	x0, x22
    9650:	97ffe468 	bl	27f0 <__snprintf_chk@plt>
    9654:	aa1603e0 	mov	x0, x22
    9658:	97ffe42e 	bl	2710 <strlen@plt>
    965c:	aa1603e1 	mov	x1, x22
    9660:	aa0003e2 	mov	x2, x0
    9664:	aa1403e0 	mov	x0, x20
    9668:	97ffe7ca 	bl	3590 <buf_put>
    966c:	17ffffa5 	b	9500 <fwp_write+0xc10>
    9670:	1e604100 	fmov	d0, d8
    9674:	aa1503e0 	mov	x0, x21
    9678:	52800221 	mov	w1, #0x11                  	// #17
    967c:	97ffe946 	bl	3b94 <fwp_format_g.constprop.0>
    9680:	17fffe43 	b	8f8c <fwp_write+0x69c>
    9684:	b9401040 	ldr	w0, [x2, #16]
    9688:	350003c0 	cbnz	w0, 9700 <fwp_write+0xe10>
    968c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9690:	f947f400 	ldr	x0, [x0, #4072]
    9694:	f94127e2 	ldr	x2, [sp, #584]
    9698:	f9400001 	ldr	x1, [x0]
    969c:	eb010042 	subs	x2, x2, x1
    96a0:	d2800001 	mov	x1, #0x0                   	// #0
    96a4:	54ffd721 	b.ne	9188 <fwp_write+0x898>  // b.any
    96a8:	f9413bf5 	ldr	x21, [sp, #624]
    96ac:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    96b0:	f9413ff6 	ldr	x22, [sp, #632]
    96b4:	aa1403e0 	mov	x0, x20
    96b8:	f94143f7 	ldr	x23, [sp, #640]
    96bc:	9131a021 	add	x1, x1, #0xc68
    96c0:	f94147f8 	ldr	x24, [sp, #648]
    96c4:	d2800042 	mov	x2, #0x2                   	// #2
    96c8:	17fffd0e 	b	8b00 <fwp_write+0x210>
    96cc:	d0000001 	adrp	x1, b000 <__divti3+0x100>
    96d0:	d2800042 	mov	x2, #0x2                   	// #2
    96d4:	912e8021 	add	x1, x1, #0xba0
    96d8:	17fffea3 	b	9164 <fwp_write+0x874>
    96dc:	f9400a63 	ldr	x3, [x19, #16]
    96e0:	8b030021 	add	x1, x1, x3
    96e4:	17ffff66 	b	947c <fwp_write+0xb8c>
    96e8:	f9400a61 	ldr	x1, [x19, #16]
    96ec:	8b0102a1 	add	x1, x21, x1
    96f0:	17fffdb3 	b	8dbc <fwp_write+0x4cc>
    96f4:	f9400a63 	ldr	x3, [x19, #16]
    96f8:	8b030021 	add	x1, x1, x3
    96fc:	17ffff56 	b	9454 <fwp_write+0xb64>
    9700:	b9404840 	ldr	w0, [x2, #72]
    9704:	91001ff5 	add	x21, sp, #0x7
    9708:	34ffa360 	cbz	w0, 8b74 <fwp_write+0x284>
    970c:	52800503 	mov	w3, #0x28                  	// #40
    9710:	aa1403e0 	mov	x0, x20
    9714:	aa1503e1 	mov	x1, x21
    9718:	d2800022 	mov	x2, #0x1                   	// #1
    971c:	39001fe3 	strb	w3, [sp, #7]
    9720:	97ffe79c 	bl	3590 <buf_put>
    9724:	b9401380 	ldr	w0, [x28, #16]
    9728:	52800038 	mov	w24, #0x1                   	// #1
    972c:	7100001f 	cmp	w0, #0x0
    9730:	54ffa36c 	b.gt	8b9c <fwp_write+0x2ac>
    9734:	17fffd32 	b	8bfc <fwp_write+0x30c>
    9738:	f9014bf9 	str	x25, [sp, #656]
    973c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x107b0>
    9740:	f9014ffa 	str	x26, [sp, #664]
    9744:	f9400676 	ldr	x22, [x19, #8]
    9748:	91102333 	add	x19, x25, #0x408
    974c:	91002273 	add	x19, x19, #0x8
    9750:	937ffed8 	asr	x24, x22, #63
    9754:	aa1802c0 	orr	x0, x22, x24
    9758:	b5000320 	cbnz	x0, 97bc <fwp_write+0xecc>
    975c:	110006b5 	add	w21, w21, #0x1
    9760:	710016bf 	cmp	w21, #0x5
    9764:	54ffffc1 	b.ne	975c <fwp_write+0xe6c>  // b.any
    9768:	b7f80578 	tbnz	x24, #63, 9814 <fwp_write+0xf24>
    976c:	910023f3 	add	x19, sp, #0x8
    9770:	aa1603e2 	mov	x2, x22
    9774:	aa1303e0 	mov	x0, x19
    9778:	d2800003 	mov	x3, #0x0                   	// #0
    977c:	97ffe5a9 	bl	2e20 <fwp_fmt_u128>
    9780:	910123f5 	add	x21, sp, #0x48
    9784:	d0000003 	adrp	x3, b000 <__divti3+0x100>
    9788:	aa1303e4 	mov	x4, x19
    978c:	aa1503e0 	mov	x0, x21
    9790:	91318063 	add	x3, x3, #0xc60
    9794:	d2804002 	mov	x2, #0x200                 	// #512
    9798:	52800041 	mov	w1, #0x2                   	// #2
    979c:	97ffe3e1 	bl	2720 <__sprintf_chk@plt>
    97a0:	aa1503e0 	mov	x0, x21
    97a4:	97ffe3db 	bl	2710 <strlen@plt>
    97a8:	aa1503e1 	mov	x1, x21
    97ac:	aa0003e2 	mov	x2, x0
    97b0:	aa1403e0 	mov	x0, x20
    97b4:	97ffe777 	bl	3590 <buf_put>
    97b8:	17fffe47 	b	90d4 <fwp_write+0x7e4>
    97bc:	f9400277 	ldr	x23, [x19]
    97c0:	aa1603e0 	mov	x0, x22
    97c4:	aa1803e1 	mov	x1, x24
    97c8:	aa1703e2 	mov	x2, x23
    97cc:	937ffefa 	asr	x26, x23, #63
    97d0:	aa1a03e3 	mov	x3, x26
    97d4:	940006ab 	bl	b280 <__modti3>
    97d8:	aa010000 	orr	x0, x0, x1
    97dc:	b40002c0 	cbz	x0, 9834 <fwp_write+0xf44>
    97e0:	110006b5 	add	w21, w21, #0x1
    97e4:	91004273 	add	x19, x19, #0x10
    97e8:	710016bf 	cmp	w21, #0x5
    97ec:	54fffe81 	b.ne	97bc <fwp_write+0xecc>  // b.any
    97f0:	17ffffde 	b	9768 <fwp_write+0xe78>
    97f4:	f9400a60 	ldr	x0, [x19, #16]
    97f8:	8b000021 	add	x1, x1, x0
    97fc:	17fffd75 	b	8dd0 <fwp_write+0x4e0>
    9800:	528c29c0 	mov	w0, #0x614e                	// #24910
    9804:	910123f5 	add	x21, sp, #0x48
    9808:	72a009c0 	movk	w0, #0x4e, lsl #16
    980c:	b9004be0 	str	w0, [sp, #72]
    9810:	17fffda2 	b	8e98 <fwp_write+0x5a8>
    9814:	528005a1 	mov	w1, #0x2d                  	// #45
    9818:	eb1603e2 	negs	x2, x22
    981c:	da1803e3 	ngc	x3, x24
    9820:	910027e0 	add	x0, sp, #0x9
    9824:	910023f3 	add	x19, sp, #0x8
    9828:	390023e1 	strb	w1, [sp, #8]
    982c:	97ffe57d 	bl	2e20 <fwp_fmt_u128>
    9830:	17ffffd4 	b	9780 <fwp_write+0xe90>
    9834:	aa1703e2 	mov	x2, x23
    9838:	aa1a03e3 	mov	x3, x26
    983c:	aa1603e0 	mov	x0, x22
    9840:	aa1803e1 	mov	x1, x24
    9844:	940005af 	bl	af00 <__divti3>
    9848:	aa0003e2 	mov	x2, x0
    984c:	aa0103e3 	mov	x3, x1
    9850:	b7f80201 	tbnz	x1, #63, 9890 <fwp_write+0xfa0>
    9854:	910023f3 	add	x19, sp, #0x8
    9858:	aa1303e0 	mov	x0, x19
    985c:	97ffe571 	bl	2e20 <fwp_fmt_u128>
    9860:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9864:	91102339 	add	x25, x25, #0x408
    9868:	910123f5 	add	x21, sp, #0x48
    986c:	aa1303e4 	mov	x4, x19
    9870:	aa1503e0 	mov	x0, x21
    9874:	d0000003 	adrp	x3, b000 <__divti3+0x100>
    9878:	f8616b25 	ldr	x5, [x25, x1]
    987c:	91316063 	add	x3, x3, #0xc58
    9880:	d2804002 	mov	x2, #0x200                 	// #512
    9884:	52800041 	mov	w1, #0x2                   	// #2
    9888:	97ffe3a6 	bl	2720 <__sprintf_chk@plt>
    988c:	17ffffc5 	b	97a0 <fwp_write+0xeb0>
    9890:	528005a4 	mov	w4, #0x2d                  	// #45
    9894:	eb0003e2 	negs	x2, x0
    9898:	da0103e3 	ngc	x3, x1
    989c:	910027e0 	add	x0, sp, #0x9
    98a0:	910023f3 	add	x19, sp, #0x8
    98a4:	390023e4 	strb	w4, [sp, #8]
    98a8:	97ffe55e 	bl	2e20 <fwp_fmt_u128>
    98ac:	17ffffed 	b	9860 <fwp_write+0xf70>
    98b0:	f9013bf5 	str	x21, [sp, #624]
    98b4:	f9013ff6 	str	x22, [sp, #632]
    98b8:	f90143f7 	str	x23, [sp, #640]
    98bc:	f90147f8 	str	x24, [sp, #648]
    98c0:	f9014bf9 	str	x25, [sp, #656]
    98c4:	f9014ffa 	str	x26, [sp, #664]
    98c8:	f90153fb 	str	x27, [sp, #672]
    98cc:	f90157fc 	str	x28, [sp, #680]
    98d0:	fd015be8 	str	d8, [sp, #688]
    98d4:	fd015fe9 	str	d9, [sp, #696]
    98d8:	97ffe3ea 	bl	2880 <__stack_chk_fail@plt>
    98dc:	d503201f 	nop

00000000000098e0 <fwp_main_thread>:
    98e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    98e4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    98e8:	91174001 	add	x1, x0, #0x5d0
    98ec:	910003fd 	mov	x29, sp
    98f0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    98f4:	f947f400 	ldr	x0, [x0, #4072]
    98f8:	a90153f3 	stp	x19, x20, [sp, #16]
    98fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    9900:	a90363f7 	stp	x23, x24, [sp, #48]
    9904:	a9046bf9 	stp	x25, x26, [sp, #64]
    9908:	a90573fb 	stp	x27, x28, [sp, #80]
    990c:	fd0033e8 	str	d8, [sp, #96]
    9910:	d10643ff 	sub	sp, sp, #0x190
    9914:	b953a421 	ldr	w1, [x1, #5028]
    9918:	f9400002 	ldr	x2, [x0]
    991c:	f81f83a2 	stur	x2, [x29, #-8]
    9920:	d2800002 	mov	x2, #0x0                   	// #0
    9924:	34007541 	cbz	w1, a7cc <fwp_main_thread+0xeec>
    9928:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    992c:	91174000 	add	x0, x0, #0x5d0
    9930:	b953a800 	ldr	w0, [x0, #5032]
    9934:	35007440 	cbnz	w0, a7bc <fwp_main_thread+0xedc>
    9938:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    993c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9940:	f00000a2 	adrp	x2, 20000 <__data_start>
    9944:	9101c013 	add	x19, x0, #0x70
    9948:	910fc042 	add	x2, x2, #0x3f0
    994c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9950:	d2a00024 	mov	x4, #0x10000               	// #65536
    9954:	d10383a0 	sub	x0, x29, #0xe0
    9958:	d103e3b5 	sub	x21, x29, #0xf8
    995c:	f81203a2 	stur	x2, [x29, #-224]
    9960:	b81283bf 	stur	wzr, [x29, #-216]
    9964:	f81303a4 	stur	x4, [x29, #-208]
    9968:	a9018e75 	stp	x21, x3, [x19, #24]
    996c:	f91f5420 	str	x0, [x1, #16040]
    9970:	d2800001 	mov	x1, #0x0                   	// #0
    9974:	97ffe35b 	bl	26e0 <sigaltstack@plt>
    9978:	3500a500 	cbnz	w0, ae18 <fwp_main_thread+0x1538>
    997c:	4f000400 	movi	v0.4s, #0x0
    9980:	d10263a0 	sub	x0, x29, #0x98
    9984:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    9988:	9101c021 	add	x1, x1, #0x70
    998c:	f81603a1 	stur	x1, [x29, #-160]
    9990:	52800082 	mov	w2, #0x4                   	// #4
    9994:	72a10002 	movk	w2, #0x800, lsl #16
    9998:	d10283b7 	sub	x23, x29, #0xa0
    999c:	3d802000 	str	q0, [x0, #128]
    99a0:	b81e83a2 	stur	w2, [x29, #-24]
    99a4:	ad000000 	stp	q0, q0, [x0]
    99a8:	ad010000 	stp	q0, q0, [x0, #32]
    99ac:	ad020000 	stp	q0, q0, [x0, #64]
    99b0:	ad030000 	stp	q0, q0, [x0, #96]
    99b4:	97ffe3a3 	bl	2840 <sigemptyset@plt>
    99b8:	3500a300 	cbnz	w0, ae18 <fwp_main_thread+0x1538>
    99bc:	aa1703e1 	mov	x1, x23
    99c0:	d2800002 	mov	x2, #0x0                   	// #0
    99c4:	52800160 	mov	w0, #0xb                   	// #11
    99c8:	97ffe3b6 	bl	28a0 <sigaction@plt>
    99cc:	3500a260 	cbnz	w0, ae18 <fwp_main_thread+0x1538>
    99d0:	aa1703e1 	mov	x1, x23
    99d4:	d2800002 	mov	x2, #0x0                   	// #0
    99d8:	528000e0 	mov	w0, #0x7                   	// #7
    99dc:	97ffe3b1 	bl	28a0 <sigaction@plt>
    99e0:	3500a1c0 	cbnz	w0, ae18 <fwp_main_thread+0x1538>
    99e4:	b9434a60 	ldr	w0, [x19, #840]
    99e8:	34001480 	cbz	w0, 9c78 <fwp_main_thread+0x398>
    99ec:	f00000a0 	adrp	x0, 20000 <__data_start>
    99f0:	9101c000 	add	x0, x0, #0x70
    99f4:	b9434c01 	ldr	w1, [x0, #844]
    99f8:	34001541 	cbz	w1, 9ca0 <fwp_main_thread+0x3c0>
    99fc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a00:	9101c015 	add	x21, x0, #0x70
    9a04:	f9400ab4 	ldr	x20, [x21, #16]
    9a08:	b4000c54 	cbz	x20, 9b90 <fwp_main_thread+0x2b0>
    9a0c:	aa1403f3 	mov	x19, x20
    9a10:	91010297 	add	x23, x20, #0x40
    9a14:	39414a98 	ldrb	w24, [x20, #82]
    9a18:	52800036 	mov	w22, #0x1                   	// #1
    9a1c:	39014a96 	strb	w22, [x20, #82]
    9a20:	f9401680 	ldr	x0, [x20, #40]
    9a24:	b4000620 	cbz	x0, 9ae8 <fwp_main_thread+0x208>
    9a28:	f9403281 	ldr	x1, [x20, #96]
    9a2c:	39414680 	ldrb	w0, [x20, #81]
    9a30:	b4000e81 	cbz	x1, 9c00 <fwp_main_thread+0x320>
    9a34:	36000d40 	tbz	w0, #0, 9bdc <fwp_main_thread+0x2fc>
    9a38:	39414a62 	ldrb	w2, [x19, #82]
    9a3c:	f9402281 	ldr	x1, [x20, #64]
    9a40:	37001082 	tbnz	w2, #0, 9c50 <fwp_main_thread+0x370>
    9a44:	f9403260 	ldr	x0, [x19, #96]
    9a48:	a911fe77 	stp	x23, xzr, [x19, #280]
    9a4c:	f9009661 	str	x1, [x19, #296]
    9a50:	b4000041 	cbz	x1, 9a58 <fwp_main_thread+0x178>
    9a54:	f9009033 	str	x19, [x1, #288]
    9a58:	f9002293 	str	x19, [x20, #64]
    9a5c:	b4000100 	cbz	x0, 9a7c <fwp_main_thread+0x19c>
    9a60:	f9406ea1 	ldr	x1, [x21, #216]
    9a64:	39015676 	strb	w22, [x19, #85]
    9a68:	f9003660 	str	x0, [x19, #104]
    9a6c:	a910867f 	stp	xzr, x1, [x19, #264]
    9a70:	b4000041 	cbz	x1, 9a78 <fwp_main_thread+0x198>
    9a74:	f9008433 	str	x19, [x1, #264]
    9a78:	f9006eb3 	str	x19, [x21, #216]
    9a7c:	39015a7f 	strb	wzr, [x19, #86]
    9a80:	97fff295 	bl	64d4 <fwp_block>
    9a84:	f9408e62 	ldr	x2, [x19, #280]
    9a88:	b4000142 	cbz	x2, 9ab0 <fwp_main_thread+0x1d0>
    9a8c:	a9520261 	ldp	x1, x0, [x19, #288]
    9a90:	b4000ec1 	cbz	x1, 9c68 <fwp_main_thread+0x388>
    9a94:	f9009420 	str	x0, [x1, #296]
    9a98:	f9409660 	ldr	x0, [x19, #296]
    9a9c:	b4000040 	cbz	x0, 9aa4 <fwp_main_thread+0x1c4>
    9aa0:	f9009001 	str	x1, [x0, #288]
    9aa4:	91080260 	add	x0, x19, #0x200
    9aa8:	f900967f 	str	xzr, [x19, #296]
    9aac:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9ab0:	39415660 	ldrb	w0, [x19, #85]
    9ab4:	f9400aa1 	ldr	x1, [x21, #16]
    9ab8:	36000c80 	tbz	w0, #0, 9c48 <fwp_main_thread+0x368>
    9abc:	a9508262 	ldp	x2, x0, [x19, #264]
    9ac0:	b4000d82 	cbz	x2, 9c70 <fwp_main_thread+0x390>
    9ac4:	f9008840 	str	x0, [x2, #272]
    9ac8:	b4000040 	cbz	x0, 9ad0 <fwp_main_thread+0x1f0>
    9acc:	f9008402 	str	x2, [x0, #264]
    9ad0:	91080260 	add	x0, x19, #0x200
    9ad4:	3901567f 	strb	wzr, [x19, #85]
    9ad8:	aa0103f3 	mov	x19, x1
    9adc:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9ae0:	f9401680 	ldr	x0, [x20, #40]
    9ae4:	b5fffa20 	cbnz	x0, 9a28 <fwp_main_thread+0x148>
    9ae8:	f00000a0 	adrp	x0, 20000 <__data_start>
    9aec:	9101c000 	add	x0, x0, #0x70
    9af0:	39014a98 	strb	w24, [x20, #82]
    9af4:	f9419400 	ldr	x0, [x0, #808]
    9af8:	b4000520 	cbz	x0, 9b9c <fwp_main_thread+0x2bc>
    9afc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b00:	9101c000 	add	x0, x0, #0x70
    9b04:	f941b001 	ldr	x1, [x0, #864]
    9b08:	b903581f 	str	wzr, [x0, #856]
    9b0c:	eb13003f 	cmp	x1, x19
    9b10:	54000641 	b.ne	9bd8 <fwp_main_thread+0x2f8>  // b.any
    9b14:	b40059b3 	cbz	x19, a648 <fwp_main_thread+0xd68>
    9b18:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b1c:	9101c000 	add	x0, x0, #0x70
    9b20:	52800021 	mov	w1, #0x1                   	// #1
    9b24:	39014a61 	strb	w1, [x19, #82]
    9b28:	f9418005 	ldr	x5, [x0, #768]
    9b2c:	b40058e5 	cbz	x5, a648 <fwp_main_thread+0xd68>
    9b30:	394140a0 	ldrb	w0, [x5, #80]
    9b34:	37000060 	tbnz	w0, #0, 9b40 <fwp_main_thread+0x260>
    9b38:	aa0503e0 	mov	x0, x5
    9b3c:	97ffe6ed 	bl	36f0 <fwp_cancel_tree.part.0>
    9b40:	f9409ca5 	ldr	x5, [x5, #312]
    9b44:	b5ffff65 	cbnz	x5, 9b30 <fwp_main_thread+0x250>
    9b48:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b4c:	9101c014 	add	x20, x0, #0x70
    9b50:	52800035 	mov	w21, #0x1                   	// #1
    9b54:	f9402a60 	ldr	x0, [x19, #80]
    9b58:	f2001c1f 	tst	x0, #0xff000000ff
    9b5c:	540000e1 	b.ne	9b78 <fwp_main_thread+0x298>  // b.any
    9b60:	f9403e80 	ldr	x0, [x20, #120]
    9b64:	39015275 	strb	w21, [x19, #84]
    9b68:	f900827f 	str	xzr, [x19, #256]
    9b6c:	b4005640 	cbz	x0, a634 <fwp_main_thread+0xd54>
    9b70:	f9008013 	str	x19, [x0, #256]
    9b74:	f9003e93 	str	x19, [x20, #120]
    9b78:	97fff257 	bl	64d4 <fwp_block>
    9b7c:	97fff1e9 	bl	6320 <fwp_free_zombie>
    9b80:	f9418280 	ldr	x0, [x20, #768]
    9b84:	b4005620 	cbz	x0, a648 <fwp_main_thread+0xd68>
    9b88:	f941b293 	ldr	x19, [x20, #864]
    9b8c:	17fffff2 	b	9b54 <fwp_main_thread+0x274>
    9b90:	f94196a0 	ldr	x0, [x21, #808]
    9b94:	b5005540 	cbnz	x0, a63c <fwp_main_thread+0xd5c>
    9b98:	d2800013 	mov	x19, #0x0                   	// #0
    9b9c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ba0:	9101c014 	add	x20, x0, #0x70
    9ba4:	f9419e80 	ldr	x0, [x20, #824]
    9ba8:	b5fffaa0 	cbnz	x0, 9afc <fwp_main_thread+0x21c>
    9bac:	f9419280 	ldr	x0, [x20, #800]
    9bb0:	97ffebb0 	bl	4a70 <fwp_mem_free>
    9bb4:	f901929f 	str	xzr, [x20, #800]
    9bb8:	f9019a9f 	str	xzr, [x20, #816]
    9bbc:	f941b280 	ldr	x0, [x20, #864]
    9bc0:	b40098f3 	cbz	x19, aedc <fwp_main_thread+0x15fc>
    9bc4:	f900567f 	str	xzr, [x19, #168]
    9bc8:	f9005e7f 	str	xzr, [x19, #184]
    9bcc:	b9035a9f 	str	wzr, [x20, #856]
    9bd0:	eb00027f 	cmp	x19, x0
    9bd4:	54fffa20 	b.eq	9b18 <fwp_main_thread+0x238>  // b.none
    9bd8:	97ffe33e 	bl	28d0 <abort@plt>
    9bdc:	97ffe769 	bl	3980 <fwp_now_ns>
    9be0:	f9403281 	ldr	x1, [x20, #96]
    9be4:	eb01001f 	cmp	x0, x1
    9be8:	540000ab 	b.lt	9bfc <fwp_main_thread+0x31c>  // b.tstop
    9bec:	39414280 	ldrb	w0, [x20, #80]
    9bf0:	37000060 	tbnz	w0, #0, 9bfc <fwp_main_thread+0x31c>
    9bf4:	aa1403e0 	mov	x0, x20
    9bf8:	97ffe6be 	bl	36f0 <fwp_cancel_tree.part.0>
    9bfc:	39414680 	ldrb	w0, [x20, #81]
    9c00:	39414a62 	ldrb	w2, [x19, #82]
    9c04:	3707f1c0 	tbnz	w0, #0, 9a3c <fwp_main_thread+0x15c>
    9c08:	f9403280 	ldr	x0, [x20, #96]
    9c0c:	370001a2 	tbnz	w2, #0, 9c40 <fwp_main_thread+0x360>
    9c10:	f9403261 	ldr	x1, [x19, #96]
    9c14:	b4000161 	cbz	x1, 9c40 <fwp_main_thread+0x360>
    9c18:	b4008ca0 	cbz	x0, adac <fwp_main_thread+0x14cc>
    9c1c:	eb01001f 	cmp	x0, x1
    9c20:	9a81d000 	csel	x0, x0, x1, le
    9c24:	f9402281 	ldr	x1, [x20, #64]
    9c28:	a911fe77 	stp	x23, xzr, [x19, #280]
    9c2c:	f9009661 	str	x1, [x19, #296]
    9c30:	b4000041 	cbz	x1, 9c38 <fwp_main_thread+0x358>
    9c34:	f9009033 	str	x19, [x1, #288]
    9c38:	f9002293 	str	x19, [x20, #64]
    9c3c:	17ffff89 	b	9a60 <fwp_main_thread+0x180>
    9c40:	f9402281 	ldr	x1, [x20, #64]
    9c44:	17ffff81 	b	9a48 <fwp_main_thread+0x168>
    9c48:	aa0103f3 	mov	x19, x1
    9c4c:	17ffff75 	b	9a20 <fwp_main_thread+0x140>
    9c50:	a911fe77 	stp	x23, xzr, [x19, #280]
    9c54:	f9009661 	str	x1, [x19, #296]
    9c58:	b4000041 	cbz	x1, 9c60 <fwp_main_thread+0x380>
    9c5c:	f9009033 	str	x19, [x1, #288]
    9c60:	f9002293 	str	x19, [x20, #64]
    9c64:	17ffff86 	b	9a7c <fwp_main_thread+0x19c>
    9c68:	f9000040 	str	x0, [x2]
    9c6c:	17ffff8c 	b	9a9c <fwp_main_thread+0x1bc>
    9c70:	f9006ea0 	str	x0, [x21, #216]
    9c74:	17ffff95 	b	9ac8 <fwp_main_thread+0x1e8>
    9c78:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9c7c:	91058000 	add	x0, x0, #0x160
    9c80:	9400065c 	bl	b5f0 <atexit>
    9c84:	35008d00 	cbnz	w0, ae24 <fwp_main_thread+0x1544>
    9c88:	52800020 	mov	w0, #0x1                   	// #1
    9c8c:	b9034a60 	str	w0, [x19, #840]
    9c90:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c94:	9101c000 	add	x0, x0, #0x70
    9c98:	b9434c01 	ldr	w1, [x0, #844]
    9c9c:	35ffeb01 	cbnz	w1, 99fc <fwp_main_thread+0x11c>
    9ca0:	f9418803 	ldr	x3, [x0, #784]
    9ca4:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9ca8:	913d4042 	add	x2, x2, #0xf50
    9cac:	a9308ba3 	stp	x3, x2, [x29, #-248]
    9cb0:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    9cb4:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9cb8:	f9018815 	str	x21, [x0, #784]
    9cbc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9cc0:	91174033 	add	x19, x1, #0x5d0
    9cc4:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0x9e0>
    9cc8:	d2800016 	mov	x22, #0x0                   	// #0
    9ccc:	f95f5442 	ldr	x2, [x2, #16040]
    9cd0:	d280041b 	mov	x27, #0x20                  	// #32
    9cd4:	fd41f828 	ldr	d8, [x1, #1008]
    9cd8:	d2800014 	mov	x20, #0x0                   	// #0
    9cdc:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    9ce0:	52800038 	mov	w24, #0x1                   	// #1
    9ce4:	91304021 	add	x1, x1, #0xc10
    9ce8:	f81183a2 	stur	x2, [x29, #-232]
    9cec:	f81203bf 	stur	xzr, [x29, #-224]
    9cf0:	a93307bf 	stp	xzr, x1, [x29, #-208]
    9cf4:	f91f7c17 	str	x23, [x0, #16120]
    9cf8:	b953a660 	ldr	w0, [x19, #5028]
    9cfc:	f1000779 	subs	x25, x27, #0x1
    9d00:	f81283b9 	stur	x25, [x29, #-216]
    9d04:	da1f029c 	sbc	x28, x20, xzr
    9d08:	aa1903fb 	mov	x27, x25
    9d0c:	aa1c03f4 	mov	x20, x28
    9d10:	34005740 	cbz	w0, a7f8 <fwp_main_thread+0xf18>
    9d14:	397e8a60 	ldrb	w0, [x19, #4002]
    9d18:	910f0001 	add	x1, x0, #0x3c0
    9d1c:	8b000400 	add	x0, x0, x0, lsl #1
    9d20:	b8617a77 	ldr	w23, [x19, x1, lsl #2]
    9d24:	8b000e61 	add	x1, x19, x0, lsl #3
    9d28:	f8607a75 	ldr	x21, [x19, x0, lsl #3]
    9d2c:	2a1703fa 	mov	w26, w23
    9d30:	b4005535 	cbz	x21, a7d4 <fwp_main_thread+0xef4>
    9d34:	f94002a1 	ldr	x1, [x21]
    9d38:	aa2103e1 	mvn	x1, x1
    9d3c:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9d40:	f100635f 	cmp	x26, #0x18
    9d44:	540000e9 	b.ls	9d60 <fwp_main_thread+0x480>  // b.plast
    9d48:	d1006742 	sub	x2, x26, #0x19
    9d4c:	910062a0 	add	x0, x21, #0x18
    9d50:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9d54:	52800001 	mov	w1, #0x0                   	// #0
    9d58:	91002042 	add	x2, x2, #0x8
    9d5c:	97ffe2bd 	bl	2850 <memset@plt>
    9d60:	f94a1260 	ldr	x0, [x19, #5152]
    9d64:	ab1a0000 	adds	x0, x0, x26
    9d68:	54008562 	b.cs	ae14 <fwp_main_thread+0x1534>  // b.hs, b.nlast
    9d6c:	f94a1661 	ldr	x1, [x19, #5160]
    9d70:	f90a1260 	str	x0, [x19, #5152]
    9d74:	eb01001f 	cmp	x0, x1
    9d78:	54000049 	b.ls	9d80 <fwp_main_thread+0x4a0>  // b.plast
    9d7c:	f90a1660 	str	x0, [x19, #5160]
    9d80:	1e6302e1 	ucvtf	d1, w23
    9d84:	fd4a1e60 	ldr	d0, [x19, #5176]
    9d88:	1e612800 	fadd	d0, d0, d1
    9d8c:	fd0a1e60 	str	d0, [x19, #5176]
    9d90:	a900dab9 	stp	x25, x22, [x21, #8]
    9d94:	aa1503f6 	mov	x22, x21
    9d98:	fd0002a8 	str	d8, [x21]
    9d9c:	f949da62 	ldr	x2, [x19, #5040]
    9da0:	f949ee60 	ldr	x0, [x19, #5080]
    9da4:	cb0202a2 	sub	x2, x21, x2
    9da8:	eb00405f 	cmp	x2, x0, lsl #16
    9dac:	54000302 	b.cs	9e0c <fwp_main_thread+0x52c>  // b.hs, b.nlast
    9db0:	d350fc40 	lsr	x0, x2, #16
    9db4:	f949fe63 	ldr	x3, [x19, #5112]
    9db8:	8b000800 	add	x0, x0, x0, lsl #2
    9dbc:	d37df001 	lsl	x1, x0, #3
    9dc0:	8b010060 	add	x0, x3, x1
    9dc4:	f940101a 	ldr	x26, [x0, #32]
    9dc8:	b400023a 	cbz	x26, 9e0c <fwp_main_thread+0x52c>
    9dcc:	38616861 	ldrb	w1, [x3, x1]
    9dd0:	7100083f 	cmp	w1, #0x2
    9dd4:	540051c0 	b.eq	a80c <fwp_main_thread+0xf2c>  // b.none
    9dd8:	7100043f 	cmp	w1, #0x1
    9ddc:	54000181 	b.ne	9e0c <fwp_main_thread+0x52c>  // b.any
    9de0:	29430003 	ldp	w3, w0, [x0, #24]
    9de4:	92403c41 	and	x1, x2, #0xffff
    9de8:	9b037c21 	mul	x1, x1, x3
    9dec:	d360fc21 	lsr	x1, x1, #32
    9df0:	eb00003f 	cmp	x1, x0
    9df4:	540000c2 	b.cs	9e0c <fwp_main_thread+0x52c>  // b.hs, b.nlast
    9df8:	8b01035a 	add	x26, x26, x1
    9dfc:	39400340 	ldrb	w0, [x26]
    9e00:	7103fc1f 	cmp	w0, #0xff
    9e04:	540050e0 	b.eq	a820 <fwp_main_thread+0xf40>  // b.none
    9e08:	39000358 	strb	w24, [x26]
    9e0c:	f81203b5 	stur	x21, [x29, #-224]
    9e10:	aa1c0339 	orr	x25, x25, x28
    9e14:	b5fff739 	cbnz	x25, 9cf8 <fwp_main_thread+0x418>
    9e18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e1c:	d10303a1 	sub	x1, x29, #0xc0
    9e20:	f85083a3 	ldur	x3, [x29, #-248]
    9e24:	f95f7c17 	ldr	x23, [x0, #16120]
    9e28:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    9e2c:	3dc10000 	ldr	q0, [x0, #1024]
    9e30:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e34:	9101c002 	add	x2, x0, #0x70
    9e38:	52800020 	mov	w0, #0x1                   	// #1
    9e3c:	3c9403a0 	stur	q0, [x29, #-192]
    9e40:	f9018843 	str	x3, [x2, #784]
    9e44:	97ffee60 	bl	57c4 <fwp_data.part.0.constprop.0>
    9e48:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9e4c:	91174022 	add	x2, x1, #0x5d0
    9e50:	aa0003f4 	mov	x20, x0
    9e54:	f949d841 	ldr	x1, [x2, #5040]
    9e58:	f949ec40 	ldr	x0, [x2, #5080]
    9e5c:	cb010281 	sub	x1, x20, x1
    9e60:	eb00403f 	cmp	x1, x0, lsl #16
    9e64:	54000322 	b.cs	9ec8 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    9e68:	d350fc20 	lsr	x0, x1, #16
    9e6c:	f949fc43 	ldr	x3, [x2, #5112]
    9e70:	8b000800 	add	x0, x0, x0, lsl #2
    9e74:	d37df002 	lsl	x2, x0, #3
    9e78:	8b020060 	add	x0, x3, x2
    9e7c:	f9401013 	ldr	x19, [x0, #32]
    9e80:	b4000253 	cbz	x19, 9ec8 <fwp_main_thread+0x5e8>
    9e84:	38626862 	ldrb	w2, [x3, x2]
    9e88:	7100085f 	cmp	w2, #0x2
    9e8c:	54007780 	b.eq	ad7c <fwp_main_thread+0x149c>  // b.none
    9e90:	7100045f 	cmp	w2, #0x1
    9e94:	540001a1 	b.ne	9ec8 <fwp_main_thread+0x5e8>  // b.any
    9e98:	29430002 	ldp	w2, w0, [x0, #24]
    9e9c:	92403c21 	and	x1, x1, #0xffff
    9ea0:	9b027c21 	mul	x1, x1, x2
    9ea4:	d360fc21 	lsr	x1, x1, #32
    9ea8:	eb00003f 	cmp	x1, x0
    9eac:	540000e2 	b.cs	9ec8 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    9eb0:	8b010273 	add	x19, x19, x1
    9eb4:	39400260 	ldrb	w0, [x19]
    9eb8:	7103fc1f 	cmp	w0, #0xff
    9ebc:	54007940 	b.eq	ade4 <fwp_main_thread+0x1504>  // b.none
    9ec0:	52800020 	mov	w0, #0x1                   	// #1
    9ec4:	39000260 	strb	w0, [x19]
    9ec8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9ecc:	aa1703e1 	mov	x1, x23
    9ed0:	52800020 	mov	w0, #0x1                   	// #1
    9ed4:	a93653a2 	stp	x2, x20, [x29, #-160]
    9ed8:	97ffee3b 	bl	57c4 <fwp_data.part.0.constprop.0>
    9edc:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9ee0:	91174022 	add	x2, x1, #0x5d0
    9ee4:	aa0003f4 	mov	x20, x0
    9ee8:	f949d841 	ldr	x1, [x2, #5040]
    9eec:	f949ec40 	ldr	x0, [x2, #5080]
    9ef0:	cb010281 	sub	x1, x20, x1
    9ef4:	eb00403f 	cmp	x1, x0, lsl #16
    9ef8:	54000322 	b.cs	9f5c <fwp_main_thread+0x67c>  // b.hs, b.nlast
    9efc:	d350fc20 	lsr	x0, x1, #16
    9f00:	f949fc43 	ldr	x3, [x2, #5112]
    9f04:	8b000800 	add	x0, x0, x0, lsl #2
    9f08:	d37df002 	lsl	x2, x0, #3
    9f0c:	8b020060 	add	x0, x3, x2
    9f10:	f9401013 	ldr	x19, [x0, #32]
    9f14:	b4000253 	cbz	x19, 9f5c <fwp_main_thread+0x67c>
    9f18:	38626862 	ldrb	w2, [x3, x2]
    9f1c:	7100085f 	cmp	w2, #0x2
    9f20:	540073a0 	b.eq	ad94 <fwp_main_thread+0x14b4>  // b.none
    9f24:	7100045f 	cmp	w2, #0x1
    9f28:	540001a1 	b.ne	9f5c <fwp_main_thread+0x67c>  // b.any
    9f2c:	29430002 	ldp	w2, w0, [x0, #24]
    9f30:	92403c21 	and	x1, x1, #0xffff
    9f34:	9b027c21 	mul	x1, x1, x2
    9f38:	d360fc21 	lsr	x1, x1, #32
    9f3c:	eb00003f 	cmp	x1, x0
    9f40:	540000e2 	b.cs	9f5c <fwp_main_thread+0x67c>  // b.hs, b.nlast
    9f44:	8b010273 	add	x19, x19, x1
    9f48:	39400260 	ldrb	w0, [x19]
    9f4c:	7103fc1f 	cmp	w0, #0xff
    9f50:	54007540 	b.eq	adf8 <fwp_main_thread+0x1518>  // b.none
    9f54:	52800020 	mov	w0, #0x1                   	// #1
    9f58:	39000260 	strb	w0, [x19]
    9f5c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9f60:	d102c3a1 	sub	x1, x29, #0xb0
    9f64:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9f68:	52800020 	mov	w0, #0x1                   	// #1
    9f6c:	a93553a2 	stp	x2, x20, [x29, #-176]
    9f70:	97ffee15 	bl	57c4 <fwp_data.part.0.constprop.0>
    9f74:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9f78:	91174023 	add	x3, x1, #0x5d0
    9f7c:	aa0003f4 	mov	x20, x0
    9f80:	f949ec62 	ldr	x2, [x3, #5080]
    9f84:	f949d861 	ldr	x1, [x3, #5040]
    9f88:	d370bc42 	lsl	x2, x2, #16
    9f8c:	cb010001 	sub	x1, x0, x1
    9f90:	eb02003f 	cmp	x1, x2
    9f94:	540003e2 	b.cs	a010 <fwp_main_thread+0x730>  // b.hs, b.nlast
    9f98:	d350fc20 	lsr	x0, x1, #16
    9f9c:	f949fc64 	ldr	x4, [x3, #5112]
    9fa0:	8b000800 	add	x0, x0, x0, lsl #2
    9fa4:	d37df003 	lsl	x3, x0, #3
    9fa8:	8b030080 	add	x0, x4, x3
    9fac:	f9401013 	ldr	x19, [x0, #32]
    9fb0:	b4000313 	cbz	x19, a010 <fwp_main_thread+0x730>
    9fb4:	38636883 	ldrb	w3, [x4, x3]
    9fb8:	7100087f 	cmp	w3, #0x2
    9fbc:	54006e60 	b.eq	ad88 <fwp_main_thread+0x14a8>  // b.none
    9fc0:	7100047f 	cmp	w3, #0x1
    9fc4:	54000261 	b.ne	a010 <fwp_main_thread+0x730>  // b.any
    9fc8:	29430004 	ldp	w4, w0, [x0, #24]
    9fcc:	92403c23 	and	x3, x1, #0xffff
    9fd0:	9b047c63 	mul	x3, x3, x4
    9fd4:	d360fc63 	lsr	x3, x3, #32
    9fd8:	eb00007f 	cmp	x3, x0
    9fdc:	540001a2 	b.cs	a010 <fwp_main_thread+0x730>  // b.hs, b.nlast
    9fe0:	8b030273 	add	x19, x19, x3
    9fe4:	39400260 	ldrb	w0, [x19]
    9fe8:	7103fc1f 	cmp	w0, #0xff
    9fec:	540070c0 	b.eq	ae04 <fwp_main_thread+0x1524>  // b.none
    9ff0:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ff4:	91174000 	add	x0, x0, #0x5d0
    9ff8:	52800021 	mov	w1, #0x1                   	// #1
    9ffc:	39000261 	strb	w1, [x19]
    a000:	f949ec02 	ldr	x2, [x0, #5080]
    a004:	f949d801 	ldr	x1, [x0, #5040]
    a008:	d370bc42 	lsl	x2, x2, #16
    a00c:	cb010281 	sub	x1, x20, x1
    a010:	d00000a0 	adrp	x0, 20000 <__data_start>
    a014:	9101c018 	add	x24, x0, #0x70
    a018:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a01c:	d00000bc 	adrp	x28, 20000 <__data_start>
    a020:	9100439b 	add	x27, x28, #0x10
    a024:	d10403b6 	sub	x22, x29, #0x100
    a028:	91010367 	add	x7, x27, #0x40
    a02c:	aa1503f7 	mov	x23, x21
    a030:	aa1503fb 	mov	x27, x21
    a034:	f91f5007 	str	x7, [x0, #16032]
    a038:	f91f581c 	str	x28, [x0, #16048]
    a03c:	eb02003f 	cmp	x1, x2
    a040:	54000382 	b.cs	a0b0 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    a044:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a048:	91174002 	add	x2, x0, #0x5d0
    a04c:	d350fc20 	lsr	x0, x1, #16
    a050:	f949fc44 	ldr	x4, [x2, #5112]
    a054:	8b000800 	add	x0, x0, x0, lsl #2
    a058:	d37df002 	lsl	x2, x0, #3
    a05c:	8b020083 	add	x3, x4, x2
    a060:	f9401060 	ldr	x0, [x3, #32]
    a064:	b4000260 	cbz	x0, a0b0 <fwp_main_thread+0x7d0>
    a068:	38626882 	ldrb	w2, [x4, x2]
    a06c:	7100085f 	cmp	w2, #0x2
    a070:	54006980 	b.eq	ada0 <fwp_main_thread+0x14c0>  // b.none
    a074:	7100045f 	cmp	w2, #0x1
    a078:	540001c1 	b.ne	a0b0 <fwp_main_thread+0x7d0>  // b.any
    a07c:	29430864 	ldp	w4, w2, [x3, #24]
    a080:	92403c21 	and	x1, x1, #0xffff
    a084:	9b047c21 	mul	x1, x1, x4
    a088:	d360fc21 	lsr	x1, x1, #32
    a08c:	eb02003f 	cmp	x1, x2
    a090:	54000102 	b.cs	a0b0 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    a094:	8b010000 	add	x0, x0, x1
    a098:	39400001 	ldrb	w1, [x0]
    a09c:	340000a1 	cbz	w1, a0b0 <fwp_main_thread+0x7d0>
    a0a0:	7103f43f 	cmp	w1, #0xfd
    a0a4:	54006a68 	b.hi	adf0 <fwp_main_thread+0x1510>  // b.pmore
    a0a8:	11000421 	add	w1, w1, #0x1
    a0ac:	39000001 	strb	w1, [x0]
    a0b0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0b4:	d28018f3 	mov	x19, #0xc7                  	// #199
    a0b8:	f95f5004 	ldr	x4, [x0, #16032]
    a0bc:	f91f4417 	str	x23, [x0, #16008]
    a0c0:	aa1403f7 	mov	x23, x20
    a0c4:	f91f481b 	str	x27, [x0, #16016]
    a0c8:	f91f4c14 	str	x20, [x0, #16024]
    a0cc:	f91f5c13 	str	x19, [x0, #16056]
    a0d0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0d4:	f81003b7 	stur	x23, [x29, #-256]
    a0d8:	f9404705 	ldr	x5, [x24, #136]
    a0dc:	f95f5800 	ldr	x0, [x0, #16048]
    a0e0:	91004000 	add	x0, x0, #0x10
    a0e4:	91010006 	add	x6, x0, #0x40
    a0e8:	b9404002 	ldr	w2, [x0, #64]
    a0ec:	d37be842 	lsl	x2, x2, #5
    a0f0:	8b0200bc 	add	x28, x5, x2
    a0f4:	f9400f81 	ldr	x1, [x28, #24]
    a0f8:	b40065e1 	cbz	x1, adb4 <fwp_main_thread+0x14d4>
    a0fc:	f9400c20 	ldr	x0, [x1, #24]
    a100:	b4005640 	cbz	x0, abc8 <fwp_main_thread+0x12e8>
    a104:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a108:	91174002 	add	x2, x0, #0x5d0
    a10c:	f949d841 	ldr	x1, [x2, #5040]
    a110:	f949ec40 	ldr	x0, [x2, #5080]
    a114:	cb010081 	sub	x1, x4, x1
    a118:	eb00403f 	cmp	x1, x0, lsl #16
    a11c:	54000342 	b.cs	a184 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    a120:	d350fc20 	lsr	x0, x1, #16
    a124:	f949fc45 	ldr	x5, [x2, #5112]
    a128:	8b000800 	add	x0, x0, x0, lsl #2
    a12c:	d37df002 	lsl	x2, x0, #3
    a130:	8b0200a3 	add	x3, x5, x2
    a134:	f9401060 	ldr	x0, [x3, #32]
    a138:	b4000260 	cbz	x0, a184 <fwp_main_thread+0x8a4>
    a13c:	386268a2 	ldrb	w2, [x5, x2]
    a140:	7100085f 	cmp	w2, #0x2
    a144:	54005b20 	b.eq	aca8 <fwp_main_thread+0x13c8>  // b.none
    a148:	7100045f 	cmp	w2, #0x1
    a14c:	540001c1 	b.ne	a184 <fwp_main_thread+0x8a4>  // b.any
    a150:	29430865 	ldp	w5, w2, [x3, #24]
    a154:	92403c21 	and	x1, x1, #0xffff
    a158:	9b057c21 	mul	x1, x1, x5
    a15c:	d360fc21 	lsr	x1, x1, #32
    a160:	eb02003f 	cmp	x1, x2
    a164:	54000102 	b.cs	a184 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    a168:	8b010000 	add	x0, x0, x1
    a16c:	39400001 	ldrb	w1, [x0]
    a170:	340000a1 	cbz	w1, a184 <fwp_main_thread+0x8a4>
    a174:	7103f43f 	cmp	w1, #0xfd
    a178:	54005e28 	b.hi	ad3c <fwp_main_thread+0x145c>  // b.pmore
    a17c:	11000421 	add	w1, w1, #0x1
    a180:	39000001 	strb	w1, [x0]
    a184:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a188:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a18c:	91174035 	add	x21, x1, #0x5d0
    a190:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a194:	aa0403f7 	mov	x23, x4
    a198:	52800034 	mov	w20, #0x1                   	// #1
    a19c:	f91f7816 	str	x22, [x0, #16112]
    a1a0:	aa0403e0 	mov	x0, x4
    a1a4:	f91f6424 	str	x4, [x1, #16072]
    a1a8:	aa1c03e4 	mov	x4, x28
    a1ac:	f91f6036 	str	x22, [x1, #16064]
    a1b0:	b93ee834 	str	w20, [x1, #16104]
    a1b4:	b93eec34 	str	w20, [x1, #16108]
    a1b8:	b9400401 	ldr	w1, [x0, #4]
    a1bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1c0:	b9400096 	ldr	w22, [x4]
    a1c4:	b97eec00 	ldr	w0, [x0, #16108]
    a1c8:	4b0102d6 	sub	w22, w22, w1
    a1cc:	6b0002df 	cmp	w22, w0
    a1d0:	1a8092dc 	csel	w28, w22, w0, ls	// ls = plast
    a1d4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1d8:	b97ee800 	ldr	w0, [x0, #16104]
    a1dc:	6b00039f 	cmp	w28, w0
    a1e0:	1a80939b 	csel	w27, w28, w0, ls	// ls = plast
    a1e4:	6b1b0382 	subs	w2, w28, w27
    a1e8:	54000100 	b.eq	a208 <fwp_main_thread+0x928>  // b.none
    a1ec:	f9400c84 	ldr	x4, [x4, #24]
    a1f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1f4:	0b1b0021 	add	w1, w1, w27
    a1f8:	f9400884 	ldr	x4, [x4, #16]
    a1fc:	f95f7800 	ldr	x0, [x0, #16112]
    a200:	8b3b4c00 	add	x0, x0, w27, uxtw #3
    a204:	d63f0080 	blr	x4
    a208:	f9404700 	ldr	x0, [x24, #136]
    a20c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a210:	b94002e4 	ldr	w4, [x23]
    a214:	aa1703e7 	mov	x7, x23
    a218:	2a1c03f9 	mov	w25, w28
    a21c:	aa1703e9 	mov	x9, x23
    a220:	f95f783a 	ldr	x26, [x1, #16112]
    a224:	8b041404 	add	x4, x0, x4, lsl #5
    a228:	f9400c88 	ldr	x8, [x4, #24]
    a22c:	b4003148 	cbz	x8, a854 <fwp_main_thread+0xf74>
    a230:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a234:	aa0403f4 	mov	x20, x4
    a238:	b93ed41b 	str	w27, [x0, #16084]
    a23c:	b93ed81c 	str	w28, [x0, #16088]
    a240:	b93ee016 	str	w22, [x0, #16096]
    a244:	14000012 	b	a28c <fwp_main_thread+0x9ac>
    a248:	f9400101 	ldr	x1, [x8]
    a24c:	aa1a03e0 	mov	x0, x26
    a250:	d63f0020 	blr	x1
    a254:	aa0003fc 	mov	x28, x0
    a258:	aa1703e0 	mov	x0, x23
    a25c:	97ffeec1 	bl	5d60 <fwp_closure_drop>
    a260:	6b1902df 	cmp	w22, w25
    a264:	54000d00 	b.eq	a404 <fwp_main_thread+0xb24>  // b.none
    a268:	f9404700 	ldr	x0, [x24, #136]
    a26c:	8b364f5a 	add	x26, x26, w22, uxtw #3
    a270:	b9400384 	ldr	w4, [x28]
    a274:	4b130379 	sub	w25, w27, w19
    a278:	aa1c03e7 	mov	x7, x28
    a27c:	8b041414 	add	x20, x0, x4, lsl #5
    a280:	f9400e88 	ldr	x8, [x20, #24]
    a284:	b4002de8 	cbz	x8, a840 <fwp_main_thread+0xf60>
    a288:	aa1c03f7 	mov	x23, x28
    a28c:	b94004e9 	ldr	w9, [x7, #4]
    a290:	b9400293 	ldr	w19, [x20]
    a294:	0b19013b 	add	w27, w9, w25
    a298:	6b1b027f 	cmp	w19, w27
    a29c:	54003768 	b.hi	a988 <fwp_main_thread+0x10a8>  // b.pmore
    a2a0:	7100013f 	cmp	w9, #0x0
    a2a4:	4b090276 	sub	w22, w19, w9
    a2a8:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    a2ac:	54fffce1 	b.ne	a248 <fwp_main_thread+0x968>  // b.any
    a2b0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a2b4:	910003e0 	mov	x0, sp
    a2b8:	7100027f 	cmp	w19, #0x0
    a2bc:	f91f7c20 	str	x0, [x1, #16120]
    a2c0:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    a2c4:	d37df000 	lsl	x0, x0, #3
    a2c8:	91003c00 	add	x0, x0, #0xf
    a2cc:	92704c01 	and	x1, x0, #0xfffff0000
    a2d0:	927c7c00 	and	x0, x0, #0xffffffff0
    a2d4:	cb2163e1 	sub	x1, sp, x1
    a2d8:	eb2163ff 	cmp	sp, x1
    a2dc:	540000a0 	b.eq	a2f0 <fwp_main_thread+0xa10>  // b.none
    a2e0:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a2e4:	f90203ff 	str	xzr, [sp, #1024]
    a2e8:	eb2163ff 	cmp	sp, x1
    a2ec:	54ffffa1 	b.ne	a2e0 <fwp_main_thread+0xa00>  // b.any
    a2f0:	92403c00 	and	x0, x0, #0xffff
    a2f4:	cb2063ff 	sub	sp, sp, x0
    a2f8:	f90003ff 	str	xzr, [sp]
    a2fc:	f110001f 	cmp	x0, #0x400
    a300:	54000043 	b.cc	a308 <fwp_main_thread+0xa28>  // b.lo, b.ul, b.last
    a304:	f90203ff 	str	xzr, [sp, #1024]
    a308:	910043fc 	add	x28, sp, #0x10
    a30c:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a310:	910020e1 	add	x1, x7, #0x8
    a314:	d2800000 	mov	x0, #0x0                   	// #0
    a318:	340000e9 	cbz	w9, a334 <fwp_main_thread+0xa54>
    a31c:	d503201f 	nop
    a320:	f8606823 	ldr	x3, [x1, x0]
    a324:	f8206b83 	str	x3, [x28, x0]
    a328:	91002000 	add	x0, x0, #0x8
    a32c:	eb02001f 	cmp	x0, x2
    a330:	54ffff81 	b.ne	a320 <fwp_main_thread+0xa40>  // b.any
    a334:	2a1603e1 	mov	w1, w22
    a338:	d2800000 	mov	x0, #0x0                   	// #0
    a33c:	340000f6 	cbz	w22, a358 <fwp_main_thread+0xa78>
    a340:	0b000122 	add	w2, w9, w0
    a344:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a348:	91000400 	add	x0, x0, #0x1
    a34c:	f8227b83 	str	x3, [x28, x2, lsl #3]
    a350:	eb01001f 	cmp	x0, x1
    a354:	54ffff61 	b.ne	a340 <fwp_main_thread+0xa60>  // b.any
    a358:	f949daa0 	ldr	x0, [x21, #5040]
    a35c:	f949eea1 	ldr	x1, [x21, #5080]
    a360:	cb0002e0 	sub	x0, x23, x0
    a364:	eb01401f 	cmp	x0, x1, lsl #16
    a368:	540002e2 	b.cs	a3c4 <fwp_main_thread+0xae4>  // b.hs, b.nlast
    a36c:	d350fc01 	lsr	x1, x0, #16
    a370:	f949fea5 	ldr	x5, [x21, #5112]
    a374:	8b010821 	add	x1, x1, x1, lsl #2
    a378:	d37df021 	lsl	x1, x1, #3
    a37c:	8b0100a3 	add	x3, x5, x1
    a380:	f9401062 	ldr	x2, [x3, #32]
    a384:	b4000202 	cbz	x2, a3c4 <fwp_main_thread+0xae4>
    a388:	386168a1 	ldrb	w1, [x5, x1]
    a38c:	7100083f 	cmp	w1, #0x2
    a390:	54002520 	b.eq	a834 <fwp_main_thread+0xf54>  // b.none
    a394:	7100043f 	cmp	w1, #0x1
    a398:	54000161 	b.ne	a3c4 <fwp_main_thread+0xae4>  // b.any
    a39c:	29430465 	ldp	w5, w1, [x3, #24]
    a3a0:	92403c00 	and	x0, x0, #0xffff
    a3a4:	9b057c00 	mul	x0, x0, x5
    a3a8:	d360fc00 	lsr	x0, x0, #32
    a3ac:	eb01001f 	cmp	x0, x1
    a3b0:	540000a2 	b.cs	a3c4 <fwp_main_thread+0xae4>  // b.hs, b.nlast
    a3b4:	8b000042 	add	x2, x2, x0
    a3b8:	39400040 	ldrb	w0, [x2]
    a3bc:	7100041f 	cmp	w0, #0x1
    a3c0:	54002360 	b.eq	a82c <fwp_main_thread+0xf4c>  // b.none
    a3c4:	f9400502 	ldr	x2, [x8, #8]
    a3c8:	aa1703e0 	mov	x0, x23
    a3cc:	52800021 	mov	w1, #0x1                   	// #1
    a3d0:	d63f0040 	blr	x2
    a3d4:	f9400e81 	ldr	x1, [x20, #24]
    a3d8:	aa1c03e0 	mov	x0, x28
    a3dc:	f9400021 	ldr	x1, [x1]
    a3e0:	d63f0020 	blr	x1
    a3e4:	aa0003fc 	mov	x28, x0
    a3e8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3ec:	f95f7c00 	ldr	x0, [x0, #16120]
    a3f0:	9100001f 	mov	sp, x0
    a3f4:	aa1703e0 	mov	x0, x23
    a3f8:	97ffee5a 	bl	5d60 <fwp_closure_drop>
    a3fc:	6b1902df 	cmp	w22, w25
    a400:	54fff341 	b.ne	a268 <fwp_main_thread+0x988>  // b.any
    a404:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a408:	aa1c03f7 	mov	x23, x28
    a40c:	b97ed41b 	ldr	w27, [x0, #16084]
    a410:	b97ed81c 	ldr	w28, [x0, #16088]
    a414:	b97ee016 	ldr	w22, [x0, #16096]
    a418:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a41c:	b97eec00 	ldr	w0, [x0, #16108]
    a420:	6b0002df 	cmp	w22, w0
    a424:	540024a3 	b.cc	a8b8 <fwp_main_thread+0xfd8>  // b.lo, b.ul, b.last
    a428:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a42c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a430:	f95f6016 	ldr	x22, [x0, #16064]
    a434:	f95f6404 	ldr	x4, [x0, #16072]
    a438:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a43c:	f95f5c00 	ldr	x0, [x0, #16056]
    a440:	f1000400 	subs	x0, x0, #0x1
    a444:	f91f5c20 	str	x0, [x1, #16056]
    a448:	54ffe441 	b.ne	a0d0 <fwp_main_thread+0x7f0>  // b.any
    a44c:	aa0103e0 	mov	x0, x1
    a450:	aa1703fc 	mov	x28, x23
    a454:	aa1703e1 	mov	x1, x23
    a458:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x107b0>
    a45c:	91102042 	add	x2, x2, #0x408
    a460:	52800023 	mov	w3, #0x1                   	// #1
    a464:	f95f4417 	ldr	x23, [x0, #16008]
    a468:	91014042 	add	x2, x2, #0x50
    a46c:	f95f481b 	ldr	x27, [x0, #16016]
    a470:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a474:	f95f4c14 	ldr	x20, [x0, #16024]
    a478:	f81303bf 	stur	xzr, [x29, #-208]
    a47c:	f95f5400 	ldr	x0, [x0, #16040]
    a480:	97fff91c 	bl	88f0 <fwp_write>
    a484:	a97267b5 	ldp	x21, x25, [x29, #-224]
    a488:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0x9e0>
    a48c:	9104e000 	add	x0, x0, #0x138
    a490:	f10002bf 	cmp	x21, #0x0
    a494:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a498:	b1002b3f 	cmn	x25, #0xa
    a49c:	54004c68 	b.hi	ae28 <fwp_main_thread+0x1548>  // b.pmore
    a4a0:	91002720 	add	x0, x25, #0x9
    a4a4:	52800021 	mov	w1, #0x1                   	// #1
    a4a8:	97ffea92 	bl	4ef0 <fwp_heap_alloc>
    a4ac:	aa0003f3 	mov	x19, x0
    a4b0:	aa1503e1 	mov	x1, x21
    a4b4:	aa0003f5 	mov	x21, x0
    a4b8:	aa1903e2 	mov	x2, x25
    a4bc:	f80086b9 	str	x25, [x21], #8
    a4c0:	8b190279 	add	x25, x19, x25
    a4c4:	aa1503e0 	mov	x0, x21
    a4c8:	97ffe082 	bl	26d0 <memcpy@plt>
    a4cc:	3900233f 	strb	wzr, [x25, #8]
    a4d0:	f85203a0 	ldur	x0, [x29, #-224]
    a4d4:	97ffe11b 	bl	2940 <free@plt>
    a4d8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a4dc:	91174002 	add	x2, x0, #0x5d0
    a4e0:	f949d841 	ldr	x1, [x2, #5040]
    a4e4:	f949ec40 	ldr	x0, [x2, #5080]
    a4e8:	cb010261 	sub	x1, x19, x1
    a4ec:	eb00403f 	cmp	x1, x0, lsl #16
    a4f0:	54000322 	b.cs	a554 <fwp_main_thread+0xc74>  // b.hs, b.nlast
    a4f4:	d350fc20 	lsr	x0, x1, #16
    a4f8:	f949fc43 	ldr	x3, [x2, #5112]
    a4fc:	8b000800 	add	x0, x0, x0, lsl #2
    a500:	d37df002 	lsl	x2, x0, #3
    a504:	8b020060 	add	x0, x3, x2
    a508:	f9401019 	ldr	x25, [x0, #32]
    a50c:	b4000259 	cbz	x25, a554 <fwp_main_thread+0xc74>
    a510:	38626862 	ldrb	w2, [x3, x2]
    a514:	7100085f 	cmp	w2, #0x2
    a518:	54004a80 	b.eq	ae68 <fwp_main_thread+0x1588>  // b.none
    a51c:	7100045f 	cmp	w2, #0x1
    a520:	540001a1 	b.ne	a554 <fwp_main_thread+0xc74>  // b.any
    a524:	29430002 	ldp	w2, w0, [x0, #24]
    a528:	92403c21 	and	x1, x1, #0xffff
    a52c:	9b027c21 	mul	x1, x1, x2
    a530:	d360fc21 	lsr	x1, x1, #32
    a534:	eb00003f 	cmp	x1, x0
    a538:	540000e2 	b.cs	a554 <fwp_main_thread+0xc74>  // b.hs, b.nlast
    a53c:	8b010339 	add	x25, x25, x1
    a540:	39400320 	ldrb	w0, [x25]
    a544:	7103fc1f 	cmp	w0, #0xff
    a548:	54004d00 	b.eq	aee8 <fwp_main_thread+0x1608>  // b.none
    a54c:	52800020 	mov	w0, #0x1                   	// #1
    a550:	39000320 	strb	w0, [x25]
    a554:	aa1c03e0 	mov	x0, x28
    a558:	97ffed52 	bl	5aa0 <fwp_drop0>
    a55c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a560:	9101c003 	add	x3, x0, #0x70
    a564:	f9400262 	ldr	x2, [x19]
    a568:	aa1503e0 	mov	x0, x21
    a56c:	aa0303f5 	mov	x21, x3
    a570:	d2800021 	mov	x1, #0x1                   	// #1
    a574:	f9400463 	ldr	x3, [x3, #8]
    a578:	97ffe102 	bl	2980 <fwrite@plt>
    a57c:	f94006a1 	ldr	x1, [x21, #8]
    a580:	52800140 	mov	w0, #0xa                   	// #10
    a584:	97ffe087 	bl	27a0 <fputc@plt>
    a588:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a58c:	91174002 	add	x2, x0, #0x5d0
    a590:	f949d841 	ldr	x1, [x2, #5040]
    a594:	f949ec40 	ldr	x0, [x2, #5080]
    a598:	cb010261 	sub	x1, x19, x1
    a59c:	eb00403f 	cmp	x1, x0, lsl #16
    a5a0:	54000382 	b.cs	a610 <fwp_main_thread+0xd30>  // b.hs, b.nlast
    a5a4:	d350fc20 	lsr	x0, x1, #16
    a5a8:	f949fc43 	ldr	x3, [x2, #5112]
    a5ac:	8b000800 	add	x0, x0, x0, lsl #2
    a5b0:	d37df000 	lsl	x0, x0, #3
    a5b4:	8b000062 	add	x2, x3, x0
    a5b8:	f9401055 	ldr	x21, [x2, #32]
    a5bc:	b40002b5 	cbz	x21, a610 <fwp_main_thread+0xd30>
    a5c0:	38606860 	ldrb	w0, [x3, x0]
    a5c4:	7100081f 	cmp	w0, #0x2
    a5c8:	540044a0 	b.eq	ae5c <fwp_main_thread+0x157c>  // b.none
    a5cc:	7100041f 	cmp	w0, #0x1
    a5d0:	54000201 	b.ne	a610 <fwp_main_thread+0xd30>  // b.any
    a5d4:	29430043 	ldp	w3, w0, [x2, #24]
    a5d8:	92403c21 	and	x1, x1, #0xffff
    a5dc:	9b037c21 	mul	x1, x1, x3
    a5e0:	d360fc21 	lsr	x1, x1, #32
    a5e4:	eb00003f 	cmp	x1, x0
    a5e8:	54000142 	b.cs	a610 <fwp_main_thread+0xd30>  // b.hs, b.nlast
    a5ec:	8b0102b5 	add	x21, x21, x1
    a5f0:	394002a0 	ldrb	w0, [x21]
    a5f4:	340000e0 	cbz	w0, a610 <fwp_main_thread+0xd30>
    a5f8:	7100041f 	cmp	w0, #0x1
    a5fc:	540046a0 	b.eq	aed0 <fwp_main_thread+0x15f0>  // b.none
    a600:	7103fc1f 	cmp	w0, #0xff
    a604:	54004380 	b.eq	ae74 <fwp_main_thread+0x1594>  // b.none
    a608:	51000400 	sub	w0, w0, #0x1
    a60c:	390002a0 	strb	w0, [x21]
    a610:	f9400b7b 	ldr	x27, [x27, #16]
    a614:	b400411b 	cbz	x27, ae34 <fwp_main_thread+0x1554>
    a618:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a61c:	91174000 	add	x0, x0, #0x5d0
    a620:	f949ec02 	ldr	x2, [x0, #5080]
    a624:	f949d801 	ldr	x1, [x0, #5040]
    a628:	d370bc42 	lsl	x2, x2, #16
    a62c:	cb010281 	sub	x1, x20, x1
    a630:	17fffe83 	b	a03c <fwp_main_thread+0x75c>
    a634:	f9004293 	str	x19, [x20, #128]
    a638:	17fffd4f 	b	9b74 <fwp_main_thread+0x294>
    a63c:	f941b2a0 	ldr	x0, [x21, #864]
    a640:	b9035abf 	str	wzr, [x21, #856]
    a644:	b5ffaca0 	cbnz	x0, 9bd8 <fwp_main_thread+0x2f8>
    a648:	97ffef36 	bl	6320 <fwp_free_zombie>
    a64c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a650:	9101c015 	add	x21, x0, #0x70
    a654:	f94042a0 	ldr	x0, [x21, #128]
    a658:	b5ffac00 	cbnz	x0, 9bd8 <fwp_main_thread+0x2f8>
    a65c:	f9406ea0 	ldr	x0, [x21, #216]
    a660:	b5ffabc0 	cbnz	x0, 9bd8 <fwp_main_thread+0x2f8>
    a664:	b940faa0 	ldr	w0, [x21, #248]
    a668:	340001c0 	cbz	w0, a6a0 <fwp_main_thread+0xdc0>
    a66c:	93407c14 	sxtw	x20, w0
    a670:	51000400 	sub	w0, w0, #0x1
    a674:	d1000a94 	sub	x20, x20, #0x2
    a678:	910402b6 	add	x22, x21, #0x100
    a67c:	cb204294 	sub	x20, x20, w0, uxtw
    a680:	93407c13 	sxtw	x19, w0
    a684:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    a688:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a68c:	b900fab3 	str	w19, [x21, #248]
    a690:	d1000673 	sub	x19, x19, #0x1
    a694:	97ffe0c3 	bl	29a0 <munmap@plt>
    a698:	eb14027f 	cmp	x19, x20
    a69c:	54ffff41 	b.ne	a684 <fwp_main_thread+0xda4>  // b.any
    a6a0:	d00000bc 	adrp	x28, 20000 <__data_start>
    a6a4:	91004380 	add	x0, x28, #0x10
    a6a8:	b9404800 	ldr	w0, [x0, #72]
    a6ac:	37f80040 	tbnz	w0, #31, a6b4 <fwp_main_thread+0xdd4>
    a6b0:	97ffe078 	bl	2890 <close@plt>
    a6b4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a6b8:	9101c000 	add	x0, x0, #0x70
    a6bc:	9100439c 	add	x28, x28, #0x10
    a6c0:	12800001 	mov	w1, #0xffffffff            	// #-1
    a6c4:	d2800013 	mov	x19, #0x0                   	// #0
    a6c8:	f941b415 	ldr	x21, [x0, #872]
    a6cc:	b9004b81 	str	w1, [x28, #72]
    a6d0:	f941b814 	ldr	x20, [x0, #880]
    a6d4:	b4000175 	cbz	x21, a700 <fwp_main_thread+0xe20>
    a6d8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    a6dc:	b40000c0 	cbz	x0, a6f4 <fwp_main_thread+0xe14>
    a6e0:	f9400001 	ldr	x1, [x0]
    a6e4:	b5ffa7a1 	cbnz	x1, 9bd8 <fwp_main_thread+0x2f8>
    a6e8:	f9400401 	ldr	x1, [x0, #8]
    a6ec:	b5ffa761 	cbnz	x1, 9bd8 <fwp_main_thread+0x2f8>
    a6f0:	97ffe8e0 	bl	4a70 <fwp_mem_free>
    a6f4:	91000673 	add	x19, x19, #0x1
    a6f8:	eb1302bf 	cmp	x21, x19
    a6fc:	54fffee1 	b.ne	a6d8 <fwp_main_thread+0xdf8>  // b.any
    a700:	aa1403e0 	mov	x0, x20
    a704:	97ffe8db 	bl	4a70 <fwp_mem_free>
    a708:	d00000a0 	adrp	x0, 20000 <__data_start>
    a70c:	9101c000 	add	x0, x0, #0x70
    a710:	f941b013 	ldr	x19, [x0, #864]
    a714:	f901b41f 	str	xzr, [x0, #872]
    a718:	f901b81f 	str	xzr, [x0, #880]
    a71c:	b40001f3 	cbz	x19, a758 <fwp_main_thread+0xe78>
    a720:	f9401661 	ldr	x1, [x19, #40]
    a724:	b5ffa5a1 	cbnz	x1, 9bd8 <fwp_main_thread+0x2f8>
    a728:	f9405661 	ldr	x1, [x19, #168]
    a72c:	b5ffa561 	cbnz	x1, 9bd8 <fwp_main_thread+0x2f8>
    a730:	f9419401 	ldr	x1, [x0, #808]
    a734:	b5ffa521 	cbnz	x1, 9bd8 <fwp_main_thread+0x2f8>
    a738:	f9419c00 	ldr	x0, [x0, #824]
    a73c:	b5ffa4e0 	cbnz	x0, 9bd8 <fwp_main_thread+0x2f8>
    a740:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a744:	d0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    a748:	910fc000 	add	x0, x0, #0x3f0
    a74c:	97ffe041 	bl	2850 <memset@plt>
    a750:	aa1303e0 	mov	x0, x19
    a754:	97ffe8c7 	bl	4a70 <fwp_mem_free>
    a758:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a75c:	f947ec00 	ldr	x0, [x0, #4056]
    a760:	d00000a1 	adrp	x1, 20000 <__data_start>
    a764:	9101c021 	add	x1, x1, #0x70
    a768:	f9400000 	ldr	x0, [x0]
    a76c:	f900083f 	str	xzr, [x1, #16]
    a770:	f901b03f 	str	xzr, [x1, #864]
    a774:	97ffe08f 	bl	29b0 <fflush@plt>
    a778:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a77c:	f947f400 	ldr	x0, [x0, #4072]
    a780:	f85f83a2 	ldur	x2, [x29, #-8]
    a784:	f9400001 	ldr	x1, [x0]
    a788:	eb010042 	subs	x2, x2, x1
    a78c:	d2800001 	mov	x1, #0x0                   	// #0
    a790:	54003401 	b.ne	ae10 <fwp_main_thread+0x1530>  // b.any
    a794:	910003bf 	mov	sp, x29
    a798:	d2800000 	mov	x0, #0x0                   	// #0
    a79c:	a94153f3 	ldp	x19, x20, [sp, #16]
    a7a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a7a4:	a94363f7 	ldp	x23, x24, [sp, #48]
    a7a8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a7ac:	a94573fb 	ldp	x27, x28, [sp, #80]
    a7b0:	fd4033e8 	ldr	d8, [sp, #96]
    a7b4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    a7b8:	d65f03c0 	ret
    a7bc:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    a7c0:	913e8000 	add	x0, x0, #0xfa0
    a7c4:	9400038b 	bl	b5f0 <atexit>
    a7c8:	17fffc5c 	b	9938 <fwp_main_thread+0x58>
    a7cc:	97ffe64e 	bl	4104 <fwp_heap_init>
    a7d0:	17fffc56 	b	9928 <fwp_main_thread+0x48>
    a7d4:	f9400435 	ldr	x21, [x1, #8]
    a7d8:	b4000115 	cbz	x21, a7f8 <fwp_main_thread+0xf18>
    a7dc:	f9400820 	ldr	x0, [x1, #16]
    a7e0:	cb150000 	sub	x0, x0, x21
    a7e4:	eb00035f 	cmp	x26, x0
    a7e8:	54000088 	b.hi	a7f8 <fwp_main_thread+0xf18>  // b.pmore
    a7ec:	8b1a02a0 	add	x0, x21, x26
    a7f0:	f9000420 	str	x0, [x1, #8]
    a7f4:	17fffd53 	b	9d40 <fwp_main_thread+0x460>
    a7f8:	52800001 	mov	w1, #0x0                   	// #0
    a7fc:	d2800300 	mov	x0, #0x18                  	// #24
    a800:	97ffe9bc 	bl	4ef0 <fwp_heap_alloc>
    a804:	aa0003f5 	mov	x21, x0
    a808:	17fffd62 	b	9d90 <fwp_main_thread+0x4b0>
    a80c:	72003c5f 	tst	w2, #0xffff
    a810:	54ffafe1 	b.ne	9e0c <fwp_main_thread+0x52c>  // b.any
    a814:	39400340 	ldrb	w0, [x26]
    a818:	7103fc1f 	cmp	w0, #0xff
    a81c:	54ffaf61 	b.ne	9e08 <fwp_main_thread+0x528>  // b.any
    a820:	aa1a03e0 	mov	x0, x26
    a824:	97ffe7f3 	bl	47f0 <fwp_rc_forget_slot>
    a828:	17fffd78 	b	9e08 <fwp_main_thread+0x528>
    a82c:	b90004ff 	str	wzr, [x7, #4]
    a830:	17fffee9 	b	a3d4 <fwp_main_thread+0xaf4>
    a834:	72003c1f 	tst	w0, #0xffff
    a838:	54ffdc61 	b.ne	a3c4 <fwp_main_thread+0xae4>  // b.any
    a83c:	17fffedf 	b	a3b8 <fwp_main_thread+0xad8>
    a840:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a844:	aa1c03e9 	mov	x9, x28
    a848:	b97ed41b 	ldr	w27, [x0, #16084]
    a84c:	b97ed81c 	ldr	w28, [x0, #16088]
    a850:	b97ee016 	ldr	w22, [x0, #16096]
    a854:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a858:	aa0903e0 	mov	x0, x9
    a85c:	f91f7c29 	str	x9, [x1, #16120]
    a860:	97ffec21 	bl	58e4 <fwp_rc_share>
    a864:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a868:	f95f7c09 	ldr	x9, [x0, #16120]
    a86c:	34000159 	cbz	w25, a894 <fwp_main_thread+0xfb4>
    a870:	8b394f53 	add	x19, x26, w25, uxtw #3
    a874:	aa1a03f4 	mov	x20, x26
    a878:	aa0903f7 	mov	x23, x9
    a87c:	d503201f 	nop
    a880:	f8408680 	ldr	x0, [x20], #8
    a884:	97ffec18 	bl	58e4 <fwp_rc_share>
    a888:	eb13029f 	cmp	x20, x19
    a88c:	54ffffa1 	b.ne	a880 <fwp_main_thread+0xfa0>  // b.any
    a890:	aa1703e9 	mov	x9, x23
    a894:	aa1a03e2 	mov	x2, x26
    a898:	2a1903e1 	mov	w1, w25
    a89c:	aa0903e0 	mov	x0, x9
    a8a0:	97ffe9d9 	bl	5004 <fwp_apply>
    a8a4:	aa0003f7 	mov	x23, x0
    a8a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8ac:	b97eec00 	ldr	w0, [x0, #16108]
    a8b0:	6b0002df 	cmp	w22, w0
    a8b4:	54ffdba2 	b.cs	a428 <fwp_main_thread+0xb48>  // b.hs, b.nlast
    a8b8:	f9404701 	ldr	x1, [x24, #136]
    a8bc:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a8c0:	b94002e4 	ldr	w4, [x23]
    a8c4:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a8c8:	4b1c0000 	sub	w0, w0, w28
    a8cc:	f95f7842 	ldr	x2, [x2, #16112]
    a8d0:	8b041424 	add	x4, x1, x4, lsl #5
    a8d4:	b93eec60 	str	w0, [x3, #16108]
    a8d8:	b97ee860 	ldr	w0, [x3, #16104]
    a8dc:	f9400c81 	ldr	x1, [x4, #24]
    a8e0:	4b1b0000 	sub	w0, w0, w27
    a8e4:	8b3c4c42 	add	x2, x2, w28, uxtw #3
    a8e8:	b93ee860 	str	w0, [x3, #16104]
    a8ec:	f91f7862 	str	x2, [x3, #16112]
    a8f0:	aa1703e0 	mov	x0, x23
    a8f4:	b5ffc621 	cbnz	x1, a1b8 <fwp_main_thread+0x8d8>
    a8f8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8fc:	f95f6404 	ldr	x4, [x0, #16072]
    a900:	f91f7c04 	str	x4, [x0, #16120]
    a904:	f95f6016 	ldr	x22, [x0, #16064]
    a908:	b97eec14 	ldr	w20, [x0, #16108]
    a90c:	aa1703e0 	mov	x0, x23
    a910:	97ffebf5 	bl	58e4 <fwp_rc_share>
    a914:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a918:	f95f7c04 	ldr	x4, [x0, #16120]
    a91c:	34000174 	cbz	w20, a948 <fwp_main_thread+0x1068>
    a920:	f95f781a 	ldr	x26, [x0, #16112]
    a924:	aa0403fb 	mov	x27, x4
    a928:	d2800015 	mov	x21, #0x0                   	// #0
    a92c:	d503201f 	nop
    a930:	f8757b40 	ldr	x0, [x26, x21, lsl #3]
    a934:	910006b5 	add	x21, x21, #0x1
    a938:	97ffebeb 	bl	58e4 <fwp_rc_share>
    a93c:	6b15029f 	cmp	w20, w21
    a940:	54ffff88 	b.hi	a930 <fwp_main_thread+0x1050>  // b.pmore
    a944:	aa1b03e4 	mov	x4, x27
    a948:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a94c:	2a1403e1 	mov	w1, w20
    a950:	f95f7802 	ldr	x2, [x0, #16112]
    a954:	f91f7c04 	str	x4, [x0, #16120]
    a958:	aa1703e0 	mov	x0, x23
    a95c:	97ffe9aa 	bl	5004 <fwp_apply>
    a960:	aa0003f7 	mov	x23, x0
    a964:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a968:	f95f7c04 	ldr	x4, [x0, #16120]
    a96c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a970:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a974:	f95f5c00 	ldr	x0, [x0, #16056]
    a978:	f1000400 	subs	x0, x0, #0x1
    a97c:	f91f5c20 	str	x0, [x1, #16056]
    a980:	54ffba81 	b.ne	a0d0 <fwp_main_thread+0x7f0>  // b.any
    a984:	17fffeb2 	b	a44c <fwp_main_thread+0xb6c>
    a988:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a98c:	2a1b03e2 	mov	w2, w27
    a990:	aa1403e4 	mov	x4, x20
    a994:	b97ed41b 	ldr	w27, [x0, #16084]
    a998:	b97ed81c 	ldr	w28, [x0, #16088]
    a99c:	b97ee016 	ldr	w22, [x0, #16096]
    a9a0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a9a4:	9117400a 	add	x10, x0, #0x5d0
    a9a8:	11000440 	add	w0, w2, #0x1
    a9ac:	f120001f 	cmp	x0, #0x800
    a9b0:	d37df000 	lsl	x0, x0, #3
    a9b4:	b953a541 	ldr	w1, [x10, #5028]
    a9b8:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a9bc:	540018e0 	b.eq	acd8 <fwp_main_thread+0x13f8>  // b.none
    a9c0:	91003c01 	add	x1, x0, #0xf
    a9c4:	8b411141 	add	x1, x10, x1, lsr #4
    a9c8:	397e8021 	ldrb	w1, [x1, #4000]
    a9cc:	910f002b 	add	x11, x1, #0x3c0
    a9d0:	8b010428 	add	x8, x1, x1, lsl #1
    a9d4:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a9d8:	8b080d4c 	add	x12, x10, x8, lsl #3
    a9dc:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a9e0:	2a0b03e1 	mov	w1, w11
    a9e4:	b4001693 	cbz	x19, acb4 <fwp_main_thread+0x13d4>
    a9e8:	f940026c 	ldr	x12, [x19]
    a9ec:	aa2c03ec 	mvn	x12, x12
    a9f0:	f828794c 	str	x12, [x10, x8, lsl #3]
    a9f4:	eb01001f 	cmp	x0, x1
    a9f8:	540000c2 	b.cs	aa10 <fwp_main_thread+0x1130>  // b.hs, b.nlast
    a9fc:	d503201f 	nop
    aa00:	f8206a7f 	str	xzr, [x19, x0]
    aa04:	91002000 	add	x0, x0, #0x8
    aa08:	eb00003f 	cmp	x1, x0
    aa0c:	54ffffa8 	b.hi	aa00 <fwp_main_thread+0x1120>  // b.pmore
    aa10:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    aa14:	91174008 	add	x8, x0, #0x5d0
    aa18:	f94a1100 	ldr	x0, [x8, #5152]
    aa1c:	ab010000 	adds	x0, x0, x1
    aa20:	54001fa2 	b.cs	ae14 <fwp_main_thread+0x1534>  // b.hs, b.nlast
    aa24:	f94a1501 	ldr	x1, [x8, #5160]
    aa28:	f90a1100 	str	x0, [x8, #5152]
    aa2c:	eb01001f 	cmp	x0, x1
    aa30:	54000049 	b.ls	aa38 <fwp_main_thread+0x1158>  // b.plast
    aa34:	f90a1500 	str	x0, [x8, #5160]
    aa38:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    aa3c:	91174000 	add	x0, x0, #0x5d0
    aa40:	1e630161 	ucvtf	d1, w11
    aa44:	fd4a1c00 	ldr	d0, [x0, #5176]
    aa48:	1e612800 	fadd	d0, d0, d1
    aa4c:	fd0a1c00 	str	d0, [x0, #5176]
    aa50:	b94000e0 	ldr	w0, [x7]
    aa54:	29000a60 	stp	w0, w2, [x19]
    aa58:	340001a9 	cbz	w9, aa8c <fwp_main_thread+0x11ac>
    aa5c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa60:	d37d7d22 	ubfiz	x2, x9, #3, #32
    aa64:	910020e1 	add	x1, x7, #0x8
    aa68:	f91f6c04 	str	x4, [x0, #16088]
    aa6c:	b93ee009 	str	w9, [x0, #16096]
    aa70:	f91f7c07 	str	x7, [x0, #16120]
    aa74:	91002260 	add	x0, x19, #0x8
    aa78:	97ffdf1e 	bl	26f0 <memmove@plt>
    aa7c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa80:	f95f6c04 	ldr	x4, [x0, #16088]
    aa84:	f95f7c07 	ldr	x7, [x0, #16120]
    aa88:	b97ee009 	ldr	w9, [x0, #16096]
    aa8c:	2a1903e8 	mov	w8, w25
    aa90:	d2800001 	mov	x1, #0x0                   	// #0
    aa94:	34000119 	cbz	w25, aab4 <fwp_main_thread+0x11d4>
    aa98:	0b010120 	add	w0, w9, w1
    aa9c:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    aaa0:	8b000e60 	add	x0, x19, x0, lsl #3
    aaa4:	91000421 	add	x1, x1, #0x1
    aaa8:	f9000402 	str	x2, [x0, #8]
    aaac:	eb08003f 	cmp	x1, x8
    aab0:	54ffff41 	b.ne	aa98 <fwp_main_thread+0x11b8>  // b.any
    aab4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    aab8:	91174002 	add	x2, x0, #0x5d0
    aabc:	f949d840 	ldr	x0, [x2, #5040]
    aac0:	f949ec41 	ldr	x1, [x2, #5080]
    aac4:	cb0002e0 	sub	x0, x23, x0
    aac8:	eb01401f 	cmp	x0, x1, lsl #16
    aacc:	540002e2 	b.cs	ab28 <fwp_main_thread+0x1248>  // b.hs, b.nlast
    aad0:	d350fc01 	lsr	x1, x0, #16
    aad4:	f949fc48 	ldr	x8, [x2, #5112]
    aad8:	8b010821 	add	x1, x1, x1, lsl #2
    aadc:	d37df021 	lsl	x1, x1, #3
    aae0:	8b010105 	add	x5, x8, x1
    aae4:	f94010a2 	ldr	x2, [x5, #32]
    aae8:	b4000202 	cbz	x2, ab28 <fwp_main_thread+0x1248>
    aaec:	38616901 	ldrb	w1, [x8, x1]
    aaf0:	7100083f 	cmp	w1, #0x2
    aaf4:	540010e0 	b.eq	ad10 <fwp_main_thread+0x1430>  // b.none
    aaf8:	7100043f 	cmp	w1, #0x1
    aafc:	54000161 	b.ne	ab28 <fwp_main_thread+0x1248>  // b.any
    ab00:	294304a8 	ldp	w8, w1, [x5, #24]
    ab04:	92403c00 	and	x0, x0, #0xffff
    ab08:	9b087c00 	mul	x0, x0, x8
    ab0c:	d360fc00 	lsr	x0, x0, #32
    ab10:	eb01001f 	cmp	x0, x1
    ab14:	540000a2 	b.cs	ab28 <fwp_main_thread+0x1248>  // b.hs, b.nlast
    ab18:	8b000042 	add	x2, x2, x0
    ab1c:	39400040 	ldrb	w0, [x2]
    ab20:	7100041f 	cmp	w0, #0x1
    ab24:	54000be0 	b.eq	aca0 <fwp_main_thread+0x13c0>  // b.none
    ab28:	f9400c82 	ldr	x2, [x4, #24]
    ab2c:	aa1703e0 	mov	x0, x23
    ab30:	52800021 	mov	w1, #0x1                   	// #1
    ab34:	f9400442 	ldr	x2, [x2, #8]
    ab38:	d63f0040 	blr	x2
    ab3c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    ab40:	91174002 	add	x2, x0, #0x5d0
    ab44:	f949d841 	ldr	x1, [x2, #5040]
    ab48:	f949ec40 	ldr	x0, [x2, #5080]
    ab4c:	cb010261 	sub	x1, x19, x1
    ab50:	eb00403f 	cmp	x1, x0, lsl #16
    ab54:	54000322 	b.cs	abb8 <fwp_main_thread+0x12d8>  // b.hs, b.nlast
    ab58:	d350fc20 	lsr	x0, x1, #16
    ab5c:	f949fc44 	ldr	x4, [x2, #5112]
    ab60:	8b000800 	add	x0, x0, x0, lsl #2
    ab64:	d37df002 	lsl	x2, x0, #3
    ab68:	8b020080 	add	x0, x4, x2
    ab6c:	f9401019 	ldr	x25, [x0, #32]
    ab70:	b4000259 	cbz	x25, abb8 <fwp_main_thread+0x12d8>
    ab74:	38626882 	ldrb	w2, [x4, x2]
    ab78:	7100085f 	cmp	w2, #0x2
    ab7c:	54000d00 	b.eq	ad1c <fwp_main_thread+0x143c>  // b.none
    ab80:	7100045f 	cmp	w2, #0x1
    ab84:	540001a1 	b.ne	abb8 <fwp_main_thread+0x12d8>  // b.any
    ab88:	29430002 	ldp	w2, w0, [x0, #24]
    ab8c:	92403c21 	and	x1, x1, #0xffff
    ab90:	9b027c21 	mul	x1, x1, x2
    ab94:	d360fc21 	lsr	x1, x1, #32
    ab98:	eb00003f 	cmp	x1, x0
    ab9c:	540000e2 	b.cs	abb8 <fwp_main_thread+0x12d8>  // b.hs, b.nlast
    aba0:	8b010339 	add	x25, x25, x1
    aba4:	39400320 	ldrb	w0, [x25]
    aba8:	7103fc1f 	cmp	w0, #0xff
    abac:	54000c20 	b.eq	ad30 <fwp_main_thread+0x1450>  // b.none
    abb0:	52800020 	mov	w0, #0x1                   	// #1
    abb4:	39000320 	strb	w0, [x25]
    abb8:	aa1703e0 	mov	x0, x23
    abbc:	aa1303f7 	mov	x23, x19
    abc0:	97ffec68 	bl	5d60 <fwp_closure_drop>
    abc4:	17ffff39 	b	a8a8 <fwp_main_thread+0xfc8>
    abc8:	b86268a0 	ldr	w0, [x5, x2]
    abcc:	b94004c2 	ldr	w2, [x6, #4]
    abd0:	4b020003 	sub	w3, w0, w2
    abd4:	7100047f 	cmp	w3, #0x1
    abd8:	54ffa961 	b.ne	a104 <fwp_main_thread+0x824>  // b.any
    abdc:	910003f4 	mov	x20, sp
    abe0:	34000ba2 	cbz	w2, ad54 <fwp_main_thread+0x1474>
    abe4:	7100001f 	cmp	w0, #0x0
    abe8:	d37d7c00 	ubfiz	x0, x0, #3, #32
    abec:	d2800101 	mov	x1, #0x8                   	// #8
    abf0:	9a81101a 	csel	x26, x0, x1, ne	// ne = any
    abf4:	91003f40 	add	x0, x26, #0xf
    abf8:	92704c01 	and	x1, x0, #0xfffff0000
    abfc:	927c7c00 	and	x0, x0, #0xffffffff0
    ac00:	cb2163e1 	sub	x1, sp, x1
    ac04:	eb2163ff 	cmp	sp, x1
    ac08:	540000a0 	b.eq	ac1c <fwp_main_thread+0x133c>  // b.none
    ac0c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    ac10:	f90203ff 	str	xzr, [sp, #1024]
    ac14:	eb2163ff 	cmp	sp, x1
    ac18:	54ffffa1 	b.ne	ac0c <fwp_main_thread+0x132c>  // b.any
    ac1c:	92403c00 	and	x0, x0, #0xffff
    ac20:	cb2063ff 	sub	sp, sp, x0
    ac24:	f90003ff 	str	xzr, [sp]
    ac28:	f110001f 	cmp	x0, #0x400
    ac2c:	54000043 	b.cc	ac34 <fwp_main_thread+0x1354>  // b.lo, b.ul, b.last
    ac30:	f90203ff 	str	xzr, [sp, #1024]
    ac34:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac38:	d37d7c5b 	ubfiz	x27, x2, #3, #32
    ac3c:	910043f5 	add	x21, sp, #0x10
    ac40:	aa1b03e2 	mov	x2, x27
    ac44:	aa1a03e3 	mov	x3, x26
    ac48:	f91f7c04 	str	x4, [x0, #16120]
    ac4c:	f95f5800 	ldr	x0, [x0, #16048]
    ac50:	91004001 	add	x1, x0, #0x10
    ac54:	aa1503e0 	mov	x0, x21
    ac58:	91012021 	add	x1, x1, #0x48
    ac5c:	97ffdedd 	bl	27d0 <__memcpy_chk@plt>
    ac60:	eb1b035f 	cmp	x26, x27
    ac64:	aa1603e1 	mov	x1, x22
    ac68:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    ac6c:	d2800102 	mov	x2, #0x8                   	// #8
    ac70:	cb1b0063 	sub	x3, x3, x27
    ac74:	8b1b02a0 	add	x0, x21, x27
    ac78:	97ffded6 	bl	27d0 <__memcpy_chk@plt>
    ac7c:	f9400f81 	ldr	x1, [x28, #24]
    ac80:	aa1503e0 	mov	x0, x21
    ac84:	f9400021 	ldr	x1, [x1]
    ac88:	d63f0020 	blr	x1
    ac8c:	aa0003f7 	mov	x23, x0
    ac90:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac94:	f95f7c04 	ldr	x4, [x0, #16120]
    ac98:	9100029f 	mov	sp, x20
    ac9c:	17ffff34 	b	a96c <fwp_main_thread+0x108c>
    aca0:	b90004ff 	str	wzr, [x7, #4]
    aca4:	17ffffa6 	b	ab3c <fwp_main_thread+0x125c>
    aca8:	72003c3f 	tst	w1, #0xffff
    acac:	54ffa6c1 	b.ne	a184 <fwp_main_thread+0x8a4>  // b.any
    acb0:	17fffd2f 	b	a16c <fwp_main_thread+0x88c>
    acb4:	f9400593 	ldr	x19, [x12, #8]
    acb8:	b4000113 	cbz	x19, acd8 <fwp_main_thread+0x13f8>
    acbc:	f9400988 	ldr	x8, [x12, #16]
    acc0:	cb130108 	sub	x8, x8, x19
    acc4:	eb08003f 	cmp	x1, x8
    acc8:	54000088 	b.hi	acd8 <fwp_main_thread+0x13f8>  // b.pmore
    accc:	8b010268 	add	x8, x19, x1
    acd0:	f9000588 	str	x8, [x12, #8]
    acd4:	17ffff48 	b	a9f4 <fwp_main_thread+0x1114>
    acd8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    acdc:	b93ed422 	str	w2, [x1, #16084]
    ace0:	b93ed829 	str	w9, [x1, #16088]
    ace4:	f91f7024 	str	x4, [x1, #16096]
    ace8:	f91f7c27 	str	x7, [x1, #16120]
    acec:	52800001 	mov	w1, #0x0                   	// #0
    acf0:	97ffe880 	bl	4ef0 <fwp_heap_alloc>
    acf4:	aa0003f3 	mov	x19, x0
    acf8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acfc:	f95f7004 	ldr	x4, [x0, #16096]
    ad00:	f95f7c07 	ldr	x7, [x0, #16120]
    ad04:	b97ed402 	ldr	w2, [x0, #16084]
    ad08:	b97ed809 	ldr	w9, [x0, #16088]
    ad0c:	17ffff51 	b	aa50 <fwp_main_thread+0x1170>
    ad10:	72003c1f 	tst	w0, #0xffff
    ad14:	54fff0a1 	b.ne	ab28 <fwp_main_thread+0x1248>  // b.any
    ad18:	17ffff81 	b	ab1c <fwp_main_thread+0x123c>
    ad1c:	72003c3f 	tst	w1, #0xffff
    ad20:	54fff4c1 	b.ne	abb8 <fwp_main_thread+0x12d8>  // b.any
    ad24:	39400320 	ldrb	w0, [x25]
    ad28:	7103fc1f 	cmp	w0, #0xff
    ad2c:	54fff421 	b.ne	abb0 <fwp_main_thread+0x12d0>  // b.any
    ad30:	aa1903e0 	mov	x0, x25
    ad34:	97ffe6af 	bl	47f0 <fwp_rc_forget_slot>
    ad38:	17ffff9e 	b	abb0 <fwp_main_thread+0x12d0>
    ad3c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad40:	f91f7c24 	str	x4, [x1, #16120]
    ad44:	97ffe664 	bl	46d4 <fwp_rc_wide_dup>
    ad48:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad4c:	f95f7c04 	ldr	x4, [x0, #16120]
    ad50:	17fffd0d 	b	a184 <fwp_main_thread+0x8a4>
    ad54:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad58:	f9400021 	ldr	x1, [x1]
    ad5c:	f91f7c04 	str	x4, [x0, #16120]
    ad60:	aa1603e0 	mov	x0, x22
    ad64:	d63f0020 	blr	x1
    ad68:	aa0003f7 	mov	x23, x0
    ad6c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad70:	f95f7c04 	ldr	x4, [x0, #16120]
    ad74:	9100029f 	mov	sp, x20
    ad78:	17fffefd 	b	a96c <fwp_main_thread+0x108c>
    ad7c:	72003c3f 	tst	w1, #0xffff
    ad80:	54ff8a41 	b.ne	9ec8 <fwp_main_thread+0x5e8>  // b.any
    ad84:	17fffc4c 	b	9eb4 <fwp_main_thread+0x5d4>
    ad88:	72003c3f 	tst	w1, #0xffff
    ad8c:	54ff9421 	b.ne	a010 <fwp_main_thread+0x730>  // b.any
    ad90:	17fffc95 	b	9fe4 <fwp_main_thread+0x704>
    ad94:	72003c3f 	tst	w1, #0xffff
    ad98:	54ff8e21 	b.ne	9f5c <fwp_main_thread+0x67c>  // b.any
    ad9c:	17fffc6b 	b	9f48 <fwp_main_thread+0x668>
    ada0:	72003c3f 	tst	w1, #0xffff
    ada4:	54ff9861 	b.ne	a0b0 <fwp_main_thread+0x7d0>  // b.any
    ada8:	17fffcbc 	b	a098 <fwp_main_thread+0x7b8>
    adac:	aa0103e0 	mov	x0, x1
    adb0:	17fffb9d 	b	9c24 <fwp_main_thread+0x344>
    adb4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    adb8:	aa0403e0 	mov	x0, x4
    adbc:	52800034 	mov	w20, #0x1                   	// #1
    adc0:	f91f7c24 	str	x4, [x1, #16120]
    adc4:	97ffeac8 	bl	58e4 <fwp_rc_share>
    adc8:	aa1703e0 	mov	x0, x23
    adcc:	97ffeac6 	bl	58e4 <fwp_rc_share>
    add0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    add4:	f95f7c04 	ldr	x4, [x0, #16120]
    add8:	f91f7816 	str	x22, [x0, #16112]
    addc:	aa0403f7 	mov	x23, x4
    ade0:	17fffeda 	b	a948 <fwp_main_thread+0x1068>
    ade4:	aa1303e0 	mov	x0, x19
    ade8:	97ffe682 	bl	47f0 <fwp_rc_forget_slot>
    adec:	17fffc35 	b	9ec0 <fwp_main_thread+0x5e0>
    adf0:	97ffe639 	bl	46d4 <fwp_rc_wide_dup>
    adf4:	17fffcaf 	b	a0b0 <fwp_main_thread+0x7d0>
    adf8:	aa1303e0 	mov	x0, x19
    adfc:	97ffe67d 	bl	47f0 <fwp_rc_forget_slot>
    ae00:	17fffc55 	b	9f54 <fwp_main_thread+0x674>
    ae04:	aa1303e0 	mov	x0, x19
    ae08:	97ffe67a 	bl	47f0 <fwp_rc_forget_slot>
    ae0c:	17fffc79 	b	9ff0 <fwp_main_thread+0x710>
    ae10:	97ffde9c 	bl	2880 <__stack_chk_fail@plt>
    ae14:	97ffe087 	bl	3030 <fwp_heap_oom>
    ae18:	b0000000 	adrp	x0, b000 <__divti3+0x100>
    ae1c:	9131e000 	add	x0, x0, #0xc78
    ae20:	97ffe278 	bl	3800 <fwp_trap>
    ae24:	97ffe0c3 	bl	3130 <descent_phase_fail>
    ae28:	b0000000 	adrp	x0, b000 <__divti3+0x100>
    ae2c:	91328000 	add	x0, x0, #0xca0
    ae30:	97ffe274 	bl	3800 <fwp_trap>
    ae34:	aa1403e0 	mov	x0, x20
    ae38:	97ffeb1a 	bl	5aa0 <fwp_drop0>
    ae3c:	aa1703e0 	mov	x0, x23
    ae40:	97ffeb18 	bl	5aa0 <fwp_drop0>
    ae44:	d00000a0 	adrp	x0, 20000 <__data_start>
    ae48:	9101c000 	add	x0, x0, #0x70
    ae4c:	52800021 	mov	w1, #0x1                   	// #1
    ae50:	b9034c01 	str	w1, [x0, #844]
    ae54:	f901a81f 	str	xzr, [x0, #848]
    ae58:	17fffae9 	b	99fc <fwp_main_thread+0x11c>
    ae5c:	72003c3f 	tst	w1, #0xffff
    ae60:	54ffbd81 	b.ne	a610 <fwp_main_thread+0xd30>  // b.any
    ae64:	17fffde3 	b	a5f0 <fwp_main_thread+0xd10>
    ae68:	72003c3f 	tst	w1, #0xffff
    ae6c:	54ffb741 	b.ne	a554 <fwp_main_thread+0xc74>  // b.any
    ae70:	17fffdb4 	b	a540 <fwp_main_thread+0xc60>
    ae74:	ca5546a0 	eor	x0, x21, x21, lsr #17
    ae78:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    ae7c:	91174021 	add	x1, x1, #0x5d0
    ae80:	ca402400 	eor	x0, x0, x0, lsr #9
    ae84:	8b200c20 	add	x0, x1, w0, uxtb #3
    ae88:	f94a2400 	ldr	x0, [x0, #5192]
    ae8c:	b5000080 	cbnz	x0, ae9c <fwp_main_thread+0x15bc>
    ae90:	14000019 	b	aef4 <fwp_main_thread+0x1614>
    ae94:	f9400800 	ldr	x0, [x0, #16]
    ae98:	b40002e0 	cbz	x0, aef4 <fwp_main_thread+0x1614>
    ae9c:	f9400001 	ldr	x1, [x0]
    aea0:	eb0102bf 	cmp	x21, x1
    aea4:	54ffff81 	b.ne	ae94 <fwp_main_thread+0x15b4>  // b.any
    aea8:	f9400401 	ldr	x1, [x0, #8]
    aeac:	d1000421 	sub	x1, x1, #0x1
    aeb0:	f9000401 	str	x1, [x0, #8]
    aeb4:	f103f83f 	cmp	x1, #0xfe
    aeb8:	54ffbac1 	b.ne	a610 <fwp_main_thread+0xd30>  // b.any
    aebc:	aa1503e0 	mov	x0, x21
    aec0:	97ffe64c 	bl	47f0 <fwp_rc_forget_slot>
    aec4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    aec8:	390002a0 	strb	w0, [x21]
    aecc:	17fffdd1 	b	a610 <fwp_main_thread+0xd30>
    aed0:	aa1303e0 	mov	x0, x19
    aed4:	97ffeaab 	bl	5980 <fwp_rc_free_arr>
    aed8:	17fffdce 	b	a610 <fwp_main_thread+0xd30>
    aedc:	b9035a9f 	str	wzr, [x20, #856]
    aee0:	b4ffbb40 	cbz	x0, a648 <fwp_main_thread+0xd68>
    aee4:	97ffde7b 	bl	28d0 <abort@plt>
    aee8:	aa1903e0 	mov	x0, x25
    aeec:	97ffe641 	bl	47f0 <fwp_rc_forget_slot>
    aef0:	17fffd97 	b	a54c <fwp_main_thread+0xc6c>
    aef4:	b0000000 	adrp	x0, b000 <__divti3+0x100>
    aef8:	91260000 	add	x0, x0, #0x980
    aefc:	97ffe241 	bl	3800 <fwp_trap>

000000000000af00 <__divti3>:
    af00:	d503245f 	bti	c
    af04:	d2800004 	mov	x4, #0x0                   	// #0
    af08:	b7f80721 	tbnz	x1, #63, afec <__divti3+0xec>
    af0c:	b6f80083 	tbz	x3, #63, af1c <__divti3+0x1c>
    af10:	eb0203e2 	negs	x2, x2
    af14:	aa2403e4 	mvn	x4, x4
    af18:	da0303e3 	ngc	x3, x3
    af1c:	aa0203e6 	mov	x6, x2
    af20:	aa0003e7 	mov	x7, x0
    af24:	aa0103e5 	mov	x5, x1
    af28:	b5000583 	cbnz	x3, afd8 <__divti3+0xd8>
    af2c:	eb01005f 	cmp	x2, x1
    af30:	54000e69 	b.ls	b0fc <__divti3+0x1fc>  // b.plast
    af34:	dac01040 	clz	x0, x2
    af38:	b40000e0 	cbz	x0, af54 <__divti3+0x54>
    af3c:	4b0003e1 	neg	w1, w0
    af40:	9ac020a5 	lsl	x5, x5, x0
    af44:	9ac02046 	lsl	x6, x2, x0
    af48:	9ac124e1 	lsr	x1, x7, x1
    af4c:	aa050025 	orr	x5, x1, x5
    af50:	9ac020e7 	lsl	x7, x7, x0
    af54:	d360fcc8 	lsr	x8, x6, #32
    af58:	92407cc2 	and	x2, x6, #0xffffffff
    af5c:	9ac808a3 	udiv	x3, x5, x8
    af60:	9b089465 	msub	x5, x3, x8, x5
    af64:	aa0303e0 	mov	x0, x3
    af68:	9b037c41 	mul	x1, x2, x3
    af6c:	93c780a5 	extr	x5, x5, x7, #32
    af70:	eb05003f 	cmp	x1, x5
    af74:	540000a9 	b.ls	af88 <__divti3+0x88>  // b.plast
    af78:	ab0500c5 	adds	x5, x6, x5
    af7c:	d1000460 	sub	x0, x3, #0x1
    af80:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    af84:	540015a8 	b.hi	b238 <__divti3+0x338>  // b.pmore
    af88:	cb0100a5 	sub	x5, x5, x1
    af8c:	9ac808a3 	udiv	x3, x5, x8
    af90:	9b089465 	msub	x5, x3, x8, x5
    af94:	aa0303e1 	mov	x1, x3
    af98:	9b037c42 	mul	x2, x2, x3
    af9c:	aa0703e3 	mov	x3, x7
    afa0:	b3607ca3 	bfi	x3, x5, #32, #32
    afa4:	eb03005f 	cmp	x2, x3
    afa8:	540000c9 	b.ls	afc0 <__divti3+0xc0>  // b.plast
    afac:	ab0300c3 	adds	x3, x6, x3
    afb0:	d1000425 	sub	x5, x1, #0x1
    afb4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    afb8:	d1000821 	sub	x1, x1, #0x2
    afbc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    afc0:	aa008020 	orr	x0, x1, x0, lsl #32
    afc4:	d2800001 	mov	x1, #0x0                   	// #0
    afc8:	b4000064 	cbz	x4, afd4 <__divti3+0xd4>
    afcc:	eb0003e0 	negs	x0, x0
    afd0:	da0103e1 	ngc	x1, x1
    afd4:	d65f03c0 	ret
    afd8:	eb01007f 	cmp	x3, x1
    afdc:	54000109 	b.ls	affc <__divti3+0xfc>  // b.plast
    afe0:	d2800001 	mov	x1, #0x0                   	// #0
    afe4:	d2800000 	mov	x0, #0x0                   	// #0
    afe8:	17fffff8 	b	afc8 <__divti3+0xc8>
    afec:	eb0003e0 	negs	x0, x0
    aff0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    aff4:	da0103e1 	ngc	x1, x1
    aff8:	17ffffc5 	b	af0c <__divti3+0xc>
    affc:	dac01067 	clz	x7, x3
    b000:	b40010e7 	cbz	x7, b21c <__divti3+0x31c>
    b004:	d2800805 	mov	x5, #0x40                  	// #64
    b008:	cb0700a5 	sub	x5, x5, x7
    b00c:	9ac72063 	lsl	x3, x3, x7
    b010:	9ac52448 	lsr	x8, x2, x5
    b014:	aa030108 	orr	x8, x8, x3
    b018:	9ac52426 	lsr	x6, x1, x5
    b01c:	92407d0a 	and	x10, x8, #0xffffffff
    b020:	d360fd09 	lsr	x9, x8, #32
    b024:	9ac52403 	lsr	x3, x0, x5
    b028:	9ac72021 	lsl	x1, x1, x7
    b02c:	aa010063 	orr	x3, x3, x1
    b030:	9ac72042 	lsl	x2, x2, x7
    b034:	9ac908cb 	udiv	x11, x6, x9
    b038:	9b099965 	msub	x5, x11, x9, x6
    b03c:	aa0b03e1 	mov	x1, x11
    b040:	9b0b7d46 	mul	x6, x10, x11
    b044:	93c380a5 	extr	x5, x5, x3, #32
    b048:	eb0500df 	cmp	x6, x5
    b04c:	540000a9 	b.ls	b060 <__divti3+0x160>  // b.plast
    b050:	ab050105 	adds	x5, x8, x5
    b054:	d1000561 	sub	x1, x11, #0x1
    b058:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    b05c:	54000f48 	b.hi	b244 <__divti3+0x344>  // b.pmore
    b060:	cb0600a6 	sub	x6, x5, x6
    b064:	9ac908cb 	udiv	x11, x6, x9
    b068:	9b099969 	msub	x9, x11, x9, x6
    b06c:	aa0b03e5 	mov	x5, x11
    b070:	9b0b7d4a 	mul	x10, x10, x11
    b074:	b3607d23 	bfi	x3, x9, #32, #32
    b078:	eb03015f 	cmp	x10, x3
    b07c:	540000a9 	b.ls	b090 <__divti3+0x190>  // b.plast
    b080:	ab030103 	adds	x3, x8, x3
    b084:	d1000565 	sub	x5, x11, #0x1
    b088:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b08c:	54000e28 	b.hi	b250 <__divti3+0x350>  // b.pmore
    b090:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b094:	92407c48 	and	x8, x2, #0xffffffff
    b098:	2a0503e5 	mov	w5, w5
    b09c:	d360fc42 	lsr	x2, x2, #32
    b0a0:	d360fc26 	lsr	x6, x1, #32
    b0a4:	cb0a0063 	sub	x3, x3, x10
    b0a8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b0ac:	9b087caa 	mul	x10, x5, x8
    b0b0:	9b087cc8 	mul	x8, x6, x8
    b0b4:	9b0220a5 	madd	x5, x5, x2, x8
    b0b8:	9b027cc6 	mul	x6, x6, x2
    b0bc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b0c0:	8b0900c5 	add	x5, x6, x9
    b0c4:	eb02011f 	cmp	x8, x2
    b0c8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b0cc:	8b4280c6 	add	x6, x6, x2, lsr #32
    b0d0:	eb06007f 	cmp	x3, x6
    b0d4:	540000e3 	b.cc	b0f0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b0d8:	92407d4a 	and	x10, x10, #0xffffffff
    b0dc:	9ac72000 	lsl	x0, x0, x7
    b0e0:	8b028142 	add	x2, x10, x2, lsl #32
    b0e4:	eb02001f 	cmp	x0, x2
    b0e8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b0ec:	54000a01 	b.ne	b22c <__divti3+0x32c>  // b.any
    b0f0:	d1000420 	sub	x0, x1, #0x1
    b0f4:	d2800001 	mov	x1, #0x0                   	// #0
    b0f8:	17ffffb4 	b	afc8 <__divti3+0xc8>
    b0fc:	b5000062 	cbnz	x2, b108 <__divti3+0x208>
    b100:	d2800022 	mov	x2, #0x1                   	// #1
    b104:	9ac30846 	udiv	x6, x2, x3
    b108:	dac010c8 	clz	x8, x6
    b10c:	b5000408 	cbnz	x8, b18c <__divti3+0x28c>
    b110:	d360fcc9 	lsr	x9, x6, #32
    b114:	92407cc5 	and	x5, x6, #0xffffffff
    b118:	cb060023 	sub	x3, x1, x6
    b11c:	d2800021 	mov	x1, #0x1                   	// #1
    b120:	9ac90868 	udiv	x8, x3, x9
    b124:	9b098d03 	msub	x3, x8, x9, x3
    b128:	aa0803e0 	mov	x0, x8
    b12c:	9b057d02 	mul	x2, x8, x5
    b130:	93c78063 	extr	x3, x3, x7, #32
    b134:	eb03005f 	cmp	x2, x3
    b138:	540000a9 	b.ls	b14c <__divti3+0x24c>  // b.plast
    b13c:	ab0300c3 	adds	x3, x6, x3
    b140:	d1000500 	sub	x0, x8, #0x1
    b144:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b148:	54000968 	b.hi	b274 <__divti3+0x374>  // b.pmore
    b14c:	cb020063 	sub	x3, x3, x2
    b150:	9ac90862 	udiv	x2, x3, x9
    b154:	aa0203e8 	mov	x8, x2
    b158:	9b098c42 	msub	x2, x2, x9, x3
    b15c:	aa0703e3 	mov	x3, x7
    b160:	9b057d05 	mul	x5, x8, x5
    b164:	b3607c43 	bfi	x3, x2, #32, #32
    b168:	eb0300bf 	cmp	x5, x3
    b16c:	540000c9 	b.ls	b184 <__divti3+0x284>  // b.plast
    b170:	ab0300c2 	adds	x2, x6, x3
    b174:	d1000503 	sub	x3, x8, #0x1
    b178:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b17c:	d1000908 	sub	x8, x8, #0x2
    b180:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b184:	aa008100 	orr	x0, x8, x0, lsl #32
    b188:	17ffff90 	b	afc8 <__divti3+0xc8>
    b18c:	9ac820c6 	lsl	x6, x6, x8
    b190:	d2800803 	mov	x3, #0x40                  	// #64
    b194:	cb080063 	sub	x3, x3, x8
    b198:	d360fcc9 	lsr	x9, x6, #32
    b19c:	9ac82027 	lsl	x7, x1, x8
    b1a0:	92407cc5 	and	x5, x6, #0xffffffff
    b1a4:	9ac32422 	lsr	x2, x1, x3
    b1a8:	9ac32403 	lsr	x3, x0, x3
    b1ac:	aa070063 	orr	x3, x3, x7
    b1b0:	9ac9084a 	udiv	x10, x2, x9
    b1b4:	9ac82007 	lsl	x7, x0, x8
    b1b8:	9b098940 	msub	x0, x10, x9, x2
    b1bc:	aa0a03e1 	mov	x1, x10
    b1c0:	9b0a7ca2 	mul	x2, x5, x10
    b1c4:	93c38000 	extr	x0, x0, x3, #32
    b1c8:	eb00005f 	cmp	x2, x0
    b1cc:	540000a9 	b.ls	b1e0 <__divti3+0x2e0>  // b.plast
    b1d0:	ab0000c0 	adds	x0, x6, x0
    b1d4:	d1000541 	sub	x1, x10, #0x1
    b1d8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b1dc:	54000468 	b.hi	b268 <__divti3+0x368>  // b.pmore
    b1e0:	cb020000 	sub	x0, x0, x2
    b1e4:	9ac9080a 	udiv	x10, x0, x9
    b1e8:	9b098140 	msub	x0, x10, x9, x0
    b1ec:	aa0a03e2 	mov	x2, x10
    b1f0:	9b0a7ca8 	mul	x8, x5, x10
    b1f4:	b3607c03 	bfi	x3, x0, #32, #32
    b1f8:	eb03011f 	cmp	x8, x3
    b1fc:	540000a9 	b.ls	b210 <__divti3+0x310>  // b.plast
    b200:	ab0300c3 	adds	x3, x6, x3
    b204:	d1000542 	sub	x2, x10, #0x1
    b208:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b20c:	54000288 	b.hi	b25c <__divti3+0x35c>  // b.pmore
    b210:	cb080063 	sub	x3, x3, x8
    b214:	aa018041 	orr	x1, x2, x1, lsl #32
    b218:	17ffffc2 	b	b120 <__divti3+0x220>
    b21c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b220:	d2800001 	mov	x1, #0x0                   	// #0
    b224:	9a9f87e0 	cset	x0, ls	// ls = plast
    b228:	17ffff68 	b	afc8 <__divti3+0xc8>
    b22c:	aa0103e0 	mov	x0, x1
    b230:	d2800001 	mov	x1, #0x0                   	// #0
    b234:	17ffff65 	b	afc8 <__divti3+0xc8>
    b238:	d1000860 	sub	x0, x3, #0x2
    b23c:	8b0600a5 	add	x5, x5, x6
    b240:	17ffff52 	b	af88 <__divti3+0x88>
    b244:	d1000961 	sub	x1, x11, #0x2
    b248:	8b0800a5 	add	x5, x5, x8
    b24c:	17ffff85 	b	b060 <__divti3+0x160>
    b250:	d1000965 	sub	x5, x11, #0x2
    b254:	8b080063 	add	x3, x3, x8
    b258:	17ffff8e 	b	b090 <__divti3+0x190>
    b25c:	d1000942 	sub	x2, x10, #0x2
    b260:	8b060063 	add	x3, x3, x6
    b264:	17ffffeb 	b	b210 <__divti3+0x310>
    b268:	d1000941 	sub	x1, x10, #0x2
    b26c:	8b060000 	add	x0, x0, x6
    b270:	17ffffdc 	b	b1e0 <__divti3+0x2e0>
    b274:	d1000900 	sub	x0, x8, #0x2
    b278:	8b060063 	add	x3, x3, x6
    b27c:	17ffffb4 	b	b14c <__divti3+0x24c>

000000000000b280 <__modti3>:
    b280:	d503245f 	bti	c
    b284:	d2800004 	mov	x4, #0x0                   	// #0
    b288:	b6f80081 	tbz	x1, #63, b298 <__modti3+0x18>
    b28c:	eb0003e0 	negs	x0, x0
    b290:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b294:	da0103e1 	ngc	x1, x1
    b298:	f100007f 	cmp	x3, #0x0
    b29c:	5400128b 	b.lt	b4ec <__modti3+0x26c>  // b.tstop
    b2a0:	aa0003e7 	mov	x7, x0
    b2a4:	aa0103e6 	mov	x6, x1
    b2a8:	540004e1 	b.ne	b344 <__modti3+0xc4>  // b.any
    b2ac:	eb02003f 	cmp	x1, x2
    b2b0:	54000dc2 	b.cs	b468 <__modti3+0x1e8>  // b.hs, b.nlast
    b2b4:	dac01043 	clz	x3, x2
    b2b8:	aa0303e5 	mov	x5, x3
    b2bc:	b40000e3 	cbz	x3, b2d8 <__modti3+0x58>
    b2c0:	4b0303e6 	neg	w6, w3
    b2c4:	9ac32021 	lsl	x1, x1, x3
    b2c8:	9ac32042 	lsl	x2, x2, x3
    b2cc:	9ac62406 	lsr	x6, x0, x6
    b2d0:	aa0100c6 	orr	x6, x6, x1
    b2d4:	9ac32007 	lsl	x7, x0, x3
    b2d8:	d360fc40 	lsr	x0, x2, #32
    b2dc:	92407c43 	and	x3, x2, #0xffffffff
    b2e0:	9ac008c1 	udiv	x1, x6, x0
    b2e4:	9b009826 	msub	x6, x1, x0, x6
    b2e8:	9b017c61 	mul	x1, x3, x1
    b2ec:	93c780c6 	extr	x6, x6, x7, #32
    b2f0:	eb06003f 	cmp	x1, x6
    b2f4:	540000a9 	b.ls	b308 <__modti3+0x88>  // b.plast
    b2f8:	ab060046 	adds	x6, x2, x6
    b2fc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b300:	8b0200c8 	add	x8, x6, x2
    b304:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b308:	cb0100c6 	sub	x6, x6, x1
    b30c:	9ac008c8 	udiv	x8, x6, x0
    b310:	9b009901 	msub	x1, x8, x0, x6
    b314:	aa0703e0 	mov	x0, x7
    b318:	9b087c63 	mul	x3, x3, x8
    b31c:	b3607c20 	bfi	x0, x1, #32, #32
    b320:	eb00007f 	cmp	x3, x0
    b324:	54001088 	b.hi	b534 <__modti3+0x2b4>  // b.pmore
    b328:	cb030000 	sub	x0, x0, x3
    b32c:	9ac52400 	lsr	x0, x0, x5
    b330:	d2800001 	mov	x1, #0x0                   	// #0
    b334:	b4000064 	cbz	x4, b340 <__modti3+0xc0>
    b338:	eb0003e0 	negs	x0, x0
    b33c:	da0103e1 	ngc	x1, x1
    b340:	d65f03c0 	ret
    b344:	dac01066 	clz	x6, x3
    b348:	eb03003f 	cmp	x1, x3
    b34c:	54ffff43 	b.cc	b334 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b350:	93407cc5 	sxtw	x5, w6
    b354:	d2800808 	mov	x8, #0x40                  	// #64
    b358:	cb050108 	sub	x8, x8, x5
    b35c:	9ac62063 	lsl	x3, x3, x6
    b360:	9ac62025 	lsl	x5, x1, x6
    b364:	9ac82447 	lsr	x7, x2, x8
    b368:	aa0300e7 	orr	x7, x7, x3
    b36c:	9ac82423 	lsr	x3, x1, x8
    b370:	92407cec 	and	x12, x7, #0xffffffff
    b374:	d360fcea 	lsr	x10, x7, #32
    b378:	9ac82401 	lsr	x1, x0, x8
    b37c:	aa050021 	orr	x1, x1, x5
    b380:	9ac62042 	lsl	x2, x2, x6
    b384:	9ac62000 	lsl	x0, x0, x6
    b388:	9aca086b 	udiv	x11, x3, x10
    b38c:	9b0a8d63 	msub	x3, x11, x10, x3
    b390:	aa0b03e5 	mov	x5, x11
    b394:	9b0b7d89 	mul	x9, x12, x11
    b398:	93c18063 	extr	x3, x3, x1, #32
    b39c:	eb03013f 	cmp	x9, x3
    b3a0:	540000a9 	b.ls	b3b4 <__modti3+0x134>  // b.plast
    b3a4:	ab0300e3 	adds	x3, x7, x3
    b3a8:	d1000565 	sub	x5, x11, #0x1
    b3ac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b3b0:	54001168 	b.hi	b5dc <__modti3+0x35c>  // b.pmore
    b3b4:	cb090063 	sub	x3, x3, x9
    b3b8:	9aca086b 	udiv	x11, x3, x10
    b3bc:	9b0a8d6a 	msub	x10, x11, x10, x3
    b3c0:	aa0b03e9 	mov	x9, x11
    b3c4:	9b0b7d8c 	mul	x12, x12, x11
    b3c8:	b3607d41 	bfi	x1, x10, #32, #32
    b3cc:	eb01019f 	cmp	x12, x1
    b3d0:	540000a9 	b.ls	b3e4 <__modti3+0x164>  // b.plast
    b3d4:	ab0100e1 	adds	x1, x7, x1
    b3d8:	d1000569 	sub	x9, x11, #0x1
    b3dc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b3e0:	54000f88 	b.hi	b5d0 <__modti3+0x350>  // b.pmore
    b3e4:	aa058123 	orr	x3, x9, x5, lsl #32
    b3e8:	92407c4b 	and	x11, x2, #0xffffffff
    b3ec:	2a0903e9 	mov	w9, w9
    b3f0:	d360fc4a 	lsr	x10, x2, #32
    b3f4:	d360fc63 	lsr	x3, x3, #32
    b3f8:	cb0c0021 	sub	x1, x1, x12
    b3fc:	aa0a03ec 	mov	x12, x10
    b400:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b404:	9b0b7d25 	mul	x5, x9, x11
    b408:	9b0b7c6b 	mul	x11, x3, x11
    b40c:	9b0a2d29 	madd	x9, x9, x10, x11
    b410:	92407caa 	and	x10, x5, #0xffffffff
    b414:	9b0c7c63 	mul	x3, x3, x12
    b418:	8b458125 	add	x5, x9, x5, lsr #32
    b41c:	8b0d0069 	add	x9, x3, x13
    b420:	eb05017f 	cmp	x11, x5
    b424:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b428:	8b058149 	add	x9, x10, x5, lsl #32
    b42c:	8b458063 	add	x3, x3, x5, lsr #32
    b430:	eb03003f 	cmp	x1, x3
    b434:	54000063 	b.cc	b440 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b438:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b43c:	54000082 	b.cs	b44c <__modti3+0x1cc>  // b.hs, b.nlast
    b440:	eb020129 	subs	x9, x9, x2
    b444:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b448:	cb070063 	sub	x3, x3, x7
    b44c:	eb090000 	subs	x0, x0, x9
    b450:	da030021 	sbc	x1, x1, x3
    b454:	9ac62400 	lsr	x0, x0, x6
    b458:	9ac82028 	lsl	x8, x1, x8
    b45c:	aa000100 	orr	x0, x8, x0
    b460:	9ac62421 	lsr	x1, x1, x6
    b464:	17ffffb4 	b	b334 <__modti3+0xb4>
    b468:	b5000062 	cbnz	x2, b474 <__modti3+0x1f4>
    b46c:	d2800023 	mov	x3, #0x1                   	// #1
    b470:	9ac20862 	udiv	x2, x3, x2
    b474:	dac01048 	clz	x8, x2
    b478:	aa0803e5 	mov	x5, x8
    b47c:	b5000668 	cbnz	x8, b548 <__modti3+0x2c8>
    b480:	cb020020 	sub	x0, x1, x2
    b484:	d360fc49 	lsr	x9, x2, #32
    b488:	92407c4a 	and	x10, x2, #0xffffffff
    b48c:	9ac90801 	udiv	x1, x0, x9
    b490:	9b098020 	msub	x0, x1, x9, x0
    b494:	9b0a7c21 	mul	x1, x1, x10
    b498:	93c78000 	extr	x0, x0, x7, #32
    b49c:	eb00003f 	cmp	x1, x0
    b4a0:	540000a9 	b.ls	b4b4 <__modti3+0x234>  // b.plast
    b4a4:	ab000040 	adds	x0, x2, x0
    b4a8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b4ac:	8b020003 	add	x3, x0, x2
    b4b0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b4b4:	cb010001 	sub	x1, x0, x1
    b4b8:	9ac90820 	udiv	x0, x1, x9
    b4bc:	9b098403 	msub	x3, x0, x9, x1
    b4c0:	aa0703e1 	mov	x1, x7
    b4c4:	9b0a7c00 	mul	x0, x0, x10
    b4c8:	b3607c61 	bfi	x1, x3, #32, #32
    b4cc:	eb01001f 	cmp	x0, x1
    b4d0:	540000a9 	b.ls	b4e4 <__modti3+0x264>  // b.plast
    b4d4:	ab010041 	adds	x1, x2, x1
    b4d8:	8b020022 	add	x2, x1, x2
    b4dc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b4e0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b4e4:	cb000020 	sub	x0, x1, x0
    b4e8:	17ffff91 	b	b32c <__modti3+0xac>
    b4ec:	eb0203e5 	negs	x5, x2
    b4f0:	aa0003e7 	mov	x7, x0
    b4f4:	da0303e8 	ngc	x8, x3
    b4f8:	aa0503e2 	mov	x2, x5
    b4fc:	aa0803e3 	mov	x3, x8
    b500:	aa0103e6 	mov	x6, x1
    b504:	b4ffed48 	cbz	x8, b2ac <__modti3+0x2c>
    b508:	eb01011f 	cmp	x8, x1
    b50c:	54fff148 	b.hi	b334 <__modti3+0xb4>  // b.pmore
    b510:	dac01109 	clz	x9, x8
    b514:	2a0903e6 	mov	w6, w9
    b518:	b5fff1c9 	cbnz	x9, b350 <__modti3+0xd0>
    b51c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b520:	54000068 	b.hi	b52c <__modti3+0x2ac>  // b.pmore
    b524:	eb050007 	subs	x7, x0, x5
    b528:	da080021 	sbc	x1, x1, x8
    b52c:	aa0703e0 	mov	x0, x7
    b530:	17ffff81 	b	b334 <__modti3+0xb4>
    b534:	ab000040 	adds	x0, x2, x0
    b538:	8b020002 	add	x2, x0, x2
    b53c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b540:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b544:	17ffff79 	b	b328 <__modti3+0xa8>
    b548:	9ac82042 	lsl	x2, x2, x8
    b54c:	d2800803 	mov	x3, #0x40                  	// #64
    b550:	cb080063 	sub	x3, x3, x8
    b554:	d360fc49 	lsr	x9, x2, #32
    b558:	9ac82027 	lsl	x7, x1, x8
    b55c:	92407c4a 	and	x10, x2, #0xffffffff
    b560:	9ac32426 	lsr	x6, x1, x3
    b564:	9ac32403 	lsr	x3, x0, x3
    b568:	aa070063 	orr	x3, x3, x7
    b56c:	9ac908c1 	udiv	x1, x6, x9
    b570:	9ac82007 	lsl	x7, x0, x8
    b574:	9b099820 	msub	x0, x1, x9, x6
    b578:	9b017d41 	mul	x1, x10, x1
    b57c:	93c38000 	extr	x0, x0, x3, #32
    b580:	eb00003f 	cmp	x1, x0
    b584:	540000a9 	b.ls	b598 <__modti3+0x318>  // b.plast
    b588:	ab000040 	adds	x0, x2, x0
    b58c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b590:	8b020006 	add	x6, x0, x2
    b594:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b598:	cb010000 	sub	x0, x0, x1
    b59c:	9ac90801 	udiv	x1, x0, x9
    b5a0:	9b098026 	msub	x6, x1, x9, x0
    b5a4:	aa0303e0 	mov	x0, x3
    b5a8:	9b017d41 	mul	x1, x10, x1
    b5ac:	b3607cc0 	bfi	x0, x6, #32, #32
    b5b0:	eb00003f 	cmp	x1, x0
    b5b4:	540000a9 	b.ls	b5c8 <__modti3+0x348>  // b.plast
    b5b8:	ab000040 	adds	x0, x2, x0
    b5bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b5c0:	8b020003 	add	x3, x0, x2
    b5c4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b5c8:	cb010000 	sub	x0, x0, x1
    b5cc:	17ffffb0 	b	b48c <__modti3+0x20c>
    b5d0:	d1000969 	sub	x9, x11, #0x2
    b5d4:	8b070021 	add	x1, x1, x7
    b5d8:	17ffff83 	b	b3e4 <__modti3+0x164>
    b5dc:	d1000965 	sub	x5, x11, #0x2
    b5e0:	8b070063 	add	x3, x3, x7
    b5e4:	17ffff74 	b	b3b4 <__modti3+0x134>
    b5e8:	d503201f 	nop
    b5ec:	d503201f 	nop

000000000000b5f0 <atexit>:
    b5f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b5f4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b5f8:	d2800001 	mov	x1, #0x0                   	// #0
    b5fc:	910003fd 	mov	x29, sp
    b600:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b604:	f9400442 	ldr	x2, [x2, #8]
    b608:	17ffdc5e 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b60c <_fini>:
    b60c:	d503201f 	nop
    b610:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b614:	910003fd 	mov	x29, sp
    b618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b61c:	d65f03c0 	ret
