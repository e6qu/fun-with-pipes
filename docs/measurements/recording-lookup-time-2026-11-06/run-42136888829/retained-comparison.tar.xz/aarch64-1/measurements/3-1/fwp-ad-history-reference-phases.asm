
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <__divti3+0x180>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912160a5 	add	x5, x5, #0x858
    2aa0:	b0000044 	adrp	x4, b000 <__divti3+0x180>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91218084 	add	x4, x4, #0x860
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9101c261 	add	x1, x19, #0x70
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10850>
    2b20:	91132000 	add	x0, x0, #0x4c8
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9004420 	str	x0, [x1, #136]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <__divti3+0x180>
    2b34:	9130e000 	add	x0, x0, #0xc38
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	f0000022 	adrp	x2, 9000 <fwp_write+0x840>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911ec042 	add	x2, x2, #0x7b0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c273 	add	x19, x19, #0x70
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9435a60 	ldr	w0, [x19, #856]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	b0000040 	adrp	x0, b000 <__divti3+0x180>
    2c7c:	91312000 	add	x0, x0, #0xc48
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	b0000040 	adrp	x0, b000 <__divti3+0x180>
    2c8c:	9133a000 	add	x0, x0, #0xce8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	b0000040 	adrp	x0, b000 <__divti3+0x180>
    2ca4:	91330000 	add	x0, x0, #0xcc0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	b0000040 	adrp	x0, b000 <__divti3+0x180>
    2cb0:	91324000 	add	x0, x0, #0xc90
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	b0000040 	adrp	x0, b000 <__divti3+0x180>
    2cbc:	9131a000 	add	x0, x0, #0xc68
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91018000 	add	x0, x0, #0x60
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91018021 	add	x1, x1, #0x60
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91018000 	add	x0, x0, #0x60
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91018021 	add	x1, x1, #0x60
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0xa60>
    2eb4:	910d4021 	add	x1, x1, #0x350
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args161>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3050:	9116a000 	add	x0, x0, #0x5a8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa60>
    3118:	910cc021 	add	x1, x1, #0x330
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3150:	91170000 	add	x0, x0, #0x5c0
    3154:	97fffe0b 	bl	2980 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe25 	bl	29f0 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xb38>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	90000042 	adrp	x2, b000 <__divti3+0x180>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	90000056 	adrp	x22, b000 <__divti3+0x180>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	b0000058 	adrp	x24, c000 <_IO_stdin_used+0xa60>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	91182042 	add	x2, x2, #0x608
    31e0:	911982d6 	add	x22, x22, #0x660
    31e4:	9102e318 	add	x24, x24, #0xb8
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	90000059 	adrp	x25, b000 <__divti3+0x180>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdbd 	bl	28f0 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	91196323 	add	x3, x25, #0x658
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb0 	bl	28f0 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	9119c000 	add	x0, x0, #0x670
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdbf 	b	2980 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd94 	bl	28f0 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd75 	bl	2880 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    32c4:	911742a1 	add	x1, x21, #0x5d0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    32d8:	912700a5 	add	x5, x5, #0x9c0
    32dc:	911742a1 	add	x1, x21, #0x5d0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911742b7 	add	x23, x21, #0x5d0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd8d 	bl	29d0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911742b5 	add	x21, x21, #0x5d0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911742b5 	add	x21, x21, #0x5d0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3468:	9126e0a5 	add	x5, x5, #0x9b8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2b 	bl	2940 <free@plt>
    3498:	f9400a60 	ldr	x0, [x19, #16]
    349c:	97fffd29 	bl	2940 <free@plt>
    34a0:	f9401260 	ldr	x0, [x19, #32]
    34a4:	97fffd27 	bl	2940 <free@plt>
    34a8:	f9001a7f 	str	xzr, [x19, #48]
    34ac:	4f000400 	movi	v0.4s, #0x0
    34b0:	ad000260 	stp	q0, q0, [x19]
    34b4:	3d800a60 	str	q0, [x19, #32]
    34b8:	f9400bf3 	ldr	x19, [sp, #16]
    34bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34c0:	d65f03c0 	ret

00000000000034c4 <buf_grow>:
    34c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c8:	910003fd 	mov	x29, sp
    34cc:	a90153f3 	stp	x19, x20, [sp, #16]
    34d0:	aa0003f4 	mov	x20, x0
    34d4:	f9400400 	ldr	x0, [x0, #8]
    34d8:	b100041f 	cmn	x0, #0x1
    34dc:	54000400 	b.eq	355c <buf_grow+0x98>  // b.none
    34e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e4:	cb000042 	sub	x2, x2, x0
    34e8:	eb01005f 	cmp	x2, x1
    34ec:	54000383 	b.cc	355c <buf_grow+0x98>  // b.lo, b.ul, b.last
    34f0:	f9400a82 	ldr	x2, [x20, #16]
    34f4:	91000421 	add	x1, x1, #0x1
    34f8:	8b000033 	add	x19, x1, x0
    34fc:	eb13005f 	cmp	x2, x19
    3500:	54000242 	b.cs	3548 <buf_grow+0x84>  // b.hs, b.nlast
    3504:	f100005f 	cmp	x2, #0x0
    3508:	b5000262 	cbnz	x2, 3554 <buf_grow+0x90>
    350c:	d2800802 	mov	x2, #0x40                  	// #64
    3510:	eb02027f 	cmp	x19, x2
    3514:	54000068 	b.hi	3520 <buf_grow+0x5c>  // b.pmore
    3518:	14000005 	b	352c <buf_grow+0x68>
    351c:	b7f800a2 	tbnz	x2, #63, 3530 <buf_grow+0x6c>
    3520:	d37ff842 	lsl	x2, x2, #1
    3524:	eb02027f 	cmp	x19, x2
    3528:	54ffffa8 	b.hi	351c <buf_grow+0x58>  // b.pmore
    352c:	aa0203f3 	mov	x19, x2
    3530:	f9400280 	ldr	x0, [x20]
    3534:	aa1303e1 	mov	x1, x19
    3538:	97fffcce 	bl	2870 <realloc@plt>
    353c:	b4000100 	cbz	x0, 355c <buf_grow+0x98>
    3540:	f9000280 	str	x0, [x20]
    3544:	f9000a93 	str	x19, [x20, #16]
    3548:	a94153f3 	ldp	x19, x20, [sp, #16]
    354c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3550:	d65f03c0 	ret
    3554:	54fffe6a 	b.ge	3520 <buf_grow+0x5c>  // b.tcont
    3558:	17fffff6 	b	3530 <buf_grow+0x6c>
    355c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3560:	f947e863 	ldr	x3, [x3, #4048]
    3564:	d2800262 	mov	x2, #0x13                  	// #19
    3568:	d2800021 	mov	x1, #0x1                   	// #1
    356c:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3570:	9116a000 	add	x0, x0, #0x5a8
    3574:	f9400063 	ldr	x3, [x3]
    3578:	97fffd02 	bl	2980 <fwrite@plt>
    357c:	d2800000 	mov	x0, #0x0                   	// #0
    3580:	97fffd0c 	bl	29b0 <fflush@plt>
    3584:	52800cc0 	mov	w0, #0x66                  	// #102
    3588:	97fffd1a 	bl	29f0 <_Exit@plt>
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc5 	bl	34c4 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc43 	bl	26d0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc5e 	bl	27b0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc67 	bl	2880 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc76 	bl	2960 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc6f 	bl	2960 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <__divti3+0x180>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9119e021 	add	x1, x1, #0x678
    37b8:	97fffc8a 	bl	29e0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <__divti3+0x180>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	911a0021 	add	x1, x1, #0x680
    37cc:	97fffc85 	bl	29e0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbce 	bl	2710 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <__divti3+0x180>
    37e0:	911a2021 	add	x1, x1, #0x688
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffdf1 	bl	2ff0 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	90000042 	adrp	x2, b000 <__divti3+0x180>
    3838:	aa1303e3 	mov	x3, x19
    383c:	911a4042 	add	x2, x2, #0x690
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc2b 	bl	28f0 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc58 	bl	29b0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc66 	bl	29f0 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbb4 	bl	2730 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbd4 	bl	2820 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbb7 	bl	27d0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc0f 	bl	2940 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3950:	9116a000 	add	x0, x0, #0x5a8
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc0a 	bl	2980 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc14 	bl	29b0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc22 	bl	29f0 <_Exit@plt>
    396c:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3970:	911a8000 	add	x0, x0, #0x6a0
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb82 	bl	27b0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3a08:	911b0000 	add	x0, x0, #0x6c0
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffb9c 	bl	2880 <__stack_chk_fail@plt>
    3a14:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3a18:	911b8000 	add	x0, x0, #0x6e0
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xa60>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc0d820 	ldr	q0, [x1, #864]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	9101c2b5 	add	x21, x21, #0x70
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f94046a2 	ldr	x2, [x21, #136]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb97 	bl	2940 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3b18:	911c2000 	add	x0, x0, #0x708
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb57 	bl	2880 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	9350fc01 	asr	x1, x0, #16
    3b3c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b40:	d1000440 	sub	x0, x2, #0x1
    3b44:	9101c062 	add	x2, x3, #0x70
    3b48:	f9404842 	ldr	x2, [x2, #144]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9403863 	ldr	x3, [x3, #112]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3b88:	911ce000 	add	x0, x0, #0x738
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	90000044 	adrp	x4, b000 <__divti3+0x180>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	911e2084 	add	x4, x4, #0x788
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffafe 	bl	27f0 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb57 	bl	2960 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb42 	bl	2920 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa8b 	bl	26d0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffac3 	bl	27d0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffab4 	bl	27d0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa6c 	bl	26d0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa78 	bl	2710 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb08 	bl	2960 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	90000044 	adrp	x4, b000 <__divti3+0x180>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	911e8084 	add	x4, x4, #0x7a0
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa88 	bl	27f0 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa77 	bl	27d0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffad7 	bl	2960 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	90000044 	adrp	x4, b000 <__divti3+0x180>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	911e4084 	add	x4, x4, #0x790
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa60 	bl	27f0 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa4a 	bl	27d0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa1e 	bl	27d0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa3a 	bl	2880 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3fa8:	91174042 	add	x2, x2, #0x5d0
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	90000041 	adrp	x1, b000 <__divti3+0x180>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	90000040 	adrp	x0, b000 <__divti3+0x180>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	911ea021 	add	x1, x1, #0x7a8
    4004:	911ec000 	add	x0, x0, #0x7b0
    4008:	97fffa02 	bl	2810 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa83 	bl	2a40 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa2d 	bl	2920 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa70 	bl	2a40 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9dd 	bl	2800 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	f0000022 	adrp	x2, b000 <__divti3+0x180>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911f4042 	add	x2, x2, #0x7d0
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa00 	b	28f0 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e0 	bl	2880 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    410c:	91134061 	add	x1, x3, #0x4d0
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    411c:	91174262 	add	x2, x19, #0x5d0
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	90000042 	adrp	x2, c000 <_IO_stdin_used+0xa60>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    414c:	91144021 	add	x1, x1, #0x510
    4150:	3dc0dc43 	ldr	q3, [x2, #880]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    417c:	91134063 	add	x3, x3, #0x4d0
    4180:	9115c084 	add	x4, x4, #0x570
    4184:	91174266 	add	x6, x19, #0x5d0
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9c5 	bl	2910 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91174275 	add	x21, x19, #0x5d0
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9af 	bl	2910 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    4268:	91220000 	add	x0, x0, #0x880
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9e8 	bl	2a10 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91174273 	add	x19, x19, #0x5d0
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffb5c 	bl	3030 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	9101c122 	add	x2, x9, #0x70
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9403c46 	ldr	x6, [x2, #120]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	9101c120 	add	x0, x9, #0x70
    4354:	f900400b 	str	x11, [x0, #128]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	9101c129 	add	x9, x9, #0x70
    4360:	f9003d26 	str	x6, [x9, #120]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <fwp_tape_buffers_release>:
    4380:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4384:	910003fd 	mov	x29, sp
    4388:	a90153f3 	stp	x19, x20, [sp, #16]
    438c:	aa0003f3 	mov	x19, x0
    4390:	f9401400 	ldr	x0, [x0, #40]
    4394:	b7f80760 	tbnz	x0, #63, 4480 <fwp_tape_buffers_release+0x100>
    4398:	f9401a61 	ldr	x1, [x19, #48]
    439c:	b7f80301 	tbnz	x1, #63, 43fc <fwp_tape_buffers_release+0x7c>
    43a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    43a4:	eb02001f 	cmp	x0, x2
    43a8:	540002a8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43ac:	8b000400 	add	x0, x0, x0, lsl #1
    43b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    43b4:	d37df000 	lsl	x0, x0, #3
    43b8:	cb000042 	sub	x2, x2, x0
    43bc:	eb420c3f 	cmp	x1, x2, lsr #3
    43c0:	540001e8 	b.hi	43fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    43c4:	8b010c14 	add	x20, x0, x1, lsl #3
    43c8:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    43cc:	91224000 	add	x0, x0, #0x890
    43d0:	97fff990 	bl	2a10 <getenv@plt>
    43d4:	b4000240 	cbz	x0, 441c <fwp_tape_buffers_release+0x9c>
    43d8:	39400001 	ldrb	w1, [x0]
    43dc:	7100c03f 	cmp	w1, #0x30
    43e0:	540001e1 	b.ne	441c <fwp_tape_buffers_release+0x9c>  // b.any
    43e4:	39400400 	ldrb	w0, [x0, #1]
    43e8:	350001a0 	cbnz	w0, 441c <fwp_tape_buffers_release+0x9c>
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f8:	17fffc22 	b	3480 <fwp_tape_buffers_dispose>
    43fc:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    4400:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4404:	91224000 	add	x0, x0, #0x890
    4408:	97fff982 	bl	2a10 <getenv@plt>
    440c:	b4ffff00 	cbz	x0, 43ec <fwp_tape_buffers_release+0x6c>
    4410:	39400001 	ldrb	w1, [x0]
    4414:	7100c03f 	cmp	w1, #0x30
    4418:	54fffe60 	b.eq	43e4 <fwp_tape_buffers_release+0x64>  // b.none
    441c:	d1000681 	sub	x1, x20, #0x1
    4420:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4424:	eb00003f 	cmp	x1, x0
    4428:	54fffe28 	b.hi	43ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    442c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4430:	900000f6 	adrp	x22, 20000 <__data_start>
    4434:	9101c2d6 	add	x22, x22, #0x70
    4438:	910262d5 	add	x21, x22, #0x98
    443c:	aa1503e0 	mov	x0, x21
    4440:	97fffc10 	bl	3480 <fwp_tape_buffers_dispose>
    4444:	ad400a61 	ldp	q1, q2, [x19]
    4448:	f9006ad4 	str	x20, [x22, #208]
    444c:	4f000400 	movi	v0.4s, #0x0
    4450:	ad000aa1 	stp	q1, q2, [x21]
    4454:	3dc00a61 	ldr	q1, [x19, #32]
    4458:	3d800aa1 	str	q1, [x21, #32]
    445c:	f9401a60 	ldr	x0, [x19, #48]
    4460:	f9001aa0 	str	x0, [x21, #48]
    4464:	f9001a7f 	str	xzr, [x19, #48]
    4468:	ad000260 	stp	q0, q0, [x19]
    446c:	3d800a60 	str	q0, [x19, #32]
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4478:	a8c37bfd 	ldp	x29, x30, [sp], #48
    447c:	d65f03c0 	ret
    4480:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    4484:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4488:	91224000 	add	x0, x0, #0x890
    448c:	97fff961 	bl	2a10 <getenv@plt>
    4490:	b5fffa40 	cbnz	x0, 43d8 <fwp_tape_buffers_release+0x58>
    4494:	17ffffd6 	b	43ec <fwp_tape_buffers_release+0x6c>
    4498:	d503201f 	nop
    449c:	d503201f 	nop

00000000000044a0 <fwp_poll_events>:
    44a0:	d10103ff 	sub	sp, sp, #0x40
    44a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    44a8:	f947f400 	ldr	x0, [x0, #4072]
    44ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    44b0:	910083fd 	add	x29, sp, #0x20
    44b4:	a90353f3 	stp	x19, x20, [sp, #48]
    44b8:	900000f4 	adrp	x20, 20000 <__data_start>
    44bc:	f9400001 	ldr	x1, [x0]
    44c0:	f9000fe1 	str	x1, [sp, #24]
    44c4:	d2800001 	mov	x1, #0x0                   	// #0
    44c8:	97fffd2e 	bl	3980 <fwp_now_ns>
    44cc:	9101c281 	add	x1, x20, #0x70
    44d0:	f9406c33 	ldr	x19, [x1, #216]
    44d4:	b4000e93 	cbz	x19, 46a4 <fwp_poll_events+0x204>
    44d8:	aa1303e1 	mov	x1, x19
    44dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    44e0:	14000005 	b	44f4 <fwp_poll_events+0x54>
    44e4:	f9408821 	ldr	x1, [x1, #272]
    44e8:	eb03005f 	cmp	x2, x3
    44ec:	9a83d042 	csel	x2, x2, x3, le
    44f0:	b40000c1 	cbz	x1, 4508 <fwp_poll_events+0x68>
    44f4:	f9403423 	ldr	x3, [x1, #104]
    44f8:	b6ffff62 	tbz	x2, #63, 44e4 <fwp_poll_events+0x44>
    44fc:	f9408821 	ldr	x1, [x1, #272]
    4500:	aa0303e2 	mov	x2, x3
    4504:	b5ffff81 	cbnz	x1, 44f4 <fwp_poll_events+0x54>
    4508:	b7f80ce2 	tbnz	x2, #63, 46a4 <fwp_poll_events+0x204>
    450c:	cb000042 	sub	x2, x2, x0
    4510:	f100005f 	cmp	x2, #0x0
    4514:	540005cd 	b.le	45cc <fwp_poll_events+0x12c>
    4518:	d2869b60 	mov	x0, #0x34db                	// #13531
    451c:	d2884801 	mov	x1, #0x4240                	// #16960
    4520:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4524:	f2a001e1 	movk	x1, #0xf, lsl #16
    4528:	f2dbd040 	movk	x0, #0xde82, lsl #32
    452c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4530:	f2e86360 	movk	x0, #0x431b, lsl #48
    4534:	9b407c40 	smulh	x0, x2, x0
    4538:	9352fc00 	asr	x0, x0, #18
    453c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4540:	9b018802 	msub	x2, x0, x1, x2
    4544:	f100005f 	cmp	x2, #0x0
    4548:	9a800400 	cinc	x0, x0, ne	// ne = any
    454c:	eb03001f 	cmp	x0, x3
    4550:	54000a0c 	b.gt	4690 <fwp_poll_events+0x1f0>
    4554:	340003c0 	cbz	w0, 45cc <fwp_poll_events+0x12c>
    4558:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    455c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4560:	72a20c42 	movk	w2, #0x1062, lsl #16
    4564:	9ba27c02 	umull	x2, w0, w2
    4568:	d366fc43 	lsr	x3, x2, #38
    456c:	aa0303e2 	mov	x2, x3
    4570:	1b048063 	msub	w3, w3, w4, w0
    4574:	9b217c63 	smull	x3, w3, w1
    4578:	d2800001 	mov	x1, #0x0                   	// #0
    457c:	910023e0 	add	x0, sp, #0x8
    4580:	a9008fe2 	stp	x2, x3, [sp, #8]
    4584:	97fff8f3 	bl	2950 <nanosleep@plt>
    4588:	9101c280 	add	x0, x20, #0x70
    458c:	f9406c13 	ldr	x19, [x0, #216]
    4590:	97fffcfc 	bl	3980 <fwp_now_ns>
    4594:	aa0003e6 	mov	x6, x0
    4598:	b50001f3 	cbnz	x19, 45d4 <fwp_poll_events+0x134>
    459c:	d503201f 	nop
    45a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45a4:	f947f400 	ldr	x0, [x0, #4072]
    45a8:	f9400fe2 	ldr	x2, [sp, #24]
    45ac:	f9400001 	ldr	x1, [x0]
    45b0:	eb010042 	subs	x2, x2, x1
    45b4:	d2800001 	mov	x1, #0x0                   	// #0
    45b8:	540008c1 	b.ne	46d0 <fwp_poll_events+0x230>  // b.any
    45bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    45c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    45c4:	910103ff 	add	sp, sp, #0x40
    45c8:	d65f03c0 	ret
    45cc:	97fffced 	bl	3980 <fwp_now_ns>
    45d0:	aa0003e6 	mov	x6, x0
    45d4:	4f000400 	movi	v0.4s, #0x0
    45d8:	9101c288 	add	x8, x20, #0x70
    45dc:	52800027 	mov	w7, #0x1                   	// #1
    45e0:	f9403661 	ldr	x1, [x19, #104]
    45e4:	aa1303e5 	mov	x5, x19
    45e8:	f9408a73 	ldr	x19, [x19, #272]
    45ec:	eb06003f 	cmp	x1, x6
    45f0:	5400032c 	b.gt	4654 <fwp_poll_events+0x1b4>
    45f4:	394154a0 	ldrb	w0, [x5, #85]
    45f8:	36000120 	tbz	w0, #0, 461c <fwp_poll_events+0x17c>
    45fc:	f94084a0 	ldr	x0, [x5, #264]
    4600:	b40003c0 	cbz	x0, 4678 <fwp_poll_events+0x1d8>
    4604:	f9008813 	str	x19, [x0, #272]
    4608:	b4000053 	cbz	x19, 4610 <fwp_poll_events+0x170>
    460c:	f9008660 	str	x0, [x19, #264]
    4610:	910800a0 	add	x0, x5, #0x200
    4614:	390154bf 	strb	wzr, [x5, #85]
    4618:	3c908000 	stur	q0, [x0, #-248]
    461c:	f94030a0 	ldr	x0, [x5, #96]
    4620:	390158a7 	strb	w7, [x5, #86]
    4624:	f100001f 	cmp	x0, #0x0
    4628:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    462c:	5400018d 	b.le	465c <fwp_poll_events+0x1bc>
    4630:	f94028a0 	ldr	x0, [x5, #80]
    4634:	f2001c1f 	tst	x0, #0xff000000ff
    4638:	540000e1 	b.ne	4654 <fwp_poll_events+0x1b4>  // b.any
    463c:	f9403d00 	ldr	x0, [x8, #120]
    4640:	390150a7 	strb	w7, [x5, #84]
    4644:	f90080bf 	str	xzr, [x5, #256]
    4648:	b40001e0 	cbz	x0, 4684 <fwp_poll_events+0x1e4>
    464c:	f9003d05 	str	x5, [x8, #120]
    4650:	f9008005 	str	x5, [x0, #256]
    4654:	b5fffc73 	cbnz	x19, 45e0 <fwp_poll_events+0x140>
    4658:	17ffffd2 	b	45a0 <fwp_poll_events+0x100>
    465c:	394144a0 	ldrb	w0, [x5, #81]
    4660:	3707fe80 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    4664:	394140a0 	ldrb	w0, [x5, #80]
    4668:	3707fe40 	tbnz	w0, #0, 4630 <fwp_poll_events+0x190>
    466c:	aa0503e0 	mov	x0, x5
    4670:	97fffc20 	bl	36f0 <fwp_cancel_tree.part.0>
    4674:	17ffffef 	b	4630 <fwp_poll_events+0x190>
    4678:	9101c281 	add	x1, x20, #0x70
    467c:	f9006c33 	str	x19, [x1, #216]
    4680:	17ffffe2 	b	4608 <fwp_poll_events+0x168>
    4684:	f9003d05 	str	x5, [x8, #120]
    4688:	f9004105 	str	x5, [x8, #128]
    468c:	17fffff2 	b	4654 <fwp_poll_events+0x1b4>
    4690:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4694:	d2989362 	mov	x2, #0xc49b                	// #50331
    4698:	f2a4d203 	movk	x3, #0x2690, lsl #16
    469c:	f2a00402 	movk	x2, #0x20, lsl #16
    46a0:	17ffffb6 	b	4578 <fwp_poll_events+0xd8>
    46a4:	97fffa53 	bl	2ff0 <fwp_flush>
    46a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    46ac:	f947e863 	ldr	x3, [x3, #4048]
    46b0:	d2800562 	mov	x2, #0x2b                  	// #43
    46b4:	d2800021 	mov	x1, #0x1                   	// #1
    46b8:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    46bc:	9122a000 	add	x0, x0, #0x8a8
    46c0:	f9400063 	ldr	x3, [x3]
    46c4:	97fff8af 	bl	2980 <fwrite@plt>
    46c8:	52800ca0 	mov	w0, #0x65                  	// #101
    46cc:	97fff819 	bl	2730 <exit@plt>
    46d0:	97fff86c 	bl	2880 <__stack_chk_fail@plt>

00000000000046d4 <fwp_rc_wide_dup>:
    46d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    46d8:	910003fd 	mov	x29, sp
    46dc:	a90153f3 	stp	x19, x20, [sp, #16]
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	ca404400 	eor	x0, x0, x0, lsr #17
    46e8:	f90013f5 	str	x21, [sp, #32]
    46ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    46f0:	ca402400 	eor	x0, x0, x0, lsr #9
    46f4:	911742a2 	add	x2, x21, #0x5d0
    46f8:	92401c00 	and	x0, x0, #0xff
    46fc:	910a2403 	add	x3, x0, #0x289
    4700:	8b000c40 	add	x0, x2, x0, lsl #3
    4704:	8b030c54 	add	x20, x2, x3, lsl #3
    4708:	f94a2401 	ldr	x1, [x0, #5192]
    470c:	b50000a1 	cbnz	x1, 4720 <fwp_rc_wide_dup+0x4c>
    4710:	1400002d 	b	47c4 <fwp_rc_wide_dup+0xf0>
    4714:	91004034 	add	x20, x1, #0x10
    4718:	f9400821 	ldr	x1, [x1, #16]
    471c:	b4000241 	cbz	x1, 4764 <fwp_rc_wide_dup+0x90>
    4720:	f9400022 	ldr	x2, [x1]
    4724:	eb02027f 	cmp	x19, x2
    4728:	54ffff61 	b.ne	4714 <fwp_rc_wide_dup+0x40>  // b.any
    472c:	f9400281 	ldr	x1, [x20]
    4730:	39400260 	ldrb	w0, [x19]
    4734:	7103f81f 	cmp	w0, #0xfe
    4738:	54000220 	b.eq	477c <fwp_rc_wide_dup+0xa8>  // b.none
    473c:	b40001a1 	cbz	x1, 4770 <fwp_rc_wide_dup+0x9c>
    4740:	f9400420 	ldr	x0, [x1, #8]
    4744:	b100041f 	cmn	x0, #0x1
    4748:	540004a0 	b.eq	47dc <fwp_rc_wide_dup+0x108>  // b.none
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f9000420 	str	x0, [x1, #8]
    4754:	a94153f3 	ldp	x19, x20, [sp, #16]
    4758:	f94013f5 	ldr	x21, [sp, #32]
    475c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4760:	d65f03c0 	ret
    4764:	39400260 	ldrb	w0, [x19]
    4768:	7103f81f 	cmp	w0, #0xfe
    476c:	540000a0 	b.eq	4780 <fwp_rc_wide_dup+0xac>  // b.none
    4770:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    4774:	91240000 	add	x0, x0, #0x900
    4778:	97fffc22 	bl	3800 <fwp_trap>
    477c:	b5000281 	cbnz	x1, 47cc <fwp_rc_wide_dup+0xf8>
    4780:	d2800300 	mov	x0, #0x18                  	// #24
    4784:	97fff827 	bl	2820 <malloc@plt>
    4788:	b4000280 	cbz	x0, 47d8 <fwp_rc_wide_dup+0x104>
    478c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4790:	a9000413 	stp	x19, x1, [x0]
    4794:	911742b5 	add	x21, x21, #0x5d0
    4798:	f900081f 	str	xzr, [x0, #16]
    479c:	12800001 	mov	w1, #0xffffffff            	// #-1
    47a0:	f9000280 	str	x0, [x20]
    47a4:	39000261 	strb	w1, [x19]
    47a8:	f94e26a0 	ldr	x0, [x21, #7240]
    47ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b0:	91000400 	add	x0, x0, #0x1
    47b4:	f90e26a0 	str	x0, [x21, #7240]
    47b8:	f94013f5 	ldr	x21, [sp, #32]
    47bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47c0:	d65f03c0 	ret
    47c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    47c8:	17ffffda 	b	4730 <fwp_rc_wide_dup+0x5c>
    47cc:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    47d0:	91236000 	add	x0, x0, #0x8d8
    47d4:	97fffc0b 	bl	3800 <fwp_trap>
    47d8:	97fffa16 	bl	3030 <fwp_heap_oom>
    47dc:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    47e0:	9124a000 	add	x0, x0, #0x928
    47e4:	97fffc07 	bl	3800 <fwp_trap>
    47e8:	d503201f 	nop
    47ec:	d503201f 	nop

00000000000047f0 <fwp_rc_forget_slot>:
    47f0:	aa0003e1 	mov	x1, x0
    47f4:	39400000 	ldrb	w0, [x0]
    47f8:	7103fc1f 	cmp	w0, #0xff
    47fc:	54000040 	b.eq	4804 <fwp_rc_forget_slot+0x14>  // b.none
    4800:	d65f03c0 	ret
    4804:	ca414420 	eor	x0, x1, x1, lsr #17
    4808:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    480c:	ca402400 	eor	x0, x0, x0, lsr #9
    4810:	910003fd 	mov	x29, sp
    4814:	92401c00 	and	x0, x0, #0xff
    4818:	f9000bf3 	str	x19, [sp, #16]
    481c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4820:	91174262 	add	x2, x19, #0x5d0
    4824:	910a2403 	add	x3, x0, #0x289
    4828:	8b000c40 	add	x0, x2, x0, lsl #3
    482c:	8b030c43 	add	x3, x2, x3, lsl #3
    4830:	f94a2400 	ldr	x0, [x0, #5192]
    4834:	b50000a0 	cbnz	x0, 4848 <fwp_rc_forget_slot+0x58>
    4838:	14000011 	b	487c <fwp_rc_forget_slot+0x8c>
    483c:	91004003 	add	x3, x0, #0x10
    4840:	f9400800 	ldr	x0, [x0, #16]
    4844:	b40001c0 	cbz	x0, 487c <fwp_rc_forget_slot+0x8c>
    4848:	f9400002 	ldr	x2, [x0]
    484c:	eb02003f 	cmp	x1, x2
    4850:	54ffff61 	b.ne	483c <fwp_rc_forget_slot+0x4c>  // b.any
    4854:	f9400801 	ldr	x1, [x0, #16]
    4858:	91174273 	add	x19, x19, #0x5d0
    485c:	f9000061 	str	x1, [x3]
    4860:	97fff838 	bl	2940 <free@plt>
    4864:	f94e2660 	ldr	x0, [x19, #7240]
    4868:	d1000400 	sub	x0, x0, #0x1
    486c:	f90e2660 	str	x0, [x19, #7240]
    4870:	f9400bf3 	ldr	x19, [sp, #16]
    4874:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4878:	d65f03c0 	ret
    487c:	f0000020 	adrp	x0, b000 <__divti3+0x180>
    4880:	91240000 	add	x0, x0, #0x900
    4884:	97fffbdf 	bl	3800 <fwp_trap>
    4888:	d503201f 	nop
    488c:	d503201f 	nop

0000000000004890 <fwp_rc_prepare_chunk>:
    4890:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4894:	910003fd 	mov	x29, sp
    4898:	a9025bf5 	stp	x21, x22, [sp, #32]
    489c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    48a0:	911742c2 	add	x2, x22, #0x5d0
    48a4:	b9401c03 	ldr	w3, [x0, #28]
    48a8:	aa0103f5 	mov	x21, x1
    48ac:	a90153f3 	stp	x19, x20, [sp, #16]
    48b0:	aa0003f4 	mov	x20, x0
    48b4:	f94e2440 	ldr	x0, [x2, #7240]
    48b8:	b4000440 	cbz	x0, 4940 <fwp_rc_prepare_chunk+0xb0>
    48bc:	d2800013 	mov	x19, #0x0                   	// #0
    48c0:	35000203 	cbnz	w3, 4900 <fwp_rc_prepare_chunk+0x70>
    48c4:	b4000361 	cbz	x1, 4930 <fwp_rc_prepare_chunk+0xa0>
    48c8:	f9401280 	ldr	x0, [x20, #32]
    48cc:	97fff81d 	bl	2940 <free@plt>
    48d0:	aa1503e0 	mov	x0, x21
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	97fff7e2 	bl	2860 <calloc@plt>
    48dc:	f9001280 	str	x0, [x20, #32]
    48e0:	b5000460 	cbnz	x0, 496c <fwp_rc_prepare_chunk+0xdc>
    48e4:	97fff9d3 	bl	3030 <fwp_heap_oom>
    48e8:	97ffffc2 	bl	47f0 <fwp_rc_forget_slot>
    48ec:	91000673 	add	x19, x19, #0x1
    48f0:	b9401e83 	ldr	w3, [x20, #28]
    48f4:	eb13007f 	cmp	x3, x19
    48f8:	54000169 	b.ls	4924 <fwp_rc_prepare_chunk+0x94>  // b.plast
    48fc:	d503201f 	nop
    4900:	f9401283 	ldr	x3, [x20, #32]
    4904:	8b130060 	add	x0, x3, x19
    4908:	38736863 	ldrb	w3, [x3, x19]
    490c:	7103fc7f 	cmp	w3, #0xff
    4910:	54fffec0 	b.eq	48e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4914:	b9401e83 	ldr	w3, [x20, #28]
    4918:	91000673 	add	x19, x19, #0x1
    491c:	eb13007f 	cmp	x3, x19
    4920:	54ffff08 	b.hi	4900 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4924:	eb0302bf 	cmp	x21, x3
    4928:	54000121 	b.ne	494c <fwp_rc_prepare_chunk+0xbc>  // b.any
    492c:	b5000335 	cbnz	x21, 4990 <fwp_rc_prepare_chunk+0x100>
    4930:	a94153f3 	ldp	x19, x20, [sp, #16]
    4934:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4938:	a8c37bfd 	ldp	x29, x30, [sp], #48
    493c:	d65f03c0 	ret
    4940:	2a0303e3 	mov	w3, w3
    4944:	eb0302bf 	cmp	x21, x3
    4948:	54ffff20 	b.eq	492c <fwp_rc_prepare_chunk+0x9c>  // b.none
    494c:	911742c2 	add	x2, x22, #0x5d0
    4950:	f9401280 	ldr	x0, [x20, #32]
    4954:	f94e2841 	ldr	x1, [x2, #7248]
    4958:	cb030021 	sub	x1, x1, x3
    495c:	f90e2841 	str	x1, [x2, #7248]
    4960:	97fff7f8 	bl	2940 <free@plt>
    4964:	b5fffb75 	cbnz	x21, 48d0 <fwp_rc_prepare_chunk+0x40>
    4968:	f900129f 	str	xzr, [x20, #32]
    496c:	911742d6 	add	x22, x22, #0x5d0
    4970:	f94e2ac0 	ldr	x0, [x22, #7248]
    4974:	b9001e95 	str	w21, [x20, #28]
    4978:	a94153f3 	ldp	x19, x20, [sp, #16]
    497c:	8b150000 	add	x0, x0, x21
    4980:	f90e2ac0 	str	x0, [x22, #7248]
    4984:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4988:	a8c37bfd 	ldp	x29, x30, [sp], #48
    498c:	d65f03c0 	ret
    4990:	f9401280 	ldr	x0, [x20, #32]
    4994:	aa1503e2 	mov	x2, x21
    4998:	a94153f3 	ldp	x19, x20, [sp, #16]
    499c:	52800001 	mov	w1, #0x0                   	// #0
    49a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49a8:	17fff7aa 	b	2850 <memset@plt>
    49ac:	d503201f 	nop

00000000000049b0 <fwp_heap_refill>:
    49b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49b4:	910003fd 	mov	x29, sp
    49b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    49bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    49c0:	911742b5 	add	x21, x21, #0x5d0
    49c4:	aa0003f6 	mov	x22, x0
    49c8:	d2800020 	mov	x0, #0x1                   	// #1
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a90363f7 	stp	x23, x24, [sp, #48]
    49d4:	2a0103f7 	mov	w23, w1
    49d8:	2a0203f8 	mov	w24, w2
    49dc:	97fffa35 	bl	32b0 <fwp_heap_chunks>
    49e0:	aa0003f3 	mov	x19, x0
    49e4:	f949fea2 	ldr	x2, [x21, #5112]
    49e8:	8b000800 	add	x0, x0, x0, lsl #2
    49ec:	2a1703e1 	mov	w1, w23
    49f0:	52800025 	mov	w5, #0x1                   	// #1
    49f4:	d37df000 	lsl	x0, x0, #3
    49f8:	910f0021 	add	x1, x1, #0x3c0
    49fc:	8b000054 	add	x20, x2, x0
    4a00:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a04:	52a00024 	mov	w4, #0x10000               	// #65536
    4a08:	38206845 	strb	w5, [x2, x0]
    4a0c:	aa1403e0 	mov	x0, x20
    4a10:	39000698 	strb	w24, [x20, #1]
    4a14:	39000a97 	strb	w23, [x20, #2]
    4a18:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a1c:	b9000681 	str	w1, [x20, #4]
    4a20:	2a0103e5 	mov	w5, w1
    4a24:	8b0300a2 	add	x2, x5, x3
    4a28:	1ac10881 	udiv	w1, w4, w1
    4a2c:	9ac50842 	udiv	x2, x2, x5
    4a30:	b9000a81 	str	w1, [x20, #8]
    4a34:	92404021 	and	x1, x1, #0x1ffff
    4a38:	b9001a82 	str	w2, [x20, #24]
    4a3c:	97ffff95 	bl	4890 <fwp_rc_prepare_chunk>
    4a40:	f949daa0 	ldr	x0, [x21, #5040]
    4a44:	29408a81 	ldp	w1, w2, [x20, #4]
    4a48:	8b134000 	add	x0, x0, x19, lsl #16
    4a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a50:	8b214003 	add	x3, x0, w1, uxtw
    4a54:	9ba20021 	umaddl	x1, w1, w2, x0
    4a58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a5c:	a90086c3 	stp	x3, x1, [x22, #8]
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a68:	d65f03c0 	ret
    4a6c:	d503201f 	nop

0000000000004a70 <fwp_mem_free>:
    4a70:	b40003c0 	cbz	x0, 4ae8 <fwp_mem_free+0x78>
    4a74:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a80:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a84:	911742a1 	add	x1, x21, #0x5d0
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	aa0003f3 	mov	x19, x0
    4a90:	f949d823 	ldr	x3, [x1, #5040]
    4a94:	f949ec22 	ldr	x2, [x1, #5080]
    4a98:	cb030000 	sub	x0, x0, x3
    4a9c:	eb02401f 	cmp	x0, x2, lsl #16
    4aa0:	540001c2 	b.cs	4ad8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4aa4:	d350fc16 	lsr	x22, x0, #16
    4aa8:	a90363f7 	stp	x23, x24, [sp, #48]
    4aac:	f949fc22 	ldr	x2, [x1, #5112]
    4ab0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4ab4:	d37df294 	lsl	x20, x20, #3
    4ab8:	ab140057 	adds	x23, x2, x20
    4abc:	540000c0 	b.eq	4ad4 <fwp_mem_free+0x64>  // b.none
    4ac0:	38746842 	ldrb	w2, [x2, x20]
    4ac4:	7100045f 	cmp	w2, #0x1
    4ac8:	54000120 	b.eq	4aec <fwp_mem_free+0x7c>  // b.none
    4acc:	7100085f 	cmp	w2, #0x2
    4ad0:	540005e0 	b.eq	4b8c <fwp_mem_free+0x11c>  // b.none
    4ad4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ae4:	d65f03c0 	ret
    4ae8:	d65f03c0 	ret
    4aec:	f94012f8 	ldr	x24, [x23, #32]
    4af0:	b94006e1 	ldr	w1, [x23, #4]
    4af4:	f90023f9 	str	x25, [sp, #64]
    4af8:	2a0103e2 	mov	w2, w1
    4afc:	394006f9 	ldrb	w25, [x23, #1]
    4b00:	39400af4 	ldrb	w20, [x23, #2]
    4b04:	b4000158 	cbz	x24, 4b2c <fwp_mem_free+0xbc>
    4b08:	92403e76 	and	x22, x19, #0xffff
    4b0c:	9ac20ad6 	udiv	x22, x22, x2
    4b10:	38766b01 	ldrb	w1, [x24, x22]
    4b14:	8b160300 	add	x0, x24, x22
    4b18:	7103fc3f 	cmp	w1, #0xff
    4b1c:	54000980 	b.eq	4c4c <fwp_mem_free+0x1dc>  // b.none
    4b20:	38366b1f 	strb	wzr, [x24, x22]
    4b24:	b94006e1 	ldr	w1, [x23, #4]
    4b28:	2a0103e2 	mov	w2, w1
    4b2c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4b30:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4b34:	cb390000 	sub	x0, x0, w25, uxtb
    4b38:	8b340074 	add	x20, x3, w20, uxtb
    4b3c:	911742b5 	add	x21, x21, #0x5d0
    4b40:	1e630021 	ucvtf	d1, w1
    4b44:	d37ae400 	lsl	x0, x0, #6
    4b48:	8b140c14 	add	x20, x0, x20, lsl #3
    4b4c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b50:	f8746aa0 	ldr	x0, [x21, x20]
    4b54:	f94023f9 	ldr	x25, [sp, #64]
    4b58:	aa2003e0 	mvn	x0, x0
    4b5c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4b60:	f9000260 	str	x0, [x19]
    4b64:	f8346ab3 	str	x19, [x21, x20]
    4b68:	f94a12a0 	ldr	x0, [x21, #5152]
    4b6c:	1e612800 	fadd	d0, d0, d1
    4b70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b74:	cb020000 	sub	x0, x0, x2
    4b78:	f90a12a0 	str	x0, [x21, #5152]
    4b7c:	fd0a22a0 	str	d0, [x21, #5184]
    4b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b84:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b88:	d65f03c0 	ret
    4b8c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4b90:	8b000063 	add	x3, x3, x0
    4b94:	eb03027f 	cmp	x19, x3
    4b98:	54fff9e1 	b.ne	4ad4 <fwp_mem_free+0x64>  // b.any
    4b9c:	fd400ae1 	ldr	d1, [x23, #16]
    4ba0:	fd4a2020 	ldr	d0, [x1, #5184]
    4ba4:	f9400ae0 	ldr	x0, [x23, #16]
    4ba8:	7e61d821 	ucvtf	d1, d1
    4bac:	f94a1022 	ldr	x2, [x1, #5152]
    4bb0:	f94012f3 	ldr	x19, [x23, #32]
    4bb4:	1e612800 	fadd	d0, d0, d1
    4bb8:	cb000042 	sub	x2, x2, x0
    4bbc:	f90a1022 	str	x2, [x1, #5152]
    4bc0:	fd0a2020 	str	d0, [x1, #5184]
    4bc4:	b40000b3 	cbz	x19, 4bd8 <fwp_mem_free+0x168>
    4bc8:	39400260 	ldrb	w0, [x19]
    4bcc:	7103fc1f 	cmp	w0, #0xff
    4bd0:	54000380 	b.eq	4c40 <fwp_mem_free+0x1d0>  // b.none
    4bd4:	3900027f 	strb	wzr, [x19]
    4bd8:	b9400ee2 	ldr	w2, [x23, #12]
    4bdc:	b4000142 	cbz	x2, 4c04 <fwp_mem_free+0x194>
    4be0:	911742a1 	add	x1, x21, #0x5d0
    4be4:	8b160040 	add	x0, x2, x22
    4be8:	8b000800 	add	x0, x0, x0, lsl #2
    4bec:	f949fc21 	ldr	x1, [x1, #5112]
    4bf0:	8b140034 	add	x20, x1, x20
    4bf4:	8b000c20 	add	x0, x1, x0, lsl #3
    4bf8:	3802869f 	strb	wzr, [x20], #40
    4bfc:	eb00029f 	cmp	x20, x0
    4c00:	54ffffc1 	b.ne	4bf8 <fwp_mem_free+0x188>  // b.any
    4c04:	911742a0 	add	x0, x21, #0x5d0
    4c08:	f94a1801 	ldr	x1, [x0, #5168]
    4c0c:	f949f803 	ldr	x3, [x0, #5104]
    4c10:	8b020021 	add	x1, x1, x2
    4c14:	f90a1801 	str	x1, [x0, #5168]
    4c18:	eb16007f 	cmp	x3, x22
    4c1c:	54000049 	b.ls	4c24 <fwp_mem_free+0x1b4>  // b.plast
    4c20:	f909f816 	str	x22, [x0, #5104]
    4c24:	911742b5 	add	x21, x21, #0x5d0
    4c28:	f949f6a0 	ldr	x0, [x21, #5096]
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54fff529 	b.ls	4ad4 <fwp_mem_free+0x64>  // b.plast
    4c34:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c38:	f909f6b6 	str	x22, [x21, #5096]
    4c3c:	17ffffa7 	b	4ad8 <fwp_mem_free+0x68>
    4c40:	aa1303e0 	mov	x0, x19
    4c44:	97fffeeb 	bl	47f0 <fwp_rc_forget_slot>
    4c48:	17ffffe3 	b	4bd4 <fwp_mem_free+0x164>
    4c4c:	97fffee9 	bl	47f0 <fwp_rc_forget_slot>
    4c50:	17ffffb4 	b	4b20 <fwp_mem_free+0xb0>

0000000000004c54 <fwp_heap_alloc_big>:
    4c54:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c58:	910003fd 	mov	x29, sp
    4c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c60:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c64:	a90363f7 	stp	x23, x24, [sp, #48]
    4c68:	aa0003f7 	mov	x23, x0
    4c6c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c70:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c74:	eb0002ff 	cmp	x23, x0
    4c78:	54000888 	b.hi	4d88 <fwp_heap_alloc_big+0x134>  // b.pmore
    4c7c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c80:	8b0002f4 	add	x20, x23, x0
    4c84:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4c88:	91174359 	add	x25, x26, #0x5d0
    4c8c:	d350fe94 	lsr	x20, x20, #16
    4c90:	2a0103f5 	mov	w21, w1
    4c94:	aa1403e0 	mov	x0, x20
    4c98:	97fff986 	bl	32b0 <fwp_heap_chunks>
    4c9c:	f949ff22 	ldr	x2, [x25, #5112]
    4ca0:	8b000813 	add	x19, x0, x0, lsl #2
    4ca4:	aa0003f8 	mov	x24, x0
    4ca8:	52800043 	mov	w3, #0x2                   	// #2
    4cac:	d37df273 	lsl	x19, x19, #3
    4cb0:	d2800021 	mov	x1, #0x1                   	// #1
    4cb4:	8b130040 	add	x0, x2, x19
    4cb8:	38336843 	strb	w3, [x2, x19]
    4cbc:	39000415 	strb	w21, [x0, #1]
    4cc0:	b9000c14 	str	w20, [x0, #12]
    4cc4:	f9000817 	str	x23, [x0, #16]
    4cc8:	97fffef2 	bl	4890 <fwp_rc_prepare_chunk>
    4ccc:	f100069f 	cmp	x20, #0x1
    4cd0:	54000269 	b.ls	4d1c <fwp_heap_alloc_big+0xc8>  // b.plast
    4cd4:	8b180294 	add	x20, x20, x24
    4cd8:	9100a273 	add	x19, x19, #0x28
    4cdc:	a90573fb 	stp	x27, x28, [sp, #80]
    4ce0:	5280007b 	mov	w27, #0x3                   	// #3
    4ce4:	8b140a94 	add	x20, x20, x20, lsl #2
    4ce8:	2a1803fc 	mov	w28, w24
    4cec:	9adb2296 	lsl	x22, x20, x27
    4cf0:	f949ff35 	ldr	x21, [x25, #5112]
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
    4cf8:	8b1302b4 	add	x20, x21, x19
    4cfc:	aa1403e0 	mov	x0, x20
    4d00:	97fffee4 	bl	4890 <fwp_rc_prepare_chunk>
    4d04:	38336abb 	strb	w27, [x21, x19]
    4d08:	9100a273 	add	x19, x19, #0x28
    4d0c:	b9000e9c 	str	w28, [x20, #12]
    4d10:	eb1302df 	cmp	x22, x19
    4d14:	54fffee1 	b.ne	4cf0 <fwp_heap_alloc_big+0x9c>  // b.any
    4d18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d1c:	91174353 	add	x19, x26, #0x5d0
    4d20:	aa1703e2 	mov	x2, x23
    4d24:	52800001 	mov	w1, #0x0                   	// #0
    4d28:	f949da60 	ldr	x0, [x19, #5040]
    4d2c:	8b184018 	add	x24, x0, x24, lsl #16
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff6c7 	bl	2850 <memset@plt>
    4d38:	f94a1260 	ldr	x0, [x19, #5152]
    4d3c:	ab170000 	adds	x0, x0, x23
    4d40:	54000242 	b.cs	4d88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4d44:	f94a1661 	ldr	x1, [x19, #5160]
    4d48:	f90a1260 	str	x0, [x19, #5152]
    4d4c:	eb01001f 	cmp	x0, x1
    4d50:	54000049 	b.ls	4d58 <fwp_heap_alloc_big+0x104>  // b.plast
    4d54:	f90a1660 	str	x0, [x19, #5160]
    4d58:	9117435a 	add	x26, x26, #0x5d0
    4d5c:	9e6202e0 	scvtf	d0, x23
    4d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d64:	aa1803e0 	mov	x0, x24
    4d68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d70:	1e602820 	fadd	d0, d1, d0
    4d74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d78:	fd0a1f40 	str	d0, [x26, #5176]
    4d7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d84:	d65f03c0 	ret
    4d88:	a90573fb 	stp	x27, x28, [sp, #80]
    4d8c:	97fff8a9 	bl	3030 <fwp_heap_oom>

0000000000004d90 <fwp_heap_alloc_slow>:
    4d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d94:	910003fd 	mov	x29, sp
    4d98:	a90153f3 	stp	x19, x20, [sp, #16]
    4d9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4da0:	91174262 	add	x2, x19, #0x5d0
    4da4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4da8:	aa0003f5 	mov	x21, x0
    4dac:	2a0103f4 	mov	w20, w1
    4db0:	b953a440 	ldr	w0, [x2, #5028]
    4db4:	34000600 	cbz	w0, 4e74 <fwp_heap_alloc_slow+0xe4>
    4db8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dbc:	54000628 	b.hi	4e80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4dc0:	91003ea0 	add	x0, x21, #0xf
    4dc4:	91174262 	add	x2, x19, #0x5d0
    4dc8:	f9001bf7 	str	x23, [sp, #48]
    4dcc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dd0:	8b401040 	add	x0, x2, x0, lsr #4
    4dd4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dd8:	d37ae484 	lsl	x4, x4, #6
    4ddc:	397e8003 	ldrb	w3, [x0, #4000]
    4de0:	910f0060 	add	x0, x3, #0x3c0
    4de4:	aa0303e1 	mov	x1, x3
    4de8:	8b030463 	add	x3, x3, x3, lsl #1
    4dec:	8b030c83 	add	x3, x4, x3, lsl #3
    4df0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4df4:	2a1703f6 	mov	w22, w23
    4df8:	f8636844 	ldr	x4, [x2, x3]
    4dfc:	b40004e4 	cbz	x4, 4e98 <fwp_heap_alloc_slow+0x108>
    4e00:	f9400080 	ldr	x0, [x4]
    4e04:	aa2003e0 	mvn	x0, x0
    4e08:	f8236840 	str	x0, [x2, x3]
    4e0c:	7100069f 	cmp	w20, #0x1
    4e10:	aa0403e0 	mov	x0, x4
    4e14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e18:	52800001 	mov	w1, #0x0                   	// #0
    4e1c:	97fff68d 	bl	2850 <memset@plt>
    4e20:	aa0003e4 	mov	x4, x0
    4e24:	91174260 	add	x0, x19, #0x5d0
    4e28:	f94a1001 	ldr	x1, [x0, #5152]
    4e2c:	ab160021 	adds	x1, x1, x22
    4e30:	540005c2 	b.cs	4ee8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e34:	f94a1402 	ldr	x2, [x0, #5160]
    4e38:	f90a1001 	str	x1, [x0, #5152]
    4e3c:	eb02003f 	cmp	x1, x2
    4e40:	54000049 	b.ls	4e48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e44:	f90a1401 	str	x1, [x0, #5160]
    4e48:	91174273 	add	x19, x19, #0x5d0
    4e4c:	1e6302e1 	ucvtf	d1, w23
    4e50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e54:	aa0403e0 	mov	x0, x4
    4e58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e5c:	f9401bf7 	ldr	x23, [sp, #48]
    4e60:	1e612800 	fadd	d0, d0, d1
    4e64:	fd0a1e60 	str	d0, [x19, #5176]
    4e68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e70:	d65f03c0 	ret
    4e74:	97fffca4 	bl	4104 <fwp_heap_init>
    4e78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e7c:	54fffa29 	b.ls	4dc0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e80:	2a1403e1 	mov	w1, w20
    4e84:	aa1503e0 	mov	x0, x21
    4e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e94:	17ffff70 	b	4c54 <fwp_heap_alloc_big>
    4e98:	8b030042 	add	x2, x2, x3
    4e9c:	f9400444 	ldr	x4, [x2, #8]
    4ea0:	b4000104 	cbz	x4, 4ec0 <fwp_heap_alloc_slow+0x130>
    4ea4:	f9400840 	ldr	x0, [x2, #16]
    4ea8:	cb040000 	sub	x0, x0, x4
    4eac:	eb16001f 	cmp	x0, x22
    4eb0:	54000083 	b.cc	4ec0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4eb4:	8b160080 	add	x0, x4, x22
    4eb8:	f9000440 	str	x0, [x2, #8]
    4ebc:	17ffffd4 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ec0:	52800302 	mov	w2, #0x18                  	// #24
    4ec4:	52807804 	mov	w4, #0x3c0                 	// #960
    4ec8:	91174260 	add	x0, x19, #0x5d0
    4ecc:	9ba27c23 	umull	x3, w1, w2
    4ed0:	2a1403e2 	mov	w2, w20
    4ed4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ed8:	8b040000 	add	x0, x0, x4
    4edc:	97fffeb5 	bl	49b0 <fwp_heap_refill>
    4ee0:	aa0003e4 	mov	x4, x0
    4ee4:	17ffffca 	b	4e0c <fwp_heap_alloc_slow+0x7c>
    4ee8:	97fff852 	bl	3030 <fwp_heap_oom>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_heap_alloc>:
    4ef0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ef4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ef8:	910003fd 	mov	x29, sp
    4efc:	a90153f3 	stp	x19, x20, [sp, #16]
    4f00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f04:	91174293 	add	x19, x20, #0x5d0
    4f08:	b953a662 	ldr	w2, [x19, #5028]
    4f0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f10:	54000640 	b.eq	4fd8 <fwp_heap_alloc+0xe8>  // b.none
    4f14:	91003c03 	add	x3, x0, #0xf
    4f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f20:	8b431263 	add	x3, x19, x3, lsr #4
    4f24:	cb21c042 	sub	x2, x2, w1, sxtw
    4f28:	d37ae442 	lsl	x2, x2, #6
    4f2c:	397e8063 	ldrb	w3, [x3, #4000]
    4f30:	910f0064 	add	x4, x3, #0x3c0
    4f34:	8b030463 	add	x3, x3, x3, lsl #1
    4f38:	8b030c43 	add	x3, x2, x3, lsl #3
    4f3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f40:	2a1603f5 	mov	w21, w22
    4f44:	f8636a64 	ldr	x4, [x19, x3]
    4f48:	b4000384 	cbz	x4, 4fb8 <fwp_heap_alloc+0xc8>
    4f4c:	f9400085 	ldr	x5, [x4]
    4f50:	7100043f 	cmp	w1, #0x1
    4f54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f58:	aa0403e0 	mov	x0, x4
    4f5c:	aa2503e5 	mvn	x5, x5
    4f60:	52800001 	mov	w1, #0x0                   	// #0
    4f64:	f8236a65 	str	x5, [x19, x3]
    4f68:	97fff63a 	bl	2850 <memset@plt>
    4f6c:	aa0003e4 	mov	x4, x0
    4f70:	f94a1260 	ldr	x0, [x19, #5152]
    4f74:	ab150000 	adds	x0, x0, x21
    4f78:	54000442 	b.cs	5000 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f7c:	f94a1661 	ldr	x1, [x19, #5160]
    4f80:	f90a1260 	str	x0, [x19, #5152]
    4f84:	eb01001f 	cmp	x0, x1
    4f88:	54000049 	b.ls	4f90 <fwp_heap_alloc+0xa0>  // b.plast
    4f8c:	f90a1660 	str	x0, [x19, #5160]
    4f90:	91174294 	add	x20, x20, #0x5d0
    4f94:	1e6302c1 	ucvtf	d1, w22
    4f98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f9c:	aa0403e0 	mov	x0, x4
    4fa0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4fa4:	1e612800 	fadd	d0, d0, d1
    4fa8:	fd0a1e80 	str	d0, [x20, #5176]
    4fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fb4:	d65f03c0 	ret
    4fb8:	8b030263 	add	x3, x19, x3
    4fbc:	f9400464 	ldr	x4, [x3, #8]
    4fc0:	b40000a4 	cbz	x4, 4fd4 <fwp_heap_alloc+0xe4>
    4fc4:	f9400862 	ldr	x2, [x3, #16]
    4fc8:	cb040042 	sub	x2, x2, x4
    4fcc:	eb15005f 	cmp	x2, x21
    4fd0:	540000a2 	b.cs	4fe4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fe0:	17ffff6c 	b	4d90 <fwp_heap_alloc_slow>
    4fe4:	7100043f 	cmp	w1, #0x1
    4fe8:	8b150085 	add	x5, x4, x21
    4fec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ff0:	52800001 	mov	w1, #0x0                   	// #0
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	f9000465 	str	x5, [x3, #8]
    4ffc:	17ffffdb 	b	4f68 <fwp_heap_alloc+0x78>
    5000:	97fff80c 	bl	3030 <fwp_heap_oom>

0000000000005004 <fwp_apply>:
    5004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5008:	aa0003e6 	mov	x6, x0
    500c:	910003fd 	mov	x29, sp
    5010:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    5014:	f947f463 	ldr	x3, [x3, #4072]
    5018:	a90153f3 	stp	x19, x20, [sp, #16]
    501c:	aa0203f4 	mov	x20, x2
    5020:	a9025bf5 	stp	x21, x22, [sp, #32]
    5024:	2a0103f5 	mov	w21, w1
    5028:	52800033 	mov	w19, #0x1                   	// #1
    502c:	a90363f7 	stp	x23, x24, [sp, #48]
    5030:	f00000d7 	adrp	x23, 20000 <__data_start>
    5034:	9101c2f7 	add	x23, x23, #0x70
    5038:	a9046bf9 	stp	x25, x26, [sp, #64]
    503c:	d100c3ff 	sub	sp, sp, #0x30
    5040:	f9400060 	ldr	x0, [x3]
    5044:	f81f83a0 	stur	x0, [x29, #-8]
    5048:	d2800000 	mov	x0, #0x0                   	// #0
    504c:	294058c3 	ldp	w3, w22, [x6]
    5050:	910003f8 	mov	x24, sp
    5054:	f94046e0 	ldr	x0, [x23, #136]
    5058:	710002df 	cmp	w22, #0x0
    505c:	d37be863 	lsl	x3, x3, #5
    5060:	8b030007 	add	x7, x0, x3
    5064:	b8636819 	ldr	w25, [x0, x3]
    5068:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    506c:	54000163 	b.cc	5098 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5070:	f94004e3 	ldr	x3, [x7, #8]
    5074:	34000bd9 	cbz	w25, 51ec <fwp_apply+0x1e8>
    5078:	aa1403e0 	mov	x0, x20
    507c:	d63f0060 	blr	x3
    5080:	aa0003e6 	mov	x6, x0
    5084:	6b1902bf 	cmp	w21, w25
    5088:	54000940 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    508c:	8b394e94 	add	x20, x20, w25, uxtw #3
    5090:	4b1902b5 	sub	w21, w21, w25
    5094:	17ffffee 	b	504c <fwp_apply+0x48>
    5098:	0b1602ba 	add	w26, w21, w22
    509c:	6b19035f 	cmp	w26, w25
    50a0:	54000543 	b.cc	5148 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    50a4:	7100033f 	cmp	w25, #0x0
    50a8:	4b16033a 	sub	w26, w25, w22
    50ac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    50b0:	d37df000 	lsl	x0, x0, #3
    50b4:	91003c00 	add	x0, x0, #0xf
    50b8:	92704c01 	and	x1, x0, #0xfffff0000
    50bc:	927c7c00 	and	x0, x0, #0xffffffff0
    50c0:	cb2163e1 	sub	x1, sp, x1
    50c4:	eb2163ff 	cmp	sp, x1
    50c8:	540000a0 	b.eq	50dc <fwp_apply+0xd8>  // b.none
    50cc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    50d0:	f90203ff 	str	xzr, [sp, #1024]
    50d4:	eb2163ff 	cmp	sp, x1
    50d8:	54ffffa1 	b.ne	50cc <fwp_apply+0xc8>  // b.any
    50dc:	92403c00 	and	x0, x0, #0xffff
    50e0:	cb2063ff 	sub	sp, sp, x0
    50e4:	f90003ff 	str	xzr, [sp]
    50e8:	f110001f 	cmp	x0, #0x400
    50ec:	54000962 	b.cs	5218 <fwp_apply+0x214>  // b.hs, b.nlast
    50f0:	910020c6 	add	x6, x6, #0x8
    50f4:	910043e0 	add	x0, sp, #0x10
    50f8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    50fc:	d2800003 	mov	x3, #0x0                   	// #0
    5100:	340000f6 	cbz	w22, 511c <fwp_apply+0x118>
    5104:	d503201f 	nop
    5108:	f86368c4 	ldr	x4, [x6, x3]
    510c:	f8236804 	str	x4, [x0, x3]
    5110:	91002063 	add	x3, x3, #0x8
    5114:	eb0300bf 	cmp	x5, x3
    5118:	54ffff81 	b.ne	5108 <fwp_apply+0x104>  // b.any
    511c:	3400013a 	cbz	w26, 5140 <fwp_apply+0x13c>
    5120:	2a1a03e6 	mov	w6, w26
    5124:	d2800003 	mov	x3, #0x0                   	// #0
    5128:	0b0302c4 	add	w4, w22, w3
    512c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5130:	91000463 	add	x3, x3, #0x1
    5134:	f8247805 	str	x5, [x0, x4, lsl #3]
    5138:	eb0300df 	cmp	x6, x3
    513c:	54ffff61 	b.ne	5128 <fwp_apply+0x124>  // b.any
    5140:	f94004e3 	ldr	x3, [x7, #8]
    5144:	1400002c 	b	51f4 <fwp_apply+0x1f0>
    5148:	11000740 	add	w0, w26, #0x1
    514c:	52800041 	mov	w1, #0x2                   	// #2
    5150:	f81e83a6 	stur	x6, [x29, #-24]
    5154:	d37df000 	lsl	x0, x0, #3
    5158:	97ffff66 	bl	4ef0 <fwp_heap_alloc>
    515c:	f85e83a6 	ldur	x6, [x29, #-24]
    5160:	aa0003f3 	mov	x19, x0
    5164:	b94000c1 	ldr	w1, [x6]
    5168:	29006801 	stp	w1, w26, [x0]
    516c:	340000b6 	cbz	w22, 5180 <fwp_apply+0x17c>
    5170:	910020c1 	add	x1, x6, #0x8
    5174:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5178:	91002000 	add	x0, x0, #0x8
    517c:	97fff55d 	bl	26f0 <memmove@plt>
    5180:	2a1503e3 	mov	w3, w21
    5184:	d2800000 	mov	x0, #0x0                   	// #0
    5188:	34000135 	cbz	w21, 51ac <fwp_apply+0x1a8>
    518c:	d503201f 	nop
    5190:	0b0002c1 	add	w1, w22, w0
    5194:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    5198:	8b010e61 	add	x1, x19, x1, lsl #3
    519c:	91000400 	add	x0, x0, #0x1
    51a0:	f9000422 	str	x2, [x1, #8]
    51a4:	eb00007f 	cmp	x3, x0
    51a8:	54ffff41 	b.ne	5190 <fwp_apply+0x18c>  // b.any
    51ac:	aa1303e6 	mov	x6, x19
    51b0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    51b4:	f947f400 	ldr	x0, [x0, #4072]
    51b8:	f85f83a2 	ldur	x2, [x29, #-8]
    51bc:	f9400001 	ldr	x1, [x0]
    51c0:	eb010042 	subs	x2, x2, x1
    51c4:	d2800001 	mov	x1, #0x0                   	// #0
    51c8:	540002c1 	b.ne	5220 <fwp_apply+0x21c>  // b.any
    51cc:	910003bf 	mov	sp, x29
    51d0:	aa0603e0 	mov	x0, x6
    51d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    51e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    51e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    51e8:	d65f03c0 	ret
    51ec:	d10043a0 	sub	x0, x29, #0x10
    51f0:	5280001a 	mov	w26, #0x0                   	// #0
    51f4:	d63f0060 	blr	x3
    51f8:	aa0003e6 	mov	x6, x0
    51fc:	6b1a02bf 	cmp	w21, w26
    5200:	54fffd80 	b.eq	51b0 <fwp_apply+0x1ac>  // b.none
    5204:	0b1602b6 	add	w22, w21, w22
    5208:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    520c:	4b1902d5 	sub	w21, w22, w25
    5210:	9100031f 	mov	sp, x24
    5214:	17ffff8e 	b	504c <fwp_apply+0x48>
    5218:	f90203ff 	str	xzr, [sp, #1024]
    521c:	17ffffb5 	b	50f0 <fwp_apply+0xec>
    5220:	97fff598 	bl	2880 <__stack_chk_fail@plt>

0000000000005224 <fwp_p_ad_push.constprop.0>:
    5224:	f100001f 	cmp	x0, #0x0
    5228:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    522c:	54000e8b 	b.lt	53fc <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    5230:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5234:	aa0003e4 	mov	x4, x0
    5238:	910003fd 	mov	x29, sp
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	aa0003f5 	mov	x21, x0
    5244:	aa020000 	orr	x0, x0, x2
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	aa0203f7 	mov	x23, x2
    5250:	6d0627e8 	stp	d8, d9, [sp, #96]
    5254:	9e670029 	fmov	d9, x1
    5258:	9e670068 	fmov	d8, x3
    525c:	b6f80900 	tbz	x0, #63, 537c <fwp_p_ad_push.constprop.0+0x158>
    5260:	a90153f3 	stp	x19, x20, [sp, #16]
    5264:	9360fc80 	asr	x0, x4, #32
    5268:	b6f800c4 	tbz	x4, #63, 5280 <fwp_p_ad_push.constprop.0+0x5c>
    526c:	1e604109 	fmov	d9, d8
    5270:	2f00e408 	movi	d8, #0x0
    5274:	9360fc40 	asr	x0, x2, #32
    5278:	aa0203f5 	mov	x21, x2
    527c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5280:	97fffa2c 	bl	3b30 <fwp_tape_of>
    5284:	aa0003f3 	mov	x19, x0
    5288:	f9403000 	ldr	x0, [x0, #96]
    528c:	b5001280 	cbnz	x0, 54dc <fwp_p_ad_push.constprop.0+0x2b8>
    5290:	f9400a76 	ldr	x22, [x19, #16]
    5294:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5298:	eb0002df 	cmp	x22, x0
    529c:	54000e2c 	b.gt	5460 <fwp_p_ad_push.constprop.0+0x23c>
    52a0:	eb3542df 	cmp	x22, w21, uxtw
    52a4:	54000d4d 	b.le	544c <fwp_p_ad_push.constprop.0+0x228>
    52a8:	b7f80077 	tbnz	x23, #63, 52b4 <fwp_p_ad_push.constprop.0+0x90>
    52ac:	eb3742df 	cmp	x22, w23, uxtw
    52b0:	54000ced 	b.le	544c <fwp_p_ad_push.constprop.0+0x228>
    52b4:	f9400678 	ldr	x24, [x19, #8]
    52b8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52bc:	cb1802d8 	sub	x24, x22, x24
    52c0:	91000701 	add	x1, x24, #0x1
    52c4:	eb00003f 	cmp	x1, x0
    52c8:	54000cc8 	b.hi	5460 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    52cc:	a9418274 	ldp	x20, x0, [x19, #24]
    52d0:	a90573fb 	stp	x27, x28, [sp, #80]
    52d4:	eb14003f 	cmp	x1, x20
    52d8:	5400068d 	b.le	53a8 <fwp_p_ad_push.constprop.0+0x184>
    52dc:	f100029f 	cmp	x20, #0x0
    52e0:	d2800803 	mov	x3, #0x40                  	// #64
    52e4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    52e8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    52ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    52f0:	eb14003f 	cmp	x1, x20
    52f4:	5400008d 	b.le	5304 <fwp_p_ad_push.constprop.0+0xe0>
    52f8:	eb02029f 	cmp	x20, x2
    52fc:	5400052d 	b.le	53a0 <fwp_p_ad_push.constprop.0+0x17c>
    5300:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5304:	d37df299 	lsl	x25, x20, #3
    5308:	aa1903e1 	mov	x1, x25
    530c:	97fff559 	bl	2870 <realloc@plt>
    5310:	aa0003e1 	mov	x1, x0
    5314:	b4000b00 	cbz	x0, 5474 <fwp_p_ad_push.constprop.0+0x250>
    5318:	f9400e62 	ldr	x2, [x19, #24]
    531c:	f9001261 	str	x1, [x19, #32]
    5320:	f9401a60 	ldr	x0, [x19, #48]
    5324:	d37cee9a 	lsl	x26, x20, #4
    5328:	8b020821 	add	x1, x1, x2, lsl #2
    532c:	f9001661 	str	x1, [x19, #40]
    5330:	aa1a03e1 	mov	x1, x26
    5334:	97fff54f 	bl	2870 <realloc@plt>
    5338:	aa0003e2 	mov	x2, x0
    533c:	b40009c0 	cbz	x0, 5474 <fwp_p_ad_push.constprop.0+0x250>
    5340:	f9400e61 	ldr	x1, [x19, #24]
    5344:	d37df31b 	lsl	x27, x24, #3
    5348:	d37ef685 	lsl	x5, x20, #2
    534c:	d37ef71c 	lsl	x28, x24, #2
    5350:	8b190004 	add	x4, x0, x25
    5354:	8b010c01 	add	x1, x0, x1, lsl #3
    5358:	a9030660 	stp	x0, x1, [x19, #48]
    535c:	b5000558 	cbnz	x24, 5404 <fwp_p_ad_push.constprop.0+0x1e0>
    5360:	f9001e64 	str	x4, [x19, #56]
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	a9446bf9 	ldp	x25, x26, [sp, #64]
    536c:	8b050001 	add	x1, x0, x5
    5370:	f9000e74 	str	x20, [x19, #24]
    5374:	f9001661 	str	x1, [x19, #40]
    5378:	14000010 	b	53b8 <fwp_p_ad_push.constprop.0+0x194>
    537c:	9360fc40 	asr	x0, x2, #32
    5380:	a90153f3 	stp	x19, x20, [sp, #16]
    5384:	eb84801f 	cmp	x0, x4, asr #32
    5388:	54fff7c0 	b.eq	5280 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    538c:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5390:	91252000 	add	x0, x0, #0x948
    5394:	a9046bf9 	stp	x25, x26, [sp, #64]
    5398:	a90573fb 	stp	x27, x28, [sp, #80]
    539c:	97fff919 	bl	3800 <fwp_trap>
    53a0:	d37ffa94 	lsl	x20, x20, #1
    53a4:	17ffffd3 	b	52f0 <fwp_p_ad_push.constprop.0+0xcc>
    53a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    53ac:	d37ef71c 	lsl	x28, x24, #2
    53b0:	f9401e64 	ldr	x4, [x19, #56]
    53b4:	d37df31b 	lsl	x27, x24, #3
    53b8:	b83c6815 	str	w21, [x0, x28]
    53bc:	f10002ff 	cmp	x23, #0x0
    53c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    53c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    53c8:	fc3b6849 	str	d9, [x2, x27]
    53cc:	aa1602a0 	orr	x0, x21, x22
    53d0:	b83c6837 	str	w23, [x1, x28]
    53d4:	910006d6 	add	x22, x22, #0x1
    53d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    53dc:	fc3b6888 	str	d8, [x4, x27]
    53e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    53e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    53e8:	f9000a76 	str	x22, [x19, #16]
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    53f8:	d65f03c0 	ret
    53fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5400:	d65f03c0 	ret
    5404:	eb1a033f 	cmp	x25, x26
    5408:	aa0403e0 	mov	x0, x4
    540c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5410:	aa1b03e2 	mov	x2, x27
    5414:	cb190063 	sub	x3, x3, x25
    5418:	f9003fe5 	str	x5, [sp, #120]
    541c:	97fff581 	bl	2a20 <__memmove_chk@plt>
    5420:	a9420660 	ldp	x0, x1, [x19, #32]
    5424:	aa1c03e2 	mov	x2, x28
    5428:	f9401a63 	ldr	x3, [x19, #48]
    542c:	f9403fe5 	ldr	x5, [sp, #120]
    5430:	8b190063 	add	x3, x3, x25
    5434:	f9001e63 	str	x3, [x19, #56]
    5438:	8b050000 	add	x0, x0, x5
    543c:	97fff4ad 	bl	26f0 <memmove@plt>
    5440:	a9431262 	ldp	x2, x4, [x19, #48]
    5444:	f9403fe5 	ldr	x5, [sp, #120]
    5448:	17ffffc7 	b	5364 <fwp_p_ad_push.constprop.0+0x140>
    544c:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5450:	91278000 	add	x0, x0, #0x9e0
    5454:	a9046bf9 	stp	x25, x26, [sp, #64]
    5458:	a90573fb 	stp	x27, x28, [sp, #80]
    545c:	97fff8e9 	bl	3800 <fwp_trap>
    5460:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5464:	91270000 	add	x0, x0, #0x9c0
    5468:	a9046bf9 	stp	x25, x26, [sp, #64]
    546c:	a90573fb 	stp	x27, x28, [sp, #80]
    5470:	97fff8e4 	bl	3800 <fwp_trap>
    5474:	aa1303e0 	mov	x0, x19
    5478:	97fff6c6 	bl	2f90 <fwp_tape_unlink_scope>
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	97fff530 	bl	2940 <free@plt>
    5484:	f9401a60 	ldr	x0, [x19, #48]
    5488:	97fff52e 	bl	2940 <free@plt>
    548c:	f9402260 	ldr	x0, [x19, #64]
    5490:	97fff52c 	bl	2940 <free@plt>
    5494:	f9000e7f 	str	xzr, [x19, #24]
    5498:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    549c:	f947e821 	ldr	x1, [x1, #4048]
    54a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54a4:	d2800262 	mov	x2, #0x13                  	// #19
    54a8:	4f000400 	movi	v0.4s, #0x0
    54ac:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    54b0:	f9400023 	ldr	x3, [x1]
    54b4:	b900067f 	str	wzr, [x19, #4]
    54b8:	d2800021 	mov	x1, #0x1                   	// #1
    54bc:	9116a000 	add	x0, x0, #0x5a8
    54c0:	3c808260 	stur	q0, [x19, #8]
    54c4:	ad010260 	stp	q0, q0, [x19, #32]
    54c8:	97fff52e 	bl	2980 <fwrite@plt>
    54cc:	d2800000 	mov	x0, #0x0                   	// #0
    54d0:	97fff538 	bl	29b0 <fflush@plt>
    54d4:	52800cc0 	mov	w0, #0x66                  	// #102
    54d8:	97fff546 	bl	29f0 <_Exit@plt>
    54dc:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    54e0:	91264000 	add	x0, x0, #0x990
    54e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54e8:	a90573fb 	stp	x27, x28, [sp, #80]
    54ec:	97fff8c5 	bl	3800 <fwp_trap>

00000000000054f0 <w107>:
    54f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    54f4:	9e660003 	fmov	x3, d0
    54f8:	aa0003e2 	mov	x2, x0
    54fc:	910003fd 	mov	x29, sp
    5500:	6d0327e8 	stp	d8, d9, [sp, #48]
    5504:	1e604028 	fmov	d8, d1
    5508:	1e600809 	fmul	d9, d0, d0
    550c:	fd0023ea 	str	d10, [sp, #64]
    5510:	1e60400a 	fmov	d10, d0
    5514:	a90153f3 	stp	x19, x20, [sp, #16]
    5518:	aa0003f3 	mov	x19, x0
    551c:	aa0103f4 	mov	x20, x1
    5520:	aa0303e1 	mov	x1, x3
    5524:	a9025bf5 	stp	x21, x22, [sp, #32]
    5528:	97ffff3f 	bl	5224 <fwp_p_ad_push.constprop.0>
    552c:	1e693908 	fsub	d8, d8, d9
    5530:	aa1403e2 	mov	x2, x20
    5534:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5538:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    553c:	9e660116 	fmov	x22, d8
    5540:	97ffff39 	bl	5224 <fwp_p_ad_push.constprop.0>
    5544:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5548:	aa0003e1 	mov	x1, x0
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa1303e0 	mov	x0, x19
    5554:	1e6a3929 	fsub	d9, d9, d10
    5558:	aa0103f3 	mov	x19, x1
    555c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5560:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5564:	9e660135 	fmov	x21, d9
    5568:	97ffff2f 	bl	5224 <fwp_p_ad_push.constprop.0>
    556c:	1e680908 	fmul	d8, d8, d8
    5570:	aa0003f4 	mov	x20, x0
    5574:	aa1603e3 	mov	x3, x22
    5578:	aa1603e1 	mov	x1, x22
    557c:	aa1303e2 	mov	x2, x19
    5580:	aa1303e0 	mov	x0, x19
    5584:	97ffff28 	bl	5224 <fwp_p_ad_push.constprop.0>
    5588:	aa0003e2 	mov	x2, x0
    558c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5590:	9e670020 	fmov	d0, x1
    5594:	9e660101 	fmov	x1, d8
    5598:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    559c:	1e600908 	fmul	d8, d8, d0
    55a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55a4:	97ffff20 	bl	5224 <fwp_p_ad_push.constprop.0>
    55a8:	1e690929 	fmul	d9, d9, d9
    55ac:	aa0003f3 	mov	x19, x0
    55b0:	aa1503e3 	mov	x3, x21
    55b4:	aa1503e1 	mov	x1, x21
    55b8:	aa1403e2 	mov	x2, x20
    55bc:	aa1403e0 	mov	x0, x20
    55c0:	97ffff19 	bl	5224 <fwp_p_ad_push.constprop.0>
    55c4:	1e692908 	fadd	d8, d8, d9
    55c8:	aa1303e2 	mov	x2, x19
    55cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55d0:	aa0303e1 	mov	x1, x3
    55d4:	97ffff14 	bl	5224 <fwp_p_ad_push.constprop.0>
    55d8:	aa0003e1 	mov	x1, x0
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	9e660100 	fmov	x0, d8
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    55ec:	fd4023ea 	ldr	d10, [sp, #64]
    55f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    55f4:	d65f03c0 	ret
    55f8:	d503201f 	nop
    55fc:	d503201f 	nop

0000000000005600 <w164.constprop.0>:
    5600:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5604:	910003fd 	mov	x29, sp
    5608:	a9025bf5 	stp	x21, x22, [sp, #32]
    560c:	fd001be8 	str	d8, [sp, #48]
    5610:	f9400015 	ldr	x21, [x0]
    5614:	b4000315 	cbz	x21, 5674 <w164.constprop.0+0x74>
    5618:	2f00e408 	movi	d8, #0x0
    561c:	91002016 	add	x22, x0, #0x8
    5620:	a90153f3 	stp	x19, x20, [sp, #16]
    5624:	91004014 	add	x20, x0, #0x10
    5628:	d2800013 	mov	x19, #0x0                   	// #0
    562c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5630:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5634:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5638:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    563c:	aa0303e1 	mov	x1, x3
    5640:	1e602908 	fadd	d8, d8, d0
    5644:	91000a73 	add	x19, x19, #0x2
    5648:	97fffef7 	bl	5224 <fwp_p_ad_push.constprop.0>
    564c:	eb1302bf 	cmp	x21, x19
    5650:	54ffff08 	b.hi	5630 <w164.constprop.0+0x30>  // b.pmore
    5654:	9e660102 	fmov	x2, d8
    5658:	fd401be8 	ldr	d8, [sp, #48]
    565c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5660:	aa0003e1 	mov	x1, x0
    5664:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5668:	aa0203e0 	mov	x0, x2
    566c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5670:	d65f03c0 	ret
    5674:	2f00e408 	movi	d8, #0x0
    5678:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    567c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5680:	aa0003e1 	mov	x1, x0
    5684:	9e660102 	fmov	x2, d8
    5688:	fd401be8 	ldr	d8, [sp, #48]
    568c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5690:	aa0203e0 	mov	x0, x2
    5694:	d65f03c0 	ret
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <fwp_data.part.0.constprop.0>:
    56a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56a4:	910003fd 	mov	x29, sp
    56a8:	a90153f3 	stp	x19, x20, [sp, #16]
    56ac:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    56b0:	91174283 	add	x3, x20, #0x5d0
    56b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56b8:	aa0103f5 	mov	x21, x1
    56bc:	b953a461 	ldr	w1, [x3, #5028]
    56c0:	a90363f7 	stp	x23, x24, [sp, #48]
    56c4:	2a0003f8 	mov	w24, w0
    56c8:	34000701 	cbz	w1, 57a8 <fwp_data.part.0.constprop.0+0x108>
    56cc:	397e8862 	ldrb	w2, [x3, #4002]
    56d0:	910f0040 	add	x0, x2, #0x3c0
    56d4:	8b020442 	add	x2, x2, x2, lsl #1
    56d8:	d37df042 	lsl	x2, x2, #3
    56dc:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    56e0:	2a1703f6 	mov	w22, w23
    56e4:	f8626873 	ldr	x19, [x3, x2]
    56e8:	b40004d3 	cbz	x19, 5780 <fwp_data.part.0.constprop.0+0xe0>
    56ec:	f9400260 	ldr	x0, [x19]
    56f0:	aa2003e0 	mvn	x0, x0
    56f4:	f8226860 	str	x0, [x3, x2]
    56f8:	f10062df 	cmp	x22, #0x18
    56fc:	540000e9 	b.ls	5718 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5700:	d10066c2 	sub	x2, x22, #0x19
    5704:	91006260 	add	x0, x19, #0x18
    5708:	927df042 	and	x2, x2, #0xfffffffffffffff8
    570c:	52800001 	mov	w1, #0x0                   	// #0
    5710:	91002042 	add	x2, x2, #0x8
    5714:	97fff44f 	bl	2850 <memset@plt>
    5718:	91174282 	add	x2, x20, #0x5d0
    571c:	f94a1041 	ldr	x1, [x2, #5152]
    5720:	ab160021 	adds	x1, x1, x22
    5724:	540004c2 	b.cs	57bc <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5728:	f94a1440 	ldr	x0, [x2, #5160]
    572c:	f90a1041 	str	x1, [x2, #5152]
    5730:	eb00003f 	cmp	x1, x0
    5734:	54000049 	b.ls	573c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5738:	f90a1441 	str	x1, [x2, #5160]
    573c:	91174294 	add	x20, x20, #0x5d0
    5740:	1e6302e1 	ucvtf	d1, w23
    5744:	fd4a1e80 	ldr	d0, [x20, #5176]
    5748:	1e612800 	fadd	d0, d0, d1
    574c:	fd0a1e80 	str	d0, [x20, #5176]
    5750:	52800041 	mov	w1, #0x2                   	// #2
    5754:	29000678 	stp	w24, w1, [x19]
    5758:	aa1303e0 	mov	x0, x19
    575c:	f94002a1 	ldr	x1, [x21]
    5760:	f9000661 	str	x1, [x19, #8]
    5764:	f94006a1 	ldr	x1, [x21, #8]
    5768:	f9000a61 	str	x1, [x19, #16]
    576c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5770:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5774:	a94363f7 	ldp	x23, x24, [sp, #48]
    5778:	a8c47bfd 	ldp	x29, x30, [sp], #64
    577c:	d65f03c0 	ret
    5780:	8b020063 	add	x3, x3, x2
    5784:	f9400473 	ldr	x19, [x3, #8]
    5788:	b4000113 	cbz	x19, 57a8 <fwp_data.part.0.constprop.0+0x108>
    578c:	f9400860 	ldr	x0, [x3, #16]
    5790:	cb130000 	sub	x0, x0, x19
    5794:	eb0002df 	cmp	x22, x0
    5798:	54000088 	b.hi	57a8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    579c:	8b160260 	add	x0, x19, x22
    57a0:	f9000460 	str	x0, [x3, #8]
    57a4:	17ffffd5 	b	56f8 <fwp_data.part.0.constprop.0+0x58>
    57a8:	52800001 	mov	w1, #0x0                   	// #0
    57ac:	d2800300 	mov	x0, #0x18                  	// #24
    57b0:	97fffdd0 	bl	4ef0 <fwp_heap_alloc>
    57b4:	aa0003f3 	mov	x19, x0
    57b8:	17ffffe6 	b	5750 <fwp_data.part.0.constprop.0+0xb0>
    57bc:	97fff61d 	bl	3030 <fwp_heap_oom>

00000000000057c0 <fwp_rc_share>:
    57c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    57c4:	91174042 	add	x2, x2, #0x5d0
    57c8:	f949d843 	ldr	x3, [x2, #5040]
    57cc:	f949ec41 	ldr	x1, [x2, #5080]
    57d0:	cb030000 	sub	x0, x0, x3
    57d4:	eb01401f 	cmp	x0, x1, lsl #16
    57d8:	540002c2 	b.cs	5830 <fwp_rc_share+0x70>  // b.hs, b.nlast
    57dc:	d350fc01 	lsr	x1, x0, #16
    57e0:	f949fc44 	ldr	x4, [x2, #5112]
    57e4:	8b010821 	add	x1, x1, x1, lsl #2
    57e8:	d37df021 	lsl	x1, x1, #3
    57ec:	8b010083 	add	x3, x4, x1
    57f0:	f9401062 	ldr	x2, [x3, #32]
    57f4:	b40001e2 	cbz	x2, 5830 <fwp_rc_share+0x70>
    57f8:	38616881 	ldrb	w1, [x4, x1]
    57fc:	7100083f 	cmp	w1, #0x2
    5800:	540001a0 	b.eq	5834 <fwp_rc_share+0x74>  // b.none
    5804:	7100043f 	cmp	w1, #0x1
    5808:	54000141 	b.ne	5830 <fwp_rc_share+0x70>  // b.any
    580c:	29430464 	ldp	w4, w1, [x3, #24]
    5810:	92403c00 	and	x0, x0, #0xffff
    5814:	9b047c00 	mul	x0, x0, x4
    5818:	d360fc00 	lsr	x0, x0, #32
    581c:	eb01001f 	cmp	x0, x1
    5820:	54000082 	b.cs	5830 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5824:	8b000042 	add	x2, x2, x0
    5828:	39400040 	ldrb	w0, [x2]
    582c:	350000a0 	cbnz	w0, 5840 <fwp_rc_share+0x80>
    5830:	d65f03c0 	ret
    5834:	72003c1f 	tst	w0, #0xffff
    5838:	54ffff80 	b.eq	5828 <fwp_rc_share+0x68>  // b.none
    583c:	d65f03c0 	ret
    5840:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5844:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5848:	91280000 	add	x0, x0, #0xa00
    584c:	910003fd 	mov	x29, sp
    5850:	97fff7ec 	bl	3800 <fwp_trap>

0000000000005854 <fwp_rc_free_arr>:
    5854:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5858:	91174063 	add	x3, x3, #0x5d0
    585c:	f949d861 	ldr	x1, [x3, #5040]
    5860:	f949ec62 	ldr	x2, [x3, #5080]
    5864:	cb010001 	sub	x1, x0, x1
    5868:	eb02403f 	cmp	x1, x2, lsl #16
    586c:	54000342 	b.cs	58d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5870:	d350fc22 	lsr	x2, x1, #16
    5874:	f949fc65 	ldr	x5, [x3, #5112]
    5878:	8b020842 	add	x2, x2, x2, lsl #2
    587c:	d37df042 	lsl	x2, x2, #3
    5880:	8b0200a4 	add	x4, x5, x2
    5884:	f9401083 	ldr	x3, [x4, #32]
    5888:	b4000263 	cbz	x3, 58d4 <fwp_rc_free_arr+0x80>
    588c:	386268a2 	ldrb	w2, [x5, x2]
    5890:	7100085f 	cmp	w2, #0x2
    5894:	540001c0 	b.eq	58cc <fwp_rc_free_arr+0x78>  // b.none
    5898:	7100045f 	cmp	w2, #0x1
    589c:	540001c1 	b.ne	58d4 <fwp_rc_free_arr+0x80>  // b.any
    58a0:	29430885 	ldp	w5, w2, [x4, #24]
    58a4:	92403c21 	and	x1, x1, #0xffff
    58a8:	9b057c21 	mul	x1, x1, x5
    58ac:	d360fc21 	lsr	x1, x1, #32
    58b0:	eb02003f 	cmp	x1, x2
    58b4:	54000102 	b.cs	58d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58b8:	8b010063 	add	x3, x3, x1
    58bc:	39400061 	ldrb	w1, [x3]
    58c0:	7100043f 	cmp	w1, #0x1
    58c4:	54000081 	b.ne	58d4 <fwp_rc_free_arr+0x80>  // b.any
    58c8:	17fffc6a 	b	4a70 <fwp_mem_free>
    58cc:	72003c3f 	tst	w1, #0xffff
    58d0:	54ffff60 	b.eq	58bc <fwp_rc_free_arr+0x68>  // b.none
    58d4:	d65f03c0 	ret
    58d8:	d503201f 	nop
    58dc:	d503201f 	nop

00000000000058e0 <fwp_rc_dup>:
    58e0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    58e4:	91174042 	add	x2, x2, #0x5d0
    58e8:	f949d841 	ldr	x1, [x2, #5040]
    58ec:	f949ec43 	ldr	x3, [x2, #5080]
    58f0:	cb010001 	sub	x1, x0, x1
    58f4:	eb03403f 	cmp	x1, x3, lsl #16
    58f8:	54000342 	b.cs	5960 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58fc:	d350fc20 	lsr	x0, x1, #16
    5900:	f949fc44 	ldr	x4, [x2, #5112]
    5904:	8b000800 	add	x0, x0, x0, lsl #2
    5908:	d37df002 	lsl	x2, x0, #3
    590c:	8b020083 	add	x3, x4, x2
    5910:	f9401060 	ldr	x0, [x3, #32]
    5914:	b4000260 	cbz	x0, 5960 <fwp_rc_dup+0x80>
    5918:	38626882 	ldrb	w2, [x4, x2]
    591c:	7100085f 	cmp	w2, #0x2
    5920:	54000220 	b.eq	5964 <fwp_rc_dup+0x84>  // b.none
    5924:	7100045f 	cmp	w2, #0x1
    5928:	540001c1 	b.ne	5960 <fwp_rc_dup+0x80>  // b.any
    592c:	29430864 	ldp	w4, w2, [x3, #24]
    5930:	92403c21 	and	x1, x1, #0xffff
    5934:	9b047c21 	mul	x1, x1, x4
    5938:	d360fc21 	lsr	x1, x1, #32
    593c:	eb02003f 	cmp	x1, x2
    5940:	54000102 	b.cs	5960 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5944:	8b010000 	add	x0, x0, x1
    5948:	39400001 	ldrb	w1, [x0]
    594c:	340000a1 	cbz	w1, 5960 <fwp_rc_dup+0x80>
    5950:	7103f43f 	cmp	w1, #0xfd
    5954:	540000e8 	b.hi	5970 <fwp_rc_dup+0x90>  // b.pmore
    5958:	11000421 	add	w1, w1, #0x1
    595c:	39000001 	strb	w1, [x0]
    5960:	d65f03c0 	ret
    5964:	72003c3f 	tst	w1, #0xffff
    5968:	54ffff00 	b.eq	5948 <fwp_rc_dup+0x68>  // b.none
    596c:	d65f03c0 	ret
    5970:	17fffb59 	b	46d4 <fwp_rc_wide_dup>

0000000000005974 <fwp_drop0>:
    5974:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5978:	910003fd 	mov	x29, sp
    597c:	a90153f3 	stp	x19, x20, [sp, #16]
    5980:	f90013f5 	str	x21, [sp, #32]
    5984:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5988:	911742b4 	add	x20, x21, #0x5d0
    598c:	f949da81 	ldr	x1, [x20, #5040]
    5990:	f949ee82 	ldr	x2, [x20, #5080]
    5994:	cb010001 	sub	x1, x0, x1
    5998:	eb02403f 	cmp	x1, x2, lsl #16
    599c:	54000382 	b.cs	5a0c <fwp_drop0+0x98>  // b.hs, b.nlast
    59a0:	d350fc22 	lsr	x2, x1, #16
    59a4:	f949fe84 	ldr	x4, [x20, #5112]
    59a8:	8b020842 	add	x2, x2, x2, lsl #2
    59ac:	d37df042 	lsl	x2, x2, #3
    59b0:	8b020083 	add	x3, x4, x2
    59b4:	f9401073 	ldr	x19, [x3, #32]
    59b8:	b40002b3 	cbz	x19, 5a0c <fwp_drop0+0x98>
    59bc:	38626882 	ldrb	w2, [x4, x2]
    59c0:	7100085f 	cmp	w2, #0x2
    59c4:	540002c0 	b.eq	5a1c <fwp_drop0+0xa8>  // b.none
    59c8:	7100045f 	cmp	w2, #0x1
    59cc:	54000201 	b.ne	5a0c <fwp_drop0+0x98>  // b.any
    59d0:	29430864 	ldp	w4, w2, [x3, #24]
    59d4:	92403c21 	and	x1, x1, #0xffff
    59d8:	9b047c21 	mul	x1, x1, x4
    59dc:	d360fc21 	lsr	x1, x1, #32
    59e0:	eb02003f 	cmp	x1, x2
    59e4:	54000142 	b.cs	5a0c <fwp_drop0+0x98>  // b.hs, b.nlast
    59e8:	8b010273 	add	x19, x19, x1
    59ec:	39400261 	ldrb	w1, [x19]
    59f0:	340000e1 	cbz	w1, 5a0c <fwp_drop0+0x98>
    59f4:	7100043f 	cmp	w1, #0x1
    59f8:	540001e0 	b.eq	5a34 <fwp_drop0+0xc0>  // b.none
    59fc:	7103fc3f 	cmp	w1, #0xff
    5a00:	540002e0 	b.eq	5a5c <fwp_drop0+0xe8>  // b.none
    5a04:	51000421 	sub	w1, w1, #0x1
    5a08:	39000261 	strb	w1, [x19]
    5a0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a10:	f94013f5 	ldr	x21, [sp, #32]
    5a14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a18:	d65f03c0 	ret
    5a1c:	72003c3f 	tst	w1, #0xffff
    5a20:	54fffe60 	b.eq	59ec <fwp_drop0+0x78>  // b.none
    5a24:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a28:	f94013f5 	ldr	x21, [sp, #32]
    5a2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a30:	d65f03c0 	ret
    5a34:	f9400813 	ldr	x19, [x0, #16]
    5a38:	97ffff87 	bl	5854 <fwp_rc_free_arr>
    5a3c:	911742a0 	add	x0, x21, #0x5d0
    5a40:	f949d801 	ldr	x1, [x0, #5040]
    5a44:	f949ec00 	ldr	x0, [x0, #5080]
    5a48:	cb010261 	sub	x1, x19, x1
    5a4c:	eb00403f 	cmp	x1, x0, lsl #16
    5a50:	54fffde2 	b.cs	5a0c <fwp_drop0+0x98>  // b.hs, b.nlast
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	17ffffd2 	b	59a0 <fwp_drop0+0x2c>
    5a5c:	ca534660 	eor	x0, x19, x19, lsr #17
    5a60:	911742b5 	add	x21, x21, #0x5d0
    5a64:	ca402400 	eor	x0, x0, x0, lsr #9
    5a68:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a6c:	f94a2400 	ldr	x0, [x0, #5192]
    5a70:	b5000080 	cbnz	x0, 5a80 <fwp_drop0+0x10c>
    5a74:	14000010 	b	5ab4 <fwp_drop0+0x140>
    5a78:	f9400800 	ldr	x0, [x0, #16]
    5a7c:	b40001c0 	cbz	x0, 5ab4 <fwp_drop0+0x140>
    5a80:	f9400001 	ldr	x1, [x0]
    5a84:	eb13003f 	cmp	x1, x19
    5a88:	54ffff81 	b.ne	5a78 <fwp_drop0+0x104>  // b.any
    5a8c:	f9400401 	ldr	x1, [x0, #8]
    5a90:	d1000421 	sub	x1, x1, #0x1
    5a94:	f9000401 	str	x1, [x0, #8]
    5a98:	f103f83f 	cmp	x1, #0xfe
    5a9c:	54fffb81 	b.ne	5a0c <fwp_drop0+0x98>  // b.any
    5aa0:	aa1303e0 	mov	x0, x19
    5aa4:	97fffb53 	bl	47f0 <fwp_rc_forget_slot>
    5aa8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5aac:	39000260 	strb	w0, [x19]
    5ab0:	17ffffd7 	b	5a0c <fwp_drop0+0x98>
    5ab4:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5ab8:	91240000 	add	x0, x0, #0x900
    5abc:	97fff751 	bl	3800 <fwp_trap>

0000000000005ac0 <fwp_arg_drop12>:
    5ac0:	7100003f 	cmp	w1, #0x0
    5ac4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5ac8:	54000041 	b.ne	5ad0 <fwp_arg_drop12+0x10>  // b.any
    5acc:	d65f03c0 	ret
    5ad0:	f9400000 	ldr	x0, [x0]
    5ad4:	17ffffa8 	b	5974 <fwp_drop0>
    5ad8:	d503201f 	nop
    5adc:	d503201f 	nop

0000000000005ae0 <fwp_drop1>:
    5ae0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ae4:	910003fd 	mov	x29, sp
    5ae8:	a90153f3 	stp	x19, x20, [sp, #16]
    5aec:	f90013f5 	str	x21, [sp, #32]
    5af0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5af4:	911742b4 	add	x20, x21, #0x5d0
    5af8:	f949da81 	ldr	x1, [x20, #5040]
    5afc:	f949ee82 	ldr	x2, [x20, #5080]
    5b00:	cb010001 	sub	x1, x0, x1
    5b04:	eb02403f 	cmp	x1, x2, lsl #16
    5b08:	54000382 	b.cs	5b78 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b0c:	d350fc22 	lsr	x2, x1, #16
    5b10:	f949fe84 	ldr	x4, [x20, #5112]
    5b14:	8b020842 	add	x2, x2, x2, lsl #2
    5b18:	d37df042 	lsl	x2, x2, #3
    5b1c:	8b020083 	add	x3, x4, x2
    5b20:	f9401073 	ldr	x19, [x3, #32]
    5b24:	b40002b3 	cbz	x19, 5b78 <fwp_drop1+0x98>
    5b28:	38626882 	ldrb	w2, [x4, x2]
    5b2c:	7100085f 	cmp	w2, #0x2
    5b30:	540002c0 	b.eq	5b88 <fwp_drop1+0xa8>  // b.none
    5b34:	7100045f 	cmp	w2, #0x1
    5b38:	54000201 	b.ne	5b78 <fwp_drop1+0x98>  // b.any
    5b3c:	29430864 	ldp	w4, w2, [x3, #24]
    5b40:	92403c21 	and	x1, x1, #0xffff
    5b44:	9b047c21 	mul	x1, x1, x4
    5b48:	d360fc21 	lsr	x1, x1, #32
    5b4c:	eb02003f 	cmp	x1, x2
    5b50:	54000142 	b.cs	5b78 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b54:	8b010273 	add	x19, x19, x1
    5b58:	39400261 	ldrb	w1, [x19]
    5b5c:	340000e1 	cbz	w1, 5b78 <fwp_drop1+0x98>
    5b60:	7100043f 	cmp	w1, #0x1
    5b64:	540001e0 	b.eq	5ba0 <fwp_drop1+0xc0>  // b.none
    5b68:	7103fc3f 	cmp	w1, #0xff
    5b6c:	540002e0 	b.eq	5bc8 <fwp_drop1+0xe8>  // b.none
    5b70:	51000421 	sub	w1, w1, #0x1
    5b74:	39000261 	strb	w1, [x19]
    5b78:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b7c:	f94013f5 	ldr	x21, [sp, #32]
    5b80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b84:	d65f03c0 	ret
    5b88:	72003c3f 	tst	w1, #0xffff
    5b8c:	54fffe60 	b.eq	5b58 <fwp_drop1+0x78>  // b.none
    5b90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b94:	f94013f5 	ldr	x21, [sp, #32]
    5b98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b9c:	d65f03c0 	ret
    5ba0:	f9400813 	ldr	x19, [x0, #16]
    5ba4:	97ffff2c 	bl	5854 <fwp_rc_free_arr>
    5ba8:	911742a0 	add	x0, x21, #0x5d0
    5bac:	f949d801 	ldr	x1, [x0, #5040]
    5bb0:	f949ec00 	ldr	x0, [x0, #5080]
    5bb4:	cb010261 	sub	x1, x19, x1
    5bb8:	eb00403f 	cmp	x1, x0, lsl #16
    5bbc:	54fffde2 	b.cs	5b78 <fwp_drop1+0x98>  // b.hs, b.nlast
    5bc0:	aa1303e0 	mov	x0, x19
    5bc4:	17ffffd2 	b	5b0c <fwp_drop1+0x2c>
    5bc8:	ca534660 	eor	x0, x19, x19, lsr #17
    5bcc:	911742b5 	add	x21, x21, #0x5d0
    5bd0:	ca402400 	eor	x0, x0, x0, lsr #9
    5bd4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5bd8:	f94a2400 	ldr	x0, [x0, #5192]
    5bdc:	b5000080 	cbnz	x0, 5bec <fwp_drop1+0x10c>
    5be0:	14000010 	b	5c20 <fwp_drop1+0x140>
    5be4:	f9400800 	ldr	x0, [x0, #16]
    5be8:	b40001c0 	cbz	x0, 5c20 <fwp_drop1+0x140>
    5bec:	f9400001 	ldr	x1, [x0]
    5bf0:	eb13003f 	cmp	x1, x19
    5bf4:	54ffff81 	b.ne	5be4 <fwp_drop1+0x104>  // b.any
    5bf8:	f9400401 	ldr	x1, [x0, #8]
    5bfc:	d1000421 	sub	x1, x1, #0x1
    5c00:	f9000401 	str	x1, [x0, #8]
    5c04:	f103f83f 	cmp	x1, #0xfe
    5c08:	54fffb81 	b.ne	5b78 <fwp_drop1+0x98>  // b.any
    5c0c:	aa1303e0 	mov	x0, x19
    5c10:	97fffaf8 	bl	47f0 <fwp_rc_forget_slot>
    5c14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c18:	39000260 	strb	w0, [x19]
    5c1c:	17ffffd7 	b	5b78 <fwp_drop1+0x98>
    5c20:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5c24:	91240000 	add	x0, x0, #0x900
    5c28:	97fff6f6 	bl	3800 <fwp_trap>
    5c2c:	d503201f 	nop

0000000000005c30 <fwp_closure_drop>:
    5c30:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5c34:	911740a4 	add	x4, x5, #0x5d0
    5c38:	aa0003e1 	mov	x1, x0
    5c3c:	f949d882 	ldr	x2, [x4, #5040]
    5c40:	f949ec80 	ldr	x0, [x4, #5080]
    5c44:	cb020022 	sub	x2, x1, x2
    5c48:	eb00405f 	cmp	x2, x0, lsl #16
    5c4c:	54000662 	b.cs	5d18 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5c50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5c54:	d350fc43 	lsr	x3, x2, #16
    5c58:	910003fd 	mov	x29, sp
    5c5c:	8b030863 	add	x3, x3, x3, lsl #2
    5c60:	f949fc84 	ldr	x4, [x4, #5112]
    5c64:	d37df063 	lsl	x3, x3, #3
    5c68:	f9000bf3 	str	x19, [sp, #16]
    5c6c:	8b030080 	add	x0, x4, x3
    5c70:	f9401013 	ldr	x19, [x0, #32]
    5c74:	b40002b3 	cbz	x19, 5cc8 <fwp_closure_drop+0x98>
    5c78:	38636883 	ldrb	w3, [x4, x3]
    5c7c:	7100087f 	cmp	w3, #0x2
    5c80:	54000420 	b.eq	5d04 <fwp_closure_drop+0xd4>  // b.none
    5c84:	7100047f 	cmp	w3, #0x1
    5c88:	54000201 	b.ne	5cc8 <fwp_closure_drop+0x98>  // b.any
    5c8c:	29430003 	ldp	w3, w0, [x0, #24]
    5c90:	92403c42 	and	x2, x2, #0xffff
    5c94:	9b037c42 	mul	x2, x2, x3
    5c98:	d360fc42 	lsr	x2, x2, #32
    5c9c:	eb00005f 	cmp	x2, x0
    5ca0:	54000142 	b.cs	5cc8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5ca4:	8b020273 	add	x19, x19, x2
    5ca8:	39400260 	ldrb	w0, [x19]
    5cac:	340000e0 	cbz	w0, 5cc8 <fwp_closure_drop+0x98>
    5cb0:	7100041f 	cmp	w0, #0x1
    5cb4:	54000100 	b.eq	5cd4 <fwp_closure_drop+0xa4>  // b.none
    5cb8:	7103fc1f 	cmp	w0, #0xff
    5cbc:	54000300 	b.eq	5d1c <fwp_closure_drop+0xec>  // b.none
    5cc0:	51000400 	sub	w0, w0, #0x1
    5cc4:	39000260 	strb	w0, [x19]
    5cc8:	f9400bf3 	ldr	x19, [sp, #16]
    5ccc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cd0:	d65f03c0 	ret
    5cd4:	d53bd040 	mrs	x0, tpidr_el0
    5cd8:	91400000 	add	x0, x0, #0x0, lsl #12
    5cdc:	91004000 	add	x0, x0, #0x10
    5ce0:	f9400000 	ldr	x0, [x0]
    5ce4:	b4000080 	cbz	x0, 5cf4 <fwp_closure_drop+0xc4>
    5ce8:	f9400bf3 	ldr	x19, [sp, #16]
    5cec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5cf0:	17fff6dd 	b	3864 <fwp_closure_drop_push>
    5cf4:	f9400bf3 	ldr	x19, [sp, #16]
    5cf8:	aa0103e0 	mov	x0, x1
    5cfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d00:	17fff748 	b	3a20 <fwp_closure_drop.part.0>
    5d04:	72003c5f 	tst	w2, #0xffff
    5d08:	54fffd00 	b.eq	5ca8 <fwp_closure_drop+0x78>  // b.none
    5d0c:	f9400bf3 	ldr	x19, [sp, #16]
    5d10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d14:	d65f03c0 	ret
    5d18:	d65f03c0 	ret
    5d1c:	ca534660 	eor	x0, x19, x19, lsr #17
    5d20:	911740a5 	add	x5, x5, #0x5d0
    5d24:	ca402400 	eor	x0, x0, x0, lsr #9
    5d28:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5d2c:	f94a2400 	ldr	x0, [x0, #5192]
    5d30:	b5000080 	cbnz	x0, 5d40 <fwp_closure_drop+0x110>
    5d34:	14000010 	b	5d74 <fwp_closure_drop+0x144>
    5d38:	f9400800 	ldr	x0, [x0, #16]
    5d3c:	b40001c0 	cbz	x0, 5d74 <fwp_closure_drop+0x144>
    5d40:	f9400001 	ldr	x1, [x0]
    5d44:	eb13003f 	cmp	x1, x19
    5d48:	54ffff81 	b.ne	5d38 <fwp_closure_drop+0x108>  // b.any
    5d4c:	f9400401 	ldr	x1, [x0, #8]
    5d50:	d1000421 	sub	x1, x1, #0x1
    5d54:	f9000401 	str	x1, [x0, #8]
    5d58:	f103f83f 	cmp	x1, #0xfe
    5d5c:	54fffb61 	b.ne	5cc8 <fwp_closure_drop+0x98>  // b.any
    5d60:	aa1303e0 	mov	x0, x19
    5d64:	97fffaa3 	bl	47f0 <fwp_rc_forget_slot>
    5d68:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d6c:	39000260 	strb	w0, [x19]
    5d70:	17ffffd6 	b	5cc8 <fwp_closure_drop+0x98>
    5d74:	d0000020 	adrp	x0, b000 <__divti3+0x180>
    5d78:	91240000 	add	x0, x0, #0x900
    5d7c:	97fff6a1 	bl	3800 <fwp_trap>

0000000000005d80 <fwp_owned_tape_release>:
    5d80:	b4000940 	cbz	x0, 5ea8 <fwp_owned_tape_release+0x128>
    5d84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d88:	910003fd 	mov	x29, sp
    5d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    5d90:	aa0003f3 	mov	x19, x0
    5d94:	f9400000 	ldr	x0, [x0]
    5d98:	b4000060 	cbz	x0, 5da4 <fwp_owned_tape_release+0x24>
    5d9c:	f9400661 	ldr	x1, [x19, #8]
    5da0:	f9000401 	str	x1, [x0, #8]
    5da4:	f9400661 	ldr	x1, [x19, #8]
    5da8:	b4000041 	cbz	x1, 5db0 <fwp_owned_tape_release+0x30>
    5dac:	f9000020 	str	x0, [x1]
    5db0:	f9400a60 	ldr	x0, [x19, #16]
    5db4:	f9403401 	ldr	x1, [x0, #104]
    5db8:	b40005c1 	cbz	x1, 5e70 <fwp_owned_tape_release+0xf0>
    5dbc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5dc0:	eb00005f 	cmp	x2, x0
    5dc4:	540002ed 	b.le	5e20 <fwp_owned_tape_release+0xa0>
    5dc8:	d2800014 	mov	x20, #0x0                   	// #0
    5dcc:	f90013f5 	str	x21, [sp, #32]
    5dd0:	d2800015 	mov	x21, #0x0                   	// #0
    5dd4:	d503201f 	nop
    5dd8:	f9402260 	ldr	x0, [x19, #64]
    5ddc:	910006b5 	add	x21, x21, #0x1
    5de0:	f8746800 	ldr	x0, [x0, x20]
    5de4:	d63f0020 	blr	x1
    5de8:	f9402260 	ldr	x0, [x19, #64]
    5dec:	f9400a61 	ldr	x1, [x19, #16]
    5df0:	8b140000 	add	x0, x0, x20
    5df4:	91004294 	add	x20, x20, #0x10
    5df8:	f9400400 	ldr	x0, [x0, #8]
    5dfc:	f9403421 	ldr	x1, [x1, #104]
    5e00:	d63f0020 	blr	x1
    5e04:	a9450261 	ldp	x1, x0, [x19, #80]
    5e08:	cb010000 	sub	x0, x0, x1
    5e0c:	eb15001f 	cmp	x0, x21
    5e10:	f9400a60 	ldr	x0, [x19, #16]
    5e14:	f9403401 	ldr	x1, [x0, #104]
    5e18:	54fffe0c 	b.gt	5dd8 <fwp_owned_tape_release+0x58>
    5e1c:	f94013f5 	ldr	x21, [sp, #32]
    5e20:	f9403663 	ldr	x3, [x19, #104]
    5e24:	f9401262 	ldr	x2, [x19, #32]
    5e28:	f100007f 	cmp	x3, #0x0
    5e2c:	540001ed 	b.le	5e68 <fwp_owned_tape_release+0xe8>
    5e30:	d2800014 	mov	x20, #0x0                   	// #0
    5e34:	d503201f 	nop
    5e38:	f9402660 	ldr	x0, [x19, #72]
    5e3c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5e40:	eb02001f 	cmp	x0, x2
    5e44:	540000c0 	b.eq	5e5c <fwp_owned_tape_release+0xdc>  // b.none
    5e48:	d63f0020 	blr	x1
    5e4c:	f9400a60 	ldr	x0, [x19, #16]
    5e50:	f9401262 	ldr	x2, [x19, #32]
    5e54:	f9403663 	ldr	x3, [x19, #104]
    5e58:	f9403401 	ldr	x1, [x0, #104]
    5e5c:	91000694 	add	x20, x20, #0x1
    5e60:	eb14007f 	cmp	x3, x20
    5e64:	54fffeac 	b.gt	5e38 <fwp_owned_tape_release+0xb8>
    5e68:	aa0203e0 	mov	x0, x2
    5e6c:	d63f0020 	blr	x1
    5e70:	f9401660 	ldr	x0, [x19, #40]
    5e74:	97ffff6f 	bl	5c30 <fwp_closure_drop>
    5e78:	f9401a60 	ldr	x0, [x19, #48]
    5e7c:	97ffff6d 	bl	5c30 <fwp_closure_drop>
    5e80:	f9401e60 	ldr	x0, [x19, #56]
    5e84:	97ffff6b 	bl	5c30 <fwp_closure_drop>
    5e88:	f9402260 	ldr	x0, [x19, #64]
    5e8c:	97fffaf9 	bl	4a70 <fwp_mem_free>
    5e90:	f9402660 	ldr	x0, [x19, #72]
    5e94:	97fffaf7 	bl	4a70 <fwp_mem_free>
    5e98:	aa1303e0 	mov	x0, x19
    5e9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ea0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ea4:	17fffaf3 	b	4a70 <fwp_mem_free>
    5ea8:	d65f03c0 	ret
    5eac:	d503201f 	nop

0000000000005eb0 <fwp_tape_finish>:
    5eb0:	d10203ff 	sub	sp, sp, #0x80
    5eb4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5eb8:	f947f421 	ldr	x1, [x1, #4072]
    5ebc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5ec0:	910103fd 	add	x29, sp, #0x40
    5ec4:	a90553f3 	stp	x19, x20, [sp, #80]
    5ec8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5ecc:	a90763f7 	stp	x23, x24, [sp, #112]
    5ed0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5ed4:	9101c316 	add	x22, x24, #0x70
    5ed8:	f9400022 	ldr	x2, [x1]
    5edc:	f9001fe2 	str	x2, [sp, #56]
    5ee0:	d2800002 	mov	x2, #0x0                   	// #0
    5ee4:	910262c0 	add	x0, x22, #0x98
    5ee8:	97fff566 	bl	3480 <fwp_tape_buffers_dispose>
    5eec:	f9006adf 	str	xzr, [x22, #208]
    5ef0:	f9404ac0 	ldr	x0, [x22, #144]
    5ef4:	f100001f 	cmp	x0, #0x0
    5ef8:	5400030d 	b.le	5f58 <fwp_tape_finish+0xa8>
    5efc:	910003f7 	mov	x23, sp
    5f00:	d2800015 	mov	x21, #0x0                   	// #0
    5f04:	d2800014 	mov	x20, #0x0                   	// #0
    5f08:	f94002d3 	ldr	x19, [x22]
    5f0c:	91000694 	add	x20, x20, #0x1
    5f10:	8b150273 	add	x19, x19, x21
    5f14:	9101a2b5 	add	x21, x21, #0x68
    5f18:	aa1303e0 	mov	x0, x19
    5f1c:	97fff41d 	bl	2f90 <fwp_tape_unlink_scope>
    5f20:	aa1703e0 	mov	x0, x23
    5f24:	f9401261 	ldr	x1, [x19, #32]
    5f28:	f90003e1 	str	x1, [sp]
    5f2c:	f9401a62 	ldr	x2, [x19, #48]
    5f30:	f9000be2 	str	x2, [sp, #16]
    5f34:	f9402261 	ldr	x1, [x19, #64]
    5f38:	f90013e1 	str	x1, [sp, #32]
    5f3c:	97fff551 	bl	3480 <fwp_tape_buffers_dispose>
    5f40:	f9403260 	ldr	x0, [x19, #96]
    5f44:	97ffff8f 	bl	5d80 <fwp_owned_tape_release>
    5f48:	f900327f 	str	xzr, [x19, #96]
    5f4c:	f9404ac0 	ldr	x0, [x22, #144]
    5f50:	eb14001f 	cmp	x0, x20
    5f54:	54fffdac 	b.gt	5f08 <fwp_tape_finish+0x58>
    5f58:	f9403b00 	ldr	x0, [x24, #112]
    5f5c:	9101c313 	add	x19, x24, #0x70
    5f60:	97fff278 	bl	2940 <free@plt>
    5f64:	f9003b1f 	str	xzr, [x24, #112]
    5f68:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5f6c:	f947f400 	ldr	x0, [x0, #4072]
    5f70:	f9004a7f 	str	xzr, [x19, #144]
    5f74:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    5f78:	f9401fe2 	ldr	x2, [sp, #56]
    5f7c:	f9400001 	ldr	x1, [x0]
    5f80:	eb010042 	subs	x2, x2, x1
    5f84:	d2800001 	mov	x1, #0x0                   	// #0
    5f88:	540000e1 	b.ne	5fa4 <fwp_tape_finish+0xf4>  // b.any
    5f8c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f90:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f94:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5f98:	a94763f7 	ldp	x23, x24, [sp, #112]
    5f9c:	910203ff 	add	sp, sp, #0x80
    5fa0:	d65f03c0 	ret
    5fa4:	97fff237 	bl	2880 <__stack_chk_fail@plt>
    5fa8:	d503201f 	nop
    5fac:	d503201f 	nop

0000000000005fb0 <fwp_tape_scope_release>:
    5fb0:	d10243ff 	sub	sp, sp, #0x90
    5fb4:	a9047bfd 	stp	x29, x30, [sp, #64]
    5fb8:	910103fd 	add	x29, sp, #0x40
    5fbc:	a90553f3 	stp	x19, x20, [sp, #80]
    5fc0:	aa0003f4 	mov	x20, x0
    5fc4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5fc8:	f947f400 	ldr	x0, [x0, #4072]
    5fcc:	b9400285 	ldr	w5, [x20]
    5fd0:	f9400001 	ldr	x1, [x0]
    5fd4:	f9001fe1 	str	x1, [sp, #56]
    5fd8:	d2800001 	mov	x1, #0x0                   	// #0
    5fdc:	37f806c5 	tbnz	w5, #31, 60b4 <fwp_tape_scope_release+0x104>
    5fe0:	a90763f7 	stp	x23, x24, [sp, #112]
    5fe4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5fe8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5fec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5ff0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5ff4:	910003f7 	mov	x23, sp
    5ff8:	9101c273 	add	x19, x19, #0x70
    5ffc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6000:	a9065bf5 	stp	x21, x22, [sp, #96]
    6004:	52800d16 	mov	w22, #0x68                  	// #104
    6008:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    600c:	f90043f9 	str	x25, [sp, #128]
    6010:	14000006 	b	6028 <fwp_tape_scope_release+0x78>
    6014:	97fff51b 	bl	3480 <fwp_tape_buffers_dispose>
    6018:	aa1903e0 	mov	x0, x25
    601c:	97ffff59 	bl	5d80 <fwp_owned_tape_release>
    6020:	b9400285 	ldr	w5, [x20]
    6024:	37f80425 	tbnz	w5, #31, 60a8 <fwp_tape_scope_release+0xf8>
    6028:	f9400266 	ldr	x6, [x19]
    602c:	9b367ca5 	smull	x5, w5, w22
    6030:	8b0500c0 	add	x0, x6, x5
    6034:	97fff3d7 	bl	2f90 <fwp_tape_unlink_scope>
    6038:	ad410001 	ldp	q1, q0, [x0, #32]
    603c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6040:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6044:	f9400c03 	ldr	x3, [x0, #24]
    6048:	ad0003e1 	stp	q1, q0, [sp]
    604c:	b86568c1 	ldr	w1, [x6, x5]
    6050:	a9440804 	ldp	x4, x2, [x0, #64]
    6054:	b900041f 	str	wzr, [x0, #4]
    6058:	f9403019 	ldr	x25, [x0, #96]
    605c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6060:	f9000c1f 	str	xzr, [x0, #24]
    6064:	a9020fe4 	stp	x4, x3, [sp, #32]
    6068:	f9001be2 	str	x2, [sp, #48]
    606c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6070:	f900301f 	str	xzr, [x0, #96]
    6074:	6b15003f 	cmp	w1, w21
    6078:	540000e8 	b.hi	6094 <fwp_tape_scope_release+0xe4>  // b.pmore
    607c:	9343fca5 	asr	x5, x5, #3
    6080:	f9407660 	ldr	x0, [x19, #232]
    6084:	9b187ca5 	mul	x5, x5, x24
    6088:	eb0000bf 	cmp	x5, x0
    608c:	5400004a 	b.ge	6094 <fwp_tape_scope_release+0xe4>  // b.tcont
    6090:	f9007665 	str	x5, [x19, #232]
    6094:	aa1703e0 	mov	x0, x23
    6098:	b5fffbf9 	cbnz	x25, 6014 <fwp_tape_scope_release+0x64>
    609c:	97fff8b9 	bl	4380 <fwp_tape_buffers_release>
    60a0:	b9400285 	ldr	w5, [x20]
    60a4:	36fffc25 	tbz	w5, #31, 6028 <fwp_tape_scope_release+0x78>
    60a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    60b0:	f94043f9 	ldr	x25, [sp, #128]
    60b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    60b8:	f947f400 	ldr	x0, [x0, #4072]
    60bc:	f9401fe2 	ldr	x2, [sp, #56]
    60c0:	f9400001 	ldr	x1, [x0]
    60c4:	eb010042 	subs	x2, x2, x1
    60c8:	d2800001 	mov	x1, #0x0                   	// #0
    60cc:	540000a1 	b.ne	60e0 <fwp_tape_scope_release+0x130>  // b.any
    60d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    60d8:	910243ff 	add	sp, sp, #0x90
    60dc:	d65f03c0 	ret
    60e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60e4:	a90763f7 	stp	x23, x24, [sp, #112]
    60e8:	f90043f9 	str	x25, [sp, #128]
    60ec:	97fff1e5 	bl	2880 <__stack_chk_fail@plt>

00000000000060f0 <fwp_task_dispose>:
    60f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60f4:	910003fd 	mov	x29, sp
    60f8:	f9000bf3 	str	x19, [sp, #16]
    60fc:	aa0003f3 	mov	x19, x0
    6100:	39414000 	ldrb	w0, [x0, #80]
    6104:	36000720 	tbz	w0, #0, 61e8 <fwp_task_dispose+0xf8>
    6108:	f9400a60 	ldr	x0, [x19, #16]
    610c:	b50006e0 	cbnz	x0, 61e8 <fwp_task_dispose+0xf8>
    6110:	a9478660 	ldp	x0, x1, [x19, #120]
    6114:	39014e7f 	strb	wzr, [x19, #83]
    6118:	f9003e7f 	str	xzr, [x19, #120]
    611c:	f100003f 	cmp	x1, #0x0
    6120:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6124:	54000040 	b.eq	612c <fwp_task_dispose+0x3c>  // b.none
    6128:	d63f0020 	blr	x1
    612c:	f9405660 	ldr	x0, [x19, #168]
    6130:	97fffa50 	bl	4a70 <fwp_mem_free>
    6134:	f900567f 	str	xzr, [x19, #168]
    6138:	b9405e60 	ldr	w0, [x19, #92]
    613c:	7100041f 	cmp	w0, #0x1
    6140:	54000420 	b.eq	61c4 <fwp_task_dispose+0xd4>  // b.none
    6144:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6148:	91174042 	add	x2, x2, #0x5d0
    614c:	f949d840 	ldr	x0, [x2, #5040]
    6150:	f949ec41 	ldr	x1, [x2, #5080]
    6154:	cb000260 	sub	x0, x19, x0
    6158:	eb01401f 	cmp	x0, x1, lsl #16
    615c:	540002e2 	b.cs	61b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6160:	d350fc01 	lsr	x1, x0, #16
    6164:	f949fc44 	ldr	x4, [x2, #5112]
    6168:	8b010821 	add	x1, x1, x1, lsl #2
    616c:	d37df021 	lsl	x1, x1, #3
    6170:	8b010083 	add	x3, x4, x1
    6174:	f9401062 	ldr	x2, [x3, #32]
    6178:	b4000202 	cbz	x2, 61b8 <fwp_task_dispose+0xc8>
    617c:	38616881 	ldrb	w1, [x4, x1]
    6180:	7100083f 	cmp	w1, #0x2
    6184:	54000280 	b.eq	61d4 <fwp_task_dispose+0xe4>  // b.none
    6188:	7100043f 	cmp	w1, #0x1
    618c:	54000161 	b.ne	61b8 <fwp_task_dispose+0xc8>  // b.any
    6190:	29430464 	ldp	w4, w1, [x3, #24]
    6194:	92403c00 	and	x0, x0, #0xffff
    6198:	9b047c00 	mul	x0, x0, x4
    619c:	d360fc00 	lsr	x0, x0, #32
    61a0:	eb01001f 	cmp	x0, x1
    61a4:	540000a2 	b.cs	61b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    61a8:	8b000042 	add	x2, x2, x0
    61ac:	39400040 	ldrb	w0, [x2]
    61b0:	7100041f 	cmp	w0, #0x1
    61b4:	54000080 	b.eq	61c4 <fwp_task_dispose+0xd4>  // b.none
    61b8:	f9400bf3 	ldr	x19, [sp, #16]
    61bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c0:	d65f03c0 	ret
    61c4:	aa1303e0 	mov	x0, x19
    61c8:	f9400bf3 	ldr	x19, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	17fffa28 	b	4a70 <fwp_mem_free>
    61d4:	72003c1f 	tst	w0, #0xffff
    61d8:	54fffea0 	b.eq	61ac <fwp_task_dispose+0xbc>  // b.none
    61dc:	f9400bf3 	ldr	x19, [sp, #16]
    61e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e4:	d65f03c0 	ret
    61e8:	97fff1ba 	bl	28d0 <abort@plt>
    61ec:	d503201f 	nop

00000000000061f0 <fwp_free_zombie>:
    61f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61f4:	910003fd 	mov	x29, sp
    61f8:	a90153f3 	stp	x19, x20, [sp, #16]
    61fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6200:	9101c281 	add	x1, x20, #0x70
    6204:	f9407833 	ldr	x19, [x1, #240]
    6208:	b4000333 	cbz	x19, 626c <fwp_free_zombie+0x7c>
    620c:	f9400820 	ldr	x0, [x1, #16]
    6210:	eb00027f 	cmp	x19, x0
    6214:	540002c0 	b.eq	626c <fwp_free_zombie+0x7c>  // b.none
    6218:	b940f822 	ldr	w2, [x1, #248]
    621c:	f9400a60 	ldr	x0, [x19, #16]
    6220:	7100fc5f 	cmp	w2, #0x3f
    6224:	5400078c 	b.gt	6314 <fwp_free_zombie+0x124>
    6228:	91040023 	add	x3, x1, #0x100
    622c:	11000444 	add	w4, w2, #0x1
    6230:	b900f824 	str	w4, [x1, #248]
    6234:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6238:	f822d860 	str	x0, [x3, w2, sxtw #3]
    623c:	a9530261 	ldp	x1, x0, [x19, #304]
    6240:	b4000741 	cbz	x1, 6328 <fwp_free_zombie+0x138>
    6244:	f9009c20 	str	x0, [x1, #312]
    6248:	b4000040 	cbz	x0, 6250 <fwp_free_zombie+0x60>
    624c:	f9009801 	str	x1, [x0, #304]
    6250:	9101c294 	add	x20, x20, #0x70
    6254:	b9405e60 	ldr	w0, [x19, #92]
    6258:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    625c:	f9007a9f 	str	xzr, [x20, #240]
    6260:	34000140 	cbz	w0, 6288 <fwp_free_zombie+0x98>
    6264:	7100041f 	cmp	w0, #0x1
    6268:	54000080 	b.eq	6278 <fwp_free_zombie+0x88>  // b.none
    626c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6270:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6274:	d65f03c0 	ret
    6278:	aa1303e0 	mov	x0, x19
    627c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6284:	17ffff9b 	b	60f0 <fwp_task_dispose>
    6288:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    628c:	91174082 	add	x2, x4, #0x5d0
    6290:	f949d841 	ldr	x1, [x2, #5040]
    6294:	f949ec40 	ldr	x0, [x2, #5080]
    6298:	cb010261 	sub	x1, x19, x1
    629c:	eb00403f 	cmp	x1, x0, lsl #16
    62a0:	54fffe62 	b.cs	626c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62a4:	d350fc20 	lsr	x0, x1, #16
    62a8:	f949fc43 	ldr	x3, [x2, #5112]
    62ac:	8b000800 	add	x0, x0, x0, lsl #2
    62b0:	d37df000 	lsl	x0, x0, #3
    62b4:	8b000062 	add	x2, x3, x0
    62b8:	f9401054 	ldr	x20, [x2, #32]
    62bc:	b4fffd94 	cbz	x20, 626c <fwp_free_zombie+0x7c>
    62c0:	38606860 	ldrb	w0, [x3, x0]
    62c4:	7100081f 	cmp	w0, #0x2
    62c8:	54000360 	b.eq	6334 <fwp_free_zombie+0x144>  // b.none
    62cc:	7100041f 	cmp	w0, #0x1
    62d0:	54fffce1 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    62d4:	29430043 	ldp	w3, w0, [x2, #24]
    62d8:	92403c21 	and	x1, x1, #0xffff
    62dc:	9b037c21 	mul	x1, x1, x3
    62e0:	d360fc21 	lsr	x1, x1, #32
    62e4:	eb00003f 	cmp	x1, x0
    62e8:	54fffc22 	b.cs	626c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62ec:	8b010294 	add	x20, x20, x1
    62f0:	39400280 	ldrb	w0, [x20]
    62f4:	34fffbc0 	cbz	w0, 626c <fwp_free_zombie+0x7c>
    62f8:	7100041f 	cmp	w0, #0x1
    62fc:	54fffbe0 	b.eq	6278 <fwp_free_zombie+0x88>  // b.none
    6300:	7103fc1f 	cmp	w0, #0xff
    6304:	540001e0 	b.eq	6340 <fwp_free_zombie+0x150>  // b.none
    6308:	51000400 	sub	w0, w0, #0x1
    630c:	39000280 	strb	w0, [x20]
    6310:	17ffffd7 	b	626c <fwp_free_zombie+0x7c>
    6314:	f9400e61 	ldr	x1, [x19, #24]
    6318:	97fff1a2 	bl	29a0 <munmap@plt>
    631c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6320:	a9530261 	ldp	x1, x0, [x19, #304]
    6324:	b5fff901 	cbnz	x1, 6244 <fwp_free_zombie+0x54>
    6328:	9101c282 	add	x2, x20, #0x70
    632c:	f9018040 	str	x0, [x2, #768]
    6330:	17ffffc6 	b	6248 <fwp_free_zombie+0x58>
    6334:	72003c3f 	tst	w1, #0xffff
    6338:	54fff9a1 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    633c:	17ffffed 	b	62f0 <fwp_free_zombie+0x100>
    6340:	ca544680 	eor	x0, x20, x20, lsr #17
    6344:	91174084 	add	x4, x4, #0x5d0
    6348:	ca402400 	eor	x0, x0, x0, lsr #9
    634c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6350:	f94a2400 	ldr	x0, [x0, #5192]
    6354:	b5000080 	cbnz	x0, 6364 <fwp_free_zombie+0x174>
    6358:	14000010 	b	6398 <fwp_free_zombie+0x1a8>
    635c:	f9400800 	ldr	x0, [x0, #16]
    6360:	b40001c0 	cbz	x0, 6398 <fwp_free_zombie+0x1a8>
    6364:	f9400001 	ldr	x1, [x0]
    6368:	eb14003f 	cmp	x1, x20
    636c:	54ffff81 	b.ne	635c <fwp_free_zombie+0x16c>  // b.any
    6370:	f9400401 	ldr	x1, [x0, #8]
    6374:	d1000421 	sub	x1, x1, #0x1
    6378:	f9000401 	str	x1, [x0, #8]
    637c:	f103f83f 	cmp	x1, #0xfe
    6380:	54fff761 	b.ne	626c <fwp_free_zombie+0x7c>  // b.any
    6384:	aa1403e0 	mov	x0, x20
    6388:	97fff91a 	bl	47f0 <fwp_rc_forget_slot>
    638c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6390:	39000280 	strb	w0, [x20]
    6394:	17ffffb6 	b	626c <fwp_free_zombie+0x7c>
    6398:	b0000020 	adrp	x0, b000 <__divti3+0x180>
    639c:	91240000 	add	x0, x0, #0x900
    63a0:	97fff518 	bl	3800 <fwp_trap>

00000000000063a4 <fwp_block>:
    63a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63a8:	910003fd 	mov	x29, sp
    63ac:	a90153f3 	stp	x19, x20, [sp, #16]
    63b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    63b4:	9101c274 	add	x20, x19, #0x70
    63b8:	f9404282 	ldr	x2, [x20, #128]
    63bc:	b4000622 	cbz	x2, 6480 <fwp_block+0xdc>
    63c0:	9101c261 	add	x1, x19, #0x70
    63c4:	f9408040 	ldr	x0, [x2, #256]
    63c8:	f9004020 	str	x0, [x1, #128]
    63cc:	b4000680 	cbz	x0, 649c <fwp_block+0xf8>
    63d0:	9101c263 	add	x3, x19, #0x70
    63d4:	3901505f 	strb	wzr, [x2, #84]
    63d8:	f9400864 	ldr	x4, [x3, #16]
    63dc:	eb02009f 	cmp	x4, x2
    63e0:	54000440 	b.eq	6468 <fwp_block+0xc4>  // b.none
    63e4:	f9418465 	ldr	x5, [x3, #776]
    63e8:	f9000862 	str	x2, [x3, #16]
    63ec:	f9400441 	ldr	x1, [x2, #8]
    63f0:	f9004885 	str	x5, [x4, #144]
    63f4:	f9418865 	ldr	x5, [x3, #784]
    63f8:	f9004c85 	str	x5, [x4, #152]
    63fc:	f9418c65 	ldr	x5, [x3, #792]
    6400:	f9005085 	str	x5, [x4, #160]
    6404:	f9419065 	ldr	x5, [x3, #800]
    6408:	f9005485 	str	x5, [x4, #168]
    640c:	f9419465 	ldr	x5, [x3, #808]
    6410:	f9005885 	str	x5, [x4, #176]
    6414:	f9419865 	ldr	x5, [x3, #816]
    6418:	f9005c85 	str	x5, [x4, #184]
    641c:	f9419c65 	ldr	x5, [x3, #824]
    6420:	f9006085 	str	x5, [x4, #192]
    6424:	f9400480 	ldr	x0, [x4, #8]
    6428:	f9404844 	ldr	x4, [x2, #144]
    642c:	f9018464 	str	x4, [x3, #776]
    6430:	f9404c44 	ldr	x4, [x2, #152]
    6434:	f9018864 	str	x4, [x3, #784]
    6438:	f9405044 	ldr	x4, [x2, #160]
    643c:	f9018c64 	str	x4, [x3, #792]
    6440:	f9405444 	ldr	x4, [x2, #168]
    6444:	f9019064 	str	x4, [x3, #800]
    6448:	f9405844 	ldr	x4, [x2, #176]
    644c:	f9019464 	str	x4, [x3, #808]
    6450:	a94b8844 	ldp	x4, x2, [x2, #184]
    6454:	f9019864 	str	x4, [x3, #816]
    6458:	f9019c62 	str	x2, [x3, #824]
    645c:	97fff121 	bl	28e0 <swapcontext@plt>
    6460:	97ffff64 	bl	61f0 <fwp_free_zombie>
    6464:	d503201f 	nop
    6468:	9101c260 	add	x0, x19, #0x70
    646c:	b9434000 	ldr	w0, [x0, #832]
    6470:	340001a0 	cbz	w0, 64a4 <fwp_block+0x100>
    6474:	a94153f3 	ldp	x19, x20, [sp, #16]
    6478:	a8c27bfd 	ldp	x29, x30, [sp], #32
    647c:	d65f03c0 	ret
    6480:	97fff808 	bl	44a0 <fwp_poll_events>
    6484:	f9404282 	ldr	x2, [x20, #128]
    6488:	b4ffffc2 	cbz	x2, 6480 <fwp_block+0xdc>
    648c:	9101c261 	add	x1, x19, #0x70
    6490:	f9408040 	ldr	x0, [x2, #256]
    6494:	f9004020 	str	x0, [x1, #128]
    6498:	b5fff9c0 	cbnz	x0, 63d0 <fwp_block+0x2c>
    649c:	f9003c3f 	str	xzr, [x1, #120]
    64a0:	17ffffcc 	b	63d0 <fwp_block+0x2c>
    64a4:	b0000020 	adrp	x0, b000 <__divti3+0x180>
    64a8:	9128c000 	add	x0, x0, #0xa30
    64ac:	97fff159 	bl	2a10 <getenv@plt>
    64b0:	5284e202 	mov	w2, #0x2710                	// #10000
    64b4:	b4000060 	cbz	x0, 64c0 <fwp_block+0x11c>
    64b8:	39400001 	ldrb	w1, [x0]
    64bc:	350000c1 	cbnz	w1, 64d4 <fwp_block+0x130>
    64c0:	9101c273 	add	x19, x19, #0x70
    64c4:	b9034262 	str	w2, [x19, #832]
    64c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    64cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64d0:	d65f03c0 	ret
    64d4:	52800142 	mov	w2, #0xa                   	// #10
    64d8:	d2800001 	mov	x1, #0x0                   	// #0
    64dc:	97fff09d 	bl	2750 <strtoll@plt>
    64e0:	d1000403 	sub	x3, x0, #0x1
    64e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    64e8:	eb02007f 	cmp	x3, x2
    64ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    64f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    64f4:	17fffff3 	b	64c0 <fwp_block+0x11c>
    64f8:	d503201f 	nop
    64fc:	d503201f 	nop

0000000000006500 <fwp_owned_entry161>:
    6500:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6504:	910003fd 	mov	x29, sp
    6508:	a90363f7 	stp	x23, x24, [sp, #48]
    650c:	a9406002 	ldp	x2, x24, [x0]
    6510:	a90153f3 	stp	x19, x20, [sp, #16]
    6514:	f9400801 	ldr	x1, [x0, #16]
    6518:	a9025bf5 	stp	x21, x22, [sp, #32]
    651c:	ab010055 	adds	x21, x2, x1
    6520:	54000d06 	b.vs	66c0 <fwp_owned_entry161+0x1c0>
    6524:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    6528:	91174281 	add	x1, x20, #0x5d0
    652c:	b953a420 	ldr	w0, [x1, #5028]
    6530:	34000a80 	cbz	w0, 6680 <fwp_owned_entry161+0x180>
    6534:	397e8820 	ldrb	w0, [x1, #4002]
    6538:	910f0002 	add	x2, x0, #0x3c0
    653c:	8b000400 	add	x0, x0, x0, lsl #1
    6540:	d37df000 	lsl	x0, x0, #3
    6544:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6548:	2a1703f6 	mov	w22, w23
    654c:	f8606833 	ldr	x19, [x1, x0]
    6550:	b4000853 	cbz	x19, 6658 <fwp_owned_entry161+0x158>
    6554:	f9400262 	ldr	x2, [x19]
    6558:	aa2203e2 	mvn	x2, x2
    655c:	f8206822 	str	x2, [x1, x0]
    6560:	f10062df 	cmp	x22, #0x18
    6564:	540000e9 	b.ls	6580 <fwp_owned_entry161+0x80>  // b.plast
    6568:	d10066c2 	sub	x2, x22, #0x19
    656c:	91006260 	add	x0, x19, #0x18
    6570:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6574:	52800001 	mov	w1, #0x0                   	// #0
    6578:	91002042 	add	x2, x2, #0x8
    657c:	97fff0b5 	bl	2850 <memset@plt>
    6580:	91174281 	add	x1, x20, #0x5d0
    6584:	f94a1020 	ldr	x0, [x1, #5152]
    6588:	ab160000 	adds	x0, x0, x22
    658c:	540009c2 	b.cs	66c4 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6590:	f94a1422 	ldr	x2, [x1, #5160]
    6594:	f90a1020 	str	x0, [x1, #5152]
    6598:	eb02001f 	cmp	x0, x2
    659c:	54000049 	b.ls	65a4 <fwp_owned_entry161+0xa4>  // b.plast
    65a0:	f90a1420 	str	x0, [x1, #5160]
    65a4:	91174280 	add	x0, x20, #0x5d0
    65a8:	1e6302e1 	ucvtf	d1, w23
    65ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    65b0:	1e612800 	fadd	d0, d0, d1
    65b4:	fd0a1c00 	str	d0, [x0, #5176]
    65b8:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    65bc:	91174294 	add	x20, x20, #0x5d0
    65c0:	a900d678 	stp	x24, x21, [x19, #8]
    65c4:	fd41c800 	ldr	d0, [x0, #912]
    65c8:	fd000260 	str	d0, [x19]
    65cc:	f949da81 	ldr	x1, [x20, #5040]
    65d0:	f949ee80 	ldr	x0, [x20, #5080]
    65d4:	cb010261 	sub	x1, x19, x1
    65d8:	eb00403f 	cmp	x1, x0, lsl #16
    65dc:	54000322 	b.cs	6640 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    65e0:	d350fc20 	lsr	x0, x1, #16
    65e4:	f949fe83 	ldr	x3, [x20, #5112]
    65e8:	8b000800 	add	x0, x0, x0, lsl #2
    65ec:	d37df002 	lsl	x2, x0, #3
    65f0:	8b020060 	add	x0, x3, x2
    65f4:	f9401014 	ldr	x20, [x0, #32]
    65f8:	b4000254 	cbz	x20, 6640 <fwp_owned_entry161+0x140>
    65fc:	38626862 	ldrb	w2, [x3, x2]
    6600:	7100085f 	cmp	w2, #0x2
    6604:	54000480 	b.eq	6694 <fwp_owned_entry161+0x194>  // b.none
    6608:	7100045f 	cmp	w2, #0x1
    660c:	540001a1 	b.ne	6640 <fwp_owned_entry161+0x140>  // b.any
    6610:	29430002 	ldp	w2, w0, [x0, #24]
    6614:	92403c21 	and	x1, x1, #0xffff
    6618:	9b027c21 	mul	x1, x1, x2
    661c:	d360fc21 	lsr	x1, x1, #32
    6620:	eb00003f 	cmp	x1, x0
    6624:	540000e2 	b.cs	6640 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6628:	8b010294 	add	x20, x20, x1
    662c:	39400280 	ldrb	w0, [x20]
    6630:	7103fc1f 	cmp	w0, #0xff
    6634:	54000400 	b.eq	66b4 <fwp_owned_entry161+0x1b4>  // b.none
    6638:	52800020 	mov	w0, #0x1                   	// #1
    663c:	39000280 	strb	w0, [x20]
    6640:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6644:	aa1303e0 	mov	x0, x19
    6648:	a94153f3 	ldp	x19, x20, [sp, #16]
    664c:	a94363f7 	ldp	x23, x24, [sp, #48]
    6650:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6654:	d65f03c0 	ret
    6658:	8b000021 	add	x1, x1, x0
    665c:	f9400433 	ldr	x19, [x1, #8]
    6660:	b4000113 	cbz	x19, 6680 <fwp_owned_entry161+0x180>
    6664:	f9400820 	ldr	x0, [x1, #16]
    6668:	cb130000 	sub	x0, x0, x19
    666c:	eb0002df 	cmp	x22, x0
    6670:	54000088 	b.hi	6680 <fwp_owned_entry161+0x180>  // b.pmore
    6674:	8b160260 	add	x0, x19, x22
    6678:	f9000420 	str	x0, [x1, #8]
    667c:	17ffffb9 	b	6560 <fwp_owned_entry161+0x60>
    6680:	52800001 	mov	w1, #0x0                   	// #0
    6684:	d2800300 	mov	x0, #0x18                  	// #24
    6688:	97fffa1a 	bl	4ef0 <fwp_heap_alloc>
    668c:	aa0003f3 	mov	x19, x0
    6690:	17ffffca 	b	65b8 <fwp_owned_entry161+0xb8>
    6694:	72003c3f 	tst	w1, #0xffff
    6698:	54fffca0 	b.eq	662c <fwp_owned_entry161+0x12c>  // b.none
    669c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66a0:	aa1303e0 	mov	x0, x19
    66a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    66ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    66b0:	d65f03c0 	ret
    66b4:	aa1403e0 	mov	x0, x20
    66b8:	97fff84e 	bl	47f0 <fwp_rc_forget_slot>
    66bc:	17ffffdf 	b	6638 <fwp_owned_entry161+0x138>
    66c0:	97fff0f0 	bl	2a80 <fwp_trap_overflow.constprop.0>
    66c4:	97fff25b 	bl	3030 <fwp_heap_oom>
    66c8:	d503201f 	nop
    66cc:	d503201f 	nop

00000000000066d0 <e161>:
    66d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    66d4:	910003fd 	mov	x29, sp
    66d8:	a90363f7 	stp	x23, x24, [sp, #48]
    66dc:	a9406002 	ldp	x2, x24, [x0]
    66e0:	a90153f3 	stp	x19, x20, [sp, #16]
    66e4:	f9400801 	ldr	x1, [x0, #16]
    66e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    66ec:	ab010055 	adds	x21, x2, x1
    66f0:	54000d86 	b.vs	68a0 <e161+0x1d0>
    66f4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc10>
    66f8:	91174281 	add	x1, x20, #0x5d0
    66fc:	b953a420 	ldr	w0, [x1, #5028]
    6700:	34000ac0 	cbz	w0, 6858 <e161+0x188>
    6704:	397e8820 	ldrb	w0, [x1, #4002]
    6708:	910f0002 	add	x2, x0, #0x3c0
    670c:	8b000400 	add	x0, x0, x0, lsl #1
    6710:	d37df000 	lsl	x0, x0, #3
    6714:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6718:	2a1703f6 	mov	w22, w23
    671c:	f8606833 	ldr	x19, [x1, x0]
    6720:	b4000893 	cbz	x19, 6830 <e161+0x160>
    6724:	f9400262 	ldr	x2, [x19]
    6728:	aa2203e2 	mvn	x2, x2
    672c:	f8206822 	str	x2, [x1, x0]
    6730:	f10062df 	cmp	x22, #0x18
    6734:	540000e9 	b.ls	6750 <e161+0x80>  // b.plast
    6738:	d10066c2 	sub	x2, x22, #0x19
    673c:	91006260 	add	x0, x19, #0x18
    6740:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6744:	52800001 	mov	w1, #0x0                   	// #0
    6748:	91002042 	add	x2, x2, #0x8
    674c:	97fff041 	bl	2850 <memset@plt>
    6750:	91174281 	add	x1, x20, #0x5d0
    6754:	f94a1020 	ldr	x0, [x1, #5152]
    6758:	ab160000 	adds	x0, x0, x22
    675c:	54000a42 	b.cs	68a4 <e161+0x1d4>  // b.hs, b.nlast
    6760:	f94a1422 	ldr	x2, [x1, #5160]
    6764:	f90a1020 	str	x0, [x1, #5152]
    6768:	eb02001f 	cmp	x0, x2
    676c:	54000049 	b.ls	6774 <e161+0xa4>  // b.plast
    6770:	f90a1420 	str	x0, [x1, #5160]
    6774:	91174280 	add	x0, x20, #0x5d0
    6778:	1e6302e1 	ucvtf	d1, w23
    677c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6780:	1e612800 	fadd	d0, d0, d1
    6784:	fd0a1c00 	str	d0, [x0, #5176]
    6788:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    678c:	91174294 	add	x20, x20, #0x5d0
    6790:	a900d678 	stp	x24, x21, [x19, #8]
    6794:	fd41c800 	ldr	d0, [x0, #912]
    6798:	fd000260 	str	d0, [x19]
    679c:	f949da81 	ldr	x1, [x20, #5040]
    67a0:	f949ee80 	ldr	x0, [x20, #5080]
    67a4:	cb010261 	sub	x1, x19, x1
    67a8:	eb00403f 	cmp	x1, x0, lsl #16
    67ac:	54000322 	b.cs	6810 <e161+0x140>  // b.hs, b.nlast
    67b0:	d350fc20 	lsr	x0, x1, #16
    67b4:	f949fe83 	ldr	x3, [x20, #5112]
    67b8:	8b000800 	add	x0, x0, x0, lsl #2
    67bc:	d37df002 	lsl	x2, x0, #3
    67c0:	8b020060 	add	x0, x3, x2
    67c4:	f9401014 	ldr	x20, [x0, #32]
    67c8:	b4000254 	cbz	x20, 6810 <e161+0x140>
    67cc:	38626862 	ldrb	w2, [x3, x2]
    67d0:	7100085f 	cmp	w2, #0x2
    67d4:	540004c0 	b.eq	686c <e161+0x19c>  // b.none
    67d8:	7100045f 	cmp	w2, #0x1
    67dc:	540001a1 	b.ne	6810 <e161+0x140>  // b.any
    67e0:	29430002 	ldp	w2, w0, [x0, #24]
    67e4:	92403c21 	and	x1, x1, #0xffff
    67e8:	9b027c21 	mul	x1, x1, x2
    67ec:	d360fc21 	lsr	x1, x1, #32
    67f0:	eb00003f 	cmp	x1, x0
    67f4:	540000e2 	b.cs	6810 <e161+0x140>  // b.hs, b.nlast
    67f8:	8b010294 	add	x20, x20, x1
    67fc:	39400280 	ldrb	w0, [x20]
    6800:	7103fc1f 	cmp	w0, #0xff
    6804:	54000480 	b.eq	6894 <e161+0x1c4>  // b.none
    6808:	52800020 	mov	w0, #0x1                   	// #1
    680c:	39000280 	strb	w0, [x20]
    6810:	aa1303e0 	mov	x0, x19
    6814:	97fffbeb 	bl	57c0 <fwp_rc_share>
    6818:	a9425bf5 	ldp	x21, x22, [sp, #32]
    681c:	aa1303e0 	mov	x0, x19
    6820:	a94153f3 	ldp	x19, x20, [sp, #16]
    6824:	a94363f7 	ldp	x23, x24, [sp, #48]
    6828:	a8c47bfd 	ldp	x29, x30, [sp], #64
    682c:	d65f03c0 	ret
    6830:	8b000021 	add	x1, x1, x0
    6834:	f9400433 	ldr	x19, [x1, #8]
    6838:	b4000113 	cbz	x19, 6858 <e161+0x188>
    683c:	f9400820 	ldr	x0, [x1, #16]
    6840:	cb130000 	sub	x0, x0, x19
    6844:	eb0002df 	cmp	x22, x0
    6848:	54000088 	b.hi	6858 <e161+0x188>  // b.pmore
    684c:	8b160260 	add	x0, x19, x22
    6850:	f9000420 	str	x0, [x1, #8]
    6854:	17ffffb7 	b	6730 <e161+0x60>
    6858:	52800001 	mov	w1, #0x0                   	// #0
    685c:	d2800300 	mov	x0, #0x18                  	// #24
    6860:	97fff9a4 	bl	4ef0 <fwp_heap_alloc>
    6864:	aa0003f3 	mov	x19, x0
    6868:	17ffffc8 	b	6788 <e161+0xb8>
    686c:	72003c3f 	tst	w1, #0xffff
    6870:	54fffc60 	b.eq	67fc <e161+0x12c>  // b.none
    6874:	aa1303e0 	mov	x0, x19
    6878:	97fffbd2 	bl	57c0 <fwp_rc_share>
    687c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6880:	aa1303e0 	mov	x0, x19
    6884:	a94153f3 	ldp	x19, x20, [sp, #16]
    6888:	a94363f7 	ldp	x23, x24, [sp, #48]
    688c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6890:	d65f03c0 	ret
    6894:	aa1403e0 	mov	x0, x20
    6898:	97fff7d6 	bl	47f0 <fwp_rc_forget_slot>
    689c:	17ffffdb 	b	6808 <e161+0x138>
    68a0:	97fff078 	bl	2a80 <fwp_trap_overflow.constprop.0>
    68a4:	97fff1e3 	bl	3030 <fwp_heap_oom>
    68a8:	d503201f 	nop
    68ac:	d503201f 	nop

00000000000068b0 <fwp_drop4>:
    68b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    68b4:	910003fd 	mov	x29, sp
    68b8:	a90153f3 	stp	x19, x20, [sp, #16]
    68bc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    68c0:	f90013f5 	str	x21, [sp, #32]
    68c4:	91174275 	add	x21, x19, #0x5d0
    68c8:	f949daa1 	ldr	x1, [x21, #5040]
    68cc:	f949eea2 	ldr	x2, [x21, #5080]
    68d0:	cb010001 	sub	x1, x0, x1
    68d4:	eb02403f 	cmp	x1, x2, lsl #16
    68d8:	54000382 	b.cs	6948 <fwp_drop4+0x98>  // b.hs, b.nlast
    68dc:	d350fc22 	lsr	x2, x1, #16
    68e0:	f949fea3 	ldr	x3, [x21, #5112]
    68e4:	8b020842 	add	x2, x2, x2, lsl #2
    68e8:	d37df042 	lsl	x2, x2, #3
    68ec:	8b020064 	add	x4, x3, x2
    68f0:	f9401094 	ldr	x20, [x4, #32]
    68f4:	b40002b4 	cbz	x20, 6948 <fwp_drop4+0x98>
    68f8:	38626862 	ldrb	w2, [x3, x2]
    68fc:	7100085f 	cmp	w2, #0x2
    6900:	540007a0 	b.eq	69f4 <fwp_drop4+0x144>  // b.none
    6904:	7100045f 	cmp	w2, #0x1
    6908:	54000201 	b.ne	6948 <fwp_drop4+0x98>  // b.any
    690c:	29430885 	ldp	w5, w2, [x4, #24]
    6910:	92403c21 	and	x1, x1, #0xffff
    6914:	9b057c21 	mul	x1, x1, x5
    6918:	d360fc21 	lsr	x1, x1, #32
    691c:	eb02003f 	cmp	x1, x2
    6920:	54000142 	b.cs	6948 <fwp_drop4+0x98>  // b.hs, b.nlast
    6924:	8b010294 	add	x20, x20, x1
    6928:	39400281 	ldrb	w1, [x20]
    692c:	340000e1 	cbz	w1, 6948 <fwp_drop4+0x98>
    6930:	7100043f 	cmp	w1, #0x1
    6934:	54000120 	b.eq	6958 <fwp_drop4+0xa8>  // b.none
    6938:	7103fc3f 	cmp	w1, #0xff
    693c:	540007c0 	b.eq	6a34 <fwp_drop4+0x184>  // b.none
    6940:	51000421 	sub	w1, w1, #0x1
    6944:	39000281 	strb	w1, [x20]
    6948:	a94153f3 	ldp	x19, x20, [sp, #16]
    694c:	f94013f5 	ldr	x21, [sp, #32]
    6950:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6954:	d65f03c0 	ret
    6958:	f9400001 	ldr	x1, [x0]
    695c:	b7f80581 	tbnz	x1, #63, 6a0c <fwp_drop4+0x15c>
    6960:	91174273 	add	x19, x19, #0x5d0
    6964:	f949da61 	ldr	x1, [x19, #5040]
    6968:	f949ee62 	ldr	x2, [x19, #5080]
    696c:	cb010001 	sub	x1, x0, x1
    6970:	eb02403f 	cmp	x1, x2, lsl #16
    6974:	54fffea2 	b.cs	6948 <fwp_drop4+0x98>  // b.hs, b.nlast
    6978:	d350fc22 	lsr	x2, x1, #16
    697c:	8b020842 	add	x2, x2, x2, lsl #2
    6980:	d37df042 	lsl	x2, x2, #3
    6984:	8b020065 	add	x5, x3, x2
    6988:	f94010a4 	ldr	x4, [x5, #32]
    698c:	b4fffde4 	cbz	x4, 6948 <fwp_drop4+0x98>
    6990:	38626862 	ldrb	w2, [x3, x2]
    6994:	7100085f 	cmp	w2, #0x2
    6998:	54000220 	b.eq	69dc <fwp_drop4+0x12c>  // b.none
    699c:	7100045f 	cmp	w2, #0x1
    69a0:	54fffd41 	b.ne	6948 <fwp_drop4+0x98>  // b.any
    69a4:	294308a3 	ldp	w3, w2, [x5, #24]
    69a8:	92403c21 	and	x1, x1, #0xffff
    69ac:	9b037c21 	mul	x1, x1, x3
    69b0:	d360fc21 	lsr	x1, x1, #32
    69b4:	eb02003f 	cmp	x1, x2
    69b8:	54fffc82 	b.cs	6948 <fwp_drop4+0x98>  // b.hs, b.nlast
    69bc:	8b010084 	add	x4, x4, x1
    69c0:	39400081 	ldrb	w1, [x4]
    69c4:	7100043f 	cmp	w1, #0x1
    69c8:	54fffc01 	b.ne	6948 <fwp_drop4+0x98>  // b.any
    69cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d0:	f94013f5 	ldr	x21, [sp, #32]
    69d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69d8:	17fff826 	b	4a70 <fwp_mem_free>
    69dc:	72003c3f 	tst	w1, #0xffff
    69e0:	54ffff00 	b.eq	69c0 <fwp_drop4+0x110>  // b.none
    69e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69e8:	f94013f5 	ldr	x21, [sp, #32]
    69ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69f0:	d65f03c0 	ret
    69f4:	72003c3f 	tst	w1, #0xffff
    69f8:	54fff980 	b.eq	6928 <fwp_drop4+0x78>  // b.none
    69fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a00:	f94013f5 	ldr	x21, [sp, #32]
    6a04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a08:	d65f03c0 	ret
    6a0c:	f9400414 	ldr	x20, [x0, #8]
    6a10:	97fffb91 	bl	5854 <fwp_rc_free_arr>
    6a14:	91174260 	add	x0, x19, #0x5d0
    6a18:	f949d801 	ldr	x1, [x0, #5040]
    6a1c:	f949ec00 	ldr	x0, [x0, #5080]
    6a20:	cb010281 	sub	x1, x20, x1
    6a24:	eb00403f 	cmp	x1, x0, lsl #16
    6a28:	54fff902 	b.cs	6948 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a2c:	aa1403e0 	mov	x0, x20
    6a30:	17ffffab 	b	68dc <fwp_drop4+0x2c>
    6a34:	ca544680 	eor	x0, x20, x20, lsr #17
    6a38:	91174273 	add	x19, x19, #0x5d0
    6a3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a40:	8b200e60 	add	x0, x19, w0, uxtb #3
    6a44:	f94a2400 	ldr	x0, [x0, #5192]
    6a48:	b5000080 	cbnz	x0, 6a58 <fwp_drop4+0x1a8>
    6a4c:	14000010 	b	6a8c <fwp_drop4+0x1dc>
    6a50:	f9400800 	ldr	x0, [x0, #16]
    6a54:	b40001c0 	cbz	x0, 6a8c <fwp_drop4+0x1dc>
    6a58:	f9400001 	ldr	x1, [x0]
    6a5c:	eb14003f 	cmp	x1, x20
    6a60:	54ffff81 	b.ne	6a50 <fwp_drop4+0x1a0>  // b.any
    6a64:	f9400401 	ldr	x1, [x0, #8]
    6a68:	d1000421 	sub	x1, x1, #0x1
    6a6c:	f9000401 	str	x1, [x0, #8]
    6a70:	f103f83f 	cmp	x1, #0xfe
    6a74:	54fff6a1 	b.ne	6948 <fwp_drop4+0x98>  // b.any
    6a78:	aa1403e0 	mov	x0, x20
    6a7c:	97fff75d 	bl	47f0 <fwp_rc_forget_slot>
    6a80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a84:	39000280 	strb	w0, [x20]
    6a88:	17ffffb0 	b	6948 <fwp_drop4+0x98>
    6a8c:	b0000020 	adrp	x0, b000 <__divti3+0x180>
    6a90:	91240000 	add	x0, x0, #0x900
    6a94:	97fff35b 	bl	3800 <fwp_trap>
    6a98:	d503201f 	nop
    6a9c:	d503201f 	nop

0000000000006aa0 <fwp_caps161>:
    6aa0:	34000041 	cbz	w1, 6aa8 <fwp_caps161+0x8>
    6aa4:	d65f03c0 	ret
    6aa8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6aac:	91174063 	add	x3, x3, #0x5d0
    6ab0:	f949d861 	ldr	x1, [x3, #5040]
    6ab4:	f949ec62 	ldr	x2, [x3, #5080]
    6ab8:	cb010001 	sub	x1, x0, x1
    6abc:	eb02403f 	cmp	x1, x2, lsl #16
    6ac0:	54ffff22 	b.cs	6aa4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ac4:	d350fc22 	lsr	x2, x1, #16
    6ac8:	f949fc65 	ldr	x5, [x3, #5112]
    6acc:	8b020842 	add	x2, x2, x2, lsl #2
    6ad0:	d37df042 	lsl	x2, x2, #3
    6ad4:	8b0200a4 	add	x4, x5, x2
    6ad8:	f9401083 	ldr	x3, [x4, #32]
    6adc:	b4fffe43 	cbz	x3, 6aa4 <fwp_caps161+0x4>
    6ae0:	386268a2 	ldrb	w2, [x5, x2]
    6ae4:	7100085f 	cmp	w2, #0x2
    6ae8:	540001c0 	b.eq	6b20 <fwp_caps161+0x80>  // b.none
    6aec:	7100045f 	cmp	w2, #0x1
    6af0:	54fffda1 	b.ne	6aa4 <fwp_caps161+0x4>  // b.any
    6af4:	29430885 	ldp	w5, w2, [x4, #24]
    6af8:	92403c21 	and	x1, x1, #0xffff
    6afc:	9b057c21 	mul	x1, x1, x5
    6b00:	d360fc21 	lsr	x1, x1, #32
    6b04:	eb02003f 	cmp	x1, x2
    6b08:	54fffce2 	b.cs	6aa4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6b0c:	8b010063 	add	x3, x3, x1
    6b10:	39400061 	ldrb	w1, [x3]
    6b14:	7100043f 	cmp	w1, #0x1
    6b18:	54fffc61 	b.ne	6aa4 <fwp_caps161+0x4>  // b.any
    6b1c:	17fff7d5 	b	4a70 <fwp_mem_free>
    6b20:	72003c3f 	tst	w1, #0xffff
    6b24:	54ffff60 	b.eq	6b10 <fwp_caps161+0x70>  // b.none
    6b28:	d65f03c0 	ret
    6b2c:	d503201f 	nop

0000000000006b30 <f12>:
    6b30:	d10483ff 	sub	sp, sp, #0x120
    6b34:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6b38:	f947f442 	ldr	x2, [x2, #4072]
    6b3c:	910103e8 	add	x8, sp, #0x40
    6b40:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6b44:	9102c3fd 	add	x29, sp, #0xb0
    6b48:	9100e3e9 	add	x9, sp, #0x38
    6b4c:	a90c53f3 	stp	x19, x20, [sp, #192]
    6b50:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6b54:	91174263 	add	x3, x19, #0x5d0
    6b58:	d00000d4 	adrp	x20, 20000 <__data_start>
    6b5c:	9101c284 	add	x4, x20, #0x70
    6b60:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6b64:	f0fffff6 	adrp	x22, 5000 <fwp_heap_alloc+0x110>
    6b68:	aa0003f5 	mov	x21, x0
    6b6c:	f949d861 	ldr	x1, [x3, #5040]
    6b70:	a90e63f7 	stp	x23, x24, [sp, #224]
    6b74:	d00000d7 	adrp	x23, 20000 <__data_start>
    6b78:	f949ec65 	ldr	x5, [x3, #5080]
    6b7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6b80:	910042f7 	add	x23, x23, #0x10
    6b84:	a91073fb 	stp	x27, x28, [sp, #256]
    6b88:	9100e2f7 	add	x23, x23, #0x38
    6b8c:	cb0102e1 	sub	x1, x23, x1
    6b90:	f9418886 	ldr	x6, [x4, #784]
    6b94:	fd008be8 	str	d8, [sp, #272]
    6b98:	f9400047 	ldr	x7, [x2]
    6b9c:	f90057e7 	str	x7, [sp, #168]
    6ba0:	d2800007 	mov	x7, #0x0                   	// #0
    6ba4:	913ec2c2 	add	x2, x22, #0xfb0
    6ba8:	12800007 	mov	w7, #0xffffffff            	// #-1
    6bac:	a90123e9 	stp	x9, x8, [sp, #16]
    6bb0:	b9003be7 	str	w7, [sp, #56]
    6bb4:	a9040be6 	stp	x6, x2, [sp, #64]
    6bb8:	f9002be9 	str	x9, [sp, #80]
    6bbc:	f9018888 	str	x8, [x4, #784]
    6bc0:	eb05403f 	cmp	x1, x5, lsl #16
    6bc4:	54000342 	b.cs	6c2c <f12+0xfc>  // b.hs, b.nlast
    6bc8:	d350fc20 	lsr	x0, x1, #16
    6bcc:	f949fc64 	ldr	x4, [x3, #5112]
    6bd0:	8b000800 	add	x0, x0, x0, lsl #2
    6bd4:	d37df002 	lsl	x2, x0, #3
    6bd8:	8b020083 	add	x3, x4, x2
    6bdc:	f9401060 	ldr	x0, [x3, #32]
    6be0:	b4000260 	cbz	x0, 6c2c <f12+0xfc>
    6be4:	38626882 	ldrb	w2, [x4, x2]
    6be8:	7100085f 	cmp	w2, #0x2
    6bec:	54007840 	b.eq	7af4 <f12+0xfc4>  // b.none
    6bf0:	7100045f 	cmp	w2, #0x1
    6bf4:	540001c1 	b.ne	6c2c <f12+0xfc>  // b.any
    6bf8:	29430864 	ldp	w4, w2, [x3, #24]
    6bfc:	92403c21 	and	x1, x1, #0xffff
    6c00:	9b047c21 	mul	x1, x1, x4
    6c04:	d360fc21 	lsr	x1, x1, #32
    6c08:	eb02003f 	cmp	x1, x2
    6c0c:	54000102 	b.cs	6c2c <f12+0xfc>  // b.hs, b.nlast
    6c10:	8b010000 	add	x0, x0, x1
    6c14:	39400001 	ldrb	w1, [x0]
    6c18:	340000a1 	cbz	w1, 6c2c <f12+0xfc>
    6c1c:	7103f43f 	cmp	w1, #0xfd
    6c20:	54007fe8 	b.hi	7c1c <f12+0x10ec>  // b.pmore
    6c24:	11000421 	add	w1, w1, #0x1
    6c28:	39000001 	strb	w1, [x0]
    6c2c:	aa1703e0 	mov	x0, x23
    6c30:	97fffc00 	bl	5c30 <fwp_closure_drop>
    6c34:	b40076b5 	cbz	x21, 7b08 <f12+0xfd8>
    6c38:	aa1503e0 	mov	x0, x21
    6c3c:	d2800017 	mov	x23, #0x0                   	// #0
    6c40:	f9400800 	ldr	x0, [x0, #16]
    6c44:	910006f7 	add	x23, x23, #0x1
    6c48:	b5ffffc0 	cbnz	x0, 6c40 <f12+0x110>
    6c4c:	52800000 	mov	w0, #0x0                   	// #0
    6c50:	97fff268 	bl	35f0 <descent_phase_step>
    6c54:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6c58:	eb0002ff 	cmp	x23, x0
    6c5c:	54008208 	b.hi	7c9c <f12+0x116c>  // b.pmore
    6c60:	9101c298 	add	x24, x20, #0x70
    6c64:	b9434700 	ldr	w0, [x24, #836]
    6c68:	34007320 	cbz	w0, 7acc <f12+0xf9c>
    6c6c:	9101c280 	add	x0, x20, #0x70
    6c70:	f9404818 	ldr	x24, [x0, #144]
    6c74:	f9407419 	ldr	x25, [x0, #232]
    6c78:	eb18033f 	cmp	x25, x24
    6c7c:	540071aa 	b.ge	7ab0 <f12+0xf80>  // b.tcont
    6c80:	f9403a81 	ldr	x1, [x20, #112]
    6c84:	8b190720 	add	x0, x25, x25, lsl #1
    6c88:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6c8c:	8b000b20 	add	x0, x25, x0, lsl #2
    6c90:	8b000c20 	add	x0, x1, x0, lsl #3
    6c94:	d503201f 	nop
    6c98:	b9400401 	ldr	w1, [x0, #4]
    6c9c:	35000081 	cbnz	w1, 6cac <f12+0x17c>
    6ca0:	b9400001 	ldr	w1, [x0]
    6ca4:	6b02003f 	cmp	w1, w2
    6ca8:	54007049 	b.ls	7ab0 <f12+0xf80>  // b.plast
    6cac:	91000739 	add	x25, x25, #0x1
    6cb0:	9101a000 	add	x0, x0, #0x68
    6cb4:	eb18033f 	cmp	x25, x24
    6cb8:	54ffff01 	b.ne	6c98 <f12+0x168>  // b.any
    6cbc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6cc0:	eb00031f 	cmp	x24, x0
    6cc4:	54007f2c 	b.gt	7ca8 <f12+0x1178>
    6cc8:	9101c280 	add	x0, x20, #0x70
    6ccc:	f9403a9c 	ldr	x28, [x20, #112]
    6cd0:	f9407000 	ldr	x0, [x0, #224]
    6cd4:	eb18001f 	cmp	x0, x24
    6cd8:	54000161 	b.ne	6d04 <f12+0x1d4>  // b.any
    6cdc:	b5007478 	cbnz	x24, 7b68 <f12+0x1038>
    6ce0:	d2800d01 	mov	x1, #0x68                  	// #104
    6ce4:	d280003a 	mov	x26, #0x1                   	// #1
    6ce8:	aa1c03e0 	mov	x0, x28
    6cec:	97ffeee1 	bl	2870 <realloc@plt>
    6cf0:	aa0003fc 	mov	x28, x0
    6cf4:	b4006c60 	cbz	x0, 7a80 <f12+0xf50>
    6cf8:	9101c280 	add	x0, x20, #0x70
    6cfc:	f9003a9c 	str	x28, [x20, #112]
    6d00:	f900701a 	str	x26, [x0, #224]
    6d04:	8b180700 	add	x0, x24, x24, lsl #1
    6d08:	9101c281 	add	x1, x20, #0x70
    6d0c:	4f000400 	movi	v0.4s, #0x0
    6d10:	91000702 	add	x2, x24, #0x1
    6d14:	8b000b00 	add	x0, x24, x0, lsl #2
    6d18:	f9004822 	str	x2, [x1, #144]
    6d1c:	8b000f80 	add	x0, x28, x0, lsl #3
    6d20:	f900301f 	str	xzr, [x0, #96]
    6d24:	ad000000 	stp	q0, q0, [x0]
    6d28:	ad010000 	stp	q0, q0, [x0, #32]
    6d2c:	ad020000 	stp	q0, q0, [x0, #64]
    6d30:	8b190721 	add	x1, x25, x25, lsl #1
    6d34:	b0000020 	adrp	x0, b000 <__divti3+0x180>
    6d38:	91224000 	add	x0, x0, #0x890
    6d3c:	8b010b38 	add	x24, x25, x1, lsl #2
    6d40:	8b180f98 	add	x24, x28, x24, lsl #3
    6d44:	f900331f 	str	xzr, [x24, #96]
    6d48:	97ffef32 	bl	2a10 <getenv@plt>
    6d4c:	b4000080 	cbz	x0, 6d5c <f12+0x22c>
    6d50:	39400001 	ldrb	w1, [x0]
    6d54:	7100c03f 	cmp	w1, #0x30
    6d58:	540030a0 	b.eq	736c <f12+0x83c>  // b.none
    6d5c:	9101c280 	add	x0, x20, #0x70
    6d60:	f9406801 	ldr	x1, [x0, #208]
    6d64:	b5006e41 	cbnz	x1, 7b2c <f12+0xffc>
    6d68:	9101c281 	add	x1, x20, #0x70
    6d6c:	2f000400 	mvni	v0.2s, #0x0
    6d70:	b9400302 	ldr	w2, [x24]
    6d74:	52800024 	mov	w4, #0x1                   	// #1
    6d78:	91000723 	add	x3, x25, #0x1
    6d7c:	a900df17 	stp	x23, x23, [x24, #8]
    6d80:	0b040042 	add	w2, w2, w4
    6d84:	f9418820 	ldr	x0, [x1, #784]
    6d88:	29001302 	stp	w2, w4, [x24]
    6d8c:	f9002b1f 	str	xzr, [x24, #80]
    6d90:	f9007423 	str	x3, [x1, #232]
    6d94:	fd002f00 	str	d0, [x24, #88]
    6d98:	b40078e0 	cbz	x0, 7cb4 <f12+0x1184>
    6d9c:	913ec2d6 	add	x22, x22, #0xfb0
    6da0:	14000003 	b	6dac <f12+0x27c>
    6da4:	f9400000 	ldr	x0, [x0]
    6da8:	b4007860 	cbz	x0, 7cb4 <f12+0x1184>
    6dac:	f9400401 	ldr	x1, [x0, #8]
    6db0:	eb16003f 	cmp	x1, x22
    6db4:	54ffff81 	b.ne	6da4 <f12+0x274>  // b.any
    6db8:	f9400800 	ldr	x0, [x0, #16]
    6dbc:	2a1903e4 	mov	w4, w25
    6dc0:	b9400001 	ldr	w1, [x0]
    6dc4:	f9002b00 	str	x0, [x24, #80]
    6dc8:	b9005f01 	str	w1, [x24, #92]
    6dcc:	37f80081 	tbnz	w1, #31, 6ddc <f12+0x2ac>
    6dd0:	52800d05 	mov	w5, #0x68                  	// #104
    6dd4:	9b257021 	smaddl	x1, w1, w5, x28
    6dd8:	b9005839 	str	w25, [x1, #88]
    6ddc:	d3707c42 	ubfiz	x2, x2, #16, #32
    6de0:	b9000004 	str	w4, [x0]
    6de4:	aa030057 	orr	x23, x2, x3
    6de8:	52800020 	mov	w0, #0x1                   	// #1
    6dec:	97fff201 	bl	35f0 <descent_phase_step>
    6df0:	aa1503e0 	mov	x0, x21
    6df4:	d2800002 	mov	x2, #0x0                   	// #0
    6df8:	b4006155 	cbz	x21, 7a20 <f12+0xef0>
    6dfc:	d503201f 	nop
    6e00:	f9400800 	ldr	x0, [x0, #16]
    6e04:	91000442 	add	x2, x2, #0x1
    6e08:	b5ffffc0 	cbnz	x0, 6e00 <f12+0x2d0>
    6e0c:	aa1503e1 	mov	x1, x21
    6e10:	f9400821 	ldr	x1, [x1, #16]
    6e14:	91000400 	add	x0, x0, #0x1
    6e18:	b5ffffc1 	cbnz	x1, 6e10 <f12+0x2e0>
    6e1c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6e20:	eb01001f 	cmp	x0, x1
    6e24:	540074e8 	b.hi	7cc0 <f12+0x1190>  // b.pmore
    6e28:	f100005f 	cmp	x2, #0x0
    6e2c:	54005fad 	b.le	7a20 <f12+0xef0>
    6e30:	eb00005f 	cmp	x2, x0
    6e34:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6e38:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    6e3c:	eb0102df 	cmp	x22, x1
    6e40:	54007408 	b.hi	7cc0 <f12+0x1190>  // b.pmore
    6e44:	d37ffad9 	lsl	x25, x22, #1
    6e48:	52800041 	mov	w1, #0x2                   	// #2
    6e4c:	91000720 	add	x0, x25, #0x1
    6e50:	d37df000 	lsl	x0, x0, #3
    6e54:	97fff827 	bl	4ef0 <fwp_heap_alloc>
    6e58:	aa0003f8 	mov	x24, x0
    6e5c:	91174261 	add	x1, x19, #0x5d0
    6e60:	aa0103e0 	mov	x0, x1
    6e64:	f9000319 	str	x25, [x24]
    6e68:	f949d821 	ldr	x1, [x1, #5040]
    6e6c:	f949ec00 	ldr	x0, [x0, #5080]
    6e70:	cb010301 	sub	x1, x24, x1
    6e74:	eb00403f 	cmp	x1, x0, lsl #16
    6e78:	54006242 	b.cs	7ac0 <f12+0xf90>  // b.hs, b.nlast
    6e7c:	91174262 	add	x2, x19, #0x5d0
    6e80:	d350fc20 	lsr	x0, x1, #16
    6e84:	8b000800 	add	x0, x0, x0, lsl #2
    6e88:	f949fc43 	ldr	x3, [x2, #5112]
    6e8c:	d37df002 	lsl	x2, x0, #3
    6e90:	8b020060 	add	x0, x3, x2
    6e94:	f9401019 	ldr	x25, [x0, #32]
    6e98:	b4000259 	cbz	x25, 6ee0 <f12+0x3b0>
    6e9c:	38626862 	ldrb	w2, [x3, x2]
    6ea0:	7100085f 	cmp	w2, #0x2
    6ea4:	54006220 	b.eq	7ae8 <f12+0xfb8>  // b.none
    6ea8:	7100045f 	cmp	w2, #0x1
    6eac:	540001a1 	b.ne	6ee0 <f12+0x3b0>  // b.any
    6eb0:	29430002 	ldp	w2, w0, [x0, #24]
    6eb4:	92403c21 	and	x1, x1, #0xffff
    6eb8:	9b027c21 	mul	x1, x1, x2
    6ebc:	d360fc21 	lsr	x1, x1, #32
    6ec0:	eb00003f 	cmp	x1, x0
    6ec4:	540000e2 	b.cs	6ee0 <f12+0x3b0>  // b.hs, b.nlast
    6ec8:	8b010339 	add	x25, x25, x1
    6ecc:	39400320 	ldrb	w0, [x25]
    6ed0:	7103fc1f 	cmp	w0, #0xff
    6ed4:	54006920 	b.eq	7bf8 <f12+0x10c8>  // b.none
    6ed8:	52800020 	mov	w0, #0x1                   	// #1
    6edc:	39000320 	strb	w0, [x25]
    6ee0:	b4000236 	cbz	x22, 6f24 <f12+0x3f4>
    6ee4:	d3607ee4 	lsl	x4, x23, #32
    6ee8:	aa1503e2 	mov	x2, x21
    6eec:	f94006a5 	ldr	x5, [x21, #8]
    6ef0:	aa0403e3 	mov	x3, x4
    6ef4:	91002300 	add	x0, x24, #0x8
    6ef8:	d2800001 	mov	x1, #0x0                   	// #0
    6efc:	14000005 	b	6f10 <f12+0x3e0>
    6f00:	f9400445 	ldr	x5, [x2, #8]
    6f04:	ab040023 	adds	x3, x1, x4
    6f08:	91004000 	add	x0, x0, #0x10
    6f0c:	54006f06 	b.vs	7cec <f12+0x11bc>
    6f10:	a9000c05 	stp	x5, x3, [x0]
    6f14:	91000421 	add	x1, x1, #0x1
    6f18:	f9400842 	ldr	x2, [x2, #16]
    6f1c:	eb0102df 	cmp	x22, x1
    6f20:	54ffff08 	b.hi	6f00 <f12+0x3d0>  // b.pmore
    6f24:	f9400300 	ldr	x0, [x24]
    6f28:	f100041f 	cmp	x0, #0x1
    6f2c:	54005cc9 	b.ls	7ac4 <f12+0xf94>  // b.plast
    6f30:	d341fc00 	lsr	x0, x0, #1
    6f34:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    6f38:	d1000401 	sub	x1, x0, #0x1
    6f3c:	eb02003f 	cmp	x1, x2
    6f40:	54006c08 	b.hi	7cc0 <f12+0x1190>  // b.pmore
    6f44:	d37ff83c 	lsl	x28, x1, #1
    6f48:	b4005be1 	cbz	x1, 7ac4 <f12+0xf94>
    6f4c:	d1002301 	sub	x1, x24, #0x8
    6f50:	91002316 	add	x22, x24, #0x8
    6f54:	8b001039 	add	x25, x1, x0, lsl #4
    6f58:	f94006c0 	ldr	x0, [x22, #8]
    6f5c:	f9400ec1 	ldr	x1, [x22, #24]
    6f60:	fd4002c0 	ldr	d0, [x22]
    6f64:	fd400ac1 	ldr	d1, [x22, #16]
    6f68:	97fff962 	bl	54f0 <w107>
    6f6c:	a90006c0 	stp	x0, x1, [x22]
    6f70:	910042d6 	add	x22, x22, #0x10
    6f74:	eb1902df 	cmp	x22, x25
    6f78:	54ffff01 	b.ne	6f58 <f12+0x428>  // b.any
    6f7c:	f900031c 	str	x28, [x24]
    6f80:	aa1803e0 	mov	x0, x24
    6f84:	93407efb 	sxtw	x27, w23
    6f88:	97fff99e 	bl	5600 <w164.constprop.0>
    6f8c:	aa1803e0 	mov	x0, x24
    6f90:	aa0103f8 	mov	x24, x1
    6f94:	97fffe47 	bl	68b0 <fwp_drop4>
    6f98:	52800040 	mov	w0, #0x2                   	// #2
    6f9c:	97fff195 	bl	35f0 <descent_phase_step>
    6fa0:	aa1b03e0 	mov	x0, x27
    6fa4:	97fff2e3 	bl	3b30 <fwp_tape_of>
    6fa8:	f9403002 	ldr	x2, [x0, #96]
    6fac:	aa0003e8 	mov	x8, x0
    6fb0:	b5006702 	cbnz	x2, 7c90 <f12+0x1160>
    6fb4:	97ffeff7 	bl	2f90 <fwp_tape_unlink_scope>
    6fb8:	b900051f 	str	wzr, [x8, #4]
    6fbc:	a9428517 	ldp	x23, x1, [x8, #40]
    6fc0:	f90007e1 	str	x1, [sp, #8]
    6fc4:	b9400103 	ldr	w3, [x8]
    6fc8:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    6fcc:	a9409d1c 	ldp	x28, x7, [x8, #8]
    6fd0:	a941d90a 	ldp	x10, x22, [x8, #24]
    6fd4:	a943e919 	ldp	x25, x26, [x8, #56]
    6fd8:	f9402502 	ldr	x2, [x8, #72]
    6fdc:	6b00007f 	cmp	w3, w0
    6fe0:	54000108 	b.hi	7000 <f12+0x4d0>  // b.pmore
    6fe4:	9101c283 	add	x3, x20, #0x70
    6fe8:	92403f60 	and	x0, x27, #0xffff
    6fec:	d1000400 	sub	x0, x0, #0x1
    6ff0:	f9407469 	ldr	x9, [x3, #232]
    6ff4:	eb09001f 	cmp	x0, x9
    6ff8:	5400004a 	b.ge	7000 <f12+0x4d0>  // b.tcont
    6ffc:	f9007460 	str	x0, [x3, #232]
    7000:	4f000400 	movi	v0.4s, #0x0
    7004:	9101c289 	add	x9, x20, #0x70
    7008:	9101c3e1 	add	x1, sp, #0x70
    700c:	f9000d1f 	str	xzr, [x8, #24]
    7010:	f90013e1 	str	x1, [sp, #32]
    7014:	910163e0 	add	x0, sp, #0x58
    7018:	f941892b 	ldr	x11, [x9, #784]
    701c:	3c808100 	stur	q0, [x8, #8]
    7020:	b0ffffe3 	adrp	x3, 4000 <fwp_heap_report+0x60>
    7024:	ad010100 	stp	q0, q0, [x8, #32]
    7028:	910e0063 	add	x3, x3, #0x380
    702c:	a906dbe1 	stp	x1, x22, [sp, #104]
    7030:	f94007e1 	ldr	x1, [sp, #8]
    7034:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    7038:	a9058feb 	stp	x11, x3, [sp, #88]
    703c:	f9003ff7 	str	x23, [sp, #120]
    7040:	f90043e1 	str	x1, [sp, #128]
    7044:	a908ebf9 	stp	x25, x26, [sp, #136]
    7048:	a9098bea 	stp	x10, x2, [sp, #152]
    704c:	f9018920 	str	x0, [x9, #784]
    7050:	b7f85658 	tbnz	x24, #63, 7b18 <f12+0xfe8>
    7054:	eb98837f 	cmp	x27, x24, asr #32
    7058:	540060e1 	b.ne	7c74 <f12+0x1144>  // b.any
    705c:	92407f03 	and	x3, x24, #0xffffffff
    7060:	eb3840ff 	cmp	x7, w24, uxtw
    7064:	540060ed 	b.le	7c80 <f12+0x1150>
    7068:	eb1c007f 	cmp	x3, x28
    706c:	9a83b79b 	csinc	x27, x28, x3, lt	// lt = tstop
    7070:	eb1b005f 	cmp	x2, x27
    7074:	54004f6a 	b.ge	7a60 <f12+0xf30>  // b.tcont
    7078:	f100005f 	cmp	x2, #0x0
    707c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7080:	9a9b1042 	csel	x2, x2, x27, ne	// ne = any
    7084:	14000004 	b	7094 <f12+0x564>
    7088:	eb01005f 	cmp	x2, x1
    708c:	d37ff842 	lsl	x2, x2, #1
    7090:	9a9bd042 	csel	x2, x2, x27, le
    7094:	eb1b005f 	cmp	x2, x27
    7098:	54ffff8b 	b.lt	7088 <f12+0x558>  // b.tstop
    709c:	b40058ba 	cbz	x26, 7bb0 <f12+0x1080>
    70a0:	aa1a03e0 	mov	x0, x26
    70a4:	d37df041 	lsl	x1, x2, #3
    70a8:	f90017e2 	str	x2, [sp, #40]
    70ac:	97ffedf1 	bl	2870 <realloc@plt>
    70b0:	f94017e2 	ldr	x2, [sp, #40]
    70b4:	aa0003fa 	mov	x26, x0
    70b8:	b4004d5a 	cbz	x26, 7a60 <f12+0xf30>
    70bc:	f9004bfa 	str	x26, [sp, #144]
    70c0:	f90053e2 	str	x2, [sp, #160]
    70c4:	b50015bb 	cbnz	x27, 7378 <f12+0x848>
    70c8:	b7f800d8 	tbnz	x24, #63, 70e0 <f12+0x5b0>
    70cc:	92407f04 	and	x4, x24, #0xffffffff
    70d0:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    70d4:	fc647b40 	ldr	d0, [x26, x4, lsl #3]
    70d8:	1e612800 	fadd	d0, d0, d1
    70dc:	fc247b40 	str	d0, [x26, x4, lsl #3]
    70e0:	9101c281 	add	x1, x20, #0x70
    70e4:	cb1c0364 	sub	x4, x27, x28
    70e8:	52800060 	mov	w0, #0x3                   	// #3
    70ec:	a9428827 	ldp	x7, x2, [x1, #40]
    70f0:	8b070084 	add	x4, x4, x7
    70f4:	8b1c0042 	add	x2, x2, x28
    70f8:	a9028824 	stp	x4, x2, [x1, #40]
    70fc:	97fff13d 	bl	35f0 <descent_phase_step>
    7100:	d1000763 	sub	x3, x27, #0x1
    7104:	d1000784 	sub	x4, x28, #0x1
    7108:	eb03039f 	cmp	x28, x3
    710c:	540003cc 	b.gt	7184 <f12+0x654>
    7110:	fc637b40 	ldr	d0, [x26, x3, lsl #3]
    7114:	1e602008 	fcmp	d0, #0.0
    7118:	54000300 	b.eq	7178 <f12+0x648>  // b.none
    711c:	cb1c0be0 	neg	x0, x28, lsl #2
    7120:	cb1c03e2 	neg	x2, x28
    7124:	8b0002c1 	add	x1, x22, x0
    7128:	b8637821 	ldr	w1, [x1, x3, lsl #2]
    712c:	37f80121 	tbnz	w1, #31, 7150 <f12+0x620>
    7130:	f94007e5 	ldr	x5, [sp, #8]
    7134:	93407c21 	sxtw	x1, w1
    7138:	8b020ca7 	add	x7, x5, x2, lsl #3
    713c:	fc617b41 	ldr	d1, [x26, x1, lsl #3]
    7140:	fc6378e2 	ldr	d2, [x7, x3, lsl #3]
    7144:	1e620802 	fmul	d2, d0, d2
    7148:	1e622821 	fadd	d1, d1, d2
    714c:	fc217b41 	str	d1, [x26, x1, lsl #3]
    7150:	8b0002e0 	add	x0, x23, x0
    7154:	b8637800 	ldr	w0, [x0, x3, lsl #2]
    7158:	37f80100 	tbnz	w0, #31, 7178 <f12+0x648>
    715c:	8b020f22 	add	x2, x25, x2, lsl #3
    7160:	93407c00 	sxtw	x0, w0
    7164:	fc637842 	ldr	d2, [x2, x3, lsl #3]
    7168:	fc607b41 	ldr	d1, [x26, x0, lsl #3]
    716c:	1e620800 	fmul	d0, d0, d2
    7170:	1e602820 	fadd	d0, d1, d0
    7174:	fc207b40 	str	d0, [x26, x0, lsl #3]
    7178:	d1000463 	sub	x3, x3, #0x1
    717c:	eb04007f 	cmp	x3, x4
    7180:	54fffc81 	b.ne	7110 <f12+0x5e0>  // b.any
    7184:	52800080 	mov	w0, #0x4                   	// #4
    7188:	97fff11a 	bl	35f0 <descent_phase_step>
    718c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7190:	eb00039f 	cmp	x28, x0
    7194:	540059e8 	b.hi	7cd0 <f12+0x11a0>  // b.pmore
    7198:	91000780 	add	x0, x28, #0x1
    719c:	52800041 	mov	w1, #0x2                   	// #2
    71a0:	d37df000 	lsl	x0, x0, #3
    71a4:	97fff753 	bl	4ef0 <fwp_heap_alloc>
    71a8:	aa0003e2 	mov	x2, x0
    71ac:	aa0003f6 	mov	x22, x0
    71b0:	d2800001 	mov	x1, #0x0                   	// #0
    71b4:	f800845c 	str	x28, [x2], #8
    71b8:	b40000fc 	cbz	x28, 71d4 <f12+0x6a4>
    71bc:	d503201f 	nop
    71c0:	f8617b40 	ldr	x0, [x26, x1, lsl #3]
    71c4:	f8217840 	str	x0, [x2, x1, lsl #3]
    71c8:	91000421 	add	x1, x1, #0x1
    71cc:	eb01039f 	cmp	x28, x1
    71d0:	54ffff81 	b.ne	71c0 <f12+0x690>  // b.any
    71d4:	528000a0 	mov	w0, #0x5                   	// #5
    71d8:	97fff106 	bl	35f0 <descent_phase_step>
    71dc:	f94013e0 	ldr	x0, [sp, #32]
    71e0:	9101c281 	add	x1, x20, #0x70
    71e4:	f9402ff8 	ldr	x24, [sp, #88]
    71e8:	f9018838 	str	x24, [x1, #784]
    71ec:	97fff465 	bl	4380 <fwp_tape_buffers_release>
    71f0:	528000c0 	mov	w0, #0x6                   	// #6
    71f4:	97fff0ff 	bl	35f0 <descent_phase_step>
    71f8:	91174262 	add	x2, x19, #0x5d0
    71fc:	f949d841 	ldr	x1, [x2, #5040]
    7200:	f949ec40 	ldr	x0, [x2, #5080]
    7204:	cb0102c1 	sub	x1, x22, x1
    7208:	eb00403f 	cmp	x1, x0, lsl #16
    720c:	54000322 	b.cs	7270 <f12+0x740>  // b.hs, b.nlast
    7210:	d350fc20 	lsr	x0, x1, #16
    7214:	f949fc43 	ldr	x3, [x2, #5112]
    7218:	8b000800 	add	x0, x0, x0, lsl #2
    721c:	d37df002 	lsl	x2, x0, #3
    7220:	8b020060 	add	x0, x3, x2
    7224:	f9401017 	ldr	x23, [x0, #32]
    7228:	b4000257 	cbz	x23, 7270 <f12+0x740>
    722c:	38626862 	ldrb	w2, [x3, x2]
    7230:	7100085f 	cmp	w2, #0x2
    7234:	54004760 	b.eq	7b20 <f12+0xff0>  // b.none
    7238:	7100045f 	cmp	w2, #0x1
    723c:	540001a1 	b.ne	7270 <f12+0x740>  // b.any
    7240:	29430002 	ldp	w2, w0, [x0, #24]
    7244:	92403c21 	and	x1, x1, #0xffff
    7248:	9b027c21 	mul	x1, x1, x2
    724c:	d360fc21 	lsr	x1, x1, #32
    7250:	eb00003f 	cmp	x1, x0
    7254:	540000e2 	b.cs	7270 <f12+0x740>  // b.hs, b.nlast
    7258:	8b0102f7 	add	x23, x23, x1
    725c:	394002e0 	ldrb	w0, [x23]
    7260:	7103fc1f 	cmp	w0, #0xff
    7264:	54004d00 	b.eq	7c04 <f12+0x10d4>  // b.none
    7268:	52800020 	mov	w0, #0x1                   	// #1
    726c:	390002e0 	strb	w0, [x23]
    7270:	f9400fe0 	ldr	x0, [sp, #24]
    7274:	eb00031f 	cmp	x24, x0
    7278:	54005381 	b.ne	7ce8 <f12+0x11b8>  // b.any
    727c:	f9400be0 	ldr	x0, [sp, #16]
    7280:	9101c294 	add	x20, x20, #0x70
    7284:	f94023e1 	ldr	x1, [sp, #64]
    7288:	f9018a81 	str	x1, [x20, #784]
    728c:	97fffb49 	bl	5fb0 <fwp_tape_scope_release>
    7290:	f94002c0 	ldr	x0, [x22]
    7294:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    7298:	b7f83700 	tbnz	x0, #63, 7978 <f12+0xe48>
    729c:	91174262 	add	x2, x19, #0x5d0
    72a0:	f949d840 	ldr	x0, [x2, #5040]
    72a4:	f949ec41 	ldr	x1, [x2, #5080]
    72a8:	cb0002c0 	sub	x0, x22, x0
    72ac:	eb01401f 	cmp	x0, x1, lsl #16
    72b0:	54003642 	b.cs	7978 <f12+0xe48>  // b.hs, b.nlast
    72b4:	d350fc01 	lsr	x1, x0, #16
    72b8:	f949fc44 	ldr	x4, [x2, #5112]
    72bc:	8b010821 	add	x1, x1, x1, lsl #2
    72c0:	d37df021 	lsl	x1, x1, #3
    72c4:	8b010083 	add	x3, x4, x1
    72c8:	f9401062 	ldr	x2, [x3, #32]
    72cc:	b4003562 	cbz	x2, 7978 <f12+0xe48>
    72d0:	38616881 	ldrb	w1, [x4, x1]
    72d4:	7100083f 	cmp	w1, #0x2
    72d8:	540034a0 	b.eq	796c <f12+0xe3c>  // b.none
    72dc:	7100043f 	cmp	w1, #0x1
    72e0:	540034c1 	b.ne	7978 <f12+0xe48>  // b.any
    72e4:	29430464 	ldp	w4, w1, [x3, #24]
    72e8:	92403c00 	and	x0, x0, #0xffff
    72ec:	9b047c00 	mul	x0, x0, x4
    72f0:	d360fc00 	lsr	x0, x0, #32
    72f4:	eb01001f 	cmp	x0, x1
    72f8:	54003402 	b.cs	7978 <f12+0xe48>  // b.hs, b.nlast
    72fc:	8b000042 	add	x2, x2, x0
    7300:	39400040 	ldrb	w0, [x2]
    7304:	7100041f 	cmp	w0, #0x1
    7308:	54003381 	b.ne	7978 <f12+0xe48>  // b.any
    730c:	aa1603fa 	mov	x26, x22
    7310:	d2800000 	mov	x0, #0x0                   	// #0
    7314:	f9000ff6 	str	x22, [sp, #24]
    7318:	f9400fe1 	ldr	x1, [sp, #24]
    731c:	91002023 	add	x3, x1, #0x8
    7320:	d2800001 	mov	x1, #0x0                   	// #0
    7324:	b4000357 	cbz	x23, 738c <f12+0x85c>
    7328:	b0000022 	adrp	x2, c000 <_IO_stdin_used+0xa60>
    732c:	910022c5 	add	x5, x22, #0x8
    7330:	fd41cc41 	ldr	d1, [x2, #920]
    7334:	14000009 	b	7358 <f12+0x828>
    7338:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    733c:	f9400342 	ldr	x2, [x26]
    7340:	1e600820 	fmul	d0, d1, d0
    7344:	b7f84cc2 	tbnz	x2, #63, 7cdc <f12+0x11ac>
    7348:	91000421 	add	x1, x1, #0x1
    734c:	fc008460 	str	d0, [x3], #8
    7350:	eb0102ff 	cmp	x23, x1
    7354:	540001c0 	b.eq	738c <f12+0x85c>  // b.none
    7358:	f94002c4 	ldr	x4, [x22]
    735c:	aa0503e2 	mov	x2, x5
    7360:	b6fffec4 	tbz	x4, #63, 7338 <f12+0x808>
    7364:	f9400ac2 	ldr	x2, [x22, #16]
    7368:	17fffff4 	b	7338 <f12+0x808>
    736c:	39400400 	ldrb	w0, [x0, #1]
    7370:	34ffcfc0 	cbz	w0, 6d68 <f12+0x238>
    7374:	17fffe7a 	b	6d5c <f12+0x22c>
    7378:	d37df362 	lsl	x2, x27, #3
    737c:	aa1a03e0 	mov	x0, x26
    7380:	52800001 	mov	w1, #0x0                   	// #0
    7384:	97ffed33 	bl	2850 <memset@plt>
    7388:	17ffff50 	b	70c8 <f12+0x598>
    738c:	97fffd49 	bl	68b0 <fwp_drop4>
    7390:	aa1503e1 	mov	x1, x21
    7394:	d2800002 	mov	x2, #0x0                   	// #0
    7398:	b40041b5 	cbz	x21, 7bcc <f12+0x109c>
    739c:	d503201f 	nop
    73a0:	f9400821 	ldr	x1, [x1, #16]
    73a4:	91000442 	add	x2, x2, #0x1
    73a8:	b5ffffc1 	cbnz	x1, 73a0 <f12+0x870>
    73ac:	f9400343 	ldr	x3, [x26]
    73b0:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    73b4:	b7f82a63 	tbnz	x3, #63, 7900 <f12+0xdd0>
    73b8:	91174261 	add	x1, x19, #0x5d0
    73bc:	f9400fe4 	ldr	x4, [sp, #24]
    73c0:	f949d820 	ldr	x0, [x1, #5040]
    73c4:	f949ec21 	ldr	x1, [x1, #5080]
    73c8:	cb000080 	sub	x0, x4, x0
    73cc:	eb01401f 	cmp	x0, x1, lsl #16
    73d0:	54002982 	b.cs	7900 <f12+0xdd0>  // b.hs, b.nlast
    73d4:	91174264 	add	x4, x19, #0x5d0
    73d8:	d350fc01 	lsr	x1, x0, #16
    73dc:	8b010821 	add	x1, x1, x1, lsl #2
    73e0:	f949fc86 	ldr	x6, [x4, #5112]
    73e4:	d37df021 	lsl	x1, x1, #3
    73e8:	8b0100c5 	add	x5, x6, x1
    73ec:	f94010a4 	ldr	x4, [x5, #32]
    73f0:	b4002864 	cbz	x4, 78fc <f12+0xdcc>
    73f4:	386168c1 	ldrb	w1, [x6, x1]
    73f8:	7100083f 	cmp	w1, #0x2
    73fc:	540027c0 	b.eq	78f4 <f12+0xdc4>  // b.none
    7400:	7100043f 	cmp	w1, #0x1
    7404:	540027c1 	b.ne	78fc <f12+0xdcc>  // b.any
    7408:	294304a6 	ldp	w6, w1, [x5, #24]
    740c:	92403c00 	and	x0, x0, #0xffff
    7410:	9b067c00 	mul	x0, x0, x6
    7414:	d360fc00 	lsr	x0, x0, #32
    7418:	eb01001f 	cmp	x0, x1
    741c:	54002702 	b.cs	78fc <f12+0xdcc>  // b.hs, b.nlast
    7420:	8b000084 	add	x4, x4, x0
    7424:	39400096 	ldrb	w22, [x4]
    7428:	710006df 	cmp	w22, #0x1
    742c:	54002681 	b.ne	78fc <f12+0xdcc>  // b.any
    7430:	b90023f6 	str	w22, [sp, #32]
    7434:	eb17005f 	cmp	x2, x23
    7438:	9a979057 	csel	x23, x2, x23, ls	// ls = plast
    743c:	91002359 	add	x25, x26, #0x8
    7440:	b4003f77 	cbz	x23, 7c2c <f12+0x10fc>
    7444:	f9400fe0 	ldr	x0, [sp, #24]
    7448:	d37df2e5 	lsl	x5, x23, #3
    744c:	aa1503e2 	mov	x2, x21
    7450:	d2800001 	mov	x1, #0x0                   	// #0
    7454:	91002000 	add	x0, x0, #0x8
    7458:	1400000a 	b	7480 <f12+0x950>
    745c:	fc616881 	ldr	d1, [x4, x1]
    7460:	fd400440 	ldr	d0, [x2, #8]
    7464:	1e613800 	fsub	d0, d0, d1
    7468:	fc216b20 	str	d0, [x25, x1]
    746c:	91002021 	add	x1, x1, #0x8
    7470:	f9400842 	ldr	x2, [x2, #16]
    7474:	eb05003f 	cmp	x1, x5
    7478:	540001c0 	b.eq	74b0 <f12+0x980>  // b.none
    747c:	f9400343 	ldr	x3, [x26]
    7480:	aa0003e4 	mov	x4, x0
    7484:	b6fffec3 	tbz	x3, #63, 745c <f12+0x92c>
    7488:	f9400fe3 	ldr	x3, [sp, #24]
    748c:	fd400440 	ldr	d0, [x2, #8]
    7490:	f9400864 	ldr	x4, [x3, #16]
    7494:	fc616881 	ldr	d1, [x4, x1]
    7498:	1e613800 	fsub	d0, d0, d1
    749c:	fc216b20 	str	d0, [x25, x1]
    74a0:	91002021 	add	x1, x1, #0x8
    74a4:	f9400842 	ldr	x2, [x2, #16]
    74a8:	eb05003f 	cmp	x1, x5
    74ac:	54fffe81 	b.ne	747c <f12+0x94c>  // b.any
    74b0:	b4003bb5 	cbz	x21, 7c24 <f12+0x10f4>
    74b4:	91174260 	add	x0, x19, #0x5d0
    74b8:	aa1503e2 	mov	x2, x21
    74bc:	d280001b 	mov	x27, #0x0                   	// #0
    74c0:	f949ec06 	ldr	x6, [x0, #5080]
    74c4:	f949d807 	ldr	x7, [x0, #5040]
    74c8:	f949fc05 	ldr	x5, [x0, #5112]
    74cc:	d370bcc6 	lsl	x6, x6, #16
    74d0:	14000006 	b	74e8 <f12+0x9b8>
    74d4:	f9400842 	ldr	x2, [x2, #16]
    74d8:	9100077b 	add	x27, x27, #0x1
    74dc:	f100005f 	cmp	x2, #0x0
    74e0:	fa571362 	ccmp	x27, x23, #0x2, ne	// ne = any
    74e4:	54000322 	b.cs	7548 <f12+0xa18>  // b.hs, b.nlast
    74e8:	cb070040 	sub	x0, x2, x7
    74ec:	eb06001f 	cmp	x0, x6
    74f0:	540002c2 	b.cs	7548 <f12+0xa18>  // b.hs, b.nlast
    74f4:	d350fc01 	lsr	x1, x0, #16
    74f8:	8b010821 	add	x1, x1, x1, lsl #2
    74fc:	d37df021 	lsl	x1, x1, #3
    7500:	8b0100a4 	add	x4, x5, x1
    7504:	f9401083 	ldr	x3, [x4, #32]
    7508:	b4000203 	cbz	x3, 7548 <f12+0xa18>
    750c:	386168a1 	ldrb	w1, [x5, x1]
    7510:	7100083f 	cmp	w1, #0x2
    7514:	54000e00 	b.eq	76d4 <f12+0xba4>  // b.none
    7518:	7100043f 	cmp	w1, #0x1
    751c:	54000161 	b.ne	7548 <f12+0xa18>  // b.any
    7520:	29430488 	ldp	w8, w1, [x4, #24]
    7524:	92403c00 	and	x0, x0, #0xffff
    7528:	9b087c00 	mul	x0, x0, x8
    752c:	d360fc00 	lsr	x0, x0, #32
    7530:	eb01001f 	cmp	x0, x1
    7534:	540000a2 	b.cs	7548 <f12+0xa18>  // b.hs, b.nlast
    7538:	8b000063 	add	x3, x3, x0
    753c:	39400060 	ldrb	w0, [x3]
    7540:	7100041f 	cmp	w0, #0x1
    7544:	54fffc80 	b.eq	74d4 <f12+0x9a4>  // b.none
    7548:	d2800018 	mov	x24, #0x0                   	// #0
    754c:	eb17037f 	cmp	x27, x23
    7550:	54000cc2 	b.cs	76e8 <f12+0xbb8>  // b.hs, b.nlast
    7554:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    7558:	d1002336 	sub	x22, x25, #0x8
    755c:	9117427a 	add	x26, x19, #0x5d0
    7560:	d2800018 	mov	x24, #0x0                   	// #0
    7564:	fd41b808 	ldr	d8, [x0, #880]
    7568:	14000042 	b	7670 <f12+0xb40>
    756c:	f9400381 	ldr	x1, [x28]
    7570:	aa2103e1 	mvn	x1, x1
    7574:	f8207b41 	str	x1, [x26, x0, lsl #3]
    7578:	f100609f 	cmp	x4, #0x18
    757c:	54000169 	b.ls	75a8 <f12+0xa78>  // b.plast
    7580:	d1006482 	sub	x2, x4, #0x19
    7584:	91006380 	add	x0, x28, #0x18
    7588:	927df042 	and	x2, x2, #0xfffffffffffffff8
    758c:	52800001 	mov	w1, #0x0                   	// #0
    7590:	91002042 	add	x2, x2, #0x8
    7594:	f90007e4 	str	x4, [sp, #8]
    7598:	b90013e5 	str	w5, [sp, #16]
    759c:	97ffecad 	bl	2850 <memset@plt>
    75a0:	f94007e4 	ldr	x4, [sp, #8]
    75a4:	b94013e5 	ldr	w5, [sp, #16]
    75a8:	91174262 	add	x2, x19, #0x5d0
    75ac:	f94a1041 	ldr	x1, [x2, #5152]
    75b0:	ab040021 	adds	x1, x1, x4
    75b4:	540036c2 	b.cs	7c8c <f12+0x115c>  // b.hs, b.nlast
    75b8:	f94a1440 	ldr	x0, [x2, #5160]
    75bc:	f90a1041 	str	x1, [x2, #5152]
    75c0:	eb00003f 	cmp	x1, x0
    75c4:	54000049 	b.ls	75cc <f12+0xa9c>  // b.plast
    75c8:	f90a1441 	str	x1, [x2, #5160]
    75cc:	91174260 	add	x0, x19, #0x5d0
    75d0:	1e6300a1 	ucvtf	d1, w5
    75d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    75d8:	1e612800 	fadd	d0, d0, d1
    75dc:	fd0a1c00 	str	d0, [x0, #5176]
    75e0:	a900e394 	stp	x20, x24, [x28, #8]
    75e4:	aa1c03f8 	mov	x24, x28
    75e8:	fd000388 	str	d8, [x28]
    75ec:	f949db41 	ldr	x1, [x26, #5040]
    75f0:	f949ef40 	ldr	x0, [x26, #5080]
    75f4:	cb010381 	sub	x1, x28, x1
    75f8:	eb00403f 	cmp	x1, x0, lsl #16
    75fc:	54000322 	b.cs	7660 <f12+0xb30>  // b.hs, b.nlast
    7600:	d350fc22 	lsr	x2, x1, #16
    7604:	f949ff44 	ldr	x4, [x26, #5112]
    7608:	8b020842 	add	x2, x2, x2, lsl #2
    760c:	d37df042 	lsl	x2, x2, #3
    7610:	8b020080 	add	x0, x4, x2
    7614:	f940101c 	ldr	x28, [x0, #32]
    7618:	b400025c 	cbz	x28, 7660 <f12+0xb30>
    761c:	38626882 	ldrb	w2, [x4, x2]
    7620:	7100085f 	cmp	w2, #0x2
    7624:	54000b00 	b.eq	7784 <f12+0xc54>  // b.none
    7628:	7100045f 	cmp	w2, #0x1
    762c:	540001a1 	b.ne	7660 <f12+0xb30>  // b.any
    7630:	29430002 	ldp	w2, w0, [x0, #24]
    7634:	92403c21 	and	x1, x1, #0xffff
    7638:	9b027c21 	mul	x1, x1, x2
    763c:	d360fc21 	lsr	x1, x1, #32
    7640:	eb00003f 	cmp	x1, x0
    7644:	540000e2 	b.cs	7660 <f12+0xb30>  // b.hs, b.nlast
    7648:	8b01039c 	add	x28, x28, x1
    764c:	39400380 	ldrb	w0, [x28]
    7650:	7103fc1f 	cmp	w0, #0xff
    7654:	54002000 	b.eq	7a54 <f12+0xf24>  // b.none
    7658:	52800020 	mov	w0, #0x1                   	// #1
    765c:	39000380 	strb	w0, [x28]
    7660:	d10006e0 	sub	x0, x23, #0x1
    7664:	eb00037f 	cmp	x27, x0
    7668:	54000982 	b.cs	7798 <f12+0xc68>  // b.hs, b.nlast
    766c:	aa0003f7 	mov	x23, x0
    7670:	b953a740 	ldr	w0, [x26, #5028]
    7674:	f8777ad4 	ldr	x20, [x22, x23, lsl #3]
    7678:	34000240 	cbz	w0, 76c0 <f12+0xb90>
    767c:	397e8b40 	ldrb	w0, [x26, #4002]
    7680:	910f0001 	add	x1, x0, #0x3c0
    7684:	8b000400 	add	x0, x0, x0, lsl #1
    7688:	b8617b45 	ldr	w5, [x26, x1, lsl #2]
    768c:	8b000f41 	add	x1, x26, x0, lsl #3
    7690:	f8607b5c 	ldr	x28, [x26, x0, lsl #3]
    7694:	2a0503e4 	mov	w4, w5
    7698:	b5fff6bc 	cbnz	x28, 756c <f12+0xa3c>
    769c:	f940043c 	ldr	x28, [x1, #8]
    76a0:	b400011c 	cbz	x28, 76c0 <f12+0xb90>
    76a4:	f9400820 	ldr	x0, [x1, #16]
    76a8:	cb1c0000 	sub	x0, x0, x28
    76ac:	eb00009f 	cmp	x4, x0
    76b0:	54000088 	b.hi	76c0 <f12+0xb90>  // b.pmore
    76b4:	8b040380 	add	x0, x28, x4
    76b8:	f9000420 	str	x0, [x1, #8]
    76bc:	17ffffaf 	b	7578 <f12+0xa48>
    76c0:	52800001 	mov	w1, #0x0                   	// #0
    76c4:	d2800300 	mov	x0, #0x18                  	// #24
    76c8:	97fff60a 	bl	4ef0 <fwp_heap_alloc>
    76cc:	aa0003fc 	mov	x28, x0
    76d0:	17ffffc4 	b	75e0 <f12+0xab0>
    76d4:	72003c1f 	tst	w0, #0xffff
    76d8:	54fff320 	b.eq	753c <f12+0xa0c>  // b.none
    76dc:	d2800018 	mov	x24, #0x0                   	// #0
    76e0:	eb17037f 	cmp	x27, x23
    76e4:	54fff383 	b.cc	7554 <f12+0xa24>  // b.lo, b.ul, b.last
    76e8:	8b1b0f3b 	add	x27, x25, x27, lsl #3
    76ec:	aa1903e1 	mov	x1, x25
    76f0:	aa1503e0 	mov	x0, x21
    76f4:	d503201f 	nop
    76f8:	f8408422 	ldr	x2, [x1], #8
    76fc:	f9000402 	str	x2, [x0, #8]
    7700:	aa0003e2 	mov	x2, x0
    7704:	f9400800 	ldr	x0, [x0, #16]
    7708:	eb1b003f 	cmp	x1, x27
    770c:	54ffff61 	b.ne	76f8 <f12+0xbc8>  // b.any
    7710:	b94023e1 	ldr	w1, [sp, #32]
    7714:	f9000858 	str	x24, [x2, #16]
    7718:	aa1503f8 	mov	x24, x21
    771c:	aa0003f5 	mov	x21, x0
    7720:	34000041 	cbz	w1, 7728 <f12+0xbf8>
    7724:	d2800019 	mov	x25, #0x0                   	// #0
    7728:	aa1903e0 	mov	x0, x25
    772c:	97fff4d1 	bl	4a70 <fwp_mem_free>
    7730:	f9400fe0 	ldr	x0, [sp, #24]
    7734:	97fffc5f 	bl	68b0 <fwp_drop4>
    7738:	aa1503e0 	mov	x0, x21
    773c:	97fff88e 	bl	5974 <fwp_drop0>
    7740:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7744:	f947f400 	ldr	x0, [x0, #4072]
    7748:	f94057e2 	ldr	x2, [sp, #168]
    774c:	f9400001 	ldr	x1, [x0]
    7750:	eb010042 	subs	x2, x2, x1
    7754:	d2800001 	mov	x1, #0x0                   	// #0
    7758:	54002ba1 	b.ne	7ccc <f12+0x119c>  // b.any
    775c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7760:	aa1803e0 	mov	x0, x24
    7764:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7768:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    776c:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7770:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7774:	a95073fb 	ldp	x27, x28, [sp, #256]
    7778:	fd408be8 	ldr	d8, [sp, #272]
    777c:	910483ff 	add	sp, sp, #0x120
    7780:	d65f03c0 	ret
    7784:	72003c3f 	tst	w1, #0xffff
    7788:	54fff620 	b.eq	764c <f12+0xb1c>  // b.none
    778c:	d10006e0 	sub	x0, x23, #0x1
    7790:	eb00037f 	cmp	x27, x0
    7794:	54fff6c3 	b.cc	766c <f12+0xb3c>  // b.lo, b.ul, b.last
    7798:	b5fffa9b 	cbnz	x27, 76e8 <f12+0xbb8>
    779c:	b94023e1 	ldr	w1, [sp, #32]
    77a0:	7100003f 	cmp	w1, #0x0
    77a4:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    77a8:	b4fffc00 	cbz	x0, 7728 <f12+0xbf8>
    77ac:	91174273 	add	x19, x19, #0x5d0
    77b0:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    77b4:	d1000afa 	sub	x26, x23, #0x2
    77b8:	52800034 	mov	w20, #0x1                   	// #1
    77bc:	fd41b808 	ldr	d8, [x0, #880]
    77c0:	b953a660 	ldr	w0, [x19, #5028]
    77c4:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    77c8:	340008c0 	cbz	w0, 78e0 <f12+0xdb0>
    77cc:	d503201f 	nop
    77d0:	397e8a60 	ldrb	w0, [x19, #4002]
    77d4:	910f0001 	add	x1, x0, #0x3c0
    77d8:	8b000400 	add	x0, x0, x0, lsl #1
    77dc:	b8617a7c 	ldr	w28, [x19, x1, lsl #2]
    77e0:	8b000e61 	add	x1, x19, x0, lsl #3
    77e4:	f8607a76 	ldr	x22, [x19, x0, lsl #3]
    77e8:	2a1c03fb 	mov	w27, w28
    77ec:	b40022d6 	cbz	x22, 7c44 <f12+0x1114>
    77f0:	f94002c1 	ldr	x1, [x22]
    77f4:	aa2103e1 	mvn	x1, x1
    77f8:	f8207a61 	str	x1, [x19, x0, lsl #3]
    77fc:	f100637f 	cmp	x27, #0x18
    7800:	540000e9 	b.ls	781c <f12+0xcec>  // b.plast
    7804:	d1006762 	sub	x2, x27, #0x19
    7808:	910062c0 	add	x0, x22, #0x18
    780c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7810:	52800001 	mov	w1, #0x0                   	// #0
    7814:	91002042 	add	x2, x2, #0x8
    7818:	97ffec0e 	bl	2850 <memset@plt>
    781c:	f94a1260 	ldr	x0, [x19, #5152]
    7820:	ab1b0000 	adds	x0, x0, x27
    7824:	54002342 	b.cs	7c8c <f12+0x115c>  // b.hs, b.nlast
    7828:	f94a1661 	ldr	x1, [x19, #5160]
    782c:	f90a1260 	str	x0, [x19, #5152]
    7830:	eb01001f 	cmp	x0, x1
    7834:	54000049 	b.ls	783c <f12+0xd0c>  // b.plast
    7838:	f90a1660 	str	x0, [x19, #5160]
    783c:	1e630381 	ucvtf	d1, w28
    7840:	fd4a1e60 	ldr	d0, [x19, #5176]
    7844:	1e612800 	fadd	d0, d0, d1
    7848:	fd0a1e60 	str	d0, [x19, #5176]
    784c:	a900e2d7 	stp	x23, x24, [x22, #8]
    7850:	aa1603f8 	mov	x24, x22
    7854:	fd0002c8 	str	d8, [x22]
    7858:	f949da61 	ldr	x1, [x19, #5040]
    785c:	f949ee60 	ldr	x0, [x19, #5080]
    7860:	cb0102c1 	sub	x1, x22, x1
    7864:	eb00403f 	cmp	x1, x0, lsl #16
    7868:	54000302 	b.cs	78c8 <f12+0xd98>  // b.hs, b.nlast
    786c:	d350fc22 	lsr	x2, x1, #16
    7870:	f949fe63 	ldr	x3, [x19, #5112]
    7874:	8b020842 	add	x2, x2, x2, lsl #2
    7878:	d37df042 	lsl	x2, x2, #3
    787c:	8b020060 	add	x0, x3, x2
    7880:	f9401016 	ldr	x22, [x0, #32]
    7884:	b4000236 	cbz	x22, 78c8 <f12+0xd98>
    7888:	38626862 	ldrb	w2, [x3, x2]
    788c:	7100085f 	cmp	w2, #0x2
    7890:	54001ec0 	b.eq	7c68 <f12+0x1138>  // b.none
    7894:	7100045f 	cmp	w2, #0x1
    7898:	54000181 	b.ne	78c8 <f12+0xd98>  // b.any
    789c:	29430002 	ldp	w2, w0, [x0, #24]
    78a0:	92403c21 	and	x1, x1, #0xffff
    78a4:	9b027c21 	mul	x1, x1, x2
    78a8:	d360fc21 	lsr	x1, x1, #32
    78ac:	eb00003f 	cmp	x1, x0
    78b0:	540000c2 	b.cs	78c8 <f12+0xd98>  // b.hs, b.nlast
    78b4:	8b0102d6 	add	x22, x22, x1
    78b8:	394002c0 	ldrb	w0, [x22]
    78bc:	7103fc1f 	cmp	w0, #0xff
    78c0:	54001bc0 	b.eq	7c38 <f12+0x1108>  // b.none
    78c4:	390002d4 	strb	w20, [x22]
    78c8:	d100075a 	sub	x26, x26, #0x1
    78cc:	b100075f 	cmn	x26, #0x1
    78d0:	54fff2c0 	b.eq	7728 <f12+0xbf8>  // b.none
    78d4:	b953a660 	ldr	w0, [x19, #5028]
    78d8:	f87a7b37 	ldr	x23, [x25, x26, lsl #3]
    78dc:	35fff7a0 	cbnz	w0, 77d0 <f12+0xca0>
    78e0:	52800001 	mov	w1, #0x0                   	// #0
    78e4:	d2800300 	mov	x0, #0x18                  	// #24
    78e8:	97fff582 	bl	4ef0 <fwp_heap_alloc>
    78ec:	aa0003f6 	mov	x22, x0
    78f0:	17ffffd7 	b	784c <f12+0xd1c>
    78f4:	72003c1f 	tst	w0, #0xffff
    78f8:	54ffd960 	b.eq	7424 <f12+0x8f4>  // b.none
    78fc:	b4001475 	cbz	x21, 7b88 <f12+0x1058>
    7900:	aa1503f6 	mov	x22, x21
    7904:	d2800018 	mov	x24, #0x0                   	// #0
    7908:	f9400ad6 	ldr	x22, [x22, #16]
    790c:	aa1803e0 	mov	x0, x24
    7910:	91000718 	add	x24, x24, #0x1
    7914:	b5ffffb6 	cbnz	x22, 7908 <f12+0xdd8>
    7918:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    791c:	eb01031f 	cmp	x24, x1
    7920:	54001d08 	b.hi	7cc0 <f12+0x1190>  // b.pmore
    7924:	91000800 	add	x0, x0, #0x2
    7928:	52800041 	mov	w1, #0x2                   	// #2
    792c:	d37df000 	lsl	x0, x0, #3
    7930:	97fff570 	bl	4ef0 <fwp_heap_alloc>
    7934:	eb17031f 	cmp	x24, x23
    7938:	aa0003f9 	mov	x25, x0
    793c:	9a979317 	csel	x23, x24, x23, ls	// ls = plast
    7940:	aa1503e1 	mov	x1, x21
    7944:	d503201f 	nop
    7948:	f9400420 	ldr	x0, [x1, #8]
    794c:	f8367b20 	str	x0, [x25, x22, lsl #3]
    7950:	910006d6 	add	x22, x22, #0x1
    7954:	f9400821 	ldr	x1, [x1, #16]
    7958:	b5ffff81 	cbnz	x1, 7948 <f12+0xe18>
    795c:	b40011f7 	cbz	x23, 7b98 <f12+0x1068>
    7960:	f9400343 	ldr	x3, [x26]
    7964:	b90023ff 	str	wzr, [sp, #32]
    7968:	17fffeb7 	b	7444 <f12+0x914>
    796c:	72003c1f 	tst	w0, #0xffff
    7970:	54ffcc80 	b.eq	7300 <f12+0x7d0>  // b.none
    7974:	d503201f 	nop
    7978:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    797c:	eb0002ff 	cmp	x23, x0
    7980:	54001a88 	b.hi	7cd0 <f12+0x11a0>  // b.pmore
    7984:	910006e0 	add	x0, x23, #0x1
    7988:	52800021 	mov	w1, #0x1                   	// #1
    798c:	d37df000 	lsl	x0, x0, #3
    7990:	97fff558 	bl	4ef0 <fwp_heap_alloc>
    7994:	91174262 	add	x2, x19, #0x5d0
    7998:	f9000017 	str	x23, [x0]
    799c:	aa0003fa 	mov	x26, x0
    79a0:	f9000ffa 	str	x26, [sp, #24]
    79a4:	f949d841 	ldr	x1, [x2, #5040]
    79a8:	f949ec40 	ldr	x0, [x2, #5080]
    79ac:	cb010341 	sub	x1, x26, x1
    79b0:	eb00403f 	cmp	x1, x0, lsl #16
    79b4:	54000322 	b.cs	7a18 <f12+0xee8>  // b.hs, b.nlast
    79b8:	d350fc20 	lsr	x0, x1, #16
    79bc:	f949fc43 	ldr	x3, [x2, #5112]
    79c0:	8b000800 	add	x0, x0, x0, lsl #2
    79c4:	d37df002 	lsl	x2, x0, #3
    79c8:	8b020060 	add	x0, x3, x2
    79cc:	f9401018 	ldr	x24, [x0, #32]
    79d0:	b4000258 	cbz	x24, 7a18 <f12+0xee8>
    79d4:	38626862 	ldrb	w2, [x3, x2]
    79d8:	7100085f 	cmp	w2, #0x2
    79dc:	54000e20 	b.eq	7ba0 <f12+0x1070>  // b.none
    79e0:	7100045f 	cmp	w2, #0x1
    79e4:	540001a1 	b.ne	7a18 <f12+0xee8>  // b.any
    79e8:	29430002 	ldp	w2, w0, [x0, #24]
    79ec:	92403c21 	and	x1, x1, #0xffff
    79f0:	9b027c21 	mul	x1, x1, x2
    79f4:	d360fc21 	lsr	x1, x1, #32
    79f8:	eb00003f 	cmp	x1, x0
    79fc:	540000e2 	b.cs	7a18 <f12+0xee8>  // b.hs, b.nlast
    7a00:	8b010318 	add	x24, x24, x1
    7a04:	39400300 	ldrb	w0, [x24]
    7a08:	7103fc1f 	cmp	w0, #0xff
    7a0c:	54001020 	b.eq	7c10 <f12+0x10e0>  // b.none
    7a10:	52800020 	mov	w0, #0x1                   	// #1
    7a14:	39000300 	strb	w0, [x24]
    7a18:	aa1603e0 	mov	x0, x22
    7a1c:	17fffe3f 	b	7318 <f12+0x7e8>
    7a20:	52800041 	mov	w1, #0x2                   	// #2
    7a24:	d2800100 	mov	x0, #0x8                   	// #8
    7a28:	97fff532 	bl	4ef0 <fwp_heap_alloc>
    7a2c:	aa0003f8 	mov	x24, x0
    7a30:	91174260 	add	x0, x19, #0x5d0
    7a34:	f900031f 	str	xzr, [x24]
    7a38:	f949d801 	ldr	x1, [x0, #5040]
    7a3c:	f949ec00 	ldr	x0, [x0, #5080]
    7a40:	cb010301 	sub	x1, x24, x1
    7a44:	eb00403f 	cmp	x1, x0, lsl #16
    7a48:	540003e2 	b.cs	7ac4 <f12+0xf94>  // b.hs, b.nlast
    7a4c:	d2800016 	mov	x22, #0x0                   	// #0
    7a50:	17fffd0b 	b	6e7c <f12+0x34c>
    7a54:	aa1c03e0 	mov	x0, x28
    7a58:	97fff366 	bl	47f0 <fwp_rc_forget_slot>
    7a5c:	17fffeff 	b	7658 <f12+0xb28>
    7a60:	f100037f 	cmp	x27, #0x0
    7a64:	fa401b40 	ccmp	x26, #0x0, #0x0, ne	// ne = any
    7a68:	54ffb2e1 	b.ne	70c4 <f12+0x594>  // b.any
    7a6c:	f94013e0 	ldr	x0, [sp, #32]
    7a70:	9101c294 	add	x20, x20, #0x70
    7a74:	f9402fe1 	ldr	x1, [sp, #88]
    7a78:	f9018a81 	str	x1, [x20, #784]
    7a7c:	97fff241 	bl	4380 <fwp_tape_buffers_release>
    7a80:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    7a84:	f947e863 	ldr	x3, [x3, #4048]
    7a88:	d2800262 	mov	x2, #0x13                  	// #19
    7a8c:	d2800021 	mov	x1, #0x1                   	// #1
    7a90:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7a94:	9116a000 	add	x0, x0, #0x5a8
    7a98:	f9400063 	ldr	x3, [x3]
    7a9c:	97ffebb9 	bl	2980 <fwrite@plt>
    7aa0:	d2800000 	mov	x0, #0x0                   	// #0
    7aa4:	97ffebc3 	bl	29b0 <fflush@plt>
    7aa8:	52800cc0 	mov	w0, #0x66                  	// #102
    7aac:	97ffebd1 	bl	29f0 <_Exit@plt>
    7ab0:	eb18033f 	cmp	x25, x24
    7ab4:	54ff9040 	b.eq	6cbc <f12+0x18c>  // b.none
    7ab8:	f9403a9c 	ldr	x28, [x20, #112]
    7abc:	17fffc9d 	b	6d30 <f12+0x200>
    7ac0:	b5ffa136 	cbnz	x22, 6ee4 <f12+0x3b4>
    7ac4:	d280001c 	mov	x28, #0x0                   	// #0
    7ac8:	17fffd2d 	b	6f7c <f12+0x44c>
    7acc:	d0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x110>
    7ad0:	913ac000 	add	x0, x0, #0xeb0
    7ad4:	94000ea7 	bl	b570 <atexit>
    7ad8:	35fffd40 	cbnz	w0, 7a80 <f12+0xf50>
    7adc:	52800020 	mov	w0, #0x1                   	// #1
    7ae0:	b9034700 	str	w0, [x24, #836]
    7ae4:	17fffc62 	b	6c6c <f12+0x13c>
    7ae8:	72003c3f 	tst	w1, #0xffff
    7aec:	54ff9fa1 	b.ne	6ee0 <f12+0x3b0>  // b.any
    7af0:	17fffcf7 	b	6ecc <f12+0x39c>
    7af4:	72003c3f 	tst	w1, #0xffff
    7af8:	54ff88e0 	b.eq	6c14 <f12+0xe4>  // b.none
    7afc:	aa1703e0 	mov	x0, x23
    7b00:	97fff84c 	bl	5c30 <fwp_closure_drop>
    7b04:	b5ff89b5 	cbnz	x21, 6c38 <f12+0x108>
    7b08:	52800000 	mov	w0, #0x0                   	// #0
    7b0c:	d2800017 	mov	x23, #0x0                   	// #0
    7b10:	97ffeeb8 	bl	35f0 <descent_phase_step>
    7b14:	17fffc53 	b	6c60 <f12+0x130>
    7b18:	aa1c03fb 	mov	x27, x28
    7b1c:	17fffd55 	b	7070 <f12+0x540>
    7b20:	72003c3f 	tst	w1, #0xffff
    7b24:	54ffba61 	b.ne	7270 <f12+0x740>  // b.any
    7b28:	17fffdcd 	b	725c <f12+0x72c>
    7b2c:	3cc98002 	ldur	q2, [x0, #152]
    7b30:	91026001 	add	x1, x0, #0x98
    7b34:	3cca8001 	ldur	q1, [x0, #168]
    7b38:	f900681f 	str	xzr, [x0, #208]
    7b3c:	4f000400 	movi	v0.4s, #0x0
    7b40:	ad010702 	stp	q2, q1, [x24, #32]
    7b44:	a94b8002 	ldp	x2, x0, [x0, #184]
    7b48:	f9000f00 	str	x0, [x24, #24]
    7b4c:	f9401820 	ldr	x0, [x1, #48]
    7b50:	f9002302 	str	x2, [x24, #64]
    7b54:	f9002700 	str	x0, [x24, #72]
    7b58:	ad000020 	stp	q0, q0, [x1]
    7b5c:	3d800820 	str	q0, [x1, #32]
    7b60:	f900183f 	str	xzr, [x1, #48]
    7b64:	17fffc81 	b	6d68 <f12+0x238>
    7b68:	d37ffb1a 	lsl	x26, x24, #1
    7b6c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7b70:	eb00035f 	cmp	x26, x0
    7b74:	9a80d35a 	csel	x26, x26, x0, le
    7b78:	8b1a0741 	add	x1, x26, x26, lsl #1
    7b7c:	8b010b41 	add	x1, x26, x1, lsl #2
    7b80:	d37df021 	lsl	x1, x1, #3
    7b84:	17fffc59 	b	6ce8 <f12+0x1b8>
    7b88:	52800041 	mov	w1, #0x2                   	// #2
    7b8c:	d2800100 	mov	x0, #0x8                   	// #8
    7b90:	97fff4d8 	bl	4ef0 <fwp_heap_alloc>
    7b94:	aa0003f9 	mov	x25, x0
    7b98:	d2800018 	mov	x24, #0x0                   	// #0
    7b9c:	17fffee3 	b	7728 <f12+0xbf8>
    7ba0:	72003c3f 	tst	w1, #0xffff
    7ba4:	54fff300 	b.eq	7a04 <f12+0xed4>  // b.none
    7ba8:	aa1603e0 	mov	x0, x22
    7bac:	17fffddb 	b	7318 <f12+0x7e8>
    7bb0:	aa0203e0 	mov	x0, x2
    7bb4:	d2800101 	mov	x1, #0x8                   	// #8
    7bb8:	f90017e2 	str	x2, [sp, #40]
    7bbc:	97ffeb29 	bl	2860 <calloc@plt>
    7bc0:	f94017e2 	ldr	x2, [sp, #40]
    7bc4:	aa0003fa 	mov	x26, x0
    7bc8:	17fffd3c 	b	70b8 <f12+0x588>
    7bcc:	f9400343 	ldr	x3, [x26]
    7bd0:	b7fffdc3 	tbnz	x3, #63, 7b88 <f12+0x1058>
    7bd4:	91174261 	add	x1, x19, #0x5d0
    7bd8:	f9400fe4 	ldr	x4, [sp, #24]
    7bdc:	f949d820 	ldr	x0, [x1, #5040]
    7be0:	f949ec21 	ldr	x1, [x1, #5080]
    7be4:	cb000080 	sub	x0, x4, x0
    7be8:	eb01401f 	cmp	x0, x1, lsl #16
    7bec:	54fffce2 	b.cs	7b88 <f12+0x1058>  // b.hs, b.nlast
    7bf0:	9240f877 	and	x23, x3, #0x7fffffffffffffff
    7bf4:	17fffdf8 	b	73d4 <f12+0x8a4>
    7bf8:	aa1903e0 	mov	x0, x25
    7bfc:	97fff2fd 	bl	47f0 <fwp_rc_forget_slot>
    7c00:	17fffcb6 	b	6ed8 <f12+0x3a8>
    7c04:	aa1703e0 	mov	x0, x23
    7c08:	97fff2fa 	bl	47f0 <fwp_rc_forget_slot>
    7c0c:	17fffd97 	b	7268 <f12+0x738>
    7c10:	aa1803e0 	mov	x0, x24
    7c14:	97fff2f7 	bl	47f0 <fwp_rc_forget_slot>
    7c18:	17ffff7e 	b	7a10 <f12+0xee0>
    7c1c:	97fff2ae 	bl	46d4 <fwp_rc_wide_dup>
    7c20:	17fffc03 	b	6c2c <f12+0xfc>
    7c24:	d280001b 	mov	x27, #0x0                   	// #0
    7c28:	17fffe4b 	b	7554 <f12+0xa24>
    7c2c:	d2800019 	mov	x25, #0x0                   	// #0
    7c30:	d2800018 	mov	x24, #0x0                   	// #0
    7c34:	17fffebd 	b	7728 <f12+0xbf8>
    7c38:	aa1603e0 	mov	x0, x22
    7c3c:	97fff2ed 	bl	47f0 <fwp_rc_forget_slot>
    7c40:	17ffff21 	b	78c4 <f12+0xd94>
    7c44:	f9400436 	ldr	x22, [x1, #8]
    7c48:	b4ffe4d6 	cbz	x22, 78e0 <f12+0xdb0>
    7c4c:	f9400820 	ldr	x0, [x1, #16]
    7c50:	cb160000 	sub	x0, x0, x22
    7c54:	eb00037f 	cmp	x27, x0
    7c58:	54ffe448 	b.hi	78e0 <f12+0xdb0>  // b.pmore
    7c5c:	8b1b02c0 	add	x0, x22, x27
    7c60:	f9000420 	str	x0, [x1, #8]
    7c64:	17fffee6 	b	77fc <f12+0xccc>
    7c68:	72003c3f 	tst	w1, #0xffff
    7c6c:	54ffe2e1 	b.ne	78c8 <f12+0xd98>  // b.any
    7c70:	17ffff12 	b	78b8 <f12+0xd88>
    7c74:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7c78:	91252000 	add	x0, x0, #0x948
    7c7c:	97ffeee1 	bl	3800 <fwp_trap>
    7c80:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7c84:	91278000 	add	x0, x0, #0x9e0
    7c88:	97ffeede 	bl	3800 <fwp_trap>
    7c8c:	97ffece9 	bl	3030 <fwp_heap_oom>
    7c90:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7c94:	91264000 	add	x0, x0, #0x990
    7c98:	97ffeeda 	bl	3800 <fwp_trap>
    7c9c:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7ca0:	91290000 	add	x0, x0, #0xa40
    7ca4:	97ffeed7 	bl	3800 <fwp_trap>
    7ca8:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7cac:	91298000 	add	x0, x0, #0xa60
    7cb0:	97ffeed4 	bl	3800 <fwp_trap>
    7cb4:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7cb8:	912a4000 	add	x0, x0, #0xa90
    7cbc:	97ffeed1 	bl	3800 <fwp_trap>
    7cc0:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7cc4:	912b0000 	add	x0, x0, #0xac0
    7cc8:	97ffeece 	bl	3800 <fwp_trap>
    7ccc:	97ffeaed 	bl	2880 <__stack_chk_fail@plt>
    7cd0:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7cd4:	912b4000 	add	x0, x0, #0xad0
    7cd8:	97ffeeca 	bl	3800 <fwp_trap>
    7cdc:	90000020 	adrp	x0, b000 <__divti3+0x180>
    7ce0:	912b8000 	add	x0, x0, #0xae0
    7ce4:	97ffeec7 	bl	3800 <fwp_trap>
    7ce8:	97ffeafa 	bl	28d0 <abort@plt>
    7cec:	97ffeb65 	bl	2a80 <fwp_trap_overflow.constprop.0>

0000000000007cf0 <fwp_owned_entry12>:
    7cf0:	f9400000 	ldr	x0, [x0]
    7cf4:	17fffb8f 	b	6b30 <f12>
    7cf8:	d503201f 	nop
    7cfc:	d503201f 	nop

0000000000007d00 <e12>:
    7d00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7d04:	910003fd 	mov	x29, sp
    7d08:	f9000bf3 	str	x19, [sp, #16]
    7d0c:	f9400013 	ldr	x19, [x0]
    7d10:	aa1303e0 	mov	x0, x19
    7d14:	97fff6ab 	bl	57c0 <fwp_rc_share>
    7d18:	aa1303e0 	mov	x0, x19
    7d1c:	97fffb85 	bl	6b30 <f12>
    7d20:	aa0003f3 	mov	x19, x0
    7d24:	97fff6a7 	bl	57c0 <fwp_rc_share>
    7d28:	aa1303e0 	mov	x0, x19
    7d2c:	f9400bf3 	ldr	x19, [sp, #16]
    7d30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7d34:	d65f03c0 	ret
    7d38:	d503201f 	nop
    7d3c:	d503201f 	nop

0000000000007d40 <fwp_args12>:
    7d40:	7100003f 	cmp	w1, #0x0
    7d44:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7d48:	54000041 	b.ne	7d50 <fwp_args12+0x10>  // b.any
    7d4c:	d65f03c0 	ret
    7d50:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7d54:	91174042 	add	x2, x2, #0x5d0
    7d58:	f9400001 	ldr	x1, [x0]
    7d5c:	f949d843 	ldr	x3, [x2, #5040]
    7d60:	f949ec40 	ldr	x0, [x2, #5080]
    7d64:	cb030021 	sub	x1, x1, x3
    7d68:	eb00403f 	cmp	x1, x0, lsl #16
    7d6c:	54ffff02 	b.cs	7d4c <fwp_args12+0xc>  // b.hs, b.nlast
    7d70:	d350fc20 	lsr	x0, x1, #16
    7d74:	f949fc44 	ldr	x4, [x2, #5112]
    7d78:	8b000800 	add	x0, x0, x0, lsl #2
    7d7c:	d37df002 	lsl	x2, x0, #3
    7d80:	8b020083 	add	x3, x4, x2
    7d84:	f9401060 	ldr	x0, [x3, #32]
    7d88:	b4fffe20 	cbz	x0, 7d4c <fwp_args12+0xc>
    7d8c:	38626882 	ldrb	w2, [x4, x2]
    7d90:	7100085f 	cmp	w2, #0x2
    7d94:	54000220 	b.eq	7dd8 <fwp_args12+0x98>  // b.none
    7d98:	7100045f 	cmp	w2, #0x1
    7d9c:	54fffd81 	b.ne	7d4c <fwp_args12+0xc>  // b.any
    7da0:	29430864 	ldp	w4, w2, [x3, #24]
    7da4:	92403c21 	and	x1, x1, #0xffff
    7da8:	9b047c21 	mul	x1, x1, x4
    7dac:	d360fc21 	lsr	x1, x1, #32
    7db0:	eb02003f 	cmp	x1, x2
    7db4:	54fffcc2 	b.cs	7d4c <fwp_args12+0xc>  // b.hs, b.nlast
    7db8:	8b010000 	add	x0, x0, x1
    7dbc:	39400001 	ldrb	w1, [x0]
    7dc0:	34fffc61 	cbz	w1, 7d4c <fwp_args12+0xc>
    7dc4:	7103f43f 	cmp	w1, #0xfd
    7dc8:	540000e8 	b.hi	7de4 <fwp_args12+0xa4>  // b.pmore
    7dcc:	11000421 	add	w1, w1, #0x1
    7dd0:	39000001 	strb	w1, [x0]
    7dd4:	d65f03c0 	ret
    7dd8:	72003c3f 	tst	w1, #0xffff
    7ddc:	54ffff00 	b.eq	7dbc <fwp_args12+0x7c>  // b.none
    7de0:	d65f03c0 	ret
    7de4:	17fff23c 	b	46d4 <fwp_rc_wide_dup>
    7de8:	d503201f 	nop
    7dec:	d503201f 	nop

0000000000007df0 <fwp_args23>:
    7df0:	7100003f 	cmp	w1, #0x0
    7df4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7df8:	54000041 	b.ne	7e00 <fwp_args23+0x10>  // b.any
    7dfc:	d65f03c0 	ret
    7e00:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7e04:	91174042 	add	x2, x2, #0x5d0
    7e08:	f9400001 	ldr	x1, [x0]
    7e0c:	f949d843 	ldr	x3, [x2, #5040]
    7e10:	f949ec40 	ldr	x0, [x2, #5080]
    7e14:	cb030021 	sub	x1, x1, x3
    7e18:	eb00403f 	cmp	x1, x0, lsl #16
    7e1c:	54ffff02 	b.cs	7dfc <fwp_args23+0xc>  // b.hs, b.nlast
    7e20:	d350fc20 	lsr	x0, x1, #16
    7e24:	f949fc44 	ldr	x4, [x2, #5112]
    7e28:	8b000800 	add	x0, x0, x0, lsl #2
    7e2c:	d37df002 	lsl	x2, x0, #3
    7e30:	8b020083 	add	x3, x4, x2
    7e34:	f9401060 	ldr	x0, [x3, #32]
    7e38:	b4fffe20 	cbz	x0, 7dfc <fwp_args23+0xc>
    7e3c:	38626882 	ldrb	w2, [x4, x2]
    7e40:	7100085f 	cmp	w2, #0x2
    7e44:	54000220 	b.eq	7e88 <fwp_args23+0x98>  // b.none
    7e48:	7100045f 	cmp	w2, #0x1
    7e4c:	54fffd81 	b.ne	7dfc <fwp_args23+0xc>  // b.any
    7e50:	29430864 	ldp	w4, w2, [x3, #24]
    7e54:	92403c21 	and	x1, x1, #0xffff
    7e58:	9b047c21 	mul	x1, x1, x4
    7e5c:	d360fc21 	lsr	x1, x1, #32
    7e60:	eb02003f 	cmp	x1, x2
    7e64:	54fffcc2 	b.cs	7dfc <fwp_args23+0xc>  // b.hs, b.nlast
    7e68:	8b010000 	add	x0, x0, x1
    7e6c:	39400001 	ldrb	w1, [x0]
    7e70:	34fffc61 	cbz	w1, 7dfc <fwp_args23+0xc>
    7e74:	7103f43f 	cmp	w1, #0xfd
    7e78:	540000e8 	b.hi	7e94 <fwp_args23+0xa4>  // b.pmore
    7e7c:	11000421 	add	w1, w1, #0x1
    7e80:	39000001 	strb	w1, [x0]
    7e84:	d65f03c0 	ret
    7e88:	72003c3f 	tst	w1, #0xffff
    7e8c:	54ffff00 	b.eq	7e6c <fwp_args23+0x7c>  // b.none
    7e90:	d65f03c0 	ret
    7e94:	17fff210 	b	46d4 <fwp_rc_wide_dup>
    7e98:	d503201f 	nop
    7e9c:	d503201f 	nop

0000000000007ea0 <fwp_caps12>:
    7ea0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7ea4:	910003fd 	mov	x29, sp
    7ea8:	f9000bf3 	str	x19, [sp, #16]
    7eac:	aa0003f3 	mov	x19, x0
    7eb0:	b9400400 	ldr	w0, [x0, #4]
    7eb4:	340004a0 	cbz	w0, 7f48 <fwp_caps12+0xa8>
    7eb8:	f9400660 	ldr	x0, [x19, #8]
    7ebc:	350004e1 	cbnz	w1, 7f58 <fwp_caps12+0xb8>
    7ec0:	97fff6ad 	bl	5974 <fwp_drop0>
    7ec4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7ec8:	91174042 	add	x2, x2, #0x5d0
    7ecc:	f949d840 	ldr	x0, [x2, #5040]
    7ed0:	f949ec41 	ldr	x1, [x2, #5080]
    7ed4:	cb000260 	sub	x0, x19, x0
    7ed8:	eb01401f 	cmp	x0, x1, lsl #16
    7edc:	54000382 	b.cs	7f4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7ee0:	d350fc01 	lsr	x1, x0, #16
    7ee4:	f949fc44 	ldr	x4, [x2, #5112]
    7ee8:	8b010821 	add	x1, x1, x1, lsl #2
    7eec:	d37df021 	lsl	x1, x1, #3
    7ef0:	8b010083 	add	x3, x4, x1
    7ef4:	f9401062 	ldr	x2, [x3, #32]
    7ef8:	b40002a2 	cbz	x2, 7f4c <fwp_caps12+0xac>
    7efc:	38616881 	ldrb	w1, [x4, x1]
    7f00:	7100083f 	cmp	w1, #0x2
    7f04:	540006c0 	b.eq	7fdc <fwp_caps12+0x13c>  // b.none
    7f08:	7100043f 	cmp	w1, #0x1
    7f0c:	54000201 	b.ne	7f4c <fwp_caps12+0xac>  // b.any
    7f10:	29430464 	ldp	w4, w1, [x3, #24]
    7f14:	92403c00 	and	x0, x0, #0xffff
    7f18:	9b047c00 	mul	x0, x0, x4
    7f1c:	d360fc00 	lsr	x0, x0, #32
    7f20:	eb01001f 	cmp	x0, x1
    7f24:	54000142 	b.cs	7f4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7f28:	8b000042 	add	x2, x2, x0
    7f2c:	39400040 	ldrb	w0, [x2]
    7f30:	7100041f 	cmp	w0, #0x1
    7f34:	540000c1 	b.ne	7f4c <fwp_caps12+0xac>  // b.any
    7f38:	aa1303e0 	mov	x0, x19
    7f3c:	f9400bf3 	ldr	x19, [sp, #16]
    7f40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7f44:	17fff2cb 	b	4a70 <fwp_mem_free>
    7f48:	34fffbe1 	cbz	w1, 7ec4 <fwp_caps12+0x24>
    7f4c:	f9400bf3 	ldr	x19, [sp, #16]
    7f50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7f54:	d65f03c0 	ret
    7f58:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7f5c:	91174042 	add	x2, x2, #0x5d0
    7f60:	f949d843 	ldr	x3, [x2, #5040]
    7f64:	f949ec41 	ldr	x1, [x2, #5080]
    7f68:	cb030000 	sub	x0, x0, x3
    7f6c:	eb01401f 	cmp	x0, x1, lsl #16
    7f70:	54fffee2 	b.cs	7f4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7f74:	d350fc01 	lsr	x1, x0, #16
    7f78:	f949fc44 	ldr	x4, [x2, #5112]
    7f7c:	8b010821 	add	x1, x1, x1, lsl #2
    7f80:	d37df021 	lsl	x1, x1, #3
    7f84:	8b010083 	add	x3, x4, x1
    7f88:	f9401062 	ldr	x2, [x3, #32]
    7f8c:	b4fffe02 	cbz	x2, 7f4c <fwp_caps12+0xac>
    7f90:	38616881 	ldrb	w1, [x4, x1]
    7f94:	7100083f 	cmp	w1, #0x2
    7f98:	54000280 	b.eq	7fe8 <fwp_caps12+0x148>  // b.none
    7f9c:	7100043f 	cmp	w1, #0x1
    7fa0:	54fffd61 	b.ne	7f4c <fwp_caps12+0xac>  // b.any
    7fa4:	92403c01 	and	x1, x0, #0xffff
    7fa8:	29430064 	ldp	w4, w0, [x3, #24]
    7fac:	9b047c21 	mul	x1, x1, x4
    7fb0:	d360fc21 	lsr	x1, x1, #32
    7fb4:	eb00003f 	cmp	x1, x0
    7fb8:	54fffca2 	b.cs	7f4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7fbc:	8b010042 	add	x2, x2, x1
    7fc0:	39400040 	ldrb	w0, [x2]
    7fc4:	34fffc40 	cbz	w0, 7f4c <fwp_caps12+0xac>
    7fc8:	7103f41f 	cmp	w0, #0xfd
    7fcc:	54000148 	b.hi	7ff4 <fwp_caps12+0x154>  // b.pmore
    7fd0:	11000400 	add	w0, w0, #0x1
    7fd4:	39000040 	strb	w0, [x2]
    7fd8:	17ffffdd 	b	7f4c <fwp_caps12+0xac>
    7fdc:	72003c1f 	tst	w0, #0xffff
    7fe0:	54fffb61 	b.ne	7f4c <fwp_caps12+0xac>  // b.any
    7fe4:	17ffffd2 	b	7f2c <fwp_caps12+0x8c>
    7fe8:	72003c1f 	tst	w0, #0xffff
    7fec:	54fffb01 	b.ne	7f4c <fwp_caps12+0xac>  // b.any
    7ff0:	17fffff4 	b	7fc0 <fwp_caps12+0x120>
    7ff4:	f9400bf3 	ldr	x19, [sp, #16]
    7ff8:	aa0203e0 	mov	x0, x2
    7ffc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8000:	17fff1b5 	b	46d4 <fwp_rc_wide_dup>

0000000000008004 <fwp_drop2>:
    8004:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    8008:	910003fd 	mov	x29, sp
    800c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8010:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    8014:	911742d5 	add	x21, x22, #0x5d0
    8018:	a90153f3 	stp	x19, x20, [sp, #16]
    801c:	aa0003f3 	mov	x19, x0
    8020:	f949daa1 	ldr	x1, [x21, #5040]
    8024:	f949eea0 	ldr	x0, [x21, #5080]
    8028:	cb010261 	sub	x1, x19, x1
    802c:	eb00403f 	cmp	x1, x0, lsl #16
    8030:	54000382 	b.cs	80a0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8034:	d350fc22 	lsr	x2, x1, #16
    8038:	f949fea3 	ldr	x3, [x21, #5112]
    803c:	8b020842 	add	x2, x2, x2, lsl #2
    8040:	d37df042 	lsl	x2, x2, #3
    8044:	8b020060 	add	x0, x3, x2
    8048:	f9401014 	ldr	x20, [x0, #32]
    804c:	b40002b4 	cbz	x20, 80a0 <fwp_drop2+0x9c>
    8050:	38626862 	ldrb	w2, [x3, x2]
    8054:	7100085f 	cmp	w2, #0x2
    8058:	540002c0 	b.eq	80b0 <fwp_drop2+0xac>  // b.none
    805c:	7100045f 	cmp	w2, #0x1
    8060:	54000201 	b.ne	80a0 <fwp_drop2+0x9c>  // b.any
    8064:	29430002 	ldp	w2, w0, [x0, #24]
    8068:	92403c21 	and	x1, x1, #0xffff
    806c:	9b027c21 	mul	x1, x1, x2
    8070:	d360fc21 	lsr	x1, x1, #32
    8074:	eb00003f 	cmp	x1, x0
    8078:	54000142 	b.cs	80a0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    807c:	8b010294 	add	x20, x20, x1
    8080:	39400280 	ldrb	w0, [x20]
    8084:	340000e0 	cbz	w0, 80a0 <fwp_drop2+0x9c>
    8088:	7100041f 	cmp	w0, #0x1
    808c:	540001e0 	b.eq	80c8 <fwp_drop2+0xc4>  // b.none
    8090:	7103fc1f 	cmp	w0, #0xff
    8094:	540007e0 	b.eq	8190 <fwp_drop2+0x18c>  // b.none
    8098:	51000400 	sub	w0, w0, #0x1
    809c:	39000280 	strb	w0, [x20]
    80a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    80a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    80a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    80ac:	d65f03c0 	ret
    80b0:	72003c3f 	tst	w1, #0xffff
    80b4:	54fffe60 	b.eq	8080 <fwp_drop2+0x7c>  // b.none
    80b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    80bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    80c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    80c4:	d65f03c0 	ret
    80c8:	911742c2 	add	x2, x22, #0x5d0
    80cc:	f9400660 	ldr	x0, [x19, #8]
    80d0:	f949d841 	ldr	x1, [x2, #5040]
    80d4:	f949ec42 	ldr	x2, [x2, #5080]
    80d8:	cb010001 	sub	x1, x0, x1
    80dc:	eb02403f 	cmp	x1, x2, lsl #16
    80e0:	54000382 	b.cs	8150 <fwp_drop2+0x14c>  // b.hs, b.nlast
    80e4:	d350fc22 	lsr	x2, x1, #16
    80e8:	8b020842 	add	x2, x2, x2, lsl #2
    80ec:	d37df042 	lsl	x2, x2, #3
    80f0:	8b020064 	add	x4, x3, x2
    80f4:	f9401094 	ldr	x20, [x4, #32]
    80f8:	b40002d4 	cbz	x20, 8150 <fwp_drop2+0x14c>
    80fc:	38626862 	ldrb	w2, [x3, x2]
    8100:	7100085f 	cmp	w2, #0x2
    8104:	54000400 	b.eq	8184 <fwp_drop2+0x180>  // b.none
    8108:	7100045f 	cmp	w2, #0x1
    810c:	54000221 	b.ne	8150 <fwp_drop2+0x14c>  // b.any
    8110:	29430883 	ldp	w3, w2, [x4, #24]
    8114:	92403c21 	and	x1, x1, #0xffff
    8118:	9b037c21 	mul	x1, x1, x3
    811c:	d360fc21 	lsr	x1, x1, #32
    8120:	eb02003f 	cmp	x1, x2
    8124:	54000162 	b.cs	8150 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8128:	8b010294 	add	x20, x20, x1
    812c:	39400281 	ldrb	w1, [x20]
    8130:	34000101 	cbz	w1, 8150 <fwp_drop2+0x14c>
    8134:	7100043f 	cmp	w1, #0x1
    8138:	54000220 	b.eq	817c <fwp_drop2+0x178>  // b.none
    813c:	7103fc3f 	cmp	w1, #0xff
    8140:	540005a0 	b.eq	81f4 <fwp_drop2+0x1f0>  // b.none
    8144:	51000421 	sub	w1, w1, #0x1
    8148:	39000281 	strb	w1, [x20]
    814c:	d503201f 	nop
    8150:	f9400a74 	ldr	x20, [x19, #16]
    8154:	aa1303e0 	mov	x0, x19
    8158:	97fff5bf 	bl	5854 <fwp_rc_free_arr>
    815c:	911742c0 	add	x0, x22, #0x5d0
    8160:	f949d801 	ldr	x1, [x0, #5040]
    8164:	f949ec00 	ldr	x0, [x0, #5080]
    8168:	cb010281 	sub	x1, x20, x1
    816c:	eb00403f 	cmp	x1, x0, lsl #16
    8170:	54fff982 	b.cs	80a0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8174:	aa1403f3 	mov	x19, x20
    8178:	17ffffaf 	b	8034 <fwp_drop2+0x30>
    817c:	97fff5b6 	bl	5854 <fwp_rc_free_arr>
    8180:	17fffff4 	b	8150 <fwp_drop2+0x14c>
    8184:	72003c3f 	tst	w1, #0xffff
    8188:	54fffe41 	b.ne	8150 <fwp_drop2+0x14c>  // b.any
    818c:	17ffffe8 	b	812c <fwp_drop2+0x128>
    8190:	ca544681 	eor	x1, x20, x20, lsr #17
    8194:	911742c0 	add	x0, x22, #0x5d0
    8198:	ca412421 	eor	x1, x1, x1, lsr #9
    819c:	8b210c01 	add	x1, x0, w1, uxtb #3
    81a0:	f94a2420 	ldr	x0, [x1, #5192]
    81a4:	b5000080 	cbnz	x0, 81b4 <fwp_drop2+0x1b0>
    81a8:	14000010 	b	81e8 <fwp_drop2+0x1e4>
    81ac:	f9400800 	ldr	x0, [x0, #16]
    81b0:	b40001c0 	cbz	x0, 81e8 <fwp_drop2+0x1e4>
    81b4:	f9400001 	ldr	x1, [x0]
    81b8:	eb14003f 	cmp	x1, x20
    81bc:	54ffff81 	b.ne	81ac <fwp_drop2+0x1a8>  // b.any
    81c0:	f9400401 	ldr	x1, [x0, #8]
    81c4:	d1000421 	sub	x1, x1, #0x1
    81c8:	f9000401 	str	x1, [x0, #8]
    81cc:	f103f83f 	cmp	x1, #0xfe
    81d0:	54fff681 	b.ne	80a0 <fwp_drop2+0x9c>  // b.any
    81d4:	aa1403e0 	mov	x0, x20
    81d8:	97fff186 	bl	47f0 <fwp_rc_forget_slot>
    81dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    81e0:	39000280 	strb	w0, [x20]
    81e4:	17ffffaf 	b	80a0 <fwp_drop2+0x9c>
    81e8:	f0000000 	adrp	x0, b000 <__divti3+0x180>
    81ec:	91240000 	add	x0, x0, #0x900
    81f0:	97ffed84 	bl	3800 <fwp_trap>
    81f4:	ca544680 	eor	x0, x20, x20, lsr #17
    81f8:	911742c1 	add	x1, x22, #0x5d0
    81fc:	ca402400 	eor	x0, x0, x0, lsr #9
    8200:	8b200c20 	add	x0, x1, w0, uxtb #3
    8204:	f94a2400 	ldr	x0, [x0, #5192]
    8208:	b5000080 	cbnz	x0, 8218 <fwp_drop2+0x214>
    820c:	17fffff7 	b	81e8 <fwp_drop2+0x1e4>
    8210:	f9400800 	ldr	x0, [x0, #16]
    8214:	b4fffea0 	cbz	x0, 81e8 <fwp_drop2+0x1e4>
    8218:	f9400001 	ldr	x1, [x0]
    821c:	eb14003f 	cmp	x1, x20
    8220:	54ffff81 	b.ne	8210 <fwp_drop2+0x20c>  // b.any
    8224:	f9400401 	ldr	x1, [x0, #8]
    8228:	d1000421 	sub	x1, x1, #0x1
    822c:	f9000401 	str	x1, [x0, #8]
    8230:	f103f83f 	cmp	x1, #0xfe
    8234:	54fff8e1 	b.ne	8150 <fwp_drop2+0x14c>  // b.any
    8238:	aa1403e0 	mov	x0, x20
    823c:	97fff16d 	bl	47f0 <fwp_rc_forget_slot>
    8240:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8244:	39000280 	strb	w0, [x20]
    8248:	17ffffc2 	b	8150 <fwp_drop2+0x14c>
    824c:	d503201f 	nop

0000000000008250 <fwp_arg_drop23>:
    8250:	7100003f 	cmp	w1, #0x0
    8254:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8258:	54000041 	b.ne	8260 <fwp_arg_drop23+0x10>  // b.any
    825c:	d65f03c0 	ret
    8260:	f9400000 	ldr	x0, [x0]
    8264:	17ffff68 	b	8004 <fwp_drop2>
    8268:	d503201f 	nop
    826c:	d503201f 	nop

0000000000008270 <fwp_caps23>:
    8270:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8274:	910003fd 	mov	x29, sp
    8278:	f9000bf3 	str	x19, [sp, #16]
    827c:	aa0003f3 	mov	x19, x0
    8280:	b9400400 	ldr	w0, [x0, #4]
    8284:	340004a0 	cbz	w0, 8318 <fwp_caps23+0xa8>
    8288:	f9400660 	ldr	x0, [x19, #8]
    828c:	350004e1 	cbnz	w1, 8328 <fwp_caps23+0xb8>
    8290:	97ffff5d 	bl	8004 <fwp_drop2>
    8294:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    8298:	91174042 	add	x2, x2, #0x5d0
    829c:	f949d840 	ldr	x0, [x2, #5040]
    82a0:	f949ec41 	ldr	x1, [x2, #5080]
    82a4:	cb000260 	sub	x0, x19, x0
    82a8:	eb01401f 	cmp	x0, x1, lsl #16
    82ac:	54000382 	b.cs	831c <fwp_caps23+0xac>  // b.hs, b.nlast
    82b0:	d350fc01 	lsr	x1, x0, #16
    82b4:	f949fc44 	ldr	x4, [x2, #5112]
    82b8:	8b010821 	add	x1, x1, x1, lsl #2
    82bc:	d37df021 	lsl	x1, x1, #3
    82c0:	8b010083 	add	x3, x4, x1
    82c4:	f9401062 	ldr	x2, [x3, #32]
    82c8:	b40002a2 	cbz	x2, 831c <fwp_caps23+0xac>
    82cc:	38616881 	ldrb	w1, [x4, x1]
    82d0:	7100083f 	cmp	w1, #0x2
    82d4:	540006c0 	b.eq	83ac <fwp_caps23+0x13c>  // b.none
    82d8:	7100043f 	cmp	w1, #0x1
    82dc:	54000201 	b.ne	831c <fwp_caps23+0xac>  // b.any
    82e0:	29430464 	ldp	w4, w1, [x3, #24]
    82e4:	92403c00 	and	x0, x0, #0xffff
    82e8:	9b047c00 	mul	x0, x0, x4
    82ec:	d360fc00 	lsr	x0, x0, #32
    82f0:	eb01001f 	cmp	x0, x1
    82f4:	54000142 	b.cs	831c <fwp_caps23+0xac>  // b.hs, b.nlast
    82f8:	8b000042 	add	x2, x2, x0
    82fc:	39400040 	ldrb	w0, [x2]
    8300:	7100041f 	cmp	w0, #0x1
    8304:	540000c1 	b.ne	831c <fwp_caps23+0xac>  // b.any
    8308:	aa1303e0 	mov	x0, x19
    830c:	f9400bf3 	ldr	x19, [sp, #16]
    8310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8314:	17fff1d7 	b	4a70 <fwp_mem_free>
    8318:	34fffbe1 	cbz	w1, 8294 <fwp_caps23+0x24>
    831c:	f9400bf3 	ldr	x19, [sp, #16]
    8320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8324:	d65f03c0 	ret
    8328:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    832c:	91174042 	add	x2, x2, #0x5d0
    8330:	f949d843 	ldr	x3, [x2, #5040]
    8334:	f949ec41 	ldr	x1, [x2, #5080]
    8338:	cb030000 	sub	x0, x0, x3
    833c:	eb01401f 	cmp	x0, x1, lsl #16
    8340:	54fffee2 	b.cs	831c <fwp_caps23+0xac>  // b.hs, b.nlast
    8344:	d350fc01 	lsr	x1, x0, #16
    8348:	f949fc44 	ldr	x4, [x2, #5112]
    834c:	8b010821 	add	x1, x1, x1, lsl #2
    8350:	d37df021 	lsl	x1, x1, #3
    8354:	8b010083 	add	x3, x4, x1
    8358:	f9401062 	ldr	x2, [x3, #32]
    835c:	b4fffe02 	cbz	x2, 831c <fwp_caps23+0xac>
    8360:	38616881 	ldrb	w1, [x4, x1]
    8364:	7100083f 	cmp	w1, #0x2
    8368:	54000280 	b.eq	83b8 <fwp_caps23+0x148>  // b.none
    836c:	7100043f 	cmp	w1, #0x1
    8370:	54fffd61 	b.ne	831c <fwp_caps23+0xac>  // b.any
    8374:	92403c01 	and	x1, x0, #0xffff
    8378:	29430064 	ldp	w4, w0, [x3, #24]
    837c:	9b047c21 	mul	x1, x1, x4
    8380:	d360fc21 	lsr	x1, x1, #32
    8384:	eb00003f 	cmp	x1, x0
    8388:	54fffca2 	b.cs	831c <fwp_caps23+0xac>  // b.hs, b.nlast
    838c:	8b010042 	add	x2, x2, x1
    8390:	39400040 	ldrb	w0, [x2]
    8394:	34fffc40 	cbz	w0, 831c <fwp_caps23+0xac>
    8398:	7103f41f 	cmp	w0, #0xfd
    839c:	54000148 	b.hi	83c4 <fwp_caps23+0x154>  // b.pmore
    83a0:	11000400 	add	w0, w0, #0x1
    83a4:	39000040 	strb	w0, [x2]
    83a8:	17ffffdd 	b	831c <fwp_caps23+0xac>
    83ac:	72003c1f 	tst	w0, #0xffff
    83b0:	54fffb61 	b.ne	831c <fwp_caps23+0xac>  // b.any
    83b4:	17ffffd2 	b	82fc <fwp_caps23+0x8c>
    83b8:	72003c1f 	tst	w0, #0xffff
    83bc:	54fffb01 	b.ne	831c <fwp_caps23+0xac>  // b.any
    83c0:	17fffff4 	b	8390 <fwp_caps23+0x120>
    83c4:	f9400bf3 	ldr	x19, [sp, #16]
    83c8:	aa0203e0 	mov	x0, x2
    83cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83d0:	17fff0c1 	b	46d4 <fwp_rc_wide_dup>

00000000000083d4 <f23>:
    83d4:	d101c3ff 	sub	sp, sp, #0x70
    83d8:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    83dc:	f947f421 	ldr	x1, [x1, #4072]
    83e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    83e4:	910083fd 	add	x29, sp, #0x20
    83e8:	a90563f7 	stp	x23, x24, [sp, #80]
    83ec:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    83f0:	911742e3 	add	x3, x23, #0x5d0
    83f4:	a90353f3 	stp	x19, x20, [sp, #48]
    83f8:	a9045bf5 	stp	x21, x22, [sp, #64]
    83fc:	aa0003f6 	mov	x22, x0
    8400:	a9066bf9 	stp	x25, x26, [sp, #96]
    8404:	f949ec62 	ldr	x2, [x3, #5080]
    8408:	f9400024 	ldr	x4, [x1]
    840c:	f9000fe4 	str	x4, [sp, #24]
    8410:	d2800004 	mov	x4, #0x0                   	// #0
    8414:	f949d861 	ldr	x1, [x3, #5040]
    8418:	d370bc42 	lsl	x2, x2, #16
    841c:	b40015a0 	cbz	x0, 86d0 <f23+0x2fc>
    8420:	f9400818 	ldr	x24, [x0, #16]
    8424:	cb010301 	sub	x1, x24, x1
    8428:	eb02003f 	cmp	x1, x2
    842c:	54000362 	b.cs	8498 <f23+0xc4>  // b.hs, b.nlast
    8430:	f949fc60 	ldr	x0, [x3, #5112]
    8434:	d350fc22 	lsr	x2, x1, #16
    8438:	8b020842 	add	x2, x2, x2, lsl #2
    843c:	8b020c02 	add	x2, x0, x2, lsl #3
    8440:	f9401040 	ldr	x0, [x2, #32]
    8444:	b40002a0 	cbz	x0, 8498 <f23+0xc4>
    8448:	39400043 	ldrb	w3, [x2]
    844c:	7100087f 	cmp	w3, #0x2
    8450:	540013a0 	b.eq	86c4 <f23+0x2f0>  // b.none
    8454:	7100047f 	cmp	w3, #0x1
    8458:	540001c1 	b.ne	8490 <f23+0xbc>  // b.any
    845c:	29430843 	ldp	w3, w2, [x2, #24]
    8460:	92403c21 	and	x1, x1, #0xffff
    8464:	9b037c21 	mul	x1, x1, x3
    8468:	d360fc21 	lsr	x1, x1, #32
    846c:	eb02003f 	cmp	x1, x2
    8470:	54000102 	b.cs	8490 <f23+0xbc>  // b.hs, b.nlast
    8474:	8b010000 	add	x0, x0, x1
    8478:	39400001 	ldrb	w1, [x0]
    847c:	340000a1 	cbz	w1, 8490 <f23+0xbc>
    8480:	7103f43f 	cmp	w1, #0xfd
    8484:	54001688 	b.hi	8754 <f23+0x380>  // b.pmore
    8488:	11000421 	add	w1, w1, #0x1
    848c:	39000001 	strb	w1, [x0]
    8490:	d2800000 	mov	x0, #0x0                   	// #0
    8494:	b40000d6 	cbz	x22, 84ac <f23+0xd8>
    8498:	aa1603e1 	mov	x1, x22
    849c:	d2800000 	mov	x0, #0x0                   	// #0
    84a0:	f9400821 	ldr	x1, [x1, #16]
    84a4:	91000400 	add	x0, x0, #0x1
    84a8:	b5ffffc1 	cbnz	x1, 84a0 <f23+0xcc>
    84ac:	b40011b8 	cbz	x24, 86e0 <f23+0x30c>
    84b0:	aa1803e1 	mov	x1, x24
    84b4:	d2800002 	mov	x2, #0x0                   	// #0
    84b8:	f9400821 	ldr	x1, [x1, #16]
    84bc:	91000442 	add	x2, x2, #0x1
    84c0:	b5ffffc1 	cbnz	x1, 84b8 <f23+0xe4>
    84c4:	eb00005f 	cmp	x2, x0
    84c8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    84cc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    84d0:	eb01033f 	cmp	x25, x1
    84d4:	54001468 	b.hi	8760 <f23+0x38c>  // b.pmore
    84d8:	d37ffb33 	lsl	x19, x25, #1
    84dc:	52800041 	mov	w1, #0x2                   	// #2
    84e0:	91000660 	add	x0, x19, #0x1
    84e4:	d37df000 	lsl	x0, x0, #3
    84e8:	97fff282 	bl	4ef0 <fwp_heap_alloc>
    84ec:	911742e1 	add	x1, x23, #0x5d0
    84f0:	aa0003fa 	mov	x26, x0
    84f4:	f9000013 	str	x19, [x0]
    84f8:	aa0103e0 	mov	x0, x1
    84fc:	f949d821 	ldr	x1, [x1, #5040]
    8500:	f949ec00 	ldr	x0, [x0, #5080]
    8504:	cb010341 	sub	x1, x26, x1
    8508:	eb00403f 	cmp	x1, x0, lsl #16
    850c:	54000342 	b.cs	8574 <f23+0x1a0>  // b.hs, b.nlast
    8510:	911742e2 	add	x2, x23, #0x5d0
    8514:	d350fc20 	lsr	x0, x1, #16
    8518:	8b000800 	add	x0, x0, x0, lsl #2
    851c:	f949fc43 	ldr	x3, [x2, #5112]
    8520:	d37df002 	lsl	x2, x0, #3
    8524:	8b020060 	add	x0, x3, x2
    8528:	f9401013 	ldr	x19, [x0, #32]
    852c:	b4000253 	cbz	x19, 8574 <f23+0x1a0>
    8530:	38626862 	ldrb	w2, [x3, x2]
    8534:	7100085f 	cmp	w2, #0x2
    8538:	54000c00 	b.eq	86b8 <f23+0x2e4>  // b.none
    853c:	7100045f 	cmp	w2, #0x1
    8540:	540001a1 	b.ne	8574 <f23+0x1a0>  // b.any
    8544:	29430002 	ldp	w2, w0, [x0, #24]
    8548:	92403c21 	and	x1, x1, #0xffff
    854c:	9b027c21 	mul	x1, x1, x2
    8550:	d360fc21 	lsr	x1, x1, #32
    8554:	eb00003f 	cmp	x1, x0
    8558:	540000e2 	b.cs	8574 <f23+0x1a0>  // b.hs, b.nlast
    855c:	8b010273 	add	x19, x19, x1
    8560:	39400260 	ldrb	w0, [x19]
    8564:	7103fc1f 	cmp	w0, #0xff
    8568:	54000da0 	b.eq	871c <f23+0x348>  // b.none
    856c:	52800020 	mov	w0, #0x1                   	// #1
    8570:	39000260 	strb	w0, [x19]
    8574:	b4000259 	cbz	x25, 85bc <f23+0x1e8>
    8578:	8b191359 	add	x25, x26, x25, lsl #4
    857c:	aa1a03f3 	mov	x19, x26
    8580:	aa1603f5 	mov	x21, x22
    8584:	aa1803f4 	mov	x20, x24
    8588:	f9400683 	ldr	x3, [x20, #8]
    858c:	f94006a2 	ldr	x2, [x21, #8]
    8590:	f9400861 	ldr	x1, [x3, #16]
    8594:	f9400840 	ldr	x0, [x2, #16]
    8598:	fd400461 	ldr	d1, [x3, #8]
    859c:	fd400440 	ldr	d0, [x2, #8]
    85a0:	97fff3d4 	bl	54f0 <w107>
    85a4:	f9000660 	str	x0, [x19, #8]
    85a8:	f8010e61 	str	x1, [x19, #16]!
    85ac:	f9400a94 	ldr	x20, [x20, #16]
    85b0:	f9400ab5 	ldr	x21, [x21, #16]
    85b4:	eb13033f 	cmp	x25, x19
    85b8:	54fffe81 	b.ne	8588 <f23+0x1b4>  // b.any
    85bc:	aa1803e0 	mov	x0, x24
    85c0:	97fffe91 	bl	8004 <fwp_drop2>
    85c4:	aa1603e0 	mov	x0, x22
    85c8:	97fffe8f 	bl	8004 <fwp_drop2>
    85cc:	911742f7 	add	x23, x23, #0x5d0
    85d0:	aa1a03e0 	mov	x0, x26
    85d4:	97fff40b 	bl	5600 <w164.constprop.0>
    85d8:	aa0103f3 	mov	x19, x1
    85dc:	aa0003f4 	mov	x20, x0
    85e0:	aa1a03e0 	mov	x0, x26
    85e4:	97fff8b3 	bl	68b0 <fwp_drop4>
    85e8:	a900cff4 	stp	x20, x19, [sp, #8]
    85ec:	910023e1 	add	x1, sp, #0x8
    85f0:	52800000 	mov	w0, #0x0                   	// #0
    85f4:	97fff42b 	bl	56a0 <fwp_data.part.0.constprop.0>
    85f8:	f949dae1 	ldr	x1, [x23, #5040]
    85fc:	aa0003f3 	mov	x19, x0
    8600:	f949eee0 	ldr	x0, [x23, #5080]
    8604:	cb010261 	sub	x1, x19, x1
    8608:	eb00403f 	cmp	x1, x0, lsl #16
    860c:	54000322 	b.cs	8670 <f23+0x29c>  // b.hs, b.nlast
    8610:	d350fc22 	lsr	x2, x1, #16
    8614:	f949fee3 	ldr	x3, [x23, #5112]
    8618:	8b020842 	add	x2, x2, x2, lsl #2
    861c:	d37df042 	lsl	x2, x2, #3
    8620:	8b020060 	add	x0, x3, x2
    8624:	f9401014 	ldr	x20, [x0, #32]
    8628:	b4000254 	cbz	x20, 8670 <f23+0x29c>
    862c:	38626862 	ldrb	w2, [x3, x2]
    8630:	7100085f 	cmp	w2, #0x2
    8634:	540003c0 	b.eq	86ac <f23+0x2d8>  // b.none
    8638:	7100045f 	cmp	w2, #0x1
    863c:	540001a1 	b.ne	8670 <f23+0x29c>  // b.any
    8640:	29430002 	ldp	w2, w0, [x0, #24]
    8644:	92403c21 	and	x1, x1, #0xffff
    8648:	9b027c21 	mul	x1, x1, x2
    864c:	d360fc21 	lsr	x1, x1, #32
    8650:	eb00003f 	cmp	x1, x0
    8654:	540000e2 	b.cs	8670 <f23+0x29c>  // b.hs, b.nlast
    8658:	8b010294 	add	x20, x20, x1
    865c:	39400280 	ldrb	w0, [x20]
    8660:	7103fc1f 	cmp	w0, #0xff
    8664:	54000620 	b.eq	8728 <f23+0x354>  // b.none
    8668:	52800020 	mov	w0, #0x1                   	// #1
    866c:	39000280 	strb	w0, [x20]
    8670:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8674:	f947f400 	ldr	x0, [x0, #4072]
    8678:	f9400fe2 	ldr	x2, [sp, #24]
    867c:	f9400001 	ldr	x1, [x0]
    8680:	eb010042 	subs	x2, x2, x1
    8684:	d2800001 	mov	x1, #0x0                   	// #0
    8688:	540006a1 	b.ne	875c <f23+0x388>  // b.any
    868c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8690:	aa1303e0 	mov	x0, x19
    8694:	a94353f3 	ldp	x19, x20, [sp, #48]
    8698:	a9445bf5 	ldp	x21, x22, [sp, #64]
    869c:	a94563f7 	ldp	x23, x24, [sp, #80]
    86a0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    86a4:	9101c3ff 	add	sp, sp, #0x70
    86a8:	d65f03c0 	ret
    86ac:	72003c3f 	tst	w1, #0xffff
    86b0:	54fffe01 	b.ne	8670 <f23+0x29c>  // b.any
    86b4:	17ffffea 	b	865c <f23+0x288>
    86b8:	72003c3f 	tst	w1, #0xffff
    86bc:	54fff5c1 	b.ne	8574 <f23+0x1a0>  // b.any
    86c0:	17ffffa8 	b	8560 <f23+0x18c>
    86c4:	72003c3f 	tst	w1, #0xffff
    86c8:	54ffee41 	b.ne	8490 <f23+0xbc>  // b.any
    86cc:	17ffff6b 	b	8478 <f23+0xa4>
    86d0:	cb0103e1 	neg	x1, x1
    86d4:	eb02003f 	cmp	x1, x2
    86d8:	540002e3 	b.cc	8734 <f23+0x360>  // b.lo, b.ul, b.last
    86dc:	d503201f 	nop
    86e0:	52800041 	mov	w1, #0x2                   	// #2
    86e4:	d2800100 	mov	x0, #0x8                   	// #8
    86e8:	97fff202 	bl	4ef0 <fwp_heap_alloc>
    86ec:	aa0003e1 	mov	x1, x0
    86f0:	911742e0 	add	x0, x23, #0x5d0
    86f4:	aa0103fa 	mov	x26, x1
    86f8:	d2800018 	mov	x24, #0x0                   	// #0
    86fc:	f900003f 	str	xzr, [x1]
    8700:	f949d801 	ldr	x1, [x0, #5040]
    8704:	f949ec00 	ldr	x0, [x0, #5080]
    8708:	cb010341 	sub	x1, x26, x1
    870c:	eb00403f 	cmp	x1, x0, lsl #16
    8710:	54fff562 	b.cs	85bc <f23+0x1e8>  // b.hs, b.nlast
    8714:	d2800019 	mov	x25, #0x0                   	// #0
    8718:	17ffff7e 	b	8510 <f23+0x13c>
    871c:	aa1303e0 	mov	x0, x19
    8720:	97fff034 	bl	47f0 <fwp_rc_forget_slot>
    8724:	17ffff92 	b	856c <f23+0x198>
    8728:	aa1403e0 	mov	x0, x20
    872c:	97fff031 	bl	47f0 <fwp_rc_forget_slot>
    8730:	17ffffce 	b	8668 <f23+0x294>
    8734:	f949fc62 	ldr	x2, [x3, #5112]
    8738:	d350fc20 	lsr	x0, x1, #16
    873c:	8b000800 	add	x0, x0, x0, lsl #2
    8740:	8b000c42 	add	x2, x2, x0, lsl #3
    8744:	f9401040 	ldr	x0, [x2, #32]
    8748:	b4fffcc0 	cbz	x0, 86e0 <f23+0x30c>
    874c:	d2800018 	mov	x24, #0x0                   	// #0
    8750:	17ffff3e 	b	8448 <f23+0x74>
    8754:	97ffefe0 	bl	46d4 <fwp_rc_wide_dup>
    8758:	17ffff4e 	b	8490 <f23+0xbc>
    875c:	97ffe849 	bl	2880 <__stack_chk_fail@plt>
    8760:	f0000000 	adrp	x0, b000 <__divti3+0x180>
    8764:	912b0000 	add	x0, x0, #0xac0
    8768:	97ffec26 	bl	3800 <fwp_trap>
    876c:	d503201f 	nop

0000000000008770 <fwp_owned_entry23>:
    8770:	f9400000 	ldr	x0, [x0]
    8774:	17ffff18 	b	83d4 <f23>
    8778:	d503201f 	nop
    877c:	d503201f 	nop

0000000000008780 <e23>:
    8780:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8784:	910003fd 	mov	x29, sp
    8788:	f9000bf3 	str	x19, [sp, #16]
    878c:	f9400013 	ldr	x19, [x0]
    8790:	aa1303e0 	mov	x0, x19
    8794:	97fff40b 	bl	57c0 <fwp_rc_share>
    8798:	aa1303e0 	mov	x0, x19
    879c:	97ffff0e 	bl	83d4 <f23>
    87a0:	aa0003f3 	mov	x19, x0
    87a4:	97fff407 	bl	57c0 <fwp_rc_share>
    87a8:	aa1303e0 	mov	x0, x19
    87ac:	f9400bf3 	ldr	x19, [sp, #16]
    87b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    87b4:	d65f03c0 	ret
    87b8:	d503201f 	nop
    87bc:	d503201f 	nop

00000000000087c0 <fwp_write>:
    87c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    87c4:	910003fd 	mov	x29, sp
    87c8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    87cc:	f947f484 	ldr	x4, [x4, #4072]
    87d0:	a90153f3 	stp	x19, x20, [sp, #16]
    87d4:	d10943ff 	sub	sp, sp, #0x250
    87d8:	b9400045 	ldr	w5, [x2]
    87dc:	aa0003f4 	mov	x20, x0
    87e0:	f9400080 	ldr	x0, [x4]
    87e4:	f90127e0 	str	x0, [sp, #584]
    87e8:	d2800000 	mov	x0, #0x0                   	// #0
    87ec:	710064bf 	cmp	w5, #0x19
    87f0:	54000408 	b.hi	8870 <fwp_write+0xb0>  // b.pmore
    87f4:	90000020 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    87f8:	aa0103f3 	mov	x19, x1
    87fc:	910bc000 	add	x0, x0, #0x2f0
    8800:	f9013bf5 	str	x21, [sp, #624]
    8804:	f9013ff6 	str	x22, [sp, #632]
    8808:	f90153fb 	str	x27, [sp, #672]
    880c:	f90157fc 	str	x28, [sp, #680]
    8810:	aa0203fc 	mov	x28, x2
    8814:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8818:	10000061 	adr	x1, 8824 <fwp_write+0x64>
    881c:	8b20a820 	add	x0, x1, w0, sxth #2
    8820:	d61f0000 	br	x0
    8824:	910123e0 	add	x0, sp, #0x48
    8828:	aa1303e5 	mov	x5, x19
    882c:	f0000004 	adrp	x4, b000 <__divti3+0x180>
    8830:	aa0003f3 	mov	x19, x0
    8834:	912d0084 	add	x4, x4, #0xb40
    8838:	d2804003 	mov	x3, #0x200                 	// #512
    883c:	aa0303e1 	mov	x1, x3
    8840:	52800042 	mov	w2, #0x2                   	// #2
    8844:	97ffe7eb 	bl	27f0 <__snprintf_chk@plt>
    8848:	aa1303e0 	mov	x0, x19
    884c:	97ffe7b1 	bl	2710 <strlen@plt>
    8850:	aa1303e1 	mov	x1, x19
    8854:	aa0003e2 	mov	x2, x0
    8858:	aa1403e0 	mov	x0, x20
    885c:	97ffeb4d 	bl	3590 <buf_put>
    8860:	f9413bf5 	ldr	x21, [sp, #624]
    8864:	f9413ff6 	ldr	x22, [sp, #632]
    8868:	f94153fb 	ldr	x27, [sp, #672]
    886c:	f94157fc 	ldr	x28, [sp, #680]
    8870:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8874:	f947f400 	ldr	x0, [x0, #4072]
    8878:	f94127e2 	ldr	x2, [sp, #584]
    887c:	f9400001 	ldr	x1, [x0]
    8880:	eb010042 	subs	x2, x2, x1
    8884:	d2800001 	mov	x1, #0x0                   	// #0
    8888:	540077c1 	b.ne	9780 <fwp_write+0xfc0>  // b.any
    888c:	910943ff 	add	sp, sp, #0x250
    8890:	a94153f3 	ldp	x19, x20, [sp, #16]
    8894:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8898:	d65f03c0 	ret
    889c:	910123e0 	add	x0, sp, #0x48
    88a0:	aa1303e5 	mov	x5, x19
    88a4:	f0000004 	adrp	x4, b000 <__divti3+0x180>
    88a8:	aa0003f3 	mov	x19, x0
    88ac:	912ce084 	add	x4, x4, #0xb38
    88b0:	d2804003 	mov	x3, #0x200                 	// #512
    88b4:	17ffffe2 	b	883c <fwp_write+0x7c>
    88b8:	71004cbf 	cmp	w5, #0x13
    88bc:	f0000000 	adrp	x0, b000 <__divti3+0x180>
    88c0:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    88c4:	912ca000 	add	x0, x0, #0xb28
    88c8:	912cc021 	add	x1, x1, #0xb30
    88cc:	d2800082 	mov	x2, #0x4                   	// #4
    88d0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    88d4:	aa1403e0 	mov	x0, x20
    88d8:	f90143f7 	str	x23, [sp, #640]
    88dc:	d2800016 	mov	x22, #0x0                   	// #0
    88e0:	f90147f8 	str	x24, [sp, #648]
    88e4:	97ffeb2b 	bl	3590 <buf_put>
    88e8:	f9400260 	ldr	x0, [x19]
    88ec:	f0000017 	adrp	x23, b000 <__divti3+0x180>
    88f0:	d2800015 	mov	x21, #0x0                   	// #0
    88f4:	912ec2f7 	add	x23, x23, #0xbb0
    88f8:	b40047a0 	cbz	x0, 91ec <fwp_write+0xa2c>
    88fc:	b9400380 	ldr	w0, [x28]
    8900:	52800003 	mov	w3, #0x0                   	// #0
    8904:	f9401f82 	ldr	x2, [x28, #56]
    8908:	71004c1f 	cmp	w0, #0x13
    890c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8910:	aa1403e0 	mov	x0, x20
    8914:	8b010e61 	add	x1, x19, x1, lsl #3
    8918:	f9400421 	ldr	x1, [x1, #8]
    891c:	97ffffa9 	bl	87c0 <fwp_write>
    8920:	b9400380 	ldr	w0, [x28]
    8924:	7100481f 	cmp	w0, #0x12
    8928:	54004b40 	b.eq	9290 <fwp_write+0xad0>  // b.none
    892c:	f9400260 	ldr	x0, [x19]
    8930:	910006b5 	add	x21, x21, #0x1
    8934:	91000ad6 	add	x22, x22, #0x2
    8938:	eb15001f 	cmp	x0, x21
    893c:	54004589 	b.ls	91ec <fwp_write+0xa2c>  // b.plast
    8940:	aa1703e1 	mov	x1, x23
    8944:	aa1403e0 	mov	x0, x20
    8948:	d2800042 	mov	x2, #0x2                   	// #2
    894c:	97ffeb11 	bl	3590 <buf_put>
    8950:	17ffffeb 	b	88fc <fwp_write+0x13c>
    8954:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    8958:	912da021 	add	x1, x1, #0xb68
    895c:	d28000c2 	mov	x2, #0x6                   	// #6
    8960:	aa1403e0 	mov	x0, x20
    8964:	91004273 	add	x19, x19, #0x10
    8968:	97ffeb0a 	bl	3590 <buf_put>
    896c:	aa1303e0 	mov	x0, x19
    8970:	97ffe768 	bl	2710 <strlen@plt>
    8974:	aa1303e1 	mov	x1, x19
    8978:	aa0003e2 	mov	x2, x0
    897c:	aa1403e0 	mov	x0, x20
    8980:	97ffeb04 	bl	3590 <buf_put>
    8984:	528007c3 	mov	w3, #0x3e                  	// #62
    8988:	aa1403e0 	mov	x0, x20
    898c:	91001fe1 	add	x1, sp, #0x7
    8990:	d2800022 	mov	x2, #0x1                   	// #1
    8994:	39001fe3 	strb	w3, [sp, #7]
    8998:	17ffffb1 	b	885c <fwp_write+0x9c>
    899c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    89a0:	f947f400 	ldr	x0, [x0, #4072]
    89a4:	f94127e2 	ldr	x2, [sp, #584]
    89a8:	f9400001 	ldr	x1, [x0]
    89ac:	eb010042 	subs	x2, x2, x1
    89b0:	d2800001 	mov	x1, #0x0                   	// #0
    89b4:	540034e1 	b.ne	9050 <fwp_write+0x890>  // b.any
    89b8:	f9413bf5 	ldr	x21, [sp, #624]
    89bc:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    89c0:	f9413ff6 	ldr	x22, [sp, #632]
    89c4:	aa1403e0 	mov	x0, x20
    89c8:	912d2021 	add	x1, x1, #0xb48
    89cc:	d2800142 	mov	x2, #0xa                   	// #10
    89d0:	f94153fb 	ldr	x27, [sp, #672]
    89d4:	f94157fc 	ldr	x28, [sp, #680]
    89d8:	910943ff 	add	sp, sp, #0x250
    89dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    89e0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    89e4:	17ffeaeb 	b	3590 <buf_put>
    89e8:	f9400456 	ldr	x22, [x2, #8]
    89ec:	f90143f7 	str	x23, [sp, #640]
    89f0:	f90147f8 	str	x24, [sp, #648]
    89f4:	b4005b16 	cbz	x22, 9554 <fwp_write+0xd94>
    89f8:	aa1603e0 	mov	x0, x22
    89fc:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    8a00:	912f2021 	add	x1, x1, #0xbc8
    8a04:	97ffe7bf 	bl	2900 <strcmp@plt>
    8a08:	2a0003f5 	mov	w21, w0
    8a0c:	34005fe0 	cbz	w0, 9608 <fwp_write+0xe48>
    8a10:	aa1603e0 	mov	x0, x22
    8a14:	97ffe73f 	bl	2710 <strlen@plt>
    8a18:	aa1603e1 	mov	x1, x22
    8a1c:	aa0003e2 	mov	x2, x0
    8a20:	aa1403e0 	mov	x0, x20
    8a24:	97ffeadb 	bl	3590 <buf_put>
    8a28:	52800403 	mov	w3, #0x20                  	// #32
    8a2c:	91001ff5 	add	x21, sp, #0x7
    8a30:	aa1503e1 	mov	x1, x21
    8a34:	aa1403e0 	mov	x0, x20
    8a38:	d2800022 	mov	x2, #0x1                   	// #1
    8a3c:	39001fe3 	strb	w3, [sp, #7]
    8a40:	97ffead4 	bl	3590 <buf_put>
    8a44:	52800f63 	mov	w3, #0x7b                  	// #123
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	aa1503e1 	mov	x1, x21
    8a50:	d2800022 	mov	x2, #0x1                   	// #1
    8a54:	39001fe3 	strb	w3, [sp, #7]
    8a58:	97ffeace 	bl	3590 <buf_put>
    8a5c:	b9401380 	ldr	w0, [x28, #16]
    8a60:	52800018 	mov	w24, #0x0                   	// #0
    8a64:	7100001f 	cmp	w0, #0x0
    8a68:	54003aad 	b.le	91bc <fwp_write+0x9fc>
    8a6c:	f9014bf9 	str	x25, [sp, #656]
    8a70:	f0000019 	adrp	x25, b000 <__divti3+0x180>
    8a74:	912fc339 	add	x25, x25, #0xbf0
    8a78:	f9014ffa 	str	x26, [sp, #664]
    8a7c:	f000001a 	adrp	x26, b000 <__divti3+0x180>
    8a80:	912ec35a 	add	x26, x26, #0xbb0
    8a84:	91002276 	add	x22, x19, #0x8
    8a88:	d2800013 	mov	x19, #0x0                   	// #0
    8a8c:	b5003e93 	cbnz	x19, 925c <fwp_write+0xa9c>
    8a90:	d37df277 	lsl	x23, x19, #3
    8a94:	34003cb8 	cbz	w24, 9228 <fwp_write+0xa68>
    8a98:	f9401382 	ldr	x2, [x28, #32]
    8a9c:	aa1403e0 	mov	x0, x20
    8aa0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8aa4:	52800003 	mov	w3, #0x0                   	// #0
    8aa8:	f8776842 	ldr	x2, [x2, x23]
    8aac:	91000673 	add	x19, x19, #0x1
    8ab0:	97ffff44 	bl	87c0 <fwp_write>
    8ab4:	b9401380 	ldr	w0, [x28, #16]
    8ab8:	6b13001f 	cmp	w0, w19
    8abc:	54fffe8c 	b.gt	8a8c <fwp_write+0x2cc>
    8ac0:	f9414bf9 	ldr	x25, [sp, #656]
    8ac4:	f9414ffa 	ldr	x26, [sp, #664]
    8ac8:	340037b8 	cbz	w24, 91bc <fwp_write+0x9fc>
    8acc:	52800523 	mov	w3, #0x29                  	// #41
    8ad0:	aa1503e1 	mov	x1, x21
    8ad4:	aa1403e0 	mov	x0, x20
    8ad8:	d2800022 	mov	x2, #0x1                   	// #1
    8adc:	39001fe3 	strb	w3, [sp, #7]
    8ae0:	97ffeaac 	bl	3590 <buf_put>
    8ae4:	f9413bf5 	ldr	x21, [sp, #624]
    8ae8:	f9413ff6 	ldr	x22, [sp, #632]
    8aec:	f94143f7 	ldr	x23, [sp, #640]
    8af0:	f94147f8 	ldr	x24, [sp, #648]
    8af4:	f94153fb 	ldr	x27, [sp, #672]
    8af8:	f94157fc 	ldr	x28, [sp, #680]
    8afc:	17ffff5d 	b	8870 <fwp_write+0xb0>
    8b00:	b9404855 	ldr	w21, [x2, #72]
    8b04:	aa1403e0 	mov	x0, x20
    8b08:	93407eb6 	sxtw	x22, w21
    8b0c:	91000ac1 	add	x1, x22, #0x2
    8b10:	97ffea6d 	bl	34c4 <buf_grow>
    8b14:	a9400281 	ldp	x1, x0, [x20]
    8b18:	528e8603 	mov	w3, #0x7430                	// #29744
    8b1c:	78206823 	strh	w3, [x1, x0]
    8b20:	8b000022 	add	x2, x1, x0
    8b24:	710002bf 	cmp	w21, #0x0
    8b28:	540036cd 	b.le	9200 <fwp_write+0xa40>
    8b2c:	110006a3 	add	w3, w21, #0x1
    8b30:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8b34:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8b38:	91000449 	add	x9, x2, #0x1
    8b3c:	8b23c043 	add	x3, x2, w3, sxtw
    8b40:	f28aaac6 	movk	x6, #0x5556
    8b44:	f2955568 	movk	x8, #0xaaab
    8b48:	1400000d 	b	8b7c <fwp_write+0x3bc>
    8b4c:	d2800021 	mov	x1, #0x1                   	// #1
    8b50:	528005a5 	mov	w5, #0x2d                  	// #45
    8b54:	f100001f 	cmp	x0, #0x0
    8b58:	9b467e60 	smulh	x0, x19, x6
    8b5c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8b60:	381ff465 	strb	w5, [x3], #-1
    8b64:	cb040000 	sub	x0, x0, x4
    8b68:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8b6c:	cb020000 	sub	x0, x0, x2
    8b70:	8b010013 	add	x19, x0, x1
    8b74:	eb03013f 	cmp	x9, x3
    8b78:	54003440 	b.eq	9200 <fwp_write+0xa40>  // b.none
    8b7c:	9b467e60 	smulh	x0, x19, x6
    8b80:	937ffe64 	asr	x4, x19, #63
    8b84:	52800605 	mov	w5, #0x30                  	// #48
    8b88:	cb040000 	sub	x0, x0, x4
    8b8c:	8b000400 	add	x0, x0, x0, lsl #1
    8b90:	cb000260 	sub	x0, x19, x0
    8b94:	91000c01 	add	x1, x0, #0x3
    8b98:	9bc87c22 	umulh	x2, x1, x8
    8b9c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8ba0:	8b4204e2 	add	x2, x7, x2, lsr #1
    8ba4:	eb020021 	subs	x1, x1, x2
    8ba8:	54fffd60 	b.eq	8b54 <fwp_write+0x394>  // b.none
    8bac:	f100043f 	cmp	x1, #0x1
    8bb0:	54fffce1 	b.ne	8b4c <fwp_write+0x38c>  // b.any
    8bb4:	d2800001 	mov	x1, #0x0                   	// #0
    8bb8:	52800565 	mov	w5, #0x2b                  	// #43
    8bbc:	17ffffe6 	b	8b54 <fwp_write+0x394>
    8bc0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8bc4:	f947f400 	ldr	x0, [x0, #4072]
    8bc8:	f94127e2 	ldr	x2, [sp, #584]
    8bcc:	f9400001 	ldr	x1, [x0]
    8bd0:	eb010042 	subs	x2, x2, x1
    8bd4:	d2800001 	mov	x1, #0x0                   	// #0
    8bd8:	540023c1 	b.ne	9050 <fwp_write+0x890>  // b.any
    8bdc:	f9413bf5 	ldr	x21, [sp, #624]
    8be0:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    8be4:	f9413ff6 	ldr	x22, [sp, #632]
    8be8:	aa1403e0 	mov	x0, x20
    8bec:	912d6021 	add	x1, x1, #0xb58
    8bf0:	d2800102 	mov	x2, #0x8                   	// #8
    8bf4:	17ffff77 	b	89d0 <fwp_write+0x210>
    8bf8:	aa1403e0 	mov	x0, x20
    8bfc:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    8c00:	d28000c2 	mov	x2, #0x6                   	// #6
    8c04:	912ee021 	add	x1, x1, #0xbb8
    8c08:	97ffea62 	bl	3590 <buf_put>
    8c0c:	d2800015 	mov	x21, #0x0                   	// #0
    8c10:	f9400263 	ldr	x3, [x19]
    8c14:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8c18:	54002c60 	b.eq	91a4 <fwp_write+0x9e4>  // b.none
    8c1c:	f9401f82 	ldr	x2, [x28, #56]
    8c20:	f90143f7 	str	x23, [sp, #640]
    8c24:	f90147f8 	str	x24, [sp, #648]
    8c28:	d2800857 	mov	x23, #0x42                  	// #66
    8c2c:	f9014bf9 	str	x25, [sp, #656]
    8c30:	f0000016 	adrp	x22, b000 <__divti3+0x180>
    8c34:	f9014ffa 	str	x26, [sp, #664]
    8c38:	912ec2d6 	add	x22, x22, #0xbb0
    8c3c:	d2800038 	mov	x24, #0x1                   	// #1
    8c40:	f2a18017 	movk	x23, #0xc00, lsl #16
    8c44:	d2809099 	mov	x25, #0x484                 	// #1156
    8c48:	b40004a2 	cbz	x2, 8cdc <fwp_write+0x51c>
    8c4c:	b9400040 	ldr	w0, [x2]
    8c50:	7100701f 	cmp	w0, #0x1c
    8c54:	540042c0 	b.eq	94ac <fwp_write+0xcec>  // b.none
    8c58:	71006c1f 	cmp	w0, #0x1b
    8c5c:	54000408 	b.hi	8cdc <fwp_write+0x51c>  // b.pmore
    8c60:	9ac02301 	lsl	x1, x24, x0
    8c64:	ea17003f 	tst	x1, x23
    8c68:	540036a1 	b.ne	933c <fwp_write+0xb7c>  // b.any
    8c6c:	ea19003f 	tst	x1, x25
    8c70:	54003521 	b.ne	9314 <fwp_write+0xb54>  // b.any
    8c74:	d2800424 	mov	x4, #0x21                  	// #33
    8c78:	ea04003f 	tst	x1, x4
    8c7c:	54000300 	b.eq	8cdc <fwp_write+0x51c>  // b.none
    8c80:	b7f849c3 	tbnz	x3, #63, 95b8 <fwp_write+0xdf8>
    8c84:	91002261 	add	x1, x19, #0x8
    8c88:	8b150021 	add	x1, x1, x21
    8c8c:	39400021 	ldrb	w1, [x1]
    8c90:	7100001f 	cmp	w0, #0x0
    8c94:	93401c23 	sxtb	x3, w1
    8c98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8c9c:	d503201f 	nop
    8ca0:	aa1403e0 	mov	x0, x20
    8ca4:	52800003 	mov	w3, #0x0                   	// #0
    8ca8:	97fffec6 	bl	87c0 <fwp_write>
    8cac:	910006b5 	add	x21, x21, #0x1
    8cb0:	f9400260 	ldr	x0, [x19]
    8cb4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8cb8:	eb0002bf 	cmp	x21, x0
    8cbc:	540026c2 	b.cs	9194 <fwp_write+0x9d4>  // b.hs, b.nlast
    8cc0:	d2800042 	mov	x2, #0x2                   	// #2
    8cc4:	aa1603e1 	mov	x1, x22
    8cc8:	aa1403e0 	mov	x0, x20
    8ccc:	97ffea31 	bl	3590 <buf_put>
    8cd0:	f9401f82 	ldr	x2, [x28, #56]
    8cd4:	f9400263 	ldr	x3, [x19]
    8cd8:	b5fffba2 	cbnz	x2, 8c4c <fwp_write+0x48c>
    8cdc:	d37df2a0 	lsl	x0, x21, #3
    8ce0:	b7f83f03 	tbnz	x3, #63, 94c0 <fwp_write+0xd00>
    8ce4:	91002261 	add	x1, x19, #0x8
    8ce8:	8b000020 	add	x0, x1, x0
    8cec:	f9400001 	ldr	x1, [x0]
    8cf0:	17ffffec 	b	8ca0 <fwp_write+0x4e0>
    8cf4:	a9400e62 	ldp	x2, x3, [x19]
    8cf8:	b7f83ca3 	tbnz	x3, #63, 948c <fwp_write+0xccc>
    8cfc:	910123f5 	add	x21, sp, #0x48
    8d00:	aa1503e0 	mov	x0, x21
    8d04:	97ffe847 	bl	2e20 <fwp_fmt_u128>
    8d08:	aa1503e0 	mov	x0, x21
    8d0c:	97ffe681 	bl	2710 <strlen@plt>
    8d10:	aa1503e1 	mov	x1, x21
    8d14:	aa0003e2 	mov	x2, x0
    8d18:	17fffed0 	b	8858 <fwp_write+0x98>
    8d1c:	fd015be8 	str	d8, [sp, #688]
    8d20:	1e270268 	fmov	s8, w19
    8d24:	fd015fe9 	str	d9, [sp, #696]
    8d28:	1e282100 	fcmp	s8, s8
    8d2c:	54004d26 	b.vs	96d0 <fwp_write+0xf10>
    8d30:	1e20c101 	fabs	s1, s8
    8d34:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8d38:	1e270000 	fmov	s0, w0
    8d3c:	1e202020 	fcmp	s1, s0
    8d40:	54002c0d 	b.le	92c0 <fwp_write+0xb00>
    8d44:	1e202118 	fcmpe	s8, #0.0
    8d48:	f0000002 	adrp	x2, b000 <__divti3+0x180>
    8d4c:	9119e042 	add	x2, x2, #0x678
    8d50:	910123f5 	add	x21, sp, #0x48
    8d54:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    8d58:	912c2021 	add	x1, x1, #0xb08
    8d5c:	aa1503e0 	mov	x0, x21
    8d60:	9a81c041 	csel	x1, x2, x1, gt
    8d64:	97ffe717 	bl	29c0 <strcpy@plt>
    8d68:	aa1503e0 	mov	x0, x21
    8d6c:	97ffe669 	bl	2710 <strlen@plt>
    8d70:	aa1503e1 	mov	x1, x21
    8d74:	aa0003e2 	mov	x2, x0
    8d78:	aa1403e0 	mov	x0, x20
    8d7c:	97ffea05 	bl	3590 <buf_put>
    8d80:	f9413bf5 	ldr	x21, [sp, #624]
    8d84:	f9413ff6 	ldr	x22, [sp, #632]
    8d88:	f94153fb 	ldr	x27, [sp, #672]
    8d8c:	f94157fc 	ldr	x28, [sp, #680]
    8d90:	fd415be8 	ldr	d8, [sp, #688]
    8d94:	fd415fe9 	ldr	d9, [sp, #696]
    8d98:	17fffeb6 	b	8870 <fwp_write+0xb0>
    8d9c:	f9400276 	ldr	x22, [x19]
    8da0:	34002e03 	cbz	w3, 9360 <fwp_write+0xba0>
    8da4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8da8:	f947f400 	ldr	x0, [x0, #4072]
    8dac:	f94127e2 	ldr	x2, [sp, #584]
    8db0:	f9400001 	ldr	x1, [x0]
    8db4:	eb010042 	subs	x2, x2, x1
    8db8:	d2800001 	mov	x1, #0x0                   	// #0
    8dbc:	540014a1 	b.ne	9050 <fwp_write+0x890>  // b.any
    8dc0:	aa1603e2 	mov	x2, x22
    8dc4:	91002261 	add	x1, x19, #0x8
    8dc8:	f9413bf5 	ldr	x21, [sp, #624]
    8dcc:	aa1403e0 	mov	x0, x20
    8dd0:	f9413ff6 	ldr	x22, [sp, #632]
    8dd4:	17fffeff 	b	89d0 <fwp_write+0x210>
    8dd8:	fd015be8 	str	d8, [sp, #688]
    8ddc:	9e670268 	fmov	d8, x19
    8de0:	fd015fe9 	str	d9, [sp, #696]
    8de4:	1e682100 	fcmp	d8, d8
    8de8:	54004746 	b.vs	96d0 <fwp_write+0xf10>
    8dec:	1e60c101 	fabs	d1, d8
    8df0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8df4:	9e670000 	fmov	d0, x0
    8df8:	910123f5 	add	x21, sp, #0x48
    8dfc:	52800033 	mov	w19, #0x1                   	// #1
    8e00:	1e602020 	fcmp	d1, d0
    8e04:	540001ad 	b.le	8e38 <fwp_write+0x678>
    8e08:	1e602118 	fcmpe	d8, #0.0
    8e0c:	f0000002 	adrp	x2, b000 <__divti3+0x180>
    8e10:	9119e042 	add	x2, x2, #0x678
    8e14:	f0000001 	adrp	x1, b000 <__divti3+0x180>
    8e18:	912c2021 	add	x1, x1, #0xb08
    8e1c:	aa1503e0 	mov	x0, x21
    8e20:	9a81c041 	csel	x1, x2, x1, gt
    8e24:	97ffe6e7 	bl	29c0 <strcpy@plt>
    8e28:	17ffffd0 	b	8d68 <fwp_write+0x5a8>
    8e2c:	11000673 	add	w19, w19, #0x1
    8e30:	71004a7f 	cmp	w19, #0x12
    8e34:	54003860 	b.eq	9540 <fwp_write+0xd80>  // b.none
    8e38:	1e604100 	fmov	d0, d8
    8e3c:	2a1303e1 	mov	w1, w19
    8e40:	aa1503e0 	mov	x0, x21
    8e44:	97ffeb54 	bl	3b94 <fwp_format_g.constprop.0>
    8e48:	aa1503e0 	mov	x0, x21
    8e4c:	d2800001 	mov	x1, #0x0                   	// #0
    8e50:	97ffe644 	bl	2760 <strtod@plt>
    8e54:	1e602100 	fcmp	d8, d0
    8e58:	54fffea1 	b.ne	8e2c <fwp_write+0x66c>  // b.any
    8e5c:	aa1503e0 	mov	x0, x21
    8e60:	97ffea45 	bl	3774 <fwp_finish_float>
    8e64:	17ffffc1 	b	8d68 <fwp_write+0x5a8>
    8e68:	a9400e62 	ldp	x2, x3, [x19]
    8e6c:	910123f3 	add	x19, sp, #0x48
    8e70:	aa1303e0 	mov	x0, x19
    8e74:	97ffe7eb 	bl	2e20 <fwp_fmt_u128>
    8e78:	17fffe74 	b	8848 <fwp_write+0x88>
    8e7c:	f90143f7 	str	x23, [sp, #640]
    8e80:	f90147f8 	str	x24, [sp, #648]
    8e84:	2a1303f8 	mov	w24, w19
    8e88:	f9014bf9 	str	x25, [sp, #656]
    8e8c:	f9014ffa 	str	x26, [sp, #664]
    8e90:	f13ffe7f 	cmp	x19, #0xfff
    8e94:	54000049 	b.ls	8e9c <fwp_write+0x6dc>  // b.plast
    8e98:	b9400278 	ldr	w24, [x19]
    8e9c:	f9400f80 	ldr	x0, [x28, #24]
    8ea0:	2a1803f5 	mov	w21, w24
    8ea4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8ea8:	d37ef6b9 	lsl	x25, x21, #2
    8eac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8eb0:	aa1603e0 	mov	x0, x22
    8eb4:	97ffe617 	bl	2710 <strlen@plt>
    8eb8:	aa1603e1 	mov	x1, x22
    8ebc:	aa0003e2 	mov	x2, x0
    8ec0:	aa1403e0 	mov	x0, x20
    8ec4:	97ffe9b3 	bl	3590 <buf_put>
    8ec8:	f9401780 	ldr	x0, [x28, #40]
    8ecc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8ed0:	7100001f 	cmp	w0, #0x0
    8ed4:	5400068d 	b.le	8fa4 <fwp_write+0x7e4>
    8ed8:	91002276 	add	x22, x19, #0x8
    8edc:	91001ff5 	add	x21, sp, #0x7
    8ee0:	d280001b 	mov	x27, #0x0                   	// #0
    8ee4:	5280041a 	mov	w26, #0x20                  	// #32
    8ee8:	f9401b80 	ldr	x0, [x28, #48]
    8eec:	aa1503e1 	mov	x1, x21
    8ef0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8ef4:	d2800022 	mov	x2, #0x1                   	// #1
    8ef8:	f8786803 	ldr	x3, [x0, x24]
    8efc:	aa1403e0 	mov	x0, x20
    8f00:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8f04:	39001ffa 	strb	w26, [sp, #7]
    8f08:	97ffe9a2 	bl	3590 <buf_put>
    8f0c:	f13ffeff 	cmp	x23, #0xfff
    8f10:	b9400261 	ldr	w1, [x19]
    8f14:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8f18:	7100383f 	cmp	w1, #0xe
    8f1c:	54000160 	b.eq	8f48 <fwp_write+0x788>  // b.none
    8f20:	7100403f 	cmp	w1, #0x10
    8f24:	54001a60 	b.eq	9270 <fwp_write+0xab0>  // b.none
    8f28:	7100283f 	cmp	w1, #0xa
    8f2c:	54002aa0 	b.eq	9480 <fwp_write+0xcc0>  // b.none
    8f30:	540014ac 	b.gt	91c4 <fwp_write+0xa04>
    8f34:	71000c3f 	cmp	w1, #0x3
    8f38:	540029ac 	b.gt	946c <fwp_write+0xcac>
    8f3c:	d37ffee0 	lsr	x0, x23, #63
    8f40:	37f814a1 	tbnz	w1, #31, 91d4 <fwp_write+0xa14>
    8f44:	d503201f 	nop
    8f48:	34001460 	cbz	w0, 91d4 <fwp_write+0xa14>
    8f4c:	52800503 	mov	w3, #0x28                  	// #40
    8f50:	aa1503e1 	mov	x1, x21
    8f54:	aa1403e0 	mov	x0, x20
    8f58:	d2800022 	mov	x2, #0x1                   	// #1
    8f5c:	39001fe3 	strb	w3, [sp, #7]
    8f60:	97ffe98c 	bl	3590 <buf_put>
    8f64:	aa1303e2 	mov	x2, x19
    8f68:	aa1703e1 	mov	x1, x23
    8f6c:	aa1403e0 	mov	x0, x20
    8f70:	52800003 	mov	w3, #0x0                   	// #0
    8f74:	97fffe13 	bl	87c0 <fwp_write>
    8f78:	52800523 	mov	w3, #0x29                  	// #41
    8f7c:	aa1503e1 	mov	x1, x21
    8f80:	aa1403e0 	mov	x0, x20
    8f84:	d2800022 	mov	x2, #0x1                   	// #1
    8f88:	39001fe3 	strb	w3, [sp, #7]
    8f8c:	97ffe981 	bl	3590 <buf_put>
    8f90:	f9401780 	ldr	x0, [x28, #40]
    8f94:	9100077b 	add	x27, x27, #0x1
    8f98:	b8796800 	ldr	w0, [x0, x25]
    8f9c:	6b1b001f 	cmp	w0, w27
    8fa0:	54fffa4c 	b.gt	8ee8 <fwp_write+0x728>
    8fa4:	f9413bf5 	ldr	x21, [sp, #624]
    8fa8:	f9413ff6 	ldr	x22, [sp, #632]
    8fac:	f94143f7 	ldr	x23, [sp, #640]
    8fb0:	f94147f8 	ldr	x24, [sp, #648]
    8fb4:	f9414bf9 	ldr	x25, [sp, #656]
    8fb8:	f9414ffa 	ldr	x26, [sp, #664]
    8fbc:	f94153fb 	ldr	x27, [sp, #672]
    8fc0:	f94157fc 	ldr	x28, [sp, #680]
    8fc4:	17fffe2b 	b	8870 <fwp_write+0xb0>
    8fc8:	52800783 	mov	w3, #0x3c                  	// #60
    8fcc:	91001ff3 	add	x19, sp, #0x7
    8fd0:	aa1303e1 	mov	x1, x19
    8fd4:	d2800022 	mov	x2, #0x1                   	// #1
    8fd8:	aa1403e0 	mov	x0, x20
    8fdc:	39001fe3 	strb	w3, [sp, #7]
    8fe0:	97ffe96c 	bl	3590 <buf_put>
    8fe4:	f9400795 	ldr	x21, [x28, #8]
    8fe8:	aa1503e0 	mov	x0, x21
    8fec:	97ffe5c9 	bl	2710 <strlen@plt>
    8ff0:	aa1503e1 	mov	x1, x21
    8ff4:	aa0003e2 	mov	x2, x0
    8ff8:	aa1403e0 	mov	x0, x20
    8ffc:	97ffe965 	bl	3590 <buf_put>
    9000:	528007c3 	mov	w3, #0x3e                  	// #62
    9004:	aa1303e1 	mov	x1, x19
    9008:	aa1403e0 	mov	x0, x20
    900c:	d2800022 	mov	x2, #0x1                   	// #1
    9010:	39001fe3 	strb	w3, [sp, #7]
    9014:	17fffe12 	b	885c <fwp_write+0x9c>
    9018:	f100067f 	cmp	x19, #0x1
    901c:	540025a0 	b.eq	94d0 <fwp_write+0xd10>  // b.none
    9020:	b100067f 	cmn	x19, #0x1
    9024:	54002bc0 	b.eq	959c <fwp_write+0xddc>  // b.none
    9028:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    902c:	912c4021 	add	x1, x1, #0xb10
    9030:	d2800022 	mov	x2, #0x1                   	// #1
    9034:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9038:	f947f400 	ldr	x0, [x0, #4072]
    903c:	f94127e4 	ldr	x4, [sp, #584]
    9040:	f9400003 	ldr	x3, [x0]
    9044:	eb030084 	subs	x4, x4, x3
    9048:	d2800003 	mov	x3, #0x0                   	// #0
    904c:	54ffebe0 	b.eq	8dc8 <fwp_write+0x608>  // b.none
    9050:	f90143f7 	str	x23, [sp, #640]
    9054:	f90147f8 	str	x24, [sp, #648]
    9058:	f9014bf9 	str	x25, [sp, #656]
    905c:	f9014ffa 	str	x26, [sp, #664]
    9060:	fd015be8 	str	d8, [sp, #688]
    9064:	fd015fe9 	str	d9, [sp, #696]
    9068:	97ffe606 	bl	2880 <__stack_chk_fail@plt>
    906c:	52800b63 	mov	w3, #0x5b                  	// #91
    9070:	91001ff5 	add	x21, sp, #0x7
    9074:	aa1503e1 	mov	x1, x21
    9078:	aa1403e0 	mov	x0, x20
    907c:	d2800022 	mov	x2, #0x1                   	// #1
    9080:	d0000016 	adrp	x22, b000 <__divti3+0x180>
    9084:	912ec2d6 	add	x22, x22, #0xbb0
    9088:	39001fe3 	strb	w3, [sp, #7]
    908c:	97ffe941 	bl	3590 <buf_put>
    9090:	b4000273 	cbz	x19, 90dc <fwp_write+0x91c>
    9094:	f9400661 	ldr	x1, [x19, #8]
    9098:	aa1403e0 	mov	x0, x20
    909c:	f9401f82 	ldr	x2, [x28, #56]
    90a0:	52800003 	mov	w3, #0x0                   	// #0
    90a4:	97fffdc7 	bl	87c0 <fwp_write>
    90a8:	f9400a73 	ldr	x19, [x19, #16]
    90ac:	b4000193 	cbz	x19, 90dc <fwp_write+0x91c>
    90b0:	aa1603e1 	mov	x1, x22
    90b4:	aa1403e0 	mov	x0, x20
    90b8:	d2800042 	mov	x2, #0x2                   	// #2
    90bc:	97ffe935 	bl	3590 <buf_put>
    90c0:	f9400661 	ldr	x1, [x19, #8]
    90c4:	aa1403e0 	mov	x0, x20
    90c8:	f9401f82 	ldr	x2, [x28, #56]
    90cc:	52800003 	mov	w3, #0x0                   	// #0
    90d0:	97fffdbc 	bl	87c0 <fwp_write>
    90d4:	f9400a73 	ldr	x19, [x19, #16]
    90d8:	b5fffed3 	cbnz	x19, 90b0 <fwp_write+0x8f0>
    90dc:	52800ba3 	mov	w3, #0x5d                  	// #93
    90e0:	aa1503e1 	mov	x1, x21
    90e4:	aa1403e0 	mov	x0, x20
    90e8:	d2800022 	mov	x2, #0x1                   	// #1
    90ec:	39001fe3 	strb	w3, [sp, #7]
    90f0:	17fffddb 	b	885c <fwp_write+0x9c>
    90f4:	aa1403e0 	mov	x0, x20
    90f8:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    90fc:	d28000c2 	mov	x2, #0x6                   	// #6
    9100:	912e8021 	add	x1, x1, #0xba0
    9104:	97ffe923 	bl	3590 <buf_put>
    9108:	f9400260 	ldr	x0, [x19]
    910c:	b40004c0 	cbz	x0, 91a4 <fwp_write+0x9e4>
    9110:	910123f5 	add	x21, sp, #0x48
    9114:	91002276 	add	x22, x19, #0x8
    9118:	f90143f7 	str	x23, [sp, #640]
    911c:	d2800017 	mov	x23, #0x0                   	// #0
    9120:	f90147f8 	str	x24, [sp, #648]
    9124:	d0000018 	adrp	x24, b000 <__divti3+0x180>
    9128:	912ea318 	add	x24, x24, #0xba8
    912c:	f9014bf9 	str	x25, [sp, #656]
    9130:	d0000019 	adrp	x25, b000 <__divti3+0x180>
    9134:	912ec339 	add	x25, x25, #0xbb0
    9138:	f9014ffa 	str	x26, [sp, #664]
    913c:	14000005 	b	9150 <fwp_write+0x990>
    9140:	aa1903e1 	mov	x1, x25
    9144:	aa1403e0 	mov	x0, x20
    9148:	d2800042 	mov	x2, #0x2                   	// #2
    914c:	97ffe911 	bl	3590 <buf_put>
    9150:	38776ac5 	ldrb	w5, [x22, x23]
    9154:	d2804003 	mov	x3, #0x200                 	// #512
    9158:	aa1803e4 	mov	x4, x24
    915c:	aa0303e1 	mov	x1, x3
    9160:	52800042 	mov	w2, #0x2                   	// #2
    9164:	aa1503e0 	mov	x0, x21
    9168:	910006f7 	add	x23, x23, #0x1
    916c:	97ffe5a1 	bl	27f0 <__snprintf_chk@plt>
    9170:	aa1503e0 	mov	x0, x21
    9174:	97ffe567 	bl	2710 <strlen@plt>
    9178:	aa1503e1 	mov	x1, x21
    917c:	aa0003e2 	mov	x2, x0
    9180:	aa1403e0 	mov	x0, x20
    9184:	97ffe903 	bl	3590 <buf_put>
    9188:	f9400260 	ldr	x0, [x19]
    918c:	eb17001f 	cmp	x0, x23
    9190:	54fffd88 	b.hi	9140 <fwp_write+0x980>  // b.pmore
    9194:	f94143f7 	ldr	x23, [sp, #640]
    9198:	f94147f8 	ldr	x24, [sp, #648]
    919c:	f9414bf9 	ldr	x25, [sp, #656]
    91a0:	f9414ffa 	ldr	x26, [sp, #664]
    91a4:	52800ba3 	mov	w3, #0x5d                  	// #93
    91a8:	aa1403e0 	mov	x0, x20
    91ac:	91001fe1 	add	x1, sp, #0x7
    91b0:	d2800022 	mov	x2, #0x1                   	// #1
    91b4:	39001fe3 	strb	w3, [sp, #7]
    91b8:	17fffda9 	b	885c <fwp_write+0x9c>
    91bc:	52800fa3 	mov	w3, #0x7d                  	// #125
    91c0:	17fffe44 	b	8ad0 <fwp_write+0x310>
    91c4:	f10002ff 	cmp	x23, #0x0
    91c8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    91cc:	71002c3f 	cmp	w1, #0xb
    91d0:	54ffebc0 	b.eq	8f48 <fwp_write+0x788>  // b.none
    91d4:	aa1303e2 	mov	x2, x19
    91d8:	aa1703e1 	mov	x1, x23
    91dc:	aa1403e0 	mov	x0, x20
    91e0:	52800003 	mov	w3, #0x0                   	// #0
    91e4:	97fffd77 	bl	87c0 <fwp_write>
    91e8:	17ffff6a 	b	8f90 <fwp_write+0x7d0>
    91ec:	aa1403e0 	mov	x0, x20
    91f0:	91001fe1 	add	x1, sp, #0x7
    91f4:	52800fa3 	mov	w3, #0x7d                  	// #125
    91f8:	d2800022 	mov	x2, #0x1                   	// #1
    91fc:	17fffe38 	b	8adc <fwp_write+0x31c>
    9200:	a9400281 	ldp	x1, x0, [x20]
    9204:	91000800 	add	x0, x0, #0x2
    9208:	8b160000 	add	x0, x0, x22
    920c:	f9000680 	str	x0, [x20, #8]
    9210:	3820683f 	strb	wzr, [x1, x0]
    9214:	f9413bf5 	ldr	x21, [sp, #624]
    9218:	f9413ff6 	ldr	x22, [sp, #632]
    921c:	f94153fb 	ldr	x27, [sp, #672]
    9220:	f94157fc 	ldr	x28, [sp, #680]
    9224:	17fffd93 	b	8870 <fwp_write+0xb0>
    9228:	f9400f80 	ldr	x0, [x28, #24]
    922c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9230:	aa1b03e0 	mov	x0, x27
    9234:	97ffe537 	bl	2710 <strlen@plt>
    9238:	aa1b03e1 	mov	x1, x27
    923c:	aa0003e2 	mov	x2, x0
    9240:	aa1403e0 	mov	x0, x20
    9244:	97ffe8d3 	bl	3590 <buf_put>
    9248:	aa1903e1 	mov	x1, x25
    924c:	aa1403e0 	mov	x0, x20
    9250:	d2800062 	mov	x2, #0x3                   	// #3
    9254:	97ffe8cf 	bl	3590 <buf_put>
    9258:	17fffe10 	b	8a98 <fwp_write+0x2d8>
    925c:	aa1a03e1 	mov	x1, x26
    9260:	aa1403e0 	mov	x0, x20
    9264:	d2800042 	mov	x2, #0x2                   	// #2
    9268:	97ffe8ca 	bl	3590 <buf_put>
    926c:	17fffe09 	b	8a90 <fwp_write+0x2d0>
    9270:	f9400660 	ldr	x0, [x19, #8]
    9274:	b4fffb00 	cbz	x0, 91d4 <fwp_write+0xa14>
    9278:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    927c:	912f2021 	add	x1, x1, #0xbc8
    9280:	97ffe5a0 	bl	2900 <strcmp@plt>
    9284:	7100001f 	cmp	w0, #0x0
    9288:	1a9f07e0 	cset	w0, ne	// ne = any
    928c:	17ffff2f 	b	8f48 <fwp_write+0x788>
    9290:	aa1403e0 	mov	x0, x20
    9294:	d2800042 	mov	x2, #0x2                   	// #2
    9298:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    929c:	912f0021 	add	x1, x1, #0xbc0
    92a0:	97ffe8bc 	bl	3590 <buf_put>
    92a4:	91004261 	add	x1, x19, #0x10
    92a8:	aa1403e0 	mov	x0, x20
    92ac:	f9402382 	ldr	x2, [x28, #64]
    92b0:	52800003 	mov	w3, #0x0                   	// #0
    92b4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    92b8:	97fffd42 	bl	87c0 <fwp_write>
    92bc:	17fffd9c 	b	892c <fwp_write+0x16c>
    92c0:	1e22c109 	fcvt	d9, s8
    92c4:	910123f5 	add	x21, sp, #0x48
    92c8:	52800033 	mov	w19, #0x1                   	// #1
    92cc:	d503201f 	nop
    92d0:	1e604120 	fmov	d0, d9
    92d4:	2a1303e1 	mov	w1, w19
    92d8:	aa1503e0 	mov	x0, x21
    92dc:	97ffea2e 	bl	3b94 <fwp_format_g.constprop.0>
    92e0:	aa1503e0 	mov	x0, x21
    92e4:	d2800001 	mov	x1, #0x0                   	// #0
    92e8:	97ffe592 	bl	2930 <strtof@plt>
    92ec:	1e202100 	fcmp	s8, s0
    92f0:	54ffdb60 	b.eq	8e5c <fwp_write+0x69c>  // b.none
    92f4:	11000673 	add	w19, w19, #0x1
    92f8:	71002a7f 	cmp	w19, #0xa
    92fc:	54fffea1 	b.ne	92d0 <fwp_write+0xb10>  // b.any
    9300:	1e604120 	fmov	d0, d9
    9304:	aa1503e0 	mov	x0, x21
    9308:	52800121 	mov	w1, #0x9                   	// #9
    930c:	97ffea22 	bl	3b94 <fwp_format_g.constprop.0>
    9310:	17fffed3 	b	8e5c <fwp_write+0x69c>
    9314:	d37ef6a1 	lsl	x1, x21, #2
    9318:	b7f81563 	tbnz	x3, #63, 95c4 <fwp_write+0xe04>
    931c:	91002263 	add	x3, x19, #0x8
    9320:	8b010061 	add	x1, x3, x1
    9324:	b9400023 	ldr	w3, [x1]
    9328:	7100081f 	cmp	w0, #0x2
    932c:	2a0303e1 	mov	w1, w3
    9330:	93407c63 	sxtw	x3, w3
    9334:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9338:	17fffe5a 	b	8ca0 <fwp_write+0x4e0>
    933c:	d37ffaa1 	lsl	x1, x21, #1
    9340:	b7f81363 	tbnz	x3, #63, 95ac <fwp_write+0xdec>
    9344:	91002263 	add	x3, x19, #0x8
    9348:	8b010061 	add	x1, x3, x1
    934c:	79400021 	ldrh	w1, [x1]
    9350:	7100041f 	cmp	w0, #0x1
    9354:	93403c23 	sxth	x3, w1
    9358:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    935c:	17fffe51 	b	8ca0 <fwp_write+0x4e0>
    9360:	52800443 	mov	w3, #0x22                  	// #34
    9364:	91001ff5 	add	x21, sp, #0x7
    9368:	91002273 	add	x19, x19, #0x8
    936c:	aa1503e1 	mov	x1, x21
    9370:	aa1403e0 	mov	x0, x20
    9374:	d2800022 	mov	x2, #0x1                   	// #1
    9378:	39001fe3 	strb	w3, [sp, #7]
    937c:	f90143f7 	str	x23, [sp, #640]
    9380:	8b160277 	add	x23, x19, x22
    9384:	f90147f8 	str	x24, [sp, #648]
    9388:	97ffe882 	bl	3590 <buf_put>
    938c:	b4000696 	cbz	x22, 945c <fwp_write+0xc9c>
    9390:	d0000018 	adrp	x24, b000 <__divti3+0x180>
    9394:	912dc318 	add	x24, x24, #0xb70
    9398:	f9014bf9 	str	x25, [sp, #656]
    939c:	d0000019 	adrp	x25, b000 <__divti3+0x180>
    93a0:	912e4339 	add	x25, x25, #0xb90
    93a4:	f9014ffa 	str	x26, [sp, #664]
    93a8:	1400000d 	b	93dc <fwp_write+0xc1c>
    93ac:	710024bf 	cmp	w5, #0x9
    93b0:	54000460 	b.eq	943c <fwp_write+0xc7c>  // b.none
    93b4:	710028bf 	cmp	w5, #0xa
    93b8:	54000a61 	b.ne	9504 <fwp_write+0xd44>  // b.any
    93bc:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    93c0:	aa1403e0 	mov	x0, x20
    93c4:	912e0021 	add	x1, x1, #0xb80
    93c8:	d2800042 	mov	x2, #0x2                   	// #2
    93cc:	97ffe871 	bl	3590 <buf_put>
    93d0:	91000673 	add	x19, x19, #0x1
    93d4:	eb17027f 	cmp	x19, x23
    93d8:	540003e0 	b.eq	9454 <fwp_write+0xc94>  // b.none
    93dc:	39400265 	ldrb	w5, [x19]
    93e0:	710034bf 	cmp	w5, #0xd
    93e4:	54000180 	b.eq	9414 <fwp_write+0xc54>  // b.none
    93e8:	54fffe29 	b.ls	93ac <fwp_write+0xbec>  // b.plast
    93ec:	710088bf 	cmp	w5, #0x22
    93f0:	540001c0 	b.eq	9428 <fwp_write+0xc68>  // b.none
    93f4:	710170bf 	cmp	w5, #0x5c
    93f8:	54000741 	b.ne	94e0 <fwp_write+0xd20>  // b.any
    93fc:	aa1403e0 	mov	x0, x20
    9400:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    9404:	d2800042 	mov	x2, #0x2                   	// #2
    9408:	912de021 	add	x1, x1, #0xb78
    940c:	97ffe861 	bl	3590 <buf_put>
    9410:	17fffff0 	b	93d0 <fwp_write+0xc10>
    9414:	aa1903e1 	mov	x1, x25
    9418:	aa1403e0 	mov	x0, x20
    941c:	d2800042 	mov	x2, #0x2                   	// #2
    9420:	97ffe85c 	bl	3590 <buf_put>
    9424:	17ffffeb 	b	93d0 <fwp_write+0xc10>
    9428:	aa1803e1 	mov	x1, x24
    942c:	aa1403e0 	mov	x0, x20
    9430:	d2800042 	mov	x2, #0x2                   	// #2
    9434:	97ffe857 	bl	3590 <buf_put>
    9438:	17ffffe6 	b	93d0 <fwp_write+0xc10>
    943c:	aa1403e0 	mov	x0, x20
    9440:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    9444:	d2800042 	mov	x2, #0x2                   	// #2
    9448:	912e2021 	add	x1, x1, #0xb88
    944c:	97ffe851 	bl	3590 <buf_put>
    9450:	17ffffe0 	b	93d0 <fwp_write+0xc10>
    9454:	f9414bf9 	ldr	x25, [sp, #656]
    9458:	f9414ffa 	ldr	x26, [sp, #664]
    945c:	aa1503e1 	mov	x1, x21
    9460:	aa1403e0 	mov	x0, x20
    9464:	52800443 	mov	w3, #0x22                  	// #34
    9468:	17fffd9c 	b	8ad8 <fwp_write+0x318>
    946c:	7100103f 	cmp	w1, #0x4
    9470:	54ffeb21 	b.ne	91d4 <fwp_write+0xa14>  // b.any
    9474:	f94006e0 	ldr	x0, [x23, #8]
    9478:	d37ffc00 	lsr	x0, x0, #63
    947c:	17fffeb3 	b	8f48 <fwp_write+0x788>
    9480:	710002ff 	cmp	w23, #0x0
    9484:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9488:	17fffeb0 	b	8f48 <fwp_write+0x788>
    948c:	528005a1 	mov	w1, #0x2d                  	// #45
    9490:	eb0203e2 	negs	x2, x2
    9494:	da0303e3 	ngc	x3, x3
    9498:	910127e0 	add	x0, sp, #0x49
    949c:	910123f5 	add	x21, sp, #0x48
    94a0:	390123e1 	strb	w1, [sp, #72]
    94a4:	97ffe65f 	bl	2e20 <fwp_fmt_u128>
    94a8:	17fffe18 	b	8d08 <fwp_write+0x548>
    94ac:	d37ceea1 	lsl	x1, x21, #4
    94b0:	b7f810a3 	tbnz	x3, #63, 96c4 <fwp_write+0xf04>
    94b4:	91002260 	add	x0, x19, #0x8
    94b8:	8b010001 	add	x1, x0, x1
    94bc:	17fffdf9 	b	8ca0 <fwp_write+0x4e0>
    94c0:	f9400a61 	ldr	x1, [x19, #16]
    94c4:	8b010000 	add	x0, x0, x1
    94c8:	f9400001 	ldr	x1, [x0]
    94cc:	17fffdf5 	b	8ca0 <fwp_write+0x4e0>
    94d0:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    94d4:	d2800042 	mov	x2, #0x2                   	// #2
    94d8:	912c6021 	add	x1, x1, #0xb18
    94dc:	17fffed6 	b	9034 <fwp_write+0x874>
    94e0:	7101fcbf 	cmp	w5, #0x7f
    94e4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    94e8:	540000e9 	b.ls	9504 <fwp_write+0xd44>  // b.plast
    94ec:	aa1503e1 	mov	x1, x21
    94f0:	aa1403e0 	mov	x0, x20
    94f4:	d2800022 	mov	x2, #0x1                   	// #1
    94f8:	39001fe5 	strb	w5, [sp, #7]
    94fc:	97ffe825 	bl	3590 <buf_put>
    9500:	17ffffb4 	b	93d0 <fwp_write+0xc10>
    9504:	d2800203 	mov	x3, #0x10                  	// #16
    9508:	d0000004 	adrp	x4, b000 <__divti3+0x180>
    950c:	aa0303e1 	mov	x1, x3
    9510:	912e6084 	add	x4, x4, #0xb98
    9514:	910123f6 	add	x22, sp, #0x48
    9518:	52800042 	mov	w2, #0x2                   	// #2
    951c:	aa1603e0 	mov	x0, x22
    9520:	97ffe4b4 	bl	27f0 <__snprintf_chk@plt>
    9524:	aa1603e0 	mov	x0, x22
    9528:	97ffe47a 	bl	2710 <strlen@plt>
    952c:	aa1603e1 	mov	x1, x22
    9530:	aa0003e2 	mov	x2, x0
    9534:	aa1403e0 	mov	x0, x20
    9538:	97ffe816 	bl	3590 <buf_put>
    953c:	17ffffa5 	b	93d0 <fwp_write+0xc10>
    9540:	1e604100 	fmov	d0, d8
    9544:	aa1503e0 	mov	x0, x21
    9548:	52800221 	mov	w1, #0x11                  	// #17
    954c:	97ffe992 	bl	3b94 <fwp_format_g.constprop.0>
    9550:	17fffe43 	b	8e5c <fwp_write+0x69c>
    9554:	b9401040 	ldr	w0, [x2, #16]
    9558:	350003c0 	cbnz	w0, 95d0 <fwp_write+0xe10>
    955c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9560:	f947f400 	ldr	x0, [x0, #4072]
    9564:	f94127e2 	ldr	x2, [sp, #584]
    9568:	f9400001 	ldr	x1, [x0]
    956c:	eb010042 	subs	x2, x2, x1
    9570:	d2800001 	mov	x1, #0x0                   	// #0
    9574:	54ffd721 	b.ne	9058 <fwp_write+0x898>  // b.any
    9578:	f9413bf5 	ldr	x21, [sp, #624]
    957c:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    9580:	f9413ff6 	ldr	x22, [sp, #632]
    9584:	aa1403e0 	mov	x0, x20
    9588:	f94143f7 	ldr	x23, [sp, #640]
    958c:	912fa021 	add	x1, x1, #0xbe8
    9590:	f94147f8 	ldr	x24, [sp, #648]
    9594:	d2800042 	mov	x2, #0x2                   	// #2
    9598:	17fffd0e 	b	89d0 <fwp_write+0x210>
    959c:	d0000001 	adrp	x1, b000 <__divti3+0x180>
    95a0:	d2800042 	mov	x2, #0x2                   	// #2
    95a4:	912c8021 	add	x1, x1, #0xb20
    95a8:	17fffea3 	b	9034 <fwp_write+0x874>
    95ac:	f9400a63 	ldr	x3, [x19, #16]
    95b0:	8b030021 	add	x1, x1, x3
    95b4:	17ffff66 	b	934c <fwp_write+0xb8c>
    95b8:	f9400a61 	ldr	x1, [x19, #16]
    95bc:	8b0102a1 	add	x1, x21, x1
    95c0:	17fffdb3 	b	8c8c <fwp_write+0x4cc>
    95c4:	f9400a63 	ldr	x3, [x19, #16]
    95c8:	8b030021 	add	x1, x1, x3
    95cc:	17ffff56 	b	9324 <fwp_write+0xb64>
    95d0:	b9404840 	ldr	w0, [x2, #72]
    95d4:	91001ff5 	add	x21, sp, #0x7
    95d8:	34ffa360 	cbz	w0, 8a44 <fwp_write+0x284>
    95dc:	52800503 	mov	w3, #0x28                  	// #40
    95e0:	aa1403e0 	mov	x0, x20
    95e4:	aa1503e1 	mov	x1, x21
    95e8:	d2800022 	mov	x2, #0x1                   	// #1
    95ec:	39001fe3 	strb	w3, [sp, #7]
    95f0:	97ffe7e8 	bl	3590 <buf_put>
    95f4:	b9401380 	ldr	w0, [x28, #16]
    95f8:	52800038 	mov	w24, #0x1                   	// #1
    95fc:	7100001f 	cmp	w0, #0x0
    9600:	54ffa36c 	b.gt	8a6c <fwp_write+0x2ac>
    9604:	17fffd32 	b	8acc <fwp_write+0x30c>
    9608:	f9014bf9 	str	x25, [sp, #656]
    960c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10850>
    9610:	f9014ffa 	str	x26, [sp, #664]
    9614:	f9400676 	ldr	x22, [x19, #8]
    9618:	91102333 	add	x19, x25, #0x408
    961c:	91002273 	add	x19, x19, #0x8
    9620:	937ffed8 	asr	x24, x22, #63
    9624:	aa1802c0 	orr	x0, x22, x24
    9628:	b5000320 	cbnz	x0, 968c <fwp_write+0xecc>
    962c:	110006b5 	add	w21, w21, #0x1
    9630:	710016bf 	cmp	w21, #0x5
    9634:	54ffffc1 	b.ne	962c <fwp_write+0xe6c>  // b.any
    9638:	b7f80578 	tbnz	x24, #63, 96e4 <fwp_write+0xf24>
    963c:	910023f3 	add	x19, sp, #0x8
    9640:	aa1603e2 	mov	x2, x22
    9644:	aa1303e0 	mov	x0, x19
    9648:	d2800003 	mov	x3, #0x0                   	// #0
    964c:	97ffe5f5 	bl	2e20 <fwp_fmt_u128>
    9650:	910123f5 	add	x21, sp, #0x48
    9654:	d0000003 	adrp	x3, b000 <__divti3+0x180>
    9658:	aa1303e4 	mov	x4, x19
    965c:	aa1503e0 	mov	x0, x21
    9660:	912f8063 	add	x3, x3, #0xbe0
    9664:	d2804002 	mov	x2, #0x200                 	// #512
    9668:	52800041 	mov	w1, #0x2                   	// #2
    966c:	97ffe42d 	bl	2720 <__sprintf_chk@plt>
    9670:	aa1503e0 	mov	x0, x21
    9674:	97ffe427 	bl	2710 <strlen@plt>
    9678:	aa1503e1 	mov	x1, x21
    967c:	aa0003e2 	mov	x2, x0
    9680:	aa1403e0 	mov	x0, x20
    9684:	97ffe7c3 	bl	3590 <buf_put>
    9688:	17fffe47 	b	8fa4 <fwp_write+0x7e4>
    968c:	f9400277 	ldr	x23, [x19]
    9690:	aa1603e0 	mov	x0, x22
    9694:	aa1803e1 	mov	x1, x24
    9698:	aa1703e2 	mov	x2, x23
    969c:	937ffefa 	asr	x26, x23, #63
    96a0:	aa1a03e3 	mov	x3, x26
    96a4:	940006d7 	bl	b200 <__modti3>
    96a8:	aa010000 	orr	x0, x0, x1
    96ac:	b40002c0 	cbz	x0, 9704 <fwp_write+0xf44>
    96b0:	110006b5 	add	w21, w21, #0x1
    96b4:	91004273 	add	x19, x19, #0x10
    96b8:	710016bf 	cmp	w21, #0x5
    96bc:	54fffe81 	b.ne	968c <fwp_write+0xecc>  // b.any
    96c0:	17ffffde 	b	9638 <fwp_write+0xe78>
    96c4:	f9400a60 	ldr	x0, [x19, #16]
    96c8:	8b000021 	add	x1, x1, x0
    96cc:	17fffd75 	b	8ca0 <fwp_write+0x4e0>
    96d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    96d4:	910123f5 	add	x21, sp, #0x48
    96d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    96dc:	b9004be0 	str	w0, [sp, #72]
    96e0:	17fffda2 	b	8d68 <fwp_write+0x5a8>
    96e4:	528005a1 	mov	w1, #0x2d                  	// #45
    96e8:	eb1603e2 	negs	x2, x22
    96ec:	da1803e3 	ngc	x3, x24
    96f0:	910027e0 	add	x0, sp, #0x9
    96f4:	910023f3 	add	x19, sp, #0x8
    96f8:	390023e1 	strb	w1, [sp, #8]
    96fc:	97ffe5c9 	bl	2e20 <fwp_fmt_u128>
    9700:	17ffffd4 	b	9650 <fwp_write+0xe90>
    9704:	aa1703e2 	mov	x2, x23
    9708:	aa1a03e3 	mov	x3, x26
    970c:	aa1603e0 	mov	x0, x22
    9710:	aa1803e1 	mov	x1, x24
    9714:	940005db 	bl	ae80 <__divti3>
    9718:	aa0003e2 	mov	x2, x0
    971c:	aa0103e3 	mov	x3, x1
    9720:	b7f80201 	tbnz	x1, #63, 9760 <fwp_write+0xfa0>
    9724:	910023f3 	add	x19, sp, #0x8
    9728:	aa1303e0 	mov	x0, x19
    972c:	97ffe5bd 	bl	2e20 <fwp_fmt_u128>
    9730:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9734:	91102339 	add	x25, x25, #0x408
    9738:	910123f5 	add	x21, sp, #0x48
    973c:	aa1303e4 	mov	x4, x19
    9740:	aa1503e0 	mov	x0, x21
    9744:	d0000003 	adrp	x3, b000 <__divti3+0x180>
    9748:	f8616b25 	ldr	x5, [x25, x1]
    974c:	912f6063 	add	x3, x3, #0xbd8
    9750:	d2804002 	mov	x2, #0x200                 	// #512
    9754:	52800041 	mov	w1, #0x2                   	// #2
    9758:	97ffe3f2 	bl	2720 <__sprintf_chk@plt>
    975c:	17ffffc5 	b	9670 <fwp_write+0xeb0>
    9760:	528005a4 	mov	w4, #0x2d                  	// #45
    9764:	eb0003e2 	negs	x2, x0
    9768:	da0103e3 	ngc	x3, x1
    976c:	910027e0 	add	x0, sp, #0x9
    9770:	910023f3 	add	x19, sp, #0x8
    9774:	390023e4 	strb	w4, [sp, #8]
    9778:	97ffe5aa 	bl	2e20 <fwp_fmt_u128>
    977c:	17ffffed 	b	9730 <fwp_write+0xf70>
    9780:	f9013bf5 	str	x21, [sp, #624]
    9784:	f9013ff6 	str	x22, [sp, #632]
    9788:	f90143f7 	str	x23, [sp, #640]
    978c:	f90147f8 	str	x24, [sp, #648]
    9790:	f9014bf9 	str	x25, [sp, #656]
    9794:	f9014ffa 	str	x26, [sp, #664]
    9798:	f90153fb 	str	x27, [sp, #672]
    979c:	f90157fc 	str	x28, [sp, #680]
    97a0:	fd015be8 	str	d8, [sp, #688]
    97a4:	fd015fe9 	str	d9, [sp, #696]
    97a8:	97ffe436 	bl	2880 <__stack_chk_fail@plt>
    97ac:	d503201f 	nop

00000000000097b0 <fwp_main_thread>:
    97b0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    97b4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    97b8:	91174001 	add	x1, x0, #0x5d0
    97bc:	910003fd 	mov	x29, sp
    97c0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    97c4:	f947f400 	ldr	x0, [x0, #4072]
    97c8:	a90153f3 	stp	x19, x20, [sp, #16]
    97cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    97d0:	a90363f7 	stp	x23, x24, [sp, #48]
    97d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    97d8:	a90573fb 	stp	x27, x28, [sp, #80]
    97dc:	fd0033e8 	str	d8, [sp, #96]
    97e0:	d10603ff 	sub	sp, sp, #0x180
    97e4:	b953a421 	ldr	w1, [x1, #5028]
    97e8:	f9400002 	ldr	x2, [x0]
    97ec:	f81f83a2 	stur	x2, [x29, #-8]
    97f0:	d2800002 	mov	x2, #0x0                   	// #0
    97f4:	34006641 	cbz	w1, a4bc <fwp_main_thread+0xd0c>
    97f8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    97fc:	91174000 	add	x0, x0, #0x5d0
    9800:	b953a800 	ldr	w0, [x0, #5032]
    9804:	35006540 	cbnz	w0, a4ac <fwp_main_thread+0xcfc>
    9808:	f00000a0 	adrp	x0, 20000 <__data_start>
    980c:	f00000a2 	adrp	x2, 20000 <__data_start>
    9810:	9101c013 	add	x19, x0, #0x70
    9814:	910fc042 	add	x2, x2, #0x3f0
    9818:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    981c:	d2a00024 	mov	x4, #0x10000               	// #65536
    9820:	d10383bb 	sub	x27, x29, #0xe0
    9824:	d103e3b8 	sub	x24, x29, #0xf8
    9828:	aa1b03e0 	mov	x0, x27
    982c:	d2800001 	mov	x1, #0x0                   	// #0
    9830:	f81203a2 	stur	x2, [x29, #-224]
    9834:	b81283bf 	stur	wzr, [x29, #-216]
    9838:	f81303a4 	stur	x4, [x29, #-208]
    983c:	a9018e78 	stp	x24, x3, [x19, #24]
    9840:	97ffe3a8 	bl	26e0 <sigaltstack@plt>
    9844:	3500a6c0 	cbnz	w0, ad1c <fwp_main_thread+0x156c>
    9848:	4f000400 	movi	v0.4s, #0x0
    984c:	d10263a0 	sub	x0, x29, #0x98
    9850:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    9854:	9101c021 	add	x1, x1, #0x70
    9858:	f81603a1 	stur	x1, [x29, #-160]
    985c:	52800082 	mov	w2, #0x4                   	// #4
    9860:	72a10002 	movk	w2, #0x800, lsl #16
    9864:	d10283b6 	sub	x22, x29, #0xa0
    9868:	3d802000 	str	q0, [x0, #128]
    986c:	b81e83a2 	stur	w2, [x29, #-24]
    9870:	ad000000 	stp	q0, q0, [x0]
    9874:	ad010000 	stp	q0, q0, [x0, #32]
    9878:	ad020000 	stp	q0, q0, [x0, #64]
    987c:	ad030000 	stp	q0, q0, [x0, #96]
    9880:	97ffe3f0 	bl	2840 <sigemptyset@plt>
    9884:	3500a4c0 	cbnz	w0, ad1c <fwp_main_thread+0x156c>
    9888:	aa1603e1 	mov	x1, x22
    988c:	d2800002 	mov	x2, #0x0                   	// #0
    9890:	52800160 	mov	w0, #0xb                   	// #11
    9894:	97ffe403 	bl	28a0 <sigaction@plt>
    9898:	3500a420 	cbnz	w0, ad1c <fwp_main_thread+0x156c>
    989c:	aa1603e1 	mov	x1, x22
    98a0:	d2800002 	mov	x2, #0x0                   	// #0
    98a4:	528000e0 	mov	w0, #0x7                   	// #7
    98a8:	97ffe3fe 	bl	28a0 <sigaction@plt>
    98ac:	3500a380 	cbnz	w0, ad1c <fwp_main_thread+0x156c>
    98b0:	b9434a60 	ldr	w0, [x19, #840]
    98b4:	34001480 	cbz	w0, 9b44 <fwp_main_thread+0x394>
    98b8:	f00000a0 	adrp	x0, 20000 <__data_start>
    98bc:	9101c000 	add	x0, x0, #0x70
    98c0:	b9434c01 	ldr	w1, [x0, #844]
    98c4:	34001541 	cbz	w1, 9b6c <fwp_main_thread+0x3bc>
    98c8:	f00000a0 	adrp	x0, 20000 <__data_start>
    98cc:	9101c015 	add	x21, x0, #0x70
    98d0:	f9400ab4 	ldr	x20, [x21, #16]
    98d4:	b4000c54 	cbz	x20, 9a5c <fwp_main_thread+0x2ac>
    98d8:	aa1403f3 	mov	x19, x20
    98dc:	91010297 	add	x23, x20, #0x40
    98e0:	39414a98 	ldrb	w24, [x20, #82]
    98e4:	52800036 	mov	w22, #0x1                   	// #1
    98e8:	39014a96 	strb	w22, [x20, #82]
    98ec:	f9401680 	ldr	x0, [x20, #40]
    98f0:	b4000620 	cbz	x0, 99b4 <fwp_main_thread+0x204>
    98f4:	f9403281 	ldr	x1, [x20, #96]
    98f8:	39414680 	ldrb	w0, [x20, #81]
    98fc:	b4000e81 	cbz	x1, 9acc <fwp_main_thread+0x31c>
    9900:	36000d40 	tbz	w0, #0, 9aa8 <fwp_main_thread+0x2f8>
    9904:	39414a62 	ldrb	w2, [x19, #82]
    9908:	f9402281 	ldr	x1, [x20, #64]
    990c:	37001082 	tbnz	w2, #0, 9b1c <fwp_main_thread+0x36c>
    9910:	f9403260 	ldr	x0, [x19, #96]
    9914:	a911fe77 	stp	x23, xzr, [x19, #280]
    9918:	f9009661 	str	x1, [x19, #296]
    991c:	b4000041 	cbz	x1, 9924 <fwp_main_thread+0x174>
    9920:	f9009033 	str	x19, [x1, #288]
    9924:	f9002293 	str	x19, [x20, #64]
    9928:	b4000100 	cbz	x0, 9948 <fwp_main_thread+0x198>
    992c:	f9406ea1 	ldr	x1, [x21, #216]
    9930:	39015676 	strb	w22, [x19, #85]
    9934:	f9003660 	str	x0, [x19, #104]
    9938:	a910867f 	stp	xzr, x1, [x19, #264]
    993c:	b4000041 	cbz	x1, 9944 <fwp_main_thread+0x194>
    9940:	f9008433 	str	x19, [x1, #264]
    9944:	f9006eb3 	str	x19, [x21, #216]
    9948:	39015a7f 	strb	wzr, [x19, #86]
    994c:	97fff296 	bl	63a4 <fwp_block>
    9950:	f9408e62 	ldr	x2, [x19, #280]
    9954:	b4000142 	cbz	x2, 997c <fwp_main_thread+0x1cc>
    9958:	a9520261 	ldp	x1, x0, [x19, #288]
    995c:	b4000ec1 	cbz	x1, 9b34 <fwp_main_thread+0x384>
    9960:	f9009420 	str	x0, [x1, #296]
    9964:	f9409660 	ldr	x0, [x19, #296]
    9968:	b4000040 	cbz	x0, 9970 <fwp_main_thread+0x1c0>
    996c:	f9009001 	str	x1, [x0, #288]
    9970:	91080260 	add	x0, x19, #0x200
    9974:	f900967f 	str	xzr, [x19, #296]
    9978:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    997c:	39415660 	ldrb	w0, [x19, #85]
    9980:	f9400aa1 	ldr	x1, [x21, #16]
    9984:	36000c80 	tbz	w0, #0, 9b14 <fwp_main_thread+0x364>
    9988:	a9508262 	ldp	x2, x0, [x19, #264]
    998c:	b4000d82 	cbz	x2, 9b3c <fwp_main_thread+0x38c>
    9990:	f9008840 	str	x0, [x2, #272]
    9994:	b4000040 	cbz	x0, 999c <fwp_main_thread+0x1ec>
    9998:	f9008402 	str	x2, [x0, #264]
    999c:	91080260 	add	x0, x19, #0x200
    99a0:	3901567f 	strb	wzr, [x19, #85]
    99a4:	aa0103f3 	mov	x19, x1
    99a8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    99ac:	f9401680 	ldr	x0, [x20, #40]
    99b0:	b5fffa20 	cbnz	x0, 98f4 <fwp_main_thread+0x144>
    99b4:	f00000a0 	adrp	x0, 20000 <__data_start>
    99b8:	9101c000 	add	x0, x0, #0x70
    99bc:	39014a98 	strb	w24, [x20, #82]
    99c0:	f9419400 	ldr	x0, [x0, #808]
    99c4:	b4000520 	cbz	x0, 9a68 <fwp_main_thread+0x2b8>
    99c8:	f00000a0 	adrp	x0, 20000 <__data_start>
    99cc:	9101c000 	add	x0, x0, #0x70
    99d0:	f941b001 	ldr	x1, [x0, #864]
    99d4:	b903581f 	str	wzr, [x0, #856]
    99d8:	eb13003f 	cmp	x1, x19
    99dc:	54000641 	b.ne	9aa4 <fwp_main_thread+0x2f4>  // b.any
    99e0:	b4004a53 	cbz	x19, a328 <fwp_main_thread+0xb78>
    99e4:	f00000a0 	adrp	x0, 20000 <__data_start>
    99e8:	9101c000 	add	x0, x0, #0x70
    99ec:	52800021 	mov	w1, #0x1                   	// #1
    99f0:	39014a61 	strb	w1, [x19, #82]
    99f4:	f9418005 	ldr	x5, [x0, #768]
    99f8:	b4004985 	cbz	x5, a328 <fwp_main_thread+0xb78>
    99fc:	394140a0 	ldrb	w0, [x5, #80]
    9a00:	37000060 	tbnz	w0, #0, 9a0c <fwp_main_thread+0x25c>
    9a04:	aa0503e0 	mov	x0, x5
    9a08:	97ffe73a 	bl	36f0 <fwp_cancel_tree.part.0>
    9a0c:	f9409ca5 	ldr	x5, [x5, #312]
    9a10:	b5ffff65 	cbnz	x5, 99fc <fwp_main_thread+0x24c>
    9a14:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a18:	9101c014 	add	x20, x0, #0x70
    9a1c:	52800035 	mov	w21, #0x1                   	// #1
    9a20:	f9402a60 	ldr	x0, [x19, #80]
    9a24:	f2001c1f 	tst	x0, #0xff000000ff
    9a28:	540000e1 	b.ne	9a44 <fwp_main_thread+0x294>  // b.any
    9a2c:	f9403e80 	ldr	x0, [x20, #120]
    9a30:	39015275 	strb	w21, [x19, #84]
    9a34:	f900827f 	str	xzr, [x19, #256]
    9a38:	b40046e0 	cbz	x0, a314 <fwp_main_thread+0xb64>
    9a3c:	f9008013 	str	x19, [x0, #256]
    9a40:	f9003e93 	str	x19, [x20, #120]
    9a44:	97fff258 	bl	63a4 <fwp_block>
    9a48:	97fff1ea 	bl	61f0 <fwp_free_zombie>
    9a4c:	f9418280 	ldr	x0, [x20, #768]
    9a50:	b40046c0 	cbz	x0, a328 <fwp_main_thread+0xb78>
    9a54:	f941b293 	ldr	x19, [x20, #864]
    9a58:	17fffff2 	b	9a20 <fwp_main_thread+0x270>
    9a5c:	f94196a0 	ldr	x0, [x21, #808]
    9a60:	b50045e0 	cbnz	x0, a31c <fwp_main_thread+0xb6c>
    9a64:	d2800013 	mov	x19, #0x0                   	// #0
    9a68:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a6c:	9101c014 	add	x20, x0, #0x70
    9a70:	f9419e80 	ldr	x0, [x20, #824]
    9a74:	b5fffaa0 	cbnz	x0, 99c8 <fwp_main_thread+0x218>
    9a78:	f9419280 	ldr	x0, [x20, #800]
    9a7c:	97ffebfd 	bl	4a70 <fwp_mem_free>
    9a80:	f901929f 	str	xzr, [x20, #800]
    9a84:	f9019a9f 	str	xzr, [x20, #816]
    9a88:	f941b280 	ldr	x0, [x20, #864]
    9a8c:	b4009e13 	cbz	x19, ae4c <fwp_main_thread+0x169c>
    9a90:	f900567f 	str	xzr, [x19, #168]
    9a94:	f9005e7f 	str	xzr, [x19, #184]
    9a98:	b9035a9f 	str	wzr, [x20, #856]
    9a9c:	eb00027f 	cmp	x19, x0
    9aa0:	54fffa20 	b.eq	99e4 <fwp_main_thread+0x234>  // b.none
    9aa4:	97ffe38b 	bl	28d0 <abort@plt>
    9aa8:	97ffe7b6 	bl	3980 <fwp_now_ns>
    9aac:	f9403281 	ldr	x1, [x20, #96]
    9ab0:	eb01001f 	cmp	x0, x1
    9ab4:	540000ab 	b.lt	9ac8 <fwp_main_thread+0x318>  // b.tstop
    9ab8:	39414280 	ldrb	w0, [x20, #80]
    9abc:	37000060 	tbnz	w0, #0, 9ac8 <fwp_main_thread+0x318>
    9ac0:	aa1403e0 	mov	x0, x20
    9ac4:	97ffe70b 	bl	36f0 <fwp_cancel_tree.part.0>
    9ac8:	39414680 	ldrb	w0, [x20, #81]
    9acc:	39414a62 	ldrb	w2, [x19, #82]
    9ad0:	3707f1c0 	tbnz	w0, #0, 9908 <fwp_main_thread+0x158>
    9ad4:	f9403280 	ldr	x0, [x20, #96]
    9ad8:	370001a2 	tbnz	w2, #0, 9b0c <fwp_main_thread+0x35c>
    9adc:	f9403261 	ldr	x1, [x19, #96]
    9ae0:	b4000161 	cbz	x1, 9b0c <fwp_main_thread+0x35c>
    9ae4:	b4008de0 	cbz	x0, aca0 <fwp_main_thread+0x14f0>
    9ae8:	eb01001f 	cmp	x0, x1
    9aec:	9a81d000 	csel	x0, x0, x1, le
    9af0:	f9402281 	ldr	x1, [x20, #64]
    9af4:	a911fe77 	stp	x23, xzr, [x19, #280]
    9af8:	f9009661 	str	x1, [x19, #296]
    9afc:	b4000041 	cbz	x1, 9b04 <fwp_main_thread+0x354>
    9b00:	f9009033 	str	x19, [x1, #288]
    9b04:	f9002293 	str	x19, [x20, #64]
    9b08:	17ffff89 	b	992c <fwp_main_thread+0x17c>
    9b0c:	f9402281 	ldr	x1, [x20, #64]
    9b10:	17ffff81 	b	9914 <fwp_main_thread+0x164>
    9b14:	aa0103f3 	mov	x19, x1
    9b18:	17ffff75 	b	98ec <fwp_main_thread+0x13c>
    9b1c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9b20:	f9009661 	str	x1, [x19, #296]
    9b24:	b4000041 	cbz	x1, 9b2c <fwp_main_thread+0x37c>
    9b28:	f9009033 	str	x19, [x1, #288]
    9b2c:	f9002293 	str	x19, [x20, #64]
    9b30:	17ffff86 	b	9948 <fwp_main_thread+0x198>
    9b34:	f9000040 	str	x0, [x2]
    9b38:	17ffff8c 	b	9968 <fwp_main_thread+0x1b8>
    9b3c:	f9006ea0 	str	x0, [x21, #216]
    9b40:	17ffff95 	b	9994 <fwp_main_thread+0x1e4>
    9b44:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9b48:	91058000 	add	x0, x0, #0x160
    9b4c:	94000689 	bl	b570 <atexit>
    9b50:	350090c0 	cbnz	w0, ad68 <fwp_main_thread+0x15b8>
    9b54:	52800020 	mov	w0, #0x1                   	// #1
    9b58:	b9034a60 	str	w0, [x19, #840]
    9b5c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b60:	9101c000 	add	x0, x0, #0x70
    9b64:	b9434c01 	ldr	w1, [x0, #844]
    9b68:	35ffeb01 	cbnz	w1, 98c8 <fwp_main_thread+0x118>
    9b6c:	f9418803 	ldr	x3, [x0, #784]
    9b70:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9b74:	f9018818 	str	x24, [x0, #784]
    9b78:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b7c:	91174033 	add	x19, x1, #0x5d0
    9b80:	f0000001 	adrp	x1, c000 <_IO_stdin_used+0xa60>
    9b84:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9b88:	d2800015 	mov	x21, #0x0                   	// #0
    9b8c:	fd41b828 	ldr	d8, [x1, #880]
    9b90:	913d4042 	add	x2, x2, #0xf50
    9b94:	90ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x110>
    9b98:	d280401a 	mov	x26, #0x200                 	// #512
    9b9c:	912b8021 	add	x1, x1, #0xae0
    9ba0:	d2800014 	mov	x20, #0x0                   	// #0
    9ba4:	52800037 	mov	w23, #0x1                   	// #1
    9ba8:	a9308ba3 	stp	x3, x2, [x29, #-248]
    9bac:	a931ffbb 	stp	x27, xzr, [x29, #-232]
    9bb0:	a93307bf 	stp	xzr, x1, [x29, #-208]
    9bb4:	f91f7816 	str	x22, [x0, #16112]
    9bb8:	f91f7c1b 	str	x27, [x0, #16120]
    9bbc:	b953a660 	ldr	w0, [x19, #5028]
    9bc0:	f1000759 	subs	x25, x26, #0x1
    9bc4:	f81283b9 	stur	x25, [x29, #-216]
    9bc8:	da1f0296 	sbc	x22, x20, xzr
    9bcc:	aa1903fa 	mov	x26, x25
    9bd0:	aa1603f4 	mov	x20, x22
    9bd4:	340048a0 	cbz	w0, a4e8 <fwp_main_thread+0xd38>
    9bd8:	397e8a60 	ldrb	w0, [x19, #4002]
    9bdc:	910f0001 	add	x1, x0, #0x3c0
    9be0:	8b000400 	add	x0, x0, x0, lsl #1
    9be4:	b8617a7b 	ldr	w27, [x19, x1, lsl #2]
    9be8:	8b000e61 	add	x1, x19, x0, lsl #3
    9bec:	f8607a78 	ldr	x24, [x19, x0, lsl #3]
    9bf0:	2a1b03fc 	mov	w28, w27
    9bf4:	b4004698 	cbz	x24, a4c4 <fwp_main_thread+0xd14>
    9bf8:	f9400301 	ldr	x1, [x24]
    9bfc:	aa2103e1 	mvn	x1, x1
    9c00:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9c04:	f100639f 	cmp	x28, #0x18
    9c08:	540000e9 	b.ls	9c24 <fwp_main_thread+0x474>  // b.plast
    9c0c:	d1006782 	sub	x2, x28, #0x19
    9c10:	91006300 	add	x0, x24, #0x18
    9c14:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9c18:	52800001 	mov	w1, #0x0                   	// #0
    9c1c:	91002042 	add	x2, x2, #0x8
    9c20:	97ffe30c 	bl	2850 <memset@plt>
    9c24:	f94a1260 	ldr	x0, [x19, #5152]
    9c28:	ab1c0000 	adds	x0, x0, x28
    9c2c:	54008762 	b.cs	ad18 <fwp_main_thread+0x1568>  // b.hs, b.nlast
    9c30:	f94a1661 	ldr	x1, [x19, #5160]
    9c34:	f90a1260 	str	x0, [x19, #5152]
    9c38:	eb01001f 	cmp	x0, x1
    9c3c:	54000049 	b.ls	9c44 <fwp_main_thread+0x494>  // b.plast
    9c40:	f90a1660 	str	x0, [x19, #5160]
    9c44:	1e630361 	ucvtf	d1, w27
    9c48:	fd4a1e60 	ldr	d0, [x19, #5176]
    9c4c:	1e612800 	fadd	d0, d0, d1
    9c50:	fd0a1e60 	str	d0, [x19, #5176]
    9c54:	a900d719 	stp	x25, x21, [x24, #8]
    9c58:	aa1803f5 	mov	x21, x24
    9c5c:	fd000308 	str	d8, [x24]
    9c60:	f949da62 	ldr	x2, [x19, #5040]
    9c64:	f949ee60 	ldr	x0, [x19, #5080]
    9c68:	cb020302 	sub	x2, x24, x2
    9c6c:	eb00405f 	cmp	x2, x0, lsl #16
    9c70:	54000302 	b.cs	9cd0 <fwp_main_thread+0x520>  // b.hs, b.nlast
    9c74:	d350fc40 	lsr	x0, x2, #16
    9c78:	f949fe64 	ldr	x4, [x19, #5112]
    9c7c:	8b000800 	add	x0, x0, x0, lsl #2
    9c80:	d37df001 	lsl	x1, x0, #3
    9c84:	8b010080 	add	x0, x4, x1
    9c88:	f940101c 	ldr	x28, [x0, #32]
    9c8c:	b400023c 	cbz	x28, 9cd0 <fwp_main_thread+0x520>
    9c90:	38616881 	ldrb	w1, [x4, x1]
    9c94:	7100083f 	cmp	w1, #0x2
    9c98:	54004320 	b.eq	a4fc <fwp_main_thread+0xd4c>  // b.none
    9c9c:	7100043f 	cmp	w1, #0x1
    9ca0:	54000181 	b.ne	9cd0 <fwp_main_thread+0x520>  // b.any
    9ca4:	29430004 	ldp	w4, w0, [x0, #24]
    9ca8:	92403c41 	and	x1, x2, #0xffff
    9cac:	9b047c21 	mul	x1, x1, x4
    9cb0:	d360fc21 	lsr	x1, x1, #32
    9cb4:	eb00003f 	cmp	x1, x0
    9cb8:	540000c2 	b.cs	9cd0 <fwp_main_thread+0x520>  // b.hs, b.nlast
    9cbc:	8b01039c 	add	x28, x28, x1
    9cc0:	39400380 	ldrb	w0, [x28]
    9cc4:	7103fc1f 	cmp	w0, #0xff
    9cc8:	54004240 	b.eq	a510 <fwp_main_thread+0xd60>  // b.none
    9ccc:	39000397 	strb	w23, [x28]
    9cd0:	f81203b8 	stur	x24, [x29, #-224]
    9cd4:	aa160339 	orr	x25, x25, x22
    9cd8:	b5fff739 	cbnz	x25, 9bbc <fwp_main_thread+0x40c>
    9cdc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9ce0:	d10303a1 	sub	x1, x29, #0xc0
    9ce4:	f85083a3 	ldur	x3, [x29, #-248]
    9ce8:	f95f7816 	ldr	x22, [x0, #16112]
    9cec:	f91f7418 	str	x24, [x0, #16104]
    9cf0:	f95f7c1b 	ldr	x27, [x0, #16120]
    9cf4:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    9cf8:	3dc0e000 	ldr	q0, [x0, #896]
    9cfc:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d00:	9101c002 	add	x2, x0, #0x70
    9d04:	52800020 	mov	w0, #0x1                   	// #1
    9d08:	3c9403a0 	stur	q0, [x29, #-192]
    9d0c:	f9018843 	str	x3, [x2, #784]
    9d10:	97ffee64 	bl	56a0 <fwp_data.part.0.constprop.0>
    9d14:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9d18:	91174022 	add	x2, x1, #0x5d0
    9d1c:	aa0003f4 	mov	x20, x0
    9d20:	f949d841 	ldr	x1, [x2, #5040]
    9d24:	f949ec40 	ldr	x0, [x2, #5080]
    9d28:	cb010281 	sub	x1, x20, x1
    9d2c:	eb00403f 	cmp	x1, x0, lsl #16
    9d30:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d34:	f95f7406 	ldr	x6, [x0, #16104]
    9d38:	54000322 	b.cs	9d9c <fwp_main_thread+0x5ec>  // b.hs, b.nlast
    9d3c:	d350fc20 	lsr	x0, x1, #16
    9d40:	f949fc43 	ldr	x3, [x2, #5112]
    9d44:	8b000800 	add	x0, x0, x0, lsl #2
    9d48:	d37df002 	lsl	x2, x0, #3
    9d4c:	8b020060 	add	x0, x3, x2
    9d50:	f9401013 	ldr	x19, [x0, #32]
    9d54:	b4000253 	cbz	x19, 9d9c <fwp_main_thread+0x5ec>
    9d58:	38626862 	ldrb	w2, [x3, x2]
    9d5c:	7100085f 	cmp	w2, #0x2
    9d60:	54007880 	b.eq	ac70 <fwp_main_thread+0x14c0>  // b.none
    9d64:	7100045f 	cmp	w2, #0x1
    9d68:	540001a1 	b.ne	9d9c <fwp_main_thread+0x5ec>  // b.any
    9d6c:	29430002 	ldp	w2, w0, [x0, #24]
    9d70:	92403c21 	and	x1, x1, #0xffff
    9d74:	9b027c21 	mul	x1, x1, x2
    9d78:	d360fc21 	lsr	x1, x1, #32
    9d7c:	eb00003f 	cmp	x1, x0
    9d80:	540000e2 	b.cs	9d9c <fwp_main_thread+0x5ec>  // b.hs, b.nlast
    9d84:	8b010273 	add	x19, x19, x1
    9d88:	39400260 	ldrb	w0, [x19]
    9d8c:	7103fc1f 	cmp	w0, #0xff
    9d90:	540078c0 	b.eq	aca8 <fwp_main_thread+0x14f8>  // b.none
    9d94:	52800020 	mov	w0, #0x1                   	// #1
    9d98:	39000260 	strb	w0, [x19]
    9d9c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9da0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9da4:	aa1603e1 	mov	x1, x22
    9da8:	a93653a2 	stp	x2, x20, [x29, #-160]
    9dac:	f91f7c06 	str	x6, [x0, #16120]
    9db0:	52800020 	mov	w0, #0x1                   	// #1
    9db4:	97ffee3b 	bl	56a0 <fwp_data.part.0.constprop.0>
    9db8:	aa0003f4 	mov	x20, x0
    9dbc:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9dc0:	91174022 	add	x2, x1, #0x5d0
    9dc4:	f949d841 	ldr	x1, [x2, #5040]
    9dc8:	f949ec40 	ldr	x0, [x2, #5080]
    9dcc:	cb010281 	sub	x1, x20, x1
    9dd0:	eb00403f 	cmp	x1, x0, lsl #16
    9dd4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9dd8:	f95f7c06 	ldr	x6, [x0, #16120]
    9ddc:	54000322 	b.cs	9e40 <fwp_main_thread+0x690>  // b.hs, b.nlast
    9de0:	d350fc20 	lsr	x0, x1, #16
    9de4:	f949fc43 	ldr	x3, [x2, #5112]
    9de8:	8b000800 	add	x0, x0, x0, lsl #2
    9dec:	d37df002 	lsl	x2, x0, #3
    9df0:	8b020060 	add	x0, x3, x2
    9df4:	f9401013 	ldr	x19, [x0, #32]
    9df8:	b4000253 	cbz	x19, 9e40 <fwp_main_thread+0x690>
    9dfc:	38626862 	ldrb	w2, [x3, x2]
    9e00:	7100085f 	cmp	w2, #0x2
    9e04:	54007420 	b.eq	ac88 <fwp_main_thread+0x14d8>  // b.none
    9e08:	7100045f 	cmp	w2, #0x1
    9e0c:	540001a1 	b.ne	9e40 <fwp_main_thread+0x690>  // b.any
    9e10:	29430002 	ldp	w2, w0, [x0, #24]
    9e14:	92403c21 	and	x1, x1, #0xffff
    9e18:	9b027c21 	mul	x1, x1, x2
    9e1c:	d360fc21 	lsr	x1, x1, #32
    9e20:	eb00003f 	cmp	x1, x0
    9e24:	540000e2 	b.cs	9e40 <fwp_main_thread+0x690>  // b.hs, b.nlast
    9e28:	8b010273 	add	x19, x19, x1
    9e2c:	39400260 	ldrb	w0, [x19]
    9e30:	7103fc1f 	cmp	w0, #0xff
    9e34:	54007480 	b.eq	acc4 <fwp_main_thread+0x1514>  // b.none
    9e38:	52800020 	mov	w0, #0x1                   	// #1
    9e3c:	39000260 	strb	w0, [x19]
    9e40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e44:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9e48:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9e4c:	d102c3a1 	sub	x1, x29, #0xb0
    9e50:	a93553a2 	stp	x2, x20, [x29, #-176]
    9e54:	f91f7c06 	str	x6, [x0, #16120]
    9e58:	52800020 	mov	w0, #0x1                   	// #1
    9e5c:	97ffee11 	bl	56a0 <fwp_data.part.0.constprop.0>
    9e60:	aa0003f6 	mov	x22, x0
    9e64:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9e68:	91174023 	add	x3, x1, #0x5d0
    9e6c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e70:	f949ec62 	ldr	x2, [x3, #5080]
    9e74:	f949d861 	ldr	x1, [x3, #5040]
    9e78:	d370bc42 	lsl	x2, x2, #16
    9e7c:	cb0102c1 	sub	x1, x22, x1
    9e80:	f95f7c06 	ldr	x6, [x0, #16120]
    9e84:	eb02003f 	cmp	x1, x2
    9e88:	540003e2 	b.cs	9f04 <fwp_main_thread+0x754>  // b.hs, b.nlast
    9e8c:	d350fc20 	lsr	x0, x1, #16
    9e90:	f949fc64 	ldr	x4, [x3, #5112]
    9e94:	8b000800 	add	x0, x0, x0, lsl #2
    9e98:	d37df003 	lsl	x3, x0, #3
    9e9c:	8b030080 	add	x0, x4, x3
    9ea0:	f9401013 	ldr	x19, [x0, #32]
    9ea4:	b4000313 	cbz	x19, 9f04 <fwp_main_thread+0x754>
    9ea8:	38636883 	ldrb	w3, [x4, x3]
    9eac:	7100087f 	cmp	w3, #0x2
    9eb0:	54006e60 	b.eq	ac7c <fwp_main_thread+0x14cc>  // b.none
    9eb4:	7100047f 	cmp	w3, #0x1
    9eb8:	54000261 	b.ne	9f04 <fwp_main_thread+0x754>  // b.any
    9ebc:	29430004 	ldp	w4, w0, [x0, #24]
    9ec0:	92403c23 	and	x3, x1, #0xffff
    9ec4:	9b047c63 	mul	x3, x3, x4
    9ec8:	d360fc63 	lsr	x3, x3, #32
    9ecc:	eb00007f 	cmp	x3, x0
    9ed0:	540001a2 	b.cs	9f04 <fwp_main_thread+0x754>  // b.hs, b.nlast
    9ed4:	8b030273 	add	x19, x19, x3
    9ed8:	39400260 	ldrb	w0, [x19]
    9edc:	7103fc1f 	cmp	w0, #0xff
    9ee0:	54007000 	b.eq	ace0 <fwp_main_thread+0x1530>  // b.none
    9ee4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ee8:	91174000 	add	x0, x0, #0x5d0
    9eec:	52800021 	mov	w1, #0x1                   	// #1
    9ef0:	39000261 	strb	w1, [x19]
    9ef4:	f949ec02 	ldr	x2, [x0, #5080]
    9ef8:	f949d801 	ldr	x1, [x0, #5040]
    9efc:	d370bc42 	lsl	x2, x2, #16
    9f00:	cb0102c1 	sub	x1, x22, x1
    9f04:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f08:	f00000a5 	adrp	x5, 20000 <__data_start>
    9f0c:	910040b7 	add	x23, x5, #0x10
    9f10:	d10403b3 	sub	x19, x29, #0x100
    9f14:	910102f7 	add	x23, x23, #0x40
    9f18:	f91f5406 	str	x6, [x0, #16040]
    9f1c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f20:	9101c01c 	add	x28, x0, #0x70
    9f24:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f28:	f91f4c06 	str	x6, [x0, #16024]
    9f2c:	aa1703e6 	mov	x6, x23
    9f30:	f91f5005 	str	x5, [x0, #16032]
    9f34:	f91f581b 	str	x27, [x0, #16048]
    9f38:	f91f5c16 	str	x22, [x0, #16056]
    9f3c:	eb02003f 	cmp	x1, x2
    9f40:	54000382 	b.cs	9fb0 <fwp_main_thread+0x800>  // b.hs, b.nlast
    9f44:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9f48:	91174002 	add	x2, x0, #0x5d0
    9f4c:	d350fc20 	lsr	x0, x1, #16
    9f50:	f949fc44 	ldr	x4, [x2, #5112]
    9f54:	8b000800 	add	x0, x0, x0, lsl #2
    9f58:	d37df002 	lsl	x2, x0, #3
    9f5c:	8b020083 	add	x3, x4, x2
    9f60:	f9401060 	ldr	x0, [x3, #32]
    9f64:	b4000260 	cbz	x0, 9fb0 <fwp_main_thread+0x800>
    9f68:	38626882 	ldrb	w2, [x4, x2]
    9f6c:	7100085f 	cmp	w2, #0x2
    9f70:	54006920 	b.eq	ac94 <fwp_main_thread+0x14e4>  // b.none
    9f74:	7100045f 	cmp	w2, #0x1
    9f78:	540001c1 	b.ne	9fb0 <fwp_main_thread+0x800>  // b.any
    9f7c:	29430864 	ldp	w4, w2, [x3, #24]
    9f80:	92403c21 	and	x1, x1, #0xffff
    9f84:	9b047c21 	mul	x1, x1, x4
    9f88:	d360fc21 	lsr	x1, x1, #32
    9f8c:	eb02003f 	cmp	x1, x2
    9f90:	54000102 	b.cs	9fb0 <fwp_main_thread+0x800>  // b.hs, b.nlast
    9f94:	8b010000 	add	x0, x0, x1
    9f98:	39400001 	ldrb	w1, [x0]
    9f9c:	340000a1 	cbz	w1, 9fb0 <fwp_main_thread+0x800>
    9fa0:	7103f43f 	cmp	w1, #0xfd
    9fa4:	54006ac8 	b.hi	acfc <fwp_main_thread+0x154c>  // b.pmore
    9fa8:	11000421 	add	w1, w1, #0x1
    9fac:	39000001 	strb	w1, [x0]
    9fb0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9fb4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9fb8:	f9404783 	ldr	x3, [x28, #136]
    9fbc:	f95f5000 	ldr	x0, [x0, #16032]
    9fc0:	f95f5c21 	ldr	x1, [x1, #16056]
    9fc4:	91004000 	add	x0, x0, #0x10
    9fc8:	f81003a1 	stur	x1, [x29, #-256]
    9fcc:	91010004 	add	x4, x0, #0x40
    9fd0:	b9404001 	ldr	w1, [x0, #64]
    9fd4:	d37be821 	lsl	x1, x1, #5
    9fd8:	8b010065 	add	x5, x3, x1
    9fdc:	f9400ca2 	ldr	x2, [x5, #24]
    9fe0:	b4006a42 	cbz	x2, ad28 <fwp_main_thread+0x1578>
    9fe4:	f9400c40 	ldr	x0, [x2, #24]
    9fe8:	b4005600 	cbz	x0, aaa8 <fwp_main_thread+0x12f8>
    9fec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9ff0:	91174002 	add	x2, x0, #0x5d0
    9ff4:	f949d841 	ldr	x1, [x2, #5040]
    9ff8:	f949ec40 	ldr	x0, [x2, #5080]
    9ffc:	cb0100c1 	sub	x1, x6, x1
    a000:	eb00403f 	cmp	x1, x0, lsl #16
    a004:	54000342 	b.cs	a06c <fwp_main_thread+0x8bc>  // b.hs, b.nlast
    a008:	d350fc20 	lsr	x0, x1, #16
    a00c:	f949fc44 	ldr	x4, [x2, #5112]
    a010:	8b000800 	add	x0, x0, x0, lsl #2
    a014:	d37df002 	lsl	x2, x0, #3
    a018:	8b020083 	add	x3, x4, x2
    a01c:	f9401060 	ldr	x0, [x3, #32]
    a020:	b4000260 	cbz	x0, a06c <fwp_main_thread+0x8bc>
    a024:	38626882 	ldrb	w2, [x4, x2]
    a028:	7100085f 	cmp	w2, #0x2
    a02c:	54005b40 	b.eq	ab94 <fwp_main_thread+0x13e4>  // b.none
    a030:	7100045f 	cmp	w2, #0x1
    a034:	540001c1 	b.ne	a06c <fwp_main_thread+0x8bc>  // b.any
    a038:	29430864 	ldp	w4, w2, [x3, #24]
    a03c:	92403c21 	and	x1, x1, #0xffff
    a040:	9b047c21 	mul	x1, x1, x4
    a044:	d360fc21 	lsr	x1, x1, #32
    a048:	eb02003f 	cmp	x1, x2
    a04c:	54000102 	b.cs	a06c <fwp_main_thread+0x8bc>  // b.hs, b.nlast
    a050:	8b010000 	add	x0, x0, x1
    a054:	39400001 	ldrb	w1, [x0]
    a058:	340000a1 	cbz	w1, a06c <fwp_main_thread+0x8bc>
    a05c:	7103f43f 	cmp	w1, #0xfd
    a060:	54005e48 	b.hi	ac28 <fwp_main_thread+0x1478>  // b.pmore
    a064:	11000421 	add	w1, w1, #0x1
    a068:	39000001 	strb	w1, [x0]
    a06c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a070:	91174035 	add	x21, x1, #0x5d0
    a074:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a078:	aa0603f8 	mov	x24, x6
    a07c:	aa1303fb 	mov	x27, x19
    a080:	aa0603e0 	mov	x0, x6
    a084:	52800034 	mov	w20, #0x1                   	// #1
    a088:	f91f6033 	str	x19, [x1, #16064]
    a08c:	f91f6426 	str	x6, [x1, #16072]
    a090:	b93ee834 	str	w20, [x1, #16104]
    a094:	b93ef034 	str	w20, [x1, #16112]
    a098:	b94000a2 	ldr	w2, [x5]
    a09c:	b9400401 	ldr	w1, [x0, #4]
    a0a0:	4b010040 	sub	w0, w2, w1
    a0a4:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a0a8:	b93ee440 	str	w0, [x2, #16100]
    a0ac:	b97ee842 	ldr	w2, [x2, #16104]
    a0b0:	6b02001f 	cmp	w0, w2
    a0b4:	1a829019 	csel	w25, w0, w2, ls	// ls = plast
    a0b8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a0bc:	b97ef000 	ldr	w0, [x0, #16112]
    a0c0:	6b00033f 	cmp	w25, w0
    a0c4:	1a809336 	csel	w22, w25, w0, ls	// ls = plast
    a0c8:	6b160322 	subs	w2, w25, w22
    a0cc:	540000c0 	b.eq	a0e4 <fwp_main_thread+0x934>  // b.none
    a0d0:	f9400ca4 	ldr	x4, [x5, #24]
    a0d4:	0b160021 	add	w1, w1, w22
    a0d8:	8b364f60 	add	x0, x27, w22, uxtw #3
    a0dc:	f9400884 	ldr	x4, [x4, #16]
    a0e0:	d63f0080 	blr	x4
    a0e4:	f9404780 	ldr	x0, [x28, #136]
    a0e8:	aa1803e7 	mov	x7, x24
    a0ec:	b9400304 	ldr	w4, [x24]
    a0f0:	aa1b03fa 	mov	x26, x27
    a0f4:	2a1903f7 	mov	w23, w25
    a0f8:	aa1803e9 	mov	x9, x24
    a0fc:	8b041404 	add	x4, x0, x4, lsl #5
    a100:	f9400c88 	ldr	x8, [x4, #24]
    a104:	b4002208 	cbz	x8, a544 <fwp_main_thread+0xd94>
    a108:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a10c:	aa0403f4 	mov	x20, x4
    a110:	f91f681b 	str	x27, [x0, #16080]
    a114:	b93ed816 	str	w22, [x0, #16088]
    a118:	b93ee019 	str	w25, [x0, #16096]
    a11c:	14000012 	b	a164 <fwp_main_thread+0x9b4>
    a120:	f9400101 	ldr	x1, [x8]
    a124:	aa1a03e0 	mov	x0, x26
    a128:	d63f0020 	blr	x1
    a12c:	aa0003fb 	mov	x27, x0
    a130:	aa1803e0 	mov	x0, x24
    a134:	97ffeebf 	bl	5c30 <fwp_closure_drop>
    a138:	6b1702df 	cmp	w22, w23
    a13c:	54000d00 	b.eq	a2dc <fwp_main_thread+0xb2c>  // b.none
    a140:	f9404780 	ldr	x0, [x28, #136]
    a144:	8b364f5a 	add	x26, x26, w22, uxtw #3
    a148:	b9400364 	ldr	w4, [x27]
    a14c:	4b130337 	sub	w23, w25, w19
    a150:	aa1b03e7 	mov	x7, x27
    a154:	8b041414 	add	x20, x0, x4, lsl #5
    a158:	f9400e88 	ldr	x8, [x20, #24]
    a15c:	b4001ea8 	cbz	x8, a530 <fwp_main_thread+0xd80>
    a160:	aa1b03f8 	mov	x24, x27
    a164:	b94004e9 	ldr	w9, [x7, #4]
    a168:	b9400293 	ldr	w19, [x20]
    a16c:	0b170139 	add	w25, w9, w23
    a170:	6b19027f 	cmp	w19, w25
    a174:	540037a8 	b.hi	a868 <fwp_main_thread+0x10b8>  // b.pmore
    a178:	7100013f 	cmp	w9, #0x0
    a17c:	4b090276 	sub	w22, w19, w9
    a180:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    a184:	54fffce1 	b.ne	a120 <fwp_main_thread+0x970>  // b.any
    a188:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a18c:	910003e0 	mov	x0, sp
    a190:	7100027f 	cmp	w19, #0x0
    a194:	f91f7c20 	str	x0, [x1, #16120]
    a198:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    a19c:	d37df000 	lsl	x0, x0, #3
    a1a0:	91003c00 	add	x0, x0, #0xf
    a1a4:	92704c01 	and	x1, x0, #0xfffff0000
    a1a8:	927c7c00 	and	x0, x0, #0xffffffff0
    a1ac:	cb2163e1 	sub	x1, sp, x1
    a1b0:	eb2163ff 	cmp	sp, x1
    a1b4:	540000a0 	b.eq	a1c8 <fwp_main_thread+0xa18>  // b.none
    a1b8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a1bc:	f90203ff 	str	xzr, [sp, #1024]
    a1c0:	eb2163ff 	cmp	sp, x1
    a1c4:	54ffffa1 	b.ne	a1b8 <fwp_main_thread+0xa08>  // b.any
    a1c8:	92403c00 	and	x0, x0, #0xffff
    a1cc:	cb2063ff 	sub	sp, sp, x0
    a1d0:	f90003ff 	str	xzr, [sp]
    a1d4:	f110001f 	cmp	x0, #0x400
    a1d8:	54000043 	b.cc	a1e0 <fwp_main_thread+0xa30>  // b.lo, b.ul, b.last
    a1dc:	f90203ff 	str	xzr, [sp, #1024]
    a1e0:	910043fb 	add	x27, sp, #0x10
    a1e4:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a1e8:	910020e1 	add	x1, x7, #0x8
    a1ec:	d2800000 	mov	x0, #0x0                   	// #0
    a1f0:	340000e9 	cbz	w9, a20c <fwp_main_thread+0xa5c>
    a1f4:	d503201f 	nop
    a1f8:	f8606823 	ldr	x3, [x1, x0]
    a1fc:	f8206b63 	str	x3, [x27, x0]
    a200:	91002000 	add	x0, x0, #0x8
    a204:	eb02001f 	cmp	x0, x2
    a208:	54ffff81 	b.ne	a1f8 <fwp_main_thread+0xa48>  // b.any
    a20c:	2a1603e1 	mov	w1, w22
    a210:	d2800000 	mov	x0, #0x0                   	// #0
    a214:	340000f6 	cbz	w22, a230 <fwp_main_thread+0xa80>
    a218:	0b000122 	add	w2, w9, w0
    a21c:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a220:	91000400 	add	x0, x0, #0x1
    a224:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a228:	eb01001f 	cmp	x0, x1
    a22c:	54ffff61 	b.ne	a218 <fwp_main_thread+0xa68>  // b.any
    a230:	f949daa0 	ldr	x0, [x21, #5040]
    a234:	f949eea1 	ldr	x1, [x21, #5080]
    a238:	cb000300 	sub	x0, x24, x0
    a23c:	eb01401f 	cmp	x0, x1, lsl #16
    a240:	540002e2 	b.cs	a29c <fwp_main_thread+0xaec>  // b.hs, b.nlast
    a244:	d350fc01 	lsr	x1, x0, #16
    a248:	f949fea5 	ldr	x5, [x21, #5112]
    a24c:	8b010821 	add	x1, x1, x1, lsl #2
    a250:	d37df021 	lsl	x1, x1, #3
    a254:	8b0100a3 	add	x3, x5, x1
    a258:	f9401062 	ldr	x2, [x3, #32]
    a25c:	b4000202 	cbz	x2, a29c <fwp_main_thread+0xaec>
    a260:	386168a1 	ldrb	w1, [x5, x1]
    a264:	7100083f 	cmp	w1, #0x2
    a268:	540015e0 	b.eq	a524 <fwp_main_thread+0xd74>  // b.none
    a26c:	7100043f 	cmp	w1, #0x1
    a270:	54000161 	b.ne	a29c <fwp_main_thread+0xaec>  // b.any
    a274:	29430465 	ldp	w5, w1, [x3, #24]
    a278:	92403c00 	and	x0, x0, #0xffff
    a27c:	9b057c00 	mul	x0, x0, x5
    a280:	d360fc00 	lsr	x0, x0, #32
    a284:	eb01001f 	cmp	x0, x1
    a288:	540000a2 	b.cs	a29c <fwp_main_thread+0xaec>  // b.hs, b.nlast
    a28c:	8b000042 	add	x2, x2, x0
    a290:	39400040 	ldrb	w0, [x2]
    a294:	7100041f 	cmp	w0, #0x1
    a298:	54001420 	b.eq	a51c <fwp_main_thread+0xd6c>  // b.none
    a29c:	f9400502 	ldr	x2, [x8, #8]
    a2a0:	aa1803e0 	mov	x0, x24
    a2a4:	52800021 	mov	w1, #0x1                   	// #1
    a2a8:	d63f0040 	blr	x2
    a2ac:	f9400e81 	ldr	x1, [x20, #24]
    a2b0:	aa1b03e0 	mov	x0, x27
    a2b4:	f9400021 	ldr	x1, [x1]
    a2b8:	d63f0020 	blr	x1
    a2bc:	aa0003fb 	mov	x27, x0
    a2c0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2c4:	f95f7c00 	ldr	x0, [x0, #16120]
    a2c8:	9100001f 	mov	sp, x0
    a2cc:	aa1803e0 	mov	x0, x24
    a2d0:	97ffee58 	bl	5c30 <fwp_closure_drop>
    a2d4:	6b1702df 	cmp	w22, w23
    a2d8:	54fff341 	b.ne	a140 <fwp_main_thread+0x990>  // b.any
    a2dc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2e0:	aa1b03f8 	mov	x24, x27
    a2e4:	f95f681b 	ldr	x27, [x0, #16080]
    a2e8:	b97ed816 	ldr	w22, [x0, #16088]
    a2ec:	b97ee019 	ldr	w25, [x0, #16096]
    a2f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2f4:	b97ee401 	ldr	w1, [x0, #16100]
    a2f8:	b97ee800 	ldr	w0, [x0, #16104]
    a2fc:	6b00003f 	cmp	w1, w0
    a300:	54001563 	b.cc	a5ac <fwp_main_thread+0xdfc>  // b.lo, b.ul, b.last
    a304:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a308:	f95f6013 	ldr	x19, [x0, #16064]
    a30c:	f95f6406 	ldr	x6, [x0, #16072]
    a310:	140000cf 	b	a64c <fwp_main_thread+0xe9c>
    a314:	f9004293 	str	x19, [x20, #128]
    a318:	17fffdca 	b	9a40 <fwp_main_thread+0x290>
    a31c:	f941b2a0 	ldr	x0, [x21, #864]
    a320:	b9035abf 	str	wzr, [x21, #856]
    a324:	b5ffbc00 	cbnz	x0, 9aa4 <fwp_main_thread+0x2f4>
    a328:	97ffefb2 	bl	61f0 <fwp_free_zombie>
    a32c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a330:	9101c015 	add	x21, x0, #0x70
    a334:	f94042a0 	ldr	x0, [x21, #128]
    a338:	b5ffbb60 	cbnz	x0, 9aa4 <fwp_main_thread+0x2f4>
    a33c:	f9406ea0 	ldr	x0, [x21, #216]
    a340:	b5ffbb20 	cbnz	x0, 9aa4 <fwp_main_thread+0x2f4>
    a344:	b940faa0 	ldr	w0, [x21, #248]
    a348:	340001c0 	cbz	w0, a380 <fwp_main_thread+0xbd0>
    a34c:	93407c14 	sxtw	x20, w0
    a350:	51000400 	sub	w0, w0, #0x1
    a354:	d1000a94 	sub	x20, x20, #0x2
    a358:	910402b6 	add	x22, x21, #0x100
    a35c:	cb204294 	sub	x20, x20, w0, uxtw
    a360:	93407c13 	sxtw	x19, w0
    a364:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    a368:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a36c:	b900fab3 	str	w19, [x21, #248]
    a370:	d1000673 	sub	x19, x19, #0x1
    a374:	97ffe18b 	bl	29a0 <munmap@plt>
    a378:	eb14027f 	cmp	x19, x20
    a37c:	54ffff41 	b.ne	a364 <fwp_main_thread+0xbb4>  // b.any
    a380:	d00000a5 	adrp	x5, 20000 <__data_start>
    a384:	910040a0 	add	x0, x5, #0x10
    a388:	b9404800 	ldr	w0, [x0, #72]
    a38c:	37f800c0 	tbnz	w0, #31, a3a4 <fwp_main_thread+0xbf4>
    a390:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a394:	f91f7c25 	str	x5, [x1, #16120]
    a398:	97ffe13e 	bl	2890 <close@plt>
    a39c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3a0:	f95f7c05 	ldr	x5, [x0, #16120]
    a3a4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a3a8:	9101c000 	add	x0, x0, #0x70
    a3ac:	910040a5 	add	x5, x5, #0x10
    a3b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    a3b4:	d2800013 	mov	x19, #0x0                   	// #0
    a3b8:	f941b415 	ldr	x21, [x0, #872]
    a3bc:	b90048a1 	str	w1, [x5, #72]
    a3c0:	f941b814 	ldr	x20, [x0, #880]
    a3c4:	b4000175 	cbz	x21, a3f0 <fwp_main_thread+0xc40>
    a3c8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    a3cc:	b40000c0 	cbz	x0, a3e4 <fwp_main_thread+0xc34>
    a3d0:	f9400001 	ldr	x1, [x0]
    a3d4:	b5ffb681 	cbnz	x1, 9aa4 <fwp_main_thread+0x2f4>
    a3d8:	f9400401 	ldr	x1, [x0, #8]
    a3dc:	b5ffb641 	cbnz	x1, 9aa4 <fwp_main_thread+0x2f4>
    a3e0:	97ffe9a4 	bl	4a70 <fwp_mem_free>
    a3e4:	91000673 	add	x19, x19, #0x1
    a3e8:	eb1302bf 	cmp	x21, x19
    a3ec:	54fffee1 	b.ne	a3c8 <fwp_main_thread+0xc18>  // b.any
    a3f0:	aa1403e0 	mov	x0, x20
    a3f4:	97ffe99f 	bl	4a70 <fwp_mem_free>
    a3f8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a3fc:	9101c000 	add	x0, x0, #0x70
    a400:	f941b013 	ldr	x19, [x0, #864]
    a404:	f901b41f 	str	xzr, [x0, #872]
    a408:	f901b81f 	str	xzr, [x0, #880]
    a40c:	b40001f3 	cbz	x19, a448 <fwp_main_thread+0xc98>
    a410:	f9401661 	ldr	x1, [x19, #40]
    a414:	b5ffb481 	cbnz	x1, 9aa4 <fwp_main_thread+0x2f4>
    a418:	f9405661 	ldr	x1, [x19, #168]
    a41c:	b5ffb441 	cbnz	x1, 9aa4 <fwp_main_thread+0x2f4>
    a420:	f9419401 	ldr	x1, [x0, #808]
    a424:	b5ffb401 	cbnz	x1, 9aa4 <fwp_main_thread+0x2f4>
    a428:	f9419c00 	ldr	x0, [x0, #824]
    a42c:	b5ffb3c0 	cbnz	x0, 9aa4 <fwp_main_thread+0x2f4>
    a430:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a434:	d0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    a438:	910fc000 	add	x0, x0, #0x3f0
    a43c:	97ffe105 	bl	2850 <memset@plt>
    a440:	aa1303e0 	mov	x0, x19
    a444:	97ffe98b 	bl	4a70 <fwp_mem_free>
    a448:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a44c:	f947ec00 	ldr	x0, [x0, #4056]
    a450:	d00000a1 	adrp	x1, 20000 <__data_start>
    a454:	9101c021 	add	x1, x1, #0x70
    a458:	f9400000 	ldr	x0, [x0]
    a45c:	f900083f 	str	xzr, [x1, #16]
    a460:	f901b03f 	str	xzr, [x1, #864]
    a464:	97ffe153 	bl	29b0 <fflush@plt>
    a468:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    a46c:	f947f400 	ldr	x0, [x0, #4072]
    a470:	f85f83a2 	ldur	x2, [x29, #-8]
    a474:	f9400001 	ldr	x1, [x0]
    a478:	eb010042 	subs	x2, x2, x1
    a47c:	d2800001 	mov	x1, #0x0                   	// #0
    a480:	540044a1 	b.ne	ad14 <fwp_main_thread+0x1564>  // b.any
    a484:	910003bf 	mov	sp, x29
    a488:	d2800000 	mov	x0, #0x0                   	// #0
    a48c:	a94153f3 	ldp	x19, x20, [sp, #16]
    a490:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a494:	a94363f7 	ldp	x23, x24, [sp, #48]
    a498:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a49c:	a94573fb 	ldp	x27, x28, [sp, #80]
    a4a0:	fd4033e8 	ldr	d8, [sp, #96]
    a4a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    a4a8:	d65f03c0 	ret
    a4ac:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    a4b0:	913e8000 	add	x0, x0, #0xfa0
    a4b4:	9400042f 	bl	b570 <atexit>
    a4b8:	17fffcd4 	b	9808 <fwp_main_thread+0x58>
    a4bc:	97ffe712 	bl	4104 <fwp_heap_init>
    a4c0:	17fffcce 	b	97f8 <fwp_main_thread+0x48>
    a4c4:	f9400438 	ldr	x24, [x1, #8]
    a4c8:	b4000118 	cbz	x24, a4e8 <fwp_main_thread+0xd38>
    a4cc:	f9400820 	ldr	x0, [x1, #16]
    a4d0:	cb180000 	sub	x0, x0, x24
    a4d4:	eb00039f 	cmp	x28, x0
    a4d8:	54000088 	b.hi	a4e8 <fwp_main_thread+0xd38>  // b.pmore
    a4dc:	8b1c0300 	add	x0, x24, x28
    a4e0:	f9000420 	str	x0, [x1, #8]
    a4e4:	17fffdc8 	b	9c04 <fwp_main_thread+0x454>
    a4e8:	52800001 	mov	w1, #0x0                   	// #0
    a4ec:	d2800300 	mov	x0, #0x18                  	// #24
    a4f0:	97ffea80 	bl	4ef0 <fwp_heap_alloc>
    a4f4:	aa0003f8 	mov	x24, x0
    a4f8:	17fffdd7 	b	9c54 <fwp_main_thread+0x4a4>
    a4fc:	72003c5f 	tst	w2, #0xffff
    a500:	54ffbe81 	b.ne	9cd0 <fwp_main_thread+0x520>  // b.any
    a504:	39400380 	ldrb	w0, [x28]
    a508:	7103fc1f 	cmp	w0, #0xff
    a50c:	54ffbe01 	b.ne	9ccc <fwp_main_thread+0x51c>  // b.any
    a510:	aa1c03e0 	mov	x0, x28
    a514:	97ffe8b7 	bl	47f0 <fwp_rc_forget_slot>
    a518:	17fffded 	b	9ccc <fwp_main_thread+0x51c>
    a51c:	b90004ff 	str	wzr, [x7, #4]
    a520:	17ffff63 	b	a2ac <fwp_main_thread+0xafc>
    a524:	72003c1f 	tst	w0, #0xffff
    a528:	54ffeba1 	b.ne	a29c <fwp_main_thread+0xaec>  // b.any
    a52c:	17ffff59 	b	a290 <fwp_main_thread+0xae0>
    a530:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a534:	aa1b03e9 	mov	x9, x27
    a538:	f95f681b 	ldr	x27, [x0, #16080]
    a53c:	b97ed816 	ldr	w22, [x0, #16088]
    a540:	b97ee019 	ldr	w25, [x0, #16096]
    a544:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a548:	aa0903e0 	mov	x0, x9
    a54c:	f91f7c29 	str	x9, [x1, #16120]
    a550:	97ffec9c 	bl	57c0 <fwp_rc_share>
    a554:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a558:	f95f7c09 	ldr	x9, [x0, #16120]
    a55c:	34000157 	cbz	w23, a584 <fwp_main_thread+0xdd4>
    a560:	8b374f53 	add	x19, x26, w23, uxtw #3
    a564:	aa1a03f4 	mov	x20, x26
    a568:	aa0903f8 	mov	x24, x9
    a56c:	d503201f 	nop
    a570:	f8408680 	ldr	x0, [x20], #8
    a574:	97ffec93 	bl	57c0 <fwp_rc_share>
    a578:	eb13029f 	cmp	x20, x19
    a57c:	54ffffa1 	b.ne	a570 <fwp_main_thread+0xdc0>  // b.any
    a580:	aa1803e9 	mov	x9, x24
    a584:	aa1a03e2 	mov	x2, x26
    a588:	2a1703e1 	mov	w1, w23
    a58c:	aa0903e0 	mov	x0, x9
    a590:	97ffea9d 	bl	5004 <fwp_apply>
    a594:	aa0003f8 	mov	x24, x0
    a598:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a59c:	b97ee401 	ldr	w1, [x0, #16100]
    a5a0:	b97ee800 	ldr	w0, [x0, #16104]
    a5a4:	6b00003f 	cmp	w1, w0
    a5a8:	54ffeae2 	b.cs	a304 <fwp_main_thread+0xb54>  // b.hs, b.nlast
    a5ac:	f9404781 	ldr	x1, [x28, #136]
    a5b0:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a5b4:	b9400305 	ldr	w5, [x24]
    a5b8:	4b190000 	sub	w0, w0, w25
    a5bc:	8b394f7b 	add	x27, x27, w25, uxtw #3
    a5c0:	b93ee840 	str	w0, [x2, #16104]
    a5c4:	8b051425 	add	x5, x1, x5, lsl #5
    a5c8:	b97ef040 	ldr	w0, [x2, #16112]
    a5cc:	4b160000 	sub	w0, w0, w22
    a5d0:	b93ef040 	str	w0, [x2, #16112]
    a5d4:	f9400ca1 	ldr	x1, [x5, #24]
    a5d8:	aa1803e0 	mov	x0, x24
    a5dc:	b5ffd5e1 	cbnz	x1, a098 <fwp_main_thread+0x8e8>
    a5e0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5e4:	f95f6406 	ldr	x6, [x0, #16072]
    a5e8:	f91f7c06 	str	x6, [x0, #16120]
    a5ec:	f95f6013 	ldr	x19, [x0, #16064]
    a5f0:	b97ee814 	ldr	w20, [x0, #16104]
    a5f4:	aa1803e0 	mov	x0, x24
    a5f8:	97ffec72 	bl	57c0 <fwp_rc_share>
    a5fc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a600:	f95f7c06 	ldr	x6, [x0, #16120]
    a604:	34000134 	cbz	w20, a628 <fwp_main_thread+0xe78>
    a608:	aa0603fa 	mov	x26, x6
    a60c:	d2800015 	mov	x21, #0x0                   	// #0
    a610:	f8757b60 	ldr	x0, [x27, x21, lsl #3]
    a614:	910006b5 	add	x21, x21, #0x1
    a618:	97ffec6a 	bl	57c0 <fwp_rc_share>
    a61c:	6b15029f 	cmp	w20, w21
    a620:	54ffff88 	b.hi	a610 <fwp_main_thread+0xe60>  // b.pmore
    a624:	aa1a03e6 	mov	x6, x26
    a628:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a62c:	aa1b03e2 	mov	x2, x27
    a630:	2a1403e1 	mov	w1, w20
    a634:	f91f7c06 	str	x6, [x0, #16120]
    a638:	aa1803e0 	mov	x0, x24
    a63c:	97ffea72 	bl	5004 <fwp_apply>
    a640:	aa0003f8 	mov	x24, x0
    a644:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a648:	f95f7c06 	ldr	x6, [x0, #16120]
    a64c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a650:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10850>
    a654:	91102042 	add	x2, x2, #0x408
    a658:	91014042 	add	x2, x2, #0x50
    a65c:	aa1803e1 	mov	x1, x24
    a660:	f91f7c06 	str	x6, [x0, #16120]
    a664:	52800023 	mov	w3, #0x1                   	// #1
    a668:	f95f5800 	ldr	x0, [x0, #16048]
    a66c:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a670:	f81303bf 	stur	xzr, [x29, #-208]
    a674:	97fff853 	bl	87c0 <fwp_write>
    a678:	a9726bb5 	ldp	x21, x26, [x29, #-224]
    a67c:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0xa60>
    a680:	9102e000 	add	x0, x0, #0xb8
    a684:	f10002bf 	cmp	x21, #0x0
    a688:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a68c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a690:	b1002b5f 	cmn	x26, #0xa
    a694:	f95f7c06 	ldr	x6, [x0, #16120]
    a698:	54003628 	b.hi	ad5c <fwp_main_thread+0x15ac>  // b.pmore
    a69c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6a0:	52800021 	mov	w1, #0x1                   	// #1
    a6a4:	f91f7c06 	str	x6, [x0, #16120]
    a6a8:	91002740 	add	x0, x26, #0x9
    a6ac:	97ffea11 	bl	4ef0 <fwp_heap_alloc>
    a6b0:	aa0003f4 	mov	x20, x0
    a6b4:	aa1503e1 	mov	x1, x21
    a6b8:	aa0003f5 	mov	x21, x0
    a6bc:	aa1a03e2 	mov	x2, x26
    a6c0:	f80086ba 	str	x26, [x21], #8
    a6c4:	8b1a029a 	add	x26, x20, x26
    a6c8:	aa1503e0 	mov	x0, x21
    a6cc:	97ffe001 	bl	26d0 <memcpy@plt>
    a6d0:	3900235f 	strb	wzr, [x26, #8]
    a6d4:	f85203a0 	ldur	x0, [x29, #-224]
    a6d8:	97ffe09a 	bl	2940 <free@plt>
    a6dc:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a6e0:	91174002 	add	x2, x0, #0x5d0
    a6e4:	f949d841 	ldr	x1, [x2, #5040]
    a6e8:	f949ec40 	ldr	x0, [x2, #5080]
    a6ec:	cb010281 	sub	x1, x20, x1
    a6f0:	eb00403f 	cmp	x1, x0, lsl #16
    a6f4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6f8:	f95f7c06 	ldr	x6, [x0, #16120]
    a6fc:	54000322 	b.cs	a760 <fwp_main_thread+0xfb0>  // b.hs, b.nlast
    a700:	d350fc20 	lsr	x0, x1, #16
    a704:	f949fc43 	ldr	x3, [x2, #5112]
    a708:	8b000800 	add	x0, x0, x0, lsl #2
    a70c:	d37df002 	lsl	x2, x0, #3
    a710:	8b020060 	add	x0, x3, x2
    a714:	f940101a 	ldr	x26, [x0, #32]
    a718:	b400025a 	cbz	x26, a760 <fwp_main_thread+0xfb0>
    a71c:	38626862 	ldrb	w2, [x3, x2]
    a720:	7100085f 	cmp	w2, #0x2
    a724:	540034a0 	b.eq	adb8 <fwp_main_thread+0x1608>  // b.none
    a728:	7100045f 	cmp	w2, #0x1
    a72c:	540001a1 	b.ne	a760 <fwp_main_thread+0xfb0>  // b.any
    a730:	29430002 	ldp	w2, w0, [x0, #24]
    a734:	92403c21 	and	x1, x1, #0xffff
    a738:	9b027c21 	mul	x1, x1, x2
    a73c:	d360fc21 	lsr	x1, x1, #32
    a740:	eb00003f 	cmp	x1, x0
    a744:	540000e2 	b.cs	a760 <fwp_main_thread+0xfb0>  // b.hs, b.nlast
    a748:	8b01035a 	add	x26, x26, x1
    a74c:	39400340 	ldrb	w0, [x26]
    a750:	7103fc1f 	cmp	w0, #0xff
    a754:	54003820 	b.eq	ae58 <fwp_main_thread+0x16a8>  // b.none
    a758:	52800020 	mov	w0, #0x1                   	// #1
    a75c:	39000340 	strb	w0, [x26]
    a760:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a764:	f91f7c06 	str	x6, [x0, #16120]
    a768:	aa1803e0 	mov	x0, x24
    a76c:	97ffec82 	bl	5974 <fwp_drop0>
    a770:	d00000a0 	adrp	x0, 20000 <__data_start>
    a774:	9101c003 	add	x3, x0, #0x70
    a778:	f9400282 	ldr	x2, [x20]
    a77c:	aa1503e0 	mov	x0, x21
    a780:	aa0303f5 	mov	x21, x3
    a784:	d2800021 	mov	x1, #0x1                   	// #1
    a788:	f9400463 	ldr	x3, [x3, #8]
    a78c:	97ffe07d 	bl	2980 <fwrite@plt>
    a790:	f94006a1 	ldr	x1, [x21, #8]
    a794:	52800140 	mov	w0, #0xa                   	// #10
    a798:	97ffe002 	bl	27a0 <fputc@plt>
    a79c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a7a0:	91174002 	add	x2, x0, #0x5d0
    a7a4:	f949d841 	ldr	x1, [x2, #5040]
    a7a8:	f949ec40 	ldr	x0, [x2, #5080]
    a7ac:	cb010281 	sub	x1, x20, x1
    a7b0:	eb00403f 	cmp	x1, x0, lsl #16
    a7b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7b8:	f95f7c06 	ldr	x6, [x0, #16120]
    a7bc:	54000382 	b.cs	a82c <fwp_main_thread+0x107c>  // b.hs, b.nlast
    a7c0:	d350fc20 	lsr	x0, x1, #16
    a7c4:	f949fc43 	ldr	x3, [x2, #5112]
    a7c8:	8b000800 	add	x0, x0, x0, lsl #2
    a7cc:	d37df000 	lsl	x0, x0, #3
    a7d0:	8b000062 	add	x2, x3, x0
    a7d4:	f9401055 	ldr	x21, [x2, #32]
    a7d8:	b40002b5 	cbz	x21, a82c <fwp_main_thread+0x107c>
    a7dc:	38606860 	ldrb	w0, [x3, x0]
    a7e0:	7100081f 	cmp	w0, #0x2
    a7e4:	54002e40 	b.eq	adac <fwp_main_thread+0x15fc>  // b.none
    a7e8:	7100041f 	cmp	w0, #0x1
    a7ec:	54000201 	b.ne	a82c <fwp_main_thread+0x107c>  // b.any
    a7f0:	29430043 	ldp	w3, w0, [x2, #24]
    a7f4:	92403c21 	and	x1, x1, #0xffff
    a7f8:	9b037c21 	mul	x1, x1, x3
    a7fc:	d360fc21 	lsr	x1, x1, #32
    a800:	eb00003f 	cmp	x1, x0
    a804:	54000142 	b.cs	a82c <fwp_main_thread+0x107c>  // b.hs, b.nlast
    a808:	8b0102b5 	add	x21, x21, x1
    a80c:	394002a0 	ldrb	w0, [x21]
    a810:	340000e0 	cbz	w0, a82c <fwp_main_thread+0x107c>
    a814:	7100041f 	cmp	w0, #0x1
    a818:	540030c0 	b.eq	ae30 <fwp_main_thread+0x1680>  // b.none
    a81c:	7103fc1f 	cmp	w0, #0xff
    a820:	54002d20 	b.eq	adc4 <fwp_main_thread+0x1614>  // b.none
    a824:	51000400 	sub	w0, w0, #0x1
    a828:	390002a0 	strb	w0, [x21]
    a82c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a830:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a834:	f95f5400 	ldr	x0, [x0, #16040]
    a838:	f9400800 	ldr	x0, [x0, #16]
    a83c:	f91f5420 	str	x0, [x1, #16040]
    a840:	b4002960 	cbz	x0, ad6c <fwp_main_thread+0x15bc>
    a844:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a848:	91174000 	add	x0, x0, #0x5d0
    a84c:	f949d801 	ldr	x1, [x0, #5040]
    a850:	f949ec02 	ldr	x2, [x0, #5080]
    a854:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a858:	f95f5c00 	ldr	x0, [x0, #16056]
    a85c:	d370bc42 	lsl	x2, x2, #16
    a860:	cb010001 	sub	x1, x0, x1
    a864:	17fffdb6 	b	9f3c <fwp_main_thread+0x78c>
    a868:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a86c:	2a1903e2 	mov	w2, w25
    a870:	aa1403e4 	mov	x4, x20
    a874:	f95f681b 	ldr	x27, [x0, #16080]
    a878:	b97ed816 	ldr	w22, [x0, #16088]
    a87c:	b97ee019 	ldr	w25, [x0, #16096]
    a880:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a884:	9117400a 	add	x10, x0, #0x5d0
    a888:	11000440 	add	w0, w2, #0x1
    a88c:	f120001f 	cmp	x0, #0x800
    a890:	d37df000 	lsl	x0, x0, #3
    a894:	b953a541 	ldr	w1, [x10, #5028]
    a898:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a89c:	54001940 	b.eq	abc4 <fwp_main_thread+0x1414>  // b.none
    a8a0:	91003c01 	add	x1, x0, #0xf
    a8a4:	8b411141 	add	x1, x10, x1, lsr #4
    a8a8:	397e8021 	ldrb	w1, [x1, #4000]
    a8ac:	910f002b 	add	x11, x1, #0x3c0
    a8b0:	8b010428 	add	x8, x1, x1, lsl #1
    a8b4:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a8b8:	8b080d4c 	add	x12, x10, x8, lsl #3
    a8bc:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a8c0:	2a0b03e1 	mov	w1, w11
    a8c4:	b40016f3 	cbz	x19, aba0 <fwp_main_thread+0x13f0>
    a8c8:	f940026c 	ldr	x12, [x19]
    a8cc:	aa2c03ec 	mvn	x12, x12
    a8d0:	f828794c 	str	x12, [x10, x8, lsl #3]
    a8d4:	eb01001f 	cmp	x0, x1
    a8d8:	540000c2 	b.cs	a8f0 <fwp_main_thread+0x1140>  // b.hs, b.nlast
    a8dc:	d503201f 	nop
    a8e0:	f8206a7f 	str	xzr, [x19, x0]
    a8e4:	91002000 	add	x0, x0, #0x8
    a8e8:	eb00003f 	cmp	x1, x0
    a8ec:	54ffffa8 	b.hi	a8e0 <fwp_main_thread+0x1130>  // b.pmore
    a8f0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a8f4:	91174008 	add	x8, x0, #0x5d0
    a8f8:	f94a1100 	ldr	x0, [x8, #5152]
    a8fc:	ab010000 	adds	x0, x0, x1
    a900:	540020c2 	b.cs	ad18 <fwp_main_thread+0x1568>  // b.hs, b.nlast
    a904:	f94a1501 	ldr	x1, [x8, #5160]
    a908:	f90a1100 	str	x0, [x8, #5152]
    a90c:	eb01001f 	cmp	x0, x1
    a910:	54000049 	b.ls	a918 <fwp_main_thread+0x1168>  // b.plast
    a914:	f90a1500 	str	x0, [x8, #5160]
    a918:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a91c:	91174000 	add	x0, x0, #0x5d0
    a920:	1e630161 	ucvtf	d1, w11
    a924:	fd4a1c00 	ldr	d0, [x0, #5176]
    a928:	1e612800 	fadd	d0, d0, d1
    a92c:	fd0a1c00 	str	d0, [x0, #5176]
    a930:	b94000e0 	ldr	w0, [x7]
    a934:	29000a60 	stp	w0, w2, [x19]
    a938:	340001a9 	cbz	w9, a96c <fwp_main_thread+0x11bc>
    a93c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a940:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a944:	910020e1 	add	x1, x7, #0x8
    a948:	f91f6c04 	str	x4, [x0, #16088]
    a94c:	b93ee009 	str	w9, [x0, #16096]
    a950:	f91f7c07 	str	x7, [x0, #16120]
    a954:	91002260 	add	x0, x19, #0x8
    a958:	97ffdf66 	bl	26f0 <memmove@plt>
    a95c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a960:	f95f6c04 	ldr	x4, [x0, #16088]
    a964:	f95f7c07 	ldr	x7, [x0, #16120]
    a968:	b97ee009 	ldr	w9, [x0, #16096]
    a96c:	2a1703e8 	mov	w8, w23
    a970:	d2800001 	mov	x1, #0x0                   	// #0
    a974:	34000117 	cbz	w23, a994 <fwp_main_thread+0x11e4>
    a978:	0b010120 	add	w0, w9, w1
    a97c:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    a980:	8b000e60 	add	x0, x19, x0, lsl #3
    a984:	91000421 	add	x1, x1, #0x1
    a988:	f9000402 	str	x2, [x0, #8]
    a98c:	eb08003f 	cmp	x1, x8
    a990:	54ffff41 	b.ne	a978 <fwp_main_thread+0x11c8>  // b.any
    a994:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a998:	91174002 	add	x2, x0, #0x5d0
    a99c:	f949d840 	ldr	x0, [x2, #5040]
    a9a0:	f949ec41 	ldr	x1, [x2, #5080]
    a9a4:	cb000300 	sub	x0, x24, x0
    a9a8:	eb01401f 	cmp	x0, x1, lsl #16
    a9ac:	540002e2 	b.cs	aa08 <fwp_main_thread+0x1258>  // b.hs, b.nlast
    a9b0:	d350fc01 	lsr	x1, x0, #16
    a9b4:	f949fc48 	ldr	x8, [x2, #5112]
    a9b8:	8b010821 	add	x1, x1, x1, lsl #2
    a9bc:	d37df021 	lsl	x1, x1, #3
    a9c0:	8b010105 	add	x5, x8, x1
    a9c4:	f94010a2 	ldr	x2, [x5, #32]
    a9c8:	b4000202 	cbz	x2, aa08 <fwp_main_thread+0x1258>
    a9cc:	38616901 	ldrb	w1, [x8, x1]
    a9d0:	7100083f 	cmp	w1, #0x2
    a9d4:	54001140 	b.eq	abfc <fwp_main_thread+0x144c>  // b.none
    a9d8:	7100043f 	cmp	w1, #0x1
    a9dc:	54000161 	b.ne	aa08 <fwp_main_thread+0x1258>  // b.any
    a9e0:	294304a8 	ldp	w8, w1, [x5, #24]
    a9e4:	92403c00 	and	x0, x0, #0xffff
    a9e8:	9b087c00 	mul	x0, x0, x8
    a9ec:	d360fc00 	lsr	x0, x0, #32
    a9f0:	eb01001f 	cmp	x0, x1
    a9f4:	540000a2 	b.cs	aa08 <fwp_main_thread+0x1258>  // b.hs, b.nlast
    a9f8:	8b000042 	add	x2, x2, x0
    a9fc:	39400040 	ldrb	w0, [x2]
    aa00:	7100041f 	cmp	w0, #0x1
    aa04:	54000c40 	b.eq	ab8c <fwp_main_thread+0x13dc>  // b.none
    aa08:	f9400c82 	ldr	x2, [x4, #24]
    aa0c:	aa1803e0 	mov	x0, x24
    aa10:	52800021 	mov	w1, #0x1                   	// #1
    aa14:	f9400442 	ldr	x2, [x2, #8]
    aa18:	d63f0040 	blr	x2
    aa1c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    aa20:	91174002 	add	x2, x0, #0x5d0
    aa24:	f949d841 	ldr	x1, [x2, #5040]
    aa28:	f949ec40 	ldr	x0, [x2, #5080]
    aa2c:	cb010261 	sub	x1, x19, x1
    aa30:	eb00403f 	cmp	x1, x0, lsl #16
    aa34:	54000322 	b.cs	aa98 <fwp_main_thread+0x12e8>  // b.hs, b.nlast
    aa38:	d350fc20 	lsr	x0, x1, #16
    aa3c:	f949fc44 	ldr	x4, [x2, #5112]
    aa40:	8b000800 	add	x0, x0, x0, lsl #2
    aa44:	d37df002 	lsl	x2, x0, #3
    aa48:	8b020080 	add	x0, x4, x2
    aa4c:	f9401017 	ldr	x23, [x0, #32]
    aa50:	b4000257 	cbz	x23, aa98 <fwp_main_thread+0x12e8>
    aa54:	38626882 	ldrb	w2, [x4, x2]
    aa58:	7100085f 	cmp	w2, #0x2
    aa5c:	54000d60 	b.eq	ac08 <fwp_main_thread+0x1458>  // b.none
    aa60:	7100045f 	cmp	w2, #0x1
    aa64:	540001a1 	b.ne	aa98 <fwp_main_thread+0x12e8>  // b.any
    aa68:	29430002 	ldp	w2, w0, [x0, #24]
    aa6c:	92403c21 	and	x1, x1, #0xffff
    aa70:	9b027c21 	mul	x1, x1, x2
    aa74:	d360fc21 	lsr	x1, x1, #32
    aa78:	eb00003f 	cmp	x1, x0
    aa7c:	540000e2 	b.cs	aa98 <fwp_main_thread+0x12e8>  // b.hs, b.nlast
    aa80:	8b0102f7 	add	x23, x23, x1
    aa84:	394002e0 	ldrb	w0, [x23]
    aa88:	7103fc1f 	cmp	w0, #0xff
    aa8c:	54000c80 	b.eq	ac1c <fwp_main_thread+0x146c>  // b.none
    aa90:	52800020 	mov	w0, #0x1                   	// #1
    aa94:	390002e0 	strb	w0, [x23]
    aa98:	aa1803e0 	mov	x0, x24
    aa9c:	aa1303f8 	mov	x24, x19
    aaa0:	97ffec64 	bl	5c30 <fwp_closure_drop>
    aaa4:	17fffebd 	b	a598 <fwp_main_thread+0xde8>
    aaa8:	b8616860 	ldr	w0, [x3, x1]
    aaac:	b9400481 	ldr	w1, [x4, #4]
    aab0:	4b010003 	sub	w3, w0, w1
    aab4:	7100047f 	cmp	w3, #0x1
    aab8:	54ffa9a1 	b.ne	9fec <fwp_main_thread+0x83c>  // b.any
    aabc:	910003f4 	mov	x20, sp
    aac0:	34000c41 	cbz	w1, ac48 <fwp_main_thread+0x1498>
    aac4:	7100001f 	cmp	w0, #0x0
    aac8:	d37d7c00 	ubfiz	x0, x0, #3, #32
    aacc:	d2800102 	mov	x2, #0x8                   	// #8
    aad0:	9a82101a 	csel	x26, x0, x2, ne	// ne = any
    aad4:	91003f40 	add	x0, x26, #0xf
    aad8:	92704c02 	and	x2, x0, #0xfffff0000
    aadc:	927c7c00 	and	x0, x0, #0xffffffff0
    aae0:	cb2263e2 	sub	x2, sp, x2
    aae4:	eb2263ff 	cmp	sp, x2
    aae8:	540000a0 	b.eq	aafc <fwp_main_thread+0x134c>  // b.none
    aaec:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    aaf0:	f90203ff 	str	xzr, [sp, #1024]
    aaf4:	eb2263ff 	cmp	sp, x2
    aaf8:	54ffffa1 	b.ne	aaec <fwp_main_thread+0x133c>  // b.any
    aafc:	92403c00 	and	x0, x0, #0xffff
    ab00:	cb2063ff 	sub	sp, sp, x0
    ab04:	f90003ff 	str	xzr, [sp]
    ab08:	f110001f 	cmp	x0, #0x400
    ab0c:	54000043 	b.cc	ab14 <fwp_main_thread+0x1364>  // b.lo, b.ul, b.last
    ab10:	f90203ff 	str	xzr, [sp, #1024]
    ab14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab18:	d37d7c3b 	ubfiz	x27, x1, #3, #32
    ab1c:	910043f5 	add	x21, sp, #0x10
    ab20:	aa1b03e2 	mov	x2, x27
    ab24:	aa1a03e3 	mov	x3, x26
    ab28:	f91f7806 	str	x6, [x0, #16112]
    ab2c:	f91f7c05 	str	x5, [x0, #16120]
    ab30:	f95f5000 	ldr	x0, [x0, #16032]
    ab34:	91004001 	add	x1, x0, #0x10
    ab38:	aa1503e0 	mov	x0, x21
    ab3c:	91012021 	add	x1, x1, #0x48
    ab40:	97ffdf24 	bl	27d0 <__memcpy_chk@plt>
    ab44:	eb1b035f 	cmp	x26, x27
    ab48:	aa1303e1 	mov	x1, x19
    ab4c:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    ab50:	d2800102 	mov	x2, #0x8                   	// #8
    ab54:	cb1b0063 	sub	x3, x3, x27
    ab58:	8b1b02a0 	add	x0, x21, x27
    ab5c:	97ffdf1d 	bl	27d0 <__memcpy_chk@plt>
    ab60:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ab64:	aa1503e0 	mov	x0, x21
    ab68:	f95f7c25 	ldr	x5, [x1, #16120]
    ab6c:	f9400ca1 	ldr	x1, [x5, #24]
    ab70:	f9400021 	ldr	x1, [x1]
    ab74:	d63f0020 	blr	x1
    ab78:	aa0003f8 	mov	x24, x0
    ab7c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab80:	f95f7806 	ldr	x6, [x0, #16112]
    ab84:	9100029f 	mov	sp, x20
    ab88:	17fffeb1 	b	a64c <fwp_main_thread+0xe9c>
    ab8c:	b90004ff 	str	wzr, [x7, #4]
    ab90:	17ffffa3 	b	aa1c <fwp_main_thread+0x126c>
    ab94:	72003c3f 	tst	w1, #0xffff
    ab98:	54ffa6a1 	b.ne	a06c <fwp_main_thread+0x8bc>  // b.any
    ab9c:	17fffd2e 	b	a054 <fwp_main_thread+0x8a4>
    aba0:	f9400593 	ldr	x19, [x12, #8]
    aba4:	b4000113 	cbz	x19, abc4 <fwp_main_thread+0x1414>
    aba8:	f9400988 	ldr	x8, [x12, #16]
    abac:	cb130108 	sub	x8, x8, x19
    abb0:	eb08003f 	cmp	x1, x8
    abb4:	54000088 	b.hi	abc4 <fwp_main_thread+0x1414>  // b.pmore
    abb8:	8b010268 	add	x8, x19, x1
    abbc:	f9000588 	str	x8, [x12, #8]
    abc0:	17ffff45 	b	a8d4 <fwp_main_thread+0x1124>
    abc4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    abc8:	f91f6824 	str	x4, [x1, #16080]
    abcc:	f91f6c27 	str	x7, [x1, #16088]
    abd0:	b93ee022 	str	w2, [x1, #16096]
    abd4:	b93ef829 	str	w9, [x1, #16120]
    abd8:	52800001 	mov	w1, #0x0                   	// #0
    abdc:	97ffe8c5 	bl	4ef0 <fwp_heap_alloc>
    abe0:	aa0003f3 	mov	x19, x0
    abe4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abe8:	f95f6804 	ldr	x4, [x0, #16080]
    abec:	f95f6c07 	ldr	x7, [x0, #16088]
    abf0:	b97ee002 	ldr	w2, [x0, #16096]
    abf4:	b97ef809 	ldr	w9, [x0, #16120]
    abf8:	17ffff4e 	b	a930 <fwp_main_thread+0x1180>
    abfc:	72003c1f 	tst	w0, #0xffff
    ac00:	54fff041 	b.ne	aa08 <fwp_main_thread+0x1258>  // b.any
    ac04:	17ffff7e 	b	a9fc <fwp_main_thread+0x124c>
    ac08:	72003c3f 	tst	w1, #0xffff
    ac0c:	54fff461 	b.ne	aa98 <fwp_main_thread+0x12e8>  // b.any
    ac10:	394002e0 	ldrb	w0, [x23]
    ac14:	7103fc1f 	cmp	w0, #0xff
    ac18:	54fff3c1 	b.ne	aa90 <fwp_main_thread+0x12e0>  // b.any
    ac1c:	aa1703e0 	mov	x0, x23
    ac20:	97ffe6f4 	bl	47f0 <fwp_rc_forget_slot>
    ac24:	17ffff9b 	b	aa90 <fwp_main_thread+0x12e0>
    ac28:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ac2c:	f91f7826 	str	x6, [x1, #16112]
    ac30:	f91f7c25 	str	x5, [x1, #16120]
    ac34:	97ffe6a8 	bl	46d4 <fwp_rc_wide_dup>
    ac38:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac3c:	f95f7806 	ldr	x6, [x0, #16112]
    ac40:	f95f7c05 	ldr	x5, [x0, #16120]
    ac44:	17fffd0a 	b	a06c <fwp_main_thread+0x8bc>
    ac48:	f9400041 	ldr	x1, [x2]
    ac4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac50:	f91f7c06 	str	x6, [x0, #16120]
    ac54:	aa1303e0 	mov	x0, x19
    ac58:	d63f0020 	blr	x1
    ac5c:	aa0003f8 	mov	x24, x0
    ac60:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac64:	f95f7c06 	ldr	x6, [x0, #16120]
    ac68:	9100029f 	mov	sp, x20
    ac6c:	17fffe78 	b	a64c <fwp_main_thread+0xe9c>
    ac70:	72003c3f 	tst	w1, #0xffff
    ac74:	54ff8941 	b.ne	9d9c <fwp_main_thread+0x5ec>  // b.any
    ac78:	17fffc44 	b	9d88 <fwp_main_thread+0x5d8>
    ac7c:	72003c3f 	tst	w1, #0xffff
    ac80:	54ff9421 	b.ne	9f04 <fwp_main_thread+0x754>  // b.any
    ac84:	17fffc95 	b	9ed8 <fwp_main_thread+0x728>
    ac88:	72003c3f 	tst	w1, #0xffff
    ac8c:	54ff8da1 	b.ne	9e40 <fwp_main_thread+0x690>  // b.any
    ac90:	17fffc67 	b	9e2c <fwp_main_thread+0x67c>
    ac94:	72003c3f 	tst	w1, #0xffff
    ac98:	54ff98c1 	b.ne	9fb0 <fwp_main_thread+0x800>  // b.any
    ac9c:	17fffcbf 	b	9f98 <fwp_main_thread+0x7e8>
    aca0:	aa0103e0 	mov	x0, x1
    aca4:	17fffb93 	b	9af0 <fwp_main_thread+0x340>
    aca8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acac:	f91f7c06 	str	x6, [x0, #16120]
    acb0:	aa1303e0 	mov	x0, x19
    acb4:	97ffe6cf 	bl	47f0 <fwp_rc_forget_slot>
    acb8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acbc:	f95f7c06 	ldr	x6, [x0, #16120]
    acc0:	17fffc35 	b	9d94 <fwp_main_thread+0x5e4>
    acc4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acc8:	f91f7c06 	str	x6, [x0, #16120]
    accc:	aa1303e0 	mov	x0, x19
    acd0:	97ffe6c8 	bl	47f0 <fwp_rc_forget_slot>
    acd4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acd8:	f95f7c06 	ldr	x6, [x0, #16120]
    acdc:	17fffc57 	b	9e38 <fwp_main_thread+0x688>
    ace0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ace4:	f91f7c06 	str	x6, [x0, #16120]
    ace8:	aa1303e0 	mov	x0, x19
    acec:	97ffe6c1 	bl	47f0 <fwp_rc_forget_slot>
    acf0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acf4:	f95f7c06 	ldr	x6, [x0, #16120]
    acf8:	17fffc7b 	b	9ee4 <fwp_main_thread+0x734>
    acfc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad00:	f91f7c26 	str	x6, [x1, #16120]
    ad04:	97ffe674 	bl	46d4 <fwp_rc_wide_dup>
    ad08:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad0c:	f95f7c06 	ldr	x6, [x0, #16120]
    ad10:	17fffca8 	b	9fb0 <fwp_main_thread+0x800>
    ad14:	97ffdedb 	bl	2880 <__stack_chk_fail@plt>
    ad18:	97ffe0c6 	bl	3030 <fwp_heap_oom>
    ad1c:	b0000000 	adrp	x0, b000 <__divti3+0x180>
    ad20:	912fe000 	add	x0, x0, #0xbf8
    ad24:	97ffe2b7 	bl	3800 <fwp_trap>
    ad28:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ad2c:	aa0603e0 	mov	x0, x6
    ad30:	aa1303fb 	mov	x27, x19
    ad34:	52800034 	mov	w20, #0x1                   	// #1
    ad38:	f91f7c26 	str	x6, [x1, #16120]
    ad3c:	97ffeaa1 	bl	57c0 <fwp_rc_share>
    ad40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad44:	f95f5c00 	ldr	x0, [x0, #16056]
    ad48:	97ffea9e 	bl	57c0 <fwp_rc_share>
    ad4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad50:	f95f7c06 	ldr	x6, [x0, #16120]
    ad54:	aa0603f8 	mov	x24, x6
    ad58:	17fffe34 	b	a628 <fwp_main_thread+0xe78>
    ad5c:	b0000000 	adrp	x0, b000 <__divti3+0x180>
    ad60:	91308000 	add	x0, x0, #0xc20
    ad64:	97ffe2a7 	bl	3800 <fwp_trap>
    ad68:	97ffe0f2 	bl	3130 <descent_phase_fail>
    ad6c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad70:	f95f4c06 	ldr	x6, [x0, #16024]
    ad74:	f91f7c06 	str	x6, [x0, #16120]
    ad78:	f95f5c16 	ldr	x22, [x0, #16056]
    ad7c:	aa1603e0 	mov	x0, x22
    ad80:	97ffeafd 	bl	5974 <fwp_drop0>
    ad84:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad88:	f95f7c06 	ldr	x6, [x0, #16120]
    ad8c:	aa0603e0 	mov	x0, x6
    ad90:	97ffeaf9 	bl	5974 <fwp_drop0>
    ad94:	d00000a0 	adrp	x0, 20000 <__data_start>
    ad98:	9101c000 	add	x0, x0, #0x70
    ad9c:	52800021 	mov	w1, #0x1                   	// #1
    ada0:	b9034c01 	str	w1, [x0, #844]
    ada4:	f901a81f 	str	xzr, [x0, #848]
    ada8:	17fffac8 	b	98c8 <fwp_main_thread+0x118>
    adac:	72003c3f 	tst	w1, #0xffff
    adb0:	54ffd3e1 	b.ne	a82c <fwp_main_thread+0x107c>  // b.any
    adb4:	17fffe96 	b	a80c <fwp_main_thread+0x105c>
    adb8:	72003c3f 	tst	w1, #0xffff
    adbc:	54ffcd21 	b.ne	a760 <fwp_main_thread+0xfb0>  // b.any
    adc0:	17fffe63 	b	a74c <fwp_main_thread+0xf9c>
    adc4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    adc8:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    adcc:	91174021 	add	x1, x1, #0x5d0
    add0:	ca402400 	eor	x0, x0, x0, lsr #9
    add4:	8b200c20 	add	x0, x1, w0, uxtb #3
    add8:	f94a2400 	ldr	x0, [x0, #5192]
    addc:	b5000080 	cbnz	x0, adec <fwp_main_thread+0x163c>
    ade0:	14000025 	b	ae74 <fwp_main_thread+0x16c4>
    ade4:	f9400800 	ldr	x0, [x0, #16]
    ade8:	b4000460 	cbz	x0, ae74 <fwp_main_thread+0x16c4>
    adec:	f9400001 	ldr	x1, [x0]
    adf0:	eb0102bf 	cmp	x21, x1
    adf4:	54ffff81 	b.ne	ade4 <fwp_main_thread+0x1634>  // b.any
    adf8:	f9400401 	ldr	x1, [x0, #8]
    adfc:	d1000421 	sub	x1, x1, #0x1
    ae00:	f9000401 	str	x1, [x0, #8]
    ae04:	f103f83f 	cmp	x1, #0xfe
    ae08:	54ffd121 	b.ne	a82c <fwp_main_thread+0x107c>  // b.any
    ae0c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae10:	f91f7c06 	str	x6, [x0, #16120]
    ae14:	aa1503e0 	mov	x0, x21
    ae18:	97ffe676 	bl	47f0 <fwp_rc_forget_slot>
    ae1c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    ae20:	390002a0 	strb	w0, [x21]
    ae24:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae28:	f95f7c06 	ldr	x6, [x0, #16120]
    ae2c:	17fffe80 	b	a82c <fwp_main_thread+0x107c>
    ae30:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae34:	f91f7c06 	str	x6, [x0, #16120]
    ae38:	aa1403e0 	mov	x0, x20
    ae3c:	97ffea86 	bl	5854 <fwp_rc_free_arr>
    ae40:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae44:	f95f7c06 	ldr	x6, [x0, #16120]
    ae48:	17fffe79 	b	a82c <fwp_main_thread+0x107c>
    ae4c:	b9035a9f 	str	wzr, [x20, #856]
    ae50:	b4ffa6c0 	cbz	x0, a328 <fwp_main_thread+0xb78>
    ae54:	97ffde9f 	bl	28d0 <abort@plt>
    ae58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae5c:	f91f7c06 	str	x6, [x0, #16120]
    ae60:	aa1a03e0 	mov	x0, x26
    ae64:	97ffe663 	bl	47f0 <fwp_rc_forget_slot>
    ae68:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae6c:	f95f7c06 	ldr	x6, [x0, #16120]
    ae70:	17fffe3a 	b	a758 <fwp_main_thread+0xfa8>
    ae74:	b0000000 	adrp	x0, b000 <__divti3+0x180>
    ae78:	91240000 	add	x0, x0, #0x900
    ae7c:	97ffe261 	bl	3800 <fwp_trap>

000000000000ae80 <__divti3>:
    ae80:	d503245f 	bti	c
    ae84:	d2800004 	mov	x4, #0x0                   	// #0
    ae88:	b7f80721 	tbnz	x1, #63, af6c <__divti3+0xec>
    ae8c:	b6f80083 	tbz	x3, #63, ae9c <__divti3+0x1c>
    ae90:	eb0203e2 	negs	x2, x2
    ae94:	aa2403e4 	mvn	x4, x4
    ae98:	da0303e3 	ngc	x3, x3
    ae9c:	aa0203e6 	mov	x6, x2
    aea0:	aa0003e7 	mov	x7, x0
    aea4:	aa0103e5 	mov	x5, x1
    aea8:	b5000583 	cbnz	x3, af58 <__divti3+0xd8>
    aeac:	eb01005f 	cmp	x2, x1
    aeb0:	54000e69 	b.ls	b07c <__divti3+0x1fc>  // b.plast
    aeb4:	dac01040 	clz	x0, x2
    aeb8:	b40000e0 	cbz	x0, aed4 <__divti3+0x54>
    aebc:	4b0003e1 	neg	w1, w0
    aec0:	9ac020a5 	lsl	x5, x5, x0
    aec4:	9ac02046 	lsl	x6, x2, x0
    aec8:	9ac124e1 	lsr	x1, x7, x1
    aecc:	aa050025 	orr	x5, x1, x5
    aed0:	9ac020e7 	lsl	x7, x7, x0
    aed4:	d360fcc8 	lsr	x8, x6, #32
    aed8:	92407cc2 	and	x2, x6, #0xffffffff
    aedc:	9ac808a3 	udiv	x3, x5, x8
    aee0:	9b089465 	msub	x5, x3, x8, x5
    aee4:	aa0303e0 	mov	x0, x3
    aee8:	9b037c41 	mul	x1, x2, x3
    aeec:	93c780a5 	extr	x5, x5, x7, #32
    aef0:	eb05003f 	cmp	x1, x5
    aef4:	540000a9 	b.ls	af08 <__divti3+0x88>  // b.plast
    aef8:	ab0500c5 	adds	x5, x6, x5
    aefc:	d1000460 	sub	x0, x3, #0x1
    af00:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    af04:	540015a8 	b.hi	b1b8 <__divti3+0x338>  // b.pmore
    af08:	cb0100a5 	sub	x5, x5, x1
    af0c:	9ac808a3 	udiv	x3, x5, x8
    af10:	9b089465 	msub	x5, x3, x8, x5
    af14:	aa0303e1 	mov	x1, x3
    af18:	9b037c42 	mul	x2, x2, x3
    af1c:	aa0703e3 	mov	x3, x7
    af20:	b3607ca3 	bfi	x3, x5, #32, #32
    af24:	eb03005f 	cmp	x2, x3
    af28:	540000c9 	b.ls	af40 <__divti3+0xc0>  // b.plast
    af2c:	ab0300c3 	adds	x3, x6, x3
    af30:	d1000425 	sub	x5, x1, #0x1
    af34:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    af38:	d1000821 	sub	x1, x1, #0x2
    af3c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    af40:	aa008020 	orr	x0, x1, x0, lsl #32
    af44:	d2800001 	mov	x1, #0x0                   	// #0
    af48:	b4000064 	cbz	x4, af54 <__divti3+0xd4>
    af4c:	eb0003e0 	negs	x0, x0
    af50:	da0103e1 	ngc	x1, x1
    af54:	d65f03c0 	ret
    af58:	eb01007f 	cmp	x3, x1
    af5c:	54000109 	b.ls	af7c <__divti3+0xfc>  // b.plast
    af60:	d2800001 	mov	x1, #0x0                   	// #0
    af64:	d2800000 	mov	x0, #0x0                   	// #0
    af68:	17fffff8 	b	af48 <__divti3+0xc8>
    af6c:	eb0003e0 	negs	x0, x0
    af70:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    af74:	da0103e1 	ngc	x1, x1
    af78:	17ffffc5 	b	ae8c <__divti3+0xc>
    af7c:	dac01067 	clz	x7, x3
    af80:	b40010e7 	cbz	x7, b19c <__divti3+0x31c>
    af84:	d2800805 	mov	x5, #0x40                  	// #64
    af88:	cb0700a5 	sub	x5, x5, x7
    af8c:	9ac72063 	lsl	x3, x3, x7
    af90:	9ac52448 	lsr	x8, x2, x5
    af94:	aa030108 	orr	x8, x8, x3
    af98:	9ac52426 	lsr	x6, x1, x5
    af9c:	92407d0a 	and	x10, x8, #0xffffffff
    afa0:	d360fd09 	lsr	x9, x8, #32
    afa4:	9ac52403 	lsr	x3, x0, x5
    afa8:	9ac72021 	lsl	x1, x1, x7
    afac:	aa010063 	orr	x3, x3, x1
    afb0:	9ac72042 	lsl	x2, x2, x7
    afb4:	9ac908cb 	udiv	x11, x6, x9
    afb8:	9b099965 	msub	x5, x11, x9, x6
    afbc:	aa0b03e1 	mov	x1, x11
    afc0:	9b0b7d46 	mul	x6, x10, x11
    afc4:	93c380a5 	extr	x5, x5, x3, #32
    afc8:	eb0500df 	cmp	x6, x5
    afcc:	540000a9 	b.ls	afe0 <__divti3+0x160>  // b.plast
    afd0:	ab050105 	adds	x5, x8, x5
    afd4:	d1000561 	sub	x1, x11, #0x1
    afd8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    afdc:	54000f48 	b.hi	b1c4 <__divti3+0x344>  // b.pmore
    afe0:	cb0600a6 	sub	x6, x5, x6
    afe4:	9ac908cb 	udiv	x11, x6, x9
    afe8:	9b099969 	msub	x9, x11, x9, x6
    afec:	aa0b03e5 	mov	x5, x11
    aff0:	9b0b7d4a 	mul	x10, x10, x11
    aff4:	b3607d23 	bfi	x3, x9, #32, #32
    aff8:	eb03015f 	cmp	x10, x3
    affc:	540000a9 	b.ls	b010 <__divti3+0x190>  // b.plast
    b000:	ab030103 	adds	x3, x8, x3
    b004:	d1000565 	sub	x5, x11, #0x1
    b008:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b00c:	54000e28 	b.hi	b1d0 <__divti3+0x350>  // b.pmore
    b010:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b014:	92407c48 	and	x8, x2, #0xffffffff
    b018:	2a0503e5 	mov	w5, w5
    b01c:	d360fc42 	lsr	x2, x2, #32
    b020:	d360fc26 	lsr	x6, x1, #32
    b024:	cb0a0063 	sub	x3, x3, x10
    b028:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b02c:	9b087caa 	mul	x10, x5, x8
    b030:	9b087cc8 	mul	x8, x6, x8
    b034:	9b0220a5 	madd	x5, x5, x2, x8
    b038:	9b027cc6 	mul	x6, x6, x2
    b03c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b040:	8b0900c5 	add	x5, x6, x9
    b044:	eb02011f 	cmp	x8, x2
    b048:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b04c:	8b4280c6 	add	x6, x6, x2, lsr #32
    b050:	eb06007f 	cmp	x3, x6
    b054:	540000e3 	b.cc	b070 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b058:	92407d4a 	and	x10, x10, #0xffffffff
    b05c:	9ac72000 	lsl	x0, x0, x7
    b060:	8b028142 	add	x2, x10, x2, lsl #32
    b064:	eb02001f 	cmp	x0, x2
    b068:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b06c:	54000a01 	b.ne	b1ac <__divti3+0x32c>  // b.any
    b070:	d1000420 	sub	x0, x1, #0x1
    b074:	d2800001 	mov	x1, #0x0                   	// #0
    b078:	17ffffb4 	b	af48 <__divti3+0xc8>
    b07c:	b5000062 	cbnz	x2, b088 <__divti3+0x208>
    b080:	d2800022 	mov	x2, #0x1                   	// #1
    b084:	9ac30846 	udiv	x6, x2, x3
    b088:	dac010c8 	clz	x8, x6
    b08c:	b5000408 	cbnz	x8, b10c <__divti3+0x28c>
    b090:	d360fcc9 	lsr	x9, x6, #32
    b094:	92407cc5 	and	x5, x6, #0xffffffff
    b098:	cb060023 	sub	x3, x1, x6
    b09c:	d2800021 	mov	x1, #0x1                   	// #1
    b0a0:	9ac90868 	udiv	x8, x3, x9
    b0a4:	9b098d03 	msub	x3, x8, x9, x3
    b0a8:	aa0803e0 	mov	x0, x8
    b0ac:	9b057d02 	mul	x2, x8, x5
    b0b0:	93c78063 	extr	x3, x3, x7, #32
    b0b4:	eb03005f 	cmp	x2, x3
    b0b8:	540000a9 	b.ls	b0cc <__divti3+0x24c>  // b.plast
    b0bc:	ab0300c3 	adds	x3, x6, x3
    b0c0:	d1000500 	sub	x0, x8, #0x1
    b0c4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b0c8:	54000968 	b.hi	b1f4 <__divti3+0x374>  // b.pmore
    b0cc:	cb020063 	sub	x3, x3, x2
    b0d0:	9ac90862 	udiv	x2, x3, x9
    b0d4:	aa0203e8 	mov	x8, x2
    b0d8:	9b098c42 	msub	x2, x2, x9, x3
    b0dc:	aa0703e3 	mov	x3, x7
    b0e0:	9b057d05 	mul	x5, x8, x5
    b0e4:	b3607c43 	bfi	x3, x2, #32, #32
    b0e8:	eb0300bf 	cmp	x5, x3
    b0ec:	540000c9 	b.ls	b104 <__divti3+0x284>  // b.plast
    b0f0:	ab0300c2 	adds	x2, x6, x3
    b0f4:	d1000503 	sub	x3, x8, #0x1
    b0f8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b0fc:	d1000908 	sub	x8, x8, #0x2
    b100:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b104:	aa008100 	orr	x0, x8, x0, lsl #32
    b108:	17ffff90 	b	af48 <__divti3+0xc8>
    b10c:	9ac820c6 	lsl	x6, x6, x8
    b110:	d2800803 	mov	x3, #0x40                  	// #64
    b114:	cb080063 	sub	x3, x3, x8
    b118:	d360fcc9 	lsr	x9, x6, #32
    b11c:	9ac82027 	lsl	x7, x1, x8
    b120:	92407cc5 	and	x5, x6, #0xffffffff
    b124:	9ac32422 	lsr	x2, x1, x3
    b128:	9ac32403 	lsr	x3, x0, x3
    b12c:	aa070063 	orr	x3, x3, x7
    b130:	9ac9084a 	udiv	x10, x2, x9
    b134:	9ac82007 	lsl	x7, x0, x8
    b138:	9b098940 	msub	x0, x10, x9, x2
    b13c:	aa0a03e1 	mov	x1, x10
    b140:	9b0a7ca2 	mul	x2, x5, x10
    b144:	93c38000 	extr	x0, x0, x3, #32
    b148:	eb00005f 	cmp	x2, x0
    b14c:	540000a9 	b.ls	b160 <__divti3+0x2e0>  // b.plast
    b150:	ab0000c0 	adds	x0, x6, x0
    b154:	d1000541 	sub	x1, x10, #0x1
    b158:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b15c:	54000468 	b.hi	b1e8 <__divti3+0x368>  // b.pmore
    b160:	cb020000 	sub	x0, x0, x2
    b164:	9ac9080a 	udiv	x10, x0, x9
    b168:	9b098140 	msub	x0, x10, x9, x0
    b16c:	aa0a03e2 	mov	x2, x10
    b170:	9b0a7ca8 	mul	x8, x5, x10
    b174:	b3607c03 	bfi	x3, x0, #32, #32
    b178:	eb03011f 	cmp	x8, x3
    b17c:	540000a9 	b.ls	b190 <__divti3+0x310>  // b.plast
    b180:	ab0300c3 	adds	x3, x6, x3
    b184:	d1000542 	sub	x2, x10, #0x1
    b188:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b18c:	54000288 	b.hi	b1dc <__divti3+0x35c>  // b.pmore
    b190:	cb080063 	sub	x3, x3, x8
    b194:	aa018041 	orr	x1, x2, x1, lsl #32
    b198:	17ffffc2 	b	b0a0 <__divti3+0x220>
    b19c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b1a0:	d2800001 	mov	x1, #0x0                   	// #0
    b1a4:	9a9f87e0 	cset	x0, ls	// ls = plast
    b1a8:	17ffff68 	b	af48 <__divti3+0xc8>
    b1ac:	aa0103e0 	mov	x0, x1
    b1b0:	d2800001 	mov	x1, #0x0                   	// #0
    b1b4:	17ffff65 	b	af48 <__divti3+0xc8>
    b1b8:	d1000860 	sub	x0, x3, #0x2
    b1bc:	8b0600a5 	add	x5, x5, x6
    b1c0:	17ffff52 	b	af08 <__divti3+0x88>
    b1c4:	d1000961 	sub	x1, x11, #0x2
    b1c8:	8b0800a5 	add	x5, x5, x8
    b1cc:	17ffff85 	b	afe0 <__divti3+0x160>
    b1d0:	d1000965 	sub	x5, x11, #0x2
    b1d4:	8b080063 	add	x3, x3, x8
    b1d8:	17ffff8e 	b	b010 <__divti3+0x190>
    b1dc:	d1000942 	sub	x2, x10, #0x2
    b1e0:	8b060063 	add	x3, x3, x6
    b1e4:	17ffffeb 	b	b190 <__divti3+0x310>
    b1e8:	d1000941 	sub	x1, x10, #0x2
    b1ec:	8b060000 	add	x0, x0, x6
    b1f0:	17ffffdc 	b	b160 <__divti3+0x2e0>
    b1f4:	d1000900 	sub	x0, x8, #0x2
    b1f8:	8b060063 	add	x3, x3, x6
    b1fc:	17ffffb4 	b	b0cc <__divti3+0x24c>

000000000000b200 <__modti3>:
    b200:	d503245f 	bti	c
    b204:	d2800004 	mov	x4, #0x0                   	// #0
    b208:	b6f80081 	tbz	x1, #63, b218 <__modti3+0x18>
    b20c:	eb0003e0 	negs	x0, x0
    b210:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b214:	da0103e1 	ngc	x1, x1
    b218:	f100007f 	cmp	x3, #0x0
    b21c:	5400128b 	b.lt	b46c <__modti3+0x26c>  // b.tstop
    b220:	aa0003e7 	mov	x7, x0
    b224:	aa0103e6 	mov	x6, x1
    b228:	540004e1 	b.ne	b2c4 <__modti3+0xc4>  // b.any
    b22c:	eb02003f 	cmp	x1, x2
    b230:	54000dc2 	b.cs	b3e8 <__modti3+0x1e8>  // b.hs, b.nlast
    b234:	dac01043 	clz	x3, x2
    b238:	aa0303e5 	mov	x5, x3
    b23c:	b40000e3 	cbz	x3, b258 <__modti3+0x58>
    b240:	4b0303e6 	neg	w6, w3
    b244:	9ac32021 	lsl	x1, x1, x3
    b248:	9ac32042 	lsl	x2, x2, x3
    b24c:	9ac62406 	lsr	x6, x0, x6
    b250:	aa0100c6 	orr	x6, x6, x1
    b254:	9ac32007 	lsl	x7, x0, x3
    b258:	d360fc40 	lsr	x0, x2, #32
    b25c:	92407c43 	and	x3, x2, #0xffffffff
    b260:	9ac008c1 	udiv	x1, x6, x0
    b264:	9b009826 	msub	x6, x1, x0, x6
    b268:	9b017c61 	mul	x1, x3, x1
    b26c:	93c780c6 	extr	x6, x6, x7, #32
    b270:	eb06003f 	cmp	x1, x6
    b274:	540000a9 	b.ls	b288 <__modti3+0x88>  // b.plast
    b278:	ab060046 	adds	x6, x2, x6
    b27c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b280:	8b0200c8 	add	x8, x6, x2
    b284:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b288:	cb0100c6 	sub	x6, x6, x1
    b28c:	9ac008c8 	udiv	x8, x6, x0
    b290:	9b009901 	msub	x1, x8, x0, x6
    b294:	aa0703e0 	mov	x0, x7
    b298:	9b087c63 	mul	x3, x3, x8
    b29c:	b3607c20 	bfi	x0, x1, #32, #32
    b2a0:	eb00007f 	cmp	x3, x0
    b2a4:	54001088 	b.hi	b4b4 <__modti3+0x2b4>  // b.pmore
    b2a8:	cb030000 	sub	x0, x0, x3
    b2ac:	9ac52400 	lsr	x0, x0, x5
    b2b0:	d2800001 	mov	x1, #0x0                   	// #0
    b2b4:	b4000064 	cbz	x4, b2c0 <__modti3+0xc0>
    b2b8:	eb0003e0 	negs	x0, x0
    b2bc:	da0103e1 	ngc	x1, x1
    b2c0:	d65f03c0 	ret
    b2c4:	dac01066 	clz	x6, x3
    b2c8:	eb03003f 	cmp	x1, x3
    b2cc:	54ffff43 	b.cc	b2b4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b2d0:	93407cc5 	sxtw	x5, w6
    b2d4:	d2800808 	mov	x8, #0x40                  	// #64
    b2d8:	cb050108 	sub	x8, x8, x5
    b2dc:	9ac62063 	lsl	x3, x3, x6
    b2e0:	9ac62025 	lsl	x5, x1, x6
    b2e4:	9ac82447 	lsr	x7, x2, x8
    b2e8:	aa0300e7 	orr	x7, x7, x3
    b2ec:	9ac82423 	lsr	x3, x1, x8
    b2f0:	92407cec 	and	x12, x7, #0xffffffff
    b2f4:	d360fcea 	lsr	x10, x7, #32
    b2f8:	9ac82401 	lsr	x1, x0, x8
    b2fc:	aa050021 	orr	x1, x1, x5
    b300:	9ac62042 	lsl	x2, x2, x6
    b304:	9ac62000 	lsl	x0, x0, x6
    b308:	9aca086b 	udiv	x11, x3, x10
    b30c:	9b0a8d63 	msub	x3, x11, x10, x3
    b310:	aa0b03e5 	mov	x5, x11
    b314:	9b0b7d89 	mul	x9, x12, x11
    b318:	93c18063 	extr	x3, x3, x1, #32
    b31c:	eb03013f 	cmp	x9, x3
    b320:	540000a9 	b.ls	b334 <__modti3+0x134>  // b.plast
    b324:	ab0300e3 	adds	x3, x7, x3
    b328:	d1000565 	sub	x5, x11, #0x1
    b32c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b330:	54001168 	b.hi	b55c <__modti3+0x35c>  // b.pmore
    b334:	cb090063 	sub	x3, x3, x9
    b338:	9aca086b 	udiv	x11, x3, x10
    b33c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b340:	aa0b03e9 	mov	x9, x11
    b344:	9b0b7d8c 	mul	x12, x12, x11
    b348:	b3607d41 	bfi	x1, x10, #32, #32
    b34c:	eb01019f 	cmp	x12, x1
    b350:	540000a9 	b.ls	b364 <__modti3+0x164>  // b.plast
    b354:	ab0100e1 	adds	x1, x7, x1
    b358:	d1000569 	sub	x9, x11, #0x1
    b35c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b360:	54000f88 	b.hi	b550 <__modti3+0x350>  // b.pmore
    b364:	aa058123 	orr	x3, x9, x5, lsl #32
    b368:	92407c4b 	and	x11, x2, #0xffffffff
    b36c:	2a0903e9 	mov	w9, w9
    b370:	d360fc4a 	lsr	x10, x2, #32
    b374:	d360fc63 	lsr	x3, x3, #32
    b378:	cb0c0021 	sub	x1, x1, x12
    b37c:	aa0a03ec 	mov	x12, x10
    b380:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b384:	9b0b7d25 	mul	x5, x9, x11
    b388:	9b0b7c6b 	mul	x11, x3, x11
    b38c:	9b0a2d29 	madd	x9, x9, x10, x11
    b390:	92407caa 	and	x10, x5, #0xffffffff
    b394:	9b0c7c63 	mul	x3, x3, x12
    b398:	8b458125 	add	x5, x9, x5, lsr #32
    b39c:	8b0d0069 	add	x9, x3, x13
    b3a0:	eb05017f 	cmp	x11, x5
    b3a4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b3a8:	8b058149 	add	x9, x10, x5, lsl #32
    b3ac:	8b458063 	add	x3, x3, x5, lsr #32
    b3b0:	eb03003f 	cmp	x1, x3
    b3b4:	54000063 	b.cc	b3c0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b3b8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b3bc:	54000082 	b.cs	b3cc <__modti3+0x1cc>  // b.hs, b.nlast
    b3c0:	eb020129 	subs	x9, x9, x2
    b3c4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b3c8:	cb070063 	sub	x3, x3, x7
    b3cc:	eb090000 	subs	x0, x0, x9
    b3d0:	da030021 	sbc	x1, x1, x3
    b3d4:	9ac62400 	lsr	x0, x0, x6
    b3d8:	9ac82028 	lsl	x8, x1, x8
    b3dc:	aa000100 	orr	x0, x8, x0
    b3e0:	9ac62421 	lsr	x1, x1, x6
    b3e4:	17ffffb4 	b	b2b4 <__modti3+0xb4>
    b3e8:	b5000062 	cbnz	x2, b3f4 <__modti3+0x1f4>
    b3ec:	d2800023 	mov	x3, #0x1                   	// #1
    b3f0:	9ac20862 	udiv	x2, x3, x2
    b3f4:	dac01048 	clz	x8, x2
    b3f8:	aa0803e5 	mov	x5, x8
    b3fc:	b5000668 	cbnz	x8, b4c8 <__modti3+0x2c8>
    b400:	cb020020 	sub	x0, x1, x2
    b404:	d360fc49 	lsr	x9, x2, #32
    b408:	92407c4a 	and	x10, x2, #0xffffffff
    b40c:	9ac90801 	udiv	x1, x0, x9
    b410:	9b098020 	msub	x0, x1, x9, x0
    b414:	9b0a7c21 	mul	x1, x1, x10
    b418:	93c78000 	extr	x0, x0, x7, #32
    b41c:	eb00003f 	cmp	x1, x0
    b420:	540000a9 	b.ls	b434 <__modti3+0x234>  // b.plast
    b424:	ab000040 	adds	x0, x2, x0
    b428:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b42c:	8b020003 	add	x3, x0, x2
    b430:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b434:	cb010001 	sub	x1, x0, x1
    b438:	9ac90820 	udiv	x0, x1, x9
    b43c:	9b098403 	msub	x3, x0, x9, x1
    b440:	aa0703e1 	mov	x1, x7
    b444:	9b0a7c00 	mul	x0, x0, x10
    b448:	b3607c61 	bfi	x1, x3, #32, #32
    b44c:	eb01001f 	cmp	x0, x1
    b450:	540000a9 	b.ls	b464 <__modti3+0x264>  // b.plast
    b454:	ab010041 	adds	x1, x2, x1
    b458:	8b020022 	add	x2, x1, x2
    b45c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b460:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b464:	cb000020 	sub	x0, x1, x0
    b468:	17ffff91 	b	b2ac <__modti3+0xac>
    b46c:	eb0203e5 	negs	x5, x2
    b470:	aa0003e7 	mov	x7, x0
    b474:	da0303e8 	ngc	x8, x3
    b478:	aa0503e2 	mov	x2, x5
    b47c:	aa0803e3 	mov	x3, x8
    b480:	aa0103e6 	mov	x6, x1
    b484:	b4ffed48 	cbz	x8, b22c <__modti3+0x2c>
    b488:	eb01011f 	cmp	x8, x1
    b48c:	54fff148 	b.hi	b2b4 <__modti3+0xb4>  // b.pmore
    b490:	dac01109 	clz	x9, x8
    b494:	2a0903e6 	mov	w6, w9
    b498:	b5fff1c9 	cbnz	x9, b2d0 <__modti3+0xd0>
    b49c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b4a0:	54000068 	b.hi	b4ac <__modti3+0x2ac>  // b.pmore
    b4a4:	eb050007 	subs	x7, x0, x5
    b4a8:	da080021 	sbc	x1, x1, x8
    b4ac:	aa0703e0 	mov	x0, x7
    b4b0:	17ffff81 	b	b2b4 <__modti3+0xb4>
    b4b4:	ab000040 	adds	x0, x2, x0
    b4b8:	8b020002 	add	x2, x0, x2
    b4bc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b4c0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b4c4:	17ffff79 	b	b2a8 <__modti3+0xa8>
    b4c8:	9ac82042 	lsl	x2, x2, x8
    b4cc:	d2800803 	mov	x3, #0x40                  	// #64
    b4d0:	cb080063 	sub	x3, x3, x8
    b4d4:	d360fc49 	lsr	x9, x2, #32
    b4d8:	9ac82027 	lsl	x7, x1, x8
    b4dc:	92407c4a 	and	x10, x2, #0xffffffff
    b4e0:	9ac32426 	lsr	x6, x1, x3
    b4e4:	9ac32403 	lsr	x3, x0, x3
    b4e8:	aa070063 	orr	x3, x3, x7
    b4ec:	9ac908c1 	udiv	x1, x6, x9
    b4f0:	9ac82007 	lsl	x7, x0, x8
    b4f4:	9b099820 	msub	x0, x1, x9, x6
    b4f8:	9b017d41 	mul	x1, x10, x1
    b4fc:	93c38000 	extr	x0, x0, x3, #32
    b500:	eb00003f 	cmp	x1, x0
    b504:	540000a9 	b.ls	b518 <__modti3+0x318>  // b.plast
    b508:	ab000040 	adds	x0, x2, x0
    b50c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b510:	8b020006 	add	x6, x0, x2
    b514:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b518:	cb010000 	sub	x0, x0, x1
    b51c:	9ac90801 	udiv	x1, x0, x9
    b520:	9b098026 	msub	x6, x1, x9, x0
    b524:	aa0303e0 	mov	x0, x3
    b528:	9b017d41 	mul	x1, x10, x1
    b52c:	b3607cc0 	bfi	x0, x6, #32, #32
    b530:	eb00003f 	cmp	x1, x0
    b534:	540000a9 	b.ls	b548 <__modti3+0x348>  // b.plast
    b538:	ab000040 	adds	x0, x2, x0
    b53c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b540:	8b020003 	add	x3, x0, x2
    b544:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b548:	cb010000 	sub	x0, x0, x1
    b54c:	17ffffb0 	b	b40c <__modti3+0x20c>
    b550:	d1000969 	sub	x9, x11, #0x2
    b554:	8b070021 	add	x1, x1, x7
    b558:	17ffff83 	b	b364 <__modti3+0x164>
    b55c:	d1000965 	sub	x5, x11, #0x2
    b560:	8b070063 	add	x3, x3, x7
    b564:	17ffff74 	b	b334 <__modti3+0x134>
    b568:	d503201f 	nop
    b56c:	d503201f 	nop

000000000000b570 <atexit>:
    b570:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b574:	b00000a2 	adrp	x2, 20000 <__data_start>
    b578:	d2800001 	mov	x1, #0x0                   	// #0
    b57c:	910003fd 	mov	x29, sp
    b580:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b584:	f9400442 	ldr	x2, [x2, #8]
    b588:	17ffdc7e 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b58c <_fini>:
    b58c:	d503201f 	nop
    b590:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b594:	910003fd 	mov	x29, sp
    b598:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b59c:	d65f03c0 	ret
