
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-identical:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	90000045 	adrp	x5, a000 <fwp_main_thread+0x2190>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912740a5 	add	x5, x5, #0x9d0
    2aa0:	90000044 	adrp	x4, a000 <fwp_main_thread+0x2190>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91276084 	add	x4, x4, #0x9d8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x118a0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	90000040 	adrp	x0, a000 <fwp_main_thread+0x2190>
    2b34:	9136c000 	add	x0, x0, #0xdb0
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000022 	adrp	x2, 7000 <fwp_write+0x17c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	9139c042 	add	x2, x2, #0xe70
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430a60 	ldr	w0, [x19, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	90000040 	adrp	x0, a000 <fwp_main_thread+0x2190>
    2c7c:	91370000 	add	x0, x0, #0xdc0
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	90000040 	adrp	x0, a000 <fwp_main_thread+0x2190>
    2c8c:	91398000 	add	x0, x0, #0xe60
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	90000040 	adrp	x0, a000 <fwp_main_thread+0x2190>
    2ca4:	9138e000 	add	x0, x0, #0xe38
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	90000040 	adrp	x0, a000 <fwp_main_thread+0x2190>
    2cb0:	91382000 	add	x0, x0, #0xe08
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	90000040 	adrp	x0, a000 <fwp_main_thread+0x2190>
    2cbc:	91378000 	add	x0, x0, #0xde0
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x830>
    2eb4:	91120021 	add	x1, x1, #0x480
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3050:	911f6000 	add	x0, x0, #0x7d8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x830>
    3118:	91118021 	add	x1, x1, #0x460
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    33f0:	911f6000 	add	x0, x0, #0x7d8
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2190>
    3530:	aa1303e0 	mov	x0, x19
    3534:	911fc021 	add	x1, x1, #0x7f0
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2190>
    3544:	aa1303e0 	mov	x0, x19
    3548:	911fe021 	add	x1, x1, #0x7f8
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2190>
    3560:	91200021 	add	x1, x1, #0x800
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x2190>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	91202042 	add	x2, x2, #0x808
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    36d0:	911f6000 	add	x0, x0, #0x7d8
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    36f0:	91206000 	add	x0, x0, #0x818
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3788:	9120e000 	add	x0, x0, #0x838
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3798:	91216000 	add	x0, x0, #0x858
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x830>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc12420 	ldr	q0, [x1, #1168]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3898:	91220000 	add	x0, x0, #0x880
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3908:	9122c000 	add	x0, x0, #0x8b0
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x2190>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	91240084 	add	x4, x4, #0x900
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x2190>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	91246084 	add	x4, x4, #0x918
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x2190>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	91242084 	add	x4, x4, #0x908
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    3d28:	91150042 	add	x2, x2, #0x540
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x2190>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91248021 	add	x1, x1, #0x920
    3d84:	9124a000 	add	x0, x0, #0x928
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x2190>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	91252042 	add	x2, x2, #0x948
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3e8c:	91110061 	add	x1, x3, #0x440
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3e9c:	91150262 	add	x2, x19, #0x540
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x830>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3ecc:	91120021 	add	x1, x1, #0x480
    3ed0:	3dc12843 	ldr	q3, [x2, #1184]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3efc:	91110063 	add	x3, x3, #0x440
    3f00:	91138084 	add	x4, x4, #0x4e0
    3f04:	91150266 	add	x6, x19, #0x540
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91150275 	add	x21, x19, #0x540
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    3fe8:	9127e000 	add	x0, x0, #0x9f8
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91150273 	add	x19, x19, #0x540
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <fwp_wake_io>:
    4044:	900000e9 	adrp	x9, 20000 <__data_start>
    4048:	9100c122 	add	x2, x9, #0x30
    404c:	f9400001 	ldr	x1, [x0]
    4050:	5280000a 	mov	w10, #0x0                   	// #0
    4054:	f9401446 	ldr	x6, [x2, #40]
    4058:	52800008 	mov	w8, #0x0                   	// #0
    405c:	4f000400 	movi	v0.4s, #0x0
    4060:	52800027 	mov	w7, #0x1                   	// #1
    4064:	aa0103e2 	mov	x2, x1
    4068:	b4000321 	cbz	x1, 40cc <fwp_wake_io+0x88>
    406c:	f9408c25 	ldr	x5, [x1, #280]
    4070:	39015c27 	strb	w7, [x1, #87]
    4074:	b4000165 	cbz	x5, 40a0 <fwp_wake_io+0x5c>
    4078:	a9520c24 	ldp	x4, x3, [x1, #288]
    407c:	b4000364 	cbz	x4, 40e8 <fwp_wake_io+0xa4>
    4080:	f9009483 	str	x3, [x4, #296]
    4084:	f9409423 	ldr	x3, [x1, #296]
    4088:	b4000043 	cbz	x3, 4090 <fwp_wake_io+0x4c>
    408c:	f9009064 	str	x4, [x3, #288]
    4090:	91080023 	add	x3, x1, #0x200
    4094:	f900943f 	str	xzr, [x1, #296]
    4098:	3c918060 	stur	q0, [x3, #-232]
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	f9402843 	ldr	x3, [x2, #80]
    40a4:	f2001c7f 	tst	x3, #0xff000000ff
    40a8:	54fffde1 	b.ne	4064 <fwp_wake_io+0x20>  // b.any
    40ac:	39015047 	strb	w7, [x2, #84]
    40b0:	f900805f 	str	xzr, [x2, #256]
    40b4:	b40001e6 	cbz	x6, 40f0 <fwp_wake_io+0xac>
    40b8:	f90080c2 	str	x2, [x6, #256]
    40bc:	aa0203e6 	mov	x6, x2
    40c0:	52800028 	mov	w8, #0x1                   	// #1
    40c4:	aa0103e2 	mov	x2, x1
    40c8:	b5fffd21 	cbnz	x1, 406c <fwp_wake_io+0x28>
    40cc:	3400006a 	cbz	w10, 40d8 <fwp_wake_io+0x94>
    40d0:	9100c120 	add	x0, x9, #0x30
    40d4:	f900180b 	str	x11, [x0, #48]
    40d8:	34000068 	cbz	w8, 40e4 <fwp_wake_io+0xa0>
    40dc:	9100c129 	add	x9, x9, #0x30
    40e0:	f9001526 	str	x6, [x9, #40]
    40e4:	d65f03c0 	ret
    40e8:	f90000a3 	str	x3, [x5]
    40ec:	17ffffe7 	b	4088 <fwp_wake_io+0x44>
    40f0:	aa0203eb 	mov	x11, x2
    40f4:	5280002a 	mov	w10, #0x1                   	// #1
    40f8:	17fffff1 	b	40bc <fwp_wake_io+0x78>
    40fc:	d503201f 	nop

0000000000004100 <fwp_tape_buffers_release>:
    4100:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4104:	910003fd 	mov	x29, sp
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f9401400 	ldr	x0, [x0, #40]
    4114:	b7f80760 	tbnz	x0, #63, 4200 <fwp_tape_buffers_release+0x100>
    4118:	f9401a61 	ldr	x1, [x19, #48]
    411c:	b7f80301 	tbnz	x1, #63, 417c <fwp_tape_buffers_release+0x7c>
    4120:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4124:	eb02001f 	cmp	x0, x2
    4128:	540002a8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    412c:	8b000400 	add	x0, x0, x0, lsl #1
    4130:	d2a00102 	mov	x2, #0x80000               	// #524288
    4134:	d37df000 	lsl	x0, x0, #3
    4138:	cb000042 	sub	x2, x2, x0
    413c:	eb420c3f 	cmp	x1, x2, lsr #3
    4140:	540001e8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4144:	8b010c14 	add	x20, x0, x1, lsl #3
    4148:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    414c:	91282000 	add	x0, x0, #0xa08
    4150:	97fffa30 	bl	2a10 <getenv@plt>
    4154:	b4000240 	cbz	x0, 419c <fwp_tape_buffers_release+0x9c>
    4158:	39400001 	ldrb	w1, [x0]
    415c:	7100c03f 	cmp	w1, #0x30
    4160:	540001e1 	b.ne	419c <fwp_tape_buffers_release+0x9c>  // b.any
    4164:	39400400 	ldrb	w0, [x0, #1]
    4168:	350001a0 	cbnz	w0, 419c <fwp_tape_buffers_release+0x9c>
    416c:	aa1303e0 	mov	x0, x19
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4178:	17fffc62 	b	3300 <fwp_tape_buffers_dispose>
    417c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    4180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4184:	91282000 	add	x0, x0, #0xa08
    4188:	97fffa22 	bl	2a10 <getenv@plt>
    418c:	b4ffff00 	cbz	x0, 416c <fwp_tape_buffers_release+0x6c>
    4190:	39400001 	ldrb	w1, [x0]
    4194:	7100c03f 	cmp	w1, #0x30
    4198:	54fffe60 	b.eq	4164 <fwp_tape_buffers_release+0x64>  // b.none
    419c:	d1000681 	sub	x1, x20, #0x1
    41a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	54fffe28 	b.hi	416c <fwp_tape_buffers_release+0x6c>  // b.pmore
    41ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    41b0:	900000f6 	adrp	x22, 20000 <__data_start>
    41b4:	9100c2d6 	add	x22, x22, #0x30
    41b8:	910122d5 	add	x21, x22, #0x48
    41bc:	aa1503e0 	mov	x0, x21
    41c0:	97fffc50 	bl	3300 <fwp_tape_buffers_dispose>
    41c4:	ad400a61 	ldp	q1, q2, [x19]
    41c8:	f90042d4 	str	x20, [x22, #128]
    41cc:	4f000400 	movi	v0.4s, #0x0
    41d0:	ad000aa1 	stp	q1, q2, [x21]
    41d4:	3dc00a61 	ldr	q1, [x19, #32]
    41d8:	3d800aa1 	str	q1, [x21, #32]
    41dc:	f9401a60 	ldr	x0, [x19, #48]
    41e0:	f9001aa0 	str	x0, [x21, #48]
    41e4:	f9001a7f 	str	xzr, [x19, #48]
    41e8:	ad000260 	stp	q0, q0, [x19]
    41ec:	3d800a60 	str	q0, [x19, #32]
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41fc:	d65f03c0 	ret
    4200:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    4204:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4208:	91282000 	add	x0, x0, #0xa08
    420c:	97fffa01 	bl	2a10 <getenv@plt>
    4210:	b5fffa40 	cbnz	x0, 4158 <fwp_tape_buffers_release+0x58>
    4214:	17ffffd6 	b	416c <fwp_tape_buffers_release+0x6c>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_poll_events>:
    4220:	d10103ff 	sub	sp, sp, #0x40
    4224:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4228:	f947f400 	ldr	x0, [x0, #4072]
    422c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4230:	910083fd 	add	x29, sp, #0x20
    4234:	a90353f3 	stp	x19, x20, [sp, #48]
    4238:	900000f4 	adrp	x20, 20000 <__data_start>
    423c:	f9400001 	ldr	x1, [x0]
    4240:	f9000fe1 	str	x1, [sp, #24]
    4244:	d2800001 	mov	x1, #0x0                   	// #0
    4248:	97fffd2e 	bl	3700 <fwp_now_ns>
    424c:	9100c281 	add	x1, x20, #0x30
    4250:	f9404433 	ldr	x19, [x1, #136]
    4254:	b4000e93 	cbz	x19, 4424 <fwp_poll_events+0x204>
    4258:	aa1303e1 	mov	x1, x19
    425c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4260:	14000005 	b	4274 <fwp_poll_events+0x54>
    4264:	f9408821 	ldr	x1, [x1, #272]
    4268:	eb03005f 	cmp	x2, x3
    426c:	9a83d042 	csel	x2, x2, x3, le
    4270:	b40000c1 	cbz	x1, 4288 <fwp_poll_events+0x68>
    4274:	f9403423 	ldr	x3, [x1, #104]
    4278:	b6ffff62 	tbz	x2, #63, 4264 <fwp_poll_events+0x44>
    427c:	f9408821 	ldr	x1, [x1, #272]
    4280:	aa0303e2 	mov	x2, x3
    4284:	b5ffff81 	cbnz	x1, 4274 <fwp_poll_events+0x54>
    4288:	b7f80ce2 	tbnz	x2, #63, 4424 <fwp_poll_events+0x204>
    428c:	cb000042 	sub	x2, x2, x0
    4290:	f100005f 	cmp	x2, #0x0
    4294:	540005cd 	b.le	434c <fwp_poll_events+0x12c>
    4298:	d2869b60 	mov	x0, #0x34db                	// #13531
    429c:	d2884801 	mov	x1, #0x4240                	// #16960
    42a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    42b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    42b4:	9b407c40 	smulh	x0, x2, x0
    42b8:	9352fc00 	asr	x0, x0, #18
    42bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    42c0:	9b018802 	msub	x2, x0, x1, x2
    42c4:	f100005f 	cmp	x2, #0x0
    42c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    42cc:	eb03001f 	cmp	x0, x3
    42d0:	54000a0c 	b.gt	4410 <fwp_poll_events+0x1f0>
    42d4:	340003c0 	cbz	w0, 434c <fwp_poll_events+0x12c>
    42d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42e4:	9ba27c02 	umull	x2, w0, w2
    42e8:	d366fc43 	lsr	x3, x2, #38
    42ec:	aa0303e2 	mov	x2, x3
    42f0:	1b048063 	msub	w3, w3, w4, w0
    42f4:	9b217c63 	smull	x3, w3, w1
    42f8:	d2800001 	mov	x1, #0x0                   	// #0
    42fc:	910023e0 	add	x0, sp, #0x8
    4300:	a9008fe2 	stp	x2, x3, [sp, #8]
    4304:	97fff993 	bl	2950 <nanosleep@plt>
    4308:	9100c280 	add	x0, x20, #0x30
    430c:	f9404413 	ldr	x19, [x0, #136]
    4310:	97fffcfc 	bl	3700 <fwp_now_ns>
    4314:	aa0003e6 	mov	x6, x0
    4318:	b50001f3 	cbnz	x19, 4354 <fwp_poll_events+0x134>
    431c:	d503201f 	nop
    4320:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4324:	f947f400 	ldr	x0, [x0, #4072]
    4328:	f9400fe2 	ldr	x2, [sp, #24]
    432c:	f9400001 	ldr	x1, [x0]
    4330:	eb010042 	subs	x2, x2, x1
    4334:	d2800001 	mov	x1, #0x0                   	// #0
    4338:	540008c1 	b.ne	4450 <fwp_poll_events+0x230>  // b.any
    433c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4340:	a94353f3 	ldp	x19, x20, [sp, #48]
    4344:	910103ff 	add	sp, sp, #0x40
    4348:	d65f03c0 	ret
    434c:	97fffced 	bl	3700 <fwp_now_ns>
    4350:	aa0003e6 	mov	x6, x0
    4354:	4f000400 	movi	v0.4s, #0x0
    4358:	9100c288 	add	x8, x20, #0x30
    435c:	52800027 	mov	w7, #0x1                   	// #1
    4360:	f9403661 	ldr	x1, [x19, #104]
    4364:	aa1303e5 	mov	x5, x19
    4368:	f9408a73 	ldr	x19, [x19, #272]
    436c:	eb06003f 	cmp	x1, x6
    4370:	5400032c 	b.gt	43d4 <fwp_poll_events+0x1b4>
    4374:	394154a0 	ldrb	w0, [x5, #85]
    4378:	36000120 	tbz	w0, #0, 439c <fwp_poll_events+0x17c>
    437c:	f94084a0 	ldr	x0, [x5, #264]
    4380:	b40003c0 	cbz	x0, 43f8 <fwp_poll_events+0x1d8>
    4384:	f9008813 	str	x19, [x0, #272]
    4388:	b4000053 	cbz	x19, 4390 <fwp_poll_events+0x170>
    438c:	f9008660 	str	x0, [x19, #264]
    4390:	910800a0 	add	x0, x5, #0x200
    4394:	390154bf 	strb	wzr, [x5, #85]
    4398:	3c908000 	stur	q0, [x0, #-248]
    439c:	f94030a0 	ldr	x0, [x5, #96]
    43a0:	390158a7 	strb	w7, [x5, #86]
    43a4:	f100001f 	cmp	x0, #0x0
    43a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43ac:	5400018d 	b.le	43dc <fwp_poll_events+0x1bc>
    43b0:	f94028a0 	ldr	x0, [x5, #80]
    43b4:	f2001c1f 	tst	x0, #0xff000000ff
    43b8:	540000e1 	b.ne	43d4 <fwp_poll_events+0x1b4>  // b.any
    43bc:	f9401500 	ldr	x0, [x8, #40]
    43c0:	390150a7 	strb	w7, [x5, #84]
    43c4:	f90080bf 	str	xzr, [x5, #256]
    43c8:	b40001e0 	cbz	x0, 4404 <fwp_poll_events+0x1e4>
    43cc:	f9001505 	str	x5, [x8, #40]
    43d0:	f9008005 	str	x5, [x0, #256]
    43d4:	b5fffc73 	cbnz	x19, 4360 <fwp_poll_events+0x140>
    43d8:	17ffffd2 	b	4320 <fwp_poll_events+0x100>
    43dc:	394144a0 	ldrb	w0, [x5, #81]
    43e0:	3707fe80 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43e4:	394140a0 	ldrb	w0, [x5, #80]
    43e8:	3707fe40 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43ec:	aa0503e0 	mov	x0, x5
    43f0:	97fffc20 	bl	3470 <fwp_cancel_tree.part.0>
    43f4:	17ffffef 	b	43b0 <fwp_poll_events+0x190>
    43f8:	9100c281 	add	x1, x20, #0x30
    43fc:	f9004433 	str	x19, [x1, #136]
    4400:	17ffffe2 	b	4388 <fwp_poll_events+0x168>
    4404:	f9001505 	str	x5, [x8, #40]
    4408:	f9001905 	str	x5, [x8, #48]
    440c:	17fffff2 	b	43d4 <fwp_poll_events+0x1b4>
    4410:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4414:	d2989362 	mov	x2, #0xc49b                	// #50331
    4418:	f2a4d203 	movk	x3, #0x2690, lsl #16
    441c:	f2a00402 	movk	x2, #0x20, lsl #16
    4420:	17ffffb6 	b	42f8 <fwp_poll_events+0xd8>
    4424:	97fffaf3 	bl	2ff0 <fwp_flush>
    4428:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    442c:	f947e863 	ldr	x3, [x3, #4048]
    4430:	d2800562 	mov	x2, #0x2b                  	// #43
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    443c:	91288000 	add	x0, x0, #0xa20
    4440:	f9400063 	ldr	x3, [x3]
    4444:	97fff94f 	bl	2980 <fwrite@plt>
    4448:	52800ca0 	mov	w0, #0x65                  	// #101
    444c:	97fff8b9 	bl	2730 <exit@plt>
    4450:	97fff90c 	bl	2880 <__stack_chk_fail@plt>

0000000000004454 <fwp_rc_wide_dup>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	ca404400 	eor	x0, x0, x0, lsr #17
    4468:	f90013f5 	str	x21, [sp, #32]
    446c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4470:	ca402400 	eor	x0, x0, x0, lsr #9
    4474:	911502a2 	add	x2, x21, #0x540
    4478:	92401c00 	and	x0, x0, #0xff
    447c:	910a2403 	add	x3, x0, #0x289
    4480:	8b000c40 	add	x0, x2, x0, lsl #3
    4484:	8b030c54 	add	x20, x2, x3, lsl #3
    4488:	f94a2401 	ldr	x1, [x0, #5192]
    448c:	b50000a1 	cbnz	x1, 44a0 <fwp_rc_wide_dup+0x4c>
    4490:	1400002d 	b	4544 <fwp_rc_wide_dup+0xf0>
    4494:	91004034 	add	x20, x1, #0x10
    4498:	f9400821 	ldr	x1, [x1, #16]
    449c:	b4000241 	cbz	x1, 44e4 <fwp_rc_wide_dup+0x90>
    44a0:	f9400022 	ldr	x2, [x1]
    44a4:	eb02027f 	cmp	x19, x2
    44a8:	54ffff61 	b.ne	4494 <fwp_rc_wide_dup+0x40>  // b.any
    44ac:	f9400281 	ldr	x1, [x20]
    44b0:	39400260 	ldrb	w0, [x19]
    44b4:	7103f81f 	cmp	w0, #0xfe
    44b8:	54000220 	b.eq	44fc <fwp_rc_wide_dup+0xa8>  // b.none
    44bc:	b40001a1 	cbz	x1, 44f0 <fwp_rc_wide_dup+0x9c>
    44c0:	f9400420 	ldr	x0, [x1, #8]
    44c4:	b100041f 	cmn	x0, #0x1
    44c8:	540004a0 	b.eq	455c <fwp_rc_wide_dup+0x108>  // b.none
    44cc:	91000400 	add	x0, x0, #0x1
    44d0:	f9000420 	str	x0, [x1, #8]
    44d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44d8:	f94013f5 	ldr	x21, [sp, #32]
    44dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44e0:	d65f03c0 	ret
    44e4:	39400260 	ldrb	w0, [x19]
    44e8:	7103f81f 	cmp	w0, #0xfe
    44ec:	540000a0 	b.eq	4500 <fwp_rc_wide_dup+0xac>  // b.none
    44f0:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    44f4:	9129e000 	add	x0, x0, #0xa78
    44f8:	97fffc22 	bl	3580 <fwp_trap>
    44fc:	b5000281 	cbnz	x1, 454c <fwp_rc_wide_dup+0xf8>
    4500:	d2800300 	mov	x0, #0x18                  	// #24
    4504:	97fff8c7 	bl	2820 <malloc@plt>
    4508:	b4000280 	cbz	x0, 4558 <fwp_rc_wide_dup+0x104>
    450c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4510:	a9000413 	stp	x19, x1, [x0]
    4514:	911502b5 	add	x21, x21, #0x540
    4518:	f900081f 	str	xzr, [x0, #16]
    451c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4520:	f9000280 	str	x0, [x20]
    4524:	39000261 	strb	w1, [x19]
    4528:	f94e26a0 	ldr	x0, [x21, #7240]
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	91000400 	add	x0, x0, #0x1
    4534:	f90e26a0 	str	x0, [x21, #7240]
    4538:	f94013f5 	ldr	x21, [sp, #32]
    453c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4540:	d65f03c0 	ret
    4544:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4548:	17ffffda 	b	44b0 <fwp_rc_wide_dup+0x5c>
    454c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    4550:	91294000 	add	x0, x0, #0xa50
    4554:	97fffc0b 	bl	3580 <fwp_trap>
    4558:	97fffab6 	bl	3030 <fwp_heap_oom>
    455c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    4560:	912a8000 	add	x0, x0, #0xaa0
    4564:	97fffc07 	bl	3580 <fwp_trap>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_rc_forget_slot>:
    4570:	aa0003e1 	mov	x1, x0
    4574:	39400000 	ldrb	w0, [x0]
    4578:	7103fc1f 	cmp	w0, #0xff
    457c:	54000040 	b.eq	4584 <fwp_rc_forget_slot+0x14>  // b.none
    4580:	d65f03c0 	ret
    4584:	ca414420 	eor	x0, x1, x1, lsr #17
    4588:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    458c:	ca402400 	eor	x0, x0, x0, lsr #9
    4590:	910003fd 	mov	x29, sp
    4594:	92401c00 	and	x0, x0, #0xff
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    45a0:	91150262 	add	x2, x19, #0x540
    45a4:	910a2403 	add	x3, x0, #0x289
    45a8:	8b000c40 	add	x0, x2, x0, lsl #3
    45ac:	8b030c43 	add	x3, x2, x3, lsl #3
    45b0:	f94a2400 	ldr	x0, [x0, #5192]
    45b4:	b50000a0 	cbnz	x0, 45c8 <fwp_rc_forget_slot+0x58>
    45b8:	14000011 	b	45fc <fwp_rc_forget_slot+0x8c>
    45bc:	91004003 	add	x3, x0, #0x10
    45c0:	f9400800 	ldr	x0, [x0, #16]
    45c4:	b40001c0 	cbz	x0, 45fc <fwp_rc_forget_slot+0x8c>
    45c8:	f9400002 	ldr	x2, [x0]
    45cc:	eb02003f 	cmp	x1, x2
    45d0:	54ffff61 	b.ne	45bc <fwp_rc_forget_slot+0x4c>  // b.any
    45d4:	f9400801 	ldr	x1, [x0, #16]
    45d8:	91150273 	add	x19, x19, #0x540
    45dc:	f9000061 	str	x1, [x3]
    45e0:	97fff8d8 	bl	2940 <free@plt>
    45e4:	f94e2660 	ldr	x0, [x19, #7240]
    45e8:	d1000400 	sub	x0, x0, #0x1
    45ec:	f90e2660 	str	x0, [x19, #7240]
    45f0:	f9400bf3 	ldr	x19, [sp, #16]
    45f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45f8:	d65f03c0 	ret
    45fc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    4600:	9129e000 	add	x0, x0, #0xa78
    4604:	97fffbdf 	bl	3580 <fwp_trap>
    4608:	d503201f 	nop
    460c:	d503201f 	nop

0000000000004610 <fwp_rc_prepare_chunk>:
    4610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4614:	910003fd 	mov	x29, sp
    4618:	a9025bf5 	stp	x21, x22, [sp, #32]
    461c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    4620:	911502c2 	add	x2, x22, #0x540
    4624:	b9401c03 	ldr	w3, [x0, #28]
    4628:	aa0103f5 	mov	x21, x1
    462c:	a90153f3 	stp	x19, x20, [sp, #16]
    4630:	aa0003f4 	mov	x20, x0
    4634:	f94e2440 	ldr	x0, [x2, #7240]
    4638:	b4000440 	cbz	x0, 46c0 <fwp_rc_prepare_chunk+0xb0>
    463c:	d2800013 	mov	x19, #0x0                   	// #0
    4640:	35000203 	cbnz	w3, 4680 <fwp_rc_prepare_chunk+0x70>
    4644:	b4000361 	cbz	x1, 46b0 <fwp_rc_prepare_chunk+0xa0>
    4648:	f9401280 	ldr	x0, [x20, #32]
    464c:	97fff8bd 	bl	2940 <free@plt>
    4650:	aa1503e0 	mov	x0, x21
    4654:	d2800021 	mov	x1, #0x1                   	// #1
    4658:	97fff882 	bl	2860 <calloc@plt>
    465c:	f9001280 	str	x0, [x20, #32]
    4660:	b5000460 	cbnz	x0, 46ec <fwp_rc_prepare_chunk+0xdc>
    4664:	97fffa73 	bl	3030 <fwp_heap_oom>
    4668:	97ffffc2 	bl	4570 <fwp_rc_forget_slot>
    466c:	91000673 	add	x19, x19, #0x1
    4670:	b9401e83 	ldr	w3, [x20, #28]
    4674:	eb13007f 	cmp	x3, x19
    4678:	54000169 	b.ls	46a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    467c:	d503201f 	nop
    4680:	f9401283 	ldr	x3, [x20, #32]
    4684:	8b130060 	add	x0, x3, x19
    4688:	38736863 	ldrb	w3, [x3, x19]
    468c:	7103fc7f 	cmp	w3, #0xff
    4690:	54fffec0 	b.eq	4668 <fwp_rc_prepare_chunk+0x58>  // b.none
    4694:	b9401e83 	ldr	w3, [x20, #28]
    4698:	91000673 	add	x19, x19, #0x1
    469c:	eb13007f 	cmp	x3, x19
    46a0:	54ffff08 	b.hi	4680 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46a4:	eb0302bf 	cmp	x21, x3
    46a8:	54000121 	b.ne	46cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    46ac:	b5000335 	cbnz	x21, 4710 <fwp_rc_prepare_chunk+0x100>
    46b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46bc:	d65f03c0 	ret
    46c0:	2a0303e3 	mov	w3, w3
    46c4:	eb0302bf 	cmp	x21, x3
    46c8:	54ffff20 	b.eq	46ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    46cc:	911502c2 	add	x2, x22, #0x540
    46d0:	f9401280 	ldr	x0, [x20, #32]
    46d4:	f94e2841 	ldr	x1, [x2, #7248]
    46d8:	cb030021 	sub	x1, x1, x3
    46dc:	f90e2841 	str	x1, [x2, #7248]
    46e0:	97fff898 	bl	2940 <free@plt>
    46e4:	b5fffb75 	cbnz	x21, 4650 <fwp_rc_prepare_chunk+0x40>
    46e8:	f900129f 	str	xzr, [x20, #32]
    46ec:	911502d6 	add	x22, x22, #0x540
    46f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46f4:	b9001e95 	str	w21, [x20, #28]
    46f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46fc:	8b150000 	add	x0, x0, x21
    4700:	f90e2ac0 	str	x0, [x22, #7248]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	f9401280 	ldr	x0, [x20, #32]
    4714:	aa1503e2 	mov	x2, x21
    4718:	a94153f3 	ldp	x19, x20, [sp, #16]
    471c:	52800001 	mov	w1, #0x0                   	// #0
    4720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4728:	17fff84a 	b	2850 <memset@plt>
    472c:	d503201f 	nop

0000000000004730 <fwp_heap_refill>:
    4730:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4734:	910003fd 	mov	x29, sp
    4738:	a9025bf5 	stp	x21, x22, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4740:	911502b5 	add	x21, x21, #0x540
    4744:	aa0003f6 	mov	x22, x0
    4748:	d2800020 	mov	x0, #0x1                   	// #1
    474c:	a90153f3 	stp	x19, x20, [sp, #16]
    4750:	a90363f7 	stp	x23, x24, [sp, #48]
    4754:	2a0103f7 	mov	w23, w1
    4758:	2a0203f8 	mov	w24, w2
    475c:	97fffa75 	bl	3130 <fwp_heap_chunks>
    4760:	aa0003f3 	mov	x19, x0
    4764:	f949fea2 	ldr	x2, [x21, #5112]
    4768:	8b000800 	add	x0, x0, x0, lsl #2
    476c:	2a1703e1 	mov	w1, w23
    4770:	52800025 	mov	w5, #0x1                   	// #1
    4774:	d37df000 	lsl	x0, x0, #3
    4778:	910f0021 	add	x1, x1, #0x3c0
    477c:	8b000054 	add	x20, x2, x0
    4780:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4784:	52a00024 	mov	w4, #0x10000               	// #65536
    4788:	38206845 	strb	w5, [x2, x0]
    478c:	aa1403e0 	mov	x0, x20
    4790:	39000698 	strb	w24, [x20, #1]
    4794:	39000a97 	strb	w23, [x20, #2]
    4798:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    479c:	b9000681 	str	w1, [x20, #4]
    47a0:	2a0103e5 	mov	w5, w1
    47a4:	8b0300a2 	add	x2, x5, x3
    47a8:	1ac10881 	udiv	w1, w4, w1
    47ac:	9ac50842 	udiv	x2, x2, x5
    47b0:	b9000a81 	str	w1, [x20, #8]
    47b4:	92404021 	and	x1, x1, #0x1ffff
    47b8:	b9001a82 	str	w2, [x20, #24]
    47bc:	97ffff95 	bl	4610 <fwp_rc_prepare_chunk>
    47c0:	f949daa0 	ldr	x0, [x21, #5040]
    47c4:	29408a81 	ldp	w1, w2, [x20, #4]
    47c8:	8b134000 	add	x0, x0, x19, lsl #16
    47cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d0:	8b214003 	add	x3, x0, w1, uxtw
    47d4:	9ba20021 	umaddl	x1, w1, w2, x0
    47d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47dc:	a90086c3 	stp	x3, x1, [x22, #8]
    47e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47e8:	d65f03c0 	ret
    47ec:	d503201f 	nop

00000000000047f0 <fwp_mem_free>:
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_mem_free+0x78>
    47f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47f8:	910003fd 	mov	x29, sp
    47fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4800:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4804:	911502a1 	add	x1, x21, #0x540
    4808:	a90153f3 	stp	x19, x20, [sp, #16]
    480c:	aa0003f3 	mov	x19, x0
    4810:	f949d823 	ldr	x3, [x1, #5040]
    4814:	f949ec22 	ldr	x2, [x1, #5080]
    4818:	cb030000 	sub	x0, x0, x3
    481c:	eb02401f 	cmp	x0, x2, lsl #16
    4820:	540001c2 	b.cs	4858 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4824:	d350fc16 	lsr	x22, x0, #16
    4828:	a90363f7 	stp	x23, x24, [sp, #48]
    482c:	f949fc22 	ldr	x2, [x1, #5112]
    4830:	8b160ad4 	add	x20, x22, x22, lsl #2
    4834:	d37df294 	lsl	x20, x20, #3
    4838:	ab140057 	adds	x23, x2, x20
    483c:	540000c0 	b.eq	4854 <fwp_mem_free+0x64>  // b.none
    4840:	38746842 	ldrb	w2, [x2, x20]
    4844:	7100045f 	cmp	w2, #0x1
    4848:	54000120 	b.eq	486c <fwp_mem_free+0x7c>  // b.none
    484c:	7100085f 	cmp	w2, #0x2
    4850:	540005e0 	b.eq	490c <fwp_mem_free+0x11c>  // b.none
    4854:	a94363f7 	ldp	x23, x24, [sp, #48]
    4858:	a94153f3 	ldp	x19, x20, [sp, #16]
    485c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4860:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4864:	d65f03c0 	ret
    4868:	d65f03c0 	ret
    486c:	f94012f8 	ldr	x24, [x23, #32]
    4870:	b94006e1 	ldr	w1, [x23, #4]
    4874:	f90023f9 	str	x25, [sp, #64]
    4878:	2a0103e2 	mov	w2, w1
    487c:	394006f9 	ldrb	w25, [x23, #1]
    4880:	39400af4 	ldrb	w20, [x23, #2]
    4884:	b4000158 	cbz	x24, 48ac <fwp_mem_free+0xbc>
    4888:	92403e76 	and	x22, x19, #0xffff
    488c:	9ac20ad6 	udiv	x22, x22, x2
    4890:	38766b01 	ldrb	w1, [x24, x22]
    4894:	8b160300 	add	x0, x24, x22
    4898:	7103fc3f 	cmp	w1, #0xff
    489c:	54000980 	b.eq	49cc <fwp_mem_free+0x1dc>  // b.none
    48a0:	38366b1f 	strb	wzr, [x24, x22]
    48a4:	b94006e1 	ldr	w1, [x23, #4]
    48a8:	2a0103e2 	mov	w2, w1
    48ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    48b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    48b4:	cb390000 	sub	x0, x0, w25, uxtb
    48b8:	8b340074 	add	x20, x3, w20, uxtb
    48bc:	911502b5 	add	x21, x21, #0x540
    48c0:	1e630021 	ucvtf	d1, w1
    48c4:	d37ae400 	lsl	x0, x0, #6
    48c8:	8b140c14 	add	x20, x0, x20, lsl #3
    48cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    48d0:	f8746aa0 	ldr	x0, [x21, x20]
    48d4:	f94023f9 	ldr	x25, [sp, #64]
    48d8:	aa2003e0 	mvn	x0, x0
    48dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    48e0:	f9000260 	str	x0, [x19]
    48e4:	f8346ab3 	str	x19, [x21, x20]
    48e8:	f94a12a0 	ldr	x0, [x21, #5152]
    48ec:	1e612800 	fadd	d0, d0, d1
    48f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f4:	cb020000 	sub	x0, x0, x2
    48f8:	f90a12a0 	str	x0, [x21, #5152]
    48fc:	fd0a22a0 	str	d0, [x21, #5184]
    4900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4904:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4908:	d65f03c0 	ret
    490c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4910:	8b000063 	add	x3, x3, x0
    4914:	eb03027f 	cmp	x19, x3
    4918:	54fff9e1 	b.ne	4854 <fwp_mem_free+0x64>  // b.any
    491c:	fd400ae1 	ldr	d1, [x23, #16]
    4920:	fd4a2020 	ldr	d0, [x1, #5184]
    4924:	f9400ae0 	ldr	x0, [x23, #16]
    4928:	7e61d821 	ucvtf	d1, d1
    492c:	f94a1022 	ldr	x2, [x1, #5152]
    4930:	f94012f3 	ldr	x19, [x23, #32]
    4934:	1e612800 	fadd	d0, d0, d1
    4938:	cb000042 	sub	x2, x2, x0
    493c:	f90a1022 	str	x2, [x1, #5152]
    4940:	fd0a2020 	str	d0, [x1, #5184]
    4944:	b40000b3 	cbz	x19, 4958 <fwp_mem_free+0x168>
    4948:	39400260 	ldrb	w0, [x19]
    494c:	7103fc1f 	cmp	w0, #0xff
    4950:	54000380 	b.eq	49c0 <fwp_mem_free+0x1d0>  // b.none
    4954:	3900027f 	strb	wzr, [x19]
    4958:	b9400ee2 	ldr	w2, [x23, #12]
    495c:	b4000142 	cbz	x2, 4984 <fwp_mem_free+0x194>
    4960:	911502a1 	add	x1, x21, #0x540
    4964:	8b160040 	add	x0, x2, x22
    4968:	8b000800 	add	x0, x0, x0, lsl #2
    496c:	f949fc21 	ldr	x1, [x1, #5112]
    4970:	8b140034 	add	x20, x1, x20
    4974:	8b000c20 	add	x0, x1, x0, lsl #3
    4978:	3802869f 	strb	wzr, [x20], #40
    497c:	eb00029f 	cmp	x20, x0
    4980:	54ffffc1 	b.ne	4978 <fwp_mem_free+0x188>  // b.any
    4984:	911502a0 	add	x0, x21, #0x540
    4988:	f94a1801 	ldr	x1, [x0, #5168]
    498c:	f949f803 	ldr	x3, [x0, #5104]
    4990:	8b020021 	add	x1, x1, x2
    4994:	f90a1801 	str	x1, [x0, #5168]
    4998:	eb16007f 	cmp	x3, x22
    499c:	54000049 	b.ls	49a4 <fwp_mem_free+0x1b4>  // b.plast
    49a0:	f909f816 	str	x22, [x0, #5104]
    49a4:	911502b5 	add	x21, x21, #0x540
    49a8:	f949f6a0 	ldr	x0, [x21, #5096]
    49ac:	eb16001f 	cmp	x0, x22
    49b0:	54fff529 	b.ls	4854 <fwp_mem_free+0x64>  // b.plast
    49b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    49b8:	f909f6b6 	str	x22, [x21, #5096]
    49bc:	17ffffa7 	b	4858 <fwp_mem_free+0x68>
    49c0:	aa1303e0 	mov	x0, x19
    49c4:	97fffeeb 	bl	4570 <fwp_rc_forget_slot>
    49c8:	17ffffe3 	b	4954 <fwp_mem_free+0x164>
    49cc:	97fffee9 	bl	4570 <fwp_rc_forget_slot>
    49d0:	17ffffb4 	b	48a0 <fwp_mem_free+0xb0>

00000000000049d4 <fwp_heap_alloc_big>:
    49d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d8:	910003fd 	mov	x29, sp
    49dc:	a90153f3 	stp	x19, x20, [sp, #16]
    49e0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e4:	a90363f7 	stp	x23, x24, [sp, #48]
    49e8:	aa0003f7 	mov	x23, x0
    49ec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f4:	eb0002ff 	cmp	x23, x0
    49f8:	54000888 	b.hi	4b08 <fwp_heap_alloc_big+0x134>  // b.pmore
    49fc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a00:	8b0002f4 	add	x20, x23, x0
    4a04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a08:	91150359 	add	x25, x26, #0x540
    4a0c:	d350fe94 	lsr	x20, x20, #16
    4a10:	2a0103f5 	mov	w21, w1
    4a14:	aa1403e0 	mov	x0, x20
    4a18:	97fff9c6 	bl	3130 <fwp_heap_chunks>
    4a1c:	f949ff22 	ldr	x2, [x25, #5112]
    4a20:	8b000813 	add	x19, x0, x0, lsl #2
    4a24:	aa0003f8 	mov	x24, x0
    4a28:	52800043 	mov	w3, #0x2                   	// #2
    4a2c:	d37df273 	lsl	x19, x19, #3
    4a30:	d2800021 	mov	x1, #0x1                   	// #1
    4a34:	8b130040 	add	x0, x2, x19
    4a38:	38336843 	strb	w3, [x2, x19]
    4a3c:	39000415 	strb	w21, [x0, #1]
    4a40:	b9000c14 	str	w20, [x0, #12]
    4a44:	f9000817 	str	x23, [x0, #16]
    4a48:	97fffef2 	bl	4610 <fwp_rc_prepare_chunk>
    4a4c:	f100069f 	cmp	x20, #0x1
    4a50:	54000269 	b.ls	4a9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a54:	8b180294 	add	x20, x20, x24
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a60:	5280007b 	mov	w27, #0x3                   	// #3
    4a64:	8b140a94 	add	x20, x20, x20, lsl #2
    4a68:	2a1803fc 	mov	w28, w24
    4a6c:	9adb2296 	lsl	x22, x20, x27
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffee4 	bl	4610 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0x9c>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffca4 	bl	3e84 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff70 	b	49d4 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffeb5 	bl	4730 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_p_ad_push>:
    4ea4:	f100001f 	cmp	x0, #0x0
    4ea8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4eac:	5400118b 	b.lt	50dc <fwp_p_ad_push+0x238>  // b.tstop
    4eb0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4eb4:	910003fd 	mov	x29, sp
    4eb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4ebc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec0:	aa0403f6 	mov	x22, x4
    4ec4:	aa0003f5 	mov	x21, x0
    4ec8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ecc:	aa0203f8 	mov	x24, x2
    4ed0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4ed4:	9e670029 	fmov	d9, x1
    4ed8:	9e670068 	fmov	d8, x3
    4edc:	aa020001 	orr	x1, x0, x2
    4ee0:	b6f80dc1 	tbz	x1, #63, 5098 <fwp_p_ad_push+0x1f4>
    4ee4:	9360fc14 	asr	x20, x0, #32
    4ee8:	b6f800c0 	tbz	x0, #63, 4f00 <fwp_p_ad_push+0x5c>
    4eec:	1e604109 	fmov	d9, d8
    4ef0:	2f00e408 	movi	d8, #0x0
    4ef4:	9360fc54 	asr	x20, x2, #32
    4ef8:	aa0203f5 	mov	x21, x2
    4efc:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    4f00:	b4001136 	cbz	x22, 5124 <fwp_p_ad_push+0x280>
    4f04:	f94002c0 	ldr	x0, [x22]
    4f08:	eb14001f 	cmp	x0, x20
    4f0c:	54000e40 	b.eq	50d4 <fwp_p_ad_push+0x230>  // b.none
    4f10:	aa1403e0 	mov	x0, x20
    4f14:	97fffa67 	bl	38b0 <fwp_tape_of>
    4f18:	aa0003f3 	mov	x19, x0
    4f1c:	f9403000 	ldr	x0, [x0, #96]
    4f20:	b50010c0 	cbnz	x0, 5138 <fwp_p_ad_push+0x294>
    4f24:	a9004ed4 	stp	x20, x19, [x22]
    4f28:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f2c:	f9400a77 	ldr	x23, [x19, #16]
    4f30:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f34:	eb0002ff 	cmp	x23, x0
    4f38:	540013ec 	b.gt	51b4 <fwp_p_ad_push+0x310>
    4f3c:	eb3542ff 	cmp	x23, w21, uxtw
    4f40:	5400132d 	b.le	51a4 <fwp_p_ad_push+0x300>
    4f44:	b7f80078 	tbnz	x24, #63, 4f50 <fwp_p_ad_push+0xac>
    4f48:	eb3842ff 	cmp	x23, w24, uxtw
    4f4c:	540012cd 	b.le	51a4 <fwp_p_ad_push+0x300>
    4f50:	f9400676 	ldr	x22, [x19, #8]
    4f54:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f58:	cb1602f6 	sub	x22, x23, x22
    4f5c:	910006c1 	add	x1, x22, #0x1
    4f60:	aa1603f9 	mov	x25, x22
    4f64:	eb00003f 	cmp	x1, x0
    4f68:	54001268 	b.hi	51b4 <fwp_p_ad_push+0x310>  // b.pmore
    4f6c:	a9418274 	ldp	x20, x0, [x19, #24]
    4f70:	eb14003f 	cmp	x1, x20
    4f74:	54000a6d 	b.le	50c0 <fwp_p_ad_push+0x21c>
    4f78:	f100029f 	cmp	x20, #0x0
    4f7c:	d2800803 	mov	x3, #0x40                  	// #64
    4f80:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4f84:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f88:	a90573fb 	stp	x27, x28, [sp, #80]
    4f8c:	eb14003f 	cmp	x1, x20
    4f90:	5400008d 	b.le	4fa0 <fwp_p_ad_push+0xfc>
    4f94:	eb02029f 	cmp	x20, x2
    4f98:	5400090d 	b.le	50b8 <fwp_p_ad_push+0x214>
    4f9c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4fa0:	d37df29a 	lsl	x26, x20, #3
    4fa4:	f940327b 	ldr	x27, [x19, #96]
    4fa8:	aa1a03e1 	mov	x1, x26
    4fac:	97fff631 	bl	2870 <realloc@plt>
    4fb0:	b40010a0 	cbz	x0, 51c4 <fwp_p_ad_push+0x320>
    4fb4:	f9400e61 	ldr	x1, [x19, #24]
    4fb8:	8b010801 	add	x1, x0, x1, lsl #2
    4fbc:	a9020660 	stp	x0, x1, [x19, #32]
    4fc0:	b400093b 	cbz	x27, 50e4 <fwp_p_ad_push+0x240>
    4fc4:	f9403363 	ldr	x3, [x27, #96]
    4fc8:	f9003be3 	str	x3, [sp, #112]
    4fcc:	eb03029f 	cmp	x20, x3
    4fd0:	5400034d 	b.le	5038 <fwp_p_ad_push+0x194>
    4fd4:	f940237c 	ldr	x28, [x27, #64]
    4fd8:	d37cee82 	lsl	x2, x20, #4
    4fdc:	aa0203e0 	mov	x0, x2
    4fe0:	52800041 	mov	w1, #0x2                   	// #2
    4fe4:	f9003fe2 	str	x2, [sp, #120]
    4fe8:	97ffff22 	bl	4c70 <fwp_heap_alloc>
    4fec:	aa0003fa 	mov	x26, x0
    4ff0:	b400013c 	cbz	x28, 5014 <fwp_p_ad_push+0x170>
    4ff4:	a9470be3 	ldp	x3, x2, [sp, #112]
    4ff8:	aa1c03e1 	mov	x1, x28
    4ffc:	d37cec63 	lsl	x3, x3, #4
    5000:	eb02007f 	cmp	x3, x2
    5004:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5008:	97fff5b2 	bl	26d0 <memcpy@plt>
    500c:	aa1c03e0 	mov	x0, x28
    5010:	97fffdf8 	bl	47f0 <fwp_mem_free>
    5014:	f9403360 	ldr	x0, [x27, #96]
    5018:	52800001 	mov	w1, #0x0                   	// #0
    501c:	cb000282 	sub	x2, x20, x0
    5020:	8b001340 	add	x0, x26, x0, lsl #4
    5024:	d37cec42 	lsl	x2, x2, #4
    5028:	97fff60a 	bl	2850 <memset@plt>
    502c:	f9401260 	ldr	x0, [x19, #32]
    5030:	f900237a 	str	x26, [x27, #64]
    5034:	f9003374 	str	x20, [x27, #96]
    5038:	b50008b6 	cbnz	x22, 514c <fwp_p_ad_push+0x2a8>
    503c:	a9431263 	ldp	x3, x4, [x19, #48]
    5040:	d37ef69a 	lsl	x26, x20, #2
    5044:	a94573fb 	ldp	x27, x28, [sp, #80]
    5048:	8b1a0002 	add	x2, x0, x26
    504c:	f9000e74 	str	x20, [x19, #24]
    5050:	f9001662 	str	x2, [x19, #40]
    5054:	b8366815 	str	w21, [x0, x22]
    5058:	f100031f 	cmp	x24, #0x0
    505c:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    5060:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5064:	fc396869 	str	d9, [x3, x25]
    5068:	aa1702a0 	orr	x0, x21, x23
    506c:	b8366841 	str	w1, [x2, x22]
    5070:	910006e1 	add	x1, x23, #0x1
    5074:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5078:	fc396888 	str	d8, [x4, x25]
    507c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5080:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5084:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5088:	f9000a61 	str	x1, [x19, #16]
    508c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5090:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5094:	d65f03c0 	ret
    5098:	9360fc54 	asr	x20, x2, #32
    509c:	eb80829f 	cmp	x20, x0, asr #32
    50a0:	54fff300 	b.eq	4f00 <fwp_p_ad_push+0x5c>  // b.none
    50a4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    50a8:	912b0000 	add	x0, x0, #0xac0
    50ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    50b0:	a90573fb 	stp	x27, x28, [sp, #80]
    50b4:	97fff933 	bl	3580 <fwp_trap>
    50b8:	d37ffa94 	lsl	x20, x20, #1
    50bc:	17ffffb4 	b	4f8c <fwp_p_ad_push+0xe8>
    50c0:	a9428e62 	ldp	x2, x3, [x19, #40]
    50c4:	d37ef6d6 	lsl	x22, x22, #2
    50c8:	f9401e64 	ldr	x4, [x19, #56]
    50cc:	d37df339 	lsl	x25, x25, #3
    50d0:	17ffffe1 	b	5054 <fwp_p_ad_push+0x1b0>
    50d4:	f94006d3 	ldr	x19, [x22, #8]
    50d8:	17ffff94 	b	4f28 <fwp_p_ad_push+0x84>
    50dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    50e0:	d65f03c0 	ret
    50e4:	f9401a60 	ldr	x0, [x19, #48]
    50e8:	d37cee9b 	lsl	x27, x20, #4
    50ec:	aa1b03e1 	mov	x1, x27
    50f0:	97fff5e0 	bl	2870 <realloc@plt>
    50f4:	aa0003e3 	mov	x3, x0
    50f8:	b4000660 	cbz	x0, 51c4 <fwp_p_ad_push+0x320>
    50fc:	8b1a0004 	add	x4, x0, x26
    5100:	f9400e60 	ldr	x0, [x19, #24]
    5104:	8b000c61 	add	x1, x3, x0, lsl #3
    5108:	a9030663 	stp	x3, x1, [x19, #48]
    510c:	b5000356 	cbnz	x22, 5174 <fwp_p_ad_push+0x2d0>
    5110:	f9401260 	ldr	x0, [x19, #32]
    5114:	d37ef69a 	lsl	x26, x20, #2
    5118:	d2800016 	mov	x22, #0x0                   	// #0
    511c:	f9001e64 	str	x4, [x19, #56]
    5120:	17ffffc9 	b	5044 <fwp_p_ad_push+0x1a0>
    5124:	aa1403e0 	mov	x0, x20
    5128:	97fff9e2 	bl	38b0 <fwp_tape_of>
    512c:	aa0003f3 	mov	x19, x0
    5130:	f9403000 	ldr	x0, [x0, #96]
    5134:	b4ffefa0 	cbz	x0, 4f28 <fwp_p_ad_push+0x84>
    5138:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    513c:	912c2000 	add	x0, x0, #0xb08
    5140:	a9046bf9 	stp	x25, x26, [sp, #64]
    5144:	a90573fb 	stp	x27, x28, [sp, #80]
    5148:	97fff90e 	bl	3580 <fwp_trap>
    514c:	d37df2d9 	lsl	x25, x22, #3
    5150:	f9401661 	ldr	x1, [x19, #40]
    5154:	d37ef6d6 	lsl	x22, x22, #2
    5158:	d37ef69a 	lsl	x26, x20, #2
    515c:	aa1603e2 	mov	x2, x22
    5160:	8b1a0000 	add	x0, x0, x26
    5164:	97fff563 	bl	26f0 <memmove@plt>
    5168:	f9401260 	ldr	x0, [x19, #32]
    516c:	a9431263 	ldp	x3, x4, [x19, #48]
    5170:	17ffffb5 	b	5044 <fwp_p_ad_push+0x1a0>
    5174:	eb1b035f 	cmp	x26, x27
    5178:	d37df2d9 	lsl	x25, x22, #3
    517c:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5180:	aa0403e0 	mov	x0, x4
    5184:	cb1a0063 	sub	x3, x3, x26
    5188:	aa1903e2 	mov	x2, x25
    518c:	97fff625 	bl	2a20 <__memmove_chk@plt>
    5190:	f9401a61 	ldr	x1, [x19, #48]
    5194:	f9401260 	ldr	x0, [x19, #32]
    5198:	8b1a0021 	add	x1, x1, x26
    519c:	f9001e61 	str	x1, [x19, #56]
    51a0:	17ffffec 	b	5150 <fwp_p_ad_push+0x2ac>
    51a4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    51a8:	912d6000 	add	x0, x0, #0xb58
    51ac:	a90573fb 	stp	x27, x28, [sp, #80]
    51b0:	97fff8f4 	bl	3580 <fwp_trap>
    51b4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    51b8:	912ce000 	add	x0, x0, #0xb38
    51bc:	a90573fb 	stp	x27, x28, [sp, #80]
    51c0:	97fff8f0 	bl	3580 <fwp_trap>
    51c4:	aa1303e0 	mov	x0, x19
    51c8:	97fff772 	bl	2f90 <fwp_tape_unlink_scope>
    51cc:	f9401260 	ldr	x0, [x19, #32]
    51d0:	97fff5dc 	bl	2940 <free@plt>
    51d4:	f9401a60 	ldr	x0, [x19, #48]
    51d8:	97fff5da 	bl	2940 <free@plt>
    51dc:	f9402260 	ldr	x0, [x19, #64]
    51e0:	97fff5d8 	bl	2940 <free@plt>
    51e4:	f9000e7f 	str	xzr, [x19, #24]
    51e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    51ec:	f947e821 	ldr	x1, [x1, #4048]
    51f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51f4:	d2800262 	mov	x2, #0x13                  	// #19
    51f8:	4f000400 	movi	v0.4s, #0x0
    51fc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    5200:	f9400023 	ldr	x3, [x1]
    5204:	b900067f 	str	wzr, [x19, #4]
    5208:	d2800021 	mov	x1, #0x1                   	// #1
    520c:	911f6000 	add	x0, x0, #0x7d8
    5210:	3c808260 	stur	q0, [x19, #8]
    5214:	ad010260 	stp	q0, q0, [x19, #32]
    5218:	97fff5da 	bl	2980 <fwrite@plt>
    521c:	d2800000 	mov	x0, #0x0                   	// #0
    5220:	97fff5e4 	bl	29b0 <fflush@plt>
    5224:	52800cc0 	mov	w0, #0x66                  	// #102
    5228:	97fff5f2 	bl	29f0 <_Exit@plt>
    522c:	d503201f 	nop

0000000000005230 <w120>:
    5230:	d10203ff 	sub	sp, sp, #0x80
    5234:	9e660003 	fmov	x3, d0
    5238:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    523c:	f947f442 	ldr	x2, [x2, #4072]
    5240:	a9027bfd 	stp	x29, x30, [sp, #32]
    5244:	910083fd 	add	x29, sp, #0x20
    5248:	6d0627e8 	stp	d8, d9, [sp, #96]
    524c:	1e604009 	fmov	d9, d0
    5250:	1e604028 	fmov	d8, d1
    5254:	fd003bea 	str	d10, [sp, #112]
    5258:	1e60080a 	fmul	d10, d0, d0
    525c:	a90353f3 	stp	x19, x20, [sp, #48]
    5260:	910023f3 	add	x19, sp, #0x8
    5264:	aa0003f4 	mov	x20, x0
    5268:	a9045bf5 	stp	x21, x22, [sp, #64]
    526c:	aa0103f6 	mov	x22, x1
    5270:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5274:	a90563f7 	stp	x23, x24, [sp, #80]
    5278:	aa0303e1 	mov	x1, x3
    527c:	f9400044 	ldr	x4, [x2]
    5280:	f9000fe4 	str	x4, [sp, #24]
    5284:	d2800004 	mov	x4, #0x0                   	// #0
    5288:	aa0003e2 	mov	x2, x0
    528c:	aa1303e4 	mov	x4, x19
    5290:	a900fff5 	stp	x21, xzr, [sp, #8]
    5294:	97ffff04 	bl	4ea4 <fwp_p_ad_push>
    5298:	1e6a3908 	fsub	d8, d8, d10
    529c:	aa1603e2 	mov	x2, x22
    52a0:	aa1303e4 	mov	x4, x19
    52a4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52a8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    52ac:	9e660118 	fmov	x24, d8
    52b0:	97fffefd 	bl	4ea4 <fwp_p_ad_push>
    52b4:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    52b8:	aa0003f6 	mov	x22, x0
    52bc:	aa1303e4 	mov	x4, x19
    52c0:	aa1403e0 	mov	x0, x20
    52c4:	1e69394a 	fsub	d10, d10, d9
    52c8:	aa1503e2 	mov	x2, x21
    52cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52d0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    52d4:	9e660157 	fmov	x23, d10
    52d8:	97fffef3 	bl	4ea4 <fwp_p_ad_push>
    52dc:	1e680908 	fmul	d8, d8, d8
    52e0:	aa0003f4 	mov	x20, x0
    52e4:	aa1303e4 	mov	x4, x19
    52e8:	aa1803e3 	mov	x3, x24
    52ec:	aa1803e1 	mov	x1, x24
    52f0:	aa1603e2 	mov	x2, x22
    52f4:	aa1603e0 	mov	x0, x22
    52f8:	97fffeeb 	bl	4ea4 <fwp_p_ad_push>
    52fc:	aa0003e2 	mov	x2, x0
    5300:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5304:	9e670029 	fmov	d9, x1
    5308:	9e660101 	fmov	x1, d8
    530c:	aa1303e4 	mov	x4, x19
    5310:	1e690909 	fmul	d9, d8, d9
    5314:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5318:	aa1503e0 	mov	x0, x21
    531c:	97fffee2 	bl	4ea4 <fwp_p_ad_push>
    5320:	1e6a094a 	fmul	d10, d10, d10
    5324:	aa1303e4 	mov	x4, x19
    5328:	aa1703e3 	mov	x3, x23
    532c:	aa0003f3 	mov	x19, x0
    5330:	aa1703e1 	mov	x1, x23
    5334:	aa1403e2 	mov	x2, x20
    5338:	aa1403e0 	mov	x0, x20
    533c:	97fffeda 	bl	4ea4 <fwp_p_ad_push>
    5340:	1e6a2929 	fadd	d9, d9, d10
    5344:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5348:	d2800004 	mov	x4, #0x0                   	// #0
    534c:	aa0303e1 	mov	x1, x3
    5350:	aa1303e2 	mov	x2, x19
    5354:	97fffed4 	bl	4ea4 <fwp_p_ad_push>
    5358:	aa0003e1 	mov	x1, x0
    535c:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    5360:	f947f463 	ldr	x3, [x3, #4072]
    5364:	f9400fe0 	ldr	x0, [sp, #24]
    5368:	f9400064 	ldr	x4, [x3]
    536c:	eb040000 	subs	x0, x0, x4
    5370:	d2800004 	mov	x4, #0x0                   	// #0
    5374:	54000161 	b.ne	53a0 <w120+0x170>  // b.any
    5378:	9e660122 	fmov	x2, d9
    537c:	fd403bea 	ldr	d10, [sp, #112]
    5380:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5384:	a94353f3 	ldp	x19, x20, [sp, #48]
    5388:	aa0203e0 	mov	x0, x2
    538c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5390:	a94563f7 	ldp	x23, x24, [sp, #80]
    5394:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5398:	910203ff 	add	sp, sp, #0x80
    539c:	d65f03c0 	ret
    53a0:	97fff538 	bl	2880 <__stack_chk_fail@plt>

00000000000053a4 <w176.constprop.0>:
    53a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53a8:	910003fd 	mov	x29, sp
    53ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    53b0:	fd001be8 	str	d8, [sp, #48]
    53b4:	f9400015 	ldr	x21, [x0]
    53b8:	b4000355 	cbz	x21, 5420 <w176.constprop.0+0x7c>
    53bc:	2f00e408 	movi	d8, #0x0
    53c0:	91002016 	add	x22, x0, #0x8
    53c4:	a90153f3 	stp	x19, x20, [sp, #16]
    53c8:	91004014 	add	x20, x0, #0x10
    53cc:	d2800013 	mov	x19, #0x0                   	// #0
    53d0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53d4:	d503201f 	nop
    53d8:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    53dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    53e0:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    53e4:	aa0303e1 	mov	x1, x3
    53e8:	1e602908 	fadd	d8, d8, d0
    53ec:	d2800004 	mov	x4, #0x0                   	// #0
    53f0:	91000a73 	add	x19, x19, #0x2
    53f4:	97fffeac 	bl	4ea4 <fwp_p_ad_push>
    53f8:	eb1302bf 	cmp	x21, x19
    53fc:	54fffee8 	b.hi	53d8 <w176.constprop.0+0x34>  // b.pmore
    5400:	9e660102 	fmov	x2, d8
    5404:	fd401be8 	ldr	d8, [sp, #48]
    5408:	a94153f3 	ldp	x19, x20, [sp, #16]
    540c:	aa0003e1 	mov	x1, x0
    5410:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5414:	aa0203e0 	mov	x0, x2
    5418:	a8c47bfd 	ldp	x29, x30, [sp], #64
    541c:	d65f03c0 	ret
    5420:	2f00e408 	movi	d8, #0x0
    5424:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5428:	a9425bf5 	ldp	x21, x22, [sp, #32]
    542c:	aa0003e1 	mov	x1, x0
    5430:	9e660102 	fmov	x2, d8
    5434:	fd401be8 	ldr	d8, [sp, #48]
    5438:	a8c47bfd 	ldp	x29, x30, [sp], #64
    543c:	aa0203e0 	mov	x0, x2
    5440:	d65f03c0 	ret

0000000000005444 <fwp_rc_share>:
    5444:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5448:	91150042 	add	x2, x2, #0x540
    544c:	f949d843 	ldr	x3, [x2, #5040]
    5450:	f949ec41 	ldr	x1, [x2, #5080]
    5454:	cb030000 	sub	x0, x0, x3
    5458:	eb01401f 	cmp	x0, x1, lsl #16
    545c:	540002c2 	b.cs	54b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5460:	d350fc01 	lsr	x1, x0, #16
    5464:	f949fc44 	ldr	x4, [x2, #5112]
    5468:	8b010821 	add	x1, x1, x1, lsl #2
    546c:	d37df021 	lsl	x1, x1, #3
    5470:	8b010083 	add	x3, x4, x1
    5474:	f9401062 	ldr	x2, [x3, #32]
    5478:	b40001e2 	cbz	x2, 54b4 <fwp_rc_share+0x70>
    547c:	38616881 	ldrb	w1, [x4, x1]
    5480:	7100083f 	cmp	w1, #0x2
    5484:	540001a0 	b.eq	54b8 <fwp_rc_share+0x74>  // b.none
    5488:	7100043f 	cmp	w1, #0x1
    548c:	54000141 	b.ne	54b4 <fwp_rc_share+0x70>  // b.any
    5490:	29430464 	ldp	w4, w1, [x3, #24]
    5494:	92403c00 	and	x0, x0, #0xffff
    5498:	9b047c00 	mul	x0, x0, x4
    549c:	d360fc00 	lsr	x0, x0, #32
    54a0:	eb01001f 	cmp	x0, x1
    54a4:	54000082 	b.cs	54b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    54a8:	8b000042 	add	x2, x2, x0
    54ac:	39400040 	ldrb	w0, [x2]
    54b0:	350000a0 	cbnz	w0, 54c4 <fwp_rc_share+0x80>
    54b4:	d65f03c0 	ret
    54b8:	72003c1f 	tst	w0, #0xffff
    54bc:	54ffff80 	b.eq	54ac <fwp_rc_share+0x68>  // b.none
    54c0:	d65f03c0 	ret
    54c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    54c8:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    54cc:	912de000 	add	x0, x0, #0xb78
    54d0:	910003fd 	mov	x29, sp
    54d4:	97fff82b 	bl	3580 <fwp_trap>
    54d8:	d503201f 	nop
    54dc:	d503201f 	nop

00000000000054e0 <fwp_rc_free_arr>:
    54e0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    54e4:	91150063 	add	x3, x3, #0x540
    54e8:	f949d861 	ldr	x1, [x3, #5040]
    54ec:	f949ec62 	ldr	x2, [x3, #5080]
    54f0:	cb010001 	sub	x1, x0, x1
    54f4:	eb02403f 	cmp	x1, x2, lsl #16
    54f8:	54000342 	b.cs	5560 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    54fc:	d350fc22 	lsr	x2, x1, #16
    5500:	f949fc65 	ldr	x5, [x3, #5112]
    5504:	8b020842 	add	x2, x2, x2, lsl #2
    5508:	d37df042 	lsl	x2, x2, #3
    550c:	8b0200a4 	add	x4, x5, x2
    5510:	f9401083 	ldr	x3, [x4, #32]
    5514:	b4000263 	cbz	x3, 5560 <fwp_rc_free_arr+0x80>
    5518:	386268a2 	ldrb	w2, [x5, x2]
    551c:	7100085f 	cmp	w2, #0x2
    5520:	540001c0 	b.eq	5558 <fwp_rc_free_arr+0x78>  // b.none
    5524:	7100045f 	cmp	w2, #0x1
    5528:	540001c1 	b.ne	5560 <fwp_rc_free_arr+0x80>  // b.any
    552c:	29430885 	ldp	w5, w2, [x4, #24]
    5530:	92403c21 	and	x1, x1, #0xffff
    5534:	9b057c21 	mul	x1, x1, x5
    5538:	d360fc21 	lsr	x1, x1, #32
    553c:	eb02003f 	cmp	x1, x2
    5540:	54000102 	b.cs	5560 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5544:	8b010063 	add	x3, x3, x1
    5548:	39400061 	ldrb	w1, [x3]
    554c:	7100043f 	cmp	w1, #0x1
    5550:	54000081 	b.ne	5560 <fwp_rc_free_arr+0x80>  // b.any
    5554:	17fffca7 	b	47f0 <fwp_mem_free>
    5558:	72003c3f 	tst	w1, #0xffff
    555c:	54ffff60 	b.eq	5548 <fwp_rc_free_arr+0x68>  // b.none
    5560:	d65f03c0 	ret

0000000000005564 <fwp_rc_dup>:
    5564:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5568:	91150042 	add	x2, x2, #0x540
    556c:	f949d841 	ldr	x1, [x2, #5040]
    5570:	f949ec43 	ldr	x3, [x2, #5080]
    5574:	cb010001 	sub	x1, x0, x1
    5578:	eb03403f 	cmp	x1, x3, lsl #16
    557c:	54000342 	b.cs	55e4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5580:	d350fc20 	lsr	x0, x1, #16
    5584:	f949fc44 	ldr	x4, [x2, #5112]
    5588:	8b000800 	add	x0, x0, x0, lsl #2
    558c:	d37df002 	lsl	x2, x0, #3
    5590:	8b020083 	add	x3, x4, x2
    5594:	f9401060 	ldr	x0, [x3, #32]
    5598:	b4000260 	cbz	x0, 55e4 <fwp_rc_dup+0x80>
    559c:	38626882 	ldrb	w2, [x4, x2]
    55a0:	7100085f 	cmp	w2, #0x2
    55a4:	54000220 	b.eq	55e8 <fwp_rc_dup+0x84>  // b.none
    55a8:	7100045f 	cmp	w2, #0x1
    55ac:	540001c1 	b.ne	55e4 <fwp_rc_dup+0x80>  // b.any
    55b0:	29430864 	ldp	w4, w2, [x3, #24]
    55b4:	92403c21 	and	x1, x1, #0xffff
    55b8:	9b047c21 	mul	x1, x1, x4
    55bc:	d360fc21 	lsr	x1, x1, #32
    55c0:	eb02003f 	cmp	x1, x2
    55c4:	54000102 	b.cs	55e4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    55c8:	8b010000 	add	x0, x0, x1
    55cc:	39400001 	ldrb	w1, [x0]
    55d0:	340000a1 	cbz	w1, 55e4 <fwp_rc_dup+0x80>
    55d4:	7103f43f 	cmp	w1, #0xfd
    55d8:	540000e8 	b.hi	55f4 <fwp_rc_dup+0x90>  // b.pmore
    55dc:	11000421 	add	w1, w1, #0x1
    55e0:	39000001 	strb	w1, [x0]
    55e4:	d65f03c0 	ret
    55e8:	72003c3f 	tst	w1, #0xffff
    55ec:	54ffff00 	b.eq	55cc <fwp_rc_dup+0x68>  // b.none
    55f0:	d65f03c0 	ret
    55f4:	17fffb98 	b	4454 <fwp_rc_wide_dup>
    55f8:	d503201f 	nop
    55fc:	d503201f 	nop

0000000000005600 <fwp_owned_entry173>:
    5600:	d10103ff 	sub	sp, sp, #0x40
    5604:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5608:	f947f442 	ldr	x2, [x2, #4072]
    560c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5610:	910083fd 	add	x29, sp, #0x20
    5614:	a90353f3 	stp	x19, x20, [sp, #48]
    5618:	f9400043 	ldr	x3, [x2]
    561c:	f9000fe3 	str	x3, [sp, #24]
    5620:	d2800003 	mov	x3, #0x0                   	// #0
    5624:	a9400c01 	ldp	x1, x3, [x0]
    5628:	f9400802 	ldr	x2, [x0, #16]
    562c:	ab020022 	adds	x2, x1, x2
    5630:	540006e6 	b.vs	570c <fwp_owned_entry173+0x10c>
    5634:	910023e1 	add	x1, sp, #0x8
    5638:	52800000 	mov	w0, #0x0                   	// #0
    563c:	a9008be3 	stp	x3, x2, [sp, #8]
    5640:	97fffdd1 	bl	4d84 <fwp_data.part.0.constprop.0>
    5644:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5648:	91150063 	add	x3, x3, #0x540
    564c:	aa0003f3 	mov	x19, x0
    5650:	f949d861 	ldr	x1, [x3, #5040]
    5654:	f949ec60 	ldr	x0, [x3, #5080]
    5658:	cb010261 	sub	x1, x19, x1
    565c:	eb00403f 	cmp	x1, x0, lsl #16
    5660:	54000322 	b.cs	56c4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5664:	d350fc22 	lsr	x2, x1, #16
    5668:	f949fc63 	ldr	x3, [x3, #5112]
    566c:	8b020842 	add	x2, x2, x2, lsl #2
    5670:	d37df042 	lsl	x2, x2, #3
    5674:	8b020060 	add	x0, x3, x2
    5678:	f9401014 	ldr	x20, [x0, #32]
    567c:	b4000254 	cbz	x20, 56c4 <fwp_owned_entry173+0xc4>
    5680:	38626862 	ldrb	w2, [x3, x2]
    5684:	7100085f 	cmp	w2, #0x2
    5688:	54000360 	b.eq	56f4 <fwp_owned_entry173+0xf4>  // b.none
    568c:	7100045f 	cmp	w2, #0x1
    5690:	540001a1 	b.ne	56c4 <fwp_owned_entry173+0xc4>  // b.any
    5694:	29430002 	ldp	w2, w0, [x0, #24]
    5698:	92403c21 	and	x1, x1, #0xffff
    569c:	9b027c21 	mul	x1, x1, x2
    56a0:	d360fc21 	lsr	x1, x1, #32
    56a4:	eb00003f 	cmp	x1, x0
    56a8:	540000e2 	b.cs	56c4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    56ac:	8b010294 	add	x20, x20, x1
    56b0:	39400280 	ldrb	w0, [x20]
    56b4:	7103fc1f 	cmp	w0, #0xff
    56b8:	54000240 	b.eq	5700 <fwp_owned_entry173+0x100>  // b.none
    56bc:	52800020 	mov	w0, #0x1                   	// #1
    56c0:	39000280 	strb	w0, [x20]
    56c4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    56c8:	f947f400 	ldr	x0, [x0, #4072]
    56cc:	f9400fe2 	ldr	x2, [sp, #24]
    56d0:	f9400001 	ldr	x1, [x0]
    56d4:	eb010042 	subs	x2, x2, x1
    56d8:	d2800001 	mov	x1, #0x0                   	// #0
    56dc:	540001a1 	b.ne	5710 <fwp_owned_entry173+0x110>  // b.any
    56e0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    56e4:	aa1303e0 	mov	x0, x19
    56e8:	a94353f3 	ldp	x19, x20, [sp, #48]
    56ec:	910103ff 	add	sp, sp, #0x40
    56f0:	d65f03c0 	ret
    56f4:	72003c3f 	tst	w1, #0xffff
    56f8:	54fffe61 	b.ne	56c4 <fwp_owned_entry173+0xc4>  // b.any
    56fc:	17ffffed 	b	56b0 <fwp_owned_entry173+0xb0>
    5700:	aa1403e0 	mov	x0, x20
    5704:	97fffb9b 	bl	4570 <fwp_rc_forget_slot>
    5708:	17ffffed 	b	56bc <fwp_owned_entry173+0xbc>
    570c:	97fff4dd 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5710:	97fff45c 	bl	2880 <__stack_chk_fail@plt>

0000000000005714 <e173>:
    5714:	d10103ff 	sub	sp, sp, #0x40
    5718:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    571c:	f947f442 	ldr	x2, [x2, #4072]
    5720:	a9027bfd 	stp	x29, x30, [sp, #32]
    5724:	910083fd 	add	x29, sp, #0x20
    5728:	a90353f3 	stp	x19, x20, [sp, #48]
    572c:	f9400043 	ldr	x3, [x2]
    5730:	f9000fe3 	str	x3, [sp, #24]
    5734:	d2800003 	mov	x3, #0x0                   	// #0
    5738:	a9400c01 	ldp	x1, x3, [x0]
    573c:	f9400802 	ldr	x2, [x0, #16]
    5740:	ab020022 	adds	x2, x1, x2
    5744:	54000726 	b.vs	5828 <e173+0x114>
    5748:	910023e1 	add	x1, sp, #0x8
    574c:	52800000 	mov	w0, #0x0                   	// #0
    5750:	a9008be3 	stp	x3, x2, [sp, #8]
    5754:	97fffd8c 	bl	4d84 <fwp_data.part.0.constprop.0>
    5758:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    575c:	91150063 	add	x3, x3, #0x540
    5760:	aa0003f3 	mov	x19, x0
    5764:	f949d861 	ldr	x1, [x3, #5040]
    5768:	f949ec60 	ldr	x0, [x3, #5080]
    576c:	cb010261 	sub	x1, x19, x1
    5770:	eb00403f 	cmp	x1, x0, lsl #16
    5774:	54000322 	b.cs	57d8 <e173+0xc4>  // b.hs, b.nlast
    5778:	d350fc22 	lsr	x2, x1, #16
    577c:	f949fc63 	ldr	x3, [x3, #5112]
    5780:	8b020842 	add	x2, x2, x2, lsl #2
    5784:	d37df042 	lsl	x2, x2, #3
    5788:	8b020060 	add	x0, x3, x2
    578c:	f9401014 	ldr	x20, [x0, #32]
    5790:	b4000254 	cbz	x20, 57d8 <e173+0xc4>
    5794:	38626862 	ldrb	w2, [x3, x2]
    5798:	7100085f 	cmp	w2, #0x2
    579c:	540003a0 	b.eq	5810 <e173+0xfc>  // b.none
    57a0:	7100045f 	cmp	w2, #0x1
    57a4:	540001a1 	b.ne	57d8 <e173+0xc4>  // b.any
    57a8:	29430002 	ldp	w2, w0, [x0, #24]
    57ac:	92403c21 	and	x1, x1, #0xffff
    57b0:	9b027c21 	mul	x1, x1, x2
    57b4:	d360fc21 	lsr	x1, x1, #32
    57b8:	eb00003f 	cmp	x1, x0
    57bc:	540000e2 	b.cs	57d8 <e173+0xc4>  // b.hs, b.nlast
    57c0:	8b010294 	add	x20, x20, x1
    57c4:	39400280 	ldrb	w0, [x20]
    57c8:	7103fc1f 	cmp	w0, #0xff
    57cc:	54000280 	b.eq	581c <e173+0x108>  // b.none
    57d0:	52800020 	mov	w0, #0x1                   	// #1
    57d4:	39000280 	strb	w0, [x20]
    57d8:	aa1303e0 	mov	x0, x19
    57dc:	97ffff1a 	bl	5444 <fwp_rc_share>
    57e0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    57e4:	f947f400 	ldr	x0, [x0, #4072]
    57e8:	f9400fe2 	ldr	x2, [sp, #24]
    57ec:	f9400001 	ldr	x1, [x0]
    57f0:	eb010042 	subs	x2, x2, x1
    57f4:	d2800001 	mov	x1, #0x0                   	// #0
    57f8:	540001a1 	b.ne	582c <e173+0x118>  // b.any
    57fc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5800:	aa1303e0 	mov	x0, x19
    5804:	a94353f3 	ldp	x19, x20, [sp, #48]
    5808:	910103ff 	add	sp, sp, #0x40
    580c:	d65f03c0 	ret
    5810:	72003c3f 	tst	w1, #0xffff
    5814:	54fffe21 	b.ne	57d8 <e173+0xc4>  // b.any
    5818:	17ffffeb 	b	57c4 <e173+0xb0>
    581c:	aa1403e0 	mov	x0, x20
    5820:	97fffb54 	bl	4570 <fwp_rc_forget_slot>
    5824:	17ffffeb 	b	57d0 <e173+0xbc>
    5828:	97fff496 	bl	2a80 <fwp_trap_overflow.constprop.0>
    582c:	97fff415 	bl	2880 <__stack_chk_fail@plt>

0000000000005830 <fwp_drop0>:
    5830:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5834:	910003fd 	mov	x29, sp
    5838:	a90153f3 	stp	x19, x20, [sp, #16]
    583c:	f90013f5 	str	x21, [sp, #32]
    5840:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5844:	911502b4 	add	x20, x21, #0x540
    5848:	f949da81 	ldr	x1, [x20, #5040]
    584c:	f949ee82 	ldr	x2, [x20, #5080]
    5850:	cb010001 	sub	x1, x0, x1
    5854:	eb02403f 	cmp	x1, x2, lsl #16
    5858:	54000382 	b.cs	58c8 <fwp_drop0+0x98>  // b.hs, b.nlast
    585c:	d350fc22 	lsr	x2, x1, #16
    5860:	f949fe84 	ldr	x4, [x20, #5112]
    5864:	8b020842 	add	x2, x2, x2, lsl #2
    5868:	d37df042 	lsl	x2, x2, #3
    586c:	8b020083 	add	x3, x4, x2
    5870:	f9401073 	ldr	x19, [x3, #32]
    5874:	b40002b3 	cbz	x19, 58c8 <fwp_drop0+0x98>
    5878:	38626882 	ldrb	w2, [x4, x2]
    587c:	7100085f 	cmp	w2, #0x2
    5880:	540002c0 	b.eq	58d8 <fwp_drop0+0xa8>  // b.none
    5884:	7100045f 	cmp	w2, #0x1
    5888:	54000201 	b.ne	58c8 <fwp_drop0+0x98>  // b.any
    588c:	29430864 	ldp	w4, w2, [x3, #24]
    5890:	92403c21 	and	x1, x1, #0xffff
    5894:	9b047c21 	mul	x1, x1, x4
    5898:	d360fc21 	lsr	x1, x1, #32
    589c:	eb02003f 	cmp	x1, x2
    58a0:	54000142 	b.cs	58c8 <fwp_drop0+0x98>  // b.hs, b.nlast
    58a4:	8b010273 	add	x19, x19, x1
    58a8:	39400261 	ldrb	w1, [x19]
    58ac:	340000e1 	cbz	w1, 58c8 <fwp_drop0+0x98>
    58b0:	7100043f 	cmp	w1, #0x1
    58b4:	540001e0 	b.eq	58f0 <fwp_drop0+0xc0>  // b.none
    58b8:	7103fc3f 	cmp	w1, #0xff
    58bc:	540002e0 	b.eq	5918 <fwp_drop0+0xe8>  // b.none
    58c0:	51000421 	sub	w1, w1, #0x1
    58c4:	39000261 	strb	w1, [x19]
    58c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    58cc:	f94013f5 	ldr	x21, [sp, #32]
    58d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    58d4:	d65f03c0 	ret
    58d8:	72003c3f 	tst	w1, #0xffff
    58dc:	54fffe60 	b.eq	58a8 <fwp_drop0+0x78>  // b.none
    58e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    58e4:	f94013f5 	ldr	x21, [sp, #32]
    58e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    58ec:	d65f03c0 	ret
    58f0:	f9400813 	ldr	x19, [x0, #16]
    58f4:	97fffefb 	bl	54e0 <fwp_rc_free_arr>
    58f8:	911502a0 	add	x0, x21, #0x540
    58fc:	f949d801 	ldr	x1, [x0, #5040]
    5900:	f949ec00 	ldr	x0, [x0, #5080]
    5904:	cb010261 	sub	x1, x19, x1
    5908:	eb00403f 	cmp	x1, x0, lsl #16
    590c:	54fffde2 	b.cs	58c8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5910:	aa1303e0 	mov	x0, x19
    5914:	17ffffd2 	b	585c <fwp_drop0+0x2c>
    5918:	ca534660 	eor	x0, x19, x19, lsr #17
    591c:	911502b5 	add	x21, x21, #0x540
    5920:	ca402400 	eor	x0, x0, x0, lsr #9
    5924:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5928:	f94a2400 	ldr	x0, [x0, #5192]
    592c:	b5000080 	cbnz	x0, 593c <fwp_drop0+0x10c>
    5930:	14000010 	b	5970 <fwp_drop0+0x140>
    5934:	f9400800 	ldr	x0, [x0, #16]
    5938:	b40001c0 	cbz	x0, 5970 <fwp_drop0+0x140>
    593c:	f9400001 	ldr	x1, [x0]
    5940:	eb13003f 	cmp	x1, x19
    5944:	54ffff81 	b.ne	5934 <fwp_drop0+0x104>  // b.any
    5948:	f9400401 	ldr	x1, [x0, #8]
    594c:	d1000421 	sub	x1, x1, #0x1
    5950:	f9000401 	str	x1, [x0, #8]
    5954:	f103f83f 	cmp	x1, #0xfe
    5958:	54fffb81 	b.ne	58c8 <fwp_drop0+0x98>  // b.any
    595c:	aa1303e0 	mov	x0, x19
    5960:	97fffb04 	bl	4570 <fwp_rc_forget_slot>
    5964:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5968:	39000260 	strb	w0, [x19]
    596c:	17ffffd7 	b	58c8 <fwp_drop0+0x98>
    5970:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    5974:	9129e000 	add	x0, x0, #0xa78
    5978:	97fff702 	bl	3580 <fwp_trap>
    597c:	d503201f 	nop

0000000000005980 <fwp_drop1>:
    5980:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5984:	910003fd 	mov	x29, sp
    5988:	a90153f3 	stp	x19, x20, [sp, #16]
    598c:	f90013f5 	str	x21, [sp, #32]
    5990:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5994:	911502b4 	add	x20, x21, #0x540
    5998:	f949da81 	ldr	x1, [x20, #5040]
    599c:	f949ee82 	ldr	x2, [x20, #5080]
    59a0:	cb010001 	sub	x1, x0, x1
    59a4:	eb02403f 	cmp	x1, x2, lsl #16
    59a8:	54000382 	b.cs	5a18 <fwp_drop1+0x98>  // b.hs, b.nlast
    59ac:	d350fc22 	lsr	x2, x1, #16
    59b0:	f949fe84 	ldr	x4, [x20, #5112]
    59b4:	8b020842 	add	x2, x2, x2, lsl #2
    59b8:	d37df042 	lsl	x2, x2, #3
    59bc:	8b020083 	add	x3, x4, x2
    59c0:	f9401073 	ldr	x19, [x3, #32]
    59c4:	b40002b3 	cbz	x19, 5a18 <fwp_drop1+0x98>
    59c8:	38626882 	ldrb	w2, [x4, x2]
    59cc:	7100085f 	cmp	w2, #0x2
    59d0:	540002c0 	b.eq	5a28 <fwp_drop1+0xa8>  // b.none
    59d4:	7100045f 	cmp	w2, #0x1
    59d8:	54000201 	b.ne	5a18 <fwp_drop1+0x98>  // b.any
    59dc:	29430864 	ldp	w4, w2, [x3, #24]
    59e0:	92403c21 	and	x1, x1, #0xffff
    59e4:	9b047c21 	mul	x1, x1, x4
    59e8:	d360fc21 	lsr	x1, x1, #32
    59ec:	eb02003f 	cmp	x1, x2
    59f0:	54000142 	b.cs	5a18 <fwp_drop1+0x98>  // b.hs, b.nlast
    59f4:	8b010273 	add	x19, x19, x1
    59f8:	39400261 	ldrb	w1, [x19]
    59fc:	340000e1 	cbz	w1, 5a18 <fwp_drop1+0x98>
    5a00:	7100043f 	cmp	w1, #0x1
    5a04:	540001e0 	b.eq	5a40 <fwp_drop1+0xc0>  // b.none
    5a08:	7103fc3f 	cmp	w1, #0xff
    5a0c:	540002e0 	b.eq	5a68 <fwp_drop1+0xe8>  // b.none
    5a10:	51000421 	sub	w1, w1, #0x1
    5a14:	39000261 	strb	w1, [x19]
    5a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a1c:	f94013f5 	ldr	x21, [sp, #32]
    5a20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a24:	d65f03c0 	ret
    5a28:	72003c3f 	tst	w1, #0xffff
    5a2c:	54fffe60 	b.eq	59f8 <fwp_drop1+0x78>  // b.none
    5a30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a34:	f94013f5 	ldr	x21, [sp, #32]
    5a38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a3c:	d65f03c0 	ret
    5a40:	f9400813 	ldr	x19, [x0, #16]
    5a44:	97fffea7 	bl	54e0 <fwp_rc_free_arr>
    5a48:	911502a0 	add	x0, x21, #0x540
    5a4c:	f949d801 	ldr	x1, [x0, #5040]
    5a50:	f949ec00 	ldr	x0, [x0, #5080]
    5a54:	cb010261 	sub	x1, x19, x1
    5a58:	eb00403f 	cmp	x1, x0, lsl #16
    5a5c:	54fffde2 	b.cs	5a18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a60:	aa1303e0 	mov	x0, x19
    5a64:	17ffffd2 	b	59ac <fwp_drop1+0x2c>
    5a68:	ca534660 	eor	x0, x19, x19, lsr #17
    5a6c:	911502b5 	add	x21, x21, #0x540
    5a70:	ca402400 	eor	x0, x0, x0, lsr #9
    5a74:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a78:	f94a2400 	ldr	x0, [x0, #5192]
    5a7c:	b5000080 	cbnz	x0, 5a8c <fwp_drop1+0x10c>
    5a80:	14000010 	b	5ac0 <fwp_drop1+0x140>
    5a84:	f9400800 	ldr	x0, [x0, #16]
    5a88:	b40001c0 	cbz	x0, 5ac0 <fwp_drop1+0x140>
    5a8c:	f9400001 	ldr	x1, [x0]
    5a90:	eb13003f 	cmp	x1, x19
    5a94:	54ffff81 	b.ne	5a84 <fwp_drop1+0x104>  // b.any
    5a98:	f9400401 	ldr	x1, [x0, #8]
    5a9c:	d1000421 	sub	x1, x1, #0x1
    5aa0:	f9000401 	str	x1, [x0, #8]
    5aa4:	f103f83f 	cmp	x1, #0xfe
    5aa8:	54fffb81 	b.ne	5a18 <fwp_drop1+0x98>  // b.any
    5aac:	aa1303e0 	mov	x0, x19
    5ab0:	97fffab0 	bl	4570 <fwp_rc_forget_slot>
    5ab4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ab8:	39000260 	strb	w0, [x19]
    5abc:	17ffffd7 	b	5a18 <fwp_drop1+0x98>
    5ac0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    5ac4:	9129e000 	add	x0, x0, #0xa78
    5ac8:	97fff6ae 	bl	3580 <fwp_trap>
    5acc:	d503201f 	nop

0000000000005ad0 <fwp_closure_drop>:
    5ad0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5ad4:	911500a4 	add	x4, x5, #0x540
    5ad8:	aa0003e1 	mov	x1, x0
    5adc:	f949d882 	ldr	x2, [x4, #5040]
    5ae0:	f949ec80 	ldr	x0, [x4, #5080]
    5ae4:	cb020022 	sub	x2, x1, x2
    5ae8:	eb00405f 	cmp	x2, x0, lsl #16
    5aec:	54000662 	b.cs	5bb8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5af0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5af4:	d350fc43 	lsr	x3, x2, #16
    5af8:	910003fd 	mov	x29, sp
    5afc:	8b030863 	add	x3, x3, x3, lsl #2
    5b00:	f949fc84 	ldr	x4, [x4, #5112]
    5b04:	d37df063 	lsl	x3, x3, #3
    5b08:	f9000bf3 	str	x19, [sp, #16]
    5b0c:	8b030080 	add	x0, x4, x3
    5b10:	f9401013 	ldr	x19, [x0, #32]
    5b14:	b40002b3 	cbz	x19, 5b68 <fwp_closure_drop+0x98>
    5b18:	38636883 	ldrb	w3, [x4, x3]
    5b1c:	7100087f 	cmp	w3, #0x2
    5b20:	54000420 	b.eq	5ba4 <fwp_closure_drop+0xd4>  // b.none
    5b24:	7100047f 	cmp	w3, #0x1
    5b28:	54000201 	b.ne	5b68 <fwp_closure_drop+0x98>  // b.any
    5b2c:	29430003 	ldp	w3, w0, [x0, #24]
    5b30:	92403c42 	and	x2, x2, #0xffff
    5b34:	9b037c42 	mul	x2, x2, x3
    5b38:	d360fc42 	lsr	x2, x2, #32
    5b3c:	eb00005f 	cmp	x2, x0
    5b40:	54000142 	b.cs	5b68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5b44:	8b020273 	add	x19, x19, x2
    5b48:	39400260 	ldrb	w0, [x19]
    5b4c:	340000e0 	cbz	w0, 5b68 <fwp_closure_drop+0x98>
    5b50:	7100041f 	cmp	w0, #0x1
    5b54:	54000100 	b.eq	5b74 <fwp_closure_drop+0xa4>  // b.none
    5b58:	7103fc1f 	cmp	w0, #0xff
    5b5c:	54000300 	b.eq	5bbc <fwp_closure_drop+0xec>  // b.none
    5b60:	51000400 	sub	w0, w0, #0x1
    5b64:	39000260 	strb	w0, [x19]
    5b68:	f9400bf3 	ldr	x19, [sp, #16]
    5b6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b70:	d65f03c0 	ret
    5b74:	d53bd040 	mrs	x0, tpidr_el0
    5b78:	91400000 	add	x0, x0, #0x0, lsl #12
    5b7c:	91004000 	add	x0, x0, #0x10
    5b80:	f9400000 	ldr	x0, [x0]
    5b84:	b4000080 	cbz	x0, 5b94 <fwp_closure_drop+0xc4>
    5b88:	f9400bf3 	ldr	x19, [sp, #16]
    5b8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b90:	17fff695 	b	35e4 <fwp_closure_drop_push>
    5b94:	f9400bf3 	ldr	x19, [sp, #16]
    5b98:	aa0103e0 	mov	x0, x1
    5b9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ba0:	17fff700 	b	37a0 <fwp_closure_drop.part.0>
    5ba4:	72003c5f 	tst	w2, #0xffff
    5ba8:	54fffd00 	b.eq	5b48 <fwp_closure_drop+0x78>  // b.none
    5bac:	f9400bf3 	ldr	x19, [sp, #16]
    5bb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5bb4:	d65f03c0 	ret
    5bb8:	d65f03c0 	ret
    5bbc:	ca534660 	eor	x0, x19, x19, lsr #17
    5bc0:	911500a5 	add	x5, x5, #0x540
    5bc4:	ca402400 	eor	x0, x0, x0, lsr #9
    5bc8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5bcc:	f94a2400 	ldr	x0, [x0, #5192]
    5bd0:	b5000080 	cbnz	x0, 5be0 <fwp_closure_drop+0x110>
    5bd4:	14000010 	b	5c14 <fwp_closure_drop+0x144>
    5bd8:	f9400800 	ldr	x0, [x0, #16]
    5bdc:	b40001c0 	cbz	x0, 5c14 <fwp_closure_drop+0x144>
    5be0:	f9400001 	ldr	x1, [x0]
    5be4:	eb13003f 	cmp	x1, x19
    5be8:	54ffff81 	b.ne	5bd8 <fwp_closure_drop+0x108>  // b.any
    5bec:	f9400401 	ldr	x1, [x0, #8]
    5bf0:	d1000421 	sub	x1, x1, #0x1
    5bf4:	f9000401 	str	x1, [x0, #8]
    5bf8:	f103f83f 	cmp	x1, #0xfe
    5bfc:	54fffb61 	b.ne	5b68 <fwp_closure_drop+0x98>  // b.any
    5c00:	aa1303e0 	mov	x0, x19
    5c04:	97fffa5b 	bl	4570 <fwp_rc_forget_slot>
    5c08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c0c:	39000260 	strb	w0, [x19]
    5c10:	17ffffd6 	b	5b68 <fwp_closure_drop+0x98>
    5c14:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    5c18:	9129e000 	add	x0, x0, #0xa78
    5c1c:	97fff659 	bl	3580 <fwp_trap>

0000000000005c20 <fwp_owned_tape_release>:
    5c20:	b4000940 	cbz	x0, 5d48 <fwp_owned_tape_release+0x128>
    5c24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c28:	910003fd 	mov	x29, sp
    5c2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5c30:	aa0003f3 	mov	x19, x0
    5c34:	f9400000 	ldr	x0, [x0]
    5c38:	b4000060 	cbz	x0, 5c44 <fwp_owned_tape_release+0x24>
    5c3c:	f9400661 	ldr	x1, [x19, #8]
    5c40:	f9000401 	str	x1, [x0, #8]
    5c44:	f9400661 	ldr	x1, [x19, #8]
    5c48:	b4000041 	cbz	x1, 5c50 <fwp_owned_tape_release+0x30>
    5c4c:	f9000020 	str	x0, [x1]
    5c50:	f9400a60 	ldr	x0, [x19, #16]
    5c54:	f9403401 	ldr	x1, [x0, #104]
    5c58:	b40005c1 	cbz	x1, 5d10 <fwp_owned_tape_release+0xf0>
    5c5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5c60:	eb00005f 	cmp	x2, x0
    5c64:	540002ed 	b.le	5cc0 <fwp_owned_tape_release+0xa0>
    5c68:	d2800014 	mov	x20, #0x0                   	// #0
    5c6c:	f90013f5 	str	x21, [sp, #32]
    5c70:	d2800015 	mov	x21, #0x0                   	// #0
    5c74:	d503201f 	nop
    5c78:	f9402260 	ldr	x0, [x19, #64]
    5c7c:	910006b5 	add	x21, x21, #0x1
    5c80:	f8746800 	ldr	x0, [x0, x20]
    5c84:	d63f0020 	blr	x1
    5c88:	f9402260 	ldr	x0, [x19, #64]
    5c8c:	f9400a61 	ldr	x1, [x19, #16]
    5c90:	8b140000 	add	x0, x0, x20
    5c94:	91004294 	add	x20, x20, #0x10
    5c98:	f9400400 	ldr	x0, [x0, #8]
    5c9c:	f9403421 	ldr	x1, [x1, #104]
    5ca0:	d63f0020 	blr	x1
    5ca4:	a9450261 	ldp	x1, x0, [x19, #80]
    5ca8:	cb010000 	sub	x0, x0, x1
    5cac:	eb15001f 	cmp	x0, x21
    5cb0:	f9400a60 	ldr	x0, [x19, #16]
    5cb4:	f9403401 	ldr	x1, [x0, #104]
    5cb8:	54fffe0c 	b.gt	5c78 <fwp_owned_tape_release+0x58>
    5cbc:	f94013f5 	ldr	x21, [sp, #32]
    5cc0:	f9403663 	ldr	x3, [x19, #104]
    5cc4:	f9401262 	ldr	x2, [x19, #32]
    5cc8:	f100007f 	cmp	x3, #0x0
    5ccc:	540001ed 	b.le	5d08 <fwp_owned_tape_release+0xe8>
    5cd0:	d2800014 	mov	x20, #0x0                   	// #0
    5cd4:	d503201f 	nop
    5cd8:	f9402660 	ldr	x0, [x19, #72]
    5cdc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5ce0:	eb02001f 	cmp	x0, x2
    5ce4:	540000c0 	b.eq	5cfc <fwp_owned_tape_release+0xdc>  // b.none
    5ce8:	d63f0020 	blr	x1
    5cec:	f9400a60 	ldr	x0, [x19, #16]
    5cf0:	f9401262 	ldr	x2, [x19, #32]
    5cf4:	f9403663 	ldr	x3, [x19, #104]
    5cf8:	f9403401 	ldr	x1, [x0, #104]
    5cfc:	91000694 	add	x20, x20, #0x1
    5d00:	eb14007f 	cmp	x3, x20
    5d04:	54fffeac 	b.gt	5cd8 <fwp_owned_tape_release+0xb8>
    5d08:	aa0203e0 	mov	x0, x2
    5d0c:	d63f0020 	blr	x1
    5d10:	f9401660 	ldr	x0, [x19, #40]
    5d14:	97ffff6f 	bl	5ad0 <fwp_closure_drop>
    5d18:	f9401a60 	ldr	x0, [x19, #48]
    5d1c:	97ffff6d 	bl	5ad0 <fwp_closure_drop>
    5d20:	f9401e60 	ldr	x0, [x19, #56]
    5d24:	97ffff6b 	bl	5ad0 <fwp_closure_drop>
    5d28:	f9402260 	ldr	x0, [x19, #64]
    5d2c:	97fffab1 	bl	47f0 <fwp_mem_free>
    5d30:	f9402660 	ldr	x0, [x19, #72]
    5d34:	97fffaaf 	bl	47f0 <fwp_mem_free>
    5d38:	aa1303e0 	mov	x0, x19
    5d3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d44:	17fffaab 	b	47f0 <fwp_mem_free>
    5d48:	d65f03c0 	ret
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_tape_finish>:
    5d50:	d10203ff 	sub	sp, sp, #0x80
    5d54:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5d58:	f947f421 	ldr	x1, [x1, #4072]
    5d5c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5d60:	910103fd 	add	x29, sp, #0x40
    5d64:	a90553f3 	stp	x19, x20, [sp, #80]
    5d68:	a9065bf5 	stp	x21, x22, [sp, #96]
    5d6c:	a90763f7 	stp	x23, x24, [sp, #112]
    5d70:	f00000d8 	adrp	x24, 20000 <__data_start>
    5d74:	9100c316 	add	x22, x24, #0x30
    5d78:	f9400022 	ldr	x2, [x1]
    5d7c:	f9001fe2 	str	x2, [sp, #56]
    5d80:	d2800002 	mov	x2, #0x0                   	// #0
    5d84:	910122c0 	add	x0, x22, #0x48
    5d88:	97fff55e 	bl	3300 <fwp_tape_buffers_dispose>
    5d8c:	f90042df 	str	xzr, [x22, #128]
    5d90:	f94022c0 	ldr	x0, [x22, #64]
    5d94:	f100001f 	cmp	x0, #0x0
    5d98:	5400030d 	b.le	5df8 <fwp_tape_finish+0xa8>
    5d9c:	910003f7 	mov	x23, sp
    5da0:	d2800015 	mov	x21, #0x0                   	// #0
    5da4:	d2800014 	mov	x20, #0x0                   	// #0
    5da8:	f94002d3 	ldr	x19, [x22]
    5dac:	91000694 	add	x20, x20, #0x1
    5db0:	8b150273 	add	x19, x19, x21
    5db4:	9101a2b5 	add	x21, x21, #0x68
    5db8:	aa1303e0 	mov	x0, x19
    5dbc:	97fff475 	bl	2f90 <fwp_tape_unlink_scope>
    5dc0:	aa1703e0 	mov	x0, x23
    5dc4:	f9401261 	ldr	x1, [x19, #32]
    5dc8:	f90003e1 	str	x1, [sp]
    5dcc:	f9401a62 	ldr	x2, [x19, #48]
    5dd0:	f9000be2 	str	x2, [sp, #16]
    5dd4:	f9402261 	ldr	x1, [x19, #64]
    5dd8:	f90013e1 	str	x1, [sp, #32]
    5ddc:	97fff549 	bl	3300 <fwp_tape_buffers_dispose>
    5de0:	f9403260 	ldr	x0, [x19, #96]
    5de4:	97ffff8f 	bl	5c20 <fwp_owned_tape_release>
    5de8:	f900327f 	str	xzr, [x19, #96]
    5dec:	f94022c0 	ldr	x0, [x22, #64]
    5df0:	eb14001f 	cmp	x0, x20
    5df4:	54fffdac 	b.gt	5da8 <fwp_tape_finish+0x58>
    5df8:	f9401b00 	ldr	x0, [x24, #48]
    5dfc:	9100c313 	add	x19, x24, #0x30
    5e00:	97fff2d0 	bl	2940 <free@plt>
    5e04:	f9001b1f 	str	xzr, [x24, #48]
    5e08:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5e0c:	f947f400 	ldr	x0, [x0, #4072]
    5e10:	f900227f 	str	xzr, [x19, #64]
    5e14:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5e18:	f9401fe2 	ldr	x2, [sp, #56]
    5e1c:	f9400001 	ldr	x1, [x0]
    5e20:	eb010042 	subs	x2, x2, x1
    5e24:	d2800001 	mov	x1, #0x0                   	// #0
    5e28:	540000e1 	b.ne	5e44 <fwp_tape_finish+0xf4>  // b.any
    5e2c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5e30:	a94553f3 	ldp	x19, x20, [sp, #80]
    5e34:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5e38:	a94763f7 	ldp	x23, x24, [sp, #112]
    5e3c:	910203ff 	add	sp, sp, #0x80
    5e40:	d65f03c0 	ret
    5e44:	97fff28f 	bl	2880 <__stack_chk_fail@plt>
    5e48:	d503201f 	nop
    5e4c:	d503201f 	nop

0000000000005e50 <fwp_tape_scope_release>:
    5e50:	d10243ff 	sub	sp, sp, #0x90
    5e54:	a9047bfd 	stp	x29, x30, [sp, #64]
    5e58:	910103fd 	add	x29, sp, #0x40
    5e5c:	a90553f3 	stp	x19, x20, [sp, #80]
    5e60:	aa0003f4 	mov	x20, x0
    5e64:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5e68:	f947f400 	ldr	x0, [x0, #4072]
    5e6c:	b9400285 	ldr	w5, [x20]
    5e70:	f9400001 	ldr	x1, [x0]
    5e74:	f9001fe1 	str	x1, [sp, #56]
    5e78:	d2800001 	mov	x1, #0x0                   	// #0
    5e7c:	37f806c5 	tbnz	w5, #31, 5f54 <fwp_tape_scope_release+0x104>
    5e80:	a90763f7 	stp	x23, x24, [sp, #112]
    5e84:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5e88:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5e8c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5e90:	f00000d3 	adrp	x19, 20000 <__data_start>
    5e94:	910003f7 	mov	x23, sp
    5e98:	9100c273 	add	x19, x19, #0x30
    5e9c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5ea0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5ea4:	52800d16 	mov	w22, #0x68                  	// #104
    5ea8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5eac:	f90043f9 	str	x25, [sp, #128]
    5eb0:	14000006 	b	5ec8 <fwp_tape_scope_release+0x78>
    5eb4:	97fff513 	bl	3300 <fwp_tape_buffers_dispose>
    5eb8:	aa1903e0 	mov	x0, x25
    5ebc:	97ffff59 	bl	5c20 <fwp_owned_tape_release>
    5ec0:	b9400285 	ldr	w5, [x20]
    5ec4:	37f80425 	tbnz	w5, #31, 5f48 <fwp_tape_scope_release+0xf8>
    5ec8:	f9400266 	ldr	x6, [x19]
    5ecc:	9b367ca5 	smull	x5, w5, w22
    5ed0:	8b0500c0 	add	x0, x6, x5
    5ed4:	97fff42f 	bl	2f90 <fwp_tape_unlink_scope>
    5ed8:	ad410001 	ldp	q1, q0, [x0, #32]
    5edc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5ee0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5ee4:	f9400c03 	ldr	x3, [x0, #24]
    5ee8:	ad0003e1 	stp	q1, q0, [sp]
    5eec:	b86568c1 	ldr	w1, [x6, x5]
    5ef0:	a9440804 	ldp	x4, x2, [x0, #64]
    5ef4:	b900041f 	str	wzr, [x0, #4]
    5ef8:	f9403019 	ldr	x25, [x0, #96]
    5efc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5f00:	f9000c1f 	str	xzr, [x0, #24]
    5f04:	a9020fe4 	stp	x4, x3, [sp, #32]
    5f08:	f9001be2 	str	x2, [sp, #48]
    5f0c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5f10:	f900301f 	str	xzr, [x0, #96]
    5f14:	6b15003f 	cmp	w1, w21
    5f18:	540000e8 	b.hi	5f34 <fwp_tape_scope_release+0xe4>  // b.pmore
    5f1c:	9343fca5 	asr	x5, x5, #3
    5f20:	f9404e60 	ldr	x0, [x19, #152]
    5f24:	9b187ca5 	mul	x5, x5, x24
    5f28:	eb0000bf 	cmp	x5, x0
    5f2c:	5400004a 	b.ge	5f34 <fwp_tape_scope_release+0xe4>  // b.tcont
    5f30:	f9004e65 	str	x5, [x19, #152]
    5f34:	aa1703e0 	mov	x0, x23
    5f38:	b5fffbf9 	cbnz	x25, 5eb4 <fwp_tape_scope_release+0x64>
    5f3c:	97fff871 	bl	4100 <fwp_tape_buffers_release>
    5f40:	b9400285 	ldr	w5, [x20]
    5f44:	36fffc25 	tbz	w5, #31, 5ec8 <fwp_tape_scope_release+0x78>
    5f48:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5f4c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5f50:	f94043f9 	ldr	x25, [sp, #128]
    5f54:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5f58:	f947f400 	ldr	x0, [x0, #4072]
    5f5c:	f9401fe2 	ldr	x2, [sp, #56]
    5f60:	f9400001 	ldr	x1, [x0]
    5f64:	eb010042 	subs	x2, x2, x1
    5f68:	d2800001 	mov	x1, #0x0                   	// #0
    5f6c:	540000a1 	b.ne	5f80 <fwp_tape_scope_release+0x130>  // b.any
    5f70:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f74:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f78:	910243ff 	add	sp, sp, #0x90
    5f7c:	d65f03c0 	ret
    5f80:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f84:	a90763f7 	stp	x23, x24, [sp, #112]
    5f88:	f90043f9 	str	x25, [sp, #128]
    5f8c:	97fff23d 	bl	2880 <__stack_chk_fail@plt>

0000000000005f90 <fwp_drop4>:
    5f90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f94:	910003fd 	mov	x29, sp
    5f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    5f9c:	90000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    5fa0:	911502d5 	add	x21, x22, #0x540
    5fa4:	a90153f3 	stp	x19, x20, [sp, #16]
    5fa8:	aa0003f3 	mov	x19, x0
    5fac:	f949daa1 	ldr	x1, [x21, #5040]
    5fb0:	f949eea0 	ldr	x0, [x21, #5080]
    5fb4:	cb010261 	sub	x1, x19, x1
    5fb8:	eb00403f 	cmp	x1, x0, lsl #16
    5fbc:	54000382 	b.cs	602c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5fc0:	d350fc22 	lsr	x2, x1, #16
    5fc4:	f949fea3 	ldr	x3, [x21, #5112]
    5fc8:	8b020842 	add	x2, x2, x2, lsl #2
    5fcc:	d37df042 	lsl	x2, x2, #3
    5fd0:	8b020060 	add	x0, x3, x2
    5fd4:	f9401014 	ldr	x20, [x0, #32]
    5fd8:	b40002b4 	cbz	x20, 602c <fwp_drop4+0x9c>
    5fdc:	38626862 	ldrb	w2, [x3, x2]
    5fe0:	7100085f 	cmp	w2, #0x2
    5fe4:	540002c0 	b.eq	603c <fwp_drop4+0xac>  // b.none
    5fe8:	7100045f 	cmp	w2, #0x1
    5fec:	54000201 	b.ne	602c <fwp_drop4+0x9c>  // b.any
    5ff0:	29430002 	ldp	w2, w0, [x0, #24]
    5ff4:	92403c21 	and	x1, x1, #0xffff
    5ff8:	9b027c21 	mul	x1, x1, x2
    5ffc:	d360fc21 	lsr	x1, x1, #32
    6000:	eb00003f 	cmp	x1, x0
    6004:	54000142 	b.cs	602c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6008:	8b010294 	add	x20, x20, x1
    600c:	39400280 	ldrb	w0, [x20]
    6010:	340000e0 	cbz	w0, 602c <fwp_drop4+0x9c>
    6014:	7100041f 	cmp	w0, #0x1
    6018:	540001e0 	b.eq	6054 <fwp_drop4+0xc4>  // b.none
    601c:	7103fc1f 	cmp	w0, #0xff
    6020:	540007c0 	b.eq	6118 <fwp_drop4+0x188>  // b.none
    6024:	51000400 	sub	w0, w0, #0x1
    6028:	39000280 	strb	w0, [x20]
    602c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6030:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6034:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6038:	d65f03c0 	ret
    603c:	72003c3f 	tst	w1, #0xffff
    6040:	54fffe60 	b.eq	600c <fwp_drop4+0x7c>  // b.none
    6044:	a94153f3 	ldp	x19, x20, [sp, #16]
    6048:	a9425bf5 	ldp	x21, x22, [sp, #32]
    604c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6050:	d65f03c0 	ret
    6054:	911502c2 	add	x2, x22, #0x540
    6058:	f9400660 	ldr	x0, [x19, #8]
    605c:	f949d841 	ldr	x1, [x2, #5040]
    6060:	f949ec42 	ldr	x2, [x2, #5080]
    6064:	cb010001 	sub	x1, x0, x1
    6068:	eb02403f 	cmp	x1, x2, lsl #16
    606c:	54000362 	b.cs	60d8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6070:	d350fc22 	lsr	x2, x1, #16
    6074:	8b020842 	add	x2, x2, x2, lsl #2
    6078:	d37df042 	lsl	x2, x2, #3
    607c:	8b020064 	add	x4, x3, x2
    6080:	f9401094 	ldr	x20, [x4, #32]
    6084:	b40002b4 	cbz	x20, 60d8 <fwp_drop4+0x148>
    6088:	38626862 	ldrb	w2, [x3, x2]
    608c:	7100085f 	cmp	w2, #0x2
    6090:	540003e0 	b.eq	610c <fwp_drop4+0x17c>  // b.none
    6094:	7100045f 	cmp	w2, #0x1
    6098:	54000201 	b.ne	60d8 <fwp_drop4+0x148>  // b.any
    609c:	29430883 	ldp	w3, w2, [x4, #24]
    60a0:	92403c21 	and	x1, x1, #0xffff
    60a4:	9b037c21 	mul	x1, x1, x3
    60a8:	d360fc21 	lsr	x1, x1, #32
    60ac:	eb02003f 	cmp	x1, x2
    60b0:	54000142 	b.cs	60d8 <fwp_drop4+0x148>  // b.hs, b.nlast
    60b4:	8b010294 	add	x20, x20, x1
    60b8:	39400281 	ldrb	w1, [x20]
    60bc:	340000e1 	cbz	w1, 60d8 <fwp_drop4+0x148>
    60c0:	7100043f 	cmp	w1, #0x1
    60c4:	54000200 	b.eq	6104 <fwp_drop4+0x174>  // b.none
    60c8:	7103fc3f 	cmp	w1, #0xff
    60cc:	54000580 	b.eq	617c <fwp_drop4+0x1ec>  // b.none
    60d0:	51000421 	sub	w1, w1, #0x1
    60d4:	39000281 	strb	w1, [x20]
    60d8:	f9400a74 	ldr	x20, [x19, #16]
    60dc:	aa1303e0 	mov	x0, x19
    60e0:	97fffd00 	bl	54e0 <fwp_rc_free_arr>
    60e4:	911502c0 	add	x0, x22, #0x540
    60e8:	f949d801 	ldr	x1, [x0, #5040]
    60ec:	f949ec00 	ldr	x0, [x0, #5080]
    60f0:	cb010281 	sub	x1, x20, x1
    60f4:	eb00403f 	cmp	x1, x0, lsl #16
    60f8:	54fff9a2 	b.cs	602c <fwp_drop4+0x9c>  // b.hs, b.nlast
    60fc:	aa1403f3 	mov	x19, x20
    6100:	17ffffb0 	b	5fc0 <fwp_drop4+0x30>
    6104:	97fffcf7 	bl	54e0 <fwp_rc_free_arr>
    6108:	17fffff4 	b	60d8 <fwp_drop4+0x148>
    610c:	72003c3f 	tst	w1, #0xffff
    6110:	54fffe41 	b.ne	60d8 <fwp_drop4+0x148>  // b.any
    6114:	17ffffe9 	b	60b8 <fwp_drop4+0x128>
    6118:	ca544681 	eor	x1, x20, x20, lsr #17
    611c:	911502c0 	add	x0, x22, #0x540
    6120:	ca412421 	eor	x1, x1, x1, lsr #9
    6124:	8b210c01 	add	x1, x0, w1, uxtb #3
    6128:	f94a2420 	ldr	x0, [x1, #5192]
    612c:	b5000080 	cbnz	x0, 613c <fwp_drop4+0x1ac>
    6130:	14000010 	b	6170 <fwp_drop4+0x1e0>
    6134:	f9400800 	ldr	x0, [x0, #16]
    6138:	b40001c0 	cbz	x0, 6170 <fwp_drop4+0x1e0>
    613c:	f9400001 	ldr	x1, [x0]
    6140:	eb14003f 	cmp	x1, x20
    6144:	54ffff81 	b.ne	6134 <fwp_drop4+0x1a4>  // b.any
    6148:	f9400401 	ldr	x1, [x0, #8]
    614c:	d1000421 	sub	x1, x1, #0x1
    6150:	f9000401 	str	x1, [x0, #8]
    6154:	f103f83f 	cmp	x1, #0xfe
    6158:	54fff6a1 	b.ne	602c <fwp_drop4+0x9c>  // b.any
    615c:	aa1403e0 	mov	x0, x20
    6160:	97fff904 	bl	4570 <fwp_rc_forget_slot>
    6164:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6168:	39000280 	strb	w0, [x20]
    616c:	17ffffb0 	b	602c <fwp_drop4+0x9c>
    6170:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    6174:	9129e000 	add	x0, x0, #0xa78
    6178:	97fff502 	bl	3580 <fwp_trap>
    617c:	ca544680 	eor	x0, x20, x20, lsr #17
    6180:	911502c1 	add	x1, x22, #0x540
    6184:	ca402400 	eor	x0, x0, x0, lsr #9
    6188:	8b200c20 	add	x0, x1, w0, uxtb #3
    618c:	f94a2400 	ldr	x0, [x0, #5192]
    6190:	b5000080 	cbnz	x0, 61a0 <fwp_drop4+0x210>
    6194:	17fffff7 	b	6170 <fwp_drop4+0x1e0>
    6198:	f9400800 	ldr	x0, [x0, #16]
    619c:	b4fffea0 	cbz	x0, 6170 <fwp_drop4+0x1e0>
    61a0:	f9400001 	ldr	x1, [x0]
    61a4:	eb14003f 	cmp	x1, x20
    61a8:	54ffff81 	b.ne	6198 <fwp_drop4+0x208>  // b.any
    61ac:	f9400401 	ldr	x1, [x0, #8]
    61b0:	d1000421 	sub	x1, x1, #0x1
    61b4:	f9000401 	str	x1, [x0, #8]
    61b8:	f103f83f 	cmp	x1, #0xfe
    61bc:	54fff8e1 	b.ne	60d8 <fwp_drop4+0x148>  // b.any
    61c0:	aa1403e0 	mov	x0, x20
    61c4:	97fff8eb 	bl	4570 <fwp_rc_forget_slot>
    61c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61cc:	39000280 	strb	w0, [x20]
    61d0:	17ffffc2 	b	60d8 <fwp_drop4+0x148>

00000000000061d4 <fwp_arg_drop37>:
    61d4:	7100003f 	cmp	w1, #0x0
    61d8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    61dc:	54000041 	b.ne	61e4 <fwp_arg_drop37+0x10>  // b.any
    61e0:	d65f03c0 	ret
    61e4:	f9400000 	ldr	x0, [x0]
    61e8:	17ffff6a 	b	5f90 <fwp_drop4>
    61ec:	d503201f 	nop

00000000000061f0 <fwp_task_dispose>:
    61f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61f4:	910003fd 	mov	x29, sp
    61f8:	f9000bf3 	str	x19, [sp, #16]
    61fc:	aa0003f3 	mov	x19, x0
    6200:	39414000 	ldrb	w0, [x0, #80]
    6204:	36000720 	tbz	w0, #0, 62e8 <fwp_task_dispose+0xf8>
    6208:	f9400a60 	ldr	x0, [x19, #16]
    620c:	b50006e0 	cbnz	x0, 62e8 <fwp_task_dispose+0xf8>
    6210:	a9478660 	ldp	x0, x1, [x19, #120]
    6214:	39014e7f 	strb	wzr, [x19, #83]
    6218:	f9003e7f 	str	xzr, [x19, #120]
    621c:	f100003f 	cmp	x1, #0x0
    6220:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6224:	54000040 	b.eq	622c <fwp_task_dispose+0x3c>  // b.none
    6228:	d63f0020 	blr	x1
    622c:	f9405660 	ldr	x0, [x19, #168]
    6230:	97fff970 	bl	47f0 <fwp_mem_free>
    6234:	f900567f 	str	xzr, [x19, #168]
    6238:	b9405e60 	ldr	w0, [x19, #92]
    623c:	7100041f 	cmp	w0, #0x1
    6240:	54000420 	b.eq	62c4 <fwp_task_dispose+0xd4>  // b.none
    6244:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6248:	91150042 	add	x2, x2, #0x540
    624c:	f949d840 	ldr	x0, [x2, #5040]
    6250:	f949ec41 	ldr	x1, [x2, #5080]
    6254:	cb000260 	sub	x0, x19, x0
    6258:	eb01401f 	cmp	x0, x1, lsl #16
    625c:	540002e2 	b.cs	62b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6260:	d350fc01 	lsr	x1, x0, #16
    6264:	f949fc44 	ldr	x4, [x2, #5112]
    6268:	8b010821 	add	x1, x1, x1, lsl #2
    626c:	d37df021 	lsl	x1, x1, #3
    6270:	8b010083 	add	x3, x4, x1
    6274:	f9401062 	ldr	x2, [x3, #32]
    6278:	b4000202 	cbz	x2, 62b8 <fwp_task_dispose+0xc8>
    627c:	38616881 	ldrb	w1, [x4, x1]
    6280:	7100083f 	cmp	w1, #0x2
    6284:	54000280 	b.eq	62d4 <fwp_task_dispose+0xe4>  // b.none
    6288:	7100043f 	cmp	w1, #0x1
    628c:	54000161 	b.ne	62b8 <fwp_task_dispose+0xc8>  // b.any
    6290:	29430464 	ldp	w4, w1, [x3, #24]
    6294:	92403c00 	and	x0, x0, #0xffff
    6298:	9b047c00 	mul	x0, x0, x4
    629c:	d360fc00 	lsr	x0, x0, #32
    62a0:	eb01001f 	cmp	x0, x1
    62a4:	540000a2 	b.cs	62b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    62a8:	8b000042 	add	x2, x2, x0
    62ac:	39400040 	ldrb	w0, [x2]
    62b0:	7100041f 	cmp	w0, #0x1
    62b4:	54000080 	b.eq	62c4 <fwp_task_dispose+0xd4>  // b.none
    62b8:	f9400bf3 	ldr	x19, [sp, #16]
    62bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62c0:	d65f03c0 	ret
    62c4:	aa1303e0 	mov	x0, x19
    62c8:	f9400bf3 	ldr	x19, [sp, #16]
    62cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62d0:	17fff948 	b	47f0 <fwp_mem_free>
    62d4:	72003c1f 	tst	w0, #0xffff
    62d8:	54fffea0 	b.eq	62ac <fwp_task_dispose+0xbc>  // b.none
    62dc:	f9400bf3 	ldr	x19, [sp, #16]
    62e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62e4:	d65f03c0 	ret
    62e8:	97fff17a 	bl	28d0 <abort@plt>
    62ec:	d503201f 	nop

00000000000062f0 <fwp_free_zombie>:
    62f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62f4:	910003fd 	mov	x29, sp
    62f8:	a90153f3 	stp	x19, x20, [sp, #16]
    62fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6300:	9100c281 	add	x1, x20, #0x30
    6304:	f9405033 	ldr	x19, [x1, #160]
    6308:	b4000333 	cbz	x19, 636c <fwp_free_zombie+0x7c>
    630c:	f9400820 	ldr	x0, [x1, #16]
    6310:	eb00027f 	cmp	x19, x0
    6314:	540002c0 	b.eq	636c <fwp_free_zombie+0x7c>  // b.none
    6318:	b940a822 	ldr	w2, [x1, #168]
    631c:	f9400a60 	ldr	x0, [x19, #16]
    6320:	7100fc5f 	cmp	w2, #0x3f
    6324:	5400078c 	b.gt	6414 <fwp_free_zombie+0x124>
    6328:	9102c023 	add	x3, x1, #0xb0
    632c:	11000444 	add	w4, w2, #0x1
    6330:	b900a824 	str	w4, [x1, #168]
    6334:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6338:	f822d860 	str	x0, [x3, w2, sxtw #3]
    633c:	a9530261 	ldp	x1, x0, [x19, #304]
    6340:	b4000741 	cbz	x1, 6428 <fwp_free_zombie+0x138>
    6344:	f9009c20 	str	x0, [x1, #312]
    6348:	b4000040 	cbz	x0, 6350 <fwp_free_zombie+0x60>
    634c:	f9009801 	str	x1, [x0, #304]
    6350:	9100c294 	add	x20, x20, #0x30
    6354:	b9405e60 	ldr	w0, [x19, #92]
    6358:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    635c:	f900529f 	str	xzr, [x20, #160]
    6360:	34000140 	cbz	w0, 6388 <fwp_free_zombie+0x98>
    6364:	7100041f 	cmp	w0, #0x1
    6368:	54000080 	b.eq	6378 <fwp_free_zombie+0x88>  // b.none
    636c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6370:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6374:	d65f03c0 	ret
    6378:	aa1303e0 	mov	x0, x19
    637c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6380:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6384:	17ffff9b 	b	61f0 <fwp_task_dispose>
    6388:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    638c:	91150082 	add	x2, x4, #0x540
    6390:	f949d841 	ldr	x1, [x2, #5040]
    6394:	f949ec40 	ldr	x0, [x2, #5080]
    6398:	cb010261 	sub	x1, x19, x1
    639c:	eb00403f 	cmp	x1, x0, lsl #16
    63a0:	54fffe62 	b.cs	636c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    63a4:	d350fc20 	lsr	x0, x1, #16
    63a8:	f949fc43 	ldr	x3, [x2, #5112]
    63ac:	8b000800 	add	x0, x0, x0, lsl #2
    63b0:	d37df000 	lsl	x0, x0, #3
    63b4:	8b000062 	add	x2, x3, x0
    63b8:	f9401054 	ldr	x20, [x2, #32]
    63bc:	b4fffd94 	cbz	x20, 636c <fwp_free_zombie+0x7c>
    63c0:	38606860 	ldrb	w0, [x3, x0]
    63c4:	7100081f 	cmp	w0, #0x2
    63c8:	54000360 	b.eq	6434 <fwp_free_zombie+0x144>  // b.none
    63cc:	7100041f 	cmp	w0, #0x1
    63d0:	54fffce1 	b.ne	636c <fwp_free_zombie+0x7c>  // b.any
    63d4:	29430043 	ldp	w3, w0, [x2, #24]
    63d8:	92403c21 	and	x1, x1, #0xffff
    63dc:	9b037c21 	mul	x1, x1, x3
    63e0:	d360fc21 	lsr	x1, x1, #32
    63e4:	eb00003f 	cmp	x1, x0
    63e8:	54fffc22 	b.cs	636c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    63ec:	8b010294 	add	x20, x20, x1
    63f0:	39400280 	ldrb	w0, [x20]
    63f4:	34fffbc0 	cbz	w0, 636c <fwp_free_zombie+0x7c>
    63f8:	7100041f 	cmp	w0, #0x1
    63fc:	54fffbe0 	b.eq	6378 <fwp_free_zombie+0x88>  // b.none
    6400:	7103fc1f 	cmp	w0, #0xff
    6404:	540001e0 	b.eq	6440 <fwp_free_zombie+0x150>  // b.none
    6408:	51000400 	sub	w0, w0, #0x1
    640c:	39000280 	strb	w0, [x20]
    6410:	17ffffd7 	b	636c <fwp_free_zombie+0x7c>
    6414:	f9400e61 	ldr	x1, [x19, #24]
    6418:	97fff162 	bl	29a0 <munmap@plt>
    641c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6420:	a9530261 	ldp	x1, x0, [x19, #304]
    6424:	b5fff901 	cbnz	x1, 6344 <fwp_free_zombie+0x54>
    6428:	9100c282 	add	x2, x20, #0x30
    642c:	f9015840 	str	x0, [x2, #688]
    6430:	17ffffc6 	b	6348 <fwp_free_zombie+0x58>
    6434:	72003c3f 	tst	w1, #0xffff
    6438:	54fff9a1 	b.ne	636c <fwp_free_zombie+0x7c>  // b.any
    643c:	17ffffed 	b	63f0 <fwp_free_zombie+0x100>
    6440:	ca544680 	eor	x0, x20, x20, lsr #17
    6444:	91150084 	add	x4, x4, #0x540
    6448:	ca402400 	eor	x0, x0, x0, lsr #9
    644c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6450:	f94a2400 	ldr	x0, [x0, #5192]
    6454:	b5000080 	cbnz	x0, 6464 <fwp_free_zombie+0x174>
    6458:	14000010 	b	6498 <fwp_free_zombie+0x1a8>
    645c:	f9400800 	ldr	x0, [x0, #16]
    6460:	b40001c0 	cbz	x0, 6498 <fwp_free_zombie+0x1a8>
    6464:	f9400001 	ldr	x1, [x0]
    6468:	eb14003f 	cmp	x1, x20
    646c:	54ffff81 	b.ne	645c <fwp_free_zombie+0x16c>  // b.any
    6470:	f9400401 	ldr	x1, [x0, #8]
    6474:	d1000421 	sub	x1, x1, #0x1
    6478:	f9000401 	str	x1, [x0, #8]
    647c:	f103f83f 	cmp	x1, #0xfe
    6480:	54fff761 	b.ne	636c <fwp_free_zombie+0x7c>  // b.any
    6484:	aa1403e0 	mov	x0, x20
    6488:	97fff83a 	bl	4570 <fwp_rc_forget_slot>
    648c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6490:	39000280 	strb	w0, [x20]
    6494:	17ffffb6 	b	636c <fwp_free_zombie+0x7c>
    6498:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    649c:	9129e000 	add	x0, x0, #0xa78
    64a0:	97fff438 	bl	3580 <fwp_trap>

00000000000064a4 <fwp_block>:
    64a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64a8:	910003fd 	mov	x29, sp
    64ac:	a90153f3 	stp	x19, x20, [sp, #16]
    64b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64b4:	9100c274 	add	x20, x19, #0x30
    64b8:	f9401a82 	ldr	x2, [x20, #48]
    64bc:	b4000622 	cbz	x2, 6580 <fwp_block+0xdc>
    64c0:	9100c261 	add	x1, x19, #0x30
    64c4:	f9408040 	ldr	x0, [x2, #256]
    64c8:	f9001820 	str	x0, [x1, #48]
    64cc:	b4000680 	cbz	x0, 659c <fwp_block+0xf8>
    64d0:	9100c263 	add	x3, x19, #0x30
    64d4:	3901505f 	strb	wzr, [x2, #84]
    64d8:	f9400864 	ldr	x4, [x3, #16]
    64dc:	eb02009f 	cmp	x4, x2
    64e0:	54000440 	b.eq	6568 <fwp_block+0xc4>  // b.none
    64e4:	f9415c65 	ldr	x5, [x3, #696]
    64e8:	f9000862 	str	x2, [x3, #16]
    64ec:	f9400441 	ldr	x1, [x2, #8]
    64f0:	f9004885 	str	x5, [x4, #144]
    64f4:	f9416065 	ldr	x5, [x3, #704]
    64f8:	f9004c85 	str	x5, [x4, #152]
    64fc:	f9416465 	ldr	x5, [x3, #712]
    6500:	f9005085 	str	x5, [x4, #160]
    6504:	f9416865 	ldr	x5, [x3, #720]
    6508:	f9005485 	str	x5, [x4, #168]
    650c:	f9416c65 	ldr	x5, [x3, #728]
    6510:	f9005885 	str	x5, [x4, #176]
    6514:	f9417065 	ldr	x5, [x3, #736]
    6518:	f9005c85 	str	x5, [x4, #184]
    651c:	f9417465 	ldr	x5, [x3, #744]
    6520:	f9006085 	str	x5, [x4, #192]
    6524:	f9400480 	ldr	x0, [x4, #8]
    6528:	f9404844 	ldr	x4, [x2, #144]
    652c:	f9015c64 	str	x4, [x3, #696]
    6530:	f9404c44 	ldr	x4, [x2, #152]
    6534:	f9016064 	str	x4, [x3, #704]
    6538:	f9405044 	ldr	x4, [x2, #160]
    653c:	f9016464 	str	x4, [x3, #712]
    6540:	f9405444 	ldr	x4, [x2, #168]
    6544:	f9016864 	str	x4, [x3, #720]
    6548:	f9405844 	ldr	x4, [x2, #176]
    654c:	f9016c64 	str	x4, [x3, #728]
    6550:	a94b8844 	ldp	x4, x2, [x2, #184]
    6554:	f9017064 	str	x4, [x3, #736]
    6558:	f9017462 	str	x2, [x3, #744]
    655c:	97fff0e1 	bl	28e0 <swapcontext@plt>
    6560:	97ffff64 	bl	62f0 <fwp_free_zombie>
    6564:	d503201f 	nop
    6568:	9100c260 	add	x0, x19, #0x30
    656c:	b942f000 	ldr	w0, [x0, #752]
    6570:	340001a0 	cbz	w0, 65a4 <fwp_block+0x100>
    6574:	a94153f3 	ldp	x19, x20, [sp, #16]
    6578:	a8c27bfd 	ldp	x29, x30, [sp], #32
    657c:	d65f03c0 	ret
    6580:	97fff728 	bl	4220 <fwp_poll_events>
    6584:	f9401a82 	ldr	x2, [x20, #48]
    6588:	b4ffffc2 	cbz	x2, 6580 <fwp_block+0xdc>
    658c:	9100c261 	add	x1, x19, #0x30
    6590:	f9408040 	ldr	x0, [x2, #256]
    6594:	f9001820 	str	x0, [x1, #48]
    6598:	b5fff9c0 	cbnz	x0, 64d0 <fwp_block+0x2c>
    659c:	f900143f 	str	xzr, [x1, #40]
    65a0:	17ffffcc 	b	64d0 <fwp_block+0x2c>
    65a4:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    65a8:	912ea000 	add	x0, x0, #0xba8
    65ac:	97fff119 	bl	2a10 <getenv@plt>
    65b0:	5284e202 	mov	w2, #0x2710                	// #10000
    65b4:	b4000060 	cbz	x0, 65c0 <fwp_block+0x11c>
    65b8:	39400001 	ldrb	w1, [x0]
    65bc:	350000c1 	cbnz	w1, 65d4 <fwp_block+0x130>
    65c0:	9100c273 	add	x19, x19, #0x30
    65c4:	b902f262 	str	w2, [x19, #752]
    65c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    65cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65d0:	d65f03c0 	ret
    65d4:	52800142 	mov	w2, #0xa                   	// #10
    65d8:	d2800001 	mov	x1, #0x0                   	// #0
    65dc:	97fff05d 	bl	2750 <strtoll@plt>
    65e0:	d1000403 	sub	x3, x0, #0x1
    65e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    65e8:	eb02007f 	cmp	x3, x2
    65ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    65f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    65f4:	17fffff3 	b	65c0 <fwp_block+0x11c>
    65f8:	d503201f 	nop
    65fc:	d503201f 	nop

0000000000006600 <fwp_drop10>:
    6600:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6604:	910003fd 	mov	x29, sp
    6608:	a90153f3 	stp	x19, x20, [sp, #16]
    660c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    6610:	f90013f5 	str	x21, [sp, #32]
    6614:	91150275 	add	x21, x19, #0x540
    6618:	f949daa1 	ldr	x1, [x21, #5040]
    661c:	f949eea2 	ldr	x2, [x21, #5080]
    6620:	cb010001 	sub	x1, x0, x1
    6624:	eb02403f 	cmp	x1, x2, lsl #16
    6628:	54000382 	b.cs	6698 <fwp_drop10+0x98>  // b.hs, b.nlast
    662c:	d350fc22 	lsr	x2, x1, #16
    6630:	f949fea3 	ldr	x3, [x21, #5112]
    6634:	8b020842 	add	x2, x2, x2, lsl #2
    6638:	d37df042 	lsl	x2, x2, #3
    663c:	8b020064 	add	x4, x3, x2
    6640:	f9401094 	ldr	x20, [x4, #32]
    6644:	b40002b4 	cbz	x20, 6698 <fwp_drop10+0x98>
    6648:	38626862 	ldrb	w2, [x3, x2]
    664c:	7100085f 	cmp	w2, #0x2
    6650:	540007a0 	b.eq	6744 <fwp_drop10+0x144>  // b.none
    6654:	7100045f 	cmp	w2, #0x1
    6658:	54000201 	b.ne	6698 <fwp_drop10+0x98>  // b.any
    665c:	29430885 	ldp	w5, w2, [x4, #24]
    6660:	92403c21 	and	x1, x1, #0xffff
    6664:	9b057c21 	mul	x1, x1, x5
    6668:	d360fc21 	lsr	x1, x1, #32
    666c:	eb02003f 	cmp	x1, x2
    6670:	54000142 	b.cs	6698 <fwp_drop10+0x98>  // b.hs, b.nlast
    6674:	8b010294 	add	x20, x20, x1
    6678:	39400281 	ldrb	w1, [x20]
    667c:	340000e1 	cbz	w1, 6698 <fwp_drop10+0x98>
    6680:	7100043f 	cmp	w1, #0x1
    6684:	54000120 	b.eq	66a8 <fwp_drop10+0xa8>  // b.none
    6688:	7103fc3f 	cmp	w1, #0xff
    668c:	540007c0 	b.eq	6784 <fwp_drop10+0x184>  // b.none
    6690:	51000421 	sub	w1, w1, #0x1
    6694:	39000281 	strb	w1, [x20]
    6698:	a94153f3 	ldp	x19, x20, [sp, #16]
    669c:	f94013f5 	ldr	x21, [sp, #32]
    66a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66a4:	d65f03c0 	ret
    66a8:	f9400001 	ldr	x1, [x0]
    66ac:	b7f80581 	tbnz	x1, #63, 675c <fwp_drop10+0x15c>
    66b0:	91150273 	add	x19, x19, #0x540
    66b4:	f949da61 	ldr	x1, [x19, #5040]
    66b8:	f949ee62 	ldr	x2, [x19, #5080]
    66bc:	cb010001 	sub	x1, x0, x1
    66c0:	eb02403f 	cmp	x1, x2, lsl #16
    66c4:	54fffea2 	b.cs	6698 <fwp_drop10+0x98>  // b.hs, b.nlast
    66c8:	d350fc22 	lsr	x2, x1, #16
    66cc:	8b020842 	add	x2, x2, x2, lsl #2
    66d0:	d37df042 	lsl	x2, x2, #3
    66d4:	8b020065 	add	x5, x3, x2
    66d8:	f94010a4 	ldr	x4, [x5, #32]
    66dc:	b4fffde4 	cbz	x4, 6698 <fwp_drop10+0x98>
    66e0:	38626862 	ldrb	w2, [x3, x2]
    66e4:	7100085f 	cmp	w2, #0x2
    66e8:	54000220 	b.eq	672c <fwp_drop10+0x12c>  // b.none
    66ec:	7100045f 	cmp	w2, #0x1
    66f0:	54fffd41 	b.ne	6698 <fwp_drop10+0x98>  // b.any
    66f4:	294308a3 	ldp	w3, w2, [x5, #24]
    66f8:	92403c21 	and	x1, x1, #0xffff
    66fc:	9b037c21 	mul	x1, x1, x3
    6700:	d360fc21 	lsr	x1, x1, #32
    6704:	eb02003f 	cmp	x1, x2
    6708:	54fffc82 	b.cs	6698 <fwp_drop10+0x98>  // b.hs, b.nlast
    670c:	8b010084 	add	x4, x4, x1
    6710:	39400081 	ldrb	w1, [x4]
    6714:	7100043f 	cmp	w1, #0x1
    6718:	54fffc01 	b.ne	6698 <fwp_drop10+0x98>  // b.any
    671c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6720:	f94013f5 	ldr	x21, [sp, #32]
    6724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6728:	17fff832 	b	47f0 <fwp_mem_free>
    672c:	72003c3f 	tst	w1, #0xffff
    6730:	54ffff00 	b.eq	6710 <fwp_drop10+0x110>  // b.none
    6734:	a94153f3 	ldp	x19, x20, [sp, #16]
    6738:	f94013f5 	ldr	x21, [sp, #32]
    673c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6740:	d65f03c0 	ret
    6744:	72003c3f 	tst	w1, #0xffff
    6748:	54fff980 	b.eq	6678 <fwp_drop10+0x78>  // b.none
    674c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6750:	f94013f5 	ldr	x21, [sp, #32]
    6754:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6758:	d65f03c0 	ret
    675c:	f9400414 	ldr	x20, [x0, #8]
    6760:	97fffb60 	bl	54e0 <fwp_rc_free_arr>
    6764:	91150260 	add	x0, x19, #0x540
    6768:	f949d801 	ldr	x1, [x0, #5040]
    676c:	f949ec00 	ldr	x0, [x0, #5080]
    6770:	cb010281 	sub	x1, x20, x1
    6774:	eb00403f 	cmp	x1, x0, lsl #16
    6778:	54fff902 	b.cs	6698 <fwp_drop10+0x98>  // b.hs, b.nlast
    677c:	aa1403e0 	mov	x0, x20
    6780:	17ffffab 	b	662c <fwp_drop10+0x2c>
    6784:	ca544680 	eor	x0, x20, x20, lsr #17
    6788:	91150273 	add	x19, x19, #0x540
    678c:	ca402400 	eor	x0, x0, x0, lsr #9
    6790:	8b200e60 	add	x0, x19, w0, uxtb #3
    6794:	f94a2400 	ldr	x0, [x0, #5192]
    6798:	b5000080 	cbnz	x0, 67a8 <fwp_drop10+0x1a8>
    679c:	14000010 	b	67dc <fwp_drop10+0x1dc>
    67a0:	f9400800 	ldr	x0, [x0, #16]
    67a4:	b40001c0 	cbz	x0, 67dc <fwp_drop10+0x1dc>
    67a8:	f9400001 	ldr	x1, [x0]
    67ac:	eb14003f 	cmp	x1, x20
    67b0:	54ffff81 	b.ne	67a0 <fwp_drop10+0x1a0>  // b.any
    67b4:	f9400401 	ldr	x1, [x0, #8]
    67b8:	d1000421 	sub	x1, x1, #0x1
    67bc:	f9000401 	str	x1, [x0, #8]
    67c0:	f103f83f 	cmp	x1, #0xfe
    67c4:	54fff6a1 	b.ne	6698 <fwp_drop10+0x98>  // b.any
    67c8:	aa1403e0 	mov	x0, x20
    67cc:	97fff769 	bl	4570 <fwp_rc_forget_slot>
    67d0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67d4:	39000280 	strb	w0, [x20]
    67d8:	17ffffb0 	b	6698 <fwp_drop10+0x98>
    67dc:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    67e0:	9129e000 	add	x0, x0, #0xa78
    67e4:	97fff367 	bl	3580 <fwp_trap>
    67e8:	d503201f 	nop
    67ec:	d503201f 	nop

00000000000067f0 <fwp_caps173>:
    67f0:	34000041 	cbz	w1, 67f8 <fwp_caps173+0x8>
    67f4:	d65f03c0 	ret
    67f8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    67fc:	91150063 	add	x3, x3, #0x540
    6800:	f949d861 	ldr	x1, [x3, #5040]
    6804:	f949ec62 	ldr	x2, [x3, #5080]
    6808:	cb010001 	sub	x1, x0, x1
    680c:	eb02403f 	cmp	x1, x2, lsl #16
    6810:	54ffff22 	b.cs	67f4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6814:	d350fc22 	lsr	x2, x1, #16
    6818:	f949fc65 	ldr	x5, [x3, #5112]
    681c:	8b020842 	add	x2, x2, x2, lsl #2
    6820:	d37df042 	lsl	x2, x2, #3
    6824:	8b0200a4 	add	x4, x5, x2
    6828:	f9401083 	ldr	x3, [x4, #32]
    682c:	b4fffe43 	cbz	x3, 67f4 <fwp_caps173+0x4>
    6830:	386268a2 	ldrb	w2, [x5, x2]
    6834:	7100085f 	cmp	w2, #0x2
    6838:	540001c0 	b.eq	6870 <fwp_caps173+0x80>  // b.none
    683c:	7100045f 	cmp	w2, #0x1
    6840:	54fffda1 	b.ne	67f4 <fwp_caps173+0x4>  // b.any
    6844:	29430885 	ldp	w5, w2, [x4, #24]
    6848:	92403c21 	and	x1, x1, #0xffff
    684c:	9b057c21 	mul	x1, x1, x5
    6850:	d360fc21 	lsr	x1, x1, #32
    6854:	eb02003f 	cmp	x1, x2
    6858:	54fffce2 	b.cs	67f4 <fwp_caps173+0x4>  // b.hs, b.nlast
    685c:	8b010063 	add	x3, x3, x1
    6860:	39400061 	ldrb	w1, [x3]
    6864:	7100043f 	cmp	w1, #0x1
    6868:	54fffc61 	b.ne	67f4 <fwp_caps173+0x4>  // b.any
    686c:	17fff7e1 	b	47f0 <fwp_mem_free>
    6870:	72003c3f 	tst	w1, #0xffff
    6874:	54ffff60 	b.eq	6860 <fwp_caps173+0x70>  // b.none
    6878:	d65f03c0 	ret
    687c:	d503201f 	nop

0000000000006880 <f37>:
    6880:	d101c3ff 	sub	sp, sp, #0x70
    6884:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6888:	f947f421 	ldr	x1, [x1, #4072]
    688c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6890:	910083fd 	add	x29, sp, #0x20
    6894:	a90563f7 	stp	x23, x24, [sp, #80]
    6898:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xca0>
    689c:	911502e3 	add	x3, x23, #0x540
    68a0:	a90353f3 	stp	x19, x20, [sp, #48]
    68a4:	a9045bf5 	stp	x21, x22, [sp, #64]
    68a8:	aa0003f6 	mov	x22, x0
    68ac:	a9066bf9 	stp	x25, x26, [sp, #96]
    68b0:	f949ec62 	ldr	x2, [x3, #5080]
    68b4:	f9400024 	ldr	x4, [x1]
    68b8:	f9000fe4 	str	x4, [sp, #24]
    68bc:	d2800004 	mov	x4, #0x0                   	// #0
    68c0:	f949d861 	ldr	x1, [x3, #5040]
    68c4:	d370bc42 	lsl	x2, x2, #16
    68c8:	b40015c0 	cbz	x0, 6b80 <f37+0x300>
    68cc:	f9400818 	ldr	x24, [x0, #16]
    68d0:	cb010301 	sub	x1, x24, x1
    68d4:	eb02003f 	cmp	x1, x2
    68d8:	54000362 	b.cs	6944 <f37+0xc4>  // b.hs, b.nlast
    68dc:	f949fc60 	ldr	x0, [x3, #5112]
    68e0:	d350fc22 	lsr	x2, x1, #16
    68e4:	8b020842 	add	x2, x2, x2, lsl #2
    68e8:	8b020c02 	add	x2, x0, x2, lsl #3
    68ec:	f9401040 	ldr	x0, [x2, #32]
    68f0:	b40002a0 	cbz	x0, 6944 <f37+0xc4>
    68f4:	39400043 	ldrb	w3, [x2]
    68f8:	7100087f 	cmp	w3, #0x2
    68fc:	540013c0 	b.eq	6b74 <f37+0x2f4>  // b.none
    6900:	7100047f 	cmp	w3, #0x1
    6904:	540001c1 	b.ne	693c <f37+0xbc>  // b.any
    6908:	29430843 	ldp	w3, w2, [x2, #24]
    690c:	92403c21 	and	x1, x1, #0xffff
    6910:	9b037c21 	mul	x1, x1, x3
    6914:	d360fc21 	lsr	x1, x1, #32
    6918:	eb02003f 	cmp	x1, x2
    691c:	54000102 	b.cs	693c <f37+0xbc>  // b.hs, b.nlast
    6920:	8b010000 	add	x0, x0, x1
    6924:	39400001 	ldrb	w1, [x0]
    6928:	340000a1 	cbz	w1, 693c <f37+0xbc>
    692c:	7103f43f 	cmp	w1, #0xfd
    6930:	540016a8 	b.hi	6c04 <f37+0x384>  // b.pmore
    6934:	11000421 	add	w1, w1, #0x1
    6938:	39000001 	strb	w1, [x0]
    693c:	d2800000 	mov	x0, #0x0                   	// #0
    6940:	b40000f6 	cbz	x22, 695c <f37+0xdc>
    6944:	aa1603e1 	mov	x1, x22
    6948:	d2800000 	mov	x0, #0x0                   	// #0
    694c:	d503201f 	nop
    6950:	f9400821 	ldr	x1, [x1, #16]
    6954:	91000400 	add	x0, x0, #0x1
    6958:	b5ffffc1 	cbnz	x1, 6950 <f37+0xd0>
    695c:	b40011b8 	cbz	x24, 6b90 <f37+0x310>
    6960:	aa1803e1 	mov	x1, x24
    6964:	d2800002 	mov	x2, #0x0                   	// #0
    6968:	f9400821 	ldr	x1, [x1, #16]
    696c:	91000442 	add	x2, x2, #0x1
    6970:	b5ffffc1 	cbnz	x1, 6968 <f37+0xe8>
    6974:	eb00005f 	cmp	x2, x0
    6978:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    697c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6980:	eb01033f 	cmp	x25, x1
    6984:	54001468 	b.hi	6c10 <f37+0x390>  // b.pmore
    6988:	d37ffb33 	lsl	x19, x25, #1
    698c:	52800041 	mov	w1, #0x2                   	// #2
    6990:	91000660 	add	x0, x19, #0x1
    6994:	d37df000 	lsl	x0, x0, #3
    6998:	97fff8b6 	bl	4c70 <fwp_heap_alloc>
    699c:	911502e1 	add	x1, x23, #0x540
    69a0:	aa0003fa 	mov	x26, x0
    69a4:	f9000013 	str	x19, [x0]
    69a8:	aa0103e0 	mov	x0, x1
    69ac:	f949d821 	ldr	x1, [x1, #5040]
    69b0:	f949ec00 	ldr	x0, [x0, #5080]
    69b4:	cb010341 	sub	x1, x26, x1
    69b8:	eb00403f 	cmp	x1, x0, lsl #16
    69bc:	54000342 	b.cs	6a24 <f37+0x1a4>  // b.hs, b.nlast
    69c0:	911502e2 	add	x2, x23, #0x540
    69c4:	d350fc20 	lsr	x0, x1, #16
    69c8:	8b000800 	add	x0, x0, x0, lsl #2
    69cc:	f949fc43 	ldr	x3, [x2, #5112]
    69d0:	d37df002 	lsl	x2, x0, #3
    69d4:	8b020060 	add	x0, x3, x2
    69d8:	f9401013 	ldr	x19, [x0, #32]
    69dc:	b4000253 	cbz	x19, 6a24 <f37+0x1a4>
    69e0:	38626862 	ldrb	w2, [x3, x2]
    69e4:	7100085f 	cmp	w2, #0x2
    69e8:	54000c00 	b.eq	6b68 <f37+0x2e8>  // b.none
    69ec:	7100045f 	cmp	w2, #0x1
    69f0:	540001a1 	b.ne	6a24 <f37+0x1a4>  // b.any
    69f4:	29430002 	ldp	w2, w0, [x0, #24]
    69f8:	92403c21 	and	x1, x1, #0xffff
    69fc:	9b027c21 	mul	x1, x1, x2
    6a00:	d360fc21 	lsr	x1, x1, #32
    6a04:	eb00003f 	cmp	x1, x0
    6a08:	540000e2 	b.cs	6a24 <f37+0x1a4>  // b.hs, b.nlast
    6a0c:	8b010273 	add	x19, x19, x1
    6a10:	39400260 	ldrb	w0, [x19]
    6a14:	7103fc1f 	cmp	w0, #0xff
    6a18:	54000da0 	b.eq	6bcc <f37+0x34c>  // b.none
    6a1c:	52800020 	mov	w0, #0x1                   	// #1
    6a20:	39000260 	strb	w0, [x19]
    6a24:	b4000259 	cbz	x25, 6a6c <f37+0x1ec>
    6a28:	8b191359 	add	x25, x26, x25, lsl #4
    6a2c:	aa1a03f3 	mov	x19, x26
    6a30:	aa1603f5 	mov	x21, x22
    6a34:	aa1803f4 	mov	x20, x24
    6a38:	f9400683 	ldr	x3, [x20, #8]
    6a3c:	f94006a2 	ldr	x2, [x21, #8]
    6a40:	f9400861 	ldr	x1, [x3, #16]
    6a44:	f9400840 	ldr	x0, [x2, #16]
    6a48:	fd400461 	ldr	d1, [x3, #8]
    6a4c:	fd400440 	ldr	d0, [x2, #8]
    6a50:	97fff9f8 	bl	5230 <w120>
    6a54:	f9000660 	str	x0, [x19, #8]
    6a58:	f8010e61 	str	x1, [x19, #16]!
    6a5c:	f9400a94 	ldr	x20, [x20, #16]
    6a60:	f9400ab5 	ldr	x21, [x21, #16]
    6a64:	eb13033f 	cmp	x25, x19
    6a68:	54fffe81 	b.ne	6a38 <f37+0x1b8>  // b.any
    6a6c:	aa1803e0 	mov	x0, x24
    6a70:	97fffd48 	bl	5f90 <fwp_drop4>
    6a74:	aa1603e0 	mov	x0, x22
    6a78:	97fffd46 	bl	5f90 <fwp_drop4>
    6a7c:	911502f7 	add	x23, x23, #0x540
    6a80:	aa1a03e0 	mov	x0, x26
    6a84:	97fffa48 	bl	53a4 <w176.constprop.0>
    6a88:	aa0103f3 	mov	x19, x1
    6a8c:	aa0003f4 	mov	x20, x0
    6a90:	aa1a03e0 	mov	x0, x26
    6a94:	97fffedb 	bl	6600 <fwp_drop10>
    6a98:	a900cff4 	stp	x20, x19, [sp, #8]
    6a9c:	910023e1 	add	x1, sp, #0x8
    6aa0:	52800000 	mov	w0, #0x0                   	// #0
    6aa4:	97fff8b8 	bl	4d84 <fwp_data.part.0.constprop.0>
    6aa8:	f949dae1 	ldr	x1, [x23, #5040]
    6aac:	aa0003f3 	mov	x19, x0
    6ab0:	f949eee0 	ldr	x0, [x23, #5080]
    6ab4:	cb010261 	sub	x1, x19, x1
    6ab8:	eb00403f 	cmp	x1, x0, lsl #16
    6abc:	54000322 	b.cs	6b20 <f37+0x2a0>  // b.hs, b.nlast
    6ac0:	d350fc22 	lsr	x2, x1, #16
    6ac4:	f949fee3 	ldr	x3, [x23, #5112]
    6ac8:	8b020842 	add	x2, x2, x2, lsl #2
    6acc:	d37df042 	lsl	x2, x2, #3
    6ad0:	8b020060 	add	x0, x3, x2
    6ad4:	f9401014 	ldr	x20, [x0, #32]
    6ad8:	b4000254 	cbz	x20, 6b20 <f37+0x2a0>
    6adc:	38626862 	ldrb	w2, [x3, x2]
    6ae0:	7100085f 	cmp	w2, #0x2
    6ae4:	540003c0 	b.eq	6b5c <f37+0x2dc>  // b.none
    6ae8:	7100045f 	cmp	w2, #0x1
    6aec:	540001a1 	b.ne	6b20 <f37+0x2a0>  // b.any
    6af0:	29430002 	ldp	w2, w0, [x0, #24]
    6af4:	92403c21 	and	x1, x1, #0xffff
    6af8:	9b027c21 	mul	x1, x1, x2
    6afc:	d360fc21 	lsr	x1, x1, #32
    6b00:	eb00003f 	cmp	x1, x0
    6b04:	540000e2 	b.cs	6b20 <f37+0x2a0>  // b.hs, b.nlast
    6b08:	8b010294 	add	x20, x20, x1
    6b0c:	39400280 	ldrb	w0, [x20]
    6b10:	7103fc1f 	cmp	w0, #0xff
    6b14:	54000620 	b.eq	6bd8 <f37+0x358>  // b.none
    6b18:	52800020 	mov	w0, #0x1                   	// #1
    6b1c:	39000280 	strb	w0, [x20]
    6b20:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6b24:	f947f400 	ldr	x0, [x0, #4072]
    6b28:	f9400fe2 	ldr	x2, [sp, #24]
    6b2c:	f9400001 	ldr	x1, [x0]
    6b30:	eb010042 	subs	x2, x2, x1
    6b34:	d2800001 	mov	x1, #0x0                   	// #0
    6b38:	540006a1 	b.ne	6c0c <f37+0x38c>  // b.any
    6b3c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6b40:	aa1303e0 	mov	x0, x19
    6b44:	a94353f3 	ldp	x19, x20, [sp, #48]
    6b48:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6b4c:	a94563f7 	ldp	x23, x24, [sp, #80]
    6b50:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6b54:	9101c3ff 	add	sp, sp, #0x70
    6b58:	d65f03c0 	ret
    6b5c:	72003c3f 	tst	w1, #0xffff
    6b60:	54fffe01 	b.ne	6b20 <f37+0x2a0>  // b.any
    6b64:	17ffffea 	b	6b0c <f37+0x28c>
    6b68:	72003c3f 	tst	w1, #0xffff
    6b6c:	54fff5c1 	b.ne	6a24 <f37+0x1a4>  // b.any
    6b70:	17ffffa8 	b	6a10 <f37+0x190>
    6b74:	72003c3f 	tst	w1, #0xffff
    6b78:	54ffee21 	b.ne	693c <f37+0xbc>  // b.any
    6b7c:	17ffff6a 	b	6924 <f37+0xa4>
    6b80:	cb0103e1 	neg	x1, x1
    6b84:	eb02003f 	cmp	x1, x2
    6b88:	540002e3 	b.cc	6be4 <f37+0x364>  // b.lo, b.ul, b.last
    6b8c:	d503201f 	nop
    6b90:	52800041 	mov	w1, #0x2                   	// #2
    6b94:	d2800100 	mov	x0, #0x8                   	// #8
    6b98:	97fff836 	bl	4c70 <fwp_heap_alloc>
    6b9c:	aa0003e1 	mov	x1, x0
    6ba0:	911502e0 	add	x0, x23, #0x540
    6ba4:	aa0103fa 	mov	x26, x1
    6ba8:	d2800018 	mov	x24, #0x0                   	// #0
    6bac:	f900003f 	str	xzr, [x1]
    6bb0:	f949d801 	ldr	x1, [x0, #5040]
    6bb4:	f949ec00 	ldr	x0, [x0, #5080]
    6bb8:	cb010341 	sub	x1, x26, x1
    6bbc:	eb00403f 	cmp	x1, x0, lsl #16
    6bc0:	54fff562 	b.cs	6a6c <f37+0x1ec>  // b.hs, b.nlast
    6bc4:	d2800019 	mov	x25, #0x0                   	// #0
    6bc8:	17ffff7e 	b	69c0 <f37+0x140>
    6bcc:	aa1303e0 	mov	x0, x19
    6bd0:	97fff668 	bl	4570 <fwp_rc_forget_slot>
    6bd4:	17ffff92 	b	6a1c <f37+0x19c>
    6bd8:	aa1403e0 	mov	x0, x20
    6bdc:	97fff665 	bl	4570 <fwp_rc_forget_slot>
    6be0:	17ffffce 	b	6b18 <f37+0x298>
    6be4:	f949fc62 	ldr	x2, [x3, #5112]
    6be8:	d350fc20 	lsr	x0, x1, #16
    6bec:	8b000800 	add	x0, x0, x0, lsl #2
    6bf0:	8b000c42 	add	x2, x2, x0, lsl #3
    6bf4:	f9401040 	ldr	x0, [x2, #32]
    6bf8:	b4fffcc0 	cbz	x0, 6b90 <f37+0x310>
    6bfc:	d2800018 	mov	x24, #0x0                   	// #0
    6c00:	17ffff3d 	b	68f4 <f37+0x74>
    6c04:	97fff614 	bl	4454 <fwp_rc_wide_dup>
    6c08:	17ffff4d 	b	693c <f37+0xbc>
    6c0c:	97ffef1d 	bl	2880 <__stack_chk_fail@plt>
    6c10:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    6c14:	912ee000 	add	x0, x0, #0xbb8
    6c18:	97fff25a 	bl	3580 <fwp_trap>
    6c1c:	d503201f 	nop

0000000000006c20 <fwp_owned_entry37>:
    6c20:	f9400000 	ldr	x0, [x0]
    6c24:	17ffff17 	b	6880 <f37>
    6c28:	d503201f 	nop
    6c2c:	d503201f 	nop

0000000000006c30 <e37>:
    6c30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c34:	910003fd 	mov	x29, sp
    6c38:	f9000bf3 	str	x19, [sp, #16]
    6c3c:	f9400013 	ldr	x19, [x0]
    6c40:	aa1303e0 	mov	x0, x19
    6c44:	97fffa00 	bl	5444 <fwp_rc_share>
    6c48:	aa1303e0 	mov	x0, x19
    6c4c:	97ffff0d 	bl	6880 <f37>
    6c50:	aa0003f3 	mov	x19, x0
    6c54:	97fff9fc 	bl	5444 <fwp_rc_share>
    6c58:	aa1303e0 	mov	x0, x19
    6c5c:	f9400bf3 	ldr	x19, [sp, #16]
    6c60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c64:	d65f03c0 	ret
    6c68:	d503201f 	nop
    6c6c:	d503201f 	nop

0000000000006c70 <fwp_args37>:
    6c70:	7100003f 	cmp	w1, #0x0
    6c74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c78:	54000041 	b.ne	6c80 <fwp_args37+0x10>  // b.any
    6c7c:	d65f03c0 	ret
    6c80:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6c84:	91150042 	add	x2, x2, #0x540
    6c88:	f9400001 	ldr	x1, [x0]
    6c8c:	f949d843 	ldr	x3, [x2, #5040]
    6c90:	f949ec40 	ldr	x0, [x2, #5080]
    6c94:	cb030021 	sub	x1, x1, x3
    6c98:	eb00403f 	cmp	x1, x0, lsl #16
    6c9c:	54ffff02 	b.cs	6c7c <fwp_args37+0xc>  // b.hs, b.nlast
    6ca0:	d350fc20 	lsr	x0, x1, #16
    6ca4:	f949fc44 	ldr	x4, [x2, #5112]
    6ca8:	8b000800 	add	x0, x0, x0, lsl #2
    6cac:	d37df002 	lsl	x2, x0, #3
    6cb0:	8b020083 	add	x3, x4, x2
    6cb4:	f9401060 	ldr	x0, [x3, #32]
    6cb8:	b4fffe20 	cbz	x0, 6c7c <fwp_args37+0xc>
    6cbc:	38626882 	ldrb	w2, [x4, x2]
    6cc0:	7100085f 	cmp	w2, #0x2
    6cc4:	54000220 	b.eq	6d08 <fwp_args37+0x98>  // b.none
    6cc8:	7100045f 	cmp	w2, #0x1
    6ccc:	54fffd81 	b.ne	6c7c <fwp_args37+0xc>  // b.any
    6cd0:	29430864 	ldp	w4, w2, [x3, #24]
    6cd4:	92403c21 	and	x1, x1, #0xffff
    6cd8:	9b047c21 	mul	x1, x1, x4
    6cdc:	d360fc21 	lsr	x1, x1, #32
    6ce0:	eb02003f 	cmp	x1, x2
    6ce4:	54fffcc2 	b.cs	6c7c <fwp_args37+0xc>  // b.hs, b.nlast
    6ce8:	8b010000 	add	x0, x0, x1
    6cec:	39400001 	ldrb	w1, [x0]
    6cf0:	34fffc61 	cbz	w1, 6c7c <fwp_args37+0xc>
    6cf4:	7103f43f 	cmp	w1, #0xfd
    6cf8:	540000e8 	b.hi	6d14 <fwp_args37+0xa4>  // b.pmore
    6cfc:	11000421 	add	w1, w1, #0x1
    6d00:	39000001 	strb	w1, [x0]
    6d04:	d65f03c0 	ret
    6d08:	72003c3f 	tst	w1, #0xffff
    6d0c:	54ffff00 	b.eq	6cec <fwp_args37+0x7c>  // b.none
    6d10:	d65f03c0 	ret
    6d14:	17fff5d0 	b	4454 <fwp_rc_wide_dup>
    6d18:	d503201f 	nop
    6d1c:	d503201f 	nop

0000000000006d20 <fwp_caps37>:
    6d20:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d24:	910003fd 	mov	x29, sp
    6d28:	f9000bf3 	str	x19, [sp, #16]
    6d2c:	aa0003f3 	mov	x19, x0
    6d30:	b9400400 	ldr	w0, [x0, #4]
    6d34:	340004a0 	cbz	w0, 6dc8 <fwp_caps37+0xa8>
    6d38:	f9400660 	ldr	x0, [x19, #8]
    6d3c:	350004e1 	cbnz	w1, 6dd8 <fwp_caps37+0xb8>
    6d40:	97fffc94 	bl	5f90 <fwp_drop4>
    6d44:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6d48:	91150042 	add	x2, x2, #0x540
    6d4c:	f949d840 	ldr	x0, [x2, #5040]
    6d50:	f949ec41 	ldr	x1, [x2, #5080]
    6d54:	cb000260 	sub	x0, x19, x0
    6d58:	eb01401f 	cmp	x0, x1, lsl #16
    6d5c:	54000382 	b.cs	6dcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6d60:	d350fc01 	lsr	x1, x0, #16
    6d64:	f949fc44 	ldr	x4, [x2, #5112]
    6d68:	8b010821 	add	x1, x1, x1, lsl #2
    6d6c:	d37df021 	lsl	x1, x1, #3
    6d70:	8b010083 	add	x3, x4, x1
    6d74:	f9401062 	ldr	x2, [x3, #32]
    6d78:	b40002a2 	cbz	x2, 6dcc <fwp_caps37+0xac>
    6d7c:	38616881 	ldrb	w1, [x4, x1]
    6d80:	7100083f 	cmp	w1, #0x2
    6d84:	540006c0 	b.eq	6e5c <fwp_caps37+0x13c>  // b.none
    6d88:	7100043f 	cmp	w1, #0x1
    6d8c:	54000201 	b.ne	6dcc <fwp_caps37+0xac>  // b.any
    6d90:	29430464 	ldp	w4, w1, [x3, #24]
    6d94:	92403c00 	and	x0, x0, #0xffff
    6d98:	9b047c00 	mul	x0, x0, x4
    6d9c:	d360fc00 	lsr	x0, x0, #32
    6da0:	eb01001f 	cmp	x0, x1
    6da4:	54000142 	b.cs	6dcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6da8:	8b000042 	add	x2, x2, x0
    6dac:	39400040 	ldrb	w0, [x2]
    6db0:	7100041f 	cmp	w0, #0x1
    6db4:	540000c1 	b.ne	6dcc <fwp_caps37+0xac>  // b.any
    6db8:	aa1303e0 	mov	x0, x19
    6dbc:	f9400bf3 	ldr	x19, [sp, #16]
    6dc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6dc4:	17fff68b 	b	47f0 <fwp_mem_free>
    6dc8:	34fffbe1 	cbz	w1, 6d44 <fwp_caps37+0x24>
    6dcc:	f9400bf3 	ldr	x19, [sp, #16]
    6dd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6dd4:	d65f03c0 	ret
    6dd8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6ddc:	91150042 	add	x2, x2, #0x540
    6de0:	f949d843 	ldr	x3, [x2, #5040]
    6de4:	f949ec41 	ldr	x1, [x2, #5080]
    6de8:	cb030000 	sub	x0, x0, x3
    6dec:	eb01401f 	cmp	x0, x1, lsl #16
    6df0:	54fffee2 	b.cs	6dcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6df4:	d350fc01 	lsr	x1, x0, #16
    6df8:	f949fc44 	ldr	x4, [x2, #5112]
    6dfc:	8b010821 	add	x1, x1, x1, lsl #2
    6e00:	d37df021 	lsl	x1, x1, #3
    6e04:	8b010083 	add	x3, x4, x1
    6e08:	f9401062 	ldr	x2, [x3, #32]
    6e0c:	b4fffe02 	cbz	x2, 6dcc <fwp_caps37+0xac>
    6e10:	38616881 	ldrb	w1, [x4, x1]
    6e14:	7100083f 	cmp	w1, #0x2
    6e18:	54000280 	b.eq	6e68 <fwp_caps37+0x148>  // b.none
    6e1c:	7100043f 	cmp	w1, #0x1
    6e20:	54fffd61 	b.ne	6dcc <fwp_caps37+0xac>  // b.any
    6e24:	92403c01 	and	x1, x0, #0xffff
    6e28:	29430064 	ldp	w4, w0, [x3, #24]
    6e2c:	9b047c21 	mul	x1, x1, x4
    6e30:	d360fc21 	lsr	x1, x1, #32
    6e34:	eb00003f 	cmp	x1, x0
    6e38:	54fffca2 	b.cs	6dcc <fwp_caps37+0xac>  // b.hs, b.nlast
    6e3c:	8b010042 	add	x2, x2, x1
    6e40:	39400040 	ldrb	w0, [x2]
    6e44:	34fffc40 	cbz	w0, 6dcc <fwp_caps37+0xac>
    6e48:	7103f41f 	cmp	w0, #0xfd
    6e4c:	54000148 	b.hi	6e74 <fwp_caps37+0x154>  // b.pmore
    6e50:	11000400 	add	w0, w0, #0x1
    6e54:	39000040 	strb	w0, [x2]
    6e58:	17ffffdd 	b	6dcc <fwp_caps37+0xac>
    6e5c:	72003c1f 	tst	w0, #0xffff
    6e60:	54fffb61 	b.ne	6dcc <fwp_caps37+0xac>  // b.any
    6e64:	17ffffd2 	b	6dac <fwp_caps37+0x8c>
    6e68:	72003c1f 	tst	w0, #0xffff
    6e6c:	54fffb01 	b.ne	6dcc <fwp_caps37+0xac>  // b.any
    6e70:	17fffff4 	b	6e40 <fwp_caps37+0x120>
    6e74:	f9400bf3 	ldr	x19, [sp, #16]
    6e78:	aa0203e0 	mov	x0, x2
    6e7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e80:	17fff575 	b	4454 <fwp_rc_wide_dup>

0000000000006e84 <fwp_write>:
    6e84:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6e88:	910003fd 	mov	x29, sp
    6e8c:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6e90:	f947f484 	ldr	x4, [x4, #4072]
    6e94:	a90153f3 	stp	x19, x20, [sp, #16]
    6e98:	d10943ff 	sub	sp, sp, #0x250
    6e9c:	b9400045 	ldr	w5, [x2]
    6ea0:	aa0003f4 	mov	x20, x0
    6ea4:	f9400080 	ldr	x0, [x4]
    6ea8:	f90127e0 	str	x0, [sp, #584]
    6eac:	d2800000 	mov	x0, #0x0                   	// #0
    6eb0:	710064bf 	cmp	w5, #0x19
    6eb4:	54000408 	b.hi	6f34 <fwp_write+0xb0>  // b.pmore
    6eb8:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x830>
    6ebc:	aa0103f3 	mov	x19, x1
    6ec0:	91108000 	add	x0, x0, #0x420
    6ec4:	f9013bf5 	str	x21, [sp, #624]
    6ec8:	f9013ff6 	str	x22, [sp, #632]
    6ecc:	f90153fb 	str	x27, [sp, #672]
    6ed0:	f90157fc 	str	x28, [sp, #680]
    6ed4:	aa0203fc 	mov	x28, x2
    6ed8:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6edc:	10000061 	adr	x1, 6ee8 <fwp_write+0x64>
    6ee0:	8b20a820 	add	x0, x1, w0, sxth #2
    6ee4:	d61f0000 	br	x0
    6ee8:	910123e0 	add	x0, sp, #0x48
    6eec:	aa1303e5 	mov	x5, x19
    6ef0:	90000024 	adrp	x4, a000 <fwp_main_thread+0x2190>
    6ef4:	aa0003f3 	mov	x19, x0
    6ef8:	91300084 	add	x4, x4, #0xc00
    6efc:	d2804003 	mov	x3, #0x200                 	// #512
    6f00:	aa0303e1 	mov	x1, x3
    6f04:	52800042 	mov	w2, #0x2                   	// #2
    6f08:	97ffee3a 	bl	27f0 <__snprintf_chk@plt>
    6f0c:	aa1303e0 	mov	x0, x19
    6f10:	97ffee00 	bl	2710 <strlen@plt>
    6f14:	aa1303e1 	mov	x1, x19
    6f18:	aa0003e2 	mov	x2, x0
    6f1c:	aa1403e0 	mov	x0, x20
    6f20:	97fff13c 	bl	3410 <buf_put>
    6f24:	f9413bf5 	ldr	x21, [sp, #624]
    6f28:	f9413ff6 	ldr	x22, [sp, #632]
    6f2c:	f94153fb 	ldr	x27, [sp, #672]
    6f30:	f94157fc 	ldr	x28, [sp, #680]
    6f34:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6f38:	f947f400 	ldr	x0, [x0, #4072]
    6f3c:	f94127e2 	ldr	x2, [sp, #584]
    6f40:	f9400001 	ldr	x1, [x0]
    6f44:	eb010042 	subs	x2, x2, x1
    6f48:	d2800001 	mov	x1, #0x0                   	// #0
    6f4c:	540077a1 	b.ne	7e40 <fwp_write+0xfbc>  // b.any
    6f50:	910943ff 	add	sp, sp, #0x250
    6f54:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f58:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6f5c:	d65f03c0 	ret
    6f60:	910123e0 	add	x0, sp, #0x48
    6f64:	aa1303e5 	mov	x5, x19
    6f68:	90000024 	adrp	x4, a000 <fwp_main_thread+0x2190>
    6f6c:	aa0003f3 	mov	x19, x0
    6f70:	912fe084 	add	x4, x4, #0xbf8
    6f74:	d2804003 	mov	x3, #0x200                 	// #512
    6f78:	17ffffe2 	b	6f00 <fwp_write+0x7c>
    6f7c:	71004cbf 	cmp	w5, #0x13
    6f80:	90000020 	adrp	x0, a000 <fwp_main_thread+0x2190>
    6f84:	90000021 	adrp	x1, a000 <fwp_main_thread+0x2190>
    6f88:	912fa000 	add	x0, x0, #0xbe8
    6f8c:	912fc021 	add	x1, x1, #0xbf0
    6f90:	d2800082 	mov	x2, #0x4                   	// #4
    6f94:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6f98:	aa1403e0 	mov	x0, x20
    6f9c:	f90143f7 	str	x23, [sp, #640]
    6fa0:	d2800016 	mov	x22, #0x0                   	// #0
    6fa4:	f90147f8 	str	x24, [sp, #648]
    6fa8:	97fff11a 	bl	3410 <buf_put>
    6fac:	f9400260 	ldr	x0, [x19]
    6fb0:	90000037 	adrp	x23, a000 <fwp_main_thread+0x2190>
    6fb4:	d2800015 	mov	x21, #0x0                   	// #0
    6fb8:	9131c2f7 	add	x23, x23, #0xc70
    6fbc:	b4004780 	cbz	x0, 78ac <fwp_write+0xa28>
    6fc0:	b9400380 	ldr	w0, [x28]
    6fc4:	52800003 	mov	w3, #0x0                   	// #0
    6fc8:	f9401f82 	ldr	x2, [x28, #56]
    6fcc:	71004c1f 	cmp	w0, #0x13
    6fd0:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    6fd4:	aa1403e0 	mov	x0, x20
    6fd8:	8b010e61 	add	x1, x19, x1, lsl #3
    6fdc:	f9400421 	ldr	x1, [x1, #8]
    6fe0:	97ffffa9 	bl	6e84 <fwp_write>
    6fe4:	b9400380 	ldr	w0, [x28]
    6fe8:	7100481f 	cmp	w0, #0x12
    6fec:	54004b20 	b.eq	7950 <fwp_write+0xacc>  // b.none
    6ff0:	f9400260 	ldr	x0, [x19]
    6ff4:	910006b5 	add	x21, x21, #0x1
    6ff8:	91000ad6 	add	x22, x22, #0x2
    6ffc:	eb15001f 	cmp	x0, x21
    7000:	54004569 	b.ls	78ac <fwp_write+0xa28>  // b.plast
    7004:	aa1703e1 	mov	x1, x23
    7008:	aa1403e0 	mov	x0, x20
    700c:	d2800042 	mov	x2, #0x2                   	// #2
    7010:	97fff100 	bl	3410 <buf_put>
    7014:	17ffffeb 	b	6fc0 <fwp_write+0x13c>
    7018:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    701c:	9130a021 	add	x1, x1, #0xc28
    7020:	d28000c2 	mov	x2, #0x6                   	// #6
    7024:	aa1403e0 	mov	x0, x20
    7028:	91004273 	add	x19, x19, #0x10
    702c:	97fff0f9 	bl	3410 <buf_put>
    7030:	aa1303e0 	mov	x0, x19
    7034:	97ffedb7 	bl	2710 <strlen@plt>
    7038:	aa1303e1 	mov	x1, x19
    703c:	aa0003e2 	mov	x2, x0
    7040:	aa1403e0 	mov	x0, x20
    7044:	97fff0f3 	bl	3410 <buf_put>
    7048:	528007c3 	mov	w3, #0x3e                  	// #62
    704c:	aa1403e0 	mov	x0, x20
    7050:	91001fe1 	add	x1, sp, #0x7
    7054:	d2800022 	mov	x2, #0x1                   	// #1
    7058:	39001fe3 	strb	w3, [sp, #7]
    705c:	17ffffb1 	b	6f20 <fwp_write+0x9c>
    7060:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7064:	f947f400 	ldr	x0, [x0, #4072]
    7068:	f94127e2 	ldr	x2, [sp, #584]
    706c:	f9400001 	ldr	x1, [x0]
    7070:	eb010042 	subs	x2, x2, x1
    7074:	d2800001 	mov	x1, #0x0                   	// #0
    7078:	540034c1 	b.ne	7710 <fwp_write+0x88c>  // b.any
    707c:	f9413bf5 	ldr	x21, [sp, #624]
    7080:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7084:	f9413ff6 	ldr	x22, [sp, #632]
    7088:	aa1403e0 	mov	x0, x20
    708c:	91302021 	add	x1, x1, #0xc08
    7090:	d2800142 	mov	x2, #0xa                   	// #10
    7094:	f94153fb 	ldr	x27, [sp, #672]
    7098:	f94157fc 	ldr	x28, [sp, #680]
    709c:	910943ff 	add	sp, sp, #0x250
    70a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    70a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    70a8:	17fff0da 	b	3410 <buf_put>
    70ac:	f9400456 	ldr	x22, [x2, #8]
    70b0:	f90143f7 	str	x23, [sp, #640]
    70b4:	f90147f8 	str	x24, [sp, #648]
    70b8:	b4005af6 	cbz	x22, 7c14 <fwp_write+0xd90>
    70bc:	aa1603e0 	mov	x0, x22
    70c0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    70c4:	91322021 	add	x1, x1, #0xc88
    70c8:	97ffee0e 	bl	2900 <strcmp@plt>
    70cc:	2a0003f5 	mov	w21, w0
    70d0:	34005fc0 	cbz	w0, 7cc8 <fwp_write+0xe44>
    70d4:	aa1603e0 	mov	x0, x22
    70d8:	97ffed8e 	bl	2710 <strlen@plt>
    70dc:	aa1603e1 	mov	x1, x22
    70e0:	aa0003e2 	mov	x2, x0
    70e4:	aa1403e0 	mov	x0, x20
    70e8:	97fff0ca 	bl	3410 <buf_put>
    70ec:	52800403 	mov	w3, #0x20                  	// #32
    70f0:	91001ff5 	add	x21, sp, #0x7
    70f4:	aa1503e1 	mov	x1, x21
    70f8:	aa1403e0 	mov	x0, x20
    70fc:	d2800022 	mov	x2, #0x1                   	// #1
    7100:	39001fe3 	strb	w3, [sp, #7]
    7104:	97fff0c3 	bl	3410 <buf_put>
    7108:	52800f63 	mov	w3, #0x7b                  	// #123
    710c:	aa1403e0 	mov	x0, x20
    7110:	aa1503e1 	mov	x1, x21
    7114:	d2800022 	mov	x2, #0x1                   	// #1
    7118:	39001fe3 	strb	w3, [sp, #7]
    711c:	97fff0bd 	bl	3410 <buf_put>
    7120:	b9401380 	ldr	w0, [x28, #16]
    7124:	52800018 	mov	w24, #0x0                   	// #0
    7128:	7100001f 	cmp	w0, #0x0
    712c:	54003a8d 	b.le	787c <fwp_write+0x9f8>
    7130:	f9014bf9 	str	x25, [sp, #656]
    7134:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x2190>
    7138:	9132c339 	add	x25, x25, #0xcb0
    713c:	f9014ffa 	str	x26, [sp, #664]
    7140:	f000001a 	adrp	x26, a000 <fwp_main_thread+0x2190>
    7144:	9131c35a 	add	x26, x26, #0xc70
    7148:	91002276 	add	x22, x19, #0x8
    714c:	d2800013 	mov	x19, #0x0                   	// #0
    7150:	b5003e73 	cbnz	x19, 791c <fwp_write+0xa98>
    7154:	d37df277 	lsl	x23, x19, #3
    7158:	34003c98 	cbz	w24, 78e8 <fwp_write+0xa64>
    715c:	f9401382 	ldr	x2, [x28, #32]
    7160:	aa1403e0 	mov	x0, x20
    7164:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7168:	52800003 	mov	w3, #0x0                   	// #0
    716c:	f8776842 	ldr	x2, [x2, x23]
    7170:	91000673 	add	x19, x19, #0x1
    7174:	97ffff44 	bl	6e84 <fwp_write>
    7178:	b9401380 	ldr	w0, [x28, #16]
    717c:	6b13001f 	cmp	w0, w19
    7180:	54fffe8c 	b.gt	7150 <fwp_write+0x2cc>
    7184:	f9414bf9 	ldr	x25, [sp, #656]
    7188:	f9414ffa 	ldr	x26, [sp, #664]
    718c:	34003798 	cbz	w24, 787c <fwp_write+0x9f8>
    7190:	52800523 	mov	w3, #0x29                  	// #41
    7194:	aa1503e1 	mov	x1, x21
    7198:	aa1403e0 	mov	x0, x20
    719c:	d2800022 	mov	x2, #0x1                   	// #1
    71a0:	39001fe3 	strb	w3, [sp, #7]
    71a4:	97fff09b 	bl	3410 <buf_put>
    71a8:	f9413bf5 	ldr	x21, [sp, #624]
    71ac:	f9413ff6 	ldr	x22, [sp, #632]
    71b0:	f94143f7 	ldr	x23, [sp, #640]
    71b4:	f94147f8 	ldr	x24, [sp, #648]
    71b8:	f94153fb 	ldr	x27, [sp, #672]
    71bc:	f94157fc 	ldr	x28, [sp, #680]
    71c0:	17ffff5d 	b	6f34 <fwp_write+0xb0>
    71c4:	b9404855 	ldr	w21, [x2, #72]
    71c8:	aa1403e0 	mov	x0, x20
    71cc:	93407eb6 	sxtw	x22, w21
    71d0:	91000ac1 	add	x1, x22, #0x2
    71d4:	97fff05c 	bl	3344 <buf_grow>
    71d8:	a9400281 	ldp	x1, x0, [x20]
    71dc:	528e8603 	mov	w3, #0x7430                	// #29744
    71e0:	78206823 	strh	w3, [x1, x0]
    71e4:	8b000022 	add	x2, x1, x0
    71e8:	710002bf 	cmp	w21, #0x0
    71ec:	540036ad 	b.le	78c0 <fwp_write+0xa3c>
    71f0:	110006a3 	add	w3, w21, #0x1
    71f4:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    71f8:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    71fc:	91000449 	add	x9, x2, #0x1
    7200:	8b23c043 	add	x3, x2, w3, sxtw
    7204:	f28aaac6 	movk	x6, #0x5556
    7208:	f2955568 	movk	x8, #0xaaab
    720c:	1400000d 	b	7240 <fwp_write+0x3bc>
    7210:	d2800021 	mov	x1, #0x1                   	// #1
    7214:	528005a5 	mov	w5, #0x2d                  	// #45
    7218:	f100001f 	cmp	x0, #0x0
    721c:	9b467e60 	smulh	x0, x19, x6
    7220:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7224:	381ff465 	strb	w5, [x3], #-1
    7228:	cb040000 	sub	x0, x0, x4
    722c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7230:	cb020000 	sub	x0, x0, x2
    7234:	8b010013 	add	x19, x0, x1
    7238:	eb03013f 	cmp	x9, x3
    723c:	54003420 	b.eq	78c0 <fwp_write+0xa3c>  // b.none
    7240:	9b467e60 	smulh	x0, x19, x6
    7244:	937ffe64 	asr	x4, x19, #63
    7248:	52800605 	mov	w5, #0x30                  	// #48
    724c:	cb040000 	sub	x0, x0, x4
    7250:	8b000400 	add	x0, x0, x0, lsl #1
    7254:	cb000260 	sub	x0, x19, x0
    7258:	91000c01 	add	x1, x0, #0x3
    725c:	9bc87c22 	umulh	x2, x1, x8
    7260:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7264:	8b4204e2 	add	x2, x7, x2, lsr #1
    7268:	eb020021 	subs	x1, x1, x2
    726c:	54fffd60 	b.eq	7218 <fwp_write+0x394>  // b.none
    7270:	f100043f 	cmp	x1, #0x1
    7274:	54fffce1 	b.ne	7210 <fwp_write+0x38c>  // b.any
    7278:	d2800001 	mov	x1, #0x0                   	// #0
    727c:	52800565 	mov	w5, #0x2b                  	// #43
    7280:	17ffffe6 	b	7218 <fwp_write+0x394>
    7284:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7288:	f947f400 	ldr	x0, [x0, #4072]
    728c:	f94127e2 	ldr	x2, [sp, #584]
    7290:	f9400001 	ldr	x1, [x0]
    7294:	eb010042 	subs	x2, x2, x1
    7298:	d2800001 	mov	x1, #0x0                   	// #0
    729c:	540023a1 	b.ne	7710 <fwp_write+0x88c>  // b.any
    72a0:	f9413bf5 	ldr	x21, [sp, #624]
    72a4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    72a8:	f9413ff6 	ldr	x22, [sp, #632]
    72ac:	aa1403e0 	mov	x0, x20
    72b0:	91306021 	add	x1, x1, #0xc18
    72b4:	d2800102 	mov	x2, #0x8                   	// #8
    72b8:	17ffff77 	b	7094 <fwp_write+0x210>
    72bc:	aa1403e0 	mov	x0, x20
    72c0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    72c4:	d28000c2 	mov	x2, #0x6                   	// #6
    72c8:	9131e021 	add	x1, x1, #0xc78
    72cc:	97fff051 	bl	3410 <buf_put>
    72d0:	d2800015 	mov	x21, #0x0                   	// #0
    72d4:	f9400263 	ldr	x3, [x19]
    72d8:	f240f87f 	tst	x3, #0x7fffffffffffffff
    72dc:	54002c40 	b.eq	7864 <fwp_write+0x9e0>  // b.none
    72e0:	f9401f82 	ldr	x2, [x28, #56]
    72e4:	f90143f7 	str	x23, [sp, #640]
    72e8:	f90147f8 	str	x24, [sp, #648]
    72ec:	d2800857 	mov	x23, #0x42                  	// #66
    72f0:	f9014bf9 	str	x25, [sp, #656]
    72f4:	f0000016 	adrp	x22, a000 <fwp_main_thread+0x2190>
    72f8:	f9014ffa 	str	x26, [sp, #664]
    72fc:	9131c2d6 	add	x22, x22, #0xc70
    7300:	d2800038 	mov	x24, #0x1                   	// #1
    7304:	f2a18017 	movk	x23, #0xc00, lsl #16
    7308:	d2809099 	mov	x25, #0x484                 	// #1156
    730c:	b4000482 	cbz	x2, 739c <fwp_write+0x518>
    7310:	b9400040 	ldr	w0, [x2]
    7314:	7100701f 	cmp	w0, #0x1c
    7318:	540042a0 	b.eq	7b6c <fwp_write+0xce8>  // b.none
    731c:	71006c1f 	cmp	w0, #0x1b
    7320:	540003e8 	b.hi	739c <fwp_write+0x518>  // b.pmore
    7324:	9ac02301 	lsl	x1, x24, x0
    7328:	ea17003f 	tst	x1, x23
    732c:	54003681 	b.ne	79fc <fwp_write+0xb78>  // b.any
    7330:	ea19003f 	tst	x1, x25
    7334:	54003501 	b.ne	79d4 <fwp_write+0xb50>  // b.any
    7338:	d2800424 	mov	x4, #0x21                  	// #33
    733c:	ea04003f 	tst	x1, x4
    7340:	540002e0 	b.eq	739c <fwp_write+0x518>  // b.none
    7344:	b7f849a3 	tbnz	x3, #63, 7c78 <fwp_write+0xdf4>
    7348:	91002261 	add	x1, x19, #0x8
    734c:	8b150021 	add	x1, x1, x21
    7350:	39400021 	ldrb	w1, [x1]
    7354:	7100001f 	cmp	w0, #0x0
    7358:	93401c23 	sxtb	x3, w1
    735c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7360:	aa1403e0 	mov	x0, x20
    7364:	52800003 	mov	w3, #0x0                   	// #0
    7368:	97fffec7 	bl	6e84 <fwp_write>
    736c:	910006b5 	add	x21, x21, #0x1
    7370:	f9400260 	ldr	x0, [x19]
    7374:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7378:	eb0002bf 	cmp	x21, x0
    737c:	540026c2 	b.cs	7854 <fwp_write+0x9d0>  // b.hs, b.nlast
    7380:	d2800042 	mov	x2, #0x2                   	// #2
    7384:	aa1603e1 	mov	x1, x22
    7388:	aa1403e0 	mov	x0, x20
    738c:	97fff021 	bl	3410 <buf_put>
    7390:	f9401f82 	ldr	x2, [x28, #56]
    7394:	f9400263 	ldr	x3, [x19]
    7398:	b5fffbc2 	cbnz	x2, 7310 <fwp_write+0x48c>
    739c:	d37df2a0 	lsl	x0, x21, #3
    73a0:	b7f83f03 	tbnz	x3, #63, 7b80 <fwp_write+0xcfc>
    73a4:	91002261 	add	x1, x19, #0x8
    73a8:	8b000020 	add	x0, x1, x0
    73ac:	f9400001 	ldr	x1, [x0]
    73b0:	17ffffec 	b	7360 <fwp_write+0x4dc>
    73b4:	a9400e62 	ldp	x2, x3, [x19]
    73b8:	b7f83ca3 	tbnz	x3, #63, 7b4c <fwp_write+0xcc8>
    73bc:	910123f5 	add	x21, sp, #0x48
    73c0:	aa1503e0 	mov	x0, x21
    73c4:	97ffee97 	bl	2e20 <fwp_fmt_u128>
    73c8:	aa1503e0 	mov	x0, x21
    73cc:	97ffecd1 	bl	2710 <strlen@plt>
    73d0:	aa1503e1 	mov	x1, x21
    73d4:	aa0003e2 	mov	x2, x0
    73d8:	17fffed1 	b	6f1c <fwp_write+0x98>
    73dc:	fd015be8 	str	d8, [sp, #688]
    73e0:	1e270268 	fmov	s8, w19
    73e4:	fd015fe9 	str	d9, [sp, #696]
    73e8:	1e282100 	fcmp	s8, s8
    73ec:	54004d26 	b.vs	7d90 <fwp_write+0xf0c>
    73f0:	1e20c101 	fabs	s1, s8
    73f4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    73f8:	1e270000 	fmov	s0, w0
    73fc:	1e202020 	fcmp	s1, s0
    7400:	54002c0d 	b.le	7980 <fwp_write+0xafc>
    7404:	1e202118 	fcmpe	s8, #0.0
    7408:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x2190>
    740c:	911fc042 	add	x2, x2, #0x7f0
    7410:	910123f5 	add	x21, sp, #0x48
    7414:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7418:	912f2021 	add	x1, x1, #0xbc8
    741c:	aa1503e0 	mov	x0, x21
    7420:	9a81c041 	csel	x1, x2, x1, gt
    7424:	97ffed67 	bl	29c0 <strcpy@plt>
    7428:	aa1503e0 	mov	x0, x21
    742c:	97ffecb9 	bl	2710 <strlen@plt>
    7430:	aa1503e1 	mov	x1, x21
    7434:	aa0003e2 	mov	x2, x0
    7438:	aa1403e0 	mov	x0, x20
    743c:	97ffeff5 	bl	3410 <buf_put>
    7440:	f9413bf5 	ldr	x21, [sp, #624]
    7444:	f9413ff6 	ldr	x22, [sp, #632]
    7448:	f94153fb 	ldr	x27, [sp, #672]
    744c:	f94157fc 	ldr	x28, [sp, #680]
    7450:	fd415be8 	ldr	d8, [sp, #688]
    7454:	fd415fe9 	ldr	d9, [sp, #696]
    7458:	17fffeb7 	b	6f34 <fwp_write+0xb0>
    745c:	f9400276 	ldr	x22, [x19]
    7460:	34002e03 	cbz	w3, 7a20 <fwp_write+0xb9c>
    7464:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7468:	f947f400 	ldr	x0, [x0, #4072]
    746c:	f94127e2 	ldr	x2, [sp, #584]
    7470:	f9400001 	ldr	x1, [x0]
    7474:	eb010042 	subs	x2, x2, x1
    7478:	d2800001 	mov	x1, #0x0                   	// #0
    747c:	540014a1 	b.ne	7710 <fwp_write+0x88c>  // b.any
    7480:	aa1603e2 	mov	x2, x22
    7484:	91002261 	add	x1, x19, #0x8
    7488:	f9413bf5 	ldr	x21, [sp, #624]
    748c:	aa1403e0 	mov	x0, x20
    7490:	f9413ff6 	ldr	x22, [sp, #632]
    7494:	17ffff00 	b	7094 <fwp_write+0x210>
    7498:	fd015be8 	str	d8, [sp, #688]
    749c:	9e670268 	fmov	d8, x19
    74a0:	fd015fe9 	str	d9, [sp, #696]
    74a4:	1e682100 	fcmp	d8, d8
    74a8:	54004746 	b.vs	7d90 <fwp_write+0xf0c>
    74ac:	1e60c101 	fabs	d1, d8
    74b0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    74b4:	9e670000 	fmov	d0, x0
    74b8:	910123f5 	add	x21, sp, #0x48
    74bc:	52800033 	mov	w19, #0x1                   	// #1
    74c0:	1e602020 	fcmp	d1, d0
    74c4:	540001ad 	b.le	74f8 <fwp_write+0x674>
    74c8:	1e602118 	fcmpe	d8, #0.0
    74cc:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x2190>
    74d0:	911fc042 	add	x2, x2, #0x7f0
    74d4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    74d8:	912f2021 	add	x1, x1, #0xbc8
    74dc:	aa1503e0 	mov	x0, x21
    74e0:	9a81c041 	csel	x1, x2, x1, gt
    74e4:	97ffed37 	bl	29c0 <strcpy@plt>
    74e8:	17ffffd0 	b	7428 <fwp_write+0x5a4>
    74ec:	11000673 	add	w19, w19, #0x1
    74f0:	71004a7f 	cmp	w19, #0x12
    74f4:	54003860 	b.eq	7c00 <fwp_write+0xd7c>  // b.none
    74f8:	1e604100 	fmov	d0, d8
    74fc:	2a1303e1 	mov	w1, w19
    7500:	aa1503e0 	mov	x0, x21
    7504:	97fff104 	bl	3914 <fwp_format_g.constprop.0>
    7508:	aa1503e0 	mov	x0, x21
    750c:	d2800001 	mov	x1, #0x0                   	// #0
    7510:	97ffec94 	bl	2760 <strtod@plt>
    7514:	1e602100 	fcmp	d8, d0
    7518:	54fffea1 	b.ne	74ec <fwp_write+0x668>  // b.any
    751c:	aa1503e0 	mov	x0, x21
    7520:	97ffeff5 	bl	34f4 <fwp_finish_float>
    7524:	17ffffc1 	b	7428 <fwp_write+0x5a4>
    7528:	a9400e62 	ldp	x2, x3, [x19]
    752c:	910123f3 	add	x19, sp, #0x48
    7530:	aa1303e0 	mov	x0, x19
    7534:	97ffee3b 	bl	2e20 <fwp_fmt_u128>
    7538:	17fffe75 	b	6f0c <fwp_write+0x88>
    753c:	f90143f7 	str	x23, [sp, #640]
    7540:	f90147f8 	str	x24, [sp, #648]
    7544:	2a1303f8 	mov	w24, w19
    7548:	f9014bf9 	str	x25, [sp, #656]
    754c:	f9014ffa 	str	x26, [sp, #664]
    7550:	f13ffe7f 	cmp	x19, #0xfff
    7554:	54000049 	b.ls	755c <fwp_write+0x6d8>  // b.plast
    7558:	b9400278 	ldr	w24, [x19]
    755c:	f9400f80 	ldr	x0, [x28, #24]
    7560:	2a1803f5 	mov	w21, w24
    7564:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7568:	d37ef6b9 	lsl	x25, x21, #2
    756c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7570:	aa1603e0 	mov	x0, x22
    7574:	97ffec67 	bl	2710 <strlen@plt>
    7578:	aa1603e1 	mov	x1, x22
    757c:	aa0003e2 	mov	x2, x0
    7580:	aa1403e0 	mov	x0, x20
    7584:	97ffefa3 	bl	3410 <buf_put>
    7588:	f9401780 	ldr	x0, [x28, #40]
    758c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7590:	7100001f 	cmp	w0, #0x0
    7594:	5400068d 	b.le	7664 <fwp_write+0x7e0>
    7598:	91002276 	add	x22, x19, #0x8
    759c:	91001ff5 	add	x21, sp, #0x7
    75a0:	d280001b 	mov	x27, #0x0                   	// #0
    75a4:	5280041a 	mov	w26, #0x20                  	// #32
    75a8:	f9401b80 	ldr	x0, [x28, #48]
    75ac:	aa1503e1 	mov	x1, x21
    75b0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    75b4:	d2800022 	mov	x2, #0x1                   	// #1
    75b8:	f8786803 	ldr	x3, [x0, x24]
    75bc:	aa1403e0 	mov	x0, x20
    75c0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    75c4:	39001ffa 	strb	w26, [sp, #7]
    75c8:	97ffef92 	bl	3410 <buf_put>
    75cc:	f13ffeff 	cmp	x23, #0xfff
    75d0:	b9400261 	ldr	w1, [x19]
    75d4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    75d8:	7100383f 	cmp	w1, #0xe
    75dc:	54000160 	b.eq	7608 <fwp_write+0x784>  // b.none
    75e0:	7100403f 	cmp	w1, #0x10
    75e4:	54001a60 	b.eq	7930 <fwp_write+0xaac>  // b.none
    75e8:	7100283f 	cmp	w1, #0xa
    75ec:	54002aa0 	b.eq	7b40 <fwp_write+0xcbc>  // b.none
    75f0:	540014ac 	b.gt	7884 <fwp_write+0xa00>
    75f4:	71000c3f 	cmp	w1, #0x3
    75f8:	540029ac 	b.gt	7b2c <fwp_write+0xca8>
    75fc:	d37ffee0 	lsr	x0, x23, #63
    7600:	37f814a1 	tbnz	w1, #31, 7894 <fwp_write+0xa10>
    7604:	d503201f 	nop
    7608:	34001460 	cbz	w0, 7894 <fwp_write+0xa10>
    760c:	52800503 	mov	w3, #0x28                  	// #40
    7610:	aa1503e1 	mov	x1, x21
    7614:	aa1403e0 	mov	x0, x20
    7618:	d2800022 	mov	x2, #0x1                   	// #1
    761c:	39001fe3 	strb	w3, [sp, #7]
    7620:	97ffef7c 	bl	3410 <buf_put>
    7624:	aa1303e2 	mov	x2, x19
    7628:	aa1703e1 	mov	x1, x23
    762c:	aa1403e0 	mov	x0, x20
    7630:	52800003 	mov	w3, #0x0                   	// #0
    7634:	97fffe14 	bl	6e84 <fwp_write>
    7638:	52800523 	mov	w3, #0x29                  	// #41
    763c:	aa1503e1 	mov	x1, x21
    7640:	aa1403e0 	mov	x0, x20
    7644:	d2800022 	mov	x2, #0x1                   	// #1
    7648:	39001fe3 	strb	w3, [sp, #7]
    764c:	97ffef71 	bl	3410 <buf_put>
    7650:	f9401780 	ldr	x0, [x28, #40]
    7654:	9100077b 	add	x27, x27, #0x1
    7658:	b8796800 	ldr	w0, [x0, x25]
    765c:	6b1b001f 	cmp	w0, w27
    7660:	54fffa4c 	b.gt	75a8 <fwp_write+0x724>
    7664:	f9413bf5 	ldr	x21, [sp, #624]
    7668:	f9413ff6 	ldr	x22, [sp, #632]
    766c:	f94143f7 	ldr	x23, [sp, #640]
    7670:	f94147f8 	ldr	x24, [sp, #648]
    7674:	f9414bf9 	ldr	x25, [sp, #656]
    7678:	f9414ffa 	ldr	x26, [sp, #664]
    767c:	f94153fb 	ldr	x27, [sp, #672]
    7680:	f94157fc 	ldr	x28, [sp, #680]
    7684:	17fffe2c 	b	6f34 <fwp_write+0xb0>
    7688:	52800783 	mov	w3, #0x3c                  	// #60
    768c:	91001ff3 	add	x19, sp, #0x7
    7690:	aa1303e1 	mov	x1, x19
    7694:	d2800022 	mov	x2, #0x1                   	// #1
    7698:	aa1403e0 	mov	x0, x20
    769c:	39001fe3 	strb	w3, [sp, #7]
    76a0:	97ffef5c 	bl	3410 <buf_put>
    76a4:	f9400795 	ldr	x21, [x28, #8]
    76a8:	aa1503e0 	mov	x0, x21
    76ac:	97ffec19 	bl	2710 <strlen@plt>
    76b0:	aa1503e1 	mov	x1, x21
    76b4:	aa0003e2 	mov	x2, x0
    76b8:	aa1403e0 	mov	x0, x20
    76bc:	97ffef55 	bl	3410 <buf_put>
    76c0:	528007c3 	mov	w3, #0x3e                  	// #62
    76c4:	aa1303e1 	mov	x1, x19
    76c8:	aa1403e0 	mov	x0, x20
    76cc:	d2800022 	mov	x2, #0x1                   	// #1
    76d0:	39001fe3 	strb	w3, [sp, #7]
    76d4:	17fffe13 	b	6f20 <fwp_write+0x9c>
    76d8:	f100067f 	cmp	x19, #0x1
    76dc:	540025a0 	b.eq	7b90 <fwp_write+0xd0c>  // b.none
    76e0:	b100067f 	cmn	x19, #0x1
    76e4:	54002bc0 	b.eq	7c5c <fwp_write+0xdd8>  // b.none
    76e8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    76ec:	912f4021 	add	x1, x1, #0xbd0
    76f0:	d2800022 	mov	x2, #0x1                   	// #1
    76f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76f8:	f947f400 	ldr	x0, [x0, #4072]
    76fc:	f94127e4 	ldr	x4, [sp, #584]
    7700:	f9400003 	ldr	x3, [x0]
    7704:	eb030084 	subs	x4, x4, x3
    7708:	d2800003 	mov	x3, #0x0                   	// #0
    770c:	54ffebe0 	b.eq	7488 <fwp_write+0x604>  // b.none
    7710:	f90143f7 	str	x23, [sp, #640]
    7714:	f90147f8 	str	x24, [sp, #648]
    7718:	f9014bf9 	str	x25, [sp, #656]
    771c:	f9014ffa 	str	x26, [sp, #664]
    7720:	fd015be8 	str	d8, [sp, #688]
    7724:	fd015fe9 	str	d9, [sp, #696]
    7728:	97ffec56 	bl	2880 <__stack_chk_fail@plt>
    772c:	52800b63 	mov	w3, #0x5b                  	// #91
    7730:	91001ff5 	add	x21, sp, #0x7
    7734:	aa1503e1 	mov	x1, x21
    7738:	aa1403e0 	mov	x0, x20
    773c:	d2800022 	mov	x2, #0x1                   	// #1
    7740:	f0000016 	adrp	x22, a000 <fwp_main_thread+0x2190>
    7744:	9131c2d6 	add	x22, x22, #0xc70
    7748:	39001fe3 	strb	w3, [sp, #7]
    774c:	97ffef31 	bl	3410 <buf_put>
    7750:	b4000273 	cbz	x19, 779c <fwp_write+0x918>
    7754:	f9400661 	ldr	x1, [x19, #8]
    7758:	aa1403e0 	mov	x0, x20
    775c:	f9401f82 	ldr	x2, [x28, #56]
    7760:	52800003 	mov	w3, #0x0                   	// #0
    7764:	97fffdc8 	bl	6e84 <fwp_write>
    7768:	f9400a73 	ldr	x19, [x19, #16]
    776c:	b4000193 	cbz	x19, 779c <fwp_write+0x918>
    7770:	aa1603e1 	mov	x1, x22
    7774:	aa1403e0 	mov	x0, x20
    7778:	d2800042 	mov	x2, #0x2                   	// #2
    777c:	97ffef25 	bl	3410 <buf_put>
    7780:	f9400661 	ldr	x1, [x19, #8]
    7784:	aa1403e0 	mov	x0, x20
    7788:	f9401f82 	ldr	x2, [x28, #56]
    778c:	52800003 	mov	w3, #0x0                   	// #0
    7790:	97fffdbd 	bl	6e84 <fwp_write>
    7794:	f9400a73 	ldr	x19, [x19, #16]
    7798:	b5fffed3 	cbnz	x19, 7770 <fwp_write+0x8ec>
    779c:	52800ba3 	mov	w3, #0x5d                  	// #93
    77a0:	aa1503e1 	mov	x1, x21
    77a4:	aa1403e0 	mov	x0, x20
    77a8:	d2800022 	mov	x2, #0x1                   	// #1
    77ac:	39001fe3 	strb	w3, [sp, #7]
    77b0:	17fffddc 	b	6f20 <fwp_write+0x9c>
    77b4:	aa1403e0 	mov	x0, x20
    77b8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    77bc:	d28000c2 	mov	x2, #0x6                   	// #6
    77c0:	91318021 	add	x1, x1, #0xc60
    77c4:	97ffef13 	bl	3410 <buf_put>
    77c8:	f9400260 	ldr	x0, [x19]
    77cc:	b40004c0 	cbz	x0, 7864 <fwp_write+0x9e0>
    77d0:	910123f5 	add	x21, sp, #0x48
    77d4:	91002276 	add	x22, x19, #0x8
    77d8:	f90143f7 	str	x23, [sp, #640]
    77dc:	d2800017 	mov	x23, #0x0                   	// #0
    77e0:	f90147f8 	str	x24, [sp, #648]
    77e4:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x2190>
    77e8:	9131a318 	add	x24, x24, #0xc68
    77ec:	f9014bf9 	str	x25, [sp, #656]
    77f0:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x2190>
    77f4:	9131c339 	add	x25, x25, #0xc70
    77f8:	f9014ffa 	str	x26, [sp, #664]
    77fc:	14000005 	b	7810 <fwp_write+0x98c>
    7800:	aa1903e1 	mov	x1, x25
    7804:	aa1403e0 	mov	x0, x20
    7808:	d2800042 	mov	x2, #0x2                   	// #2
    780c:	97ffef01 	bl	3410 <buf_put>
    7810:	38776ac5 	ldrb	w5, [x22, x23]
    7814:	d2804003 	mov	x3, #0x200                 	// #512
    7818:	aa1803e4 	mov	x4, x24
    781c:	aa0303e1 	mov	x1, x3
    7820:	52800042 	mov	w2, #0x2                   	// #2
    7824:	aa1503e0 	mov	x0, x21
    7828:	910006f7 	add	x23, x23, #0x1
    782c:	97ffebf1 	bl	27f0 <__snprintf_chk@plt>
    7830:	aa1503e0 	mov	x0, x21
    7834:	97ffebb7 	bl	2710 <strlen@plt>
    7838:	aa1503e1 	mov	x1, x21
    783c:	aa0003e2 	mov	x2, x0
    7840:	aa1403e0 	mov	x0, x20
    7844:	97ffeef3 	bl	3410 <buf_put>
    7848:	f9400260 	ldr	x0, [x19]
    784c:	eb17001f 	cmp	x0, x23
    7850:	54fffd88 	b.hi	7800 <fwp_write+0x97c>  // b.pmore
    7854:	f94143f7 	ldr	x23, [sp, #640]
    7858:	f94147f8 	ldr	x24, [sp, #648]
    785c:	f9414bf9 	ldr	x25, [sp, #656]
    7860:	f9414ffa 	ldr	x26, [sp, #664]
    7864:	52800ba3 	mov	w3, #0x5d                  	// #93
    7868:	aa1403e0 	mov	x0, x20
    786c:	91001fe1 	add	x1, sp, #0x7
    7870:	d2800022 	mov	x2, #0x1                   	// #1
    7874:	39001fe3 	strb	w3, [sp, #7]
    7878:	17fffdaa 	b	6f20 <fwp_write+0x9c>
    787c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7880:	17fffe45 	b	7194 <fwp_write+0x310>
    7884:	f10002ff 	cmp	x23, #0x0
    7888:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    788c:	71002c3f 	cmp	w1, #0xb
    7890:	54ffebc0 	b.eq	7608 <fwp_write+0x784>  // b.none
    7894:	aa1303e2 	mov	x2, x19
    7898:	aa1703e1 	mov	x1, x23
    789c:	aa1403e0 	mov	x0, x20
    78a0:	52800003 	mov	w3, #0x0                   	// #0
    78a4:	97fffd78 	bl	6e84 <fwp_write>
    78a8:	17ffff6a 	b	7650 <fwp_write+0x7cc>
    78ac:	aa1403e0 	mov	x0, x20
    78b0:	91001fe1 	add	x1, sp, #0x7
    78b4:	52800fa3 	mov	w3, #0x7d                  	// #125
    78b8:	d2800022 	mov	x2, #0x1                   	// #1
    78bc:	17fffe39 	b	71a0 <fwp_write+0x31c>
    78c0:	a9400281 	ldp	x1, x0, [x20]
    78c4:	91000800 	add	x0, x0, #0x2
    78c8:	8b160000 	add	x0, x0, x22
    78cc:	f9000680 	str	x0, [x20, #8]
    78d0:	3820683f 	strb	wzr, [x1, x0]
    78d4:	f9413bf5 	ldr	x21, [sp, #624]
    78d8:	f9413ff6 	ldr	x22, [sp, #632]
    78dc:	f94153fb 	ldr	x27, [sp, #672]
    78e0:	f94157fc 	ldr	x28, [sp, #680]
    78e4:	17fffd94 	b	6f34 <fwp_write+0xb0>
    78e8:	f9400f80 	ldr	x0, [x28, #24]
    78ec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    78f0:	aa1b03e0 	mov	x0, x27
    78f4:	97ffeb87 	bl	2710 <strlen@plt>
    78f8:	aa1b03e1 	mov	x1, x27
    78fc:	aa0003e2 	mov	x2, x0
    7900:	aa1403e0 	mov	x0, x20
    7904:	97ffeec3 	bl	3410 <buf_put>
    7908:	aa1903e1 	mov	x1, x25
    790c:	aa1403e0 	mov	x0, x20
    7910:	d2800062 	mov	x2, #0x3                   	// #3
    7914:	97ffeebf 	bl	3410 <buf_put>
    7918:	17fffe11 	b	715c <fwp_write+0x2d8>
    791c:	aa1a03e1 	mov	x1, x26
    7920:	aa1403e0 	mov	x0, x20
    7924:	d2800042 	mov	x2, #0x2                   	// #2
    7928:	97ffeeba 	bl	3410 <buf_put>
    792c:	17fffe0a 	b	7154 <fwp_write+0x2d0>
    7930:	f9400660 	ldr	x0, [x19, #8]
    7934:	b4fffb00 	cbz	x0, 7894 <fwp_write+0xa10>
    7938:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    793c:	91322021 	add	x1, x1, #0xc88
    7940:	97ffebf0 	bl	2900 <strcmp@plt>
    7944:	7100001f 	cmp	w0, #0x0
    7948:	1a9f07e0 	cset	w0, ne	// ne = any
    794c:	17ffff2f 	b	7608 <fwp_write+0x784>
    7950:	aa1403e0 	mov	x0, x20
    7954:	d2800042 	mov	x2, #0x2                   	// #2
    7958:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    795c:	91320021 	add	x1, x1, #0xc80
    7960:	97ffeeac 	bl	3410 <buf_put>
    7964:	91004261 	add	x1, x19, #0x10
    7968:	aa1403e0 	mov	x0, x20
    796c:	f9402382 	ldr	x2, [x28, #64]
    7970:	52800003 	mov	w3, #0x0                   	// #0
    7974:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7978:	97fffd43 	bl	6e84 <fwp_write>
    797c:	17fffd9d 	b	6ff0 <fwp_write+0x16c>
    7980:	1e22c109 	fcvt	d9, s8
    7984:	910123f5 	add	x21, sp, #0x48
    7988:	52800033 	mov	w19, #0x1                   	// #1
    798c:	d503201f 	nop
    7990:	1e604120 	fmov	d0, d9
    7994:	2a1303e1 	mov	w1, w19
    7998:	aa1503e0 	mov	x0, x21
    799c:	97ffefde 	bl	3914 <fwp_format_g.constprop.0>
    79a0:	aa1503e0 	mov	x0, x21
    79a4:	d2800001 	mov	x1, #0x0                   	// #0
    79a8:	97ffebe2 	bl	2930 <strtof@plt>
    79ac:	1e202100 	fcmp	s8, s0
    79b0:	54ffdb60 	b.eq	751c <fwp_write+0x698>  // b.none
    79b4:	11000673 	add	w19, w19, #0x1
    79b8:	71002a7f 	cmp	w19, #0xa
    79bc:	54fffea1 	b.ne	7990 <fwp_write+0xb0c>  // b.any
    79c0:	1e604120 	fmov	d0, d9
    79c4:	aa1503e0 	mov	x0, x21
    79c8:	52800121 	mov	w1, #0x9                   	// #9
    79cc:	97ffefd2 	bl	3914 <fwp_format_g.constprop.0>
    79d0:	17fffed3 	b	751c <fwp_write+0x698>
    79d4:	d37ef6a1 	lsl	x1, x21, #2
    79d8:	b7f81563 	tbnz	x3, #63, 7c84 <fwp_write+0xe00>
    79dc:	91002263 	add	x3, x19, #0x8
    79e0:	8b010061 	add	x1, x3, x1
    79e4:	b9400023 	ldr	w3, [x1]
    79e8:	7100081f 	cmp	w0, #0x2
    79ec:	2a0303e1 	mov	w1, w3
    79f0:	93407c63 	sxtw	x3, w3
    79f4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    79f8:	17fffe5a 	b	7360 <fwp_write+0x4dc>
    79fc:	d37ffaa1 	lsl	x1, x21, #1
    7a00:	b7f81363 	tbnz	x3, #63, 7c6c <fwp_write+0xde8>
    7a04:	91002263 	add	x3, x19, #0x8
    7a08:	8b010061 	add	x1, x3, x1
    7a0c:	79400021 	ldrh	w1, [x1]
    7a10:	7100041f 	cmp	w0, #0x1
    7a14:	93403c23 	sxth	x3, w1
    7a18:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7a1c:	17fffe51 	b	7360 <fwp_write+0x4dc>
    7a20:	52800443 	mov	w3, #0x22                  	// #34
    7a24:	91001ff5 	add	x21, sp, #0x7
    7a28:	91002273 	add	x19, x19, #0x8
    7a2c:	aa1503e1 	mov	x1, x21
    7a30:	aa1403e0 	mov	x0, x20
    7a34:	d2800022 	mov	x2, #0x1                   	// #1
    7a38:	39001fe3 	strb	w3, [sp, #7]
    7a3c:	f90143f7 	str	x23, [sp, #640]
    7a40:	8b160277 	add	x23, x19, x22
    7a44:	f90147f8 	str	x24, [sp, #648]
    7a48:	97ffee72 	bl	3410 <buf_put>
    7a4c:	b4000696 	cbz	x22, 7b1c <fwp_write+0xc98>
    7a50:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x2190>
    7a54:	9130c318 	add	x24, x24, #0xc30
    7a58:	f9014bf9 	str	x25, [sp, #656]
    7a5c:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x2190>
    7a60:	91314339 	add	x25, x25, #0xc50
    7a64:	f9014ffa 	str	x26, [sp, #664]
    7a68:	1400000d 	b	7a9c <fwp_write+0xc18>
    7a6c:	710024bf 	cmp	w5, #0x9
    7a70:	54000460 	b.eq	7afc <fwp_write+0xc78>  // b.none
    7a74:	710028bf 	cmp	w5, #0xa
    7a78:	54000a61 	b.ne	7bc4 <fwp_write+0xd40>  // b.any
    7a7c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7a80:	aa1403e0 	mov	x0, x20
    7a84:	91310021 	add	x1, x1, #0xc40
    7a88:	d2800042 	mov	x2, #0x2                   	// #2
    7a8c:	97ffee61 	bl	3410 <buf_put>
    7a90:	91000673 	add	x19, x19, #0x1
    7a94:	eb17027f 	cmp	x19, x23
    7a98:	540003e0 	b.eq	7b14 <fwp_write+0xc90>  // b.none
    7a9c:	39400265 	ldrb	w5, [x19]
    7aa0:	710034bf 	cmp	w5, #0xd
    7aa4:	54000180 	b.eq	7ad4 <fwp_write+0xc50>  // b.none
    7aa8:	54fffe29 	b.ls	7a6c <fwp_write+0xbe8>  // b.plast
    7aac:	710088bf 	cmp	w5, #0x22
    7ab0:	540001c0 	b.eq	7ae8 <fwp_write+0xc64>  // b.none
    7ab4:	710170bf 	cmp	w5, #0x5c
    7ab8:	54000741 	b.ne	7ba0 <fwp_write+0xd1c>  // b.any
    7abc:	aa1403e0 	mov	x0, x20
    7ac0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7ac4:	d2800042 	mov	x2, #0x2                   	// #2
    7ac8:	9130e021 	add	x1, x1, #0xc38
    7acc:	97ffee51 	bl	3410 <buf_put>
    7ad0:	17fffff0 	b	7a90 <fwp_write+0xc0c>
    7ad4:	aa1903e1 	mov	x1, x25
    7ad8:	aa1403e0 	mov	x0, x20
    7adc:	d2800042 	mov	x2, #0x2                   	// #2
    7ae0:	97ffee4c 	bl	3410 <buf_put>
    7ae4:	17ffffeb 	b	7a90 <fwp_write+0xc0c>
    7ae8:	aa1803e1 	mov	x1, x24
    7aec:	aa1403e0 	mov	x0, x20
    7af0:	d2800042 	mov	x2, #0x2                   	// #2
    7af4:	97ffee47 	bl	3410 <buf_put>
    7af8:	17ffffe6 	b	7a90 <fwp_write+0xc0c>
    7afc:	aa1403e0 	mov	x0, x20
    7b00:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7b04:	d2800042 	mov	x2, #0x2                   	// #2
    7b08:	91312021 	add	x1, x1, #0xc48
    7b0c:	97ffee41 	bl	3410 <buf_put>
    7b10:	17ffffe0 	b	7a90 <fwp_write+0xc0c>
    7b14:	f9414bf9 	ldr	x25, [sp, #656]
    7b18:	f9414ffa 	ldr	x26, [sp, #664]
    7b1c:	aa1503e1 	mov	x1, x21
    7b20:	aa1403e0 	mov	x0, x20
    7b24:	52800443 	mov	w3, #0x22                  	// #34
    7b28:	17fffd9d 	b	719c <fwp_write+0x318>
    7b2c:	7100103f 	cmp	w1, #0x4
    7b30:	54ffeb21 	b.ne	7894 <fwp_write+0xa10>  // b.any
    7b34:	f94006e0 	ldr	x0, [x23, #8]
    7b38:	d37ffc00 	lsr	x0, x0, #63
    7b3c:	17fffeb3 	b	7608 <fwp_write+0x784>
    7b40:	710002ff 	cmp	w23, #0x0
    7b44:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7b48:	17fffeb0 	b	7608 <fwp_write+0x784>
    7b4c:	528005a1 	mov	w1, #0x2d                  	// #45
    7b50:	eb0203e2 	negs	x2, x2
    7b54:	da0303e3 	ngc	x3, x3
    7b58:	910127e0 	add	x0, sp, #0x49
    7b5c:	910123f5 	add	x21, sp, #0x48
    7b60:	390123e1 	strb	w1, [sp, #72]
    7b64:	97ffecaf 	bl	2e20 <fwp_fmt_u128>
    7b68:	17fffe18 	b	73c8 <fwp_write+0x544>
    7b6c:	d37ceea1 	lsl	x1, x21, #4
    7b70:	b7f810a3 	tbnz	x3, #63, 7d84 <fwp_write+0xf00>
    7b74:	91002260 	add	x0, x19, #0x8
    7b78:	8b010001 	add	x1, x0, x1
    7b7c:	17fffdf9 	b	7360 <fwp_write+0x4dc>
    7b80:	f9400a61 	ldr	x1, [x19, #16]
    7b84:	8b010000 	add	x0, x0, x1
    7b88:	f9400001 	ldr	x1, [x0]
    7b8c:	17fffdf5 	b	7360 <fwp_write+0x4dc>
    7b90:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7b94:	d2800042 	mov	x2, #0x2                   	// #2
    7b98:	912f6021 	add	x1, x1, #0xbd8
    7b9c:	17fffed6 	b	76f4 <fwp_write+0x870>
    7ba0:	7101fcbf 	cmp	w5, #0x7f
    7ba4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7ba8:	540000e9 	b.ls	7bc4 <fwp_write+0xd40>  // b.plast
    7bac:	aa1503e1 	mov	x1, x21
    7bb0:	aa1403e0 	mov	x0, x20
    7bb4:	d2800022 	mov	x2, #0x1                   	// #1
    7bb8:	39001fe5 	strb	w5, [sp, #7]
    7bbc:	97ffee15 	bl	3410 <buf_put>
    7bc0:	17ffffb4 	b	7a90 <fwp_write+0xc0c>
    7bc4:	d2800203 	mov	x3, #0x10                  	// #16
    7bc8:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x2190>
    7bcc:	aa0303e1 	mov	x1, x3
    7bd0:	91316084 	add	x4, x4, #0xc58
    7bd4:	910123f6 	add	x22, sp, #0x48
    7bd8:	52800042 	mov	w2, #0x2                   	// #2
    7bdc:	aa1603e0 	mov	x0, x22
    7be0:	97ffeb04 	bl	27f0 <__snprintf_chk@plt>
    7be4:	aa1603e0 	mov	x0, x22
    7be8:	97ffeaca 	bl	2710 <strlen@plt>
    7bec:	aa1603e1 	mov	x1, x22
    7bf0:	aa0003e2 	mov	x2, x0
    7bf4:	aa1403e0 	mov	x0, x20
    7bf8:	97ffee06 	bl	3410 <buf_put>
    7bfc:	17ffffa5 	b	7a90 <fwp_write+0xc0c>
    7c00:	1e604100 	fmov	d0, d8
    7c04:	aa1503e0 	mov	x0, x21
    7c08:	52800221 	mov	w1, #0x11                  	// #17
    7c0c:	97ffef42 	bl	3914 <fwp_format_g.constprop.0>
    7c10:	17fffe43 	b	751c <fwp_write+0x698>
    7c14:	b9401040 	ldr	w0, [x2, #16]
    7c18:	350003c0 	cbnz	w0, 7c90 <fwp_write+0xe0c>
    7c1c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7c20:	f947f400 	ldr	x0, [x0, #4072]
    7c24:	f94127e2 	ldr	x2, [sp, #584]
    7c28:	f9400001 	ldr	x1, [x0]
    7c2c:	eb010042 	subs	x2, x2, x1
    7c30:	d2800001 	mov	x1, #0x0                   	// #0
    7c34:	54ffd721 	b.ne	7718 <fwp_write+0x894>  // b.any
    7c38:	f9413bf5 	ldr	x21, [sp, #624]
    7c3c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7c40:	f9413ff6 	ldr	x22, [sp, #632]
    7c44:	aa1403e0 	mov	x0, x20
    7c48:	f94143f7 	ldr	x23, [sp, #640]
    7c4c:	9132a021 	add	x1, x1, #0xca8
    7c50:	f94147f8 	ldr	x24, [sp, #648]
    7c54:	d2800042 	mov	x2, #0x2                   	// #2
    7c58:	17fffd0f 	b	7094 <fwp_write+0x210>
    7c5c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x2190>
    7c60:	d2800042 	mov	x2, #0x2                   	// #2
    7c64:	912f8021 	add	x1, x1, #0xbe0
    7c68:	17fffea3 	b	76f4 <fwp_write+0x870>
    7c6c:	f9400a63 	ldr	x3, [x19, #16]
    7c70:	8b030021 	add	x1, x1, x3
    7c74:	17ffff66 	b	7a0c <fwp_write+0xb88>
    7c78:	f9400a61 	ldr	x1, [x19, #16]
    7c7c:	8b0102a1 	add	x1, x21, x1
    7c80:	17fffdb4 	b	7350 <fwp_write+0x4cc>
    7c84:	f9400a63 	ldr	x3, [x19, #16]
    7c88:	8b030021 	add	x1, x1, x3
    7c8c:	17ffff56 	b	79e4 <fwp_write+0xb60>
    7c90:	b9404840 	ldr	w0, [x2, #72]
    7c94:	91001ff5 	add	x21, sp, #0x7
    7c98:	34ffa380 	cbz	w0, 7108 <fwp_write+0x284>
    7c9c:	52800503 	mov	w3, #0x28                  	// #40
    7ca0:	aa1403e0 	mov	x0, x20
    7ca4:	aa1503e1 	mov	x1, x21
    7ca8:	d2800022 	mov	x2, #0x1                   	// #1
    7cac:	39001fe3 	strb	w3, [sp, #7]
    7cb0:	97ffedd8 	bl	3410 <buf_put>
    7cb4:	b9401380 	ldr	w0, [x28, #16]
    7cb8:	52800038 	mov	w24, #0x1                   	// #1
    7cbc:	7100001f 	cmp	w0, #0x0
    7cc0:	54ffa38c 	b.gt	7130 <fwp_write+0x2ac>
    7cc4:	17fffd33 	b	7190 <fwp_write+0x30c>
    7cc8:	f9014bf9 	str	x25, [sp, #656]
    7ccc:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x118a0>
    7cd0:	f9014ffa 	str	x26, [sp, #664]
    7cd4:	f9400676 	ldr	x22, [x19, #8]
    7cd8:	910aa333 	add	x19, x25, #0x2a8
    7cdc:	91002273 	add	x19, x19, #0x8
    7ce0:	937ffed8 	asr	x24, x22, #63
    7ce4:	aa1802c0 	orr	x0, x22, x24
    7ce8:	b5000320 	cbnz	x0, 7d4c <fwp_write+0xec8>
    7cec:	110006b5 	add	w21, w21, #0x1
    7cf0:	710016bf 	cmp	w21, #0x5
    7cf4:	54ffffc1 	b.ne	7cec <fwp_write+0xe68>  // b.any
    7cf8:	b7f80578 	tbnz	x24, #63, 7da4 <fwp_write+0xf20>
    7cfc:	910023f3 	add	x19, sp, #0x8
    7d00:	aa1603e2 	mov	x2, x22
    7d04:	aa1303e0 	mov	x0, x19
    7d08:	d2800003 	mov	x3, #0x0                   	// #0
    7d0c:	97ffec45 	bl	2e20 <fwp_fmt_u128>
    7d10:	910123f5 	add	x21, sp, #0x48
    7d14:	f0000003 	adrp	x3, a000 <fwp_main_thread+0x2190>
    7d18:	aa1303e4 	mov	x4, x19
    7d1c:	aa1503e0 	mov	x0, x21
    7d20:	91328063 	add	x3, x3, #0xca0
    7d24:	d2804002 	mov	x2, #0x200                 	// #512
    7d28:	52800041 	mov	w1, #0x2                   	// #2
    7d2c:	97ffea7d 	bl	2720 <__sprintf_chk@plt>
    7d30:	aa1503e0 	mov	x0, x21
    7d34:	97ffea77 	bl	2710 <strlen@plt>
    7d38:	aa1503e1 	mov	x1, x21
    7d3c:	aa0003e2 	mov	x2, x0
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	97ffedb3 	bl	3410 <buf_put>
    7d48:	17fffe47 	b	7664 <fwp_write+0x7e0>
    7d4c:	f9400277 	ldr	x23, [x19]
    7d50:	aa1603e0 	mov	x0, x22
    7d54:	aa1803e1 	mov	x1, x24
    7d58:	aa1703e2 	mov	x2, x23
    7d5c:	937ffefa 	asr	x26, x23, #63
    7d60:	aa1a03e3 	mov	x3, x26
    7d64:	940009b3 	bl	a430 <__modti3>
    7d68:	aa010000 	orr	x0, x0, x1
    7d6c:	b40002c0 	cbz	x0, 7dc4 <fwp_write+0xf40>
    7d70:	110006b5 	add	w21, w21, #0x1
    7d74:	91004273 	add	x19, x19, #0x10
    7d78:	710016bf 	cmp	w21, #0x5
    7d7c:	54fffe81 	b.ne	7d4c <fwp_write+0xec8>  // b.any
    7d80:	17ffffde 	b	7cf8 <fwp_write+0xe74>
    7d84:	f9400a60 	ldr	x0, [x19, #16]
    7d88:	8b000021 	add	x1, x1, x0
    7d8c:	17fffd75 	b	7360 <fwp_write+0x4dc>
    7d90:	528c29c0 	mov	w0, #0x614e                	// #24910
    7d94:	910123f5 	add	x21, sp, #0x48
    7d98:	72a009c0 	movk	w0, #0x4e, lsl #16
    7d9c:	b9004be0 	str	w0, [sp, #72]
    7da0:	17fffda2 	b	7428 <fwp_write+0x5a4>
    7da4:	528005a1 	mov	w1, #0x2d                  	// #45
    7da8:	eb1603e2 	negs	x2, x22
    7dac:	da1803e3 	ngc	x3, x24
    7db0:	910027e0 	add	x0, sp, #0x9
    7db4:	910023f3 	add	x19, sp, #0x8
    7db8:	390023e1 	strb	w1, [sp, #8]
    7dbc:	97ffec19 	bl	2e20 <fwp_fmt_u128>
    7dc0:	17ffffd4 	b	7d10 <fwp_write+0xe8c>
    7dc4:	aa1703e2 	mov	x2, x23
    7dc8:	aa1a03e3 	mov	x3, x26
    7dcc:	aa1603e0 	mov	x0, x22
    7dd0:	aa1803e1 	mov	x1, x24
    7dd4:	940008b7 	bl	a0b0 <__divti3>
    7dd8:	aa0003e2 	mov	x2, x0
    7ddc:	aa0103e3 	mov	x3, x1
    7de0:	b7f80201 	tbnz	x1, #63, 7e20 <fwp_write+0xf9c>
    7de4:	910023f3 	add	x19, sp, #0x8
    7de8:	aa1303e0 	mov	x0, x19
    7dec:	97ffec0d 	bl	2e20 <fwp_fmt_u128>
    7df0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7df4:	910aa339 	add	x25, x25, #0x2a8
    7df8:	910123f5 	add	x21, sp, #0x48
    7dfc:	aa1303e4 	mov	x4, x19
    7e00:	aa1503e0 	mov	x0, x21
    7e04:	f0000003 	adrp	x3, a000 <fwp_main_thread+0x2190>
    7e08:	f8616b25 	ldr	x5, [x25, x1]
    7e0c:	91326063 	add	x3, x3, #0xc98
    7e10:	d2804002 	mov	x2, #0x200                 	// #512
    7e14:	52800041 	mov	w1, #0x2                   	// #2
    7e18:	97ffea42 	bl	2720 <__sprintf_chk@plt>
    7e1c:	17ffffc5 	b	7d30 <fwp_write+0xeac>
    7e20:	528005a4 	mov	w4, #0x2d                  	// #45
    7e24:	eb0003e2 	negs	x2, x0
    7e28:	da0103e3 	ngc	x3, x1
    7e2c:	910027e0 	add	x0, sp, #0x9
    7e30:	910023f3 	add	x19, sp, #0x8
    7e34:	390023e4 	strb	w4, [sp, #8]
    7e38:	97ffebfa 	bl	2e20 <fwp_fmt_u128>
    7e3c:	17ffffed 	b	7df0 <fwp_write+0xf6c>
    7e40:	f9013bf5 	str	x21, [sp, #624]
    7e44:	f9013ff6 	str	x22, [sp, #632]
    7e48:	f90143f7 	str	x23, [sp, #640]
    7e4c:	f90147f8 	str	x24, [sp, #648]
    7e50:	f9014bf9 	str	x25, [sp, #656]
    7e54:	f9014ffa 	str	x26, [sp, #664]
    7e58:	f90153fb 	str	x27, [sp, #672]
    7e5c:	f90157fc 	str	x28, [sp, #680]
    7e60:	fd015be8 	str	d8, [sp, #688]
    7e64:	fd015fe9 	str	d9, [sp, #696]
    7e68:	97ffea86 	bl	2880 <__stack_chk_fail@plt>
    7e6c:	d503201f 	nop

0000000000007e70 <fwp_main_thread>:
    7e70:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7e74:	d0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    7e78:	91150001 	add	x1, x0, #0x540
    7e7c:	910003fd 	mov	x29, sp
    7e80:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7e84:	f947f400 	ldr	x0, [x0, #4072]
    7e88:	a9025bf5 	stp	x21, x22, [sp, #32]
    7e8c:	a90363f7 	stp	x23, x24, [sp, #48]
    7e90:	d10643ff 	sub	sp, sp, #0x190
    7e94:	b953a421 	ldr	w1, [x1, #5028]
    7e98:	f9400002 	ldr	x2, [x0]
    7e9c:	f900c7e2 	str	x2, [sp, #392]
    7ea0:	d2800002 	mov	x2, #0x0                   	// #0
    7ea4:	340023e1 	cbz	w1, 8320 <fwp_main_thread+0x4b0>
    7ea8:	d0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    7eac:	91150000 	add	x0, x0, #0x540
    7eb0:	b953a800 	ldr	w0, [x0, #5032]
    7eb4:	35002400 	cbnz	w0, 8334 <fwp_main_thread+0x4c4>
    7eb8:	9101c3e5 	add	x5, sp, #0x70
    7ebc:	b00000d8 	adrp	x24, 20000 <__data_start>
    7ec0:	b00000c2 	adrp	x2, 20000 <__data_start>
    7ec4:	9100c316 	add	x22, x24, #0x30
    7ec8:	910d8042 	add	x2, x2, #0x360
    7ecc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    7ed0:	d2a00024 	mov	x4, #0x10000               	// #65536
    7ed4:	910223e0 	add	x0, sp, #0x88
    7ed8:	d2800001 	mov	x1, #0x0                   	// #0
    7edc:	f90003e0 	str	x0, [sp]
    7ee0:	a9018ec5 	stp	x5, x3, [x22, #24]
    7ee4:	f9000fe5 	str	x5, [sp, #24]
    7ee8:	f90047e2 	str	x2, [sp, #136]
    7eec:	b90093ff 	str	wzr, [sp, #144]
    7ef0:	f9004fe4 	str	x4, [sp, #152]
    7ef4:	97ffe9fb 	bl	26e0 <sigaltstack@plt>
    7ef8:	a91a53f3 	stp	x19, x20, [sp, #416]
    7efc:	35010c80 	cbnz	w0, a08c <fwp_main_thread+0x221c>
    7f00:	4f000400 	movi	v0.4s, #0x0
    7f04:	9103e3e0 	add	x0, sp, #0xf8
    7f08:	90ffffe1 	adrp	x1, 3000 <fwp_flush+0x10>
    7f0c:	9101c021 	add	x1, x1, #0x70
    7f10:	f9007be1 	str	x1, [sp, #240]
    7f14:	52800082 	mov	w2, #0x4                   	// #4
    7f18:	72a10002 	movk	w2, #0x800, lsl #16
    7f1c:	9103c3f3 	add	x19, sp, #0xf0
    7f20:	3d802000 	str	q0, [x0, #128]
    7f24:	b9017be2 	str	w2, [sp, #376]
    7f28:	ad000000 	stp	q0, q0, [x0]
    7f2c:	ad010000 	stp	q0, q0, [x0, #32]
    7f30:	ad020000 	stp	q0, q0, [x0, #64]
    7f34:	ad030000 	stp	q0, q0, [x0, #96]
    7f38:	97ffea42 	bl	2840 <sigemptyset@plt>
    7f3c:	35010a80 	cbnz	w0, a08c <fwp_main_thread+0x221c>
    7f40:	aa1303e1 	mov	x1, x19
    7f44:	d2800002 	mov	x2, #0x0                   	// #0
    7f48:	52800160 	mov	w0, #0xb                   	// #11
    7f4c:	97ffea55 	bl	28a0 <sigaction@plt>
    7f50:	350109e0 	cbnz	w0, a08c <fwp_main_thread+0x221c>
    7f54:	aa1303e1 	mov	x1, x19
    7f58:	d2800002 	mov	x2, #0x0                   	// #0
    7f5c:	528000e0 	mov	w0, #0x7                   	// #7
    7f60:	97ffea50 	bl	28a0 <sigaction@plt>
    7f64:	35010940 	cbnz	w0, a08c <fwp_main_thread+0x221c>
    7f68:	b942f6c0 	ldr	w0, [x22, #756]
    7f6c:	34001ec0 	cbz	w0, 8344 <fwp_main_thread+0x4d4>
    7f70:	9100c315 	add	x21, x24, #0x30
    7f74:	f9400ab3 	ldr	x19, [x21, #16]
    7f78:	b4000c73 	cbz	x19, 8104 <fwp_main_thread+0x294>
    7f7c:	aa1303f4 	mov	x20, x19
    7f80:	91010277 	add	x23, x19, #0x40
    7f84:	a91d6bf9 	stp	x25, x26, [sp, #464]
    7f88:	52800036 	mov	w22, #0x1                   	// #1
    7f8c:	39414a79 	ldrb	w25, [x19, #82]
    7f90:	39014a76 	strb	w22, [x19, #82]
    7f94:	f9401660 	ldr	x0, [x19, #40]
    7f98:	b4000620 	cbz	x0, 805c <fwp_main_thread+0x1ec>
    7f9c:	f9403261 	ldr	x1, [x19, #96]
    7fa0:	39414660 	ldrb	w0, [x19, #81]
    7fa4:	b4000ca1 	cbz	x1, 8138 <fwp_main_thread+0x2c8>
    7fa8:	36000b60 	tbz	w0, #0, 8114 <fwp_main_thread+0x2a4>
    7fac:	39414a82 	ldrb	w2, [x20, #82]
    7fb0:	f9402260 	ldr	x0, [x19, #64]
    7fb4:	37000ec2 	tbnz	w2, #0, 818c <fwp_main_thread+0x31c>
    7fb8:	f9403281 	ldr	x1, [x20, #96]
    7fbc:	a911fe97 	stp	x23, xzr, [x20, #280]
    7fc0:	f9009680 	str	x0, [x20, #296]
    7fc4:	b4000040 	cbz	x0, 7fcc <fwp_main_thread+0x15c>
    7fc8:	f9009014 	str	x20, [x0, #288]
    7fcc:	f9002274 	str	x20, [x19, #64]
    7fd0:	b4000101 	cbz	x1, 7ff0 <fwp_main_thread+0x180>
    7fd4:	f94046a0 	ldr	x0, [x21, #136]
    7fd8:	39015696 	strb	w22, [x20, #85]
    7fdc:	f9003681 	str	x1, [x20, #104]
    7fe0:	a910829f 	stp	xzr, x0, [x20, #264]
    7fe4:	b4000040 	cbz	x0, 7fec <fwp_main_thread+0x17c>
    7fe8:	f9008414 	str	x20, [x0, #264]
    7fec:	f90046b4 	str	x20, [x21, #136]
    7ff0:	39015a9f 	strb	wzr, [x20, #86]
    7ff4:	97fff92c 	bl	64a4 <fwp_block>
    7ff8:	f9408e82 	ldr	x2, [x20, #280]
    7ffc:	b4000142 	cbz	x2, 8024 <fwp_main_thread+0x1b4>
    8000:	a9520281 	ldp	x1, x0, [x20, #288]
    8004:	b4000d01 	cbz	x1, 81a4 <fwp_main_thread+0x334>
    8008:	f9009420 	str	x0, [x1, #296]
    800c:	f9409680 	ldr	x0, [x20, #296]
    8010:	b4000040 	cbz	x0, 8018 <fwp_main_thread+0x1a8>
    8014:	f9009001 	str	x1, [x0, #288]
    8018:	91080280 	add	x0, x20, #0x200
    801c:	f900969f 	str	xzr, [x20, #296]
    8020:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8024:	39415680 	ldrb	w0, [x20, #85]
    8028:	f9400aa2 	ldr	x2, [x21, #16]
    802c:	36000ac0 	tbz	w0, #0, 8184 <fwp_main_thread+0x314>
    8030:	a9508281 	ldp	x1, x0, [x20, #264]
    8034:	b4000bc1 	cbz	x1, 81ac <fwp_main_thread+0x33c>
    8038:	f9008820 	str	x0, [x1, #272]
    803c:	b4000040 	cbz	x0, 8044 <fwp_main_thread+0x1d4>
    8040:	f9008401 	str	x1, [x0, #264]
    8044:	91080280 	add	x0, x20, #0x200
    8048:	3901569f 	strb	wzr, [x20, #85]
    804c:	aa0203f4 	mov	x20, x2
    8050:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8054:	f9401660 	ldr	x0, [x19, #40]
    8058:	b5fffa20 	cbnz	x0, 7f9c <fwp_main_thread+0x12c>
    805c:	9100c300 	add	x0, x24, #0x30
    8060:	39014a79 	strb	w25, [x19, #82]
    8064:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    8068:	f9416c00 	ldr	x0, [x0, #728]
    806c:	b5000080 	cbnz	x0, 807c <fwp_main_thread+0x20c>
    8070:	9100c313 	add	x19, x24, #0x30
    8074:	f9417660 	ldr	x0, [x19, #744]
    8078:	b400f360 	cbz	x0, 9ee4 <fwp_main_thread+0x2074>
    807c:	9100c300 	add	x0, x24, #0x30
    8080:	f9418801 	ldr	x1, [x0, #784]
    8084:	b903081f 	str	wzr, [x0, #776]
    8088:	eb14003f 	cmp	x1, x20
    808c:	5400f421 	b.ne	9f10 <fwp_main_thread+0x20a0>  // b.any
    8090:	b40009d4 	cbz	x20, 81c8 <fwp_main_thread+0x358>
    8094:	9100c300 	add	x0, x24, #0x30
    8098:	52800021 	mov	w1, #0x1                   	// #1
    809c:	39014a81 	strb	w1, [x20, #82]
    80a0:	f9415805 	ldr	x5, [x0, #688]
    80a4:	b4000925 	cbz	x5, 81c8 <fwp_main_thread+0x358>
    80a8:	394140a0 	ldrb	w0, [x5, #80]
    80ac:	37000060 	tbnz	w0, #0, 80b8 <fwp_main_thread+0x248>
    80b0:	aa0503e0 	mov	x0, x5
    80b4:	97ffecef 	bl	3470 <fwp_cancel_tree.part.0>
    80b8:	f9409ca5 	ldr	x5, [x5, #312]
    80bc:	b5ffff65 	cbnz	x5, 80a8 <fwp_main_thread+0x238>
    80c0:	9100c313 	add	x19, x24, #0x30
    80c4:	52800035 	mov	w21, #0x1                   	// #1
    80c8:	f9402a80 	ldr	x0, [x20, #80]
    80cc:	f2001c1f 	tst	x0, #0xff000000ff
    80d0:	540000e1 	b.ne	80ec <fwp_main_thread+0x27c>  // b.any
    80d4:	f9401660 	ldr	x0, [x19, #40]
    80d8:	39015295 	strb	w21, [x20, #84]
    80dc:	f900829f 	str	xzr, [x20, #256]
    80e0:	b40006a0 	cbz	x0, 81b4 <fwp_main_thread+0x344>
    80e4:	f9008014 	str	x20, [x0, #256]
    80e8:	f9001674 	str	x20, [x19, #40]
    80ec:	97fff8ee 	bl	64a4 <fwp_block>
    80f0:	97fff880 	bl	62f0 <fwp_free_zombie>
    80f4:	f9415a60 	ldr	x0, [x19, #688]
    80f8:	b4000680 	cbz	x0, 81c8 <fwp_main_thread+0x358>
    80fc:	f9418a74 	ldr	x20, [x19, #784]
    8100:	17fffff2 	b	80c8 <fwp_main_thread+0x258>
    8104:	f9416ea0 	ldr	x0, [x21, #728]
    8108:	b50005a0 	cbnz	x0, 81bc <fwp_main_thread+0x34c>
    810c:	d2800014 	mov	x20, #0x0                   	// #0
    8110:	17ffffd8 	b	8070 <fwp_main_thread+0x200>
    8114:	97ffed7b 	bl	3700 <fwp_now_ns>
    8118:	f9403261 	ldr	x1, [x19, #96]
    811c:	eb01001f 	cmp	x0, x1
    8120:	540000ab 	b.lt	8134 <fwp_main_thread+0x2c4>  // b.tstop
    8124:	39414260 	ldrb	w0, [x19, #80]
    8128:	37000060 	tbnz	w0, #0, 8134 <fwp_main_thread+0x2c4>
    812c:	aa1303e0 	mov	x0, x19
    8130:	97ffecd0 	bl	3470 <fwp_cancel_tree.part.0>
    8134:	39414660 	ldrb	w0, [x19, #81]
    8138:	39414a82 	ldrb	w2, [x20, #82]
    813c:	3707f3a0 	tbnz	w0, #0, 7fb0 <fwp_main_thread+0x140>
    8140:	f9403261 	ldr	x1, [x19, #96]
    8144:	370001c2 	tbnz	w2, #0, 817c <fwp_main_thread+0x30c>
    8148:	f9403280 	ldr	x0, [x20, #96]
    814c:	b4000180 	cbz	x0, 817c <fwp_main_thread+0x30c>
    8150:	b4000061 	cbz	x1, 815c <fwp_main_thread+0x2ec>
    8154:	eb01001f 	cmp	x0, x1
    8158:	9a81d000 	csel	x0, x0, x1, le
    815c:	f9402261 	ldr	x1, [x19, #64]
    8160:	a911fe97 	stp	x23, xzr, [x20, #280]
    8164:	f9009681 	str	x1, [x20, #296]
    8168:	b400eb41 	cbz	x1, 9ed0 <fwp_main_thread+0x2060>
    816c:	f9009034 	str	x20, [x1, #288]
    8170:	aa0003e1 	mov	x1, x0
    8174:	f9002274 	str	x20, [x19, #64]
    8178:	17ffff97 	b	7fd4 <fwp_main_thread+0x164>
    817c:	f9402260 	ldr	x0, [x19, #64]
    8180:	17ffff8f 	b	7fbc <fwp_main_thread+0x14c>
    8184:	aa0203f4 	mov	x20, x2
    8188:	17ffff83 	b	7f94 <fwp_main_thread+0x124>
    818c:	a911fe97 	stp	x23, xzr, [x20, #280]
    8190:	f9009680 	str	x0, [x20, #296]
    8194:	b4000040 	cbz	x0, 819c <fwp_main_thread+0x32c>
    8198:	f9009014 	str	x20, [x0, #288]
    819c:	f9002274 	str	x20, [x19, #64]
    81a0:	17ffff94 	b	7ff0 <fwp_main_thread+0x180>
    81a4:	f9000040 	str	x0, [x2]
    81a8:	17ffff9a 	b	8010 <fwp_main_thread+0x1a0>
    81ac:	f90046a0 	str	x0, [x21, #136]
    81b0:	17ffffa3 	b	803c <fwp_main_thread+0x1cc>
    81b4:	f9001a74 	str	x20, [x19, #48]
    81b8:	17ffffcc 	b	80e8 <fwp_main_thread+0x278>
    81bc:	f9418aa0 	ldr	x0, [x21, #784]
    81c0:	b9030abf 	str	wzr, [x21, #776]
    81c4:	b500ea60 	cbnz	x0, 9f10 <fwp_main_thread+0x20a0>
    81c8:	9100c314 	add	x20, x24, #0x30
    81cc:	97fff849 	bl	62f0 <fwp_free_zombie>
    81d0:	f9401a80 	ldr	x0, [x20, #48]
    81d4:	b500e9e0 	cbnz	x0, 9f10 <fwp_main_thread+0x20a0>
    81d8:	f9404680 	ldr	x0, [x20, #136]
    81dc:	b500e9a0 	cbnz	x0, 9f10 <fwp_main_thread+0x20a0>
    81e0:	b940aa80 	ldr	w0, [x20, #168]
    81e4:	340001c0 	cbz	w0, 821c <fwp_main_thread+0x3ac>
    81e8:	93407c15 	sxtw	x21, w0
    81ec:	51000400 	sub	w0, w0, #0x1
    81f0:	d1000ab5 	sub	x21, x21, #0x2
    81f4:	9102c296 	add	x22, x20, #0xb0
    81f8:	cb2042b5 	sub	x21, x21, w0, uxtw
    81fc:	93407c13 	sxtw	x19, w0
    8200:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    8204:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8208:	b900aa93 	str	w19, [x20, #168]
    820c:	d1000673 	sub	x19, x19, #0x1
    8210:	97ffe9e4 	bl	29a0 <munmap@plt>
    8214:	eb15027f 	cmp	x19, x21
    8218:	54ffff41 	b.ne	8200 <fwp_main_thread+0x390>  // b.any
    821c:	900000d3 	adrp	x19, 20000 <__data_start>
    8220:	91004260 	add	x0, x19, #0x10
    8224:	b9400800 	ldr	w0, [x0, #8]
    8228:	37f80040 	tbnz	w0, #31, 8230 <fwp_main_thread+0x3c0>
    822c:	97ffe999 	bl	2890 <close@plt>
    8230:	9100c300 	add	x0, x24, #0x30
    8234:	91004261 	add	x1, x19, #0x10
    8238:	12800002 	mov	w2, #0xffffffff            	// #-1
    823c:	d2800013 	mov	x19, #0x0                   	// #0
    8240:	f9418c15 	ldr	x21, [x0, #792]
    8244:	b9000822 	str	w2, [x1, #8]
    8248:	f9419014 	ldr	x20, [x0, #800]
    824c:	b4000175 	cbz	x21, 8278 <fwp_main_thread+0x408>
    8250:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8254:	b40000c0 	cbz	x0, 826c <fwp_main_thread+0x3fc>
    8258:	f9400001 	ldr	x1, [x0]
    825c:	b500e5a1 	cbnz	x1, 9f10 <fwp_main_thread+0x20a0>
    8260:	f9400401 	ldr	x1, [x0, #8]
    8264:	b500e561 	cbnz	x1, 9f10 <fwp_main_thread+0x20a0>
    8268:	97fff162 	bl	47f0 <fwp_mem_free>
    826c:	91000673 	add	x19, x19, #0x1
    8270:	eb1302bf 	cmp	x21, x19
    8274:	54fffee1 	b.ne	8250 <fwp_main_thread+0x3e0>  // b.any
    8278:	aa1403e0 	mov	x0, x20
    827c:	97fff15d 	bl	47f0 <fwp_mem_free>
    8280:	9100c300 	add	x0, x24, #0x30
    8284:	f9418813 	ldr	x19, [x0, #784]
    8288:	f9018c1f 	str	xzr, [x0, #792]
    828c:	f901901f 	str	xzr, [x0, #800]
    8290:	b40001f3 	cbz	x19, 82cc <fwp_main_thread+0x45c>
    8294:	f9401661 	ldr	x1, [x19, #40]
    8298:	b500e3c1 	cbnz	x1, 9f10 <fwp_main_thread+0x20a0>
    829c:	f9405661 	ldr	x1, [x19, #168]
    82a0:	b500e381 	cbnz	x1, 9f10 <fwp_main_thread+0x20a0>
    82a4:	f9416c01 	ldr	x1, [x0, #728]
    82a8:	b500e341 	cbnz	x1, 9f10 <fwp_main_thread+0x20a0>
    82ac:	f9417400 	ldr	x0, [x0, #744]
    82b0:	b500e300 	cbnz	x0, 9f10 <fwp_main_thread+0x20a0>
    82b4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    82b8:	90000140 	adrp	x0, 30000 <alt.5+0xfca0>
    82bc:	910d8000 	add	x0, x0, #0x360
    82c0:	97ffe964 	bl	2850 <memset@plt>
    82c4:	aa1303e0 	mov	x0, x19
    82c8:	97fff14a 	bl	47f0 <fwp_mem_free>
    82cc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    82d0:	f947ec00 	ldr	x0, [x0, #4056]
    82d4:	9100c318 	add	x24, x24, #0x30
    82d8:	f9400000 	ldr	x0, [x0]
    82dc:	f9000b1f 	str	xzr, [x24, #16]
    82e0:	f9018b1f 	str	xzr, [x24, #784]
    82e4:	97ffe9b3 	bl	29b0 <fflush@plt>
    82e8:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    82ec:	f947f400 	ldr	x0, [x0, #4072]
    82f0:	f940c7e2 	ldr	x2, [sp, #392]
    82f4:	f9400001 	ldr	x1, [x0]
    82f8:	eb010042 	subs	x2, x2, x1
    82fc:	d2800001 	mov	x1, #0x0                   	// #0
    8300:	5400eb21 	b.ne	a064 <fwp_main_thread+0x21f4>  // b.any
    8304:	a95a53f3 	ldp	x19, x20, [sp, #416]
    8308:	910643ff 	add	sp, sp, #0x190
    830c:	d2800000 	mov	x0, #0x0                   	// #0
    8310:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8314:	a94363f7 	ldp	x23, x24, [sp, #48]
    8318:	a8c77bfd 	ldp	x29, x30, [sp], #112
    831c:	d65f03c0 	ret
    8320:	97ffeed9 	bl	3e84 <fwp_heap_init>
    8324:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    8328:	91150000 	add	x0, x0, #0x540
    832c:	b953a800 	ldr	w0, [x0, #5032]
    8330:	34ffdc40 	cbz	w0, 7eb8 <fwp_main_thread+0x48>
    8334:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    8338:	91348000 	add	x0, x0, #0xd20
    833c:	94000919 	bl	a7a0 <atexit>
    8340:	17fffede 	b	7eb8 <fwp_main_thread+0x48>
    8344:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    8348:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    834c:	f94162c2 	ldr	x2, [x22, #704]
    8350:	913d4021 	add	x1, x1, #0xf50
    8354:	a91e73fb 	stp	x27, x28, [sp, #480]
    8358:	9115001c 	add	x28, x0, #0x540
    835c:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    8360:	91260000 	add	x0, x0, #0x980
    8364:	a90707e2 	stp	x2, x1, [sp, #112]
    8368:	d2804017 	mov	x23, #0x200                 	// #512
    836c:	f94003e1 	ldr	x1, [sp]
    8370:	a90983ff 	stp	xzr, x0, [sp, #152]
    8374:	d2800014 	mov	x20, #0x0                   	// #0
    8378:	f9400fe0 	ldr	x0, [sp, #24]
    837c:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8380:	52800035 	mov	w21, #0x1                   	// #1
    8384:	fd00fbe8 	str	d8, [sp, #496]
    8388:	f9000bff 	str	xzr, [sp, #16]
    838c:	f90043e1 	str	x1, [sp, #128]
    8390:	f90047ff 	str	xzr, [sp, #136]
    8394:	f90162c0 	str	x0, [x22, #704]
    8398:	f9400be2 	ldr	x2, [sp, #16]
    839c:	f10006f9 	subs	x25, x23, #0x1
    83a0:	aa1303e1 	mov	x1, x19
    83a4:	da1f029a 	sbc	x26, x20, xzr
    83a8:	52800020 	mov	w0, #0x1                   	// #1
    83ac:	f9004bf9 	str	x25, [sp, #144]
    83b0:	a90f0bf9 	stp	x25, x2, [sp, #240]
    83b4:	97fff274 	bl	4d84 <fwp_data.part.0.constprop.0>
    83b8:	aa0003e2 	mov	x2, x0
    83bc:	f949db81 	ldr	x1, [x28, #5040]
    83c0:	f9000be2 	str	x2, [sp, #16]
    83c4:	f949ef80 	ldr	x0, [x28, #5080]
    83c8:	cb010041 	sub	x1, x2, x1
    83cc:	aa1903f7 	mov	x23, x25
    83d0:	aa1a03f4 	mov	x20, x26
    83d4:	eb00403f 	cmp	x1, x0, lsl #16
    83d8:	54000302 	b.cs	8438 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    83dc:	d350fc20 	lsr	x0, x1, #16
    83e0:	f949ff83 	ldr	x3, [x28, #5112]
    83e4:	8b000800 	add	x0, x0, x0, lsl #2
    83e8:	d37df002 	lsl	x2, x0, #3
    83ec:	8b020060 	add	x0, x3, x2
    83f0:	f9401016 	ldr	x22, [x0, #32]
    83f4:	b4000236 	cbz	x22, 8438 <fwp_main_thread+0x5c8>
    83f8:	38626862 	ldrb	w2, [x3, x2]
    83fc:	7100085f 	cmp	w2, #0x2
    8400:	54005ac0 	b.eq	8f58 <fwp_main_thread+0x10e8>  // b.none
    8404:	7100045f 	cmp	w2, #0x1
    8408:	54000181 	b.ne	8438 <fwp_main_thread+0x5c8>  // b.any
    840c:	29430002 	ldp	w2, w0, [x0, #24]
    8410:	92403c21 	and	x1, x1, #0xffff
    8414:	9b027c21 	mul	x1, x1, x2
    8418:	d360fc21 	lsr	x1, x1, #32
    841c:	eb00003f 	cmp	x1, x0
    8420:	540000c2 	b.cs	8438 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    8424:	8b0102d6 	add	x22, x22, x1
    8428:	394002c0 	ldrb	w0, [x22]
    842c:	7103fc1f 	cmp	w0, #0xff
    8430:	540059e0 	b.eq	8f6c <fwp_main_thread+0x10fc>  // b.none
    8434:	390002d5 	strb	w21, [x22]
    8438:	f9400be0 	ldr	x0, [sp, #16]
    843c:	f90047e0 	str	x0, [sp, #136]
    8440:	aa1a0320 	orr	x0, x25, x26
    8444:	b5fffaa0 	cbnz	x0, 8398 <fwp_main_thread+0x528>
    8448:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x830>
    844c:	9100c302 	add	x2, x24, #0x30
    8450:	f9403bf5 	ldr	x21, [sp, #112]
    8454:	910303e1 	add	x1, sp, #0xc0
    8458:	3dc12c00 	ldr	q0, [x0, #1200]
    845c:	52800020 	mov	w0, #0x1                   	// #1
    8460:	f9016055 	str	x21, [x2, #704]
    8464:	3d8033e0 	str	q0, [sp, #192]
    8468:	97fff247 	bl	4d84 <fwp_data.part.0.constprop.0>
    846c:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    8470:	91150022 	add	x2, x1, #0x540
    8474:	aa0003f6 	mov	x22, x0
    8478:	f949d841 	ldr	x1, [x2, #5040]
    847c:	f949ec40 	ldr	x0, [x2, #5080]
    8480:	cb0102c1 	sub	x1, x22, x1
    8484:	eb00403f 	cmp	x1, x0, lsl #16
    8488:	54000322 	b.cs	84ec <fwp_main_thread+0x67c>  // b.hs, b.nlast
    848c:	d350fc20 	lsr	x0, x1, #16
    8490:	f949fc43 	ldr	x3, [x2, #5112]
    8494:	8b000800 	add	x0, x0, x0, lsl #2
    8498:	d37df002 	lsl	x2, x0, #3
    849c:	8b020060 	add	x0, x3, x2
    84a0:	f9401014 	ldr	x20, [x0, #32]
    84a4:	b4000254 	cbz	x20, 84ec <fwp_main_thread+0x67c>
    84a8:	38626862 	ldrb	w2, [x3, x2]
    84ac:	7100085f 	cmp	w2, #0x2
    84b0:	5400d0a0 	b.eq	9ec4 <fwp_main_thread+0x2054>  // b.none
    84b4:	7100045f 	cmp	w2, #0x1
    84b8:	540001a1 	b.ne	84ec <fwp_main_thread+0x67c>  // b.any
    84bc:	29430002 	ldp	w2, w0, [x0, #24]
    84c0:	92403c21 	and	x1, x1, #0xffff
    84c4:	9b027c21 	mul	x1, x1, x2
    84c8:	d360fc21 	lsr	x1, x1, #32
    84cc:	eb00003f 	cmp	x1, x0
    84d0:	540000e2 	b.cs	84ec <fwp_main_thread+0x67c>  // b.hs, b.nlast
    84d4:	8b010294 	add	x20, x20, x1
    84d8:	39400280 	ldrb	w0, [x20]
    84dc:	7103fc1f 	cmp	w0, #0xff
    84e0:	5400d820 	b.eq	9fe4 <fwp_main_thread+0x2174>  // b.none
    84e4:	52800020 	mov	w0, #0x1                   	// #1
    84e8:	39000280 	strb	w0, [x20]
    84ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    84f0:	910383e1 	add	x1, sp, #0xe0
    84f4:	52800020 	mov	w0, #0x1                   	// #1
    84f8:	a90e5be2 	stp	x2, x22, [sp, #224]
    84fc:	97fff222 	bl	4d84 <fwp_data.part.0.constprop.0>
    8500:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    8504:	91150022 	add	x2, x1, #0x540
    8508:	aa0003f6 	mov	x22, x0
    850c:	f949d841 	ldr	x1, [x2, #5040]
    8510:	f949ec40 	ldr	x0, [x2, #5080]
    8514:	cb0102c1 	sub	x1, x22, x1
    8518:	eb00403f 	cmp	x1, x0, lsl #16
    851c:	54000322 	b.cs	8580 <fwp_main_thread+0x710>  // b.hs, b.nlast
    8520:	d350fc20 	lsr	x0, x1, #16
    8524:	f949fc43 	ldr	x3, [x2, #5112]
    8528:	8b000800 	add	x0, x0, x0, lsl #2
    852c:	d37df002 	lsl	x2, x0, #3
    8530:	8b020060 	add	x0, x3, x2
    8534:	f9401014 	ldr	x20, [x0, #32]
    8538:	b4000254 	cbz	x20, 8580 <fwp_main_thread+0x710>
    853c:	38626862 	ldrb	w2, [x3, x2]
    8540:	7100085f 	cmp	w2, #0x2
    8544:	5400cba0 	b.eq	9eb8 <fwp_main_thread+0x2048>  // b.none
    8548:	7100045f 	cmp	w2, #0x1
    854c:	540001a1 	b.ne	8580 <fwp_main_thread+0x710>  // b.any
    8550:	29430002 	ldp	w2, w0, [x0, #24]
    8554:	92403c21 	and	x1, x1, #0xffff
    8558:	9b027c21 	mul	x1, x1, x2
    855c:	d360fc21 	lsr	x1, x1, #32
    8560:	eb00003f 	cmp	x1, x0
    8564:	540000e2 	b.cs	8580 <fwp_main_thread+0x710>  // b.hs, b.nlast
    8568:	8b010294 	add	x20, x20, x1
    856c:	39400280 	ldrb	w0, [x20]
    8570:	7103fc1f 	cmp	w0, #0xff
    8574:	5400d3e0 	b.eq	9ff0 <fwp_main_thread+0x2180>  // b.none
    8578:	52800020 	mov	w0, #0x1                   	// #1
    857c:	39000280 	strb	w0, [x20]
    8580:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8584:	910343e1 	add	x1, sp, #0xd0
    8588:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    858c:	52800020 	mov	w0, #0x1                   	// #1
    8590:	a90d5be2 	stp	x2, x22, [sp, #208]
    8594:	97fff1fc 	bl	4d84 <fwp_data.part.0.constprop.0>
    8598:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    859c:	91150022 	add	x2, x1, #0x540
    85a0:	aa0003f4 	mov	x20, x0
    85a4:	f949d841 	ldr	x1, [x2, #5040]
    85a8:	f949ec40 	ldr	x0, [x2, #5080]
    85ac:	cb010281 	sub	x1, x20, x1
    85b0:	eb00403f 	cmp	x1, x0, lsl #16
    85b4:	54000322 	b.cs	8618 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    85b8:	d350fc20 	lsr	x0, x1, #16
    85bc:	f949fc43 	ldr	x3, [x2, #5112]
    85c0:	8b000800 	add	x0, x0, x0, lsl #2
    85c4:	d37df002 	lsl	x2, x0, #3
    85c8:	8b020060 	add	x0, x3, x2
    85cc:	f9401016 	ldr	x22, [x0, #32]
    85d0:	b4000256 	cbz	x22, 8618 <fwp_main_thread+0x7a8>
    85d4:	38626862 	ldrb	w2, [x3, x2]
    85d8:	7100085f 	cmp	w2, #0x2
    85dc:	5400c680 	b.eq	9eac <fwp_main_thread+0x203c>  // b.none
    85e0:	7100045f 	cmp	w2, #0x1
    85e4:	540001a1 	b.ne	8618 <fwp_main_thread+0x7a8>  // b.any
    85e8:	29430002 	ldp	w2, w0, [x0, #24]
    85ec:	92403c21 	and	x1, x1, #0xffff
    85f0:	9b027c21 	mul	x1, x1, x2
    85f4:	d360fc21 	lsr	x1, x1, #32
    85f8:	eb00003f 	cmp	x1, x0
    85fc:	540000e2 	b.cs	8618 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    8600:	8b0102d6 	add	x22, x22, x1
    8604:	394002c0 	ldrb	w0, [x22]
    8608:	7103fc1f 	cmp	w0, #0xff
    860c:	5400d0a0 	b.eq	a020 <fwp_main_thread+0x21b0>  // b.none
    8610:	52800020 	mov	w0, #0x1                   	// #1
    8614:	390002c0 	strb	w0, [x22]
    8618:	f9400be0 	ldr	x0, [sp, #16]
    861c:	b400b460 	cbz	x0, 9ca8 <fwp_main_thread+0x1e38>
    8620:	900000c0 	adrp	x0, 20000 <__data_start>
    8624:	91004000 	add	x0, x0, #0x10
    8628:	f9001fe0 	str	x0, [sp, #56]
    862c:	910143e0 	add	x0, sp, #0x50
    8630:	f90013e0 	str	x0, [sp, #32]
    8634:	910163e0 	add	x0, sp, #0x58
    8638:	f90017e0 	str	x0, [sp, #40]
    863c:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    8640:	9115001b 	add	x27, x0, #0x540
    8644:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x830>
    8648:	f9400be1 	ldr	x1, [sp, #16]
    864c:	f90027e1 	str	x1, [sp, #72]
    8650:	fd426008 	ldr	d8, [x0, #1216]
    8654:	f949ef66 	ldr	x6, [x27, #5080]
    8658:	f949db62 	ldr	x2, [x27, #5040]
    865c:	d370bcc6 	lsl	x6, x6, #16
    8660:	cb020285 	sub	x5, x20, x2
    8664:	eb0600bf 	cmp	x5, x6
    8668:	540003a2 	b.cs	86dc <fwp_main_thread+0x86c>  // b.hs, b.nlast
    866c:	d350fca0 	lsr	x0, x5, #16
    8670:	f949ff67 	ldr	x7, [x27, #5112]
    8674:	8b000800 	add	x0, x0, x0, lsl #2
    8678:	d37df001 	lsl	x1, x0, #3
    867c:	8b0100e3 	add	x3, x7, x1
    8680:	f9401060 	ldr	x0, [x3, #32]
    8684:	b40002c0 	cbz	x0, 86dc <fwp_main_thread+0x86c>
    8688:	386168e1 	ldrb	w1, [x7, x1]
    868c:	7100083f 	cmp	w1, #0x2
    8690:	5400b300 	b.eq	9cf0 <fwp_main_thread+0x1e80>  // b.none
    8694:	7100043f 	cmp	w1, #0x1
    8698:	54000221 	b.ne	86dc <fwp_main_thread+0x86c>  // b.any
    869c:	29430c67 	ldp	w7, w3, [x3, #24]
    86a0:	92403ca1 	and	x1, x5, #0xffff
    86a4:	9b077c21 	mul	x1, x1, x7
    86a8:	d360fc21 	lsr	x1, x1, #32
    86ac:	eb03003f 	cmp	x1, x3
    86b0:	54000162 	b.cs	86dc <fwp_main_thread+0x86c>  // b.hs, b.nlast
    86b4:	8b010000 	add	x0, x0, x1
    86b8:	39400001 	ldrb	w1, [x0]
    86bc:	34000101 	cbz	w1, 86dc <fwp_main_thread+0x86c>
    86c0:	7103f43f 	cmp	w1, #0xfd
    86c4:	5400c548 	b.hi	9f6c <fwp_main_thread+0x20fc>  // b.pmore
    86c8:	11000421 	add	w1, w1, #0x1
    86cc:	39000001 	strb	w1, [x0]
    86d0:	f949ef66 	ldr	x6, [x27, #5080]
    86d4:	f949db62 	ldr	x2, [x27, #5040]
    86d8:	d370bcc6 	lsl	x6, x6, #16
    86dc:	f9401fe1 	ldr	x1, [sp, #56]
    86e0:	9100c300 	add	x0, x24, #0x30
    86e4:	cb020023 	sub	x3, x1, x2
    86e8:	b0ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0x15c>
    86ec:	91394021 	add	x1, x1, #0xe50
    86f0:	a90587f5 	stp	x21, x1, [sp, #88]
    86f4:	12800002 	mov	w2, #0xffffffff            	// #-1
    86f8:	f94013e1 	ldr	x1, [sp, #32]
    86fc:	f90037e1 	str	x1, [sp, #104]
    8700:	f94017e1 	ldr	x1, [sp, #40]
    8704:	b90053e2 	str	w2, [sp, #80]
    8708:	f9016001 	str	x1, [x0, #704]
    870c:	eb06007f 	cmp	x3, x6
    8710:	54000742 	b.cs	87f8 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8714:	d350fc60 	lsr	x0, x3, #16
    8718:	f949ff65 	ldr	x5, [x27, #5112]
    871c:	8b000800 	add	x0, x0, x0, lsl #2
    8720:	d37df002 	lsl	x2, x0, #3
    8724:	8b0200a1 	add	x1, x5, x2
    8728:	f9401035 	ldr	x21, [x1, #32]
    872c:	b4000675 	cbz	x21, 87f8 <fwp_main_thread+0x988>
    8730:	386268a0 	ldrb	w0, [x5, x2]
    8734:	7100081f 	cmp	w0, #0x2
    8738:	54009f60 	b.eq	9b24 <fwp_main_thread+0x1cb4>  // b.none
    873c:	7100041f 	cmp	w0, #0x1
    8740:	540005c1 	b.ne	87f8 <fwp_main_thread+0x988>  // b.any
    8744:	29430825 	ldp	w5, w2, [x1, #24]
    8748:	92403c60 	and	x0, x3, #0xffff
    874c:	9b057c00 	mul	x0, x0, x5
    8750:	d360fc00 	lsr	x0, x0, #32
    8754:	eb02001f 	cmp	x0, x2
    8758:	54000282 	b.cs	87a8 <fwp_main_thread+0x938>  // b.hs, b.nlast
    875c:	8b0002a0 	add	x0, x21, x0
    8760:	39400002 	ldrb	w2, [x0]
    8764:	34000222 	cbz	w2, 87a8 <fwp_main_thread+0x938>
    8768:	7103f45f 	cmp	w2, #0xfd
    876c:	5400b6e8 	b.hi	9e48 <fwp_main_thread+0x1fd8>  // b.pmore
    8770:	11000442 	add	w2, w2, #0x1
    8774:	39000002 	strb	w2, [x0]
    8778:	f9401fe1 	ldr	x1, [sp, #56]
    877c:	f949db62 	ldr	x2, [x27, #5040]
    8780:	f949ef60 	ldr	x0, [x27, #5080]
    8784:	cb020023 	sub	x3, x1, x2
    8788:	eb00407f 	cmp	x3, x0, lsl #16
    878c:	54000362 	b.cs	87f8 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8790:	f949ff60 	ldr	x0, [x27, #5112]
    8794:	d350fc61 	lsr	x1, x3, #16
    8798:	8b010821 	add	x1, x1, x1, lsl #2
    879c:	8b010c01 	add	x1, x0, x1, lsl #3
    87a0:	f9401035 	ldr	x21, [x1, #32]
    87a4:	b40002b5 	cbz	x21, 87f8 <fwp_main_thread+0x988>
    87a8:	39400020 	ldrb	w0, [x1]
    87ac:	7100081f 	cmp	w0, #0x2
    87b0:	54009b40 	b.eq	9b18 <fwp_main_thread+0x1ca8>  // b.none
    87b4:	7100041f 	cmp	w0, #0x1
    87b8:	54000201 	b.ne	87f8 <fwp_main_thread+0x988>  // b.any
    87bc:	29430025 	ldp	w5, w0, [x1, #24]
    87c0:	92403c62 	and	x2, x3, #0xffff
    87c4:	9b057c41 	mul	x1, x2, x5
    87c8:	d360fc21 	lsr	x1, x1, #32
    87cc:	eb00003f 	cmp	x1, x0
    87d0:	54000142 	b.cs	87f8 <fwp_main_thread+0x988>  // b.hs, b.nlast
    87d4:	8b0102b5 	add	x21, x21, x1
    87d8:	394002a1 	ldrb	w1, [x21]
    87dc:	340000e1 	cbz	w1, 87f8 <fwp_main_thread+0x988>
    87e0:	7100043f 	cmp	w1, #0x1
    87e4:	54008360 	b.eq	9850 <fwp_main_thread+0x19e0>  // b.none
    87e8:	7103fc3f 	cmp	w1, #0xff
    87ec:	5400b320 	b.eq	9e50 <fwp_main_thread+0x1fe0>  // b.none
    87f0:	51000421 	sub	w1, w1, #0x1
    87f4:	390002a1 	strb	w1, [x21]
    87f8:	b40083d4 	cbz	x20, 9870 <fwp_main_thread+0x1a00>
    87fc:	aa1403e0 	mov	x0, x20
    8800:	d2800001 	mov	x1, #0x0                   	// #0
    8804:	d503201f 	nop
    8808:	f9400800 	ldr	x0, [x0, #16]
    880c:	91000421 	add	x1, x1, #0x1
    8810:	b5ffffc0 	cbnz	x0, 8808 <fwp_main_thread+0x998>
    8814:	aa0103f7 	mov	x23, x1
    8818:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    881c:	eb00003f 	cmp	x1, x0
    8820:	5400c308 	b.hi	a080 <fwp_main_thread+0x2210>  // b.pmore
    8824:	9100c315 	add	x21, x24, #0x30
    8828:	b942faa0 	ldr	w0, [x21, #760]
    882c:	340082a0 	cbz	w0, 9880 <fwp_main_thread+0x1a10>
    8830:	9100c300 	add	x0, x24, #0x30
    8834:	f9402015 	ldr	x21, [x0, #64]
    8838:	f9404c16 	ldr	x22, [x0, #152]
    883c:	eb1502df 	cmp	x22, x21
    8840:	54007cea 	b.ge	97dc <fwp_main_thread+0x196c>  // b.tcont
    8844:	f9401b01 	ldr	x1, [x24, #48]
    8848:	8b1606c0 	add	x0, x22, x22, lsl #1
    884c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8850:	8b000ac0 	add	x0, x22, x0, lsl #2
    8854:	8b000c20 	add	x0, x1, x0, lsl #3
    8858:	b9400401 	ldr	w1, [x0, #4]
    885c:	35000081 	cbnz	w1, 886c <fwp_main_thread+0x9fc>
    8860:	b9400001 	ldr	w1, [x0]
    8864:	6b02003f 	cmp	w1, w2
    8868:	54007ba9 	b.ls	97dc <fwp_main_thread+0x196c>  // b.plast
    886c:	910006d6 	add	x22, x22, #0x1
    8870:	9101a000 	add	x0, x0, #0x68
    8874:	eb1502df 	cmp	x22, x21
    8878:	54ffff01 	b.ne	8858 <fwp_main_thread+0x9e8>  // b.any
    887c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8880:	eb0002bf 	cmp	x21, x0
    8884:	5400bf8c 	b.gt	a074 <fwp_main_thread+0x2204>
    8888:	9100c300 	add	x0, x24, #0x30
    888c:	f9401b1a 	ldr	x26, [x24, #48]
    8890:	f9404800 	ldr	x0, [x0, #144]
    8894:	eb15001f 	cmp	x0, x21
    8898:	54000201 	b.ne	88d8 <fwp_main_thread+0xa68>  // b.any
    889c:	b4009ef5 	cbz	x21, 9c78 <fwp_main_thread+0x1e08>
    88a0:	d37ffab6 	lsl	x22, x21, #1
    88a4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    88a8:	eb0002df 	cmp	x22, x0
    88ac:	9a80d2d6 	csel	x22, x22, x0, le
    88b0:	8b1606c1 	add	x1, x22, x22, lsl #1
    88b4:	8b010ac1 	add	x1, x22, x1, lsl #2
    88b8:	d37df021 	lsl	x1, x1, #3
    88bc:	aa1a03e0 	mov	x0, x26
    88c0:	97ffe7ec 	bl	2870 <realloc@plt>
    88c4:	aa0003fa 	mov	x26, x0
    88c8:	b40037e0 	cbz	x0, 8fc4 <fwp_main_thread+0x1154>
    88cc:	9100c300 	add	x0, x24, #0x30
    88d0:	f9001b1a 	str	x26, [x24, #48]
    88d4:	f9004816 	str	x22, [x0, #144]
    88d8:	9100c302 	add	x2, x24, #0x30
    88dc:	aa1503f6 	mov	x22, x21
    88e0:	910006a1 	add	x1, x21, #0x1
    88e4:	8b1506a0 	add	x0, x21, x21, lsl #1
    88e8:	4f000400 	movi	v0.4s, #0x0
    88ec:	f9002041 	str	x1, [x2, #64]
    88f0:	8b1606c1 	add	x1, x22, x22, lsl #1
    88f4:	8b000aa0 	add	x0, x21, x0, lsl #2
    88f8:	8b010ac1 	add	x1, x22, x1, lsl #2
    88fc:	8b000f40 	add	x0, x26, x0, lsl #3
    8900:	8b010f5c 	add	x28, x26, x1, lsl #3
    8904:	ad000000 	stp	q0, q0, [x0]
    8908:	ad010000 	stp	q0, q0, [x0, #32]
    890c:	ad020000 	stp	q0, q0, [x0, #64]
    8910:	f900301f 	str	xzr, [x0, #96]
    8914:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    8918:	f900339f 	str	xzr, [x28, #96]
    891c:	91282000 	add	x0, x0, #0xa08
    8920:	97ffe83c 	bl	2a10 <getenv@plt>
    8924:	b4007720 	cbz	x0, 9808 <fwp_main_thread+0x1998>
    8928:	39400001 	ldrb	w1, [x0]
    892c:	7100c03f 	cmp	w1, #0x30
    8930:	540076c1 	b.ne	9808 <fwp_main_thread+0x1998>  // b.any
    8934:	39400400 	ldrb	w0, [x0, #1]
    8938:	35007680 	cbnz	w0, 9808 <fwp_main_thread+0x1998>
    893c:	9100c300 	add	x0, x24, #0x30
    8940:	2f000400 	mvni	v0.2s, #0x0
    8944:	b9400395 	ldr	w21, [x28]
    8948:	52800022 	mov	w2, #0x1                   	// #1
    894c:	910006c5 	add	x5, x22, #0x1
    8950:	a900df97 	stp	x23, x23, [x28, #8]
    8954:	0b0202b5 	add	w21, w21, w2
    8958:	f9416001 	ldr	x1, [x0, #704]
    895c:	29000b95 	stp	w21, w2, [x28]
    8960:	f9002b9f 	str	xzr, [x28, #80]
    8964:	f9004c05 	str	x5, [x0, #152]
    8968:	fd002f80 	str	d0, [x28, #88]
    896c:	b400b661 	cbz	x1, a038 <fwp_main_thread+0x21c8>
    8970:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    8974:	91394003 	add	x3, x0, #0xe50
    8978:	14000003 	b	8984 <fwp_main_thread+0xb14>
    897c:	f9400021 	ldr	x1, [x1]
    8980:	b400b5c1 	cbz	x1, a038 <fwp_main_thread+0x21c8>
    8984:	f9400422 	ldr	x2, [x1, #8]
    8988:	eb03005f 	cmp	x2, x3
    898c:	54ffff81 	b.ne	897c <fwp_main_thread+0xb0c>  // b.any
    8990:	f9400820 	ldr	x0, [x1, #16]
    8994:	2a1603e2 	mov	w2, w22
    8998:	b9400001 	ldr	w1, [x0]
    899c:	f9002b80 	str	x0, [x28, #80]
    89a0:	b9005f81 	str	w1, [x28, #92]
    89a4:	37f80081 	tbnz	w1, #31, 89b4 <fwp_main_thread+0xb44>
    89a8:	52800d03 	mov	w3, #0x68                  	// #104
    89ac:	9b236821 	smaddl	x1, w1, w3, x26
    89b0:	b9005836 	str	w22, [x1, #88]
    89b4:	b9000002 	str	w2, [x0]
    89b8:	d3707eb5 	ubfiz	x21, x21, #16, #32
    89bc:	aa0502b5 	orr	x21, x21, x5
    89c0:	aa1403e0 	mov	x0, x20
    89c4:	d2800002 	mov	x2, #0x0                   	// #0
    89c8:	b4007d74 	cbz	x20, 9974 <fwp_main_thread+0x1b04>
    89cc:	d503201f 	nop
    89d0:	f9400800 	ldr	x0, [x0, #16]
    89d4:	91000442 	add	x2, x2, #0x1
    89d8:	b5ffffc0 	cbnz	x0, 89d0 <fwp_main_thread+0xb60>
    89dc:	aa1403e1 	mov	x1, x20
    89e0:	f9400821 	ldr	x1, [x1, #16]
    89e4:	91000400 	add	x0, x0, #0x1
    89e8:	b5ffffc1 	cbnz	x1, 89e0 <fwp_main_thread+0xb70>
    89ec:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    89f0:	eb01001f 	cmp	x0, x1
    89f4:	5400b0a8 	b.hi	a008 <fwp_main_thread+0x2198>  // b.pmore
    89f8:	f100005f 	cmp	x2, #0x0
    89fc:	54007bcd 	b.le	9974 <fwp_main_thread+0x1b04>
    8a00:	eb00005f 	cmp	x2, x0
    8a04:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8a08:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    8a0c:	eb0102df 	cmp	x22, x1
    8a10:	5400afc8 	b.hi	a008 <fwp_main_thread+0x2198>  // b.pmore
    8a14:	d37ffadc 	lsl	x28, x22, #1
    8a18:	52800041 	mov	w1, #0x2                   	// #2
    8a1c:	91000780 	add	x0, x28, #0x1
    8a20:	d37df000 	lsl	x0, x0, #3
    8a24:	97fff093 	bl	4c70 <fwp_heap_alloc>
    8a28:	f900001c 	str	x28, [x0]
    8a2c:	aa0003f7 	mov	x23, x0
    8a30:	aa0003fa 	mov	x26, x0
    8a34:	f949db61 	ldr	x1, [x27, #5040]
    8a38:	f949ef60 	ldr	x0, [x27, #5080]
    8a3c:	cb0102e1 	sub	x1, x23, x1
    8a40:	eb00403f 	cmp	x1, x0, lsl #16
    8a44:	54007ba2 	b.cs	99b8 <fwp_main_thread+0x1b48>  // b.hs, b.nlast
    8a48:	d350fc20 	lsr	x0, x1, #16
    8a4c:	f949ff63 	ldr	x3, [x27, #5112]
    8a50:	8b000800 	add	x0, x0, x0, lsl #2
    8a54:	d37df002 	lsl	x2, x0, #3
    8a58:	8b020060 	add	x0, x3, x2
    8a5c:	f940101c 	ldr	x28, [x0, #32]
    8a60:	b400025c 	cbz	x28, 8aa8 <fwp_main_thread+0xc38>
    8a64:	38626862 	ldrb	w2, [x3, x2]
    8a68:	7100085f 	cmp	w2, #0x2
    8a6c:	54008460 	b.eq	9af8 <fwp_main_thread+0x1c88>  // b.none
    8a70:	7100045f 	cmp	w2, #0x1
    8a74:	540001a1 	b.ne	8aa8 <fwp_main_thread+0xc38>  // b.any
    8a78:	29430002 	ldp	w2, w0, [x0, #24]
    8a7c:	92403c21 	and	x1, x1, #0xffff
    8a80:	9b027c21 	mul	x1, x1, x2
    8a84:	d360fc21 	lsr	x1, x1, #32
    8a88:	eb00003f 	cmp	x1, x0
    8a8c:	540000e2 	b.cs	8aa8 <fwp_main_thread+0xc38>  // b.hs, b.nlast
    8a90:	8b01039c 	add	x28, x28, x1
    8a94:	39400380 	ldrb	w0, [x28]
    8a98:	7103fc1f 	cmp	w0, #0xff
    8a9c:	54008380 	b.eq	9b0c <fwp_main_thread+0x1c9c>  // b.none
    8aa0:	52800020 	mov	w0, #0x1                   	// #1
    8aa4:	39000380 	strb	w0, [x28]
    8aa8:	b4000236 	cbz	x22, 8aec <fwp_main_thread+0xc7c>
    8aac:	d3607ea5 	lsl	x5, x21, #32
    8ab0:	aa1403e1 	mov	x1, x20
    8ab4:	f9400686 	ldr	x6, [x20, #8]
    8ab8:	aa0503e3 	mov	x3, x5
    8abc:	910022e2 	add	x2, x23, #0x8
    8ac0:	d2800000 	mov	x0, #0x0                   	// #0
    8ac4:	14000005 	b	8ad8 <fwp_main_thread+0xc68>
    8ac8:	f9400426 	ldr	x6, [x1, #8]
    8acc:	ab050003 	adds	x3, x0, x5
    8ad0:	91004042 	add	x2, x2, #0x10
    8ad4:	5400ae86 	b.vs	a0a4 <fwp_main_thread+0x2234>
    8ad8:	a9000c46 	stp	x6, x3, [x2]
    8adc:	91000400 	add	x0, x0, #0x1
    8ae0:	f9400821 	ldr	x1, [x1, #16]
    8ae4:	eb16001f 	cmp	x0, x22
    8ae8:	54ffff03 	b.cc	8ac8 <fwp_main_thread+0xc58>  // b.lo, b.ul, b.last
    8aec:	f94002e0 	ldr	x0, [x23]
    8af0:	f100041f 	cmp	x0, #0x1
    8af4:	54007669 	b.ls	99c0 <fwp_main_thread+0x1b50>  // b.plast
    8af8:	d341fc00 	lsr	x0, x0, #1
    8afc:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8b00:	d1000401 	sub	x1, x0, #0x1
    8b04:	eb02003f 	cmp	x1, x2
    8b08:	5400a808 	b.hi	a008 <fwp_main_thread+0x2198>  // b.pmore
    8b0c:	d37ff83c 	lsl	x28, x1, #1
    8b10:	b4007581 	cbz	x1, 99c0 <fwp_main_thread+0x1b50>
    8b14:	d10022e1 	sub	x1, x23, #0x8
    8b18:	910022f9 	add	x25, x23, #0x8
    8b1c:	8b001036 	add	x22, x1, x0, lsl #4
    8b20:	f9400720 	ldr	x0, [x25, #8]
    8b24:	f9400f21 	ldr	x1, [x25, #24]
    8b28:	fd400320 	ldr	d0, [x25]
    8b2c:	fd400b21 	ldr	d1, [x25, #16]
    8b30:	97fff1c0 	bl	5230 <w120>
    8b34:	a9000720 	stp	x0, x1, [x25]
    8b38:	91004339 	add	x25, x25, #0x10
    8b3c:	eb16033f 	cmp	x25, x22
    8b40:	54ffff01 	b.ne	8b20 <fwp_main_thread+0xcb0>  // b.any
    8b44:	f90002fc 	str	x28, [x23]
    8b48:	aa1703e0 	mov	x0, x23
    8b4c:	97fff216 	bl	53a4 <w176.constprop.0>
    8b50:	aa0103f9 	mov	x25, x1
    8b54:	f949db60 	ldr	x0, [x27, #5040]
    8b58:	f949ef62 	ldr	x2, [x27, #5080]
    8b5c:	cb0002e1 	sub	x1, x23, x0
    8b60:	eb02403f 	cmp	x1, x2, lsl #16
    8b64:	540003a2 	b.cs	8bd8 <fwp_main_thread+0xd68>  // b.hs, b.nlast
    8b68:	d350fc20 	lsr	x0, x1, #16
    8b6c:	f949ff65 	ldr	x5, [x27, #5112]
    8b70:	8b000800 	add	x0, x0, x0, lsl #2
    8b74:	d37df000 	lsl	x0, x0, #3
    8b78:	8b0000a2 	add	x2, x5, x0
    8b7c:	f9401056 	ldr	x22, [x2, #32]
    8b80:	b40002d6 	cbz	x22, 8bd8 <fwp_main_thread+0xd68>
    8b84:	386068a0 	ldrb	w0, [x5, x0]
    8b88:	7100081f 	cmp	w0, #0x2
    8b8c:	540071e0 	b.eq	99c8 <fwp_main_thread+0x1b58>  // b.none
    8b90:	7100041f 	cmp	w0, #0x1
    8b94:	54000221 	b.ne	8bd8 <fwp_main_thread+0xd68>  // b.any
    8b98:	29430043 	ldp	w3, w0, [x2, #24]
    8b9c:	92403c21 	and	x1, x1, #0xffff
    8ba0:	9b037c21 	mul	x1, x1, x3
    8ba4:	d360fc21 	lsr	x1, x1, #32
    8ba8:	eb00003f 	cmp	x1, x0
    8bac:	54000162 	b.cs	8bd8 <fwp_main_thread+0xd68>  // b.hs, b.nlast
    8bb0:	8b0102d6 	add	x22, x22, x1
    8bb4:	394002c0 	ldrb	w0, [x22]
    8bb8:	34000100 	cbz	w0, 8bd8 <fwp_main_thread+0xd68>
    8bbc:	7100041f 	cmp	w0, #0x1
    8bc0:	540021a0 	b.eq	8ff4 <fwp_main_thread+0x1184>  // b.none
    8bc4:	7103fc1f 	cmp	w0, #0xff
    8bc8:	540089a0 	b.eq	9cfc <fwp_main_thread+0x1e8c>  // b.none
    8bcc:	51000400 	sub	w0, w0, #0x1
    8bd0:	390002c0 	strb	w0, [x22]
    8bd4:	d503201f 	nop
    8bd8:	93407eb5 	sxtw	x21, w21
    8bdc:	aa1503e0 	mov	x0, x21
    8be0:	97ffeb34 	bl	38b0 <fwp_tape_of>
    8be4:	f9403001 	ldr	x1, [x0, #96]
    8be8:	aa0003e7 	mov	x7, x0
    8bec:	b500a2c1 	cbnz	x1, a044 <fwp_main_thread+0x21d4>
    8bf0:	97ffe8e8 	bl	2f90 <fwp_tape_unlink_scope>
    8bf4:	b90004ff 	str	wzr, [x7, #4]
    8bf8:	b94000e1 	ldr	w1, [x7]
    8bfc:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8c00:	a940a0f7 	ldp	x23, x8, [x7, #8]
    8c04:	a941e8e9 	ldp	x9, x26, [x7, #24]
    8c08:	a9428cfc 	ldp	x28, x3, [x7, #40]
    8c0c:	a943d8e5 	ldp	x5, x22, [x7, #56]
    8c10:	f94024e2 	ldr	x2, [x7, #72]
    8c14:	6b00003f 	cmp	w1, w0
    8c18:	54000108 	b.hi	8c38 <fwp_main_thread+0xdc8>  // b.pmore
    8c1c:	9100c301 	add	x1, x24, #0x30
    8c20:	92403ea0 	and	x0, x21, #0xffff
    8c24:	d1000400 	sub	x0, x0, #0x1
    8c28:	f9404c2a 	ldr	x10, [x1, #152]
    8c2c:	eb0a001f 	cmp	x0, x10
    8c30:	5400004a 	b.ge	8c38 <fwp_main_thread+0xdc8>  // b.tcont
    8c34:	f9004c20 	str	x0, [x1, #152]
    8c38:	4f000400 	movi	v0.4s, #0x0
    8c3c:	9100c300 	add	x0, x24, #0x30
    8c40:	90ffffe1 	adrp	x1, 4000 <fwp_heap_init+0x17c>
    8c44:	91040021 	add	x1, x1, #0x100
    8c48:	f9000cff 	str	xzr, [x7, #24]
    8c4c:	f941600a 	ldr	x10, [x0, #704]
    8c50:	3c8080e0 	stur	q0, [x7, #8]
    8c54:	ad0100e0 	stp	q0, q0, [x7, #32]
    8c58:	a9047cff 	stp	xzr, xzr, [x7, #64]
    8c5c:	a90707ea 	stp	x10, x1, [sp, #112]
    8c60:	f94003e1 	ldr	x1, [sp]
    8c64:	f90043e1 	str	x1, [sp, #128]
    8c68:	f9400fe1 	ldr	x1, [sp, #24]
    8c6c:	a908f3fa 	stp	x26, x28, [sp, #136]
    8c70:	a90997e3 	stp	x3, x5, [sp, #152]
    8c74:	a90aa7f6 	stp	x22, x9, [sp, #168]
    8c78:	f9005fe2 	str	x2, [sp, #184]
    8c7c:	f9016001 	str	x1, [x0, #704]
    8c80:	b7f875b9 	tbnz	x25, #63, 9b34 <fwp_main_thread+0x1cc4>
    8c84:	eb9982bf 	cmp	x21, x25, asr #32
    8c88:	540096c1 	b.ne	9f60 <fwp_main_thread+0x20f0>  // b.any
    8c8c:	92407f21 	and	x1, x25, #0xffffffff
    8c90:	eb39411f 	cmp	x8, w25, uxtw
    8c94:	5400960d 	b.le	9f54 <fwp_main_thread+0x20e4>
    8c98:	eb0102ff 	cmp	x23, x1
    8c9c:	9a81c6f5 	csinc	x21, x23, x1, gt
    8ca0:	eb15005f 	cmp	x2, x21
    8ca4:	540017ca 	b.ge	8f9c <fwp_main_thread+0x112c>  // b.tcont
    8ca8:	f100005f 	cmp	x2, #0x0
    8cac:	9a951042 	csel	x2, x2, x21, ne	// ne = any
    8cb0:	14000005 	b	8cc4 <fwp_main_thread+0xe54>
    8cb4:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8cb8:	eb00005f 	cmp	x2, x0
    8cbc:	d37ff842 	lsl	x2, x2, #1
    8cc0:	9a95d042 	csel	x2, x2, x21, le
    8cc4:	eb15005f 	cmp	x2, x21
    8cc8:	54ffff6b 	b.lt	8cb4 <fwp_main_thread+0xe44>  // b.tstop
    8ccc:	f9001be3 	str	x3, [sp, #48]
    8cd0:	f90023e5 	str	x5, [sp, #64]
    8cd4:	b4007af6 	cbz	x22, 9c30 <fwp_main_thread+0x1dc0>
    8cd8:	aa1603e0 	mov	x0, x22
    8cdc:	d37df041 	lsl	x1, x2, #3
    8ce0:	f90007e2 	str	x2, [sp, #8]
    8ce4:	97ffe6e3 	bl	2870 <realloc@plt>
    8ce8:	f94007e2 	ldr	x2, [sp, #8]
    8cec:	aa0003f6 	mov	x22, x0
    8cf0:	f9401be3 	ldr	x3, [sp, #48]
    8cf4:	f94023e5 	ldr	x5, [sp, #64]
    8cf8:	b4009ad6 	cbz	x22, a050 <fwp_main_thread+0x21e0>
    8cfc:	f90057f6 	str	x22, [sp, #168]
    8d00:	f9005fe2 	str	x2, [sp, #184]
    8d04:	b50013b5 	cbnz	x21, 8f78 <fwp_main_thread+0x1108>
    8d08:	b7f800d9 	tbnz	x25, #63, 8d20 <fwp_main_thread+0xeb0>
    8d0c:	92407f21 	and	x1, x25, #0xffffffff
    8d10:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8d14:	fc617ac0 	ldr	d0, [x22, x1, lsl #3]
    8d18:	1e612800 	fadd	d0, d0, d1
    8d1c:	fc217ac0 	str	d0, [x22, x1, lsl #3]
    8d20:	d10006a1 	sub	x1, x21, #0x1
    8d24:	d10006e7 	sub	x7, x23, #0x1
    8d28:	eb0102ff 	cmp	x23, x1
    8d2c:	540003ac 	b.gt	8da0 <fwp_main_thread+0xf30>
    8d30:	fc617ac0 	ldr	d0, [x22, x1, lsl #3]
    8d34:	1e602008 	fcmp	d0, #0.0
    8d38:	540002e0 	b.eq	8d94 <fwp_main_thread+0xf24>  // b.none
    8d3c:	cb170be0 	neg	x0, x23, lsl #2
    8d40:	cb1703e6 	neg	x6, x23
    8d44:	8b000342 	add	x2, x26, x0
    8d48:	b8617842 	ldr	w2, [x2, x1, lsl #2]
    8d4c:	37f80102 	tbnz	w2, #31, 8d6c <fwp_main_thread+0xefc>
    8d50:	8b060c68 	add	x8, x3, x6, lsl #3
    8d54:	93407c42 	sxtw	x2, w2
    8d58:	fc617902 	ldr	d2, [x8, x1, lsl #3]
    8d5c:	fc627ac1 	ldr	d1, [x22, x2, lsl #3]
    8d60:	1e620802 	fmul	d2, d0, d2
    8d64:	1e622821 	fadd	d1, d1, d2
    8d68:	fc227ac1 	str	d1, [x22, x2, lsl #3]
    8d6c:	8b000380 	add	x0, x28, x0
    8d70:	b8617800 	ldr	w0, [x0, x1, lsl #2]
    8d74:	37f80100 	tbnz	w0, #31, 8d94 <fwp_main_thread+0xf24>
    8d78:	8b060ca6 	add	x6, x5, x6, lsl #3
    8d7c:	93407c00 	sxtw	x0, w0
    8d80:	fc6178c2 	ldr	d2, [x6, x1, lsl #3]
    8d84:	fc607ac1 	ldr	d1, [x22, x0, lsl #3]
    8d88:	1e620800 	fmul	d0, d0, d2
    8d8c:	1e602820 	fadd	d0, d1, d0
    8d90:	fc207ac0 	str	d0, [x22, x0, lsl #3]
    8d94:	d1000421 	sub	x1, x1, #0x1
    8d98:	eb0100ff 	cmp	x7, x1
    8d9c:	54fffca1 	b.ne	8d30 <fwp_main_thread+0xec0>  // b.any
    8da0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8da4:	eb0002ff 	cmp	x23, x0
    8da8:	54009588 	b.hi	a058 <fwp_main_thread+0x21e8>  // b.pmore
    8dac:	910006e0 	add	x0, x23, #0x1
    8db0:	52800041 	mov	w1, #0x2                   	// #2
    8db4:	d37df000 	lsl	x0, x0, #3
    8db8:	97ffefae 	bl	4c70 <fwp_heap_alloc>
    8dbc:	aa0003e2 	mov	x2, x0
    8dc0:	aa0003fa 	mov	x26, x0
    8dc4:	d2800001 	mov	x1, #0x0                   	// #0
    8dc8:	f8008457 	str	x23, [x2], #8
    8dcc:	b40000d7 	cbz	x23, 8de4 <fwp_main_thread+0xf74>
    8dd0:	f8617ac0 	ldr	x0, [x22, x1, lsl #3]
    8dd4:	f8217840 	str	x0, [x2, x1, lsl #3]
    8dd8:	91000421 	add	x1, x1, #0x1
    8ddc:	eb0102ff 	cmp	x23, x1
    8de0:	54ffff81 	b.ne	8dd0 <fwp_main_thread+0xf60>  // b.any
    8de4:	f94003e0 	ldr	x0, [sp]
    8de8:	9100c301 	add	x1, x24, #0x30
    8dec:	f9403bf6 	ldr	x22, [sp, #112]
    8df0:	f9016036 	str	x22, [x1, #704]
    8df4:	97ffecc3 	bl	4100 <fwp_tape_buffers_release>
    8df8:	f949db61 	ldr	x1, [x27, #5040]
    8dfc:	f949ef60 	ldr	x0, [x27, #5080]
    8e00:	cb010341 	sub	x1, x26, x1
    8e04:	eb00403f 	cmp	x1, x0, lsl #16
    8e08:	54000322 	b.cs	8e6c <fwp_main_thread+0xffc>  // b.hs, b.nlast
    8e0c:	d350fc20 	lsr	x0, x1, #16
    8e10:	f949ff63 	ldr	x3, [x27, #5112]
    8e14:	8b000800 	add	x0, x0, x0, lsl #2
    8e18:	d37df002 	lsl	x2, x0, #3
    8e1c:	8b020060 	add	x0, x3, x2
    8e20:	f9401015 	ldr	x21, [x0, #32]
    8e24:	b4000255 	cbz	x21, 8e6c <fwp_main_thread+0xffc>
    8e28:	38626862 	ldrb	w2, [x3, x2]
    8e2c:	7100085f 	cmp	w2, #0x2
    8e30:	54006860 	b.eq	9b3c <fwp_main_thread+0x1ccc>  // b.none
    8e34:	7100045f 	cmp	w2, #0x1
    8e38:	540001a1 	b.ne	8e6c <fwp_main_thread+0xffc>  // b.any
    8e3c:	29430002 	ldp	w2, w0, [x0, #24]
    8e40:	92403c21 	and	x1, x1, #0xffff
    8e44:	9b027c21 	mul	x1, x1, x2
    8e48:	d360fc21 	lsr	x1, x1, #32
    8e4c:	eb00003f 	cmp	x1, x0
    8e50:	540000e2 	b.cs	8e6c <fwp_main_thread+0xffc>  // b.hs, b.nlast
    8e54:	8b0102b5 	add	x21, x21, x1
    8e58:	394002a0 	ldrb	w0, [x21]
    8e5c:	7103fc1f 	cmp	w0, #0xff
    8e60:	54006780 	b.eq	9b50 <fwp_main_thread+0x1ce0>  // b.none
    8e64:	52800020 	mov	w0, #0x1                   	// #1
    8e68:	390002a0 	strb	w0, [x21]
    8e6c:	f94017e0 	ldr	x0, [sp, #40]
    8e70:	eb0002df 	cmp	x22, x0
    8e74:	54008541 	b.ne	9f1c <fwp_main_thread+0x20ac>  // b.any
    8e78:	f94013e0 	ldr	x0, [sp, #32]
    8e7c:	9100c301 	add	x1, x24, #0x30
    8e80:	f9402fe2 	ldr	x2, [sp, #88]
    8e84:	f9016022 	str	x2, [x1, #704]
    8e88:	97fff3f2 	bl	5e50 <fwp_tape_scope_release>
    8e8c:	f9400340 	ldr	x0, [x26]
    8e90:	9240f816 	and	x22, x0, #0x7fffffffffffffff
    8e94:	b7f850a0 	tbnz	x0, #63, 98a8 <fwp_main_thread+0x1a38>
    8e98:	f949db60 	ldr	x0, [x27, #5040]
    8e9c:	f949ef61 	ldr	x1, [x27, #5080]
    8ea0:	cb000340 	sub	x0, x26, x0
    8ea4:	eb01401f 	cmp	x0, x1, lsl #16
    8ea8:	54005002 	b.cs	98a8 <fwp_main_thread+0x1a38>  // b.hs, b.nlast
    8eac:	d350fc01 	lsr	x1, x0, #16
    8eb0:	f949ff65 	ldr	x5, [x27, #5112]
    8eb4:	8b010821 	add	x1, x1, x1, lsl #2
    8eb8:	d37df021 	lsl	x1, x1, #3
    8ebc:	8b0100a3 	add	x3, x5, x1
    8ec0:	f9401062 	ldr	x2, [x3, #32]
    8ec4:	b4004f22 	cbz	x2, 98a8 <fwp_main_thread+0x1a38>
    8ec8:	386168a1 	ldrb	w1, [x5, x1]
    8ecc:	7100083f 	cmp	w1, #0x2
    8ed0:	54004e60 	b.eq	989c <fwp_main_thread+0x1a2c>  // b.none
    8ed4:	7100043f 	cmp	w1, #0x1
    8ed8:	54004e81 	b.ne	98a8 <fwp_main_thread+0x1a38>  // b.any
    8edc:	29430465 	ldp	w5, w1, [x3, #24]
    8ee0:	92403c00 	and	x0, x0, #0xffff
    8ee4:	9b057c00 	mul	x0, x0, x5
    8ee8:	d360fc00 	lsr	x0, x0, #32
    8eec:	eb01001f 	cmp	x0, x1
    8ef0:	54004dc2 	b.cs	98a8 <fwp_main_thread+0x1a38>  // b.hs, b.nlast
    8ef4:	8b000042 	add	x2, x2, x0
    8ef8:	39400040 	ldrb	w0, [x2]
    8efc:	7100041f 	cmp	w0, #0x1
    8f00:	54004d41 	b.ne	98a8 <fwp_main_thread+0x1a38>  // b.any
    8f04:	aa1a03e5 	mov	x5, x26
    8f08:	aa1a03f5 	mov	x21, x26
    8f0c:	d2800000 	mov	x0, #0x0                   	// #0
    8f10:	910022a3 	add	x3, x21, #0x8
    8f14:	91002347 	add	x7, x26, #0x8
    8f18:	d2800001 	mov	x1, #0x0                   	// #0
    8f1c:	b5000156 	cbnz	x22, 8f44 <fwp_main_thread+0x10d4>
    8f20:	14000056 	b	9078 <fwp_main_thread+0x1208>
    8f24:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8f28:	f94000a2 	ldr	x2, [x5]
    8f2c:	1e600900 	fmul	d0, d8, d0
    8f30:	b7f88722 	tbnz	x2, #63, a014 <fwp_main_thread+0x21a4>
    8f34:	91000421 	add	x1, x1, #0x1
    8f38:	fc008460 	str	d0, [x3], #8
    8f3c:	eb0102df 	cmp	x22, x1
    8f40:	540009c0 	b.eq	9078 <fwp_main_thread+0x1208>  // b.none
    8f44:	f9400346 	ldr	x6, [x26]
    8f48:	aa0703e2 	mov	x2, x7
    8f4c:	b6fffec6 	tbz	x6, #63, 8f24 <fwp_main_thread+0x10b4>
    8f50:	f9400b42 	ldr	x2, [x26, #16]
    8f54:	17fffff4 	b	8f24 <fwp_main_thread+0x10b4>
    8f58:	72003c3f 	tst	w1, #0xffff
    8f5c:	54ffa6e1 	b.ne	8438 <fwp_main_thread+0x5c8>  // b.any
    8f60:	394002c0 	ldrb	w0, [x22]
    8f64:	7103fc1f 	cmp	w0, #0xff
    8f68:	54ffa661 	b.ne	8434 <fwp_main_thread+0x5c4>  // b.any
    8f6c:	aa1603e0 	mov	x0, x22
    8f70:	97ffed80 	bl	4570 <fwp_rc_forget_slot>
    8f74:	17fffd30 	b	8434 <fwp_main_thread+0x5c4>
    8f78:	d37df2a2 	lsl	x2, x21, #3
    8f7c:	aa1603e0 	mov	x0, x22
    8f80:	52800001 	mov	w1, #0x0                   	// #0
    8f84:	f90007e3 	str	x3, [sp, #8]
    8f88:	f9001be5 	str	x5, [sp, #48]
    8f8c:	97ffe631 	bl	2850 <memset@plt>
    8f90:	f94007e3 	ldr	x3, [sp, #8]
    8f94:	f9401be5 	ldr	x5, [sp, #48]
    8f98:	17ffff5c 	b	8d08 <fwp_main_thread+0xe98>
    8f9c:	f10002df 	cmp	x22, #0x0
    8fa0:	1a9f17e0 	cset	w0, eq	// eq = none
    8fa4:	f10002bf 	cmp	x21, #0x0
    8fa8:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8fac:	54ffeac0 	b.eq	8d04 <fwp_main_thread+0xe94>  // b.none
    8fb0:	f94003e0 	ldr	x0, [sp]
    8fb4:	9100c318 	add	x24, x24, #0x30
    8fb8:	f9403be1 	ldr	x1, [sp, #112]
    8fbc:	f9016301 	str	x1, [x24, #704]
    8fc0:	97ffec50 	bl	4100 <fwp_tape_buffers_release>
    8fc4:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8fc8:	f947e863 	ldr	x3, [x3, #4048]
    8fcc:	d2800262 	mov	x2, #0x13                  	// #19
    8fd0:	d2800021 	mov	x1, #0x1                   	// #1
    8fd4:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    8fd8:	911f6000 	add	x0, x0, #0x7d8
    8fdc:	f9400063 	ldr	x3, [x3]
    8fe0:	97ffe668 	bl	2980 <fwrite@plt>
    8fe4:	d2800000 	mov	x0, #0x0                   	// #0
    8fe8:	97ffe672 	bl	29b0 <fflush@plt>
    8fec:	52800cc0 	mov	w0, #0x66                  	// #102
    8ff0:	97ffe680 	bl	29f0 <_Exit@plt>
    8ff4:	f9400347 	ldr	x7, [x26]
    8ff8:	aa1a03e0 	mov	x0, x26
    8ffc:	f949ef63 	ldr	x3, [x27, #5080]
    9000:	f949db61 	ldr	x1, [x27, #5040]
    9004:	d370bc63 	lsl	x3, x3, #16
    9008:	cb010342 	sub	x2, x26, x1
    900c:	b7f84ea7 	tbnz	x7, #63, 99e0 <fwp_main_thread+0x1b70>
    9010:	eb03005f 	cmp	x2, x3
    9014:	54ffde22 	b.cs	8bd8 <fwp_main_thread+0xd68>  // b.hs, b.nlast
    9018:	d350fc40 	lsr	x0, x2, #16
    901c:	8b000800 	add	x0, x0, x0, lsl #2
    9020:	d37df000 	lsl	x0, x0, #3
    9024:	8b0000a3 	add	x3, x5, x0
    9028:	f9401061 	ldr	x1, [x3, #32]
    902c:	b4ffdd61 	cbz	x1, 8bd8 <fwp_main_thread+0xd68>
    9030:	386068a0 	ldrb	w0, [x5, x0]
    9034:	7100081f 	cmp	w0, #0x2
    9038:	54005920 	b.eq	9b5c <fwp_main_thread+0x1cec>  // b.none
    903c:	7100041f 	cmp	w0, #0x1
    9040:	54ffdcc1 	b.ne	8bd8 <fwp_main_thread+0xd68>  // b.any
    9044:	92403c40 	and	x0, x2, #0xffff
    9048:	29430865 	ldp	w5, w2, [x3, #24]
    904c:	9b057c00 	mul	x0, x0, x5
    9050:	d360fc00 	lsr	x0, x0, #32
    9054:	eb02001f 	cmp	x0, x2
    9058:	54ffdc02 	b.cs	8bd8 <fwp_main_thread+0xd68>  // b.hs, b.nlast
    905c:	8b000021 	add	x1, x1, x0
    9060:	39400020 	ldrb	w0, [x1]
    9064:	7100041f 	cmp	w0, #0x1
    9068:	54ffdb81 	b.ne	8bd8 <fwp_main_thread+0xd68>  // b.any
    906c:	aa1a03e0 	mov	x0, x26
    9070:	97ffede0 	bl	47f0 <fwp_mem_free>
    9074:	17fffed9 	b	8bd8 <fwp_main_thread+0xd68>
    9078:	f90007e5 	str	x5, [sp, #8]
    907c:	97fff561 	bl	6600 <fwp_drop10>
    9080:	f94007e5 	ldr	x5, [sp, #8]
    9084:	aa1403e1 	mov	x1, x20
    9088:	d2800003 	mov	x3, #0x0                   	// #0
    908c:	b4005e54 	cbz	x20, 9c54 <fwp_main_thread+0x1de4>
    9090:	f9400821 	ldr	x1, [x1, #16]
    9094:	91000463 	add	x3, x3, #0x1
    9098:	b5ffffc1 	cbnz	x1, 9090 <fwp_main_thread+0x1220>
    909c:	f94000a0 	ldr	x0, [x5]
    90a0:	9240f81a 	and	x26, x0, #0x7fffffffffffffff
    90a4:	b7f83620 	tbnz	x0, #63, 9768 <fwp_main_thread+0x18f8>
    90a8:	f949db61 	ldr	x1, [x27, #5040]
    90ac:	f949ef62 	ldr	x2, [x27, #5080]
    90b0:	cb0102a1 	sub	x1, x21, x1
    90b4:	eb02403f 	cmp	x1, x2, lsl #16
    90b8:	54003582 	b.cs	9768 <fwp_main_thread+0x18f8>  // b.hs, b.nlast
    90bc:	d350fc22 	lsr	x2, x1, #16
    90c0:	f949ff68 	ldr	x8, [x27, #5112]
    90c4:	8b020842 	add	x2, x2, x2, lsl #2
    90c8:	d37df042 	lsl	x2, x2, #3
    90cc:	8b020107 	add	x7, x8, x2
    90d0:	f94010e6 	ldr	x6, [x7, #32]
    90d4:	b4003486 	cbz	x6, 9764 <fwp_main_thread+0x18f4>
    90d8:	38626902 	ldrb	w2, [x8, x2]
    90dc:	7100085f 	cmp	w2, #0x2
    90e0:	540033e0 	b.eq	975c <fwp_main_thread+0x18ec>  // b.none
    90e4:	7100045f 	cmp	w2, #0x1
    90e8:	540033e1 	b.ne	9764 <fwp_main_thread+0x18f4>  // b.any
    90ec:	294308e8 	ldp	w8, w2, [x7, #24]
    90f0:	92403c21 	and	x1, x1, #0xffff
    90f4:	9b087c21 	mul	x1, x1, x8
    90f8:	d360fc21 	lsr	x1, x1, #32
    90fc:	eb02003f 	cmp	x1, x2
    9100:	54003322 	b.cs	9764 <fwp_main_thread+0x18f4>  // b.hs, b.nlast
    9104:	8b0100c6 	add	x6, x6, x1
    9108:	394000d6 	ldrb	w22, [x6]
    910c:	710006df 	cmp	w22, #0x1
    9110:	540032a1 	b.ne	9764 <fwp_main_thread+0x18f4>  // b.any
    9114:	b9000bf6 	str	w22, [sp, #8]
    9118:	eb03035f 	cmp	x26, x3
    911c:	9a83935a 	csel	x26, x26, x3, ls	// ls = plast
    9120:	910020bc 	add	x28, x5, #0x8
    9124:	b40068ba 	cbz	x26, 9e38 <fwp_main_thread+0x1fc8>
    9128:	d37df347 	lsl	x7, x26, #3
    912c:	aa1403e2 	mov	x2, x20
    9130:	910022a6 	add	x6, x21, #0x8
    9134:	d2800001 	mov	x1, #0x0                   	// #0
    9138:	1400000a 	b	9160 <fwp_main_thread+0x12f0>
    913c:	fc616861 	ldr	d1, [x3, x1]
    9140:	fd400440 	ldr	d0, [x2, #8]
    9144:	1e613800 	fsub	d0, d0, d1
    9148:	fc216b80 	str	d0, [x28, x1]
    914c:	91002021 	add	x1, x1, #0x8
    9150:	f9400842 	ldr	x2, [x2, #16]
    9154:	eb07003f 	cmp	x1, x7
    9158:	540001a0 	b.eq	918c <fwp_main_thread+0x131c>  // b.none
    915c:	f94000a0 	ldr	x0, [x5]
    9160:	aa0603e3 	mov	x3, x6
    9164:	b6fffec0 	tbz	x0, #63, 913c <fwp_main_thread+0x12cc>
    9168:	f9400aa3 	ldr	x3, [x21, #16]
    916c:	fd400440 	ldr	d0, [x2, #8]
    9170:	fc616861 	ldr	d1, [x3, x1]
    9174:	1e613800 	fsub	d0, d0, d1
    9178:	fc216b80 	str	d0, [x28, x1]
    917c:	91002021 	add	x1, x1, #0x8
    9180:	f9400842 	ldr	x2, [x2, #16]
    9184:	eb07003f 	cmp	x1, x7
    9188:	54fffea1 	b.ne	915c <fwp_main_thread+0x12ec>  // b.any
    918c:	b4006a94 	cbz	x20, 9edc <fwp_main_thread+0x206c>
    9190:	f949ef68 	ldr	x8, [x27, #5080]
    9194:	aa1403e6 	mov	x6, x20
    9198:	f949db69 	ldr	x9, [x27, #5040]
    919c:	d2800016 	mov	x22, #0x0                   	// #0
    91a0:	f949ff67 	ldr	x7, [x27, #5112]
    91a4:	d370bd08 	lsl	x8, x8, #16
    91a8:	14000006 	b	91c0 <fwp_main_thread+0x1350>
    91ac:	f94008c6 	ldr	x6, [x6, #16]
    91b0:	910006d6 	add	x22, x22, #0x1
    91b4:	f10000df 	cmp	x6, #0x0
    91b8:	fa561340 	ccmp	x26, x22, #0x0, ne	// ne = any
    91bc:	54003c89 	b.ls	994c <fwp_main_thread+0x1adc>  // b.plast
    91c0:	cb0900c0 	sub	x0, x6, x9
    91c4:	eb08001f 	cmp	x0, x8
    91c8:	540002c2 	b.cs	9220 <fwp_main_thread+0x13b0>  // b.hs, b.nlast
    91cc:	d350fc01 	lsr	x1, x0, #16
    91d0:	8b010821 	add	x1, x1, x1, lsl #2
    91d4:	d37df021 	lsl	x1, x1, #3
    91d8:	8b0100e5 	add	x5, x7, x1
    91dc:	f94010a2 	ldr	x2, [x5, #32]
    91e0:	b4000202 	cbz	x2, 9220 <fwp_main_thread+0x13b0>
    91e4:	386168e1 	ldrb	w1, [x7, x1]
    91e8:	7100083f 	cmp	w1, #0x2
    91ec:	54000d80 	b.eq	939c <fwp_main_thread+0x152c>  // b.none
    91f0:	7100043f 	cmp	w1, #0x1
    91f4:	54000161 	b.ne	9220 <fwp_main_thread+0x13b0>  // b.any
    91f8:	294304aa 	ldp	w10, w1, [x5, #24]
    91fc:	92403c00 	and	x0, x0, #0xffff
    9200:	9b0a7c00 	mul	x0, x0, x10
    9204:	d360fc00 	lsr	x0, x0, #32
    9208:	eb01001f 	cmp	x0, x1
    920c:	540000a2 	b.cs	9220 <fwp_main_thread+0x13b0>  // b.hs, b.nlast
    9210:	8b000042 	add	x2, x2, x0
    9214:	39400040 	ldrb	w0, [x2]
    9218:	7100041f 	cmp	w0, #0x1
    921c:	54fffc80 	b.eq	91ac <fwp_main_thread+0x133c>  // b.none
    9220:	eb1a02df 	cmp	x22, x26
    9224:	54000c62 	b.cs	93b0 <fwp_main_thread+0x1540>  // b.hs, b.nlast
    9228:	d1002399 	sub	x25, x28, #0x8
    922c:	d2800017 	mov	x23, #0x0                   	// #0
    9230:	14000012 	b	9278 <fwp_main_thread+0x1408>
    9234:	7100045f 	cmp	w2, #0x1
    9238:	540001a1 	b.ne	926c <fwp_main_thread+0x13fc>  // b.any
    923c:	294308c7 	ldp	w7, w2, [x6, #24]
    9240:	92403c21 	and	x1, x1, #0xffff
    9244:	9b077c21 	mul	x1, x1, x7
    9248:	d360fc21 	lsr	x1, x1, #32
    924c:	eb02003f 	cmp	x1, x2
    9250:	540000e2 	b.cs	926c <fwp_main_thread+0x13fc>  // b.hs, b.nlast
    9254:	8b010000 	add	x0, x0, x1
    9258:	39400001 	ldrb	w1, [x0]
    925c:	7103fc3f 	cmp	w1, #0xff
    9260:	54003a40 	b.eq	99a8 <fwp_main_thread+0x1b38>  // b.none
    9264:	52800021 	mov	w1, #0x1                   	// #1
    9268:	39000001 	strb	w1, [x0]
    926c:	d100075a 	sub	x26, x26, #0x1
    9270:	eb1a02df 	cmp	x22, x26
    9274:	54000362 	b.cs	92e0 <fwp_main_thread+0x1470>  // b.hs, b.nlast
    9278:	f87a7b22 	ldr	x2, [x25, x26, lsl #3]
    927c:	aa1303e1 	mov	x1, x19
    9280:	52800020 	mov	w0, #0x1                   	// #1
    9284:	a90f5fe2 	stp	x2, x23, [sp, #240]
    9288:	97ffeebf 	bl	4d84 <fwp_data.part.0.constprop.0>
    928c:	aa0003f7 	mov	x23, x0
    9290:	f949db61 	ldr	x1, [x27, #5040]
    9294:	f949ef60 	ldr	x0, [x27, #5080]
    9298:	cb0102e1 	sub	x1, x23, x1
    929c:	eb00403f 	cmp	x1, x0, lsl #16
    92a0:	54fffe62 	b.cs	926c <fwp_main_thread+0x13fc>  // b.hs, b.nlast
    92a4:	d350fc20 	lsr	x0, x1, #16
    92a8:	f949ff67 	ldr	x7, [x27, #5112]
    92ac:	8b000800 	add	x0, x0, x0, lsl #2
    92b0:	d37df002 	lsl	x2, x0, #3
    92b4:	8b0200e6 	add	x6, x7, x2
    92b8:	f94010c0 	ldr	x0, [x6, #32]
    92bc:	b4fffd80 	cbz	x0, 926c <fwp_main_thread+0x13fc>
    92c0:	386268e2 	ldrb	w2, [x7, x2]
    92c4:	7100085f 	cmp	w2, #0x2
    92c8:	54fffb61 	b.ne	9234 <fwp_main_thread+0x13c4>  // b.any
    92cc:	72003c3f 	tst	w1, #0xffff
    92d0:	54fffc40 	b.eq	9258 <fwp_main_thread+0x13e8>  // b.none
    92d4:	d100075a 	sub	x26, x26, #0x1
    92d8:	eb1a02df 	cmp	x22, x26
    92dc:	54fffce3 	b.cc	9278 <fwp_main_thread+0x1408>  // b.lo, b.ul, b.last
    92e0:	b50006b6 	cbnz	x22, 93b4 <fwp_main_thread+0x1544>
    92e4:	b9400be0 	ldr	w0, [sp, #8]
    92e8:	d2800036 	mov	x22, #0x1                   	// #1
    92ec:	d280001a 	mov	x26, #0x0                   	// #0
    92f0:	7100001f 	cmp	w0, #0x0
    92f4:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    92f8:	b40004fa 	cbz	x26, 9394 <fwp_main_thread+0x1524>
    92fc:	d100075a 	sub	x26, x26, #0x1
    9300:	f87a7b82 	ldr	x2, [x28, x26, lsl #3]
    9304:	aa1303e1 	mov	x1, x19
    9308:	52800020 	mov	w0, #0x1                   	// #1
    930c:	a90f5fe2 	stp	x2, x23, [sp, #240]
    9310:	97ffee9d 	bl	4d84 <fwp_data.part.0.constprop.0>
    9314:	aa0003f7 	mov	x23, x0
    9318:	f949db61 	ldr	x1, [x27, #5040]
    931c:	f949ef60 	ldr	x0, [x27, #5080]
    9320:	cb0102e1 	sub	x1, x23, x1
    9324:	eb00403f 	cmp	x1, x0, lsl #16
    9328:	54000302 	b.cs	9388 <fwp_main_thread+0x1518>  // b.hs, b.nlast
    932c:	d350fc22 	lsr	x2, x1, #16
    9330:	f949ff65 	ldr	x5, [x27, #5112]
    9334:	8b020842 	add	x2, x2, x2, lsl #2
    9338:	d37df042 	lsl	x2, x2, #3
    933c:	8b0200a3 	add	x3, x5, x2
    9340:	f9401079 	ldr	x25, [x3, #32]
    9344:	b4000239 	cbz	x25, 9388 <fwp_main_thread+0x1518>
    9348:	386268a2 	ldrb	w2, [x5, x2]
    934c:	7100085f 	cmp	w2, #0x2
    9350:	54002000 	b.eq	9750 <fwp_main_thread+0x18e0>  // b.none
    9354:	7100045f 	cmp	w2, #0x1
    9358:	54000181 	b.ne	9388 <fwp_main_thread+0x1518>  // b.any
    935c:	29430865 	ldp	w5, w2, [x3, #24]
    9360:	92403c21 	and	x1, x1, #0xffff
    9364:	9b057c21 	mul	x1, x1, x5
    9368:	d360fc21 	lsr	x1, x1, #32
    936c:	eb02003f 	cmp	x1, x2
    9370:	540000c2 	b.cs	9388 <fwp_main_thread+0x1518>  // b.hs, b.nlast
    9374:	8b010339 	add	x25, x25, x1
    9378:	39400321 	ldrb	w1, [x25]
    937c:	7103fc3f 	cmp	w1, #0xff
    9380:	54001e20 	b.eq	9744 <fwp_main_thread+0x18d4>  // b.none
    9384:	39000336 	strb	w22, [x25]
    9388:	d100075a 	sub	x26, x26, #0x1
    938c:	b100075f 	cmn	x26, #0x1
    9390:	54fffb81 	b.ne	9300 <fwp_main_thread+0x1490>  // b.any
    9394:	aa1403fa 	mov	x26, x20
    9398:	14000015 	b	93ec <fwp_main_thread+0x157c>
    939c:	72003c1f 	tst	w0, #0xffff
    93a0:	54fff3a0 	b.eq	9214 <fwp_main_thread+0x13a4>  // b.none
    93a4:	eb1a02df 	cmp	x22, x26
    93a8:	54fff403 	b.cc	9228 <fwp_main_thread+0x13b8>  // b.lo, b.ul, b.last
    93ac:	d503201f 	nop
    93b0:	d2800017 	mov	x23, #0x0                   	// #0
    93b4:	8b160f83 	add	x3, x28, x22, lsl #3
    93b8:	aa1c03e0 	mov	x0, x28
    93bc:	aa1403fa 	mov	x26, x20
    93c0:	f8408401 	ldr	x1, [x0], #8
    93c4:	f9000741 	str	x1, [x26, #8]
    93c8:	aa1a03e1 	mov	x1, x26
    93cc:	f9400b5a 	ldr	x26, [x26, #16]
    93d0:	eb03001f 	cmp	x0, x3
    93d4:	54ffff61 	b.ne	93c0 <fwp_main_thread+0x1550>  // b.any
    93d8:	b9400be0 	ldr	w0, [sp, #8]
    93dc:	f9000837 	str	x23, [x1, #16]
    93e0:	aa1403f7 	mov	x23, x20
    93e4:	7100001f 	cmp	w0, #0x0
    93e8:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    93ec:	aa1c03e0 	mov	x0, x28
    93f0:	97ffed00 	bl	47f0 <fwp_mem_free>
    93f4:	f949ef63 	ldr	x3, [x27, #5080]
    93f8:	f949db61 	ldr	x1, [x27, #5040]
    93fc:	d370bc63 	lsl	x3, x3, #16
    9400:	cb0102a2 	sub	x2, x21, x1
    9404:	eb03005f 	cmp	x2, x3
    9408:	54000402 	b.cs	9488 <fwp_main_thread+0x1618>  // b.hs, b.nlast
    940c:	d350fc40 	lsr	x0, x2, #16
    9410:	f949ff65 	ldr	x5, [x27, #5112]
    9414:	8b000800 	add	x0, x0, x0, lsl #2
    9418:	d37df000 	lsl	x0, x0, #3
    941c:	8b0000a3 	add	x3, x5, x0
    9420:	f9401076 	ldr	x22, [x3, #32]
    9424:	b4001896 	cbz	x22, 9734 <fwp_main_thread+0x18c4>
    9428:	386068a1 	ldrb	w1, [x5, x0]
    942c:	7100083f 	cmp	w1, #0x2
    9430:	54002d20 	b.eq	99d4 <fwp_main_thread+0x1b64>  // b.none
    9434:	7100043f 	cmp	w1, #0x1
    9438:	540017e1 	b.ne	9734 <fwp_main_thread+0x18c4>  // b.any
    943c:	92403c41 	and	x1, x2, #0xffff
    9440:	29430866 	ldp	w6, w2, [x3, #24]
    9444:	9b067c21 	mul	x1, x1, x6
    9448:	d360fc21 	lsr	x1, x1, #32
    944c:	eb02003f 	cmp	x1, x2
    9450:	54001722 	b.cs	9734 <fwp_main_thread+0x18c4>  // b.hs, b.nlast
    9454:	8b0102d6 	add	x22, x22, x1
    9458:	394002c1 	ldrb	w1, [x22]
    945c:	340016c1 	cbz	w1, 9734 <fwp_main_thread+0x18c4>
    9460:	7100043f 	cmp	w1, #0x1
    9464:	54001280 	b.eq	96b4 <fwp_main_thread+0x1844>  // b.none
    9468:	7103fc3f 	cmp	w1, #0xff
    946c:	540047c0 	b.eq	9d64 <fwp_main_thread+0x1ef4>  // b.none
    9470:	51000421 	sub	w1, w1, #0x1
    9474:	390002c1 	strb	w1, [x22]
    9478:	f949ef63 	ldr	x3, [x27, #5080]
    947c:	f949db61 	ldr	x1, [x27, #5040]
    9480:	d370bc63 	lsl	x3, x3, #16
    9484:	d503201f 	nop
    9488:	cb010341 	sub	x1, x26, x1
    948c:	eb03003f 	cmp	x1, x3
    9490:	54000382 	b.cs	9500 <fwp_main_thread+0x1690>  // b.hs, b.nlast
    9494:	d350fc20 	lsr	x0, x1, #16
    9498:	f949ff63 	ldr	x3, [x27, #5112]
    949c:	8b000800 	add	x0, x0, x0, lsl #2
    94a0:	d37df000 	lsl	x0, x0, #3
    94a4:	8b000062 	add	x2, x3, x0
    94a8:	f9401055 	ldr	x21, [x2, #32]
    94ac:	b40002b5 	cbz	x21, 9500 <fwp_main_thread+0x1690>
    94b0:	38606865 	ldrb	w5, [x3, x0]
    94b4:	710008bf 	cmp	w5, #0x2
    94b8:	54002d40 	b.eq	9a60 <fwp_main_thread+0x1bf0>  // b.none
    94bc:	710004bf 	cmp	w5, #0x1
    94c0:	54000201 	b.ne	9500 <fwp_main_thread+0x1690>  // b.any
    94c4:	29430845 	ldp	w5, w2, [x2, #24]
    94c8:	92403c21 	and	x1, x1, #0xffff
    94cc:	9b057c21 	mul	x1, x1, x5
    94d0:	d360fc21 	lsr	x1, x1, #32
    94d4:	eb02003f 	cmp	x1, x2
    94d8:	54000142 	b.cs	9500 <fwp_main_thread+0x1690>  // b.hs, b.nlast
    94dc:	8b0102b5 	add	x21, x21, x1
    94e0:	394002a1 	ldrb	w1, [x21]
    94e4:	340000e1 	cbz	w1, 9500 <fwp_main_thread+0x1690>
    94e8:	7100043f 	cmp	w1, #0x1
    94ec:	540033e0 	b.eq	9b68 <fwp_main_thread+0x1cf8>  // b.none
    94f0:	7103fc3f 	cmp	w1, #0xff
    94f4:	54004680 	b.eq	9dc4 <fwp_main_thread+0x1f54>  // b.none
    94f8:	51000421 	sub	w1, w1, #0x1
    94fc:	390002a1 	strb	w1, [x21]
    9500:	f94003e0 	ldr	x0, [sp]
    9504:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x118a0>
    9508:	910aa042 	add	x2, x2, #0x2a8
    950c:	aa1703e1 	mov	x1, x23
    9510:	91014042 	add	x2, x2, #0x50
    9514:	52800023 	mov	w3, #0x1                   	// #1
    9518:	a908ffff 	stp	xzr, xzr, [sp, #136]
    951c:	f9004fff 	str	xzr, [sp, #152]
    9520:	97fff659 	bl	6e84 <fwp_write>
    9524:	a948ebf6 	ldp	x22, x26, [sp, #136]
    9528:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x830>
    952c:	91080000 	add	x0, x0, #0x200
    9530:	f10002df 	cmp	x22, #0x0
    9534:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9538:	b1002b5f 	cmn	x26, #0xa
    953c:	54005788 	b.hi	a02c <fwp_main_thread+0x21bc>  // b.pmore
    9540:	91002740 	add	x0, x26, #0x9
    9544:	52800021 	mov	w1, #0x1                   	// #1
    9548:	97ffedca 	bl	4c70 <fwp_heap_alloc>
    954c:	aa0003fc 	mov	x28, x0
    9550:	aa0003f5 	mov	x21, x0
    9554:	aa1a03e2 	mov	x2, x26
    9558:	aa1603e1 	mov	x1, x22
    955c:	f800879a 	str	x26, [x28], #8
    9560:	8b1a02ba 	add	x26, x21, x26
    9564:	aa1c03e0 	mov	x0, x28
    9568:	97ffe45a 	bl	26d0 <memcpy@plt>
    956c:	3900235f 	strb	wzr, [x26, #8]
    9570:	f94047e0 	ldr	x0, [sp, #136]
    9574:	97ffe4f3 	bl	2940 <free@plt>
    9578:	f949db62 	ldr	x2, [x27, #5040]
    957c:	f949ef60 	ldr	x0, [x27, #5080]
    9580:	cb0202a2 	sub	x2, x21, x2
    9584:	eb00405f 	cmp	x2, x0, lsl #16
    9588:	54000322 	b.cs	95ec <fwp_main_thread+0x177c>  // b.hs, b.nlast
    958c:	d350fc40 	lsr	x0, x2, #16
    9590:	f949ff63 	ldr	x3, [x27, #5112]
    9594:	8b000800 	add	x0, x0, x0, lsl #2
    9598:	d37df001 	lsl	x1, x0, #3
    959c:	8b010060 	add	x0, x3, x1
    95a0:	f9401016 	ldr	x22, [x0, #32]
    95a4:	b4000256 	cbz	x22, 95ec <fwp_main_thread+0x177c>
    95a8:	38616861 	ldrb	w1, [x3, x1]
    95ac:	7100083f 	cmp	w1, #0x2
    95b0:	54004380 	b.eq	9e20 <fwp_main_thread+0x1fb0>  // b.none
    95b4:	7100043f 	cmp	w1, #0x1
    95b8:	540001a1 	b.ne	95ec <fwp_main_thread+0x177c>  // b.any
    95bc:	29430003 	ldp	w3, w0, [x0, #24]
    95c0:	92403c41 	and	x1, x2, #0xffff
    95c4:	9b037c21 	mul	x1, x1, x3
    95c8:	d360fc21 	lsr	x1, x1, #32
    95cc:	eb00003f 	cmp	x1, x0
    95d0:	540000e2 	b.cs	95ec <fwp_main_thread+0x177c>  // b.hs, b.nlast
    95d4:	8b0102d6 	add	x22, x22, x1
    95d8:	394002c0 	ldrb	w0, [x22]
    95dc:	7103fc1f 	cmp	w0, #0xff
    95e0:	54004a00 	b.eq	9f20 <fwp_main_thread+0x20b0>  // b.none
    95e4:	52800020 	mov	w0, #0x1                   	// #1
    95e8:	390002c0 	strb	w0, [x22]
    95ec:	9100c316 	add	x22, x24, #0x30
    95f0:	aa1703e0 	mov	x0, x23
    95f4:	97fff08f 	bl	5830 <fwp_drop0>
    95f8:	f94002a2 	ldr	x2, [x21]
    95fc:	d2800021 	mov	x1, #0x1                   	// #1
    9600:	f94006c3 	ldr	x3, [x22, #8]
    9604:	aa1c03e0 	mov	x0, x28
    9608:	97ffe4de 	bl	2980 <fwrite@plt>
    960c:	f94006c1 	ldr	x1, [x22, #8]
    9610:	52800140 	mov	w0, #0xa                   	// #10
    9614:	97ffe463 	bl	27a0 <fputc@plt>
    9618:	f949db62 	ldr	x2, [x27, #5040]
    961c:	f949ef60 	ldr	x0, [x27, #5080]
    9620:	cb0202a2 	sub	x2, x21, x2
    9624:	eb00405f 	cmp	x2, x0, lsl #16
    9628:	54000382 	b.cs	9698 <fwp_main_thread+0x1828>  // b.hs, b.nlast
    962c:	d350fc40 	lsr	x0, x2, #16
    9630:	f949ff63 	ldr	x3, [x27, #5112]
    9634:	8b000800 	add	x0, x0, x0, lsl #2
    9638:	d37df001 	lsl	x1, x0, #3
    963c:	8b010060 	add	x0, x3, x1
    9640:	f9401016 	ldr	x22, [x0, #32]
    9644:	b40002b6 	cbz	x22, 9698 <fwp_main_thread+0x1828>
    9648:	38616861 	ldrb	w1, [x3, x1]
    964c:	7100083f 	cmp	w1, #0x2
    9650:	54003ee0 	b.eq	9e2c <fwp_main_thread+0x1fbc>  // b.none
    9654:	7100043f 	cmp	w1, #0x1
    9658:	54000201 	b.ne	9698 <fwp_main_thread+0x1828>  // b.any
    965c:	29430003 	ldp	w3, w0, [x0, #24]
    9660:	92403c41 	and	x1, x2, #0xffff
    9664:	9b037c21 	mul	x1, x1, x3
    9668:	d360fc21 	lsr	x1, x1, #32
    966c:	eb00003f 	cmp	x1, x0
    9670:	54000142 	b.cs	9698 <fwp_main_thread+0x1828>  // b.hs, b.nlast
    9674:	8b0102d6 	add	x22, x22, x1
    9678:	394002c0 	ldrb	w0, [x22]
    967c:	340000e0 	cbz	w0, 9698 <fwp_main_thread+0x1828>
    9680:	7100041f 	cmp	w0, #0x1
    9684:	54003060 	b.eq	9c90 <fwp_main_thread+0x1e20>  // b.none
    9688:	7103fc1f 	cmp	w0, #0xff
    968c:	540047e0 	b.eq	9f88 <fwp_main_thread+0x2118>  // b.none
    9690:	51000400 	sub	w0, w0, #0x1
    9694:	390002c0 	strb	w0, [x22]
    9698:	f94027e0 	ldr	x0, [sp, #72]
    969c:	f9400800 	ldr	x0, [x0, #16]
    96a0:	f90027e0 	str	x0, [sp, #72]
    96a4:	b4003020 	cbz	x0, 9ca8 <fwp_main_thread+0x1e38>
    96a8:	9100c300 	add	x0, x24, #0x30
    96ac:	f9416015 	ldr	x21, [x0, #704]
    96b0:	17fffbe9 	b	8654 <fwp_main_thread+0x7e4>
    96b4:	f94002a2 	ldr	x2, [x21]
    96b8:	aa1503e0 	mov	x0, x21
    96bc:	f949ef63 	ldr	x3, [x27, #5080]
    96c0:	f949db61 	ldr	x1, [x27, #5040]
    96c4:	d370bc63 	lsl	x3, x3, #16
    96c8:	cb0102a8 	sub	x8, x21, x1
    96cc:	b7f81d02 	tbnz	x2, #63, 9a6c <fwp_main_thread+0x1bfc>
    96d0:	eb03011f 	cmp	x8, x3
    96d4:	54ffeda2 	b.cs	9488 <fwp_main_thread+0x1618>  // b.hs, b.nlast
    96d8:	d350fd02 	lsr	x2, x8, #16
    96dc:	8b020842 	add	x2, x2, x2, lsl #2
    96e0:	d37df042 	lsl	x2, x2, #3
    96e4:	8b0200a7 	add	x7, x5, x2
    96e8:	f94010e6 	ldr	x6, [x7, #32]
    96ec:	b4ffece6 	cbz	x6, 9488 <fwp_main_thread+0x1618>
    96f0:	386268a2 	ldrb	w2, [x5, x2]
    96f4:	7100085f 	cmp	w2, #0x2
    96f8:	54002840 	b.eq	9c00 <fwp_main_thread+0x1d90>  // b.none
    96fc:	7100045f 	cmp	w2, #0x1
    9700:	54ffec41 	b.ne	9488 <fwp_main_thread+0x1618>  // b.any
    9704:	294308e5 	ldp	w5, w2, [x7, #24]
    9708:	92403d00 	and	x0, x8, #0xffff
    970c:	9b057c00 	mul	x0, x0, x5
    9710:	d360fc00 	lsr	x0, x0, #32
    9714:	eb02001f 	cmp	x0, x2
    9718:	54ffeb82 	b.cs	9488 <fwp_main_thread+0x1618>  // b.hs, b.nlast
    971c:	8b0000c6 	add	x6, x6, x0
    9720:	394000c0 	ldrb	w0, [x6]
    9724:	7100041f 	cmp	w0, #0x1
    9728:	54ffeb01 	b.ne	9488 <fwp_main_thread+0x1618>  // b.any
    972c:	aa1503e0 	mov	x0, x21
    9730:	97ffec30 	bl	47f0 <fwp_mem_free>
    9734:	f949ef63 	ldr	x3, [x27, #5080]
    9738:	f949db61 	ldr	x1, [x27, #5040]
    973c:	d370bc63 	lsl	x3, x3, #16
    9740:	17ffff52 	b	9488 <fwp_main_thread+0x1618>
    9744:	aa1903e0 	mov	x0, x25
    9748:	97ffeb8a 	bl	4570 <fwp_rc_forget_slot>
    974c:	17ffff0e 	b	9384 <fwp_main_thread+0x1514>
    9750:	72003c3f 	tst	w1, #0xffff
    9754:	54ffe1a1 	b.ne	9388 <fwp_main_thread+0x1518>  // b.any
    9758:	17ffff08 	b	9378 <fwp_main_thread+0x1508>
    975c:	72003c3f 	tst	w1, #0xffff
    9760:	54ffcd40 	b.eq	9108 <fwp_main_thread+0x1298>  // b.none
    9764:	b4000fb4 	cbz	x20, 9958 <fwp_main_thread+0x1ae8>
    9768:	aa1403f6 	mov	x22, x20
    976c:	d2800017 	mov	x23, #0x0                   	// #0
    9770:	f9400ad6 	ldr	x22, [x22, #16]
    9774:	aa1703e0 	mov	x0, x23
    9778:	910006f7 	add	x23, x23, #0x1
    977c:	b5ffffb6 	cbnz	x22, 9770 <fwp_main_thread+0x1900>
    9780:	f90007e5 	str	x5, [sp, #8]
    9784:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9788:	eb0102ff 	cmp	x23, x1
    978c:	540043e8 	b.hi	a008 <fwp_main_thread+0x2198>  // b.pmore
    9790:	91000800 	add	x0, x0, #0x2
    9794:	52800041 	mov	w1, #0x2                   	// #2
    9798:	d37df000 	lsl	x0, x0, #3
    979c:	97ffed35 	bl	4c70 <fwp_heap_alloc>
    97a0:	f94007e5 	ldr	x5, [sp, #8]
    97a4:	eb1a02ff 	cmp	x23, x26
    97a8:	9a9a92fa 	csel	x26, x23, x26, ls	// ls = plast
    97ac:	aa0003fc 	mov	x28, x0
    97b0:	aa1403e1 	mov	x1, x20
    97b4:	d503201f 	nop
    97b8:	f9400420 	ldr	x0, [x1, #8]
    97bc:	f8367b80 	str	x0, [x28, x22, lsl #3]
    97c0:	910006d6 	add	x22, x22, #0x1
    97c4:	f9400821 	ldr	x1, [x1, #16]
    97c8:	b5ffff81 	cbnz	x1, 97b8 <fwp_main_thread+0x1948>
    97cc:	b4000cfa 	cbz	x26, 9968 <fwp_main_thread+0x1af8>
    97d0:	f94000a0 	ldr	x0, [x5]
    97d4:	b9000bff 	str	wzr, [sp, #8]
    97d8:	17fffe54 	b	9128 <fwp_main_thread+0x12b8>
    97dc:	eb1602bf 	cmp	x21, x22
    97e0:	54ff84e0 	b.eq	887c <fwp_main_thread+0xa0c>  // b.none
    97e4:	f9401b1a 	ldr	x26, [x24, #48]
    97e8:	8b1606c1 	add	x1, x22, x22, lsl #1
    97ec:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    97f0:	91282000 	add	x0, x0, #0xa08
    97f4:	8b010ac1 	add	x1, x22, x1, lsl #2
    97f8:	8b010f5c 	add	x28, x26, x1, lsl #3
    97fc:	f900339f 	str	xzr, [x28, #96]
    9800:	97ffe484 	bl	2a10 <getenv@plt>
    9804:	b5ff8920 	cbnz	x0, 8928 <fwp_main_thread+0xab8>
    9808:	9100c300 	add	x0, x24, #0x30
    980c:	f9404001 	ldr	x1, [x0, #128]
    9810:	b4ff8961 	cbz	x1, 893c <fwp_main_thread+0xacc>
    9814:	3cc48002 	ldur	q2, [x0, #72]
    9818:	91012001 	add	x1, x0, #0x48
    981c:	3cc58001 	ldur	q1, [x0, #88]
    9820:	f900401f 	str	xzr, [x0, #128]
    9824:	4f000400 	movi	v0.4s, #0x0
    9828:	ad010782 	stp	q2, q1, [x28, #32]
    982c:	a9468002 	ldp	x2, x0, [x0, #104]
    9830:	f9000f80 	str	x0, [x28, #24]
    9834:	f9401820 	ldr	x0, [x1, #48]
    9838:	f9002382 	str	x2, [x28, #64]
    983c:	f9002780 	str	x0, [x28, #72]
    9840:	ad000020 	stp	q0, q0, [x1]
    9844:	3d800820 	str	q0, [x1, #32]
    9848:	f900183f 	str	xzr, [x1, #48]
    984c:	17fffc3c 	b	893c <fwp_main_thread+0xacc>
    9850:	d53bd040 	mrs	x0, tpidr_el0
    9854:	91400000 	add	x0, x0, #0x0, lsl #12
    9858:	91004000 	add	x0, x0, #0x10
    985c:	f9400000 	ldr	x0, [x0]
    9860:	b4001460 	cbz	x0, 9aec <fwp_main_thread+0x1c7c>
    9864:	f9401fe1 	ldr	x1, [sp, #56]
    9868:	97ffe75f 	bl	35e4 <fwp_closure_drop_push>
    986c:	b5ff7c94 	cbnz	x20, 87fc <fwp_main_thread+0x98c>
    9870:	9100c315 	add	x21, x24, #0x30
    9874:	d2800017 	mov	x23, #0x0                   	// #0
    9878:	b942faa0 	ldr	w0, [x21, #760]
    987c:	35ff7da0 	cbnz	w0, 8830 <fwp_main_thread+0x9c0>
    9880:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    9884:	91354000 	add	x0, x0, #0xd50
    9888:	940003c6 	bl	a7a0 <atexit>
    988c:	35ffb9c0 	cbnz	w0, 8fc4 <fwp_main_thread+0x1154>
    9890:	52800020 	mov	w0, #0x1                   	// #1
    9894:	b902faa0 	str	w0, [x21, #760]
    9898:	17fffbe6 	b	8830 <fwp_main_thread+0x9c0>
    989c:	72003c1f 	tst	w0, #0xffff
    98a0:	54ffb2c0 	b.eq	8ef8 <fwp_main_thread+0x1088>  // b.none
    98a4:	d503201f 	nop
    98a8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    98ac:	eb0002df 	cmp	x22, x0
    98b0:	54003d48 	b.hi	a058 <fwp_main_thread+0x21e8>  // b.pmore
    98b4:	910006c0 	add	x0, x22, #0x1
    98b8:	52800021 	mov	w1, #0x1                   	// #1
    98bc:	d37df000 	lsl	x0, x0, #3
    98c0:	97ffecec 	bl	4c70 <fwp_heap_alloc>
    98c4:	f9000016 	str	x22, [x0]
    98c8:	aa0003e5 	mov	x5, x0
    98cc:	aa0003f5 	mov	x21, x0
    98d0:	f949db61 	ldr	x1, [x27, #5040]
    98d4:	f949ef60 	ldr	x0, [x27, #5080]
    98d8:	cb0100a1 	sub	x1, x5, x1
    98dc:	eb00403f 	cmp	x1, x0, lsl #16
    98e0:	54000322 	b.cs	9944 <fwp_main_thread+0x1ad4>  // b.hs, b.nlast
    98e4:	d350fc20 	lsr	x0, x1, #16
    98e8:	f949ff63 	ldr	x3, [x27, #5112]
    98ec:	8b000800 	add	x0, x0, x0, lsl #2
    98f0:	d37df002 	lsl	x2, x0, #3
    98f4:	8b020060 	add	x0, x3, x2
    98f8:	f9401017 	ldr	x23, [x0, #32]
    98fc:	b4000257 	cbz	x23, 9944 <fwp_main_thread+0x1ad4>
    9900:	38626862 	ldrb	w2, [x3, x2]
    9904:	7100085f 	cmp	w2, #0x2
    9908:	54001820 	b.eq	9c0c <fwp_main_thread+0x1d9c>  // b.none
    990c:	7100045f 	cmp	w2, #0x1
    9910:	540001a1 	b.ne	9944 <fwp_main_thread+0x1ad4>  // b.any
    9914:	29430002 	ldp	w2, w0, [x0, #24]
    9918:	92403c21 	and	x1, x1, #0xffff
    991c:	9b027c21 	mul	x1, x1, x2
    9920:	d360fc21 	lsr	x1, x1, #32
    9924:	eb00003f 	cmp	x1, x0
    9928:	540000e2 	b.cs	9944 <fwp_main_thread+0x1ad4>  // b.hs, b.nlast
    992c:	8b0102f7 	add	x23, x23, x1
    9930:	394002e0 	ldrb	w0, [x23]
    9934:	7103fc1f 	cmp	w0, #0xff
    9938:	54001720 	b.eq	9c1c <fwp_main_thread+0x1dac>  // b.none
    993c:	52800020 	mov	w0, #0x1                   	// #1
    9940:	390002e0 	strb	w0, [x23]
    9944:	aa1a03e0 	mov	x0, x26
    9948:	17fffd72 	b	8f10 <fwp_main_thread+0x10a0>
    994c:	eb16035f 	cmp	x26, x22
    9950:	54ffc6c8 	b.hi	9228 <fwp_main_thread+0x13b8>  // b.pmore
    9954:	17fffe97 	b	93b0 <fwp_main_thread+0x1540>
    9958:	52800041 	mov	w1, #0x2                   	// #2
    995c:	d2800100 	mov	x0, #0x8                   	// #8
    9960:	97ffecc4 	bl	4c70 <fwp_heap_alloc>
    9964:	aa0003fc 	mov	x28, x0
    9968:	aa1403fa 	mov	x26, x20
    996c:	d2800017 	mov	x23, #0x0                   	// #0
    9970:	17fffe9f 	b	93ec <fwp_main_thread+0x157c>
    9974:	52800041 	mov	w1, #0x2                   	// #2
    9978:	d2800100 	mov	x0, #0x8                   	// #8
    997c:	97ffecbd 	bl	4c70 <fwp_heap_alloc>
    9980:	f900001f 	str	xzr, [x0]
    9984:	aa0003f7 	mov	x23, x0
    9988:	aa0003fa 	mov	x26, x0
    998c:	f949db61 	ldr	x1, [x27, #5040]
    9990:	f949ef60 	ldr	x0, [x27, #5080]
    9994:	cb0102e1 	sub	x1, x23, x1
    9998:	eb00403f 	cmp	x1, x0, lsl #16
    999c:	54000122 	b.cs	99c0 <fwp_main_thread+0x1b50>  // b.hs, b.nlast
    99a0:	d2800016 	mov	x22, #0x0                   	// #0
    99a4:	17fffc29 	b	8a48 <fwp_main_thread+0xbd8>
    99a8:	f9001be0 	str	x0, [sp, #48]
    99ac:	97ffeaf1 	bl	4570 <fwp_rc_forget_slot>
    99b0:	f9401be0 	ldr	x0, [sp, #48]
    99b4:	17fffe2c 	b	9264 <fwp_main_thread+0x13f4>
    99b8:	b5ff87b6 	cbnz	x22, 8aac <fwp_main_thread+0xc3c>
    99bc:	d503201f 	nop
    99c0:	d280001c 	mov	x28, #0x0                   	// #0
    99c4:	17fffc60 	b	8b44 <fwp_main_thread+0xcd4>
    99c8:	72003c3f 	tst	w1, #0xffff
    99cc:	54ff9061 	b.ne	8bd8 <fwp_main_thread+0xd68>  // b.any
    99d0:	17fffc79 	b	8bb4 <fwp_main_thread+0xd44>
    99d4:	72003c5f 	tst	w2, #0xffff
    99d8:	54ffeae1 	b.ne	9734 <fwp_main_thread+0x18c4>  // b.any
    99dc:	17fffe9f 	b	9458 <fwp_main_thread+0x15e8>
    99e0:	f940075a 	ldr	x26, [x26, #8]
    99e4:	eb03005f 	cmp	x2, x3
    99e8:	54000342 	b.cs	9a50 <fwp_main_thread+0x1be0>  // b.hs, b.nlast
    99ec:	d350fc47 	lsr	x7, x2, #16
    99f0:	8b0708e7 	add	x7, x7, x7, lsl #2
    99f4:	d37df0e7 	lsl	x7, x7, #3
    99f8:	8b0700a9 	add	x9, x5, x7
    99fc:	f9401128 	ldr	x8, [x9, #32]
    9a00:	b4000288 	cbz	x8, 9a50 <fwp_main_thread+0x1be0>
    9a04:	386768a5 	ldrb	w5, [x5, x7]
    9a08:	710008bf 	cmp	w5, #0x2
    9a0c:	54001660 	b.eq	9cd8 <fwp_main_thread+0x1e68>  // b.none
    9a10:	710004bf 	cmp	w5, #0x1
    9a14:	540001e1 	b.ne	9a50 <fwp_main_thread+0x1be0>  // b.any
    9a18:	29431527 	ldp	w7, w5, [x9, #24]
    9a1c:	92403c42 	and	x2, x2, #0xffff
    9a20:	9b077c42 	mul	x2, x2, x7
    9a24:	d360fc42 	lsr	x2, x2, #32
    9a28:	eb05005f 	cmp	x2, x5
    9a2c:	54000122 	b.cs	9a50 <fwp_main_thread+0x1be0>  // b.hs, b.nlast
    9a30:	8b020108 	add	x8, x8, x2
    9a34:	39400102 	ldrb	w2, [x8]
    9a38:	7100045f 	cmp	w2, #0x1
    9a3c:	540000a1 	b.ne	9a50 <fwp_main_thread+0x1be0>  // b.any
    9a40:	97ffeb6c 	bl	47f0 <fwp_mem_free>
    9a44:	f949ef63 	ldr	x3, [x27, #5080]
    9a48:	f949db61 	ldr	x1, [x27, #5040]
    9a4c:	d370bc63 	lsl	x3, x3, #16
    9a50:	cb010341 	sub	x1, x26, x1
    9a54:	eb01007f 	cmp	x3, x1
    9a58:	54ff8888 	b.hi	8b68 <fwp_main_thread+0xcf8>  // b.pmore
    9a5c:	17fffc5f 	b	8bd8 <fwp_main_thread+0xd68>
    9a60:	72003c3f 	tst	w1, #0xffff
    9a64:	54ffd4e1 	b.ne	9500 <fwp_main_thread+0x1690>  // b.any
    9a68:	17fffe9e 	b	94e0 <fwp_main_thread+0x1670>
    9a6c:	f94006b5 	ldr	x21, [x21, #8]
    9a70:	eb03011f 	cmp	x8, x3
    9a74:	54000342 	b.cs	9adc <fwp_main_thread+0x1c6c>  // b.hs, b.nlast
    9a78:	d350fd02 	lsr	x2, x8, #16
    9a7c:	8b020842 	add	x2, x2, x2, lsl #2
    9a80:	d37df042 	lsl	x2, x2, #3
    9a84:	8b0200a7 	add	x7, x5, x2
    9a88:	f94010e6 	ldr	x6, [x7, #32]
    9a8c:	b4000286 	cbz	x6, 9adc <fwp_main_thread+0x1c6c>
    9a90:	386268a2 	ldrb	w2, [x5, x2]
    9a94:	7100085f 	cmp	w2, #0x2
    9a98:	54000f60 	b.eq	9c84 <fwp_main_thread+0x1e14>  // b.none
    9a9c:	7100045f 	cmp	w2, #0x1
    9aa0:	540001e1 	b.ne	9adc <fwp_main_thread+0x1c6c>  // b.any
    9aa4:	294314e9 	ldp	w9, w5, [x7, #24]
    9aa8:	92403d02 	and	x2, x8, #0xffff
    9aac:	9b097c42 	mul	x2, x2, x9
    9ab0:	d360fc42 	lsr	x2, x2, #32
    9ab4:	eb05005f 	cmp	x2, x5
    9ab8:	54000122 	b.cs	9adc <fwp_main_thread+0x1c6c>  // b.hs, b.nlast
    9abc:	8b0200c6 	add	x6, x6, x2
    9ac0:	394000c2 	ldrb	w2, [x6]
    9ac4:	7100045f 	cmp	w2, #0x1
    9ac8:	540000a1 	b.ne	9adc <fwp_main_thread+0x1c6c>  // b.any
    9acc:	97ffeb49 	bl	47f0 <fwp_mem_free>
    9ad0:	f949ef63 	ldr	x3, [x27, #5080]
    9ad4:	f949db61 	ldr	x1, [x27, #5040]
    9ad8:	d370bc63 	lsl	x3, x3, #16
    9adc:	cb0102a2 	sub	x2, x21, x1
    9ae0:	eb03005f 	cmp	x2, x3
    9ae4:	54ffc943 	b.cc	940c <fwp_main_thread+0x159c>  // b.lo, b.ul, b.last
    9ae8:	17fffe68 	b	9488 <fwp_main_thread+0x1618>
    9aec:	f9401fe0 	ldr	x0, [sp, #56]
    9af0:	97ffe72c 	bl	37a0 <fwp_closure_drop.part.0>
    9af4:	17fffb41 	b	87f8 <fwp_main_thread+0x988>
    9af8:	72003c3f 	tst	w1, #0xffff
    9afc:	54ff7d61 	b.ne	8aa8 <fwp_main_thread+0xc38>  // b.any
    9b00:	39400380 	ldrb	w0, [x28]
    9b04:	7103fc1f 	cmp	w0, #0xff
    9b08:	54ff7cc1 	b.ne	8aa0 <fwp_main_thread+0xc30>  // b.any
    9b0c:	aa1c03e0 	mov	x0, x28
    9b10:	97ffea98 	bl	4570 <fwp_rc_forget_slot>
    9b14:	17fffbe3 	b	8aa0 <fwp_main_thread+0xc30>
    9b18:	72003c7f 	tst	w3, #0xffff
    9b1c:	54ff66e1 	b.ne	87f8 <fwp_main_thread+0x988>  // b.any
    9b20:	17fffb2e 	b	87d8 <fwp_main_thread+0x968>
    9b24:	72003c7f 	tst	w3, #0xffff
    9b28:	54ff6401 	b.ne	87a8 <fwp_main_thread+0x938>  // b.any
    9b2c:	aa1503e0 	mov	x0, x21
    9b30:	17fffb0c 	b	8760 <fwp_main_thread+0x8f0>
    9b34:	aa1703f5 	mov	x21, x23
    9b38:	17fffc5a 	b	8ca0 <fwp_main_thread+0xe30>
    9b3c:	72003c3f 	tst	w1, #0xffff
    9b40:	54ff9961 	b.ne	8e6c <fwp_main_thread+0xffc>  // b.any
    9b44:	394002a0 	ldrb	w0, [x21]
    9b48:	7103fc1f 	cmp	w0, #0xff
    9b4c:	54ff98c1 	b.ne	8e64 <fwp_main_thread+0xff4>  // b.any
    9b50:	aa1503e0 	mov	x0, x21
    9b54:	97ffea87 	bl	4570 <fwp_rc_forget_slot>
    9b58:	17fffcc3 	b	8e64 <fwp_main_thread+0xff4>
    9b5c:	72003c5f 	tst	w2, #0xffff
    9b60:	54ff83c1 	b.ne	8bd8 <fwp_main_thread+0xd68>  // b.any
    9b64:	17fffd3f 	b	9060 <fwp_main_thread+0x11f0>
    9b68:	f949ef65 	ldr	x5, [x27, #5080]
    9b6c:	f949db61 	ldr	x1, [x27, #5040]
    9b70:	d370bca5 	lsl	x5, x5, #16
    9b74:	cb010340 	sub	x0, x26, x1
    9b78:	f9400b55 	ldr	x21, [x26, #16]
    9b7c:	eb05001f 	cmp	x0, x5
    9b80:	54000362 	b.cs	9bec <fwp_main_thread+0x1d7c>  // b.hs, b.nlast
    9b84:	d350fc02 	lsr	x2, x0, #16
    9b88:	8b020842 	add	x2, x2, x2, lsl #2
    9b8c:	d37df042 	lsl	x2, x2, #3
    9b90:	8b020067 	add	x7, x3, x2
    9b94:	f94010e6 	ldr	x6, [x7, #32]
    9b98:	b40002a6 	cbz	x6, 9bec <fwp_main_thread+0x1d7c>
    9b9c:	38626862 	ldrb	w2, [x3, x2]
    9ba0:	7100085f 	cmp	w2, #0x2
    9ba4:	54000a00 	b.eq	9ce4 <fwp_main_thread+0x1e74>  // b.none
    9ba8:	7100045f 	cmp	w2, #0x1
    9bac:	54000201 	b.ne	9bec <fwp_main_thread+0x1d7c>  // b.any
    9bb0:	294308e3 	ldp	w3, w2, [x7, #24]
    9bb4:	92403c00 	and	x0, x0, #0xffff
    9bb8:	9b037c00 	mul	x0, x0, x3
    9bbc:	d360fc00 	lsr	x0, x0, #32
    9bc0:	eb02001f 	cmp	x0, x2
    9bc4:	54000142 	b.cs	9bec <fwp_main_thread+0x1d7c>  // b.hs, b.nlast
    9bc8:	8b0000c6 	add	x6, x6, x0
    9bcc:	394000c0 	ldrb	w0, [x6]
    9bd0:	7100041f 	cmp	w0, #0x1
    9bd4:	540000c1 	b.ne	9bec <fwp_main_thread+0x1d7c>  // b.any
    9bd8:	aa1a03e0 	mov	x0, x26
    9bdc:	97ffeb05 	bl	47f0 <fwp_mem_free>
    9be0:	f949ef65 	ldr	x5, [x27, #5080]
    9be4:	f949db61 	ldr	x1, [x27, #5040]
    9be8:	d370bca5 	lsl	x5, x5, #16
    9bec:	cb0102a1 	sub	x1, x21, x1
    9bf0:	eb0100bf 	cmp	x5, x1
    9bf4:	54ffc869 	b.ls	9500 <fwp_main_thread+0x1690>  // b.plast
    9bf8:	aa1503fa 	mov	x26, x21
    9bfc:	17fffe26 	b	9494 <fwp_main_thread+0x1624>
    9c00:	72003d1f 	tst	w8, #0xffff
    9c04:	54ffc421 	b.ne	9488 <fwp_main_thread+0x1618>  // b.any
    9c08:	17fffec6 	b	9720 <fwp_main_thread+0x18b0>
    9c0c:	72003c3f 	tst	w1, #0xffff
    9c10:	54ffe900 	b.eq	9930 <fwp_main_thread+0x1ac0>  // b.none
    9c14:	aa1a03e0 	mov	x0, x26
    9c18:	17fffcbe 	b	8f10 <fwp_main_thread+0x10a0>
    9c1c:	aa1703e0 	mov	x0, x23
    9c20:	f90007e5 	str	x5, [sp, #8]
    9c24:	97ffea53 	bl	4570 <fwp_rc_forget_slot>
    9c28:	f94007e5 	ldr	x5, [sp, #8]
    9c2c:	17ffff44 	b	993c <fwp_main_thread+0x1acc>
    9c30:	aa0203e0 	mov	x0, x2
    9c34:	d2800101 	mov	x1, #0x8                   	// #8
    9c38:	f90007e2 	str	x2, [sp, #8]
    9c3c:	97ffe309 	bl	2860 <calloc@plt>
    9c40:	f94007e2 	ldr	x2, [sp, #8]
    9c44:	aa0003f6 	mov	x22, x0
    9c48:	f9401be3 	ldr	x3, [sp, #48]
    9c4c:	f94023e5 	ldr	x5, [sp, #64]
    9c50:	17fffc2a 	b	8cf8 <fwp_main_thread+0xe88>
    9c54:	f94000a0 	ldr	x0, [x5]
    9c58:	b7ffe800 	tbnz	x0, #63, 9958 <fwp_main_thread+0x1ae8>
    9c5c:	f949db61 	ldr	x1, [x27, #5040]
    9c60:	f949ef62 	ldr	x2, [x27, #5080]
    9c64:	cb0102a1 	sub	x1, x21, x1
    9c68:	eb02403f 	cmp	x1, x2, lsl #16
    9c6c:	54ffe762 	b.cs	9958 <fwp_main_thread+0x1ae8>  // b.hs, b.nlast
    9c70:	9240f81a 	and	x26, x0, #0x7fffffffffffffff
    9c74:	17fffd12 	b	90bc <fwp_main_thread+0x124c>
    9c78:	d2800d01 	mov	x1, #0x68                  	// #104
    9c7c:	d2800036 	mov	x22, #0x1                   	// #1
    9c80:	17fffb0f 	b	88bc <fwp_main_thread+0xa4c>
    9c84:	72003d1f 	tst	w8, #0xffff
    9c88:	54fff2a1 	b.ne	9adc <fwp_main_thread+0x1c6c>  // b.any
    9c8c:	17ffff8d 	b	9ac0 <fwp_main_thread+0x1c50>
    9c90:	aa1503e0 	mov	x0, x21
    9c94:	97ffee13 	bl	54e0 <fwp_rc_free_arr>
    9c98:	f94027e0 	ldr	x0, [sp, #72]
    9c9c:	f9400800 	ldr	x0, [x0, #16]
    9ca0:	f90027e0 	str	x0, [sp, #72]
    9ca4:	b5ffd020 	cbnz	x0, 96a8 <fwp_main_thread+0x1838>
    9ca8:	aa1403e0 	mov	x0, x20
    9cac:	97ffeee1 	bl	5830 <fwp_drop0>
    9cb0:	f9400be0 	ldr	x0, [sp, #16]
    9cb4:	97ffeedf 	bl	5830 <fwp_drop0>
    9cb8:	9100c300 	add	x0, x24, #0x30
    9cbc:	fd40fbe8 	ldr	d8, [sp, #496]
    9cc0:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    9cc4:	52800021 	mov	w1, #0x1                   	// #1
    9cc8:	a95e73fb 	ldp	x27, x28, [sp, #480]
    9ccc:	b902f401 	str	w1, [x0, #756]
    9cd0:	f901801f 	str	xzr, [x0, #768]
    9cd4:	17fff8a7 	b	7f70 <fwp_main_thread+0x100>
    9cd8:	72003c5f 	tst	w2, #0xffff
    9cdc:	54ffeba1 	b.ne	9a50 <fwp_main_thread+0x1be0>  // b.any
    9ce0:	17ffff55 	b	9a34 <fwp_main_thread+0x1bc4>
    9ce4:	72003c1f 	tst	w0, #0xffff
    9ce8:	54fff821 	b.ne	9bec <fwp_main_thread+0x1d7c>  // b.any
    9cec:	17ffffb8 	b	9bcc <fwp_main_thread+0x1d5c>
    9cf0:	72003cbf 	tst	w5, #0xffff
    9cf4:	54ff4f41 	b.ne	86dc <fwp_main_thread+0x86c>  // b.any
    9cf8:	17fffa70 	b	86b8 <fwp_main_thread+0x848>
    9cfc:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9d00:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9d04:	91150021 	add	x1, x1, #0x540
    9d08:	ca402400 	eor	x0, x0, x0, lsr #9
    9d0c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d10:	f94a2400 	ldr	x0, [x0, #5192]
    9d14:	b5000080 	cbnz	x0, 9d24 <fwp_main_thread+0x1eb4>
    9d18:	14000010 	b	9d58 <fwp_main_thread+0x1ee8>
    9d1c:	f9400800 	ldr	x0, [x0, #16]
    9d20:	b40001c0 	cbz	x0, 9d58 <fwp_main_thread+0x1ee8>
    9d24:	f9400001 	ldr	x1, [x0]
    9d28:	eb16003f 	cmp	x1, x22
    9d2c:	54ffff81 	b.ne	9d1c <fwp_main_thread+0x1eac>  // b.any
    9d30:	f9400401 	ldr	x1, [x0, #8]
    9d34:	d1000421 	sub	x1, x1, #0x1
    9d38:	f9000401 	str	x1, [x0, #8]
    9d3c:	f103f83f 	cmp	x1, #0xfe
    9d40:	54ff74c1 	b.ne	8bd8 <fwp_main_thread+0xd68>  // b.any
    9d44:	aa1603e0 	mov	x0, x22
    9d48:	97ffea0a 	bl	4570 <fwp_rc_forget_slot>
    9d4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d50:	390002c0 	strb	w0, [x22]
    9d54:	17fffba1 	b	8bd8 <fwp_main_thread+0xd68>
    9d58:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    9d5c:	9129e000 	add	x0, x0, #0xa78
    9d60:	97ffe608 	bl	3580 <fwp_trap>
    9d64:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9d68:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9d6c:	91150021 	add	x1, x1, #0x540
    9d70:	ca402400 	eor	x0, x0, x0, lsr #9
    9d74:	8b200c20 	add	x0, x1, w0, uxtb #3
    9d78:	f94a2401 	ldr	x1, [x0, #5192]
    9d7c:	b5000081 	cbnz	x1, 9d8c <fwp_main_thread+0x1f1c>
    9d80:	17fffff6 	b	9d58 <fwp_main_thread+0x1ee8>
    9d84:	f9400821 	ldr	x1, [x1, #16]
    9d88:	b4fffe81 	cbz	x1, 9d58 <fwp_main_thread+0x1ee8>
    9d8c:	f9400020 	ldr	x0, [x1]
    9d90:	eb0002df 	cmp	x22, x0
    9d94:	54ffff81 	b.ne	9d84 <fwp_main_thread+0x1f14>  // b.any
    9d98:	f9400420 	ldr	x0, [x1, #8]
    9d9c:	d1000400 	sub	x0, x0, #0x1
    9da0:	f9000420 	str	x0, [x1, #8]
    9da4:	f103f81f 	cmp	x0, #0xfe
    9da8:	54000c20 	b.eq	9f2c <fwp_main_thread+0x20bc>  // b.none
    9dac:	90000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    9db0:	91150000 	add	x0, x0, #0x540
    9db4:	f949ec03 	ldr	x3, [x0, #5080]
    9db8:	f949d801 	ldr	x1, [x0, #5040]
    9dbc:	d370bc63 	lsl	x3, x3, #16
    9dc0:	17fffdb2 	b	9488 <fwp_main_thread+0x1618>
    9dc4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9dc8:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9dcc:	91150021 	add	x1, x1, #0x540
    9dd0:	ca402400 	eor	x0, x0, x0, lsr #9
    9dd4:	8b200c20 	add	x0, x1, w0, uxtb #3
    9dd8:	f94a2401 	ldr	x1, [x0, #5192]
    9ddc:	b5000081 	cbnz	x1, 9dec <fwp_main_thread+0x1f7c>
    9de0:	17ffffde 	b	9d58 <fwp_main_thread+0x1ee8>
    9de4:	f9400821 	ldr	x1, [x1, #16]
    9de8:	b4fffb81 	cbz	x1, 9d58 <fwp_main_thread+0x1ee8>
    9dec:	f9400020 	ldr	x0, [x1]
    9df0:	eb15001f 	cmp	x0, x21
    9df4:	54ffff81 	b.ne	9de4 <fwp_main_thread+0x1f74>  // b.any
    9df8:	f9400420 	ldr	x0, [x1, #8]
    9dfc:	d1000400 	sub	x0, x0, #0x1
    9e00:	f9000420 	str	x0, [x1, #8]
    9e04:	f103f81f 	cmp	x0, #0xfe
    9e08:	54ffb7c1 	b.ne	9500 <fwp_main_thread+0x1690>  // b.any
    9e0c:	aa1503e0 	mov	x0, x21
    9e10:	97ffe9d8 	bl	4570 <fwp_rc_forget_slot>
    9e14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e18:	390002a0 	strb	w0, [x21]
    9e1c:	17fffdb9 	b	9500 <fwp_main_thread+0x1690>
    9e20:	72003c5f 	tst	w2, #0xffff
    9e24:	54ffbe41 	b.ne	95ec <fwp_main_thread+0x177c>  // b.any
    9e28:	17fffdec 	b	95d8 <fwp_main_thread+0x1768>
    9e2c:	72003c5f 	tst	w2, #0xffff
    9e30:	54ffc341 	b.ne	9698 <fwp_main_thread+0x1828>  // b.any
    9e34:	17fffe11 	b	9678 <fwp_main_thread+0x1808>
    9e38:	aa1403fa 	mov	x26, x20
    9e3c:	d280001c 	mov	x28, #0x0                   	// #0
    9e40:	d2800017 	mov	x23, #0x0                   	// #0
    9e44:	17fffd6a 	b	93ec <fwp_main_thread+0x157c>
    9e48:	97ffe983 	bl	4454 <fwp_rc_wide_dup>
    9e4c:	17fffa4b 	b	8778 <fwp_main_thread+0x908>
    9e50:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9e54:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9e58:	91150021 	add	x1, x1, #0x540
    9e5c:	ca402400 	eor	x0, x0, x0, lsr #9
    9e60:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e64:	f94a2400 	ldr	x0, [x0, #5192]
    9e68:	b5000080 	cbnz	x0, 9e78 <fwp_main_thread+0x2008>
    9e6c:	17ffffbb 	b	9d58 <fwp_main_thread+0x1ee8>
    9e70:	f9400800 	ldr	x0, [x0, #16]
    9e74:	b4fff720 	cbz	x0, 9d58 <fwp_main_thread+0x1ee8>
    9e78:	f9400001 	ldr	x1, [x0]
    9e7c:	eb15003f 	cmp	x1, x21
    9e80:	54ffff81 	b.ne	9e70 <fwp_main_thread+0x2000>  // b.any
    9e84:	f9400401 	ldr	x1, [x0, #8]
    9e88:	d1000421 	sub	x1, x1, #0x1
    9e8c:	f9000401 	str	x1, [x0, #8]
    9e90:	f103f83f 	cmp	x1, #0xfe
    9e94:	54ff4b21 	b.ne	87f8 <fwp_main_thread+0x988>  // b.any
    9e98:	aa1503e0 	mov	x0, x21
    9e9c:	97ffe9b5 	bl	4570 <fwp_rc_forget_slot>
    9ea0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ea4:	390002a0 	strb	w0, [x21]
    9ea8:	17fffa54 	b	87f8 <fwp_main_thread+0x988>
    9eac:	72003c3f 	tst	w1, #0xffff
    9eb0:	54ff3b41 	b.ne	8618 <fwp_main_thread+0x7a8>  // b.any
    9eb4:	17fff9d4 	b	8604 <fwp_main_thread+0x794>
    9eb8:	72003c3f 	tst	w1, #0xffff
    9ebc:	54ff3621 	b.ne	8580 <fwp_main_thread+0x710>  // b.any
    9ec0:	17fff9ab 	b	856c <fwp_main_thread+0x6fc>
    9ec4:	72003c3f 	tst	w1, #0xffff
    9ec8:	54ff3121 	b.ne	84ec <fwp_main_thread+0x67c>  // b.any
    9ecc:	17fff983 	b	84d8 <fwp_main_thread+0x668>
    9ed0:	aa0003e1 	mov	x1, x0
    9ed4:	f9002274 	str	x20, [x19, #64]
    9ed8:	17fff83f 	b	7fd4 <fwp_main_thread+0x164>
    9edc:	d2800016 	mov	x22, #0x0                   	// #0
    9ee0:	17fffcd2 	b	9228 <fwp_main_thread+0x13b8>
    9ee4:	f9416a60 	ldr	x0, [x19, #720]
    9ee8:	97ffea42 	bl	47f0 <fwp_mem_free>
    9eec:	f9016a7f 	str	xzr, [x19, #720]
    9ef0:	f901727f 	str	xzr, [x19, #736]
    9ef4:	f9418a60 	ldr	x0, [x19, #784]
    9ef8:	b4000834 	cbz	x20, 9ffc <fwp_main_thread+0x218c>
    9efc:	f900569f 	str	xzr, [x20, #168]
    9f00:	f9005e9f 	str	xzr, [x20, #184]
    9f04:	b9030a7f 	str	wzr, [x19, #776]
    9f08:	eb14001f 	cmp	x0, x20
    9f0c:	54ff0c40 	b.eq	8094 <fwp_main_thread+0x224>  // b.none
    9f10:	a91d6bf9 	stp	x25, x26, [sp, #464]
    9f14:	a91e73fb 	stp	x27, x28, [sp, #480]
    9f18:	fd00fbe8 	str	d8, [sp, #496]
    9f1c:	97ffe26d 	bl	28d0 <abort@plt>
    9f20:	aa1603e0 	mov	x0, x22
    9f24:	97ffe993 	bl	4570 <fwp_rc_forget_slot>
    9f28:	17fffdaf 	b	95e4 <fwp_main_thread+0x1774>
    9f2c:	aa1603e0 	mov	x0, x22
    9f30:	97ffe990 	bl	4570 <fwp_rc_forget_slot>
    9f34:	90000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    9f38:	91150000 	add	x0, x0, #0x540
    9f3c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9f40:	390002c1 	strb	w1, [x22]
    9f44:	f949ec03 	ldr	x3, [x0, #5080]
    9f48:	f949d801 	ldr	x1, [x0, #5040]
    9f4c:	d370bc63 	lsl	x3, x3, #16
    9f50:	17fffd4e 	b	9488 <fwp_main_thread+0x1618>
    9f54:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    9f58:	912d6000 	add	x0, x0, #0xb58
    9f5c:	97ffe589 	bl	3580 <fwp_trap>
    9f60:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    9f64:	912b0000 	add	x0, x0, #0xac0
    9f68:	97ffe586 	bl	3580 <fwp_trap>
    9f6c:	97ffe93a 	bl	4454 <fwp_rc_wide_dup>
    9f70:	90000140 	adrp	x0, 31000 <fwp_root_context+0xca0>
    9f74:	91150000 	add	x0, x0, #0x540
    9f78:	f949ec06 	ldr	x6, [x0, #5080]
    9f7c:	f949d802 	ldr	x2, [x0, #5040]
    9f80:	d370bcc6 	lsl	x6, x6, #16
    9f84:	17fff9d6 	b	86dc <fwp_main_thread+0x86c>
    9f88:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9f8c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xca0>
    9f90:	91150021 	add	x1, x1, #0x540
    9f94:	ca402400 	eor	x0, x0, x0, lsr #9
    9f98:	8b200c20 	add	x0, x1, w0, uxtb #3
    9f9c:	f94a2400 	ldr	x0, [x0, #5192]
    9fa0:	b5000080 	cbnz	x0, 9fb0 <fwp_main_thread+0x2140>
    9fa4:	17ffff6d 	b	9d58 <fwp_main_thread+0x1ee8>
    9fa8:	f9400800 	ldr	x0, [x0, #16]
    9fac:	b4ffed60 	cbz	x0, 9d58 <fwp_main_thread+0x1ee8>
    9fb0:	f9400001 	ldr	x1, [x0]
    9fb4:	eb0102df 	cmp	x22, x1
    9fb8:	54ffff81 	b.ne	9fa8 <fwp_main_thread+0x2138>  // b.any
    9fbc:	f9400401 	ldr	x1, [x0, #8]
    9fc0:	d1000421 	sub	x1, x1, #0x1
    9fc4:	f9000401 	str	x1, [x0, #8]
    9fc8:	f103f83f 	cmp	x1, #0xfe
    9fcc:	54ffb661 	b.ne	9698 <fwp_main_thread+0x1828>  // b.any
    9fd0:	aa1603e0 	mov	x0, x22
    9fd4:	97ffe967 	bl	4570 <fwp_rc_forget_slot>
    9fd8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9fdc:	390002c0 	strb	w0, [x22]
    9fe0:	17fffdae 	b	9698 <fwp_main_thread+0x1828>
    9fe4:	aa1403e0 	mov	x0, x20
    9fe8:	97ffe962 	bl	4570 <fwp_rc_forget_slot>
    9fec:	17fff93e 	b	84e4 <fwp_main_thread+0x674>
    9ff0:	aa1403e0 	mov	x0, x20
    9ff4:	97ffe95f 	bl	4570 <fwp_rc_forget_slot>
    9ff8:	17fff960 	b	8578 <fwp_main_thread+0x708>
    9ffc:	b9030a7f 	str	wzr, [x19, #776]
    a000:	b4ff0e40 	cbz	x0, 81c8 <fwp_main_thread+0x358>
    a004:	17ffffc3 	b	9f10 <fwp_main_thread+0x20a0>
    a008:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a00c:	912ee000 	add	x0, x0, #0xbb8
    a010:	97ffe55c 	bl	3580 <fwp_trap>
    a014:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a018:	91350000 	add	x0, x0, #0xd40
    a01c:	97ffe559 	bl	3580 <fwp_trap>
    a020:	aa1603e0 	mov	x0, x22
    a024:	97ffe953 	bl	4570 <fwp_rc_forget_slot>
    a028:	17fff97a 	b	8610 <fwp_main_thread+0x7a0>
    a02c:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a030:	9135a000 	add	x0, x0, #0xd68
    a034:	97ffe553 	bl	3580 <fwp_trap>
    a038:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a03c:	91360000 	add	x0, x0, #0xd80
    a040:	97ffe550 	bl	3580 <fwp_trap>
    a044:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a048:	912c2000 	add	x0, x0, #0xb08
    a04c:	97ffe54d 	bl	3580 <fwp_trap>
    a050:	52800020 	mov	w0, #0x1                   	// #1
    a054:	17fffbd4 	b	8fa4 <fwp_main_thread+0x1134>
    a058:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a05c:	9134c000 	add	x0, x0, #0xd30
    a060:	97ffe548 	bl	3580 <fwp_trap>
    a064:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a068:	a91e73fb 	stp	x27, x28, [sp, #480]
    a06c:	fd00fbe8 	str	d8, [sp, #496]
    a070:	97ffe204 	bl	2880 <__stack_chk_fail@plt>
    a074:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a078:	91340000 	add	x0, x0, #0xd00
    a07c:	97ffe541 	bl	3580 <fwp_trap>
    a080:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a084:	91338000 	add	x0, x0, #0xce0
    a088:	97ffe53e 	bl	3580 <fwp_trap>
    a08c:	90000000 	adrp	x0, a000 <fwp_main_thread+0x2190>
    a090:	9132e000 	add	x0, x0, #0xcb8
    a094:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a098:	a91e73fb 	stp	x27, x28, [sp, #480]
    a09c:	fd00fbe8 	str	d8, [sp, #496]
    a0a0:	97ffe538 	bl	3580 <fwp_trap>
    a0a4:	97ffe277 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a0a8:	d503201f 	nop
    a0ac:	d503201f 	nop

000000000000a0b0 <__divti3>:
    a0b0:	d503245f 	bti	c
    a0b4:	d2800004 	mov	x4, #0x0                   	// #0
    a0b8:	b7f80721 	tbnz	x1, #63, a19c <__divti3+0xec>
    a0bc:	b6f80083 	tbz	x3, #63, a0cc <__divti3+0x1c>
    a0c0:	eb0203e2 	negs	x2, x2
    a0c4:	aa2403e4 	mvn	x4, x4
    a0c8:	da0303e3 	ngc	x3, x3
    a0cc:	aa0203e6 	mov	x6, x2
    a0d0:	aa0003e7 	mov	x7, x0
    a0d4:	aa0103e5 	mov	x5, x1
    a0d8:	b5000583 	cbnz	x3, a188 <__divti3+0xd8>
    a0dc:	eb01005f 	cmp	x2, x1
    a0e0:	54000e69 	b.ls	a2ac <__divti3+0x1fc>  // b.plast
    a0e4:	dac01040 	clz	x0, x2
    a0e8:	b40000e0 	cbz	x0, a104 <__divti3+0x54>
    a0ec:	4b0003e1 	neg	w1, w0
    a0f0:	9ac020a5 	lsl	x5, x5, x0
    a0f4:	9ac02046 	lsl	x6, x2, x0
    a0f8:	9ac124e1 	lsr	x1, x7, x1
    a0fc:	aa050025 	orr	x5, x1, x5
    a100:	9ac020e7 	lsl	x7, x7, x0
    a104:	d360fcc8 	lsr	x8, x6, #32
    a108:	92407cc2 	and	x2, x6, #0xffffffff
    a10c:	9ac808a3 	udiv	x3, x5, x8
    a110:	9b089465 	msub	x5, x3, x8, x5
    a114:	aa0303e0 	mov	x0, x3
    a118:	9b037c41 	mul	x1, x2, x3
    a11c:	93c780a5 	extr	x5, x5, x7, #32
    a120:	eb05003f 	cmp	x1, x5
    a124:	540000a9 	b.ls	a138 <__divti3+0x88>  // b.plast
    a128:	ab0500c5 	adds	x5, x6, x5
    a12c:	d1000460 	sub	x0, x3, #0x1
    a130:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a134:	540015a8 	b.hi	a3e8 <__divti3+0x338>  // b.pmore
    a138:	cb0100a5 	sub	x5, x5, x1
    a13c:	9ac808a3 	udiv	x3, x5, x8
    a140:	9b089465 	msub	x5, x3, x8, x5
    a144:	aa0303e1 	mov	x1, x3
    a148:	9b037c42 	mul	x2, x2, x3
    a14c:	aa0703e3 	mov	x3, x7
    a150:	b3607ca3 	bfi	x3, x5, #32, #32
    a154:	eb03005f 	cmp	x2, x3
    a158:	540000c9 	b.ls	a170 <__divti3+0xc0>  // b.plast
    a15c:	ab0300c3 	adds	x3, x6, x3
    a160:	d1000425 	sub	x5, x1, #0x1
    a164:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a168:	d1000821 	sub	x1, x1, #0x2
    a16c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a170:	aa008020 	orr	x0, x1, x0, lsl #32
    a174:	d2800001 	mov	x1, #0x0                   	// #0
    a178:	b4000064 	cbz	x4, a184 <__divti3+0xd4>
    a17c:	eb0003e0 	negs	x0, x0
    a180:	da0103e1 	ngc	x1, x1
    a184:	d65f03c0 	ret
    a188:	eb01007f 	cmp	x3, x1
    a18c:	54000109 	b.ls	a1ac <__divti3+0xfc>  // b.plast
    a190:	d2800001 	mov	x1, #0x0                   	// #0
    a194:	d2800000 	mov	x0, #0x0                   	// #0
    a198:	17fffff8 	b	a178 <__divti3+0xc8>
    a19c:	eb0003e0 	negs	x0, x0
    a1a0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a1a4:	da0103e1 	ngc	x1, x1
    a1a8:	17ffffc5 	b	a0bc <__divti3+0xc>
    a1ac:	dac01067 	clz	x7, x3
    a1b0:	b40010e7 	cbz	x7, a3cc <__divti3+0x31c>
    a1b4:	d2800805 	mov	x5, #0x40                  	// #64
    a1b8:	cb0700a5 	sub	x5, x5, x7
    a1bc:	9ac72063 	lsl	x3, x3, x7
    a1c0:	9ac52448 	lsr	x8, x2, x5
    a1c4:	aa030108 	orr	x8, x8, x3
    a1c8:	9ac52426 	lsr	x6, x1, x5
    a1cc:	92407d0a 	and	x10, x8, #0xffffffff
    a1d0:	d360fd09 	lsr	x9, x8, #32
    a1d4:	9ac52403 	lsr	x3, x0, x5
    a1d8:	9ac72021 	lsl	x1, x1, x7
    a1dc:	aa010063 	orr	x3, x3, x1
    a1e0:	9ac72042 	lsl	x2, x2, x7
    a1e4:	9ac908cb 	udiv	x11, x6, x9
    a1e8:	9b099965 	msub	x5, x11, x9, x6
    a1ec:	aa0b03e1 	mov	x1, x11
    a1f0:	9b0b7d46 	mul	x6, x10, x11
    a1f4:	93c380a5 	extr	x5, x5, x3, #32
    a1f8:	eb0500df 	cmp	x6, x5
    a1fc:	540000a9 	b.ls	a210 <__divti3+0x160>  // b.plast
    a200:	ab050105 	adds	x5, x8, x5
    a204:	d1000561 	sub	x1, x11, #0x1
    a208:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a20c:	54000f48 	b.hi	a3f4 <__divti3+0x344>  // b.pmore
    a210:	cb0600a6 	sub	x6, x5, x6
    a214:	9ac908cb 	udiv	x11, x6, x9
    a218:	9b099969 	msub	x9, x11, x9, x6
    a21c:	aa0b03e5 	mov	x5, x11
    a220:	9b0b7d4a 	mul	x10, x10, x11
    a224:	b3607d23 	bfi	x3, x9, #32, #32
    a228:	eb03015f 	cmp	x10, x3
    a22c:	540000a9 	b.ls	a240 <__divti3+0x190>  // b.plast
    a230:	ab030103 	adds	x3, x8, x3
    a234:	d1000565 	sub	x5, x11, #0x1
    a238:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a23c:	54000e28 	b.hi	a400 <__divti3+0x350>  // b.pmore
    a240:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a244:	92407c48 	and	x8, x2, #0xffffffff
    a248:	2a0503e5 	mov	w5, w5
    a24c:	d360fc42 	lsr	x2, x2, #32
    a250:	d360fc26 	lsr	x6, x1, #32
    a254:	cb0a0063 	sub	x3, x3, x10
    a258:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a25c:	9b087caa 	mul	x10, x5, x8
    a260:	9b087cc8 	mul	x8, x6, x8
    a264:	9b0220a5 	madd	x5, x5, x2, x8
    a268:	9b027cc6 	mul	x6, x6, x2
    a26c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a270:	8b0900c5 	add	x5, x6, x9
    a274:	eb02011f 	cmp	x8, x2
    a278:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a27c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a280:	eb06007f 	cmp	x3, x6
    a284:	540000e3 	b.cc	a2a0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a288:	92407d4a 	and	x10, x10, #0xffffffff
    a28c:	9ac72000 	lsl	x0, x0, x7
    a290:	8b028142 	add	x2, x10, x2, lsl #32
    a294:	eb02001f 	cmp	x0, x2
    a298:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a29c:	54000a01 	b.ne	a3dc <__divti3+0x32c>  // b.any
    a2a0:	d1000420 	sub	x0, x1, #0x1
    a2a4:	d2800001 	mov	x1, #0x0                   	// #0
    a2a8:	17ffffb4 	b	a178 <__divti3+0xc8>
    a2ac:	b5000062 	cbnz	x2, a2b8 <__divti3+0x208>
    a2b0:	d2800022 	mov	x2, #0x1                   	// #1
    a2b4:	9ac30846 	udiv	x6, x2, x3
    a2b8:	dac010c8 	clz	x8, x6
    a2bc:	b5000408 	cbnz	x8, a33c <__divti3+0x28c>
    a2c0:	d360fcc9 	lsr	x9, x6, #32
    a2c4:	92407cc5 	and	x5, x6, #0xffffffff
    a2c8:	cb060023 	sub	x3, x1, x6
    a2cc:	d2800021 	mov	x1, #0x1                   	// #1
    a2d0:	9ac90868 	udiv	x8, x3, x9
    a2d4:	9b098d03 	msub	x3, x8, x9, x3
    a2d8:	aa0803e0 	mov	x0, x8
    a2dc:	9b057d02 	mul	x2, x8, x5
    a2e0:	93c78063 	extr	x3, x3, x7, #32
    a2e4:	eb03005f 	cmp	x2, x3
    a2e8:	540000a9 	b.ls	a2fc <__divti3+0x24c>  // b.plast
    a2ec:	ab0300c3 	adds	x3, x6, x3
    a2f0:	d1000500 	sub	x0, x8, #0x1
    a2f4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a2f8:	54000968 	b.hi	a424 <__divti3+0x374>  // b.pmore
    a2fc:	cb020063 	sub	x3, x3, x2
    a300:	9ac90862 	udiv	x2, x3, x9
    a304:	aa0203e8 	mov	x8, x2
    a308:	9b098c42 	msub	x2, x2, x9, x3
    a30c:	aa0703e3 	mov	x3, x7
    a310:	9b057d05 	mul	x5, x8, x5
    a314:	b3607c43 	bfi	x3, x2, #32, #32
    a318:	eb0300bf 	cmp	x5, x3
    a31c:	540000c9 	b.ls	a334 <__divti3+0x284>  // b.plast
    a320:	ab0300c2 	adds	x2, x6, x3
    a324:	d1000503 	sub	x3, x8, #0x1
    a328:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a32c:	d1000908 	sub	x8, x8, #0x2
    a330:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a334:	aa008100 	orr	x0, x8, x0, lsl #32
    a338:	17ffff90 	b	a178 <__divti3+0xc8>
    a33c:	9ac820c6 	lsl	x6, x6, x8
    a340:	d2800803 	mov	x3, #0x40                  	// #64
    a344:	cb080063 	sub	x3, x3, x8
    a348:	d360fcc9 	lsr	x9, x6, #32
    a34c:	9ac82027 	lsl	x7, x1, x8
    a350:	92407cc5 	and	x5, x6, #0xffffffff
    a354:	9ac32422 	lsr	x2, x1, x3
    a358:	9ac32403 	lsr	x3, x0, x3
    a35c:	aa070063 	orr	x3, x3, x7
    a360:	9ac9084a 	udiv	x10, x2, x9
    a364:	9ac82007 	lsl	x7, x0, x8
    a368:	9b098940 	msub	x0, x10, x9, x2
    a36c:	aa0a03e1 	mov	x1, x10
    a370:	9b0a7ca2 	mul	x2, x5, x10
    a374:	93c38000 	extr	x0, x0, x3, #32
    a378:	eb00005f 	cmp	x2, x0
    a37c:	540000a9 	b.ls	a390 <__divti3+0x2e0>  // b.plast
    a380:	ab0000c0 	adds	x0, x6, x0
    a384:	d1000541 	sub	x1, x10, #0x1
    a388:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a38c:	54000468 	b.hi	a418 <__divti3+0x368>  // b.pmore
    a390:	cb020000 	sub	x0, x0, x2
    a394:	9ac9080a 	udiv	x10, x0, x9
    a398:	9b098140 	msub	x0, x10, x9, x0
    a39c:	aa0a03e2 	mov	x2, x10
    a3a0:	9b0a7ca8 	mul	x8, x5, x10
    a3a4:	b3607c03 	bfi	x3, x0, #32, #32
    a3a8:	eb03011f 	cmp	x8, x3
    a3ac:	540000a9 	b.ls	a3c0 <__divti3+0x310>  // b.plast
    a3b0:	ab0300c3 	adds	x3, x6, x3
    a3b4:	d1000542 	sub	x2, x10, #0x1
    a3b8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a3bc:	54000288 	b.hi	a40c <__divti3+0x35c>  // b.pmore
    a3c0:	cb080063 	sub	x3, x3, x8
    a3c4:	aa018041 	orr	x1, x2, x1, lsl #32
    a3c8:	17ffffc2 	b	a2d0 <__divti3+0x220>
    a3cc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a3d0:	d2800001 	mov	x1, #0x0                   	// #0
    a3d4:	9a9f87e0 	cset	x0, ls	// ls = plast
    a3d8:	17ffff68 	b	a178 <__divti3+0xc8>
    a3dc:	aa0103e0 	mov	x0, x1
    a3e0:	d2800001 	mov	x1, #0x0                   	// #0
    a3e4:	17ffff65 	b	a178 <__divti3+0xc8>
    a3e8:	d1000860 	sub	x0, x3, #0x2
    a3ec:	8b0600a5 	add	x5, x5, x6
    a3f0:	17ffff52 	b	a138 <__divti3+0x88>
    a3f4:	d1000961 	sub	x1, x11, #0x2
    a3f8:	8b0800a5 	add	x5, x5, x8
    a3fc:	17ffff85 	b	a210 <__divti3+0x160>
    a400:	d1000965 	sub	x5, x11, #0x2
    a404:	8b080063 	add	x3, x3, x8
    a408:	17ffff8e 	b	a240 <__divti3+0x190>
    a40c:	d1000942 	sub	x2, x10, #0x2
    a410:	8b060063 	add	x3, x3, x6
    a414:	17ffffeb 	b	a3c0 <__divti3+0x310>
    a418:	d1000941 	sub	x1, x10, #0x2
    a41c:	8b060000 	add	x0, x0, x6
    a420:	17ffffdc 	b	a390 <__divti3+0x2e0>
    a424:	d1000900 	sub	x0, x8, #0x2
    a428:	8b060063 	add	x3, x3, x6
    a42c:	17ffffb4 	b	a2fc <__divti3+0x24c>

000000000000a430 <__modti3>:
    a430:	d503245f 	bti	c
    a434:	d2800004 	mov	x4, #0x0                   	// #0
    a438:	b6f80081 	tbz	x1, #63, a448 <__modti3+0x18>
    a43c:	eb0003e0 	negs	x0, x0
    a440:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a444:	da0103e1 	ngc	x1, x1
    a448:	f100007f 	cmp	x3, #0x0
    a44c:	5400128b 	b.lt	a69c <__modti3+0x26c>  // b.tstop
    a450:	aa0003e7 	mov	x7, x0
    a454:	aa0103e6 	mov	x6, x1
    a458:	540004e1 	b.ne	a4f4 <__modti3+0xc4>  // b.any
    a45c:	eb02003f 	cmp	x1, x2
    a460:	54000dc2 	b.cs	a618 <__modti3+0x1e8>  // b.hs, b.nlast
    a464:	dac01043 	clz	x3, x2
    a468:	aa0303e5 	mov	x5, x3
    a46c:	b40000e3 	cbz	x3, a488 <__modti3+0x58>
    a470:	4b0303e6 	neg	w6, w3
    a474:	9ac32021 	lsl	x1, x1, x3
    a478:	9ac32042 	lsl	x2, x2, x3
    a47c:	9ac62406 	lsr	x6, x0, x6
    a480:	aa0100c6 	orr	x6, x6, x1
    a484:	9ac32007 	lsl	x7, x0, x3
    a488:	d360fc40 	lsr	x0, x2, #32
    a48c:	92407c43 	and	x3, x2, #0xffffffff
    a490:	9ac008c1 	udiv	x1, x6, x0
    a494:	9b009826 	msub	x6, x1, x0, x6
    a498:	9b017c61 	mul	x1, x3, x1
    a49c:	93c780c6 	extr	x6, x6, x7, #32
    a4a0:	eb06003f 	cmp	x1, x6
    a4a4:	540000a9 	b.ls	a4b8 <__modti3+0x88>  // b.plast
    a4a8:	ab060046 	adds	x6, x2, x6
    a4ac:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a4b0:	8b0200c8 	add	x8, x6, x2
    a4b4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a4b8:	cb0100c6 	sub	x6, x6, x1
    a4bc:	9ac008c8 	udiv	x8, x6, x0
    a4c0:	9b009901 	msub	x1, x8, x0, x6
    a4c4:	aa0703e0 	mov	x0, x7
    a4c8:	9b087c63 	mul	x3, x3, x8
    a4cc:	b3607c20 	bfi	x0, x1, #32, #32
    a4d0:	eb00007f 	cmp	x3, x0
    a4d4:	54001088 	b.hi	a6e4 <__modti3+0x2b4>  // b.pmore
    a4d8:	cb030000 	sub	x0, x0, x3
    a4dc:	9ac52400 	lsr	x0, x0, x5
    a4e0:	d2800001 	mov	x1, #0x0                   	// #0
    a4e4:	b4000064 	cbz	x4, a4f0 <__modti3+0xc0>
    a4e8:	eb0003e0 	negs	x0, x0
    a4ec:	da0103e1 	ngc	x1, x1
    a4f0:	d65f03c0 	ret
    a4f4:	dac01066 	clz	x6, x3
    a4f8:	eb03003f 	cmp	x1, x3
    a4fc:	54ffff43 	b.cc	a4e4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a500:	93407cc5 	sxtw	x5, w6
    a504:	d2800808 	mov	x8, #0x40                  	// #64
    a508:	cb050108 	sub	x8, x8, x5
    a50c:	9ac62063 	lsl	x3, x3, x6
    a510:	9ac62025 	lsl	x5, x1, x6
    a514:	9ac82447 	lsr	x7, x2, x8
    a518:	aa0300e7 	orr	x7, x7, x3
    a51c:	9ac82423 	lsr	x3, x1, x8
    a520:	92407cec 	and	x12, x7, #0xffffffff
    a524:	d360fcea 	lsr	x10, x7, #32
    a528:	9ac82401 	lsr	x1, x0, x8
    a52c:	aa050021 	orr	x1, x1, x5
    a530:	9ac62042 	lsl	x2, x2, x6
    a534:	9ac62000 	lsl	x0, x0, x6
    a538:	9aca086b 	udiv	x11, x3, x10
    a53c:	9b0a8d63 	msub	x3, x11, x10, x3
    a540:	aa0b03e5 	mov	x5, x11
    a544:	9b0b7d89 	mul	x9, x12, x11
    a548:	93c18063 	extr	x3, x3, x1, #32
    a54c:	eb03013f 	cmp	x9, x3
    a550:	540000a9 	b.ls	a564 <__modti3+0x134>  // b.plast
    a554:	ab0300e3 	adds	x3, x7, x3
    a558:	d1000565 	sub	x5, x11, #0x1
    a55c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a560:	54001168 	b.hi	a78c <__modti3+0x35c>  // b.pmore
    a564:	cb090063 	sub	x3, x3, x9
    a568:	9aca086b 	udiv	x11, x3, x10
    a56c:	9b0a8d6a 	msub	x10, x11, x10, x3
    a570:	aa0b03e9 	mov	x9, x11
    a574:	9b0b7d8c 	mul	x12, x12, x11
    a578:	b3607d41 	bfi	x1, x10, #32, #32
    a57c:	eb01019f 	cmp	x12, x1
    a580:	540000a9 	b.ls	a594 <__modti3+0x164>  // b.plast
    a584:	ab0100e1 	adds	x1, x7, x1
    a588:	d1000569 	sub	x9, x11, #0x1
    a58c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a590:	54000f88 	b.hi	a780 <__modti3+0x350>  // b.pmore
    a594:	aa058123 	orr	x3, x9, x5, lsl #32
    a598:	92407c4b 	and	x11, x2, #0xffffffff
    a59c:	2a0903e9 	mov	w9, w9
    a5a0:	d360fc4a 	lsr	x10, x2, #32
    a5a4:	d360fc63 	lsr	x3, x3, #32
    a5a8:	cb0c0021 	sub	x1, x1, x12
    a5ac:	aa0a03ec 	mov	x12, x10
    a5b0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a5b4:	9b0b7d25 	mul	x5, x9, x11
    a5b8:	9b0b7c6b 	mul	x11, x3, x11
    a5bc:	9b0a2d29 	madd	x9, x9, x10, x11
    a5c0:	92407caa 	and	x10, x5, #0xffffffff
    a5c4:	9b0c7c63 	mul	x3, x3, x12
    a5c8:	8b458125 	add	x5, x9, x5, lsr #32
    a5cc:	8b0d0069 	add	x9, x3, x13
    a5d0:	eb05017f 	cmp	x11, x5
    a5d4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a5d8:	8b058149 	add	x9, x10, x5, lsl #32
    a5dc:	8b458063 	add	x3, x3, x5, lsr #32
    a5e0:	eb03003f 	cmp	x1, x3
    a5e4:	54000063 	b.cc	a5f0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a5e8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a5ec:	54000082 	b.cs	a5fc <__modti3+0x1cc>  // b.hs, b.nlast
    a5f0:	eb020129 	subs	x9, x9, x2
    a5f4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a5f8:	cb070063 	sub	x3, x3, x7
    a5fc:	eb090000 	subs	x0, x0, x9
    a600:	da030021 	sbc	x1, x1, x3
    a604:	9ac62400 	lsr	x0, x0, x6
    a608:	9ac82028 	lsl	x8, x1, x8
    a60c:	aa000100 	orr	x0, x8, x0
    a610:	9ac62421 	lsr	x1, x1, x6
    a614:	17ffffb4 	b	a4e4 <__modti3+0xb4>
    a618:	b5000062 	cbnz	x2, a624 <__modti3+0x1f4>
    a61c:	d2800023 	mov	x3, #0x1                   	// #1
    a620:	9ac20862 	udiv	x2, x3, x2
    a624:	dac01048 	clz	x8, x2
    a628:	aa0803e5 	mov	x5, x8
    a62c:	b5000668 	cbnz	x8, a6f8 <__modti3+0x2c8>
    a630:	cb020020 	sub	x0, x1, x2
    a634:	d360fc49 	lsr	x9, x2, #32
    a638:	92407c4a 	and	x10, x2, #0xffffffff
    a63c:	9ac90801 	udiv	x1, x0, x9
    a640:	9b098020 	msub	x0, x1, x9, x0
    a644:	9b0a7c21 	mul	x1, x1, x10
    a648:	93c78000 	extr	x0, x0, x7, #32
    a64c:	eb00003f 	cmp	x1, x0
    a650:	540000a9 	b.ls	a664 <__modti3+0x234>  // b.plast
    a654:	ab000040 	adds	x0, x2, x0
    a658:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a65c:	8b020003 	add	x3, x0, x2
    a660:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a664:	cb010001 	sub	x1, x0, x1
    a668:	9ac90820 	udiv	x0, x1, x9
    a66c:	9b098403 	msub	x3, x0, x9, x1
    a670:	aa0703e1 	mov	x1, x7
    a674:	9b0a7c00 	mul	x0, x0, x10
    a678:	b3607c61 	bfi	x1, x3, #32, #32
    a67c:	eb01001f 	cmp	x0, x1
    a680:	540000a9 	b.ls	a694 <__modti3+0x264>  // b.plast
    a684:	ab010041 	adds	x1, x2, x1
    a688:	8b020022 	add	x2, x1, x2
    a68c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a690:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a694:	cb000020 	sub	x0, x1, x0
    a698:	17ffff91 	b	a4dc <__modti3+0xac>
    a69c:	eb0203e5 	negs	x5, x2
    a6a0:	aa0003e7 	mov	x7, x0
    a6a4:	da0303e8 	ngc	x8, x3
    a6a8:	aa0503e2 	mov	x2, x5
    a6ac:	aa0803e3 	mov	x3, x8
    a6b0:	aa0103e6 	mov	x6, x1
    a6b4:	b4ffed48 	cbz	x8, a45c <__modti3+0x2c>
    a6b8:	eb01011f 	cmp	x8, x1
    a6bc:	54fff148 	b.hi	a4e4 <__modti3+0xb4>  // b.pmore
    a6c0:	dac01109 	clz	x9, x8
    a6c4:	2a0903e6 	mov	w6, w9
    a6c8:	b5fff1c9 	cbnz	x9, a500 <__modti3+0xd0>
    a6cc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    a6d0:	54000068 	b.hi	a6dc <__modti3+0x2ac>  // b.pmore
    a6d4:	eb050007 	subs	x7, x0, x5
    a6d8:	da080021 	sbc	x1, x1, x8
    a6dc:	aa0703e0 	mov	x0, x7
    a6e0:	17ffff81 	b	a4e4 <__modti3+0xb4>
    a6e4:	ab000040 	adds	x0, x2, x0
    a6e8:	8b020002 	add	x2, x0, x2
    a6ec:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    a6f0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    a6f4:	17ffff79 	b	a4d8 <__modti3+0xa8>
    a6f8:	9ac82042 	lsl	x2, x2, x8
    a6fc:	d2800803 	mov	x3, #0x40                  	// #64
    a700:	cb080063 	sub	x3, x3, x8
    a704:	d360fc49 	lsr	x9, x2, #32
    a708:	9ac82027 	lsl	x7, x1, x8
    a70c:	92407c4a 	and	x10, x2, #0xffffffff
    a710:	9ac32426 	lsr	x6, x1, x3
    a714:	9ac32403 	lsr	x3, x0, x3
    a718:	aa070063 	orr	x3, x3, x7
    a71c:	9ac908c1 	udiv	x1, x6, x9
    a720:	9ac82007 	lsl	x7, x0, x8
    a724:	9b099820 	msub	x0, x1, x9, x6
    a728:	9b017d41 	mul	x1, x10, x1
    a72c:	93c38000 	extr	x0, x0, x3, #32
    a730:	eb00003f 	cmp	x1, x0
    a734:	540000a9 	b.ls	a748 <__modti3+0x318>  // b.plast
    a738:	ab000040 	adds	x0, x2, x0
    a73c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a740:	8b020006 	add	x6, x0, x2
    a744:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    a748:	cb010000 	sub	x0, x0, x1
    a74c:	9ac90801 	udiv	x1, x0, x9
    a750:	9b098026 	msub	x6, x1, x9, x0
    a754:	aa0303e0 	mov	x0, x3
    a758:	9b017d41 	mul	x1, x10, x1
    a75c:	b3607cc0 	bfi	x0, x6, #32, #32
    a760:	eb00003f 	cmp	x1, x0
    a764:	540000a9 	b.ls	a778 <__modti3+0x348>  // b.plast
    a768:	ab000040 	adds	x0, x2, x0
    a76c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a770:	8b020003 	add	x3, x0, x2
    a774:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a778:	cb010000 	sub	x0, x0, x1
    a77c:	17ffffb0 	b	a63c <__modti3+0x20c>
    a780:	d1000969 	sub	x9, x11, #0x2
    a784:	8b070021 	add	x1, x1, x7
    a788:	17ffff83 	b	a594 <__modti3+0x164>
    a78c:	d1000965 	sub	x5, x11, #0x2
    a790:	8b070063 	add	x3, x3, x7
    a794:	17ffff74 	b	a564 <__modti3+0x134>
    a798:	d503201f 	nop
    a79c:	d503201f 	nop

000000000000a7a0 <atexit>:
    a7a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a7a4:	d00000a2 	adrp	x2, 20000 <__data_start>
    a7a8:	d2800001 	mov	x1, #0x0                   	// #0
    a7ac:	910003fd 	mov	x29, sp
    a7b0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a7b4:	f9400442 	ldr	x2, [x2, #8]
    a7b8:	17ffdff2 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a7bc <_fini>:
    a7bc:	d503201f 	nop
    a7c0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a7c4:	910003fd 	mov	x29, sp
    a7c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a7cc:	d65f03c0 	ret
