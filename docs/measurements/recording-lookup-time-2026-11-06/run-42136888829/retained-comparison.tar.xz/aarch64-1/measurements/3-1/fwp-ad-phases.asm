
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	90000045 	adrp	x5, a000 <fwp_main_thread+0x1e90>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	9138e0a5 	add	x5, x5, #0xe38
    2b20:	90000044 	adrp	x4, a000 <fwp_main_thread+0x1e90>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91390084 	add	x4, x4, #0xe40
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x112f0>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x480>
    2bb4:	91086000 	add	x0, x0, #0x218
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xe7c>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	9105c042 	add	x2, x2, #0x170
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x480>
    2cfc:	9108a000 	add	x0, x0, #0x228
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x480>
    2d0c:	910b2000 	add	x0, x0, #0x2c8
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x480>
    2d24:	910a8000 	add	x0, x0, #0x2a0
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x480>
    2d30:	9109c000 	add	x0, x0, #0x270
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x480>
    2d3c:	91092000 	add	x0, x0, #0x248
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x480>
    2f34:	91254021 	add	x1, x1, #0x950
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    30d0:	912e2000 	add	x0, x0, #0xb88
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x480>
    3198:	9124c021 	add	x1, x1, #0x930
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    31d0:	912e8000 	add	x0, x0, #0xba0
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1e90>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	f0000036 	adrp	x22, a000 <fwp_main_thread+0x1e90>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	90000058 	adrp	x24, b000 <_IO_stdin_used+0x480>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	912fa042 	add	x2, x2, #0xbe8
    3260:	913102d6 	add	x22, x22, #0xc40
    3264:	911b4318 	add	x24, x24, #0x6d0
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x1e90>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	9130e323 	add	x3, x25, #0xc38
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	91314000 	add	x0, x0, #0xc50
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    35f0:	912e2000 	add	x0, x0, #0xb88
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1e90>
    3830:	aa1303e0 	mov	x0, x19
    3834:	91316021 	add	x1, x1, #0xc58
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1e90>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91318021 	add	x1, x1, #0xc60
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1e90>
    3860:	9131a021 	add	x1, x1, #0xc68
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1e90>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	9131c042 	add	x2, x2, #0xc70
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    39d0:	912e2000 	add	x0, x0, #0xb88
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    39f0:	91320000 	add	x0, x0, #0xc80
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    3a88:	91328000 	add	x0, x0, #0xca0
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    3a98:	91330000 	add	x0, x0, #0xcc0
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x480>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc25820 	ldr	q0, [x1, #2400]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    3b98:	9133a000 	add	x0, x0, #0xce8
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    3c08:	91346000 	add	x0, x0, #0xd18
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1e90>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	9135a084 	add	x4, x4, #0xd68
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1e90>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91360084 	add	x4, x4, #0xd80
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1e90>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	9135c084 	add	x4, x4, #0xd70
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    4028:	91174042 	add	x2, x2, #0x5d0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	d0000021 	adrp	x1, a000 <fwp_main_thread+0x1e90>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	91362021 	add	x1, x1, #0xd88
    4084:	91364000 	add	x0, x0, #0xd90
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	d0000022 	adrp	x2, a000 <fwp_main_thread+0x1e90>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	9136c042 	add	x2, x2, #0xdb0
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    418c:	91134061 	add	x1, x3, #0x4d0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    419c:	91174262 	add	x2, x19, #0x5d0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x480>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    41cc:	91144021 	add	x1, x1, #0x510
    41d0:	3dc25c43 	ldr	q3, [x2, #2416]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    41fc:	91134063 	add	x3, x3, #0x4d0
    4200:	9115c084 	add	x4, x4, #0x570
    4204:	91174266 	add	x6, x19, #0x5d0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91174275 	add	x21, x19, #0x5d0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    42e8:	91398000 	add	x0, x0, #0xe60
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91174273 	add	x19, x19, #0x5d0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	9101c122 	add	x2, x9, #0x70
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	9101c120 	add	x0, x9, #0x70
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	9101c129 	add	x9, x9, #0x70
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    444c:	9139c000 	add	x0, x0, #0xe70
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	9139c000 	add	x0, x0, #0xe70
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	9101c2d6 	add	x22, x22, #0x70
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	9139c000 	add	x0, x0, #0xe70
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	9101c281 	add	x1, x20, #0x70
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	9101c280 	add	x0, x20, #0x70
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	9101c288 	add	x8, x20, #0x70
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	9101c281 	add	x1, x20, #0x70
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    473c:	913a2000 	add	x0, x0, #0xe88
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911742a2 	add	x2, x21, #0x5d0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    47f4:	913b8000 	add	x0, x0, #0xee0
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911742b5 	add	x21, x21, #0x5d0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    4850:	913ae000 	add	x0, x0, #0xeb8
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    4860:	913c2000 	add	x0, x0, #0xf08
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    48a0:	91174262 	add	x2, x19, #0x5d0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91174273 	add	x19, x19, #0x5d0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    4900:	913b8000 	add	x0, x0, #0xee0
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4920:	911742c2 	add	x2, x22, #0x5d0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911742c2 	add	x2, x22, #0x5d0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911742d6 	add	x22, x22, #0x5d0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a40:	911742b5 	add	x21, x21, #0x5d0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4b04:	911742a1 	add	x1, x21, #0x5d0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911742b5 	add	x21, x21, #0x5d0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911742a1 	add	x1, x21, #0x5d0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911742a0 	add	x0, x21, #0x5d0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911742b5 	add	x21, x21, #0x5d0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d08:	91174359 	add	x25, x26, #0x5d0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	5400118b 	b.lt	53dc <fwp_p_ad_push+0x238>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	910003fd 	mov	x29, sp
    51b8:	a90153f3 	stp	x19, x20, [sp, #16]
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0403f6 	mov	x22, x4
    51c4:	aa0003f5 	mov	x21, x0
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f8 	mov	x24, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	aa020001 	orr	x1, x0, x2
    51e0:	b6f80dc1 	tbz	x1, #63, 5398 <fwp_p_ad_push+0x1f4>
    51e4:	9360fc14 	asr	x20, x0, #32
    51e8:	b6f800c0 	tbz	x0, #63, 5200 <fwp_p_ad_push+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc54 	asr	x20, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5200:	b4001136 	cbz	x22, 5424 <fwp_p_ad_push+0x280>
    5204:	f94002c0 	ldr	x0, [x22]
    5208:	eb14001f 	cmp	x0, x20
    520c:	54000e40 	b.eq	53d4 <fwp_p_ad_push+0x230>  // b.none
    5210:	aa1403e0 	mov	x0, x20
    5214:	97fffa67 	bl	3bb0 <fwp_tape_of>
    5218:	aa0003f3 	mov	x19, x0
    521c:	f9403000 	ldr	x0, [x0, #96]
    5220:	b50010c0 	cbnz	x0, 5438 <fwp_p_ad_push+0x294>
    5224:	a9004ed4 	stp	x20, x19, [x22]
    5228:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    522c:	f9400a77 	ldr	x23, [x19, #16]
    5230:	a9046bf9 	stp	x25, x26, [sp, #64]
    5234:	eb0002ff 	cmp	x23, x0
    5238:	540013ec 	b.gt	54b4 <fwp_p_ad_push+0x310>
    523c:	eb3542ff 	cmp	x23, w21, uxtw
    5240:	5400132d 	b.le	54a4 <fwp_p_ad_push+0x300>
    5244:	b7f80078 	tbnz	x24, #63, 5250 <fwp_p_ad_push+0xac>
    5248:	eb3842ff 	cmp	x23, w24, uxtw
    524c:	540012cd 	b.le	54a4 <fwp_p_ad_push+0x300>
    5250:	f9400676 	ldr	x22, [x19, #8]
    5254:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5258:	cb1602f6 	sub	x22, x23, x22
    525c:	910006c1 	add	x1, x22, #0x1
    5260:	aa1603f9 	mov	x25, x22
    5264:	eb00003f 	cmp	x1, x0
    5268:	54001268 	b.hi	54b4 <fwp_p_ad_push+0x310>  // b.pmore
    526c:	a9418274 	ldp	x20, x0, [x19, #24]
    5270:	eb14003f 	cmp	x1, x20
    5274:	54000a6d 	b.le	53c0 <fwp_p_ad_push+0x21c>
    5278:	f100029f 	cmp	x20, #0x0
    527c:	d2800803 	mov	x3, #0x40                  	// #64
    5280:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5284:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5288:	a90573fb 	stp	x27, x28, [sp, #80]
    528c:	eb14003f 	cmp	x1, x20
    5290:	5400008d 	b.le	52a0 <fwp_p_ad_push+0xfc>
    5294:	eb02029f 	cmp	x20, x2
    5298:	5400090d 	b.le	53b8 <fwp_p_ad_push+0x214>
    529c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    52a0:	d37df29a 	lsl	x26, x20, #3
    52a4:	f940327b 	ldr	x27, [x19, #96]
    52a8:	aa1a03e1 	mov	x1, x26
    52ac:	97fff595 	bl	2900 <realloc@plt>
    52b0:	b40010a0 	cbz	x0, 54c4 <fwp_p_ad_push+0x320>
    52b4:	f9400e61 	ldr	x1, [x19, #24]
    52b8:	8b010801 	add	x1, x0, x1, lsl #2
    52bc:	a9020660 	stp	x0, x1, [x19, #32]
    52c0:	b400093b 	cbz	x27, 53e4 <fwp_p_ad_push+0x240>
    52c4:	f9403363 	ldr	x3, [x27, #96]
    52c8:	f9003be3 	str	x3, [sp, #112]
    52cc:	eb03029f 	cmp	x20, x3
    52d0:	5400034d 	b.le	5338 <fwp_p_ad_push+0x194>
    52d4:	f940237c 	ldr	x28, [x27, #64]
    52d8:	d37cee82 	lsl	x2, x20, #4
    52dc:	aa0203e0 	mov	x0, x2
    52e0:	52800041 	mov	w1, #0x2                   	// #2
    52e4:	f9003fe2 	str	x2, [sp, #120]
    52e8:	97ffff22 	bl	4f70 <fwp_heap_alloc>
    52ec:	aa0003fa 	mov	x26, x0
    52f0:	b400013c 	cbz	x28, 5314 <fwp_p_ad_push+0x170>
    52f4:	a9470be3 	ldp	x3, x2, [sp, #112]
    52f8:	aa1c03e1 	mov	x1, x28
    52fc:	d37cec63 	lsl	x3, x3, #4
    5300:	eb02007f 	cmp	x3, x2
    5304:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5308:	97fff516 	bl	2760 <memcpy@plt>
    530c:	aa1c03e0 	mov	x0, x28
    5310:	97fffdf8 	bl	4af0 <fwp_mem_free>
    5314:	f9403360 	ldr	x0, [x27, #96]
    5318:	52800001 	mov	w1, #0x0                   	// #0
    531c:	cb000282 	sub	x2, x20, x0
    5320:	8b001340 	add	x0, x26, x0, lsl #4
    5324:	d37cec42 	lsl	x2, x2, #4
    5328:	97fff56e 	bl	28e0 <memset@plt>
    532c:	f9401260 	ldr	x0, [x19, #32]
    5330:	f900237a 	str	x26, [x27, #64]
    5334:	f9003374 	str	x20, [x27, #96]
    5338:	b50008b6 	cbnz	x22, 544c <fwp_p_ad_push+0x2a8>
    533c:	a9431263 	ldp	x3, x4, [x19, #48]
    5340:	d37ef69a 	lsl	x26, x20, #2
    5344:	a94573fb 	ldp	x27, x28, [sp, #80]
    5348:	8b1a0002 	add	x2, x0, x26
    534c:	f9000e74 	str	x20, [x19, #24]
    5350:	f9001662 	str	x2, [x19, #40]
    5354:	b8366815 	str	w21, [x0, x22]
    5358:	f100031f 	cmp	x24, #0x0
    535c:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    5360:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5364:	fc396869 	str	d9, [x3, x25]
    5368:	aa1702a0 	orr	x0, x21, x23
    536c:	b8366841 	str	w1, [x2, x22]
    5370:	910006e1 	add	x1, x23, #0x1
    5374:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5378:	fc396888 	str	d8, [x4, x25]
    537c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5380:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5384:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5388:	f9000a61 	str	x1, [x19, #16]
    538c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5390:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5394:	d65f03c0 	ret
    5398:	9360fc54 	asr	x20, x2, #32
    539c:	eb80829f 	cmp	x20, x0, asr #32
    53a0:	54fff300 	b.eq	5200 <fwp_p_ad_push+0x5c>  // b.none
    53a4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    53a8:	913ca000 	add	x0, x0, #0xf28
    53ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    53b0:	a90573fb 	stp	x27, x28, [sp, #80]
    53b4:	97fff933 	bl	3880 <fwp_trap>
    53b8:	d37ffa94 	lsl	x20, x20, #1
    53bc:	17ffffb4 	b	528c <fwp_p_ad_push+0xe8>
    53c0:	a9428e62 	ldp	x2, x3, [x19, #40]
    53c4:	d37ef6d6 	lsl	x22, x22, #2
    53c8:	f9401e64 	ldr	x4, [x19, #56]
    53cc:	d37df339 	lsl	x25, x25, #3
    53d0:	17ffffe1 	b	5354 <fwp_p_ad_push+0x1b0>
    53d4:	f94006d3 	ldr	x19, [x22, #8]
    53d8:	17ffff94 	b	5228 <fwp_p_ad_push+0x84>
    53dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53e0:	d65f03c0 	ret
    53e4:	f9401a60 	ldr	x0, [x19, #48]
    53e8:	d37cee9b 	lsl	x27, x20, #4
    53ec:	aa1b03e1 	mov	x1, x27
    53f0:	97fff544 	bl	2900 <realloc@plt>
    53f4:	aa0003e3 	mov	x3, x0
    53f8:	b4000660 	cbz	x0, 54c4 <fwp_p_ad_push+0x320>
    53fc:	8b1a0004 	add	x4, x0, x26
    5400:	f9400e60 	ldr	x0, [x19, #24]
    5404:	8b000c61 	add	x1, x3, x0, lsl #3
    5408:	a9030663 	stp	x3, x1, [x19, #48]
    540c:	b5000356 	cbnz	x22, 5474 <fwp_p_ad_push+0x2d0>
    5410:	f9401260 	ldr	x0, [x19, #32]
    5414:	d37ef69a 	lsl	x26, x20, #2
    5418:	d2800016 	mov	x22, #0x0                   	// #0
    541c:	f9001e64 	str	x4, [x19, #56]
    5420:	17ffffc9 	b	5344 <fwp_p_ad_push+0x1a0>
    5424:	aa1403e0 	mov	x0, x20
    5428:	97fff9e2 	bl	3bb0 <fwp_tape_of>
    542c:	aa0003f3 	mov	x19, x0
    5430:	f9403000 	ldr	x0, [x0, #96]
    5434:	b4ffefa0 	cbz	x0, 5228 <fwp_p_ad_push+0x84>
    5438:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    543c:	913dc000 	add	x0, x0, #0xf70
    5440:	a9046bf9 	stp	x25, x26, [sp, #64]
    5444:	a90573fb 	stp	x27, x28, [sp, #80]
    5448:	97fff90e 	bl	3880 <fwp_trap>
    544c:	d37df2d9 	lsl	x25, x22, #3
    5450:	f9401661 	ldr	x1, [x19, #40]
    5454:	d37ef6d6 	lsl	x22, x22, #2
    5458:	d37ef69a 	lsl	x26, x20, #2
    545c:	aa1603e2 	mov	x2, x22
    5460:	8b1a0000 	add	x0, x0, x26
    5464:	97fff4c7 	bl	2780 <memmove@plt>
    5468:	f9401260 	ldr	x0, [x19, #32]
    546c:	a9431263 	ldp	x3, x4, [x19, #48]
    5470:	17ffffb5 	b	5344 <fwp_p_ad_push+0x1a0>
    5474:	eb1b035f 	cmp	x26, x27
    5478:	d37df2d9 	lsl	x25, x22, #3
    547c:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5480:	aa0403e0 	mov	x0, x4
    5484:	cb1a0063 	sub	x3, x3, x26
    5488:	aa1903e2 	mov	x2, x25
    548c:	97fff589 	bl	2ab0 <__memmove_chk@plt>
    5490:	f9401a61 	ldr	x1, [x19, #48]
    5494:	f9401260 	ldr	x0, [x19, #32]
    5498:	8b1a0021 	add	x1, x1, x26
    549c:	f9001e61 	str	x1, [x19, #56]
    54a0:	17ffffec 	b	5450 <fwp_p_ad_push+0x2ac>
    54a4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    54a8:	913f0000 	add	x0, x0, #0xfc0
    54ac:	a90573fb 	stp	x27, x28, [sp, #80]
    54b0:	97fff8f4 	bl	3880 <fwp_trap>
    54b4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    54b8:	913e8000 	add	x0, x0, #0xfa0
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	97fff8f0 	bl	3880 <fwp_trap>
    54c4:	aa1303e0 	mov	x0, x19
    54c8:	97fff6d2 	bl	3010 <fwp_tape_unlink_scope>
    54cc:	f9401260 	ldr	x0, [x19, #32]
    54d0:	97fff540 	bl	29d0 <free@plt>
    54d4:	f9401a60 	ldr	x0, [x19, #48]
    54d8:	97fff53e 	bl	29d0 <free@plt>
    54dc:	f9402260 	ldr	x0, [x19, #64]
    54e0:	97fff53c 	bl	29d0 <free@plt>
    54e4:	f9000e7f 	str	xzr, [x19, #24]
    54e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    54ec:	f947e821 	ldr	x1, [x1, #4048]
    54f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    54f4:	d2800262 	mov	x2, #0x13                  	// #19
    54f8:	4f000400 	movi	v0.4s, #0x0
    54fc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    5500:	f9400023 	ldr	x3, [x1]
    5504:	b900067f 	str	wzr, [x19, #4]
    5508:	d2800021 	mov	x1, #0x1                   	// #1
    550c:	912e2000 	add	x0, x0, #0xb88
    5510:	3c808260 	stur	q0, [x19, #8]
    5514:	ad010260 	stp	q0, q0, [x19, #32]
    5518:	97fff53e 	bl	2a10 <fwrite@plt>
    551c:	d2800000 	mov	x0, #0x0                   	// #0
    5520:	97fff548 	bl	2a40 <fflush@plt>
    5524:	52800cc0 	mov	w0, #0x66                  	// #102
    5528:	97fff556 	bl	2a80 <_Exit@plt>
    552c:	d503201f 	nop

0000000000005530 <w120>:
    5530:	d10203ff 	sub	sp, sp, #0x80
    5534:	9e660003 	fmov	x3, d0
    5538:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    553c:	f947f442 	ldr	x2, [x2, #4072]
    5540:	a9027bfd 	stp	x29, x30, [sp, #32]
    5544:	910083fd 	add	x29, sp, #0x20
    5548:	6d0627e8 	stp	d8, d9, [sp, #96]
    554c:	1e604009 	fmov	d9, d0
    5550:	1e604028 	fmov	d8, d1
    5554:	fd003bea 	str	d10, [sp, #112]
    5558:	1e60080a 	fmul	d10, d0, d0
    555c:	a90353f3 	stp	x19, x20, [sp, #48]
    5560:	910023f3 	add	x19, sp, #0x8
    5564:	aa0003f4 	mov	x20, x0
    5568:	a9045bf5 	stp	x21, x22, [sp, #64]
    556c:	aa0103f6 	mov	x22, x1
    5570:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5574:	a90563f7 	stp	x23, x24, [sp, #80]
    5578:	aa0303e1 	mov	x1, x3
    557c:	f9400044 	ldr	x4, [x2]
    5580:	f9000fe4 	str	x4, [sp, #24]
    5584:	d2800004 	mov	x4, #0x0                   	// #0
    5588:	aa0003e2 	mov	x2, x0
    558c:	aa1303e4 	mov	x4, x19
    5590:	a900fff5 	stp	x21, xzr, [sp, #8]
    5594:	97ffff04 	bl	51a4 <fwp_p_ad_push>
    5598:	1e6a3908 	fsub	d8, d8, d10
    559c:	aa1603e2 	mov	x2, x22
    55a0:	aa1303e4 	mov	x4, x19
    55a4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55a8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    55ac:	9e660118 	fmov	x24, d8
    55b0:	97fffefd 	bl	51a4 <fwp_p_ad_push>
    55b4:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    55b8:	aa0003f6 	mov	x22, x0
    55bc:	aa1303e4 	mov	x4, x19
    55c0:	aa1403e0 	mov	x0, x20
    55c4:	1e69394a 	fsub	d10, d10, d9
    55c8:	aa1503e2 	mov	x2, x21
    55cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55d0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    55d4:	9e660157 	fmov	x23, d10
    55d8:	97fffef3 	bl	51a4 <fwp_p_ad_push>
    55dc:	1e680908 	fmul	d8, d8, d8
    55e0:	aa0003f4 	mov	x20, x0
    55e4:	aa1303e4 	mov	x4, x19
    55e8:	aa1803e3 	mov	x3, x24
    55ec:	aa1803e1 	mov	x1, x24
    55f0:	aa1603e2 	mov	x2, x22
    55f4:	aa1603e0 	mov	x0, x22
    55f8:	97fffeeb 	bl	51a4 <fwp_p_ad_push>
    55fc:	aa0003e2 	mov	x2, x0
    5600:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5604:	9e670029 	fmov	d9, x1
    5608:	9e660101 	fmov	x1, d8
    560c:	aa1303e4 	mov	x4, x19
    5610:	1e690909 	fmul	d9, d8, d9
    5614:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5618:	aa1503e0 	mov	x0, x21
    561c:	97fffee2 	bl	51a4 <fwp_p_ad_push>
    5620:	1e6a094a 	fmul	d10, d10, d10
    5624:	aa1303e4 	mov	x4, x19
    5628:	aa1703e3 	mov	x3, x23
    562c:	aa0003f3 	mov	x19, x0
    5630:	aa1703e1 	mov	x1, x23
    5634:	aa1403e2 	mov	x2, x20
    5638:	aa1403e0 	mov	x0, x20
    563c:	97fffeda 	bl	51a4 <fwp_p_ad_push>
    5640:	1e6a2929 	fadd	d9, d9, d10
    5644:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5648:	d2800004 	mov	x4, #0x0                   	// #0
    564c:	aa0303e1 	mov	x1, x3
    5650:	aa1303e2 	mov	x2, x19
    5654:	97fffed4 	bl	51a4 <fwp_p_ad_push>
    5658:	aa0003e1 	mov	x1, x0
    565c:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    5660:	f947f463 	ldr	x3, [x3, #4072]
    5664:	f9400fe0 	ldr	x0, [sp, #24]
    5668:	f9400064 	ldr	x4, [x3]
    566c:	eb040000 	subs	x0, x0, x4
    5670:	d2800004 	mov	x4, #0x0                   	// #0
    5674:	54000161 	b.ne	56a0 <w120+0x170>  // b.any
    5678:	9e660122 	fmov	x2, d9
    567c:	fd403bea 	ldr	d10, [sp, #112]
    5680:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5684:	a94353f3 	ldp	x19, x20, [sp, #48]
    5688:	aa0203e0 	mov	x0, x2
    568c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5690:	a94563f7 	ldp	x23, x24, [sp, #80]
    5694:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5698:	910203ff 	add	sp, sp, #0x80
    569c:	d65f03c0 	ret
    56a0:	97fff49c 	bl	2910 <__stack_chk_fail@plt>

00000000000056a4 <w176.constprop.0>:
    56a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56a8:	910003fd 	mov	x29, sp
    56ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    56b0:	fd001be8 	str	d8, [sp, #48]
    56b4:	f9400015 	ldr	x21, [x0]
    56b8:	b4000355 	cbz	x21, 5720 <w176.constprop.0+0x7c>
    56bc:	2f00e408 	movi	d8, #0x0
    56c0:	91002016 	add	x22, x0, #0x8
    56c4:	a90153f3 	stp	x19, x20, [sp, #16]
    56c8:	91004014 	add	x20, x0, #0x10
    56cc:	d2800013 	mov	x19, #0x0                   	// #0
    56d0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    56d4:	d503201f 	nop
    56d8:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    56dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    56e0:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    56e4:	aa0303e1 	mov	x1, x3
    56e8:	1e602908 	fadd	d8, d8, d0
    56ec:	d2800004 	mov	x4, #0x0                   	// #0
    56f0:	91000a73 	add	x19, x19, #0x2
    56f4:	97fffeac 	bl	51a4 <fwp_p_ad_push>
    56f8:	eb1302bf 	cmp	x21, x19
    56fc:	54fffee8 	b.hi	56d8 <w176.constprop.0+0x34>  // b.pmore
    5700:	9e660102 	fmov	x2, d8
    5704:	fd401be8 	ldr	d8, [sp, #48]
    5708:	a94153f3 	ldp	x19, x20, [sp, #16]
    570c:	aa0003e1 	mov	x1, x0
    5710:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5714:	aa0203e0 	mov	x0, x2
    5718:	a8c47bfd 	ldp	x29, x30, [sp], #64
    571c:	d65f03c0 	ret
    5720:	2f00e408 	movi	d8, #0x0
    5724:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5728:	a9425bf5 	ldp	x21, x22, [sp, #32]
    572c:	aa0003e1 	mov	x1, x0
    5730:	9e660102 	fmov	x2, d8
    5734:	fd401be8 	ldr	d8, [sp, #48]
    5738:	a8c47bfd 	ldp	x29, x30, [sp], #64
    573c:	aa0203e0 	mov	x0, x2
    5740:	d65f03c0 	ret

0000000000005744 <fwp_rc_share>:
    5744:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5748:	91174042 	add	x2, x2, #0x5d0
    574c:	f949d843 	ldr	x3, [x2, #5040]
    5750:	f949ec41 	ldr	x1, [x2, #5080]
    5754:	cb030000 	sub	x0, x0, x3
    5758:	eb01401f 	cmp	x0, x1, lsl #16
    575c:	540002c2 	b.cs	57b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5760:	d350fc01 	lsr	x1, x0, #16
    5764:	f949fc44 	ldr	x4, [x2, #5112]
    5768:	8b010821 	add	x1, x1, x1, lsl #2
    576c:	d37df021 	lsl	x1, x1, #3
    5770:	8b010083 	add	x3, x4, x1
    5774:	f9401062 	ldr	x2, [x3, #32]
    5778:	b40001e2 	cbz	x2, 57b4 <fwp_rc_share+0x70>
    577c:	38616881 	ldrb	w1, [x4, x1]
    5780:	7100083f 	cmp	w1, #0x2
    5784:	540001a0 	b.eq	57b8 <fwp_rc_share+0x74>  // b.none
    5788:	7100043f 	cmp	w1, #0x1
    578c:	54000141 	b.ne	57b4 <fwp_rc_share+0x70>  // b.any
    5790:	29430464 	ldp	w4, w1, [x3, #24]
    5794:	92403c00 	and	x0, x0, #0xffff
    5798:	9b047c00 	mul	x0, x0, x4
    579c:	d360fc00 	lsr	x0, x0, #32
    57a0:	eb01001f 	cmp	x0, x1
    57a4:	54000082 	b.cs	57b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    57a8:	8b000042 	add	x2, x2, x0
    57ac:	39400040 	ldrb	w0, [x2]
    57b0:	350000a0 	cbnz	w0, 57c4 <fwp_rc_share+0x80>
    57b4:	d65f03c0 	ret
    57b8:	72003c1f 	tst	w0, #0xffff
    57bc:	54ffff80 	b.eq	57ac <fwp_rc_share+0x68>  // b.none
    57c0:	d65f03c0 	ret
    57c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57c8:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    57cc:	913f8000 	add	x0, x0, #0xfe0
    57d0:	910003fd 	mov	x29, sp
    57d4:	97fff82b 	bl	3880 <fwp_trap>
    57d8:	d503201f 	nop
    57dc:	d503201f 	nop

00000000000057e0 <fwp_rc_free_arr>:
    57e0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    57e4:	91174063 	add	x3, x3, #0x5d0
    57e8:	f949d861 	ldr	x1, [x3, #5040]
    57ec:	f949ec62 	ldr	x2, [x3, #5080]
    57f0:	cb010001 	sub	x1, x0, x1
    57f4:	eb02403f 	cmp	x1, x2, lsl #16
    57f8:	54000342 	b.cs	5860 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57fc:	d350fc22 	lsr	x2, x1, #16
    5800:	f949fc65 	ldr	x5, [x3, #5112]
    5804:	8b020842 	add	x2, x2, x2, lsl #2
    5808:	d37df042 	lsl	x2, x2, #3
    580c:	8b0200a4 	add	x4, x5, x2
    5810:	f9401083 	ldr	x3, [x4, #32]
    5814:	b4000263 	cbz	x3, 5860 <fwp_rc_free_arr+0x80>
    5818:	386268a2 	ldrb	w2, [x5, x2]
    581c:	7100085f 	cmp	w2, #0x2
    5820:	540001c0 	b.eq	5858 <fwp_rc_free_arr+0x78>  // b.none
    5824:	7100045f 	cmp	w2, #0x1
    5828:	540001c1 	b.ne	5860 <fwp_rc_free_arr+0x80>  // b.any
    582c:	29430885 	ldp	w5, w2, [x4, #24]
    5830:	92403c21 	and	x1, x1, #0xffff
    5834:	9b057c21 	mul	x1, x1, x5
    5838:	d360fc21 	lsr	x1, x1, #32
    583c:	eb02003f 	cmp	x1, x2
    5840:	54000102 	b.cs	5860 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5844:	8b010063 	add	x3, x3, x1
    5848:	39400061 	ldrb	w1, [x3]
    584c:	7100043f 	cmp	w1, #0x1
    5850:	54000081 	b.ne	5860 <fwp_rc_free_arr+0x80>  // b.any
    5854:	17fffca7 	b	4af0 <fwp_mem_free>
    5858:	72003c3f 	tst	w1, #0xffff
    585c:	54ffff60 	b.eq	5848 <fwp_rc_free_arr+0x68>  // b.none
    5860:	d65f03c0 	ret

0000000000005864 <fwp_rc_dup>:
    5864:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5868:	91174042 	add	x2, x2, #0x5d0
    586c:	f949d841 	ldr	x1, [x2, #5040]
    5870:	f949ec43 	ldr	x3, [x2, #5080]
    5874:	cb010001 	sub	x1, x0, x1
    5878:	eb03403f 	cmp	x1, x3, lsl #16
    587c:	54000342 	b.cs	58e4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5880:	d350fc20 	lsr	x0, x1, #16
    5884:	f949fc44 	ldr	x4, [x2, #5112]
    5888:	8b000800 	add	x0, x0, x0, lsl #2
    588c:	d37df002 	lsl	x2, x0, #3
    5890:	8b020083 	add	x3, x4, x2
    5894:	f9401060 	ldr	x0, [x3, #32]
    5898:	b4000260 	cbz	x0, 58e4 <fwp_rc_dup+0x80>
    589c:	38626882 	ldrb	w2, [x4, x2]
    58a0:	7100085f 	cmp	w2, #0x2
    58a4:	54000220 	b.eq	58e8 <fwp_rc_dup+0x84>  // b.none
    58a8:	7100045f 	cmp	w2, #0x1
    58ac:	540001c1 	b.ne	58e4 <fwp_rc_dup+0x80>  // b.any
    58b0:	29430864 	ldp	w4, w2, [x3, #24]
    58b4:	92403c21 	and	x1, x1, #0xffff
    58b8:	9b047c21 	mul	x1, x1, x4
    58bc:	d360fc21 	lsr	x1, x1, #32
    58c0:	eb02003f 	cmp	x1, x2
    58c4:	54000102 	b.cs	58e4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58c8:	8b010000 	add	x0, x0, x1
    58cc:	39400001 	ldrb	w1, [x0]
    58d0:	340000a1 	cbz	w1, 58e4 <fwp_rc_dup+0x80>
    58d4:	7103f43f 	cmp	w1, #0xfd
    58d8:	540000e8 	b.hi	58f4 <fwp_rc_dup+0x90>  // b.pmore
    58dc:	11000421 	add	w1, w1, #0x1
    58e0:	39000001 	strb	w1, [x0]
    58e4:	d65f03c0 	ret
    58e8:	72003c3f 	tst	w1, #0xffff
    58ec:	54ffff00 	b.eq	58cc <fwp_rc_dup+0x68>  // b.none
    58f0:	d65f03c0 	ret
    58f4:	17fffb98 	b	4754 <fwp_rc_wide_dup>
    58f8:	d503201f 	nop
    58fc:	d503201f 	nop

0000000000005900 <fwp_owned_entry173>:
    5900:	d10103ff 	sub	sp, sp, #0x40
    5904:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5908:	f947f442 	ldr	x2, [x2, #4072]
    590c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5910:	910083fd 	add	x29, sp, #0x20
    5914:	a90353f3 	stp	x19, x20, [sp, #48]
    5918:	f9400043 	ldr	x3, [x2]
    591c:	f9000fe3 	str	x3, [sp, #24]
    5920:	d2800003 	mov	x3, #0x0                   	// #0
    5924:	a9400c01 	ldp	x1, x3, [x0]
    5928:	f9400802 	ldr	x2, [x0, #16]
    592c:	ab020022 	adds	x2, x1, x2
    5930:	540006e6 	b.vs	5a0c <fwp_owned_entry173+0x10c>
    5934:	910023e1 	add	x1, sp, #0x8
    5938:	52800000 	mov	w0, #0x0                   	// #0
    593c:	a9008be3 	stp	x3, x2, [sp, #8]
    5940:	97fffdd1 	bl	5084 <fwp_data.part.0.constprop.0>
    5944:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5948:	91174063 	add	x3, x3, #0x5d0
    594c:	aa0003f3 	mov	x19, x0
    5950:	f949d861 	ldr	x1, [x3, #5040]
    5954:	f949ec60 	ldr	x0, [x3, #5080]
    5958:	cb010261 	sub	x1, x19, x1
    595c:	eb00403f 	cmp	x1, x0, lsl #16
    5960:	54000322 	b.cs	59c4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5964:	d350fc22 	lsr	x2, x1, #16
    5968:	f949fc63 	ldr	x3, [x3, #5112]
    596c:	8b020842 	add	x2, x2, x2, lsl #2
    5970:	d37df042 	lsl	x2, x2, #3
    5974:	8b020060 	add	x0, x3, x2
    5978:	f9401014 	ldr	x20, [x0, #32]
    597c:	b4000254 	cbz	x20, 59c4 <fwp_owned_entry173+0xc4>
    5980:	38626862 	ldrb	w2, [x3, x2]
    5984:	7100085f 	cmp	w2, #0x2
    5988:	54000360 	b.eq	59f4 <fwp_owned_entry173+0xf4>  // b.none
    598c:	7100045f 	cmp	w2, #0x1
    5990:	540001a1 	b.ne	59c4 <fwp_owned_entry173+0xc4>  // b.any
    5994:	29430002 	ldp	w2, w0, [x0, #24]
    5998:	92403c21 	and	x1, x1, #0xffff
    599c:	9b027c21 	mul	x1, x1, x2
    59a0:	d360fc21 	lsr	x1, x1, #32
    59a4:	eb00003f 	cmp	x1, x0
    59a8:	540000e2 	b.cs	59c4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    59ac:	8b010294 	add	x20, x20, x1
    59b0:	39400280 	ldrb	w0, [x20]
    59b4:	7103fc1f 	cmp	w0, #0xff
    59b8:	54000240 	b.eq	5a00 <fwp_owned_entry173+0x100>  // b.none
    59bc:	52800020 	mov	w0, #0x1                   	// #1
    59c0:	39000280 	strb	w0, [x20]
    59c4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59c8:	f947f400 	ldr	x0, [x0, #4072]
    59cc:	f9400fe2 	ldr	x2, [sp, #24]
    59d0:	f9400001 	ldr	x1, [x0]
    59d4:	eb010042 	subs	x2, x2, x1
    59d8:	d2800001 	mov	x1, #0x0                   	// #0
    59dc:	540001a1 	b.ne	5a10 <fwp_owned_entry173+0x110>  // b.any
    59e0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59e4:	aa1303e0 	mov	x0, x19
    59e8:	a94353f3 	ldp	x19, x20, [sp, #48]
    59ec:	910103ff 	add	sp, sp, #0x40
    59f0:	d65f03c0 	ret
    59f4:	72003c3f 	tst	w1, #0xffff
    59f8:	54fffe61 	b.ne	59c4 <fwp_owned_entry173+0xc4>  // b.any
    59fc:	17ffffed 	b	59b0 <fwp_owned_entry173+0xb0>
    5a00:	aa1403e0 	mov	x0, x20
    5a04:	97fffb9b 	bl	4870 <fwp_rc_forget_slot>
    5a08:	17ffffed 	b	59bc <fwp_owned_entry173+0xbc>
    5a0c:	97fff43d 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5a10:	97fff3c0 	bl	2910 <__stack_chk_fail@plt>

0000000000005a14 <e173>:
    5a14:	d10103ff 	sub	sp, sp, #0x40
    5a18:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5a1c:	f947f442 	ldr	x2, [x2, #4072]
    5a20:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a24:	910083fd 	add	x29, sp, #0x20
    5a28:	a90353f3 	stp	x19, x20, [sp, #48]
    5a2c:	f9400043 	ldr	x3, [x2]
    5a30:	f9000fe3 	str	x3, [sp, #24]
    5a34:	d2800003 	mov	x3, #0x0                   	// #0
    5a38:	a9400c01 	ldp	x1, x3, [x0]
    5a3c:	f9400802 	ldr	x2, [x0, #16]
    5a40:	ab020022 	adds	x2, x1, x2
    5a44:	54000726 	b.vs	5b28 <e173+0x114>
    5a48:	910023e1 	add	x1, sp, #0x8
    5a4c:	52800000 	mov	w0, #0x0                   	// #0
    5a50:	a9008be3 	stp	x3, x2, [sp, #8]
    5a54:	97fffd8c 	bl	5084 <fwp_data.part.0.constprop.0>
    5a58:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5a5c:	91174063 	add	x3, x3, #0x5d0
    5a60:	aa0003f3 	mov	x19, x0
    5a64:	f949d861 	ldr	x1, [x3, #5040]
    5a68:	f949ec60 	ldr	x0, [x3, #5080]
    5a6c:	cb010261 	sub	x1, x19, x1
    5a70:	eb00403f 	cmp	x1, x0, lsl #16
    5a74:	54000322 	b.cs	5ad8 <e173+0xc4>  // b.hs, b.nlast
    5a78:	d350fc22 	lsr	x2, x1, #16
    5a7c:	f949fc63 	ldr	x3, [x3, #5112]
    5a80:	8b020842 	add	x2, x2, x2, lsl #2
    5a84:	d37df042 	lsl	x2, x2, #3
    5a88:	8b020060 	add	x0, x3, x2
    5a8c:	f9401014 	ldr	x20, [x0, #32]
    5a90:	b4000254 	cbz	x20, 5ad8 <e173+0xc4>
    5a94:	38626862 	ldrb	w2, [x3, x2]
    5a98:	7100085f 	cmp	w2, #0x2
    5a9c:	540003a0 	b.eq	5b10 <e173+0xfc>  // b.none
    5aa0:	7100045f 	cmp	w2, #0x1
    5aa4:	540001a1 	b.ne	5ad8 <e173+0xc4>  // b.any
    5aa8:	29430002 	ldp	w2, w0, [x0, #24]
    5aac:	92403c21 	and	x1, x1, #0xffff
    5ab0:	9b027c21 	mul	x1, x1, x2
    5ab4:	d360fc21 	lsr	x1, x1, #32
    5ab8:	eb00003f 	cmp	x1, x0
    5abc:	540000e2 	b.cs	5ad8 <e173+0xc4>  // b.hs, b.nlast
    5ac0:	8b010294 	add	x20, x20, x1
    5ac4:	39400280 	ldrb	w0, [x20]
    5ac8:	7103fc1f 	cmp	w0, #0xff
    5acc:	54000280 	b.eq	5b1c <e173+0x108>  // b.none
    5ad0:	52800020 	mov	w0, #0x1                   	// #1
    5ad4:	39000280 	strb	w0, [x20]
    5ad8:	aa1303e0 	mov	x0, x19
    5adc:	97ffff1a 	bl	5744 <fwp_rc_share>
    5ae0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ae4:	f947f400 	ldr	x0, [x0, #4072]
    5ae8:	f9400fe2 	ldr	x2, [sp, #24]
    5aec:	f9400001 	ldr	x1, [x0]
    5af0:	eb010042 	subs	x2, x2, x1
    5af4:	d2800001 	mov	x1, #0x0                   	// #0
    5af8:	540001a1 	b.ne	5b2c <e173+0x118>  // b.any
    5afc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b00:	aa1303e0 	mov	x0, x19
    5b04:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b08:	910103ff 	add	sp, sp, #0x40
    5b0c:	d65f03c0 	ret
    5b10:	72003c3f 	tst	w1, #0xffff
    5b14:	54fffe21 	b.ne	5ad8 <e173+0xc4>  // b.any
    5b18:	17ffffeb 	b	5ac4 <e173+0xb0>
    5b1c:	aa1403e0 	mov	x0, x20
    5b20:	97fffb54 	bl	4870 <fwp_rc_forget_slot>
    5b24:	17ffffeb 	b	5ad0 <e173+0xbc>
    5b28:	97fff3f6 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5b2c:	97fff379 	bl	2910 <__stack_chk_fail@plt>

0000000000005b30 <fwp_drop0>:
    5b30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b34:	910003fd 	mov	x29, sp
    5b38:	a90153f3 	stp	x19, x20, [sp, #16]
    5b3c:	f90013f5 	str	x21, [sp, #32]
    5b40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5b44:	911742b4 	add	x20, x21, #0x5d0
    5b48:	f949da81 	ldr	x1, [x20, #5040]
    5b4c:	f949ee82 	ldr	x2, [x20, #5080]
    5b50:	cb010001 	sub	x1, x0, x1
    5b54:	eb02403f 	cmp	x1, x2, lsl #16
    5b58:	54000382 	b.cs	5bc8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b5c:	d350fc22 	lsr	x2, x1, #16
    5b60:	f949fe84 	ldr	x4, [x20, #5112]
    5b64:	8b020842 	add	x2, x2, x2, lsl #2
    5b68:	d37df042 	lsl	x2, x2, #3
    5b6c:	8b020083 	add	x3, x4, x2
    5b70:	f9401073 	ldr	x19, [x3, #32]
    5b74:	b40002b3 	cbz	x19, 5bc8 <fwp_drop0+0x98>
    5b78:	38626882 	ldrb	w2, [x4, x2]
    5b7c:	7100085f 	cmp	w2, #0x2
    5b80:	540002c0 	b.eq	5bd8 <fwp_drop0+0xa8>  // b.none
    5b84:	7100045f 	cmp	w2, #0x1
    5b88:	54000201 	b.ne	5bc8 <fwp_drop0+0x98>  // b.any
    5b8c:	29430864 	ldp	w4, w2, [x3, #24]
    5b90:	92403c21 	and	x1, x1, #0xffff
    5b94:	9b047c21 	mul	x1, x1, x4
    5b98:	d360fc21 	lsr	x1, x1, #32
    5b9c:	eb02003f 	cmp	x1, x2
    5ba0:	54000142 	b.cs	5bc8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ba4:	8b010273 	add	x19, x19, x1
    5ba8:	39400261 	ldrb	w1, [x19]
    5bac:	340000e1 	cbz	w1, 5bc8 <fwp_drop0+0x98>
    5bb0:	7100043f 	cmp	w1, #0x1
    5bb4:	540001e0 	b.eq	5bf0 <fwp_drop0+0xc0>  // b.none
    5bb8:	7103fc3f 	cmp	w1, #0xff
    5bbc:	540002e0 	b.eq	5c18 <fwp_drop0+0xe8>  // b.none
    5bc0:	51000421 	sub	w1, w1, #0x1
    5bc4:	39000261 	strb	w1, [x19]
    5bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bcc:	f94013f5 	ldr	x21, [sp, #32]
    5bd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bd4:	d65f03c0 	ret
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54fffe60 	b.eq	5ba8 <fwp_drop0+0x78>  // b.none
    5be0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5be4:	f94013f5 	ldr	x21, [sp, #32]
    5be8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bec:	d65f03c0 	ret
    5bf0:	f9400813 	ldr	x19, [x0, #16]
    5bf4:	97fffefb 	bl	57e0 <fwp_rc_free_arr>
    5bf8:	911742a0 	add	x0, x21, #0x5d0
    5bfc:	f949d801 	ldr	x1, [x0, #5040]
    5c00:	f949ec00 	ldr	x0, [x0, #5080]
    5c04:	cb010261 	sub	x1, x19, x1
    5c08:	eb00403f 	cmp	x1, x0, lsl #16
    5c0c:	54fffde2 	b.cs	5bc8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c10:	aa1303e0 	mov	x0, x19
    5c14:	17ffffd2 	b	5b5c <fwp_drop0+0x2c>
    5c18:	ca534660 	eor	x0, x19, x19, lsr #17
    5c1c:	911742b5 	add	x21, x21, #0x5d0
    5c20:	ca402400 	eor	x0, x0, x0, lsr #9
    5c24:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5c28:	f94a2400 	ldr	x0, [x0, #5192]
    5c2c:	b5000080 	cbnz	x0, 5c3c <fwp_drop0+0x10c>
    5c30:	14000010 	b	5c70 <fwp_drop0+0x140>
    5c34:	f9400800 	ldr	x0, [x0, #16]
    5c38:	b40001c0 	cbz	x0, 5c70 <fwp_drop0+0x140>
    5c3c:	f9400001 	ldr	x1, [x0]
    5c40:	eb13003f 	cmp	x1, x19
    5c44:	54ffff81 	b.ne	5c34 <fwp_drop0+0x104>  // b.any
    5c48:	f9400401 	ldr	x1, [x0, #8]
    5c4c:	d1000421 	sub	x1, x1, #0x1
    5c50:	f9000401 	str	x1, [x0, #8]
    5c54:	f103f83f 	cmp	x1, #0xfe
    5c58:	54fffb81 	b.ne	5bc8 <fwp_drop0+0x98>  // b.any
    5c5c:	aa1303e0 	mov	x0, x19
    5c60:	97fffb04 	bl	4870 <fwp_rc_forget_slot>
    5c64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c68:	39000260 	strb	w0, [x19]
    5c6c:	17ffffd7 	b	5bc8 <fwp_drop0+0x98>
    5c70:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    5c74:	913b8000 	add	x0, x0, #0xee0
    5c78:	97fff702 	bl	3880 <fwp_trap>
    5c7c:	d503201f 	nop

0000000000005c80 <fwp_drop1>:
    5c80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c84:	910003fd 	mov	x29, sp
    5c88:	a90153f3 	stp	x19, x20, [sp, #16]
    5c8c:	f90013f5 	str	x21, [sp, #32]
    5c90:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5c94:	911742b4 	add	x20, x21, #0x5d0
    5c98:	f949da81 	ldr	x1, [x20, #5040]
    5c9c:	f949ee82 	ldr	x2, [x20, #5080]
    5ca0:	cb010001 	sub	x1, x0, x1
    5ca4:	eb02403f 	cmp	x1, x2, lsl #16
    5ca8:	54000382 	b.cs	5d18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cac:	d350fc22 	lsr	x2, x1, #16
    5cb0:	f949fe84 	ldr	x4, [x20, #5112]
    5cb4:	8b020842 	add	x2, x2, x2, lsl #2
    5cb8:	d37df042 	lsl	x2, x2, #3
    5cbc:	8b020083 	add	x3, x4, x2
    5cc0:	f9401073 	ldr	x19, [x3, #32]
    5cc4:	b40002b3 	cbz	x19, 5d18 <fwp_drop1+0x98>
    5cc8:	38626882 	ldrb	w2, [x4, x2]
    5ccc:	7100085f 	cmp	w2, #0x2
    5cd0:	540002c0 	b.eq	5d28 <fwp_drop1+0xa8>  // b.none
    5cd4:	7100045f 	cmp	w2, #0x1
    5cd8:	54000201 	b.ne	5d18 <fwp_drop1+0x98>  // b.any
    5cdc:	29430864 	ldp	w4, w2, [x3, #24]
    5ce0:	92403c21 	and	x1, x1, #0xffff
    5ce4:	9b047c21 	mul	x1, x1, x4
    5ce8:	d360fc21 	lsr	x1, x1, #32
    5cec:	eb02003f 	cmp	x1, x2
    5cf0:	54000142 	b.cs	5d18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cf4:	8b010273 	add	x19, x19, x1
    5cf8:	39400261 	ldrb	w1, [x19]
    5cfc:	340000e1 	cbz	w1, 5d18 <fwp_drop1+0x98>
    5d00:	7100043f 	cmp	w1, #0x1
    5d04:	540001e0 	b.eq	5d40 <fwp_drop1+0xc0>  // b.none
    5d08:	7103fc3f 	cmp	w1, #0xff
    5d0c:	540002e0 	b.eq	5d68 <fwp_drop1+0xe8>  // b.none
    5d10:	51000421 	sub	w1, w1, #0x1
    5d14:	39000261 	strb	w1, [x19]
    5d18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d1c:	f94013f5 	ldr	x21, [sp, #32]
    5d20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d24:	d65f03c0 	ret
    5d28:	72003c3f 	tst	w1, #0xffff
    5d2c:	54fffe60 	b.eq	5cf8 <fwp_drop1+0x78>  // b.none
    5d30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d34:	f94013f5 	ldr	x21, [sp, #32]
    5d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d3c:	d65f03c0 	ret
    5d40:	f9400813 	ldr	x19, [x0, #16]
    5d44:	97fffea7 	bl	57e0 <fwp_rc_free_arr>
    5d48:	911742a0 	add	x0, x21, #0x5d0
    5d4c:	f949d801 	ldr	x1, [x0, #5040]
    5d50:	f949ec00 	ldr	x0, [x0, #5080]
    5d54:	cb010261 	sub	x1, x19, x1
    5d58:	eb00403f 	cmp	x1, x0, lsl #16
    5d5c:	54fffde2 	b.cs	5d18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d60:	aa1303e0 	mov	x0, x19
    5d64:	17ffffd2 	b	5cac <fwp_drop1+0x2c>
    5d68:	ca534660 	eor	x0, x19, x19, lsr #17
    5d6c:	911742b5 	add	x21, x21, #0x5d0
    5d70:	ca402400 	eor	x0, x0, x0, lsr #9
    5d74:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5d78:	f94a2400 	ldr	x0, [x0, #5192]
    5d7c:	b5000080 	cbnz	x0, 5d8c <fwp_drop1+0x10c>
    5d80:	14000010 	b	5dc0 <fwp_drop1+0x140>
    5d84:	f9400800 	ldr	x0, [x0, #16]
    5d88:	b40001c0 	cbz	x0, 5dc0 <fwp_drop1+0x140>
    5d8c:	f9400001 	ldr	x1, [x0]
    5d90:	eb13003f 	cmp	x1, x19
    5d94:	54ffff81 	b.ne	5d84 <fwp_drop1+0x104>  // b.any
    5d98:	f9400401 	ldr	x1, [x0, #8]
    5d9c:	d1000421 	sub	x1, x1, #0x1
    5da0:	f9000401 	str	x1, [x0, #8]
    5da4:	f103f83f 	cmp	x1, #0xfe
    5da8:	54fffb81 	b.ne	5d18 <fwp_drop1+0x98>  // b.any
    5dac:	aa1303e0 	mov	x0, x19
    5db0:	97fffab0 	bl	4870 <fwp_rc_forget_slot>
    5db4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5db8:	39000260 	strb	w0, [x19]
    5dbc:	17ffffd7 	b	5d18 <fwp_drop1+0x98>
    5dc0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    5dc4:	913b8000 	add	x0, x0, #0xee0
    5dc8:	97fff6ae 	bl	3880 <fwp_trap>
    5dcc:	d503201f 	nop

0000000000005dd0 <fwp_closure_drop>:
    5dd0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5dd4:	911740a4 	add	x4, x5, #0x5d0
    5dd8:	aa0003e1 	mov	x1, x0
    5ddc:	f949d882 	ldr	x2, [x4, #5040]
    5de0:	f949ec80 	ldr	x0, [x4, #5080]
    5de4:	cb020022 	sub	x2, x1, x2
    5de8:	eb00405f 	cmp	x2, x0, lsl #16
    5dec:	54000662 	b.cs	5eb8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5df0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5df4:	d350fc43 	lsr	x3, x2, #16
    5df8:	910003fd 	mov	x29, sp
    5dfc:	8b030863 	add	x3, x3, x3, lsl #2
    5e00:	f949fc84 	ldr	x4, [x4, #5112]
    5e04:	d37df063 	lsl	x3, x3, #3
    5e08:	f9000bf3 	str	x19, [sp, #16]
    5e0c:	8b030080 	add	x0, x4, x3
    5e10:	f9401013 	ldr	x19, [x0, #32]
    5e14:	b40002b3 	cbz	x19, 5e68 <fwp_closure_drop+0x98>
    5e18:	38636883 	ldrb	w3, [x4, x3]
    5e1c:	7100087f 	cmp	w3, #0x2
    5e20:	54000420 	b.eq	5ea4 <fwp_closure_drop+0xd4>  // b.none
    5e24:	7100047f 	cmp	w3, #0x1
    5e28:	54000201 	b.ne	5e68 <fwp_closure_drop+0x98>  // b.any
    5e2c:	29430003 	ldp	w3, w0, [x0, #24]
    5e30:	92403c42 	and	x2, x2, #0xffff
    5e34:	9b037c42 	mul	x2, x2, x3
    5e38:	d360fc42 	lsr	x2, x2, #32
    5e3c:	eb00005f 	cmp	x2, x0
    5e40:	54000142 	b.cs	5e68 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5e44:	8b020273 	add	x19, x19, x2
    5e48:	39400260 	ldrb	w0, [x19]
    5e4c:	340000e0 	cbz	w0, 5e68 <fwp_closure_drop+0x98>
    5e50:	7100041f 	cmp	w0, #0x1
    5e54:	54000100 	b.eq	5e74 <fwp_closure_drop+0xa4>  // b.none
    5e58:	7103fc1f 	cmp	w0, #0xff
    5e5c:	54000300 	b.eq	5ebc <fwp_closure_drop+0xec>  // b.none
    5e60:	51000400 	sub	w0, w0, #0x1
    5e64:	39000260 	strb	w0, [x19]
    5e68:	f9400bf3 	ldr	x19, [sp, #16]
    5e6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e70:	d65f03c0 	ret
    5e74:	d53bd040 	mrs	x0, tpidr_el0
    5e78:	91400000 	add	x0, x0, #0x0, lsl #12
    5e7c:	91004000 	add	x0, x0, #0x10
    5e80:	f9400000 	ldr	x0, [x0]
    5e84:	b4000080 	cbz	x0, 5e94 <fwp_closure_drop+0xc4>
    5e88:	f9400bf3 	ldr	x19, [sp, #16]
    5e8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e90:	17fff695 	b	38e4 <fwp_closure_drop_push>
    5e94:	f9400bf3 	ldr	x19, [sp, #16]
    5e98:	aa0103e0 	mov	x0, x1
    5e9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ea0:	17fff700 	b	3aa0 <fwp_closure_drop.part.0>
    5ea4:	72003c5f 	tst	w2, #0xffff
    5ea8:	54fffd00 	b.eq	5e48 <fwp_closure_drop+0x78>  // b.none
    5eac:	f9400bf3 	ldr	x19, [sp, #16]
    5eb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5eb4:	d65f03c0 	ret
    5eb8:	d65f03c0 	ret
    5ebc:	ca534660 	eor	x0, x19, x19, lsr #17
    5ec0:	911740a5 	add	x5, x5, #0x5d0
    5ec4:	ca402400 	eor	x0, x0, x0, lsr #9
    5ec8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5ecc:	f94a2400 	ldr	x0, [x0, #5192]
    5ed0:	b5000080 	cbnz	x0, 5ee0 <fwp_closure_drop+0x110>
    5ed4:	14000010 	b	5f14 <fwp_closure_drop+0x144>
    5ed8:	f9400800 	ldr	x0, [x0, #16]
    5edc:	b40001c0 	cbz	x0, 5f14 <fwp_closure_drop+0x144>
    5ee0:	f9400001 	ldr	x1, [x0]
    5ee4:	eb13003f 	cmp	x1, x19
    5ee8:	54ffff81 	b.ne	5ed8 <fwp_closure_drop+0x108>  // b.any
    5eec:	f9400401 	ldr	x1, [x0, #8]
    5ef0:	d1000421 	sub	x1, x1, #0x1
    5ef4:	f9000401 	str	x1, [x0, #8]
    5ef8:	f103f83f 	cmp	x1, #0xfe
    5efc:	54fffb61 	b.ne	5e68 <fwp_closure_drop+0x98>  // b.any
    5f00:	aa1303e0 	mov	x0, x19
    5f04:	97fffa5b 	bl	4870 <fwp_rc_forget_slot>
    5f08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f0c:	39000260 	strb	w0, [x19]
    5f10:	17ffffd6 	b	5e68 <fwp_closure_drop+0x98>
    5f14:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    5f18:	913b8000 	add	x0, x0, #0xee0
    5f1c:	97fff659 	bl	3880 <fwp_trap>

0000000000005f20 <fwp_owned_tape_release>:
    5f20:	b4000940 	cbz	x0, 6048 <fwp_owned_tape_release+0x128>
    5f24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f28:	910003fd 	mov	x29, sp
    5f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5f30:	aa0003f3 	mov	x19, x0
    5f34:	f9400000 	ldr	x0, [x0]
    5f38:	b4000060 	cbz	x0, 5f44 <fwp_owned_tape_release+0x24>
    5f3c:	f9400661 	ldr	x1, [x19, #8]
    5f40:	f9000401 	str	x1, [x0, #8]
    5f44:	f9400661 	ldr	x1, [x19, #8]
    5f48:	b4000041 	cbz	x1, 5f50 <fwp_owned_tape_release+0x30>
    5f4c:	f9000020 	str	x0, [x1]
    5f50:	f9400a60 	ldr	x0, [x19, #16]
    5f54:	f9403401 	ldr	x1, [x0, #104]
    5f58:	b40005c1 	cbz	x1, 6010 <fwp_owned_tape_release+0xf0>
    5f5c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5f60:	eb00005f 	cmp	x2, x0
    5f64:	540002ed 	b.le	5fc0 <fwp_owned_tape_release+0xa0>
    5f68:	d2800014 	mov	x20, #0x0                   	// #0
    5f6c:	f90013f5 	str	x21, [sp, #32]
    5f70:	d2800015 	mov	x21, #0x0                   	// #0
    5f74:	d503201f 	nop
    5f78:	f9402260 	ldr	x0, [x19, #64]
    5f7c:	910006b5 	add	x21, x21, #0x1
    5f80:	f8746800 	ldr	x0, [x0, x20]
    5f84:	d63f0020 	blr	x1
    5f88:	f9402260 	ldr	x0, [x19, #64]
    5f8c:	f9400a61 	ldr	x1, [x19, #16]
    5f90:	8b140000 	add	x0, x0, x20
    5f94:	91004294 	add	x20, x20, #0x10
    5f98:	f9400400 	ldr	x0, [x0, #8]
    5f9c:	f9403421 	ldr	x1, [x1, #104]
    5fa0:	d63f0020 	blr	x1
    5fa4:	a9450261 	ldp	x1, x0, [x19, #80]
    5fa8:	cb010000 	sub	x0, x0, x1
    5fac:	eb15001f 	cmp	x0, x21
    5fb0:	f9400a60 	ldr	x0, [x19, #16]
    5fb4:	f9403401 	ldr	x1, [x0, #104]
    5fb8:	54fffe0c 	b.gt	5f78 <fwp_owned_tape_release+0x58>
    5fbc:	f94013f5 	ldr	x21, [sp, #32]
    5fc0:	f9403663 	ldr	x3, [x19, #104]
    5fc4:	f9401262 	ldr	x2, [x19, #32]
    5fc8:	f100007f 	cmp	x3, #0x0
    5fcc:	540001ed 	b.le	6008 <fwp_owned_tape_release+0xe8>
    5fd0:	d2800014 	mov	x20, #0x0                   	// #0
    5fd4:	d503201f 	nop
    5fd8:	f9402660 	ldr	x0, [x19, #72]
    5fdc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5fe0:	eb02001f 	cmp	x0, x2
    5fe4:	540000c0 	b.eq	5ffc <fwp_owned_tape_release+0xdc>  // b.none
    5fe8:	d63f0020 	blr	x1
    5fec:	f9400a60 	ldr	x0, [x19, #16]
    5ff0:	f9401262 	ldr	x2, [x19, #32]
    5ff4:	f9403663 	ldr	x3, [x19, #104]
    5ff8:	f9403401 	ldr	x1, [x0, #104]
    5ffc:	91000694 	add	x20, x20, #0x1
    6000:	eb14007f 	cmp	x3, x20
    6004:	54fffeac 	b.gt	5fd8 <fwp_owned_tape_release+0xb8>
    6008:	aa0203e0 	mov	x0, x2
    600c:	d63f0020 	blr	x1
    6010:	f9401660 	ldr	x0, [x19, #40]
    6014:	97ffff6f 	bl	5dd0 <fwp_closure_drop>
    6018:	f9401a60 	ldr	x0, [x19, #48]
    601c:	97ffff6d 	bl	5dd0 <fwp_closure_drop>
    6020:	f9401e60 	ldr	x0, [x19, #56]
    6024:	97ffff6b 	bl	5dd0 <fwp_closure_drop>
    6028:	f9402260 	ldr	x0, [x19, #64]
    602c:	97fffab1 	bl	4af0 <fwp_mem_free>
    6030:	f9402660 	ldr	x0, [x19, #72]
    6034:	97fffaaf 	bl	4af0 <fwp_mem_free>
    6038:	aa1303e0 	mov	x0, x19
    603c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6040:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6044:	17fffaab 	b	4af0 <fwp_mem_free>
    6048:	d65f03c0 	ret
    604c:	d503201f 	nop

0000000000006050 <fwp_tape_finish>:
    6050:	d10203ff 	sub	sp, sp, #0x80
    6054:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6058:	f947f421 	ldr	x1, [x1, #4072]
    605c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6060:	910103fd 	add	x29, sp, #0x40
    6064:	a90553f3 	stp	x19, x20, [sp, #80]
    6068:	a9065bf5 	stp	x21, x22, [sp, #96]
    606c:	a90763f7 	stp	x23, x24, [sp, #112]
    6070:	d00000d8 	adrp	x24, 20000 <__data_start>
    6074:	9101c316 	add	x22, x24, #0x70
    6078:	f9400022 	ldr	x2, [x1]
    607c:	f9001fe2 	str	x2, [sp, #56]
    6080:	d2800002 	mov	x2, #0x0                   	// #0
    6084:	910262c0 	add	x0, x22, #0x98
    6088:	97fff51e 	bl	3500 <fwp_tape_buffers_dispose>
    608c:	f9006adf 	str	xzr, [x22, #208]
    6090:	f9404ac0 	ldr	x0, [x22, #144]
    6094:	f100001f 	cmp	x0, #0x0
    6098:	5400030d 	b.le	60f8 <fwp_tape_finish+0xa8>
    609c:	910003f7 	mov	x23, sp
    60a0:	d2800015 	mov	x21, #0x0                   	// #0
    60a4:	d2800014 	mov	x20, #0x0                   	// #0
    60a8:	f94002d3 	ldr	x19, [x22]
    60ac:	91000694 	add	x20, x20, #0x1
    60b0:	8b150273 	add	x19, x19, x21
    60b4:	9101a2b5 	add	x21, x21, #0x68
    60b8:	aa1303e0 	mov	x0, x19
    60bc:	97fff3d5 	bl	3010 <fwp_tape_unlink_scope>
    60c0:	aa1703e0 	mov	x0, x23
    60c4:	f9401261 	ldr	x1, [x19, #32]
    60c8:	f90003e1 	str	x1, [sp]
    60cc:	f9401a62 	ldr	x2, [x19, #48]
    60d0:	f9000be2 	str	x2, [sp, #16]
    60d4:	f9402261 	ldr	x1, [x19, #64]
    60d8:	f90013e1 	str	x1, [sp, #32]
    60dc:	97fff509 	bl	3500 <fwp_tape_buffers_dispose>
    60e0:	f9403260 	ldr	x0, [x19, #96]
    60e4:	97ffff8f 	bl	5f20 <fwp_owned_tape_release>
    60e8:	f900327f 	str	xzr, [x19, #96]
    60ec:	f9404ac0 	ldr	x0, [x22, #144]
    60f0:	eb14001f 	cmp	x0, x20
    60f4:	54fffdac 	b.gt	60a8 <fwp_tape_finish+0x58>
    60f8:	f9403b00 	ldr	x0, [x24, #112]
    60fc:	9101c313 	add	x19, x24, #0x70
    6100:	97fff234 	bl	29d0 <free@plt>
    6104:	f9003b1f 	str	xzr, [x24, #112]
    6108:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    610c:	f947f400 	ldr	x0, [x0, #4072]
    6110:	f9004a7f 	str	xzr, [x19, #144]
    6114:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6118:	f9401fe2 	ldr	x2, [sp, #56]
    611c:	f9400001 	ldr	x1, [x0]
    6120:	eb010042 	subs	x2, x2, x1
    6124:	d2800001 	mov	x1, #0x0                   	// #0
    6128:	540000e1 	b.ne	6144 <fwp_tape_finish+0xf4>  // b.any
    612c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6130:	a94553f3 	ldp	x19, x20, [sp, #80]
    6134:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6138:	a94763f7 	ldp	x23, x24, [sp, #112]
    613c:	910203ff 	add	sp, sp, #0x80
    6140:	d65f03c0 	ret
    6144:	97fff1f3 	bl	2910 <__stack_chk_fail@plt>
    6148:	d503201f 	nop
    614c:	d503201f 	nop

0000000000006150 <fwp_tape_scope_release>:
    6150:	d10243ff 	sub	sp, sp, #0x90
    6154:	a9047bfd 	stp	x29, x30, [sp, #64]
    6158:	910103fd 	add	x29, sp, #0x40
    615c:	a90553f3 	stp	x19, x20, [sp, #80]
    6160:	aa0003f4 	mov	x20, x0
    6164:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6168:	f947f400 	ldr	x0, [x0, #4072]
    616c:	b9400285 	ldr	w5, [x20]
    6170:	f9400001 	ldr	x1, [x0]
    6174:	f9001fe1 	str	x1, [sp, #56]
    6178:	d2800001 	mov	x1, #0x0                   	// #0
    617c:	37f806c5 	tbnz	w5, #31, 6254 <fwp_tape_scope_release+0x104>
    6180:	a90763f7 	stp	x23, x24, [sp, #112]
    6184:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6188:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    618c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6190:	d00000d3 	adrp	x19, 20000 <__data_start>
    6194:	910003f7 	mov	x23, sp
    6198:	9101c273 	add	x19, x19, #0x70
    619c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    61a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    61a4:	52800d16 	mov	w22, #0x68                  	// #104
    61a8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    61ac:	f90043f9 	str	x25, [sp, #128]
    61b0:	14000006 	b	61c8 <fwp_tape_scope_release+0x78>
    61b4:	97fff4d3 	bl	3500 <fwp_tape_buffers_dispose>
    61b8:	aa1903e0 	mov	x0, x25
    61bc:	97ffff59 	bl	5f20 <fwp_owned_tape_release>
    61c0:	b9400285 	ldr	w5, [x20]
    61c4:	37f80425 	tbnz	w5, #31, 6248 <fwp_tape_scope_release+0xf8>
    61c8:	f9400266 	ldr	x6, [x19]
    61cc:	9b367ca5 	smull	x5, w5, w22
    61d0:	8b0500c0 	add	x0, x6, x5
    61d4:	97fff38f 	bl	3010 <fwp_tape_unlink_scope>
    61d8:	ad410001 	ldp	q1, q0, [x0, #32]
    61dc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    61e0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    61e4:	f9400c03 	ldr	x3, [x0, #24]
    61e8:	ad0003e1 	stp	q1, q0, [sp]
    61ec:	b86568c1 	ldr	w1, [x6, x5]
    61f0:	a9440804 	ldp	x4, x2, [x0, #64]
    61f4:	b900041f 	str	wzr, [x0, #4]
    61f8:	f9403019 	ldr	x25, [x0, #96]
    61fc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6200:	f9000c1f 	str	xzr, [x0, #24]
    6204:	a9020fe4 	stp	x4, x3, [sp, #32]
    6208:	f9001be2 	str	x2, [sp, #48]
    620c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6210:	f900301f 	str	xzr, [x0, #96]
    6214:	6b15003f 	cmp	w1, w21
    6218:	540000e8 	b.hi	6234 <fwp_tape_scope_release+0xe4>  // b.pmore
    621c:	9343fca5 	asr	x5, x5, #3
    6220:	f9407660 	ldr	x0, [x19, #232]
    6224:	9b187ca5 	mul	x5, x5, x24
    6228:	eb0000bf 	cmp	x5, x0
    622c:	5400004a 	b.ge	6234 <fwp_tape_scope_release+0xe4>  // b.tcont
    6230:	f9007665 	str	x5, [x19, #232]
    6234:	aa1703e0 	mov	x0, x23
    6238:	b5fffbf9 	cbnz	x25, 61b4 <fwp_tape_scope_release+0x64>
    623c:	97fff871 	bl	4400 <fwp_tape_buffers_release>
    6240:	b9400285 	ldr	w5, [x20]
    6244:	36fffc25 	tbz	w5, #31, 61c8 <fwp_tape_scope_release+0x78>
    6248:	a9465bf5 	ldp	x21, x22, [sp, #96]
    624c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6250:	f94043f9 	ldr	x25, [sp, #128]
    6254:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6258:	f947f400 	ldr	x0, [x0, #4072]
    625c:	f9401fe2 	ldr	x2, [sp, #56]
    6260:	f9400001 	ldr	x1, [x0]
    6264:	eb010042 	subs	x2, x2, x1
    6268:	d2800001 	mov	x1, #0x0                   	// #0
    626c:	540000a1 	b.ne	6280 <fwp_tape_scope_release+0x130>  // b.any
    6270:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6274:	a94553f3 	ldp	x19, x20, [sp, #80]
    6278:	910243ff 	add	sp, sp, #0x90
    627c:	d65f03c0 	ret
    6280:	a9065bf5 	stp	x21, x22, [sp, #96]
    6284:	a90763f7 	stp	x23, x24, [sp, #112]
    6288:	f90043f9 	str	x25, [sp, #128]
    628c:	97fff1a1 	bl	2910 <__stack_chk_fail@plt>

0000000000006290 <fwp_drop4>:
    6290:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6294:	910003fd 	mov	x29, sp
    6298:	a9025bf5 	stp	x21, x22, [sp, #32]
    629c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    62a0:	911742d5 	add	x21, x22, #0x5d0
    62a4:	a90153f3 	stp	x19, x20, [sp, #16]
    62a8:	aa0003f3 	mov	x19, x0
    62ac:	f949daa1 	ldr	x1, [x21, #5040]
    62b0:	f949eea0 	ldr	x0, [x21, #5080]
    62b4:	cb010261 	sub	x1, x19, x1
    62b8:	eb00403f 	cmp	x1, x0, lsl #16
    62bc:	54000382 	b.cs	632c <fwp_drop4+0x9c>  // b.hs, b.nlast
    62c0:	d350fc22 	lsr	x2, x1, #16
    62c4:	f949fea3 	ldr	x3, [x21, #5112]
    62c8:	8b020842 	add	x2, x2, x2, lsl #2
    62cc:	d37df042 	lsl	x2, x2, #3
    62d0:	8b020060 	add	x0, x3, x2
    62d4:	f9401014 	ldr	x20, [x0, #32]
    62d8:	b40002b4 	cbz	x20, 632c <fwp_drop4+0x9c>
    62dc:	38626862 	ldrb	w2, [x3, x2]
    62e0:	7100085f 	cmp	w2, #0x2
    62e4:	540002c0 	b.eq	633c <fwp_drop4+0xac>  // b.none
    62e8:	7100045f 	cmp	w2, #0x1
    62ec:	54000201 	b.ne	632c <fwp_drop4+0x9c>  // b.any
    62f0:	29430002 	ldp	w2, w0, [x0, #24]
    62f4:	92403c21 	and	x1, x1, #0xffff
    62f8:	9b027c21 	mul	x1, x1, x2
    62fc:	d360fc21 	lsr	x1, x1, #32
    6300:	eb00003f 	cmp	x1, x0
    6304:	54000142 	b.cs	632c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6308:	8b010294 	add	x20, x20, x1
    630c:	39400280 	ldrb	w0, [x20]
    6310:	340000e0 	cbz	w0, 632c <fwp_drop4+0x9c>
    6314:	7100041f 	cmp	w0, #0x1
    6318:	540001e0 	b.eq	6354 <fwp_drop4+0xc4>  // b.none
    631c:	7103fc1f 	cmp	w0, #0xff
    6320:	540007c0 	b.eq	6418 <fwp_drop4+0x188>  // b.none
    6324:	51000400 	sub	w0, w0, #0x1
    6328:	39000280 	strb	w0, [x20]
    632c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6330:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6334:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6338:	d65f03c0 	ret
    633c:	72003c3f 	tst	w1, #0xffff
    6340:	54fffe60 	b.eq	630c <fwp_drop4+0x7c>  // b.none
    6344:	a94153f3 	ldp	x19, x20, [sp, #16]
    6348:	a9425bf5 	ldp	x21, x22, [sp, #32]
    634c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6350:	d65f03c0 	ret
    6354:	911742c2 	add	x2, x22, #0x5d0
    6358:	f9400660 	ldr	x0, [x19, #8]
    635c:	f949d841 	ldr	x1, [x2, #5040]
    6360:	f949ec42 	ldr	x2, [x2, #5080]
    6364:	cb010001 	sub	x1, x0, x1
    6368:	eb02403f 	cmp	x1, x2, lsl #16
    636c:	54000362 	b.cs	63d8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6370:	d350fc22 	lsr	x2, x1, #16
    6374:	8b020842 	add	x2, x2, x2, lsl #2
    6378:	d37df042 	lsl	x2, x2, #3
    637c:	8b020064 	add	x4, x3, x2
    6380:	f9401094 	ldr	x20, [x4, #32]
    6384:	b40002b4 	cbz	x20, 63d8 <fwp_drop4+0x148>
    6388:	38626862 	ldrb	w2, [x3, x2]
    638c:	7100085f 	cmp	w2, #0x2
    6390:	540003e0 	b.eq	640c <fwp_drop4+0x17c>  // b.none
    6394:	7100045f 	cmp	w2, #0x1
    6398:	54000201 	b.ne	63d8 <fwp_drop4+0x148>  // b.any
    639c:	29430883 	ldp	w3, w2, [x4, #24]
    63a0:	92403c21 	and	x1, x1, #0xffff
    63a4:	9b037c21 	mul	x1, x1, x3
    63a8:	d360fc21 	lsr	x1, x1, #32
    63ac:	eb02003f 	cmp	x1, x2
    63b0:	54000142 	b.cs	63d8 <fwp_drop4+0x148>  // b.hs, b.nlast
    63b4:	8b010294 	add	x20, x20, x1
    63b8:	39400281 	ldrb	w1, [x20]
    63bc:	340000e1 	cbz	w1, 63d8 <fwp_drop4+0x148>
    63c0:	7100043f 	cmp	w1, #0x1
    63c4:	54000200 	b.eq	6404 <fwp_drop4+0x174>  // b.none
    63c8:	7103fc3f 	cmp	w1, #0xff
    63cc:	54000580 	b.eq	647c <fwp_drop4+0x1ec>  // b.none
    63d0:	51000421 	sub	w1, w1, #0x1
    63d4:	39000281 	strb	w1, [x20]
    63d8:	f9400a74 	ldr	x20, [x19, #16]
    63dc:	aa1303e0 	mov	x0, x19
    63e0:	97fffd00 	bl	57e0 <fwp_rc_free_arr>
    63e4:	911742c0 	add	x0, x22, #0x5d0
    63e8:	f949d801 	ldr	x1, [x0, #5040]
    63ec:	f949ec00 	ldr	x0, [x0, #5080]
    63f0:	cb010281 	sub	x1, x20, x1
    63f4:	eb00403f 	cmp	x1, x0, lsl #16
    63f8:	54fff9a2 	b.cs	632c <fwp_drop4+0x9c>  // b.hs, b.nlast
    63fc:	aa1403f3 	mov	x19, x20
    6400:	17ffffb0 	b	62c0 <fwp_drop4+0x30>
    6404:	97fffcf7 	bl	57e0 <fwp_rc_free_arr>
    6408:	17fffff4 	b	63d8 <fwp_drop4+0x148>
    640c:	72003c3f 	tst	w1, #0xffff
    6410:	54fffe41 	b.ne	63d8 <fwp_drop4+0x148>  // b.any
    6414:	17ffffe9 	b	63b8 <fwp_drop4+0x128>
    6418:	ca544681 	eor	x1, x20, x20, lsr #17
    641c:	911742c0 	add	x0, x22, #0x5d0
    6420:	ca412421 	eor	x1, x1, x1, lsr #9
    6424:	8b210c01 	add	x1, x0, w1, uxtb #3
    6428:	f94a2420 	ldr	x0, [x1, #5192]
    642c:	b5000080 	cbnz	x0, 643c <fwp_drop4+0x1ac>
    6430:	14000010 	b	6470 <fwp_drop4+0x1e0>
    6434:	f9400800 	ldr	x0, [x0, #16]
    6438:	b40001c0 	cbz	x0, 6470 <fwp_drop4+0x1e0>
    643c:	f9400001 	ldr	x1, [x0]
    6440:	eb14003f 	cmp	x1, x20
    6444:	54ffff81 	b.ne	6434 <fwp_drop4+0x1a4>  // b.any
    6448:	f9400401 	ldr	x1, [x0, #8]
    644c:	d1000421 	sub	x1, x1, #0x1
    6450:	f9000401 	str	x1, [x0, #8]
    6454:	f103f83f 	cmp	x1, #0xfe
    6458:	54fff6a1 	b.ne	632c <fwp_drop4+0x9c>  // b.any
    645c:	aa1403e0 	mov	x0, x20
    6460:	97fff904 	bl	4870 <fwp_rc_forget_slot>
    6464:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6468:	39000280 	strb	w0, [x20]
    646c:	17ffffb0 	b	632c <fwp_drop4+0x9c>
    6470:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    6474:	913b8000 	add	x0, x0, #0xee0
    6478:	97fff502 	bl	3880 <fwp_trap>
    647c:	ca544680 	eor	x0, x20, x20, lsr #17
    6480:	911742c1 	add	x1, x22, #0x5d0
    6484:	ca402400 	eor	x0, x0, x0, lsr #9
    6488:	8b200c20 	add	x0, x1, w0, uxtb #3
    648c:	f94a2400 	ldr	x0, [x0, #5192]
    6490:	b5000080 	cbnz	x0, 64a0 <fwp_drop4+0x210>
    6494:	17fffff7 	b	6470 <fwp_drop4+0x1e0>
    6498:	f9400800 	ldr	x0, [x0, #16]
    649c:	b4fffea0 	cbz	x0, 6470 <fwp_drop4+0x1e0>
    64a0:	f9400001 	ldr	x1, [x0]
    64a4:	eb14003f 	cmp	x1, x20
    64a8:	54ffff81 	b.ne	6498 <fwp_drop4+0x208>  // b.any
    64ac:	f9400401 	ldr	x1, [x0, #8]
    64b0:	d1000421 	sub	x1, x1, #0x1
    64b4:	f9000401 	str	x1, [x0, #8]
    64b8:	f103f83f 	cmp	x1, #0xfe
    64bc:	54fff8e1 	b.ne	63d8 <fwp_drop4+0x148>  // b.any
    64c0:	aa1403e0 	mov	x0, x20
    64c4:	97fff8eb 	bl	4870 <fwp_rc_forget_slot>
    64c8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64cc:	39000280 	strb	w0, [x20]
    64d0:	17ffffc2 	b	63d8 <fwp_drop4+0x148>

00000000000064d4 <fwp_arg_drop37>:
    64d4:	7100003f 	cmp	w1, #0x0
    64d8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    64dc:	54000041 	b.ne	64e4 <fwp_arg_drop37+0x10>  // b.any
    64e0:	d65f03c0 	ret
    64e4:	f9400000 	ldr	x0, [x0]
    64e8:	17ffff6a 	b	6290 <fwp_drop4>
    64ec:	d503201f 	nop

00000000000064f0 <fwp_task_dispose>:
    64f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64f4:	910003fd 	mov	x29, sp
    64f8:	f9000bf3 	str	x19, [sp, #16]
    64fc:	aa0003f3 	mov	x19, x0
    6500:	39414000 	ldrb	w0, [x0, #80]
    6504:	36000720 	tbz	w0, #0, 65e8 <fwp_task_dispose+0xf8>
    6508:	f9400a60 	ldr	x0, [x19, #16]
    650c:	b50006e0 	cbnz	x0, 65e8 <fwp_task_dispose+0xf8>
    6510:	a9478660 	ldp	x0, x1, [x19, #120]
    6514:	39014e7f 	strb	wzr, [x19, #83]
    6518:	f9003e7f 	str	xzr, [x19, #120]
    651c:	f100003f 	cmp	x1, #0x0
    6520:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6524:	54000040 	b.eq	652c <fwp_task_dispose+0x3c>  // b.none
    6528:	d63f0020 	blr	x1
    652c:	f9405660 	ldr	x0, [x19, #168]
    6530:	97fff970 	bl	4af0 <fwp_mem_free>
    6534:	f900567f 	str	xzr, [x19, #168]
    6538:	b9405e60 	ldr	w0, [x19, #92]
    653c:	7100041f 	cmp	w0, #0x1
    6540:	54000420 	b.eq	65c4 <fwp_task_dispose+0xd4>  // b.none
    6544:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6548:	91174042 	add	x2, x2, #0x5d0
    654c:	f949d840 	ldr	x0, [x2, #5040]
    6550:	f949ec41 	ldr	x1, [x2, #5080]
    6554:	cb000260 	sub	x0, x19, x0
    6558:	eb01401f 	cmp	x0, x1, lsl #16
    655c:	540002e2 	b.cs	65b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6560:	d350fc01 	lsr	x1, x0, #16
    6564:	f949fc44 	ldr	x4, [x2, #5112]
    6568:	8b010821 	add	x1, x1, x1, lsl #2
    656c:	d37df021 	lsl	x1, x1, #3
    6570:	8b010083 	add	x3, x4, x1
    6574:	f9401062 	ldr	x2, [x3, #32]
    6578:	b4000202 	cbz	x2, 65b8 <fwp_task_dispose+0xc8>
    657c:	38616881 	ldrb	w1, [x4, x1]
    6580:	7100083f 	cmp	w1, #0x2
    6584:	54000280 	b.eq	65d4 <fwp_task_dispose+0xe4>  // b.none
    6588:	7100043f 	cmp	w1, #0x1
    658c:	54000161 	b.ne	65b8 <fwp_task_dispose+0xc8>  // b.any
    6590:	29430464 	ldp	w4, w1, [x3, #24]
    6594:	92403c00 	and	x0, x0, #0xffff
    6598:	9b047c00 	mul	x0, x0, x4
    659c:	d360fc00 	lsr	x0, x0, #32
    65a0:	eb01001f 	cmp	x0, x1
    65a4:	540000a2 	b.cs	65b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65a8:	8b000042 	add	x2, x2, x0
    65ac:	39400040 	ldrb	w0, [x2]
    65b0:	7100041f 	cmp	w0, #0x1
    65b4:	54000080 	b.eq	65c4 <fwp_task_dispose+0xd4>  // b.none
    65b8:	f9400bf3 	ldr	x19, [sp, #16]
    65bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65c0:	d65f03c0 	ret
    65c4:	aa1303e0 	mov	x0, x19
    65c8:	f9400bf3 	ldr	x19, [sp, #16]
    65cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65d0:	17fff948 	b	4af0 <fwp_mem_free>
    65d4:	72003c1f 	tst	w0, #0xffff
    65d8:	54fffea0 	b.eq	65ac <fwp_task_dispose+0xbc>  // b.none
    65dc:	f9400bf3 	ldr	x19, [sp, #16]
    65e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65e4:	d65f03c0 	ret
    65e8:	97fff0de 	bl	2960 <abort@plt>
    65ec:	d503201f 	nop

00000000000065f0 <fwp_free_zombie>:
    65f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65f4:	910003fd 	mov	x29, sp
    65f8:	a90153f3 	stp	x19, x20, [sp, #16]
    65fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6600:	9101c281 	add	x1, x20, #0x70
    6604:	f9407833 	ldr	x19, [x1, #240]
    6608:	b4000333 	cbz	x19, 666c <fwp_free_zombie+0x7c>
    660c:	f9400820 	ldr	x0, [x1, #16]
    6610:	eb00027f 	cmp	x19, x0
    6614:	540002c0 	b.eq	666c <fwp_free_zombie+0x7c>  // b.none
    6618:	b940f822 	ldr	w2, [x1, #248]
    661c:	f9400a60 	ldr	x0, [x19, #16]
    6620:	7100fc5f 	cmp	w2, #0x3f
    6624:	5400078c 	b.gt	6714 <fwp_free_zombie+0x124>
    6628:	91040023 	add	x3, x1, #0x100
    662c:	11000444 	add	w4, w2, #0x1
    6630:	b900f824 	str	w4, [x1, #248]
    6634:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6638:	f822d860 	str	x0, [x3, w2, sxtw #3]
    663c:	a9530261 	ldp	x1, x0, [x19, #304]
    6640:	b4000741 	cbz	x1, 6728 <fwp_free_zombie+0x138>
    6644:	f9009c20 	str	x0, [x1, #312]
    6648:	b4000040 	cbz	x0, 6650 <fwp_free_zombie+0x60>
    664c:	f9009801 	str	x1, [x0, #304]
    6650:	9101c294 	add	x20, x20, #0x70
    6654:	b9405e60 	ldr	w0, [x19, #92]
    6658:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    665c:	f9007a9f 	str	xzr, [x20, #240]
    6660:	34000140 	cbz	w0, 6688 <fwp_free_zombie+0x98>
    6664:	7100041f 	cmp	w0, #0x1
    6668:	54000080 	b.eq	6678 <fwp_free_zombie+0x88>  // b.none
    666c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6670:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6674:	d65f03c0 	ret
    6678:	aa1303e0 	mov	x0, x19
    667c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6680:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6684:	17ffff9b 	b	64f0 <fwp_task_dispose>
    6688:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    668c:	91174082 	add	x2, x4, #0x5d0
    6690:	f949d841 	ldr	x1, [x2, #5040]
    6694:	f949ec40 	ldr	x0, [x2, #5080]
    6698:	cb010261 	sub	x1, x19, x1
    669c:	eb00403f 	cmp	x1, x0, lsl #16
    66a0:	54fffe62 	b.cs	666c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    66a4:	d350fc20 	lsr	x0, x1, #16
    66a8:	f949fc43 	ldr	x3, [x2, #5112]
    66ac:	8b000800 	add	x0, x0, x0, lsl #2
    66b0:	d37df000 	lsl	x0, x0, #3
    66b4:	8b000062 	add	x2, x3, x0
    66b8:	f9401054 	ldr	x20, [x2, #32]
    66bc:	b4fffd94 	cbz	x20, 666c <fwp_free_zombie+0x7c>
    66c0:	38606860 	ldrb	w0, [x3, x0]
    66c4:	7100081f 	cmp	w0, #0x2
    66c8:	54000360 	b.eq	6734 <fwp_free_zombie+0x144>  // b.none
    66cc:	7100041f 	cmp	w0, #0x1
    66d0:	54fffce1 	b.ne	666c <fwp_free_zombie+0x7c>  // b.any
    66d4:	29430043 	ldp	w3, w0, [x2, #24]
    66d8:	92403c21 	and	x1, x1, #0xffff
    66dc:	9b037c21 	mul	x1, x1, x3
    66e0:	d360fc21 	lsr	x1, x1, #32
    66e4:	eb00003f 	cmp	x1, x0
    66e8:	54fffc22 	b.cs	666c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    66ec:	8b010294 	add	x20, x20, x1
    66f0:	39400280 	ldrb	w0, [x20]
    66f4:	34fffbc0 	cbz	w0, 666c <fwp_free_zombie+0x7c>
    66f8:	7100041f 	cmp	w0, #0x1
    66fc:	54fffbe0 	b.eq	6678 <fwp_free_zombie+0x88>  // b.none
    6700:	7103fc1f 	cmp	w0, #0xff
    6704:	540001e0 	b.eq	6740 <fwp_free_zombie+0x150>  // b.none
    6708:	51000400 	sub	w0, w0, #0x1
    670c:	39000280 	strb	w0, [x20]
    6710:	17ffffd7 	b	666c <fwp_free_zombie+0x7c>
    6714:	f9400e61 	ldr	x1, [x19, #24]
    6718:	97fff0c6 	bl	2a30 <munmap@plt>
    671c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6720:	a9530261 	ldp	x1, x0, [x19, #304]
    6724:	b5fff901 	cbnz	x1, 6644 <fwp_free_zombie+0x54>
    6728:	9101c282 	add	x2, x20, #0x70
    672c:	f9018040 	str	x0, [x2, #768]
    6730:	17ffffc6 	b	6648 <fwp_free_zombie+0x58>
    6734:	72003c3f 	tst	w1, #0xffff
    6738:	54fff9a1 	b.ne	666c <fwp_free_zombie+0x7c>  // b.any
    673c:	17ffffed 	b	66f0 <fwp_free_zombie+0x100>
    6740:	ca544680 	eor	x0, x20, x20, lsr #17
    6744:	91174084 	add	x4, x4, #0x5d0
    6748:	ca402400 	eor	x0, x0, x0, lsr #9
    674c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6750:	f94a2400 	ldr	x0, [x0, #5192]
    6754:	b5000080 	cbnz	x0, 6764 <fwp_free_zombie+0x174>
    6758:	14000010 	b	6798 <fwp_free_zombie+0x1a8>
    675c:	f9400800 	ldr	x0, [x0, #16]
    6760:	b40001c0 	cbz	x0, 6798 <fwp_free_zombie+0x1a8>
    6764:	f9400001 	ldr	x1, [x0]
    6768:	eb14003f 	cmp	x1, x20
    676c:	54ffff81 	b.ne	675c <fwp_free_zombie+0x16c>  // b.any
    6770:	f9400401 	ldr	x1, [x0, #8]
    6774:	d1000421 	sub	x1, x1, #0x1
    6778:	f9000401 	str	x1, [x0, #8]
    677c:	f103f83f 	cmp	x1, #0xfe
    6780:	54fff761 	b.ne	666c <fwp_free_zombie+0x7c>  // b.any
    6784:	aa1403e0 	mov	x0, x20
    6788:	97fff83a 	bl	4870 <fwp_rc_forget_slot>
    678c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6790:	39000280 	strb	w0, [x20]
    6794:	17ffffb6 	b	666c <fwp_free_zombie+0x7c>
    6798:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    679c:	913b8000 	add	x0, x0, #0xee0
    67a0:	97fff438 	bl	3880 <fwp_trap>

00000000000067a4 <fwp_block>:
    67a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67a8:	910003fd 	mov	x29, sp
    67ac:	a90153f3 	stp	x19, x20, [sp, #16]
    67b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    67b4:	9101c274 	add	x20, x19, #0x70
    67b8:	f9404282 	ldr	x2, [x20, #128]
    67bc:	b4000622 	cbz	x2, 6880 <fwp_block+0xdc>
    67c0:	9101c261 	add	x1, x19, #0x70
    67c4:	f9408040 	ldr	x0, [x2, #256]
    67c8:	f9004020 	str	x0, [x1, #128]
    67cc:	b4000680 	cbz	x0, 689c <fwp_block+0xf8>
    67d0:	9101c263 	add	x3, x19, #0x70
    67d4:	3901505f 	strb	wzr, [x2, #84]
    67d8:	f9400864 	ldr	x4, [x3, #16]
    67dc:	eb02009f 	cmp	x4, x2
    67e0:	54000440 	b.eq	6868 <fwp_block+0xc4>  // b.none
    67e4:	f9418465 	ldr	x5, [x3, #776]
    67e8:	f9000862 	str	x2, [x3, #16]
    67ec:	f9400441 	ldr	x1, [x2, #8]
    67f0:	f9004885 	str	x5, [x4, #144]
    67f4:	f9418865 	ldr	x5, [x3, #784]
    67f8:	f9004c85 	str	x5, [x4, #152]
    67fc:	f9418c65 	ldr	x5, [x3, #792]
    6800:	f9005085 	str	x5, [x4, #160]
    6804:	f9419065 	ldr	x5, [x3, #800]
    6808:	f9005485 	str	x5, [x4, #168]
    680c:	f9419465 	ldr	x5, [x3, #808]
    6810:	f9005885 	str	x5, [x4, #176]
    6814:	f9419865 	ldr	x5, [x3, #816]
    6818:	f9005c85 	str	x5, [x4, #184]
    681c:	f9419c65 	ldr	x5, [x3, #824]
    6820:	f9006085 	str	x5, [x4, #192]
    6824:	f9400480 	ldr	x0, [x4, #8]
    6828:	f9404844 	ldr	x4, [x2, #144]
    682c:	f9018464 	str	x4, [x3, #776]
    6830:	f9404c44 	ldr	x4, [x2, #152]
    6834:	f9018864 	str	x4, [x3, #784]
    6838:	f9405044 	ldr	x4, [x2, #160]
    683c:	f9018c64 	str	x4, [x3, #792]
    6840:	f9405444 	ldr	x4, [x2, #168]
    6844:	f9019064 	str	x4, [x3, #800]
    6848:	f9405844 	ldr	x4, [x2, #176]
    684c:	f9019464 	str	x4, [x3, #808]
    6850:	a94b8844 	ldp	x4, x2, [x2, #184]
    6854:	f9019864 	str	x4, [x3, #816]
    6858:	f9019c62 	str	x2, [x3, #824]
    685c:	97fff045 	bl	2970 <swapcontext@plt>
    6860:	97ffff64 	bl	65f0 <fwp_free_zombie>
    6864:	d503201f 	nop
    6868:	9101c260 	add	x0, x19, #0x70
    686c:	b9434000 	ldr	w0, [x0, #832]
    6870:	340001a0 	cbz	w0, 68a4 <fwp_block+0x100>
    6874:	a94153f3 	ldp	x19, x20, [sp, #16]
    6878:	a8c27bfd 	ldp	x29, x30, [sp], #32
    687c:	d65f03c0 	ret
    6880:	97fff728 	bl	4520 <fwp_poll_events>
    6884:	f9404282 	ldr	x2, [x20, #128]
    6888:	b4ffffc2 	cbz	x2, 6880 <fwp_block+0xdc>
    688c:	9101c261 	add	x1, x19, #0x70
    6890:	f9408040 	ldr	x0, [x2, #256]
    6894:	f9004020 	str	x0, [x1, #128]
    6898:	b5fff9c0 	cbnz	x0, 67d0 <fwp_block+0x2c>
    689c:	f9003c3f 	str	xzr, [x1, #120]
    68a0:	17ffffcc 	b	67d0 <fwp_block+0x2c>
    68a4:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x480>
    68a8:	91004000 	add	x0, x0, #0x10
    68ac:	97fff07d 	bl	2aa0 <getenv@plt>
    68b0:	5284e202 	mov	w2, #0x2710                	// #10000
    68b4:	b4000060 	cbz	x0, 68c0 <fwp_block+0x11c>
    68b8:	39400001 	ldrb	w1, [x0]
    68bc:	350000c1 	cbnz	w1, 68d4 <fwp_block+0x130>
    68c0:	9101c273 	add	x19, x19, #0x70
    68c4:	b9034262 	str	w2, [x19, #832]
    68c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    68cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68d0:	d65f03c0 	ret
    68d4:	52800142 	mov	w2, #0xa                   	// #10
    68d8:	d2800001 	mov	x1, #0x0                   	// #0
    68dc:	97ffefc1 	bl	27e0 <strtoll@plt>
    68e0:	d1000403 	sub	x3, x0, #0x1
    68e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    68e8:	eb02007f 	cmp	x3, x2
    68ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    68f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    68f4:	17fffff3 	b	68c0 <fwp_block+0x11c>
    68f8:	d503201f 	nop
    68fc:	d503201f 	nop

0000000000006900 <fwp_drop10>:
    6900:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6904:	910003fd 	mov	x29, sp
    6908:	a90153f3 	stp	x19, x20, [sp, #16]
    690c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6910:	f90013f5 	str	x21, [sp, #32]
    6914:	91174275 	add	x21, x19, #0x5d0
    6918:	f949daa1 	ldr	x1, [x21, #5040]
    691c:	f949eea2 	ldr	x2, [x21, #5080]
    6920:	cb010001 	sub	x1, x0, x1
    6924:	eb02403f 	cmp	x1, x2, lsl #16
    6928:	54000382 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    692c:	d350fc22 	lsr	x2, x1, #16
    6930:	f949fea3 	ldr	x3, [x21, #5112]
    6934:	8b020842 	add	x2, x2, x2, lsl #2
    6938:	d37df042 	lsl	x2, x2, #3
    693c:	8b020064 	add	x4, x3, x2
    6940:	f9401094 	ldr	x20, [x4, #32]
    6944:	b40002b4 	cbz	x20, 6998 <fwp_drop10+0x98>
    6948:	38626862 	ldrb	w2, [x3, x2]
    694c:	7100085f 	cmp	w2, #0x2
    6950:	540007a0 	b.eq	6a44 <fwp_drop10+0x144>  // b.none
    6954:	7100045f 	cmp	w2, #0x1
    6958:	54000201 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    695c:	29430885 	ldp	w5, w2, [x4, #24]
    6960:	92403c21 	and	x1, x1, #0xffff
    6964:	9b057c21 	mul	x1, x1, x5
    6968:	d360fc21 	lsr	x1, x1, #32
    696c:	eb02003f 	cmp	x1, x2
    6970:	54000142 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    6974:	8b010294 	add	x20, x20, x1
    6978:	39400281 	ldrb	w1, [x20]
    697c:	340000e1 	cbz	w1, 6998 <fwp_drop10+0x98>
    6980:	7100043f 	cmp	w1, #0x1
    6984:	54000120 	b.eq	69a8 <fwp_drop10+0xa8>  // b.none
    6988:	7103fc3f 	cmp	w1, #0xff
    698c:	540007c0 	b.eq	6a84 <fwp_drop10+0x184>  // b.none
    6990:	51000421 	sub	w1, w1, #0x1
    6994:	39000281 	strb	w1, [x20]
    6998:	a94153f3 	ldp	x19, x20, [sp, #16]
    699c:	f94013f5 	ldr	x21, [sp, #32]
    69a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69a4:	d65f03c0 	ret
    69a8:	f9400001 	ldr	x1, [x0]
    69ac:	b7f80581 	tbnz	x1, #63, 6a5c <fwp_drop10+0x15c>
    69b0:	91174273 	add	x19, x19, #0x5d0
    69b4:	f949da61 	ldr	x1, [x19, #5040]
    69b8:	f949ee62 	ldr	x2, [x19, #5080]
    69bc:	cb010001 	sub	x1, x0, x1
    69c0:	eb02403f 	cmp	x1, x2, lsl #16
    69c4:	54fffea2 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    69c8:	d350fc22 	lsr	x2, x1, #16
    69cc:	8b020842 	add	x2, x2, x2, lsl #2
    69d0:	d37df042 	lsl	x2, x2, #3
    69d4:	8b020065 	add	x5, x3, x2
    69d8:	f94010a4 	ldr	x4, [x5, #32]
    69dc:	b4fffde4 	cbz	x4, 6998 <fwp_drop10+0x98>
    69e0:	38626862 	ldrb	w2, [x3, x2]
    69e4:	7100085f 	cmp	w2, #0x2
    69e8:	54000220 	b.eq	6a2c <fwp_drop10+0x12c>  // b.none
    69ec:	7100045f 	cmp	w2, #0x1
    69f0:	54fffd41 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    69f4:	294308a3 	ldp	w3, w2, [x5, #24]
    69f8:	92403c21 	and	x1, x1, #0xffff
    69fc:	9b037c21 	mul	x1, x1, x3
    6a00:	d360fc21 	lsr	x1, x1, #32
    6a04:	eb02003f 	cmp	x1, x2
    6a08:	54fffc82 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a0c:	8b010084 	add	x4, x4, x1
    6a10:	39400081 	ldrb	w1, [x4]
    6a14:	7100043f 	cmp	w1, #0x1
    6a18:	54fffc01 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    6a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a20:	f94013f5 	ldr	x21, [sp, #32]
    6a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a28:	17fff832 	b	4af0 <fwp_mem_free>
    6a2c:	72003c3f 	tst	w1, #0xffff
    6a30:	54ffff00 	b.eq	6a10 <fwp_drop10+0x110>  // b.none
    6a34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a38:	f94013f5 	ldr	x21, [sp, #32]
    6a3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a40:	d65f03c0 	ret
    6a44:	72003c3f 	tst	w1, #0xffff
    6a48:	54fff980 	b.eq	6978 <fwp_drop10+0x78>  // b.none
    6a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a50:	f94013f5 	ldr	x21, [sp, #32]
    6a54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a58:	d65f03c0 	ret
    6a5c:	f9400414 	ldr	x20, [x0, #8]
    6a60:	97fffb60 	bl	57e0 <fwp_rc_free_arr>
    6a64:	91174260 	add	x0, x19, #0x5d0
    6a68:	f949d801 	ldr	x1, [x0, #5040]
    6a6c:	f949ec00 	ldr	x0, [x0, #5080]
    6a70:	cb010281 	sub	x1, x20, x1
    6a74:	eb00403f 	cmp	x1, x0, lsl #16
    6a78:	54fff902 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a7c:	aa1403e0 	mov	x0, x20
    6a80:	17ffffab 	b	692c <fwp_drop10+0x2c>
    6a84:	ca544680 	eor	x0, x20, x20, lsr #17
    6a88:	91174273 	add	x19, x19, #0x5d0
    6a8c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a90:	8b200e60 	add	x0, x19, w0, uxtb #3
    6a94:	f94a2400 	ldr	x0, [x0, #5192]
    6a98:	b5000080 	cbnz	x0, 6aa8 <fwp_drop10+0x1a8>
    6a9c:	14000010 	b	6adc <fwp_drop10+0x1dc>
    6aa0:	f9400800 	ldr	x0, [x0, #16]
    6aa4:	b40001c0 	cbz	x0, 6adc <fwp_drop10+0x1dc>
    6aa8:	f9400001 	ldr	x1, [x0]
    6aac:	eb14003f 	cmp	x1, x20
    6ab0:	54ffff81 	b.ne	6aa0 <fwp_drop10+0x1a0>  // b.any
    6ab4:	f9400401 	ldr	x1, [x0, #8]
    6ab8:	d1000421 	sub	x1, x1, #0x1
    6abc:	f9000401 	str	x1, [x0, #8]
    6ac0:	f103f83f 	cmp	x1, #0xfe
    6ac4:	54fff6a1 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    6ac8:	aa1403e0 	mov	x0, x20
    6acc:	97fff769 	bl	4870 <fwp_rc_forget_slot>
    6ad0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6ad4:	39000280 	strb	w0, [x20]
    6ad8:	17ffffb0 	b	6998 <fwp_drop10+0x98>
    6adc:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    6ae0:	913b8000 	add	x0, x0, #0xee0
    6ae4:	97fff367 	bl	3880 <fwp_trap>
    6ae8:	d503201f 	nop
    6aec:	d503201f 	nop

0000000000006af0 <fwp_caps173>:
    6af0:	34000041 	cbz	w1, 6af8 <fwp_caps173+0x8>
    6af4:	d65f03c0 	ret
    6af8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6afc:	91174063 	add	x3, x3, #0x5d0
    6b00:	f949d861 	ldr	x1, [x3, #5040]
    6b04:	f949ec62 	ldr	x2, [x3, #5080]
    6b08:	cb010001 	sub	x1, x0, x1
    6b0c:	eb02403f 	cmp	x1, x2, lsl #16
    6b10:	54ffff22 	b.cs	6af4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6b14:	d350fc22 	lsr	x2, x1, #16
    6b18:	f949fc65 	ldr	x5, [x3, #5112]
    6b1c:	8b020842 	add	x2, x2, x2, lsl #2
    6b20:	d37df042 	lsl	x2, x2, #3
    6b24:	8b0200a4 	add	x4, x5, x2
    6b28:	f9401083 	ldr	x3, [x4, #32]
    6b2c:	b4fffe43 	cbz	x3, 6af4 <fwp_caps173+0x4>
    6b30:	386268a2 	ldrb	w2, [x5, x2]
    6b34:	7100085f 	cmp	w2, #0x2
    6b38:	540001c0 	b.eq	6b70 <fwp_caps173+0x80>  // b.none
    6b3c:	7100045f 	cmp	w2, #0x1
    6b40:	54fffda1 	b.ne	6af4 <fwp_caps173+0x4>  // b.any
    6b44:	29430885 	ldp	w5, w2, [x4, #24]
    6b48:	92403c21 	and	x1, x1, #0xffff
    6b4c:	9b057c21 	mul	x1, x1, x5
    6b50:	d360fc21 	lsr	x1, x1, #32
    6b54:	eb02003f 	cmp	x1, x2
    6b58:	54fffce2 	b.cs	6af4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6b5c:	8b010063 	add	x3, x3, x1
    6b60:	39400061 	ldrb	w1, [x3]
    6b64:	7100043f 	cmp	w1, #0x1
    6b68:	54fffc61 	b.ne	6af4 <fwp_caps173+0x4>  // b.any
    6b6c:	17fff7e1 	b	4af0 <fwp_mem_free>
    6b70:	72003c3f 	tst	w1, #0xffff
    6b74:	54ffff60 	b.eq	6b60 <fwp_caps173+0x70>  // b.none
    6b78:	d65f03c0 	ret
    6b7c:	d503201f 	nop

0000000000006b80 <f37>:
    6b80:	d101c3ff 	sub	sp, sp, #0x70
    6b84:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6b88:	f947f421 	ldr	x1, [x1, #4072]
    6b8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6b90:	910083fd 	add	x29, sp, #0x20
    6b94:	a90563f7 	stp	x23, x24, [sp, #80]
    6b98:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    6b9c:	911742e3 	add	x3, x23, #0x5d0
    6ba0:	a90353f3 	stp	x19, x20, [sp, #48]
    6ba4:	a9045bf5 	stp	x21, x22, [sp, #64]
    6ba8:	aa0003f6 	mov	x22, x0
    6bac:	a9066bf9 	stp	x25, x26, [sp, #96]
    6bb0:	f949ec62 	ldr	x2, [x3, #5080]
    6bb4:	f9400024 	ldr	x4, [x1]
    6bb8:	f9000fe4 	str	x4, [sp, #24]
    6bbc:	d2800004 	mov	x4, #0x0                   	// #0
    6bc0:	f949d861 	ldr	x1, [x3, #5040]
    6bc4:	d370bc42 	lsl	x2, x2, #16
    6bc8:	b40015c0 	cbz	x0, 6e80 <f37+0x300>
    6bcc:	f9400818 	ldr	x24, [x0, #16]
    6bd0:	cb010301 	sub	x1, x24, x1
    6bd4:	eb02003f 	cmp	x1, x2
    6bd8:	54000362 	b.cs	6c44 <f37+0xc4>  // b.hs, b.nlast
    6bdc:	f949fc60 	ldr	x0, [x3, #5112]
    6be0:	d350fc22 	lsr	x2, x1, #16
    6be4:	8b020842 	add	x2, x2, x2, lsl #2
    6be8:	8b020c02 	add	x2, x0, x2, lsl #3
    6bec:	f9401040 	ldr	x0, [x2, #32]
    6bf0:	b40002a0 	cbz	x0, 6c44 <f37+0xc4>
    6bf4:	39400043 	ldrb	w3, [x2]
    6bf8:	7100087f 	cmp	w3, #0x2
    6bfc:	540013c0 	b.eq	6e74 <f37+0x2f4>  // b.none
    6c00:	7100047f 	cmp	w3, #0x1
    6c04:	540001c1 	b.ne	6c3c <f37+0xbc>  // b.any
    6c08:	29430843 	ldp	w3, w2, [x2, #24]
    6c0c:	92403c21 	and	x1, x1, #0xffff
    6c10:	9b037c21 	mul	x1, x1, x3
    6c14:	d360fc21 	lsr	x1, x1, #32
    6c18:	eb02003f 	cmp	x1, x2
    6c1c:	54000102 	b.cs	6c3c <f37+0xbc>  // b.hs, b.nlast
    6c20:	8b010000 	add	x0, x0, x1
    6c24:	39400001 	ldrb	w1, [x0]
    6c28:	340000a1 	cbz	w1, 6c3c <f37+0xbc>
    6c2c:	7103f43f 	cmp	w1, #0xfd
    6c30:	540016a8 	b.hi	6f04 <f37+0x384>  // b.pmore
    6c34:	11000421 	add	w1, w1, #0x1
    6c38:	39000001 	strb	w1, [x0]
    6c3c:	d2800000 	mov	x0, #0x0                   	// #0
    6c40:	b40000f6 	cbz	x22, 6c5c <f37+0xdc>
    6c44:	aa1603e1 	mov	x1, x22
    6c48:	d2800000 	mov	x0, #0x0                   	// #0
    6c4c:	d503201f 	nop
    6c50:	f9400821 	ldr	x1, [x1, #16]
    6c54:	91000400 	add	x0, x0, #0x1
    6c58:	b5ffffc1 	cbnz	x1, 6c50 <f37+0xd0>
    6c5c:	b40011b8 	cbz	x24, 6e90 <f37+0x310>
    6c60:	aa1803e1 	mov	x1, x24
    6c64:	d2800002 	mov	x2, #0x0                   	// #0
    6c68:	f9400821 	ldr	x1, [x1, #16]
    6c6c:	91000442 	add	x2, x2, #0x1
    6c70:	b5ffffc1 	cbnz	x1, 6c68 <f37+0xe8>
    6c74:	eb00005f 	cmp	x2, x0
    6c78:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6c7c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6c80:	eb01033f 	cmp	x25, x1
    6c84:	54001468 	b.hi	6f10 <f37+0x390>  // b.pmore
    6c88:	d37ffb33 	lsl	x19, x25, #1
    6c8c:	52800041 	mov	w1, #0x2                   	// #2
    6c90:	91000660 	add	x0, x19, #0x1
    6c94:	d37df000 	lsl	x0, x0, #3
    6c98:	97fff8b6 	bl	4f70 <fwp_heap_alloc>
    6c9c:	911742e1 	add	x1, x23, #0x5d0
    6ca0:	aa0003fa 	mov	x26, x0
    6ca4:	f9000013 	str	x19, [x0]
    6ca8:	aa0103e0 	mov	x0, x1
    6cac:	f949d821 	ldr	x1, [x1, #5040]
    6cb0:	f949ec00 	ldr	x0, [x0, #5080]
    6cb4:	cb010341 	sub	x1, x26, x1
    6cb8:	eb00403f 	cmp	x1, x0, lsl #16
    6cbc:	54000342 	b.cs	6d24 <f37+0x1a4>  // b.hs, b.nlast
    6cc0:	911742e2 	add	x2, x23, #0x5d0
    6cc4:	d350fc20 	lsr	x0, x1, #16
    6cc8:	8b000800 	add	x0, x0, x0, lsl #2
    6ccc:	f949fc43 	ldr	x3, [x2, #5112]
    6cd0:	d37df002 	lsl	x2, x0, #3
    6cd4:	8b020060 	add	x0, x3, x2
    6cd8:	f9401013 	ldr	x19, [x0, #32]
    6cdc:	b4000253 	cbz	x19, 6d24 <f37+0x1a4>
    6ce0:	38626862 	ldrb	w2, [x3, x2]
    6ce4:	7100085f 	cmp	w2, #0x2
    6ce8:	54000c00 	b.eq	6e68 <f37+0x2e8>  // b.none
    6cec:	7100045f 	cmp	w2, #0x1
    6cf0:	540001a1 	b.ne	6d24 <f37+0x1a4>  // b.any
    6cf4:	29430002 	ldp	w2, w0, [x0, #24]
    6cf8:	92403c21 	and	x1, x1, #0xffff
    6cfc:	9b027c21 	mul	x1, x1, x2
    6d00:	d360fc21 	lsr	x1, x1, #32
    6d04:	eb00003f 	cmp	x1, x0
    6d08:	540000e2 	b.cs	6d24 <f37+0x1a4>  // b.hs, b.nlast
    6d0c:	8b010273 	add	x19, x19, x1
    6d10:	39400260 	ldrb	w0, [x19]
    6d14:	7103fc1f 	cmp	w0, #0xff
    6d18:	54000da0 	b.eq	6ecc <f37+0x34c>  // b.none
    6d1c:	52800020 	mov	w0, #0x1                   	// #1
    6d20:	39000260 	strb	w0, [x19]
    6d24:	b4000259 	cbz	x25, 6d6c <f37+0x1ec>
    6d28:	8b191359 	add	x25, x26, x25, lsl #4
    6d2c:	aa1a03f3 	mov	x19, x26
    6d30:	aa1603f5 	mov	x21, x22
    6d34:	aa1803f4 	mov	x20, x24
    6d38:	f9400683 	ldr	x3, [x20, #8]
    6d3c:	f94006a2 	ldr	x2, [x21, #8]
    6d40:	f9400861 	ldr	x1, [x3, #16]
    6d44:	f9400840 	ldr	x0, [x2, #16]
    6d48:	fd400461 	ldr	d1, [x3, #8]
    6d4c:	fd400440 	ldr	d0, [x2, #8]
    6d50:	97fff9f8 	bl	5530 <w120>
    6d54:	f9000660 	str	x0, [x19, #8]
    6d58:	f8010e61 	str	x1, [x19, #16]!
    6d5c:	f9400a94 	ldr	x20, [x20, #16]
    6d60:	f9400ab5 	ldr	x21, [x21, #16]
    6d64:	eb13033f 	cmp	x25, x19
    6d68:	54fffe81 	b.ne	6d38 <f37+0x1b8>  // b.any
    6d6c:	aa1803e0 	mov	x0, x24
    6d70:	97fffd48 	bl	6290 <fwp_drop4>
    6d74:	aa1603e0 	mov	x0, x22
    6d78:	97fffd46 	bl	6290 <fwp_drop4>
    6d7c:	911742f7 	add	x23, x23, #0x5d0
    6d80:	aa1a03e0 	mov	x0, x26
    6d84:	97fffa48 	bl	56a4 <w176.constprop.0>
    6d88:	aa0103f3 	mov	x19, x1
    6d8c:	aa0003f4 	mov	x20, x0
    6d90:	aa1a03e0 	mov	x0, x26
    6d94:	97fffedb 	bl	6900 <fwp_drop10>
    6d98:	a900cff4 	stp	x20, x19, [sp, #8]
    6d9c:	910023e1 	add	x1, sp, #0x8
    6da0:	52800000 	mov	w0, #0x0                   	// #0
    6da4:	97fff8b8 	bl	5084 <fwp_data.part.0.constprop.0>
    6da8:	f949dae1 	ldr	x1, [x23, #5040]
    6dac:	aa0003f3 	mov	x19, x0
    6db0:	f949eee0 	ldr	x0, [x23, #5080]
    6db4:	cb010261 	sub	x1, x19, x1
    6db8:	eb00403f 	cmp	x1, x0, lsl #16
    6dbc:	54000322 	b.cs	6e20 <f37+0x2a0>  // b.hs, b.nlast
    6dc0:	d350fc22 	lsr	x2, x1, #16
    6dc4:	f949fee3 	ldr	x3, [x23, #5112]
    6dc8:	8b020842 	add	x2, x2, x2, lsl #2
    6dcc:	d37df042 	lsl	x2, x2, #3
    6dd0:	8b020060 	add	x0, x3, x2
    6dd4:	f9401014 	ldr	x20, [x0, #32]
    6dd8:	b4000254 	cbz	x20, 6e20 <f37+0x2a0>
    6ddc:	38626862 	ldrb	w2, [x3, x2]
    6de0:	7100085f 	cmp	w2, #0x2
    6de4:	540003c0 	b.eq	6e5c <f37+0x2dc>  // b.none
    6de8:	7100045f 	cmp	w2, #0x1
    6dec:	540001a1 	b.ne	6e20 <f37+0x2a0>  // b.any
    6df0:	29430002 	ldp	w2, w0, [x0, #24]
    6df4:	92403c21 	and	x1, x1, #0xffff
    6df8:	9b027c21 	mul	x1, x1, x2
    6dfc:	d360fc21 	lsr	x1, x1, #32
    6e00:	eb00003f 	cmp	x1, x0
    6e04:	540000e2 	b.cs	6e20 <f37+0x2a0>  // b.hs, b.nlast
    6e08:	8b010294 	add	x20, x20, x1
    6e0c:	39400280 	ldrb	w0, [x20]
    6e10:	7103fc1f 	cmp	w0, #0xff
    6e14:	54000620 	b.eq	6ed8 <f37+0x358>  // b.none
    6e18:	52800020 	mov	w0, #0x1                   	// #1
    6e1c:	39000280 	strb	w0, [x20]
    6e20:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6e24:	f947f400 	ldr	x0, [x0, #4072]
    6e28:	f9400fe2 	ldr	x2, [sp, #24]
    6e2c:	f9400001 	ldr	x1, [x0]
    6e30:	eb010042 	subs	x2, x2, x1
    6e34:	d2800001 	mov	x1, #0x0                   	// #0
    6e38:	540006a1 	b.ne	6f0c <f37+0x38c>  // b.any
    6e3c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6e40:	aa1303e0 	mov	x0, x19
    6e44:	a94353f3 	ldp	x19, x20, [sp, #48]
    6e48:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6e4c:	a94563f7 	ldp	x23, x24, [sp, #80]
    6e50:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6e54:	9101c3ff 	add	sp, sp, #0x70
    6e58:	d65f03c0 	ret
    6e5c:	72003c3f 	tst	w1, #0xffff
    6e60:	54fffe01 	b.ne	6e20 <f37+0x2a0>  // b.any
    6e64:	17ffffea 	b	6e0c <f37+0x28c>
    6e68:	72003c3f 	tst	w1, #0xffff
    6e6c:	54fff5c1 	b.ne	6d24 <f37+0x1a4>  // b.any
    6e70:	17ffffa8 	b	6d10 <f37+0x190>
    6e74:	72003c3f 	tst	w1, #0xffff
    6e78:	54ffee21 	b.ne	6c3c <f37+0xbc>  // b.any
    6e7c:	17ffff6a 	b	6c24 <f37+0xa4>
    6e80:	cb0103e1 	neg	x1, x1
    6e84:	eb02003f 	cmp	x1, x2
    6e88:	540002e3 	b.cc	6ee4 <f37+0x364>  // b.lo, b.ul, b.last
    6e8c:	d503201f 	nop
    6e90:	52800041 	mov	w1, #0x2                   	// #2
    6e94:	d2800100 	mov	x0, #0x8                   	// #8
    6e98:	97fff836 	bl	4f70 <fwp_heap_alloc>
    6e9c:	aa0003e1 	mov	x1, x0
    6ea0:	911742e0 	add	x0, x23, #0x5d0
    6ea4:	aa0103fa 	mov	x26, x1
    6ea8:	d2800018 	mov	x24, #0x0                   	// #0
    6eac:	f900003f 	str	xzr, [x1]
    6eb0:	f949d801 	ldr	x1, [x0, #5040]
    6eb4:	f949ec00 	ldr	x0, [x0, #5080]
    6eb8:	cb010341 	sub	x1, x26, x1
    6ebc:	eb00403f 	cmp	x1, x0, lsl #16
    6ec0:	54fff562 	b.cs	6d6c <f37+0x1ec>  // b.hs, b.nlast
    6ec4:	d2800019 	mov	x25, #0x0                   	// #0
    6ec8:	17ffff7e 	b	6cc0 <f37+0x140>
    6ecc:	aa1303e0 	mov	x0, x19
    6ed0:	97fff668 	bl	4870 <fwp_rc_forget_slot>
    6ed4:	17ffff92 	b	6d1c <f37+0x19c>
    6ed8:	aa1403e0 	mov	x0, x20
    6edc:	97fff665 	bl	4870 <fwp_rc_forget_slot>
    6ee0:	17ffffce 	b	6e18 <f37+0x298>
    6ee4:	f949fc62 	ldr	x2, [x3, #5112]
    6ee8:	d350fc20 	lsr	x0, x1, #16
    6eec:	8b000800 	add	x0, x0, x0, lsl #2
    6ef0:	8b000c42 	add	x2, x2, x0, lsl #3
    6ef4:	f9401040 	ldr	x0, [x2, #32]
    6ef8:	b4fffcc0 	cbz	x0, 6e90 <f37+0x310>
    6efc:	d2800018 	mov	x24, #0x0                   	// #0
    6f00:	17ffff3d 	b	6bf4 <f37+0x74>
    6f04:	97fff614 	bl	4754 <fwp_rc_wide_dup>
    6f08:	17ffff4d 	b	6c3c <f37+0xbc>
    6f0c:	97ffee81 	bl	2910 <__stack_chk_fail@plt>
    6f10:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x480>
    6f14:	91008000 	add	x0, x0, #0x20
    6f18:	97fff25a 	bl	3880 <fwp_trap>
    6f1c:	d503201f 	nop

0000000000006f20 <fwp_owned_entry37>:
    6f20:	f9400000 	ldr	x0, [x0]
    6f24:	17ffff17 	b	6b80 <f37>
    6f28:	d503201f 	nop
    6f2c:	d503201f 	nop

0000000000006f30 <e37>:
    6f30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f34:	910003fd 	mov	x29, sp
    6f38:	f9000bf3 	str	x19, [sp, #16]
    6f3c:	f9400013 	ldr	x19, [x0]
    6f40:	aa1303e0 	mov	x0, x19
    6f44:	97fffa00 	bl	5744 <fwp_rc_share>
    6f48:	aa1303e0 	mov	x0, x19
    6f4c:	97ffff0d 	bl	6b80 <f37>
    6f50:	aa0003f3 	mov	x19, x0
    6f54:	97fff9fc 	bl	5744 <fwp_rc_share>
    6f58:	aa1303e0 	mov	x0, x19
    6f5c:	f9400bf3 	ldr	x19, [sp, #16]
    6f60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f64:	d65f03c0 	ret
    6f68:	d503201f 	nop
    6f6c:	d503201f 	nop

0000000000006f70 <fwp_args37>:
    6f70:	7100003f 	cmp	w1, #0x0
    6f74:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f78:	54000041 	b.ne	6f80 <fwp_args37+0x10>  // b.any
    6f7c:	d65f03c0 	ret
    6f80:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f84:	91174042 	add	x2, x2, #0x5d0
    6f88:	f9400001 	ldr	x1, [x0]
    6f8c:	f949d843 	ldr	x3, [x2, #5040]
    6f90:	f949ec40 	ldr	x0, [x2, #5080]
    6f94:	cb030021 	sub	x1, x1, x3
    6f98:	eb00403f 	cmp	x1, x0, lsl #16
    6f9c:	54ffff02 	b.cs	6f7c <fwp_args37+0xc>  // b.hs, b.nlast
    6fa0:	d350fc20 	lsr	x0, x1, #16
    6fa4:	f949fc44 	ldr	x4, [x2, #5112]
    6fa8:	8b000800 	add	x0, x0, x0, lsl #2
    6fac:	d37df002 	lsl	x2, x0, #3
    6fb0:	8b020083 	add	x3, x4, x2
    6fb4:	f9401060 	ldr	x0, [x3, #32]
    6fb8:	b4fffe20 	cbz	x0, 6f7c <fwp_args37+0xc>
    6fbc:	38626882 	ldrb	w2, [x4, x2]
    6fc0:	7100085f 	cmp	w2, #0x2
    6fc4:	54000220 	b.eq	7008 <fwp_args37+0x98>  // b.none
    6fc8:	7100045f 	cmp	w2, #0x1
    6fcc:	54fffd81 	b.ne	6f7c <fwp_args37+0xc>  // b.any
    6fd0:	29430864 	ldp	w4, w2, [x3, #24]
    6fd4:	92403c21 	and	x1, x1, #0xffff
    6fd8:	9b047c21 	mul	x1, x1, x4
    6fdc:	d360fc21 	lsr	x1, x1, #32
    6fe0:	eb02003f 	cmp	x1, x2
    6fe4:	54fffcc2 	b.cs	6f7c <fwp_args37+0xc>  // b.hs, b.nlast
    6fe8:	8b010000 	add	x0, x0, x1
    6fec:	39400001 	ldrb	w1, [x0]
    6ff0:	34fffc61 	cbz	w1, 6f7c <fwp_args37+0xc>
    6ff4:	7103f43f 	cmp	w1, #0xfd
    6ff8:	540000e8 	b.hi	7014 <fwp_args37+0xa4>  // b.pmore
    6ffc:	11000421 	add	w1, w1, #0x1
    7000:	39000001 	strb	w1, [x0]
    7004:	d65f03c0 	ret
    7008:	72003c3f 	tst	w1, #0xffff
    700c:	54ffff00 	b.eq	6fec <fwp_args37+0x7c>  // b.none
    7010:	d65f03c0 	ret
    7014:	17fff5d0 	b	4754 <fwp_rc_wide_dup>
    7018:	d503201f 	nop
    701c:	d503201f 	nop

0000000000007020 <fwp_caps37>:
    7020:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7024:	910003fd 	mov	x29, sp
    7028:	f9000bf3 	str	x19, [sp, #16]
    702c:	aa0003f3 	mov	x19, x0
    7030:	b9400400 	ldr	w0, [x0, #4]
    7034:	340004a0 	cbz	w0, 70c8 <fwp_caps37+0xa8>
    7038:	f9400660 	ldr	x0, [x19, #8]
    703c:	350004e1 	cbnz	w1, 70d8 <fwp_caps37+0xb8>
    7040:	97fffc94 	bl	6290 <fwp_drop4>
    7044:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7048:	91174042 	add	x2, x2, #0x5d0
    704c:	f949d840 	ldr	x0, [x2, #5040]
    7050:	f949ec41 	ldr	x1, [x2, #5080]
    7054:	cb000260 	sub	x0, x19, x0
    7058:	eb01401f 	cmp	x0, x1, lsl #16
    705c:	54000382 	b.cs	70cc <fwp_caps37+0xac>  // b.hs, b.nlast
    7060:	d350fc01 	lsr	x1, x0, #16
    7064:	f949fc44 	ldr	x4, [x2, #5112]
    7068:	8b010821 	add	x1, x1, x1, lsl #2
    706c:	d37df021 	lsl	x1, x1, #3
    7070:	8b010083 	add	x3, x4, x1
    7074:	f9401062 	ldr	x2, [x3, #32]
    7078:	b40002a2 	cbz	x2, 70cc <fwp_caps37+0xac>
    707c:	38616881 	ldrb	w1, [x4, x1]
    7080:	7100083f 	cmp	w1, #0x2
    7084:	540006c0 	b.eq	715c <fwp_caps37+0x13c>  // b.none
    7088:	7100043f 	cmp	w1, #0x1
    708c:	54000201 	b.ne	70cc <fwp_caps37+0xac>  // b.any
    7090:	29430464 	ldp	w4, w1, [x3, #24]
    7094:	92403c00 	and	x0, x0, #0xffff
    7098:	9b047c00 	mul	x0, x0, x4
    709c:	d360fc00 	lsr	x0, x0, #32
    70a0:	eb01001f 	cmp	x0, x1
    70a4:	54000142 	b.cs	70cc <fwp_caps37+0xac>  // b.hs, b.nlast
    70a8:	8b000042 	add	x2, x2, x0
    70ac:	39400040 	ldrb	w0, [x2]
    70b0:	7100041f 	cmp	w0, #0x1
    70b4:	540000c1 	b.ne	70cc <fwp_caps37+0xac>  // b.any
    70b8:	aa1303e0 	mov	x0, x19
    70bc:	f9400bf3 	ldr	x19, [sp, #16]
    70c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70c4:	17fff68b 	b	4af0 <fwp_mem_free>
    70c8:	34fffbe1 	cbz	w1, 7044 <fwp_caps37+0x24>
    70cc:	f9400bf3 	ldr	x19, [sp, #16]
    70d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70d4:	d65f03c0 	ret
    70d8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    70dc:	91174042 	add	x2, x2, #0x5d0
    70e0:	f949d843 	ldr	x3, [x2, #5040]
    70e4:	f949ec41 	ldr	x1, [x2, #5080]
    70e8:	cb030000 	sub	x0, x0, x3
    70ec:	eb01401f 	cmp	x0, x1, lsl #16
    70f0:	54fffee2 	b.cs	70cc <fwp_caps37+0xac>  // b.hs, b.nlast
    70f4:	d350fc01 	lsr	x1, x0, #16
    70f8:	f949fc44 	ldr	x4, [x2, #5112]
    70fc:	8b010821 	add	x1, x1, x1, lsl #2
    7100:	d37df021 	lsl	x1, x1, #3
    7104:	8b010083 	add	x3, x4, x1
    7108:	f9401062 	ldr	x2, [x3, #32]
    710c:	b4fffe02 	cbz	x2, 70cc <fwp_caps37+0xac>
    7110:	38616881 	ldrb	w1, [x4, x1]
    7114:	7100083f 	cmp	w1, #0x2
    7118:	54000280 	b.eq	7168 <fwp_caps37+0x148>  // b.none
    711c:	7100043f 	cmp	w1, #0x1
    7120:	54fffd61 	b.ne	70cc <fwp_caps37+0xac>  // b.any
    7124:	92403c01 	and	x1, x0, #0xffff
    7128:	29430064 	ldp	w4, w0, [x3, #24]
    712c:	9b047c21 	mul	x1, x1, x4
    7130:	d360fc21 	lsr	x1, x1, #32
    7134:	eb00003f 	cmp	x1, x0
    7138:	54fffca2 	b.cs	70cc <fwp_caps37+0xac>  // b.hs, b.nlast
    713c:	8b010042 	add	x2, x2, x1
    7140:	39400040 	ldrb	w0, [x2]
    7144:	34fffc40 	cbz	w0, 70cc <fwp_caps37+0xac>
    7148:	7103f41f 	cmp	w0, #0xfd
    714c:	54000148 	b.hi	7174 <fwp_caps37+0x154>  // b.pmore
    7150:	11000400 	add	w0, w0, #0x1
    7154:	39000040 	strb	w0, [x2]
    7158:	17ffffdd 	b	70cc <fwp_caps37+0xac>
    715c:	72003c1f 	tst	w0, #0xffff
    7160:	54fffb61 	b.ne	70cc <fwp_caps37+0xac>  // b.any
    7164:	17ffffd2 	b	70ac <fwp_caps37+0x8c>
    7168:	72003c1f 	tst	w0, #0xffff
    716c:	54fffb01 	b.ne	70cc <fwp_caps37+0xac>  // b.any
    7170:	17fffff4 	b	7140 <fwp_caps37+0x120>
    7174:	f9400bf3 	ldr	x19, [sp, #16]
    7178:	aa0203e0 	mov	x0, x2
    717c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7180:	17fff575 	b	4754 <fwp_rc_wide_dup>

0000000000007184 <fwp_write>:
    7184:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7188:	910003fd 	mov	x29, sp
    718c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    7190:	f947f484 	ldr	x4, [x4, #4072]
    7194:	a90153f3 	stp	x19, x20, [sp, #16]
    7198:	d10943ff 	sub	sp, sp, #0x250
    719c:	b9400045 	ldr	w5, [x2]
    71a0:	aa0003f4 	mov	x20, x0
    71a4:	f9400080 	ldr	x0, [x4]
    71a8:	f90127e0 	str	x0, [sp, #584]
    71ac:	d2800000 	mov	x0, #0x0                   	// #0
    71b0:	710064bf 	cmp	w5, #0x19
    71b4:	54000408 	b.hi	7234 <fwp_write+0xb0>  // b.pmore
    71b8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x480>
    71bc:	aa0103f3 	mov	x19, x1
    71c0:	9123c000 	add	x0, x0, #0x8f0
    71c4:	f9013bf5 	str	x21, [sp, #624]
    71c8:	f9013ff6 	str	x22, [sp, #632]
    71cc:	f90153fb 	str	x27, [sp, #672]
    71d0:	f90157fc 	str	x28, [sp, #680]
    71d4:	aa0203fc 	mov	x28, x2
    71d8:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    71dc:	10000061 	adr	x1, 71e8 <fwp_write+0x64>
    71e0:	8b20a820 	add	x0, x1, w0, sxth #2
    71e4:	d61f0000 	br	x0
    71e8:	910123e0 	add	x0, sp, #0x48
    71ec:	aa1303e5 	mov	x5, x19
    71f0:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x480>
    71f4:	aa0003f3 	mov	x19, x0
    71f8:	9101a084 	add	x4, x4, #0x68
    71fc:	d2804003 	mov	x3, #0x200                 	// #512
    7200:	aa0303e1 	mov	x1, x3
    7204:	52800042 	mov	w2, #0x2                   	// #2
    7208:	97ffed9e 	bl	2880 <__snprintf_chk@plt>
    720c:	aa1303e0 	mov	x0, x19
    7210:	97ffed64 	bl	27a0 <strlen@plt>
    7214:	aa1303e1 	mov	x1, x19
    7218:	aa0003e2 	mov	x2, x0
    721c:	aa1403e0 	mov	x0, x20
    7220:	97fff0fc 	bl	3610 <buf_put>
    7224:	f9413bf5 	ldr	x21, [sp, #624]
    7228:	f9413ff6 	ldr	x22, [sp, #632]
    722c:	f94153fb 	ldr	x27, [sp, #672]
    7230:	f94157fc 	ldr	x28, [sp, #680]
    7234:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7238:	f947f400 	ldr	x0, [x0, #4072]
    723c:	f94127e2 	ldr	x2, [sp, #584]
    7240:	f9400001 	ldr	x1, [x0]
    7244:	eb010042 	subs	x2, x2, x1
    7248:	d2800001 	mov	x1, #0x0                   	// #0
    724c:	540077a1 	b.ne	8140 <fwp_write+0xfbc>  // b.any
    7250:	910943ff 	add	sp, sp, #0x250
    7254:	a94153f3 	ldp	x19, x20, [sp, #16]
    7258:	a8c77bfd 	ldp	x29, x30, [sp], #112
    725c:	d65f03c0 	ret
    7260:	910123e0 	add	x0, sp, #0x48
    7264:	aa1303e5 	mov	x5, x19
    7268:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x480>
    726c:	aa0003f3 	mov	x19, x0
    7270:	91018084 	add	x4, x4, #0x60
    7274:	d2804003 	mov	x3, #0x200                 	// #512
    7278:	17ffffe2 	b	7200 <fwp_write+0x7c>
    727c:	71004cbf 	cmp	w5, #0x13
    7280:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x480>
    7284:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7288:	91014000 	add	x0, x0, #0x50
    728c:	91016021 	add	x1, x1, #0x58
    7290:	d2800082 	mov	x2, #0x4                   	// #4
    7294:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7298:	aa1403e0 	mov	x0, x20
    729c:	f90143f7 	str	x23, [sp, #640]
    72a0:	d2800016 	mov	x22, #0x0                   	// #0
    72a4:	f90147f8 	str	x24, [sp, #648]
    72a8:	97fff0da 	bl	3610 <buf_put>
    72ac:	f9400260 	ldr	x0, [x19]
    72b0:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x480>
    72b4:	d2800015 	mov	x21, #0x0                   	// #0
    72b8:	910362f7 	add	x23, x23, #0xd8
    72bc:	b4004780 	cbz	x0, 7bac <fwp_write+0xa28>
    72c0:	b9400380 	ldr	w0, [x28]
    72c4:	52800003 	mov	w3, #0x0                   	// #0
    72c8:	f9401f82 	ldr	x2, [x28, #56]
    72cc:	71004c1f 	cmp	w0, #0x13
    72d0:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    72d4:	aa1403e0 	mov	x0, x20
    72d8:	8b010e61 	add	x1, x19, x1, lsl #3
    72dc:	f9400421 	ldr	x1, [x1, #8]
    72e0:	97ffffa9 	bl	7184 <fwp_write>
    72e4:	b9400380 	ldr	w0, [x28]
    72e8:	7100481f 	cmp	w0, #0x12
    72ec:	54004b20 	b.eq	7c50 <fwp_write+0xacc>  // b.none
    72f0:	f9400260 	ldr	x0, [x19]
    72f4:	910006b5 	add	x21, x21, #0x1
    72f8:	91000ad6 	add	x22, x22, #0x2
    72fc:	eb15001f 	cmp	x0, x21
    7300:	54004569 	b.ls	7bac <fwp_write+0xa28>  // b.plast
    7304:	aa1703e1 	mov	x1, x23
    7308:	aa1403e0 	mov	x0, x20
    730c:	d2800042 	mov	x2, #0x2                   	// #2
    7310:	97fff0c0 	bl	3610 <buf_put>
    7314:	17ffffeb 	b	72c0 <fwp_write+0x13c>
    7318:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    731c:	91024021 	add	x1, x1, #0x90
    7320:	d28000c2 	mov	x2, #0x6                   	// #6
    7324:	aa1403e0 	mov	x0, x20
    7328:	91004273 	add	x19, x19, #0x10
    732c:	97fff0b9 	bl	3610 <buf_put>
    7330:	aa1303e0 	mov	x0, x19
    7334:	97ffed1b 	bl	27a0 <strlen@plt>
    7338:	aa1303e1 	mov	x1, x19
    733c:	aa0003e2 	mov	x2, x0
    7340:	aa1403e0 	mov	x0, x20
    7344:	97fff0b3 	bl	3610 <buf_put>
    7348:	528007c3 	mov	w3, #0x3e                  	// #62
    734c:	aa1403e0 	mov	x0, x20
    7350:	91001fe1 	add	x1, sp, #0x7
    7354:	d2800022 	mov	x2, #0x1                   	// #1
    7358:	39001fe3 	strb	w3, [sp, #7]
    735c:	17ffffb1 	b	7220 <fwp_write+0x9c>
    7360:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7364:	f947f400 	ldr	x0, [x0, #4072]
    7368:	f94127e2 	ldr	x2, [sp, #584]
    736c:	f9400001 	ldr	x1, [x0]
    7370:	eb010042 	subs	x2, x2, x1
    7374:	d2800001 	mov	x1, #0x0                   	// #0
    7378:	540034c1 	b.ne	7a10 <fwp_write+0x88c>  // b.any
    737c:	f9413bf5 	ldr	x21, [sp, #624]
    7380:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7384:	f9413ff6 	ldr	x22, [sp, #632]
    7388:	aa1403e0 	mov	x0, x20
    738c:	9101c021 	add	x1, x1, #0x70
    7390:	d2800142 	mov	x2, #0xa                   	// #10
    7394:	f94153fb 	ldr	x27, [sp, #672]
    7398:	f94157fc 	ldr	x28, [sp, #680]
    739c:	910943ff 	add	sp, sp, #0x250
    73a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    73a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    73a8:	17fff09a 	b	3610 <buf_put>
    73ac:	f9400456 	ldr	x22, [x2, #8]
    73b0:	f90143f7 	str	x23, [sp, #640]
    73b4:	f90147f8 	str	x24, [sp, #648]
    73b8:	b4005af6 	cbz	x22, 7f14 <fwp_write+0xd90>
    73bc:	aa1603e0 	mov	x0, x22
    73c0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    73c4:	9103c021 	add	x1, x1, #0xf0
    73c8:	97ffed72 	bl	2990 <strcmp@plt>
    73cc:	2a0003f5 	mov	w21, w0
    73d0:	34005fc0 	cbz	w0, 7fc8 <fwp_write+0xe44>
    73d4:	aa1603e0 	mov	x0, x22
    73d8:	97ffecf2 	bl	27a0 <strlen@plt>
    73dc:	aa1603e1 	mov	x1, x22
    73e0:	aa0003e2 	mov	x2, x0
    73e4:	aa1403e0 	mov	x0, x20
    73e8:	97fff08a 	bl	3610 <buf_put>
    73ec:	52800403 	mov	w3, #0x20                  	// #32
    73f0:	91001ff5 	add	x21, sp, #0x7
    73f4:	aa1503e1 	mov	x1, x21
    73f8:	aa1403e0 	mov	x0, x20
    73fc:	d2800022 	mov	x2, #0x1                   	// #1
    7400:	39001fe3 	strb	w3, [sp, #7]
    7404:	97fff083 	bl	3610 <buf_put>
    7408:	52800f63 	mov	w3, #0x7b                  	// #123
    740c:	aa1403e0 	mov	x0, x20
    7410:	aa1503e1 	mov	x1, x21
    7414:	d2800022 	mov	x2, #0x1                   	// #1
    7418:	39001fe3 	strb	w3, [sp, #7]
    741c:	97fff07d 	bl	3610 <buf_put>
    7420:	b9401380 	ldr	w0, [x28, #16]
    7424:	52800018 	mov	w24, #0x0                   	// #0
    7428:	7100001f 	cmp	w0, #0x0
    742c:	54003a8d 	b.le	7b7c <fwp_write+0x9f8>
    7430:	f9014bf9 	str	x25, [sp, #656]
    7434:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x480>
    7438:	91046339 	add	x25, x25, #0x118
    743c:	f9014ffa 	str	x26, [sp, #664]
    7440:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x480>
    7444:	9103635a 	add	x26, x26, #0xd8
    7448:	91002276 	add	x22, x19, #0x8
    744c:	d2800013 	mov	x19, #0x0                   	// #0
    7450:	b5003e73 	cbnz	x19, 7c1c <fwp_write+0xa98>
    7454:	d37df277 	lsl	x23, x19, #3
    7458:	34003c98 	cbz	w24, 7be8 <fwp_write+0xa64>
    745c:	f9401382 	ldr	x2, [x28, #32]
    7460:	aa1403e0 	mov	x0, x20
    7464:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7468:	52800003 	mov	w3, #0x0                   	// #0
    746c:	f8776842 	ldr	x2, [x2, x23]
    7470:	91000673 	add	x19, x19, #0x1
    7474:	97ffff44 	bl	7184 <fwp_write>
    7478:	b9401380 	ldr	w0, [x28, #16]
    747c:	6b13001f 	cmp	w0, w19
    7480:	54fffe8c 	b.gt	7450 <fwp_write+0x2cc>
    7484:	f9414bf9 	ldr	x25, [sp, #656]
    7488:	f9414ffa 	ldr	x26, [sp, #664]
    748c:	34003798 	cbz	w24, 7b7c <fwp_write+0x9f8>
    7490:	52800523 	mov	w3, #0x29                  	// #41
    7494:	aa1503e1 	mov	x1, x21
    7498:	aa1403e0 	mov	x0, x20
    749c:	d2800022 	mov	x2, #0x1                   	// #1
    74a0:	39001fe3 	strb	w3, [sp, #7]
    74a4:	97fff05b 	bl	3610 <buf_put>
    74a8:	f9413bf5 	ldr	x21, [sp, #624]
    74ac:	f9413ff6 	ldr	x22, [sp, #632]
    74b0:	f94143f7 	ldr	x23, [sp, #640]
    74b4:	f94147f8 	ldr	x24, [sp, #648]
    74b8:	f94153fb 	ldr	x27, [sp, #672]
    74bc:	f94157fc 	ldr	x28, [sp, #680]
    74c0:	17ffff5d 	b	7234 <fwp_write+0xb0>
    74c4:	b9404855 	ldr	w21, [x2, #72]
    74c8:	aa1403e0 	mov	x0, x20
    74cc:	93407eb6 	sxtw	x22, w21
    74d0:	91000ac1 	add	x1, x22, #0x2
    74d4:	97fff01c 	bl	3544 <buf_grow>
    74d8:	a9400281 	ldp	x1, x0, [x20]
    74dc:	528e8603 	mov	w3, #0x7430                	// #29744
    74e0:	78206823 	strh	w3, [x1, x0]
    74e4:	8b000022 	add	x2, x1, x0
    74e8:	710002bf 	cmp	w21, #0x0
    74ec:	540036ad 	b.le	7bc0 <fwp_write+0xa3c>
    74f0:	110006a3 	add	w3, w21, #0x1
    74f4:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    74f8:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    74fc:	91000449 	add	x9, x2, #0x1
    7500:	8b23c043 	add	x3, x2, w3, sxtw
    7504:	f28aaac6 	movk	x6, #0x5556
    7508:	f2955568 	movk	x8, #0xaaab
    750c:	1400000d 	b	7540 <fwp_write+0x3bc>
    7510:	d2800021 	mov	x1, #0x1                   	// #1
    7514:	528005a5 	mov	w5, #0x2d                  	// #45
    7518:	f100001f 	cmp	x0, #0x0
    751c:	9b467e60 	smulh	x0, x19, x6
    7520:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7524:	381ff465 	strb	w5, [x3], #-1
    7528:	cb040000 	sub	x0, x0, x4
    752c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7530:	cb020000 	sub	x0, x0, x2
    7534:	8b010013 	add	x19, x0, x1
    7538:	eb03013f 	cmp	x9, x3
    753c:	54003420 	b.eq	7bc0 <fwp_write+0xa3c>  // b.none
    7540:	9b467e60 	smulh	x0, x19, x6
    7544:	937ffe64 	asr	x4, x19, #63
    7548:	52800605 	mov	w5, #0x30                  	// #48
    754c:	cb040000 	sub	x0, x0, x4
    7550:	8b000400 	add	x0, x0, x0, lsl #1
    7554:	cb000260 	sub	x0, x19, x0
    7558:	91000c01 	add	x1, x0, #0x3
    755c:	9bc87c22 	umulh	x2, x1, x8
    7560:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7564:	8b4204e2 	add	x2, x7, x2, lsr #1
    7568:	eb020021 	subs	x1, x1, x2
    756c:	54fffd60 	b.eq	7518 <fwp_write+0x394>  // b.none
    7570:	f100043f 	cmp	x1, #0x1
    7574:	54fffce1 	b.ne	7510 <fwp_write+0x38c>  // b.any
    7578:	d2800001 	mov	x1, #0x0                   	// #0
    757c:	52800565 	mov	w5, #0x2b                  	// #43
    7580:	17ffffe6 	b	7518 <fwp_write+0x394>
    7584:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7588:	f947f400 	ldr	x0, [x0, #4072]
    758c:	f94127e2 	ldr	x2, [sp, #584]
    7590:	f9400001 	ldr	x1, [x0]
    7594:	eb010042 	subs	x2, x2, x1
    7598:	d2800001 	mov	x1, #0x0                   	// #0
    759c:	540023a1 	b.ne	7a10 <fwp_write+0x88c>  // b.any
    75a0:	f9413bf5 	ldr	x21, [sp, #624]
    75a4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    75a8:	f9413ff6 	ldr	x22, [sp, #632]
    75ac:	aa1403e0 	mov	x0, x20
    75b0:	91020021 	add	x1, x1, #0x80
    75b4:	d2800102 	mov	x2, #0x8                   	// #8
    75b8:	17ffff77 	b	7394 <fwp_write+0x210>
    75bc:	aa1403e0 	mov	x0, x20
    75c0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    75c4:	d28000c2 	mov	x2, #0x6                   	// #6
    75c8:	91038021 	add	x1, x1, #0xe0
    75cc:	97fff011 	bl	3610 <buf_put>
    75d0:	d2800015 	mov	x21, #0x0                   	// #0
    75d4:	f9400263 	ldr	x3, [x19]
    75d8:	f240f87f 	tst	x3, #0x7fffffffffffffff
    75dc:	54002c40 	b.eq	7b64 <fwp_write+0x9e0>  // b.none
    75e0:	f9401f82 	ldr	x2, [x28, #56]
    75e4:	f90143f7 	str	x23, [sp, #640]
    75e8:	f90147f8 	str	x24, [sp, #648]
    75ec:	d2800857 	mov	x23, #0x42                  	// #66
    75f0:	f9014bf9 	str	x25, [sp, #656]
    75f4:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x480>
    75f8:	f9014ffa 	str	x26, [sp, #664]
    75fc:	910362d6 	add	x22, x22, #0xd8
    7600:	d2800038 	mov	x24, #0x1                   	// #1
    7604:	f2a18017 	movk	x23, #0xc00, lsl #16
    7608:	d2809099 	mov	x25, #0x484                 	// #1156
    760c:	b4000482 	cbz	x2, 769c <fwp_write+0x518>
    7610:	b9400040 	ldr	w0, [x2]
    7614:	7100701f 	cmp	w0, #0x1c
    7618:	540042a0 	b.eq	7e6c <fwp_write+0xce8>  // b.none
    761c:	71006c1f 	cmp	w0, #0x1b
    7620:	540003e8 	b.hi	769c <fwp_write+0x518>  // b.pmore
    7624:	9ac02301 	lsl	x1, x24, x0
    7628:	ea17003f 	tst	x1, x23
    762c:	54003681 	b.ne	7cfc <fwp_write+0xb78>  // b.any
    7630:	ea19003f 	tst	x1, x25
    7634:	54003501 	b.ne	7cd4 <fwp_write+0xb50>  // b.any
    7638:	d2800424 	mov	x4, #0x21                  	// #33
    763c:	ea04003f 	tst	x1, x4
    7640:	540002e0 	b.eq	769c <fwp_write+0x518>  // b.none
    7644:	b7f849a3 	tbnz	x3, #63, 7f78 <fwp_write+0xdf4>
    7648:	91002261 	add	x1, x19, #0x8
    764c:	8b150021 	add	x1, x1, x21
    7650:	39400021 	ldrb	w1, [x1]
    7654:	7100001f 	cmp	w0, #0x0
    7658:	93401c23 	sxtb	x3, w1
    765c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7660:	aa1403e0 	mov	x0, x20
    7664:	52800003 	mov	w3, #0x0                   	// #0
    7668:	97fffec7 	bl	7184 <fwp_write>
    766c:	910006b5 	add	x21, x21, #0x1
    7670:	f9400260 	ldr	x0, [x19]
    7674:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7678:	eb0002bf 	cmp	x21, x0
    767c:	540026c2 	b.cs	7b54 <fwp_write+0x9d0>  // b.hs, b.nlast
    7680:	d2800042 	mov	x2, #0x2                   	// #2
    7684:	aa1603e1 	mov	x1, x22
    7688:	aa1403e0 	mov	x0, x20
    768c:	97ffefe1 	bl	3610 <buf_put>
    7690:	f9401f82 	ldr	x2, [x28, #56]
    7694:	f9400263 	ldr	x3, [x19]
    7698:	b5fffbc2 	cbnz	x2, 7610 <fwp_write+0x48c>
    769c:	d37df2a0 	lsl	x0, x21, #3
    76a0:	b7f83f03 	tbnz	x3, #63, 7e80 <fwp_write+0xcfc>
    76a4:	91002261 	add	x1, x19, #0x8
    76a8:	8b000020 	add	x0, x1, x0
    76ac:	f9400001 	ldr	x1, [x0]
    76b0:	17ffffec 	b	7660 <fwp_write+0x4dc>
    76b4:	a9400e62 	ldp	x2, x3, [x19]
    76b8:	b7f83ca3 	tbnz	x3, #63, 7e4c <fwp_write+0xcc8>
    76bc:	910123f5 	add	x21, sp, #0x48
    76c0:	aa1503e0 	mov	x0, x21
    76c4:	97ffedf7 	bl	2ea0 <fwp_fmt_u128>
    76c8:	aa1503e0 	mov	x0, x21
    76cc:	97ffec35 	bl	27a0 <strlen@plt>
    76d0:	aa1503e1 	mov	x1, x21
    76d4:	aa0003e2 	mov	x2, x0
    76d8:	17fffed1 	b	721c <fwp_write+0x98>
    76dc:	fd015be8 	str	d8, [sp, #688]
    76e0:	1e270268 	fmov	s8, w19
    76e4:	fd015fe9 	str	d9, [sp, #696]
    76e8:	1e282100 	fcmp	s8, s8
    76ec:	54004d26 	b.vs	8090 <fwp_write+0xf0c>
    76f0:	1e20c101 	fabs	s1, s8
    76f4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    76f8:	1e270000 	fmov	s0, w0
    76fc:	1e202020 	fcmp	s1, s0
    7700:	54002c0d 	b.le	7c80 <fwp_write+0xafc>
    7704:	1e202118 	fcmpe	s8, #0.0
    7708:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1e90>
    770c:	91316042 	add	x2, x2, #0xc58
    7710:	910123f5 	add	x21, sp, #0x48
    7714:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7718:	9100c021 	add	x1, x1, #0x30
    771c:	aa1503e0 	mov	x0, x21
    7720:	9a81c041 	csel	x1, x2, x1, gt
    7724:	97ffeccb 	bl	2a50 <strcpy@plt>
    7728:	aa1503e0 	mov	x0, x21
    772c:	97ffec1d 	bl	27a0 <strlen@plt>
    7730:	aa1503e1 	mov	x1, x21
    7734:	aa0003e2 	mov	x2, x0
    7738:	aa1403e0 	mov	x0, x20
    773c:	97ffefb5 	bl	3610 <buf_put>
    7740:	f9413bf5 	ldr	x21, [sp, #624]
    7744:	f9413ff6 	ldr	x22, [sp, #632]
    7748:	f94153fb 	ldr	x27, [sp, #672]
    774c:	f94157fc 	ldr	x28, [sp, #680]
    7750:	fd415be8 	ldr	d8, [sp, #688]
    7754:	fd415fe9 	ldr	d9, [sp, #696]
    7758:	17fffeb7 	b	7234 <fwp_write+0xb0>
    775c:	f9400276 	ldr	x22, [x19]
    7760:	34002e03 	cbz	w3, 7d20 <fwp_write+0xb9c>
    7764:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7768:	f947f400 	ldr	x0, [x0, #4072]
    776c:	f94127e2 	ldr	x2, [sp, #584]
    7770:	f9400001 	ldr	x1, [x0]
    7774:	eb010042 	subs	x2, x2, x1
    7778:	d2800001 	mov	x1, #0x0                   	// #0
    777c:	540014a1 	b.ne	7a10 <fwp_write+0x88c>  // b.any
    7780:	aa1603e2 	mov	x2, x22
    7784:	91002261 	add	x1, x19, #0x8
    7788:	f9413bf5 	ldr	x21, [sp, #624]
    778c:	aa1403e0 	mov	x0, x20
    7790:	f9413ff6 	ldr	x22, [sp, #632]
    7794:	17ffff00 	b	7394 <fwp_write+0x210>
    7798:	fd015be8 	str	d8, [sp, #688]
    779c:	9e670268 	fmov	d8, x19
    77a0:	fd015fe9 	str	d9, [sp, #696]
    77a4:	1e682100 	fcmp	d8, d8
    77a8:	54004746 	b.vs	8090 <fwp_write+0xf0c>
    77ac:	1e60c101 	fabs	d1, d8
    77b0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    77b4:	9e670000 	fmov	d0, x0
    77b8:	910123f5 	add	x21, sp, #0x48
    77bc:	52800033 	mov	w19, #0x1                   	// #1
    77c0:	1e602020 	fcmp	d1, d0
    77c4:	540001ad 	b.le	77f8 <fwp_write+0x674>
    77c8:	1e602118 	fcmpe	d8, #0.0
    77cc:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1e90>
    77d0:	91316042 	add	x2, x2, #0xc58
    77d4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    77d8:	9100c021 	add	x1, x1, #0x30
    77dc:	aa1503e0 	mov	x0, x21
    77e0:	9a81c041 	csel	x1, x2, x1, gt
    77e4:	97ffec9b 	bl	2a50 <strcpy@plt>
    77e8:	17ffffd0 	b	7728 <fwp_write+0x5a4>
    77ec:	11000673 	add	w19, w19, #0x1
    77f0:	71004a7f 	cmp	w19, #0x12
    77f4:	54003860 	b.eq	7f00 <fwp_write+0xd7c>  // b.none
    77f8:	1e604100 	fmov	d0, d8
    77fc:	2a1303e1 	mov	w1, w19
    7800:	aa1503e0 	mov	x0, x21
    7804:	97fff104 	bl	3c14 <fwp_format_g.constprop.0>
    7808:	aa1503e0 	mov	x0, x21
    780c:	d2800001 	mov	x1, #0x0                   	// #0
    7810:	97ffebf8 	bl	27f0 <strtod@plt>
    7814:	1e602100 	fcmp	d8, d0
    7818:	54fffea1 	b.ne	77ec <fwp_write+0x668>  // b.any
    781c:	aa1503e0 	mov	x0, x21
    7820:	97ffeff5 	bl	37f4 <fwp_finish_float>
    7824:	17ffffc1 	b	7728 <fwp_write+0x5a4>
    7828:	a9400e62 	ldp	x2, x3, [x19]
    782c:	910123f3 	add	x19, sp, #0x48
    7830:	aa1303e0 	mov	x0, x19
    7834:	97ffed9b 	bl	2ea0 <fwp_fmt_u128>
    7838:	17fffe75 	b	720c <fwp_write+0x88>
    783c:	f90143f7 	str	x23, [sp, #640]
    7840:	f90147f8 	str	x24, [sp, #648]
    7844:	2a1303f8 	mov	w24, w19
    7848:	f9014bf9 	str	x25, [sp, #656]
    784c:	f9014ffa 	str	x26, [sp, #664]
    7850:	f13ffe7f 	cmp	x19, #0xfff
    7854:	54000049 	b.ls	785c <fwp_write+0x6d8>  // b.plast
    7858:	b9400278 	ldr	w24, [x19]
    785c:	f9400f80 	ldr	x0, [x28, #24]
    7860:	2a1803f5 	mov	w21, w24
    7864:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7868:	d37ef6b9 	lsl	x25, x21, #2
    786c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7870:	aa1603e0 	mov	x0, x22
    7874:	97ffebcb 	bl	27a0 <strlen@plt>
    7878:	aa1603e1 	mov	x1, x22
    787c:	aa0003e2 	mov	x2, x0
    7880:	aa1403e0 	mov	x0, x20
    7884:	97ffef63 	bl	3610 <buf_put>
    7888:	f9401780 	ldr	x0, [x28, #40]
    788c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7890:	7100001f 	cmp	w0, #0x0
    7894:	5400068d 	b.le	7964 <fwp_write+0x7e0>
    7898:	91002276 	add	x22, x19, #0x8
    789c:	91001ff5 	add	x21, sp, #0x7
    78a0:	d280001b 	mov	x27, #0x0                   	// #0
    78a4:	5280041a 	mov	w26, #0x20                  	// #32
    78a8:	f9401b80 	ldr	x0, [x28, #48]
    78ac:	aa1503e1 	mov	x1, x21
    78b0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    78b4:	d2800022 	mov	x2, #0x1                   	// #1
    78b8:	f8786803 	ldr	x3, [x0, x24]
    78bc:	aa1403e0 	mov	x0, x20
    78c0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    78c4:	39001ffa 	strb	w26, [sp, #7]
    78c8:	97ffef52 	bl	3610 <buf_put>
    78cc:	f13ffeff 	cmp	x23, #0xfff
    78d0:	b9400261 	ldr	w1, [x19]
    78d4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    78d8:	7100383f 	cmp	w1, #0xe
    78dc:	54000160 	b.eq	7908 <fwp_write+0x784>  // b.none
    78e0:	7100403f 	cmp	w1, #0x10
    78e4:	54001a60 	b.eq	7c30 <fwp_write+0xaac>  // b.none
    78e8:	7100283f 	cmp	w1, #0xa
    78ec:	54002aa0 	b.eq	7e40 <fwp_write+0xcbc>  // b.none
    78f0:	540014ac 	b.gt	7b84 <fwp_write+0xa00>
    78f4:	71000c3f 	cmp	w1, #0x3
    78f8:	540029ac 	b.gt	7e2c <fwp_write+0xca8>
    78fc:	d37ffee0 	lsr	x0, x23, #63
    7900:	37f814a1 	tbnz	w1, #31, 7b94 <fwp_write+0xa10>
    7904:	d503201f 	nop
    7908:	34001460 	cbz	w0, 7b94 <fwp_write+0xa10>
    790c:	52800503 	mov	w3, #0x28                  	// #40
    7910:	aa1503e1 	mov	x1, x21
    7914:	aa1403e0 	mov	x0, x20
    7918:	d2800022 	mov	x2, #0x1                   	// #1
    791c:	39001fe3 	strb	w3, [sp, #7]
    7920:	97ffef3c 	bl	3610 <buf_put>
    7924:	aa1303e2 	mov	x2, x19
    7928:	aa1703e1 	mov	x1, x23
    792c:	aa1403e0 	mov	x0, x20
    7930:	52800003 	mov	w3, #0x0                   	// #0
    7934:	97fffe14 	bl	7184 <fwp_write>
    7938:	52800523 	mov	w3, #0x29                  	// #41
    793c:	aa1503e1 	mov	x1, x21
    7940:	aa1403e0 	mov	x0, x20
    7944:	d2800022 	mov	x2, #0x1                   	// #1
    7948:	39001fe3 	strb	w3, [sp, #7]
    794c:	97ffef31 	bl	3610 <buf_put>
    7950:	f9401780 	ldr	x0, [x28, #40]
    7954:	9100077b 	add	x27, x27, #0x1
    7958:	b8796800 	ldr	w0, [x0, x25]
    795c:	6b1b001f 	cmp	w0, w27
    7960:	54fffa4c 	b.gt	78a8 <fwp_write+0x724>
    7964:	f9413bf5 	ldr	x21, [sp, #624]
    7968:	f9413ff6 	ldr	x22, [sp, #632]
    796c:	f94143f7 	ldr	x23, [sp, #640]
    7970:	f94147f8 	ldr	x24, [sp, #648]
    7974:	f9414bf9 	ldr	x25, [sp, #656]
    7978:	f9414ffa 	ldr	x26, [sp, #664]
    797c:	f94153fb 	ldr	x27, [sp, #672]
    7980:	f94157fc 	ldr	x28, [sp, #680]
    7984:	17fffe2c 	b	7234 <fwp_write+0xb0>
    7988:	52800783 	mov	w3, #0x3c                  	// #60
    798c:	91001ff3 	add	x19, sp, #0x7
    7990:	aa1303e1 	mov	x1, x19
    7994:	d2800022 	mov	x2, #0x1                   	// #1
    7998:	aa1403e0 	mov	x0, x20
    799c:	39001fe3 	strb	w3, [sp, #7]
    79a0:	97ffef1c 	bl	3610 <buf_put>
    79a4:	f9400795 	ldr	x21, [x28, #8]
    79a8:	aa1503e0 	mov	x0, x21
    79ac:	97ffeb7d 	bl	27a0 <strlen@plt>
    79b0:	aa1503e1 	mov	x1, x21
    79b4:	aa0003e2 	mov	x2, x0
    79b8:	aa1403e0 	mov	x0, x20
    79bc:	97ffef15 	bl	3610 <buf_put>
    79c0:	528007c3 	mov	w3, #0x3e                  	// #62
    79c4:	aa1303e1 	mov	x1, x19
    79c8:	aa1403e0 	mov	x0, x20
    79cc:	d2800022 	mov	x2, #0x1                   	// #1
    79d0:	39001fe3 	strb	w3, [sp, #7]
    79d4:	17fffe13 	b	7220 <fwp_write+0x9c>
    79d8:	f100067f 	cmp	x19, #0x1
    79dc:	540025a0 	b.eq	7e90 <fwp_write+0xd0c>  // b.none
    79e0:	b100067f 	cmn	x19, #0x1
    79e4:	54002bc0 	b.eq	7f5c <fwp_write+0xdd8>  // b.none
    79e8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    79ec:	9100e021 	add	x1, x1, #0x38
    79f0:	d2800022 	mov	x2, #0x1                   	// #1
    79f4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    79f8:	f947f400 	ldr	x0, [x0, #4072]
    79fc:	f94127e4 	ldr	x4, [sp, #584]
    7a00:	f9400003 	ldr	x3, [x0]
    7a04:	eb030084 	subs	x4, x4, x3
    7a08:	d2800003 	mov	x3, #0x0                   	// #0
    7a0c:	54ffebe0 	b.eq	7788 <fwp_write+0x604>  // b.none
    7a10:	f90143f7 	str	x23, [sp, #640]
    7a14:	f90147f8 	str	x24, [sp, #648]
    7a18:	f9014bf9 	str	x25, [sp, #656]
    7a1c:	f9014ffa 	str	x26, [sp, #664]
    7a20:	fd015be8 	str	d8, [sp, #688]
    7a24:	fd015fe9 	str	d9, [sp, #696]
    7a28:	97ffebba 	bl	2910 <__stack_chk_fail@plt>
    7a2c:	52800b63 	mov	w3, #0x5b                  	// #91
    7a30:	91001ff5 	add	x21, sp, #0x7
    7a34:	aa1503e1 	mov	x1, x21
    7a38:	aa1403e0 	mov	x0, x20
    7a3c:	d2800022 	mov	x2, #0x1                   	// #1
    7a40:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x480>
    7a44:	910362d6 	add	x22, x22, #0xd8
    7a48:	39001fe3 	strb	w3, [sp, #7]
    7a4c:	97ffeef1 	bl	3610 <buf_put>
    7a50:	b4000273 	cbz	x19, 7a9c <fwp_write+0x918>
    7a54:	f9400661 	ldr	x1, [x19, #8]
    7a58:	aa1403e0 	mov	x0, x20
    7a5c:	f9401f82 	ldr	x2, [x28, #56]
    7a60:	52800003 	mov	w3, #0x0                   	// #0
    7a64:	97fffdc8 	bl	7184 <fwp_write>
    7a68:	f9400a73 	ldr	x19, [x19, #16]
    7a6c:	b4000193 	cbz	x19, 7a9c <fwp_write+0x918>
    7a70:	aa1603e1 	mov	x1, x22
    7a74:	aa1403e0 	mov	x0, x20
    7a78:	d2800042 	mov	x2, #0x2                   	// #2
    7a7c:	97ffeee5 	bl	3610 <buf_put>
    7a80:	f9400661 	ldr	x1, [x19, #8]
    7a84:	aa1403e0 	mov	x0, x20
    7a88:	f9401f82 	ldr	x2, [x28, #56]
    7a8c:	52800003 	mov	w3, #0x0                   	// #0
    7a90:	97fffdbd 	bl	7184 <fwp_write>
    7a94:	f9400a73 	ldr	x19, [x19, #16]
    7a98:	b5fffed3 	cbnz	x19, 7a70 <fwp_write+0x8ec>
    7a9c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7aa0:	aa1503e1 	mov	x1, x21
    7aa4:	aa1403e0 	mov	x0, x20
    7aa8:	d2800022 	mov	x2, #0x1                   	// #1
    7aac:	39001fe3 	strb	w3, [sp, #7]
    7ab0:	17fffddc 	b	7220 <fwp_write+0x9c>
    7ab4:	aa1403e0 	mov	x0, x20
    7ab8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7abc:	d28000c2 	mov	x2, #0x6                   	// #6
    7ac0:	91032021 	add	x1, x1, #0xc8
    7ac4:	97ffeed3 	bl	3610 <buf_put>
    7ac8:	f9400260 	ldr	x0, [x19]
    7acc:	b40004c0 	cbz	x0, 7b64 <fwp_write+0x9e0>
    7ad0:	910123f5 	add	x21, sp, #0x48
    7ad4:	91002276 	add	x22, x19, #0x8
    7ad8:	f90143f7 	str	x23, [sp, #640]
    7adc:	d2800017 	mov	x23, #0x0                   	// #0
    7ae0:	f90147f8 	str	x24, [sp, #648]
    7ae4:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x480>
    7ae8:	91034318 	add	x24, x24, #0xd0
    7aec:	f9014bf9 	str	x25, [sp, #656]
    7af0:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x480>
    7af4:	91036339 	add	x25, x25, #0xd8
    7af8:	f9014ffa 	str	x26, [sp, #664]
    7afc:	14000005 	b	7b10 <fwp_write+0x98c>
    7b00:	aa1903e1 	mov	x1, x25
    7b04:	aa1403e0 	mov	x0, x20
    7b08:	d2800042 	mov	x2, #0x2                   	// #2
    7b0c:	97ffeec1 	bl	3610 <buf_put>
    7b10:	38776ac5 	ldrb	w5, [x22, x23]
    7b14:	d2804003 	mov	x3, #0x200                 	// #512
    7b18:	aa1803e4 	mov	x4, x24
    7b1c:	aa0303e1 	mov	x1, x3
    7b20:	52800042 	mov	w2, #0x2                   	// #2
    7b24:	aa1503e0 	mov	x0, x21
    7b28:	910006f7 	add	x23, x23, #0x1
    7b2c:	97ffeb55 	bl	2880 <__snprintf_chk@plt>
    7b30:	aa1503e0 	mov	x0, x21
    7b34:	97ffeb1b 	bl	27a0 <strlen@plt>
    7b38:	aa1503e1 	mov	x1, x21
    7b3c:	aa0003e2 	mov	x2, x0
    7b40:	aa1403e0 	mov	x0, x20
    7b44:	97ffeeb3 	bl	3610 <buf_put>
    7b48:	f9400260 	ldr	x0, [x19]
    7b4c:	eb17001f 	cmp	x0, x23
    7b50:	54fffd88 	b.hi	7b00 <fwp_write+0x97c>  // b.pmore
    7b54:	f94143f7 	ldr	x23, [sp, #640]
    7b58:	f94147f8 	ldr	x24, [sp, #648]
    7b5c:	f9414bf9 	ldr	x25, [sp, #656]
    7b60:	f9414ffa 	ldr	x26, [sp, #664]
    7b64:	52800ba3 	mov	w3, #0x5d                  	// #93
    7b68:	aa1403e0 	mov	x0, x20
    7b6c:	91001fe1 	add	x1, sp, #0x7
    7b70:	d2800022 	mov	x2, #0x1                   	// #1
    7b74:	39001fe3 	strb	w3, [sp, #7]
    7b78:	17fffdaa 	b	7220 <fwp_write+0x9c>
    7b7c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7b80:	17fffe45 	b	7494 <fwp_write+0x310>
    7b84:	f10002ff 	cmp	x23, #0x0
    7b88:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7b8c:	71002c3f 	cmp	w1, #0xb
    7b90:	54ffebc0 	b.eq	7908 <fwp_write+0x784>  // b.none
    7b94:	aa1303e2 	mov	x2, x19
    7b98:	aa1703e1 	mov	x1, x23
    7b9c:	aa1403e0 	mov	x0, x20
    7ba0:	52800003 	mov	w3, #0x0                   	// #0
    7ba4:	97fffd78 	bl	7184 <fwp_write>
    7ba8:	17ffff6a 	b	7950 <fwp_write+0x7cc>
    7bac:	aa1403e0 	mov	x0, x20
    7bb0:	91001fe1 	add	x1, sp, #0x7
    7bb4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7bb8:	d2800022 	mov	x2, #0x1                   	// #1
    7bbc:	17fffe39 	b	74a0 <fwp_write+0x31c>
    7bc0:	a9400281 	ldp	x1, x0, [x20]
    7bc4:	91000800 	add	x0, x0, #0x2
    7bc8:	8b160000 	add	x0, x0, x22
    7bcc:	f9000680 	str	x0, [x20, #8]
    7bd0:	3820683f 	strb	wzr, [x1, x0]
    7bd4:	f9413bf5 	ldr	x21, [sp, #624]
    7bd8:	f9413ff6 	ldr	x22, [sp, #632]
    7bdc:	f94153fb 	ldr	x27, [sp, #672]
    7be0:	f94157fc 	ldr	x28, [sp, #680]
    7be4:	17fffd94 	b	7234 <fwp_write+0xb0>
    7be8:	f9400f80 	ldr	x0, [x28, #24]
    7bec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7bf0:	aa1b03e0 	mov	x0, x27
    7bf4:	97ffeaeb 	bl	27a0 <strlen@plt>
    7bf8:	aa1b03e1 	mov	x1, x27
    7bfc:	aa0003e2 	mov	x2, x0
    7c00:	aa1403e0 	mov	x0, x20
    7c04:	97ffee83 	bl	3610 <buf_put>
    7c08:	aa1903e1 	mov	x1, x25
    7c0c:	aa1403e0 	mov	x0, x20
    7c10:	d2800062 	mov	x2, #0x3                   	// #3
    7c14:	97ffee7f 	bl	3610 <buf_put>
    7c18:	17fffe11 	b	745c <fwp_write+0x2d8>
    7c1c:	aa1a03e1 	mov	x1, x26
    7c20:	aa1403e0 	mov	x0, x20
    7c24:	d2800042 	mov	x2, #0x2                   	// #2
    7c28:	97ffee7a 	bl	3610 <buf_put>
    7c2c:	17fffe0a 	b	7454 <fwp_write+0x2d0>
    7c30:	f9400660 	ldr	x0, [x19, #8]
    7c34:	b4fffb00 	cbz	x0, 7b94 <fwp_write+0xa10>
    7c38:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7c3c:	9103c021 	add	x1, x1, #0xf0
    7c40:	97ffeb54 	bl	2990 <strcmp@plt>
    7c44:	7100001f 	cmp	w0, #0x0
    7c48:	1a9f07e0 	cset	w0, ne	// ne = any
    7c4c:	17ffff2f 	b	7908 <fwp_write+0x784>
    7c50:	aa1403e0 	mov	x0, x20
    7c54:	d2800042 	mov	x2, #0x2                   	// #2
    7c58:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7c5c:	9103a021 	add	x1, x1, #0xe8
    7c60:	97ffee6c 	bl	3610 <buf_put>
    7c64:	91004261 	add	x1, x19, #0x10
    7c68:	aa1403e0 	mov	x0, x20
    7c6c:	f9402382 	ldr	x2, [x28, #64]
    7c70:	52800003 	mov	w3, #0x0                   	// #0
    7c74:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7c78:	97fffd43 	bl	7184 <fwp_write>
    7c7c:	17fffd9d 	b	72f0 <fwp_write+0x16c>
    7c80:	1e22c109 	fcvt	d9, s8
    7c84:	910123f5 	add	x21, sp, #0x48
    7c88:	52800033 	mov	w19, #0x1                   	// #1
    7c8c:	d503201f 	nop
    7c90:	1e604120 	fmov	d0, d9
    7c94:	2a1303e1 	mov	w1, w19
    7c98:	aa1503e0 	mov	x0, x21
    7c9c:	97ffefde 	bl	3c14 <fwp_format_g.constprop.0>
    7ca0:	aa1503e0 	mov	x0, x21
    7ca4:	d2800001 	mov	x1, #0x0                   	// #0
    7ca8:	97ffeb46 	bl	29c0 <strtof@plt>
    7cac:	1e202100 	fcmp	s8, s0
    7cb0:	54ffdb60 	b.eq	781c <fwp_write+0x698>  // b.none
    7cb4:	11000673 	add	w19, w19, #0x1
    7cb8:	71002a7f 	cmp	w19, #0xa
    7cbc:	54fffea1 	b.ne	7c90 <fwp_write+0xb0c>  // b.any
    7cc0:	1e604120 	fmov	d0, d9
    7cc4:	aa1503e0 	mov	x0, x21
    7cc8:	52800121 	mov	w1, #0x9                   	// #9
    7ccc:	97ffefd2 	bl	3c14 <fwp_format_g.constprop.0>
    7cd0:	17fffed3 	b	781c <fwp_write+0x698>
    7cd4:	d37ef6a1 	lsl	x1, x21, #2
    7cd8:	b7f81563 	tbnz	x3, #63, 7f84 <fwp_write+0xe00>
    7cdc:	91002263 	add	x3, x19, #0x8
    7ce0:	8b010061 	add	x1, x3, x1
    7ce4:	b9400023 	ldr	w3, [x1]
    7ce8:	7100081f 	cmp	w0, #0x2
    7cec:	2a0303e1 	mov	w1, w3
    7cf0:	93407c63 	sxtw	x3, w3
    7cf4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7cf8:	17fffe5a 	b	7660 <fwp_write+0x4dc>
    7cfc:	d37ffaa1 	lsl	x1, x21, #1
    7d00:	b7f81363 	tbnz	x3, #63, 7f6c <fwp_write+0xde8>
    7d04:	91002263 	add	x3, x19, #0x8
    7d08:	8b010061 	add	x1, x3, x1
    7d0c:	79400021 	ldrh	w1, [x1]
    7d10:	7100041f 	cmp	w0, #0x1
    7d14:	93403c23 	sxth	x3, w1
    7d18:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7d1c:	17fffe51 	b	7660 <fwp_write+0x4dc>
    7d20:	52800443 	mov	w3, #0x22                  	// #34
    7d24:	91001ff5 	add	x21, sp, #0x7
    7d28:	91002273 	add	x19, x19, #0x8
    7d2c:	aa1503e1 	mov	x1, x21
    7d30:	aa1403e0 	mov	x0, x20
    7d34:	d2800022 	mov	x2, #0x1                   	// #1
    7d38:	39001fe3 	strb	w3, [sp, #7]
    7d3c:	f90143f7 	str	x23, [sp, #640]
    7d40:	8b160277 	add	x23, x19, x22
    7d44:	f90147f8 	str	x24, [sp, #648]
    7d48:	97ffee32 	bl	3610 <buf_put>
    7d4c:	b4000696 	cbz	x22, 7e1c <fwp_write+0xc98>
    7d50:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x480>
    7d54:	91026318 	add	x24, x24, #0x98
    7d58:	f9014bf9 	str	x25, [sp, #656]
    7d5c:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x480>
    7d60:	9102e339 	add	x25, x25, #0xb8
    7d64:	f9014ffa 	str	x26, [sp, #664]
    7d68:	1400000d 	b	7d9c <fwp_write+0xc18>
    7d6c:	710024bf 	cmp	w5, #0x9
    7d70:	54000460 	b.eq	7dfc <fwp_write+0xc78>  // b.none
    7d74:	710028bf 	cmp	w5, #0xa
    7d78:	54000a61 	b.ne	7ec4 <fwp_write+0xd40>  // b.any
    7d7c:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	9102a021 	add	x1, x1, #0xa8
    7d88:	d2800042 	mov	x2, #0x2                   	// #2
    7d8c:	97ffee21 	bl	3610 <buf_put>
    7d90:	91000673 	add	x19, x19, #0x1
    7d94:	eb17027f 	cmp	x19, x23
    7d98:	540003e0 	b.eq	7e14 <fwp_write+0xc90>  // b.none
    7d9c:	39400265 	ldrb	w5, [x19]
    7da0:	710034bf 	cmp	w5, #0xd
    7da4:	54000180 	b.eq	7dd4 <fwp_write+0xc50>  // b.none
    7da8:	54fffe29 	b.ls	7d6c <fwp_write+0xbe8>  // b.plast
    7dac:	710088bf 	cmp	w5, #0x22
    7db0:	540001c0 	b.eq	7de8 <fwp_write+0xc64>  // b.none
    7db4:	710170bf 	cmp	w5, #0x5c
    7db8:	54000741 	b.ne	7ea0 <fwp_write+0xd1c>  // b.any
    7dbc:	aa1403e0 	mov	x0, x20
    7dc0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7dc4:	d2800042 	mov	x2, #0x2                   	// #2
    7dc8:	91028021 	add	x1, x1, #0xa0
    7dcc:	97ffee11 	bl	3610 <buf_put>
    7dd0:	17fffff0 	b	7d90 <fwp_write+0xc0c>
    7dd4:	aa1903e1 	mov	x1, x25
    7dd8:	aa1403e0 	mov	x0, x20
    7ddc:	d2800042 	mov	x2, #0x2                   	// #2
    7de0:	97ffee0c 	bl	3610 <buf_put>
    7de4:	17ffffeb 	b	7d90 <fwp_write+0xc0c>
    7de8:	aa1803e1 	mov	x1, x24
    7dec:	aa1403e0 	mov	x0, x20
    7df0:	d2800042 	mov	x2, #0x2                   	// #2
    7df4:	97ffee07 	bl	3610 <buf_put>
    7df8:	17ffffe6 	b	7d90 <fwp_write+0xc0c>
    7dfc:	aa1403e0 	mov	x0, x20
    7e00:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7e04:	d2800042 	mov	x2, #0x2                   	// #2
    7e08:	9102c021 	add	x1, x1, #0xb0
    7e0c:	97ffee01 	bl	3610 <buf_put>
    7e10:	17ffffe0 	b	7d90 <fwp_write+0xc0c>
    7e14:	f9414bf9 	ldr	x25, [sp, #656]
    7e18:	f9414ffa 	ldr	x26, [sp, #664]
    7e1c:	aa1503e1 	mov	x1, x21
    7e20:	aa1403e0 	mov	x0, x20
    7e24:	52800443 	mov	w3, #0x22                  	// #34
    7e28:	17fffd9d 	b	749c <fwp_write+0x318>
    7e2c:	7100103f 	cmp	w1, #0x4
    7e30:	54ffeb21 	b.ne	7b94 <fwp_write+0xa10>  // b.any
    7e34:	f94006e0 	ldr	x0, [x23, #8]
    7e38:	d37ffc00 	lsr	x0, x0, #63
    7e3c:	17fffeb3 	b	7908 <fwp_write+0x784>
    7e40:	710002ff 	cmp	w23, #0x0
    7e44:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7e48:	17fffeb0 	b	7908 <fwp_write+0x784>
    7e4c:	528005a1 	mov	w1, #0x2d                  	// #45
    7e50:	eb0203e2 	negs	x2, x2
    7e54:	da0303e3 	ngc	x3, x3
    7e58:	910127e0 	add	x0, sp, #0x49
    7e5c:	910123f5 	add	x21, sp, #0x48
    7e60:	390123e1 	strb	w1, [sp, #72]
    7e64:	97ffec0f 	bl	2ea0 <fwp_fmt_u128>
    7e68:	17fffe18 	b	76c8 <fwp_write+0x544>
    7e6c:	d37ceea1 	lsl	x1, x21, #4
    7e70:	b7f810a3 	tbnz	x3, #63, 8084 <fwp_write+0xf00>
    7e74:	91002260 	add	x0, x19, #0x8
    7e78:	8b010001 	add	x1, x0, x1
    7e7c:	17fffdf9 	b	7660 <fwp_write+0x4dc>
    7e80:	f9400a61 	ldr	x1, [x19, #16]
    7e84:	8b010000 	add	x0, x0, x1
    7e88:	f9400001 	ldr	x1, [x0]
    7e8c:	17fffdf5 	b	7660 <fwp_write+0x4dc>
    7e90:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7e94:	d2800042 	mov	x2, #0x2                   	// #2
    7e98:	91010021 	add	x1, x1, #0x40
    7e9c:	17fffed6 	b	79f4 <fwp_write+0x870>
    7ea0:	7101fcbf 	cmp	w5, #0x7f
    7ea4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7ea8:	540000e9 	b.ls	7ec4 <fwp_write+0xd40>  // b.plast
    7eac:	aa1503e1 	mov	x1, x21
    7eb0:	aa1403e0 	mov	x0, x20
    7eb4:	d2800022 	mov	x2, #0x1                   	// #1
    7eb8:	39001fe5 	strb	w5, [sp, #7]
    7ebc:	97ffedd5 	bl	3610 <buf_put>
    7ec0:	17ffffb4 	b	7d90 <fwp_write+0xc0c>
    7ec4:	d2800203 	mov	x3, #0x10                  	// #16
    7ec8:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x480>
    7ecc:	aa0303e1 	mov	x1, x3
    7ed0:	91030084 	add	x4, x4, #0xc0
    7ed4:	910123f6 	add	x22, sp, #0x48
    7ed8:	52800042 	mov	w2, #0x2                   	// #2
    7edc:	aa1603e0 	mov	x0, x22
    7ee0:	97ffea68 	bl	2880 <__snprintf_chk@plt>
    7ee4:	aa1603e0 	mov	x0, x22
    7ee8:	97ffea2e 	bl	27a0 <strlen@plt>
    7eec:	aa1603e1 	mov	x1, x22
    7ef0:	aa0003e2 	mov	x2, x0
    7ef4:	aa1403e0 	mov	x0, x20
    7ef8:	97ffedc6 	bl	3610 <buf_put>
    7efc:	17ffffa5 	b	7d90 <fwp_write+0xc0c>
    7f00:	1e604100 	fmov	d0, d8
    7f04:	aa1503e0 	mov	x0, x21
    7f08:	52800221 	mov	w1, #0x11                  	// #17
    7f0c:	97ffef42 	bl	3c14 <fwp_format_g.constprop.0>
    7f10:	17fffe43 	b	781c <fwp_write+0x698>
    7f14:	b9401040 	ldr	w0, [x2, #16]
    7f18:	350003c0 	cbnz	w0, 7f90 <fwp_write+0xe0c>
    7f1c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7f20:	f947f400 	ldr	x0, [x0, #4072]
    7f24:	f94127e2 	ldr	x2, [sp, #584]
    7f28:	f9400001 	ldr	x1, [x0]
    7f2c:	eb010042 	subs	x2, x2, x1
    7f30:	d2800001 	mov	x1, #0x0                   	// #0
    7f34:	54ffd721 	b.ne	7a18 <fwp_write+0x894>  // b.any
    7f38:	f9413bf5 	ldr	x21, [sp, #624]
    7f3c:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7f40:	f9413ff6 	ldr	x22, [sp, #632]
    7f44:	aa1403e0 	mov	x0, x20
    7f48:	f94143f7 	ldr	x23, [sp, #640]
    7f4c:	91044021 	add	x1, x1, #0x110
    7f50:	f94147f8 	ldr	x24, [sp, #648]
    7f54:	d2800042 	mov	x2, #0x2                   	// #2
    7f58:	17fffd0f 	b	7394 <fwp_write+0x210>
    7f5c:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x480>
    7f60:	d2800042 	mov	x2, #0x2                   	// #2
    7f64:	91012021 	add	x1, x1, #0x48
    7f68:	17fffea3 	b	79f4 <fwp_write+0x870>
    7f6c:	f9400a63 	ldr	x3, [x19, #16]
    7f70:	8b030021 	add	x1, x1, x3
    7f74:	17ffff66 	b	7d0c <fwp_write+0xb88>
    7f78:	f9400a61 	ldr	x1, [x19, #16]
    7f7c:	8b0102a1 	add	x1, x21, x1
    7f80:	17fffdb4 	b	7650 <fwp_write+0x4cc>
    7f84:	f9400a63 	ldr	x3, [x19, #16]
    7f88:	8b030021 	add	x1, x1, x3
    7f8c:	17ffff56 	b	7ce4 <fwp_write+0xb60>
    7f90:	b9404840 	ldr	w0, [x2, #72]
    7f94:	91001ff5 	add	x21, sp, #0x7
    7f98:	34ffa380 	cbz	w0, 7408 <fwp_write+0x284>
    7f9c:	52800503 	mov	w3, #0x28                  	// #40
    7fa0:	aa1403e0 	mov	x0, x20
    7fa4:	aa1503e1 	mov	x1, x21
    7fa8:	d2800022 	mov	x2, #0x1                   	// #1
    7fac:	39001fe3 	strb	w3, [sp, #7]
    7fb0:	97ffed98 	bl	3610 <buf_put>
    7fb4:	b9401380 	ldr	w0, [x28, #16]
    7fb8:	52800038 	mov	w24, #0x1                   	// #1
    7fbc:	7100001f 	cmp	w0, #0x0
    7fc0:	54ffa38c 	b.gt	7430 <fwp_write+0x2ac>
    7fc4:	17fffd33 	b	7490 <fwp_write+0x30c>
    7fc8:	f9014bf9 	str	x25, [sp, #656]
    7fcc:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x112f0>
    7fd0:	f9014ffa 	str	x26, [sp, #664]
    7fd4:	f9400676 	ldr	x22, [x19, #8]
    7fd8:	910aa333 	add	x19, x25, #0x2a8
    7fdc:	91002273 	add	x19, x19, #0x8
    7fe0:	937ffed8 	asr	x24, x22, #63
    7fe4:	aa1802c0 	orr	x0, x22, x24
    7fe8:	b5000320 	cbnz	x0, 804c <fwp_write+0xec8>
    7fec:	110006b5 	add	w21, w21, #0x1
    7ff0:	710016bf 	cmp	w21, #0x5
    7ff4:	54ffffc1 	b.ne	7fec <fwp_write+0xe68>  // b.any
    7ff8:	b7f80578 	tbnz	x24, #63, 80a4 <fwp_write+0xf20>
    7ffc:	910023f3 	add	x19, sp, #0x8
    8000:	aa1603e2 	mov	x2, x22
    8004:	aa1303e0 	mov	x0, x19
    8008:	d2800003 	mov	x3, #0x0                   	// #0
    800c:	97ffeba5 	bl	2ea0 <fwp_fmt_u128>
    8010:	910123f5 	add	x21, sp, #0x48
    8014:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x480>
    8018:	aa1303e4 	mov	x4, x19
    801c:	aa1503e0 	mov	x0, x21
    8020:	91042063 	add	x3, x3, #0x108
    8024:	d2804002 	mov	x2, #0x200                 	// #512
    8028:	52800041 	mov	w1, #0x2                   	// #2
    802c:	97ffe9e1 	bl	27b0 <__sprintf_chk@plt>
    8030:	aa1503e0 	mov	x0, x21
    8034:	97ffe9db 	bl	27a0 <strlen@plt>
    8038:	aa1503e1 	mov	x1, x21
    803c:	aa0003e2 	mov	x2, x0
    8040:	aa1403e0 	mov	x0, x20
    8044:	97ffed73 	bl	3610 <buf_put>
    8048:	17fffe47 	b	7964 <fwp_write+0x7e0>
    804c:	f9400277 	ldr	x23, [x19]
    8050:	aa1603e0 	mov	x0, x22
    8054:	aa1803e1 	mov	x1, x24
    8058:	aa1703e2 	mov	x2, x23
    805c:	937ffefa 	asr	x26, x23, #63
    8060:	aa1a03e3 	mov	x3, x26
    8064:	940009df 	bl	a7e0 <__modti3>
    8068:	aa010000 	orr	x0, x0, x1
    806c:	b40002c0 	cbz	x0, 80c4 <fwp_write+0xf40>
    8070:	110006b5 	add	w21, w21, #0x1
    8074:	91004273 	add	x19, x19, #0x10
    8078:	710016bf 	cmp	w21, #0x5
    807c:	54fffe81 	b.ne	804c <fwp_write+0xec8>  // b.any
    8080:	17ffffde 	b	7ff8 <fwp_write+0xe74>
    8084:	f9400a60 	ldr	x0, [x19, #16]
    8088:	8b000021 	add	x1, x1, x0
    808c:	17fffd75 	b	7660 <fwp_write+0x4dc>
    8090:	528c29c0 	mov	w0, #0x614e                	// #24910
    8094:	910123f5 	add	x21, sp, #0x48
    8098:	72a009c0 	movk	w0, #0x4e, lsl #16
    809c:	b9004be0 	str	w0, [sp, #72]
    80a0:	17fffda2 	b	7728 <fwp_write+0x5a4>
    80a4:	528005a1 	mov	w1, #0x2d                  	// #45
    80a8:	eb1603e2 	negs	x2, x22
    80ac:	da1803e3 	ngc	x3, x24
    80b0:	910027e0 	add	x0, sp, #0x9
    80b4:	910023f3 	add	x19, sp, #0x8
    80b8:	390023e1 	strb	w1, [sp, #8]
    80bc:	97ffeb79 	bl	2ea0 <fwp_fmt_u128>
    80c0:	17ffffd4 	b	8010 <fwp_write+0xe8c>
    80c4:	aa1703e2 	mov	x2, x23
    80c8:	aa1a03e3 	mov	x3, x26
    80cc:	aa1603e0 	mov	x0, x22
    80d0:	aa1803e1 	mov	x1, x24
    80d4:	940008e3 	bl	a460 <__divti3>
    80d8:	aa0003e2 	mov	x2, x0
    80dc:	aa0103e3 	mov	x3, x1
    80e0:	b7f80201 	tbnz	x1, #63, 8120 <fwp_write+0xf9c>
    80e4:	910023f3 	add	x19, sp, #0x8
    80e8:	aa1303e0 	mov	x0, x19
    80ec:	97ffeb6d 	bl	2ea0 <fwp_fmt_u128>
    80f0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    80f4:	910aa339 	add	x25, x25, #0x2a8
    80f8:	910123f5 	add	x21, sp, #0x48
    80fc:	aa1303e4 	mov	x4, x19
    8100:	aa1503e0 	mov	x0, x21
    8104:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x480>
    8108:	f8616b25 	ldr	x5, [x25, x1]
    810c:	91040063 	add	x3, x3, #0x100
    8110:	d2804002 	mov	x2, #0x200                 	// #512
    8114:	52800041 	mov	w1, #0x2                   	// #2
    8118:	97ffe9a6 	bl	27b0 <__sprintf_chk@plt>
    811c:	17ffffc5 	b	8030 <fwp_write+0xeac>
    8120:	528005a4 	mov	w4, #0x2d                  	// #45
    8124:	eb0003e2 	negs	x2, x0
    8128:	da0103e3 	ngc	x3, x1
    812c:	910027e0 	add	x0, sp, #0x9
    8130:	910023f3 	add	x19, sp, #0x8
    8134:	390023e4 	strb	w4, [sp, #8]
    8138:	97ffeb5a 	bl	2ea0 <fwp_fmt_u128>
    813c:	17ffffed 	b	80f0 <fwp_write+0xf6c>
    8140:	f9013bf5 	str	x21, [sp, #624]
    8144:	f9013ff6 	str	x22, [sp, #632]
    8148:	f90143f7 	str	x23, [sp, #640]
    814c:	f90147f8 	str	x24, [sp, #648]
    8150:	f9014bf9 	str	x25, [sp, #656]
    8154:	f9014ffa 	str	x26, [sp, #664]
    8158:	f90153fb 	str	x27, [sp, #672]
    815c:	f90157fc 	str	x28, [sp, #680]
    8160:	fd015be8 	str	d8, [sp, #688]
    8164:	fd015fe9 	str	d9, [sp, #696]
    8168:	97ffe9ea 	bl	2910 <__stack_chk_fail@plt>
    816c:	d503201f 	nop

0000000000008170 <fwp_main_thread>:
    8170:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8174:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    8178:	91174001 	add	x1, x0, #0x5d0
    817c:	910003fd 	mov	x29, sp
    8180:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8184:	f947f400 	ldr	x0, [x0, #4072]
    8188:	a90153f3 	stp	x19, x20, [sp, #16]
    818c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8190:	d10643ff 	sub	sp, sp, #0x190
    8194:	b953a421 	ldr	w1, [x1, #5028]
    8198:	f9400002 	ldr	x2, [x0]
    819c:	f900c7e2 	str	x2, [sp, #392]
    81a0:	d2800002 	mov	x2, #0x0                   	// #0
    81a4:	34008ae1 	cbz	w1, 9300 <fwp_main_thread+0x1190>
    81a8:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    81ac:	91174000 	add	x0, x0, #0x5d0
    81b0:	b953a800 	ldr	w0, [x0, #5032]
    81b4:	350089e0 	cbnz	w0, 92f0 <fwp_main_thread+0x1180>
    81b8:	9101c3e5 	add	x5, sp, #0x70
    81bc:	900000d3 	adrp	x19, 20000 <__data_start>
    81c0:	900000c2 	adrp	x2, 20000 <__data_start>
    81c4:	9101c275 	add	x21, x19, #0x70
    81c8:	910fc042 	add	x2, x2, #0x3f0
    81cc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    81d0:	d2a00024 	mov	x4, #0x10000               	// #65536
    81d4:	910223e0 	add	x0, sp, #0x88
    81d8:	d2800001 	mov	x1, #0x0                   	// #0
    81dc:	f9000be0 	str	x0, [sp, #16]
    81e0:	a9018ea5 	stp	x5, x3, [x21, #24]
    81e4:	f90013e5 	str	x5, [sp, #32]
    81e8:	f90047e2 	str	x2, [sp, #136]
    81ec:	b90093ff 	str	wzr, [sp, #144]
    81f0:	f9004fe4 	str	x4, [sp, #152]
    81f4:	97ffe95f 	bl	2770 <sigaltstack@plt>
    81f8:	35010f60 	cbnz	w0, a3e4 <fwp_main_thread+0x2274>
    81fc:	4f000400 	movi	v0.4s, #0x0
    8200:	9103e3e0 	add	x0, sp, #0xf8
    8204:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    8208:	9103c021 	add	x1, x1, #0xf0
    820c:	f9007be1 	str	x1, [sp, #240]
    8210:	52800082 	mov	w2, #0x4                   	// #4
    8214:	72a10002 	movk	w2, #0x800, lsl #16
    8218:	9103c3f4 	add	x20, sp, #0xf0
    821c:	3d802000 	str	q0, [x0, #128]
    8220:	b9017be2 	str	w2, [sp, #376]
    8224:	ad000000 	stp	q0, q0, [x0]
    8228:	ad010000 	stp	q0, q0, [x0, #32]
    822c:	ad020000 	stp	q0, q0, [x0, #64]
    8230:	ad030000 	stp	q0, q0, [x0, #96]
    8234:	97ffe9a7 	bl	28d0 <sigemptyset@plt>
    8238:	35010d60 	cbnz	w0, a3e4 <fwp_main_thread+0x2274>
    823c:	aa1403e1 	mov	x1, x20
    8240:	d2800002 	mov	x2, #0x0                   	// #0
    8244:	52800160 	mov	w0, #0xb                   	// #11
    8248:	97ffe9ba 	bl	2930 <sigaction@plt>
    824c:	35010cc0 	cbnz	w0, a3e4 <fwp_main_thread+0x2274>
    8250:	aa1403e1 	mov	x1, x20
    8254:	d2800002 	mov	x2, #0x0                   	// #0
    8258:	528000e0 	mov	w0, #0x7                   	// #7
    825c:	97ffe9b5 	bl	2930 <sigaction@plt>
    8260:	35010c20 	cbnz	w0, a3e4 <fwp_main_thread+0x2274>
    8264:	b94346a0 	ldr	w0, [x21, #836]
    8268:	340012e0 	cbz	w0, 84c4 <fwp_main_thread+0x354>
    826c:	9101c260 	add	x0, x19, #0x70
    8270:	a91c63f7 	stp	x23, x24, [sp, #448]
    8274:	b9434801 	ldr	w1, [x0, #840]
    8278:	340013a1 	cbz	w1, 84ec <fwp_main_thread+0x37c>
    827c:	9101c276 	add	x22, x19, #0x70
    8280:	f9400ad5 	ldr	x21, [x22, #16]
    8284:	b4000c95 	cbz	x21, 8414 <fwp_main_thread+0x2a4>
    8288:	aa1503f4 	mov	x20, x21
    828c:	910102b8 	add	x24, x21, #0x40
    8290:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8294:	52800037 	mov	w23, #0x1                   	// #1
    8298:	39414ab9 	ldrb	w25, [x21, #82]
    829c:	39014ab7 	strb	w23, [x21, #82]
    82a0:	f94016a0 	ldr	x0, [x21, #40]
    82a4:	b4000620 	cbz	x0, 8368 <fwp_main_thread+0x1f8>
    82a8:	f94032a1 	ldr	x1, [x21, #96]
    82ac:	394146a0 	ldrb	w0, [x21, #81]
    82b0:	b4000cc1 	cbz	x1, 8448 <fwp_main_thread+0x2d8>
    82b4:	36000b80 	tbz	w0, #0, 8424 <fwp_main_thread+0x2b4>
    82b8:	39414a82 	ldrb	w2, [x20, #82]
    82bc:	f94022a0 	ldr	x0, [x21, #64]
    82c0:	37000ee2 	tbnz	w2, #0, 849c <fwp_main_thread+0x32c>
    82c4:	f9403281 	ldr	x1, [x20, #96]
    82c8:	a911fe98 	stp	x24, xzr, [x20, #280]
    82cc:	f9009680 	str	x0, [x20, #296]
    82d0:	b4000040 	cbz	x0, 82d8 <fwp_main_thread+0x168>
    82d4:	f9009014 	str	x20, [x0, #288]
    82d8:	f90022b4 	str	x20, [x21, #64]
    82dc:	b4000101 	cbz	x1, 82fc <fwp_main_thread+0x18c>
    82e0:	f9406ec0 	ldr	x0, [x22, #216]
    82e4:	39015697 	strb	w23, [x20, #85]
    82e8:	f9003681 	str	x1, [x20, #104]
    82ec:	a910829f 	stp	xzr, x0, [x20, #264]
    82f0:	b4000040 	cbz	x0, 82f8 <fwp_main_thread+0x188>
    82f4:	f9008414 	str	x20, [x0, #264]
    82f8:	f9006ed4 	str	x20, [x22, #216]
    82fc:	39015a9f 	strb	wzr, [x20, #86]
    8300:	97fff929 	bl	67a4 <fwp_block>
    8304:	f9408e82 	ldr	x2, [x20, #280]
    8308:	b4000142 	cbz	x2, 8330 <fwp_main_thread+0x1c0>
    830c:	a9520281 	ldp	x1, x0, [x20, #288]
    8310:	b4000d21 	cbz	x1, 84b4 <fwp_main_thread+0x344>
    8314:	f9009420 	str	x0, [x1, #296]
    8318:	f9409680 	ldr	x0, [x20, #296]
    831c:	b4000040 	cbz	x0, 8324 <fwp_main_thread+0x1b4>
    8320:	f9009001 	str	x1, [x0, #288]
    8324:	91080280 	add	x0, x20, #0x200
    8328:	f900969f 	str	xzr, [x20, #296]
    832c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8330:	39415680 	ldrb	w0, [x20, #85]
    8334:	f9400ac2 	ldr	x2, [x22, #16]
    8338:	36000ae0 	tbz	w0, #0, 8494 <fwp_main_thread+0x324>
    833c:	a9508281 	ldp	x1, x0, [x20, #264]
    8340:	b4000be1 	cbz	x1, 84bc <fwp_main_thread+0x34c>
    8344:	f9008820 	str	x0, [x1, #272]
    8348:	b4000040 	cbz	x0, 8350 <fwp_main_thread+0x1e0>
    834c:	f9008401 	str	x1, [x0, #264]
    8350:	91080280 	add	x0, x20, #0x200
    8354:	3901569f 	strb	wzr, [x20, #85]
    8358:	aa0203f4 	mov	x20, x2
    835c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8360:	f94016a0 	ldr	x0, [x21, #40]
    8364:	b5fffa20 	cbnz	x0, 82a8 <fwp_main_thread+0x138>
    8368:	9101c260 	add	x0, x19, #0x70
    836c:	39014ab9 	strb	w25, [x21, #82]
    8370:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    8374:	f9419400 	ldr	x0, [x0, #808]
    8378:	b5000080 	cbnz	x0, 8388 <fwp_main_thread+0x218>
    837c:	9101c275 	add	x21, x19, #0x70
    8380:	f9419ea0 	ldr	x0, [x21, #824]
    8384:	b400f860 	cbz	x0, a290 <fwp_main_thread+0x2120>
    8388:	9101c260 	add	x0, x19, #0x70
    838c:	f941b001 	ldr	x1, [x0, #864]
    8390:	b903581f 	str	wzr, [x0, #856]
    8394:	eb14003f 	cmp	x1, x20
    8398:	5400f921 	b.ne	a2bc <fwp_main_thread+0x214c>  // b.any
    839c:	b4006ed4 	cbz	x20, 9174 <fwp_main_thread+0x1004>
    83a0:	9101c260 	add	x0, x19, #0x70
    83a4:	52800021 	mov	w1, #0x1                   	// #1
    83a8:	39014a81 	strb	w1, [x20, #82]
    83ac:	f9418005 	ldr	x5, [x0, #768]
    83b0:	b4006e25 	cbz	x5, 9174 <fwp_main_thread+0x1004>
    83b4:	d503201f 	nop
    83b8:	394140a0 	ldrb	w0, [x5, #80]
    83bc:	37000060 	tbnz	w0, #0, 83c8 <fwp_main_thread+0x258>
    83c0:	aa0503e0 	mov	x0, x5
    83c4:	97ffeceb 	bl	3770 <fwp_cancel_tree.part.0>
    83c8:	f9409ca5 	ldr	x5, [x5, #312]
    83cc:	b5ffff65 	cbnz	x5, 83b8 <fwp_main_thread+0x248>
    83d0:	9101c275 	add	x21, x19, #0x70
    83d4:	52800036 	mov	w22, #0x1                   	// #1
    83d8:	f9402a80 	ldr	x0, [x20, #80]
    83dc:	f2001c1f 	tst	x0, #0xff000000ff
    83e0:	540000e1 	b.ne	83fc <fwp_main_thread+0x28c>  // b.any
    83e4:	f9403ea0 	ldr	x0, [x21, #120]
    83e8:	39015296 	strb	w22, [x20, #84]
    83ec:	f900829f 	str	xzr, [x20, #256]
    83f0:	b4006b80 	cbz	x0, 9160 <fwp_main_thread+0xff0>
    83f4:	f9008014 	str	x20, [x0, #256]
    83f8:	f9003eb4 	str	x20, [x21, #120]
    83fc:	97fff8ea 	bl	67a4 <fwp_block>
    8400:	97fff87c 	bl	65f0 <fwp_free_zombie>
    8404:	f94182a0 	ldr	x0, [x21, #768]
    8408:	b4006b60 	cbz	x0, 9174 <fwp_main_thread+0x1004>
    840c:	f941b2b4 	ldr	x20, [x21, #864]
    8410:	17fffff2 	b	83d8 <fwp_main_thread+0x268>
    8414:	f94196c0 	ldr	x0, [x22, #808]
    8418:	b5006a80 	cbnz	x0, 9168 <fwp_main_thread+0xff8>
    841c:	d2800014 	mov	x20, #0x0                   	// #0
    8420:	17ffffd7 	b	837c <fwp_main_thread+0x20c>
    8424:	97ffed77 	bl	3a00 <fwp_now_ns>
    8428:	f94032a1 	ldr	x1, [x21, #96]
    842c:	eb01001f 	cmp	x0, x1
    8430:	540000ab 	b.lt	8444 <fwp_main_thread+0x2d4>  // b.tstop
    8434:	394142a0 	ldrb	w0, [x21, #80]
    8438:	37000060 	tbnz	w0, #0, 8444 <fwp_main_thread+0x2d4>
    843c:	aa1503e0 	mov	x0, x21
    8440:	97ffeccc 	bl	3770 <fwp_cancel_tree.part.0>
    8444:	394146a0 	ldrb	w0, [x21, #81]
    8448:	39414a82 	ldrb	w2, [x20, #82]
    844c:	3707f380 	tbnz	w0, #0, 82bc <fwp_main_thread+0x14c>
    8450:	f94032a1 	ldr	x1, [x21, #96]
    8454:	370001c2 	tbnz	w2, #0, 848c <fwp_main_thread+0x31c>
    8458:	f9403280 	ldr	x0, [x20, #96]
    845c:	b4000180 	cbz	x0, 848c <fwp_main_thread+0x31c>
    8460:	b4000061 	cbz	x1, 846c <fwp_main_thread+0x2fc>
    8464:	eb01001f 	cmp	x0, x1
    8468:	9a81d000 	csel	x0, x0, x1, le
    846c:	f94022a1 	ldr	x1, [x21, #64]
    8470:	a911fe98 	stp	x24, xzr, [x20, #280]
    8474:	f9009681 	str	x1, [x20, #296]
    8478:	b400efc1 	cbz	x1, a270 <fwp_main_thread+0x2100>
    847c:	f9009034 	str	x20, [x1, #288]
    8480:	aa0003e1 	mov	x1, x0
    8484:	f90022b4 	str	x20, [x21, #64]
    8488:	17ffff96 	b	82e0 <fwp_main_thread+0x170>
    848c:	f94022a0 	ldr	x0, [x21, #64]
    8490:	17ffff8e 	b	82c8 <fwp_main_thread+0x158>
    8494:	aa0203f4 	mov	x20, x2
    8498:	17ffff82 	b	82a0 <fwp_main_thread+0x130>
    849c:	a911fe98 	stp	x24, xzr, [x20, #280]
    84a0:	f9009680 	str	x0, [x20, #296]
    84a4:	b4000040 	cbz	x0, 84ac <fwp_main_thread+0x33c>
    84a8:	f9009014 	str	x20, [x0, #288]
    84ac:	f90022b4 	str	x20, [x21, #64]
    84b0:	17ffff93 	b	82fc <fwp_main_thread+0x18c>
    84b4:	f9000040 	str	x0, [x2]
    84b8:	17ffff99 	b	831c <fwp_main_thread+0x1ac>
    84bc:	f9006ec0 	str	x0, [x22, #216]
    84c0:	17ffffa2 	b	8348 <fwp_main_thread+0x1d8>
    84c4:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    84c8:	91078000 	add	x0, x0, #0x1e0
    84cc:	940009a1 	bl	ab50 <atexit>
    84d0:	a91c63f7 	stp	x23, x24, [sp, #448]
    84d4:	3500f960 	cbnz	w0, a400 <fwp_main_thread+0x2290>
    84d8:	52800020 	mov	w0, #0x1                   	// #1
    84dc:	b90346a0 	str	w0, [x21, #836]
    84e0:	9101c260 	add	x0, x19, #0x70
    84e4:	b9434801 	ldr	w1, [x0, #840]
    84e8:	35ffeca1 	cbnz	w1, 827c <fwp_main_thread+0x10c>
    84ec:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    84f0:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    84f4:	f9418803 	ldr	x3, [x0, #784]
    84f8:	913f4042 	add	x2, x2, #0xfd0
    84fc:	a91e73fb 	stp	x27, x28, [sp, #480]
    8500:	9117403c 	add	x28, x1, #0x5d0
    8504:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    8508:	91320021 	add	x1, x1, #0xc80
    850c:	a9070be3 	stp	x3, x2, [sp, #112]
    8510:	d2804018 	mov	x24, #0x200                 	// #512
    8514:	f9400be2 	ldr	x2, [sp, #16]
    8518:	a90987ff 	stp	xzr, x1, [sp, #152]
    851c:	d2800015 	mov	x21, #0x0                   	// #0
    8520:	f94013e1 	ldr	x1, [sp, #32]
    8524:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8528:	52800036 	mov	w22, #0x1                   	// #1
    852c:	fd00fbe8 	str	d8, [sp, #496]
    8530:	f9000fff 	str	xzr, [sp, #24]
    8534:	f90043e2 	str	x2, [sp, #128]
    8538:	f90047ff 	str	xzr, [sp, #136]
    853c:	f9018801 	str	x1, [x0, #784]
    8540:	f9400fe2 	ldr	x2, [sp, #24]
    8544:	f1000719 	subs	x25, x24, #0x1
    8548:	aa1403e1 	mov	x1, x20
    854c:	da1f02bb 	sbc	x27, x21, xzr
    8550:	52800020 	mov	w0, #0x1                   	// #1
    8554:	f9004bf9 	str	x25, [sp, #144]
    8558:	a90f0bf9 	stp	x25, x2, [sp, #240]
    855c:	97fff2ca 	bl	5084 <fwp_data.part.0.constprop.0>
    8560:	aa0003e2 	mov	x2, x0
    8564:	f949db81 	ldr	x1, [x28, #5040]
    8568:	f9000fe2 	str	x2, [sp, #24]
    856c:	f949ef80 	ldr	x0, [x28, #5080]
    8570:	cb010041 	sub	x1, x2, x1
    8574:	aa1903f8 	mov	x24, x25
    8578:	aa1b03f5 	mov	x21, x27
    857c:	eb00403f 	cmp	x1, x0, lsl #16
    8580:	54000302 	b.cs	85e0 <fwp_main_thread+0x470>  // b.hs, b.nlast
    8584:	d350fc20 	lsr	x0, x1, #16
    8588:	f949ff83 	ldr	x3, [x28, #5112]
    858c:	8b000800 	add	x0, x0, x0, lsl #2
    8590:	d37df002 	lsl	x2, x0, #3
    8594:	8b020060 	add	x0, x3, x2
    8598:	f9401017 	ldr	x23, [x0, #32]
    859c:	b4000237 	cbz	x23, 85e0 <fwp_main_thread+0x470>
    85a0:	38626862 	ldrb	w2, [x3, x2]
    85a4:	7100085f 	cmp	w2, #0x2
    85a8:	54006940 	b.eq	92d0 <fwp_main_thread+0x1160>  // b.none
    85ac:	7100045f 	cmp	w2, #0x1
    85b0:	54000181 	b.ne	85e0 <fwp_main_thread+0x470>  // b.any
    85b4:	29430002 	ldp	w2, w0, [x0, #24]
    85b8:	92403c21 	and	x1, x1, #0xffff
    85bc:	9b027c21 	mul	x1, x1, x2
    85c0:	d360fc21 	lsr	x1, x1, #32
    85c4:	eb00003f 	cmp	x1, x0
    85c8:	540000c2 	b.cs	85e0 <fwp_main_thread+0x470>  // b.hs, b.nlast
    85cc:	8b0102f7 	add	x23, x23, x1
    85d0:	394002e0 	ldrb	w0, [x23]
    85d4:	7103fc1f 	cmp	w0, #0xff
    85d8:	54006860 	b.eq	92e4 <fwp_main_thread+0x1174>  // b.none
    85dc:	390002f6 	strb	w22, [x23]
    85e0:	f9400fe0 	ldr	x0, [sp, #24]
    85e4:	f90047e0 	str	x0, [sp, #136]
    85e8:	aa1b0320 	orr	x0, x25, x27
    85ec:	b5fffaa0 	cbnz	x0, 8540 <fwp_main_thread+0x3d0>
    85f0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    85f4:	9101c262 	add	x2, x19, #0x70
    85f8:	f9403bf6 	ldr	x22, [sp, #112]
    85fc:	910303e1 	add	x1, sp, #0xc0
    8600:	3dc26000 	ldr	q0, [x0, #2432]
    8604:	52800020 	mov	w0, #0x1                   	// #1
    8608:	f9018856 	str	x22, [x2, #784]
    860c:	3d8033e0 	str	q0, [sp, #192]
    8610:	97fff29d 	bl	5084 <fwp_data.part.0.constprop.0>
    8614:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    8618:	91174022 	add	x2, x1, #0x5d0
    861c:	aa0003f7 	mov	x23, x0
    8620:	f949d841 	ldr	x1, [x2, #5040]
    8624:	f949ec40 	ldr	x0, [x2, #5080]
    8628:	cb0102e1 	sub	x1, x23, x1
    862c:	eb00403f 	cmp	x1, x0, lsl #16
    8630:	54000322 	b.cs	8694 <fwp_main_thread+0x524>  // b.hs, b.nlast
    8634:	d350fc20 	lsr	x0, x1, #16
    8638:	f949fc43 	ldr	x3, [x2, #5112]
    863c:	8b000800 	add	x0, x0, x0, lsl #2
    8640:	d37df002 	lsl	x2, x0, #3
    8644:	8b020060 	add	x0, x3, x2
    8648:	f9401015 	ldr	x21, [x0, #32]
    864c:	b4000255 	cbz	x21, 8694 <fwp_main_thread+0x524>
    8650:	38626862 	ldrb	w2, [x3, x2]
    8654:	7100085f 	cmp	w2, #0x2
    8658:	5400dfa0 	b.eq	a24c <fwp_main_thread+0x20dc>  // b.none
    865c:	7100045f 	cmp	w2, #0x1
    8660:	540001a1 	b.ne	8694 <fwp_main_thread+0x524>  // b.any
    8664:	29430002 	ldp	w2, w0, [x0, #24]
    8668:	92403c21 	and	x1, x1, #0xffff
    866c:	9b027c21 	mul	x1, x1, x2
    8670:	d360fc21 	lsr	x1, x1, #32
    8674:	eb00003f 	cmp	x1, x0
    8678:	540000e2 	b.cs	8694 <fwp_main_thread+0x524>  // b.hs, b.nlast
    867c:	8b0102b5 	add	x21, x21, x1
    8680:	394002a0 	ldrb	w0, [x21]
    8684:	7103fc1f 	cmp	w0, #0xff
    8688:	5400e900 	b.eq	a3a8 <fwp_main_thread+0x2238>  // b.none
    868c:	52800020 	mov	w0, #0x1                   	// #1
    8690:	390002a0 	strb	w0, [x21]
    8694:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8698:	910383e1 	add	x1, sp, #0xe0
    869c:	52800020 	mov	w0, #0x1                   	// #1
    86a0:	a90e5fe2 	stp	x2, x23, [sp, #224]
    86a4:	97fff278 	bl	5084 <fwp_data.part.0.constprop.0>
    86a8:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    86ac:	91174022 	add	x2, x1, #0x5d0
    86b0:	aa0003f7 	mov	x23, x0
    86b4:	f949d841 	ldr	x1, [x2, #5040]
    86b8:	f949ec40 	ldr	x0, [x2, #5080]
    86bc:	cb0102e1 	sub	x1, x23, x1
    86c0:	eb00403f 	cmp	x1, x0, lsl #16
    86c4:	54000322 	b.cs	8728 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    86c8:	d350fc20 	lsr	x0, x1, #16
    86cc:	f949fc43 	ldr	x3, [x2, #5112]
    86d0:	8b000800 	add	x0, x0, x0, lsl #2
    86d4:	d37df002 	lsl	x2, x0, #3
    86d8:	8b020060 	add	x0, x3, x2
    86dc:	f9401015 	ldr	x21, [x0, #32]
    86e0:	b4000255 	cbz	x21, 8728 <fwp_main_thread+0x5b8>
    86e4:	38626862 	ldrb	w2, [x3, x2]
    86e8:	7100085f 	cmp	w2, #0x2
    86ec:	5400dbc0 	b.eq	a264 <fwp_main_thread+0x20f4>  // b.none
    86f0:	7100045f 	cmp	w2, #0x1
    86f4:	540001a1 	b.ne	8728 <fwp_main_thread+0x5b8>  // b.any
    86f8:	29430002 	ldp	w2, w0, [x0, #24]
    86fc:	92403c21 	and	x1, x1, #0xffff
    8700:	9b027c21 	mul	x1, x1, x2
    8704:	d360fc21 	lsr	x1, x1, #32
    8708:	eb00003f 	cmp	x1, x0
    870c:	540000e2 	b.cs	8728 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    8710:	8b0102b5 	add	x21, x21, x1
    8714:	394002a0 	ldrb	w0, [x21]
    8718:	7103fc1f 	cmp	w0, #0xff
    871c:	5400e4c0 	b.eq	a3b4 <fwp_main_thread+0x2244>  // b.none
    8720:	52800020 	mov	w0, #0x1                   	// #1
    8724:	390002a0 	strb	w0, [x21]
    8728:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    872c:	910343e1 	add	x1, sp, #0xd0
    8730:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8734:	52800020 	mov	w0, #0x1                   	// #1
    8738:	a90d5fe2 	stp	x2, x23, [sp, #208]
    873c:	97fff252 	bl	5084 <fwp_data.part.0.constprop.0>
    8740:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    8744:	91174022 	add	x2, x1, #0x5d0
    8748:	aa0003f5 	mov	x21, x0
    874c:	f949d841 	ldr	x1, [x2, #5040]
    8750:	f949ec40 	ldr	x0, [x2, #5080]
    8754:	cb0102a1 	sub	x1, x21, x1
    8758:	eb00403f 	cmp	x1, x0, lsl #16
    875c:	54000322 	b.cs	87c0 <fwp_main_thread+0x650>  // b.hs, b.nlast
    8760:	d350fc20 	lsr	x0, x1, #16
    8764:	f949fc43 	ldr	x3, [x2, #5112]
    8768:	8b000800 	add	x0, x0, x0, lsl #2
    876c:	d37df002 	lsl	x2, x0, #3
    8770:	8b020060 	add	x0, x3, x2
    8774:	f9401017 	ldr	x23, [x0, #32]
    8778:	b4000257 	cbz	x23, 87c0 <fwp_main_thread+0x650>
    877c:	38626862 	ldrb	w2, [x3, x2]
    8780:	7100085f 	cmp	w2, #0x2
    8784:	5400d6a0 	b.eq	a258 <fwp_main_thread+0x20e8>  // b.none
    8788:	7100045f 	cmp	w2, #0x1
    878c:	540001a1 	b.ne	87c0 <fwp_main_thread+0x650>  // b.any
    8790:	29430002 	ldp	w2, w0, [x0, #24]
    8794:	92403c21 	and	x1, x1, #0xffff
    8798:	9b027c21 	mul	x1, x1, x2
    879c:	d360fc21 	lsr	x1, x1, #32
    87a0:	eb00003f 	cmp	x1, x0
    87a4:	540000e2 	b.cs	87c0 <fwp_main_thread+0x650>  // b.hs, b.nlast
    87a8:	8b0102f7 	add	x23, x23, x1
    87ac:	394002e0 	ldrb	w0, [x23]
    87b0:	7103fc1f 	cmp	w0, #0xff
    87b4:	5400e060 	b.eq	a3c0 <fwp_main_thread+0x2250>  // b.none
    87b8:	52800020 	mov	w0, #0x1                   	// #1
    87bc:	390002e0 	strb	w0, [x23]
    87c0:	f9400fe0 	ldr	x0, [sp, #24]
    87c4:	b400c3c0 	cbz	x0, a03c <fwp_main_thread+0x1ecc>
    87c8:	900000c0 	adrp	x0, 20000 <__data_start>
    87cc:	91004000 	add	x0, x0, #0x10
    87d0:	9100e000 	add	x0, x0, #0x38
    87d4:	f9001fe0 	str	x0, [sp, #56]
    87d8:	f9400fe0 	ldr	x0, [sp, #24]
    87dc:	f90027e0 	str	x0, [sp, #72]
    87e0:	910143e0 	add	x0, sp, #0x50
    87e4:	f90017e0 	str	x0, [sp, #40]
    87e8:	910163e0 	add	x0, sp, #0x58
    87ec:	f9001be0 	str	x0, [sp, #48]
    87f0:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    87f4:	9117401a 	add	x26, x0, #0x5d0
    87f8:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    87fc:	fd44c808 	ldr	d8, [x0, #2448]
    8800:	f949ef46 	ldr	x6, [x26, #5080]
    8804:	f949db43 	ldr	x3, [x26, #5040]
    8808:	d370bcc6 	lsl	x6, x6, #16
    880c:	cb0302a2 	sub	x2, x21, x3
    8810:	eb06005f 	cmp	x2, x6
    8814:	540003a2 	b.cs	8888 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8818:	d350fc40 	lsr	x0, x2, #16
    881c:	f949ff47 	ldr	x7, [x26, #5112]
    8820:	8b000800 	add	x0, x0, x0, lsl #2
    8824:	d37df001 	lsl	x1, x0, #3
    8828:	8b0100e5 	add	x5, x7, x1
    882c:	f94010a0 	ldr	x0, [x5, #32]
    8830:	b40002c0 	cbz	x0, 8888 <fwp_main_thread+0x718>
    8834:	386168e1 	ldrb	w1, [x7, x1]
    8838:	7100083f 	cmp	w1, #0x2
    883c:	5400c2a0 	b.eq	a090 <fwp_main_thread+0x1f20>  // b.none
    8840:	7100043f 	cmp	w1, #0x1
    8844:	54000221 	b.ne	8888 <fwp_main_thread+0x718>  // b.any
    8848:	92403c41 	and	x1, x2, #0xffff
    884c:	294308a7 	ldp	w7, w2, [x5, #24]
    8850:	9b077c21 	mul	x1, x1, x7
    8854:	d360fc21 	lsr	x1, x1, #32
    8858:	eb02003f 	cmp	x1, x2
    885c:	54000162 	b.cs	8888 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8860:	8b010000 	add	x0, x0, x1
    8864:	39400001 	ldrb	w1, [x0]
    8868:	34000101 	cbz	w1, 8888 <fwp_main_thread+0x718>
    886c:	7103f43f 	cmp	w1, #0xfd
    8870:	5400d4e8 	b.hi	a30c <fwp_main_thread+0x219c>  // b.pmore
    8874:	11000421 	add	w1, w1, #0x1
    8878:	39000001 	strb	w1, [x0]
    887c:	f949ef46 	ldr	x6, [x26, #5080]
    8880:	f949db43 	ldr	x3, [x26, #5040]
    8884:	d370bcc6 	lsl	x6, x6, #16
    8888:	f9401fe1 	ldr	x1, [sp, #56]
    888c:	9101c260 	add	x0, x19, #0x70
    8890:	12800002 	mov	w2, #0xffffffff            	// #-1
    8894:	b90053e2 	str	w2, [sp, #80]
    8898:	cb030023 	sub	x3, x1, x3
    889c:	d0ffffe1 	adrp	x1, 6000 <fwp_owned_tape_release+0xe0>
    88a0:	91054021 	add	x1, x1, #0x150
    88a4:	a90587f6 	stp	x22, x1, [sp, #88]
    88a8:	f94017e1 	ldr	x1, [sp, #40]
    88ac:	f90037e1 	str	x1, [sp, #104]
    88b0:	f9401be1 	ldr	x1, [sp, #48]
    88b4:	f9018801 	str	x1, [x0, #784]
    88b8:	eb0300df 	cmp	x6, x3
    88bc:	54000769 	b.ls	89a8 <fwp_main_thread+0x838>  // b.plast
    88c0:	d350fc60 	lsr	x0, x3, #16
    88c4:	f949ff45 	ldr	x5, [x26, #5112]
    88c8:	8b000800 	add	x0, x0, x0, lsl #2
    88cc:	d37df002 	lsl	x2, x0, #3
    88d0:	8b0200a1 	add	x1, x5, x2
    88d4:	f9401036 	ldr	x22, [x1, #32]
    88d8:	b4000696 	cbz	x22, 89a8 <fwp_main_thread+0x838>
    88dc:	386268a0 	ldrb	w0, [x5, x2]
    88e0:	7100081f 	cmp	w0, #0x2
    88e4:	5400ade0 	b.eq	9ea0 <fwp_main_thread+0x1d30>  // b.none
    88e8:	7100041f 	cmp	w0, #0x1
    88ec:	540005e1 	b.ne	89a8 <fwp_main_thread+0x838>  // b.any
    88f0:	29430825 	ldp	w5, w2, [x1, #24]
    88f4:	92403c60 	and	x0, x3, #0xffff
    88f8:	9b057c00 	mul	x0, x0, x5
    88fc:	d360fc00 	lsr	x0, x0, #32
    8900:	eb02001f 	cmp	x0, x2
    8904:	54000282 	b.cs	8954 <fwp_main_thread+0x7e4>  // b.hs, b.nlast
    8908:	8b0002c0 	add	x0, x22, x0
    890c:	39400002 	ldrb	w2, [x0]
    8910:	34000222 	cbz	w2, 8954 <fwp_main_thread+0x7e4>
    8914:	7103f45f 	cmp	w2, #0xfd
    8918:	5400c688 	b.hi	a1e8 <fwp_main_thread+0x2078>  // b.pmore
    891c:	11000442 	add	w2, w2, #0x1
    8920:	39000002 	strb	w2, [x0]
    8924:	f9401fe1 	ldr	x1, [sp, #56]
    8928:	f949db43 	ldr	x3, [x26, #5040]
    892c:	f949ef40 	ldr	x0, [x26, #5080]
    8930:	cb030023 	sub	x3, x1, x3
    8934:	eb00407f 	cmp	x3, x0, lsl #16
    8938:	54000382 	b.cs	89a8 <fwp_main_thread+0x838>  // b.hs, b.nlast
    893c:	f949ff40 	ldr	x0, [x26, #5112]
    8940:	d350fc61 	lsr	x1, x3, #16
    8944:	8b010821 	add	x1, x1, x1, lsl #2
    8948:	8b010c01 	add	x1, x0, x1, lsl #3
    894c:	f9401036 	ldr	x22, [x1, #32]
    8950:	b40002d6 	cbz	x22, 89a8 <fwp_main_thread+0x838>
    8954:	39400020 	ldrb	w0, [x1]
    8958:	7100081f 	cmp	w0, #0x2
    895c:	5400aaa0 	b.eq	9eb0 <fwp_main_thread+0x1d40>  // b.none
    8960:	7100041f 	cmp	w0, #0x1
    8964:	54000221 	b.ne	89a8 <fwp_main_thread+0x838>  // b.any
    8968:	29430022 	ldp	w2, w0, [x1, #24]
    896c:	92403c63 	and	x3, x3, #0xffff
    8970:	9b027c61 	mul	x1, x3, x2
    8974:	d360fc21 	lsr	x1, x1, #32
    8978:	eb00003f 	cmp	x1, x0
    897c:	54000162 	b.cs	89a8 <fwp_main_thread+0x838>  // b.hs, b.nlast
    8980:	8b0102d6 	add	x22, x22, x1
    8984:	394002c1 	ldrb	w1, [x22]
    8988:	34000101 	cbz	w1, 89a8 <fwp_main_thread+0x838>
    898c:	7100043f 	cmp	w1, #0x1
    8990:	54008e60 	b.eq	9b5c <fwp_main_thread+0x19ec>  // b.none
    8994:	7103fc3f 	cmp	w1, #0xff
    8998:	5400c2c0 	b.eq	a1f0 <fwp_main_thread+0x2080>  // b.none
    899c:	51000421 	sub	w1, w1, #0x1
    89a0:	390002c1 	strb	w1, [x22]
    89a4:	d503201f 	nop
    89a8:	b4008eb5 	cbz	x21, 9b7c <fwp_main_thread+0x1a0c>
    89ac:	aa1503e0 	mov	x0, x21
    89b0:	d2800016 	mov	x22, #0x0                   	// #0
    89b4:	d503201f 	nop
    89b8:	f9400800 	ldr	x0, [x0, #16]
    89bc:	910006d6 	add	x22, x22, #0x1
    89c0:	b5ffffc0 	cbnz	x0, 89b8 <fwp_main_thread+0x848>
    89c4:	52800000 	mov	w0, #0x0                   	// #0
    89c8:	97ffeb2a 	bl	3670 <descent_phase_step>
    89cc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    89d0:	eb0002df 	cmp	x22, x0
    89d4:	5400d368 	b.hi	a440 <fwp_main_thread+0x22d0>  // b.pmore
    89d8:	9101c277 	add	x23, x19, #0x70
    89dc:	b9434ee0 	ldr	w0, [x23, #844]
    89e0:	34008dc0 	cbz	w0, 9b98 <fwp_main_thread+0x1a28>
    89e4:	9101c260 	add	x0, x19, #0x70
    89e8:	f9404817 	ldr	x23, [x0, #144]
    89ec:	f9407401 	ldr	x1, [x0, #232]
    89f0:	eb17003f 	cmp	x1, x23
    89f4:	54008eaa 	b.ge	9bc8 <fwp_main_thread+0x1a58>  // b.tcont
    89f8:	f9403a62 	ldr	x2, [x19, #112]
    89fc:	8b010420 	add	x0, x1, x1, lsl #1
    8a00:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8a04:	8b000820 	add	x0, x1, x0, lsl #2
    8a08:	8b000c40 	add	x0, x2, x0, lsl #3
    8a0c:	d503201f 	nop
    8a10:	b9400402 	ldr	w2, [x0, #4]
    8a14:	35000082 	cbnz	w2, 8a24 <fwp_main_thread+0x8b4>
    8a18:	b9400002 	ldr	w2, [x0]
    8a1c:	6b03005f 	cmp	w2, w3
    8a20:	54008d49 	b.ls	9bc8 <fwp_main_thread+0x1a58>  // b.plast
    8a24:	91000421 	add	x1, x1, #0x1
    8a28:	9101a000 	add	x0, x0, #0x68
    8a2c:	eb17003f 	cmp	x1, x23
    8a30:	54ffff01 	b.ne	8a10 <fwp_main_thread+0x8a0>  // b.any
    8a34:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8a38:	eb0002ff 	cmp	x23, x0
    8a3c:	5400d08c 	b.gt	a44c <fwp_main_thread+0x22dc>
    8a40:	9101c260 	add	x0, x19, #0x70
    8a44:	f9403a7b 	ldr	x27, [x19, #112]
    8a48:	f9407000 	ldr	x0, [x0, #224]
    8a4c:	eb17001f 	cmp	x0, x23
    8a50:	54000201 	b.ne	8a90 <fwp_main_thread+0x920>  // b.any
    8a54:	b400ad17 	cbz	x23, 9ff4 <fwp_main_thread+0x1e84>
    8a58:	d37ffaf8 	lsl	x24, x23, #1
    8a5c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8a60:	eb00031f 	cmp	x24, x0
    8a64:	9a80d318 	csel	x24, x24, x0, le
    8a68:	8b180701 	add	x1, x24, x24, lsl #1
    8a6c:	8b010b01 	add	x1, x24, x1, lsl #2
    8a70:	d37df021 	lsl	x1, x1, #3
    8a74:	aa1b03e0 	mov	x0, x27
    8a78:	97ffe7a2 	bl	2900 <realloc@plt>
    8a7c:	aa0003fb 	mov	x27, x0
    8a80:	b4004620 	cbz	x0, 9344 <fwp_main_thread+0x11d4>
    8a84:	9101c260 	add	x0, x19, #0x70
    8a88:	f9003a7b 	str	x27, [x19, #112]
    8a8c:	f9007018 	str	x24, [x0, #224]
    8a90:	d37ffae1 	lsl	x1, x23, #1
    8a94:	9101c260 	add	x0, x19, #0x70
    8a98:	8b170022 	add	x2, x1, x23
    8a9c:	8b170021 	add	x1, x1, x23
    8aa0:	4f000400 	movi	v0.4s, #0x0
    8aa4:	910006fc 	add	x28, x23, #0x1
    8aa8:	8b020ae2 	add	x2, x23, x2, lsl #2
    8aac:	8b010ae1 	add	x1, x23, x1, lsl #2
    8ab0:	f900481c 	str	x28, [x0, #144]
    8ab4:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    8ab8:	8b020f62 	add	x2, x27, x2, lsl #3
    8abc:	8b010f78 	add	x24, x27, x1, lsl #3
    8ac0:	9139c000 	add	x0, x0, #0xe70
    8ac4:	ad000040 	stp	q0, q0, [x2]
    8ac8:	ad010040 	stp	q0, q0, [x2, #32]
    8acc:	ad020040 	stp	q0, q0, [x2, #64]
    8ad0:	f900305f 	str	xzr, [x2, #96]
    8ad4:	f900331f 	str	xzr, [x24, #96]
    8ad8:	97ffe7f2 	bl	2aa0 <getenv@plt>
    8adc:	b4008920 	cbz	x0, 9c00 <fwp_main_thread+0x1a90>
    8ae0:	39400001 	ldrb	w1, [x0]
    8ae4:	7100c03f 	cmp	w1, #0x30
    8ae8:	540088c1 	b.ne	9c00 <fwp_main_thread+0x1a90>  // b.any
    8aec:	39400400 	ldrb	w0, [x0, #1]
    8af0:	35008880 	cbnz	w0, 9c00 <fwp_main_thread+0x1a90>
    8af4:	9101c260 	add	x0, x19, #0x70
    8af8:	b9400305 	ldr	w5, [x24]
    8afc:	52800021 	mov	w1, #0x1                   	// #1
    8b00:	2f000400 	mvni	v0.2s, #0x0
    8b04:	110004a5 	add	w5, w5, #0x1
    8b08:	29000705 	stp	w5, w1, [x24]
    8b0c:	f9418801 	ldr	x1, [x0, #784]
    8b10:	a900db16 	stp	x22, x22, [x24, #8]
    8b14:	f9002b1f 	str	xzr, [x24, #80]
    8b18:	f900741c 	str	x28, [x0, #232]
    8b1c:	fd002f00 	str	d0, [x24, #88]
    8b20:	b400c561 	cbz	x1, a3cc <fwp_main_thread+0x225c>
    8b24:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0xe0>
    8b28:	91054003 	add	x3, x0, #0x150
    8b2c:	14000003 	b	8b38 <fwp_main_thread+0x9c8>
    8b30:	f9400021 	ldr	x1, [x1]
    8b34:	b400c4c1 	cbz	x1, a3cc <fwp_main_thread+0x225c>
    8b38:	f9400422 	ldr	x2, [x1, #8]
    8b3c:	eb03005f 	cmp	x2, x3
    8b40:	54ffff81 	b.ne	8b30 <fwp_main_thread+0x9c0>  // b.any
    8b44:	f9400820 	ldr	x0, [x1, #16]
    8b48:	2a1703e2 	mov	w2, w23
    8b4c:	b9400001 	ldr	w1, [x0]
    8b50:	f9002b00 	str	x0, [x24, #80]
    8b54:	b9005f01 	str	w1, [x24, #92]
    8b58:	37f80081 	tbnz	w1, #31, 8b68 <fwp_main_thread+0x9f8>
    8b5c:	52800d03 	mov	w3, #0x68                  	// #104
    8b60:	9b236c21 	smaddl	x1, w1, w3, x27
    8b64:	b9005837 	str	w23, [x1, #88]
    8b68:	b9000002 	str	w2, [x0]
    8b6c:	d3707cb6 	ubfiz	x22, x5, #16, #32
    8b70:	52800020 	mov	w0, #0x1                   	// #1
    8b74:	aa1c02d6 	orr	x22, x22, x28
    8b78:	97ffeabe 	bl	3670 <descent_phase_step>
    8b7c:	aa1503e0 	mov	x0, x21
    8b80:	d2800002 	mov	x2, #0x0                   	// #0
    8b84:	b4008cd5 	cbz	x21, 9d1c <fwp_main_thread+0x1bac>
    8b88:	f9400800 	ldr	x0, [x0, #16]
    8b8c:	91000442 	add	x2, x2, #0x1
    8b90:	b5ffffc0 	cbnz	x0, 8b88 <fwp_main_thread+0xa18>
    8b94:	aa1503e1 	mov	x1, x21
    8b98:	f9400821 	ldr	x1, [x1, #16]
    8b9c:	91000400 	add	x0, x0, #0x1
    8ba0:	b5ffffc1 	cbnz	x1, 8b98 <fwp_main_thread+0xa28>
    8ba4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8ba8:	eb01001f 	cmp	x0, x1
    8bac:	5400bf28 	b.hi	a390 <fwp_main_thread+0x2220>  // b.pmore
    8bb0:	f100005f 	cmp	x2, #0x0
    8bb4:	54008b4d 	b.le	9d1c <fwp_main_thread+0x1bac>
    8bb8:	eb00005f 	cmp	x2, x0
    8bbc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8bc0:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8bc4:	eb0102ff 	cmp	x23, x1
    8bc8:	5400be48 	b.hi	a390 <fwp_main_thread+0x2220>  // b.pmore
    8bcc:	d37ffafc 	lsl	x28, x23, #1
    8bd0:	52800041 	mov	w1, #0x2                   	// #2
    8bd4:	91000780 	add	x0, x28, #0x1
    8bd8:	d37df000 	lsl	x0, x0, #3
    8bdc:	97fff0e5 	bl	4f70 <fwp_heap_alloc>
    8be0:	f900001c 	str	x28, [x0]
    8be4:	aa0003f8 	mov	x24, x0
    8be8:	aa0003fb 	mov	x27, x0
    8bec:	f949db41 	ldr	x1, [x26, #5040]
    8bf0:	f949ef40 	ldr	x0, [x26, #5080]
    8bf4:	cb010301 	sub	x1, x24, x1
    8bf8:	eb00403f 	cmp	x1, x0, lsl #16
    8bfc:	54008b22 	b.cs	9d60 <fwp_main_thread+0x1bf0>  // b.hs, b.nlast
    8c00:	d350fc20 	lsr	x0, x1, #16
    8c04:	f949ff43 	ldr	x3, [x26, #5112]
    8c08:	8b000800 	add	x0, x0, x0, lsl #2
    8c0c:	d37df002 	lsl	x2, x0, #3
    8c10:	8b020060 	add	x0, x3, x2
    8c14:	f940101c 	ldr	x28, [x0, #32]
    8c18:	b400025c 	cbz	x28, 8c60 <fwp_main_thread+0xaf0>
    8c1c:	38626862 	ldrb	w2, [x3, x2]
    8c20:	7100085f 	cmp	w2, #0x2
    8c24:	540094c0 	b.eq	9ebc <fwp_main_thread+0x1d4c>  // b.none
    8c28:	7100045f 	cmp	w2, #0x1
    8c2c:	540001a1 	b.ne	8c60 <fwp_main_thread+0xaf0>  // b.any
    8c30:	29430002 	ldp	w2, w0, [x0, #24]
    8c34:	92403c21 	and	x1, x1, #0xffff
    8c38:	9b027c21 	mul	x1, x1, x2
    8c3c:	d360fc21 	lsr	x1, x1, #32
    8c40:	eb00003f 	cmp	x1, x0
    8c44:	540000e2 	b.cs	8c60 <fwp_main_thread+0xaf0>  // b.hs, b.nlast
    8c48:	8b01039c 	add	x28, x28, x1
    8c4c:	39400380 	ldrb	w0, [x28]
    8c50:	7103fc1f 	cmp	w0, #0xff
    8c54:	540093e0 	b.eq	9ed0 <fwp_main_thread+0x1d60>  // b.none
    8c58:	52800020 	mov	w0, #0x1                   	// #1
    8c5c:	39000380 	strb	w0, [x28]
    8c60:	b4000237 	cbz	x23, 8ca4 <fwp_main_thread+0xb34>
    8c64:	d3607ec5 	lsl	x5, x22, #32
    8c68:	aa1503e1 	mov	x1, x21
    8c6c:	f94006a6 	ldr	x6, [x21, #8]
    8c70:	aa0503e3 	mov	x3, x5
    8c74:	91002302 	add	x2, x24, #0x8
    8c78:	d2800000 	mov	x0, #0x0                   	// #0
    8c7c:	14000005 	b	8c90 <fwp_main_thread+0xb20>
    8c80:	f9400426 	ldr	x6, [x1, #8]
    8c84:	ab050003 	adds	x3, x0, x5
    8c88:	91004042 	add	x2, x2, #0x10
    8c8c:	5400be66 	b.vs	a458 <fwp_main_thread+0x22e8>
    8c90:	a9000c46 	stp	x6, x3, [x2]
    8c94:	91000400 	add	x0, x0, #0x1
    8c98:	f9400821 	ldr	x1, [x1, #16]
    8c9c:	eb17001f 	cmp	x0, x23
    8ca0:	54ffff03 	b.cc	8c80 <fwp_main_thread+0xb10>  // b.lo, b.ul, b.last
    8ca4:	f9400300 	ldr	x0, [x24]
    8ca8:	f100041f 	cmp	x0, #0x1
    8cac:	540085e9 	b.ls	9d68 <fwp_main_thread+0x1bf8>  // b.plast
    8cb0:	d341fc00 	lsr	x0, x0, #1
    8cb4:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8cb8:	d1000401 	sub	x1, x0, #0x1
    8cbc:	eb02003f 	cmp	x1, x2
    8cc0:	5400b688 	b.hi	a390 <fwp_main_thread+0x2220>  // b.pmore
    8cc4:	d37ff83c 	lsl	x28, x1, #1
    8cc8:	b4008501 	cbz	x1, 9d68 <fwp_main_thread+0x1bf8>
    8ccc:	d1002301 	sub	x1, x24, #0x8
    8cd0:	91002319 	add	x25, x24, #0x8
    8cd4:	8b001037 	add	x23, x1, x0, lsl #4
    8cd8:	f9400720 	ldr	x0, [x25, #8]
    8cdc:	f9400f21 	ldr	x1, [x25, #24]
    8ce0:	fd400320 	ldr	d0, [x25]
    8ce4:	fd400b21 	ldr	d1, [x25, #16]
    8ce8:	97fff212 	bl	5530 <w120>
    8cec:	a9000720 	stp	x0, x1, [x25]
    8cf0:	91004339 	add	x25, x25, #0x10
    8cf4:	eb17033f 	cmp	x25, x23
    8cf8:	54ffff01 	b.ne	8cd8 <fwp_main_thread+0xb68>  // b.any
    8cfc:	f900031c 	str	x28, [x24]
    8d00:	aa1803e0 	mov	x0, x24
    8d04:	97fff268 	bl	56a4 <w176.constprop.0>
    8d08:	aa0103fc 	mov	x28, x1
    8d0c:	f949db40 	ldr	x0, [x26, #5040]
    8d10:	f949ef42 	ldr	x2, [x26, #5080]
    8d14:	cb000301 	sub	x1, x24, x0
    8d18:	eb02403f 	cmp	x1, x2, lsl #16
    8d1c:	540003a2 	b.cs	8d90 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    8d20:	d350fc20 	lsr	x0, x1, #16
    8d24:	f949ff45 	ldr	x5, [x26, #5112]
    8d28:	8b000800 	add	x0, x0, x0, lsl #2
    8d2c:	d37df000 	lsl	x0, x0, #3
    8d30:	8b0000a2 	add	x2, x5, x0
    8d34:	f9401057 	ldr	x23, [x2, #32]
    8d38:	b40002d7 	cbz	x23, 8d90 <fwp_main_thread+0xc20>
    8d3c:	386068a0 	ldrb	w0, [x5, x0]
    8d40:	7100081f 	cmp	w0, #0x2
    8d44:	54008160 	b.eq	9d70 <fwp_main_thread+0x1c00>  // b.none
    8d48:	7100041f 	cmp	w0, #0x1
    8d4c:	54000221 	b.ne	8d90 <fwp_main_thread+0xc20>  // b.any
    8d50:	29430043 	ldp	w3, w0, [x2, #24]
    8d54:	92403c21 	and	x1, x1, #0xffff
    8d58:	9b037c21 	mul	x1, x1, x3
    8d5c:	d360fc21 	lsr	x1, x1, #32
    8d60:	eb00003f 	cmp	x1, x0
    8d64:	54000162 	b.cs	8d90 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    8d68:	8b0102f7 	add	x23, x23, x1
    8d6c:	394002e0 	ldrb	w0, [x23]
    8d70:	34000100 	cbz	w0, 8d90 <fwp_main_thread+0xc20>
    8d74:	7100041f 	cmp	w0, #0x1
    8d78:	54002fe0 	b.eq	9374 <fwp_main_thread+0x1204>  // b.none
    8d7c:	7103fc1f 	cmp	w0, #0xff
    8d80:	54009c40 	b.eq	a108 <fwp_main_thread+0x1f98>  // b.none
    8d84:	51000400 	sub	w0, w0, #0x1
    8d88:	390002e0 	strb	w0, [x23]
    8d8c:	d503201f 	nop
    8d90:	52800040 	mov	w0, #0x2                   	// #2
    8d94:	93407ed6 	sxtw	x22, w22
    8d98:	97ffea36 	bl	3670 <descent_phase_step>
    8d9c:	aa1603e0 	mov	x0, x22
    8da0:	97ffeb84 	bl	3bb0 <fwp_tape_of>
    8da4:	f9403001 	ldr	x1, [x0, #96]
    8da8:	aa0003e6 	mov	x6, x0
    8dac:	b500b441 	cbnz	x1, a434 <fwp_main_thread+0x22c4>
    8db0:	97ffe898 	bl	3010 <fwp_tape_unlink_scope>
    8db4:	b90004df 	str	wzr, [x6, #4]
    8db8:	a94288d8 	ldp	x24, x2, [x6, #40]
    8dbc:	f90003e2 	str	x2, [sp]
    8dc0:	f9401cc2 	ldr	x2, [x6, #56]
    8dc4:	f90007e2 	str	x2, [sp, #8]
    8dc8:	b94000c1 	ldr	w1, [x6]
    8dcc:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8dd0:	a940a0d9 	ldp	x25, x8, [x6, #8]
    8dd4:	a941dcc9 	ldp	x9, x23, [x6, #24]
    8dd8:	f94020db 	ldr	x27, [x6, #64]
    8ddc:	f94024c2 	ldr	x2, [x6, #72]
    8de0:	6b00003f 	cmp	w1, w0
    8de4:	54000108 	b.hi	8e04 <fwp_main_thread+0xc94>  // b.pmore
    8de8:	9101c261 	add	x1, x19, #0x70
    8dec:	92403ec0 	and	x0, x22, #0xffff
    8df0:	d1000400 	sub	x0, x0, #0x1
    8df4:	f940742a 	ldr	x10, [x1, #232]
    8df8:	eb0a001f 	cmp	x0, x10
    8dfc:	5400004a 	b.ge	8e04 <fwp_main_thread+0xc94>  // b.tcont
    8e00:	f9007420 	str	x0, [x1, #232]
    8e04:	4f000400 	movi	v0.4s, #0x0
    8e08:	9101c261 	add	x1, x19, #0x70
    8e0c:	90ffffe0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    8e10:	91100000 	add	x0, x0, #0x400
    8e14:	f9000cdf 	str	xzr, [x6, #24]
    8e18:	f941882a 	ldr	x10, [x1, #784]
    8e1c:	3c8080c0 	stur	q0, [x6, #8]
    8e20:	ad0100c0 	stp	q0, q0, [x6, #32]
    8e24:	a9047cdf 	stp	xzr, xzr, [x6, #64]
    8e28:	a90703ea 	stp	x10, x0, [sp, #112]
    8e2c:	f9400be0 	ldr	x0, [sp, #16]
    8e30:	f90043e0 	str	x0, [sp, #128]
    8e34:	f94003e0 	ldr	x0, [sp]
    8e38:	f9004fe0 	str	x0, [sp, #152]
    8e3c:	f94007e0 	ldr	x0, [sp, #8]
    8e40:	f90053e0 	str	x0, [sp, #160]
    8e44:	f94013e0 	ldr	x0, [sp, #32]
    8e48:	a908e3f7 	stp	x23, x24, [sp, #136]
    8e4c:	a90aa7fb 	stp	x27, x9, [sp, #168]
    8e50:	f9005fe2 	str	x2, [sp, #184]
    8e54:	f9018820 	str	x0, [x1, #784]
    8e58:	b7f8843c 	tbnz	x28, #63, 9edc <fwp_main_thread+0x1d6c>
    8e5c:	eb9c82df 	cmp	x22, x28, asr #32
    8e60:	5400a501 	b.ne	a300 <fwp_main_thread+0x2190>  // b.any
    8e64:	92407f81 	and	x1, x28, #0xffffffff
    8e68:	eb3c411f 	cmp	x8, w28, uxtw
    8e6c:	5400a44d 	b.le	a2f4 <fwp_main_thread+0x2184>
    8e70:	eb19003f 	cmp	x1, x25
    8e74:	9a81b736 	csinc	x22, x25, x1, lt	// lt = tstop
    8e78:	eb16005f 	cmp	x2, x22
    8e7c:	5400250a 	b.ge	931c <fwp_main_thread+0x11ac>  // b.tcont
    8e80:	f100005f 	cmp	x2, #0x0
    8e84:	9a961042 	csel	x2, x2, x22, ne	// ne = any
    8e88:	14000005 	b	8e9c <fwp_main_thread+0xd2c>
    8e8c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8e90:	eb00005f 	cmp	x2, x0
    8e94:	d37ff842 	lsl	x2, x2, #1
    8e98:	9a96d042 	csel	x2, x2, x22, le
    8e9c:	eb16005f 	cmp	x2, x22
    8ea0:	54ffff6b 	b.lt	8e8c <fwp_main_thread+0xd1c>  // b.tstop
    8ea4:	b40089bb 	cbz	x27, 9fd8 <fwp_main_thread+0x1e68>
    8ea8:	aa1b03e0 	mov	x0, x27
    8eac:	d37df041 	lsl	x1, x2, #3
    8eb0:	f90023e2 	str	x2, [sp, #64]
    8eb4:	97ffe693 	bl	2900 <realloc@plt>
    8eb8:	f94023e2 	ldr	x2, [sp, #64]
    8ebc:	aa0003fb 	mov	x27, x0
    8ec0:	b400ab1b 	cbz	x27, a420 <fwp_main_thread+0x22b0>
    8ec4:	f90057fb 	str	x27, [sp, #168]
    8ec8:	f9005fe2 	str	x2, [sp, #184]
    8ecc:	b50021f6 	cbnz	x22, 9308 <fwp_main_thread+0x1198>
    8ed0:	b7f800dc 	tbnz	x28, #63, 8ee8 <fwp_main_thread+0xd78>
    8ed4:	92407f81 	and	x1, x28, #0xffffffff
    8ed8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8edc:	fc617b60 	ldr	d0, [x27, x1, lsl #3]
    8ee0:	1e612800 	fadd	d0, d0, d1
    8ee4:	fc217b60 	str	d0, [x27, x1, lsl #3]
    8ee8:	9101c261 	add	x1, x19, #0x70
    8eec:	cb1902c6 	sub	x6, x22, x25
    8ef0:	52800060 	mov	w0, #0x3                   	// #3
    8ef4:	a9428827 	ldp	x7, x2, [x1, #40]
    8ef8:	8b0700c6 	add	x6, x6, x7
    8efc:	8b190042 	add	x2, x2, x25
    8f00:	a9028826 	stp	x6, x2, [x1, #40]
    8f04:	97ffe9db 	bl	3670 <descent_phase_step>
    8f08:	d10006c1 	sub	x1, x22, #0x1
    8f0c:	d1000727 	sub	x7, x25, #0x1
    8f10:	eb01033f 	cmp	x25, x1
    8f14:	540003ec 	b.gt	8f90 <fwp_main_thread+0xe20>
    8f18:	fc617b60 	ldr	d0, [x27, x1, lsl #3]
    8f1c:	1e602008 	fcmp	d0, #0.0
    8f20:	54000320 	b.eq	8f84 <fwp_main_thread+0xe14>  // b.none
    8f24:	cb190be0 	neg	x0, x25, lsl #2
    8f28:	cb1903e6 	neg	x6, x25
    8f2c:	8b0002e2 	add	x2, x23, x0
    8f30:	b8617842 	ldr	w2, [x2, x1, lsl #2]
    8f34:	37f80122 	tbnz	w2, #31, 8f58 <fwp_main_thread+0xde8>
    8f38:	f94003e3 	ldr	x3, [sp]
    8f3c:	93407c42 	sxtw	x2, w2
    8f40:	8b060c68 	add	x8, x3, x6, lsl #3
    8f44:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    8f48:	fc617902 	ldr	d2, [x8, x1, lsl #3]
    8f4c:	1e620802 	fmul	d2, d0, d2
    8f50:	1e622821 	fadd	d1, d1, d2
    8f54:	fc227b61 	str	d1, [x27, x2, lsl #3]
    8f58:	8b000300 	add	x0, x24, x0
    8f5c:	b8617800 	ldr	w0, [x0, x1, lsl #2]
    8f60:	37f80120 	tbnz	w0, #31, 8f84 <fwp_main_thread+0xe14>
    8f64:	f94007e2 	ldr	x2, [sp, #8]
    8f68:	93407c00 	sxtw	x0, w0
    8f6c:	8b060c46 	add	x6, x2, x6, lsl #3
    8f70:	fc607b61 	ldr	d1, [x27, x0, lsl #3]
    8f74:	fc6178c2 	ldr	d2, [x6, x1, lsl #3]
    8f78:	1e620800 	fmul	d0, d0, d2
    8f7c:	1e602820 	fadd	d0, d1, d0
    8f80:	fc207b60 	str	d0, [x27, x0, lsl #3]
    8f84:	d1000421 	sub	x1, x1, #0x1
    8f88:	eb0100ff 	cmp	x7, x1
    8f8c:	54fffc61 	b.ne	8f18 <fwp_main_thread+0xda8>  // b.any
    8f90:	52800080 	mov	w0, #0x4                   	// #4
    8f94:	97ffe9b7 	bl	3670 <descent_phase_step>
    8f98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8f9c:	eb00033f 	cmp	x25, x0
    8fa0:	5400a448 	b.hi	a428 <fwp_main_thread+0x22b8>  // b.pmore
    8fa4:	91000720 	add	x0, x25, #0x1
    8fa8:	52800041 	mov	w1, #0x2                   	// #2
    8fac:	d37df000 	lsl	x0, x0, #3
    8fb0:	97ffeff0 	bl	4f70 <fwp_heap_alloc>
    8fb4:	aa0003e2 	mov	x2, x0
    8fb8:	aa0003f7 	mov	x23, x0
    8fbc:	d2800001 	mov	x1, #0x0                   	// #0
    8fc0:	f8008459 	str	x25, [x2], #8
    8fc4:	b40000d9 	cbz	x25, 8fdc <fwp_main_thread+0xe6c>
    8fc8:	f8617b60 	ldr	x0, [x27, x1, lsl #3]
    8fcc:	f8217840 	str	x0, [x2, x1, lsl #3]
    8fd0:	91000421 	add	x1, x1, #0x1
    8fd4:	eb01033f 	cmp	x25, x1
    8fd8:	54ffff81 	b.ne	8fc8 <fwp_main_thread+0xe58>  // b.any
    8fdc:	528000a0 	mov	w0, #0x5                   	// #5
    8fe0:	97ffe9a4 	bl	3670 <descent_phase_step>
    8fe4:	f9400be0 	ldr	x0, [sp, #16]
    8fe8:	9101c261 	add	x1, x19, #0x70
    8fec:	f9403bf8 	ldr	x24, [sp, #112]
    8ff0:	f9018838 	str	x24, [x1, #784]
    8ff4:	97ffed03 	bl	4400 <fwp_tape_buffers_release>
    8ff8:	528000c0 	mov	w0, #0x6                   	// #6
    8ffc:	97ffe99d 	bl	3670 <descent_phase_step>
    9000:	f949db41 	ldr	x1, [x26, #5040]
    9004:	f949ef40 	ldr	x0, [x26, #5080]
    9008:	cb0102e1 	sub	x1, x23, x1
    900c:	eb00403f 	cmp	x1, x0, lsl #16
    9010:	54000322 	b.cs	9074 <fwp_main_thread+0xf04>  // b.hs, b.nlast
    9014:	d350fc20 	lsr	x0, x1, #16
    9018:	f949ff43 	ldr	x3, [x26, #5112]
    901c:	8b000800 	add	x0, x0, x0, lsl #2
    9020:	d37df002 	lsl	x2, x0, #3
    9024:	8b020060 	add	x0, x3, x2
    9028:	f9401016 	ldr	x22, [x0, #32]
    902c:	b4000256 	cbz	x22, 9074 <fwp_main_thread+0xf04>
    9030:	38626862 	ldrb	w2, [x3, x2]
    9034:	7100085f 	cmp	w2, #0x2
    9038:	54007560 	b.eq	9ee4 <fwp_main_thread+0x1d74>  // b.none
    903c:	7100045f 	cmp	w2, #0x1
    9040:	540001a1 	b.ne	9074 <fwp_main_thread+0xf04>  // b.any
    9044:	29430002 	ldp	w2, w0, [x0, #24]
    9048:	92403c21 	and	x1, x1, #0xffff
    904c:	9b027c21 	mul	x1, x1, x2
    9050:	d360fc21 	lsr	x1, x1, #32
    9054:	eb00003f 	cmp	x1, x0
    9058:	540000e2 	b.cs	9074 <fwp_main_thread+0xf04>  // b.hs, b.nlast
    905c:	8b0102d6 	add	x22, x22, x1
    9060:	394002c0 	ldrb	w0, [x22]
    9064:	7103fc1f 	cmp	w0, #0xff
    9068:	54007480 	b.eq	9ef8 <fwp_main_thread+0x1d88>  // b.none
    906c:	52800020 	mov	w0, #0x1                   	// #1
    9070:	390002c0 	strb	w0, [x22]
    9074:	f9401be0 	ldr	x0, [sp, #48]
    9078:	eb00031f 	cmp	x24, x0
    907c:	54009261 	b.ne	a2c8 <fwp_main_thread+0x2158>  // b.any
    9080:	f94017e0 	ldr	x0, [sp, #40]
    9084:	9101c261 	add	x1, x19, #0x70
    9088:	f9402fe2 	ldr	x2, [sp, #88]
    908c:	f9018822 	str	x2, [x1, #784]
    9090:	97fff430 	bl	6150 <fwp_tape_scope_release>
    9094:	f94002e0 	ldr	x0, [x23]
    9098:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    909c:	b7f85da0 	tbnz	x0, #63, 9c50 <fwp_main_thread+0x1ae0>
    90a0:	f949db40 	ldr	x0, [x26, #5040]
    90a4:	f949ef41 	ldr	x1, [x26, #5080]
    90a8:	cb0002e0 	sub	x0, x23, x0
    90ac:	eb01401f 	cmp	x0, x1, lsl #16
    90b0:	54005d02 	b.cs	9c50 <fwp_main_thread+0x1ae0>  // b.hs, b.nlast
    90b4:	d350fc01 	lsr	x1, x0, #16
    90b8:	f949ff45 	ldr	x5, [x26, #5112]
    90bc:	8b010821 	add	x1, x1, x1, lsl #2
    90c0:	d37df021 	lsl	x1, x1, #3
    90c4:	8b0100a3 	add	x3, x5, x1
    90c8:	f9401062 	ldr	x2, [x3, #32]
    90cc:	b4005c22 	cbz	x2, 9c50 <fwp_main_thread+0x1ae0>
    90d0:	386168a1 	ldrb	w1, [x5, x1]
    90d4:	7100083f 	cmp	w1, #0x2
    90d8:	54005b80 	b.eq	9c48 <fwp_main_thread+0x1ad8>  // b.none
    90dc:	7100043f 	cmp	w1, #0x1
    90e0:	54005b81 	b.ne	9c50 <fwp_main_thread+0x1ae0>  // b.any
    90e4:	29430465 	ldp	w5, w1, [x3, #24]
    90e8:	92403c00 	and	x0, x0, #0xffff
    90ec:	9b057c00 	mul	x0, x0, x5
    90f0:	d360fc00 	lsr	x0, x0, #32
    90f4:	eb01001f 	cmp	x0, x1
    90f8:	54005ac2 	b.cs	9c50 <fwp_main_thread+0x1ae0>  // b.hs, b.nlast
    90fc:	8b000042 	add	x2, x2, x0
    9100:	39400040 	ldrb	w0, [x2]
    9104:	7100041f 	cmp	w0, #0x1
    9108:	54005a41 	b.ne	9c50 <fwp_main_thread+0x1ae0>  // b.any
    910c:	aa1703e5 	mov	x5, x23
    9110:	aa1703f6 	mov	x22, x23
    9114:	d2800000 	mov	x0, #0x0                   	// #0
    9118:	910022c3 	add	x3, x22, #0x8
    911c:	910022e7 	add	x7, x23, #0x8
    9120:	d2800001 	mov	x1, #0x0                   	// #0
    9124:	b5000158 	cbnz	x24, 914c <fwp_main_thread+0xfdc>
    9128:	140000b4 	b	93f8 <fwp_main_thread+0x1288>
    912c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    9130:	f94000a2 	ldr	x2, [x5]
    9134:	1e600900 	fmul	d0, d8, d0
    9138:	b7f89262 	tbnz	x2, #63, a384 <fwp_main_thread+0x2214>
    913c:	91000421 	add	x1, x1, #0x1
    9140:	fc008460 	str	d0, [x3], #8
    9144:	eb01031f 	cmp	x24, x1
    9148:	54001580 	b.eq	93f8 <fwp_main_thread+0x1288>  // b.none
    914c:	f94002e6 	ldr	x6, [x23]
    9150:	aa0703e2 	mov	x2, x7
    9154:	b6fffec6 	tbz	x6, #63, 912c <fwp_main_thread+0xfbc>
    9158:	f9400ae2 	ldr	x2, [x23, #16]
    915c:	17fffff4 	b	912c <fwp_main_thread+0xfbc>
    9160:	f90042b4 	str	x20, [x21, #128]
    9164:	17fffca5 	b	83f8 <fwp_main_thread+0x288>
    9168:	f941b2c0 	ldr	x0, [x22, #864]
    916c:	b9035adf 	str	wzr, [x22, #856]
    9170:	b5008a60 	cbnz	x0, a2bc <fwp_main_thread+0x214c>
    9174:	9101c275 	add	x21, x19, #0x70
    9178:	97fff51e 	bl	65f0 <fwp_free_zombie>
    917c:	f94042a0 	ldr	x0, [x21, #128]
    9180:	b50089e0 	cbnz	x0, a2bc <fwp_main_thread+0x214c>
    9184:	f9406ea0 	ldr	x0, [x21, #216]
    9188:	b50089a0 	cbnz	x0, a2bc <fwp_main_thread+0x214c>
    918c:	b940faa0 	ldr	w0, [x21, #248]
    9190:	340001e0 	cbz	w0, 91cc <fwp_main_thread+0x105c>
    9194:	93407c16 	sxtw	x22, w0
    9198:	51000400 	sub	w0, w0, #0x1
    919c:	d1000ad6 	sub	x22, x22, #0x2
    91a0:	910402b7 	add	x23, x21, #0x100
    91a4:	cb2042d6 	sub	x22, x22, w0, uxtw
    91a8:	93407c14 	sxtw	x20, w0
    91ac:	d503201f 	nop
    91b0:	f8747ae0 	ldr	x0, [x23, x20, lsl #3]
    91b4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    91b8:	b900fab4 	str	w20, [x21, #248]
    91bc:	d1000694 	sub	x20, x20, #0x1
    91c0:	97ffe61c 	bl	2a30 <munmap@plt>
    91c4:	eb16029f 	cmp	x20, x22
    91c8:	54ffff41 	b.ne	91b0 <fwp_main_thread+0x1040>  // b.any
    91cc:	f00000b4 	adrp	x20, 20000 <__data_start>
    91d0:	91004280 	add	x0, x20, #0x10
    91d4:	b9404000 	ldr	w0, [x0, #64]
    91d8:	37f80040 	tbnz	w0, #31, 91e0 <fwp_main_thread+0x1070>
    91dc:	97ffe5d1 	bl	2920 <close@plt>
    91e0:	9101c260 	add	x0, x19, #0x70
    91e4:	91004281 	add	x1, x20, #0x10
    91e8:	12800002 	mov	w2, #0xffffffff            	// #-1
    91ec:	d2800014 	mov	x20, #0x0                   	// #0
    91f0:	f941b416 	ldr	x22, [x0, #872]
    91f4:	b9004022 	str	w2, [x1, #64]
    91f8:	f941b815 	ldr	x21, [x0, #880]
    91fc:	b4000176 	cbz	x22, 9228 <fwp_main_thread+0x10b8>
    9200:	f8747aa0 	ldr	x0, [x21, x20, lsl #3]
    9204:	b40000c0 	cbz	x0, 921c <fwp_main_thread+0x10ac>
    9208:	f9400001 	ldr	x1, [x0]
    920c:	b5008581 	cbnz	x1, a2bc <fwp_main_thread+0x214c>
    9210:	f9400401 	ldr	x1, [x0, #8]
    9214:	b5008541 	cbnz	x1, a2bc <fwp_main_thread+0x214c>
    9218:	97ffee36 	bl	4af0 <fwp_mem_free>
    921c:	91000694 	add	x20, x20, #0x1
    9220:	eb1402df 	cmp	x22, x20
    9224:	54fffee1 	b.ne	9200 <fwp_main_thread+0x1090>  // b.any
    9228:	aa1503e0 	mov	x0, x21
    922c:	97ffee31 	bl	4af0 <fwp_mem_free>
    9230:	9101c260 	add	x0, x19, #0x70
    9234:	f941b014 	ldr	x20, [x0, #864]
    9238:	f901b41f 	str	xzr, [x0, #872]
    923c:	f901b81f 	str	xzr, [x0, #880]
    9240:	b40001f4 	cbz	x20, 927c <fwp_main_thread+0x110c>
    9244:	f9401681 	ldr	x1, [x20, #40]
    9248:	b50083a1 	cbnz	x1, a2bc <fwp_main_thread+0x214c>
    924c:	f9405681 	ldr	x1, [x20, #168]
    9250:	b5008361 	cbnz	x1, a2bc <fwp_main_thread+0x214c>
    9254:	f9419401 	ldr	x1, [x0, #808]
    9258:	b5008321 	cbnz	x1, a2bc <fwp_main_thread+0x214c>
    925c:	f9419c00 	ldr	x0, [x0, #824]
    9260:	b50082e0 	cbnz	x0, a2bc <fwp_main_thread+0x214c>
    9264:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9268:	f0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    926c:	910fc000 	add	x0, x0, #0x3f0
    9270:	97ffe59c 	bl	28e0 <memset@plt>
    9274:	aa1403e0 	mov	x0, x20
    9278:	97ffee1e 	bl	4af0 <fwp_mem_free>
    927c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9280:	f947ec00 	ldr	x0, [x0, #4056]
    9284:	9101c273 	add	x19, x19, #0x70
    9288:	f9400000 	ldr	x0, [x0]
    928c:	f9000a7f 	str	xzr, [x19, #16]
    9290:	f901b27f 	str	xzr, [x19, #864]
    9294:	97ffe5eb 	bl	2a40 <fflush@plt>
    9298:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    929c:	f947f400 	ldr	x0, [x0, #4072]
    92a0:	f940c7e2 	ldr	x2, [sp, #392]
    92a4:	f9400001 	ldr	x1, [x0]
    92a8:	eb010042 	subs	x2, x2, x1
    92ac:	d2800001 	mov	x1, #0x0                   	// #0
    92b0:	54008b01 	b.ne	a410 <fwp_main_thread+0x22a0>  // b.any
    92b4:	a95c63f7 	ldp	x23, x24, [sp, #448]
    92b8:	910643ff 	add	sp, sp, #0x190
    92bc:	d2800000 	mov	x0, #0x0                   	// #0
    92c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    92c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    92c8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    92cc:	d65f03c0 	ret
    92d0:	72003c3f 	tst	w1, #0xffff
    92d4:	54ff9861 	b.ne	85e0 <fwp_main_thread+0x470>  // b.any
    92d8:	394002e0 	ldrb	w0, [x23]
    92dc:	7103fc1f 	cmp	w0, #0xff
    92e0:	54ff97e1 	b.ne	85dc <fwp_main_thread+0x46c>  // b.any
    92e4:	aa1703e0 	mov	x0, x23
    92e8:	97ffed62 	bl	4870 <fwp_rc_forget_slot>
    92ec:	17fffcbc 	b	85dc <fwp_main_thread+0x46c>
    92f0:	f0ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    92f4:	91008000 	add	x0, x0, #0x20
    92f8:	94000616 	bl	ab50 <atexit>
    92fc:	17fffbaf 	b	81b8 <fwp_main_thread+0x48>
    9300:	97ffeba1 	bl	4184 <fwp_heap_init>
    9304:	17fffba9 	b	81a8 <fwp_main_thread+0x38>
    9308:	d37df2c2 	lsl	x2, x22, #3
    930c:	aa1b03e0 	mov	x0, x27
    9310:	52800001 	mov	w1, #0x0                   	// #0
    9314:	97ffe573 	bl	28e0 <memset@plt>
    9318:	17fffeee 	b	8ed0 <fwp_main_thread+0xd60>
    931c:	f100037f 	cmp	x27, #0x0
    9320:	1a9f17e0 	cset	w0, eq	// eq = none
    9324:	f10002df 	cmp	x22, #0x0
    9328:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    932c:	54ffdd00 	b.eq	8ecc <fwp_main_thread+0xd5c>  // b.none
    9330:	f9400be0 	ldr	x0, [sp, #16]
    9334:	9101c273 	add	x19, x19, #0x70
    9338:	f9403be1 	ldr	x1, [sp, #112]
    933c:	f9018a61 	str	x1, [x19, #784]
    9340:	97ffec30 	bl	4400 <fwp_tape_buffers_release>
    9344:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9348:	f947e863 	ldr	x3, [x3, #4048]
    934c:	d2800262 	mov	x2, #0x13                  	// #19
    9350:	d2800021 	mov	x1, #0x1                   	// #1
    9354:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    9358:	912e2000 	add	x0, x0, #0xb88
    935c:	f9400063 	ldr	x3, [x3]
    9360:	97ffe5ac 	bl	2a10 <fwrite@plt>
    9364:	d2800000 	mov	x0, #0x0                   	// #0
    9368:	97ffe5b6 	bl	2a40 <fflush@plt>
    936c:	52800cc0 	mov	w0, #0x66                  	// #102
    9370:	97ffe5c4 	bl	2a80 <_Exit@plt>
    9374:	f9400366 	ldr	x6, [x27]
    9378:	aa1b03e0 	mov	x0, x27
    937c:	f949ef43 	ldr	x3, [x26, #5080]
    9380:	f949db41 	ldr	x1, [x26, #5040]
    9384:	d370bc63 	lsl	x3, x3, #16
    9388:	cb010362 	sub	x2, x27, x1
    938c:	b7f84fe6 	tbnz	x6, #63, 9d88 <fwp_main_thread+0x1c18>
    9390:	eb02007f 	cmp	x3, x2
    9394:	54ffcfe9 	b.ls	8d90 <fwp_main_thread+0xc20>  // b.plast
    9398:	d350fc40 	lsr	x0, x2, #16
    939c:	8b000800 	add	x0, x0, x0, lsl #2
    93a0:	d37df000 	lsl	x0, x0, #3
    93a4:	8b0000a3 	add	x3, x5, x0
    93a8:	f9401061 	ldr	x1, [x3, #32]
    93ac:	b4ffcf21 	cbz	x1, 8d90 <fwp_main_thread+0xc20>
    93b0:	386068a0 	ldrb	w0, [x5, x0]
    93b4:	7100081f 	cmp	w0, #0x2
    93b8:	54005a60 	b.eq	9f04 <fwp_main_thread+0x1d94>  // b.none
    93bc:	7100041f 	cmp	w0, #0x1
    93c0:	54ffce81 	b.ne	8d90 <fwp_main_thread+0xc20>  // b.any
    93c4:	92403c40 	and	x0, x2, #0xffff
    93c8:	29430865 	ldp	w5, w2, [x3, #24]
    93cc:	9b057c00 	mul	x0, x0, x5
    93d0:	d360fc00 	lsr	x0, x0, #32
    93d4:	eb02001f 	cmp	x0, x2
    93d8:	54ffcdc2 	b.cs	8d90 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    93dc:	8b000021 	add	x1, x1, x0
    93e0:	39400020 	ldrb	w0, [x1]
    93e4:	7100041f 	cmp	w0, #0x1
    93e8:	54ffcd41 	b.ne	8d90 <fwp_main_thread+0xc20>  // b.any
    93ec:	aa1b03e0 	mov	x0, x27
    93f0:	97ffedc0 	bl	4af0 <fwp_mem_free>
    93f4:	17fffe67 	b	8d90 <fwp_main_thread+0xc20>
    93f8:	f90003e5 	str	x5, [sp]
    93fc:	97fff541 	bl	6900 <fwp_drop10>
    9400:	f94003e5 	ldr	x5, [sp]
    9404:	aa1503e1 	mov	x1, x21
    9408:	d2800002 	mov	x2, #0x0                   	// #0
    940c:	b4005fb5 	cbz	x21, a000 <fwp_main_thread+0x1e90>
    9410:	f9400821 	ldr	x1, [x1, #16]
    9414:	91000442 	add	x2, x2, #0x1
    9418:	b5ffffc1 	cbnz	x1, 9410 <fwp_main_thread+0x12a0>
    941c:	f94000a0 	ldr	x0, [x5]
    9420:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    9424:	b7f83620 	tbnz	x0, #63, 9ae8 <fwp_main_thread+0x1978>
    9428:	f949db41 	ldr	x1, [x26, #5040]
    942c:	f949ef43 	ldr	x3, [x26, #5080]
    9430:	cb0102c1 	sub	x1, x22, x1
    9434:	eb03403f 	cmp	x1, x3, lsl #16
    9438:	54003582 	b.cs	9ae8 <fwp_main_thread+0x1978>  // b.hs, b.nlast
    943c:	d350fc23 	lsr	x3, x1, #16
    9440:	f949ff48 	ldr	x8, [x26, #5112]
    9444:	8b030863 	add	x3, x3, x3, lsl #2
    9448:	d37df063 	lsl	x3, x3, #3
    944c:	8b030107 	add	x7, x8, x3
    9450:	f94010e6 	ldr	x6, [x7, #32]
    9454:	b4003486 	cbz	x6, 9ae4 <fwp_main_thread+0x1974>
    9458:	38636903 	ldrb	w3, [x8, x3]
    945c:	7100087f 	cmp	w3, #0x2
    9460:	540033e0 	b.eq	9adc <fwp_main_thread+0x196c>  // b.none
    9464:	7100047f 	cmp	w3, #0x1
    9468:	540033e1 	b.ne	9ae4 <fwp_main_thread+0x1974>  // b.any
    946c:	29430ce8 	ldp	w8, w3, [x7, #24]
    9470:	92403c21 	and	x1, x1, #0xffff
    9474:	9b087c21 	mul	x1, x1, x8
    9478:	d360fc21 	lsr	x1, x1, #32
    947c:	eb03003f 	cmp	x1, x3
    9480:	54003322 	b.cs	9ae4 <fwp_main_thread+0x1974>  // b.hs, b.nlast
    9484:	8b0100c6 	add	x6, x6, x1
    9488:	394000d7 	ldrb	w23, [x6]
    948c:	710006ff 	cmp	w23, #0x1
    9490:	540032a1 	b.ne	9ae4 <fwp_main_thread+0x1974>  // b.any
    9494:	b90003f7 	str	w23, [sp]
    9498:	eb1b005f 	cmp	x2, x27
    949c:	9a9b905b 	csel	x27, x2, x27, ls	// ls = plast
    94a0:	910020bc 	add	x28, x5, #0x8
    94a4:	b40069bb 	cbz	x27, a1d8 <fwp_main_thread+0x2068>
    94a8:	d37df367 	lsl	x7, x27, #3
    94ac:	aa1503e2 	mov	x2, x21
    94b0:	910022c6 	add	x6, x22, #0x8
    94b4:	d2800001 	mov	x1, #0x0                   	// #0
    94b8:	1400000a 	b	94e0 <fwp_main_thread+0x1370>
    94bc:	fc616861 	ldr	d1, [x3, x1]
    94c0:	fd400440 	ldr	d0, [x2, #8]
    94c4:	1e613800 	fsub	d0, d0, d1
    94c8:	fc216b80 	str	d0, [x28, x1]
    94cc:	91002021 	add	x1, x1, #0x8
    94d0:	f9400842 	ldr	x2, [x2, #16]
    94d4:	eb07003f 	cmp	x1, x7
    94d8:	540001a0 	b.eq	950c <fwp_main_thread+0x139c>  // b.none
    94dc:	f94000a0 	ldr	x0, [x5]
    94e0:	aa0603e3 	mov	x3, x6
    94e4:	b6fffec0 	tbz	x0, #63, 94bc <fwp_main_thread+0x134c>
    94e8:	f9400ac3 	ldr	x3, [x22, #16]
    94ec:	fd400440 	ldr	d0, [x2, #8]
    94f0:	fc616861 	ldr	d1, [x3, x1]
    94f4:	1e613800 	fsub	d0, d0, d1
    94f8:	fc216b80 	str	d0, [x28, x1]
    94fc:	91002021 	add	x1, x1, #0x8
    9500:	f9400842 	ldr	x2, [x2, #16]
    9504:	eb07003f 	cmp	x1, x7
    9508:	54fffea1 	b.ne	94dc <fwp_main_thread+0x136c>  // b.any
    950c:	b4006b95 	cbz	x21, a27c <fwp_main_thread+0x210c>
    9510:	f949ef48 	ldr	x8, [x26, #5080]
    9514:	aa1503e6 	mov	x6, x21
    9518:	f949db49 	ldr	x9, [x26, #5040]
    951c:	d2800017 	mov	x23, #0x0                   	// #0
    9520:	f949ff47 	ldr	x7, [x26, #5112]
    9524:	d370bd08 	lsl	x8, x8, #16
    9528:	14000006 	b	9540 <fwp_main_thread+0x13d0>
    952c:	f94008c6 	ldr	x6, [x6, #16]
    9530:	910006f7 	add	x23, x23, #0x1
    9534:	f10000df 	cmp	x6, #0x0
    9538:	fa571360 	ccmp	x27, x23, #0x0, ne	// ne = any
    953c:	54003dc9 	b.ls	9cf4 <fwp_main_thread+0x1b84>  // b.plast
    9540:	cb0900c0 	sub	x0, x6, x9
    9544:	eb08001f 	cmp	x0, x8
    9548:	540002c2 	b.cs	95a0 <fwp_main_thread+0x1430>  // b.hs, b.nlast
    954c:	d350fc01 	lsr	x1, x0, #16
    9550:	8b010821 	add	x1, x1, x1, lsl #2
    9554:	d37df021 	lsl	x1, x1, #3
    9558:	8b0100e5 	add	x5, x7, x1
    955c:	f94010a2 	ldr	x2, [x5, #32]
    9560:	b4000202 	cbz	x2, 95a0 <fwp_main_thread+0x1430>
    9564:	386168e1 	ldrb	w1, [x7, x1]
    9568:	7100083f 	cmp	w1, #0x2
    956c:	54000d80 	b.eq	971c <fwp_main_thread+0x15ac>  // b.none
    9570:	7100043f 	cmp	w1, #0x1
    9574:	54000161 	b.ne	95a0 <fwp_main_thread+0x1430>  // b.any
    9578:	294304aa 	ldp	w10, w1, [x5, #24]
    957c:	92403c00 	and	x0, x0, #0xffff
    9580:	9b0a7c00 	mul	x0, x0, x10
    9584:	d360fc00 	lsr	x0, x0, #32
    9588:	eb01001f 	cmp	x0, x1
    958c:	540000a2 	b.cs	95a0 <fwp_main_thread+0x1430>  // b.hs, b.nlast
    9590:	8b000042 	add	x2, x2, x0
    9594:	39400040 	ldrb	w0, [x2]
    9598:	7100041f 	cmp	w0, #0x1
    959c:	54fffc80 	b.eq	952c <fwp_main_thread+0x13bc>  // b.none
    95a0:	eb1b02ff 	cmp	x23, x27
    95a4:	54000c62 	b.cs	9730 <fwp_main_thread+0x15c0>  // b.hs, b.nlast
    95a8:	d1002399 	sub	x25, x28, #0x8
    95ac:	d2800018 	mov	x24, #0x0                   	// #0
    95b0:	14000012 	b	95f8 <fwp_main_thread+0x1488>
    95b4:	7100045f 	cmp	w2, #0x1
    95b8:	540001a1 	b.ne	95ec <fwp_main_thread+0x147c>  // b.any
    95bc:	294308c7 	ldp	w7, w2, [x6, #24]
    95c0:	92403c21 	and	x1, x1, #0xffff
    95c4:	9b077c21 	mul	x1, x1, x7
    95c8:	d360fc21 	lsr	x1, x1, #32
    95cc:	eb02003f 	cmp	x1, x2
    95d0:	540000e2 	b.cs	95ec <fwp_main_thread+0x147c>  // b.hs, b.nlast
    95d4:	8b010000 	add	x0, x0, x1
    95d8:	39400001 	ldrb	w1, [x0]
    95dc:	7103fc3f 	cmp	w1, #0xff
    95e0:	54003b80 	b.eq	9d50 <fwp_main_thread+0x1be0>  // b.none
    95e4:	52800021 	mov	w1, #0x1                   	// #1
    95e8:	39000001 	strb	w1, [x0]
    95ec:	d100077b 	sub	x27, x27, #0x1
    95f0:	eb1b02ff 	cmp	x23, x27
    95f4:	54000362 	b.cs	9660 <fwp_main_thread+0x14f0>  // b.hs, b.nlast
    95f8:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    95fc:	aa1403e1 	mov	x1, x20
    9600:	52800020 	mov	w0, #0x1                   	// #1
    9604:	a90f63e2 	stp	x2, x24, [sp, #240]
    9608:	97ffee9f 	bl	5084 <fwp_data.part.0.constprop.0>
    960c:	aa0003f8 	mov	x24, x0
    9610:	f949db41 	ldr	x1, [x26, #5040]
    9614:	f949ef40 	ldr	x0, [x26, #5080]
    9618:	cb010301 	sub	x1, x24, x1
    961c:	eb00403f 	cmp	x1, x0, lsl #16
    9620:	54fffe62 	b.cs	95ec <fwp_main_thread+0x147c>  // b.hs, b.nlast
    9624:	d350fc20 	lsr	x0, x1, #16
    9628:	f949ff47 	ldr	x7, [x26, #5112]
    962c:	8b000800 	add	x0, x0, x0, lsl #2
    9630:	d37df002 	lsl	x2, x0, #3
    9634:	8b0200e6 	add	x6, x7, x2
    9638:	f94010c0 	ldr	x0, [x6, #32]
    963c:	b4fffd80 	cbz	x0, 95ec <fwp_main_thread+0x147c>
    9640:	386268e2 	ldrb	w2, [x7, x2]
    9644:	7100085f 	cmp	w2, #0x2
    9648:	54fffb61 	b.ne	95b4 <fwp_main_thread+0x1444>  // b.any
    964c:	72003c3f 	tst	w1, #0xffff
    9650:	54fffc40 	b.eq	95d8 <fwp_main_thread+0x1468>  // b.none
    9654:	d100077b 	sub	x27, x27, #0x1
    9658:	eb1b02ff 	cmp	x23, x27
    965c:	54fffce3 	b.cc	95f8 <fwp_main_thread+0x1488>  // b.lo, b.ul, b.last
    9660:	b50006b7 	cbnz	x23, 9734 <fwp_main_thread+0x15c4>
    9664:	b94003e0 	ldr	w0, [sp]
    9668:	d2800037 	mov	x23, #0x1                   	// #1
    966c:	d280001b 	mov	x27, #0x0                   	// #0
    9670:	7100001f 	cmp	w0, #0x0
    9674:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    9678:	b40004fb 	cbz	x27, 9714 <fwp_main_thread+0x15a4>
    967c:	d100077b 	sub	x27, x27, #0x1
    9680:	f87b7b82 	ldr	x2, [x28, x27, lsl #3]
    9684:	aa1403e1 	mov	x1, x20
    9688:	52800020 	mov	w0, #0x1                   	// #1
    968c:	a90f63e2 	stp	x2, x24, [sp, #240]
    9690:	97ffee7d 	bl	5084 <fwp_data.part.0.constprop.0>
    9694:	aa0003f8 	mov	x24, x0
    9698:	f949db41 	ldr	x1, [x26, #5040]
    969c:	f949ef40 	ldr	x0, [x26, #5080]
    96a0:	cb010301 	sub	x1, x24, x1
    96a4:	eb00403f 	cmp	x1, x0, lsl #16
    96a8:	54000302 	b.cs	9708 <fwp_main_thread+0x1598>  // b.hs, b.nlast
    96ac:	d350fc22 	lsr	x2, x1, #16
    96b0:	f949ff45 	ldr	x5, [x26, #5112]
    96b4:	8b020842 	add	x2, x2, x2, lsl #2
    96b8:	d37df042 	lsl	x2, x2, #3
    96bc:	8b0200a3 	add	x3, x5, x2
    96c0:	f9401079 	ldr	x25, [x3, #32]
    96c4:	b4000239 	cbz	x25, 9708 <fwp_main_thread+0x1598>
    96c8:	386268a2 	ldrb	w2, [x5, x2]
    96cc:	7100085f 	cmp	w2, #0x2
    96d0:	54002000 	b.eq	9ad0 <fwp_main_thread+0x1960>  // b.none
    96d4:	7100045f 	cmp	w2, #0x1
    96d8:	54000181 	b.ne	9708 <fwp_main_thread+0x1598>  // b.any
    96dc:	29430865 	ldp	w5, w2, [x3, #24]
    96e0:	92403c21 	and	x1, x1, #0xffff
    96e4:	9b057c21 	mul	x1, x1, x5
    96e8:	d360fc21 	lsr	x1, x1, #32
    96ec:	eb02003f 	cmp	x1, x2
    96f0:	540000c2 	b.cs	9708 <fwp_main_thread+0x1598>  // b.hs, b.nlast
    96f4:	8b010339 	add	x25, x25, x1
    96f8:	39400321 	ldrb	w1, [x25]
    96fc:	7103fc3f 	cmp	w1, #0xff
    9700:	54001e20 	b.eq	9ac4 <fwp_main_thread+0x1954>  // b.none
    9704:	39000337 	strb	w23, [x25]
    9708:	d100077b 	sub	x27, x27, #0x1
    970c:	b100077f 	cmn	x27, #0x1
    9710:	54fffb81 	b.ne	9680 <fwp_main_thread+0x1510>  // b.any
    9714:	aa1503fb 	mov	x27, x21
    9718:	14000015 	b	976c <fwp_main_thread+0x15fc>
    971c:	72003c1f 	tst	w0, #0xffff
    9720:	54fff3a0 	b.eq	9594 <fwp_main_thread+0x1424>  // b.none
    9724:	eb1b02ff 	cmp	x23, x27
    9728:	54fff403 	b.cc	95a8 <fwp_main_thread+0x1438>  // b.lo, b.ul, b.last
    972c:	d503201f 	nop
    9730:	d2800018 	mov	x24, #0x0                   	// #0
    9734:	8b170f83 	add	x3, x28, x23, lsl #3
    9738:	aa1c03e0 	mov	x0, x28
    973c:	aa1503fb 	mov	x27, x21
    9740:	f8408401 	ldr	x1, [x0], #8
    9744:	f9000761 	str	x1, [x27, #8]
    9748:	aa1b03e1 	mov	x1, x27
    974c:	f9400b7b 	ldr	x27, [x27, #16]
    9750:	eb03001f 	cmp	x0, x3
    9754:	54ffff61 	b.ne	9740 <fwp_main_thread+0x15d0>  // b.any
    9758:	b94003e0 	ldr	w0, [sp]
    975c:	f9000838 	str	x24, [x1, #16]
    9760:	aa1503f8 	mov	x24, x21
    9764:	7100001f 	cmp	w0, #0x0
    9768:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    976c:	aa1c03e0 	mov	x0, x28
    9770:	97ffece0 	bl	4af0 <fwp_mem_free>
    9774:	f949ef42 	ldr	x2, [x26, #5080]
    9778:	f949db41 	ldr	x1, [x26, #5040]
    977c:	d370bc42 	lsl	x2, x2, #16
    9780:	cb0102c3 	sub	x3, x22, x1
    9784:	eb02007f 	cmp	x3, x2
    9788:	54000402 	b.cs	9808 <fwp_main_thread+0x1698>  // b.hs, b.nlast
    978c:	d350fc60 	lsr	x0, x3, #16
    9790:	f949ff45 	ldr	x5, [x26, #5112]
    9794:	8b000800 	add	x0, x0, x0, lsl #2
    9798:	d37df000 	lsl	x0, x0, #3
    979c:	8b0000a2 	add	x2, x5, x0
    97a0:	f9401057 	ldr	x23, [x2, #32]
    97a4:	b4001897 	cbz	x23, 9ab4 <fwp_main_thread+0x1944>
    97a8:	386068a1 	ldrb	w1, [x5, x0]
    97ac:	7100083f 	cmp	w1, #0x2
    97b0:	54002e60 	b.eq	9d7c <fwp_main_thread+0x1c0c>  // b.none
    97b4:	7100043f 	cmp	w1, #0x1
    97b8:	540017e1 	b.ne	9ab4 <fwp_main_thread+0x1944>  // b.any
    97bc:	29430846 	ldp	w6, w2, [x2, #24]
    97c0:	92403c61 	and	x1, x3, #0xffff
    97c4:	9b067c21 	mul	x1, x1, x6
    97c8:	d360fc21 	lsr	x1, x1, #32
    97cc:	eb02003f 	cmp	x1, x2
    97d0:	54001722 	b.cs	9ab4 <fwp_main_thread+0x1944>  // b.hs, b.nlast
    97d4:	8b0102f7 	add	x23, x23, x1
    97d8:	394002e1 	ldrb	w1, [x23]
    97dc:	340016c1 	cbz	w1, 9ab4 <fwp_main_thread+0x1944>
    97e0:	7100043f 	cmp	w1, #0x1
    97e4:	54001280 	b.eq	9a34 <fwp_main_thread+0x18c4>  // b.none
    97e8:	7103fc3f 	cmp	w1, #0xff
    97ec:	54004580 	b.eq	a09c <fwp_main_thread+0x1f2c>  // b.none
    97f0:	51000421 	sub	w1, w1, #0x1
    97f4:	390002e1 	strb	w1, [x23]
    97f8:	f949ef42 	ldr	x2, [x26, #5080]
    97fc:	f949db41 	ldr	x1, [x26, #5040]
    9800:	d370bc42 	lsl	x2, x2, #16
    9804:	d503201f 	nop
    9808:	cb010361 	sub	x1, x27, x1
    980c:	eb01005f 	cmp	x2, x1
    9810:	54000389 	b.ls	9880 <fwp_main_thread+0x1710>  // b.plast
    9814:	d350fc20 	lsr	x0, x1, #16
    9818:	f949ff43 	ldr	x3, [x26, #5112]
    981c:	8b000800 	add	x0, x0, x0, lsl #2
    9820:	d37df000 	lsl	x0, x0, #3
    9824:	8b000062 	add	x2, x3, x0
    9828:	f9401056 	ldr	x22, [x2, #32]
    982c:	b40002b6 	cbz	x22, 9880 <fwp_main_thread+0x1710>
    9830:	38606865 	ldrb	w5, [x3, x0]
    9834:	710008bf 	cmp	w5, #0x2
    9838:	54002e80 	b.eq	9e08 <fwp_main_thread+0x1c98>  // b.none
    983c:	710004bf 	cmp	w5, #0x1
    9840:	54000201 	b.ne	9880 <fwp_main_thread+0x1710>  // b.any
    9844:	29430845 	ldp	w5, w2, [x2, #24]
    9848:	92403c21 	and	x1, x1, #0xffff
    984c:	9b057c21 	mul	x1, x1, x5
    9850:	d360fc21 	lsr	x1, x1, #32
    9854:	eb02003f 	cmp	x1, x2
    9858:	54000142 	b.cs	9880 <fwp_main_thread+0x1710>  // b.hs, b.nlast
    985c:	8b0102d6 	add	x22, x22, x1
    9860:	394002c1 	ldrb	w1, [x22]
    9864:	340000e1 	cbz	w1, 9880 <fwp_main_thread+0x1710>
    9868:	7100043f 	cmp	w1, #0x1
    986c:	54003520 	b.eq	9f10 <fwp_main_thread+0x1da0>  // b.none
    9870:	7103fc3f 	cmp	w1, #0xff
    9874:	540047e0 	b.eq	a170 <fwp_main_thread+0x2000>  // b.none
    9878:	51000421 	sub	w1, w1, #0x1
    987c:	390002c1 	strb	w1, [x22]
    9880:	f9400be0 	ldr	x0, [sp, #16]
    9884:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x112f0>
    9888:	910aa042 	add	x2, x2, #0x2a8
    988c:	aa1803e1 	mov	x1, x24
    9890:	91014042 	add	x2, x2, #0x50
    9894:	52800023 	mov	w3, #0x1                   	// #1
    9898:	a908ffff 	stp	xzr, xzr, [sp, #136]
    989c:	f9004fff 	str	xzr, [sp, #152]
    98a0:	97fff639 	bl	7184 <fwp_write>
    98a4:	a948eff7 	ldp	x23, x27, [sp, #136]
    98a8:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    98ac:	911b4000 	add	x0, x0, #0x6d0
    98b0:	f10002ff 	cmp	x23, #0x0
    98b4:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    98b8:	b1002b7f 	cmn	x27, #0xa
    98bc:	540058e8 	b.hi	a3d8 <fwp_main_thread+0x2268>  // b.pmore
    98c0:	91002760 	add	x0, x27, #0x9
    98c4:	52800021 	mov	w1, #0x1                   	// #1
    98c8:	97ffedaa 	bl	4f70 <fwp_heap_alloc>
    98cc:	aa0003fc 	mov	x28, x0
    98d0:	aa0003f6 	mov	x22, x0
    98d4:	aa1b03e2 	mov	x2, x27
    98d8:	aa1703e1 	mov	x1, x23
    98dc:	f800879b 	str	x27, [x28], #8
    98e0:	8b1b02db 	add	x27, x22, x27
    98e4:	aa1c03e0 	mov	x0, x28
    98e8:	97ffe39e 	bl	2760 <memcpy@plt>
    98ec:	3900237f 	strb	wzr, [x27, #8]
    98f0:	f94047e0 	ldr	x0, [sp, #136]
    98f4:	97ffe437 	bl	29d0 <free@plt>
    98f8:	f949db42 	ldr	x2, [x26, #5040]
    98fc:	f949ef40 	ldr	x0, [x26, #5080]
    9900:	cb0202c2 	sub	x2, x22, x2
    9904:	eb00405f 	cmp	x2, x0, lsl #16
    9908:	54000322 	b.cs	996c <fwp_main_thread+0x17fc>  // b.hs, b.nlast
    990c:	d350fc40 	lsr	x0, x2, #16
    9910:	f949ff43 	ldr	x3, [x26, #5112]
    9914:	8b000800 	add	x0, x0, x0, lsl #2
    9918:	d37df001 	lsl	x1, x0, #3
    991c:	8b010060 	add	x0, x3, x1
    9920:	f9401017 	ldr	x23, [x0, #32]
    9924:	b4000257 	cbz	x23, 996c <fwp_main_thread+0x17fc>
    9928:	38616861 	ldrb	w1, [x3, x1]
    992c:	7100083f 	cmp	w1, #0x2
    9930:	540041a0 	b.eq	a164 <fwp_main_thread+0x1ff4>  // b.none
    9934:	7100043f 	cmp	w1, #0x1
    9938:	540001a1 	b.ne	996c <fwp_main_thread+0x17fc>  // b.any
    993c:	29430003 	ldp	w3, w0, [x0, #24]
    9940:	92403c41 	and	x1, x2, #0xffff
    9944:	9b037c21 	mul	x1, x1, x3
    9948:	d360fc21 	lsr	x1, x1, #32
    994c:	eb00003f 	cmp	x1, x0
    9950:	540000e2 	b.cs	996c <fwp_main_thread+0x17fc>  // b.hs, b.nlast
    9954:	8b0102f7 	add	x23, x23, x1
    9958:	394002e0 	ldrb	w0, [x23]
    995c:	7103fc1f 	cmp	w0, #0xff
    9960:	54004920 	b.eq	a284 <fwp_main_thread+0x2114>  // b.none
    9964:	52800020 	mov	w0, #0x1                   	// #1
    9968:	390002e0 	strb	w0, [x23]
    996c:	9101c277 	add	x23, x19, #0x70
    9970:	aa1803e0 	mov	x0, x24
    9974:	97fff06f 	bl	5b30 <fwp_drop0>
    9978:	f94002c2 	ldr	x2, [x22]
    997c:	d2800021 	mov	x1, #0x1                   	// #1
    9980:	f94006e3 	ldr	x3, [x23, #8]
    9984:	aa1c03e0 	mov	x0, x28
    9988:	97ffe422 	bl	2a10 <fwrite@plt>
    998c:	f94006e1 	ldr	x1, [x23, #8]
    9990:	52800140 	mov	w0, #0xa                   	// #10
    9994:	97ffe3a7 	bl	2830 <fputc@plt>
    9998:	f949db42 	ldr	x2, [x26, #5040]
    999c:	f949ef40 	ldr	x0, [x26, #5080]
    99a0:	cb0202c2 	sub	x2, x22, x2
    99a4:	eb00405f 	cmp	x2, x0, lsl #16
    99a8:	54000382 	b.cs	9a18 <fwp_main_thread+0x18a8>  // b.hs, b.nlast
    99ac:	d350fc40 	lsr	x0, x2, #16
    99b0:	f949ff43 	ldr	x3, [x26, #5112]
    99b4:	8b000800 	add	x0, x0, x0, lsl #2
    99b8:	d37df001 	lsl	x1, x0, #3
    99bc:	8b010060 	add	x0, x3, x1
    99c0:	f9401017 	ldr	x23, [x0, #32]
    99c4:	b40002b7 	cbz	x23, 9a18 <fwp_main_thread+0x18a8>
    99c8:	38616861 	ldrb	w1, [x3, x1]
    99cc:	7100083f 	cmp	w1, #0x2
    99d0:	54003fe0 	b.eq	a1cc <fwp_main_thread+0x205c>  // b.none
    99d4:	7100043f 	cmp	w1, #0x1
    99d8:	54000201 	b.ne	9a18 <fwp_main_thread+0x18a8>  // b.any
    99dc:	29430003 	ldp	w3, w0, [x0, #24]
    99e0:	92403c41 	and	x1, x2, #0xffff
    99e4:	9b037c21 	mul	x1, x1, x3
    99e8:	d360fc21 	lsr	x1, x1, #32
    99ec:	eb00003f 	cmp	x1, x0
    99f0:	54000142 	b.cs	9a18 <fwp_main_thread+0x18a8>  // b.hs, b.nlast
    99f4:	8b0102f7 	add	x23, x23, x1
    99f8:	394002e0 	ldrb	w0, [x23]
    99fc:	340000e0 	cbz	w0, 9a18 <fwp_main_thread+0x18a8>
    9a00:	7100041f 	cmp	w0, #0x1
    9a04:	54003100 	b.eq	a024 <fwp_main_thread+0x1eb4>  // b.none
    9a08:	7103fc1f 	cmp	w0, #0xff
    9a0c:	540048e0 	b.eq	a328 <fwp_main_thread+0x21b8>  // b.none
    9a10:	51000400 	sub	w0, w0, #0x1
    9a14:	390002e0 	strb	w0, [x23]
    9a18:	f94027e0 	ldr	x0, [sp, #72]
    9a1c:	f9400800 	ldr	x0, [x0, #16]
    9a20:	f90027e0 	str	x0, [sp, #72]
    9a24:	b40030c0 	cbz	x0, a03c <fwp_main_thread+0x1ecc>
    9a28:	9101c260 	add	x0, x19, #0x70
    9a2c:	f9418816 	ldr	x22, [x0, #784]
    9a30:	17fffb74 	b	8800 <fwp_main_thread+0x690>
    9a34:	f94002c3 	ldr	x3, [x22]
    9a38:	aa1603e0 	mov	x0, x22
    9a3c:	f949ef42 	ldr	x2, [x26, #5080]
    9a40:	f949db41 	ldr	x1, [x26, #5040]
    9a44:	d370bc42 	lsl	x2, x2, #16
    9a48:	cb0102c8 	sub	x8, x22, x1
    9a4c:	b7f81e43 	tbnz	x3, #63, 9e14 <fwp_main_thread+0x1ca4>
    9a50:	eb08005f 	cmp	x2, x8
    9a54:	54ffeda9 	b.ls	9808 <fwp_main_thread+0x1698>  // b.plast
    9a58:	d350fd03 	lsr	x3, x8, #16
    9a5c:	8b030863 	add	x3, x3, x3, lsl #2
    9a60:	d37df063 	lsl	x3, x3, #3
    9a64:	8b0300a7 	add	x7, x5, x3
    9a68:	f94010e6 	ldr	x6, [x7, #32]
    9a6c:	b4ffece6 	cbz	x6, 9808 <fwp_main_thread+0x1698>
    9a70:	386368a3 	ldrb	w3, [x5, x3]
    9a74:	7100087f 	cmp	w3, #0x2
    9a78:	54002980 	b.eq	9fa8 <fwp_main_thread+0x1e38>  // b.none
    9a7c:	7100047f 	cmp	w3, #0x1
    9a80:	54ffec41 	b.ne	9808 <fwp_main_thread+0x1698>  // b.any
    9a84:	29430ce5 	ldp	w5, w3, [x7, #24]
    9a88:	92403d00 	and	x0, x8, #0xffff
    9a8c:	9b057c00 	mul	x0, x0, x5
    9a90:	d360fc00 	lsr	x0, x0, #32
    9a94:	eb03001f 	cmp	x0, x3
    9a98:	54ffeb82 	b.cs	9808 <fwp_main_thread+0x1698>  // b.hs, b.nlast
    9a9c:	8b0000c6 	add	x6, x6, x0
    9aa0:	394000c0 	ldrb	w0, [x6]
    9aa4:	7100041f 	cmp	w0, #0x1
    9aa8:	54ffeb01 	b.ne	9808 <fwp_main_thread+0x1698>  // b.any
    9aac:	aa1603e0 	mov	x0, x22
    9ab0:	97ffec10 	bl	4af0 <fwp_mem_free>
    9ab4:	f949ef42 	ldr	x2, [x26, #5080]
    9ab8:	f949db41 	ldr	x1, [x26, #5040]
    9abc:	d370bc42 	lsl	x2, x2, #16
    9ac0:	17ffff52 	b	9808 <fwp_main_thread+0x1698>
    9ac4:	aa1903e0 	mov	x0, x25
    9ac8:	97ffeb6a 	bl	4870 <fwp_rc_forget_slot>
    9acc:	17ffff0e 	b	9704 <fwp_main_thread+0x1594>
    9ad0:	72003c3f 	tst	w1, #0xffff
    9ad4:	54ffe1a1 	b.ne	9708 <fwp_main_thread+0x1598>  // b.any
    9ad8:	17ffff08 	b	96f8 <fwp_main_thread+0x1588>
    9adc:	72003c3f 	tst	w1, #0xffff
    9ae0:	54ffcd40 	b.eq	9488 <fwp_main_thread+0x1318>  // b.none
    9ae4:	b40010f5 	cbz	x21, 9d00 <fwp_main_thread+0x1b90>
    9ae8:	aa1503f7 	mov	x23, x21
    9aec:	d2800018 	mov	x24, #0x0                   	// #0
    9af0:	f9400af7 	ldr	x23, [x23, #16]
    9af4:	aa1803e0 	mov	x0, x24
    9af8:	91000718 	add	x24, x24, #0x1
    9afc:	b5ffffb7 	cbnz	x23, 9af0 <fwp_main_thread+0x1980>
    9b00:	f90003e5 	str	x5, [sp]
    9b04:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9b08:	eb01031f 	cmp	x24, x1
    9b0c:	54004428 	b.hi	a390 <fwp_main_thread+0x2220>  // b.pmore
    9b10:	91000800 	add	x0, x0, #0x2
    9b14:	52800041 	mov	w1, #0x2                   	// #2
    9b18:	d37df000 	lsl	x0, x0, #3
    9b1c:	97ffed15 	bl	4f70 <fwp_heap_alloc>
    9b20:	f94003e5 	ldr	x5, [sp]
    9b24:	eb1b031f 	cmp	x24, x27
    9b28:	9a9b931b 	csel	x27, x24, x27, ls	// ls = plast
    9b2c:	aa0003fc 	mov	x28, x0
    9b30:	aa1503e1 	mov	x1, x21
    9b34:	d503201f 	nop
    9b38:	f9400420 	ldr	x0, [x1, #8]
    9b3c:	f8377b80 	str	x0, [x28, x23, lsl #3]
    9b40:	910006f7 	add	x23, x23, #0x1
    9b44:	f9400821 	ldr	x1, [x1, #16]
    9b48:	b5ffff81 	cbnz	x1, 9b38 <fwp_main_thread+0x19c8>
    9b4c:	b4000e3b 	cbz	x27, 9d10 <fwp_main_thread+0x1ba0>
    9b50:	f94000a0 	ldr	x0, [x5]
    9b54:	b90003ff 	str	wzr, [sp]
    9b58:	17fffe54 	b	94a8 <fwp_main_thread+0x1338>
    9b5c:	d53bd040 	mrs	x0, tpidr_el0
    9b60:	91400000 	add	x0, x0, #0x0, lsl #12
    9b64:	91004000 	add	x0, x0, #0x10
    9b68:	f9400000 	ldr	x0, [x0]
    9b6c:	b4001940 	cbz	x0, 9e94 <fwp_main_thread+0x1d24>
    9b70:	f9401fe1 	ldr	x1, [sp, #56]
    9b74:	97ffe75c 	bl	38e4 <fwp_closure_drop_push>
    9b78:	b5ff71b5 	cbnz	x21, 89ac <fwp_main_thread+0x83c>
    9b7c:	9101c277 	add	x23, x19, #0x70
    9b80:	52800000 	mov	w0, #0x0                   	// #0
    9b84:	97ffe6bb 	bl	3670 <descent_phase_step>
    9b88:	d2800016 	mov	x22, #0x0                   	// #0
    9b8c:	b9434ee0 	ldr	w0, [x23, #844]
    9b90:	35ff72a0 	cbnz	w0, 89e4 <fwp_main_thread+0x874>
    9b94:	d503201f 	nop
    9b98:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0xe0>
    9b9c:	91014000 	add	x0, x0, #0x50
    9ba0:	940003ec 	bl	ab50 <atexit>
    9ba4:	35ffbd00 	cbnz	w0, 9344 <fwp_main_thread+0x11d4>
    9ba8:	52800020 	mov	w0, #0x1                   	// #1
    9bac:	b9034ee0 	str	w0, [x23, #844]
    9bb0:	9101c260 	add	x0, x19, #0x70
    9bb4:	f9404817 	ldr	x23, [x0, #144]
    9bb8:	f9407401 	ldr	x1, [x0, #232]
    9bbc:	eb17003f 	cmp	x1, x23
    9bc0:	54ff71cb 	b.lt	89f8 <fwp_main_thread+0x888>  // b.tstop
    9bc4:	d503201f 	nop
    9bc8:	eb0102ff 	cmp	x23, x1
    9bcc:	54ff7340 	b.eq	8a34 <fwp_main_thread+0x8c4>  // b.none
    9bd0:	aa0103f7 	mov	x23, x1
    9bd4:	9100043c 	add	x28, x1, #0x1
    9bd8:	d37ff821 	lsl	x1, x1, #1
    9bdc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    9be0:	f9403a7b 	ldr	x27, [x19, #112]
    9be4:	8b170021 	add	x1, x1, x23
    9be8:	9139c000 	add	x0, x0, #0xe70
    9bec:	8b010ae1 	add	x1, x23, x1, lsl #2
    9bf0:	8b010f78 	add	x24, x27, x1, lsl #3
    9bf4:	f900331f 	str	xzr, [x24, #96]
    9bf8:	97ffe3aa 	bl	2aa0 <getenv@plt>
    9bfc:	b5ff7720 	cbnz	x0, 8ae0 <fwp_main_thread+0x970>
    9c00:	9101c260 	add	x0, x19, #0x70
    9c04:	f9406801 	ldr	x1, [x0, #208]
    9c08:	b4ff7761 	cbz	x1, 8af4 <fwp_main_thread+0x984>
    9c0c:	3cc98002 	ldur	q2, [x0, #152]
    9c10:	91026001 	add	x1, x0, #0x98
    9c14:	3cca8001 	ldur	q1, [x0, #168]
    9c18:	f900681f 	str	xzr, [x0, #208]
    9c1c:	4f000400 	movi	v0.4s, #0x0
    9c20:	ad010702 	stp	q2, q1, [x24, #32]
    9c24:	f9405c02 	ldr	x2, [x0, #184]
    9c28:	f9406400 	ldr	x0, [x0, #200]
    9c2c:	a9040302 	stp	x2, x0, [x24, #64]
    9c30:	f9401422 	ldr	x2, [x1, #40]
    9c34:	f9000f02 	str	x2, [x24, #24]
    9c38:	f900183f 	str	xzr, [x1, #48]
    9c3c:	ad000020 	stp	q0, q0, [x1]
    9c40:	3d800820 	str	q0, [x1, #32]
    9c44:	17fffbac 	b	8af4 <fwp_main_thread+0x984>
    9c48:	72003c1f 	tst	w0, #0xffff
    9c4c:	54ffa5a0 	b.eq	9100 <fwp_main_thread+0xf90>  // b.none
    9c50:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9c54:	eb00031f 	cmp	x24, x0
    9c58:	54003e88 	b.hi	a428 <fwp_main_thread+0x22b8>  // b.pmore
    9c5c:	91000700 	add	x0, x24, #0x1
    9c60:	52800021 	mov	w1, #0x1                   	// #1
    9c64:	d37df000 	lsl	x0, x0, #3
    9c68:	97ffecc2 	bl	4f70 <fwp_heap_alloc>
    9c6c:	f9000018 	str	x24, [x0]
    9c70:	aa0003e5 	mov	x5, x0
    9c74:	aa0003f6 	mov	x22, x0
    9c78:	f949db41 	ldr	x1, [x26, #5040]
    9c7c:	f949ef40 	ldr	x0, [x26, #5080]
    9c80:	cb0100a1 	sub	x1, x5, x1
    9c84:	eb00403f 	cmp	x1, x0, lsl #16
    9c88:	54000322 	b.cs	9cec <fwp_main_thread+0x1b7c>  // b.hs, b.nlast
    9c8c:	d350fc20 	lsr	x0, x1, #16
    9c90:	f949ff43 	ldr	x3, [x26, #5112]
    9c94:	8b000800 	add	x0, x0, x0, lsl #2
    9c98:	d37df002 	lsl	x2, x0, #3
    9c9c:	8b020060 	add	x0, x3, x2
    9ca0:	f940101b 	ldr	x27, [x0, #32]
    9ca4:	b400025b 	cbz	x27, 9cec <fwp_main_thread+0x1b7c>
    9ca8:	38626862 	ldrb	w2, [x3, x2]
    9cac:	7100085f 	cmp	w2, #0x2
    9cb0:	54001820 	b.eq	9fb4 <fwp_main_thread+0x1e44>  // b.none
    9cb4:	7100045f 	cmp	w2, #0x1
    9cb8:	540001a1 	b.ne	9cec <fwp_main_thread+0x1b7c>  // b.any
    9cbc:	29430002 	ldp	w2, w0, [x0, #24]
    9cc0:	92403c21 	and	x1, x1, #0xffff
    9cc4:	9b027c21 	mul	x1, x1, x2
    9cc8:	d360fc21 	lsr	x1, x1, #32
    9ccc:	eb00003f 	cmp	x1, x0
    9cd0:	540000e2 	b.cs	9cec <fwp_main_thread+0x1b7c>  // b.hs, b.nlast
    9cd4:	8b01037b 	add	x27, x27, x1
    9cd8:	39400360 	ldrb	w0, [x27]
    9cdc:	7103fc1f 	cmp	w0, #0xff
    9ce0:	54001720 	b.eq	9fc4 <fwp_main_thread+0x1e54>  // b.none
    9ce4:	52800020 	mov	w0, #0x1                   	// #1
    9ce8:	39000360 	strb	w0, [x27]
    9cec:	aa1703e0 	mov	x0, x23
    9cf0:	17fffd0a 	b	9118 <fwp_main_thread+0xfa8>
    9cf4:	eb17037f 	cmp	x27, x23
    9cf8:	54ffc588 	b.hi	95a8 <fwp_main_thread+0x1438>  // b.pmore
    9cfc:	17fffe8d 	b	9730 <fwp_main_thread+0x15c0>
    9d00:	52800041 	mov	w1, #0x2                   	// #2
    9d04:	d2800100 	mov	x0, #0x8                   	// #8
    9d08:	97ffec9a 	bl	4f70 <fwp_heap_alloc>
    9d0c:	aa0003fc 	mov	x28, x0
    9d10:	aa1503fb 	mov	x27, x21
    9d14:	d2800018 	mov	x24, #0x0                   	// #0
    9d18:	17fffe95 	b	976c <fwp_main_thread+0x15fc>
    9d1c:	52800041 	mov	w1, #0x2                   	// #2
    9d20:	d2800100 	mov	x0, #0x8                   	// #8
    9d24:	97ffec93 	bl	4f70 <fwp_heap_alloc>
    9d28:	f900001f 	str	xzr, [x0]
    9d2c:	aa0003f8 	mov	x24, x0
    9d30:	aa0003fb 	mov	x27, x0
    9d34:	f949db41 	ldr	x1, [x26, #5040]
    9d38:	f949ef40 	ldr	x0, [x26, #5080]
    9d3c:	cb010301 	sub	x1, x24, x1
    9d40:	eb00403f 	cmp	x1, x0, lsl #16
    9d44:	54000122 	b.cs	9d68 <fwp_main_thread+0x1bf8>  // b.hs, b.nlast
    9d48:	d2800017 	mov	x23, #0x0                   	// #0
    9d4c:	17fffbad 	b	8c00 <fwp_main_thread+0xa90>
    9d50:	f90007e0 	str	x0, [sp, #8]
    9d54:	97ffeac7 	bl	4870 <fwp_rc_forget_slot>
    9d58:	f94007e0 	ldr	x0, [sp, #8]
    9d5c:	17fffe22 	b	95e4 <fwp_main_thread+0x1474>
    9d60:	b5ff7837 	cbnz	x23, 8c64 <fwp_main_thread+0xaf4>
    9d64:	d503201f 	nop
    9d68:	d280001c 	mov	x28, #0x0                   	// #0
    9d6c:	17fffbe4 	b	8cfc <fwp_main_thread+0xb8c>
    9d70:	72003c3f 	tst	w1, #0xffff
    9d74:	54ff80e1 	b.ne	8d90 <fwp_main_thread+0xc20>  // b.any
    9d78:	17fffbfd 	b	8d6c <fwp_main_thread+0xbfc>
    9d7c:	72003c7f 	tst	w3, #0xffff
    9d80:	54ffe9a1 	b.ne	9ab4 <fwp_main_thread+0x1944>  // b.any
    9d84:	17fffe95 	b	97d8 <fwp_main_thread+0x1668>
    9d88:	f940077b 	ldr	x27, [x27, #8]
    9d8c:	eb02007f 	cmp	x3, x2
    9d90:	54000349 	b.ls	9df8 <fwp_main_thread+0x1c88>  // b.plast
    9d94:	d350fc46 	lsr	x6, x2, #16
    9d98:	8b0608c6 	add	x6, x6, x6, lsl #2
    9d9c:	d37df0c6 	lsl	x6, x6, #3
    9da0:	8b0600a9 	add	x9, x5, x6
    9da4:	f9401128 	ldr	x8, [x9, #32]
    9da8:	b4000288 	cbz	x8, 9df8 <fwp_main_thread+0x1c88>
    9dac:	386668a5 	ldrb	w5, [x5, x6]
    9db0:	710008bf 	cmp	w5, #0x2
    9db4:	54001620 	b.eq	a078 <fwp_main_thread+0x1f08>  // b.none
    9db8:	710004bf 	cmp	w5, #0x1
    9dbc:	540001e1 	b.ne	9df8 <fwp_main_thread+0x1c88>  // b.any
    9dc0:	29431526 	ldp	w6, w5, [x9, #24]
    9dc4:	92403c42 	and	x2, x2, #0xffff
    9dc8:	9b067c42 	mul	x2, x2, x6
    9dcc:	d360fc42 	lsr	x2, x2, #32
    9dd0:	eb05005f 	cmp	x2, x5
    9dd4:	54000122 	b.cs	9df8 <fwp_main_thread+0x1c88>  // b.hs, b.nlast
    9dd8:	8b020108 	add	x8, x8, x2
    9ddc:	39400102 	ldrb	w2, [x8]
    9de0:	7100045f 	cmp	w2, #0x1
    9de4:	540000a1 	b.ne	9df8 <fwp_main_thread+0x1c88>  // b.any
    9de8:	97ffeb42 	bl	4af0 <fwp_mem_free>
    9dec:	f949ef43 	ldr	x3, [x26, #5080]
    9df0:	f949db41 	ldr	x1, [x26, #5040]
    9df4:	d370bc63 	lsl	x3, x3, #16
    9df8:	cb010361 	sub	x1, x27, x1
    9dfc:	eb03003f 	cmp	x1, x3
    9e00:	54ff7903 	b.cc	8d20 <fwp_main_thread+0xbb0>  // b.lo, b.ul, b.last
    9e04:	17fffbe3 	b	8d90 <fwp_main_thread+0xc20>
    9e08:	72003c3f 	tst	w1, #0xffff
    9e0c:	54ffd3a1 	b.ne	9880 <fwp_main_thread+0x1710>  // b.any
    9e10:	17fffe94 	b	9860 <fwp_main_thread+0x16f0>
    9e14:	f94006d6 	ldr	x22, [x22, #8]
    9e18:	eb08005f 	cmp	x2, x8
    9e1c:	54000349 	b.ls	9e84 <fwp_main_thread+0x1d14>  // b.plast
    9e20:	d350fd03 	lsr	x3, x8, #16
    9e24:	8b030863 	add	x3, x3, x3, lsl #2
    9e28:	d37df063 	lsl	x3, x3, #3
    9e2c:	8b0300a7 	add	x7, x5, x3
    9e30:	f94010e6 	ldr	x6, [x7, #32]
    9e34:	b4000286 	cbz	x6, 9e84 <fwp_main_thread+0x1d14>
    9e38:	386368a3 	ldrb	w3, [x5, x3]
    9e3c:	7100087f 	cmp	w3, #0x2
    9e40:	54001160 	b.eq	a06c <fwp_main_thread+0x1efc>  // b.none
    9e44:	7100047f 	cmp	w3, #0x1
    9e48:	540001e1 	b.ne	9e84 <fwp_main_thread+0x1d14>  // b.any
    9e4c:	294314e9 	ldp	w9, w5, [x7, #24]
    9e50:	92403d03 	and	x3, x8, #0xffff
    9e54:	9b097c63 	mul	x3, x3, x9
    9e58:	d360fc63 	lsr	x3, x3, #32
    9e5c:	eb05007f 	cmp	x3, x5
    9e60:	54000122 	b.cs	9e84 <fwp_main_thread+0x1d14>  // b.hs, b.nlast
    9e64:	8b0300c6 	add	x6, x6, x3
    9e68:	394000c3 	ldrb	w3, [x6]
    9e6c:	7100047f 	cmp	w3, #0x1
    9e70:	540000a1 	b.ne	9e84 <fwp_main_thread+0x1d14>  // b.any
    9e74:	97ffeb1f 	bl	4af0 <fwp_mem_free>
    9e78:	f949ef42 	ldr	x2, [x26, #5080]
    9e7c:	f949db41 	ldr	x1, [x26, #5040]
    9e80:	d370bc42 	lsl	x2, x2, #16
    9e84:	cb0102c3 	sub	x3, x22, x1
    9e88:	eb02007f 	cmp	x3, x2
    9e8c:	54ffc803 	b.cc	978c <fwp_main_thread+0x161c>  // b.lo, b.ul, b.last
    9e90:	17fffe5e 	b	9808 <fwp_main_thread+0x1698>
    9e94:	f9401fe0 	ldr	x0, [sp, #56]
    9e98:	97ffe702 	bl	3aa0 <fwp_closure_drop.part.0>
    9e9c:	17fffac3 	b	89a8 <fwp_main_thread+0x838>
    9ea0:	72003c7f 	tst	w3, #0xffff
    9ea4:	54ff5581 	b.ne	8954 <fwp_main_thread+0x7e4>  // b.any
    9ea8:	aa1603e0 	mov	x0, x22
    9eac:	17fffa98 	b	890c <fwp_main_thread+0x79c>
    9eb0:	72003c7f 	tst	w3, #0xffff
    9eb4:	54ff57a1 	b.ne	89a8 <fwp_main_thread+0x838>  // b.any
    9eb8:	17fffab3 	b	8984 <fwp_main_thread+0x814>
    9ebc:	72003c3f 	tst	w1, #0xffff
    9ec0:	54ff6d01 	b.ne	8c60 <fwp_main_thread+0xaf0>  // b.any
    9ec4:	39400380 	ldrb	w0, [x28]
    9ec8:	7103fc1f 	cmp	w0, #0xff
    9ecc:	54ff6c61 	b.ne	8c58 <fwp_main_thread+0xae8>  // b.any
    9ed0:	aa1c03e0 	mov	x0, x28
    9ed4:	97ffea67 	bl	4870 <fwp_rc_forget_slot>
    9ed8:	17fffb60 	b	8c58 <fwp_main_thread+0xae8>
    9edc:	aa1903f6 	mov	x22, x25
    9ee0:	17fffbe6 	b	8e78 <fwp_main_thread+0xd08>
    9ee4:	72003c3f 	tst	w1, #0xffff
    9ee8:	54ff8c61 	b.ne	9074 <fwp_main_thread+0xf04>  // b.any
    9eec:	394002c0 	ldrb	w0, [x22]
    9ef0:	7103fc1f 	cmp	w0, #0xff
    9ef4:	54ff8bc1 	b.ne	906c <fwp_main_thread+0xefc>  // b.any
    9ef8:	aa1603e0 	mov	x0, x22
    9efc:	97ffea5d 	bl	4870 <fwp_rc_forget_slot>
    9f00:	17fffc5b 	b	906c <fwp_main_thread+0xefc>
    9f04:	72003c5f 	tst	w2, #0xffff
    9f08:	54ff7441 	b.ne	8d90 <fwp_main_thread+0xc20>  // b.any
    9f0c:	17fffd35 	b	93e0 <fwp_main_thread+0x1270>
    9f10:	f949ef45 	ldr	x5, [x26, #5080]
    9f14:	f949db41 	ldr	x1, [x26, #5040]
    9f18:	d370bca5 	lsl	x5, x5, #16
    9f1c:	cb010360 	sub	x0, x27, x1
    9f20:	f9400b76 	ldr	x22, [x27, #16]
    9f24:	eb05001f 	cmp	x0, x5
    9f28:	54000362 	b.cs	9f94 <fwp_main_thread+0x1e24>  // b.hs, b.nlast
    9f2c:	d350fc02 	lsr	x2, x0, #16
    9f30:	8b020842 	add	x2, x2, x2, lsl #2
    9f34:	d37df042 	lsl	x2, x2, #3
    9f38:	8b020067 	add	x7, x3, x2
    9f3c:	f94010e6 	ldr	x6, [x7, #32]
    9f40:	b40002a6 	cbz	x6, 9f94 <fwp_main_thread+0x1e24>
    9f44:	38626862 	ldrb	w2, [x3, x2]
    9f48:	7100085f 	cmp	w2, #0x2
    9f4c:	540009c0 	b.eq	a084 <fwp_main_thread+0x1f14>  // b.none
    9f50:	7100045f 	cmp	w2, #0x1
    9f54:	54000201 	b.ne	9f94 <fwp_main_thread+0x1e24>  // b.any
    9f58:	294308e3 	ldp	w3, w2, [x7, #24]
    9f5c:	92403c00 	and	x0, x0, #0xffff
    9f60:	9b037c00 	mul	x0, x0, x3
    9f64:	d360fc00 	lsr	x0, x0, #32
    9f68:	eb02001f 	cmp	x0, x2
    9f6c:	54000142 	b.cs	9f94 <fwp_main_thread+0x1e24>  // b.hs, b.nlast
    9f70:	8b0000c6 	add	x6, x6, x0
    9f74:	394000c0 	ldrb	w0, [x6]
    9f78:	7100041f 	cmp	w0, #0x1
    9f7c:	540000c1 	b.ne	9f94 <fwp_main_thread+0x1e24>  // b.any
    9f80:	aa1b03e0 	mov	x0, x27
    9f84:	97ffeadb 	bl	4af0 <fwp_mem_free>
    9f88:	f949ef45 	ldr	x5, [x26, #5080]
    9f8c:	f949db41 	ldr	x1, [x26, #5040]
    9f90:	d370bca5 	lsl	x5, x5, #16
    9f94:	cb0102c1 	sub	x1, x22, x1
    9f98:	eb0100bf 	cmp	x5, x1
    9f9c:	54ffc729 	b.ls	9880 <fwp_main_thread+0x1710>  // b.plast
    9fa0:	aa1603fb 	mov	x27, x22
    9fa4:	17fffe1c 	b	9814 <fwp_main_thread+0x16a4>
    9fa8:	72003d1f 	tst	w8, #0xffff
    9fac:	54ffc2e1 	b.ne	9808 <fwp_main_thread+0x1698>  // b.any
    9fb0:	17fffebc 	b	9aa0 <fwp_main_thread+0x1930>
    9fb4:	72003c3f 	tst	w1, #0xffff
    9fb8:	54ffe900 	b.eq	9cd8 <fwp_main_thread+0x1b68>  // b.none
    9fbc:	aa1703e0 	mov	x0, x23
    9fc0:	17fffc56 	b	9118 <fwp_main_thread+0xfa8>
    9fc4:	aa1b03e0 	mov	x0, x27
    9fc8:	f90003e5 	str	x5, [sp]
    9fcc:	97ffea29 	bl	4870 <fwp_rc_forget_slot>
    9fd0:	f94003e5 	ldr	x5, [sp]
    9fd4:	17ffff44 	b	9ce4 <fwp_main_thread+0x1b74>
    9fd8:	aa0203e0 	mov	x0, x2
    9fdc:	d2800101 	mov	x1, #0x8                   	// #8
    9fe0:	f90023e2 	str	x2, [sp, #64]
    9fe4:	97ffe243 	bl	28f0 <calloc@plt>
    9fe8:	f94023e2 	ldr	x2, [sp, #64]
    9fec:	aa0003fb 	mov	x27, x0
    9ff0:	17fffbb4 	b	8ec0 <fwp_main_thread+0xd50>
    9ff4:	d2800d01 	mov	x1, #0x68                  	// #104
    9ff8:	d2800038 	mov	x24, #0x1                   	// #1
    9ffc:	17fffa9e 	b	8a74 <fwp_main_thread+0x904>
    a000:	f94000a0 	ldr	x0, [x5]
    a004:	b7ffe7e0 	tbnz	x0, #63, 9d00 <fwp_main_thread+0x1b90>
    a008:	f949db41 	ldr	x1, [x26, #5040]
    a00c:	f949ef43 	ldr	x3, [x26, #5080]
    a010:	cb0102c1 	sub	x1, x22, x1
    a014:	eb03403f 	cmp	x1, x3, lsl #16
    a018:	54ffe742 	b.cs	9d00 <fwp_main_thread+0x1b90>  // b.hs, b.nlast
    a01c:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    a020:	17fffd07 	b	943c <fwp_main_thread+0x12cc>
    a024:	aa1603e0 	mov	x0, x22
    a028:	97ffedee 	bl	57e0 <fwp_rc_free_arr>
    a02c:	f94027e0 	ldr	x0, [sp, #72]
    a030:	f9400800 	ldr	x0, [x0, #16]
    a034:	f90027e0 	str	x0, [sp, #72]
    a038:	b5ffcf80 	cbnz	x0, 9a28 <fwp_main_thread+0x18b8>
    a03c:	aa1503e0 	mov	x0, x21
    a040:	97ffeebc 	bl	5b30 <fwp_drop0>
    a044:	f9400fe0 	ldr	x0, [sp, #24]
    a048:	97ffeeba 	bl	5b30 <fwp_drop0>
    a04c:	9101c260 	add	x0, x19, #0x70
    a050:	fd40fbe8 	ldr	d8, [sp, #496]
    a054:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    a058:	52800021 	mov	w1, #0x1                   	// #1
    a05c:	a95e73fb 	ldp	x27, x28, [sp, #480]
    a060:	b9034801 	str	w1, [x0, #840]
    a064:	f901a81f 	str	xzr, [x0, #848]
    a068:	17fff885 	b	827c <fwp_main_thread+0x10c>
    a06c:	72003d1f 	tst	w8, #0xffff
    a070:	54fff0a1 	b.ne	9e84 <fwp_main_thread+0x1d14>  // b.any
    a074:	17ffff7d 	b	9e68 <fwp_main_thread+0x1cf8>
    a078:	72003c5f 	tst	w2, #0xffff
    a07c:	54ffebe1 	b.ne	9df8 <fwp_main_thread+0x1c88>  // b.any
    a080:	17ffff57 	b	9ddc <fwp_main_thread+0x1c6c>
    a084:	72003c1f 	tst	w0, #0xffff
    a088:	54fff861 	b.ne	9f94 <fwp_main_thread+0x1e24>  // b.any
    a08c:	17ffffba 	b	9f74 <fwp_main_thread+0x1e04>
    a090:	72003c5f 	tst	w2, #0xffff
    a094:	54ff3fa1 	b.ne	8888 <fwp_main_thread+0x718>  // b.any
    a098:	17fff9f3 	b	8864 <fwp_main_thread+0x6f4>
    a09c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a0a0:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a0a4:	91174021 	add	x1, x1, #0x5d0
    a0a8:	ca402400 	eor	x0, x0, x0, lsr #9
    a0ac:	8b200c20 	add	x0, x1, w0, uxtb #3
    a0b0:	f94a2401 	ldr	x1, [x0, #5192]
    a0b4:	b5000081 	cbnz	x1, a0c4 <fwp_main_thread+0x1f54>
    a0b8:	14000011 	b	a0fc <fwp_main_thread+0x1f8c>
    a0bc:	f9400821 	ldr	x1, [x1, #16]
    a0c0:	b40001e1 	cbz	x1, a0fc <fwp_main_thread+0x1f8c>
    a0c4:	f9400020 	ldr	x0, [x1]
    a0c8:	eb0002ff 	cmp	x23, x0
    a0cc:	54ffff81 	b.ne	a0bc <fwp_main_thread+0x1f4c>  // b.any
    a0d0:	f9400420 	ldr	x0, [x1, #8]
    a0d4:	d1000400 	sub	x0, x0, #0x1
    a0d8:	f9000420 	str	x0, [x1, #8]
    a0dc:	f103f81f 	cmp	x0, #0xfe
    a0e0:	54000f60 	b.eq	a2cc <fwp_main_thread+0x215c>  // b.none
    a0e4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a0e8:	91174000 	add	x0, x0, #0x5d0
    a0ec:	f949ec02 	ldr	x2, [x0, #5080]
    a0f0:	f949d801 	ldr	x1, [x0, #5040]
    a0f4:	d370bc42 	lsl	x2, x2, #16
    a0f8:	17fffdc4 	b	9808 <fwp_main_thread+0x1698>
    a0fc:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    a100:	913b8000 	add	x0, x0, #0xee0
    a104:	97ffe5df 	bl	3880 <fwp_trap>
    a108:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a10c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a110:	91174021 	add	x1, x1, #0x5d0
    a114:	ca402400 	eor	x0, x0, x0, lsr #9
    a118:	8b200c20 	add	x0, x1, w0, uxtb #3
    a11c:	f94a2400 	ldr	x0, [x0, #5192]
    a120:	b5000080 	cbnz	x0, a130 <fwp_main_thread+0x1fc0>
    a124:	17fffff6 	b	a0fc <fwp_main_thread+0x1f8c>
    a128:	f9400800 	ldr	x0, [x0, #16]
    a12c:	b4fffe80 	cbz	x0, a0fc <fwp_main_thread+0x1f8c>
    a130:	f9400001 	ldr	x1, [x0]
    a134:	eb17003f 	cmp	x1, x23
    a138:	54ffff81 	b.ne	a128 <fwp_main_thread+0x1fb8>  // b.any
    a13c:	f9400401 	ldr	x1, [x0, #8]
    a140:	d1000421 	sub	x1, x1, #0x1
    a144:	f9000401 	str	x1, [x0, #8]
    a148:	f103f83f 	cmp	x1, #0xfe
    a14c:	54ff6221 	b.ne	8d90 <fwp_main_thread+0xc20>  // b.any
    a150:	aa1703e0 	mov	x0, x23
    a154:	97ffe9c7 	bl	4870 <fwp_rc_forget_slot>
    a158:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a15c:	390002e0 	strb	w0, [x23]
    a160:	17fffb0c 	b	8d90 <fwp_main_thread+0xc20>
    a164:	72003c5f 	tst	w2, #0xffff
    a168:	54ffc021 	b.ne	996c <fwp_main_thread+0x17fc>  // b.any
    a16c:	17fffdfb 	b	9958 <fwp_main_thread+0x17e8>
    a170:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a174:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a178:	91174021 	add	x1, x1, #0x5d0
    a17c:	ca402400 	eor	x0, x0, x0, lsr #9
    a180:	8b200c20 	add	x0, x1, w0, uxtb #3
    a184:	f94a2401 	ldr	x1, [x0, #5192]
    a188:	b5000081 	cbnz	x1, a198 <fwp_main_thread+0x2028>
    a18c:	17ffffdc 	b	a0fc <fwp_main_thread+0x1f8c>
    a190:	f9400821 	ldr	x1, [x1, #16]
    a194:	b4fffb41 	cbz	x1, a0fc <fwp_main_thread+0x1f8c>
    a198:	f9400020 	ldr	x0, [x1]
    a19c:	eb16001f 	cmp	x0, x22
    a1a0:	54ffff81 	b.ne	a190 <fwp_main_thread+0x2020>  // b.any
    a1a4:	f9400420 	ldr	x0, [x1, #8]
    a1a8:	d1000400 	sub	x0, x0, #0x1
    a1ac:	f9000420 	str	x0, [x1, #8]
    a1b0:	f103f81f 	cmp	x0, #0xfe
    a1b4:	54ffb661 	b.ne	9880 <fwp_main_thread+0x1710>  // b.any
    a1b8:	aa1603e0 	mov	x0, x22
    a1bc:	97ffe9ad 	bl	4870 <fwp_rc_forget_slot>
    a1c0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a1c4:	390002c0 	strb	w0, [x22]
    a1c8:	17fffdae 	b	9880 <fwp_main_thread+0x1710>
    a1cc:	72003c5f 	tst	w2, #0xffff
    a1d0:	54ffc241 	b.ne	9a18 <fwp_main_thread+0x18a8>  // b.any
    a1d4:	17fffe09 	b	99f8 <fwp_main_thread+0x1888>
    a1d8:	aa1503fb 	mov	x27, x21
    a1dc:	d280001c 	mov	x28, #0x0                   	// #0
    a1e0:	d2800018 	mov	x24, #0x0                   	// #0
    a1e4:	17fffd62 	b	976c <fwp_main_thread+0x15fc>
    a1e8:	97ffe95b 	bl	4754 <fwp_rc_wide_dup>
    a1ec:	17fff9ce 	b	8924 <fwp_main_thread+0x7b4>
    a1f0:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a1f4:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a1f8:	91174021 	add	x1, x1, #0x5d0
    a1fc:	ca402400 	eor	x0, x0, x0, lsr #9
    a200:	8b200c20 	add	x0, x1, w0, uxtb #3
    a204:	f94a2400 	ldr	x0, [x0, #5192]
    a208:	b5000080 	cbnz	x0, a218 <fwp_main_thread+0x20a8>
    a20c:	17ffffbc 	b	a0fc <fwp_main_thread+0x1f8c>
    a210:	f9400800 	ldr	x0, [x0, #16]
    a214:	b4fff740 	cbz	x0, a0fc <fwp_main_thread+0x1f8c>
    a218:	f9400001 	ldr	x1, [x0]
    a21c:	eb16003f 	cmp	x1, x22
    a220:	54ffff81 	b.ne	a210 <fwp_main_thread+0x20a0>  // b.any
    a224:	f9400401 	ldr	x1, [x0, #8]
    a228:	d1000421 	sub	x1, x1, #0x1
    a22c:	f9000401 	str	x1, [x0, #8]
    a230:	f103f83f 	cmp	x1, #0xfe
    a234:	54ff3ba1 	b.ne	89a8 <fwp_main_thread+0x838>  // b.any
    a238:	aa1603e0 	mov	x0, x22
    a23c:	97ffe98d 	bl	4870 <fwp_rc_forget_slot>
    a240:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a244:	390002c0 	strb	w0, [x22]
    a248:	17fff9d8 	b	89a8 <fwp_main_thread+0x838>
    a24c:	72003c3f 	tst	w1, #0xffff
    a250:	54ff2221 	b.ne	8694 <fwp_main_thread+0x524>  // b.any
    a254:	17fff90b 	b	8680 <fwp_main_thread+0x510>
    a258:	72003c3f 	tst	w1, #0xffff
    a25c:	54ff2b21 	b.ne	87c0 <fwp_main_thread+0x650>  // b.any
    a260:	17fff953 	b	87ac <fwp_main_thread+0x63c>
    a264:	72003c3f 	tst	w1, #0xffff
    a268:	54ff2601 	b.ne	8728 <fwp_main_thread+0x5b8>  // b.any
    a26c:	17fff92a 	b	8714 <fwp_main_thread+0x5a4>
    a270:	aa0003e1 	mov	x1, x0
    a274:	f90022b4 	str	x20, [x21, #64]
    a278:	17fff81a 	b	82e0 <fwp_main_thread+0x170>
    a27c:	d2800017 	mov	x23, #0x0                   	// #0
    a280:	17fffcca 	b	95a8 <fwp_main_thread+0x1438>
    a284:	aa1703e0 	mov	x0, x23
    a288:	97ffe97a 	bl	4870 <fwp_rc_forget_slot>
    a28c:	17fffdb6 	b	9964 <fwp_main_thread+0x17f4>
    a290:	f94192a0 	ldr	x0, [x21, #800]
    a294:	97ffea17 	bl	4af0 <fwp_mem_free>
    a298:	f90192bf 	str	xzr, [x21, #800]
    a29c:	f9019abf 	str	xzr, [x21, #816]
    a2a0:	f941b2a0 	ldr	x0, [x21, #864]
    a2a4:	b40007d4 	cbz	x20, a39c <fwp_main_thread+0x222c>
    a2a8:	f900569f 	str	xzr, [x20, #168]
    a2ac:	f9005e9f 	str	xzr, [x20, #184]
    a2b0:	b9035abf 	str	wzr, [x21, #856]
    a2b4:	eb14001f 	cmp	x0, x20
    a2b8:	54ff0740 	b.eq	83a0 <fwp_main_thread+0x230>  // b.none
    a2bc:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2c0:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2c4:	fd00fbe8 	str	d8, [sp, #496]
    a2c8:	97ffe1a6 	bl	2960 <abort@plt>
    a2cc:	aa1703e0 	mov	x0, x23
    a2d0:	97ffe968 	bl	4870 <fwp_rc_forget_slot>
    a2d4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a2d8:	91174000 	add	x0, x0, #0x5d0
    a2dc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a2e0:	390002e1 	strb	w1, [x23]
    a2e4:	f949ec02 	ldr	x2, [x0, #5080]
    a2e8:	f949d801 	ldr	x1, [x0, #5040]
    a2ec:	d370bc42 	lsl	x2, x2, #16
    a2f0:	17fffd46 	b	9808 <fwp_main_thread+0x1698>
    a2f4:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    a2f8:	913f0000 	add	x0, x0, #0xfc0
    a2fc:	97ffe561 	bl	3880 <fwp_trap>
    a300:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    a304:	913ca000 	add	x0, x0, #0xf28
    a308:	97ffe55e 	bl	3880 <fwp_trap>
    a30c:	97ffe912 	bl	4754 <fwp_rc_wide_dup>
    a310:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a314:	91174000 	add	x0, x0, #0x5d0
    a318:	f949ec06 	ldr	x6, [x0, #5080]
    a31c:	f949d803 	ldr	x3, [x0, #5040]
    a320:	d370bcc6 	lsl	x6, x6, #16
    a324:	17fff959 	b	8888 <fwp_main_thread+0x718>
    a328:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a32c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a330:	91174021 	add	x1, x1, #0x5d0
    a334:	ca402400 	eor	x0, x0, x0, lsr #9
    a338:	8b200c20 	add	x0, x1, w0, uxtb #3
    a33c:	f94a2400 	ldr	x0, [x0, #5192]
    a340:	b5000080 	cbnz	x0, a350 <fwp_main_thread+0x21e0>
    a344:	17ffff6e 	b	a0fc <fwp_main_thread+0x1f8c>
    a348:	f9400800 	ldr	x0, [x0, #16]
    a34c:	b4ffed80 	cbz	x0, a0fc <fwp_main_thread+0x1f8c>
    a350:	f9400001 	ldr	x1, [x0]
    a354:	eb0102ff 	cmp	x23, x1
    a358:	54ffff81 	b.ne	a348 <fwp_main_thread+0x21d8>  // b.any
    a35c:	f9400401 	ldr	x1, [x0, #8]
    a360:	d1000421 	sub	x1, x1, #0x1
    a364:	f9000401 	str	x1, [x0, #8]
    a368:	f103f83f 	cmp	x1, #0xfe
    a36c:	54ffb561 	b.ne	9a18 <fwp_main_thread+0x18a8>  // b.any
    a370:	aa1703e0 	mov	x0, x23
    a374:	97ffe93f 	bl	4870 <fwp_rc_forget_slot>
    a378:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a37c:	390002e0 	strb	w0, [x23]
    a380:	17fffda6 	b	9a18 <fwp_main_thread+0x18a8>
    a384:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a388:	9106a000 	add	x0, x0, #0x1a8
    a38c:	97ffe53d 	bl	3880 <fwp_trap>
    a390:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a394:	91008000 	add	x0, x0, #0x20
    a398:	97ffe53a 	bl	3880 <fwp_trap>
    a39c:	b9035abf 	str	wzr, [x21, #856]
    a3a0:	b4ff6ea0 	cbz	x0, 9174 <fwp_main_thread+0x1004>
    a3a4:	17ffffc6 	b	a2bc <fwp_main_thread+0x214c>
    a3a8:	aa1503e0 	mov	x0, x21
    a3ac:	97ffe931 	bl	4870 <fwp_rc_forget_slot>
    a3b0:	17fff8b7 	b	868c <fwp_main_thread+0x51c>
    a3b4:	aa1503e0 	mov	x0, x21
    a3b8:	97ffe92e 	bl	4870 <fwp_rc_forget_slot>
    a3bc:	17fff8d9 	b	8720 <fwp_main_thread+0x5b0>
    a3c0:	aa1703e0 	mov	x0, x23
    a3c4:	97ffe92b 	bl	4870 <fwp_rc_forget_slot>
    a3c8:	17fff8fc 	b	87b8 <fwp_main_thread+0x648>
    a3cc:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a3d0:	9107a000 	add	x0, x0, #0x1e8
    a3d4:	97ffe52b 	bl	3880 <fwp_trap>
    a3d8:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a3dc:	91074000 	add	x0, x0, #0x1d0
    a3e0:	97ffe528 	bl	3880 <fwp_trap>
    a3e4:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a3e8:	91048000 	add	x0, x0, #0x120
    a3ec:	a91c63f7 	stp	x23, x24, [sp, #448]
    a3f0:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a3f4:	a91e73fb 	stp	x27, x28, [sp, #480]
    a3f8:	fd00fbe8 	str	d8, [sp, #496]
    a3fc:	97ffe521 	bl	3880 <fwp_trap>
    a400:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a404:	a91e73fb 	stp	x27, x28, [sp, #480]
    a408:	fd00fbe8 	str	d8, [sp, #496]
    a40c:	97ffe369 	bl	31b0 <descent_phase_fail>
    a410:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a414:	a91e73fb 	stp	x27, x28, [sp, #480]
    a418:	fd00fbe8 	str	d8, [sp, #496]
    a41c:	97ffe13d 	bl	2910 <__stack_chk_fail@plt>
    a420:	52800020 	mov	w0, #0x1                   	// #1
    a424:	17fffbc0 	b	9324 <fwp_main_thread+0x11b4>
    a428:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a42c:	91066000 	add	x0, x0, #0x198
    a430:	97ffe514 	bl	3880 <fwp_trap>
    a434:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1e90>
    a438:	913dc000 	add	x0, x0, #0xf70
    a43c:	97ffe511 	bl	3880 <fwp_trap>
    a440:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a444:	91052000 	add	x0, x0, #0x148
    a448:	97ffe50e 	bl	3880 <fwp_trap>
    a44c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x480>
    a450:	9105a000 	add	x0, x0, #0x168
    a454:	97ffe50b 	bl	3880 <fwp_trap>
    a458:	97ffe1aa 	bl	2b00 <fwp_trap_overflow.constprop.0>
    a45c:	d503201f 	nop

000000000000a460 <__divti3>:
    a460:	d503245f 	bti	c
    a464:	d2800004 	mov	x4, #0x0                   	// #0
    a468:	b7f80721 	tbnz	x1, #63, a54c <__divti3+0xec>
    a46c:	b6f80083 	tbz	x3, #63, a47c <__divti3+0x1c>
    a470:	eb0203e2 	negs	x2, x2
    a474:	aa2403e4 	mvn	x4, x4
    a478:	da0303e3 	ngc	x3, x3
    a47c:	aa0203e6 	mov	x6, x2
    a480:	aa0003e7 	mov	x7, x0
    a484:	aa0103e5 	mov	x5, x1
    a488:	b5000583 	cbnz	x3, a538 <__divti3+0xd8>
    a48c:	eb01005f 	cmp	x2, x1
    a490:	54000e69 	b.ls	a65c <__divti3+0x1fc>  // b.plast
    a494:	dac01040 	clz	x0, x2
    a498:	b40000e0 	cbz	x0, a4b4 <__divti3+0x54>
    a49c:	4b0003e1 	neg	w1, w0
    a4a0:	9ac020a5 	lsl	x5, x5, x0
    a4a4:	9ac02046 	lsl	x6, x2, x0
    a4a8:	9ac124e1 	lsr	x1, x7, x1
    a4ac:	aa050025 	orr	x5, x1, x5
    a4b0:	9ac020e7 	lsl	x7, x7, x0
    a4b4:	d360fcc8 	lsr	x8, x6, #32
    a4b8:	92407cc2 	and	x2, x6, #0xffffffff
    a4bc:	9ac808a3 	udiv	x3, x5, x8
    a4c0:	9b089465 	msub	x5, x3, x8, x5
    a4c4:	aa0303e0 	mov	x0, x3
    a4c8:	9b037c41 	mul	x1, x2, x3
    a4cc:	93c780a5 	extr	x5, x5, x7, #32
    a4d0:	eb05003f 	cmp	x1, x5
    a4d4:	540000a9 	b.ls	a4e8 <__divti3+0x88>  // b.plast
    a4d8:	ab0500c5 	adds	x5, x6, x5
    a4dc:	d1000460 	sub	x0, x3, #0x1
    a4e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a4e4:	540015a8 	b.hi	a798 <__divti3+0x338>  // b.pmore
    a4e8:	cb0100a5 	sub	x5, x5, x1
    a4ec:	9ac808a3 	udiv	x3, x5, x8
    a4f0:	9b089465 	msub	x5, x3, x8, x5
    a4f4:	aa0303e1 	mov	x1, x3
    a4f8:	9b037c42 	mul	x2, x2, x3
    a4fc:	aa0703e3 	mov	x3, x7
    a500:	b3607ca3 	bfi	x3, x5, #32, #32
    a504:	eb03005f 	cmp	x2, x3
    a508:	540000c9 	b.ls	a520 <__divti3+0xc0>  // b.plast
    a50c:	ab0300c3 	adds	x3, x6, x3
    a510:	d1000425 	sub	x5, x1, #0x1
    a514:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a518:	d1000821 	sub	x1, x1, #0x2
    a51c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a520:	aa008020 	orr	x0, x1, x0, lsl #32
    a524:	d2800001 	mov	x1, #0x0                   	// #0
    a528:	b4000064 	cbz	x4, a534 <__divti3+0xd4>
    a52c:	eb0003e0 	negs	x0, x0
    a530:	da0103e1 	ngc	x1, x1
    a534:	d65f03c0 	ret
    a538:	eb01007f 	cmp	x3, x1
    a53c:	54000109 	b.ls	a55c <__divti3+0xfc>  // b.plast
    a540:	d2800001 	mov	x1, #0x0                   	// #0
    a544:	d2800000 	mov	x0, #0x0                   	// #0
    a548:	17fffff8 	b	a528 <__divti3+0xc8>
    a54c:	eb0003e0 	negs	x0, x0
    a550:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a554:	da0103e1 	ngc	x1, x1
    a558:	17ffffc5 	b	a46c <__divti3+0xc>
    a55c:	dac01067 	clz	x7, x3
    a560:	b40010e7 	cbz	x7, a77c <__divti3+0x31c>
    a564:	d2800805 	mov	x5, #0x40                  	// #64
    a568:	cb0700a5 	sub	x5, x5, x7
    a56c:	9ac72063 	lsl	x3, x3, x7
    a570:	9ac52448 	lsr	x8, x2, x5
    a574:	aa030108 	orr	x8, x8, x3
    a578:	9ac52426 	lsr	x6, x1, x5
    a57c:	92407d0a 	and	x10, x8, #0xffffffff
    a580:	d360fd09 	lsr	x9, x8, #32
    a584:	9ac52403 	lsr	x3, x0, x5
    a588:	9ac72021 	lsl	x1, x1, x7
    a58c:	aa010063 	orr	x3, x3, x1
    a590:	9ac72042 	lsl	x2, x2, x7
    a594:	9ac908cb 	udiv	x11, x6, x9
    a598:	9b099965 	msub	x5, x11, x9, x6
    a59c:	aa0b03e1 	mov	x1, x11
    a5a0:	9b0b7d46 	mul	x6, x10, x11
    a5a4:	93c380a5 	extr	x5, x5, x3, #32
    a5a8:	eb0500df 	cmp	x6, x5
    a5ac:	540000a9 	b.ls	a5c0 <__divti3+0x160>  // b.plast
    a5b0:	ab050105 	adds	x5, x8, x5
    a5b4:	d1000561 	sub	x1, x11, #0x1
    a5b8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a5bc:	54000f48 	b.hi	a7a4 <__divti3+0x344>  // b.pmore
    a5c0:	cb0600a6 	sub	x6, x5, x6
    a5c4:	9ac908cb 	udiv	x11, x6, x9
    a5c8:	9b099969 	msub	x9, x11, x9, x6
    a5cc:	aa0b03e5 	mov	x5, x11
    a5d0:	9b0b7d4a 	mul	x10, x10, x11
    a5d4:	b3607d23 	bfi	x3, x9, #32, #32
    a5d8:	eb03015f 	cmp	x10, x3
    a5dc:	540000a9 	b.ls	a5f0 <__divti3+0x190>  // b.plast
    a5e0:	ab030103 	adds	x3, x8, x3
    a5e4:	d1000565 	sub	x5, x11, #0x1
    a5e8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a5ec:	54000e28 	b.hi	a7b0 <__divti3+0x350>  // b.pmore
    a5f0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a5f4:	92407c48 	and	x8, x2, #0xffffffff
    a5f8:	2a0503e5 	mov	w5, w5
    a5fc:	d360fc42 	lsr	x2, x2, #32
    a600:	d360fc26 	lsr	x6, x1, #32
    a604:	cb0a0063 	sub	x3, x3, x10
    a608:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a60c:	9b087caa 	mul	x10, x5, x8
    a610:	9b087cc8 	mul	x8, x6, x8
    a614:	9b0220a5 	madd	x5, x5, x2, x8
    a618:	9b027cc6 	mul	x6, x6, x2
    a61c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a620:	8b0900c5 	add	x5, x6, x9
    a624:	eb02011f 	cmp	x8, x2
    a628:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a62c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a630:	eb06007f 	cmp	x3, x6
    a634:	540000e3 	b.cc	a650 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a638:	92407d4a 	and	x10, x10, #0xffffffff
    a63c:	9ac72000 	lsl	x0, x0, x7
    a640:	8b028142 	add	x2, x10, x2, lsl #32
    a644:	eb02001f 	cmp	x0, x2
    a648:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a64c:	54000a01 	b.ne	a78c <__divti3+0x32c>  // b.any
    a650:	d1000420 	sub	x0, x1, #0x1
    a654:	d2800001 	mov	x1, #0x0                   	// #0
    a658:	17ffffb4 	b	a528 <__divti3+0xc8>
    a65c:	b5000062 	cbnz	x2, a668 <__divti3+0x208>
    a660:	d2800022 	mov	x2, #0x1                   	// #1
    a664:	9ac30846 	udiv	x6, x2, x3
    a668:	dac010c8 	clz	x8, x6
    a66c:	b5000408 	cbnz	x8, a6ec <__divti3+0x28c>
    a670:	d360fcc9 	lsr	x9, x6, #32
    a674:	92407cc5 	and	x5, x6, #0xffffffff
    a678:	cb060023 	sub	x3, x1, x6
    a67c:	d2800021 	mov	x1, #0x1                   	// #1
    a680:	9ac90868 	udiv	x8, x3, x9
    a684:	9b098d03 	msub	x3, x8, x9, x3
    a688:	aa0803e0 	mov	x0, x8
    a68c:	9b057d02 	mul	x2, x8, x5
    a690:	93c78063 	extr	x3, x3, x7, #32
    a694:	eb03005f 	cmp	x2, x3
    a698:	540000a9 	b.ls	a6ac <__divti3+0x24c>  // b.plast
    a69c:	ab0300c3 	adds	x3, x6, x3
    a6a0:	d1000500 	sub	x0, x8, #0x1
    a6a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a6a8:	54000968 	b.hi	a7d4 <__divti3+0x374>  // b.pmore
    a6ac:	cb020063 	sub	x3, x3, x2
    a6b0:	9ac90862 	udiv	x2, x3, x9
    a6b4:	aa0203e8 	mov	x8, x2
    a6b8:	9b098c42 	msub	x2, x2, x9, x3
    a6bc:	aa0703e3 	mov	x3, x7
    a6c0:	9b057d05 	mul	x5, x8, x5
    a6c4:	b3607c43 	bfi	x3, x2, #32, #32
    a6c8:	eb0300bf 	cmp	x5, x3
    a6cc:	540000c9 	b.ls	a6e4 <__divti3+0x284>  // b.plast
    a6d0:	ab0300c2 	adds	x2, x6, x3
    a6d4:	d1000503 	sub	x3, x8, #0x1
    a6d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a6dc:	d1000908 	sub	x8, x8, #0x2
    a6e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a6e4:	aa008100 	orr	x0, x8, x0, lsl #32
    a6e8:	17ffff90 	b	a528 <__divti3+0xc8>
    a6ec:	9ac820c6 	lsl	x6, x6, x8
    a6f0:	d2800803 	mov	x3, #0x40                  	// #64
    a6f4:	cb080063 	sub	x3, x3, x8
    a6f8:	d360fcc9 	lsr	x9, x6, #32
    a6fc:	9ac82027 	lsl	x7, x1, x8
    a700:	92407cc5 	and	x5, x6, #0xffffffff
    a704:	9ac32422 	lsr	x2, x1, x3
    a708:	9ac32403 	lsr	x3, x0, x3
    a70c:	aa070063 	orr	x3, x3, x7
    a710:	9ac9084a 	udiv	x10, x2, x9
    a714:	9ac82007 	lsl	x7, x0, x8
    a718:	9b098940 	msub	x0, x10, x9, x2
    a71c:	aa0a03e1 	mov	x1, x10
    a720:	9b0a7ca2 	mul	x2, x5, x10
    a724:	93c38000 	extr	x0, x0, x3, #32
    a728:	eb00005f 	cmp	x2, x0
    a72c:	540000a9 	b.ls	a740 <__divti3+0x2e0>  // b.plast
    a730:	ab0000c0 	adds	x0, x6, x0
    a734:	d1000541 	sub	x1, x10, #0x1
    a738:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a73c:	54000468 	b.hi	a7c8 <__divti3+0x368>  // b.pmore
    a740:	cb020000 	sub	x0, x0, x2
    a744:	9ac9080a 	udiv	x10, x0, x9
    a748:	9b098140 	msub	x0, x10, x9, x0
    a74c:	aa0a03e2 	mov	x2, x10
    a750:	9b0a7ca8 	mul	x8, x5, x10
    a754:	b3607c03 	bfi	x3, x0, #32, #32
    a758:	eb03011f 	cmp	x8, x3
    a75c:	540000a9 	b.ls	a770 <__divti3+0x310>  // b.plast
    a760:	ab0300c3 	adds	x3, x6, x3
    a764:	d1000542 	sub	x2, x10, #0x1
    a768:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a76c:	54000288 	b.hi	a7bc <__divti3+0x35c>  // b.pmore
    a770:	cb080063 	sub	x3, x3, x8
    a774:	aa018041 	orr	x1, x2, x1, lsl #32
    a778:	17ffffc2 	b	a680 <__divti3+0x220>
    a77c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a780:	d2800001 	mov	x1, #0x0                   	// #0
    a784:	9a9f87e0 	cset	x0, ls	// ls = plast
    a788:	17ffff68 	b	a528 <__divti3+0xc8>
    a78c:	aa0103e0 	mov	x0, x1
    a790:	d2800001 	mov	x1, #0x0                   	// #0
    a794:	17ffff65 	b	a528 <__divti3+0xc8>
    a798:	d1000860 	sub	x0, x3, #0x2
    a79c:	8b0600a5 	add	x5, x5, x6
    a7a0:	17ffff52 	b	a4e8 <__divti3+0x88>
    a7a4:	d1000961 	sub	x1, x11, #0x2
    a7a8:	8b0800a5 	add	x5, x5, x8
    a7ac:	17ffff85 	b	a5c0 <__divti3+0x160>
    a7b0:	d1000965 	sub	x5, x11, #0x2
    a7b4:	8b080063 	add	x3, x3, x8
    a7b8:	17ffff8e 	b	a5f0 <__divti3+0x190>
    a7bc:	d1000942 	sub	x2, x10, #0x2
    a7c0:	8b060063 	add	x3, x3, x6
    a7c4:	17ffffeb 	b	a770 <__divti3+0x310>
    a7c8:	d1000941 	sub	x1, x10, #0x2
    a7cc:	8b060000 	add	x0, x0, x6
    a7d0:	17ffffdc 	b	a740 <__divti3+0x2e0>
    a7d4:	d1000900 	sub	x0, x8, #0x2
    a7d8:	8b060063 	add	x3, x3, x6
    a7dc:	17ffffb4 	b	a6ac <__divti3+0x24c>

000000000000a7e0 <__modti3>:
    a7e0:	d503245f 	bti	c
    a7e4:	d2800004 	mov	x4, #0x0                   	// #0
    a7e8:	b6f80081 	tbz	x1, #63, a7f8 <__modti3+0x18>
    a7ec:	eb0003e0 	negs	x0, x0
    a7f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a7f4:	da0103e1 	ngc	x1, x1
    a7f8:	f100007f 	cmp	x3, #0x0
    a7fc:	5400128b 	b.lt	aa4c <__modti3+0x26c>  // b.tstop
    a800:	aa0003e7 	mov	x7, x0
    a804:	aa0103e6 	mov	x6, x1
    a808:	540004e1 	b.ne	a8a4 <__modti3+0xc4>  // b.any
    a80c:	eb02003f 	cmp	x1, x2
    a810:	54000dc2 	b.cs	a9c8 <__modti3+0x1e8>  // b.hs, b.nlast
    a814:	dac01043 	clz	x3, x2
    a818:	aa0303e5 	mov	x5, x3
    a81c:	b40000e3 	cbz	x3, a838 <__modti3+0x58>
    a820:	4b0303e6 	neg	w6, w3
    a824:	9ac32021 	lsl	x1, x1, x3
    a828:	9ac32042 	lsl	x2, x2, x3
    a82c:	9ac62406 	lsr	x6, x0, x6
    a830:	aa0100c6 	orr	x6, x6, x1
    a834:	9ac32007 	lsl	x7, x0, x3
    a838:	d360fc40 	lsr	x0, x2, #32
    a83c:	92407c43 	and	x3, x2, #0xffffffff
    a840:	9ac008c1 	udiv	x1, x6, x0
    a844:	9b009826 	msub	x6, x1, x0, x6
    a848:	9b017c61 	mul	x1, x3, x1
    a84c:	93c780c6 	extr	x6, x6, x7, #32
    a850:	eb06003f 	cmp	x1, x6
    a854:	540000a9 	b.ls	a868 <__modti3+0x88>  // b.plast
    a858:	ab060046 	adds	x6, x2, x6
    a85c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a860:	8b0200c8 	add	x8, x6, x2
    a864:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a868:	cb0100c6 	sub	x6, x6, x1
    a86c:	9ac008c8 	udiv	x8, x6, x0
    a870:	9b009901 	msub	x1, x8, x0, x6
    a874:	aa0703e0 	mov	x0, x7
    a878:	9b087c63 	mul	x3, x3, x8
    a87c:	b3607c20 	bfi	x0, x1, #32, #32
    a880:	eb00007f 	cmp	x3, x0
    a884:	54001088 	b.hi	aa94 <__modti3+0x2b4>  // b.pmore
    a888:	cb030000 	sub	x0, x0, x3
    a88c:	9ac52400 	lsr	x0, x0, x5
    a890:	d2800001 	mov	x1, #0x0                   	// #0
    a894:	b4000064 	cbz	x4, a8a0 <__modti3+0xc0>
    a898:	eb0003e0 	negs	x0, x0
    a89c:	da0103e1 	ngc	x1, x1
    a8a0:	d65f03c0 	ret
    a8a4:	dac01066 	clz	x6, x3
    a8a8:	eb03003f 	cmp	x1, x3
    a8ac:	54ffff43 	b.cc	a894 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a8b0:	93407cc5 	sxtw	x5, w6
    a8b4:	d2800808 	mov	x8, #0x40                  	// #64
    a8b8:	cb050108 	sub	x8, x8, x5
    a8bc:	9ac62063 	lsl	x3, x3, x6
    a8c0:	9ac62025 	lsl	x5, x1, x6
    a8c4:	9ac82447 	lsr	x7, x2, x8
    a8c8:	aa0300e7 	orr	x7, x7, x3
    a8cc:	9ac82423 	lsr	x3, x1, x8
    a8d0:	92407cec 	and	x12, x7, #0xffffffff
    a8d4:	d360fcea 	lsr	x10, x7, #32
    a8d8:	9ac82401 	lsr	x1, x0, x8
    a8dc:	aa050021 	orr	x1, x1, x5
    a8e0:	9ac62042 	lsl	x2, x2, x6
    a8e4:	9ac62000 	lsl	x0, x0, x6
    a8e8:	9aca086b 	udiv	x11, x3, x10
    a8ec:	9b0a8d63 	msub	x3, x11, x10, x3
    a8f0:	aa0b03e5 	mov	x5, x11
    a8f4:	9b0b7d89 	mul	x9, x12, x11
    a8f8:	93c18063 	extr	x3, x3, x1, #32
    a8fc:	eb03013f 	cmp	x9, x3
    a900:	540000a9 	b.ls	a914 <__modti3+0x134>  // b.plast
    a904:	ab0300e3 	adds	x3, x7, x3
    a908:	d1000565 	sub	x5, x11, #0x1
    a90c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a910:	54001168 	b.hi	ab3c <__modti3+0x35c>  // b.pmore
    a914:	cb090063 	sub	x3, x3, x9
    a918:	9aca086b 	udiv	x11, x3, x10
    a91c:	9b0a8d6a 	msub	x10, x11, x10, x3
    a920:	aa0b03e9 	mov	x9, x11
    a924:	9b0b7d8c 	mul	x12, x12, x11
    a928:	b3607d41 	bfi	x1, x10, #32, #32
    a92c:	eb01019f 	cmp	x12, x1
    a930:	540000a9 	b.ls	a944 <__modti3+0x164>  // b.plast
    a934:	ab0100e1 	adds	x1, x7, x1
    a938:	d1000569 	sub	x9, x11, #0x1
    a93c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a940:	54000f88 	b.hi	ab30 <__modti3+0x350>  // b.pmore
    a944:	aa058123 	orr	x3, x9, x5, lsl #32
    a948:	92407c4b 	and	x11, x2, #0xffffffff
    a94c:	2a0903e9 	mov	w9, w9
    a950:	d360fc4a 	lsr	x10, x2, #32
    a954:	d360fc63 	lsr	x3, x3, #32
    a958:	cb0c0021 	sub	x1, x1, x12
    a95c:	aa0a03ec 	mov	x12, x10
    a960:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a964:	9b0b7d25 	mul	x5, x9, x11
    a968:	9b0b7c6b 	mul	x11, x3, x11
    a96c:	9b0a2d29 	madd	x9, x9, x10, x11
    a970:	92407caa 	and	x10, x5, #0xffffffff
    a974:	9b0c7c63 	mul	x3, x3, x12
    a978:	8b458125 	add	x5, x9, x5, lsr #32
    a97c:	8b0d0069 	add	x9, x3, x13
    a980:	eb05017f 	cmp	x11, x5
    a984:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a988:	8b058149 	add	x9, x10, x5, lsl #32
    a98c:	8b458063 	add	x3, x3, x5, lsr #32
    a990:	eb03003f 	cmp	x1, x3
    a994:	54000063 	b.cc	a9a0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a998:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a99c:	54000082 	b.cs	a9ac <__modti3+0x1cc>  // b.hs, b.nlast
    a9a0:	eb020129 	subs	x9, x9, x2
    a9a4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a9a8:	cb070063 	sub	x3, x3, x7
    a9ac:	eb090000 	subs	x0, x0, x9
    a9b0:	da030021 	sbc	x1, x1, x3
    a9b4:	9ac62400 	lsr	x0, x0, x6
    a9b8:	9ac82028 	lsl	x8, x1, x8
    a9bc:	aa000100 	orr	x0, x8, x0
    a9c0:	9ac62421 	lsr	x1, x1, x6
    a9c4:	17ffffb4 	b	a894 <__modti3+0xb4>
    a9c8:	b5000062 	cbnz	x2, a9d4 <__modti3+0x1f4>
    a9cc:	d2800023 	mov	x3, #0x1                   	// #1
    a9d0:	9ac20862 	udiv	x2, x3, x2
    a9d4:	dac01048 	clz	x8, x2
    a9d8:	aa0803e5 	mov	x5, x8
    a9dc:	b5000668 	cbnz	x8, aaa8 <__modti3+0x2c8>
    a9e0:	cb020020 	sub	x0, x1, x2
    a9e4:	d360fc49 	lsr	x9, x2, #32
    a9e8:	92407c4a 	and	x10, x2, #0xffffffff
    a9ec:	9ac90801 	udiv	x1, x0, x9
    a9f0:	9b098020 	msub	x0, x1, x9, x0
    a9f4:	9b0a7c21 	mul	x1, x1, x10
    a9f8:	93c78000 	extr	x0, x0, x7, #32
    a9fc:	eb00003f 	cmp	x1, x0
    aa00:	540000a9 	b.ls	aa14 <__modti3+0x234>  // b.plast
    aa04:	ab000040 	adds	x0, x2, x0
    aa08:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aa0c:	8b020003 	add	x3, x0, x2
    aa10:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    aa14:	cb010001 	sub	x1, x0, x1
    aa18:	9ac90820 	udiv	x0, x1, x9
    aa1c:	9b098403 	msub	x3, x0, x9, x1
    aa20:	aa0703e1 	mov	x1, x7
    aa24:	9b0a7c00 	mul	x0, x0, x10
    aa28:	b3607c61 	bfi	x1, x3, #32, #32
    aa2c:	eb01001f 	cmp	x0, x1
    aa30:	540000a9 	b.ls	aa44 <__modti3+0x264>  // b.plast
    aa34:	ab010041 	adds	x1, x2, x1
    aa38:	8b020022 	add	x2, x1, x2
    aa3c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    aa40:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    aa44:	cb000020 	sub	x0, x1, x0
    aa48:	17ffff91 	b	a88c <__modti3+0xac>
    aa4c:	eb0203e5 	negs	x5, x2
    aa50:	aa0003e7 	mov	x7, x0
    aa54:	da0303e8 	ngc	x8, x3
    aa58:	aa0503e2 	mov	x2, x5
    aa5c:	aa0803e3 	mov	x3, x8
    aa60:	aa0103e6 	mov	x6, x1
    aa64:	b4ffed48 	cbz	x8, a80c <__modti3+0x2c>
    aa68:	eb01011f 	cmp	x8, x1
    aa6c:	54fff148 	b.hi	a894 <__modti3+0xb4>  // b.pmore
    aa70:	dac01109 	clz	x9, x8
    aa74:	2a0903e6 	mov	w6, w9
    aa78:	b5fff1c9 	cbnz	x9, a8b0 <__modti3+0xd0>
    aa7c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    aa80:	54000068 	b.hi	aa8c <__modti3+0x2ac>  // b.pmore
    aa84:	eb050007 	subs	x7, x0, x5
    aa88:	da080021 	sbc	x1, x1, x8
    aa8c:	aa0703e0 	mov	x0, x7
    aa90:	17ffff81 	b	a894 <__modti3+0xb4>
    aa94:	ab000040 	adds	x0, x2, x0
    aa98:	8b020002 	add	x2, x0, x2
    aa9c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    aaa0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    aaa4:	17ffff79 	b	a888 <__modti3+0xa8>
    aaa8:	9ac82042 	lsl	x2, x2, x8
    aaac:	d2800803 	mov	x3, #0x40                  	// #64
    aab0:	cb080063 	sub	x3, x3, x8
    aab4:	d360fc49 	lsr	x9, x2, #32
    aab8:	9ac82027 	lsl	x7, x1, x8
    aabc:	92407c4a 	and	x10, x2, #0xffffffff
    aac0:	9ac32426 	lsr	x6, x1, x3
    aac4:	9ac32403 	lsr	x3, x0, x3
    aac8:	aa070063 	orr	x3, x3, x7
    aacc:	9ac908c1 	udiv	x1, x6, x9
    aad0:	9ac82007 	lsl	x7, x0, x8
    aad4:	9b099820 	msub	x0, x1, x9, x6
    aad8:	9b017d41 	mul	x1, x10, x1
    aadc:	93c38000 	extr	x0, x0, x3, #32
    aae0:	eb00003f 	cmp	x1, x0
    aae4:	540000a9 	b.ls	aaf8 <__modti3+0x318>  // b.plast
    aae8:	ab000040 	adds	x0, x2, x0
    aaec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aaf0:	8b020006 	add	x6, x0, x2
    aaf4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    aaf8:	cb010000 	sub	x0, x0, x1
    aafc:	9ac90801 	udiv	x1, x0, x9
    ab00:	9b098026 	msub	x6, x1, x9, x0
    ab04:	aa0303e0 	mov	x0, x3
    ab08:	9b017d41 	mul	x1, x10, x1
    ab0c:	b3607cc0 	bfi	x0, x6, #32, #32
    ab10:	eb00003f 	cmp	x1, x0
    ab14:	540000a9 	b.ls	ab28 <__modti3+0x348>  // b.plast
    ab18:	ab000040 	adds	x0, x2, x0
    ab1c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ab20:	8b020003 	add	x3, x0, x2
    ab24:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ab28:	cb010000 	sub	x0, x0, x1
    ab2c:	17ffffb0 	b	a9ec <__modti3+0x20c>
    ab30:	d1000969 	sub	x9, x11, #0x2
    ab34:	8b070021 	add	x1, x1, x7
    ab38:	17ffff83 	b	a944 <__modti3+0x164>
    ab3c:	d1000965 	sub	x5, x11, #0x2
    ab40:	8b070063 	add	x3, x3, x7
    ab44:	17ffff74 	b	a914 <__modti3+0x134>
    ab48:	d503201f 	nop
    ab4c:	d503201f 	nop

000000000000ab50 <atexit>:
    ab50:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ab54:	d00000a2 	adrp	x2, 20000 <__data_start>
    ab58:	d2800001 	mov	x1, #0x0                   	// #0
    ab5c:	910003fd 	mov	x29, sp
    ab60:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ab64:	f9400442 	ldr	x2, [x2, #8]
    ab68:	17ffdf2a 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ab6c <_fini>:
    ab6c:	d503201f 	nop
    ab70:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ab74:	910003fd 	mov	x29, sp
    ab78:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ab7c:	d65f03c0 	ret
