
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/c-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000000710 <_init>:
 710:	d503201f 	nop
 714:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 718:	910003fd 	mov	x29, sp
 71c:	940000c6 	bl	a34 <call_weak_fn>
 720:	a8c17bfd 	ldp	x29, x30, [sp], #16
 724:	d65f03c0 	ret

Disassembly of section .plt:

0000000000000730 <.plt>:
 730:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 734:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 738:	f947ba11 	ldr	x17, [x16, #3952]
 73c:	913dc210 	add	x16, x16, #0xf70
 740:	d61f0220 	br	x17
 744:	d503201f 	nop
 748:	d503201f 	nop
 74c:	d503201f 	nop

0000000000000750 <__libc_start_main@plt>:
 750:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 754:	f947be11 	ldr	x17, [x16, #3960]
 758:	913de210 	add	x16, x16, #0xf78
 75c:	d61f0220 	br	x17

0000000000000760 <__cxa_finalize@plt>:
 760:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 764:	f947c211 	ldr	x17, [x16, #3968]
 768:	913e0210 	add	x16, x16, #0xf80
 76c:	d61f0220 	br	x17

0000000000000770 <putc@plt>:
 770:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 774:	f947c611 	ldr	x17, [x16, #3976]
 778:	913e2210 	add	x16, x16, #0xf88
 77c:	d61f0220 	br	x17

0000000000000780 <malloc@plt>:
 780:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 784:	f947ca11 	ldr	x17, [x16, #3984]
 788:	913e4210 	add	x16, x16, #0xf90
 78c:	d61f0220 	br	x17

0000000000000790 <__printf_chk@plt>:
 790:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 794:	f947ce11 	ldr	x17, [x16, #3992]
 798:	913e6210 	add	x16, x16, #0xf98
 79c:	d61f0220 	br	x17

00000000000007a0 <__gmon_start__@plt>:
 7a0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 7a4:	f947d211 	ldr	x17, [x16, #4000]
 7a8:	913e8210 	add	x16, x16, #0xfa0
 7ac:	d61f0220 	br	x17

00000000000007b0 <abort@plt>:
 7b0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 7b4:	f947d611 	ldr	x17, [x16, #4008]
 7b8:	913ea210 	add	x16, x16, #0xfa8
 7bc:	d61f0220 	br	x17

00000000000007c0 <puts@plt>:
 7c0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 7c4:	f947da11 	ldr	x17, [x16, #4016]
 7c8:	913ec210 	add	x16, x16, #0xfb0
 7cc:	d61f0220 	br	x17

00000000000007d0 <free@plt>:
 7d0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 7d4:	f947de11 	ldr	x17, [x16, #4024]
 7d8:	913ee210 	add	x16, x16, #0xfb8
 7dc:	d61f0220 	br	x17

00000000000007e0 <ferror@plt>:
 7e0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e340>
 7e4:	f947e211 	ldr	x17, [x16, #4032]
 7e8:	913f0210 	add	x16, x16, #0xfc0
 7ec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000800 <main>:
 800:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 804:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 808:	910003fd 	mov	x29, sp
 80c:	f9001bf7 	str	x23, [sp, #48]
 810:	f00000f7 	adrp	x23, 1f000 <__FRAME_END__+0x1e340>
 814:	f947f2f7 	ldr	x23, [x23, #4064]
 818:	6d0427e8 	stp	d8, d9, [sp, #64]
 81c:	fd45a808 	ldr	d8, [x0, #2896]
 820:	a90153f3 	stp	x19, x20, [sp, #16]
 824:	a9025bf5 	stp	x21, x22, [sp, #32]
 828:	d2804016 	mov	x22, #0x200                 	// #512
 82c:	6d052fea 	stp	d10, d11, [sp, #80]
 830:	d2800300 	mov	x0, #0x18                  	// #24
 834:	97ffffd3 	bl	780 <malloc@plt>
 838:	aa0003f3 	mov	x19, x0
 83c:	d2800300 	mov	x0, #0x18                  	// #24
 840:	97ffffd0 	bl	780 <malloc@plt>
 844:	f100027f 	cmp	x19, #0x0
 848:	aa0003f4 	mov	x20, x0
 84c:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
 850:	54000ae0 	b.eq	9ac <main+0x1ac>  // b.none
 854:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 858:	d2800001 	mov	x1, #0x0                   	// #0
 85c:	3dc2d800 	ldr	q0, [x0, #2912]
 860:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 864:	3d800280 	str	q0, [x20]
 868:	3dc2dc00 	ldr	q0, [x0, #2928]
 86c:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 870:	3d800260 	str	q0, [x19]
 874:	3dc2e000 	ldr	q0, [x0, #2944]
 878:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 87c:	3c808280 	stur	q0, [x20, #8]
 880:	fd45b800 	ldr	d0, [x0, #2928]
 884:	fd000a60 	str	d0, [x19, #16]
 888:	fc617a81 	ldr	d1, [x20, x1, lsl #3]
 88c:	fc617a60 	ldr	d0, [x19, x1, lsl #3]
 890:	1e680821 	fmul	d1, d1, d8
 894:	1e613800 	fsub	d0, d0, d1
 898:	fc217a60 	str	d0, [x19, x1, lsl #3]
 89c:	91000421 	add	x1, x1, #0x1
 8a0:	f1000c3f 	cmp	x1, #0x3
 8a4:	54ffff21 	b.ne	888 <main+0x88>  // b.any
 8a8:	fd400269 	ldr	d9, [x19]
 8ac:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
 8b0:	9e670001 	fmov	d1, x0
 8b4:	1e60c120 	fabs	d0, d9
 8b8:	1e612000 	fcmp	d0, d1
 8bc:	540006c8 	b.hi	994 <main+0x194>  // b.pmore
 8c0:	fd40066a 	ldr	d10, [x19, #8]
 8c4:	1e60c140 	fabs	d0, d10
 8c8:	1e612000 	fcmp	d0, d1
 8cc:	54000648 	b.hi	994 <main+0x194>  // b.pmore
 8d0:	fd400a6b 	ldr	d11, [x19, #16]
 8d4:	1e60c160 	fabs	d0, d11
 8d8:	1e612000 	fcmp	d0, d1
 8dc:	540005c8 	b.hi	994 <main+0x194>  // b.pmore
 8e0:	f94002e1 	ldr	x1, [x23]
 8e4:	52800b60 	mov	w0, #0x5b                  	// #91
 8e8:	90000015 	adrp	x21, 0 <__abi_tag-0x278>
 8ec:	912d02b5 	add	x21, x21, #0xb40
 8f0:	97ffffa0 	bl	770 <putc@plt>
 8f4:	1e604120 	fmov	d0, d9
 8f8:	90000001 	adrp	x1, 0 <__abi_tag-0x278>
 8fc:	52800040 	mov	w0, #0x2                   	// #2
 900:	912ce021 	add	x1, x1, #0xb38
 904:	97ffffa3 	bl	790 <__printf_chk@plt>
 908:	1e604140 	fmov	d0, d10
 90c:	aa1503e1 	mov	x1, x21
 910:	52800040 	mov	w0, #0x2                   	// #2
 914:	97ffff9f 	bl	790 <__printf_chk@plt>
 918:	1e604160 	fmov	d0, d11
 91c:	aa1503e1 	mov	x1, x21
 920:	52800040 	mov	w0, #0x2                   	// #2
 924:	97ffff9b 	bl	790 <__printf_chk@plt>
 928:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 92c:	912d2000 	add	x0, x0, #0xb48
 930:	97ffffa4 	bl	7c0 <puts@plt>
 934:	aa1303e0 	mov	x0, x19
 938:	97ffffa6 	bl	7d0 <free@plt>
 93c:	aa1403e0 	mov	x0, x20
 940:	97ffffa4 	bl	7d0 <free@plt>
 944:	f94002e0 	ldr	x0, [x23]
 948:	97ffffa6 	bl	7e0 <ferror@plt>
 94c:	35000140 	cbnz	w0, 974 <main+0x174>
 950:	f10006d6 	subs	x22, x22, #0x1
 954:	54fff6e1 	b.ne	830 <main+0x30>  // b.any
 958:	a94153f3 	ldp	x19, x20, [sp, #16]
 95c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 960:	f9401bf7 	ldr	x23, [sp, #48]
 964:	6d4427e8 	ldp	d8, d9, [sp, #64]
 968:	6d452fea 	ldp	d10, d11, [sp, #80]
 96c:	a8c67bfd 	ldp	x29, x30, [sp], #96
 970:	d65f03c0 	ret
 974:	a94153f3 	ldp	x19, x20, [sp, #16]
 978:	52800080 	mov	w0, #0x4                   	// #4
 97c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 980:	f9401bf7 	ldr	x23, [sp, #48]
 984:	6d4427e8 	ldp	d8, d9, [sp, #64]
 988:	6d452fea 	ldp	d10, d11, [sp, #80]
 98c:	a8c67bfd 	ldp	x29, x30, [sp], #96
 990:	d65f03c0 	ret
 994:	aa1303e0 	mov	x0, x19
 998:	97ffff8e 	bl	7d0 <free@plt>
 99c:	aa1403e0 	mov	x0, x20
 9a0:	97ffff8c 	bl	7d0 <free@plt>
 9a4:	52800060 	mov	w0, #0x3                   	// #3
 9a8:	17ffffec 	b	958 <main+0x158>
 9ac:	aa1303e0 	mov	x0, x19
 9b0:	97ffff88 	bl	7d0 <free@plt>
 9b4:	aa1403e0 	mov	x0, x20
 9b8:	97ffff86 	bl	7d0 <free@plt>
 9bc:	52800040 	mov	w0, #0x2                   	// #2
 9c0:	17ffffe6 	b	958 <main+0x158>
 9c4:	d503201f 	nop
 9c8:	d503201f 	nop
 9cc:	d503201f 	nop
 9d0:	d503201f 	nop
 9d4:	d503201f 	nop
 9d8:	d503201f 	nop
 9dc:	d503201f 	nop
 9e0:	d503201f 	nop
 9e4:	d503201f 	nop
 9e8:	d503201f 	nop
 9ec:	d503201f 	nop
 9f0:	d503201f 	nop
 9f4:	d503201f 	nop
 9f8:	d503201f 	nop
 9fc:	d503201f 	nop

0000000000000a00 <_start>:
 a00:	d503201f 	nop
 a04:	d280001d 	mov	x29, #0x0                   	// #0
 a08:	d280001e 	mov	x30, #0x0                   	// #0
 a0c:	aa0003e5 	mov	x5, x0
 a10:	f94003e1 	ldr	x1, [sp]
 a14:	910023e2 	add	x2, sp, #0x8
 a18:	910003e6 	mov	x6, sp
 a1c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e340>
 a20:	f947f800 	ldr	x0, [x0, #4080]
 a24:	d2800003 	mov	x3, #0x0                   	// #0
 a28:	d2800004 	mov	x4, #0x0                   	// #0
 a2c:	97ffff49 	bl	750 <__libc_start_main@plt>
 a30:	97ffff60 	bl	7b0 <abort@plt>

0000000000000a34 <call_weak_fn>:
 a34:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e340>
 a38:	f947f400 	ldr	x0, [x0, #4072]
 a3c:	b4000040 	cbz	x0, a44 <call_weak_fn+0x10>
 a40:	17ffff58 	b	7a0 <__gmon_start__@plt>
 a44:	d65f03c0 	ret
 a48:	d503201f 	nop
 a4c:	d503201f 	nop

0000000000000a50 <deregister_tm_clones>:
 a50:	90000100 	adrp	x0, 20000 <__data_start>
 a54:	91004000 	add	x0, x0, #0x10
 a58:	90000101 	adrp	x1, 20000 <__data_start>
 a5c:	91004021 	add	x1, x1, #0x10
 a60:	eb00003f 	cmp	x1, x0
 a64:	540000c0 	b.eq	a7c <deregister_tm_clones+0x2c>  // b.none
 a68:	f00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x1e340>
 a6c:	f947e821 	ldr	x1, [x1, #4048]
 a70:	b4000061 	cbz	x1, a7c <deregister_tm_clones+0x2c>
 a74:	aa0103f0 	mov	x16, x1
 a78:	d61f0200 	br	x16
 a7c:	d65f03c0 	ret

0000000000000a80 <register_tm_clones>:
 a80:	90000100 	adrp	x0, 20000 <__data_start>
 a84:	91004000 	add	x0, x0, #0x10
 a88:	90000101 	adrp	x1, 20000 <__data_start>
 a8c:	91004021 	add	x1, x1, #0x10
 a90:	cb000021 	sub	x1, x1, x0
 a94:	d37ffc22 	lsr	x2, x1, #63
 a98:	8b810c41 	add	x1, x2, x1, asr #3
 a9c:	9341fc21 	asr	x1, x1, #1
 aa0:	b40000c1 	cbz	x1, ab8 <register_tm_clones+0x38>
 aa4:	f00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x1e340>
 aa8:	f947fc42 	ldr	x2, [x2, #4088]
 aac:	b4000062 	cbz	x2, ab8 <register_tm_clones+0x38>
 ab0:	aa0203f0 	mov	x16, x2
 ab4:	d61f0200 	br	x16
 ab8:	d65f03c0 	ret
 abc:	d503201f 	nop

0000000000000ac0 <__do_global_dtors_aux>:
 ac0:	d503233f 	paciasp
 ac4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 ac8:	910003fd 	mov	x29, sp
 acc:	f9000bf3 	str	x19, [sp, #16]
 ad0:	90000113 	adrp	x19, 20000 <__data_start>
 ad4:	39404260 	ldrb	w0, [x19, #16]
 ad8:	37000140 	tbnz	w0, #0, b00 <__do_global_dtors_aux+0x40>
 adc:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e340>
 ae0:	f947ec00 	ldr	x0, [x0, #4056]
 ae4:	b4000080 	cbz	x0, af4 <__do_global_dtors_aux+0x34>
 ae8:	90000100 	adrp	x0, 20000 <__data_start>
 aec:	f9400400 	ldr	x0, [x0, #8]
 af0:	97ffff1c 	bl	760 <__cxa_finalize@plt>
 af4:	97ffffd7 	bl	a50 <deregister_tm_clones>
 af8:	52800020 	mov	w0, #0x1                   	// #1
 afc:	39004260 	strb	w0, [x19, #16]
 b00:	f9400bf3 	ldr	x19, [sp, #16]
 b04:	a8c27bfd 	ldp	x29, x30, [sp], #32
 b08:	d50323bf 	autiasp
 b0c:	d65f03c0 	ret

0000000000000b10 <frame_dummy>:
 b10:	d503245f 	bti	c
 b14:	17ffffdb 	b	a80 <register_tm_clones>

Disassembly of section .fini:

0000000000000b18 <_fini>:
 b18:	d503201f 	nop
 b1c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 b20:	910003fd 	mov	x29, sp
 b24:	a8c17bfd 	ldp	x29, x30, [sp], #16
 b28:	d65f03c0 	ret
