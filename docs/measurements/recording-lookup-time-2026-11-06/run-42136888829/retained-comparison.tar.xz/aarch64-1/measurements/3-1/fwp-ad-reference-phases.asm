
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	90000045 	adrp	x5, a000 <fwp_main_thread+0x1fb0>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	913460a5 	add	x5, x5, #0xd18
    2b20:	90000044 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	91348084 	add	x4, x4, #0xd20
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	9400034c 	bl	3880 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2b7c:	9101c261 	add	x1, x19, #0x70
    2b80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b84:	f947ee94 	ldr	x20, [x20, #4056]
    2b88:	f9400282 	ldr	x2, [x20]
    2b8c:	f90043f5 	str	x21, [sp, #128]
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11430>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9004420 	str	x0, [x1, #136]
    2bac:	94000395 	bl	3a00 <fwp_now_ns>
    2bb0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    2bb4:	9103e000 	add	x0, x0, #0xf8
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f5 	mov	x21, x0
    2bc8:	35000801 	cbnz	w1, 2cc8 <main+0x168>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	35000900 	cbnz	w0, 2cf8 <main+0x198>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b50009a0 	cbnz	x0, 2d38 <main+0x1d8>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f5 	add	x21, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1503e0 	mov	x0, x21
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007c0 	cbnz	w0, 2d2c <main+0x1cc>
    2c38:	aa1503e0 	mov	x0, x21
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000680 	cbnz	w0, 2d14 <main+0x1b4>
    2c48:	aa1503e1 	mov	x1, x21
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000022 	adrp	x2, 8000 <fwp_write+0xf9c>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	91014042 	add	x2, x2, #0x50
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1503e0 	mov	x0, x21
    2c68:	2a0103f5 	mov	w21, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	350004b5 	cbnz	w21, 2d08 <main+0x1a8>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c273 	add	x19, x19, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435a60 	ldr	w0, [x19, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	540002a1 	b.ne	2d04 <main+0x1a4>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	910003e1 	mov	x1, sp
    2ccc:	52800142 	mov	w2, #0xa                   	// #10
    2cd0:	97ffff4c 	bl	2a00 <strtoull@plt>
    2cd4:	f94003e0 	ldr	x0, [sp]
    2cd8:	39400000 	ldrb	w0, [x0]
    2cdc:	35fff780 	cbnz	w0, 2bcc <main+0x6c>
    2ce0:	394002a0 	ldrb	w0, [x21]
    2ce4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2ce8:	5100ac00 	sub	w0, w0, #0x2b
    2cec:	6a01001f 	tst	w0, w1
    2cf0:	54fff6e0 	b.eq	2bcc <main+0x6c>  // b.none
    2cf4:	17ffffc5 	b	2c08 <main+0xa8>
    2cf8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    2cfc:	91042000 	add	x0, x0, #0x108
    2d00:	940002e0 	bl	3880 <fwp_trap>
    2d04:	97ffff03 	bl	2910 <__stack_chk_fail@plt>
    2d08:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    2d0c:	9106a000 	add	x0, x0, #0x1a8
    2d10:	940002dc 	bl	3880 <fwp_trap>
    2d14:	aa1503e0 	mov	x0, x21
    2d18:	97fffeea 	bl	28c0 <pthread_attr_destroy@plt>
    2d1c:	35000140 	cbnz	w0, 2d44 <main+0x1e4>
    2d20:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    2d24:	91060000 	add	x0, x0, #0x180
    2d28:	940002d6 	bl	3880 <fwp_trap>
    2d2c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    2d30:	91054000 	add	x0, x0, #0x150
    2d34:	940002d3 	bl	3880 <fwp_trap>
    2d38:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    2d3c:	9104a000 	add	x0, x0, #0x128
    2d40:	940002d0 	bl	3880 <fwp_trap>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x5a0>
    2f34:	9120c021 	add	x1, x1, #0x830
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    30d0:	9129a000 	add	x0, x0, #0xa68
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x5a0>
    3198:	91204021 	add	x1, x1, #0x810
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    31d0:	912a0000 	add	x0, x0, #0xa80
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1fb0>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	f0000036 	adrp	x22, a000 <fwp_main_thread+0x1fb0>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	90000058 	adrp	x24, b000 <_IO_stdin_used+0x5a0>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	912b2042 	add	x2, x2, #0xac8
    3260:	912c82d6 	add	x22, x22, #0xb20
    3264:	9116c318 	add	x24, x24, #0x5b0
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x1fb0>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	912c6323 	add	x3, x25, #0xb18
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	912cc000 	add	x0, x0, #0xb30
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    35f0:	9129a000 	add	x0, x0, #0xa68
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    3830:	aa1303e0 	mov	x0, x19
    3834:	912ce021 	add	x1, x1, #0xb38
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    3844:	aa1303e0 	mov	x0, x19
    3848:	912d0021 	add	x1, x1, #0xb40
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    3860:	912d2021 	add	x1, x1, #0xb48
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_trap>:
    3880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3884:	d53bd041 	mrs	x1, tpidr_el0
    3888:	91400021 	add	x1, x1, #0x0, lsl #12
    388c:	91004021 	add	x1, x1, #0x10
    3890:	910003fd 	mov	x29, sp
    3894:	a90153f3 	stp	x19, x20, [sp, #16]
    3898:	aa0003f3 	mov	x19, x0
    389c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    38a0:	f947ea94 	ldr	x20, [x20, #4048]
    38a4:	f90013f5 	str	x21, [sp, #32]
    38a8:	f9400035 	ldr	x21, [x1]
    38ac:	97fffdf1 	bl	3070 <fwp_flush>
    38b0:	f9400280 	ldr	x0, [x20]
    38b4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1fb0>
    38b8:	aa1303e3 	mov	x3, x19
    38bc:	912d4042 	add	x2, x2, #0xb50
    38c0:	52800041 	mov	w1, #0x2                   	// #2
    38c4:	97fffc2f 	bl	2980 <__fprintf_chk@plt>
    38c8:	b40000b5 	cbz	x21, 38dc <fwp_trap+0x5c>
    38cc:	f9400280 	ldr	x0, [x20]
    38d0:	97fffc5c 	bl	2a40 <fflush@plt>
    38d4:	52800ca0 	mov	w0, #0x65                  	// #101
    38d8:	97fffc6a 	bl	2a80 <_Exit@plt>
    38dc:	52800ca0 	mov	w0, #0x65                  	// #101
    38e0:	97fffbb8 	bl	27c0 <exit@plt>

00000000000038e4 <fwp_closure_drop_push>:
    38e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    38e8:	910003fd 	mov	x29, sp
    38ec:	a90153f3 	stp	x19, x20, [sp, #16]
    38f0:	aa0003f3 	mov	x19, x0
    38f4:	a9408014 	ldp	x20, x0, [x0, #8]
    38f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    38fc:	aa0103f5 	mov	x21, x1
    3900:	a90363f7 	stp	x23, x24, [sp, #48]
    3904:	eb00029f 	cmp	x20, x0
    3908:	54000160 	b.eq	3934 <fwp_closure_drop_push+0x50>  // b.none
    390c:	f9400276 	ldr	x22, [x19]
    3910:	d37df297 	lsl	x23, x20, #3
    3914:	91000694 	add	x20, x20, #0x1
    3918:	f9000674 	str	x20, [x19, #8]
    391c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3920:	f8376ad5 	str	x21, [x22, x23]
    3924:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3928:	a94363f7 	ldp	x23, x24, [sp, #48]
    392c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3930:	d65f03c0 	ret
    3934:	a9046bf9 	stp	x25, x26, [sp, #64]
    3938:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    393c:	eb00029f 	cmp	x20, x0
    3940:	54000568 	b.hi	39ec <fwp_closure_drop_push+0x108>  // b.pmore
    3944:	d37cee99 	lsl	x25, x20, #4
    3948:	d37ffa9a 	lsl	x26, x20, #1
    394c:	aa1903e0 	mov	x0, x25
    3950:	97fffbd8 	bl	28b0 <malloc@plt>
    3954:	aa0003f6 	mov	x22, x0
    3958:	b4000320 	cbz	x0, 39bc <fwp_closure_drop_push+0xd8>
    395c:	aa1303f8 	mov	x24, x19
    3960:	aa1903e3 	mov	x3, x25
    3964:	d37df297 	lsl	x23, x20, #3
    3968:	aa1703e2 	mov	x2, x23
    396c:	f8418719 	ldr	x25, [x24], #24
    3970:	aa1903e1 	mov	x1, x25
    3974:	97fffbbb 	bl	2860 <__memcpy_chk@plt>
    3978:	eb18033f 	cmp	x25, x24
    397c:	540000a0 	b.eq	3990 <fwp_closure_drop_push+0xac>  // b.none
    3980:	aa1903e0 	mov	x0, x25
    3984:	97fffc13 	bl	29d0 <free@plt>
    3988:	f9400674 	ldr	x20, [x19, #8]
    398c:	d37df297 	lsl	x23, x20, #3
    3990:	91000694 	add	x20, x20, #0x1
    3994:	f9000276 	str	x22, [x19]
    3998:	f9000a7a 	str	x26, [x19, #16]
    399c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39a0:	f9000674 	str	x20, [x19, #8]
    39a4:	f8376ad5 	str	x21, [x22, x23]
    39a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    39b8:	d65f03c0 	ret
    39bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    39c0:	f947e863 	ldr	x3, [x3, #4048]
    39c4:	d2800262 	mov	x2, #0x13                  	// #19
    39c8:	d2800021 	mov	x1, #0x1                   	// #1
    39cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    39d0:	9129a000 	add	x0, x0, #0xa68
    39d4:	f9400063 	ldr	x3, [x3]
    39d8:	97fffc0e 	bl	2a10 <fwrite@plt>
    39dc:	d2800000 	mov	x0, #0x0                   	// #0
    39e0:	97fffc18 	bl	2a40 <fflush@plt>
    39e4:	52800cc0 	mov	w0, #0x66                  	// #102
    39e8:	97fffc26 	bl	2a80 <_Exit@plt>
    39ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    39f0:	912d8000 	add	x0, x0, #0xb60
    39f4:	97ffffa3 	bl	3880 <fwp_trap>
    39f8:	d503201f 	nop
    39fc:	d503201f 	nop

0000000000003a00 <fwp_now_ns>:
    3a00:	d100c3ff 	sub	sp, sp, #0x30
    3a04:	52800020 	mov	w0, #0x1                   	// #1
    3a08:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3a0c:	f947f442 	ldr	x2, [x2, #4072]
    3a10:	910023e1 	add	x1, sp, #0x8
    3a14:	a9027bfd 	stp	x29, x30, [sp, #32]
    3a18:	910083fd 	add	x29, sp, #0x20
    3a1c:	f9400043 	ldr	x3, [x2]
    3a20:	f9000fe3 	str	x3, [sp, #24]
    3a24:	d2800003 	mov	x3, #0x0                   	// #0
    3a28:	97fffb86 	bl	2840 <clock_gettime@plt>
    3a2c:	350002c0 	cbnz	w0, 3a84 <fwp_now_ns+0x84>
    3a30:	a9408be1 	ldp	x1, x2, [sp, #8]
    3a34:	d2994003 	mov	x3, #0xca00                	// #51712
    3a38:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    3a3c:	9b037c20 	mul	x0, x1, x3
    3a40:	9b437c21 	smulh	x1, x1, x3
    3a44:	ab020000 	adds	x0, x0, x2
    3a48:	937ffc42 	asr	x2, x2, #63
    3a4c:	9a020021 	adc	x1, x1, x2
    3a50:	f100001f 	cmp	x0, #0x0
    3a54:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3a58:	b50001e1 	cbnz	x1, 3a94 <fwp_now_ns+0x94>
    3a5c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3a60:	f947f421 	ldr	x1, [x1, #4072]
    3a64:	f9400fe3 	ldr	x3, [sp, #24]
    3a68:	f9400022 	ldr	x2, [x1]
    3a6c:	eb020063 	subs	x3, x3, x2
    3a70:	d2800002 	mov	x2, #0x0                   	// #0
    3a74:	540000e1 	b.ne	3a90 <fwp_now_ns+0x90>  // b.any
    3a78:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3a7c:	9100c3ff 	add	sp, sp, #0x30
    3a80:	d65f03c0 	ret
    3a84:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    3a88:	912e0000 	add	x0, x0, #0xb80
    3a8c:	97ffff7d 	bl	3880 <fwp_trap>
    3a90:	97fffba0 	bl	2910 <__stack_chk_fail@plt>
    3a94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    3a98:	912e8000 	add	x0, x0, #0xba0
    3a9c:	97ffff79 	bl	3880 <fwp_trap>

0000000000003aa0 <fwp_closure_drop.part.0>:
    3aa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3aa4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x5a0>
    3aa8:	910003fd 	mov	x29, sp
    3aac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3ab0:	f947f463 	ldr	x3, [x3, #4072]
    3ab4:	a90153f3 	stp	x19, x20, [sp, #16]
    3ab8:	d10883ff 	sub	sp, sp, #0x220
    3abc:	910003e2 	mov	x2, sp
    3ac0:	d53bd053 	mrs	x19, tpidr_el0
    3ac4:	910063f4 	add	x20, sp, #0x18
    3ac8:	3dc21020 	ldr	q0, [x1, #2112]
    3acc:	91400264 	add	x4, x19, #0x0, lsl #12
    3ad0:	91004084 	add	x4, x4, #0x10
    3ad4:	aa0003e1 	mov	x1, x0
    3ad8:	aa0203e0 	mov	x0, x2
    3adc:	f9400062 	ldr	x2, [x3]
    3ae0:	f9010fe2 	str	x2, [sp, #536]
    3ae4:	d2800002 	mov	x2, #0x0                   	// #0
    3ae8:	f90003f4 	str	x20, [sp]
    3aec:	f9000080 	str	x0, [x4]
    3af0:	3c8083e0 	stur	q0, [sp, #8]
    3af4:	97ffff7c 	bl	38e4 <fwp_closure_drop_push>
    3af8:	f94007e0 	ldr	x0, [sp, #8]
    3afc:	b4000280 	cbz	x0, 3b4c <fwp_closure_drop.part.0+0xac>
    3b00:	f90123f5 	str	x21, [sp, #576]
    3b04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3b08:	9101c2b5 	add	x21, x21, #0x70
    3b0c:	d503201f 	nop
    3b10:	f94003e1 	ldr	x1, [sp]
    3b14:	d1000400 	sub	x0, x0, #0x1
    3b18:	f90007e0 	str	x0, [sp, #8]
    3b1c:	f94046a2 	ldr	x2, [x21, #136]
    3b20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3b24:	b9400001 	ldr	w1, [x0]
    3b28:	8b011441 	add	x1, x2, x1, lsl #5
    3b2c:	f9400c21 	ldr	x1, [x1, #24]
    3b30:	b4000321 	cbz	x1, 3b94 <fwp_closure_drop.part.0+0xf4>
    3b34:	f9400422 	ldr	x2, [x1, #8]
    3b38:	52800001 	mov	w1, #0x0                   	// #0
    3b3c:	d63f0040 	blr	x2
    3b40:	f94007e0 	ldr	x0, [sp, #8]
    3b44:	b5fffe60 	cbnz	x0, 3b10 <fwp_closure_drop.part.0+0x70>
    3b48:	f94123f5 	ldr	x21, [sp, #576]
    3b4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3b50:	91004273 	add	x19, x19, #0x10
    3b54:	f94003e0 	ldr	x0, [sp]
    3b58:	f900027f 	str	xzr, [x19]
    3b5c:	eb14001f 	cmp	x0, x20
    3b60:	54000040 	b.eq	3b68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3b64:	97fffb9b 	bl	29d0 <free@plt>
    3b68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3b6c:	f947f400 	ldr	x0, [x0, #4072]
    3b70:	f9410fe2 	ldr	x2, [sp, #536]
    3b74:	f9400001 	ldr	x1, [x0]
    3b78:	eb010042 	subs	x2, x2, x1
    3b7c:	d2800001 	mov	x1, #0x0                   	// #0
    3b80:	54000101 	b.ne	3ba0 <fwp_closure_drop.part.0+0x100>  // b.any
    3b84:	910883ff 	add	sp, sp, #0x220
    3b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b90:	d65f03c0 	ret
    3b94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    3b98:	912f2000 	add	x0, x0, #0xbc8
    3b9c:	97ffff39 	bl	3880 <fwp_trap>
    3ba0:	f90123f5 	str	x21, [sp, #576]
    3ba4:	97fffb5b 	bl	2910 <__stack_chk_fail@plt>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_tape_of>:
    3bb0:	92403c02 	and	x2, x0, #0xffff
    3bb4:	b4000262 	cbz	x2, 3c00 <fwp_tape_of+0x50>
    3bb8:	9350fc01 	asr	x1, x0, #16
    3bbc:	b00000e3 	adrp	x3, 20000 <__data_start>
    3bc0:	d1000440 	sub	x0, x2, #0x1
    3bc4:	9101c062 	add	x2, x3, #0x70
    3bc8:	f9404842 	ldr	x2, [x2, #144]
    3bcc:	eb00005f 	cmp	x2, x0
    3bd0:	5400018d 	b.le	3c00 <fwp_tape_of+0x50>
    3bd4:	8b000402 	add	x2, x0, x0, lsl #1
    3bd8:	f9403863 	ldr	x3, [x3, #112]
    3bdc:	8b020802 	add	x2, x0, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b020060 	add	x0, x3, x2
    3be8:	b9400404 	ldr	w4, [x0, #4]
    3bec:	340000a4 	cbz	w4, 3c00 <fwp_tape_of+0x50>
    3bf0:	b8626862 	ldr	w2, [x3, x2]
    3bf4:	6b01005f 	cmp	w2, w1
    3bf8:	54000041 	b.ne	3c00 <fwp_tape_of+0x50>  // b.any
    3bfc:	d65f03c0 	ret
    3c00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3c04:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    3c08:	912fe000 	add	x0, x0, #0xbf8
    3c0c:	910003fd 	mov	x29, sp
    3c10:	97ffff1c 	bl	3880 <fwp_trap>

0000000000003c14 <fwp_format_g.constprop.0>:
    3c14:	d10483ff 	sub	sp, sp, #0x120
    3c18:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    3c1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3c20:	f947f442 	ldr	x2, [x2, #4072]
    3c24:	91312084 	add	x4, x4, #0xc48
    3c28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3c2c:	9102c3fd 	add	x29, sp, #0xb0
    3c30:	d2800803 	mov	x3, #0x40                  	// #64
    3c34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3c38:	93407c38 	sxtw	x24, w1
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	fd008be8 	str	d8, [sp, #272]
    3c44:	1e604008 	fmov	d8, d0
    3c48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3c4c:	910083f4 	add	x20, sp, #0x20
    3c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3c54:	aa0003f5 	mov	x21, x0
    3c58:	a91073fb 	stp	x27, x28, [sp, #256]
    3c5c:	5100071c 	sub	w28, w24, #0x1
    3c60:	2a1c03e5 	mov	w5, w28
    3c64:	f9400040 	ldr	x0, [x2]
    3c68:	f90057e0 	str	x0, [sp, #168]
    3c6c:	d2800000 	mov	x0, #0x0                   	// #0
    3c70:	52800042 	mov	w2, #0x2                   	// #2
    3c74:	aa1403e0 	mov	x0, x20
    3c78:	97fffb02 	bl	2880 <__snprintf_chk@plt>
    3c7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3c80:	aa1403e0 	mov	x0, x20
    3c84:	97fffb5b 	bl	29f0 <strchr@plt>
    3c88:	aa0003f3 	mov	x19, x0
    3c8c:	52800142 	mov	w2, #0xa                   	// #10
    3c90:	91000400 	add	x0, x0, #0x1
    3c94:	d2800001 	mov	x1, #0x0                   	// #0
    3c98:	97fffb46 	bl	29b0 <strtol@plt>
    3c9c:	aa0003f7 	mov	x23, x0
    3ca0:	11001400 	add	w0, w0, #0x5
    3ca4:	7100541f 	cmp	w0, #0x15
    3ca8:	54000d88 	b.hi	3e58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3cac:	4b170385 	sub	w5, w28, w23
    3cb0:	710000bf 	cmp	w5, #0x0
    3cb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3cb8:	54000ba0 	b.eq	3e2c <fwp_format_g.constprop.0+0x218>  // b.none
    3cbc:	394083e0 	ldrb	w0, [sp, #32]
    3cc0:	cb180273 	sub	x19, x19, x24
    3cc4:	91000673 	add	x19, x19, #0x1
    3cc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ccc:	7100b41f 	cmp	w0, #0x2d
    3cd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3cd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3cd8:	cb010266 	sub	x6, x19, x1
    3cdc:	d10004da 	sub	x26, x6, #0x1
    3ce0:	540018c0 	b.eq	3ff8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3ce4:	910183f9 	add	x25, sp, #0x60
    3ce8:	d280091b 	mov	x27, #0x48                  	// #72
    3cec:	aa1903e7 	mov	x7, x25
    3cf0:	91000423 	add	x3, x1, #0x1
    3cf4:	91011cc6 	add	x6, x6, #0x47
    3cf8:	910004f6 	add	x22, x7, #0x1
    3cfc:	37f81017 	tbnz	w23, #31, 3efc <fwp_format_g.constprop.0+0x2e8>
    3d00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3d04:	93407ef7 	sxtw	x23, w23
    3d08:	390000e4 	strb	w4, [x7]
    3d0c:	aa1303e1 	mov	x1, x19
    3d10:	aa1703e2 	mov	x2, x23
    3d14:	aa1603e0 	mov	x0, x22
    3d18:	b9000be5 	str	w5, [sp, #8]
    3d1c:	cb170374 	sub	x20, x27, x23
    3d20:	a9011be3 	stp	x3, x6, [sp, #16]
    3d24:	97fffa8f 	bl	2760 <memcpy@plt>
    3d28:	d1000694 	sub	x20, x20, #0x1
    3d2c:	f9400be3 	ldr	x3, [sp, #16]
    3d30:	8b1702d6 	add	x22, x22, x23
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	aa1a03e2 	mov	x2, x26
    3d3c:	aa0303e1 	mov	x1, x3
    3d40:	aa1403e3 	mov	x3, x20
    3d44:	97fffac7 	bl	2860 <__memcpy_chk@plt>
    3d48:	8b1a02d6 	add	x22, x22, x26
    3d4c:	f9400fe6 	ldr	x6, [sp, #24]
    3d50:	d2800900 	mov	x0, #0x48                  	// #72
    3d54:	b9400be5 	ldr	w5, [sp, #8]
    3d58:	8b170261 	add	x1, x19, x23
    3d5c:	cb1400c3 	sub	x3, x6, x20
    3d60:	cb060294 	sub	x20, x20, x6
    3d64:	f101207f 	cmp	x3, #0x48
    3d68:	93407cb8 	sxtw	x24, w5
    3d6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3d70:	aa1803e2 	mov	x2, x24
    3d74:	8b1802d3 	add	x19, x22, x24
    3d78:	8b140063 	add	x3, x3, x20
    3d7c:	aa1603e0 	mov	x0, x22
    3d80:	97fffab8 	bl	2860 <__memcpy_chk@plt>
    3d84:	cb190273 	sub	x19, x19, x25
    3d88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d8c:	eb00027f 	cmp	x19, x0
    3d90:	aa1903e1 	mov	x1, x25
    3d94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d98:	aa1503e0 	mov	x0, x21
    3d9c:	aa1303e2 	mov	x2, x19
    3da0:	97fffa70 	bl	2760 <memcpy@plt>
    3da4:	38336abf 	strb	wzr, [x21, x19]
    3da8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffa7c 	bl	27a0 <strlen@plt>
    3db4:	aa0003f3 	mov	x19, x0
    3db8:	528005c1 	mov	w1, #0x2e                  	// #46
    3dbc:	aa1503e0 	mov	x0, x21
    3dc0:	97fffb0c 	bl	29f0 <strchr@plt>
    3dc4:	b4000160 	cbz	x0, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dc8:	b4000153 	cbz	x19, 3df0 <fwp_format_g.constprop.0+0x1dc>
    3dcc:	d503201f 	nop
    3dd0:	aa1303e1 	mov	x1, x19
    3dd4:	d1000673 	sub	x19, x19, #0x1
    3dd8:	38736aa0 	ldrb	w0, [x21, x19]
    3ddc:	7100c01f 	cmp	w0, #0x30
    3de0:	54001001 	b.ne	3fe0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3de4:	38336abf 	strb	wzr, [x21, x19]
    3de8:	b5ffff53 	cbnz	x19, 3dd0 <fwp_format_g.constprop.0+0x1bc>
    3dec:	d503201f 	nop
    3df0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3df4:	f947f400 	ldr	x0, [x0, #4072]
    3df8:	f94057e2 	ldr	x2, [sp, #168]
    3dfc:	f9400001 	ldr	x1, [x0]
    3e00:	eb010042 	subs	x2, x2, x1
    3e04:	d2800001 	mov	x1, #0x0                   	// #0
    3e08:	54001061 	b.ne	4014 <fwp_format_g.constprop.0+0x400>  // b.any
    3e0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3e10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3e14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3e18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3e1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3e20:	fd408be8 	ldr	d8, [sp, #272]
    3e24:	910483ff 	add	sp, sp, #0x120
    3e28:	d65f03c0 	ret
    3e2c:	1e604100 	fmov	d0, d8
    3e30:	710000bf 	cmp	w5, #0x0
    3e34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3e38:	aa1503e0 	mov	x0, x21
    3e3c:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    3e40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e44:	91318084 	add	x4, x4, #0xc60
    3e48:	52800042 	mov	w2, #0x2                   	// #2
    3e4c:	d2803201 	mov	x1, #0x190                 	// #400
    3e50:	97fffa8c 	bl	2880 <__snprintf_chk@plt>
    3e54:	17ffffd6 	b	3dac <fwp_format_g.constprop.0+0x198>
    3e58:	cb140273 	sub	x19, x19, x20
    3e5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3e60:	910183f9 	add	x25, sp, #0x60
    3e64:	aa1303e2 	mov	x2, x19
    3e68:	aa1403e1 	mov	x1, x20
    3e6c:	aa1903e0 	mov	x0, x25
    3e70:	d2800803 	mov	x3, #0x40                  	// #64
    3e74:	97fffa7b 	bl	2860 <__memcpy_chk@plt>
    3e78:	38336b3f 	strb	wzr, [x25, x19]
    3e7c:	aa1903e0 	mov	x0, x25
    3e80:	528005c1 	mov	w1, #0x2e                  	// #46
    3e84:	97fffadb 	bl	29f0 <strchr@plt>
    3e88:	b40001c0 	cbz	x0, 3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e8c:	b50000b3 	cbnz	x19, 3ea0 <fwp_format_g.constprop.0+0x28c>
    3e90:	1400000c 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    3e94:	381ff01f 	sturb	wzr, [x0, #-1]
    3e98:	f1000673 	subs	x19, x19, #0x1
    3e9c:	54000120 	b.eq	3ec0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ea0:	8b130320 	add	x0, x25, x19
    3ea4:	385ff001 	ldurb	w1, [x0, #-1]
    3ea8:	7100c03f 	cmp	w1, #0x30
    3eac:	54ffff40 	b.eq	3e94 <fwp_format_g.constprop.0+0x280>  // b.none
    3eb0:	d1000673 	sub	x19, x19, #0x1
    3eb4:	38736b20 	ldrb	w0, [x25, x19]
    3eb8:	7100b81f 	cmp	w0, #0x2e
    3ebc:	54000a80 	b.eq	400c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3ec0:	710002ff 	cmp	w23, #0x0
    3ec4:	528005a1 	mov	w1, #0x2d                  	// #45
    3ec8:	aa1903e5 	mov	x5, x25
    3ecc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ed0:	aa1503e0 	mov	x0, x21
    3ed4:	52800566 	mov	w6, #0x2b                  	// #43
    3ed8:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    3edc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ee0:	91314084 	add	x4, x4, #0xc50
    3ee4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ee8:	52800042 	mov	w2, #0x2                   	// #2
    3eec:	d2803201 	mov	x1, #0x190                 	// #400
    3ef0:	97fffa64 	bl	2880 <__snprintf_chk@plt>
    3ef4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ef8:	17ffffbe 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3efc:	52800605 	mov	w5, #0x30                  	// #48
    3f00:	390000e5 	strb	w5, [x7]
    3f04:	d100077b 	sub	x27, x27, #0x1
    3f08:	aa0303e1 	mov	x1, x3
    3f0c:	aa1603e0 	mov	x0, x22
    3f10:	aa1b03e3 	mov	x3, x27
    3f14:	aa1a03e2 	mov	x2, x26
    3f18:	f90007e6 	str	x6, [sp, #8]
    3f1c:	b90013e4 	str	w4, [sp, #16]
    3f20:	8b1a02d6 	add	x22, x22, x26
    3f24:	b9001be5 	str	w5, [sp, #24]
    3f28:	97fffa4e 	bl	2860 <__memcpy_chk@plt>
    3f2c:	f94007e6 	ldr	x6, [sp, #8]
    3f30:	2a3703e7 	mvn	w7, w23
    3f34:	b94013e4 	ldr	w4, [sp, #16]
    3f38:	cb1b00c1 	sub	x1, x6, x27
    3f3c:	cb06037b 	sub	x27, x27, x6
    3f40:	f101203f 	cmp	x1, #0x48
    3f44:	d2800906 	mov	x6, #0x48                  	// #72
    3f48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3f4c:	8b1b0023 	add	x3, x1, x27
    3f50:	310006ff 	cmn	w23, #0x1
    3f54:	54000220 	b.eq	3f98 <fwp_format_g.constprop.0+0x384>  // b.none
    3f58:	b9401be5 	ldr	w5, [sp, #24]
    3f5c:	d2800001 	mov	x1, #0x0                   	// #0
    3f60:	f101207f 	cmp	x3, #0x48
    3f64:	d1000462 	sub	x2, x3, #0x1
    3f68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3f6c:	38216ac5 	strb	w5, [x22, x1]
    3f70:	cb030003 	sub	x3, x0, x3
    3f74:	91000421 	add	x1, x1, #0x1
    3f78:	91000463 	add	x3, x3, #0x1
    3f7c:	eb00007f 	cmp	x3, x0
    3f80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f84:	cb000063 	sub	x3, x3, x0
    3f88:	8b020063 	add	x3, x3, x2
    3f8c:	6b0100ff 	cmp	w7, w1
    3f90:	54fffe8c 	b.gt	3f60 <fwp_format_g.constprop.0+0x34c>
    3f94:	8b2742d6 	add	x22, x22, w7, uxtw
    3f98:	f101207f 	cmp	x3, #0x48
    3f9c:	d2800905 	mov	x5, #0x48                  	// #72
    3fa0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3fa4:	aa1603e0 	mov	x0, x22
    3fa8:	cb0300a1 	sub	x1, x5, x3
    3fac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3fb0:	91000421 	add	x1, x1, #0x1
    3fb4:	d1000463 	sub	x3, x3, #0x1
    3fb8:	eb05003f 	cmp	x1, x5
    3fbc:	38001402 	strb	w2, [x0], #1
    3fc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3fc4:	93407f82 	sxtw	x2, w28
    3fc8:	cb050025 	sub	x5, x1, x5
    3fcc:	aa1303e1 	mov	x1, x19
    3fd0:	8b0300a3 	add	x3, x5, x3
    3fd4:	8b1802d3 	add	x19, x22, x24
    3fd8:	97fffa22 	bl	2860 <__memcpy_chk@plt>
    3fdc:	17ffff6a 	b	3d84 <fwp_format_g.constprop.0+0x170>
    3fe0:	d1000421 	sub	x1, x1, #0x1
    3fe4:	38616aa0 	ldrb	w0, [x21, x1]
    3fe8:	7100b81f 	cmp	w0, #0x2e
    3fec:	54fff021 	b.ne	3df0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ff0:	38216abf 	strb	wzr, [x21, x1]
    3ff4:	17ffff7f 	b	3df0 <fwp_format_g.constprop.0+0x1dc>
    3ff8:	910187e7 	add	x7, sp, #0x61
    3ffc:	910183f9 	add	x25, sp, #0x60
    4000:	d28008fb 	mov	x27, #0x47                  	// #71
    4004:	390183e0 	strb	w0, [sp, #96]
    4008:	17ffff3a 	b	3cf0 <fwp_format_g.constprop.0+0xdc>
    400c:	38336b3f 	strb	wzr, [x25, x19]
    4010:	17ffffac 	b	3ec0 <fwp_format_g.constprop.0+0x2ac>
    4014:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4018:	97fffa3e 	bl	2910 <__stack_chk_fail@plt>
    401c:	d503201f 	nop

0000000000004020 <fwp_heap_report>:
    4020:	d105c3ff 	sub	sp, sp, #0x170
    4024:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    4028:	91174042 	add	x2, x2, #0x5d0
    402c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4030:	f947e821 	ldr	x1, [x1, #4048]
    4034:	a9117bfd 	stp	x29, x30, [sp, #272]
    4038:	910443fd 	add	x29, sp, #0x110
    403c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4040:	f947f400 	ldr	x0, [x0, #4072]
    4044:	a9135bf5 	stp	x21, x22, [sp, #304]
    4048:	a91463f7 	stp	x23, x24, [sp, #320]
    404c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4050:	6d1627e8 	stp	d8, d9, [sp, #352]
    4054:	fd4a1c48 	ldr	d8, [x2, #5176]
    4058:	fd4a2049 	ldr	d9, [x2, #5184]
    405c:	f9400036 	ldr	x22, [x1]
    4060:	f9400001 	ldr	x1, [x0]
    4064:	f90087e1 	str	x1, [sp, #264]
    4068:	d2800001 	mov	x1, #0x0                   	// #0
    406c:	f949e459 	ldr	x25, [x2, #5064]
    4070:	d0000021 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    4074:	f94a1057 	ldr	x23, [x2, #5152]
    4078:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    407c:	f94a1458 	ldr	x24, [x2, #5160]
    4080:	9131a021 	add	x1, x1, #0xc68
    4084:	9131c000 	add	x0, x0, #0xc70
    4088:	97fffa06 	bl	28a0 <fopen@plt>
    408c:	b4000740 	cbz	x0, 4174 <fwp_heap_report+0x154>
    4090:	528daad5 	mov	w21, #0x6d56                	// #27990
    4094:	a91253f3 	stp	x19, x20, [sp, #288]
    4098:	aa0003f4 	mov	x20, x0
    409c:	910023f3 	add	x19, sp, #0x8
    40a0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40a4:	72aae915 	movk	w21, #0x5748, lsl #16
    40a8:	aa1403e2 	mov	x2, x20
    40ac:	aa1303e0 	mov	x0, x19
    40b0:	52802001 	mov	w1, #0x100                 	// #256
    40b4:	97fffa87 	bl	2ad0 <fgets@plt>
    40b8:	b4000280 	cbz	x0, 4108 <fwp_heap_report+0xe8>
    40bc:	b9400261 	ldr	w1, [x19]
    40c0:	6b15003f 	cmp	w1, w21
    40c4:	54ffff21 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40c8:	39401260 	ldrb	w0, [x19, #4]
    40cc:	7101341f 	cmp	w0, #0x4d
    40d0:	54fffec1 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40d4:	394037e0 	ldrb	w0, [sp, #13]
    40d8:	7100e81f 	cmp	w0, #0x3a
    40dc:	54fffe61 	b.ne	40a8 <fwp_heap_report+0x88>  // b.any
    40e0:	52800142 	mov	w2, #0xa                   	// #10
    40e4:	d2800001 	mov	x1, #0x0                   	// #0
    40e8:	91003be0 	add	x0, sp, #0xe
    40ec:	97fffa31 	bl	29b0 <strtol@plt>
    40f0:	aa1403e2 	mov	x2, x20
    40f4:	aa0003fa 	mov	x26, x0
    40f8:	52802001 	mov	w1, #0x100                 	// #256
    40fc:	aa1303e0 	mov	x0, x19
    4100:	97fffa74 	bl	2ad0 <fgets@plt>
    4104:	b5fffdc0 	cbnz	x0, 40bc <fwp_heap_report+0x9c>
    4108:	aa1403e0 	mov	x0, x20
    410c:	97fff9e1 	bl	2890 <fclose@plt>
    4110:	a95253f3 	ldp	x19, x20, [sp, #288]
    4114:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4118:	f947f400 	ldr	x0, [x0, #4072]
    411c:	f94087e2 	ldr	x2, [sp, #264]
    4120:	f9400001 	ldr	x1, [x0]
    4124:	eb010042 	subs	x2, x2, x1
    4128:	d2800001 	mov	x1, #0x0                   	// #0
    412c:	54000281 	b.ne	417c <fwp_heap_report+0x15c>  // b.any
    4130:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4134:	aa1a03e6 	mov	x6, x26
    4138:	aa1903e5 	mov	x5, x25
    413c:	aa1803e4 	mov	x4, x24
    4140:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4144:	aa1703e3 	mov	x3, x23
    4148:	a95463f7 	ldp	x23, x24, [sp, #320]
    414c:	aa1603e0 	mov	x0, x22
    4150:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4154:	1e604121 	fmov	d1, d9
    4158:	1e604100 	fmov	d0, d8
    415c:	d0000022 	adrp	x2, a000 <fwp_main_thread+0x1fb0>
    4160:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4164:	91324042 	add	x2, x2, #0xc90
    4168:	9105c3ff 	add	sp, sp, #0x170
    416c:	52800041 	mov	w1, #0x2                   	// #2
    4170:	17fffa04 	b	2980 <__fprintf_chk@plt>
    4174:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4178:	17ffffe7 	b	4114 <fwp_heap_report+0xf4>
    417c:	a91253f3 	stp	x19, x20, [sp, #288]
    4180:	97fff9e4 	bl	2910 <__stack_chk_fail@plt>

0000000000004184 <fwp_heap_init>:
    4184:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4188:	d0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    418c:	91134061 	add	x1, x3, #0x4d0
    4190:	910003fd 	mov	x29, sp
    4194:	a90153f3 	stp	x19, x20, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    419c:	91174262 	add	x2, x19, #0x5d0
    41a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    41a4:	52800024 	mov	w4, #0x1                   	// #1
    41a8:	52800200 	mov	w0, #0x10                  	// #16
    41ac:	b913a444 	str	w4, [x2, #5028]
    41b0:	b8004420 	str	w0, [x1], #4
    41b4:	11004000 	add	w0, w0, #0x10
    41b8:	7104401f 	cmp	w0, #0x110
    41bc:	54ffffa1 	b.ne	41b0 <fwp_heap_init+0x2c>  // b.any
    41c0:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x5a0>
    41c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    41c8:	d0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    41cc:	91144021 	add	x1, x1, #0x510
    41d0:	3dc21443 	ldr	q3, [x2, #2128]
    41d4:	d2800000 	mov	x0, #0x0                   	// #0
    41d8:	4e040401 	dup	v1.4s, v0.s[0]
    41dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    41e0:	0f215400 	shl	v0.2s, v0.2s, #1
    41e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    41e8:	3ca06821 	str	q1, [x1, x0]
    41ec:	91004000 	add	x0, x0, #0x10
    41f0:	f101801f 	cmp	x0, #0x60
    41f4:	54ffff21 	b.ne	41d8 <fwp_heap_init+0x54>  // b.any
    41f8:	d0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    41fc:	91134063 	add	x3, x3, #0x4d0
    4200:	9115c084 	add	x4, x4, #0x570
    4204:	91174266 	add	x6, x19, #0x5d0
    4208:	d2800002 	mov	x2, #0x0                   	// #0
    420c:	d2800000 	mov	x0, #0x0                   	// #0
    4210:	d2880205 	mov	x5, #0x4010                	// #16400
    4214:	d503201f 	nop
    4218:	910f0001 	add	x1, x0, #0x3c0
    421c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4220:	eb02003f 	cmp	x1, x2
    4224:	540000a2 	b.cs	4238 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4228:	91000400 	add	x0, x0, #0x1
    422c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4230:	eb02003f 	cmp	x1, x2
    4234:	54ffffa3 	b.cc	4228 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4238:	91004042 	add	x2, x2, #0x10
    423c:	38001480 	strb	w0, [x4], #1
    4240:	eb05005f 	cmp	x2, x5
    4244:	54fffea1 	b.ne	4218 <fwp_heap_init+0x94>  // b.any
    4248:	528000b5 	mov	w21, #0x5                   	// #5
    424c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4250:	14000004 	b	4260 <fwp_heap_init+0xdc>
    4254:	d342fe94 	lsr	x20, x20, #2
    4258:	710006b5 	subs	w21, w21, #0x1
    425c:	54000720 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    4260:	91404296 	add	x22, x20, #0x10, lsl #12
    4264:	d2800005 	mov	x5, #0x0                   	// #0
    4268:	aa1603e1 	mov	x1, x22
    426c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4270:	52880443 	mov	w3, #0x4022                	// #16418
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	d2800000 	mov	x0, #0x0                   	// #0
    427c:	97fff9c9 	bl	29a0 <mmap@plt>
    4280:	aa0003e6 	mov	x6, x0
    4284:	b100041f 	cmn	x0, #0x1
    4288:	54fffe60 	b.eq	4254 <fwp_heap_init+0xd0>  // b.none
    428c:	b40005a0 	cbz	x0, 4340 <fwp_heap_init+0x1bc>
    4290:	d350fe94 	lsr	x20, x20, #16
    4294:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4298:	8b0000c7 	add	x7, x6, x0
    429c:	91174275 	add	x21, x19, #0x5d0
    42a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    42a4:	8b140a81 	add	x1, x20, x20, lsl #2
    42a8:	d2800005 	mov	x5, #0x0                   	// #0
    42ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    42b0:	d37df021 	lsl	x1, x1, #3
    42b4:	52880443 	mov	w3, #0x4022                	// #16418
    42b8:	52800002 	mov	w2, #0x0                   	// #0
    42bc:	d2800000 	mov	x0, #0x0                   	// #0
    42c0:	f909daa7 	str	x7, [x21, #5040]
    42c4:	f909dea6 	str	x6, [x21, #5048]
    42c8:	f909e2b6 	str	x22, [x21, #5056]
    42cc:	f909eab4 	str	x20, [x21, #5072]
    42d0:	f90a02a1 	str	x1, [x21, #5120]
    42d4:	97fff9b3 	bl	29a0 <mmap@plt>
    42d8:	aa0003e1 	mov	x1, x0
    42dc:	b100041f 	cmn	x0, #0x1
    42e0:	54000300 	b.eq	4340 <fwp_heap_init+0x1bc>  // b.none
    42e4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    42e8:	91350000 	add	x0, x0, #0xd40
    42ec:	f909fea1 	str	x1, [x21, #5112]
    42f0:	97fff9ec 	bl	2aa0 <getenv@plt>
    42f4:	52800002 	mov	w2, #0x0                   	// #0
    42f8:	aa0003e1 	mov	x1, x0
    42fc:	b40000e0 	cbz	x0, 4318 <fwp_heap_init+0x194>
    4300:	39400000 	ldrb	w0, [x0]
    4304:	340000a0 	cbz	w0, 4318 <fwp_heap_init+0x194>
    4308:	7100c000 	subs	w0, w0, #0x30
    430c:	54000120 	b.eq	4330 <fwp_heap_init+0x1ac>  // b.none
    4310:	7100001f 	cmp	w0, #0x0
    4314:	1a9f07e2 	cset	w2, ne	// ne = any
    4318:	91174273 	add	x19, x19, #0x5d0
    431c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4320:	b913aa62 	str	w2, [x19, #5032]
    4324:	a94153f3 	ldp	x19, x20, [sp, #16]
    4328:	a8c37bfd 	ldp	x29, x30, [sp], #48
    432c:	d65f03c0 	ret
    4330:	39400420 	ldrb	w0, [x1, #1]
    4334:	7100001f 	cmp	w0, #0x0
    4338:	1a9f07e2 	cset	w2, ne	// ne = any
    433c:	17fffff7 	b	4318 <fwp_heap_init+0x194>
    4340:	97fffb5c 	bl	30b0 <fwp_heap_oom>

0000000000004344 <fwp_wake_io>:
    4344:	900000e9 	adrp	x9, 20000 <__data_start>
    4348:	9101c122 	add	x2, x9, #0x70
    434c:	f9400001 	ldr	x1, [x0]
    4350:	5280000a 	mov	w10, #0x0                   	// #0
    4354:	f9403c46 	ldr	x6, [x2, #120]
    4358:	52800008 	mov	w8, #0x0                   	// #0
    435c:	4f000400 	movi	v0.4s, #0x0
    4360:	52800027 	mov	w7, #0x1                   	// #1
    4364:	aa0103e2 	mov	x2, x1
    4368:	b4000321 	cbz	x1, 43cc <fwp_wake_io+0x88>
    436c:	f9408c25 	ldr	x5, [x1, #280]
    4370:	39015c27 	strb	w7, [x1, #87]
    4374:	b4000165 	cbz	x5, 43a0 <fwp_wake_io+0x5c>
    4378:	a9520c24 	ldp	x4, x3, [x1, #288]
    437c:	b4000364 	cbz	x4, 43e8 <fwp_wake_io+0xa4>
    4380:	f9009483 	str	x3, [x4, #296]
    4384:	f9409423 	ldr	x3, [x1, #296]
    4388:	b4000043 	cbz	x3, 4390 <fwp_wake_io+0x4c>
    438c:	f9009064 	str	x4, [x3, #288]
    4390:	91080023 	add	x3, x1, #0x200
    4394:	f900943f 	str	xzr, [x1, #296]
    4398:	3c918060 	stur	q0, [x3, #-232]
    439c:	f9400001 	ldr	x1, [x0]
    43a0:	f9402843 	ldr	x3, [x2, #80]
    43a4:	f2001c7f 	tst	x3, #0xff000000ff
    43a8:	54fffde1 	b.ne	4364 <fwp_wake_io+0x20>  // b.any
    43ac:	39015047 	strb	w7, [x2, #84]
    43b0:	f900805f 	str	xzr, [x2, #256]
    43b4:	b40001e6 	cbz	x6, 43f0 <fwp_wake_io+0xac>
    43b8:	f90080c2 	str	x2, [x6, #256]
    43bc:	aa0203e6 	mov	x6, x2
    43c0:	52800028 	mov	w8, #0x1                   	// #1
    43c4:	aa0103e2 	mov	x2, x1
    43c8:	b5fffd21 	cbnz	x1, 436c <fwp_wake_io+0x28>
    43cc:	3400006a 	cbz	w10, 43d8 <fwp_wake_io+0x94>
    43d0:	9101c120 	add	x0, x9, #0x70
    43d4:	f900400b 	str	x11, [x0, #128]
    43d8:	34000068 	cbz	w8, 43e4 <fwp_wake_io+0xa0>
    43dc:	9101c129 	add	x9, x9, #0x70
    43e0:	f9003d26 	str	x6, [x9, #120]
    43e4:	d65f03c0 	ret
    43e8:	f90000a3 	str	x3, [x5]
    43ec:	17ffffe7 	b	4388 <fwp_wake_io+0x44>
    43f0:	aa0203eb 	mov	x11, x2
    43f4:	5280002a 	mov	w10, #0x1                   	// #1
    43f8:	17fffff1 	b	43bc <fwp_wake_io+0x78>
    43fc:	d503201f 	nop

0000000000004400 <fwp_tape_buffers_release>:
    4400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f9401400 	ldr	x0, [x0, #40]
    4414:	b7f80760 	tbnz	x0, #63, 4500 <fwp_tape_buffers_release+0x100>
    4418:	f9401a61 	ldr	x1, [x19, #48]
    441c:	b7f80301 	tbnz	x1, #63, 447c <fwp_tape_buffers_release+0x7c>
    4420:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4424:	eb02001f 	cmp	x0, x2
    4428:	540002a8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    442c:	8b000400 	add	x0, x0, x0, lsl #1
    4430:	d2a00102 	mov	x2, #0x80000               	// #524288
    4434:	d37df000 	lsl	x0, x0, #3
    4438:	cb000042 	sub	x2, x2, x0
    443c:	eb420c3f 	cmp	x1, x2, lsr #3
    4440:	540001e8 	b.hi	447c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4444:	8b010c14 	add	x20, x0, x1, lsl #3
    4448:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    444c:	91354000 	add	x0, x0, #0xd50
    4450:	97fff994 	bl	2aa0 <getenv@plt>
    4454:	b4000240 	cbz	x0, 449c <fwp_tape_buffers_release+0x9c>
    4458:	39400001 	ldrb	w1, [x0]
    445c:	7100c03f 	cmp	w1, #0x30
    4460:	540001e1 	b.ne	449c <fwp_tape_buffers_release+0x9c>  // b.any
    4464:	39400400 	ldrb	w0, [x0, #1]
    4468:	350001a0 	cbnz	w0, 449c <fwp_tape_buffers_release+0x9c>
    446c:	aa1303e0 	mov	x0, x19
    4470:	a94153f3 	ldp	x19, x20, [sp, #16]
    4474:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4478:	17fffc22 	b	3500 <fwp_tape_buffers_dispose>
    447c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    4480:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4484:	91354000 	add	x0, x0, #0xd50
    4488:	97fff986 	bl	2aa0 <getenv@plt>
    448c:	b4ffff00 	cbz	x0, 446c <fwp_tape_buffers_release+0x6c>
    4490:	39400001 	ldrb	w1, [x0]
    4494:	7100c03f 	cmp	w1, #0x30
    4498:	54fffe60 	b.eq	4464 <fwp_tape_buffers_release+0x64>  // b.none
    449c:	d1000681 	sub	x1, x20, #0x1
    44a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    44a4:	eb00003f 	cmp	x1, x0
    44a8:	54fffe28 	b.hi	446c <fwp_tape_buffers_release+0x6c>  // b.pmore
    44ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    44b0:	900000f6 	adrp	x22, 20000 <__data_start>
    44b4:	9101c2d6 	add	x22, x22, #0x70
    44b8:	910262d5 	add	x21, x22, #0x98
    44bc:	aa1503e0 	mov	x0, x21
    44c0:	97fffc10 	bl	3500 <fwp_tape_buffers_dispose>
    44c4:	ad400a61 	ldp	q1, q2, [x19]
    44c8:	f9006ad4 	str	x20, [x22, #208]
    44cc:	4f000400 	movi	v0.4s, #0x0
    44d0:	ad000aa1 	stp	q1, q2, [x21]
    44d4:	3dc00a61 	ldr	q1, [x19, #32]
    44d8:	3d800aa1 	str	q1, [x21, #32]
    44dc:	f9401a60 	ldr	x0, [x19, #48]
    44e0:	f9001aa0 	str	x0, [x21, #48]
    44e4:	f9001a7f 	str	xzr, [x19, #48]
    44e8:	ad000260 	stp	q0, q0, [x19]
    44ec:	3d800a60 	str	q0, [x19, #32]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44fc:	d65f03c0 	ret
    4500:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    4504:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4508:	91354000 	add	x0, x0, #0xd50
    450c:	97fff965 	bl	2aa0 <getenv@plt>
    4510:	b5fffa40 	cbnz	x0, 4458 <fwp_tape_buffers_release+0x58>
    4514:	17ffffd6 	b	446c <fwp_tape_buffers_release+0x6c>
    4518:	d503201f 	nop
    451c:	d503201f 	nop

0000000000004520 <fwp_poll_events>:
    4520:	d10103ff 	sub	sp, sp, #0x40
    4524:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4528:	f947f400 	ldr	x0, [x0, #4072]
    452c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4530:	910083fd 	add	x29, sp, #0x20
    4534:	a90353f3 	stp	x19, x20, [sp, #48]
    4538:	900000f4 	adrp	x20, 20000 <__data_start>
    453c:	f9400001 	ldr	x1, [x0]
    4540:	f9000fe1 	str	x1, [sp, #24]
    4544:	d2800001 	mov	x1, #0x0                   	// #0
    4548:	97fffd2e 	bl	3a00 <fwp_now_ns>
    454c:	9101c281 	add	x1, x20, #0x70
    4550:	f9406c33 	ldr	x19, [x1, #216]
    4554:	b4000e93 	cbz	x19, 4724 <fwp_poll_events+0x204>
    4558:	aa1303e1 	mov	x1, x19
    455c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4560:	14000005 	b	4574 <fwp_poll_events+0x54>
    4564:	f9408821 	ldr	x1, [x1, #272]
    4568:	eb03005f 	cmp	x2, x3
    456c:	9a83d042 	csel	x2, x2, x3, le
    4570:	b40000c1 	cbz	x1, 4588 <fwp_poll_events+0x68>
    4574:	f9403423 	ldr	x3, [x1, #104]
    4578:	b6ffff62 	tbz	x2, #63, 4564 <fwp_poll_events+0x44>
    457c:	f9408821 	ldr	x1, [x1, #272]
    4580:	aa0303e2 	mov	x2, x3
    4584:	b5ffff81 	cbnz	x1, 4574 <fwp_poll_events+0x54>
    4588:	b7f80ce2 	tbnz	x2, #63, 4724 <fwp_poll_events+0x204>
    458c:	cb000042 	sub	x2, x2, x0
    4590:	f100005f 	cmp	x2, #0x0
    4594:	540005cd 	b.le	464c <fwp_poll_events+0x12c>
    4598:	d2869b60 	mov	x0, #0x34db                	// #13531
    459c:	d2884801 	mov	x1, #0x4240                	// #16960
    45a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    45a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    45a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    45ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    45b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    45b4:	9b407c40 	smulh	x0, x2, x0
    45b8:	9352fc00 	asr	x0, x0, #18
    45bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    45c0:	9b018802 	msub	x2, x0, x1, x2
    45c4:	f100005f 	cmp	x2, #0x0
    45c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    45cc:	eb03001f 	cmp	x0, x3
    45d0:	54000a0c 	b.gt	4710 <fwp_poll_events+0x1f0>
    45d4:	340003c0 	cbz	w0, 464c <fwp_poll_events+0x12c>
    45d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    45dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    45e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    45e4:	9ba27c02 	umull	x2, w0, w2
    45e8:	d366fc43 	lsr	x3, x2, #38
    45ec:	aa0303e2 	mov	x2, x3
    45f0:	1b048063 	msub	w3, w3, w4, w0
    45f4:	9b217c63 	smull	x3, w3, w1
    45f8:	d2800001 	mov	x1, #0x0                   	// #0
    45fc:	910023e0 	add	x0, sp, #0x8
    4600:	a9008fe2 	stp	x2, x3, [sp, #8]
    4604:	97fff8f7 	bl	29e0 <nanosleep@plt>
    4608:	9101c280 	add	x0, x20, #0x70
    460c:	f9406c13 	ldr	x19, [x0, #216]
    4610:	97fffcfc 	bl	3a00 <fwp_now_ns>
    4614:	aa0003e6 	mov	x6, x0
    4618:	b50001f3 	cbnz	x19, 4654 <fwp_poll_events+0x134>
    461c:	d503201f 	nop
    4620:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4624:	f947f400 	ldr	x0, [x0, #4072]
    4628:	f9400fe2 	ldr	x2, [sp, #24]
    462c:	f9400001 	ldr	x1, [x0]
    4630:	eb010042 	subs	x2, x2, x1
    4634:	d2800001 	mov	x1, #0x0                   	// #0
    4638:	540008c1 	b.ne	4750 <fwp_poll_events+0x230>  // b.any
    463c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4640:	a94353f3 	ldp	x19, x20, [sp, #48]
    4644:	910103ff 	add	sp, sp, #0x40
    4648:	d65f03c0 	ret
    464c:	97fffced 	bl	3a00 <fwp_now_ns>
    4650:	aa0003e6 	mov	x6, x0
    4654:	4f000400 	movi	v0.4s, #0x0
    4658:	9101c288 	add	x8, x20, #0x70
    465c:	52800027 	mov	w7, #0x1                   	// #1
    4660:	f9403661 	ldr	x1, [x19, #104]
    4664:	aa1303e5 	mov	x5, x19
    4668:	f9408a73 	ldr	x19, [x19, #272]
    466c:	eb06003f 	cmp	x1, x6
    4670:	5400032c 	b.gt	46d4 <fwp_poll_events+0x1b4>
    4674:	394154a0 	ldrb	w0, [x5, #85]
    4678:	36000120 	tbz	w0, #0, 469c <fwp_poll_events+0x17c>
    467c:	f94084a0 	ldr	x0, [x5, #264]
    4680:	b40003c0 	cbz	x0, 46f8 <fwp_poll_events+0x1d8>
    4684:	f9008813 	str	x19, [x0, #272]
    4688:	b4000053 	cbz	x19, 4690 <fwp_poll_events+0x170>
    468c:	f9008660 	str	x0, [x19, #264]
    4690:	910800a0 	add	x0, x5, #0x200
    4694:	390154bf 	strb	wzr, [x5, #85]
    4698:	3c908000 	stur	q0, [x0, #-248]
    469c:	f94030a0 	ldr	x0, [x5, #96]
    46a0:	390158a7 	strb	w7, [x5, #86]
    46a4:	f100001f 	cmp	x0, #0x0
    46a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    46ac:	5400018d 	b.le	46dc <fwp_poll_events+0x1bc>
    46b0:	f94028a0 	ldr	x0, [x5, #80]
    46b4:	f2001c1f 	tst	x0, #0xff000000ff
    46b8:	540000e1 	b.ne	46d4 <fwp_poll_events+0x1b4>  // b.any
    46bc:	f9403d00 	ldr	x0, [x8, #120]
    46c0:	390150a7 	strb	w7, [x5, #84]
    46c4:	f90080bf 	str	xzr, [x5, #256]
    46c8:	b40001e0 	cbz	x0, 4704 <fwp_poll_events+0x1e4>
    46cc:	f9003d05 	str	x5, [x8, #120]
    46d0:	f9008005 	str	x5, [x0, #256]
    46d4:	b5fffc73 	cbnz	x19, 4660 <fwp_poll_events+0x140>
    46d8:	17ffffd2 	b	4620 <fwp_poll_events+0x100>
    46dc:	394144a0 	ldrb	w0, [x5, #81]
    46e0:	3707fe80 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46e4:	394140a0 	ldrb	w0, [x5, #80]
    46e8:	3707fe40 	tbnz	w0, #0, 46b0 <fwp_poll_events+0x190>
    46ec:	aa0503e0 	mov	x0, x5
    46f0:	97fffc20 	bl	3770 <fwp_cancel_tree.part.0>
    46f4:	17ffffef 	b	46b0 <fwp_poll_events+0x190>
    46f8:	9101c281 	add	x1, x20, #0x70
    46fc:	f9006c33 	str	x19, [x1, #216]
    4700:	17ffffe2 	b	4688 <fwp_poll_events+0x168>
    4704:	f9003d05 	str	x5, [x8, #120]
    4708:	f9004105 	str	x5, [x8, #128]
    470c:	17fffff2 	b	46d4 <fwp_poll_events+0x1b4>
    4710:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4714:	d2989362 	mov	x2, #0xc49b                	// #50331
    4718:	f2a4d203 	movk	x3, #0x2690, lsl #16
    471c:	f2a00402 	movk	x2, #0x20, lsl #16
    4720:	17ffffb6 	b	45f8 <fwp_poll_events+0xd8>
    4724:	97fffa53 	bl	3070 <fwp_flush>
    4728:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    472c:	f947e863 	ldr	x3, [x3, #4048]
    4730:	d2800562 	mov	x2, #0x2b                  	// #43
    4734:	d2800021 	mov	x1, #0x1                   	// #1
    4738:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    473c:	9135a000 	add	x0, x0, #0xd68
    4740:	f9400063 	ldr	x3, [x3]
    4744:	97fff8b3 	bl	2a10 <fwrite@plt>
    4748:	52800ca0 	mov	w0, #0x65                  	// #101
    474c:	97fff81d 	bl	27c0 <exit@plt>
    4750:	97fff870 	bl	2910 <__stack_chk_fail@plt>

0000000000004754 <fwp_rc_wide_dup>:
    4754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4758:	910003fd 	mov	x29, sp
    475c:	a90153f3 	stp	x19, x20, [sp, #16]
    4760:	aa0003f3 	mov	x19, x0
    4764:	ca404400 	eor	x0, x0, x0, lsr #17
    4768:	f90013f5 	str	x21, [sp, #32]
    476c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4770:	ca402400 	eor	x0, x0, x0, lsr #9
    4774:	911742a2 	add	x2, x21, #0x5d0
    4778:	92401c00 	and	x0, x0, #0xff
    477c:	910a2403 	add	x3, x0, #0x289
    4780:	8b000c40 	add	x0, x2, x0, lsl #3
    4784:	8b030c54 	add	x20, x2, x3, lsl #3
    4788:	f94a2401 	ldr	x1, [x0, #5192]
    478c:	b50000a1 	cbnz	x1, 47a0 <fwp_rc_wide_dup+0x4c>
    4790:	1400002d 	b	4844 <fwp_rc_wide_dup+0xf0>
    4794:	91004034 	add	x20, x1, #0x10
    4798:	f9400821 	ldr	x1, [x1, #16]
    479c:	b4000241 	cbz	x1, 47e4 <fwp_rc_wide_dup+0x90>
    47a0:	f9400022 	ldr	x2, [x1]
    47a4:	eb02027f 	cmp	x19, x2
    47a8:	54ffff61 	b.ne	4794 <fwp_rc_wide_dup+0x40>  // b.any
    47ac:	f9400281 	ldr	x1, [x20]
    47b0:	39400260 	ldrb	w0, [x19]
    47b4:	7103f81f 	cmp	w0, #0xfe
    47b8:	54000220 	b.eq	47fc <fwp_rc_wide_dup+0xa8>  // b.none
    47bc:	b40001a1 	cbz	x1, 47f0 <fwp_rc_wide_dup+0x9c>
    47c0:	f9400420 	ldr	x0, [x1, #8]
    47c4:	b100041f 	cmn	x0, #0x1
    47c8:	540004a0 	b.eq	485c <fwp_rc_wide_dup+0x108>  // b.none
    47cc:	91000400 	add	x0, x0, #0x1
    47d0:	f9000420 	str	x0, [x1, #8]
    47d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d8:	f94013f5 	ldr	x21, [sp, #32]
    47dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    47e0:	d65f03c0 	ret
    47e4:	39400260 	ldrb	w0, [x19]
    47e8:	7103f81f 	cmp	w0, #0xfe
    47ec:	540000a0 	b.eq	4800 <fwp_rc_wide_dup+0xac>  // b.none
    47f0:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    47f4:	91370000 	add	x0, x0, #0xdc0
    47f8:	97fffc22 	bl	3880 <fwp_trap>
    47fc:	b5000281 	cbnz	x1, 484c <fwp_rc_wide_dup+0xf8>
    4800:	d2800300 	mov	x0, #0x18                  	// #24
    4804:	97fff82b 	bl	28b0 <malloc@plt>
    4808:	b4000280 	cbz	x0, 4858 <fwp_rc_wide_dup+0x104>
    480c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4810:	a9000413 	stp	x19, x1, [x0]
    4814:	911742b5 	add	x21, x21, #0x5d0
    4818:	f900081f 	str	xzr, [x0, #16]
    481c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4820:	f9000280 	str	x0, [x20]
    4824:	39000261 	strb	w1, [x19]
    4828:	f94e26a0 	ldr	x0, [x21, #7240]
    482c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4830:	91000400 	add	x0, x0, #0x1
    4834:	f90e26a0 	str	x0, [x21, #7240]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4848:	17ffffda 	b	47b0 <fwp_rc_wide_dup+0x5c>
    484c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    4850:	91366000 	add	x0, x0, #0xd98
    4854:	97fffc0b 	bl	3880 <fwp_trap>
    4858:	97fffa16 	bl	30b0 <fwp_heap_oom>
    485c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    4860:	9137a000 	add	x0, x0, #0xde8
    4864:	97fffc07 	bl	3880 <fwp_trap>
    4868:	d503201f 	nop
    486c:	d503201f 	nop

0000000000004870 <fwp_rc_forget_slot>:
    4870:	aa0003e1 	mov	x1, x0
    4874:	39400000 	ldrb	w0, [x0]
    4878:	7103fc1f 	cmp	w0, #0xff
    487c:	54000040 	b.eq	4884 <fwp_rc_forget_slot+0x14>  // b.none
    4880:	d65f03c0 	ret
    4884:	ca414420 	eor	x0, x1, x1, lsr #17
    4888:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    488c:	ca402400 	eor	x0, x0, x0, lsr #9
    4890:	910003fd 	mov	x29, sp
    4894:	92401c00 	and	x0, x0, #0xff
    4898:	f9000bf3 	str	x19, [sp, #16]
    489c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    48a0:	91174262 	add	x2, x19, #0x5d0
    48a4:	910a2403 	add	x3, x0, #0x289
    48a8:	8b000c40 	add	x0, x2, x0, lsl #3
    48ac:	8b030c43 	add	x3, x2, x3, lsl #3
    48b0:	f94a2400 	ldr	x0, [x0, #5192]
    48b4:	b50000a0 	cbnz	x0, 48c8 <fwp_rc_forget_slot+0x58>
    48b8:	14000011 	b	48fc <fwp_rc_forget_slot+0x8c>
    48bc:	91004003 	add	x3, x0, #0x10
    48c0:	f9400800 	ldr	x0, [x0, #16]
    48c4:	b40001c0 	cbz	x0, 48fc <fwp_rc_forget_slot+0x8c>
    48c8:	f9400002 	ldr	x2, [x0]
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54ffff61 	b.ne	48bc <fwp_rc_forget_slot+0x4c>  // b.any
    48d4:	f9400801 	ldr	x1, [x0, #16]
    48d8:	91174273 	add	x19, x19, #0x5d0
    48dc:	f9000061 	str	x1, [x3]
    48e0:	97fff83c 	bl	29d0 <free@plt>
    48e4:	f94e2660 	ldr	x0, [x19, #7240]
    48e8:	d1000400 	sub	x0, x0, #0x1
    48ec:	f90e2660 	str	x0, [x19, #7240]
    48f0:	f9400bf3 	ldr	x19, [sp, #16]
    48f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48f8:	d65f03c0 	ret
    48fc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    4900:	91370000 	add	x0, x0, #0xdc0
    4904:	97fffbdf 	bl	3880 <fwp_trap>
    4908:	d503201f 	nop
    490c:	d503201f 	nop

0000000000004910 <fwp_rc_prepare_chunk>:
    4910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4914:	910003fd 	mov	x29, sp
    4918:	a9025bf5 	stp	x21, x22, [sp, #32]
    491c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    4920:	911742c2 	add	x2, x22, #0x5d0
    4924:	b9401c03 	ldr	w3, [x0, #28]
    4928:	aa0103f5 	mov	x21, x1
    492c:	a90153f3 	stp	x19, x20, [sp, #16]
    4930:	aa0003f4 	mov	x20, x0
    4934:	f94e2440 	ldr	x0, [x2, #7240]
    4938:	b4000440 	cbz	x0, 49c0 <fwp_rc_prepare_chunk+0xb0>
    493c:	d2800013 	mov	x19, #0x0                   	// #0
    4940:	35000203 	cbnz	w3, 4980 <fwp_rc_prepare_chunk+0x70>
    4944:	b4000361 	cbz	x1, 49b0 <fwp_rc_prepare_chunk+0xa0>
    4948:	f9401280 	ldr	x0, [x20, #32]
    494c:	97fff821 	bl	29d0 <free@plt>
    4950:	aa1503e0 	mov	x0, x21
    4954:	d2800021 	mov	x1, #0x1                   	// #1
    4958:	97fff7e6 	bl	28f0 <calloc@plt>
    495c:	f9001280 	str	x0, [x20, #32]
    4960:	b5000460 	cbnz	x0, 49ec <fwp_rc_prepare_chunk+0xdc>
    4964:	97fff9d3 	bl	30b0 <fwp_heap_oom>
    4968:	97ffffc2 	bl	4870 <fwp_rc_forget_slot>
    496c:	91000673 	add	x19, x19, #0x1
    4970:	b9401e83 	ldr	w3, [x20, #28]
    4974:	eb13007f 	cmp	x3, x19
    4978:	54000169 	b.ls	49a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    497c:	d503201f 	nop
    4980:	f9401283 	ldr	x3, [x20, #32]
    4984:	8b130060 	add	x0, x3, x19
    4988:	38736863 	ldrb	w3, [x3, x19]
    498c:	7103fc7f 	cmp	w3, #0xff
    4990:	54fffec0 	b.eq	4968 <fwp_rc_prepare_chunk+0x58>  // b.none
    4994:	b9401e83 	ldr	w3, [x20, #28]
    4998:	91000673 	add	x19, x19, #0x1
    499c:	eb13007f 	cmp	x3, x19
    49a0:	54ffff08 	b.hi	4980 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    49a4:	eb0302bf 	cmp	x21, x3
    49a8:	54000121 	b.ne	49cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    49ac:	b5000335 	cbnz	x21, 4a10 <fwp_rc_prepare_chunk+0x100>
    49b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    49b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49bc:	d65f03c0 	ret
    49c0:	2a0303e3 	mov	w3, w3
    49c4:	eb0302bf 	cmp	x21, x3
    49c8:	54ffff20 	b.eq	49ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    49cc:	911742c2 	add	x2, x22, #0x5d0
    49d0:	f9401280 	ldr	x0, [x20, #32]
    49d4:	f94e2841 	ldr	x1, [x2, #7248]
    49d8:	cb030021 	sub	x1, x1, x3
    49dc:	f90e2841 	str	x1, [x2, #7248]
    49e0:	97fff7fc 	bl	29d0 <free@plt>
    49e4:	b5fffb75 	cbnz	x21, 4950 <fwp_rc_prepare_chunk+0x40>
    49e8:	f900129f 	str	xzr, [x20, #32]
    49ec:	911742d6 	add	x22, x22, #0x5d0
    49f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    49f4:	b9001e95 	str	w21, [x20, #28]
    49f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    49fc:	8b150000 	add	x0, x0, x21
    4a00:	f90e2ac0 	str	x0, [x22, #7248]
    4a04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a0c:	d65f03c0 	ret
    4a10:	f9401280 	ldr	x0, [x20, #32]
    4a14:	aa1503e2 	mov	x2, x21
    4a18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a1c:	52800001 	mov	w1, #0x0                   	// #0
    4a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a28:	17fff7ae 	b	28e0 <memset@plt>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_heap_refill>:
    4a30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4a40:	911742b5 	add	x21, x21, #0x5d0
    4a44:	aa0003f6 	mov	x22, x0
    4a48:	d2800020 	mov	x0, #0x1                   	// #1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	a90363f7 	stp	x23, x24, [sp, #48]
    4a54:	2a0103f7 	mov	w23, w1
    4a58:	2a0203f8 	mov	w24, w2
    4a5c:	97fffa35 	bl	3330 <fwp_heap_chunks>
    4a60:	aa0003f3 	mov	x19, x0
    4a64:	f949fea2 	ldr	x2, [x21, #5112]
    4a68:	8b000800 	add	x0, x0, x0, lsl #2
    4a6c:	2a1703e1 	mov	w1, w23
    4a70:	52800025 	mov	w5, #0x1                   	// #1
    4a74:	d37df000 	lsl	x0, x0, #3
    4a78:	910f0021 	add	x1, x1, #0x3c0
    4a7c:	8b000054 	add	x20, x2, x0
    4a80:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4a84:	52a00024 	mov	w4, #0x10000               	// #65536
    4a88:	38206845 	strb	w5, [x2, x0]
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	39000698 	strb	w24, [x20, #1]
    4a94:	39000a97 	strb	w23, [x20, #2]
    4a98:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4a9c:	b9000681 	str	w1, [x20, #4]
    4aa0:	2a0103e5 	mov	w5, w1
    4aa4:	8b0300a2 	add	x2, x5, x3
    4aa8:	1ac10881 	udiv	w1, w4, w1
    4aac:	9ac50842 	udiv	x2, x2, x5
    4ab0:	b9000a81 	str	w1, [x20, #8]
    4ab4:	92404021 	and	x1, x1, #0x1ffff
    4ab8:	b9001a82 	str	w2, [x20, #24]
    4abc:	97ffff95 	bl	4910 <fwp_rc_prepare_chunk>
    4ac0:	f949daa0 	ldr	x0, [x21, #5040]
    4ac4:	29408a81 	ldp	w1, w2, [x20, #4]
    4ac8:	8b134000 	add	x0, x0, x19, lsl #16
    4acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad0:	8b214003 	add	x3, x0, w1, uxtw
    4ad4:	9ba20021 	umaddl	x1, w1, w2, x0
    4ad8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4adc:	a90086c3 	stp	x3, x1, [x22, #8]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ae8:	d65f03c0 	ret
    4aec:	d503201f 	nop

0000000000004af0 <fwp_mem_free>:
    4af0:	b40003c0 	cbz	x0, 4b68 <fwp_mem_free+0x78>
    4af4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4af8:	910003fd 	mov	x29, sp
    4afc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b00:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4b04:	911742a1 	add	x1, x21, #0x5d0
    4b08:	a90153f3 	stp	x19, x20, [sp, #16]
    4b0c:	aa0003f3 	mov	x19, x0
    4b10:	f949d823 	ldr	x3, [x1, #5040]
    4b14:	f949ec22 	ldr	x2, [x1, #5080]
    4b18:	cb030000 	sub	x0, x0, x3
    4b1c:	eb02401f 	cmp	x0, x2, lsl #16
    4b20:	540001c2 	b.cs	4b58 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4b24:	d350fc16 	lsr	x22, x0, #16
    4b28:	a90363f7 	stp	x23, x24, [sp, #48]
    4b2c:	f949fc22 	ldr	x2, [x1, #5112]
    4b30:	8b160ad4 	add	x20, x22, x22, lsl #2
    4b34:	d37df294 	lsl	x20, x20, #3
    4b38:	ab140057 	adds	x23, x2, x20
    4b3c:	540000c0 	b.eq	4b54 <fwp_mem_free+0x64>  // b.none
    4b40:	38746842 	ldrb	w2, [x2, x20]
    4b44:	7100045f 	cmp	w2, #0x1
    4b48:	54000120 	b.eq	4b6c <fwp_mem_free+0x7c>  // b.none
    4b4c:	7100085f 	cmp	w2, #0x2
    4b50:	540005e0 	b.eq	4c0c <fwp_mem_free+0x11c>  // b.none
    4b54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b60:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4b64:	d65f03c0 	ret
    4b68:	d65f03c0 	ret
    4b6c:	f94012f8 	ldr	x24, [x23, #32]
    4b70:	b94006e1 	ldr	w1, [x23, #4]
    4b74:	f90023f9 	str	x25, [sp, #64]
    4b78:	2a0103e2 	mov	w2, w1
    4b7c:	394006f9 	ldrb	w25, [x23, #1]
    4b80:	39400af4 	ldrb	w20, [x23, #2]
    4b84:	b4000158 	cbz	x24, 4bac <fwp_mem_free+0xbc>
    4b88:	92403e76 	and	x22, x19, #0xffff
    4b8c:	9ac20ad6 	udiv	x22, x22, x2
    4b90:	38766b01 	ldrb	w1, [x24, x22]
    4b94:	8b160300 	add	x0, x24, x22
    4b98:	7103fc3f 	cmp	w1, #0xff
    4b9c:	54000980 	b.eq	4ccc <fwp_mem_free+0x1dc>  // b.none
    4ba0:	38366b1f 	strb	wzr, [x24, x22]
    4ba4:	b94006e1 	ldr	w1, [x23, #4]
    4ba8:	2a0103e2 	mov	w2, w1
    4bac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4bb0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4bb4:	cb390000 	sub	x0, x0, w25, uxtb
    4bb8:	8b340074 	add	x20, x3, w20, uxtb
    4bbc:	911742b5 	add	x21, x21, #0x5d0
    4bc0:	1e630021 	ucvtf	d1, w1
    4bc4:	d37ae400 	lsl	x0, x0, #6
    4bc8:	8b140c14 	add	x20, x0, x20, lsl #3
    4bcc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bd0:	f8746aa0 	ldr	x0, [x21, x20]
    4bd4:	f94023f9 	ldr	x25, [sp, #64]
    4bd8:	aa2003e0 	mvn	x0, x0
    4bdc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4be0:	f9000260 	str	x0, [x19]
    4be4:	f8346ab3 	str	x19, [x21, x20]
    4be8:	f94a12a0 	ldr	x0, [x21, #5152]
    4bec:	1e612800 	fadd	d0, d0, d1
    4bf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf4:	cb020000 	sub	x0, x0, x2
    4bf8:	f90a12a0 	str	x0, [x21, #5152]
    4bfc:	fd0a22a0 	str	d0, [x21, #5184]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c08:	d65f03c0 	ret
    4c0c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4c10:	8b000063 	add	x3, x3, x0
    4c14:	eb03027f 	cmp	x19, x3
    4c18:	54fff9e1 	b.ne	4b54 <fwp_mem_free+0x64>  // b.any
    4c1c:	fd400ae1 	ldr	d1, [x23, #16]
    4c20:	fd4a2020 	ldr	d0, [x1, #5184]
    4c24:	f9400ae0 	ldr	x0, [x23, #16]
    4c28:	7e61d821 	ucvtf	d1, d1
    4c2c:	f94a1022 	ldr	x2, [x1, #5152]
    4c30:	f94012f3 	ldr	x19, [x23, #32]
    4c34:	1e612800 	fadd	d0, d0, d1
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f90a1022 	str	x2, [x1, #5152]
    4c40:	fd0a2020 	str	d0, [x1, #5184]
    4c44:	b40000b3 	cbz	x19, 4c58 <fwp_mem_free+0x168>
    4c48:	39400260 	ldrb	w0, [x19]
    4c4c:	7103fc1f 	cmp	w0, #0xff
    4c50:	54000380 	b.eq	4cc0 <fwp_mem_free+0x1d0>  // b.none
    4c54:	3900027f 	strb	wzr, [x19]
    4c58:	b9400ee2 	ldr	w2, [x23, #12]
    4c5c:	b4000142 	cbz	x2, 4c84 <fwp_mem_free+0x194>
    4c60:	911742a1 	add	x1, x21, #0x5d0
    4c64:	8b160040 	add	x0, x2, x22
    4c68:	8b000800 	add	x0, x0, x0, lsl #2
    4c6c:	f949fc21 	ldr	x1, [x1, #5112]
    4c70:	8b140034 	add	x20, x1, x20
    4c74:	8b000c20 	add	x0, x1, x0, lsl #3
    4c78:	3802869f 	strb	wzr, [x20], #40
    4c7c:	eb00029f 	cmp	x20, x0
    4c80:	54ffffc1 	b.ne	4c78 <fwp_mem_free+0x188>  // b.any
    4c84:	911742a0 	add	x0, x21, #0x5d0
    4c88:	f94a1801 	ldr	x1, [x0, #5168]
    4c8c:	f949f803 	ldr	x3, [x0, #5104]
    4c90:	8b020021 	add	x1, x1, x2
    4c94:	f90a1801 	str	x1, [x0, #5168]
    4c98:	eb16007f 	cmp	x3, x22
    4c9c:	54000049 	b.ls	4ca4 <fwp_mem_free+0x1b4>  // b.plast
    4ca0:	f909f816 	str	x22, [x0, #5104]
    4ca4:	911742b5 	add	x21, x21, #0x5d0
    4ca8:	f949f6a0 	ldr	x0, [x21, #5096]
    4cac:	eb16001f 	cmp	x0, x22
    4cb0:	54fff529 	b.ls	4b54 <fwp_mem_free+0x64>  // b.plast
    4cb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cb8:	f909f6b6 	str	x22, [x21, #5096]
    4cbc:	17ffffa7 	b	4b58 <fwp_mem_free+0x68>
    4cc0:	aa1303e0 	mov	x0, x19
    4cc4:	97fffeeb 	bl	4870 <fwp_rc_forget_slot>
    4cc8:	17ffffe3 	b	4c54 <fwp_mem_free+0x164>
    4ccc:	97fffee9 	bl	4870 <fwp_rc_forget_slot>
    4cd0:	17ffffb4 	b	4ba0 <fwp_mem_free+0xb0>

0000000000004cd4 <fwp_heap_alloc_big>:
    4cd4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd8:	910003fd 	mov	x29, sp
    4cdc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ce0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce4:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce8:	aa0003f7 	mov	x23, x0
    4cec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cf0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf4:	eb0002ff 	cmp	x23, x0
    4cf8:	54000888 	b.hi	4e08 <fwp_heap_alloc_big+0x134>  // b.pmore
    4cfc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4d00:	8b0002f4 	add	x20, x23, x0
    4d04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d08:	91174359 	add	x25, x26, #0x5d0
    4d0c:	d350fe94 	lsr	x20, x20, #16
    4d10:	2a0103f5 	mov	w21, w1
    4d14:	aa1403e0 	mov	x0, x20
    4d18:	97fff986 	bl	3330 <fwp_heap_chunks>
    4d1c:	f949ff22 	ldr	x2, [x25, #5112]
    4d20:	8b000813 	add	x19, x0, x0, lsl #2
    4d24:	aa0003f8 	mov	x24, x0
    4d28:	52800043 	mov	w3, #0x2                   	// #2
    4d2c:	d37df273 	lsl	x19, x19, #3
    4d30:	d2800021 	mov	x1, #0x1                   	// #1
    4d34:	8b130040 	add	x0, x2, x19
    4d38:	38336843 	strb	w3, [x2, x19]
    4d3c:	39000415 	strb	w21, [x0, #1]
    4d40:	b9000c14 	str	w20, [x0, #12]
    4d44:	f9000817 	str	x23, [x0, #16]
    4d48:	97fffef2 	bl	4910 <fwp_rc_prepare_chunk>
    4d4c:	f100069f 	cmp	x20, #0x1
    4d50:	54000269 	b.ls	4d9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4d54:	8b180294 	add	x20, x20, x24
    4d58:	9100a273 	add	x19, x19, #0x28
    4d5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4d60:	5280007b 	mov	w27, #0x3                   	// #3
    4d64:	8b140a94 	add	x20, x20, x20, lsl #2
    4d68:	2a1803fc 	mov	w28, w24
    4d6c:	9adb2296 	lsl	x22, x20, x27
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffee4 	bl	4910 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0x9c>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x104>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffca4 	bl	4184 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff70 	b	4cd4 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffeb5 	bl	4a30 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_p_ad_push.constprop.0>:
    51a4:	f100001f 	cmp	x0, #0x0
    51a8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    51ac:	54000e8b 	b.lt	537c <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    51b0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    51b4:	aa0003e4 	mov	x4, x0
    51b8:	910003fd 	mov	x29, sp
    51bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51c0:	aa0003f5 	mov	x21, x0
    51c4:	aa020000 	orr	x0, x0, x2
    51c8:	a90363f7 	stp	x23, x24, [sp, #48]
    51cc:	aa0203f7 	mov	x23, x2
    51d0:	6d0627e8 	stp	d8, d9, [sp, #96]
    51d4:	9e670029 	fmov	d9, x1
    51d8:	9e670068 	fmov	d8, x3
    51dc:	b6f80900 	tbz	x0, #63, 52fc <fwp_p_ad_push.constprop.0+0x158>
    51e0:	a90153f3 	stp	x19, x20, [sp, #16]
    51e4:	9360fc80 	asr	x0, x4, #32
    51e8:	b6f800c4 	tbz	x4, #63, 5200 <fwp_p_ad_push.constprop.0+0x5c>
    51ec:	1e604109 	fmov	d9, d8
    51f0:	2f00e408 	movi	d8, #0x0
    51f4:	9360fc40 	asr	x0, x2, #32
    51f8:	aa0203f5 	mov	x21, x2
    51fc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5200:	97fffa6c 	bl	3bb0 <fwp_tape_of>
    5204:	aa0003f3 	mov	x19, x0
    5208:	f9403000 	ldr	x0, [x0, #96]
    520c:	b5001280 	cbnz	x0, 545c <fwp_p_ad_push.constprop.0+0x2b8>
    5210:	f9400a76 	ldr	x22, [x19, #16]
    5214:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5218:	eb0002df 	cmp	x22, x0
    521c:	54000e2c 	b.gt	53e0 <fwp_p_ad_push.constprop.0+0x23c>
    5220:	eb3542df 	cmp	x22, w21, uxtw
    5224:	54000d4d 	b.le	53cc <fwp_p_ad_push.constprop.0+0x228>
    5228:	b7f80077 	tbnz	x23, #63, 5234 <fwp_p_ad_push.constprop.0+0x90>
    522c:	eb3742df 	cmp	x22, w23, uxtw
    5230:	54000ced 	b.le	53cc <fwp_p_ad_push.constprop.0+0x228>
    5234:	f9400678 	ldr	x24, [x19, #8]
    5238:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    523c:	cb1802d8 	sub	x24, x22, x24
    5240:	91000701 	add	x1, x24, #0x1
    5244:	eb00003f 	cmp	x1, x0
    5248:	54000cc8 	b.hi	53e0 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    524c:	a9418274 	ldp	x20, x0, [x19, #24]
    5250:	a90573fb 	stp	x27, x28, [sp, #80]
    5254:	eb14003f 	cmp	x1, x20
    5258:	5400068d 	b.le	5328 <fwp_p_ad_push.constprop.0+0x184>
    525c:	f100029f 	cmp	x20, #0x0
    5260:	d2800803 	mov	x3, #0x40                  	// #64
    5264:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5268:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    526c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5270:	eb14003f 	cmp	x1, x20
    5274:	5400008d 	b.le	5284 <fwp_p_ad_push.constprop.0+0xe0>
    5278:	eb02029f 	cmp	x20, x2
    527c:	5400052d 	b.le	5320 <fwp_p_ad_push.constprop.0+0x17c>
    5280:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5284:	d37df299 	lsl	x25, x20, #3
    5288:	aa1903e1 	mov	x1, x25
    528c:	97fff59d 	bl	2900 <realloc@plt>
    5290:	aa0003e1 	mov	x1, x0
    5294:	b4000b00 	cbz	x0, 53f4 <fwp_p_ad_push.constprop.0+0x250>
    5298:	f9400e62 	ldr	x2, [x19, #24]
    529c:	f9001261 	str	x1, [x19, #32]
    52a0:	f9401a60 	ldr	x0, [x19, #48]
    52a4:	d37cee9a 	lsl	x26, x20, #4
    52a8:	8b020821 	add	x1, x1, x2, lsl #2
    52ac:	f9001661 	str	x1, [x19, #40]
    52b0:	aa1a03e1 	mov	x1, x26
    52b4:	97fff593 	bl	2900 <realloc@plt>
    52b8:	aa0003e2 	mov	x2, x0
    52bc:	b40009c0 	cbz	x0, 53f4 <fwp_p_ad_push.constprop.0+0x250>
    52c0:	f9400e61 	ldr	x1, [x19, #24]
    52c4:	d37df31b 	lsl	x27, x24, #3
    52c8:	d37ef685 	lsl	x5, x20, #2
    52cc:	d37ef71c 	lsl	x28, x24, #2
    52d0:	8b190004 	add	x4, x0, x25
    52d4:	8b010c01 	add	x1, x0, x1, lsl #3
    52d8:	a9030660 	stp	x0, x1, [x19, #48]
    52dc:	b5000558 	cbnz	x24, 5384 <fwp_p_ad_push.constprop.0+0x1e0>
    52e0:	f9001e64 	str	x4, [x19, #56]
    52e4:	f9401260 	ldr	x0, [x19, #32]
    52e8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    52ec:	8b050001 	add	x1, x0, x5
    52f0:	f9000e74 	str	x20, [x19, #24]
    52f4:	f9001661 	str	x1, [x19, #40]
    52f8:	14000010 	b	5338 <fwp_p_ad_push.constprop.0+0x194>
    52fc:	9360fc40 	asr	x0, x2, #32
    5300:	a90153f3 	stp	x19, x20, [sp, #16]
    5304:	eb84801f 	cmp	x0, x4, asr #32
    5308:	54fff7c0 	b.eq	5200 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    530c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    5310:	91382000 	add	x0, x0, #0xe08
    5314:	a9046bf9 	stp	x25, x26, [sp, #64]
    5318:	a90573fb 	stp	x27, x28, [sp, #80]
    531c:	97fff959 	bl	3880 <fwp_trap>
    5320:	d37ffa94 	lsl	x20, x20, #1
    5324:	17ffffd3 	b	5270 <fwp_p_ad_push.constprop.0+0xcc>
    5328:	a9428a61 	ldp	x1, x2, [x19, #40]
    532c:	d37ef71c 	lsl	x28, x24, #2
    5330:	f9401e64 	ldr	x4, [x19, #56]
    5334:	d37df31b 	lsl	x27, x24, #3
    5338:	b83c6815 	str	w21, [x0, x28]
    533c:	f10002ff 	cmp	x23, #0x0
    5340:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5344:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5348:	fc3b6849 	str	d9, [x2, x27]
    534c:	aa1602a0 	orr	x0, x21, x22
    5350:	b83c6837 	str	w23, [x1, x28]
    5354:	910006d6 	add	x22, x22, #0x1
    5358:	a94363f7 	ldp	x23, x24, [sp, #48]
    535c:	fc3b6888 	str	d8, [x4, x27]
    5360:	a94573fb 	ldp	x27, x28, [sp, #80]
    5364:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5368:	f9000a76 	str	x22, [x19, #16]
    536c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5374:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5378:	d65f03c0 	ret
    537c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5380:	d65f03c0 	ret
    5384:	eb1a033f 	cmp	x25, x26
    5388:	aa0403e0 	mov	x0, x4
    538c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5390:	aa1b03e2 	mov	x2, x27
    5394:	cb190063 	sub	x3, x3, x25
    5398:	f9003fe5 	str	x5, [sp, #120]
    539c:	97fff5c5 	bl	2ab0 <__memmove_chk@plt>
    53a0:	a9420660 	ldp	x0, x1, [x19, #32]
    53a4:	aa1c03e2 	mov	x2, x28
    53a8:	f9401a63 	ldr	x3, [x19, #48]
    53ac:	f9403fe5 	ldr	x5, [sp, #120]
    53b0:	8b190063 	add	x3, x3, x25
    53b4:	f9001e63 	str	x3, [x19, #56]
    53b8:	8b050000 	add	x0, x0, x5
    53bc:	97fff4f1 	bl	2780 <memmove@plt>
    53c0:	a9431262 	ldp	x2, x4, [x19, #48]
    53c4:	f9403fe5 	ldr	x5, [sp, #120]
    53c8:	17ffffc7 	b	52e4 <fwp_p_ad_push.constprop.0+0x140>
    53cc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    53d0:	913a8000 	add	x0, x0, #0xea0
    53d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    53d8:	a90573fb 	stp	x27, x28, [sp, #80]
    53dc:	97fff929 	bl	3880 <fwp_trap>
    53e0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    53e4:	913a0000 	add	x0, x0, #0xe80
    53e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    53ec:	a90573fb 	stp	x27, x28, [sp, #80]
    53f0:	97fff924 	bl	3880 <fwp_trap>
    53f4:	aa1303e0 	mov	x0, x19
    53f8:	97fff706 	bl	3010 <fwp_tape_unlink_scope>
    53fc:	f9401260 	ldr	x0, [x19, #32]
    5400:	97fff574 	bl	29d0 <free@plt>
    5404:	f9401a60 	ldr	x0, [x19, #48]
    5408:	97fff572 	bl	29d0 <free@plt>
    540c:	f9402260 	ldr	x0, [x19, #64]
    5410:	97fff570 	bl	29d0 <free@plt>
    5414:	f9000e7f 	str	xzr, [x19, #24]
    5418:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    541c:	f947e821 	ldr	x1, [x1, #4048]
    5420:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5424:	d2800262 	mov	x2, #0x13                  	// #19
    5428:	4f000400 	movi	v0.4s, #0x0
    542c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    5430:	f9400023 	ldr	x3, [x1]
    5434:	b900067f 	str	wzr, [x19, #4]
    5438:	d2800021 	mov	x1, #0x1                   	// #1
    543c:	9129a000 	add	x0, x0, #0xa68
    5440:	3c808260 	stur	q0, [x19, #8]
    5444:	ad010260 	stp	q0, q0, [x19, #32]
    5448:	97fff572 	bl	2a10 <fwrite@plt>
    544c:	d2800000 	mov	x0, #0x0                   	// #0
    5450:	97fff57c 	bl	2a40 <fflush@plt>
    5454:	52800cc0 	mov	w0, #0x66                  	// #102
    5458:	97fff58a 	bl	2a80 <_Exit@plt>
    545c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    5460:	91394000 	add	x0, x0, #0xe50
    5464:	a9046bf9 	stp	x25, x26, [sp, #64]
    5468:	a90573fb 	stp	x27, x28, [sp, #80]
    546c:	97fff905 	bl	3880 <fwp_trap>

0000000000005470 <w120>:
    5470:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5474:	9e660003 	fmov	x3, d0
    5478:	aa0003e2 	mov	x2, x0
    547c:	910003fd 	mov	x29, sp
    5480:	6d0327e8 	stp	d8, d9, [sp, #48]
    5484:	1e604028 	fmov	d8, d1
    5488:	1e600809 	fmul	d9, d0, d0
    548c:	fd0023ea 	str	d10, [sp, #64]
    5490:	1e60400a 	fmov	d10, d0
    5494:	a90153f3 	stp	x19, x20, [sp, #16]
    5498:	aa0003f3 	mov	x19, x0
    549c:	aa0103f4 	mov	x20, x1
    54a0:	aa0303e1 	mov	x1, x3
    54a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    54a8:	97ffff3f 	bl	51a4 <fwp_p_ad_push.constprop.0>
    54ac:	1e693908 	fsub	d8, d8, d9
    54b0:	aa1403e2 	mov	x2, x20
    54b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54bc:	9e660116 	fmov	x22, d8
    54c0:	97ffff39 	bl	51a4 <fwp_p_ad_push.constprop.0>
    54c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    54c8:	aa0003e1 	mov	x1, x0
    54cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	1e6a3929 	fsub	d9, d9, d10
    54d8:	aa0103f3 	mov	x19, x1
    54dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    54e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    54e4:	9e660135 	fmov	x21, d9
    54e8:	97ffff2f 	bl	51a4 <fwp_p_ad_push.constprop.0>
    54ec:	1e680908 	fmul	d8, d8, d8
    54f0:	aa0003f4 	mov	x20, x0
    54f4:	aa1603e3 	mov	x3, x22
    54f8:	aa1603e1 	mov	x1, x22
    54fc:	aa1303e2 	mov	x2, x19
    5500:	aa1303e0 	mov	x0, x19
    5504:	97ffff28 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5508:	aa0003e2 	mov	x2, x0
    550c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5510:	9e670020 	fmov	d0, x1
    5514:	9e660101 	fmov	x1, d8
    5518:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    551c:	1e600908 	fmul	d8, d8, d0
    5520:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5524:	97ffff20 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5528:	1e690929 	fmul	d9, d9, d9
    552c:	aa0003f3 	mov	x19, x0
    5530:	aa1503e3 	mov	x3, x21
    5534:	aa1503e1 	mov	x1, x21
    5538:	aa1403e2 	mov	x2, x20
    553c:	aa1403e0 	mov	x0, x20
    5540:	97ffff19 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5544:	1e692908 	fadd	d8, d8, d9
    5548:	aa1303e2 	mov	x2, x19
    554c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5550:	aa0303e1 	mov	x1, x3
    5554:	97ffff14 	bl	51a4 <fwp_p_ad_push.constprop.0>
    5558:	aa0003e1 	mov	x1, x0
    555c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5560:	9e660100 	fmov	x0, d8
    5564:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5568:	6d4327e8 	ldp	d8, d9, [sp, #48]
    556c:	fd4023ea 	ldr	d10, [sp, #64]
    5570:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5574:	d65f03c0 	ret
    5578:	d503201f 	nop
    557c:	d503201f 	nop

0000000000005580 <w176.constprop.0>:
    5580:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5584:	910003fd 	mov	x29, sp
    5588:	a9025bf5 	stp	x21, x22, [sp, #32]
    558c:	fd001be8 	str	d8, [sp, #48]
    5590:	f9400015 	ldr	x21, [x0]
    5594:	b4000315 	cbz	x21, 55f4 <w176.constprop.0+0x74>
    5598:	2f00e408 	movi	d8, #0x0
    559c:	91002016 	add	x22, x0, #0x8
    55a0:	a90153f3 	stp	x19, x20, [sp, #16]
    55a4:	91004014 	add	x20, x0, #0x10
    55a8:	d2800013 	mov	x19, #0x0                   	// #0
    55ac:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55b0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    55b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    55b8:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    55bc:	aa0303e1 	mov	x1, x3
    55c0:	1e602908 	fadd	d8, d8, d0
    55c4:	91000a73 	add	x19, x19, #0x2
    55c8:	97fffef7 	bl	51a4 <fwp_p_ad_push.constprop.0>
    55cc:	eb1302bf 	cmp	x21, x19
    55d0:	54ffff08 	b.hi	55b0 <w176.constprop.0+0x30>  // b.pmore
    55d4:	9e660102 	fmov	x2, d8
    55d8:	fd401be8 	ldr	d8, [sp, #48]
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	aa0003e1 	mov	x1, x0
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	aa0203e0 	mov	x0, x2
    55ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    55f0:	d65f03c0 	ret
    55f4:	2f00e408 	movi	d8, #0x0
    55f8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5600:	aa0003e1 	mov	x1, x0
    5604:	9e660102 	fmov	x2, d8
    5608:	fd401be8 	ldr	d8, [sp, #48]
    560c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5610:	aa0203e0 	mov	x0, x2
    5614:	d65f03c0 	ret
    5618:	d503201f 	nop
    561c:	d503201f 	nop

0000000000005620 <fwp_rc_share>:
    5620:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5624:	91174042 	add	x2, x2, #0x5d0
    5628:	f949d843 	ldr	x3, [x2, #5040]
    562c:	f949ec41 	ldr	x1, [x2, #5080]
    5630:	cb030000 	sub	x0, x0, x3
    5634:	eb01401f 	cmp	x0, x1, lsl #16
    5638:	540002c2 	b.cs	5690 <fwp_rc_share+0x70>  // b.hs, b.nlast
    563c:	d350fc01 	lsr	x1, x0, #16
    5640:	f949fc44 	ldr	x4, [x2, #5112]
    5644:	8b010821 	add	x1, x1, x1, lsl #2
    5648:	d37df021 	lsl	x1, x1, #3
    564c:	8b010083 	add	x3, x4, x1
    5650:	f9401062 	ldr	x2, [x3, #32]
    5654:	b40001e2 	cbz	x2, 5690 <fwp_rc_share+0x70>
    5658:	38616881 	ldrb	w1, [x4, x1]
    565c:	7100083f 	cmp	w1, #0x2
    5660:	540001a0 	b.eq	5694 <fwp_rc_share+0x74>  // b.none
    5664:	7100043f 	cmp	w1, #0x1
    5668:	54000141 	b.ne	5690 <fwp_rc_share+0x70>  // b.any
    566c:	29430464 	ldp	w4, w1, [x3, #24]
    5670:	92403c00 	and	x0, x0, #0xffff
    5674:	9b047c00 	mul	x0, x0, x4
    5678:	d360fc00 	lsr	x0, x0, #32
    567c:	eb01001f 	cmp	x0, x1
    5680:	54000082 	b.cs	5690 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5684:	8b000042 	add	x2, x2, x0
    5688:	39400040 	ldrb	w0, [x2]
    568c:	350000a0 	cbnz	w0, 56a0 <fwp_rc_share+0x80>
    5690:	d65f03c0 	ret
    5694:	72003c1f 	tst	w0, #0xffff
    5698:	54ffff80 	b.eq	5688 <fwp_rc_share+0x68>  // b.none
    569c:	d65f03c0 	ret
    56a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    56a4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    56a8:	913b0000 	add	x0, x0, #0xec0
    56ac:	910003fd 	mov	x29, sp
    56b0:	97fff874 	bl	3880 <fwp_trap>

00000000000056b4 <fwp_rc_free_arr>:
    56b4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    56b8:	91174063 	add	x3, x3, #0x5d0
    56bc:	f949d861 	ldr	x1, [x3, #5040]
    56c0:	f949ec62 	ldr	x2, [x3, #5080]
    56c4:	cb010001 	sub	x1, x0, x1
    56c8:	eb02403f 	cmp	x1, x2, lsl #16
    56cc:	54000342 	b.cs	5734 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    56d0:	d350fc22 	lsr	x2, x1, #16
    56d4:	f949fc65 	ldr	x5, [x3, #5112]
    56d8:	8b020842 	add	x2, x2, x2, lsl #2
    56dc:	d37df042 	lsl	x2, x2, #3
    56e0:	8b0200a4 	add	x4, x5, x2
    56e4:	f9401083 	ldr	x3, [x4, #32]
    56e8:	b4000263 	cbz	x3, 5734 <fwp_rc_free_arr+0x80>
    56ec:	386268a2 	ldrb	w2, [x5, x2]
    56f0:	7100085f 	cmp	w2, #0x2
    56f4:	540001c0 	b.eq	572c <fwp_rc_free_arr+0x78>  // b.none
    56f8:	7100045f 	cmp	w2, #0x1
    56fc:	540001c1 	b.ne	5734 <fwp_rc_free_arr+0x80>  // b.any
    5700:	29430885 	ldp	w5, w2, [x4, #24]
    5704:	92403c21 	and	x1, x1, #0xffff
    5708:	9b057c21 	mul	x1, x1, x5
    570c:	d360fc21 	lsr	x1, x1, #32
    5710:	eb02003f 	cmp	x1, x2
    5714:	54000102 	b.cs	5734 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5718:	8b010063 	add	x3, x3, x1
    571c:	39400061 	ldrb	w1, [x3]
    5720:	7100043f 	cmp	w1, #0x1
    5724:	54000081 	b.ne	5734 <fwp_rc_free_arr+0x80>  // b.any
    5728:	17fffcf2 	b	4af0 <fwp_mem_free>
    572c:	72003c3f 	tst	w1, #0xffff
    5730:	54ffff60 	b.eq	571c <fwp_rc_free_arr+0x68>  // b.none
    5734:	d65f03c0 	ret
    5738:	d503201f 	nop
    573c:	d503201f 	nop

0000000000005740 <fwp_rc_dup>:
    5740:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5744:	91174042 	add	x2, x2, #0x5d0
    5748:	f949d841 	ldr	x1, [x2, #5040]
    574c:	f949ec43 	ldr	x3, [x2, #5080]
    5750:	cb010001 	sub	x1, x0, x1
    5754:	eb03403f 	cmp	x1, x3, lsl #16
    5758:	54000342 	b.cs	57c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    575c:	d350fc20 	lsr	x0, x1, #16
    5760:	f949fc44 	ldr	x4, [x2, #5112]
    5764:	8b000800 	add	x0, x0, x0, lsl #2
    5768:	d37df002 	lsl	x2, x0, #3
    576c:	8b020083 	add	x3, x4, x2
    5770:	f9401060 	ldr	x0, [x3, #32]
    5774:	b4000260 	cbz	x0, 57c0 <fwp_rc_dup+0x80>
    5778:	38626882 	ldrb	w2, [x4, x2]
    577c:	7100085f 	cmp	w2, #0x2
    5780:	54000220 	b.eq	57c4 <fwp_rc_dup+0x84>  // b.none
    5784:	7100045f 	cmp	w2, #0x1
    5788:	540001c1 	b.ne	57c0 <fwp_rc_dup+0x80>  // b.any
    578c:	29430864 	ldp	w4, w2, [x3, #24]
    5790:	92403c21 	and	x1, x1, #0xffff
    5794:	9b047c21 	mul	x1, x1, x4
    5798:	d360fc21 	lsr	x1, x1, #32
    579c:	eb02003f 	cmp	x1, x2
    57a0:	54000102 	b.cs	57c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57a4:	8b010000 	add	x0, x0, x1
    57a8:	39400001 	ldrb	w1, [x0]
    57ac:	340000a1 	cbz	w1, 57c0 <fwp_rc_dup+0x80>
    57b0:	7103f43f 	cmp	w1, #0xfd
    57b4:	540000e8 	b.hi	57d0 <fwp_rc_dup+0x90>  // b.pmore
    57b8:	11000421 	add	w1, w1, #0x1
    57bc:	39000001 	strb	w1, [x0]
    57c0:	d65f03c0 	ret
    57c4:	72003c3f 	tst	w1, #0xffff
    57c8:	54ffff00 	b.eq	57a8 <fwp_rc_dup+0x68>  // b.none
    57cc:	d65f03c0 	ret
    57d0:	17fffbe1 	b	4754 <fwp_rc_wide_dup>

00000000000057d4 <fwp_owned_entry173>:
    57d4:	d10103ff 	sub	sp, sp, #0x40
    57d8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    57dc:	f947f442 	ldr	x2, [x2, #4072]
    57e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57e4:	910083fd 	add	x29, sp, #0x20
    57e8:	a90353f3 	stp	x19, x20, [sp, #48]
    57ec:	f9400043 	ldr	x3, [x2]
    57f0:	f9000fe3 	str	x3, [sp, #24]
    57f4:	d2800003 	mov	x3, #0x0                   	// #0
    57f8:	a9400c01 	ldp	x1, x3, [x0]
    57fc:	f9400802 	ldr	x2, [x0, #16]
    5800:	ab020022 	adds	x2, x1, x2
    5804:	540006e6 	b.vs	58e0 <fwp_owned_entry173+0x10c>
    5808:	910023e1 	add	x1, sp, #0x8
    580c:	52800000 	mov	w0, #0x0                   	// #0
    5810:	a9008be3 	stp	x3, x2, [sp, #8]
    5814:	97fffe1c 	bl	5084 <fwp_data.part.0.constprop.0>
    5818:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    581c:	91174063 	add	x3, x3, #0x5d0
    5820:	aa0003f3 	mov	x19, x0
    5824:	f949d861 	ldr	x1, [x3, #5040]
    5828:	f949ec60 	ldr	x0, [x3, #5080]
    582c:	cb010261 	sub	x1, x19, x1
    5830:	eb00403f 	cmp	x1, x0, lsl #16
    5834:	54000322 	b.cs	5898 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5838:	d350fc22 	lsr	x2, x1, #16
    583c:	f949fc63 	ldr	x3, [x3, #5112]
    5840:	8b020842 	add	x2, x2, x2, lsl #2
    5844:	d37df042 	lsl	x2, x2, #3
    5848:	8b020060 	add	x0, x3, x2
    584c:	f9401014 	ldr	x20, [x0, #32]
    5850:	b4000254 	cbz	x20, 5898 <fwp_owned_entry173+0xc4>
    5854:	38626862 	ldrb	w2, [x3, x2]
    5858:	7100085f 	cmp	w2, #0x2
    585c:	54000360 	b.eq	58c8 <fwp_owned_entry173+0xf4>  // b.none
    5860:	7100045f 	cmp	w2, #0x1
    5864:	540001a1 	b.ne	5898 <fwp_owned_entry173+0xc4>  // b.any
    5868:	29430002 	ldp	w2, w0, [x0, #24]
    586c:	92403c21 	and	x1, x1, #0xffff
    5870:	9b027c21 	mul	x1, x1, x2
    5874:	d360fc21 	lsr	x1, x1, #32
    5878:	eb00003f 	cmp	x1, x0
    587c:	540000e2 	b.cs	5898 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5880:	8b010294 	add	x20, x20, x1
    5884:	39400280 	ldrb	w0, [x20]
    5888:	7103fc1f 	cmp	w0, #0xff
    588c:	54000240 	b.eq	58d4 <fwp_owned_entry173+0x100>  // b.none
    5890:	52800020 	mov	w0, #0x1                   	// #1
    5894:	39000280 	strb	w0, [x20]
    5898:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    589c:	f947f400 	ldr	x0, [x0, #4072]
    58a0:	f9400fe2 	ldr	x2, [sp, #24]
    58a4:	f9400001 	ldr	x1, [x0]
    58a8:	eb010042 	subs	x2, x2, x1
    58ac:	d2800001 	mov	x1, #0x0                   	// #0
    58b0:	540001a1 	b.ne	58e4 <fwp_owned_entry173+0x110>  // b.any
    58b4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    58b8:	aa1303e0 	mov	x0, x19
    58bc:	a94353f3 	ldp	x19, x20, [sp, #48]
    58c0:	910103ff 	add	sp, sp, #0x40
    58c4:	d65f03c0 	ret
    58c8:	72003c3f 	tst	w1, #0xffff
    58cc:	54fffe61 	b.ne	5898 <fwp_owned_entry173+0xc4>  // b.any
    58d0:	17ffffed 	b	5884 <fwp_owned_entry173+0xb0>
    58d4:	aa1403e0 	mov	x0, x20
    58d8:	97fffbe6 	bl	4870 <fwp_rc_forget_slot>
    58dc:	17ffffed 	b	5890 <fwp_owned_entry173+0xbc>
    58e0:	97fff488 	bl	2b00 <fwp_trap_overflow.constprop.0>
    58e4:	97fff40b 	bl	2910 <__stack_chk_fail@plt>
    58e8:	d503201f 	nop
    58ec:	d503201f 	nop

00000000000058f0 <e173>:
    58f0:	d10103ff 	sub	sp, sp, #0x40
    58f4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    58f8:	f947f442 	ldr	x2, [x2, #4072]
    58fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5900:	910083fd 	add	x29, sp, #0x20
    5904:	a90353f3 	stp	x19, x20, [sp, #48]
    5908:	f9400043 	ldr	x3, [x2]
    590c:	f9000fe3 	str	x3, [sp, #24]
    5910:	d2800003 	mov	x3, #0x0                   	// #0
    5914:	a9400c01 	ldp	x1, x3, [x0]
    5918:	f9400802 	ldr	x2, [x0, #16]
    591c:	ab020022 	adds	x2, x1, x2
    5920:	54000726 	b.vs	5a04 <e173+0x114>
    5924:	910023e1 	add	x1, sp, #0x8
    5928:	52800000 	mov	w0, #0x0                   	// #0
    592c:	a9008be3 	stp	x3, x2, [sp, #8]
    5930:	97fffdd5 	bl	5084 <fwp_data.part.0.constprop.0>
    5934:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5938:	91174063 	add	x3, x3, #0x5d0
    593c:	aa0003f3 	mov	x19, x0
    5940:	f949d861 	ldr	x1, [x3, #5040]
    5944:	f949ec60 	ldr	x0, [x3, #5080]
    5948:	cb010261 	sub	x1, x19, x1
    594c:	eb00403f 	cmp	x1, x0, lsl #16
    5950:	54000322 	b.cs	59b4 <e173+0xc4>  // b.hs, b.nlast
    5954:	d350fc22 	lsr	x2, x1, #16
    5958:	f949fc63 	ldr	x3, [x3, #5112]
    595c:	8b020842 	add	x2, x2, x2, lsl #2
    5960:	d37df042 	lsl	x2, x2, #3
    5964:	8b020060 	add	x0, x3, x2
    5968:	f9401014 	ldr	x20, [x0, #32]
    596c:	b4000254 	cbz	x20, 59b4 <e173+0xc4>
    5970:	38626862 	ldrb	w2, [x3, x2]
    5974:	7100085f 	cmp	w2, #0x2
    5978:	540003a0 	b.eq	59ec <e173+0xfc>  // b.none
    597c:	7100045f 	cmp	w2, #0x1
    5980:	540001a1 	b.ne	59b4 <e173+0xc4>  // b.any
    5984:	29430002 	ldp	w2, w0, [x0, #24]
    5988:	92403c21 	and	x1, x1, #0xffff
    598c:	9b027c21 	mul	x1, x1, x2
    5990:	d360fc21 	lsr	x1, x1, #32
    5994:	eb00003f 	cmp	x1, x0
    5998:	540000e2 	b.cs	59b4 <e173+0xc4>  // b.hs, b.nlast
    599c:	8b010294 	add	x20, x20, x1
    59a0:	39400280 	ldrb	w0, [x20]
    59a4:	7103fc1f 	cmp	w0, #0xff
    59a8:	54000280 	b.eq	59f8 <e173+0x108>  // b.none
    59ac:	52800020 	mov	w0, #0x1                   	// #1
    59b0:	39000280 	strb	w0, [x20]
    59b4:	aa1303e0 	mov	x0, x19
    59b8:	97ffff1a 	bl	5620 <fwp_rc_share>
    59bc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59c0:	f947f400 	ldr	x0, [x0, #4072]
    59c4:	f9400fe2 	ldr	x2, [sp, #24]
    59c8:	f9400001 	ldr	x1, [x0]
    59cc:	eb010042 	subs	x2, x2, x1
    59d0:	d2800001 	mov	x1, #0x0                   	// #0
    59d4:	540001a1 	b.ne	5a08 <e173+0x118>  // b.any
    59d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59dc:	aa1303e0 	mov	x0, x19
    59e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    59e4:	910103ff 	add	sp, sp, #0x40
    59e8:	d65f03c0 	ret
    59ec:	72003c3f 	tst	w1, #0xffff
    59f0:	54fffe21 	b.ne	59b4 <e173+0xc4>  // b.any
    59f4:	17ffffeb 	b	59a0 <e173+0xb0>
    59f8:	aa1403e0 	mov	x0, x20
    59fc:	97fffb9d 	bl	4870 <fwp_rc_forget_slot>
    5a00:	17ffffeb 	b	59ac <e173+0xbc>
    5a04:	97fff43f 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5a08:	97fff3c2 	bl	2910 <__stack_chk_fail@plt>
    5a0c:	d503201f 	nop

0000000000005a10 <fwp_drop1>:
    5a10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a14:	910003fd 	mov	x29, sp
    5a18:	a90153f3 	stp	x19, x20, [sp, #16]
    5a1c:	f90013f5 	str	x21, [sp, #32]
    5a20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5a24:	911742b4 	add	x20, x21, #0x5d0
    5a28:	f949da81 	ldr	x1, [x20, #5040]
    5a2c:	f949ee82 	ldr	x2, [x20, #5080]
    5a30:	cb010001 	sub	x1, x0, x1
    5a34:	eb02403f 	cmp	x1, x2, lsl #16
    5a38:	54000382 	b.cs	5aa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a3c:	d350fc22 	lsr	x2, x1, #16
    5a40:	f949fe84 	ldr	x4, [x20, #5112]
    5a44:	8b020842 	add	x2, x2, x2, lsl #2
    5a48:	d37df042 	lsl	x2, x2, #3
    5a4c:	8b020083 	add	x3, x4, x2
    5a50:	f9401073 	ldr	x19, [x3, #32]
    5a54:	b40002b3 	cbz	x19, 5aa8 <fwp_drop1+0x98>
    5a58:	38626882 	ldrb	w2, [x4, x2]
    5a5c:	7100085f 	cmp	w2, #0x2
    5a60:	540002c0 	b.eq	5ab8 <fwp_drop1+0xa8>  // b.none
    5a64:	7100045f 	cmp	w2, #0x1
    5a68:	54000201 	b.ne	5aa8 <fwp_drop1+0x98>  // b.any
    5a6c:	29430864 	ldp	w4, w2, [x3, #24]
    5a70:	92403c21 	and	x1, x1, #0xffff
    5a74:	9b047c21 	mul	x1, x1, x4
    5a78:	d360fc21 	lsr	x1, x1, #32
    5a7c:	eb02003f 	cmp	x1, x2
    5a80:	54000142 	b.cs	5aa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a84:	8b010273 	add	x19, x19, x1
    5a88:	39400261 	ldrb	w1, [x19]
    5a8c:	340000e1 	cbz	w1, 5aa8 <fwp_drop1+0x98>
    5a90:	7100043f 	cmp	w1, #0x1
    5a94:	540001e0 	b.eq	5ad0 <fwp_drop1+0xc0>  // b.none
    5a98:	7103fc3f 	cmp	w1, #0xff
    5a9c:	540002e0 	b.eq	5af8 <fwp_drop1+0xe8>  // b.none
    5aa0:	51000421 	sub	w1, w1, #0x1
    5aa4:	39000261 	strb	w1, [x19]
    5aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5aac:	f94013f5 	ldr	x21, [sp, #32]
    5ab0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ab4:	d65f03c0 	ret
    5ab8:	72003c3f 	tst	w1, #0xffff
    5abc:	54fffe60 	b.eq	5a88 <fwp_drop1+0x78>  // b.none
    5ac0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ac4:	f94013f5 	ldr	x21, [sp, #32]
    5ac8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5acc:	d65f03c0 	ret
    5ad0:	f9400813 	ldr	x19, [x0, #16]
    5ad4:	97fffef8 	bl	56b4 <fwp_rc_free_arr>
    5ad8:	911742a0 	add	x0, x21, #0x5d0
    5adc:	f949d801 	ldr	x1, [x0, #5040]
    5ae0:	f949ec00 	ldr	x0, [x0, #5080]
    5ae4:	cb010261 	sub	x1, x19, x1
    5ae8:	eb00403f 	cmp	x1, x0, lsl #16
    5aec:	54fffde2 	b.cs	5aa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5af0:	aa1303e0 	mov	x0, x19
    5af4:	17ffffd2 	b	5a3c <fwp_drop1+0x2c>
    5af8:	ca534660 	eor	x0, x19, x19, lsr #17
    5afc:	911742b5 	add	x21, x21, #0x5d0
    5b00:	ca402400 	eor	x0, x0, x0, lsr #9
    5b04:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b08:	f94a2400 	ldr	x0, [x0, #5192]
    5b0c:	b5000080 	cbnz	x0, 5b1c <fwp_drop1+0x10c>
    5b10:	14000010 	b	5b50 <fwp_drop1+0x140>
    5b14:	f9400800 	ldr	x0, [x0, #16]
    5b18:	b40001c0 	cbz	x0, 5b50 <fwp_drop1+0x140>
    5b1c:	f9400001 	ldr	x1, [x0]
    5b20:	eb13003f 	cmp	x1, x19
    5b24:	54ffff81 	b.ne	5b14 <fwp_drop1+0x104>  // b.any
    5b28:	f9400401 	ldr	x1, [x0, #8]
    5b2c:	d1000421 	sub	x1, x1, #0x1
    5b30:	f9000401 	str	x1, [x0, #8]
    5b34:	f103f83f 	cmp	x1, #0xfe
    5b38:	54fffb81 	b.ne	5aa8 <fwp_drop1+0x98>  // b.any
    5b3c:	aa1303e0 	mov	x0, x19
    5b40:	97fffb4c 	bl	4870 <fwp_rc_forget_slot>
    5b44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b48:	39000260 	strb	w0, [x19]
    5b4c:	17ffffd7 	b	5aa8 <fwp_drop1+0x98>
    5b50:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    5b54:	91370000 	add	x0, x0, #0xdc0
    5b58:	97fff74a 	bl	3880 <fwp_trap>
    5b5c:	d503201f 	nop

0000000000005b60 <fwp_drop0>:
    5b60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b64:	910003fd 	mov	x29, sp
    5b68:	a90153f3 	stp	x19, x20, [sp, #16]
    5b6c:	f90013f5 	str	x21, [sp, #32]
    5b70:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5b74:	911742b4 	add	x20, x21, #0x5d0
    5b78:	f949da81 	ldr	x1, [x20, #5040]
    5b7c:	f949ee82 	ldr	x2, [x20, #5080]
    5b80:	cb010001 	sub	x1, x0, x1
    5b84:	eb02403f 	cmp	x1, x2, lsl #16
    5b88:	54000382 	b.cs	5bf8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b8c:	d350fc22 	lsr	x2, x1, #16
    5b90:	f949fe84 	ldr	x4, [x20, #5112]
    5b94:	8b020842 	add	x2, x2, x2, lsl #2
    5b98:	d37df042 	lsl	x2, x2, #3
    5b9c:	8b020083 	add	x3, x4, x2
    5ba0:	f9401073 	ldr	x19, [x3, #32]
    5ba4:	b40002b3 	cbz	x19, 5bf8 <fwp_drop0+0x98>
    5ba8:	38626882 	ldrb	w2, [x4, x2]
    5bac:	7100085f 	cmp	w2, #0x2
    5bb0:	540002c0 	b.eq	5c08 <fwp_drop0+0xa8>  // b.none
    5bb4:	7100045f 	cmp	w2, #0x1
    5bb8:	54000201 	b.ne	5bf8 <fwp_drop0+0x98>  // b.any
    5bbc:	29430864 	ldp	w4, w2, [x3, #24]
    5bc0:	92403c21 	and	x1, x1, #0xffff
    5bc4:	9b047c21 	mul	x1, x1, x4
    5bc8:	d360fc21 	lsr	x1, x1, #32
    5bcc:	eb02003f 	cmp	x1, x2
    5bd0:	54000142 	b.cs	5bf8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bd4:	8b010273 	add	x19, x19, x1
    5bd8:	39400261 	ldrb	w1, [x19]
    5bdc:	340000e1 	cbz	w1, 5bf8 <fwp_drop0+0x98>
    5be0:	7100043f 	cmp	w1, #0x1
    5be4:	540001e0 	b.eq	5c20 <fwp_drop0+0xc0>  // b.none
    5be8:	7103fc3f 	cmp	w1, #0xff
    5bec:	540002e0 	b.eq	5c48 <fwp_drop0+0xe8>  // b.none
    5bf0:	51000421 	sub	w1, w1, #0x1
    5bf4:	39000261 	strb	w1, [x19]
    5bf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bfc:	f94013f5 	ldr	x21, [sp, #32]
    5c00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c04:	d65f03c0 	ret
    5c08:	72003c3f 	tst	w1, #0xffff
    5c0c:	54fffe60 	b.eq	5bd8 <fwp_drop0+0x78>  // b.none
    5c10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c14:	f94013f5 	ldr	x21, [sp, #32]
    5c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c1c:	d65f03c0 	ret
    5c20:	f9400813 	ldr	x19, [x0, #16]
    5c24:	97fffea4 	bl	56b4 <fwp_rc_free_arr>
    5c28:	911742a0 	add	x0, x21, #0x5d0
    5c2c:	f949d801 	ldr	x1, [x0, #5040]
    5c30:	f949ec00 	ldr	x0, [x0, #5080]
    5c34:	cb010261 	sub	x1, x19, x1
    5c38:	eb00403f 	cmp	x1, x0, lsl #16
    5c3c:	54fffde2 	b.cs	5bf8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c40:	aa1303e0 	mov	x0, x19
    5c44:	17ffffd2 	b	5b8c <fwp_drop0+0x2c>
    5c48:	ca534660 	eor	x0, x19, x19, lsr #17
    5c4c:	911742b5 	add	x21, x21, #0x5d0
    5c50:	ca402400 	eor	x0, x0, x0, lsr #9
    5c54:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5c58:	f94a2400 	ldr	x0, [x0, #5192]
    5c5c:	b5000080 	cbnz	x0, 5c6c <fwp_drop0+0x10c>
    5c60:	14000010 	b	5ca0 <fwp_drop0+0x140>
    5c64:	f9400800 	ldr	x0, [x0, #16]
    5c68:	b40001c0 	cbz	x0, 5ca0 <fwp_drop0+0x140>
    5c6c:	f9400001 	ldr	x1, [x0]
    5c70:	eb13003f 	cmp	x1, x19
    5c74:	54ffff81 	b.ne	5c64 <fwp_drop0+0x104>  // b.any
    5c78:	f9400401 	ldr	x1, [x0, #8]
    5c7c:	d1000421 	sub	x1, x1, #0x1
    5c80:	f9000401 	str	x1, [x0, #8]
    5c84:	f103f83f 	cmp	x1, #0xfe
    5c88:	54fffb81 	b.ne	5bf8 <fwp_drop0+0x98>  // b.any
    5c8c:	aa1303e0 	mov	x0, x19
    5c90:	97fffaf8 	bl	4870 <fwp_rc_forget_slot>
    5c94:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c98:	39000260 	strb	w0, [x19]
    5c9c:	17ffffd7 	b	5bf8 <fwp_drop0+0x98>
    5ca0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    5ca4:	91370000 	add	x0, x0, #0xdc0
    5ca8:	97fff6f6 	bl	3880 <fwp_trap>
    5cac:	d503201f 	nop

0000000000005cb0 <fwp_closure_drop>:
    5cb0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc10>
    5cb4:	911740a4 	add	x4, x5, #0x5d0
    5cb8:	aa0003e1 	mov	x1, x0
    5cbc:	f949d882 	ldr	x2, [x4, #5040]
    5cc0:	f949ec80 	ldr	x0, [x4, #5080]
    5cc4:	cb020022 	sub	x2, x1, x2
    5cc8:	eb00405f 	cmp	x2, x0, lsl #16
    5ccc:	54000662 	b.cs	5d98 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5cd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5cd4:	d350fc43 	lsr	x3, x2, #16
    5cd8:	910003fd 	mov	x29, sp
    5cdc:	8b030863 	add	x3, x3, x3, lsl #2
    5ce0:	f949fc84 	ldr	x4, [x4, #5112]
    5ce4:	d37df063 	lsl	x3, x3, #3
    5ce8:	f9000bf3 	str	x19, [sp, #16]
    5cec:	8b030080 	add	x0, x4, x3
    5cf0:	f9401013 	ldr	x19, [x0, #32]
    5cf4:	b40002b3 	cbz	x19, 5d48 <fwp_closure_drop+0x98>
    5cf8:	38636883 	ldrb	w3, [x4, x3]
    5cfc:	7100087f 	cmp	w3, #0x2
    5d00:	54000420 	b.eq	5d84 <fwp_closure_drop+0xd4>  // b.none
    5d04:	7100047f 	cmp	w3, #0x1
    5d08:	54000201 	b.ne	5d48 <fwp_closure_drop+0x98>  // b.any
    5d0c:	29430003 	ldp	w3, w0, [x0, #24]
    5d10:	92403c42 	and	x2, x2, #0xffff
    5d14:	9b037c42 	mul	x2, x2, x3
    5d18:	d360fc42 	lsr	x2, x2, #32
    5d1c:	eb00005f 	cmp	x2, x0
    5d20:	54000142 	b.cs	5d48 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5d24:	8b020273 	add	x19, x19, x2
    5d28:	39400260 	ldrb	w0, [x19]
    5d2c:	340000e0 	cbz	w0, 5d48 <fwp_closure_drop+0x98>
    5d30:	7100041f 	cmp	w0, #0x1
    5d34:	54000100 	b.eq	5d54 <fwp_closure_drop+0xa4>  // b.none
    5d38:	7103fc1f 	cmp	w0, #0xff
    5d3c:	54000300 	b.eq	5d9c <fwp_closure_drop+0xec>  // b.none
    5d40:	51000400 	sub	w0, w0, #0x1
    5d44:	39000260 	strb	w0, [x19]
    5d48:	f9400bf3 	ldr	x19, [sp, #16]
    5d4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d50:	d65f03c0 	ret
    5d54:	d53bd040 	mrs	x0, tpidr_el0
    5d58:	91400000 	add	x0, x0, #0x0, lsl #12
    5d5c:	91004000 	add	x0, x0, #0x10
    5d60:	f9400000 	ldr	x0, [x0]
    5d64:	b4000080 	cbz	x0, 5d74 <fwp_closure_drop+0xc4>
    5d68:	f9400bf3 	ldr	x19, [sp, #16]
    5d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d70:	17fff6dd 	b	38e4 <fwp_closure_drop_push>
    5d74:	f9400bf3 	ldr	x19, [sp, #16]
    5d78:	aa0103e0 	mov	x0, x1
    5d7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d80:	17fff748 	b	3aa0 <fwp_closure_drop.part.0>
    5d84:	72003c5f 	tst	w2, #0xffff
    5d88:	54fffd00 	b.eq	5d28 <fwp_closure_drop+0x78>  // b.none
    5d8c:	f9400bf3 	ldr	x19, [sp, #16]
    5d90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d94:	d65f03c0 	ret
    5d98:	d65f03c0 	ret
    5d9c:	ca534660 	eor	x0, x19, x19, lsr #17
    5da0:	911740a5 	add	x5, x5, #0x5d0
    5da4:	ca402400 	eor	x0, x0, x0, lsr #9
    5da8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5dac:	f94a2400 	ldr	x0, [x0, #5192]
    5db0:	b5000080 	cbnz	x0, 5dc0 <fwp_closure_drop+0x110>
    5db4:	14000010 	b	5df4 <fwp_closure_drop+0x144>
    5db8:	f9400800 	ldr	x0, [x0, #16]
    5dbc:	b40001c0 	cbz	x0, 5df4 <fwp_closure_drop+0x144>
    5dc0:	f9400001 	ldr	x1, [x0]
    5dc4:	eb13003f 	cmp	x1, x19
    5dc8:	54ffff81 	b.ne	5db8 <fwp_closure_drop+0x108>  // b.any
    5dcc:	f9400401 	ldr	x1, [x0, #8]
    5dd0:	d1000421 	sub	x1, x1, #0x1
    5dd4:	f9000401 	str	x1, [x0, #8]
    5dd8:	f103f83f 	cmp	x1, #0xfe
    5ddc:	54fffb61 	b.ne	5d48 <fwp_closure_drop+0x98>  // b.any
    5de0:	aa1303e0 	mov	x0, x19
    5de4:	97fffaa3 	bl	4870 <fwp_rc_forget_slot>
    5de8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5dec:	39000260 	strb	w0, [x19]
    5df0:	17ffffd6 	b	5d48 <fwp_closure_drop+0x98>
    5df4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    5df8:	91370000 	add	x0, x0, #0xdc0
    5dfc:	97fff6a1 	bl	3880 <fwp_trap>

0000000000005e00 <fwp_owned_tape_release>:
    5e00:	b4000940 	cbz	x0, 5f28 <fwp_owned_tape_release+0x128>
    5e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e08:	910003fd 	mov	x29, sp
    5e0c:	a90153f3 	stp	x19, x20, [sp, #16]
    5e10:	aa0003f3 	mov	x19, x0
    5e14:	f9400000 	ldr	x0, [x0]
    5e18:	b4000060 	cbz	x0, 5e24 <fwp_owned_tape_release+0x24>
    5e1c:	f9400661 	ldr	x1, [x19, #8]
    5e20:	f9000401 	str	x1, [x0, #8]
    5e24:	f9400661 	ldr	x1, [x19, #8]
    5e28:	b4000041 	cbz	x1, 5e30 <fwp_owned_tape_release+0x30>
    5e2c:	f9000020 	str	x0, [x1]
    5e30:	f9400a60 	ldr	x0, [x19, #16]
    5e34:	f9403401 	ldr	x1, [x0, #104]
    5e38:	b40005c1 	cbz	x1, 5ef0 <fwp_owned_tape_release+0xf0>
    5e3c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5e40:	eb00005f 	cmp	x2, x0
    5e44:	540002ed 	b.le	5ea0 <fwp_owned_tape_release+0xa0>
    5e48:	d2800014 	mov	x20, #0x0                   	// #0
    5e4c:	f90013f5 	str	x21, [sp, #32]
    5e50:	d2800015 	mov	x21, #0x0                   	// #0
    5e54:	d503201f 	nop
    5e58:	f9402260 	ldr	x0, [x19, #64]
    5e5c:	910006b5 	add	x21, x21, #0x1
    5e60:	f8746800 	ldr	x0, [x0, x20]
    5e64:	d63f0020 	blr	x1
    5e68:	f9402260 	ldr	x0, [x19, #64]
    5e6c:	f9400a61 	ldr	x1, [x19, #16]
    5e70:	8b140000 	add	x0, x0, x20
    5e74:	91004294 	add	x20, x20, #0x10
    5e78:	f9400400 	ldr	x0, [x0, #8]
    5e7c:	f9403421 	ldr	x1, [x1, #104]
    5e80:	d63f0020 	blr	x1
    5e84:	a9450261 	ldp	x1, x0, [x19, #80]
    5e88:	cb010000 	sub	x0, x0, x1
    5e8c:	eb15001f 	cmp	x0, x21
    5e90:	f9400a60 	ldr	x0, [x19, #16]
    5e94:	f9403401 	ldr	x1, [x0, #104]
    5e98:	54fffe0c 	b.gt	5e58 <fwp_owned_tape_release+0x58>
    5e9c:	f94013f5 	ldr	x21, [sp, #32]
    5ea0:	f9403663 	ldr	x3, [x19, #104]
    5ea4:	f9401262 	ldr	x2, [x19, #32]
    5ea8:	f100007f 	cmp	x3, #0x0
    5eac:	540001ed 	b.le	5ee8 <fwp_owned_tape_release+0xe8>
    5eb0:	d2800014 	mov	x20, #0x0                   	// #0
    5eb4:	d503201f 	nop
    5eb8:	f9402660 	ldr	x0, [x19, #72]
    5ebc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5ec0:	eb02001f 	cmp	x0, x2
    5ec4:	540000c0 	b.eq	5edc <fwp_owned_tape_release+0xdc>  // b.none
    5ec8:	d63f0020 	blr	x1
    5ecc:	f9400a60 	ldr	x0, [x19, #16]
    5ed0:	f9401262 	ldr	x2, [x19, #32]
    5ed4:	f9403663 	ldr	x3, [x19, #104]
    5ed8:	f9403401 	ldr	x1, [x0, #104]
    5edc:	91000694 	add	x20, x20, #0x1
    5ee0:	eb14007f 	cmp	x3, x20
    5ee4:	54fffeac 	b.gt	5eb8 <fwp_owned_tape_release+0xb8>
    5ee8:	aa0203e0 	mov	x0, x2
    5eec:	d63f0020 	blr	x1
    5ef0:	f9401660 	ldr	x0, [x19, #40]
    5ef4:	97ffff6f 	bl	5cb0 <fwp_closure_drop>
    5ef8:	f9401a60 	ldr	x0, [x19, #48]
    5efc:	97ffff6d 	bl	5cb0 <fwp_closure_drop>
    5f00:	f9401e60 	ldr	x0, [x19, #56]
    5f04:	97ffff6b 	bl	5cb0 <fwp_closure_drop>
    5f08:	f9402260 	ldr	x0, [x19, #64]
    5f0c:	97fffaf9 	bl	4af0 <fwp_mem_free>
    5f10:	f9402660 	ldr	x0, [x19, #72]
    5f14:	97fffaf7 	bl	4af0 <fwp_mem_free>
    5f18:	aa1303e0 	mov	x0, x19
    5f1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f24:	17fffaf3 	b	4af0 <fwp_mem_free>
    5f28:	d65f03c0 	ret
    5f2c:	d503201f 	nop

0000000000005f30 <fwp_tape_finish>:
    5f30:	d10203ff 	sub	sp, sp, #0x80
    5f34:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5f38:	f947f421 	ldr	x1, [x1, #4072]
    5f3c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f40:	910103fd 	add	x29, sp, #0x40
    5f44:	a90553f3 	stp	x19, x20, [sp, #80]
    5f48:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f4c:	a90763f7 	stp	x23, x24, [sp, #112]
    5f50:	f00000d8 	adrp	x24, 20000 <__data_start>
    5f54:	9101c316 	add	x22, x24, #0x70
    5f58:	f9400022 	ldr	x2, [x1]
    5f5c:	f9001fe2 	str	x2, [sp, #56]
    5f60:	d2800002 	mov	x2, #0x0                   	// #0
    5f64:	910262c0 	add	x0, x22, #0x98
    5f68:	97fff566 	bl	3500 <fwp_tape_buffers_dispose>
    5f6c:	f9006adf 	str	xzr, [x22, #208]
    5f70:	f9404ac0 	ldr	x0, [x22, #144]
    5f74:	f100001f 	cmp	x0, #0x0
    5f78:	5400030d 	b.le	5fd8 <fwp_tape_finish+0xa8>
    5f7c:	910003f7 	mov	x23, sp
    5f80:	d2800015 	mov	x21, #0x0                   	// #0
    5f84:	d2800014 	mov	x20, #0x0                   	// #0
    5f88:	f94002d3 	ldr	x19, [x22]
    5f8c:	91000694 	add	x20, x20, #0x1
    5f90:	8b150273 	add	x19, x19, x21
    5f94:	9101a2b5 	add	x21, x21, #0x68
    5f98:	aa1303e0 	mov	x0, x19
    5f9c:	97fff41d 	bl	3010 <fwp_tape_unlink_scope>
    5fa0:	aa1703e0 	mov	x0, x23
    5fa4:	f9401261 	ldr	x1, [x19, #32]
    5fa8:	f90003e1 	str	x1, [sp]
    5fac:	f9401a62 	ldr	x2, [x19, #48]
    5fb0:	f9000be2 	str	x2, [sp, #16]
    5fb4:	f9402261 	ldr	x1, [x19, #64]
    5fb8:	f90013e1 	str	x1, [sp, #32]
    5fbc:	97fff551 	bl	3500 <fwp_tape_buffers_dispose>
    5fc0:	f9403260 	ldr	x0, [x19, #96]
    5fc4:	97ffff8f 	bl	5e00 <fwp_owned_tape_release>
    5fc8:	f900327f 	str	xzr, [x19, #96]
    5fcc:	f9404ac0 	ldr	x0, [x22, #144]
    5fd0:	eb14001f 	cmp	x0, x20
    5fd4:	54fffdac 	b.gt	5f88 <fwp_tape_finish+0x58>
    5fd8:	f9403b00 	ldr	x0, [x24, #112]
    5fdc:	9101c313 	add	x19, x24, #0x70
    5fe0:	97fff27c 	bl	29d0 <free@plt>
    5fe4:	f9003b1f 	str	xzr, [x24, #112]
    5fe8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5fec:	f947f400 	ldr	x0, [x0, #4072]
    5ff0:	f9004a7f 	str	xzr, [x19, #144]
    5ff4:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    5ff8:	f9401fe2 	ldr	x2, [sp, #56]
    5ffc:	f9400001 	ldr	x1, [x0]
    6000:	eb010042 	subs	x2, x2, x1
    6004:	d2800001 	mov	x1, #0x0                   	// #0
    6008:	540000e1 	b.ne	6024 <fwp_tape_finish+0xf4>  // b.any
    600c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6010:	a94553f3 	ldp	x19, x20, [sp, #80]
    6014:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6018:	a94763f7 	ldp	x23, x24, [sp, #112]
    601c:	910203ff 	add	sp, sp, #0x80
    6020:	d65f03c0 	ret
    6024:	97fff23b 	bl	2910 <__stack_chk_fail@plt>
    6028:	d503201f 	nop
    602c:	d503201f 	nop

0000000000006030 <fwp_tape_scope_release>:
    6030:	d10243ff 	sub	sp, sp, #0x90
    6034:	a9047bfd 	stp	x29, x30, [sp, #64]
    6038:	910103fd 	add	x29, sp, #0x40
    603c:	a90553f3 	stp	x19, x20, [sp, #80]
    6040:	aa0003f4 	mov	x20, x0
    6044:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6048:	f947f400 	ldr	x0, [x0, #4072]
    604c:	b9400285 	ldr	w5, [x20]
    6050:	f9400001 	ldr	x1, [x0]
    6054:	f9001fe1 	str	x1, [sp, #56]
    6058:	d2800001 	mov	x1, #0x0                   	// #0
    605c:	37f806c5 	tbnz	w5, #31, 6134 <fwp_tape_scope_release+0x104>
    6060:	a90763f7 	stp	x23, x24, [sp, #112]
    6064:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6068:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    606c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6070:	d00000d3 	adrp	x19, 20000 <__data_start>
    6074:	910003f7 	mov	x23, sp
    6078:	9101c273 	add	x19, x19, #0x70
    607c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6080:	a9065bf5 	stp	x21, x22, [sp, #96]
    6084:	52800d16 	mov	w22, #0x68                  	// #104
    6088:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    608c:	f90043f9 	str	x25, [sp, #128]
    6090:	14000006 	b	60a8 <fwp_tape_scope_release+0x78>
    6094:	97fff51b 	bl	3500 <fwp_tape_buffers_dispose>
    6098:	aa1903e0 	mov	x0, x25
    609c:	97ffff59 	bl	5e00 <fwp_owned_tape_release>
    60a0:	b9400285 	ldr	w5, [x20]
    60a4:	37f80425 	tbnz	w5, #31, 6128 <fwp_tape_scope_release+0xf8>
    60a8:	f9400266 	ldr	x6, [x19]
    60ac:	9b367ca5 	smull	x5, w5, w22
    60b0:	8b0500c0 	add	x0, x6, x5
    60b4:	97fff3d7 	bl	3010 <fwp_tape_unlink_scope>
    60b8:	ad410001 	ldp	q1, q0, [x0, #32]
    60bc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    60c0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    60c4:	f9400c03 	ldr	x3, [x0, #24]
    60c8:	ad0003e1 	stp	q1, q0, [sp]
    60cc:	b86568c1 	ldr	w1, [x6, x5]
    60d0:	a9440804 	ldp	x4, x2, [x0, #64]
    60d4:	b900041f 	str	wzr, [x0, #4]
    60d8:	f9403019 	ldr	x25, [x0, #96]
    60dc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    60e0:	f9000c1f 	str	xzr, [x0, #24]
    60e4:	a9020fe4 	stp	x4, x3, [sp, #32]
    60e8:	f9001be2 	str	x2, [sp, #48]
    60ec:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    60f0:	f900301f 	str	xzr, [x0, #96]
    60f4:	6b15003f 	cmp	w1, w21
    60f8:	540000e8 	b.hi	6114 <fwp_tape_scope_release+0xe4>  // b.pmore
    60fc:	9343fca5 	asr	x5, x5, #3
    6100:	f9407660 	ldr	x0, [x19, #232]
    6104:	9b187ca5 	mul	x5, x5, x24
    6108:	eb0000bf 	cmp	x5, x0
    610c:	5400004a 	b.ge	6114 <fwp_tape_scope_release+0xe4>  // b.tcont
    6110:	f9007665 	str	x5, [x19, #232]
    6114:	aa1703e0 	mov	x0, x23
    6118:	b5fffbf9 	cbnz	x25, 6094 <fwp_tape_scope_release+0x64>
    611c:	97fff8b9 	bl	4400 <fwp_tape_buffers_release>
    6120:	b9400285 	ldr	w5, [x20]
    6124:	36fffc25 	tbz	w5, #31, 60a8 <fwp_tape_scope_release+0x78>
    6128:	a9465bf5 	ldp	x21, x22, [sp, #96]
    612c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6130:	f94043f9 	ldr	x25, [sp, #128]
    6134:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6138:	f947f400 	ldr	x0, [x0, #4072]
    613c:	f9401fe2 	ldr	x2, [sp, #56]
    6140:	f9400001 	ldr	x1, [x0]
    6144:	eb010042 	subs	x2, x2, x1
    6148:	d2800001 	mov	x1, #0x0                   	// #0
    614c:	540000a1 	b.ne	6160 <fwp_tape_scope_release+0x130>  // b.any
    6150:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6154:	a94553f3 	ldp	x19, x20, [sp, #80]
    6158:	910243ff 	add	sp, sp, #0x90
    615c:	d65f03c0 	ret
    6160:	a9065bf5 	stp	x21, x22, [sp, #96]
    6164:	a90763f7 	stp	x23, x24, [sp, #112]
    6168:	f90043f9 	str	x25, [sp, #128]
    616c:	97fff1e9 	bl	2910 <__stack_chk_fail@plt>

0000000000006170 <fwp_drop4>:
    6170:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6174:	910003fd 	mov	x29, sp
    6178:	a9025bf5 	stp	x21, x22, [sp, #32]
    617c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    6180:	911742d5 	add	x21, x22, #0x5d0
    6184:	a90153f3 	stp	x19, x20, [sp, #16]
    6188:	aa0003f3 	mov	x19, x0
    618c:	f949daa1 	ldr	x1, [x21, #5040]
    6190:	f949eea0 	ldr	x0, [x21, #5080]
    6194:	cb010261 	sub	x1, x19, x1
    6198:	eb00403f 	cmp	x1, x0, lsl #16
    619c:	54000382 	b.cs	620c <fwp_drop4+0x9c>  // b.hs, b.nlast
    61a0:	d350fc22 	lsr	x2, x1, #16
    61a4:	f949fea3 	ldr	x3, [x21, #5112]
    61a8:	8b020842 	add	x2, x2, x2, lsl #2
    61ac:	d37df042 	lsl	x2, x2, #3
    61b0:	8b020060 	add	x0, x3, x2
    61b4:	f9401014 	ldr	x20, [x0, #32]
    61b8:	b40002b4 	cbz	x20, 620c <fwp_drop4+0x9c>
    61bc:	38626862 	ldrb	w2, [x3, x2]
    61c0:	7100085f 	cmp	w2, #0x2
    61c4:	540002c0 	b.eq	621c <fwp_drop4+0xac>  // b.none
    61c8:	7100045f 	cmp	w2, #0x1
    61cc:	54000201 	b.ne	620c <fwp_drop4+0x9c>  // b.any
    61d0:	29430002 	ldp	w2, w0, [x0, #24]
    61d4:	92403c21 	and	x1, x1, #0xffff
    61d8:	9b027c21 	mul	x1, x1, x2
    61dc:	d360fc21 	lsr	x1, x1, #32
    61e0:	eb00003f 	cmp	x1, x0
    61e4:	54000142 	b.cs	620c <fwp_drop4+0x9c>  // b.hs, b.nlast
    61e8:	8b010294 	add	x20, x20, x1
    61ec:	39400280 	ldrb	w0, [x20]
    61f0:	340000e0 	cbz	w0, 620c <fwp_drop4+0x9c>
    61f4:	7100041f 	cmp	w0, #0x1
    61f8:	540001e0 	b.eq	6234 <fwp_drop4+0xc4>  // b.none
    61fc:	7103fc1f 	cmp	w0, #0xff
    6200:	540007c0 	b.eq	62f8 <fwp_drop4+0x188>  // b.none
    6204:	51000400 	sub	w0, w0, #0x1
    6208:	39000280 	strb	w0, [x20]
    620c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6210:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6214:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6218:	d65f03c0 	ret
    621c:	72003c3f 	tst	w1, #0xffff
    6220:	54fffe60 	b.eq	61ec <fwp_drop4+0x7c>  // b.none
    6224:	a94153f3 	ldp	x19, x20, [sp, #16]
    6228:	a9425bf5 	ldp	x21, x22, [sp, #32]
    622c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6230:	d65f03c0 	ret
    6234:	911742c2 	add	x2, x22, #0x5d0
    6238:	f9400660 	ldr	x0, [x19, #8]
    623c:	f949d841 	ldr	x1, [x2, #5040]
    6240:	f949ec42 	ldr	x2, [x2, #5080]
    6244:	cb010001 	sub	x1, x0, x1
    6248:	eb02403f 	cmp	x1, x2, lsl #16
    624c:	54000362 	b.cs	62b8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6250:	d350fc22 	lsr	x2, x1, #16
    6254:	8b020842 	add	x2, x2, x2, lsl #2
    6258:	d37df042 	lsl	x2, x2, #3
    625c:	8b020064 	add	x4, x3, x2
    6260:	f9401094 	ldr	x20, [x4, #32]
    6264:	b40002b4 	cbz	x20, 62b8 <fwp_drop4+0x148>
    6268:	38626862 	ldrb	w2, [x3, x2]
    626c:	7100085f 	cmp	w2, #0x2
    6270:	540003e0 	b.eq	62ec <fwp_drop4+0x17c>  // b.none
    6274:	7100045f 	cmp	w2, #0x1
    6278:	54000201 	b.ne	62b8 <fwp_drop4+0x148>  // b.any
    627c:	29430883 	ldp	w3, w2, [x4, #24]
    6280:	92403c21 	and	x1, x1, #0xffff
    6284:	9b037c21 	mul	x1, x1, x3
    6288:	d360fc21 	lsr	x1, x1, #32
    628c:	eb02003f 	cmp	x1, x2
    6290:	54000142 	b.cs	62b8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6294:	8b010294 	add	x20, x20, x1
    6298:	39400281 	ldrb	w1, [x20]
    629c:	340000e1 	cbz	w1, 62b8 <fwp_drop4+0x148>
    62a0:	7100043f 	cmp	w1, #0x1
    62a4:	54000200 	b.eq	62e4 <fwp_drop4+0x174>  // b.none
    62a8:	7103fc3f 	cmp	w1, #0xff
    62ac:	54000580 	b.eq	635c <fwp_drop4+0x1ec>  // b.none
    62b0:	51000421 	sub	w1, w1, #0x1
    62b4:	39000281 	strb	w1, [x20]
    62b8:	f9400a74 	ldr	x20, [x19, #16]
    62bc:	aa1303e0 	mov	x0, x19
    62c0:	97fffcfd 	bl	56b4 <fwp_rc_free_arr>
    62c4:	911742c0 	add	x0, x22, #0x5d0
    62c8:	f949d801 	ldr	x1, [x0, #5040]
    62cc:	f949ec00 	ldr	x0, [x0, #5080]
    62d0:	cb010281 	sub	x1, x20, x1
    62d4:	eb00403f 	cmp	x1, x0, lsl #16
    62d8:	54fff9a2 	b.cs	620c <fwp_drop4+0x9c>  // b.hs, b.nlast
    62dc:	aa1403f3 	mov	x19, x20
    62e0:	17ffffb0 	b	61a0 <fwp_drop4+0x30>
    62e4:	97fffcf4 	bl	56b4 <fwp_rc_free_arr>
    62e8:	17fffff4 	b	62b8 <fwp_drop4+0x148>
    62ec:	72003c3f 	tst	w1, #0xffff
    62f0:	54fffe41 	b.ne	62b8 <fwp_drop4+0x148>  // b.any
    62f4:	17ffffe9 	b	6298 <fwp_drop4+0x128>
    62f8:	ca544681 	eor	x1, x20, x20, lsr #17
    62fc:	911742c0 	add	x0, x22, #0x5d0
    6300:	ca412421 	eor	x1, x1, x1, lsr #9
    6304:	8b210c01 	add	x1, x0, w1, uxtb #3
    6308:	f94a2420 	ldr	x0, [x1, #5192]
    630c:	b5000080 	cbnz	x0, 631c <fwp_drop4+0x1ac>
    6310:	14000010 	b	6350 <fwp_drop4+0x1e0>
    6314:	f9400800 	ldr	x0, [x0, #16]
    6318:	b40001c0 	cbz	x0, 6350 <fwp_drop4+0x1e0>
    631c:	f9400001 	ldr	x1, [x0]
    6320:	eb14003f 	cmp	x1, x20
    6324:	54ffff81 	b.ne	6314 <fwp_drop4+0x1a4>  // b.any
    6328:	f9400401 	ldr	x1, [x0, #8]
    632c:	d1000421 	sub	x1, x1, #0x1
    6330:	f9000401 	str	x1, [x0, #8]
    6334:	f103f83f 	cmp	x1, #0xfe
    6338:	54fff6a1 	b.ne	620c <fwp_drop4+0x9c>  // b.any
    633c:	aa1403e0 	mov	x0, x20
    6340:	97fff94c 	bl	4870 <fwp_rc_forget_slot>
    6344:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6348:	39000280 	strb	w0, [x20]
    634c:	17ffffb0 	b	620c <fwp_drop4+0x9c>
    6350:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    6354:	91370000 	add	x0, x0, #0xdc0
    6358:	97fff54a 	bl	3880 <fwp_trap>
    635c:	ca544680 	eor	x0, x20, x20, lsr #17
    6360:	911742c1 	add	x1, x22, #0x5d0
    6364:	ca402400 	eor	x0, x0, x0, lsr #9
    6368:	8b200c20 	add	x0, x1, w0, uxtb #3
    636c:	f94a2400 	ldr	x0, [x0, #5192]
    6370:	b5000080 	cbnz	x0, 6380 <fwp_drop4+0x210>
    6374:	17fffff7 	b	6350 <fwp_drop4+0x1e0>
    6378:	f9400800 	ldr	x0, [x0, #16]
    637c:	b4fffea0 	cbz	x0, 6350 <fwp_drop4+0x1e0>
    6380:	f9400001 	ldr	x1, [x0]
    6384:	eb14003f 	cmp	x1, x20
    6388:	54ffff81 	b.ne	6378 <fwp_drop4+0x208>  // b.any
    638c:	f9400401 	ldr	x1, [x0, #8]
    6390:	d1000421 	sub	x1, x1, #0x1
    6394:	f9000401 	str	x1, [x0, #8]
    6398:	f103f83f 	cmp	x1, #0xfe
    639c:	54fff8e1 	b.ne	62b8 <fwp_drop4+0x148>  // b.any
    63a0:	aa1403e0 	mov	x0, x20
    63a4:	97fff933 	bl	4870 <fwp_rc_forget_slot>
    63a8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    63ac:	39000280 	strb	w0, [x20]
    63b0:	17ffffc2 	b	62b8 <fwp_drop4+0x148>

00000000000063b4 <fwp_arg_drop37>:
    63b4:	7100003f 	cmp	w1, #0x0
    63b8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    63bc:	54000041 	b.ne	63c4 <fwp_arg_drop37+0x10>  // b.any
    63c0:	d65f03c0 	ret
    63c4:	f9400000 	ldr	x0, [x0]
    63c8:	17ffff6a 	b	6170 <fwp_drop4>
    63cc:	d503201f 	nop

00000000000063d0 <fwp_task_dispose>:
    63d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63d4:	910003fd 	mov	x29, sp
    63d8:	f9000bf3 	str	x19, [sp, #16]
    63dc:	aa0003f3 	mov	x19, x0
    63e0:	39414000 	ldrb	w0, [x0, #80]
    63e4:	36000720 	tbz	w0, #0, 64c8 <fwp_task_dispose+0xf8>
    63e8:	f9400a60 	ldr	x0, [x19, #16]
    63ec:	b50006e0 	cbnz	x0, 64c8 <fwp_task_dispose+0xf8>
    63f0:	a9478660 	ldp	x0, x1, [x19, #120]
    63f4:	39014e7f 	strb	wzr, [x19, #83]
    63f8:	f9003e7f 	str	xzr, [x19, #120]
    63fc:	f100003f 	cmp	x1, #0x0
    6400:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6404:	54000040 	b.eq	640c <fwp_task_dispose+0x3c>  // b.none
    6408:	d63f0020 	blr	x1
    640c:	f9405660 	ldr	x0, [x19, #168]
    6410:	97fff9b8 	bl	4af0 <fwp_mem_free>
    6414:	f900567f 	str	xzr, [x19, #168]
    6418:	b9405e60 	ldr	w0, [x19, #92]
    641c:	7100041f 	cmp	w0, #0x1
    6420:	54000420 	b.eq	64a4 <fwp_task_dispose+0xd4>  // b.none
    6424:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6428:	91174042 	add	x2, x2, #0x5d0
    642c:	f949d840 	ldr	x0, [x2, #5040]
    6430:	f949ec41 	ldr	x1, [x2, #5080]
    6434:	cb000260 	sub	x0, x19, x0
    6438:	eb01401f 	cmp	x0, x1, lsl #16
    643c:	540002e2 	b.cs	6498 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6440:	d350fc01 	lsr	x1, x0, #16
    6444:	f949fc44 	ldr	x4, [x2, #5112]
    6448:	8b010821 	add	x1, x1, x1, lsl #2
    644c:	d37df021 	lsl	x1, x1, #3
    6450:	8b010083 	add	x3, x4, x1
    6454:	f9401062 	ldr	x2, [x3, #32]
    6458:	b4000202 	cbz	x2, 6498 <fwp_task_dispose+0xc8>
    645c:	38616881 	ldrb	w1, [x4, x1]
    6460:	7100083f 	cmp	w1, #0x2
    6464:	54000280 	b.eq	64b4 <fwp_task_dispose+0xe4>  // b.none
    6468:	7100043f 	cmp	w1, #0x1
    646c:	54000161 	b.ne	6498 <fwp_task_dispose+0xc8>  // b.any
    6470:	29430464 	ldp	w4, w1, [x3, #24]
    6474:	92403c00 	and	x0, x0, #0xffff
    6478:	9b047c00 	mul	x0, x0, x4
    647c:	d360fc00 	lsr	x0, x0, #32
    6480:	eb01001f 	cmp	x0, x1
    6484:	540000a2 	b.cs	6498 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6488:	8b000042 	add	x2, x2, x0
    648c:	39400040 	ldrb	w0, [x2]
    6490:	7100041f 	cmp	w0, #0x1
    6494:	54000080 	b.eq	64a4 <fwp_task_dispose+0xd4>  // b.none
    6498:	f9400bf3 	ldr	x19, [sp, #16]
    649c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64a0:	d65f03c0 	ret
    64a4:	aa1303e0 	mov	x0, x19
    64a8:	f9400bf3 	ldr	x19, [sp, #16]
    64ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64b0:	17fff990 	b	4af0 <fwp_mem_free>
    64b4:	72003c1f 	tst	w0, #0xffff
    64b8:	54fffea0 	b.eq	648c <fwp_task_dispose+0xbc>  // b.none
    64bc:	f9400bf3 	ldr	x19, [sp, #16]
    64c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64c4:	d65f03c0 	ret
    64c8:	97fff126 	bl	2960 <abort@plt>
    64cc:	d503201f 	nop

00000000000064d0 <fwp_free_zombie>:
    64d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64d4:	910003fd 	mov	x29, sp
    64d8:	a90153f3 	stp	x19, x20, [sp, #16]
    64dc:	d00000d4 	adrp	x20, 20000 <__data_start>
    64e0:	9101c281 	add	x1, x20, #0x70
    64e4:	f9407833 	ldr	x19, [x1, #240]
    64e8:	b4000333 	cbz	x19, 654c <fwp_free_zombie+0x7c>
    64ec:	f9400820 	ldr	x0, [x1, #16]
    64f0:	eb00027f 	cmp	x19, x0
    64f4:	540002c0 	b.eq	654c <fwp_free_zombie+0x7c>  // b.none
    64f8:	b940f822 	ldr	w2, [x1, #248]
    64fc:	f9400a60 	ldr	x0, [x19, #16]
    6500:	7100fc5f 	cmp	w2, #0x3f
    6504:	5400078c 	b.gt	65f4 <fwp_free_zombie+0x124>
    6508:	91040023 	add	x3, x1, #0x100
    650c:	11000444 	add	w4, w2, #0x1
    6510:	b900f824 	str	w4, [x1, #248]
    6514:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6518:	f822d860 	str	x0, [x3, w2, sxtw #3]
    651c:	a9530261 	ldp	x1, x0, [x19, #304]
    6520:	b4000741 	cbz	x1, 6608 <fwp_free_zombie+0x138>
    6524:	f9009c20 	str	x0, [x1, #312]
    6528:	b4000040 	cbz	x0, 6530 <fwp_free_zombie+0x60>
    652c:	f9009801 	str	x1, [x0, #304]
    6530:	9101c294 	add	x20, x20, #0x70
    6534:	b9405e60 	ldr	w0, [x19, #92]
    6538:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    653c:	f9007a9f 	str	xzr, [x20, #240]
    6540:	34000140 	cbz	w0, 6568 <fwp_free_zombie+0x98>
    6544:	7100041f 	cmp	w0, #0x1
    6548:	54000080 	b.eq	6558 <fwp_free_zombie+0x88>  // b.none
    654c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6550:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6554:	d65f03c0 	ret
    6558:	aa1303e0 	mov	x0, x19
    655c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6560:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6564:	17ffff9b 	b	63d0 <fwp_task_dispose>
    6568:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    656c:	91174082 	add	x2, x4, #0x5d0
    6570:	f949d841 	ldr	x1, [x2, #5040]
    6574:	f949ec40 	ldr	x0, [x2, #5080]
    6578:	cb010261 	sub	x1, x19, x1
    657c:	eb00403f 	cmp	x1, x0, lsl #16
    6580:	54fffe62 	b.cs	654c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6584:	d350fc20 	lsr	x0, x1, #16
    6588:	f949fc43 	ldr	x3, [x2, #5112]
    658c:	8b000800 	add	x0, x0, x0, lsl #2
    6590:	d37df000 	lsl	x0, x0, #3
    6594:	8b000062 	add	x2, x3, x0
    6598:	f9401054 	ldr	x20, [x2, #32]
    659c:	b4fffd94 	cbz	x20, 654c <fwp_free_zombie+0x7c>
    65a0:	38606860 	ldrb	w0, [x3, x0]
    65a4:	7100081f 	cmp	w0, #0x2
    65a8:	54000360 	b.eq	6614 <fwp_free_zombie+0x144>  // b.none
    65ac:	7100041f 	cmp	w0, #0x1
    65b0:	54fffce1 	b.ne	654c <fwp_free_zombie+0x7c>  // b.any
    65b4:	29430043 	ldp	w3, w0, [x2, #24]
    65b8:	92403c21 	and	x1, x1, #0xffff
    65bc:	9b037c21 	mul	x1, x1, x3
    65c0:	d360fc21 	lsr	x1, x1, #32
    65c4:	eb00003f 	cmp	x1, x0
    65c8:	54fffc22 	b.cs	654c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    65cc:	8b010294 	add	x20, x20, x1
    65d0:	39400280 	ldrb	w0, [x20]
    65d4:	34fffbc0 	cbz	w0, 654c <fwp_free_zombie+0x7c>
    65d8:	7100041f 	cmp	w0, #0x1
    65dc:	54fffbe0 	b.eq	6558 <fwp_free_zombie+0x88>  // b.none
    65e0:	7103fc1f 	cmp	w0, #0xff
    65e4:	540001e0 	b.eq	6620 <fwp_free_zombie+0x150>  // b.none
    65e8:	51000400 	sub	w0, w0, #0x1
    65ec:	39000280 	strb	w0, [x20]
    65f0:	17ffffd7 	b	654c <fwp_free_zombie+0x7c>
    65f4:	f9400e61 	ldr	x1, [x19, #24]
    65f8:	97fff10e 	bl	2a30 <munmap@plt>
    65fc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6600:	a9530261 	ldp	x1, x0, [x19, #304]
    6604:	b5fff901 	cbnz	x1, 6524 <fwp_free_zombie+0x54>
    6608:	9101c282 	add	x2, x20, #0x70
    660c:	f9018040 	str	x0, [x2, #768]
    6610:	17ffffc6 	b	6528 <fwp_free_zombie+0x58>
    6614:	72003c3f 	tst	w1, #0xffff
    6618:	54fff9a1 	b.ne	654c <fwp_free_zombie+0x7c>  // b.any
    661c:	17ffffed 	b	65d0 <fwp_free_zombie+0x100>
    6620:	ca544680 	eor	x0, x20, x20, lsr #17
    6624:	91174084 	add	x4, x4, #0x5d0
    6628:	ca402400 	eor	x0, x0, x0, lsr #9
    662c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6630:	f94a2400 	ldr	x0, [x0, #5192]
    6634:	b5000080 	cbnz	x0, 6644 <fwp_free_zombie+0x174>
    6638:	14000010 	b	6678 <fwp_free_zombie+0x1a8>
    663c:	f9400800 	ldr	x0, [x0, #16]
    6640:	b40001c0 	cbz	x0, 6678 <fwp_free_zombie+0x1a8>
    6644:	f9400001 	ldr	x1, [x0]
    6648:	eb14003f 	cmp	x1, x20
    664c:	54ffff81 	b.ne	663c <fwp_free_zombie+0x16c>  // b.any
    6650:	f9400401 	ldr	x1, [x0, #8]
    6654:	d1000421 	sub	x1, x1, #0x1
    6658:	f9000401 	str	x1, [x0, #8]
    665c:	f103f83f 	cmp	x1, #0xfe
    6660:	54fff761 	b.ne	654c <fwp_free_zombie+0x7c>  // b.any
    6664:	aa1403e0 	mov	x0, x20
    6668:	97fff882 	bl	4870 <fwp_rc_forget_slot>
    666c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6670:	39000280 	strb	w0, [x20]
    6674:	17ffffb6 	b	654c <fwp_free_zombie+0x7c>
    6678:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    667c:	91370000 	add	x0, x0, #0xdc0
    6680:	97fff480 	bl	3880 <fwp_trap>

0000000000006684 <fwp_block>:
    6684:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6688:	910003fd 	mov	x29, sp
    668c:	a90153f3 	stp	x19, x20, [sp, #16]
    6690:	d00000d3 	adrp	x19, 20000 <__data_start>
    6694:	9101c274 	add	x20, x19, #0x70
    6698:	f9404282 	ldr	x2, [x20, #128]
    669c:	b4000622 	cbz	x2, 6760 <fwp_block+0xdc>
    66a0:	9101c261 	add	x1, x19, #0x70
    66a4:	f9408040 	ldr	x0, [x2, #256]
    66a8:	f9004020 	str	x0, [x1, #128]
    66ac:	b4000680 	cbz	x0, 677c <fwp_block+0xf8>
    66b0:	9101c263 	add	x3, x19, #0x70
    66b4:	3901505f 	strb	wzr, [x2, #84]
    66b8:	f9400864 	ldr	x4, [x3, #16]
    66bc:	eb02009f 	cmp	x4, x2
    66c0:	54000440 	b.eq	6748 <fwp_block+0xc4>  // b.none
    66c4:	f9418465 	ldr	x5, [x3, #776]
    66c8:	f9000862 	str	x2, [x3, #16]
    66cc:	f9400441 	ldr	x1, [x2, #8]
    66d0:	f9004885 	str	x5, [x4, #144]
    66d4:	f9418865 	ldr	x5, [x3, #784]
    66d8:	f9004c85 	str	x5, [x4, #152]
    66dc:	f9418c65 	ldr	x5, [x3, #792]
    66e0:	f9005085 	str	x5, [x4, #160]
    66e4:	f9419065 	ldr	x5, [x3, #800]
    66e8:	f9005485 	str	x5, [x4, #168]
    66ec:	f9419465 	ldr	x5, [x3, #808]
    66f0:	f9005885 	str	x5, [x4, #176]
    66f4:	f9419865 	ldr	x5, [x3, #816]
    66f8:	f9005c85 	str	x5, [x4, #184]
    66fc:	f9419c65 	ldr	x5, [x3, #824]
    6700:	f9006085 	str	x5, [x4, #192]
    6704:	f9400480 	ldr	x0, [x4, #8]
    6708:	f9404844 	ldr	x4, [x2, #144]
    670c:	f9018464 	str	x4, [x3, #776]
    6710:	f9404c44 	ldr	x4, [x2, #152]
    6714:	f9018864 	str	x4, [x3, #784]
    6718:	f9405044 	ldr	x4, [x2, #160]
    671c:	f9018c64 	str	x4, [x3, #792]
    6720:	f9405444 	ldr	x4, [x2, #168]
    6724:	f9019064 	str	x4, [x3, #800]
    6728:	f9405844 	ldr	x4, [x2, #176]
    672c:	f9019464 	str	x4, [x3, #808]
    6730:	a94b8844 	ldp	x4, x2, [x2, #184]
    6734:	f9019864 	str	x4, [x3, #816]
    6738:	f9019c62 	str	x2, [x3, #824]
    673c:	97fff08d 	bl	2970 <swapcontext@plt>
    6740:	97ffff64 	bl	64d0 <fwp_free_zombie>
    6744:	d503201f 	nop
    6748:	9101c260 	add	x0, x19, #0x70
    674c:	b9434000 	ldr	w0, [x0, #832]
    6750:	340001a0 	cbz	w0, 6784 <fwp_block+0x100>
    6754:	a94153f3 	ldp	x19, x20, [sp, #16]
    6758:	a8c27bfd 	ldp	x29, x30, [sp], #32
    675c:	d65f03c0 	ret
    6760:	97fff770 	bl	4520 <fwp_poll_events>
    6764:	f9404282 	ldr	x2, [x20, #128]
    6768:	b4ffffc2 	cbz	x2, 6760 <fwp_block+0xdc>
    676c:	9101c261 	add	x1, x19, #0x70
    6770:	f9408040 	ldr	x0, [x2, #256]
    6774:	f9004020 	str	x0, [x1, #128]
    6778:	b5fff9c0 	cbnz	x0, 66b0 <fwp_block+0x2c>
    677c:	f9003c3f 	str	xzr, [x1, #120]
    6780:	17ffffcc 	b	66b0 <fwp_block+0x2c>
    6784:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    6788:	913bc000 	add	x0, x0, #0xef0
    678c:	97fff0c5 	bl	2aa0 <getenv@plt>
    6790:	5284e202 	mov	w2, #0x2710                	// #10000
    6794:	b4000060 	cbz	x0, 67a0 <fwp_block+0x11c>
    6798:	39400001 	ldrb	w1, [x0]
    679c:	350000c1 	cbnz	w1, 67b4 <fwp_block+0x130>
    67a0:	9101c273 	add	x19, x19, #0x70
    67a4:	b9034262 	str	w2, [x19, #832]
    67a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    67ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67b0:	d65f03c0 	ret
    67b4:	52800142 	mov	w2, #0xa                   	// #10
    67b8:	d2800001 	mov	x1, #0x0                   	// #0
    67bc:	97fff009 	bl	27e0 <strtoll@plt>
    67c0:	d1000403 	sub	x3, x0, #0x1
    67c4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    67c8:	eb02007f 	cmp	x3, x2
    67cc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    67d0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    67d4:	17fffff3 	b	67a0 <fwp_block+0x11c>
    67d8:	d503201f 	nop
    67dc:	d503201f 	nop

00000000000067e0 <fwp_drop10>:
    67e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    67e4:	910003fd 	mov	x29, sp
    67e8:	a90153f3 	stp	x19, x20, [sp, #16]
    67ec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    67f0:	f90013f5 	str	x21, [sp, #32]
    67f4:	91174275 	add	x21, x19, #0x5d0
    67f8:	f949daa1 	ldr	x1, [x21, #5040]
    67fc:	f949eea2 	ldr	x2, [x21, #5080]
    6800:	cb010001 	sub	x1, x0, x1
    6804:	eb02403f 	cmp	x1, x2, lsl #16
    6808:	54000382 	b.cs	6878 <fwp_drop10+0x98>  // b.hs, b.nlast
    680c:	d350fc22 	lsr	x2, x1, #16
    6810:	f949fea3 	ldr	x3, [x21, #5112]
    6814:	8b020842 	add	x2, x2, x2, lsl #2
    6818:	d37df042 	lsl	x2, x2, #3
    681c:	8b020064 	add	x4, x3, x2
    6820:	f9401094 	ldr	x20, [x4, #32]
    6824:	b40002b4 	cbz	x20, 6878 <fwp_drop10+0x98>
    6828:	38626862 	ldrb	w2, [x3, x2]
    682c:	7100085f 	cmp	w2, #0x2
    6830:	540007a0 	b.eq	6924 <fwp_drop10+0x144>  // b.none
    6834:	7100045f 	cmp	w2, #0x1
    6838:	54000201 	b.ne	6878 <fwp_drop10+0x98>  // b.any
    683c:	29430885 	ldp	w5, w2, [x4, #24]
    6840:	92403c21 	and	x1, x1, #0xffff
    6844:	9b057c21 	mul	x1, x1, x5
    6848:	d360fc21 	lsr	x1, x1, #32
    684c:	eb02003f 	cmp	x1, x2
    6850:	54000142 	b.cs	6878 <fwp_drop10+0x98>  // b.hs, b.nlast
    6854:	8b010294 	add	x20, x20, x1
    6858:	39400281 	ldrb	w1, [x20]
    685c:	340000e1 	cbz	w1, 6878 <fwp_drop10+0x98>
    6860:	7100043f 	cmp	w1, #0x1
    6864:	54000120 	b.eq	6888 <fwp_drop10+0xa8>  // b.none
    6868:	7103fc3f 	cmp	w1, #0xff
    686c:	540007c0 	b.eq	6964 <fwp_drop10+0x184>  // b.none
    6870:	51000421 	sub	w1, w1, #0x1
    6874:	39000281 	strb	w1, [x20]
    6878:	a94153f3 	ldp	x19, x20, [sp, #16]
    687c:	f94013f5 	ldr	x21, [sp, #32]
    6880:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6884:	d65f03c0 	ret
    6888:	f9400001 	ldr	x1, [x0]
    688c:	b7f80581 	tbnz	x1, #63, 693c <fwp_drop10+0x15c>
    6890:	91174273 	add	x19, x19, #0x5d0
    6894:	f949da61 	ldr	x1, [x19, #5040]
    6898:	f949ee62 	ldr	x2, [x19, #5080]
    689c:	cb010001 	sub	x1, x0, x1
    68a0:	eb02403f 	cmp	x1, x2, lsl #16
    68a4:	54fffea2 	b.cs	6878 <fwp_drop10+0x98>  // b.hs, b.nlast
    68a8:	d350fc22 	lsr	x2, x1, #16
    68ac:	8b020842 	add	x2, x2, x2, lsl #2
    68b0:	d37df042 	lsl	x2, x2, #3
    68b4:	8b020065 	add	x5, x3, x2
    68b8:	f94010a4 	ldr	x4, [x5, #32]
    68bc:	b4fffde4 	cbz	x4, 6878 <fwp_drop10+0x98>
    68c0:	38626862 	ldrb	w2, [x3, x2]
    68c4:	7100085f 	cmp	w2, #0x2
    68c8:	54000220 	b.eq	690c <fwp_drop10+0x12c>  // b.none
    68cc:	7100045f 	cmp	w2, #0x1
    68d0:	54fffd41 	b.ne	6878 <fwp_drop10+0x98>  // b.any
    68d4:	294308a3 	ldp	w3, w2, [x5, #24]
    68d8:	92403c21 	and	x1, x1, #0xffff
    68dc:	9b037c21 	mul	x1, x1, x3
    68e0:	d360fc21 	lsr	x1, x1, #32
    68e4:	eb02003f 	cmp	x1, x2
    68e8:	54fffc82 	b.cs	6878 <fwp_drop10+0x98>  // b.hs, b.nlast
    68ec:	8b010084 	add	x4, x4, x1
    68f0:	39400081 	ldrb	w1, [x4]
    68f4:	7100043f 	cmp	w1, #0x1
    68f8:	54fffc01 	b.ne	6878 <fwp_drop10+0x98>  // b.any
    68fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6900:	f94013f5 	ldr	x21, [sp, #32]
    6904:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6908:	17fff87a 	b	4af0 <fwp_mem_free>
    690c:	72003c3f 	tst	w1, #0xffff
    6910:	54ffff00 	b.eq	68f0 <fwp_drop10+0x110>  // b.none
    6914:	a94153f3 	ldp	x19, x20, [sp, #16]
    6918:	f94013f5 	ldr	x21, [sp, #32]
    691c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6920:	d65f03c0 	ret
    6924:	72003c3f 	tst	w1, #0xffff
    6928:	54fff980 	b.eq	6858 <fwp_drop10+0x78>  // b.none
    692c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6930:	f94013f5 	ldr	x21, [sp, #32]
    6934:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6938:	d65f03c0 	ret
    693c:	f9400414 	ldr	x20, [x0, #8]
    6940:	97fffb5d 	bl	56b4 <fwp_rc_free_arr>
    6944:	91174260 	add	x0, x19, #0x5d0
    6948:	f949d801 	ldr	x1, [x0, #5040]
    694c:	f949ec00 	ldr	x0, [x0, #5080]
    6950:	cb010281 	sub	x1, x20, x1
    6954:	eb00403f 	cmp	x1, x0, lsl #16
    6958:	54fff902 	b.cs	6878 <fwp_drop10+0x98>  // b.hs, b.nlast
    695c:	aa1403e0 	mov	x0, x20
    6960:	17ffffab 	b	680c <fwp_drop10+0x2c>
    6964:	ca544680 	eor	x0, x20, x20, lsr #17
    6968:	91174273 	add	x19, x19, #0x5d0
    696c:	ca402400 	eor	x0, x0, x0, lsr #9
    6970:	8b200e60 	add	x0, x19, w0, uxtb #3
    6974:	f94a2400 	ldr	x0, [x0, #5192]
    6978:	b5000080 	cbnz	x0, 6988 <fwp_drop10+0x1a8>
    697c:	14000010 	b	69bc <fwp_drop10+0x1dc>
    6980:	f9400800 	ldr	x0, [x0, #16]
    6984:	b40001c0 	cbz	x0, 69bc <fwp_drop10+0x1dc>
    6988:	f9400001 	ldr	x1, [x0]
    698c:	eb14003f 	cmp	x1, x20
    6990:	54ffff81 	b.ne	6980 <fwp_drop10+0x1a0>  // b.any
    6994:	f9400401 	ldr	x1, [x0, #8]
    6998:	d1000421 	sub	x1, x1, #0x1
    699c:	f9000401 	str	x1, [x0, #8]
    69a0:	f103f83f 	cmp	x1, #0xfe
    69a4:	54fff6a1 	b.ne	6878 <fwp_drop10+0x98>  // b.any
    69a8:	aa1403e0 	mov	x0, x20
    69ac:	97fff7b1 	bl	4870 <fwp_rc_forget_slot>
    69b0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    69b4:	39000280 	strb	w0, [x20]
    69b8:	17ffffb0 	b	6878 <fwp_drop10+0x98>
    69bc:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    69c0:	91370000 	add	x0, x0, #0xdc0
    69c4:	97fff3af 	bl	3880 <fwp_trap>
    69c8:	d503201f 	nop
    69cc:	d503201f 	nop

00000000000069d0 <fwp_caps173>:
    69d0:	34000041 	cbz	w1, 69d8 <fwp_caps173+0x8>
    69d4:	d65f03c0 	ret
    69d8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    69dc:	91174063 	add	x3, x3, #0x5d0
    69e0:	f949d861 	ldr	x1, [x3, #5040]
    69e4:	f949ec62 	ldr	x2, [x3, #5080]
    69e8:	cb010001 	sub	x1, x0, x1
    69ec:	eb02403f 	cmp	x1, x2, lsl #16
    69f0:	54ffff22 	b.cs	69d4 <fwp_caps173+0x4>  // b.hs, b.nlast
    69f4:	d350fc22 	lsr	x2, x1, #16
    69f8:	f949fc65 	ldr	x5, [x3, #5112]
    69fc:	8b020842 	add	x2, x2, x2, lsl #2
    6a00:	d37df042 	lsl	x2, x2, #3
    6a04:	8b0200a4 	add	x4, x5, x2
    6a08:	f9401083 	ldr	x3, [x4, #32]
    6a0c:	b4fffe43 	cbz	x3, 69d4 <fwp_caps173+0x4>
    6a10:	386268a2 	ldrb	w2, [x5, x2]
    6a14:	7100085f 	cmp	w2, #0x2
    6a18:	540001c0 	b.eq	6a50 <fwp_caps173+0x80>  // b.none
    6a1c:	7100045f 	cmp	w2, #0x1
    6a20:	54fffda1 	b.ne	69d4 <fwp_caps173+0x4>  // b.any
    6a24:	29430885 	ldp	w5, w2, [x4, #24]
    6a28:	92403c21 	and	x1, x1, #0xffff
    6a2c:	9b057c21 	mul	x1, x1, x5
    6a30:	d360fc21 	lsr	x1, x1, #32
    6a34:	eb02003f 	cmp	x1, x2
    6a38:	54fffce2 	b.cs	69d4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6a3c:	8b010063 	add	x3, x3, x1
    6a40:	39400061 	ldrb	w1, [x3]
    6a44:	7100043f 	cmp	w1, #0x1
    6a48:	54fffc61 	b.ne	69d4 <fwp_caps173+0x4>  // b.any
    6a4c:	17fff829 	b	4af0 <fwp_mem_free>
    6a50:	72003c3f 	tst	w1, #0xffff
    6a54:	54ffff60 	b.eq	6a40 <fwp_caps173+0x70>  // b.none
    6a58:	d65f03c0 	ret
    6a5c:	d503201f 	nop

0000000000006a60 <f37>:
    6a60:	d101c3ff 	sub	sp, sp, #0x70
    6a64:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6a68:	f947f421 	ldr	x1, [x1, #4072]
    6a6c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6a70:	910083fd 	add	x29, sp, #0x20
    6a74:	a90563f7 	stp	x23, x24, [sp, #80]
    6a78:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    6a7c:	911742e3 	add	x3, x23, #0x5d0
    6a80:	a90353f3 	stp	x19, x20, [sp, #48]
    6a84:	a9045bf5 	stp	x21, x22, [sp, #64]
    6a88:	aa0003f6 	mov	x22, x0
    6a8c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6a90:	f949ec62 	ldr	x2, [x3, #5080]
    6a94:	f9400024 	ldr	x4, [x1]
    6a98:	f9000fe4 	str	x4, [sp, #24]
    6a9c:	d2800004 	mov	x4, #0x0                   	// #0
    6aa0:	f949d861 	ldr	x1, [x3, #5040]
    6aa4:	d370bc42 	lsl	x2, x2, #16
    6aa8:	b40015c0 	cbz	x0, 6d60 <f37+0x300>
    6aac:	f9400818 	ldr	x24, [x0, #16]
    6ab0:	cb010301 	sub	x1, x24, x1
    6ab4:	eb02003f 	cmp	x1, x2
    6ab8:	54000362 	b.cs	6b24 <f37+0xc4>  // b.hs, b.nlast
    6abc:	f949fc60 	ldr	x0, [x3, #5112]
    6ac0:	d350fc22 	lsr	x2, x1, #16
    6ac4:	8b020842 	add	x2, x2, x2, lsl #2
    6ac8:	8b020c02 	add	x2, x0, x2, lsl #3
    6acc:	f9401040 	ldr	x0, [x2, #32]
    6ad0:	b40002a0 	cbz	x0, 6b24 <f37+0xc4>
    6ad4:	39400043 	ldrb	w3, [x2]
    6ad8:	7100087f 	cmp	w3, #0x2
    6adc:	540013c0 	b.eq	6d54 <f37+0x2f4>  // b.none
    6ae0:	7100047f 	cmp	w3, #0x1
    6ae4:	540001c1 	b.ne	6b1c <f37+0xbc>  // b.any
    6ae8:	29430843 	ldp	w3, w2, [x2, #24]
    6aec:	92403c21 	and	x1, x1, #0xffff
    6af0:	9b037c21 	mul	x1, x1, x3
    6af4:	d360fc21 	lsr	x1, x1, #32
    6af8:	eb02003f 	cmp	x1, x2
    6afc:	54000102 	b.cs	6b1c <f37+0xbc>  // b.hs, b.nlast
    6b00:	8b010000 	add	x0, x0, x1
    6b04:	39400001 	ldrb	w1, [x0]
    6b08:	340000a1 	cbz	w1, 6b1c <f37+0xbc>
    6b0c:	7103f43f 	cmp	w1, #0xfd
    6b10:	540016a8 	b.hi	6de4 <f37+0x384>  // b.pmore
    6b14:	11000421 	add	w1, w1, #0x1
    6b18:	39000001 	strb	w1, [x0]
    6b1c:	d2800000 	mov	x0, #0x0                   	// #0
    6b20:	b40000f6 	cbz	x22, 6b3c <f37+0xdc>
    6b24:	aa1603e1 	mov	x1, x22
    6b28:	d2800000 	mov	x0, #0x0                   	// #0
    6b2c:	d503201f 	nop
    6b30:	f9400821 	ldr	x1, [x1, #16]
    6b34:	91000400 	add	x0, x0, #0x1
    6b38:	b5ffffc1 	cbnz	x1, 6b30 <f37+0xd0>
    6b3c:	b40011b8 	cbz	x24, 6d70 <f37+0x310>
    6b40:	aa1803e1 	mov	x1, x24
    6b44:	d2800002 	mov	x2, #0x0                   	// #0
    6b48:	f9400821 	ldr	x1, [x1, #16]
    6b4c:	91000442 	add	x2, x2, #0x1
    6b50:	b5ffffc1 	cbnz	x1, 6b48 <f37+0xe8>
    6b54:	eb00005f 	cmp	x2, x0
    6b58:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6b5c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6b60:	eb01033f 	cmp	x25, x1
    6b64:	54001468 	b.hi	6df0 <f37+0x390>  // b.pmore
    6b68:	d37ffb33 	lsl	x19, x25, #1
    6b6c:	52800041 	mov	w1, #0x2                   	// #2
    6b70:	91000660 	add	x0, x19, #0x1
    6b74:	d37df000 	lsl	x0, x0, #3
    6b78:	97fff8fe 	bl	4f70 <fwp_heap_alloc>
    6b7c:	911742e1 	add	x1, x23, #0x5d0
    6b80:	aa0003fa 	mov	x26, x0
    6b84:	f9000013 	str	x19, [x0]
    6b88:	aa0103e0 	mov	x0, x1
    6b8c:	f949d821 	ldr	x1, [x1, #5040]
    6b90:	f949ec00 	ldr	x0, [x0, #5080]
    6b94:	cb010341 	sub	x1, x26, x1
    6b98:	eb00403f 	cmp	x1, x0, lsl #16
    6b9c:	54000342 	b.cs	6c04 <f37+0x1a4>  // b.hs, b.nlast
    6ba0:	911742e2 	add	x2, x23, #0x5d0
    6ba4:	d350fc20 	lsr	x0, x1, #16
    6ba8:	8b000800 	add	x0, x0, x0, lsl #2
    6bac:	f949fc43 	ldr	x3, [x2, #5112]
    6bb0:	d37df002 	lsl	x2, x0, #3
    6bb4:	8b020060 	add	x0, x3, x2
    6bb8:	f9401013 	ldr	x19, [x0, #32]
    6bbc:	b4000253 	cbz	x19, 6c04 <f37+0x1a4>
    6bc0:	38626862 	ldrb	w2, [x3, x2]
    6bc4:	7100085f 	cmp	w2, #0x2
    6bc8:	54000c00 	b.eq	6d48 <f37+0x2e8>  // b.none
    6bcc:	7100045f 	cmp	w2, #0x1
    6bd0:	540001a1 	b.ne	6c04 <f37+0x1a4>  // b.any
    6bd4:	29430002 	ldp	w2, w0, [x0, #24]
    6bd8:	92403c21 	and	x1, x1, #0xffff
    6bdc:	9b027c21 	mul	x1, x1, x2
    6be0:	d360fc21 	lsr	x1, x1, #32
    6be4:	eb00003f 	cmp	x1, x0
    6be8:	540000e2 	b.cs	6c04 <f37+0x1a4>  // b.hs, b.nlast
    6bec:	8b010273 	add	x19, x19, x1
    6bf0:	39400260 	ldrb	w0, [x19]
    6bf4:	7103fc1f 	cmp	w0, #0xff
    6bf8:	54000da0 	b.eq	6dac <f37+0x34c>  // b.none
    6bfc:	52800020 	mov	w0, #0x1                   	// #1
    6c00:	39000260 	strb	w0, [x19]
    6c04:	b4000259 	cbz	x25, 6c4c <f37+0x1ec>
    6c08:	8b191359 	add	x25, x26, x25, lsl #4
    6c0c:	aa1a03f3 	mov	x19, x26
    6c10:	aa1603f5 	mov	x21, x22
    6c14:	aa1803f4 	mov	x20, x24
    6c18:	f9400683 	ldr	x3, [x20, #8]
    6c1c:	f94006a2 	ldr	x2, [x21, #8]
    6c20:	f9400861 	ldr	x1, [x3, #16]
    6c24:	f9400840 	ldr	x0, [x2, #16]
    6c28:	fd400461 	ldr	d1, [x3, #8]
    6c2c:	fd400440 	ldr	d0, [x2, #8]
    6c30:	97fffa10 	bl	5470 <w120>
    6c34:	f9000660 	str	x0, [x19, #8]
    6c38:	f8010e61 	str	x1, [x19, #16]!
    6c3c:	f9400a94 	ldr	x20, [x20, #16]
    6c40:	f9400ab5 	ldr	x21, [x21, #16]
    6c44:	eb13033f 	cmp	x25, x19
    6c48:	54fffe81 	b.ne	6c18 <f37+0x1b8>  // b.any
    6c4c:	aa1803e0 	mov	x0, x24
    6c50:	97fffd48 	bl	6170 <fwp_drop4>
    6c54:	aa1603e0 	mov	x0, x22
    6c58:	97fffd46 	bl	6170 <fwp_drop4>
    6c5c:	911742f7 	add	x23, x23, #0x5d0
    6c60:	aa1a03e0 	mov	x0, x26
    6c64:	97fffa47 	bl	5580 <w176.constprop.0>
    6c68:	aa0103f3 	mov	x19, x1
    6c6c:	aa0003f4 	mov	x20, x0
    6c70:	aa1a03e0 	mov	x0, x26
    6c74:	97fffedb 	bl	67e0 <fwp_drop10>
    6c78:	a900cff4 	stp	x20, x19, [sp, #8]
    6c7c:	910023e1 	add	x1, sp, #0x8
    6c80:	52800000 	mov	w0, #0x0                   	// #0
    6c84:	97fff900 	bl	5084 <fwp_data.part.0.constprop.0>
    6c88:	f949dae1 	ldr	x1, [x23, #5040]
    6c8c:	aa0003f3 	mov	x19, x0
    6c90:	f949eee0 	ldr	x0, [x23, #5080]
    6c94:	cb010261 	sub	x1, x19, x1
    6c98:	eb00403f 	cmp	x1, x0, lsl #16
    6c9c:	54000322 	b.cs	6d00 <f37+0x2a0>  // b.hs, b.nlast
    6ca0:	d350fc22 	lsr	x2, x1, #16
    6ca4:	f949fee3 	ldr	x3, [x23, #5112]
    6ca8:	8b020842 	add	x2, x2, x2, lsl #2
    6cac:	d37df042 	lsl	x2, x2, #3
    6cb0:	8b020060 	add	x0, x3, x2
    6cb4:	f9401014 	ldr	x20, [x0, #32]
    6cb8:	b4000254 	cbz	x20, 6d00 <f37+0x2a0>
    6cbc:	38626862 	ldrb	w2, [x3, x2]
    6cc0:	7100085f 	cmp	w2, #0x2
    6cc4:	540003c0 	b.eq	6d3c <f37+0x2dc>  // b.none
    6cc8:	7100045f 	cmp	w2, #0x1
    6ccc:	540001a1 	b.ne	6d00 <f37+0x2a0>  // b.any
    6cd0:	29430002 	ldp	w2, w0, [x0, #24]
    6cd4:	92403c21 	and	x1, x1, #0xffff
    6cd8:	9b027c21 	mul	x1, x1, x2
    6cdc:	d360fc21 	lsr	x1, x1, #32
    6ce0:	eb00003f 	cmp	x1, x0
    6ce4:	540000e2 	b.cs	6d00 <f37+0x2a0>  // b.hs, b.nlast
    6ce8:	8b010294 	add	x20, x20, x1
    6cec:	39400280 	ldrb	w0, [x20]
    6cf0:	7103fc1f 	cmp	w0, #0xff
    6cf4:	54000620 	b.eq	6db8 <f37+0x358>  // b.none
    6cf8:	52800020 	mov	w0, #0x1                   	// #1
    6cfc:	39000280 	strb	w0, [x20]
    6d00:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6d04:	f947f400 	ldr	x0, [x0, #4072]
    6d08:	f9400fe2 	ldr	x2, [sp, #24]
    6d0c:	f9400001 	ldr	x1, [x0]
    6d10:	eb010042 	subs	x2, x2, x1
    6d14:	d2800001 	mov	x1, #0x0                   	// #0
    6d18:	540006a1 	b.ne	6dec <f37+0x38c>  // b.any
    6d1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6d20:	aa1303e0 	mov	x0, x19
    6d24:	a94353f3 	ldp	x19, x20, [sp, #48]
    6d28:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6d2c:	a94563f7 	ldp	x23, x24, [sp, #80]
    6d30:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6d34:	9101c3ff 	add	sp, sp, #0x70
    6d38:	d65f03c0 	ret
    6d3c:	72003c3f 	tst	w1, #0xffff
    6d40:	54fffe01 	b.ne	6d00 <f37+0x2a0>  // b.any
    6d44:	17ffffea 	b	6cec <f37+0x28c>
    6d48:	72003c3f 	tst	w1, #0xffff
    6d4c:	54fff5c1 	b.ne	6c04 <f37+0x1a4>  // b.any
    6d50:	17ffffa8 	b	6bf0 <f37+0x190>
    6d54:	72003c3f 	tst	w1, #0xffff
    6d58:	54ffee21 	b.ne	6b1c <f37+0xbc>  // b.any
    6d5c:	17ffff6a 	b	6b04 <f37+0xa4>
    6d60:	cb0103e1 	neg	x1, x1
    6d64:	eb02003f 	cmp	x1, x2
    6d68:	540002e3 	b.cc	6dc4 <f37+0x364>  // b.lo, b.ul, b.last
    6d6c:	d503201f 	nop
    6d70:	52800041 	mov	w1, #0x2                   	// #2
    6d74:	d2800100 	mov	x0, #0x8                   	// #8
    6d78:	97fff87e 	bl	4f70 <fwp_heap_alloc>
    6d7c:	aa0003e1 	mov	x1, x0
    6d80:	911742e0 	add	x0, x23, #0x5d0
    6d84:	aa0103fa 	mov	x26, x1
    6d88:	d2800018 	mov	x24, #0x0                   	// #0
    6d8c:	f900003f 	str	xzr, [x1]
    6d90:	f949d801 	ldr	x1, [x0, #5040]
    6d94:	f949ec00 	ldr	x0, [x0, #5080]
    6d98:	cb010341 	sub	x1, x26, x1
    6d9c:	eb00403f 	cmp	x1, x0, lsl #16
    6da0:	54fff562 	b.cs	6c4c <f37+0x1ec>  // b.hs, b.nlast
    6da4:	d2800019 	mov	x25, #0x0                   	// #0
    6da8:	17ffff7e 	b	6ba0 <f37+0x140>
    6dac:	aa1303e0 	mov	x0, x19
    6db0:	97fff6b0 	bl	4870 <fwp_rc_forget_slot>
    6db4:	17ffff92 	b	6bfc <f37+0x19c>
    6db8:	aa1403e0 	mov	x0, x20
    6dbc:	97fff6ad 	bl	4870 <fwp_rc_forget_slot>
    6dc0:	17ffffce 	b	6cf8 <f37+0x298>
    6dc4:	f949fc62 	ldr	x2, [x3, #5112]
    6dc8:	d350fc20 	lsr	x0, x1, #16
    6dcc:	8b000800 	add	x0, x0, x0, lsl #2
    6dd0:	8b000c42 	add	x2, x2, x0, lsl #3
    6dd4:	f9401040 	ldr	x0, [x2, #32]
    6dd8:	b4fffcc0 	cbz	x0, 6d70 <f37+0x310>
    6ddc:	d2800018 	mov	x24, #0x0                   	// #0
    6de0:	17ffff3d 	b	6ad4 <f37+0x74>
    6de4:	97fff65c 	bl	4754 <fwp_rc_wide_dup>
    6de8:	17ffff4d 	b	6b1c <f37+0xbc>
    6dec:	97ffeec9 	bl	2910 <__stack_chk_fail@plt>
    6df0:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    6df4:	913c0000 	add	x0, x0, #0xf00
    6df8:	97fff2a2 	bl	3880 <fwp_trap>
    6dfc:	d503201f 	nop

0000000000006e00 <fwp_owned_entry37>:
    6e00:	f9400000 	ldr	x0, [x0]
    6e04:	17ffff17 	b	6a60 <f37>
    6e08:	d503201f 	nop
    6e0c:	d503201f 	nop

0000000000006e10 <e37>:
    6e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6e14:	910003fd 	mov	x29, sp
    6e18:	f9000bf3 	str	x19, [sp, #16]
    6e1c:	f9400013 	ldr	x19, [x0]
    6e20:	aa1303e0 	mov	x0, x19
    6e24:	97fff9ff 	bl	5620 <fwp_rc_share>
    6e28:	aa1303e0 	mov	x0, x19
    6e2c:	97ffff0d 	bl	6a60 <f37>
    6e30:	aa0003f3 	mov	x19, x0
    6e34:	97fff9fb 	bl	5620 <fwp_rc_share>
    6e38:	aa1303e0 	mov	x0, x19
    6e3c:	f9400bf3 	ldr	x19, [sp, #16]
    6e40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e44:	d65f03c0 	ret
    6e48:	d503201f 	nop
    6e4c:	d503201f 	nop

0000000000006e50 <fwp_args37>:
    6e50:	7100003f 	cmp	w1, #0x0
    6e54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6e58:	54000041 	b.ne	6e60 <fwp_args37+0x10>  // b.any
    6e5c:	d65f03c0 	ret
    6e60:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6e64:	91174042 	add	x2, x2, #0x5d0
    6e68:	f9400001 	ldr	x1, [x0]
    6e6c:	f949d843 	ldr	x3, [x2, #5040]
    6e70:	f949ec40 	ldr	x0, [x2, #5080]
    6e74:	cb030021 	sub	x1, x1, x3
    6e78:	eb00403f 	cmp	x1, x0, lsl #16
    6e7c:	54ffff02 	b.cs	6e5c <fwp_args37+0xc>  // b.hs, b.nlast
    6e80:	d350fc20 	lsr	x0, x1, #16
    6e84:	f949fc44 	ldr	x4, [x2, #5112]
    6e88:	8b000800 	add	x0, x0, x0, lsl #2
    6e8c:	d37df002 	lsl	x2, x0, #3
    6e90:	8b020083 	add	x3, x4, x2
    6e94:	f9401060 	ldr	x0, [x3, #32]
    6e98:	b4fffe20 	cbz	x0, 6e5c <fwp_args37+0xc>
    6e9c:	38626882 	ldrb	w2, [x4, x2]
    6ea0:	7100085f 	cmp	w2, #0x2
    6ea4:	54000220 	b.eq	6ee8 <fwp_args37+0x98>  // b.none
    6ea8:	7100045f 	cmp	w2, #0x1
    6eac:	54fffd81 	b.ne	6e5c <fwp_args37+0xc>  // b.any
    6eb0:	29430864 	ldp	w4, w2, [x3, #24]
    6eb4:	92403c21 	and	x1, x1, #0xffff
    6eb8:	9b047c21 	mul	x1, x1, x4
    6ebc:	d360fc21 	lsr	x1, x1, #32
    6ec0:	eb02003f 	cmp	x1, x2
    6ec4:	54fffcc2 	b.cs	6e5c <fwp_args37+0xc>  // b.hs, b.nlast
    6ec8:	8b010000 	add	x0, x0, x1
    6ecc:	39400001 	ldrb	w1, [x0]
    6ed0:	34fffc61 	cbz	w1, 6e5c <fwp_args37+0xc>
    6ed4:	7103f43f 	cmp	w1, #0xfd
    6ed8:	540000e8 	b.hi	6ef4 <fwp_args37+0xa4>  // b.pmore
    6edc:	11000421 	add	w1, w1, #0x1
    6ee0:	39000001 	strb	w1, [x0]
    6ee4:	d65f03c0 	ret
    6ee8:	72003c3f 	tst	w1, #0xffff
    6eec:	54ffff00 	b.eq	6ecc <fwp_args37+0x7c>  // b.none
    6ef0:	d65f03c0 	ret
    6ef4:	17fff618 	b	4754 <fwp_rc_wide_dup>
    6ef8:	d503201f 	nop
    6efc:	d503201f 	nop

0000000000006f00 <fwp_caps37>:
    6f00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f04:	910003fd 	mov	x29, sp
    6f08:	f9000bf3 	str	x19, [sp, #16]
    6f0c:	aa0003f3 	mov	x19, x0
    6f10:	b9400400 	ldr	w0, [x0, #4]
    6f14:	340004a0 	cbz	w0, 6fa8 <fwp_caps37+0xa8>
    6f18:	f9400660 	ldr	x0, [x19, #8]
    6f1c:	350004e1 	cbnz	w1, 6fb8 <fwp_caps37+0xb8>
    6f20:	97fffc94 	bl	6170 <fwp_drop4>
    6f24:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f28:	91174042 	add	x2, x2, #0x5d0
    6f2c:	f949d840 	ldr	x0, [x2, #5040]
    6f30:	f949ec41 	ldr	x1, [x2, #5080]
    6f34:	cb000260 	sub	x0, x19, x0
    6f38:	eb01401f 	cmp	x0, x1, lsl #16
    6f3c:	54000382 	b.cs	6fac <fwp_caps37+0xac>  // b.hs, b.nlast
    6f40:	d350fc01 	lsr	x1, x0, #16
    6f44:	f949fc44 	ldr	x4, [x2, #5112]
    6f48:	8b010821 	add	x1, x1, x1, lsl #2
    6f4c:	d37df021 	lsl	x1, x1, #3
    6f50:	8b010083 	add	x3, x4, x1
    6f54:	f9401062 	ldr	x2, [x3, #32]
    6f58:	b40002a2 	cbz	x2, 6fac <fwp_caps37+0xac>
    6f5c:	38616881 	ldrb	w1, [x4, x1]
    6f60:	7100083f 	cmp	w1, #0x2
    6f64:	540006c0 	b.eq	703c <fwp_caps37+0x13c>  // b.none
    6f68:	7100043f 	cmp	w1, #0x1
    6f6c:	54000201 	b.ne	6fac <fwp_caps37+0xac>  // b.any
    6f70:	29430464 	ldp	w4, w1, [x3, #24]
    6f74:	92403c00 	and	x0, x0, #0xffff
    6f78:	9b047c00 	mul	x0, x0, x4
    6f7c:	d360fc00 	lsr	x0, x0, #32
    6f80:	eb01001f 	cmp	x0, x1
    6f84:	54000142 	b.cs	6fac <fwp_caps37+0xac>  // b.hs, b.nlast
    6f88:	8b000042 	add	x2, x2, x0
    6f8c:	39400040 	ldrb	w0, [x2]
    6f90:	7100041f 	cmp	w0, #0x1
    6f94:	540000c1 	b.ne	6fac <fwp_caps37+0xac>  // b.any
    6f98:	aa1303e0 	mov	x0, x19
    6f9c:	f9400bf3 	ldr	x19, [sp, #16]
    6fa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fa4:	17fff6d3 	b	4af0 <fwp_mem_free>
    6fa8:	34fffbe1 	cbz	w1, 6f24 <fwp_caps37+0x24>
    6fac:	f9400bf3 	ldr	x19, [sp, #16]
    6fb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fb4:	d65f03c0 	ret
    6fb8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6fbc:	91174042 	add	x2, x2, #0x5d0
    6fc0:	f949d843 	ldr	x3, [x2, #5040]
    6fc4:	f949ec41 	ldr	x1, [x2, #5080]
    6fc8:	cb030000 	sub	x0, x0, x3
    6fcc:	eb01401f 	cmp	x0, x1, lsl #16
    6fd0:	54fffee2 	b.cs	6fac <fwp_caps37+0xac>  // b.hs, b.nlast
    6fd4:	d350fc01 	lsr	x1, x0, #16
    6fd8:	f949fc44 	ldr	x4, [x2, #5112]
    6fdc:	8b010821 	add	x1, x1, x1, lsl #2
    6fe0:	d37df021 	lsl	x1, x1, #3
    6fe4:	8b010083 	add	x3, x4, x1
    6fe8:	f9401062 	ldr	x2, [x3, #32]
    6fec:	b4fffe02 	cbz	x2, 6fac <fwp_caps37+0xac>
    6ff0:	38616881 	ldrb	w1, [x4, x1]
    6ff4:	7100083f 	cmp	w1, #0x2
    6ff8:	54000280 	b.eq	7048 <fwp_caps37+0x148>  // b.none
    6ffc:	7100043f 	cmp	w1, #0x1
    7000:	54fffd61 	b.ne	6fac <fwp_caps37+0xac>  // b.any
    7004:	92403c01 	and	x1, x0, #0xffff
    7008:	29430064 	ldp	w4, w0, [x3, #24]
    700c:	9b047c21 	mul	x1, x1, x4
    7010:	d360fc21 	lsr	x1, x1, #32
    7014:	eb00003f 	cmp	x1, x0
    7018:	54fffca2 	b.cs	6fac <fwp_caps37+0xac>  // b.hs, b.nlast
    701c:	8b010042 	add	x2, x2, x1
    7020:	39400040 	ldrb	w0, [x2]
    7024:	34fffc40 	cbz	w0, 6fac <fwp_caps37+0xac>
    7028:	7103f41f 	cmp	w0, #0xfd
    702c:	54000148 	b.hi	7054 <fwp_caps37+0x154>  // b.pmore
    7030:	11000400 	add	w0, w0, #0x1
    7034:	39000040 	strb	w0, [x2]
    7038:	17ffffdd 	b	6fac <fwp_caps37+0xac>
    703c:	72003c1f 	tst	w0, #0xffff
    7040:	54fffb61 	b.ne	6fac <fwp_caps37+0xac>  // b.any
    7044:	17ffffd2 	b	6f8c <fwp_caps37+0x8c>
    7048:	72003c1f 	tst	w0, #0xffff
    704c:	54fffb01 	b.ne	6fac <fwp_caps37+0xac>  // b.any
    7050:	17fffff4 	b	7020 <fwp_caps37+0x120>
    7054:	f9400bf3 	ldr	x19, [sp, #16]
    7058:	aa0203e0 	mov	x0, x2
    705c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7060:	17fff5bd 	b	4754 <fwp_rc_wide_dup>

0000000000007064 <fwp_write>:
    7064:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7068:	910003fd 	mov	x29, sp
    706c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    7070:	f947f484 	ldr	x4, [x4, #4072]
    7074:	a90153f3 	stp	x19, x20, [sp, #16]
    7078:	d10943ff 	sub	sp, sp, #0x250
    707c:	b9400045 	ldr	w5, [x2]
    7080:	aa0003f4 	mov	x20, x0
    7084:	f9400080 	ldr	x0, [x4]
    7088:	f90127e0 	str	x0, [sp, #584]
    708c:	d2800000 	mov	x0, #0x0                   	// #0
    7090:	710064bf 	cmp	w5, #0x19
    7094:	54000408 	b.hi	7114 <fwp_write+0xb0>  // b.pmore
    7098:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    709c:	aa0103f3 	mov	x19, x1
    70a0:	911f4000 	add	x0, x0, #0x7d0
    70a4:	f9013bf5 	str	x21, [sp, #624]
    70a8:	f9013ff6 	str	x22, [sp, #632]
    70ac:	f90153fb 	str	x27, [sp, #672]
    70b0:	f90157fc 	str	x28, [sp, #680]
    70b4:	aa0203fc 	mov	x28, x2
    70b8:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    70bc:	10000061 	adr	x1, 70c8 <fwp_write+0x64>
    70c0:	8b20a820 	add	x0, x1, w0, sxth #2
    70c4:	d61f0000 	br	x0
    70c8:	910123e0 	add	x0, sp, #0x48
    70cc:	aa1303e5 	mov	x5, x19
    70d0:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    70d4:	aa0003f3 	mov	x19, x0
    70d8:	913d2084 	add	x4, x4, #0xf48
    70dc:	d2804003 	mov	x3, #0x200                 	// #512
    70e0:	aa0303e1 	mov	x1, x3
    70e4:	52800042 	mov	w2, #0x2                   	// #2
    70e8:	97ffede6 	bl	2880 <__snprintf_chk@plt>
    70ec:	aa1303e0 	mov	x0, x19
    70f0:	97ffedac 	bl	27a0 <strlen@plt>
    70f4:	aa1303e1 	mov	x1, x19
    70f8:	aa0003e2 	mov	x2, x0
    70fc:	aa1403e0 	mov	x0, x20
    7100:	97fff144 	bl	3610 <buf_put>
    7104:	f9413bf5 	ldr	x21, [sp, #624]
    7108:	f9413ff6 	ldr	x22, [sp, #632]
    710c:	f94153fb 	ldr	x27, [sp, #672]
    7110:	f94157fc 	ldr	x28, [sp, #680]
    7114:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7118:	f947f400 	ldr	x0, [x0, #4072]
    711c:	f94127e2 	ldr	x2, [sp, #584]
    7120:	f9400001 	ldr	x1, [x0]
    7124:	eb010042 	subs	x2, x2, x1
    7128:	d2800001 	mov	x1, #0x0                   	// #0
    712c:	540077a1 	b.ne	8020 <fwp_write+0xfbc>  // b.any
    7130:	910943ff 	add	sp, sp, #0x250
    7134:	a94153f3 	ldp	x19, x20, [sp, #16]
    7138:	a8c77bfd 	ldp	x29, x30, [sp], #112
    713c:	d65f03c0 	ret
    7140:	910123e0 	add	x0, sp, #0x48
    7144:	aa1303e5 	mov	x5, x19
    7148:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    714c:	aa0003f3 	mov	x19, x0
    7150:	913d0084 	add	x4, x4, #0xf40
    7154:	d2804003 	mov	x3, #0x200                 	// #512
    7158:	17ffffe2 	b	70e0 <fwp_write+0x7c>
    715c:	71004cbf 	cmp	w5, #0x13
    7160:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    7164:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7168:	913cc000 	add	x0, x0, #0xf30
    716c:	913ce021 	add	x1, x1, #0xf38
    7170:	d2800082 	mov	x2, #0x4                   	// #4
    7174:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7178:	aa1403e0 	mov	x0, x20
    717c:	f90143f7 	str	x23, [sp, #640]
    7180:	d2800016 	mov	x22, #0x0                   	// #0
    7184:	f90147f8 	str	x24, [sp, #648]
    7188:	97fff122 	bl	3610 <buf_put>
    718c:	f9400260 	ldr	x0, [x19]
    7190:	f0000017 	adrp	x23, a000 <fwp_main_thread+0x1fb0>
    7194:	d2800015 	mov	x21, #0x0                   	// #0
    7198:	913ee2f7 	add	x23, x23, #0xfb8
    719c:	b4004780 	cbz	x0, 7a8c <fwp_write+0xa28>
    71a0:	b9400380 	ldr	w0, [x28]
    71a4:	52800003 	mov	w3, #0x0                   	// #0
    71a8:	f9401f82 	ldr	x2, [x28, #56]
    71ac:	71004c1f 	cmp	w0, #0x13
    71b0:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    71b4:	aa1403e0 	mov	x0, x20
    71b8:	8b010e61 	add	x1, x19, x1, lsl #3
    71bc:	f9400421 	ldr	x1, [x1, #8]
    71c0:	97ffffa9 	bl	7064 <fwp_write>
    71c4:	b9400380 	ldr	w0, [x28]
    71c8:	7100481f 	cmp	w0, #0x12
    71cc:	54004b20 	b.eq	7b30 <fwp_write+0xacc>  // b.none
    71d0:	f9400260 	ldr	x0, [x19]
    71d4:	910006b5 	add	x21, x21, #0x1
    71d8:	91000ad6 	add	x22, x22, #0x2
    71dc:	eb15001f 	cmp	x0, x21
    71e0:	54004569 	b.ls	7a8c <fwp_write+0xa28>  // b.plast
    71e4:	aa1703e1 	mov	x1, x23
    71e8:	aa1403e0 	mov	x0, x20
    71ec:	d2800042 	mov	x2, #0x2                   	// #2
    71f0:	97fff108 	bl	3610 <buf_put>
    71f4:	17ffffeb 	b	71a0 <fwp_write+0x13c>
    71f8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    71fc:	913dc021 	add	x1, x1, #0xf70
    7200:	d28000c2 	mov	x2, #0x6                   	// #6
    7204:	aa1403e0 	mov	x0, x20
    7208:	91004273 	add	x19, x19, #0x10
    720c:	97fff101 	bl	3610 <buf_put>
    7210:	aa1303e0 	mov	x0, x19
    7214:	97ffed63 	bl	27a0 <strlen@plt>
    7218:	aa1303e1 	mov	x1, x19
    721c:	aa0003e2 	mov	x2, x0
    7220:	aa1403e0 	mov	x0, x20
    7224:	97fff0fb 	bl	3610 <buf_put>
    7228:	528007c3 	mov	w3, #0x3e                  	// #62
    722c:	aa1403e0 	mov	x0, x20
    7230:	91001fe1 	add	x1, sp, #0x7
    7234:	d2800022 	mov	x2, #0x1                   	// #1
    7238:	39001fe3 	strb	w3, [sp, #7]
    723c:	17ffffb1 	b	7100 <fwp_write+0x9c>
    7240:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7244:	f947f400 	ldr	x0, [x0, #4072]
    7248:	f94127e2 	ldr	x2, [sp, #584]
    724c:	f9400001 	ldr	x1, [x0]
    7250:	eb010042 	subs	x2, x2, x1
    7254:	d2800001 	mov	x1, #0x0                   	// #0
    7258:	540034c1 	b.ne	78f0 <fwp_write+0x88c>  // b.any
    725c:	f9413bf5 	ldr	x21, [sp, #624]
    7260:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7264:	f9413ff6 	ldr	x22, [sp, #632]
    7268:	aa1403e0 	mov	x0, x20
    726c:	913d4021 	add	x1, x1, #0xf50
    7270:	d2800142 	mov	x2, #0xa                   	// #10
    7274:	f94153fb 	ldr	x27, [sp, #672]
    7278:	f94157fc 	ldr	x28, [sp, #680]
    727c:	910943ff 	add	sp, sp, #0x250
    7280:	a94153f3 	ldp	x19, x20, [sp, #16]
    7284:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7288:	17fff0e2 	b	3610 <buf_put>
    728c:	f9400456 	ldr	x22, [x2, #8]
    7290:	f90143f7 	str	x23, [sp, #640]
    7294:	f90147f8 	str	x24, [sp, #648]
    7298:	b4005af6 	cbz	x22, 7df4 <fwp_write+0xd90>
    729c:	aa1603e0 	mov	x0, x22
    72a0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    72a4:	913f4021 	add	x1, x1, #0xfd0
    72a8:	97ffedba 	bl	2990 <strcmp@plt>
    72ac:	2a0003f5 	mov	w21, w0
    72b0:	34005fc0 	cbz	w0, 7ea8 <fwp_write+0xe44>
    72b4:	aa1603e0 	mov	x0, x22
    72b8:	97ffed3a 	bl	27a0 <strlen@plt>
    72bc:	aa1603e1 	mov	x1, x22
    72c0:	aa0003e2 	mov	x2, x0
    72c4:	aa1403e0 	mov	x0, x20
    72c8:	97fff0d2 	bl	3610 <buf_put>
    72cc:	52800403 	mov	w3, #0x20                  	// #32
    72d0:	91001ff5 	add	x21, sp, #0x7
    72d4:	aa1503e1 	mov	x1, x21
    72d8:	aa1403e0 	mov	x0, x20
    72dc:	d2800022 	mov	x2, #0x1                   	// #1
    72e0:	39001fe3 	strb	w3, [sp, #7]
    72e4:	97fff0cb 	bl	3610 <buf_put>
    72e8:	52800f63 	mov	w3, #0x7b                  	// #123
    72ec:	aa1403e0 	mov	x0, x20
    72f0:	aa1503e1 	mov	x1, x21
    72f4:	d2800022 	mov	x2, #0x1                   	// #1
    72f8:	39001fe3 	strb	w3, [sp, #7]
    72fc:	97fff0c5 	bl	3610 <buf_put>
    7300:	b9401380 	ldr	w0, [x28, #16]
    7304:	52800018 	mov	w24, #0x0                   	// #0
    7308:	7100001f 	cmp	w0, #0x0
    730c:	54003a8d 	b.le	7a5c <fwp_write+0x9f8>
    7310:	f9014bf9 	str	x25, [sp, #656]
    7314:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x1fb0>
    7318:	913fe339 	add	x25, x25, #0xff8
    731c:	f9014ffa 	str	x26, [sp, #664]
    7320:	f000001a 	adrp	x26, a000 <fwp_main_thread+0x1fb0>
    7324:	913ee35a 	add	x26, x26, #0xfb8
    7328:	91002276 	add	x22, x19, #0x8
    732c:	d2800013 	mov	x19, #0x0                   	// #0
    7330:	b5003e73 	cbnz	x19, 7afc <fwp_write+0xa98>
    7334:	d37df277 	lsl	x23, x19, #3
    7338:	34003c98 	cbz	w24, 7ac8 <fwp_write+0xa64>
    733c:	f9401382 	ldr	x2, [x28, #32]
    7340:	aa1403e0 	mov	x0, x20
    7344:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7348:	52800003 	mov	w3, #0x0                   	// #0
    734c:	f8776842 	ldr	x2, [x2, x23]
    7350:	91000673 	add	x19, x19, #0x1
    7354:	97ffff44 	bl	7064 <fwp_write>
    7358:	b9401380 	ldr	w0, [x28, #16]
    735c:	6b13001f 	cmp	w0, w19
    7360:	54fffe8c 	b.gt	7330 <fwp_write+0x2cc>
    7364:	f9414bf9 	ldr	x25, [sp, #656]
    7368:	f9414ffa 	ldr	x26, [sp, #664]
    736c:	34003798 	cbz	w24, 7a5c <fwp_write+0x9f8>
    7370:	52800523 	mov	w3, #0x29                  	// #41
    7374:	aa1503e1 	mov	x1, x21
    7378:	aa1403e0 	mov	x0, x20
    737c:	d2800022 	mov	x2, #0x1                   	// #1
    7380:	39001fe3 	strb	w3, [sp, #7]
    7384:	97fff0a3 	bl	3610 <buf_put>
    7388:	f9413bf5 	ldr	x21, [sp, #624]
    738c:	f9413ff6 	ldr	x22, [sp, #632]
    7390:	f94143f7 	ldr	x23, [sp, #640]
    7394:	f94147f8 	ldr	x24, [sp, #648]
    7398:	f94153fb 	ldr	x27, [sp, #672]
    739c:	f94157fc 	ldr	x28, [sp, #680]
    73a0:	17ffff5d 	b	7114 <fwp_write+0xb0>
    73a4:	b9404855 	ldr	w21, [x2, #72]
    73a8:	aa1403e0 	mov	x0, x20
    73ac:	93407eb6 	sxtw	x22, w21
    73b0:	91000ac1 	add	x1, x22, #0x2
    73b4:	97fff064 	bl	3544 <buf_grow>
    73b8:	a9400281 	ldp	x1, x0, [x20]
    73bc:	528e8603 	mov	w3, #0x7430                	// #29744
    73c0:	78206823 	strh	w3, [x1, x0]
    73c4:	8b000022 	add	x2, x1, x0
    73c8:	710002bf 	cmp	w21, #0x0
    73cc:	540036ad 	b.le	7aa0 <fwp_write+0xa3c>
    73d0:	110006a3 	add	w3, w21, #0x1
    73d4:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    73d8:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    73dc:	91000449 	add	x9, x2, #0x1
    73e0:	8b23c043 	add	x3, x2, w3, sxtw
    73e4:	f28aaac6 	movk	x6, #0x5556
    73e8:	f2955568 	movk	x8, #0xaaab
    73ec:	1400000d 	b	7420 <fwp_write+0x3bc>
    73f0:	d2800021 	mov	x1, #0x1                   	// #1
    73f4:	528005a5 	mov	w5, #0x2d                  	// #45
    73f8:	f100001f 	cmp	x0, #0x0
    73fc:	9b467e60 	smulh	x0, x19, x6
    7400:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7404:	381ff465 	strb	w5, [x3], #-1
    7408:	cb040000 	sub	x0, x0, x4
    740c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7410:	cb020000 	sub	x0, x0, x2
    7414:	8b010013 	add	x19, x0, x1
    7418:	eb03013f 	cmp	x9, x3
    741c:	54003420 	b.eq	7aa0 <fwp_write+0xa3c>  // b.none
    7420:	9b467e60 	smulh	x0, x19, x6
    7424:	937ffe64 	asr	x4, x19, #63
    7428:	52800605 	mov	w5, #0x30                  	// #48
    742c:	cb040000 	sub	x0, x0, x4
    7430:	8b000400 	add	x0, x0, x0, lsl #1
    7434:	cb000260 	sub	x0, x19, x0
    7438:	91000c01 	add	x1, x0, #0x3
    743c:	9bc87c22 	umulh	x2, x1, x8
    7440:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7444:	8b4204e2 	add	x2, x7, x2, lsr #1
    7448:	eb020021 	subs	x1, x1, x2
    744c:	54fffd60 	b.eq	73f8 <fwp_write+0x394>  // b.none
    7450:	f100043f 	cmp	x1, #0x1
    7454:	54fffce1 	b.ne	73f0 <fwp_write+0x38c>  // b.any
    7458:	d2800001 	mov	x1, #0x0                   	// #0
    745c:	52800565 	mov	w5, #0x2b                  	// #43
    7460:	17ffffe6 	b	73f8 <fwp_write+0x394>
    7464:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7468:	f947f400 	ldr	x0, [x0, #4072]
    746c:	f94127e2 	ldr	x2, [sp, #584]
    7470:	f9400001 	ldr	x1, [x0]
    7474:	eb010042 	subs	x2, x2, x1
    7478:	d2800001 	mov	x1, #0x0                   	// #0
    747c:	540023a1 	b.ne	78f0 <fwp_write+0x88c>  // b.any
    7480:	f9413bf5 	ldr	x21, [sp, #624]
    7484:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7488:	f9413ff6 	ldr	x22, [sp, #632]
    748c:	aa1403e0 	mov	x0, x20
    7490:	913d8021 	add	x1, x1, #0xf60
    7494:	d2800102 	mov	x2, #0x8                   	// #8
    7498:	17ffff77 	b	7274 <fwp_write+0x210>
    749c:	aa1403e0 	mov	x0, x20
    74a0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    74a4:	d28000c2 	mov	x2, #0x6                   	// #6
    74a8:	913f0021 	add	x1, x1, #0xfc0
    74ac:	97fff059 	bl	3610 <buf_put>
    74b0:	d2800015 	mov	x21, #0x0                   	// #0
    74b4:	f9400263 	ldr	x3, [x19]
    74b8:	f240f87f 	tst	x3, #0x7fffffffffffffff
    74bc:	54002c40 	b.eq	7a44 <fwp_write+0x9e0>  // b.none
    74c0:	f9401f82 	ldr	x2, [x28, #56]
    74c4:	f90143f7 	str	x23, [sp, #640]
    74c8:	f90147f8 	str	x24, [sp, #648]
    74cc:	d2800857 	mov	x23, #0x42                  	// #66
    74d0:	f9014bf9 	str	x25, [sp, #656]
    74d4:	f0000016 	adrp	x22, a000 <fwp_main_thread+0x1fb0>
    74d8:	f9014ffa 	str	x26, [sp, #664]
    74dc:	913ee2d6 	add	x22, x22, #0xfb8
    74e0:	d2800038 	mov	x24, #0x1                   	// #1
    74e4:	f2a18017 	movk	x23, #0xc00, lsl #16
    74e8:	d2809099 	mov	x25, #0x484                 	// #1156
    74ec:	b4000482 	cbz	x2, 757c <fwp_write+0x518>
    74f0:	b9400040 	ldr	w0, [x2]
    74f4:	7100701f 	cmp	w0, #0x1c
    74f8:	540042a0 	b.eq	7d4c <fwp_write+0xce8>  // b.none
    74fc:	71006c1f 	cmp	w0, #0x1b
    7500:	540003e8 	b.hi	757c <fwp_write+0x518>  // b.pmore
    7504:	9ac02301 	lsl	x1, x24, x0
    7508:	ea17003f 	tst	x1, x23
    750c:	54003681 	b.ne	7bdc <fwp_write+0xb78>  // b.any
    7510:	ea19003f 	tst	x1, x25
    7514:	54003501 	b.ne	7bb4 <fwp_write+0xb50>  // b.any
    7518:	d2800424 	mov	x4, #0x21                  	// #33
    751c:	ea04003f 	tst	x1, x4
    7520:	540002e0 	b.eq	757c <fwp_write+0x518>  // b.none
    7524:	b7f849a3 	tbnz	x3, #63, 7e58 <fwp_write+0xdf4>
    7528:	91002261 	add	x1, x19, #0x8
    752c:	8b150021 	add	x1, x1, x21
    7530:	39400021 	ldrb	w1, [x1]
    7534:	7100001f 	cmp	w0, #0x0
    7538:	93401c23 	sxtb	x3, w1
    753c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7540:	aa1403e0 	mov	x0, x20
    7544:	52800003 	mov	w3, #0x0                   	// #0
    7548:	97fffec7 	bl	7064 <fwp_write>
    754c:	910006b5 	add	x21, x21, #0x1
    7550:	f9400260 	ldr	x0, [x19]
    7554:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7558:	eb0002bf 	cmp	x21, x0
    755c:	540026c2 	b.cs	7a34 <fwp_write+0x9d0>  // b.hs, b.nlast
    7560:	d2800042 	mov	x2, #0x2                   	// #2
    7564:	aa1603e1 	mov	x1, x22
    7568:	aa1403e0 	mov	x0, x20
    756c:	97fff029 	bl	3610 <buf_put>
    7570:	f9401f82 	ldr	x2, [x28, #56]
    7574:	f9400263 	ldr	x3, [x19]
    7578:	b5fffbc2 	cbnz	x2, 74f0 <fwp_write+0x48c>
    757c:	d37df2a0 	lsl	x0, x21, #3
    7580:	b7f83f03 	tbnz	x3, #63, 7d60 <fwp_write+0xcfc>
    7584:	91002261 	add	x1, x19, #0x8
    7588:	8b000020 	add	x0, x1, x0
    758c:	f9400001 	ldr	x1, [x0]
    7590:	17ffffec 	b	7540 <fwp_write+0x4dc>
    7594:	a9400e62 	ldp	x2, x3, [x19]
    7598:	b7f83ca3 	tbnz	x3, #63, 7d2c <fwp_write+0xcc8>
    759c:	910123f5 	add	x21, sp, #0x48
    75a0:	aa1503e0 	mov	x0, x21
    75a4:	97ffee3f 	bl	2ea0 <fwp_fmt_u128>
    75a8:	aa1503e0 	mov	x0, x21
    75ac:	97ffec7d 	bl	27a0 <strlen@plt>
    75b0:	aa1503e1 	mov	x1, x21
    75b4:	aa0003e2 	mov	x2, x0
    75b8:	17fffed1 	b	70fc <fwp_write+0x98>
    75bc:	fd015be8 	str	d8, [sp, #688]
    75c0:	1e270268 	fmov	s8, w19
    75c4:	fd015fe9 	str	d9, [sp, #696]
    75c8:	1e282100 	fcmp	s8, s8
    75cc:	54004d26 	b.vs	7f70 <fwp_write+0xf0c>
    75d0:	1e20c101 	fabs	s1, s8
    75d4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    75d8:	1e270000 	fmov	s0, w0
    75dc:	1e202020 	fcmp	s1, s0
    75e0:	54002c0d 	b.le	7b60 <fwp_write+0xafc>
    75e4:	1e202118 	fcmpe	s8, #0.0
    75e8:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1fb0>
    75ec:	912ce042 	add	x2, x2, #0xb38
    75f0:	910123f5 	add	x21, sp, #0x48
    75f4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    75f8:	913c4021 	add	x1, x1, #0xf10
    75fc:	aa1503e0 	mov	x0, x21
    7600:	9a81c041 	csel	x1, x2, x1, gt
    7604:	97ffed13 	bl	2a50 <strcpy@plt>
    7608:	aa1503e0 	mov	x0, x21
    760c:	97ffec65 	bl	27a0 <strlen@plt>
    7610:	aa1503e1 	mov	x1, x21
    7614:	aa0003e2 	mov	x2, x0
    7618:	aa1403e0 	mov	x0, x20
    761c:	97ffeffd 	bl	3610 <buf_put>
    7620:	f9413bf5 	ldr	x21, [sp, #624]
    7624:	f9413ff6 	ldr	x22, [sp, #632]
    7628:	f94153fb 	ldr	x27, [sp, #672]
    762c:	f94157fc 	ldr	x28, [sp, #680]
    7630:	fd415be8 	ldr	d8, [sp, #688]
    7634:	fd415fe9 	ldr	d9, [sp, #696]
    7638:	17fffeb7 	b	7114 <fwp_write+0xb0>
    763c:	f9400276 	ldr	x22, [x19]
    7640:	34002e03 	cbz	w3, 7c00 <fwp_write+0xb9c>
    7644:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7648:	f947f400 	ldr	x0, [x0, #4072]
    764c:	f94127e2 	ldr	x2, [sp, #584]
    7650:	f9400001 	ldr	x1, [x0]
    7654:	eb010042 	subs	x2, x2, x1
    7658:	d2800001 	mov	x1, #0x0                   	// #0
    765c:	540014a1 	b.ne	78f0 <fwp_write+0x88c>  // b.any
    7660:	aa1603e2 	mov	x2, x22
    7664:	91002261 	add	x1, x19, #0x8
    7668:	f9413bf5 	ldr	x21, [sp, #624]
    766c:	aa1403e0 	mov	x0, x20
    7670:	f9413ff6 	ldr	x22, [sp, #632]
    7674:	17ffff00 	b	7274 <fwp_write+0x210>
    7678:	fd015be8 	str	d8, [sp, #688]
    767c:	9e670268 	fmov	d8, x19
    7680:	fd015fe9 	str	d9, [sp, #696]
    7684:	1e682100 	fcmp	d8, d8
    7688:	54004746 	b.vs	7f70 <fwp_write+0xf0c>
    768c:	1e60c101 	fabs	d1, d8
    7690:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7694:	9e670000 	fmov	d0, x0
    7698:	910123f5 	add	x21, sp, #0x48
    769c:	52800033 	mov	w19, #0x1                   	// #1
    76a0:	1e602020 	fcmp	d1, d0
    76a4:	540001ad 	b.le	76d8 <fwp_write+0x674>
    76a8:	1e602118 	fcmpe	d8, #0.0
    76ac:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1fb0>
    76b0:	912ce042 	add	x2, x2, #0xb38
    76b4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    76b8:	913c4021 	add	x1, x1, #0xf10
    76bc:	aa1503e0 	mov	x0, x21
    76c0:	9a81c041 	csel	x1, x2, x1, gt
    76c4:	97ffece3 	bl	2a50 <strcpy@plt>
    76c8:	17ffffd0 	b	7608 <fwp_write+0x5a4>
    76cc:	11000673 	add	w19, w19, #0x1
    76d0:	71004a7f 	cmp	w19, #0x12
    76d4:	54003860 	b.eq	7de0 <fwp_write+0xd7c>  // b.none
    76d8:	1e604100 	fmov	d0, d8
    76dc:	2a1303e1 	mov	w1, w19
    76e0:	aa1503e0 	mov	x0, x21
    76e4:	97fff14c 	bl	3c14 <fwp_format_g.constprop.0>
    76e8:	aa1503e0 	mov	x0, x21
    76ec:	d2800001 	mov	x1, #0x0                   	// #0
    76f0:	97ffec40 	bl	27f0 <strtod@plt>
    76f4:	1e602100 	fcmp	d8, d0
    76f8:	54fffea1 	b.ne	76cc <fwp_write+0x668>  // b.any
    76fc:	aa1503e0 	mov	x0, x21
    7700:	97fff03d 	bl	37f4 <fwp_finish_float>
    7704:	17ffffc1 	b	7608 <fwp_write+0x5a4>
    7708:	a9400e62 	ldp	x2, x3, [x19]
    770c:	910123f3 	add	x19, sp, #0x48
    7710:	aa1303e0 	mov	x0, x19
    7714:	97ffede3 	bl	2ea0 <fwp_fmt_u128>
    7718:	17fffe75 	b	70ec <fwp_write+0x88>
    771c:	f90143f7 	str	x23, [sp, #640]
    7720:	f90147f8 	str	x24, [sp, #648]
    7724:	2a1303f8 	mov	w24, w19
    7728:	f9014bf9 	str	x25, [sp, #656]
    772c:	f9014ffa 	str	x26, [sp, #664]
    7730:	f13ffe7f 	cmp	x19, #0xfff
    7734:	54000049 	b.ls	773c <fwp_write+0x6d8>  // b.plast
    7738:	b9400278 	ldr	w24, [x19]
    773c:	f9400f80 	ldr	x0, [x28, #24]
    7740:	2a1803f5 	mov	w21, w24
    7744:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7748:	d37ef6b9 	lsl	x25, x21, #2
    774c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7750:	aa1603e0 	mov	x0, x22
    7754:	97ffec13 	bl	27a0 <strlen@plt>
    7758:	aa1603e1 	mov	x1, x22
    775c:	aa0003e2 	mov	x2, x0
    7760:	aa1403e0 	mov	x0, x20
    7764:	97ffefab 	bl	3610 <buf_put>
    7768:	f9401780 	ldr	x0, [x28, #40]
    776c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7770:	7100001f 	cmp	w0, #0x0
    7774:	5400068d 	b.le	7844 <fwp_write+0x7e0>
    7778:	91002276 	add	x22, x19, #0x8
    777c:	91001ff5 	add	x21, sp, #0x7
    7780:	d280001b 	mov	x27, #0x0                   	// #0
    7784:	5280041a 	mov	w26, #0x20                  	// #32
    7788:	f9401b80 	ldr	x0, [x28, #48]
    778c:	aa1503e1 	mov	x1, x21
    7790:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7794:	d2800022 	mov	x2, #0x1                   	// #1
    7798:	f8786803 	ldr	x3, [x0, x24]
    779c:	aa1403e0 	mov	x0, x20
    77a0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    77a4:	39001ffa 	strb	w26, [sp, #7]
    77a8:	97ffef9a 	bl	3610 <buf_put>
    77ac:	f13ffeff 	cmp	x23, #0xfff
    77b0:	b9400261 	ldr	w1, [x19]
    77b4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    77b8:	7100383f 	cmp	w1, #0xe
    77bc:	54000160 	b.eq	77e8 <fwp_write+0x784>  // b.none
    77c0:	7100403f 	cmp	w1, #0x10
    77c4:	54001a60 	b.eq	7b10 <fwp_write+0xaac>  // b.none
    77c8:	7100283f 	cmp	w1, #0xa
    77cc:	54002aa0 	b.eq	7d20 <fwp_write+0xcbc>  // b.none
    77d0:	540014ac 	b.gt	7a64 <fwp_write+0xa00>
    77d4:	71000c3f 	cmp	w1, #0x3
    77d8:	540029ac 	b.gt	7d0c <fwp_write+0xca8>
    77dc:	d37ffee0 	lsr	x0, x23, #63
    77e0:	37f814a1 	tbnz	w1, #31, 7a74 <fwp_write+0xa10>
    77e4:	d503201f 	nop
    77e8:	34001460 	cbz	w0, 7a74 <fwp_write+0xa10>
    77ec:	52800503 	mov	w3, #0x28                  	// #40
    77f0:	aa1503e1 	mov	x1, x21
    77f4:	aa1403e0 	mov	x0, x20
    77f8:	d2800022 	mov	x2, #0x1                   	// #1
    77fc:	39001fe3 	strb	w3, [sp, #7]
    7800:	97ffef84 	bl	3610 <buf_put>
    7804:	aa1303e2 	mov	x2, x19
    7808:	aa1703e1 	mov	x1, x23
    780c:	aa1403e0 	mov	x0, x20
    7810:	52800003 	mov	w3, #0x0                   	// #0
    7814:	97fffe14 	bl	7064 <fwp_write>
    7818:	52800523 	mov	w3, #0x29                  	// #41
    781c:	aa1503e1 	mov	x1, x21
    7820:	aa1403e0 	mov	x0, x20
    7824:	d2800022 	mov	x2, #0x1                   	// #1
    7828:	39001fe3 	strb	w3, [sp, #7]
    782c:	97ffef79 	bl	3610 <buf_put>
    7830:	f9401780 	ldr	x0, [x28, #40]
    7834:	9100077b 	add	x27, x27, #0x1
    7838:	b8796800 	ldr	w0, [x0, x25]
    783c:	6b1b001f 	cmp	w0, w27
    7840:	54fffa4c 	b.gt	7788 <fwp_write+0x724>
    7844:	f9413bf5 	ldr	x21, [sp, #624]
    7848:	f9413ff6 	ldr	x22, [sp, #632]
    784c:	f94143f7 	ldr	x23, [sp, #640]
    7850:	f94147f8 	ldr	x24, [sp, #648]
    7854:	f9414bf9 	ldr	x25, [sp, #656]
    7858:	f9414ffa 	ldr	x26, [sp, #664]
    785c:	f94153fb 	ldr	x27, [sp, #672]
    7860:	f94157fc 	ldr	x28, [sp, #680]
    7864:	17fffe2c 	b	7114 <fwp_write+0xb0>
    7868:	52800783 	mov	w3, #0x3c                  	// #60
    786c:	91001ff3 	add	x19, sp, #0x7
    7870:	aa1303e1 	mov	x1, x19
    7874:	d2800022 	mov	x2, #0x1                   	// #1
    7878:	aa1403e0 	mov	x0, x20
    787c:	39001fe3 	strb	w3, [sp, #7]
    7880:	97ffef64 	bl	3610 <buf_put>
    7884:	f9400795 	ldr	x21, [x28, #8]
    7888:	aa1503e0 	mov	x0, x21
    788c:	97ffebc5 	bl	27a0 <strlen@plt>
    7890:	aa1503e1 	mov	x1, x21
    7894:	aa0003e2 	mov	x2, x0
    7898:	aa1403e0 	mov	x0, x20
    789c:	97ffef5d 	bl	3610 <buf_put>
    78a0:	528007c3 	mov	w3, #0x3e                  	// #62
    78a4:	aa1303e1 	mov	x1, x19
    78a8:	aa1403e0 	mov	x0, x20
    78ac:	d2800022 	mov	x2, #0x1                   	// #1
    78b0:	39001fe3 	strb	w3, [sp, #7]
    78b4:	17fffe13 	b	7100 <fwp_write+0x9c>
    78b8:	f100067f 	cmp	x19, #0x1
    78bc:	540025a0 	b.eq	7d70 <fwp_write+0xd0c>  // b.none
    78c0:	b100067f 	cmn	x19, #0x1
    78c4:	54002bc0 	b.eq	7e3c <fwp_write+0xdd8>  // b.none
    78c8:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    78cc:	913c6021 	add	x1, x1, #0xf18
    78d0:	d2800022 	mov	x2, #0x1                   	// #1
    78d4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    78d8:	f947f400 	ldr	x0, [x0, #4072]
    78dc:	f94127e4 	ldr	x4, [sp, #584]
    78e0:	f9400003 	ldr	x3, [x0]
    78e4:	eb030084 	subs	x4, x4, x3
    78e8:	d2800003 	mov	x3, #0x0                   	// #0
    78ec:	54ffebe0 	b.eq	7668 <fwp_write+0x604>  // b.none
    78f0:	f90143f7 	str	x23, [sp, #640]
    78f4:	f90147f8 	str	x24, [sp, #648]
    78f8:	f9014bf9 	str	x25, [sp, #656]
    78fc:	f9014ffa 	str	x26, [sp, #664]
    7900:	fd015be8 	str	d8, [sp, #688]
    7904:	fd015fe9 	str	d9, [sp, #696]
    7908:	97ffec02 	bl	2910 <__stack_chk_fail@plt>
    790c:	52800b63 	mov	w3, #0x5b                  	// #91
    7910:	91001ff5 	add	x21, sp, #0x7
    7914:	aa1503e1 	mov	x1, x21
    7918:	aa1403e0 	mov	x0, x20
    791c:	d2800022 	mov	x2, #0x1                   	// #1
    7920:	f0000016 	adrp	x22, a000 <fwp_main_thread+0x1fb0>
    7924:	913ee2d6 	add	x22, x22, #0xfb8
    7928:	39001fe3 	strb	w3, [sp, #7]
    792c:	97ffef39 	bl	3610 <buf_put>
    7930:	b4000273 	cbz	x19, 797c <fwp_write+0x918>
    7934:	f9400661 	ldr	x1, [x19, #8]
    7938:	aa1403e0 	mov	x0, x20
    793c:	f9401f82 	ldr	x2, [x28, #56]
    7940:	52800003 	mov	w3, #0x0                   	// #0
    7944:	97fffdc8 	bl	7064 <fwp_write>
    7948:	f9400a73 	ldr	x19, [x19, #16]
    794c:	b4000193 	cbz	x19, 797c <fwp_write+0x918>
    7950:	aa1603e1 	mov	x1, x22
    7954:	aa1403e0 	mov	x0, x20
    7958:	d2800042 	mov	x2, #0x2                   	// #2
    795c:	97ffef2d 	bl	3610 <buf_put>
    7960:	f9400661 	ldr	x1, [x19, #8]
    7964:	aa1403e0 	mov	x0, x20
    7968:	f9401f82 	ldr	x2, [x28, #56]
    796c:	52800003 	mov	w3, #0x0                   	// #0
    7970:	97fffdbd 	bl	7064 <fwp_write>
    7974:	f9400a73 	ldr	x19, [x19, #16]
    7978:	b5fffed3 	cbnz	x19, 7950 <fwp_write+0x8ec>
    797c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7980:	aa1503e1 	mov	x1, x21
    7984:	aa1403e0 	mov	x0, x20
    7988:	d2800022 	mov	x2, #0x1                   	// #1
    798c:	39001fe3 	strb	w3, [sp, #7]
    7990:	17fffddc 	b	7100 <fwp_write+0x9c>
    7994:	aa1403e0 	mov	x0, x20
    7998:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    799c:	d28000c2 	mov	x2, #0x6                   	// #6
    79a0:	913ea021 	add	x1, x1, #0xfa8
    79a4:	97ffef1b 	bl	3610 <buf_put>
    79a8:	f9400260 	ldr	x0, [x19]
    79ac:	b40004c0 	cbz	x0, 7a44 <fwp_write+0x9e0>
    79b0:	910123f5 	add	x21, sp, #0x48
    79b4:	91002276 	add	x22, x19, #0x8
    79b8:	f90143f7 	str	x23, [sp, #640]
    79bc:	d2800017 	mov	x23, #0x0                   	// #0
    79c0:	f90147f8 	str	x24, [sp, #648]
    79c4:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x1fb0>
    79c8:	913ec318 	add	x24, x24, #0xfb0
    79cc:	f9014bf9 	str	x25, [sp, #656]
    79d0:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x1fb0>
    79d4:	913ee339 	add	x25, x25, #0xfb8
    79d8:	f9014ffa 	str	x26, [sp, #664]
    79dc:	14000005 	b	79f0 <fwp_write+0x98c>
    79e0:	aa1903e1 	mov	x1, x25
    79e4:	aa1403e0 	mov	x0, x20
    79e8:	d2800042 	mov	x2, #0x2                   	// #2
    79ec:	97ffef09 	bl	3610 <buf_put>
    79f0:	38776ac5 	ldrb	w5, [x22, x23]
    79f4:	d2804003 	mov	x3, #0x200                 	// #512
    79f8:	aa1803e4 	mov	x4, x24
    79fc:	aa0303e1 	mov	x1, x3
    7a00:	52800042 	mov	w2, #0x2                   	// #2
    7a04:	aa1503e0 	mov	x0, x21
    7a08:	910006f7 	add	x23, x23, #0x1
    7a0c:	97ffeb9d 	bl	2880 <__snprintf_chk@plt>
    7a10:	aa1503e0 	mov	x0, x21
    7a14:	97ffeb63 	bl	27a0 <strlen@plt>
    7a18:	aa1503e1 	mov	x1, x21
    7a1c:	aa0003e2 	mov	x2, x0
    7a20:	aa1403e0 	mov	x0, x20
    7a24:	97ffeefb 	bl	3610 <buf_put>
    7a28:	f9400260 	ldr	x0, [x19]
    7a2c:	eb17001f 	cmp	x0, x23
    7a30:	54fffd88 	b.hi	79e0 <fwp_write+0x97c>  // b.pmore
    7a34:	f94143f7 	ldr	x23, [sp, #640]
    7a38:	f94147f8 	ldr	x24, [sp, #648]
    7a3c:	f9414bf9 	ldr	x25, [sp, #656]
    7a40:	f9414ffa 	ldr	x26, [sp, #664]
    7a44:	52800ba3 	mov	w3, #0x5d                  	// #93
    7a48:	aa1403e0 	mov	x0, x20
    7a4c:	91001fe1 	add	x1, sp, #0x7
    7a50:	d2800022 	mov	x2, #0x1                   	// #1
    7a54:	39001fe3 	strb	w3, [sp, #7]
    7a58:	17fffdaa 	b	7100 <fwp_write+0x9c>
    7a5c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7a60:	17fffe45 	b	7374 <fwp_write+0x310>
    7a64:	f10002ff 	cmp	x23, #0x0
    7a68:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7a6c:	71002c3f 	cmp	w1, #0xb
    7a70:	54ffebc0 	b.eq	77e8 <fwp_write+0x784>  // b.none
    7a74:	aa1303e2 	mov	x2, x19
    7a78:	aa1703e1 	mov	x1, x23
    7a7c:	aa1403e0 	mov	x0, x20
    7a80:	52800003 	mov	w3, #0x0                   	// #0
    7a84:	97fffd78 	bl	7064 <fwp_write>
    7a88:	17ffff6a 	b	7830 <fwp_write+0x7cc>
    7a8c:	aa1403e0 	mov	x0, x20
    7a90:	91001fe1 	add	x1, sp, #0x7
    7a94:	52800fa3 	mov	w3, #0x7d                  	// #125
    7a98:	d2800022 	mov	x2, #0x1                   	// #1
    7a9c:	17fffe39 	b	7380 <fwp_write+0x31c>
    7aa0:	a9400281 	ldp	x1, x0, [x20]
    7aa4:	91000800 	add	x0, x0, #0x2
    7aa8:	8b160000 	add	x0, x0, x22
    7aac:	f9000680 	str	x0, [x20, #8]
    7ab0:	3820683f 	strb	wzr, [x1, x0]
    7ab4:	f9413bf5 	ldr	x21, [sp, #624]
    7ab8:	f9413ff6 	ldr	x22, [sp, #632]
    7abc:	f94153fb 	ldr	x27, [sp, #672]
    7ac0:	f94157fc 	ldr	x28, [sp, #680]
    7ac4:	17fffd94 	b	7114 <fwp_write+0xb0>
    7ac8:	f9400f80 	ldr	x0, [x28, #24]
    7acc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7ad0:	aa1b03e0 	mov	x0, x27
    7ad4:	97ffeb33 	bl	27a0 <strlen@plt>
    7ad8:	aa1b03e1 	mov	x1, x27
    7adc:	aa0003e2 	mov	x2, x0
    7ae0:	aa1403e0 	mov	x0, x20
    7ae4:	97ffeecb 	bl	3610 <buf_put>
    7ae8:	aa1903e1 	mov	x1, x25
    7aec:	aa1403e0 	mov	x0, x20
    7af0:	d2800062 	mov	x2, #0x3                   	// #3
    7af4:	97ffeec7 	bl	3610 <buf_put>
    7af8:	17fffe11 	b	733c <fwp_write+0x2d8>
    7afc:	aa1a03e1 	mov	x1, x26
    7b00:	aa1403e0 	mov	x0, x20
    7b04:	d2800042 	mov	x2, #0x2                   	// #2
    7b08:	97ffeec2 	bl	3610 <buf_put>
    7b0c:	17fffe0a 	b	7334 <fwp_write+0x2d0>
    7b10:	f9400660 	ldr	x0, [x19, #8]
    7b14:	b4fffb00 	cbz	x0, 7a74 <fwp_write+0xa10>
    7b18:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7b1c:	913f4021 	add	x1, x1, #0xfd0
    7b20:	97ffeb9c 	bl	2990 <strcmp@plt>
    7b24:	7100001f 	cmp	w0, #0x0
    7b28:	1a9f07e0 	cset	w0, ne	// ne = any
    7b2c:	17ffff2f 	b	77e8 <fwp_write+0x784>
    7b30:	aa1403e0 	mov	x0, x20
    7b34:	d2800042 	mov	x2, #0x2                   	// #2
    7b38:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7b3c:	913f2021 	add	x1, x1, #0xfc8
    7b40:	97ffeeb4 	bl	3610 <buf_put>
    7b44:	91004261 	add	x1, x19, #0x10
    7b48:	aa1403e0 	mov	x0, x20
    7b4c:	f9402382 	ldr	x2, [x28, #64]
    7b50:	52800003 	mov	w3, #0x0                   	// #0
    7b54:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7b58:	97fffd43 	bl	7064 <fwp_write>
    7b5c:	17fffd9d 	b	71d0 <fwp_write+0x16c>
    7b60:	1e22c109 	fcvt	d9, s8
    7b64:	910123f5 	add	x21, sp, #0x48
    7b68:	52800033 	mov	w19, #0x1                   	// #1
    7b6c:	d503201f 	nop
    7b70:	1e604120 	fmov	d0, d9
    7b74:	2a1303e1 	mov	w1, w19
    7b78:	aa1503e0 	mov	x0, x21
    7b7c:	97fff026 	bl	3c14 <fwp_format_g.constprop.0>
    7b80:	aa1503e0 	mov	x0, x21
    7b84:	d2800001 	mov	x1, #0x0                   	// #0
    7b88:	97ffeb8e 	bl	29c0 <strtof@plt>
    7b8c:	1e202100 	fcmp	s8, s0
    7b90:	54ffdb60 	b.eq	76fc <fwp_write+0x698>  // b.none
    7b94:	11000673 	add	w19, w19, #0x1
    7b98:	71002a7f 	cmp	w19, #0xa
    7b9c:	54fffea1 	b.ne	7b70 <fwp_write+0xb0c>  // b.any
    7ba0:	1e604120 	fmov	d0, d9
    7ba4:	aa1503e0 	mov	x0, x21
    7ba8:	52800121 	mov	w1, #0x9                   	// #9
    7bac:	97fff01a 	bl	3c14 <fwp_format_g.constprop.0>
    7bb0:	17fffed3 	b	76fc <fwp_write+0x698>
    7bb4:	d37ef6a1 	lsl	x1, x21, #2
    7bb8:	b7f81563 	tbnz	x3, #63, 7e64 <fwp_write+0xe00>
    7bbc:	91002263 	add	x3, x19, #0x8
    7bc0:	8b010061 	add	x1, x3, x1
    7bc4:	b9400023 	ldr	w3, [x1]
    7bc8:	7100081f 	cmp	w0, #0x2
    7bcc:	2a0303e1 	mov	w1, w3
    7bd0:	93407c63 	sxtw	x3, w3
    7bd4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7bd8:	17fffe5a 	b	7540 <fwp_write+0x4dc>
    7bdc:	d37ffaa1 	lsl	x1, x21, #1
    7be0:	b7f81363 	tbnz	x3, #63, 7e4c <fwp_write+0xde8>
    7be4:	91002263 	add	x3, x19, #0x8
    7be8:	8b010061 	add	x1, x3, x1
    7bec:	79400021 	ldrh	w1, [x1]
    7bf0:	7100041f 	cmp	w0, #0x1
    7bf4:	93403c23 	sxth	x3, w1
    7bf8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7bfc:	17fffe51 	b	7540 <fwp_write+0x4dc>
    7c00:	52800443 	mov	w3, #0x22                  	// #34
    7c04:	91001ff5 	add	x21, sp, #0x7
    7c08:	91002273 	add	x19, x19, #0x8
    7c0c:	aa1503e1 	mov	x1, x21
    7c10:	aa1403e0 	mov	x0, x20
    7c14:	d2800022 	mov	x2, #0x1                   	// #1
    7c18:	39001fe3 	strb	w3, [sp, #7]
    7c1c:	f90143f7 	str	x23, [sp, #640]
    7c20:	8b160277 	add	x23, x19, x22
    7c24:	f90147f8 	str	x24, [sp, #648]
    7c28:	97ffee7a 	bl	3610 <buf_put>
    7c2c:	b4000696 	cbz	x22, 7cfc <fwp_write+0xc98>
    7c30:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x1fb0>
    7c34:	913de318 	add	x24, x24, #0xf78
    7c38:	f9014bf9 	str	x25, [sp, #656]
    7c3c:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x1fb0>
    7c40:	913e6339 	add	x25, x25, #0xf98
    7c44:	f9014ffa 	str	x26, [sp, #664]
    7c48:	1400000d 	b	7c7c <fwp_write+0xc18>
    7c4c:	710024bf 	cmp	w5, #0x9
    7c50:	54000460 	b.eq	7cdc <fwp_write+0xc78>  // b.none
    7c54:	710028bf 	cmp	w5, #0xa
    7c58:	54000a61 	b.ne	7da4 <fwp_write+0xd40>  // b.any
    7c5c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7c60:	aa1403e0 	mov	x0, x20
    7c64:	913e2021 	add	x1, x1, #0xf88
    7c68:	d2800042 	mov	x2, #0x2                   	// #2
    7c6c:	97ffee69 	bl	3610 <buf_put>
    7c70:	91000673 	add	x19, x19, #0x1
    7c74:	eb17027f 	cmp	x19, x23
    7c78:	540003e0 	b.eq	7cf4 <fwp_write+0xc90>  // b.none
    7c7c:	39400265 	ldrb	w5, [x19]
    7c80:	710034bf 	cmp	w5, #0xd
    7c84:	54000180 	b.eq	7cb4 <fwp_write+0xc50>  // b.none
    7c88:	54fffe29 	b.ls	7c4c <fwp_write+0xbe8>  // b.plast
    7c8c:	710088bf 	cmp	w5, #0x22
    7c90:	540001c0 	b.eq	7cc8 <fwp_write+0xc64>  // b.none
    7c94:	710170bf 	cmp	w5, #0x5c
    7c98:	54000741 	b.ne	7d80 <fwp_write+0xd1c>  // b.any
    7c9c:	aa1403e0 	mov	x0, x20
    7ca0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7ca4:	d2800042 	mov	x2, #0x2                   	// #2
    7ca8:	913e0021 	add	x1, x1, #0xf80
    7cac:	97ffee59 	bl	3610 <buf_put>
    7cb0:	17fffff0 	b	7c70 <fwp_write+0xc0c>
    7cb4:	aa1903e1 	mov	x1, x25
    7cb8:	aa1403e0 	mov	x0, x20
    7cbc:	d2800042 	mov	x2, #0x2                   	// #2
    7cc0:	97ffee54 	bl	3610 <buf_put>
    7cc4:	17ffffeb 	b	7c70 <fwp_write+0xc0c>
    7cc8:	aa1803e1 	mov	x1, x24
    7ccc:	aa1403e0 	mov	x0, x20
    7cd0:	d2800042 	mov	x2, #0x2                   	// #2
    7cd4:	97ffee4f 	bl	3610 <buf_put>
    7cd8:	17ffffe6 	b	7c70 <fwp_write+0xc0c>
    7cdc:	aa1403e0 	mov	x0, x20
    7ce0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7ce4:	d2800042 	mov	x2, #0x2                   	// #2
    7ce8:	913e4021 	add	x1, x1, #0xf90
    7cec:	97ffee49 	bl	3610 <buf_put>
    7cf0:	17ffffe0 	b	7c70 <fwp_write+0xc0c>
    7cf4:	f9414bf9 	ldr	x25, [sp, #656]
    7cf8:	f9414ffa 	ldr	x26, [sp, #664]
    7cfc:	aa1503e1 	mov	x1, x21
    7d00:	aa1403e0 	mov	x0, x20
    7d04:	52800443 	mov	w3, #0x22                  	// #34
    7d08:	17fffd9d 	b	737c <fwp_write+0x318>
    7d0c:	7100103f 	cmp	w1, #0x4
    7d10:	54ffeb21 	b.ne	7a74 <fwp_write+0xa10>  // b.any
    7d14:	f94006e0 	ldr	x0, [x23, #8]
    7d18:	d37ffc00 	lsr	x0, x0, #63
    7d1c:	17fffeb3 	b	77e8 <fwp_write+0x784>
    7d20:	710002ff 	cmp	w23, #0x0
    7d24:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7d28:	17fffeb0 	b	77e8 <fwp_write+0x784>
    7d2c:	528005a1 	mov	w1, #0x2d                  	// #45
    7d30:	eb0203e2 	negs	x2, x2
    7d34:	da0303e3 	ngc	x3, x3
    7d38:	910127e0 	add	x0, sp, #0x49
    7d3c:	910123f5 	add	x21, sp, #0x48
    7d40:	390123e1 	strb	w1, [sp, #72]
    7d44:	97ffec57 	bl	2ea0 <fwp_fmt_u128>
    7d48:	17fffe18 	b	75a8 <fwp_write+0x544>
    7d4c:	d37ceea1 	lsl	x1, x21, #4
    7d50:	b7f810a3 	tbnz	x3, #63, 7f64 <fwp_write+0xf00>
    7d54:	91002260 	add	x0, x19, #0x8
    7d58:	8b010001 	add	x1, x0, x1
    7d5c:	17fffdf9 	b	7540 <fwp_write+0x4dc>
    7d60:	f9400a61 	ldr	x1, [x19, #16]
    7d64:	8b010000 	add	x0, x0, x1
    7d68:	f9400001 	ldr	x1, [x0]
    7d6c:	17fffdf5 	b	7540 <fwp_write+0x4dc>
    7d70:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7d74:	d2800042 	mov	x2, #0x2                   	// #2
    7d78:	913c8021 	add	x1, x1, #0xf20
    7d7c:	17fffed6 	b	78d4 <fwp_write+0x870>
    7d80:	7101fcbf 	cmp	w5, #0x7f
    7d84:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7d88:	540000e9 	b.ls	7da4 <fwp_write+0xd40>  // b.plast
    7d8c:	aa1503e1 	mov	x1, x21
    7d90:	aa1403e0 	mov	x0, x20
    7d94:	d2800022 	mov	x2, #0x1                   	// #1
    7d98:	39001fe5 	strb	w5, [sp, #7]
    7d9c:	97ffee1d 	bl	3610 <buf_put>
    7da0:	17ffffb4 	b	7c70 <fwp_write+0xc0c>
    7da4:	d2800203 	mov	x3, #0x10                  	// #16
    7da8:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1fb0>
    7dac:	aa0303e1 	mov	x1, x3
    7db0:	913e8084 	add	x4, x4, #0xfa0
    7db4:	910123f6 	add	x22, sp, #0x48
    7db8:	52800042 	mov	w2, #0x2                   	// #2
    7dbc:	aa1603e0 	mov	x0, x22
    7dc0:	97ffeab0 	bl	2880 <__snprintf_chk@plt>
    7dc4:	aa1603e0 	mov	x0, x22
    7dc8:	97ffea76 	bl	27a0 <strlen@plt>
    7dcc:	aa1603e1 	mov	x1, x22
    7dd0:	aa0003e2 	mov	x2, x0
    7dd4:	aa1403e0 	mov	x0, x20
    7dd8:	97ffee0e 	bl	3610 <buf_put>
    7ddc:	17ffffa5 	b	7c70 <fwp_write+0xc0c>
    7de0:	1e604100 	fmov	d0, d8
    7de4:	aa1503e0 	mov	x0, x21
    7de8:	52800221 	mov	w1, #0x11                  	// #17
    7dec:	97ffef8a 	bl	3c14 <fwp_format_g.constprop.0>
    7df0:	17fffe43 	b	76fc <fwp_write+0x698>
    7df4:	b9401040 	ldr	w0, [x2, #16]
    7df8:	350003c0 	cbnz	w0, 7e70 <fwp_write+0xe0c>
    7dfc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7e00:	f947f400 	ldr	x0, [x0, #4072]
    7e04:	f94127e2 	ldr	x2, [sp, #584]
    7e08:	f9400001 	ldr	x1, [x0]
    7e0c:	eb010042 	subs	x2, x2, x1
    7e10:	d2800001 	mov	x1, #0x0                   	// #0
    7e14:	54ffd721 	b.ne	78f8 <fwp_write+0x894>  // b.any
    7e18:	f9413bf5 	ldr	x21, [sp, #624]
    7e1c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7e20:	f9413ff6 	ldr	x22, [sp, #632]
    7e24:	aa1403e0 	mov	x0, x20
    7e28:	f94143f7 	ldr	x23, [sp, #640]
    7e2c:	913fc021 	add	x1, x1, #0xff0
    7e30:	f94147f8 	ldr	x24, [sp, #648]
    7e34:	d2800042 	mov	x2, #0x2                   	// #2
    7e38:	17fffd0f 	b	7274 <fwp_write+0x210>
    7e3c:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1fb0>
    7e40:	d2800042 	mov	x2, #0x2                   	// #2
    7e44:	913ca021 	add	x1, x1, #0xf28
    7e48:	17fffea3 	b	78d4 <fwp_write+0x870>
    7e4c:	f9400a63 	ldr	x3, [x19, #16]
    7e50:	8b030021 	add	x1, x1, x3
    7e54:	17ffff66 	b	7bec <fwp_write+0xb88>
    7e58:	f9400a61 	ldr	x1, [x19, #16]
    7e5c:	8b0102a1 	add	x1, x21, x1
    7e60:	17fffdb4 	b	7530 <fwp_write+0x4cc>
    7e64:	f9400a63 	ldr	x3, [x19, #16]
    7e68:	8b030021 	add	x1, x1, x3
    7e6c:	17ffff56 	b	7bc4 <fwp_write+0xb60>
    7e70:	b9404840 	ldr	w0, [x2, #72]
    7e74:	91001ff5 	add	x21, sp, #0x7
    7e78:	34ffa380 	cbz	w0, 72e8 <fwp_write+0x284>
    7e7c:	52800503 	mov	w3, #0x28                  	// #40
    7e80:	aa1403e0 	mov	x0, x20
    7e84:	aa1503e1 	mov	x1, x21
    7e88:	d2800022 	mov	x2, #0x1                   	// #1
    7e8c:	39001fe3 	strb	w3, [sp, #7]
    7e90:	97ffede0 	bl	3610 <buf_put>
    7e94:	b9401380 	ldr	w0, [x28, #16]
    7e98:	52800038 	mov	w24, #0x1                   	// #1
    7e9c:	7100001f 	cmp	w0, #0x0
    7ea0:	54ffa38c 	b.gt	7310 <fwp_write+0x2ac>
    7ea4:	17fffd33 	b	7370 <fwp_write+0x30c>
    7ea8:	f9014bf9 	str	x25, [sp, #656]
    7eac:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11430>
    7eb0:	f9014ffa 	str	x26, [sp, #664]
    7eb4:	f9400676 	ldr	x22, [x19, #8]
    7eb8:	910aa333 	add	x19, x25, #0x2a8
    7ebc:	91002273 	add	x19, x19, #0x8
    7ec0:	937ffed8 	asr	x24, x22, #63
    7ec4:	aa1802c0 	orr	x0, x22, x24
    7ec8:	b5000320 	cbnz	x0, 7f2c <fwp_write+0xec8>
    7ecc:	110006b5 	add	w21, w21, #0x1
    7ed0:	710016bf 	cmp	w21, #0x5
    7ed4:	54ffffc1 	b.ne	7ecc <fwp_write+0xe68>  // b.any
    7ed8:	b7f80578 	tbnz	x24, #63, 7f84 <fwp_write+0xf20>
    7edc:	910023f3 	add	x19, sp, #0x8
    7ee0:	aa1603e2 	mov	x2, x22
    7ee4:	aa1303e0 	mov	x0, x19
    7ee8:	d2800003 	mov	x3, #0x0                   	// #0
    7eec:	97ffebed 	bl	2ea0 <fwp_fmt_u128>
    7ef0:	910123f5 	add	x21, sp, #0x48
    7ef4:	f0000003 	adrp	x3, a000 <fwp_main_thread+0x1fb0>
    7ef8:	aa1303e4 	mov	x4, x19
    7efc:	aa1503e0 	mov	x0, x21
    7f00:	913fa063 	add	x3, x3, #0xfe8
    7f04:	d2804002 	mov	x2, #0x200                 	// #512
    7f08:	52800041 	mov	w1, #0x2                   	// #2
    7f0c:	97ffea29 	bl	27b0 <__sprintf_chk@plt>
    7f10:	aa1503e0 	mov	x0, x21
    7f14:	97ffea23 	bl	27a0 <strlen@plt>
    7f18:	aa1503e1 	mov	x1, x21
    7f1c:	aa0003e2 	mov	x2, x0
    7f20:	aa1403e0 	mov	x0, x20
    7f24:	97ffedbb 	bl	3610 <buf_put>
    7f28:	17fffe47 	b	7844 <fwp_write+0x7e0>
    7f2c:	f9400277 	ldr	x23, [x19]
    7f30:	aa1603e0 	mov	x0, x22
    7f34:	aa1803e1 	mov	x1, x24
    7f38:	aa1703e2 	mov	x2, x23
    7f3c:	937ffefa 	asr	x26, x23, #63
    7f40:	aa1a03e3 	mov	x3, x26
    7f44:	940009df 	bl	a6c0 <__modti3>
    7f48:	aa010000 	orr	x0, x0, x1
    7f4c:	b40002c0 	cbz	x0, 7fa4 <fwp_write+0xf40>
    7f50:	110006b5 	add	w21, w21, #0x1
    7f54:	91004273 	add	x19, x19, #0x10
    7f58:	710016bf 	cmp	w21, #0x5
    7f5c:	54fffe81 	b.ne	7f2c <fwp_write+0xec8>  // b.any
    7f60:	17ffffde 	b	7ed8 <fwp_write+0xe74>
    7f64:	f9400a60 	ldr	x0, [x19, #16]
    7f68:	8b000021 	add	x1, x1, x0
    7f6c:	17fffd75 	b	7540 <fwp_write+0x4dc>
    7f70:	528c29c0 	mov	w0, #0x614e                	// #24910
    7f74:	910123f5 	add	x21, sp, #0x48
    7f78:	72a009c0 	movk	w0, #0x4e, lsl #16
    7f7c:	b9004be0 	str	w0, [sp, #72]
    7f80:	17fffda2 	b	7608 <fwp_write+0x5a4>
    7f84:	528005a1 	mov	w1, #0x2d                  	// #45
    7f88:	eb1603e2 	negs	x2, x22
    7f8c:	da1803e3 	ngc	x3, x24
    7f90:	910027e0 	add	x0, sp, #0x9
    7f94:	910023f3 	add	x19, sp, #0x8
    7f98:	390023e1 	strb	w1, [sp, #8]
    7f9c:	97ffebc1 	bl	2ea0 <fwp_fmt_u128>
    7fa0:	17ffffd4 	b	7ef0 <fwp_write+0xe8c>
    7fa4:	aa1703e2 	mov	x2, x23
    7fa8:	aa1a03e3 	mov	x3, x26
    7fac:	aa1603e0 	mov	x0, x22
    7fb0:	aa1803e1 	mov	x1, x24
    7fb4:	940008e3 	bl	a340 <__divti3>
    7fb8:	aa0003e2 	mov	x2, x0
    7fbc:	aa0103e3 	mov	x3, x1
    7fc0:	b7f80201 	tbnz	x1, #63, 8000 <fwp_write+0xf9c>
    7fc4:	910023f3 	add	x19, sp, #0x8
    7fc8:	aa1303e0 	mov	x0, x19
    7fcc:	97ffebb5 	bl	2ea0 <fwp_fmt_u128>
    7fd0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7fd4:	910aa339 	add	x25, x25, #0x2a8
    7fd8:	910123f5 	add	x21, sp, #0x48
    7fdc:	aa1303e4 	mov	x4, x19
    7fe0:	aa1503e0 	mov	x0, x21
    7fe4:	f0000003 	adrp	x3, a000 <fwp_main_thread+0x1fb0>
    7fe8:	f8616b25 	ldr	x5, [x25, x1]
    7fec:	913f8063 	add	x3, x3, #0xfe0
    7ff0:	d2804002 	mov	x2, #0x200                 	// #512
    7ff4:	52800041 	mov	w1, #0x2                   	// #2
    7ff8:	97ffe9ee 	bl	27b0 <__sprintf_chk@plt>
    7ffc:	17ffffc5 	b	7f10 <fwp_write+0xeac>
    8000:	528005a4 	mov	w4, #0x2d                  	// #45
    8004:	eb0003e2 	negs	x2, x0
    8008:	da0103e3 	ngc	x3, x1
    800c:	910027e0 	add	x0, sp, #0x9
    8010:	910023f3 	add	x19, sp, #0x8
    8014:	390023e4 	strb	w4, [sp, #8]
    8018:	97ffeba2 	bl	2ea0 <fwp_fmt_u128>
    801c:	17ffffed 	b	7fd0 <fwp_write+0xf6c>
    8020:	f9013bf5 	str	x21, [sp, #624]
    8024:	f9013ff6 	str	x22, [sp, #632]
    8028:	f90143f7 	str	x23, [sp, #640]
    802c:	f90147f8 	str	x24, [sp, #648]
    8030:	f9014bf9 	str	x25, [sp, #656]
    8034:	f9014ffa 	str	x26, [sp, #664]
    8038:	f90153fb 	str	x27, [sp, #672]
    803c:	f90157fc 	str	x28, [sp, #680]
    8040:	fd015be8 	str	d8, [sp, #688]
    8044:	fd015fe9 	str	d9, [sp, #696]
    8048:	97ffea32 	bl	2910 <__stack_chk_fail@plt>
    804c:	d503201f 	nop

0000000000008050 <fwp_main_thread>:
    8050:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8054:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    8058:	91174001 	add	x1, x0, #0x5d0
    805c:	910003fd 	mov	x29, sp
    8060:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8064:	f947f400 	ldr	x0, [x0, #4072]
    8068:	a90153f3 	stp	x19, x20, [sp, #16]
    806c:	a9025bf5 	stp	x21, x22, [sp, #32]
    8070:	d10643ff 	sub	sp, sp, #0x190
    8074:	b953a421 	ldr	w1, [x1, #5028]
    8078:	f9400002 	ldr	x2, [x0]
    807c:	f900c7e2 	str	x2, [sp, #392]
    8080:	d2800002 	mov	x2, #0x0                   	// #0
    8084:	34008ae1 	cbz	w1, 91e0 <fwp_main_thread+0x1190>
    8088:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    808c:	91174000 	add	x0, x0, #0x5d0
    8090:	b953a800 	ldr	w0, [x0, #5032]
    8094:	350089e0 	cbnz	w0, 91d0 <fwp_main_thread+0x1180>
    8098:	9101c3e5 	add	x5, sp, #0x70
    809c:	900000d3 	adrp	x19, 20000 <__data_start>
    80a0:	900000c2 	adrp	x2, 20000 <__data_start>
    80a4:	9101c275 	add	x21, x19, #0x70
    80a8:	910fc042 	add	x2, x2, #0x3f0
    80ac:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    80b0:	d2a00024 	mov	x4, #0x10000               	// #65536
    80b4:	910223e0 	add	x0, sp, #0x88
    80b8:	d2800001 	mov	x1, #0x0                   	// #0
    80bc:	f9000be0 	str	x0, [sp, #16]
    80c0:	a9018ea5 	stp	x5, x3, [x21, #24]
    80c4:	f90013e5 	str	x5, [sp, #32]
    80c8:	f90047e2 	str	x2, [sp, #136]
    80cc:	b90093ff 	str	wzr, [sp, #144]
    80d0:	f9004fe4 	str	x4, [sp, #152]
    80d4:	97ffe9a7 	bl	2770 <sigaltstack@plt>
    80d8:	35010f60 	cbnz	w0, a2c4 <fwp_main_thread+0x2274>
    80dc:	4f000400 	movi	v0.4s, #0x0
    80e0:	9103e3e0 	add	x0, sp, #0xf8
    80e4:	f0ffffc1 	adrp	x1, 3000 <fwp_range_release+0x30>
    80e8:	9103c021 	add	x1, x1, #0xf0
    80ec:	f9007be1 	str	x1, [sp, #240]
    80f0:	52800082 	mov	w2, #0x4                   	// #4
    80f4:	72a10002 	movk	w2, #0x800, lsl #16
    80f8:	9103c3f4 	add	x20, sp, #0xf0
    80fc:	3d802000 	str	q0, [x0, #128]
    8100:	b9017be2 	str	w2, [sp, #376]
    8104:	ad000000 	stp	q0, q0, [x0]
    8108:	ad010000 	stp	q0, q0, [x0, #32]
    810c:	ad020000 	stp	q0, q0, [x0, #64]
    8110:	ad030000 	stp	q0, q0, [x0, #96]
    8114:	97ffe9ef 	bl	28d0 <sigemptyset@plt>
    8118:	35010d60 	cbnz	w0, a2c4 <fwp_main_thread+0x2274>
    811c:	aa1403e1 	mov	x1, x20
    8120:	d2800002 	mov	x2, #0x0                   	// #0
    8124:	52800160 	mov	w0, #0xb                   	// #11
    8128:	97ffea02 	bl	2930 <sigaction@plt>
    812c:	35010cc0 	cbnz	w0, a2c4 <fwp_main_thread+0x2274>
    8130:	aa1403e1 	mov	x1, x20
    8134:	d2800002 	mov	x2, #0x0                   	// #0
    8138:	528000e0 	mov	w0, #0x7                   	// #7
    813c:	97ffe9fd 	bl	2930 <sigaction@plt>
    8140:	35010c20 	cbnz	w0, a2c4 <fwp_main_thread+0x2274>
    8144:	b94346a0 	ldr	w0, [x21, #836]
    8148:	340012e0 	cbz	w0, 83a4 <fwp_main_thread+0x354>
    814c:	9101c260 	add	x0, x19, #0x70
    8150:	a91c63f7 	stp	x23, x24, [sp, #448]
    8154:	b9434801 	ldr	w1, [x0, #840]
    8158:	340013a1 	cbz	w1, 83cc <fwp_main_thread+0x37c>
    815c:	9101c276 	add	x22, x19, #0x70
    8160:	f9400ad5 	ldr	x21, [x22, #16]
    8164:	b4000c95 	cbz	x21, 82f4 <fwp_main_thread+0x2a4>
    8168:	aa1503f4 	mov	x20, x21
    816c:	910102b8 	add	x24, x21, #0x40
    8170:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8174:	52800037 	mov	w23, #0x1                   	// #1
    8178:	39414ab9 	ldrb	w25, [x21, #82]
    817c:	39014ab7 	strb	w23, [x21, #82]
    8180:	f94016a0 	ldr	x0, [x21, #40]
    8184:	b4000620 	cbz	x0, 8248 <fwp_main_thread+0x1f8>
    8188:	f94032a1 	ldr	x1, [x21, #96]
    818c:	394146a0 	ldrb	w0, [x21, #81]
    8190:	b4000cc1 	cbz	x1, 8328 <fwp_main_thread+0x2d8>
    8194:	36000b80 	tbz	w0, #0, 8304 <fwp_main_thread+0x2b4>
    8198:	39414a82 	ldrb	w2, [x20, #82]
    819c:	f94022a0 	ldr	x0, [x21, #64]
    81a0:	37000ee2 	tbnz	w2, #0, 837c <fwp_main_thread+0x32c>
    81a4:	f9403281 	ldr	x1, [x20, #96]
    81a8:	a911fe98 	stp	x24, xzr, [x20, #280]
    81ac:	f9009680 	str	x0, [x20, #296]
    81b0:	b4000040 	cbz	x0, 81b8 <fwp_main_thread+0x168>
    81b4:	f9009014 	str	x20, [x0, #288]
    81b8:	f90022b4 	str	x20, [x21, #64]
    81bc:	b4000101 	cbz	x1, 81dc <fwp_main_thread+0x18c>
    81c0:	f9406ec0 	ldr	x0, [x22, #216]
    81c4:	39015697 	strb	w23, [x20, #85]
    81c8:	f9003681 	str	x1, [x20, #104]
    81cc:	a910829f 	stp	xzr, x0, [x20, #264]
    81d0:	b4000040 	cbz	x0, 81d8 <fwp_main_thread+0x188>
    81d4:	f9008414 	str	x20, [x0, #264]
    81d8:	f9006ed4 	str	x20, [x22, #216]
    81dc:	39015a9f 	strb	wzr, [x20, #86]
    81e0:	97fff929 	bl	6684 <fwp_block>
    81e4:	f9408e82 	ldr	x2, [x20, #280]
    81e8:	b4000142 	cbz	x2, 8210 <fwp_main_thread+0x1c0>
    81ec:	a9520281 	ldp	x1, x0, [x20, #288]
    81f0:	b4000d21 	cbz	x1, 8394 <fwp_main_thread+0x344>
    81f4:	f9009420 	str	x0, [x1, #296]
    81f8:	f9409680 	ldr	x0, [x20, #296]
    81fc:	b4000040 	cbz	x0, 8204 <fwp_main_thread+0x1b4>
    8200:	f9009001 	str	x1, [x0, #288]
    8204:	91080280 	add	x0, x20, #0x200
    8208:	f900969f 	str	xzr, [x20, #296]
    820c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8210:	39415680 	ldrb	w0, [x20, #85]
    8214:	f9400ac2 	ldr	x2, [x22, #16]
    8218:	36000ae0 	tbz	w0, #0, 8374 <fwp_main_thread+0x324>
    821c:	a9508281 	ldp	x1, x0, [x20, #264]
    8220:	b4000be1 	cbz	x1, 839c <fwp_main_thread+0x34c>
    8224:	f9008820 	str	x0, [x1, #272]
    8228:	b4000040 	cbz	x0, 8230 <fwp_main_thread+0x1e0>
    822c:	f9008401 	str	x1, [x0, #264]
    8230:	91080280 	add	x0, x20, #0x200
    8234:	3901569f 	strb	wzr, [x20, #85]
    8238:	aa0203f4 	mov	x20, x2
    823c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8240:	f94016a0 	ldr	x0, [x21, #40]
    8244:	b5fffa20 	cbnz	x0, 8188 <fwp_main_thread+0x138>
    8248:	9101c260 	add	x0, x19, #0x70
    824c:	39014ab9 	strb	w25, [x21, #82]
    8250:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    8254:	f9419400 	ldr	x0, [x0, #808]
    8258:	b5000080 	cbnz	x0, 8268 <fwp_main_thread+0x218>
    825c:	9101c275 	add	x21, x19, #0x70
    8260:	f9419ea0 	ldr	x0, [x21, #824]
    8264:	b400f860 	cbz	x0, a170 <fwp_main_thread+0x2120>
    8268:	9101c260 	add	x0, x19, #0x70
    826c:	f941b001 	ldr	x1, [x0, #864]
    8270:	b903581f 	str	wzr, [x0, #856]
    8274:	eb14003f 	cmp	x1, x20
    8278:	5400f921 	b.ne	a19c <fwp_main_thread+0x214c>  // b.any
    827c:	b4006ed4 	cbz	x20, 9054 <fwp_main_thread+0x1004>
    8280:	9101c260 	add	x0, x19, #0x70
    8284:	52800021 	mov	w1, #0x1                   	// #1
    8288:	39014a81 	strb	w1, [x20, #82]
    828c:	f9418005 	ldr	x5, [x0, #768]
    8290:	b4006e25 	cbz	x5, 9054 <fwp_main_thread+0x1004>
    8294:	d503201f 	nop
    8298:	394140a0 	ldrb	w0, [x5, #80]
    829c:	37000060 	tbnz	w0, #0, 82a8 <fwp_main_thread+0x258>
    82a0:	aa0503e0 	mov	x0, x5
    82a4:	97ffed33 	bl	3770 <fwp_cancel_tree.part.0>
    82a8:	f9409ca5 	ldr	x5, [x5, #312]
    82ac:	b5ffff65 	cbnz	x5, 8298 <fwp_main_thread+0x248>
    82b0:	9101c275 	add	x21, x19, #0x70
    82b4:	52800036 	mov	w22, #0x1                   	// #1
    82b8:	f9402a80 	ldr	x0, [x20, #80]
    82bc:	f2001c1f 	tst	x0, #0xff000000ff
    82c0:	540000e1 	b.ne	82dc <fwp_main_thread+0x28c>  // b.any
    82c4:	f9403ea0 	ldr	x0, [x21, #120]
    82c8:	39015296 	strb	w22, [x20, #84]
    82cc:	f900829f 	str	xzr, [x20, #256]
    82d0:	b4006b80 	cbz	x0, 9040 <fwp_main_thread+0xff0>
    82d4:	f9008014 	str	x20, [x0, #256]
    82d8:	f9003eb4 	str	x20, [x21, #120]
    82dc:	97fff8ea 	bl	6684 <fwp_block>
    82e0:	97fff87c 	bl	64d0 <fwp_free_zombie>
    82e4:	f94182a0 	ldr	x0, [x21, #768]
    82e8:	b4006b60 	cbz	x0, 9054 <fwp_main_thread+0x1004>
    82ec:	f941b2b4 	ldr	x20, [x21, #864]
    82f0:	17fffff2 	b	82b8 <fwp_main_thread+0x268>
    82f4:	f94196c0 	ldr	x0, [x22, #808]
    82f8:	b5006a80 	cbnz	x0, 9048 <fwp_main_thread+0xff8>
    82fc:	d2800014 	mov	x20, #0x0                   	// #0
    8300:	17ffffd7 	b	825c <fwp_main_thread+0x20c>
    8304:	97ffedbf 	bl	3a00 <fwp_now_ns>
    8308:	f94032a1 	ldr	x1, [x21, #96]
    830c:	eb01001f 	cmp	x0, x1
    8310:	540000ab 	b.lt	8324 <fwp_main_thread+0x2d4>  // b.tstop
    8314:	394142a0 	ldrb	w0, [x21, #80]
    8318:	37000060 	tbnz	w0, #0, 8324 <fwp_main_thread+0x2d4>
    831c:	aa1503e0 	mov	x0, x21
    8320:	97ffed14 	bl	3770 <fwp_cancel_tree.part.0>
    8324:	394146a0 	ldrb	w0, [x21, #81]
    8328:	39414a82 	ldrb	w2, [x20, #82]
    832c:	3707f380 	tbnz	w0, #0, 819c <fwp_main_thread+0x14c>
    8330:	f94032a1 	ldr	x1, [x21, #96]
    8334:	370001c2 	tbnz	w2, #0, 836c <fwp_main_thread+0x31c>
    8338:	f9403280 	ldr	x0, [x20, #96]
    833c:	b4000180 	cbz	x0, 836c <fwp_main_thread+0x31c>
    8340:	b4000061 	cbz	x1, 834c <fwp_main_thread+0x2fc>
    8344:	eb01001f 	cmp	x0, x1
    8348:	9a81d000 	csel	x0, x0, x1, le
    834c:	f94022a1 	ldr	x1, [x21, #64]
    8350:	a911fe98 	stp	x24, xzr, [x20, #280]
    8354:	f9009681 	str	x1, [x20, #296]
    8358:	b400efc1 	cbz	x1, a150 <fwp_main_thread+0x2100>
    835c:	f9009034 	str	x20, [x1, #288]
    8360:	aa0003e1 	mov	x1, x0
    8364:	f90022b4 	str	x20, [x21, #64]
    8368:	17ffff96 	b	81c0 <fwp_main_thread+0x170>
    836c:	f94022a0 	ldr	x0, [x21, #64]
    8370:	17ffff8e 	b	81a8 <fwp_main_thread+0x158>
    8374:	aa0203f4 	mov	x20, x2
    8378:	17ffff82 	b	8180 <fwp_main_thread+0x130>
    837c:	a911fe98 	stp	x24, xzr, [x20, #280]
    8380:	f9009680 	str	x0, [x20, #296]
    8384:	b4000040 	cbz	x0, 838c <fwp_main_thread+0x33c>
    8388:	f9009014 	str	x20, [x0, #288]
    838c:	f90022b4 	str	x20, [x21, #64]
    8390:	17ffff93 	b	81dc <fwp_main_thread+0x18c>
    8394:	f9000040 	str	x0, [x2]
    8398:	17ffff99 	b	81fc <fwp_main_thread+0x1ac>
    839c:	f9006ec0 	str	x0, [x22, #216]
    83a0:	17ffffa2 	b	8228 <fwp_main_thread+0x1d8>
    83a4:	f0ffffc0 	adrp	x0, 3000 <fwp_range_release+0x30>
    83a8:	91078000 	add	x0, x0, #0x1e0
    83ac:	940009a1 	bl	aa30 <atexit>
    83b0:	a91c63f7 	stp	x23, x24, [sp, #448]
    83b4:	3500f960 	cbnz	w0, a2e0 <fwp_main_thread+0x2290>
    83b8:	52800020 	mov	w0, #0x1                   	// #1
    83bc:	b90346a0 	str	w0, [x21, #836]
    83c0:	9101c260 	add	x0, x19, #0x70
    83c4:	b9434801 	ldr	w1, [x0, #840]
    83c8:	35ffeca1 	cbnz	w1, 815c <fwp_main_thread+0x10c>
    83cc:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    83d0:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    83d4:	f9418803 	ldr	x3, [x0, #784]
    83d8:	913f4042 	add	x2, x2, #0xfd0
    83dc:	a91e73fb 	stp	x27, x28, [sp, #480]
    83e0:	9117403c 	add	x28, x1, #0x5d0
    83e4:	b0ffffe1 	adrp	x1, 5000 <fwp_heap_alloc+0x90>
    83e8:	91284021 	add	x1, x1, #0xa10
    83ec:	a9070be3 	stp	x3, x2, [sp, #112]
    83f0:	d2804018 	mov	x24, #0x200                 	// #512
    83f4:	f9400be2 	ldr	x2, [sp, #16]
    83f8:	a90987ff 	stp	xzr, x1, [sp, #152]
    83fc:	d2800015 	mov	x21, #0x0                   	// #0
    8400:	f94013e1 	ldr	x1, [sp, #32]
    8404:	a91d6bf9 	stp	x25, x26, [sp, #464]
    8408:	52800036 	mov	w22, #0x1                   	// #1
    840c:	fd00fbe8 	str	d8, [sp, #496]
    8410:	f9000fff 	str	xzr, [sp, #24]
    8414:	f90043e2 	str	x2, [sp, #128]
    8418:	f90047ff 	str	xzr, [sp, #136]
    841c:	f9018801 	str	x1, [x0, #784]
    8420:	f9400fe2 	ldr	x2, [sp, #24]
    8424:	f1000719 	subs	x25, x24, #0x1
    8428:	aa1403e1 	mov	x1, x20
    842c:	da1f02bb 	sbc	x27, x21, xzr
    8430:	52800020 	mov	w0, #0x1                   	// #1
    8434:	f9004bf9 	str	x25, [sp, #144]
    8438:	a90f0bf9 	stp	x25, x2, [sp, #240]
    843c:	97fff312 	bl	5084 <fwp_data.part.0.constprop.0>
    8440:	aa0003e2 	mov	x2, x0
    8444:	f949db81 	ldr	x1, [x28, #5040]
    8448:	f9000fe2 	str	x2, [sp, #24]
    844c:	f949ef80 	ldr	x0, [x28, #5080]
    8450:	cb010041 	sub	x1, x2, x1
    8454:	aa1903f8 	mov	x24, x25
    8458:	aa1b03f5 	mov	x21, x27
    845c:	eb00403f 	cmp	x1, x0, lsl #16
    8460:	54000302 	b.cs	84c0 <fwp_main_thread+0x470>  // b.hs, b.nlast
    8464:	d350fc20 	lsr	x0, x1, #16
    8468:	f949ff83 	ldr	x3, [x28, #5112]
    846c:	8b000800 	add	x0, x0, x0, lsl #2
    8470:	d37df002 	lsl	x2, x0, #3
    8474:	8b020060 	add	x0, x3, x2
    8478:	f9401017 	ldr	x23, [x0, #32]
    847c:	b4000237 	cbz	x23, 84c0 <fwp_main_thread+0x470>
    8480:	38626862 	ldrb	w2, [x3, x2]
    8484:	7100085f 	cmp	w2, #0x2
    8488:	54006940 	b.eq	91b0 <fwp_main_thread+0x1160>  // b.none
    848c:	7100045f 	cmp	w2, #0x1
    8490:	54000181 	b.ne	84c0 <fwp_main_thread+0x470>  // b.any
    8494:	29430002 	ldp	w2, w0, [x0, #24]
    8498:	92403c21 	and	x1, x1, #0xffff
    849c:	9b027c21 	mul	x1, x1, x2
    84a0:	d360fc21 	lsr	x1, x1, #32
    84a4:	eb00003f 	cmp	x1, x0
    84a8:	540000c2 	b.cs	84c0 <fwp_main_thread+0x470>  // b.hs, b.nlast
    84ac:	8b0102f7 	add	x23, x23, x1
    84b0:	394002e0 	ldrb	w0, [x23]
    84b4:	7103fc1f 	cmp	w0, #0xff
    84b8:	54006860 	b.eq	91c4 <fwp_main_thread+0x1174>  // b.none
    84bc:	390002f6 	strb	w22, [x23]
    84c0:	f9400fe0 	ldr	x0, [sp, #24]
    84c4:	f90047e0 	str	x0, [sp, #136]
    84c8:	aa1b0320 	orr	x0, x25, x27
    84cc:	b5fffaa0 	cbnz	x0, 8420 <fwp_main_thread+0x3d0>
    84d0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    84d4:	9101c262 	add	x2, x19, #0x70
    84d8:	f9403bf6 	ldr	x22, [sp, #112]
    84dc:	910303e1 	add	x1, sp, #0xc0
    84e0:	3dc21800 	ldr	q0, [x0, #2144]
    84e4:	52800020 	mov	w0, #0x1                   	// #1
    84e8:	f9018856 	str	x22, [x2, #784]
    84ec:	3d8033e0 	str	q0, [sp, #192]
    84f0:	97fff2e5 	bl	5084 <fwp_data.part.0.constprop.0>
    84f4:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    84f8:	91174022 	add	x2, x1, #0x5d0
    84fc:	aa0003f7 	mov	x23, x0
    8500:	f949d841 	ldr	x1, [x2, #5040]
    8504:	f949ec40 	ldr	x0, [x2, #5080]
    8508:	cb0102e1 	sub	x1, x23, x1
    850c:	eb00403f 	cmp	x1, x0, lsl #16
    8510:	54000322 	b.cs	8574 <fwp_main_thread+0x524>  // b.hs, b.nlast
    8514:	d350fc20 	lsr	x0, x1, #16
    8518:	f949fc43 	ldr	x3, [x2, #5112]
    851c:	8b000800 	add	x0, x0, x0, lsl #2
    8520:	d37df002 	lsl	x2, x0, #3
    8524:	8b020060 	add	x0, x3, x2
    8528:	f9401015 	ldr	x21, [x0, #32]
    852c:	b4000255 	cbz	x21, 8574 <fwp_main_thread+0x524>
    8530:	38626862 	ldrb	w2, [x3, x2]
    8534:	7100085f 	cmp	w2, #0x2
    8538:	5400dfa0 	b.eq	a12c <fwp_main_thread+0x20dc>  // b.none
    853c:	7100045f 	cmp	w2, #0x1
    8540:	540001a1 	b.ne	8574 <fwp_main_thread+0x524>  // b.any
    8544:	29430002 	ldp	w2, w0, [x0, #24]
    8548:	92403c21 	and	x1, x1, #0xffff
    854c:	9b027c21 	mul	x1, x1, x2
    8550:	d360fc21 	lsr	x1, x1, #32
    8554:	eb00003f 	cmp	x1, x0
    8558:	540000e2 	b.cs	8574 <fwp_main_thread+0x524>  // b.hs, b.nlast
    855c:	8b0102b5 	add	x21, x21, x1
    8560:	394002a0 	ldrb	w0, [x21]
    8564:	7103fc1f 	cmp	w0, #0xff
    8568:	5400e900 	b.eq	a288 <fwp_main_thread+0x2238>  // b.none
    856c:	52800020 	mov	w0, #0x1                   	// #1
    8570:	390002a0 	strb	w0, [x21]
    8574:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8578:	910383e1 	add	x1, sp, #0xe0
    857c:	52800020 	mov	w0, #0x1                   	// #1
    8580:	a90e5fe2 	stp	x2, x23, [sp, #224]
    8584:	97fff2c0 	bl	5084 <fwp_data.part.0.constprop.0>
    8588:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    858c:	91174022 	add	x2, x1, #0x5d0
    8590:	aa0003f7 	mov	x23, x0
    8594:	f949d841 	ldr	x1, [x2, #5040]
    8598:	f949ec40 	ldr	x0, [x2, #5080]
    859c:	cb0102e1 	sub	x1, x23, x1
    85a0:	eb00403f 	cmp	x1, x0, lsl #16
    85a4:	54000322 	b.cs	8608 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    85a8:	d350fc20 	lsr	x0, x1, #16
    85ac:	f949fc43 	ldr	x3, [x2, #5112]
    85b0:	8b000800 	add	x0, x0, x0, lsl #2
    85b4:	d37df002 	lsl	x2, x0, #3
    85b8:	8b020060 	add	x0, x3, x2
    85bc:	f9401015 	ldr	x21, [x0, #32]
    85c0:	b4000255 	cbz	x21, 8608 <fwp_main_thread+0x5b8>
    85c4:	38626862 	ldrb	w2, [x3, x2]
    85c8:	7100085f 	cmp	w2, #0x2
    85cc:	5400dbc0 	b.eq	a144 <fwp_main_thread+0x20f4>  // b.none
    85d0:	7100045f 	cmp	w2, #0x1
    85d4:	540001a1 	b.ne	8608 <fwp_main_thread+0x5b8>  // b.any
    85d8:	29430002 	ldp	w2, w0, [x0, #24]
    85dc:	92403c21 	and	x1, x1, #0xffff
    85e0:	9b027c21 	mul	x1, x1, x2
    85e4:	d360fc21 	lsr	x1, x1, #32
    85e8:	eb00003f 	cmp	x1, x0
    85ec:	540000e2 	b.cs	8608 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    85f0:	8b0102b5 	add	x21, x21, x1
    85f4:	394002a0 	ldrb	w0, [x21]
    85f8:	7103fc1f 	cmp	w0, #0xff
    85fc:	5400e4c0 	b.eq	a294 <fwp_main_thread+0x2244>  // b.none
    8600:	52800020 	mov	w0, #0x1                   	// #1
    8604:	390002a0 	strb	w0, [x21]
    8608:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    860c:	910343e1 	add	x1, sp, #0xd0
    8610:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8614:	52800020 	mov	w0, #0x1                   	// #1
    8618:	a90d5fe2 	stp	x2, x23, [sp, #208]
    861c:	97fff29a 	bl	5084 <fwp_data.part.0.constprop.0>
    8620:	b0000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    8624:	91174022 	add	x2, x1, #0x5d0
    8628:	aa0003f5 	mov	x21, x0
    862c:	f949d841 	ldr	x1, [x2, #5040]
    8630:	f949ec40 	ldr	x0, [x2, #5080]
    8634:	cb0102a1 	sub	x1, x21, x1
    8638:	eb00403f 	cmp	x1, x0, lsl #16
    863c:	54000322 	b.cs	86a0 <fwp_main_thread+0x650>  // b.hs, b.nlast
    8640:	d350fc20 	lsr	x0, x1, #16
    8644:	f949fc43 	ldr	x3, [x2, #5112]
    8648:	8b000800 	add	x0, x0, x0, lsl #2
    864c:	d37df002 	lsl	x2, x0, #3
    8650:	8b020060 	add	x0, x3, x2
    8654:	f9401017 	ldr	x23, [x0, #32]
    8658:	b4000257 	cbz	x23, 86a0 <fwp_main_thread+0x650>
    865c:	38626862 	ldrb	w2, [x3, x2]
    8660:	7100085f 	cmp	w2, #0x2
    8664:	5400d6a0 	b.eq	a138 <fwp_main_thread+0x20e8>  // b.none
    8668:	7100045f 	cmp	w2, #0x1
    866c:	540001a1 	b.ne	86a0 <fwp_main_thread+0x650>  // b.any
    8670:	29430002 	ldp	w2, w0, [x0, #24]
    8674:	92403c21 	and	x1, x1, #0xffff
    8678:	9b027c21 	mul	x1, x1, x2
    867c:	d360fc21 	lsr	x1, x1, #32
    8680:	eb00003f 	cmp	x1, x0
    8684:	540000e2 	b.cs	86a0 <fwp_main_thread+0x650>  // b.hs, b.nlast
    8688:	8b0102f7 	add	x23, x23, x1
    868c:	394002e0 	ldrb	w0, [x23]
    8690:	7103fc1f 	cmp	w0, #0xff
    8694:	5400e060 	b.eq	a2a0 <fwp_main_thread+0x2250>  // b.none
    8698:	52800020 	mov	w0, #0x1                   	// #1
    869c:	390002e0 	strb	w0, [x23]
    86a0:	f9400fe0 	ldr	x0, [sp, #24]
    86a4:	b400c3c0 	cbz	x0, 9f1c <fwp_main_thread+0x1ecc>
    86a8:	900000c0 	adrp	x0, 20000 <__data_start>
    86ac:	91004000 	add	x0, x0, #0x10
    86b0:	9100e000 	add	x0, x0, #0x38
    86b4:	f9001fe0 	str	x0, [sp, #56]
    86b8:	f9400fe0 	ldr	x0, [sp, #24]
    86bc:	f90027e0 	str	x0, [sp, #72]
    86c0:	910143e0 	add	x0, sp, #0x50
    86c4:	f90017e0 	str	x0, [sp, #40]
    86c8:	910163e0 	add	x0, sp, #0x58
    86cc:	f9001be0 	str	x0, [sp, #48]
    86d0:	b0000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    86d4:	9117401a 	add	x26, x0, #0x5d0
    86d8:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    86dc:	fd443808 	ldr	d8, [x0, #2160]
    86e0:	f949ef46 	ldr	x6, [x26, #5080]
    86e4:	f949db43 	ldr	x3, [x26, #5040]
    86e8:	d370bcc6 	lsl	x6, x6, #16
    86ec:	cb0302a2 	sub	x2, x21, x3
    86f0:	eb06005f 	cmp	x2, x6
    86f4:	540003a2 	b.cs	8768 <fwp_main_thread+0x718>  // b.hs, b.nlast
    86f8:	d350fc40 	lsr	x0, x2, #16
    86fc:	f949ff47 	ldr	x7, [x26, #5112]
    8700:	8b000800 	add	x0, x0, x0, lsl #2
    8704:	d37df001 	lsl	x1, x0, #3
    8708:	8b0100e5 	add	x5, x7, x1
    870c:	f94010a0 	ldr	x0, [x5, #32]
    8710:	b40002c0 	cbz	x0, 8768 <fwp_main_thread+0x718>
    8714:	386168e1 	ldrb	w1, [x7, x1]
    8718:	7100083f 	cmp	w1, #0x2
    871c:	5400c2a0 	b.eq	9f70 <fwp_main_thread+0x1f20>  // b.none
    8720:	7100043f 	cmp	w1, #0x1
    8724:	54000221 	b.ne	8768 <fwp_main_thread+0x718>  // b.any
    8728:	92403c41 	and	x1, x2, #0xffff
    872c:	294308a7 	ldp	w7, w2, [x5, #24]
    8730:	9b077c21 	mul	x1, x1, x7
    8734:	d360fc21 	lsr	x1, x1, #32
    8738:	eb02003f 	cmp	x1, x2
    873c:	54000162 	b.cs	8768 <fwp_main_thread+0x718>  // b.hs, b.nlast
    8740:	8b010000 	add	x0, x0, x1
    8744:	39400001 	ldrb	w1, [x0]
    8748:	34000101 	cbz	w1, 8768 <fwp_main_thread+0x718>
    874c:	7103f43f 	cmp	w1, #0xfd
    8750:	5400d4e8 	b.hi	a1ec <fwp_main_thread+0x219c>  // b.pmore
    8754:	11000421 	add	w1, w1, #0x1
    8758:	39000001 	strb	w1, [x0]
    875c:	f949ef46 	ldr	x6, [x26, #5080]
    8760:	f949db43 	ldr	x3, [x26, #5040]
    8764:	d370bcc6 	lsl	x6, x6, #16
    8768:	f9401fe1 	ldr	x1, [sp, #56]
    876c:	9101c260 	add	x0, x19, #0x70
    8770:	12800002 	mov	w2, #0xffffffff            	// #-1
    8774:	b90053e2 	str	w2, [sp, #80]
    8778:	cb030023 	sub	x3, x1, x3
    877c:	d0ffffe1 	adrp	x1, 6000 <fwp_tape_finish+0xd0>
    8780:	9100c021 	add	x1, x1, #0x30
    8784:	a90587f6 	stp	x22, x1, [sp, #88]
    8788:	f94017e1 	ldr	x1, [sp, #40]
    878c:	f90037e1 	str	x1, [sp, #104]
    8790:	f9401be1 	ldr	x1, [sp, #48]
    8794:	f9018801 	str	x1, [x0, #784]
    8798:	eb0300df 	cmp	x6, x3
    879c:	54000769 	b.ls	8888 <fwp_main_thread+0x838>  // b.plast
    87a0:	d350fc60 	lsr	x0, x3, #16
    87a4:	f949ff45 	ldr	x5, [x26, #5112]
    87a8:	8b000800 	add	x0, x0, x0, lsl #2
    87ac:	d37df002 	lsl	x2, x0, #3
    87b0:	8b0200a1 	add	x1, x5, x2
    87b4:	f9401036 	ldr	x22, [x1, #32]
    87b8:	b4000696 	cbz	x22, 8888 <fwp_main_thread+0x838>
    87bc:	386268a0 	ldrb	w0, [x5, x2]
    87c0:	7100081f 	cmp	w0, #0x2
    87c4:	5400ade0 	b.eq	9d80 <fwp_main_thread+0x1d30>  // b.none
    87c8:	7100041f 	cmp	w0, #0x1
    87cc:	540005e1 	b.ne	8888 <fwp_main_thread+0x838>  // b.any
    87d0:	29430825 	ldp	w5, w2, [x1, #24]
    87d4:	92403c60 	and	x0, x3, #0xffff
    87d8:	9b057c00 	mul	x0, x0, x5
    87dc:	d360fc00 	lsr	x0, x0, #32
    87e0:	eb02001f 	cmp	x0, x2
    87e4:	54000282 	b.cs	8834 <fwp_main_thread+0x7e4>  // b.hs, b.nlast
    87e8:	8b0002c0 	add	x0, x22, x0
    87ec:	39400002 	ldrb	w2, [x0]
    87f0:	34000222 	cbz	w2, 8834 <fwp_main_thread+0x7e4>
    87f4:	7103f45f 	cmp	w2, #0xfd
    87f8:	5400c688 	b.hi	a0c8 <fwp_main_thread+0x2078>  // b.pmore
    87fc:	11000442 	add	w2, w2, #0x1
    8800:	39000002 	strb	w2, [x0]
    8804:	f9401fe1 	ldr	x1, [sp, #56]
    8808:	f949db43 	ldr	x3, [x26, #5040]
    880c:	f949ef40 	ldr	x0, [x26, #5080]
    8810:	cb030023 	sub	x3, x1, x3
    8814:	eb00407f 	cmp	x3, x0, lsl #16
    8818:	54000382 	b.cs	8888 <fwp_main_thread+0x838>  // b.hs, b.nlast
    881c:	f949ff40 	ldr	x0, [x26, #5112]
    8820:	d350fc61 	lsr	x1, x3, #16
    8824:	8b010821 	add	x1, x1, x1, lsl #2
    8828:	8b010c01 	add	x1, x0, x1, lsl #3
    882c:	f9401036 	ldr	x22, [x1, #32]
    8830:	b40002d6 	cbz	x22, 8888 <fwp_main_thread+0x838>
    8834:	39400020 	ldrb	w0, [x1]
    8838:	7100081f 	cmp	w0, #0x2
    883c:	5400aaa0 	b.eq	9d90 <fwp_main_thread+0x1d40>  // b.none
    8840:	7100041f 	cmp	w0, #0x1
    8844:	54000221 	b.ne	8888 <fwp_main_thread+0x838>  // b.any
    8848:	29430022 	ldp	w2, w0, [x1, #24]
    884c:	92403c63 	and	x3, x3, #0xffff
    8850:	9b027c61 	mul	x1, x3, x2
    8854:	d360fc21 	lsr	x1, x1, #32
    8858:	eb00003f 	cmp	x1, x0
    885c:	54000162 	b.cs	8888 <fwp_main_thread+0x838>  // b.hs, b.nlast
    8860:	8b0102d6 	add	x22, x22, x1
    8864:	394002c1 	ldrb	w1, [x22]
    8868:	34000101 	cbz	w1, 8888 <fwp_main_thread+0x838>
    886c:	7100043f 	cmp	w1, #0x1
    8870:	54008e60 	b.eq	9a3c <fwp_main_thread+0x19ec>  // b.none
    8874:	7103fc3f 	cmp	w1, #0xff
    8878:	5400c2c0 	b.eq	a0d0 <fwp_main_thread+0x2080>  // b.none
    887c:	51000421 	sub	w1, w1, #0x1
    8880:	390002c1 	strb	w1, [x22]
    8884:	d503201f 	nop
    8888:	b4008eb5 	cbz	x21, 9a5c <fwp_main_thread+0x1a0c>
    888c:	aa1503e0 	mov	x0, x21
    8890:	d2800016 	mov	x22, #0x0                   	// #0
    8894:	d503201f 	nop
    8898:	f9400800 	ldr	x0, [x0, #16]
    889c:	910006d6 	add	x22, x22, #0x1
    88a0:	b5ffffc0 	cbnz	x0, 8898 <fwp_main_thread+0x848>
    88a4:	52800000 	mov	w0, #0x0                   	// #0
    88a8:	97ffeb72 	bl	3670 <descent_phase_step>
    88ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    88b0:	eb0002df 	cmp	x22, x0
    88b4:	5400d368 	b.hi	a320 <fwp_main_thread+0x22d0>  // b.pmore
    88b8:	9101c277 	add	x23, x19, #0x70
    88bc:	b9434ee0 	ldr	w0, [x23, #844]
    88c0:	34008dc0 	cbz	w0, 9a78 <fwp_main_thread+0x1a28>
    88c4:	9101c260 	add	x0, x19, #0x70
    88c8:	f9404817 	ldr	x23, [x0, #144]
    88cc:	f9407401 	ldr	x1, [x0, #232]
    88d0:	eb17003f 	cmp	x1, x23
    88d4:	54008eaa 	b.ge	9aa8 <fwp_main_thread+0x1a58>  // b.tcont
    88d8:	f9403a62 	ldr	x2, [x19, #112]
    88dc:	8b010420 	add	x0, x1, x1, lsl #1
    88e0:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    88e4:	8b000820 	add	x0, x1, x0, lsl #2
    88e8:	8b000c40 	add	x0, x2, x0, lsl #3
    88ec:	d503201f 	nop
    88f0:	b9400402 	ldr	w2, [x0, #4]
    88f4:	35000082 	cbnz	w2, 8904 <fwp_main_thread+0x8b4>
    88f8:	b9400002 	ldr	w2, [x0]
    88fc:	6b03005f 	cmp	w2, w3
    8900:	54008d49 	b.ls	9aa8 <fwp_main_thread+0x1a58>  // b.plast
    8904:	91000421 	add	x1, x1, #0x1
    8908:	9101a000 	add	x0, x0, #0x68
    890c:	eb17003f 	cmp	x1, x23
    8910:	54ffff01 	b.ne	88f0 <fwp_main_thread+0x8a0>  // b.any
    8914:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8918:	eb0002ff 	cmp	x23, x0
    891c:	5400d08c 	b.gt	a32c <fwp_main_thread+0x22dc>
    8920:	9101c260 	add	x0, x19, #0x70
    8924:	f9403a7b 	ldr	x27, [x19, #112]
    8928:	f9407000 	ldr	x0, [x0, #224]
    892c:	eb17001f 	cmp	x0, x23
    8930:	54000201 	b.ne	8970 <fwp_main_thread+0x920>  // b.any
    8934:	b400ad17 	cbz	x23, 9ed4 <fwp_main_thread+0x1e84>
    8938:	d37ffaf8 	lsl	x24, x23, #1
    893c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8940:	eb00031f 	cmp	x24, x0
    8944:	9a80d318 	csel	x24, x24, x0, le
    8948:	8b180701 	add	x1, x24, x24, lsl #1
    894c:	8b010b01 	add	x1, x24, x1, lsl #2
    8950:	d37df021 	lsl	x1, x1, #3
    8954:	aa1b03e0 	mov	x0, x27
    8958:	97ffe7ea 	bl	2900 <realloc@plt>
    895c:	aa0003fb 	mov	x27, x0
    8960:	b4004620 	cbz	x0, 9224 <fwp_main_thread+0x11d4>
    8964:	9101c260 	add	x0, x19, #0x70
    8968:	f9003a7b 	str	x27, [x19, #112]
    896c:	f9007018 	str	x24, [x0, #224]
    8970:	d37ffae1 	lsl	x1, x23, #1
    8974:	9101c260 	add	x0, x19, #0x70
    8978:	8b170022 	add	x2, x1, x23
    897c:	8b170021 	add	x1, x1, x23
    8980:	4f000400 	movi	v0.4s, #0x0
    8984:	910006fc 	add	x28, x23, #0x1
    8988:	8b020ae2 	add	x2, x23, x2, lsl #2
    898c:	8b010ae1 	add	x1, x23, x1, lsl #2
    8990:	f900481c 	str	x28, [x0, #144]
    8994:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    8998:	8b020f62 	add	x2, x27, x2, lsl #3
    899c:	8b010f78 	add	x24, x27, x1, lsl #3
    89a0:	91354000 	add	x0, x0, #0xd50
    89a4:	ad000040 	stp	q0, q0, [x2]
    89a8:	ad010040 	stp	q0, q0, [x2, #32]
    89ac:	ad020040 	stp	q0, q0, [x2, #64]
    89b0:	f900305f 	str	xzr, [x2, #96]
    89b4:	f900331f 	str	xzr, [x24, #96]
    89b8:	97ffe83a 	bl	2aa0 <getenv@plt>
    89bc:	b4008920 	cbz	x0, 9ae0 <fwp_main_thread+0x1a90>
    89c0:	39400001 	ldrb	w1, [x0]
    89c4:	7100c03f 	cmp	w1, #0x30
    89c8:	540088c1 	b.ne	9ae0 <fwp_main_thread+0x1a90>  // b.any
    89cc:	39400400 	ldrb	w0, [x0, #1]
    89d0:	35008880 	cbnz	w0, 9ae0 <fwp_main_thread+0x1a90>
    89d4:	9101c260 	add	x0, x19, #0x70
    89d8:	b9400305 	ldr	w5, [x24]
    89dc:	52800021 	mov	w1, #0x1                   	// #1
    89e0:	2f000400 	mvni	v0.2s, #0x0
    89e4:	110004a5 	add	w5, w5, #0x1
    89e8:	29000705 	stp	w5, w1, [x24]
    89ec:	f9418801 	ldr	x1, [x0, #784]
    89f0:	a900db16 	stp	x22, x22, [x24, #8]
    89f4:	f9002b1f 	str	xzr, [x24, #80]
    89f8:	f900741c 	str	x28, [x0, #232]
    89fc:	fd002f00 	str	d0, [x24, #88]
    8a00:	b400c561 	cbz	x1, a2ac <fwp_main_thread+0x225c>
    8a04:	d0ffffe0 	adrp	x0, 6000 <fwp_tape_finish+0xd0>
    8a08:	9100c003 	add	x3, x0, #0x30
    8a0c:	14000003 	b	8a18 <fwp_main_thread+0x9c8>
    8a10:	f9400021 	ldr	x1, [x1]
    8a14:	b400c4c1 	cbz	x1, a2ac <fwp_main_thread+0x225c>
    8a18:	f9400422 	ldr	x2, [x1, #8]
    8a1c:	eb03005f 	cmp	x2, x3
    8a20:	54ffff81 	b.ne	8a10 <fwp_main_thread+0x9c0>  // b.any
    8a24:	f9400820 	ldr	x0, [x1, #16]
    8a28:	2a1703e2 	mov	w2, w23
    8a2c:	b9400001 	ldr	w1, [x0]
    8a30:	f9002b00 	str	x0, [x24, #80]
    8a34:	b9005f01 	str	w1, [x24, #92]
    8a38:	37f80081 	tbnz	w1, #31, 8a48 <fwp_main_thread+0x9f8>
    8a3c:	52800d03 	mov	w3, #0x68                  	// #104
    8a40:	9b236c21 	smaddl	x1, w1, w3, x27
    8a44:	b9005837 	str	w23, [x1, #88]
    8a48:	b9000002 	str	w2, [x0]
    8a4c:	d3707cb6 	ubfiz	x22, x5, #16, #32
    8a50:	52800020 	mov	w0, #0x1                   	// #1
    8a54:	aa1c02d6 	orr	x22, x22, x28
    8a58:	97ffeb06 	bl	3670 <descent_phase_step>
    8a5c:	aa1503e0 	mov	x0, x21
    8a60:	d2800002 	mov	x2, #0x0                   	// #0
    8a64:	b4008cd5 	cbz	x21, 9bfc <fwp_main_thread+0x1bac>
    8a68:	f9400800 	ldr	x0, [x0, #16]
    8a6c:	91000442 	add	x2, x2, #0x1
    8a70:	b5ffffc0 	cbnz	x0, 8a68 <fwp_main_thread+0xa18>
    8a74:	aa1503e1 	mov	x1, x21
    8a78:	f9400821 	ldr	x1, [x1, #16]
    8a7c:	91000400 	add	x0, x0, #0x1
    8a80:	b5ffffc1 	cbnz	x1, 8a78 <fwp_main_thread+0xa28>
    8a84:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8a88:	eb01001f 	cmp	x0, x1
    8a8c:	5400bf28 	b.hi	a270 <fwp_main_thread+0x2220>  // b.pmore
    8a90:	f100005f 	cmp	x2, #0x0
    8a94:	54008b4d 	b.le	9bfc <fwp_main_thread+0x1bac>
    8a98:	eb00005f 	cmp	x2, x0
    8a9c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8aa0:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8aa4:	eb0102ff 	cmp	x23, x1
    8aa8:	5400be48 	b.hi	a270 <fwp_main_thread+0x2220>  // b.pmore
    8aac:	d37ffafc 	lsl	x28, x23, #1
    8ab0:	52800041 	mov	w1, #0x2                   	// #2
    8ab4:	91000780 	add	x0, x28, #0x1
    8ab8:	d37df000 	lsl	x0, x0, #3
    8abc:	97fff12d 	bl	4f70 <fwp_heap_alloc>
    8ac0:	f900001c 	str	x28, [x0]
    8ac4:	aa0003f8 	mov	x24, x0
    8ac8:	aa0003fb 	mov	x27, x0
    8acc:	f949db41 	ldr	x1, [x26, #5040]
    8ad0:	f949ef40 	ldr	x0, [x26, #5080]
    8ad4:	cb010301 	sub	x1, x24, x1
    8ad8:	eb00403f 	cmp	x1, x0, lsl #16
    8adc:	54008b22 	b.cs	9c40 <fwp_main_thread+0x1bf0>  // b.hs, b.nlast
    8ae0:	d350fc20 	lsr	x0, x1, #16
    8ae4:	f949ff43 	ldr	x3, [x26, #5112]
    8ae8:	8b000800 	add	x0, x0, x0, lsl #2
    8aec:	d37df002 	lsl	x2, x0, #3
    8af0:	8b020060 	add	x0, x3, x2
    8af4:	f940101c 	ldr	x28, [x0, #32]
    8af8:	b400025c 	cbz	x28, 8b40 <fwp_main_thread+0xaf0>
    8afc:	38626862 	ldrb	w2, [x3, x2]
    8b00:	7100085f 	cmp	w2, #0x2
    8b04:	540094c0 	b.eq	9d9c <fwp_main_thread+0x1d4c>  // b.none
    8b08:	7100045f 	cmp	w2, #0x1
    8b0c:	540001a1 	b.ne	8b40 <fwp_main_thread+0xaf0>  // b.any
    8b10:	29430002 	ldp	w2, w0, [x0, #24]
    8b14:	92403c21 	and	x1, x1, #0xffff
    8b18:	9b027c21 	mul	x1, x1, x2
    8b1c:	d360fc21 	lsr	x1, x1, #32
    8b20:	eb00003f 	cmp	x1, x0
    8b24:	540000e2 	b.cs	8b40 <fwp_main_thread+0xaf0>  // b.hs, b.nlast
    8b28:	8b01039c 	add	x28, x28, x1
    8b2c:	39400380 	ldrb	w0, [x28]
    8b30:	7103fc1f 	cmp	w0, #0xff
    8b34:	540093e0 	b.eq	9db0 <fwp_main_thread+0x1d60>  // b.none
    8b38:	52800020 	mov	w0, #0x1                   	// #1
    8b3c:	39000380 	strb	w0, [x28]
    8b40:	b4000237 	cbz	x23, 8b84 <fwp_main_thread+0xb34>
    8b44:	d3607ec5 	lsl	x5, x22, #32
    8b48:	aa1503e1 	mov	x1, x21
    8b4c:	f94006a6 	ldr	x6, [x21, #8]
    8b50:	aa0503e3 	mov	x3, x5
    8b54:	91002302 	add	x2, x24, #0x8
    8b58:	d2800000 	mov	x0, #0x0                   	// #0
    8b5c:	14000005 	b	8b70 <fwp_main_thread+0xb20>
    8b60:	f9400426 	ldr	x6, [x1, #8]
    8b64:	ab050003 	adds	x3, x0, x5
    8b68:	91004042 	add	x2, x2, #0x10
    8b6c:	5400be66 	b.vs	a338 <fwp_main_thread+0x22e8>
    8b70:	a9000c46 	stp	x6, x3, [x2]
    8b74:	91000400 	add	x0, x0, #0x1
    8b78:	f9400821 	ldr	x1, [x1, #16]
    8b7c:	eb17001f 	cmp	x0, x23
    8b80:	54ffff03 	b.cc	8b60 <fwp_main_thread+0xb10>  // b.lo, b.ul, b.last
    8b84:	f9400300 	ldr	x0, [x24]
    8b88:	f100041f 	cmp	x0, #0x1
    8b8c:	540085e9 	b.ls	9c48 <fwp_main_thread+0x1bf8>  // b.plast
    8b90:	d341fc00 	lsr	x0, x0, #1
    8b94:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8b98:	d1000401 	sub	x1, x0, #0x1
    8b9c:	eb02003f 	cmp	x1, x2
    8ba0:	5400b688 	b.hi	a270 <fwp_main_thread+0x2220>  // b.pmore
    8ba4:	d37ff83c 	lsl	x28, x1, #1
    8ba8:	b4008501 	cbz	x1, 9c48 <fwp_main_thread+0x1bf8>
    8bac:	d1002301 	sub	x1, x24, #0x8
    8bb0:	91002319 	add	x25, x24, #0x8
    8bb4:	8b001037 	add	x23, x1, x0, lsl #4
    8bb8:	f9400720 	ldr	x0, [x25, #8]
    8bbc:	f9400f21 	ldr	x1, [x25, #24]
    8bc0:	fd400320 	ldr	d0, [x25]
    8bc4:	fd400b21 	ldr	d1, [x25, #16]
    8bc8:	97fff22a 	bl	5470 <w120>
    8bcc:	a9000720 	stp	x0, x1, [x25]
    8bd0:	91004339 	add	x25, x25, #0x10
    8bd4:	eb17033f 	cmp	x25, x23
    8bd8:	54ffff01 	b.ne	8bb8 <fwp_main_thread+0xb68>  // b.any
    8bdc:	f900031c 	str	x28, [x24]
    8be0:	aa1803e0 	mov	x0, x24
    8be4:	97fff267 	bl	5580 <w176.constprop.0>
    8be8:	aa0103fc 	mov	x28, x1
    8bec:	f949db40 	ldr	x0, [x26, #5040]
    8bf0:	f949ef42 	ldr	x2, [x26, #5080]
    8bf4:	cb000301 	sub	x1, x24, x0
    8bf8:	eb02403f 	cmp	x1, x2, lsl #16
    8bfc:	540003a2 	b.cs	8c70 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    8c00:	d350fc20 	lsr	x0, x1, #16
    8c04:	f949ff45 	ldr	x5, [x26, #5112]
    8c08:	8b000800 	add	x0, x0, x0, lsl #2
    8c0c:	d37df000 	lsl	x0, x0, #3
    8c10:	8b0000a2 	add	x2, x5, x0
    8c14:	f9401057 	ldr	x23, [x2, #32]
    8c18:	b40002d7 	cbz	x23, 8c70 <fwp_main_thread+0xc20>
    8c1c:	386068a0 	ldrb	w0, [x5, x0]
    8c20:	7100081f 	cmp	w0, #0x2
    8c24:	54008160 	b.eq	9c50 <fwp_main_thread+0x1c00>  // b.none
    8c28:	7100041f 	cmp	w0, #0x1
    8c2c:	54000221 	b.ne	8c70 <fwp_main_thread+0xc20>  // b.any
    8c30:	29430043 	ldp	w3, w0, [x2, #24]
    8c34:	92403c21 	and	x1, x1, #0xffff
    8c38:	9b037c21 	mul	x1, x1, x3
    8c3c:	d360fc21 	lsr	x1, x1, #32
    8c40:	eb00003f 	cmp	x1, x0
    8c44:	54000162 	b.cs	8c70 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    8c48:	8b0102f7 	add	x23, x23, x1
    8c4c:	394002e0 	ldrb	w0, [x23]
    8c50:	34000100 	cbz	w0, 8c70 <fwp_main_thread+0xc20>
    8c54:	7100041f 	cmp	w0, #0x1
    8c58:	54002fe0 	b.eq	9254 <fwp_main_thread+0x1204>  // b.none
    8c5c:	7103fc1f 	cmp	w0, #0xff
    8c60:	54009c40 	b.eq	9fe8 <fwp_main_thread+0x1f98>  // b.none
    8c64:	51000400 	sub	w0, w0, #0x1
    8c68:	390002e0 	strb	w0, [x23]
    8c6c:	d503201f 	nop
    8c70:	52800040 	mov	w0, #0x2                   	// #2
    8c74:	93407ed6 	sxtw	x22, w22
    8c78:	97ffea7e 	bl	3670 <descent_phase_step>
    8c7c:	aa1603e0 	mov	x0, x22
    8c80:	97ffebcc 	bl	3bb0 <fwp_tape_of>
    8c84:	f9403001 	ldr	x1, [x0, #96]
    8c88:	aa0003e6 	mov	x6, x0
    8c8c:	b500b441 	cbnz	x1, a314 <fwp_main_thread+0x22c4>
    8c90:	97ffe8e0 	bl	3010 <fwp_tape_unlink_scope>
    8c94:	b90004df 	str	wzr, [x6, #4]
    8c98:	a94288d8 	ldp	x24, x2, [x6, #40]
    8c9c:	f90003e2 	str	x2, [sp]
    8ca0:	f9401cc2 	ldr	x2, [x6, #56]
    8ca4:	f90007e2 	str	x2, [sp, #8]
    8ca8:	b94000c1 	ldr	w1, [x6]
    8cac:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8cb0:	a940a0d9 	ldp	x25, x8, [x6, #8]
    8cb4:	a941dcc9 	ldp	x9, x23, [x6, #24]
    8cb8:	f94020db 	ldr	x27, [x6, #64]
    8cbc:	f94024c2 	ldr	x2, [x6, #72]
    8cc0:	6b00003f 	cmp	w1, w0
    8cc4:	54000108 	b.hi	8ce4 <fwp_main_thread+0xc94>  // b.pmore
    8cc8:	9101c261 	add	x1, x19, #0x70
    8ccc:	92403ec0 	and	x0, x22, #0xffff
    8cd0:	d1000400 	sub	x0, x0, #0x1
    8cd4:	f940742a 	ldr	x10, [x1, #232]
    8cd8:	eb0a001f 	cmp	x0, x10
    8cdc:	5400004a 	b.ge	8ce4 <fwp_main_thread+0xc94>  // b.tcont
    8ce0:	f9007420 	str	x0, [x1, #232]
    8ce4:	4f000400 	movi	v0.4s, #0x0
    8ce8:	9101c261 	add	x1, x19, #0x70
    8cec:	90ffffe0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    8cf0:	91100000 	add	x0, x0, #0x400
    8cf4:	f9000cdf 	str	xzr, [x6, #24]
    8cf8:	f941882a 	ldr	x10, [x1, #784]
    8cfc:	3c8080c0 	stur	q0, [x6, #8]
    8d00:	ad0100c0 	stp	q0, q0, [x6, #32]
    8d04:	a9047cdf 	stp	xzr, xzr, [x6, #64]
    8d08:	a90703ea 	stp	x10, x0, [sp, #112]
    8d0c:	f9400be0 	ldr	x0, [sp, #16]
    8d10:	f90043e0 	str	x0, [sp, #128]
    8d14:	f94003e0 	ldr	x0, [sp]
    8d18:	f9004fe0 	str	x0, [sp, #152]
    8d1c:	f94007e0 	ldr	x0, [sp, #8]
    8d20:	f90053e0 	str	x0, [sp, #160]
    8d24:	f94013e0 	ldr	x0, [sp, #32]
    8d28:	a908e3f7 	stp	x23, x24, [sp, #136]
    8d2c:	a90aa7fb 	stp	x27, x9, [sp, #168]
    8d30:	f9005fe2 	str	x2, [sp, #184]
    8d34:	f9018820 	str	x0, [x1, #784]
    8d38:	b7f8843c 	tbnz	x28, #63, 9dbc <fwp_main_thread+0x1d6c>
    8d3c:	eb9c82df 	cmp	x22, x28, asr #32
    8d40:	5400a501 	b.ne	a1e0 <fwp_main_thread+0x2190>  // b.any
    8d44:	92407f81 	and	x1, x28, #0xffffffff
    8d48:	eb3c411f 	cmp	x8, w28, uxtw
    8d4c:	5400a44d 	b.le	a1d4 <fwp_main_thread+0x2184>
    8d50:	eb19003f 	cmp	x1, x25
    8d54:	9a81b736 	csinc	x22, x25, x1, lt	// lt = tstop
    8d58:	eb16005f 	cmp	x2, x22
    8d5c:	5400250a 	b.ge	91fc <fwp_main_thread+0x11ac>  // b.tcont
    8d60:	f100005f 	cmp	x2, #0x0
    8d64:	9a961042 	csel	x2, x2, x22, ne	// ne = any
    8d68:	14000005 	b	8d7c <fwp_main_thread+0xd2c>
    8d6c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8d70:	eb00005f 	cmp	x2, x0
    8d74:	d37ff842 	lsl	x2, x2, #1
    8d78:	9a96d042 	csel	x2, x2, x22, le
    8d7c:	eb16005f 	cmp	x2, x22
    8d80:	54ffff6b 	b.lt	8d6c <fwp_main_thread+0xd1c>  // b.tstop
    8d84:	b40089bb 	cbz	x27, 9eb8 <fwp_main_thread+0x1e68>
    8d88:	aa1b03e0 	mov	x0, x27
    8d8c:	d37df041 	lsl	x1, x2, #3
    8d90:	f90023e2 	str	x2, [sp, #64]
    8d94:	97ffe6db 	bl	2900 <realloc@plt>
    8d98:	f94023e2 	ldr	x2, [sp, #64]
    8d9c:	aa0003fb 	mov	x27, x0
    8da0:	b400ab1b 	cbz	x27, a300 <fwp_main_thread+0x22b0>
    8da4:	f90057fb 	str	x27, [sp, #168]
    8da8:	f9005fe2 	str	x2, [sp, #184]
    8dac:	b50021f6 	cbnz	x22, 91e8 <fwp_main_thread+0x1198>
    8db0:	b7f800dc 	tbnz	x28, #63, 8dc8 <fwp_main_thread+0xd78>
    8db4:	92407f81 	and	x1, x28, #0xffffffff
    8db8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8dbc:	fc617b60 	ldr	d0, [x27, x1, lsl #3]
    8dc0:	1e612800 	fadd	d0, d0, d1
    8dc4:	fc217b60 	str	d0, [x27, x1, lsl #3]
    8dc8:	9101c261 	add	x1, x19, #0x70
    8dcc:	cb1902c6 	sub	x6, x22, x25
    8dd0:	52800060 	mov	w0, #0x3                   	// #3
    8dd4:	a9428827 	ldp	x7, x2, [x1, #40]
    8dd8:	8b0700c6 	add	x6, x6, x7
    8ddc:	8b190042 	add	x2, x2, x25
    8de0:	a9028826 	stp	x6, x2, [x1, #40]
    8de4:	97ffea23 	bl	3670 <descent_phase_step>
    8de8:	d10006c1 	sub	x1, x22, #0x1
    8dec:	d1000727 	sub	x7, x25, #0x1
    8df0:	eb01033f 	cmp	x25, x1
    8df4:	540003ec 	b.gt	8e70 <fwp_main_thread+0xe20>
    8df8:	fc617b60 	ldr	d0, [x27, x1, lsl #3]
    8dfc:	1e602008 	fcmp	d0, #0.0
    8e00:	54000320 	b.eq	8e64 <fwp_main_thread+0xe14>  // b.none
    8e04:	cb190be0 	neg	x0, x25, lsl #2
    8e08:	cb1903e6 	neg	x6, x25
    8e0c:	8b0002e2 	add	x2, x23, x0
    8e10:	b8617842 	ldr	w2, [x2, x1, lsl #2]
    8e14:	37f80122 	tbnz	w2, #31, 8e38 <fwp_main_thread+0xde8>
    8e18:	f94003e3 	ldr	x3, [sp]
    8e1c:	93407c42 	sxtw	x2, w2
    8e20:	8b060c68 	add	x8, x3, x6, lsl #3
    8e24:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    8e28:	fc617902 	ldr	d2, [x8, x1, lsl #3]
    8e2c:	1e620802 	fmul	d2, d0, d2
    8e30:	1e622821 	fadd	d1, d1, d2
    8e34:	fc227b61 	str	d1, [x27, x2, lsl #3]
    8e38:	8b000300 	add	x0, x24, x0
    8e3c:	b8617800 	ldr	w0, [x0, x1, lsl #2]
    8e40:	37f80120 	tbnz	w0, #31, 8e64 <fwp_main_thread+0xe14>
    8e44:	f94007e2 	ldr	x2, [sp, #8]
    8e48:	93407c00 	sxtw	x0, w0
    8e4c:	8b060c46 	add	x6, x2, x6, lsl #3
    8e50:	fc607b61 	ldr	d1, [x27, x0, lsl #3]
    8e54:	fc6178c2 	ldr	d2, [x6, x1, lsl #3]
    8e58:	1e620800 	fmul	d0, d0, d2
    8e5c:	1e602820 	fadd	d0, d1, d0
    8e60:	fc207b60 	str	d0, [x27, x0, lsl #3]
    8e64:	d1000421 	sub	x1, x1, #0x1
    8e68:	eb0100ff 	cmp	x7, x1
    8e6c:	54fffc61 	b.ne	8df8 <fwp_main_thread+0xda8>  // b.any
    8e70:	52800080 	mov	w0, #0x4                   	// #4
    8e74:	97ffe9ff 	bl	3670 <descent_phase_step>
    8e78:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8e7c:	eb00033f 	cmp	x25, x0
    8e80:	5400a448 	b.hi	a308 <fwp_main_thread+0x22b8>  // b.pmore
    8e84:	91000720 	add	x0, x25, #0x1
    8e88:	52800041 	mov	w1, #0x2                   	// #2
    8e8c:	d37df000 	lsl	x0, x0, #3
    8e90:	97fff038 	bl	4f70 <fwp_heap_alloc>
    8e94:	aa0003e2 	mov	x2, x0
    8e98:	aa0003f7 	mov	x23, x0
    8e9c:	d2800001 	mov	x1, #0x0                   	// #0
    8ea0:	f8008459 	str	x25, [x2], #8
    8ea4:	b40000d9 	cbz	x25, 8ebc <fwp_main_thread+0xe6c>
    8ea8:	f8617b60 	ldr	x0, [x27, x1, lsl #3]
    8eac:	f8217840 	str	x0, [x2, x1, lsl #3]
    8eb0:	91000421 	add	x1, x1, #0x1
    8eb4:	eb01033f 	cmp	x25, x1
    8eb8:	54ffff81 	b.ne	8ea8 <fwp_main_thread+0xe58>  // b.any
    8ebc:	528000a0 	mov	w0, #0x5                   	// #5
    8ec0:	97ffe9ec 	bl	3670 <descent_phase_step>
    8ec4:	f9400be0 	ldr	x0, [sp, #16]
    8ec8:	9101c261 	add	x1, x19, #0x70
    8ecc:	f9403bf8 	ldr	x24, [sp, #112]
    8ed0:	f9018838 	str	x24, [x1, #784]
    8ed4:	97ffed4b 	bl	4400 <fwp_tape_buffers_release>
    8ed8:	528000c0 	mov	w0, #0x6                   	// #6
    8edc:	97ffe9e5 	bl	3670 <descent_phase_step>
    8ee0:	f949db41 	ldr	x1, [x26, #5040]
    8ee4:	f949ef40 	ldr	x0, [x26, #5080]
    8ee8:	cb0102e1 	sub	x1, x23, x1
    8eec:	eb00403f 	cmp	x1, x0, lsl #16
    8ef0:	54000322 	b.cs	8f54 <fwp_main_thread+0xf04>  // b.hs, b.nlast
    8ef4:	d350fc20 	lsr	x0, x1, #16
    8ef8:	f949ff43 	ldr	x3, [x26, #5112]
    8efc:	8b000800 	add	x0, x0, x0, lsl #2
    8f00:	d37df002 	lsl	x2, x0, #3
    8f04:	8b020060 	add	x0, x3, x2
    8f08:	f9401016 	ldr	x22, [x0, #32]
    8f0c:	b4000256 	cbz	x22, 8f54 <fwp_main_thread+0xf04>
    8f10:	38626862 	ldrb	w2, [x3, x2]
    8f14:	7100085f 	cmp	w2, #0x2
    8f18:	54007560 	b.eq	9dc4 <fwp_main_thread+0x1d74>  // b.none
    8f1c:	7100045f 	cmp	w2, #0x1
    8f20:	540001a1 	b.ne	8f54 <fwp_main_thread+0xf04>  // b.any
    8f24:	29430002 	ldp	w2, w0, [x0, #24]
    8f28:	92403c21 	and	x1, x1, #0xffff
    8f2c:	9b027c21 	mul	x1, x1, x2
    8f30:	d360fc21 	lsr	x1, x1, #32
    8f34:	eb00003f 	cmp	x1, x0
    8f38:	540000e2 	b.cs	8f54 <fwp_main_thread+0xf04>  // b.hs, b.nlast
    8f3c:	8b0102d6 	add	x22, x22, x1
    8f40:	394002c0 	ldrb	w0, [x22]
    8f44:	7103fc1f 	cmp	w0, #0xff
    8f48:	54007480 	b.eq	9dd8 <fwp_main_thread+0x1d88>  // b.none
    8f4c:	52800020 	mov	w0, #0x1                   	// #1
    8f50:	390002c0 	strb	w0, [x22]
    8f54:	f9401be0 	ldr	x0, [sp, #48]
    8f58:	eb00031f 	cmp	x24, x0
    8f5c:	54009261 	b.ne	a1a8 <fwp_main_thread+0x2158>  // b.any
    8f60:	f94017e0 	ldr	x0, [sp, #40]
    8f64:	9101c261 	add	x1, x19, #0x70
    8f68:	f9402fe2 	ldr	x2, [sp, #88]
    8f6c:	f9018822 	str	x2, [x1, #784]
    8f70:	97fff430 	bl	6030 <fwp_tape_scope_release>
    8f74:	f94002e0 	ldr	x0, [x23]
    8f78:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    8f7c:	b7f85da0 	tbnz	x0, #63, 9b30 <fwp_main_thread+0x1ae0>
    8f80:	f949db40 	ldr	x0, [x26, #5040]
    8f84:	f949ef41 	ldr	x1, [x26, #5080]
    8f88:	cb0002e0 	sub	x0, x23, x0
    8f8c:	eb01401f 	cmp	x0, x1, lsl #16
    8f90:	54005d02 	b.cs	9b30 <fwp_main_thread+0x1ae0>  // b.hs, b.nlast
    8f94:	d350fc01 	lsr	x1, x0, #16
    8f98:	f949ff45 	ldr	x5, [x26, #5112]
    8f9c:	8b010821 	add	x1, x1, x1, lsl #2
    8fa0:	d37df021 	lsl	x1, x1, #3
    8fa4:	8b0100a3 	add	x3, x5, x1
    8fa8:	f9401062 	ldr	x2, [x3, #32]
    8fac:	b4005c22 	cbz	x2, 9b30 <fwp_main_thread+0x1ae0>
    8fb0:	386168a1 	ldrb	w1, [x5, x1]
    8fb4:	7100083f 	cmp	w1, #0x2
    8fb8:	54005b80 	b.eq	9b28 <fwp_main_thread+0x1ad8>  // b.none
    8fbc:	7100043f 	cmp	w1, #0x1
    8fc0:	54005b81 	b.ne	9b30 <fwp_main_thread+0x1ae0>  // b.any
    8fc4:	29430465 	ldp	w5, w1, [x3, #24]
    8fc8:	92403c00 	and	x0, x0, #0xffff
    8fcc:	9b057c00 	mul	x0, x0, x5
    8fd0:	d360fc00 	lsr	x0, x0, #32
    8fd4:	eb01001f 	cmp	x0, x1
    8fd8:	54005ac2 	b.cs	9b30 <fwp_main_thread+0x1ae0>  // b.hs, b.nlast
    8fdc:	8b000042 	add	x2, x2, x0
    8fe0:	39400040 	ldrb	w0, [x2]
    8fe4:	7100041f 	cmp	w0, #0x1
    8fe8:	54005a41 	b.ne	9b30 <fwp_main_thread+0x1ae0>  // b.any
    8fec:	aa1703e5 	mov	x5, x23
    8ff0:	aa1703f6 	mov	x22, x23
    8ff4:	d2800000 	mov	x0, #0x0                   	// #0
    8ff8:	910022c3 	add	x3, x22, #0x8
    8ffc:	910022e7 	add	x7, x23, #0x8
    9000:	d2800001 	mov	x1, #0x0                   	// #0
    9004:	b5000158 	cbnz	x24, 902c <fwp_main_thread+0xfdc>
    9008:	140000b4 	b	92d8 <fwp_main_thread+0x1288>
    900c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    9010:	f94000a2 	ldr	x2, [x5]
    9014:	1e600900 	fmul	d0, d8, d0
    9018:	b7f89262 	tbnz	x2, #63, a264 <fwp_main_thread+0x2214>
    901c:	91000421 	add	x1, x1, #0x1
    9020:	fc008460 	str	d0, [x3], #8
    9024:	eb01031f 	cmp	x24, x1
    9028:	54001580 	b.eq	92d8 <fwp_main_thread+0x1288>  // b.none
    902c:	f94002e6 	ldr	x6, [x23]
    9030:	aa0703e2 	mov	x2, x7
    9034:	b6fffec6 	tbz	x6, #63, 900c <fwp_main_thread+0xfbc>
    9038:	f9400ae2 	ldr	x2, [x23, #16]
    903c:	17fffff4 	b	900c <fwp_main_thread+0xfbc>
    9040:	f90042b4 	str	x20, [x21, #128]
    9044:	17fffca5 	b	82d8 <fwp_main_thread+0x288>
    9048:	f941b2c0 	ldr	x0, [x22, #864]
    904c:	b9035adf 	str	wzr, [x22, #856]
    9050:	b5008a60 	cbnz	x0, a19c <fwp_main_thread+0x214c>
    9054:	9101c275 	add	x21, x19, #0x70
    9058:	97fff51e 	bl	64d0 <fwp_free_zombie>
    905c:	f94042a0 	ldr	x0, [x21, #128]
    9060:	b50089e0 	cbnz	x0, a19c <fwp_main_thread+0x214c>
    9064:	f9406ea0 	ldr	x0, [x21, #216]
    9068:	b50089a0 	cbnz	x0, a19c <fwp_main_thread+0x214c>
    906c:	b940faa0 	ldr	w0, [x21, #248]
    9070:	340001e0 	cbz	w0, 90ac <fwp_main_thread+0x105c>
    9074:	93407c16 	sxtw	x22, w0
    9078:	51000400 	sub	w0, w0, #0x1
    907c:	d1000ad6 	sub	x22, x22, #0x2
    9080:	910402b7 	add	x23, x21, #0x100
    9084:	cb2042d6 	sub	x22, x22, w0, uxtw
    9088:	93407c14 	sxtw	x20, w0
    908c:	d503201f 	nop
    9090:	f8747ae0 	ldr	x0, [x23, x20, lsl #3]
    9094:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9098:	b900fab4 	str	w20, [x21, #248]
    909c:	d1000694 	sub	x20, x20, #0x1
    90a0:	97ffe664 	bl	2a30 <munmap@plt>
    90a4:	eb16029f 	cmp	x20, x22
    90a8:	54ffff41 	b.ne	9090 <fwp_main_thread+0x1040>  // b.any
    90ac:	f00000b4 	adrp	x20, 20000 <__data_start>
    90b0:	91004280 	add	x0, x20, #0x10
    90b4:	b9404000 	ldr	w0, [x0, #64]
    90b8:	37f80040 	tbnz	w0, #31, 90c0 <fwp_main_thread+0x1070>
    90bc:	97ffe619 	bl	2920 <close@plt>
    90c0:	9101c260 	add	x0, x19, #0x70
    90c4:	91004281 	add	x1, x20, #0x10
    90c8:	12800002 	mov	w2, #0xffffffff            	// #-1
    90cc:	d2800014 	mov	x20, #0x0                   	// #0
    90d0:	f941b416 	ldr	x22, [x0, #872]
    90d4:	b9004022 	str	w2, [x1, #64]
    90d8:	f941b815 	ldr	x21, [x0, #880]
    90dc:	b4000176 	cbz	x22, 9108 <fwp_main_thread+0x10b8>
    90e0:	f8747aa0 	ldr	x0, [x21, x20, lsl #3]
    90e4:	b40000c0 	cbz	x0, 90fc <fwp_main_thread+0x10ac>
    90e8:	f9400001 	ldr	x1, [x0]
    90ec:	b5008581 	cbnz	x1, a19c <fwp_main_thread+0x214c>
    90f0:	f9400401 	ldr	x1, [x0, #8]
    90f4:	b5008541 	cbnz	x1, a19c <fwp_main_thread+0x214c>
    90f8:	97ffee7e 	bl	4af0 <fwp_mem_free>
    90fc:	91000694 	add	x20, x20, #0x1
    9100:	eb1402df 	cmp	x22, x20
    9104:	54fffee1 	b.ne	90e0 <fwp_main_thread+0x1090>  // b.any
    9108:	aa1503e0 	mov	x0, x21
    910c:	97ffee79 	bl	4af0 <fwp_mem_free>
    9110:	9101c260 	add	x0, x19, #0x70
    9114:	f941b014 	ldr	x20, [x0, #864]
    9118:	f901b41f 	str	xzr, [x0, #872]
    911c:	f901b81f 	str	xzr, [x0, #880]
    9120:	b40001f4 	cbz	x20, 915c <fwp_main_thread+0x110c>
    9124:	f9401681 	ldr	x1, [x20, #40]
    9128:	b50083a1 	cbnz	x1, a19c <fwp_main_thread+0x214c>
    912c:	f9405681 	ldr	x1, [x20, #168]
    9130:	b5008361 	cbnz	x1, a19c <fwp_main_thread+0x214c>
    9134:	f9419401 	ldr	x1, [x0, #808]
    9138:	b5008321 	cbnz	x1, a19c <fwp_main_thread+0x214c>
    913c:	f9419c00 	ldr	x0, [x0, #824]
    9140:	b50082e0 	cbnz	x0, a19c <fwp_main_thread+0x214c>
    9144:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9148:	f0000120 	adrp	x0, 30000 <alt.5+0xfc10>
    914c:	910fc000 	add	x0, x0, #0x3f0
    9150:	97ffe5e4 	bl	28e0 <memset@plt>
    9154:	aa1403e0 	mov	x0, x20
    9158:	97ffee66 	bl	4af0 <fwp_mem_free>
    915c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9160:	f947ec00 	ldr	x0, [x0, #4056]
    9164:	9101c273 	add	x19, x19, #0x70
    9168:	f9400000 	ldr	x0, [x0]
    916c:	f9000a7f 	str	xzr, [x19, #16]
    9170:	f901b27f 	str	xzr, [x19, #864]
    9174:	97ffe633 	bl	2a40 <fflush@plt>
    9178:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    917c:	f947f400 	ldr	x0, [x0, #4072]
    9180:	f940c7e2 	ldr	x2, [sp, #392]
    9184:	f9400001 	ldr	x1, [x0]
    9188:	eb010042 	subs	x2, x2, x1
    918c:	d2800001 	mov	x1, #0x0                   	// #0
    9190:	54008b01 	b.ne	a2f0 <fwp_main_thread+0x22a0>  // b.any
    9194:	a95c63f7 	ldp	x23, x24, [sp, #448]
    9198:	910643ff 	add	sp, sp, #0x190
    919c:	d2800000 	mov	x0, #0x0                   	// #0
    91a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    91a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    91a8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    91ac:	d65f03c0 	ret
    91b0:	72003c3f 	tst	w1, #0xffff
    91b4:	54ff9861 	b.ne	84c0 <fwp_main_thread+0x470>  // b.any
    91b8:	394002e0 	ldrb	w0, [x23]
    91bc:	7103fc1f 	cmp	w0, #0xff
    91c0:	54ff97e1 	b.ne	84bc <fwp_main_thread+0x46c>  // b.any
    91c4:	aa1703e0 	mov	x0, x23
    91c8:	97ffedaa 	bl	4870 <fwp_rc_forget_slot>
    91cc:	17fffcbc 	b	84bc <fwp_main_thread+0x46c>
    91d0:	f0ffffc0 	adrp	x0, 4000 <fwp_format_g.constprop.0+0x3ec>
    91d4:	91008000 	add	x0, x0, #0x20
    91d8:	94000616 	bl	aa30 <atexit>
    91dc:	17fffbaf 	b	8098 <fwp_main_thread+0x48>
    91e0:	97ffebe9 	bl	4184 <fwp_heap_init>
    91e4:	17fffba9 	b	8088 <fwp_main_thread+0x38>
    91e8:	d37df2c2 	lsl	x2, x22, #3
    91ec:	aa1b03e0 	mov	x0, x27
    91f0:	52800001 	mov	w1, #0x0                   	// #0
    91f4:	97ffe5bb 	bl	28e0 <memset@plt>
    91f8:	17fffeee 	b	8db0 <fwp_main_thread+0xd60>
    91fc:	f100037f 	cmp	x27, #0x0
    9200:	1a9f17e0 	cset	w0, eq	// eq = none
    9204:	f10002df 	cmp	x22, #0x0
    9208:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    920c:	54ffdd00 	b.eq	8dac <fwp_main_thread+0xd5c>  // b.none
    9210:	f9400be0 	ldr	x0, [sp, #16]
    9214:	9101c273 	add	x19, x19, #0x70
    9218:	f9403be1 	ldr	x1, [sp, #112]
    921c:	f9018a61 	str	x1, [x19, #784]
    9220:	97ffec78 	bl	4400 <fwp_tape_buffers_release>
    9224:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9228:	f947e863 	ldr	x3, [x3, #4048]
    922c:	d2800262 	mov	x2, #0x13                  	// #19
    9230:	d2800021 	mov	x1, #0x1                   	// #1
    9234:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    9238:	9129a000 	add	x0, x0, #0xa68
    923c:	f9400063 	ldr	x3, [x3]
    9240:	97ffe5f4 	bl	2a10 <fwrite@plt>
    9244:	d2800000 	mov	x0, #0x0                   	// #0
    9248:	97ffe5fe 	bl	2a40 <fflush@plt>
    924c:	52800cc0 	mov	w0, #0x66                  	// #102
    9250:	97ffe60c 	bl	2a80 <_Exit@plt>
    9254:	f9400366 	ldr	x6, [x27]
    9258:	aa1b03e0 	mov	x0, x27
    925c:	f949ef43 	ldr	x3, [x26, #5080]
    9260:	f949db41 	ldr	x1, [x26, #5040]
    9264:	d370bc63 	lsl	x3, x3, #16
    9268:	cb010362 	sub	x2, x27, x1
    926c:	b7f84fe6 	tbnz	x6, #63, 9c68 <fwp_main_thread+0x1c18>
    9270:	eb02007f 	cmp	x3, x2
    9274:	54ffcfe9 	b.ls	8c70 <fwp_main_thread+0xc20>  // b.plast
    9278:	d350fc40 	lsr	x0, x2, #16
    927c:	8b000800 	add	x0, x0, x0, lsl #2
    9280:	d37df000 	lsl	x0, x0, #3
    9284:	8b0000a3 	add	x3, x5, x0
    9288:	f9401061 	ldr	x1, [x3, #32]
    928c:	b4ffcf21 	cbz	x1, 8c70 <fwp_main_thread+0xc20>
    9290:	386068a0 	ldrb	w0, [x5, x0]
    9294:	7100081f 	cmp	w0, #0x2
    9298:	54005a60 	b.eq	9de4 <fwp_main_thread+0x1d94>  // b.none
    929c:	7100041f 	cmp	w0, #0x1
    92a0:	54ffce81 	b.ne	8c70 <fwp_main_thread+0xc20>  // b.any
    92a4:	92403c40 	and	x0, x2, #0xffff
    92a8:	29430865 	ldp	w5, w2, [x3, #24]
    92ac:	9b057c00 	mul	x0, x0, x5
    92b0:	d360fc00 	lsr	x0, x0, #32
    92b4:	eb02001f 	cmp	x0, x2
    92b8:	54ffcdc2 	b.cs	8c70 <fwp_main_thread+0xc20>  // b.hs, b.nlast
    92bc:	8b000021 	add	x1, x1, x0
    92c0:	39400020 	ldrb	w0, [x1]
    92c4:	7100041f 	cmp	w0, #0x1
    92c8:	54ffcd41 	b.ne	8c70 <fwp_main_thread+0xc20>  // b.any
    92cc:	aa1b03e0 	mov	x0, x27
    92d0:	97ffee08 	bl	4af0 <fwp_mem_free>
    92d4:	17fffe67 	b	8c70 <fwp_main_thread+0xc20>
    92d8:	f90003e5 	str	x5, [sp]
    92dc:	97fff541 	bl	67e0 <fwp_drop10>
    92e0:	f94003e5 	ldr	x5, [sp]
    92e4:	aa1503e1 	mov	x1, x21
    92e8:	d2800002 	mov	x2, #0x0                   	// #0
    92ec:	b4005fb5 	cbz	x21, 9ee0 <fwp_main_thread+0x1e90>
    92f0:	f9400821 	ldr	x1, [x1, #16]
    92f4:	91000442 	add	x2, x2, #0x1
    92f8:	b5ffffc1 	cbnz	x1, 92f0 <fwp_main_thread+0x12a0>
    92fc:	f94000a0 	ldr	x0, [x5]
    9300:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    9304:	b7f83620 	tbnz	x0, #63, 99c8 <fwp_main_thread+0x1978>
    9308:	f949db41 	ldr	x1, [x26, #5040]
    930c:	f949ef43 	ldr	x3, [x26, #5080]
    9310:	cb0102c1 	sub	x1, x22, x1
    9314:	eb03403f 	cmp	x1, x3, lsl #16
    9318:	54003582 	b.cs	99c8 <fwp_main_thread+0x1978>  // b.hs, b.nlast
    931c:	d350fc23 	lsr	x3, x1, #16
    9320:	f949ff48 	ldr	x8, [x26, #5112]
    9324:	8b030863 	add	x3, x3, x3, lsl #2
    9328:	d37df063 	lsl	x3, x3, #3
    932c:	8b030107 	add	x7, x8, x3
    9330:	f94010e6 	ldr	x6, [x7, #32]
    9334:	b4003486 	cbz	x6, 99c4 <fwp_main_thread+0x1974>
    9338:	38636903 	ldrb	w3, [x8, x3]
    933c:	7100087f 	cmp	w3, #0x2
    9340:	540033e0 	b.eq	99bc <fwp_main_thread+0x196c>  // b.none
    9344:	7100047f 	cmp	w3, #0x1
    9348:	540033e1 	b.ne	99c4 <fwp_main_thread+0x1974>  // b.any
    934c:	29430ce8 	ldp	w8, w3, [x7, #24]
    9350:	92403c21 	and	x1, x1, #0xffff
    9354:	9b087c21 	mul	x1, x1, x8
    9358:	d360fc21 	lsr	x1, x1, #32
    935c:	eb03003f 	cmp	x1, x3
    9360:	54003322 	b.cs	99c4 <fwp_main_thread+0x1974>  // b.hs, b.nlast
    9364:	8b0100c6 	add	x6, x6, x1
    9368:	394000d7 	ldrb	w23, [x6]
    936c:	710006ff 	cmp	w23, #0x1
    9370:	540032a1 	b.ne	99c4 <fwp_main_thread+0x1974>  // b.any
    9374:	b90003f7 	str	w23, [sp]
    9378:	eb1b005f 	cmp	x2, x27
    937c:	9a9b905b 	csel	x27, x2, x27, ls	// ls = plast
    9380:	910020bc 	add	x28, x5, #0x8
    9384:	b40069bb 	cbz	x27, a0b8 <fwp_main_thread+0x2068>
    9388:	d37df367 	lsl	x7, x27, #3
    938c:	aa1503e2 	mov	x2, x21
    9390:	910022c6 	add	x6, x22, #0x8
    9394:	d2800001 	mov	x1, #0x0                   	// #0
    9398:	1400000a 	b	93c0 <fwp_main_thread+0x1370>
    939c:	fc616861 	ldr	d1, [x3, x1]
    93a0:	fd400440 	ldr	d0, [x2, #8]
    93a4:	1e613800 	fsub	d0, d0, d1
    93a8:	fc216b80 	str	d0, [x28, x1]
    93ac:	91002021 	add	x1, x1, #0x8
    93b0:	f9400842 	ldr	x2, [x2, #16]
    93b4:	eb07003f 	cmp	x1, x7
    93b8:	540001a0 	b.eq	93ec <fwp_main_thread+0x139c>  // b.none
    93bc:	f94000a0 	ldr	x0, [x5]
    93c0:	aa0603e3 	mov	x3, x6
    93c4:	b6fffec0 	tbz	x0, #63, 939c <fwp_main_thread+0x134c>
    93c8:	f9400ac3 	ldr	x3, [x22, #16]
    93cc:	fd400440 	ldr	d0, [x2, #8]
    93d0:	fc616861 	ldr	d1, [x3, x1]
    93d4:	1e613800 	fsub	d0, d0, d1
    93d8:	fc216b80 	str	d0, [x28, x1]
    93dc:	91002021 	add	x1, x1, #0x8
    93e0:	f9400842 	ldr	x2, [x2, #16]
    93e4:	eb07003f 	cmp	x1, x7
    93e8:	54fffea1 	b.ne	93bc <fwp_main_thread+0x136c>  // b.any
    93ec:	b4006b95 	cbz	x21, a15c <fwp_main_thread+0x210c>
    93f0:	f949ef48 	ldr	x8, [x26, #5080]
    93f4:	aa1503e6 	mov	x6, x21
    93f8:	f949db49 	ldr	x9, [x26, #5040]
    93fc:	d2800017 	mov	x23, #0x0                   	// #0
    9400:	f949ff47 	ldr	x7, [x26, #5112]
    9404:	d370bd08 	lsl	x8, x8, #16
    9408:	14000006 	b	9420 <fwp_main_thread+0x13d0>
    940c:	f94008c6 	ldr	x6, [x6, #16]
    9410:	910006f7 	add	x23, x23, #0x1
    9414:	f10000df 	cmp	x6, #0x0
    9418:	fa571360 	ccmp	x27, x23, #0x0, ne	// ne = any
    941c:	54003dc9 	b.ls	9bd4 <fwp_main_thread+0x1b84>  // b.plast
    9420:	cb0900c0 	sub	x0, x6, x9
    9424:	eb08001f 	cmp	x0, x8
    9428:	540002c2 	b.cs	9480 <fwp_main_thread+0x1430>  // b.hs, b.nlast
    942c:	d350fc01 	lsr	x1, x0, #16
    9430:	8b010821 	add	x1, x1, x1, lsl #2
    9434:	d37df021 	lsl	x1, x1, #3
    9438:	8b0100e5 	add	x5, x7, x1
    943c:	f94010a2 	ldr	x2, [x5, #32]
    9440:	b4000202 	cbz	x2, 9480 <fwp_main_thread+0x1430>
    9444:	386168e1 	ldrb	w1, [x7, x1]
    9448:	7100083f 	cmp	w1, #0x2
    944c:	54000d80 	b.eq	95fc <fwp_main_thread+0x15ac>  // b.none
    9450:	7100043f 	cmp	w1, #0x1
    9454:	54000161 	b.ne	9480 <fwp_main_thread+0x1430>  // b.any
    9458:	294304aa 	ldp	w10, w1, [x5, #24]
    945c:	92403c00 	and	x0, x0, #0xffff
    9460:	9b0a7c00 	mul	x0, x0, x10
    9464:	d360fc00 	lsr	x0, x0, #32
    9468:	eb01001f 	cmp	x0, x1
    946c:	540000a2 	b.cs	9480 <fwp_main_thread+0x1430>  // b.hs, b.nlast
    9470:	8b000042 	add	x2, x2, x0
    9474:	39400040 	ldrb	w0, [x2]
    9478:	7100041f 	cmp	w0, #0x1
    947c:	54fffc80 	b.eq	940c <fwp_main_thread+0x13bc>  // b.none
    9480:	eb1b02ff 	cmp	x23, x27
    9484:	54000c62 	b.cs	9610 <fwp_main_thread+0x15c0>  // b.hs, b.nlast
    9488:	d1002399 	sub	x25, x28, #0x8
    948c:	d2800018 	mov	x24, #0x0                   	// #0
    9490:	14000012 	b	94d8 <fwp_main_thread+0x1488>
    9494:	7100045f 	cmp	w2, #0x1
    9498:	540001a1 	b.ne	94cc <fwp_main_thread+0x147c>  // b.any
    949c:	294308c7 	ldp	w7, w2, [x6, #24]
    94a0:	92403c21 	and	x1, x1, #0xffff
    94a4:	9b077c21 	mul	x1, x1, x7
    94a8:	d360fc21 	lsr	x1, x1, #32
    94ac:	eb02003f 	cmp	x1, x2
    94b0:	540000e2 	b.cs	94cc <fwp_main_thread+0x147c>  // b.hs, b.nlast
    94b4:	8b010000 	add	x0, x0, x1
    94b8:	39400001 	ldrb	w1, [x0]
    94bc:	7103fc3f 	cmp	w1, #0xff
    94c0:	54003b80 	b.eq	9c30 <fwp_main_thread+0x1be0>  // b.none
    94c4:	52800021 	mov	w1, #0x1                   	// #1
    94c8:	39000001 	strb	w1, [x0]
    94cc:	d100077b 	sub	x27, x27, #0x1
    94d0:	eb1b02ff 	cmp	x23, x27
    94d4:	54000362 	b.cs	9540 <fwp_main_thread+0x14f0>  // b.hs, b.nlast
    94d8:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    94dc:	aa1403e1 	mov	x1, x20
    94e0:	52800020 	mov	w0, #0x1                   	// #1
    94e4:	a90f63e2 	stp	x2, x24, [sp, #240]
    94e8:	97ffeee7 	bl	5084 <fwp_data.part.0.constprop.0>
    94ec:	aa0003f8 	mov	x24, x0
    94f0:	f949db41 	ldr	x1, [x26, #5040]
    94f4:	f949ef40 	ldr	x0, [x26, #5080]
    94f8:	cb010301 	sub	x1, x24, x1
    94fc:	eb00403f 	cmp	x1, x0, lsl #16
    9500:	54fffe62 	b.cs	94cc <fwp_main_thread+0x147c>  // b.hs, b.nlast
    9504:	d350fc20 	lsr	x0, x1, #16
    9508:	f949ff47 	ldr	x7, [x26, #5112]
    950c:	8b000800 	add	x0, x0, x0, lsl #2
    9510:	d37df002 	lsl	x2, x0, #3
    9514:	8b0200e6 	add	x6, x7, x2
    9518:	f94010c0 	ldr	x0, [x6, #32]
    951c:	b4fffd80 	cbz	x0, 94cc <fwp_main_thread+0x147c>
    9520:	386268e2 	ldrb	w2, [x7, x2]
    9524:	7100085f 	cmp	w2, #0x2
    9528:	54fffb61 	b.ne	9494 <fwp_main_thread+0x1444>  // b.any
    952c:	72003c3f 	tst	w1, #0xffff
    9530:	54fffc40 	b.eq	94b8 <fwp_main_thread+0x1468>  // b.none
    9534:	d100077b 	sub	x27, x27, #0x1
    9538:	eb1b02ff 	cmp	x23, x27
    953c:	54fffce3 	b.cc	94d8 <fwp_main_thread+0x1488>  // b.lo, b.ul, b.last
    9540:	b50006b7 	cbnz	x23, 9614 <fwp_main_thread+0x15c4>
    9544:	b94003e0 	ldr	w0, [sp]
    9548:	d2800037 	mov	x23, #0x1                   	// #1
    954c:	d280001b 	mov	x27, #0x0                   	// #0
    9550:	7100001f 	cmp	w0, #0x0
    9554:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    9558:	b40004fb 	cbz	x27, 95f4 <fwp_main_thread+0x15a4>
    955c:	d100077b 	sub	x27, x27, #0x1
    9560:	f87b7b82 	ldr	x2, [x28, x27, lsl #3]
    9564:	aa1403e1 	mov	x1, x20
    9568:	52800020 	mov	w0, #0x1                   	// #1
    956c:	a90f63e2 	stp	x2, x24, [sp, #240]
    9570:	97ffeec5 	bl	5084 <fwp_data.part.0.constprop.0>
    9574:	aa0003f8 	mov	x24, x0
    9578:	f949db41 	ldr	x1, [x26, #5040]
    957c:	f949ef40 	ldr	x0, [x26, #5080]
    9580:	cb010301 	sub	x1, x24, x1
    9584:	eb00403f 	cmp	x1, x0, lsl #16
    9588:	54000302 	b.cs	95e8 <fwp_main_thread+0x1598>  // b.hs, b.nlast
    958c:	d350fc22 	lsr	x2, x1, #16
    9590:	f949ff45 	ldr	x5, [x26, #5112]
    9594:	8b020842 	add	x2, x2, x2, lsl #2
    9598:	d37df042 	lsl	x2, x2, #3
    959c:	8b0200a3 	add	x3, x5, x2
    95a0:	f9401079 	ldr	x25, [x3, #32]
    95a4:	b4000239 	cbz	x25, 95e8 <fwp_main_thread+0x1598>
    95a8:	386268a2 	ldrb	w2, [x5, x2]
    95ac:	7100085f 	cmp	w2, #0x2
    95b0:	54002000 	b.eq	99b0 <fwp_main_thread+0x1960>  // b.none
    95b4:	7100045f 	cmp	w2, #0x1
    95b8:	54000181 	b.ne	95e8 <fwp_main_thread+0x1598>  // b.any
    95bc:	29430865 	ldp	w5, w2, [x3, #24]
    95c0:	92403c21 	and	x1, x1, #0xffff
    95c4:	9b057c21 	mul	x1, x1, x5
    95c8:	d360fc21 	lsr	x1, x1, #32
    95cc:	eb02003f 	cmp	x1, x2
    95d0:	540000c2 	b.cs	95e8 <fwp_main_thread+0x1598>  // b.hs, b.nlast
    95d4:	8b010339 	add	x25, x25, x1
    95d8:	39400321 	ldrb	w1, [x25]
    95dc:	7103fc3f 	cmp	w1, #0xff
    95e0:	54001e20 	b.eq	99a4 <fwp_main_thread+0x1954>  // b.none
    95e4:	39000337 	strb	w23, [x25]
    95e8:	d100077b 	sub	x27, x27, #0x1
    95ec:	b100077f 	cmn	x27, #0x1
    95f0:	54fffb81 	b.ne	9560 <fwp_main_thread+0x1510>  // b.any
    95f4:	aa1503fb 	mov	x27, x21
    95f8:	14000015 	b	964c <fwp_main_thread+0x15fc>
    95fc:	72003c1f 	tst	w0, #0xffff
    9600:	54fff3a0 	b.eq	9474 <fwp_main_thread+0x1424>  // b.none
    9604:	eb1b02ff 	cmp	x23, x27
    9608:	54fff403 	b.cc	9488 <fwp_main_thread+0x1438>  // b.lo, b.ul, b.last
    960c:	d503201f 	nop
    9610:	d2800018 	mov	x24, #0x0                   	// #0
    9614:	8b170f83 	add	x3, x28, x23, lsl #3
    9618:	aa1c03e0 	mov	x0, x28
    961c:	aa1503fb 	mov	x27, x21
    9620:	f8408401 	ldr	x1, [x0], #8
    9624:	f9000761 	str	x1, [x27, #8]
    9628:	aa1b03e1 	mov	x1, x27
    962c:	f9400b7b 	ldr	x27, [x27, #16]
    9630:	eb03001f 	cmp	x0, x3
    9634:	54ffff61 	b.ne	9620 <fwp_main_thread+0x15d0>  // b.any
    9638:	b94003e0 	ldr	w0, [sp]
    963c:	f9000838 	str	x24, [x1, #16]
    9640:	aa1503f8 	mov	x24, x21
    9644:	7100001f 	cmp	w0, #0x0
    9648:	9a9f039c 	csel	x28, x28, xzr, eq	// eq = none
    964c:	aa1c03e0 	mov	x0, x28
    9650:	97ffed28 	bl	4af0 <fwp_mem_free>
    9654:	f949ef42 	ldr	x2, [x26, #5080]
    9658:	f949db41 	ldr	x1, [x26, #5040]
    965c:	d370bc42 	lsl	x2, x2, #16
    9660:	cb0102c3 	sub	x3, x22, x1
    9664:	eb02007f 	cmp	x3, x2
    9668:	54000402 	b.cs	96e8 <fwp_main_thread+0x1698>  // b.hs, b.nlast
    966c:	d350fc60 	lsr	x0, x3, #16
    9670:	f949ff45 	ldr	x5, [x26, #5112]
    9674:	8b000800 	add	x0, x0, x0, lsl #2
    9678:	d37df000 	lsl	x0, x0, #3
    967c:	8b0000a2 	add	x2, x5, x0
    9680:	f9401057 	ldr	x23, [x2, #32]
    9684:	b4001897 	cbz	x23, 9994 <fwp_main_thread+0x1944>
    9688:	386068a1 	ldrb	w1, [x5, x0]
    968c:	7100083f 	cmp	w1, #0x2
    9690:	54002e60 	b.eq	9c5c <fwp_main_thread+0x1c0c>  // b.none
    9694:	7100043f 	cmp	w1, #0x1
    9698:	540017e1 	b.ne	9994 <fwp_main_thread+0x1944>  // b.any
    969c:	29430846 	ldp	w6, w2, [x2, #24]
    96a0:	92403c61 	and	x1, x3, #0xffff
    96a4:	9b067c21 	mul	x1, x1, x6
    96a8:	d360fc21 	lsr	x1, x1, #32
    96ac:	eb02003f 	cmp	x1, x2
    96b0:	54001722 	b.cs	9994 <fwp_main_thread+0x1944>  // b.hs, b.nlast
    96b4:	8b0102f7 	add	x23, x23, x1
    96b8:	394002e1 	ldrb	w1, [x23]
    96bc:	340016c1 	cbz	w1, 9994 <fwp_main_thread+0x1944>
    96c0:	7100043f 	cmp	w1, #0x1
    96c4:	54001280 	b.eq	9914 <fwp_main_thread+0x18c4>  // b.none
    96c8:	7103fc3f 	cmp	w1, #0xff
    96cc:	54004580 	b.eq	9f7c <fwp_main_thread+0x1f2c>  // b.none
    96d0:	51000421 	sub	w1, w1, #0x1
    96d4:	390002e1 	strb	w1, [x23]
    96d8:	f949ef42 	ldr	x2, [x26, #5080]
    96dc:	f949db41 	ldr	x1, [x26, #5040]
    96e0:	d370bc42 	lsl	x2, x2, #16
    96e4:	d503201f 	nop
    96e8:	cb010361 	sub	x1, x27, x1
    96ec:	eb01005f 	cmp	x2, x1
    96f0:	54000389 	b.ls	9760 <fwp_main_thread+0x1710>  // b.plast
    96f4:	d350fc20 	lsr	x0, x1, #16
    96f8:	f949ff43 	ldr	x3, [x26, #5112]
    96fc:	8b000800 	add	x0, x0, x0, lsl #2
    9700:	d37df000 	lsl	x0, x0, #3
    9704:	8b000062 	add	x2, x3, x0
    9708:	f9401056 	ldr	x22, [x2, #32]
    970c:	b40002b6 	cbz	x22, 9760 <fwp_main_thread+0x1710>
    9710:	38606865 	ldrb	w5, [x3, x0]
    9714:	710008bf 	cmp	w5, #0x2
    9718:	54002e80 	b.eq	9ce8 <fwp_main_thread+0x1c98>  // b.none
    971c:	710004bf 	cmp	w5, #0x1
    9720:	54000201 	b.ne	9760 <fwp_main_thread+0x1710>  // b.any
    9724:	29430845 	ldp	w5, w2, [x2, #24]
    9728:	92403c21 	and	x1, x1, #0xffff
    972c:	9b057c21 	mul	x1, x1, x5
    9730:	d360fc21 	lsr	x1, x1, #32
    9734:	eb02003f 	cmp	x1, x2
    9738:	54000142 	b.cs	9760 <fwp_main_thread+0x1710>  // b.hs, b.nlast
    973c:	8b0102d6 	add	x22, x22, x1
    9740:	394002c1 	ldrb	w1, [x22]
    9744:	340000e1 	cbz	w1, 9760 <fwp_main_thread+0x1710>
    9748:	7100043f 	cmp	w1, #0x1
    974c:	54003520 	b.eq	9df0 <fwp_main_thread+0x1da0>  // b.none
    9750:	7103fc3f 	cmp	w1, #0xff
    9754:	540047e0 	b.eq	a050 <fwp_main_thread+0x2000>  // b.none
    9758:	51000421 	sub	w1, w1, #0x1
    975c:	390002c1 	strb	w1, [x22]
    9760:	f9400be0 	ldr	x0, [sp, #16]
    9764:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x11430>
    9768:	910aa042 	add	x2, x2, #0x2a8
    976c:	aa1803e1 	mov	x1, x24
    9770:	91014042 	add	x2, x2, #0x50
    9774:	52800023 	mov	w3, #0x1                   	// #1
    9778:	a908ffff 	stp	xzr, xzr, [sp, #136]
    977c:	f9004fff 	str	xzr, [sp, #152]
    9780:	97fff639 	bl	7064 <fwp_write>
    9784:	a948eff7 	ldp	x23, x27, [sp, #136]
    9788:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    978c:	9116c000 	add	x0, x0, #0x5b0
    9790:	f10002ff 	cmp	x23, #0x0
    9794:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    9798:	b1002b7f 	cmn	x27, #0xa
    979c:	540058e8 	b.hi	a2b8 <fwp_main_thread+0x2268>  // b.pmore
    97a0:	91002760 	add	x0, x27, #0x9
    97a4:	52800021 	mov	w1, #0x1                   	// #1
    97a8:	97ffedf2 	bl	4f70 <fwp_heap_alloc>
    97ac:	aa0003fc 	mov	x28, x0
    97b0:	aa0003f6 	mov	x22, x0
    97b4:	aa1b03e2 	mov	x2, x27
    97b8:	aa1703e1 	mov	x1, x23
    97bc:	f800879b 	str	x27, [x28], #8
    97c0:	8b1b02db 	add	x27, x22, x27
    97c4:	aa1c03e0 	mov	x0, x28
    97c8:	97ffe3e6 	bl	2760 <memcpy@plt>
    97cc:	3900237f 	strb	wzr, [x27, #8]
    97d0:	f94047e0 	ldr	x0, [sp, #136]
    97d4:	97ffe47f 	bl	29d0 <free@plt>
    97d8:	f949db42 	ldr	x2, [x26, #5040]
    97dc:	f949ef40 	ldr	x0, [x26, #5080]
    97e0:	cb0202c2 	sub	x2, x22, x2
    97e4:	eb00405f 	cmp	x2, x0, lsl #16
    97e8:	54000322 	b.cs	984c <fwp_main_thread+0x17fc>  // b.hs, b.nlast
    97ec:	d350fc40 	lsr	x0, x2, #16
    97f0:	f949ff43 	ldr	x3, [x26, #5112]
    97f4:	8b000800 	add	x0, x0, x0, lsl #2
    97f8:	d37df001 	lsl	x1, x0, #3
    97fc:	8b010060 	add	x0, x3, x1
    9800:	f9401017 	ldr	x23, [x0, #32]
    9804:	b4000257 	cbz	x23, 984c <fwp_main_thread+0x17fc>
    9808:	38616861 	ldrb	w1, [x3, x1]
    980c:	7100083f 	cmp	w1, #0x2
    9810:	540041a0 	b.eq	a044 <fwp_main_thread+0x1ff4>  // b.none
    9814:	7100043f 	cmp	w1, #0x1
    9818:	540001a1 	b.ne	984c <fwp_main_thread+0x17fc>  // b.any
    981c:	29430003 	ldp	w3, w0, [x0, #24]
    9820:	92403c41 	and	x1, x2, #0xffff
    9824:	9b037c21 	mul	x1, x1, x3
    9828:	d360fc21 	lsr	x1, x1, #32
    982c:	eb00003f 	cmp	x1, x0
    9830:	540000e2 	b.cs	984c <fwp_main_thread+0x17fc>  // b.hs, b.nlast
    9834:	8b0102f7 	add	x23, x23, x1
    9838:	394002e0 	ldrb	w0, [x23]
    983c:	7103fc1f 	cmp	w0, #0xff
    9840:	54004920 	b.eq	a164 <fwp_main_thread+0x2114>  // b.none
    9844:	52800020 	mov	w0, #0x1                   	// #1
    9848:	390002e0 	strb	w0, [x23]
    984c:	9101c277 	add	x23, x19, #0x70
    9850:	aa1803e0 	mov	x0, x24
    9854:	97fff0c3 	bl	5b60 <fwp_drop0>
    9858:	f94002c2 	ldr	x2, [x22]
    985c:	d2800021 	mov	x1, #0x1                   	// #1
    9860:	f94006e3 	ldr	x3, [x23, #8]
    9864:	aa1c03e0 	mov	x0, x28
    9868:	97ffe46a 	bl	2a10 <fwrite@plt>
    986c:	f94006e1 	ldr	x1, [x23, #8]
    9870:	52800140 	mov	w0, #0xa                   	// #10
    9874:	97ffe3ef 	bl	2830 <fputc@plt>
    9878:	f949db42 	ldr	x2, [x26, #5040]
    987c:	f949ef40 	ldr	x0, [x26, #5080]
    9880:	cb0202c2 	sub	x2, x22, x2
    9884:	eb00405f 	cmp	x2, x0, lsl #16
    9888:	54000382 	b.cs	98f8 <fwp_main_thread+0x18a8>  // b.hs, b.nlast
    988c:	d350fc40 	lsr	x0, x2, #16
    9890:	f949ff43 	ldr	x3, [x26, #5112]
    9894:	8b000800 	add	x0, x0, x0, lsl #2
    9898:	d37df001 	lsl	x1, x0, #3
    989c:	8b010060 	add	x0, x3, x1
    98a0:	f9401017 	ldr	x23, [x0, #32]
    98a4:	b40002b7 	cbz	x23, 98f8 <fwp_main_thread+0x18a8>
    98a8:	38616861 	ldrb	w1, [x3, x1]
    98ac:	7100083f 	cmp	w1, #0x2
    98b0:	54003fe0 	b.eq	a0ac <fwp_main_thread+0x205c>  // b.none
    98b4:	7100043f 	cmp	w1, #0x1
    98b8:	54000201 	b.ne	98f8 <fwp_main_thread+0x18a8>  // b.any
    98bc:	29430003 	ldp	w3, w0, [x0, #24]
    98c0:	92403c41 	and	x1, x2, #0xffff
    98c4:	9b037c21 	mul	x1, x1, x3
    98c8:	d360fc21 	lsr	x1, x1, #32
    98cc:	eb00003f 	cmp	x1, x0
    98d0:	54000142 	b.cs	98f8 <fwp_main_thread+0x18a8>  // b.hs, b.nlast
    98d4:	8b0102f7 	add	x23, x23, x1
    98d8:	394002e0 	ldrb	w0, [x23]
    98dc:	340000e0 	cbz	w0, 98f8 <fwp_main_thread+0x18a8>
    98e0:	7100041f 	cmp	w0, #0x1
    98e4:	54003100 	b.eq	9f04 <fwp_main_thread+0x1eb4>  // b.none
    98e8:	7103fc1f 	cmp	w0, #0xff
    98ec:	540048e0 	b.eq	a208 <fwp_main_thread+0x21b8>  // b.none
    98f0:	51000400 	sub	w0, w0, #0x1
    98f4:	390002e0 	strb	w0, [x23]
    98f8:	f94027e0 	ldr	x0, [sp, #72]
    98fc:	f9400800 	ldr	x0, [x0, #16]
    9900:	f90027e0 	str	x0, [sp, #72]
    9904:	b40030c0 	cbz	x0, 9f1c <fwp_main_thread+0x1ecc>
    9908:	9101c260 	add	x0, x19, #0x70
    990c:	f9418816 	ldr	x22, [x0, #784]
    9910:	17fffb74 	b	86e0 <fwp_main_thread+0x690>
    9914:	f94002c3 	ldr	x3, [x22]
    9918:	aa1603e0 	mov	x0, x22
    991c:	f949ef42 	ldr	x2, [x26, #5080]
    9920:	f949db41 	ldr	x1, [x26, #5040]
    9924:	d370bc42 	lsl	x2, x2, #16
    9928:	cb0102c8 	sub	x8, x22, x1
    992c:	b7f81e43 	tbnz	x3, #63, 9cf4 <fwp_main_thread+0x1ca4>
    9930:	eb08005f 	cmp	x2, x8
    9934:	54ffeda9 	b.ls	96e8 <fwp_main_thread+0x1698>  // b.plast
    9938:	d350fd03 	lsr	x3, x8, #16
    993c:	8b030863 	add	x3, x3, x3, lsl #2
    9940:	d37df063 	lsl	x3, x3, #3
    9944:	8b0300a7 	add	x7, x5, x3
    9948:	f94010e6 	ldr	x6, [x7, #32]
    994c:	b4ffece6 	cbz	x6, 96e8 <fwp_main_thread+0x1698>
    9950:	386368a3 	ldrb	w3, [x5, x3]
    9954:	7100087f 	cmp	w3, #0x2
    9958:	54002980 	b.eq	9e88 <fwp_main_thread+0x1e38>  // b.none
    995c:	7100047f 	cmp	w3, #0x1
    9960:	54ffec41 	b.ne	96e8 <fwp_main_thread+0x1698>  // b.any
    9964:	29430ce5 	ldp	w5, w3, [x7, #24]
    9968:	92403d00 	and	x0, x8, #0xffff
    996c:	9b057c00 	mul	x0, x0, x5
    9970:	d360fc00 	lsr	x0, x0, #32
    9974:	eb03001f 	cmp	x0, x3
    9978:	54ffeb82 	b.cs	96e8 <fwp_main_thread+0x1698>  // b.hs, b.nlast
    997c:	8b0000c6 	add	x6, x6, x0
    9980:	394000c0 	ldrb	w0, [x6]
    9984:	7100041f 	cmp	w0, #0x1
    9988:	54ffeb01 	b.ne	96e8 <fwp_main_thread+0x1698>  // b.any
    998c:	aa1603e0 	mov	x0, x22
    9990:	97ffec58 	bl	4af0 <fwp_mem_free>
    9994:	f949ef42 	ldr	x2, [x26, #5080]
    9998:	f949db41 	ldr	x1, [x26, #5040]
    999c:	d370bc42 	lsl	x2, x2, #16
    99a0:	17ffff52 	b	96e8 <fwp_main_thread+0x1698>
    99a4:	aa1903e0 	mov	x0, x25
    99a8:	97ffebb2 	bl	4870 <fwp_rc_forget_slot>
    99ac:	17ffff0e 	b	95e4 <fwp_main_thread+0x1594>
    99b0:	72003c3f 	tst	w1, #0xffff
    99b4:	54ffe1a1 	b.ne	95e8 <fwp_main_thread+0x1598>  // b.any
    99b8:	17ffff08 	b	95d8 <fwp_main_thread+0x1588>
    99bc:	72003c3f 	tst	w1, #0xffff
    99c0:	54ffcd40 	b.eq	9368 <fwp_main_thread+0x1318>  // b.none
    99c4:	b40010f5 	cbz	x21, 9be0 <fwp_main_thread+0x1b90>
    99c8:	aa1503f7 	mov	x23, x21
    99cc:	d2800018 	mov	x24, #0x0                   	// #0
    99d0:	f9400af7 	ldr	x23, [x23, #16]
    99d4:	aa1803e0 	mov	x0, x24
    99d8:	91000718 	add	x24, x24, #0x1
    99dc:	b5ffffb7 	cbnz	x23, 99d0 <fwp_main_thread+0x1980>
    99e0:	f90003e5 	str	x5, [sp]
    99e4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    99e8:	eb01031f 	cmp	x24, x1
    99ec:	54004428 	b.hi	a270 <fwp_main_thread+0x2220>  // b.pmore
    99f0:	91000800 	add	x0, x0, #0x2
    99f4:	52800041 	mov	w1, #0x2                   	// #2
    99f8:	d37df000 	lsl	x0, x0, #3
    99fc:	97ffed5d 	bl	4f70 <fwp_heap_alloc>
    9a00:	f94003e5 	ldr	x5, [sp]
    9a04:	eb1b031f 	cmp	x24, x27
    9a08:	9a9b931b 	csel	x27, x24, x27, ls	// ls = plast
    9a0c:	aa0003fc 	mov	x28, x0
    9a10:	aa1503e1 	mov	x1, x21
    9a14:	d503201f 	nop
    9a18:	f9400420 	ldr	x0, [x1, #8]
    9a1c:	f8377b80 	str	x0, [x28, x23, lsl #3]
    9a20:	910006f7 	add	x23, x23, #0x1
    9a24:	f9400821 	ldr	x1, [x1, #16]
    9a28:	b5ffff81 	cbnz	x1, 9a18 <fwp_main_thread+0x19c8>
    9a2c:	b4000e3b 	cbz	x27, 9bf0 <fwp_main_thread+0x1ba0>
    9a30:	f94000a0 	ldr	x0, [x5]
    9a34:	b90003ff 	str	wzr, [sp]
    9a38:	17fffe54 	b	9388 <fwp_main_thread+0x1338>
    9a3c:	d53bd040 	mrs	x0, tpidr_el0
    9a40:	91400000 	add	x0, x0, #0x0, lsl #12
    9a44:	91004000 	add	x0, x0, #0x10
    9a48:	f9400000 	ldr	x0, [x0]
    9a4c:	b4001940 	cbz	x0, 9d74 <fwp_main_thread+0x1d24>
    9a50:	f9401fe1 	ldr	x1, [sp, #56]
    9a54:	97ffe7a4 	bl	38e4 <fwp_closure_drop_push>
    9a58:	b5ff71b5 	cbnz	x21, 888c <fwp_main_thread+0x83c>
    9a5c:	9101c277 	add	x23, x19, #0x70
    9a60:	52800000 	mov	w0, #0x0                   	// #0
    9a64:	97ffe703 	bl	3670 <descent_phase_step>
    9a68:	d2800016 	mov	x22, #0x0                   	// #0
    9a6c:	b9434ee0 	ldr	w0, [x23, #844]
    9a70:	35ff72a0 	cbnz	w0, 88c4 <fwp_main_thread+0x874>
    9a74:	d503201f 	nop
    9a78:	90ffffe0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    9a7c:	913cc000 	add	x0, x0, #0xf30
    9a80:	940003ec 	bl	aa30 <atexit>
    9a84:	35ffbd00 	cbnz	w0, 9224 <fwp_main_thread+0x11d4>
    9a88:	52800020 	mov	w0, #0x1                   	// #1
    9a8c:	b9034ee0 	str	w0, [x23, #844]
    9a90:	9101c260 	add	x0, x19, #0x70
    9a94:	f9404817 	ldr	x23, [x0, #144]
    9a98:	f9407401 	ldr	x1, [x0, #232]
    9a9c:	eb17003f 	cmp	x1, x23
    9aa0:	54ff71cb 	b.lt	88d8 <fwp_main_thread+0x888>  // b.tstop
    9aa4:	d503201f 	nop
    9aa8:	eb0102ff 	cmp	x23, x1
    9aac:	54ff7340 	b.eq	8914 <fwp_main_thread+0x8c4>  // b.none
    9ab0:	aa0103f7 	mov	x23, x1
    9ab4:	9100043c 	add	x28, x1, #0x1
    9ab8:	d37ff821 	lsl	x1, x1, #1
    9abc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    9ac0:	f9403a7b 	ldr	x27, [x19, #112]
    9ac4:	8b170021 	add	x1, x1, x23
    9ac8:	91354000 	add	x0, x0, #0xd50
    9acc:	8b010ae1 	add	x1, x23, x1, lsl #2
    9ad0:	8b010f78 	add	x24, x27, x1, lsl #3
    9ad4:	f900331f 	str	xzr, [x24, #96]
    9ad8:	97ffe3f2 	bl	2aa0 <getenv@plt>
    9adc:	b5ff7720 	cbnz	x0, 89c0 <fwp_main_thread+0x970>
    9ae0:	9101c260 	add	x0, x19, #0x70
    9ae4:	f9406801 	ldr	x1, [x0, #208]
    9ae8:	b4ff7761 	cbz	x1, 89d4 <fwp_main_thread+0x984>
    9aec:	3cc98002 	ldur	q2, [x0, #152]
    9af0:	91026001 	add	x1, x0, #0x98
    9af4:	3cca8001 	ldur	q1, [x0, #168]
    9af8:	f900681f 	str	xzr, [x0, #208]
    9afc:	4f000400 	movi	v0.4s, #0x0
    9b00:	ad010702 	stp	q2, q1, [x24, #32]
    9b04:	f9405c02 	ldr	x2, [x0, #184]
    9b08:	f9406400 	ldr	x0, [x0, #200]
    9b0c:	a9040302 	stp	x2, x0, [x24, #64]
    9b10:	f9401422 	ldr	x2, [x1, #40]
    9b14:	f9000f02 	str	x2, [x24, #24]
    9b18:	f900183f 	str	xzr, [x1, #48]
    9b1c:	ad000020 	stp	q0, q0, [x1]
    9b20:	3d800820 	str	q0, [x1, #32]
    9b24:	17fffbac 	b	89d4 <fwp_main_thread+0x984>
    9b28:	72003c1f 	tst	w0, #0xffff
    9b2c:	54ffa5a0 	b.eq	8fe0 <fwp_main_thread+0xf90>  // b.none
    9b30:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9b34:	eb00031f 	cmp	x24, x0
    9b38:	54003e88 	b.hi	a308 <fwp_main_thread+0x22b8>  // b.pmore
    9b3c:	91000700 	add	x0, x24, #0x1
    9b40:	52800021 	mov	w1, #0x1                   	// #1
    9b44:	d37df000 	lsl	x0, x0, #3
    9b48:	97ffed0a 	bl	4f70 <fwp_heap_alloc>
    9b4c:	f9000018 	str	x24, [x0]
    9b50:	aa0003e5 	mov	x5, x0
    9b54:	aa0003f6 	mov	x22, x0
    9b58:	f949db41 	ldr	x1, [x26, #5040]
    9b5c:	f949ef40 	ldr	x0, [x26, #5080]
    9b60:	cb0100a1 	sub	x1, x5, x1
    9b64:	eb00403f 	cmp	x1, x0, lsl #16
    9b68:	54000322 	b.cs	9bcc <fwp_main_thread+0x1b7c>  // b.hs, b.nlast
    9b6c:	d350fc20 	lsr	x0, x1, #16
    9b70:	f949ff43 	ldr	x3, [x26, #5112]
    9b74:	8b000800 	add	x0, x0, x0, lsl #2
    9b78:	d37df002 	lsl	x2, x0, #3
    9b7c:	8b020060 	add	x0, x3, x2
    9b80:	f940101b 	ldr	x27, [x0, #32]
    9b84:	b400025b 	cbz	x27, 9bcc <fwp_main_thread+0x1b7c>
    9b88:	38626862 	ldrb	w2, [x3, x2]
    9b8c:	7100085f 	cmp	w2, #0x2
    9b90:	54001820 	b.eq	9e94 <fwp_main_thread+0x1e44>  // b.none
    9b94:	7100045f 	cmp	w2, #0x1
    9b98:	540001a1 	b.ne	9bcc <fwp_main_thread+0x1b7c>  // b.any
    9b9c:	29430002 	ldp	w2, w0, [x0, #24]
    9ba0:	92403c21 	and	x1, x1, #0xffff
    9ba4:	9b027c21 	mul	x1, x1, x2
    9ba8:	d360fc21 	lsr	x1, x1, #32
    9bac:	eb00003f 	cmp	x1, x0
    9bb0:	540000e2 	b.cs	9bcc <fwp_main_thread+0x1b7c>  // b.hs, b.nlast
    9bb4:	8b01037b 	add	x27, x27, x1
    9bb8:	39400360 	ldrb	w0, [x27]
    9bbc:	7103fc1f 	cmp	w0, #0xff
    9bc0:	54001720 	b.eq	9ea4 <fwp_main_thread+0x1e54>  // b.none
    9bc4:	52800020 	mov	w0, #0x1                   	// #1
    9bc8:	39000360 	strb	w0, [x27]
    9bcc:	aa1703e0 	mov	x0, x23
    9bd0:	17fffd0a 	b	8ff8 <fwp_main_thread+0xfa8>
    9bd4:	eb17037f 	cmp	x27, x23
    9bd8:	54ffc588 	b.hi	9488 <fwp_main_thread+0x1438>  // b.pmore
    9bdc:	17fffe8d 	b	9610 <fwp_main_thread+0x15c0>
    9be0:	52800041 	mov	w1, #0x2                   	// #2
    9be4:	d2800100 	mov	x0, #0x8                   	// #8
    9be8:	97ffece2 	bl	4f70 <fwp_heap_alloc>
    9bec:	aa0003fc 	mov	x28, x0
    9bf0:	aa1503fb 	mov	x27, x21
    9bf4:	d2800018 	mov	x24, #0x0                   	// #0
    9bf8:	17fffe95 	b	964c <fwp_main_thread+0x15fc>
    9bfc:	52800041 	mov	w1, #0x2                   	// #2
    9c00:	d2800100 	mov	x0, #0x8                   	// #8
    9c04:	97ffecdb 	bl	4f70 <fwp_heap_alloc>
    9c08:	f900001f 	str	xzr, [x0]
    9c0c:	aa0003f8 	mov	x24, x0
    9c10:	aa0003fb 	mov	x27, x0
    9c14:	f949db41 	ldr	x1, [x26, #5040]
    9c18:	f949ef40 	ldr	x0, [x26, #5080]
    9c1c:	cb010301 	sub	x1, x24, x1
    9c20:	eb00403f 	cmp	x1, x0, lsl #16
    9c24:	54000122 	b.cs	9c48 <fwp_main_thread+0x1bf8>  // b.hs, b.nlast
    9c28:	d2800017 	mov	x23, #0x0                   	// #0
    9c2c:	17fffbad 	b	8ae0 <fwp_main_thread+0xa90>
    9c30:	f90007e0 	str	x0, [sp, #8]
    9c34:	97ffeb0f 	bl	4870 <fwp_rc_forget_slot>
    9c38:	f94007e0 	ldr	x0, [sp, #8]
    9c3c:	17fffe22 	b	94c4 <fwp_main_thread+0x1474>
    9c40:	b5ff7837 	cbnz	x23, 8b44 <fwp_main_thread+0xaf4>
    9c44:	d503201f 	nop
    9c48:	d280001c 	mov	x28, #0x0                   	// #0
    9c4c:	17fffbe4 	b	8bdc <fwp_main_thread+0xb8c>
    9c50:	72003c3f 	tst	w1, #0xffff
    9c54:	54ff80e1 	b.ne	8c70 <fwp_main_thread+0xc20>  // b.any
    9c58:	17fffbfd 	b	8c4c <fwp_main_thread+0xbfc>
    9c5c:	72003c7f 	tst	w3, #0xffff
    9c60:	54ffe9a1 	b.ne	9994 <fwp_main_thread+0x1944>  // b.any
    9c64:	17fffe95 	b	96b8 <fwp_main_thread+0x1668>
    9c68:	f940077b 	ldr	x27, [x27, #8]
    9c6c:	eb02007f 	cmp	x3, x2
    9c70:	54000349 	b.ls	9cd8 <fwp_main_thread+0x1c88>  // b.plast
    9c74:	d350fc46 	lsr	x6, x2, #16
    9c78:	8b0608c6 	add	x6, x6, x6, lsl #2
    9c7c:	d37df0c6 	lsl	x6, x6, #3
    9c80:	8b0600a9 	add	x9, x5, x6
    9c84:	f9401128 	ldr	x8, [x9, #32]
    9c88:	b4000288 	cbz	x8, 9cd8 <fwp_main_thread+0x1c88>
    9c8c:	386668a5 	ldrb	w5, [x5, x6]
    9c90:	710008bf 	cmp	w5, #0x2
    9c94:	54001620 	b.eq	9f58 <fwp_main_thread+0x1f08>  // b.none
    9c98:	710004bf 	cmp	w5, #0x1
    9c9c:	540001e1 	b.ne	9cd8 <fwp_main_thread+0x1c88>  // b.any
    9ca0:	29431526 	ldp	w6, w5, [x9, #24]
    9ca4:	92403c42 	and	x2, x2, #0xffff
    9ca8:	9b067c42 	mul	x2, x2, x6
    9cac:	d360fc42 	lsr	x2, x2, #32
    9cb0:	eb05005f 	cmp	x2, x5
    9cb4:	54000122 	b.cs	9cd8 <fwp_main_thread+0x1c88>  // b.hs, b.nlast
    9cb8:	8b020108 	add	x8, x8, x2
    9cbc:	39400102 	ldrb	w2, [x8]
    9cc0:	7100045f 	cmp	w2, #0x1
    9cc4:	540000a1 	b.ne	9cd8 <fwp_main_thread+0x1c88>  // b.any
    9cc8:	97ffeb8a 	bl	4af0 <fwp_mem_free>
    9ccc:	f949ef43 	ldr	x3, [x26, #5080]
    9cd0:	f949db41 	ldr	x1, [x26, #5040]
    9cd4:	d370bc63 	lsl	x3, x3, #16
    9cd8:	cb010361 	sub	x1, x27, x1
    9cdc:	eb03003f 	cmp	x1, x3
    9ce0:	54ff7903 	b.cc	8c00 <fwp_main_thread+0xbb0>  // b.lo, b.ul, b.last
    9ce4:	17fffbe3 	b	8c70 <fwp_main_thread+0xc20>
    9ce8:	72003c3f 	tst	w1, #0xffff
    9cec:	54ffd3a1 	b.ne	9760 <fwp_main_thread+0x1710>  // b.any
    9cf0:	17fffe94 	b	9740 <fwp_main_thread+0x16f0>
    9cf4:	f94006d6 	ldr	x22, [x22, #8]
    9cf8:	eb08005f 	cmp	x2, x8
    9cfc:	54000349 	b.ls	9d64 <fwp_main_thread+0x1d14>  // b.plast
    9d00:	d350fd03 	lsr	x3, x8, #16
    9d04:	8b030863 	add	x3, x3, x3, lsl #2
    9d08:	d37df063 	lsl	x3, x3, #3
    9d0c:	8b0300a7 	add	x7, x5, x3
    9d10:	f94010e6 	ldr	x6, [x7, #32]
    9d14:	b4000286 	cbz	x6, 9d64 <fwp_main_thread+0x1d14>
    9d18:	386368a3 	ldrb	w3, [x5, x3]
    9d1c:	7100087f 	cmp	w3, #0x2
    9d20:	54001160 	b.eq	9f4c <fwp_main_thread+0x1efc>  // b.none
    9d24:	7100047f 	cmp	w3, #0x1
    9d28:	540001e1 	b.ne	9d64 <fwp_main_thread+0x1d14>  // b.any
    9d2c:	294314e9 	ldp	w9, w5, [x7, #24]
    9d30:	92403d03 	and	x3, x8, #0xffff
    9d34:	9b097c63 	mul	x3, x3, x9
    9d38:	d360fc63 	lsr	x3, x3, #32
    9d3c:	eb05007f 	cmp	x3, x5
    9d40:	54000122 	b.cs	9d64 <fwp_main_thread+0x1d14>  // b.hs, b.nlast
    9d44:	8b0300c6 	add	x6, x6, x3
    9d48:	394000c3 	ldrb	w3, [x6]
    9d4c:	7100047f 	cmp	w3, #0x1
    9d50:	540000a1 	b.ne	9d64 <fwp_main_thread+0x1d14>  // b.any
    9d54:	97ffeb67 	bl	4af0 <fwp_mem_free>
    9d58:	f949ef42 	ldr	x2, [x26, #5080]
    9d5c:	f949db41 	ldr	x1, [x26, #5040]
    9d60:	d370bc42 	lsl	x2, x2, #16
    9d64:	cb0102c3 	sub	x3, x22, x1
    9d68:	eb02007f 	cmp	x3, x2
    9d6c:	54ffc803 	b.cc	966c <fwp_main_thread+0x161c>  // b.lo, b.ul, b.last
    9d70:	17fffe5e 	b	96e8 <fwp_main_thread+0x1698>
    9d74:	f9401fe0 	ldr	x0, [sp, #56]
    9d78:	97ffe74a 	bl	3aa0 <fwp_closure_drop.part.0>
    9d7c:	17fffac3 	b	8888 <fwp_main_thread+0x838>
    9d80:	72003c7f 	tst	w3, #0xffff
    9d84:	54ff5581 	b.ne	8834 <fwp_main_thread+0x7e4>  // b.any
    9d88:	aa1603e0 	mov	x0, x22
    9d8c:	17fffa98 	b	87ec <fwp_main_thread+0x79c>
    9d90:	72003c7f 	tst	w3, #0xffff
    9d94:	54ff57a1 	b.ne	8888 <fwp_main_thread+0x838>  // b.any
    9d98:	17fffab3 	b	8864 <fwp_main_thread+0x814>
    9d9c:	72003c3f 	tst	w1, #0xffff
    9da0:	54ff6d01 	b.ne	8b40 <fwp_main_thread+0xaf0>  // b.any
    9da4:	39400380 	ldrb	w0, [x28]
    9da8:	7103fc1f 	cmp	w0, #0xff
    9dac:	54ff6c61 	b.ne	8b38 <fwp_main_thread+0xae8>  // b.any
    9db0:	aa1c03e0 	mov	x0, x28
    9db4:	97ffeaaf 	bl	4870 <fwp_rc_forget_slot>
    9db8:	17fffb60 	b	8b38 <fwp_main_thread+0xae8>
    9dbc:	aa1903f6 	mov	x22, x25
    9dc0:	17fffbe6 	b	8d58 <fwp_main_thread+0xd08>
    9dc4:	72003c3f 	tst	w1, #0xffff
    9dc8:	54ff8c61 	b.ne	8f54 <fwp_main_thread+0xf04>  // b.any
    9dcc:	394002c0 	ldrb	w0, [x22]
    9dd0:	7103fc1f 	cmp	w0, #0xff
    9dd4:	54ff8bc1 	b.ne	8f4c <fwp_main_thread+0xefc>  // b.any
    9dd8:	aa1603e0 	mov	x0, x22
    9ddc:	97ffeaa5 	bl	4870 <fwp_rc_forget_slot>
    9de0:	17fffc5b 	b	8f4c <fwp_main_thread+0xefc>
    9de4:	72003c5f 	tst	w2, #0xffff
    9de8:	54ff7441 	b.ne	8c70 <fwp_main_thread+0xc20>  // b.any
    9dec:	17fffd35 	b	92c0 <fwp_main_thread+0x1270>
    9df0:	f949ef45 	ldr	x5, [x26, #5080]
    9df4:	f949db41 	ldr	x1, [x26, #5040]
    9df8:	d370bca5 	lsl	x5, x5, #16
    9dfc:	cb010360 	sub	x0, x27, x1
    9e00:	f9400b76 	ldr	x22, [x27, #16]
    9e04:	eb05001f 	cmp	x0, x5
    9e08:	54000362 	b.cs	9e74 <fwp_main_thread+0x1e24>  // b.hs, b.nlast
    9e0c:	d350fc02 	lsr	x2, x0, #16
    9e10:	8b020842 	add	x2, x2, x2, lsl #2
    9e14:	d37df042 	lsl	x2, x2, #3
    9e18:	8b020067 	add	x7, x3, x2
    9e1c:	f94010e6 	ldr	x6, [x7, #32]
    9e20:	b40002a6 	cbz	x6, 9e74 <fwp_main_thread+0x1e24>
    9e24:	38626862 	ldrb	w2, [x3, x2]
    9e28:	7100085f 	cmp	w2, #0x2
    9e2c:	540009c0 	b.eq	9f64 <fwp_main_thread+0x1f14>  // b.none
    9e30:	7100045f 	cmp	w2, #0x1
    9e34:	54000201 	b.ne	9e74 <fwp_main_thread+0x1e24>  // b.any
    9e38:	294308e3 	ldp	w3, w2, [x7, #24]
    9e3c:	92403c00 	and	x0, x0, #0xffff
    9e40:	9b037c00 	mul	x0, x0, x3
    9e44:	d360fc00 	lsr	x0, x0, #32
    9e48:	eb02001f 	cmp	x0, x2
    9e4c:	54000142 	b.cs	9e74 <fwp_main_thread+0x1e24>  // b.hs, b.nlast
    9e50:	8b0000c6 	add	x6, x6, x0
    9e54:	394000c0 	ldrb	w0, [x6]
    9e58:	7100041f 	cmp	w0, #0x1
    9e5c:	540000c1 	b.ne	9e74 <fwp_main_thread+0x1e24>  // b.any
    9e60:	aa1b03e0 	mov	x0, x27
    9e64:	97ffeb23 	bl	4af0 <fwp_mem_free>
    9e68:	f949ef45 	ldr	x5, [x26, #5080]
    9e6c:	f949db41 	ldr	x1, [x26, #5040]
    9e70:	d370bca5 	lsl	x5, x5, #16
    9e74:	cb0102c1 	sub	x1, x22, x1
    9e78:	eb0100bf 	cmp	x5, x1
    9e7c:	54ffc729 	b.ls	9760 <fwp_main_thread+0x1710>  // b.plast
    9e80:	aa1603fb 	mov	x27, x22
    9e84:	17fffe1c 	b	96f4 <fwp_main_thread+0x16a4>
    9e88:	72003d1f 	tst	w8, #0xffff
    9e8c:	54ffc2e1 	b.ne	96e8 <fwp_main_thread+0x1698>  // b.any
    9e90:	17fffebc 	b	9980 <fwp_main_thread+0x1930>
    9e94:	72003c3f 	tst	w1, #0xffff
    9e98:	54ffe900 	b.eq	9bb8 <fwp_main_thread+0x1b68>  // b.none
    9e9c:	aa1703e0 	mov	x0, x23
    9ea0:	17fffc56 	b	8ff8 <fwp_main_thread+0xfa8>
    9ea4:	aa1b03e0 	mov	x0, x27
    9ea8:	f90003e5 	str	x5, [sp]
    9eac:	97ffea71 	bl	4870 <fwp_rc_forget_slot>
    9eb0:	f94003e5 	ldr	x5, [sp]
    9eb4:	17ffff44 	b	9bc4 <fwp_main_thread+0x1b74>
    9eb8:	aa0203e0 	mov	x0, x2
    9ebc:	d2800101 	mov	x1, #0x8                   	// #8
    9ec0:	f90023e2 	str	x2, [sp, #64]
    9ec4:	97ffe28b 	bl	28f0 <calloc@plt>
    9ec8:	f94023e2 	ldr	x2, [sp, #64]
    9ecc:	aa0003fb 	mov	x27, x0
    9ed0:	17fffbb4 	b	8da0 <fwp_main_thread+0xd50>
    9ed4:	d2800d01 	mov	x1, #0x68                  	// #104
    9ed8:	d2800038 	mov	x24, #0x1                   	// #1
    9edc:	17fffa9e 	b	8954 <fwp_main_thread+0x904>
    9ee0:	f94000a0 	ldr	x0, [x5]
    9ee4:	b7ffe7e0 	tbnz	x0, #63, 9be0 <fwp_main_thread+0x1b90>
    9ee8:	f949db41 	ldr	x1, [x26, #5040]
    9eec:	f949ef43 	ldr	x3, [x26, #5080]
    9ef0:	cb0102c1 	sub	x1, x22, x1
    9ef4:	eb03403f 	cmp	x1, x3, lsl #16
    9ef8:	54ffe742 	b.cs	9be0 <fwp_main_thread+0x1b90>  // b.hs, b.nlast
    9efc:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    9f00:	17fffd07 	b	931c <fwp_main_thread+0x12cc>
    9f04:	aa1603e0 	mov	x0, x22
    9f08:	97ffedeb 	bl	56b4 <fwp_rc_free_arr>
    9f0c:	f94027e0 	ldr	x0, [sp, #72]
    9f10:	f9400800 	ldr	x0, [x0, #16]
    9f14:	f90027e0 	str	x0, [sp, #72]
    9f18:	b5ffcf80 	cbnz	x0, 9908 <fwp_main_thread+0x18b8>
    9f1c:	aa1503e0 	mov	x0, x21
    9f20:	97ffef10 	bl	5b60 <fwp_drop0>
    9f24:	f9400fe0 	ldr	x0, [sp, #24]
    9f28:	97ffef0e 	bl	5b60 <fwp_drop0>
    9f2c:	9101c260 	add	x0, x19, #0x70
    9f30:	fd40fbe8 	ldr	d8, [sp, #496]
    9f34:	a95d6bf9 	ldp	x25, x26, [sp, #464]
    9f38:	52800021 	mov	w1, #0x1                   	// #1
    9f3c:	a95e73fb 	ldp	x27, x28, [sp, #480]
    9f40:	b9034801 	str	w1, [x0, #840]
    9f44:	f901a81f 	str	xzr, [x0, #848]
    9f48:	17fff885 	b	815c <fwp_main_thread+0x10c>
    9f4c:	72003d1f 	tst	w8, #0xffff
    9f50:	54fff0a1 	b.ne	9d64 <fwp_main_thread+0x1d14>  // b.any
    9f54:	17ffff7d 	b	9d48 <fwp_main_thread+0x1cf8>
    9f58:	72003c5f 	tst	w2, #0xffff
    9f5c:	54ffebe1 	b.ne	9cd8 <fwp_main_thread+0x1c88>  // b.any
    9f60:	17ffff57 	b	9cbc <fwp_main_thread+0x1c6c>
    9f64:	72003c1f 	tst	w0, #0xffff
    9f68:	54fff861 	b.ne	9e74 <fwp_main_thread+0x1e24>  // b.any
    9f6c:	17ffffba 	b	9e54 <fwp_main_thread+0x1e04>
    9f70:	72003c5f 	tst	w2, #0xffff
    9f74:	54ff3fa1 	b.ne	8768 <fwp_main_thread+0x718>  // b.any
    9f78:	17fff9f3 	b	8744 <fwp_main_thread+0x6f4>
    9f7c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9f80:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9f84:	91174021 	add	x1, x1, #0x5d0
    9f88:	ca402400 	eor	x0, x0, x0, lsr #9
    9f8c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9f90:	f94a2401 	ldr	x1, [x0, #5192]
    9f94:	b5000081 	cbnz	x1, 9fa4 <fwp_main_thread+0x1f54>
    9f98:	14000011 	b	9fdc <fwp_main_thread+0x1f8c>
    9f9c:	f9400821 	ldr	x1, [x1, #16]
    9fa0:	b40001e1 	cbz	x1, 9fdc <fwp_main_thread+0x1f8c>
    9fa4:	f9400020 	ldr	x0, [x1]
    9fa8:	eb0002ff 	cmp	x23, x0
    9fac:	54ffff81 	b.ne	9f9c <fwp_main_thread+0x1f4c>  // b.any
    9fb0:	f9400420 	ldr	x0, [x1, #8]
    9fb4:	d1000400 	sub	x0, x0, #0x1
    9fb8:	f9000420 	str	x0, [x1, #8]
    9fbc:	f103f81f 	cmp	x0, #0xfe
    9fc0:	54000f60 	b.eq	a1ac <fwp_main_thread+0x215c>  // b.none
    9fc4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc10>
    9fc8:	91174000 	add	x0, x0, #0x5d0
    9fcc:	f949ec02 	ldr	x2, [x0, #5080]
    9fd0:	f949d801 	ldr	x1, [x0, #5040]
    9fd4:	d370bc42 	lsl	x2, x2, #16
    9fd8:	17fffdc4 	b	96e8 <fwp_main_thread+0x1698>
    9fdc:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    9fe0:	91370000 	add	x0, x0, #0xdc0
    9fe4:	97ffe627 	bl	3880 <fwp_trap>
    9fe8:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9fec:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc10>
    9ff0:	91174021 	add	x1, x1, #0x5d0
    9ff4:	ca402400 	eor	x0, x0, x0, lsr #9
    9ff8:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ffc:	f94a2400 	ldr	x0, [x0, #5192]
    a000:	b5000080 	cbnz	x0, a010 <fwp_main_thread+0x1fc0>
    a004:	17fffff6 	b	9fdc <fwp_main_thread+0x1f8c>
    a008:	f9400800 	ldr	x0, [x0, #16]
    a00c:	b4fffe80 	cbz	x0, 9fdc <fwp_main_thread+0x1f8c>
    a010:	f9400001 	ldr	x1, [x0]
    a014:	eb17003f 	cmp	x1, x23
    a018:	54ffff81 	b.ne	a008 <fwp_main_thread+0x1fb8>  // b.any
    a01c:	f9400401 	ldr	x1, [x0, #8]
    a020:	d1000421 	sub	x1, x1, #0x1
    a024:	f9000401 	str	x1, [x0, #8]
    a028:	f103f83f 	cmp	x1, #0xfe
    a02c:	54ff6221 	b.ne	8c70 <fwp_main_thread+0xc20>  // b.any
    a030:	aa1703e0 	mov	x0, x23
    a034:	97ffea0f 	bl	4870 <fwp_rc_forget_slot>
    a038:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a03c:	390002e0 	strb	w0, [x23]
    a040:	17fffb0c 	b	8c70 <fwp_main_thread+0xc20>
    a044:	72003c5f 	tst	w2, #0xffff
    a048:	54ffc021 	b.ne	984c <fwp_main_thread+0x17fc>  // b.any
    a04c:	17fffdfb 	b	9838 <fwp_main_thread+0x17e8>
    a050:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a054:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a058:	91174021 	add	x1, x1, #0x5d0
    a05c:	ca402400 	eor	x0, x0, x0, lsr #9
    a060:	8b200c20 	add	x0, x1, w0, uxtb #3
    a064:	f94a2401 	ldr	x1, [x0, #5192]
    a068:	b5000081 	cbnz	x1, a078 <fwp_main_thread+0x2028>
    a06c:	17ffffdc 	b	9fdc <fwp_main_thread+0x1f8c>
    a070:	f9400821 	ldr	x1, [x1, #16]
    a074:	b4fffb41 	cbz	x1, 9fdc <fwp_main_thread+0x1f8c>
    a078:	f9400020 	ldr	x0, [x1]
    a07c:	eb16001f 	cmp	x0, x22
    a080:	54ffff81 	b.ne	a070 <fwp_main_thread+0x2020>  // b.any
    a084:	f9400420 	ldr	x0, [x1, #8]
    a088:	d1000400 	sub	x0, x0, #0x1
    a08c:	f9000420 	str	x0, [x1, #8]
    a090:	f103f81f 	cmp	x0, #0xfe
    a094:	54ffb661 	b.ne	9760 <fwp_main_thread+0x1710>  // b.any
    a098:	aa1603e0 	mov	x0, x22
    a09c:	97ffe9f5 	bl	4870 <fwp_rc_forget_slot>
    a0a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a0a4:	390002c0 	strb	w0, [x22]
    a0a8:	17fffdae 	b	9760 <fwp_main_thread+0x1710>
    a0ac:	72003c5f 	tst	w2, #0xffff
    a0b0:	54ffc241 	b.ne	98f8 <fwp_main_thread+0x18a8>  // b.any
    a0b4:	17fffe09 	b	98d8 <fwp_main_thread+0x1888>
    a0b8:	aa1503fb 	mov	x27, x21
    a0bc:	d280001c 	mov	x28, #0x0                   	// #0
    a0c0:	d2800018 	mov	x24, #0x0                   	// #0
    a0c4:	17fffd62 	b	964c <fwp_main_thread+0x15fc>
    a0c8:	97ffe9a3 	bl	4754 <fwp_rc_wide_dup>
    a0cc:	17fff9ce 	b	8804 <fwp_main_thread+0x7b4>
    a0d0:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a0d4:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a0d8:	91174021 	add	x1, x1, #0x5d0
    a0dc:	ca402400 	eor	x0, x0, x0, lsr #9
    a0e0:	8b200c20 	add	x0, x1, w0, uxtb #3
    a0e4:	f94a2400 	ldr	x0, [x0, #5192]
    a0e8:	b5000080 	cbnz	x0, a0f8 <fwp_main_thread+0x20a8>
    a0ec:	17ffffbc 	b	9fdc <fwp_main_thread+0x1f8c>
    a0f0:	f9400800 	ldr	x0, [x0, #16]
    a0f4:	b4fff740 	cbz	x0, 9fdc <fwp_main_thread+0x1f8c>
    a0f8:	f9400001 	ldr	x1, [x0]
    a0fc:	eb16003f 	cmp	x1, x22
    a100:	54ffff81 	b.ne	a0f0 <fwp_main_thread+0x20a0>  // b.any
    a104:	f9400401 	ldr	x1, [x0, #8]
    a108:	d1000421 	sub	x1, x1, #0x1
    a10c:	f9000401 	str	x1, [x0, #8]
    a110:	f103f83f 	cmp	x1, #0xfe
    a114:	54ff3ba1 	b.ne	8888 <fwp_main_thread+0x838>  // b.any
    a118:	aa1603e0 	mov	x0, x22
    a11c:	97ffe9d5 	bl	4870 <fwp_rc_forget_slot>
    a120:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a124:	390002c0 	strb	w0, [x22]
    a128:	17fff9d8 	b	8888 <fwp_main_thread+0x838>
    a12c:	72003c3f 	tst	w1, #0xffff
    a130:	54ff2221 	b.ne	8574 <fwp_main_thread+0x524>  // b.any
    a134:	17fff90b 	b	8560 <fwp_main_thread+0x510>
    a138:	72003c3f 	tst	w1, #0xffff
    a13c:	54ff2b21 	b.ne	86a0 <fwp_main_thread+0x650>  // b.any
    a140:	17fff953 	b	868c <fwp_main_thread+0x63c>
    a144:	72003c3f 	tst	w1, #0xffff
    a148:	54ff2601 	b.ne	8608 <fwp_main_thread+0x5b8>  // b.any
    a14c:	17fff92a 	b	85f4 <fwp_main_thread+0x5a4>
    a150:	aa0003e1 	mov	x1, x0
    a154:	f90022b4 	str	x20, [x21, #64]
    a158:	17fff81a 	b	81c0 <fwp_main_thread+0x170>
    a15c:	d2800017 	mov	x23, #0x0                   	// #0
    a160:	17fffcca 	b	9488 <fwp_main_thread+0x1438>
    a164:	aa1703e0 	mov	x0, x23
    a168:	97ffe9c2 	bl	4870 <fwp_rc_forget_slot>
    a16c:	17fffdb6 	b	9844 <fwp_main_thread+0x17f4>
    a170:	f94192a0 	ldr	x0, [x21, #800]
    a174:	97ffea5f 	bl	4af0 <fwp_mem_free>
    a178:	f90192bf 	str	xzr, [x21, #800]
    a17c:	f9019abf 	str	xzr, [x21, #816]
    a180:	f941b2a0 	ldr	x0, [x21, #864]
    a184:	b40007d4 	cbz	x20, a27c <fwp_main_thread+0x222c>
    a188:	f900569f 	str	xzr, [x20, #168]
    a18c:	f9005e9f 	str	xzr, [x20, #184]
    a190:	b9035abf 	str	wzr, [x21, #856]
    a194:	eb14001f 	cmp	x0, x20
    a198:	54ff0740 	b.eq	8280 <fwp_main_thread+0x230>  // b.none
    a19c:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a1a0:	a91e73fb 	stp	x27, x28, [sp, #480]
    a1a4:	fd00fbe8 	str	d8, [sp, #496]
    a1a8:	97ffe1ee 	bl	2960 <abort@plt>
    a1ac:	aa1703e0 	mov	x0, x23
    a1b0:	97ffe9b0 	bl	4870 <fwp_rc_forget_slot>
    a1b4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a1b8:	91174000 	add	x0, x0, #0x5d0
    a1bc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a1c0:	390002e1 	strb	w1, [x23]
    a1c4:	f949ec02 	ldr	x2, [x0, #5080]
    a1c8:	f949d801 	ldr	x1, [x0, #5040]
    a1cc:	d370bc42 	lsl	x2, x2, #16
    a1d0:	17fffd46 	b	96e8 <fwp_main_thread+0x1698>
    a1d4:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    a1d8:	913a8000 	add	x0, x0, #0xea0
    a1dc:	97ffe5a9 	bl	3880 <fwp_trap>
    a1e0:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    a1e4:	91382000 	add	x0, x0, #0xe08
    a1e8:	97ffe5a6 	bl	3880 <fwp_trap>
    a1ec:	97ffe95a 	bl	4754 <fwp_rc_wide_dup>
    a1f0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc10>
    a1f4:	91174000 	add	x0, x0, #0x5d0
    a1f8:	f949ec06 	ldr	x6, [x0, #5080]
    a1fc:	f949d803 	ldr	x3, [x0, #5040]
    a200:	d370bcc6 	lsl	x6, x6, #16
    a204:	17fff959 	b	8768 <fwp_main_thread+0x718>
    a208:	ca5746e0 	eor	x0, x23, x23, lsr #17
    a20c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc10>
    a210:	91174021 	add	x1, x1, #0x5d0
    a214:	ca402400 	eor	x0, x0, x0, lsr #9
    a218:	8b200c20 	add	x0, x1, w0, uxtb #3
    a21c:	f94a2400 	ldr	x0, [x0, #5192]
    a220:	b5000080 	cbnz	x0, a230 <fwp_main_thread+0x21e0>
    a224:	17ffff6e 	b	9fdc <fwp_main_thread+0x1f8c>
    a228:	f9400800 	ldr	x0, [x0, #16]
    a22c:	b4ffed80 	cbz	x0, 9fdc <fwp_main_thread+0x1f8c>
    a230:	f9400001 	ldr	x1, [x0]
    a234:	eb0102ff 	cmp	x23, x1
    a238:	54ffff81 	b.ne	a228 <fwp_main_thread+0x21d8>  // b.any
    a23c:	f9400401 	ldr	x1, [x0, #8]
    a240:	d1000421 	sub	x1, x1, #0x1
    a244:	f9000401 	str	x1, [x0, #8]
    a248:	f103f83f 	cmp	x1, #0xfe
    a24c:	54ffb561 	b.ne	98f8 <fwp_main_thread+0x18a8>  // b.any
    a250:	aa1703e0 	mov	x0, x23
    a254:	97ffe987 	bl	4870 <fwp_rc_forget_slot>
    a258:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a25c:	390002e0 	strb	w0, [x23]
    a260:	17fffda6 	b	98f8 <fwp_main_thread+0x18a8>
    a264:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a268:	91022000 	add	x0, x0, #0x88
    a26c:	97ffe585 	bl	3880 <fwp_trap>
    a270:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    a274:	913c0000 	add	x0, x0, #0xf00
    a278:	97ffe582 	bl	3880 <fwp_trap>
    a27c:	b9035abf 	str	wzr, [x21, #856]
    a280:	b4ff6ea0 	cbz	x0, 9054 <fwp_main_thread+0x1004>
    a284:	17ffffc6 	b	a19c <fwp_main_thread+0x214c>
    a288:	aa1503e0 	mov	x0, x21
    a28c:	97ffe979 	bl	4870 <fwp_rc_forget_slot>
    a290:	17fff8b7 	b	856c <fwp_main_thread+0x51c>
    a294:	aa1503e0 	mov	x0, x21
    a298:	97ffe976 	bl	4870 <fwp_rc_forget_slot>
    a29c:	17fff8d9 	b	8600 <fwp_main_thread+0x5b0>
    a2a0:	aa1703e0 	mov	x0, x23
    a2a4:	97ffe973 	bl	4870 <fwp_rc_forget_slot>
    a2a8:	17fff8fc 	b	8698 <fwp_main_thread+0x648>
    a2ac:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a2b0:	91032000 	add	x0, x0, #0xc8
    a2b4:	97ffe573 	bl	3880 <fwp_trap>
    a2b8:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a2bc:	9102c000 	add	x0, x0, #0xb0
    a2c0:	97ffe570 	bl	3880 <fwp_trap>
    a2c4:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a2c8:	91000000 	add	x0, x0, #0x0
    a2cc:	a91c63f7 	stp	x23, x24, [sp, #448]
    a2d0:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2d4:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2d8:	fd00fbe8 	str	d8, [sp, #496]
    a2dc:	97ffe569 	bl	3880 <fwp_trap>
    a2e0:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2e4:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2e8:	fd00fbe8 	str	d8, [sp, #496]
    a2ec:	97ffe3b1 	bl	31b0 <descent_phase_fail>
    a2f0:	a91d6bf9 	stp	x25, x26, [sp, #464]
    a2f4:	a91e73fb 	stp	x27, x28, [sp, #480]
    a2f8:	fd00fbe8 	str	d8, [sp, #496]
    a2fc:	97ffe185 	bl	2910 <__stack_chk_fail@plt>
    a300:	52800020 	mov	w0, #0x1                   	// #1
    a304:	17fffbc0 	b	9204 <fwp_main_thread+0x11b4>
    a308:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a30c:	9101e000 	add	x0, x0, #0x78
    a310:	97ffe55c 	bl	3880 <fwp_trap>
    a314:	90000000 	adrp	x0, a000 <fwp_main_thread+0x1fb0>
    a318:	91394000 	add	x0, x0, #0xe50
    a31c:	97ffe559 	bl	3880 <fwp_trap>
    a320:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a324:	9100a000 	add	x0, x0, #0x28
    a328:	97ffe556 	bl	3880 <fwp_trap>
    a32c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x5a0>
    a330:	91012000 	add	x0, x0, #0x48
    a334:	97ffe553 	bl	3880 <fwp_trap>
    a338:	97ffe1f2 	bl	2b00 <fwp_trap_overflow.constprop.0>
    a33c:	d503201f 	nop

000000000000a340 <__divti3>:
    a340:	d503245f 	bti	c
    a344:	d2800004 	mov	x4, #0x0                   	// #0
    a348:	b7f80721 	tbnz	x1, #63, a42c <__divti3+0xec>
    a34c:	b6f80083 	tbz	x3, #63, a35c <__divti3+0x1c>
    a350:	eb0203e2 	negs	x2, x2
    a354:	aa2403e4 	mvn	x4, x4
    a358:	da0303e3 	ngc	x3, x3
    a35c:	aa0203e6 	mov	x6, x2
    a360:	aa0003e7 	mov	x7, x0
    a364:	aa0103e5 	mov	x5, x1
    a368:	b5000583 	cbnz	x3, a418 <__divti3+0xd8>
    a36c:	eb01005f 	cmp	x2, x1
    a370:	54000e69 	b.ls	a53c <__divti3+0x1fc>  // b.plast
    a374:	dac01040 	clz	x0, x2
    a378:	b40000e0 	cbz	x0, a394 <__divti3+0x54>
    a37c:	4b0003e1 	neg	w1, w0
    a380:	9ac020a5 	lsl	x5, x5, x0
    a384:	9ac02046 	lsl	x6, x2, x0
    a388:	9ac124e1 	lsr	x1, x7, x1
    a38c:	aa050025 	orr	x5, x1, x5
    a390:	9ac020e7 	lsl	x7, x7, x0
    a394:	d360fcc8 	lsr	x8, x6, #32
    a398:	92407cc2 	and	x2, x6, #0xffffffff
    a39c:	9ac808a3 	udiv	x3, x5, x8
    a3a0:	9b089465 	msub	x5, x3, x8, x5
    a3a4:	aa0303e0 	mov	x0, x3
    a3a8:	9b037c41 	mul	x1, x2, x3
    a3ac:	93c780a5 	extr	x5, x5, x7, #32
    a3b0:	eb05003f 	cmp	x1, x5
    a3b4:	540000a9 	b.ls	a3c8 <__divti3+0x88>  // b.plast
    a3b8:	ab0500c5 	adds	x5, x6, x5
    a3bc:	d1000460 	sub	x0, x3, #0x1
    a3c0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a3c4:	540015a8 	b.hi	a678 <__divti3+0x338>  // b.pmore
    a3c8:	cb0100a5 	sub	x5, x5, x1
    a3cc:	9ac808a3 	udiv	x3, x5, x8
    a3d0:	9b089465 	msub	x5, x3, x8, x5
    a3d4:	aa0303e1 	mov	x1, x3
    a3d8:	9b037c42 	mul	x2, x2, x3
    a3dc:	aa0703e3 	mov	x3, x7
    a3e0:	b3607ca3 	bfi	x3, x5, #32, #32
    a3e4:	eb03005f 	cmp	x2, x3
    a3e8:	540000c9 	b.ls	a400 <__divti3+0xc0>  // b.plast
    a3ec:	ab0300c3 	adds	x3, x6, x3
    a3f0:	d1000425 	sub	x5, x1, #0x1
    a3f4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a3f8:	d1000821 	sub	x1, x1, #0x2
    a3fc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a400:	aa008020 	orr	x0, x1, x0, lsl #32
    a404:	d2800001 	mov	x1, #0x0                   	// #0
    a408:	b4000064 	cbz	x4, a414 <__divti3+0xd4>
    a40c:	eb0003e0 	negs	x0, x0
    a410:	da0103e1 	ngc	x1, x1
    a414:	d65f03c0 	ret
    a418:	eb01007f 	cmp	x3, x1
    a41c:	54000109 	b.ls	a43c <__divti3+0xfc>  // b.plast
    a420:	d2800001 	mov	x1, #0x0                   	// #0
    a424:	d2800000 	mov	x0, #0x0                   	// #0
    a428:	17fffff8 	b	a408 <__divti3+0xc8>
    a42c:	eb0003e0 	negs	x0, x0
    a430:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a434:	da0103e1 	ngc	x1, x1
    a438:	17ffffc5 	b	a34c <__divti3+0xc>
    a43c:	dac01067 	clz	x7, x3
    a440:	b40010e7 	cbz	x7, a65c <__divti3+0x31c>
    a444:	d2800805 	mov	x5, #0x40                  	// #64
    a448:	cb0700a5 	sub	x5, x5, x7
    a44c:	9ac72063 	lsl	x3, x3, x7
    a450:	9ac52448 	lsr	x8, x2, x5
    a454:	aa030108 	orr	x8, x8, x3
    a458:	9ac52426 	lsr	x6, x1, x5
    a45c:	92407d0a 	and	x10, x8, #0xffffffff
    a460:	d360fd09 	lsr	x9, x8, #32
    a464:	9ac52403 	lsr	x3, x0, x5
    a468:	9ac72021 	lsl	x1, x1, x7
    a46c:	aa010063 	orr	x3, x3, x1
    a470:	9ac72042 	lsl	x2, x2, x7
    a474:	9ac908cb 	udiv	x11, x6, x9
    a478:	9b099965 	msub	x5, x11, x9, x6
    a47c:	aa0b03e1 	mov	x1, x11
    a480:	9b0b7d46 	mul	x6, x10, x11
    a484:	93c380a5 	extr	x5, x5, x3, #32
    a488:	eb0500df 	cmp	x6, x5
    a48c:	540000a9 	b.ls	a4a0 <__divti3+0x160>  // b.plast
    a490:	ab050105 	adds	x5, x8, x5
    a494:	d1000561 	sub	x1, x11, #0x1
    a498:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a49c:	54000f48 	b.hi	a684 <__divti3+0x344>  // b.pmore
    a4a0:	cb0600a6 	sub	x6, x5, x6
    a4a4:	9ac908cb 	udiv	x11, x6, x9
    a4a8:	9b099969 	msub	x9, x11, x9, x6
    a4ac:	aa0b03e5 	mov	x5, x11
    a4b0:	9b0b7d4a 	mul	x10, x10, x11
    a4b4:	b3607d23 	bfi	x3, x9, #32, #32
    a4b8:	eb03015f 	cmp	x10, x3
    a4bc:	540000a9 	b.ls	a4d0 <__divti3+0x190>  // b.plast
    a4c0:	ab030103 	adds	x3, x8, x3
    a4c4:	d1000565 	sub	x5, x11, #0x1
    a4c8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a4cc:	54000e28 	b.hi	a690 <__divti3+0x350>  // b.pmore
    a4d0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a4d4:	92407c48 	and	x8, x2, #0xffffffff
    a4d8:	2a0503e5 	mov	w5, w5
    a4dc:	d360fc42 	lsr	x2, x2, #32
    a4e0:	d360fc26 	lsr	x6, x1, #32
    a4e4:	cb0a0063 	sub	x3, x3, x10
    a4e8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a4ec:	9b087caa 	mul	x10, x5, x8
    a4f0:	9b087cc8 	mul	x8, x6, x8
    a4f4:	9b0220a5 	madd	x5, x5, x2, x8
    a4f8:	9b027cc6 	mul	x6, x6, x2
    a4fc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a500:	8b0900c5 	add	x5, x6, x9
    a504:	eb02011f 	cmp	x8, x2
    a508:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a50c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a510:	eb06007f 	cmp	x3, x6
    a514:	540000e3 	b.cc	a530 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a518:	92407d4a 	and	x10, x10, #0xffffffff
    a51c:	9ac72000 	lsl	x0, x0, x7
    a520:	8b028142 	add	x2, x10, x2, lsl #32
    a524:	eb02001f 	cmp	x0, x2
    a528:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a52c:	54000a01 	b.ne	a66c <__divti3+0x32c>  // b.any
    a530:	d1000420 	sub	x0, x1, #0x1
    a534:	d2800001 	mov	x1, #0x0                   	// #0
    a538:	17ffffb4 	b	a408 <__divti3+0xc8>
    a53c:	b5000062 	cbnz	x2, a548 <__divti3+0x208>
    a540:	d2800022 	mov	x2, #0x1                   	// #1
    a544:	9ac30846 	udiv	x6, x2, x3
    a548:	dac010c8 	clz	x8, x6
    a54c:	b5000408 	cbnz	x8, a5cc <__divti3+0x28c>
    a550:	d360fcc9 	lsr	x9, x6, #32
    a554:	92407cc5 	and	x5, x6, #0xffffffff
    a558:	cb060023 	sub	x3, x1, x6
    a55c:	d2800021 	mov	x1, #0x1                   	// #1
    a560:	9ac90868 	udiv	x8, x3, x9
    a564:	9b098d03 	msub	x3, x8, x9, x3
    a568:	aa0803e0 	mov	x0, x8
    a56c:	9b057d02 	mul	x2, x8, x5
    a570:	93c78063 	extr	x3, x3, x7, #32
    a574:	eb03005f 	cmp	x2, x3
    a578:	540000a9 	b.ls	a58c <__divti3+0x24c>  // b.plast
    a57c:	ab0300c3 	adds	x3, x6, x3
    a580:	d1000500 	sub	x0, x8, #0x1
    a584:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a588:	54000968 	b.hi	a6b4 <__divti3+0x374>  // b.pmore
    a58c:	cb020063 	sub	x3, x3, x2
    a590:	9ac90862 	udiv	x2, x3, x9
    a594:	aa0203e8 	mov	x8, x2
    a598:	9b098c42 	msub	x2, x2, x9, x3
    a59c:	aa0703e3 	mov	x3, x7
    a5a0:	9b057d05 	mul	x5, x8, x5
    a5a4:	b3607c43 	bfi	x3, x2, #32, #32
    a5a8:	eb0300bf 	cmp	x5, x3
    a5ac:	540000c9 	b.ls	a5c4 <__divti3+0x284>  // b.plast
    a5b0:	ab0300c2 	adds	x2, x6, x3
    a5b4:	d1000503 	sub	x3, x8, #0x1
    a5b8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a5bc:	d1000908 	sub	x8, x8, #0x2
    a5c0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a5c4:	aa008100 	orr	x0, x8, x0, lsl #32
    a5c8:	17ffff90 	b	a408 <__divti3+0xc8>
    a5cc:	9ac820c6 	lsl	x6, x6, x8
    a5d0:	d2800803 	mov	x3, #0x40                  	// #64
    a5d4:	cb080063 	sub	x3, x3, x8
    a5d8:	d360fcc9 	lsr	x9, x6, #32
    a5dc:	9ac82027 	lsl	x7, x1, x8
    a5e0:	92407cc5 	and	x5, x6, #0xffffffff
    a5e4:	9ac32422 	lsr	x2, x1, x3
    a5e8:	9ac32403 	lsr	x3, x0, x3
    a5ec:	aa070063 	orr	x3, x3, x7
    a5f0:	9ac9084a 	udiv	x10, x2, x9
    a5f4:	9ac82007 	lsl	x7, x0, x8
    a5f8:	9b098940 	msub	x0, x10, x9, x2
    a5fc:	aa0a03e1 	mov	x1, x10
    a600:	9b0a7ca2 	mul	x2, x5, x10
    a604:	93c38000 	extr	x0, x0, x3, #32
    a608:	eb00005f 	cmp	x2, x0
    a60c:	540000a9 	b.ls	a620 <__divti3+0x2e0>  // b.plast
    a610:	ab0000c0 	adds	x0, x6, x0
    a614:	d1000541 	sub	x1, x10, #0x1
    a618:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a61c:	54000468 	b.hi	a6a8 <__divti3+0x368>  // b.pmore
    a620:	cb020000 	sub	x0, x0, x2
    a624:	9ac9080a 	udiv	x10, x0, x9
    a628:	9b098140 	msub	x0, x10, x9, x0
    a62c:	aa0a03e2 	mov	x2, x10
    a630:	9b0a7ca8 	mul	x8, x5, x10
    a634:	b3607c03 	bfi	x3, x0, #32, #32
    a638:	eb03011f 	cmp	x8, x3
    a63c:	540000a9 	b.ls	a650 <__divti3+0x310>  // b.plast
    a640:	ab0300c3 	adds	x3, x6, x3
    a644:	d1000542 	sub	x2, x10, #0x1
    a648:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a64c:	54000288 	b.hi	a69c <__divti3+0x35c>  // b.pmore
    a650:	cb080063 	sub	x3, x3, x8
    a654:	aa018041 	orr	x1, x2, x1, lsl #32
    a658:	17ffffc2 	b	a560 <__divti3+0x220>
    a65c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a660:	d2800001 	mov	x1, #0x0                   	// #0
    a664:	9a9f87e0 	cset	x0, ls	// ls = plast
    a668:	17ffff68 	b	a408 <__divti3+0xc8>
    a66c:	aa0103e0 	mov	x0, x1
    a670:	d2800001 	mov	x1, #0x0                   	// #0
    a674:	17ffff65 	b	a408 <__divti3+0xc8>
    a678:	d1000860 	sub	x0, x3, #0x2
    a67c:	8b0600a5 	add	x5, x5, x6
    a680:	17ffff52 	b	a3c8 <__divti3+0x88>
    a684:	d1000961 	sub	x1, x11, #0x2
    a688:	8b0800a5 	add	x5, x5, x8
    a68c:	17ffff85 	b	a4a0 <__divti3+0x160>
    a690:	d1000965 	sub	x5, x11, #0x2
    a694:	8b080063 	add	x3, x3, x8
    a698:	17ffff8e 	b	a4d0 <__divti3+0x190>
    a69c:	d1000942 	sub	x2, x10, #0x2
    a6a0:	8b060063 	add	x3, x3, x6
    a6a4:	17ffffeb 	b	a650 <__divti3+0x310>
    a6a8:	d1000941 	sub	x1, x10, #0x2
    a6ac:	8b060000 	add	x0, x0, x6
    a6b0:	17ffffdc 	b	a620 <__divti3+0x2e0>
    a6b4:	d1000900 	sub	x0, x8, #0x2
    a6b8:	8b060063 	add	x3, x3, x6
    a6bc:	17ffffb4 	b	a58c <__divti3+0x24c>

000000000000a6c0 <__modti3>:
    a6c0:	d503245f 	bti	c
    a6c4:	d2800004 	mov	x4, #0x0                   	// #0
    a6c8:	b6f80081 	tbz	x1, #63, a6d8 <__modti3+0x18>
    a6cc:	eb0003e0 	negs	x0, x0
    a6d0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a6d4:	da0103e1 	ngc	x1, x1
    a6d8:	f100007f 	cmp	x3, #0x0
    a6dc:	5400128b 	b.lt	a92c <__modti3+0x26c>  // b.tstop
    a6e0:	aa0003e7 	mov	x7, x0
    a6e4:	aa0103e6 	mov	x6, x1
    a6e8:	540004e1 	b.ne	a784 <__modti3+0xc4>  // b.any
    a6ec:	eb02003f 	cmp	x1, x2
    a6f0:	54000dc2 	b.cs	a8a8 <__modti3+0x1e8>  // b.hs, b.nlast
    a6f4:	dac01043 	clz	x3, x2
    a6f8:	aa0303e5 	mov	x5, x3
    a6fc:	b40000e3 	cbz	x3, a718 <__modti3+0x58>
    a700:	4b0303e6 	neg	w6, w3
    a704:	9ac32021 	lsl	x1, x1, x3
    a708:	9ac32042 	lsl	x2, x2, x3
    a70c:	9ac62406 	lsr	x6, x0, x6
    a710:	aa0100c6 	orr	x6, x6, x1
    a714:	9ac32007 	lsl	x7, x0, x3
    a718:	d360fc40 	lsr	x0, x2, #32
    a71c:	92407c43 	and	x3, x2, #0xffffffff
    a720:	9ac008c1 	udiv	x1, x6, x0
    a724:	9b009826 	msub	x6, x1, x0, x6
    a728:	9b017c61 	mul	x1, x3, x1
    a72c:	93c780c6 	extr	x6, x6, x7, #32
    a730:	eb06003f 	cmp	x1, x6
    a734:	540000a9 	b.ls	a748 <__modti3+0x88>  // b.plast
    a738:	ab060046 	adds	x6, x2, x6
    a73c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a740:	8b0200c8 	add	x8, x6, x2
    a744:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a748:	cb0100c6 	sub	x6, x6, x1
    a74c:	9ac008c8 	udiv	x8, x6, x0
    a750:	9b009901 	msub	x1, x8, x0, x6
    a754:	aa0703e0 	mov	x0, x7
    a758:	9b087c63 	mul	x3, x3, x8
    a75c:	b3607c20 	bfi	x0, x1, #32, #32
    a760:	eb00007f 	cmp	x3, x0
    a764:	54001088 	b.hi	a974 <__modti3+0x2b4>  // b.pmore
    a768:	cb030000 	sub	x0, x0, x3
    a76c:	9ac52400 	lsr	x0, x0, x5
    a770:	d2800001 	mov	x1, #0x0                   	// #0
    a774:	b4000064 	cbz	x4, a780 <__modti3+0xc0>
    a778:	eb0003e0 	negs	x0, x0
    a77c:	da0103e1 	ngc	x1, x1
    a780:	d65f03c0 	ret
    a784:	dac01066 	clz	x6, x3
    a788:	eb03003f 	cmp	x1, x3
    a78c:	54ffff43 	b.cc	a774 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a790:	93407cc5 	sxtw	x5, w6
    a794:	d2800808 	mov	x8, #0x40                  	// #64
    a798:	cb050108 	sub	x8, x8, x5
    a79c:	9ac62063 	lsl	x3, x3, x6
    a7a0:	9ac62025 	lsl	x5, x1, x6
    a7a4:	9ac82447 	lsr	x7, x2, x8
    a7a8:	aa0300e7 	orr	x7, x7, x3
    a7ac:	9ac82423 	lsr	x3, x1, x8
    a7b0:	92407cec 	and	x12, x7, #0xffffffff
    a7b4:	d360fcea 	lsr	x10, x7, #32
    a7b8:	9ac82401 	lsr	x1, x0, x8
    a7bc:	aa050021 	orr	x1, x1, x5
    a7c0:	9ac62042 	lsl	x2, x2, x6
    a7c4:	9ac62000 	lsl	x0, x0, x6
    a7c8:	9aca086b 	udiv	x11, x3, x10
    a7cc:	9b0a8d63 	msub	x3, x11, x10, x3
    a7d0:	aa0b03e5 	mov	x5, x11
    a7d4:	9b0b7d89 	mul	x9, x12, x11
    a7d8:	93c18063 	extr	x3, x3, x1, #32
    a7dc:	eb03013f 	cmp	x9, x3
    a7e0:	540000a9 	b.ls	a7f4 <__modti3+0x134>  // b.plast
    a7e4:	ab0300e3 	adds	x3, x7, x3
    a7e8:	d1000565 	sub	x5, x11, #0x1
    a7ec:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a7f0:	54001168 	b.hi	aa1c <__modti3+0x35c>  // b.pmore
    a7f4:	cb090063 	sub	x3, x3, x9
    a7f8:	9aca086b 	udiv	x11, x3, x10
    a7fc:	9b0a8d6a 	msub	x10, x11, x10, x3
    a800:	aa0b03e9 	mov	x9, x11
    a804:	9b0b7d8c 	mul	x12, x12, x11
    a808:	b3607d41 	bfi	x1, x10, #32, #32
    a80c:	eb01019f 	cmp	x12, x1
    a810:	540000a9 	b.ls	a824 <__modti3+0x164>  // b.plast
    a814:	ab0100e1 	adds	x1, x7, x1
    a818:	d1000569 	sub	x9, x11, #0x1
    a81c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a820:	54000f88 	b.hi	aa10 <__modti3+0x350>  // b.pmore
    a824:	aa058123 	orr	x3, x9, x5, lsl #32
    a828:	92407c4b 	and	x11, x2, #0xffffffff
    a82c:	2a0903e9 	mov	w9, w9
    a830:	d360fc4a 	lsr	x10, x2, #32
    a834:	d360fc63 	lsr	x3, x3, #32
    a838:	cb0c0021 	sub	x1, x1, x12
    a83c:	aa0a03ec 	mov	x12, x10
    a840:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a844:	9b0b7d25 	mul	x5, x9, x11
    a848:	9b0b7c6b 	mul	x11, x3, x11
    a84c:	9b0a2d29 	madd	x9, x9, x10, x11
    a850:	92407caa 	and	x10, x5, #0xffffffff
    a854:	9b0c7c63 	mul	x3, x3, x12
    a858:	8b458125 	add	x5, x9, x5, lsr #32
    a85c:	8b0d0069 	add	x9, x3, x13
    a860:	eb05017f 	cmp	x11, x5
    a864:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a868:	8b058149 	add	x9, x10, x5, lsl #32
    a86c:	8b458063 	add	x3, x3, x5, lsr #32
    a870:	eb03003f 	cmp	x1, x3
    a874:	54000063 	b.cc	a880 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a878:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a87c:	54000082 	b.cs	a88c <__modti3+0x1cc>  // b.hs, b.nlast
    a880:	eb020129 	subs	x9, x9, x2
    a884:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a888:	cb070063 	sub	x3, x3, x7
    a88c:	eb090000 	subs	x0, x0, x9
    a890:	da030021 	sbc	x1, x1, x3
    a894:	9ac62400 	lsr	x0, x0, x6
    a898:	9ac82028 	lsl	x8, x1, x8
    a89c:	aa000100 	orr	x0, x8, x0
    a8a0:	9ac62421 	lsr	x1, x1, x6
    a8a4:	17ffffb4 	b	a774 <__modti3+0xb4>
    a8a8:	b5000062 	cbnz	x2, a8b4 <__modti3+0x1f4>
    a8ac:	d2800023 	mov	x3, #0x1                   	// #1
    a8b0:	9ac20862 	udiv	x2, x3, x2
    a8b4:	dac01048 	clz	x8, x2
    a8b8:	aa0803e5 	mov	x5, x8
    a8bc:	b5000668 	cbnz	x8, a988 <__modti3+0x2c8>
    a8c0:	cb020020 	sub	x0, x1, x2
    a8c4:	d360fc49 	lsr	x9, x2, #32
    a8c8:	92407c4a 	and	x10, x2, #0xffffffff
    a8cc:	9ac90801 	udiv	x1, x0, x9
    a8d0:	9b098020 	msub	x0, x1, x9, x0
    a8d4:	9b0a7c21 	mul	x1, x1, x10
    a8d8:	93c78000 	extr	x0, x0, x7, #32
    a8dc:	eb00003f 	cmp	x1, x0
    a8e0:	540000a9 	b.ls	a8f4 <__modti3+0x234>  // b.plast
    a8e4:	ab000040 	adds	x0, x2, x0
    a8e8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a8ec:	8b020003 	add	x3, x0, x2
    a8f0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a8f4:	cb010001 	sub	x1, x0, x1
    a8f8:	9ac90820 	udiv	x0, x1, x9
    a8fc:	9b098403 	msub	x3, x0, x9, x1
    a900:	aa0703e1 	mov	x1, x7
    a904:	9b0a7c00 	mul	x0, x0, x10
    a908:	b3607c61 	bfi	x1, x3, #32, #32
    a90c:	eb01001f 	cmp	x0, x1
    a910:	540000a9 	b.ls	a924 <__modti3+0x264>  // b.plast
    a914:	ab010041 	adds	x1, x2, x1
    a918:	8b020022 	add	x2, x1, x2
    a91c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a920:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a924:	cb000020 	sub	x0, x1, x0
    a928:	17ffff91 	b	a76c <__modti3+0xac>
    a92c:	eb0203e5 	negs	x5, x2
    a930:	aa0003e7 	mov	x7, x0
    a934:	da0303e8 	ngc	x8, x3
    a938:	aa0503e2 	mov	x2, x5
    a93c:	aa0803e3 	mov	x3, x8
    a940:	aa0103e6 	mov	x6, x1
    a944:	b4ffed48 	cbz	x8, a6ec <__modti3+0x2c>
    a948:	eb01011f 	cmp	x8, x1
    a94c:	54fff148 	b.hi	a774 <__modti3+0xb4>  // b.pmore
    a950:	dac01109 	clz	x9, x8
    a954:	2a0903e6 	mov	w6, w9
    a958:	b5fff1c9 	cbnz	x9, a790 <__modti3+0xd0>
    a95c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    a960:	54000068 	b.hi	a96c <__modti3+0x2ac>  // b.pmore
    a964:	eb050007 	subs	x7, x0, x5
    a968:	da080021 	sbc	x1, x1, x8
    a96c:	aa0703e0 	mov	x0, x7
    a970:	17ffff81 	b	a774 <__modti3+0xb4>
    a974:	ab000040 	adds	x0, x2, x0
    a978:	8b020002 	add	x2, x0, x2
    a97c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    a980:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    a984:	17ffff79 	b	a768 <__modti3+0xa8>
    a988:	9ac82042 	lsl	x2, x2, x8
    a98c:	d2800803 	mov	x3, #0x40                  	// #64
    a990:	cb080063 	sub	x3, x3, x8
    a994:	d360fc49 	lsr	x9, x2, #32
    a998:	9ac82027 	lsl	x7, x1, x8
    a99c:	92407c4a 	and	x10, x2, #0xffffffff
    a9a0:	9ac32426 	lsr	x6, x1, x3
    a9a4:	9ac32403 	lsr	x3, x0, x3
    a9a8:	aa070063 	orr	x3, x3, x7
    a9ac:	9ac908c1 	udiv	x1, x6, x9
    a9b0:	9ac82007 	lsl	x7, x0, x8
    a9b4:	9b099820 	msub	x0, x1, x9, x6
    a9b8:	9b017d41 	mul	x1, x10, x1
    a9bc:	93c38000 	extr	x0, x0, x3, #32
    a9c0:	eb00003f 	cmp	x1, x0
    a9c4:	540000a9 	b.ls	a9d8 <__modti3+0x318>  // b.plast
    a9c8:	ab000040 	adds	x0, x2, x0
    a9cc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a9d0:	8b020006 	add	x6, x0, x2
    a9d4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    a9d8:	cb010000 	sub	x0, x0, x1
    a9dc:	9ac90801 	udiv	x1, x0, x9
    a9e0:	9b098026 	msub	x6, x1, x9, x0
    a9e4:	aa0303e0 	mov	x0, x3
    a9e8:	9b017d41 	mul	x1, x10, x1
    a9ec:	b3607cc0 	bfi	x0, x6, #32, #32
    a9f0:	eb00003f 	cmp	x1, x0
    a9f4:	540000a9 	b.ls	aa08 <__modti3+0x348>  // b.plast
    a9f8:	ab000040 	adds	x0, x2, x0
    a9fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aa00:	8b020003 	add	x3, x0, x2
    aa04:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    aa08:	cb010000 	sub	x0, x0, x1
    aa0c:	17ffffb0 	b	a8cc <__modti3+0x20c>
    aa10:	d1000969 	sub	x9, x11, #0x2
    aa14:	8b070021 	add	x1, x1, x7
    aa18:	17ffff83 	b	a824 <__modti3+0x164>
    aa1c:	d1000965 	sub	x5, x11, #0x2
    aa20:	8b070063 	add	x3, x3, x7
    aa24:	17ffff74 	b	a7f4 <__modti3+0x134>
    aa28:	d503201f 	nop
    aa2c:	d503201f 	nop

000000000000aa30 <atexit>:
    aa30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aa34:	d00000a2 	adrp	x2, 20000 <__data_start>
    aa38:	d2800001 	mov	x1, #0x0                   	// #0
    aa3c:	910003fd 	mov	x29, sp
    aa40:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aa44:	f9400442 	ldr	x2, [x2, #8]
    aa48:	17ffdf72 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000aa4c <_fini>:
    aa4c:	d503201f 	nop
    aa50:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aa54:	910003fd 	mov	x29, sp
    aa58:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aa5c:	d65f03c0 	ret
