
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/c-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000000710 <_init>:
 710:	d503201f 	nop
 714:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 718:	910003fd 	mov	x29, sp
 71c:	94000096 	bl	974 <call_weak_fn>
 720:	a8c17bfd 	ldp	x29, x30, [sp], #16
 724:	d65f03c0 	ret

Disassembly of section .plt:

0000000000000730 <.plt>:
 730:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 734:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 738:	f947ba11 	ldr	x17, [x16, #3952]
 73c:	913dc210 	add	x16, x16, #0xf70
 740:	d61f0220 	br	x17
 744:	d503201f 	nop
 748:	d503201f 	nop
 74c:	d503201f 	nop

0000000000000750 <__libc_start_main@plt>:
 750:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 754:	f947be11 	ldr	x17, [x16, #3960]
 758:	913de210 	add	x16, x16, #0xf78
 75c:	d61f0220 	br	x17

0000000000000760 <__cxa_finalize@plt>:
 760:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 764:	f947c211 	ldr	x17, [x16, #3968]
 768:	913e0210 	add	x16, x16, #0xf80
 76c:	d61f0220 	br	x17

0000000000000770 <putc@plt>:
 770:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 774:	f947c611 	ldr	x17, [x16, #3976]
 778:	913e2210 	add	x16, x16, #0xf88
 77c:	d61f0220 	br	x17

0000000000000780 <malloc@plt>:
 780:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 784:	f947ca11 	ldr	x17, [x16, #3984]
 788:	913e4210 	add	x16, x16, #0xf90
 78c:	d61f0220 	br	x17

0000000000000790 <__printf_chk@plt>:
 790:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 794:	f947ce11 	ldr	x17, [x16, #3992]
 798:	913e6210 	add	x16, x16, #0xf98
 79c:	d61f0220 	br	x17

00000000000007a0 <__gmon_start__@plt>:
 7a0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 7a4:	f947d211 	ldr	x17, [x16, #4000]
 7a8:	913e8210 	add	x16, x16, #0xfa0
 7ac:	d61f0220 	br	x17

00000000000007b0 <abort@plt>:
 7b0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 7b4:	f947d611 	ldr	x17, [x16, #4008]
 7b8:	913ea210 	add	x16, x16, #0xfa8
 7bc:	d61f0220 	br	x17

00000000000007c0 <puts@plt>:
 7c0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 7c4:	f947da11 	ldr	x17, [x16, #4016]
 7c8:	913ec210 	add	x16, x16, #0xfb0
 7cc:	d61f0220 	br	x17

00000000000007d0 <free@plt>:
 7d0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 7d4:	f947de11 	ldr	x17, [x16, #4024]
 7d8:	913ee210 	add	x16, x16, #0xfb8
 7dc:	d61f0220 	br	x17

00000000000007e0 <ferror@plt>:
 7e0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e46c>
 7e4:	f947e211 	ldr	x17, [x16, #4032]
 7e8:	913f0210 	add	x16, x16, #0xfc0
 7ec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000800 <main>:
 800:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 804:	b200e7e0 	mov	x0, #0x3333333333333333    	// #3689348814741910323
 808:	f2f7fe60 	movk	x0, #0xbff3, lsl #48
 80c:	910003fd 	mov	x29, sp
 810:	a90153f3 	stp	x19, x20, [sp, #16]
 814:	a9025bf5 	stp	x21, x22, [sp, #32]
 818:	d2900016 	mov	x22, #0x8000                	// #32768
 81c:	a90363f7 	stp	x23, x24, [sp, #48]
 820:	90000018 	adrp	x24, 0 <__abi_tag-0x278>
 824:	9129e318 	add	x24, x24, #0xa78
 828:	f00000f7 	adrp	x23, 1f000 <__FRAME_END__+0x1e46c>
 82c:	f947f2f7 	ldr	x23, [x23, #4064]
 830:	fd0023e8 	str	d8, [sp, #64]
 834:	9e670008 	fmov	d8, x0
 838:	14000003 	b	844 <main+0x44>
 83c:	f10006d6 	subs	x22, x22, #0x1
 840:	540004c0 	b.eq	8d8 <main+0xd8>  // b.none
 844:	d2800300 	mov	x0, #0x18                  	// #24
 848:	97ffffce 	bl	780 <malloc@plt>
 84c:	aa0003f4 	mov	x20, x0
 850:	d2800300 	mov	x0, #0x18                  	// #24
 854:	97ffffcb 	bl	780 <malloc@plt>
 858:	aa0003f3 	mov	x19, x0
 85c:	f100029f 	cmp	x20, #0x0
 860:	52800b60 	mov	w0, #0x5b                  	// #91
 864:	fa401a64 	ccmp	x19, #0x0, #0x4, ne	// ne = any
 868:	54000440 	b.eq	8f0 <main+0xf0>  // b.none
 86c:	f94002e1 	ldr	x1, [x23]
 870:	90000015 	adrp	x21, 0 <__abi_tag-0x278>
 874:	912a02b5 	add	x21, x21, #0xa80
 878:	97ffffbe 	bl	770 <putc@plt>
 87c:	1e604100 	fmov	d0, d8
 880:	aa1803e1 	mov	x1, x24
 884:	52800040 	mov	w0, #0x2                   	// #2
 888:	97ffffc2 	bl	790 <__printf_chk@plt>
 88c:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
 890:	aa1503e1 	mov	x1, x21
 894:	52800040 	mov	w0, #0x2                   	// #2
 898:	97ffffbe 	bl	790 <__printf_chk@plt>
 89c:	1e604100 	fmov	d0, d8
 8a0:	aa1503e1 	mov	x1, x21
 8a4:	52800040 	mov	w0, #0x2                   	// #2
 8a8:	97ffffba 	bl	790 <__printf_chk@plt>
 8ac:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 8b0:	912a2000 	add	x0, x0, #0xa88
 8b4:	97ffffc3 	bl	7c0 <puts@plt>
 8b8:	aa1403e0 	mov	x0, x20
 8bc:	97ffffc5 	bl	7d0 <free@plt>
 8c0:	aa1303e0 	mov	x0, x19
 8c4:	97ffffc3 	bl	7d0 <free@plt>
 8c8:	f94002e0 	ldr	x0, [x23]
 8cc:	97ffffc5 	bl	7e0 <ferror@plt>
 8d0:	34fffb60 	cbz	w0, 83c <main+0x3c>
 8d4:	52800080 	mov	w0, #0x4                   	// #4
 8d8:	a94153f3 	ldp	x19, x20, [sp, #16]
 8dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 8e0:	a94363f7 	ldp	x23, x24, [sp, #48]
 8e4:	fd4023e8 	ldr	d8, [sp, #64]
 8e8:	a8c57bfd 	ldp	x29, x30, [sp], #80
 8ec:	d65f03c0 	ret
 8f0:	aa1403e0 	mov	x0, x20
 8f4:	97ffffb7 	bl	7d0 <free@plt>
 8f8:	aa1303e0 	mov	x0, x19
 8fc:	97ffffb5 	bl	7d0 <free@plt>
 900:	52800040 	mov	w0, #0x2                   	// #2
 904:	17fffff5 	b	8d8 <main+0xd8>
 908:	d503201f 	nop
 90c:	d503201f 	nop
 910:	d503201f 	nop
 914:	d503201f 	nop
 918:	d503201f 	nop
 91c:	d503201f 	nop
 920:	d503201f 	nop
 924:	d503201f 	nop
 928:	d503201f 	nop
 92c:	d503201f 	nop
 930:	d503201f 	nop
 934:	d503201f 	nop
 938:	d503201f 	nop
 93c:	d503201f 	nop

0000000000000940 <_start>:
 940:	d503201f 	nop
 944:	d280001d 	mov	x29, #0x0                   	// #0
 948:	d280001e 	mov	x30, #0x0                   	// #0
 94c:	aa0003e5 	mov	x5, x0
 950:	f94003e1 	ldr	x1, [sp]
 954:	910023e2 	add	x2, sp, #0x8
 958:	910003e6 	mov	x6, sp
 95c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e46c>
 960:	f947f800 	ldr	x0, [x0, #4080]
 964:	d2800003 	mov	x3, #0x0                   	// #0
 968:	d2800004 	mov	x4, #0x0                   	// #0
 96c:	97ffff79 	bl	750 <__libc_start_main@plt>
 970:	97ffff90 	bl	7b0 <abort@plt>

0000000000000974 <call_weak_fn>:
 974:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e46c>
 978:	f947f400 	ldr	x0, [x0, #4072]
 97c:	b4000040 	cbz	x0, 984 <call_weak_fn+0x10>
 980:	17ffff88 	b	7a0 <__gmon_start__@plt>
 984:	d65f03c0 	ret
 988:	d503201f 	nop
 98c:	d503201f 	nop

0000000000000990 <deregister_tm_clones>:
 990:	90000100 	adrp	x0, 20000 <__data_start>
 994:	91004000 	add	x0, x0, #0x10
 998:	90000101 	adrp	x1, 20000 <__data_start>
 99c:	91004021 	add	x1, x1, #0x10
 9a0:	eb00003f 	cmp	x1, x0
 9a4:	540000c0 	b.eq	9bc <deregister_tm_clones+0x2c>  // b.none
 9a8:	f00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x1e46c>
 9ac:	f947e821 	ldr	x1, [x1, #4048]
 9b0:	b4000061 	cbz	x1, 9bc <deregister_tm_clones+0x2c>
 9b4:	aa0103f0 	mov	x16, x1
 9b8:	d61f0200 	br	x16
 9bc:	d65f03c0 	ret

00000000000009c0 <register_tm_clones>:
 9c0:	90000100 	adrp	x0, 20000 <__data_start>
 9c4:	91004000 	add	x0, x0, #0x10
 9c8:	90000101 	adrp	x1, 20000 <__data_start>
 9cc:	91004021 	add	x1, x1, #0x10
 9d0:	cb000021 	sub	x1, x1, x0
 9d4:	d37ffc22 	lsr	x2, x1, #63
 9d8:	8b810c41 	add	x1, x2, x1, asr #3
 9dc:	9341fc21 	asr	x1, x1, #1
 9e0:	b40000c1 	cbz	x1, 9f8 <register_tm_clones+0x38>
 9e4:	f00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x1e46c>
 9e8:	f947fc42 	ldr	x2, [x2, #4088]
 9ec:	b4000062 	cbz	x2, 9f8 <register_tm_clones+0x38>
 9f0:	aa0203f0 	mov	x16, x2
 9f4:	d61f0200 	br	x16
 9f8:	d65f03c0 	ret
 9fc:	d503201f 	nop

0000000000000a00 <__do_global_dtors_aux>:
 a00:	d503233f 	paciasp
 a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 a08:	910003fd 	mov	x29, sp
 a0c:	f9000bf3 	str	x19, [sp, #16]
 a10:	90000113 	adrp	x19, 20000 <__data_start>
 a14:	39404260 	ldrb	w0, [x19, #16]
 a18:	37000140 	tbnz	w0, #0, a40 <__do_global_dtors_aux+0x40>
 a1c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e46c>
 a20:	f947ec00 	ldr	x0, [x0, #4056]
 a24:	b4000080 	cbz	x0, a34 <__do_global_dtors_aux+0x34>
 a28:	90000100 	adrp	x0, 20000 <__data_start>
 a2c:	f9400400 	ldr	x0, [x0, #8]
 a30:	97ffff4c 	bl	760 <__cxa_finalize@plt>
 a34:	97ffffd7 	bl	990 <deregister_tm_clones>
 a38:	52800020 	mov	w0, #0x1                   	// #1
 a3c:	39004260 	strb	w0, [x19, #16]
 a40:	f9400bf3 	ldr	x19, [sp, #16]
 a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
 a48:	d50323bf 	autiasp
 a4c:	d65f03c0 	ret

0000000000000a50 <frame_dummy>:
 a50:	d503245f 	bti	c
 a54:	17ffffdb 	b	9c0 <register_tm_clones>

Disassembly of section .fini:

0000000000000a58 <_fini>:
 a58:	d503201f 	nop
 a5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 a60:	910003fd 	mov	x29, sp
 a64:	a8c17bfd 	ldp	x29, x30, [sp], #16
 a68:	d65f03c0 	ret
