
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <_IO_stdin_used+0x30>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	910740a5 	add	x5, x5, #0x1d0
    2aa0:	f0000024 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91076084 	add	x4, x4, #0x1d8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x131d0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    2b34:	9113e000 	add	x0, x0, #0x4f8
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000022 	adrp	x2, 7000 <fwp_write+0x29c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91354042 	add	x2, x2, #0xd50
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430260 	ldr	w0, [x19, #768]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    2c7c:	91142000 	add	x0, x0, #0x508
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    2c8c:	9116a000 	add	x0, x0, #0x5a8
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    2ca4:	91160000 	add	x0, x0, #0x580
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    2cb0:	91154000 	add	x0, x0, #0x550
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    2cbc:	9114a000 	add	x0, x0, #0x528
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91006000 	add	x0, x0, #0x18
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91006021 	add	x1, x1, #0x18
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91006000 	add	x0, x0, #0x18
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91006021 	add	x1, x1, #0x18
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000021 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    2eb4:	912f0021 	add	x1, x1, #0xbc0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x2b0>
    3050:	913f6000 	add	x0, x0, #0xfd8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000021 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    3118:	912e8021 	add	x1, x1, #0xba0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3144:	9114c2a1 	add	x1, x21, #0x530
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    3158:	912480a5 	add	x5, x5, #0x920
    315c:	9114c2a1 	add	x1, x21, #0x530
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	9114c2b7 	add	x23, x21, #0x530
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	9114c2b5 	add	x21, x21, #0x530
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	9114c2b5 	add	x21, x21, #0x530
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    32e8:	912460a5 	add	x5, x5, #0x918
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x2b0>
    33f0:	913f6000 	add	x0, x0, #0xfd8
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x2b0>
    3530:	aa1303e0 	mov	x0, x19
    3534:	913fc021 	add	x1, x1, #0xff0
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x2b0>
    3544:	aa1303e0 	mov	x0, x19
    3548:	913fe021 	add	x1, x1, #0xff8
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000021 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    3560:	91000021 	add	x1, x1, #0x0
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	d0000022 	adrp	x2, 9000 <_IO_stdin_used+0x30>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	91002042 	add	x2, x2, #0x8
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x2b0>
    36d0:	913f6000 	add	x0, x0, #0xfd8
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    36f0:	91006000 	add	x0, x0, #0x18
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    3788:	9100e000 	add	x0, x0, #0x38
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    3798:	91016000 	add	x0, x0, #0x58
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	d0000021 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc2f420 	ldr	q0, [x1, #3024]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    3898:	91020000 	add	x0, x0, #0x80
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    3908:	9102c000 	add	x0, x0, #0xb0
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	d0000024 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	91040084 	add	x4, x4, #0x100
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	d0000024 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	91046084 	add	x4, x4, #0x118
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	d0000024 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	91042084 	add	x4, x4, #0x108
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3d28:	9114c042 	add	x2, x2, #0x530
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	d0000021 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91048021 	add	x1, x1, #0x120
    3d84:	9104a000 	add	x0, x0, #0x128
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	d0000022 	adrp	x2, 9000 <_IO_stdin_used+0x30>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	91052042 	add	x2, x2, #0x148
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xad0>
    3e8c:	9110c061 	add	x1, x3, #0x430
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3e9c:	9114c262 	add	x2, x19, #0x530
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	d0000022 	adrp	x2, 9000 <_IO_stdin_used+0x30>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xad0>
    3ecc:	9111c021 	add	x1, x1, #0x470
    3ed0:	3dc2f843 	ldr	q3, [x2, #3040]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xad0>
    3efc:	9110c063 	add	x3, x3, #0x430
    3f00:	91134084 	add	x4, x4, #0x4d0
    3f04:	9114c266 	add	x6, x19, #0x530
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	9114c275 	add	x21, x19, #0x530
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    3fe8:	9107e000 	add	x0, x0, #0x1f8
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	9114c273 	add	x19, x19, #0x530
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <fwp_wake_io>:
    4044:	900000e9 	adrp	x9, 20000 <__data_start>
    4048:	9100c122 	add	x2, x9, #0x30
    404c:	f9400001 	ldr	x1, [x0]
    4050:	5280000a 	mov	w10, #0x0                   	// #0
    4054:	f9401446 	ldr	x6, [x2, #40]
    4058:	52800008 	mov	w8, #0x0                   	// #0
    405c:	4f000400 	movi	v0.4s, #0x0
    4060:	52800027 	mov	w7, #0x1                   	// #1
    4064:	aa0103e2 	mov	x2, x1
    4068:	b4000321 	cbz	x1, 40cc <fwp_wake_io+0x88>
    406c:	f9408c25 	ldr	x5, [x1, #280]
    4070:	39015c27 	strb	w7, [x1, #87]
    4074:	b4000165 	cbz	x5, 40a0 <fwp_wake_io+0x5c>
    4078:	a9520c24 	ldp	x4, x3, [x1, #288]
    407c:	b4000364 	cbz	x4, 40e8 <fwp_wake_io+0xa4>
    4080:	f9009483 	str	x3, [x4, #296]
    4084:	f9409423 	ldr	x3, [x1, #296]
    4088:	b4000043 	cbz	x3, 4090 <fwp_wake_io+0x4c>
    408c:	f9009064 	str	x4, [x3, #288]
    4090:	91080023 	add	x3, x1, #0x200
    4094:	f900943f 	str	xzr, [x1, #296]
    4098:	3c918060 	stur	q0, [x3, #-232]
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	f9402843 	ldr	x3, [x2, #80]
    40a4:	f2001c7f 	tst	x3, #0xff000000ff
    40a8:	54fffde1 	b.ne	4064 <fwp_wake_io+0x20>  // b.any
    40ac:	39015047 	strb	w7, [x2, #84]
    40b0:	f900805f 	str	xzr, [x2, #256]
    40b4:	b40001e6 	cbz	x6, 40f0 <fwp_wake_io+0xac>
    40b8:	f90080c2 	str	x2, [x6, #256]
    40bc:	aa0203e6 	mov	x6, x2
    40c0:	52800028 	mov	w8, #0x1                   	// #1
    40c4:	aa0103e2 	mov	x2, x1
    40c8:	b5fffd21 	cbnz	x1, 406c <fwp_wake_io+0x28>
    40cc:	3400006a 	cbz	w10, 40d8 <fwp_wake_io+0x94>
    40d0:	9100c120 	add	x0, x9, #0x30
    40d4:	f900180b 	str	x11, [x0, #48]
    40d8:	34000068 	cbz	w8, 40e4 <fwp_wake_io+0xa0>
    40dc:	9100c129 	add	x9, x9, #0x30
    40e0:	f9001526 	str	x6, [x9, #40]
    40e4:	d65f03c0 	ret
    40e8:	f90000a3 	str	x3, [x5]
    40ec:	17ffffe7 	b	4088 <fwp_wake_io+0x44>
    40f0:	aa0203eb 	mov	x11, x2
    40f4:	5280002a 	mov	w10, #0x1                   	// #1
    40f8:	17fffff1 	b	40bc <fwp_wake_io+0x78>
    40fc:	d503201f 	nop

0000000000004100 <fwp_tape_buffers_release>:
    4100:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4104:	910003fd 	mov	x29, sp
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f9401400 	ldr	x0, [x0, #40]
    4114:	b7f80760 	tbnz	x0, #63, 4200 <fwp_tape_buffers_release+0x100>
    4118:	f9401a61 	ldr	x1, [x19, #48]
    411c:	b7f80301 	tbnz	x1, #63, 417c <fwp_tape_buffers_release+0x7c>
    4120:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4124:	eb02001f 	cmp	x0, x2
    4128:	540002a8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    412c:	8b000400 	add	x0, x0, x0, lsl #1
    4130:	d2a00102 	mov	x2, #0x80000               	// #524288
    4134:	d37df000 	lsl	x0, x0, #3
    4138:	cb000042 	sub	x2, x2, x0
    413c:	eb420c3f 	cmp	x1, x2, lsr #3
    4140:	540001e8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4144:	8b010c14 	add	x20, x0, x1, lsl #3
    4148:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    414c:	91082000 	add	x0, x0, #0x208
    4150:	97fffa30 	bl	2a10 <getenv@plt>
    4154:	b4000240 	cbz	x0, 419c <fwp_tape_buffers_release+0x9c>
    4158:	39400001 	ldrb	w1, [x0]
    415c:	7100c03f 	cmp	w1, #0x30
    4160:	540001e1 	b.ne	419c <fwp_tape_buffers_release+0x9c>  // b.any
    4164:	39400400 	ldrb	w0, [x0, #1]
    4168:	350001a0 	cbnz	w0, 419c <fwp_tape_buffers_release+0x9c>
    416c:	aa1303e0 	mov	x0, x19
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4178:	17fffc62 	b	3300 <fwp_tape_buffers_dispose>
    417c:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    4180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4184:	91082000 	add	x0, x0, #0x208
    4188:	97fffa22 	bl	2a10 <getenv@plt>
    418c:	b4ffff00 	cbz	x0, 416c <fwp_tape_buffers_release+0x6c>
    4190:	39400001 	ldrb	w1, [x0]
    4194:	7100c03f 	cmp	w1, #0x30
    4198:	54fffe60 	b.eq	4164 <fwp_tape_buffers_release+0x64>  // b.none
    419c:	d1000681 	sub	x1, x20, #0x1
    41a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	54fffe28 	b.hi	416c <fwp_tape_buffers_release+0x6c>  // b.pmore
    41ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    41b0:	900000f6 	adrp	x22, 20000 <__data_start>
    41b4:	9100c2d6 	add	x22, x22, #0x30
    41b8:	910122d5 	add	x21, x22, #0x48
    41bc:	aa1503e0 	mov	x0, x21
    41c0:	97fffc50 	bl	3300 <fwp_tape_buffers_dispose>
    41c4:	ad400a61 	ldp	q1, q2, [x19]
    41c8:	f90042d4 	str	x20, [x22, #128]
    41cc:	4f000400 	movi	v0.4s, #0x0
    41d0:	ad000aa1 	stp	q1, q2, [x21]
    41d4:	3dc00a61 	ldr	q1, [x19, #32]
    41d8:	3d800aa1 	str	q1, [x21, #32]
    41dc:	f9401a60 	ldr	x0, [x19, #48]
    41e0:	f9001aa0 	str	x0, [x21, #48]
    41e4:	f9001a7f 	str	xzr, [x19, #48]
    41e8:	ad000260 	stp	q0, q0, [x19]
    41ec:	3d800a60 	str	q0, [x19, #32]
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41fc:	d65f03c0 	ret
    4200:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    4204:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4208:	91082000 	add	x0, x0, #0x208
    420c:	97fffa01 	bl	2a10 <getenv@plt>
    4210:	b5fffa40 	cbnz	x0, 4158 <fwp_tape_buffers_release+0x58>
    4214:	17ffffd6 	b	416c <fwp_tape_buffers_release+0x6c>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_poll_events>:
    4220:	d10103ff 	sub	sp, sp, #0x40
    4224:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4228:	f947f400 	ldr	x0, [x0, #4072]
    422c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4230:	910083fd 	add	x29, sp, #0x20
    4234:	a90353f3 	stp	x19, x20, [sp, #48]
    4238:	900000f4 	adrp	x20, 20000 <__data_start>
    423c:	f9400001 	ldr	x1, [x0]
    4240:	f9000fe1 	str	x1, [sp, #24]
    4244:	d2800001 	mov	x1, #0x0                   	// #0
    4248:	97fffd2e 	bl	3700 <fwp_now_ns>
    424c:	9100c281 	add	x1, x20, #0x30
    4250:	f9404433 	ldr	x19, [x1, #136]
    4254:	b4000e93 	cbz	x19, 4424 <fwp_poll_events+0x204>
    4258:	aa1303e1 	mov	x1, x19
    425c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4260:	14000005 	b	4274 <fwp_poll_events+0x54>
    4264:	f9408821 	ldr	x1, [x1, #272]
    4268:	eb03005f 	cmp	x2, x3
    426c:	9a83d042 	csel	x2, x2, x3, le
    4270:	b40000c1 	cbz	x1, 4288 <fwp_poll_events+0x68>
    4274:	f9403423 	ldr	x3, [x1, #104]
    4278:	b6ffff62 	tbz	x2, #63, 4264 <fwp_poll_events+0x44>
    427c:	f9408821 	ldr	x1, [x1, #272]
    4280:	aa0303e2 	mov	x2, x3
    4284:	b5ffff81 	cbnz	x1, 4274 <fwp_poll_events+0x54>
    4288:	b7f80ce2 	tbnz	x2, #63, 4424 <fwp_poll_events+0x204>
    428c:	cb000042 	sub	x2, x2, x0
    4290:	f100005f 	cmp	x2, #0x0
    4294:	540005cd 	b.le	434c <fwp_poll_events+0x12c>
    4298:	d2869b60 	mov	x0, #0x34db                	// #13531
    429c:	d2884801 	mov	x1, #0x4240                	// #16960
    42a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    42b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    42b4:	9b407c40 	smulh	x0, x2, x0
    42b8:	9352fc00 	asr	x0, x0, #18
    42bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    42c0:	9b018802 	msub	x2, x0, x1, x2
    42c4:	f100005f 	cmp	x2, #0x0
    42c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    42cc:	eb03001f 	cmp	x0, x3
    42d0:	54000a0c 	b.gt	4410 <fwp_poll_events+0x1f0>
    42d4:	340003c0 	cbz	w0, 434c <fwp_poll_events+0x12c>
    42d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42e4:	9ba27c02 	umull	x2, w0, w2
    42e8:	d366fc43 	lsr	x3, x2, #38
    42ec:	aa0303e2 	mov	x2, x3
    42f0:	1b048063 	msub	w3, w3, w4, w0
    42f4:	9b217c63 	smull	x3, w3, w1
    42f8:	d2800001 	mov	x1, #0x0                   	// #0
    42fc:	910023e0 	add	x0, sp, #0x8
    4300:	a9008fe2 	stp	x2, x3, [sp, #8]
    4304:	97fff993 	bl	2950 <nanosleep@plt>
    4308:	9100c280 	add	x0, x20, #0x30
    430c:	f9404413 	ldr	x19, [x0, #136]
    4310:	97fffcfc 	bl	3700 <fwp_now_ns>
    4314:	aa0003e6 	mov	x6, x0
    4318:	b50001f3 	cbnz	x19, 4354 <fwp_poll_events+0x134>
    431c:	d503201f 	nop
    4320:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4324:	f947f400 	ldr	x0, [x0, #4072]
    4328:	f9400fe2 	ldr	x2, [sp, #24]
    432c:	f9400001 	ldr	x1, [x0]
    4330:	eb010042 	subs	x2, x2, x1
    4334:	d2800001 	mov	x1, #0x0                   	// #0
    4338:	540008c1 	b.ne	4450 <fwp_poll_events+0x230>  // b.any
    433c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4340:	a94353f3 	ldp	x19, x20, [sp, #48]
    4344:	910103ff 	add	sp, sp, #0x40
    4348:	d65f03c0 	ret
    434c:	97fffced 	bl	3700 <fwp_now_ns>
    4350:	aa0003e6 	mov	x6, x0
    4354:	4f000400 	movi	v0.4s, #0x0
    4358:	9100c288 	add	x8, x20, #0x30
    435c:	52800027 	mov	w7, #0x1                   	// #1
    4360:	f9403661 	ldr	x1, [x19, #104]
    4364:	aa1303e5 	mov	x5, x19
    4368:	f9408a73 	ldr	x19, [x19, #272]
    436c:	eb06003f 	cmp	x1, x6
    4370:	5400032c 	b.gt	43d4 <fwp_poll_events+0x1b4>
    4374:	394154a0 	ldrb	w0, [x5, #85]
    4378:	36000120 	tbz	w0, #0, 439c <fwp_poll_events+0x17c>
    437c:	f94084a0 	ldr	x0, [x5, #264]
    4380:	b40003c0 	cbz	x0, 43f8 <fwp_poll_events+0x1d8>
    4384:	f9008813 	str	x19, [x0, #272]
    4388:	b4000053 	cbz	x19, 4390 <fwp_poll_events+0x170>
    438c:	f9008660 	str	x0, [x19, #264]
    4390:	910800a0 	add	x0, x5, #0x200
    4394:	390154bf 	strb	wzr, [x5, #85]
    4398:	3c908000 	stur	q0, [x0, #-248]
    439c:	f94030a0 	ldr	x0, [x5, #96]
    43a0:	390158a7 	strb	w7, [x5, #86]
    43a4:	f100001f 	cmp	x0, #0x0
    43a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43ac:	5400018d 	b.le	43dc <fwp_poll_events+0x1bc>
    43b0:	f94028a0 	ldr	x0, [x5, #80]
    43b4:	f2001c1f 	tst	x0, #0xff000000ff
    43b8:	540000e1 	b.ne	43d4 <fwp_poll_events+0x1b4>  // b.any
    43bc:	f9401500 	ldr	x0, [x8, #40]
    43c0:	390150a7 	strb	w7, [x5, #84]
    43c4:	f90080bf 	str	xzr, [x5, #256]
    43c8:	b40001e0 	cbz	x0, 4404 <fwp_poll_events+0x1e4>
    43cc:	f9001505 	str	x5, [x8, #40]
    43d0:	f9008005 	str	x5, [x0, #256]
    43d4:	b5fffc73 	cbnz	x19, 4360 <fwp_poll_events+0x140>
    43d8:	17ffffd2 	b	4320 <fwp_poll_events+0x100>
    43dc:	394144a0 	ldrb	w0, [x5, #81]
    43e0:	3707fe80 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43e4:	394140a0 	ldrb	w0, [x5, #80]
    43e8:	3707fe40 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43ec:	aa0503e0 	mov	x0, x5
    43f0:	97fffc20 	bl	3470 <fwp_cancel_tree.part.0>
    43f4:	17ffffef 	b	43b0 <fwp_poll_events+0x190>
    43f8:	9100c281 	add	x1, x20, #0x30
    43fc:	f9004433 	str	x19, [x1, #136]
    4400:	17ffffe2 	b	4388 <fwp_poll_events+0x168>
    4404:	f9001505 	str	x5, [x8, #40]
    4408:	f9001905 	str	x5, [x8, #48]
    440c:	17fffff2 	b	43d4 <fwp_poll_events+0x1b4>
    4410:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4414:	d2989362 	mov	x2, #0xc49b                	// #50331
    4418:	f2a4d203 	movk	x3, #0x2690, lsl #16
    441c:	f2a00402 	movk	x2, #0x20, lsl #16
    4420:	17ffffb6 	b	42f8 <fwp_poll_events+0xd8>
    4424:	97fffaf3 	bl	2ff0 <fwp_flush>
    4428:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    442c:	f947e863 	ldr	x3, [x3, #4048]
    4430:	d2800562 	mov	x2, #0x2b                  	// #43
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    443c:	91088000 	add	x0, x0, #0x220
    4440:	f9400063 	ldr	x3, [x3]
    4444:	97fff94f 	bl	2980 <fwrite@plt>
    4448:	52800ca0 	mov	w0, #0x65                  	// #101
    444c:	97fff8b9 	bl	2730 <exit@plt>
    4450:	97fff90c 	bl	2880 <__stack_chk_fail@plt>

0000000000004454 <fwp_rc_wide_dup>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	ca404400 	eor	x0, x0, x0, lsr #17
    4468:	f90013f5 	str	x21, [sp, #32]
    446c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4470:	ca402400 	eor	x0, x0, x0, lsr #9
    4474:	9114c2a2 	add	x2, x21, #0x530
    4478:	92401c00 	and	x0, x0, #0xff
    447c:	910a2403 	add	x3, x0, #0x289
    4480:	8b000c40 	add	x0, x2, x0, lsl #3
    4484:	8b030c54 	add	x20, x2, x3, lsl #3
    4488:	f94a2401 	ldr	x1, [x0, #5192]
    448c:	b50000a1 	cbnz	x1, 44a0 <fwp_rc_wide_dup+0x4c>
    4490:	1400002d 	b	4544 <fwp_rc_wide_dup+0xf0>
    4494:	91004034 	add	x20, x1, #0x10
    4498:	f9400821 	ldr	x1, [x1, #16]
    449c:	b4000241 	cbz	x1, 44e4 <fwp_rc_wide_dup+0x90>
    44a0:	f9400022 	ldr	x2, [x1]
    44a4:	eb02027f 	cmp	x19, x2
    44a8:	54ffff61 	b.ne	4494 <fwp_rc_wide_dup+0x40>  // b.any
    44ac:	f9400281 	ldr	x1, [x20]
    44b0:	39400260 	ldrb	w0, [x19]
    44b4:	7103f81f 	cmp	w0, #0xfe
    44b8:	54000220 	b.eq	44fc <fwp_rc_wide_dup+0xa8>  // b.none
    44bc:	b40001a1 	cbz	x1, 44f0 <fwp_rc_wide_dup+0x9c>
    44c0:	f9400420 	ldr	x0, [x1, #8]
    44c4:	b100041f 	cmn	x0, #0x1
    44c8:	540004a0 	b.eq	455c <fwp_rc_wide_dup+0x108>  // b.none
    44cc:	91000400 	add	x0, x0, #0x1
    44d0:	f9000420 	str	x0, [x1, #8]
    44d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44d8:	f94013f5 	ldr	x21, [sp, #32]
    44dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44e0:	d65f03c0 	ret
    44e4:	39400260 	ldrb	w0, [x19]
    44e8:	7103f81f 	cmp	w0, #0xfe
    44ec:	540000a0 	b.eq	4500 <fwp_rc_wide_dup+0xac>  // b.none
    44f0:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    44f4:	9109e000 	add	x0, x0, #0x278
    44f8:	97fffc22 	bl	3580 <fwp_trap>
    44fc:	b5000281 	cbnz	x1, 454c <fwp_rc_wide_dup+0xf8>
    4500:	d2800300 	mov	x0, #0x18                  	// #24
    4504:	97fff8c7 	bl	2820 <malloc@plt>
    4508:	b4000280 	cbz	x0, 4558 <fwp_rc_wide_dup+0x104>
    450c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4510:	a9000413 	stp	x19, x1, [x0]
    4514:	9114c2b5 	add	x21, x21, #0x530
    4518:	f900081f 	str	xzr, [x0, #16]
    451c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4520:	f9000280 	str	x0, [x20]
    4524:	39000261 	strb	w1, [x19]
    4528:	f94e26a0 	ldr	x0, [x21, #7240]
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	91000400 	add	x0, x0, #0x1
    4534:	f90e26a0 	str	x0, [x21, #7240]
    4538:	f94013f5 	ldr	x21, [sp, #32]
    453c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4540:	d65f03c0 	ret
    4544:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4548:	17ffffda 	b	44b0 <fwp_rc_wide_dup+0x5c>
    454c:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    4550:	91094000 	add	x0, x0, #0x250
    4554:	97fffc0b 	bl	3580 <fwp_trap>
    4558:	97fffab6 	bl	3030 <fwp_heap_oom>
    455c:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    4560:	910a8000 	add	x0, x0, #0x2a0
    4564:	97fffc07 	bl	3580 <fwp_trap>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_rc_forget_slot>:
    4570:	aa0003e1 	mov	x1, x0
    4574:	39400000 	ldrb	w0, [x0]
    4578:	7103fc1f 	cmp	w0, #0xff
    457c:	54000040 	b.eq	4584 <fwp_rc_forget_slot+0x14>  // b.none
    4580:	d65f03c0 	ret
    4584:	ca414420 	eor	x0, x1, x1, lsr #17
    4588:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    458c:	ca402400 	eor	x0, x0, x0, lsr #9
    4590:	910003fd 	mov	x29, sp
    4594:	92401c00 	and	x0, x0, #0xff
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    45a0:	9114c262 	add	x2, x19, #0x530
    45a4:	910a2403 	add	x3, x0, #0x289
    45a8:	8b000c40 	add	x0, x2, x0, lsl #3
    45ac:	8b030c43 	add	x3, x2, x3, lsl #3
    45b0:	f94a2400 	ldr	x0, [x0, #5192]
    45b4:	b50000a0 	cbnz	x0, 45c8 <fwp_rc_forget_slot+0x58>
    45b8:	14000011 	b	45fc <fwp_rc_forget_slot+0x8c>
    45bc:	91004003 	add	x3, x0, #0x10
    45c0:	f9400800 	ldr	x0, [x0, #16]
    45c4:	b40001c0 	cbz	x0, 45fc <fwp_rc_forget_slot+0x8c>
    45c8:	f9400002 	ldr	x2, [x0]
    45cc:	eb02003f 	cmp	x1, x2
    45d0:	54ffff61 	b.ne	45bc <fwp_rc_forget_slot+0x4c>  // b.any
    45d4:	f9400801 	ldr	x1, [x0, #16]
    45d8:	9114c273 	add	x19, x19, #0x530
    45dc:	f9000061 	str	x1, [x3]
    45e0:	97fff8d8 	bl	2940 <free@plt>
    45e4:	f94e2660 	ldr	x0, [x19, #7240]
    45e8:	d1000400 	sub	x0, x0, #0x1
    45ec:	f90e2660 	str	x0, [x19, #7240]
    45f0:	f9400bf3 	ldr	x19, [sp, #16]
    45f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45f8:	d65f03c0 	ret
    45fc:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    4600:	9109e000 	add	x0, x0, #0x278
    4604:	97fffbdf 	bl	3580 <fwp_trap>
    4608:	d503201f 	nop
    460c:	d503201f 	nop

0000000000004610 <fwp_rc_prepare_chunk>:
    4610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4614:	910003fd 	mov	x29, sp
    4618:	a9025bf5 	stp	x21, x22, [sp, #32]
    461c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    4620:	9114c2c2 	add	x2, x22, #0x530
    4624:	b9401c03 	ldr	w3, [x0, #28]
    4628:	aa0103f5 	mov	x21, x1
    462c:	a90153f3 	stp	x19, x20, [sp, #16]
    4630:	aa0003f4 	mov	x20, x0
    4634:	f94e2440 	ldr	x0, [x2, #7240]
    4638:	b4000440 	cbz	x0, 46c0 <fwp_rc_prepare_chunk+0xb0>
    463c:	d2800013 	mov	x19, #0x0                   	// #0
    4640:	35000203 	cbnz	w3, 4680 <fwp_rc_prepare_chunk+0x70>
    4644:	b4000361 	cbz	x1, 46b0 <fwp_rc_prepare_chunk+0xa0>
    4648:	f9401280 	ldr	x0, [x20, #32]
    464c:	97fff8bd 	bl	2940 <free@plt>
    4650:	aa1503e0 	mov	x0, x21
    4654:	d2800021 	mov	x1, #0x1                   	// #1
    4658:	97fff882 	bl	2860 <calloc@plt>
    465c:	f9001280 	str	x0, [x20, #32]
    4660:	b5000460 	cbnz	x0, 46ec <fwp_rc_prepare_chunk+0xdc>
    4664:	97fffa73 	bl	3030 <fwp_heap_oom>
    4668:	97ffffc2 	bl	4570 <fwp_rc_forget_slot>
    466c:	91000673 	add	x19, x19, #0x1
    4670:	b9401e83 	ldr	w3, [x20, #28]
    4674:	eb13007f 	cmp	x3, x19
    4678:	54000169 	b.ls	46a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    467c:	d503201f 	nop
    4680:	f9401283 	ldr	x3, [x20, #32]
    4684:	8b130060 	add	x0, x3, x19
    4688:	38736863 	ldrb	w3, [x3, x19]
    468c:	7103fc7f 	cmp	w3, #0xff
    4690:	54fffec0 	b.eq	4668 <fwp_rc_prepare_chunk+0x58>  // b.none
    4694:	b9401e83 	ldr	w3, [x20, #28]
    4698:	91000673 	add	x19, x19, #0x1
    469c:	eb13007f 	cmp	x3, x19
    46a0:	54ffff08 	b.hi	4680 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46a4:	eb0302bf 	cmp	x21, x3
    46a8:	54000121 	b.ne	46cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    46ac:	b5000335 	cbnz	x21, 4710 <fwp_rc_prepare_chunk+0x100>
    46b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46bc:	d65f03c0 	ret
    46c0:	2a0303e3 	mov	w3, w3
    46c4:	eb0302bf 	cmp	x21, x3
    46c8:	54ffff20 	b.eq	46ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    46cc:	9114c2c2 	add	x2, x22, #0x530
    46d0:	f9401280 	ldr	x0, [x20, #32]
    46d4:	f94e2841 	ldr	x1, [x2, #7248]
    46d8:	cb030021 	sub	x1, x1, x3
    46dc:	f90e2841 	str	x1, [x2, #7248]
    46e0:	97fff898 	bl	2940 <free@plt>
    46e4:	b5fffb75 	cbnz	x21, 4650 <fwp_rc_prepare_chunk+0x40>
    46e8:	f900129f 	str	xzr, [x20, #32]
    46ec:	9114c2d6 	add	x22, x22, #0x530
    46f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46f4:	b9001e95 	str	w21, [x20, #28]
    46f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46fc:	8b150000 	add	x0, x0, x21
    4700:	f90e2ac0 	str	x0, [x22, #7248]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	f9401280 	ldr	x0, [x20, #32]
    4714:	aa1503e2 	mov	x2, x21
    4718:	a94153f3 	ldp	x19, x20, [sp, #16]
    471c:	52800001 	mov	w1, #0x0                   	// #0
    4720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4728:	17fff84a 	b	2850 <memset@plt>
    472c:	d503201f 	nop

0000000000004730 <fwp_heap_refill>:
    4730:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4734:	910003fd 	mov	x29, sp
    4738:	a9025bf5 	stp	x21, x22, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4740:	9114c2b5 	add	x21, x21, #0x530
    4744:	aa0003f6 	mov	x22, x0
    4748:	d2800020 	mov	x0, #0x1                   	// #1
    474c:	a90153f3 	stp	x19, x20, [sp, #16]
    4750:	a90363f7 	stp	x23, x24, [sp, #48]
    4754:	2a0103f7 	mov	w23, w1
    4758:	2a0203f8 	mov	w24, w2
    475c:	97fffa75 	bl	3130 <fwp_heap_chunks>
    4760:	aa0003f3 	mov	x19, x0
    4764:	f949fea2 	ldr	x2, [x21, #5112]
    4768:	8b000800 	add	x0, x0, x0, lsl #2
    476c:	2a1703e1 	mov	w1, w23
    4770:	52800025 	mov	w5, #0x1                   	// #1
    4774:	d37df000 	lsl	x0, x0, #3
    4778:	910f0021 	add	x1, x1, #0x3c0
    477c:	8b000054 	add	x20, x2, x0
    4780:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4784:	52a00024 	mov	w4, #0x10000               	// #65536
    4788:	38206845 	strb	w5, [x2, x0]
    478c:	aa1403e0 	mov	x0, x20
    4790:	39000698 	strb	w24, [x20, #1]
    4794:	39000a97 	strb	w23, [x20, #2]
    4798:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    479c:	b9000681 	str	w1, [x20, #4]
    47a0:	2a0103e5 	mov	w5, w1
    47a4:	8b0300a2 	add	x2, x5, x3
    47a8:	1ac10881 	udiv	w1, w4, w1
    47ac:	9ac50842 	udiv	x2, x2, x5
    47b0:	b9000a81 	str	w1, [x20, #8]
    47b4:	92404021 	and	x1, x1, #0x1ffff
    47b8:	b9001a82 	str	w2, [x20, #24]
    47bc:	97ffff95 	bl	4610 <fwp_rc_prepare_chunk>
    47c0:	f949daa0 	ldr	x0, [x21, #5040]
    47c4:	29408a81 	ldp	w1, w2, [x20, #4]
    47c8:	8b134000 	add	x0, x0, x19, lsl #16
    47cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d0:	8b214003 	add	x3, x0, w1, uxtw
    47d4:	9ba20021 	umaddl	x1, w1, w2, x0
    47d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47dc:	a90086c3 	stp	x3, x1, [x22, #8]
    47e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47e8:	d65f03c0 	ret
    47ec:	d503201f 	nop

00000000000047f0 <fwp_mem_free>:
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_mem_free+0x78>
    47f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47f8:	910003fd 	mov	x29, sp
    47fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4800:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4804:	9114c2a1 	add	x1, x21, #0x530
    4808:	a90153f3 	stp	x19, x20, [sp, #16]
    480c:	aa0003f3 	mov	x19, x0
    4810:	f949d823 	ldr	x3, [x1, #5040]
    4814:	f949ec22 	ldr	x2, [x1, #5080]
    4818:	cb030000 	sub	x0, x0, x3
    481c:	eb02401f 	cmp	x0, x2, lsl #16
    4820:	540001c2 	b.cs	4858 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4824:	d350fc16 	lsr	x22, x0, #16
    4828:	a90363f7 	stp	x23, x24, [sp, #48]
    482c:	f949fc22 	ldr	x2, [x1, #5112]
    4830:	8b160ad4 	add	x20, x22, x22, lsl #2
    4834:	d37df294 	lsl	x20, x20, #3
    4838:	ab140057 	adds	x23, x2, x20
    483c:	540000c0 	b.eq	4854 <fwp_mem_free+0x64>  // b.none
    4840:	38746842 	ldrb	w2, [x2, x20]
    4844:	7100045f 	cmp	w2, #0x1
    4848:	54000120 	b.eq	486c <fwp_mem_free+0x7c>  // b.none
    484c:	7100085f 	cmp	w2, #0x2
    4850:	540005e0 	b.eq	490c <fwp_mem_free+0x11c>  // b.none
    4854:	a94363f7 	ldp	x23, x24, [sp, #48]
    4858:	a94153f3 	ldp	x19, x20, [sp, #16]
    485c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4860:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4864:	d65f03c0 	ret
    4868:	d65f03c0 	ret
    486c:	f94012f8 	ldr	x24, [x23, #32]
    4870:	b94006e1 	ldr	w1, [x23, #4]
    4874:	f90023f9 	str	x25, [sp, #64]
    4878:	2a0103e2 	mov	w2, w1
    487c:	394006f9 	ldrb	w25, [x23, #1]
    4880:	39400af4 	ldrb	w20, [x23, #2]
    4884:	b4000158 	cbz	x24, 48ac <fwp_mem_free+0xbc>
    4888:	92403e76 	and	x22, x19, #0xffff
    488c:	9ac20ad6 	udiv	x22, x22, x2
    4890:	38766b01 	ldrb	w1, [x24, x22]
    4894:	8b160300 	add	x0, x24, x22
    4898:	7103fc3f 	cmp	w1, #0xff
    489c:	54000980 	b.eq	49cc <fwp_mem_free+0x1dc>  // b.none
    48a0:	38366b1f 	strb	wzr, [x24, x22]
    48a4:	b94006e1 	ldr	w1, [x23, #4]
    48a8:	2a0103e2 	mov	w2, w1
    48ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    48b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    48b4:	cb390000 	sub	x0, x0, w25, uxtb
    48b8:	8b340074 	add	x20, x3, w20, uxtb
    48bc:	9114c2b5 	add	x21, x21, #0x530
    48c0:	1e630021 	ucvtf	d1, w1
    48c4:	d37ae400 	lsl	x0, x0, #6
    48c8:	8b140c14 	add	x20, x0, x20, lsl #3
    48cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    48d0:	f8746aa0 	ldr	x0, [x21, x20]
    48d4:	f94023f9 	ldr	x25, [sp, #64]
    48d8:	aa2003e0 	mvn	x0, x0
    48dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    48e0:	f9000260 	str	x0, [x19]
    48e4:	f8346ab3 	str	x19, [x21, x20]
    48e8:	f94a12a0 	ldr	x0, [x21, #5152]
    48ec:	1e612800 	fadd	d0, d0, d1
    48f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f4:	cb020000 	sub	x0, x0, x2
    48f8:	f90a12a0 	str	x0, [x21, #5152]
    48fc:	fd0a22a0 	str	d0, [x21, #5184]
    4900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4904:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4908:	d65f03c0 	ret
    490c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4910:	8b000063 	add	x3, x3, x0
    4914:	eb03027f 	cmp	x19, x3
    4918:	54fff9e1 	b.ne	4854 <fwp_mem_free+0x64>  // b.any
    491c:	fd400ae1 	ldr	d1, [x23, #16]
    4920:	fd4a2020 	ldr	d0, [x1, #5184]
    4924:	f9400ae0 	ldr	x0, [x23, #16]
    4928:	7e61d821 	ucvtf	d1, d1
    492c:	f94a1022 	ldr	x2, [x1, #5152]
    4930:	f94012f3 	ldr	x19, [x23, #32]
    4934:	1e612800 	fadd	d0, d0, d1
    4938:	cb000042 	sub	x2, x2, x0
    493c:	f90a1022 	str	x2, [x1, #5152]
    4940:	fd0a2020 	str	d0, [x1, #5184]
    4944:	b40000b3 	cbz	x19, 4958 <fwp_mem_free+0x168>
    4948:	39400260 	ldrb	w0, [x19]
    494c:	7103fc1f 	cmp	w0, #0xff
    4950:	54000380 	b.eq	49c0 <fwp_mem_free+0x1d0>  // b.none
    4954:	3900027f 	strb	wzr, [x19]
    4958:	b9400ee2 	ldr	w2, [x23, #12]
    495c:	b4000142 	cbz	x2, 4984 <fwp_mem_free+0x194>
    4960:	9114c2a1 	add	x1, x21, #0x530
    4964:	8b160040 	add	x0, x2, x22
    4968:	8b000800 	add	x0, x0, x0, lsl #2
    496c:	f949fc21 	ldr	x1, [x1, #5112]
    4970:	8b140034 	add	x20, x1, x20
    4974:	8b000c20 	add	x0, x1, x0, lsl #3
    4978:	3802869f 	strb	wzr, [x20], #40
    497c:	eb00029f 	cmp	x20, x0
    4980:	54ffffc1 	b.ne	4978 <fwp_mem_free+0x188>  // b.any
    4984:	9114c2a0 	add	x0, x21, #0x530
    4988:	f94a1801 	ldr	x1, [x0, #5168]
    498c:	f949f803 	ldr	x3, [x0, #5104]
    4990:	8b020021 	add	x1, x1, x2
    4994:	f90a1801 	str	x1, [x0, #5168]
    4998:	eb16007f 	cmp	x3, x22
    499c:	54000049 	b.ls	49a4 <fwp_mem_free+0x1b4>  // b.plast
    49a0:	f909f816 	str	x22, [x0, #5104]
    49a4:	9114c2b5 	add	x21, x21, #0x530
    49a8:	f949f6a0 	ldr	x0, [x21, #5096]
    49ac:	eb16001f 	cmp	x0, x22
    49b0:	54fff529 	b.ls	4854 <fwp_mem_free+0x64>  // b.plast
    49b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    49b8:	f909f6b6 	str	x22, [x21, #5096]
    49bc:	17ffffa7 	b	4858 <fwp_mem_free+0x68>
    49c0:	aa1303e0 	mov	x0, x19
    49c4:	97fffeeb 	bl	4570 <fwp_rc_forget_slot>
    49c8:	17ffffe3 	b	4954 <fwp_mem_free+0x164>
    49cc:	97fffee9 	bl	4570 <fwp_rc_forget_slot>
    49d0:	17ffffb4 	b	48a0 <fwp_mem_free+0xb0>

00000000000049d4 <fwp_heap_alloc_big>:
    49d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d8:	910003fd 	mov	x29, sp
    49dc:	a90153f3 	stp	x19, x20, [sp, #16]
    49e0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e4:	a90363f7 	stp	x23, x24, [sp, #48]
    49e8:	aa0003f7 	mov	x23, x0
    49ec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f4:	eb0002ff 	cmp	x23, x0
    49f8:	54000888 	b.hi	4b08 <fwp_heap_alloc_big+0x134>  // b.pmore
    49fc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a00:	8b0002f4 	add	x20, x23, x0
    4a04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    4a08:	9114c359 	add	x25, x26, #0x530
    4a0c:	d350fe94 	lsr	x20, x20, #16
    4a10:	2a0103f5 	mov	w21, w1
    4a14:	aa1403e0 	mov	x0, x20
    4a18:	97fff9c6 	bl	3130 <fwp_heap_chunks>
    4a1c:	f949ff22 	ldr	x2, [x25, #5112]
    4a20:	8b000813 	add	x19, x0, x0, lsl #2
    4a24:	aa0003f8 	mov	x24, x0
    4a28:	52800043 	mov	w3, #0x2                   	// #2
    4a2c:	d37df273 	lsl	x19, x19, #3
    4a30:	d2800021 	mov	x1, #0x1                   	// #1
    4a34:	8b130040 	add	x0, x2, x19
    4a38:	38336843 	strb	w3, [x2, x19]
    4a3c:	39000415 	strb	w21, [x0, #1]
    4a40:	b9000c14 	str	w20, [x0, #12]
    4a44:	f9000817 	str	x23, [x0, #16]
    4a48:	97fffef2 	bl	4610 <fwp_rc_prepare_chunk>
    4a4c:	f100069f 	cmp	x20, #0x1
    4a50:	54000269 	b.ls	4a9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a54:	8b180294 	add	x20, x20, x24
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a60:	5280007b 	mov	w27, #0x3                   	// #3
    4a64:	8b140a94 	add	x20, x20, x20, lsl #2
    4a68:	2a1803fc 	mov	w28, w24
    4a6c:	9adb2296 	lsl	x22, x20, x27
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffee4 	bl	4610 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0x9c>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	9114c353 	add	x19, x26, #0x530
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9114c35a 	add	x26, x26, #0x530
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    4b20:	9114c262 	add	x2, x19, #0x530
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	9114c262 	add	x2, x19, #0x530
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	9114c260 	add	x0, x19, #0x530
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	9114c273 	add	x19, x19, #0x530
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffca4 	bl	3e84 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff70 	b	49d4 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	9114c260 	add	x0, x19, #0x530
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffeb5 	bl	4730 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4c84:	9114c293 	add	x19, x20, #0x530
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	9114c294 	add	x20, x20, #0x530
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4d94:	9114c283 	add	x3, x20, #0x530
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	9114c282 	add	x2, x20, #0x530
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	9114c294 	add	x20, x20, #0x530
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_p_ad_push.constprop.0>:
    4ea4:	f100001f 	cmp	x0, #0x0
    4ea8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4eac:	54000e8b 	b.lt	507c <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    4eb0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4eb4:	aa0003e4 	mov	x4, x0
    4eb8:	910003fd 	mov	x29, sp
    4ebc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec0:	aa0003f5 	mov	x21, x0
    4ec4:	aa020000 	orr	x0, x0, x2
    4ec8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ecc:	aa0203f7 	mov	x23, x2
    4ed0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4ed4:	9e670029 	fmov	d9, x1
    4ed8:	9e670068 	fmov	d8, x3
    4edc:	b6f80900 	tbz	x0, #63, 4ffc <fwp_p_ad_push.constprop.0+0x158>
    4ee0:	a90153f3 	stp	x19, x20, [sp, #16]
    4ee4:	9360fc80 	asr	x0, x4, #32
    4ee8:	b6f800c4 	tbz	x4, #63, 4f00 <fwp_p_ad_push.constprop.0+0x5c>
    4eec:	1e604109 	fmov	d9, d8
    4ef0:	2f00e408 	movi	d8, #0x0
    4ef4:	9360fc40 	asr	x0, x2, #32
    4ef8:	aa0203f5 	mov	x21, x2
    4efc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f00:	97fffa6c 	bl	38b0 <fwp_tape_of>
    4f04:	aa0003f3 	mov	x19, x0
    4f08:	f9403000 	ldr	x0, [x0, #96]
    4f0c:	b5001280 	cbnz	x0, 515c <fwp_p_ad_push.constprop.0+0x2b8>
    4f10:	f9400a76 	ldr	x22, [x19, #16]
    4f14:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f18:	eb0002df 	cmp	x22, x0
    4f1c:	54000e2c 	b.gt	50e0 <fwp_p_ad_push.constprop.0+0x23c>
    4f20:	eb3542df 	cmp	x22, w21, uxtw
    4f24:	54000d4d 	b.le	50cc <fwp_p_ad_push.constprop.0+0x228>
    4f28:	b7f80077 	tbnz	x23, #63, 4f34 <fwp_p_ad_push.constprop.0+0x90>
    4f2c:	eb3742df 	cmp	x22, w23, uxtw
    4f30:	54000ced 	b.le	50cc <fwp_p_ad_push.constprop.0+0x228>
    4f34:	f9400678 	ldr	x24, [x19, #8]
    4f38:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f3c:	cb1802d8 	sub	x24, x22, x24
    4f40:	91000701 	add	x1, x24, #0x1
    4f44:	eb00003f 	cmp	x1, x0
    4f48:	54000cc8 	b.hi	50e0 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    4f4c:	a9418274 	ldp	x20, x0, [x19, #24]
    4f50:	a90573fb 	stp	x27, x28, [sp, #80]
    4f54:	eb14003f 	cmp	x1, x20
    4f58:	5400068d 	b.le	5028 <fwp_p_ad_push.constprop.0+0x184>
    4f5c:	f100029f 	cmp	x20, #0x0
    4f60:	d2800803 	mov	x3, #0x40                  	// #64
    4f64:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4f68:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f70:	eb14003f 	cmp	x1, x20
    4f74:	5400008d 	b.le	4f84 <fwp_p_ad_push.constprop.0+0xe0>
    4f78:	eb02029f 	cmp	x20, x2
    4f7c:	5400052d 	b.le	5020 <fwp_p_ad_push.constprop.0+0x17c>
    4f80:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4f84:	d37df299 	lsl	x25, x20, #3
    4f88:	aa1903e1 	mov	x1, x25
    4f8c:	97fff639 	bl	2870 <realloc@plt>
    4f90:	aa0003e1 	mov	x1, x0
    4f94:	b4000b00 	cbz	x0, 50f4 <fwp_p_ad_push.constprop.0+0x250>
    4f98:	f9400e62 	ldr	x2, [x19, #24]
    4f9c:	f9001261 	str	x1, [x19, #32]
    4fa0:	f9401a60 	ldr	x0, [x19, #48]
    4fa4:	d37cee9a 	lsl	x26, x20, #4
    4fa8:	8b020821 	add	x1, x1, x2, lsl #2
    4fac:	f9001661 	str	x1, [x19, #40]
    4fb0:	aa1a03e1 	mov	x1, x26
    4fb4:	97fff62f 	bl	2870 <realloc@plt>
    4fb8:	aa0003e2 	mov	x2, x0
    4fbc:	b40009c0 	cbz	x0, 50f4 <fwp_p_ad_push.constprop.0+0x250>
    4fc0:	f9400e61 	ldr	x1, [x19, #24]
    4fc4:	d37df31b 	lsl	x27, x24, #3
    4fc8:	d37ef685 	lsl	x5, x20, #2
    4fcc:	d37ef71c 	lsl	x28, x24, #2
    4fd0:	8b190004 	add	x4, x0, x25
    4fd4:	8b010c01 	add	x1, x0, x1, lsl #3
    4fd8:	a9030660 	stp	x0, x1, [x19, #48]
    4fdc:	b5000558 	cbnz	x24, 5084 <fwp_p_ad_push.constprop.0+0x1e0>
    4fe0:	f9001e64 	str	x4, [x19, #56]
    4fe4:	f9401260 	ldr	x0, [x19, #32]
    4fe8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fec:	8b050001 	add	x1, x0, x5
    4ff0:	f9000e74 	str	x20, [x19, #24]
    4ff4:	f9001661 	str	x1, [x19, #40]
    4ff8:	14000010 	b	5038 <fwp_p_ad_push.constprop.0+0x194>
    4ffc:	9360fc40 	asr	x0, x2, #32
    5000:	a90153f3 	stp	x19, x20, [sp, #16]
    5004:	eb84801f 	cmp	x0, x4, asr #32
    5008:	54fff7c0 	b.eq	4f00 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    500c:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    5010:	910b0000 	add	x0, x0, #0x2c0
    5014:	a9046bf9 	stp	x25, x26, [sp, #64]
    5018:	a90573fb 	stp	x27, x28, [sp, #80]
    501c:	97fff959 	bl	3580 <fwp_trap>
    5020:	d37ffa94 	lsl	x20, x20, #1
    5024:	17ffffd3 	b	4f70 <fwp_p_ad_push.constprop.0+0xcc>
    5028:	a9428a61 	ldp	x1, x2, [x19, #40]
    502c:	d37ef71c 	lsl	x28, x24, #2
    5030:	f9401e64 	ldr	x4, [x19, #56]
    5034:	d37df31b 	lsl	x27, x24, #3
    5038:	b83c6815 	str	w21, [x0, x28]
    503c:	f10002ff 	cmp	x23, #0x0
    5040:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5044:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5048:	fc3b6849 	str	d9, [x2, x27]
    504c:	aa1602a0 	orr	x0, x21, x22
    5050:	b83c6837 	str	w23, [x1, x28]
    5054:	910006d6 	add	x22, x22, #0x1
    5058:	a94363f7 	ldp	x23, x24, [sp, #48]
    505c:	fc3b6888 	str	d8, [x4, x27]
    5060:	a94573fb 	ldp	x27, x28, [sp, #80]
    5064:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5068:	f9000a76 	str	x22, [x19, #16]
    506c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5078:	d65f03c0 	ret
    507c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5080:	d65f03c0 	ret
    5084:	eb1a033f 	cmp	x25, x26
    5088:	aa0403e0 	mov	x0, x4
    508c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5090:	aa1b03e2 	mov	x2, x27
    5094:	cb190063 	sub	x3, x3, x25
    5098:	f9003fe5 	str	x5, [sp, #120]
    509c:	97fff661 	bl	2a20 <__memmove_chk@plt>
    50a0:	a9420660 	ldp	x0, x1, [x19, #32]
    50a4:	aa1c03e2 	mov	x2, x28
    50a8:	f9401a63 	ldr	x3, [x19, #48]
    50ac:	f9403fe5 	ldr	x5, [sp, #120]
    50b0:	8b190063 	add	x3, x3, x25
    50b4:	f9001e63 	str	x3, [x19, #56]
    50b8:	8b050000 	add	x0, x0, x5
    50bc:	97fff58d 	bl	26f0 <memmove@plt>
    50c0:	a9431262 	ldp	x2, x4, [x19, #48]
    50c4:	f9403fe5 	ldr	x5, [sp, #120]
    50c8:	17ffffc7 	b	4fe4 <fwp_p_ad_push.constprop.0+0x140>
    50cc:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    50d0:	910d6000 	add	x0, x0, #0x358
    50d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    50d8:	a90573fb 	stp	x27, x28, [sp, #80]
    50dc:	97fff929 	bl	3580 <fwp_trap>
    50e0:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    50e4:	910ce000 	add	x0, x0, #0x338
    50e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    50ec:	a90573fb 	stp	x27, x28, [sp, #80]
    50f0:	97fff924 	bl	3580 <fwp_trap>
    50f4:	aa1303e0 	mov	x0, x19
    50f8:	97fff7a6 	bl	2f90 <fwp_tape_unlink_scope>
    50fc:	f9401260 	ldr	x0, [x19, #32]
    5100:	97fff610 	bl	2940 <free@plt>
    5104:	f9401a60 	ldr	x0, [x19, #48]
    5108:	97fff60e 	bl	2940 <free@plt>
    510c:	f9402260 	ldr	x0, [x19, #64]
    5110:	97fff60c 	bl	2940 <free@plt>
    5114:	f9000e7f 	str	xzr, [x19, #24]
    5118:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    511c:	f947e821 	ldr	x1, [x1, #4048]
    5120:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5124:	d2800262 	mov	x2, #0x13                  	// #19
    5128:	4f000400 	movi	v0.4s, #0x0
    512c:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x2b0>
    5130:	f9400023 	ldr	x3, [x1]
    5134:	b900067f 	str	wzr, [x19, #4]
    5138:	d2800021 	mov	x1, #0x1                   	// #1
    513c:	913f6000 	add	x0, x0, #0xfd8
    5140:	3c808260 	stur	q0, [x19, #8]
    5144:	ad010260 	stp	q0, q0, [x19, #32]
    5148:	97fff60e 	bl	2980 <fwrite@plt>
    514c:	d2800000 	mov	x0, #0x0                   	// #0
    5150:	97fff618 	bl	29b0 <fflush@plt>
    5154:	52800cc0 	mov	w0, #0x66                  	// #102
    5158:	97fff626 	bl	29f0 <_Exit@plt>
    515c:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    5160:	910c2000 	add	x0, x0, #0x308
    5164:	a9046bf9 	stp	x25, x26, [sp, #64]
    5168:	a90573fb 	stp	x27, x28, [sp, #80]
    516c:	97fff905 	bl	3580 <fwp_trap>

0000000000005170 <w120>:
    5170:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5174:	9e660003 	fmov	x3, d0
    5178:	aa0003e2 	mov	x2, x0
    517c:	910003fd 	mov	x29, sp
    5180:	6d0327e8 	stp	d8, d9, [sp, #48]
    5184:	1e604028 	fmov	d8, d1
    5188:	1e600809 	fmul	d9, d0, d0
    518c:	fd0023ea 	str	d10, [sp, #64]
    5190:	1e60400a 	fmov	d10, d0
    5194:	a90153f3 	stp	x19, x20, [sp, #16]
    5198:	aa0003f3 	mov	x19, x0
    519c:	aa0103f4 	mov	x20, x1
    51a0:	aa0303e1 	mov	x1, x3
    51a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51a8:	97ffff3f 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    51ac:	1e693908 	fsub	d8, d8, d9
    51b0:	aa1403e2 	mov	x2, x20
    51b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51bc:	9e660116 	fmov	x22, d8
    51c0:	97ffff39 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    51c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    51c8:	aa0003e1 	mov	x1, x0
    51cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51d0:	aa1303e0 	mov	x0, x19
    51d4:	1e6a3929 	fsub	d9, d9, d10
    51d8:	aa0103f3 	mov	x19, x1
    51dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    51e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51e4:	9e660135 	fmov	x21, d9
    51e8:	97ffff2f 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    51ec:	1e680908 	fmul	d8, d8, d8
    51f0:	aa0003f4 	mov	x20, x0
    51f4:	aa1603e3 	mov	x3, x22
    51f8:	aa1603e1 	mov	x1, x22
    51fc:	aa1303e2 	mov	x2, x19
    5200:	aa1303e0 	mov	x0, x19
    5204:	97ffff28 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5208:	aa0003e2 	mov	x2, x0
    520c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5210:	9e670020 	fmov	d0, x1
    5214:	9e660101 	fmov	x1, d8
    5218:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    521c:	1e600908 	fmul	d8, d8, d0
    5220:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5224:	97ffff20 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5228:	1e690929 	fmul	d9, d9, d9
    522c:	aa0003f3 	mov	x19, x0
    5230:	aa1503e3 	mov	x3, x21
    5234:	aa1503e1 	mov	x1, x21
    5238:	aa1403e2 	mov	x2, x20
    523c:	aa1403e0 	mov	x0, x20
    5240:	97ffff19 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5244:	1e692908 	fadd	d8, d8, d9
    5248:	aa1303e2 	mov	x2, x19
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa0303e1 	mov	x1, x3
    5254:	97ffff14 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5258:	aa0003e1 	mov	x1, x0
    525c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5260:	9e660100 	fmov	x0, d8
    5264:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5268:	6d4327e8 	ldp	d8, d9, [sp, #48]
    526c:	fd4023ea 	ldr	d10, [sp, #64]
    5270:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5274:	d65f03c0 	ret
    5278:	d503201f 	nop
    527c:	d503201f 	nop

0000000000005280 <w176.constprop.0>:
    5280:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5284:	910003fd 	mov	x29, sp
    5288:	a9025bf5 	stp	x21, x22, [sp, #32]
    528c:	fd001be8 	str	d8, [sp, #48]
    5290:	f9400015 	ldr	x21, [x0]
    5294:	b4000315 	cbz	x21, 52f4 <w176.constprop.0+0x74>
    5298:	2f00e408 	movi	d8, #0x0
    529c:	91002016 	add	x22, x0, #0x8
    52a0:	a90153f3 	stp	x19, x20, [sp, #16]
    52a4:	91004014 	add	x20, x0, #0x10
    52a8:	d2800013 	mov	x19, #0x0                   	// #0
    52ac:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52b0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    52b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52b8:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    52bc:	aa0303e1 	mov	x1, x3
    52c0:	1e602908 	fadd	d8, d8, d0
    52c4:	91000a73 	add	x19, x19, #0x2
    52c8:	97fffef7 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    52cc:	eb1302bf 	cmp	x21, x19
    52d0:	54ffff08 	b.hi	52b0 <w176.constprop.0+0x30>  // b.pmore
    52d4:	9e660102 	fmov	x2, d8
    52d8:	fd401be8 	ldr	d8, [sp, #48]
    52dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    52e0:	aa0003e1 	mov	x1, x0
    52e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52e8:	aa0203e0 	mov	x0, x2
    52ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    52f0:	d65f03c0 	ret
    52f4:	2f00e408 	movi	d8, #0x0
    52f8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5300:	aa0003e1 	mov	x1, x0
    5304:	9e660102 	fmov	x2, d8
    5308:	fd401be8 	ldr	d8, [sp, #48]
    530c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5310:	aa0203e0 	mov	x0, x2
    5314:	d65f03c0 	ret
    5318:	d503201f 	nop
    531c:	d503201f 	nop

0000000000005320 <fwp_rc_share>:
    5320:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5324:	9114c042 	add	x2, x2, #0x530
    5328:	f949d843 	ldr	x3, [x2, #5040]
    532c:	f949ec41 	ldr	x1, [x2, #5080]
    5330:	cb030000 	sub	x0, x0, x3
    5334:	eb01401f 	cmp	x0, x1, lsl #16
    5338:	540002c2 	b.cs	5390 <fwp_rc_share+0x70>  // b.hs, b.nlast
    533c:	d350fc01 	lsr	x1, x0, #16
    5340:	f949fc44 	ldr	x4, [x2, #5112]
    5344:	8b010821 	add	x1, x1, x1, lsl #2
    5348:	d37df021 	lsl	x1, x1, #3
    534c:	8b010083 	add	x3, x4, x1
    5350:	f9401062 	ldr	x2, [x3, #32]
    5354:	b40001e2 	cbz	x2, 5390 <fwp_rc_share+0x70>
    5358:	38616881 	ldrb	w1, [x4, x1]
    535c:	7100083f 	cmp	w1, #0x2
    5360:	540001a0 	b.eq	5394 <fwp_rc_share+0x74>  // b.none
    5364:	7100043f 	cmp	w1, #0x1
    5368:	54000141 	b.ne	5390 <fwp_rc_share+0x70>  // b.any
    536c:	29430464 	ldp	w4, w1, [x3, #24]
    5370:	92403c00 	and	x0, x0, #0xffff
    5374:	9b047c00 	mul	x0, x0, x4
    5378:	d360fc00 	lsr	x0, x0, #32
    537c:	eb01001f 	cmp	x0, x1
    5380:	54000082 	b.cs	5390 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5384:	8b000042 	add	x2, x2, x0
    5388:	39400040 	ldrb	w0, [x2]
    538c:	350000a0 	cbnz	w0, 53a0 <fwp_rc_share+0x80>
    5390:	d65f03c0 	ret
    5394:	72003c1f 	tst	w0, #0xffff
    5398:	54ffff80 	b.eq	5388 <fwp_rc_share+0x68>  // b.none
    539c:	d65f03c0 	ret
    53a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    53a4:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    53a8:	910de000 	add	x0, x0, #0x378
    53ac:	910003fd 	mov	x29, sp
    53b0:	97fff874 	bl	3580 <fwp_trap>

00000000000053b4 <fwp_rc_free_arr>:
    53b4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    53b8:	9114c063 	add	x3, x3, #0x530
    53bc:	f949d861 	ldr	x1, [x3, #5040]
    53c0:	f949ec62 	ldr	x2, [x3, #5080]
    53c4:	cb010001 	sub	x1, x0, x1
    53c8:	eb02403f 	cmp	x1, x2, lsl #16
    53cc:	54000342 	b.cs	5434 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    53d0:	d350fc22 	lsr	x2, x1, #16
    53d4:	f949fc65 	ldr	x5, [x3, #5112]
    53d8:	8b020842 	add	x2, x2, x2, lsl #2
    53dc:	d37df042 	lsl	x2, x2, #3
    53e0:	8b0200a4 	add	x4, x5, x2
    53e4:	f9401083 	ldr	x3, [x4, #32]
    53e8:	b4000263 	cbz	x3, 5434 <fwp_rc_free_arr+0x80>
    53ec:	386268a2 	ldrb	w2, [x5, x2]
    53f0:	7100085f 	cmp	w2, #0x2
    53f4:	540001c0 	b.eq	542c <fwp_rc_free_arr+0x78>  // b.none
    53f8:	7100045f 	cmp	w2, #0x1
    53fc:	540001c1 	b.ne	5434 <fwp_rc_free_arr+0x80>  // b.any
    5400:	29430885 	ldp	w5, w2, [x4, #24]
    5404:	92403c21 	and	x1, x1, #0xffff
    5408:	9b057c21 	mul	x1, x1, x5
    540c:	d360fc21 	lsr	x1, x1, #32
    5410:	eb02003f 	cmp	x1, x2
    5414:	54000102 	b.cs	5434 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5418:	8b010063 	add	x3, x3, x1
    541c:	39400061 	ldrb	w1, [x3]
    5420:	7100043f 	cmp	w1, #0x1
    5424:	54000081 	b.ne	5434 <fwp_rc_free_arr+0x80>  // b.any
    5428:	17fffcf2 	b	47f0 <fwp_mem_free>
    542c:	72003c3f 	tst	w1, #0xffff
    5430:	54ffff60 	b.eq	541c <fwp_rc_free_arr+0x68>  // b.none
    5434:	d65f03c0 	ret
    5438:	d503201f 	nop
    543c:	d503201f 	nop

0000000000005440 <fwp_rc_dup>:
    5440:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5444:	9114c042 	add	x2, x2, #0x530
    5448:	f949d841 	ldr	x1, [x2, #5040]
    544c:	f949ec43 	ldr	x3, [x2, #5080]
    5450:	cb010001 	sub	x1, x0, x1
    5454:	eb03403f 	cmp	x1, x3, lsl #16
    5458:	54000342 	b.cs	54c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    545c:	d350fc20 	lsr	x0, x1, #16
    5460:	f949fc44 	ldr	x4, [x2, #5112]
    5464:	8b000800 	add	x0, x0, x0, lsl #2
    5468:	d37df002 	lsl	x2, x0, #3
    546c:	8b020083 	add	x3, x4, x2
    5470:	f9401060 	ldr	x0, [x3, #32]
    5474:	b4000260 	cbz	x0, 54c0 <fwp_rc_dup+0x80>
    5478:	38626882 	ldrb	w2, [x4, x2]
    547c:	7100085f 	cmp	w2, #0x2
    5480:	54000220 	b.eq	54c4 <fwp_rc_dup+0x84>  // b.none
    5484:	7100045f 	cmp	w2, #0x1
    5488:	540001c1 	b.ne	54c0 <fwp_rc_dup+0x80>  // b.any
    548c:	29430864 	ldp	w4, w2, [x3, #24]
    5490:	92403c21 	and	x1, x1, #0xffff
    5494:	9b047c21 	mul	x1, x1, x4
    5498:	d360fc21 	lsr	x1, x1, #32
    549c:	eb02003f 	cmp	x1, x2
    54a0:	54000102 	b.cs	54c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    54a4:	8b010000 	add	x0, x0, x1
    54a8:	39400001 	ldrb	w1, [x0]
    54ac:	340000a1 	cbz	w1, 54c0 <fwp_rc_dup+0x80>
    54b0:	7103f43f 	cmp	w1, #0xfd
    54b4:	540000e8 	b.hi	54d0 <fwp_rc_dup+0x90>  // b.pmore
    54b8:	11000421 	add	w1, w1, #0x1
    54bc:	39000001 	strb	w1, [x0]
    54c0:	d65f03c0 	ret
    54c4:	72003c3f 	tst	w1, #0xffff
    54c8:	54ffff00 	b.eq	54a8 <fwp_rc_dup+0x68>  // b.none
    54cc:	d65f03c0 	ret
    54d0:	17fffbe1 	b	4454 <fwp_rc_wide_dup>

00000000000054d4 <fwp_owned_entry173>:
    54d4:	d10103ff 	sub	sp, sp, #0x40
    54d8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    54dc:	f947f442 	ldr	x2, [x2, #4072]
    54e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    54e4:	910083fd 	add	x29, sp, #0x20
    54e8:	a90353f3 	stp	x19, x20, [sp, #48]
    54ec:	f9400043 	ldr	x3, [x2]
    54f0:	f9000fe3 	str	x3, [sp, #24]
    54f4:	d2800003 	mov	x3, #0x0                   	// #0
    54f8:	a9400c01 	ldp	x1, x3, [x0]
    54fc:	f9400802 	ldr	x2, [x0, #16]
    5500:	ab020022 	adds	x2, x1, x2
    5504:	540006e6 	b.vs	55e0 <fwp_owned_entry173+0x10c>
    5508:	910023e1 	add	x1, sp, #0x8
    550c:	52800000 	mov	w0, #0x0                   	// #0
    5510:	a9008be3 	stp	x3, x2, [sp, #8]
    5514:	97fffe1c 	bl	4d84 <fwp_data.part.0.constprop.0>
    5518:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    551c:	9114c063 	add	x3, x3, #0x530
    5520:	aa0003f3 	mov	x19, x0
    5524:	f949d861 	ldr	x1, [x3, #5040]
    5528:	f949ec60 	ldr	x0, [x3, #5080]
    552c:	cb010261 	sub	x1, x19, x1
    5530:	eb00403f 	cmp	x1, x0, lsl #16
    5534:	54000322 	b.cs	5598 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5538:	d350fc22 	lsr	x2, x1, #16
    553c:	f949fc63 	ldr	x3, [x3, #5112]
    5540:	8b020842 	add	x2, x2, x2, lsl #2
    5544:	d37df042 	lsl	x2, x2, #3
    5548:	8b020060 	add	x0, x3, x2
    554c:	f9401014 	ldr	x20, [x0, #32]
    5550:	b4000254 	cbz	x20, 5598 <fwp_owned_entry173+0xc4>
    5554:	38626862 	ldrb	w2, [x3, x2]
    5558:	7100085f 	cmp	w2, #0x2
    555c:	54000360 	b.eq	55c8 <fwp_owned_entry173+0xf4>  // b.none
    5560:	7100045f 	cmp	w2, #0x1
    5564:	540001a1 	b.ne	5598 <fwp_owned_entry173+0xc4>  // b.any
    5568:	29430002 	ldp	w2, w0, [x0, #24]
    556c:	92403c21 	and	x1, x1, #0xffff
    5570:	9b027c21 	mul	x1, x1, x2
    5574:	d360fc21 	lsr	x1, x1, #32
    5578:	eb00003f 	cmp	x1, x0
    557c:	540000e2 	b.cs	5598 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5580:	8b010294 	add	x20, x20, x1
    5584:	39400280 	ldrb	w0, [x20]
    5588:	7103fc1f 	cmp	w0, #0xff
    558c:	54000240 	b.eq	55d4 <fwp_owned_entry173+0x100>  // b.none
    5590:	52800020 	mov	w0, #0x1                   	// #1
    5594:	39000280 	strb	w0, [x20]
    5598:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    559c:	f947f400 	ldr	x0, [x0, #4072]
    55a0:	f9400fe2 	ldr	x2, [sp, #24]
    55a4:	f9400001 	ldr	x1, [x0]
    55a8:	eb010042 	subs	x2, x2, x1
    55ac:	d2800001 	mov	x1, #0x0                   	// #0
    55b0:	540001a1 	b.ne	55e4 <fwp_owned_entry173+0x110>  // b.any
    55b4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    55b8:	aa1303e0 	mov	x0, x19
    55bc:	a94353f3 	ldp	x19, x20, [sp, #48]
    55c0:	910103ff 	add	sp, sp, #0x40
    55c4:	d65f03c0 	ret
    55c8:	72003c3f 	tst	w1, #0xffff
    55cc:	54fffe61 	b.ne	5598 <fwp_owned_entry173+0xc4>  // b.any
    55d0:	17ffffed 	b	5584 <fwp_owned_entry173+0xb0>
    55d4:	aa1403e0 	mov	x0, x20
    55d8:	97fffbe6 	bl	4570 <fwp_rc_forget_slot>
    55dc:	17ffffed 	b	5590 <fwp_owned_entry173+0xbc>
    55e0:	97fff528 	bl	2a80 <fwp_trap_overflow.constprop.0>
    55e4:	97fff4a7 	bl	2880 <__stack_chk_fail@plt>
    55e8:	d503201f 	nop
    55ec:	d503201f 	nop

00000000000055f0 <e173>:
    55f0:	d10103ff 	sub	sp, sp, #0x40
    55f4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    55f8:	f947f442 	ldr	x2, [x2, #4072]
    55fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5600:	910083fd 	add	x29, sp, #0x20
    5604:	a90353f3 	stp	x19, x20, [sp, #48]
    5608:	f9400043 	ldr	x3, [x2]
    560c:	f9000fe3 	str	x3, [sp, #24]
    5610:	d2800003 	mov	x3, #0x0                   	// #0
    5614:	a9400c01 	ldp	x1, x3, [x0]
    5618:	f9400802 	ldr	x2, [x0, #16]
    561c:	ab020022 	adds	x2, x1, x2
    5620:	54000726 	b.vs	5704 <e173+0x114>
    5624:	910023e1 	add	x1, sp, #0x8
    5628:	52800000 	mov	w0, #0x0                   	// #0
    562c:	a9008be3 	stp	x3, x2, [sp, #8]
    5630:	97fffdd5 	bl	4d84 <fwp_data.part.0.constprop.0>
    5634:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5638:	9114c063 	add	x3, x3, #0x530
    563c:	aa0003f3 	mov	x19, x0
    5640:	f949d861 	ldr	x1, [x3, #5040]
    5644:	f949ec60 	ldr	x0, [x3, #5080]
    5648:	cb010261 	sub	x1, x19, x1
    564c:	eb00403f 	cmp	x1, x0, lsl #16
    5650:	54000322 	b.cs	56b4 <e173+0xc4>  // b.hs, b.nlast
    5654:	d350fc22 	lsr	x2, x1, #16
    5658:	f949fc63 	ldr	x3, [x3, #5112]
    565c:	8b020842 	add	x2, x2, x2, lsl #2
    5660:	d37df042 	lsl	x2, x2, #3
    5664:	8b020060 	add	x0, x3, x2
    5668:	f9401014 	ldr	x20, [x0, #32]
    566c:	b4000254 	cbz	x20, 56b4 <e173+0xc4>
    5670:	38626862 	ldrb	w2, [x3, x2]
    5674:	7100085f 	cmp	w2, #0x2
    5678:	540003a0 	b.eq	56ec <e173+0xfc>  // b.none
    567c:	7100045f 	cmp	w2, #0x1
    5680:	540001a1 	b.ne	56b4 <e173+0xc4>  // b.any
    5684:	29430002 	ldp	w2, w0, [x0, #24]
    5688:	92403c21 	and	x1, x1, #0xffff
    568c:	9b027c21 	mul	x1, x1, x2
    5690:	d360fc21 	lsr	x1, x1, #32
    5694:	eb00003f 	cmp	x1, x0
    5698:	540000e2 	b.cs	56b4 <e173+0xc4>  // b.hs, b.nlast
    569c:	8b010294 	add	x20, x20, x1
    56a0:	39400280 	ldrb	w0, [x20]
    56a4:	7103fc1f 	cmp	w0, #0xff
    56a8:	54000280 	b.eq	56f8 <e173+0x108>  // b.none
    56ac:	52800020 	mov	w0, #0x1                   	// #1
    56b0:	39000280 	strb	w0, [x20]
    56b4:	aa1303e0 	mov	x0, x19
    56b8:	97ffff1a 	bl	5320 <fwp_rc_share>
    56bc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    56c0:	f947f400 	ldr	x0, [x0, #4072]
    56c4:	f9400fe2 	ldr	x2, [sp, #24]
    56c8:	f9400001 	ldr	x1, [x0]
    56cc:	eb010042 	subs	x2, x2, x1
    56d0:	d2800001 	mov	x1, #0x0                   	// #0
    56d4:	540001a1 	b.ne	5708 <e173+0x118>  // b.any
    56d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    56dc:	aa1303e0 	mov	x0, x19
    56e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    56e4:	910103ff 	add	sp, sp, #0x40
    56e8:	d65f03c0 	ret
    56ec:	72003c3f 	tst	w1, #0xffff
    56f0:	54fffe21 	b.ne	56b4 <e173+0xc4>  // b.any
    56f4:	17ffffeb 	b	56a0 <e173+0xb0>
    56f8:	aa1403e0 	mov	x0, x20
    56fc:	97fffb9d 	bl	4570 <fwp_rc_forget_slot>
    5700:	17ffffeb 	b	56ac <e173+0xbc>
    5704:	97fff4df 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5708:	97fff45e 	bl	2880 <__stack_chk_fail@plt>
    570c:	d503201f 	nop

0000000000005710 <fwp_drop0>:
    5710:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5714:	910003fd 	mov	x29, sp
    5718:	a90153f3 	stp	x19, x20, [sp, #16]
    571c:	f90013f5 	str	x21, [sp, #32]
    5720:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5724:	9114c2b4 	add	x20, x21, #0x530
    5728:	f949da81 	ldr	x1, [x20, #5040]
    572c:	f949ee82 	ldr	x2, [x20, #5080]
    5730:	cb010001 	sub	x1, x0, x1
    5734:	eb02403f 	cmp	x1, x2, lsl #16
    5738:	54000382 	b.cs	57a8 <fwp_drop0+0x98>  // b.hs, b.nlast
    573c:	d350fc22 	lsr	x2, x1, #16
    5740:	f949fe84 	ldr	x4, [x20, #5112]
    5744:	8b020842 	add	x2, x2, x2, lsl #2
    5748:	d37df042 	lsl	x2, x2, #3
    574c:	8b020083 	add	x3, x4, x2
    5750:	f9401073 	ldr	x19, [x3, #32]
    5754:	b40002b3 	cbz	x19, 57a8 <fwp_drop0+0x98>
    5758:	38626882 	ldrb	w2, [x4, x2]
    575c:	7100085f 	cmp	w2, #0x2
    5760:	540002c0 	b.eq	57b8 <fwp_drop0+0xa8>  // b.none
    5764:	7100045f 	cmp	w2, #0x1
    5768:	54000201 	b.ne	57a8 <fwp_drop0+0x98>  // b.any
    576c:	29430864 	ldp	w4, w2, [x3, #24]
    5770:	92403c21 	and	x1, x1, #0xffff
    5774:	9b047c21 	mul	x1, x1, x4
    5778:	d360fc21 	lsr	x1, x1, #32
    577c:	eb02003f 	cmp	x1, x2
    5780:	54000142 	b.cs	57a8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5784:	8b010273 	add	x19, x19, x1
    5788:	39400261 	ldrb	w1, [x19]
    578c:	340000e1 	cbz	w1, 57a8 <fwp_drop0+0x98>
    5790:	7100043f 	cmp	w1, #0x1
    5794:	540001e0 	b.eq	57d0 <fwp_drop0+0xc0>  // b.none
    5798:	7103fc3f 	cmp	w1, #0xff
    579c:	540002e0 	b.eq	57f8 <fwp_drop0+0xe8>  // b.none
    57a0:	51000421 	sub	w1, w1, #0x1
    57a4:	39000261 	strb	w1, [x19]
    57a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    57ac:	f94013f5 	ldr	x21, [sp, #32]
    57b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57b4:	d65f03c0 	ret
    57b8:	72003c3f 	tst	w1, #0xffff
    57bc:	54fffe60 	b.eq	5788 <fwp_drop0+0x78>  // b.none
    57c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c4:	f94013f5 	ldr	x21, [sp, #32]
    57c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57cc:	d65f03c0 	ret
    57d0:	f9400813 	ldr	x19, [x0, #16]
    57d4:	97fffef8 	bl	53b4 <fwp_rc_free_arr>
    57d8:	9114c2a0 	add	x0, x21, #0x530
    57dc:	f949d801 	ldr	x1, [x0, #5040]
    57e0:	f949ec00 	ldr	x0, [x0, #5080]
    57e4:	cb010261 	sub	x1, x19, x1
    57e8:	eb00403f 	cmp	x1, x0, lsl #16
    57ec:	54fffde2 	b.cs	57a8 <fwp_drop0+0x98>  // b.hs, b.nlast
    57f0:	aa1303e0 	mov	x0, x19
    57f4:	17ffffd2 	b	573c <fwp_drop0+0x2c>
    57f8:	ca534660 	eor	x0, x19, x19, lsr #17
    57fc:	9114c2b5 	add	x21, x21, #0x530
    5800:	ca402400 	eor	x0, x0, x0, lsr #9
    5804:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5808:	f94a2400 	ldr	x0, [x0, #5192]
    580c:	b5000080 	cbnz	x0, 581c <fwp_drop0+0x10c>
    5810:	14000010 	b	5850 <fwp_drop0+0x140>
    5814:	f9400800 	ldr	x0, [x0, #16]
    5818:	b40001c0 	cbz	x0, 5850 <fwp_drop0+0x140>
    581c:	f9400001 	ldr	x1, [x0]
    5820:	eb13003f 	cmp	x1, x19
    5824:	54ffff81 	b.ne	5814 <fwp_drop0+0x104>  // b.any
    5828:	f9400401 	ldr	x1, [x0, #8]
    582c:	d1000421 	sub	x1, x1, #0x1
    5830:	f9000401 	str	x1, [x0, #8]
    5834:	f103f83f 	cmp	x1, #0xfe
    5838:	54fffb81 	b.ne	57a8 <fwp_drop0+0x98>  // b.any
    583c:	aa1303e0 	mov	x0, x19
    5840:	97fffb4c 	bl	4570 <fwp_rc_forget_slot>
    5844:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5848:	39000260 	strb	w0, [x19]
    584c:	17ffffd7 	b	57a8 <fwp_drop0+0x98>
    5850:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    5854:	9109e000 	add	x0, x0, #0x278
    5858:	97fff74a 	bl	3580 <fwp_trap>
    585c:	d503201f 	nop

0000000000005860 <fwp_drop1>:
    5860:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5864:	910003fd 	mov	x29, sp
    5868:	a90153f3 	stp	x19, x20, [sp, #16]
    586c:	f90013f5 	str	x21, [sp, #32]
    5870:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5874:	9114c2b4 	add	x20, x21, #0x530
    5878:	f949da81 	ldr	x1, [x20, #5040]
    587c:	f949ee82 	ldr	x2, [x20, #5080]
    5880:	cb010001 	sub	x1, x0, x1
    5884:	eb02403f 	cmp	x1, x2, lsl #16
    5888:	54000382 	b.cs	58f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    588c:	d350fc22 	lsr	x2, x1, #16
    5890:	f949fe84 	ldr	x4, [x20, #5112]
    5894:	8b020842 	add	x2, x2, x2, lsl #2
    5898:	d37df042 	lsl	x2, x2, #3
    589c:	8b020083 	add	x3, x4, x2
    58a0:	f9401073 	ldr	x19, [x3, #32]
    58a4:	b40002b3 	cbz	x19, 58f8 <fwp_drop1+0x98>
    58a8:	38626882 	ldrb	w2, [x4, x2]
    58ac:	7100085f 	cmp	w2, #0x2
    58b0:	540002c0 	b.eq	5908 <fwp_drop1+0xa8>  // b.none
    58b4:	7100045f 	cmp	w2, #0x1
    58b8:	54000201 	b.ne	58f8 <fwp_drop1+0x98>  // b.any
    58bc:	29430864 	ldp	w4, w2, [x3, #24]
    58c0:	92403c21 	and	x1, x1, #0xffff
    58c4:	9b047c21 	mul	x1, x1, x4
    58c8:	d360fc21 	lsr	x1, x1, #32
    58cc:	eb02003f 	cmp	x1, x2
    58d0:	54000142 	b.cs	58f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    58d4:	8b010273 	add	x19, x19, x1
    58d8:	39400261 	ldrb	w1, [x19]
    58dc:	340000e1 	cbz	w1, 58f8 <fwp_drop1+0x98>
    58e0:	7100043f 	cmp	w1, #0x1
    58e4:	540001e0 	b.eq	5920 <fwp_drop1+0xc0>  // b.none
    58e8:	7103fc3f 	cmp	w1, #0xff
    58ec:	540002e0 	b.eq	5948 <fwp_drop1+0xe8>  // b.none
    58f0:	51000421 	sub	w1, w1, #0x1
    58f4:	39000261 	strb	w1, [x19]
    58f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    58fc:	f94013f5 	ldr	x21, [sp, #32]
    5900:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5904:	d65f03c0 	ret
    5908:	72003c3f 	tst	w1, #0xffff
    590c:	54fffe60 	b.eq	58d8 <fwp_drop1+0x78>  // b.none
    5910:	a94153f3 	ldp	x19, x20, [sp, #16]
    5914:	f94013f5 	ldr	x21, [sp, #32]
    5918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    591c:	d65f03c0 	ret
    5920:	f9400813 	ldr	x19, [x0, #16]
    5924:	97fffea4 	bl	53b4 <fwp_rc_free_arr>
    5928:	9114c2a0 	add	x0, x21, #0x530
    592c:	f949d801 	ldr	x1, [x0, #5040]
    5930:	f949ec00 	ldr	x0, [x0, #5080]
    5934:	cb010261 	sub	x1, x19, x1
    5938:	eb00403f 	cmp	x1, x0, lsl #16
    593c:	54fffde2 	b.cs	58f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5940:	aa1303e0 	mov	x0, x19
    5944:	17ffffd2 	b	588c <fwp_drop1+0x2c>
    5948:	ca534660 	eor	x0, x19, x19, lsr #17
    594c:	9114c2b5 	add	x21, x21, #0x530
    5950:	ca402400 	eor	x0, x0, x0, lsr #9
    5954:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5958:	f94a2400 	ldr	x0, [x0, #5192]
    595c:	b5000080 	cbnz	x0, 596c <fwp_drop1+0x10c>
    5960:	14000010 	b	59a0 <fwp_drop1+0x140>
    5964:	f9400800 	ldr	x0, [x0, #16]
    5968:	b40001c0 	cbz	x0, 59a0 <fwp_drop1+0x140>
    596c:	f9400001 	ldr	x1, [x0]
    5970:	eb13003f 	cmp	x1, x19
    5974:	54ffff81 	b.ne	5964 <fwp_drop1+0x104>  // b.any
    5978:	f9400401 	ldr	x1, [x0, #8]
    597c:	d1000421 	sub	x1, x1, #0x1
    5980:	f9000401 	str	x1, [x0, #8]
    5984:	f103f83f 	cmp	x1, #0xfe
    5988:	54fffb81 	b.ne	58f8 <fwp_drop1+0x98>  // b.any
    598c:	aa1303e0 	mov	x0, x19
    5990:	97fffaf8 	bl	4570 <fwp_rc_forget_slot>
    5994:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5998:	39000260 	strb	w0, [x19]
    599c:	17ffffd7 	b	58f8 <fwp_drop1+0x98>
    59a0:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    59a4:	9109e000 	add	x0, x0, #0x278
    59a8:	97fff6f6 	bl	3580 <fwp_trap>
    59ac:	d503201f 	nop

00000000000059b0 <fwp_closure_drop>:
    59b0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    59b4:	9114c0a4 	add	x4, x5, #0x530
    59b8:	aa0003e1 	mov	x1, x0
    59bc:	f949d882 	ldr	x2, [x4, #5040]
    59c0:	f949ec80 	ldr	x0, [x4, #5080]
    59c4:	cb020022 	sub	x2, x1, x2
    59c8:	eb00405f 	cmp	x2, x0, lsl #16
    59cc:	54000662 	b.cs	5a98 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    59d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    59d4:	d350fc43 	lsr	x3, x2, #16
    59d8:	910003fd 	mov	x29, sp
    59dc:	8b030863 	add	x3, x3, x3, lsl #2
    59e0:	f949fc84 	ldr	x4, [x4, #5112]
    59e4:	d37df063 	lsl	x3, x3, #3
    59e8:	f9000bf3 	str	x19, [sp, #16]
    59ec:	8b030080 	add	x0, x4, x3
    59f0:	f9401013 	ldr	x19, [x0, #32]
    59f4:	b40002b3 	cbz	x19, 5a48 <fwp_closure_drop+0x98>
    59f8:	38636883 	ldrb	w3, [x4, x3]
    59fc:	7100087f 	cmp	w3, #0x2
    5a00:	54000420 	b.eq	5a84 <fwp_closure_drop+0xd4>  // b.none
    5a04:	7100047f 	cmp	w3, #0x1
    5a08:	54000201 	b.ne	5a48 <fwp_closure_drop+0x98>  // b.any
    5a0c:	29430003 	ldp	w3, w0, [x0, #24]
    5a10:	92403c42 	and	x2, x2, #0xffff
    5a14:	9b037c42 	mul	x2, x2, x3
    5a18:	d360fc42 	lsr	x2, x2, #32
    5a1c:	eb00005f 	cmp	x2, x0
    5a20:	54000142 	b.cs	5a48 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5a24:	8b020273 	add	x19, x19, x2
    5a28:	39400260 	ldrb	w0, [x19]
    5a2c:	340000e0 	cbz	w0, 5a48 <fwp_closure_drop+0x98>
    5a30:	7100041f 	cmp	w0, #0x1
    5a34:	54000100 	b.eq	5a54 <fwp_closure_drop+0xa4>  // b.none
    5a38:	7103fc1f 	cmp	w0, #0xff
    5a3c:	54000300 	b.eq	5a9c <fwp_closure_drop+0xec>  // b.none
    5a40:	51000400 	sub	w0, w0, #0x1
    5a44:	39000260 	strb	w0, [x19]
    5a48:	f9400bf3 	ldr	x19, [sp, #16]
    5a4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a50:	d65f03c0 	ret
    5a54:	d53bd040 	mrs	x0, tpidr_el0
    5a58:	91400000 	add	x0, x0, #0x0, lsl #12
    5a5c:	91004000 	add	x0, x0, #0x10
    5a60:	f9400000 	ldr	x0, [x0]
    5a64:	b4000080 	cbz	x0, 5a74 <fwp_closure_drop+0xc4>
    5a68:	f9400bf3 	ldr	x19, [sp, #16]
    5a6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a70:	17fff6dd 	b	35e4 <fwp_closure_drop_push>
    5a74:	f9400bf3 	ldr	x19, [sp, #16]
    5a78:	aa0103e0 	mov	x0, x1
    5a7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a80:	17fff748 	b	37a0 <fwp_closure_drop.part.0>
    5a84:	72003c5f 	tst	w2, #0xffff
    5a88:	54fffd00 	b.eq	5a28 <fwp_closure_drop+0x78>  // b.none
    5a8c:	f9400bf3 	ldr	x19, [sp, #16]
    5a90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a94:	d65f03c0 	ret
    5a98:	d65f03c0 	ret
    5a9c:	ca534660 	eor	x0, x19, x19, lsr #17
    5aa0:	9114c0a5 	add	x5, x5, #0x530
    5aa4:	ca402400 	eor	x0, x0, x0, lsr #9
    5aa8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5aac:	f94a2400 	ldr	x0, [x0, #5192]
    5ab0:	b5000080 	cbnz	x0, 5ac0 <fwp_closure_drop+0x110>
    5ab4:	14000010 	b	5af4 <fwp_closure_drop+0x144>
    5ab8:	f9400800 	ldr	x0, [x0, #16]
    5abc:	b40001c0 	cbz	x0, 5af4 <fwp_closure_drop+0x144>
    5ac0:	f9400001 	ldr	x1, [x0]
    5ac4:	eb13003f 	cmp	x1, x19
    5ac8:	54ffff81 	b.ne	5ab8 <fwp_closure_drop+0x108>  // b.any
    5acc:	f9400401 	ldr	x1, [x0, #8]
    5ad0:	d1000421 	sub	x1, x1, #0x1
    5ad4:	f9000401 	str	x1, [x0, #8]
    5ad8:	f103f83f 	cmp	x1, #0xfe
    5adc:	54fffb61 	b.ne	5a48 <fwp_closure_drop+0x98>  // b.any
    5ae0:	aa1303e0 	mov	x0, x19
    5ae4:	97fffaa3 	bl	4570 <fwp_rc_forget_slot>
    5ae8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5aec:	39000260 	strb	w0, [x19]
    5af0:	17ffffd6 	b	5a48 <fwp_closure_drop+0x98>
    5af4:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    5af8:	9109e000 	add	x0, x0, #0x278
    5afc:	97fff6a1 	bl	3580 <fwp_trap>

0000000000005b00 <fwp_owned_tape_release>:
    5b00:	b4000940 	cbz	x0, 5c28 <fwp_owned_tape_release+0x128>
    5b04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b08:	910003fd 	mov	x29, sp
    5b0c:	a90153f3 	stp	x19, x20, [sp, #16]
    5b10:	aa0003f3 	mov	x19, x0
    5b14:	f9400000 	ldr	x0, [x0]
    5b18:	b4000060 	cbz	x0, 5b24 <fwp_owned_tape_release+0x24>
    5b1c:	f9400661 	ldr	x1, [x19, #8]
    5b20:	f9000401 	str	x1, [x0, #8]
    5b24:	f9400661 	ldr	x1, [x19, #8]
    5b28:	b4000041 	cbz	x1, 5b30 <fwp_owned_tape_release+0x30>
    5b2c:	f9000020 	str	x0, [x1]
    5b30:	f9400a60 	ldr	x0, [x19, #16]
    5b34:	f9403401 	ldr	x1, [x0, #104]
    5b38:	b40005c1 	cbz	x1, 5bf0 <fwp_owned_tape_release+0xf0>
    5b3c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5b40:	eb00005f 	cmp	x2, x0
    5b44:	540002ed 	b.le	5ba0 <fwp_owned_tape_release+0xa0>
    5b48:	d2800014 	mov	x20, #0x0                   	// #0
    5b4c:	f90013f5 	str	x21, [sp, #32]
    5b50:	d2800015 	mov	x21, #0x0                   	// #0
    5b54:	d503201f 	nop
    5b58:	f9402260 	ldr	x0, [x19, #64]
    5b5c:	910006b5 	add	x21, x21, #0x1
    5b60:	f8746800 	ldr	x0, [x0, x20]
    5b64:	d63f0020 	blr	x1
    5b68:	f9402260 	ldr	x0, [x19, #64]
    5b6c:	f9400a61 	ldr	x1, [x19, #16]
    5b70:	8b140000 	add	x0, x0, x20
    5b74:	91004294 	add	x20, x20, #0x10
    5b78:	f9400400 	ldr	x0, [x0, #8]
    5b7c:	f9403421 	ldr	x1, [x1, #104]
    5b80:	d63f0020 	blr	x1
    5b84:	a9450261 	ldp	x1, x0, [x19, #80]
    5b88:	cb010000 	sub	x0, x0, x1
    5b8c:	eb15001f 	cmp	x0, x21
    5b90:	f9400a60 	ldr	x0, [x19, #16]
    5b94:	f9403401 	ldr	x1, [x0, #104]
    5b98:	54fffe0c 	b.gt	5b58 <fwp_owned_tape_release+0x58>
    5b9c:	f94013f5 	ldr	x21, [sp, #32]
    5ba0:	f9403663 	ldr	x3, [x19, #104]
    5ba4:	f9401262 	ldr	x2, [x19, #32]
    5ba8:	f100007f 	cmp	x3, #0x0
    5bac:	540001ed 	b.le	5be8 <fwp_owned_tape_release+0xe8>
    5bb0:	d2800014 	mov	x20, #0x0                   	// #0
    5bb4:	d503201f 	nop
    5bb8:	f9402660 	ldr	x0, [x19, #72]
    5bbc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5bc0:	eb02001f 	cmp	x0, x2
    5bc4:	540000c0 	b.eq	5bdc <fwp_owned_tape_release+0xdc>  // b.none
    5bc8:	d63f0020 	blr	x1
    5bcc:	f9400a60 	ldr	x0, [x19, #16]
    5bd0:	f9401262 	ldr	x2, [x19, #32]
    5bd4:	f9403663 	ldr	x3, [x19, #104]
    5bd8:	f9403401 	ldr	x1, [x0, #104]
    5bdc:	91000694 	add	x20, x20, #0x1
    5be0:	eb14007f 	cmp	x3, x20
    5be4:	54fffeac 	b.gt	5bb8 <fwp_owned_tape_release+0xb8>
    5be8:	aa0203e0 	mov	x0, x2
    5bec:	d63f0020 	blr	x1
    5bf0:	f9401660 	ldr	x0, [x19, #40]
    5bf4:	97ffff6f 	bl	59b0 <fwp_closure_drop>
    5bf8:	f9401a60 	ldr	x0, [x19, #48]
    5bfc:	97ffff6d 	bl	59b0 <fwp_closure_drop>
    5c00:	f9401e60 	ldr	x0, [x19, #56]
    5c04:	97ffff6b 	bl	59b0 <fwp_closure_drop>
    5c08:	f9402260 	ldr	x0, [x19, #64]
    5c0c:	97fffaf9 	bl	47f0 <fwp_mem_free>
    5c10:	f9402660 	ldr	x0, [x19, #72]
    5c14:	97fffaf7 	bl	47f0 <fwp_mem_free>
    5c18:	aa1303e0 	mov	x0, x19
    5c1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c24:	17fffaf3 	b	47f0 <fwp_mem_free>
    5c28:	d65f03c0 	ret
    5c2c:	d503201f 	nop

0000000000005c30 <fwp_tape_finish>:
    5c30:	d10203ff 	sub	sp, sp, #0x80
    5c34:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5c38:	f947f421 	ldr	x1, [x1, #4072]
    5c3c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5c40:	910103fd 	add	x29, sp, #0x40
    5c44:	a90553f3 	stp	x19, x20, [sp, #80]
    5c48:	a9065bf5 	stp	x21, x22, [sp, #96]
    5c4c:	a90763f7 	stp	x23, x24, [sp, #112]
    5c50:	f00000d8 	adrp	x24, 20000 <__data_start>
    5c54:	9100c316 	add	x22, x24, #0x30
    5c58:	f9400022 	ldr	x2, [x1]
    5c5c:	f9001fe2 	str	x2, [sp, #56]
    5c60:	d2800002 	mov	x2, #0x0                   	// #0
    5c64:	910122c0 	add	x0, x22, #0x48
    5c68:	97fff5a6 	bl	3300 <fwp_tape_buffers_dispose>
    5c6c:	f90042df 	str	xzr, [x22, #128]
    5c70:	f94022c0 	ldr	x0, [x22, #64]
    5c74:	f100001f 	cmp	x0, #0x0
    5c78:	5400030d 	b.le	5cd8 <fwp_tape_finish+0xa8>
    5c7c:	910003f7 	mov	x23, sp
    5c80:	d2800015 	mov	x21, #0x0                   	// #0
    5c84:	d2800014 	mov	x20, #0x0                   	// #0
    5c88:	f94002d3 	ldr	x19, [x22]
    5c8c:	91000694 	add	x20, x20, #0x1
    5c90:	8b150273 	add	x19, x19, x21
    5c94:	9101a2b5 	add	x21, x21, #0x68
    5c98:	aa1303e0 	mov	x0, x19
    5c9c:	97fff4bd 	bl	2f90 <fwp_tape_unlink_scope>
    5ca0:	aa1703e0 	mov	x0, x23
    5ca4:	f9401261 	ldr	x1, [x19, #32]
    5ca8:	f90003e1 	str	x1, [sp]
    5cac:	f9401a62 	ldr	x2, [x19, #48]
    5cb0:	f9000be2 	str	x2, [sp, #16]
    5cb4:	f9402261 	ldr	x1, [x19, #64]
    5cb8:	f90013e1 	str	x1, [sp, #32]
    5cbc:	97fff591 	bl	3300 <fwp_tape_buffers_dispose>
    5cc0:	f9403260 	ldr	x0, [x19, #96]
    5cc4:	97ffff8f 	bl	5b00 <fwp_owned_tape_release>
    5cc8:	f900327f 	str	xzr, [x19, #96]
    5ccc:	f94022c0 	ldr	x0, [x22, #64]
    5cd0:	eb14001f 	cmp	x0, x20
    5cd4:	54fffdac 	b.gt	5c88 <fwp_tape_finish+0x58>
    5cd8:	f9401b00 	ldr	x0, [x24, #48]
    5cdc:	9100c313 	add	x19, x24, #0x30
    5ce0:	97fff318 	bl	2940 <free@plt>
    5ce4:	f9001b1f 	str	xzr, [x24, #48]
    5ce8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5cec:	f947f400 	ldr	x0, [x0, #4072]
    5cf0:	f900227f 	str	xzr, [x19, #64]
    5cf4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5cf8:	f9401fe2 	ldr	x2, [sp, #56]
    5cfc:	f9400001 	ldr	x1, [x0]
    5d00:	eb010042 	subs	x2, x2, x1
    5d04:	d2800001 	mov	x1, #0x0                   	// #0
    5d08:	540000e1 	b.ne	5d24 <fwp_tape_finish+0xf4>  // b.any
    5d0c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5d10:	a94553f3 	ldp	x19, x20, [sp, #80]
    5d14:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5d18:	a94763f7 	ldp	x23, x24, [sp, #112]
    5d1c:	910203ff 	add	sp, sp, #0x80
    5d20:	d65f03c0 	ret
    5d24:	97fff2d7 	bl	2880 <__stack_chk_fail@plt>
    5d28:	d503201f 	nop
    5d2c:	d503201f 	nop

0000000000005d30 <fwp_tape_scope_release>:
    5d30:	d10243ff 	sub	sp, sp, #0x90
    5d34:	a9047bfd 	stp	x29, x30, [sp, #64]
    5d38:	910103fd 	add	x29, sp, #0x40
    5d3c:	a90553f3 	stp	x19, x20, [sp, #80]
    5d40:	aa0003f4 	mov	x20, x0
    5d44:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5d48:	f947f400 	ldr	x0, [x0, #4072]
    5d4c:	b9400285 	ldr	w5, [x20]
    5d50:	f9400001 	ldr	x1, [x0]
    5d54:	f9001fe1 	str	x1, [sp, #56]
    5d58:	d2800001 	mov	x1, #0x0                   	// #0
    5d5c:	37f806c5 	tbnz	w5, #31, 5e34 <fwp_tape_scope_release+0x104>
    5d60:	a90763f7 	stp	x23, x24, [sp, #112]
    5d64:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5d68:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5d6c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5d70:	f00000d3 	adrp	x19, 20000 <__data_start>
    5d74:	910003f7 	mov	x23, sp
    5d78:	9100c273 	add	x19, x19, #0x30
    5d7c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5d80:	a9065bf5 	stp	x21, x22, [sp, #96]
    5d84:	52800d16 	mov	w22, #0x68                  	// #104
    5d88:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5d8c:	f90043f9 	str	x25, [sp, #128]
    5d90:	14000006 	b	5da8 <fwp_tape_scope_release+0x78>
    5d94:	97fff55b 	bl	3300 <fwp_tape_buffers_dispose>
    5d98:	aa1903e0 	mov	x0, x25
    5d9c:	97ffff59 	bl	5b00 <fwp_owned_tape_release>
    5da0:	b9400285 	ldr	w5, [x20]
    5da4:	37f80425 	tbnz	w5, #31, 5e28 <fwp_tape_scope_release+0xf8>
    5da8:	f9400266 	ldr	x6, [x19]
    5dac:	9b367ca5 	smull	x5, w5, w22
    5db0:	8b0500c0 	add	x0, x6, x5
    5db4:	97fff477 	bl	2f90 <fwp_tape_unlink_scope>
    5db8:	ad410001 	ldp	q1, q0, [x0, #32]
    5dbc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5dc0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5dc4:	f9400c03 	ldr	x3, [x0, #24]
    5dc8:	ad0003e1 	stp	q1, q0, [sp]
    5dcc:	b86568c1 	ldr	w1, [x6, x5]
    5dd0:	a9440804 	ldp	x4, x2, [x0, #64]
    5dd4:	b900041f 	str	wzr, [x0, #4]
    5dd8:	f9403019 	ldr	x25, [x0, #96]
    5ddc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5de0:	f9000c1f 	str	xzr, [x0, #24]
    5de4:	a9020fe4 	stp	x4, x3, [sp, #32]
    5de8:	f9001be2 	str	x2, [sp, #48]
    5dec:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5df0:	f900301f 	str	xzr, [x0, #96]
    5df4:	6b15003f 	cmp	w1, w21
    5df8:	540000e8 	b.hi	5e14 <fwp_tape_scope_release+0xe4>  // b.pmore
    5dfc:	9343fca5 	asr	x5, x5, #3
    5e00:	f9404e60 	ldr	x0, [x19, #152]
    5e04:	9b187ca5 	mul	x5, x5, x24
    5e08:	eb0000bf 	cmp	x5, x0
    5e0c:	5400004a 	b.ge	5e14 <fwp_tape_scope_release+0xe4>  // b.tcont
    5e10:	f9004e65 	str	x5, [x19, #152]
    5e14:	aa1703e0 	mov	x0, x23
    5e18:	b5fffbf9 	cbnz	x25, 5d94 <fwp_tape_scope_release+0x64>
    5e1c:	97fff8b9 	bl	4100 <fwp_tape_buffers_release>
    5e20:	b9400285 	ldr	w5, [x20]
    5e24:	36fffc25 	tbz	w5, #31, 5da8 <fwp_tape_scope_release+0x78>
    5e28:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5e2c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5e30:	f94043f9 	ldr	x25, [sp, #128]
    5e34:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5e38:	f947f400 	ldr	x0, [x0, #4072]
    5e3c:	f9401fe2 	ldr	x2, [sp, #56]
    5e40:	f9400001 	ldr	x1, [x0]
    5e44:	eb010042 	subs	x2, x2, x1
    5e48:	d2800001 	mov	x1, #0x0                   	// #0
    5e4c:	540000a1 	b.ne	5e60 <fwp_tape_scope_release+0x130>  // b.any
    5e50:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5e54:	a94553f3 	ldp	x19, x20, [sp, #80]
    5e58:	910243ff 	add	sp, sp, #0x90
    5e5c:	d65f03c0 	ret
    5e60:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e64:	a90763f7 	stp	x23, x24, [sp, #112]
    5e68:	f90043f9 	str	x25, [sp, #128]
    5e6c:	97fff285 	bl	2880 <__stack_chk_fail@plt>

0000000000005e70 <fwp_drop4>:
    5e70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e74:	910003fd 	mov	x29, sp
    5e78:	a9025bf5 	stp	x21, x22, [sp, #32]
    5e7c:	90000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    5e80:	9114c2d5 	add	x21, x22, #0x530
    5e84:	a90153f3 	stp	x19, x20, [sp, #16]
    5e88:	aa0003f3 	mov	x19, x0
    5e8c:	f949daa1 	ldr	x1, [x21, #5040]
    5e90:	f949eea0 	ldr	x0, [x21, #5080]
    5e94:	cb010261 	sub	x1, x19, x1
    5e98:	eb00403f 	cmp	x1, x0, lsl #16
    5e9c:	54000382 	b.cs	5f0c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5ea0:	d350fc22 	lsr	x2, x1, #16
    5ea4:	f949fea3 	ldr	x3, [x21, #5112]
    5ea8:	8b020842 	add	x2, x2, x2, lsl #2
    5eac:	d37df042 	lsl	x2, x2, #3
    5eb0:	8b020060 	add	x0, x3, x2
    5eb4:	f9401014 	ldr	x20, [x0, #32]
    5eb8:	b40002b4 	cbz	x20, 5f0c <fwp_drop4+0x9c>
    5ebc:	38626862 	ldrb	w2, [x3, x2]
    5ec0:	7100085f 	cmp	w2, #0x2
    5ec4:	540002c0 	b.eq	5f1c <fwp_drop4+0xac>  // b.none
    5ec8:	7100045f 	cmp	w2, #0x1
    5ecc:	54000201 	b.ne	5f0c <fwp_drop4+0x9c>  // b.any
    5ed0:	29430002 	ldp	w2, w0, [x0, #24]
    5ed4:	92403c21 	and	x1, x1, #0xffff
    5ed8:	9b027c21 	mul	x1, x1, x2
    5edc:	d360fc21 	lsr	x1, x1, #32
    5ee0:	eb00003f 	cmp	x1, x0
    5ee4:	54000142 	b.cs	5f0c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5ee8:	8b010294 	add	x20, x20, x1
    5eec:	39400280 	ldrb	w0, [x20]
    5ef0:	340000e0 	cbz	w0, 5f0c <fwp_drop4+0x9c>
    5ef4:	7100041f 	cmp	w0, #0x1
    5ef8:	540001e0 	b.eq	5f34 <fwp_drop4+0xc4>  // b.none
    5efc:	7103fc1f 	cmp	w0, #0xff
    5f00:	540007c0 	b.eq	5ff8 <fwp_drop4+0x188>  // b.none
    5f04:	51000400 	sub	w0, w0, #0x1
    5f08:	39000280 	strb	w0, [x20]
    5f0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5f14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f18:	d65f03c0 	ret
    5f1c:	72003c3f 	tst	w1, #0xffff
    5f20:	54fffe60 	b.eq	5eec <fwp_drop4+0x7c>  // b.none
    5f24:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5f2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f30:	d65f03c0 	ret
    5f34:	9114c2c2 	add	x2, x22, #0x530
    5f38:	f9400660 	ldr	x0, [x19, #8]
    5f3c:	f949d841 	ldr	x1, [x2, #5040]
    5f40:	f949ec42 	ldr	x2, [x2, #5080]
    5f44:	cb010001 	sub	x1, x0, x1
    5f48:	eb02403f 	cmp	x1, x2, lsl #16
    5f4c:	54000362 	b.cs	5fb8 <fwp_drop4+0x148>  // b.hs, b.nlast
    5f50:	d350fc22 	lsr	x2, x1, #16
    5f54:	8b020842 	add	x2, x2, x2, lsl #2
    5f58:	d37df042 	lsl	x2, x2, #3
    5f5c:	8b020064 	add	x4, x3, x2
    5f60:	f9401094 	ldr	x20, [x4, #32]
    5f64:	b40002b4 	cbz	x20, 5fb8 <fwp_drop4+0x148>
    5f68:	38626862 	ldrb	w2, [x3, x2]
    5f6c:	7100085f 	cmp	w2, #0x2
    5f70:	540003e0 	b.eq	5fec <fwp_drop4+0x17c>  // b.none
    5f74:	7100045f 	cmp	w2, #0x1
    5f78:	54000201 	b.ne	5fb8 <fwp_drop4+0x148>  // b.any
    5f7c:	29430883 	ldp	w3, w2, [x4, #24]
    5f80:	92403c21 	and	x1, x1, #0xffff
    5f84:	9b037c21 	mul	x1, x1, x3
    5f88:	d360fc21 	lsr	x1, x1, #32
    5f8c:	eb02003f 	cmp	x1, x2
    5f90:	54000142 	b.cs	5fb8 <fwp_drop4+0x148>  // b.hs, b.nlast
    5f94:	8b010294 	add	x20, x20, x1
    5f98:	39400281 	ldrb	w1, [x20]
    5f9c:	340000e1 	cbz	w1, 5fb8 <fwp_drop4+0x148>
    5fa0:	7100043f 	cmp	w1, #0x1
    5fa4:	54000200 	b.eq	5fe4 <fwp_drop4+0x174>  // b.none
    5fa8:	7103fc3f 	cmp	w1, #0xff
    5fac:	54000580 	b.eq	605c <fwp_drop4+0x1ec>  // b.none
    5fb0:	51000421 	sub	w1, w1, #0x1
    5fb4:	39000281 	strb	w1, [x20]
    5fb8:	f9400a74 	ldr	x20, [x19, #16]
    5fbc:	aa1303e0 	mov	x0, x19
    5fc0:	97fffcfd 	bl	53b4 <fwp_rc_free_arr>
    5fc4:	9114c2c0 	add	x0, x22, #0x530
    5fc8:	f949d801 	ldr	x1, [x0, #5040]
    5fcc:	f949ec00 	ldr	x0, [x0, #5080]
    5fd0:	cb010281 	sub	x1, x20, x1
    5fd4:	eb00403f 	cmp	x1, x0, lsl #16
    5fd8:	54fff9a2 	b.cs	5f0c <fwp_drop4+0x9c>  // b.hs, b.nlast
    5fdc:	aa1403f3 	mov	x19, x20
    5fe0:	17ffffb0 	b	5ea0 <fwp_drop4+0x30>
    5fe4:	97fffcf4 	bl	53b4 <fwp_rc_free_arr>
    5fe8:	17fffff4 	b	5fb8 <fwp_drop4+0x148>
    5fec:	72003c3f 	tst	w1, #0xffff
    5ff0:	54fffe41 	b.ne	5fb8 <fwp_drop4+0x148>  // b.any
    5ff4:	17ffffe9 	b	5f98 <fwp_drop4+0x128>
    5ff8:	ca544681 	eor	x1, x20, x20, lsr #17
    5ffc:	9114c2c0 	add	x0, x22, #0x530
    6000:	ca412421 	eor	x1, x1, x1, lsr #9
    6004:	8b210c01 	add	x1, x0, w1, uxtb #3
    6008:	f94a2420 	ldr	x0, [x1, #5192]
    600c:	b5000080 	cbnz	x0, 601c <fwp_drop4+0x1ac>
    6010:	14000010 	b	6050 <fwp_drop4+0x1e0>
    6014:	f9400800 	ldr	x0, [x0, #16]
    6018:	b40001c0 	cbz	x0, 6050 <fwp_drop4+0x1e0>
    601c:	f9400001 	ldr	x1, [x0]
    6020:	eb14003f 	cmp	x1, x20
    6024:	54ffff81 	b.ne	6014 <fwp_drop4+0x1a4>  // b.any
    6028:	f9400401 	ldr	x1, [x0, #8]
    602c:	d1000421 	sub	x1, x1, #0x1
    6030:	f9000401 	str	x1, [x0, #8]
    6034:	f103f83f 	cmp	x1, #0xfe
    6038:	54fff6a1 	b.ne	5f0c <fwp_drop4+0x9c>  // b.any
    603c:	aa1403e0 	mov	x0, x20
    6040:	97fff94c 	bl	4570 <fwp_rc_forget_slot>
    6044:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6048:	39000280 	strb	w0, [x20]
    604c:	17ffffb0 	b	5f0c <fwp_drop4+0x9c>
    6050:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    6054:	9109e000 	add	x0, x0, #0x278
    6058:	97fff54a 	bl	3580 <fwp_trap>
    605c:	ca544680 	eor	x0, x20, x20, lsr #17
    6060:	9114c2c1 	add	x1, x22, #0x530
    6064:	ca402400 	eor	x0, x0, x0, lsr #9
    6068:	8b200c20 	add	x0, x1, w0, uxtb #3
    606c:	f94a2400 	ldr	x0, [x0, #5192]
    6070:	b5000080 	cbnz	x0, 6080 <fwp_drop4+0x210>
    6074:	17fffff7 	b	6050 <fwp_drop4+0x1e0>
    6078:	f9400800 	ldr	x0, [x0, #16]
    607c:	b4fffea0 	cbz	x0, 6050 <fwp_drop4+0x1e0>
    6080:	f9400001 	ldr	x1, [x0]
    6084:	eb14003f 	cmp	x1, x20
    6088:	54ffff81 	b.ne	6078 <fwp_drop4+0x208>  // b.any
    608c:	f9400401 	ldr	x1, [x0, #8]
    6090:	d1000421 	sub	x1, x1, #0x1
    6094:	f9000401 	str	x1, [x0, #8]
    6098:	f103f83f 	cmp	x1, #0xfe
    609c:	54fff8e1 	b.ne	5fb8 <fwp_drop4+0x148>  // b.any
    60a0:	aa1403e0 	mov	x0, x20
    60a4:	97fff933 	bl	4570 <fwp_rc_forget_slot>
    60a8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60ac:	39000280 	strb	w0, [x20]
    60b0:	17ffffc2 	b	5fb8 <fwp_drop4+0x148>

00000000000060b4 <fwp_arg_drop37>:
    60b4:	7100003f 	cmp	w1, #0x0
    60b8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    60bc:	54000041 	b.ne	60c4 <fwp_arg_drop37+0x10>  // b.any
    60c0:	d65f03c0 	ret
    60c4:	f9400000 	ldr	x0, [x0]
    60c8:	17ffff6a 	b	5e70 <fwp_drop4>
    60cc:	d503201f 	nop

00000000000060d0 <fwp_task_dispose>:
    60d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60d4:	910003fd 	mov	x29, sp
    60d8:	f9000bf3 	str	x19, [sp, #16]
    60dc:	aa0003f3 	mov	x19, x0
    60e0:	39414000 	ldrb	w0, [x0, #80]
    60e4:	36000720 	tbz	w0, #0, 61c8 <fwp_task_dispose+0xf8>
    60e8:	f9400a60 	ldr	x0, [x19, #16]
    60ec:	b50006e0 	cbnz	x0, 61c8 <fwp_task_dispose+0xf8>
    60f0:	a9478660 	ldp	x0, x1, [x19, #120]
    60f4:	39014e7f 	strb	wzr, [x19, #83]
    60f8:	f9003e7f 	str	xzr, [x19, #120]
    60fc:	f100003f 	cmp	x1, #0x0
    6100:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6104:	54000040 	b.eq	610c <fwp_task_dispose+0x3c>  // b.none
    6108:	d63f0020 	blr	x1
    610c:	f9405660 	ldr	x0, [x19, #168]
    6110:	97fff9b8 	bl	47f0 <fwp_mem_free>
    6114:	f900567f 	str	xzr, [x19, #168]
    6118:	b9405e60 	ldr	w0, [x19, #92]
    611c:	7100041f 	cmp	w0, #0x1
    6120:	54000420 	b.eq	61a4 <fwp_task_dispose+0xd4>  // b.none
    6124:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6128:	9114c042 	add	x2, x2, #0x530
    612c:	f949d840 	ldr	x0, [x2, #5040]
    6130:	f949ec41 	ldr	x1, [x2, #5080]
    6134:	cb000260 	sub	x0, x19, x0
    6138:	eb01401f 	cmp	x0, x1, lsl #16
    613c:	540002e2 	b.cs	6198 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6140:	d350fc01 	lsr	x1, x0, #16
    6144:	f949fc44 	ldr	x4, [x2, #5112]
    6148:	8b010821 	add	x1, x1, x1, lsl #2
    614c:	d37df021 	lsl	x1, x1, #3
    6150:	8b010083 	add	x3, x4, x1
    6154:	f9401062 	ldr	x2, [x3, #32]
    6158:	b4000202 	cbz	x2, 6198 <fwp_task_dispose+0xc8>
    615c:	38616881 	ldrb	w1, [x4, x1]
    6160:	7100083f 	cmp	w1, #0x2
    6164:	54000280 	b.eq	61b4 <fwp_task_dispose+0xe4>  // b.none
    6168:	7100043f 	cmp	w1, #0x1
    616c:	54000161 	b.ne	6198 <fwp_task_dispose+0xc8>  // b.any
    6170:	29430464 	ldp	w4, w1, [x3, #24]
    6174:	92403c00 	and	x0, x0, #0xffff
    6178:	9b047c00 	mul	x0, x0, x4
    617c:	d360fc00 	lsr	x0, x0, #32
    6180:	eb01001f 	cmp	x0, x1
    6184:	540000a2 	b.cs	6198 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6188:	8b000042 	add	x2, x2, x0
    618c:	39400040 	ldrb	w0, [x2]
    6190:	7100041f 	cmp	w0, #0x1
    6194:	54000080 	b.eq	61a4 <fwp_task_dispose+0xd4>  // b.none
    6198:	f9400bf3 	ldr	x19, [sp, #16]
    619c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61a0:	d65f03c0 	ret
    61a4:	aa1303e0 	mov	x0, x19
    61a8:	f9400bf3 	ldr	x19, [sp, #16]
    61ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61b0:	17fff990 	b	47f0 <fwp_mem_free>
    61b4:	72003c1f 	tst	w0, #0xffff
    61b8:	54fffea0 	b.eq	618c <fwp_task_dispose+0xbc>  // b.none
    61bc:	f9400bf3 	ldr	x19, [sp, #16]
    61c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c4:	d65f03c0 	ret
    61c8:	97fff1c2 	bl	28d0 <abort@plt>
    61cc:	d503201f 	nop

00000000000061d0 <fwp_free_zombie>:
    61d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61d4:	910003fd 	mov	x29, sp
    61d8:	a90153f3 	stp	x19, x20, [sp, #16]
    61dc:	d00000d4 	adrp	x20, 20000 <__data_start>
    61e0:	9100c281 	add	x1, x20, #0x30
    61e4:	f9405033 	ldr	x19, [x1, #160]
    61e8:	b4000333 	cbz	x19, 624c <fwp_free_zombie+0x7c>
    61ec:	f9400820 	ldr	x0, [x1, #16]
    61f0:	eb00027f 	cmp	x19, x0
    61f4:	540002c0 	b.eq	624c <fwp_free_zombie+0x7c>  // b.none
    61f8:	b940a822 	ldr	w2, [x1, #168]
    61fc:	f9400a60 	ldr	x0, [x19, #16]
    6200:	7100fc5f 	cmp	w2, #0x3f
    6204:	5400078c 	b.gt	62f4 <fwp_free_zombie+0x124>
    6208:	9102c023 	add	x3, x1, #0xb0
    620c:	11000444 	add	w4, w2, #0x1
    6210:	b900a824 	str	w4, [x1, #168]
    6214:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6218:	f822d860 	str	x0, [x3, w2, sxtw #3]
    621c:	a9530261 	ldp	x1, x0, [x19, #304]
    6220:	b4000741 	cbz	x1, 6308 <fwp_free_zombie+0x138>
    6224:	f9009c20 	str	x0, [x1, #312]
    6228:	b4000040 	cbz	x0, 6230 <fwp_free_zombie+0x60>
    622c:	f9009801 	str	x1, [x0, #304]
    6230:	9100c294 	add	x20, x20, #0x30
    6234:	b9405e60 	ldr	w0, [x19, #92]
    6238:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    623c:	f900529f 	str	xzr, [x20, #160]
    6240:	34000140 	cbz	w0, 6268 <fwp_free_zombie+0x98>
    6244:	7100041f 	cmp	w0, #0x1
    6248:	54000080 	b.eq	6258 <fwp_free_zombie+0x88>  // b.none
    624c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6250:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6254:	d65f03c0 	ret
    6258:	aa1303e0 	mov	x0, x19
    625c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6260:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6264:	17ffff9b 	b	60d0 <fwp_task_dispose>
    6268:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    626c:	9114c082 	add	x2, x4, #0x530
    6270:	f949d841 	ldr	x1, [x2, #5040]
    6274:	f949ec40 	ldr	x0, [x2, #5080]
    6278:	cb010261 	sub	x1, x19, x1
    627c:	eb00403f 	cmp	x1, x0, lsl #16
    6280:	54fffe62 	b.cs	624c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6284:	d350fc20 	lsr	x0, x1, #16
    6288:	f949fc43 	ldr	x3, [x2, #5112]
    628c:	8b000800 	add	x0, x0, x0, lsl #2
    6290:	d37df000 	lsl	x0, x0, #3
    6294:	8b000062 	add	x2, x3, x0
    6298:	f9401054 	ldr	x20, [x2, #32]
    629c:	b4fffd94 	cbz	x20, 624c <fwp_free_zombie+0x7c>
    62a0:	38606860 	ldrb	w0, [x3, x0]
    62a4:	7100081f 	cmp	w0, #0x2
    62a8:	54000360 	b.eq	6314 <fwp_free_zombie+0x144>  // b.none
    62ac:	7100041f 	cmp	w0, #0x1
    62b0:	54fffce1 	b.ne	624c <fwp_free_zombie+0x7c>  // b.any
    62b4:	29430043 	ldp	w3, w0, [x2, #24]
    62b8:	92403c21 	and	x1, x1, #0xffff
    62bc:	9b037c21 	mul	x1, x1, x3
    62c0:	d360fc21 	lsr	x1, x1, #32
    62c4:	eb00003f 	cmp	x1, x0
    62c8:	54fffc22 	b.cs	624c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    62cc:	8b010294 	add	x20, x20, x1
    62d0:	39400280 	ldrb	w0, [x20]
    62d4:	34fffbc0 	cbz	w0, 624c <fwp_free_zombie+0x7c>
    62d8:	7100041f 	cmp	w0, #0x1
    62dc:	54fffbe0 	b.eq	6258 <fwp_free_zombie+0x88>  // b.none
    62e0:	7103fc1f 	cmp	w0, #0xff
    62e4:	540001e0 	b.eq	6320 <fwp_free_zombie+0x150>  // b.none
    62e8:	51000400 	sub	w0, w0, #0x1
    62ec:	39000280 	strb	w0, [x20]
    62f0:	17ffffd7 	b	624c <fwp_free_zombie+0x7c>
    62f4:	f9400e61 	ldr	x1, [x19, #24]
    62f8:	97fff1aa 	bl	29a0 <munmap@plt>
    62fc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6300:	a9530261 	ldp	x1, x0, [x19, #304]
    6304:	b5fff901 	cbnz	x1, 6224 <fwp_free_zombie+0x54>
    6308:	9100c282 	add	x2, x20, #0x30
    630c:	f9015840 	str	x0, [x2, #688]
    6310:	17ffffc6 	b	6228 <fwp_free_zombie+0x58>
    6314:	72003c3f 	tst	w1, #0xffff
    6318:	54fff9a1 	b.ne	624c <fwp_free_zombie+0x7c>  // b.any
    631c:	17ffffed 	b	62d0 <fwp_free_zombie+0x100>
    6320:	ca544680 	eor	x0, x20, x20, lsr #17
    6324:	9114c084 	add	x4, x4, #0x530
    6328:	ca402400 	eor	x0, x0, x0, lsr #9
    632c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6330:	f94a2400 	ldr	x0, [x0, #5192]
    6334:	b5000080 	cbnz	x0, 6344 <fwp_free_zombie+0x174>
    6338:	14000010 	b	6378 <fwp_free_zombie+0x1a8>
    633c:	f9400800 	ldr	x0, [x0, #16]
    6340:	b40001c0 	cbz	x0, 6378 <fwp_free_zombie+0x1a8>
    6344:	f9400001 	ldr	x1, [x0]
    6348:	eb14003f 	cmp	x1, x20
    634c:	54ffff81 	b.ne	633c <fwp_free_zombie+0x16c>  // b.any
    6350:	f9400401 	ldr	x1, [x0, #8]
    6354:	d1000421 	sub	x1, x1, #0x1
    6358:	f9000401 	str	x1, [x0, #8]
    635c:	f103f83f 	cmp	x1, #0xfe
    6360:	54fff761 	b.ne	624c <fwp_free_zombie+0x7c>  // b.any
    6364:	aa1403e0 	mov	x0, x20
    6368:	97fff882 	bl	4570 <fwp_rc_forget_slot>
    636c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6370:	39000280 	strb	w0, [x20]
    6374:	17ffffb6 	b	624c <fwp_free_zombie+0x7c>
    6378:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    637c:	9109e000 	add	x0, x0, #0x278
    6380:	97fff480 	bl	3580 <fwp_trap>

0000000000006384 <fwp_block>:
    6384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6388:	910003fd 	mov	x29, sp
    638c:	a90153f3 	stp	x19, x20, [sp, #16]
    6390:	d00000d3 	adrp	x19, 20000 <__data_start>
    6394:	9100c274 	add	x20, x19, #0x30
    6398:	f9401a82 	ldr	x2, [x20, #48]
    639c:	b4000622 	cbz	x2, 6460 <fwp_block+0xdc>
    63a0:	9100c261 	add	x1, x19, #0x30
    63a4:	f9408040 	ldr	x0, [x2, #256]
    63a8:	f9001820 	str	x0, [x1, #48]
    63ac:	b4000680 	cbz	x0, 647c <fwp_block+0xf8>
    63b0:	9100c263 	add	x3, x19, #0x30
    63b4:	3901505f 	strb	wzr, [x2, #84]
    63b8:	f9400864 	ldr	x4, [x3, #16]
    63bc:	eb02009f 	cmp	x4, x2
    63c0:	54000440 	b.eq	6448 <fwp_block+0xc4>  // b.none
    63c4:	f9415c65 	ldr	x5, [x3, #696]
    63c8:	f9000862 	str	x2, [x3, #16]
    63cc:	f9400441 	ldr	x1, [x2, #8]
    63d0:	f9004885 	str	x5, [x4, #144]
    63d4:	f9416065 	ldr	x5, [x3, #704]
    63d8:	f9004c85 	str	x5, [x4, #152]
    63dc:	f9416465 	ldr	x5, [x3, #712]
    63e0:	f9005085 	str	x5, [x4, #160]
    63e4:	f9416865 	ldr	x5, [x3, #720]
    63e8:	f9005485 	str	x5, [x4, #168]
    63ec:	f9416c65 	ldr	x5, [x3, #728]
    63f0:	f9005885 	str	x5, [x4, #176]
    63f4:	f9417065 	ldr	x5, [x3, #736]
    63f8:	f9005c85 	str	x5, [x4, #184]
    63fc:	f9417465 	ldr	x5, [x3, #744]
    6400:	f9006085 	str	x5, [x4, #192]
    6404:	f9400480 	ldr	x0, [x4, #8]
    6408:	f9404844 	ldr	x4, [x2, #144]
    640c:	f9015c64 	str	x4, [x3, #696]
    6410:	f9404c44 	ldr	x4, [x2, #152]
    6414:	f9016064 	str	x4, [x3, #704]
    6418:	f9405044 	ldr	x4, [x2, #160]
    641c:	f9016464 	str	x4, [x3, #712]
    6420:	f9405444 	ldr	x4, [x2, #168]
    6424:	f9016864 	str	x4, [x3, #720]
    6428:	f9405844 	ldr	x4, [x2, #176]
    642c:	f9016c64 	str	x4, [x3, #728]
    6430:	a94b8844 	ldp	x4, x2, [x2, #184]
    6434:	f9017064 	str	x4, [x3, #736]
    6438:	f9017462 	str	x2, [x3, #744]
    643c:	97fff129 	bl	28e0 <swapcontext@plt>
    6440:	97ffff64 	bl	61d0 <fwp_free_zombie>
    6444:	d503201f 	nop
    6448:	9100c260 	add	x0, x19, #0x30
    644c:	b942f000 	ldr	w0, [x0, #752]
    6450:	340001a0 	cbz	w0, 6484 <fwp_block+0x100>
    6454:	a94153f3 	ldp	x19, x20, [sp, #16]
    6458:	a8c27bfd 	ldp	x29, x30, [sp], #32
    645c:	d65f03c0 	ret
    6460:	97fff770 	bl	4220 <fwp_poll_events>
    6464:	f9401a82 	ldr	x2, [x20, #48]
    6468:	b4ffffc2 	cbz	x2, 6460 <fwp_block+0xdc>
    646c:	9100c261 	add	x1, x19, #0x30
    6470:	f9408040 	ldr	x0, [x2, #256]
    6474:	f9001820 	str	x0, [x1, #48]
    6478:	b5fff9c0 	cbnz	x0, 63b0 <fwp_block+0x2c>
    647c:	f900143f 	str	xzr, [x1, #40]
    6480:	17ffffcc 	b	63b0 <fwp_block+0x2c>
    6484:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    6488:	910ea000 	add	x0, x0, #0x3a8
    648c:	97fff161 	bl	2a10 <getenv@plt>
    6490:	5284e202 	mov	w2, #0x2710                	// #10000
    6494:	b4000060 	cbz	x0, 64a0 <fwp_block+0x11c>
    6498:	39400001 	ldrb	w1, [x0]
    649c:	350000c1 	cbnz	w1, 64b4 <fwp_block+0x130>
    64a0:	9100c273 	add	x19, x19, #0x30
    64a4:	b902f262 	str	w2, [x19, #752]
    64a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    64ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64b0:	d65f03c0 	ret
    64b4:	52800142 	mov	w2, #0xa                   	// #10
    64b8:	d2800001 	mov	x1, #0x0                   	// #0
    64bc:	97fff0a5 	bl	2750 <strtoll@plt>
    64c0:	d1000403 	sub	x3, x0, #0x1
    64c4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    64c8:	eb02007f 	cmp	x3, x2
    64cc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    64d0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    64d4:	17fffff3 	b	64a0 <fwp_block+0x11c>
    64d8:	d503201f 	nop
    64dc:	d503201f 	nop

00000000000064e0 <fwp_drop10>:
    64e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    64e4:	910003fd 	mov	x29, sp
    64e8:	a90153f3 	stp	x19, x20, [sp, #16]
    64ec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    64f0:	f90013f5 	str	x21, [sp, #32]
    64f4:	9114c275 	add	x21, x19, #0x530
    64f8:	f949daa1 	ldr	x1, [x21, #5040]
    64fc:	f949eea2 	ldr	x2, [x21, #5080]
    6500:	cb010001 	sub	x1, x0, x1
    6504:	eb02403f 	cmp	x1, x2, lsl #16
    6508:	54000382 	b.cs	6578 <fwp_drop10+0x98>  // b.hs, b.nlast
    650c:	d350fc22 	lsr	x2, x1, #16
    6510:	f949fea3 	ldr	x3, [x21, #5112]
    6514:	8b020842 	add	x2, x2, x2, lsl #2
    6518:	d37df042 	lsl	x2, x2, #3
    651c:	8b020064 	add	x4, x3, x2
    6520:	f9401094 	ldr	x20, [x4, #32]
    6524:	b40002b4 	cbz	x20, 6578 <fwp_drop10+0x98>
    6528:	38626862 	ldrb	w2, [x3, x2]
    652c:	7100085f 	cmp	w2, #0x2
    6530:	540007a0 	b.eq	6624 <fwp_drop10+0x144>  // b.none
    6534:	7100045f 	cmp	w2, #0x1
    6538:	54000201 	b.ne	6578 <fwp_drop10+0x98>  // b.any
    653c:	29430885 	ldp	w5, w2, [x4, #24]
    6540:	92403c21 	and	x1, x1, #0xffff
    6544:	9b057c21 	mul	x1, x1, x5
    6548:	d360fc21 	lsr	x1, x1, #32
    654c:	eb02003f 	cmp	x1, x2
    6550:	54000142 	b.cs	6578 <fwp_drop10+0x98>  // b.hs, b.nlast
    6554:	8b010294 	add	x20, x20, x1
    6558:	39400281 	ldrb	w1, [x20]
    655c:	340000e1 	cbz	w1, 6578 <fwp_drop10+0x98>
    6560:	7100043f 	cmp	w1, #0x1
    6564:	54000120 	b.eq	6588 <fwp_drop10+0xa8>  // b.none
    6568:	7103fc3f 	cmp	w1, #0xff
    656c:	540007c0 	b.eq	6664 <fwp_drop10+0x184>  // b.none
    6570:	51000421 	sub	w1, w1, #0x1
    6574:	39000281 	strb	w1, [x20]
    6578:	a94153f3 	ldp	x19, x20, [sp, #16]
    657c:	f94013f5 	ldr	x21, [sp, #32]
    6580:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6584:	d65f03c0 	ret
    6588:	f9400001 	ldr	x1, [x0]
    658c:	b7f80581 	tbnz	x1, #63, 663c <fwp_drop10+0x15c>
    6590:	9114c273 	add	x19, x19, #0x530
    6594:	f949da61 	ldr	x1, [x19, #5040]
    6598:	f949ee62 	ldr	x2, [x19, #5080]
    659c:	cb010001 	sub	x1, x0, x1
    65a0:	eb02403f 	cmp	x1, x2, lsl #16
    65a4:	54fffea2 	b.cs	6578 <fwp_drop10+0x98>  // b.hs, b.nlast
    65a8:	d350fc22 	lsr	x2, x1, #16
    65ac:	8b020842 	add	x2, x2, x2, lsl #2
    65b0:	d37df042 	lsl	x2, x2, #3
    65b4:	8b020065 	add	x5, x3, x2
    65b8:	f94010a4 	ldr	x4, [x5, #32]
    65bc:	b4fffde4 	cbz	x4, 6578 <fwp_drop10+0x98>
    65c0:	38626862 	ldrb	w2, [x3, x2]
    65c4:	7100085f 	cmp	w2, #0x2
    65c8:	54000220 	b.eq	660c <fwp_drop10+0x12c>  // b.none
    65cc:	7100045f 	cmp	w2, #0x1
    65d0:	54fffd41 	b.ne	6578 <fwp_drop10+0x98>  // b.any
    65d4:	294308a3 	ldp	w3, w2, [x5, #24]
    65d8:	92403c21 	and	x1, x1, #0xffff
    65dc:	9b037c21 	mul	x1, x1, x3
    65e0:	d360fc21 	lsr	x1, x1, #32
    65e4:	eb02003f 	cmp	x1, x2
    65e8:	54fffc82 	b.cs	6578 <fwp_drop10+0x98>  // b.hs, b.nlast
    65ec:	8b010084 	add	x4, x4, x1
    65f0:	39400081 	ldrb	w1, [x4]
    65f4:	7100043f 	cmp	w1, #0x1
    65f8:	54fffc01 	b.ne	6578 <fwp_drop10+0x98>  // b.any
    65fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6600:	f94013f5 	ldr	x21, [sp, #32]
    6604:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6608:	17fff87a 	b	47f0 <fwp_mem_free>
    660c:	72003c3f 	tst	w1, #0xffff
    6610:	54ffff00 	b.eq	65f0 <fwp_drop10+0x110>  // b.none
    6614:	a94153f3 	ldp	x19, x20, [sp, #16]
    6618:	f94013f5 	ldr	x21, [sp, #32]
    661c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6620:	d65f03c0 	ret
    6624:	72003c3f 	tst	w1, #0xffff
    6628:	54fff980 	b.eq	6558 <fwp_drop10+0x78>  // b.none
    662c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6630:	f94013f5 	ldr	x21, [sp, #32]
    6634:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6638:	d65f03c0 	ret
    663c:	f9400414 	ldr	x20, [x0, #8]
    6640:	97fffb5d 	bl	53b4 <fwp_rc_free_arr>
    6644:	9114c260 	add	x0, x19, #0x530
    6648:	f949d801 	ldr	x1, [x0, #5040]
    664c:	f949ec00 	ldr	x0, [x0, #5080]
    6650:	cb010281 	sub	x1, x20, x1
    6654:	eb00403f 	cmp	x1, x0, lsl #16
    6658:	54fff902 	b.cs	6578 <fwp_drop10+0x98>  // b.hs, b.nlast
    665c:	aa1403e0 	mov	x0, x20
    6660:	17ffffab 	b	650c <fwp_drop10+0x2c>
    6664:	ca544680 	eor	x0, x20, x20, lsr #17
    6668:	9114c273 	add	x19, x19, #0x530
    666c:	ca402400 	eor	x0, x0, x0, lsr #9
    6670:	8b200e60 	add	x0, x19, w0, uxtb #3
    6674:	f94a2400 	ldr	x0, [x0, #5192]
    6678:	b5000080 	cbnz	x0, 6688 <fwp_drop10+0x1a8>
    667c:	14000010 	b	66bc <fwp_drop10+0x1dc>
    6680:	f9400800 	ldr	x0, [x0, #16]
    6684:	b40001c0 	cbz	x0, 66bc <fwp_drop10+0x1dc>
    6688:	f9400001 	ldr	x1, [x0]
    668c:	eb14003f 	cmp	x1, x20
    6690:	54ffff81 	b.ne	6680 <fwp_drop10+0x1a0>  // b.any
    6694:	f9400401 	ldr	x1, [x0, #8]
    6698:	d1000421 	sub	x1, x1, #0x1
    669c:	f9000401 	str	x1, [x0, #8]
    66a0:	f103f83f 	cmp	x1, #0xfe
    66a4:	54fff6a1 	b.ne	6578 <fwp_drop10+0x98>  // b.any
    66a8:	aa1403e0 	mov	x0, x20
    66ac:	97fff7b1 	bl	4570 <fwp_rc_forget_slot>
    66b0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    66b4:	39000280 	strb	w0, [x20]
    66b8:	17ffffb0 	b	6578 <fwp_drop10+0x98>
    66bc:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    66c0:	9109e000 	add	x0, x0, #0x278
    66c4:	97fff3af 	bl	3580 <fwp_trap>
    66c8:	d503201f 	nop
    66cc:	d503201f 	nop

00000000000066d0 <fwp_caps173>:
    66d0:	34000041 	cbz	w1, 66d8 <fwp_caps173+0x8>
    66d4:	d65f03c0 	ret
    66d8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    66dc:	9114c063 	add	x3, x3, #0x530
    66e0:	f949d861 	ldr	x1, [x3, #5040]
    66e4:	f949ec62 	ldr	x2, [x3, #5080]
    66e8:	cb010001 	sub	x1, x0, x1
    66ec:	eb02403f 	cmp	x1, x2, lsl #16
    66f0:	54ffff22 	b.cs	66d4 <fwp_caps173+0x4>  // b.hs, b.nlast
    66f4:	d350fc22 	lsr	x2, x1, #16
    66f8:	f949fc65 	ldr	x5, [x3, #5112]
    66fc:	8b020842 	add	x2, x2, x2, lsl #2
    6700:	d37df042 	lsl	x2, x2, #3
    6704:	8b0200a4 	add	x4, x5, x2
    6708:	f9401083 	ldr	x3, [x4, #32]
    670c:	b4fffe43 	cbz	x3, 66d4 <fwp_caps173+0x4>
    6710:	386268a2 	ldrb	w2, [x5, x2]
    6714:	7100085f 	cmp	w2, #0x2
    6718:	540001c0 	b.eq	6750 <fwp_caps173+0x80>  // b.none
    671c:	7100045f 	cmp	w2, #0x1
    6720:	54fffda1 	b.ne	66d4 <fwp_caps173+0x4>  // b.any
    6724:	29430885 	ldp	w5, w2, [x4, #24]
    6728:	92403c21 	and	x1, x1, #0xffff
    672c:	9b057c21 	mul	x1, x1, x5
    6730:	d360fc21 	lsr	x1, x1, #32
    6734:	eb02003f 	cmp	x1, x2
    6738:	54fffce2 	b.cs	66d4 <fwp_caps173+0x4>  // b.hs, b.nlast
    673c:	8b010063 	add	x3, x3, x1
    6740:	39400061 	ldrb	w1, [x3]
    6744:	7100043f 	cmp	w1, #0x1
    6748:	54fffc61 	b.ne	66d4 <fwp_caps173+0x4>  // b.any
    674c:	17fff829 	b	47f0 <fwp_mem_free>
    6750:	72003c3f 	tst	w1, #0xffff
    6754:	54ffff60 	b.eq	6740 <fwp_caps173+0x70>  // b.none
    6758:	d65f03c0 	ret
    675c:	d503201f 	nop

0000000000006760 <f37>:
    6760:	d101c3ff 	sub	sp, sp, #0x70
    6764:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6768:	f947f421 	ldr	x1, [x1, #4072]
    676c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6770:	910083fd 	add	x29, sp, #0x20
    6774:	a90563f7 	stp	x23, x24, [sp, #80]
    6778:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xcb0>
    677c:	9114c2e3 	add	x3, x23, #0x530
    6780:	a90353f3 	stp	x19, x20, [sp, #48]
    6784:	a9045bf5 	stp	x21, x22, [sp, #64]
    6788:	aa0003f6 	mov	x22, x0
    678c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6790:	f949ec62 	ldr	x2, [x3, #5080]
    6794:	f9400024 	ldr	x4, [x1]
    6798:	f9000fe4 	str	x4, [sp, #24]
    679c:	d2800004 	mov	x4, #0x0                   	// #0
    67a0:	f949d861 	ldr	x1, [x3, #5040]
    67a4:	d370bc42 	lsl	x2, x2, #16
    67a8:	b40015c0 	cbz	x0, 6a60 <f37+0x300>
    67ac:	f9400818 	ldr	x24, [x0, #16]
    67b0:	cb010301 	sub	x1, x24, x1
    67b4:	eb02003f 	cmp	x1, x2
    67b8:	54000362 	b.cs	6824 <f37+0xc4>  // b.hs, b.nlast
    67bc:	f949fc60 	ldr	x0, [x3, #5112]
    67c0:	d350fc22 	lsr	x2, x1, #16
    67c4:	8b020842 	add	x2, x2, x2, lsl #2
    67c8:	8b020c02 	add	x2, x0, x2, lsl #3
    67cc:	f9401040 	ldr	x0, [x2, #32]
    67d0:	b40002a0 	cbz	x0, 6824 <f37+0xc4>
    67d4:	39400043 	ldrb	w3, [x2]
    67d8:	7100087f 	cmp	w3, #0x2
    67dc:	540013c0 	b.eq	6a54 <f37+0x2f4>  // b.none
    67e0:	7100047f 	cmp	w3, #0x1
    67e4:	540001c1 	b.ne	681c <f37+0xbc>  // b.any
    67e8:	29430843 	ldp	w3, w2, [x2, #24]
    67ec:	92403c21 	and	x1, x1, #0xffff
    67f0:	9b037c21 	mul	x1, x1, x3
    67f4:	d360fc21 	lsr	x1, x1, #32
    67f8:	eb02003f 	cmp	x1, x2
    67fc:	54000102 	b.cs	681c <f37+0xbc>  // b.hs, b.nlast
    6800:	8b010000 	add	x0, x0, x1
    6804:	39400001 	ldrb	w1, [x0]
    6808:	340000a1 	cbz	w1, 681c <f37+0xbc>
    680c:	7103f43f 	cmp	w1, #0xfd
    6810:	540016a8 	b.hi	6ae4 <f37+0x384>  // b.pmore
    6814:	11000421 	add	w1, w1, #0x1
    6818:	39000001 	strb	w1, [x0]
    681c:	d2800000 	mov	x0, #0x0                   	// #0
    6820:	b40000f6 	cbz	x22, 683c <f37+0xdc>
    6824:	aa1603e1 	mov	x1, x22
    6828:	d2800000 	mov	x0, #0x0                   	// #0
    682c:	d503201f 	nop
    6830:	f9400821 	ldr	x1, [x1, #16]
    6834:	91000400 	add	x0, x0, #0x1
    6838:	b5ffffc1 	cbnz	x1, 6830 <f37+0xd0>
    683c:	b40011b8 	cbz	x24, 6a70 <f37+0x310>
    6840:	aa1803e1 	mov	x1, x24
    6844:	d2800002 	mov	x2, #0x0                   	// #0
    6848:	f9400821 	ldr	x1, [x1, #16]
    684c:	91000442 	add	x2, x2, #0x1
    6850:	b5ffffc1 	cbnz	x1, 6848 <f37+0xe8>
    6854:	eb00005f 	cmp	x2, x0
    6858:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    685c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6860:	eb01033f 	cmp	x25, x1
    6864:	54001468 	b.hi	6af0 <f37+0x390>  // b.pmore
    6868:	d37ffb33 	lsl	x19, x25, #1
    686c:	52800041 	mov	w1, #0x2                   	// #2
    6870:	91000660 	add	x0, x19, #0x1
    6874:	d37df000 	lsl	x0, x0, #3
    6878:	97fff8fe 	bl	4c70 <fwp_heap_alloc>
    687c:	9114c2e1 	add	x1, x23, #0x530
    6880:	aa0003fa 	mov	x26, x0
    6884:	f9000013 	str	x19, [x0]
    6888:	aa0103e0 	mov	x0, x1
    688c:	f949d821 	ldr	x1, [x1, #5040]
    6890:	f949ec00 	ldr	x0, [x0, #5080]
    6894:	cb010341 	sub	x1, x26, x1
    6898:	eb00403f 	cmp	x1, x0, lsl #16
    689c:	54000342 	b.cs	6904 <f37+0x1a4>  // b.hs, b.nlast
    68a0:	9114c2e2 	add	x2, x23, #0x530
    68a4:	d350fc20 	lsr	x0, x1, #16
    68a8:	8b000800 	add	x0, x0, x0, lsl #2
    68ac:	f949fc43 	ldr	x3, [x2, #5112]
    68b0:	d37df002 	lsl	x2, x0, #3
    68b4:	8b020060 	add	x0, x3, x2
    68b8:	f9401013 	ldr	x19, [x0, #32]
    68bc:	b4000253 	cbz	x19, 6904 <f37+0x1a4>
    68c0:	38626862 	ldrb	w2, [x3, x2]
    68c4:	7100085f 	cmp	w2, #0x2
    68c8:	54000c00 	b.eq	6a48 <f37+0x2e8>  // b.none
    68cc:	7100045f 	cmp	w2, #0x1
    68d0:	540001a1 	b.ne	6904 <f37+0x1a4>  // b.any
    68d4:	29430002 	ldp	w2, w0, [x0, #24]
    68d8:	92403c21 	and	x1, x1, #0xffff
    68dc:	9b027c21 	mul	x1, x1, x2
    68e0:	d360fc21 	lsr	x1, x1, #32
    68e4:	eb00003f 	cmp	x1, x0
    68e8:	540000e2 	b.cs	6904 <f37+0x1a4>  // b.hs, b.nlast
    68ec:	8b010273 	add	x19, x19, x1
    68f0:	39400260 	ldrb	w0, [x19]
    68f4:	7103fc1f 	cmp	w0, #0xff
    68f8:	54000da0 	b.eq	6aac <f37+0x34c>  // b.none
    68fc:	52800020 	mov	w0, #0x1                   	// #1
    6900:	39000260 	strb	w0, [x19]
    6904:	b4000259 	cbz	x25, 694c <f37+0x1ec>
    6908:	8b191359 	add	x25, x26, x25, lsl #4
    690c:	aa1a03f3 	mov	x19, x26
    6910:	aa1603f5 	mov	x21, x22
    6914:	aa1803f4 	mov	x20, x24
    6918:	f9400683 	ldr	x3, [x20, #8]
    691c:	f94006a2 	ldr	x2, [x21, #8]
    6920:	f9400861 	ldr	x1, [x3, #16]
    6924:	f9400840 	ldr	x0, [x2, #16]
    6928:	fd400461 	ldr	d1, [x3, #8]
    692c:	fd400440 	ldr	d0, [x2, #8]
    6930:	97fffa10 	bl	5170 <w120>
    6934:	f9000660 	str	x0, [x19, #8]
    6938:	f8010e61 	str	x1, [x19, #16]!
    693c:	f9400a94 	ldr	x20, [x20, #16]
    6940:	f9400ab5 	ldr	x21, [x21, #16]
    6944:	eb13033f 	cmp	x25, x19
    6948:	54fffe81 	b.ne	6918 <f37+0x1b8>  // b.any
    694c:	aa1803e0 	mov	x0, x24
    6950:	97fffd48 	bl	5e70 <fwp_drop4>
    6954:	aa1603e0 	mov	x0, x22
    6958:	97fffd46 	bl	5e70 <fwp_drop4>
    695c:	9114c2f7 	add	x23, x23, #0x530
    6960:	aa1a03e0 	mov	x0, x26
    6964:	97fffa47 	bl	5280 <w176.constprop.0>
    6968:	aa0103f3 	mov	x19, x1
    696c:	aa0003f4 	mov	x20, x0
    6970:	aa1a03e0 	mov	x0, x26
    6974:	97fffedb 	bl	64e0 <fwp_drop10>
    6978:	a900cff4 	stp	x20, x19, [sp, #8]
    697c:	910023e1 	add	x1, sp, #0x8
    6980:	52800000 	mov	w0, #0x0                   	// #0
    6984:	97fff900 	bl	4d84 <fwp_data.part.0.constprop.0>
    6988:	f949dae1 	ldr	x1, [x23, #5040]
    698c:	aa0003f3 	mov	x19, x0
    6990:	f949eee0 	ldr	x0, [x23, #5080]
    6994:	cb010261 	sub	x1, x19, x1
    6998:	eb00403f 	cmp	x1, x0, lsl #16
    699c:	54000322 	b.cs	6a00 <f37+0x2a0>  // b.hs, b.nlast
    69a0:	d350fc22 	lsr	x2, x1, #16
    69a4:	f949fee3 	ldr	x3, [x23, #5112]
    69a8:	8b020842 	add	x2, x2, x2, lsl #2
    69ac:	d37df042 	lsl	x2, x2, #3
    69b0:	8b020060 	add	x0, x3, x2
    69b4:	f9401014 	ldr	x20, [x0, #32]
    69b8:	b4000254 	cbz	x20, 6a00 <f37+0x2a0>
    69bc:	38626862 	ldrb	w2, [x3, x2]
    69c0:	7100085f 	cmp	w2, #0x2
    69c4:	540003c0 	b.eq	6a3c <f37+0x2dc>  // b.none
    69c8:	7100045f 	cmp	w2, #0x1
    69cc:	540001a1 	b.ne	6a00 <f37+0x2a0>  // b.any
    69d0:	29430002 	ldp	w2, w0, [x0, #24]
    69d4:	92403c21 	and	x1, x1, #0xffff
    69d8:	9b027c21 	mul	x1, x1, x2
    69dc:	d360fc21 	lsr	x1, x1, #32
    69e0:	eb00003f 	cmp	x1, x0
    69e4:	540000e2 	b.cs	6a00 <f37+0x2a0>  // b.hs, b.nlast
    69e8:	8b010294 	add	x20, x20, x1
    69ec:	39400280 	ldrb	w0, [x20]
    69f0:	7103fc1f 	cmp	w0, #0xff
    69f4:	54000620 	b.eq	6ab8 <f37+0x358>  // b.none
    69f8:	52800020 	mov	w0, #0x1                   	// #1
    69fc:	39000280 	strb	w0, [x20]
    6a00:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6a04:	f947f400 	ldr	x0, [x0, #4072]
    6a08:	f9400fe2 	ldr	x2, [sp, #24]
    6a0c:	f9400001 	ldr	x1, [x0]
    6a10:	eb010042 	subs	x2, x2, x1
    6a14:	d2800001 	mov	x1, #0x0                   	// #0
    6a18:	540006a1 	b.ne	6aec <f37+0x38c>  // b.any
    6a1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6a20:	aa1303e0 	mov	x0, x19
    6a24:	a94353f3 	ldp	x19, x20, [sp, #48]
    6a28:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6a2c:	a94563f7 	ldp	x23, x24, [sp, #80]
    6a30:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6a34:	9101c3ff 	add	sp, sp, #0x70
    6a38:	d65f03c0 	ret
    6a3c:	72003c3f 	tst	w1, #0xffff
    6a40:	54fffe01 	b.ne	6a00 <f37+0x2a0>  // b.any
    6a44:	17ffffea 	b	69ec <f37+0x28c>
    6a48:	72003c3f 	tst	w1, #0xffff
    6a4c:	54fff5c1 	b.ne	6904 <f37+0x1a4>  // b.any
    6a50:	17ffffa8 	b	68f0 <f37+0x190>
    6a54:	72003c3f 	tst	w1, #0xffff
    6a58:	54ffee21 	b.ne	681c <f37+0xbc>  // b.any
    6a5c:	17ffff6a 	b	6804 <f37+0xa4>
    6a60:	cb0103e1 	neg	x1, x1
    6a64:	eb02003f 	cmp	x1, x2
    6a68:	540002e3 	b.cc	6ac4 <f37+0x364>  // b.lo, b.ul, b.last
    6a6c:	d503201f 	nop
    6a70:	52800041 	mov	w1, #0x2                   	// #2
    6a74:	d2800100 	mov	x0, #0x8                   	// #8
    6a78:	97fff87e 	bl	4c70 <fwp_heap_alloc>
    6a7c:	aa0003e1 	mov	x1, x0
    6a80:	9114c2e0 	add	x0, x23, #0x530
    6a84:	aa0103fa 	mov	x26, x1
    6a88:	d2800018 	mov	x24, #0x0                   	// #0
    6a8c:	f900003f 	str	xzr, [x1]
    6a90:	f949d801 	ldr	x1, [x0, #5040]
    6a94:	f949ec00 	ldr	x0, [x0, #5080]
    6a98:	cb010341 	sub	x1, x26, x1
    6a9c:	eb00403f 	cmp	x1, x0, lsl #16
    6aa0:	54fff562 	b.cs	694c <f37+0x1ec>  // b.hs, b.nlast
    6aa4:	d2800019 	mov	x25, #0x0                   	// #0
    6aa8:	17ffff7e 	b	68a0 <f37+0x140>
    6aac:	aa1303e0 	mov	x0, x19
    6ab0:	97fff6b0 	bl	4570 <fwp_rc_forget_slot>
    6ab4:	17ffff92 	b	68fc <f37+0x19c>
    6ab8:	aa1403e0 	mov	x0, x20
    6abc:	97fff6ad 	bl	4570 <fwp_rc_forget_slot>
    6ac0:	17ffffce 	b	69f8 <f37+0x298>
    6ac4:	f949fc62 	ldr	x2, [x3, #5112]
    6ac8:	d350fc20 	lsr	x0, x1, #16
    6acc:	8b000800 	add	x0, x0, x0, lsl #2
    6ad0:	8b000c42 	add	x2, x2, x0, lsl #3
    6ad4:	f9401040 	ldr	x0, [x2, #32]
    6ad8:	b4fffcc0 	cbz	x0, 6a70 <f37+0x310>
    6adc:	d2800018 	mov	x24, #0x0                   	// #0
    6ae0:	17ffff3d 	b	67d4 <f37+0x74>
    6ae4:	97fff65c 	bl	4454 <fwp_rc_wide_dup>
    6ae8:	17ffff4d 	b	681c <f37+0xbc>
    6aec:	97ffef65 	bl	2880 <__stack_chk_fail@plt>
    6af0:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    6af4:	910ee000 	add	x0, x0, #0x3b8
    6af8:	97fff2a2 	bl	3580 <fwp_trap>
    6afc:	d503201f 	nop

0000000000006b00 <fwp_owned_entry37>:
    6b00:	f9400000 	ldr	x0, [x0]
    6b04:	17ffff17 	b	6760 <f37>
    6b08:	d503201f 	nop
    6b0c:	d503201f 	nop

0000000000006b10 <e37>:
    6b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b14:	910003fd 	mov	x29, sp
    6b18:	f9000bf3 	str	x19, [sp, #16]
    6b1c:	f9400013 	ldr	x19, [x0]
    6b20:	aa1303e0 	mov	x0, x19
    6b24:	97fff9ff 	bl	5320 <fwp_rc_share>
    6b28:	aa1303e0 	mov	x0, x19
    6b2c:	97ffff0d 	bl	6760 <f37>
    6b30:	aa0003f3 	mov	x19, x0
    6b34:	97fff9fb 	bl	5320 <fwp_rc_share>
    6b38:	aa1303e0 	mov	x0, x19
    6b3c:	f9400bf3 	ldr	x19, [sp, #16]
    6b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b44:	d65f03c0 	ret
    6b48:	d503201f 	nop
    6b4c:	d503201f 	nop

0000000000006b50 <fwp_args37>:
    6b50:	7100003f 	cmp	w1, #0x0
    6b54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b58:	54000041 	b.ne	6b60 <fwp_args37+0x10>  // b.any
    6b5c:	d65f03c0 	ret
    6b60:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6b64:	9114c042 	add	x2, x2, #0x530
    6b68:	f9400001 	ldr	x1, [x0]
    6b6c:	f949d843 	ldr	x3, [x2, #5040]
    6b70:	f949ec40 	ldr	x0, [x2, #5080]
    6b74:	cb030021 	sub	x1, x1, x3
    6b78:	eb00403f 	cmp	x1, x0, lsl #16
    6b7c:	54ffff02 	b.cs	6b5c <fwp_args37+0xc>  // b.hs, b.nlast
    6b80:	d350fc20 	lsr	x0, x1, #16
    6b84:	f949fc44 	ldr	x4, [x2, #5112]
    6b88:	8b000800 	add	x0, x0, x0, lsl #2
    6b8c:	d37df002 	lsl	x2, x0, #3
    6b90:	8b020083 	add	x3, x4, x2
    6b94:	f9401060 	ldr	x0, [x3, #32]
    6b98:	b4fffe20 	cbz	x0, 6b5c <fwp_args37+0xc>
    6b9c:	38626882 	ldrb	w2, [x4, x2]
    6ba0:	7100085f 	cmp	w2, #0x2
    6ba4:	54000220 	b.eq	6be8 <fwp_args37+0x98>  // b.none
    6ba8:	7100045f 	cmp	w2, #0x1
    6bac:	54fffd81 	b.ne	6b5c <fwp_args37+0xc>  // b.any
    6bb0:	29430864 	ldp	w4, w2, [x3, #24]
    6bb4:	92403c21 	and	x1, x1, #0xffff
    6bb8:	9b047c21 	mul	x1, x1, x4
    6bbc:	d360fc21 	lsr	x1, x1, #32
    6bc0:	eb02003f 	cmp	x1, x2
    6bc4:	54fffcc2 	b.cs	6b5c <fwp_args37+0xc>  // b.hs, b.nlast
    6bc8:	8b010000 	add	x0, x0, x1
    6bcc:	39400001 	ldrb	w1, [x0]
    6bd0:	34fffc61 	cbz	w1, 6b5c <fwp_args37+0xc>
    6bd4:	7103f43f 	cmp	w1, #0xfd
    6bd8:	540000e8 	b.hi	6bf4 <fwp_args37+0xa4>  // b.pmore
    6bdc:	11000421 	add	w1, w1, #0x1
    6be0:	39000001 	strb	w1, [x0]
    6be4:	d65f03c0 	ret
    6be8:	72003c3f 	tst	w1, #0xffff
    6bec:	54ffff00 	b.eq	6bcc <fwp_args37+0x7c>  // b.none
    6bf0:	d65f03c0 	ret
    6bf4:	17fff618 	b	4454 <fwp_rc_wide_dup>
    6bf8:	d503201f 	nop
    6bfc:	d503201f 	nop

0000000000006c00 <fwp_caps37>:
    6c00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c04:	910003fd 	mov	x29, sp
    6c08:	f9000bf3 	str	x19, [sp, #16]
    6c0c:	aa0003f3 	mov	x19, x0
    6c10:	b9400400 	ldr	w0, [x0, #4]
    6c14:	340004a0 	cbz	w0, 6ca8 <fwp_caps37+0xa8>
    6c18:	f9400660 	ldr	x0, [x19, #8]
    6c1c:	350004e1 	cbnz	w1, 6cb8 <fwp_caps37+0xb8>
    6c20:	97fffc94 	bl	5e70 <fwp_drop4>
    6c24:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6c28:	9114c042 	add	x2, x2, #0x530
    6c2c:	f949d840 	ldr	x0, [x2, #5040]
    6c30:	f949ec41 	ldr	x1, [x2, #5080]
    6c34:	cb000260 	sub	x0, x19, x0
    6c38:	eb01401f 	cmp	x0, x1, lsl #16
    6c3c:	54000382 	b.cs	6cac <fwp_caps37+0xac>  // b.hs, b.nlast
    6c40:	d350fc01 	lsr	x1, x0, #16
    6c44:	f949fc44 	ldr	x4, [x2, #5112]
    6c48:	8b010821 	add	x1, x1, x1, lsl #2
    6c4c:	d37df021 	lsl	x1, x1, #3
    6c50:	8b010083 	add	x3, x4, x1
    6c54:	f9401062 	ldr	x2, [x3, #32]
    6c58:	b40002a2 	cbz	x2, 6cac <fwp_caps37+0xac>
    6c5c:	38616881 	ldrb	w1, [x4, x1]
    6c60:	7100083f 	cmp	w1, #0x2
    6c64:	540006c0 	b.eq	6d3c <fwp_caps37+0x13c>  // b.none
    6c68:	7100043f 	cmp	w1, #0x1
    6c6c:	54000201 	b.ne	6cac <fwp_caps37+0xac>  // b.any
    6c70:	29430464 	ldp	w4, w1, [x3, #24]
    6c74:	92403c00 	and	x0, x0, #0xffff
    6c78:	9b047c00 	mul	x0, x0, x4
    6c7c:	d360fc00 	lsr	x0, x0, #32
    6c80:	eb01001f 	cmp	x0, x1
    6c84:	54000142 	b.cs	6cac <fwp_caps37+0xac>  // b.hs, b.nlast
    6c88:	8b000042 	add	x2, x2, x0
    6c8c:	39400040 	ldrb	w0, [x2]
    6c90:	7100041f 	cmp	w0, #0x1
    6c94:	540000c1 	b.ne	6cac <fwp_caps37+0xac>  // b.any
    6c98:	aa1303e0 	mov	x0, x19
    6c9c:	f9400bf3 	ldr	x19, [sp, #16]
    6ca0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ca4:	17fff6d3 	b	47f0 <fwp_mem_free>
    6ca8:	34fffbe1 	cbz	w1, 6c24 <fwp_caps37+0x24>
    6cac:	f9400bf3 	ldr	x19, [sp, #16]
    6cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cb4:	d65f03c0 	ret
    6cb8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6cbc:	9114c042 	add	x2, x2, #0x530
    6cc0:	f949d843 	ldr	x3, [x2, #5040]
    6cc4:	f949ec41 	ldr	x1, [x2, #5080]
    6cc8:	cb030000 	sub	x0, x0, x3
    6ccc:	eb01401f 	cmp	x0, x1, lsl #16
    6cd0:	54fffee2 	b.cs	6cac <fwp_caps37+0xac>  // b.hs, b.nlast
    6cd4:	d350fc01 	lsr	x1, x0, #16
    6cd8:	f949fc44 	ldr	x4, [x2, #5112]
    6cdc:	8b010821 	add	x1, x1, x1, lsl #2
    6ce0:	d37df021 	lsl	x1, x1, #3
    6ce4:	8b010083 	add	x3, x4, x1
    6ce8:	f9401062 	ldr	x2, [x3, #32]
    6cec:	b4fffe02 	cbz	x2, 6cac <fwp_caps37+0xac>
    6cf0:	38616881 	ldrb	w1, [x4, x1]
    6cf4:	7100083f 	cmp	w1, #0x2
    6cf8:	54000280 	b.eq	6d48 <fwp_caps37+0x148>  // b.none
    6cfc:	7100043f 	cmp	w1, #0x1
    6d00:	54fffd61 	b.ne	6cac <fwp_caps37+0xac>  // b.any
    6d04:	92403c01 	and	x1, x0, #0xffff
    6d08:	29430064 	ldp	w4, w0, [x3, #24]
    6d0c:	9b047c21 	mul	x1, x1, x4
    6d10:	d360fc21 	lsr	x1, x1, #32
    6d14:	eb00003f 	cmp	x1, x0
    6d18:	54fffca2 	b.cs	6cac <fwp_caps37+0xac>  // b.hs, b.nlast
    6d1c:	8b010042 	add	x2, x2, x1
    6d20:	39400040 	ldrb	w0, [x2]
    6d24:	34fffc40 	cbz	w0, 6cac <fwp_caps37+0xac>
    6d28:	7103f41f 	cmp	w0, #0xfd
    6d2c:	54000148 	b.hi	6d54 <fwp_caps37+0x154>  // b.pmore
    6d30:	11000400 	add	w0, w0, #0x1
    6d34:	39000040 	strb	w0, [x2]
    6d38:	17ffffdd 	b	6cac <fwp_caps37+0xac>
    6d3c:	72003c1f 	tst	w0, #0xffff
    6d40:	54fffb61 	b.ne	6cac <fwp_caps37+0xac>  // b.any
    6d44:	17ffffd2 	b	6c8c <fwp_caps37+0x8c>
    6d48:	72003c1f 	tst	w0, #0xffff
    6d4c:	54fffb01 	b.ne	6cac <fwp_caps37+0xac>  // b.any
    6d50:	17fffff4 	b	6d20 <fwp_caps37+0x120>
    6d54:	f9400bf3 	ldr	x19, [sp, #16]
    6d58:	aa0203e0 	mov	x0, x2
    6d5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d60:	17fff5bd 	b	4454 <fwp_rc_wide_dup>

0000000000006d64 <fwp_write>:
    6d64:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6d68:	910003fd 	mov	x29, sp
    6d6c:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6d70:	f947f484 	ldr	x4, [x4, #4072]
    6d74:	a90153f3 	stp	x19, x20, [sp, #16]
    6d78:	d10943ff 	sub	sp, sp, #0x250
    6d7c:	b9400045 	ldr	w5, [x2]
    6d80:	aa0003f4 	mov	x20, x0
    6d84:	f9400080 	ldr	x0, [x4]
    6d88:	f90127e0 	str	x0, [sp, #584]
    6d8c:	d2800000 	mov	x0, #0x0                   	// #0
    6d90:	710064bf 	cmp	w5, #0x19
    6d94:	54000408 	b.hi	6e14 <fwp_write+0xb0>  // b.pmore
    6d98:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    6d9c:	aa0103f3 	mov	x19, x1
    6da0:	912d8000 	add	x0, x0, #0xb60
    6da4:	f9013bf5 	str	x21, [sp, #624]
    6da8:	f9013ff6 	str	x22, [sp, #632]
    6dac:	f90153fb 	str	x27, [sp, #672]
    6db0:	f90157fc 	str	x28, [sp, #680]
    6db4:	aa0203fc 	mov	x28, x2
    6db8:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6dbc:	10000061 	adr	x1, 6dc8 <fwp_write+0x64>
    6dc0:	8b20a820 	add	x0, x1, w0, sxth #2
    6dc4:	d61f0000 	br	x0
    6dc8:	910123e0 	add	x0, sp, #0x48
    6dcc:	aa1303e5 	mov	x5, x19
    6dd0:	f0000004 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    6dd4:	aa0003f3 	mov	x19, x0
    6dd8:	91100084 	add	x4, x4, #0x400
    6ddc:	d2804003 	mov	x3, #0x200                 	// #512
    6de0:	aa0303e1 	mov	x1, x3
    6de4:	52800042 	mov	w2, #0x2                   	// #2
    6de8:	97ffee82 	bl	27f0 <__snprintf_chk@plt>
    6dec:	aa1303e0 	mov	x0, x19
    6df0:	97ffee48 	bl	2710 <strlen@plt>
    6df4:	aa1303e1 	mov	x1, x19
    6df8:	aa0003e2 	mov	x2, x0
    6dfc:	aa1403e0 	mov	x0, x20
    6e00:	97fff184 	bl	3410 <buf_put>
    6e04:	f9413bf5 	ldr	x21, [sp, #624]
    6e08:	f9413ff6 	ldr	x22, [sp, #632]
    6e0c:	f94153fb 	ldr	x27, [sp, #672]
    6e10:	f94157fc 	ldr	x28, [sp, #680]
    6e14:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6e18:	f947f400 	ldr	x0, [x0, #4072]
    6e1c:	f94127e2 	ldr	x2, [sp, #584]
    6e20:	f9400001 	ldr	x1, [x0]
    6e24:	eb010042 	subs	x2, x2, x1
    6e28:	d2800001 	mov	x1, #0x0                   	// #0
    6e2c:	540077a1 	b.ne	7d20 <fwp_write+0xfbc>  // b.any
    6e30:	910943ff 	add	sp, sp, #0x250
    6e34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e38:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6e3c:	d65f03c0 	ret
    6e40:	910123e0 	add	x0, sp, #0x48
    6e44:	aa1303e5 	mov	x5, x19
    6e48:	f0000004 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    6e4c:	aa0003f3 	mov	x19, x0
    6e50:	910fe084 	add	x4, x4, #0x3f8
    6e54:	d2804003 	mov	x3, #0x200                 	// #512
    6e58:	17ffffe2 	b	6de0 <fwp_write+0x7c>
    6e5c:	71004cbf 	cmp	w5, #0x13
    6e60:	f0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    6e64:	f0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    6e68:	910fa000 	add	x0, x0, #0x3e8
    6e6c:	910fc021 	add	x1, x1, #0x3f0
    6e70:	d2800082 	mov	x2, #0x4                   	// #4
    6e74:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6e78:	aa1403e0 	mov	x0, x20
    6e7c:	f90143f7 	str	x23, [sp, #640]
    6e80:	d2800016 	mov	x22, #0x0                   	// #0
    6e84:	f90147f8 	str	x24, [sp, #648]
    6e88:	97fff162 	bl	3410 <buf_put>
    6e8c:	f9400260 	ldr	x0, [x19]
    6e90:	f0000017 	adrp	x23, 9000 <_IO_stdin_used+0x30>
    6e94:	d2800015 	mov	x21, #0x0                   	// #0
    6e98:	9111c2f7 	add	x23, x23, #0x470
    6e9c:	b4004780 	cbz	x0, 778c <fwp_write+0xa28>
    6ea0:	b9400380 	ldr	w0, [x28]
    6ea4:	52800003 	mov	w3, #0x0                   	// #0
    6ea8:	f9401f82 	ldr	x2, [x28, #56]
    6eac:	71004c1f 	cmp	w0, #0x13
    6eb0:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    6eb4:	aa1403e0 	mov	x0, x20
    6eb8:	8b010e61 	add	x1, x19, x1, lsl #3
    6ebc:	f9400421 	ldr	x1, [x1, #8]
    6ec0:	97ffffa9 	bl	6d64 <fwp_write>
    6ec4:	b9400380 	ldr	w0, [x28]
    6ec8:	7100481f 	cmp	w0, #0x12
    6ecc:	54004b20 	b.eq	7830 <fwp_write+0xacc>  // b.none
    6ed0:	f9400260 	ldr	x0, [x19]
    6ed4:	910006b5 	add	x21, x21, #0x1
    6ed8:	91000ad6 	add	x22, x22, #0x2
    6edc:	eb15001f 	cmp	x0, x21
    6ee0:	54004569 	b.ls	778c <fwp_write+0xa28>  // b.plast
    6ee4:	aa1703e1 	mov	x1, x23
    6ee8:	aa1403e0 	mov	x0, x20
    6eec:	d2800042 	mov	x2, #0x2                   	// #2
    6ef0:	97fff148 	bl	3410 <buf_put>
    6ef4:	17ffffeb 	b	6ea0 <fwp_write+0x13c>
    6ef8:	f0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    6efc:	9110a021 	add	x1, x1, #0x428
    6f00:	d28000c2 	mov	x2, #0x6                   	// #6
    6f04:	aa1403e0 	mov	x0, x20
    6f08:	91004273 	add	x19, x19, #0x10
    6f0c:	97fff141 	bl	3410 <buf_put>
    6f10:	aa1303e0 	mov	x0, x19
    6f14:	97ffedff 	bl	2710 <strlen@plt>
    6f18:	aa1303e1 	mov	x1, x19
    6f1c:	aa0003e2 	mov	x2, x0
    6f20:	aa1403e0 	mov	x0, x20
    6f24:	97fff13b 	bl	3410 <buf_put>
    6f28:	528007c3 	mov	w3, #0x3e                  	// #62
    6f2c:	aa1403e0 	mov	x0, x20
    6f30:	91001fe1 	add	x1, sp, #0x7
    6f34:	d2800022 	mov	x2, #0x1                   	// #1
    6f38:	39001fe3 	strb	w3, [sp, #7]
    6f3c:	17ffffb1 	b	6e00 <fwp_write+0x9c>
    6f40:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6f44:	f947f400 	ldr	x0, [x0, #4072]
    6f48:	f94127e2 	ldr	x2, [sp, #584]
    6f4c:	f9400001 	ldr	x1, [x0]
    6f50:	eb010042 	subs	x2, x2, x1
    6f54:	d2800001 	mov	x1, #0x0                   	// #0
    6f58:	540034c1 	b.ne	75f0 <fwp_write+0x88c>  // b.any
    6f5c:	f9413bf5 	ldr	x21, [sp, #624]
    6f60:	f0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    6f64:	f9413ff6 	ldr	x22, [sp, #632]
    6f68:	aa1403e0 	mov	x0, x20
    6f6c:	91102021 	add	x1, x1, #0x408
    6f70:	d2800142 	mov	x2, #0xa                   	// #10
    6f74:	f94153fb 	ldr	x27, [sp, #672]
    6f78:	f94157fc 	ldr	x28, [sp, #680]
    6f7c:	910943ff 	add	sp, sp, #0x250
    6f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f84:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6f88:	17fff122 	b	3410 <buf_put>
    6f8c:	f9400456 	ldr	x22, [x2, #8]
    6f90:	f90143f7 	str	x23, [sp, #640]
    6f94:	f90147f8 	str	x24, [sp, #648]
    6f98:	b4005af6 	cbz	x22, 7af4 <fwp_write+0xd90>
    6f9c:	aa1603e0 	mov	x0, x22
    6fa0:	f0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    6fa4:	91122021 	add	x1, x1, #0x488
    6fa8:	97ffee56 	bl	2900 <strcmp@plt>
    6fac:	2a0003f5 	mov	w21, w0
    6fb0:	34005fc0 	cbz	w0, 7ba8 <fwp_write+0xe44>
    6fb4:	aa1603e0 	mov	x0, x22
    6fb8:	97ffedd6 	bl	2710 <strlen@plt>
    6fbc:	aa1603e1 	mov	x1, x22
    6fc0:	aa0003e2 	mov	x2, x0
    6fc4:	aa1403e0 	mov	x0, x20
    6fc8:	97fff112 	bl	3410 <buf_put>
    6fcc:	52800403 	mov	w3, #0x20                  	// #32
    6fd0:	91001ff5 	add	x21, sp, #0x7
    6fd4:	aa1503e1 	mov	x1, x21
    6fd8:	aa1403e0 	mov	x0, x20
    6fdc:	d2800022 	mov	x2, #0x1                   	// #1
    6fe0:	39001fe3 	strb	w3, [sp, #7]
    6fe4:	97fff10b 	bl	3410 <buf_put>
    6fe8:	52800f63 	mov	w3, #0x7b                  	// #123
    6fec:	aa1403e0 	mov	x0, x20
    6ff0:	aa1503e1 	mov	x1, x21
    6ff4:	d2800022 	mov	x2, #0x1                   	// #1
    6ff8:	39001fe3 	strb	w3, [sp, #7]
    6ffc:	97fff105 	bl	3410 <buf_put>
    7000:	b9401380 	ldr	w0, [x28, #16]
    7004:	52800018 	mov	w24, #0x0                   	// #0
    7008:	7100001f 	cmp	w0, #0x0
    700c:	54003a8d 	b.le	775c <fwp_write+0x9f8>
    7010:	f9014bf9 	str	x25, [sp, #656]
    7014:	d0000019 	adrp	x25, 9000 <_IO_stdin_used+0x30>
    7018:	9112c339 	add	x25, x25, #0x4b0
    701c:	f9014ffa 	str	x26, [sp, #664]
    7020:	d000001a 	adrp	x26, 9000 <_IO_stdin_used+0x30>
    7024:	9111c35a 	add	x26, x26, #0x470
    7028:	91002276 	add	x22, x19, #0x8
    702c:	d2800013 	mov	x19, #0x0                   	// #0
    7030:	b5003e73 	cbnz	x19, 77fc <fwp_write+0xa98>
    7034:	d37df277 	lsl	x23, x19, #3
    7038:	34003c98 	cbz	w24, 77c8 <fwp_write+0xa64>
    703c:	f9401382 	ldr	x2, [x28, #32]
    7040:	aa1403e0 	mov	x0, x20
    7044:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7048:	52800003 	mov	w3, #0x0                   	// #0
    704c:	f8776842 	ldr	x2, [x2, x23]
    7050:	91000673 	add	x19, x19, #0x1
    7054:	97ffff44 	bl	6d64 <fwp_write>
    7058:	b9401380 	ldr	w0, [x28, #16]
    705c:	6b13001f 	cmp	w0, w19
    7060:	54fffe8c 	b.gt	7030 <fwp_write+0x2cc>
    7064:	f9414bf9 	ldr	x25, [sp, #656]
    7068:	f9414ffa 	ldr	x26, [sp, #664]
    706c:	34003798 	cbz	w24, 775c <fwp_write+0x9f8>
    7070:	52800523 	mov	w3, #0x29                  	// #41
    7074:	aa1503e1 	mov	x1, x21
    7078:	aa1403e0 	mov	x0, x20
    707c:	d2800022 	mov	x2, #0x1                   	// #1
    7080:	39001fe3 	strb	w3, [sp, #7]
    7084:	97fff0e3 	bl	3410 <buf_put>
    7088:	f9413bf5 	ldr	x21, [sp, #624]
    708c:	f9413ff6 	ldr	x22, [sp, #632]
    7090:	f94143f7 	ldr	x23, [sp, #640]
    7094:	f94147f8 	ldr	x24, [sp, #648]
    7098:	f94153fb 	ldr	x27, [sp, #672]
    709c:	f94157fc 	ldr	x28, [sp, #680]
    70a0:	17ffff5d 	b	6e14 <fwp_write+0xb0>
    70a4:	b9404855 	ldr	w21, [x2, #72]
    70a8:	aa1403e0 	mov	x0, x20
    70ac:	93407eb6 	sxtw	x22, w21
    70b0:	91000ac1 	add	x1, x22, #0x2
    70b4:	97fff0a4 	bl	3344 <buf_grow>
    70b8:	a9400281 	ldp	x1, x0, [x20]
    70bc:	528e8603 	mov	w3, #0x7430                	// #29744
    70c0:	78206823 	strh	w3, [x1, x0]
    70c4:	8b000022 	add	x2, x1, x0
    70c8:	710002bf 	cmp	w21, #0x0
    70cc:	540036ad 	b.le	77a0 <fwp_write+0xa3c>
    70d0:	110006a3 	add	w3, w21, #0x1
    70d4:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    70d8:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    70dc:	91000449 	add	x9, x2, #0x1
    70e0:	8b23c043 	add	x3, x2, w3, sxtw
    70e4:	f28aaac6 	movk	x6, #0x5556
    70e8:	f2955568 	movk	x8, #0xaaab
    70ec:	1400000d 	b	7120 <fwp_write+0x3bc>
    70f0:	d2800021 	mov	x1, #0x1                   	// #1
    70f4:	528005a5 	mov	w5, #0x2d                  	// #45
    70f8:	f100001f 	cmp	x0, #0x0
    70fc:	9b467e60 	smulh	x0, x19, x6
    7100:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7104:	381ff465 	strb	w5, [x3], #-1
    7108:	cb040000 	sub	x0, x0, x4
    710c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7110:	cb020000 	sub	x0, x0, x2
    7114:	8b010013 	add	x19, x0, x1
    7118:	eb03013f 	cmp	x9, x3
    711c:	54003420 	b.eq	77a0 <fwp_write+0xa3c>  // b.none
    7120:	9b467e60 	smulh	x0, x19, x6
    7124:	937ffe64 	asr	x4, x19, #63
    7128:	52800605 	mov	w5, #0x30                  	// #48
    712c:	cb040000 	sub	x0, x0, x4
    7130:	8b000400 	add	x0, x0, x0, lsl #1
    7134:	cb000260 	sub	x0, x19, x0
    7138:	91000c01 	add	x1, x0, #0x3
    713c:	9bc87c22 	umulh	x2, x1, x8
    7140:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7144:	8b4204e2 	add	x2, x7, x2, lsr #1
    7148:	eb020021 	subs	x1, x1, x2
    714c:	54fffd60 	b.eq	70f8 <fwp_write+0x394>  // b.none
    7150:	f100043f 	cmp	x1, #0x1
    7154:	54fffce1 	b.ne	70f0 <fwp_write+0x38c>  // b.any
    7158:	d2800001 	mov	x1, #0x0                   	// #0
    715c:	52800565 	mov	w5, #0x2b                  	// #43
    7160:	17ffffe6 	b	70f8 <fwp_write+0x394>
    7164:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7168:	f947f400 	ldr	x0, [x0, #4072]
    716c:	f94127e2 	ldr	x2, [sp, #584]
    7170:	f9400001 	ldr	x1, [x0]
    7174:	eb010042 	subs	x2, x2, x1
    7178:	d2800001 	mov	x1, #0x0                   	// #0
    717c:	540023a1 	b.ne	75f0 <fwp_write+0x88c>  // b.any
    7180:	f9413bf5 	ldr	x21, [sp, #624]
    7184:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    7188:	f9413ff6 	ldr	x22, [sp, #632]
    718c:	aa1403e0 	mov	x0, x20
    7190:	91106021 	add	x1, x1, #0x418
    7194:	d2800102 	mov	x2, #0x8                   	// #8
    7198:	17ffff77 	b	6f74 <fwp_write+0x210>
    719c:	aa1403e0 	mov	x0, x20
    71a0:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    71a4:	d28000c2 	mov	x2, #0x6                   	// #6
    71a8:	9111e021 	add	x1, x1, #0x478
    71ac:	97fff099 	bl	3410 <buf_put>
    71b0:	d2800015 	mov	x21, #0x0                   	// #0
    71b4:	f9400263 	ldr	x3, [x19]
    71b8:	f240f87f 	tst	x3, #0x7fffffffffffffff
    71bc:	54002c40 	b.eq	7744 <fwp_write+0x9e0>  // b.none
    71c0:	f9401f82 	ldr	x2, [x28, #56]
    71c4:	f90143f7 	str	x23, [sp, #640]
    71c8:	f90147f8 	str	x24, [sp, #648]
    71cc:	d2800857 	mov	x23, #0x42                  	// #66
    71d0:	f9014bf9 	str	x25, [sp, #656]
    71d4:	d0000016 	adrp	x22, 9000 <_IO_stdin_used+0x30>
    71d8:	f9014ffa 	str	x26, [sp, #664]
    71dc:	9111c2d6 	add	x22, x22, #0x470
    71e0:	d2800038 	mov	x24, #0x1                   	// #1
    71e4:	f2a18017 	movk	x23, #0xc00, lsl #16
    71e8:	d2809099 	mov	x25, #0x484                 	// #1156
    71ec:	b4000482 	cbz	x2, 727c <fwp_write+0x518>
    71f0:	b9400040 	ldr	w0, [x2]
    71f4:	7100701f 	cmp	w0, #0x1c
    71f8:	540042a0 	b.eq	7a4c <fwp_write+0xce8>  // b.none
    71fc:	71006c1f 	cmp	w0, #0x1b
    7200:	540003e8 	b.hi	727c <fwp_write+0x518>  // b.pmore
    7204:	9ac02301 	lsl	x1, x24, x0
    7208:	ea17003f 	tst	x1, x23
    720c:	54003681 	b.ne	78dc <fwp_write+0xb78>  // b.any
    7210:	ea19003f 	tst	x1, x25
    7214:	54003501 	b.ne	78b4 <fwp_write+0xb50>  // b.any
    7218:	d2800424 	mov	x4, #0x21                  	// #33
    721c:	ea04003f 	tst	x1, x4
    7220:	540002e0 	b.eq	727c <fwp_write+0x518>  // b.none
    7224:	b7f849a3 	tbnz	x3, #63, 7b58 <fwp_write+0xdf4>
    7228:	91002261 	add	x1, x19, #0x8
    722c:	8b150021 	add	x1, x1, x21
    7230:	39400021 	ldrb	w1, [x1]
    7234:	7100001f 	cmp	w0, #0x0
    7238:	93401c23 	sxtb	x3, w1
    723c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7240:	aa1403e0 	mov	x0, x20
    7244:	52800003 	mov	w3, #0x0                   	// #0
    7248:	97fffec7 	bl	6d64 <fwp_write>
    724c:	910006b5 	add	x21, x21, #0x1
    7250:	f9400260 	ldr	x0, [x19]
    7254:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7258:	eb0002bf 	cmp	x21, x0
    725c:	540026c2 	b.cs	7734 <fwp_write+0x9d0>  // b.hs, b.nlast
    7260:	d2800042 	mov	x2, #0x2                   	// #2
    7264:	aa1603e1 	mov	x1, x22
    7268:	aa1403e0 	mov	x0, x20
    726c:	97fff069 	bl	3410 <buf_put>
    7270:	f9401f82 	ldr	x2, [x28, #56]
    7274:	f9400263 	ldr	x3, [x19]
    7278:	b5fffbc2 	cbnz	x2, 71f0 <fwp_write+0x48c>
    727c:	d37df2a0 	lsl	x0, x21, #3
    7280:	b7f83f03 	tbnz	x3, #63, 7a60 <fwp_write+0xcfc>
    7284:	91002261 	add	x1, x19, #0x8
    7288:	8b000020 	add	x0, x1, x0
    728c:	f9400001 	ldr	x1, [x0]
    7290:	17ffffec 	b	7240 <fwp_write+0x4dc>
    7294:	a9400e62 	ldp	x2, x3, [x19]
    7298:	b7f83ca3 	tbnz	x3, #63, 7a2c <fwp_write+0xcc8>
    729c:	910123f5 	add	x21, sp, #0x48
    72a0:	aa1503e0 	mov	x0, x21
    72a4:	97ffeedf 	bl	2e20 <fwp_fmt_u128>
    72a8:	aa1503e0 	mov	x0, x21
    72ac:	97ffed19 	bl	2710 <strlen@plt>
    72b0:	aa1503e1 	mov	x1, x21
    72b4:	aa0003e2 	mov	x2, x0
    72b8:	17fffed1 	b	6dfc <fwp_write+0x98>
    72bc:	fd015be8 	str	d8, [sp, #688]
    72c0:	1e270268 	fmov	s8, w19
    72c4:	fd015fe9 	str	d9, [sp, #696]
    72c8:	1e282100 	fcmp	s8, s8
    72cc:	54004d26 	b.vs	7c70 <fwp_write+0xf0c>
    72d0:	1e20c101 	fabs	s1, s8
    72d4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    72d8:	1e270000 	fmov	s0, w0
    72dc:	1e202020 	fcmp	s1, s0
    72e0:	54002c0d 	b.le	7860 <fwp_write+0xafc>
    72e4:	1e202118 	fcmpe	s8, #0.0
    72e8:	b0000002 	adrp	x2, 8000 <fwp_main_thread+0x2b0>
    72ec:	913fc042 	add	x2, x2, #0xff0
    72f0:	910123f5 	add	x21, sp, #0x48
    72f4:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    72f8:	910f2021 	add	x1, x1, #0x3c8
    72fc:	aa1503e0 	mov	x0, x21
    7300:	9a81c041 	csel	x1, x2, x1, gt
    7304:	97ffedaf 	bl	29c0 <strcpy@plt>
    7308:	aa1503e0 	mov	x0, x21
    730c:	97ffed01 	bl	2710 <strlen@plt>
    7310:	aa1503e1 	mov	x1, x21
    7314:	aa0003e2 	mov	x2, x0
    7318:	aa1403e0 	mov	x0, x20
    731c:	97fff03d 	bl	3410 <buf_put>
    7320:	f9413bf5 	ldr	x21, [sp, #624]
    7324:	f9413ff6 	ldr	x22, [sp, #632]
    7328:	f94153fb 	ldr	x27, [sp, #672]
    732c:	f94157fc 	ldr	x28, [sp, #680]
    7330:	fd415be8 	ldr	d8, [sp, #688]
    7334:	fd415fe9 	ldr	d9, [sp, #696]
    7338:	17fffeb7 	b	6e14 <fwp_write+0xb0>
    733c:	f9400276 	ldr	x22, [x19]
    7340:	34002e03 	cbz	w3, 7900 <fwp_write+0xb9c>
    7344:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7348:	f947f400 	ldr	x0, [x0, #4072]
    734c:	f94127e2 	ldr	x2, [sp, #584]
    7350:	f9400001 	ldr	x1, [x0]
    7354:	eb010042 	subs	x2, x2, x1
    7358:	d2800001 	mov	x1, #0x0                   	// #0
    735c:	540014a1 	b.ne	75f0 <fwp_write+0x88c>  // b.any
    7360:	aa1603e2 	mov	x2, x22
    7364:	91002261 	add	x1, x19, #0x8
    7368:	f9413bf5 	ldr	x21, [sp, #624]
    736c:	aa1403e0 	mov	x0, x20
    7370:	f9413ff6 	ldr	x22, [sp, #632]
    7374:	17ffff00 	b	6f74 <fwp_write+0x210>
    7378:	fd015be8 	str	d8, [sp, #688]
    737c:	9e670268 	fmov	d8, x19
    7380:	fd015fe9 	str	d9, [sp, #696]
    7384:	1e682100 	fcmp	d8, d8
    7388:	54004746 	b.vs	7c70 <fwp_write+0xf0c>
    738c:	1e60c101 	fabs	d1, d8
    7390:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7394:	9e670000 	fmov	d0, x0
    7398:	910123f5 	add	x21, sp, #0x48
    739c:	52800033 	mov	w19, #0x1                   	// #1
    73a0:	1e602020 	fcmp	d1, d0
    73a4:	540001ad 	b.le	73d8 <fwp_write+0x674>
    73a8:	1e602118 	fcmpe	d8, #0.0
    73ac:	b0000002 	adrp	x2, 8000 <fwp_main_thread+0x2b0>
    73b0:	913fc042 	add	x2, x2, #0xff0
    73b4:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    73b8:	910f2021 	add	x1, x1, #0x3c8
    73bc:	aa1503e0 	mov	x0, x21
    73c0:	9a81c041 	csel	x1, x2, x1, gt
    73c4:	97ffed7f 	bl	29c0 <strcpy@plt>
    73c8:	17ffffd0 	b	7308 <fwp_write+0x5a4>
    73cc:	11000673 	add	w19, w19, #0x1
    73d0:	71004a7f 	cmp	w19, #0x12
    73d4:	54003860 	b.eq	7ae0 <fwp_write+0xd7c>  // b.none
    73d8:	1e604100 	fmov	d0, d8
    73dc:	2a1303e1 	mov	w1, w19
    73e0:	aa1503e0 	mov	x0, x21
    73e4:	97fff14c 	bl	3914 <fwp_format_g.constprop.0>
    73e8:	aa1503e0 	mov	x0, x21
    73ec:	d2800001 	mov	x1, #0x0                   	// #0
    73f0:	97ffecdc 	bl	2760 <strtod@plt>
    73f4:	1e602100 	fcmp	d8, d0
    73f8:	54fffea1 	b.ne	73cc <fwp_write+0x668>  // b.any
    73fc:	aa1503e0 	mov	x0, x21
    7400:	97fff03d 	bl	34f4 <fwp_finish_float>
    7404:	17ffffc1 	b	7308 <fwp_write+0x5a4>
    7408:	a9400e62 	ldp	x2, x3, [x19]
    740c:	910123f3 	add	x19, sp, #0x48
    7410:	aa1303e0 	mov	x0, x19
    7414:	97ffee83 	bl	2e20 <fwp_fmt_u128>
    7418:	17fffe75 	b	6dec <fwp_write+0x88>
    741c:	f90143f7 	str	x23, [sp, #640]
    7420:	f90147f8 	str	x24, [sp, #648]
    7424:	2a1303f8 	mov	w24, w19
    7428:	f9014bf9 	str	x25, [sp, #656]
    742c:	f9014ffa 	str	x26, [sp, #664]
    7430:	f13ffe7f 	cmp	x19, #0xfff
    7434:	54000049 	b.ls	743c <fwp_write+0x6d8>  // b.plast
    7438:	b9400278 	ldr	w24, [x19]
    743c:	f9400f80 	ldr	x0, [x28, #24]
    7440:	2a1803f5 	mov	w21, w24
    7444:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7448:	d37ef6b9 	lsl	x25, x21, #2
    744c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7450:	aa1603e0 	mov	x0, x22
    7454:	97ffecaf 	bl	2710 <strlen@plt>
    7458:	aa1603e1 	mov	x1, x22
    745c:	aa0003e2 	mov	x2, x0
    7460:	aa1403e0 	mov	x0, x20
    7464:	97ffefeb 	bl	3410 <buf_put>
    7468:	f9401780 	ldr	x0, [x28, #40]
    746c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7470:	7100001f 	cmp	w0, #0x0
    7474:	5400068d 	b.le	7544 <fwp_write+0x7e0>
    7478:	91002276 	add	x22, x19, #0x8
    747c:	91001ff5 	add	x21, sp, #0x7
    7480:	d280001b 	mov	x27, #0x0                   	// #0
    7484:	5280041a 	mov	w26, #0x20                  	// #32
    7488:	f9401b80 	ldr	x0, [x28, #48]
    748c:	aa1503e1 	mov	x1, x21
    7490:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7494:	d2800022 	mov	x2, #0x1                   	// #1
    7498:	f8786803 	ldr	x3, [x0, x24]
    749c:	aa1403e0 	mov	x0, x20
    74a0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    74a4:	39001ffa 	strb	w26, [sp, #7]
    74a8:	97ffefda 	bl	3410 <buf_put>
    74ac:	f13ffeff 	cmp	x23, #0xfff
    74b0:	b9400261 	ldr	w1, [x19]
    74b4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    74b8:	7100383f 	cmp	w1, #0xe
    74bc:	54000160 	b.eq	74e8 <fwp_write+0x784>  // b.none
    74c0:	7100403f 	cmp	w1, #0x10
    74c4:	54001a60 	b.eq	7810 <fwp_write+0xaac>  // b.none
    74c8:	7100283f 	cmp	w1, #0xa
    74cc:	54002aa0 	b.eq	7a20 <fwp_write+0xcbc>  // b.none
    74d0:	540014ac 	b.gt	7764 <fwp_write+0xa00>
    74d4:	71000c3f 	cmp	w1, #0x3
    74d8:	540029ac 	b.gt	7a0c <fwp_write+0xca8>
    74dc:	d37ffee0 	lsr	x0, x23, #63
    74e0:	37f814a1 	tbnz	w1, #31, 7774 <fwp_write+0xa10>
    74e4:	d503201f 	nop
    74e8:	34001460 	cbz	w0, 7774 <fwp_write+0xa10>
    74ec:	52800503 	mov	w3, #0x28                  	// #40
    74f0:	aa1503e1 	mov	x1, x21
    74f4:	aa1403e0 	mov	x0, x20
    74f8:	d2800022 	mov	x2, #0x1                   	// #1
    74fc:	39001fe3 	strb	w3, [sp, #7]
    7500:	97ffefc4 	bl	3410 <buf_put>
    7504:	aa1303e2 	mov	x2, x19
    7508:	aa1703e1 	mov	x1, x23
    750c:	aa1403e0 	mov	x0, x20
    7510:	52800003 	mov	w3, #0x0                   	// #0
    7514:	97fffe14 	bl	6d64 <fwp_write>
    7518:	52800523 	mov	w3, #0x29                  	// #41
    751c:	aa1503e1 	mov	x1, x21
    7520:	aa1403e0 	mov	x0, x20
    7524:	d2800022 	mov	x2, #0x1                   	// #1
    7528:	39001fe3 	strb	w3, [sp, #7]
    752c:	97ffefb9 	bl	3410 <buf_put>
    7530:	f9401780 	ldr	x0, [x28, #40]
    7534:	9100077b 	add	x27, x27, #0x1
    7538:	b8796800 	ldr	w0, [x0, x25]
    753c:	6b1b001f 	cmp	w0, w27
    7540:	54fffa4c 	b.gt	7488 <fwp_write+0x724>
    7544:	f9413bf5 	ldr	x21, [sp, #624]
    7548:	f9413ff6 	ldr	x22, [sp, #632]
    754c:	f94143f7 	ldr	x23, [sp, #640]
    7550:	f94147f8 	ldr	x24, [sp, #648]
    7554:	f9414bf9 	ldr	x25, [sp, #656]
    7558:	f9414ffa 	ldr	x26, [sp, #664]
    755c:	f94153fb 	ldr	x27, [sp, #672]
    7560:	f94157fc 	ldr	x28, [sp, #680]
    7564:	17fffe2c 	b	6e14 <fwp_write+0xb0>
    7568:	52800783 	mov	w3, #0x3c                  	// #60
    756c:	91001ff3 	add	x19, sp, #0x7
    7570:	aa1303e1 	mov	x1, x19
    7574:	d2800022 	mov	x2, #0x1                   	// #1
    7578:	aa1403e0 	mov	x0, x20
    757c:	39001fe3 	strb	w3, [sp, #7]
    7580:	97ffefa4 	bl	3410 <buf_put>
    7584:	f9400795 	ldr	x21, [x28, #8]
    7588:	aa1503e0 	mov	x0, x21
    758c:	97ffec61 	bl	2710 <strlen@plt>
    7590:	aa1503e1 	mov	x1, x21
    7594:	aa0003e2 	mov	x2, x0
    7598:	aa1403e0 	mov	x0, x20
    759c:	97ffef9d 	bl	3410 <buf_put>
    75a0:	528007c3 	mov	w3, #0x3e                  	// #62
    75a4:	aa1303e1 	mov	x1, x19
    75a8:	aa1403e0 	mov	x0, x20
    75ac:	d2800022 	mov	x2, #0x1                   	// #1
    75b0:	39001fe3 	strb	w3, [sp, #7]
    75b4:	17fffe13 	b	6e00 <fwp_write+0x9c>
    75b8:	f100067f 	cmp	x19, #0x1
    75bc:	540025a0 	b.eq	7a70 <fwp_write+0xd0c>  // b.none
    75c0:	b100067f 	cmn	x19, #0x1
    75c4:	54002bc0 	b.eq	7b3c <fwp_write+0xdd8>  // b.none
    75c8:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    75cc:	910f4021 	add	x1, x1, #0x3d0
    75d0:	d2800022 	mov	x2, #0x1                   	// #1
    75d4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    75d8:	f947f400 	ldr	x0, [x0, #4072]
    75dc:	f94127e4 	ldr	x4, [sp, #584]
    75e0:	f9400003 	ldr	x3, [x0]
    75e4:	eb030084 	subs	x4, x4, x3
    75e8:	d2800003 	mov	x3, #0x0                   	// #0
    75ec:	54ffebe0 	b.eq	7368 <fwp_write+0x604>  // b.none
    75f0:	f90143f7 	str	x23, [sp, #640]
    75f4:	f90147f8 	str	x24, [sp, #648]
    75f8:	f9014bf9 	str	x25, [sp, #656]
    75fc:	f9014ffa 	str	x26, [sp, #664]
    7600:	fd015be8 	str	d8, [sp, #688]
    7604:	fd015fe9 	str	d9, [sp, #696]
    7608:	97ffec9e 	bl	2880 <__stack_chk_fail@plt>
    760c:	52800b63 	mov	w3, #0x5b                  	// #91
    7610:	91001ff5 	add	x21, sp, #0x7
    7614:	aa1503e1 	mov	x1, x21
    7618:	aa1403e0 	mov	x0, x20
    761c:	d2800022 	mov	x2, #0x1                   	// #1
    7620:	d0000016 	adrp	x22, 9000 <_IO_stdin_used+0x30>
    7624:	9111c2d6 	add	x22, x22, #0x470
    7628:	39001fe3 	strb	w3, [sp, #7]
    762c:	97ffef79 	bl	3410 <buf_put>
    7630:	b4000273 	cbz	x19, 767c <fwp_write+0x918>
    7634:	f9400661 	ldr	x1, [x19, #8]
    7638:	aa1403e0 	mov	x0, x20
    763c:	f9401f82 	ldr	x2, [x28, #56]
    7640:	52800003 	mov	w3, #0x0                   	// #0
    7644:	97fffdc8 	bl	6d64 <fwp_write>
    7648:	f9400a73 	ldr	x19, [x19, #16]
    764c:	b4000193 	cbz	x19, 767c <fwp_write+0x918>
    7650:	aa1603e1 	mov	x1, x22
    7654:	aa1403e0 	mov	x0, x20
    7658:	d2800042 	mov	x2, #0x2                   	// #2
    765c:	97ffef6d 	bl	3410 <buf_put>
    7660:	f9400661 	ldr	x1, [x19, #8]
    7664:	aa1403e0 	mov	x0, x20
    7668:	f9401f82 	ldr	x2, [x28, #56]
    766c:	52800003 	mov	w3, #0x0                   	// #0
    7670:	97fffdbd 	bl	6d64 <fwp_write>
    7674:	f9400a73 	ldr	x19, [x19, #16]
    7678:	b5fffed3 	cbnz	x19, 7650 <fwp_write+0x8ec>
    767c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7680:	aa1503e1 	mov	x1, x21
    7684:	aa1403e0 	mov	x0, x20
    7688:	d2800022 	mov	x2, #0x1                   	// #1
    768c:	39001fe3 	strb	w3, [sp, #7]
    7690:	17fffddc 	b	6e00 <fwp_write+0x9c>
    7694:	aa1403e0 	mov	x0, x20
    7698:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    769c:	d28000c2 	mov	x2, #0x6                   	// #6
    76a0:	91118021 	add	x1, x1, #0x460
    76a4:	97ffef5b 	bl	3410 <buf_put>
    76a8:	f9400260 	ldr	x0, [x19]
    76ac:	b40004c0 	cbz	x0, 7744 <fwp_write+0x9e0>
    76b0:	910123f5 	add	x21, sp, #0x48
    76b4:	91002276 	add	x22, x19, #0x8
    76b8:	f90143f7 	str	x23, [sp, #640]
    76bc:	d2800017 	mov	x23, #0x0                   	// #0
    76c0:	f90147f8 	str	x24, [sp, #648]
    76c4:	d0000018 	adrp	x24, 9000 <_IO_stdin_used+0x30>
    76c8:	9111a318 	add	x24, x24, #0x468
    76cc:	f9014bf9 	str	x25, [sp, #656]
    76d0:	d0000019 	adrp	x25, 9000 <_IO_stdin_used+0x30>
    76d4:	9111c339 	add	x25, x25, #0x470
    76d8:	f9014ffa 	str	x26, [sp, #664]
    76dc:	14000005 	b	76f0 <fwp_write+0x98c>
    76e0:	aa1903e1 	mov	x1, x25
    76e4:	aa1403e0 	mov	x0, x20
    76e8:	d2800042 	mov	x2, #0x2                   	// #2
    76ec:	97ffef49 	bl	3410 <buf_put>
    76f0:	38776ac5 	ldrb	w5, [x22, x23]
    76f4:	d2804003 	mov	x3, #0x200                 	// #512
    76f8:	aa1803e4 	mov	x4, x24
    76fc:	aa0303e1 	mov	x1, x3
    7700:	52800042 	mov	w2, #0x2                   	// #2
    7704:	aa1503e0 	mov	x0, x21
    7708:	910006f7 	add	x23, x23, #0x1
    770c:	97ffec39 	bl	27f0 <__snprintf_chk@plt>
    7710:	aa1503e0 	mov	x0, x21
    7714:	97ffebff 	bl	2710 <strlen@plt>
    7718:	aa1503e1 	mov	x1, x21
    771c:	aa0003e2 	mov	x2, x0
    7720:	aa1403e0 	mov	x0, x20
    7724:	97ffef3b 	bl	3410 <buf_put>
    7728:	f9400260 	ldr	x0, [x19]
    772c:	eb17001f 	cmp	x0, x23
    7730:	54fffd88 	b.hi	76e0 <fwp_write+0x97c>  // b.pmore
    7734:	f94143f7 	ldr	x23, [sp, #640]
    7738:	f94147f8 	ldr	x24, [sp, #648]
    773c:	f9414bf9 	ldr	x25, [sp, #656]
    7740:	f9414ffa 	ldr	x26, [sp, #664]
    7744:	52800ba3 	mov	w3, #0x5d                  	// #93
    7748:	aa1403e0 	mov	x0, x20
    774c:	91001fe1 	add	x1, sp, #0x7
    7750:	d2800022 	mov	x2, #0x1                   	// #1
    7754:	39001fe3 	strb	w3, [sp, #7]
    7758:	17fffdaa 	b	6e00 <fwp_write+0x9c>
    775c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7760:	17fffe45 	b	7074 <fwp_write+0x310>
    7764:	f10002ff 	cmp	x23, #0x0
    7768:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    776c:	71002c3f 	cmp	w1, #0xb
    7770:	54ffebc0 	b.eq	74e8 <fwp_write+0x784>  // b.none
    7774:	aa1303e2 	mov	x2, x19
    7778:	aa1703e1 	mov	x1, x23
    777c:	aa1403e0 	mov	x0, x20
    7780:	52800003 	mov	w3, #0x0                   	// #0
    7784:	97fffd78 	bl	6d64 <fwp_write>
    7788:	17ffff6a 	b	7530 <fwp_write+0x7cc>
    778c:	aa1403e0 	mov	x0, x20
    7790:	91001fe1 	add	x1, sp, #0x7
    7794:	52800fa3 	mov	w3, #0x7d                  	// #125
    7798:	d2800022 	mov	x2, #0x1                   	// #1
    779c:	17fffe39 	b	7080 <fwp_write+0x31c>
    77a0:	a9400281 	ldp	x1, x0, [x20]
    77a4:	91000800 	add	x0, x0, #0x2
    77a8:	8b160000 	add	x0, x0, x22
    77ac:	f9000680 	str	x0, [x20, #8]
    77b0:	3820683f 	strb	wzr, [x1, x0]
    77b4:	f9413bf5 	ldr	x21, [sp, #624]
    77b8:	f9413ff6 	ldr	x22, [sp, #632]
    77bc:	f94153fb 	ldr	x27, [sp, #672]
    77c0:	f94157fc 	ldr	x28, [sp, #680]
    77c4:	17fffd94 	b	6e14 <fwp_write+0xb0>
    77c8:	f9400f80 	ldr	x0, [x28, #24]
    77cc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    77d0:	aa1b03e0 	mov	x0, x27
    77d4:	97ffebcf 	bl	2710 <strlen@plt>
    77d8:	aa1b03e1 	mov	x1, x27
    77dc:	aa0003e2 	mov	x2, x0
    77e0:	aa1403e0 	mov	x0, x20
    77e4:	97ffef0b 	bl	3410 <buf_put>
    77e8:	aa1903e1 	mov	x1, x25
    77ec:	aa1403e0 	mov	x0, x20
    77f0:	d2800062 	mov	x2, #0x3                   	// #3
    77f4:	97ffef07 	bl	3410 <buf_put>
    77f8:	17fffe11 	b	703c <fwp_write+0x2d8>
    77fc:	aa1a03e1 	mov	x1, x26
    7800:	aa1403e0 	mov	x0, x20
    7804:	d2800042 	mov	x2, #0x2                   	// #2
    7808:	97ffef02 	bl	3410 <buf_put>
    780c:	17fffe0a 	b	7034 <fwp_write+0x2d0>
    7810:	f9400660 	ldr	x0, [x19, #8]
    7814:	b4fffb00 	cbz	x0, 7774 <fwp_write+0xa10>
    7818:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    781c:	91122021 	add	x1, x1, #0x488
    7820:	97ffec38 	bl	2900 <strcmp@plt>
    7824:	7100001f 	cmp	w0, #0x0
    7828:	1a9f07e0 	cset	w0, ne	// ne = any
    782c:	17ffff2f 	b	74e8 <fwp_write+0x784>
    7830:	aa1403e0 	mov	x0, x20
    7834:	d2800042 	mov	x2, #0x2                   	// #2
    7838:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    783c:	91120021 	add	x1, x1, #0x480
    7840:	97ffeef4 	bl	3410 <buf_put>
    7844:	91004261 	add	x1, x19, #0x10
    7848:	aa1403e0 	mov	x0, x20
    784c:	f9402382 	ldr	x2, [x28, #64]
    7850:	52800003 	mov	w3, #0x0                   	// #0
    7854:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7858:	97fffd43 	bl	6d64 <fwp_write>
    785c:	17fffd9d 	b	6ed0 <fwp_write+0x16c>
    7860:	1e22c109 	fcvt	d9, s8
    7864:	910123f5 	add	x21, sp, #0x48
    7868:	52800033 	mov	w19, #0x1                   	// #1
    786c:	d503201f 	nop
    7870:	1e604120 	fmov	d0, d9
    7874:	2a1303e1 	mov	w1, w19
    7878:	aa1503e0 	mov	x0, x21
    787c:	97fff026 	bl	3914 <fwp_format_g.constprop.0>
    7880:	aa1503e0 	mov	x0, x21
    7884:	d2800001 	mov	x1, #0x0                   	// #0
    7888:	97ffec2a 	bl	2930 <strtof@plt>
    788c:	1e202100 	fcmp	s8, s0
    7890:	54ffdb60 	b.eq	73fc <fwp_write+0x698>  // b.none
    7894:	11000673 	add	w19, w19, #0x1
    7898:	71002a7f 	cmp	w19, #0xa
    789c:	54fffea1 	b.ne	7870 <fwp_write+0xb0c>  // b.any
    78a0:	1e604120 	fmov	d0, d9
    78a4:	aa1503e0 	mov	x0, x21
    78a8:	52800121 	mov	w1, #0x9                   	// #9
    78ac:	97fff01a 	bl	3914 <fwp_format_g.constprop.0>
    78b0:	17fffed3 	b	73fc <fwp_write+0x698>
    78b4:	d37ef6a1 	lsl	x1, x21, #2
    78b8:	b7f81563 	tbnz	x3, #63, 7b64 <fwp_write+0xe00>
    78bc:	91002263 	add	x3, x19, #0x8
    78c0:	8b010061 	add	x1, x3, x1
    78c4:	b9400023 	ldr	w3, [x1]
    78c8:	7100081f 	cmp	w0, #0x2
    78cc:	2a0303e1 	mov	w1, w3
    78d0:	93407c63 	sxtw	x3, w3
    78d4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    78d8:	17fffe5a 	b	7240 <fwp_write+0x4dc>
    78dc:	d37ffaa1 	lsl	x1, x21, #1
    78e0:	b7f81363 	tbnz	x3, #63, 7b4c <fwp_write+0xde8>
    78e4:	91002263 	add	x3, x19, #0x8
    78e8:	8b010061 	add	x1, x3, x1
    78ec:	79400021 	ldrh	w1, [x1]
    78f0:	7100041f 	cmp	w0, #0x1
    78f4:	93403c23 	sxth	x3, w1
    78f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    78fc:	17fffe51 	b	7240 <fwp_write+0x4dc>
    7900:	52800443 	mov	w3, #0x22                  	// #34
    7904:	91001ff5 	add	x21, sp, #0x7
    7908:	91002273 	add	x19, x19, #0x8
    790c:	aa1503e1 	mov	x1, x21
    7910:	aa1403e0 	mov	x0, x20
    7914:	d2800022 	mov	x2, #0x1                   	// #1
    7918:	39001fe3 	strb	w3, [sp, #7]
    791c:	f90143f7 	str	x23, [sp, #640]
    7920:	8b160277 	add	x23, x19, x22
    7924:	f90147f8 	str	x24, [sp, #648]
    7928:	97ffeeba 	bl	3410 <buf_put>
    792c:	b4000696 	cbz	x22, 79fc <fwp_write+0xc98>
    7930:	d0000018 	adrp	x24, 9000 <_IO_stdin_used+0x30>
    7934:	9110c318 	add	x24, x24, #0x430
    7938:	f9014bf9 	str	x25, [sp, #656]
    793c:	d0000019 	adrp	x25, 9000 <_IO_stdin_used+0x30>
    7940:	91114339 	add	x25, x25, #0x450
    7944:	f9014ffa 	str	x26, [sp, #664]
    7948:	1400000d 	b	797c <fwp_write+0xc18>
    794c:	710024bf 	cmp	w5, #0x9
    7950:	54000460 	b.eq	79dc <fwp_write+0xc78>  // b.none
    7954:	710028bf 	cmp	w5, #0xa
    7958:	54000a61 	b.ne	7aa4 <fwp_write+0xd40>  // b.any
    795c:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    7960:	aa1403e0 	mov	x0, x20
    7964:	91110021 	add	x1, x1, #0x440
    7968:	d2800042 	mov	x2, #0x2                   	// #2
    796c:	97ffeea9 	bl	3410 <buf_put>
    7970:	91000673 	add	x19, x19, #0x1
    7974:	eb17027f 	cmp	x19, x23
    7978:	540003e0 	b.eq	79f4 <fwp_write+0xc90>  // b.none
    797c:	39400265 	ldrb	w5, [x19]
    7980:	710034bf 	cmp	w5, #0xd
    7984:	54000180 	b.eq	79b4 <fwp_write+0xc50>  // b.none
    7988:	54fffe29 	b.ls	794c <fwp_write+0xbe8>  // b.plast
    798c:	710088bf 	cmp	w5, #0x22
    7990:	540001c0 	b.eq	79c8 <fwp_write+0xc64>  // b.none
    7994:	710170bf 	cmp	w5, #0x5c
    7998:	54000741 	b.ne	7a80 <fwp_write+0xd1c>  // b.any
    799c:	aa1403e0 	mov	x0, x20
    79a0:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    79a4:	d2800042 	mov	x2, #0x2                   	// #2
    79a8:	9110e021 	add	x1, x1, #0x438
    79ac:	97ffee99 	bl	3410 <buf_put>
    79b0:	17fffff0 	b	7970 <fwp_write+0xc0c>
    79b4:	aa1903e1 	mov	x1, x25
    79b8:	aa1403e0 	mov	x0, x20
    79bc:	d2800042 	mov	x2, #0x2                   	// #2
    79c0:	97ffee94 	bl	3410 <buf_put>
    79c4:	17ffffeb 	b	7970 <fwp_write+0xc0c>
    79c8:	aa1803e1 	mov	x1, x24
    79cc:	aa1403e0 	mov	x0, x20
    79d0:	d2800042 	mov	x2, #0x2                   	// #2
    79d4:	97ffee8f 	bl	3410 <buf_put>
    79d8:	17ffffe6 	b	7970 <fwp_write+0xc0c>
    79dc:	aa1403e0 	mov	x0, x20
    79e0:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    79e4:	d2800042 	mov	x2, #0x2                   	// #2
    79e8:	91112021 	add	x1, x1, #0x448
    79ec:	97ffee89 	bl	3410 <buf_put>
    79f0:	17ffffe0 	b	7970 <fwp_write+0xc0c>
    79f4:	f9414bf9 	ldr	x25, [sp, #656]
    79f8:	f9414ffa 	ldr	x26, [sp, #664]
    79fc:	aa1503e1 	mov	x1, x21
    7a00:	aa1403e0 	mov	x0, x20
    7a04:	52800443 	mov	w3, #0x22                  	// #34
    7a08:	17fffd9d 	b	707c <fwp_write+0x318>
    7a0c:	7100103f 	cmp	w1, #0x4
    7a10:	54ffeb21 	b.ne	7774 <fwp_write+0xa10>  // b.any
    7a14:	f94006e0 	ldr	x0, [x23, #8]
    7a18:	d37ffc00 	lsr	x0, x0, #63
    7a1c:	17fffeb3 	b	74e8 <fwp_write+0x784>
    7a20:	710002ff 	cmp	w23, #0x0
    7a24:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7a28:	17fffeb0 	b	74e8 <fwp_write+0x784>
    7a2c:	528005a1 	mov	w1, #0x2d                  	// #45
    7a30:	eb0203e2 	negs	x2, x2
    7a34:	da0303e3 	ngc	x3, x3
    7a38:	910127e0 	add	x0, sp, #0x49
    7a3c:	910123f5 	add	x21, sp, #0x48
    7a40:	390123e1 	strb	w1, [sp, #72]
    7a44:	97ffecf7 	bl	2e20 <fwp_fmt_u128>
    7a48:	17fffe18 	b	72a8 <fwp_write+0x544>
    7a4c:	d37ceea1 	lsl	x1, x21, #4
    7a50:	b7f810a3 	tbnz	x3, #63, 7c64 <fwp_write+0xf00>
    7a54:	91002260 	add	x0, x19, #0x8
    7a58:	8b010001 	add	x1, x0, x1
    7a5c:	17fffdf9 	b	7240 <fwp_write+0x4dc>
    7a60:	f9400a61 	ldr	x1, [x19, #16]
    7a64:	8b010000 	add	x0, x0, x1
    7a68:	f9400001 	ldr	x1, [x0]
    7a6c:	17fffdf5 	b	7240 <fwp_write+0x4dc>
    7a70:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    7a74:	d2800042 	mov	x2, #0x2                   	// #2
    7a78:	910f6021 	add	x1, x1, #0x3d8
    7a7c:	17fffed6 	b	75d4 <fwp_write+0x870>
    7a80:	7101fcbf 	cmp	w5, #0x7f
    7a84:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7a88:	540000e9 	b.ls	7aa4 <fwp_write+0xd40>  // b.plast
    7a8c:	aa1503e1 	mov	x1, x21
    7a90:	aa1403e0 	mov	x0, x20
    7a94:	d2800022 	mov	x2, #0x1                   	// #1
    7a98:	39001fe5 	strb	w5, [sp, #7]
    7a9c:	97ffee5d 	bl	3410 <buf_put>
    7aa0:	17ffffb4 	b	7970 <fwp_write+0xc0c>
    7aa4:	d2800203 	mov	x3, #0x10                  	// #16
    7aa8:	d0000004 	adrp	x4, 9000 <_IO_stdin_used+0x30>
    7aac:	aa0303e1 	mov	x1, x3
    7ab0:	91116084 	add	x4, x4, #0x458
    7ab4:	910123f6 	add	x22, sp, #0x48
    7ab8:	52800042 	mov	w2, #0x2                   	// #2
    7abc:	aa1603e0 	mov	x0, x22
    7ac0:	97ffeb4c 	bl	27f0 <__snprintf_chk@plt>
    7ac4:	aa1603e0 	mov	x0, x22
    7ac8:	97ffeb12 	bl	2710 <strlen@plt>
    7acc:	aa1603e1 	mov	x1, x22
    7ad0:	aa0003e2 	mov	x2, x0
    7ad4:	aa1403e0 	mov	x0, x20
    7ad8:	97ffee4e 	bl	3410 <buf_put>
    7adc:	17ffffa5 	b	7970 <fwp_write+0xc0c>
    7ae0:	1e604100 	fmov	d0, d8
    7ae4:	aa1503e0 	mov	x0, x21
    7ae8:	52800221 	mov	w1, #0x11                  	// #17
    7aec:	97ffef8a 	bl	3914 <fwp_format_g.constprop.0>
    7af0:	17fffe43 	b	73fc <fwp_write+0x698>
    7af4:	b9401040 	ldr	w0, [x2, #16]
    7af8:	350003c0 	cbnz	w0, 7b70 <fwp_write+0xe0c>
    7afc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7b00:	f947f400 	ldr	x0, [x0, #4072]
    7b04:	f94127e2 	ldr	x2, [sp, #584]
    7b08:	f9400001 	ldr	x1, [x0]
    7b0c:	eb010042 	subs	x2, x2, x1
    7b10:	d2800001 	mov	x1, #0x0                   	// #0
    7b14:	54ffd721 	b.ne	75f8 <fwp_write+0x894>  // b.any
    7b18:	f9413bf5 	ldr	x21, [sp, #624]
    7b1c:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    7b20:	f9413ff6 	ldr	x22, [sp, #632]
    7b24:	aa1403e0 	mov	x0, x20
    7b28:	f94143f7 	ldr	x23, [sp, #640]
    7b2c:	9112a021 	add	x1, x1, #0x4a8
    7b30:	f94147f8 	ldr	x24, [sp, #648]
    7b34:	d2800042 	mov	x2, #0x2                   	// #2
    7b38:	17fffd0f 	b	6f74 <fwp_write+0x210>
    7b3c:	d0000001 	adrp	x1, 9000 <_IO_stdin_used+0x30>
    7b40:	d2800042 	mov	x2, #0x2                   	// #2
    7b44:	910f8021 	add	x1, x1, #0x3e0
    7b48:	17fffea3 	b	75d4 <fwp_write+0x870>
    7b4c:	f9400a63 	ldr	x3, [x19, #16]
    7b50:	8b030021 	add	x1, x1, x3
    7b54:	17ffff66 	b	78ec <fwp_write+0xb88>
    7b58:	f9400a61 	ldr	x1, [x19, #16]
    7b5c:	8b0102a1 	add	x1, x21, x1
    7b60:	17fffdb4 	b	7230 <fwp_write+0x4cc>
    7b64:	f9400a63 	ldr	x3, [x19, #16]
    7b68:	8b030021 	add	x1, x1, x3
    7b6c:	17ffff56 	b	78c4 <fwp_write+0xb60>
    7b70:	b9404840 	ldr	w0, [x2, #72]
    7b74:	91001ff5 	add	x21, sp, #0x7
    7b78:	34ffa380 	cbz	w0, 6fe8 <fwp_write+0x284>
    7b7c:	52800503 	mov	w3, #0x28                  	// #40
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	aa1503e1 	mov	x1, x21
    7b88:	d2800022 	mov	x2, #0x1                   	// #1
    7b8c:	39001fe3 	strb	w3, [sp, #7]
    7b90:	97ffee20 	bl	3410 <buf_put>
    7b94:	b9401380 	ldr	w0, [x28, #16]
    7b98:	52800038 	mov	w24, #0x1                   	// #1
    7b9c:	7100001f 	cmp	w0, #0x0
    7ba0:	54ffa38c 	b.gt	7010 <fwp_write+0x2ac>
    7ba4:	17fffd33 	b	7070 <fwp_write+0x30c>
    7ba8:	f9014bf9 	str	x25, [sp, #656]
    7bac:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x131d0>
    7bb0:	f9014ffa 	str	x26, [sp, #664]
    7bb4:	f9400676 	ldr	x22, [x19, #8]
    7bb8:	910aa333 	add	x19, x25, #0x2a8
    7bbc:	91002273 	add	x19, x19, #0x8
    7bc0:	937ffed8 	asr	x24, x22, #63
    7bc4:	aa1802c0 	orr	x0, x22, x24
    7bc8:	b5000320 	cbnz	x0, 7c2c <fwp_write+0xec8>
    7bcc:	110006b5 	add	w21, w21, #0x1
    7bd0:	710016bf 	cmp	w21, #0x5
    7bd4:	54ffffc1 	b.ne	7bcc <fwp_write+0xe68>  // b.any
    7bd8:	b7f80578 	tbnz	x24, #63, 7c84 <fwp_write+0xf20>
    7bdc:	910023f3 	add	x19, sp, #0x8
    7be0:	aa1603e2 	mov	x2, x22
    7be4:	aa1303e0 	mov	x0, x19
    7be8:	d2800003 	mov	x3, #0x0                   	// #0
    7bec:	97ffec8d 	bl	2e20 <fwp_fmt_u128>
    7bf0:	910123f5 	add	x21, sp, #0x48
    7bf4:	d0000003 	adrp	x3, 9000 <_IO_stdin_used+0x30>
    7bf8:	aa1303e4 	mov	x4, x19
    7bfc:	aa1503e0 	mov	x0, x21
    7c00:	91128063 	add	x3, x3, #0x4a0
    7c04:	d2804002 	mov	x2, #0x200                 	// #512
    7c08:	52800041 	mov	w1, #0x2                   	// #2
    7c0c:	97ffeac5 	bl	2720 <__sprintf_chk@plt>
    7c10:	aa1503e0 	mov	x0, x21
    7c14:	97ffeabf 	bl	2710 <strlen@plt>
    7c18:	aa1503e1 	mov	x1, x21
    7c1c:	aa0003e2 	mov	x2, x0
    7c20:	aa1403e0 	mov	x0, x20
    7c24:	97ffedfb 	bl	3410 <buf_put>
    7c28:	17fffe47 	b	7544 <fwp_write+0x7e0>
    7c2c:	f9400277 	ldr	x23, [x19]
    7c30:	aa1603e0 	mov	x0, x22
    7c34:	aa1803e1 	mov	x1, x24
    7c38:	aa1703e2 	mov	x2, x23
    7c3c:	937ffefa 	asr	x26, x23, #63
    7c40:	aa1a03e3 	mov	x3, x26
    7c44:	940003fb 	bl	8c30 <__modti3>
    7c48:	aa010000 	orr	x0, x0, x1
    7c4c:	b40002c0 	cbz	x0, 7ca4 <fwp_write+0xf40>
    7c50:	110006b5 	add	w21, w21, #0x1
    7c54:	91004273 	add	x19, x19, #0x10
    7c58:	710016bf 	cmp	w21, #0x5
    7c5c:	54fffe81 	b.ne	7c2c <fwp_write+0xec8>  // b.any
    7c60:	17ffffde 	b	7bd8 <fwp_write+0xe74>
    7c64:	f9400a60 	ldr	x0, [x19, #16]
    7c68:	8b000021 	add	x1, x1, x0
    7c6c:	17fffd75 	b	7240 <fwp_write+0x4dc>
    7c70:	528c29c0 	mov	w0, #0x614e                	// #24910
    7c74:	910123f5 	add	x21, sp, #0x48
    7c78:	72a009c0 	movk	w0, #0x4e, lsl #16
    7c7c:	b9004be0 	str	w0, [sp, #72]
    7c80:	17fffda2 	b	7308 <fwp_write+0x5a4>
    7c84:	528005a1 	mov	w1, #0x2d                  	// #45
    7c88:	eb1603e2 	negs	x2, x22
    7c8c:	da1803e3 	ngc	x3, x24
    7c90:	910027e0 	add	x0, sp, #0x9
    7c94:	910023f3 	add	x19, sp, #0x8
    7c98:	390023e1 	strb	w1, [sp, #8]
    7c9c:	97ffec61 	bl	2e20 <fwp_fmt_u128>
    7ca0:	17ffffd4 	b	7bf0 <fwp_write+0xe8c>
    7ca4:	aa1703e2 	mov	x2, x23
    7ca8:	aa1a03e3 	mov	x3, x26
    7cac:	aa1603e0 	mov	x0, x22
    7cb0:	aa1803e1 	mov	x1, x24
    7cb4:	940002ff 	bl	88b0 <__divti3>
    7cb8:	aa0003e2 	mov	x2, x0
    7cbc:	aa0103e3 	mov	x3, x1
    7cc0:	b7f80201 	tbnz	x1, #63, 7d00 <fwp_write+0xf9c>
    7cc4:	910023f3 	add	x19, sp, #0x8
    7cc8:	aa1303e0 	mov	x0, x19
    7ccc:	97ffec55 	bl	2e20 <fwp_fmt_u128>
    7cd0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7cd4:	910aa339 	add	x25, x25, #0x2a8
    7cd8:	910123f5 	add	x21, sp, #0x48
    7cdc:	aa1303e4 	mov	x4, x19
    7ce0:	aa1503e0 	mov	x0, x21
    7ce4:	d0000003 	adrp	x3, 9000 <_IO_stdin_used+0x30>
    7ce8:	f8616b25 	ldr	x5, [x25, x1]
    7cec:	91126063 	add	x3, x3, #0x498
    7cf0:	d2804002 	mov	x2, #0x200                 	// #512
    7cf4:	52800041 	mov	w1, #0x2                   	// #2
    7cf8:	97ffea8a 	bl	2720 <__sprintf_chk@plt>
    7cfc:	17ffffc5 	b	7c10 <fwp_write+0xeac>
    7d00:	528005a4 	mov	w4, #0x2d                  	// #45
    7d04:	eb0003e2 	negs	x2, x0
    7d08:	da0103e3 	ngc	x3, x1
    7d0c:	910027e0 	add	x0, sp, #0x9
    7d10:	910023f3 	add	x19, sp, #0x8
    7d14:	390023e4 	strb	w4, [sp, #8]
    7d18:	97ffec42 	bl	2e20 <fwp_fmt_u128>
    7d1c:	17ffffed 	b	7cd0 <fwp_write+0xf6c>
    7d20:	f9013bf5 	str	x21, [sp, #624]
    7d24:	f9013ff6 	str	x22, [sp, #632]
    7d28:	f90143f7 	str	x23, [sp, #640]
    7d2c:	f90147f8 	str	x24, [sp, #648]
    7d30:	f9014bf9 	str	x25, [sp, #656]
    7d34:	f9014ffa 	str	x26, [sp, #664]
    7d38:	f90153fb 	str	x27, [sp, #672]
    7d3c:	f90157fc 	str	x28, [sp, #680]
    7d40:	fd015be8 	str	d8, [sp, #688]
    7d44:	fd015fe9 	str	d9, [sp, #696]
    7d48:	97ffeace 	bl	2880 <__stack_chk_fail@plt>
    7d4c:	d503201f 	nop

0000000000007d50 <fwp_main_thread>:
    7d50:	d10603ff 	sub	sp, sp, #0x180
    7d54:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7d58:	f947f400 	ldr	x0, [x0, #4072]
    7d5c:	a9127bfd 	stp	x29, x30, [sp, #288]
    7d60:	910483fd 	add	x29, sp, #0x120
    7d64:	a91563f7 	stp	x23, x24, [sp, #336]
    7d68:	d0000157 	adrp	x23, 31000 <fwp_root_context+0xcb0>
    7d6c:	9114c2e1 	add	x1, x23, #0x530
    7d70:	a9145bf5 	stp	x21, x22, [sp, #320]
    7d74:	a91773fb 	stp	x27, x28, [sp, #368]
    7d78:	b953a421 	ldr	w1, [x1, #5028]
    7d7c:	f9400002 	ldr	x2, [x0]
    7d80:	f9008fe2 	str	x2, [sp, #280]
    7d84:	d2800002 	mov	x2, #0x0                   	// #0
    7d88:	340023a1 	cbz	w1, 81fc <fwp_main_thread+0x4ac>
    7d8c:	9114c2e0 	add	x0, x23, #0x530
    7d90:	b953a800 	ldr	w0, [x0, #5032]
    7d94:	350023c0 	cbnz	w0, 820c <fwp_main_thread+0x4bc>
    7d98:	b00000d5 	adrp	x21, 20000 <__data_start>
    7d9c:	b00000c2 	adrp	x2, 20000 <__data_start>
    7da0:	9100c2bb 	add	x27, x21, #0x30
    7da4:	910d4042 	add	x2, x2, #0x350
    7da8:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    7dac:	d2a00024 	mov	x4, #0x10000               	// #65536
    7db0:	910103e0 	add	x0, sp, #0x40
    7db4:	9100a3fc 	add	x28, sp, #0x28
    7db8:	d2800001 	mov	x1, #0x0                   	// #0
    7dbc:	f90003e0 	str	x0, [sp]
    7dc0:	a9018f7c 	stp	x28, x3, [x27, #24]
    7dc4:	f90023e2 	str	x2, [sp, #64]
    7dc8:	b9004bff 	str	wzr, [sp, #72]
    7dcc:	f9002be4 	str	x4, [sp, #80]
    7dd0:	97ffea44 	bl	26e0 <sigaltstack@plt>
    7dd4:	a91353f3 	stp	x19, x20, [sp, #304]
    7dd8:	35005540 	cbnz	w0, 8880 <fwp_main_thread+0xb30>
    7ddc:	4f000400 	movi	v0.4s, #0x0
    7de0:	910223e0 	add	x0, sp, #0x88
    7de4:	90ffffe1 	adrp	x1, 3000 <fwp_flush+0x10>
    7de8:	9101c021 	add	x1, x1, #0x70
    7dec:	f90043e1 	str	x1, [sp, #128]
    7df0:	52800082 	mov	w2, #0x4                   	// #4
    7df4:	72a10002 	movk	w2, #0x800, lsl #16
    7df8:	910203f4 	add	x20, sp, #0x80
    7dfc:	3d802000 	str	q0, [x0, #128]
    7e00:	b9010be2 	str	w2, [sp, #264]
    7e04:	ad000000 	stp	q0, q0, [x0]
    7e08:	ad010000 	stp	q0, q0, [x0, #32]
    7e0c:	ad020000 	stp	q0, q0, [x0, #64]
    7e10:	ad030000 	stp	q0, q0, [x0, #96]
    7e14:	97ffea8b 	bl	2840 <sigemptyset@plt>
    7e18:	35005340 	cbnz	w0, 8880 <fwp_main_thread+0xb30>
    7e1c:	aa1403e1 	mov	x1, x20
    7e20:	d2800002 	mov	x2, #0x0                   	// #0
    7e24:	52800160 	mov	w0, #0xb                   	// #11
    7e28:	97ffea9e 	bl	28a0 <sigaction@plt>
    7e2c:	350052a0 	cbnz	w0, 8880 <fwp_main_thread+0xb30>
    7e30:	aa1403e1 	mov	x1, x20
    7e34:	d2800002 	mov	x2, #0x0                   	// #0
    7e38:	528000e0 	mov	w0, #0x7                   	// #7
    7e3c:	97ffea99 	bl	28a0 <sigaction@plt>
    7e40:	35005200 	cbnz	w0, 8880 <fwp_main_thread+0xb30>
    7e44:	b942f760 	ldr	w0, [x27, #756]
    7e48:	34001ea0 	cbz	w0, 821c <fwp_main_thread+0x4cc>
    7e4c:	9100c2b6 	add	x22, x21, #0x30
    7e50:	f9400ad4 	ldr	x20, [x22, #16]
    7e54:	b4000c94 	cbz	x20, 7fe4 <fwp_main_thread+0x294>
    7e58:	aa1403f3 	mov	x19, x20
    7e5c:	91010298 	add	x24, x20, #0x40
    7e60:	a9166bf9 	stp	x25, x26, [sp, #352]
    7e64:	52800037 	mov	w23, #0x1                   	// #1
    7e68:	39414a99 	ldrb	w25, [x20, #82]
    7e6c:	39014a97 	strb	w23, [x20, #82]
    7e70:	f9401680 	ldr	x0, [x20, #40]
    7e74:	b4000620 	cbz	x0, 7f38 <fwp_main_thread+0x1e8>
    7e78:	f9403281 	ldr	x1, [x20, #96]
    7e7c:	39414680 	ldrb	w0, [x20, #81]
    7e80:	b4000cc1 	cbz	x1, 8018 <fwp_main_thread+0x2c8>
    7e84:	36000b80 	tbz	w0, #0, 7ff4 <fwp_main_thread+0x2a4>
    7e88:	39414a62 	ldrb	w2, [x19, #82]
    7e8c:	f9402280 	ldr	x0, [x20, #64]
    7e90:	37000ee2 	tbnz	w2, #0, 806c <fwp_main_thread+0x31c>
    7e94:	f9403261 	ldr	x1, [x19, #96]
    7e98:	a911fe78 	stp	x24, xzr, [x19, #280]
    7e9c:	f9009660 	str	x0, [x19, #296]
    7ea0:	b4000040 	cbz	x0, 7ea8 <fwp_main_thread+0x158>
    7ea4:	f9009013 	str	x19, [x0, #288]
    7ea8:	f9002293 	str	x19, [x20, #64]
    7eac:	b4000101 	cbz	x1, 7ecc <fwp_main_thread+0x17c>
    7eb0:	f94046c0 	ldr	x0, [x22, #136]
    7eb4:	39015677 	strb	w23, [x19, #85]
    7eb8:	f9003661 	str	x1, [x19, #104]
    7ebc:	a910827f 	stp	xzr, x0, [x19, #264]
    7ec0:	b4000040 	cbz	x0, 7ec8 <fwp_main_thread+0x178>
    7ec4:	f9008413 	str	x19, [x0, #264]
    7ec8:	f90046d3 	str	x19, [x22, #136]
    7ecc:	39015a7f 	strb	wzr, [x19, #86]
    7ed0:	97fff92d 	bl	6384 <fwp_block>
    7ed4:	f9408e62 	ldr	x2, [x19, #280]
    7ed8:	b4000142 	cbz	x2, 7f00 <fwp_main_thread+0x1b0>
    7edc:	a9520261 	ldp	x1, x0, [x19, #288]
    7ee0:	b4000d21 	cbz	x1, 8084 <fwp_main_thread+0x334>
    7ee4:	f9009420 	str	x0, [x1, #296]
    7ee8:	f9409660 	ldr	x0, [x19, #296]
    7eec:	b4000040 	cbz	x0, 7ef4 <fwp_main_thread+0x1a4>
    7ef0:	f9009001 	str	x1, [x0, #288]
    7ef4:	91080260 	add	x0, x19, #0x200
    7ef8:	f900967f 	str	xzr, [x19, #296]
    7efc:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    7f00:	39415660 	ldrb	w0, [x19, #85]
    7f04:	f9400ac2 	ldr	x2, [x22, #16]
    7f08:	36000ae0 	tbz	w0, #0, 8064 <fwp_main_thread+0x314>
    7f0c:	a9508261 	ldp	x1, x0, [x19, #264]
    7f10:	b4000be1 	cbz	x1, 808c <fwp_main_thread+0x33c>
    7f14:	f9008820 	str	x0, [x1, #272]
    7f18:	b4000040 	cbz	x0, 7f20 <fwp_main_thread+0x1d0>
    7f1c:	f9008401 	str	x1, [x0, #264]
    7f20:	91080260 	add	x0, x19, #0x200
    7f24:	3901567f 	strb	wzr, [x19, #85]
    7f28:	aa0203f3 	mov	x19, x2
    7f2c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    7f30:	f9401680 	ldr	x0, [x20, #40]
    7f34:	b5fffa20 	cbnz	x0, 7e78 <fwp_main_thread+0x128>
    7f38:	9100c2a0 	add	x0, x21, #0x30
    7f3c:	39014a99 	strb	w25, [x20, #82]
    7f40:	a9566bf9 	ldp	x25, x26, [sp, #352]
    7f44:	f9416c00 	ldr	x0, [x0, #728]
    7f48:	b5000080 	cbnz	x0, 7f58 <fwp_main_thread+0x208>
    7f4c:	9100c2b4 	add	x20, x21, #0x30
    7f50:	f9417680 	ldr	x0, [x20, #744]
    7f54:	b4004320 	cbz	x0, 87b8 <fwp_main_thread+0xa68>
    7f58:	9100c2a0 	add	x0, x21, #0x30
    7f5c:	f9418401 	ldr	x1, [x0, #776]
    7f60:	b903001f 	str	wzr, [x0, #768]
    7f64:	eb13003f 	cmp	x1, x19
    7f68:	540043e1 	b.ne	87e4 <fwp_main_thread+0xa94>  // b.any
    7f6c:	b40009f3 	cbz	x19, 80a8 <fwp_main_thread+0x358>
    7f70:	9100c2a0 	add	x0, x21, #0x30
    7f74:	52800021 	mov	w1, #0x1                   	// #1
    7f78:	39014a61 	strb	w1, [x19, #82]
    7f7c:	f9415805 	ldr	x5, [x0, #688]
    7f80:	b4000945 	cbz	x5, 80a8 <fwp_main_thread+0x358>
    7f84:	d503201f 	nop
    7f88:	394140a0 	ldrb	w0, [x5, #80]
    7f8c:	37000060 	tbnz	w0, #0, 7f98 <fwp_main_thread+0x248>
    7f90:	aa0503e0 	mov	x0, x5
    7f94:	97ffed37 	bl	3470 <fwp_cancel_tree.part.0>
    7f98:	f9409ca5 	ldr	x5, [x5, #312]
    7f9c:	b5ffff65 	cbnz	x5, 7f88 <fwp_main_thread+0x238>
    7fa0:	9100c2b4 	add	x20, x21, #0x30
    7fa4:	52800036 	mov	w22, #0x1                   	// #1
    7fa8:	f9402a60 	ldr	x0, [x19, #80]
    7fac:	f2001c1f 	tst	x0, #0xff000000ff
    7fb0:	540000e1 	b.ne	7fcc <fwp_main_thread+0x27c>  // b.any
    7fb4:	f9401680 	ldr	x0, [x20, #40]
    7fb8:	39015276 	strb	w22, [x19, #84]
    7fbc:	f900827f 	str	xzr, [x19, #256]
    7fc0:	b40006a0 	cbz	x0, 8094 <fwp_main_thread+0x344>
    7fc4:	f9008013 	str	x19, [x0, #256]
    7fc8:	f9001693 	str	x19, [x20, #40]
    7fcc:	97fff8ee 	bl	6384 <fwp_block>
    7fd0:	97fff880 	bl	61d0 <fwp_free_zombie>
    7fd4:	f9415a80 	ldr	x0, [x20, #688]
    7fd8:	b4000680 	cbz	x0, 80a8 <fwp_main_thread+0x358>
    7fdc:	f9418693 	ldr	x19, [x20, #776]
    7fe0:	17fffff2 	b	7fa8 <fwp_main_thread+0x258>
    7fe4:	f9416ec0 	ldr	x0, [x22, #728]
    7fe8:	b50005a0 	cbnz	x0, 809c <fwp_main_thread+0x34c>
    7fec:	d2800013 	mov	x19, #0x0                   	// #0
    7ff0:	17ffffd7 	b	7f4c <fwp_main_thread+0x1fc>
    7ff4:	97ffedc3 	bl	3700 <fwp_now_ns>
    7ff8:	f9403281 	ldr	x1, [x20, #96]
    7ffc:	eb01001f 	cmp	x0, x1
    8000:	540000ab 	b.lt	8014 <fwp_main_thread+0x2c4>  // b.tstop
    8004:	39414280 	ldrb	w0, [x20, #80]
    8008:	37000060 	tbnz	w0, #0, 8014 <fwp_main_thread+0x2c4>
    800c:	aa1403e0 	mov	x0, x20
    8010:	97ffed18 	bl	3470 <fwp_cancel_tree.part.0>
    8014:	39414680 	ldrb	w0, [x20, #81]
    8018:	39414a62 	ldrb	w2, [x19, #82]
    801c:	3707f380 	tbnz	w0, #0, 7e8c <fwp_main_thread+0x13c>
    8020:	f9403281 	ldr	x1, [x20, #96]
    8024:	370001c2 	tbnz	w2, #0, 805c <fwp_main_thread+0x30c>
    8028:	f9403260 	ldr	x0, [x19, #96]
    802c:	b4000180 	cbz	x0, 805c <fwp_main_thread+0x30c>
    8030:	b4000061 	cbz	x1, 803c <fwp_main_thread+0x2ec>
    8034:	eb01001f 	cmp	x0, x1
    8038:	9a81d000 	csel	x0, x0, x1, le
    803c:	f9402281 	ldr	x1, [x20, #64]
    8040:	a911fe78 	stp	x24, xzr, [x19, #280]
    8044:	f9009661 	str	x1, [x19, #296]
    8048:	b4003b21 	cbz	x1, 87ac <fwp_main_thread+0xa5c>
    804c:	f9009033 	str	x19, [x1, #288]
    8050:	aa0003e1 	mov	x1, x0
    8054:	f9002293 	str	x19, [x20, #64]
    8058:	17ffff96 	b	7eb0 <fwp_main_thread+0x160>
    805c:	f9402280 	ldr	x0, [x20, #64]
    8060:	17ffff8e 	b	7e98 <fwp_main_thread+0x148>
    8064:	aa0203f3 	mov	x19, x2
    8068:	17ffff82 	b	7e70 <fwp_main_thread+0x120>
    806c:	a911fe78 	stp	x24, xzr, [x19, #280]
    8070:	f9009660 	str	x0, [x19, #296]
    8074:	b4000040 	cbz	x0, 807c <fwp_main_thread+0x32c>
    8078:	f9009013 	str	x19, [x0, #288]
    807c:	f9002293 	str	x19, [x20, #64]
    8080:	17ffff93 	b	7ecc <fwp_main_thread+0x17c>
    8084:	f9000040 	str	x0, [x2]
    8088:	17ffff99 	b	7eec <fwp_main_thread+0x19c>
    808c:	f90046c0 	str	x0, [x22, #136]
    8090:	17ffffa2 	b	7f18 <fwp_main_thread+0x1c8>
    8094:	f9001a93 	str	x19, [x20, #48]
    8098:	17ffffcc 	b	7fc8 <fwp_main_thread+0x278>
    809c:	f94186c0 	ldr	x0, [x22, #776]
    80a0:	b90302df 	str	wzr, [x22, #768]
    80a4:	b5003a00 	cbnz	x0, 87e4 <fwp_main_thread+0xa94>
    80a8:	9100c2b4 	add	x20, x21, #0x30
    80ac:	97fff849 	bl	61d0 <fwp_free_zombie>
    80b0:	f9401a80 	ldr	x0, [x20, #48]
    80b4:	b5003980 	cbnz	x0, 87e4 <fwp_main_thread+0xa94>
    80b8:	f9404680 	ldr	x0, [x20, #136]
    80bc:	b5003940 	cbnz	x0, 87e4 <fwp_main_thread+0xa94>
    80c0:	b940aa80 	ldr	w0, [x20, #168]
    80c4:	340001c0 	cbz	w0, 80fc <fwp_main_thread+0x3ac>
    80c8:	93407c16 	sxtw	x22, w0
    80cc:	51000400 	sub	w0, w0, #0x1
    80d0:	d1000ad6 	sub	x22, x22, #0x2
    80d4:	9102c297 	add	x23, x20, #0xb0
    80d8:	cb2042d6 	sub	x22, x22, w0, uxtw
    80dc:	93407c13 	sxtw	x19, w0
    80e0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    80e4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    80e8:	b900aa93 	str	w19, [x20, #168]
    80ec:	d1000673 	sub	x19, x19, #0x1
    80f0:	97ffea2c 	bl	29a0 <munmap@plt>
    80f4:	eb1302df 	cmp	x22, x19
    80f8:	54ffff41 	b.ne	80e0 <fwp_main_thread+0x390>  // b.any
    80fc:	900000d3 	adrp	x19, 20000 <__data_start>
    8100:	b9401260 	ldr	w0, [x19, #16]
    8104:	37f80040 	tbnz	w0, #31, 810c <fwp_main_thread+0x3bc>
    8108:	97ffe9e2 	bl	2890 <close@plt>
    810c:	9100c2a0 	add	x0, x21, #0x30
    8110:	12800001 	mov	w1, #0xffffffff            	// #-1
    8114:	b9001261 	str	w1, [x19, #16]
    8118:	d2800013 	mov	x19, #0x0                   	// #0
    811c:	f9418816 	ldr	x22, [x0, #784]
    8120:	f9418c14 	ldr	x20, [x0, #792]
    8124:	b4000176 	cbz	x22, 8150 <fwp_main_thread+0x400>
    8128:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    812c:	b40000c0 	cbz	x0, 8144 <fwp_main_thread+0x3f4>
    8130:	f9400001 	ldr	x1, [x0]
    8134:	b5003581 	cbnz	x1, 87e4 <fwp_main_thread+0xa94>
    8138:	f9400401 	ldr	x1, [x0, #8]
    813c:	b5003541 	cbnz	x1, 87e4 <fwp_main_thread+0xa94>
    8140:	97fff1ac 	bl	47f0 <fwp_mem_free>
    8144:	91000673 	add	x19, x19, #0x1
    8148:	eb16027f 	cmp	x19, x22
    814c:	54fffee1 	b.ne	8128 <fwp_main_thread+0x3d8>  // b.any
    8150:	aa1403e0 	mov	x0, x20
    8154:	97fff1a7 	bl	47f0 <fwp_mem_free>
    8158:	9100c2a0 	add	x0, x21, #0x30
    815c:	f9418413 	ldr	x19, [x0, #776]
    8160:	f901881f 	str	xzr, [x0, #784]
    8164:	f9018c1f 	str	xzr, [x0, #792]
    8168:	b40001f3 	cbz	x19, 81a4 <fwp_main_thread+0x454>
    816c:	f9401661 	ldr	x1, [x19, #40]
    8170:	b50033a1 	cbnz	x1, 87e4 <fwp_main_thread+0xa94>
    8174:	f9405661 	ldr	x1, [x19, #168]
    8178:	b5003361 	cbnz	x1, 87e4 <fwp_main_thread+0xa94>
    817c:	f9416c01 	ldr	x1, [x0, #728]
    8180:	b5003321 	cbnz	x1, 87e4 <fwp_main_thread+0xa94>
    8184:	f9417400 	ldr	x0, [x0, #744]
    8188:	b50032e0 	cbnz	x0, 87e4 <fwp_main_thread+0xa94>
    818c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8190:	90000140 	adrp	x0, 30000 <alt.5+0xfcb0>
    8194:	910d4000 	add	x0, x0, #0x350
    8198:	97ffe9ae 	bl	2850 <memset@plt>
    819c:	aa1303e0 	mov	x0, x19
    81a0:	97fff194 	bl	47f0 <fwp_mem_free>
    81a4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    81a8:	f947ec00 	ldr	x0, [x0, #4056]
    81ac:	9100c2b5 	add	x21, x21, #0x30
    81b0:	f9400000 	ldr	x0, [x0]
    81b4:	f9000abf 	str	xzr, [x21, #16]
    81b8:	f90186bf 	str	xzr, [x21, #776]
    81bc:	97ffe9fd 	bl	29b0 <fflush@plt>
    81c0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    81c4:	f947f400 	ldr	x0, [x0, #4072]
    81c8:	f9408fe2 	ldr	x2, [sp, #280]
    81cc:	f9400001 	ldr	x1, [x0]
    81d0:	eb010042 	subs	x2, x2, x1
    81d4:	d2800001 	mov	x1, #0x0                   	// #0
    81d8:	54003621 	b.ne	889c <fwp_main_thread+0xb4c>  // b.any
    81dc:	a9527bfd 	ldp	x29, x30, [sp, #288]
    81e0:	d2800000 	mov	x0, #0x0                   	// #0
    81e4:	a95353f3 	ldp	x19, x20, [sp, #304]
    81e8:	a9545bf5 	ldp	x21, x22, [sp, #320]
    81ec:	a95563f7 	ldp	x23, x24, [sp, #336]
    81f0:	a95773fb 	ldp	x27, x28, [sp, #368]
    81f4:	910603ff 	add	sp, sp, #0x180
    81f8:	d65f03c0 	ret
    81fc:	97ffef22 	bl	3e84 <fwp_heap_init>
    8200:	9114c2e0 	add	x0, x23, #0x530
    8204:	b953a800 	ldr	w0, [x0, #5032]
    8208:	34ffdc80 	cbz	w0, 7d98 <fwp_main_thread+0x48>
    820c:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    8210:	91348000 	add	x0, x0, #0xd20
    8214:	94000363 	bl	8fa0 <atexit>
    8218:	17fffee0 	b	7d98 <fwp_main_thread+0x48>
    821c:	f9416362 	ldr	x2, [x27, #704]
    8220:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8224:	913d4021 	add	x1, x1, #0xf50
    8228:	a90287e2 	stp	x2, x1, [sp, #40]
    822c:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0x15c>
    8230:	f94003e1 	ldr	x1, [sp]
    8234:	a9166bf9 	stp	x25, x26, [sp, #352]
    8238:	91218000 	add	x0, x0, #0x860
    823c:	9114c2f9 	add	x25, x23, #0x530
    8240:	d2800013 	mov	x19, #0x0                   	// #0
    8244:	d290001a 	mov	x26, #0x8000                	// #32768
    8248:	d2800016 	mov	x22, #0x0                   	// #0
    824c:	f9001fe1 	str	x1, [sp, #56]
    8250:	f90023ff 	str	xzr, [sp, #64]
    8254:	a90503ff 	stp	xzr, x0, [sp, #80]
    8258:	f901637c 	str	x28, [x27, #704]
    825c:	14000012 	b	82a4 <fwp_main_thread+0x554>
    8260:	7100045f 	cmp	w2, #0x1
    8264:	540001a1 	b.ne	8298 <fwp_main_thread+0x548>  // b.any
    8268:	29430002 	ldp	w2, w0, [x0, #24]
    826c:	92403c21 	and	x1, x1, #0xffff
    8270:	9b027c21 	mul	x1, x1, x2
    8274:	d360fc21 	lsr	x1, x1, #32
    8278:	eb00003f 	cmp	x1, x0
    827c:	540000e2 	b.cs	8298 <fwp_main_thread+0x548>  // b.hs, b.nlast
    8280:	8b01039c 	add	x28, x28, x1
    8284:	39400380 	ldrb	w0, [x28]
    8288:	7103fc1f 	cmp	w0, #0xff
    828c:	540028a0 	b.eq	87a0 <fwp_main_thread+0xa50>  // b.none
    8290:	52800020 	mov	w0, #0x1                   	// #1
    8294:	39000380 	strb	w0, [x28]
    8298:	f90023f3 	str	x19, [sp, #64]
    829c:	aa18037b 	orr	x27, x27, x24
    82a0:	b40003fb 	cbz	x27, 831c <fwp_main_thread+0x5cc>
    82a4:	f100075b 	subs	x27, x26, #0x1
    82a8:	aa1403e1 	mov	x1, x20
    82ac:	da1f02d8 	sbc	x24, x22, xzr
    82b0:	52800020 	mov	w0, #0x1                   	// #1
    82b4:	f90027fb 	str	x27, [sp, #72]
    82b8:	aa1b03fa 	mov	x26, x27
    82bc:	a9084ffb 	stp	x27, x19, [sp, #128]
    82c0:	97fff2b1 	bl	4d84 <fwp_data.part.0.constprop.0>
    82c4:	aa0003f3 	mov	x19, x0
    82c8:	f949db21 	ldr	x1, [x25, #5040]
    82cc:	aa1803f6 	mov	x22, x24
    82d0:	f949ef20 	ldr	x0, [x25, #5080]
    82d4:	cb010261 	sub	x1, x19, x1
    82d8:	eb00403f 	cmp	x1, x0, lsl #16
    82dc:	54fffde2 	b.cs	8298 <fwp_main_thread+0x548>  // b.hs, b.nlast
    82e0:	d350fc20 	lsr	x0, x1, #16
    82e4:	f949ff25 	ldr	x5, [x25, #5112]
    82e8:	8b000800 	add	x0, x0, x0, lsl #2
    82ec:	d37df002 	lsl	x2, x0, #3
    82f0:	8b0200a0 	add	x0, x5, x2
    82f4:	f940101c 	ldr	x28, [x0, #32]
    82f8:	b4fffd1c 	cbz	x28, 8298 <fwp_main_thread+0x548>
    82fc:	386268a2 	ldrb	w2, [x5, x2]
    8300:	7100085f 	cmp	w2, #0x2
    8304:	54fffae1 	b.ne	8260 <fwp_main_thread+0x510>  // b.any
    8308:	72003c3f 	tst	w1, #0xffff
    830c:	54fffbc0 	b.eq	8284 <fwp_main_thread+0x534>  // b.none
    8310:	f90023f3 	str	x19, [sp, #64]
    8314:	aa18037b 	orr	x27, x27, x24
    8318:	b5fffc7b 	cbnz	x27, 82a4 <fwp_main_thread+0x554>
    831c:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    8320:	9100c2a2 	add	x2, x21, #0x30
    8324:	f94017e3 	ldr	x3, [sp, #40]
    8328:	910183e1 	add	x1, sp, #0x60
    832c:	3dc2fc00 	ldr	q0, [x0, #3056]
    8330:	52800020 	mov	w0, #0x1                   	// #1
    8334:	f9016043 	str	x3, [x2, #704]
    8338:	3d801be0 	str	q0, [sp, #96]
    833c:	97fff292 	bl	4d84 <fwp_data.part.0.constprop.0>
    8340:	9114c2e2 	add	x2, x23, #0x530
    8344:	aa0003f9 	mov	x25, x0
    8348:	f949d841 	ldr	x1, [x2, #5040]
    834c:	f949ec40 	ldr	x0, [x2, #5080]
    8350:	cb010321 	sub	x1, x25, x1
    8354:	eb00403f 	cmp	x1, x0, lsl #16
    8358:	54000322 	b.cs	83bc <fwp_main_thread+0x66c>  // b.hs, b.nlast
    835c:	d350fc20 	lsr	x0, x1, #16
    8360:	f949fc43 	ldr	x3, [x2, #5112]
    8364:	8b000800 	add	x0, x0, x0, lsl #2
    8368:	d37df002 	lsl	x2, x0, #3
    836c:	8b020060 	add	x0, x3, x2
    8370:	f9401016 	ldr	x22, [x0, #32]
    8374:	b4000256 	cbz	x22, 83bc <fwp_main_thread+0x66c>
    8378:	38626862 	ldrb	w2, [x3, x2]
    837c:	7100085f 	cmp	w2, #0x2
    8380:	540020a0 	b.eq	8794 <fwp_main_thread+0xa44>  // b.none
    8384:	7100045f 	cmp	w2, #0x1
    8388:	540001a1 	b.ne	83bc <fwp_main_thread+0x66c>  // b.any
    838c:	29430002 	ldp	w2, w0, [x0, #24]
    8390:	92403c21 	and	x1, x1, #0xffff
    8394:	9b027c21 	mul	x1, x1, x2
    8398:	d360fc21 	lsr	x1, x1, #32
    839c:	eb00003f 	cmp	x1, x0
    83a0:	540000e2 	b.cs	83bc <fwp_main_thread+0x66c>  // b.hs, b.nlast
    83a4:	8b0102d6 	add	x22, x22, x1
    83a8:	394002c0 	ldrb	w0, [x22]
    83ac:	7103fc1f 	cmp	w0, #0xff
    83b0:	54002620 	b.eq	8874 <fwp_main_thread+0xb24>  // b.none
    83b4:	52800020 	mov	w0, #0x1                   	// #1
    83b8:	390002c0 	strb	w0, [x22]
    83bc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    83c0:	aa1403e1 	mov	x1, x20
    83c4:	52800020 	mov	w0, #0x1                   	// #1
    83c8:	a90867e2 	stp	x2, x25, [sp, #128]
    83cc:	97fff26e 	bl	4d84 <fwp_data.part.0.constprop.0>
    83d0:	9114c2e2 	add	x2, x23, #0x530
    83d4:	aa0003f6 	mov	x22, x0
    83d8:	f949d841 	ldr	x1, [x2, #5040]
    83dc:	f949ec40 	ldr	x0, [x2, #5080]
    83e0:	cb0102c1 	sub	x1, x22, x1
    83e4:	eb00403f 	cmp	x1, x0, lsl #16
    83e8:	54000322 	b.cs	844c <fwp_main_thread+0x6fc>  // b.hs, b.nlast
    83ec:	d350fc20 	lsr	x0, x1, #16
    83f0:	f949fc43 	ldr	x3, [x2, #5112]
    83f4:	8b000800 	add	x0, x0, x0, lsl #2
    83f8:	d37df002 	lsl	x2, x0, #3
    83fc:	8b020060 	add	x0, x3, x2
    8400:	f9401014 	ldr	x20, [x0, #32]
    8404:	b4000254 	cbz	x20, 844c <fwp_main_thread+0x6fc>
    8408:	38626862 	ldrb	w2, [x3, x2]
    840c:	7100085f 	cmp	w2, #0x2
    8410:	54001bc0 	b.eq	8788 <fwp_main_thread+0xa38>  // b.none
    8414:	7100045f 	cmp	w2, #0x1
    8418:	540001a1 	b.ne	844c <fwp_main_thread+0x6fc>  // b.any
    841c:	29430002 	ldp	w2, w0, [x0, #24]
    8420:	92403c21 	and	x1, x1, #0xffff
    8424:	9b027c21 	mul	x1, x1, x2
    8428:	d360fc21 	lsr	x1, x1, #32
    842c:	eb00003f 	cmp	x1, x0
    8430:	540000e2 	b.cs	844c <fwp_main_thread+0x6fc>  // b.hs, b.nlast
    8434:	8b010294 	add	x20, x20, x1
    8438:	39400280 	ldrb	w0, [x20]
    843c:	7103fc1f 	cmp	w0, #0xff
    8440:	540020e0 	b.eq	885c <fwp_main_thread+0xb0c>  // b.none
    8444:	52800020 	mov	w0, #0x1                   	// #1
    8448:	39000280 	strb	w0, [x20]
    844c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8450:	9101c3e1 	add	x1, sp, #0x70
    8454:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8458:	52800020 	mov	w0, #0x1                   	// #1
    845c:	a9075be2 	stp	x2, x22, [sp, #112]
    8460:	97fff249 	bl	4d84 <fwp_data.part.0.constprop.0>
    8464:	9114c2e2 	add	x2, x23, #0x530
    8468:	aa0003f4 	mov	x20, x0
    846c:	f949d841 	ldr	x1, [x2, #5040]
    8470:	f949ec40 	ldr	x0, [x2, #5080]
    8474:	cb010281 	sub	x1, x20, x1
    8478:	eb00403f 	cmp	x1, x0, lsl #16
    847c:	54000322 	b.cs	84e0 <fwp_main_thread+0x790>  // b.hs, b.nlast
    8480:	d350fc20 	lsr	x0, x1, #16
    8484:	f949fc43 	ldr	x3, [x2, #5112]
    8488:	8b000800 	add	x0, x0, x0, lsl #2
    848c:	d37df002 	lsl	x2, x0, #3
    8490:	8b020060 	add	x0, x3, x2
    8494:	f9401016 	ldr	x22, [x0, #32]
    8498:	b4000256 	cbz	x22, 84e0 <fwp_main_thread+0x790>
    849c:	38626862 	ldrb	w2, [x3, x2]
    84a0:	7100085f 	cmp	w2, #0x2
    84a4:	54001640 	b.eq	876c <fwp_main_thread+0xa1c>  // b.none
    84a8:	7100045f 	cmp	w2, #0x1
    84ac:	540001a1 	b.ne	84e0 <fwp_main_thread+0x790>  // b.any
    84b0:	29430002 	ldp	w2, w0, [x0, #24]
    84b4:	92403c21 	and	x1, x1, #0xffff
    84b8:	9b027c21 	mul	x1, x1, x2
    84bc:	d360fc21 	lsr	x1, x1, #32
    84c0:	eb00003f 	cmp	x1, x0
    84c4:	540000e2 	b.cs	84e0 <fwp_main_thread+0x790>  // b.hs, b.nlast
    84c8:	8b0102d6 	add	x22, x22, x1
    84cc:	394002c0 	ldrb	w0, [x22]
    84d0:	7103fc1f 	cmp	w0, #0xff
    84d4:	54001ca0 	b.eq	8868 <fwp_main_thread+0xb18>  // b.none
    84d8:	52800020 	mov	w0, #0x1                   	// #1
    84dc:	390002c0 	strb	w0, [x22]
    84e0:	aa1303f6 	mov	x22, x19
    84e4:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x131d0>
    84e8:	b4001173 	cbz	x19, 8714 <fwp_main_thread+0x9c4>
    84ec:	910aa000 	add	x0, x0, #0x2a8
    84f0:	9114c2fb 	add	x27, x23, #0x530
    84f4:	91014000 	add	x0, x0, #0x50
    84f8:	b000001a 	adrp	x26, 9000 <_IO_stdin_used+0x30>
    84fc:	52800038 	mov	w24, #0x1                   	// #1
    8500:	f90007e0 	str	x0, [sp, #8]
    8504:	91252340 	add	x0, x26, #0x948
    8508:	f9000be0 	str	x0, [sp, #16]
    850c:	f949db61 	ldr	x1, [x27, #5040]
    8510:	f949ef60 	ldr	x0, [x27, #5080]
    8514:	cb010281 	sub	x1, x20, x1
    8518:	eb00403f 	cmp	x1, x0, lsl #16
    851c:	54000342 	b.cs	8584 <fwp_main_thread+0x834>  // b.hs, b.nlast
    8520:	d350fc20 	lsr	x0, x1, #16
    8524:	f949ff65 	ldr	x5, [x27, #5112]
    8528:	8b000800 	add	x0, x0, x0, lsl #2
    852c:	d37df002 	lsl	x2, x0, #3
    8530:	8b0200a3 	add	x3, x5, x2
    8534:	f9401060 	ldr	x0, [x3, #32]
    8538:	b4000260 	cbz	x0, 8584 <fwp_main_thread+0x834>
    853c:	386268a2 	ldrb	w2, [x5, x2]
    8540:	7100085f 	cmp	w2, #0x2
    8544:	54001020 	b.eq	8748 <fwp_main_thread+0x9f8>  // b.none
    8548:	7100045f 	cmp	w2, #0x1
    854c:	540001c1 	b.ne	8584 <fwp_main_thread+0x834>  // b.any
    8550:	29430865 	ldp	w5, w2, [x3, #24]
    8554:	92403c21 	and	x1, x1, #0xffff
    8558:	9b057c21 	mul	x1, x1, x5
    855c:	d360fc21 	lsr	x1, x1, #32
    8560:	eb02003f 	cmp	x1, x2
    8564:	54000102 	b.cs	8584 <fwp_main_thread+0x834>  // b.hs, b.nlast
    8568:	8b010000 	add	x0, x0, x1
    856c:	39400001 	ldrb	w1, [x0]
    8570:	340000a1 	cbz	w1, 8584 <fwp_main_thread+0x834>
    8574:	7103f43f 	cmp	w1, #0xfd
    8578:	54001688 	b.hi	8848 <fwp_main_thread+0xaf8>  // b.pmore
    857c:	11000421 	add	w1, w1, #0x1
    8580:	39000001 	strb	w1, [x0]
    8584:	a9400be0 	ldp	x0, x2, [sp]
    8588:	aa1403e1 	mov	x1, x20
    858c:	52800023 	mov	w3, #0x1                   	// #1
    8590:	a9047fff 	stp	xzr, xzr, [sp, #64]
    8594:	f9002bff 	str	xzr, [sp, #80]
    8598:	97fff9f3 	bl	6d64 <fwp_write>
    859c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    85a0:	f9400be0 	ldr	x0, [sp, #16]
    85a4:	f100033f 	cmp	x25, #0x0
    85a8:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    85ac:	b1002b5f 	cmn	x26, #0xa
    85b0:	540017a8 	b.hi	88a4 <fwp_main_thread+0xb54>  // b.pmore
    85b4:	52800021 	mov	w1, #0x1                   	// #1
    85b8:	91002740 	add	x0, x26, #0x9
    85bc:	97fff1ad 	bl	4c70 <fwp_heap_alloc>
    85c0:	aa0003fc 	mov	x28, x0
    85c4:	aa1903e1 	mov	x1, x25
    85c8:	aa0003f9 	mov	x25, x0
    85cc:	aa1a03e2 	mov	x2, x26
    85d0:	f800873a 	str	x26, [x25], #8
    85d4:	aa1903e0 	mov	x0, x25
    85d8:	97ffe83e 	bl	26d0 <memcpy@plt>
    85dc:	8b1a0382 	add	x2, x28, x26
    85e0:	3900205f 	strb	wzr, [x2, #8]
    85e4:	f94023e0 	ldr	x0, [sp, #64]
    85e8:	97ffe8d6 	bl	2940 <free@plt>
    85ec:	f949db62 	ldr	x2, [x27, #5040]
    85f0:	f949ef60 	ldr	x0, [x27, #5080]
    85f4:	cb020382 	sub	x2, x28, x2
    85f8:	eb00405f 	cmp	x2, x0, lsl #16
    85fc:	54000302 	b.cs	865c <fwp_main_thread+0x90c>  // b.hs, b.nlast
    8600:	d350fc40 	lsr	x0, x2, #16
    8604:	f949ff66 	ldr	x6, [x27, #5112]
    8608:	8b000800 	add	x0, x0, x0, lsl #2
    860c:	d37df001 	lsl	x1, x0, #3
    8610:	8b0100c5 	add	x5, x6, x1
    8614:	f94010a0 	ldr	x0, [x5, #32]
    8618:	b4000220 	cbz	x0, 865c <fwp_main_thread+0x90c>
    861c:	386168c1 	ldrb	w1, [x6, x1]
    8620:	7100083f 	cmp	w1, #0x2
    8624:	54000980 	b.eq	8754 <fwp_main_thread+0xa04>  // b.none
    8628:	7100043f 	cmp	w1, #0x1
    862c:	54000181 	b.ne	865c <fwp_main_thread+0x90c>  // b.any
    8630:	92403c41 	and	x1, x2, #0xffff
    8634:	294308a6 	ldp	w6, w2, [x5, #24]
    8638:	9b067c21 	mul	x1, x1, x6
    863c:	d360fc21 	lsr	x1, x1, #32
    8640:	eb02003f 	cmp	x1, x2
    8644:	540000c2 	b.cs	865c <fwp_main_thread+0x90c>  // b.hs, b.nlast
    8648:	8b010000 	add	x0, x0, x1
    864c:	39400001 	ldrb	w1, [x0]
    8650:	7103fc3f 	cmp	w1, #0xff
    8654:	54000920 	b.eq	8778 <fwp_main_thread+0xa28>  // b.none
    8658:	39000018 	strb	w24, [x0]
    865c:	aa1403e0 	mov	x0, x20
    8660:	97fff42c 	bl	5710 <fwp_drop0>
    8664:	9100c2a5 	add	x5, x21, #0x30
    8668:	aa1903e0 	mov	x0, x25
    866c:	f9400382 	ldr	x2, [x28]
    8670:	aa0503f9 	mov	x25, x5
    8674:	f94004a3 	ldr	x3, [x5, #8]
    8678:	d2800021 	mov	x1, #0x1                   	// #1
    867c:	97ffe8c1 	bl	2980 <fwrite@plt>
    8680:	f9400721 	ldr	x1, [x25, #8]
    8684:	52800140 	mov	w0, #0xa                   	// #10
    8688:	97ffe846 	bl	27a0 <fputc@plt>
    868c:	f949db62 	ldr	x2, [x27, #5040]
    8690:	f949ef60 	ldr	x0, [x27, #5080]
    8694:	cb020382 	sub	x2, x28, x2
    8698:	eb00405f 	cmp	x2, x0, lsl #16
    869c:	54000382 	b.cs	870c <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    86a0:	d350fc40 	lsr	x0, x2, #16
    86a4:	f949ff65 	ldr	x5, [x27, #5112]
    86a8:	8b000800 	add	x0, x0, x0, lsl #2
    86ac:	d37df001 	lsl	x1, x0, #3
    86b0:	8b0100a3 	add	x3, x5, x1
    86b4:	f9401060 	ldr	x0, [x3, #32]
    86b8:	b40002a0 	cbz	x0, 870c <fwp_main_thread+0x9bc>
    86bc:	386168a1 	ldrb	w1, [x5, x1]
    86c0:	7100083f 	cmp	w1, #0x2
    86c4:	540004e0 	b.eq	8760 <fwp_main_thread+0xa10>  // b.none
    86c8:	7100043f 	cmp	w1, #0x1
    86cc:	54000201 	b.ne	870c <fwp_main_thread+0x9bc>  // b.any
    86d0:	92403c41 	and	x1, x2, #0xffff
    86d4:	29430865 	ldp	w5, w2, [x3, #24]
    86d8:	9b057c21 	mul	x1, x1, x5
    86dc:	d360fc21 	lsr	x1, x1, #32
    86e0:	eb02003f 	cmp	x1, x2
    86e4:	54000142 	b.cs	870c <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    86e8:	8b010000 	add	x0, x0, x1
    86ec:	39400001 	ldrb	w1, [x0]
    86f0:	340000e1 	cbz	w1, 870c <fwp_main_thread+0x9bc>
    86f4:	7100043f 	cmp	w1, #0x1
    86f8:	54000220 	b.eq	873c <fwp_main_thread+0x9ec>  // b.none
    86fc:	7103fc3f 	cmp	w1, #0xff
    8700:	54000760 	b.eq	87ec <fwp_main_thread+0xa9c>  // b.none
    8704:	51000421 	sub	w1, w1, #0x1
    8708:	39000001 	strb	w1, [x0]
    870c:	f9400ad6 	ldr	x22, [x22, #16]
    8710:	b5ffeff6 	cbnz	x22, 850c <fwp_main_thread+0x7bc>
    8714:	aa1403e0 	mov	x0, x20
    8718:	97fff3fe 	bl	5710 <fwp_drop0>
    871c:	aa1303e0 	mov	x0, x19
    8720:	97fff3fc 	bl	5710 <fwp_drop0>
    8724:	9100c2a0 	add	x0, x21, #0x30
    8728:	52800021 	mov	w1, #0x1                   	// #1
    872c:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8730:	b902f401 	str	w1, [x0, #756]
    8734:	f9017c1f 	str	xzr, [x0, #760]
    8738:	17fffdc5 	b	7e4c <fwp_main_thread+0xfc>
    873c:	aa1c03e0 	mov	x0, x28
    8740:	97fff31d 	bl	53b4 <fwp_rc_free_arr>
    8744:	17fffff2 	b	870c <fwp_main_thread+0x9bc>
    8748:	72003c3f 	tst	w1, #0xffff
    874c:	54fff1c1 	b.ne	8584 <fwp_main_thread+0x834>  // b.any
    8750:	17ffff87 	b	856c <fwp_main_thread+0x81c>
    8754:	72003c5f 	tst	w2, #0xffff
    8758:	54fff821 	b.ne	865c <fwp_main_thread+0x90c>  // b.any
    875c:	17ffffbc 	b	864c <fwp_main_thread+0x8fc>
    8760:	72003c5f 	tst	w2, #0xffff
    8764:	54fffd41 	b.ne	870c <fwp_main_thread+0x9bc>  // b.any
    8768:	17ffffe1 	b	86ec <fwp_main_thread+0x99c>
    876c:	72003c3f 	tst	w1, #0xffff
    8770:	54ffeb81 	b.ne	84e0 <fwp_main_thread+0x790>  // b.any
    8774:	17ffff56 	b	84cc <fwp_main_thread+0x77c>
    8778:	f9000fe0 	str	x0, [sp, #24]
    877c:	97ffef7d 	bl	4570 <fwp_rc_forget_slot>
    8780:	f9400fe0 	ldr	x0, [sp, #24]
    8784:	17ffffb5 	b	8658 <fwp_main_thread+0x908>
    8788:	72003c3f 	tst	w1, #0xffff
    878c:	54ffe601 	b.ne	844c <fwp_main_thread+0x6fc>  // b.any
    8790:	17ffff2a 	b	8438 <fwp_main_thread+0x6e8>
    8794:	72003c3f 	tst	w1, #0xffff
    8798:	54ffe121 	b.ne	83bc <fwp_main_thread+0x66c>  // b.any
    879c:	17ffff03 	b	83a8 <fwp_main_thread+0x658>
    87a0:	aa1c03e0 	mov	x0, x28
    87a4:	97ffef73 	bl	4570 <fwp_rc_forget_slot>
    87a8:	17fffeba 	b	8290 <fwp_main_thread+0x540>
    87ac:	aa0003e1 	mov	x1, x0
    87b0:	f9002293 	str	x19, [x20, #64]
    87b4:	17fffdbf 	b	7eb0 <fwp_main_thread+0x160>
    87b8:	f9416a80 	ldr	x0, [x20, #720]
    87bc:	97fff00d 	bl	47f0 <fwp_mem_free>
    87c0:	f9016a9f 	str	xzr, [x20, #720]
    87c4:	f901729f 	str	xzr, [x20, #736]
    87c8:	f9418680 	ldr	x0, [x20, #776]
    87cc:	b4000433 	cbz	x19, 8850 <fwp_main_thread+0xb00>
    87d0:	f900567f 	str	xzr, [x19, #168]
    87d4:	f9005e7f 	str	xzr, [x19, #184]
    87d8:	b903029f 	str	wzr, [x20, #768]
    87dc:	eb13001f 	cmp	x0, x19
    87e0:	54ffbc80 	b.eq	7f70 <fwp_main_thread+0x220>  // b.none
    87e4:	a9166bf9 	stp	x25, x26, [sp, #352]
    87e8:	97ffe83a 	bl	28d0 <abort@plt>
    87ec:	ca404401 	eor	x1, x0, x0, lsr #17
    87f0:	9114c2e2 	add	x2, x23, #0x530
    87f4:	ca412421 	eor	x1, x1, x1, lsr #9
    87f8:	8b210c41 	add	x1, x2, w1, uxtb #3
    87fc:	f94a2421 	ldr	x1, [x1, #5192]
    8800:	b5000081 	cbnz	x1, 8810 <fwp_main_thread+0xac0>
    8804:	14000023 	b	8890 <fwp_main_thread+0xb40>
    8808:	f9400821 	ldr	x1, [x1, #16]
    880c:	b4000421 	cbz	x1, 8890 <fwp_main_thread+0xb40>
    8810:	f9400022 	ldr	x2, [x1]
    8814:	eb02001f 	cmp	x0, x2
    8818:	54ffff81 	b.ne	8808 <fwp_main_thread+0xab8>  // b.any
    881c:	f9400422 	ldr	x2, [x1, #8]
    8820:	d1000442 	sub	x2, x2, #0x1
    8824:	f9000422 	str	x2, [x1, #8]
    8828:	f103f85f 	cmp	x2, #0xfe
    882c:	54fff701 	b.ne	870c <fwp_main_thread+0x9bc>  // b.any
    8830:	f9000fe0 	str	x0, [sp, #24]
    8834:	97ffef4f 	bl	4570 <fwp_rc_forget_slot>
    8838:	f9400fe0 	ldr	x0, [sp, #24]
    883c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    8840:	39000001 	strb	w1, [x0]
    8844:	17ffffb2 	b	870c <fwp_main_thread+0x9bc>
    8848:	97ffef03 	bl	4454 <fwp_rc_wide_dup>
    884c:	17ffff4e 	b	8584 <fwp_main_thread+0x834>
    8850:	b903029f 	str	wzr, [x20, #768]
    8854:	b4ffc2a0 	cbz	x0, 80a8 <fwp_main_thread+0x358>
    8858:	17ffffe3 	b	87e4 <fwp_main_thread+0xa94>
    885c:	aa1403e0 	mov	x0, x20
    8860:	97ffef44 	bl	4570 <fwp_rc_forget_slot>
    8864:	17fffef8 	b	8444 <fwp_main_thread+0x6f4>
    8868:	aa1603e0 	mov	x0, x22
    886c:	97ffef41 	bl	4570 <fwp_rc_forget_slot>
    8870:	17ffff1a 	b	84d8 <fwp_main_thread+0x788>
    8874:	aa1603e0 	mov	x0, x22
    8878:	97ffef3e 	bl	4570 <fwp_rc_forget_slot>
    887c:	17fffece 	b	83b4 <fwp_main_thread+0x664>
    8880:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    8884:	9112e000 	add	x0, x0, #0x4b8
    8888:	a9166bf9 	stp	x25, x26, [sp, #352]
    888c:	97ffeb3d 	bl	3580 <fwp_trap>
    8890:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    8894:	9109e000 	add	x0, x0, #0x278
    8898:	97ffeb3a 	bl	3580 <fwp_trap>
    889c:	a9166bf9 	stp	x25, x26, [sp, #352]
    88a0:	97ffe7f8 	bl	2880 <__stack_chk_fail@plt>
    88a4:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x30>
    88a8:	91138000 	add	x0, x0, #0x4e0
    88ac:	97ffeb35 	bl	3580 <fwp_trap>

00000000000088b0 <__divti3>:
    88b0:	d503245f 	bti	c
    88b4:	d2800004 	mov	x4, #0x0                   	// #0
    88b8:	b7f80721 	tbnz	x1, #63, 899c <__divti3+0xec>
    88bc:	b6f80083 	tbz	x3, #63, 88cc <__divti3+0x1c>
    88c0:	eb0203e2 	negs	x2, x2
    88c4:	aa2403e4 	mvn	x4, x4
    88c8:	da0303e3 	ngc	x3, x3
    88cc:	aa0203e6 	mov	x6, x2
    88d0:	aa0003e7 	mov	x7, x0
    88d4:	aa0103e5 	mov	x5, x1
    88d8:	b5000583 	cbnz	x3, 8988 <__divti3+0xd8>
    88dc:	eb01005f 	cmp	x2, x1
    88e0:	54000e69 	b.ls	8aac <__divti3+0x1fc>  // b.plast
    88e4:	dac01040 	clz	x0, x2
    88e8:	b40000e0 	cbz	x0, 8904 <__divti3+0x54>
    88ec:	4b0003e1 	neg	w1, w0
    88f0:	9ac020a5 	lsl	x5, x5, x0
    88f4:	9ac02046 	lsl	x6, x2, x0
    88f8:	9ac124e1 	lsr	x1, x7, x1
    88fc:	aa050025 	orr	x5, x1, x5
    8900:	9ac020e7 	lsl	x7, x7, x0
    8904:	d360fcc8 	lsr	x8, x6, #32
    8908:	92407cc2 	and	x2, x6, #0xffffffff
    890c:	9ac808a3 	udiv	x3, x5, x8
    8910:	9b089465 	msub	x5, x3, x8, x5
    8914:	aa0303e0 	mov	x0, x3
    8918:	9b037c41 	mul	x1, x2, x3
    891c:	93c780a5 	extr	x5, x5, x7, #32
    8920:	eb05003f 	cmp	x1, x5
    8924:	540000a9 	b.ls	8938 <__divti3+0x88>  // b.plast
    8928:	ab0500c5 	adds	x5, x6, x5
    892c:	d1000460 	sub	x0, x3, #0x1
    8930:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8934:	540015a8 	b.hi	8be8 <__divti3+0x338>  // b.pmore
    8938:	cb0100a5 	sub	x5, x5, x1
    893c:	9ac808a3 	udiv	x3, x5, x8
    8940:	9b089465 	msub	x5, x3, x8, x5
    8944:	aa0303e1 	mov	x1, x3
    8948:	9b037c42 	mul	x2, x2, x3
    894c:	aa0703e3 	mov	x3, x7
    8950:	b3607ca3 	bfi	x3, x5, #32, #32
    8954:	eb03005f 	cmp	x2, x3
    8958:	540000c9 	b.ls	8970 <__divti3+0xc0>  // b.plast
    895c:	ab0300c3 	adds	x3, x6, x3
    8960:	d1000425 	sub	x5, x1, #0x1
    8964:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8968:	d1000821 	sub	x1, x1, #0x2
    896c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8970:	aa008020 	orr	x0, x1, x0, lsl #32
    8974:	d2800001 	mov	x1, #0x0                   	// #0
    8978:	b4000064 	cbz	x4, 8984 <__divti3+0xd4>
    897c:	eb0003e0 	negs	x0, x0
    8980:	da0103e1 	ngc	x1, x1
    8984:	d65f03c0 	ret
    8988:	eb01007f 	cmp	x3, x1
    898c:	54000109 	b.ls	89ac <__divti3+0xfc>  // b.plast
    8990:	d2800001 	mov	x1, #0x0                   	// #0
    8994:	d2800000 	mov	x0, #0x0                   	// #0
    8998:	17fffff8 	b	8978 <__divti3+0xc8>
    899c:	eb0003e0 	negs	x0, x0
    89a0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    89a4:	da0103e1 	ngc	x1, x1
    89a8:	17ffffc5 	b	88bc <__divti3+0xc>
    89ac:	dac01067 	clz	x7, x3
    89b0:	b40010e7 	cbz	x7, 8bcc <__divti3+0x31c>
    89b4:	d2800805 	mov	x5, #0x40                  	// #64
    89b8:	cb0700a5 	sub	x5, x5, x7
    89bc:	9ac72063 	lsl	x3, x3, x7
    89c0:	9ac52448 	lsr	x8, x2, x5
    89c4:	aa030108 	orr	x8, x8, x3
    89c8:	9ac52426 	lsr	x6, x1, x5
    89cc:	92407d0a 	and	x10, x8, #0xffffffff
    89d0:	d360fd09 	lsr	x9, x8, #32
    89d4:	9ac52403 	lsr	x3, x0, x5
    89d8:	9ac72021 	lsl	x1, x1, x7
    89dc:	aa010063 	orr	x3, x3, x1
    89e0:	9ac72042 	lsl	x2, x2, x7
    89e4:	9ac908cb 	udiv	x11, x6, x9
    89e8:	9b099965 	msub	x5, x11, x9, x6
    89ec:	aa0b03e1 	mov	x1, x11
    89f0:	9b0b7d46 	mul	x6, x10, x11
    89f4:	93c380a5 	extr	x5, x5, x3, #32
    89f8:	eb0500df 	cmp	x6, x5
    89fc:	540000a9 	b.ls	8a10 <__divti3+0x160>  // b.plast
    8a00:	ab050105 	adds	x5, x8, x5
    8a04:	d1000561 	sub	x1, x11, #0x1
    8a08:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8a0c:	54000f48 	b.hi	8bf4 <__divti3+0x344>  // b.pmore
    8a10:	cb0600a6 	sub	x6, x5, x6
    8a14:	9ac908cb 	udiv	x11, x6, x9
    8a18:	9b099969 	msub	x9, x11, x9, x6
    8a1c:	aa0b03e5 	mov	x5, x11
    8a20:	9b0b7d4a 	mul	x10, x10, x11
    8a24:	b3607d23 	bfi	x3, x9, #32, #32
    8a28:	eb03015f 	cmp	x10, x3
    8a2c:	540000a9 	b.ls	8a40 <__divti3+0x190>  // b.plast
    8a30:	ab030103 	adds	x3, x8, x3
    8a34:	d1000565 	sub	x5, x11, #0x1
    8a38:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8a3c:	54000e28 	b.hi	8c00 <__divti3+0x350>  // b.pmore
    8a40:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8a44:	92407c48 	and	x8, x2, #0xffffffff
    8a48:	2a0503e5 	mov	w5, w5
    8a4c:	d360fc42 	lsr	x2, x2, #32
    8a50:	d360fc26 	lsr	x6, x1, #32
    8a54:	cb0a0063 	sub	x3, x3, x10
    8a58:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8a5c:	9b087caa 	mul	x10, x5, x8
    8a60:	9b087cc8 	mul	x8, x6, x8
    8a64:	9b0220a5 	madd	x5, x5, x2, x8
    8a68:	9b027cc6 	mul	x6, x6, x2
    8a6c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8a70:	8b0900c5 	add	x5, x6, x9
    8a74:	eb02011f 	cmp	x8, x2
    8a78:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8a7c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8a80:	eb06007f 	cmp	x3, x6
    8a84:	540000e3 	b.cc	8aa0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8a88:	92407d4a 	and	x10, x10, #0xffffffff
    8a8c:	9ac72000 	lsl	x0, x0, x7
    8a90:	8b028142 	add	x2, x10, x2, lsl #32
    8a94:	eb02001f 	cmp	x0, x2
    8a98:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8a9c:	54000a01 	b.ne	8bdc <__divti3+0x32c>  // b.any
    8aa0:	d1000420 	sub	x0, x1, #0x1
    8aa4:	d2800001 	mov	x1, #0x0                   	// #0
    8aa8:	17ffffb4 	b	8978 <__divti3+0xc8>
    8aac:	b5000062 	cbnz	x2, 8ab8 <__divti3+0x208>
    8ab0:	d2800022 	mov	x2, #0x1                   	// #1
    8ab4:	9ac30846 	udiv	x6, x2, x3
    8ab8:	dac010c8 	clz	x8, x6
    8abc:	b5000408 	cbnz	x8, 8b3c <__divti3+0x28c>
    8ac0:	d360fcc9 	lsr	x9, x6, #32
    8ac4:	92407cc5 	and	x5, x6, #0xffffffff
    8ac8:	cb060023 	sub	x3, x1, x6
    8acc:	d2800021 	mov	x1, #0x1                   	// #1
    8ad0:	9ac90868 	udiv	x8, x3, x9
    8ad4:	9b098d03 	msub	x3, x8, x9, x3
    8ad8:	aa0803e0 	mov	x0, x8
    8adc:	9b057d02 	mul	x2, x8, x5
    8ae0:	93c78063 	extr	x3, x3, x7, #32
    8ae4:	eb03005f 	cmp	x2, x3
    8ae8:	540000a9 	b.ls	8afc <__divti3+0x24c>  // b.plast
    8aec:	ab0300c3 	adds	x3, x6, x3
    8af0:	d1000500 	sub	x0, x8, #0x1
    8af4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8af8:	54000968 	b.hi	8c24 <__divti3+0x374>  // b.pmore
    8afc:	cb020063 	sub	x3, x3, x2
    8b00:	9ac90862 	udiv	x2, x3, x9
    8b04:	aa0203e8 	mov	x8, x2
    8b08:	9b098c42 	msub	x2, x2, x9, x3
    8b0c:	aa0703e3 	mov	x3, x7
    8b10:	9b057d05 	mul	x5, x8, x5
    8b14:	b3607c43 	bfi	x3, x2, #32, #32
    8b18:	eb0300bf 	cmp	x5, x3
    8b1c:	540000c9 	b.ls	8b34 <__divti3+0x284>  // b.plast
    8b20:	ab0300c2 	adds	x2, x6, x3
    8b24:	d1000503 	sub	x3, x8, #0x1
    8b28:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8b2c:	d1000908 	sub	x8, x8, #0x2
    8b30:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8b34:	aa008100 	orr	x0, x8, x0, lsl #32
    8b38:	17ffff90 	b	8978 <__divti3+0xc8>
    8b3c:	9ac820c6 	lsl	x6, x6, x8
    8b40:	d2800803 	mov	x3, #0x40                  	// #64
    8b44:	cb080063 	sub	x3, x3, x8
    8b48:	d360fcc9 	lsr	x9, x6, #32
    8b4c:	9ac82027 	lsl	x7, x1, x8
    8b50:	92407cc5 	and	x5, x6, #0xffffffff
    8b54:	9ac32422 	lsr	x2, x1, x3
    8b58:	9ac32403 	lsr	x3, x0, x3
    8b5c:	aa070063 	orr	x3, x3, x7
    8b60:	9ac9084a 	udiv	x10, x2, x9
    8b64:	9ac82007 	lsl	x7, x0, x8
    8b68:	9b098940 	msub	x0, x10, x9, x2
    8b6c:	aa0a03e1 	mov	x1, x10
    8b70:	9b0a7ca2 	mul	x2, x5, x10
    8b74:	93c38000 	extr	x0, x0, x3, #32
    8b78:	eb00005f 	cmp	x2, x0
    8b7c:	540000a9 	b.ls	8b90 <__divti3+0x2e0>  // b.plast
    8b80:	ab0000c0 	adds	x0, x6, x0
    8b84:	d1000541 	sub	x1, x10, #0x1
    8b88:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    8b8c:	54000468 	b.hi	8c18 <__divti3+0x368>  // b.pmore
    8b90:	cb020000 	sub	x0, x0, x2
    8b94:	9ac9080a 	udiv	x10, x0, x9
    8b98:	9b098140 	msub	x0, x10, x9, x0
    8b9c:	aa0a03e2 	mov	x2, x10
    8ba0:	9b0a7ca8 	mul	x8, x5, x10
    8ba4:	b3607c03 	bfi	x3, x0, #32, #32
    8ba8:	eb03011f 	cmp	x8, x3
    8bac:	540000a9 	b.ls	8bc0 <__divti3+0x310>  // b.plast
    8bb0:	ab0300c3 	adds	x3, x6, x3
    8bb4:	d1000542 	sub	x2, x10, #0x1
    8bb8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    8bbc:	54000288 	b.hi	8c0c <__divti3+0x35c>  // b.pmore
    8bc0:	cb080063 	sub	x3, x3, x8
    8bc4:	aa018041 	orr	x1, x2, x1, lsl #32
    8bc8:	17ffffc2 	b	8ad0 <__divti3+0x220>
    8bcc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8bd0:	d2800001 	mov	x1, #0x0                   	// #0
    8bd4:	9a9f87e0 	cset	x0, ls	// ls = plast
    8bd8:	17ffff68 	b	8978 <__divti3+0xc8>
    8bdc:	aa0103e0 	mov	x0, x1
    8be0:	d2800001 	mov	x1, #0x0                   	// #0
    8be4:	17ffff65 	b	8978 <__divti3+0xc8>
    8be8:	d1000860 	sub	x0, x3, #0x2
    8bec:	8b0600a5 	add	x5, x5, x6
    8bf0:	17ffff52 	b	8938 <__divti3+0x88>
    8bf4:	d1000961 	sub	x1, x11, #0x2
    8bf8:	8b0800a5 	add	x5, x5, x8
    8bfc:	17ffff85 	b	8a10 <__divti3+0x160>
    8c00:	d1000965 	sub	x5, x11, #0x2
    8c04:	8b080063 	add	x3, x3, x8
    8c08:	17ffff8e 	b	8a40 <__divti3+0x190>
    8c0c:	d1000942 	sub	x2, x10, #0x2
    8c10:	8b060063 	add	x3, x3, x6
    8c14:	17ffffeb 	b	8bc0 <__divti3+0x310>
    8c18:	d1000941 	sub	x1, x10, #0x2
    8c1c:	8b060000 	add	x0, x0, x6
    8c20:	17ffffdc 	b	8b90 <__divti3+0x2e0>
    8c24:	d1000900 	sub	x0, x8, #0x2
    8c28:	8b060063 	add	x3, x3, x6
    8c2c:	17ffffb4 	b	8afc <__divti3+0x24c>

0000000000008c30 <__modti3>:
    8c30:	d503245f 	bti	c
    8c34:	d2800004 	mov	x4, #0x0                   	// #0
    8c38:	b6f80081 	tbz	x1, #63, 8c48 <__modti3+0x18>
    8c3c:	eb0003e0 	negs	x0, x0
    8c40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8c44:	da0103e1 	ngc	x1, x1
    8c48:	f100007f 	cmp	x3, #0x0
    8c4c:	5400128b 	b.lt	8e9c <__modti3+0x26c>  // b.tstop
    8c50:	aa0003e7 	mov	x7, x0
    8c54:	aa0103e6 	mov	x6, x1
    8c58:	540004e1 	b.ne	8cf4 <__modti3+0xc4>  // b.any
    8c5c:	eb02003f 	cmp	x1, x2
    8c60:	54000dc2 	b.cs	8e18 <__modti3+0x1e8>  // b.hs, b.nlast
    8c64:	dac01043 	clz	x3, x2
    8c68:	aa0303e5 	mov	x5, x3
    8c6c:	b40000e3 	cbz	x3, 8c88 <__modti3+0x58>
    8c70:	4b0303e6 	neg	w6, w3
    8c74:	9ac32021 	lsl	x1, x1, x3
    8c78:	9ac32042 	lsl	x2, x2, x3
    8c7c:	9ac62406 	lsr	x6, x0, x6
    8c80:	aa0100c6 	orr	x6, x6, x1
    8c84:	9ac32007 	lsl	x7, x0, x3
    8c88:	d360fc40 	lsr	x0, x2, #32
    8c8c:	92407c43 	and	x3, x2, #0xffffffff
    8c90:	9ac008c1 	udiv	x1, x6, x0
    8c94:	9b009826 	msub	x6, x1, x0, x6
    8c98:	9b017c61 	mul	x1, x3, x1
    8c9c:	93c780c6 	extr	x6, x6, x7, #32
    8ca0:	eb06003f 	cmp	x1, x6
    8ca4:	540000a9 	b.ls	8cb8 <__modti3+0x88>  // b.plast
    8ca8:	ab060046 	adds	x6, x2, x6
    8cac:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    8cb0:	8b0200c8 	add	x8, x6, x2
    8cb4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    8cb8:	cb0100c6 	sub	x6, x6, x1
    8cbc:	9ac008c8 	udiv	x8, x6, x0
    8cc0:	9b009901 	msub	x1, x8, x0, x6
    8cc4:	aa0703e0 	mov	x0, x7
    8cc8:	9b087c63 	mul	x3, x3, x8
    8ccc:	b3607c20 	bfi	x0, x1, #32, #32
    8cd0:	eb00007f 	cmp	x3, x0
    8cd4:	54001088 	b.hi	8ee4 <__modti3+0x2b4>  // b.pmore
    8cd8:	cb030000 	sub	x0, x0, x3
    8cdc:	9ac52400 	lsr	x0, x0, x5
    8ce0:	d2800001 	mov	x1, #0x0                   	// #0
    8ce4:	b4000064 	cbz	x4, 8cf0 <__modti3+0xc0>
    8ce8:	eb0003e0 	negs	x0, x0
    8cec:	da0103e1 	ngc	x1, x1
    8cf0:	d65f03c0 	ret
    8cf4:	dac01066 	clz	x6, x3
    8cf8:	eb03003f 	cmp	x1, x3
    8cfc:	54ffff43 	b.cc	8ce4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8d00:	93407cc5 	sxtw	x5, w6
    8d04:	d2800808 	mov	x8, #0x40                  	// #64
    8d08:	cb050108 	sub	x8, x8, x5
    8d0c:	9ac62063 	lsl	x3, x3, x6
    8d10:	9ac62025 	lsl	x5, x1, x6
    8d14:	9ac82447 	lsr	x7, x2, x8
    8d18:	aa0300e7 	orr	x7, x7, x3
    8d1c:	9ac82423 	lsr	x3, x1, x8
    8d20:	92407cec 	and	x12, x7, #0xffffffff
    8d24:	d360fcea 	lsr	x10, x7, #32
    8d28:	9ac82401 	lsr	x1, x0, x8
    8d2c:	aa050021 	orr	x1, x1, x5
    8d30:	9ac62042 	lsl	x2, x2, x6
    8d34:	9ac62000 	lsl	x0, x0, x6
    8d38:	9aca086b 	udiv	x11, x3, x10
    8d3c:	9b0a8d63 	msub	x3, x11, x10, x3
    8d40:	aa0b03e5 	mov	x5, x11
    8d44:	9b0b7d89 	mul	x9, x12, x11
    8d48:	93c18063 	extr	x3, x3, x1, #32
    8d4c:	eb03013f 	cmp	x9, x3
    8d50:	540000a9 	b.ls	8d64 <__modti3+0x134>  // b.plast
    8d54:	ab0300e3 	adds	x3, x7, x3
    8d58:	d1000565 	sub	x5, x11, #0x1
    8d5c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8d60:	54001168 	b.hi	8f8c <__modti3+0x35c>  // b.pmore
    8d64:	cb090063 	sub	x3, x3, x9
    8d68:	9aca086b 	udiv	x11, x3, x10
    8d6c:	9b0a8d6a 	msub	x10, x11, x10, x3
    8d70:	aa0b03e9 	mov	x9, x11
    8d74:	9b0b7d8c 	mul	x12, x12, x11
    8d78:	b3607d41 	bfi	x1, x10, #32, #32
    8d7c:	eb01019f 	cmp	x12, x1
    8d80:	540000a9 	b.ls	8d94 <__modti3+0x164>  // b.plast
    8d84:	ab0100e1 	adds	x1, x7, x1
    8d88:	d1000569 	sub	x9, x11, #0x1
    8d8c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    8d90:	54000f88 	b.hi	8f80 <__modti3+0x350>  // b.pmore
    8d94:	aa058123 	orr	x3, x9, x5, lsl #32
    8d98:	92407c4b 	and	x11, x2, #0xffffffff
    8d9c:	2a0903e9 	mov	w9, w9
    8da0:	d360fc4a 	lsr	x10, x2, #32
    8da4:	d360fc63 	lsr	x3, x3, #32
    8da8:	cb0c0021 	sub	x1, x1, x12
    8dac:	aa0a03ec 	mov	x12, x10
    8db0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    8db4:	9b0b7d25 	mul	x5, x9, x11
    8db8:	9b0b7c6b 	mul	x11, x3, x11
    8dbc:	9b0a2d29 	madd	x9, x9, x10, x11
    8dc0:	92407caa 	and	x10, x5, #0xffffffff
    8dc4:	9b0c7c63 	mul	x3, x3, x12
    8dc8:	8b458125 	add	x5, x9, x5, lsr #32
    8dcc:	8b0d0069 	add	x9, x3, x13
    8dd0:	eb05017f 	cmp	x11, x5
    8dd4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    8dd8:	8b058149 	add	x9, x10, x5, lsl #32
    8ddc:	8b458063 	add	x3, x3, x5, lsr #32
    8de0:	eb03003f 	cmp	x1, x3
    8de4:	54000063 	b.cc	8df0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    8de8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    8dec:	54000082 	b.cs	8dfc <__modti3+0x1cc>  // b.hs, b.nlast
    8df0:	eb020129 	subs	x9, x9, x2
    8df4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    8df8:	cb070063 	sub	x3, x3, x7
    8dfc:	eb090000 	subs	x0, x0, x9
    8e00:	da030021 	sbc	x1, x1, x3
    8e04:	9ac62400 	lsr	x0, x0, x6
    8e08:	9ac82028 	lsl	x8, x1, x8
    8e0c:	aa000100 	orr	x0, x8, x0
    8e10:	9ac62421 	lsr	x1, x1, x6
    8e14:	17ffffb4 	b	8ce4 <__modti3+0xb4>
    8e18:	b5000062 	cbnz	x2, 8e24 <__modti3+0x1f4>
    8e1c:	d2800023 	mov	x3, #0x1                   	// #1
    8e20:	9ac20862 	udiv	x2, x3, x2
    8e24:	dac01048 	clz	x8, x2
    8e28:	aa0803e5 	mov	x5, x8
    8e2c:	b5000668 	cbnz	x8, 8ef8 <__modti3+0x2c8>
    8e30:	cb020020 	sub	x0, x1, x2
    8e34:	d360fc49 	lsr	x9, x2, #32
    8e38:	92407c4a 	and	x10, x2, #0xffffffff
    8e3c:	9ac90801 	udiv	x1, x0, x9
    8e40:	9b098020 	msub	x0, x1, x9, x0
    8e44:	9b0a7c21 	mul	x1, x1, x10
    8e48:	93c78000 	extr	x0, x0, x7, #32
    8e4c:	eb00003f 	cmp	x1, x0
    8e50:	540000a9 	b.ls	8e64 <__modti3+0x234>  // b.plast
    8e54:	ab000040 	adds	x0, x2, x0
    8e58:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8e5c:	8b020003 	add	x3, x0, x2
    8e60:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8e64:	cb010001 	sub	x1, x0, x1
    8e68:	9ac90820 	udiv	x0, x1, x9
    8e6c:	9b098403 	msub	x3, x0, x9, x1
    8e70:	aa0703e1 	mov	x1, x7
    8e74:	9b0a7c00 	mul	x0, x0, x10
    8e78:	b3607c61 	bfi	x1, x3, #32, #32
    8e7c:	eb01001f 	cmp	x0, x1
    8e80:	540000a9 	b.ls	8e94 <__modti3+0x264>  // b.plast
    8e84:	ab010041 	adds	x1, x2, x1
    8e88:	8b020022 	add	x2, x1, x2
    8e8c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    8e90:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    8e94:	cb000020 	sub	x0, x1, x0
    8e98:	17ffff91 	b	8cdc <__modti3+0xac>
    8e9c:	eb0203e5 	negs	x5, x2
    8ea0:	aa0003e7 	mov	x7, x0
    8ea4:	da0303e8 	ngc	x8, x3
    8ea8:	aa0503e2 	mov	x2, x5
    8eac:	aa0803e3 	mov	x3, x8
    8eb0:	aa0103e6 	mov	x6, x1
    8eb4:	b4ffed48 	cbz	x8, 8c5c <__modti3+0x2c>
    8eb8:	eb01011f 	cmp	x8, x1
    8ebc:	54fff148 	b.hi	8ce4 <__modti3+0xb4>  // b.pmore
    8ec0:	dac01109 	clz	x9, x8
    8ec4:	2a0903e6 	mov	w6, w9
    8ec8:	b5fff1c9 	cbnz	x9, 8d00 <__modti3+0xd0>
    8ecc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    8ed0:	54000068 	b.hi	8edc <__modti3+0x2ac>  // b.pmore
    8ed4:	eb050007 	subs	x7, x0, x5
    8ed8:	da080021 	sbc	x1, x1, x8
    8edc:	aa0703e0 	mov	x0, x7
    8ee0:	17ffff81 	b	8ce4 <__modti3+0xb4>
    8ee4:	ab000040 	adds	x0, x2, x0
    8ee8:	8b020002 	add	x2, x0, x2
    8eec:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    8ef0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    8ef4:	17ffff79 	b	8cd8 <__modti3+0xa8>
    8ef8:	9ac82042 	lsl	x2, x2, x8
    8efc:	d2800803 	mov	x3, #0x40                  	// #64
    8f00:	cb080063 	sub	x3, x3, x8
    8f04:	d360fc49 	lsr	x9, x2, #32
    8f08:	9ac82027 	lsl	x7, x1, x8
    8f0c:	92407c4a 	and	x10, x2, #0xffffffff
    8f10:	9ac32426 	lsr	x6, x1, x3
    8f14:	9ac32403 	lsr	x3, x0, x3
    8f18:	aa070063 	orr	x3, x3, x7
    8f1c:	9ac908c1 	udiv	x1, x6, x9
    8f20:	9ac82007 	lsl	x7, x0, x8
    8f24:	9b099820 	msub	x0, x1, x9, x6
    8f28:	9b017d41 	mul	x1, x10, x1
    8f2c:	93c38000 	extr	x0, x0, x3, #32
    8f30:	eb00003f 	cmp	x1, x0
    8f34:	540000a9 	b.ls	8f48 <__modti3+0x318>  // b.plast
    8f38:	ab000040 	adds	x0, x2, x0
    8f3c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8f40:	8b020006 	add	x6, x0, x2
    8f44:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    8f48:	cb010000 	sub	x0, x0, x1
    8f4c:	9ac90801 	udiv	x1, x0, x9
    8f50:	9b098026 	msub	x6, x1, x9, x0
    8f54:	aa0303e0 	mov	x0, x3
    8f58:	9b017d41 	mul	x1, x10, x1
    8f5c:	b3607cc0 	bfi	x0, x6, #32, #32
    8f60:	eb00003f 	cmp	x1, x0
    8f64:	540000a9 	b.ls	8f78 <__modti3+0x348>  // b.plast
    8f68:	ab000040 	adds	x0, x2, x0
    8f6c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8f70:	8b020003 	add	x3, x0, x2
    8f74:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8f78:	cb010000 	sub	x0, x0, x1
    8f7c:	17ffffb0 	b	8e3c <__modti3+0x20c>
    8f80:	d1000969 	sub	x9, x11, #0x2
    8f84:	8b070021 	add	x1, x1, x7
    8f88:	17ffff83 	b	8d94 <__modti3+0x164>
    8f8c:	d1000965 	sub	x5, x11, #0x2
    8f90:	8b070063 	add	x3, x3, x7
    8f94:	17ffff74 	b	8d64 <__modti3+0x134>
    8f98:	d503201f 	nop
    8f9c:	d503201f 	nop

0000000000008fa0 <atexit>:
    8fa0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8fa4:	900000c2 	adrp	x2, 20000 <__data_start>
    8fa8:	d2800001 	mov	x1, #0x0                   	// #0
    8fac:	910003fd 	mov	x29, sp
    8fb0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8fb4:	f9400442 	ldr	x2, [x2, #8]
    8fb8:	17ffe5f2 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008fbc <_fini>:
    8fbc:	d503201f 	nop
    8fc0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8fc4:	910003fd 	mov	x29, sp
    8fc8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8fcc:	d65f03c0 	ret
