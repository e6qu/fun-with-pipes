
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	90000045 	adrp	x5, a000 <fwp_main_thread+0xb80>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	912800a5 	add	x5, x5, #0xa00
    2a20:	90000044 	adrp	x4, a000 <fwp_main_thread+0xb80>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91282084 	add	x4, x4, #0xa08
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	9100c261 	add	x1, x19, #0x30
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x11738>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2ab4:	91378000 	add	x0, x0, #0xde0
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0xb70>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91120042 	add	x2, x2, #0x480
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	9100c273 	add	x19, x19, #0x30
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430a60 	ldr	w0, [x19, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2bfc:	9137c000 	add	x0, x0, #0xdf0
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2c0c:	913a4000 	add	x0, x0, #0xe90
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2c24:	9139a000 	add	x0, x0, #0xe68
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2c30:	9138e000 	add	x0, x0, #0xe38
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2c3c:	91384000 	add	x0, x0, #0xe10
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91008000 	add	x0, x0, #0x20
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91008021 	add	x1, x1, #0x20
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91008000 	add	x0, x0, #0x20
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91008021 	add	x1, x1, #0x20
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39408260 	ldrb	w0, [x19, #32]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39008260 	strb	w0, [x19, #32]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x800>
    2e34:	91124021 	add	x1, x1, #0x490
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9401884 	ldr	x4, [x4, #48]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9401863 	ldr	x3, [x3, #48]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9401c00 	ldr	x0, [x0, #56]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	90000040 	adrp	x0, a000 <fwp_main_thread+0xb80>
    2fd0:	91202000 	add	x0, x0, #0x808
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	9100c043 	add	x3, x2, #0x30
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	9100c042 	add	x2, x2, #0x30
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x800>
    3098:	9111c021 	add	x1, x1, #0x470
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    30c4:	911502a1 	add	x1, x21, #0x540
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    30d8:	9124c0a5 	add	x5, x5, #0x930
    30dc:	911502a1 	add	x1, x21, #0x540
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911502b7 	add	x23, x21, #0x540
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911502b5 	add	x21, x21, #0x540
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911502b5 	add	x21, x21, #0x540
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3268:	9124a0a5 	add	x5, x5, #0x928
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3370:	91202000 	add	x0, x0, #0x808
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	9100c022 	add	x2, x1, #0x30
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	9100c021 	add	x1, x1, #0x30
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	f0000021 	adrp	x1, a000 <fwp_main_thread+0xb80>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	91208021 	add	x1, x1, #0x820
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	f0000021 	adrp	x1, a000 <fwp_main_thread+0xb80>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	9120a021 	add	x1, x1, #0x828
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	f0000021 	adrp	x1, a000 <fwp_main_thread+0xb80>
    34e0:	9120c021 	add	x1, x1, #0x830
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	f0000022 	adrp	x2, a000 <fwp_main_thread+0xb80>
    3538:	aa1303e3 	mov	x3, x19
    353c:	9120e042 	add	x2, x2, #0x838
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3650:	91202000 	add	x0, x0, #0x808
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3670:	91212000 	add	x0, x0, #0x848
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3708:	9121a000 	add	x0, x0, #0x868
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3718:	91222000 	add	x0, x0, #0x888
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x800>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc12820 	ldr	q0, [x1, #1184]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	9100c2b5 	add	x21, x21, #0x30
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3818:	9122c000 	add	x0, x0, #0x8b0
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	9100c062 	add	x2, x3, #0x30
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9401863 	ldr	x3, [x3, #48]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3888:	91238000 	add	x0, x0, #0x8e0
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	f0000024 	adrp	x4, a000 <fwp_main_thread+0xb80>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	9124c084 	add	x4, x4, #0x930
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	f0000024 	adrp	x4, a000 <fwp_main_thread+0xb80>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	91252084 	add	x4, x4, #0x948
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	f0000024 	adrp	x4, a000 <fwp_main_thread+0xb80>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	9124e084 	add	x4, x4, #0x938
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    3ca8:	91150042 	add	x2, x2, #0x540
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	f0000021 	adrp	x1, a000 <fwp_main_thread+0xb80>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	91254021 	add	x1, x1, #0x950
    3d04:	91256000 	add	x0, x0, #0x958
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	f0000022 	adrp	x2, a000 <fwp_main_thread+0xb80>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	9125e042 	add	x2, x2, #0x978
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3e0c:	91110061 	add	x1, x3, #0x440
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3e1c:	91150262 	add	x2, x19, #0x540
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x800>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3e4c:	91120021 	add	x1, x1, #0x480
    3e50:	3dc12c43 	ldr	q3, [x2, #1200]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3e7c:	91110063 	add	x3, x3, #0x440
    3e80:	91138084 	add	x4, x4, #0x4e0
    3e84:	91150266 	add	x6, x19, #0x540
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	91150275 	add	x21, x19, #0x540
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	f0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    3f68:	9128a000 	add	x0, x0, #0xa28
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	91150273 	add	x19, x19, #0x540
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <fwp_wake_io>:
    3fc4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fc8:	9100c122 	add	x2, x9, #0x30
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	5280000a 	mov	w10, #0x0                   	// #0
    3fd4:	f9401446 	ldr	x6, [x2, #40]
    3fd8:	52800008 	mov	w8, #0x0                   	// #0
    3fdc:	4f000400 	movi	v0.4s, #0x0
    3fe0:	52800027 	mov	w7, #0x1                   	// #1
    3fe4:	aa0103e2 	mov	x2, x1
    3fe8:	b4000321 	cbz	x1, 404c <fwp_wake_io+0x88>
    3fec:	f9408c25 	ldr	x5, [x1, #280]
    3ff0:	39015c27 	strb	w7, [x1, #87]
    3ff4:	b4000165 	cbz	x5, 4020 <fwp_wake_io+0x5c>
    3ff8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3ffc:	b4000364 	cbz	x4, 4068 <fwp_wake_io+0xa4>
    4000:	f9009483 	str	x3, [x4, #296]
    4004:	f9409423 	ldr	x3, [x1, #296]
    4008:	b4000043 	cbz	x3, 4010 <fwp_wake_io+0x4c>
    400c:	f9009064 	str	x4, [x3, #288]
    4010:	91080023 	add	x3, x1, #0x200
    4014:	f900943f 	str	xzr, [x1, #296]
    4018:	3c918060 	stur	q0, [x3, #-232]
    401c:	f9400001 	ldr	x1, [x0]
    4020:	f9402843 	ldr	x3, [x2, #80]
    4024:	f2001c7f 	tst	x3, #0xff000000ff
    4028:	54fffde1 	b.ne	3fe4 <fwp_wake_io+0x20>  // b.any
    402c:	39015047 	strb	w7, [x2, #84]
    4030:	f900805f 	str	xzr, [x2, #256]
    4034:	b40001e6 	cbz	x6, 4070 <fwp_wake_io+0xac>
    4038:	f90080c2 	str	x2, [x6, #256]
    403c:	aa0203e6 	mov	x6, x2
    4040:	52800028 	mov	w8, #0x1                   	// #1
    4044:	aa0103e2 	mov	x2, x1
    4048:	b5fffd21 	cbnz	x1, 3fec <fwp_wake_io+0x28>
    404c:	3400006a 	cbz	w10, 4058 <fwp_wake_io+0x94>
    4050:	9100c120 	add	x0, x9, #0x30
    4054:	f900180b 	str	x11, [x0, #48]
    4058:	34000068 	cbz	w8, 4064 <fwp_wake_io+0xa0>
    405c:	9100c129 	add	x9, x9, #0x30
    4060:	f9001526 	str	x6, [x9, #40]
    4064:	d65f03c0 	ret
    4068:	f90000a3 	str	x3, [x5]
    406c:	17ffffe7 	b	4008 <fwp_wake_io+0x44>
    4070:	aa0203eb 	mov	x11, x2
    4074:	5280002a 	mov	w10, #0x1                   	// #1
    4078:	17fffff1 	b	403c <fwp_wake_io+0x78>
    407c:	d503201f 	nop

0000000000004080 <fwp_tape_buffers_release>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	aa0003f3 	mov	x19, x0
    4090:	f9401400 	ldr	x0, [x0, #40]
    4094:	b7f80760 	tbnz	x0, #63, 4180 <fwp_tape_buffers_release+0x100>
    4098:	f9401a61 	ldr	x1, [x19, #48]
    409c:	b7f80301 	tbnz	x1, #63, 40fc <fwp_tape_buffers_release+0x7c>
    40a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40a4:	eb02001f 	cmp	x0, x2
    40a8:	540002a8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40ac:	8b000400 	add	x0, x0, x0, lsl #1
    40b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40b4:	d37df000 	lsl	x0, x0, #3
    40b8:	cb000042 	sub	x2, x2, x0
    40bc:	eb420c3f 	cmp	x1, x2, lsr #3
    40c0:	540001e8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40c4:	8b010c14 	add	x20, x0, x1, lsl #3
    40c8:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    40cc:	9128e000 	add	x0, x0, #0xa38
    40d0:	97fffa2c 	bl	2980 <getenv@plt>
    40d4:	b4000240 	cbz	x0, 411c <fwp_tape_buffers_release+0x9c>
    40d8:	39400001 	ldrb	w1, [x0]
    40dc:	7100c03f 	cmp	w1, #0x30
    40e0:	540001e1 	b.ne	411c <fwp_tape_buffers_release+0x9c>  // b.any
    40e4:	39400400 	ldrb	w0, [x0, #1]
    40e8:	350001a0 	cbnz	w0, 411c <fwp_tape_buffers_release+0x9c>
    40ec:	aa1303e0 	mov	x0, x19
    40f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40f8:	17fffc62 	b	3280 <fwp_tape_buffers_dispose>
    40fc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    4100:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4104:	9128e000 	add	x0, x0, #0xa38
    4108:	97fffa1e 	bl	2980 <getenv@plt>
    410c:	b4ffff00 	cbz	x0, 40ec <fwp_tape_buffers_release+0x6c>
    4110:	39400001 	ldrb	w1, [x0]
    4114:	7100c03f 	cmp	w1, #0x30
    4118:	54fffe60 	b.eq	40e4 <fwp_tape_buffers_release+0x64>  // b.none
    411c:	d1000681 	sub	x1, x20, #0x1
    4120:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4124:	eb00003f 	cmp	x1, x0
    4128:	54fffe28 	b.hi	40ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    412c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4130:	900000f6 	adrp	x22, 20000 <__data_start>
    4134:	9100c2d6 	add	x22, x22, #0x30
    4138:	910122d5 	add	x21, x22, #0x48
    413c:	aa1503e0 	mov	x0, x21
    4140:	97fffc50 	bl	3280 <fwp_tape_buffers_dispose>
    4144:	ad400a61 	ldp	q1, q2, [x19]
    4148:	f90042d4 	str	x20, [x22, #128]
    414c:	4f000400 	movi	v0.4s, #0x0
    4150:	ad000aa1 	stp	q1, q2, [x21]
    4154:	3dc00a61 	ldr	q1, [x19, #32]
    4158:	3d800aa1 	str	q1, [x21, #32]
    415c:	f9401a60 	ldr	x0, [x19, #48]
    4160:	f9001aa0 	str	x0, [x21, #48]
    4164:	f9001a7f 	str	xzr, [x19, #48]
    4168:	ad000260 	stp	q0, q0, [x19]
    416c:	3d800a60 	str	q0, [x19, #32]
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    417c:	d65f03c0 	ret
    4180:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    4184:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4188:	9128e000 	add	x0, x0, #0xa38
    418c:	97fff9fd 	bl	2980 <getenv@plt>
    4190:	b5fffa40 	cbnz	x0, 40d8 <fwp_tape_buffers_release+0x58>
    4194:	17ffffd6 	b	40ec <fwp_tape_buffers_release+0x6c>
    4198:	d503201f 	nop
    419c:	d503201f 	nop

00000000000041a0 <fwp_poll_events>:
    41a0:	d10103ff 	sub	sp, sp, #0x40
    41a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41a8:	f947f400 	ldr	x0, [x0, #4072]
    41ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    41b0:	910083fd 	add	x29, sp, #0x20
    41b4:	a90353f3 	stp	x19, x20, [sp, #48]
    41b8:	900000f4 	adrp	x20, 20000 <__data_start>
    41bc:	f9400001 	ldr	x1, [x0]
    41c0:	f9000fe1 	str	x1, [sp, #24]
    41c4:	d2800001 	mov	x1, #0x0                   	// #0
    41c8:	97fffd2e 	bl	3680 <fwp_now_ns>
    41cc:	9100c281 	add	x1, x20, #0x30
    41d0:	f9404433 	ldr	x19, [x1, #136]
    41d4:	b4000e93 	cbz	x19, 43a4 <fwp_poll_events+0x204>
    41d8:	aa1303e1 	mov	x1, x19
    41dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    41e0:	14000005 	b	41f4 <fwp_poll_events+0x54>
    41e4:	f9408821 	ldr	x1, [x1, #272]
    41e8:	eb03005f 	cmp	x2, x3
    41ec:	9a83d042 	csel	x2, x2, x3, le
    41f0:	b40000c1 	cbz	x1, 4208 <fwp_poll_events+0x68>
    41f4:	f9403423 	ldr	x3, [x1, #104]
    41f8:	b6ffff62 	tbz	x2, #63, 41e4 <fwp_poll_events+0x44>
    41fc:	f9408821 	ldr	x1, [x1, #272]
    4200:	aa0303e2 	mov	x2, x3
    4204:	b5ffff81 	cbnz	x1, 41f4 <fwp_poll_events+0x54>
    4208:	b7f80ce2 	tbnz	x2, #63, 43a4 <fwp_poll_events+0x204>
    420c:	cb000042 	sub	x2, x2, x0
    4210:	f100005f 	cmp	x2, #0x0
    4214:	540005cd 	b.le	42cc <fwp_poll_events+0x12c>
    4218:	d2869b60 	mov	x0, #0x34db                	// #13531
    421c:	d2884801 	mov	x1, #0x4240                	// #16960
    4220:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4224:	f2a001e1 	movk	x1, #0xf, lsl #16
    4228:	f2dbd040 	movk	x0, #0xde82, lsl #32
    422c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4230:	f2e86360 	movk	x0, #0x431b, lsl #48
    4234:	9b407c40 	smulh	x0, x2, x0
    4238:	9352fc00 	asr	x0, x0, #18
    423c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4240:	9b018802 	msub	x2, x0, x1, x2
    4244:	f100005f 	cmp	x2, #0x0
    4248:	9a800400 	cinc	x0, x0, ne	// ne = any
    424c:	eb03001f 	cmp	x0, x3
    4250:	54000a0c 	b.gt	4390 <fwp_poll_events+0x1f0>
    4254:	340003c0 	cbz	w0, 42cc <fwp_poll_events+0x12c>
    4258:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    425c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4260:	72a20c42 	movk	w2, #0x1062, lsl #16
    4264:	9ba27c02 	umull	x2, w0, w2
    4268:	d366fc43 	lsr	x3, x2, #38
    426c:	aa0303e2 	mov	x2, x3
    4270:	1b048063 	msub	w3, w3, w4, w0
    4274:	9b217c63 	smull	x3, w3, w1
    4278:	d2800001 	mov	x1, #0x0                   	// #0
    427c:	910023e0 	add	x0, sp, #0x8
    4280:	a9008fe2 	stp	x2, x3, [sp, #8]
    4284:	97fff98f 	bl	28c0 <nanosleep@plt>
    4288:	9100c280 	add	x0, x20, #0x30
    428c:	f9404413 	ldr	x19, [x0, #136]
    4290:	97fffcfc 	bl	3680 <fwp_now_ns>
    4294:	aa0003e6 	mov	x6, x0
    4298:	b50001f3 	cbnz	x19, 42d4 <fwp_poll_events+0x134>
    429c:	d503201f 	nop
    42a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42a4:	f947f400 	ldr	x0, [x0, #4072]
    42a8:	f9400fe2 	ldr	x2, [sp, #24]
    42ac:	f9400001 	ldr	x1, [x0]
    42b0:	eb010042 	subs	x2, x2, x1
    42b4:	d2800001 	mov	x1, #0x0                   	// #0
    42b8:	540008c1 	b.ne	43d0 <fwp_poll_events+0x230>  // b.any
    42bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    42c4:	910103ff 	add	sp, sp, #0x40
    42c8:	d65f03c0 	ret
    42cc:	97fffced 	bl	3680 <fwp_now_ns>
    42d0:	aa0003e6 	mov	x6, x0
    42d4:	4f000400 	movi	v0.4s, #0x0
    42d8:	9100c288 	add	x8, x20, #0x30
    42dc:	52800027 	mov	w7, #0x1                   	// #1
    42e0:	f9403661 	ldr	x1, [x19, #104]
    42e4:	aa1303e5 	mov	x5, x19
    42e8:	f9408a73 	ldr	x19, [x19, #272]
    42ec:	eb06003f 	cmp	x1, x6
    42f0:	5400032c 	b.gt	4354 <fwp_poll_events+0x1b4>
    42f4:	394154a0 	ldrb	w0, [x5, #85]
    42f8:	36000120 	tbz	w0, #0, 431c <fwp_poll_events+0x17c>
    42fc:	f94084a0 	ldr	x0, [x5, #264]
    4300:	b40003c0 	cbz	x0, 4378 <fwp_poll_events+0x1d8>
    4304:	f9008813 	str	x19, [x0, #272]
    4308:	b4000053 	cbz	x19, 4310 <fwp_poll_events+0x170>
    430c:	f9008660 	str	x0, [x19, #264]
    4310:	910800a0 	add	x0, x5, #0x200
    4314:	390154bf 	strb	wzr, [x5, #85]
    4318:	3c908000 	stur	q0, [x0, #-248]
    431c:	f94030a0 	ldr	x0, [x5, #96]
    4320:	390158a7 	strb	w7, [x5, #86]
    4324:	f100001f 	cmp	x0, #0x0
    4328:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    432c:	5400018d 	b.le	435c <fwp_poll_events+0x1bc>
    4330:	f94028a0 	ldr	x0, [x5, #80]
    4334:	f2001c1f 	tst	x0, #0xff000000ff
    4338:	540000e1 	b.ne	4354 <fwp_poll_events+0x1b4>  // b.any
    433c:	f9401500 	ldr	x0, [x8, #40]
    4340:	390150a7 	strb	w7, [x5, #84]
    4344:	f90080bf 	str	xzr, [x5, #256]
    4348:	b40001e0 	cbz	x0, 4384 <fwp_poll_events+0x1e4>
    434c:	f9001505 	str	x5, [x8, #40]
    4350:	f9008005 	str	x5, [x0, #256]
    4354:	b5fffc73 	cbnz	x19, 42e0 <fwp_poll_events+0x140>
    4358:	17ffffd2 	b	42a0 <fwp_poll_events+0x100>
    435c:	394144a0 	ldrb	w0, [x5, #81]
    4360:	3707fe80 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    4364:	394140a0 	ldrb	w0, [x5, #80]
    4368:	3707fe40 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    436c:	aa0503e0 	mov	x0, x5
    4370:	97fffc20 	bl	33f0 <fwp_cancel_tree.part.0>
    4374:	17ffffef 	b	4330 <fwp_poll_events+0x190>
    4378:	9100c281 	add	x1, x20, #0x30
    437c:	f9004433 	str	x19, [x1, #136]
    4380:	17ffffe2 	b	4308 <fwp_poll_events+0x168>
    4384:	f9001505 	str	x5, [x8, #40]
    4388:	f9001905 	str	x5, [x8, #48]
    438c:	17fffff2 	b	4354 <fwp_poll_events+0x1b4>
    4390:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4394:	d2989362 	mov	x2, #0xc49b                	// #50331
    4398:	f2a4d203 	movk	x3, #0x2690, lsl #16
    439c:	f2a00402 	movk	x2, #0x20, lsl #16
    43a0:	17ffffb6 	b	4278 <fwp_poll_events+0xd8>
    43a4:	97fffaf3 	bl	2f70 <fwp_flush>
    43a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43ac:	f947e863 	ldr	x3, [x3, #4048]
    43b0:	d2800562 	mov	x2, #0x2b                  	// #43
    43b4:	d2800021 	mov	x1, #0x1                   	// #1
    43b8:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    43bc:	91294000 	add	x0, x0, #0xa50
    43c0:	f9400063 	ldr	x3, [x3]
    43c4:	97fff94b 	bl	28f0 <fwrite@plt>
    43c8:	52800ca0 	mov	w0, #0x65                  	// #101
    43cc:	97fff8b5 	bl	26a0 <exit@plt>
    43d0:	97fff908 	bl	27f0 <__stack_chk_fail@plt>

00000000000043d4 <fwp_rc_wide_dup>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	ca404400 	eor	x0, x0, x0, lsr #17
    43e8:	f90013f5 	str	x21, [sp, #32]
    43ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    43f0:	ca402400 	eor	x0, x0, x0, lsr #9
    43f4:	911502a2 	add	x2, x21, #0x540
    43f8:	92401c00 	and	x0, x0, #0xff
    43fc:	910a2403 	add	x3, x0, #0x289
    4400:	8b000c40 	add	x0, x2, x0, lsl #3
    4404:	8b030c54 	add	x20, x2, x3, lsl #3
    4408:	f94a2401 	ldr	x1, [x0, #5192]
    440c:	b50000a1 	cbnz	x1, 4420 <fwp_rc_wide_dup+0x4c>
    4410:	1400002d 	b	44c4 <fwp_rc_wide_dup+0xf0>
    4414:	91004034 	add	x20, x1, #0x10
    4418:	f9400821 	ldr	x1, [x1, #16]
    441c:	b4000241 	cbz	x1, 4464 <fwp_rc_wide_dup+0x90>
    4420:	f9400022 	ldr	x2, [x1]
    4424:	eb02027f 	cmp	x19, x2
    4428:	54ffff61 	b.ne	4414 <fwp_rc_wide_dup+0x40>  // b.any
    442c:	f9400281 	ldr	x1, [x20]
    4430:	39400260 	ldrb	w0, [x19]
    4434:	7103f81f 	cmp	w0, #0xfe
    4438:	54000220 	b.eq	447c <fwp_rc_wide_dup+0xa8>  // b.none
    443c:	b40001a1 	cbz	x1, 4470 <fwp_rc_wide_dup+0x9c>
    4440:	f9400420 	ldr	x0, [x1, #8]
    4444:	b100041f 	cmn	x0, #0x1
    4448:	540004a0 	b.eq	44dc <fwp_rc_wide_dup+0x108>  // b.none
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f9000420 	str	x0, [x1, #8]
    4454:	a94153f3 	ldp	x19, x20, [sp, #16]
    4458:	f94013f5 	ldr	x21, [sp, #32]
    445c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4460:	d65f03c0 	ret
    4464:	39400260 	ldrb	w0, [x19]
    4468:	7103f81f 	cmp	w0, #0xfe
    446c:	540000a0 	b.eq	4480 <fwp_rc_wide_dup+0xac>  // b.none
    4470:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    4474:	912aa000 	add	x0, x0, #0xaa8
    4478:	97fffc22 	bl	3500 <fwp_trap>
    447c:	b5000281 	cbnz	x1, 44cc <fwp_rc_wide_dup+0xf8>
    4480:	d2800300 	mov	x0, #0x18                  	// #24
    4484:	97fff8c3 	bl	2790 <malloc@plt>
    4488:	b4000280 	cbz	x0, 44d8 <fwp_rc_wide_dup+0x104>
    448c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4490:	a9000413 	stp	x19, x1, [x0]
    4494:	911502b5 	add	x21, x21, #0x540
    4498:	f900081f 	str	xzr, [x0, #16]
    449c:	12800001 	mov	w1, #0xffffffff            	// #-1
    44a0:	f9000280 	str	x0, [x20]
    44a4:	39000261 	strb	w1, [x19]
    44a8:	f94e26a0 	ldr	x0, [x21, #7240]
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	91000400 	add	x0, x0, #0x1
    44b4:	f90e26a0 	str	x0, [x21, #7240]
    44b8:	f94013f5 	ldr	x21, [sp, #32]
    44bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c0:	d65f03c0 	ret
    44c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    44c8:	17ffffda 	b	4430 <fwp_rc_wide_dup+0x5c>
    44cc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    44d0:	912a0000 	add	x0, x0, #0xa80
    44d4:	97fffc0b 	bl	3500 <fwp_trap>
    44d8:	97fffab6 	bl	2fb0 <fwp_heap_oom>
    44dc:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    44e0:	912b4000 	add	x0, x0, #0xad0
    44e4:	97fffc07 	bl	3500 <fwp_trap>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_rc_forget_slot>:
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	39400000 	ldrb	w0, [x0]
    44f8:	7103fc1f 	cmp	w0, #0xff
    44fc:	54000040 	b.eq	4504 <fwp_rc_forget_slot+0x14>  // b.none
    4500:	d65f03c0 	ret
    4504:	ca414420 	eor	x0, x1, x1, lsr #17
    4508:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    450c:	ca402400 	eor	x0, x0, x0, lsr #9
    4510:	910003fd 	mov	x29, sp
    4514:	92401c00 	and	x0, x0, #0xff
    4518:	f9000bf3 	str	x19, [sp, #16]
    451c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4520:	91150262 	add	x2, x19, #0x540
    4524:	910a2403 	add	x3, x0, #0x289
    4528:	8b000c40 	add	x0, x2, x0, lsl #3
    452c:	8b030c43 	add	x3, x2, x3, lsl #3
    4530:	f94a2400 	ldr	x0, [x0, #5192]
    4534:	b50000a0 	cbnz	x0, 4548 <fwp_rc_forget_slot+0x58>
    4538:	14000011 	b	457c <fwp_rc_forget_slot+0x8c>
    453c:	91004003 	add	x3, x0, #0x10
    4540:	f9400800 	ldr	x0, [x0, #16]
    4544:	b40001c0 	cbz	x0, 457c <fwp_rc_forget_slot+0x8c>
    4548:	f9400002 	ldr	x2, [x0]
    454c:	eb02003f 	cmp	x1, x2
    4550:	54ffff61 	b.ne	453c <fwp_rc_forget_slot+0x4c>  // b.any
    4554:	f9400801 	ldr	x1, [x0, #16]
    4558:	91150273 	add	x19, x19, #0x540
    455c:	f9000061 	str	x1, [x3]
    4560:	97fff8d4 	bl	28b0 <free@plt>
    4564:	f94e2660 	ldr	x0, [x19, #7240]
    4568:	d1000400 	sub	x0, x0, #0x1
    456c:	f90e2660 	str	x0, [x19, #7240]
    4570:	f9400bf3 	ldr	x19, [sp, #16]
    4574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4578:	d65f03c0 	ret
    457c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    4580:	912aa000 	add	x0, x0, #0xaa8
    4584:	97fffbdf 	bl	3500 <fwp_trap>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_rc_prepare_chunk>:
    4590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4594:	910003fd 	mov	x29, sp
    4598:	a9025bf5 	stp	x21, x22, [sp, #32]
    459c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    45a0:	911502c2 	add	x2, x22, #0x540
    45a4:	b9401c03 	ldr	w3, [x0, #28]
    45a8:	aa0103f5 	mov	x21, x1
    45ac:	a90153f3 	stp	x19, x20, [sp, #16]
    45b0:	aa0003f4 	mov	x20, x0
    45b4:	f94e2440 	ldr	x0, [x2, #7240]
    45b8:	b4000440 	cbz	x0, 4640 <fwp_rc_prepare_chunk+0xb0>
    45bc:	d2800013 	mov	x19, #0x0                   	// #0
    45c0:	35000203 	cbnz	w3, 4600 <fwp_rc_prepare_chunk+0x70>
    45c4:	b4000361 	cbz	x1, 4630 <fwp_rc_prepare_chunk+0xa0>
    45c8:	f9401280 	ldr	x0, [x20, #32]
    45cc:	97fff8b9 	bl	28b0 <free@plt>
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	d2800021 	mov	x1, #0x1                   	// #1
    45d8:	97fff87e 	bl	27d0 <calloc@plt>
    45dc:	f9001280 	str	x0, [x20, #32]
    45e0:	b5000460 	cbnz	x0, 466c <fwp_rc_prepare_chunk+0xdc>
    45e4:	97fffa73 	bl	2fb0 <fwp_heap_oom>
    45e8:	97ffffc2 	bl	44f0 <fwp_rc_forget_slot>
    45ec:	91000673 	add	x19, x19, #0x1
    45f0:	b9401e83 	ldr	w3, [x20, #28]
    45f4:	eb13007f 	cmp	x3, x19
    45f8:	54000169 	b.ls	4624 <fwp_rc_prepare_chunk+0x94>  // b.plast
    45fc:	d503201f 	nop
    4600:	f9401283 	ldr	x3, [x20, #32]
    4604:	8b130060 	add	x0, x3, x19
    4608:	38736863 	ldrb	w3, [x3, x19]
    460c:	7103fc7f 	cmp	w3, #0xff
    4610:	54fffec0 	b.eq	45e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4614:	b9401e83 	ldr	w3, [x20, #28]
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb13007f 	cmp	x3, x19
    4620:	54ffff08 	b.hi	4600 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4624:	eb0302bf 	cmp	x21, x3
    4628:	54000121 	b.ne	464c <fwp_rc_prepare_chunk+0xbc>  // b.any
    462c:	b5000335 	cbnz	x21, 4690 <fwp_rc_prepare_chunk+0x100>
    4630:	a94153f3 	ldp	x19, x20, [sp, #16]
    4634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4638:	a8c37bfd 	ldp	x29, x30, [sp], #48
    463c:	d65f03c0 	ret
    4640:	2a0303e3 	mov	w3, w3
    4644:	eb0302bf 	cmp	x21, x3
    4648:	54ffff20 	b.eq	462c <fwp_rc_prepare_chunk+0x9c>  // b.none
    464c:	911502c2 	add	x2, x22, #0x540
    4650:	f9401280 	ldr	x0, [x20, #32]
    4654:	f94e2841 	ldr	x1, [x2, #7248]
    4658:	cb030021 	sub	x1, x1, x3
    465c:	f90e2841 	str	x1, [x2, #7248]
    4660:	97fff894 	bl	28b0 <free@plt>
    4664:	b5fffb75 	cbnz	x21, 45d0 <fwp_rc_prepare_chunk+0x40>
    4668:	f900129f 	str	xzr, [x20, #32]
    466c:	911502d6 	add	x22, x22, #0x540
    4670:	f94e2ac0 	ldr	x0, [x22, #7248]
    4674:	b9001e95 	str	w21, [x20, #28]
    4678:	a94153f3 	ldp	x19, x20, [sp, #16]
    467c:	8b150000 	add	x0, x0, x21
    4680:	f90e2ac0 	str	x0, [x22, #7248]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	f9401280 	ldr	x0, [x20, #32]
    4694:	aa1503e2 	mov	x2, x21
    4698:	a94153f3 	ldp	x19, x20, [sp, #16]
    469c:	52800001 	mov	w1, #0x0                   	// #0
    46a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46a8:	17fff846 	b	27c0 <memset@plt>
    46ac:	d503201f 	nop

00000000000046b0 <fwp_heap_refill>:
    46b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    46b4:	910003fd 	mov	x29, sp
    46b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    46bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    46c0:	911502b5 	add	x21, x21, #0x540
    46c4:	aa0003f6 	mov	x22, x0
    46c8:	d2800020 	mov	x0, #0x1                   	// #1
    46cc:	a90153f3 	stp	x19, x20, [sp, #16]
    46d0:	a90363f7 	stp	x23, x24, [sp, #48]
    46d4:	2a0103f7 	mov	w23, w1
    46d8:	2a0203f8 	mov	w24, w2
    46dc:	97fffa75 	bl	30b0 <fwp_heap_chunks>
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	f949fea2 	ldr	x2, [x21, #5112]
    46e8:	8b000800 	add	x0, x0, x0, lsl #2
    46ec:	2a1703e1 	mov	w1, w23
    46f0:	52800025 	mov	w5, #0x1                   	// #1
    46f4:	d37df000 	lsl	x0, x0, #3
    46f8:	910f0021 	add	x1, x1, #0x3c0
    46fc:	8b000054 	add	x20, x2, x0
    4700:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4704:	52a00024 	mov	w4, #0x10000               	// #65536
    4708:	38206845 	strb	w5, [x2, x0]
    470c:	aa1403e0 	mov	x0, x20
    4710:	39000698 	strb	w24, [x20, #1]
    4714:	39000a97 	strb	w23, [x20, #2]
    4718:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    471c:	b9000681 	str	w1, [x20, #4]
    4720:	2a0103e5 	mov	w5, w1
    4724:	8b0300a2 	add	x2, x5, x3
    4728:	1ac10881 	udiv	w1, w4, w1
    472c:	9ac50842 	udiv	x2, x2, x5
    4730:	b9000a81 	str	w1, [x20, #8]
    4734:	92404021 	and	x1, x1, #0x1ffff
    4738:	b9001a82 	str	w2, [x20, #24]
    473c:	97ffff95 	bl	4590 <fwp_rc_prepare_chunk>
    4740:	f949daa0 	ldr	x0, [x21, #5040]
    4744:	29408a81 	ldp	w1, w2, [x20, #4]
    4748:	8b134000 	add	x0, x0, x19, lsl #16
    474c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4750:	8b214003 	add	x3, x0, w1, uxtw
    4754:	9ba20021 	umaddl	x1, w1, w2, x0
    4758:	a94363f7 	ldp	x23, x24, [sp, #48]
    475c:	a90086c3 	stp	x3, x1, [x22, #8]
    4760:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4764:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4768:	d65f03c0 	ret
    476c:	d503201f 	nop

0000000000004770 <fwp_mem_free>:
    4770:	b40003c0 	cbz	x0, 47e8 <fwp_mem_free+0x78>
    4774:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4778:	910003fd 	mov	x29, sp
    477c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4780:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4784:	911502a1 	add	x1, x21, #0x540
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	f949d823 	ldr	x3, [x1, #5040]
    4794:	f949ec22 	ldr	x2, [x1, #5080]
    4798:	cb030000 	sub	x0, x0, x3
    479c:	eb02401f 	cmp	x0, x2, lsl #16
    47a0:	540001c2 	b.cs	47d8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47a4:	d350fc16 	lsr	x22, x0, #16
    47a8:	a90363f7 	stp	x23, x24, [sp, #48]
    47ac:	f949fc22 	ldr	x2, [x1, #5112]
    47b0:	8b160ad4 	add	x20, x22, x22, lsl #2
    47b4:	d37df294 	lsl	x20, x20, #3
    47b8:	ab140057 	adds	x23, x2, x20
    47bc:	540000c0 	b.eq	47d4 <fwp_mem_free+0x64>  // b.none
    47c0:	38746842 	ldrb	w2, [x2, x20]
    47c4:	7100045f 	cmp	w2, #0x1
    47c8:	54000120 	b.eq	47ec <fwp_mem_free+0x7c>  // b.none
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540005e0 	b.eq	488c <fwp_mem_free+0x11c>  // b.none
    47d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47e4:	d65f03c0 	ret
    47e8:	d65f03c0 	ret
    47ec:	f94012f8 	ldr	x24, [x23, #32]
    47f0:	b94006e1 	ldr	w1, [x23, #4]
    47f4:	f90023f9 	str	x25, [sp, #64]
    47f8:	2a0103e2 	mov	w2, w1
    47fc:	394006f9 	ldrb	w25, [x23, #1]
    4800:	39400af4 	ldrb	w20, [x23, #2]
    4804:	b4000158 	cbz	x24, 482c <fwp_mem_free+0xbc>
    4808:	92403e76 	and	x22, x19, #0xffff
    480c:	9ac20ad6 	udiv	x22, x22, x2
    4810:	38766b01 	ldrb	w1, [x24, x22]
    4814:	8b160300 	add	x0, x24, x22
    4818:	7103fc3f 	cmp	w1, #0xff
    481c:	54000980 	b.eq	494c <fwp_mem_free+0x1dc>  // b.none
    4820:	38366b1f 	strb	wzr, [x24, x22]
    4824:	b94006e1 	ldr	w1, [x23, #4]
    4828:	2a0103e2 	mov	w2, w1
    482c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4830:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4834:	cb390000 	sub	x0, x0, w25, uxtb
    4838:	8b340074 	add	x20, x3, w20, uxtb
    483c:	911502b5 	add	x21, x21, #0x540
    4840:	1e630021 	ucvtf	d1, w1
    4844:	d37ae400 	lsl	x0, x0, #6
    4848:	8b140c14 	add	x20, x0, x20, lsl #3
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	f8746aa0 	ldr	x0, [x21, x20]
    4854:	f94023f9 	ldr	x25, [sp, #64]
    4858:	aa2003e0 	mvn	x0, x0
    485c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4860:	f9000260 	str	x0, [x19]
    4864:	f8346ab3 	str	x19, [x21, x20]
    4868:	f94a12a0 	ldr	x0, [x21, #5152]
    486c:	1e612800 	fadd	d0, d0, d1
    4870:	a94153f3 	ldp	x19, x20, [sp, #16]
    4874:	cb020000 	sub	x0, x0, x2
    4878:	f90a12a0 	str	x0, [x21, #5152]
    487c:	fd0a22a0 	str	d0, [x21, #5184]
    4880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4884:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4888:	d65f03c0 	ret
    488c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4890:	8b000063 	add	x3, x3, x0
    4894:	eb03027f 	cmp	x19, x3
    4898:	54fff9e1 	b.ne	47d4 <fwp_mem_free+0x64>  // b.any
    489c:	fd400ae1 	ldr	d1, [x23, #16]
    48a0:	fd4a2020 	ldr	d0, [x1, #5184]
    48a4:	f9400ae0 	ldr	x0, [x23, #16]
    48a8:	7e61d821 	ucvtf	d1, d1
    48ac:	f94a1022 	ldr	x2, [x1, #5152]
    48b0:	f94012f3 	ldr	x19, [x23, #32]
    48b4:	1e612800 	fadd	d0, d0, d1
    48b8:	cb000042 	sub	x2, x2, x0
    48bc:	f90a1022 	str	x2, [x1, #5152]
    48c0:	fd0a2020 	str	d0, [x1, #5184]
    48c4:	b40000b3 	cbz	x19, 48d8 <fwp_mem_free+0x168>
    48c8:	39400260 	ldrb	w0, [x19]
    48cc:	7103fc1f 	cmp	w0, #0xff
    48d0:	54000380 	b.eq	4940 <fwp_mem_free+0x1d0>  // b.none
    48d4:	3900027f 	strb	wzr, [x19]
    48d8:	b9400ee2 	ldr	w2, [x23, #12]
    48dc:	b4000142 	cbz	x2, 4904 <fwp_mem_free+0x194>
    48e0:	911502a1 	add	x1, x21, #0x540
    48e4:	8b160040 	add	x0, x2, x22
    48e8:	8b000800 	add	x0, x0, x0, lsl #2
    48ec:	f949fc21 	ldr	x1, [x1, #5112]
    48f0:	8b140034 	add	x20, x1, x20
    48f4:	8b000c20 	add	x0, x1, x0, lsl #3
    48f8:	3802869f 	strb	wzr, [x20], #40
    48fc:	eb00029f 	cmp	x20, x0
    4900:	54ffffc1 	b.ne	48f8 <fwp_mem_free+0x188>  // b.any
    4904:	911502a0 	add	x0, x21, #0x540
    4908:	f94a1801 	ldr	x1, [x0, #5168]
    490c:	f949f803 	ldr	x3, [x0, #5104]
    4910:	8b020021 	add	x1, x1, x2
    4914:	f90a1801 	str	x1, [x0, #5168]
    4918:	eb16007f 	cmp	x3, x22
    491c:	54000049 	b.ls	4924 <fwp_mem_free+0x1b4>  // b.plast
    4920:	f909f816 	str	x22, [x0, #5104]
    4924:	911502b5 	add	x21, x21, #0x540
    4928:	f949f6a0 	ldr	x0, [x21, #5096]
    492c:	eb16001f 	cmp	x0, x22
    4930:	54fff529 	b.ls	47d4 <fwp_mem_free+0x64>  // b.plast
    4934:	a94363f7 	ldp	x23, x24, [sp, #48]
    4938:	f909f6b6 	str	x22, [x21, #5096]
    493c:	17ffffa7 	b	47d8 <fwp_mem_free+0x68>
    4940:	aa1303e0 	mov	x0, x19
    4944:	97fffeeb 	bl	44f0 <fwp_rc_forget_slot>
    4948:	17ffffe3 	b	48d4 <fwp_mem_free+0x164>
    494c:	97fffee9 	bl	44f0 <fwp_rc_forget_slot>
    4950:	17ffffb4 	b	4820 <fwp_mem_free+0xb0>

0000000000004954 <fwp_heap_alloc_big>:
    4954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4958:	910003fd 	mov	x29, sp
    495c:	a90153f3 	stp	x19, x20, [sp, #16]
    4960:	a9025bf5 	stp	x21, x22, [sp, #32]
    4964:	a90363f7 	stp	x23, x24, [sp, #48]
    4968:	aa0003f7 	mov	x23, x0
    496c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	eb0002ff 	cmp	x23, x0
    4978:	54000888 	b.hi	4a88 <fwp_heap_alloc_big+0x134>  // b.pmore
    497c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4980:	8b0002f4 	add	x20, x23, x0
    4984:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4988:	91150359 	add	x25, x26, #0x540
    498c:	d350fe94 	lsr	x20, x20, #16
    4990:	2a0103f5 	mov	w21, w1
    4994:	aa1403e0 	mov	x0, x20
    4998:	97fff9c6 	bl	30b0 <fwp_heap_chunks>
    499c:	f949ff22 	ldr	x2, [x25, #5112]
    49a0:	8b000813 	add	x19, x0, x0, lsl #2
    49a4:	aa0003f8 	mov	x24, x0
    49a8:	52800043 	mov	w3, #0x2                   	// #2
    49ac:	d37df273 	lsl	x19, x19, #3
    49b0:	d2800021 	mov	x1, #0x1                   	// #1
    49b4:	8b130040 	add	x0, x2, x19
    49b8:	38336843 	strb	w3, [x2, x19]
    49bc:	39000415 	strb	w21, [x0, #1]
    49c0:	b9000c14 	str	w20, [x0, #12]
    49c4:	f9000817 	str	x23, [x0, #16]
    49c8:	97fffef2 	bl	4590 <fwp_rc_prepare_chunk>
    49cc:	f100069f 	cmp	x20, #0x1
    49d0:	54000269 	b.ls	4a1c <fwp_heap_alloc_big+0xc8>  // b.plast
    49d4:	8b180294 	add	x20, x20, x24
    49d8:	9100a273 	add	x19, x19, #0x28
    49dc:	a90573fb 	stp	x27, x28, [sp, #80]
    49e0:	5280007b 	mov	w27, #0x3                   	// #3
    49e4:	8b140a94 	add	x20, x20, x20, lsl #2
    49e8:	2a1803fc 	mov	w28, w24
    49ec:	9adb2296 	lsl	x22, x20, x27
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffee4 	bl	4590 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0x9c>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91150353 	add	x19, x26, #0x540
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x104>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115035a 	add	x26, x26, #0x540
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4aa0:	91150262 	add	x2, x19, #0x540
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91150262 	add	x2, x19, #0x540
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91150260 	add	x0, x19, #0x540
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91150273 	add	x19, x19, #0x540
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffca4 	bl	3e04 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff70 	b	4954 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91150260 	add	x0, x19, #0x540
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffeb5 	bl	46b0 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c04:	91150293 	add	x19, x20, #0x540
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91150294 	add	x20, x20, #0x540
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	9100c2f7 	add	x23, x23, #0x30
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9401ee0 	ldr	x0, [x23, #56]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_p_ad_push.constprop.0>:
    4f24:	f100001f 	cmp	x0, #0x0
    4f28:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f2c:	54000e8b 	b.lt	50fc <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    4f30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f34:	aa0003e4 	mov	x4, x0
    4f38:	910003fd 	mov	x29, sp
    4f3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f40:	aa0003f5 	mov	x21, x0
    4f44:	aa020000 	orr	x0, x0, x2
    4f48:	a90363f7 	stp	x23, x24, [sp, #48]
    4f4c:	aa0203f7 	mov	x23, x2
    4f50:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f54:	9e670029 	fmov	d9, x1
    4f58:	9e670068 	fmov	d8, x3
    4f5c:	b6f80900 	tbz	x0, #63, 507c <fwp_p_ad_push.constprop.0+0x158>
    4f60:	a90153f3 	stp	x19, x20, [sp, #16]
    4f64:	9360fc80 	asr	x0, x4, #32
    4f68:	b6f800c4 	tbz	x4, #63, 4f80 <fwp_p_ad_push.constprop.0+0x5c>
    4f6c:	1e604109 	fmov	d9, d8
    4f70:	2f00e408 	movi	d8, #0x0
    4f74:	9360fc40 	asr	x0, x2, #32
    4f78:	aa0203f5 	mov	x21, x2
    4f7c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f80:	97fffa2c 	bl	3830 <fwp_tape_of>
    4f84:	aa0003f3 	mov	x19, x0
    4f88:	f9403000 	ldr	x0, [x0, #96]
    4f8c:	b5001280 	cbnz	x0, 51dc <fwp_p_ad_push.constprop.0+0x2b8>
    4f90:	f9400a76 	ldr	x22, [x19, #16]
    4f94:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f98:	eb0002df 	cmp	x22, x0
    4f9c:	54000e2c 	b.gt	5160 <fwp_p_ad_push.constprop.0+0x23c>
    4fa0:	eb3542df 	cmp	x22, w21, uxtw
    4fa4:	54000d4d 	b.le	514c <fwp_p_ad_push.constprop.0+0x228>
    4fa8:	b7f80077 	tbnz	x23, #63, 4fb4 <fwp_p_ad_push.constprop.0+0x90>
    4fac:	eb3742df 	cmp	x22, w23, uxtw
    4fb0:	54000ced 	b.le	514c <fwp_p_ad_push.constprop.0+0x228>
    4fb4:	f9400678 	ldr	x24, [x19, #8]
    4fb8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4fbc:	cb1802d8 	sub	x24, x22, x24
    4fc0:	91000701 	add	x1, x24, #0x1
    4fc4:	eb00003f 	cmp	x1, x0
    4fc8:	54000cc8 	b.hi	5160 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    4fcc:	a9418274 	ldp	x20, x0, [x19, #24]
    4fd0:	a90573fb 	stp	x27, x28, [sp, #80]
    4fd4:	eb14003f 	cmp	x1, x20
    4fd8:	5400068d 	b.le	50a8 <fwp_p_ad_push.constprop.0+0x184>
    4fdc:	f100029f 	cmp	x20, #0x0
    4fe0:	d2800803 	mov	x3, #0x40                  	// #64
    4fe4:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4fe8:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4fec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4ff0:	eb14003f 	cmp	x1, x20
    4ff4:	5400008d 	b.le	5004 <fwp_p_ad_push.constprop.0+0xe0>
    4ff8:	eb02029f 	cmp	x20, x2
    4ffc:	5400052d 	b.le	50a0 <fwp_p_ad_push.constprop.0+0x17c>
    5000:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5004:	d37df299 	lsl	x25, x20, #3
    5008:	aa1903e1 	mov	x1, x25
    500c:	97fff5f5 	bl	27e0 <realloc@plt>
    5010:	aa0003e1 	mov	x1, x0
    5014:	b4000b00 	cbz	x0, 5174 <fwp_p_ad_push.constprop.0+0x250>
    5018:	f9400e62 	ldr	x2, [x19, #24]
    501c:	f9001261 	str	x1, [x19, #32]
    5020:	f9401a60 	ldr	x0, [x19, #48]
    5024:	d37cee9a 	lsl	x26, x20, #4
    5028:	8b020821 	add	x1, x1, x2, lsl #2
    502c:	f9001661 	str	x1, [x19, #40]
    5030:	aa1a03e1 	mov	x1, x26
    5034:	97fff5eb 	bl	27e0 <realloc@plt>
    5038:	aa0003e2 	mov	x2, x0
    503c:	b40009c0 	cbz	x0, 5174 <fwp_p_ad_push.constprop.0+0x250>
    5040:	f9400e61 	ldr	x1, [x19, #24]
    5044:	d37df31b 	lsl	x27, x24, #3
    5048:	d37ef685 	lsl	x5, x20, #2
    504c:	d37ef71c 	lsl	x28, x24, #2
    5050:	8b190004 	add	x4, x0, x25
    5054:	8b010c01 	add	x1, x0, x1, lsl #3
    5058:	a9030660 	stp	x0, x1, [x19, #48]
    505c:	b5000558 	cbnz	x24, 5104 <fwp_p_ad_push.constprop.0+0x1e0>
    5060:	f9001e64 	str	x4, [x19, #56]
    5064:	f9401260 	ldr	x0, [x19, #32]
    5068:	a9446bf9 	ldp	x25, x26, [sp, #64]
    506c:	8b050001 	add	x1, x0, x5
    5070:	f9000e74 	str	x20, [x19, #24]
    5074:	f9001661 	str	x1, [x19, #40]
    5078:	14000010 	b	50b8 <fwp_p_ad_push.constprop.0+0x194>
    507c:	9360fc40 	asr	x0, x2, #32
    5080:	a90153f3 	stp	x19, x20, [sp, #16]
    5084:	eb84801f 	cmp	x0, x4, asr #32
    5088:	54fff7c0 	b.eq	4f80 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    508c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    5090:	912bc000 	add	x0, x0, #0xaf0
    5094:	a9046bf9 	stp	x25, x26, [sp, #64]
    5098:	a90573fb 	stp	x27, x28, [sp, #80]
    509c:	97fff919 	bl	3500 <fwp_trap>
    50a0:	d37ffa94 	lsl	x20, x20, #1
    50a4:	17ffffd3 	b	4ff0 <fwp_p_ad_push.constprop.0+0xcc>
    50a8:	a9428a61 	ldp	x1, x2, [x19, #40]
    50ac:	d37ef71c 	lsl	x28, x24, #2
    50b0:	f9401e64 	ldr	x4, [x19, #56]
    50b4:	d37df31b 	lsl	x27, x24, #3
    50b8:	b83c6815 	str	w21, [x0, x28]
    50bc:	f10002ff 	cmp	x23, #0x0
    50c0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    50c4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    50c8:	fc3b6849 	str	d9, [x2, x27]
    50cc:	aa1602a0 	orr	x0, x21, x22
    50d0:	b83c6837 	str	w23, [x1, x28]
    50d4:	910006d6 	add	x22, x22, #0x1
    50d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50dc:	fc3b6888 	str	d8, [x4, x27]
    50e0:	a94573fb 	ldp	x27, x28, [sp, #80]
    50e4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    50e8:	f9000a76 	str	x22, [x19, #16]
    50ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    50f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    50f8:	d65f03c0 	ret
    50fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5100:	d65f03c0 	ret
    5104:	eb1a033f 	cmp	x25, x26
    5108:	aa0403e0 	mov	x0, x4
    510c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5110:	aa1b03e2 	mov	x2, x27
    5114:	cb190063 	sub	x3, x3, x25
    5118:	f9003fe5 	str	x5, [sp, #120]
    511c:	97fff61d 	bl	2990 <__memmove_chk@plt>
    5120:	a9420660 	ldp	x0, x1, [x19, #32]
    5124:	aa1c03e2 	mov	x2, x28
    5128:	f9401a63 	ldr	x3, [x19, #48]
    512c:	f9403fe5 	ldr	x5, [sp, #120]
    5130:	8b190063 	add	x3, x3, x25
    5134:	f9001e63 	str	x3, [x19, #56]
    5138:	8b050000 	add	x0, x0, x5
    513c:	97fff549 	bl	2660 <memmove@plt>
    5140:	a9431262 	ldp	x2, x4, [x19, #48]
    5144:	f9403fe5 	ldr	x5, [sp, #120]
    5148:	17ffffc7 	b	5064 <fwp_p_ad_push.constprop.0+0x140>
    514c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    5150:	912e2000 	add	x0, x0, #0xb88
    5154:	a9046bf9 	stp	x25, x26, [sp, #64]
    5158:	a90573fb 	stp	x27, x28, [sp, #80]
    515c:	97fff8e9 	bl	3500 <fwp_trap>
    5160:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    5164:	912da000 	add	x0, x0, #0xb68
    5168:	a9046bf9 	stp	x25, x26, [sp, #64]
    516c:	a90573fb 	stp	x27, x28, [sp, #80]
    5170:	97fff8e4 	bl	3500 <fwp_trap>
    5174:	aa1303e0 	mov	x0, x19
    5178:	97fff766 	bl	2f10 <fwp_tape_unlink_scope>
    517c:	f9401260 	ldr	x0, [x19, #32]
    5180:	97fff5cc 	bl	28b0 <free@plt>
    5184:	f9401a60 	ldr	x0, [x19, #48]
    5188:	97fff5ca 	bl	28b0 <free@plt>
    518c:	f9402260 	ldr	x0, [x19, #64]
    5190:	97fff5c8 	bl	28b0 <free@plt>
    5194:	f9000e7f 	str	xzr, [x19, #24]
    5198:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    519c:	f947e821 	ldr	x1, [x1, #4048]
    51a0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51a4:	d2800262 	mov	x2, #0x13                  	// #19
    51a8:	4f000400 	movi	v0.4s, #0x0
    51ac:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    51b0:	f9400023 	ldr	x3, [x1]
    51b4:	b900067f 	str	wzr, [x19, #4]
    51b8:	d2800021 	mov	x1, #0x1                   	// #1
    51bc:	91202000 	add	x0, x0, #0x808
    51c0:	3c808260 	stur	q0, [x19, #8]
    51c4:	ad010260 	stp	q0, q0, [x19, #32]
    51c8:	97fff5ca 	bl	28f0 <fwrite@plt>
    51cc:	d2800000 	mov	x0, #0x0                   	// #0
    51d0:	97fff5d4 	bl	2920 <fflush@plt>
    51d4:	52800cc0 	mov	w0, #0x66                  	// #102
    51d8:	97fff5e2 	bl	2960 <_Exit@plt>
    51dc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    51e0:	912ce000 	add	x0, x0, #0xb38
    51e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    51e8:	a90573fb 	stp	x27, x28, [sp, #80]
    51ec:	97fff8c5 	bl	3500 <fwp_trap>

00000000000051f0 <w107>:
    51f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51f4:	9e660003 	fmov	x3, d0
    51f8:	aa0003e2 	mov	x2, x0
    51fc:	910003fd 	mov	x29, sp
    5200:	6d0327e8 	stp	d8, d9, [sp, #48]
    5204:	1e604028 	fmov	d8, d1
    5208:	1e600809 	fmul	d9, d0, d0
    520c:	fd0023ea 	str	d10, [sp, #64]
    5210:	1e60400a 	fmov	d10, d0
    5214:	a90153f3 	stp	x19, x20, [sp, #16]
    5218:	aa0003f3 	mov	x19, x0
    521c:	aa0103f4 	mov	x20, x1
    5220:	aa0303e1 	mov	x1, x3
    5224:	a9025bf5 	stp	x21, x22, [sp, #32]
    5228:	97ffff3f 	bl	4f24 <fwp_p_ad_push.constprop.0>
    522c:	1e693908 	fsub	d8, d8, d9
    5230:	aa1403e2 	mov	x2, x20
    5234:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5238:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    523c:	9e660116 	fmov	x22, d8
    5240:	97ffff39 	bl	4f24 <fwp_p_ad_push.constprop.0>
    5244:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5248:	aa0003e1 	mov	x1, x0
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa1303e0 	mov	x0, x19
    5254:	1e6a3929 	fsub	d9, d9, d10
    5258:	aa0103f3 	mov	x19, x1
    525c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5260:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5264:	9e660135 	fmov	x21, d9
    5268:	97ffff2f 	bl	4f24 <fwp_p_ad_push.constprop.0>
    526c:	1e680908 	fmul	d8, d8, d8
    5270:	aa0003f4 	mov	x20, x0
    5274:	aa1603e3 	mov	x3, x22
    5278:	aa1603e1 	mov	x1, x22
    527c:	aa1303e2 	mov	x2, x19
    5280:	aa1303e0 	mov	x0, x19
    5284:	97ffff28 	bl	4f24 <fwp_p_ad_push.constprop.0>
    5288:	aa0003e2 	mov	x2, x0
    528c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5290:	9e670020 	fmov	d0, x1
    5294:	9e660101 	fmov	x1, d8
    5298:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    529c:	1e600908 	fmul	d8, d8, d0
    52a0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52a4:	97ffff20 	bl	4f24 <fwp_p_ad_push.constprop.0>
    52a8:	1e690929 	fmul	d9, d9, d9
    52ac:	aa0003f3 	mov	x19, x0
    52b0:	aa1503e3 	mov	x3, x21
    52b4:	aa1503e1 	mov	x1, x21
    52b8:	aa1403e2 	mov	x2, x20
    52bc:	aa1403e0 	mov	x0, x20
    52c0:	97ffff19 	bl	4f24 <fwp_p_ad_push.constprop.0>
    52c4:	1e692908 	fadd	d8, d8, d9
    52c8:	aa1303e2 	mov	x2, x19
    52cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52d0:	aa0303e1 	mov	x1, x3
    52d4:	97ffff14 	bl	4f24 <fwp_p_ad_push.constprop.0>
    52d8:	aa0003e1 	mov	x1, x0
    52dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    52e0:	9e660100 	fmov	x0, d8
    52e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52e8:	6d4327e8 	ldp	d8, d9, [sp, #48]
    52ec:	fd4023ea 	ldr	d10, [sp, #64]
    52f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52f4:	d65f03c0 	ret
    52f8:	d503201f 	nop
    52fc:	d503201f 	nop

0000000000005300 <w164.constprop.0>:
    5300:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5304:	910003fd 	mov	x29, sp
    5308:	a9025bf5 	stp	x21, x22, [sp, #32]
    530c:	fd001be8 	str	d8, [sp, #48]
    5310:	f9400015 	ldr	x21, [x0]
    5314:	b4000315 	cbz	x21, 5374 <w164.constprop.0+0x74>
    5318:	2f00e408 	movi	d8, #0x0
    531c:	91002016 	add	x22, x0, #0x8
    5320:	a90153f3 	stp	x19, x20, [sp, #16]
    5324:	91004014 	add	x20, x0, #0x10
    5328:	d2800013 	mov	x19, #0x0                   	// #0
    532c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5330:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5334:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5338:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    533c:	aa0303e1 	mov	x1, x3
    5340:	1e602908 	fadd	d8, d8, d0
    5344:	91000a73 	add	x19, x19, #0x2
    5348:	97fffef7 	bl	4f24 <fwp_p_ad_push.constprop.0>
    534c:	eb1302bf 	cmp	x21, x19
    5350:	54ffff08 	b.hi	5330 <w164.constprop.0+0x30>  // b.pmore
    5354:	9e660102 	fmov	x2, d8
    5358:	fd401be8 	ldr	d8, [sp, #48]
    535c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5360:	aa0003e1 	mov	x1, x0
    5364:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5368:	aa0203e0 	mov	x0, x2
    536c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5370:	d65f03c0 	ret
    5374:	2f00e408 	movi	d8, #0x0
    5378:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    537c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5380:	aa0003e1 	mov	x1, x0
    5384:	9e660102 	fmov	x2, d8
    5388:	fd401be8 	ldr	d8, [sp, #48]
    538c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5390:	aa0203e0 	mov	x0, x2
    5394:	d65f03c0 	ret
    5398:	d503201f 	nop
    539c:	d503201f 	nop

00000000000053a0 <fwp_data.part.0.constprop.0>:
    53a0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53a4:	910003fd 	mov	x29, sp
    53a8:	a90153f3 	stp	x19, x20, [sp, #16]
    53ac:	90000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    53b0:	91150283 	add	x3, x20, #0x540
    53b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    53b8:	aa0103f5 	mov	x21, x1
    53bc:	b953a461 	ldr	w1, [x3, #5028]
    53c0:	a90363f7 	stp	x23, x24, [sp, #48]
    53c4:	2a0003f8 	mov	w24, w0
    53c8:	34000701 	cbz	w1, 54a8 <fwp_data.part.0.constprop.0+0x108>
    53cc:	397e8862 	ldrb	w2, [x3, #4002]
    53d0:	910f0040 	add	x0, x2, #0x3c0
    53d4:	8b020442 	add	x2, x2, x2, lsl #1
    53d8:	d37df042 	lsl	x2, x2, #3
    53dc:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    53e0:	2a1703f6 	mov	w22, w23
    53e4:	f8626873 	ldr	x19, [x3, x2]
    53e8:	b40004d3 	cbz	x19, 5480 <fwp_data.part.0.constprop.0+0xe0>
    53ec:	f9400260 	ldr	x0, [x19]
    53f0:	aa2003e0 	mvn	x0, x0
    53f4:	f8226860 	str	x0, [x3, x2]
    53f8:	f10062df 	cmp	x22, #0x18
    53fc:	540000e9 	b.ls	5418 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5400:	d10066c2 	sub	x2, x22, #0x19
    5404:	91006260 	add	x0, x19, #0x18
    5408:	927df042 	and	x2, x2, #0xfffffffffffffff8
    540c:	52800001 	mov	w1, #0x0                   	// #0
    5410:	91002042 	add	x2, x2, #0x8
    5414:	97fff4eb 	bl	27c0 <memset@plt>
    5418:	91150282 	add	x2, x20, #0x540
    541c:	f94a1041 	ldr	x1, [x2, #5152]
    5420:	ab160021 	adds	x1, x1, x22
    5424:	540004c2 	b.cs	54bc <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5428:	f94a1440 	ldr	x0, [x2, #5160]
    542c:	f90a1041 	str	x1, [x2, #5152]
    5430:	eb00003f 	cmp	x1, x0
    5434:	54000049 	b.ls	543c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5438:	f90a1441 	str	x1, [x2, #5160]
    543c:	91150294 	add	x20, x20, #0x540
    5440:	1e6302e1 	ucvtf	d1, w23
    5444:	fd4a1e80 	ldr	d0, [x20, #5176]
    5448:	1e612800 	fadd	d0, d0, d1
    544c:	fd0a1e80 	str	d0, [x20, #5176]
    5450:	52800041 	mov	w1, #0x2                   	// #2
    5454:	29000678 	stp	w24, w1, [x19]
    5458:	aa1303e0 	mov	x0, x19
    545c:	f94002a1 	ldr	x1, [x21]
    5460:	f9000661 	str	x1, [x19, #8]
    5464:	f94006a1 	ldr	x1, [x21, #8]
    5468:	f9000a61 	str	x1, [x19, #16]
    546c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5474:	a94363f7 	ldp	x23, x24, [sp, #48]
    5478:	a8c47bfd 	ldp	x29, x30, [sp], #64
    547c:	d65f03c0 	ret
    5480:	8b020063 	add	x3, x3, x2
    5484:	f9400473 	ldr	x19, [x3, #8]
    5488:	b4000113 	cbz	x19, 54a8 <fwp_data.part.0.constprop.0+0x108>
    548c:	f9400860 	ldr	x0, [x3, #16]
    5490:	cb130000 	sub	x0, x0, x19
    5494:	eb0002df 	cmp	x22, x0
    5498:	54000088 	b.hi	54a8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    549c:	8b160260 	add	x0, x19, x22
    54a0:	f9000460 	str	x0, [x3, #8]
    54a4:	17ffffd5 	b	53f8 <fwp_data.part.0.constprop.0+0x58>
    54a8:	52800001 	mov	w1, #0x0                   	// #0
    54ac:	d2800300 	mov	x0, #0x18                  	// #24
    54b0:	97fffdd0 	bl	4bf0 <fwp_heap_alloc>
    54b4:	aa0003f3 	mov	x19, x0
    54b8:	17ffffe6 	b	5450 <fwp_data.part.0.constprop.0+0xb0>
    54bc:	97fff6bd 	bl	2fb0 <fwp_heap_oom>

00000000000054c0 <fwp_rc_share>:
    54c0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    54c4:	91150042 	add	x2, x2, #0x540
    54c8:	f949d843 	ldr	x3, [x2, #5040]
    54cc:	f949ec41 	ldr	x1, [x2, #5080]
    54d0:	cb030000 	sub	x0, x0, x3
    54d4:	eb01401f 	cmp	x0, x1, lsl #16
    54d8:	540002c2 	b.cs	5530 <fwp_rc_share+0x70>  // b.hs, b.nlast
    54dc:	d350fc01 	lsr	x1, x0, #16
    54e0:	f949fc44 	ldr	x4, [x2, #5112]
    54e4:	8b010821 	add	x1, x1, x1, lsl #2
    54e8:	d37df021 	lsl	x1, x1, #3
    54ec:	8b010083 	add	x3, x4, x1
    54f0:	f9401062 	ldr	x2, [x3, #32]
    54f4:	b40001e2 	cbz	x2, 5530 <fwp_rc_share+0x70>
    54f8:	38616881 	ldrb	w1, [x4, x1]
    54fc:	7100083f 	cmp	w1, #0x2
    5500:	540001a0 	b.eq	5534 <fwp_rc_share+0x74>  // b.none
    5504:	7100043f 	cmp	w1, #0x1
    5508:	54000141 	b.ne	5530 <fwp_rc_share+0x70>  // b.any
    550c:	29430464 	ldp	w4, w1, [x3, #24]
    5510:	92403c00 	and	x0, x0, #0xffff
    5514:	9b047c00 	mul	x0, x0, x4
    5518:	d360fc00 	lsr	x0, x0, #32
    551c:	eb01001f 	cmp	x0, x1
    5520:	54000082 	b.cs	5530 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5524:	8b000042 	add	x2, x2, x0
    5528:	39400040 	ldrb	w0, [x2]
    552c:	350000a0 	cbnz	w0, 5540 <fwp_rc_share+0x80>
    5530:	d65f03c0 	ret
    5534:	72003c1f 	tst	w0, #0xffff
    5538:	54ffff80 	b.eq	5528 <fwp_rc_share+0x68>  // b.none
    553c:	d65f03c0 	ret
    5540:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5544:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    5548:	912ea000 	add	x0, x0, #0xba8
    554c:	910003fd 	mov	x29, sp
    5550:	97fff7ec 	bl	3500 <fwp_trap>

0000000000005554 <fwp_rc_free_arr>:
    5554:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5558:	91150063 	add	x3, x3, #0x540
    555c:	f949d861 	ldr	x1, [x3, #5040]
    5560:	f949ec62 	ldr	x2, [x3, #5080]
    5564:	cb010001 	sub	x1, x0, x1
    5568:	eb02403f 	cmp	x1, x2, lsl #16
    556c:	54000342 	b.cs	55d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5570:	d350fc22 	lsr	x2, x1, #16
    5574:	f949fc65 	ldr	x5, [x3, #5112]
    5578:	8b020842 	add	x2, x2, x2, lsl #2
    557c:	d37df042 	lsl	x2, x2, #3
    5580:	8b0200a4 	add	x4, x5, x2
    5584:	f9401083 	ldr	x3, [x4, #32]
    5588:	b4000263 	cbz	x3, 55d4 <fwp_rc_free_arr+0x80>
    558c:	386268a2 	ldrb	w2, [x5, x2]
    5590:	7100085f 	cmp	w2, #0x2
    5594:	540001c0 	b.eq	55cc <fwp_rc_free_arr+0x78>  // b.none
    5598:	7100045f 	cmp	w2, #0x1
    559c:	540001c1 	b.ne	55d4 <fwp_rc_free_arr+0x80>  // b.any
    55a0:	29430885 	ldp	w5, w2, [x4, #24]
    55a4:	92403c21 	and	x1, x1, #0xffff
    55a8:	9b057c21 	mul	x1, x1, x5
    55ac:	d360fc21 	lsr	x1, x1, #32
    55b0:	eb02003f 	cmp	x1, x2
    55b4:	54000102 	b.cs	55d4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    55b8:	8b010063 	add	x3, x3, x1
    55bc:	39400061 	ldrb	w1, [x3]
    55c0:	7100043f 	cmp	w1, #0x1
    55c4:	54000081 	b.ne	55d4 <fwp_rc_free_arr+0x80>  // b.any
    55c8:	17fffc6a 	b	4770 <fwp_mem_free>
    55cc:	72003c3f 	tst	w1, #0xffff
    55d0:	54ffff60 	b.eq	55bc <fwp_rc_free_arr+0x68>  // b.none
    55d4:	d65f03c0 	ret
    55d8:	d503201f 	nop
    55dc:	d503201f 	nop

00000000000055e0 <fwp_rc_dup>:
    55e0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    55e4:	91150042 	add	x2, x2, #0x540
    55e8:	f949d841 	ldr	x1, [x2, #5040]
    55ec:	f949ec43 	ldr	x3, [x2, #5080]
    55f0:	cb010001 	sub	x1, x0, x1
    55f4:	eb03403f 	cmp	x1, x3, lsl #16
    55f8:	54000342 	b.cs	5660 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    55fc:	d350fc20 	lsr	x0, x1, #16
    5600:	f949fc44 	ldr	x4, [x2, #5112]
    5604:	8b000800 	add	x0, x0, x0, lsl #2
    5608:	d37df002 	lsl	x2, x0, #3
    560c:	8b020083 	add	x3, x4, x2
    5610:	f9401060 	ldr	x0, [x3, #32]
    5614:	b4000260 	cbz	x0, 5660 <fwp_rc_dup+0x80>
    5618:	38626882 	ldrb	w2, [x4, x2]
    561c:	7100085f 	cmp	w2, #0x2
    5620:	54000220 	b.eq	5664 <fwp_rc_dup+0x84>  // b.none
    5624:	7100045f 	cmp	w2, #0x1
    5628:	540001c1 	b.ne	5660 <fwp_rc_dup+0x80>  // b.any
    562c:	29430864 	ldp	w4, w2, [x3, #24]
    5630:	92403c21 	and	x1, x1, #0xffff
    5634:	9b047c21 	mul	x1, x1, x4
    5638:	d360fc21 	lsr	x1, x1, #32
    563c:	eb02003f 	cmp	x1, x2
    5640:	54000102 	b.cs	5660 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5644:	8b010000 	add	x0, x0, x1
    5648:	39400001 	ldrb	w1, [x0]
    564c:	340000a1 	cbz	w1, 5660 <fwp_rc_dup+0x80>
    5650:	7103f43f 	cmp	w1, #0xfd
    5654:	540000e8 	b.hi	5670 <fwp_rc_dup+0x90>  // b.pmore
    5658:	11000421 	add	w1, w1, #0x1
    565c:	39000001 	strb	w1, [x0]
    5660:	d65f03c0 	ret
    5664:	72003c3f 	tst	w1, #0xffff
    5668:	54ffff00 	b.eq	5648 <fwp_rc_dup+0x68>  // b.none
    566c:	d65f03c0 	ret
    5670:	17fffb59 	b	43d4 <fwp_rc_wide_dup>

0000000000005674 <fwp_drop0>:
    5674:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5678:	910003fd 	mov	x29, sp
    567c:	a90153f3 	stp	x19, x20, [sp, #16]
    5680:	f90013f5 	str	x21, [sp, #32]
    5684:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5688:	911502b4 	add	x20, x21, #0x540
    568c:	f949da81 	ldr	x1, [x20, #5040]
    5690:	f949ee82 	ldr	x2, [x20, #5080]
    5694:	cb010001 	sub	x1, x0, x1
    5698:	eb02403f 	cmp	x1, x2, lsl #16
    569c:	54000382 	b.cs	570c <fwp_drop0+0x98>  // b.hs, b.nlast
    56a0:	d350fc22 	lsr	x2, x1, #16
    56a4:	f949fe84 	ldr	x4, [x20, #5112]
    56a8:	8b020842 	add	x2, x2, x2, lsl #2
    56ac:	d37df042 	lsl	x2, x2, #3
    56b0:	8b020083 	add	x3, x4, x2
    56b4:	f9401073 	ldr	x19, [x3, #32]
    56b8:	b40002b3 	cbz	x19, 570c <fwp_drop0+0x98>
    56bc:	38626882 	ldrb	w2, [x4, x2]
    56c0:	7100085f 	cmp	w2, #0x2
    56c4:	540002c0 	b.eq	571c <fwp_drop0+0xa8>  // b.none
    56c8:	7100045f 	cmp	w2, #0x1
    56cc:	54000201 	b.ne	570c <fwp_drop0+0x98>  // b.any
    56d0:	29430864 	ldp	w4, w2, [x3, #24]
    56d4:	92403c21 	and	x1, x1, #0xffff
    56d8:	9b047c21 	mul	x1, x1, x4
    56dc:	d360fc21 	lsr	x1, x1, #32
    56e0:	eb02003f 	cmp	x1, x2
    56e4:	54000142 	b.cs	570c <fwp_drop0+0x98>  // b.hs, b.nlast
    56e8:	8b010273 	add	x19, x19, x1
    56ec:	39400261 	ldrb	w1, [x19]
    56f0:	340000e1 	cbz	w1, 570c <fwp_drop0+0x98>
    56f4:	7100043f 	cmp	w1, #0x1
    56f8:	540001e0 	b.eq	5734 <fwp_drop0+0xc0>  // b.none
    56fc:	7103fc3f 	cmp	w1, #0xff
    5700:	540002e0 	b.eq	575c <fwp_drop0+0xe8>  // b.none
    5704:	51000421 	sub	w1, w1, #0x1
    5708:	39000261 	strb	w1, [x19]
    570c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5710:	f94013f5 	ldr	x21, [sp, #32]
    5714:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5718:	d65f03c0 	ret
    571c:	72003c3f 	tst	w1, #0xffff
    5720:	54fffe60 	b.eq	56ec <fwp_drop0+0x78>  // b.none
    5724:	a94153f3 	ldp	x19, x20, [sp, #16]
    5728:	f94013f5 	ldr	x21, [sp, #32]
    572c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5730:	d65f03c0 	ret
    5734:	f9400813 	ldr	x19, [x0, #16]
    5738:	97ffff87 	bl	5554 <fwp_rc_free_arr>
    573c:	911502a0 	add	x0, x21, #0x540
    5740:	f949d801 	ldr	x1, [x0, #5040]
    5744:	f949ec00 	ldr	x0, [x0, #5080]
    5748:	cb010261 	sub	x1, x19, x1
    574c:	eb00403f 	cmp	x1, x0, lsl #16
    5750:	54fffde2 	b.cs	570c <fwp_drop0+0x98>  // b.hs, b.nlast
    5754:	aa1303e0 	mov	x0, x19
    5758:	17ffffd2 	b	56a0 <fwp_drop0+0x2c>
    575c:	ca534660 	eor	x0, x19, x19, lsr #17
    5760:	911502b5 	add	x21, x21, #0x540
    5764:	ca402400 	eor	x0, x0, x0, lsr #9
    5768:	8b200ea0 	add	x0, x21, w0, uxtb #3
    576c:	f94a2400 	ldr	x0, [x0, #5192]
    5770:	b5000080 	cbnz	x0, 5780 <fwp_drop0+0x10c>
    5774:	14000010 	b	57b4 <fwp_drop0+0x140>
    5778:	f9400800 	ldr	x0, [x0, #16]
    577c:	b40001c0 	cbz	x0, 57b4 <fwp_drop0+0x140>
    5780:	f9400001 	ldr	x1, [x0]
    5784:	eb13003f 	cmp	x1, x19
    5788:	54ffff81 	b.ne	5778 <fwp_drop0+0x104>  // b.any
    578c:	f9400401 	ldr	x1, [x0, #8]
    5790:	d1000421 	sub	x1, x1, #0x1
    5794:	f9000401 	str	x1, [x0, #8]
    5798:	f103f83f 	cmp	x1, #0xfe
    579c:	54fffb81 	b.ne	570c <fwp_drop0+0x98>  // b.any
    57a0:	aa1303e0 	mov	x0, x19
    57a4:	97fffb53 	bl	44f0 <fwp_rc_forget_slot>
    57a8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    57ac:	39000260 	strb	w0, [x19]
    57b0:	17ffffd7 	b	570c <fwp_drop0+0x98>
    57b4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    57b8:	912aa000 	add	x0, x0, #0xaa8
    57bc:	97fff751 	bl	3500 <fwp_trap>

00000000000057c0 <fwp_arg_drop12>:
    57c0:	7100003f 	cmp	w1, #0x0
    57c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    57c8:	54000041 	b.ne	57d0 <fwp_arg_drop12+0x10>  // b.any
    57cc:	d65f03c0 	ret
    57d0:	f9400000 	ldr	x0, [x0]
    57d4:	17ffffa8 	b	5674 <fwp_drop0>
    57d8:	d503201f 	nop
    57dc:	d503201f 	nop

00000000000057e0 <fwp_drop1>:
    57e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    57e4:	910003fd 	mov	x29, sp
    57e8:	a90153f3 	stp	x19, x20, [sp, #16]
    57ec:	f90013f5 	str	x21, [sp, #32]
    57f0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    57f4:	911502b4 	add	x20, x21, #0x540
    57f8:	f949da81 	ldr	x1, [x20, #5040]
    57fc:	f949ee82 	ldr	x2, [x20, #5080]
    5800:	cb010001 	sub	x1, x0, x1
    5804:	eb02403f 	cmp	x1, x2, lsl #16
    5808:	54000382 	b.cs	5878 <fwp_drop1+0x98>  // b.hs, b.nlast
    580c:	d350fc22 	lsr	x2, x1, #16
    5810:	f949fe84 	ldr	x4, [x20, #5112]
    5814:	8b020842 	add	x2, x2, x2, lsl #2
    5818:	d37df042 	lsl	x2, x2, #3
    581c:	8b020083 	add	x3, x4, x2
    5820:	f9401073 	ldr	x19, [x3, #32]
    5824:	b40002b3 	cbz	x19, 5878 <fwp_drop1+0x98>
    5828:	38626882 	ldrb	w2, [x4, x2]
    582c:	7100085f 	cmp	w2, #0x2
    5830:	540002c0 	b.eq	5888 <fwp_drop1+0xa8>  // b.none
    5834:	7100045f 	cmp	w2, #0x1
    5838:	54000201 	b.ne	5878 <fwp_drop1+0x98>  // b.any
    583c:	29430864 	ldp	w4, w2, [x3, #24]
    5840:	92403c21 	and	x1, x1, #0xffff
    5844:	9b047c21 	mul	x1, x1, x4
    5848:	d360fc21 	lsr	x1, x1, #32
    584c:	eb02003f 	cmp	x1, x2
    5850:	54000142 	b.cs	5878 <fwp_drop1+0x98>  // b.hs, b.nlast
    5854:	8b010273 	add	x19, x19, x1
    5858:	39400261 	ldrb	w1, [x19]
    585c:	340000e1 	cbz	w1, 5878 <fwp_drop1+0x98>
    5860:	7100043f 	cmp	w1, #0x1
    5864:	540001e0 	b.eq	58a0 <fwp_drop1+0xc0>  // b.none
    5868:	7103fc3f 	cmp	w1, #0xff
    586c:	540002e0 	b.eq	58c8 <fwp_drop1+0xe8>  // b.none
    5870:	51000421 	sub	w1, w1, #0x1
    5874:	39000261 	strb	w1, [x19]
    5878:	a94153f3 	ldp	x19, x20, [sp, #16]
    587c:	f94013f5 	ldr	x21, [sp, #32]
    5880:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5884:	d65f03c0 	ret
    5888:	72003c3f 	tst	w1, #0xffff
    588c:	54fffe60 	b.eq	5858 <fwp_drop1+0x78>  // b.none
    5890:	a94153f3 	ldp	x19, x20, [sp, #16]
    5894:	f94013f5 	ldr	x21, [sp, #32]
    5898:	a8c37bfd 	ldp	x29, x30, [sp], #48
    589c:	d65f03c0 	ret
    58a0:	f9400813 	ldr	x19, [x0, #16]
    58a4:	97ffff2c 	bl	5554 <fwp_rc_free_arr>
    58a8:	911502a0 	add	x0, x21, #0x540
    58ac:	f949d801 	ldr	x1, [x0, #5040]
    58b0:	f949ec00 	ldr	x0, [x0, #5080]
    58b4:	cb010261 	sub	x1, x19, x1
    58b8:	eb00403f 	cmp	x1, x0, lsl #16
    58bc:	54fffde2 	b.cs	5878 <fwp_drop1+0x98>  // b.hs, b.nlast
    58c0:	aa1303e0 	mov	x0, x19
    58c4:	17ffffd2 	b	580c <fwp_drop1+0x2c>
    58c8:	ca534660 	eor	x0, x19, x19, lsr #17
    58cc:	911502b5 	add	x21, x21, #0x540
    58d0:	ca402400 	eor	x0, x0, x0, lsr #9
    58d4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    58d8:	f94a2400 	ldr	x0, [x0, #5192]
    58dc:	b5000080 	cbnz	x0, 58ec <fwp_drop1+0x10c>
    58e0:	14000010 	b	5920 <fwp_drop1+0x140>
    58e4:	f9400800 	ldr	x0, [x0, #16]
    58e8:	b40001c0 	cbz	x0, 5920 <fwp_drop1+0x140>
    58ec:	f9400001 	ldr	x1, [x0]
    58f0:	eb13003f 	cmp	x1, x19
    58f4:	54ffff81 	b.ne	58e4 <fwp_drop1+0x104>  // b.any
    58f8:	f9400401 	ldr	x1, [x0, #8]
    58fc:	d1000421 	sub	x1, x1, #0x1
    5900:	f9000401 	str	x1, [x0, #8]
    5904:	f103f83f 	cmp	x1, #0xfe
    5908:	54fffb81 	b.ne	5878 <fwp_drop1+0x98>  // b.any
    590c:	aa1303e0 	mov	x0, x19
    5910:	97fffaf8 	bl	44f0 <fwp_rc_forget_slot>
    5914:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5918:	39000260 	strb	w0, [x19]
    591c:	17ffffd7 	b	5878 <fwp_drop1+0x98>
    5920:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    5924:	912aa000 	add	x0, x0, #0xaa8
    5928:	97fff6f6 	bl	3500 <fwp_trap>
    592c:	d503201f 	nop

0000000000005930 <fwp_closure_drop>:
    5930:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5934:	911500a4 	add	x4, x5, #0x540
    5938:	aa0003e1 	mov	x1, x0
    593c:	f949d882 	ldr	x2, [x4, #5040]
    5940:	f949ec80 	ldr	x0, [x4, #5080]
    5944:	cb020022 	sub	x2, x1, x2
    5948:	eb00405f 	cmp	x2, x0, lsl #16
    594c:	54000662 	b.cs	5a18 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5950:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5954:	d350fc43 	lsr	x3, x2, #16
    5958:	910003fd 	mov	x29, sp
    595c:	8b030863 	add	x3, x3, x3, lsl #2
    5960:	f949fc84 	ldr	x4, [x4, #5112]
    5964:	d37df063 	lsl	x3, x3, #3
    5968:	f9000bf3 	str	x19, [sp, #16]
    596c:	8b030080 	add	x0, x4, x3
    5970:	f9401013 	ldr	x19, [x0, #32]
    5974:	b40002b3 	cbz	x19, 59c8 <fwp_closure_drop+0x98>
    5978:	38636883 	ldrb	w3, [x4, x3]
    597c:	7100087f 	cmp	w3, #0x2
    5980:	54000420 	b.eq	5a04 <fwp_closure_drop+0xd4>  // b.none
    5984:	7100047f 	cmp	w3, #0x1
    5988:	54000201 	b.ne	59c8 <fwp_closure_drop+0x98>  // b.any
    598c:	29430003 	ldp	w3, w0, [x0, #24]
    5990:	92403c42 	and	x2, x2, #0xffff
    5994:	9b037c42 	mul	x2, x2, x3
    5998:	d360fc42 	lsr	x2, x2, #32
    599c:	eb00005f 	cmp	x2, x0
    59a0:	54000142 	b.cs	59c8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    59a4:	8b020273 	add	x19, x19, x2
    59a8:	39400260 	ldrb	w0, [x19]
    59ac:	340000e0 	cbz	w0, 59c8 <fwp_closure_drop+0x98>
    59b0:	7100041f 	cmp	w0, #0x1
    59b4:	54000100 	b.eq	59d4 <fwp_closure_drop+0xa4>  // b.none
    59b8:	7103fc1f 	cmp	w0, #0xff
    59bc:	54000300 	b.eq	5a1c <fwp_closure_drop+0xec>  // b.none
    59c0:	51000400 	sub	w0, w0, #0x1
    59c4:	39000260 	strb	w0, [x19]
    59c8:	f9400bf3 	ldr	x19, [sp, #16]
    59cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59d0:	d65f03c0 	ret
    59d4:	d53bd040 	mrs	x0, tpidr_el0
    59d8:	91400000 	add	x0, x0, #0x0, lsl #12
    59dc:	91004000 	add	x0, x0, #0x10
    59e0:	f9400000 	ldr	x0, [x0]
    59e4:	b4000080 	cbz	x0, 59f4 <fwp_closure_drop+0xc4>
    59e8:	f9400bf3 	ldr	x19, [sp, #16]
    59ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59f0:	17fff6dd 	b	3564 <fwp_closure_drop_push>
    59f4:	f9400bf3 	ldr	x19, [sp, #16]
    59f8:	aa0103e0 	mov	x0, x1
    59fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a00:	17fff748 	b	3720 <fwp_closure_drop.part.0>
    5a04:	72003c5f 	tst	w2, #0xffff
    5a08:	54fffd00 	b.eq	59a8 <fwp_closure_drop+0x78>  // b.none
    5a0c:	f9400bf3 	ldr	x19, [sp, #16]
    5a10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a14:	d65f03c0 	ret
    5a18:	d65f03c0 	ret
    5a1c:	ca534660 	eor	x0, x19, x19, lsr #17
    5a20:	911500a5 	add	x5, x5, #0x540
    5a24:	ca402400 	eor	x0, x0, x0, lsr #9
    5a28:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5a2c:	f94a2400 	ldr	x0, [x0, #5192]
    5a30:	b5000080 	cbnz	x0, 5a40 <fwp_closure_drop+0x110>
    5a34:	14000010 	b	5a74 <fwp_closure_drop+0x144>
    5a38:	f9400800 	ldr	x0, [x0, #16]
    5a3c:	b40001c0 	cbz	x0, 5a74 <fwp_closure_drop+0x144>
    5a40:	f9400001 	ldr	x1, [x0]
    5a44:	eb13003f 	cmp	x1, x19
    5a48:	54ffff81 	b.ne	5a38 <fwp_closure_drop+0x108>  // b.any
    5a4c:	f9400401 	ldr	x1, [x0, #8]
    5a50:	d1000421 	sub	x1, x1, #0x1
    5a54:	f9000401 	str	x1, [x0, #8]
    5a58:	f103f83f 	cmp	x1, #0xfe
    5a5c:	54fffb61 	b.ne	59c8 <fwp_closure_drop+0x98>  // b.any
    5a60:	aa1303e0 	mov	x0, x19
    5a64:	97fffaa3 	bl	44f0 <fwp_rc_forget_slot>
    5a68:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a6c:	39000260 	strb	w0, [x19]
    5a70:	17ffffd6 	b	59c8 <fwp_closure_drop+0x98>
    5a74:	b0000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    5a78:	912aa000 	add	x0, x0, #0xaa8
    5a7c:	97fff6a1 	bl	3500 <fwp_trap>

0000000000005a80 <fwp_owned_tape_release>:
    5a80:	b4000940 	cbz	x0, 5ba8 <fwp_owned_tape_release+0x128>
    5a84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a88:	910003fd 	mov	x29, sp
    5a8c:	a90153f3 	stp	x19, x20, [sp, #16]
    5a90:	aa0003f3 	mov	x19, x0
    5a94:	f9400000 	ldr	x0, [x0]
    5a98:	b4000060 	cbz	x0, 5aa4 <fwp_owned_tape_release+0x24>
    5a9c:	f9400661 	ldr	x1, [x19, #8]
    5aa0:	f9000401 	str	x1, [x0, #8]
    5aa4:	f9400661 	ldr	x1, [x19, #8]
    5aa8:	b4000041 	cbz	x1, 5ab0 <fwp_owned_tape_release+0x30>
    5aac:	f9000020 	str	x0, [x1]
    5ab0:	f9400a60 	ldr	x0, [x19, #16]
    5ab4:	f9403401 	ldr	x1, [x0, #104]
    5ab8:	b40005c1 	cbz	x1, 5b70 <fwp_owned_tape_release+0xf0>
    5abc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ac0:	eb00005f 	cmp	x2, x0
    5ac4:	540002ed 	b.le	5b20 <fwp_owned_tape_release+0xa0>
    5ac8:	d2800014 	mov	x20, #0x0                   	// #0
    5acc:	f90013f5 	str	x21, [sp, #32]
    5ad0:	d2800015 	mov	x21, #0x0                   	// #0
    5ad4:	d503201f 	nop
    5ad8:	f9402260 	ldr	x0, [x19, #64]
    5adc:	910006b5 	add	x21, x21, #0x1
    5ae0:	f8746800 	ldr	x0, [x0, x20]
    5ae4:	d63f0020 	blr	x1
    5ae8:	f9402260 	ldr	x0, [x19, #64]
    5aec:	f9400a61 	ldr	x1, [x19, #16]
    5af0:	8b140000 	add	x0, x0, x20
    5af4:	91004294 	add	x20, x20, #0x10
    5af8:	f9400400 	ldr	x0, [x0, #8]
    5afc:	f9403421 	ldr	x1, [x1, #104]
    5b00:	d63f0020 	blr	x1
    5b04:	a9450261 	ldp	x1, x0, [x19, #80]
    5b08:	cb010000 	sub	x0, x0, x1
    5b0c:	eb15001f 	cmp	x0, x21
    5b10:	f9400a60 	ldr	x0, [x19, #16]
    5b14:	f9403401 	ldr	x1, [x0, #104]
    5b18:	54fffe0c 	b.gt	5ad8 <fwp_owned_tape_release+0x58>
    5b1c:	f94013f5 	ldr	x21, [sp, #32]
    5b20:	f9403663 	ldr	x3, [x19, #104]
    5b24:	f9401262 	ldr	x2, [x19, #32]
    5b28:	f100007f 	cmp	x3, #0x0
    5b2c:	540001ed 	b.le	5b68 <fwp_owned_tape_release+0xe8>
    5b30:	d2800014 	mov	x20, #0x0                   	// #0
    5b34:	d503201f 	nop
    5b38:	f9402660 	ldr	x0, [x19, #72]
    5b3c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5b40:	eb02001f 	cmp	x0, x2
    5b44:	540000c0 	b.eq	5b5c <fwp_owned_tape_release+0xdc>  // b.none
    5b48:	d63f0020 	blr	x1
    5b4c:	f9400a60 	ldr	x0, [x19, #16]
    5b50:	f9401262 	ldr	x2, [x19, #32]
    5b54:	f9403663 	ldr	x3, [x19, #104]
    5b58:	f9403401 	ldr	x1, [x0, #104]
    5b5c:	91000694 	add	x20, x20, #0x1
    5b60:	eb14007f 	cmp	x3, x20
    5b64:	54fffeac 	b.gt	5b38 <fwp_owned_tape_release+0xb8>
    5b68:	aa0203e0 	mov	x0, x2
    5b6c:	d63f0020 	blr	x1
    5b70:	f9401660 	ldr	x0, [x19, #40]
    5b74:	97ffff6f 	bl	5930 <fwp_closure_drop>
    5b78:	f9401a60 	ldr	x0, [x19, #48]
    5b7c:	97ffff6d 	bl	5930 <fwp_closure_drop>
    5b80:	f9401e60 	ldr	x0, [x19, #56]
    5b84:	97ffff6b 	bl	5930 <fwp_closure_drop>
    5b88:	f9402260 	ldr	x0, [x19, #64]
    5b8c:	97fffaf9 	bl	4770 <fwp_mem_free>
    5b90:	f9402660 	ldr	x0, [x19, #72]
    5b94:	97fffaf7 	bl	4770 <fwp_mem_free>
    5b98:	aa1303e0 	mov	x0, x19
    5b9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ba0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ba4:	17fffaf3 	b	4770 <fwp_mem_free>
    5ba8:	d65f03c0 	ret
    5bac:	d503201f 	nop

0000000000005bb0 <fwp_tape_finish>:
    5bb0:	d10203ff 	sub	sp, sp, #0x80
    5bb4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5bb8:	f947f421 	ldr	x1, [x1, #4072]
    5bbc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5bc0:	910103fd 	add	x29, sp, #0x40
    5bc4:	a90553f3 	stp	x19, x20, [sp, #80]
    5bc8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5bcc:	a90763f7 	stp	x23, x24, [sp, #112]
    5bd0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5bd4:	9100c316 	add	x22, x24, #0x30
    5bd8:	f9400022 	ldr	x2, [x1]
    5bdc:	f9001fe2 	str	x2, [sp, #56]
    5be0:	d2800002 	mov	x2, #0x0                   	// #0
    5be4:	910122c0 	add	x0, x22, #0x48
    5be8:	97fff5a6 	bl	3280 <fwp_tape_buffers_dispose>
    5bec:	f90042df 	str	xzr, [x22, #128]
    5bf0:	f94022c0 	ldr	x0, [x22, #64]
    5bf4:	f100001f 	cmp	x0, #0x0
    5bf8:	5400030d 	b.le	5c58 <fwp_tape_finish+0xa8>
    5bfc:	910003f7 	mov	x23, sp
    5c00:	d2800015 	mov	x21, #0x0                   	// #0
    5c04:	d2800014 	mov	x20, #0x0                   	// #0
    5c08:	f94002d3 	ldr	x19, [x22]
    5c0c:	91000694 	add	x20, x20, #0x1
    5c10:	8b150273 	add	x19, x19, x21
    5c14:	9101a2b5 	add	x21, x21, #0x68
    5c18:	aa1303e0 	mov	x0, x19
    5c1c:	97fff4bd 	bl	2f10 <fwp_tape_unlink_scope>
    5c20:	aa1703e0 	mov	x0, x23
    5c24:	f9401261 	ldr	x1, [x19, #32]
    5c28:	f90003e1 	str	x1, [sp]
    5c2c:	f9401a62 	ldr	x2, [x19, #48]
    5c30:	f9000be2 	str	x2, [sp, #16]
    5c34:	f9402261 	ldr	x1, [x19, #64]
    5c38:	f90013e1 	str	x1, [sp, #32]
    5c3c:	97fff591 	bl	3280 <fwp_tape_buffers_dispose>
    5c40:	f9403260 	ldr	x0, [x19, #96]
    5c44:	97ffff8f 	bl	5a80 <fwp_owned_tape_release>
    5c48:	f900327f 	str	xzr, [x19, #96]
    5c4c:	f94022c0 	ldr	x0, [x22, #64]
    5c50:	eb14001f 	cmp	x0, x20
    5c54:	54fffdac 	b.gt	5c08 <fwp_tape_finish+0x58>
    5c58:	f9401b00 	ldr	x0, [x24, #48]
    5c5c:	9100c313 	add	x19, x24, #0x30
    5c60:	97fff314 	bl	28b0 <free@plt>
    5c64:	f9001b1f 	str	xzr, [x24, #48]
    5c68:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5c6c:	f947f400 	ldr	x0, [x0, #4072]
    5c70:	f900227f 	str	xzr, [x19, #64]
    5c74:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5c78:	f9401fe2 	ldr	x2, [sp, #56]
    5c7c:	f9400001 	ldr	x1, [x0]
    5c80:	eb010042 	subs	x2, x2, x1
    5c84:	d2800001 	mov	x1, #0x0                   	// #0
    5c88:	540000e1 	b.ne	5ca4 <fwp_tape_finish+0xf4>  // b.any
    5c8c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5c90:	a94553f3 	ldp	x19, x20, [sp, #80]
    5c94:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5c98:	a94763f7 	ldp	x23, x24, [sp, #112]
    5c9c:	910203ff 	add	sp, sp, #0x80
    5ca0:	d65f03c0 	ret
    5ca4:	97fff2d3 	bl	27f0 <__stack_chk_fail@plt>
    5ca8:	d503201f 	nop
    5cac:	d503201f 	nop

0000000000005cb0 <fwp_tape_scope_release>:
    5cb0:	d10243ff 	sub	sp, sp, #0x90
    5cb4:	a9047bfd 	stp	x29, x30, [sp, #64]
    5cb8:	910103fd 	add	x29, sp, #0x40
    5cbc:	a90553f3 	stp	x19, x20, [sp, #80]
    5cc0:	aa0003f4 	mov	x20, x0
    5cc4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5cc8:	f947f400 	ldr	x0, [x0, #4072]
    5ccc:	b9400285 	ldr	w5, [x20]
    5cd0:	f9400001 	ldr	x1, [x0]
    5cd4:	f9001fe1 	str	x1, [sp, #56]
    5cd8:	d2800001 	mov	x1, #0x0                   	// #0
    5cdc:	37f806c5 	tbnz	w5, #31, 5db4 <fwp_tape_scope_release+0x104>
    5ce0:	a90763f7 	stp	x23, x24, [sp, #112]
    5ce4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5ce8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5cec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5cf0:	f00000d3 	adrp	x19, 20000 <__data_start>
    5cf4:	910003f7 	mov	x23, sp
    5cf8:	9100c273 	add	x19, x19, #0x30
    5cfc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5d00:	a9065bf5 	stp	x21, x22, [sp, #96]
    5d04:	52800d16 	mov	w22, #0x68                  	// #104
    5d08:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5d0c:	f90043f9 	str	x25, [sp, #128]
    5d10:	14000006 	b	5d28 <fwp_tape_scope_release+0x78>
    5d14:	97fff55b 	bl	3280 <fwp_tape_buffers_dispose>
    5d18:	aa1903e0 	mov	x0, x25
    5d1c:	97ffff59 	bl	5a80 <fwp_owned_tape_release>
    5d20:	b9400285 	ldr	w5, [x20]
    5d24:	37f80425 	tbnz	w5, #31, 5da8 <fwp_tape_scope_release+0xf8>
    5d28:	f9400266 	ldr	x6, [x19]
    5d2c:	9b367ca5 	smull	x5, w5, w22
    5d30:	8b0500c0 	add	x0, x6, x5
    5d34:	97fff477 	bl	2f10 <fwp_tape_unlink_scope>
    5d38:	ad410001 	ldp	q1, q0, [x0, #32]
    5d3c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5d40:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5d44:	f9400c03 	ldr	x3, [x0, #24]
    5d48:	ad0003e1 	stp	q1, q0, [sp]
    5d4c:	b86568c1 	ldr	w1, [x6, x5]
    5d50:	a9440804 	ldp	x4, x2, [x0, #64]
    5d54:	b900041f 	str	wzr, [x0, #4]
    5d58:	f9403019 	ldr	x25, [x0, #96]
    5d5c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5d60:	f9000c1f 	str	xzr, [x0, #24]
    5d64:	a9020fe4 	stp	x4, x3, [sp, #32]
    5d68:	f9001be2 	str	x2, [sp, #48]
    5d6c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5d70:	f900301f 	str	xzr, [x0, #96]
    5d74:	6b15003f 	cmp	w1, w21
    5d78:	540000e8 	b.hi	5d94 <fwp_tape_scope_release+0xe4>  // b.pmore
    5d7c:	9343fca5 	asr	x5, x5, #3
    5d80:	f9404e60 	ldr	x0, [x19, #152]
    5d84:	9b187ca5 	mul	x5, x5, x24
    5d88:	eb0000bf 	cmp	x5, x0
    5d8c:	5400004a 	b.ge	5d94 <fwp_tape_scope_release+0xe4>  // b.tcont
    5d90:	f9004e65 	str	x5, [x19, #152]
    5d94:	aa1703e0 	mov	x0, x23
    5d98:	b5fffbf9 	cbnz	x25, 5d14 <fwp_tape_scope_release+0x64>
    5d9c:	97fff8b9 	bl	4080 <fwp_tape_buffers_release>
    5da0:	b9400285 	ldr	w5, [x20]
    5da4:	36fffc25 	tbz	w5, #31, 5d28 <fwp_tape_scope_release+0x78>
    5da8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5dac:	a94763f7 	ldp	x23, x24, [sp, #112]
    5db0:	f94043f9 	ldr	x25, [sp, #128]
    5db4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5db8:	f947f400 	ldr	x0, [x0, #4072]
    5dbc:	f9401fe2 	ldr	x2, [sp, #56]
    5dc0:	f9400001 	ldr	x1, [x0]
    5dc4:	eb010042 	subs	x2, x2, x1
    5dc8:	d2800001 	mov	x1, #0x0                   	// #0
    5dcc:	540000a1 	b.ne	5de0 <fwp_tape_scope_release+0x130>  // b.any
    5dd0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5dd4:	a94553f3 	ldp	x19, x20, [sp, #80]
    5dd8:	910243ff 	add	sp, sp, #0x90
    5ddc:	d65f03c0 	ret
    5de0:	a9065bf5 	stp	x21, x22, [sp, #96]
    5de4:	a90763f7 	stp	x23, x24, [sp, #112]
    5de8:	f90043f9 	str	x25, [sp, #128]
    5dec:	97fff281 	bl	27f0 <__stack_chk_fail@plt>

0000000000005df0 <fwp_task_dispose>:
    5df0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5df4:	910003fd 	mov	x29, sp
    5df8:	f9000bf3 	str	x19, [sp, #16]
    5dfc:	aa0003f3 	mov	x19, x0
    5e00:	39414000 	ldrb	w0, [x0, #80]
    5e04:	36000720 	tbz	w0, #0, 5ee8 <fwp_task_dispose+0xf8>
    5e08:	f9400a60 	ldr	x0, [x19, #16]
    5e0c:	b50006e0 	cbnz	x0, 5ee8 <fwp_task_dispose+0xf8>
    5e10:	a9478660 	ldp	x0, x1, [x19, #120]
    5e14:	39014e7f 	strb	wzr, [x19, #83]
    5e18:	f9003e7f 	str	xzr, [x19, #120]
    5e1c:	f100003f 	cmp	x1, #0x0
    5e20:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    5e24:	54000040 	b.eq	5e2c <fwp_task_dispose+0x3c>  // b.none
    5e28:	d63f0020 	blr	x1
    5e2c:	f9405660 	ldr	x0, [x19, #168]
    5e30:	97fffa50 	bl	4770 <fwp_mem_free>
    5e34:	f900567f 	str	xzr, [x19, #168]
    5e38:	b9405e60 	ldr	w0, [x19, #92]
    5e3c:	7100041f 	cmp	w0, #0x1
    5e40:	54000420 	b.eq	5ec4 <fwp_task_dispose+0xd4>  // b.none
    5e44:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5e48:	91150042 	add	x2, x2, #0x540
    5e4c:	f949d840 	ldr	x0, [x2, #5040]
    5e50:	f949ec41 	ldr	x1, [x2, #5080]
    5e54:	cb000260 	sub	x0, x19, x0
    5e58:	eb01401f 	cmp	x0, x1, lsl #16
    5e5c:	540002e2 	b.cs	5eb8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5e60:	d350fc01 	lsr	x1, x0, #16
    5e64:	f949fc44 	ldr	x4, [x2, #5112]
    5e68:	8b010821 	add	x1, x1, x1, lsl #2
    5e6c:	d37df021 	lsl	x1, x1, #3
    5e70:	8b010083 	add	x3, x4, x1
    5e74:	f9401062 	ldr	x2, [x3, #32]
    5e78:	b4000202 	cbz	x2, 5eb8 <fwp_task_dispose+0xc8>
    5e7c:	38616881 	ldrb	w1, [x4, x1]
    5e80:	7100083f 	cmp	w1, #0x2
    5e84:	54000280 	b.eq	5ed4 <fwp_task_dispose+0xe4>  // b.none
    5e88:	7100043f 	cmp	w1, #0x1
    5e8c:	54000161 	b.ne	5eb8 <fwp_task_dispose+0xc8>  // b.any
    5e90:	29430464 	ldp	w4, w1, [x3, #24]
    5e94:	92403c00 	and	x0, x0, #0xffff
    5e98:	9b047c00 	mul	x0, x0, x4
    5e9c:	d360fc00 	lsr	x0, x0, #32
    5ea0:	eb01001f 	cmp	x0, x1
    5ea4:	540000a2 	b.cs	5eb8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5ea8:	8b000042 	add	x2, x2, x0
    5eac:	39400040 	ldrb	w0, [x2]
    5eb0:	7100041f 	cmp	w0, #0x1
    5eb4:	54000080 	b.eq	5ec4 <fwp_task_dispose+0xd4>  // b.none
    5eb8:	f9400bf3 	ldr	x19, [sp, #16]
    5ebc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ec0:	d65f03c0 	ret
    5ec4:	aa1303e0 	mov	x0, x19
    5ec8:	f9400bf3 	ldr	x19, [sp, #16]
    5ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed0:	17fffa28 	b	4770 <fwp_mem_free>
    5ed4:	72003c1f 	tst	w0, #0xffff
    5ed8:	54fffea0 	b.eq	5eac <fwp_task_dispose+0xbc>  // b.none
    5edc:	f9400bf3 	ldr	x19, [sp, #16]
    5ee0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ee4:	d65f03c0 	ret
    5ee8:	97fff256 	bl	2840 <abort@plt>
    5eec:	d503201f 	nop

0000000000005ef0 <fwp_free_zombie>:
    5ef0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ef4:	910003fd 	mov	x29, sp
    5ef8:	a90153f3 	stp	x19, x20, [sp, #16]
    5efc:	f00000d4 	adrp	x20, 20000 <__data_start>
    5f00:	9100c281 	add	x1, x20, #0x30
    5f04:	f9405033 	ldr	x19, [x1, #160]
    5f08:	b4000333 	cbz	x19, 5f6c <fwp_free_zombie+0x7c>
    5f0c:	f9400820 	ldr	x0, [x1, #16]
    5f10:	eb00027f 	cmp	x19, x0
    5f14:	540002c0 	b.eq	5f6c <fwp_free_zombie+0x7c>  // b.none
    5f18:	b940a822 	ldr	w2, [x1, #168]
    5f1c:	f9400a60 	ldr	x0, [x19, #16]
    5f20:	7100fc5f 	cmp	w2, #0x3f
    5f24:	5400078c 	b.gt	6014 <fwp_free_zombie+0x124>
    5f28:	9102c023 	add	x3, x1, #0xb0
    5f2c:	11000444 	add	w4, w2, #0x1
    5f30:	b900a824 	str	w4, [x1, #168]
    5f34:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    5f38:	f822d860 	str	x0, [x3, w2, sxtw #3]
    5f3c:	a9530261 	ldp	x1, x0, [x19, #304]
    5f40:	b4000741 	cbz	x1, 6028 <fwp_free_zombie+0x138>
    5f44:	f9009c20 	str	x0, [x1, #312]
    5f48:	b4000040 	cbz	x0, 5f50 <fwp_free_zombie+0x60>
    5f4c:	f9009801 	str	x1, [x0, #304]
    5f50:	9100c294 	add	x20, x20, #0x30
    5f54:	b9405e60 	ldr	w0, [x19, #92]
    5f58:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    5f5c:	f900529f 	str	xzr, [x20, #160]
    5f60:	34000140 	cbz	w0, 5f88 <fwp_free_zombie+0x98>
    5f64:	7100041f 	cmp	w0, #0x1
    5f68:	54000080 	b.eq	5f78 <fwp_free_zombie+0x88>  // b.none
    5f6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f74:	d65f03c0 	ret
    5f78:	aa1303e0 	mov	x0, x19
    5f7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f84:	17ffff9b 	b	5df0 <fwp_task_dispose>
    5f88:	90000164 	adrp	x4, 31000 <fwp_root_context+0xca0>
    5f8c:	91150082 	add	x2, x4, #0x540
    5f90:	f949d841 	ldr	x1, [x2, #5040]
    5f94:	f949ec40 	ldr	x0, [x2, #5080]
    5f98:	cb010261 	sub	x1, x19, x1
    5f9c:	eb00403f 	cmp	x1, x0, lsl #16
    5fa0:	54fffe62 	b.cs	5f6c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    5fa4:	d350fc20 	lsr	x0, x1, #16
    5fa8:	f949fc43 	ldr	x3, [x2, #5112]
    5fac:	8b000800 	add	x0, x0, x0, lsl #2
    5fb0:	d37df000 	lsl	x0, x0, #3
    5fb4:	8b000062 	add	x2, x3, x0
    5fb8:	f9401054 	ldr	x20, [x2, #32]
    5fbc:	b4fffd94 	cbz	x20, 5f6c <fwp_free_zombie+0x7c>
    5fc0:	38606860 	ldrb	w0, [x3, x0]
    5fc4:	7100081f 	cmp	w0, #0x2
    5fc8:	54000360 	b.eq	6034 <fwp_free_zombie+0x144>  // b.none
    5fcc:	7100041f 	cmp	w0, #0x1
    5fd0:	54fffce1 	b.ne	5f6c <fwp_free_zombie+0x7c>  // b.any
    5fd4:	29430043 	ldp	w3, w0, [x2, #24]
    5fd8:	92403c21 	and	x1, x1, #0xffff
    5fdc:	9b037c21 	mul	x1, x1, x3
    5fe0:	d360fc21 	lsr	x1, x1, #32
    5fe4:	eb00003f 	cmp	x1, x0
    5fe8:	54fffc22 	b.cs	5f6c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    5fec:	8b010294 	add	x20, x20, x1
    5ff0:	39400280 	ldrb	w0, [x20]
    5ff4:	34fffbc0 	cbz	w0, 5f6c <fwp_free_zombie+0x7c>
    5ff8:	7100041f 	cmp	w0, #0x1
    5ffc:	54fffbe0 	b.eq	5f78 <fwp_free_zombie+0x88>  // b.none
    6000:	7103fc1f 	cmp	w0, #0xff
    6004:	540001e0 	b.eq	6040 <fwp_free_zombie+0x150>  // b.none
    6008:	51000400 	sub	w0, w0, #0x1
    600c:	39000280 	strb	w0, [x20]
    6010:	17ffffd7 	b	5f6c <fwp_free_zombie+0x7c>
    6014:	f9400e61 	ldr	x1, [x19, #24]
    6018:	97fff23e 	bl	2910 <munmap@plt>
    601c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6020:	a9530261 	ldp	x1, x0, [x19, #304]
    6024:	b5fff901 	cbnz	x1, 5f44 <fwp_free_zombie+0x54>
    6028:	9100c282 	add	x2, x20, #0x30
    602c:	f9015840 	str	x0, [x2, #688]
    6030:	17ffffc6 	b	5f48 <fwp_free_zombie+0x58>
    6034:	72003c3f 	tst	w1, #0xffff
    6038:	54fff9a1 	b.ne	5f6c <fwp_free_zombie+0x7c>  // b.any
    603c:	17ffffed 	b	5ff0 <fwp_free_zombie+0x100>
    6040:	ca544680 	eor	x0, x20, x20, lsr #17
    6044:	91150084 	add	x4, x4, #0x540
    6048:	ca402400 	eor	x0, x0, x0, lsr #9
    604c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6050:	f94a2400 	ldr	x0, [x0, #5192]
    6054:	b5000080 	cbnz	x0, 6064 <fwp_free_zombie+0x174>
    6058:	14000010 	b	6098 <fwp_free_zombie+0x1a8>
    605c:	f9400800 	ldr	x0, [x0, #16]
    6060:	b40001c0 	cbz	x0, 6098 <fwp_free_zombie+0x1a8>
    6064:	f9400001 	ldr	x1, [x0]
    6068:	eb14003f 	cmp	x1, x20
    606c:	54ffff81 	b.ne	605c <fwp_free_zombie+0x16c>  // b.any
    6070:	f9400401 	ldr	x1, [x0, #8]
    6074:	d1000421 	sub	x1, x1, #0x1
    6078:	f9000401 	str	x1, [x0, #8]
    607c:	f103f83f 	cmp	x1, #0xfe
    6080:	54fff761 	b.ne	5f6c <fwp_free_zombie+0x7c>  // b.any
    6084:	aa1403e0 	mov	x0, x20
    6088:	97fff91a 	bl	44f0 <fwp_rc_forget_slot>
    608c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6090:	39000280 	strb	w0, [x20]
    6094:	17ffffb6 	b	5f6c <fwp_free_zombie+0x7c>
    6098:	90000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    609c:	912aa000 	add	x0, x0, #0xaa8
    60a0:	97fff518 	bl	3500 <fwp_trap>

00000000000060a4 <fwp_block>:
    60a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    60a8:	910003fd 	mov	x29, sp
    60ac:	a90153f3 	stp	x19, x20, [sp, #16]
    60b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    60b4:	9100c274 	add	x20, x19, #0x30
    60b8:	f9401a82 	ldr	x2, [x20, #48]
    60bc:	b4000622 	cbz	x2, 6180 <fwp_block+0xdc>
    60c0:	9100c261 	add	x1, x19, #0x30
    60c4:	f9408040 	ldr	x0, [x2, #256]
    60c8:	f9001820 	str	x0, [x1, #48]
    60cc:	b4000680 	cbz	x0, 619c <fwp_block+0xf8>
    60d0:	9100c263 	add	x3, x19, #0x30
    60d4:	3901505f 	strb	wzr, [x2, #84]
    60d8:	f9400864 	ldr	x4, [x3, #16]
    60dc:	eb02009f 	cmp	x4, x2
    60e0:	54000440 	b.eq	6168 <fwp_block+0xc4>  // b.none
    60e4:	f9415c65 	ldr	x5, [x3, #696]
    60e8:	f9000862 	str	x2, [x3, #16]
    60ec:	f9400441 	ldr	x1, [x2, #8]
    60f0:	f9004885 	str	x5, [x4, #144]
    60f4:	f9416065 	ldr	x5, [x3, #704]
    60f8:	f9004c85 	str	x5, [x4, #152]
    60fc:	f9416465 	ldr	x5, [x3, #712]
    6100:	f9005085 	str	x5, [x4, #160]
    6104:	f9416865 	ldr	x5, [x3, #720]
    6108:	f9005485 	str	x5, [x4, #168]
    610c:	f9416c65 	ldr	x5, [x3, #728]
    6110:	f9005885 	str	x5, [x4, #176]
    6114:	f9417065 	ldr	x5, [x3, #736]
    6118:	f9005c85 	str	x5, [x4, #184]
    611c:	f9417465 	ldr	x5, [x3, #744]
    6120:	f9006085 	str	x5, [x4, #192]
    6124:	f9400480 	ldr	x0, [x4, #8]
    6128:	f9404844 	ldr	x4, [x2, #144]
    612c:	f9015c64 	str	x4, [x3, #696]
    6130:	f9404c44 	ldr	x4, [x2, #152]
    6134:	f9016064 	str	x4, [x3, #704]
    6138:	f9405044 	ldr	x4, [x2, #160]
    613c:	f9016464 	str	x4, [x3, #712]
    6140:	f9405444 	ldr	x4, [x2, #168]
    6144:	f9016864 	str	x4, [x3, #720]
    6148:	f9405844 	ldr	x4, [x2, #176]
    614c:	f9016c64 	str	x4, [x3, #728]
    6150:	a94b8844 	ldp	x4, x2, [x2, #184]
    6154:	f9017064 	str	x4, [x3, #736]
    6158:	f9017462 	str	x2, [x3, #744]
    615c:	97fff1bd 	bl	2850 <swapcontext@plt>
    6160:	97ffff64 	bl	5ef0 <fwp_free_zombie>
    6164:	d503201f 	nop
    6168:	9100c260 	add	x0, x19, #0x30
    616c:	b942f000 	ldr	w0, [x0, #752]
    6170:	340001a0 	cbz	w0, 61a4 <fwp_block+0x100>
    6174:	a94153f3 	ldp	x19, x20, [sp, #16]
    6178:	a8c27bfd 	ldp	x29, x30, [sp], #32
    617c:	d65f03c0 	ret
    6180:	97fff808 	bl	41a0 <fwp_poll_events>
    6184:	f9401a82 	ldr	x2, [x20, #48]
    6188:	b4ffffc2 	cbz	x2, 6180 <fwp_block+0xdc>
    618c:	9100c261 	add	x1, x19, #0x30
    6190:	f9408040 	ldr	x0, [x2, #256]
    6194:	f9001820 	str	x0, [x1, #48]
    6198:	b5fff9c0 	cbnz	x0, 60d0 <fwp_block+0x2c>
    619c:	f900143f 	str	xzr, [x1, #40]
    61a0:	17ffffcc 	b	60d0 <fwp_block+0x2c>
    61a4:	90000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    61a8:	912f6000 	add	x0, x0, #0xbd8
    61ac:	97fff1f5 	bl	2980 <getenv@plt>
    61b0:	5284e202 	mov	w2, #0x2710                	// #10000
    61b4:	b4000060 	cbz	x0, 61c0 <fwp_block+0x11c>
    61b8:	39400001 	ldrb	w1, [x0]
    61bc:	350000c1 	cbnz	w1, 61d4 <fwp_block+0x130>
    61c0:	9100c273 	add	x19, x19, #0x30
    61c4:	b902f262 	str	w2, [x19, #752]
    61c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	d65f03c0 	ret
    61d4:	52800142 	mov	w2, #0xa                   	// #10
    61d8:	d2800001 	mov	x1, #0x0                   	// #0
    61dc:	97fff139 	bl	26c0 <strtoll@plt>
    61e0:	d1000403 	sub	x3, x0, #0x1
    61e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    61e8:	eb02007f 	cmp	x3, x2
    61ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    61f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    61f4:	17fffff3 	b	61c0 <fwp_block+0x11c>
    61f8:	d503201f 	nop
    61fc:	d503201f 	nop

0000000000006200 <fwp_owned_entry161>:
    6200:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6204:	910003fd 	mov	x29, sp
    6208:	a90363f7 	stp	x23, x24, [sp, #48]
    620c:	a9406002 	ldp	x2, x24, [x0]
    6210:	a90153f3 	stp	x19, x20, [sp, #16]
    6214:	f9400801 	ldr	x1, [x0, #16]
    6218:	a9025bf5 	stp	x21, x22, [sp, #32]
    621c:	ab010055 	adds	x21, x2, x1
    6220:	54000d06 	b.vs	63c0 <fwp_owned_entry161+0x1c0>
    6224:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    6228:	91150281 	add	x1, x20, #0x540
    622c:	b953a420 	ldr	w0, [x1, #5028]
    6230:	34000a80 	cbz	w0, 6380 <fwp_owned_entry161+0x180>
    6234:	397e8820 	ldrb	w0, [x1, #4002]
    6238:	910f0002 	add	x2, x0, #0x3c0
    623c:	8b000400 	add	x0, x0, x0, lsl #1
    6240:	d37df000 	lsl	x0, x0, #3
    6244:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6248:	2a1703f6 	mov	w22, w23
    624c:	f8606833 	ldr	x19, [x1, x0]
    6250:	b4000853 	cbz	x19, 6358 <fwp_owned_entry161+0x158>
    6254:	f9400262 	ldr	x2, [x19]
    6258:	aa2203e2 	mvn	x2, x2
    625c:	f8206822 	str	x2, [x1, x0]
    6260:	f10062df 	cmp	x22, #0x18
    6264:	540000e9 	b.ls	6280 <fwp_owned_entry161+0x80>  // b.plast
    6268:	d10066c2 	sub	x2, x22, #0x19
    626c:	91006260 	add	x0, x19, #0x18
    6270:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6274:	52800001 	mov	w1, #0x0                   	// #0
    6278:	91002042 	add	x2, x2, #0x8
    627c:	97fff151 	bl	27c0 <memset@plt>
    6280:	91150281 	add	x1, x20, #0x540
    6284:	f94a1020 	ldr	x0, [x1, #5152]
    6288:	ab160000 	adds	x0, x0, x22
    628c:	540009c2 	b.cs	63c4 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6290:	f94a1422 	ldr	x2, [x1, #5160]
    6294:	f90a1020 	str	x0, [x1, #5152]
    6298:	eb02001f 	cmp	x0, x2
    629c:	54000049 	b.ls	62a4 <fwp_owned_entry161+0xa4>  // b.plast
    62a0:	f90a1420 	str	x0, [x1, #5160]
    62a4:	91150280 	add	x0, x20, #0x540
    62a8:	1e6302e1 	ucvtf	d1, w23
    62ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    62b0:	1e612800 	fadd	d0, d0, d1
    62b4:	fd0a1c00 	str	d0, [x0, #5176]
    62b8:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x800>
    62bc:	91150294 	add	x20, x20, #0x540
    62c0:	a900d678 	stp	x24, x21, [x19, #8]
    62c4:	fd426800 	ldr	d0, [x0, #1232]
    62c8:	fd000260 	str	d0, [x19]
    62cc:	f949da81 	ldr	x1, [x20, #5040]
    62d0:	f949ee80 	ldr	x0, [x20, #5080]
    62d4:	cb010261 	sub	x1, x19, x1
    62d8:	eb00403f 	cmp	x1, x0, lsl #16
    62dc:	54000322 	b.cs	6340 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    62e0:	d350fc20 	lsr	x0, x1, #16
    62e4:	f949fe83 	ldr	x3, [x20, #5112]
    62e8:	8b000800 	add	x0, x0, x0, lsl #2
    62ec:	d37df002 	lsl	x2, x0, #3
    62f0:	8b020060 	add	x0, x3, x2
    62f4:	f9401014 	ldr	x20, [x0, #32]
    62f8:	b4000254 	cbz	x20, 6340 <fwp_owned_entry161+0x140>
    62fc:	38626862 	ldrb	w2, [x3, x2]
    6300:	7100085f 	cmp	w2, #0x2
    6304:	54000480 	b.eq	6394 <fwp_owned_entry161+0x194>  // b.none
    6308:	7100045f 	cmp	w2, #0x1
    630c:	540001a1 	b.ne	6340 <fwp_owned_entry161+0x140>  // b.any
    6310:	29430002 	ldp	w2, w0, [x0, #24]
    6314:	92403c21 	and	x1, x1, #0xffff
    6318:	9b027c21 	mul	x1, x1, x2
    631c:	d360fc21 	lsr	x1, x1, #32
    6320:	eb00003f 	cmp	x1, x0
    6324:	540000e2 	b.cs	6340 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6328:	8b010294 	add	x20, x20, x1
    632c:	39400280 	ldrb	w0, [x20]
    6330:	7103fc1f 	cmp	w0, #0xff
    6334:	54000400 	b.eq	63b4 <fwp_owned_entry161+0x1b4>  // b.none
    6338:	52800020 	mov	w0, #0x1                   	// #1
    633c:	39000280 	strb	w0, [x20]
    6340:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6344:	aa1303e0 	mov	x0, x19
    6348:	a94153f3 	ldp	x19, x20, [sp, #16]
    634c:	a94363f7 	ldp	x23, x24, [sp, #48]
    6350:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6354:	d65f03c0 	ret
    6358:	8b000021 	add	x1, x1, x0
    635c:	f9400433 	ldr	x19, [x1, #8]
    6360:	b4000113 	cbz	x19, 6380 <fwp_owned_entry161+0x180>
    6364:	f9400820 	ldr	x0, [x1, #16]
    6368:	cb130000 	sub	x0, x0, x19
    636c:	eb0002df 	cmp	x22, x0
    6370:	54000088 	b.hi	6380 <fwp_owned_entry161+0x180>  // b.pmore
    6374:	8b160260 	add	x0, x19, x22
    6378:	f9000420 	str	x0, [x1, #8]
    637c:	17ffffb9 	b	6260 <fwp_owned_entry161+0x60>
    6380:	52800001 	mov	w1, #0x0                   	// #0
    6384:	d2800300 	mov	x0, #0x18                  	// #24
    6388:	97fffa1a 	bl	4bf0 <fwp_heap_alloc>
    638c:	aa0003f3 	mov	x19, x0
    6390:	17ffffca 	b	62b8 <fwp_owned_entry161+0xb8>
    6394:	72003c3f 	tst	w1, #0xffff
    6398:	54fffca0 	b.eq	632c <fwp_owned_entry161+0x12c>  // b.none
    639c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63a0:	aa1303e0 	mov	x0, x19
    63a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    63ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    63b0:	d65f03c0 	ret
    63b4:	aa1403e0 	mov	x0, x20
    63b8:	97fff84e 	bl	44f0 <fwp_rc_forget_slot>
    63bc:	17ffffdf 	b	6338 <fwp_owned_entry161+0x138>
    63c0:	97fff190 	bl	2a00 <fwp_trap_overflow.constprop.0>
    63c4:	97fff2fb 	bl	2fb0 <fwp_heap_oom>
    63c8:	d503201f 	nop
    63cc:	d503201f 	nop

00000000000063d0 <e161>:
    63d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    63d4:	910003fd 	mov	x29, sp
    63d8:	a90363f7 	stp	x23, x24, [sp, #48]
    63dc:	a9406002 	ldp	x2, x24, [x0]
    63e0:	a90153f3 	stp	x19, x20, [sp, #16]
    63e4:	f9400801 	ldr	x1, [x0, #16]
    63e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    63ec:	ab010055 	adds	x21, x2, x1
    63f0:	54000d86 	b.vs	65a0 <e161+0x1d0>
    63f4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    63f8:	91150281 	add	x1, x20, #0x540
    63fc:	b953a420 	ldr	w0, [x1, #5028]
    6400:	34000ac0 	cbz	w0, 6558 <e161+0x188>
    6404:	397e8820 	ldrb	w0, [x1, #4002]
    6408:	910f0002 	add	x2, x0, #0x3c0
    640c:	8b000400 	add	x0, x0, x0, lsl #1
    6410:	d37df000 	lsl	x0, x0, #3
    6414:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6418:	2a1703f6 	mov	w22, w23
    641c:	f8606833 	ldr	x19, [x1, x0]
    6420:	b4000893 	cbz	x19, 6530 <e161+0x160>
    6424:	f9400262 	ldr	x2, [x19]
    6428:	aa2203e2 	mvn	x2, x2
    642c:	f8206822 	str	x2, [x1, x0]
    6430:	f10062df 	cmp	x22, #0x18
    6434:	540000e9 	b.ls	6450 <e161+0x80>  // b.plast
    6438:	d10066c2 	sub	x2, x22, #0x19
    643c:	91006260 	add	x0, x19, #0x18
    6440:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6444:	52800001 	mov	w1, #0x0                   	// #0
    6448:	91002042 	add	x2, x2, #0x8
    644c:	97fff0dd 	bl	27c0 <memset@plt>
    6450:	91150281 	add	x1, x20, #0x540
    6454:	f94a1020 	ldr	x0, [x1, #5152]
    6458:	ab160000 	adds	x0, x0, x22
    645c:	54000a42 	b.cs	65a4 <e161+0x1d4>  // b.hs, b.nlast
    6460:	f94a1422 	ldr	x2, [x1, #5160]
    6464:	f90a1020 	str	x0, [x1, #5152]
    6468:	eb02001f 	cmp	x0, x2
    646c:	54000049 	b.ls	6474 <e161+0xa4>  // b.plast
    6470:	f90a1420 	str	x0, [x1, #5160]
    6474:	91150280 	add	x0, x20, #0x540
    6478:	1e6302e1 	ucvtf	d1, w23
    647c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6480:	1e612800 	fadd	d0, d0, d1
    6484:	fd0a1c00 	str	d0, [x0, #5176]
    6488:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x800>
    648c:	91150294 	add	x20, x20, #0x540
    6490:	a900d678 	stp	x24, x21, [x19, #8]
    6494:	fd426800 	ldr	d0, [x0, #1232]
    6498:	fd000260 	str	d0, [x19]
    649c:	f949da81 	ldr	x1, [x20, #5040]
    64a0:	f949ee80 	ldr	x0, [x20, #5080]
    64a4:	cb010261 	sub	x1, x19, x1
    64a8:	eb00403f 	cmp	x1, x0, lsl #16
    64ac:	54000322 	b.cs	6510 <e161+0x140>  // b.hs, b.nlast
    64b0:	d350fc20 	lsr	x0, x1, #16
    64b4:	f949fe83 	ldr	x3, [x20, #5112]
    64b8:	8b000800 	add	x0, x0, x0, lsl #2
    64bc:	d37df002 	lsl	x2, x0, #3
    64c0:	8b020060 	add	x0, x3, x2
    64c4:	f9401014 	ldr	x20, [x0, #32]
    64c8:	b4000254 	cbz	x20, 6510 <e161+0x140>
    64cc:	38626862 	ldrb	w2, [x3, x2]
    64d0:	7100085f 	cmp	w2, #0x2
    64d4:	540004c0 	b.eq	656c <e161+0x19c>  // b.none
    64d8:	7100045f 	cmp	w2, #0x1
    64dc:	540001a1 	b.ne	6510 <e161+0x140>  // b.any
    64e0:	29430002 	ldp	w2, w0, [x0, #24]
    64e4:	92403c21 	and	x1, x1, #0xffff
    64e8:	9b027c21 	mul	x1, x1, x2
    64ec:	d360fc21 	lsr	x1, x1, #32
    64f0:	eb00003f 	cmp	x1, x0
    64f4:	540000e2 	b.cs	6510 <e161+0x140>  // b.hs, b.nlast
    64f8:	8b010294 	add	x20, x20, x1
    64fc:	39400280 	ldrb	w0, [x20]
    6500:	7103fc1f 	cmp	w0, #0xff
    6504:	54000480 	b.eq	6594 <e161+0x1c4>  // b.none
    6508:	52800020 	mov	w0, #0x1                   	// #1
    650c:	39000280 	strb	w0, [x20]
    6510:	aa1303e0 	mov	x0, x19
    6514:	97fffbeb 	bl	54c0 <fwp_rc_share>
    6518:	a9425bf5 	ldp	x21, x22, [sp, #32]
    651c:	aa1303e0 	mov	x0, x19
    6520:	a94153f3 	ldp	x19, x20, [sp, #16]
    6524:	a94363f7 	ldp	x23, x24, [sp, #48]
    6528:	a8c47bfd 	ldp	x29, x30, [sp], #64
    652c:	d65f03c0 	ret
    6530:	8b000021 	add	x1, x1, x0
    6534:	f9400433 	ldr	x19, [x1, #8]
    6538:	b4000113 	cbz	x19, 6558 <e161+0x188>
    653c:	f9400820 	ldr	x0, [x1, #16]
    6540:	cb130000 	sub	x0, x0, x19
    6544:	eb0002df 	cmp	x22, x0
    6548:	54000088 	b.hi	6558 <e161+0x188>  // b.pmore
    654c:	8b160260 	add	x0, x19, x22
    6550:	f9000420 	str	x0, [x1, #8]
    6554:	17ffffb7 	b	6430 <e161+0x60>
    6558:	52800001 	mov	w1, #0x0                   	// #0
    655c:	d2800300 	mov	x0, #0x18                  	// #24
    6560:	97fff9a4 	bl	4bf0 <fwp_heap_alloc>
    6564:	aa0003f3 	mov	x19, x0
    6568:	17ffffc8 	b	6488 <e161+0xb8>
    656c:	72003c3f 	tst	w1, #0xffff
    6570:	54fffc60 	b.eq	64fc <e161+0x12c>  // b.none
    6574:	aa1303e0 	mov	x0, x19
    6578:	97fffbd2 	bl	54c0 <fwp_rc_share>
    657c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6580:	aa1303e0 	mov	x0, x19
    6584:	a94153f3 	ldp	x19, x20, [sp, #16]
    6588:	a94363f7 	ldp	x23, x24, [sp, #48]
    658c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6590:	d65f03c0 	ret
    6594:	aa1403e0 	mov	x0, x20
    6598:	97fff7d6 	bl	44f0 <fwp_rc_forget_slot>
    659c:	17ffffdb 	b	6508 <e161+0x138>
    65a0:	97fff118 	bl	2a00 <fwp_trap_overflow.constprop.0>
    65a4:	97fff283 	bl	2fb0 <fwp_heap_oom>
    65a8:	d503201f 	nop
    65ac:	d503201f 	nop

00000000000065b0 <fwp_drop4>:
    65b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65b4:	910003fd 	mov	x29, sp
    65b8:	a90153f3 	stp	x19, x20, [sp, #16]
    65bc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    65c0:	f90013f5 	str	x21, [sp, #32]
    65c4:	91150275 	add	x21, x19, #0x540
    65c8:	f949daa1 	ldr	x1, [x21, #5040]
    65cc:	f949eea2 	ldr	x2, [x21, #5080]
    65d0:	cb010001 	sub	x1, x0, x1
    65d4:	eb02403f 	cmp	x1, x2, lsl #16
    65d8:	54000382 	b.cs	6648 <fwp_drop4+0x98>  // b.hs, b.nlast
    65dc:	d350fc22 	lsr	x2, x1, #16
    65e0:	f949fea3 	ldr	x3, [x21, #5112]
    65e4:	8b020842 	add	x2, x2, x2, lsl #2
    65e8:	d37df042 	lsl	x2, x2, #3
    65ec:	8b020064 	add	x4, x3, x2
    65f0:	f9401094 	ldr	x20, [x4, #32]
    65f4:	b40002b4 	cbz	x20, 6648 <fwp_drop4+0x98>
    65f8:	38626862 	ldrb	w2, [x3, x2]
    65fc:	7100085f 	cmp	w2, #0x2
    6600:	540007a0 	b.eq	66f4 <fwp_drop4+0x144>  // b.none
    6604:	7100045f 	cmp	w2, #0x1
    6608:	54000201 	b.ne	6648 <fwp_drop4+0x98>  // b.any
    660c:	29430885 	ldp	w5, w2, [x4, #24]
    6610:	92403c21 	and	x1, x1, #0xffff
    6614:	9b057c21 	mul	x1, x1, x5
    6618:	d360fc21 	lsr	x1, x1, #32
    661c:	eb02003f 	cmp	x1, x2
    6620:	54000142 	b.cs	6648 <fwp_drop4+0x98>  // b.hs, b.nlast
    6624:	8b010294 	add	x20, x20, x1
    6628:	39400281 	ldrb	w1, [x20]
    662c:	340000e1 	cbz	w1, 6648 <fwp_drop4+0x98>
    6630:	7100043f 	cmp	w1, #0x1
    6634:	54000120 	b.eq	6658 <fwp_drop4+0xa8>  // b.none
    6638:	7103fc3f 	cmp	w1, #0xff
    663c:	540007c0 	b.eq	6734 <fwp_drop4+0x184>  // b.none
    6640:	51000421 	sub	w1, w1, #0x1
    6644:	39000281 	strb	w1, [x20]
    6648:	a94153f3 	ldp	x19, x20, [sp, #16]
    664c:	f94013f5 	ldr	x21, [sp, #32]
    6650:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6654:	d65f03c0 	ret
    6658:	f9400001 	ldr	x1, [x0]
    665c:	b7f80581 	tbnz	x1, #63, 670c <fwp_drop4+0x15c>
    6660:	91150273 	add	x19, x19, #0x540
    6664:	f949da61 	ldr	x1, [x19, #5040]
    6668:	f949ee62 	ldr	x2, [x19, #5080]
    666c:	cb010001 	sub	x1, x0, x1
    6670:	eb02403f 	cmp	x1, x2, lsl #16
    6674:	54fffea2 	b.cs	6648 <fwp_drop4+0x98>  // b.hs, b.nlast
    6678:	d350fc22 	lsr	x2, x1, #16
    667c:	8b020842 	add	x2, x2, x2, lsl #2
    6680:	d37df042 	lsl	x2, x2, #3
    6684:	8b020065 	add	x5, x3, x2
    6688:	f94010a4 	ldr	x4, [x5, #32]
    668c:	b4fffde4 	cbz	x4, 6648 <fwp_drop4+0x98>
    6690:	38626862 	ldrb	w2, [x3, x2]
    6694:	7100085f 	cmp	w2, #0x2
    6698:	54000220 	b.eq	66dc <fwp_drop4+0x12c>  // b.none
    669c:	7100045f 	cmp	w2, #0x1
    66a0:	54fffd41 	b.ne	6648 <fwp_drop4+0x98>  // b.any
    66a4:	294308a3 	ldp	w3, w2, [x5, #24]
    66a8:	92403c21 	and	x1, x1, #0xffff
    66ac:	9b037c21 	mul	x1, x1, x3
    66b0:	d360fc21 	lsr	x1, x1, #32
    66b4:	eb02003f 	cmp	x1, x2
    66b8:	54fffc82 	b.cs	6648 <fwp_drop4+0x98>  // b.hs, b.nlast
    66bc:	8b010084 	add	x4, x4, x1
    66c0:	39400081 	ldrb	w1, [x4]
    66c4:	7100043f 	cmp	w1, #0x1
    66c8:	54fffc01 	b.ne	6648 <fwp_drop4+0x98>  // b.any
    66cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    66d0:	f94013f5 	ldr	x21, [sp, #32]
    66d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66d8:	17fff826 	b	4770 <fwp_mem_free>
    66dc:	72003c3f 	tst	w1, #0xffff
    66e0:	54ffff00 	b.eq	66c0 <fwp_drop4+0x110>  // b.none
    66e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66e8:	f94013f5 	ldr	x21, [sp, #32]
    66ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66f0:	d65f03c0 	ret
    66f4:	72003c3f 	tst	w1, #0xffff
    66f8:	54fff980 	b.eq	6628 <fwp_drop4+0x78>  // b.none
    66fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6700:	f94013f5 	ldr	x21, [sp, #32]
    6704:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6708:	d65f03c0 	ret
    670c:	f9400414 	ldr	x20, [x0, #8]
    6710:	97fffb91 	bl	5554 <fwp_rc_free_arr>
    6714:	91150260 	add	x0, x19, #0x540
    6718:	f949d801 	ldr	x1, [x0, #5040]
    671c:	f949ec00 	ldr	x0, [x0, #5080]
    6720:	cb010281 	sub	x1, x20, x1
    6724:	eb00403f 	cmp	x1, x0, lsl #16
    6728:	54fff902 	b.cs	6648 <fwp_drop4+0x98>  // b.hs, b.nlast
    672c:	aa1403e0 	mov	x0, x20
    6730:	17ffffab 	b	65dc <fwp_drop4+0x2c>
    6734:	ca544680 	eor	x0, x20, x20, lsr #17
    6738:	91150273 	add	x19, x19, #0x540
    673c:	ca402400 	eor	x0, x0, x0, lsr #9
    6740:	8b200e60 	add	x0, x19, w0, uxtb #3
    6744:	f94a2400 	ldr	x0, [x0, #5192]
    6748:	b5000080 	cbnz	x0, 6758 <fwp_drop4+0x1a8>
    674c:	14000010 	b	678c <fwp_drop4+0x1dc>
    6750:	f9400800 	ldr	x0, [x0, #16]
    6754:	b40001c0 	cbz	x0, 678c <fwp_drop4+0x1dc>
    6758:	f9400001 	ldr	x1, [x0]
    675c:	eb14003f 	cmp	x1, x20
    6760:	54ffff81 	b.ne	6750 <fwp_drop4+0x1a0>  // b.any
    6764:	f9400401 	ldr	x1, [x0, #8]
    6768:	d1000421 	sub	x1, x1, #0x1
    676c:	f9000401 	str	x1, [x0, #8]
    6770:	f103f83f 	cmp	x1, #0xfe
    6774:	54fff6a1 	b.ne	6648 <fwp_drop4+0x98>  // b.any
    6778:	aa1403e0 	mov	x0, x20
    677c:	97fff75d 	bl	44f0 <fwp_rc_forget_slot>
    6780:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6784:	39000280 	strb	w0, [x20]
    6788:	17ffffb0 	b	6648 <fwp_drop4+0x98>
    678c:	90000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    6790:	912aa000 	add	x0, x0, #0xaa8
    6794:	97fff35b 	bl	3500 <fwp_trap>
    6798:	d503201f 	nop
    679c:	d503201f 	nop

00000000000067a0 <fwp_caps161>:
    67a0:	34000041 	cbz	w1, 67a8 <fwp_caps161+0x8>
    67a4:	d65f03c0 	ret
    67a8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    67ac:	91150063 	add	x3, x3, #0x540
    67b0:	f949d861 	ldr	x1, [x3, #5040]
    67b4:	f949ec62 	ldr	x2, [x3, #5080]
    67b8:	cb010001 	sub	x1, x0, x1
    67bc:	eb02403f 	cmp	x1, x2, lsl #16
    67c0:	54ffff22 	b.cs	67a4 <fwp_caps161+0x4>  // b.hs, b.nlast
    67c4:	d350fc22 	lsr	x2, x1, #16
    67c8:	f949fc65 	ldr	x5, [x3, #5112]
    67cc:	8b020842 	add	x2, x2, x2, lsl #2
    67d0:	d37df042 	lsl	x2, x2, #3
    67d4:	8b0200a4 	add	x4, x5, x2
    67d8:	f9401083 	ldr	x3, [x4, #32]
    67dc:	b4fffe43 	cbz	x3, 67a4 <fwp_caps161+0x4>
    67e0:	386268a2 	ldrb	w2, [x5, x2]
    67e4:	7100085f 	cmp	w2, #0x2
    67e8:	540001c0 	b.eq	6820 <fwp_caps161+0x80>  // b.none
    67ec:	7100045f 	cmp	w2, #0x1
    67f0:	54fffda1 	b.ne	67a4 <fwp_caps161+0x4>  // b.any
    67f4:	29430885 	ldp	w5, w2, [x4, #24]
    67f8:	92403c21 	and	x1, x1, #0xffff
    67fc:	9b057c21 	mul	x1, x1, x5
    6800:	d360fc21 	lsr	x1, x1, #32
    6804:	eb02003f 	cmp	x1, x2
    6808:	54fffce2 	b.cs	67a4 <fwp_caps161+0x4>  // b.hs, b.nlast
    680c:	8b010063 	add	x3, x3, x1
    6810:	39400061 	ldrb	w1, [x3]
    6814:	7100043f 	cmp	w1, #0x1
    6818:	54fffc61 	b.ne	67a4 <fwp_caps161+0x4>  // b.any
    681c:	17fff7d5 	b	4770 <fwp_mem_free>
    6820:	72003c3f 	tst	w1, #0xffff
    6824:	54ffff60 	b.eq	6810 <fwp_caps161+0x70>  // b.none
    6828:	d65f03c0 	ret
    682c:	d503201f 	nop

0000000000006830 <f12>:
    6830:	d10443ff 	sub	sp, sp, #0x110
    6834:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6838:	f947f442 	ldr	x2, [x2, #4072]
    683c:	a90a7bfd 	stp	x29, x30, [sp, #160]
    6840:	910283fd 	add	x29, sp, #0xa0
    6844:	a90b53f3 	stp	x19, x20, [sp, #176]
    6848:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    684c:	91150283 	add	x3, x20, #0x540
    6850:	a90d63f7 	stp	x23, x24, [sp, #208]
    6854:	d00000d7 	adrp	x23, 20000 <__data_start>
    6858:	9100c2e4 	add	x4, x23, #0x30
    685c:	f949d861 	ldr	x1, [x3, #5040]
    6860:	a90c5bf5 	stp	x21, x22, [sp, #192]
    6864:	d00000d5 	adrp	x21, 20000 <__data_start>
    6868:	f949ec65 	ldr	x5, [x3, #5080]
    686c:	a90e6bf9 	stp	x25, x26, [sp, #224]
    6870:	910042b5 	add	x21, x21, #0x10
    6874:	a90f73fb 	stp	x27, x28, [sp, #240]
    6878:	9100c3f9 	add	x25, sp, #0x30
    687c:	9100a3f8 	add	x24, sp, #0x28
    6880:	f9416086 	ldr	x6, [x4, #704]
    6884:	fd0083e8 	str	d8, [sp, #256]
    6888:	f9400047 	ldr	x7, [x2]
    688c:	f9004fe7 	str	x7, [sp, #152]
    6890:	d2800007 	mov	x7, #0x0                   	// #0
    6894:	f0fffff3 	adrp	x19, 5000 <fwp_p_ad_push.constprop.0+0xdc>
    6898:	12800007 	mov	w7, #0xffffffff            	// #-1
    689c:	9132c262 	add	x2, x19, #0xcb0
    68a0:	cb0102a1 	sub	x1, x21, x1
    68a4:	b9002be7 	str	w7, [sp, #40]
    68a8:	a9030be6 	stp	x6, x2, [sp, #48]
    68ac:	aa0003f6 	mov	x22, x0
    68b0:	f90023f8 	str	x24, [sp, #64]
    68b4:	f9016099 	str	x25, [x4, #704]
    68b8:	eb05403f 	cmp	x1, x5, lsl #16
    68bc:	54000342 	b.cs	6924 <f12+0xf4>  // b.hs, b.nlast
    68c0:	d350fc20 	lsr	x0, x1, #16
    68c4:	f949fc64 	ldr	x4, [x3, #5112]
    68c8:	8b000800 	add	x0, x0, x0, lsl #2
    68cc:	d37df002 	lsl	x2, x0, #3
    68d0:	8b020083 	add	x3, x4, x2
    68d4:	f9401060 	ldr	x0, [x3, #32]
    68d8:	b4000260 	cbz	x0, 6924 <f12+0xf4>
    68dc:	38626882 	ldrb	w2, [x4, x2]
    68e0:	7100085f 	cmp	w2, #0x2
    68e4:	540077c0 	b.eq	77dc <f12+0xfac>  // b.none
    68e8:	7100045f 	cmp	w2, #0x1
    68ec:	540001c1 	b.ne	6924 <f12+0xf4>  // b.any
    68f0:	29430864 	ldp	w4, w2, [x3, #24]
    68f4:	92403c21 	and	x1, x1, #0xffff
    68f8:	9b047c21 	mul	x1, x1, x4
    68fc:	d360fc21 	lsr	x1, x1, #32
    6900:	eb02003f 	cmp	x1, x2
    6904:	54000102 	b.cs	6924 <f12+0xf4>  // b.hs, b.nlast
    6908:	8b010000 	add	x0, x0, x1
    690c:	39400001 	ldrb	w1, [x0]
    6910:	340000a1 	cbz	w1, 6924 <f12+0xf4>
    6914:	7103f43f 	cmp	w1, #0xfd
    6918:	54007e88 	b.hi	78e8 <f12+0x10b8>  // b.pmore
    691c:	11000421 	add	w1, w1, #0x1
    6920:	39000001 	strb	w1, [x0]
    6924:	aa1503e0 	mov	x0, x21
    6928:	97fffc02 	bl	5930 <fwp_closure_drop>
    692c:	b4007636 	cbz	x22, 77f0 <f12+0xfc0>
    6930:	aa1603e0 	mov	x0, x22
    6934:	d2800001 	mov	x1, #0x0                   	// #0
    6938:	f9400800 	ldr	x0, [x0, #16]
    693c:	91000421 	add	x1, x1, #0x1
    6940:	b5ffffc0 	cbnz	x0, 6938 <f12+0x108>
    6944:	aa0103fa 	mov	x26, x1
    6948:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    694c:	eb00003f 	cmp	x1, x0
    6950:	540081a8 	b.hi	7984 <f12+0x1154>  // b.pmore
    6954:	9100c2f5 	add	x21, x23, #0x30
    6958:	b942f6a0 	ldr	w0, [x21, #756]
    695c:	340072c0 	cbz	w0, 77b4 <f12+0xf84>
    6960:	9100c2e0 	add	x0, x23, #0x30
    6964:	f940201b 	ldr	x27, [x0, #64]
    6968:	f9404c15 	ldr	x21, [x0, #152]
    696c:	eb1b02bf 	cmp	x21, x27
    6970:	5400354a 	b.ge	7018 <f12+0x7e8>  // b.tcont
    6974:	f9401ae1 	ldr	x1, [x23, #48]
    6978:	8b1506a0 	add	x0, x21, x21, lsl #1
    697c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6980:	8b000aa0 	add	x0, x21, x0, lsl #2
    6984:	8b000c20 	add	x0, x1, x0, lsl #3
    6988:	b9400401 	ldr	w1, [x0, #4]
    698c:	35000081 	cbnz	w1, 699c <f12+0x16c>
    6990:	b9400001 	ldr	w1, [x0]
    6994:	6b02003f 	cmp	w1, w2
    6998:	54003409 	b.ls	7018 <f12+0x7e8>  // b.plast
    699c:	910006b5 	add	x21, x21, #0x1
    69a0:	9101a000 	add	x0, x0, #0x68
    69a4:	eb1b02bf 	cmp	x21, x27
    69a8:	54ffff01 	b.ne	6988 <f12+0x158>  // b.any
    69ac:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    69b0:	eb00037f 	cmp	x27, x0
    69b4:	54007eec 	b.gt	7990 <f12+0x1160>
    69b8:	9100c2e0 	add	x0, x23, #0x30
    69bc:	f9401afc 	ldr	x28, [x23, #48]
    69c0:	f9404800 	ldr	x0, [x0, #144]
    69c4:	eb1b001f 	cmp	x0, x27
    69c8:	54000241 	b.ne	6a10 <f12+0x1e0>  // b.any
    69cc:	b400777b 	cbz	x27, 78b8 <f12+0x1088>
    69d0:	d37ffb62 	lsl	x2, x27, #1
    69d4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    69d8:	eb00005f 	cmp	x2, x0
    69dc:	9a80d042 	csel	x2, x2, x0, le
    69e0:	8b020441 	add	x1, x2, x2, lsl #1
    69e4:	8b010841 	add	x1, x2, x1, lsl #2
    69e8:	d37df021 	lsl	x1, x1, #3
    69ec:	aa1c03e0 	mov	x0, x28
    69f0:	f90003e2 	str	x2, [sp]
    69f4:	97ffef7b 	bl	27e0 <realloc@plt>
    69f8:	aa0003fc 	mov	x28, x0
    69fc:	f94003e2 	ldr	x2, [sp]
    6a00:	b4006bc0 	cbz	x0, 7778 <f12+0xf48>
    6a04:	9100c2e0 	add	x0, x23, #0x30
    6a08:	f9001afc 	str	x28, [x23, #48]
    6a0c:	f9004802 	str	x2, [x0, #144]
    6a10:	9100c2e1 	add	x1, x23, #0x30
    6a14:	8b1b0760 	add	x0, x27, x27, lsl #1
    6a18:	4f000400 	movi	v0.4s, #0x0
    6a1c:	91000762 	add	x2, x27, #0x1
    6a20:	8b000b60 	add	x0, x27, x0, lsl #2
    6a24:	f9002022 	str	x2, [x1, #64]
    6a28:	8b1506a1 	add	x1, x21, x21, lsl #1
    6a2c:	8b000f80 	add	x0, x28, x0, lsl #3
    6a30:	8b010abb 	add	x27, x21, x1, lsl #2
    6a34:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6a38:	ad000000 	stp	q0, q0, [x0]
    6a3c:	ad010000 	stp	q0, q0, [x0, #32]
    6a40:	ad020000 	stp	q0, q0, [x0, #64]
    6a44:	f900301f 	str	xzr, [x0, #96]
    6a48:	90000020 	adrp	x0, a000 <fwp_main_thread+0xb80>
    6a4c:	f900337f 	str	xzr, [x27, #96]
    6a50:	9128e000 	add	x0, x0, #0xa38
    6a54:	97ffefcb 	bl	2980 <getenv@plt>
    6a58:	b5002f60 	cbnz	x0, 7044 <f12+0x814>
    6a5c:	d503201f 	nop
    6a60:	9100c2e0 	add	x0, x23, #0x30
    6a64:	f9404001 	ldr	x1, [x0, #128]
    6a68:	b5006d21 	cbnz	x1, 780c <f12+0xfdc>
    6a6c:	9100c2e1 	add	x1, x23, #0x30
    6a70:	2f000400 	mvni	v0.2s, #0x0
    6a74:	b9400362 	ldr	w2, [x27]
    6a78:	52800024 	mov	w4, #0x1                   	// #1
    6a7c:	910006a3 	add	x3, x21, #0x1
    6a80:	a900eb7a 	stp	x26, x26, [x27, #8]
    6a84:	0b040042 	add	w2, w2, w4
    6a88:	f9416020 	ldr	x0, [x1, #704]
    6a8c:	29001362 	stp	w2, w4, [x27]
    6a90:	f9002b7f 	str	xzr, [x27, #80]
    6a94:	f9004c23 	str	x3, [x1, #152]
    6a98:	fd002f60 	str	d0, [x27, #88]
    6a9c:	b40076e0 	cbz	x0, 7978 <f12+0x1148>
    6aa0:	9132c273 	add	x19, x19, #0xcb0
    6aa4:	14000003 	b	6ab0 <f12+0x280>
    6aa8:	f9400000 	ldr	x0, [x0]
    6aac:	b4007660 	cbz	x0, 7978 <f12+0x1148>
    6ab0:	f9400401 	ldr	x1, [x0, #8]
    6ab4:	eb13003f 	cmp	x1, x19
    6ab8:	54ffff81 	b.ne	6aa8 <f12+0x278>  // b.any
    6abc:	f9400800 	ldr	x0, [x0, #16]
    6ac0:	2a1503e4 	mov	w4, w21
    6ac4:	b9400001 	ldr	w1, [x0]
    6ac8:	f9002b60 	str	x0, [x27, #80]
    6acc:	b9005f61 	str	w1, [x27, #92]
    6ad0:	37f80081 	tbnz	w1, #31, 6ae0 <f12+0x2b0>
    6ad4:	52800d05 	mov	w5, #0x68                  	// #104
    6ad8:	9b257021 	smaddl	x1, w1, w5, x28
    6adc:	b9005835 	str	w21, [x1, #88]
    6ae0:	b9000004 	str	w4, [x0]
    6ae4:	d3707c42 	ubfiz	x2, x2, #16, #32
    6ae8:	aa03005a 	orr	x26, x2, x3
    6aec:	aa1603e0 	mov	x0, x22
    6af0:	d2800002 	mov	x2, #0x0                   	// #0
    6af4:	b4006136 	cbz	x22, 7718 <f12+0xee8>
    6af8:	f9400800 	ldr	x0, [x0, #16]
    6afc:	91000442 	add	x2, x2, #0x1
    6b00:	b5ffffc0 	cbnz	x0, 6af8 <f12+0x2c8>
    6b04:	aa1603e1 	mov	x1, x22
    6b08:	f9400821 	ldr	x1, [x1, #16]
    6b0c:	91000400 	add	x0, x0, #0x1
    6b10:	b5ffffc1 	cbnz	x1, 6b08 <f12+0x2d8>
    6b14:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6b18:	eb01001f 	cmp	x0, x1
    6b1c:	54007468 	b.hi	79a8 <f12+0x1178>  // b.pmore
    6b20:	f100005f 	cmp	x2, #0x0
    6b24:	54005fad 	b.le	7718 <f12+0xee8>
    6b28:	eb00005f 	cmp	x2, x0
    6b2c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6b30:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6b34:	eb01027f 	cmp	x19, x1
    6b38:	54007388 	b.hi	79a8 <f12+0x1178>  // b.pmore
    6b3c:	d37ffa75 	lsl	x21, x19, #1
    6b40:	52800041 	mov	w1, #0x2                   	// #2
    6b44:	910006a0 	add	x0, x21, #0x1
    6b48:	d37df000 	lsl	x0, x0, #3
    6b4c:	97fff829 	bl	4bf0 <fwp_heap_alloc>
    6b50:	aa0003fb 	mov	x27, x0
    6b54:	91150281 	add	x1, x20, #0x540
    6b58:	aa0103e0 	mov	x0, x1
    6b5c:	f9000375 	str	x21, [x27]
    6b60:	f949d821 	ldr	x1, [x1, #5040]
    6b64:	f949ec00 	ldr	x0, [x0, #5080]
    6b68:	cb010361 	sub	x1, x27, x1
    6b6c:	eb00403f 	cmp	x1, x0, lsl #16
    6b70:	540061c2 	b.cs	77a8 <f12+0xf78>  // b.hs, b.nlast
    6b74:	91150282 	add	x2, x20, #0x540
    6b78:	d350fc20 	lsr	x0, x1, #16
    6b7c:	8b000800 	add	x0, x0, x0, lsl #2
    6b80:	f949fc43 	ldr	x3, [x2, #5112]
    6b84:	d37df002 	lsl	x2, x0, #3
    6b88:	8b020060 	add	x0, x3, x2
    6b8c:	f9401015 	ldr	x21, [x0, #32]
    6b90:	b4000255 	cbz	x21, 6bd8 <f12+0x3a8>
    6b94:	38626862 	ldrb	w2, [x3, x2]
    6b98:	7100085f 	cmp	w2, #0x2
    6b9c:	540061a0 	b.eq	77d0 <f12+0xfa0>  // b.none
    6ba0:	7100045f 	cmp	w2, #0x1
    6ba4:	540001a1 	b.ne	6bd8 <f12+0x3a8>  // b.any
    6ba8:	29430002 	ldp	w2, w0, [x0, #24]
    6bac:	92403c21 	and	x1, x1, #0xffff
    6bb0:	9b027c21 	mul	x1, x1, x2
    6bb4:	d360fc21 	lsr	x1, x1, #32
    6bb8:	eb00003f 	cmp	x1, x0
    6bbc:	540000e2 	b.cs	6bd8 <f12+0x3a8>  // b.hs, b.nlast
    6bc0:	8b0102b5 	add	x21, x21, x1
    6bc4:	394002a0 	ldrb	w0, [x21]
    6bc8:	7103fc1f 	cmp	w0, #0xff
    6bcc:	540067c0 	b.eq	78c4 <f12+0x1094>  // b.none
    6bd0:	52800020 	mov	w0, #0x1                   	// #1
    6bd4:	390002a0 	strb	w0, [x21]
    6bd8:	b4000233 	cbz	x19, 6c1c <f12+0x3ec>
    6bdc:	d3607f44 	lsl	x4, x26, #32
    6be0:	aa1603e2 	mov	x2, x22
    6be4:	f94006c5 	ldr	x5, [x22, #8]
    6be8:	aa0403e3 	mov	x3, x4
    6bec:	91002360 	add	x0, x27, #0x8
    6bf0:	d2800001 	mov	x1, #0x0                   	// #0
    6bf4:	14000005 	b	6c08 <f12+0x3d8>
    6bf8:	f9400445 	ldr	x5, [x2, #8]
    6bfc:	ab040023 	adds	x3, x1, x4
    6c00:	91004000 	add	x0, x0, #0x10
    6c04:	54006da6 	b.vs	79b8 <f12+0x1188>
    6c08:	a9000c05 	stp	x5, x3, [x0]
    6c0c:	91000421 	add	x1, x1, #0x1
    6c10:	f9400842 	ldr	x2, [x2, #16]
    6c14:	eb01027f 	cmp	x19, x1
    6c18:	54ffff08 	b.hi	6bf8 <f12+0x3c8>  // b.pmore
    6c1c:	f9400360 	ldr	x0, [x27]
    6c20:	f100041f 	cmp	x0, #0x1
    6c24:	54005c49 	b.ls	77ac <f12+0xf7c>  // b.plast
    6c28:	d341fc00 	lsr	x0, x0, #1
    6c2c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    6c30:	d1000401 	sub	x1, x0, #0x1
    6c34:	eb02003f 	cmp	x1, x2
    6c38:	54006b88 	b.hi	79a8 <f12+0x1178>  // b.pmore
    6c3c:	d37ff83c 	lsl	x28, x1, #1
    6c40:	b4005b61 	cbz	x1, 77ac <f12+0xf7c>
    6c44:	d1002361 	sub	x1, x27, #0x8
    6c48:	91002373 	add	x19, x27, #0x8
    6c4c:	8b001035 	add	x21, x1, x0, lsl #4
    6c50:	f9400660 	ldr	x0, [x19, #8]
    6c54:	f9400e61 	ldr	x1, [x19, #24]
    6c58:	fd400260 	ldr	d0, [x19]
    6c5c:	fd400a61 	ldr	d1, [x19, #16]
    6c60:	97fff964 	bl	51f0 <w107>
    6c64:	a9000660 	stp	x0, x1, [x19]
    6c68:	91004273 	add	x19, x19, #0x10
    6c6c:	eb15027f 	cmp	x19, x21
    6c70:	54ffff01 	b.ne	6c50 <f12+0x420>  // b.any
    6c74:	f900037c 	str	x28, [x27]
    6c78:	aa1b03e0 	mov	x0, x27
    6c7c:	93407f53 	sxtw	x19, w26
    6c80:	97fff9a0 	bl	5300 <w164.constprop.0>
    6c84:	aa0103f5 	mov	x21, x1
    6c88:	aa1b03e0 	mov	x0, x27
    6c8c:	97fffe49 	bl	65b0 <fwp_drop4>
    6c90:	aa1303e0 	mov	x0, x19
    6c94:	97fff2e7 	bl	3830 <fwp_tape_of>
    6c98:	f9403001 	ldr	x1, [x0, #96]
    6c9c:	aa0003e8 	mov	x8, x0
    6ca0:	b50067e1 	cbnz	x1, 799c <f12+0x116c>
    6ca4:	97fff09b 	bl	2f10 <fwp_tape_unlink_scope>
    6ca8:	b900051f 	str	wzr, [x8, #4]
    6cac:	b9400102 	ldr	w2, [x8]
    6cb0:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    6cb4:	a940851c 	ldp	x28, x1, [x8, #8]
    6cb8:	a941910a 	ldp	x10, x4, [x8, #24]
    6cbc:	a9429905 	ldp	x5, x6, [x8, #40]
    6cc0:	a9438d07 	ldp	x7, x3, [x8, #56]
    6cc4:	f940251b 	ldr	x27, [x8, #72]
    6cc8:	6b00005f 	cmp	w2, w0
    6ccc:	54000108 	b.hi	6cec <f12+0x4bc>  // b.pmore
    6cd0:	9100c2e2 	add	x2, x23, #0x30
    6cd4:	92403e60 	and	x0, x19, #0xffff
    6cd8:	d1000400 	sub	x0, x0, #0x1
    6cdc:	f9404c49 	ldr	x9, [x2, #152]
    6ce0:	eb09001f 	cmp	x0, x9
    6ce4:	5400004a 	b.ge	6cec <f12+0x4bc>  // b.tcont
    6ce8:	f9004c40 	str	x0, [x2, #152]
    6cec:	4f000400 	movi	v0.4s, #0x0
    6cf0:	9100c2e9 	add	x9, x23, #0x30
    6cf4:	f9000d1f 	str	xzr, [x8, #24]
    6cf8:	910123e0 	add	x0, sp, #0x48
    6cfc:	910183fa 	add	x26, sp, #0x60
    6d00:	d0ffffe2 	adrp	x2, 4000 <fwp_wake_io+0x3c>
    6d04:	f941612b 	ldr	x11, [x9, #704]
    6d08:	3c808100 	stur	q0, [x8, #8]
    6d0c:	91020042 	add	x2, x2, #0x80
    6d10:	ad010100 	stp	q0, q0, [x8, #32]
    6d14:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    6d18:	a9048beb 	stp	x11, x2, [sp, #72]
    6d1c:	a90593fa 	stp	x26, x4, [sp, #88]
    6d20:	a9069be5 	stp	x5, x6, [sp, #104]
    6d24:	a9078fe7 	stp	x7, x3, [sp, #120]
    6d28:	a908efea 	stp	x10, x27, [sp, #136]
    6d2c:	f9016120 	str	x0, [x9, #704]
    6d30:	b7f856b5 	tbnz	x21, #63, 7804 <f12+0xfd4>
    6d34:	eb95827f 	cmp	x19, x21, asr #32
    6d38:	540060a1 	b.ne	794c <f12+0x111c>  // b.any
    6d3c:	92407eb3 	and	x19, x21, #0xffffffff
    6d40:	eb35403f 	cmp	x1, w21, uxtw
    6d44:	54005fed 	b.le	7940 <f12+0x1110>
    6d48:	eb13039f 	cmp	x28, x19
    6d4c:	9a93c793 	csinc	x19, x28, x19, gt
    6d50:	eb13037f 	cmp	x27, x19
    6d54:	5400502a 	b.ge	7758 <f12+0xf28>  // b.tcont
    6d58:	f100037f 	cmp	x27, #0x0
    6d5c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    6d60:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    6d64:	14000004 	b	6d74 <f12+0x544>
    6d68:	eb01037f 	cmp	x27, x1
    6d6c:	d37ffb7b 	lsl	x27, x27, #1
    6d70:	9a93d37b 	csel	x27, x27, x19, le
    6d74:	eb13037f 	cmp	x27, x19
    6d78:	54ffff8b 	b.lt	6d68 <f12+0x538>  // b.tstop
    6d7c:	a90017e4 	stp	x4, x5, [sp]
    6d80:	a9011fe6 	stp	x6, x7, [sp, #16]
    6d84:	b4005763 	cbz	x3, 7870 <f12+0x1040>
    6d88:	aa0303e0 	mov	x0, x3
    6d8c:	d37df361 	lsl	x1, x27, #3
    6d90:	97ffee94 	bl	27e0 <realloc@plt>
    6d94:	aa0003e3 	mov	x3, x0
    6d98:	a94017e4 	ldp	x4, x5, [sp]
    6d9c:	a9411fe6 	ldp	x6, x7, [sp, #16]
    6da0:	b4004dc3 	cbz	x3, 7758 <f12+0xf28>
    6da4:	f90043e3 	str	x3, [sp, #128]
    6da8:	f9004bfb 	str	x27, [sp, #144]
    6dac:	b5001593 	cbnz	x19, 705c <f12+0x82c>
    6db0:	b7f800d5 	tbnz	x21, #63, 6dc8 <f12+0x598>
    6db4:	92407eb5 	and	x21, x21, #0xffffffff
    6db8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    6dbc:	fc757860 	ldr	d0, [x3, x21, lsl #3]
    6dc0:	1e612800 	fadd	d0, d0, d1
    6dc4:	fc357860 	str	d0, [x3, x21, lsl #3]
    6dc8:	d1000673 	sub	x19, x19, #0x1
    6dcc:	d1000788 	sub	x8, x28, #0x1
    6dd0:	eb13039f 	cmp	x28, x19
    6dd4:	540003ac 	b.gt	6e48 <f12+0x618>
    6dd8:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    6ddc:	1e602008 	fcmp	d0, #0.0
    6de0:	540002e0 	b.eq	6e3c <f12+0x60c>  // b.none
    6de4:	cb1c0be0 	neg	x0, x28, lsl #2
    6de8:	cb1c03e2 	neg	x2, x28
    6dec:	8b000081 	add	x1, x4, x0
    6df0:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    6df4:	37f80101 	tbnz	w1, #31, 6e14 <f12+0x5e4>
    6df8:	8b020cc9 	add	x9, x6, x2, lsl #3
    6dfc:	93407c21 	sxtw	x1, w1
    6e00:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    6e04:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    6e08:	1e620802 	fmul	d2, d0, d2
    6e0c:	1e622821 	fadd	d1, d1, d2
    6e10:	fc217861 	str	d1, [x3, x1, lsl #3]
    6e14:	8b0000a0 	add	x0, x5, x0
    6e18:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    6e1c:	37f80100 	tbnz	w0, #31, 6e3c <f12+0x60c>
    6e20:	8b020ce2 	add	x2, x7, x2, lsl #3
    6e24:	93407c00 	sxtw	x0, w0
    6e28:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    6e2c:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    6e30:	1e620800 	fmul	d0, d0, d2
    6e34:	1e602820 	fadd	d0, d1, d0
    6e38:	fc207860 	str	d0, [x3, x0, lsl #3]
    6e3c:	d1000673 	sub	x19, x19, #0x1
    6e40:	eb08027f 	cmp	x19, x8
    6e44:	54fffca1 	b.ne	6dd8 <f12+0x5a8>  // b.any
    6e48:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    6e4c:	eb00039f 	cmp	x28, x0
    6e50:	540058c8 	b.hi	7968 <f12+0x1138>  // b.pmore
    6e54:	91000780 	add	x0, x28, #0x1
    6e58:	52800041 	mov	w1, #0x2                   	// #2
    6e5c:	f90003e3 	str	x3, [sp]
    6e60:	d37df000 	lsl	x0, x0, #3
    6e64:	97fff763 	bl	4bf0 <fwp_heap_alloc>
    6e68:	aa0003e2 	mov	x2, x0
    6e6c:	aa0003f3 	mov	x19, x0
    6e70:	f94003e3 	ldr	x3, [sp]
    6e74:	d2800001 	mov	x1, #0x0                   	// #0
    6e78:	f800845c 	str	x28, [x2], #8
    6e7c:	b40000dc 	cbz	x28, 6e94 <f12+0x664>
    6e80:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    6e84:	f8217840 	str	x0, [x2, x1, lsl #3]
    6e88:	91000421 	add	x1, x1, #0x1
    6e8c:	eb01039f 	cmp	x28, x1
    6e90:	54ffff81 	b.ne	6e80 <f12+0x650>  // b.any
    6e94:	9100c2e1 	add	x1, x23, #0x30
    6e98:	aa1a03e0 	mov	x0, x26
    6e9c:	f94027fa 	ldr	x26, [sp, #72]
    6ea0:	f901603a 	str	x26, [x1, #704]
    6ea4:	97fff477 	bl	4080 <fwp_tape_buffers_release>
    6ea8:	91150282 	add	x2, x20, #0x540
    6eac:	f949d841 	ldr	x1, [x2, #5040]
    6eb0:	f949ec40 	ldr	x0, [x2, #5080]
    6eb4:	cb010261 	sub	x1, x19, x1
    6eb8:	eb00403f 	cmp	x1, x0, lsl #16
    6ebc:	54000322 	b.cs	6f20 <f12+0x6f0>  // b.hs, b.nlast
    6ec0:	d350fc20 	lsr	x0, x1, #16
    6ec4:	f949fc43 	ldr	x3, [x2, #5112]
    6ec8:	8b000800 	add	x0, x0, x0, lsl #2
    6ecc:	d37df002 	lsl	x2, x0, #3
    6ed0:	8b020060 	add	x0, x3, x2
    6ed4:	f9401015 	ldr	x21, [x0, #32]
    6ed8:	b4000255 	cbz	x21, 6f20 <f12+0x6f0>
    6edc:	38626862 	ldrb	w2, [x3, x2]
    6ee0:	7100085f 	cmp	w2, #0x2
    6ee4:	540048a0 	b.eq	77f8 <f12+0xfc8>  // b.none
    6ee8:	7100045f 	cmp	w2, #0x1
    6eec:	540001a1 	b.ne	6f20 <f12+0x6f0>  // b.any
    6ef0:	29430002 	ldp	w2, w0, [x0, #24]
    6ef4:	92403c21 	and	x1, x1, #0xffff
    6ef8:	9b027c21 	mul	x1, x1, x2
    6efc:	d360fc21 	lsr	x1, x1, #32
    6f00:	eb00003f 	cmp	x1, x0
    6f04:	540000e2 	b.cs	6f20 <f12+0x6f0>  // b.hs, b.nlast
    6f08:	8b0102b5 	add	x21, x21, x1
    6f0c:	394002a0 	ldrb	w0, [x21]
    6f10:	7103fc1f 	cmp	w0, #0xff
    6f14:	54004de0 	b.eq	78d0 <f12+0x10a0>  // b.none
    6f18:	52800020 	mov	w0, #0x1                   	// #1
    6f1c:	390002a0 	strb	w0, [x21]
    6f20:	eb19035f 	cmp	x26, x25
    6f24:	54005481 	b.ne	79b4 <f12+0x1184>  // b.any
    6f28:	f9401be1 	ldr	x1, [sp, #48]
    6f2c:	9100c2f7 	add	x23, x23, #0x30
    6f30:	aa1803e0 	mov	x0, x24
    6f34:	f90162e1 	str	x1, [x23, #704]
    6f38:	97fffb5e 	bl	5cb0 <fwp_tape_scope_release>
    6f3c:	f9400260 	ldr	x0, [x19]
    6f40:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    6f44:	b7f83960 	tbnz	x0, #63, 7670 <f12+0xe40>
    6f48:	91150282 	add	x2, x20, #0x540
    6f4c:	f949d840 	ldr	x0, [x2, #5040]
    6f50:	f949ec41 	ldr	x1, [x2, #5080]
    6f54:	cb000260 	sub	x0, x19, x0
    6f58:	eb01401f 	cmp	x0, x1, lsl #16
    6f5c:	540038a2 	b.cs	7670 <f12+0xe40>  // b.hs, b.nlast
    6f60:	d350fc01 	lsr	x1, x0, #16
    6f64:	f949fc44 	ldr	x4, [x2, #5112]
    6f68:	8b010821 	add	x1, x1, x1, lsl #2
    6f6c:	d37df021 	lsl	x1, x1, #3
    6f70:	8b010083 	add	x3, x4, x1
    6f74:	f9401062 	ldr	x2, [x3, #32]
    6f78:	b40037c2 	cbz	x2, 7670 <f12+0xe40>
    6f7c:	38616881 	ldrb	w1, [x4, x1]
    6f80:	7100083f 	cmp	w1, #0x2
    6f84:	54003700 	b.eq	7664 <f12+0xe34>  // b.none
    6f88:	7100043f 	cmp	w1, #0x1
    6f8c:	54003721 	b.ne	7670 <f12+0xe40>  // b.any
    6f90:	29430464 	ldp	w4, w1, [x3, #24]
    6f94:	92403c00 	and	x0, x0, #0xffff
    6f98:	9b047c00 	mul	x0, x0, x4
    6f9c:	d360fc00 	lsr	x0, x0, #32
    6fa0:	eb01001f 	cmp	x0, x1
    6fa4:	54003662 	b.cs	7670 <f12+0xe40>  // b.hs, b.nlast
    6fa8:	8b000042 	add	x2, x2, x0
    6fac:	39400040 	ldrb	w0, [x2]
    6fb0:	7100041f 	cmp	w0, #0x1
    6fb4:	540035e1 	b.ne	7670 <f12+0xe40>  // b.any
    6fb8:	aa1303f9 	mov	x25, x19
    6fbc:	d2800000 	mov	x0, #0x0                   	// #0
    6fc0:	f9000bf3 	str	x19, [sp, #16]
    6fc4:	f9400be1 	ldr	x1, [sp, #16]
    6fc8:	91002023 	add	x3, x1, #0x8
    6fcc:	d2800001 	mov	x1, #0x0                   	// #0
    6fd0:	b40005b7 	cbz	x23, 7084 <f12+0x854>
    6fd4:	b0000022 	adrp	x2, b000 <_IO_stdin_used+0x800>
    6fd8:	91002265 	add	x5, x19, #0x8
    6fdc:	fd426c41 	ldr	d1, [x2, #1240]
    6fe0:	14000009 	b	7004 <f12+0x7d4>
    6fe4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    6fe8:	f9400322 	ldr	x2, [x25]
    6fec:	1e600820 	fmul	d0, d1, d0
    6ff0:	b7f84b62 	tbnz	x2, #63, 795c <f12+0x112c>
    6ff4:	91000421 	add	x1, x1, #0x1
    6ff8:	fc008460 	str	d0, [x3], #8
    6ffc:	eb0102ff 	cmp	x23, x1
    7000:	54000420 	b.eq	7084 <f12+0x854>  // b.none
    7004:	f9400264 	ldr	x4, [x19]
    7008:	aa0503e2 	mov	x2, x5
    700c:	b6fffec4 	tbz	x4, #63, 6fe4 <f12+0x7b4>
    7010:	f9400a62 	ldr	x2, [x19, #16]
    7014:	17fffff4 	b	6fe4 <f12+0x7b4>
    7018:	eb1b02bf 	cmp	x21, x27
    701c:	54ffcc80 	b.eq	69ac <f12+0x17c>  // b.none
    7020:	f9401afc 	ldr	x28, [x23, #48]
    7024:	8b1506a1 	add	x1, x21, x21, lsl #1
    7028:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    702c:	9128e000 	add	x0, x0, #0xa38
    7030:	8b010abb 	add	x27, x21, x1, lsl #2
    7034:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7038:	f900337f 	str	xzr, [x27, #96]
    703c:	97ffee51 	bl	2980 <getenv@plt>
    7040:	b4ffd100 	cbz	x0, 6a60 <f12+0x230>
    7044:	39400001 	ldrb	w1, [x0]
    7048:	7100c03f 	cmp	w1, #0x30
    704c:	54ffd0a1 	b.ne	6a60 <f12+0x230>  // b.any
    7050:	39400400 	ldrb	w0, [x0, #1]
    7054:	34ffd0c0 	cbz	w0, 6a6c <f12+0x23c>
    7058:	17fffe82 	b	6a60 <f12+0x230>
    705c:	aa0303e0 	mov	x0, x3
    7060:	d37df262 	lsl	x2, x19, #3
    7064:	52800001 	mov	w1, #0x0                   	// #0
    7068:	a90017e4 	stp	x4, x5, [sp]
    706c:	a9011fe6 	stp	x6, x7, [sp, #16]
    7070:	97ffedd4 	bl	27c0 <memset@plt>
    7074:	aa0003e3 	mov	x3, x0
    7078:	a94017e4 	ldp	x4, x5, [sp]
    707c:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7080:	17ffff4c 	b	6db0 <f12+0x580>
    7084:	97fffd4b 	bl	65b0 <fwp_drop4>
    7088:	aa1603e1 	mov	x1, x22
    708c:	d2800002 	mov	x2, #0x0                   	// #0
    7090:	b4003ff6 	cbz	x22, 788c <f12+0x105c>
    7094:	d503201f 	nop
    7098:	f9400821 	ldr	x1, [x1, #16]
    709c:	91000442 	add	x2, x2, #0x1
    70a0:	b5ffffc1 	cbnz	x1, 7098 <f12+0x868>
    70a4:	f9400323 	ldr	x3, [x25]
    70a8:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    70ac:	b7f82a63 	tbnz	x3, #63, 75f8 <f12+0xdc8>
    70b0:	91150281 	add	x1, x20, #0x540
    70b4:	f9400be4 	ldr	x4, [sp, #16]
    70b8:	f949d820 	ldr	x0, [x1, #5040]
    70bc:	f949ec21 	ldr	x1, [x1, #5080]
    70c0:	cb000080 	sub	x0, x4, x0
    70c4:	eb01401f 	cmp	x0, x1, lsl #16
    70c8:	54002982 	b.cs	75f8 <f12+0xdc8>  // b.hs, b.nlast
    70cc:	91150284 	add	x4, x20, #0x540
    70d0:	d350fc01 	lsr	x1, x0, #16
    70d4:	8b010821 	add	x1, x1, x1, lsl #2
    70d8:	f949fc86 	ldr	x6, [x4, #5112]
    70dc:	d37df021 	lsl	x1, x1, #3
    70e0:	8b0100c5 	add	x5, x6, x1
    70e4:	f94010a4 	ldr	x4, [x5, #32]
    70e8:	b4002864 	cbz	x4, 75f4 <f12+0xdc4>
    70ec:	386168c1 	ldrb	w1, [x6, x1]
    70f0:	7100083f 	cmp	w1, #0x2
    70f4:	540027c0 	b.eq	75ec <f12+0xdbc>  // b.none
    70f8:	7100043f 	cmp	w1, #0x1
    70fc:	540027c1 	b.ne	75f4 <f12+0xdc4>  // b.any
    7100:	294304a6 	ldp	w6, w1, [x5, #24]
    7104:	92403c00 	and	x0, x0, #0xffff
    7108:	9b067c00 	mul	x0, x0, x6
    710c:	d360fc00 	lsr	x0, x0, #32
    7110:	eb01001f 	cmp	x0, x1
    7114:	54002702 	b.cs	75f4 <f12+0xdc4>  // b.hs, b.nlast
    7118:	8b000084 	add	x4, x4, x0
    711c:	39400097 	ldrb	w23, [x4]
    7120:	710006ff 	cmp	w23, #0x1
    7124:	54002681 	b.ne	75f4 <f12+0xdc4>  // b.any
    7128:	b9001bf7 	str	w23, [sp, #24]
    712c:	eb13005f 	cmp	x2, x19
    7130:	9a939053 	csel	x19, x2, x19, ls	// ls = plast
    7134:	9100233a 	add	x26, x25, #0x8
    7138:	b4003e13 	cbz	x19, 78f8 <f12+0x10c8>
    713c:	f9400be0 	ldr	x0, [sp, #16]
    7140:	d37df265 	lsl	x5, x19, #3
    7144:	aa1603e2 	mov	x2, x22
    7148:	d2800001 	mov	x1, #0x0                   	// #0
    714c:	91002000 	add	x0, x0, #0x8
    7150:	1400000a 	b	7178 <f12+0x948>
    7154:	fc616881 	ldr	d1, [x4, x1]
    7158:	fd400440 	ldr	d0, [x2, #8]
    715c:	1e613800 	fsub	d0, d0, d1
    7160:	fc216b40 	str	d0, [x26, x1]
    7164:	91002021 	add	x1, x1, #0x8
    7168:	f9400842 	ldr	x2, [x2, #16]
    716c:	eb05003f 	cmp	x1, x5
    7170:	540001c0 	b.eq	71a8 <f12+0x978>  // b.none
    7174:	f9400323 	ldr	x3, [x25]
    7178:	aa0003e4 	mov	x4, x0
    717c:	b6fffec3 	tbz	x3, #63, 7154 <f12+0x924>
    7180:	f9400be3 	ldr	x3, [sp, #16]
    7184:	fd400440 	ldr	d0, [x2, #8]
    7188:	f9400864 	ldr	x4, [x3, #16]
    718c:	fc616881 	ldr	d1, [x4, x1]
    7190:	1e613800 	fsub	d0, d0, d1
    7194:	fc216b40 	str	d0, [x26, x1]
    7198:	91002021 	add	x1, x1, #0x8
    719c:	f9400842 	ldr	x2, [x2, #16]
    71a0:	eb05003f 	cmp	x1, x5
    71a4:	54fffe81 	b.ne	7174 <f12+0x944>  // b.any
    71a8:	b4003a56 	cbz	x22, 78f0 <f12+0x10c0>
    71ac:	91150280 	add	x0, x20, #0x540
    71b0:	aa1603e2 	mov	x2, x22
    71b4:	d280001b 	mov	x27, #0x0                   	// #0
    71b8:	f949ec06 	ldr	x6, [x0, #5080]
    71bc:	f949d807 	ldr	x7, [x0, #5040]
    71c0:	f949fc05 	ldr	x5, [x0, #5112]
    71c4:	d370bcc6 	lsl	x6, x6, #16
    71c8:	14000006 	b	71e0 <f12+0x9b0>
    71cc:	f9400842 	ldr	x2, [x2, #16]
    71d0:	9100077b 	add	x27, x27, #0x1
    71d4:	f100005f 	cmp	x2, #0x0
    71d8:	fa531362 	ccmp	x27, x19, #0x2, ne	// ne = any
    71dc:	54000322 	b.cs	7240 <f12+0xa10>  // b.hs, b.nlast
    71e0:	cb070040 	sub	x0, x2, x7
    71e4:	eb06001f 	cmp	x0, x6
    71e8:	540002c2 	b.cs	7240 <f12+0xa10>  // b.hs, b.nlast
    71ec:	d350fc01 	lsr	x1, x0, #16
    71f0:	8b010821 	add	x1, x1, x1, lsl #2
    71f4:	d37df021 	lsl	x1, x1, #3
    71f8:	8b0100a4 	add	x4, x5, x1
    71fc:	f9401083 	ldr	x3, [x4, #32]
    7200:	b4000203 	cbz	x3, 7240 <f12+0xa10>
    7204:	386168a1 	ldrb	w1, [x5, x1]
    7208:	7100083f 	cmp	w1, #0x2
    720c:	54000e00 	b.eq	73cc <f12+0xb9c>  // b.none
    7210:	7100043f 	cmp	w1, #0x1
    7214:	54000161 	b.ne	7240 <f12+0xa10>  // b.any
    7218:	29430488 	ldp	w8, w1, [x4, #24]
    721c:	92403c00 	and	x0, x0, #0xffff
    7220:	9b087c00 	mul	x0, x0, x8
    7224:	d360fc00 	lsr	x0, x0, #32
    7228:	eb01001f 	cmp	x0, x1
    722c:	540000a2 	b.cs	7240 <f12+0xa10>  // b.hs, b.nlast
    7230:	8b000063 	add	x3, x3, x0
    7234:	39400060 	ldrb	w0, [x3]
    7238:	7100041f 	cmp	w0, #0x1
    723c:	54fffc80 	b.eq	71cc <f12+0x99c>  // b.none
    7240:	d2800019 	mov	x25, #0x0                   	// #0
    7244:	eb13037f 	cmp	x27, x19
    7248:	54000cc2 	b.cs	73e0 <f12+0xbb0>  // b.hs, b.nlast
    724c:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x800>
    7250:	d1002357 	sub	x23, x26, #0x8
    7254:	91150298 	add	x24, x20, #0x540
    7258:	d2800019 	mov	x25, #0x0                   	// #0
    725c:	fd425808 	ldr	d8, [x0, #1200]
    7260:	14000042 	b	7368 <f12+0xb38>
    7264:	f9400381 	ldr	x1, [x28]
    7268:	aa2103e1 	mvn	x1, x1
    726c:	f8207b01 	str	x1, [x24, x0, lsl #3]
    7270:	f100609f 	cmp	x4, #0x18
    7274:	54000169 	b.ls	72a0 <f12+0xa70>  // b.plast
    7278:	d1006482 	sub	x2, x4, #0x19
    727c:	91006380 	add	x0, x28, #0x18
    7280:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7284:	52800001 	mov	w1, #0x0                   	// #0
    7288:	91002042 	add	x2, x2, #0x8
    728c:	f90003e4 	str	x4, [sp]
    7290:	b9000be5 	str	w5, [sp, #8]
    7294:	97ffed4b 	bl	27c0 <memset@plt>
    7298:	f94003e4 	ldr	x4, [sp]
    729c:	b9400be5 	ldr	w5, [sp, #8]
    72a0:	91150282 	add	x2, x20, #0x540
    72a4:	f94a1041 	ldr	x1, [x2, #5152]
    72a8:	ab040021 	adds	x1, x1, x4
    72ac:	54003562 	b.cs	7958 <f12+0x1128>  // b.hs, b.nlast
    72b0:	f94a1440 	ldr	x0, [x2, #5160]
    72b4:	f90a1041 	str	x1, [x2, #5152]
    72b8:	eb00003f 	cmp	x1, x0
    72bc:	54000049 	b.ls	72c4 <f12+0xa94>  // b.plast
    72c0:	f90a1441 	str	x1, [x2, #5160]
    72c4:	91150280 	add	x0, x20, #0x540
    72c8:	1e6300a1 	ucvtf	d1, w5
    72cc:	fd4a1c00 	ldr	d0, [x0, #5176]
    72d0:	1e612800 	fadd	d0, d0, d1
    72d4:	fd0a1c00 	str	d0, [x0, #5176]
    72d8:	a900e795 	stp	x21, x25, [x28, #8]
    72dc:	aa1c03f9 	mov	x25, x28
    72e0:	fd000388 	str	d8, [x28]
    72e4:	f949db01 	ldr	x1, [x24, #5040]
    72e8:	f949ef00 	ldr	x0, [x24, #5080]
    72ec:	cb010381 	sub	x1, x28, x1
    72f0:	eb00403f 	cmp	x1, x0, lsl #16
    72f4:	54000322 	b.cs	7358 <f12+0xb28>  // b.hs, b.nlast
    72f8:	d350fc20 	lsr	x0, x1, #16
    72fc:	f949ff04 	ldr	x4, [x24, #5112]
    7300:	8b000800 	add	x0, x0, x0, lsl #2
    7304:	d37df002 	lsl	x2, x0, #3
    7308:	8b020080 	add	x0, x4, x2
    730c:	f940101c 	ldr	x28, [x0, #32]
    7310:	b400025c 	cbz	x28, 7358 <f12+0xb28>
    7314:	38626882 	ldrb	w2, [x4, x2]
    7318:	7100085f 	cmp	w2, #0x2
    731c:	54000b00 	b.eq	747c <f12+0xc4c>  // b.none
    7320:	7100045f 	cmp	w2, #0x1
    7324:	540001a1 	b.ne	7358 <f12+0xb28>  // b.any
    7328:	29430002 	ldp	w2, w0, [x0, #24]
    732c:	92403c21 	and	x1, x1, #0xffff
    7330:	9b027c21 	mul	x1, x1, x2
    7334:	d360fc21 	lsr	x1, x1, #32
    7338:	eb00003f 	cmp	x1, x0
    733c:	540000e2 	b.cs	7358 <f12+0xb28>  // b.hs, b.nlast
    7340:	8b01039c 	add	x28, x28, x1
    7344:	39400380 	ldrb	w0, [x28]
    7348:	7103fc1f 	cmp	w0, #0xff
    734c:	54002000 	b.eq	774c <f12+0xf1c>  // b.none
    7350:	52800020 	mov	w0, #0x1                   	// #1
    7354:	39000380 	strb	w0, [x28]
    7358:	d1000660 	sub	x0, x19, #0x1
    735c:	eb1b001f 	cmp	x0, x27
    7360:	54000989 	b.ls	7490 <f12+0xc60>  // b.plast
    7364:	aa0003f3 	mov	x19, x0
    7368:	b953a700 	ldr	w0, [x24, #5028]
    736c:	f8737af5 	ldr	x21, [x23, x19, lsl #3]
    7370:	34000240 	cbz	w0, 73b8 <f12+0xb88>
    7374:	397e8b00 	ldrb	w0, [x24, #4002]
    7378:	910f0001 	add	x1, x0, #0x3c0
    737c:	8b000400 	add	x0, x0, x0, lsl #1
    7380:	b8617b05 	ldr	w5, [x24, x1, lsl #2]
    7384:	8b000f01 	add	x1, x24, x0, lsl #3
    7388:	f8607b1c 	ldr	x28, [x24, x0, lsl #3]
    738c:	2a0503e4 	mov	w4, w5
    7390:	b5fff6bc 	cbnz	x28, 7264 <f12+0xa34>
    7394:	f940043c 	ldr	x28, [x1, #8]
    7398:	b400011c 	cbz	x28, 73b8 <f12+0xb88>
    739c:	f9400820 	ldr	x0, [x1, #16]
    73a0:	cb1c0000 	sub	x0, x0, x28
    73a4:	eb00009f 	cmp	x4, x0
    73a8:	54000088 	b.hi	73b8 <f12+0xb88>  // b.pmore
    73ac:	8b040380 	add	x0, x28, x4
    73b0:	f9000420 	str	x0, [x1, #8]
    73b4:	17ffffaf 	b	7270 <f12+0xa40>
    73b8:	52800001 	mov	w1, #0x0                   	// #0
    73bc:	d2800300 	mov	x0, #0x18                  	// #24
    73c0:	97fff60c 	bl	4bf0 <fwp_heap_alloc>
    73c4:	aa0003fc 	mov	x28, x0
    73c8:	17ffffc4 	b	72d8 <f12+0xaa8>
    73cc:	72003c1f 	tst	w0, #0xffff
    73d0:	54fff320 	b.eq	7234 <f12+0xa04>  // b.none
    73d4:	d2800019 	mov	x25, #0x0                   	// #0
    73d8:	eb13037f 	cmp	x27, x19
    73dc:	54fff383 	b.cc	724c <f12+0xa1c>  // b.lo, b.ul, b.last
    73e0:	8b1b0f5b 	add	x27, x26, x27, lsl #3
    73e4:	aa1a03e1 	mov	x1, x26
    73e8:	aa1603e0 	mov	x0, x22
    73ec:	d503201f 	nop
    73f0:	f8408422 	ldr	x2, [x1], #8
    73f4:	f9000402 	str	x2, [x0, #8]
    73f8:	aa0003e2 	mov	x2, x0
    73fc:	f9400800 	ldr	x0, [x0, #16]
    7400:	eb1b003f 	cmp	x1, x27
    7404:	54ffff61 	b.ne	73f0 <f12+0xbc0>  // b.any
    7408:	b9401be1 	ldr	w1, [sp, #24]
    740c:	f9000859 	str	x25, [x2, #16]
    7410:	aa1603f9 	mov	x25, x22
    7414:	aa0003f6 	mov	x22, x0
    7418:	34000041 	cbz	w1, 7420 <f12+0xbf0>
    741c:	d280001a 	mov	x26, #0x0                   	// #0
    7420:	aa1a03e0 	mov	x0, x26
    7424:	97fff4d3 	bl	4770 <fwp_mem_free>
    7428:	f9400be0 	ldr	x0, [sp, #16]
    742c:	97fffc61 	bl	65b0 <fwp_drop4>
    7430:	aa1603e0 	mov	x0, x22
    7434:	97fff890 	bl	5674 <fwp_drop0>
    7438:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    743c:	f947f400 	ldr	x0, [x0, #4072]
    7440:	f9404fe2 	ldr	x2, [sp, #152]
    7444:	f9400001 	ldr	x1, [x0]
    7448:	eb010042 	subs	x2, x2, x1
    744c:	d2800001 	mov	x1, #0x0                   	// #0
    7450:	54002921 	b.ne	7974 <f12+0x1144>  // b.any
    7454:	a94a7bfd 	ldp	x29, x30, [sp, #160]
    7458:	aa1903e0 	mov	x0, x25
    745c:	a94b53f3 	ldp	x19, x20, [sp, #176]
    7460:	a94c5bf5 	ldp	x21, x22, [sp, #192]
    7464:	a94d63f7 	ldp	x23, x24, [sp, #208]
    7468:	a94e6bf9 	ldp	x25, x26, [sp, #224]
    746c:	a94f73fb 	ldp	x27, x28, [sp, #240]
    7470:	fd4083e8 	ldr	d8, [sp, #256]
    7474:	910443ff 	add	sp, sp, #0x110
    7478:	d65f03c0 	ret
    747c:	72003c3f 	tst	w1, #0xffff
    7480:	54fff620 	b.eq	7344 <f12+0xb14>  // b.none
    7484:	d1000660 	sub	x0, x19, #0x1
    7488:	eb1b001f 	cmp	x0, x27
    748c:	54fff6c8 	b.hi	7364 <f12+0xb34>  // b.pmore
    7490:	b5fffa9b 	cbnz	x27, 73e0 <f12+0xbb0>
    7494:	b9401be1 	ldr	w1, [sp, #24]
    7498:	7100003f 	cmp	w1, #0x0
    749c:	9a9f035a 	csel	x26, x26, xzr, eq	// eq = none
    74a0:	b4fffc00 	cbz	x0, 7420 <f12+0xbf0>
    74a4:	91150294 	add	x20, x20, #0x540
    74a8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x800>
    74ac:	d1000a73 	sub	x19, x19, #0x2
    74b0:	52800035 	mov	w21, #0x1                   	// #1
    74b4:	fd425808 	ldr	d8, [x0, #1200]
    74b8:	b953a680 	ldr	w0, [x20, #5028]
    74bc:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    74c0:	340008c0 	cbz	w0, 75d8 <f12+0xda8>
    74c4:	d503201f 	nop
    74c8:	397e8a80 	ldrb	w0, [x20, #4002]
    74cc:	910f0001 	add	x1, x0, #0x3c0
    74d0:	8b000400 	add	x0, x0, x0, lsl #1
    74d4:	b8617a9c 	ldr	w28, [x20, x1, lsl #2]
    74d8:	8b000e81 	add	x1, x20, x0, lsl #3
    74dc:	f8607a97 	ldr	x23, [x20, x0, lsl #3]
    74e0:	2a1c03fb 	mov	w27, w28
    74e4:	b4002177 	cbz	x23, 7910 <f12+0x10e0>
    74e8:	f94002e1 	ldr	x1, [x23]
    74ec:	aa2103e1 	mvn	x1, x1
    74f0:	f8207a81 	str	x1, [x20, x0, lsl #3]
    74f4:	f100637f 	cmp	x27, #0x18
    74f8:	540000e9 	b.ls	7514 <f12+0xce4>  // b.plast
    74fc:	d1006762 	sub	x2, x27, #0x19
    7500:	910062e0 	add	x0, x23, #0x18
    7504:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7508:	52800001 	mov	w1, #0x0                   	// #0
    750c:	91002042 	add	x2, x2, #0x8
    7510:	97ffecac 	bl	27c0 <memset@plt>
    7514:	f94a1280 	ldr	x0, [x20, #5152]
    7518:	ab1b0000 	adds	x0, x0, x27
    751c:	540021e2 	b.cs	7958 <f12+0x1128>  // b.hs, b.nlast
    7520:	f94a1681 	ldr	x1, [x20, #5160]
    7524:	f90a1280 	str	x0, [x20, #5152]
    7528:	eb01001f 	cmp	x0, x1
    752c:	54000049 	b.ls	7534 <f12+0xd04>  // b.plast
    7530:	f90a1680 	str	x0, [x20, #5160]
    7534:	1e630381 	ucvtf	d1, w28
    7538:	fd4a1e80 	ldr	d0, [x20, #5176]
    753c:	1e612800 	fadd	d0, d0, d1
    7540:	fd0a1e80 	str	d0, [x20, #5176]
    7544:	a900e6f8 	stp	x24, x25, [x23, #8]
    7548:	aa1703f9 	mov	x25, x23
    754c:	fd0002e8 	str	d8, [x23]
    7550:	f949da81 	ldr	x1, [x20, #5040]
    7554:	f949ee80 	ldr	x0, [x20, #5080]
    7558:	cb0102e1 	sub	x1, x23, x1
    755c:	eb00403f 	cmp	x1, x0, lsl #16
    7560:	54000302 	b.cs	75c0 <f12+0xd90>  // b.hs, b.nlast
    7564:	d350fc22 	lsr	x2, x1, #16
    7568:	f949fe83 	ldr	x3, [x20, #5112]
    756c:	8b020842 	add	x2, x2, x2, lsl #2
    7570:	d37df042 	lsl	x2, x2, #3
    7574:	8b020060 	add	x0, x3, x2
    7578:	f9401017 	ldr	x23, [x0, #32]
    757c:	b4000237 	cbz	x23, 75c0 <f12+0xd90>
    7580:	38626862 	ldrb	w2, [x3, x2]
    7584:	7100085f 	cmp	w2, #0x2
    7588:	54001d60 	b.eq	7934 <f12+0x1104>  // b.none
    758c:	7100045f 	cmp	w2, #0x1
    7590:	54000181 	b.ne	75c0 <f12+0xd90>  // b.any
    7594:	29430002 	ldp	w2, w0, [x0, #24]
    7598:	92403c21 	and	x1, x1, #0xffff
    759c:	9b027c21 	mul	x1, x1, x2
    75a0:	d360fc21 	lsr	x1, x1, #32
    75a4:	eb00003f 	cmp	x1, x0
    75a8:	540000c2 	b.cs	75c0 <f12+0xd90>  // b.hs, b.nlast
    75ac:	8b0102f7 	add	x23, x23, x1
    75b0:	394002e0 	ldrb	w0, [x23]
    75b4:	7103fc1f 	cmp	w0, #0xff
    75b8:	54001a60 	b.eq	7904 <f12+0x10d4>  // b.none
    75bc:	390002f5 	strb	w21, [x23]
    75c0:	d1000673 	sub	x19, x19, #0x1
    75c4:	b100067f 	cmn	x19, #0x1
    75c8:	54fff2c0 	b.eq	7420 <f12+0xbf0>  // b.none
    75cc:	b953a680 	ldr	w0, [x20, #5028]
    75d0:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    75d4:	35fff7a0 	cbnz	w0, 74c8 <f12+0xc98>
    75d8:	52800001 	mov	w1, #0x0                   	// #0
    75dc:	d2800300 	mov	x0, #0x18                  	// #24
    75e0:	97fff584 	bl	4bf0 <fwp_heap_alloc>
    75e4:	aa0003f7 	mov	x23, x0
    75e8:	17ffffd7 	b	7544 <f12+0xd14>
    75ec:	72003c1f 	tst	w0, #0xffff
    75f0:	54ffd960 	b.eq	711c <f12+0x8ec>  // b.none
    75f4:	b40012b6 	cbz	x22, 7848 <f12+0x1018>
    75f8:	aa1603f7 	mov	x23, x22
    75fc:	d2800018 	mov	x24, #0x0                   	// #0
    7600:	f9400af7 	ldr	x23, [x23, #16]
    7604:	aa1803e0 	mov	x0, x24
    7608:	91000718 	add	x24, x24, #0x1
    760c:	b5ffffb7 	cbnz	x23, 7600 <f12+0xdd0>
    7610:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7614:	eb01031f 	cmp	x24, x1
    7618:	54001c88 	b.hi	79a8 <f12+0x1178>  // b.pmore
    761c:	91000800 	add	x0, x0, #0x2
    7620:	52800041 	mov	w1, #0x2                   	// #2
    7624:	d37df000 	lsl	x0, x0, #3
    7628:	97fff572 	bl	4bf0 <fwp_heap_alloc>
    762c:	eb13031f 	cmp	x24, x19
    7630:	aa0003fa 	mov	x26, x0
    7634:	9a939313 	csel	x19, x24, x19, ls	// ls = plast
    7638:	aa1603e1 	mov	x1, x22
    763c:	d503201f 	nop
    7640:	f9400420 	ldr	x0, [x1, #8]
    7644:	f8377b40 	str	x0, [x26, x23, lsl #3]
    7648:	910006f7 	add	x23, x23, #0x1
    764c:	f9400821 	ldr	x1, [x1, #16]
    7650:	b5ffff81 	cbnz	x1, 7640 <f12+0xe10>
    7654:	b4001033 	cbz	x19, 7858 <f12+0x1028>
    7658:	f9400323 	ldr	x3, [x25]
    765c:	b9001bff 	str	wzr, [sp, #24]
    7660:	17fffeb7 	b	713c <f12+0x90c>
    7664:	72003c1f 	tst	w0, #0xffff
    7668:	54ffca20 	b.eq	6fac <f12+0x77c>  // b.none
    766c:	d503201f 	nop
    7670:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7674:	eb0002ff 	cmp	x23, x0
    7678:	54001788 	b.hi	7968 <f12+0x1138>  // b.pmore
    767c:	910006e0 	add	x0, x23, #0x1
    7680:	52800021 	mov	w1, #0x1                   	// #1
    7684:	d37df000 	lsl	x0, x0, #3
    7688:	97fff55a 	bl	4bf0 <fwp_heap_alloc>
    768c:	91150282 	add	x2, x20, #0x540
    7690:	f9000017 	str	x23, [x0]
    7694:	aa0003f9 	mov	x25, x0
    7698:	f9000bf9 	str	x25, [sp, #16]
    769c:	f949d841 	ldr	x1, [x2, #5040]
    76a0:	f949ec40 	ldr	x0, [x2, #5080]
    76a4:	cb010321 	sub	x1, x25, x1
    76a8:	eb00403f 	cmp	x1, x0, lsl #16
    76ac:	54000322 	b.cs	7710 <f12+0xee0>  // b.hs, b.nlast
    76b0:	d350fc20 	lsr	x0, x1, #16
    76b4:	f949fc43 	ldr	x3, [x2, #5112]
    76b8:	8b000800 	add	x0, x0, x0, lsl #2
    76bc:	d37df002 	lsl	x2, x0, #3
    76c0:	8b020060 	add	x0, x3, x2
    76c4:	f9401018 	ldr	x24, [x0, #32]
    76c8:	b4000258 	cbz	x24, 7710 <f12+0xee0>
    76cc:	38626862 	ldrb	w2, [x3, x2]
    76d0:	7100085f 	cmp	w2, #0x2
    76d4:	54000c60 	b.eq	7860 <f12+0x1030>  // b.none
    76d8:	7100045f 	cmp	w2, #0x1
    76dc:	540001a1 	b.ne	7710 <f12+0xee0>  // b.any
    76e0:	29430002 	ldp	w2, w0, [x0, #24]
    76e4:	92403c21 	and	x1, x1, #0xffff
    76e8:	9b027c21 	mul	x1, x1, x2
    76ec:	d360fc21 	lsr	x1, x1, #32
    76f0:	eb00003f 	cmp	x1, x0
    76f4:	540000e2 	b.cs	7710 <f12+0xee0>  // b.hs, b.nlast
    76f8:	8b010318 	add	x24, x24, x1
    76fc:	39400300 	ldrb	w0, [x24]
    7700:	7103fc1f 	cmp	w0, #0xff
    7704:	54000ec0 	b.eq	78dc <f12+0x10ac>  // b.none
    7708:	52800020 	mov	w0, #0x1                   	// #1
    770c:	39000300 	strb	w0, [x24]
    7710:	aa1303e0 	mov	x0, x19
    7714:	17fffe2c 	b	6fc4 <f12+0x794>
    7718:	52800041 	mov	w1, #0x2                   	// #2
    771c:	d2800100 	mov	x0, #0x8                   	// #8
    7720:	97fff534 	bl	4bf0 <fwp_heap_alloc>
    7724:	aa0003fb 	mov	x27, x0
    7728:	91150280 	add	x0, x20, #0x540
    772c:	f900037f 	str	xzr, [x27]
    7730:	f949d801 	ldr	x1, [x0, #5040]
    7734:	f949ec00 	ldr	x0, [x0, #5080]
    7738:	cb010361 	sub	x1, x27, x1
    773c:	eb00403f 	cmp	x1, x0, lsl #16
    7740:	54000362 	b.cs	77ac <f12+0xf7c>  // b.hs, b.nlast
    7744:	d2800013 	mov	x19, #0x0                   	// #0
    7748:	17fffd0b 	b	6b74 <f12+0x344>
    774c:	aa1c03e0 	mov	x0, x28
    7750:	97fff368 	bl	44f0 <fwp_rc_forget_slot>
    7754:	17fffeff 	b	7350 <f12+0xb20>
    7758:	f100027f 	cmp	x19, #0x0
    775c:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    7760:	54ffb261 	b.ne	6dac <f12+0x57c>  // b.any
    7764:	f94027e1 	ldr	x1, [sp, #72]
    7768:	9100c2f7 	add	x23, x23, #0x30
    776c:	aa1a03e0 	mov	x0, x26
    7770:	f90162e1 	str	x1, [x23, #704]
    7774:	97fff243 	bl	4080 <fwp_tape_buffers_release>
    7778:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    777c:	f947e863 	ldr	x3, [x3, #4048]
    7780:	d2800262 	mov	x2, #0x13                  	// #19
    7784:	d2800021 	mov	x1, #0x1                   	// #1
    7788:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    778c:	91202000 	add	x0, x0, #0x808
    7790:	f9400063 	ldr	x3, [x3]
    7794:	97ffec57 	bl	28f0 <fwrite@plt>
    7798:	d2800000 	mov	x0, #0x0                   	// #0
    779c:	97ffec61 	bl	2920 <fflush@plt>
    77a0:	52800cc0 	mov	w0, #0x66                  	// #102
    77a4:	97ffec6f 	bl	2960 <_Exit@plt>
    77a8:	b5ffa1b3 	cbnz	x19, 6bdc <f12+0x3ac>
    77ac:	d280001c 	mov	x28, #0x0                   	// #0
    77b0:	17fffd31 	b	6c74 <f12+0x444>
    77b4:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0xdc>
    77b8:	912ec000 	add	x0, x0, #0xbb0
    77bc:	94000c05 	bl	a7d0 <atexit>
    77c0:	35fffdc0 	cbnz	w0, 7778 <f12+0xf48>
    77c4:	52800020 	mov	w0, #0x1                   	// #1
    77c8:	b902f6a0 	str	w0, [x21, #756]
    77cc:	17fffc65 	b	6960 <f12+0x130>
    77d0:	72003c3f 	tst	w1, #0xffff
    77d4:	54ffa021 	b.ne	6bd8 <f12+0x3a8>  // b.any
    77d8:	17fffcfb 	b	6bc4 <f12+0x394>
    77dc:	72003c3f 	tst	w1, #0xffff
    77e0:	54ff8960 	b.eq	690c <f12+0xdc>  // b.none
    77e4:	aa1503e0 	mov	x0, x21
    77e8:	97fff852 	bl	5930 <fwp_closure_drop>
    77ec:	b5ff8a36 	cbnz	x22, 6930 <f12+0x100>
    77f0:	d280001a 	mov	x26, #0x0                   	// #0
    77f4:	17fffc58 	b	6954 <f12+0x124>
    77f8:	72003c3f 	tst	w1, #0xffff
    77fc:	54ffb921 	b.ne	6f20 <f12+0x6f0>  // b.any
    7800:	17fffdc3 	b	6f0c <f12+0x6dc>
    7804:	aa1c03f3 	mov	x19, x28
    7808:	17fffd52 	b	6d50 <f12+0x520>
    780c:	3cc48002 	ldur	q2, [x0, #72]
    7810:	91012001 	add	x1, x0, #0x48
    7814:	3cc58001 	ldur	q1, [x0, #88]
    7818:	f900401f 	str	xzr, [x0, #128]
    781c:	4f000400 	movi	v0.4s, #0x0
    7820:	ad010762 	stp	q2, q1, [x27, #32]
    7824:	a9468002 	ldp	x2, x0, [x0, #104]
    7828:	f9000f60 	str	x0, [x27, #24]
    782c:	f9401820 	ldr	x0, [x1, #48]
    7830:	f9002362 	str	x2, [x27, #64]
    7834:	f9002760 	str	x0, [x27, #72]
    7838:	ad000020 	stp	q0, q0, [x1]
    783c:	3d800820 	str	q0, [x1, #32]
    7840:	f900183f 	str	xzr, [x1, #48]
    7844:	17fffc8a 	b	6a6c <f12+0x23c>
    7848:	52800041 	mov	w1, #0x2                   	// #2
    784c:	d2800100 	mov	x0, #0x8                   	// #8
    7850:	97fff4e8 	bl	4bf0 <fwp_heap_alloc>
    7854:	aa0003fa 	mov	x26, x0
    7858:	d2800019 	mov	x25, #0x0                   	// #0
    785c:	17fffef1 	b	7420 <f12+0xbf0>
    7860:	72003c3f 	tst	w1, #0xffff
    7864:	54fff4c0 	b.eq	76fc <f12+0xecc>  // b.none
    7868:	aa1303e0 	mov	x0, x19
    786c:	17fffdd6 	b	6fc4 <f12+0x794>
    7870:	aa1b03e0 	mov	x0, x27
    7874:	d2800101 	mov	x1, #0x8                   	// #8
    7878:	97ffebd6 	bl	27d0 <calloc@plt>
    787c:	aa0003e3 	mov	x3, x0
    7880:	a94017e4 	ldp	x4, x5, [sp]
    7884:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7888:	17fffd46 	b	6da0 <f12+0x570>
    788c:	f9400323 	ldr	x3, [x25]
    7890:	b7fffdc3 	tbnz	x3, #63, 7848 <f12+0x1018>
    7894:	91150281 	add	x1, x20, #0x540
    7898:	f9400be4 	ldr	x4, [sp, #16]
    789c:	f949d820 	ldr	x0, [x1, #5040]
    78a0:	f949ec21 	ldr	x1, [x1, #5080]
    78a4:	cb000080 	sub	x0, x4, x0
    78a8:	eb01401f 	cmp	x0, x1, lsl #16
    78ac:	54fffce2 	b.cs	7848 <f12+0x1018>  // b.hs, b.nlast
    78b0:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    78b4:	17fffe06 	b	70cc <f12+0x89c>
    78b8:	d2800d01 	mov	x1, #0x68                  	// #104
    78bc:	d2800022 	mov	x2, #0x1                   	// #1
    78c0:	17fffc4b 	b	69ec <f12+0x1bc>
    78c4:	aa1503e0 	mov	x0, x21
    78c8:	97fff30a 	bl	44f0 <fwp_rc_forget_slot>
    78cc:	17fffcc1 	b	6bd0 <f12+0x3a0>
    78d0:	aa1503e0 	mov	x0, x21
    78d4:	97fff307 	bl	44f0 <fwp_rc_forget_slot>
    78d8:	17fffd90 	b	6f18 <f12+0x6e8>
    78dc:	aa1803e0 	mov	x0, x24
    78e0:	97fff304 	bl	44f0 <fwp_rc_forget_slot>
    78e4:	17ffff89 	b	7708 <f12+0xed8>
    78e8:	97fff2bb 	bl	43d4 <fwp_rc_wide_dup>
    78ec:	17fffc0e 	b	6924 <f12+0xf4>
    78f0:	d280001b 	mov	x27, #0x0                   	// #0
    78f4:	17fffe56 	b	724c <f12+0xa1c>
    78f8:	d280001a 	mov	x26, #0x0                   	// #0
    78fc:	d2800019 	mov	x25, #0x0                   	// #0
    7900:	17fffec8 	b	7420 <f12+0xbf0>
    7904:	aa1703e0 	mov	x0, x23
    7908:	97fff2fa 	bl	44f0 <fwp_rc_forget_slot>
    790c:	17ffff2c 	b	75bc <f12+0xd8c>
    7910:	f9400437 	ldr	x23, [x1, #8]
    7914:	b4ffe637 	cbz	x23, 75d8 <f12+0xda8>
    7918:	f9400820 	ldr	x0, [x1, #16]
    791c:	cb170000 	sub	x0, x0, x23
    7920:	eb00037f 	cmp	x27, x0
    7924:	54ffe5a8 	b.hi	75d8 <f12+0xda8>  // b.pmore
    7928:	8b1b02e0 	add	x0, x23, x27
    792c:	f9000420 	str	x0, [x1, #8]
    7930:	17fffef1 	b	74f4 <f12+0xcc4>
    7934:	72003c3f 	tst	w1, #0xffff
    7938:	54ffe441 	b.ne	75c0 <f12+0xd90>  // b.any
    793c:	17ffff1d 	b	75b0 <f12+0xd80>
    7940:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    7944:	912e2000 	add	x0, x0, #0xb88
    7948:	97ffeeee 	bl	3500 <fwp_trap>
    794c:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    7950:	912bc000 	add	x0, x0, #0xaf0
    7954:	97ffeeeb 	bl	3500 <fwp_trap>
    7958:	97ffed96 	bl	2fb0 <fwp_heap_oom>
    795c:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    7960:	91322000 	add	x0, x0, #0xc88
    7964:	97ffeee7 	bl	3500 <fwp_trap>
    7968:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    796c:	9131e000 	add	x0, x0, #0xc78
    7970:	97ffeee4 	bl	3500 <fwp_trap>
    7974:	97ffeb9f 	bl	27f0 <__stack_chk_fail@plt>
    7978:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    797c:	9130e000 	add	x0, x0, #0xc38
    7980:	97ffeee0 	bl	3500 <fwp_trap>
    7984:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    7988:	912fa000 	add	x0, x0, #0xbe8
    798c:	97ffeedd 	bl	3500 <fwp_trap>
    7990:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    7994:	91302000 	add	x0, x0, #0xc08
    7998:	97ffeeda 	bl	3500 <fwp_trap>
    799c:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    79a0:	912ce000 	add	x0, x0, #0xb38
    79a4:	97ffeed7 	bl	3500 <fwp_trap>
    79a8:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    79ac:	9131a000 	add	x0, x0, #0xc68
    79b0:	97ffeed4 	bl	3500 <fwp_trap>
    79b4:	97ffeba3 	bl	2840 <abort@plt>
    79b8:	97ffec12 	bl	2a00 <fwp_trap_overflow.constprop.0>
    79bc:	d503201f 	nop

00000000000079c0 <fwp_owned_entry12>:
    79c0:	f9400000 	ldr	x0, [x0]
    79c4:	17fffb9b 	b	6830 <f12>
    79c8:	d503201f 	nop
    79cc:	d503201f 	nop

00000000000079d0 <e12>:
    79d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    79d4:	910003fd 	mov	x29, sp
    79d8:	f9000bf3 	str	x19, [sp, #16]
    79dc:	f9400013 	ldr	x19, [x0]
    79e0:	aa1303e0 	mov	x0, x19
    79e4:	97fff6b7 	bl	54c0 <fwp_rc_share>
    79e8:	aa1303e0 	mov	x0, x19
    79ec:	97fffb91 	bl	6830 <f12>
    79f0:	aa0003f3 	mov	x19, x0
    79f4:	97fff6b3 	bl	54c0 <fwp_rc_share>
    79f8:	aa1303e0 	mov	x0, x19
    79fc:	f9400bf3 	ldr	x19, [sp, #16]
    7a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7a04:	d65f03c0 	ret
    7a08:	d503201f 	nop
    7a0c:	d503201f 	nop

0000000000007a10 <fwp_args23>:
    7a10:	7100003f 	cmp	w1, #0x0
    7a14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7a18:	54000041 	b.ne	7a20 <fwp_args23+0x10>  // b.any
    7a1c:	d65f03c0 	ret
    7a20:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7a24:	91150042 	add	x2, x2, #0x540
    7a28:	f9400001 	ldr	x1, [x0]
    7a2c:	f949d843 	ldr	x3, [x2, #5040]
    7a30:	f949ec40 	ldr	x0, [x2, #5080]
    7a34:	cb030021 	sub	x1, x1, x3
    7a38:	eb00403f 	cmp	x1, x0, lsl #16
    7a3c:	54ffff02 	b.cs	7a1c <fwp_args23+0xc>  // b.hs, b.nlast
    7a40:	d350fc20 	lsr	x0, x1, #16
    7a44:	f949fc44 	ldr	x4, [x2, #5112]
    7a48:	8b000800 	add	x0, x0, x0, lsl #2
    7a4c:	d37df002 	lsl	x2, x0, #3
    7a50:	8b020083 	add	x3, x4, x2
    7a54:	f9401060 	ldr	x0, [x3, #32]
    7a58:	b4fffe20 	cbz	x0, 7a1c <fwp_args23+0xc>
    7a5c:	38626882 	ldrb	w2, [x4, x2]
    7a60:	7100085f 	cmp	w2, #0x2
    7a64:	54000220 	b.eq	7aa8 <fwp_args23+0x98>  // b.none
    7a68:	7100045f 	cmp	w2, #0x1
    7a6c:	54fffd81 	b.ne	7a1c <fwp_args23+0xc>  // b.any
    7a70:	29430864 	ldp	w4, w2, [x3, #24]
    7a74:	92403c21 	and	x1, x1, #0xffff
    7a78:	9b047c21 	mul	x1, x1, x4
    7a7c:	d360fc21 	lsr	x1, x1, #32
    7a80:	eb02003f 	cmp	x1, x2
    7a84:	54fffcc2 	b.cs	7a1c <fwp_args23+0xc>  // b.hs, b.nlast
    7a88:	8b010000 	add	x0, x0, x1
    7a8c:	39400001 	ldrb	w1, [x0]
    7a90:	34fffc61 	cbz	w1, 7a1c <fwp_args23+0xc>
    7a94:	7103f43f 	cmp	w1, #0xfd
    7a98:	540000e8 	b.hi	7ab4 <fwp_args23+0xa4>  // b.pmore
    7a9c:	11000421 	add	w1, w1, #0x1
    7aa0:	39000001 	strb	w1, [x0]
    7aa4:	d65f03c0 	ret
    7aa8:	72003c3f 	tst	w1, #0xffff
    7aac:	54ffff00 	b.eq	7a8c <fwp_args23+0x7c>  // b.none
    7ab0:	d65f03c0 	ret
    7ab4:	17fff248 	b	43d4 <fwp_rc_wide_dup>
    7ab8:	d503201f 	nop
    7abc:	d503201f 	nop

0000000000007ac0 <fwp_args12>:
    7ac0:	7100003f 	cmp	w1, #0x0
    7ac4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7ac8:	54000041 	b.ne	7ad0 <fwp_args12+0x10>  // b.any
    7acc:	d65f03c0 	ret
    7ad0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7ad4:	91150042 	add	x2, x2, #0x540
    7ad8:	f9400001 	ldr	x1, [x0]
    7adc:	f949d843 	ldr	x3, [x2, #5040]
    7ae0:	f949ec40 	ldr	x0, [x2, #5080]
    7ae4:	cb030021 	sub	x1, x1, x3
    7ae8:	eb00403f 	cmp	x1, x0, lsl #16
    7aec:	54ffff02 	b.cs	7acc <fwp_args12+0xc>  // b.hs, b.nlast
    7af0:	d350fc20 	lsr	x0, x1, #16
    7af4:	f949fc44 	ldr	x4, [x2, #5112]
    7af8:	8b000800 	add	x0, x0, x0, lsl #2
    7afc:	d37df002 	lsl	x2, x0, #3
    7b00:	8b020083 	add	x3, x4, x2
    7b04:	f9401060 	ldr	x0, [x3, #32]
    7b08:	b4fffe20 	cbz	x0, 7acc <fwp_args12+0xc>
    7b0c:	38626882 	ldrb	w2, [x4, x2]
    7b10:	7100085f 	cmp	w2, #0x2
    7b14:	54000220 	b.eq	7b58 <fwp_args12+0x98>  // b.none
    7b18:	7100045f 	cmp	w2, #0x1
    7b1c:	54fffd81 	b.ne	7acc <fwp_args12+0xc>  // b.any
    7b20:	29430864 	ldp	w4, w2, [x3, #24]
    7b24:	92403c21 	and	x1, x1, #0xffff
    7b28:	9b047c21 	mul	x1, x1, x4
    7b2c:	d360fc21 	lsr	x1, x1, #32
    7b30:	eb02003f 	cmp	x1, x2
    7b34:	54fffcc2 	b.cs	7acc <fwp_args12+0xc>  // b.hs, b.nlast
    7b38:	8b010000 	add	x0, x0, x1
    7b3c:	39400001 	ldrb	w1, [x0]
    7b40:	34fffc61 	cbz	w1, 7acc <fwp_args12+0xc>
    7b44:	7103f43f 	cmp	w1, #0xfd
    7b48:	540000e8 	b.hi	7b64 <fwp_args12+0xa4>  // b.pmore
    7b4c:	11000421 	add	w1, w1, #0x1
    7b50:	39000001 	strb	w1, [x0]
    7b54:	d65f03c0 	ret
    7b58:	72003c3f 	tst	w1, #0xffff
    7b5c:	54ffff00 	b.eq	7b3c <fwp_args12+0x7c>  // b.none
    7b60:	d65f03c0 	ret
    7b64:	17fff21c 	b	43d4 <fwp_rc_wide_dup>
    7b68:	d503201f 	nop
    7b6c:	d503201f 	nop

0000000000007b70 <fwp_caps12>:
    7b70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7b74:	910003fd 	mov	x29, sp
    7b78:	f9000bf3 	str	x19, [sp, #16]
    7b7c:	aa0003f3 	mov	x19, x0
    7b80:	b9400400 	ldr	w0, [x0, #4]
    7b84:	340004a0 	cbz	w0, 7c18 <fwp_caps12+0xa8>
    7b88:	f9400660 	ldr	x0, [x19, #8]
    7b8c:	350004e1 	cbnz	w1, 7c28 <fwp_caps12+0xb8>
    7b90:	97fff6b9 	bl	5674 <fwp_drop0>
    7b94:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7b98:	91150042 	add	x2, x2, #0x540
    7b9c:	f949d840 	ldr	x0, [x2, #5040]
    7ba0:	f949ec41 	ldr	x1, [x2, #5080]
    7ba4:	cb000260 	sub	x0, x19, x0
    7ba8:	eb01401f 	cmp	x0, x1, lsl #16
    7bac:	54000382 	b.cs	7c1c <fwp_caps12+0xac>  // b.hs, b.nlast
    7bb0:	d350fc01 	lsr	x1, x0, #16
    7bb4:	f949fc44 	ldr	x4, [x2, #5112]
    7bb8:	8b010821 	add	x1, x1, x1, lsl #2
    7bbc:	d37df021 	lsl	x1, x1, #3
    7bc0:	8b010083 	add	x3, x4, x1
    7bc4:	f9401062 	ldr	x2, [x3, #32]
    7bc8:	b40002a2 	cbz	x2, 7c1c <fwp_caps12+0xac>
    7bcc:	38616881 	ldrb	w1, [x4, x1]
    7bd0:	7100083f 	cmp	w1, #0x2
    7bd4:	540006c0 	b.eq	7cac <fwp_caps12+0x13c>  // b.none
    7bd8:	7100043f 	cmp	w1, #0x1
    7bdc:	54000201 	b.ne	7c1c <fwp_caps12+0xac>  // b.any
    7be0:	29430464 	ldp	w4, w1, [x3, #24]
    7be4:	92403c00 	and	x0, x0, #0xffff
    7be8:	9b047c00 	mul	x0, x0, x4
    7bec:	d360fc00 	lsr	x0, x0, #32
    7bf0:	eb01001f 	cmp	x0, x1
    7bf4:	54000142 	b.cs	7c1c <fwp_caps12+0xac>  // b.hs, b.nlast
    7bf8:	8b000042 	add	x2, x2, x0
    7bfc:	39400040 	ldrb	w0, [x2]
    7c00:	7100041f 	cmp	w0, #0x1
    7c04:	540000c1 	b.ne	7c1c <fwp_caps12+0xac>  // b.any
    7c08:	aa1303e0 	mov	x0, x19
    7c0c:	f9400bf3 	ldr	x19, [sp, #16]
    7c10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7c14:	17fff2d7 	b	4770 <fwp_mem_free>
    7c18:	34fffbe1 	cbz	w1, 7b94 <fwp_caps12+0x24>
    7c1c:	f9400bf3 	ldr	x19, [sp, #16]
    7c20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7c24:	d65f03c0 	ret
    7c28:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7c2c:	91150042 	add	x2, x2, #0x540
    7c30:	f949d843 	ldr	x3, [x2, #5040]
    7c34:	f949ec41 	ldr	x1, [x2, #5080]
    7c38:	cb030000 	sub	x0, x0, x3
    7c3c:	eb01401f 	cmp	x0, x1, lsl #16
    7c40:	54fffee2 	b.cs	7c1c <fwp_caps12+0xac>  // b.hs, b.nlast
    7c44:	d350fc01 	lsr	x1, x0, #16
    7c48:	f949fc44 	ldr	x4, [x2, #5112]
    7c4c:	8b010821 	add	x1, x1, x1, lsl #2
    7c50:	d37df021 	lsl	x1, x1, #3
    7c54:	8b010083 	add	x3, x4, x1
    7c58:	f9401062 	ldr	x2, [x3, #32]
    7c5c:	b4fffe02 	cbz	x2, 7c1c <fwp_caps12+0xac>
    7c60:	38616881 	ldrb	w1, [x4, x1]
    7c64:	7100083f 	cmp	w1, #0x2
    7c68:	54000280 	b.eq	7cb8 <fwp_caps12+0x148>  // b.none
    7c6c:	7100043f 	cmp	w1, #0x1
    7c70:	54fffd61 	b.ne	7c1c <fwp_caps12+0xac>  // b.any
    7c74:	92403c01 	and	x1, x0, #0xffff
    7c78:	29430064 	ldp	w4, w0, [x3, #24]
    7c7c:	9b047c21 	mul	x1, x1, x4
    7c80:	d360fc21 	lsr	x1, x1, #32
    7c84:	eb00003f 	cmp	x1, x0
    7c88:	54fffca2 	b.cs	7c1c <fwp_caps12+0xac>  // b.hs, b.nlast
    7c8c:	8b010042 	add	x2, x2, x1
    7c90:	39400040 	ldrb	w0, [x2]
    7c94:	34fffc40 	cbz	w0, 7c1c <fwp_caps12+0xac>
    7c98:	7103f41f 	cmp	w0, #0xfd
    7c9c:	54000148 	b.hi	7cc4 <fwp_caps12+0x154>  // b.pmore
    7ca0:	11000400 	add	w0, w0, #0x1
    7ca4:	39000040 	strb	w0, [x2]
    7ca8:	17ffffdd 	b	7c1c <fwp_caps12+0xac>
    7cac:	72003c1f 	tst	w0, #0xffff
    7cb0:	54fffb61 	b.ne	7c1c <fwp_caps12+0xac>  // b.any
    7cb4:	17ffffd2 	b	7bfc <fwp_caps12+0x8c>
    7cb8:	72003c1f 	tst	w0, #0xffff
    7cbc:	54fffb01 	b.ne	7c1c <fwp_caps12+0xac>  // b.any
    7cc0:	17fffff4 	b	7c90 <fwp_caps12+0x120>
    7cc4:	f9400bf3 	ldr	x19, [sp, #16]
    7cc8:	aa0203e0 	mov	x0, x2
    7ccc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7cd0:	17fff1c1 	b	43d4 <fwp_rc_wide_dup>

0000000000007cd4 <fwp_drop2>:
    7cd4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7cd8:	910003fd 	mov	x29, sp
    7cdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    7ce0:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    7ce4:	911502d5 	add	x21, x22, #0x540
    7ce8:	a90153f3 	stp	x19, x20, [sp, #16]
    7cec:	aa0003f3 	mov	x19, x0
    7cf0:	f949daa1 	ldr	x1, [x21, #5040]
    7cf4:	f949eea0 	ldr	x0, [x21, #5080]
    7cf8:	cb010261 	sub	x1, x19, x1
    7cfc:	eb00403f 	cmp	x1, x0, lsl #16
    7d00:	54000382 	b.cs	7d70 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7d04:	d350fc22 	lsr	x2, x1, #16
    7d08:	f949fea3 	ldr	x3, [x21, #5112]
    7d0c:	8b020842 	add	x2, x2, x2, lsl #2
    7d10:	d37df042 	lsl	x2, x2, #3
    7d14:	8b020060 	add	x0, x3, x2
    7d18:	f9401014 	ldr	x20, [x0, #32]
    7d1c:	b40002b4 	cbz	x20, 7d70 <fwp_drop2+0x9c>
    7d20:	38626862 	ldrb	w2, [x3, x2]
    7d24:	7100085f 	cmp	w2, #0x2
    7d28:	540002c0 	b.eq	7d80 <fwp_drop2+0xac>  // b.none
    7d2c:	7100045f 	cmp	w2, #0x1
    7d30:	54000201 	b.ne	7d70 <fwp_drop2+0x9c>  // b.any
    7d34:	29430002 	ldp	w2, w0, [x0, #24]
    7d38:	92403c21 	and	x1, x1, #0xffff
    7d3c:	9b027c21 	mul	x1, x1, x2
    7d40:	d360fc21 	lsr	x1, x1, #32
    7d44:	eb00003f 	cmp	x1, x0
    7d48:	54000142 	b.cs	7d70 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7d4c:	8b010294 	add	x20, x20, x1
    7d50:	39400280 	ldrb	w0, [x20]
    7d54:	340000e0 	cbz	w0, 7d70 <fwp_drop2+0x9c>
    7d58:	7100041f 	cmp	w0, #0x1
    7d5c:	540001e0 	b.eq	7d98 <fwp_drop2+0xc4>  // b.none
    7d60:	7103fc1f 	cmp	w0, #0xff
    7d64:	540007e0 	b.eq	7e60 <fwp_drop2+0x18c>  // b.none
    7d68:	51000400 	sub	w0, w0, #0x1
    7d6c:	39000280 	strb	w0, [x20]
    7d70:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d74:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7d7c:	d65f03c0 	ret
    7d80:	72003c3f 	tst	w1, #0xffff
    7d84:	54fffe60 	b.eq	7d50 <fwp_drop2+0x7c>  // b.none
    7d88:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7d94:	d65f03c0 	ret
    7d98:	911502c2 	add	x2, x22, #0x540
    7d9c:	f9400660 	ldr	x0, [x19, #8]
    7da0:	f949d841 	ldr	x1, [x2, #5040]
    7da4:	f949ec42 	ldr	x2, [x2, #5080]
    7da8:	cb010001 	sub	x1, x0, x1
    7dac:	eb02403f 	cmp	x1, x2, lsl #16
    7db0:	54000382 	b.cs	7e20 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7db4:	d350fc22 	lsr	x2, x1, #16
    7db8:	8b020842 	add	x2, x2, x2, lsl #2
    7dbc:	d37df042 	lsl	x2, x2, #3
    7dc0:	8b020064 	add	x4, x3, x2
    7dc4:	f9401094 	ldr	x20, [x4, #32]
    7dc8:	b40002d4 	cbz	x20, 7e20 <fwp_drop2+0x14c>
    7dcc:	38626862 	ldrb	w2, [x3, x2]
    7dd0:	7100085f 	cmp	w2, #0x2
    7dd4:	54000400 	b.eq	7e54 <fwp_drop2+0x180>  // b.none
    7dd8:	7100045f 	cmp	w2, #0x1
    7ddc:	54000221 	b.ne	7e20 <fwp_drop2+0x14c>  // b.any
    7de0:	29430883 	ldp	w3, w2, [x4, #24]
    7de4:	92403c21 	and	x1, x1, #0xffff
    7de8:	9b037c21 	mul	x1, x1, x3
    7dec:	d360fc21 	lsr	x1, x1, #32
    7df0:	eb02003f 	cmp	x1, x2
    7df4:	54000162 	b.cs	7e20 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7df8:	8b010294 	add	x20, x20, x1
    7dfc:	39400281 	ldrb	w1, [x20]
    7e00:	34000101 	cbz	w1, 7e20 <fwp_drop2+0x14c>
    7e04:	7100043f 	cmp	w1, #0x1
    7e08:	54000220 	b.eq	7e4c <fwp_drop2+0x178>  // b.none
    7e0c:	7103fc3f 	cmp	w1, #0xff
    7e10:	540005a0 	b.eq	7ec4 <fwp_drop2+0x1f0>  // b.none
    7e14:	51000421 	sub	w1, w1, #0x1
    7e18:	39000281 	strb	w1, [x20]
    7e1c:	d503201f 	nop
    7e20:	f9400a74 	ldr	x20, [x19, #16]
    7e24:	aa1303e0 	mov	x0, x19
    7e28:	97fff5cb 	bl	5554 <fwp_rc_free_arr>
    7e2c:	911502c0 	add	x0, x22, #0x540
    7e30:	f949d801 	ldr	x1, [x0, #5040]
    7e34:	f949ec00 	ldr	x0, [x0, #5080]
    7e38:	cb010281 	sub	x1, x20, x1
    7e3c:	eb00403f 	cmp	x1, x0, lsl #16
    7e40:	54fff982 	b.cs	7d70 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7e44:	aa1403f3 	mov	x19, x20
    7e48:	17ffffaf 	b	7d04 <fwp_drop2+0x30>
    7e4c:	97fff5c2 	bl	5554 <fwp_rc_free_arr>
    7e50:	17fffff4 	b	7e20 <fwp_drop2+0x14c>
    7e54:	72003c3f 	tst	w1, #0xffff
    7e58:	54fffe41 	b.ne	7e20 <fwp_drop2+0x14c>  // b.any
    7e5c:	17ffffe8 	b	7dfc <fwp_drop2+0x128>
    7e60:	ca544681 	eor	x1, x20, x20, lsr #17
    7e64:	911502c0 	add	x0, x22, #0x540
    7e68:	ca412421 	eor	x1, x1, x1, lsr #9
    7e6c:	8b210c01 	add	x1, x0, w1, uxtb #3
    7e70:	f94a2420 	ldr	x0, [x1, #5192]
    7e74:	b5000080 	cbnz	x0, 7e84 <fwp_drop2+0x1b0>
    7e78:	14000010 	b	7eb8 <fwp_drop2+0x1e4>
    7e7c:	f9400800 	ldr	x0, [x0, #16]
    7e80:	b40001c0 	cbz	x0, 7eb8 <fwp_drop2+0x1e4>
    7e84:	f9400001 	ldr	x1, [x0]
    7e88:	eb14003f 	cmp	x1, x20
    7e8c:	54ffff81 	b.ne	7e7c <fwp_drop2+0x1a8>  // b.any
    7e90:	f9400401 	ldr	x1, [x0, #8]
    7e94:	d1000421 	sub	x1, x1, #0x1
    7e98:	f9000401 	str	x1, [x0, #8]
    7e9c:	f103f83f 	cmp	x1, #0xfe
    7ea0:	54fff681 	b.ne	7d70 <fwp_drop2+0x9c>  // b.any
    7ea4:	aa1403e0 	mov	x0, x20
    7ea8:	97fff192 	bl	44f0 <fwp_rc_forget_slot>
    7eac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7eb0:	39000280 	strb	w0, [x20]
    7eb4:	17ffffaf 	b	7d70 <fwp_drop2+0x9c>
    7eb8:	f0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    7ebc:	912aa000 	add	x0, x0, #0xaa8
    7ec0:	97ffed90 	bl	3500 <fwp_trap>
    7ec4:	ca544680 	eor	x0, x20, x20, lsr #17
    7ec8:	911502c1 	add	x1, x22, #0x540
    7ecc:	ca402400 	eor	x0, x0, x0, lsr #9
    7ed0:	8b200c20 	add	x0, x1, w0, uxtb #3
    7ed4:	f94a2400 	ldr	x0, [x0, #5192]
    7ed8:	b5000080 	cbnz	x0, 7ee8 <fwp_drop2+0x214>
    7edc:	17fffff7 	b	7eb8 <fwp_drop2+0x1e4>
    7ee0:	f9400800 	ldr	x0, [x0, #16]
    7ee4:	b4fffea0 	cbz	x0, 7eb8 <fwp_drop2+0x1e4>
    7ee8:	f9400001 	ldr	x1, [x0]
    7eec:	eb14003f 	cmp	x1, x20
    7ef0:	54ffff81 	b.ne	7ee0 <fwp_drop2+0x20c>  // b.any
    7ef4:	f9400401 	ldr	x1, [x0, #8]
    7ef8:	d1000421 	sub	x1, x1, #0x1
    7efc:	f9000401 	str	x1, [x0, #8]
    7f00:	f103f83f 	cmp	x1, #0xfe
    7f04:	54fff8e1 	b.ne	7e20 <fwp_drop2+0x14c>  // b.any
    7f08:	aa1403e0 	mov	x0, x20
    7f0c:	97fff179 	bl	44f0 <fwp_rc_forget_slot>
    7f10:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7f14:	39000280 	strb	w0, [x20]
    7f18:	17ffffc2 	b	7e20 <fwp_drop2+0x14c>
    7f1c:	d503201f 	nop

0000000000007f20 <fwp_arg_drop23>:
    7f20:	7100003f 	cmp	w1, #0x0
    7f24:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7f28:	54000041 	b.ne	7f30 <fwp_arg_drop23+0x10>  // b.any
    7f2c:	d65f03c0 	ret
    7f30:	f9400000 	ldr	x0, [x0]
    7f34:	17ffff68 	b	7cd4 <fwp_drop2>
    7f38:	d503201f 	nop
    7f3c:	d503201f 	nop

0000000000007f40 <fwp_caps23>:
    7f40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7f44:	910003fd 	mov	x29, sp
    7f48:	f9000bf3 	str	x19, [sp, #16]
    7f4c:	aa0003f3 	mov	x19, x0
    7f50:	b9400400 	ldr	w0, [x0, #4]
    7f54:	340004a0 	cbz	w0, 7fe8 <fwp_caps23+0xa8>
    7f58:	f9400660 	ldr	x0, [x19, #8]
    7f5c:	350004e1 	cbnz	w1, 7ff8 <fwp_caps23+0xb8>
    7f60:	97ffff5d 	bl	7cd4 <fwp_drop2>
    7f64:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7f68:	91150042 	add	x2, x2, #0x540
    7f6c:	f949d840 	ldr	x0, [x2, #5040]
    7f70:	f949ec41 	ldr	x1, [x2, #5080]
    7f74:	cb000260 	sub	x0, x19, x0
    7f78:	eb01401f 	cmp	x0, x1, lsl #16
    7f7c:	54000382 	b.cs	7fec <fwp_caps23+0xac>  // b.hs, b.nlast
    7f80:	d350fc01 	lsr	x1, x0, #16
    7f84:	f949fc44 	ldr	x4, [x2, #5112]
    7f88:	8b010821 	add	x1, x1, x1, lsl #2
    7f8c:	d37df021 	lsl	x1, x1, #3
    7f90:	8b010083 	add	x3, x4, x1
    7f94:	f9401062 	ldr	x2, [x3, #32]
    7f98:	b40002a2 	cbz	x2, 7fec <fwp_caps23+0xac>
    7f9c:	38616881 	ldrb	w1, [x4, x1]
    7fa0:	7100083f 	cmp	w1, #0x2
    7fa4:	540006c0 	b.eq	807c <fwp_caps23+0x13c>  // b.none
    7fa8:	7100043f 	cmp	w1, #0x1
    7fac:	54000201 	b.ne	7fec <fwp_caps23+0xac>  // b.any
    7fb0:	29430464 	ldp	w4, w1, [x3, #24]
    7fb4:	92403c00 	and	x0, x0, #0xffff
    7fb8:	9b047c00 	mul	x0, x0, x4
    7fbc:	d360fc00 	lsr	x0, x0, #32
    7fc0:	eb01001f 	cmp	x0, x1
    7fc4:	54000142 	b.cs	7fec <fwp_caps23+0xac>  // b.hs, b.nlast
    7fc8:	8b000042 	add	x2, x2, x0
    7fcc:	39400040 	ldrb	w0, [x2]
    7fd0:	7100041f 	cmp	w0, #0x1
    7fd4:	540000c1 	b.ne	7fec <fwp_caps23+0xac>  // b.any
    7fd8:	aa1303e0 	mov	x0, x19
    7fdc:	f9400bf3 	ldr	x19, [sp, #16]
    7fe0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7fe4:	17fff1e3 	b	4770 <fwp_mem_free>
    7fe8:	34fffbe1 	cbz	w1, 7f64 <fwp_caps23+0x24>
    7fec:	f9400bf3 	ldr	x19, [sp, #16]
    7ff0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ff4:	d65f03c0 	ret
    7ff8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    7ffc:	91150042 	add	x2, x2, #0x540
    8000:	f949d843 	ldr	x3, [x2, #5040]
    8004:	f949ec41 	ldr	x1, [x2, #5080]
    8008:	cb030000 	sub	x0, x0, x3
    800c:	eb01401f 	cmp	x0, x1, lsl #16
    8010:	54fffee2 	b.cs	7fec <fwp_caps23+0xac>  // b.hs, b.nlast
    8014:	d350fc01 	lsr	x1, x0, #16
    8018:	f949fc44 	ldr	x4, [x2, #5112]
    801c:	8b010821 	add	x1, x1, x1, lsl #2
    8020:	d37df021 	lsl	x1, x1, #3
    8024:	8b010083 	add	x3, x4, x1
    8028:	f9401062 	ldr	x2, [x3, #32]
    802c:	b4fffe02 	cbz	x2, 7fec <fwp_caps23+0xac>
    8030:	38616881 	ldrb	w1, [x4, x1]
    8034:	7100083f 	cmp	w1, #0x2
    8038:	54000280 	b.eq	8088 <fwp_caps23+0x148>  // b.none
    803c:	7100043f 	cmp	w1, #0x1
    8040:	54fffd61 	b.ne	7fec <fwp_caps23+0xac>  // b.any
    8044:	92403c01 	and	x1, x0, #0xffff
    8048:	29430064 	ldp	w4, w0, [x3, #24]
    804c:	9b047c21 	mul	x1, x1, x4
    8050:	d360fc21 	lsr	x1, x1, #32
    8054:	eb00003f 	cmp	x1, x0
    8058:	54fffca2 	b.cs	7fec <fwp_caps23+0xac>  // b.hs, b.nlast
    805c:	8b010042 	add	x2, x2, x1
    8060:	39400040 	ldrb	w0, [x2]
    8064:	34fffc40 	cbz	w0, 7fec <fwp_caps23+0xac>
    8068:	7103f41f 	cmp	w0, #0xfd
    806c:	54000148 	b.hi	8094 <fwp_caps23+0x154>  // b.pmore
    8070:	11000400 	add	w0, w0, #0x1
    8074:	39000040 	strb	w0, [x2]
    8078:	17ffffdd 	b	7fec <fwp_caps23+0xac>
    807c:	72003c1f 	tst	w0, #0xffff
    8080:	54fffb61 	b.ne	7fec <fwp_caps23+0xac>  // b.any
    8084:	17ffffd2 	b	7fcc <fwp_caps23+0x8c>
    8088:	72003c1f 	tst	w0, #0xffff
    808c:	54fffb01 	b.ne	7fec <fwp_caps23+0xac>  // b.any
    8090:	17fffff4 	b	8060 <fwp_caps23+0x120>
    8094:	f9400bf3 	ldr	x19, [sp, #16]
    8098:	aa0203e0 	mov	x0, x2
    809c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    80a0:	17fff0cd 	b	43d4 <fwp_rc_wide_dup>

00000000000080a4 <f23>:
    80a4:	d101c3ff 	sub	sp, sp, #0x70
    80a8:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    80ac:	f947f421 	ldr	x1, [x1, #4072]
    80b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    80b4:	910083fd 	add	x29, sp, #0x20
    80b8:	a90563f7 	stp	x23, x24, [sp, #80]
    80bc:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xca0>
    80c0:	911502e3 	add	x3, x23, #0x540
    80c4:	a90353f3 	stp	x19, x20, [sp, #48]
    80c8:	a9045bf5 	stp	x21, x22, [sp, #64]
    80cc:	aa0003f6 	mov	x22, x0
    80d0:	a9066bf9 	stp	x25, x26, [sp, #96]
    80d4:	f949ec62 	ldr	x2, [x3, #5080]
    80d8:	f9400024 	ldr	x4, [x1]
    80dc:	f9000fe4 	str	x4, [sp, #24]
    80e0:	d2800004 	mov	x4, #0x0                   	// #0
    80e4:	f949d861 	ldr	x1, [x3, #5040]
    80e8:	d370bc42 	lsl	x2, x2, #16
    80ec:	b40015a0 	cbz	x0, 83a0 <f23+0x2fc>
    80f0:	f9400818 	ldr	x24, [x0, #16]
    80f4:	cb010301 	sub	x1, x24, x1
    80f8:	eb02003f 	cmp	x1, x2
    80fc:	54000362 	b.cs	8168 <f23+0xc4>  // b.hs, b.nlast
    8100:	f949fc60 	ldr	x0, [x3, #5112]
    8104:	d350fc22 	lsr	x2, x1, #16
    8108:	8b020842 	add	x2, x2, x2, lsl #2
    810c:	8b020c02 	add	x2, x0, x2, lsl #3
    8110:	f9401040 	ldr	x0, [x2, #32]
    8114:	b40002a0 	cbz	x0, 8168 <f23+0xc4>
    8118:	39400043 	ldrb	w3, [x2]
    811c:	7100087f 	cmp	w3, #0x2
    8120:	540013a0 	b.eq	8394 <f23+0x2f0>  // b.none
    8124:	7100047f 	cmp	w3, #0x1
    8128:	540001c1 	b.ne	8160 <f23+0xbc>  // b.any
    812c:	29430843 	ldp	w3, w2, [x2, #24]
    8130:	92403c21 	and	x1, x1, #0xffff
    8134:	9b037c21 	mul	x1, x1, x3
    8138:	d360fc21 	lsr	x1, x1, #32
    813c:	eb02003f 	cmp	x1, x2
    8140:	54000102 	b.cs	8160 <f23+0xbc>  // b.hs, b.nlast
    8144:	8b010000 	add	x0, x0, x1
    8148:	39400001 	ldrb	w1, [x0]
    814c:	340000a1 	cbz	w1, 8160 <f23+0xbc>
    8150:	7103f43f 	cmp	w1, #0xfd
    8154:	54001688 	b.hi	8424 <f23+0x380>  // b.pmore
    8158:	11000421 	add	w1, w1, #0x1
    815c:	39000001 	strb	w1, [x0]
    8160:	d2800000 	mov	x0, #0x0                   	// #0
    8164:	b40000d6 	cbz	x22, 817c <f23+0xd8>
    8168:	aa1603e1 	mov	x1, x22
    816c:	d2800000 	mov	x0, #0x0                   	// #0
    8170:	f9400821 	ldr	x1, [x1, #16]
    8174:	91000400 	add	x0, x0, #0x1
    8178:	b5ffffc1 	cbnz	x1, 8170 <f23+0xcc>
    817c:	b40011b8 	cbz	x24, 83b0 <f23+0x30c>
    8180:	aa1803e1 	mov	x1, x24
    8184:	d2800002 	mov	x2, #0x0                   	// #0
    8188:	f9400821 	ldr	x1, [x1, #16]
    818c:	91000442 	add	x2, x2, #0x1
    8190:	b5ffffc1 	cbnz	x1, 8188 <f23+0xe4>
    8194:	eb00005f 	cmp	x2, x0
    8198:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    819c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    81a0:	eb01033f 	cmp	x25, x1
    81a4:	54001468 	b.hi	8430 <f23+0x38c>  // b.pmore
    81a8:	d37ffb33 	lsl	x19, x25, #1
    81ac:	52800041 	mov	w1, #0x2                   	// #2
    81b0:	91000660 	add	x0, x19, #0x1
    81b4:	d37df000 	lsl	x0, x0, #3
    81b8:	97fff28e 	bl	4bf0 <fwp_heap_alloc>
    81bc:	911502e1 	add	x1, x23, #0x540
    81c0:	aa0003fa 	mov	x26, x0
    81c4:	f9000013 	str	x19, [x0]
    81c8:	aa0103e0 	mov	x0, x1
    81cc:	f949d821 	ldr	x1, [x1, #5040]
    81d0:	f949ec00 	ldr	x0, [x0, #5080]
    81d4:	cb010341 	sub	x1, x26, x1
    81d8:	eb00403f 	cmp	x1, x0, lsl #16
    81dc:	54000342 	b.cs	8244 <f23+0x1a0>  // b.hs, b.nlast
    81e0:	911502e2 	add	x2, x23, #0x540
    81e4:	d350fc20 	lsr	x0, x1, #16
    81e8:	8b000800 	add	x0, x0, x0, lsl #2
    81ec:	f949fc43 	ldr	x3, [x2, #5112]
    81f0:	d37df002 	lsl	x2, x0, #3
    81f4:	8b020060 	add	x0, x3, x2
    81f8:	f9401013 	ldr	x19, [x0, #32]
    81fc:	b4000253 	cbz	x19, 8244 <f23+0x1a0>
    8200:	38626862 	ldrb	w2, [x3, x2]
    8204:	7100085f 	cmp	w2, #0x2
    8208:	54000c00 	b.eq	8388 <f23+0x2e4>  // b.none
    820c:	7100045f 	cmp	w2, #0x1
    8210:	540001a1 	b.ne	8244 <f23+0x1a0>  // b.any
    8214:	29430002 	ldp	w2, w0, [x0, #24]
    8218:	92403c21 	and	x1, x1, #0xffff
    821c:	9b027c21 	mul	x1, x1, x2
    8220:	d360fc21 	lsr	x1, x1, #32
    8224:	eb00003f 	cmp	x1, x0
    8228:	540000e2 	b.cs	8244 <f23+0x1a0>  // b.hs, b.nlast
    822c:	8b010273 	add	x19, x19, x1
    8230:	39400260 	ldrb	w0, [x19]
    8234:	7103fc1f 	cmp	w0, #0xff
    8238:	54000da0 	b.eq	83ec <f23+0x348>  // b.none
    823c:	52800020 	mov	w0, #0x1                   	// #1
    8240:	39000260 	strb	w0, [x19]
    8244:	b4000259 	cbz	x25, 828c <f23+0x1e8>
    8248:	8b191359 	add	x25, x26, x25, lsl #4
    824c:	aa1a03f3 	mov	x19, x26
    8250:	aa1603f5 	mov	x21, x22
    8254:	aa1803f4 	mov	x20, x24
    8258:	f9400683 	ldr	x3, [x20, #8]
    825c:	f94006a2 	ldr	x2, [x21, #8]
    8260:	f9400861 	ldr	x1, [x3, #16]
    8264:	f9400840 	ldr	x0, [x2, #16]
    8268:	fd400461 	ldr	d1, [x3, #8]
    826c:	fd400440 	ldr	d0, [x2, #8]
    8270:	97fff3e0 	bl	51f0 <w107>
    8274:	f9000660 	str	x0, [x19, #8]
    8278:	f8010e61 	str	x1, [x19, #16]!
    827c:	f9400a94 	ldr	x20, [x20, #16]
    8280:	f9400ab5 	ldr	x21, [x21, #16]
    8284:	eb13033f 	cmp	x25, x19
    8288:	54fffe81 	b.ne	8258 <f23+0x1b4>  // b.any
    828c:	aa1803e0 	mov	x0, x24
    8290:	97fffe91 	bl	7cd4 <fwp_drop2>
    8294:	aa1603e0 	mov	x0, x22
    8298:	97fffe8f 	bl	7cd4 <fwp_drop2>
    829c:	911502f7 	add	x23, x23, #0x540
    82a0:	aa1a03e0 	mov	x0, x26
    82a4:	97fff417 	bl	5300 <w164.constprop.0>
    82a8:	aa0103f3 	mov	x19, x1
    82ac:	aa0003f4 	mov	x20, x0
    82b0:	aa1a03e0 	mov	x0, x26
    82b4:	97fff8bf 	bl	65b0 <fwp_drop4>
    82b8:	a900cff4 	stp	x20, x19, [sp, #8]
    82bc:	910023e1 	add	x1, sp, #0x8
    82c0:	52800000 	mov	w0, #0x0                   	// #0
    82c4:	97fff437 	bl	53a0 <fwp_data.part.0.constprop.0>
    82c8:	f949dae1 	ldr	x1, [x23, #5040]
    82cc:	aa0003f3 	mov	x19, x0
    82d0:	f949eee0 	ldr	x0, [x23, #5080]
    82d4:	cb010261 	sub	x1, x19, x1
    82d8:	eb00403f 	cmp	x1, x0, lsl #16
    82dc:	54000322 	b.cs	8340 <f23+0x29c>  // b.hs, b.nlast
    82e0:	d350fc22 	lsr	x2, x1, #16
    82e4:	f949fee3 	ldr	x3, [x23, #5112]
    82e8:	8b020842 	add	x2, x2, x2, lsl #2
    82ec:	d37df042 	lsl	x2, x2, #3
    82f0:	8b020060 	add	x0, x3, x2
    82f4:	f9401014 	ldr	x20, [x0, #32]
    82f8:	b4000254 	cbz	x20, 8340 <f23+0x29c>
    82fc:	38626862 	ldrb	w2, [x3, x2]
    8300:	7100085f 	cmp	w2, #0x2
    8304:	540003c0 	b.eq	837c <f23+0x2d8>  // b.none
    8308:	7100045f 	cmp	w2, #0x1
    830c:	540001a1 	b.ne	8340 <f23+0x29c>  // b.any
    8310:	29430002 	ldp	w2, w0, [x0, #24]
    8314:	92403c21 	and	x1, x1, #0xffff
    8318:	9b027c21 	mul	x1, x1, x2
    831c:	d360fc21 	lsr	x1, x1, #32
    8320:	eb00003f 	cmp	x1, x0
    8324:	540000e2 	b.cs	8340 <f23+0x29c>  // b.hs, b.nlast
    8328:	8b010294 	add	x20, x20, x1
    832c:	39400280 	ldrb	w0, [x20]
    8330:	7103fc1f 	cmp	w0, #0xff
    8334:	54000620 	b.eq	83f8 <f23+0x354>  // b.none
    8338:	52800020 	mov	w0, #0x1                   	// #1
    833c:	39000280 	strb	w0, [x20]
    8340:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8344:	f947f400 	ldr	x0, [x0, #4072]
    8348:	f9400fe2 	ldr	x2, [sp, #24]
    834c:	f9400001 	ldr	x1, [x0]
    8350:	eb010042 	subs	x2, x2, x1
    8354:	d2800001 	mov	x1, #0x0                   	// #0
    8358:	540006a1 	b.ne	842c <f23+0x388>  // b.any
    835c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8360:	aa1303e0 	mov	x0, x19
    8364:	a94353f3 	ldp	x19, x20, [sp, #48]
    8368:	a9445bf5 	ldp	x21, x22, [sp, #64]
    836c:	a94563f7 	ldp	x23, x24, [sp, #80]
    8370:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8374:	9101c3ff 	add	sp, sp, #0x70
    8378:	d65f03c0 	ret
    837c:	72003c3f 	tst	w1, #0xffff
    8380:	54fffe01 	b.ne	8340 <f23+0x29c>  // b.any
    8384:	17ffffea 	b	832c <f23+0x288>
    8388:	72003c3f 	tst	w1, #0xffff
    838c:	54fff5c1 	b.ne	8244 <f23+0x1a0>  // b.any
    8390:	17ffffa8 	b	8230 <f23+0x18c>
    8394:	72003c3f 	tst	w1, #0xffff
    8398:	54ffee41 	b.ne	8160 <f23+0xbc>  // b.any
    839c:	17ffff6b 	b	8148 <f23+0xa4>
    83a0:	cb0103e1 	neg	x1, x1
    83a4:	eb02003f 	cmp	x1, x2
    83a8:	540002e3 	b.cc	8404 <f23+0x360>  // b.lo, b.ul, b.last
    83ac:	d503201f 	nop
    83b0:	52800041 	mov	w1, #0x2                   	// #2
    83b4:	d2800100 	mov	x0, #0x8                   	// #8
    83b8:	97fff20e 	bl	4bf0 <fwp_heap_alloc>
    83bc:	aa0003e1 	mov	x1, x0
    83c0:	911502e0 	add	x0, x23, #0x540
    83c4:	aa0103fa 	mov	x26, x1
    83c8:	d2800018 	mov	x24, #0x0                   	// #0
    83cc:	f900003f 	str	xzr, [x1]
    83d0:	f949d801 	ldr	x1, [x0, #5040]
    83d4:	f949ec00 	ldr	x0, [x0, #5080]
    83d8:	cb010341 	sub	x1, x26, x1
    83dc:	eb00403f 	cmp	x1, x0, lsl #16
    83e0:	54fff562 	b.cs	828c <f23+0x1e8>  // b.hs, b.nlast
    83e4:	d2800019 	mov	x25, #0x0                   	// #0
    83e8:	17ffff7e 	b	81e0 <f23+0x13c>
    83ec:	aa1303e0 	mov	x0, x19
    83f0:	97fff040 	bl	44f0 <fwp_rc_forget_slot>
    83f4:	17ffff92 	b	823c <f23+0x198>
    83f8:	aa1403e0 	mov	x0, x20
    83fc:	97fff03d 	bl	44f0 <fwp_rc_forget_slot>
    8400:	17ffffce 	b	8338 <f23+0x294>
    8404:	f949fc62 	ldr	x2, [x3, #5112]
    8408:	d350fc20 	lsr	x0, x1, #16
    840c:	8b000800 	add	x0, x0, x0, lsl #2
    8410:	8b000c42 	add	x2, x2, x0, lsl #3
    8414:	f9401040 	ldr	x0, [x2, #32]
    8418:	b4fffcc0 	cbz	x0, 83b0 <f23+0x30c>
    841c:	d2800018 	mov	x24, #0x0                   	// #0
    8420:	17ffff3e 	b	8118 <f23+0x74>
    8424:	97ffefec 	bl	43d4 <fwp_rc_wide_dup>
    8428:	17ffff4e 	b	8160 <f23+0xbc>
    842c:	97ffe8f1 	bl	27f0 <__stack_chk_fail@plt>
    8430:	d0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    8434:	9131a000 	add	x0, x0, #0xc68
    8438:	97ffec32 	bl	3500 <fwp_trap>
    843c:	d503201f 	nop

0000000000008440 <fwp_owned_entry23>:
    8440:	f9400000 	ldr	x0, [x0]
    8444:	17ffff18 	b	80a4 <f23>
    8448:	d503201f 	nop
    844c:	d503201f 	nop

0000000000008450 <e23>:
    8450:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8454:	910003fd 	mov	x29, sp
    8458:	f9000bf3 	str	x19, [sp, #16]
    845c:	f9400013 	ldr	x19, [x0]
    8460:	aa1303e0 	mov	x0, x19
    8464:	97fff417 	bl	54c0 <fwp_rc_share>
    8468:	aa1303e0 	mov	x0, x19
    846c:	97ffff0e 	bl	80a4 <f23>
    8470:	aa0003f3 	mov	x19, x0
    8474:	97fff413 	bl	54c0 <fwp_rc_share>
    8478:	aa1303e0 	mov	x0, x19
    847c:	f9400bf3 	ldr	x19, [sp, #16]
    8480:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8484:	d65f03c0 	ret
    8488:	d503201f 	nop
    848c:	d503201f 	nop

0000000000008490 <fwp_write>:
    8490:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8494:	910003fd 	mov	x29, sp
    8498:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    849c:	f947f484 	ldr	x4, [x4, #4072]
    84a0:	a90153f3 	stp	x19, x20, [sp, #16]
    84a4:	d10943ff 	sub	sp, sp, #0x250
    84a8:	b9400045 	ldr	w5, [x2]
    84ac:	aa0003f4 	mov	x20, x0
    84b0:	f9400080 	ldr	x0, [x4]
    84b4:	f90127e0 	str	x0, [sp, #584]
    84b8:	d2800000 	mov	x0, #0x0                   	// #0
    84bc:	710064bf 	cmp	w5, #0x19
    84c0:	54000408 	b.hi	8540 <fwp_write+0xb0>  // b.pmore
    84c4:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x800>
    84c8:	aa0103f3 	mov	x19, x1
    84cc:	9110c000 	add	x0, x0, #0x430
    84d0:	f9013bf5 	str	x21, [sp, #624]
    84d4:	f9013ff6 	str	x22, [sp, #632]
    84d8:	f90153fb 	str	x27, [sp, #672]
    84dc:	f90157fc 	str	x28, [sp, #680]
    84e0:	aa0203fc 	mov	x28, x2
    84e4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    84e8:	10000061 	adr	x1, 84f4 <fwp_write+0x64>
    84ec:	8b20a820 	add	x0, x1, w0, sxth #2
    84f0:	d61f0000 	br	x0
    84f4:	910123e0 	add	x0, sp, #0x48
    84f8:	aa1303e5 	mov	x5, x19
    84fc:	d0000004 	adrp	x4, a000 <fwp_main_thread+0xb80>
    8500:	aa0003f3 	mov	x19, x0
    8504:	9133a084 	add	x4, x4, #0xce8
    8508:	d2804003 	mov	x3, #0x200                 	// #512
    850c:	aa0303e1 	mov	x1, x3
    8510:	52800042 	mov	w2, #0x2                   	// #2
    8514:	97ffe893 	bl	2760 <__snprintf_chk@plt>
    8518:	aa1303e0 	mov	x0, x19
    851c:	97ffe859 	bl	2680 <strlen@plt>
    8520:	aa1303e1 	mov	x1, x19
    8524:	aa0003e2 	mov	x2, x0
    8528:	aa1403e0 	mov	x0, x20
    852c:	97ffeb99 	bl	3390 <buf_put>
    8530:	f9413bf5 	ldr	x21, [sp, #624]
    8534:	f9413ff6 	ldr	x22, [sp, #632]
    8538:	f94153fb 	ldr	x27, [sp, #672]
    853c:	f94157fc 	ldr	x28, [sp, #680]
    8540:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8544:	f947f400 	ldr	x0, [x0, #4072]
    8548:	f94127e2 	ldr	x2, [sp, #584]
    854c:	f9400001 	ldr	x1, [x0]
    8550:	eb010042 	subs	x2, x2, x1
    8554:	d2800001 	mov	x1, #0x0                   	// #0
    8558:	540077c1 	b.ne	9450 <fwp_write+0xfc0>  // b.any
    855c:	910943ff 	add	sp, sp, #0x250
    8560:	a94153f3 	ldp	x19, x20, [sp, #16]
    8564:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8568:	d65f03c0 	ret
    856c:	910123e0 	add	x0, sp, #0x48
    8570:	aa1303e5 	mov	x5, x19
    8574:	d0000004 	adrp	x4, a000 <fwp_main_thread+0xb80>
    8578:	aa0003f3 	mov	x19, x0
    857c:	91338084 	add	x4, x4, #0xce0
    8580:	d2804003 	mov	x3, #0x200                 	// #512
    8584:	17ffffe2 	b	850c <fwp_write+0x7c>
    8588:	71004cbf 	cmp	w5, #0x13
    858c:	d0000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    8590:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8594:	91334000 	add	x0, x0, #0xcd0
    8598:	91336021 	add	x1, x1, #0xcd8
    859c:	d2800082 	mov	x2, #0x4                   	// #4
    85a0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    85a4:	aa1403e0 	mov	x0, x20
    85a8:	f90143f7 	str	x23, [sp, #640]
    85ac:	d2800016 	mov	x22, #0x0                   	// #0
    85b0:	f90147f8 	str	x24, [sp, #648]
    85b4:	97ffeb77 	bl	3390 <buf_put>
    85b8:	f9400260 	ldr	x0, [x19]
    85bc:	d0000017 	adrp	x23, a000 <fwp_main_thread+0xb80>
    85c0:	d2800015 	mov	x21, #0x0                   	// #0
    85c4:	913562f7 	add	x23, x23, #0xd58
    85c8:	b40047a0 	cbz	x0, 8ebc <fwp_write+0xa2c>
    85cc:	b9400380 	ldr	w0, [x28]
    85d0:	52800003 	mov	w3, #0x0                   	// #0
    85d4:	f9401f82 	ldr	x2, [x28, #56]
    85d8:	71004c1f 	cmp	w0, #0x13
    85dc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    85e0:	aa1403e0 	mov	x0, x20
    85e4:	8b010e61 	add	x1, x19, x1, lsl #3
    85e8:	f9400421 	ldr	x1, [x1, #8]
    85ec:	97ffffa9 	bl	8490 <fwp_write>
    85f0:	b9400380 	ldr	w0, [x28]
    85f4:	7100481f 	cmp	w0, #0x12
    85f8:	54004b40 	b.eq	8f60 <fwp_write+0xad0>  // b.none
    85fc:	f9400260 	ldr	x0, [x19]
    8600:	910006b5 	add	x21, x21, #0x1
    8604:	91000ad6 	add	x22, x22, #0x2
    8608:	eb15001f 	cmp	x0, x21
    860c:	54004589 	b.ls	8ebc <fwp_write+0xa2c>  // b.plast
    8610:	aa1703e1 	mov	x1, x23
    8614:	aa1403e0 	mov	x0, x20
    8618:	d2800042 	mov	x2, #0x2                   	// #2
    861c:	97ffeb5d 	bl	3390 <buf_put>
    8620:	17ffffeb 	b	85cc <fwp_write+0x13c>
    8624:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8628:	91344021 	add	x1, x1, #0xd10
    862c:	d28000c2 	mov	x2, #0x6                   	// #6
    8630:	aa1403e0 	mov	x0, x20
    8634:	91004273 	add	x19, x19, #0x10
    8638:	97ffeb56 	bl	3390 <buf_put>
    863c:	aa1303e0 	mov	x0, x19
    8640:	97ffe810 	bl	2680 <strlen@plt>
    8644:	aa1303e1 	mov	x1, x19
    8648:	aa0003e2 	mov	x2, x0
    864c:	aa1403e0 	mov	x0, x20
    8650:	97ffeb50 	bl	3390 <buf_put>
    8654:	528007c3 	mov	w3, #0x3e                  	// #62
    8658:	aa1403e0 	mov	x0, x20
    865c:	91001fe1 	add	x1, sp, #0x7
    8660:	d2800022 	mov	x2, #0x1                   	// #1
    8664:	39001fe3 	strb	w3, [sp, #7]
    8668:	17ffffb1 	b	852c <fwp_write+0x9c>
    866c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8670:	f947f400 	ldr	x0, [x0, #4072]
    8674:	f94127e2 	ldr	x2, [sp, #584]
    8678:	f9400001 	ldr	x1, [x0]
    867c:	eb010042 	subs	x2, x2, x1
    8680:	d2800001 	mov	x1, #0x0                   	// #0
    8684:	540034e1 	b.ne	8d20 <fwp_write+0x890>  // b.any
    8688:	f9413bf5 	ldr	x21, [sp, #624]
    868c:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8690:	f9413ff6 	ldr	x22, [sp, #632]
    8694:	aa1403e0 	mov	x0, x20
    8698:	9133c021 	add	x1, x1, #0xcf0
    869c:	d2800142 	mov	x2, #0xa                   	// #10
    86a0:	f94153fb 	ldr	x27, [sp, #672]
    86a4:	f94157fc 	ldr	x28, [sp, #680]
    86a8:	910943ff 	add	sp, sp, #0x250
    86ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    86b0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    86b4:	17ffeb37 	b	3390 <buf_put>
    86b8:	f9400456 	ldr	x22, [x2, #8]
    86bc:	f90143f7 	str	x23, [sp, #640]
    86c0:	f90147f8 	str	x24, [sp, #648]
    86c4:	b4005b16 	cbz	x22, 9224 <fwp_write+0xd94>
    86c8:	aa1603e0 	mov	x0, x22
    86cc:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    86d0:	9135c021 	add	x1, x1, #0xd70
    86d4:	97ffe867 	bl	2870 <strcmp@plt>
    86d8:	2a0003f5 	mov	w21, w0
    86dc:	34005fe0 	cbz	w0, 92d8 <fwp_write+0xe48>
    86e0:	aa1603e0 	mov	x0, x22
    86e4:	97ffe7e7 	bl	2680 <strlen@plt>
    86e8:	aa1603e1 	mov	x1, x22
    86ec:	aa0003e2 	mov	x2, x0
    86f0:	aa1403e0 	mov	x0, x20
    86f4:	97ffeb27 	bl	3390 <buf_put>
    86f8:	52800403 	mov	w3, #0x20                  	// #32
    86fc:	91001ff5 	add	x21, sp, #0x7
    8700:	aa1503e1 	mov	x1, x21
    8704:	aa1403e0 	mov	x0, x20
    8708:	d2800022 	mov	x2, #0x1                   	// #1
    870c:	39001fe3 	strb	w3, [sp, #7]
    8710:	97ffeb20 	bl	3390 <buf_put>
    8714:	52800f63 	mov	w3, #0x7b                  	// #123
    8718:	aa1403e0 	mov	x0, x20
    871c:	aa1503e1 	mov	x1, x21
    8720:	d2800022 	mov	x2, #0x1                   	// #1
    8724:	39001fe3 	strb	w3, [sp, #7]
    8728:	97ffeb1a 	bl	3390 <buf_put>
    872c:	b9401380 	ldr	w0, [x28, #16]
    8730:	52800018 	mov	w24, #0x0                   	// #0
    8734:	7100001f 	cmp	w0, #0x0
    8738:	54003aad 	b.le	8e8c <fwp_write+0x9fc>
    873c:	f9014bf9 	str	x25, [sp, #656]
    8740:	d0000019 	adrp	x25, a000 <fwp_main_thread+0xb80>
    8744:	91366339 	add	x25, x25, #0xd98
    8748:	f9014ffa 	str	x26, [sp, #664]
    874c:	d000001a 	adrp	x26, a000 <fwp_main_thread+0xb80>
    8750:	9135635a 	add	x26, x26, #0xd58
    8754:	91002276 	add	x22, x19, #0x8
    8758:	d2800013 	mov	x19, #0x0                   	// #0
    875c:	b5003e93 	cbnz	x19, 8f2c <fwp_write+0xa9c>
    8760:	d37df277 	lsl	x23, x19, #3
    8764:	34003cb8 	cbz	w24, 8ef8 <fwp_write+0xa68>
    8768:	f9401382 	ldr	x2, [x28, #32]
    876c:	aa1403e0 	mov	x0, x20
    8770:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8774:	52800003 	mov	w3, #0x0                   	// #0
    8778:	f8776842 	ldr	x2, [x2, x23]
    877c:	91000673 	add	x19, x19, #0x1
    8780:	97ffff44 	bl	8490 <fwp_write>
    8784:	b9401380 	ldr	w0, [x28, #16]
    8788:	6b13001f 	cmp	w0, w19
    878c:	54fffe8c 	b.gt	875c <fwp_write+0x2cc>
    8790:	f9414bf9 	ldr	x25, [sp, #656]
    8794:	f9414ffa 	ldr	x26, [sp, #664]
    8798:	340037b8 	cbz	w24, 8e8c <fwp_write+0x9fc>
    879c:	52800523 	mov	w3, #0x29                  	// #41
    87a0:	aa1503e1 	mov	x1, x21
    87a4:	aa1403e0 	mov	x0, x20
    87a8:	d2800022 	mov	x2, #0x1                   	// #1
    87ac:	39001fe3 	strb	w3, [sp, #7]
    87b0:	97ffeaf8 	bl	3390 <buf_put>
    87b4:	f9413bf5 	ldr	x21, [sp, #624]
    87b8:	f9413ff6 	ldr	x22, [sp, #632]
    87bc:	f94143f7 	ldr	x23, [sp, #640]
    87c0:	f94147f8 	ldr	x24, [sp, #648]
    87c4:	f94153fb 	ldr	x27, [sp, #672]
    87c8:	f94157fc 	ldr	x28, [sp, #680]
    87cc:	17ffff5d 	b	8540 <fwp_write+0xb0>
    87d0:	b9404855 	ldr	w21, [x2, #72]
    87d4:	aa1403e0 	mov	x0, x20
    87d8:	93407eb6 	sxtw	x22, w21
    87dc:	91000ac1 	add	x1, x22, #0x2
    87e0:	97ffeab9 	bl	32c4 <buf_grow>
    87e4:	a9400281 	ldp	x1, x0, [x20]
    87e8:	528e8603 	mov	w3, #0x7430                	// #29744
    87ec:	78206823 	strh	w3, [x1, x0]
    87f0:	8b000022 	add	x2, x1, x0
    87f4:	710002bf 	cmp	w21, #0x0
    87f8:	540036cd 	b.le	8ed0 <fwp_write+0xa40>
    87fc:	110006a3 	add	w3, w21, #0x1
    8800:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8804:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8808:	91000449 	add	x9, x2, #0x1
    880c:	8b23c043 	add	x3, x2, w3, sxtw
    8810:	f28aaac6 	movk	x6, #0x5556
    8814:	f2955568 	movk	x8, #0xaaab
    8818:	1400000d 	b	884c <fwp_write+0x3bc>
    881c:	d2800021 	mov	x1, #0x1                   	// #1
    8820:	528005a5 	mov	w5, #0x2d                  	// #45
    8824:	f100001f 	cmp	x0, #0x0
    8828:	9b467e60 	smulh	x0, x19, x6
    882c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8830:	381ff465 	strb	w5, [x3], #-1
    8834:	cb040000 	sub	x0, x0, x4
    8838:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    883c:	cb020000 	sub	x0, x0, x2
    8840:	8b010013 	add	x19, x0, x1
    8844:	eb03013f 	cmp	x9, x3
    8848:	54003440 	b.eq	8ed0 <fwp_write+0xa40>  // b.none
    884c:	9b467e60 	smulh	x0, x19, x6
    8850:	937ffe64 	asr	x4, x19, #63
    8854:	52800605 	mov	w5, #0x30                  	// #48
    8858:	cb040000 	sub	x0, x0, x4
    885c:	8b000400 	add	x0, x0, x0, lsl #1
    8860:	cb000260 	sub	x0, x19, x0
    8864:	91000c01 	add	x1, x0, #0x3
    8868:	9bc87c22 	umulh	x2, x1, x8
    886c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8870:	8b4204e2 	add	x2, x7, x2, lsr #1
    8874:	eb020021 	subs	x1, x1, x2
    8878:	54fffd60 	b.eq	8824 <fwp_write+0x394>  // b.none
    887c:	f100043f 	cmp	x1, #0x1
    8880:	54fffce1 	b.ne	881c <fwp_write+0x38c>  // b.any
    8884:	d2800001 	mov	x1, #0x0                   	// #0
    8888:	52800565 	mov	w5, #0x2b                  	// #43
    888c:	17ffffe6 	b	8824 <fwp_write+0x394>
    8890:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8894:	f947f400 	ldr	x0, [x0, #4072]
    8898:	f94127e2 	ldr	x2, [sp, #584]
    889c:	f9400001 	ldr	x1, [x0]
    88a0:	eb010042 	subs	x2, x2, x1
    88a4:	d2800001 	mov	x1, #0x0                   	// #0
    88a8:	540023c1 	b.ne	8d20 <fwp_write+0x890>  // b.any
    88ac:	f9413bf5 	ldr	x21, [sp, #624]
    88b0:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    88b4:	f9413ff6 	ldr	x22, [sp, #632]
    88b8:	aa1403e0 	mov	x0, x20
    88bc:	91340021 	add	x1, x1, #0xd00
    88c0:	d2800102 	mov	x2, #0x8                   	// #8
    88c4:	17ffff77 	b	86a0 <fwp_write+0x210>
    88c8:	aa1403e0 	mov	x0, x20
    88cc:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    88d0:	d28000c2 	mov	x2, #0x6                   	// #6
    88d4:	91358021 	add	x1, x1, #0xd60
    88d8:	97ffeaae 	bl	3390 <buf_put>
    88dc:	d2800015 	mov	x21, #0x0                   	// #0
    88e0:	f9400263 	ldr	x3, [x19]
    88e4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    88e8:	54002c60 	b.eq	8e74 <fwp_write+0x9e4>  // b.none
    88ec:	f9401f82 	ldr	x2, [x28, #56]
    88f0:	f90143f7 	str	x23, [sp, #640]
    88f4:	f90147f8 	str	x24, [sp, #648]
    88f8:	d2800857 	mov	x23, #0x42                  	// #66
    88fc:	f9014bf9 	str	x25, [sp, #656]
    8900:	d0000016 	adrp	x22, a000 <fwp_main_thread+0xb80>
    8904:	f9014ffa 	str	x26, [sp, #664]
    8908:	913562d6 	add	x22, x22, #0xd58
    890c:	d2800038 	mov	x24, #0x1                   	// #1
    8910:	f2a18017 	movk	x23, #0xc00, lsl #16
    8914:	d2809099 	mov	x25, #0x484                 	// #1156
    8918:	b40004a2 	cbz	x2, 89ac <fwp_write+0x51c>
    891c:	b9400040 	ldr	w0, [x2]
    8920:	7100701f 	cmp	w0, #0x1c
    8924:	540042c0 	b.eq	917c <fwp_write+0xcec>  // b.none
    8928:	71006c1f 	cmp	w0, #0x1b
    892c:	54000408 	b.hi	89ac <fwp_write+0x51c>  // b.pmore
    8930:	9ac02301 	lsl	x1, x24, x0
    8934:	ea17003f 	tst	x1, x23
    8938:	540036a1 	b.ne	900c <fwp_write+0xb7c>  // b.any
    893c:	ea19003f 	tst	x1, x25
    8940:	54003521 	b.ne	8fe4 <fwp_write+0xb54>  // b.any
    8944:	d2800424 	mov	x4, #0x21                  	// #33
    8948:	ea04003f 	tst	x1, x4
    894c:	54000300 	b.eq	89ac <fwp_write+0x51c>  // b.none
    8950:	b7f849c3 	tbnz	x3, #63, 9288 <fwp_write+0xdf8>
    8954:	91002261 	add	x1, x19, #0x8
    8958:	8b150021 	add	x1, x1, x21
    895c:	39400021 	ldrb	w1, [x1]
    8960:	7100001f 	cmp	w0, #0x0
    8964:	93401c23 	sxtb	x3, w1
    8968:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    896c:	d503201f 	nop
    8970:	aa1403e0 	mov	x0, x20
    8974:	52800003 	mov	w3, #0x0                   	// #0
    8978:	97fffec6 	bl	8490 <fwp_write>
    897c:	910006b5 	add	x21, x21, #0x1
    8980:	f9400260 	ldr	x0, [x19]
    8984:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8988:	eb0002bf 	cmp	x21, x0
    898c:	540026c2 	b.cs	8e64 <fwp_write+0x9d4>  // b.hs, b.nlast
    8990:	d2800042 	mov	x2, #0x2                   	// #2
    8994:	aa1603e1 	mov	x1, x22
    8998:	aa1403e0 	mov	x0, x20
    899c:	97ffea7d 	bl	3390 <buf_put>
    89a0:	f9401f82 	ldr	x2, [x28, #56]
    89a4:	f9400263 	ldr	x3, [x19]
    89a8:	b5fffba2 	cbnz	x2, 891c <fwp_write+0x48c>
    89ac:	d37df2a0 	lsl	x0, x21, #3
    89b0:	b7f83f03 	tbnz	x3, #63, 9190 <fwp_write+0xd00>
    89b4:	91002261 	add	x1, x19, #0x8
    89b8:	8b000020 	add	x0, x1, x0
    89bc:	f9400001 	ldr	x1, [x0]
    89c0:	17ffffec 	b	8970 <fwp_write+0x4e0>
    89c4:	a9400e62 	ldp	x2, x3, [x19]
    89c8:	b7f83ca3 	tbnz	x3, #63, 915c <fwp_write+0xccc>
    89cc:	910123f5 	add	x21, sp, #0x48
    89d0:	aa1503e0 	mov	x0, x21
    89d4:	97ffe8f3 	bl	2da0 <fwp_fmt_u128>
    89d8:	aa1503e0 	mov	x0, x21
    89dc:	97ffe729 	bl	2680 <strlen@plt>
    89e0:	aa1503e1 	mov	x1, x21
    89e4:	aa0003e2 	mov	x2, x0
    89e8:	17fffed0 	b	8528 <fwp_write+0x98>
    89ec:	fd015be8 	str	d8, [sp, #688]
    89f0:	1e270268 	fmov	s8, w19
    89f4:	fd015fe9 	str	d9, [sp, #696]
    89f8:	1e282100 	fcmp	s8, s8
    89fc:	54004d26 	b.vs	93a0 <fwp_write+0xf10>
    8a00:	1e20c101 	fabs	s1, s8
    8a04:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8a08:	1e270000 	fmov	s0, w0
    8a0c:	1e202020 	fcmp	s1, s0
    8a10:	54002c0d 	b.le	8f90 <fwp_write+0xb00>
    8a14:	1e202118 	fcmpe	s8, #0.0
    8a18:	d0000002 	adrp	x2, a000 <fwp_main_thread+0xb80>
    8a1c:	91208042 	add	x2, x2, #0x820
    8a20:	910123f5 	add	x21, sp, #0x48
    8a24:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8a28:	9132c021 	add	x1, x1, #0xcb0
    8a2c:	aa1503e0 	mov	x0, x21
    8a30:	9a81c041 	csel	x1, x2, x1, gt
    8a34:	97ffe7bf 	bl	2930 <strcpy@plt>
    8a38:	aa1503e0 	mov	x0, x21
    8a3c:	97ffe711 	bl	2680 <strlen@plt>
    8a40:	aa1503e1 	mov	x1, x21
    8a44:	aa0003e2 	mov	x2, x0
    8a48:	aa1403e0 	mov	x0, x20
    8a4c:	97ffea51 	bl	3390 <buf_put>
    8a50:	f9413bf5 	ldr	x21, [sp, #624]
    8a54:	f9413ff6 	ldr	x22, [sp, #632]
    8a58:	f94153fb 	ldr	x27, [sp, #672]
    8a5c:	f94157fc 	ldr	x28, [sp, #680]
    8a60:	fd415be8 	ldr	d8, [sp, #688]
    8a64:	fd415fe9 	ldr	d9, [sp, #696]
    8a68:	17fffeb6 	b	8540 <fwp_write+0xb0>
    8a6c:	f9400276 	ldr	x22, [x19]
    8a70:	34002e03 	cbz	w3, 9030 <fwp_write+0xba0>
    8a74:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8a78:	f947f400 	ldr	x0, [x0, #4072]
    8a7c:	f94127e2 	ldr	x2, [sp, #584]
    8a80:	f9400001 	ldr	x1, [x0]
    8a84:	eb010042 	subs	x2, x2, x1
    8a88:	d2800001 	mov	x1, #0x0                   	// #0
    8a8c:	540014a1 	b.ne	8d20 <fwp_write+0x890>  // b.any
    8a90:	aa1603e2 	mov	x2, x22
    8a94:	91002261 	add	x1, x19, #0x8
    8a98:	f9413bf5 	ldr	x21, [sp, #624]
    8a9c:	aa1403e0 	mov	x0, x20
    8aa0:	f9413ff6 	ldr	x22, [sp, #632]
    8aa4:	17fffeff 	b	86a0 <fwp_write+0x210>
    8aa8:	fd015be8 	str	d8, [sp, #688]
    8aac:	9e670268 	fmov	d8, x19
    8ab0:	fd015fe9 	str	d9, [sp, #696]
    8ab4:	1e682100 	fcmp	d8, d8
    8ab8:	54004746 	b.vs	93a0 <fwp_write+0xf10>
    8abc:	1e60c101 	fabs	d1, d8
    8ac0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8ac4:	9e670000 	fmov	d0, x0
    8ac8:	910123f5 	add	x21, sp, #0x48
    8acc:	52800033 	mov	w19, #0x1                   	// #1
    8ad0:	1e602020 	fcmp	d1, d0
    8ad4:	540001ad 	b.le	8b08 <fwp_write+0x678>
    8ad8:	1e602118 	fcmpe	d8, #0.0
    8adc:	d0000002 	adrp	x2, a000 <fwp_main_thread+0xb80>
    8ae0:	91208042 	add	x2, x2, #0x820
    8ae4:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8ae8:	9132c021 	add	x1, x1, #0xcb0
    8aec:	aa1503e0 	mov	x0, x21
    8af0:	9a81c041 	csel	x1, x2, x1, gt
    8af4:	97ffe78f 	bl	2930 <strcpy@plt>
    8af8:	17ffffd0 	b	8a38 <fwp_write+0x5a8>
    8afc:	11000673 	add	w19, w19, #0x1
    8b00:	71004a7f 	cmp	w19, #0x12
    8b04:	54003860 	b.eq	9210 <fwp_write+0xd80>  // b.none
    8b08:	1e604100 	fmov	d0, d8
    8b0c:	2a1303e1 	mov	w1, w19
    8b10:	aa1503e0 	mov	x0, x21
    8b14:	97ffeb60 	bl	3894 <fwp_format_g.constprop.0>
    8b18:	aa1503e0 	mov	x0, x21
    8b1c:	d2800001 	mov	x1, #0x0                   	// #0
    8b20:	97ffe6ec 	bl	26d0 <strtod@plt>
    8b24:	1e602100 	fcmp	d8, d0
    8b28:	54fffea1 	b.ne	8afc <fwp_write+0x66c>  // b.any
    8b2c:	aa1503e0 	mov	x0, x21
    8b30:	97ffea51 	bl	3474 <fwp_finish_float>
    8b34:	17ffffc1 	b	8a38 <fwp_write+0x5a8>
    8b38:	a9400e62 	ldp	x2, x3, [x19]
    8b3c:	910123f3 	add	x19, sp, #0x48
    8b40:	aa1303e0 	mov	x0, x19
    8b44:	97ffe897 	bl	2da0 <fwp_fmt_u128>
    8b48:	17fffe74 	b	8518 <fwp_write+0x88>
    8b4c:	f90143f7 	str	x23, [sp, #640]
    8b50:	f90147f8 	str	x24, [sp, #648]
    8b54:	2a1303f8 	mov	w24, w19
    8b58:	f9014bf9 	str	x25, [sp, #656]
    8b5c:	f9014ffa 	str	x26, [sp, #664]
    8b60:	f13ffe7f 	cmp	x19, #0xfff
    8b64:	54000049 	b.ls	8b6c <fwp_write+0x6dc>  // b.plast
    8b68:	b9400278 	ldr	w24, [x19]
    8b6c:	f9400f80 	ldr	x0, [x28, #24]
    8b70:	2a1803f5 	mov	w21, w24
    8b74:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8b78:	d37ef6b9 	lsl	x25, x21, #2
    8b7c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8b80:	aa1603e0 	mov	x0, x22
    8b84:	97ffe6bf 	bl	2680 <strlen@plt>
    8b88:	aa1603e1 	mov	x1, x22
    8b8c:	aa0003e2 	mov	x2, x0
    8b90:	aa1403e0 	mov	x0, x20
    8b94:	97ffe9ff 	bl	3390 <buf_put>
    8b98:	f9401780 	ldr	x0, [x28, #40]
    8b9c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8ba0:	7100001f 	cmp	w0, #0x0
    8ba4:	5400068d 	b.le	8c74 <fwp_write+0x7e4>
    8ba8:	91002276 	add	x22, x19, #0x8
    8bac:	91001ff5 	add	x21, sp, #0x7
    8bb0:	d280001b 	mov	x27, #0x0                   	// #0
    8bb4:	5280041a 	mov	w26, #0x20                  	// #32
    8bb8:	f9401b80 	ldr	x0, [x28, #48]
    8bbc:	aa1503e1 	mov	x1, x21
    8bc0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8bc4:	d2800022 	mov	x2, #0x1                   	// #1
    8bc8:	f8786803 	ldr	x3, [x0, x24]
    8bcc:	aa1403e0 	mov	x0, x20
    8bd0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8bd4:	39001ffa 	strb	w26, [sp, #7]
    8bd8:	97ffe9ee 	bl	3390 <buf_put>
    8bdc:	f13ffeff 	cmp	x23, #0xfff
    8be0:	b9400261 	ldr	w1, [x19]
    8be4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8be8:	7100383f 	cmp	w1, #0xe
    8bec:	54000160 	b.eq	8c18 <fwp_write+0x788>  // b.none
    8bf0:	7100403f 	cmp	w1, #0x10
    8bf4:	54001a60 	b.eq	8f40 <fwp_write+0xab0>  // b.none
    8bf8:	7100283f 	cmp	w1, #0xa
    8bfc:	54002aa0 	b.eq	9150 <fwp_write+0xcc0>  // b.none
    8c00:	540014ac 	b.gt	8e94 <fwp_write+0xa04>
    8c04:	71000c3f 	cmp	w1, #0x3
    8c08:	540029ac 	b.gt	913c <fwp_write+0xcac>
    8c0c:	d37ffee0 	lsr	x0, x23, #63
    8c10:	37f814a1 	tbnz	w1, #31, 8ea4 <fwp_write+0xa14>
    8c14:	d503201f 	nop
    8c18:	34001460 	cbz	w0, 8ea4 <fwp_write+0xa14>
    8c1c:	52800503 	mov	w3, #0x28                  	// #40
    8c20:	aa1503e1 	mov	x1, x21
    8c24:	aa1403e0 	mov	x0, x20
    8c28:	d2800022 	mov	x2, #0x1                   	// #1
    8c2c:	39001fe3 	strb	w3, [sp, #7]
    8c30:	97ffe9d8 	bl	3390 <buf_put>
    8c34:	aa1303e2 	mov	x2, x19
    8c38:	aa1703e1 	mov	x1, x23
    8c3c:	aa1403e0 	mov	x0, x20
    8c40:	52800003 	mov	w3, #0x0                   	// #0
    8c44:	97fffe13 	bl	8490 <fwp_write>
    8c48:	52800523 	mov	w3, #0x29                  	// #41
    8c4c:	aa1503e1 	mov	x1, x21
    8c50:	aa1403e0 	mov	x0, x20
    8c54:	d2800022 	mov	x2, #0x1                   	// #1
    8c58:	39001fe3 	strb	w3, [sp, #7]
    8c5c:	97ffe9cd 	bl	3390 <buf_put>
    8c60:	f9401780 	ldr	x0, [x28, #40]
    8c64:	9100077b 	add	x27, x27, #0x1
    8c68:	b8796800 	ldr	w0, [x0, x25]
    8c6c:	6b1b001f 	cmp	w0, w27
    8c70:	54fffa4c 	b.gt	8bb8 <fwp_write+0x728>
    8c74:	f9413bf5 	ldr	x21, [sp, #624]
    8c78:	f9413ff6 	ldr	x22, [sp, #632]
    8c7c:	f94143f7 	ldr	x23, [sp, #640]
    8c80:	f94147f8 	ldr	x24, [sp, #648]
    8c84:	f9414bf9 	ldr	x25, [sp, #656]
    8c88:	f9414ffa 	ldr	x26, [sp, #664]
    8c8c:	f94153fb 	ldr	x27, [sp, #672]
    8c90:	f94157fc 	ldr	x28, [sp, #680]
    8c94:	17fffe2b 	b	8540 <fwp_write+0xb0>
    8c98:	52800783 	mov	w3, #0x3c                  	// #60
    8c9c:	91001ff3 	add	x19, sp, #0x7
    8ca0:	aa1303e1 	mov	x1, x19
    8ca4:	d2800022 	mov	x2, #0x1                   	// #1
    8ca8:	aa1403e0 	mov	x0, x20
    8cac:	39001fe3 	strb	w3, [sp, #7]
    8cb0:	97ffe9b8 	bl	3390 <buf_put>
    8cb4:	f9400795 	ldr	x21, [x28, #8]
    8cb8:	aa1503e0 	mov	x0, x21
    8cbc:	97ffe671 	bl	2680 <strlen@plt>
    8cc0:	aa1503e1 	mov	x1, x21
    8cc4:	aa0003e2 	mov	x2, x0
    8cc8:	aa1403e0 	mov	x0, x20
    8ccc:	97ffe9b1 	bl	3390 <buf_put>
    8cd0:	528007c3 	mov	w3, #0x3e                  	// #62
    8cd4:	aa1303e1 	mov	x1, x19
    8cd8:	aa1403e0 	mov	x0, x20
    8cdc:	d2800022 	mov	x2, #0x1                   	// #1
    8ce0:	39001fe3 	strb	w3, [sp, #7]
    8ce4:	17fffe12 	b	852c <fwp_write+0x9c>
    8ce8:	f100067f 	cmp	x19, #0x1
    8cec:	540025a0 	b.eq	91a0 <fwp_write+0xd10>  // b.none
    8cf0:	b100067f 	cmn	x19, #0x1
    8cf4:	54002bc0 	b.eq	926c <fwp_write+0xddc>  // b.none
    8cf8:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8cfc:	9132e021 	add	x1, x1, #0xcb8
    8d00:	d2800022 	mov	x2, #0x1                   	// #1
    8d04:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8d08:	f947f400 	ldr	x0, [x0, #4072]
    8d0c:	f94127e4 	ldr	x4, [sp, #584]
    8d10:	f9400003 	ldr	x3, [x0]
    8d14:	eb030084 	subs	x4, x4, x3
    8d18:	d2800003 	mov	x3, #0x0                   	// #0
    8d1c:	54ffebe0 	b.eq	8a98 <fwp_write+0x608>  // b.none
    8d20:	f90143f7 	str	x23, [sp, #640]
    8d24:	f90147f8 	str	x24, [sp, #648]
    8d28:	f9014bf9 	str	x25, [sp, #656]
    8d2c:	f9014ffa 	str	x26, [sp, #664]
    8d30:	fd015be8 	str	d8, [sp, #688]
    8d34:	fd015fe9 	str	d9, [sp, #696]
    8d38:	97ffe6ae 	bl	27f0 <__stack_chk_fail@plt>
    8d3c:	52800b63 	mov	w3, #0x5b                  	// #91
    8d40:	91001ff5 	add	x21, sp, #0x7
    8d44:	aa1503e1 	mov	x1, x21
    8d48:	aa1403e0 	mov	x0, x20
    8d4c:	d2800022 	mov	x2, #0x1                   	// #1
    8d50:	d0000016 	adrp	x22, a000 <fwp_main_thread+0xb80>
    8d54:	913562d6 	add	x22, x22, #0xd58
    8d58:	39001fe3 	strb	w3, [sp, #7]
    8d5c:	97ffe98d 	bl	3390 <buf_put>
    8d60:	b4000273 	cbz	x19, 8dac <fwp_write+0x91c>
    8d64:	f9400661 	ldr	x1, [x19, #8]
    8d68:	aa1403e0 	mov	x0, x20
    8d6c:	f9401f82 	ldr	x2, [x28, #56]
    8d70:	52800003 	mov	w3, #0x0                   	// #0
    8d74:	97fffdc7 	bl	8490 <fwp_write>
    8d78:	f9400a73 	ldr	x19, [x19, #16]
    8d7c:	b4000193 	cbz	x19, 8dac <fwp_write+0x91c>
    8d80:	aa1603e1 	mov	x1, x22
    8d84:	aa1403e0 	mov	x0, x20
    8d88:	d2800042 	mov	x2, #0x2                   	// #2
    8d8c:	97ffe981 	bl	3390 <buf_put>
    8d90:	f9400661 	ldr	x1, [x19, #8]
    8d94:	aa1403e0 	mov	x0, x20
    8d98:	f9401f82 	ldr	x2, [x28, #56]
    8d9c:	52800003 	mov	w3, #0x0                   	// #0
    8da0:	97fffdbc 	bl	8490 <fwp_write>
    8da4:	f9400a73 	ldr	x19, [x19, #16]
    8da8:	b5fffed3 	cbnz	x19, 8d80 <fwp_write+0x8f0>
    8dac:	52800ba3 	mov	w3, #0x5d                  	// #93
    8db0:	aa1503e1 	mov	x1, x21
    8db4:	aa1403e0 	mov	x0, x20
    8db8:	d2800022 	mov	x2, #0x1                   	// #1
    8dbc:	39001fe3 	strb	w3, [sp, #7]
    8dc0:	17fffddb 	b	852c <fwp_write+0x9c>
    8dc4:	aa1403e0 	mov	x0, x20
    8dc8:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8dcc:	d28000c2 	mov	x2, #0x6                   	// #6
    8dd0:	91352021 	add	x1, x1, #0xd48
    8dd4:	97ffe96f 	bl	3390 <buf_put>
    8dd8:	f9400260 	ldr	x0, [x19]
    8ddc:	b40004c0 	cbz	x0, 8e74 <fwp_write+0x9e4>
    8de0:	910123f5 	add	x21, sp, #0x48
    8de4:	91002276 	add	x22, x19, #0x8
    8de8:	f90143f7 	str	x23, [sp, #640]
    8dec:	d2800017 	mov	x23, #0x0                   	// #0
    8df0:	f90147f8 	str	x24, [sp, #648]
    8df4:	d0000018 	adrp	x24, a000 <fwp_main_thread+0xb80>
    8df8:	91354318 	add	x24, x24, #0xd50
    8dfc:	f9014bf9 	str	x25, [sp, #656]
    8e00:	d0000019 	adrp	x25, a000 <fwp_main_thread+0xb80>
    8e04:	91356339 	add	x25, x25, #0xd58
    8e08:	f9014ffa 	str	x26, [sp, #664]
    8e0c:	14000005 	b	8e20 <fwp_write+0x990>
    8e10:	aa1903e1 	mov	x1, x25
    8e14:	aa1403e0 	mov	x0, x20
    8e18:	d2800042 	mov	x2, #0x2                   	// #2
    8e1c:	97ffe95d 	bl	3390 <buf_put>
    8e20:	38776ac5 	ldrb	w5, [x22, x23]
    8e24:	d2804003 	mov	x3, #0x200                 	// #512
    8e28:	aa1803e4 	mov	x4, x24
    8e2c:	aa0303e1 	mov	x1, x3
    8e30:	52800042 	mov	w2, #0x2                   	// #2
    8e34:	aa1503e0 	mov	x0, x21
    8e38:	910006f7 	add	x23, x23, #0x1
    8e3c:	97ffe649 	bl	2760 <__snprintf_chk@plt>
    8e40:	aa1503e0 	mov	x0, x21
    8e44:	97ffe60f 	bl	2680 <strlen@plt>
    8e48:	aa1503e1 	mov	x1, x21
    8e4c:	aa0003e2 	mov	x2, x0
    8e50:	aa1403e0 	mov	x0, x20
    8e54:	97ffe94f 	bl	3390 <buf_put>
    8e58:	f9400260 	ldr	x0, [x19]
    8e5c:	eb17001f 	cmp	x0, x23
    8e60:	54fffd88 	b.hi	8e10 <fwp_write+0x980>  // b.pmore
    8e64:	f94143f7 	ldr	x23, [sp, #640]
    8e68:	f94147f8 	ldr	x24, [sp, #648]
    8e6c:	f9414bf9 	ldr	x25, [sp, #656]
    8e70:	f9414ffa 	ldr	x26, [sp, #664]
    8e74:	52800ba3 	mov	w3, #0x5d                  	// #93
    8e78:	aa1403e0 	mov	x0, x20
    8e7c:	91001fe1 	add	x1, sp, #0x7
    8e80:	d2800022 	mov	x2, #0x1                   	// #1
    8e84:	39001fe3 	strb	w3, [sp, #7]
    8e88:	17fffda9 	b	852c <fwp_write+0x9c>
    8e8c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8e90:	17fffe44 	b	87a0 <fwp_write+0x310>
    8e94:	f10002ff 	cmp	x23, #0x0
    8e98:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8e9c:	71002c3f 	cmp	w1, #0xb
    8ea0:	54ffebc0 	b.eq	8c18 <fwp_write+0x788>  // b.none
    8ea4:	aa1303e2 	mov	x2, x19
    8ea8:	aa1703e1 	mov	x1, x23
    8eac:	aa1403e0 	mov	x0, x20
    8eb0:	52800003 	mov	w3, #0x0                   	// #0
    8eb4:	97fffd77 	bl	8490 <fwp_write>
    8eb8:	17ffff6a 	b	8c60 <fwp_write+0x7d0>
    8ebc:	aa1403e0 	mov	x0, x20
    8ec0:	91001fe1 	add	x1, sp, #0x7
    8ec4:	52800fa3 	mov	w3, #0x7d                  	// #125
    8ec8:	d2800022 	mov	x2, #0x1                   	// #1
    8ecc:	17fffe38 	b	87ac <fwp_write+0x31c>
    8ed0:	a9400281 	ldp	x1, x0, [x20]
    8ed4:	91000800 	add	x0, x0, #0x2
    8ed8:	8b160000 	add	x0, x0, x22
    8edc:	f9000680 	str	x0, [x20, #8]
    8ee0:	3820683f 	strb	wzr, [x1, x0]
    8ee4:	f9413bf5 	ldr	x21, [sp, #624]
    8ee8:	f9413ff6 	ldr	x22, [sp, #632]
    8eec:	f94153fb 	ldr	x27, [sp, #672]
    8ef0:	f94157fc 	ldr	x28, [sp, #680]
    8ef4:	17fffd93 	b	8540 <fwp_write+0xb0>
    8ef8:	f9400f80 	ldr	x0, [x28, #24]
    8efc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8f00:	aa1b03e0 	mov	x0, x27
    8f04:	97ffe5df 	bl	2680 <strlen@plt>
    8f08:	aa1b03e1 	mov	x1, x27
    8f0c:	aa0003e2 	mov	x2, x0
    8f10:	aa1403e0 	mov	x0, x20
    8f14:	97ffe91f 	bl	3390 <buf_put>
    8f18:	aa1903e1 	mov	x1, x25
    8f1c:	aa1403e0 	mov	x0, x20
    8f20:	d2800062 	mov	x2, #0x3                   	// #3
    8f24:	97ffe91b 	bl	3390 <buf_put>
    8f28:	17fffe10 	b	8768 <fwp_write+0x2d8>
    8f2c:	aa1a03e1 	mov	x1, x26
    8f30:	aa1403e0 	mov	x0, x20
    8f34:	d2800042 	mov	x2, #0x2                   	// #2
    8f38:	97ffe916 	bl	3390 <buf_put>
    8f3c:	17fffe09 	b	8760 <fwp_write+0x2d0>
    8f40:	f9400660 	ldr	x0, [x19, #8]
    8f44:	b4fffb00 	cbz	x0, 8ea4 <fwp_write+0xa14>
    8f48:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8f4c:	9135c021 	add	x1, x1, #0xd70
    8f50:	97ffe648 	bl	2870 <strcmp@plt>
    8f54:	7100001f 	cmp	w0, #0x0
    8f58:	1a9f07e0 	cset	w0, ne	// ne = any
    8f5c:	17ffff2f 	b	8c18 <fwp_write+0x788>
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	d2800042 	mov	x2, #0x2                   	// #2
    8f68:	d0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    8f6c:	9135a021 	add	x1, x1, #0xd68
    8f70:	97ffe908 	bl	3390 <buf_put>
    8f74:	91004261 	add	x1, x19, #0x10
    8f78:	aa1403e0 	mov	x0, x20
    8f7c:	f9402382 	ldr	x2, [x28, #64]
    8f80:	52800003 	mov	w3, #0x0                   	// #0
    8f84:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8f88:	97fffd42 	bl	8490 <fwp_write>
    8f8c:	17fffd9c 	b	85fc <fwp_write+0x16c>
    8f90:	1e22c109 	fcvt	d9, s8
    8f94:	910123f5 	add	x21, sp, #0x48
    8f98:	52800033 	mov	w19, #0x1                   	// #1
    8f9c:	d503201f 	nop
    8fa0:	1e604120 	fmov	d0, d9
    8fa4:	2a1303e1 	mov	w1, w19
    8fa8:	aa1503e0 	mov	x0, x21
    8fac:	97ffea3a 	bl	3894 <fwp_format_g.constprop.0>
    8fb0:	aa1503e0 	mov	x0, x21
    8fb4:	d2800001 	mov	x1, #0x0                   	// #0
    8fb8:	97ffe63a 	bl	28a0 <strtof@plt>
    8fbc:	1e202100 	fcmp	s8, s0
    8fc0:	54ffdb60 	b.eq	8b2c <fwp_write+0x69c>  // b.none
    8fc4:	11000673 	add	w19, w19, #0x1
    8fc8:	71002a7f 	cmp	w19, #0xa
    8fcc:	54fffea1 	b.ne	8fa0 <fwp_write+0xb10>  // b.any
    8fd0:	1e604120 	fmov	d0, d9
    8fd4:	aa1503e0 	mov	x0, x21
    8fd8:	52800121 	mov	w1, #0x9                   	// #9
    8fdc:	97ffea2e 	bl	3894 <fwp_format_g.constprop.0>
    8fe0:	17fffed3 	b	8b2c <fwp_write+0x69c>
    8fe4:	d37ef6a1 	lsl	x1, x21, #2
    8fe8:	b7f81563 	tbnz	x3, #63, 9294 <fwp_write+0xe04>
    8fec:	91002263 	add	x3, x19, #0x8
    8ff0:	8b010061 	add	x1, x3, x1
    8ff4:	b9400023 	ldr	w3, [x1]
    8ff8:	7100081f 	cmp	w0, #0x2
    8ffc:	2a0303e1 	mov	w1, w3
    9000:	93407c63 	sxtw	x3, w3
    9004:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9008:	17fffe5a 	b	8970 <fwp_write+0x4e0>
    900c:	d37ffaa1 	lsl	x1, x21, #1
    9010:	b7f81363 	tbnz	x3, #63, 927c <fwp_write+0xdec>
    9014:	91002263 	add	x3, x19, #0x8
    9018:	8b010061 	add	x1, x3, x1
    901c:	79400021 	ldrh	w1, [x1]
    9020:	7100041f 	cmp	w0, #0x1
    9024:	93403c23 	sxth	x3, w1
    9028:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    902c:	17fffe51 	b	8970 <fwp_write+0x4e0>
    9030:	52800443 	mov	w3, #0x22                  	// #34
    9034:	91001ff5 	add	x21, sp, #0x7
    9038:	91002273 	add	x19, x19, #0x8
    903c:	aa1503e1 	mov	x1, x21
    9040:	aa1403e0 	mov	x0, x20
    9044:	d2800022 	mov	x2, #0x1                   	// #1
    9048:	39001fe3 	strb	w3, [sp, #7]
    904c:	f90143f7 	str	x23, [sp, #640]
    9050:	8b160277 	add	x23, x19, x22
    9054:	f90147f8 	str	x24, [sp, #648]
    9058:	97ffe8ce 	bl	3390 <buf_put>
    905c:	b4000696 	cbz	x22, 912c <fwp_write+0xc9c>
    9060:	b0000018 	adrp	x24, a000 <fwp_main_thread+0xb80>
    9064:	91346318 	add	x24, x24, #0xd18
    9068:	f9014bf9 	str	x25, [sp, #656]
    906c:	b0000019 	adrp	x25, a000 <fwp_main_thread+0xb80>
    9070:	9134e339 	add	x25, x25, #0xd38
    9074:	f9014ffa 	str	x26, [sp, #664]
    9078:	1400000d 	b	90ac <fwp_write+0xc1c>
    907c:	710024bf 	cmp	w5, #0x9
    9080:	54000460 	b.eq	910c <fwp_write+0xc7c>  // b.none
    9084:	710028bf 	cmp	w5, #0xa
    9088:	54000a61 	b.ne	91d4 <fwp_write+0xd44>  // b.any
    908c:	b0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    9090:	aa1403e0 	mov	x0, x20
    9094:	9134a021 	add	x1, x1, #0xd28
    9098:	d2800042 	mov	x2, #0x2                   	// #2
    909c:	97ffe8bd 	bl	3390 <buf_put>
    90a0:	91000673 	add	x19, x19, #0x1
    90a4:	eb17027f 	cmp	x19, x23
    90a8:	540003e0 	b.eq	9124 <fwp_write+0xc94>  // b.none
    90ac:	39400265 	ldrb	w5, [x19]
    90b0:	710034bf 	cmp	w5, #0xd
    90b4:	54000180 	b.eq	90e4 <fwp_write+0xc54>  // b.none
    90b8:	54fffe29 	b.ls	907c <fwp_write+0xbec>  // b.plast
    90bc:	710088bf 	cmp	w5, #0x22
    90c0:	540001c0 	b.eq	90f8 <fwp_write+0xc68>  // b.none
    90c4:	710170bf 	cmp	w5, #0x5c
    90c8:	54000741 	b.ne	91b0 <fwp_write+0xd20>  // b.any
    90cc:	aa1403e0 	mov	x0, x20
    90d0:	b0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    90d4:	d2800042 	mov	x2, #0x2                   	// #2
    90d8:	91348021 	add	x1, x1, #0xd20
    90dc:	97ffe8ad 	bl	3390 <buf_put>
    90e0:	17fffff0 	b	90a0 <fwp_write+0xc10>
    90e4:	aa1903e1 	mov	x1, x25
    90e8:	aa1403e0 	mov	x0, x20
    90ec:	d2800042 	mov	x2, #0x2                   	// #2
    90f0:	97ffe8a8 	bl	3390 <buf_put>
    90f4:	17ffffeb 	b	90a0 <fwp_write+0xc10>
    90f8:	aa1803e1 	mov	x1, x24
    90fc:	aa1403e0 	mov	x0, x20
    9100:	d2800042 	mov	x2, #0x2                   	// #2
    9104:	97ffe8a3 	bl	3390 <buf_put>
    9108:	17ffffe6 	b	90a0 <fwp_write+0xc10>
    910c:	aa1403e0 	mov	x0, x20
    9110:	b0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    9114:	d2800042 	mov	x2, #0x2                   	// #2
    9118:	9134c021 	add	x1, x1, #0xd30
    911c:	97ffe89d 	bl	3390 <buf_put>
    9120:	17ffffe0 	b	90a0 <fwp_write+0xc10>
    9124:	f9414bf9 	ldr	x25, [sp, #656]
    9128:	f9414ffa 	ldr	x26, [sp, #664]
    912c:	aa1503e1 	mov	x1, x21
    9130:	aa1403e0 	mov	x0, x20
    9134:	52800443 	mov	w3, #0x22                  	// #34
    9138:	17fffd9c 	b	87a8 <fwp_write+0x318>
    913c:	7100103f 	cmp	w1, #0x4
    9140:	54ffeb21 	b.ne	8ea4 <fwp_write+0xa14>  // b.any
    9144:	f94006e0 	ldr	x0, [x23, #8]
    9148:	d37ffc00 	lsr	x0, x0, #63
    914c:	17fffeb3 	b	8c18 <fwp_write+0x788>
    9150:	710002ff 	cmp	w23, #0x0
    9154:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9158:	17fffeb0 	b	8c18 <fwp_write+0x788>
    915c:	528005a1 	mov	w1, #0x2d                  	// #45
    9160:	eb0203e2 	negs	x2, x2
    9164:	da0303e3 	ngc	x3, x3
    9168:	910127e0 	add	x0, sp, #0x49
    916c:	910123f5 	add	x21, sp, #0x48
    9170:	390123e1 	strb	w1, [sp, #72]
    9174:	97ffe70b 	bl	2da0 <fwp_fmt_u128>
    9178:	17fffe18 	b	89d8 <fwp_write+0x548>
    917c:	d37ceea1 	lsl	x1, x21, #4
    9180:	b7f810a3 	tbnz	x3, #63, 9394 <fwp_write+0xf04>
    9184:	91002260 	add	x0, x19, #0x8
    9188:	8b010001 	add	x1, x0, x1
    918c:	17fffdf9 	b	8970 <fwp_write+0x4e0>
    9190:	f9400a61 	ldr	x1, [x19, #16]
    9194:	8b010000 	add	x0, x0, x1
    9198:	f9400001 	ldr	x1, [x0]
    919c:	17fffdf5 	b	8970 <fwp_write+0x4e0>
    91a0:	b0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    91a4:	d2800042 	mov	x2, #0x2                   	// #2
    91a8:	91330021 	add	x1, x1, #0xcc0
    91ac:	17fffed6 	b	8d04 <fwp_write+0x874>
    91b0:	7101fcbf 	cmp	w5, #0x7f
    91b4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    91b8:	540000e9 	b.ls	91d4 <fwp_write+0xd44>  // b.plast
    91bc:	aa1503e1 	mov	x1, x21
    91c0:	aa1403e0 	mov	x0, x20
    91c4:	d2800022 	mov	x2, #0x1                   	// #1
    91c8:	39001fe5 	strb	w5, [sp, #7]
    91cc:	97ffe871 	bl	3390 <buf_put>
    91d0:	17ffffb4 	b	90a0 <fwp_write+0xc10>
    91d4:	d2800203 	mov	x3, #0x10                  	// #16
    91d8:	b0000004 	adrp	x4, a000 <fwp_main_thread+0xb80>
    91dc:	aa0303e1 	mov	x1, x3
    91e0:	91350084 	add	x4, x4, #0xd40
    91e4:	910123f6 	add	x22, sp, #0x48
    91e8:	52800042 	mov	w2, #0x2                   	// #2
    91ec:	aa1603e0 	mov	x0, x22
    91f0:	97ffe55c 	bl	2760 <__snprintf_chk@plt>
    91f4:	aa1603e0 	mov	x0, x22
    91f8:	97ffe522 	bl	2680 <strlen@plt>
    91fc:	aa1603e1 	mov	x1, x22
    9200:	aa0003e2 	mov	x2, x0
    9204:	aa1403e0 	mov	x0, x20
    9208:	97ffe862 	bl	3390 <buf_put>
    920c:	17ffffa5 	b	90a0 <fwp_write+0xc10>
    9210:	1e604100 	fmov	d0, d8
    9214:	aa1503e0 	mov	x0, x21
    9218:	52800221 	mov	w1, #0x11                  	// #17
    921c:	97ffe99e 	bl	3894 <fwp_format_g.constprop.0>
    9220:	17fffe43 	b	8b2c <fwp_write+0x69c>
    9224:	b9401040 	ldr	w0, [x2, #16]
    9228:	350003c0 	cbnz	w0, 92a0 <fwp_write+0xe10>
    922c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9230:	f947f400 	ldr	x0, [x0, #4072]
    9234:	f94127e2 	ldr	x2, [sp, #584]
    9238:	f9400001 	ldr	x1, [x0]
    923c:	eb010042 	subs	x2, x2, x1
    9240:	d2800001 	mov	x1, #0x0                   	// #0
    9244:	54ffd721 	b.ne	8d28 <fwp_write+0x898>  // b.any
    9248:	f9413bf5 	ldr	x21, [sp, #624]
    924c:	b0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    9250:	f9413ff6 	ldr	x22, [sp, #632]
    9254:	aa1403e0 	mov	x0, x20
    9258:	f94143f7 	ldr	x23, [sp, #640]
    925c:	91364021 	add	x1, x1, #0xd90
    9260:	f94147f8 	ldr	x24, [sp, #648]
    9264:	d2800042 	mov	x2, #0x2                   	// #2
    9268:	17fffd0e 	b	86a0 <fwp_write+0x210>
    926c:	b0000001 	adrp	x1, a000 <fwp_main_thread+0xb80>
    9270:	d2800042 	mov	x2, #0x2                   	// #2
    9274:	91332021 	add	x1, x1, #0xcc8
    9278:	17fffea3 	b	8d04 <fwp_write+0x874>
    927c:	f9400a63 	ldr	x3, [x19, #16]
    9280:	8b030021 	add	x1, x1, x3
    9284:	17ffff66 	b	901c <fwp_write+0xb8c>
    9288:	f9400a61 	ldr	x1, [x19, #16]
    928c:	8b0102a1 	add	x1, x21, x1
    9290:	17fffdb3 	b	895c <fwp_write+0x4cc>
    9294:	f9400a63 	ldr	x3, [x19, #16]
    9298:	8b030021 	add	x1, x1, x3
    929c:	17ffff56 	b	8ff4 <fwp_write+0xb64>
    92a0:	b9404840 	ldr	w0, [x2, #72]
    92a4:	91001ff5 	add	x21, sp, #0x7
    92a8:	34ffa360 	cbz	w0, 8714 <fwp_write+0x284>
    92ac:	52800503 	mov	w3, #0x28                  	// #40
    92b0:	aa1403e0 	mov	x0, x20
    92b4:	aa1503e1 	mov	x1, x21
    92b8:	d2800022 	mov	x2, #0x1                   	// #1
    92bc:	39001fe3 	strb	w3, [sp, #7]
    92c0:	97ffe834 	bl	3390 <buf_put>
    92c4:	b9401380 	ldr	w0, [x28, #16]
    92c8:	52800038 	mov	w24, #0x1                   	// #1
    92cc:	7100001f 	cmp	w0, #0x0
    92d0:	54ffa36c 	b.gt	873c <fwp_write+0x2ac>
    92d4:	17fffd32 	b	879c <fwp_write+0x30c>
    92d8:	f9014bf9 	str	x25, [sp, #656]
    92dc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x11738>
    92e0:	f9014ffa 	str	x26, [sp, #664]
    92e4:	f9400676 	ldr	x22, [x19, #8]
    92e8:	91102333 	add	x19, x25, #0x408
    92ec:	91002273 	add	x19, x19, #0x8
    92f0:	937ffed8 	asr	x24, x22, #63
    92f4:	aa1802c0 	orr	x0, x22, x24
    92f8:	b5000320 	cbnz	x0, 935c <fwp_write+0xecc>
    92fc:	110006b5 	add	w21, w21, #0x1
    9300:	710016bf 	cmp	w21, #0x5
    9304:	54ffffc1 	b.ne	92fc <fwp_write+0xe6c>  // b.any
    9308:	b7f80578 	tbnz	x24, #63, 93b4 <fwp_write+0xf24>
    930c:	910023f3 	add	x19, sp, #0x8
    9310:	aa1603e2 	mov	x2, x22
    9314:	aa1303e0 	mov	x0, x19
    9318:	d2800003 	mov	x3, #0x0                   	// #0
    931c:	97ffe6a1 	bl	2da0 <fwp_fmt_u128>
    9320:	910123f5 	add	x21, sp, #0x48
    9324:	b0000003 	adrp	x3, a000 <fwp_main_thread+0xb80>
    9328:	aa1303e4 	mov	x4, x19
    932c:	aa1503e0 	mov	x0, x21
    9330:	91362063 	add	x3, x3, #0xd88
    9334:	d2804002 	mov	x2, #0x200                 	// #512
    9338:	52800041 	mov	w1, #0x2                   	// #2
    933c:	97ffe4d5 	bl	2690 <__sprintf_chk@plt>
    9340:	aa1503e0 	mov	x0, x21
    9344:	97ffe4cf 	bl	2680 <strlen@plt>
    9348:	aa1503e1 	mov	x1, x21
    934c:	aa0003e2 	mov	x2, x0
    9350:	aa1403e0 	mov	x0, x20
    9354:	97ffe80f 	bl	3390 <buf_put>
    9358:	17fffe47 	b	8c74 <fwp_write+0x7e4>
    935c:	f9400277 	ldr	x23, [x19]
    9360:	aa1603e0 	mov	x0, x22
    9364:	aa1803e1 	mov	x1, x24
    9368:	aa1703e2 	mov	x2, x23
    936c:	937ffefa 	asr	x26, x23, #63
    9370:	aa1a03e3 	mov	x3, x26
    9374:	9400043b 	bl	a460 <__modti3>
    9378:	aa010000 	orr	x0, x0, x1
    937c:	b40002c0 	cbz	x0, 93d4 <fwp_write+0xf44>
    9380:	110006b5 	add	w21, w21, #0x1
    9384:	91004273 	add	x19, x19, #0x10
    9388:	710016bf 	cmp	w21, #0x5
    938c:	54fffe81 	b.ne	935c <fwp_write+0xecc>  // b.any
    9390:	17ffffde 	b	9308 <fwp_write+0xe78>
    9394:	f9400a60 	ldr	x0, [x19, #16]
    9398:	8b000021 	add	x1, x1, x0
    939c:	17fffd75 	b	8970 <fwp_write+0x4e0>
    93a0:	528c29c0 	mov	w0, #0x614e                	// #24910
    93a4:	910123f5 	add	x21, sp, #0x48
    93a8:	72a009c0 	movk	w0, #0x4e, lsl #16
    93ac:	b9004be0 	str	w0, [sp, #72]
    93b0:	17fffda2 	b	8a38 <fwp_write+0x5a8>
    93b4:	528005a1 	mov	w1, #0x2d                  	// #45
    93b8:	eb1603e2 	negs	x2, x22
    93bc:	da1803e3 	ngc	x3, x24
    93c0:	910027e0 	add	x0, sp, #0x9
    93c4:	910023f3 	add	x19, sp, #0x8
    93c8:	390023e1 	strb	w1, [sp, #8]
    93cc:	97ffe675 	bl	2da0 <fwp_fmt_u128>
    93d0:	17ffffd4 	b	9320 <fwp_write+0xe90>
    93d4:	aa1703e2 	mov	x2, x23
    93d8:	aa1a03e3 	mov	x3, x26
    93dc:	aa1603e0 	mov	x0, x22
    93e0:	aa1803e1 	mov	x1, x24
    93e4:	9400033f 	bl	a0e0 <__divti3>
    93e8:	aa0003e2 	mov	x2, x0
    93ec:	aa0103e3 	mov	x3, x1
    93f0:	b7f80201 	tbnz	x1, #63, 9430 <fwp_write+0xfa0>
    93f4:	910023f3 	add	x19, sp, #0x8
    93f8:	aa1303e0 	mov	x0, x19
    93fc:	97ffe669 	bl	2da0 <fwp_fmt_u128>
    9400:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9404:	91102339 	add	x25, x25, #0x408
    9408:	910123f5 	add	x21, sp, #0x48
    940c:	aa1303e4 	mov	x4, x19
    9410:	aa1503e0 	mov	x0, x21
    9414:	b0000003 	adrp	x3, a000 <fwp_main_thread+0xb80>
    9418:	f8616b25 	ldr	x5, [x25, x1]
    941c:	91360063 	add	x3, x3, #0xd80
    9420:	d2804002 	mov	x2, #0x200                 	// #512
    9424:	52800041 	mov	w1, #0x2                   	// #2
    9428:	97ffe49a 	bl	2690 <__sprintf_chk@plt>
    942c:	17ffffc5 	b	9340 <fwp_write+0xeb0>
    9430:	528005a4 	mov	w4, #0x2d                  	// #45
    9434:	eb0003e2 	negs	x2, x0
    9438:	da0103e3 	ngc	x3, x1
    943c:	910027e0 	add	x0, sp, #0x9
    9440:	910023f3 	add	x19, sp, #0x8
    9444:	390023e4 	strb	w4, [sp, #8]
    9448:	97ffe656 	bl	2da0 <fwp_fmt_u128>
    944c:	17ffffed 	b	9400 <fwp_write+0xf70>
    9450:	f9013bf5 	str	x21, [sp, #624]
    9454:	f9013ff6 	str	x22, [sp, #632]
    9458:	f90143f7 	str	x23, [sp, #640]
    945c:	f90147f8 	str	x24, [sp, #648]
    9460:	f9014bf9 	str	x25, [sp, #656]
    9464:	f9014ffa 	str	x26, [sp, #664]
    9468:	f90153fb 	str	x27, [sp, #672]
    946c:	f90157fc 	str	x28, [sp, #680]
    9470:	fd015be8 	str	d8, [sp, #688]
    9474:	fd015fe9 	str	d9, [sp, #696]
    9478:	97ffe4de 	bl	27f0 <__stack_chk_fail@plt>
    947c:	d503201f 	nop

0000000000009480 <fwp_main_thread>:
    9480:	d10643ff 	sub	sp, sp, #0x190
    9484:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9488:	f947f400 	ldr	x0, [x0, #4072]
    948c:	a9127bfd 	stp	x29, x30, [sp, #288]
    9490:	910483fd 	add	x29, sp, #0x120
    9494:	a9145bf5 	stp	x21, x22, [sp, #320]
    9498:	90000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    949c:	911502c1 	add	x1, x22, #0x540
    94a0:	a91353f3 	stp	x19, x20, [sp, #304]
    94a4:	a91773fb 	stp	x27, x28, [sp, #368]
    94a8:	b953a421 	ldr	w1, [x1, #5028]
    94ac:	f9400002 	ldr	x2, [x0]
    94b0:	f9008fe2 	str	x2, [sp, #280]
    94b4:	d2800002 	mov	x2, #0x0                   	// #0
    94b8:	340025e1 	cbz	w1, 9974 <fwp_main_thread+0x4f4>
    94bc:	911502c0 	add	x0, x22, #0x540
    94c0:	b953a800 	ldr	w0, [x0, #5032]
    94c4:	35002500 	cbnz	w0, 9964 <fwp_main_thread+0x4e4>
    94c8:	f00000b5 	adrp	x21, 20000 <__data_start>
    94cc:	f00000a2 	adrp	x2, 20000 <__data_start>
    94d0:	9100c2bc 	add	x28, x21, #0x30
    94d4:	910d8042 	add	x2, x2, #0x360
    94d8:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    94dc:	d2a00024 	mov	x4, #0x10000               	// #65536
    94e0:	910103e0 	add	x0, sp, #0x40
    94e4:	9100a3f3 	add	x19, sp, #0x28
    94e8:	d2800001 	mov	x1, #0x0                   	// #0
    94ec:	f9000be0 	str	x0, [sp, #16]
    94f0:	a9018f93 	stp	x19, x3, [x28, #24]
    94f4:	f90023e2 	str	x2, [sp, #64]
    94f8:	b9004bff 	str	wzr, [sp, #72]
    94fc:	f9002be4 	str	x4, [sp, #80]
    9500:	97ffe454 	bl	2650 <sigaltstack@plt>
    9504:	35005d00 	cbnz	w0, a0a4 <fwp_main_thread+0xc24>
    9508:	4f000400 	movi	v0.4s, #0x0
    950c:	910223e0 	add	x0, sp, #0x88
    9510:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9514:	913fc021 	add	x1, x1, #0xff0
    9518:	f90043e1 	str	x1, [sp, #128]
    951c:	52800082 	mov	w2, #0x4                   	// #4
    9520:	72a10002 	movk	w2, #0x800, lsl #16
    9524:	910203f4 	add	x20, sp, #0x80
    9528:	3d802000 	str	q0, [x0, #128]
    952c:	b9010be2 	str	w2, [sp, #264]
    9530:	f9000ff4 	str	x20, [sp, #24]
    9534:	ad000000 	stp	q0, q0, [x0]
    9538:	ad010000 	stp	q0, q0, [x0, #32]
    953c:	ad020000 	stp	q0, q0, [x0, #64]
    9540:	ad030000 	stp	q0, q0, [x0, #96]
    9544:	97ffe49b 	bl	27b0 <sigemptyset@plt>
    9548:	35005ae0 	cbnz	w0, a0a4 <fwp_main_thread+0xc24>
    954c:	aa1403e1 	mov	x1, x20
    9550:	d2800002 	mov	x2, #0x0                   	// #0
    9554:	52800160 	mov	w0, #0xb                   	// #11
    9558:	97ffe4ae 	bl	2810 <sigaction@plt>
    955c:	35005a40 	cbnz	w0, a0a4 <fwp_main_thread+0xc24>
    9560:	aa1403e1 	mov	x1, x20
    9564:	d2800002 	mov	x2, #0x0                   	// #0
    9568:	528000e0 	mov	w0, #0x7                   	// #7
    956c:	97ffe4a9 	bl	2810 <sigaction@plt>
    9570:	350059a0 	cbnz	w0, a0a4 <fwp_main_thread+0xc24>
    9574:	b942fb80 	ldr	w0, [x28, #760]
    9578:	a91563f7 	stp	x23, x24, [sp, #336]
    957c:	34002000 	cbz	w0, 997c <fwp_main_thread+0x4fc>
    9580:	9100c2b6 	add	x22, x21, #0x30
    9584:	f9400ad4 	ldr	x20, [x22, #16]
    9588:	b4000c14 	cbz	x20, 9708 <fwp_main_thread+0x288>
    958c:	aa1403f3 	mov	x19, x20
    9590:	91010298 	add	x24, x20, #0x40
    9594:	a9166bf9 	stp	x25, x26, [sp, #352]
    9598:	52800037 	mov	w23, #0x1                   	// #1
    959c:	39414a99 	ldrb	w25, [x20, #82]
    95a0:	39014a97 	strb	w23, [x20, #82]
    95a4:	f9401680 	ldr	x0, [x20, #40]
    95a8:	b4000620 	cbz	x0, 966c <fwp_main_thread+0x1ec>
    95ac:	f9403281 	ldr	x1, [x20, #96]
    95b0:	39414680 	ldrb	w0, [x20, #81]
    95b4:	b4000e41 	cbz	x1, 977c <fwp_main_thread+0x2fc>
    95b8:	36000d00 	tbz	w0, #0, 9758 <fwp_main_thread+0x2d8>
    95bc:	39414a62 	ldrb	w2, [x19, #82]
    95c0:	f9402281 	ldr	x1, [x20, #64]
    95c4:	37001042 	tbnz	w2, #0, 97cc <fwp_main_thread+0x34c>
    95c8:	f9403260 	ldr	x0, [x19, #96]
    95cc:	a911fe78 	stp	x24, xzr, [x19, #280]
    95d0:	f9009661 	str	x1, [x19, #296]
    95d4:	b4000041 	cbz	x1, 95dc <fwp_main_thread+0x15c>
    95d8:	f9009033 	str	x19, [x1, #288]
    95dc:	f9002293 	str	x19, [x20, #64]
    95e0:	b4000100 	cbz	x0, 9600 <fwp_main_thread+0x180>
    95e4:	f94046c1 	ldr	x1, [x22, #136]
    95e8:	39015677 	strb	w23, [x19, #85]
    95ec:	f9003660 	str	x0, [x19, #104]
    95f0:	a910867f 	stp	xzr, x1, [x19, #264]
    95f4:	b4000041 	cbz	x1, 95fc <fwp_main_thread+0x17c>
    95f8:	f9008433 	str	x19, [x1, #264]
    95fc:	f90046d3 	str	x19, [x22, #136]
    9600:	39015a7f 	strb	wzr, [x19, #86]
    9604:	97fff2a8 	bl	60a4 <fwp_block>
    9608:	f9408e62 	ldr	x2, [x19, #280]
    960c:	b4000142 	cbz	x2, 9634 <fwp_main_thread+0x1b4>
    9610:	a9520261 	ldp	x1, x0, [x19, #288]
    9614:	b4000e81 	cbz	x1, 97e4 <fwp_main_thread+0x364>
    9618:	f9009420 	str	x0, [x1, #296]
    961c:	f9409660 	ldr	x0, [x19, #296]
    9620:	b4000040 	cbz	x0, 9628 <fwp_main_thread+0x1a8>
    9624:	f9009001 	str	x1, [x0, #288]
    9628:	91080260 	add	x0, x19, #0x200
    962c:	f900967f 	str	xzr, [x19, #296]
    9630:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9634:	39415660 	ldrb	w0, [x19, #85]
    9638:	f9400ac1 	ldr	x1, [x22, #16]
    963c:	36000c40 	tbz	w0, #0, 97c4 <fwp_main_thread+0x344>
    9640:	a9508262 	ldp	x2, x0, [x19, #264]
    9644:	b4000d42 	cbz	x2, 97ec <fwp_main_thread+0x36c>
    9648:	f9008840 	str	x0, [x2, #272]
    964c:	b4000040 	cbz	x0, 9654 <fwp_main_thread+0x1d4>
    9650:	f9008402 	str	x2, [x0, #264]
    9654:	91080260 	add	x0, x19, #0x200
    9658:	3901567f 	strb	wzr, [x19, #85]
    965c:	aa0103f3 	mov	x19, x1
    9660:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9664:	f9401680 	ldr	x0, [x20, #40]
    9668:	b5fffa20 	cbnz	x0, 95ac <fwp_main_thread+0x12c>
    966c:	9100c2a0 	add	x0, x21, #0x30
    9670:	39014a99 	strb	w25, [x20, #82]
    9674:	a9566bf9 	ldp	x25, x26, [sp, #352]
    9678:	f9416c00 	ldr	x0, [x0, #728]
    967c:	b40004c0 	cbz	x0, 9714 <fwp_main_thread+0x294>
    9680:	9100c2a0 	add	x0, x21, #0x30
    9684:	f9418801 	ldr	x1, [x0, #784]
    9688:	b903081f 	str	wzr, [x0, #776]
    968c:	eb13003f 	cmp	x1, x19
    9690:	540005e1 	b.ne	974c <fwp_main_thread+0x2cc>  // b.any
    9694:	b4000bb3 	cbz	x19, 9808 <fwp_main_thread+0x388>
    9698:	9100c2a0 	add	x0, x21, #0x30
    969c:	52800021 	mov	w1, #0x1                   	// #1
    96a0:	39014a61 	strb	w1, [x19, #82]
    96a4:	f9415805 	ldr	x5, [x0, #688]
    96a8:	b4000b05 	cbz	x5, 9808 <fwp_main_thread+0x388>
    96ac:	394140a0 	ldrb	w0, [x5, #80]
    96b0:	37000060 	tbnz	w0, #0, 96bc <fwp_main_thread+0x23c>
    96b4:	aa0503e0 	mov	x0, x5
    96b8:	97ffe74e 	bl	33f0 <fwp_cancel_tree.part.0>
    96bc:	f9409ca5 	ldr	x5, [x5, #312]
    96c0:	b5ffff65 	cbnz	x5, 96ac <fwp_main_thread+0x22c>
    96c4:	9100c2b4 	add	x20, x21, #0x30
    96c8:	52800036 	mov	w22, #0x1                   	// #1
    96cc:	f9402a60 	ldr	x0, [x19, #80]
    96d0:	f2001c1f 	tst	x0, #0xff000000ff
    96d4:	540000e1 	b.ne	96f0 <fwp_main_thread+0x270>  // b.any
    96d8:	f9401680 	ldr	x0, [x20, #40]
    96dc:	39015276 	strb	w22, [x19, #84]
    96e0:	f900827f 	str	xzr, [x19, #256]
    96e4:	b4000880 	cbz	x0, 97f4 <fwp_main_thread+0x374>
    96e8:	f9008013 	str	x19, [x0, #256]
    96ec:	f9001693 	str	x19, [x20, #40]
    96f0:	97fff26d 	bl	60a4 <fwp_block>
    96f4:	97fff1ff 	bl	5ef0 <fwp_free_zombie>
    96f8:	f9415a80 	ldr	x0, [x20, #688]
    96fc:	b4000860 	cbz	x0, 9808 <fwp_main_thread+0x388>
    9700:	f9418a93 	ldr	x19, [x20, #784]
    9704:	17fffff2 	b	96cc <fwp_main_thread+0x24c>
    9708:	f9416ec0 	ldr	x0, [x22, #728]
    970c:	b5000780 	cbnz	x0, 97fc <fwp_main_thread+0x37c>
    9710:	d2800013 	mov	x19, #0x0                   	// #0
    9714:	9100c2b4 	add	x20, x21, #0x30
    9718:	f9417680 	ldr	x0, [x20, #744]
    971c:	b5fffb20 	cbnz	x0, 9680 <fwp_main_thread+0x200>
    9720:	f9416a80 	ldr	x0, [x20, #720]
    9724:	97ffec13 	bl	4770 <fwp_mem_free>
    9728:	f9016a9f 	str	xzr, [x20, #720]
    972c:	f901729f 	str	xzr, [x20, #736]
    9730:	f9418a80 	ldr	x0, [x20, #784]
    9734:	b40047b3 	cbz	x19, a028 <fwp_main_thread+0xba8>
    9738:	f900567f 	str	xzr, [x19, #168]
    973c:	f9005e7f 	str	xzr, [x19, #184]
    9740:	b9030a9f 	str	wzr, [x20, #776]
    9744:	eb13001f 	cmp	x0, x19
    9748:	54fffa80 	b.eq	9698 <fwp_main_thread+0x218>  // b.none
    974c:	a9166bf9 	stp	x25, x26, [sp, #352]
    9750:	fd00c3e8 	str	d8, [sp, #384]
    9754:	97ffe43b 	bl	2840 <abort@plt>
    9758:	97ffe7ca 	bl	3680 <fwp_now_ns>
    975c:	f9403281 	ldr	x1, [x20, #96]
    9760:	eb01001f 	cmp	x0, x1
    9764:	540000ab 	b.lt	9778 <fwp_main_thread+0x2f8>  // b.tstop
    9768:	39414280 	ldrb	w0, [x20, #80]
    976c:	37000060 	tbnz	w0, #0, 9778 <fwp_main_thread+0x2f8>
    9770:	aa1403e0 	mov	x0, x20
    9774:	97ffe71f 	bl	33f0 <fwp_cancel_tree.part.0>
    9778:	39414680 	ldrb	w0, [x20, #81]
    977c:	39414a62 	ldrb	w2, [x19, #82]
    9780:	3707f200 	tbnz	w0, #0, 95c0 <fwp_main_thread+0x140>
    9784:	f9403280 	ldr	x0, [x20, #96]
    9788:	370001a2 	tbnz	w2, #0, 97bc <fwp_main_thread+0x33c>
    978c:	f9403261 	ldr	x1, [x19, #96]
    9790:	b4000161 	cbz	x1, 97bc <fwp_main_thread+0x33c>
    9794:	b4003940 	cbz	x0, 9ebc <fwp_main_thread+0xa3c>
    9798:	eb01001f 	cmp	x0, x1
    979c:	9a81d000 	csel	x0, x0, x1, le
    97a0:	f9402281 	ldr	x1, [x20, #64]
    97a4:	a911fe78 	stp	x24, xzr, [x19, #280]
    97a8:	f9009661 	str	x1, [x19, #296]
    97ac:	b4000041 	cbz	x1, 97b4 <fwp_main_thread+0x334>
    97b0:	f9009033 	str	x19, [x1, #288]
    97b4:	f9002293 	str	x19, [x20, #64]
    97b8:	17ffff8b 	b	95e4 <fwp_main_thread+0x164>
    97bc:	f9402281 	ldr	x1, [x20, #64]
    97c0:	17ffff83 	b	95cc <fwp_main_thread+0x14c>
    97c4:	aa0103f3 	mov	x19, x1
    97c8:	17ffff77 	b	95a4 <fwp_main_thread+0x124>
    97cc:	a911fe78 	stp	x24, xzr, [x19, #280]
    97d0:	f9009661 	str	x1, [x19, #296]
    97d4:	b4000041 	cbz	x1, 97dc <fwp_main_thread+0x35c>
    97d8:	f9009033 	str	x19, [x1, #288]
    97dc:	f9002293 	str	x19, [x20, #64]
    97e0:	17ffff88 	b	9600 <fwp_main_thread+0x180>
    97e4:	f9000040 	str	x0, [x2]
    97e8:	17ffff8e 	b	9620 <fwp_main_thread+0x1a0>
    97ec:	f90046c0 	str	x0, [x22, #136]
    97f0:	17ffff97 	b	964c <fwp_main_thread+0x1cc>
    97f4:	f9001a93 	str	x19, [x20, #48]
    97f8:	17ffffbd 	b	96ec <fwp_main_thread+0x26c>
    97fc:	f9418ac0 	ldr	x0, [x22, #784]
    9800:	b9030adf 	str	wzr, [x22, #776]
    9804:	b5fffa40 	cbnz	x0, 974c <fwp_main_thread+0x2cc>
    9808:	9100c2b6 	add	x22, x21, #0x30
    980c:	97fff1b9 	bl	5ef0 <fwp_free_zombie>
    9810:	f9401ac0 	ldr	x0, [x22, #48]
    9814:	b5fff9c0 	cbnz	x0, 974c <fwp_main_thread+0x2cc>
    9818:	f94046c0 	ldr	x0, [x22, #136]
    981c:	b5fff980 	cbnz	x0, 974c <fwp_main_thread+0x2cc>
    9820:	b940aac0 	ldr	w0, [x22, #168]
    9824:	340001c0 	cbz	w0, 985c <fwp_main_thread+0x3dc>
    9828:	93407c14 	sxtw	x20, w0
    982c:	51000400 	sub	w0, w0, #0x1
    9830:	d1000a94 	sub	x20, x20, #0x2
    9834:	9102c2d7 	add	x23, x22, #0xb0
    9838:	cb204294 	sub	x20, x20, w0, uxtw
    983c:	93407c13 	sxtw	x19, w0
    9840:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    9844:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9848:	b900aad3 	str	w19, [x22, #168]
    984c:	d1000673 	sub	x19, x19, #0x1
    9850:	97ffe430 	bl	2910 <munmap@plt>
    9854:	eb14027f 	cmp	x19, x20
    9858:	54ffff41 	b.ne	9840 <fwp_main_thread+0x3c0>  // b.any
    985c:	f00000b3 	adrp	x19, 20000 <__data_start>
    9860:	91004260 	add	x0, x19, #0x10
    9864:	b9400800 	ldr	w0, [x0, #8]
    9868:	37f80040 	tbnz	w0, #31, 9870 <fwp_main_thread+0x3f0>
    986c:	97ffe3e5 	bl	2800 <close@plt>
    9870:	9100c2a0 	add	x0, x21, #0x30
    9874:	91004261 	add	x1, x19, #0x10
    9878:	12800002 	mov	w2, #0xffffffff            	// #-1
    987c:	d2800013 	mov	x19, #0x0                   	// #0
    9880:	f9418c16 	ldr	x22, [x0, #792]
    9884:	b9000822 	str	w2, [x1, #8]
    9888:	f9419014 	ldr	x20, [x0, #800]
    988c:	b4000176 	cbz	x22, 98b8 <fwp_main_thread+0x438>
    9890:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    9894:	b40000c0 	cbz	x0, 98ac <fwp_main_thread+0x42c>
    9898:	f9400001 	ldr	x1, [x0]
    989c:	b5fff581 	cbnz	x1, 974c <fwp_main_thread+0x2cc>
    98a0:	f9400401 	ldr	x1, [x0, #8]
    98a4:	b5fff541 	cbnz	x1, 974c <fwp_main_thread+0x2cc>
    98a8:	97ffebb2 	bl	4770 <fwp_mem_free>
    98ac:	91000673 	add	x19, x19, #0x1
    98b0:	eb16027f 	cmp	x19, x22
    98b4:	54fffee1 	b.ne	9890 <fwp_main_thread+0x410>  // b.any
    98b8:	aa1403e0 	mov	x0, x20
    98bc:	97ffebad 	bl	4770 <fwp_mem_free>
    98c0:	9100c2a0 	add	x0, x21, #0x30
    98c4:	f9418813 	ldr	x19, [x0, #784]
    98c8:	f9018c1f 	str	xzr, [x0, #792]
    98cc:	f901901f 	str	xzr, [x0, #800]
    98d0:	b40001f3 	cbz	x19, 990c <fwp_main_thread+0x48c>
    98d4:	f9401661 	ldr	x1, [x19, #40]
    98d8:	b5fff3a1 	cbnz	x1, 974c <fwp_main_thread+0x2cc>
    98dc:	f9405661 	ldr	x1, [x19, #168]
    98e0:	b5fff361 	cbnz	x1, 974c <fwp_main_thread+0x2cc>
    98e4:	f9416c01 	ldr	x1, [x0, #728]
    98e8:	b5fff321 	cbnz	x1, 974c <fwp_main_thread+0x2cc>
    98ec:	f9417400 	ldr	x0, [x0, #744]
    98f0:	b5fff2e0 	cbnz	x0, 974c <fwp_main_thread+0x2cc>
    98f4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    98f8:	f0000120 	adrp	x0, 30000 <alt.5+0xfca0>
    98fc:	910d8000 	add	x0, x0, #0x360
    9900:	97ffe3b0 	bl	27c0 <memset@plt>
    9904:	aa1303e0 	mov	x0, x19
    9908:	97ffeb9a 	bl	4770 <fwp_mem_free>
    990c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9910:	f947ec00 	ldr	x0, [x0, #4056]
    9914:	9100c2b5 	add	x21, x21, #0x30
    9918:	f9400000 	ldr	x0, [x0]
    991c:	f9000abf 	str	xzr, [x21, #16]
    9920:	f9018abf 	str	xzr, [x21, #784]
    9924:	97ffe3ff 	bl	2920 <fflush@plt>
    9928:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    992c:	f947f400 	ldr	x0, [x0, #4072]
    9930:	f9408fe2 	ldr	x2, [sp, #280]
    9934:	f9400001 	ldr	x1, [x0]
    9938:	eb010042 	subs	x2, x2, x1
    993c:	d2800001 	mov	x1, #0x0                   	// #0
    9940:	54003be1 	b.ne	a0bc <fwp_main_thread+0xc3c>  // b.any
    9944:	a9527bfd 	ldp	x29, x30, [sp, #288]
    9948:	d2800000 	mov	x0, #0x0                   	// #0
    994c:	a95353f3 	ldp	x19, x20, [sp, #304]
    9950:	a9545bf5 	ldp	x21, x22, [sp, #320]
    9954:	a95563f7 	ldp	x23, x24, [sp, #336]
    9958:	a95773fb 	ldp	x27, x28, [sp, #368]
    995c:	910643ff 	add	sp, sp, #0x190
    9960:	d65f03c0 	ret
    9964:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    9968:	91328000 	add	x0, x0, #0xca0
    996c:	94000399 	bl	a7d0 <atexit>
    9970:	17fffed6 	b	94c8 <fwp_main_thread+0x48>
    9974:	97ffe924 	bl	3e04 <fwp_heap_init>
    9978:	17fffed1 	b	94bc <fwp_main_thread+0x3c>
    997c:	f9416382 	ldr	x2, [x28, #704]
    9980:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x800>
    9984:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9988:	913b4021 	add	x1, x1, #0xed0
    998c:	a90287e2 	stp	x2, x1, [sp, #40]
    9990:	911502d4 	add	x20, x22, #0x540
    9994:	d2800018 	mov	x24, #0x0                   	// #0
    9998:	f9400be1 	ldr	x1, [sp, #16]
    999c:	a9166bf9 	stp	x25, x26, [sp, #352]
    99a0:	d290001b 	mov	x27, #0x8000                	// #32768
    99a4:	fd00c3e8 	str	d8, [sp, #384]
    99a8:	d2800017 	mov	x23, #0x0                   	// #0
    99ac:	fd425808 	ldr	d8, [x0, #1200]
    99b0:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0xdc>
    99b4:	911f8000 	add	x0, x0, #0x7e0
    99b8:	f9001fe1 	str	x1, [sp, #56]
    99bc:	f90023ff 	str	xzr, [sp, #64]
    99c0:	f9002bff 	str	xzr, [sp, #80]
    99c4:	f9002fe0 	str	x0, [sp, #88]
    99c8:	f9016393 	str	x19, [x28, #704]
    99cc:	1400003d 	b	9ac0 <fwp_main_thread+0x640>
    99d0:	f9400261 	ldr	x1, [x19]
    99d4:	aa2103e1 	mvn	x1, x1
    99d8:	f8207a81 	str	x1, [x20, x0, lsl #3]
    99dc:	f10060bf 	cmp	x5, #0x18
    99e0:	54000129 	b.ls	9a04 <fwp_main_thread+0x584>  // b.plast
    99e4:	d10064a2 	sub	x2, x5, #0x19
    99e8:	91006260 	add	x0, x19, #0x18
    99ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    99f0:	52800001 	mov	w1, #0x0                   	// #0
    99f4:	91002042 	add	x2, x2, #0x8
    99f8:	f90007e5 	str	x5, [sp, #8]
    99fc:	97ffe371 	bl	27c0 <memset@plt>
    9a00:	f94007e5 	ldr	x5, [sp, #8]
    9a04:	f94a1280 	ldr	x0, [x20, #5152]
    9a08:	ab050000 	adds	x0, x0, x5
    9a0c:	540035e2 	b.cs	a0c8 <fwp_main_thread+0xc48>  // b.hs, b.nlast
    9a10:	f94a1681 	ldr	x1, [x20, #5160]
    9a14:	f90a1280 	str	x0, [x20, #5152]
    9a18:	eb01001f 	cmp	x0, x1
    9a1c:	54000049 	b.ls	9a24 <fwp_main_thread+0x5a4>  // b.plast
    9a20:	f90a1680 	str	x0, [x20, #5160]
    9a24:	1e630321 	ucvtf	d1, w25
    9a28:	fd4a1e80 	ldr	d0, [x20, #5176]
    9a2c:	1e612800 	fadd	d0, d0, d1
    9a30:	fd0a1e80 	str	d0, [x20, #5176]
    9a34:	a900e27c 	stp	x28, x24, [x19, #8]
    9a38:	aa1303f8 	mov	x24, x19
    9a3c:	fd000268 	str	d8, [x19]
    9a40:	f949da82 	ldr	x2, [x20, #5040]
    9a44:	f949ee80 	ldr	x0, [x20, #5080]
    9a48:	cb020262 	sub	x2, x19, x2
    9a4c:	eb00405f 	cmp	x2, x0, lsl #16
    9a50:	54000322 	b.cs	9ab4 <fwp_main_thread+0x634>  // b.hs, b.nlast
    9a54:	d350fc40 	lsr	x0, x2, #16
    9a58:	f949fe86 	ldr	x6, [x20, #5112]
    9a5c:	8b000800 	add	x0, x0, x0, lsl #2
    9a60:	d37df001 	lsl	x1, x0, #3
    9a64:	8b0100c5 	add	x5, x6, x1
    9a68:	f94010a0 	ldr	x0, [x5, #32]
    9a6c:	b4000240 	cbz	x0, 9ab4 <fwp_main_thread+0x634>
    9a70:	386168c1 	ldrb	w1, [x6, x1]
    9a74:	7100083f 	cmp	w1, #0x2
    9a78:	540005e0 	b.eq	9b34 <fwp_main_thread+0x6b4>  // b.none
    9a7c:	7100043f 	cmp	w1, #0x1
    9a80:	540001a1 	b.ne	9ab4 <fwp_main_thread+0x634>  // b.any
    9a84:	92403c41 	and	x1, x2, #0xffff
    9a88:	294308a6 	ldp	w6, w2, [x5, #24]
    9a8c:	9b067c21 	mul	x1, x1, x6
    9a90:	d360fc21 	lsr	x1, x1, #32
    9a94:	eb02003f 	cmp	x1, x2
    9a98:	540000e2 	b.cs	9ab4 <fwp_main_thread+0x634>  // b.hs, b.nlast
    9a9c:	8b010000 	add	x0, x0, x1
    9aa0:	39400001 	ldrb	w1, [x0]
    9aa4:	7103fc3f 	cmp	w1, #0xff
    9aa8:	54002020 	b.eq	9eac <fwp_main_thread+0xa2c>  // b.none
    9aac:	52800021 	mov	w1, #0x1                   	// #1
    9ab0:	39000001 	strb	w1, [x0]
    9ab4:	f90023f3 	str	x19, [sp, #64]
    9ab8:	aa1a039c 	orr	x28, x28, x26
    9abc:	b400047c 	cbz	x28, 9b48 <fwp_main_thread+0x6c8>
    9ac0:	b953a680 	ldr	w0, [x20, #5028]
    9ac4:	f100077c 	subs	x28, x27, #0x1
    9ac8:	f90027fc 	str	x28, [sp, #72]
    9acc:	da1f02fa 	sbc	x26, x23, xzr
    9ad0:	aa1c03fb 	mov	x27, x28
    9ad4:	aa1a03f7 	mov	x23, x26
    9ad8:	34000240 	cbz	w0, 9b20 <fwp_main_thread+0x6a0>
    9adc:	397e8a80 	ldrb	w0, [x20, #4002]
    9ae0:	910f0001 	add	x1, x0, #0x3c0
    9ae4:	8b000400 	add	x0, x0, x0, lsl #1
    9ae8:	b8617a99 	ldr	w25, [x20, x1, lsl #2]
    9aec:	8b000e81 	add	x1, x20, x0, lsl #3
    9af0:	f8607a93 	ldr	x19, [x20, x0, lsl #3]
    9af4:	2a1903e5 	mov	w5, w25
    9af8:	b5fff6d3 	cbnz	x19, 99d0 <fwp_main_thread+0x550>
    9afc:	f9400433 	ldr	x19, [x1, #8]
    9b00:	b4000113 	cbz	x19, 9b20 <fwp_main_thread+0x6a0>
    9b04:	f9400820 	ldr	x0, [x1, #16]
    9b08:	cb130000 	sub	x0, x0, x19
    9b0c:	eb0000bf 	cmp	x5, x0
    9b10:	54000088 	b.hi	9b20 <fwp_main_thread+0x6a0>  // b.pmore
    9b14:	8b050260 	add	x0, x19, x5
    9b18:	f9000420 	str	x0, [x1, #8]
    9b1c:	17ffffb0 	b	99dc <fwp_main_thread+0x55c>
    9b20:	52800001 	mov	w1, #0x0                   	// #0
    9b24:	d2800300 	mov	x0, #0x18                  	// #24
    9b28:	97ffec32 	bl	4bf0 <fwp_heap_alloc>
    9b2c:	aa0003f3 	mov	x19, x0
    9b30:	17ffffc1 	b	9a34 <fwp_main_thread+0x5b4>
    9b34:	72003c5f 	tst	w2, #0xffff
    9b38:	54fffb40 	b.eq	9aa0 <fwp_main_thread+0x620>  // b.none
    9b3c:	f90023f3 	str	x19, [sp, #64]
    9b40:	aa1a039c 	orr	x28, x28, x26
    9b44:	b5fffbfc 	cbnz	x28, 9ac0 <fwp_main_thread+0x640>
    9b48:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x800>
    9b4c:	9100c2a2 	add	x2, x21, #0x30
    9b50:	f94017e3 	ldr	x3, [sp, #40]
    9b54:	910183e1 	add	x1, sp, #0x60
    9b58:	3dc13000 	ldr	q0, [x0, #1216]
    9b5c:	52800020 	mov	w0, #0x1                   	// #1
    9b60:	f9016043 	str	x3, [x2, #704]
    9b64:	3d801be0 	str	q0, [sp, #96]
    9b68:	97ffee0e 	bl	53a0 <fwp_data.part.0.constprop.0>
    9b6c:	911502c2 	add	x2, x22, #0x540
    9b70:	aa0003f7 	mov	x23, x0
    9b74:	f949d841 	ldr	x1, [x2, #5040]
    9b78:	f949ec40 	ldr	x0, [x2, #5080]
    9b7c:	cb0102e1 	sub	x1, x23, x1
    9b80:	eb00403f 	cmp	x1, x0, lsl #16
    9b84:	54000322 	b.cs	9be8 <fwp_main_thread+0x768>  // b.hs, b.nlast
    9b88:	d350fc20 	lsr	x0, x1, #16
    9b8c:	f949fc43 	ldr	x3, [x2, #5112]
    9b90:	8b000800 	add	x0, x0, x0, lsl #2
    9b94:	d37df002 	lsl	x2, x0, #3
    9b98:	8b020060 	add	x0, x3, x2
    9b9c:	f9401014 	ldr	x20, [x0, #32]
    9ba0:	b4000254 	cbz	x20, 9be8 <fwp_main_thread+0x768>
    9ba4:	38626862 	ldrb	w2, [x3, x2]
    9ba8:	7100085f 	cmp	w2, #0x2
    9bac:	540017a0 	b.eq	9ea0 <fwp_main_thread+0xa20>  // b.none
    9bb0:	7100045f 	cmp	w2, #0x1
    9bb4:	540001a1 	b.ne	9be8 <fwp_main_thread+0x768>  // b.any
    9bb8:	29430002 	ldp	w2, w0, [x0, #24]
    9bbc:	92403c21 	and	x1, x1, #0xffff
    9bc0:	9b027c21 	mul	x1, x1, x2
    9bc4:	d360fc21 	lsr	x1, x1, #32
    9bc8:	eb00003f 	cmp	x1, x0
    9bcc:	540000e2 	b.cs	9be8 <fwp_main_thread+0x768>  // b.hs, b.nlast
    9bd0:	8b010294 	add	x20, x20, x1
    9bd4:	39400280 	ldrb	w0, [x20]
    9bd8:	7103fc1f 	cmp	w0, #0xff
    9bdc:	54002020 	b.eq	9fe0 <fwp_main_thread+0xb60>  // b.none
    9be0:	52800020 	mov	w0, #0x1                   	// #1
    9be4:	39000280 	strb	w0, [x20]
    9be8:	f9400fe1 	ldr	x1, [sp, #24]
    9bec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9bf0:	52800020 	mov	w0, #0x1                   	// #1
    9bf4:	a9085fe2 	stp	x2, x23, [sp, #128]
    9bf8:	97ffedea 	bl	53a0 <fwp_data.part.0.constprop.0>
    9bfc:	aa0003f7 	mov	x23, x0
    9c00:	911502c2 	add	x2, x22, #0x540
    9c04:	f949d841 	ldr	x1, [x2, #5040]
    9c08:	f949ec40 	ldr	x0, [x2, #5080]
    9c0c:	cb0102e1 	sub	x1, x23, x1
    9c10:	eb00403f 	cmp	x1, x0, lsl #16
    9c14:	54000322 	b.cs	9c78 <fwp_main_thread+0x7f8>  // b.hs, b.nlast
    9c18:	d350fc20 	lsr	x0, x1, #16
    9c1c:	f949fc43 	ldr	x3, [x2, #5112]
    9c20:	8b000800 	add	x0, x0, x0, lsl #2
    9c24:	d37df002 	lsl	x2, x0, #3
    9c28:	8b020060 	add	x0, x3, x2
    9c2c:	f9401014 	ldr	x20, [x0, #32]
    9c30:	b4000254 	cbz	x20, 9c78 <fwp_main_thread+0x7f8>
    9c34:	38626862 	ldrb	w2, [x3, x2]
    9c38:	7100085f 	cmp	w2, #0x2
    9c3c:	54001200 	b.eq	9e7c <fwp_main_thread+0x9fc>  // b.none
    9c40:	7100045f 	cmp	w2, #0x1
    9c44:	540001a1 	b.ne	9c78 <fwp_main_thread+0x7f8>  // b.any
    9c48:	29430002 	ldp	w2, w0, [x0, #24]
    9c4c:	92403c21 	and	x1, x1, #0xffff
    9c50:	9b027c21 	mul	x1, x1, x2
    9c54:	d360fc21 	lsr	x1, x1, #32
    9c58:	eb00003f 	cmp	x1, x0
    9c5c:	540000e2 	b.cs	9c78 <fwp_main_thread+0x7f8>  // b.hs, b.nlast
    9c60:	8b010294 	add	x20, x20, x1
    9c64:	39400280 	ldrb	w0, [x20]
    9c68:	7103fc1f 	cmp	w0, #0xff
    9c6c:	54001c80 	b.eq	9ffc <fwp_main_thread+0xb7c>  // b.none
    9c70:	52800020 	mov	w0, #0x1                   	// #1
    9c74:	39000280 	strb	w0, [x20]
    9c78:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9c7c:	9101c3e1 	add	x1, sp, #0x70
    9c80:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9c84:	52800020 	mov	w0, #0x1                   	// #1
    9c88:	a9075fe2 	stp	x2, x23, [sp, #112]
    9c8c:	97ffedc5 	bl	53a0 <fwp_data.part.0.constprop.0>
    9c90:	911502c3 	add	x3, x22, #0x540
    9c94:	aa0003f4 	mov	x20, x0
    9c98:	f949ec60 	ldr	x0, [x3, #5080]
    9c9c:	f949d861 	ldr	x1, [x3, #5040]
    9ca0:	d370bc00 	lsl	x0, x0, #16
    9ca4:	cb010281 	sub	x1, x20, x1
    9ca8:	eb00003f 	cmp	x1, x0
    9cac:	540003c2 	b.cs	9d24 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    9cb0:	d350fc22 	lsr	x2, x1, #16
    9cb4:	f949fc64 	ldr	x4, [x3, #5112]
    9cb8:	8b020842 	add	x2, x2, x2, lsl #2
    9cbc:	d37df042 	lsl	x2, x2, #3
    9cc0:	8b020083 	add	x3, x4, x2
    9cc4:	f9401077 	ldr	x23, [x3, #32]
    9cc8:	b40002f7 	cbz	x23, 9d24 <fwp_main_thread+0x8a4>
    9ccc:	38626882 	ldrb	w2, [x4, x2]
    9cd0:	7100085f 	cmp	w2, #0x2
    9cd4:	54000e00 	b.eq	9e94 <fwp_main_thread+0xa14>  // b.none
    9cd8:	7100045f 	cmp	w2, #0x1
    9cdc:	54000241 	b.ne	9d24 <fwp_main_thread+0x8a4>  // b.any
    9ce0:	29430c64 	ldp	w4, w3, [x3, #24]
    9ce4:	92403c22 	and	x2, x1, #0xffff
    9ce8:	9b047c42 	mul	x2, x2, x4
    9cec:	d360fc42 	lsr	x2, x2, #32
    9cf0:	eb03005f 	cmp	x2, x3
    9cf4:	54000182 	b.cs	9d24 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    9cf8:	8b0202f7 	add	x23, x23, x2
    9cfc:	394002e0 	ldrb	w0, [x23]
    9d00:	7103fc1f 	cmp	w0, #0xff
    9d04:	54001820 	b.eq	a008 <fwp_main_thread+0xb88>  // b.none
    9d08:	911502c1 	add	x1, x22, #0x540
    9d0c:	52800020 	mov	w0, #0x1                   	// #1
    9d10:	390002e0 	strb	w0, [x23]
    9d14:	f949ec20 	ldr	x0, [x1, #5080]
    9d18:	f949d821 	ldr	x1, [x1, #5040]
    9d1c:	d370bc00 	lsl	x0, x0, #16
    9d20:	cb010281 	sub	x1, x20, x1
    9d24:	b00000b7 	adrp	x23, 1e000 <__FRAME_END__+0x11738>
    9d28:	911022f7 	add	x23, x23, #0x408
    9d2c:	d0000018 	adrp	x24, b000 <_IO_stdin_used+0x800>
    9d30:	910142f9 	add	x25, x23, #0x50
    9d34:	aa1303fa 	mov	x26, x19
    9d38:	9107e318 	add	x24, x24, #0x1f8
    9d3c:	eb00003f 	cmp	x1, x0
    9d40:	54000362 	b.cs	9dac <fwp_main_thread+0x92c>  // b.hs, b.nlast
    9d44:	911502c2 	add	x2, x22, #0x540
    9d48:	d350fc20 	lsr	x0, x1, #16
    9d4c:	8b000800 	add	x0, x0, x0, lsl #2
    9d50:	f949fc44 	ldr	x4, [x2, #5112]
    9d54:	d37df002 	lsl	x2, x0, #3
    9d58:	8b020083 	add	x3, x4, x2
    9d5c:	f9401060 	ldr	x0, [x3, #32]
    9d60:	b4000260 	cbz	x0, 9dac <fwp_main_thread+0x92c>
    9d64:	38626882 	ldrb	w2, [x4, x2]
    9d68:	7100085f 	cmp	w2, #0x2
    9d6c:	540008e0 	b.eq	9e88 <fwp_main_thread+0xa08>  // b.none
    9d70:	7100045f 	cmp	w2, #0x1
    9d74:	540001c1 	b.ne	9dac <fwp_main_thread+0x92c>  // b.any
    9d78:	29430864 	ldp	w4, w2, [x3, #24]
    9d7c:	92403c21 	and	x1, x1, #0xffff
    9d80:	9b047c21 	mul	x1, x1, x4
    9d84:	d360fc21 	lsr	x1, x1, #32
    9d88:	eb02003f 	cmp	x1, x2
    9d8c:	54000102 	b.cs	9dac <fwp_main_thread+0x92c>  // b.hs, b.nlast
    9d90:	8b010000 	add	x0, x0, x1
    9d94:	39400001 	ldrb	w1, [x0]
    9d98:	340000a1 	cbz	w1, 9dac <fwp_main_thread+0x92c>
    9d9c:	7103f43f 	cmp	w1, #0xfd
    9da0:	540013a8 	b.hi	a014 <fwp_main_thread+0xb94>  // b.pmore
    9da4:	11000421 	add	w1, w1, #0x1
    9da8:	39000001 	strb	w1, [x0]
    9dac:	f9400be0 	ldr	x0, [sp, #16]
    9db0:	aa1903e2 	mov	x2, x25
    9db4:	aa1403e1 	mov	x1, x20
    9db8:	52800023 	mov	w3, #0x1                   	// #1
    9dbc:	a9047fff 	stp	xzr, xzr, [sp, #64]
    9dc0:	f9002bff 	str	xzr, [sp, #80]
    9dc4:	97fff9b3 	bl	8490 <fwp_write>
    9dc8:	a9445ffc 	ldp	x28, x23, [sp, #64]
    9dcc:	f100039f 	cmp	x28, #0x0
    9dd0:	9a9c031c 	csel	x28, x24, x28, eq	// eq = none
    9dd4:	b1002aff 	cmn	x23, #0xa
    9dd8:	540017a8 	b.hi	a0cc <fwp_main_thread+0xc4c>  // b.pmore
    9ddc:	52800021 	mov	w1, #0x1                   	// #1
    9de0:	910026e0 	add	x0, x23, #0x9
    9de4:	97ffeb83 	bl	4bf0 <fwp_heap_alloc>
    9de8:	aa0003fb 	mov	x27, x0
    9dec:	aa1c03e1 	mov	x1, x28
    9df0:	aa0003fc 	mov	x28, x0
    9df4:	aa1703e2 	mov	x2, x23
    9df8:	f8008797 	str	x23, [x28], #8
    9dfc:	aa1c03e0 	mov	x0, x28
    9e00:	97ffe210 	bl	2640 <memcpy@plt>
    9e04:	8b170362 	add	x2, x27, x23
    9e08:	3900205f 	strb	wzr, [x2, #8]
    9e0c:	f94023e0 	ldr	x0, [sp, #64]
    9e10:	97ffe2a8 	bl	28b0 <free@plt>
    9e14:	911502c2 	add	x2, x22, #0x540
    9e18:	f949d841 	ldr	x1, [x2, #5040]
    9e1c:	f949ec40 	ldr	x0, [x2, #5080]
    9e20:	cb010361 	sub	x1, x27, x1
    9e24:	eb00403f 	cmp	x1, x0, lsl #16
    9e28:	540005c2 	b.cs	9ee0 <fwp_main_thread+0xa60>  // b.hs, b.nlast
    9e2c:	d350fc20 	lsr	x0, x1, #16
    9e30:	f949fc44 	ldr	x4, [x2, #5112]
    9e34:	8b000800 	add	x0, x0, x0, lsl #2
    9e38:	d37df002 	lsl	x2, x0, #3
    9e3c:	8b020083 	add	x3, x4, x2
    9e40:	f9401060 	ldr	x0, [x3, #32]
    9e44:	b40004e0 	cbz	x0, 9ee0 <fwp_main_thread+0xa60>
    9e48:	38626882 	ldrb	w2, [x4, x2]
    9e4c:	7100085f 	cmp	w2, #0x2
    9e50:	540003a0 	b.eq	9ec4 <fwp_main_thread+0xa44>  // b.none
    9e54:	7100045f 	cmp	w2, #0x1
    9e58:	54000441 	b.ne	9ee0 <fwp_main_thread+0xa60>  // b.any
    9e5c:	29430864 	ldp	w4, w2, [x3, #24]
    9e60:	92403c21 	and	x1, x1, #0xffff
    9e64:	9b047c21 	mul	x1, x1, x4
    9e68:	d360fc21 	lsr	x1, x1, #32
    9e6c:	eb02003f 	cmp	x1, x2
    9e70:	54000382 	b.cs	9ee0 <fwp_main_thread+0xa60>  // b.hs, b.nlast
    9e74:	8b010000 	add	x0, x0, x1
    9e78:	14000015 	b	9ecc <fwp_main_thread+0xa4c>
    9e7c:	72003c3f 	tst	w1, #0xffff
    9e80:	54ffefc1 	b.ne	9c78 <fwp_main_thread+0x7f8>  // b.any
    9e84:	17ffff78 	b	9c64 <fwp_main_thread+0x7e4>
    9e88:	72003c3f 	tst	w1, #0xffff
    9e8c:	54fff901 	b.ne	9dac <fwp_main_thread+0x92c>  // b.any
    9e90:	17ffffc1 	b	9d94 <fwp_main_thread+0x914>
    9e94:	72003c3f 	tst	w1, #0xffff
    9e98:	54fff461 	b.ne	9d24 <fwp_main_thread+0x8a4>  // b.any
    9e9c:	17ffff98 	b	9cfc <fwp_main_thread+0x87c>
    9ea0:	72003c3f 	tst	w1, #0xffff
    9ea4:	54ffea21 	b.ne	9be8 <fwp_main_thread+0x768>  // b.any
    9ea8:	17ffff4b 	b	9bd4 <fwp_main_thread+0x754>
    9eac:	f90007e0 	str	x0, [sp, #8]
    9eb0:	97ffe990 	bl	44f0 <fwp_rc_forget_slot>
    9eb4:	f94007e0 	ldr	x0, [sp, #8]
    9eb8:	17fffefd 	b	9aac <fwp_main_thread+0x62c>
    9ebc:	aa0103e0 	mov	x0, x1
    9ec0:	17fffe38 	b	97a0 <fwp_main_thread+0x320>
    9ec4:	72003c3f 	tst	w1, #0xffff
    9ec8:	540000c1 	b.ne	9ee0 <fwp_main_thread+0xa60>  // b.any
    9ecc:	39400001 	ldrb	w1, [x0]
    9ed0:	7103fc3f 	cmp	w1, #0xff
    9ed4:	540008c0 	b.eq	9fec <fwp_main_thread+0xb6c>  // b.none
    9ed8:	52800021 	mov	w1, #0x1                   	// #1
    9edc:	39000001 	strb	w1, [x0]
    9ee0:	aa1403e0 	mov	x0, x20
    9ee4:	97ffede4 	bl	5674 <fwp_drop0>
    9ee8:	9100c2a3 	add	x3, x21, #0x30
    9eec:	aa1c03e0 	mov	x0, x28
    9ef0:	f9400362 	ldr	x2, [x27]
    9ef4:	aa0303fc 	mov	x28, x3
    9ef8:	f9400463 	ldr	x3, [x3, #8]
    9efc:	d2800021 	mov	x1, #0x1                   	// #1
    9f00:	97ffe27c 	bl	28f0 <fwrite@plt>
    9f04:	f9400781 	ldr	x1, [x28, #8]
    9f08:	52800140 	mov	w0, #0xa                   	// #10
    9f0c:	97ffe201 	bl	2710 <fputc@plt>
    9f10:	911502c2 	add	x2, x22, #0x540
    9f14:	f949d841 	ldr	x1, [x2, #5040]
    9f18:	f949ec40 	ldr	x0, [x2, #5080]
    9f1c:	cb010361 	sub	x1, x27, x1
    9f20:	eb00403f 	cmp	x1, x0, lsl #16
    9f24:	54000382 	b.cs	9f94 <fwp_main_thread+0xb14>  // b.hs, b.nlast
    9f28:	d350fc20 	lsr	x0, x1, #16
    9f2c:	f949fc43 	ldr	x3, [x2, #5112]
    9f30:	8b000800 	add	x0, x0, x0, lsl #2
    9f34:	d37df000 	lsl	x0, x0, #3
    9f38:	8b000062 	add	x2, x3, x0
    9f3c:	f940105c 	ldr	x28, [x2, #32]
    9f40:	b40002bc 	cbz	x28, 9f94 <fwp_main_thread+0xb14>
    9f44:	38606860 	ldrb	w0, [x3, x0]
    9f48:	7100081f 	cmp	w0, #0x2
    9f4c:	54000680 	b.eq	a01c <fwp_main_thread+0xb9c>  // b.none
    9f50:	7100041f 	cmp	w0, #0x1
    9f54:	54000201 	b.ne	9f94 <fwp_main_thread+0xb14>  // b.any
    9f58:	29430043 	ldp	w3, w0, [x2, #24]
    9f5c:	92403c21 	and	x1, x1, #0xffff
    9f60:	9b037c21 	mul	x1, x1, x3
    9f64:	d360fc21 	lsr	x1, x1, #32
    9f68:	eb00003f 	cmp	x1, x0
    9f6c:	54000142 	b.cs	9f94 <fwp_main_thread+0xb14>  // b.hs, b.nlast
    9f70:	8b01039c 	add	x28, x28, x1
    9f74:	39400380 	ldrb	w0, [x28]
    9f78:	340000e0 	cbz	w0, 9f94 <fwp_main_thread+0xb14>
    9f7c:	7100041f 	cmp	w0, #0x1
    9f80:	54000860 	b.eq	a08c <fwp_main_thread+0xc0c>  // b.none
    9f84:	7103fc1f 	cmp	w0, #0xff
    9f88:	54000560 	b.eq	a034 <fwp_main_thread+0xbb4>  // b.none
    9f8c:	51000400 	sub	w0, w0, #0x1
    9f90:	39000380 	strb	w0, [x28]
    9f94:	f9400b5a 	ldr	x26, [x26, #16]
    9f98:	b40000fa 	cbz	x26, 9fb4 <fwp_main_thread+0xb34>
    9f9c:	911502c1 	add	x1, x22, #0x540
    9fa0:	f949ec20 	ldr	x0, [x1, #5080]
    9fa4:	f949d821 	ldr	x1, [x1, #5040]
    9fa8:	d370bc00 	lsl	x0, x0, #16
    9fac:	cb010281 	sub	x1, x20, x1
    9fb0:	17ffff63 	b	9d3c <fwp_main_thread+0x8bc>
    9fb4:	aa1403e0 	mov	x0, x20
    9fb8:	97ffedaf 	bl	5674 <fwp_drop0>
    9fbc:	aa1303e0 	mov	x0, x19
    9fc0:	97ffedad 	bl	5674 <fwp_drop0>
    9fc4:	9100c2a0 	add	x0, x21, #0x30
    9fc8:	fd40c3e8 	ldr	d8, [sp, #384]
    9fcc:	a9566bf9 	ldp	x25, x26, [sp, #352]
    9fd0:	52800021 	mov	w1, #0x1                   	// #1
    9fd4:	b902f801 	str	w1, [x0, #760]
    9fd8:	f901801f 	str	xzr, [x0, #768]
    9fdc:	17fffd69 	b	9580 <fwp_main_thread+0x100>
    9fe0:	aa1403e0 	mov	x0, x20
    9fe4:	97ffe943 	bl	44f0 <fwp_rc_forget_slot>
    9fe8:	17fffefe 	b	9be0 <fwp_main_thread+0x760>
    9fec:	f90007e0 	str	x0, [sp, #8]
    9ff0:	97ffe940 	bl	44f0 <fwp_rc_forget_slot>
    9ff4:	f94007e0 	ldr	x0, [sp, #8]
    9ff8:	17ffffb8 	b	9ed8 <fwp_main_thread+0xa58>
    9ffc:	aa1403e0 	mov	x0, x20
    a000:	97ffe93c 	bl	44f0 <fwp_rc_forget_slot>
    a004:	17ffff1b 	b	9c70 <fwp_main_thread+0x7f0>
    a008:	aa1703e0 	mov	x0, x23
    a00c:	97ffe939 	bl	44f0 <fwp_rc_forget_slot>
    a010:	17ffff3e 	b	9d08 <fwp_main_thread+0x888>
    a014:	97ffe8f0 	bl	43d4 <fwp_rc_wide_dup>
    a018:	17ffff65 	b	9dac <fwp_main_thread+0x92c>
    a01c:	72003c3f 	tst	w1, #0xffff
    a020:	54fffba1 	b.ne	9f94 <fwp_main_thread+0xb14>  // b.any
    a024:	17ffffd4 	b	9f74 <fwp_main_thread+0xaf4>
    a028:	b9030a9f 	str	wzr, [x20, #776]
    a02c:	b4ffbee0 	cbz	x0, 9808 <fwp_main_thread+0x388>
    a030:	17fffdc7 	b	974c <fwp_main_thread+0x2cc>
    a034:	ca5c4780 	eor	x0, x28, x28, lsr #17
    a038:	911502c1 	add	x1, x22, #0x540
    a03c:	ca402400 	eor	x0, x0, x0, lsr #9
    a040:	8b200c20 	add	x0, x1, w0, uxtb #3
    a044:	f94a2400 	ldr	x0, [x0, #5192]
    a048:	b5000080 	cbnz	x0, a058 <fwp_main_thread+0xbd8>
    a04c:	14000013 	b	a098 <fwp_main_thread+0xc18>
    a050:	f9400800 	ldr	x0, [x0, #16]
    a054:	b4000220 	cbz	x0, a098 <fwp_main_thread+0xc18>
    a058:	f9400001 	ldr	x1, [x0]
    a05c:	eb01039f 	cmp	x28, x1
    a060:	54ffff81 	b.ne	a050 <fwp_main_thread+0xbd0>  // b.any
    a064:	f9400401 	ldr	x1, [x0, #8]
    a068:	d1000421 	sub	x1, x1, #0x1
    a06c:	f9000401 	str	x1, [x0, #8]
    a070:	f103f83f 	cmp	x1, #0xfe
    a074:	54fff901 	b.ne	9f94 <fwp_main_thread+0xb14>  // b.any
    a078:	aa1c03e0 	mov	x0, x28
    a07c:	97ffe91d 	bl	44f0 <fwp_rc_forget_slot>
    a080:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a084:	39000380 	strb	w0, [x28]
    a088:	17ffffc3 	b	9f94 <fwp_main_thread+0xb14>
    a08c:	aa1b03e0 	mov	x0, x27
    a090:	97ffed31 	bl	5554 <fwp_rc_free_arr>
    a094:	17ffffc0 	b	9f94 <fwp_main_thread+0xb14>
    a098:	90000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    a09c:	912aa000 	add	x0, x0, #0xaa8
    a0a0:	97ffe518 	bl	3500 <fwp_trap>
    a0a4:	90000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    a0a8:	91368000 	add	x0, x0, #0xda0
    a0ac:	a91563f7 	stp	x23, x24, [sp, #336]
    a0b0:	a9166bf9 	stp	x25, x26, [sp, #352]
    a0b4:	fd00c3e8 	str	d8, [sp, #384]
    a0b8:	97ffe512 	bl	3500 <fwp_trap>
    a0bc:	a9166bf9 	stp	x25, x26, [sp, #352]
    a0c0:	fd00c3e8 	str	d8, [sp, #384]
    a0c4:	97ffe1cb 	bl	27f0 <__stack_chk_fail@plt>
    a0c8:	97ffe3ba 	bl	2fb0 <fwp_heap_oom>
    a0cc:	90000000 	adrp	x0, a000 <fwp_main_thread+0xb80>
    a0d0:	91372000 	add	x0, x0, #0xdc8
    a0d4:	97ffe50b 	bl	3500 <fwp_trap>
    a0d8:	d503201f 	nop
    a0dc:	d503201f 	nop

000000000000a0e0 <__divti3>:
    a0e0:	d503245f 	bti	c
    a0e4:	d2800004 	mov	x4, #0x0                   	// #0
    a0e8:	b7f80721 	tbnz	x1, #63, a1cc <__divti3+0xec>
    a0ec:	b6f80083 	tbz	x3, #63, a0fc <__divti3+0x1c>
    a0f0:	eb0203e2 	negs	x2, x2
    a0f4:	aa2403e4 	mvn	x4, x4
    a0f8:	da0303e3 	ngc	x3, x3
    a0fc:	aa0203e6 	mov	x6, x2
    a100:	aa0003e7 	mov	x7, x0
    a104:	aa0103e5 	mov	x5, x1
    a108:	b5000583 	cbnz	x3, a1b8 <__divti3+0xd8>
    a10c:	eb01005f 	cmp	x2, x1
    a110:	54000e69 	b.ls	a2dc <__divti3+0x1fc>  // b.plast
    a114:	dac01040 	clz	x0, x2
    a118:	b40000e0 	cbz	x0, a134 <__divti3+0x54>
    a11c:	4b0003e1 	neg	w1, w0
    a120:	9ac020a5 	lsl	x5, x5, x0
    a124:	9ac02046 	lsl	x6, x2, x0
    a128:	9ac124e1 	lsr	x1, x7, x1
    a12c:	aa050025 	orr	x5, x1, x5
    a130:	9ac020e7 	lsl	x7, x7, x0
    a134:	d360fcc8 	lsr	x8, x6, #32
    a138:	92407cc2 	and	x2, x6, #0xffffffff
    a13c:	9ac808a3 	udiv	x3, x5, x8
    a140:	9b089465 	msub	x5, x3, x8, x5
    a144:	aa0303e0 	mov	x0, x3
    a148:	9b037c41 	mul	x1, x2, x3
    a14c:	93c780a5 	extr	x5, x5, x7, #32
    a150:	eb05003f 	cmp	x1, x5
    a154:	540000a9 	b.ls	a168 <__divti3+0x88>  // b.plast
    a158:	ab0500c5 	adds	x5, x6, x5
    a15c:	d1000460 	sub	x0, x3, #0x1
    a160:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a164:	540015a8 	b.hi	a418 <__divti3+0x338>  // b.pmore
    a168:	cb0100a5 	sub	x5, x5, x1
    a16c:	9ac808a3 	udiv	x3, x5, x8
    a170:	9b089465 	msub	x5, x3, x8, x5
    a174:	aa0303e1 	mov	x1, x3
    a178:	9b037c42 	mul	x2, x2, x3
    a17c:	aa0703e3 	mov	x3, x7
    a180:	b3607ca3 	bfi	x3, x5, #32, #32
    a184:	eb03005f 	cmp	x2, x3
    a188:	540000c9 	b.ls	a1a0 <__divti3+0xc0>  // b.plast
    a18c:	ab0300c3 	adds	x3, x6, x3
    a190:	d1000425 	sub	x5, x1, #0x1
    a194:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a198:	d1000821 	sub	x1, x1, #0x2
    a19c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a1a0:	aa008020 	orr	x0, x1, x0, lsl #32
    a1a4:	d2800001 	mov	x1, #0x0                   	// #0
    a1a8:	b4000064 	cbz	x4, a1b4 <__divti3+0xd4>
    a1ac:	eb0003e0 	negs	x0, x0
    a1b0:	da0103e1 	ngc	x1, x1
    a1b4:	d65f03c0 	ret
    a1b8:	eb01007f 	cmp	x3, x1
    a1bc:	54000109 	b.ls	a1dc <__divti3+0xfc>  // b.plast
    a1c0:	d2800001 	mov	x1, #0x0                   	// #0
    a1c4:	d2800000 	mov	x0, #0x0                   	// #0
    a1c8:	17fffff8 	b	a1a8 <__divti3+0xc8>
    a1cc:	eb0003e0 	negs	x0, x0
    a1d0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a1d4:	da0103e1 	ngc	x1, x1
    a1d8:	17ffffc5 	b	a0ec <__divti3+0xc>
    a1dc:	dac01067 	clz	x7, x3
    a1e0:	b40010e7 	cbz	x7, a3fc <__divti3+0x31c>
    a1e4:	d2800805 	mov	x5, #0x40                  	// #64
    a1e8:	cb0700a5 	sub	x5, x5, x7
    a1ec:	9ac72063 	lsl	x3, x3, x7
    a1f0:	9ac52448 	lsr	x8, x2, x5
    a1f4:	aa030108 	orr	x8, x8, x3
    a1f8:	9ac52426 	lsr	x6, x1, x5
    a1fc:	92407d0a 	and	x10, x8, #0xffffffff
    a200:	d360fd09 	lsr	x9, x8, #32
    a204:	9ac52403 	lsr	x3, x0, x5
    a208:	9ac72021 	lsl	x1, x1, x7
    a20c:	aa010063 	orr	x3, x3, x1
    a210:	9ac72042 	lsl	x2, x2, x7
    a214:	9ac908cb 	udiv	x11, x6, x9
    a218:	9b099965 	msub	x5, x11, x9, x6
    a21c:	aa0b03e1 	mov	x1, x11
    a220:	9b0b7d46 	mul	x6, x10, x11
    a224:	93c380a5 	extr	x5, x5, x3, #32
    a228:	eb0500df 	cmp	x6, x5
    a22c:	540000a9 	b.ls	a240 <__divti3+0x160>  // b.plast
    a230:	ab050105 	adds	x5, x8, x5
    a234:	d1000561 	sub	x1, x11, #0x1
    a238:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a23c:	54000f48 	b.hi	a424 <__divti3+0x344>  // b.pmore
    a240:	cb0600a6 	sub	x6, x5, x6
    a244:	9ac908cb 	udiv	x11, x6, x9
    a248:	9b099969 	msub	x9, x11, x9, x6
    a24c:	aa0b03e5 	mov	x5, x11
    a250:	9b0b7d4a 	mul	x10, x10, x11
    a254:	b3607d23 	bfi	x3, x9, #32, #32
    a258:	eb03015f 	cmp	x10, x3
    a25c:	540000a9 	b.ls	a270 <__divti3+0x190>  // b.plast
    a260:	ab030103 	adds	x3, x8, x3
    a264:	d1000565 	sub	x5, x11, #0x1
    a268:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a26c:	54000e28 	b.hi	a430 <__divti3+0x350>  // b.pmore
    a270:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a274:	92407c48 	and	x8, x2, #0xffffffff
    a278:	2a0503e5 	mov	w5, w5
    a27c:	d360fc42 	lsr	x2, x2, #32
    a280:	d360fc26 	lsr	x6, x1, #32
    a284:	cb0a0063 	sub	x3, x3, x10
    a288:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a28c:	9b087caa 	mul	x10, x5, x8
    a290:	9b087cc8 	mul	x8, x6, x8
    a294:	9b0220a5 	madd	x5, x5, x2, x8
    a298:	9b027cc6 	mul	x6, x6, x2
    a29c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a2a0:	8b0900c5 	add	x5, x6, x9
    a2a4:	eb02011f 	cmp	x8, x2
    a2a8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a2ac:	8b4280c6 	add	x6, x6, x2, lsr #32
    a2b0:	eb06007f 	cmp	x3, x6
    a2b4:	540000e3 	b.cc	a2d0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a2b8:	92407d4a 	and	x10, x10, #0xffffffff
    a2bc:	9ac72000 	lsl	x0, x0, x7
    a2c0:	8b028142 	add	x2, x10, x2, lsl #32
    a2c4:	eb02001f 	cmp	x0, x2
    a2c8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a2cc:	54000a01 	b.ne	a40c <__divti3+0x32c>  // b.any
    a2d0:	d1000420 	sub	x0, x1, #0x1
    a2d4:	d2800001 	mov	x1, #0x0                   	// #0
    a2d8:	17ffffb4 	b	a1a8 <__divti3+0xc8>
    a2dc:	b5000062 	cbnz	x2, a2e8 <__divti3+0x208>
    a2e0:	d2800022 	mov	x2, #0x1                   	// #1
    a2e4:	9ac30846 	udiv	x6, x2, x3
    a2e8:	dac010c8 	clz	x8, x6
    a2ec:	b5000408 	cbnz	x8, a36c <__divti3+0x28c>
    a2f0:	d360fcc9 	lsr	x9, x6, #32
    a2f4:	92407cc5 	and	x5, x6, #0xffffffff
    a2f8:	cb060023 	sub	x3, x1, x6
    a2fc:	d2800021 	mov	x1, #0x1                   	// #1
    a300:	9ac90868 	udiv	x8, x3, x9
    a304:	9b098d03 	msub	x3, x8, x9, x3
    a308:	aa0803e0 	mov	x0, x8
    a30c:	9b057d02 	mul	x2, x8, x5
    a310:	93c78063 	extr	x3, x3, x7, #32
    a314:	eb03005f 	cmp	x2, x3
    a318:	540000a9 	b.ls	a32c <__divti3+0x24c>  // b.plast
    a31c:	ab0300c3 	adds	x3, x6, x3
    a320:	d1000500 	sub	x0, x8, #0x1
    a324:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a328:	54000968 	b.hi	a454 <__divti3+0x374>  // b.pmore
    a32c:	cb020063 	sub	x3, x3, x2
    a330:	9ac90862 	udiv	x2, x3, x9
    a334:	aa0203e8 	mov	x8, x2
    a338:	9b098c42 	msub	x2, x2, x9, x3
    a33c:	aa0703e3 	mov	x3, x7
    a340:	9b057d05 	mul	x5, x8, x5
    a344:	b3607c43 	bfi	x3, x2, #32, #32
    a348:	eb0300bf 	cmp	x5, x3
    a34c:	540000c9 	b.ls	a364 <__divti3+0x284>  // b.plast
    a350:	ab0300c2 	adds	x2, x6, x3
    a354:	d1000503 	sub	x3, x8, #0x1
    a358:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a35c:	d1000908 	sub	x8, x8, #0x2
    a360:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a364:	aa008100 	orr	x0, x8, x0, lsl #32
    a368:	17ffff90 	b	a1a8 <__divti3+0xc8>
    a36c:	9ac820c6 	lsl	x6, x6, x8
    a370:	d2800803 	mov	x3, #0x40                  	// #64
    a374:	cb080063 	sub	x3, x3, x8
    a378:	d360fcc9 	lsr	x9, x6, #32
    a37c:	9ac82027 	lsl	x7, x1, x8
    a380:	92407cc5 	and	x5, x6, #0xffffffff
    a384:	9ac32422 	lsr	x2, x1, x3
    a388:	9ac32403 	lsr	x3, x0, x3
    a38c:	aa070063 	orr	x3, x3, x7
    a390:	9ac9084a 	udiv	x10, x2, x9
    a394:	9ac82007 	lsl	x7, x0, x8
    a398:	9b098940 	msub	x0, x10, x9, x2
    a39c:	aa0a03e1 	mov	x1, x10
    a3a0:	9b0a7ca2 	mul	x2, x5, x10
    a3a4:	93c38000 	extr	x0, x0, x3, #32
    a3a8:	eb00005f 	cmp	x2, x0
    a3ac:	540000a9 	b.ls	a3c0 <__divti3+0x2e0>  // b.plast
    a3b0:	ab0000c0 	adds	x0, x6, x0
    a3b4:	d1000541 	sub	x1, x10, #0x1
    a3b8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a3bc:	54000468 	b.hi	a448 <__divti3+0x368>  // b.pmore
    a3c0:	cb020000 	sub	x0, x0, x2
    a3c4:	9ac9080a 	udiv	x10, x0, x9
    a3c8:	9b098140 	msub	x0, x10, x9, x0
    a3cc:	aa0a03e2 	mov	x2, x10
    a3d0:	9b0a7ca8 	mul	x8, x5, x10
    a3d4:	b3607c03 	bfi	x3, x0, #32, #32
    a3d8:	eb03011f 	cmp	x8, x3
    a3dc:	540000a9 	b.ls	a3f0 <__divti3+0x310>  // b.plast
    a3e0:	ab0300c3 	adds	x3, x6, x3
    a3e4:	d1000542 	sub	x2, x10, #0x1
    a3e8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a3ec:	54000288 	b.hi	a43c <__divti3+0x35c>  // b.pmore
    a3f0:	cb080063 	sub	x3, x3, x8
    a3f4:	aa018041 	orr	x1, x2, x1, lsl #32
    a3f8:	17ffffc2 	b	a300 <__divti3+0x220>
    a3fc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a400:	d2800001 	mov	x1, #0x0                   	// #0
    a404:	9a9f87e0 	cset	x0, ls	// ls = plast
    a408:	17ffff68 	b	a1a8 <__divti3+0xc8>
    a40c:	aa0103e0 	mov	x0, x1
    a410:	d2800001 	mov	x1, #0x0                   	// #0
    a414:	17ffff65 	b	a1a8 <__divti3+0xc8>
    a418:	d1000860 	sub	x0, x3, #0x2
    a41c:	8b0600a5 	add	x5, x5, x6
    a420:	17ffff52 	b	a168 <__divti3+0x88>
    a424:	d1000961 	sub	x1, x11, #0x2
    a428:	8b0800a5 	add	x5, x5, x8
    a42c:	17ffff85 	b	a240 <__divti3+0x160>
    a430:	d1000965 	sub	x5, x11, #0x2
    a434:	8b080063 	add	x3, x3, x8
    a438:	17ffff8e 	b	a270 <__divti3+0x190>
    a43c:	d1000942 	sub	x2, x10, #0x2
    a440:	8b060063 	add	x3, x3, x6
    a444:	17ffffeb 	b	a3f0 <__divti3+0x310>
    a448:	d1000941 	sub	x1, x10, #0x2
    a44c:	8b060000 	add	x0, x0, x6
    a450:	17ffffdc 	b	a3c0 <__divti3+0x2e0>
    a454:	d1000900 	sub	x0, x8, #0x2
    a458:	8b060063 	add	x3, x3, x6
    a45c:	17ffffb4 	b	a32c <__divti3+0x24c>

000000000000a460 <__modti3>:
    a460:	d503245f 	bti	c
    a464:	d2800004 	mov	x4, #0x0                   	// #0
    a468:	b6f80081 	tbz	x1, #63, a478 <__modti3+0x18>
    a46c:	eb0003e0 	negs	x0, x0
    a470:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a474:	da0103e1 	ngc	x1, x1
    a478:	f100007f 	cmp	x3, #0x0
    a47c:	5400128b 	b.lt	a6cc <__modti3+0x26c>  // b.tstop
    a480:	aa0003e7 	mov	x7, x0
    a484:	aa0103e6 	mov	x6, x1
    a488:	540004e1 	b.ne	a524 <__modti3+0xc4>  // b.any
    a48c:	eb02003f 	cmp	x1, x2
    a490:	54000dc2 	b.cs	a648 <__modti3+0x1e8>  // b.hs, b.nlast
    a494:	dac01043 	clz	x3, x2
    a498:	aa0303e5 	mov	x5, x3
    a49c:	b40000e3 	cbz	x3, a4b8 <__modti3+0x58>
    a4a0:	4b0303e6 	neg	w6, w3
    a4a4:	9ac32021 	lsl	x1, x1, x3
    a4a8:	9ac32042 	lsl	x2, x2, x3
    a4ac:	9ac62406 	lsr	x6, x0, x6
    a4b0:	aa0100c6 	orr	x6, x6, x1
    a4b4:	9ac32007 	lsl	x7, x0, x3
    a4b8:	d360fc40 	lsr	x0, x2, #32
    a4bc:	92407c43 	and	x3, x2, #0xffffffff
    a4c0:	9ac008c1 	udiv	x1, x6, x0
    a4c4:	9b009826 	msub	x6, x1, x0, x6
    a4c8:	9b017c61 	mul	x1, x3, x1
    a4cc:	93c780c6 	extr	x6, x6, x7, #32
    a4d0:	eb06003f 	cmp	x1, x6
    a4d4:	540000a9 	b.ls	a4e8 <__modti3+0x88>  // b.plast
    a4d8:	ab060046 	adds	x6, x2, x6
    a4dc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a4e0:	8b0200c8 	add	x8, x6, x2
    a4e4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a4e8:	cb0100c6 	sub	x6, x6, x1
    a4ec:	9ac008c8 	udiv	x8, x6, x0
    a4f0:	9b009901 	msub	x1, x8, x0, x6
    a4f4:	aa0703e0 	mov	x0, x7
    a4f8:	9b087c63 	mul	x3, x3, x8
    a4fc:	b3607c20 	bfi	x0, x1, #32, #32
    a500:	eb00007f 	cmp	x3, x0
    a504:	54001088 	b.hi	a714 <__modti3+0x2b4>  // b.pmore
    a508:	cb030000 	sub	x0, x0, x3
    a50c:	9ac52400 	lsr	x0, x0, x5
    a510:	d2800001 	mov	x1, #0x0                   	// #0
    a514:	b4000064 	cbz	x4, a520 <__modti3+0xc0>
    a518:	eb0003e0 	negs	x0, x0
    a51c:	da0103e1 	ngc	x1, x1
    a520:	d65f03c0 	ret
    a524:	dac01066 	clz	x6, x3
    a528:	eb03003f 	cmp	x1, x3
    a52c:	54ffff43 	b.cc	a514 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a530:	93407cc5 	sxtw	x5, w6
    a534:	d2800808 	mov	x8, #0x40                  	// #64
    a538:	cb050108 	sub	x8, x8, x5
    a53c:	9ac62063 	lsl	x3, x3, x6
    a540:	9ac62025 	lsl	x5, x1, x6
    a544:	9ac82447 	lsr	x7, x2, x8
    a548:	aa0300e7 	orr	x7, x7, x3
    a54c:	9ac82423 	lsr	x3, x1, x8
    a550:	92407cec 	and	x12, x7, #0xffffffff
    a554:	d360fcea 	lsr	x10, x7, #32
    a558:	9ac82401 	lsr	x1, x0, x8
    a55c:	aa050021 	orr	x1, x1, x5
    a560:	9ac62042 	lsl	x2, x2, x6
    a564:	9ac62000 	lsl	x0, x0, x6
    a568:	9aca086b 	udiv	x11, x3, x10
    a56c:	9b0a8d63 	msub	x3, x11, x10, x3
    a570:	aa0b03e5 	mov	x5, x11
    a574:	9b0b7d89 	mul	x9, x12, x11
    a578:	93c18063 	extr	x3, x3, x1, #32
    a57c:	eb03013f 	cmp	x9, x3
    a580:	540000a9 	b.ls	a594 <__modti3+0x134>  // b.plast
    a584:	ab0300e3 	adds	x3, x7, x3
    a588:	d1000565 	sub	x5, x11, #0x1
    a58c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a590:	54001168 	b.hi	a7bc <__modti3+0x35c>  // b.pmore
    a594:	cb090063 	sub	x3, x3, x9
    a598:	9aca086b 	udiv	x11, x3, x10
    a59c:	9b0a8d6a 	msub	x10, x11, x10, x3
    a5a0:	aa0b03e9 	mov	x9, x11
    a5a4:	9b0b7d8c 	mul	x12, x12, x11
    a5a8:	b3607d41 	bfi	x1, x10, #32, #32
    a5ac:	eb01019f 	cmp	x12, x1
    a5b0:	540000a9 	b.ls	a5c4 <__modti3+0x164>  // b.plast
    a5b4:	ab0100e1 	adds	x1, x7, x1
    a5b8:	d1000569 	sub	x9, x11, #0x1
    a5bc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a5c0:	54000f88 	b.hi	a7b0 <__modti3+0x350>  // b.pmore
    a5c4:	aa058123 	orr	x3, x9, x5, lsl #32
    a5c8:	92407c4b 	and	x11, x2, #0xffffffff
    a5cc:	2a0903e9 	mov	w9, w9
    a5d0:	d360fc4a 	lsr	x10, x2, #32
    a5d4:	d360fc63 	lsr	x3, x3, #32
    a5d8:	cb0c0021 	sub	x1, x1, x12
    a5dc:	aa0a03ec 	mov	x12, x10
    a5e0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a5e4:	9b0b7d25 	mul	x5, x9, x11
    a5e8:	9b0b7c6b 	mul	x11, x3, x11
    a5ec:	9b0a2d29 	madd	x9, x9, x10, x11
    a5f0:	92407caa 	and	x10, x5, #0xffffffff
    a5f4:	9b0c7c63 	mul	x3, x3, x12
    a5f8:	8b458125 	add	x5, x9, x5, lsr #32
    a5fc:	8b0d0069 	add	x9, x3, x13
    a600:	eb05017f 	cmp	x11, x5
    a604:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a608:	8b058149 	add	x9, x10, x5, lsl #32
    a60c:	8b458063 	add	x3, x3, x5, lsr #32
    a610:	eb03003f 	cmp	x1, x3
    a614:	54000063 	b.cc	a620 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a618:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a61c:	54000082 	b.cs	a62c <__modti3+0x1cc>  // b.hs, b.nlast
    a620:	eb020129 	subs	x9, x9, x2
    a624:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a628:	cb070063 	sub	x3, x3, x7
    a62c:	eb090000 	subs	x0, x0, x9
    a630:	da030021 	sbc	x1, x1, x3
    a634:	9ac62400 	lsr	x0, x0, x6
    a638:	9ac82028 	lsl	x8, x1, x8
    a63c:	aa000100 	orr	x0, x8, x0
    a640:	9ac62421 	lsr	x1, x1, x6
    a644:	17ffffb4 	b	a514 <__modti3+0xb4>
    a648:	b5000062 	cbnz	x2, a654 <__modti3+0x1f4>
    a64c:	d2800023 	mov	x3, #0x1                   	// #1
    a650:	9ac20862 	udiv	x2, x3, x2
    a654:	dac01048 	clz	x8, x2
    a658:	aa0803e5 	mov	x5, x8
    a65c:	b5000668 	cbnz	x8, a728 <__modti3+0x2c8>
    a660:	cb020020 	sub	x0, x1, x2
    a664:	d360fc49 	lsr	x9, x2, #32
    a668:	92407c4a 	and	x10, x2, #0xffffffff
    a66c:	9ac90801 	udiv	x1, x0, x9
    a670:	9b098020 	msub	x0, x1, x9, x0
    a674:	9b0a7c21 	mul	x1, x1, x10
    a678:	93c78000 	extr	x0, x0, x7, #32
    a67c:	eb00003f 	cmp	x1, x0
    a680:	540000a9 	b.ls	a694 <__modti3+0x234>  // b.plast
    a684:	ab000040 	adds	x0, x2, x0
    a688:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a68c:	8b020003 	add	x3, x0, x2
    a690:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a694:	cb010001 	sub	x1, x0, x1
    a698:	9ac90820 	udiv	x0, x1, x9
    a69c:	9b098403 	msub	x3, x0, x9, x1
    a6a0:	aa0703e1 	mov	x1, x7
    a6a4:	9b0a7c00 	mul	x0, x0, x10
    a6a8:	b3607c61 	bfi	x1, x3, #32, #32
    a6ac:	eb01001f 	cmp	x0, x1
    a6b0:	540000a9 	b.ls	a6c4 <__modti3+0x264>  // b.plast
    a6b4:	ab010041 	adds	x1, x2, x1
    a6b8:	8b020022 	add	x2, x1, x2
    a6bc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a6c0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a6c4:	cb000020 	sub	x0, x1, x0
    a6c8:	17ffff91 	b	a50c <__modti3+0xac>
    a6cc:	eb0203e5 	negs	x5, x2
    a6d0:	aa0003e7 	mov	x7, x0
    a6d4:	da0303e8 	ngc	x8, x3
    a6d8:	aa0503e2 	mov	x2, x5
    a6dc:	aa0803e3 	mov	x3, x8
    a6e0:	aa0103e6 	mov	x6, x1
    a6e4:	b4ffed48 	cbz	x8, a48c <__modti3+0x2c>
    a6e8:	eb01011f 	cmp	x8, x1
    a6ec:	54fff148 	b.hi	a514 <__modti3+0xb4>  // b.pmore
    a6f0:	dac01109 	clz	x9, x8
    a6f4:	2a0903e6 	mov	w6, w9
    a6f8:	b5fff1c9 	cbnz	x9, a530 <__modti3+0xd0>
    a6fc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    a700:	54000068 	b.hi	a70c <__modti3+0x2ac>  // b.pmore
    a704:	eb050007 	subs	x7, x0, x5
    a708:	da080021 	sbc	x1, x1, x8
    a70c:	aa0703e0 	mov	x0, x7
    a710:	17ffff81 	b	a514 <__modti3+0xb4>
    a714:	ab000040 	adds	x0, x2, x0
    a718:	8b020002 	add	x2, x0, x2
    a71c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    a720:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    a724:	17ffff79 	b	a508 <__modti3+0xa8>
    a728:	9ac82042 	lsl	x2, x2, x8
    a72c:	d2800803 	mov	x3, #0x40                  	// #64
    a730:	cb080063 	sub	x3, x3, x8
    a734:	d360fc49 	lsr	x9, x2, #32
    a738:	9ac82027 	lsl	x7, x1, x8
    a73c:	92407c4a 	and	x10, x2, #0xffffffff
    a740:	9ac32426 	lsr	x6, x1, x3
    a744:	9ac32403 	lsr	x3, x0, x3
    a748:	aa070063 	orr	x3, x3, x7
    a74c:	9ac908c1 	udiv	x1, x6, x9
    a750:	9ac82007 	lsl	x7, x0, x8
    a754:	9b099820 	msub	x0, x1, x9, x6
    a758:	9b017d41 	mul	x1, x10, x1
    a75c:	93c38000 	extr	x0, x0, x3, #32
    a760:	eb00003f 	cmp	x1, x0
    a764:	540000a9 	b.ls	a778 <__modti3+0x318>  // b.plast
    a768:	ab000040 	adds	x0, x2, x0
    a76c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a770:	8b020006 	add	x6, x0, x2
    a774:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    a778:	cb010000 	sub	x0, x0, x1
    a77c:	9ac90801 	udiv	x1, x0, x9
    a780:	9b098026 	msub	x6, x1, x9, x0
    a784:	aa0303e0 	mov	x0, x3
    a788:	9b017d41 	mul	x1, x10, x1
    a78c:	b3607cc0 	bfi	x0, x6, #32, #32
    a790:	eb00003f 	cmp	x1, x0
    a794:	540000a9 	b.ls	a7a8 <__modti3+0x348>  // b.plast
    a798:	ab000040 	adds	x0, x2, x0
    a79c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a7a0:	8b020003 	add	x3, x0, x2
    a7a4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a7a8:	cb010000 	sub	x0, x0, x1
    a7ac:	17ffffb0 	b	a66c <__modti3+0x20c>
    a7b0:	d1000969 	sub	x9, x11, #0x2
    a7b4:	8b070021 	add	x1, x1, x7
    a7b8:	17ffff83 	b	a5c4 <__modti3+0x164>
    a7bc:	d1000965 	sub	x5, x11, #0x2
    a7c0:	8b070063 	add	x3, x3, x7
    a7c4:	17ffff74 	b	a594 <__modti3+0x134>
    a7c8:	d503201f 	nop
    a7cc:	d503201f 	nop

000000000000a7d0 <atexit>:
    a7d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a7d4:	d00000a2 	adrp	x2, 20000 <__data_start>
    a7d8:	d2800001 	mov	x1, #0x0                   	// #0
    a7dc:	910003fd 	mov	x29, sp
    a7e0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a7e4:	f9400442 	ldr	x2, [x2, #8]
    a7e8:	17ffdfc2 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a7ec <_fini>:
    a7ec:	d503201f 	nop
    a7f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a7f4:	910003fd 	mov	x29, sp
    a7f8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a7fc:	d65f03c0 	ret
