
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <__divti3+0xb0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912720a5 	add	x5, x5, #0x9c8
    2aa0:	f0000024 	adrp	x4, 9000 <__divti3+0xb0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91274084 	add	x4, x4, #0x9d0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x127c8>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <__divti3+0xb0>
    2b34:	91390000 	add	x0, x0, #0xe40
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xcac>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	910d0042 	add	x2, x2, #0x340
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943d260 	ldr	w0, [x19, #976]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000020 	adrp	x0, 9000 <__divti3+0xb0>
    2c7c:	91394000 	add	x0, x0, #0xe50
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000020 	adrp	x0, 9000 <__divti3+0xb0>
    2c8c:	913bc000 	add	x0, x0, #0xef0
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000020 	adrp	x0, 9000 <__divti3+0xb0>
    2ca4:	913b2000 	add	x0, x0, #0xec8
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000020 	adrp	x0, 9000 <__divti3+0xb0>
    2cb0:	913a6000 	add	x0, x0, #0xe98
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000020 	adrp	x0, 9000 <__divti3+0xb0>
    2cbc:	9139c000 	add	x0, x0, #0xe70
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	9100e000 	add	x0, x0, #0x38
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	9100e021 	add	x1, x1, #0x38
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	9100e000 	add	x0, x0, #0x38
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	9100e021 	add	x1, x1, #0x38
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x990>
    2eb4:	91150021 	add	x1, x1, #0x540
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x990>
    3158:	91148021 	add	x1, x1, #0x520
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3190:	9119e000 	add	x0, x0, #0x678
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    31c4:	911882a1 	add	x1, x21, #0x620
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    31d8:	912840a5 	add	x5, x5, #0xa10
    31dc:	911882a1 	add	x1, x21, #0x620
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	911882b7 	add	x23, x21, #0x620
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	911882b5 	add	x21, x21, #0x620
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	911882b5 	add	x21, x21, #0x620
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    3368:	912820a5 	add	x5, x5, #0xa08
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000022 	adrp	x2, 9000 <__divti3+0xb0>
    339c:	911a4042 	add	x2, x2, #0x690
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000022 	adrp	x2, 9000 <__divti3+0xb0>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	911ba042 	add	x2, x2, #0x6e8
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000039 	adrp	x25, 9000 <__divti3+0xb0>
    3428:	d000003a 	adrp	x26, 9000 <__divti3+0xb0>
    342c:	911d2339 	add	x25, x25, #0x748
    3430:	911ac35a 	add	x26, x26, #0x6b0
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000003b 	adrp	x27, 9000 <__divti3+0xb0>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	911ae377 	add	x23, x27, #0x6b8
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	911e2000 	add	x0, x0, #0x788
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbc0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbc0>
    34fc:	d0000023 	adrp	x3, 9000 <__divti3+0xb0>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000035 	adrp	x21, 9000 <__divti3+0xb0>
    3508:	f9422024 	ldr	x4, [x1, #1088]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f94224a5 	ldr	x5, [x5, #1096]
    3514:	91110033 	add	x19, x1, #0x440
    3518:	f9422846 	ldr	x6, [x2, #1104]
    351c:	911ac063 	add	x3, x3, #0x6b0
    3520:	911e82b5 	add	x21, x21, #0x7a0
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	911f8000 	add	x0, x0, #0x7e0
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    35ac:	911b0000 	add	x0, x0, #0x6c0
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    366c:	9119e000 	add	x0, x0, #0x678
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000021 	adrp	x1, 9000 <__divti3+0xb0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	911fa021 	add	x1, x1, #0x7e8
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000021 	adrp	x1, 9000 <__divti3+0xb0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	911fc021 	add	x1, x1, #0x7f0
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000021 	adrp	x1, 9000 <__divti3+0xb0>
    37e0:	911fe021 	add	x1, x1, #0x7f8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000022 	adrp	x2, 9000 <__divti3+0xb0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91200042 	add	x2, x2, #0x800
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3950:	9119e000 	add	x0, x0, #0x678
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3970:	91204000 	add	x0, x0, #0x810
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3a08:	9120c000 	add	x0, x0, #0x830
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3a18:	91214000 	add	x0, x0, #0x850
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x990>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc15420 	ldr	q0, [x1, #1360]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3b18:	9121e000 	add	x0, x0, #0x878
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3b88:	9122a000 	add	x0, x0, #0x8a8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000024 	adrp	x4, 9000 <__divti3+0xb0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	9123e084 	add	x4, x4, #0x8f8
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000024 	adrp	x4, 9000 <__divti3+0xb0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	91244084 	add	x4, x4, #0x910
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000024 	adrp	x4, 9000 <__divti3+0xb0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91240084 	add	x4, x4, #0x900
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    3fa8:	91188042 	add	x2, x2, #0x620
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000021 	adrp	x1, 9000 <__divti3+0xb0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000020 	adrp	x0, 9000 <__divti3+0xb0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	91246021 	add	x1, x1, #0x918
    4004:	91248000 	add	x0, x0, #0x920
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000022 	adrp	x2, 9000 <__divti3+0xb0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91250042 	add	x2, x2, #0x940
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9e0>
    410c:	91148061 	add	x1, x3, #0x520
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    411c:	91188262 	add	x2, x19, #0x620
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000022 	adrp	x2, a000 <_IO_stdin_used+0x990>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9e0>
    414c:	91158021 	add	x1, x1, #0x560
    4150:	3dc15843 	ldr	q3, [x2, #1376]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9e0>
    417c:	91148063 	add	x3, x3, #0x520
    4180:	91170084 	add	x4, x4, #0x5c0
    4184:	91188266 	add	x6, x19, #0x620
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	91188275 	add	x21, x19, #0x620
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4268:	9127c000 	add	x0, x0, #0x9f0
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	91188273 	add	x19, x19, #0x620
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	91014122 	add	x2, x9, #0x50
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9406046 	ldr	x6, [x2, #192]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	91014120 	add	x0, x9, #0x50
    4354:	f900640b 	str	x11, [x0, #200]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	91014129 	add	x9, x9, #0x50
    4360:	f9006126 	str	x6, [x9, #192]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <ad_raw_free.part.0>:
    4380:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbc0>
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	91110082 	add	x2, x4, #0x440
    438c:	14000005 	b	43a0 <ad_raw_free.part.0+0x20>
    4390:	91000421 	add	x1, x1, #0x1
    4394:	91006042 	add	x2, x2, #0x18
    4398:	f140043f 	cmp	x1, #0x1, lsl #12
    439c:	54000220 	b.eq	43e0 <ad_raw_free.part.0+0x60>  // b.none
    43a0:	f9400043 	ldr	x3, [x2]
    43a4:	eb03001f 	cmp	x0, x3
    43a8:	54ffff41 	b.ne	4390 <ad_raw_free.part.0+0x10>  // b.any
    43ac:	8b010421 	add	x1, x1, x1, lsl #1
    43b0:	91110084 	add	x4, x4, #0x440
    43b4:	900000e2 	adrp	x2, 20000 <__data_start>
    43b8:	91014042 	add	x2, x2, #0x50
    43bc:	8b010c81 	add	x1, x4, x1, lsl #3
    43c0:	b9401024 	ldr	w4, [x1, #16]
    43c4:	f9400425 	ldr	x5, [x1, #8]
    43c8:	a9007c3f 	stp	xzr, xzr, [x1]
    43cc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43d0:	f900083f 	str	xzr, [x1, #16]
    43d4:	cb050061 	sub	x1, x3, x5
    43d8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43dc:	17fff961 	b	2960 <free@plt>
    43e0:	f100001f 	cmp	x0, #0x0
    43e4:	b0000021 	adrp	x1, 9000 <__divti3+0xb0>
    43e8:	91286021 	add	x1, x1, #0xa18
    43ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43f0:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    43f4:	91280000 	add	x0, x0, #0xa00
    43f8:	910003fd 	mov	x29, sp
    43fc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4400:	97fffbe0 	bl	3380 <ad_raw_fail>

0000000000004404 <fwp_tape_buffers_dispose>:
    4404:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4408:	910003fd 	mov	x29, sp
    440c:	f9000bf3 	str	x19, [sp, #16]
    4410:	aa0003f3 	mov	x19, x0
    4414:	f9400000 	ldr	x0, [x0]
    4418:	b4000040 	cbz	x0, 4420 <fwp_tape_buffers_dispose+0x1c>
    441c:	97ffffd9 	bl	4380 <ad_raw_free.part.0>
    4420:	f9400a60 	ldr	x0, [x19, #16]
    4424:	b4000040 	cbz	x0, 442c <fwp_tape_buffers_dispose+0x28>
    4428:	97ffffd6 	bl	4380 <ad_raw_free.part.0>
    442c:	f9401260 	ldr	x0, [x19, #32]
    4430:	b4000040 	cbz	x0, 4438 <fwp_tape_buffers_dispose+0x34>
    4434:	97ffffd3 	bl	4380 <ad_raw_free.part.0>
    4438:	4f000400 	movi	v0.4s, #0x0
    443c:	f9001a7f 	str	xzr, [x19, #48]
    4440:	ad000260 	stp	q0, q0, [x19]
    4444:	3d800a60 	str	q0, [x19, #32]
    4448:	f9400bf3 	ldr	x19, [sp, #16]
    444c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4450:	d65f03c0 	ret

0000000000004454 <ad_raw_realloc>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	f90013f5 	str	x21, [sp, #32]
    4464:	b40005a1 	cbz	x1, 4518 <ad_raw_realloc+0xc4>
    4468:	aa0103f4 	mov	x20, x1
    446c:	2a0203f5 	mov	w21, w2
    4470:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbc0>
    4474:	d2800004 	mov	x4, #0x0                   	// #0
    4478:	91110025 	add	x5, x1, #0x440
    447c:	14000005 	b	4490 <ad_raw_realloc+0x3c>
    4480:	91000484 	add	x4, x4, #0x1
    4484:	910060a5 	add	x5, x5, #0x18
    4488:	f140049f 	cmp	x4, #0x1, lsl #12
    448c:	54000320 	b.eq	44f0 <ad_raw_realloc+0x9c>  // b.none
    4490:	f94000a6 	ldr	x6, [x5]
    4494:	eb06001f 	cmp	x0, x6
    4498:	54ffff41 	b.ne	4480 <ad_raw_realloc+0x2c>  // b.any
    449c:	8b040484 	add	x4, x4, x4, lsl #1
    44a0:	91110021 	add	x1, x1, #0x440
    44a4:	8b040c33 	add	x19, x1, x4, lsl #3
    44a8:	b4000080 	cbz	x0, 44b8 <ad_raw_realloc+0x64>
    44ac:	b9401261 	ldr	w1, [x19, #16]
    44b0:	6b15003f 	cmp	w1, w21
    44b4:	540002c1 	b.ne	450c <ad_raw_realloc+0xb8>  // b.any
    44b8:	aa1403e1 	mov	x1, x20
    44bc:	97fff8f5 	bl	2890 <realloc@plt>
    44c0:	aa0003ed 	mov	x13, x0
    44c4:	b40000c0 	cbz	x0, 44dc <ad_raw_realloc+0x88>
    44c8:	2a1503e3 	mov	w3, w21
    44cc:	aa1403e2 	mov	x2, x20
    44d0:	aa1303e0 	mov	x0, x19
    44d4:	aa0d03e1 	mov	x1, x13
    44d8:	97fffaae 	bl	2f90 <ad_raw_record>
    44dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e0:	aa0d03e0 	mov	x0, x13
    44e4:	f94013f5 	ldr	x21, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f100001f 	cmp	x0, #0x0
    44f4:	b0000021 	adrp	x1, 9000 <__divti3+0xb0>
    44f8:	91286021 	add	x1, x1, #0xa18
    44fc:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4500:	91280000 	add	x0, x0, #0xa00
    4504:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4508:	97fffb9e 	bl	3380 <ad_raw_fail>
    450c:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4510:	91296000 	add	x0, x0, #0xa58
    4514:	97fffb9b 	bl	3380 <ad_raw_fail>
    4518:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    451c:	9128e000 	add	x0, x0, #0xa38
    4520:	97fffb98 	bl	3380 <ad_raw_fail>

0000000000004524 <fwp_tape_buffers_release>:
    4524:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4528:	910003fd 	mov	x29, sp
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	aa0003f4 	mov	x20, x0
    4534:	f9401400 	ldr	x0, [x0, #40]
    4538:	a9025bf5 	stp	x21, x22, [sp, #32]
    453c:	b7f80560 	tbnz	x0, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4540:	f9401a93 	ldr	x19, [x20, #48]
    4544:	b7f80533 	tbnz	x19, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4548:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    454c:	eb01001f 	cmp	x0, x1
    4550:	540004c8 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4554:	8b000400 	add	x0, x0, x0, lsl #1
    4558:	d2a00101 	mov	x1, #0x80000               	// #524288
    455c:	d37df000 	lsl	x0, x0, #3
    4560:	cb000021 	sub	x1, x1, x0
    4564:	eb410e7f 	cmp	x19, x1, lsr #3
    4568:	54000408 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    456c:	8b130c13 	add	x19, x0, x19, lsl #3
    4570:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4574:	9129c000 	add	x0, x0, #0xa70
    4578:	97fff92e 	bl	2a30 <getenv@plt>
    457c:	b4000080 	cbz	x0, 458c <fwp_tape_buffers_release+0x68>
    4580:	39400001 	ldrb	w1, [x0]
    4584:	7100c03f 	cmp	w1, #0x30
    4588:	54000880 	b.eq	4698 <fwp_tape_buffers_release+0x174>  // b.none
    458c:	d1000661 	sub	x1, x19, #0x1
    4590:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4594:	eb00003f 	cmp	x1, x0
    4598:	54000328 	b.hi	45fc <fwp_tape_buffers_release+0xd8>  // b.pmore
    459c:	900000f5 	adrp	x21, 20000 <__data_start>
    45a0:	f9001bf7 	str	x23, [sp, #48]
    45a4:	910142b7 	add	x23, x21, #0x50
    45a8:	910382f6 	add	x22, x23, #0xe0
    45ac:	aa1603e0 	mov	x0, x22
    45b0:	97ffff95 	bl	4404 <fwp_tape_buffers_dispose>
    45b4:	ad400a81 	ldp	q1, q2, [x20]
    45b8:	f9008ef3 	str	x19, [x23, #280]
    45bc:	4f000400 	movi	v0.4s, #0x0
    45c0:	ad000ac1 	stp	q1, q2, [x22]
    45c4:	3dc00a81 	ldr	q1, [x20, #32]
    45c8:	3d800ac1 	str	q1, [x22, #32]
    45cc:	f9401a80 	ldr	x0, [x20, #48]
    45d0:	f9001ac0 	str	x0, [x22, #48]
    45d4:	f9001a9f 	str	xzr, [x20, #48]
    45d8:	ad000280 	stp	q0, q0, [x20]
    45dc:	3d800a80 	str	q0, [x20, #32]
    45e0:	f9401bf7 	ldr	x23, [sp, #48]
    45e4:	1400000b 	b	4610 <fwp_tape_buffers_release+0xec>
    45e8:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    45ec:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45f0:	9129c000 	add	x0, x0, #0xa70
    45f4:	97fff90f 	bl	2a30 <getenv@plt>
    45f8:	b5fffc40 	cbnz	x0, 4580 <fwp_tape_buffers_release+0x5c>
    45fc:	aa1403e0 	mov	x0, x20
    4600:	97ffff81 	bl	4404 <fwp_tape_buffers_dispose>
    4604:	900000f5 	adrp	x21, 20000 <__data_start>
    4608:	910142a0 	add	x0, x21, #0x50
    460c:	f9408c13 	ldr	x19, [x0, #280]
    4610:	910142a2 	add	x2, x21, #0x50
    4614:	f9409044 	ldr	x4, [x2, #288]
    4618:	a9400c45 	ldp	x5, x3, [x2]
    461c:	8b040481 	add	x1, x4, x4, lsl #1
    4620:	f9400840 	ldr	x0, [x2, #16]
    4624:	8b010881 	add	x1, x4, x1, lsl #2
    4628:	f9400c44 	ldr	x4, [x2, #24]
    462c:	8b0300a3 	add	x3, x5, x3
    4630:	d37df021 	lsl	x1, x1, #3
    4634:	8b040000 	add	x0, x0, x4
    4638:	8b030000 	add	x0, x0, x3
    463c:	eb05003f 	cmp	x1, x5
    4640:	54000321 	b.ne	46a4 <fwp_tape_buffers_release+0x180>  // b.any
    4644:	8b130023 	add	x3, x1, x19
    4648:	eb00007f 	cmp	x3, x0
    464c:	540002c8 	b.hi	46a4 <fwp_tape_buffers_release+0x180>  // b.pmore
    4650:	f9405c43 	ldr	x3, [x2, #184]
    4654:	f140087f 	cmp	x3, #0x2, lsl #12
    4658:	540002e0 	b.eq	46b4 <fwp_tape_buffers_release+0x190>  // b.none
    465c:	8b030464 	add	x4, x3, x3, lsl #1
    4660:	90000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    4664:	911100a5 	add	x5, x5, #0x440
    4668:	cb010000 	sub	x0, x0, x1
    466c:	d37df084 	lsl	x4, x4, #3
    4670:	cb130000 	sub	x0, x0, x19
    4674:	8b0400a6 	add	x6, x5, x4
    4678:	91000463 	add	x3, x3, #0x1
    467c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4680:	f82468a1 	str	x1, [x5, x4]
    4684:	a90080d3 	stp	x19, x0, [x6, #8]
    4688:	f9005c43 	str	x3, [x2, #184]
    468c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4694:	d65f03c0 	ret
    4698:	39400400 	ldrb	w0, [x0, #1]
    469c:	34fffb00 	cbz	w0, 45fc <fwp_tape_buffers_release+0xd8>
    46a0:	17ffffbb 	b	458c <fwp_tape_buffers_release+0x68>
    46a4:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    46a8:	912a2000 	add	x0, x0, #0xa88
    46ac:	f9001bf7 	str	x23, [sp, #48]
    46b0:	97fffb34 	bl	3380 <ad_raw_fail>
    46b4:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    46b8:	912ae000 	add	x0, x0, #0xab8
    46bc:	f9001bf7 	str	x23, [sp, #48]
    46c0:	97fffb30 	bl	3380 <ad_raw_fail>

00000000000046c4 <fwp_poll_events>:
    46c4:	d10103ff 	sub	sp, sp, #0x40
    46c8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    46cc:	f947f400 	ldr	x0, [x0, #4072]
    46d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46d4:	910083fd 	add	x29, sp, #0x20
    46d8:	a90353f3 	stp	x19, x20, [sp, #48]
    46dc:	900000f4 	adrp	x20, 20000 <__data_start>
    46e0:	f9400001 	ldr	x1, [x0]
    46e4:	f9000fe1 	str	x1, [sp, #24]
    46e8:	d2800001 	mov	x1, #0x0                   	// #0
    46ec:	97fffca5 	bl	3980 <fwp_now_ns>
    46f0:	91014281 	add	x1, x20, #0x50
    46f4:	f9409433 	ldr	x19, [x1, #296]
    46f8:	b4000e73 	cbz	x19, 48c4 <fwp_poll_events+0x200>
    46fc:	aa1303e1 	mov	x1, x19
    4700:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4704:	14000005 	b	4718 <fwp_poll_events+0x54>
    4708:	f9408821 	ldr	x1, [x1, #272]
    470c:	eb03005f 	cmp	x2, x3
    4710:	9a83d042 	csel	x2, x2, x3, le
    4714:	b40000c1 	cbz	x1, 472c <fwp_poll_events+0x68>
    4718:	f9403423 	ldr	x3, [x1, #104]
    471c:	b6ffff62 	tbz	x2, #63, 4708 <fwp_poll_events+0x44>
    4720:	f9408821 	ldr	x1, [x1, #272]
    4724:	aa0303e2 	mov	x2, x3
    4728:	b5ffff81 	cbnz	x1, 4718 <fwp_poll_events+0x54>
    472c:	b7f80cc2 	tbnz	x2, #63, 48c4 <fwp_poll_events+0x200>
    4730:	cb000042 	sub	x2, x2, x0
    4734:	f100005f 	cmp	x2, #0x0
    4738:	540005ad 	b.le	47ec <fwp_poll_events+0x128>
    473c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4740:	d2884801 	mov	x1, #0x4240                	// #16960
    4744:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4748:	f2a001e1 	movk	x1, #0xf, lsl #16
    474c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4750:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4754:	f2e86360 	movk	x0, #0x431b, lsl #48
    4758:	9b407c40 	smulh	x0, x2, x0
    475c:	9352fc00 	asr	x0, x0, #18
    4760:	cb82fc00 	sub	x0, x0, x2, asr #63
    4764:	9b018802 	msub	x2, x0, x1, x2
    4768:	f100005f 	cmp	x2, #0x0
    476c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4770:	eb03001f 	cmp	x0, x3
    4774:	540009ec 	b.gt	48b0 <fwp_poll_events+0x1ec>
    4778:	340003a0 	cbz	w0, 47ec <fwp_poll_events+0x128>
    477c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4780:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4784:	72a20c42 	movk	w2, #0x1062, lsl #16
    4788:	9ba27c02 	umull	x2, w0, w2
    478c:	d366fc43 	lsr	x3, x2, #38
    4790:	aa0303e2 	mov	x2, x3
    4794:	1b048063 	msub	w3, w3, w4, w0
    4798:	9b217c63 	smull	x3, w3, w1
    479c:	d2800001 	mov	x1, #0x0                   	// #0
    47a0:	910023e0 	add	x0, sp, #0x8
    47a4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47a8:	97fff872 	bl	2970 <nanosleep@plt>
    47ac:	91014280 	add	x0, x20, #0x50
    47b0:	f9409413 	ldr	x19, [x0, #296]
    47b4:	97fffc73 	bl	3980 <fwp_now_ns>
    47b8:	aa0003e6 	mov	x6, x0
    47bc:	b50001d3 	cbnz	x19, 47f4 <fwp_poll_events+0x130>
    47c0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    47c4:	f947f400 	ldr	x0, [x0, #4072]
    47c8:	f9400fe2 	ldr	x2, [sp, #24]
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	eb010042 	subs	x2, x2, x1
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	540008c1 	b.ne	48f0 <fwp_poll_events+0x22c>  // b.any
    47dc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47e4:	910103ff 	add	sp, sp, #0x40
    47e8:	d65f03c0 	ret
    47ec:	97fffc65 	bl	3980 <fwp_now_ns>
    47f0:	aa0003e6 	mov	x6, x0
    47f4:	4f000400 	movi	v0.4s, #0x0
    47f8:	91014288 	add	x8, x20, #0x50
    47fc:	52800027 	mov	w7, #0x1                   	// #1
    4800:	f9403661 	ldr	x1, [x19, #104]
    4804:	aa1303e5 	mov	x5, x19
    4808:	f9408a73 	ldr	x19, [x19, #272]
    480c:	eb06003f 	cmp	x1, x6
    4810:	5400032c 	b.gt	4874 <fwp_poll_events+0x1b0>
    4814:	394154a0 	ldrb	w0, [x5, #85]
    4818:	36000120 	tbz	w0, #0, 483c <fwp_poll_events+0x178>
    481c:	f94084a0 	ldr	x0, [x5, #264]
    4820:	b40003c0 	cbz	x0, 4898 <fwp_poll_events+0x1d4>
    4824:	f9008813 	str	x19, [x0, #272]
    4828:	b4000053 	cbz	x19, 4830 <fwp_poll_events+0x16c>
    482c:	f9008660 	str	x0, [x19, #264]
    4830:	910800a0 	add	x0, x5, #0x200
    4834:	390154bf 	strb	wzr, [x5, #85]
    4838:	3c908000 	stur	q0, [x0, #-248]
    483c:	f94030a0 	ldr	x0, [x5, #96]
    4840:	390158a7 	strb	w7, [x5, #86]
    4844:	f100001f 	cmp	x0, #0x0
    4848:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    484c:	5400018d 	b.le	487c <fwp_poll_events+0x1b8>
    4850:	f94028a0 	ldr	x0, [x5, #80]
    4854:	f2001c1f 	tst	x0, #0xff000000ff
    4858:	540000e1 	b.ne	4874 <fwp_poll_events+0x1b0>  // b.any
    485c:	f9406100 	ldr	x0, [x8, #192]
    4860:	390150a7 	strb	w7, [x5, #84]
    4864:	f90080bf 	str	xzr, [x5, #256]
    4868:	b40001e0 	cbz	x0, 48a4 <fwp_poll_events+0x1e0>
    486c:	f9006105 	str	x5, [x8, #192]
    4870:	f9008005 	str	x5, [x0, #256]
    4874:	b5fffc73 	cbnz	x19, 4800 <fwp_poll_events+0x13c>
    4878:	17ffffd2 	b	47c0 <fwp_poll_events+0xfc>
    487c:	394144a0 	ldrb	w0, [x5, #81]
    4880:	3707fe80 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    4884:	394140a0 	ldrb	w0, [x5, #80]
    4888:	3707fe40 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    488c:	aa0503e0 	mov	x0, x5
    4890:	97fffb98 	bl	36f0 <fwp_cancel_tree.part.0>
    4894:	17ffffef 	b	4850 <fwp_poll_events+0x18c>
    4898:	91014281 	add	x1, x20, #0x50
    489c:	f9009433 	str	x19, [x1, #296]
    48a0:	17ffffe2 	b	4828 <fwp_poll_events+0x164>
    48a4:	f9006105 	str	x5, [x8, #192]
    48a8:	f9006505 	str	x5, [x8, #200]
    48ac:	17fffff2 	b	4874 <fwp_poll_events+0x1b0>
    48b0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    48b4:	d2989362 	mov	x2, #0xc49b                	// #50331
    48b8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    48bc:	f2a00402 	movk	x2, #0x20, lsl #16
    48c0:	17ffffb7 	b	479c <fwp_poll_events+0xd8>
    48c4:	97fff9ec 	bl	3074 <fwp_flush>
    48c8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    48cc:	f947e863 	ldr	x3, [x3, #4048]
    48d0:	d2800562 	mov	x2, #0x2b                  	// #43
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    48dc:	912b6000 	add	x0, x0, #0xad8
    48e0:	f9400063 	ldr	x3, [x3]
    48e4:	97fff82f 	bl	29a0 <fwrite@plt>
    48e8:	52800ca0 	mov	w0, #0x65                  	// #101
    48ec:	97fff799 	bl	2750 <exit@plt>
    48f0:	97fff7ec 	bl	28a0 <__stack_chk_fail@plt>

00000000000048f4 <fwp_rc_wide_dup>:
    48f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48f8:	910003fd 	mov	x29, sp
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f3 	mov	x19, x0
    4904:	ca404400 	eor	x0, x0, x0, lsr #17
    4908:	f90013f5 	str	x21, [sp, #32]
    490c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4910:	ca402400 	eor	x0, x0, x0, lsr #9
    4914:	911882a2 	add	x2, x21, #0x620
    4918:	92401c00 	and	x0, x0, #0xff
    491c:	910a2403 	add	x3, x0, #0x289
    4920:	8b000c40 	add	x0, x2, x0, lsl #3
    4924:	8b030c54 	add	x20, x2, x3, lsl #3
    4928:	f94a2401 	ldr	x1, [x0, #5192]
    492c:	b50000a1 	cbnz	x1, 4940 <fwp_rc_wide_dup+0x4c>
    4930:	1400002d 	b	49e4 <fwp_rc_wide_dup+0xf0>
    4934:	91004034 	add	x20, x1, #0x10
    4938:	f9400821 	ldr	x1, [x1, #16]
    493c:	b4000241 	cbz	x1, 4984 <fwp_rc_wide_dup+0x90>
    4940:	f9400022 	ldr	x2, [x1]
    4944:	eb02027f 	cmp	x19, x2
    4948:	54ffff61 	b.ne	4934 <fwp_rc_wide_dup+0x40>  // b.any
    494c:	f9400281 	ldr	x1, [x20]
    4950:	39400260 	ldrb	w0, [x19]
    4954:	7103f81f 	cmp	w0, #0xfe
    4958:	54000220 	b.eq	499c <fwp_rc_wide_dup+0xa8>  // b.none
    495c:	b40001a1 	cbz	x1, 4990 <fwp_rc_wide_dup+0x9c>
    4960:	f9400420 	ldr	x0, [x1, #8]
    4964:	b100041f 	cmn	x0, #0x1
    4968:	540004a0 	b.eq	49fc <fwp_rc_wide_dup+0x108>  // b.none
    496c:	91000400 	add	x0, x0, #0x1
    4970:	f9000420 	str	x0, [x1, #8]
    4974:	a94153f3 	ldp	x19, x20, [sp, #16]
    4978:	f94013f5 	ldr	x21, [sp, #32]
    497c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4980:	d65f03c0 	ret
    4984:	39400260 	ldrb	w0, [x19]
    4988:	7103f81f 	cmp	w0, #0xfe
    498c:	540000a0 	b.eq	49a0 <fwp_rc_wide_dup+0xac>  // b.none
    4990:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4994:	912cc000 	add	x0, x0, #0xb30
    4998:	97fffb9a 	bl	3800 <fwp_trap>
    499c:	b5000281 	cbnz	x1, 49ec <fwp_rc_wide_dup+0xf8>
    49a0:	d2800300 	mov	x0, #0x18                  	// #24
    49a4:	97fff7a7 	bl	2840 <malloc@plt>
    49a8:	b4000280 	cbz	x0, 49f8 <fwp_rc_wide_dup+0x104>
    49ac:	d2801fe1 	mov	x1, #0xff                  	// #255
    49b0:	a9000413 	stp	x19, x1, [x0]
    49b4:	911882b5 	add	x21, x21, #0x620
    49b8:	f900081f 	str	xzr, [x0, #16]
    49bc:	12800001 	mov	w1, #0xffffffff            	// #-1
    49c0:	f9000280 	str	x0, [x20]
    49c4:	39000261 	strb	w1, [x19]
    49c8:	f94e26a0 	ldr	x0, [x21, #7240]
    49cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    49d0:	91000400 	add	x0, x0, #0x1
    49d4:	f90e26a0 	str	x0, [x21, #7240]
    49d8:	f94013f5 	ldr	x21, [sp, #32]
    49dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49e0:	d65f03c0 	ret
    49e4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49e8:	17ffffda 	b	4950 <fwp_rc_wide_dup+0x5c>
    49ec:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    49f0:	912c2000 	add	x0, x0, #0xb08
    49f4:	97fffb83 	bl	3800 <fwp_trap>
    49f8:	97fff9de 	bl	3170 <fwp_heap_oom>
    49fc:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4a00:	912d6000 	add	x0, x0, #0xb58
    4a04:	97fffb7f 	bl	3800 <fwp_trap>
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_rc_forget_slot>:
    4a10:	aa0003e1 	mov	x1, x0
    4a14:	39400000 	ldrb	w0, [x0]
    4a18:	7103fc1f 	cmp	w0, #0xff
    4a1c:	54000040 	b.eq	4a24 <fwp_rc_forget_slot+0x14>  // b.none
    4a20:	d65f03c0 	ret
    4a24:	ca414420 	eor	x0, x1, x1, lsr #17
    4a28:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a30:	910003fd 	mov	x29, sp
    4a34:	92401c00 	and	x0, x0, #0xff
    4a38:	f9000bf3 	str	x19, [sp, #16]
    4a3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4a40:	91188262 	add	x2, x19, #0x620
    4a44:	910a2403 	add	x3, x0, #0x289
    4a48:	8b000c40 	add	x0, x2, x0, lsl #3
    4a4c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a50:	f94a2400 	ldr	x0, [x0, #5192]
    4a54:	b50000a0 	cbnz	x0, 4a68 <fwp_rc_forget_slot+0x58>
    4a58:	14000011 	b	4a9c <fwp_rc_forget_slot+0x8c>
    4a5c:	91004003 	add	x3, x0, #0x10
    4a60:	f9400800 	ldr	x0, [x0, #16]
    4a64:	b40001c0 	cbz	x0, 4a9c <fwp_rc_forget_slot+0x8c>
    4a68:	f9400002 	ldr	x2, [x0]
    4a6c:	eb02003f 	cmp	x1, x2
    4a70:	54ffff61 	b.ne	4a5c <fwp_rc_forget_slot+0x4c>  // b.any
    4a74:	f9400801 	ldr	x1, [x0, #16]
    4a78:	91188273 	add	x19, x19, #0x620
    4a7c:	f9000061 	str	x1, [x3]
    4a80:	97fff7b8 	bl	2960 <free@plt>
    4a84:	f94e2660 	ldr	x0, [x19, #7240]
    4a88:	d1000400 	sub	x0, x0, #0x1
    4a8c:	f90e2660 	str	x0, [x19, #7240]
    4a90:	f9400bf3 	ldr	x19, [sp, #16]
    4a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a98:	d65f03c0 	ret
    4a9c:	b0000020 	adrp	x0, 9000 <__divti3+0xb0>
    4aa0:	912cc000 	add	x0, x0, #0xb30
    4aa4:	97fffb57 	bl	3800 <fwp_trap>
    4aa8:	d503201f 	nop
    4aac:	d503201f 	nop

0000000000004ab0 <fwp_rc_prepare_chunk>:
    4ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ab4:	910003fd 	mov	x29, sp
    4ab8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4abc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    4ac0:	911882c2 	add	x2, x22, #0x620
    4ac4:	b9401c03 	ldr	w3, [x0, #28]
    4ac8:	aa0103f5 	mov	x21, x1
    4acc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ad0:	aa0003f4 	mov	x20, x0
    4ad4:	f94e2440 	ldr	x0, [x2, #7240]
    4ad8:	b4000440 	cbz	x0, 4b60 <fwp_rc_prepare_chunk+0xb0>
    4adc:	d2800013 	mov	x19, #0x0                   	// #0
    4ae0:	35000203 	cbnz	w3, 4b20 <fwp_rc_prepare_chunk+0x70>
    4ae4:	b4000361 	cbz	x1, 4b50 <fwp_rc_prepare_chunk+0xa0>
    4ae8:	f9401280 	ldr	x0, [x20, #32]
    4aec:	97fff79d 	bl	2960 <free@plt>
    4af0:	aa1503e0 	mov	x0, x21
    4af4:	d2800021 	mov	x1, #0x1                   	// #1
    4af8:	97fff762 	bl	2880 <calloc@plt>
    4afc:	f9001280 	str	x0, [x20, #32]
    4b00:	b5000460 	cbnz	x0, 4b8c <fwp_rc_prepare_chunk+0xdc>
    4b04:	97fff99b 	bl	3170 <fwp_heap_oom>
    4b08:	97ffffc2 	bl	4a10 <fwp_rc_forget_slot>
    4b0c:	91000673 	add	x19, x19, #0x1
    4b10:	b9401e83 	ldr	w3, [x20, #28]
    4b14:	eb13007f 	cmp	x3, x19
    4b18:	54000169 	b.ls	4b44 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b1c:	d503201f 	nop
    4b20:	f9401283 	ldr	x3, [x20, #32]
    4b24:	8b130060 	add	x0, x3, x19
    4b28:	38736863 	ldrb	w3, [x3, x19]
    4b2c:	7103fc7f 	cmp	w3, #0xff
    4b30:	54fffec0 	b.eq	4b08 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b34:	b9401e83 	ldr	w3, [x20, #28]
    4b38:	91000673 	add	x19, x19, #0x1
    4b3c:	eb13007f 	cmp	x3, x19
    4b40:	54ffff08 	b.hi	4b20 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b44:	eb0302bf 	cmp	x21, x3
    4b48:	54000121 	b.ne	4b6c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b4c:	b5000335 	cbnz	x21, 4bb0 <fwp_rc_prepare_chunk+0x100>
    4b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b5c:	d65f03c0 	ret
    4b60:	2a0303e3 	mov	w3, w3
    4b64:	eb0302bf 	cmp	x21, x3
    4b68:	54ffff20 	b.eq	4b4c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b6c:	911882c2 	add	x2, x22, #0x620
    4b70:	f9401280 	ldr	x0, [x20, #32]
    4b74:	f94e2841 	ldr	x1, [x2, #7248]
    4b78:	cb030021 	sub	x1, x1, x3
    4b7c:	f90e2841 	str	x1, [x2, #7248]
    4b80:	97fff778 	bl	2960 <free@plt>
    4b84:	b5fffb75 	cbnz	x21, 4af0 <fwp_rc_prepare_chunk+0x40>
    4b88:	f900129f 	str	xzr, [x20, #32]
    4b8c:	911882d6 	add	x22, x22, #0x620
    4b90:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b94:	b9001e95 	str	w21, [x20, #28]
    4b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b9c:	8b150000 	add	x0, x0, x21
    4ba0:	f90e2ac0 	str	x0, [x22, #7248]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	f9401280 	ldr	x0, [x20, #32]
    4bb4:	aa1503e2 	mov	x2, x21
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	52800001 	mov	w1, #0x0                   	// #0
    4bc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bc8:	17fff72a 	b	2870 <memset@plt>
    4bcc:	d503201f 	nop

0000000000004bd0 <fwp_heap_refill>:
    4bd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4bd4:	910003fd 	mov	x29, sp
    4bd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bdc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4be0:	911882b5 	add	x21, x21, #0x620
    4be4:	aa0003f6 	mov	x22, x0
    4be8:	d2800020 	mov	x0, #0x1                   	// #1
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bf4:	2a0103f7 	mov	w23, w1
    4bf8:	2a0203f8 	mov	w24, w2
    4bfc:	97fff96d 	bl	31b0 <fwp_heap_chunks>
    4c00:	aa0003f3 	mov	x19, x0
    4c04:	f949fea2 	ldr	x2, [x21, #5112]
    4c08:	8b000800 	add	x0, x0, x0, lsl #2
    4c0c:	2a1703e1 	mov	w1, w23
    4c10:	52800025 	mov	w5, #0x1                   	// #1
    4c14:	d37df000 	lsl	x0, x0, #3
    4c18:	910f0021 	add	x1, x1, #0x3c0
    4c1c:	8b000054 	add	x20, x2, x0
    4c20:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c24:	52a00024 	mov	w4, #0x10000               	// #65536
    4c28:	38206845 	strb	w5, [x2, x0]
    4c2c:	aa1403e0 	mov	x0, x20
    4c30:	39000698 	strb	w24, [x20, #1]
    4c34:	39000a97 	strb	w23, [x20, #2]
    4c38:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c3c:	b9000681 	str	w1, [x20, #4]
    4c40:	2a0103e5 	mov	w5, w1
    4c44:	8b0300a2 	add	x2, x5, x3
    4c48:	1ac10881 	udiv	w1, w4, w1
    4c4c:	9ac50842 	udiv	x2, x2, x5
    4c50:	b9000a81 	str	w1, [x20, #8]
    4c54:	92404021 	and	x1, x1, #0x1ffff
    4c58:	b9001a82 	str	w2, [x20, #24]
    4c5c:	97ffff95 	bl	4ab0 <fwp_rc_prepare_chunk>
    4c60:	f949daa0 	ldr	x0, [x21, #5040]
    4c64:	29408a81 	ldp	w1, w2, [x20, #4]
    4c68:	8b134000 	add	x0, x0, x19, lsl #16
    4c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c70:	8b214003 	add	x3, x0, w1, uxtw
    4c74:	9ba20021 	umaddl	x1, w1, w2, x0
    4c78:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c7c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c88:	d65f03c0 	ret
    4c8c:	d503201f 	nop

0000000000004c90 <fwp_mem_free>:
    4c90:	b40003c0 	cbz	x0, 4d08 <fwp_mem_free+0x78>
    4c94:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c98:	910003fd 	mov	x29, sp
    4c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ca0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4ca4:	911882a1 	add	x1, x21, #0x620
    4ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cac:	aa0003f3 	mov	x19, x0
    4cb0:	f949d823 	ldr	x3, [x1, #5040]
    4cb4:	f949ec22 	ldr	x2, [x1, #5080]
    4cb8:	cb030000 	sub	x0, x0, x3
    4cbc:	eb02401f 	cmp	x0, x2, lsl #16
    4cc0:	540001c2 	b.cs	4cf8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4cc4:	d350fc16 	lsr	x22, x0, #16
    4cc8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ccc:	f949fc22 	ldr	x2, [x1, #5112]
    4cd0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4cd4:	d37df294 	lsl	x20, x20, #3
    4cd8:	ab140057 	adds	x23, x2, x20
    4cdc:	540000c0 	b.eq	4cf4 <fwp_mem_free+0x64>  // b.none
    4ce0:	38746842 	ldrb	w2, [x2, x20]
    4ce4:	7100045f 	cmp	w2, #0x1
    4ce8:	54000120 	b.eq	4d0c <fwp_mem_free+0x7c>  // b.none
    4cec:	7100085f 	cmp	w2, #0x2
    4cf0:	540005e0 	b.eq	4dac <fwp_mem_free+0x11c>  // b.none
    4cf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d00:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d04:	d65f03c0 	ret
    4d08:	d65f03c0 	ret
    4d0c:	f94012f8 	ldr	x24, [x23, #32]
    4d10:	b94006e1 	ldr	w1, [x23, #4]
    4d14:	f90023f9 	str	x25, [sp, #64]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	394006f9 	ldrb	w25, [x23, #1]
    4d20:	39400af4 	ldrb	w20, [x23, #2]
    4d24:	b4000158 	cbz	x24, 4d4c <fwp_mem_free+0xbc>
    4d28:	92403e76 	and	x22, x19, #0xffff
    4d2c:	9ac20ad6 	udiv	x22, x22, x2
    4d30:	38766b01 	ldrb	w1, [x24, x22]
    4d34:	8b160300 	add	x0, x24, x22
    4d38:	7103fc3f 	cmp	w1, #0xff
    4d3c:	54000980 	b.eq	4e6c <fwp_mem_free+0x1dc>  // b.none
    4d40:	38366b1f 	strb	wzr, [x24, x22]
    4d44:	b94006e1 	ldr	w1, [x23, #4]
    4d48:	2a0103e2 	mov	w2, w1
    4d4c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d50:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d54:	cb390000 	sub	x0, x0, w25, uxtb
    4d58:	8b340074 	add	x20, x3, w20, uxtb
    4d5c:	911882b5 	add	x21, x21, #0x620
    4d60:	1e630021 	ucvtf	d1, w1
    4d64:	d37ae400 	lsl	x0, x0, #6
    4d68:	8b140c14 	add	x20, x0, x20, lsl #3
    4d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d70:	f8746aa0 	ldr	x0, [x21, x20]
    4d74:	f94023f9 	ldr	x25, [sp, #64]
    4d78:	aa2003e0 	mvn	x0, x0
    4d7c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d80:	f9000260 	str	x0, [x19]
    4d84:	f8346ab3 	str	x19, [x21, x20]
    4d88:	f94a12a0 	ldr	x0, [x21, #5152]
    4d8c:	1e612800 	fadd	d0, d0, d1
    4d90:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d94:	cb020000 	sub	x0, x0, x2
    4d98:	f90a12a0 	str	x0, [x21, #5152]
    4d9c:	fd0a22a0 	str	d0, [x21, #5184]
    4da0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4da8:	d65f03c0 	ret
    4dac:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4db0:	8b000063 	add	x3, x3, x0
    4db4:	eb03027f 	cmp	x19, x3
    4db8:	54fff9e1 	b.ne	4cf4 <fwp_mem_free+0x64>  // b.any
    4dbc:	fd400ae1 	ldr	d1, [x23, #16]
    4dc0:	fd4a2020 	ldr	d0, [x1, #5184]
    4dc4:	f9400ae0 	ldr	x0, [x23, #16]
    4dc8:	7e61d821 	ucvtf	d1, d1
    4dcc:	f94a1022 	ldr	x2, [x1, #5152]
    4dd0:	f94012f3 	ldr	x19, [x23, #32]
    4dd4:	1e612800 	fadd	d0, d0, d1
    4dd8:	cb000042 	sub	x2, x2, x0
    4ddc:	f90a1022 	str	x2, [x1, #5152]
    4de0:	fd0a2020 	str	d0, [x1, #5184]
    4de4:	b40000b3 	cbz	x19, 4df8 <fwp_mem_free+0x168>
    4de8:	39400260 	ldrb	w0, [x19]
    4dec:	7103fc1f 	cmp	w0, #0xff
    4df0:	54000380 	b.eq	4e60 <fwp_mem_free+0x1d0>  // b.none
    4df4:	3900027f 	strb	wzr, [x19]
    4df8:	b9400ee2 	ldr	w2, [x23, #12]
    4dfc:	b4000142 	cbz	x2, 4e24 <fwp_mem_free+0x194>
    4e00:	911882a1 	add	x1, x21, #0x620
    4e04:	8b160040 	add	x0, x2, x22
    4e08:	8b000800 	add	x0, x0, x0, lsl #2
    4e0c:	f949fc21 	ldr	x1, [x1, #5112]
    4e10:	8b140034 	add	x20, x1, x20
    4e14:	8b000c20 	add	x0, x1, x0, lsl #3
    4e18:	3802869f 	strb	wzr, [x20], #40
    4e1c:	eb00029f 	cmp	x20, x0
    4e20:	54ffffc1 	b.ne	4e18 <fwp_mem_free+0x188>  // b.any
    4e24:	911882a0 	add	x0, x21, #0x620
    4e28:	f94a1801 	ldr	x1, [x0, #5168]
    4e2c:	f949f803 	ldr	x3, [x0, #5104]
    4e30:	8b020021 	add	x1, x1, x2
    4e34:	f90a1801 	str	x1, [x0, #5168]
    4e38:	eb16007f 	cmp	x3, x22
    4e3c:	54000049 	b.ls	4e44 <fwp_mem_free+0x1b4>  // b.plast
    4e40:	f909f816 	str	x22, [x0, #5104]
    4e44:	911882b5 	add	x21, x21, #0x620
    4e48:	f949f6a0 	ldr	x0, [x21, #5096]
    4e4c:	eb16001f 	cmp	x0, x22
    4e50:	54fff529 	b.ls	4cf4 <fwp_mem_free+0x64>  // b.plast
    4e54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e58:	f909f6b6 	str	x22, [x21, #5096]
    4e5c:	17ffffa7 	b	4cf8 <fwp_mem_free+0x68>
    4e60:	aa1303e0 	mov	x0, x19
    4e64:	97fffeeb 	bl	4a10 <fwp_rc_forget_slot>
    4e68:	17ffffe3 	b	4df4 <fwp_mem_free+0x164>
    4e6c:	97fffee9 	bl	4a10 <fwp_rc_forget_slot>
    4e70:	17ffffb4 	b	4d40 <fwp_mem_free+0xb0>

0000000000004e74 <fwp_heap_alloc_big>:
    4e74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e78:	910003fd 	mov	x29, sp
    4e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e80:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	aa0003f7 	mov	x23, x0
    4e8c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e94:	eb0002ff 	cmp	x23, x0
    4e98:	54000888 	b.hi	4fa8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ea0:	8b0002f4 	add	x20, x23, x0
    4ea4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbc0>
    4ea8:	91188359 	add	x25, x26, #0x620
    4eac:	d350fe94 	lsr	x20, x20, #16
    4eb0:	2a0103f5 	mov	w21, w1
    4eb4:	aa1403e0 	mov	x0, x20
    4eb8:	97fff8be 	bl	31b0 <fwp_heap_chunks>
    4ebc:	f949ff22 	ldr	x2, [x25, #5112]
    4ec0:	8b000813 	add	x19, x0, x0, lsl #2
    4ec4:	aa0003f8 	mov	x24, x0
    4ec8:	52800043 	mov	w3, #0x2                   	// #2
    4ecc:	d37df273 	lsl	x19, x19, #3
    4ed0:	d2800021 	mov	x1, #0x1                   	// #1
    4ed4:	8b130040 	add	x0, x2, x19
    4ed8:	38336843 	strb	w3, [x2, x19]
    4edc:	39000415 	strb	w21, [x0, #1]
    4ee0:	b9000c14 	str	w20, [x0, #12]
    4ee4:	f9000817 	str	x23, [x0, #16]
    4ee8:	97fffef2 	bl	4ab0 <fwp_rc_prepare_chunk>
    4eec:	f100069f 	cmp	x20, #0x1
    4ef0:	54000269 	b.ls	4f3c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ef4:	8b180294 	add	x20, x20, x24
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	a90573fb 	stp	x27, x28, [sp, #80]
    4f00:	5280007b 	mov	w27, #0x3                   	// #3
    4f04:	8b140a94 	add	x20, x20, x20, lsl #2
    4f08:	2a1803fc 	mov	w28, w24
    4f0c:	9adb2296 	lsl	x22, x20, x27
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffee4 	bl	4ab0 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0x9c>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	91188353 	add	x19, x26, #0x620
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x104>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118835a 	add	x26, x26, #0x620
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4fc0:	91188262 	add	x2, x19, #0x620
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	91188262 	add	x2, x19, #0x620
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	91188260 	add	x0, x19, #0x620
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	91188273 	add	x19, x19, #0x620
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffc1c 	bl	4104 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff70 	b	4e74 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	91188260 	add	x0, x19, #0x620
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffeb5 	bl	4bd0 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	54000861 	b.ne	5244 <fwp_heap_alloc+0x134>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbc0>
    5140:	911882f3 	add	x19, x23, #0x620
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	540006e2 	b.cs	5290 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	911882e0 	add	x0, x23, #0x620
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	911882e1 	add	x1, x23, #0x620
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	540002cc 	b.gt	5258 <fwp_heap_alloc+0x148>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000209 	b.ls	5274 <fwp_heap_alloc+0x164>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	17ffffe8 	b	51e0 <fwp_heap_alloc+0xd0>
    5244:	a9538c44 	ldp	x4, x3, [x2, #312]
    5248:	91000484 	add	x4, x4, #0x1
    524c:	8b000063 	add	x3, x3, x0
    5250:	a9138c44 	stp	x4, x3, [x2, #312]
    5254:	17ffffba 	b	513c <fwp_heap_alloc+0x2c>
    5258:	a94153f3 	ldp	x19, x20, [sp, #16]
    525c:	fd00a800 	str	d0, [x0, #336]
    5260:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5264:	aa0403e0 	mov	x0, x4
    5268:	a94363f7 	ldp	x23, x24, [sp, #48]
    526c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5270:	d65f03c0 	ret
    5274:	7100043f 	cmp	w1, #0x1
    5278:	8b140085 	add	x5, x4, x20
    527c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5280:	52800001 	mov	w1, #0x0                   	// #0
    5284:	aa0403e0 	mov	x0, x4
    5288:	f9000465 	str	x5, [x3, #8]
    528c:	17ffffc6 	b	51a4 <fwp_heap_alloc+0x94>
    5290:	97fff7b8 	bl	3170 <fwp_heap_oom>

0000000000005294 <fwp_data.part.0.constprop.0>:
    5294:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5298:	910003fd 	mov	x29, sp
    529c:	a9025bf5 	stp	x21, x22, [sp, #32]
    52a0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52a4:	910142c2 	add	x2, x22, #0x50
    52a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52ac:	b9413059 	ldr	w25, [x2, #304]
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	aa0103f4 	mov	x20, x1
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	2a0003f7 	mov	w23, w0
    52c0:	340000b9 	cbz	w25, 52d4 <fwp_data.part.0.constprop.0+0x40>
    52c4:	a9538041 	ldp	x1, x0, [x2, #312]
    52c8:	91000421 	add	x1, x1, #0x1
    52cc:	91006000 	add	x0, x0, #0x18
    52d0:	a9138041 	stp	x1, x0, [x2, #312]
    52d4:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    52d8:	911882a3 	add	x3, x21, #0x620
    52dc:	b953a460 	ldr	w0, [x3, #5028]
    52e0:	34000840 	cbz	w0, 53e8 <fwp_data.part.0.constprop.0+0x154>
    52e4:	397e8862 	ldrb	w2, [x3, #4002]
    52e8:	910f0040 	add	x0, x2, #0x3c0
    52ec:	8b020442 	add	x2, x2, x2, lsl #1
    52f0:	d37df042 	lsl	x2, x2, #3
    52f4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52f8:	2a1a03f8 	mov	w24, w26
    52fc:	f8626873 	ldr	x19, [x3, x2]
    5300:	b4000613 	cbz	x19, 53c0 <fwp_data.part.0.constprop.0+0x12c>
    5304:	f9400260 	ldr	x0, [x19]
    5308:	aa2003e0 	mvn	x0, x0
    530c:	f8226860 	str	x0, [x3, x2]
    5310:	f100631f 	cmp	x24, #0x18
    5314:	540000e9 	b.ls	5330 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5318:	d1006702 	sub	x2, x24, #0x19
    531c:	91006260 	add	x0, x19, #0x18
    5320:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5324:	52800001 	mov	w1, #0x0                   	// #0
    5328:	91002042 	add	x2, x2, #0x8
    532c:	97fff551 	bl	2870 <memset@plt>
    5330:	911882a0 	add	x0, x21, #0x620
    5334:	f94a1001 	ldr	x1, [x0, #5152]
    5338:	ab180021 	adds	x1, x1, x24
    533c:	54000642 	b.cs	5404 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5340:	f94a1402 	ldr	x2, [x0, #5160]
    5344:	f90a1001 	str	x1, [x0, #5152]
    5348:	eb02003f 	cmp	x1, x2
    534c:	54000049 	b.ls	5354 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5350:	f90a1401 	str	x1, [x0, #5160]
    5354:	911882a0 	add	x0, x21, #0x620
    5358:	1e630341 	ucvtf	d1, w26
    535c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5360:	1e612800 	fadd	d0, d0, d1
    5364:	fd0a1c00 	str	d0, [x0, #5176]
    5368:	34000139 	cbz	w25, 538c <fwp_data.part.0.constprop.0+0xf8>
    536c:	911882b5 	add	x21, x21, #0x620
    5370:	910142d6 	add	x22, x22, #0x50
    5374:	fd4a12a0 	ldr	d0, [x21, #5152]
    5378:	6d5486c2 	ldp	d2, d1, [x22, #328]
    537c:	7e61d800 	ucvtf	d0, d0
    5380:	1e623800 	fsub	d0, d0, d2
    5384:	1e612010 	fcmpe	d0, d1
    5388:	540003ac 	b.gt	53fc <fwp_data.part.0.constprop.0+0x168>
    538c:	52800040 	mov	w0, #0x2                   	// #2
    5390:	29000277 	stp	w23, w0, [x19]
    5394:	aa1303e0 	mov	x0, x19
    5398:	f9400281 	ldr	x1, [x20]
    539c:	f9000661 	str	x1, [x19, #8]
    53a0:	f9400681 	ldr	x1, [x20, #8]
    53a4:	f9000a61 	str	x1, [x19, #16]
    53a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53bc:	d65f03c0 	ret
    53c0:	8b020063 	add	x3, x3, x2
    53c4:	f9400473 	ldr	x19, [x3, #8]
    53c8:	b4000113 	cbz	x19, 53e8 <fwp_data.part.0.constprop.0+0x154>
    53cc:	f9400860 	ldr	x0, [x3, #16]
    53d0:	cb130000 	sub	x0, x0, x19
    53d4:	eb00031f 	cmp	x24, x0
    53d8:	54000088 	b.hi	53e8 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53dc:	8b180260 	add	x0, x19, x24
    53e0:	f9000460 	str	x0, [x3, #8]
    53e4:	17ffffcb 	b	5310 <fwp_data.part.0.constprop.0+0x7c>
    53e8:	52800001 	mov	w1, #0x0                   	// #0
    53ec:	d2800300 	mov	x0, #0x18                  	// #24
    53f0:	97ffff48 	bl	5110 <fwp_heap_alloc>
    53f4:	aa0003f3 	mov	x19, x0
    53f8:	17ffffdc 	b	5368 <fwp_data.part.0.constprop.0+0xd4>
    53fc:	fd00aac0 	str	d0, [x22, #336]
    5400:	17ffffe3 	b	538c <fwp_data.part.0.constprop.0+0xf8>
    5404:	97fff75b 	bl	3170 <fwp_heap_oom>
    5408:	d503201f 	nop
    540c:	d503201f 	nop

0000000000005410 <fwp_p_ad_push.constprop.0>:
    5410:	f100001f 	cmp	x0, #0x0
    5414:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5418:	54000eab 	b.lt	55ec <fwp_p_ad_push.constprop.0+0x1dc>  // b.tstop
    541c:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5420:	aa0003e4 	mov	x4, x0
    5424:	910003fd 	mov	x29, sp
    5428:	a9025bf5 	stp	x21, x22, [sp, #32]
    542c:	aa0003f5 	mov	x21, x0
    5430:	aa020000 	orr	x0, x0, x2
    5434:	a90363f7 	stp	x23, x24, [sp, #48]
    5438:	aa0203f7 	mov	x23, x2
    543c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5440:	9e670029 	fmov	d9, x1
    5444:	9e670068 	fmov	d8, x3
    5448:	b6f80920 	tbz	x0, #63, 556c <fwp_p_ad_push.constprop.0+0x15c>
    544c:	a90153f3 	stp	x19, x20, [sp, #16]
    5450:	9360fc80 	asr	x0, x4, #32
    5454:	b6f800c4 	tbz	x4, #63, 546c <fwp_p_ad_push.constprop.0+0x5c>
    5458:	1e604109 	fmov	d9, d8
    545c:	2f00e408 	movi	d8, #0x0
    5460:	9360fc40 	asr	x0, x2, #32
    5464:	aa0203f5 	mov	x21, x2
    5468:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    546c:	97fff9b1 	bl	3b30 <fwp_tape_of>
    5470:	aa0003f3 	mov	x19, x0
    5474:	f9403000 	ldr	x0, [x0, #96]
    5478:	b5001240 	cbnz	x0, 56c0 <fwp_p_ad_push.constprop.0+0x2b0>
    547c:	f9400a76 	ldr	x22, [x19, #16]
    5480:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5484:	eb0002df 	cmp	x22, x0
    5488:	54000d8c 	b.gt	5638 <fwp_p_ad_push.constprop.0+0x228>
    548c:	eb3542df 	cmp	x22, w21, uxtw
    5490:	54000cad 	b.le	5624 <fwp_p_ad_push.constprop.0+0x214>
    5494:	b7f80077 	tbnz	x23, #63, 54a0 <fwp_p_ad_push.constprop.0+0x90>
    5498:	eb3742df 	cmp	x22, w23, uxtw
    549c:	54000c4d 	b.le	5624 <fwp_p_ad_push.constprop.0+0x214>
    54a0:	f9400678 	ldr	x24, [x19, #8]
    54a4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54a8:	cb1802d8 	sub	x24, x22, x24
    54ac:	91000701 	add	x1, x24, #0x1
    54b0:	eb00003f 	cmp	x1, x0
    54b4:	54000c28 	b.hi	5638 <fwp_p_ad_push.constprop.0+0x228>  // b.pmore
    54b8:	a9418274 	ldp	x20, x0, [x19, #24]
    54bc:	a90573fb 	stp	x27, x28, [sp, #80]
    54c0:	eb14003f 	cmp	x1, x20
    54c4:	540006ad 	b.le	5598 <fwp_p_ad_push.constprop.0+0x188>
    54c8:	f100029f 	cmp	x20, #0x0
    54cc:	d2800803 	mov	x3, #0x40                  	// #64
    54d0:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54d4:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    54dc:	eb14003f 	cmp	x1, x20
    54e0:	5400008d 	b.le	54f0 <fwp_p_ad_push.constprop.0+0xe0>
    54e4:	eb02029f 	cmp	x20, x2
    54e8:	5400054d 	b.le	5590 <fwp_p_ad_push.constprop.0+0x180>
    54ec:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    54f0:	d37df299 	lsl	x25, x20, #3
    54f4:	52800022 	mov	w2, #0x1                   	// #1
    54f8:	aa1903e1 	mov	x1, x25
    54fc:	97fffbd6 	bl	4454 <ad_raw_realloc>
    5500:	aa0003e1 	mov	x1, x0
    5504:	b4000a40 	cbz	x0, 564c <fwp_p_ad_push.constprop.0+0x23c>
    5508:	f9400e63 	ldr	x3, [x19, #24]
    550c:	f9001261 	str	x1, [x19, #32]
    5510:	f9401a60 	ldr	x0, [x19, #48]
    5514:	52800042 	mov	w2, #0x2                   	// #2
    5518:	8b030821 	add	x1, x1, x3, lsl #2
    551c:	f9001661 	str	x1, [x19, #40]
    5520:	d37cee81 	lsl	x1, x20, #4
    5524:	97fffbcc 	bl	4454 <ad_raw_realloc>
    5528:	aa0003e2 	mov	x2, x0
    552c:	b4000900 	cbz	x0, 564c <fwp_p_ad_push.constprop.0+0x23c>
    5530:	f9400e61 	ldr	x1, [x19, #24]
    5534:	d37df31b 	lsl	x27, x24, #3
    5538:	d37ef69a 	lsl	x26, x20, #2
    553c:	d37ef71c 	lsl	x28, x24, #2
    5540:	8b190003 	add	x3, x0, x25
    5544:	8b010c01 	add	x1, x0, x1, lsl #3
    5548:	a9030660 	stp	x0, x1, [x19, #48]
    554c:	b5000558 	cbnz	x24, 55f4 <fwp_p_ad_push.constprop.0+0x1e4>
    5550:	f9001e63 	str	x3, [x19, #56]
    5554:	f9401260 	ldr	x0, [x19, #32]
    5558:	8b1a0001 	add	x1, x0, x26
    555c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5560:	f9000e74 	str	x20, [x19, #24]
    5564:	f9001661 	str	x1, [x19, #40]
    5568:	14000010 	b	55a8 <fwp_p_ad_push.constprop.0+0x198>
    556c:	9360fc40 	asr	x0, x2, #32
    5570:	a90153f3 	stp	x19, x20, [sp, #16]
    5574:	eb84801f 	cmp	x0, x4, asr #32
    5578:	54fff7a0 	b.eq	546c <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    557c:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    5580:	912de000 	add	x0, x0, #0xb78
    5584:	a9046bf9 	stp	x25, x26, [sp, #64]
    5588:	a90573fb 	stp	x27, x28, [sp, #80]
    558c:	97fff89d 	bl	3800 <fwp_trap>
    5590:	d37ffa94 	lsl	x20, x20, #1
    5594:	17ffffd2 	b	54dc <fwp_p_ad_push.constprop.0+0xcc>
    5598:	a9428a61 	ldp	x1, x2, [x19, #40]
    559c:	d37ef71c 	lsl	x28, x24, #2
    55a0:	f9401e63 	ldr	x3, [x19, #56]
    55a4:	d37df31b 	lsl	x27, x24, #3
    55a8:	b83c6815 	str	w21, [x0, x28]
    55ac:	f10002ff 	cmp	x23, #0x0
    55b0:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    55b4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55b8:	fc3b6849 	str	d9, [x2, x27]
    55bc:	aa1602a0 	orr	x0, x21, x22
    55c0:	b83c6837 	str	w23, [x1, x28]
    55c4:	910006d6 	add	x22, x22, #0x1
    55c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55cc:	fc3b6868 	str	d8, [x3, x27]
    55d0:	a94573fb 	ldp	x27, x28, [sp, #80]
    55d4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55d8:	f9000a76 	str	x22, [x19, #16]
    55dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    55e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    55e8:	d65f03c0 	ret
    55ec:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    55f0:	d65f03c0 	ret
    55f4:	aa0303e0 	mov	x0, x3
    55f8:	aa1b03e2 	mov	x2, x27
    55fc:	97fff445 	bl	2710 <memmove@plt>
    5600:	a9420660 	ldp	x0, x1, [x19, #32]
    5604:	aa1c03e2 	mov	x2, x28
    5608:	f9401a63 	ldr	x3, [x19, #48]
    560c:	8b190063 	add	x3, x3, x25
    5610:	f9001e63 	str	x3, [x19, #56]
    5614:	8b1a0000 	add	x0, x0, x26
    5618:	97fff43e 	bl	2710 <memmove@plt>
    561c:	a9430e62 	ldp	x2, x3, [x19, #48]
    5620:	17ffffcd 	b	5554 <fwp_p_ad_push.constprop.0+0x144>
    5624:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    5628:	91304000 	add	x0, x0, #0xc10
    562c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5630:	a90573fb 	stp	x27, x28, [sp, #80]
    5634:	97fff873 	bl	3800 <fwp_trap>
    5638:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    563c:	912fc000 	add	x0, x0, #0xbf0
    5640:	a9046bf9 	stp	x25, x26, [sp, #64]
    5644:	a90573fb 	stp	x27, x28, [sp, #80]
    5648:	97fff86e 	bl	3800 <fwp_trap>
    564c:	aa1303e0 	mov	x0, x19
    5650:	97fff671 	bl	3014 <fwp_tape_unlink_scope>
    5654:	f9401260 	ldr	x0, [x19, #32]
    5658:	b4000040 	cbz	x0, 5660 <fwp_p_ad_push.constprop.0+0x250>
    565c:	97fffb49 	bl	4380 <ad_raw_free.part.0>
    5660:	f9401a60 	ldr	x0, [x19, #48]
    5664:	b4000040 	cbz	x0, 566c <fwp_p_ad_push.constprop.0+0x25c>
    5668:	97fffb46 	bl	4380 <ad_raw_free.part.0>
    566c:	f9402260 	ldr	x0, [x19, #64]
    5670:	b4000040 	cbz	x0, 5678 <fwp_p_ad_push.constprop.0+0x268>
    5674:	97fffb43 	bl	4380 <ad_raw_free.part.0>
    5678:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    567c:	f947e821 	ldr	x1, [x1, #4048]
    5680:	f9000e7f 	str	xzr, [x19, #24]
    5684:	4f000400 	movi	v0.4s, #0x0
    5688:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    568c:	d2800262 	mov	x2, #0x13                  	// #19
    5690:	f9400023 	ldr	x3, [x1]
    5694:	b900067f 	str	wzr, [x19, #4]
    5698:	d2800021 	mov	x1, #0x1                   	// #1
    569c:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    56a0:	9119e000 	add	x0, x0, #0x678
    56a4:	3c808260 	stur	q0, [x19, #8]
    56a8:	ad010260 	stp	q0, q0, [x19, #32]
    56ac:	97fff4bd 	bl	29a0 <fwrite@plt>
    56b0:	d2800000 	mov	x0, #0x0                   	// #0
    56b4:	97fff4c7 	bl	29d0 <fflush@plt>
    56b8:	52800cc0 	mov	w0, #0x66                  	// #102
    56bc:	97fff4d5 	bl	2a10 <_Exit@plt>
    56c0:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    56c4:	912f0000 	add	x0, x0, #0xbc0
    56c8:	a9046bf9 	stp	x25, x26, [sp, #64]
    56cc:	a90573fb 	stp	x27, x28, [sp, #80]
    56d0:	97fff84c 	bl	3800 <fwp_trap>

00000000000056d4 <w120>:
    56d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    56d8:	9e660003 	fmov	x3, d0
    56dc:	aa0003e2 	mov	x2, x0
    56e0:	910003fd 	mov	x29, sp
    56e4:	6d0327e8 	stp	d8, d9, [sp, #48]
    56e8:	1e604028 	fmov	d8, d1
    56ec:	1e600809 	fmul	d9, d0, d0
    56f0:	fd0023ea 	str	d10, [sp, #64]
    56f4:	1e60400a 	fmov	d10, d0
    56f8:	a90153f3 	stp	x19, x20, [sp, #16]
    56fc:	aa0003f3 	mov	x19, x0
    5700:	aa0103f4 	mov	x20, x1
    5704:	aa0303e1 	mov	x1, x3
    5708:	a9025bf5 	stp	x21, x22, [sp, #32]
    570c:	97ffff41 	bl	5410 <fwp_p_ad_push.constprop.0>
    5710:	1e693908 	fsub	d8, d8, d9
    5714:	aa1403e2 	mov	x2, x20
    5718:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    571c:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5720:	9e660116 	fmov	x22, d8
    5724:	97ffff3b 	bl	5410 <fwp_p_ad_push.constprop.0>
    5728:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    572c:	aa0003e1 	mov	x1, x0
    5730:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5734:	aa1303e0 	mov	x0, x19
    5738:	1e6a3929 	fsub	d9, d9, d10
    573c:	aa0103f3 	mov	x19, x1
    5740:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5744:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5748:	9e660135 	fmov	x21, d9
    574c:	97ffff31 	bl	5410 <fwp_p_ad_push.constprop.0>
    5750:	1e680908 	fmul	d8, d8, d8
    5754:	aa0003f4 	mov	x20, x0
    5758:	aa1603e3 	mov	x3, x22
    575c:	aa1603e1 	mov	x1, x22
    5760:	aa1303e2 	mov	x2, x19
    5764:	aa1303e0 	mov	x0, x19
    5768:	97ffff2a 	bl	5410 <fwp_p_ad_push.constprop.0>
    576c:	aa0003e2 	mov	x2, x0
    5770:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5774:	9e670020 	fmov	d0, x1
    5778:	9e660101 	fmov	x1, d8
    577c:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5780:	1e600908 	fmul	d8, d8, d0
    5784:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5788:	97ffff22 	bl	5410 <fwp_p_ad_push.constprop.0>
    578c:	1e690929 	fmul	d9, d9, d9
    5790:	aa0003f3 	mov	x19, x0
    5794:	aa1503e3 	mov	x3, x21
    5798:	aa1503e1 	mov	x1, x21
    579c:	aa1403e2 	mov	x2, x20
    57a0:	aa1403e0 	mov	x0, x20
    57a4:	97ffff1b 	bl	5410 <fwp_p_ad_push.constprop.0>
    57a8:	1e692908 	fadd	d8, d8, d9
    57ac:	aa1303e2 	mov	x2, x19
    57b0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    57b4:	aa0303e1 	mov	x1, x3
    57b8:	97ffff16 	bl	5410 <fwp_p_ad_push.constprop.0>
    57bc:	aa0003e1 	mov	x1, x0
    57c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c4:	9e660100 	fmov	x0, d8
    57c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57cc:	6d4327e8 	ldp	d8, d9, [sp, #48]
    57d0:	fd4023ea 	ldr	d10, [sp, #64]
    57d4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    57d8:	d65f03c0 	ret
    57dc:	d503201f 	nop

00000000000057e0 <w176.constprop.0>:
    57e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    57e4:	910003fd 	mov	x29, sp
    57e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    57ec:	fd001be8 	str	d8, [sp, #48]
    57f0:	f9400015 	ldr	x21, [x0]
    57f4:	b4000315 	cbz	x21, 5854 <w176.constprop.0+0x74>
    57f8:	2f00e408 	movi	d8, #0x0
    57fc:	91002016 	add	x22, x0, #0x8
    5800:	a90153f3 	stp	x19, x20, [sp, #16]
    5804:	91004014 	add	x20, x0, #0x10
    5808:	d2800013 	mov	x19, #0x0                   	// #0
    580c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5810:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    5814:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5818:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    581c:	aa0303e1 	mov	x1, x3
    5820:	1e602908 	fadd	d8, d8, d0
    5824:	91000a73 	add	x19, x19, #0x2
    5828:	97fffefa 	bl	5410 <fwp_p_ad_push.constprop.0>
    582c:	eb1302bf 	cmp	x21, x19
    5830:	54ffff08 	b.hi	5810 <w176.constprop.0+0x30>  // b.pmore
    5834:	9e660102 	fmov	x2, d8
    5838:	fd401be8 	ldr	d8, [sp, #48]
    583c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5840:	aa0003e1 	mov	x1, x0
    5844:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5848:	aa0203e0 	mov	x0, x2
    584c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5850:	d65f03c0 	ret
    5854:	2f00e408 	movi	d8, #0x0
    5858:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    585c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5860:	aa0003e1 	mov	x1, x0
    5864:	9e660102 	fmov	x2, d8
    5868:	fd401be8 	ldr	d8, [sp, #48]
    586c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5870:	aa0203e0 	mov	x0, x2
    5874:	d65f03c0 	ret
    5878:	d503201f 	nop
    587c:	d503201f 	nop

0000000000005880 <fwp_rc_share>:
    5880:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5884:	91188042 	add	x2, x2, #0x620
    5888:	f949d843 	ldr	x3, [x2, #5040]
    588c:	f949ec41 	ldr	x1, [x2, #5080]
    5890:	cb030000 	sub	x0, x0, x3
    5894:	eb01401f 	cmp	x0, x1, lsl #16
    5898:	540002c2 	b.cs	58f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    589c:	d350fc01 	lsr	x1, x0, #16
    58a0:	f949fc44 	ldr	x4, [x2, #5112]
    58a4:	8b010821 	add	x1, x1, x1, lsl #2
    58a8:	d37df021 	lsl	x1, x1, #3
    58ac:	8b010083 	add	x3, x4, x1
    58b0:	f9401062 	ldr	x2, [x3, #32]
    58b4:	b40001e2 	cbz	x2, 58f0 <fwp_rc_share+0x70>
    58b8:	38616881 	ldrb	w1, [x4, x1]
    58bc:	7100083f 	cmp	w1, #0x2
    58c0:	540001a0 	b.eq	58f4 <fwp_rc_share+0x74>  // b.none
    58c4:	7100043f 	cmp	w1, #0x1
    58c8:	54000141 	b.ne	58f0 <fwp_rc_share+0x70>  // b.any
    58cc:	29430464 	ldp	w4, w1, [x3, #24]
    58d0:	92403c00 	and	x0, x0, #0xffff
    58d4:	9b047c00 	mul	x0, x0, x4
    58d8:	d360fc00 	lsr	x0, x0, #32
    58dc:	eb01001f 	cmp	x0, x1
    58e0:	54000082 	b.cs	58f0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    58e4:	8b000042 	add	x2, x2, x0
    58e8:	39400040 	ldrb	w0, [x2]
    58ec:	350000a0 	cbnz	w0, 5900 <fwp_rc_share+0x80>
    58f0:	d65f03c0 	ret
    58f4:	72003c1f 	tst	w0, #0xffff
    58f8:	54ffff80 	b.eq	58e8 <fwp_rc_share+0x68>  // b.none
    58fc:	d65f03c0 	ret
    5900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5904:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    5908:	9130c000 	add	x0, x0, #0xc30
    590c:	910003fd 	mov	x29, sp
    5910:	97fff7bc 	bl	3800 <fwp_trap>

0000000000005914 <fwp_rc_free_arr>:
    5914:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5918:	91188063 	add	x3, x3, #0x620
    591c:	f949d861 	ldr	x1, [x3, #5040]
    5920:	f949ec62 	ldr	x2, [x3, #5080]
    5924:	cb010001 	sub	x1, x0, x1
    5928:	eb02403f 	cmp	x1, x2, lsl #16
    592c:	54000342 	b.cs	5994 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5930:	d350fc22 	lsr	x2, x1, #16
    5934:	f949fc65 	ldr	x5, [x3, #5112]
    5938:	8b020842 	add	x2, x2, x2, lsl #2
    593c:	d37df042 	lsl	x2, x2, #3
    5940:	8b0200a4 	add	x4, x5, x2
    5944:	f9401083 	ldr	x3, [x4, #32]
    5948:	b4000263 	cbz	x3, 5994 <fwp_rc_free_arr+0x80>
    594c:	386268a2 	ldrb	w2, [x5, x2]
    5950:	7100085f 	cmp	w2, #0x2
    5954:	540001c0 	b.eq	598c <fwp_rc_free_arr+0x78>  // b.none
    5958:	7100045f 	cmp	w2, #0x1
    595c:	540001c1 	b.ne	5994 <fwp_rc_free_arr+0x80>  // b.any
    5960:	29430885 	ldp	w5, w2, [x4, #24]
    5964:	92403c21 	and	x1, x1, #0xffff
    5968:	9b057c21 	mul	x1, x1, x5
    596c:	d360fc21 	lsr	x1, x1, #32
    5970:	eb02003f 	cmp	x1, x2
    5974:	54000102 	b.cs	5994 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5978:	8b010063 	add	x3, x3, x1
    597c:	39400061 	ldrb	w1, [x3]
    5980:	7100043f 	cmp	w1, #0x1
    5984:	54000081 	b.ne	5994 <fwp_rc_free_arr+0x80>  // b.any
    5988:	17fffcc2 	b	4c90 <fwp_mem_free>
    598c:	72003c3f 	tst	w1, #0xffff
    5990:	54ffff60 	b.eq	597c <fwp_rc_free_arr+0x68>  // b.none
    5994:	d65f03c0 	ret
    5998:	d503201f 	nop
    599c:	d503201f 	nop

00000000000059a0 <fwp_rc_dup>:
    59a0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    59a4:	91188042 	add	x2, x2, #0x620
    59a8:	f949d841 	ldr	x1, [x2, #5040]
    59ac:	f949ec43 	ldr	x3, [x2, #5080]
    59b0:	cb010001 	sub	x1, x0, x1
    59b4:	eb03403f 	cmp	x1, x3, lsl #16
    59b8:	540003c2 	b.cs	5a30 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    59bc:	d350fc20 	lsr	x0, x1, #16
    59c0:	f949fc44 	ldr	x4, [x2, #5112]
    59c4:	8b000800 	add	x0, x0, x0, lsl #2
    59c8:	d37df002 	lsl	x2, x0, #3
    59cc:	8b020083 	add	x3, x4, x2
    59d0:	f9401060 	ldr	x0, [x3, #32]
    59d4:	b40002e0 	cbz	x0, 5a30 <fwp_rc_dup+0x90>
    59d8:	38626882 	ldrb	w2, [x4, x2]
    59dc:	7100085f 	cmp	w2, #0x2
    59e0:	540002a0 	b.eq	5a34 <fwp_rc_dup+0x94>  // b.none
    59e4:	7100045f 	cmp	w2, #0x1
    59e8:	54000241 	b.ne	5a30 <fwp_rc_dup+0x90>  // b.any
    59ec:	29430864 	ldp	w4, w2, [x3, #24]
    59f0:	92403c21 	and	x1, x1, #0xffff
    59f4:	9b047c21 	mul	x1, x1, x4
    59f8:	d360fc21 	lsr	x1, x1, #32
    59fc:	eb02003f 	cmp	x1, x2
    5a00:	54000182 	b.cs	5a30 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5a04:	8b010000 	add	x0, x0, x1
    5a08:	39400001 	ldrb	w1, [x0]
    5a0c:	34000121 	cbz	w1, 5a30 <fwp_rc_dup+0x90>
    5a10:	f00000c2 	adrp	x2, 20000 <__data_start>
    5a14:	91014042 	add	x2, x2, #0x50
    5a18:	b9413043 	ldr	w3, [x2, #304]
    5a1c:	35000123 	cbnz	w3, 5a40 <fwp_rc_dup+0xa0>
    5a20:	7103f43f 	cmp	w1, #0xfd
    5a24:	54000168 	b.hi	5a50 <fwp_rc_dup+0xb0>  // b.pmore
    5a28:	11000421 	add	w1, w1, #0x1
    5a2c:	39000001 	strb	w1, [x0]
    5a30:	d65f03c0 	ret
    5a34:	72003c3f 	tst	w1, #0xffff
    5a38:	54fffe80 	b.eq	5a08 <fwp_rc_dup+0x68>  // b.none
    5a3c:	d65f03c0 	ret
    5a40:	f940ac43 	ldr	x3, [x2, #344]
    5a44:	91000463 	add	x3, x3, #0x1
    5a48:	f900ac43 	str	x3, [x2, #344]
    5a4c:	17fffff5 	b	5a20 <fwp_rc_dup+0x80>
    5a50:	17fffba9 	b	48f4 <fwp_rc_wide_dup>

0000000000005a54 <fwp_owned_entry173>:
    5a54:	d10103ff 	sub	sp, sp, #0x40
    5a58:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5a5c:	f947f442 	ldr	x2, [x2, #4072]
    5a60:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a64:	910083fd 	add	x29, sp, #0x20
    5a68:	a90353f3 	stp	x19, x20, [sp, #48]
    5a6c:	f9400043 	ldr	x3, [x2]
    5a70:	f9000fe3 	str	x3, [sp, #24]
    5a74:	d2800003 	mov	x3, #0x0                   	// #0
    5a78:	a9400c01 	ldp	x1, x3, [x0]
    5a7c:	f9400802 	ldr	x2, [x0, #16]
    5a80:	ab020022 	adds	x2, x1, x2
    5a84:	540006e6 	b.vs	5b60 <fwp_owned_entry173+0x10c>
    5a88:	910023e1 	add	x1, sp, #0x8
    5a8c:	52800000 	mov	w0, #0x0                   	// #0
    5a90:	a9008be3 	stp	x3, x2, [sp, #8]
    5a94:	97fffe00 	bl	5294 <fwp_data.part.0.constprop.0>
    5a98:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5a9c:	91188063 	add	x3, x3, #0x620
    5aa0:	aa0003f3 	mov	x19, x0
    5aa4:	f949d861 	ldr	x1, [x3, #5040]
    5aa8:	f949ec60 	ldr	x0, [x3, #5080]
    5aac:	cb010261 	sub	x1, x19, x1
    5ab0:	eb00403f 	cmp	x1, x0, lsl #16
    5ab4:	54000322 	b.cs	5b18 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ab8:	d350fc22 	lsr	x2, x1, #16
    5abc:	f949fc63 	ldr	x3, [x3, #5112]
    5ac0:	8b020842 	add	x2, x2, x2, lsl #2
    5ac4:	d37df042 	lsl	x2, x2, #3
    5ac8:	8b020060 	add	x0, x3, x2
    5acc:	f9401014 	ldr	x20, [x0, #32]
    5ad0:	b4000254 	cbz	x20, 5b18 <fwp_owned_entry173+0xc4>
    5ad4:	38626862 	ldrb	w2, [x3, x2]
    5ad8:	7100085f 	cmp	w2, #0x2
    5adc:	54000360 	b.eq	5b48 <fwp_owned_entry173+0xf4>  // b.none
    5ae0:	7100045f 	cmp	w2, #0x1
    5ae4:	540001a1 	b.ne	5b18 <fwp_owned_entry173+0xc4>  // b.any
    5ae8:	29430002 	ldp	w2, w0, [x0, #24]
    5aec:	92403c21 	and	x1, x1, #0xffff
    5af0:	9b027c21 	mul	x1, x1, x2
    5af4:	d360fc21 	lsr	x1, x1, #32
    5af8:	eb00003f 	cmp	x1, x0
    5afc:	540000e2 	b.cs	5b18 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5b00:	8b010294 	add	x20, x20, x1
    5b04:	39400280 	ldrb	w0, [x20]
    5b08:	7103fc1f 	cmp	w0, #0xff
    5b0c:	54000240 	b.eq	5b54 <fwp_owned_entry173+0x100>  // b.none
    5b10:	52800020 	mov	w0, #0x1                   	// #1
    5b14:	39000280 	strb	w0, [x20]
    5b18:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5b1c:	f947f400 	ldr	x0, [x0, #4072]
    5b20:	f9400fe2 	ldr	x2, [sp, #24]
    5b24:	f9400001 	ldr	x1, [x0]
    5b28:	eb010042 	subs	x2, x2, x1
    5b2c:	d2800001 	mov	x1, #0x0                   	// #0
    5b30:	540001a1 	b.ne	5b64 <fwp_owned_entry173+0x110>  // b.any
    5b34:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b38:	aa1303e0 	mov	x0, x19
    5b3c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b40:	910103ff 	add	sp, sp, #0x40
    5b44:	d65f03c0 	ret
    5b48:	72003c3f 	tst	w1, #0xffff
    5b4c:	54fffe61 	b.ne	5b18 <fwp_owned_entry173+0xc4>  // b.any
    5b50:	17ffffed 	b	5b04 <fwp_owned_entry173+0xb0>
    5b54:	aa1403e0 	mov	x0, x20
    5b58:	97fffbae 	bl	4a10 <fwp_rc_forget_slot>
    5b5c:	17ffffed 	b	5b10 <fwp_owned_entry173+0xbc>
    5b60:	97fff3c8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5b64:	97fff34f 	bl	28a0 <__stack_chk_fail@plt>
    5b68:	d503201f 	nop
    5b6c:	d503201f 	nop

0000000000005b70 <e173>:
    5b70:	d10103ff 	sub	sp, sp, #0x40
    5b74:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5b78:	f947f442 	ldr	x2, [x2, #4072]
    5b7c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b80:	910083fd 	add	x29, sp, #0x20
    5b84:	a90353f3 	stp	x19, x20, [sp, #48]
    5b88:	f9400043 	ldr	x3, [x2]
    5b8c:	f9000fe3 	str	x3, [sp, #24]
    5b90:	d2800003 	mov	x3, #0x0                   	// #0
    5b94:	a9400c01 	ldp	x1, x3, [x0]
    5b98:	f9400802 	ldr	x2, [x0, #16]
    5b9c:	ab020022 	adds	x2, x1, x2
    5ba0:	54000726 	b.vs	5c84 <e173+0x114>
    5ba4:	910023e1 	add	x1, sp, #0x8
    5ba8:	52800000 	mov	w0, #0x0                   	// #0
    5bac:	a9008be3 	stp	x3, x2, [sp, #8]
    5bb0:	97fffdb9 	bl	5294 <fwp_data.part.0.constprop.0>
    5bb4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5bb8:	91188063 	add	x3, x3, #0x620
    5bbc:	aa0003f3 	mov	x19, x0
    5bc0:	f949d861 	ldr	x1, [x3, #5040]
    5bc4:	f949ec60 	ldr	x0, [x3, #5080]
    5bc8:	cb010261 	sub	x1, x19, x1
    5bcc:	eb00403f 	cmp	x1, x0, lsl #16
    5bd0:	54000322 	b.cs	5c34 <e173+0xc4>  // b.hs, b.nlast
    5bd4:	d350fc22 	lsr	x2, x1, #16
    5bd8:	f949fc63 	ldr	x3, [x3, #5112]
    5bdc:	8b020842 	add	x2, x2, x2, lsl #2
    5be0:	d37df042 	lsl	x2, x2, #3
    5be4:	8b020060 	add	x0, x3, x2
    5be8:	f9401014 	ldr	x20, [x0, #32]
    5bec:	b4000254 	cbz	x20, 5c34 <e173+0xc4>
    5bf0:	38626862 	ldrb	w2, [x3, x2]
    5bf4:	7100085f 	cmp	w2, #0x2
    5bf8:	540003a0 	b.eq	5c6c <e173+0xfc>  // b.none
    5bfc:	7100045f 	cmp	w2, #0x1
    5c00:	540001a1 	b.ne	5c34 <e173+0xc4>  // b.any
    5c04:	29430002 	ldp	w2, w0, [x0, #24]
    5c08:	92403c21 	and	x1, x1, #0xffff
    5c0c:	9b027c21 	mul	x1, x1, x2
    5c10:	d360fc21 	lsr	x1, x1, #32
    5c14:	eb00003f 	cmp	x1, x0
    5c18:	540000e2 	b.cs	5c34 <e173+0xc4>  // b.hs, b.nlast
    5c1c:	8b010294 	add	x20, x20, x1
    5c20:	39400280 	ldrb	w0, [x20]
    5c24:	7103fc1f 	cmp	w0, #0xff
    5c28:	54000280 	b.eq	5c78 <e173+0x108>  // b.none
    5c2c:	52800020 	mov	w0, #0x1                   	// #1
    5c30:	39000280 	strb	w0, [x20]
    5c34:	aa1303e0 	mov	x0, x19
    5c38:	97ffff12 	bl	5880 <fwp_rc_share>
    5c3c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5c40:	f947f400 	ldr	x0, [x0, #4072]
    5c44:	f9400fe2 	ldr	x2, [sp, #24]
    5c48:	f9400001 	ldr	x1, [x0]
    5c4c:	eb010042 	subs	x2, x2, x1
    5c50:	d2800001 	mov	x1, #0x0                   	// #0
    5c54:	540001a1 	b.ne	5c88 <e173+0x118>  // b.any
    5c58:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c5c:	aa1303e0 	mov	x0, x19
    5c60:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c64:	910103ff 	add	sp, sp, #0x40
    5c68:	d65f03c0 	ret
    5c6c:	72003c3f 	tst	w1, #0xffff
    5c70:	54fffe21 	b.ne	5c34 <e173+0xc4>  // b.any
    5c74:	17ffffeb 	b	5c20 <e173+0xb0>
    5c78:	aa1403e0 	mov	x0, x20
    5c7c:	97fffb65 	bl	4a10 <fwp_rc_forget_slot>
    5c80:	17ffffeb 	b	5c2c <e173+0xbc>
    5c84:	97fff37f 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5c88:	97fff306 	bl	28a0 <__stack_chk_fail@plt>
    5c8c:	d503201f 	nop

0000000000005c90 <fwp_drop0>:
    5c90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c94:	910003fd 	mov	x29, sp
    5c98:	a90153f3 	stp	x19, x20, [sp, #16]
    5c9c:	f90013f5 	str	x21, [sp, #32]
    5ca0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    5ca4:	911882b4 	add	x20, x21, #0x620
    5ca8:	f949da81 	ldr	x1, [x20, #5040]
    5cac:	f949ee82 	ldr	x2, [x20, #5080]
    5cb0:	cb010001 	sub	x1, x0, x1
    5cb4:	eb02403f 	cmp	x1, x2, lsl #16
    5cb8:	54000382 	b.cs	5d28 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cbc:	d350fc22 	lsr	x2, x1, #16
    5cc0:	f949fe84 	ldr	x4, [x20, #5112]
    5cc4:	8b020842 	add	x2, x2, x2, lsl #2
    5cc8:	d37df042 	lsl	x2, x2, #3
    5ccc:	8b020083 	add	x3, x4, x2
    5cd0:	f9401073 	ldr	x19, [x3, #32]
    5cd4:	b40002b3 	cbz	x19, 5d28 <fwp_drop0+0x98>
    5cd8:	38626882 	ldrb	w2, [x4, x2]
    5cdc:	7100085f 	cmp	w2, #0x2
    5ce0:	540002c0 	b.eq	5d38 <fwp_drop0+0xa8>  // b.none
    5ce4:	7100045f 	cmp	w2, #0x1
    5ce8:	54000201 	b.ne	5d28 <fwp_drop0+0x98>  // b.any
    5cec:	29430864 	ldp	w4, w2, [x3, #24]
    5cf0:	92403c21 	and	x1, x1, #0xffff
    5cf4:	9b047c21 	mul	x1, x1, x4
    5cf8:	d360fc21 	lsr	x1, x1, #32
    5cfc:	eb02003f 	cmp	x1, x2
    5d00:	54000142 	b.cs	5d28 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d04:	8b010273 	add	x19, x19, x1
    5d08:	39400261 	ldrb	w1, [x19]
    5d0c:	340000e1 	cbz	w1, 5d28 <fwp_drop0+0x98>
    5d10:	7100043f 	cmp	w1, #0x1
    5d14:	540001e0 	b.eq	5d50 <fwp_drop0+0xc0>  // b.none
    5d18:	7103fc3f 	cmp	w1, #0xff
    5d1c:	540002e0 	b.eq	5d78 <fwp_drop0+0xe8>  // b.none
    5d20:	51000421 	sub	w1, w1, #0x1
    5d24:	39000261 	strb	w1, [x19]
    5d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d2c:	f94013f5 	ldr	x21, [sp, #32]
    5d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d34:	d65f03c0 	ret
    5d38:	72003c3f 	tst	w1, #0xffff
    5d3c:	54fffe60 	b.eq	5d08 <fwp_drop0+0x78>  // b.none
    5d40:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d44:	f94013f5 	ldr	x21, [sp, #32]
    5d48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d4c:	d65f03c0 	ret
    5d50:	f9400813 	ldr	x19, [x0, #16]
    5d54:	97fffef0 	bl	5914 <fwp_rc_free_arr>
    5d58:	911882a0 	add	x0, x21, #0x620
    5d5c:	f949d801 	ldr	x1, [x0, #5040]
    5d60:	f949ec00 	ldr	x0, [x0, #5080]
    5d64:	cb010261 	sub	x1, x19, x1
    5d68:	eb00403f 	cmp	x1, x0, lsl #16
    5d6c:	54fffde2 	b.cs	5d28 <fwp_drop0+0x98>  // b.hs, b.nlast
    5d70:	aa1303e0 	mov	x0, x19
    5d74:	17ffffd2 	b	5cbc <fwp_drop0+0x2c>
    5d78:	ca534660 	eor	x0, x19, x19, lsr #17
    5d7c:	911882b5 	add	x21, x21, #0x620
    5d80:	ca402400 	eor	x0, x0, x0, lsr #9
    5d84:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5d88:	f94a2400 	ldr	x0, [x0, #5192]
    5d8c:	b5000080 	cbnz	x0, 5d9c <fwp_drop0+0x10c>
    5d90:	14000010 	b	5dd0 <fwp_drop0+0x140>
    5d94:	f9400800 	ldr	x0, [x0, #16]
    5d98:	b40001c0 	cbz	x0, 5dd0 <fwp_drop0+0x140>
    5d9c:	f9400001 	ldr	x1, [x0]
    5da0:	eb13003f 	cmp	x1, x19
    5da4:	54ffff81 	b.ne	5d94 <fwp_drop0+0x104>  // b.any
    5da8:	f9400401 	ldr	x1, [x0, #8]
    5dac:	d1000421 	sub	x1, x1, #0x1
    5db0:	f9000401 	str	x1, [x0, #8]
    5db4:	f103f83f 	cmp	x1, #0xfe
    5db8:	54fffb81 	b.ne	5d28 <fwp_drop0+0x98>  // b.any
    5dbc:	aa1303e0 	mov	x0, x19
    5dc0:	97fffb14 	bl	4a10 <fwp_rc_forget_slot>
    5dc4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5dc8:	39000260 	strb	w0, [x19]
    5dcc:	17ffffd7 	b	5d28 <fwp_drop0+0x98>
    5dd0:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    5dd4:	912cc000 	add	x0, x0, #0xb30
    5dd8:	97fff68a 	bl	3800 <fwp_trap>
    5ddc:	d503201f 	nop

0000000000005de0 <fwp_drop1>:
    5de0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5de4:	910003fd 	mov	x29, sp
    5de8:	a90153f3 	stp	x19, x20, [sp, #16]
    5dec:	f90013f5 	str	x21, [sp, #32]
    5df0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    5df4:	911882b4 	add	x20, x21, #0x620
    5df8:	f949da81 	ldr	x1, [x20, #5040]
    5dfc:	f949ee82 	ldr	x2, [x20, #5080]
    5e00:	cb010001 	sub	x1, x0, x1
    5e04:	eb02403f 	cmp	x1, x2, lsl #16
    5e08:	54000382 	b.cs	5e78 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e0c:	d350fc22 	lsr	x2, x1, #16
    5e10:	f949fe84 	ldr	x4, [x20, #5112]
    5e14:	8b020842 	add	x2, x2, x2, lsl #2
    5e18:	d37df042 	lsl	x2, x2, #3
    5e1c:	8b020083 	add	x3, x4, x2
    5e20:	f9401073 	ldr	x19, [x3, #32]
    5e24:	b40002b3 	cbz	x19, 5e78 <fwp_drop1+0x98>
    5e28:	38626882 	ldrb	w2, [x4, x2]
    5e2c:	7100085f 	cmp	w2, #0x2
    5e30:	540002c0 	b.eq	5e88 <fwp_drop1+0xa8>  // b.none
    5e34:	7100045f 	cmp	w2, #0x1
    5e38:	54000201 	b.ne	5e78 <fwp_drop1+0x98>  // b.any
    5e3c:	29430864 	ldp	w4, w2, [x3, #24]
    5e40:	92403c21 	and	x1, x1, #0xffff
    5e44:	9b047c21 	mul	x1, x1, x4
    5e48:	d360fc21 	lsr	x1, x1, #32
    5e4c:	eb02003f 	cmp	x1, x2
    5e50:	54000142 	b.cs	5e78 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e54:	8b010273 	add	x19, x19, x1
    5e58:	39400261 	ldrb	w1, [x19]
    5e5c:	340000e1 	cbz	w1, 5e78 <fwp_drop1+0x98>
    5e60:	7100043f 	cmp	w1, #0x1
    5e64:	540001e0 	b.eq	5ea0 <fwp_drop1+0xc0>  // b.none
    5e68:	7103fc3f 	cmp	w1, #0xff
    5e6c:	540002e0 	b.eq	5ec8 <fwp_drop1+0xe8>  // b.none
    5e70:	51000421 	sub	w1, w1, #0x1
    5e74:	39000261 	strb	w1, [x19]
    5e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e7c:	f94013f5 	ldr	x21, [sp, #32]
    5e80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e84:	d65f03c0 	ret
    5e88:	72003c3f 	tst	w1, #0xffff
    5e8c:	54fffe60 	b.eq	5e58 <fwp_drop1+0x78>  // b.none
    5e90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e94:	f94013f5 	ldr	x21, [sp, #32]
    5e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e9c:	d65f03c0 	ret
    5ea0:	f9400813 	ldr	x19, [x0, #16]
    5ea4:	97fffe9c 	bl	5914 <fwp_rc_free_arr>
    5ea8:	911882a0 	add	x0, x21, #0x620
    5eac:	f949d801 	ldr	x1, [x0, #5040]
    5eb0:	f949ec00 	ldr	x0, [x0, #5080]
    5eb4:	cb010261 	sub	x1, x19, x1
    5eb8:	eb00403f 	cmp	x1, x0, lsl #16
    5ebc:	54fffde2 	b.cs	5e78 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ec0:	aa1303e0 	mov	x0, x19
    5ec4:	17ffffd2 	b	5e0c <fwp_drop1+0x2c>
    5ec8:	ca534660 	eor	x0, x19, x19, lsr #17
    5ecc:	911882b5 	add	x21, x21, #0x620
    5ed0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ed4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5ed8:	f94a2400 	ldr	x0, [x0, #5192]
    5edc:	b5000080 	cbnz	x0, 5eec <fwp_drop1+0x10c>
    5ee0:	14000010 	b	5f20 <fwp_drop1+0x140>
    5ee4:	f9400800 	ldr	x0, [x0, #16]
    5ee8:	b40001c0 	cbz	x0, 5f20 <fwp_drop1+0x140>
    5eec:	f9400001 	ldr	x1, [x0]
    5ef0:	eb13003f 	cmp	x1, x19
    5ef4:	54ffff81 	b.ne	5ee4 <fwp_drop1+0x104>  // b.any
    5ef8:	f9400401 	ldr	x1, [x0, #8]
    5efc:	d1000421 	sub	x1, x1, #0x1
    5f00:	f9000401 	str	x1, [x0, #8]
    5f04:	f103f83f 	cmp	x1, #0xfe
    5f08:	54fffb81 	b.ne	5e78 <fwp_drop1+0x98>  // b.any
    5f0c:	aa1303e0 	mov	x0, x19
    5f10:	97fffac0 	bl	4a10 <fwp_rc_forget_slot>
    5f14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f18:	39000260 	strb	w0, [x19]
    5f1c:	17ffffd7 	b	5e78 <fwp_drop1+0x98>
    5f20:	90000020 	adrp	x0, 9000 <__divti3+0xb0>
    5f24:	912cc000 	add	x0, x0, #0xb30
    5f28:	97fff636 	bl	3800 <fwp_trap>
    5f2c:	d503201f 	nop

0000000000005f30 <fwp_closure_drop>:
    5f30:	900003a5 	adrp	x5, 79000 <fwp_root_context+0xbc0>
    5f34:	911880a4 	add	x4, x5, #0x620
    5f38:	aa0003e1 	mov	x1, x0
    5f3c:	f949d882 	ldr	x2, [x4, #5040]
    5f40:	f949ec80 	ldr	x0, [x4, #5080]
    5f44:	cb020022 	sub	x2, x1, x2
    5f48:	eb00405f 	cmp	x2, x0, lsl #16
    5f4c:	54000662 	b.cs	6018 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5f54:	d350fc43 	lsr	x3, x2, #16
    5f58:	910003fd 	mov	x29, sp
    5f5c:	8b030863 	add	x3, x3, x3, lsl #2
    5f60:	f949fc84 	ldr	x4, [x4, #5112]
    5f64:	d37df063 	lsl	x3, x3, #3
    5f68:	f9000bf3 	str	x19, [sp, #16]
    5f6c:	8b030080 	add	x0, x4, x3
    5f70:	f9401013 	ldr	x19, [x0, #32]
    5f74:	b40002b3 	cbz	x19, 5fc8 <fwp_closure_drop+0x98>
    5f78:	38636883 	ldrb	w3, [x4, x3]
    5f7c:	7100087f 	cmp	w3, #0x2
    5f80:	54000420 	b.eq	6004 <fwp_closure_drop+0xd4>  // b.none
    5f84:	7100047f 	cmp	w3, #0x1
    5f88:	54000201 	b.ne	5fc8 <fwp_closure_drop+0x98>  // b.any
    5f8c:	29430003 	ldp	w3, w0, [x0, #24]
    5f90:	92403c42 	and	x2, x2, #0xffff
    5f94:	9b037c42 	mul	x2, x2, x3
    5f98:	d360fc42 	lsr	x2, x2, #32
    5f9c:	eb00005f 	cmp	x2, x0
    5fa0:	54000142 	b.cs	5fc8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5fa4:	8b020273 	add	x19, x19, x2
    5fa8:	39400260 	ldrb	w0, [x19]
    5fac:	340000e0 	cbz	w0, 5fc8 <fwp_closure_drop+0x98>
    5fb0:	7100041f 	cmp	w0, #0x1
    5fb4:	54000100 	b.eq	5fd4 <fwp_closure_drop+0xa4>  // b.none
    5fb8:	7103fc1f 	cmp	w0, #0xff
    5fbc:	54000300 	b.eq	601c <fwp_closure_drop+0xec>  // b.none
    5fc0:	51000400 	sub	w0, w0, #0x1
    5fc4:	39000260 	strb	w0, [x19]
    5fc8:	f9400bf3 	ldr	x19, [sp, #16]
    5fcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fd0:	d65f03c0 	ret
    5fd4:	d53bd040 	mrs	x0, tpidr_el0
    5fd8:	91400000 	add	x0, x0, #0x0, lsl #12
    5fdc:	91004000 	add	x0, x0, #0x10
    5fe0:	f9400000 	ldr	x0, [x0]
    5fe4:	b4000080 	cbz	x0, 5ff4 <fwp_closure_drop+0xc4>
    5fe8:	f9400bf3 	ldr	x19, [sp, #16]
    5fec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ff0:	17fff61d 	b	3864 <fwp_closure_drop_push>
    5ff4:	f9400bf3 	ldr	x19, [sp, #16]
    5ff8:	aa0103e0 	mov	x0, x1
    5ffc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6000:	17fff688 	b	3a20 <fwp_closure_drop.part.0>
    6004:	72003c5f 	tst	w2, #0xffff
    6008:	54fffd00 	b.eq	5fa8 <fwp_closure_drop+0x78>  // b.none
    600c:	f9400bf3 	ldr	x19, [sp, #16]
    6010:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6014:	d65f03c0 	ret
    6018:	d65f03c0 	ret
    601c:	ca534660 	eor	x0, x19, x19, lsr #17
    6020:	911880a5 	add	x5, x5, #0x620
    6024:	ca402400 	eor	x0, x0, x0, lsr #9
    6028:	8b200ca0 	add	x0, x5, w0, uxtb #3
    602c:	f94a2400 	ldr	x0, [x0, #5192]
    6030:	b5000080 	cbnz	x0, 6040 <fwp_closure_drop+0x110>
    6034:	14000010 	b	6074 <fwp_closure_drop+0x144>
    6038:	f9400800 	ldr	x0, [x0, #16]
    603c:	b40001c0 	cbz	x0, 6074 <fwp_closure_drop+0x144>
    6040:	f9400001 	ldr	x1, [x0]
    6044:	eb13003f 	cmp	x1, x19
    6048:	54ffff81 	b.ne	6038 <fwp_closure_drop+0x108>  // b.any
    604c:	f9400401 	ldr	x1, [x0, #8]
    6050:	d1000421 	sub	x1, x1, #0x1
    6054:	f9000401 	str	x1, [x0, #8]
    6058:	f103f83f 	cmp	x1, #0xfe
    605c:	54fffb61 	b.ne	5fc8 <fwp_closure_drop+0x98>  // b.any
    6060:	aa1303e0 	mov	x0, x19
    6064:	97fffa6b 	bl	4a10 <fwp_rc_forget_slot>
    6068:	12800020 	mov	w0, #0xfffffffe            	// #-2
    606c:	39000260 	strb	w0, [x19]
    6070:	17ffffd6 	b	5fc8 <fwp_closure_drop+0x98>
    6074:	f0000000 	adrp	x0, 9000 <__divti3+0xb0>
    6078:	912cc000 	add	x0, x0, #0xb30
    607c:	97fff5e1 	bl	3800 <fwp_trap>

0000000000006080 <fwp_owned_tape_release>:
    6080:	b4000940 	cbz	x0, 61a8 <fwp_owned_tape_release+0x128>
    6084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6088:	910003fd 	mov	x29, sp
    608c:	a90153f3 	stp	x19, x20, [sp, #16]
    6090:	aa0003f3 	mov	x19, x0
    6094:	f9400000 	ldr	x0, [x0]
    6098:	b4000060 	cbz	x0, 60a4 <fwp_owned_tape_release+0x24>
    609c:	f9400661 	ldr	x1, [x19, #8]
    60a0:	f9000401 	str	x1, [x0, #8]
    60a4:	f9400661 	ldr	x1, [x19, #8]
    60a8:	b4000041 	cbz	x1, 60b0 <fwp_owned_tape_release+0x30>
    60ac:	f9000020 	str	x0, [x1]
    60b0:	f9400a60 	ldr	x0, [x19, #16]
    60b4:	f9403401 	ldr	x1, [x0, #104]
    60b8:	b40005c1 	cbz	x1, 6170 <fwp_owned_tape_release+0xf0>
    60bc:	a9450a60 	ldp	x0, x2, [x19, #80]
    60c0:	eb00005f 	cmp	x2, x0
    60c4:	540002ed 	b.le	6120 <fwp_owned_tape_release+0xa0>
    60c8:	d2800014 	mov	x20, #0x0                   	// #0
    60cc:	f90013f5 	str	x21, [sp, #32]
    60d0:	d2800015 	mov	x21, #0x0                   	// #0
    60d4:	d503201f 	nop
    60d8:	f9402260 	ldr	x0, [x19, #64]
    60dc:	910006b5 	add	x21, x21, #0x1
    60e0:	f8746800 	ldr	x0, [x0, x20]
    60e4:	d63f0020 	blr	x1
    60e8:	f9402260 	ldr	x0, [x19, #64]
    60ec:	f9400a61 	ldr	x1, [x19, #16]
    60f0:	8b140000 	add	x0, x0, x20
    60f4:	91004294 	add	x20, x20, #0x10
    60f8:	f9400400 	ldr	x0, [x0, #8]
    60fc:	f9403421 	ldr	x1, [x1, #104]
    6100:	d63f0020 	blr	x1
    6104:	a9450261 	ldp	x1, x0, [x19, #80]
    6108:	cb010000 	sub	x0, x0, x1
    610c:	eb15001f 	cmp	x0, x21
    6110:	f9400a60 	ldr	x0, [x19, #16]
    6114:	f9403401 	ldr	x1, [x0, #104]
    6118:	54fffe0c 	b.gt	60d8 <fwp_owned_tape_release+0x58>
    611c:	f94013f5 	ldr	x21, [sp, #32]
    6120:	f9403663 	ldr	x3, [x19, #104]
    6124:	f9401262 	ldr	x2, [x19, #32]
    6128:	f100007f 	cmp	x3, #0x0
    612c:	540001ed 	b.le	6168 <fwp_owned_tape_release+0xe8>
    6130:	d2800014 	mov	x20, #0x0                   	// #0
    6134:	d503201f 	nop
    6138:	f9402660 	ldr	x0, [x19, #72]
    613c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6140:	eb02001f 	cmp	x0, x2
    6144:	540000c0 	b.eq	615c <fwp_owned_tape_release+0xdc>  // b.none
    6148:	d63f0020 	blr	x1
    614c:	f9400a60 	ldr	x0, [x19, #16]
    6150:	f9401262 	ldr	x2, [x19, #32]
    6154:	f9403663 	ldr	x3, [x19, #104]
    6158:	f9403401 	ldr	x1, [x0, #104]
    615c:	91000694 	add	x20, x20, #0x1
    6160:	eb14007f 	cmp	x3, x20
    6164:	54fffeac 	b.gt	6138 <fwp_owned_tape_release+0xb8>
    6168:	aa0203e0 	mov	x0, x2
    616c:	d63f0020 	blr	x1
    6170:	f9401660 	ldr	x0, [x19, #40]
    6174:	97ffff6f 	bl	5f30 <fwp_closure_drop>
    6178:	f9401a60 	ldr	x0, [x19, #48]
    617c:	97ffff6d 	bl	5f30 <fwp_closure_drop>
    6180:	f9401e60 	ldr	x0, [x19, #56]
    6184:	97ffff6b 	bl	5f30 <fwp_closure_drop>
    6188:	f9402260 	ldr	x0, [x19, #64]
    618c:	97fffac1 	bl	4c90 <fwp_mem_free>
    6190:	f9402660 	ldr	x0, [x19, #72]
    6194:	97fffabf 	bl	4c90 <fwp_mem_free>
    6198:	aa1303e0 	mov	x0, x19
    619c:	a94153f3 	ldp	x19, x20, [sp, #16]
    61a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61a4:	17fffabb 	b	4c90 <fwp_mem_free>
    61a8:	d65f03c0 	ret
    61ac:	d503201f 	nop

00000000000061b0 <fwp_tape_finish>:
    61b0:	d10203ff 	sub	sp, sp, #0x80
    61b4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    61b8:	f947f421 	ldr	x1, [x1, #4072]
    61bc:	a9047bfd 	stp	x29, x30, [sp, #64]
    61c0:	910103fd 	add	x29, sp, #0x40
    61c4:	a9065bf5 	stp	x21, x22, [sp, #96]
    61c8:	a90763f7 	stp	x23, x24, [sp, #112]
    61cc:	d00000d7 	adrp	x23, 20000 <__data_start>
    61d0:	910142f6 	add	x22, x23, #0x50
    61d4:	f9400022 	ldr	x2, [x1]
    61d8:	f9001fe2 	str	x2, [sp, #56]
    61dc:	d2800002 	mov	x2, #0x0                   	// #0
    61e0:	910382c0 	add	x0, x22, #0xe0
    61e4:	97fff888 	bl	4404 <fwp_tape_buffers_dispose>
    61e8:	f9008edf 	str	xzr, [x22, #280]
    61ec:	f9406ec0 	ldr	x0, [x22, #216]
    61f0:	f100001f 	cmp	x0, #0x0
    61f4:	5400034d 	b.le	625c <fwp_tape_finish+0xac>
    61f8:	910003f8 	mov	x24, sp
    61fc:	d2800015 	mov	x21, #0x0                   	// #0
    6200:	a90553f3 	stp	x19, x20, [sp, #80]
    6204:	d2800014 	mov	x20, #0x0                   	// #0
    6208:	91000694 	add	x20, x20, #0x1
    620c:	f94046d3 	ldr	x19, [x22, #136]
    6210:	8b150273 	add	x19, x19, x21
    6214:	9101a2b5 	add	x21, x21, #0x68
    6218:	aa1303e0 	mov	x0, x19
    621c:	97fff37e 	bl	3014 <fwp_tape_unlink_scope>
    6220:	aa1803e0 	mov	x0, x24
    6224:	a9440663 	ldp	x3, x1, [x19, #64]
    6228:	f9001be1 	str	x1, [sp, #48]
    622c:	f9400e62 	ldr	x2, [x19, #24]
    6230:	a9020be3 	stp	x3, x2, [sp, #32]
    6234:	ad410261 	ldp	q1, q0, [x19, #32]
    6238:	ad0003e1 	stp	q1, q0, [sp]
    623c:	97fff872 	bl	4404 <fwp_tape_buffers_dispose>
    6240:	f9403260 	ldr	x0, [x19, #96]
    6244:	97ffff8f 	bl	6080 <fwp_owned_tape_release>
    6248:	f900327f 	str	xzr, [x19, #96]
    624c:	f9406ec0 	ldr	x0, [x22, #216]
    6250:	eb14001f 	cmp	x0, x20
    6254:	54fffdac 	b.gt	6208 <fwp_tape_finish+0x58>
    6258:	a94553f3 	ldp	x19, x20, [sp, #80]
    625c:	910142e0 	add	x0, x23, #0x50
    6260:	f9404400 	ldr	x0, [x0, #136]
    6264:	b4000040 	cbz	x0, 626c <fwp_tape_finish+0xbc>
    6268:	97fff846 	bl	4380 <ad_raw_free.part.0>
    626c:	910142f7 	add	x23, x23, #0x50
    6270:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6274:	f947f400 	ldr	x0, [x0, #4072]
    6278:	f90046ff 	str	xzr, [x23, #136]
    627c:	f9006eff 	str	xzr, [x23, #216]
    6280:	f90092ff 	str	xzr, [x23, #288]
    6284:	f900b2ff 	str	xzr, [x23, #352]
    6288:	f9401fe2 	ldr	x2, [sp, #56]
    628c:	f9400001 	ldr	x1, [x0]
    6290:	eb010042 	subs	x2, x2, x1
    6294:	d2800001 	mov	x1, #0x0                   	// #0
    6298:	540000c1 	b.ne	62b0 <fwp_tape_finish+0x100>  // b.any
    629c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    62a0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    62a4:	a94763f7 	ldp	x23, x24, [sp, #112]
    62a8:	910203ff 	add	sp, sp, #0x80
    62ac:	d65f03c0 	ret
    62b0:	a90553f3 	stp	x19, x20, [sp, #80]
    62b4:	97fff17b 	bl	28a0 <__stack_chk_fail@plt>
    62b8:	d503201f 	nop
    62bc:	d503201f 	nop

00000000000062c0 <fwp_tape_scope_release>:
    62c0:	d10243ff 	sub	sp, sp, #0x90
    62c4:	a9047bfd 	stp	x29, x30, [sp, #64]
    62c8:	910103fd 	add	x29, sp, #0x40
    62cc:	a90553f3 	stp	x19, x20, [sp, #80]
    62d0:	aa0003f4 	mov	x20, x0
    62d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    62d8:	f947f400 	ldr	x0, [x0, #4072]
    62dc:	b9400285 	ldr	w5, [x20]
    62e0:	f9400001 	ldr	x1, [x0]
    62e4:	f9001fe1 	str	x1, [sp, #56]
    62e8:	d2800001 	mov	x1, #0x0                   	// #0
    62ec:	37f806c5 	tbnz	w5, #31, 63c4 <fwp_tape_scope_release+0x104>
    62f0:	a90763f7 	stp	x23, x24, [sp, #112]
    62f4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    62f8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    62fc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6300:	d00000d3 	adrp	x19, 20000 <__data_start>
    6304:	910003f7 	mov	x23, sp
    6308:	91014273 	add	x19, x19, #0x50
    630c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6310:	a9065bf5 	stp	x21, x22, [sp, #96]
    6314:	52800d16 	mov	w22, #0x68                  	// #104
    6318:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    631c:	f90043f9 	str	x25, [sp, #128]
    6320:	14000006 	b	6338 <fwp_tape_scope_release+0x78>
    6324:	97fff838 	bl	4404 <fwp_tape_buffers_dispose>
    6328:	aa1903e0 	mov	x0, x25
    632c:	97ffff55 	bl	6080 <fwp_owned_tape_release>
    6330:	b9400285 	ldr	w5, [x20]
    6334:	37f80425 	tbnz	w5, #31, 63b8 <fwp_tape_scope_release+0xf8>
    6338:	f9404666 	ldr	x6, [x19, #136]
    633c:	9b367ca5 	smull	x5, w5, w22
    6340:	8b0500c0 	add	x0, x6, x5
    6344:	97fff334 	bl	3014 <fwp_tape_unlink_scope>
    6348:	ad410001 	ldp	q1, q0, [x0, #32]
    634c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6350:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6354:	f9400c03 	ldr	x3, [x0, #24]
    6358:	ad0003e1 	stp	q1, q0, [sp]
    635c:	b86568c1 	ldr	w1, [x6, x5]
    6360:	a9440804 	ldp	x4, x2, [x0, #64]
    6364:	b900041f 	str	wzr, [x0, #4]
    6368:	f9403019 	ldr	x25, [x0, #96]
    636c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6370:	f9000c1f 	str	xzr, [x0, #24]
    6374:	a9020fe4 	stp	x4, x3, [sp, #32]
    6378:	f9001be2 	str	x2, [sp, #48]
    637c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6380:	f900301f 	str	xzr, [x0, #96]
    6384:	6b15003f 	cmp	w1, w21
    6388:	540000e8 	b.hi	63a4 <fwp_tape_scope_release+0xe4>  // b.pmore
    638c:	9343fca5 	asr	x5, x5, #3
    6390:	f940b260 	ldr	x0, [x19, #352]
    6394:	9b187ca5 	mul	x5, x5, x24
    6398:	eb0000bf 	cmp	x5, x0
    639c:	5400004a 	b.ge	63a4 <fwp_tape_scope_release+0xe4>  // b.tcont
    63a0:	f900b265 	str	x5, [x19, #352]
    63a4:	aa1703e0 	mov	x0, x23
    63a8:	b5fffbf9 	cbnz	x25, 6324 <fwp_tape_scope_release+0x64>
    63ac:	97fff85e 	bl	4524 <fwp_tape_buffers_release>
    63b0:	b9400285 	ldr	w5, [x20]
    63b4:	36fffc25 	tbz	w5, #31, 6338 <fwp_tape_scope_release+0x78>
    63b8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63bc:	a94763f7 	ldp	x23, x24, [sp, #112]
    63c0:	f94043f9 	ldr	x25, [sp, #128]
    63c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    63c8:	f947f400 	ldr	x0, [x0, #4072]
    63cc:	f9401fe2 	ldr	x2, [sp, #56]
    63d0:	f9400001 	ldr	x1, [x0]
    63d4:	eb010042 	subs	x2, x2, x1
    63d8:	d2800001 	mov	x1, #0x0                   	// #0
    63dc:	540000a1 	b.ne	63f0 <fwp_tape_scope_release+0x130>  // b.any
    63e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63e4:	a94553f3 	ldp	x19, x20, [sp, #80]
    63e8:	910243ff 	add	sp, sp, #0x90
    63ec:	d65f03c0 	ret
    63f0:	a9065bf5 	stp	x21, x22, [sp, #96]
    63f4:	a90763f7 	stp	x23, x24, [sp, #112]
    63f8:	f90043f9 	str	x25, [sp, #128]
    63fc:	97fff129 	bl	28a0 <__stack_chk_fail@plt>

0000000000006400 <fwp_drop4>:
    6400:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6404:	910003fd 	mov	x29, sp
    6408:	a9025bf5 	stp	x21, x22, [sp, #32]
    640c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    6410:	911882d5 	add	x21, x22, #0x620
    6414:	a90153f3 	stp	x19, x20, [sp, #16]
    6418:	aa0003f3 	mov	x19, x0
    641c:	f949daa1 	ldr	x1, [x21, #5040]
    6420:	f949eea0 	ldr	x0, [x21, #5080]
    6424:	cb010261 	sub	x1, x19, x1
    6428:	eb00403f 	cmp	x1, x0, lsl #16
    642c:	54000382 	b.cs	649c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6430:	d350fc22 	lsr	x2, x1, #16
    6434:	f949fea3 	ldr	x3, [x21, #5112]
    6438:	8b020842 	add	x2, x2, x2, lsl #2
    643c:	d37df042 	lsl	x2, x2, #3
    6440:	8b020060 	add	x0, x3, x2
    6444:	f9401014 	ldr	x20, [x0, #32]
    6448:	b40002b4 	cbz	x20, 649c <fwp_drop4+0x9c>
    644c:	38626862 	ldrb	w2, [x3, x2]
    6450:	7100085f 	cmp	w2, #0x2
    6454:	540002c0 	b.eq	64ac <fwp_drop4+0xac>  // b.none
    6458:	7100045f 	cmp	w2, #0x1
    645c:	54000201 	b.ne	649c <fwp_drop4+0x9c>  // b.any
    6460:	29430002 	ldp	w2, w0, [x0, #24]
    6464:	92403c21 	and	x1, x1, #0xffff
    6468:	9b027c21 	mul	x1, x1, x2
    646c:	d360fc21 	lsr	x1, x1, #32
    6470:	eb00003f 	cmp	x1, x0
    6474:	54000142 	b.cs	649c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6478:	8b010294 	add	x20, x20, x1
    647c:	39400280 	ldrb	w0, [x20]
    6480:	340000e0 	cbz	w0, 649c <fwp_drop4+0x9c>
    6484:	7100041f 	cmp	w0, #0x1
    6488:	540001e0 	b.eq	64c4 <fwp_drop4+0xc4>  // b.none
    648c:	7103fc1f 	cmp	w0, #0xff
    6490:	540007c0 	b.eq	6588 <fwp_drop4+0x188>  // b.none
    6494:	51000400 	sub	w0, w0, #0x1
    6498:	39000280 	strb	w0, [x20]
    649c:	a94153f3 	ldp	x19, x20, [sp, #16]
    64a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    64a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    64a8:	d65f03c0 	ret
    64ac:	72003c3f 	tst	w1, #0xffff
    64b0:	54fffe60 	b.eq	647c <fwp_drop4+0x7c>  // b.none
    64b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    64b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    64bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    64c0:	d65f03c0 	ret
    64c4:	911882c2 	add	x2, x22, #0x620
    64c8:	f9400660 	ldr	x0, [x19, #8]
    64cc:	f949d841 	ldr	x1, [x2, #5040]
    64d0:	f949ec42 	ldr	x2, [x2, #5080]
    64d4:	cb010001 	sub	x1, x0, x1
    64d8:	eb02403f 	cmp	x1, x2, lsl #16
    64dc:	54000362 	b.cs	6548 <fwp_drop4+0x148>  // b.hs, b.nlast
    64e0:	d350fc22 	lsr	x2, x1, #16
    64e4:	8b020842 	add	x2, x2, x2, lsl #2
    64e8:	d37df042 	lsl	x2, x2, #3
    64ec:	8b020064 	add	x4, x3, x2
    64f0:	f9401094 	ldr	x20, [x4, #32]
    64f4:	b40002b4 	cbz	x20, 6548 <fwp_drop4+0x148>
    64f8:	38626862 	ldrb	w2, [x3, x2]
    64fc:	7100085f 	cmp	w2, #0x2
    6500:	540003e0 	b.eq	657c <fwp_drop4+0x17c>  // b.none
    6504:	7100045f 	cmp	w2, #0x1
    6508:	54000201 	b.ne	6548 <fwp_drop4+0x148>  // b.any
    650c:	29430883 	ldp	w3, w2, [x4, #24]
    6510:	92403c21 	and	x1, x1, #0xffff
    6514:	9b037c21 	mul	x1, x1, x3
    6518:	d360fc21 	lsr	x1, x1, #32
    651c:	eb02003f 	cmp	x1, x2
    6520:	54000142 	b.cs	6548 <fwp_drop4+0x148>  // b.hs, b.nlast
    6524:	8b010294 	add	x20, x20, x1
    6528:	39400281 	ldrb	w1, [x20]
    652c:	340000e1 	cbz	w1, 6548 <fwp_drop4+0x148>
    6530:	7100043f 	cmp	w1, #0x1
    6534:	54000200 	b.eq	6574 <fwp_drop4+0x174>  // b.none
    6538:	7103fc3f 	cmp	w1, #0xff
    653c:	54000580 	b.eq	65ec <fwp_drop4+0x1ec>  // b.none
    6540:	51000421 	sub	w1, w1, #0x1
    6544:	39000281 	strb	w1, [x20]
    6548:	f9400a74 	ldr	x20, [x19, #16]
    654c:	aa1303e0 	mov	x0, x19
    6550:	97fffcf1 	bl	5914 <fwp_rc_free_arr>
    6554:	911882c0 	add	x0, x22, #0x620
    6558:	f949d801 	ldr	x1, [x0, #5040]
    655c:	f949ec00 	ldr	x0, [x0, #5080]
    6560:	cb010281 	sub	x1, x20, x1
    6564:	eb00403f 	cmp	x1, x0, lsl #16
    6568:	54fff9a2 	b.cs	649c <fwp_drop4+0x9c>  // b.hs, b.nlast
    656c:	aa1403f3 	mov	x19, x20
    6570:	17ffffb0 	b	6430 <fwp_drop4+0x30>
    6574:	97fffce8 	bl	5914 <fwp_rc_free_arr>
    6578:	17fffff4 	b	6548 <fwp_drop4+0x148>
    657c:	72003c3f 	tst	w1, #0xffff
    6580:	54fffe41 	b.ne	6548 <fwp_drop4+0x148>  // b.any
    6584:	17ffffe9 	b	6528 <fwp_drop4+0x128>
    6588:	ca544681 	eor	x1, x20, x20, lsr #17
    658c:	911882c0 	add	x0, x22, #0x620
    6590:	ca412421 	eor	x1, x1, x1, lsr #9
    6594:	8b210c01 	add	x1, x0, w1, uxtb #3
    6598:	f94a2420 	ldr	x0, [x1, #5192]
    659c:	b5000080 	cbnz	x0, 65ac <fwp_drop4+0x1ac>
    65a0:	14000010 	b	65e0 <fwp_drop4+0x1e0>
    65a4:	f9400800 	ldr	x0, [x0, #16]
    65a8:	b40001c0 	cbz	x0, 65e0 <fwp_drop4+0x1e0>
    65ac:	f9400001 	ldr	x1, [x0]
    65b0:	eb14003f 	cmp	x1, x20
    65b4:	54ffff81 	b.ne	65a4 <fwp_drop4+0x1a4>  // b.any
    65b8:	f9400401 	ldr	x1, [x0, #8]
    65bc:	d1000421 	sub	x1, x1, #0x1
    65c0:	f9000401 	str	x1, [x0, #8]
    65c4:	f103f83f 	cmp	x1, #0xfe
    65c8:	54fff6a1 	b.ne	649c <fwp_drop4+0x9c>  // b.any
    65cc:	aa1403e0 	mov	x0, x20
    65d0:	97fff910 	bl	4a10 <fwp_rc_forget_slot>
    65d4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65d8:	39000280 	strb	w0, [x20]
    65dc:	17ffffb0 	b	649c <fwp_drop4+0x9c>
    65e0:	f0000000 	adrp	x0, 9000 <__divti3+0xb0>
    65e4:	912cc000 	add	x0, x0, #0xb30
    65e8:	97fff486 	bl	3800 <fwp_trap>
    65ec:	ca544680 	eor	x0, x20, x20, lsr #17
    65f0:	911882c1 	add	x1, x22, #0x620
    65f4:	ca402400 	eor	x0, x0, x0, lsr #9
    65f8:	8b200c20 	add	x0, x1, w0, uxtb #3
    65fc:	f94a2400 	ldr	x0, [x0, #5192]
    6600:	b5000080 	cbnz	x0, 6610 <fwp_drop4+0x210>
    6604:	17fffff7 	b	65e0 <fwp_drop4+0x1e0>
    6608:	f9400800 	ldr	x0, [x0, #16]
    660c:	b4fffea0 	cbz	x0, 65e0 <fwp_drop4+0x1e0>
    6610:	f9400001 	ldr	x1, [x0]
    6614:	eb14003f 	cmp	x1, x20
    6618:	54ffff81 	b.ne	6608 <fwp_drop4+0x208>  // b.any
    661c:	f9400401 	ldr	x1, [x0, #8]
    6620:	d1000421 	sub	x1, x1, #0x1
    6624:	f9000401 	str	x1, [x0, #8]
    6628:	f103f83f 	cmp	x1, #0xfe
    662c:	54fff8e1 	b.ne	6548 <fwp_drop4+0x148>  // b.any
    6630:	aa1403e0 	mov	x0, x20
    6634:	97fff8f7 	bl	4a10 <fwp_rc_forget_slot>
    6638:	12800020 	mov	w0, #0xfffffffe            	// #-2
    663c:	39000280 	strb	w0, [x20]
    6640:	17ffffc2 	b	6548 <fwp_drop4+0x148>

0000000000006644 <fwp_arg_drop37>:
    6644:	7100003f 	cmp	w1, #0x0
    6648:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    664c:	54000041 	b.ne	6654 <fwp_arg_drop37+0x10>  // b.any
    6650:	d65f03c0 	ret
    6654:	f9400000 	ldr	x0, [x0]
    6658:	17ffff6a 	b	6400 <fwp_drop4>
    665c:	d503201f 	nop

0000000000006660 <fwp_task_dispose>:
    6660:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6664:	910003fd 	mov	x29, sp
    6668:	f9000bf3 	str	x19, [sp, #16]
    666c:	aa0003f3 	mov	x19, x0
    6670:	39414000 	ldrb	w0, [x0, #80]
    6674:	36000720 	tbz	w0, #0, 6758 <fwp_task_dispose+0xf8>
    6678:	f9400a60 	ldr	x0, [x19, #16]
    667c:	b50006e0 	cbnz	x0, 6758 <fwp_task_dispose+0xf8>
    6680:	a9478660 	ldp	x0, x1, [x19, #120]
    6684:	39014e7f 	strb	wzr, [x19, #83]
    6688:	f9003e7f 	str	xzr, [x19, #120]
    668c:	f100003f 	cmp	x1, #0x0
    6690:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6694:	54000040 	b.eq	669c <fwp_task_dispose+0x3c>  // b.none
    6698:	d63f0020 	blr	x1
    669c:	f9405660 	ldr	x0, [x19, #168]
    66a0:	97fff97c 	bl	4c90 <fwp_mem_free>
    66a4:	f900567f 	str	xzr, [x19, #168]
    66a8:	b9405e60 	ldr	w0, [x19, #92]
    66ac:	7100041f 	cmp	w0, #0x1
    66b0:	54000420 	b.eq	6734 <fwp_task_dispose+0xd4>  // b.none
    66b4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    66b8:	91188042 	add	x2, x2, #0x620
    66bc:	f949d840 	ldr	x0, [x2, #5040]
    66c0:	f949ec41 	ldr	x1, [x2, #5080]
    66c4:	cb000260 	sub	x0, x19, x0
    66c8:	eb01401f 	cmp	x0, x1, lsl #16
    66cc:	540002e2 	b.cs	6728 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    66d0:	d350fc01 	lsr	x1, x0, #16
    66d4:	f949fc44 	ldr	x4, [x2, #5112]
    66d8:	8b010821 	add	x1, x1, x1, lsl #2
    66dc:	d37df021 	lsl	x1, x1, #3
    66e0:	8b010083 	add	x3, x4, x1
    66e4:	f9401062 	ldr	x2, [x3, #32]
    66e8:	b4000202 	cbz	x2, 6728 <fwp_task_dispose+0xc8>
    66ec:	38616881 	ldrb	w1, [x4, x1]
    66f0:	7100083f 	cmp	w1, #0x2
    66f4:	54000280 	b.eq	6744 <fwp_task_dispose+0xe4>  // b.none
    66f8:	7100043f 	cmp	w1, #0x1
    66fc:	54000161 	b.ne	6728 <fwp_task_dispose+0xc8>  // b.any
    6700:	29430464 	ldp	w4, w1, [x3, #24]
    6704:	92403c00 	and	x0, x0, #0xffff
    6708:	9b047c00 	mul	x0, x0, x4
    670c:	d360fc00 	lsr	x0, x0, #32
    6710:	eb01001f 	cmp	x0, x1
    6714:	540000a2 	b.cs	6728 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6718:	8b000042 	add	x2, x2, x0
    671c:	39400040 	ldrb	w0, [x2]
    6720:	7100041f 	cmp	w0, #0x1
    6724:	54000080 	b.eq	6734 <fwp_task_dispose+0xd4>  // b.none
    6728:	f9400bf3 	ldr	x19, [sp, #16]
    672c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6730:	d65f03c0 	ret
    6734:	aa1303e0 	mov	x0, x19
    6738:	f9400bf3 	ldr	x19, [sp, #16]
    673c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6740:	17fff954 	b	4c90 <fwp_mem_free>
    6744:	72003c1f 	tst	w0, #0xffff
    6748:	54fffea0 	b.eq	671c <fwp_task_dispose+0xbc>  // b.none
    674c:	f9400bf3 	ldr	x19, [sp, #16]
    6750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6754:	d65f03c0 	ret
    6758:	97fff066 	bl	28f0 <abort@plt>
    675c:	d503201f 	nop

0000000000006760 <fwp_free_zombie>:
    6760:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6764:	910003fd 	mov	x29, sp
    6768:	a90153f3 	stp	x19, x20, [sp, #16]
    676c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6770:	91014281 	add	x1, x20, #0x50
    6774:	f940b433 	ldr	x19, [x1, #360]
    6778:	b4000333 	cbz	x19, 67dc <fwp_free_zombie+0x7c>
    677c:	f9404c20 	ldr	x0, [x1, #152]
    6780:	eb00027f 	cmp	x19, x0
    6784:	540002c0 	b.eq	67dc <fwp_free_zombie+0x7c>  // b.none
    6788:	b9417022 	ldr	w2, [x1, #368]
    678c:	f9400a60 	ldr	x0, [x19, #16]
    6790:	7100fc5f 	cmp	w2, #0x3f
    6794:	5400078c 	b.gt	6884 <fwp_free_zombie+0x124>
    6798:	91060023 	add	x3, x1, #0x180
    679c:	11000444 	add	w4, w2, #0x1
    67a0:	b9017024 	str	w4, [x1, #368]
    67a4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67a8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    67ac:	a9530261 	ldp	x1, x0, [x19, #304]
    67b0:	b4000741 	cbz	x1, 6898 <fwp_free_zombie+0x138>
    67b4:	f9009c20 	str	x0, [x1, #312]
    67b8:	b4000040 	cbz	x0, 67c0 <fwp_free_zombie+0x60>
    67bc:	f9009801 	str	x1, [x0, #304]
    67c0:	91014294 	add	x20, x20, #0x50
    67c4:	b9405e60 	ldr	w0, [x19, #92]
    67c8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    67cc:	f900b69f 	str	xzr, [x20, #360]
    67d0:	34000140 	cbz	w0, 67f8 <fwp_free_zombie+0x98>
    67d4:	7100041f 	cmp	w0, #0x1
    67d8:	54000080 	b.eq	67e8 <fwp_free_zombie+0x88>  // b.none
    67dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    67e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67e4:	d65f03c0 	ret
    67e8:	aa1303e0 	mov	x0, x19
    67ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f4:	17ffff9b 	b	6660 <fwp_task_dispose>
    67f8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbc0>
    67fc:	91188082 	add	x2, x4, #0x620
    6800:	f949d841 	ldr	x1, [x2, #5040]
    6804:	f949ec40 	ldr	x0, [x2, #5080]
    6808:	cb010261 	sub	x1, x19, x1
    680c:	eb00403f 	cmp	x1, x0, lsl #16
    6810:	54fffe62 	b.cs	67dc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6814:	d350fc20 	lsr	x0, x1, #16
    6818:	f949fc43 	ldr	x3, [x2, #5112]
    681c:	8b000800 	add	x0, x0, x0, lsl #2
    6820:	d37df000 	lsl	x0, x0, #3
    6824:	8b000062 	add	x2, x3, x0
    6828:	f9401054 	ldr	x20, [x2, #32]
    682c:	b4fffd94 	cbz	x20, 67dc <fwp_free_zombie+0x7c>
    6830:	38606860 	ldrb	w0, [x3, x0]
    6834:	7100081f 	cmp	w0, #0x2
    6838:	54000360 	b.eq	68a4 <fwp_free_zombie+0x144>  // b.none
    683c:	7100041f 	cmp	w0, #0x1
    6840:	54fffce1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    6844:	29430043 	ldp	w3, w0, [x2, #24]
    6848:	92403c21 	and	x1, x1, #0xffff
    684c:	9b037c21 	mul	x1, x1, x3
    6850:	d360fc21 	lsr	x1, x1, #32
    6854:	eb00003f 	cmp	x1, x0
    6858:	54fffc22 	b.cs	67dc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    685c:	8b010294 	add	x20, x20, x1
    6860:	39400280 	ldrb	w0, [x20]
    6864:	34fffbc0 	cbz	w0, 67dc <fwp_free_zombie+0x7c>
    6868:	7100041f 	cmp	w0, #0x1
    686c:	54fffbe0 	b.eq	67e8 <fwp_free_zombie+0x88>  // b.none
    6870:	7103fc1f 	cmp	w0, #0xff
    6874:	540001e0 	b.eq	68b0 <fwp_free_zombie+0x150>  // b.none
    6878:	51000400 	sub	w0, w0, #0x1
    687c:	39000280 	strb	w0, [x20]
    6880:	17ffffd7 	b	67dc <fwp_free_zombie+0x7c>
    6884:	f9400e61 	ldr	x1, [x19, #24]
    6888:	97fff04e 	bl	29c0 <munmap@plt>
    688c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6890:	a9530261 	ldp	x1, x0, [x19, #304]
    6894:	b5fff901 	cbnz	x1, 67b4 <fwp_free_zombie+0x54>
    6898:	91014282 	add	x2, x20, #0x50
    689c:	f901c040 	str	x0, [x2, #896]
    68a0:	17ffffc6 	b	67b8 <fwp_free_zombie+0x58>
    68a4:	72003c3f 	tst	w1, #0xffff
    68a8:	54fff9a1 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    68ac:	17ffffed 	b	6860 <fwp_free_zombie+0x100>
    68b0:	ca544680 	eor	x0, x20, x20, lsr #17
    68b4:	91188084 	add	x4, x4, #0x620
    68b8:	ca402400 	eor	x0, x0, x0, lsr #9
    68bc:	8b200c80 	add	x0, x4, w0, uxtb #3
    68c0:	f94a2400 	ldr	x0, [x0, #5192]
    68c4:	b5000080 	cbnz	x0, 68d4 <fwp_free_zombie+0x174>
    68c8:	14000010 	b	6908 <fwp_free_zombie+0x1a8>
    68cc:	f9400800 	ldr	x0, [x0, #16]
    68d0:	b40001c0 	cbz	x0, 6908 <fwp_free_zombie+0x1a8>
    68d4:	f9400001 	ldr	x1, [x0]
    68d8:	eb14003f 	cmp	x1, x20
    68dc:	54ffff81 	b.ne	68cc <fwp_free_zombie+0x16c>  // b.any
    68e0:	f9400401 	ldr	x1, [x0, #8]
    68e4:	d1000421 	sub	x1, x1, #0x1
    68e8:	f9000401 	str	x1, [x0, #8]
    68ec:	f103f83f 	cmp	x1, #0xfe
    68f0:	54fff761 	b.ne	67dc <fwp_free_zombie+0x7c>  // b.any
    68f4:	aa1403e0 	mov	x0, x20
    68f8:	97fff846 	bl	4a10 <fwp_rc_forget_slot>
    68fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6900:	39000280 	strb	w0, [x20]
    6904:	17ffffb6 	b	67dc <fwp_free_zombie+0x7c>
    6908:	f0000000 	adrp	x0, 9000 <__divti3+0xb0>
    690c:	912cc000 	add	x0, x0, #0xb30
    6910:	97fff3bc 	bl	3800 <fwp_trap>

0000000000006914 <fwp_block>:
    6914:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6918:	910003fd 	mov	x29, sp
    691c:	a90153f3 	stp	x19, x20, [sp, #16]
    6920:	d00000d3 	adrp	x19, 20000 <__data_start>
    6924:	91014274 	add	x20, x19, #0x50
    6928:	f9406682 	ldr	x2, [x20, #200]
    692c:	b4000622 	cbz	x2, 69f0 <fwp_block+0xdc>
    6930:	91014261 	add	x1, x19, #0x50
    6934:	f9408040 	ldr	x0, [x2, #256]
    6938:	f9006420 	str	x0, [x1, #200]
    693c:	b4000680 	cbz	x0, 6a0c <fwp_block+0xf8>
    6940:	91014263 	add	x3, x19, #0x50
    6944:	3901505f 	strb	wzr, [x2, #84]
    6948:	f9404c64 	ldr	x4, [x3, #152]
    694c:	eb02009f 	cmp	x4, x2
    6950:	54000440 	b.eq	69d8 <fwp_block+0xc4>  // b.none
    6954:	f941c465 	ldr	x5, [x3, #904]
    6958:	f9004c62 	str	x2, [x3, #152]
    695c:	f9400441 	ldr	x1, [x2, #8]
    6960:	f9004885 	str	x5, [x4, #144]
    6964:	f941c865 	ldr	x5, [x3, #912]
    6968:	f9004c85 	str	x5, [x4, #152]
    696c:	f941cc65 	ldr	x5, [x3, #920]
    6970:	f9005085 	str	x5, [x4, #160]
    6974:	f941d065 	ldr	x5, [x3, #928]
    6978:	f9005485 	str	x5, [x4, #168]
    697c:	f941d465 	ldr	x5, [x3, #936]
    6980:	f9005885 	str	x5, [x4, #176]
    6984:	f941d865 	ldr	x5, [x3, #944]
    6988:	f9005c85 	str	x5, [x4, #184]
    698c:	f941dc65 	ldr	x5, [x3, #952]
    6990:	f9006085 	str	x5, [x4, #192]
    6994:	f9400480 	ldr	x0, [x4, #8]
    6998:	f9404844 	ldr	x4, [x2, #144]
    699c:	f901c464 	str	x4, [x3, #904]
    69a0:	f9404c44 	ldr	x4, [x2, #152]
    69a4:	f901c864 	str	x4, [x3, #912]
    69a8:	f9405044 	ldr	x4, [x2, #160]
    69ac:	f901cc64 	str	x4, [x3, #920]
    69b0:	f9405444 	ldr	x4, [x2, #168]
    69b4:	f901d064 	str	x4, [x3, #928]
    69b8:	f9405844 	ldr	x4, [x2, #176]
    69bc:	f901d464 	str	x4, [x3, #936]
    69c0:	a94b8844 	ldp	x4, x2, [x2, #184]
    69c4:	f901d864 	str	x4, [x3, #944]
    69c8:	f901dc62 	str	x2, [x3, #952]
    69cc:	97ffefcd 	bl	2900 <swapcontext@plt>
    69d0:	97ffff64 	bl	6760 <fwp_free_zombie>
    69d4:	d503201f 	nop
    69d8:	91014260 	add	x0, x19, #0x50
    69dc:	b943c000 	ldr	w0, [x0, #960]
    69e0:	340001a0 	cbz	w0, 6a14 <fwp_block+0x100>
    69e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    69e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69ec:	d65f03c0 	ret
    69f0:	97fff735 	bl	46c4 <fwp_poll_events>
    69f4:	f9406682 	ldr	x2, [x20, #200]
    69f8:	b4ffffc2 	cbz	x2, 69f0 <fwp_block+0xdc>
    69fc:	91014261 	add	x1, x19, #0x50
    6a00:	f9408040 	ldr	x0, [x2, #256]
    6a04:	f9006420 	str	x0, [x1, #200]
    6a08:	b5fff9c0 	cbnz	x0, 6940 <fwp_block+0x2c>
    6a0c:	f900603f 	str	xzr, [x1, #192]
    6a10:	17ffffcc 	b	6940 <fwp_block+0x2c>
    6a14:	f0000000 	adrp	x0, 9000 <__divti3+0xb0>
    6a18:	91318000 	add	x0, x0, #0xc60
    6a1c:	97fff005 	bl	2a30 <getenv@plt>
    6a20:	5284e202 	mov	w2, #0x2710                	// #10000
    6a24:	b4000060 	cbz	x0, 6a30 <fwp_block+0x11c>
    6a28:	39400001 	ldrb	w1, [x0]
    6a2c:	350000c1 	cbnz	w1, 6a44 <fwp_block+0x130>
    6a30:	91014273 	add	x19, x19, #0x50
    6a34:	b903c262 	str	w2, [x19, #960]
    6a38:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a40:	d65f03c0 	ret
    6a44:	52800142 	mov	w2, #0xa                   	// #10
    6a48:	d2800001 	mov	x1, #0x0                   	// #0
    6a4c:	97ffef49 	bl	2770 <strtoll@plt>
    6a50:	d1000403 	sub	x3, x0, #0x1
    6a54:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6a58:	eb02007f 	cmp	x3, x2
    6a5c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6a60:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6a64:	17fffff3 	b	6a30 <fwp_block+0x11c>
    6a68:	d503201f 	nop
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_drop10>:
    6a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6a74:	910003fd 	mov	x29, sp
    6a78:	a90153f3 	stp	x19, x20, [sp, #16]
    6a7c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    6a80:	f90013f5 	str	x21, [sp, #32]
    6a84:	91188275 	add	x21, x19, #0x620
    6a88:	f949daa1 	ldr	x1, [x21, #5040]
    6a8c:	f949eea2 	ldr	x2, [x21, #5080]
    6a90:	cb010001 	sub	x1, x0, x1
    6a94:	eb02403f 	cmp	x1, x2, lsl #16
    6a98:	54000382 	b.cs	6b08 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a9c:	d350fc22 	lsr	x2, x1, #16
    6aa0:	f949fea3 	ldr	x3, [x21, #5112]
    6aa4:	8b020842 	add	x2, x2, x2, lsl #2
    6aa8:	d37df042 	lsl	x2, x2, #3
    6aac:	8b020064 	add	x4, x3, x2
    6ab0:	f9401094 	ldr	x20, [x4, #32]
    6ab4:	b40002b4 	cbz	x20, 6b08 <fwp_drop10+0x98>
    6ab8:	38626862 	ldrb	w2, [x3, x2]
    6abc:	7100085f 	cmp	w2, #0x2
    6ac0:	540007a0 	b.eq	6bb4 <fwp_drop10+0x144>  // b.none
    6ac4:	7100045f 	cmp	w2, #0x1
    6ac8:	54000201 	b.ne	6b08 <fwp_drop10+0x98>  // b.any
    6acc:	29430885 	ldp	w5, w2, [x4, #24]
    6ad0:	92403c21 	and	x1, x1, #0xffff
    6ad4:	9b057c21 	mul	x1, x1, x5
    6ad8:	d360fc21 	lsr	x1, x1, #32
    6adc:	eb02003f 	cmp	x1, x2
    6ae0:	54000142 	b.cs	6b08 <fwp_drop10+0x98>  // b.hs, b.nlast
    6ae4:	8b010294 	add	x20, x20, x1
    6ae8:	39400281 	ldrb	w1, [x20]
    6aec:	340000e1 	cbz	w1, 6b08 <fwp_drop10+0x98>
    6af0:	7100043f 	cmp	w1, #0x1
    6af4:	54000120 	b.eq	6b18 <fwp_drop10+0xa8>  // b.none
    6af8:	7103fc3f 	cmp	w1, #0xff
    6afc:	540007c0 	b.eq	6bf4 <fwp_drop10+0x184>  // b.none
    6b00:	51000421 	sub	w1, w1, #0x1
    6b04:	39000281 	strb	w1, [x20]
    6b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b0c:	f94013f5 	ldr	x21, [sp, #32]
    6b10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b14:	d65f03c0 	ret
    6b18:	f9400001 	ldr	x1, [x0]
    6b1c:	b7f80581 	tbnz	x1, #63, 6bcc <fwp_drop10+0x15c>
    6b20:	91188273 	add	x19, x19, #0x620
    6b24:	f949da61 	ldr	x1, [x19, #5040]
    6b28:	f949ee62 	ldr	x2, [x19, #5080]
    6b2c:	cb010001 	sub	x1, x0, x1
    6b30:	eb02403f 	cmp	x1, x2, lsl #16
    6b34:	54fffea2 	b.cs	6b08 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b38:	d350fc22 	lsr	x2, x1, #16
    6b3c:	8b020842 	add	x2, x2, x2, lsl #2
    6b40:	d37df042 	lsl	x2, x2, #3
    6b44:	8b020065 	add	x5, x3, x2
    6b48:	f94010a4 	ldr	x4, [x5, #32]
    6b4c:	b4fffde4 	cbz	x4, 6b08 <fwp_drop10+0x98>
    6b50:	38626862 	ldrb	w2, [x3, x2]
    6b54:	7100085f 	cmp	w2, #0x2
    6b58:	54000220 	b.eq	6b9c <fwp_drop10+0x12c>  // b.none
    6b5c:	7100045f 	cmp	w2, #0x1
    6b60:	54fffd41 	b.ne	6b08 <fwp_drop10+0x98>  // b.any
    6b64:	294308a3 	ldp	w3, w2, [x5, #24]
    6b68:	92403c21 	and	x1, x1, #0xffff
    6b6c:	9b037c21 	mul	x1, x1, x3
    6b70:	d360fc21 	lsr	x1, x1, #32
    6b74:	eb02003f 	cmp	x1, x2
    6b78:	54fffc82 	b.cs	6b08 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b7c:	8b010084 	add	x4, x4, x1
    6b80:	39400081 	ldrb	w1, [x4]
    6b84:	7100043f 	cmp	w1, #0x1
    6b88:	54fffc01 	b.ne	6b08 <fwp_drop10+0x98>  // b.any
    6b8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b90:	f94013f5 	ldr	x21, [sp, #32]
    6b94:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b98:	17fff83e 	b	4c90 <fwp_mem_free>
    6b9c:	72003c3f 	tst	w1, #0xffff
    6ba0:	54ffff00 	b.eq	6b80 <fwp_drop10+0x110>  // b.none
    6ba4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ba8:	f94013f5 	ldr	x21, [sp, #32]
    6bac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bb0:	d65f03c0 	ret
    6bb4:	72003c3f 	tst	w1, #0xffff
    6bb8:	54fff980 	b.eq	6ae8 <fwp_drop10+0x78>  // b.none
    6bbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bc0:	f94013f5 	ldr	x21, [sp, #32]
    6bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bc8:	d65f03c0 	ret
    6bcc:	f9400414 	ldr	x20, [x0, #8]
    6bd0:	97fffb51 	bl	5914 <fwp_rc_free_arr>
    6bd4:	91188260 	add	x0, x19, #0x620
    6bd8:	f949d801 	ldr	x1, [x0, #5040]
    6bdc:	f949ec00 	ldr	x0, [x0, #5080]
    6be0:	cb010281 	sub	x1, x20, x1
    6be4:	eb00403f 	cmp	x1, x0, lsl #16
    6be8:	54fff902 	b.cs	6b08 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bec:	aa1403e0 	mov	x0, x20
    6bf0:	17ffffab 	b	6a9c <fwp_drop10+0x2c>
    6bf4:	ca544680 	eor	x0, x20, x20, lsr #17
    6bf8:	91188273 	add	x19, x19, #0x620
    6bfc:	ca402400 	eor	x0, x0, x0, lsr #9
    6c00:	8b200e60 	add	x0, x19, w0, uxtb #3
    6c04:	f94a2400 	ldr	x0, [x0, #5192]
    6c08:	b5000080 	cbnz	x0, 6c18 <fwp_drop10+0x1a8>
    6c0c:	14000010 	b	6c4c <fwp_drop10+0x1dc>
    6c10:	f9400800 	ldr	x0, [x0, #16]
    6c14:	b40001c0 	cbz	x0, 6c4c <fwp_drop10+0x1dc>
    6c18:	f9400001 	ldr	x1, [x0]
    6c1c:	eb14003f 	cmp	x1, x20
    6c20:	54ffff81 	b.ne	6c10 <fwp_drop10+0x1a0>  // b.any
    6c24:	f9400401 	ldr	x1, [x0, #8]
    6c28:	d1000421 	sub	x1, x1, #0x1
    6c2c:	f9000401 	str	x1, [x0, #8]
    6c30:	f103f83f 	cmp	x1, #0xfe
    6c34:	54fff6a1 	b.ne	6b08 <fwp_drop10+0x98>  // b.any
    6c38:	aa1403e0 	mov	x0, x20
    6c3c:	97fff775 	bl	4a10 <fwp_rc_forget_slot>
    6c40:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c44:	39000280 	strb	w0, [x20]
    6c48:	17ffffb0 	b	6b08 <fwp_drop10+0x98>
    6c4c:	f0000000 	adrp	x0, 9000 <__divti3+0xb0>
    6c50:	912cc000 	add	x0, x0, #0xb30
    6c54:	97fff2eb 	bl	3800 <fwp_trap>
    6c58:	d503201f 	nop
    6c5c:	d503201f 	nop

0000000000006c60 <fwp_caps173>:
    6c60:	34000041 	cbz	w1, 6c68 <fwp_caps173+0x8>
    6c64:	d65f03c0 	ret
    6c68:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    6c6c:	91188063 	add	x3, x3, #0x620
    6c70:	f949d861 	ldr	x1, [x3, #5040]
    6c74:	f949ec62 	ldr	x2, [x3, #5080]
    6c78:	cb010001 	sub	x1, x0, x1
    6c7c:	eb02403f 	cmp	x1, x2, lsl #16
    6c80:	54ffff22 	b.cs	6c64 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c84:	d350fc22 	lsr	x2, x1, #16
    6c88:	f949fc65 	ldr	x5, [x3, #5112]
    6c8c:	8b020842 	add	x2, x2, x2, lsl #2
    6c90:	d37df042 	lsl	x2, x2, #3
    6c94:	8b0200a4 	add	x4, x5, x2
    6c98:	f9401083 	ldr	x3, [x4, #32]
    6c9c:	b4fffe43 	cbz	x3, 6c64 <fwp_caps173+0x4>
    6ca0:	386268a2 	ldrb	w2, [x5, x2]
    6ca4:	7100085f 	cmp	w2, #0x2
    6ca8:	540001c0 	b.eq	6ce0 <fwp_caps173+0x80>  // b.none
    6cac:	7100045f 	cmp	w2, #0x1
    6cb0:	54fffda1 	b.ne	6c64 <fwp_caps173+0x4>  // b.any
    6cb4:	29430885 	ldp	w5, w2, [x4, #24]
    6cb8:	92403c21 	and	x1, x1, #0xffff
    6cbc:	9b057c21 	mul	x1, x1, x5
    6cc0:	d360fc21 	lsr	x1, x1, #32
    6cc4:	eb02003f 	cmp	x1, x2
    6cc8:	54fffce2 	b.cs	6c64 <fwp_caps173+0x4>  // b.hs, b.nlast
    6ccc:	8b010063 	add	x3, x3, x1
    6cd0:	39400061 	ldrb	w1, [x3]
    6cd4:	7100043f 	cmp	w1, #0x1
    6cd8:	54fffc61 	b.ne	6c64 <fwp_caps173+0x4>  // b.any
    6cdc:	17fff7ed 	b	4c90 <fwp_mem_free>
    6ce0:	72003c3f 	tst	w1, #0xffff
    6ce4:	54ffff60 	b.eq	6cd0 <fwp_caps173+0x70>  // b.none
    6ce8:	d65f03c0 	ret
    6cec:	d503201f 	nop

0000000000006cf0 <f37>:
    6cf0:	d101c3ff 	sub	sp, sp, #0x70
    6cf4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6cf8:	f947f421 	ldr	x1, [x1, #4072]
    6cfc:	a9027bfd 	stp	x29, x30, [sp, #32]
    6d00:	910083fd 	add	x29, sp, #0x20
    6d04:	a90563f7 	stp	x23, x24, [sp, #80]
    6d08:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xbc0>
    6d0c:	911882e3 	add	x3, x23, #0x620
    6d10:	a90353f3 	stp	x19, x20, [sp, #48]
    6d14:	a9045bf5 	stp	x21, x22, [sp, #64]
    6d18:	aa0003f6 	mov	x22, x0
    6d1c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6d20:	f949ec62 	ldr	x2, [x3, #5080]
    6d24:	f9400024 	ldr	x4, [x1]
    6d28:	f9000fe4 	str	x4, [sp, #24]
    6d2c:	d2800004 	mov	x4, #0x0                   	// #0
    6d30:	f949d861 	ldr	x1, [x3, #5040]
    6d34:	d370bc42 	lsl	x2, x2, #16
    6d38:	b40016c0 	cbz	x0, 7010 <f37+0x320>
    6d3c:	f9400818 	ldr	x24, [x0, #16]
    6d40:	cb010301 	sub	x1, x24, x1
    6d44:	eb02003f 	cmp	x1, x2
    6d48:	540003e2 	b.cs	6dc4 <f37+0xd4>  // b.hs, b.nlast
    6d4c:	f949fc60 	ldr	x0, [x3, #5112]
    6d50:	d350fc22 	lsr	x2, x1, #16
    6d54:	8b020842 	add	x2, x2, x2, lsl #2
    6d58:	8b020c02 	add	x2, x0, x2, lsl #3
    6d5c:	f9401040 	ldr	x0, [x2, #32]
    6d60:	b4000320 	cbz	x0, 6dc4 <f37+0xd4>
    6d64:	39400043 	ldrb	w3, [x2]
    6d68:	7100087f 	cmp	w3, #0x2
    6d6c:	54001440 	b.eq	6ff4 <f37+0x304>  // b.none
    6d70:	7100047f 	cmp	w3, #0x1
    6d74:	54000241 	b.ne	6dbc <f37+0xcc>  // b.any
    6d78:	29430843 	ldp	w3, w2, [x2, #24]
    6d7c:	92403c21 	and	x1, x1, #0xffff
    6d80:	9b037c21 	mul	x1, x1, x3
    6d84:	d360fc21 	lsr	x1, x1, #32
    6d88:	eb02003f 	cmp	x1, x2
    6d8c:	54000182 	b.cs	6dbc <f37+0xcc>  // b.hs, b.nlast
    6d90:	8b010000 	add	x0, x0, x1
    6d94:	39400001 	ldrb	w1, [x0]
    6d98:	34000121 	cbz	w1, 6dbc <f37+0xcc>
    6d9c:	d00000c2 	adrp	x2, 20000 <__data_start>
    6da0:	91014042 	add	x2, x2, #0x50
    6da4:	b9413043 	ldr	w3, [x2, #304]
    6da8:	350012c3 	cbnz	w3, 7000 <f37+0x310>
    6dac:	7103f43f 	cmp	w1, #0xfd
    6db0:	54001728 	b.hi	7094 <f37+0x3a4>  // b.pmore
    6db4:	11000421 	add	w1, w1, #0x1
    6db8:	39000001 	strb	w1, [x0]
    6dbc:	d2800000 	mov	x0, #0x0                   	// #0
    6dc0:	b40000f6 	cbz	x22, 6ddc <f37+0xec>
    6dc4:	aa1603e1 	mov	x1, x22
    6dc8:	d2800000 	mov	x0, #0x0                   	// #0
    6dcc:	d503201f 	nop
    6dd0:	f9400821 	ldr	x1, [x1, #16]
    6dd4:	91000400 	add	x0, x0, #0x1
    6dd8:	b5ffffc1 	cbnz	x1, 6dd0 <f37+0xe0>
    6ddc:	b4001238 	cbz	x24, 7020 <f37+0x330>
    6de0:	aa1803e1 	mov	x1, x24
    6de4:	d2800002 	mov	x2, #0x0                   	// #0
    6de8:	f9400821 	ldr	x1, [x1, #16]
    6dec:	91000442 	add	x2, x2, #0x1
    6df0:	b5ffffc1 	cbnz	x1, 6de8 <f37+0xf8>
    6df4:	eb00005f 	cmp	x2, x0
    6df8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6dfc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6e00:	eb01033f 	cmp	x25, x1
    6e04:	540014e8 	b.hi	70a0 <f37+0x3b0>  // b.pmore
    6e08:	d37ffb33 	lsl	x19, x25, #1
    6e0c:	52800041 	mov	w1, #0x2                   	// #2
    6e10:	91000660 	add	x0, x19, #0x1
    6e14:	d37df000 	lsl	x0, x0, #3
    6e18:	97fff8be 	bl	5110 <fwp_heap_alloc>
    6e1c:	911882e1 	add	x1, x23, #0x620
    6e20:	aa0003fa 	mov	x26, x0
    6e24:	f9000013 	str	x19, [x0]
    6e28:	aa0103e0 	mov	x0, x1
    6e2c:	f949d821 	ldr	x1, [x1, #5040]
    6e30:	f949ec00 	ldr	x0, [x0, #5080]
    6e34:	cb010341 	sub	x1, x26, x1
    6e38:	eb00403f 	cmp	x1, x0, lsl #16
    6e3c:	54000342 	b.cs	6ea4 <f37+0x1b4>  // b.hs, b.nlast
    6e40:	911882e2 	add	x2, x23, #0x620
    6e44:	d350fc20 	lsr	x0, x1, #16
    6e48:	8b000800 	add	x0, x0, x0, lsl #2
    6e4c:	f949fc43 	ldr	x3, [x2, #5112]
    6e50:	d37df002 	lsl	x2, x0, #3
    6e54:	8b020060 	add	x0, x3, x2
    6e58:	f9401013 	ldr	x19, [x0, #32]
    6e5c:	b4000253 	cbz	x19, 6ea4 <f37+0x1b4>
    6e60:	38626862 	ldrb	w2, [x3, x2]
    6e64:	7100085f 	cmp	w2, #0x2
    6e68:	54000c00 	b.eq	6fe8 <f37+0x2f8>  // b.none
    6e6c:	7100045f 	cmp	w2, #0x1
    6e70:	540001a1 	b.ne	6ea4 <f37+0x1b4>  // b.any
    6e74:	29430002 	ldp	w2, w0, [x0, #24]
    6e78:	92403c21 	and	x1, x1, #0xffff
    6e7c:	9b027c21 	mul	x1, x1, x2
    6e80:	d360fc21 	lsr	x1, x1, #32
    6e84:	eb00003f 	cmp	x1, x0
    6e88:	540000e2 	b.cs	6ea4 <f37+0x1b4>  // b.hs, b.nlast
    6e8c:	8b010273 	add	x19, x19, x1
    6e90:	39400260 	ldrb	w0, [x19]
    6e94:	7103fc1f 	cmp	w0, #0xff
    6e98:	54000e80 	b.eq	7068 <f37+0x378>  // b.none
    6e9c:	52800020 	mov	w0, #0x1                   	// #1
    6ea0:	39000260 	strb	w0, [x19]
    6ea4:	b4000259 	cbz	x25, 6eec <f37+0x1fc>
    6ea8:	8b191359 	add	x25, x26, x25, lsl #4
    6eac:	aa1a03f3 	mov	x19, x26
    6eb0:	aa1603f5 	mov	x21, x22
    6eb4:	aa1803f4 	mov	x20, x24
    6eb8:	f9400683 	ldr	x3, [x20, #8]
    6ebc:	f94006a2 	ldr	x2, [x21, #8]
    6ec0:	f9400861 	ldr	x1, [x3, #16]
    6ec4:	f9400840 	ldr	x0, [x2, #16]
    6ec8:	fd400461 	ldr	d1, [x3, #8]
    6ecc:	fd400440 	ldr	d0, [x2, #8]
    6ed0:	97fffa01 	bl	56d4 <w120>
    6ed4:	f9000660 	str	x0, [x19, #8]
    6ed8:	f8010e61 	str	x1, [x19, #16]!
    6edc:	f9400a94 	ldr	x20, [x20, #16]
    6ee0:	f9400ab5 	ldr	x21, [x21, #16]
    6ee4:	eb13033f 	cmp	x25, x19
    6ee8:	54fffe81 	b.ne	6eb8 <f37+0x1c8>  // b.any
    6eec:	aa1803e0 	mov	x0, x24
    6ef0:	97fffd44 	bl	6400 <fwp_drop4>
    6ef4:	aa1603e0 	mov	x0, x22
    6ef8:	97fffd42 	bl	6400 <fwp_drop4>
    6efc:	911882f7 	add	x23, x23, #0x620
    6f00:	aa1a03e0 	mov	x0, x26
    6f04:	97fffa37 	bl	57e0 <w176.constprop.0>
    6f08:	aa0103f3 	mov	x19, x1
    6f0c:	aa0003f4 	mov	x20, x0
    6f10:	aa1a03e0 	mov	x0, x26
    6f14:	97fffed7 	bl	6a70 <fwp_drop10>
    6f18:	a900cff4 	stp	x20, x19, [sp, #8]
    6f1c:	910023e1 	add	x1, sp, #0x8
    6f20:	52800000 	mov	w0, #0x0                   	// #0
    6f24:	97fff8dc 	bl	5294 <fwp_data.part.0.constprop.0>
    6f28:	f949dae1 	ldr	x1, [x23, #5040]
    6f2c:	aa0003f3 	mov	x19, x0
    6f30:	f949eee0 	ldr	x0, [x23, #5080]
    6f34:	cb010261 	sub	x1, x19, x1
    6f38:	eb00403f 	cmp	x1, x0, lsl #16
    6f3c:	54000322 	b.cs	6fa0 <f37+0x2b0>  // b.hs, b.nlast
    6f40:	d350fc22 	lsr	x2, x1, #16
    6f44:	f949fee3 	ldr	x3, [x23, #5112]
    6f48:	8b020842 	add	x2, x2, x2, lsl #2
    6f4c:	d37df042 	lsl	x2, x2, #3
    6f50:	8b020060 	add	x0, x3, x2
    6f54:	f9401014 	ldr	x20, [x0, #32]
    6f58:	b4000254 	cbz	x20, 6fa0 <f37+0x2b0>
    6f5c:	38626862 	ldrb	w2, [x3, x2]
    6f60:	7100085f 	cmp	w2, #0x2
    6f64:	540003c0 	b.eq	6fdc <f37+0x2ec>  // b.none
    6f68:	7100045f 	cmp	w2, #0x1
    6f6c:	540001a1 	b.ne	6fa0 <f37+0x2b0>  // b.any
    6f70:	29430002 	ldp	w2, w0, [x0, #24]
    6f74:	92403c21 	and	x1, x1, #0xffff
    6f78:	9b027c21 	mul	x1, x1, x2
    6f7c:	d360fc21 	lsr	x1, x1, #32
    6f80:	eb00003f 	cmp	x1, x0
    6f84:	540000e2 	b.cs	6fa0 <f37+0x2b0>  // b.hs, b.nlast
    6f88:	8b010294 	add	x20, x20, x1
    6f8c:	39400280 	ldrb	w0, [x20]
    6f90:	7103fc1f 	cmp	w0, #0xff
    6f94:	54000640 	b.eq	705c <f37+0x36c>  // b.none
    6f98:	52800020 	mov	w0, #0x1                   	// #1
    6f9c:	39000280 	strb	w0, [x20]
    6fa0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6fa4:	f947f400 	ldr	x0, [x0, #4072]
    6fa8:	f9400fe2 	ldr	x2, [sp, #24]
    6fac:	f9400001 	ldr	x1, [x0]
    6fb0:	eb010042 	subs	x2, x2, x1
    6fb4:	d2800001 	mov	x1, #0x0                   	// #0
    6fb8:	54000721 	b.ne	709c <f37+0x3ac>  // b.any
    6fbc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6fc0:	aa1303e0 	mov	x0, x19
    6fc4:	a94353f3 	ldp	x19, x20, [sp, #48]
    6fc8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6fcc:	a94563f7 	ldp	x23, x24, [sp, #80]
    6fd0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6fd4:	9101c3ff 	add	sp, sp, #0x70
    6fd8:	d65f03c0 	ret
    6fdc:	72003c3f 	tst	w1, #0xffff
    6fe0:	54fffe01 	b.ne	6fa0 <f37+0x2b0>  // b.any
    6fe4:	17ffffea 	b	6f8c <f37+0x29c>
    6fe8:	72003c3f 	tst	w1, #0xffff
    6fec:	54fff5c1 	b.ne	6ea4 <f37+0x1b4>  // b.any
    6ff0:	17ffffa8 	b	6e90 <f37+0x1a0>
    6ff4:	72003c3f 	tst	w1, #0xffff
    6ff8:	54ffee21 	b.ne	6dbc <f37+0xcc>  // b.any
    6ffc:	17ffff66 	b	6d94 <f37+0xa4>
    7000:	f940ac43 	ldr	x3, [x2, #344]
    7004:	91000463 	add	x3, x3, #0x1
    7008:	f900ac43 	str	x3, [x2, #344]
    700c:	17ffff68 	b	6dac <f37+0xbc>
    7010:	cb0103e1 	neg	x1, x1
    7014:	eb02003f 	cmp	x1, x2
    7018:	540002e3 	b.cc	7074 <f37+0x384>  // b.lo, b.ul, b.last
    701c:	d503201f 	nop
    7020:	52800041 	mov	w1, #0x2                   	// #2
    7024:	d2800100 	mov	x0, #0x8                   	// #8
    7028:	97fff83a 	bl	5110 <fwp_heap_alloc>
    702c:	aa0003e1 	mov	x1, x0
    7030:	911882e0 	add	x0, x23, #0x620
    7034:	aa0103fa 	mov	x26, x1
    7038:	d2800018 	mov	x24, #0x0                   	// #0
    703c:	f900003f 	str	xzr, [x1]
    7040:	f949d801 	ldr	x1, [x0, #5040]
    7044:	f949ec00 	ldr	x0, [x0, #5080]
    7048:	cb010341 	sub	x1, x26, x1
    704c:	eb00403f 	cmp	x1, x0, lsl #16
    7050:	54fff4e2 	b.cs	6eec <f37+0x1fc>  // b.hs, b.nlast
    7054:	d2800019 	mov	x25, #0x0                   	// #0
    7058:	17ffff7a 	b	6e40 <f37+0x150>
    705c:	aa1403e0 	mov	x0, x20
    7060:	97fff66c 	bl	4a10 <fwp_rc_forget_slot>
    7064:	17ffffcd 	b	6f98 <f37+0x2a8>
    7068:	aa1303e0 	mov	x0, x19
    706c:	97fff669 	bl	4a10 <fwp_rc_forget_slot>
    7070:	17ffff8b 	b	6e9c <f37+0x1ac>
    7074:	f949fc62 	ldr	x2, [x3, #5112]
    7078:	d350fc20 	lsr	x0, x1, #16
    707c:	8b000800 	add	x0, x0, x0, lsl #2
    7080:	8b000c42 	add	x2, x2, x0, lsl #3
    7084:	f9401040 	ldr	x0, [x2, #32]
    7088:	b4fffcc0 	cbz	x0, 7020 <f37+0x330>
    708c:	d2800018 	mov	x24, #0x0                   	// #0
    7090:	17ffff35 	b	6d64 <f37+0x74>
    7094:	97fff618 	bl	48f4 <fwp_rc_wide_dup>
    7098:	17ffff49 	b	6dbc <f37+0xcc>
    709c:	97ffee01 	bl	28a0 <__stack_chk_fail@plt>
    70a0:	d0000000 	adrp	x0, 9000 <__divti3+0xb0>
    70a4:	9131c000 	add	x0, x0, #0xc70
    70a8:	97fff1d6 	bl	3800 <fwp_trap>
    70ac:	d503201f 	nop

00000000000070b0 <fwp_owned_entry37>:
    70b0:	f9400000 	ldr	x0, [x0]
    70b4:	17ffff0f 	b	6cf0 <f37>
    70b8:	d503201f 	nop
    70bc:	d503201f 	nop

00000000000070c0 <e37>:
    70c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    70c4:	910003fd 	mov	x29, sp
    70c8:	f9000bf3 	str	x19, [sp, #16]
    70cc:	f9400013 	ldr	x19, [x0]
    70d0:	aa1303e0 	mov	x0, x19
    70d4:	97fff9eb 	bl	5880 <fwp_rc_share>
    70d8:	aa1303e0 	mov	x0, x19
    70dc:	97ffff05 	bl	6cf0 <f37>
    70e0:	aa0003f3 	mov	x19, x0
    70e4:	97fff9e7 	bl	5880 <fwp_rc_share>
    70e8:	aa1303e0 	mov	x0, x19
    70ec:	f9400bf3 	ldr	x19, [sp, #16]
    70f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70f4:	d65f03c0 	ret
    70f8:	d503201f 	nop
    70fc:	d503201f 	nop

0000000000007100 <fwp_args37>:
    7100:	7100003f 	cmp	w1, #0x0
    7104:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7108:	54000041 	b.ne	7110 <fwp_args37+0x10>  // b.any
    710c:	d65f03c0 	ret
    7110:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    7114:	91188042 	add	x2, x2, #0x620
    7118:	f9400001 	ldr	x1, [x0]
    711c:	f949d843 	ldr	x3, [x2, #5040]
    7120:	f949ec40 	ldr	x0, [x2, #5080]
    7124:	cb030021 	sub	x1, x1, x3
    7128:	eb00403f 	cmp	x1, x0, lsl #16
    712c:	54ffff02 	b.cs	710c <fwp_args37+0xc>  // b.hs, b.nlast
    7130:	d350fc20 	lsr	x0, x1, #16
    7134:	f949fc44 	ldr	x4, [x2, #5112]
    7138:	8b000800 	add	x0, x0, x0, lsl #2
    713c:	d37df002 	lsl	x2, x0, #3
    7140:	8b020083 	add	x3, x4, x2
    7144:	f9401060 	ldr	x0, [x3, #32]
    7148:	b4fffe20 	cbz	x0, 710c <fwp_args37+0xc>
    714c:	38626882 	ldrb	w2, [x4, x2]
    7150:	7100085f 	cmp	w2, #0x2
    7154:	54000320 	b.eq	71b8 <fwp_args37+0xb8>  // b.none
    7158:	7100045f 	cmp	w2, #0x1
    715c:	54fffd81 	b.ne	710c <fwp_args37+0xc>  // b.any
    7160:	29430864 	ldp	w4, w2, [x3, #24]
    7164:	92403c21 	and	x1, x1, #0xffff
    7168:	9b047c21 	mul	x1, x1, x4
    716c:	d360fc21 	lsr	x1, x1, #32
    7170:	eb02003f 	cmp	x1, x2
    7174:	54fffcc2 	b.cs	710c <fwp_args37+0xc>  // b.hs, b.nlast
    7178:	8b010000 	add	x0, x0, x1
    717c:	39400001 	ldrb	w1, [x0]
    7180:	34fffc61 	cbz	w1, 710c <fwp_args37+0xc>
    7184:	b00000c2 	adrp	x2, 20000 <__data_start>
    7188:	91014042 	add	x2, x2, #0x50
    718c:	b9413043 	ldr	w3, [x2, #304]
    7190:	350000c3 	cbnz	w3, 71a8 <fwp_args37+0xa8>
    7194:	7103f43f 	cmp	w1, #0xfd
    7198:	54000168 	b.hi	71c4 <fwp_args37+0xc4>  // b.pmore
    719c:	11000421 	add	w1, w1, #0x1
    71a0:	39000001 	strb	w1, [x0]
    71a4:	d65f03c0 	ret
    71a8:	f940ac43 	ldr	x3, [x2, #344]
    71ac:	91000463 	add	x3, x3, #0x1
    71b0:	f900ac43 	str	x3, [x2, #344]
    71b4:	17fffff8 	b	7194 <fwp_args37+0x94>
    71b8:	72003c3f 	tst	w1, #0xffff
    71bc:	54fffe00 	b.eq	717c <fwp_args37+0x7c>  // b.none
    71c0:	d65f03c0 	ret
    71c4:	17fff5cc 	b	48f4 <fwp_rc_wide_dup>
    71c8:	d503201f 	nop
    71cc:	d503201f 	nop

00000000000071d0 <fwp_caps37>:
    71d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    71d4:	910003fd 	mov	x29, sp
    71d8:	f9000bf3 	str	x19, [sp, #16]
    71dc:	aa0003f3 	mov	x19, x0
    71e0:	b9400400 	ldr	w0, [x0, #4]
    71e4:	340004a0 	cbz	w0, 7278 <fwp_caps37+0xa8>
    71e8:	f9400660 	ldr	x0, [x19, #8]
    71ec:	350004e1 	cbnz	w1, 7288 <fwp_caps37+0xb8>
    71f0:	97fffc84 	bl	6400 <fwp_drop4>
    71f4:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    71f8:	91188042 	add	x2, x2, #0x620
    71fc:	f949d840 	ldr	x0, [x2, #5040]
    7200:	f949ec41 	ldr	x1, [x2, #5080]
    7204:	cb000260 	sub	x0, x19, x0
    7208:	eb01401f 	cmp	x0, x1, lsl #16
    720c:	54000382 	b.cs	727c <fwp_caps37+0xac>  // b.hs, b.nlast
    7210:	d350fc01 	lsr	x1, x0, #16
    7214:	f949fc44 	ldr	x4, [x2, #5112]
    7218:	8b010821 	add	x1, x1, x1, lsl #2
    721c:	d37df021 	lsl	x1, x1, #3
    7220:	8b010083 	add	x3, x4, x1
    7224:	f9401062 	ldr	x2, [x3, #32]
    7228:	b40002a2 	cbz	x2, 727c <fwp_caps37+0xac>
    722c:	38616881 	ldrb	w1, [x4, x1]
    7230:	7100083f 	cmp	w1, #0x2
    7234:	54000740 	b.eq	731c <fwp_caps37+0x14c>  // b.none
    7238:	7100043f 	cmp	w1, #0x1
    723c:	54000201 	b.ne	727c <fwp_caps37+0xac>  // b.any
    7240:	29430464 	ldp	w4, w1, [x3, #24]
    7244:	92403c00 	and	x0, x0, #0xffff
    7248:	9b047c00 	mul	x0, x0, x4
    724c:	d360fc00 	lsr	x0, x0, #32
    7250:	eb01001f 	cmp	x0, x1
    7254:	54000142 	b.cs	727c <fwp_caps37+0xac>  // b.hs, b.nlast
    7258:	8b000042 	add	x2, x2, x0
    725c:	39400040 	ldrb	w0, [x2]
    7260:	7100041f 	cmp	w0, #0x1
    7264:	540000c1 	b.ne	727c <fwp_caps37+0xac>  // b.any
    7268:	aa1303e0 	mov	x0, x19
    726c:	f9400bf3 	ldr	x19, [sp, #16]
    7270:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7274:	17fff687 	b	4c90 <fwp_mem_free>
    7278:	34fffbe1 	cbz	w1, 71f4 <fwp_caps37+0x24>
    727c:	f9400bf3 	ldr	x19, [sp, #16]
    7280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7284:	d65f03c0 	ret
    7288:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    728c:	91188042 	add	x2, x2, #0x620
    7290:	f949d843 	ldr	x3, [x2, #5040]
    7294:	f949ec41 	ldr	x1, [x2, #5080]
    7298:	cb030000 	sub	x0, x0, x3
    729c:	eb01401f 	cmp	x0, x1, lsl #16
    72a0:	54fffee2 	b.cs	727c <fwp_caps37+0xac>  // b.hs, b.nlast
    72a4:	d350fc01 	lsr	x1, x0, #16
    72a8:	f949fc44 	ldr	x4, [x2, #5112]
    72ac:	8b010821 	add	x1, x1, x1, lsl #2
    72b0:	d37df021 	lsl	x1, x1, #3
    72b4:	8b010083 	add	x3, x4, x1
    72b8:	f9401062 	ldr	x2, [x3, #32]
    72bc:	b4fffe02 	cbz	x2, 727c <fwp_caps37+0xac>
    72c0:	38616881 	ldrb	w1, [x4, x1]
    72c4:	7100083f 	cmp	w1, #0x2
    72c8:	54000300 	b.eq	7328 <fwp_caps37+0x158>  // b.none
    72cc:	7100043f 	cmp	w1, #0x1
    72d0:	54fffd61 	b.ne	727c <fwp_caps37+0xac>  // b.any
    72d4:	92403c01 	and	x1, x0, #0xffff
    72d8:	29430064 	ldp	w4, w0, [x3, #24]
    72dc:	9b047c21 	mul	x1, x1, x4
    72e0:	d360fc21 	lsr	x1, x1, #32
    72e4:	eb00003f 	cmp	x1, x0
    72e8:	54fffca2 	b.cs	727c <fwp_caps37+0xac>  // b.hs, b.nlast
    72ec:	8b010042 	add	x2, x2, x1
    72f0:	39400040 	ldrb	w0, [x2]
    72f4:	34fffc40 	cbz	w0, 727c <fwp_caps37+0xac>
    72f8:	b00000c1 	adrp	x1, 20000 <__data_start>
    72fc:	91014021 	add	x1, x1, #0x50
    7300:	b9413023 	ldr	w3, [x1, #304]
    7304:	35000183 	cbnz	w3, 7334 <fwp_caps37+0x164>
    7308:	7103f41f 	cmp	w0, #0xfd
    730c:	540001c8 	b.hi	7344 <fwp_caps37+0x174>  // b.pmore
    7310:	11000400 	add	w0, w0, #0x1
    7314:	39000040 	strb	w0, [x2]
    7318:	17ffffd9 	b	727c <fwp_caps37+0xac>
    731c:	72003c1f 	tst	w0, #0xffff
    7320:	54fffae1 	b.ne	727c <fwp_caps37+0xac>  // b.any
    7324:	17ffffce 	b	725c <fwp_caps37+0x8c>
    7328:	72003c1f 	tst	w0, #0xffff
    732c:	54fffa81 	b.ne	727c <fwp_caps37+0xac>  // b.any
    7330:	17fffff0 	b	72f0 <fwp_caps37+0x120>
    7334:	f940ac23 	ldr	x3, [x1, #344]
    7338:	91000463 	add	x3, x3, #0x1
    733c:	f900ac23 	str	x3, [x1, #344]
    7340:	17fffff2 	b	7308 <fwp_caps37+0x138>
    7344:	f9400bf3 	ldr	x19, [sp, #16]
    7348:	aa0203e0 	mov	x0, x2
    734c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7350:	17fff569 	b	48f4 <fwp_rc_wide_dup>

0000000000007354 <fwp_write>:
    7354:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7358:	910003fd 	mov	x29, sp
    735c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    7360:	f947f484 	ldr	x4, [x4, #4072]
    7364:	a90153f3 	stp	x19, x20, [sp, #16]
    7368:	d10943ff 	sub	sp, sp, #0x250
    736c:	b9400045 	ldr	w5, [x2]
    7370:	aa0003f4 	mov	x20, x0
    7374:	f9400080 	ldr	x0, [x4]
    7378:	f90127e0 	str	x0, [sp, #584]
    737c:	d2800000 	mov	x0, #0x0                   	// #0
    7380:	710064bf 	cmp	w5, #0x19
    7384:	54000408 	b.hi	7404 <fwp_write+0xb0>  // b.pmore
    7388:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x990>
    738c:	aa0103f3 	mov	x19, x1
    7390:	91138000 	add	x0, x0, #0x4e0
    7394:	f9013bf5 	str	x21, [sp, #624]
    7398:	f9013ff6 	str	x22, [sp, #632]
    739c:	f90153fb 	str	x27, [sp, #672]
    73a0:	f90157fc 	str	x28, [sp, #680]
    73a4:	aa0203fc 	mov	x28, x2
    73a8:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    73ac:	10000061 	adr	x1, 73b8 <fwp_write+0x64>
    73b0:	8b20a820 	add	x0, x1, w0, sxth #2
    73b4:	d61f0000 	br	x0
    73b8:	910123e0 	add	x0, sp, #0x48
    73bc:	aa1303e5 	mov	x5, x19
    73c0:	d0000004 	adrp	x4, 9000 <__divti3+0xb0>
    73c4:	aa0003f3 	mov	x19, x0
    73c8:	9132e084 	add	x4, x4, #0xcb8
    73cc:	d2804003 	mov	x3, #0x200                 	// #512
    73d0:	aa0303e1 	mov	x1, x3
    73d4:	52800042 	mov	w2, #0x2                   	// #2
    73d8:	97ffed0e 	bl	2810 <__snprintf_chk@plt>
    73dc:	aa1303e0 	mov	x0, x19
    73e0:	97ffecd4 	bl	2730 <strlen@plt>
    73e4:	aa1303e1 	mov	x1, x19
    73e8:	aa0003e2 	mov	x2, x0
    73ec:	aa1403e0 	mov	x0, x20
    73f0:	97fff0a8 	bl	3690 <buf_put>
    73f4:	f9413bf5 	ldr	x21, [sp, #624]
    73f8:	f9413ff6 	ldr	x22, [sp, #632]
    73fc:	f94153fb 	ldr	x27, [sp, #672]
    7400:	f94157fc 	ldr	x28, [sp, #680]
    7404:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7408:	f947f400 	ldr	x0, [x0, #4072]
    740c:	f94127e2 	ldr	x2, [sp, #584]
    7410:	f9400001 	ldr	x1, [x0]
    7414:	eb010042 	subs	x2, x2, x1
    7418:	d2800001 	mov	x1, #0x0                   	// #0
    741c:	540077a1 	b.ne	8310 <fwp_write+0xfbc>  // b.any
    7420:	910943ff 	add	sp, sp, #0x250
    7424:	a94153f3 	ldp	x19, x20, [sp, #16]
    7428:	a8c77bfd 	ldp	x29, x30, [sp], #112
    742c:	d65f03c0 	ret
    7430:	910123e0 	add	x0, sp, #0x48
    7434:	aa1303e5 	mov	x5, x19
    7438:	d0000004 	adrp	x4, 9000 <__divti3+0xb0>
    743c:	aa0003f3 	mov	x19, x0
    7440:	9132c084 	add	x4, x4, #0xcb0
    7444:	d2804003 	mov	x3, #0x200                 	// #512
    7448:	17ffffe2 	b	73d0 <fwp_write+0x7c>
    744c:	71004cbf 	cmp	w5, #0x13
    7450:	d0000000 	adrp	x0, 9000 <__divti3+0xb0>
    7454:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7458:	91328000 	add	x0, x0, #0xca0
    745c:	9132a021 	add	x1, x1, #0xca8
    7460:	d2800082 	mov	x2, #0x4                   	// #4
    7464:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7468:	aa1403e0 	mov	x0, x20
    746c:	f90143f7 	str	x23, [sp, #640]
    7470:	d2800016 	mov	x22, #0x0                   	// #0
    7474:	f90147f8 	str	x24, [sp, #648]
    7478:	97fff086 	bl	3690 <buf_put>
    747c:	f9400260 	ldr	x0, [x19]
    7480:	d0000017 	adrp	x23, 9000 <__divti3+0xb0>
    7484:	d2800015 	mov	x21, #0x0                   	// #0
    7488:	9134a2f7 	add	x23, x23, #0xd28
    748c:	b4004780 	cbz	x0, 7d7c <fwp_write+0xa28>
    7490:	b9400380 	ldr	w0, [x28]
    7494:	52800003 	mov	w3, #0x0                   	// #0
    7498:	f9401f82 	ldr	x2, [x28, #56]
    749c:	71004c1f 	cmp	w0, #0x13
    74a0:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    74a4:	aa1403e0 	mov	x0, x20
    74a8:	8b010e61 	add	x1, x19, x1, lsl #3
    74ac:	f9400421 	ldr	x1, [x1, #8]
    74b0:	97ffffa9 	bl	7354 <fwp_write>
    74b4:	b9400380 	ldr	w0, [x28]
    74b8:	7100481f 	cmp	w0, #0x12
    74bc:	54004b20 	b.eq	7e20 <fwp_write+0xacc>  // b.none
    74c0:	f9400260 	ldr	x0, [x19]
    74c4:	910006b5 	add	x21, x21, #0x1
    74c8:	91000ad6 	add	x22, x22, #0x2
    74cc:	eb15001f 	cmp	x0, x21
    74d0:	54004569 	b.ls	7d7c <fwp_write+0xa28>  // b.plast
    74d4:	aa1703e1 	mov	x1, x23
    74d8:	aa1403e0 	mov	x0, x20
    74dc:	d2800042 	mov	x2, #0x2                   	// #2
    74e0:	97fff06c 	bl	3690 <buf_put>
    74e4:	17ffffeb 	b	7490 <fwp_write+0x13c>
    74e8:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    74ec:	91338021 	add	x1, x1, #0xce0
    74f0:	d28000c2 	mov	x2, #0x6                   	// #6
    74f4:	aa1403e0 	mov	x0, x20
    74f8:	91004273 	add	x19, x19, #0x10
    74fc:	97fff065 	bl	3690 <buf_put>
    7500:	aa1303e0 	mov	x0, x19
    7504:	97ffec8b 	bl	2730 <strlen@plt>
    7508:	aa1303e1 	mov	x1, x19
    750c:	aa0003e2 	mov	x2, x0
    7510:	aa1403e0 	mov	x0, x20
    7514:	97fff05f 	bl	3690 <buf_put>
    7518:	528007c3 	mov	w3, #0x3e                  	// #62
    751c:	aa1403e0 	mov	x0, x20
    7520:	91001fe1 	add	x1, sp, #0x7
    7524:	d2800022 	mov	x2, #0x1                   	// #1
    7528:	39001fe3 	strb	w3, [sp, #7]
    752c:	17ffffb1 	b	73f0 <fwp_write+0x9c>
    7530:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7534:	f947f400 	ldr	x0, [x0, #4072]
    7538:	f94127e2 	ldr	x2, [sp, #584]
    753c:	f9400001 	ldr	x1, [x0]
    7540:	eb010042 	subs	x2, x2, x1
    7544:	d2800001 	mov	x1, #0x0                   	// #0
    7548:	540034c1 	b.ne	7be0 <fwp_write+0x88c>  // b.any
    754c:	f9413bf5 	ldr	x21, [sp, #624]
    7550:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7554:	f9413ff6 	ldr	x22, [sp, #632]
    7558:	aa1403e0 	mov	x0, x20
    755c:	91330021 	add	x1, x1, #0xcc0
    7560:	d2800142 	mov	x2, #0xa                   	// #10
    7564:	f94153fb 	ldr	x27, [sp, #672]
    7568:	f94157fc 	ldr	x28, [sp, #680]
    756c:	910943ff 	add	sp, sp, #0x250
    7570:	a94153f3 	ldp	x19, x20, [sp, #16]
    7574:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7578:	17fff046 	b	3690 <buf_put>
    757c:	f9400456 	ldr	x22, [x2, #8]
    7580:	f90143f7 	str	x23, [sp, #640]
    7584:	f90147f8 	str	x24, [sp, #648]
    7588:	b4005af6 	cbz	x22, 80e4 <fwp_write+0xd90>
    758c:	aa1603e0 	mov	x0, x22
    7590:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7594:	91350021 	add	x1, x1, #0xd40
    7598:	97ffece2 	bl	2920 <strcmp@plt>
    759c:	2a0003f5 	mov	w21, w0
    75a0:	34005fc0 	cbz	w0, 8198 <fwp_write+0xe44>
    75a4:	aa1603e0 	mov	x0, x22
    75a8:	97ffec62 	bl	2730 <strlen@plt>
    75ac:	aa1603e1 	mov	x1, x22
    75b0:	aa0003e2 	mov	x2, x0
    75b4:	aa1403e0 	mov	x0, x20
    75b8:	97fff036 	bl	3690 <buf_put>
    75bc:	52800403 	mov	w3, #0x20                  	// #32
    75c0:	91001ff5 	add	x21, sp, #0x7
    75c4:	aa1503e1 	mov	x1, x21
    75c8:	aa1403e0 	mov	x0, x20
    75cc:	d2800022 	mov	x2, #0x1                   	// #1
    75d0:	39001fe3 	strb	w3, [sp, #7]
    75d4:	97fff02f 	bl	3690 <buf_put>
    75d8:	52800f63 	mov	w3, #0x7b                  	// #123
    75dc:	aa1403e0 	mov	x0, x20
    75e0:	aa1503e1 	mov	x1, x21
    75e4:	d2800022 	mov	x2, #0x1                   	// #1
    75e8:	39001fe3 	strb	w3, [sp, #7]
    75ec:	97fff029 	bl	3690 <buf_put>
    75f0:	b9401380 	ldr	w0, [x28, #16]
    75f4:	52800018 	mov	w24, #0x0                   	// #0
    75f8:	7100001f 	cmp	w0, #0x0
    75fc:	54003a8d 	b.le	7d4c <fwp_write+0x9f8>
    7600:	f9014bf9 	str	x25, [sp, #656]
    7604:	d0000019 	adrp	x25, 9000 <__divti3+0xb0>
    7608:	9135a339 	add	x25, x25, #0xd68
    760c:	f9014ffa 	str	x26, [sp, #664]
    7610:	d000001a 	adrp	x26, 9000 <__divti3+0xb0>
    7614:	9134a35a 	add	x26, x26, #0xd28
    7618:	91002276 	add	x22, x19, #0x8
    761c:	d2800013 	mov	x19, #0x0                   	// #0
    7620:	b5003e73 	cbnz	x19, 7dec <fwp_write+0xa98>
    7624:	d37df277 	lsl	x23, x19, #3
    7628:	34003c98 	cbz	w24, 7db8 <fwp_write+0xa64>
    762c:	f9401382 	ldr	x2, [x28, #32]
    7630:	aa1403e0 	mov	x0, x20
    7634:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7638:	52800003 	mov	w3, #0x0                   	// #0
    763c:	f8776842 	ldr	x2, [x2, x23]
    7640:	91000673 	add	x19, x19, #0x1
    7644:	97ffff44 	bl	7354 <fwp_write>
    7648:	b9401380 	ldr	w0, [x28, #16]
    764c:	6b13001f 	cmp	w0, w19
    7650:	54fffe8c 	b.gt	7620 <fwp_write+0x2cc>
    7654:	f9414bf9 	ldr	x25, [sp, #656]
    7658:	f9414ffa 	ldr	x26, [sp, #664]
    765c:	34003798 	cbz	w24, 7d4c <fwp_write+0x9f8>
    7660:	52800523 	mov	w3, #0x29                  	// #41
    7664:	aa1503e1 	mov	x1, x21
    7668:	aa1403e0 	mov	x0, x20
    766c:	d2800022 	mov	x2, #0x1                   	// #1
    7670:	39001fe3 	strb	w3, [sp, #7]
    7674:	97fff007 	bl	3690 <buf_put>
    7678:	f9413bf5 	ldr	x21, [sp, #624]
    767c:	f9413ff6 	ldr	x22, [sp, #632]
    7680:	f94143f7 	ldr	x23, [sp, #640]
    7684:	f94147f8 	ldr	x24, [sp, #648]
    7688:	f94153fb 	ldr	x27, [sp, #672]
    768c:	f94157fc 	ldr	x28, [sp, #680]
    7690:	17ffff5d 	b	7404 <fwp_write+0xb0>
    7694:	b9404855 	ldr	w21, [x2, #72]
    7698:	aa1403e0 	mov	x0, x20
    769c:	93407eb6 	sxtw	x22, w21
    76a0:	91000ac1 	add	x1, x22, #0x2
    76a4:	97ffefc7 	bl	35c0 <buf_grow>
    76a8:	a9400281 	ldp	x1, x0, [x20]
    76ac:	528e8603 	mov	w3, #0x7430                	// #29744
    76b0:	78206823 	strh	w3, [x1, x0]
    76b4:	8b000022 	add	x2, x1, x0
    76b8:	710002bf 	cmp	w21, #0x0
    76bc:	540036ad 	b.le	7d90 <fwp_write+0xa3c>
    76c0:	110006a3 	add	w3, w21, #0x1
    76c4:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    76c8:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    76cc:	91000449 	add	x9, x2, #0x1
    76d0:	8b23c043 	add	x3, x2, w3, sxtw
    76d4:	f28aaac6 	movk	x6, #0x5556
    76d8:	f2955568 	movk	x8, #0xaaab
    76dc:	1400000d 	b	7710 <fwp_write+0x3bc>
    76e0:	d2800021 	mov	x1, #0x1                   	// #1
    76e4:	528005a5 	mov	w5, #0x2d                  	// #45
    76e8:	f100001f 	cmp	x0, #0x0
    76ec:	9b467e60 	smulh	x0, x19, x6
    76f0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    76f4:	381ff465 	strb	w5, [x3], #-1
    76f8:	cb040000 	sub	x0, x0, x4
    76fc:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7700:	cb020000 	sub	x0, x0, x2
    7704:	8b010013 	add	x19, x0, x1
    7708:	eb03013f 	cmp	x9, x3
    770c:	54003420 	b.eq	7d90 <fwp_write+0xa3c>  // b.none
    7710:	9b467e60 	smulh	x0, x19, x6
    7714:	937ffe64 	asr	x4, x19, #63
    7718:	52800605 	mov	w5, #0x30                  	// #48
    771c:	cb040000 	sub	x0, x0, x4
    7720:	8b000400 	add	x0, x0, x0, lsl #1
    7724:	cb000260 	sub	x0, x19, x0
    7728:	91000c01 	add	x1, x0, #0x3
    772c:	9bc87c22 	umulh	x2, x1, x8
    7730:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7734:	8b4204e2 	add	x2, x7, x2, lsr #1
    7738:	eb020021 	subs	x1, x1, x2
    773c:	54fffd60 	b.eq	76e8 <fwp_write+0x394>  // b.none
    7740:	f100043f 	cmp	x1, #0x1
    7744:	54fffce1 	b.ne	76e0 <fwp_write+0x38c>  // b.any
    7748:	d2800001 	mov	x1, #0x0                   	// #0
    774c:	52800565 	mov	w5, #0x2b                  	// #43
    7750:	17ffffe6 	b	76e8 <fwp_write+0x394>
    7754:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7758:	f947f400 	ldr	x0, [x0, #4072]
    775c:	f94127e2 	ldr	x2, [sp, #584]
    7760:	f9400001 	ldr	x1, [x0]
    7764:	eb010042 	subs	x2, x2, x1
    7768:	d2800001 	mov	x1, #0x0                   	// #0
    776c:	540023a1 	b.ne	7be0 <fwp_write+0x88c>  // b.any
    7770:	f9413bf5 	ldr	x21, [sp, #624]
    7774:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7778:	f9413ff6 	ldr	x22, [sp, #632]
    777c:	aa1403e0 	mov	x0, x20
    7780:	91334021 	add	x1, x1, #0xcd0
    7784:	d2800102 	mov	x2, #0x8                   	// #8
    7788:	17ffff77 	b	7564 <fwp_write+0x210>
    778c:	aa1403e0 	mov	x0, x20
    7790:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7794:	d28000c2 	mov	x2, #0x6                   	// #6
    7798:	9134c021 	add	x1, x1, #0xd30
    779c:	97ffefbd 	bl	3690 <buf_put>
    77a0:	d2800015 	mov	x21, #0x0                   	// #0
    77a4:	f9400263 	ldr	x3, [x19]
    77a8:	f240f87f 	tst	x3, #0x7fffffffffffffff
    77ac:	54002c40 	b.eq	7d34 <fwp_write+0x9e0>  // b.none
    77b0:	f9401f82 	ldr	x2, [x28, #56]
    77b4:	f90143f7 	str	x23, [sp, #640]
    77b8:	f90147f8 	str	x24, [sp, #648]
    77bc:	d2800857 	mov	x23, #0x42                  	// #66
    77c0:	f9014bf9 	str	x25, [sp, #656]
    77c4:	d0000016 	adrp	x22, 9000 <__divti3+0xb0>
    77c8:	f9014ffa 	str	x26, [sp, #664]
    77cc:	9134a2d6 	add	x22, x22, #0xd28
    77d0:	d2800038 	mov	x24, #0x1                   	// #1
    77d4:	f2a18017 	movk	x23, #0xc00, lsl #16
    77d8:	d2809099 	mov	x25, #0x484                 	// #1156
    77dc:	b4000482 	cbz	x2, 786c <fwp_write+0x518>
    77e0:	b9400040 	ldr	w0, [x2]
    77e4:	7100701f 	cmp	w0, #0x1c
    77e8:	540042a0 	b.eq	803c <fwp_write+0xce8>  // b.none
    77ec:	71006c1f 	cmp	w0, #0x1b
    77f0:	540003e8 	b.hi	786c <fwp_write+0x518>  // b.pmore
    77f4:	9ac02301 	lsl	x1, x24, x0
    77f8:	ea17003f 	tst	x1, x23
    77fc:	54003681 	b.ne	7ecc <fwp_write+0xb78>  // b.any
    7800:	ea19003f 	tst	x1, x25
    7804:	54003501 	b.ne	7ea4 <fwp_write+0xb50>  // b.any
    7808:	d2800424 	mov	x4, #0x21                  	// #33
    780c:	ea04003f 	tst	x1, x4
    7810:	540002e0 	b.eq	786c <fwp_write+0x518>  // b.none
    7814:	b7f849a3 	tbnz	x3, #63, 8148 <fwp_write+0xdf4>
    7818:	91002261 	add	x1, x19, #0x8
    781c:	8b150021 	add	x1, x1, x21
    7820:	39400021 	ldrb	w1, [x1]
    7824:	7100001f 	cmp	w0, #0x0
    7828:	93401c23 	sxtb	x3, w1
    782c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7830:	aa1403e0 	mov	x0, x20
    7834:	52800003 	mov	w3, #0x0                   	// #0
    7838:	97fffec7 	bl	7354 <fwp_write>
    783c:	910006b5 	add	x21, x21, #0x1
    7840:	f9400260 	ldr	x0, [x19]
    7844:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7848:	eb0002bf 	cmp	x21, x0
    784c:	540026c2 	b.cs	7d24 <fwp_write+0x9d0>  // b.hs, b.nlast
    7850:	d2800042 	mov	x2, #0x2                   	// #2
    7854:	aa1603e1 	mov	x1, x22
    7858:	aa1403e0 	mov	x0, x20
    785c:	97ffef8d 	bl	3690 <buf_put>
    7860:	f9401f82 	ldr	x2, [x28, #56]
    7864:	f9400263 	ldr	x3, [x19]
    7868:	b5fffbc2 	cbnz	x2, 77e0 <fwp_write+0x48c>
    786c:	d37df2a0 	lsl	x0, x21, #3
    7870:	b7f83f03 	tbnz	x3, #63, 8050 <fwp_write+0xcfc>
    7874:	91002261 	add	x1, x19, #0x8
    7878:	8b000020 	add	x0, x1, x0
    787c:	f9400001 	ldr	x1, [x0]
    7880:	17ffffec 	b	7830 <fwp_write+0x4dc>
    7884:	a9400e62 	ldp	x2, x3, [x19]
    7888:	b7f83ca3 	tbnz	x3, #63, 801c <fwp_write+0xcc8>
    788c:	910123f5 	add	x21, sp, #0x48
    7890:	aa1503e0 	mov	x0, x21
    7894:	97ffed63 	bl	2e20 <fwp_fmt_u128>
    7898:	aa1503e0 	mov	x0, x21
    789c:	97ffeba5 	bl	2730 <strlen@plt>
    78a0:	aa1503e1 	mov	x1, x21
    78a4:	aa0003e2 	mov	x2, x0
    78a8:	17fffed1 	b	73ec <fwp_write+0x98>
    78ac:	fd015be8 	str	d8, [sp, #688]
    78b0:	1e270268 	fmov	s8, w19
    78b4:	fd015fe9 	str	d9, [sp, #696]
    78b8:	1e282100 	fcmp	s8, s8
    78bc:	54004d26 	b.vs	8260 <fwp_write+0xf0c>
    78c0:	1e20c101 	fabs	s1, s8
    78c4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    78c8:	1e270000 	fmov	s0, w0
    78cc:	1e202020 	fcmp	s1, s0
    78d0:	54002c0d 	b.le	7e50 <fwp_write+0xafc>
    78d4:	1e202118 	fcmpe	s8, #0.0
    78d8:	d0000002 	adrp	x2, 9000 <__divti3+0xb0>
    78dc:	911fa042 	add	x2, x2, #0x7e8
    78e0:	910123f5 	add	x21, sp, #0x48
    78e4:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    78e8:	91320021 	add	x1, x1, #0xc80
    78ec:	aa1503e0 	mov	x0, x21
    78f0:	9a81c041 	csel	x1, x2, x1, gt
    78f4:	97ffec3b 	bl	29e0 <strcpy@plt>
    78f8:	aa1503e0 	mov	x0, x21
    78fc:	97ffeb8d 	bl	2730 <strlen@plt>
    7900:	aa1503e1 	mov	x1, x21
    7904:	aa0003e2 	mov	x2, x0
    7908:	aa1403e0 	mov	x0, x20
    790c:	97ffef61 	bl	3690 <buf_put>
    7910:	f9413bf5 	ldr	x21, [sp, #624]
    7914:	f9413ff6 	ldr	x22, [sp, #632]
    7918:	f94153fb 	ldr	x27, [sp, #672]
    791c:	f94157fc 	ldr	x28, [sp, #680]
    7920:	fd415be8 	ldr	d8, [sp, #688]
    7924:	fd415fe9 	ldr	d9, [sp, #696]
    7928:	17fffeb7 	b	7404 <fwp_write+0xb0>
    792c:	f9400276 	ldr	x22, [x19]
    7930:	34002e03 	cbz	w3, 7ef0 <fwp_write+0xb9c>
    7934:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7938:	f947f400 	ldr	x0, [x0, #4072]
    793c:	f94127e2 	ldr	x2, [sp, #584]
    7940:	f9400001 	ldr	x1, [x0]
    7944:	eb010042 	subs	x2, x2, x1
    7948:	d2800001 	mov	x1, #0x0                   	// #0
    794c:	540014a1 	b.ne	7be0 <fwp_write+0x88c>  // b.any
    7950:	aa1603e2 	mov	x2, x22
    7954:	91002261 	add	x1, x19, #0x8
    7958:	f9413bf5 	ldr	x21, [sp, #624]
    795c:	aa1403e0 	mov	x0, x20
    7960:	f9413ff6 	ldr	x22, [sp, #632]
    7964:	17ffff00 	b	7564 <fwp_write+0x210>
    7968:	fd015be8 	str	d8, [sp, #688]
    796c:	9e670268 	fmov	d8, x19
    7970:	fd015fe9 	str	d9, [sp, #696]
    7974:	1e682100 	fcmp	d8, d8
    7978:	54004746 	b.vs	8260 <fwp_write+0xf0c>
    797c:	1e60c101 	fabs	d1, d8
    7980:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7984:	9e670000 	fmov	d0, x0
    7988:	910123f5 	add	x21, sp, #0x48
    798c:	52800033 	mov	w19, #0x1                   	// #1
    7990:	1e602020 	fcmp	d1, d0
    7994:	540001ad 	b.le	79c8 <fwp_write+0x674>
    7998:	1e602118 	fcmpe	d8, #0.0
    799c:	d0000002 	adrp	x2, 9000 <__divti3+0xb0>
    79a0:	911fa042 	add	x2, x2, #0x7e8
    79a4:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    79a8:	91320021 	add	x1, x1, #0xc80
    79ac:	aa1503e0 	mov	x0, x21
    79b0:	9a81c041 	csel	x1, x2, x1, gt
    79b4:	97ffec0b 	bl	29e0 <strcpy@plt>
    79b8:	17ffffd0 	b	78f8 <fwp_write+0x5a4>
    79bc:	11000673 	add	w19, w19, #0x1
    79c0:	71004a7f 	cmp	w19, #0x12
    79c4:	54003860 	b.eq	80d0 <fwp_write+0xd7c>  // b.none
    79c8:	1e604100 	fmov	d0, d8
    79cc:	2a1303e1 	mov	w1, w19
    79d0:	aa1503e0 	mov	x0, x21
    79d4:	97fff070 	bl	3b94 <fwp_format_g.constprop.0>
    79d8:	aa1503e0 	mov	x0, x21
    79dc:	d2800001 	mov	x1, #0x0                   	// #0
    79e0:	97ffeb68 	bl	2780 <strtod@plt>
    79e4:	1e602100 	fcmp	d8, d0
    79e8:	54fffea1 	b.ne	79bc <fwp_write+0x668>  // b.any
    79ec:	aa1503e0 	mov	x0, x21
    79f0:	97ffef61 	bl	3774 <fwp_finish_float>
    79f4:	17ffffc1 	b	78f8 <fwp_write+0x5a4>
    79f8:	a9400e62 	ldp	x2, x3, [x19]
    79fc:	910123f3 	add	x19, sp, #0x48
    7a00:	aa1303e0 	mov	x0, x19
    7a04:	97ffed07 	bl	2e20 <fwp_fmt_u128>
    7a08:	17fffe75 	b	73dc <fwp_write+0x88>
    7a0c:	f90143f7 	str	x23, [sp, #640]
    7a10:	f90147f8 	str	x24, [sp, #648]
    7a14:	2a1303f8 	mov	w24, w19
    7a18:	f9014bf9 	str	x25, [sp, #656]
    7a1c:	f9014ffa 	str	x26, [sp, #664]
    7a20:	f13ffe7f 	cmp	x19, #0xfff
    7a24:	54000049 	b.ls	7a2c <fwp_write+0x6d8>  // b.plast
    7a28:	b9400278 	ldr	w24, [x19]
    7a2c:	f9400f80 	ldr	x0, [x28, #24]
    7a30:	2a1803f5 	mov	w21, w24
    7a34:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7a38:	d37ef6b9 	lsl	x25, x21, #2
    7a3c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7a40:	aa1603e0 	mov	x0, x22
    7a44:	97ffeb3b 	bl	2730 <strlen@plt>
    7a48:	aa1603e1 	mov	x1, x22
    7a4c:	aa0003e2 	mov	x2, x0
    7a50:	aa1403e0 	mov	x0, x20
    7a54:	97ffef0f 	bl	3690 <buf_put>
    7a58:	f9401780 	ldr	x0, [x28, #40]
    7a5c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7a60:	7100001f 	cmp	w0, #0x0
    7a64:	5400068d 	b.le	7b34 <fwp_write+0x7e0>
    7a68:	91002276 	add	x22, x19, #0x8
    7a6c:	91001ff5 	add	x21, sp, #0x7
    7a70:	d280001b 	mov	x27, #0x0                   	// #0
    7a74:	5280041a 	mov	w26, #0x20                  	// #32
    7a78:	f9401b80 	ldr	x0, [x28, #48]
    7a7c:	aa1503e1 	mov	x1, x21
    7a80:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7a84:	d2800022 	mov	x2, #0x1                   	// #1
    7a88:	f8786803 	ldr	x3, [x0, x24]
    7a8c:	aa1403e0 	mov	x0, x20
    7a90:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7a94:	39001ffa 	strb	w26, [sp, #7]
    7a98:	97ffeefe 	bl	3690 <buf_put>
    7a9c:	f13ffeff 	cmp	x23, #0xfff
    7aa0:	b9400261 	ldr	w1, [x19]
    7aa4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7aa8:	7100383f 	cmp	w1, #0xe
    7aac:	54000160 	b.eq	7ad8 <fwp_write+0x784>  // b.none
    7ab0:	7100403f 	cmp	w1, #0x10
    7ab4:	54001a60 	b.eq	7e00 <fwp_write+0xaac>  // b.none
    7ab8:	7100283f 	cmp	w1, #0xa
    7abc:	54002aa0 	b.eq	8010 <fwp_write+0xcbc>  // b.none
    7ac0:	540014ac 	b.gt	7d54 <fwp_write+0xa00>
    7ac4:	71000c3f 	cmp	w1, #0x3
    7ac8:	540029ac 	b.gt	7ffc <fwp_write+0xca8>
    7acc:	d37ffee0 	lsr	x0, x23, #63
    7ad0:	37f814a1 	tbnz	w1, #31, 7d64 <fwp_write+0xa10>
    7ad4:	d503201f 	nop
    7ad8:	34001460 	cbz	w0, 7d64 <fwp_write+0xa10>
    7adc:	52800503 	mov	w3, #0x28                  	// #40
    7ae0:	aa1503e1 	mov	x1, x21
    7ae4:	aa1403e0 	mov	x0, x20
    7ae8:	d2800022 	mov	x2, #0x1                   	// #1
    7aec:	39001fe3 	strb	w3, [sp, #7]
    7af0:	97ffeee8 	bl	3690 <buf_put>
    7af4:	aa1303e2 	mov	x2, x19
    7af8:	aa1703e1 	mov	x1, x23
    7afc:	aa1403e0 	mov	x0, x20
    7b00:	52800003 	mov	w3, #0x0                   	// #0
    7b04:	97fffe14 	bl	7354 <fwp_write>
    7b08:	52800523 	mov	w3, #0x29                  	// #41
    7b0c:	aa1503e1 	mov	x1, x21
    7b10:	aa1403e0 	mov	x0, x20
    7b14:	d2800022 	mov	x2, #0x1                   	// #1
    7b18:	39001fe3 	strb	w3, [sp, #7]
    7b1c:	97ffeedd 	bl	3690 <buf_put>
    7b20:	f9401780 	ldr	x0, [x28, #40]
    7b24:	9100077b 	add	x27, x27, #0x1
    7b28:	b8796800 	ldr	w0, [x0, x25]
    7b2c:	6b1b001f 	cmp	w0, w27
    7b30:	54fffa4c 	b.gt	7a78 <fwp_write+0x724>
    7b34:	f9413bf5 	ldr	x21, [sp, #624]
    7b38:	f9413ff6 	ldr	x22, [sp, #632]
    7b3c:	f94143f7 	ldr	x23, [sp, #640]
    7b40:	f94147f8 	ldr	x24, [sp, #648]
    7b44:	f9414bf9 	ldr	x25, [sp, #656]
    7b48:	f9414ffa 	ldr	x26, [sp, #664]
    7b4c:	f94153fb 	ldr	x27, [sp, #672]
    7b50:	f94157fc 	ldr	x28, [sp, #680]
    7b54:	17fffe2c 	b	7404 <fwp_write+0xb0>
    7b58:	52800783 	mov	w3, #0x3c                  	// #60
    7b5c:	91001ff3 	add	x19, sp, #0x7
    7b60:	aa1303e1 	mov	x1, x19
    7b64:	d2800022 	mov	x2, #0x1                   	// #1
    7b68:	aa1403e0 	mov	x0, x20
    7b6c:	39001fe3 	strb	w3, [sp, #7]
    7b70:	97ffeec8 	bl	3690 <buf_put>
    7b74:	f9400795 	ldr	x21, [x28, #8]
    7b78:	aa1503e0 	mov	x0, x21
    7b7c:	97ffeaed 	bl	2730 <strlen@plt>
    7b80:	aa1503e1 	mov	x1, x21
    7b84:	aa0003e2 	mov	x2, x0
    7b88:	aa1403e0 	mov	x0, x20
    7b8c:	97ffeec1 	bl	3690 <buf_put>
    7b90:	528007c3 	mov	w3, #0x3e                  	// #62
    7b94:	aa1303e1 	mov	x1, x19
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	d2800022 	mov	x2, #0x1                   	// #1
    7ba0:	39001fe3 	strb	w3, [sp, #7]
    7ba4:	17fffe13 	b	73f0 <fwp_write+0x9c>
    7ba8:	f100067f 	cmp	x19, #0x1
    7bac:	540025a0 	b.eq	8060 <fwp_write+0xd0c>  // b.none
    7bb0:	b100067f 	cmn	x19, #0x1
    7bb4:	54002bc0 	b.eq	812c <fwp_write+0xdd8>  // b.none
    7bb8:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7bbc:	91322021 	add	x1, x1, #0xc88
    7bc0:	d2800022 	mov	x2, #0x1                   	// #1
    7bc4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7bc8:	f947f400 	ldr	x0, [x0, #4072]
    7bcc:	f94127e4 	ldr	x4, [sp, #584]
    7bd0:	f9400003 	ldr	x3, [x0]
    7bd4:	eb030084 	subs	x4, x4, x3
    7bd8:	d2800003 	mov	x3, #0x0                   	// #0
    7bdc:	54ffebe0 	b.eq	7958 <fwp_write+0x604>  // b.none
    7be0:	f90143f7 	str	x23, [sp, #640]
    7be4:	f90147f8 	str	x24, [sp, #648]
    7be8:	f9014bf9 	str	x25, [sp, #656]
    7bec:	f9014ffa 	str	x26, [sp, #664]
    7bf0:	fd015be8 	str	d8, [sp, #688]
    7bf4:	fd015fe9 	str	d9, [sp, #696]
    7bf8:	97ffeb2a 	bl	28a0 <__stack_chk_fail@plt>
    7bfc:	52800b63 	mov	w3, #0x5b                  	// #91
    7c00:	91001ff5 	add	x21, sp, #0x7
    7c04:	aa1503e1 	mov	x1, x21
    7c08:	aa1403e0 	mov	x0, x20
    7c0c:	d2800022 	mov	x2, #0x1                   	// #1
    7c10:	d0000016 	adrp	x22, 9000 <__divti3+0xb0>
    7c14:	9134a2d6 	add	x22, x22, #0xd28
    7c18:	39001fe3 	strb	w3, [sp, #7]
    7c1c:	97ffee9d 	bl	3690 <buf_put>
    7c20:	b4000273 	cbz	x19, 7c6c <fwp_write+0x918>
    7c24:	f9400661 	ldr	x1, [x19, #8]
    7c28:	aa1403e0 	mov	x0, x20
    7c2c:	f9401f82 	ldr	x2, [x28, #56]
    7c30:	52800003 	mov	w3, #0x0                   	// #0
    7c34:	97fffdc8 	bl	7354 <fwp_write>
    7c38:	f9400a73 	ldr	x19, [x19, #16]
    7c3c:	b4000193 	cbz	x19, 7c6c <fwp_write+0x918>
    7c40:	aa1603e1 	mov	x1, x22
    7c44:	aa1403e0 	mov	x0, x20
    7c48:	d2800042 	mov	x2, #0x2                   	// #2
    7c4c:	97ffee91 	bl	3690 <buf_put>
    7c50:	f9400661 	ldr	x1, [x19, #8]
    7c54:	aa1403e0 	mov	x0, x20
    7c58:	f9401f82 	ldr	x2, [x28, #56]
    7c5c:	52800003 	mov	w3, #0x0                   	// #0
    7c60:	97fffdbd 	bl	7354 <fwp_write>
    7c64:	f9400a73 	ldr	x19, [x19, #16]
    7c68:	b5fffed3 	cbnz	x19, 7c40 <fwp_write+0x8ec>
    7c6c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7c70:	aa1503e1 	mov	x1, x21
    7c74:	aa1403e0 	mov	x0, x20
    7c78:	d2800022 	mov	x2, #0x1                   	// #1
    7c7c:	39001fe3 	strb	w3, [sp, #7]
    7c80:	17fffddc 	b	73f0 <fwp_write+0x9c>
    7c84:	aa1403e0 	mov	x0, x20
    7c88:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7c8c:	d28000c2 	mov	x2, #0x6                   	// #6
    7c90:	91346021 	add	x1, x1, #0xd18
    7c94:	97ffee7f 	bl	3690 <buf_put>
    7c98:	f9400260 	ldr	x0, [x19]
    7c9c:	b40004c0 	cbz	x0, 7d34 <fwp_write+0x9e0>
    7ca0:	910123f5 	add	x21, sp, #0x48
    7ca4:	91002276 	add	x22, x19, #0x8
    7ca8:	f90143f7 	str	x23, [sp, #640]
    7cac:	d2800017 	mov	x23, #0x0                   	// #0
    7cb0:	f90147f8 	str	x24, [sp, #648]
    7cb4:	d0000018 	adrp	x24, 9000 <__divti3+0xb0>
    7cb8:	91348318 	add	x24, x24, #0xd20
    7cbc:	f9014bf9 	str	x25, [sp, #656]
    7cc0:	d0000019 	adrp	x25, 9000 <__divti3+0xb0>
    7cc4:	9134a339 	add	x25, x25, #0xd28
    7cc8:	f9014ffa 	str	x26, [sp, #664]
    7ccc:	14000005 	b	7ce0 <fwp_write+0x98c>
    7cd0:	aa1903e1 	mov	x1, x25
    7cd4:	aa1403e0 	mov	x0, x20
    7cd8:	d2800042 	mov	x2, #0x2                   	// #2
    7cdc:	97ffee6d 	bl	3690 <buf_put>
    7ce0:	38776ac5 	ldrb	w5, [x22, x23]
    7ce4:	d2804003 	mov	x3, #0x200                 	// #512
    7ce8:	aa1803e4 	mov	x4, x24
    7cec:	aa0303e1 	mov	x1, x3
    7cf0:	52800042 	mov	w2, #0x2                   	// #2
    7cf4:	aa1503e0 	mov	x0, x21
    7cf8:	910006f7 	add	x23, x23, #0x1
    7cfc:	97ffeac5 	bl	2810 <__snprintf_chk@plt>
    7d00:	aa1503e0 	mov	x0, x21
    7d04:	97ffea8b 	bl	2730 <strlen@plt>
    7d08:	aa1503e1 	mov	x1, x21
    7d0c:	aa0003e2 	mov	x2, x0
    7d10:	aa1403e0 	mov	x0, x20
    7d14:	97ffee5f 	bl	3690 <buf_put>
    7d18:	f9400260 	ldr	x0, [x19]
    7d1c:	eb17001f 	cmp	x0, x23
    7d20:	54fffd88 	b.hi	7cd0 <fwp_write+0x97c>  // b.pmore
    7d24:	f94143f7 	ldr	x23, [sp, #640]
    7d28:	f94147f8 	ldr	x24, [sp, #648]
    7d2c:	f9414bf9 	ldr	x25, [sp, #656]
    7d30:	f9414ffa 	ldr	x26, [sp, #664]
    7d34:	52800ba3 	mov	w3, #0x5d                  	// #93
    7d38:	aa1403e0 	mov	x0, x20
    7d3c:	91001fe1 	add	x1, sp, #0x7
    7d40:	d2800022 	mov	x2, #0x1                   	// #1
    7d44:	39001fe3 	strb	w3, [sp, #7]
    7d48:	17fffdaa 	b	73f0 <fwp_write+0x9c>
    7d4c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7d50:	17fffe45 	b	7664 <fwp_write+0x310>
    7d54:	f10002ff 	cmp	x23, #0x0
    7d58:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7d5c:	71002c3f 	cmp	w1, #0xb
    7d60:	54ffebc0 	b.eq	7ad8 <fwp_write+0x784>  // b.none
    7d64:	aa1303e2 	mov	x2, x19
    7d68:	aa1703e1 	mov	x1, x23
    7d6c:	aa1403e0 	mov	x0, x20
    7d70:	52800003 	mov	w3, #0x0                   	// #0
    7d74:	97fffd78 	bl	7354 <fwp_write>
    7d78:	17ffff6a 	b	7b20 <fwp_write+0x7cc>
    7d7c:	aa1403e0 	mov	x0, x20
    7d80:	91001fe1 	add	x1, sp, #0x7
    7d84:	52800fa3 	mov	w3, #0x7d                  	// #125
    7d88:	d2800022 	mov	x2, #0x1                   	// #1
    7d8c:	17fffe39 	b	7670 <fwp_write+0x31c>
    7d90:	a9400281 	ldp	x1, x0, [x20]
    7d94:	91000800 	add	x0, x0, #0x2
    7d98:	8b160000 	add	x0, x0, x22
    7d9c:	f9000680 	str	x0, [x20, #8]
    7da0:	3820683f 	strb	wzr, [x1, x0]
    7da4:	f9413bf5 	ldr	x21, [sp, #624]
    7da8:	f9413ff6 	ldr	x22, [sp, #632]
    7dac:	f94153fb 	ldr	x27, [sp, #672]
    7db0:	f94157fc 	ldr	x28, [sp, #680]
    7db4:	17fffd94 	b	7404 <fwp_write+0xb0>
    7db8:	f9400f80 	ldr	x0, [x28, #24]
    7dbc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7dc0:	aa1b03e0 	mov	x0, x27
    7dc4:	97ffea5b 	bl	2730 <strlen@plt>
    7dc8:	aa1b03e1 	mov	x1, x27
    7dcc:	aa0003e2 	mov	x2, x0
    7dd0:	aa1403e0 	mov	x0, x20
    7dd4:	97ffee2f 	bl	3690 <buf_put>
    7dd8:	aa1903e1 	mov	x1, x25
    7ddc:	aa1403e0 	mov	x0, x20
    7de0:	d2800062 	mov	x2, #0x3                   	// #3
    7de4:	97ffee2b 	bl	3690 <buf_put>
    7de8:	17fffe11 	b	762c <fwp_write+0x2d8>
    7dec:	aa1a03e1 	mov	x1, x26
    7df0:	aa1403e0 	mov	x0, x20
    7df4:	d2800042 	mov	x2, #0x2                   	// #2
    7df8:	97ffee26 	bl	3690 <buf_put>
    7dfc:	17fffe0a 	b	7624 <fwp_write+0x2d0>
    7e00:	f9400660 	ldr	x0, [x19, #8]
    7e04:	b4fffb00 	cbz	x0, 7d64 <fwp_write+0xa10>
    7e08:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7e0c:	91350021 	add	x1, x1, #0xd40
    7e10:	97ffeac4 	bl	2920 <strcmp@plt>
    7e14:	7100001f 	cmp	w0, #0x0
    7e18:	1a9f07e0 	cset	w0, ne	// ne = any
    7e1c:	17ffff2f 	b	7ad8 <fwp_write+0x784>
    7e20:	aa1403e0 	mov	x0, x20
    7e24:	d2800042 	mov	x2, #0x2                   	// #2
    7e28:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7e2c:	9134e021 	add	x1, x1, #0xd38
    7e30:	97ffee18 	bl	3690 <buf_put>
    7e34:	91004261 	add	x1, x19, #0x10
    7e38:	aa1403e0 	mov	x0, x20
    7e3c:	f9402382 	ldr	x2, [x28, #64]
    7e40:	52800003 	mov	w3, #0x0                   	// #0
    7e44:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7e48:	97fffd43 	bl	7354 <fwp_write>
    7e4c:	17fffd9d 	b	74c0 <fwp_write+0x16c>
    7e50:	1e22c109 	fcvt	d9, s8
    7e54:	910123f5 	add	x21, sp, #0x48
    7e58:	52800033 	mov	w19, #0x1                   	// #1
    7e5c:	d503201f 	nop
    7e60:	1e604120 	fmov	d0, d9
    7e64:	2a1303e1 	mov	w1, w19
    7e68:	aa1503e0 	mov	x0, x21
    7e6c:	97ffef4a 	bl	3b94 <fwp_format_g.constprop.0>
    7e70:	aa1503e0 	mov	x0, x21
    7e74:	d2800001 	mov	x1, #0x0                   	// #0
    7e78:	97ffeab6 	bl	2950 <strtof@plt>
    7e7c:	1e202100 	fcmp	s8, s0
    7e80:	54ffdb60 	b.eq	79ec <fwp_write+0x698>  // b.none
    7e84:	11000673 	add	w19, w19, #0x1
    7e88:	71002a7f 	cmp	w19, #0xa
    7e8c:	54fffea1 	b.ne	7e60 <fwp_write+0xb0c>  // b.any
    7e90:	1e604120 	fmov	d0, d9
    7e94:	aa1503e0 	mov	x0, x21
    7e98:	52800121 	mov	w1, #0x9                   	// #9
    7e9c:	97ffef3e 	bl	3b94 <fwp_format_g.constprop.0>
    7ea0:	17fffed3 	b	79ec <fwp_write+0x698>
    7ea4:	d37ef6a1 	lsl	x1, x21, #2
    7ea8:	b7f81563 	tbnz	x3, #63, 8154 <fwp_write+0xe00>
    7eac:	91002263 	add	x3, x19, #0x8
    7eb0:	8b010061 	add	x1, x3, x1
    7eb4:	b9400023 	ldr	w3, [x1]
    7eb8:	7100081f 	cmp	w0, #0x2
    7ebc:	2a0303e1 	mov	w1, w3
    7ec0:	93407c63 	sxtw	x3, w3
    7ec4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ec8:	17fffe5a 	b	7830 <fwp_write+0x4dc>
    7ecc:	d37ffaa1 	lsl	x1, x21, #1
    7ed0:	b7f81363 	tbnz	x3, #63, 813c <fwp_write+0xde8>
    7ed4:	91002263 	add	x3, x19, #0x8
    7ed8:	8b010061 	add	x1, x3, x1
    7edc:	79400021 	ldrh	w1, [x1]
    7ee0:	7100041f 	cmp	w0, #0x1
    7ee4:	93403c23 	sxth	x3, w1
    7ee8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7eec:	17fffe51 	b	7830 <fwp_write+0x4dc>
    7ef0:	52800443 	mov	w3, #0x22                  	// #34
    7ef4:	91001ff5 	add	x21, sp, #0x7
    7ef8:	91002273 	add	x19, x19, #0x8
    7efc:	aa1503e1 	mov	x1, x21
    7f00:	aa1403e0 	mov	x0, x20
    7f04:	d2800022 	mov	x2, #0x1                   	// #1
    7f08:	39001fe3 	strb	w3, [sp, #7]
    7f0c:	f90143f7 	str	x23, [sp, #640]
    7f10:	8b160277 	add	x23, x19, x22
    7f14:	f90147f8 	str	x24, [sp, #648]
    7f18:	97ffedde 	bl	3690 <buf_put>
    7f1c:	b4000696 	cbz	x22, 7fec <fwp_write+0xc98>
    7f20:	d0000018 	adrp	x24, 9000 <__divti3+0xb0>
    7f24:	9133a318 	add	x24, x24, #0xce8
    7f28:	f9014bf9 	str	x25, [sp, #656]
    7f2c:	d0000019 	adrp	x25, 9000 <__divti3+0xb0>
    7f30:	91342339 	add	x25, x25, #0xd08
    7f34:	f9014ffa 	str	x26, [sp, #664]
    7f38:	1400000d 	b	7f6c <fwp_write+0xc18>
    7f3c:	710024bf 	cmp	w5, #0x9
    7f40:	54000460 	b.eq	7fcc <fwp_write+0xc78>  // b.none
    7f44:	710028bf 	cmp	w5, #0xa
    7f48:	54000a61 	b.ne	8094 <fwp_write+0xd40>  // b.any
    7f4c:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7f50:	aa1403e0 	mov	x0, x20
    7f54:	9133e021 	add	x1, x1, #0xcf8
    7f58:	d2800042 	mov	x2, #0x2                   	// #2
    7f5c:	97ffedcd 	bl	3690 <buf_put>
    7f60:	91000673 	add	x19, x19, #0x1
    7f64:	eb17027f 	cmp	x19, x23
    7f68:	540003e0 	b.eq	7fe4 <fwp_write+0xc90>  // b.none
    7f6c:	39400265 	ldrb	w5, [x19]
    7f70:	710034bf 	cmp	w5, #0xd
    7f74:	54000180 	b.eq	7fa4 <fwp_write+0xc50>  // b.none
    7f78:	54fffe29 	b.ls	7f3c <fwp_write+0xbe8>  // b.plast
    7f7c:	710088bf 	cmp	w5, #0x22
    7f80:	540001c0 	b.eq	7fb8 <fwp_write+0xc64>  // b.none
    7f84:	710170bf 	cmp	w5, #0x5c
    7f88:	54000741 	b.ne	8070 <fwp_write+0xd1c>  // b.any
    7f8c:	aa1403e0 	mov	x0, x20
    7f90:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7f94:	d2800042 	mov	x2, #0x2                   	// #2
    7f98:	9133c021 	add	x1, x1, #0xcf0
    7f9c:	97ffedbd 	bl	3690 <buf_put>
    7fa0:	17fffff0 	b	7f60 <fwp_write+0xc0c>
    7fa4:	aa1903e1 	mov	x1, x25
    7fa8:	aa1403e0 	mov	x0, x20
    7fac:	d2800042 	mov	x2, #0x2                   	// #2
    7fb0:	97ffedb8 	bl	3690 <buf_put>
    7fb4:	17ffffeb 	b	7f60 <fwp_write+0xc0c>
    7fb8:	aa1803e1 	mov	x1, x24
    7fbc:	aa1403e0 	mov	x0, x20
    7fc0:	d2800042 	mov	x2, #0x2                   	// #2
    7fc4:	97ffedb3 	bl	3690 <buf_put>
    7fc8:	17ffffe6 	b	7f60 <fwp_write+0xc0c>
    7fcc:	aa1403e0 	mov	x0, x20
    7fd0:	d0000001 	adrp	x1, 9000 <__divti3+0xb0>
    7fd4:	d2800042 	mov	x2, #0x2                   	// #2
    7fd8:	91340021 	add	x1, x1, #0xd00
    7fdc:	97ffedad 	bl	3690 <buf_put>
    7fe0:	17ffffe0 	b	7f60 <fwp_write+0xc0c>
    7fe4:	f9414bf9 	ldr	x25, [sp, #656]
    7fe8:	f9414ffa 	ldr	x26, [sp, #664]
    7fec:	aa1503e1 	mov	x1, x21
    7ff0:	aa1403e0 	mov	x0, x20
    7ff4:	52800443 	mov	w3, #0x22                  	// #34
    7ff8:	17fffd9d 	b	766c <fwp_write+0x318>
    7ffc:	7100103f 	cmp	w1, #0x4
    8000:	54ffeb21 	b.ne	7d64 <fwp_write+0xa10>  // b.any
    8004:	f94006e0 	ldr	x0, [x23, #8]
    8008:	d37ffc00 	lsr	x0, x0, #63
    800c:	17fffeb3 	b	7ad8 <fwp_write+0x784>
    8010:	710002ff 	cmp	w23, #0x0
    8014:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8018:	17fffeb0 	b	7ad8 <fwp_write+0x784>
    801c:	528005a1 	mov	w1, #0x2d                  	// #45
    8020:	eb0203e2 	negs	x2, x2
    8024:	da0303e3 	ngc	x3, x3
    8028:	910127e0 	add	x0, sp, #0x49
    802c:	910123f5 	add	x21, sp, #0x48
    8030:	390123e1 	strb	w1, [sp, #72]
    8034:	97ffeb7b 	bl	2e20 <fwp_fmt_u128>
    8038:	17fffe18 	b	7898 <fwp_write+0x544>
    803c:	d37ceea1 	lsl	x1, x21, #4
    8040:	b7f810a3 	tbnz	x3, #63, 8254 <fwp_write+0xf00>
    8044:	91002260 	add	x0, x19, #0x8
    8048:	8b010001 	add	x1, x0, x1
    804c:	17fffdf9 	b	7830 <fwp_write+0x4dc>
    8050:	f9400a61 	ldr	x1, [x19, #16]
    8054:	8b010000 	add	x0, x0, x1
    8058:	f9400001 	ldr	x1, [x0]
    805c:	17fffdf5 	b	7830 <fwp_write+0x4dc>
    8060:	b0000001 	adrp	x1, 9000 <__divti3+0xb0>
    8064:	d2800042 	mov	x2, #0x2                   	// #2
    8068:	91324021 	add	x1, x1, #0xc90
    806c:	17fffed6 	b	7bc4 <fwp_write+0x870>
    8070:	7101fcbf 	cmp	w5, #0x7f
    8074:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8078:	540000e9 	b.ls	8094 <fwp_write+0xd40>  // b.plast
    807c:	aa1503e1 	mov	x1, x21
    8080:	aa1403e0 	mov	x0, x20
    8084:	d2800022 	mov	x2, #0x1                   	// #1
    8088:	39001fe5 	strb	w5, [sp, #7]
    808c:	97ffed81 	bl	3690 <buf_put>
    8090:	17ffffb4 	b	7f60 <fwp_write+0xc0c>
    8094:	d2800203 	mov	x3, #0x10                  	// #16
    8098:	b0000004 	adrp	x4, 9000 <__divti3+0xb0>
    809c:	aa0303e1 	mov	x1, x3
    80a0:	91344084 	add	x4, x4, #0xd10
    80a4:	910123f6 	add	x22, sp, #0x48
    80a8:	52800042 	mov	w2, #0x2                   	// #2
    80ac:	aa1603e0 	mov	x0, x22
    80b0:	97ffe9d8 	bl	2810 <__snprintf_chk@plt>
    80b4:	aa1603e0 	mov	x0, x22
    80b8:	97ffe99e 	bl	2730 <strlen@plt>
    80bc:	aa1603e1 	mov	x1, x22
    80c0:	aa0003e2 	mov	x2, x0
    80c4:	aa1403e0 	mov	x0, x20
    80c8:	97ffed72 	bl	3690 <buf_put>
    80cc:	17ffffa5 	b	7f60 <fwp_write+0xc0c>
    80d0:	1e604100 	fmov	d0, d8
    80d4:	aa1503e0 	mov	x0, x21
    80d8:	52800221 	mov	w1, #0x11                  	// #17
    80dc:	97ffeeae 	bl	3b94 <fwp_format_g.constprop.0>
    80e0:	17fffe43 	b	79ec <fwp_write+0x698>
    80e4:	b9401040 	ldr	w0, [x2, #16]
    80e8:	350003c0 	cbnz	w0, 8160 <fwp_write+0xe0c>
    80ec:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    80f0:	f947f400 	ldr	x0, [x0, #4072]
    80f4:	f94127e2 	ldr	x2, [sp, #584]
    80f8:	f9400001 	ldr	x1, [x0]
    80fc:	eb010042 	subs	x2, x2, x1
    8100:	d2800001 	mov	x1, #0x0                   	// #0
    8104:	54ffd721 	b.ne	7be8 <fwp_write+0x894>  // b.any
    8108:	f9413bf5 	ldr	x21, [sp, #624]
    810c:	b0000001 	adrp	x1, 9000 <__divti3+0xb0>
    8110:	f9413ff6 	ldr	x22, [sp, #632]
    8114:	aa1403e0 	mov	x0, x20
    8118:	f94143f7 	ldr	x23, [sp, #640]
    811c:	91358021 	add	x1, x1, #0xd60
    8120:	f94147f8 	ldr	x24, [sp, #648]
    8124:	d2800042 	mov	x2, #0x2                   	// #2
    8128:	17fffd0f 	b	7564 <fwp_write+0x210>
    812c:	b0000001 	adrp	x1, 9000 <__divti3+0xb0>
    8130:	d2800042 	mov	x2, #0x2                   	// #2
    8134:	91326021 	add	x1, x1, #0xc98
    8138:	17fffea3 	b	7bc4 <fwp_write+0x870>
    813c:	f9400a63 	ldr	x3, [x19, #16]
    8140:	8b030021 	add	x1, x1, x3
    8144:	17ffff66 	b	7edc <fwp_write+0xb88>
    8148:	f9400a61 	ldr	x1, [x19, #16]
    814c:	8b0102a1 	add	x1, x21, x1
    8150:	17fffdb4 	b	7820 <fwp_write+0x4cc>
    8154:	f9400a63 	ldr	x3, [x19, #16]
    8158:	8b030021 	add	x1, x1, x3
    815c:	17ffff56 	b	7eb4 <fwp_write+0xb60>
    8160:	b9404840 	ldr	w0, [x2, #72]
    8164:	91001ff5 	add	x21, sp, #0x7
    8168:	34ffa380 	cbz	w0, 75d8 <fwp_write+0x284>
    816c:	52800503 	mov	w3, #0x28                  	// #40
    8170:	aa1403e0 	mov	x0, x20
    8174:	aa1503e1 	mov	x1, x21
    8178:	d2800022 	mov	x2, #0x1                   	// #1
    817c:	39001fe3 	strb	w3, [sp, #7]
    8180:	97ffed44 	bl	3690 <buf_put>
    8184:	b9401380 	ldr	w0, [x28, #16]
    8188:	52800038 	mov	w24, #0x1                   	// #1
    818c:	7100001f 	cmp	w0, #0x0
    8190:	54ffa38c 	b.gt	7600 <fwp_write+0x2ac>
    8194:	17fffd33 	b	7660 <fwp_write+0x30c>
    8198:	f9014bf9 	str	x25, [sp, #656]
    819c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x127c8>
    81a0:	f9014ffa 	str	x26, [sp, #664]
    81a4:	f9400676 	ldr	x22, [x19, #8]
    81a8:	910ac333 	add	x19, x25, #0x2b0
    81ac:	91002273 	add	x19, x19, #0x8
    81b0:	937ffed8 	asr	x24, x22, #63
    81b4:	aa1802c0 	orr	x0, x22, x24
    81b8:	b5000320 	cbnz	x0, 821c <fwp_write+0xec8>
    81bc:	110006b5 	add	w21, w21, #0x1
    81c0:	710016bf 	cmp	w21, #0x5
    81c4:	54ffffc1 	b.ne	81bc <fwp_write+0xe68>  // b.any
    81c8:	b7f80578 	tbnz	x24, #63, 8274 <fwp_write+0xf20>
    81cc:	910023f3 	add	x19, sp, #0x8
    81d0:	aa1603e2 	mov	x2, x22
    81d4:	aa1303e0 	mov	x0, x19
    81d8:	d2800003 	mov	x3, #0x0                   	// #0
    81dc:	97ffeb11 	bl	2e20 <fwp_fmt_u128>
    81e0:	910123f5 	add	x21, sp, #0x48
    81e4:	b0000003 	adrp	x3, 9000 <__divti3+0xb0>
    81e8:	aa1303e4 	mov	x4, x19
    81ec:	aa1503e0 	mov	x0, x21
    81f0:	91356063 	add	x3, x3, #0xd58
    81f4:	d2804002 	mov	x2, #0x200                 	// #512
    81f8:	52800041 	mov	w1, #0x2                   	// #2
    81fc:	97ffe951 	bl	2740 <__sprintf_chk@plt>
    8200:	aa1503e0 	mov	x0, x21
    8204:	97ffe94b 	bl	2730 <strlen@plt>
    8208:	aa1503e1 	mov	x1, x21
    820c:	aa0003e2 	mov	x2, x0
    8210:	aa1403e0 	mov	x0, x20
    8214:	97ffed1f 	bl	3690 <buf_put>
    8218:	17fffe47 	b	7b34 <fwp_write+0x7e0>
    821c:	f9400277 	ldr	x23, [x19]
    8220:	aa1603e0 	mov	x0, x22
    8224:	aa1803e1 	mov	x1, x24
    8228:	aa1703e2 	mov	x2, x23
    822c:	937ffefa 	asr	x26, x23, #63
    8230:	aa1a03e3 	mov	x3, x26
    8234:	94000427 	bl	92d0 <__modti3>
    8238:	aa010000 	orr	x0, x0, x1
    823c:	b40002c0 	cbz	x0, 8294 <fwp_write+0xf40>
    8240:	110006b5 	add	w21, w21, #0x1
    8244:	91004273 	add	x19, x19, #0x10
    8248:	710016bf 	cmp	w21, #0x5
    824c:	54fffe81 	b.ne	821c <fwp_write+0xec8>  // b.any
    8250:	17ffffde 	b	81c8 <fwp_write+0xe74>
    8254:	f9400a60 	ldr	x0, [x19, #16]
    8258:	8b000021 	add	x1, x1, x0
    825c:	17fffd75 	b	7830 <fwp_write+0x4dc>
    8260:	528c29c0 	mov	w0, #0x614e                	// #24910
    8264:	910123f5 	add	x21, sp, #0x48
    8268:	72a009c0 	movk	w0, #0x4e, lsl #16
    826c:	b9004be0 	str	w0, [sp, #72]
    8270:	17fffda2 	b	78f8 <fwp_write+0x5a4>
    8274:	528005a1 	mov	w1, #0x2d                  	// #45
    8278:	eb1603e2 	negs	x2, x22
    827c:	da1803e3 	ngc	x3, x24
    8280:	910027e0 	add	x0, sp, #0x9
    8284:	910023f3 	add	x19, sp, #0x8
    8288:	390023e1 	strb	w1, [sp, #8]
    828c:	97ffeae5 	bl	2e20 <fwp_fmt_u128>
    8290:	17ffffd4 	b	81e0 <fwp_write+0xe8c>
    8294:	aa1703e2 	mov	x2, x23
    8298:	aa1a03e3 	mov	x3, x26
    829c:	aa1603e0 	mov	x0, x22
    82a0:	aa1803e1 	mov	x1, x24
    82a4:	9400032b 	bl	8f50 <__divti3>
    82a8:	aa0003e2 	mov	x2, x0
    82ac:	aa0103e3 	mov	x3, x1
    82b0:	b7f80201 	tbnz	x1, #63, 82f0 <fwp_write+0xf9c>
    82b4:	910023f3 	add	x19, sp, #0x8
    82b8:	aa1303e0 	mov	x0, x19
    82bc:	97ffead9 	bl	2e20 <fwp_fmt_u128>
    82c0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    82c4:	910ac339 	add	x25, x25, #0x2b0
    82c8:	910123f5 	add	x21, sp, #0x48
    82cc:	aa1303e4 	mov	x4, x19
    82d0:	aa1503e0 	mov	x0, x21
    82d4:	b0000003 	adrp	x3, 9000 <__divti3+0xb0>
    82d8:	f8616b25 	ldr	x5, [x25, x1]
    82dc:	91354063 	add	x3, x3, #0xd50
    82e0:	d2804002 	mov	x2, #0x200                 	// #512
    82e4:	52800041 	mov	w1, #0x2                   	// #2
    82e8:	97ffe916 	bl	2740 <__sprintf_chk@plt>
    82ec:	17ffffc5 	b	8200 <fwp_write+0xeac>
    82f0:	528005a4 	mov	w4, #0x2d                  	// #45
    82f4:	eb0003e2 	negs	x2, x0
    82f8:	da0103e3 	ngc	x3, x1
    82fc:	910027e0 	add	x0, sp, #0x9
    8300:	910023f3 	add	x19, sp, #0x8
    8304:	390023e4 	strb	w4, [sp, #8]
    8308:	97ffeac6 	bl	2e20 <fwp_fmt_u128>
    830c:	17ffffed 	b	82c0 <fwp_write+0xf6c>
    8310:	f9013bf5 	str	x21, [sp, #624]
    8314:	f9013ff6 	str	x22, [sp, #632]
    8318:	f90143f7 	str	x23, [sp, #640]
    831c:	f90147f8 	str	x24, [sp, #648]
    8320:	f9014bf9 	str	x25, [sp, #656]
    8324:	f9014ffa 	str	x26, [sp, #664]
    8328:	f90153fb 	str	x27, [sp, #672]
    832c:	f90157fc 	str	x28, [sp, #680]
    8330:	fd015be8 	str	d8, [sp, #688]
    8334:	fd015fe9 	str	d9, [sp, #696]
    8338:	97ffe95a 	bl	28a0 <__stack_chk_fail@plt>
    833c:	d503201f 	nop

0000000000008340 <fwp_main_thread>:
    8340:	d10603ff 	sub	sp, sp, #0x180
    8344:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8348:	f947f400 	ldr	x0, [x0, #4072]
    834c:	a9127bfd 	stp	x29, x30, [sp, #288]
    8350:	910483fd 	add	x29, sp, #0x120
    8354:	a9145bf5 	stp	x21, x22, [sp, #320]
    8358:	b0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    835c:	911882a1 	add	x1, x21, #0x620
    8360:	a91353f3 	stp	x19, x20, [sp, #304]
    8364:	a91563f7 	stp	x23, x24, [sp, #336]
    8368:	b953a421 	ldr	w1, [x1, #5028]
    836c:	a9166bf9 	stp	x25, x26, [sp, #352]
    8370:	a91773fb 	stp	x27, x28, [sp, #368]
    8374:	f9400002 	ldr	x2, [x0]
    8378:	f9008fe2 	str	x2, [sp, #280]
    837c:	d2800002 	mov	x2, #0x0                   	// #0
    8380:	34002761 	cbz	w1, 886c <fwp_main_thread+0x52c>
    8384:	911882a0 	add	x0, x21, #0x620
    8388:	b953a800 	ldr	w0, [x0, #5032]
    838c:	35002780 	cbnz	w0, 887c <fwp_main_thread+0x53c>
    8390:	900000d4 	adrp	x20, 20000 <__data_start>
    8394:	900000c2 	adrp	x2, 20000 <__data_start>
    8398:	9101429a 	add	x26, x20, #0x50
    839c:	91110042 	add	x2, x2, #0x440
    83a0:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    83a4:	d2a00024 	mov	x4, #0x10000               	// #65536
    83a8:	910103f7 	add	x23, sp, #0x40
    83ac:	9100a3fb 	add	x27, sp, #0x28
    83b0:	aa1703e0 	mov	x0, x23
    83b4:	d2800001 	mov	x1, #0x0                   	// #0
    83b8:	f90023e2 	str	x2, [sp, #64]
    83bc:	b9004bff 	str	wzr, [sp, #72]
    83c0:	f9002be4 	str	x4, [sp, #80]
    83c4:	a90a0f5b 	stp	x27, x3, [x26, #160]
    83c8:	97ffe8ce 	bl	2700 <sigaltstack@plt>
    83cc:	35005a80 	cbnz	w0, 8f1c <fwp_main_thread+0xbdc>
    83d0:	4f000400 	movi	v0.4s, #0x0
    83d4:	910223e0 	add	x0, sp, #0x88
    83d8:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    83dc:	9102c021 	add	x1, x1, #0xb0
    83e0:	f90043e1 	str	x1, [sp, #128]
    83e4:	52800082 	mov	w2, #0x4                   	// #4
    83e8:	72a10002 	movk	w2, #0x800, lsl #16
    83ec:	910203f3 	add	x19, sp, #0x80
    83f0:	3d802000 	str	q0, [x0, #128]
    83f4:	b9010be2 	str	w2, [sp, #264]
    83f8:	ad000000 	stp	q0, q0, [x0]
    83fc:	ad010000 	stp	q0, q0, [x0, #32]
    8400:	ad020000 	stp	q0, q0, [x0, #64]
    8404:	ad030000 	stp	q0, q0, [x0, #96]
    8408:	97ffe916 	bl	2860 <sigemptyset@plt>
    840c:	35005880 	cbnz	w0, 8f1c <fwp_main_thread+0xbdc>
    8410:	aa1303e1 	mov	x1, x19
    8414:	d2800002 	mov	x2, #0x0                   	// #0
    8418:	52800160 	mov	w0, #0xb                   	// #11
    841c:	97ffe929 	bl	28c0 <sigaction@plt>
    8420:	350057e0 	cbnz	w0, 8f1c <fwp_main_thread+0xbdc>
    8424:	aa1303e1 	mov	x1, x19
    8428:	d2800002 	mov	x2, #0x0                   	// #0
    842c:	528000e0 	mov	w0, #0x7                   	// #7
    8430:	97ffe924 	bl	28c0 <sigaction@plt>
    8434:	35005740 	cbnz	w0, 8f1c <fwp_main_thread+0xbdc>
    8438:	911882bc 	add	x28, x21, #0x620
    843c:	52800036 	mov	w22, #0x1                   	// #1
    8440:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    8444:	910ec000 	add	x0, x0, #0x3b0
    8448:	b9013356 	str	w22, [x26, #304]
    844c:	fd4a1380 	ldr	d0, [x28, #5152]
    8450:	7e61d800 	ucvtf	d0, d0
    8454:	fd00a740 	str	d0, [x26, #328]
    8458:	9400047a 	bl	9640 <atexit>
    845c:	35005680 	cbnz	w0, 8f2c <fwp_main_thread+0xbec>
    8460:	b943c740 	ldr	w0, [x26, #964]
    8464:	34002140 	cbz	w0, 888c <fwp_main_thread+0x54c>
    8468:	9101429a 	add	x26, x20, #0x50
    846c:	f9404f56 	ldr	x22, [x26, #152]
    8470:	b4000c36 	cbz	x22, 85f4 <fwp_main_thread+0x2b4>
    8474:	aa1603f3 	mov	x19, x22
    8478:	910102d7 	add	x23, x22, #0x40
    847c:	39414ad9 	ldrb	w25, [x22, #82]
    8480:	52800038 	mov	w24, #0x1                   	// #1
    8484:	39014ad8 	strb	w24, [x22, #82]
    8488:	f94016c0 	ldr	x0, [x22, #40]
    848c:	b4000620 	cbz	x0, 8550 <fwp_main_thread+0x210>
    8490:	f94032c1 	ldr	x1, [x22, #96]
    8494:	394146c0 	ldrb	w0, [x22, #81]
    8498:	b4000c81 	cbz	x1, 8628 <fwp_main_thread+0x2e8>
    849c:	36000b40 	tbz	w0, #0, 8604 <fwp_main_thread+0x2c4>
    84a0:	39414a62 	ldrb	w2, [x19, #82]
    84a4:	f94022c0 	ldr	x0, [x22, #64]
    84a8:	37000ea2 	tbnz	w2, #0, 867c <fwp_main_thread+0x33c>
    84ac:	f9403261 	ldr	x1, [x19, #96]
    84b0:	a911fe77 	stp	x23, xzr, [x19, #280]
    84b4:	f9009660 	str	x0, [x19, #296]
    84b8:	b4000040 	cbz	x0, 84c0 <fwp_main_thread+0x180>
    84bc:	f9009013 	str	x19, [x0, #288]
    84c0:	f90022d3 	str	x19, [x22, #64]
    84c4:	b4000101 	cbz	x1, 84e4 <fwp_main_thread+0x1a4>
    84c8:	f9409740 	ldr	x0, [x26, #296]
    84cc:	39015678 	strb	w24, [x19, #85]
    84d0:	f9003661 	str	x1, [x19, #104]
    84d4:	a910827f 	stp	xzr, x0, [x19, #264]
    84d8:	b4000040 	cbz	x0, 84e0 <fwp_main_thread+0x1a0>
    84dc:	f9008413 	str	x19, [x0, #264]
    84e0:	f9009753 	str	x19, [x26, #296]
    84e4:	39015a7f 	strb	wzr, [x19, #86]
    84e8:	97fff90b 	bl	6914 <fwp_block>
    84ec:	f9408e62 	ldr	x2, [x19, #280]
    84f0:	b4000142 	cbz	x2, 8518 <fwp_main_thread+0x1d8>
    84f4:	a9520261 	ldp	x1, x0, [x19, #288]
    84f8:	b4000ce1 	cbz	x1, 8694 <fwp_main_thread+0x354>
    84fc:	f9009420 	str	x0, [x1, #296]
    8500:	f9409660 	ldr	x0, [x19, #296]
    8504:	b4000040 	cbz	x0, 850c <fwp_main_thread+0x1cc>
    8508:	f9009001 	str	x1, [x0, #288]
    850c:	91080260 	add	x0, x19, #0x200
    8510:	f900967f 	str	xzr, [x19, #296]
    8514:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8518:	39415660 	ldrb	w0, [x19, #85]
    851c:	f9404f42 	ldr	x2, [x26, #152]
    8520:	36000aa0 	tbz	w0, #0, 8674 <fwp_main_thread+0x334>
    8524:	a9508261 	ldp	x1, x0, [x19, #264]
    8528:	b4000ba1 	cbz	x1, 869c <fwp_main_thread+0x35c>
    852c:	f9008820 	str	x0, [x1, #272]
    8530:	b4000040 	cbz	x0, 8538 <fwp_main_thread+0x1f8>
    8534:	f9008401 	str	x1, [x0, #264]
    8538:	91080260 	add	x0, x19, #0x200
    853c:	3901567f 	strb	wzr, [x19, #85]
    8540:	aa0203f3 	mov	x19, x2
    8544:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8548:	f94016c0 	ldr	x0, [x22, #40]
    854c:	b5fffa20 	cbnz	x0, 8490 <fwp_main_thread+0x150>
    8550:	91014280 	add	x0, x20, #0x50
    8554:	39014ad9 	strb	w25, [x22, #82]
    8558:	f941d400 	ldr	x0, [x0, #936]
    855c:	b5000080 	cbnz	x0, 856c <fwp_main_thread+0x22c>
    8560:	91014296 	add	x22, x20, #0x50
    8564:	f941dec0 	ldr	x0, [x22, #952]
    8568:	b40046a0 	cbz	x0, 8e3c <fwp_main_thread+0xafc>
    856c:	91014280 	add	x0, x20, #0x50
    8570:	f941ec01 	ldr	x1, [x0, #984]
    8574:	b903d01f 	str	wzr, [x0, #976]
    8578:	eb13003f 	cmp	x1, x19
    857c:	54004761 	b.ne	8e68 <fwp_main_thread+0xb28>  // b.any
    8580:	b40009d3 	cbz	x19, 86b8 <fwp_main_thread+0x378>
    8584:	91014280 	add	x0, x20, #0x50
    8588:	52800021 	mov	w1, #0x1                   	// #1
    858c:	39014a61 	strb	w1, [x19, #82]
    8590:	f941c005 	ldr	x5, [x0, #896]
    8594:	b4000925 	cbz	x5, 86b8 <fwp_main_thread+0x378>
    8598:	394140a0 	ldrb	w0, [x5, #80]
    859c:	37000060 	tbnz	w0, #0, 85a8 <fwp_main_thread+0x268>
    85a0:	aa0503e0 	mov	x0, x5
    85a4:	97ffec53 	bl	36f0 <fwp_cancel_tree.part.0>
    85a8:	f9409ca5 	ldr	x5, [x5, #312]
    85ac:	b5ffff65 	cbnz	x5, 8598 <fwp_main_thread+0x258>
    85b0:	91014296 	add	x22, x20, #0x50
    85b4:	52800037 	mov	w23, #0x1                   	// #1
    85b8:	f9402a60 	ldr	x0, [x19, #80]
    85bc:	f2001c1f 	tst	x0, #0xff000000ff
    85c0:	540000e1 	b.ne	85dc <fwp_main_thread+0x29c>  // b.any
    85c4:	f94062c0 	ldr	x0, [x22, #192]
    85c8:	39015277 	strb	w23, [x19, #84]
    85cc:	f900827f 	str	xzr, [x19, #256]
    85d0:	b40006a0 	cbz	x0, 86a4 <fwp_main_thread+0x364>
    85d4:	f9008013 	str	x19, [x0, #256]
    85d8:	f90062d3 	str	x19, [x22, #192]
    85dc:	97fff8ce 	bl	6914 <fwp_block>
    85e0:	97fff860 	bl	6760 <fwp_free_zombie>
    85e4:	f941c2c0 	ldr	x0, [x22, #896]
    85e8:	b4000680 	cbz	x0, 86b8 <fwp_main_thread+0x378>
    85ec:	f941eed3 	ldr	x19, [x22, #984]
    85f0:	17fffff2 	b	85b8 <fwp_main_thread+0x278>
    85f4:	f941d740 	ldr	x0, [x26, #936]
    85f8:	b50005a0 	cbnz	x0, 86ac <fwp_main_thread+0x36c>
    85fc:	d2800013 	mov	x19, #0x0                   	// #0
    8600:	17ffffd8 	b	8560 <fwp_main_thread+0x220>
    8604:	97ffecdf 	bl	3980 <fwp_now_ns>
    8608:	f94032c1 	ldr	x1, [x22, #96]
    860c:	eb01001f 	cmp	x0, x1
    8610:	540000ab 	b.lt	8624 <fwp_main_thread+0x2e4>  // b.tstop
    8614:	394142c0 	ldrb	w0, [x22, #80]
    8618:	37000060 	tbnz	w0, #0, 8624 <fwp_main_thread+0x2e4>
    861c:	aa1603e0 	mov	x0, x22
    8620:	97ffec34 	bl	36f0 <fwp_cancel_tree.part.0>
    8624:	394146c0 	ldrb	w0, [x22, #81]
    8628:	39414a62 	ldrb	w2, [x19, #82]
    862c:	3707f3c0 	tbnz	w0, #0, 84a4 <fwp_main_thread+0x164>
    8630:	f94032c1 	ldr	x1, [x22, #96]
    8634:	370001c2 	tbnz	w2, #0, 866c <fwp_main_thread+0x32c>
    8638:	f9403260 	ldr	x0, [x19, #96]
    863c:	b4000180 	cbz	x0, 866c <fwp_main_thread+0x32c>
    8640:	b4000061 	cbz	x1, 864c <fwp_main_thread+0x30c>
    8644:	eb01001f 	cmp	x0, x1
    8648:	9a81d000 	csel	x0, x0, x1, le
    864c:	f94022c1 	ldr	x1, [x22, #64]
    8650:	a911fe77 	stp	x23, xzr, [x19, #280]
    8654:	f9009661 	str	x1, [x19, #296]
    8658:	b4003ec1 	cbz	x1, 8e30 <fwp_main_thread+0xaf0>
    865c:	f9009033 	str	x19, [x1, #288]
    8660:	aa0003e1 	mov	x1, x0
    8664:	f90022d3 	str	x19, [x22, #64]
    8668:	17ffff98 	b	84c8 <fwp_main_thread+0x188>
    866c:	f94022c0 	ldr	x0, [x22, #64]
    8670:	17ffff90 	b	84b0 <fwp_main_thread+0x170>
    8674:	aa0203f3 	mov	x19, x2
    8678:	17ffff84 	b	8488 <fwp_main_thread+0x148>
    867c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8680:	f9009660 	str	x0, [x19, #296]
    8684:	b4000040 	cbz	x0, 868c <fwp_main_thread+0x34c>
    8688:	f9009013 	str	x19, [x0, #288]
    868c:	f90022d3 	str	x19, [x22, #64]
    8690:	17ffff95 	b	84e4 <fwp_main_thread+0x1a4>
    8694:	f9000040 	str	x0, [x2]
    8698:	17ffff9b 	b	8504 <fwp_main_thread+0x1c4>
    869c:	f9009740 	str	x0, [x26, #296]
    86a0:	17ffffa4 	b	8530 <fwp_main_thread+0x1f0>
    86a4:	f90066d3 	str	x19, [x22, #200]
    86a8:	17ffffcc 	b	85d8 <fwp_main_thread+0x298>
    86ac:	f941ef40 	ldr	x0, [x26, #984]
    86b0:	b903d35f 	str	wzr, [x26, #976]
    86b4:	b5003da0 	cbnz	x0, 8e68 <fwp_main_thread+0xb28>
    86b8:	91014296 	add	x22, x20, #0x50
    86bc:	97fff829 	bl	6760 <fwp_free_zombie>
    86c0:	f94066c0 	ldr	x0, [x22, #200]
    86c4:	b5003d20 	cbnz	x0, 8e68 <fwp_main_thread+0xb28>
    86c8:	f94096c0 	ldr	x0, [x22, #296]
    86cc:	b5003ce0 	cbnz	x0, 8e68 <fwp_main_thread+0xb28>
    86d0:	b94172c0 	ldr	w0, [x22, #368]
    86d4:	340001c0 	cbz	w0, 870c <fwp_main_thread+0x3cc>
    86d8:	93407c17 	sxtw	x23, w0
    86dc:	51000400 	sub	w0, w0, #0x1
    86e0:	d1000af7 	sub	x23, x23, #0x2
    86e4:	910602d8 	add	x24, x22, #0x180
    86e8:	cb2042f7 	sub	x23, x23, w0, uxtw
    86ec:	93407c13 	sxtw	x19, w0
    86f0:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    86f4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    86f8:	b90172d3 	str	w19, [x22, #368]
    86fc:	d1000673 	sub	x19, x19, #0x1
    8700:	97ffe8b0 	bl	29c0 <munmap@plt>
    8704:	eb1302ff 	cmp	x23, x19
    8708:	54ffff41 	b.ne	86f0 <fwp_main_thread+0x3b0>  // b.any
    870c:	900000d3 	adrp	x19, 20000 <__data_start>
    8710:	91004260 	add	x0, x19, #0x10
    8714:	b9402000 	ldr	w0, [x0, #32]
    8718:	37f80040 	tbnz	w0, #31, 8720 <fwp_main_thread+0x3e0>
    871c:	97ffe865 	bl	28b0 <close@plt>
    8720:	91014280 	add	x0, x20, #0x50
    8724:	91004261 	add	x1, x19, #0x10
    8728:	12800002 	mov	w2, #0xffffffff            	// #-1
    872c:	d2800013 	mov	x19, #0x0                   	// #0
    8730:	f941f017 	ldr	x23, [x0, #992]
    8734:	b9002022 	str	w2, [x1, #32]
    8738:	f941f416 	ldr	x22, [x0, #1000]
    873c:	b4000177 	cbz	x23, 8768 <fwp_main_thread+0x428>
    8740:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    8744:	b40000c0 	cbz	x0, 875c <fwp_main_thread+0x41c>
    8748:	f9400001 	ldr	x1, [x0]
    874c:	b50038e1 	cbnz	x1, 8e68 <fwp_main_thread+0xb28>
    8750:	f9400401 	ldr	x1, [x0, #8]
    8754:	b50038a1 	cbnz	x1, 8e68 <fwp_main_thread+0xb28>
    8758:	97fff14e 	bl	4c90 <fwp_mem_free>
    875c:	91000673 	add	x19, x19, #0x1
    8760:	eb17027f 	cmp	x19, x23
    8764:	54fffee1 	b.ne	8740 <fwp_main_thread+0x400>  // b.any
    8768:	aa1603e0 	mov	x0, x22
    876c:	97fff149 	bl	4c90 <fwp_mem_free>
    8770:	91014280 	add	x0, x20, #0x50
    8774:	f941ec13 	ldr	x19, [x0, #984]
    8778:	f901f01f 	str	xzr, [x0, #992]
    877c:	f901f41f 	str	xzr, [x0, #1000]
    8780:	b40001f3 	cbz	x19, 87bc <fwp_main_thread+0x47c>
    8784:	f9401661 	ldr	x1, [x19, #40]
    8788:	b5003701 	cbnz	x1, 8e68 <fwp_main_thread+0xb28>
    878c:	f9405661 	ldr	x1, [x19, #168]
    8790:	b50036c1 	cbnz	x1, 8e68 <fwp_main_thread+0xb28>
    8794:	f941d401 	ldr	x1, [x0, #936]
    8798:	b5003681 	cbnz	x1, 8e68 <fwp_main_thread+0xb28>
    879c:	f941dc00 	ldr	x0, [x0, #952]
    87a0:	b5003640 	cbnz	x0, 8e68 <fwp_main_thread+0xb28>
    87a4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    87a8:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bc0>
    87ac:	91110000 	add	x0, x0, #0x440
    87b0:	97ffe830 	bl	2870 <memset@plt>
    87b4:	aa1303e0 	mov	x0, x19
    87b8:	97fff136 	bl	4c90 <fwp_mem_free>
    87bc:	91014286 	add	x6, x20, #0x50
    87c0:	911882b5 	add	x21, x21, #0x620
    87c4:	3dc01682 	ldr	q2, [x20, #80]
    87c8:	52800041 	mov	w1, #0x2                   	// #2
    87cc:	3dc004c1 	ldr	q1, [x6, #16]
    87d0:	b0000002 	adrp	x2, 9000 <__divti3+0xb0>
    87d4:	fd4a12a0 	ldr	d0, [x21, #5152]
    87d8:	91374042 	add	x2, x2, #0xdd0
    87dc:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    87e0:	fd40a4c1 	ldr	d1, [x6, #328]
    87e4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    87e8:	f947e800 	ldr	x0, [x0, #4048]
    87ec:	7e61d800 	ucvtf	d0, d0
    87f0:	a95390c3 	ldp	x3, x4, [x6, #312]
    87f4:	f9004cdf 	str	xzr, [x6, #152]
    87f8:	f9400000 	ldr	x0, [x0]
    87fc:	1e613801 	fsub	d1, d0, d1
    8800:	f940acc5 	ldr	x5, [x6, #344]
    8804:	b90130df 	str	wzr, [x6, #304]
    8808:	5ef1b842 	addp	d2, v2.2d
    880c:	fd40a8c0 	ldr	d0, [x6, #336]
    8810:	f901ecdf 	str	xzr, [x6, #984]
    8814:	fd0058c2 	str	d2, [x6, #176]
    8818:	97ffe83e 	bl	2910 <__fprintf_chk@plt>
    881c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8820:	f947ec00 	ldr	x0, [x0, #4056]
    8824:	f9400000 	ldr	x0, [x0]
    8828:	97ffe86a 	bl	29d0 <fflush@plt>
    882c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8830:	f947f400 	ldr	x0, [x0, #4072]
    8834:	f9408fe2 	ldr	x2, [sp, #280]
    8838:	f9400001 	ldr	x1, [x0]
    883c:	eb010042 	subs	x2, x2, x1
    8840:	d2800001 	mov	x1, #0x0                   	// #0
    8844:	54003721 	b.ne	8f28 <fwp_main_thread+0xbe8>  // b.any
    8848:	a9527bfd 	ldp	x29, x30, [sp, #288]
    884c:	d2800000 	mov	x0, #0x0                   	// #0
    8850:	a95353f3 	ldp	x19, x20, [sp, #304]
    8854:	a9545bf5 	ldp	x21, x22, [sp, #320]
    8858:	a95563f7 	ldp	x23, x24, [sp, #336]
    885c:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8860:	a95773fb 	ldp	x27, x28, [sp, #368]
    8864:	910603ff 	add	sp, sp, #0x180
    8868:	d65f03c0 	ret
    886c:	97ffee26 	bl	4104 <fwp_heap_init>
    8870:	911882a0 	add	x0, x21, #0x620
    8874:	b953a800 	ldr	w0, [x0, #5032]
    8878:	34ffd8c0 	cbz	w0, 8390 <fwp_main_thread+0x50>
    887c:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    8880:	913e8000 	add	x0, x0, #0xfa0
    8884:	9400036f 	bl	9640 <atexit>
    8888:	17fffec2 	b	8390 <fwp_main_thread+0x50>
    888c:	f941cb42 	ldr	x2, [x26, #912]
    8890:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0x50>
    8894:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8898:	91378000 	add	x0, x0, #0xde0
    889c:	913d4021 	add	x1, x1, #0xf50
    88a0:	d2800018 	mov	x24, #0x0                   	// #0
    88a4:	d2900019 	mov	x25, #0x8000                	// #32768
    88a8:	390023f6 	strb	w22, [sp, #8]
    88ac:	d2800016 	mov	x22, #0x0                   	// #0
    88b0:	a90287e2 	stp	x2, x1, [sp, #40]
    88b4:	a903fff7 	stp	x23, xzr, [sp, #56]
    88b8:	a90503ff 	stp	xzr, x0, [sp, #80]
    88bc:	f901cb5b 	str	x27, [x26, #912]
    88c0:	14000012 	b	8908 <fwp_main_thread+0x5c8>
    88c4:	7100045f 	cmp	w2, #0x1
    88c8:	540001a1 	b.ne	88fc <fwp_main_thread+0x5bc>  // b.any
    88cc:	29430865 	ldp	w5, w2, [x3, #24]
    88d0:	92403c21 	and	x1, x1, #0xffff
    88d4:	9b057c21 	mul	x1, x1, x5
    88d8:	d360fc21 	lsr	x1, x1, #32
    88dc:	eb02003f 	cmp	x1, x2
    88e0:	540000e2 	b.cs	88fc <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    88e4:	8b010000 	add	x0, x0, x1
    88e8:	39400001 	ldrb	w1, [x0]
    88ec:	7103fc3f 	cmp	w1, #0xff
    88f0:	54002980 	b.eq	8e20 <fwp_main_thread+0xae0>  // b.none
    88f4:	394023e1 	ldrb	w1, [sp, #8]
    88f8:	39000001 	strb	w1, [x0]
    88fc:	f90023f8 	str	x24, [sp, #64]
    8900:	aa1b035a 	orr	x26, x26, x27
    8904:	b40003fa 	cbz	x26, 8980 <fwp_main_thread+0x640>
    8908:	f100073a 	subs	x26, x25, #0x1
    890c:	aa1303e1 	mov	x1, x19
    8910:	da1f02db 	sbc	x27, x22, xzr
    8914:	52800020 	mov	w0, #0x1                   	// #1
    8918:	f90027fa 	str	x26, [sp, #72]
    891c:	aa1a03f9 	mov	x25, x26
    8920:	a90863fa 	stp	x26, x24, [sp, #128]
    8924:	97fff25c 	bl	5294 <fwp_data.part.0.constprop.0>
    8928:	aa0003f8 	mov	x24, x0
    892c:	f949db81 	ldr	x1, [x28, #5040]
    8930:	aa1b03f6 	mov	x22, x27
    8934:	f949ef80 	ldr	x0, [x28, #5080]
    8938:	cb010301 	sub	x1, x24, x1
    893c:	eb00403f 	cmp	x1, x0, lsl #16
    8940:	54fffde2 	b.cs	88fc <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    8944:	d350fc22 	lsr	x2, x1, #16
    8948:	f949ff85 	ldr	x5, [x28, #5112]
    894c:	8b020842 	add	x2, x2, x2, lsl #2
    8950:	d37df042 	lsl	x2, x2, #3
    8954:	8b0200a3 	add	x3, x5, x2
    8958:	f9401060 	ldr	x0, [x3, #32]
    895c:	b4fffd00 	cbz	x0, 88fc <fwp_main_thread+0x5bc>
    8960:	386268a2 	ldrb	w2, [x5, x2]
    8964:	7100085f 	cmp	w2, #0x2
    8968:	54fffae1 	b.ne	88c4 <fwp_main_thread+0x584>  // b.any
    896c:	72003c3f 	tst	w1, #0xffff
    8970:	54fffbc0 	b.eq	88e8 <fwp_main_thread+0x5a8>  // b.none
    8974:	f90023f8 	str	x24, [sp, #64]
    8978:	aa1b035a 	orr	x26, x26, x27
    897c:	b5fffc7a 	cbnz	x26, 8908 <fwp_main_thread+0x5c8>
    8980:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x990>
    8984:	91014282 	add	x2, x20, #0x50
    8988:	f94017e3 	ldr	x3, [sp, #40]
    898c:	910183e1 	add	x1, sp, #0x60
    8990:	3dc15c00 	ldr	q0, [x0, #1392]
    8994:	52800020 	mov	w0, #0x1                   	// #1
    8998:	f901c843 	str	x3, [x2, #912]
    899c:	3d801be0 	str	q0, [sp, #96]
    89a0:	97fff23d 	bl	5294 <fwp_data.part.0.constprop.0>
    89a4:	911882a1 	add	x1, x21, #0x620
    89a8:	aa0003f6 	mov	x22, x0
    89ac:	f949d822 	ldr	x2, [x1, #5040]
    89b0:	f949ec20 	ldr	x0, [x1, #5080]
    89b4:	cb0202c2 	sub	x2, x22, x2
    89b8:	eb00405f 	cmp	x2, x0, lsl #16
    89bc:	54000322 	b.cs	8a20 <fwp_main_thread+0x6e0>  // b.hs, b.nlast
    89c0:	d350fc40 	lsr	x0, x2, #16
    89c4:	f949fc23 	ldr	x3, [x1, #5112]
    89c8:	8b000800 	add	x0, x0, x0, lsl #2
    89cc:	d37df001 	lsl	x1, x0, #3
    89d0:	8b010060 	add	x0, x3, x1
    89d4:	f9401019 	ldr	x25, [x0, #32]
    89d8:	b4000259 	cbz	x25, 8a20 <fwp_main_thread+0x6e0>
    89dc:	38616861 	ldrb	w1, [x3, x1]
    89e0:	7100083f 	cmp	w1, #0x2
    89e4:	54002080 	b.eq	8df4 <fwp_main_thread+0xab4>  // b.none
    89e8:	7100043f 	cmp	w1, #0x1
    89ec:	540001a1 	b.ne	8a20 <fwp_main_thread+0x6e0>  // b.any
    89f0:	29430003 	ldp	w3, w0, [x0, #24]
    89f4:	92403c41 	and	x1, x2, #0xffff
    89f8:	9b037c21 	mul	x1, x1, x3
    89fc:	d360fc21 	lsr	x1, x1, #32
    8a00:	eb00003f 	cmp	x1, x0
    8a04:	540000e2 	b.cs	8a20 <fwp_main_thread+0x6e0>  // b.hs, b.nlast
    8a08:	8b010339 	add	x25, x25, x1
    8a0c:	39400320 	ldrb	w0, [x25]
    8a10:	7103fc1f 	cmp	w0, #0xff
    8a14:	540023e0 	b.eq	8e90 <fwp_main_thread+0xb50>  // b.none
    8a18:	52800020 	mov	w0, #0x1                   	// #1
    8a1c:	39000320 	strb	w0, [x25]
    8a20:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8a24:	aa1303e1 	mov	x1, x19
    8a28:	52800020 	mov	w0, #0x1                   	// #1
    8a2c:	a9085be2 	stp	x2, x22, [sp, #128]
    8a30:	97fff219 	bl	5294 <fwp_data.part.0.constprop.0>
    8a34:	911882a1 	add	x1, x21, #0x620
    8a38:	aa0003f3 	mov	x19, x0
    8a3c:	f949d822 	ldr	x2, [x1, #5040]
    8a40:	f949ec20 	ldr	x0, [x1, #5080]
    8a44:	cb020262 	sub	x2, x19, x2
    8a48:	eb00405f 	cmp	x2, x0, lsl #16
    8a4c:	54000322 	b.cs	8ab0 <fwp_main_thread+0x770>  // b.hs, b.nlast
    8a50:	d350fc40 	lsr	x0, x2, #16
    8a54:	f949fc23 	ldr	x3, [x1, #5112]
    8a58:	8b000800 	add	x0, x0, x0, lsl #2
    8a5c:	d37df001 	lsl	x1, x0, #3
    8a60:	8b010060 	add	x0, x3, x1
    8a64:	f9401016 	ldr	x22, [x0, #32]
    8a68:	b4000256 	cbz	x22, 8ab0 <fwp_main_thread+0x770>
    8a6c:	38616861 	ldrb	w1, [x3, x1]
    8a70:	7100083f 	cmp	w1, #0x2
    8a74:	54001b40 	b.eq	8ddc <fwp_main_thread+0xa9c>  // b.none
    8a78:	7100043f 	cmp	w1, #0x1
    8a7c:	540001a1 	b.ne	8ab0 <fwp_main_thread+0x770>  // b.any
    8a80:	29430003 	ldp	w3, w0, [x0, #24]
    8a84:	92403c41 	and	x1, x2, #0xffff
    8a88:	9b037c21 	mul	x1, x1, x3
    8a8c:	d360fc21 	lsr	x1, x1, #32
    8a90:	eb00003f 	cmp	x1, x0
    8a94:	540000e2 	b.cs	8ab0 <fwp_main_thread+0x770>  // b.hs, b.nlast
    8a98:	8b0102d6 	add	x22, x22, x1
    8a9c:	394002c0 	ldrb	w0, [x22]
    8aa0:	7103fc1f 	cmp	w0, #0xff
    8aa4:	54001fc0 	b.eq	8e9c <fwp_main_thread+0xb5c>  // b.none
    8aa8:	52800020 	mov	w0, #0x1                   	// #1
    8aac:	390002c0 	strb	w0, [x22]
    8ab0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8ab4:	9101c3e1 	add	x1, sp, #0x70
    8ab8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8abc:	52800020 	mov	w0, #0x1                   	// #1
    8ac0:	a9074fe2 	stp	x2, x19, [sp, #112]
    8ac4:	97fff1f4 	bl	5294 <fwp_data.part.0.constprop.0>
    8ac8:	911882a1 	add	x1, x21, #0x620
    8acc:	aa0003f3 	mov	x19, x0
    8ad0:	f949d822 	ldr	x2, [x1, #5040]
    8ad4:	f949ec20 	ldr	x0, [x1, #5080]
    8ad8:	cb020262 	sub	x2, x19, x2
    8adc:	eb00405f 	cmp	x2, x0, lsl #16
    8ae0:	54000322 	b.cs	8b44 <fwp_main_thread+0x804>  // b.hs, b.nlast
    8ae4:	d350fc40 	lsr	x0, x2, #16
    8ae8:	f949fc23 	ldr	x3, [x1, #5112]
    8aec:	8b000800 	add	x0, x0, x0, lsl #2
    8af0:	d37df001 	lsl	x1, x0, #3
    8af4:	8b010060 	add	x0, x3, x1
    8af8:	f9401016 	ldr	x22, [x0, #32]
    8afc:	b4000256 	cbz	x22, 8b44 <fwp_main_thread+0x804>
    8b00:	38616861 	ldrb	w1, [x3, x1]
    8b04:	7100083f 	cmp	w1, #0x2
    8b08:	54001700 	b.eq	8de8 <fwp_main_thread+0xaa8>  // b.none
    8b0c:	7100043f 	cmp	w1, #0x1
    8b10:	540001a1 	b.ne	8b44 <fwp_main_thread+0x804>  // b.any
    8b14:	29430003 	ldp	w3, w0, [x0, #24]
    8b18:	92403c41 	and	x1, x2, #0xffff
    8b1c:	9b037c21 	mul	x1, x1, x3
    8b20:	d360fc21 	lsr	x1, x1, #32
    8b24:	eb00003f 	cmp	x1, x0
    8b28:	540000e2 	b.cs	8b44 <fwp_main_thread+0x804>  // b.hs, b.nlast
    8b2c:	8b0102d6 	add	x22, x22, x1
    8b30:	394002c0 	ldrb	w0, [x22]
    8b34:	7103fc1f 	cmp	w0, #0xff
    8b38:	54001b80 	b.eq	8ea8 <fwp_main_thread+0xb68>  // b.none
    8b3c:	52800020 	mov	w0, #0x1                   	// #1
    8b40:	390002c0 	strb	w0, [x22]
    8b44:	aa1803f9 	mov	x25, x24
    8b48:	d00000b6 	adrp	x22, 1e000 <__FRAME_END__+0x127c8>
    8b4c:	b40011f8 	cbz	x24, 8d88 <fwp_main_thread+0xa48>
    8b50:	910ac2d6 	add	x22, x22, #0x2b0
    8b54:	911882bb 	add	x27, x21, #0x620
    8b58:	910142c0 	add	x0, x22, #0x50
    8b5c:	b000001a 	adrp	x26, 9000 <__divti3+0xb0>
    8b60:	f90007e0 	str	x0, [sp, #8]
    8b64:	911ac340 	add	x0, x26, #0x6b0
    8b68:	f9000be0 	str	x0, [sp, #16]
    8b6c:	f949db61 	ldr	x1, [x27, #5040]
    8b70:	f949ef60 	ldr	x0, [x27, #5080]
    8b74:	cb010261 	sub	x1, x19, x1
    8b78:	eb00403f 	cmp	x1, x0, lsl #16
    8b7c:	540003a2 	b.cs	8bf0 <fwp_main_thread+0x8b0>  // b.hs, b.nlast
    8b80:	d350fc20 	lsr	x0, x1, #16
    8b84:	f949ff65 	ldr	x5, [x27, #5112]
    8b88:	8b000800 	add	x0, x0, x0, lsl #2
    8b8c:	d37df002 	lsl	x2, x0, #3
    8b90:	8b0200a3 	add	x3, x5, x2
    8b94:	f9401060 	ldr	x0, [x3, #32]
    8b98:	b40002c0 	cbz	x0, 8bf0 <fwp_main_thread+0x8b0>
    8b9c:	386268a2 	ldrb	w2, [x5, x2]
    8ba0:	7100085f 	cmp	w2, #0x2
    8ba4:	540010e0 	b.eq	8dc0 <fwp_main_thread+0xa80>  // b.none
    8ba8:	7100045f 	cmp	w2, #0x1
    8bac:	54000221 	b.ne	8bf0 <fwp_main_thread+0x8b0>  // b.any
    8bb0:	29430865 	ldp	w5, w2, [x3, #24]
    8bb4:	92403c21 	and	x1, x1, #0xffff
    8bb8:	9b057c21 	mul	x1, x1, x5
    8bbc:	d360fc21 	lsr	x1, x1, #32
    8bc0:	eb02003f 	cmp	x1, x2
    8bc4:	54000162 	b.cs	8bf0 <fwp_main_thread+0x8b0>  // b.hs, b.nlast
    8bc8:	8b010000 	add	x0, x0, x1
    8bcc:	39400001 	ldrb	w1, [x0]
    8bd0:	34000101 	cbz	w1, 8bf0 <fwp_main_thread+0x8b0>
    8bd4:	91014282 	add	x2, x20, #0x50
    8bd8:	b9413043 	ldr	w3, [x2, #304]
    8bdc:	35000f83 	cbnz	w3, 8dcc <fwp_main_thread+0xa8c>
    8be0:	7103f43f 	cmp	w1, #0xfd
    8be4:	54001528 	b.hi	8e88 <fwp_main_thread+0xb48>  // b.pmore
    8be8:	11000421 	add	w1, w1, #0x1
    8bec:	39000001 	strb	w1, [x0]
    8bf0:	f94007e2 	ldr	x2, [sp, #8]
    8bf4:	aa1703e0 	mov	x0, x23
    8bf8:	aa1303e1 	mov	x1, x19
    8bfc:	52800023 	mov	w3, #0x1                   	// #1
    8c00:	a9047fff 	stp	xzr, xzr, [sp, #64]
    8c04:	f9002bff 	str	xzr, [sp, #80]
    8c08:	97fff9d3 	bl	7354 <fwp_write>
    8c0c:	a9446bf6 	ldp	x22, x26, [sp, #64]
    8c10:	f9400be0 	ldr	x0, [sp, #16]
    8c14:	f10002df 	cmp	x22, #0x0
    8c18:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    8c1c:	b1002b5f 	cmn	x26, #0xa
    8c20:	540018c8 	b.hi	8f38 <fwp_main_thread+0xbf8>  // b.pmore
    8c24:	52800021 	mov	w1, #0x1                   	// #1
    8c28:	91002740 	add	x0, x26, #0x9
    8c2c:	97fff139 	bl	5110 <fwp_heap_alloc>
    8c30:	aa0003fc 	mov	x28, x0
    8c34:	aa1603e1 	mov	x1, x22
    8c38:	aa0003f6 	mov	x22, x0
    8c3c:	aa1a03e2 	mov	x2, x26
    8c40:	f80086da 	str	x26, [x22], #8
    8c44:	aa1603e0 	mov	x0, x22
    8c48:	97ffe6aa 	bl	26f0 <memcpy@plt>
    8c4c:	8b1a0382 	add	x2, x28, x26
    8c50:	3900205f 	strb	wzr, [x2, #8]
    8c54:	f94023e0 	ldr	x0, [sp, #64]
    8c58:	97ffe742 	bl	2960 <free@plt>
    8c5c:	f949db62 	ldr	x2, [x27, #5040]
    8c60:	f949ef60 	ldr	x0, [x27, #5080]
    8c64:	cb020382 	sub	x2, x28, x2
    8c68:	eb00405f 	cmp	x2, x0, lsl #16
    8c6c:	54000322 	b.cs	8cd0 <fwp_main_thread+0x990>  // b.hs, b.nlast
    8c70:	d350fc40 	lsr	x0, x2, #16
    8c74:	f949ff66 	ldr	x6, [x27, #5112]
    8c78:	8b000800 	add	x0, x0, x0, lsl #2
    8c7c:	d37df001 	lsl	x1, x0, #3
    8c80:	8b0100c5 	add	x5, x6, x1
    8c84:	f94010a0 	ldr	x0, [x5, #32]
    8c88:	b4000240 	cbz	x0, 8cd0 <fwp_main_thread+0x990>
    8c8c:	386168c1 	ldrb	w1, [x6, x1]
    8c90:	7100083f 	cmp	w1, #0x2
    8c94:	54000c00 	b.eq	8e14 <fwp_main_thread+0xad4>  // b.none
    8c98:	7100043f 	cmp	w1, #0x1
    8c9c:	540001a1 	b.ne	8cd0 <fwp_main_thread+0x990>  // b.any
    8ca0:	92403c41 	and	x1, x2, #0xffff
    8ca4:	294308a6 	ldp	w6, w2, [x5, #24]
    8ca8:	9b067c21 	mul	x1, x1, x6
    8cac:	d360fc21 	lsr	x1, x1, #32
    8cb0:	eb02003f 	cmp	x1, x2
    8cb4:	540000e2 	b.cs	8cd0 <fwp_main_thread+0x990>  // b.hs, b.nlast
    8cb8:	8b010000 	add	x0, x0, x1
    8cbc:	39400001 	ldrb	w1, [x0]
    8cc0:	7103fc3f 	cmp	w1, #0xff
    8cc4:	54000d40 	b.eq	8e6c <fwp_main_thread+0xb2c>  // b.none
    8cc8:	52800021 	mov	w1, #0x1                   	// #1
    8ccc:	39000001 	strb	w1, [x0]
    8cd0:	aa1303e0 	mov	x0, x19
    8cd4:	97fff3ef 	bl	5c90 <fwp_drop0>
    8cd8:	91014285 	add	x5, x20, #0x50
    8cdc:	aa1603e0 	mov	x0, x22
    8ce0:	f9400382 	ldr	x2, [x28]
    8ce4:	aa0503f6 	mov	x22, x5
    8ce8:	f94048a3 	ldr	x3, [x5, #144]
    8cec:	d2800021 	mov	x1, #0x1                   	// #1
    8cf0:	97ffe72c 	bl	29a0 <fwrite@plt>
    8cf4:	f9404ac1 	ldr	x1, [x22, #144]
    8cf8:	52800140 	mov	w0, #0xa                   	// #10
    8cfc:	97ffe6b1 	bl	27c0 <fputc@plt>
    8d00:	f949db62 	ldr	x2, [x27, #5040]
    8d04:	f949ef60 	ldr	x0, [x27, #5080]
    8d08:	cb020382 	sub	x2, x28, x2
    8d0c:	eb00405f 	cmp	x2, x0, lsl #16
    8d10:	54000382 	b.cs	8d80 <fwp_main_thread+0xa40>  // b.hs, b.nlast
    8d14:	d350fc40 	lsr	x0, x2, #16
    8d18:	f949ff65 	ldr	x5, [x27, #5112]
    8d1c:	8b000800 	add	x0, x0, x0, lsl #2
    8d20:	d37df001 	lsl	x1, x0, #3
    8d24:	8b0100a3 	add	x3, x5, x1
    8d28:	f9401060 	ldr	x0, [x3, #32]
    8d2c:	b40002a0 	cbz	x0, 8d80 <fwp_main_thread+0xa40>
    8d30:	386168a1 	ldrb	w1, [x5, x1]
    8d34:	7100083f 	cmp	w1, #0x2
    8d38:	54000640 	b.eq	8e00 <fwp_main_thread+0xac0>  // b.none
    8d3c:	7100043f 	cmp	w1, #0x1
    8d40:	54000201 	b.ne	8d80 <fwp_main_thread+0xa40>  // b.any
    8d44:	92403c41 	and	x1, x2, #0xffff
    8d48:	29430865 	ldp	w5, w2, [x3, #24]
    8d4c:	9b057c21 	mul	x1, x1, x5
    8d50:	d360fc21 	lsr	x1, x1, #32
    8d54:	eb02003f 	cmp	x1, x2
    8d58:	54000142 	b.cs	8d80 <fwp_main_thread+0xa40>  // b.hs, b.nlast
    8d5c:	8b010000 	add	x0, x0, x1
    8d60:	39400001 	ldrb	w1, [x0]
    8d64:	340000e1 	cbz	w1, 8d80 <fwp_main_thread+0xa40>
    8d68:	7100043f 	cmp	w1, #0x1
    8d6c:	54000200 	b.eq	8dac <fwp_main_thread+0xa6c>  // b.none
    8d70:	7103fc3f 	cmp	w1, #0xff
    8d74:	54000a00 	b.eq	8eb4 <fwp_main_thread+0xb74>  // b.none
    8d78:	51000421 	sub	w1, w1, #0x1
    8d7c:	39000001 	strb	w1, [x0]
    8d80:	f9400b39 	ldr	x25, [x25, #16]
    8d84:	b5ffef59 	cbnz	x25, 8b6c <fwp_main_thread+0x82c>
    8d88:	aa1303e0 	mov	x0, x19
    8d8c:	97fff3c1 	bl	5c90 <fwp_drop0>
    8d90:	aa1803e0 	mov	x0, x24
    8d94:	97fff3bf 	bl	5c90 <fwp_drop0>
    8d98:	91014280 	add	x0, x20, #0x50
    8d9c:	52800021 	mov	w1, #0x1                   	// #1
    8da0:	b903c401 	str	w1, [x0, #964]
    8da4:	f901e41f 	str	xzr, [x0, #968]
    8da8:	17fffdb0 	b	8468 <fwp_main_thread+0x128>
    8dac:	aa1c03e0 	mov	x0, x28
    8db0:	97fff2d9 	bl	5914 <fwp_rc_free_arr>
    8db4:	f9400b39 	ldr	x25, [x25, #16]
    8db8:	b5ffedb9 	cbnz	x25, 8b6c <fwp_main_thread+0x82c>
    8dbc:	17fffff3 	b	8d88 <fwp_main_thread+0xa48>
    8dc0:	72003c3f 	tst	w1, #0xffff
    8dc4:	54fff161 	b.ne	8bf0 <fwp_main_thread+0x8b0>  // b.any
    8dc8:	17ffff81 	b	8bcc <fwp_main_thread+0x88c>
    8dcc:	f940ac43 	ldr	x3, [x2, #344]
    8dd0:	91000463 	add	x3, x3, #0x1
    8dd4:	f900ac43 	str	x3, [x2, #344]
    8dd8:	17ffff82 	b	8be0 <fwp_main_thread+0x8a0>
    8ddc:	72003c5f 	tst	w2, #0xffff
    8de0:	54ffe681 	b.ne	8ab0 <fwp_main_thread+0x770>  // b.any
    8de4:	17ffff2e 	b	8a9c <fwp_main_thread+0x75c>
    8de8:	72003c5f 	tst	w2, #0xffff
    8dec:	54ffeac1 	b.ne	8b44 <fwp_main_thread+0x804>  // b.any
    8df0:	17ffff50 	b	8b30 <fwp_main_thread+0x7f0>
    8df4:	72003c5f 	tst	w2, #0xffff
    8df8:	54ffe141 	b.ne	8a20 <fwp_main_thread+0x6e0>  // b.any
    8dfc:	17ffff04 	b	8a0c <fwp_main_thread+0x6cc>
    8e00:	72003c5f 	tst	w2, #0xffff
    8e04:	54fffae0 	b.eq	8d60 <fwp_main_thread+0xa20>  // b.none
    8e08:	f9400b39 	ldr	x25, [x25, #16]
    8e0c:	b5ffeb19 	cbnz	x25, 8b6c <fwp_main_thread+0x82c>
    8e10:	17ffffde 	b	8d88 <fwp_main_thread+0xa48>
    8e14:	72003c5f 	tst	w2, #0xffff
    8e18:	54fff5c1 	b.ne	8cd0 <fwp_main_thread+0x990>  // b.any
    8e1c:	17ffffa8 	b	8cbc <fwp_main_thread+0x97c>
    8e20:	f9000be0 	str	x0, [sp, #16]
    8e24:	97ffeefb 	bl	4a10 <fwp_rc_forget_slot>
    8e28:	f9400be0 	ldr	x0, [sp, #16]
    8e2c:	17fffeb2 	b	88f4 <fwp_main_thread+0x5b4>
    8e30:	aa0003e1 	mov	x1, x0
    8e34:	f90022d3 	str	x19, [x22, #64]
    8e38:	17fffda4 	b	84c8 <fwp_main_thread+0x188>
    8e3c:	f941d2c0 	ldr	x0, [x22, #928]
    8e40:	97ffef94 	bl	4c90 <fwp_mem_free>
    8e44:	f901d2df 	str	xzr, [x22, #928]
    8e48:	f901dadf 	str	xzr, [x22, #944]
    8e4c:	f941eec0 	ldr	x0, [x22, #984]
    8e50:	b4000173 	cbz	x19, 8e7c <fwp_main_thread+0xb3c>
    8e54:	f900567f 	str	xzr, [x19, #168]
    8e58:	f9005e7f 	str	xzr, [x19, #184]
    8e5c:	b903d2df 	str	wzr, [x22, #976]
    8e60:	eb13001f 	cmp	x0, x19
    8e64:	54ffb900 	b.eq	8584 <fwp_main_thread+0x244>  // b.none
    8e68:	97ffe6a2 	bl	28f0 <abort@plt>
    8e6c:	f9000fe0 	str	x0, [sp, #24]
    8e70:	97ffeee8 	bl	4a10 <fwp_rc_forget_slot>
    8e74:	f9400fe0 	ldr	x0, [sp, #24]
    8e78:	17ffff94 	b	8cc8 <fwp_main_thread+0x988>
    8e7c:	b903d2df 	str	wzr, [x22, #976]
    8e80:	b4ffc1c0 	cbz	x0, 86b8 <fwp_main_thread+0x378>
    8e84:	97ffe69b 	bl	28f0 <abort@plt>
    8e88:	97ffee9b 	bl	48f4 <fwp_rc_wide_dup>
    8e8c:	17ffff59 	b	8bf0 <fwp_main_thread+0x8b0>
    8e90:	aa1903e0 	mov	x0, x25
    8e94:	97ffeedf 	bl	4a10 <fwp_rc_forget_slot>
    8e98:	17fffee0 	b	8a18 <fwp_main_thread+0x6d8>
    8e9c:	aa1603e0 	mov	x0, x22
    8ea0:	97ffeedc 	bl	4a10 <fwp_rc_forget_slot>
    8ea4:	17ffff01 	b	8aa8 <fwp_main_thread+0x768>
    8ea8:	aa1603e0 	mov	x0, x22
    8eac:	97ffeed9 	bl	4a10 <fwp_rc_forget_slot>
    8eb0:	17ffff23 	b	8b3c <fwp_main_thread+0x7fc>
    8eb4:	ca404401 	eor	x1, x0, x0, lsr #17
    8eb8:	911882a2 	add	x2, x21, #0x620
    8ebc:	ca412421 	eor	x1, x1, x1, lsr #9
    8ec0:	8b210c41 	add	x1, x2, w1, uxtb #3
    8ec4:	f94a2421 	ldr	x1, [x1, #5192]
    8ec8:	b5000081 	cbnz	x1, 8ed8 <fwp_main_thread+0xb98>
    8ecc:	14000011 	b	8f10 <fwp_main_thread+0xbd0>
    8ed0:	f9400821 	ldr	x1, [x1, #16]
    8ed4:	b40001e1 	cbz	x1, 8f10 <fwp_main_thread+0xbd0>
    8ed8:	f9400022 	ldr	x2, [x1]
    8edc:	eb02001f 	cmp	x0, x2
    8ee0:	54ffff81 	b.ne	8ed0 <fwp_main_thread+0xb90>  // b.any
    8ee4:	f9400422 	ldr	x2, [x1, #8]
    8ee8:	d1000442 	sub	x2, x2, #0x1
    8eec:	f9000422 	str	x2, [x1, #8]
    8ef0:	f103f85f 	cmp	x2, #0xfe
    8ef4:	54fff461 	b.ne	8d80 <fwp_main_thread+0xa40>  // b.any
    8ef8:	f9000fe0 	str	x0, [sp, #24]
    8efc:	97ffeec5 	bl	4a10 <fwp_rc_forget_slot>
    8f00:	f9400fe0 	ldr	x0, [sp, #24]
    8f04:	12800021 	mov	w1, #0xfffffffe            	// #-2
    8f08:	39000001 	strb	w1, [x0]
    8f0c:	17ffff9d 	b	8d80 <fwp_main_thread+0xa40>
    8f10:	b0000000 	adrp	x0, 9000 <__divti3+0xb0>
    8f14:	912cc000 	add	x0, x0, #0xb30
    8f18:	97ffea3a 	bl	3800 <fwp_trap>
    8f1c:	b0000000 	adrp	x0, 9000 <__divti3+0xb0>
    8f20:	9135c000 	add	x0, x0, #0xd70
    8f24:	97ffea37 	bl	3800 <fwp_trap>
    8f28:	97ffe65e 	bl	28a0 <__stack_chk_fail@plt>
    8f2c:	b0000000 	adrp	x0, 9000 <__divti3+0xb0>
    8f30:	91366000 	add	x0, x0, #0xd98
    8f34:	97ffe913 	bl	3380 <ad_raw_fail>
    8f38:	b0000000 	adrp	x0, 9000 <__divti3+0xb0>
    8f3c:	9136e000 	add	x0, x0, #0xdb8
    8f40:	97ffea30 	bl	3800 <fwp_trap>
    8f44:	d503201f 	nop
    8f48:	d503201f 	nop
    8f4c:	d503201f 	nop

0000000000008f50 <__divti3>:
    8f50:	d503245f 	bti	c
    8f54:	d2800004 	mov	x4, #0x0                   	// #0
    8f58:	b7f80721 	tbnz	x1, #63, 903c <__divti3+0xec>
    8f5c:	b6f80083 	tbz	x3, #63, 8f6c <__divti3+0x1c>
    8f60:	eb0203e2 	negs	x2, x2
    8f64:	aa2403e4 	mvn	x4, x4
    8f68:	da0303e3 	ngc	x3, x3
    8f6c:	aa0203e6 	mov	x6, x2
    8f70:	aa0003e7 	mov	x7, x0
    8f74:	aa0103e5 	mov	x5, x1
    8f78:	b5000583 	cbnz	x3, 9028 <__divti3+0xd8>
    8f7c:	eb01005f 	cmp	x2, x1
    8f80:	54000e69 	b.ls	914c <__divti3+0x1fc>  // b.plast
    8f84:	dac01040 	clz	x0, x2
    8f88:	b40000e0 	cbz	x0, 8fa4 <__divti3+0x54>
    8f8c:	4b0003e1 	neg	w1, w0
    8f90:	9ac020a5 	lsl	x5, x5, x0
    8f94:	9ac02046 	lsl	x6, x2, x0
    8f98:	9ac124e1 	lsr	x1, x7, x1
    8f9c:	aa050025 	orr	x5, x1, x5
    8fa0:	9ac020e7 	lsl	x7, x7, x0
    8fa4:	d360fcc8 	lsr	x8, x6, #32
    8fa8:	92407cc2 	and	x2, x6, #0xffffffff
    8fac:	9ac808a3 	udiv	x3, x5, x8
    8fb0:	9b089465 	msub	x5, x3, x8, x5
    8fb4:	aa0303e0 	mov	x0, x3
    8fb8:	9b037c41 	mul	x1, x2, x3
    8fbc:	93c780a5 	extr	x5, x5, x7, #32
    8fc0:	eb05003f 	cmp	x1, x5
    8fc4:	540000a9 	b.ls	8fd8 <__divti3+0x88>  // b.plast
    8fc8:	ab0500c5 	adds	x5, x6, x5
    8fcc:	d1000460 	sub	x0, x3, #0x1
    8fd0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8fd4:	540015a8 	b.hi	9288 <__divti3+0x338>  // b.pmore
    8fd8:	cb0100a5 	sub	x5, x5, x1
    8fdc:	9ac808a3 	udiv	x3, x5, x8
    8fe0:	9b089465 	msub	x5, x3, x8, x5
    8fe4:	aa0303e1 	mov	x1, x3
    8fe8:	9b037c42 	mul	x2, x2, x3
    8fec:	aa0703e3 	mov	x3, x7
    8ff0:	b3607ca3 	bfi	x3, x5, #32, #32
    8ff4:	eb03005f 	cmp	x2, x3
    8ff8:	540000c9 	b.ls	9010 <__divti3+0xc0>  // b.plast
    8ffc:	ab0300c3 	adds	x3, x6, x3
    9000:	d1000425 	sub	x5, x1, #0x1
    9004:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9008:	d1000821 	sub	x1, x1, #0x2
    900c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    9010:	aa008020 	orr	x0, x1, x0, lsl #32
    9014:	d2800001 	mov	x1, #0x0                   	// #0
    9018:	b4000064 	cbz	x4, 9024 <__divti3+0xd4>
    901c:	eb0003e0 	negs	x0, x0
    9020:	da0103e1 	ngc	x1, x1
    9024:	d65f03c0 	ret
    9028:	eb01007f 	cmp	x3, x1
    902c:	54000109 	b.ls	904c <__divti3+0xfc>  // b.plast
    9030:	d2800001 	mov	x1, #0x0                   	// #0
    9034:	d2800000 	mov	x0, #0x0                   	// #0
    9038:	17fffff8 	b	9018 <__divti3+0xc8>
    903c:	eb0003e0 	negs	x0, x0
    9040:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9044:	da0103e1 	ngc	x1, x1
    9048:	17ffffc5 	b	8f5c <__divti3+0xc>
    904c:	dac01067 	clz	x7, x3
    9050:	b40010e7 	cbz	x7, 926c <__divti3+0x31c>
    9054:	d2800805 	mov	x5, #0x40                  	// #64
    9058:	cb0700a5 	sub	x5, x5, x7
    905c:	9ac72063 	lsl	x3, x3, x7
    9060:	9ac52448 	lsr	x8, x2, x5
    9064:	aa030108 	orr	x8, x8, x3
    9068:	9ac52426 	lsr	x6, x1, x5
    906c:	92407d0a 	and	x10, x8, #0xffffffff
    9070:	d360fd09 	lsr	x9, x8, #32
    9074:	9ac52403 	lsr	x3, x0, x5
    9078:	9ac72021 	lsl	x1, x1, x7
    907c:	aa010063 	orr	x3, x3, x1
    9080:	9ac72042 	lsl	x2, x2, x7
    9084:	9ac908cb 	udiv	x11, x6, x9
    9088:	9b099965 	msub	x5, x11, x9, x6
    908c:	aa0b03e1 	mov	x1, x11
    9090:	9b0b7d46 	mul	x6, x10, x11
    9094:	93c380a5 	extr	x5, x5, x3, #32
    9098:	eb0500df 	cmp	x6, x5
    909c:	540000a9 	b.ls	90b0 <__divti3+0x160>  // b.plast
    90a0:	ab050105 	adds	x5, x8, x5
    90a4:	d1000561 	sub	x1, x11, #0x1
    90a8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    90ac:	54000f48 	b.hi	9294 <__divti3+0x344>  // b.pmore
    90b0:	cb0600a6 	sub	x6, x5, x6
    90b4:	9ac908cb 	udiv	x11, x6, x9
    90b8:	9b099969 	msub	x9, x11, x9, x6
    90bc:	aa0b03e5 	mov	x5, x11
    90c0:	9b0b7d4a 	mul	x10, x10, x11
    90c4:	b3607d23 	bfi	x3, x9, #32, #32
    90c8:	eb03015f 	cmp	x10, x3
    90cc:	540000a9 	b.ls	90e0 <__divti3+0x190>  // b.plast
    90d0:	ab030103 	adds	x3, x8, x3
    90d4:	d1000565 	sub	x5, x11, #0x1
    90d8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    90dc:	54000e28 	b.hi	92a0 <__divti3+0x350>  // b.pmore
    90e0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    90e4:	92407c48 	and	x8, x2, #0xffffffff
    90e8:	2a0503e5 	mov	w5, w5
    90ec:	d360fc42 	lsr	x2, x2, #32
    90f0:	d360fc26 	lsr	x6, x1, #32
    90f4:	cb0a0063 	sub	x3, x3, x10
    90f8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    90fc:	9b087caa 	mul	x10, x5, x8
    9100:	9b087cc8 	mul	x8, x6, x8
    9104:	9b0220a5 	madd	x5, x5, x2, x8
    9108:	9b027cc6 	mul	x6, x6, x2
    910c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    9110:	8b0900c5 	add	x5, x6, x9
    9114:	eb02011f 	cmp	x8, x2
    9118:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    911c:	8b4280c6 	add	x6, x6, x2, lsr #32
    9120:	eb06007f 	cmp	x3, x6
    9124:	540000e3 	b.cc	9140 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    9128:	92407d4a 	and	x10, x10, #0xffffffff
    912c:	9ac72000 	lsl	x0, x0, x7
    9130:	8b028142 	add	x2, x10, x2, lsl #32
    9134:	eb02001f 	cmp	x0, x2
    9138:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    913c:	54000a01 	b.ne	927c <__divti3+0x32c>  // b.any
    9140:	d1000420 	sub	x0, x1, #0x1
    9144:	d2800001 	mov	x1, #0x0                   	// #0
    9148:	17ffffb4 	b	9018 <__divti3+0xc8>
    914c:	b5000062 	cbnz	x2, 9158 <__divti3+0x208>
    9150:	d2800022 	mov	x2, #0x1                   	// #1
    9154:	9ac30846 	udiv	x6, x2, x3
    9158:	dac010c8 	clz	x8, x6
    915c:	b5000408 	cbnz	x8, 91dc <__divti3+0x28c>
    9160:	d360fcc9 	lsr	x9, x6, #32
    9164:	92407cc5 	and	x5, x6, #0xffffffff
    9168:	cb060023 	sub	x3, x1, x6
    916c:	d2800021 	mov	x1, #0x1                   	// #1
    9170:	9ac90868 	udiv	x8, x3, x9
    9174:	9b098d03 	msub	x3, x8, x9, x3
    9178:	aa0803e0 	mov	x0, x8
    917c:	9b057d02 	mul	x2, x8, x5
    9180:	93c78063 	extr	x3, x3, x7, #32
    9184:	eb03005f 	cmp	x2, x3
    9188:	540000a9 	b.ls	919c <__divti3+0x24c>  // b.plast
    918c:	ab0300c3 	adds	x3, x6, x3
    9190:	d1000500 	sub	x0, x8, #0x1
    9194:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9198:	54000968 	b.hi	92c4 <__divti3+0x374>  // b.pmore
    919c:	cb020063 	sub	x3, x3, x2
    91a0:	9ac90862 	udiv	x2, x3, x9
    91a4:	aa0203e8 	mov	x8, x2
    91a8:	9b098c42 	msub	x2, x2, x9, x3
    91ac:	aa0703e3 	mov	x3, x7
    91b0:	9b057d05 	mul	x5, x8, x5
    91b4:	b3607c43 	bfi	x3, x2, #32, #32
    91b8:	eb0300bf 	cmp	x5, x3
    91bc:	540000c9 	b.ls	91d4 <__divti3+0x284>  // b.plast
    91c0:	ab0300c2 	adds	x2, x6, x3
    91c4:	d1000503 	sub	x3, x8, #0x1
    91c8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    91cc:	d1000908 	sub	x8, x8, #0x2
    91d0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    91d4:	aa008100 	orr	x0, x8, x0, lsl #32
    91d8:	17ffff90 	b	9018 <__divti3+0xc8>
    91dc:	9ac820c6 	lsl	x6, x6, x8
    91e0:	d2800803 	mov	x3, #0x40                  	// #64
    91e4:	cb080063 	sub	x3, x3, x8
    91e8:	d360fcc9 	lsr	x9, x6, #32
    91ec:	9ac82027 	lsl	x7, x1, x8
    91f0:	92407cc5 	and	x5, x6, #0xffffffff
    91f4:	9ac32422 	lsr	x2, x1, x3
    91f8:	9ac32403 	lsr	x3, x0, x3
    91fc:	aa070063 	orr	x3, x3, x7
    9200:	9ac9084a 	udiv	x10, x2, x9
    9204:	9ac82007 	lsl	x7, x0, x8
    9208:	9b098940 	msub	x0, x10, x9, x2
    920c:	aa0a03e1 	mov	x1, x10
    9210:	9b0a7ca2 	mul	x2, x5, x10
    9214:	93c38000 	extr	x0, x0, x3, #32
    9218:	eb00005f 	cmp	x2, x0
    921c:	540000a9 	b.ls	9230 <__divti3+0x2e0>  // b.plast
    9220:	ab0000c0 	adds	x0, x6, x0
    9224:	d1000541 	sub	x1, x10, #0x1
    9228:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    922c:	54000468 	b.hi	92b8 <__divti3+0x368>  // b.pmore
    9230:	cb020000 	sub	x0, x0, x2
    9234:	9ac9080a 	udiv	x10, x0, x9
    9238:	9b098140 	msub	x0, x10, x9, x0
    923c:	aa0a03e2 	mov	x2, x10
    9240:	9b0a7ca8 	mul	x8, x5, x10
    9244:	b3607c03 	bfi	x3, x0, #32, #32
    9248:	eb03011f 	cmp	x8, x3
    924c:	540000a9 	b.ls	9260 <__divti3+0x310>  // b.plast
    9250:	ab0300c3 	adds	x3, x6, x3
    9254:	d1000542 	sub	x2, x10, #0x1
    9258:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    925c:	54000288 	b.hi	92ac <__divti3+0x35c>  // b.pmore
    9260:	cb080063 	sub	x3, x3, x8
    9264:	aa018041 	orr	x1, x2, x1, lsl #32
    9268:	17ffffc2 	b	9170 <__divti3+0x220>
    926c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9270:	d2800001 	mov	x1, #0x0                   	// #0
    9274:	9a9f87e0 	cset	x0, ls	// ls = plast
    9278:	17ffff68 	b	9018 <__divti3+0xc8>
    927c:	aa0103e0 	mov	x0, x1
    9280:	d2800001 	mov	x1, #0x0                   	// #0
    9284:	17ffff65 	b	9018 <__divti3+0xc8>
    9288:	d1000860 	sub	x0, x3, #0x2
    928c:	8b0600a5 	add	x5, x5, x6
    9290:	17ffff52 	b	8fd8 <__divti3+0x88>
    9294:	d1000961 	sub	x1, x11, #0x2
    9298:	8b0800a5 	add	x5, x5, x8
    929c:	17ffff85 	b	90b0 <__divti3+0x160>
    92a0:	d1000965 	sub	x5, x11, #0x2
    92a4:	8b080063 	add	x3, x3, x8
    92a8:	17ffff8e 	b	90e0 <__divti3+0x190>
    92ac:	d1000942 	sub	x2, x10, #0x2
    92b0:	8b060063 	add	x3, x3, x6
    92b4:	17ffffeb 	b	9260 <__divti3+0x310>
    92b8:	d1000941 	sub	x1, x10, #0x2
    92bc:	8b060000 	add	x0, x0, x6
    92c0:	17ffffdc 	b	9230 <__divti3+0x2e0>
    92c4:	d1000900 	sub	x0, x8, #0x2
    92c8:	8b060063 	add	x3, x3, x6
    92cc:	17ffffb4 	b	919c <__divti3+0x24c>

00000000000092d0 <__modti3>:
    92d0:	d503245f 	bti	c
    92d4:	d2800004 	mov	x4, #0x0                   	// #0
    92d8:	b6f80081 	tbz	x1, #63, 92e8 <__modti3+0x18>
    92dc:	eb0003e0 	negs	x0, x0
    92e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    92e4:	da0103e1 	ngc	x1, x1
    92e8:	f100007f 	cmp	x3, #0x0
    92ec:	5400128b 	b.lt	953c <__modti3+0x26c>  // b.tstop
    92f0:	aa0003e7 	mov	x7, x0
    92f4:	aa0103e6 	mov	x6, x1
    92f8:	540004e1 	b.ne	9394 <__modti3+0xc4>  // b.any
    92fc:	eb02003f 	cmp	x1, x2
    9300:	54000dc2 	b.cs	94b8 <__modti3+0x1e8>  // b.hs, b.nlast
    9304:	dac01043 	clz	x3, x2
    9308:	aa0303e5 	mov	x5, x3
    930c:	b40000e3 	cbz	x3, 9328 <__modti3+0x58>
    9310:	4b0303e6 	neg	w6, w3
    9314:	9ac32021 	lsl	x1, x1, x3
    9318:	9ac32042 	lsl	x2, x2, x3
    931c:	9ac62406 	lsr	x6, x0, x6
    9320:	aa0100c6 	orr	x6, x6, x1
    9324:	9ac32007 	lsl	x7, x0, x3
    9328:	d360fc40 	lsr	x0, x2, #32
    932c:	92407c43 	and	x3, x2, #0xffffffff
    9330:	9ac008c1 	udiv	x1, x6, x0
    9334:	9b009826 	msub	x6, x1, x0, x6
    9338:	9b017c61 	mul	x1, x3, x1
    933c:	93c780c6 	extr	x6, x6, x7, #32
    9340:	eb06003f 	cmp	x1, x6
    9344:	540000a9 	b.ls	9358 <__modti3+0x88>  // b.plast
    9348:	ab060046 	adds	x6, x2, x6
    934c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9350:	8b0200c8 	add	x8, x6, x2
    9354:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9358:	cb0100c6 	sub	x6, x6, x1
    935c:	9ac008c8 	udiv	x8, x6, x0
    9360:	9b009901 	msub	x1, x8, x0, x6
    9364:	aa0703e0 	mov	x0, x7
    9368:	9b087c63 	mul	x3, x3, x8
    936c:	b3607c20 	bfi	x0, x1, #32, #32
    9370:	eb00007f 	cmp	x3, x0
    9374:	54001088 	b.hi	9584 <__modti3+0x2b4>  // b.pmore
    9378:	cb030000 	sub	x0, x0, x3
    937c:	9ac52400 	lsr	x0, x0, x5
    9380:	d2800001 	mov	x1, #0x0                   	// #0
    9384:	b4000064 	cbz	x4, 9390 <__modti3+0xc0>
    9388:	eb0003e0 	negs	x0, x0
    938c:	da0103e1 	ngc	x1, x1
    9390:	d65f03c0 	ret
    9394:	dac01066 	clz	x6, x3
    9398:	eb03003f 	cmp	x1, x3
    939c:	54ffff43 	b.cc	9384 <__modti3+0xb4>  // b.lo, b.ul, b.last
    93a0:	93407cc5 	sxtw	x5, w6
    93a4:	d2800808 	mov	x8, #0x40                  	// #64
    93a8:	cb050108 	sub	x8, x8, x5
    93ac:	9ac62063 	lsl	x3, x3, x6
    93b0:	9ac62025 	lsl	x5, x1, x6
    93b4:	9ac82447 	lsr	x7, x2, x8
    93b8:	aa0300e7 	orr	x7, x7, x3
    93bc:	9ac82423 	lsr	x3, x1, x8
    93c0:	92407cec 	and	x12, x7, #0xffffffff
    93c4:	d360fcea 	lsr	x10, x7, #32
    93c8:	9ac82401 	lsr	x1, x0, x8
    93cc:	aa050021 	orr	x1, x1, x5
    93d0:	9ac62042 	lsl	x2, x2, x6
    93d4:	9ac62000 	lsl	x0, x0, x6
    93d8:	9aca086b 	udiv	x11, x3, x10
    93dc:	9b0a8d63 	msub	x3, x11, x10, x3
    93e0:	aa0b03e5 	mov	x5, x11
    93e4:	9b0b7d89 	mul	x9, x12, x11
    93e8:	93c18063 	extr	x3, x3, x1, #32
    93ec:	eb03013f 	cmp	x9, x3
    93f0:	540000a9 	b.ls	9404 <__modti3+0x134>  // b.plast
    93f4:	ab0300e3 	adds	x3, x7, x3
    93f8:	d1000565 	sub	x5, x11, #0x1
    93fc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9400:	54001168 	b.hi	962c <__modti3+0x35c>  // b.pmore
    9404:	cb090063 	sub	x3, x3, x9
    9408:	9aca086b 	udiv	x11, x3, x10
    940c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9410:	aa0b03e9 	mov	x9, x11
    9414:	9b0b7d8c 	mul	x12, x12, x11
    9418:	b3607d41 	bfi	x1, x10, #32, #32
    941c:	eb01019f 	cmp	x12, x1
    9420:	540000a9 	b.ls	9434 <__modti3+0x164>  // b.plast
    9424:	ab0100e1 	adds	x1, x7, x1
    9428:	d1000569 	sub	x9, x11, #0x1
    942c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9430:	54000f88 	b.hi	9620 <__modti3+0x350>  // b.pmore
    9434:	aa058123 	orr	x3, x9, x5, lsl #32
    9438:	92407c4b 	and	x11, x2, #0xffffffff
    943c:	2a0903e9 	mov	w9, w9
    9440:	d360fc4a 	lsr	x10, x2, #32
    9444:	d360fc63 	lsr	x3, x3, #32
    9448:	cb0c0021 	sub	x1, x1, x12
    944c:	aa0a03ec 	mov	x12, x10
    9450:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9454:	9b0b7d25 	mul	x5, x9, x11
    9458:	9b0b7c6b 	mul	x11, x3, x11
    945c:	9b0a2d29 	madd	x9, x9, x10, x11
    9460:	92407caa 	and	x10, x5, #0xffffffff
    9464:	9b0c7c63 	mul	x3, x3, x12
    9468:	8b458125 	add	x5, x9, x5, lsr #32
    946c:	8b0d0069 	add	x9, x3, x13
    9470:	eb05017f 	cmp	x11, x5
    9474:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9478:	8b058149 	add	x9, x10, x5, lsl #32
    947c:	8b458063 	add	x3, x3, x5, lsr #32
    9480:	eb03003f 	cmp	x1, x3
    9484:	54000063 	b.cc	9490 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9488:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    948c:	54000082 	b.cs	949c <__modti3+0x1cc>  // b.hs, b.nlast
    9490:	eb020129 	subs	x9, x9, x2
    9494:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9498:	cb070063 	sub	x3, x3, x7
    949c:	eb090000 	subs	x0, x0, x9
    94a0:	da030021 	sbc	x1, x1, x3
    94a4:	9ac62400 	lsr	x0, x0, x6
    94a8:	9ac82028 	lsl	x8, x1, x8
    94ac:	aa000100 	orr	x0, x8, x0
    94b0:	9ac62421 	lsr	x1, x1, x6
    94b4:	17ffffb4 	b	9384 <__modti3+0xb4>
    94b8:	b5000062 	cbnz	x2, 94c4 <__modti3+0x1f4>
    94bc:	d2800023 	mov	x3, #0x1                   	// #1
    94c0:	9ac20862 	udiv	x2, x3, x2
    94c4:	dac01048 	clz	x8, x2
    94c8:	aa0803e5 	mov	x5, x8
    94cc:	b5000668 	cbnz	x8, 9598 <__modti3+0x2c8>
    94d0:	cb020020 	sub	x0, x1, x2
    94d4:	d360fc49 	lsr	x9, x2, #32
    94d8:	92407c4a 	and	x10, x2, #0xffffffff
    94dc:	9ac90801 	udiv	x1, x0, x9
    94e0:	9b098020 	msub	x0, x1, x9, x0
    94e4:	9b0a7c21 	mul	x1, x1, x10
    94e8:	93c78000 	extr	x0, x0, x7, #32
    94ec:	eb00003f 	cmp	x1, x0
    94f0:	540000a9 	b.ls	9504 <__modti3+0x234>  // b.plast
    94f4:	ab000040 	adds	x0, x2, x0
    94f8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    94fc:	8b020003 	add	x3, x0, x2
    9500:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9504:	cb010001 	sub	x1, x0, x1
    9508:	9ac90820 	udiv	x0, x1, x9
    950c:	9b098403 	msub	x3, x0, x9, x1
    9510:	aa0703e1 	mov	x1, x7
    9514:	9b0a7c00 	mul	x0, x0, x10
    9518:	b3607c61 	bfi	x1, x3, #32, #32
    951c:	eb01001f 	cmp	x0, x1
    9520:	540000a9 	b.ls	9534 <__modti3+0x264>  // b.plast
    9524:	ab010041 	adds	x1, x2, x1
    9528:	8b020022 	add	x2, x1, x2
    952c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9530:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9534:	cb000020 	sub	x0, x1, x0
    9538:	17ffff91 	b	937c <__modti3+0xac>
    953c:	eb0203e5 	negs	x5, x2
    9540:	aa0003e7 	mov	x7, x0
    9544:	da0303e8 	ngc	x8, x3
    9548:	aa0503e2 	mov	x2, x5
    954c:	aa0803e3 	mov	x3, x8
    9550:	aa0103e6 	mov	x6, x1
    9554:	b4ffed48 	cbz	x8, 92fc <__modti3+0x2c>
    9558:	eb01011f 	cmp	x8, x1
    955c:	54fff148 	b.hi	9384 <__modti3+0xb4>  // b.pmore
    9560:	dac01109 	clz	x9, x8
    9564:	2a0903e6 	mov	w6, w9
    9568:	b5fff1c9 	cbnz	x9, 93a0 <__modti3+0xd0>
    956c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9570:	54000068 	b.hi	957c <__modti3+0x2ac>  // b.pmore
    9574:	eb050007 	subs	x7, x0, x5
    9578:	da080021 	sbc	x1, x1, x8
    957c:	aa0703e0 	mov	x0, x7
    9580:	17ffff81 	b	9384 <__modti3+0xb4>
    9584:	ab000040 	adds	x0, x2, x0
    9588:	8b020002 	add	x2, x0, x2
    958c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9590:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9594:	17ffff79 	b	9378 <__modti3+0xa8>
    9598:	9ac82042 	lsl	x2, x2, x8
    959c:	d2800803 	mov	x3, #0x40                  	// #64
    95a0:	cb080063 	sub	x3, x3, x8
    95a4:	d360fc49 	lsr	x9, x2, #32
    95a8:	9ac82027 	lsl	x7, x1, x8
    95ac:	92407c4a 	and	x10, x2, #0xffffffff
    95b0:	9ac32426 	lsr	x6, x1, x3
    95b4:	9ac32403 	lsr	x3, x0, x3
    95b8:	aa070063 	orr	x3, x3, x7
    95bc:	9ac908c1 	udiv	x1, x6, x9
    95c0:	9ac82007 	lsl	x7, x0, x8
    95c4:	9b099820 	msub	x0, x1, x9, x6
    95c8:	9b017d41 	mul	x1, x10, x1
    95cc:	93c38000 	extr	x0, x0, x3, #32
    95d0:	eb00003f 	cmp	x1, x0
    95d4:	540000a9 	b.ls	95e8 <__modti3+0x318>  // b.plast
    95d8:	ab000040 	adds	x0, x2, x0
    95dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    95e0:	8b020006 	add	x6, x0, x2
    95e4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    95e8:	cb010000 	sub	x0, x0, x1
    95ec:	9ac90801 	udiv	x1, x0, x9
    95f0:	9b098026 	msub	x6, x1, x9, x0
    95f4:	aa0303e0 	mov	x0, x3
    95f8:	9b017d41 	mul	x1, x10, x1
    95fc:	b3607cc0 	bfi	x0, x6, #32, #32
    9600:	eb00003f 	cmp	x1, x0
    9604:	540000a9 	b.ls	9618 <__modti3+0x348>  // b.plast
    9608:	ab000040 	adds	x0, x2, x0
    960c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9610:	8b020003 	add	x3, x0, x2
    9614:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9618:	cb010000 	sub	x0, x0, x1
    961c:	17ffffb0 	b	94dc <__modti3+0x20c>
    9620:	d1000969 	sub	x9, x11, #0x2
    9624:	8b070021 	add	x1, x1, x7
    9628:	17ffff83 	b	9434 <__modti3+0x164>
    962c:	d1000965 	sub	x5, x11, #0x2
    9630:	8b070063 	add	x3, x3, x7
    9634:	17ffff74 	b	9404 <__modti3+0x134>
    9638:	d503201f 	nop
    963c:	d503201f 	nop

0000000000009640 <atexit>:
    9640:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9644:	f00000a2 	adrp	x2, 20000 <__data_start>
    9648:	d2800001 	mov	x1, #0x0                   	// #0
    964c:	910003fd 	mov	x29, sp
    9650:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9654:	f9400442 	ldr	x2, [x2, #8]
    9658:	17ffe452 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000965c <_fini>:
    965c:	d503201f 	nop
    9660:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9664:	910003fd 	mov	x29, sp
    9668:	a8c17bfd 	ldp	x29, x30, [sp], #16
    966c:	d65f03c0 	ret
