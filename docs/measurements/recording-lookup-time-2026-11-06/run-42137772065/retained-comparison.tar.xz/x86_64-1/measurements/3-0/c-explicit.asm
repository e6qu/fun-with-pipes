
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/c-explicit:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	f3 0f 1e fa          	endbr64
    1004:	48 83 ec 08          	sub    $0x8,%rsp
    1008:	48 8b 05 d9 2f 00 00 	mov    0x2fd9(%rip),%rax        # 3fe8 <__gmon_start__>
    100f:	48 85 c0             	test   %rax,%rax
    1012:	74 02                	je     1016 <_init+0x16>
    1014:	ff d0                	call   *%rax
    1016:	48 83 c4 08          	add    $0x8,%rsp
    101a:	c3                   	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	ff 35 72 2f 00 00    	push   0x2f72(%rip)        # 3f98 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	ff 25 74 2f 00 00    	jmp    *0x2f74(%rip)        # 3fa0 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	0f 1f 40 00          	nopl   0x0(%rax)
    1030:	f3 0f 1e fa          	endbr64
    1034:	68 00 00 00 00       	push   $0x0
    1039:	e9 e2 ff ff ff       	jmp    1020 <_init+0x20>
    103e:	66 90                	xchg   %ax,%ax
    1040:	f3 0f 1e fa          	endbr64
    1044:	68 01 00 00 00       	push   $0x1
    1049:	e9 d2 ff ff ff       	jmp    1020 <_init+0x20>
    104e:	66 90                	xchg   %ax,%ax
    1050:	f3 0f 1e fa          	endbr64
    1054:	68 02 00 00 00       	push   $0x2
    1059:	e9 c2 ff ff ff       	jmp    1020 <_init+0x20>
    105e:	66 90                	xchg   %ax,%ax
    1060:	f3 0f 1e fa          	endbr64
    1064:	68 03 00 00 00       	push   $0x3
    1069:	e9 b2 ff ff ff       	jmp    1020 <_init+0x20>
    106e:	66 90                	xchg   %ax,%ax
    1070:	f3 0f 1e fa          	endbr64
    1074:	68 04 00 00 00       	push   $0x4
    1079:	e9 a2 ff ff ff       	jmp    1020 <_init+0x20>
    107e:	66 90                	xchg   %ax,%ax
    1080:	f3 0f 1e fa          	endbr64
    1084:	68 05 00 00 00       	push   $0x5
    1089:	e9 92 ff ff ff       	jmp    1020 <_init+0x20>
    108e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000001090 <__cxa_finalize@plt>:
    1090:	f3 0f 1e fa          	endbr64
    1094:	ff 25 5e 2f 00 00    	jmp    *0x2f5e(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    109a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000010a0 <free@plt>:
    10a0:	f3 0f 1e fa          	endbr64
    10a4:	ff 25 fe 2e 00 00    	jmp    *0x2efe(%rip)        # 3fa8 <free@GLIBC_2.2.5>
    10aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010b0 <puts@plt>:
    10b0:	f3 0f 1e fa          	endbr64
    10b4:	ff 25 f6 2e 00 00    	jmp    *0x2ef6(%rip)        # 3fb0 <puts@GLIBC_2.2.5>
    10ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010c0 <ferror@plt>:
    10c0:	f3 0f 1e fa          	endbr64
    10c4:	ff 25 ee 2e 00 00    	jmp    *0x2eee(%rip)        # 3fb8 <ferror@GLIBC_2.2.5>
    10ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010d0 <putc@plt>:
    10d0:	f3 0f 1e fa          	endbr64
    10d4:	ff 25 e6 2e 00 00    	jmp    *0x2ee6(%rip)        # 3fc0 <putc@GLIBC_2.2.5>
    10da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010e0 <malloc@plt>:
    10e0:	f3 0f 1e fa          	endbr64
    10e4:	ff 25 de 2e 00 00    	jmp    *0x2ede(%rip)        # 3fc8 <malloc@GLIBC_2.2.5>
    10ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000010f0 <__printf_chk@plt>:
    10f0:	f3 0f 1e fa          	endbr64
    10f4:	ff 25 d6 2e 00 00    	jmp    *0x2ed6(%rip)        # 3fd0 <__printf_chk@GLIBC_2.3.4>
    10fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000001100 <main>:
    1100:	f3 0f 1e fa          	endbr64
    1104:	41 54                	push   %r12
    1106:	41 bc 00 80 00 00    	mov    $0x8000,%r12d
    110c:	55                   	push   %rbp
    110d:	53                   	push   %rbx
    110e:	eb 0a                	jmp    111a <main+0x1a>
    1110:	49 83 ec 01          	sub    $0x1,%r12
    1114:	0f 84 d8 00 00 00    	je     11f2 <main+0xf2>
    111a:	bf 18 00 00 00       	mov    $0x18,%edi
    111f:	e8 bc ff ff ff       	call   10e0 <malloc@plt>
    1124:	bf 18 00 00 00       	mov    $0x18,%edi
    1129:	48 89 c3             	mov    %rax,%rbx
    112c:	e8 af ff ff ff       	call   10e0 <malloc@plt>
    1131:	48 89 c5             	mov    %rax,%rbp
    1134:	48 85 db             	test   %rbx,%rbx
    1137:	0f 84 ba 00 00 00    	je     11f7 <main+0xf7>
    113d:	48 85 c0             	test   %rax,%rax
    1140:	0f 84 b1 00 00 00    	je     11f7 <main+0xf7>
    1146:	48 8b 05 c3 0e 00 00 	mov    0xec3(%rip),%rax        # 2010 <_IO_stdin_used+0x10>
    114d:	66 0f 28 0d bb 0e 00 	movapd 0xebb(%rip),%xmm1        # 2010 <_IO_stdin_used+0x10>
    1154:	00 
    1155:	bf 5b 00 00 00       	mov    $0x5b,%edi
    115a:	48 8b 35 af 2e 00 00 	mov    0x2eaf(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    1161:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1165:	0f 11 0b             	movups %xmm1,(%rbx)
    1168:	e8 63 ff ff ff       	call   10d0 <putc@plt>
    116d:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    1171:	bf 02 00 00 00       	mov    $0x2,%edi
    1176:	48 8d 35 89 0e 00 00 	lea    0xe89(%rip),%rsi        # 2006 <_IO_stdin_used+0x6>
    117d:	b8 01 00 00 00       	mov    $0x1,%eax
    1182:	e8 69 ff ff ff       	call   10f0 <__printf_chk@plt>
    1187:	f2 0f 10 43 08       	movsd  0x8(%rbx),%xmm0
    118c:	bf 02 00 00 00       	mov    $0x2,%edi
    1191:	48 8d 35 6c 0e 00 00 	lea    0xe6c(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    1198:	b8 01 00 00 00       	mov    $0x1,%eax
    119d:	e8 4e ff ff ff       	call   10f0 <__printf_chk@plt>
    11a2:	f2 0f 10 43 10       	movsd  0x10(%rbx),%xmm0
    11a7:	bf 02 00 00 00       	mov    $0x2,%edi
    11ac:	48 8d 35 51 0e 00 00 	lea    0xe51(%rip),%rsi        # 2004 <_IO_stdin_used+0x4>
    11b3:	b8 01 00 00 00       	mov    $0x1,%eax
    11b8:	e8 33 ff ff ff       	call   10f0 <__printf_chk@plt>
    11bd:	48 8d 3d 48 0e 00 00 	lea    0xe48(%rip),%rdi        # 200c <_IO_stdin_used+0xc>
    11c4:	e8 e7 fe ff ff       	call   10b0 <puts@plt>
    11c9:	48 89 df             	mov    %rbx,%rdi
    11cc:	e8 cf fe ff ff       	call   10a0 <free@plt>
    11d1:	48 89 ef             	mov    %rbp,%rdi
    11d4:	e8 c7 fe ff ff       	call   10a0 <free@plt>
    11d9:	48 8b 3d 30 2e 00 00 	mov    0x2e30(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    11e0:	e8 db fe ff ff       	call   10c0 <ferror@plt>
    11e5:	85 c0                	test   %eax,%eax
    11e7:	0f 84 23 ff ff ff    	je     1110 <main+0x10>
    11ed:	b8 04 00 00 00       	mov    $0x4,%eax
    11f2:	5b                   	pop    %rbx
    11f3:	5d                   	pop    %rbp
    11f4:	41 5c                	pop    %r12
    11f6:	c3                   	ret
    11f7:	48 89 df             	mov    %rbx,%rdi
    11fa:	e8 a1 fe ff ff       	call   10a0 <free@plt>
    11ff:	48 89 ef             	mov    %rbp,%rdi
    1202:	e8 99 fe ff ff       	call   10a0 <free@plt>
    1207:	b8 02 00 00 00       	mov    $0x2,%eax
    120c:	eb e4                	jmp    11f2 <main+0xf2>
    120e:	66 90                	xchg   %ax,%ax

0000000000001210 <_start>:
    1210:	f3 0f 1e fa          	endbr64
    1214:	31 ed                	xor    %ebp,%ebp
    1216:	49 89 d1             	mov    %rdx,%r9
    1219:	5e                   	pop    %rsi
    121a:	48 89 e2             	mov    %rsp,%rdx
    121d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    1221:	50                   	push   %rax
    1222:	54                   	push   %rsp
    1223:	45 31 c0             	xor    %r8d,%r8d
    1226:	31 c9                	xor    %ecx,%ecx
    1228:	48 8d 3d d1 fe ff ff 	lea    -0x12f(%rip),%rdi        # 1100 <main>
    122f:	ff 15 a3 2d 00 00    	call   *0x2da3(%rip)        # 3fd8 <__libc_start_main@GLIBC_2.34>
    1235:	f4                   	hlt
    1236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    123d:	00 00 00 

0000000000001240 <deregister_tm_clones>:
    1240:	48 8d 3d c9 2d 00 00 	lea    0x2dc9(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    1247:	48 8d 05 c2 2d 00 00 	lea    0x2dc2(%rip),%rax        # 4010 <stdout@GLIBC_2.2.5>
    124e:	48 39 f8             	cmp    %rdi,%rax
    1251:	74 15                	je     1268 <deregister_tm_clones+0x28>
    1253:	48 8b 05 86 2d 00 00 	mov    0x2d86(%rip),%rax        # 3fe0 <_ITM_deregisterTMCloneTable>
    125a:	48 85 c0             	test   %rax,%rax
    125d:	74 09                	je     1268 <deregister_tm_clones+0x28>
    125f:	ff e0                	jmp    *%rax
    1261:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1268:	c3                   	ret
    1269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000001270 <register_tm_clones>:
    1270:	48 8d 3d 99 2d 00 00 	lea    0x2d99(%rip),%rdi        # 4010 <stdout@GLIBC_2.2.5>
    1277:	48 8d 35 92 2d 00 00 	lea    0x2d92(%rip),%rsi        # 4010 <stdout@GLIBC_2.2.5>
    127e:	48 29 fe             	sub    %rdi,%rsi
    1281:	48 89 f0             	mov    %rsi,%rax
    1284:	48 c1 ee 3f          	shr    $0x3f,%rsi
    1288:	48 c1 f8 03          	sar    $0x3,%rax
    128c:	48 01 c6             	add    %rax,%rsi
    128f:	48 d1 fe             	sar    $1,%rsi
    1292:	74 14                	je     12a8 <register_tm_clones+0x38>
    1294:	48 8b 05 55 2d 00 00 	mov    0x2d55(%rip),%rax        # 3ff0 <_ITM_registerTMCloneTable>
    129b:	48 85 c0             	test   %rax,%rax
    129e:	74 08                	je     12a8 <register_tm_clones+0x38>
    12a0:	ff e0                	jmp    *%rax
    12a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    12a8:	c3                   	ret
    12a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000012b0 <__do_global_dtors_aux>:
    12b0:	f3 0f 1e fa          	endbr64
    12b4:	80 3d 5d 2d 00 00 00 	cmpb   $0x0,0x2d5d(%rip)        # 4018 <completed.0>
    12bb:	75 2b                	jne    12e8 <__do_global_dtors_aux+0x38>
    12bd:	55                   	push   %rbp
    12be:	48 83 3d 32 2d 00 00 	cmpq   $0x0,0x2d32(%rip)        # 3ff8 <__cxa_finalize@GLIBC_2.2.5>
    12c5:	00 
    12c6:	48 89 e5             	mov    %rsp,%rbp
    12c9:	74 0c                	je     12d7 <__do_global_dtors_aux+0x27>
    12cb:	48 8b 3d 36 2d 00 00 	mov    0x2d36(%rip),%rdi        # 4008 <__dso_handle>
    12d2:	e8 b9 fd ff ff       	call   1090 <__cxa_finalize@plt>
    12d7:	e8 64 ff ff ff       	call   1240 <deregister_tm_clones>
    12dc:	c6 05 35 2d 00 00 01 	movb   $0x1,0x2d35(%rip)        # 4018 <completed.0>
    12e3:	5d                   	pop    %rbp
    12e4:	c3                   	ret
    12e5:	0f 1f 00             	nopl   (%rax)
    12e8:	c3                   	ret
    12e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000012f0 <frame_dummy>:
    12f0:	f3 0f 1e fa          	endbr64
    12f4:	e9 77 ff ff ff       	jmp    1270 <register_tm_clones>

Disassembly of section .fini:

00000000000012fc <_fini>:
    12fc:	f3 0f 1e fa          	endbr64
    1300:	48 83 ec 08          	sub    $0x8,%rsp
    1304:	48 83 c4 08          	add    $0x8,%rsp
    1308:	c3                   	ret
