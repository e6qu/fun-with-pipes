
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 cf 00 00 	mov    0xcfc1(%rip),%rax        # ffd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da cd 00 00    	push   0xcdda(%rip)        # fe00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc cd 00 00    	jmp    *0xcddc(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 cc 00 00    	jmp    *0xcc46(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fe90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fe98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # feb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # feb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # fef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # fef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ff90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ff98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be c8 00 00    	jmp    *0xc8be(%rip)        # ffb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 89 00 00 	lea    0x89dd(%rip),%r9        # c0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 89 00 00 	lea    0x89da(%rip),%r8        # c0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 ac 00 00 	lea    0xace1(%rip),%rax        # e460 <fwp_fn_table>
    377f:	48 89 05 92 ec 01 00 	mov    %rax,0x1ec92(%rip)        # 22418 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c ec 01 00 	mov    %rax,0x1ec8c(%rip)        # 22420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 8a 00 00 	lea    0x8ab7(%rip),%rdi        # c257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 6f 74 00 00 	lea    0x746f(%rip),%rdx        # acd0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 89 00 00 	lea    0x8967(%rip),%rdi        # c260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e 91 00 00 	lea    0x917e(%rip),%rdi        # ca88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 91 00 00 	lea    0x9138(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc 90 00 00 	lea    0x90fc(%rip),%rdi        # ca30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 90 00 00 	lea    0x90c8(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b c6 00 00    	call   *0xc64b(%rip)        # ffc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e c6 00 00 	mov    0xc62e(%rip),%rax        # ffc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd c5 00 00 	mov    0xc5fd(%rip),%rax        # ffd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da c5 00 00 	cmpq   $0x0,0xc5da(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 e7 01 00 	mov    0x1e7a9(%rip),%rdi        # 22420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 ca 01 00 	mov    0x1caa1(%rip),%rax        # 207a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 c3 01 00 	mov    0x1c3d9(%rip),%rax        # 20158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 c3 01 00 	sub    0x1c3c5(%rip),%rax        # 20150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 8d 00 00 	lea    0x8dad(%rip),%rsi        # cb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f 88 00 00 	lea    0x887f(%rip),%rdi        # c668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 c2 00 00 	mov    0xc242(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 c1 00 00 ff 	cmpl   $0xffffffff,0xc1e5(%rip)        # 10018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 81 00 00 	lea    0x81e2(%rip),%rax        # c022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 c2 01 00 	mov    0x1c2c1(%rip),%r9        # 20108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f bd 00 	movq   0xbd9f(%rip),%xmm0        # fbf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 81 00 00 	lea    0x81e7(%rip),%rax        # c044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c c2 01 00 	mov    0x1c29c(%rip),%r8        # 20100 <descent_inputs>
    3e64:	48 8b 0d a5 c2 01 00 	mov    0x1c2a5(%rip),%rcx        # 20110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 c1 00 00 	mov    0xc1c2(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 81 00 00 	lea    0x81d8(%rip),%rax        # c061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 bd 00 	movq   0xbd67(%rip),%xmm0        # fbf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 88 00 00 	lea    0x8818(%rip),%rdx        # c6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 c2 01 00 	lea    0x1c271(%rip),%r12        # 20120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 bd 00 	movq   0xbd44(%rip),%xmm0        # fc00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b c1 00 00 	mov    0xc15b(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 81 00 00 	lea    0x8175(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 81 00 00 	lea    0x8170(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 c1 00 00 	mov    0xc120(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 81 00 00 	lea    0x8144(%rip),%rdi        # c07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 c0 00 00 	mov    0xc0f9(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 81 00 00 	lea    0x8143(%rip),%rcx        # c091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 81 00 00 	lea    0x8119(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b dc 01 00 	mov    0x1dc1b(%rip),%rax        # 21bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 dc 01 00 	lea    0x1dc14(%rip),%r8        # 21bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 db 01 00 	mov    0x1dbf5(%rip),%rbx        # 21b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 dc 01 00 	mov    0x1dc05(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 db 01 00 	mov    0x1dba1(%rip),%rdi        # 21ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea db 01 00 	sub    %rsi,0x1dbea(%rip)        # 21bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a db 01 00 	mov    0x1db7a(%rip),%rax        # 21b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 db 01 00 	add    0x1db30(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e db 01 00 	mov    0x1db3e(%rip),%rsi        # 21ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c db 01 00 	mov    0x1db4c(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb da 01 00 	mov    %r12,0x1dafb(%rip)        # 21ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 da 01 00 	mov    %rbp,0x1dae9(%rip)        # 21b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce da 01 00 	cmp    %rdi,0x1dace(%rip)        # 21b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 da 01 00 	mov    %rdi,0x1dac5(%rip)        # 21b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 db 01 00 	sub    %rdi,0x1db09(%rip)        # 21bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 da 01 00 	mov    0x1dab1(%rip),%rax        # 21ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa da 01 00 	lea    0x1daaa(%rip),%r8        # 21ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d be 00 00 	mov    0xbe5d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 7e 00 00 	lea    0x7e14(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad bd 00 00 	movslq 0xbdad(%rip),%rbp        # 10018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a be 01 00 	mov    0x1be7a(%rip),%rsi        # 20118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 be 01 00 	lea    0x1be76(%rip),%rcx        # 20120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b be 01 00 	addq   $0x1,0x1be4b(%rip)        # 20110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 bd 00 00    	mov    %ebx,0xbd48(%rip)        # 10018 <descent_active_phase>
    42d0:	48 89 05 41 be 01 00 	mov    %rax,0x1be41(%rip)        # 20118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 c4 01 00 	cmp    0x1c499(%rip),%rdi        # 207a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f c4 01 00 	mov    0x1c45f(%rip),%rax        # 20780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d c4 01 00 	mov    %rdi,0x1c43d(%rip)        # 20780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 c4 01 00 	mov    %rdi,0x1c419(%rip)        # 20788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 7e 00 00 	lea    0x7e18(%rip),%rsi        # c1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 7c 00 00 	lea    0x7cba(%rip),%rsi        # c07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 bc 00 00 	mov    0xbc28(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 7c 00 00 	lea    0x7c64(%rip),%rdx        # c083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 bc 00 00 	mov    0xbc10(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 bb 00 00 	mov    0xbb21(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 7a 00 00 	lea    0x7ad8(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 7b 00 00 	lea    0x7b45(%rip),%rdi        # c092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 7a 00 00 	lea    0x7acd(%rip),%rdi        # c0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 81 00 00 	lea    0x8110(%rip),%rdi        # c700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 85 00 	movdqa 0x8580(%rip),%xmm0        # cb90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa dd 01 00 	add    0x1ddaa(%rip),%rax        # 22418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 80 00 00 	lea    0x8064(%rip),%rdi        # c728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ba 01 00 	cmp    %rax,0x1ba05(%rip)        # 200e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ba 01 00 	add    0x1ba00(%rip),%rax        # 200f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d 80 00 00 	lea    0x804d(%rip),%rdi        # c758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 79 00 00 	lea    0x79a5(%rip),%r8        # c0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 77 00 00 	lea    0x77fa(%rip),%r8        # c0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 76 00 00 	lea    0x7697(%rip),%r8        # c0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 74 00 00 	lea    0x746f(%rip),%rdi        # c0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e 75 00 00 	lea    0x757e(%rip),%rsi        # c20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 ce 01 00 	mov    0x1ce85(%rip),%r9        # 21b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de ce 01 00 	mov    0x1cede(%rip),%r8        # 21be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 7a 00 00 	lea    0x7a97(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 ce 01 00 	mov    0x1cec6(%rip),%rcx        # 21be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 ce 01 	movsd  0x1ced4(%rip),%xmm1        # 21c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 ce 01 	movsd  0x1cec4(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 b3 00 00 	mov    0xb305(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 7e 00 	movdqa 0x7e28(%rip),%xmm0        # cba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f c9 01 00 	lea    0x1c97f(%rip),%rax        # 21700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 7e 00 	movdqa 0x7e51(%rip),%xmm2        # cbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 c9 01 00 	movaps %xmm0,0x1c925(%rip)        # 216c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d 7e 00 	movdqa 0x7e0d(%rip),%xmm0        # cbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 cd 01 00 01 	movl   $0x1,0x1cdb3(%rip)        # 21b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 c9 01 00 	movaps %xmm0,0x1c913(%rip)        # 216d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb 7d 00 	movdqa 0x7dfb(%rip),%xmm0        # cbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 14 c9 01 00 	movaps %xmm0,0x1c914(%rip)        # 216e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc 7d 00 	movdqa 0x7dfc(%rip),%xmm0        # cbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 15 c9 01 00 	movaps %xmm0,0x1c915(%rip)        # 216f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 b9 01 00 	lea    0x1b995(%rip),%r8        # 207c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 cc 01 00 	mov    %rax,0x1ccb0(%rip)        # 21b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e cc 01 00 	mov    %r12,0x1cc8e(%rip)        # 21b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 cc 01 00 	mov    %rax,0x1cc77(%rip)        # 21b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 cc 01 00 	mov    %rbx,0x1cc90(%rip)        # 21b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 cc 01 00 	mov    %rsi,0x1ccb9(%rip)        # 21bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 71 00 00 	lea    0x71f9(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 cc 01 00 	mov    %rax,0x1cc98(%rip)        # 21bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c cc 01 00    	mov    %eax,0x1cc1c(%rip)        # 21b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c b8 01 00 	mov    0x1b80c(%rip),%r8        # 20780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c b7 01 00 	mov    %rbx,0x1b73c(%rip)        # 20788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 b7 01 00 	mov    %r8,0x1b728(%rip)        # 20780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 70 00 00 	lea    0x705c(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d af 01 00 	lea    0x1af9d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 af 01 00 	movaps %xmm0,0x1af85(%rip)        # 200a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 af 01 00 	mov    %rax,0x1af61(%rip)        # 20088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 af 01 00 	movaps %xmm0,0x1af82(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 af 01 00 	movaps %xmm0,0x1af86(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 af 01 00 	mov    %rdx,0x1af87(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 6f 00 00 	lea    0x6fb3(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 b5 01 00 	mov    0x1b5b7(%rip),%rbx        # 20778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a ad 00 00 	mov    0xad8a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 75 00 00 	lea    0x7573(%rip),%rdi        # c830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d b4 01 00 	mov    0x1b48d(%rip),%rax        # 20780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 b4 01 00 	mov    %rdx,0x1b467(%rip)        # 20780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 b3 01 00 	mov    0x1b3b4(%rip),%rbx        # 20778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 b3 01 00 	mov    %rbx,0x1b371(%rip)        # 20778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 b3 01 00 	mov    %rdx,0x1b371(%rip)        # 20788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 b3 01 00 	lea    0x1b386(%rip),%rsi        # 207c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 cf 01 00 	addq   $0x1,0x1cf05(%rip)        # 22408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 73 00 00 	lea    0x7347(%rip),%rdi        # c860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 73 00 00 	lea    0x7358(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 6b 00 00 	lea    0x6bf7(%rip),%rdi        # c133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e b2 01 00 	lea    0x1b23e(%rip),%rcx        # 207c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f ce 01 00 	subq   $0x1,0x1ce3f(%rip)        # 22408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 72 00 00 	lea    0x72b3(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 ce 01 00 	cmpq   $0x0,0x1ce20(%rip)        # 22408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 cd 01 00 	sub    %rax,0x1cd75(%rip)        # 22410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 cd 01 00 	add    %r12,0x1cd53(%rip)        # 22410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af c4 01 00 	mov    0x1c4af(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac b0 01 00 	lea    0x1b0ac(%rip),%rax        # 207c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 c4 01 00 	add    0x1c403(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 c3 01 00 	mov    0x1c3d0(%rip),%rsi        # 21b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 c3 01 00 	mov    0x1c3f1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 c3 01 00 	add    0x1c3e5(%rip),%r8        # 21bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad c3 01 	addsd  0x1c3ad(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 af 01 00 	lea    0x1af62(%rip),%rax        # 207c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c c3 01 00 	sub    %rdi,0x1c36c(%rip)        # 21be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 c3 01 	movsd  %xmm0,0x1c384(%rip)        # 21c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e c3 01 00 	sub    %rdx,0x1c33e(%rip)        # 21be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 c3 01 	addsd  0x1c344(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 c3 01 	movsd  %xmm0,0x1c338(%rip)        # 21c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf c2 01 00 	mov    0x1c2cf(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 c2 01 00 	add    %rcx,0x1c2c9(%rip)        # 21bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 c2 01 00 	cmp    0x1c282(%rip),%r9        # 21bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 c2 01 00 	mov    %r9,0x1c279(%rip)        # 21bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a c2 01 00 	cmp    0x1c26a(%rip),%r9        # 21ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d c2 01 00 	mov    %r9,0x1c25d(%rip)        # 21ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 c1 01 00 	add    0x1c173(%rip),%rdi        # 21bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 ad 01 00 	lea    0x1ad50(%rip),%r15        # 207c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 c0 01 00 	add    0x1c0c0(%rip),%r12        # 21b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 c1 01 00 	add    0x1c119(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 c1 01 00 	cmp    %rax,0x1c118(%rip)        # 21be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 c1 01 00 	mov    %rax,0x1c109(%rip)        # 21be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 c1 01 00 	mov    %rax,0x1c108(%rip)        # 21be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 c1 01 	addsd  0x1c104(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc c0 01 	movsd  %xmm0,0x1c0fc(%rip)        # 21bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 c0 01 00    	mov    0x1c043(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f ac 01 00 	lea    0x1ac7f(%rip),%rdi        # 207c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 c0 01 00 	add    0x1c038(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 c0 01 00 	cmp    %rax,0x1c033(%rip)        # 21be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 c0 01 00 	mov    %rax,0x1c024(%rip)        # 21be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 c0 01 00 	mov    %rax,0x1c023(%rip)        # 21be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f c0 01 	addsd  0x1c01f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 c0 01 	movsd  %xmm0,0x1c017(%rip)        # 21bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce be 01 00    	mov    0x1bece(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 ab 01 00 	lea    0x1ab05(%rip),%rax        # 207c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb be 01 00 	add    0x1bebb(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba be 01 00 	cmp    %rax,0x1beba(%rip)        # 21be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab be 01 00 	mov    %rax,0x1beab(%rip)        # 21be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa be 01 00 	mov    %rax,0x1beaa(%rip)        # 21be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 be 01 	addsd  0x1bea6(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e be 01 	movsd  %xmm0,0x1be9e(%rip)        # 21bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 2c c6 01 00 	add    0x1c62c(%rip),%r9        # 22418 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_p_ad_push.constprop.0>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	49 89 d5             	mov    %rdx,%r13
    5ff9:	41 54                	push   %r12
    5ffb:	49 89 fc             	mov    %rdi,%r12
    5ffe:	55                   	push   %rbp
    5fff:	53                   	push   %rbx
    6000:	48 83 ec 38          	sub    $0x38,%rsp
    6004:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6009:	48 85 ff             	test   %rdi,%rdi
    600c:	79 09                	jns    6017 <fwp_p_ad_push.constprop.0+0x27>
    600e:	48 85 d2             	test   %rdx,%rdx
    6011:	0f 88 a9 01 00 00    	js     61c0 <fwp_p_ad_push.constprop.0+0x1d0>
    6017:	48 89 f8             	mov    %rdi,%rax
    601a:	48 89 0c 24          	mov    %rcx,(%rsp)
    601e:	48 09 d0             	or     %rdx,%rax
    6021:	0f 89 79 01 00 00    	jns    61a0 <fwp_p_ad_push.constprop.0+0x1b0>
    6027:	48 89 f8             	mov    %rdi,%rax
    602a:	48 c1 f8 20          	sar    $0x20,%rax
    602e:	48 85 ff             	test   %rdi,%rdi
    6031:	79 24                	jns    6057 <fwp_p_ad_push.constprop.0+0x67>
    6033:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6038:	48 89 d0             	mov    %rdx,%rax
    603b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6042:	00 
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	48 c1 f8 20          	sar    $0x20,%rax
    604a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6051:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6057:	48 89 c7             	mov    %rax,%rdi
    605a:	e8 71 e6 ff ff       	call   46d0 <fwp_tape_of>
    605f:	48 89 c3             	mov    %rax,%rbx
    6062:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6067:	0f 85 f0 02 00 00    	jne    635d <fwp_p_ad_push.constprop.0+0x36d>
    606d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6071:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6078:	0f 8f 51 02 00 00    	jg     62cf <fwp_p_ad_push.constprop.0+0x2df>
    607e:	44 89 e0             	mov    %r12d,%eax
    6081:	49 39 c7             	cmp    %rax,%r15
    6084:	0f 8e 51 02 00 00    	jle    62db <fwp_p_ad_push.constprop.0+0x2eb>
    608a:	4d 85 ed             	test   %r13,%r13
    608d:	78 0c                	js     609b <fwp_p_ad_push.constprop.0+0xab>
    608f:	44 89 e8             	mov    %r13d,%eax
    6092:	49 39 c7             	cmp    %rax,%r15
    6095:	0f 8e 40 02 00 00    	jle    62db <fwp_p_ad_push.constprop.0+0x2eb>
    609b:	4d 89 fe             	mov    %r15,%r14
    609e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    60a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    60a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    60ac:	0f 87 1d 02 00 00    	ja     62cf <fwp_p_ad_push.constprop.0+0x2df>
    60b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    60b6:	48 39 e8             	cmp    %rbp,%rax
    60b9:	0f 8e 31 01 00 00    	jle    61f0 <fwp_p_ad_push.constprop.0+0x200>
    60bf:	48 85 ed             	test   %rbp,%rbp
    60c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    60c7:	48 0f 44 e9          	cmove  %rcx,%rbp
    60cb:	48 39 e8             	cmp    %rbp,%rax
    60ce:	7e 20                	jle    60f0 <fwp_p_ad_push.constprop.0+0x100>
    60d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    60d7:	0f 8f 03 01 00 00    	jg     61e0 <fwp_p_ad_push.constprop.0+0x1f0>
    60dd:	48 01 ed             	add    %rbp,%rbp
    60e0:	48 39 e8             	cmp    %rbp,%rax
    60e3:	7f eb                	jg     60d0 <fwp_p_ad_push.constprop.0+0xe0>
    60e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60ec:	00 00 00 00 
    60f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    60f7:	00 
    60f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60fc:	48 89 c6             	mov    %rax,%rsi
    60ff:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6104:	e8 c7 d4 ff ff       	call   35d0 <realloc@plt>
    6109:	48 85 c0             	test   %rax,%rax
    610c:	0f 84 d5 01 00 00    	je     62e7 <fwp_p_ad_push.constprop.0+0x2f7>
    6112:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6116:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    611a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    611e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6122:	48 89 e9             	mov    %rbp,%rcx
    6125:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6129:	48 c1 e1 04          	shl    $0x4,%rcx
    612d:	48 89 ce             	mov    %rcx,%rsi
    6130:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6135:	e8 96 d4 ff ff       	call   35d0 <realloc@plt>
    613a:	48 85 c0             	test   %rax,%rax
    613d:	0f 84 a4 01 00 00    	je     62e7 <fwp_p_ad_push.constprop.0+0x2f7>
    6143:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6147:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    614c:	4d 85 f6             	test   %r14,%r14
    614f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6153:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6158:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    615f:	00 
    6160:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6167:	00 
    6168:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    616c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6173:	00 
    6174:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6178:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    617c:	0f 85 e6 00 00 00    	jne    6268 <fwp_p_ad_push.constprop.0+0x278>
    6182:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6186:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    618a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    618e:	49 01 c8             	add    %rcx,%r8
    6191:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6195:	eb 79                	jmp    6210 <fwp_p_ad_push.constprop.0+0x220>
    6197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    619e:	00 00 
    61a0:	48 89 d0             	mov    %rdx,%rax
    61a3:	48 c1 ff 20          	sar    $0x20,%rdi
    61a7:	48 c1 f8 20          	sar    $0x20,%rax
    61ab:	48 39 c7             	cmp    %rax,%rdi
    61ae:	0f 84 a3 fe ff ff    	je     6057 <fwp_p_ad_push.constprop.0+0x67>
    61b4:	48 8d 3d f5 66 00 00 	lea    0x66f5(%rip),%rdi        # c8b0 <_IO_stdin_used+0x8b0>
    61bb:	e8 30 e2 ff ff       	call   43f0 <fwp_trap>
    61c0:	48 83 c4 38          	add    $0x38,%rsp
    61c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61cb:	5b                   	pop    %rbx
    61cc:	5d                   	pop    %rbp
    61cd:	41 5c                	pop    %r12
    61cf:	41 5d                	pop    %r13
    61d1:	41 5e                	pop    %r14
    61d3:	41 5f                	pop    %r15
    61d5:	c3                   	ret
    61d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61dd:	00 00 00 
    61e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    61e5:	e9 06 ff ff ff       	jmp    60f0 <fwp_p_ad_push.constprop.0+0x100>
    61ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    61f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    61ff:	00 
    6200:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6207:	00 
    6208:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    620c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6210:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6216:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    621a:	4d 85 ed             	test   %r13,%r13
    621d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6222:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6228:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    622f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6233:	49 8d 47 01          	lea    0x1(%r15),%rax
    6237:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    623b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6241:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6245:	48 83 c4 38          	add    $0x38,%rsp
    6249:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6250:	ff ff ff 
    6253:	4c 21 e0             	and    %r12,%rax
    6256:	5b                   	pop    %rbx
    6257:	5d                   	pop    %rbp
    6258:	4c 09 f8             	or     %r15,%rax
    625b:	41 5c                	pop    %r12
    625d:	41 5d                	pop    %r13
    625f:	41 5e                	pop    %r14
    6261:	41 5f                	pop    %r15
    6263:	c3                   	ret
    6264:	0f 1f 40 00          	nopl   0x0(%rax)
    6268:	48 39 ca             	cmp    %rcx,%rdx
    626b:	49 89 d6             	mov    %rdx,%r14
    626e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6273:	48 0f 43 ca          	cmovae %rdx,%rcx
    6277:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    627c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6281:	48 29 d1             	sub    %rdx,%rcx
    6284:	4c 89 ca             	mov    %r9,%rdx
    6287:	e8 d4 d2 ff ff       	call   3560 <__memmove_chk@plt>
    628c:	4c 03 73 30          	add    0x30(%rbx),%r14
    6290:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6295:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6299:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    629e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    62a2:	48 03 7b 20          	add    0x20(%rbx),%rdi
    62a6:	4c 89 d2             	mov    %r10,%rdx
    62a9:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    62ae:	e8 5d d3 ff ff       	call   3610 <memmove@plt>
    62b3:	48 8b 43 30          	mov    0x30(%rbx),%rax
    62b7:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    62bb:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    62c0:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    62c5:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    62ca:	e9 b7 fe ff ff       	jmp    6186 <fwp_p_ad_push.constprop.0+0x196>
    62cf:	48 8d 3d 76 5e 00 00 	lea    0x5e76(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    62d6:	e8 15 e1 ff ff       	call   43f0 <fwp_trap>
    62db:	48 8d 3d 85 5e 00 00 	lea    0x5e85(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    62e2:	e8 09 e1 ff ff       	call   43f0 <fwp_trap>
    62e7:	48 89 df             	mov    %rbx,%rdi
    62ea:	e8 11 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    62ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    62f3:	e8 c8 d0 ff ff       	call   33c0 <free@plt>
    62f8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    62fc:	e8 bf d0 ff ff       	call   33c0 <free@plt>
    6301:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6305:	e8 b6 d0 ff ff       	call   33c0 <free@plt>
    630a:	31 c9                	xor    %ecx,%ecx
    630c:	31 c0                	xor    %eax,%eax
    630e:	31 d2                	xor    %edx,%edx
    6310:	89 53 04             	mov    %edx,0x4(%rbx)
    6313:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6317:	ba 13 00 00 00       	mov    $0x13,%edx
    631c:	be 01 00 00 00       	mov    $0x1,%esi
    6321:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6325:	48 8d 3d dc 5c 00 00 	lea    0x5cdc(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    632c:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6330:	48 8b 0d 09 9d 00 00 	mov    0x9d09(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    6337:	48 89 43 40          	mov    %rax,0x40(%rbx)
    633b:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    633f:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6343:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6347:	e8 34 d3 ff ff       	call   3680 <fwrite@plt>
    634c:	31 ff                	xor    %edi,%edi
    634e:	e8 6d d2 ff ff       	call   35c0 <fflush@plt>
    6353:	bf 66 00 00 00       	mov    $0x66,%edi
    6358:	e8 43 d3 ff ff       	call   36a0 <_Exit@plt>
    635d:	48 8d 3d 94 65 00 00 	lea    0x6594(%rip),%rdi        # c8f8 <_IO_stdin_used+0x8f8>
    6364:	e8 87 e0 ff ff       	call   43f0 <fwp_trap>
    6369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006370 <w107>:
    6370:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6374:	41 55                	push   %r13
    6376:	48 89 fa             	mov    %rdi,%rdx
    6379:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    637d:	41 54                	push   %r12
    637f:	49 89 fc             	mov    %rdi,%r12
    6382:	55                   	push   %rbp
    6383:	53                   	push   %rbx
    6384:	48 89 f3             	mov    %rsi,%rbx
    6387:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    638c:	48 89 f1             	mov    %rsi,%rcx
    638f:	48 83 ec 28          	sub    $0x28,%rsp
    6393:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6399:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    639f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    63a5:	e8 46 fc ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    63aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    63b0:	48 89 da             	mov    %rbx,%rdx
    63b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    63b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63c0:	00 f0 3f 
    63c3:	48 89 c7             	mov    %rax,%rdi
    63c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    63cd:	00 f0 bf 
    63d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    63d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63db:	e8 10 fc ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    63e0:	f2 0f 10 05 38 68 00 	movsd  0x6838(%rip),%xmm0        # cc20 <msg.4+0xb0>
    63e7:	00 
    63e8:	4c 89 e7             	mov    %r12,%rdi
    63eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    63f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    63f8:	00 f0 3f 
    63fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6402:	49 89 c5             	mov    %rax,%r13
    6405:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    640c:	00 f0 bf 
    640f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6414:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    641a:	e8 d1 fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    641f:	48 89 e9             	mov    %rbp,%rcx
    6422:	4c 89 ea             	mov    %r13,%rdx
    6425:	48 89 ee             	mov    %rbp,%rsi
    6428:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    642e:	4c 89 ef             	mov    %r13,%rdi
    6431:	49 89 c4             	mov    %rax,%r12
    6434:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6438:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    643e:	e8 ad fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6443:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6449:	f2 0f 59 1d d7 67 00 	mulsd  0x67d7(%rip),%xmm3        # cc28 <msg.4+0xb8>
    6450:	00 
    6451:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6458:	00 59 40 
    645b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6460:	48 89 c2             	mov    %rax,%rdx
    6463:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    646a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6470:	e8 7b fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6475:	48 89 d9             	mov    %rbx,%rcx
    6478:	4c 89 e2             	mov    %r12,%rdx
    647b:	48 89 de             	mov    %rbx,%rsi
    647e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6484:	4c 89 e7             	mov    %r12,%rdi
    6487:	48 89 c5             	mov    %rax,%rbp
    648a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    648e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6494:	e8 57 fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6499:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    649f:	48 89 ea             	mov    %rbp,%rdx
    64a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    64a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    64af:	00 f0 3f 
    64b2:	48 89 c7             	mov    %rax,%rdi
    64b5:	48 89 ce             	mov    %rcx,%rsi
    64b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    64bd:	e8 2e fb ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    64c2:	48 83 c4 28          	add    $0x28,%rsp
    64c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	c3                   	ret
    64d2:	0f 1f 00             	nopl   (%rax)
    64d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64dc:	00 00 00 00 

00000000000064e0 <w164.constprop.0>:
    64e0:	41 54                	push   %r12
    64e2:	55                   	push   %rbp
    64e3:	53                   	push   %rbx
    64e4:	48 83 ec 10          	sub    $0x10,%rsp
    64e8:	4c 8b 27             	mov    (%rdi),%r12
    64eb:	4d 85 e4             	test   %r12,%r12
    64ee:	74 58                	je     6548 <w164.constprop.0+0x68>
    64f0:	48 89 fd             	mov    %rdi,%rbp
    64f3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64f7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64fe:	31 db                	xor    %ebx,%ebx
    6500:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6506:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    650b:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6512:	00 f0 3f 
    6515:	48 83 c3 02          	add    $0x2,%rbx
    6519:	48 89 ce             	mov    %rcx,%rsi
    651c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6522:	e8 c9 fa ff ff       	call   5ff0 <fwp_p_ad_push.constprop.0>
    6527:	4c 39 e3             	cmp    %r12,%rbx
    652a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6530:	48 89 c7             	mov    %rax,%rdi
    6533:	72 cb                	jb     6500 <w164.constprop.0+0x20>
    6535:	48 83 c4 10          	add    $0x10,%rsp
    6539:	48 89 f8             	mov    %rdi,%rax
    653c:	5b                   	pop    %rbx
    653d:	5d                   	pop    %rbp
    653e:	41 5c                	pop    %r12
    6540:	c3                   	ret
    6541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6548:	48 83 c4 10          	add    $0x10,%rsp
    654c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6553:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6557:	5b                   	pop    %rbx
    6558:	48 89 f8             	mov    %rdi,%rax
    655b:	5d                   	pop    %rbp
    655c:	41 5c                	pop    %r12
    655e:	c3                   	ret
    655f:	90                   	nop

0000000000006560 <fwp_data.part.0.constprop.0>:
    6560:	41 56                	push   %r14
    6562:	41 89 fe             	mov    %edi,%r14d
    6565:	41 54                	push   %r12
    6567:	49 89 f4             	mov    %rsi,%r12
    656a:	55                   	push   %rbp
    656b:	53                   	push   %rbx
    656c:	48 83 ec 08          	sub    $0x8,%rsp
    6570:	8b 05 ee b5 01 00    	mov    0x1b5ee(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    6576:	85 c0                	test   %eax,%eax
    6578:	0f 84 fa 00 00 00    	je     6678 <fwp_data.part.0.constprop.0+0x118>
    657e:	0f b6 05 dd b1 01 00 	movzbl 0x1b1dd(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    6585:	48 8d 15 34 a2 01 00 	lea    0x1a234(%rip),%rdx        # 207c0 <fwp_heap>
    658c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6593:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6597:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    659b:	48 8b 18             	mov    (%rax),%rbx
    659e:	48 85 db             	test   %rbx,%rbx
    65a1:	0f 84 a9 00 00 00    	je     6650 <fwp_data.part.0.constprop.0+0xf0>
    65a7:	48 8b 13             	mov    (%rbx),%rdx
    65aa:	48 f7 d2             	not    %rdx
    65ad:	48 89 10             	mov    %rdx,(%rax)
    65b0:	48 83 fd 18          	cmp    $0x18,%rbp
    65b4:	76 1b                	jbe    65d1 <fwp_data.part.0.constprop.0+0x71>
    65b6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    65ba:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    65be:	31 f6                	xor    %esi,%esi
    65c0:	48 c1 e8 03          	shr    $0x3,%rax
    65c4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    65cb:	00 
    65cc:	e8 ef ce ff ff       	call   34c0 <memset@plt>
    65d1:	48 89 e8             	mov    %rbp,%rax
    65d4:	48 03 05 05 b6 01 00 	add    0x1b605(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    65db:	0f 82 a8 00 00 00    	jb     6689 <fwp_data.part.0.constprop.0+0x129>
    65e1:	48 39 05 00 b6 01 00 	cmp    %rax,0x1b600(%rip)        # 21be8 <fwp_heap+0x1428>
    65e8:	48 89 05 f1 b5 01 00 	mov    %rax,0x1b5f1(%rip)        # 21be0 <fwp_heap+0x1420>
    65ef:	73 07                	jae    65f8 <fwp_data.part.0.constprop.0+0x98>
    65f1:	48 89 05 f0 b5 01 00 	mov    %rax,0x1b5f0(%rip)        # 21be8 <fwp_heap+0x1428>
    65f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    65fc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6601:	f2 0f 58 05 ef b5 01 	addsd  0x1b5ef(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    6608:	00 
    6609:	f2 0f 11 05 e7 b5 01 	movsd  %xmm0,0x1b5e7(%rip)        # 21bf8 <fwp_heap+0x1438>
    6610:	00 
    6611:	b8 02 00 00 00       	mov    $0x2,%eax
    6616:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    661b:	66 0f 6e c8          	movd   %eax,%xmm1
    661f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6623:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6627:	49 8b 04 24          	mov    (%r12),%rax
    662b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    662f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6634:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6638:	48 83 c4 08          	add    $0x8,%rsp
    663c:	48 89 d8             	mov    %rbx,%rax
    663f:	5b                   	pop    %rbx
    6640:	5d                   	pop    %rbp
    6641:	41 5c                	pop    %r12
    6643:	41 5e                	pop    %r14
    6645:	c3                   	ret
    6646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    664d:	00 00 00 
    6650:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6654:	48 85 db             	test   %rbx,%rbx
    6657:	74 1f                	je     6678 <fwp_data.part.0.constprop.0+0x118>
    6659:	48 8b 50 10          	mov    0x10(%rax),%rdx
    665d:	48 29 da             	sub    %rbx,%rdx
    6660:	48 39 ea             	cmp    %rbp,%rdx
    6663:	72 13                	jb     6678 <fwp_data.part.0.constprop.0+0x118>
    6665:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6669:	48 89 50 08          	mov    %rdx,0x8(%rax)
    666d:	e9 3e ff ff ff       	jmp    65b0 <fwp_data.part.0.constprop.0+0x50>
    6672:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6678:	31 f6                	xor    %esi,%esi
    667a:	bf 18 00 00 00       	mov    $0x18,%edi
    667f:	e8 0c f6 ff ff       	call   5c90 <fwp_heap_alloc>
    6684:	48 89 c3             	mov    %rax,%rbx
    6687:	eb 88                	jmp    6611 <fwp_data.part.0.constprop.0+0xb1>
    6689:	e8 22 d6 ff ff       	call   3cb0 <fwp_heap_oom>
    668e:	66 90                	xchg   %ax,%ax

0000000000006690 <fwp_rc_share>:
    6690:	48 8b 05 01 b5 01 00 	mov    0x1b501(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    6697:	48 2b 3d d2 b4 01 00 	sub    0x1b4d2(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    669e:	48 c1 e0 10          	shl    $0x10,%rax
    66a2:	48 39 c7             	cmp    %rax,%rdi
    66a5:	73 4a                	jae    66f1 <fwp_rc_share+0x61>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 c1 e8 10          	shr    $0x10,%rax
    66ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    66b2:	48 8b 05 ff b4 01 00 	mov    0x1b4ff(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    66b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    66bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    66c1:	48 85 d2             	test   %rdx,%rdx
    66c4:	74 2b                	je     66f1 <fwp_rc_share+0x61>
    66c6:	0f b6 08             	movzbl (%rax),%ecx
    66c9:	80 f9 02             	cmp    $0x2,%cl
    66cc:	74 2a                	je     66f8 <fwp_rc_share+0x68>
    66ce:	80 f9 01             	cmp    $0x1,%cl
    66d1:	75 1e                	jne    66f1 <fwp_rc_share+0x61>
    66d3:	8b 48 18             	mov    0x18(%rax),%ecx
    66d6:	0f b7 ff             	movzwl %di,%edi
    66d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    66dc:	48 0f af f9          	imul   %rcx,%rdi
    66e0:	48 c1 ef 20          	shr    $0x20,%rdi
    66e4:	48 39 c7             	cmp    %rax,%rdi
    66e7:	73 08                	jae    66f1 <fwp_rc_share+0x61>
    66e9:	48 01 fa             	add    %rdi,%rdx
    66ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    66ef:	75 0d                	jne    66fe <fwp_rc_share+0x6e>
    66f1:	c3                   	ret
    66f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66f8:	66 85 ff             	test   %di,%di
    66fb:	74 ef                	je     66ec <fwp_rc_share+0x5c>
    66fd:	c3                   	ret
    66fe:	50                   	push   %rax
    66ff:	48 8d 3d 22 62 00 00 	lea    0x6222(%rip),%rdi        # c928 <_IO_stdin_used+0x928>
    6706:	e8 e5 dc ff ff       	call   43f0 <fwp_trap>
    670b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006710 <fwp_rc_free_arr>:
    6710:	48 8b 15 81 b4 01 00 	mov    0x1b481(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6717:	48 89 f8             	mov    %rdi,%rax
    671a:	48 2b 05 4f b4 01 00 	sub    0x1b44f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6721:	48 c1 e2 10          	shl    $0x10,%rdx
    6725:	48 39 d0             	cmp    %rdx,%rax
    6728:	73 5b                	jae    6785 <fwp_rc_free_arr+0x75>
    672a:	48 89 c2             	mov    %rax,%rdx
    672d:	48 c1 ea 10          	shr    $0x10,%rdx
    6731:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6735:	48 8b 15 7c b4 01 00 	mov    0x1b47c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    673c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6740:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6744:	48 85 c9             	test   %rcx,%rcx
    6747:	74 3c                	je     6785 <fwp_rc_free_arr+0x75>
    6749:	0f b6 32             	movzbl (%rdx),%esi
    674c:	40 80 fe 02          	cmp    $0x2,%sil
    6750:	74 2e                	je     6780 <fwp_rc_free_arr+0x70>
    6752:	40 80 fe 01          	cmp    $0x1,%sil
    6756:	75 2d                	jne    6785 <fwp_rc_free_arr+0x75>
    6758:	8b 72 18             	mov    0x18(%rdx),%esi
    675b:	0f b7 c0             	movzwl %ax,%eax
    675e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6761:	48 0f af c6          	imul   %rsi,%rax
    6765:	48 c1 e8 20          	shr    $0x20,%rax
    6769:	48 39 d0             	cmp    %rdx,%rax
    676c:	73 17                	jae    6785 <fwp_rc_free_arr+0x75>
    676e:	48 01 c1             	add    %rax,%rcx
    6771:	80 39 01             	cmpb   $0x1,(%rcx)
    6774:	75 0f                	jne    6785 <fwp_rc_free_arr+0x75>
    6776:	e9 15 f0 ff ff       	jmp    5790 <fwp_mem_free>
    677b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6780:	66 85 c0             	test   %ax,%ax
    6783:	74 ec                	je     6771 <fwp_rc_free_arr+0x61>
    6785:	c3                   	ret
    6786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    678d:	00 00 00 

0000000000006790 <fwp_rc_dup>:
    6790:	f3 0f 1e fa          	endbr64
    6794:	48 8b 05 fd b3 01 00 	mov    0x1b3fd(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    679b:	48 2b 3d ce b3 01 00 	sub    0x1b3ce(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    67a2:	48 c1 e0 10          	shl    $0x10,%rax
    67a6:	48 39 c7             	cmp    %rax,%rdi
    67a9:	73 56                	jae    6801 <fwp_rc_dup+0x71>
    67ab:	48 89 f8             	mov    %rdi,%rax
    67ae:	48 c1 e8 10          	shr    $0x10,%rax
    67b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    67b6:	48 8b 05 fb b3 01 00 	mov    0x1b3fb(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    67bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    67c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    67c5:	48 85 c0             	test   %rax,%rax
    67c8:	74 37                	je     6801 <fwp_rc_dup+0x71>
    67ca:	0f b6 0a             	movzbl (%rdx),%ecx
    67cd:	80 f9 02             	cmp    $0x2,%cl
    67d0:	74 36                	je     6808 <fwp_rc_dup+0x78>
    67d2:	80 f9 01             	cmp    $0x1,%cl
    67d5:	75 2a                	jne    6801 <fwp_rc_dup+0x71>
    67d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    67da:	0f b7 ff             	movzwl %di,%edi
    67dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67e0:	48 0f af f9          	imul   %rcx,%rdi
    67e4:	48 c1 ef 20          	shr    $0x20,%rdi
    67e8:	48 39 d7             	cmp    %rdx,%rdi
    67eb:	73 14                	jae    6801 <fwp_rc_dup+0x71>
    67ed:	48 01 f8             	add    %rdi,%rax
    67f0:	0f b6 10             	movzbl (%rax),%edx
    67f3:	84 d2                	test   %dl,%dl
    67f5:	74 0a                	je     6801 <fwp_rc_dup+0x71>
    67f7:	80 fa fd             	cmp    $0xfd,%dl
    67fa:	77 14                	ja     6810 <fwp_rc_dup+0x80>
    67fc:	83 c2 01             	add    $0x1,%edx
    67ff:	88 10                	mov    %dl,(%rax)
    6801:	c3                   	ret
    6802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6808:	66 85 ff             	test   %di,%di
    680b:	74 e3                	je     67f0 <fwp_rc_dup+0x60>
    680d:	c3                   	ret
    680e:	66 90                	xchg   %ax,%ax
    6810:	48 89 c7             	mov    %rax,%rdi
    6813:	e9 18 ec ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    681f:	00 

0000000000006820 <fwp_drop0>:
    6820:	f3 0f 1e fa          	endbr64
    6824:	48 8b 15 6d b3 01 00 	mov    0x1b36d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    682b:	48 89 f8             	mov    %rdi,%rax
    682e:	48 2b 05 3b b3 01 00 	sub    0x1b33b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6835:	48 c1 e2 10          	shl    $0x10,%rdx
    6839:	48 39 d0             	cmp    %rdx,%rax
    683c:	0f 83 be 00 00 00    	jae    6900 <fwp_drop0+0xe0>
    6842:	48 83 ec 18          	sub    $0x18,%rsp
    6846:	4c 8d 05 73 9f 01 00 	lea    0x19f73(%rip),%r8        # 207c0 <fwp_heap>
    684d:	48 89 c2             	mov    %rax,%rdx
    6850:	48 c1 ea 10          	shr    $0x10,%rdx
    6854:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6858:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    685f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6863:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6867:	48 85 d2             	test   %rdx,%rdx
    686a:	74 3c                	je     68a8 <fwp_drop0+0x88>
    686c:	0f b6 31             	movzbl (%rcx),%esi
    686f:	40 80 fe 02          	cmp    $0x2,%sil
    6873:	74 3b                	je     68b0 <fwp_drop0+0x90>
    6875:	40 80 fe 01          	cmp    $0x1,%sil
    6879:	75 2d                	jne    68a8 <fwp_drop0+0x88>
    687b:	8b 71 18             	mov    0x18(%rcx),%esi
    687e:	0f b7 c0             	movzwl %ax,%eax
    6881:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6884:	48 0f af c6          	imul   %rsi,%rax
    6888:	48 c1 e8 20          	shr    $0x20,%rax
    688c:	48 39 c8             	cmp    %rcx,%rax
    688f:	73 17                	jae    68a8 <fwp_drop0+0x88>
    6891:	48 01 c2             	add    %rax,%rdx
    6894:	0f b6 02             	movzbl (%rdx),%eax
    6897:	84 c0                	test   %al,%al
    6899:	74 0d                	je     68a8 <fwp_drop0+0x88>
    689b:	3c 01                	cmp    $0x1,%al
    689d:	74 21                	je     68c0 <fwp_drop0+0xa0>
    689f:	3c ff                	cmp    $0xff,%al
    68a1:	74 65                	je     6908 <fwp_drop0+0xe8>
    68a3:	83 e8 01             	sub    $0x1,%eax
    68a6:	88 02                	mov    %al,(%rdx)
    68a8:	48 83 c4 18          	add    $0x18,%rsp
    68ac:	c3                   	ret
    68ad:	0f 1f 00             	nopl   (%rax)
    68b0:	66 85 c0             	test   %ax,%ax
    68b3:	74 df                	je     6894 <fwp_drop0+0x74>
    68b5:	48 83 c4 18          	add    $0x18,%rsp
    68b9:	c3                   	ret
    68ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    68c4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    68c9:	e8 42 fe ff ff       	call   6710 <fwp_rc_free_arr>
    68ce:	4c 8d 05 eb 9e 01 00 	lea    0x19eeb(%rip),%r8        # 207c0 <fwp_heap>
    68d5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    68da:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    68e1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    68e8:	48 c1 e2 10          	shl    $0x10,%rdx
    68ec:	48 39 d0             	cmp    %rdx,%rax
    68ef:	73 b7                	jae    68a8 <fwp_drop0+0x88>
    68f1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    68f6:	e9 52 ff ff ff       	jmp    684d <fwp_drop0+0x2d>
    68fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6900:	c3                   	ret
    6901:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6908:	48 89 d0             	mov    %rdx,%rax
    690b:	48 c1 e8 11          	shr    $0x11,%rax
    690f:	48 31 d0             	xor    %rdx,%rax
    6912:	48 89 c1             	mov    %rax,%rcx
    6915:	48 c1 e9 09          	shr    $0x9,%rcx
    6919:	48 31 c8             	xor    %rcx,%rax
    691c:	0f b6 c8             	movzbl %al,%ecx
    691f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6926:	00 
    6927:	48 85 c0             	test   %rax,%rax
    692a:	75 1d                	jne    6949 <fwp_drop0+0x129>
    692c:	eb 56                	jmp    6984 <fwp_drop0+0x164>
    692e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    693c:	00 00 00 00 
    6940:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6944:	48 85 c0             	test   %rax,%rax
    6947:	74 3b                	je     6984 <fwp_drop0+0x164>
    6949:	48 89 c1             	mov    %rax,%rcx
    694c:	48 39 10             	cmp    %rdx,(%rax)
    694f:	75 ef                	jne    6940 <fwp_drop0+0x120>
    6951:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6955:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6959:	48 89 48 08          	mov    %rcx,0x8(%rax)
    695d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6964:	0f 85 3e ff ff ff    	jne    68a8 <fwp_drop0+0x88>
    696a:	48 89 d7             	mov    %rdx,%rdi
    696d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6972:	e8 d9 eb ff ff       	call   5550 <fwp_rc_forget_slot>
    6977:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    697c:	c6 02 fe             	movb   $0xfe,(%rdx)
    697f:	e9 24 ff ff ff       	jmp    68a8 <fwp_drop0+0x88>
    6984:	48 8d 3d fd 5e 00 00 	lea    0x5efd(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    698b:	e8 60 da ff ff       	call   43f0 <fwp_trap>

0000000000006990 <fwp_arg_drop12>:
    6990:	f3 0f 1e fa          	endbr64
    6994:	85 f6                	test   %esi,%esi
    6996:	75 04                	jne    699c <fwp_arg_drop12+0xc>
    6998:	85 d2                	test   %edx,%edx
    699a:	75 04                	jne    69a0 <fwp_arg_drop12+0x10>
    699c:	c3                   	ret
    699d:	0f 1f 00             	nopl   (%rax)
    69a0:	48 8b 3f             	mov    (%rdi),%rdi
    69a3:	e9 78 fe ff ff       	jmp    6820 <fwp_drop0>
    69a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    69af:	00 

00000000000069b0 <fwp_drop1>:
    69b0:	f3 0f 1e fa          	endbr64
    69b4:	48 8b 15 dd b1 01 00 	mov    0x1b1dd(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    69bb:	48 89 f8             	mov    %rdi,%rax
    69be:	48 2b 05 ab b1 01 00 	sub    0x1b1ab(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    69c5:	48 c1 e2 10          	shl    $0x10,%rdx
    69c9:	48 39 d0             	cmp    %rdx,%rax
    69cc:	0f 83 be 00 00 00    	jae    6a90 <fwp_drop1+0xe0>
    69d2:	48 83 ec 18          	sub    $0x18,%rsp
    69d6:	4c 8d 05 e3 9d 01 00 	lea    0x19de3(%rip),%r8        # 207c0 <fwp_heap>
    69dd:	48 89 c2             	mov    %rax,%rdx
    69e0:	48 c1 ea 10          	shr    $0x10,%rdx
    69e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69e8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    69ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69f7:	48 85 d2             	test   %rdx,%rdx
    69fa:	74 3c                	je     6a38 <fwp_drop1+0x88>
    69fc:	0f b6 31             	movzbl (%rcx),%esi
    69ff:	40 80 fe 02          	cmp    $0x2,%sil
    6a03:	74 3b                	je     6a40 <fwp_drop1+0x90>
    6a05:	40 80 fe 01          	cmp    $0x1,%sil
    6a09:	75 2d                	jne    6a38 <fwp_drop1+0x88>
    6a0b:	8b 71 18             	mov    0x18(%rcx),%esi
    6a0e:	0f b7 c0             	movzwl %ax,%eax
    6a11:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a14:	48 0f af c6          	imul   %rsi,%rax
    6a18:	48 c1 e8 20          	shr    $0x20,%rax
    6a1c:	48 39 c8             	cmp    %rcx,%rax
    6a1f:	73 17                	jae    6a38 <fwp_drop1+0x88>
    6a21:	48 01 c2             	add    %rax,%rdx
    6a24:	0f b6 02             	movzbl (%rdx),%eax
    6a27:	84 c0                	test   %al,%al
    6a29:	74 0d                	je     6a38 <fwp_drop1+0x88>
    6a2b:	3c 01                	cmp    $0x1,%al
    6a2d:	74 21                	je     6a50 <fwp_drop1+0xa0>
    6a2f:	3c ff                	cmp    $0xff,%al
    6a31:	74 65                	je     6a98 <fwp_drop1+0xe8>
    6a33:	83 e8 01             	sub    $0x1,%eax
    6a36:	88 02                	mov    %al,(%rdx)
    6a38:	48 83 c4 18          	add    $0x18,%rsp
    6a3c:	c3                   	ret
    6a3d:	0f 1f 00             	nopl   (%rax)
    6a40:	66 85 c0             	test   %ax,%ax
    6a43:	74 df                	je     6a24 <fwp_drop1+0x74>
    6a45:	48 83 c4 18          	add    $0x18,%rsp
    6a49:	c3                   	ret
    6a4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a50:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6a54:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6a59:	e8 b2 fc ff ff       	call   6710 <fwp_rc_free_arr>
    6a5e:	4c 8d 05 5b 9d 01 00 	lea    0x19d5b(%rip),%r8        # 207c0 <fwp_heap>
    6a65:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6a6a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6a71:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6a78:	48 c1 e2 10          	shl    $0x10,%rdx
    6a7c:	48 39 d0             	cmp    %rdx,%rax
    6a7f:	73 b7                	jae    6a38 <fwp_drop1+0x88>
    6a81:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6a86:	e9 52 ff ff ff       	jmp    69dd <fwp_drop1+0x2d>
    6a8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a90:	c3                   	ret
    6a91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a98:	48 89 d0             	mov    %rdx,%rax
    6a9b:	48 c1 e8 11          	shr    $0x11,%rax
    6a9f:	48 31 d0             	xor    %rdx,%rax
    6aa2:	48 89 c1             	mov    %rax,%rcx
    6aa5:	48 c1 e9 09          	shr    $0x9,%rcx
    6aa9:	48 31 c8             	xor    %rcx,%rax
    6aac:	0f b6 c8             	movzbl %al,%ecx
    6aaf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6ab6:	00 
    6ab7:	48 85 c0             	test   %rax,%rax
    6aba:	75 0d                	jne    6ac9 <fwp_drop1+0x119>
    6abc:	eb 46                	jmp    6b04 <fwp_drop1+0x154>
    6abe:	66 90                	xchg   %ax,%ax
    6ac0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6ac4:	48 85 c0             	test   %rax,%rax
    6ac7:	74 3b                	je     6b04 <fwp_drop1+0x154>
    6ac9:	48 89 c1             	mov    %rax,%rcx
    6acc:	48 39 10             	cmp    %rdx,(%rax)
    6acf:	75 ef                	jne    6ac0 <fwp_drop1+0x110>
    6ad1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ad5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6ad9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6add:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ae4:	0f 85 4e ff ff ff    	jne    6a38 <fwp_drop1+0x88>
    6aea:	48 89 d7             	mov    %rdx,%rdi
    6aed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6af2:	e8 59 ea ff ff       	call   5550 <fwp_rc_forget_slot>
    6af7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6afc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6aff:	e9 34 ff ff ff       	jmp    6a38 <fwp_drop1+0x88>
    6b04:	48 8d 3d 7d 5d 00 00 	lea    0x5d7d(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    6b0b:	e8 e0 d8 ff ff       	call   43f0 <fwp_trap>

0000000000006b10 <fwp_closure_drop>:
    6b10:	48 8b 15 81 b0 01 00 	mov    0x1b081(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6b17:	48 89 f8             	mov    %rdi,%rax
    6b1a:	48 2b 05 4f b0 01 00 	sub    0x1b04f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6b21:	48 c1 e2 10          	shl    $0x10,%rdx
    6b25:	48 39 d0             	cmp    %rdx,%rax
    6b28:	73 6b                	jae    6b95 <fwp_closure_drop+0x85>
    6b2a:	48 89 c2             	mov    %rax,%rdx
    6b2d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b35:	48 8b 15 7c b0 01 00 	mov    0x1b07c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6b3c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b40:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b44:	48 85 d2             	test   %rdx,%rdx
    6b47:	74 4c                	je     6b95 <fwp_closure_drop+0x85>
    6b49:	0f b6 31             	movzbl (%rcx),%esi
    6b4c:	40 80 fe 02          	cmp    $0x2,%sil
    6b50:	74 3e                	je     6b90 <fwp_closure_drop+0x80>
    6b52:	40 80 fe 01          	cmp    $0x1,%sil
    6b56:	75 3d                	jne    6b95 <fwp_closure_drop+0x85>
    6b58:	8b 71 18             	mov    0x18(%rcx),%esi
    6b5b:	0f b7 c0             	movzwl %ax,%eax
    6b5e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b61:	48 0f af c6          	imul   %rsi,%rax
    6b65:	48 c1 e8 20          	shr    $0x20,%rax
    6b69:	48 39 c8             	cmp    %rcx,%rax
    6b6c:	73 27                	jae    6b95 <fwp_closure_drop+0x85>
    6b6e:	48 01 c2             	add    %rax,%rdx
    6b71:	0f b6 02             	movzbl (%rdx),%eax
    6b74:	84 c0                	test   %al,%al
    6b76:	74 1d                	je     6b95 <fwp_closure_drop+0x85>
    6b78:	3c 01                	cmp    $0x1,%al
    6b7a:	74 24                	je     6ba0 <fwp_closure_drop+0x90>
    6b7c:	3c ff                	cmp    $0xff,%al
    6b7e:	74 48                	je     6bc8 <fwp_closure_drop+0xb8>
    6b80:	83 e8 01             	sub    $0x1,%eax
    6b83:	88 02                	mov    %al,(%rdx)
    6b85:	c3                   	ret
    6b86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b8d:	00 00 00 
    6b90:	66 85 c0             	test   %ax,%ax
    6b93:	74 dc                	je     6b71 <fwp_closure_drop+0x61>
    6b95:	c3                   	ret
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 
    6ba0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6ba7:	ff ff 
    6ba9:	48 85 c0             	test   %rax,%rax
    6bac:	74 12                	je     6bc0 <fwp_closure_drop+0xb0>
    6bae:	48 89 fe             	mov    %rdi,%rsi
    6bb1:	48 89 c7             	mov    %rax,%rdi
    6bb4:	e9 97 d8 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bc0:	e9 3b da ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6bc5:	0f 1f 00             	nopl   (%rax)
    6bc8:	48 89 d0             	mov    %rdx,%rax
    6bcb:	48 8d 35 ee 9b 01 00 	lea    0x19bee(%rip),%rsi        # 207c0 <fwp_heap>
    6bd2:	48 83 ec 18          	sub    $0x18,%rsp
    6bd6:	48 c1 e8 11          	shr    $0x11,%rax
    6bda:	48 31 d0             	xor    %rdx,%rax
    6bdd:	48 89 c1             	mov    %rax,%rcx
    6be0:	48 c1 e9 09          	shr    $0x9,%rcx
    6be4:	48 31 c8             	xor    %rcx,%rax
    6be7:	0f b6 c8             	movzbl %al,%ecx
    6bea:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6bf1:	00 
    6bf2:	48 85 c0             	test   %rax,%rax
    6bf5:	75 12                	jne    6c09 <fwp_closure_drop+0xf9>
    6bf7:	eb 49                	jmp    6c42 <fwp_closure_drop+0x132>
    6bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c04:	48 85 c0             	test   %rax,%rax
    6c07:	74 39                	je     6c42 <fwp_closure_drop+0x132>
    6c09:	48 89 c1             	mov    %rax,%rcx
    6c0c:	48 39 10             	cmp    %rdx,(%rax)
    6c0f:	75 ef                	jne    6c00 <fwp_closure_drop+0xf0>
    6c11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6c24:	74 05                	je     6c2b <fwp_closure_drop+0x11b>
    6c26:	48 83 c4 18          	add    $0x18,%rsp
    6c2a:	c3                   	ret
    6c2b:	48 89 d7             	mov    %rdx,%rdi
    6c2e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c33:	e8 18 e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6c38:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c3d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6c40:	eb e4                	jmp    6c26 <fwp_closure_drop+0x116>
    6c42:	48 8d 3d 3f 5c 00 00 	lea    0x5c3f(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    6c49:	e8 a2 d7 ff ff       	call   43f0 <fwp_trap>
    6c4e:	66 90                	xchg   %ax,%ax

0000000000006c50 <fwp_owned_tape_release>:
    6c50:	48 85 ff             	test   %rdi,%rdi
    6c53:	0f 84 f7 00 00 00    	je     6d50 <fwp_owned_tape_release+0x100>
    6c59:	41 54                	push   %r12
    6c5b:	55                   	push   %rbp
    6c5c:	53                   	push   %rbx
    6c5d:	48 8b 07             	mov    (%rdi),%rax
    6c60:	48 85 c0             	test   %rax,%rax
    6c63:	74 08                	je     6c6d <fwp_owned_tape_release+0x1d>
    6c65:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6c69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c6d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6c71:	48 85 d2             	test   %rdx,%rdx
    6c74:	74 03                	je     6c79 <fwp_owned_tape_release+0x29>
    6c76:	48 89 02             	mov    %rax,(%rdx)
    6c79:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6c7d:	48 89 fb             	mov    %rdi,%rbx
    6c80:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	0f 84 89 00 00 00    	je     6d16 <fwp_owned_tape_release+0xc6>
    6c8d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6c91:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6c95:	7e 47                	jle    6cde <fwp_owned_tape_release+0x8e>
    6c97:	31 ed                	xor    %ebp,%ebp
    6c99:	eb 0d                	jmp    6ca8 <fwp_owned_tape_release+0x58>
    6c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ca0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ca4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ca8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6cac:	49 89 ec             	mov    %rbp,%r12
    6caf:	48 83 c5 01          	add    $0x1,%rbp
    6cb3:	49 c1 e4 04          	shl    $0x4,%r12
    6cb7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6cbb:	ff d0                	call   *%rax
    6cbd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6cc1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6cc6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6cca:	ff 50 68             	call   *0x68(%rax)
    6ccd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6cd1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6cd5:	48 39 e8             	cmp    %rbp,%rax
    6cd8:	7f c6                	jg     6ca0 <fwp_owned_tape_release+0x50>
    6cda:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6cde:	31 ed                	xor    %ebp,%ebp
    6ce0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6ce5:	7e 28                	jle    6d0f <fwp_owned_tape_release+0xbf>
    6ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cee:	00 00 
    6cf0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6cf4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6cf8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6cfc:	74 07                	je     6d05 <fwp_owned_tape_release+0xb5>
    6cfe:	ff 52 68             	call   *0x68(%rdx)
    6d01:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d05:	48 83 c5 01          	add    $0x1,%rbp
    6d09:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6d0d:	7f e1                	jg     6cf0 <fwp_owned_tape_release+0xa0>
    6d0f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d13:	ff 52 68             	call   *0x68(%rdx)
    6d16:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6d1a:	e8 f1 fd ff ff       	call   6b10 <fwp_closure_drop>
    6d1f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6d23:	e8 e8 fd ff ff       	call   6b10 <fwp_closure_drop>
    6d28:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6d2c:	e8 df fd ff ff       	call   6b10 <fwp_closure_drop>
    6d31:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6d35:	e8 56 ea ff ff       	call   5790 <fwp_mem_free>
    6d3a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6d3e:	e8 4d ea ff ff       	call   5790 <fwp_mem_free>
    6d43:	48 89 df             	mov    %rbx,%rdi
    6d46:	5b                   	pop    %rbx
    6d47:	5d                   	pop    %rbp
    6d48:	41 5c                	pop    %r12
    6d4a:	e9 41 ea ff ff       	jmp    5790 <fwp_mem_free>
    6d4f:	90                   	nop
    6d50:	c3                   	ret
    6d51:	0f 1f 40 00          	nopl   0x0(%rax)
    6d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d5c:	00 00 00 00 

0000000000006d60 <fwp_tape_finish>:
    6d60:	f3 0f 1e fa          	endbr64
    6d64:	41 56                	push   %r14
    6d66:	48 8d 3d 33 93 01 00 	lea    0x19333(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6d6d:	41 55                	push   %r13
    6d6f:	41 54                	push   %r12
    6d71:	55                   	push   %rbp
    6d72:	53                   	push   %rbx
    6d73:	e8 98 d3 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6d78:	48 83 3d 68 93 01 00 	cmpq   $0x0,0x19368(%rip)        # 200e8 <fwp_ntapes>
    6d7f:	00 
    6d80:	48 c7 05 fd 92 01 00 	movq   $0x0,0x192fd(%rip)        # 20088 <fwp_tape_cached_bytes>
    6d87:	00 00 00 00 
    6d8b:	7e 68                	jle    6df5 <fwp_tape_finish+0x95>
    6d8d:	45 31 e4             	xor    %r12d,%r12d
    6d90:	31 ed                	xor    %ebp,%ebp
    6d92:	0f 1f 00             	nopl   (%rax)
    6d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d9c:	00 00 00 00 
    6da0:	48 8b 1d 49 93 01 00 	mov    0x19349(%rip),%rbx        # 200f0 <fwp_tapes>
    6da7:	48 83 c5 01          	add    $0x1,%rbp
    6dab:	4c 01 e3             	add    %r12,%rbx
    6dae:	49 83 c4 68          	add    $0x68,%r12
    6db2:	48 89 df             	mov    %rbx,%rdi
    6db5:	e8 46 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6dba:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6dbe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6dc2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6dc6:	e8 f5 c5 ff ff       	call   33c0 <free@plt>
    6dcb:	4c 89 f7             	mov    %r14,%rdi
    6dce:	e8 ed c5 ff ff       	call   33c0 <free@plt>
    6dd3:	4c 89 ef             	mov    %r13,%rdi
    6dd6:	e8 e5 c5 ff ff       	call   33c0 <free@plt>
    6ddb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6ddf:	e8 6c fe ff ff       	call   6c50 <fwp_owned_tape_release>
    6de4:	48 39 2d fd 92 01 00 	cmp    %rbp,0x192fd(%rip)        # 200e8 <fwp_ntapes>
    6deb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6df2:	00 
    6df3:	7f ab                	jg     6da0 <fwp_tape_finish+0x40>
    6df5:	48 8b 3d f4 92 01 00 	mov    0x192f4(%rip),%rdi        # 200f0 <fwp_tapes>
    6dfc:	e8 bf c5 ff ff       	call   33c0 <free@plt>
    6e01:	5b                   	pop    %rbx
    6e02:	5d                   	pop    %rbp
    6e03:	48 c7 05 e2 92 01 00 	movq   $0x0,0x192e2(%rip)        # 200f0 <fwp_tapes>
    6e0a:	00 00 00 00 
    6e0e:	48 c7 05 c7 92 01 00 	movq   $0x0,0x192c7(%rip)        # 200e0 <fwp_tapes_cap>
    6e15:	00 00 00 00 
    6e19:	41 5c                	pop    %r12
    6e1b:	48 c7 05 c2 92 01 00 	movq   $0x0,0x192c2(%rip)        # 200e8 <fwp_ntapes>
    6e22:	00 00 00 00 
    6e26:	41 5d                	pop    %r13
    6e28:	48 c7 05 a5 92 01 00 	movq   $0x0,0x192a5(%rip)        # 200d8 <fwp_tape_next_slot>
    6e2f:	00 00 00 00 
    6e33:	41 5e                	pop    %r14
    6e35:	c3                   	ret
    6e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e3d:	00 00 00 

0000000000006e40 <fwp_tape_scope_release>:
    6e40:	f3 0f 1e fa          	endbr64
    6e44:	41 55                	push   %r13
    6e46:	41 54                	push   %r12
    6e48:	55                   	push   %rbp
    6e49:	53                   	push   %rbx
    6e4a:	48 83 ec 58          	sub    $0x58,%rsp
    6e4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e55:	00 00 
    6e57:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6e5c:	48 63 07             	movslq (%rdi),%rax
    6e5f:	85 c0                	test   %eax,%eax
    6e61:	0f 88 05 01 00 00    	js     6f6c <fwp_tape_scope_release+0x12c>
    6e67:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6e6e:	ec c4 4e 
    6e71:	48 89 fb             	mov    %rdi,%rbx
    6e74:	eb 3c                	jmp    6eb2 <fwp_tape_scope_release+0x72>
    6e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e7d:	00 00 00 
    6e80:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6e85:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6e89:	e8 32 c5 ff ff       	call   33c0 <free@plt>
    6e8e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6e92:	e8 29 c5 ff ff       	call   33c0 <free@plt>
    6e97:	4c 89 ef             	mov    %r13,%rdi
    6e9a:	e8 21 c5 ff ff       	call   33c0 <free@plt>
    6e9f:	4c 89 e7             	mov    %r12,%rdi
    6ea2:	e8 a9 fd ff ff       	call   6c50 <fwp_owned_tape_release>
    6ea7:	48 63 03             	movslq (%rbx),%rax
    6eaa:	85 c0                	test   %eax,%eax
    6eac:	0f 88 ba 00 00 00    	js     6f6c <fwp_tape_scope_release+0x12c>
    6eb2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6eb6:	48 8b 35 33 92 01 00 	mov    0x19233(%rip),%rsi        # 200f0 <fwp_tapes>
    6ebd:	4c 01 c6             	add    %r8,%rsi
    6ec0:	48 89 f7             	mov    %rsi,%rdi
    6ec3:	e8 38 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ec8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6ecd:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6ed2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6ed9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6edd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6ee1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6ee8:	00 
    6ee9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6eee:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6ef2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6ef7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6efb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6f00:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6f07:	00 
    6f08:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6f0f:	00 
    6f10:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6f17:	00 
    6f18:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6f1d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6f22:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6f26:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6f2a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6f2e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6f34:	77 18                	ja     6f4e <fwp_tape_scope_release+0x10e>
    6f36:	49 c1 f8 03          	sar    $0x3,%r8
    6f3a:	4c 0f af c5          	imul   %rbp,%r8
    6f3e:	4c 3b 05 93 91 01 00 	cmp    0x19193(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6f45:	7d 07                	jge    6f4e <fwp_tape_scope_release+0x10e>
    6f47:	4c 89 05 8a 91 01 00 	mov    %r8,0x1918a(%rip)        # 200d8 <fwp_tape_next_slot>
    6f4e:	4d 85 e4             	test   %r12,%r12
    6f51:	0f 85 29 ff ff ff    	jne    6e80 <fwp_tape_scope_release+0x40>
    6f57:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6f5c:	e8 0f e1 ff ff       	call   5070 <fwp_tape_buffers_release>
    6f61:	48 63 03             	movslq (%rbx),%rax
    6f64:	85 c0                	test   %eax,%eax
    6f66:	0f 89 46 ff ff ff    	jns    6eb2 <fwp_tape_scope_release+0x72>
    6f6c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6f71:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f78:	00 00 
    6f7a:	75 0b                	jne    6f87 <fwp_tape_scope_release+0x147>
    6f7c:	48 83 c4 58          	add    $0x58,%rsp
    6f80:	5b                   	pop    %rbx
    6f81:	5d                   	pop    %rbp
    6f82:	41 5c                	pop    %r12
    6f84:	41 5d                	pop    %r13
    6f86:	c3                   	ret
    6f87:	e8 d4 c4 ff ff       	call   3460 <__stack_chk_fail@plt>
    6f8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006f90 <fwp_task_dispose>:
    6f90:	53                   	push   %rbx
    6f91:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f95:	0f 84 ab c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f9b:	48 89 fb             	mov    %rdi,%rbx
    6f9e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6fa3:	0f 85 9d c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6fa9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6fad:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6fb4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6fbb:	00 
    6fbc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6fc0:	48 85 ff             	test   %rdi,%rdi
    6fc3:	74 07                	je     6fcc <fwp_task_dispose+0x3c>
    6fc5:	48 85 c0             	test   %rax,%rax
    6fc8:	74 02                	je     6fcc <fwp_task_dispose+0x3c>
    6fca:	ff d0                	call   *%rax
    6fcc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6fd3:	e8 b8 e7 ff ff       	call   5790 <fwp_mem_free>
    6fd8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6fdf:	00 00 00 00 
    6fe3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6fe7:	74 6f                	je     7058 <fwp_task_dispose+0xc8>
    6fe9:	48 8b 15 a8 ab 01 00 	mov    0x1aba8(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6ff0:	48 89 d8             	mov    %rbx,%rax
    6ff3:	48 2b 05 76 ab 01 00 	sub    0x1ab76(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6ffa:	48 c1 e2 10          	shl    $0x10,%rdx
    6ffe:	48 39 d0             	cmp    %rdx,%rax
    7001:	73 4c                	jae    704f <fwp_task_dispose+0xbf>
    7003:	48 89 c2             	mov    %rax,%rdx
    7006:	48 c1 ea 10          	shr    $0x10,%rdx
    700a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    700e:	48 8b 15 a3 ab 01 00 	mov    0x1aba3(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7015:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7019:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    701d:	48 85 c9             	test   %rcx,%rcx
    7020:	74 2d                	je     704f <fwp_task_dispose+0xbf>
    7022:	0f b6 32             	movzbl (%rdx),%esi
    7025:	40 80 fe 02          	cmp    $0x2,%sil
    7029:	74 3d                	je     7068 <fwp_task_dispose+0xd8>
    702b:	40 80 fe 01          	cmp    $0x1,%sil
    702f:	75 1e                	jne    704f <fwp_task_dispose+0xbf>
    7031:	8b 72 18             	mov    0x18(%rdx),%esi
    7034:	0f b7 c0             	movzwl %ax,%eax
    7037:	8b 52 1c             	mov    0x1c(%rdx),%edx
    703a:	48 0f af c6          	imul   %rsi,%rax
    703e:	48 c1 e8 20          	shr    $0x20,%rax
    7042:	48 39 d0             	cmp    %rdx,%rax
    7045:	73 08                	jae    704f <fwp_task_dispose+0xbf>
    7047:	48 01 c1             	add    %rax,%rcx
    704a:	80 39 01             	cmpb   $0x1,(%rcx)
    704d:	74 09                	je     7058 <fwp_task_dispose+0xc8>
    704f:	5b                   	pop    %rbx
    7050:	c3                   	ret
    7051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7058:	48 89 df             	mov    %rbx,%rdi
    705b:	5b                   	pop    %rbx
    705c:	e9 2f e7 ff ff       	jmp    5790 <fwp_mem_free>
    7061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7068:	66 85 c0             	test   %ax,%ax
    706b:	74 dd                	je     704a <fwp_task_dispose+0xba>
    706d:	5b                   	pop    %rbx
    706e:	c3                   	ret
    706f:	90                   	nop

0000000000007070 <fwp_free_zombie>:
    7070:	48 8b 15 19 97 01 00 	mov    0x19719(%rip),%rdx        # 20790 <fwp_zombie>
    7077:	48 85 d2             	test   %rdx,%rdx
    707a:	0f 84 98 00 00 00    	je     7118 <fwp_free_zombie+0xa8>
    7080:	48 3b 15 19 97 01 00 	cmp    0x19719(%rip),%rdx        # 207a0 <fwp_cur>
    7087:	0f 84 8b 00 00 00    	je     7118 <fwp_free_zombie+0xa8>
    708d:	48 83 ec 18          	sub    $0x18,%rsp
    7091:	48 63 05 cc 90 01 00 	movslq 0x190cc(%rip),%rax        # 20164 <fwp_stack_pool_n>
    7098:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    709c:	83 f8 3f             	cmp    $0x3f,%eax
    709f:	7f 7f                	jg     7120 <fwp_free_zombie+0xb0>
    70a1:	8d 48 01             	lea    0x1(%rax),%ecx
    70a4:	89 0d ba 90 01 00    	mov    %ecx,0x190ba(%rip)        # 20164 <fwp_stack_pool_n>
    70aa:	48 8d 0d cf 90 01 00 	lea    0x190cf(%rip),%rcx        # 20180 <fwp_stack_pool>
    70b1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    70b5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    70bc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70c0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    70c7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    70cb:	48 85 c9             	test   %rcx,%rcx
    70ce:	0f 84 fc 00 00 00    	je     71d0 <fwp_free_zombie+0x160>
    70d4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    70db:	48 85 c0             	test   %rax,%rax
    70de:	74 07                	je     70e7 <fwp_free_zombie+0x77>
    70e0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    70e7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    70ea:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70ee:	48 c7 05 97 96 01 00 	movq   $0x0,0x19697(%rip)        # 20790 <fwp_zombie>
    70f5:	00 00 00 00 
    70f9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7100:	85 c0                	test   %eax,%eax
    7102:	74 34                	je     7138 <fwp_free_zombie+0xc8>
    7104:	83 f8 01             	cmp    $0x1,%eax
    7107:	0f 84 b3 00 00 00    	je     71c0 <fwp_free_zombie+0x150>
    710d:	48 83 c4 18          	add    $0x18,%rsp
    7111:	c3                   	ret
    7112:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7118:	c3                   	ret
    7119:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7120:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7124:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7129:	e8 b2 c4 ff ff       	call   35e0 <munmap@plt>
    712e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7133:	eb 80                	jmp    70b5 <fwp_free_zombie+0x45>
    7135:	0f 1f 00             	nopl   (%rax)
    7138:	48 8b 0d 59 aa 01 00 	mov    0x1aa59(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    713f:	48 89 d0             	mov    %rdx,%rax
    7142:	48 2b 05 27 aa 01 00 	sub    0x1aa27(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7149:	48 c1 e1 10          	shl    $0x10,%rcx
    714d:	48 39 c8             	cmp    %rcx,%rax
    7150:	73 bb                	jae    710d <fwp_free_zombie+0x9d>
    7152:	48 89 c1             	mov    %rax,%rcx
    7155:	48 c1 e9 10          	shr    $0x10,%rcx
    7159:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    715d:	48 8b 0d 54 aa 01 00 	mov    0x1aa54(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    7164:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7168:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    716c:	48 85 c9             	test   %rcx,%rcx
    716f:	74 9c                	je     710d <fwp_free_zombie+0x9d>
    7171:	0f b6 3e             	movzbl (%rsi),%edi
    7174:	40 80 ff 02          	cmp    $0x2,%dil
    7178:	74 66                	je     71e0 <fwp_free_zombie+0x170>
    717a:	40 80 ff 01          	cmp    $0x1,%dil
    717e:	75 8d                	jne    710d <fwp_free_zombie+0x9d>
    7180:	8b 7e 18             	mov    0x18(%rsi),%edi
    7183:	0f b7 c0             	movzwl %ax,%eax
    7186:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7189:	48 0f af c7          	imul   %rdi,%rax
    718d:	48 c1 e8 20          	shr    $0x20,%rax
    7191:	48 39 f0             	cmp    %rsi,%rax
    7194:	0f 83 73 ff ff ff    	jae    710d <fwp_free_zombie+0x9d>
    719a:	48 01 c1             	add    %rax,%rcx
    719d:	0f b6 01             	movzbl (%rcx),%eax
    71a0:	84 c0                	test   %al,%al
    71a2:	0f 84 65 ff ff ff    	je     710d <fwp_free_zombie+0x9d>
    71a8:	3c 01                	cmp    $0x1,%al
    71aa:	74 14                	je     71c0 <fwp_free_zombie+0x150>
    71ac:	3c ff                	cmp    $0xff,%al
    71ae:	74 3b                	je     71eb <fwp_free_zombie+0x17b>
    71b0:	83 e8 01             	sub    $0x1,%eax
    71b3:	88 01                	mov    %al,(%rcx)
    71b5:	e9 53 ff ff ff       	jmp    710d <fwp_free_zombie+0x9d>
    71ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71c0:	48 89 d7             	mov    %rdx,%rdi
    71c3:	48 83 c4 18          	add    $0x18,%rsp
    71c7:	e9 c4 fd ff ff       	jmp    6f90 <fwp_task_dispose>
    71cc:	0f 1f 40 00          	nopl   0x0(%rax)
    71d0:	48 89 05 91 95 01 00 	mov    %rax,0x19591(%rip)        # 20768 <fwp_tasks_active>
    71d7:	e9 ff fe ff ff       	jmp    70db <fwp_free_zombie+0x6b>
    71dc:	0f 1f 40 00          	nopl   0x0(%rax)
    71e0:	66 85 c0             	test   %ax,%ax
    71e3:	0f 85 24 ff ff ff    	jne    710d <fwp_free_zombie+0x9d>
    71e9:	eb b2                	jmp    719d <fwp_free_zombie+0x12d>
    71eb:	48 89 ca             	mov    %rcx,%rdx
    71ee:	48 8d 35 cb 95 01 00 	lea    0x195cb(%rip),%rsi        # 207c0 <fwp_heap>
    71f5:	48 c1 ea 11          	shr    $0x11,%rdx
    71f9:	48 31 ca             	xor    %rcx,%rdx
    71fc:	48 89 d0             	mov    %rdx,%rax
    71ff:	48 c1 e8 09          	shr    $0x9,%rax
    7203:	48 31 c2             	xor    %rax,%rdx
    7206:	0f b6 d2             	movzbl %dl,%edx
    7209:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7210:	00 
    7211:	48 85 c0             	test   %rax,%rax
    7214:	75 13                	jne    7229 <fwp_free_zombie+0x1b9>
    7216:	eb 4c                	jmp    7264 <fwp_free_zombie+0x1f4>
    7218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    721f:	00 
    7220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7224:	48 85 c0             	test   %rax,%rax
    7227:	74 3b                	je     7264 <fwp_free_zombie+0x1f4>
    7229:	48 89 c2             	mov    %rax,%rdx
    722c:	48 39 08             	cmp    %rcx,(%rax)
    722f:	75 ef                	jne    7220 <fwp_free_zombie+0x1b0>
    7231:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7235:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7239:	48 89 50 08          	mov    %rdx,0x8(%rax)
    723d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7244:	0f 85 c3 fe ff ff    	jne    710d <fwp_free_zombie+0x9d>
    724a:	48 89 cf             	mov    %rcx,%rdi
    724d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7252:	e8 f9 e2 ff ff       	call   5550 <fwp_rc_forget_slot>
    7257:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    725c:	c6 01 fe             	movb   $0xfe,(%rcx)
    725f:	e9 a9 fe ff ff       	jmp    710d <fwp_free_zombie+0x9d>
    7264:	48 8d 3d 1d 56 00 00 	lea    0x561d(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    726b:	e8 80 d1 ff ff       	call   43f0 <fwp_trap>

0000000000007270 <fwp_block>:
    7270:	48 83 ec 08          	sub    $0x8,%rsp
    7274:	48 8b 05 0d 95 01 00 	mov    0x1950d(%rip),%rax        # 20788 <fwp_ready_head>
    727b:	48 85 c0             	test   %rax,%rax
    727e:	0f 84 1c 01 00 00    	je     73a0 <fwp_block+0x130>
    7284:	90                   	nop
    7285:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    728c:	00 00 00 00 
    7290:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7297:	48 89 15 ea 94 01 00 	mov    %rdx,0x194ea(%rip)        # 20788 <fwp_ready_head>
    729e:	48 85 d2             	test   %rdx,%rdx
    72a1:	0f 84 19 01 00 00    	je     73c0 <fwp_block+0x150>
    72a7:	48 8b 15 f2 94 01 00 	mov    0x194f2(%rip),%rdx        # 207a0 <fwp_cur>
    72ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    72b2:	48 39 c2             	cmp    %rax,%rdx
    72b5:	0f 84 d5 00 00 00    	je     7390 <fwp_block+0x120>
    72bb:	48 8b 0d 66 b1 01 00 	mov    0x1b166(%rip),%rcx        # 22428 <fwp_state_owners>
    72c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    72c6:	48 89 05 d3 94 01 00 	mov    %rax,0x194d3(%rip)        # 207a0 <fwp_cur>
    72cd:	f3 0f 7e 05 7b b1 01 	movq   0x1b17b(%rip),%xmm0        # 22450 <fwp_foreign_callbacks>
    72d4:	00 
    72d5:	0f 16 05 64 b1 01 00 	movhps 0x1b164(%rip),%xmm0        # 22440 <fwp_state>
    72dc:	f3 0f 7e 0d 64 b1 01 	movq   0x1b164(%rip),%xmm1        # 22448 <fwp_handlers>
    72e3:	00 
    72e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    72eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    72f2:	0f 16 0d 5f b1 01 00 	movhps 0x1b15f(%rip),%xmm1        # 22458 <fwp_cleanups>
    72f9:	f3 0f 7e 05 37 b1 01 	movq   0x1b137(%rip),%xmm0        # 22438 <fwp_state_len>
    7300:	00 
    7301:	0f 16 05 28 b1 01 00 	movhps 0x1b128(%rip),%xmm0        # 22430 <fwp_state_cap>
    7308:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    730f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7316:	48 8b 70 08          	mov    0x8(%rax),%rsi
    731a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7321:	48 89 0d 20 b1 01 00 	mov    %rcx,0x1b120(%rip)        # 22448 <fwp_handlers>
    7328:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    732f:	48 89 0d 22 b1 01 00 	mov    %rcx,0x1b122(%rip)        # 22458 <fwp_cleanups>
    7336:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    733d:	48 89 0d 0c b1 01 00 	mov    %rcx,0x1b10c(%rip)        # 22450 <fwp_foreign_callbacks>
    7344:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    734b:	48 89 0d ee b0 01 00 	mov    %rcx,0x1b0ee(%rip)        # 22440 <fwp_state>
    7352:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7359:	48 89 0d d8 b0 01 00 	mov    %rcx,0x1b0d8(%rip)        # 22438 <fwp_state_len>
    7360:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7367:	48 89 0d c2 b0 01 00 	mov    %rcx,0x1b0c2(%rip)        # 22430 <fwp_state_cap>
    736e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7375:	48 89 0d ac b0 01 00 	mov    %rcx,0x1b0ac(%rip)        # 22428 <fwp_state_owners>
    737c:	e8 0f c1 ff ff       	call   3490 <swapcontext@plt>
    7381:	f3 0f 1e fa          	endbr64
    7385:	e8 e6 fc ff ff       	call   7070 <fwp_free_zombie>
    738a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7390:	8b 05 ca 8d 01 00    	mov    0x18dca(%rip),%eax        # 20160 <fwp_slice>
    7396:	85 c0                	test   %eax,%eax
    7398:	74 36                	je     73d0 <fwp_block+0x160>
    739a:	48 83 c4 08          	add    $0x8,%rsp
    739e:	c3                   	ret
    739f:	90                   	nop
    73a0:	e8 fb dd ff ff       	call   51a0 <fwp_poll_events>
    73a5:	48 8b 05 dc 93 01 00 	mov    0x193dc(%rip),%rax        # 20788 <fwp_ready_head>
    73ac:	48 85 c0             	test   %rax,%rax
    73af:	0f 85 db fe ff ff    	jne    7290 <fwp_block+0x20>
    73b5:	eb e9                	jmp    73a0 <fwp_block+0x130>
    73b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73be:	00 00 
    73c0:	48 c7 05 b5 93 01 00 	movq   $0x0,0x193b5(%rip)        # 20780 <fwp_ready_tail>
    73c7:	00 00 00 00 
    73cb:	e9 d7 fe ff ff       	jmp    72a7 <fwp_block+0x37>
    73d0:	48 8d 3d ad 4d 00 00 	lea    0x4dad(%rip),%rdi        # c184 <_IO_stdin_used+0x184>
    73d7:	e8 c4 bf ff ff       	call   33a0 <getenv@plt>
    73dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    73e1:	48 85 c0             	test   %rax,%rax
    73e4:	74 05                	je     73eb <fwp_block+0x17b>
    73e6:	80 38 00             	cmpb   $0x0,(%rax)
    73e9:	75 0b                	jne    73f6 <fwp_block+0x186>
    73eb:	89 15 6f 8d 01 00    	mov    %edx,0x18d6f(%rip)        # 20160 <fwp_slice>
    73f1:	48 83 c4 08          	add    $0x8,%rsp
    73f5:	c3                   	ret
    73f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    73fb:	31 f6                	xor    %esi,%esi
    73fd:	48 89 c7             	mov    %rax,%rdi
    7400:	e8 4b c1 ff ff       	call   3550 <strtoll@plt>
    7405:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7409:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7410:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7415:	0f 46 d0             	cmovbe %eax,%edx
    7418:	eb d1                	jmp    73eb <fwp_block+0x17b>
    741a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007420 <fwp_owned_entry161>:
    7420:	f3 0f 1e fa          	endbr64
    7424:	41 56                	push   %r14
    7426:	55                   	push   %rbp
    7427:	53                   	push   %rbx
    7428:	48 83 ec 10          	sub    $0x10,%rsp
    742c:	48 8b 07             	mov    (%rdi),%rax
    742f:	48 03 47 10          	add    0x10(%rdi),%rax
    7433:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7438:	0f 80 b7 01 00 00    	jo     75f5 <fwp_owned_entry161+0x1d5>
    743e:	49 89 c6             	mov    %rax,%r14
    7441:	8b 05 1d a7 01 00    	mov    0x1a71d(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    7447:	48 8d 15 72 93 01 00 	lea    0x19372(%rip),%rdx        # 207c0 <fwp_heap>
    744e:	85 c0                	test   %eax,%eax
    7450:	0f 84 52 01 00 00    	je     75a8 <fwp_owned_entry161+0x188>
    7456:	0f b6 05 05 a3 01 00 	movzbl 0x1a305(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    745d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7464:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7468:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    746c:	48 8b 18             	mov    (%rax),%rbx
    746f:	48 85 db             	test   %rbx,%rbx
    7472:	0f 84 08 01 00 00    	je     7580 <fwp_owned_entry161+0x160>
    7478:	48 8b 13             	mov    (%rbx),%rdx
    747b:	48 f7 d2             	not    %rdx
    747e:	48 89 10             	mov    %rdx,(%rax)
    7481:	48 83 fd 18          	cmp    $0x18,%rbp
    7485:	76 27                	jbe    74ae <fwp_owned_entry161+0x8e>
    7487:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    748b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    748f:	31 f6                	xor    %esi,%esi
    7491:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7497:	48 c1 e8 03          	shr    $0x3,%rax
    749b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    74a2:	00 
    74a3:	e8 18 c0 ff ff       	call   34c0 <memset@plt>
    74a8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    74ae:	48 89 e8             	mov    %rbp,%rax
    74b1:	48 03 05 28 a7 01 00 	add    0x1a728(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    74b8:	0f 82 3c 01 00 00    	jb     75fa <fwp_owned_entry161+0x1da>
    74be:	48 39 05 23 a7 01 00 	cmp    %rax,0x1a723(%rip)        # 21be8 <fwp_heap+0x1428>
    74c5:	48 89 05 14 a7 01 00 	mov    %rax,0x1a714(%rip)        # 21be0 <fwp_heap+0x1420>
    74cc:	73 07                	jae    74d5 <fwp_owned_entry161+0xb5>
    74ce:	48 89 05 13 a7 01 00 	mov    %rax,0x1a713(%rip)        # 21be8 <fwp_heap+0x1428>
    74d5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    74d9:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    74de:	f2 0f 58 0d 12 a7 01 	addsd  0x1a712(%rip),%xmm1        # 21bf8 <fwp_heap+0x1438>
    74e5:	00 
    74e6:	f2 0f 11 0d 0a a7 01 	movsd  %xmm1,0x1a70a(%rip)        # 21bf8 <fwp_heap+0x1438>
    74ed:	00 
    74ee:	48 8b 05 3b 57 00 00 	mov    0x573b(%rip),%rax        # cc30 <msg.4+0xc0>
    74f5:	66 49 0f 6e d6       	movq   %r14,%xmm2
    74fa:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    74fe:	48 89 03             	mov    %rax,(%rbx)
    7501:	48 89 d8             	mov    %rbx,%rax
    7504:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7508:	48 8b 15 89 a6 01 00 	mov    0x1a689(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    750f:	48 2b 05 5a a6 01 00 	sub    0x1a65a(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7516:	48 c1 e2 10          	shl    $0x10,%rdx
    751a:	48 39 d0             	cmp    %rdx,%rax
    751d:	73 53                	jae    7572 <fwp_owned_entry161+0x152>
    751f:	48 89 c2             	mov    %rax,%rdx
    7522:	48 c1 ea 10          	shr    $0x10,%rdx
    7526:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    752a:	48 8b 15 87 a6 01 00 	mov    0x1a687(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7531:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7535:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7539:	48 85 ed             	test   %rbp,%rbp
    753c:	74 34                	je     7572 <fwp_owned_entry161+0x152>
    753e:	0f b6 0a             	movzbl (%rdx),%ecx
    7541:	80 f9 02             	cmp    $0x2,%cl
    7544:	0f 84 86 00 00 00    	je     75d0 <fwp_owned_entry161+0x1b0>
    754a:	80 f9 01             	cmp    $0x1,%cl
    754d:	75 23                	jne    7572 <fwp_owned_entry161+0x152>
    754f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7552:	0f b7 c0             	movzwl %ax,%eax
    7555:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7558:	48 0f af c1          	imul   %rcx,%rax
    755c:	48 c1 e8 20          	shr    $0x20,%rax
    7560:	48 39 d0             	cmp    %rdx,%rax
    7563:	73 0d                	jae    7572 <fwp_owned_entry161+0x152>
    7565:	48 01 c5             	add    %rax,%rbp
    7568:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    756c:	74 7a                	je     75e8 <fwp_owned_entry161+0x1c8>
    756e:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7572:	48 83 c4 10          	add    $0x10,%rsp
    7576:	48 89 d8             	mov    %rbx,%rax
    7579:	5b                   	pop    %rbx
    757a:	5d                   	pop    %rbp
    757b:	41 5e                	pop    %r14
    757d:	c3                   	ret
    757e:	66 90                	xchg   %ax,%ax
    7580:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7584:	48 85 db             	test   %rbx,%rbx
    7587:	74 1f                	je     75a8 <fwp_owned_entry161+0x188>
    7589:	48 8b 50 10          	mov    0x10(%rax),%rdx
    758d:	48 29 da             	sub    %rbx,%rdx
    7590:	48 39 ea             	cmp    %rbp,%rdx
    7593:	72 13                	jb     75a8 <fwp_owned_entry161+0x188>
    7595:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7599:	48 89 50 08          	mov    %rdx,0x8(%rax)
    759d:	e9 df fe ff ff       	jmp    7481 <fwp_owned_entry161+0x61>
    75a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75a8:	31 f6                	xor    %esi,%esi
    75aa:	bf 18 00 00 00       	mov    $0x18,%edi
    75af:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    75b5:	e8 d6 e6 ff ff       	call   5c90 <fwp_heap_alloc>
    75ba:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    75c0:	48 89 c3             	mov    %rax,%rbx
    75c3:	e9 26 ff ff ff       	jmp    74ee <fwp_owned_entry161+0xce>
    75c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    75cf:	00 
    75d0:	66 85 c0             	test   %ax,%ax
    75d3:	74 93                	je     7568 <fwp_owned_entry161+0x148>
    75d5:	48 83 c4 10          	add    $0x10,%rsp
    75d9:	48 89 d8             	mov    %rbx,%rax
    75dc:	5b                   	pop    %rbx
    75dd:	5d                   	pop    %rbp
    75de:	41 5e                	pop    %r14
    75e0:	c3                   	ret
    75e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75e8:	48 89 ef             	mov    %rbp,%rdi
    75eb:	e8 60 df ff ff       	call   5550 <fwp_rc_forget_slot>
    75f0:	e9 79 ff ff ff       	jmp    756e <fwp_owned_entry161+0x14e>
    75f5:	e8 06 c1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    75fa:	e8 b1 c6 ff ff       	call   3cb0 <fwp_heap_oom>
    75ff:	90                   	nop

0000000000007600 <e161>:
    7600:	f3 0f 1e fa          	endbr64
    7604:	41 56                	push   %r14
    7606:	55                   	push   %rbp
    7607:	53                   	push   %rbx
    7608:	48 83 ec 10          	sub    $0x10,%rsp
    760c:	48 8b 07             	mov    (%rdi),%rax
    760f:	48 03 47 10          	add    0x10(%rdi),%rax
    7613:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7618:	0f 80 bf 01 00 00    	jo     77dd <e161+0x1dd>
    761e:	49 89 c6             	mov    %rax,%r14
    7621:	8b 05 3d a5 01 00    	mov    0x1a53d(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    7627:	48 8d 15 92 91 01 00 	lea    0x19192(%rip),%rdx        # 207c0 <fwp_heap>
    762e:	85 c0                	test   %eax,%eax
    7630:	0f 84 62 01 00 00    	je     7798 <e161+0x198>
    7636:	0f b6 05 25 a1 01 00 	movzbl 0x1a125(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    763d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7644:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7648:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    764c:	48 8b 18             	mov    (%rax),%rbx
    764f:	48 85 db             	test   %rbx,%rbx
    7652:	0f 84 18 01 00 00    	je     7770 <e161+0x170>
    7658:	48 8b 13             	mov    (%rbx),%rdx
    765b:	48 f7 d2             	not    %rdx
    765e:	48 89 10             	mov    %rdx,(%rax)
    7661:	48 83 fd 18          	cmp    $0x18,%rbp
    7665:	76 27                	jbe    768e <e161+0x8e>
    7667:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    766b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    766f:	31 f6                	xor    %esi,%esi
    7671:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7677:	48 c1 e8 03          	shr    $0x3,%rax
    767b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7682:	00 
    7683:	e8 38 be ff ff       	call   34c0 <memset@plt>
    7688:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    768e:	48 89 e8             	mov    %rbp,%rax
    7691:	48 03 05 48 a5 01 00 	add    0x1a548(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    7698:	0f 82 44 01 00 00    	jb     77e2 <e161+0x1e2>
    769e:	48 39 05 43 a5 01 00 	cmp    %rax,0x1a543(%rip)        # 21be8 <fwp_heap+0x1428>
    76a5:	48 89 05 34 a5 01 00 	mov    %rax,0x1a534(%rip)        # 21be0 <fwp_heap+0x1420>
    76ac:	73 07                	jae    76b5 <e161+0xb5>
    76ae:	48 89 05 33 a5 01 00 	mov    %rax,0x1a533(%rip)        # 21be8 <fwp_heap+0x1428>
    76b5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    76b9:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    76be:	f2 0f 58 0d 32 a5 01 	addsd  0x1a532(%rip),%xmm1        # 21bf8 <fwp_heap+0x1438>
    76c5:	00 
    76c6:	f2 0f 11 0d 2a a5 01 	movsd  %xmm1,0x1a52a(%rip)        # 21bf8 <fwp_heap+0x1438>
    76cd:	00 
    76ce:	48 8b 05 5b 55 00 00 	mov    0x555b(%rip),%rax        # cc30 <msg.4+0xc0>
    76d5:	66 49 0f 6e d6       	movq   %r14,%xmm2
    76da:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    76de:	48 89 03             	mov    %rax,(%rbx)
    76e1:	48 89 d8             	mov    %rbx,%rax
    76e4:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    76e8:	48 8b 15 a9 a4 01 00 	mov    0x1a4a9(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    76ef:	48 2b 05 7a a4 01 00 	sub    0x1a47a(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    76f6:	48 c1 e2 10          	shl    $0x10,%rdx
    76fa:	48 39 d0             	cmp    %rdx,%rax
    76fd:	73 57                	jae    7756 <e161+0x156>
    76ff:	48 89 c2             	mov    %rax,%rdx
    7702:	48 c1 ea 10          	shr    $0x10,%rdx
    7706:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    770a:	48 8b 15 a7 a4 01 00 	mov    0x1a4a7(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7711:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7715:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7719:	48 85 ed             	test   %rbp,%rbp
    771c:	74 38                	je     7756 <e161+0x156>
    771e:	0f b6 0a             	movzbl (%rdx),%ecx
    7721:	80 f9 02             	cmp    $0x2,%cl
    7724:	0f 84 96 00 00 00    	je     77c0 <e161+0x1c0>
    772a:	80 f9 01             	cmp    $0x1,%cl
    772d:	75 27                	jne    7756 <e161+0x156>
    772f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7732:	0f b7 c0             	movzwl %ax,%eax
    7735:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7738:	48 0f af c1          	imul   %rcx,%rax
    773c:	48 c1 e8 20          	shr    $0x20,%rax
    7740:	48 39 d0             	cmp    %rdx,%rax
    7743:	73 11                	jae    7756 <e161+0x156>
    7745:	48 01 c5             	add    %rax,%rbp
    7748:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    774c:	0f 84 7e 00 00 00    	je     77d0 <e161+0x1d0>
    7752:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7756:	48 89 df             	mov    %rbx,%rdi
    7759:	e8 32 ef ff ff       	call   6690 <fwp_rc_share>
    775e:	48 83 c4 10          	add    $0x10,%rsp
    7762:	48 89 d8             	mov    %rbx,%rax
    7765:	5b                   	pop    %rbx
    7766:	5d                   	pop    %rbp
    7767:	41 5e                	pop    %r14
    7769:	c3                   	ret
    776a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7770:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7774:	48 85 db             	test   %rbx,%rbx
    7777:	74 1f                	je     7798 <e161+0x198>
    7779:	48 8b 50 10          	mov    0x10(%rax),%rdx
    777d:	48 29 da             	sub    %rbx,%rdx
    7780:	48 39 ea             	cmp    %rbp,%rdx
    7783:	72 13                	jb     7798 <e161+0x198>
    7785:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7789:	48 89 50 08          	mov    %rdx,0x8(%rax)
    778d:	e9 cf fe ff ff       	jmp    7661 <e161+0x61>
    7792:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7798:	31 f6                	xor    %esi,%esi
    779a:	bf 18 00 00 00       	mov    $0x18,%edi
    779f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    77a5:	e8 e6 e4 ff ff       	call   5c90 <fwp_heap_alloc>
    77aa:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    77b0:	48 89 c3             	mov    %rax,%rbx
    77b3:	e9 16 ff ff ff       	jmp    76ce <e161+0xce>
    77b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    77bf:	00 
    77c0:	66 85 c0             	test   %ax,%ax
    77c3:	75 91                	jne    7756 <e161+0x156>
    77c5:	eb 81                	jmp    7748 <e161+0x148>
    77c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77ce:	00 00 
    77d0:	48 89 ef             	mov    %rbp,%rdi
    77d3:	e8 78 dd ff ff       	call   5550 <fwp_rc_forget_slot>
    77d8:	e9 75 ff ff ff       	jmp    7752 <e161+0x152>
    77dd:	e8 1e bf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    77e2:	e8 c9 c4 ff ff       	call   3cb0 <fwp_heap_oom>
    77e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77ee:	00 00 

00000000000077f0 <fwp_drop4>:
    77f0:	48 8b 15 a1 a3 01 00 	mov    0x1a3a1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    77f7:	48 89 f8             	mov    %rdi,%rax
    77fa:	48 2b 05 6f a3 01 00 	sub    0x1a36f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7801:	48 c1 e2 10          	shl    $0x10,%rdx
    7805:	48 39 d0             	cmp    %rdx,%rax
    7808:	0f 83 52 01 00 00    	jae    7960 <fwp_drop4+0x170>
    780e:	48 83 ec 18          	sub    $0x18,%rsp
    7812:	4c 8d 05 a7 8f 01 00 	lea    0x18fa7(%rip),%r8        # 207c0 <fwp_heap>
    7819:	48 89 c2             	mov    %rax,%rdx
    781c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7823:	48 c1 ea 10          	shr    $0x10,%rdx
    7827:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    782b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    782f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7833:	48 85 d2             	test   %rdx,%rdx
    7836:	74 46                	je     787e <fwp_drop4+0x8e>
    7838:	44 0f b6 09          	movzbl (%rcx),%r9d
    783c:	41 80 f9 02          	cmp    $0x2,%r9b
    7840:	0f 84 ca 00 00 00    	je     7910 <fwp_drop4+0x120>
    7846:	41 80 f9 01          	cmp    $0x1,%r9b
    784a:	75 32                	jne    787e <fwp_drop4+0x8e>
    784c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7850:	0f b7 c0             	movzwl %ax,%eax
    7853:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7856:	49 0f af c1          	imul   %r9,%rax
    785a:	48 c1 e8 20          	shr    $0x20,%rax
    785e:	48 39 c8             	cmp    %rcx,%rax
    7861:	73 1b                	jae    787e <fwp_drop4+0x8e>
    7863:	48 01 c2             	add    %rax,%rdx
    7866:	0f b6 02             	movzbl (%rdx),%eax
    7869:	84 c0                	test   %al,%al
    786b:	74 11                	je     787e <fwp_drop4+0x8e>
    786d:	3c 01                	cmp    $0x1,%al
    786f:	74 17                	je     7888 <fwp_drop4+0x98>
    7871:	3c ff                	cmp    $0xff,%al
    7873:	0f 84 ef 00 00 00    	je     7968 <fwp_drop4+0x178>
    7879:	83 e8 01             	sub    $0x1,%eax
    787c:	88 02                	mov    %al,(%rdx)
    787e:	48 83 c4 18          	add    $0x18,%rsp
    7882:	c3                   	ret
    7883:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7888:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    788c:	0f 88 8e 00 00 00    	js     7920 <fwp_drop4+0x130>
    7892:	48 8b 15 ff a2 01 00 	mov    0x1a2ff(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7899:	48 89 f8             	mov    %rdi,%rax
    789c:	48 2b 05 cd a2 01 00 	sub    0x1a2cd(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    78a3:	48 c1 e2 10          	shl    $0x10,%rdx
    78a7:	48 39 d0             	cmp    %rdx,%rax
    78aa:	73 d2                	jae    787e <fwp_drop4+0x8e>
    78ac:	48 89 c2             	mov    %rax,%rdx
    78af:	48 c1 ea 10          	shr    $0x10,%rdx
    78b3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    78b7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    78bb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78bf:	48 85 c9             	test   %rcx,%rcx
    78c2:	74 ba                	je     787e <fwp_drop4+0x8e>
    78c4:	0f b6 32             	movzbl (%rdx),%esi
    78c7:	40 80 fe 02          	cmp    $0x2,%sil
    78cb:	74 33                	je     7900 <fwp_drop4+0x110>
    78cd:	40 80 fe 01          	cmp    $0x1,%sil
    78d1:	75 ab                	jne    787e <fwp_drop4+0x8e>
    78d3:	8b 72 18             	mov    0x18(%rdx),%esi
    78d6:	0f b7 c0             	movzwl %ax,%eax
    78d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78dc:	48 0f af c6          	imul   %rsi,%rax
    78e0:	48 c1 e8 20          	shr    $0x20,%rax
    78e4:	48 39 d0             	cmp    %rdx,%rax
    78e7:	73 95                	jae    787e <fwp_drop4+0x8e>
    78e9:	48 01 c1             	add    %rax,%rcx
    78ec:	80 39 01             	cmpb   $0x1,(%rcx)
    78ef:	75 8d                	jne    787e <fwp_drop4+0x8e>
    78f1:	48 83 c4 18          	add    $0x18,%rsp
    78f5:	e9 96 de ff ff       	jmp    5790 <fwp_mem_free>
    78fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7900:	66 85 c0             	test   %ax,%ax
    7903:	74 e7                	je     78ec <fwp_drop4+0xfc>
    7905:	48 83 c4 18          	add    $0x18,%rsp
    7909:	c3                   	ret
    790a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7910:	66 85 c0             	test   %ax,%ax
    7913:	0f 84 4d ff ff ff    	je     7866 <fwp_drop4+0x76>
    7919:	48 83 c4 18          	add    $0x18,%rsp
    791d:	c3                   	ret
    791e:	66 90                	xchg   %ax,%ax
    7920:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7924:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7929:	e8 e2 ed ff ff       	call   6710 <fwp_rc_free_arr>
    792e:	4c 8d 05 8b 8e 01 00 	lea    0x18e8b(%rip),%r8        # 207c0 <fwp_heap>
    7935:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    793a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7941:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7948:	48 c1 e2 10          	shl    $0x10,%rdx
    794c:	48 39 d0             	cmp    %rdx,%rax
    794f:	0f 83 29 ff ff ff    	jae    787e <fwp_drop4+0x8e>
    7955:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    795a:	e9 ba fe ff ff       	jmp    7819 <fwp_drop4+0x29>
    795f:	90                   	nop
    7960:	c3                   	ret
    7961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7968:	48 89 d0             	mov    %rdx,%rax
    796b:	48 c1 e8 11          	shr    $0x11,%rax
    796f:	48 31 d0             	xor    %rdx,%rax
    7972:	48 89 c1             	mov    %rax,%rcx
    7975:	48 c1 e9 09          	shr    $0x9,%rcx
    7979:	48 31 c8             	xor    %rcx,%rax
    797c:	0f b6 c8             	movzbl %al,%ecx
    797f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7986:	00 
    7987:	48 85 c0             	test   %rax,%rax
    798a:	75 1d                	jne    79a9 <fwp_drop4+0x1b9>
    798c:	eb 56                	jmp    79e4 <fwp_drop4+0x1f4>
    798e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    799c:	00 00 00 00 
    79a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    79a4:	48 85 c0             	test   %rax,%rax
    79a7:	74 3b                	je     79e4 <fwp_drop4+0x1f4>
    79a9:	48 89 c1             	mov    %rax,%rcx
    79ac:	48 39 10             	cmp    %rdx,(%rax)
    79af:	75 ef                	jne    79a0 <fwp_drop4+0x1b0>
    79b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    79b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    79b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    79bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    79c4:	0f 85 b4 fe ff ff    	jne    787e <fwp_drop4+0x8e>
    79ca:	48 89 d7             	mov    %rdx,%rdi
    79cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79d2:	e8 79 db ff ff       	call   5550 <fwp_rc_forget_slot>
    79d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    79df:	e9 9a fe ff ff       	jmp    787e <fwp_drop4+0x8e>
    79e4:	48 8d 3d 9d 4e 00 00 	lea    0x4e9d(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    79eb:	e8 00 ca ff ff       	call   43f0 <fwp_trap>

00000000000079f0 <fwp_caps161>:
    79f0:	f3 0f 1e fa          	endbr64
    79f4:	85 f6                	test   %esi,%esi
    79f6:	74 08                	je     7a00 <fwp_caps161+0x10>
    79f8:	c3                   	ret
    79f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a00:	48 8b 15 91 a1 01 00 	mov    0x1a191(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7a07:	48 89 f8             	mov    %rdi,%rax
    7a0a:	48 2b 05 5f a1 01 00 	sub    0x1a15f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7a11:	48 c1 e2 10          	shl    $0x10,%rdx
    7a15:	48 39 d0             	cmp    %rdx,%rax
    7a18:	73 de                	jae    79f8 <fwp_caps161+0x8>
    7a1a:	48 89 c2             	mov    %rax,%rdx
    7a1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a25:	48 8b 15 8c a1 01 00 	mov    0x1a18c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7a2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7a34:	48 85 c9             	test   %rcx,%rcx
    7a37:	74 bf                	je     79f8 <fwp_caps161+0x8>
    7a39:	0f b6 32             	movzbl (%rdx),%esi
    7a3c:	40 80 fe 02          	cmp    $0x2,%sil
    7a40:	74 2e                	je     7a70 <fwp_caps161+0x80>
    7a42:	40 80 fe 01          	cmp    $0x1,%sil
    7a46:	75 b0                	jne    79f8 <fwp_caps161+0x8>
    7a48:	8b 72 18             	mov    0x18(%rdx),%esi
    7a4b:	0f b7 c0             	movzwl %ax,%eax
    7a4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a51:	48 0f af c6          	imul   %rsi,%rax
    7a55:	48 c1 e8 20          	shr    $0x20,%rax
    7a59:	48 39 d0             	cmp    %rdx,%rax
    7a5c:	73 9a                	jae    79f8 <fwp_caps161+0x8>
    7a5e:	48 01 c1             	add    %rax,%rcx
    7a61:	80 39 01             	cmpb   $0x1,(%rcx)
    7a64:	75 92                	jne    79f8 <fwp_caps161+0x8>
    7a66:	e9 25 dd ff ff       	jmp    5790 <fwp_mem_free>
    7a6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a70:	66 85 c0             	test   %ax,%ax
    7a73:	74 ec                	je     7a61 <fwp_caps161+0x71>
    7a75:	c3                   	ret
    7a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a7d:	00 00 00 

0000000000007a80 <fwp_args12>:
    7a80:	f3 0f 1e fa          	endbr64
    7a84:	85 d2                	test   %edx,%edx
    7a86:	74 04                	je     7a8c <fwp_args12+0xc>
    7a88:	85 f6                	test   %esi,%esi
    7a8a:	74 04                	je     7a90 <fwp_args12+0x10>
    7a8c:	c3                   	ret
    7a8d:	0f 1f 00             	nopl   (%rax)
    7a90:	48 8b 15 01 a1 01 00 	mov    0x1a101(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7a97:	48 8b 07             	mov    (%rdi),%rax
    7a9a:	48 2b 05 cf a0 01 00 	sub    0x1a0cf(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7aa1:	48 c1 e2 10          	shl    $0x10,%rdx
    7aa5:	48 39 d0             	cmp    %rdx,%rax
    7aa8:	73 e2                	jae    7a8c <fwp_args12+0xc>
    7aaa:	48 89 c2             	mov    %rax,%rdx
    7aad:	48 c1 ea 10          	shr    $0x10,%rdx
    7ab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ab5:	48 8b 15 fc a0 01 00 	mov    0x1a0fc(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7abc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ac0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ac4:	48 85 ff             	test   %rdi,%rdi
    7ac7:	74 c3                	je     7a8c <fwp_args12+0xc>
    7ac9:	0f b6 0a             	movzbl (%rdx),%ecx
    7acc:	80 f9 02             	cmp    $0x2,%cl
    7acf:	74 2f                	je     7b00 <fwp_args12+0x80>
    7ad1:	80 f9 01             	cmp    $0x1,%cl
    7ad4:	75 b6                	jne    7a8c <fwp_args12+0xc>
    7ad6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ad9:	0f b7 c0             	movzwl %ax,%eax
    7adc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7adf:	48 0f af c1          	imul   %rcx,%rax
    7ae3:	48 c1 e8 20          	shr    $0x20,%rax
    7ae7:	48 39 d0             	cmp    %rdx,%rax
    7aea:	73 a0                	jae    7a8c <fwp_args12+0xc>
    7aec:	48 01 c7             	add    %rax,%rdi
    7aef:	0f b6 07             	movzbl (%rdi),%eax
    7af2:	84 c0                	test   %al,%al
    7af4:	74 96                	je     7a8c <fwp_args12+0xc>
    7af6:	3c fd                	cmp    $0xfd,%al
    7af8:	77 0c                	ja     7b06 <fwp_args12+0x86>
    7afa:	83 c0 01             	add    $0x1,%eax
    7afd:	88 07                	mov    %al,(%rdi)
    7aff:	c3                   	ret
    7b00:	66 85 c0             	test   %ax,%ax
    7b03:	74 ea                	je     7aef <fwp_args12+0x6f>
    7b05:	c3                   	ret
    7b06:	e9 25 d9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b10 <fwp_args23>:
    7b10:	f3 0f 1e fa          	endbr64
    7b14:	85 d2                	test   %edx,%edx
    7b16:	74 04                	je     7b1c <fwp_args23+0xc>
    7b18:	85 f6                	test   %esi,%esi
    7b1a:	74 04                	je     7b20 <fwp_args23+0x10>
    7b1c:	c3                   	ret
    7b1d:	0f 1f 00             	nopl   (%rax)
    7b20:	48 8b 15 71 a0 01 00 	mov    0x1a071(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7b27:	48 8b 07             	mov    (%rdi),%rax
    7b2a:	48 2b 05 3f a0 01 00 	sub    0x1a03f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7b31:	48 c1 e2 10          	shl    $0x10,%rdx
    7b35:	48 39 d0             	cmp    %rdx,%rax
    7b38:	73 e2                	jae    7b1c <fwp_args23+0xc>
    7b3a:	48 89 c2             	mov    %rax,%rdx
    7b3d:	48 c1 ea 10          	shr    $0x10,%rdx
    7b41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b45:	48 8b 15 6c a0 01 00 	mov    0x1a06c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7b4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b50:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b54:	48 85 ff             	test   %rdi,%rdi
    7b57:	74 c3                	je     7b1c <fwp_args23+0xc>
    7b59:	0f b6 0a             	movzbl (%rdx),%ecx
    7b5c:	80 f9 02             	cmp    $0x2,%cl
    7b5f:	74 2f                	je     7b90 <fwp_args23+0x80>
    7b61:	80 f9 01             	cmp    $0x1,%cl
    7b64:	75 b6                	jne    7b1c <fwp_args23+0xc>
    7b66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b69:	0f b7 c0             	movzwl %ax,%eax
    7b6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b6f:	48 0f af c1          	imul   %rcx,%rax
    7b73:	48 c1 e8 20          	shr    $0x20,%rax
    7b77:	48 39 d0             	cmp    %rdx,%rax
    7b7a:	73 a0                	jae    7b1c <fwp_args23+0xc>
    7b7c:	48 01 c7             	add    %rax,%rdi
    7b7f:	0f b6 07             	movzbl (%rdi),%eax
    7b82:	84 c0                	test   %al,%al
    7b84:	74 96                	je     7b1c <fwp_args23+0xc>
    7b86:	3c fd                	cmp    $0xfd,%al
    7b88:	77 0c                	ja     7b96 <fwp_args23+0x86>
    7b8a:	83 c0 01             	add    $0x1,%eax
    7b8d:	88 07                	mov    %al,(%rdi)
    7b8f:	c3                   	ret
    7b90:	66 85 c0             	test   %ax,%ax
    7b93:	74 ea                	je     7b7f <fwp_args23+0x6f>
    7b95:	c3                   	ret
    7b96:	e9 95 d8 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7b9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007ba0 <fwp_caps12>:
    7ba0:	f3 0f 1e fa          	endbr64
    7ba4:	48 83 ec 18          	sub    $0x18,%rsp
    7ba8:	8b 57 04             	mov    0x4(%rdi),%edx
    7bab:	48 89 f8             	mov    %rdi,%rax
    7bae:	85 d2                	test   %edx,%edx
    7bb0:	0f 84 9a 00 00 00    	je     7c50 <fwp_caps12+0xb0>
    7bb6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7bba:	85 f6                	test   %esi,%esi
    7bbc:	0f 85 9e 00 00 00    	jne    7c60 <fwp_caps12+0xc0>
    7bc2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7bc7:	e8 54 ec ff ff       	call   6820 <fwp_drop0>
    7bcc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bd1:	48 8b 0d c0 9f 01 00 	mov    0x19fc0(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    7bd8:	48 89 c2             	mov    %rax,%rdx
    7bdb:	48 2b 15 8e 9f 01 00 	sub    0x19f8e(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    7be2:	48 c1 e1 10          	shl    $0x10,%rcx
    7be6:	48 39 ca             	cmp    %rcx,%rdx
    7be9:	73 6d                	jae    7c58 <fwp_caps12+0xb8>
    7beb:	48 89 d1             	mov    %rdx,%rcx
    7bee:	48 c1 e9 10          	shr    $0x10,%rcx
    7bf2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7bf6:	48 8b 0d bb 9f 01 00 	mov    0x19fbb(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    7bfd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7c01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7c05:	48 85 f6             	test   %rsi,%rsi
    7c08:	74 4e                	je     7c58 <fwp_caps12+0xb8>
    7c0a:	0f b6 39             	movzbl (%rcx),%edi
    7c0d:	40 80 ff 02          	cmp    $0x2,%dil
    7c11:	0f 84 b9 00 00 00    	je     7cd0 <fwp_caps12+0x130>
    7c17:	40 80 ff 01          	cmp    $0x1,%dil
    7c1b:	75 3b                	jne    7c58 <fwp_caps12+0xb8>
    7c1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7c20:	0f b7 d2             	movzwl %dx,%edx
    7c23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c26:	48 0f af d7          	imul   %rdi,%rdx
    7c2a:	48 c1 ea 20          	shr    $0x20,%rdx
    7c2e:	48 39 ca             	cmp    %rcx,%rdx
    7c31:	73 25                	jae    7c58 <fwp_caps12+0xb8>
    7c33:	48 01 d6             	add    %rdx,%rsi
    7c36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7c39:	75 1d                	jne    7c58 <fwp_caps12+0xb8>
    7c3b:	48 89 c7             	mov    %rax,%rdi
    7c3e:	48 83 c4 18          	add    $0x18,%rsp
    7c42:	e9 49 db ff ff       	jmp    5790 <fwp_mem_free>
    7c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c4e:	00 00 
    7c50:	85 f6                	test   %esi,%esi
    7c52:	0f 84 79 ff ff ff    	je     7bd1 <fwp_caps12+0x31>
    7c58:	48 83 c4 18          	add    $0x18,%rsp
    7c5c:	c3                   	ret
    7c5d:	0f 1f 00             	nopl   (%rax)
    7c60:	48 8b 05 31 9f 01 00 	mov    0x19f31(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    7c67:	48 2b 3d 02 9f 01 00 	sub    0x19f02(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    7c6e:	48 c1 e0 10          	shl    $0x10,%rax
    7c72:	48 39 c7             	cmp    %rax,%rdi
    7c75:	73 e1                	jae    7c58 <fwp_caps12+0xb8>
    7c77:	48 89 f8             	mov    %rdi,%rax
    7c7a:	48 c1 e8 10          	shr    $0x10,%rax
    7c7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7c82:	48 8b 05 2f 9f 01 00 	mov    0x19f2f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    7c89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7c8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7c91:	48 85 c0             	test   %rax,%rax
    7c94:	74 c2                	je     7c58 <fwp_caps12+0xb8>
    7c96:	0f b6 0a             	movzbl (%rdx),%ecx
    7c99:	80 f9 02             	cmp    $0x2,%cl
    7c9c:	74 42                	je     7ce0 <fwp_caps12+0x140>
    7c9e:	80 f9 01             	cmp    $0x1,%cl
    7ca1:	75 b5                	jne    7c58 <fwp_caps12+0xb8>
    7ca3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ca6:	0f b7 ff             	movzwl %di,%edi
    7ca9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cac:	48 0f af f9          	imul   %rcx,%rdi
    7cb0:	48 c1 ef 20          	shr    $0x20,%rdi
    7cb4:	48 39 d7             	cmp    %rdx,%rdi
    7cb7:	73 9f                	jae    7c58 <fwp_caps12+0xb8>
    7cb9:	48 01 f8             	add    %rdi,%rax
    7cbc:	0f b6 10             	movzbl (%rax),%edx
    7cbf:	84 d2                	test   %dl,%dl
    7cc1:	74 95                	je     7c58 <fwp_caps12+0xb8>
    7cc3:	80 fa fd             	cmp    $0xfd,%dl
    7cc6:	77 23                	ja     7ceb <fwp_caps12+0x14b>
    7cc8:	83 c2 01             	add    $0x1,%edx
    7ccb:	88 10                	mov    %dl,(%rax)
    7ccd:	eb 89                	jmp    7c58 <fwp_caps12+0xb8>
    7ccf:	90                   	nop
    7cd0:	66 85 d2             	test   %dx,%dx
    7cd3:	0f 85 7f ff ff ff    	jne    7c58 <fwp_caps12+0xb8>
    7cd9:	e9 58 ff ff ff       	jmp    7c36 <fwp_caps12+0x96>
    7cde:	66 90                	xchg   %ax,%ax
    7ce0:	66 85 ff             	test   %di,%di
    7ce3:	0f 85 6f ff ff ff    	jne    7c58 <fwp_caps12+0xb8>
    7ce9:	eb d1                	jmp    7cbc <fwp_caps12+0x11c>
    7ceb:	48 89 c7             	mov    %rax,%rdi
    7cee:	48 83 c4 18          	add    $0x18,%rsp
    7cf2:	e9 39 d7 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cfe:	00 00 

0000000000007d00 <f12>:
    7d00:	41 57                	push   %r15
    7d02:	41 56                	push   %r14
    7d04:	41 55                	push   %r13
    7d06:	4c 8d 2d 33 f1 ff ff 	lea    -0xecd(%rip),%r13        # 6e40 <fwp_tape_scope_release>
    7d0d:	41 54                	push   %r12
    7d0f:	55                   	push   %rbp
    7d10:	53                   	push   %rbx
    7d11:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    7d18:	48 8b 15 79 9e 01 00 	mov    0x19e79(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7d1f:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    7d24:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7d29:	48 c1 e2 10          	shl    $0x10,%rdx
    7d2d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7d34:	00 00 
    7d36:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7d3d:	00 
    7d3e:	31 c0                	xor    %eax,%eax
    7d40:	48 8b 05 11 a7 01 00 	mov    0x1a711(%rip),%rax        # 22458 <fwp_cleanups>
    7d47:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7d4e:	ff 
    7d4f:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7d54:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7d59:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7d5e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    7d63:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7d68:	48 8d 05 a1 82 00 00 	lea    0x82a1(%rip),%rax        # 10010 <fc23>
    7d6f:	48 2b 05 fa 9d 01 00 	sub    0x19dfa(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7d76:	4c 89 3d db a6 01 00 	mov    %r15,0x1a6db(%rip)        # 22458 <fwp_cleanups>
    7d7d:	48 39 d0             	cmp    %rdx,%rax
    7d80:	73 5d                	jae    7ddf <f12+0xdf>
    7d82:	48 89 c2             	mov    %rax,%rdx
    7d85:	48 c1 ea 10          	shr    $0x10,%rdx
    7d89:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d8d:	48 8b 15 24 9e 01 00 	mov    0x19e24(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7d94:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d98:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d9c:	48 85 ff             	test   %rdi,%rdi
    7d9f:	74 3e                	je     7ddf <f12+0xdf>
    7da1:	0f b6 0a             	movzbl (%rdx),%ecx
    7da4:	80 f9 02             	cmp    $0x2,%cl
    7da7:	0f 84 d3 11 00 00    	je     8f80 <f12+0x1280>
    7dad:	80 f9 01             	cmp    $0x1,%cl
    7db0:	75 2d                	jne    7ddf <f12+0xdf>
    7db2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7db5:	0f b7 c0             	movzwl %ax,%eax
    7db8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dbb:	48 0f af c1          	imul   %rcx,%rax
    7dbf:	48 c1 e8 20          	shr    $0x20,%rax
    7dc3:	48 39 d0             	cmp    %rdx,%rax
    7dc6:	73 17                	jae    7ddf <f12+0xdf>
    7dc8:	48 01 c7             	add    %rax,%rdi
    7dcb:	0f b6 07             	movzbl (%rdi),%eax
    7dce:	84 c0                	test   %al,%al
    7dd0:	74 0d                	je     7ddf <f12+0xdf>
    7dd2:	3c fd                	cmp    $0xfd,%al
    7dd4:	0f 87 0f 14 00 00    	ja     91e9 <f12+0x14e9>
    7dda:	83 c0 01             	add    $0x1,%eax
    7ddd:	88 07                	mov    %al,(%rdi)
    7ddf:	48 8d 3d 2a 82 00 00 	lea    0x822a(%rip),%rdi        # 10010 <fc23>
    7de6:	e8 25 ed ff ff       	call   6b10 <fwp_closure_drop>
    7deb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7df0:	48 85 c0             	test   %rax,%rax
    7df3:	0f 84 56 13 00 00    	je     914f <f12+0x144f>
    7df9:	31 db                	xor    %ebx,%ebx
    7dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7e00:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e04:	48 83 c3 01          	add    $0x1,%rbx
    7e08:	48 85 c0             	test   %rax,%rax
    7e0b:	75 f3                	jne    7e00 <f12+0x100>
    7e0d:	31 ff                	xor    %edi,%edi
    7e0f:	e8 3c c4 ff ff       	call   4250 <descent_phase_step>
    7e14:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    7e1b:	0f 87 d6 14 00 00    	ja     92f7 <f12+0x15f7>
    7e21:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    7e26:	44 8b 05 33 82 00 00 	mov    0x8233(%rip),%r8d        # 10060 <registered_finish.0>
    7e2d:	45 85 c0             	test   %r8d,%r8d
    7e30:	0f 84 1a 11 00 00    	je     8f50 <f12+0x1250>
    7e36:	48 8b 1d 9b 82 01 00 	mov    0x1829b(%rip),%rbx        # 200d8 <fwp_tape_next_slot>
    7e3d:	4c 8b 25 a4 82 01 00 	mov    0x182a4(%rip),%r12        # 200e8 <fwp_ntapes>
    7e44:	4c 39 e3             	cmp    %r12,%rbx
    7e47:	0f 8d e3 05 00 00    	jge    8430 <f12+0x730>
    7e4d:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7e51:	48 03 05 98 82 01 00 	add    0x18298(%rip),%rax        # 200f0 <fwp_tapes>
    7e58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e5f:	00 
    7e60:	8b 78 04             	mov    0x4(%rax),%edi
    7e63:	85 ff                	test   %edi,%edi
    7e65:	75 0c                	jne    7e73 <f12+0x173>
    7e67:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7e6d:	0f 86 bd 05 00 00    	jbe    8430 <f12+0x730>
    7e73:	48 83 c3 01          	add    $0x1,%rbx
    7e77:	48 83 c0 68          	add    $0x68,%rax
    7e7b:	4c 39 e3             	cmp    %r12,%rbx
    7e7e:	75 e0                	jne    7e60 <f12+0x160>
    7e80:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    7e87:	0f 8f 9a 14 00 00    	jg     9327 <f12+0x1627>
    7e8d:	4c 39 25 4c 82 01 00 	cmp    %r12,0x1824c(%rip)        # 200e0 <fwp_tapes_cap>
    7e94:	48 8b 2d 55 82 01 00 	mov    0x18255(%rip),%rbp        # 200f0 <fwp_tapes>
    7e9b:	75 4b                	jne    7ee8 <f12+0x1e8>
    7e9d:	4d 85 e4             	test   %r12,%r12
    7ea0:	0f 84 42 12 00 00    	je     90e8 <f12+0x13e8>
    7ea6:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    7eaa:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7eaf:	49 39 c6             	cmp    %rax,%r14
    7eb2:	4c 0f 4f f0          	cmovg  %rax,%r14
    7eb6:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    7eba:	48 89 ef             	mov    %rbp,%rdi
    7ebd:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    7ec3:	e8 08 b7 ff ff       	call   35d0 <realloc@plt>
    7ec8:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    7ece:	48 85 c0             	test   %rax,%rax
    7ed1:	48 89 c5             	mov    %rax,%rbp
    7ed4:	0f 84 eb 10 00 00    	je     8fc5 <f12+0x12c5>
    7eda:	48 89 05 0f 82 01 00 	mov    %rax,0x1820f(%rip)        # 200f0 <fwp_tapes>
    7ee1:	4c 89 35 f8 81 01 00 	mov    %r14,0x181f8(%rip)        # 200e0 <fwp_tapes_cap>
    7ee8:	49 6b c4 68          	imul   $0x68,%r12,%rax
    7eec:	49 83 c4 01          	add    $0x1,%r12
    7ef0:	48 01 e8             	add    %rbp,%rax
    7ef3:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7ef7:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7efe:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7f02:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7f09:	00 
    7f0a:	48 29 f8             	sub    %rdi,%rax
    7f0d:	8d 48 68             	lea    0x68(%rax),%ecx
    7f10:	31 c0                	xor    %eax,%eax
    7f12:	c1 e9 03             	shr    $0x3,%ecx
    7f15:	f3 48 ab             	rep stos %rax,(%rdi)
    7f18:	4c 89 25 c9 81 01 00 	mov    %r12,0x181c9(%rip)        # 200e8 <fwp_ntapes>
    7f1f:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    7f23:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7f27:	48 8d 3d f4 41 00 00 	lea    0x41f4(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    7f2e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7f33:	49 01 ec             	add    %rbp,%r12
    7f36:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    7f3d:	00 00 
    7f3f:	e8 5c b4 ff ff       	call   33a0 <getenv@plt>
    7f44:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    7f4a:	48 85 c0             	test   %rax,%rax
    7f4d:	74 09                	je     7f58 <f12+0x258>
    7f4f:	80 38 30             	cmpb   $0x30,(%rax)
    7f52:	0f 84 28 04 00 00    	je     8380 <f12+0x680>
    7f58:	48 83 3d 28 81 01 00 	cmpq   $0x0,0x18128(%rip)        # 20088 <fwp_tape_cached_bytes>
    7f5f:	00 
    7f60:	0f 85 ba 10 00 00    	jne    9020 <f12+0x1320>
    7f66:	41 8b 04 24          	mov    (%r12),%eax
    7f6a:	4c 8d 43 01          	lea    0x1(%rbx),%r8
    7f6e:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    7f75:	00 00 
    7f77:	4c 89 05 5a 81 01 00 	mov    %r8,0x1815a(%rip)        # 200d8 <fwp_tape_next_slot>
    7f7e:	8d 70 01             	lea    0x1(%rax),%esi
    7f81:	48 8b 05 d0 a4 01 00 	mov    0x1a4d0(%rip),%rax        # 22458 <fwp_cleanups>
    7f88:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    7f8f:	00 00 
    7f91:	41 89 34 24          	mov    %esi,(%r12)
    7f95:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    7f9c:	ff ff 
    7f9e:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    7fa4:	48 85 c0             	test   %rax,%rax
    7fa7:	75 13                	jne    7fbc <f12+0x2bc>
    7fa9:	e9 6d 13 00 00       	jmp    931b <f12+0x161b>
    7fae:	66 90                	xchg   %ax,%ax
    7fb0:	48 8b 00             	mov    (%rax),%rax
    7fb3:	48 85 c0             	test   %rax,%rax
    7fb6:	0f 84 5f 13 00 00    	je     931b <f12+0x161b>
    7fbc:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    7fc0:	75 ee                	jne    7fb0 <f12+0x2b0>
    7fc2:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7fc6:	89 df                	mov    %ebx,%edi
    7fc8:	48 63 01             	movslq (%rcx),%rax
    7fcb:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    7fd0:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    7fd5:	85 c0                	test   %eax,%eax
    7fd7:	78 08                	js     7fe1 <f12+0x2e1>
    7fd9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7fdd:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    7fe1:	89 39                	mov    %edi,(%rcx)
    7fe3:	bf 01 00 00 00       	mov    $0x1,%edi
    7fe8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    7fed:	89 74 24 10          	mov    %esi,0x10(%rsp)
    7ff1:	e8 5a c2 ff ff       	call   4250 <descent_phase_step>
    7ff6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7ffb:	31 c9                	xor    %ecx,%ecx
    7ffd:	8b 74 24 10          	mov    0x10(%rsp),%esi
    8001:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8006:	48 85 ff             	test   %rdi,%rdi
    8009:	48 89 f8             	mov    %rdi,%rax
    800c:	0f 84 7e 03 00 00    	je     8390 <f12+0x690>
    8012:	0f 1f 00             	nopl   (%rax)
    8015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    801c:	00 00 00 00 
    8020:	48 8b 40 10          	mov    0x10(%rax),%rax
    8024:	48 83 c1 01          	add    $0x1,%rcx
    8028:	48 85 c0             	test   %rax,%rax
    802b:	75 f3                	jne    8020 <f12+0x320>
    802d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8032:	0f 1f 00             	nopl   (%rax)
    8035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    803c:	00 00 00 00 
    8040:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8044:	48 83 c0 01          	add    $0x1,%rax
    8048:	48 85 d2             	test   %rdx,%rdx
    804b:	75 f3                	jne    8040 <f12+0x340>
    804d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8054:	ff ff 1f 
    8057:	48 39 c2             	cmp    %rax,%rdx
    805a:	0f 82 a3 12 00 00    	jb     9303 <f12+0x1603>
    8060:	48 85 c9             	test   %rcx,%rcx
    8063:	0f 8e 27 03 00 00    	jle    8390 <f12+0x690>
    8069:	48 39 c1             	cmp    %rax,%rcx
    806c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8070:	49 89 c5             	mov    %rax,%r13
    8073:	48 c1 e8 3c          	shr    $0x3c,%rax
    8077:	0f 85 86 12 00 00    	jne    9303 <f12+0x1603>
    807d:	48 c1 e6 10          	shl    $0x10,%rsi
    8081:	4b 8d 6c 2d 00       	lea    0x0(%r13,%r13,1),%rbp
    8086:	4c 09 c6             	or     %r8,%rsi
    8089:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8090:	00 
    8091:	49 89 f4             	mov    %rsi,%r12
    8094:	be 02 00 00 00       	mov    $0x2,%esi
    8099:	e8 f2 db ff ff       	call   5c90 <fwp_heap_alloc>
    809e:	48 89 28             	mov    %rbp,(%rax)
    80a1:	48 8b 15 f0 9a 01 00 	mov    0x19af0(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    80a8:	48 89 c3             	mov    %rax,%rbx
    80ab:	48 2b 05 be 9a 01 00 	sub    0x19abe(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    80b2:	48 c1 e2 10          	shl    $0x10,%rdx
    80b6:	48 39 d0             	cmp    %rdx,%rax
    80b9:	0f 83 51 03 00 00    	jae    8410 <f12+0x710>
    80bf:	48 89 c2             	mov    %rax,%rdx
    80c2:	48 c1 ea 10          	shr    $0x10,%rdx
    80c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80ca:	48 8b 15 e7 9a 01 00 	mov    0x19ae7(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    80d1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    80d5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    80d9:	48 85 d2             	test   %rdx,%rdx
    80dc:	74 38                	je     8116 <f12+0x416>
    80de:	0f b6 31             	movzbl (%rcx),%esi
    80e1:	40 80 fe 02          	cmp    $0x2,%sil
    80e5:	0f 84 12 03 00 00    	je     83fd <f12+0x6fd>
    80eb:	40 80 fe 01          	cmp    $0x1,%sil
    80ef:	75 25                	jne    8116 <f12+0x416>
    80f1:	8b 71 18             	mov    0x18(%rcx),%esi
    80f4:	0f b7 c0             	movzwl %ax,%eax
    80f7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    80fa:	48 0f af c6          	imul   %rsi,%rax
    80fe:	48 c1 e8 20          	shr    $0x20,%rax
    8102:	48 39 c8             	cmp    %rcx,%rax
    8105:	73 0f                	jae    8116 <f12+0x416>
    8107:	48 01 c2             	add    %rax,%rdx
    810a:	80 3a ff             	cmpb   $0xff,(%rdx)
    810d:	0f 84 a5 10 00 00    	je     91b8 <f12+0x14b8>
    8113:	c6 02 01             	movb   $0x1,(%rdx)
    8116:	4d 85 ed             	test   %r13,%r13
    8119:	74 58                	je     8173 <f12+0x473>
    811b:	4c 89 e1             	mov    %r12,%rcx
    811e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8123:	31 c0                	xor    %eax,%eax
    8125:	48 c1 e1 20          	shl    $0x20,%rcx
    8129:	90                   	nop
    812a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8131:	00 00 00 00 
    8135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    813c:	00 00 00 00 
    8140:	48 89 c6             	mov    %rax,%rsi
    8143:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8148:	48 01 ce             	add    %rcx,%rsi
    814b:	0f 80 8d 11 00 00    	jo     92de <f12+0x15de>
    8151:	66 48 0f 6e de       	movq   %rsi,%xmm3
    8156:	48 89 c6             	mov    %rax,%rsi
    8159:	48 83 c0 01          	add    $0x1,%rax
    815d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8161:	48 c1 e6 04          	shl    $0x4,%rsi
    8165:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    816a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    816e:	4c 39 e8             	cmp    %r13,%rax
    8171:	72 cd                	jb     8140 <f12+0x440>
    8173:	48 8b 03             	mov    (%rbx),%rax
    8176:	48 d1 e8             	shr    $1,%rax
    8179:	0f 84 a1 02 00 00    	je     8420 <f12+0x720>
    817f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8183:	48 89 d1             	mov    %rdx,%rcx
    8186:	48 c1 e9 3c          	shr    $0x3c,%rcx
    818a:	0f 85 73 11 00 00    	jne    9303 <f12+0x1603>
    8190:	48 8d 2c 12          	lea    (%rdx,%rdx,1),%rbp
    8194:	48 85 d2             	test   %rdx,%rdx
    8197:	74 45                	je     81de <f12+0x4de>
    8199:	48 c1 e0 04          	shl    $0x4,%rax
    819d:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    81a1:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    81a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81ad:	00 00 00 
    81b0:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    81b5:	49 8b 76 18          	mov    0x18(%r14),%rsi
    81b9:	49 83 c6 10          	add    $0x10,%r14
    81bd:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    81c1:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    81c6:	e8 a5 e1 ff ff       	call   6370 <w107>
    81cb:	66 48 0f 6e e0       	movq   %rax,%xmm4
    81d0:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    81d4:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    81d9:	4d 39 f5             	cmp    %r14,%r13
    81dc:	75 d2                	jne    81b0 <f12+0x4b0>
    81de:	48 89 2b             	mov    %rbp,(%rbx)
    81e1:	48 89 df             	mov    %rbx,%rdi
    81e4:	e8 f7 e2 ff ff       	call   64e0 <w164.constprop.0>
    81e9:	48 89 df             	mov    %rbx,%rdi
    81ec:	49 63 dc             	movslq %r12d,%rbx
    81ef:	49 89 c5             	mov    %rax,%r13
    81f2:	e8 f9 f5 ff ff       	call   77f0 <fwp_drop4>
    81f7:	bf 02 00 00 00       	mov    $0x2,%edi
    81fc:	e8 4f c0 ff ff       	call   4250 <descent_phase_step>
    8201:	48 89 df             	mov    %rbx,%rdi
    8204:	e8 c7 c4 ff ff       	call   46d0 <fwp_tape_of>
    8209:	48 89 c6             	mov    %rax,%rsi
    820c:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8211:	0f 85 f8 10 00 00    	jne    930f <f12+0x160f>
    8217:	48 89 c7             	mov    %rax,%rdi
    821a:	e8 e1 b9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    821f:	f3 0f 6f 7e 20       	movdqu 0x20(%rsi),%xmm7
    8224:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    8228:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    822f:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8234:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    8238:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    823d:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8242:	66 48 0f 6e d2       	movq   %rdx,%xmm2
    8247:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    824b:	4c 8b 76 40          	mov    0x40(%rsi),%r14
    824f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8253:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    8258:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    825e:	77 19                	ja     8279 <f12+0x579>
    8260:	41 0f b7 c4          	movzwl %r12w,%eax
    8264:	83 e8 01             	sub    $0x1,%eax
    8267:	48 98                	cltq
    8269:	48 3b 05 68 7e 01 00 	cmp    0x17e68(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    8270:	7d 07                	jge    8279 <f12+0x579>
    8272:	48 89 05 5f 7e 01 00 	mov    %rax,0x17e5f(%rip)        # 200d8 <fwp_tape_next_slot>
    8279:	66 0f ef c9          	pxor   %xmm1,%xmm1
    827d:	48 8b 05 d4 a1 01 00 	mov    0x1a1d4(%rip),%rax        # 22458 <fwp_cleanups>
    8284:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    828a:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    8291:	00 
    8292:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    8298:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    829c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    82a3:	00 
    82a4:	48 8d 05 c5 cd ff ff 	lea    -0x323b(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    82ab:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    82b2:	00 
    82b3:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    82ba:	00 
    82bb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    82c2:	00 
    82c3:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    82c7:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    82cb:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    82d2:	00 
    82d3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    82da:	00 
    82db:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    82e2:	00 
    82e3:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    82ea:	00 
    82eb:	48 89 05 66 a1 01 00 	mov    %rax,0x1a166(%rip)        # 22458 <fwp_cleanups>
    82f2:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    82f9:	00 
    82fa:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    8301:	00 
    8302:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8309:	00 
    830a:	4d 85 ed             	test   %r13,%r13
    830d:	0f 88 7d 0c 00 00    	js     8f90 <f12+0x1290>
    8313:	4c 89 e8             	mov    %r13,%rax
    8316:	48 c1 f8 20          	sar    $0x20,%rax
    831a:	48 39 c3             	cmp    %rax,%rbx
    831d:	0f 85 92 0f 00 00    	jne    92b5 <f12+0x15b5>
    8323:	45 89 ea             	mov    %r13d,%r10d
    8326:	4c 39 d7             	cmp    %r10,%rdi
    8329:	0f 8e 92 0f 00 00    	jle    92c1 <f12+0x15c1>
    832f:	4c 39 d5             	cmp    %r10,%rbp
    8332:	0f 8e 10 01 00 00    	jle    8448 <f12+0x748>
    8338:	48 39 d5             	cmp    %rdx,%rbp
    833b:	0f 8f 57 0d 00 00    	jg     9098 <f12+0x1398>
    8341:	4d 85 f6             	test   %r14,%r14
    8344:	0f 84 64 0c 00 00    	je     8fae <f12+0x12ae>
    834a:	4c 8d 4d ff          	lea    -0x1(%rbp),%r9
    834e:	31 f6                	xor    %esi,%esi
    8350:	4c 89 f7             	mov    %r14,%rdi
    8353:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    8358:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    835f:	00 
    8360:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8365:	e8 56 b1 ff ff       	call   34c0 <memset@plt>
    836a:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    836f:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    8374:	45 31 db             	xor    %r11d,%r11d
    8377:	e9 5b 01 00 00       	jmp    84d7 <f12+0x7d7>
    837c:	0f 1f 40 00          	nopl   0x0(%rax)
    8380:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8384:	0f 84 dc fb ff ff    	je     7f66 <f12+0x266>
    838a:	e9 c9 fb ff ff       	jmp    7f58 <f12+0x258>
    838f:	90                   	nop
    8390:	48 c1 e6 10          	shl    $0x10,%rsi
    8394:	bf 08 00 00 00       	mov    $0x8,%edi
    8399:	4c 09 c6             	or     %r8,%rsi
    839c:	49 89 f4             	mov    %rsi,%r12
    839f:	be 02 00 00 00       	mov    $0x2,%esi
    83a4:	e8 e7 d8 ff ff       	call   5c90 <fwp_heap_alloc>
    83a9:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    83b0:	48 8b 15 e1 97 01 00 	mov    0x197e1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    83b7:	48 89 c3             	mov    %rax,%rbx
    83ba:	48 2b 05 af 97 01 00 	sub    0x197af(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    83c1:	48 c1 e2 10          	shl    $0x10,%rdx
    83c5:	48 39 d0             	cmp    %rdx,%rax
    83c8:	73 56                	jae    8420 <f12+0x720>
    83ca:	48 89 c2             	mov    %rax,%rdx
    83cd:	48 c1 ea 10          	shr    $0x10,%rdx
    83d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83d5:	48 8b 15 dc 97 01 00 	mov    0x197dc(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    83dc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    83e0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    83e4:	48 85 d2             	test   %rdx,%rdx
    83e7:	0f 84 86 fd ff ff    	je     8173 <f12+0x473>
    83ed:	0f b6 31             	movzbl (%rcx),%esi
    83f0:	45 31 ed             	xor    %r13d,%r13d
    83f3:	40 80 fe 02          	cmp    $0x2,%sil
    83f7:	0f 85 ee fc ff ff    	jne    80eb <f12+0x3eb>
    83fd:	66 85 c0             	test   %ax,%ax
    8400:	0f 85 10 fd ff ff    	jne    8116 <f12+0x416>
    8406:	e9 ff fc ff ff       	jmp    810a <f12+0x40a>
    840b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8410:	4d 85 ed             	test   %r13,%r13
    8413:	0f 85 02 fd ff ff    	jne    811b <f12+0x41b>
    8419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8420:	31 ed                	xor    %ebp,%ebp
    8422:	e9 b7 fd ff ff       	jmp    81de <f12+0x4de>
    8427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    842e:	00 00 
    8430:	4c 39 e3             	cmp    %r12,%rbx
    8433:	0f 84 47 fa ff ff    	je     7e80 <f12+0x180>
    8439:	48 8b 2d b0 7c 01 00 	mov    0x17cb0(%rip),%rbp        # 200f0 <fwp_tapes>
    8440:	e9 da fa ff ff       	jmp    7f1f <f12+0x21f>
    8445:	0f 1f 00             	nopl   (%rax)
    8448:	49 8d 5a 01          	lea    0x1(%r10),%rbx
    844c:	48 39 da             	cmp    %rbx,%rdx
    844f:	0f 8d 4b 0c 00 00    	jge    90a0 <f12+0x13a0>
    8455:	48 85 d2             	test   %rdx,%rdx
    8458:	48 0f 44 d3          	cmove  %rbx,%rdx
    845c:	eb 17                	jmp    8475 <f12+0x775>
    845e:	66 90                	xchg   %ax,%ax
    8460:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8464:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    846b:	48 89 d8             	mov    %rbx,%rax
    846e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8472:	48 89 c2             	mov    %rax,%rdx
    8475:	48 39 d3             	cmp    %rdx,%rbx
    8478:	7f e6                	jg     8460 <f12+0x760>
    847a:	4d 85 f6             	test   %r14,%r14
    847d:	0f 84 ad 0c 00 00    	je     9130 <f12+0x1430>
    8483:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    848a:	00 
    848b:	4c 89 f7             	mov    %r14,%rdi
    848e:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    8493:	e8 38 b1 ff ff       	call   35d0 <realloc@plt>
    8498:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    849d:	49 89 c6             	mov    %rax,%r14
    84a0:	4d 85 f6             	test   %r14,%r14
    84a3:	0f 84 f3 0a 00 00    	je     8f9c <f12+0x129c>
    84a9:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    84b0:	00 
    84b1:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
    84b8:	00 
    84b9:	48 85 db             	test   %rbx,%rbx
    84bc:	0f 85 31 0d 00 00    	jne    91f3 <f12+0x14f3>
    84c2:	49 89 eb             	mov    %rbp,%r11
    84c5:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    84cc:	49 f7 db             	neg    %r11
    84cf:	4d 85 ed             	test   %r13,%r13
    84d2:	78 17                	js     84eb <f12+0x7eb>
    84d4:	45 89 ea             	mov    %r13d,%r10d
    84d7:	f2 0f 10 05 41 47 00 	movsd  0x4741(%rip),%xmm0        # cc20 <msg.4+0xb0>
    84de:	00 
    84df:	f2 43 0f 58 04 d6    	addsd  (%r14,%r10,8),%xmm0
    84e5:	f2 43 0f 11 04 d6    	movsd  %xmm0,(%r14,%r10,8)
    84eb:	bf 03 00 00 00       	mov    $0x3,%edi
    84f0:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    84f5:	48 01 2d 04 7c 01 00 	add    %rbp,0x17c04(%rip)        # 20100 <descent_inputs>
    84fc:	4c 01 1d 05 7c 01 00 	add    %r11,0x17c05(%rip)        # 20108 <descent_nodes>
    8503:	e8 48 bd ff ff       	call   4250 <descent_phase_step>
    8508:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    850d:	49 39 e9             	cmp    %rbp,%r9
    8510:	0f 8c 8c 00 00 00    	jl     85a2 <f12+0x8a2>
    8516:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    851b:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    8520:	49 29 e9             	sub    %rbp,%r9
    8523:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8527:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    852c:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    8531:	4b 8d 14 cb          	lea    (%r11,%r9,8),%rdx
    8535:	4a 8d 04 8f          	lea    (%rdi,%r9,4),%rax
    8539:	4d 8d 0c ee          	lea    (%r14,%rbp,8),%r9
    853d:	48 29 fe             	sub    %rdi,%rsi
    8540:	4d 29 da             	sub    %r11,%r10
    8543:	4d 29 d9             	sub    %r11,%r9
    8546:	eb 0c                	jmp    8554 <f12+0x854>
    8548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    854f:	00 
    8550:	48 83 e8 04          	sub    $0x4,%rax
    8554:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    855a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    855e:	7a 02                	jp     8562 <f12+0x862>
    8560:	74 37                	je     8599 <f12+0x899>
    8562:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8566:	45 85 db             	test   %r11d,%r11d
    8569:	78 16                	js     8581 <f12+0x881>
    856b:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8571:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8575:	f2 43 0f 58 0c de    	addsd  (%r14,%r11,8),%xmm1
    857b:	f2 43 0f 11 0c de    	movsd  %xmm1,(%r14,%r11,8)
    8581:	4c 63 18             	movslq (%rax),%r11
    8584:	45 85 db             	test   %r11d,%r11d
    8587:	78 10                	js     8599 <f12+0x899>
    8589:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    858d:	f2 43 0f 58 04 de    	addsd  (%r14,%r11,8),%xmm0
    8593:	f2 43 0f 11 04 de    	movsd  %xmm0,(%r14,%r11,8)
    8599:	48 83 ea 08          	sub    $0x8,%rdx
    859d:	48 39 c7             	cmp    %rax,%rdi
    85a0:	75 ae                	jne    8550 <f12+0x850>
    85a2:	bf 04 00 00 00       	mov    $0x4,%edi
    85a7:	e8 a4 bc ff ff       	call   4250 <descent_phase_step>
    85ac:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    85b3:	ff ff 1f 
    85b6:	48 39 e8             	cmp    %rbp,%rax
    85b9:	0f 82 2c 0d 00 00    	jb     92eb <f12+0x15eb>
    85bf:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    85c6:	00 
    85c7:	be 02 00 00 00       	mov    $0x2,%esi
    85cc:	e8 bf d6 ff ff       	call   5c90 <fwp_heap_alloc>
    85d1:	48 89 28             	mov    %rbp,(%rax)
    85d4:	48 89 c3             	mov    %rax,%rbx
    85d7:	31 c0                	xor    %eax,%eax
    85d9:	48 85 ed             	test   %rbp,%rbp
    85dc:	74 14                	je     85f2 <f12+0x8f2>
    85de:	66 90                	xchg   %ax,%ax
    85e0:	49 8b 14 c6          	mov    (%r14,%rax,8),%rdx
    85e4:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    85e9:	48 83 c0 01          	add    $0x1,%rax
    85ed:	48 39 c5             	cmp    %rax,%rbp
    85f0:	75 ee                	jne    85e0 <f12+0x8e0>
    85f2:	bf 05 00 00 00       	mov    $0x5,%edi
    85f7:	e8 54 bc ff ff       	call   4250 <descent_phase_step>
    85fc:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    8603:	00 
    8604:	4c 89 e7             	mov    %r12,%rdi
    8607:	4c 89 2d 4a 9e 01 00 	mov    %r13,0x19e4a(%rip)        # 22458 <fwp_cleanups>
    860e:	e8 5d ca ff ff       	call   5070 <fwp_tape_buffers_release>
    8613:	bf 06 00 00 00       	mov    $0x6,%edi
    8618:	e8 33 bc ff ff       	call   4250 <descent_phase_step>
    861d:	48 8b 15 74 95 01 00 	mov    0x19574(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    8624:	48 89 d8             	mov    %rbx,%rax
    8627:	48 2b 05 42 95 01 00 	sub    0x19542(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    862e:	48 c1 e2 10          	shl    $0x10,%rdx
    8632:	48 39 d0             	cmp    %rdx,%rax
    8635:	73 59                	jae    8690 <f12+0x990>
    8637:	48 89 c2             	mov    %rax,%rdx
    863a:	48 c1 ea 10          	shr    $0x10,%rdx
    863e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8642:	48 8b 15 6f 95 01 00 	mov    0x1956f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    8649:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    864d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8651:	4d 85 e4             	test   %r12,%r12
    8654:	74 3a                	je     8690 <f12+0x990>
    8656:	0f b6 0a             	movzbl (%rdx),%ecx
    8659:	80 f9 02             	cmp    $0x2,%cl
    865c:	0f 84 96 09 00 00    	je     8ff8 <f12+0x12f8>
    8662:	80 f9 01             	cmp    $0x1,%cl
    8665:	75 29                	jne    8690 <f12+0x990>
    8667:	8b 4a 18             	mov    0x18(%rdx),%ecx
    866a:	0f b7 c0             	movzwl %ax,%eax
    866d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8670:	48 0f af c1          	imul   %rcx,%rax
    8674:	48 c1 e8 20          	shr    $0x20,%rax
    8678:	48 39 d0             	cmp    %rdx,%rax
    867b:	73 13                	jae    8690 <f12+0x990>
    867d:	49 01 c4             	add    %rax,%r12
    8680:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8685:	0f 84 44 0b 00 00    	je     91cf <f12+0x14cf>
    868b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8690:	4d 39 fd             	cmp    %r15,%r13
    8693:	0f 85 b2 b0 ff ff    	jne    374b <f12.cold>
    8699:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    869e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    86a3:	48 89 05 ae 9d 01 00 	mov    %rax,0x19dae(%rip)        # 22458 <fwp_cleanups>
    86aa:	e8 91 e7 ff ff       	call   6e40 <fwp_tape_scope_release>
    86af:	48 8b 03             	mov    (%rbx),%rax
    86b2:	49 89 c4             	mov    %rax,%r12
    86b5:	49 0f ba f4 3f       	btr    $0x3f,%r12
    86ba:	48 85 c0             	test   %rax,%rax
    86bd:	0f 88 bd 07 00 00    	js     8e80 <f12+0x1180>
    86c3:	48 8b 15 ce 94 01 00 	mov    0x194ce(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    86ca:	48 89 d8             	mov    %rbx,%rax
    86cd:	48 2b 05 9c 94 01 00 	sub    0x1949c(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    86d4:	48 c1 e2 10          	shl    $0x10,%rdx
    86d8:	48 39 d0             	cmp    %rdx,%rax
    86db:	0f 83 9f 07 00 00    	jae    8e80 <f12+0x1180>
    86e1:	48 89 c2             	mov    %rax,%rdx
    86e4:	48 c1 ea 10          	shr    $0x10,%rdx
    86e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86ec:	48 8b 15 c5 94 01 00 	mov    0x194c5(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    86f3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86f7:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    86fb:	48 85 c9             	test   %rcx,%rcx
    86fe:	0f 84 7c 07 00 00    	je     8e80 <f12+0x1180>
    8704:	0f b6 32             	movzbl (%rdx),%esi
    8707:	40 80 fe 02          	cmp    $0x2,%sil
    870b:	0f 84 5f 07 00 00    	je     8e70 <f12+0x1170>
    8711:	40 80 fe 01          	cmp    $0x1,%sil
    8715:	0f 85 65 07 00 00    	jne    8e80 <f12+0x1180>
    871b:	8b 72 18             	mov    0x18(%rdx),%esi
    871e:	0f b7 c0             	movzwl %ax,%eax
    8721:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8724:	48 0f af c6          	imul   %rsi,%rax
    8728:	48 c1 e8 20          	shr    $0x20,%rax
    872c:	48 39 d0             	cmp    %rdx,%rax
    872f:	0f 83 4b 07 00 00    	jae    8e80 <f12+0x1180>
    8735:	48 01 c1             	add    %rax,%rcx
    8738:	80 39 01             	cmpb   $0x1,(%rcx)
    873b:	0f 85 3f 07 00 00    	jne    8e80 <f12+0x1180>
    8741:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
    8746:	49 89 dd             	mov    %rbx,%r13
    8749:	31 ff                	xor    %edi,%edi
    874b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8750:	f2 0f 10 0d e0 44 00 	movsd  0x44e0(%rip),%xmm1        # cc38 <msg.4+0xc8>
    8757:	00 
    8758:	48 8d 50 08          	lea    0x8(%rax),%rdx
    875c:	31 c0                	xor    %eax,%eax
    875e:	4d 85 e4             	test   %r12,%r12
    8761:	75 2b                	jne    878e <f12+0xa8e>
    8763:	eb 3b                	jmp    87a0 <f12+0xaa0>
    8765:	0f 1f 00             	nopl   (%rax)
    8768:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    876d:	0f 88 5f 0b 00 00    	js     92d2 <f12+0x15d2>
    8773:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8778:	48 83 c0 01          	add    $0x1,%rax
    877c:	48 83 c2 08          	add    $0x8,%rdx
    8780:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8784:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8789:	49 39 c4             	cmp    %rax,%r12
    878c:	74 12                	je     87a0 <f12+0xaa0>
    878e:	48 8d 4b 08          	lea    0x8(%rbx),%rcx
    8792:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8796:	79 d0                	jns    8768 <f12+0xa68>
    8798:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    879c:	eb ca                	jmp    8768 <f12+0xa68>
    879e:	66 90                	xchg   %ax,%ax
    87a0:	e8 4b f0 ff ff       	call   77f0 <fwp_drop4>
    87a5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    87aa:	31 d2                	xor    %edx,%edx
    87ac:	48 89 c8             	mov    %rcx,%rax
    87af:	48 85 c9             	test   %rcx,%rcx
    87b2:	0f 84 a7 09 00 00    	je     915f <f12+0x145f>
    87b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87bf:	00 
    87c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    87c4:	48 83 c2 01          	add    $0x1,%rdx
    87c8:	48 85 c0             	test   %rax,%rax
    87cb:	75 f3                	jne    87c0 <f12+0xac0>
    87cd:	49 8b 45 00          	mov    0x0(%r13),%rax
    87d1:	49 89 c7             	mov    %rax,%r15
    87d4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    87d9:	48 85 c0             	test   %rax,%rax
    87dc:	0f 88 f3 05 00 00    	js     8dd5 <f12+0x10d5>
    87e2:	48 8b 0d af 93 01 00 	mov    0x193af(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    87e9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    87ee:	48 2b 05 7b 93 01 00 	sub    0x1937b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    87f5:	48 c1 e1 10          	shl    $0x10,%rcx
    87f9:	48 39 c8             	cmp    %rcx,%rax
    87fc:	0f 83 d3 05 00 00    	jae    8dd5 <f12+0x10d5>
    8802:	48 89 c1             	mov    %rax,%rcx
    8805:	48 c1 e9 10          	shr    $0x10,%rcx
    8809:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    880d:	48 8b 0d a4 93 01 00 	mov    0x193a4(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    8814:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    8818:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    881c:	48 85 ff             	test   %rdi,%rdi
    881f:	0f 84 b0 05 00 00    	je     8dd5 <f12+0x10d5>
    8825:	0f b6 0e             	movzbl (%rsi),%ecx
    8828:	80 f9 02             	cmp    $0x2,%cl
    882b:	0f 84 8f 05 00 00    	je     8dc0 <f12+0x10c0>
    8831:	80 f9 01             	cmp    $0x1,%cl
    8834:	0f 85 8f 05 00 00    	jne    8dc9 <f12+0x10c9>
    883a:	8b 4e 18             	mov    0x18(%rsi),%ecx
    883d:	0f b7 c0             	movzwl %ax,%eax
    8840:	48 0f af c1          	imul   %rcx,%rax
    8844:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    8847:	48 c1 e8 20          	shr    $0x20,%rax
    884b:	48 39 c8             	cmp    %rcx,%rax
    884e:	0f 83 75 05 00 00    	jae    8dc9 <f12+0x10c9>
    8854:	48 01 c7             	add    %rax,%rdi
    8857:	80 3f 01             	cmpb   $0x1,(%rdi)
    885a:	0f 85 69 05 00 00    	jne    8dc9 <f12+0x10c9>
    8860:	4c 39 fa             	cmp    %r15,%rdx
    8863:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8867:	4c 89 fd             	mov    %r15,%rbp
    886a:	4d 85 ff             	test   %r15,%r15
    886d:	0f 84 70 0a 00 00    	je     92e3 <f12+0x15e3>
    8873:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    887a:	00 
    887b:	4d 8d 65 08          	lea    0x8(%r13),%r12
    887f:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8884:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8889:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    8890:	00 
    8891:	31 c0                	xor    %eax,%eax
    8893:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8897:	eb 44                	jmp    88dd <f12+0xbdd>
    8899:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    889f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88a6:	00 00 00 00 
    88aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88b1:	00 00 00 00 
    88b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88bc:	00 00 00 00 
    88c0:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    88c5:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    88ca:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    88d0:	48 83 c0 08          	add    $0x8,%rax
    88d4:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    88d8:	49 39 c0             	cmp    %rax,%r8
    88db:	74 1b                	je     88f8 <f12+0xbf8>
    88dd:	48 89 fe             	mov    %rdi,%rsi
    88e0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    88e5:	79 d9                	jns    88c0 <f12+0xbc0>
    88e7:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    88ec:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    88f0:	eb ce                	jmp    88c0 <f12+0xbc0>
    88f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    88fd:	48 85 d2             	test   %rdx,%rdx
    8900:	0f 84 a7 09 00 00    	je     92ad <f12+0x15ad>
    8906:	4c 8b 05 8b 92 01 00 	mov    0x1928b(%rip),%r8        # 21b98 <fwp_heap+0x13d8>
    890d:	4c 8b 15 5c 92 01 00 	mov    0x1925c(%rip),%r10        # 21b70 <fwp_heap+0x13b0>
    8914:	45 31 ff             	xor    %r15d,%r15d
    8917:	4c 8b 1d 9a 92 01 00 	mov    0x1929a(%rip),%r11        # 21bb8 <fwp_heap+0x13f8>
    891e:	49 c1 e0 10          	shl    $0x10,%r8
    8922:	eb 1a                	jmp    893e <f12+0xc3e>
    8924:	0f 1f 40 00          	nopl   0x0(%rax)
    8928:	49 83 c7 01          	add    $0x1,%r15
    892c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8930:	49 39 ef             	cmp    %rbp,%r15
    8933:	0f 83 37 02 00 00    	jae    8b70 <f12+0xe70>
    8939:	48 85 d2             	test   %rdx,%rdx
    893c:	74 52                	je     8990 <f12+0xc90>
    893e:	48 89 d0             	mov    %rdx,%rax
    8941:	4c 29 d0             	sub    %r10,%rax
    8944:	4c 39 c0             	cmp    %r8,%rax
    8947:	73 47                	jae    8990 <f12+0xc90>
    8949:	48 89 c6             	mov    %rax,%rsi
    894c:	48 c1 ee 10          	shr    $0x10,%rsi
    8950:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8954:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    8958:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    895c:	48 85 ff             	test   %rdi,%rdi
    895f:	74 2f                	je     8990 <f12+0xc90>
    8961:	0f b6 1e             	movzbl (%rsi),%ebx
    8964:	80 fb 02             	cmp    $0x2,%bl
    8967:	0f 84 e3 01 00 00    	je     8b50 <f12+0xe50>
    896d:	80 fb 01             	cmp    $0x1,%bl
    8970:	75 1e                	jne    8990 <f12+0xc90>
    8972:	8b 5e 18             	mov    0x18(%rsi),%ebx
    8975:	0f b7 c0             	movzwl %ax,%eax
    8978:	8b 76 1c             	mov    0x1c(%rsi),%esi
    897b:	48 0f af c3          	imul   %rbx,%rax
    897f:	48 c1 e8 20          	shr    $0x20,%rax
    8983:	48 39 f0             	cmp    %rsi,%rax
    8986:	73 08                	jae    8990 <f12+0xc90>
    8988:	48 01 c7             	add    %rax,%rdi
    898b:	80 3f 01             	cmpb   $0x1,(%rdi)
    898e:	74 98                	je     8928 <f12+0xc28>
    8990:	49 39 ef             	cmp    %rbp,%r15
    8993:	0f 83 d7 01 00 00    	jae    8b70 <f12+0xe70>
    8999:	4c 8b 2d 40 42 00 00 	mov    0x4240(%rip),%r13        # cbe0 <msg.4+0x70>
    89a0:	45 31 f6             	xor    %r14d,%r14d
    89a3:	48 8d 1d 16 7e 01 00 	lea    0x17e16(%rip),%rbx        # 207c0 <fwp_heap>
    89aa:	e9 19 01 00 00       	jmp    8ac8 <f12+0xdc8>
    89af:	90                   	nop
    89b0:	49 8b 10             	mov    (%r8),%rdx
    89b3:	48 f7 d2             	not    %rdx
    89b6:	48 89 10             	mov    %rdx,(%rax)
    89b9:	49 83 fb 18          	cmp    $0x18,%r11
    89bd:	76 3b                	jbe    89fa <f12+0xcfa>
    89bf:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    89c3:	49 8d 78 18          	lea    0x18(%r8),%rdi
    89c7:	31 f6                	xor    %esi,%esi
    89c9:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    89ce:	48 c1 e8 03          	shr    $0x3,%rax
    89d2:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    89d7:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    89de:	00 
    89df:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    89e5:	e8 d6 aa ff ff       	call   34c0 <memset@plt>
    89ea:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    89ef:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    89f4:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    89fa:	4c 89 d8             	mov    %r11,%rax
    89fd:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8a04:	0f 82 c3 08 00 00    	jb     92cd <f12+0x15cd>
    8a0a:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8a11:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8a18:	73 07                	jae    8a21 <f12+0xd21>
    8a1a:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8a21:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8a25:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    8a2a:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8a31:	00 
    8a32:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8a39:	00 
    8a3a:	66 49 0f 6e ee       	movq   %r14,%xmm5
    8a3f:	4d 89 28             	mov    %r13,(%r8)
    8a42:	4c 89 c0             	mov    %r8,%rax
    8a45:	4d 89 c6             	mov    %r8,%r14
    8a48:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8a4c:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8a51:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8a58:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8a5f:	48 c1 e2 10          	shl    $0x10,%rdx
    8a63:	48 39 d0             	cmp    %rdx,%rax
    8a66:	73 57                	jae    8abf <f12+0xdbf>
    8a68:	48 89 c2             	mov    %rax,%rdx
    8a6b:	48 c1 ea 10          	shr    $0x10,%rdx
    8a6f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8a73:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8a7a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    8a7e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8a82:	48 85 d2             	test   %rdx,%rdx
    8a85:	74 38                	je     8abf <f12+0xdbf>
    8a87:	0f b6 3e             	movzbl (%rsi),%edi
    8a8a:	40 80 ff 02          	cmp    $0x2,%dil
    8a8e:	0f 84 7c 01 00 00    	je     8c10 <f12+0xf10>
    8a94:	40 80 ff 01          	cmp    $0x1,%dil
    8a98:	75 25                	jne    8abf <f12+0xdbf>
    8a9a:	8b 7e 18             	mov    0x18(%rsi),%edi
    8a9d:	0f b7 c0             	movzwl %ax,%eax
    8aa0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8aa3:	48 0f af c7          	imul   %rdi,%rax
    8aa7:	48 c1 e8 20          	shr    $0x20,%rax
    8aab:	48 39 f0             	cmp    %rsi,%rax
    8aae:	73 0f                	jae    8abf <f12+0xdbf>
    8ab0:	48 01 c2             	add    %rax,%rdx
    8ab3:	80 3a ff             	cmpb   $0xff,(%rdx)
    8ab6:	0f 84 74 04 00 00    	je     8f30 <f12+0x1230>
    8abc:	c6 02 01             	movb   $0x1,(%rdx)
    8abf:	49 39 ef             	cmp    %rbp,%r15
    8ac2:	0f 83 68 01 00 00    	jae    8c30 <f12+0xf30>
    8ac8:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    8ace:	48 83 ed 01          	sub    $0x1,%rbp
    8ad2:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8ad8:	85 f6                	test   %esi,%esi
    8ada:	74 4c                	je     8b28 <f12+0xe28>
    8adc:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8ae3:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8aea:	00 
    8aeb:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8aef:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8af3:	4c 8b 00             	mov    (%rax),%r8
    8af6:	4d 85 c0             	test   %r8,%r8
    8af9:	0f 85 b1 fe ff ff    	jne    89b0 <f12+0xcb0>
    8aff:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8b03:	4d 85 c0             	test   %r8,%r8
    8b06:	74 20                	je     8b28 <f12+0xe28>
    8b08:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8b0c:	4c 29 c2             	sub    %r8,%rdx
    8b0f:	4c 39 da             	cmp    %r11,%rdx
    8b12:	72 14                	jb     8b28 <f12+0xe28>
    8b14:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8b18:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8b1c:	e9 98 fe ff ff       	jmp    89b9 <f12+0xcb9>
    8b21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b28:	31 f6                	xor    %esi,%esi
    8b2a:	bf 18 00 00 00       	mov    $0x18,%edi
    8b2f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8b35:	e8 56 d1 ff ff       	call   5c90 <fwp_heap_alloc>
    8b3a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8b40:	49 89 c0             	mov    %rax,%r8
    8b43:	e9 f2 fe ff ff       	jmp    8a3a <f12+0xd3a>
    8b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b4f:	00 
    8b50:	66 85 c0             	test   %ax,%ax
    8b53:	0f 84 32 fe ff ff    	je     898b <f12+0xc8b>
    8b59:	49 39 ef             	cmp    %rbp,%r15
    8b5c:	0f 82 37 fe ff ff    	jb     8999 <f12+0xc99>
    8b62:	0f 1f 00             	nopl   (%rax)
    8b65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b6c:	00 00 00 00 
    8b70:	45 31 f6             	xor    %r14d,%r14d
    8b73:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8b78:	4c 89 e2             	mov    %r12,%rdx
    8b7b:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    8b7f:	90                   	nop
    8b80:	48 8b 0a             	mov    (%rdx),%rcx
    8b83:	48 83 c2 08          	add    $0x8,%rdx
    8b87:	48 89 c6             	mov    %rax,%rsi
    8b8a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8b8e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8b92:	48 39 d7             	cmp    %rdx,%rdi
    8b95:	75 e9                	jne    8b80 <f12+0xe80>
    8b97:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
    8b9b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    8b9f:	85 c9                	test   %ecx,%ecx
    8ba1:	0f 84 69 04 00 00    	je     9010 <f12+0x1310>
    8ba7:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8bac:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8bb1:	45 31 e4             	xor    %r12d,%r12d
    8bb4:	90                   	nop
    8bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bbc:	00 00 00 00 
    8bc0:	4c 89 e7             	mov    %r12,%rdi
    8bc3:	e8 c8 cb ff ff       	call   5790 <fwp_mem_free>
    8bc8:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    8bcd:	e8 1e ec ff ff       	call   77f0 <fwp_drop4>
    8bd2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8bd7:	e8 44 dc ff ff       	call   6820 <fwp_drop0>
    8bdc:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    8be3:	00 
    8be4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8beb:	00 00 
    8bed:	0f 85 40 07 00 00    	jne    9333 <f12+0x1633>
    8bf3:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    8bfa:	4c 89 f0             	mov    %r14,%rax
    8bfd:	5b                   	pop    %rbx
    8bfe:	5d                   	pop    %rbp
    8bff:	41 5c                	pop    %r12
    8c01:	41 5d                	pop    %r13
    8c03:	41 5e                	pop    %r14
    8c05:	41 5f                	pop    %r15
    8c07:	c3                   	ret
    8c08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c0f:	00 
    8c10:	66 85 c0             	test   %ax,%ax
    8c13:	0f 84 9a fe ff ff    	je     8ab3 <f12+0xdb3>
    8c19:	49 39 ef             	cmp    %rbp,%r15
    8c1c:	0f 82 a6 fe ff ff    	jb     8ac8 <f12+0xdc8>
    8c22:	0f 1f 00             	nopl   (%rax)
    8c25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c2c:	00 00 00 00 
    8c30:	4d 85 ff             	test   %r15,%r15
    8c33:	0f 85 3a ff ff ff    	jne    8b73 <f12+0xe73>
    8c39:	8b 54 24 40          	mov    0x40(%rsp),%edx
    8c3d:	85 d2                	test   %edx,%edx
    8c3f:	4d 0f 45 e7          	cmovne %r15,%r12
    8c43:	66 90                	xchg   %ax,%ax
    8c45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c4c:	00 00 00 00 
    8c50:	48 85 ed             	test   %rbp,%rbp
    8c53:	0f 84 67 ff ff ff    	je     8bc0 <f12+0xec0>
    8c59:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    8c5f:	48 83 ed 01          	sub    $0x1,%rbp
    8c63:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8c69:	85 c0                	test   %eax,%eax
    8c6b:	0f 84 e7 05 00 00    	je     9258 <f12+0x1558>
    8c71:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8c78:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    8c7f:	00 
    8c80:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8c84:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8c88:	4c 8b 38             	mov    (%rax),%r15
    8c8b:	4d 85 ff             	test   %r15,%r15
    8c8e:	0f 84 9c 05 00 00    	je     9230 <f12+0x1530>
    8c94:	49 8b 17             	mov    (%r15),%rdx
    8c97:	48 f7 d2             	not    %rdx
    8c9a:	48 89 10             	mov    %rdx,(%rax)
    8c9d:	49 83 f8 18          	cmp    $0x18,%r8
    8ca1:	76 31                	jbe    8cd4 <f12+0xfd4>
    8ca3:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8ca7:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    8cab:	31 f6                	xor    %esi,%esi
    8cad:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8cb2:	48 c1 e8 03          	shr    $0x3,%rax
    8cb6:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    8cbc:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8cc3:	00 
    8cc4:	e8 f7 a7 ff ff       	call   34c0 <memset@plt>
    8cc9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8cce:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    8cd4:	4c 89 c0             	mov    %r8,%rax
    8cd7:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8cde:	0f 82 e9 05 00 00    	jb     92cd <f12+0x15cd>
    8ce4:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8ceb:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8cf2:	73 07                	jae    8cfb <f12+0xffb>
    8cf4:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8cfb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8cff:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8d04:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8d0b:	00 
    8d0c:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8d13:	00 
    8d14:	66 49 0f 6e f6       	movq   %r14,%xmm6
    8d19:	4d 89 2f             	mov    %r13,(%r15)
    8d1c:	4c 89 f8             	mov    %r15,%rax
    8d1f:	4d 89 fe             	mov    %r15,%r14
    8d22:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8d26:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8d2b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8d32:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8d39:	48 c1 e2 10          	shl    $0x10,%rdx
    8d3d:	48 39 d0             	cmp    %rdx,%rax
    8d40:	0f 83 0a ff ff ff    	jae    8c50 <f12+0xf50>
    8d46:	48 89 c2             	mov    %rax,%rdx
    8d49:	48 c1 ea 10          	shr    $0x10,%rdx
    8d4d:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8d51:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8d58:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8d5c:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8d60:	4d 85 ff             	test   %r15,%r15
    8d63:	0f 84 e7 fe ff ff    	je     8c50 <f12+0xf50>
    8d69:	0f b6 32             	movzbl (%rdx),%esi
    8d6c:	40 80 fe 02          	cmp    $0x2,%sil
    8d70:	0f 84 0a 05 00 00    	je     9280 <f12+0x1580>
    8d76:	40 80 fe 01          	cmp    $0x1,%sil
    8d7a:	0f 85 d0 fe ff ff    	jne    8c50 <f12+0xf50>
    8d80:	8b 72 18             	mov    0x18(%rdx),%esi
    8d83:	0f b7 c0             	movzwl %ax,%eax
    8d86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d89:	48 0f af c6          	imul   %rsi,%rax
    8d8d:	48 c1 e8 20          	shr    $0x20,%rax
    8d91:	48 39 d0             	cmp    %rdx,%rax
    8d94:	0f 83 b6 fe ff ff    	jae    8c50 <f12+0xf50>
    8d9a:	49 01 c7             	add    %rax,%r15
    8d9d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8da1:	0f 84 f9 04 00 00    	je     92a0 <f12+0x15a0>
    8da7:	41 c6 07 01          	movb   $0x1,(%r15)
    8dab:	48 85 ed             	test   %rbp,%rbp
    8dae:	0f 85 a5 fe ff ff    	jne    8c59 <f12+0xf59>
    8db4:	e9 07 fe ff ff       	jmp    8bc0 <f12+0xec0>
    8db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8dc0:	66 85 c0             	test   %ax,%ax
    8dc3:	0f 84 8e fa ff ff    	je     8857 <f12+0xb57>
    8dc9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    8dcf:	0f 84 23 03 00 00    	je     90f8 <f12+0x13f8>
    8dd5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8dda:	31 ed                	xor    %ebp,%ebp
    8ddc:	0f 1f 40 00          	nopl   0x0(%rax)
    8de0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8de4:	48 89 ea             	mov    %rbp,%rdx
    8de7:	48 83 c5 01          	add    $0x1,%rbp
    8deb:	48 85 c0             	test   %rax,%rax
    8dee:	75 f0                	jne    8de0 <f12+0x10e0>
    8df0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8df7:	ff ff 1f 
    8dfa:	48 39 e8             	cmp    %rbp,%rax
    8dfd:	0f 82 00 05 00 00    	jb     9303 <f12+0x1603>
    8e03:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8e0a:	00 
    8e0b:	be 02 00 00 00       	mov    $0x2,%esi
    8e10:	e8 7b ce ff ff       	call   5c90 <fwp_heap_alloc>
    8e15:	49 39 ef             	cmp    %rbp,%r15
    8e18:	49 89 c4             	mov    %rax,%r12
    8e1b:	48 89 c2             	mov    %rax,%rdx
    8e1e:	49 0f 46 ef          	cmovbe %r15,%rbp
    8e22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8e27:	0f 1f 00             	nopl   (%rax)
    8e2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e31:	00 00 00 00 
    8e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e3c:	00 00 00 00 
    8e40:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8e44:	48 83 c2 08          	add    $0x8,%rdx
    8e48:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8e4c:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e50:	48 85 c0             	test   %rax,%rax
    8e53:	75 eb                	jne    8e40 <f12+0x1140>
    8e55:	48 85 ed             	test   %rbp,%rbp
    8e58:	0f 84 ac 02 00 00    	je     910a <f12+0x140a>
    8e5e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    8e65:	00 
    8e66:	e9 14 fa ff ff       	jmp    887f <f12+0xb7f>
    8e6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e70:	66 85 c0             	test   %ax,%ax
    8e73:	0f 84 bf f8 ff ff    	je     8738 <f12+0xa38>
    8e79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e80:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8e87:	ff ff 1f 
    8e8a:	4c 39 e0             	cmp    %r12,%rax
    8e8d:	0f 82 58 04 00 00    	jb     92eb <f12+0x15eb>
    8e93:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8e9a:	00 
    8e9b:	be 01 00 00 00       	mov    $0x1,%esi
    8ea0:	e8 eb cd ff ff       	call   5c90 <fwp_heap_alloc>
    8ea5:	4c 89 20             	mov    %r12,(%rax)
    8ea8:	48 8b 15 e9 8c 01 00 	mov    0x18ce9(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    8eaf:	49 89 c5             	mov    %rax,%r13
    8eb2:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    8eb7:	48 2b 05 b2 8c 01 00 	sub    0x18cb2(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    8ebe:	48 c1 e2 10          	shl    $0x10,%rdx
    8ec2:	48 39 d0             	cmp    %rdx,%rax
    8ec5:	73 57                	jae    8f1e <f12+0x121e>
    8ec7:	48 89 c2             	mov    %rax,%rdx
    8eca:	48 c1 ea 10          	shr    $0x10,%rdx
    8ece:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ed2:	48 8b 15 df 8c 01 00 	mov    0x18cdf(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    8ed9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8edd:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8ee1:	4d 85 ff             	test   %r15,%r15
    8ee4:	74 38                	je     8f1e <f12+0x121e>
    8ee6:	0f b6 0a             	movzbl (%rdx),%ecx
    8ee9:	80 f9 02             	cmp    $0x2,%cl
    8eec:	0f 84 26 02 00 00    	je     9118 <f12+0x1418>
    8ef2:	80 f9 01             	cmp    $0x1,%cl
    8ef5:	75 27                	jne    8f1e <f12+0x121e>
    8ef7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8efa:	0f b7 c0             	movzwl %ax,%eax
    8efd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f00:	48 0f af c1          	imul   %rcx,%rax
    8f04:	48 c1 e8 20          	shr    $0x20,%rax
    8f08:	48 39 d0             	cmp    %rdx,%rax
    8f0b:	73 11                	jae    8f1e <f12+0x121e>
    8f0d:	49 01 c7             	add    %rax,%r15
    8f10:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8f14:	0f 84 c2 02 00 00    	je     91dc <f12+0x14dc>
    8f1a:	41 c6 07 01          	movb   $0x1,(%r15)
    8f1e:	48 89 df             	mov    %rbx,%rdi
    8f21:	e9 25 f8 ff ff       	jmp    874b <f12+0xa4b>
    8f26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f2d:	00 00 00 
    8f30:	48 89 d7             	mov    %rdx,%rdi
    8f33:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    8f38:	e8 13 c6 ff ff       	call   5550 <fwp_rc_forget_slot>
    8f3d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f42:	e9 75 fb ff ff       	jmp    8abc <f12+0xdbc>
    8f47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8f4e:	00 00 
    8f50:	48 8d 3d 09 de ff ff 	lea    -0x21f7(%rip),%rdi        # 6d60 <fwp_tape_finish>
    8f57:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8f5d:	e8 4e 2e 00 00       	call   bdb0 <atexit>
    8f62:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8f68:	85 c0                	test   %eax,%eax
    8f6a:	75 59                	jne    8fc5 <f12+0x12c5>
    8f6c:	c7 05 ea 70 00 00 01 	movl   $0x1,0x70ea(%rip)        # 10060 <registered_finish.0>
    8f73:	00 00 00 
    8f76:	e9 bb ee ff ff       	jmp    7e36 <f12+0x136>
    8f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f80:	66 85 c0             	test   %ax,%ax
    8f83:	0f 85 56 ee ff ff    	jne    7ddf <f12+0xdf>
    8f89:	e9 3d ee ff ff       	jmp    7dcb <f12+0xcb>
    8f8e:	66 90                	xchg   %ax,%ax
    8f90:	48 89 eb             	mov    %rbp,%rbx
    8f93:	48 39 d5             	cmp    %rdx,%rbp
    8f96:	0f 8f b9 f4 ff ff    	jg     8455 <f12+0x755>
    8f9c:	48 85 db             	test   %rbx,%rbx
    8f9f:	0f 84 1d f5 ff ff    	je     84c2 <f12+0x7c2>
    8fa5:	4d 85 f6             	test   %r14,%r14
    8fa8:	0f 85 0b f5 ff ff    	jne    84b9 <f12+0x7b9>
    8fae:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    8fb5:	00 
    8fb6:	4c 89 e7             	mov    %r12,%rdi
    8fb9:	48 89 05 98 94 01 00 	mov    %rax,0x19498(%rip)        # 22458 <fwp_cleanups>
    8fc0:	e8 ab c0 ff ff       	call   5070 <fwp_tape_buffers_release>
    8fc5:	48 8b 0d 74 70 00 00 	mov    0x7074(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    8fcc:	ba 13 00 00 00       	mov    $0x13,%edx
    8fd1:	be 01 00 00 00       	mov    $0x1,%esi
    8fd6:	48 8d 3d 2b 30 00 00 	lea    0x302b(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    8fdd:	e8 9e a6 ff ff       	call   3680 <fwrite@plt>
    8fe2:	31 ff                	xor    %edi,%edi
    8fe4:	e8 d7 a5 ff ff       	call   35c0 <fflush@plt>
    8fe9:	bf 66 00 00 00       	mov    $0x66,%edi
    8fee:	e8 ad a6 ff ff       	call   36a0 <_Exit@plt>
    8ff3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ff8:	66 85 c0             	test   %ax,%ax
    8ffb:	0f 85 8f f6 ff ff    	jne    8690 <f12+0x990>
    9001:	e9 7a f6 ff ff       	jmp    8680 <f12+0x980>
    9006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    900d:	00 00 00 
    9010:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9015:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    901a:	e9 a1 fb ff ff       	jmp    8bc0 <f12+0xec0>
    901f:	90                   	nop
    9020:	66 0f 6f 0d 78 70 01 	movdqa 0x17078(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    9027:	00 
    9028:	48 c7 05 55 70 01 00 	movq   $0x0,0x17055(%rip)        # 20088 <fwp_tape_cached_bytes>
    902f:	00 00 00 00 
    9033:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9039:	48 8b 05 80 70 01 00 	mov    0x17080(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    9040:	66 0f 6f 0d 68 70 01 	movdqa 0x17068(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    9047:	00 
    9048:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    904d:	48 8b 05 74 70 01 00 	mov    0x17074(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    9054:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    905a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    905e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9063:	48 8b 05 66 70 01 00 	mov    0x17066(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    906a:	0f 29 0d 2f 70 01 00 	movaps %xmm1,0x1702f(%rip)        # 200a0 <fwp_tape_workspace>
    9071:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9076:	0f 29 0d 33 70 01 00 	movaps %xmm1,0x17033(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    907d:	48 c7 05 48 70 01 00 	movq   $0x0,0x17048(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    9084:	00 00 00 00 
    9088:	0f 29 0d 31 70 01 00 	movaps %xmm1,0x17031(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    908f:	e9 d2 ee ff ff       	jmp    7f66 <f12+0x266>
    9094:	0f 1f 40 00          	nopl   0x0(%rax)
    9098:	48 89 eb             	mov    %rbp,%rbx
    909b:	e9 b5 f3 ff ff       	jmp    8455 <f12+0x755>
    90a0:	4d 85 f6             	test   %r14,%r14
    90a3:	0f 84 05 ff ff ff    	je     8fae <f12+0x12ae>
    90a9:	49 89 db             	mov    %rbx,%r11
    90ac:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    90b3:	00 
    90b4:	31 f6                	xor    %esi,%esi
    90b6:	4c 89 f7             	mov    %r14,%rdi
    90b9:	49 29 eb             	sub    %rbp,%r11
    90bc:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    90c1:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    90c6:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    90cb:	e8 f0 a3 ff ff       	call   34c0 <memset@plt>
    90d0:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    90d5:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    90da:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    90df:	e9 f3 f3 ff ff       	jmp    84d7 <f12+0x7d7>
    90e4:	0f 1f 40 00          	nopl   0x0(%rax)
    90e8:	be 68 00 00 00       	mov    $0x68,%esi
    90ed:	41 be 01 00 00 00    	mov    $0x1,%r14d
    90f3:	e9 c2 ed ff ff       	jmp    7eba <f12+0x1ba>
    90f8:	be 02 00 00 00       	mov    $0x2,%esi
    90fd:	bf 08 00 00 00       	mov    $0x8,%edi
    9102:	e8 89 cb ff ff       	call   5c90 <fwp_heap_alloc>
    9107:	49 89 c4             	mov    %rax,%r12
    910a:	45 31 f6             	xor    %r14d,%r14d
    910d:	e9 ae fa ff ff       	jmp    8bc0 <f12+0xec0>
    9112:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9118:	66 85 c0             	test   %ax,%ax
    911b:	0f 85 fd fd ff ff    	jne    8f1e <f12+0x121e>
    9121:	e9 ea fd ff ff       	jmp    8f10 <f12+0x1210>
    9126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    912d:	00 00 00 
    9130:	48 89 d7             	mov    %rdx,%rdi
    9133:	be 08 00 00 00       	mov    $0x8,%esi
    9138:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    913d:	e8 de a3 ff ff       	call   3520 <calloc@plt>
    9142:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    9147:	49 89 c6             	mov    %rax,%r14
    914a:	e9 51 f3 ff ff       	jmp    84a0 <f12+0x7a0>
    914f:	31 ff                	xor    %edi,%edi
    9151:	e8 fa b0 ff ff       	call   4250 <descent_phase_step>
    9156:	66 0f ef c0          	pxor   %xmm0,%xmm0
    915a:	e9 c7 ec ff ff       	jmp    7e26 <f12+0x126>
    915f:	49 8b 4d 00          	mov    0x0(%r13),%rcx
    9163:	48 85 c9             	test   %rcx,%rcx
    9166:	78 90                	js     90f8 <f12+0x13f8>
    9168:	48 8b 35 29 8a 01 00 	mov    0x18a29(%rip),%rsi        # 21b98 <fwp_heap+0x13d8>
    916f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    9174:	48 2b 05 f5 89 01 00 	sub    0x189f5(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    917b:	48 c1 e6 10          	shl    $0x10,%rsi
    917f:	48 39 f0             	cmp    %rsi,%rax
    9182:	0f 83 70 ff ff ff    	jae    90f8 <f12+0x13f8>
    9188:	48 89 c6             	mov    %rax,%rsi
    918b:	48 c1 ee 10          	shr    $0x10,%rsi
    918f:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9193:	48 8b 35 1e 8a 01 00 	mov    0x18a1e(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    919a:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    919e:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    91a2:	48 85 ff             	test   %rdi,%rdi
    91a5:	0f 84 4d ff ff ff    	je     90f8 <f12+0x13f8>
    91ab:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    91b0:	49 89 cf             	mov    %rcx,%r15
    91b3:	e9 6d f6 ff ff       	jmp    8825 <f12+0xb25>
    91b8:	48 89 d7             	mov    %rdx,%rdi
    91bb:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    91c0:	e8 8b c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    91c5:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    91ca:	e9 44 ef ff ff       	jmp    8113 <f12+0x413>
    91cf:	4c 89 e7             	mov    %r12,%rdi
    91d2:	e8 79 c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    91d7:	e9 af f4 ff ff       	jmp    868b <f12+0x98b>
    91dc:	4c 89 ff             	mov    %r15,%rdi
    91df:	e8 6c c3 ff ff       	call   5550 <fwp_rc_forget_slot>
    91e4:	e9 31 fd ff ff       	jmp    8f1a <f12+0x121a>
    91e9:	e8 42 c2 ff ff       	call   5430 <fwp_rc_wide_dup>
    91ee:	e9 ec eb ff ff       	jmp    7ddf <f12+0xdf>
    91f3:	49 89 db             	mov    %rbx,%r11
    91f6:	4c 8d 4b ff          	lea    -0x1(%rbx),%r9
    91fa:	31 f6                	xor    %esi,%esi
    91fc:	4c 89 f7             	mov    %r14,%rdi
    91ff:	49 29 eb             	sub    %rbp,%r11
    9202:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9209:	00 
    920a:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    920f:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    9214:	e8 a7 a2 ff ff       	call   34c0 <memset@plt>
    9219:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    921e:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    9223:	e9 a7 f2 ff ff       	jmp    84cf <f12+0x7cf>
    9228:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    922f:	00 
    9230:	4c 8b 78 08          	mov    0x8(%rax),%r15
    9234:	4d 85 ff             	test   %r15,%r15
    9237:	74 1f                	je     9258 <f12+0x1558>
    9239:	48 8b 50 10          	mov    0x10(%rax),%rdx
    923d:	4c 29 fa             	sub    %r15,%rdx
    9240:	4c 39 c2             	cmp    %r8,%rdx
    9243:	72 13                	jb     9258 <f12+0x1558>
    9245:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    9249:	48 89 50 08          	mov    %rdx,0x8(%rax)
    924d:	e9 4b fa ff ff       	jmp    8c9d <f12+0xf9d>
    9252:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9258:	31 f6                	xor    %esi,%esi
    925a:	bf 18 00 00 00       	mov    $0x18,%edi
    925f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9265:	e8 26 ca ff ff       	call   5c90 <fwp_heap_alloc>
    926a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9270:	49 89 c7             	mov    %rax,%r15
    9273:	e9 9c fa ff ff       	jmp    8d14 <f12+0x1014>
    9278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    927f:	00 
    9280:	66 85 c0             	test   %ax,%ax
    9283:	0f 85 c7 f9 ff ff    	jne    8c50 <f12+0xf50>
    9289:	41 80 3f ff          	cmpb   $0xff,(%r15)
    928d:	0f 85 14 fb ff ff    	jne    8da7 <f12+0x10a7>
    9293:	66 90                	xchg   %ax,%ax
    9295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    929c:	00 00 00 00 
    92a0:	4c 89 ff             	mov    %r15,%rdi
    92a3:	e8 a8 c2 ff ff       	call   5550 <fwp_rc_forget_slot>
    92a8:	e9 fa fa ff ff       	jmp    8da7 <f12+0x10a7>
    92ad:	45 31 ff             	xor    %r15d,%r15d
    92b0:	e9 e4 f6 ff ff       	jmp    8999 <f12+0xc99>
    92b5:	48 8d 3d f4 35 00 00 	lea    0x35f4(%rip),%rdi        # c8b0 <_IO_stdin_used+0x8b0>
    92bc:	e8 2f b1 ff ff       	call   43f0 <fwp_trap>
    92c1:	48 8d 3d 9f 2e 00 00 	lea    0x2e9f(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    92c8:	e8 23 b1 ff ff       	call   43f0 <fwp_trap>
    92cd:	e8 de a9 ff ff       	call   3cb0 <fwp_heap_oom>
    92d2:	48 8d 3d df 36 00 00 	lea    0x36df(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    92d9:	e8 12 b1 ff ff       	call   43f0 <fwp_trap>
    92de:	e8 1d a4 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    92e3:	45 31 e4             	xor    %r12d,%r12d
    92e6:	e9 1f fe ff ff       	jmp    910a <f12+0x140a>
    92eb:	48 8d 3d c6 2e 00 00 	lea    0x2ec6(%rip),%rdi        # c1b8 <_IO_stdin_used+0x1b8>
    92f2:	e8 f9 b0 ff ff       	call   43f0 <fwp_trap>
    92f7:	48 8d 3d 92 2e 00 00 	lea    0x2e92(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    92fe:	e8 ed b0 ff ff       	call   43f0 <fwp_trap>
    9303:	48 8d 3d a0 2e 00 00 	lea    0x2ea0(%rip),%rdi        # c1aa <_IO_stdin_used+0x1aa>
    930a:	e8 e1 b0 ff ff       	call   43f0 <fwp_trap>
    930f:	48 8d 3d e2 35 00 00 	lea    0x35e2(%rip),%rdi        # c8f8 <_IO_stdin_used+0x8f8>
    9316:	e8 d5 b0 ff ff       	call   43f0 <fwp_trap>
    931b:	48 8d 3d 66 36 00 00 	lea    0x3666(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    9322:	e8 c9 b0 ff ff       	call   43f0 <fwp_trap>
    9327:	48 8d 3d 2a 36 00 00 	lea    0x362a(%rip),%rdi        # c958 <_IO_stdin_used+0x958>
    932e:	e8 bd b0 ff ff       	call   43f0 <fwp_trap>
    9333:	e8 28 a1 ff ff       	call   3460 <__stack_chk_fail@plt>
    9338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    933f:	00 

0000000000009340 <fwp_owned_entry12>:
    9340:	f3 0f 1e fa          	endbr64
    9344:	48 8b 3f             	mov    (%rdi),%rdi
    9347:	e9 b4 e9 ff ff       	jmp    7d00 <f12>
    934c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009350 <e12>:
    9350:	f3 0f 1e fa          	endbr64
    9354:	53                   	push   %rbx
    9355:	48 8b 1f             	mov    (%rdi),%rbx
    9358:	48 89 df             	mov    %rbx,%rdi
    935b:	e8 30 d3 ff ff       	call   6690 <fwp_rc_share>
    9360:	48 89 df             	mov    %rbx,%rdi
    9363:	e8 98 e9 ff ff       	call   7d00 <f12>
    9368:	48 89 c3             	mov    %rax,%rbx
    936b:	48 89 c7             	mov    %rax,%rdi
    936e:	e8 1d d3 ff ff       	call   6690 <fwp_rc_share>
    9373:	48 89 d8             	mov    %rbx,%rax
    9376:	5b                   	pop    %rbx
    9377:	c3                   	ret
    9378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    937f:	00 

0000000000009380 <fwp_drop2>:
    9380:	48 8b 0d 11 88 01 00 	mov    0x18811(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    9387:	48 89 f8             	mov    %rdi,%rax
    938a:	48 2b 05 df 87 01 00 	sub    0x187df(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9391:	48 c1 e1 10          	shl    $0x10,%rcx
    9395:	48 39 c8             	cmp    %rcx,%rax
    9398:	0f 83 42 01 00 00    	jae    94e0 <fwp_drop2+0x160>
    939e:	48 83 ec 18          	sub    $0x18,%rsp
    93a2:	48 89 fa             	mov    %rdi,%rdx
    93a5:	4c 8d 05 14 74 01 00 	lea    0x17414(%rip),%r8        # 207c0 <fwp_heap>
    93ac:	48 89 c1             	mov    %rax,%rcx
    93af:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    93b6:	48 c1 e9 10          	shr    $0x10,%rcx
    93ba:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    93be:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    93c2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    93c6:	48 85 c9             	test   %rcx,%rcx
    93c9:	74 40                	je     940b <fwp_drop2+0x8b>
    93cb:	0f b6 3e             	movzbl (%rsi),%edi
    93ce:	40 80 ff 02          	cmp    $0x2,%dil
    93d2:	74 3c                	je     9410 <fwp_drop2+0x90>
    93d4:	40 80 ff 01          	cmp    $0x1,%dil
    93d8:	75 31                	jne    940b <fwp_drop2+0x8b>
    93da:	8b 7e 18             	mov    0x18(%rsi),%edi
    93dd:	0f b7 c0             	movzwl %ax,%eax
    93e0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    93e3:	48 0f af c7          	imul   %rdi,%rax
    93e7:	48 c1 e8 20          	shr    $0x20,%rax
    93eb:	48 39 f0             	cmp    %rsi,%rax
    93ee:	73 1b                	jae    940b <fwp_drop2+0x8b>
    93f0:	48 01 c1             	add    %rax,%rcx
    93f3:	0f b6 01             	movzbl (%rcx),%eax
    93f6:	84 c0                	test   %al,%al
    93f8:	74 11                	je     940b <fwp_drop2+0x8b>
    93fa:	3c 01                	cmp    $0x1,%al
    93fc:	74 22                	je     9420 <fwp_drop2+0xa0>
    93fe:	3c ff                	cmp    $0xff,%al
    9400:	0f 84 0a 01 00 00    	je     9510 <fwp_drop2+0x190>
    9406:	83 e8 01             	sub    $0x1,%eax
    9409:	88 01                	mov    %al,(%rcx)
    940b:	48 83 c4 18          	add    $0x18,%rsp
    940f:	c3                   	ret
    9410:	66 85 c0             	test   %ax,%ax
    9413:	74 de                	je     93f3 <fwp_drop2+0x73>
    9415:	48 83 c4 18          	add    $0x18,%rsp
    9419:	c3                   	ret
    941a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9420:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9424:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    942b:	48 89 f8             	mov    %rdi,%rax
    942e:	48 c1 e1 10          	shl    $0x10,%rcx
    9432:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9439:	48 39 c8             	cmp    %rcx,%rax
    943c:	73 62                	jae    94a0 <fwp_drop2+0x120>
    943e:	48 89 c1             	mov    %rax,%rcx
    9441:	48 c1 e9 10          	shr    $0x10,%rcx
    9445:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9449:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    944d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9451:	48 85 c9             	test   %rcx,%rcx
    9454:	74 4a                	je     94a0 <fwp_drop2+0x120>
    9456:	44 0f b6 0e          	movzbl (%rsi),%r9d
    945a:	41 80 f9 02          	cmp    $0x2,%r9b
    945e:	0f 84 9c 00 00 00    	je     9500 <fwp_drop2+0x180>
    9464:	41 80 f9 01          	cmp    $0x1,%r9b
    9468:	75 36                	jne    94a0 <fwp_drop2+0x120>
    946a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    946e:	0f b7 c0             	movzwl %ax,%eax
    9471:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9474:	49 0f af c1          	imul   %r9,%rax
    9478:	48 c1 e8 20          	shr    $0x20,%rax
    947c:	48 39 f0             	cmp    %rsi,%rax
    947f:	73 1f                	jae    94a0 <fwp_drop2+0x120>
    9481:	48 01 c1             	add    %rax,%rcx
    9484:	0f b6 01             	movzbl (%rcx),%eax
    9487:	84 c0                	test   %al,%al
    9489:	74 15                	je     94a0 <fwp_drop2+0x120>
    948b:	3c 01                	cmp    $0x1,%al
    948d:	74 59                	je     94e8 <fwp_drop2+0x168>
    948f:	3c ff                	cmp    $0xff,%al
    9491:	0f 84 ef 00 00 00    	je     9586 <fwp_drop2+0x206>
    9497:	83 e8 01             	sub    $0x1,%eax
    949a:	88 01                	mov    %al,(%rcx)
    949c:	0f 1f 40 00          	nopl   0x0(%rax)
    94a0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    94a4:	48 89 d7             	mov    %rdx,%rdi
    94a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    94ab:	e8 60 d2 ff ff       	call   6710 <fwp_rc_free_arr>
    94b0:	4c 8d 05 09 73 01 00 	lea    0x17309(%rip),%r8        # 207c0 <fwp_heap>
    94b7:	48 8b 04 24          	mov    (%rsp),%rax
    94bb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    94c2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    94c9:	48 c1 e2 10          	shl    $0x10,%rdx
    94cd:	48 39 d0             	cmp    %rdx,%rax
    94d0:	0f 83 35 ff ff ff    	jae    940b <fwp_drop2+0x8b>
    94d6:	48 8b 14 24          	mov    (%rsp),%rdx
    94da:	e9 cd fe ff ff       	jmp    93ac <fwp_drop2+0x2c>
    94df:	90                   	nop
    94e0:	c3                   	ret
    94e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94e8:	48 89 14 24          	mov    %rdx,(%rsp)
    94ec:	e8 1f d2 ff ff       	call   6710 <fwp_rc_free_arr>
    94f1:	48 8b 14 24          	mov    (%rsp),%rdx
    94f5:	eb a9                	jmp    94a0 <fwp_drop2+0x120>
    94f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    94fe:	00 00 
    9500:	66 85 c0             	test   %ax,%ax
    9503:	75 9b                	jne    94a0 <fwp_drop2+0x120>
    9505:	e9 7a ff ff ff       	jmp    9484 <fwp_drop2+0x104>
    950a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9510:	48 89 c8             	mov    %rcx,%rax
    9513:	48 c1 e8 11          	shr    $0x11,%rax
    9517:	48 31 c8             	xor    %rcx,%rax
    951a:	48 89 c2             	mov    %rax,%rdx
    951d:	48 c1 ea 09          	shr    $0x9,%rdx
    9521:	48 31 d0             	xor    %rdx,%rax
    9524:	0f b6 d0             	movzbl %al,%edx
    9527:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    952e:	00 
    952f:	48 85 c0             	test   %rax,%rax
    9532:	75 19                	jne    954d <fwp_drop2+0x1cd>
    9534:	e9 d3 00 00 00       	jmp    960c <fwp_drop2+0x28c>
    9539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9540:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9544:	48 85 c0             	test   %rax,%rax
    9547:	0f 84 bf 00 00 00    	je     960c <fwp_drop2+0x28c>
    954d:	48 89 c2             	mov    %rax,%rdx
    9550:	48 39 08             	cmp    %rcx,(%rax)
    9553:	75 eb                	jne    9540 <fwp_drop2+0x1c0>
    9555:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9559:	48 83 ea 01          	sub    $0x1,%rdx
    955d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9561:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9568:	0f 85 9d fe ff ff    	jne    940b <fwp_drop2+0x8b>
    956e:	48 89 cf             	mov    %rcx,%rdi
    9571:	48 89 0c 24          	mov    %rcx,(%rsp)
    9575:	e8 d6 bf ff ff       	call   5550 <fwp_rc_forget_slot>
    957a:	48 8b 0c 24          	mov    (%rsp),%rcx
    957e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9581:	e9 85 fe ff ff       	jmp    940b <fwp_drop2+0x8b>
    9586:	48 89 ce             	mov    %rcx,%rsi
    9589:	48 c1 ee 11          	shr    $0x11,%rsi
    958d:	48 31 ce             	xor    %rcx,%rsi
    9590:	48 89 f0             	mov    %rsi,%rax
    9593:	48 c1 e8 09          	shr    $0x9,%rax
    9597:	48 31 c6             	xor    %rax,%rsi
    959a:	40 0f b6 f6          	movzbl %sil,%esi
    959e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    95a5:	00 
    95a6:	48 85 c0             	test   %rax,%rax
    95a9:	75 1e                	jne    95c9 <fwp_drop2+0x249>
    95ab:	eb 5f                	jmp    960c <fwp_drop2+0x28c>
    95ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95b4:	00 
    95b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    95bc:	00 00 00 00 
    95c0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    95c4:	48 85 c0             	test   %rax,%rax
    95c7:	74 43                	je     960c <fwp_drop2+0x28c>
    95c9:	48 89 c6             	mov    %rax,%rsi
    95cc:	48 39 08             	cmp    %rcx,(%rax)
    95cf:	75 ef                	jne    95c0 <fwp_drop2+0x240>
    95d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    95d5:	48 83 ee 01          	sub    $0x1,%rsi
    95d9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    95dd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    95e4:	0f 85 b6 fe ff ff    	jne    94a0 <fwp_drop2+0x120>
    95ea:	48 89 cf             	mov    %rcx,%rdi
    95ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    95f2:	48 89 0c 24          	mov    %rcx,(%rsp)
    95f6:	e8 55 bf ff ff       	call   5550 <fwp_rc_forget_slot>
    95fb:	48 8b 0c 24          	mov    (%rsp),%rcx
    95ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9604:	c6 01 fe             	movb   $0xfe,(%rcx)
    9607:	e9 94 fe ff ff       	jmp    94a0 <fwp_drop2+0x120>
    960c:	48 8d 3d 75 32 00 00 	lea    0x3275(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    9613:	e8 d8 ad ff ff       	call   43f0 <fwp_trap>
    9618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    961f:	00 

0000000000009620 <fwp_arg_drop23>:
    9620:	f3 0f 1e fa          	endbr64
    9624:	85 f6                	test   %esi,%esi
    9626:	75 04                	jne    962c <fwp_arg_drop23+0xc>
    9628:	85 d2                	test   %edx,%edx
    962a:	75 04                	jne    9630 <fwp_arg_drop23+0x10>
    962c:	c3                   	ret
    962d:	0f 1f 00             	nopl   (%rax)
    9630:	48 8b 3f             	mov    (%rdi),%rdi
    9633:	e9 48 fd ff ff       	jmp    9380 <fwp_drop2>
    9638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    963f:	00 

0000000000009640 <fwp_caps23>:
    9640:	f3 0f 1e fa          	endbr64
    9644:	48 83 ec 18          	sub    $0x18,%rsp
    9648:	8b 57 04             	mov    0x4(%rdi),%edx
    964b:	48 89 f8             	mov    %rdi,%rax
    964e:	85 d2                	test   %edx,%edx
    9650:	0f 84 9a 00 00 00    	je     96f0 <fwp_caps23+0xb0>
    9656:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    965a:	85 f6                	test   %esi,%esi
    965c:	0f 85 9e 00 00 00    	jne    9700 <fwp_caps23+0xc0>
    9662:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9667:	e8 14 fd ff ff       	call   9380 <fwp_drop2>
    966c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9671:	48 8b 0d 20 85 01 00 	mov    0x18520(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    9678:	48 89 c2             	mov    %rax,%rdx
    967b:	48 2b 15 ee 84 01 00 	sub    0x184ee(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    9682:	48 c1 e1 10          	shl    $0x10,%rcx
    9686:	48 39 ca             	cmp    %rcx,%rdx
    9689:	73 6d                	jae    96f8 <fwp_caps23+0xb8>
    968b:	48 89 d1             	mov    %rdx,%rcx
    968e:	48 c1 e9 10          	shr    $0x10,%rcx
    9692:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9696:	48 8b 0d 1b 85 01 00 	mov    0x1851b(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    969d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    96a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    96a5:	48 85 f6             	test   %rsi,%rsi
    96a8:	74 4e                	je     96f8 <fwp_caps23+0xb8>
    96aa:	0f b6 39             	movzbl (%rcx),%edi
    96ad:	40 80 ff 02          	cmp    $0x2,%dil
    96b1:	0f 84 b9 00 00 00    	je     9770 <fwp_caps23+0x130>
    96b7:	40 80 ff 01          	cmp    $0x1,%dil
    96bb:	75 3b                	jne    96f8 <fwp_caps23+0xb8>
    96bd:	8b 79 18             	mov    0x18(%rcx),%edi
    96c0:	0f b7 d2             	movzwl %dx,%edx
    96c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    96c6:	48 0f af d7          	imul   %rdi,%rdx
    96ca:	48 c1 ea 20          	shr    $0x20,%rdx
    96ce:	48 39 ca             	cmp    %rcx,%rdx
    96d1:	73 25                	jae    96f8 <fwp_caps23+0xb8>
    96d3:	48 01 d6             	add    %rdx,%rsi
    96d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    96d9:	75 1d                	jne    96f8 <fwp_caps23+0xb8>
    96db:	48 89 c7             	mov    %rax,%rdi
    96de:	48 83 c4 18          	add    $0x18,%rsp
    96e2:	e9 a9 c0 ff ff       	jmp    5790 <fwp_mem_free>
    96e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96ee:	00 00 
    96f0:	85 f6                	test   %esi,%esi
    96f2:	0f 84 79 ff ff ff    	je     9671 <fwp_caps23+0x31>
    96f8:	48 83 c4 18          	add    $0x18,%rsp
    96fc:	c3                   	ret
    96fd:	0f 1f 00             	nopl   (%rax)
    9700:	48 8b 05 91 84 01 00 	mov    0x18491(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    9707:	48 2b 3d 62 84 01 00 	sub    0x18462(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    970e:	48 c1 e0 10          	shl    $0x10,%rax
    9712:	48 39 c7             	cmp    %rax,%rdi
    9715:	73 e1                	jae    96f8 <fwp_caps23+0xb8>
    9717:	48 89 f8             	mov    %rdi,%rax
    971a:	48 c1 e8 10          	shr    $0x10,%rax
    971e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9722:	48 8b 05 8f 84 01 00 	mov    0x1848f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    9729:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    972d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9731:	48 85 c0             	test   %rax,%rax
    9734:	74 c2                	je     96f8 <fwp_caps23+0xb8>
    9736:	0f b6 0a             	movzbl (%rdx),%ecx
    9739:	80 f9 02             	cmp    $0x2,%cl
    973c:	74 42                	je     9780 <fwp_caps23+0x140>
    973e:	80 f9 01             	cmp    $0x1,%cl
    9741:	75 b5                	jne    96f8 <fwp_caps23+0xb8>
    9743:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9746:	0f b7 ff             	movzwl %di,%edi
    9749:	8b 52 1c             	mov    0x1c(%rdx),%edx
    974c:	48 0f af f9          	imul   %rcx,%rdi
    9750:	48 c1 ef 20          	shr    $0x20,%rdi
    9754:	48 39 d7             	cmp    %rdx,%rdi
    9757:	73 9f                	jae    96f8 <fwp_caps23+0xb8>
    9759:	48 01 f8             	add    %rdi,%rax
    975c:	0f b6 10             	movzbl (%rax),%edx
    975f:	84 d2                	test   %dl,%dl
    9761:	74 95                	je     96f8 <fwp_caps23+0xb8>
    9763:	80 fa fd             	cmp    $0xfd,%dl
    9766:	77 23                	ja     978b <fwp_caps23+0x14b>
    9768:	83 c2 01             	add    $0x1,%edx
    976b:	88 10                	mov    %dl,(%rax)
    976d:	eb 89                	jmp    96f8 <fwp_caps23+0xb8>
    976f:	90                   	nop
    9770:	66 85 d2             	test   %dx,%dx
    9773:	0f 85 7f ff ff ff    	jne    96f8 <fwp_caps23+0xb8>
    9779:	e9 58 ff ff ff       	jmp    96d6 <fwp_caps23+0x96>
    977e:	66 90                	xchg   %ax,%ax
    9780:	66 85 ff             	test   %di,%di
    9783:	0f 85 6f ff ff ff    	jne    96f8 <fwp_caps23+0xb8>
    9789:	eb d1                	jmp    975c <fwp_caps23+0x11c>
    978b:	48 89 c7             	mov    %rax,%rdi
    978e:	48 83 c4 18          	add    $0x18,%rsp
    9792:	e9 99 bc ff ff       	jmp    5430 <fwp_rc_wide_dup>
    9797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    979e:	00 00 

00000000000097a0 <f23>:
    97a0:	41 57                	push   %r15
    97a2:	41 56                	push   %r14
    97a4:	41 55                	push   %r13
    97a6:	41 54                	push   %r12
    97a8:	55                   	push   %rbp
    97a9:	53                   	push   %rbx
    97aa:	48 83 ec 38          	sub    $0x38,%rsp
    97ae:	48 8b 15 e3 83 01 00 	mov    0x183e3(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    97b5:	48 8b 0d b4 83 01 00 	mov    0x183b4(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    97bc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    97c3:	00 00 
    97c5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    97ca:	49 89 fc             	mov    %rdi,%r12
    97cd:	48 c1 e2 10          	shl    $0x10,%rdx
    97d1:	48 85 ff             	test   %rdi,%rdi
    97d4:	0f 84 bc 02 00 00    	je     9a96 <f23+0x2f6>
    97da:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    97df:	48 89 d8             	mov    %rbx,%rax
    97e2:	48 29 c8             	sub    %rcx,%rax
    97e5:	48 39 d0             	cmp    %rdx,%rax
    97e8:	0f 83 72 03 00 00    	jae    9b60 <f23+0x3c0>
    97ee:	48 89 c2             	mov    %rax,%rdx
    97f1:	48 c1 ea 10          	shr    $0x10,%rdx
    97f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97f9:	48 8b 15 b8 83 01 00 	mov    0x183b8(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9800:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9804:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9808:	48 85 ff             	test   %rdi,%rdi
    980b:	0f 84 4f 03 00 00    	je     9b60 <f23+0x3c0>
    9811:	0f b6 0a             	movzbl (%rdx),%ecx
    9814:	80 f9 02             	cmp    $0x2,%cl
    9817:	0f 84 53 02 00 00    	je     9a70 <f23+0x2d0>
    981d:	80 f9 01             	cmp    $0x1,%cl
    9820:	75 24                	jne    9846 <f23+0xa6>
    9822:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9825:	0f b7 c0             	movzwl %ax,%eax
    9828:	8b 52 1c             	mov    0x1c(%rdx),%edx
    982b:	48 0f af c1          	imul   %rcx,%rax
    982f:	48 c1 e8 20          	shr    $0x20,%rax
    9833:	48 39 d0             	cmp    %rdx,%rax
    9836:	73 0e                	jae    9846 <f23+0xa6>
    9838:	48 01 c7             	add    %rax,%rdi
    983b:	0f b6 07             	movzbl (%rdi),%eax
    983e:	84 c0                	test   %al,%al
    9840:	0f 85 ca 02 00 00    	jne    9b10 <f23+0x370>
    9846:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    984b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    9850:	ba 01 00 00 00       	mov    $0x1,%edx
    9855:	48 85 db             	test   %rbx,%rbx
    9858:	74 13                	je     986d <f23+0xcd>
    985a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9860:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9864:	48 83 c2 01          	add    $0x1,%rdx
    9868:	48 85 db             	test   %rbx,%rbx
    986b:	75 f3                	jne    9860 <f23+0xc0>
    986d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9872:	48 85 c0             	test   %rax,%rax
    9875:	0f 84 15 03 00 00    	je     9b90 <f23+0x3f0>
    987b:	31 db                	xor    %ebx,%ebx
    987d:	0f 1f 00             	nopl   (%rax)
    9880:	48 8b 40 10          	mov    0x10(%rax),%rax
    9884:	48 83 c3 01          	add    $0x1,%rbx
    9888:	48 85 c0             	test   %rax,%rax
    988b:	75 f3                	jne    9880 <f23+0xe0>
    988d:	48 39 d3             	cmp    %rdx,%rbx
    9890:	48 0f 47 da          	cmova  %rdx,%rbx
    9894:	48 89 d8             	mov    %rbx,%rax
    9897:	48 c1 e8 3c          	shr    $0x3c,%rax
    989b:	0f 85 8f 03 00 00    	jne    9c30 <f23+0x490>
    98a1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    98a5:	be 02 00 00 00       	mov    $0x2,%esi
    98aa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    98b1:	00 
    98b2:	e8 d9 c3 ff ff       	call   5c90 <fwp_heap_alloc>
    98b7:	48 89 28             	mov    %rbp,(%rax)
    98ba:	48 8b 15 d7 82 01 00 	mov    0x182d7(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    98c1:	49 89 c6             	mov    %rax,%r14
    98c4:	48 2b 05 a5 82 01 00 	sub    0x182a5(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    98cb:	48 c1 e2 10          	shl    $0x10,%rdx
    98cf:	48 39 d0             	cmp    %rdx,%rax
    98d2:	73 57                	jae    992b <f23+0x18b>
    98d4:	48 89 c2             	mov    %rax,%rdx
    98d7:	48 c1 ea 10          	shr    $0x10,%rdx
    98db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98df:	48 8b 15 d2 82 01 00 	mov    0x182d2(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    98e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98ea:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    98ee:	48 85 ed             	test   %rbp,%rbp
    98f1:	74 38                	je     992b <f23+0x18b>
    98f3:	0f b6 0a             	movzbl (%rdx),%ecx
    98f6:	80 f9 02             	cmp    $0x2,%cl
    98f9:	0f 84 51 02 00 00    	je     9b50 <f23+0x3b0>
    98ff:	80 f9 01             	cmp    $0x1,%cl
    9902:	75 27                	jne    992b <f23+0x18b>
    9904:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9907:	0f b7 c0             	movzwl %ax,%eax
    990a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    990d:	48 0f af c1          	imul   %rcx,%rax
    9911:	48 c1 e8 20          	shr    $0x20,%rax
    9915:	48 39 d0             	cmp    %rdx,%rax
    9918:	73 11                	jae    992b <f23+0x18b>
    991a:	48 01 c5             	add    %rax,%rbp
    991d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9921:	0f 84 d5 02 00 00    	je     9bfc <f23+0x45c>
    9927:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    992b:	48 85 db             	test   %rbx,%rbx
    992e:	74 5d                	je     998d <f23+0x1ed>
    9930:	48 c1 e3 04          	shl    $0x4,%rbx
    9934:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9939:	4c 89 f5             	mov    %r14,%rbp
    993c:	4d 89 e5             	mov    %r12,%r13
    993f:	4c 01 f3             	add    %r14,%rbx
    9942:	0f 1f 00             	nopl   (%rax)
    9945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    994c:	00 00 00 00 
    9950:	49 8b 45 08          	mov    0x8(%r13),%rax
    9954:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9958:	48 83 c5 10          	add    $0x10,%rbp
    995c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9961:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9965:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9969:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    996e:	e8 fd c9 ff ff       	call   6370 <w107>
    9973:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9978:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    997c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9980:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9984:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9988:	48 39 dd             	cmp    %rbx,%rbp
    998b:	75 c3                	jne    9950 <f23+0x1b0>
    998d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9992:	e8 e9 f9 ff ff       	call   9380 <fwp_drop2>
    9997:	4c 89 e7             	mov    %r12,%rdi
    999a:	e8 e1 f9 ff ff       	call   9380 <fwp_drop2>
    999f:	4c 89 f7             	mov    %r14,%rdi
    99a2:	e8 39 cb ff ff       	call   64e0 <w164.constprop.0>
    99a7:	4c 89 f7             	mov    %r14,%rdi
    99aa:	48 89 c3             	mov    %rax,%rbx
    99ad:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    99b3:	e8 38 de ff ff       	call   77f0 <fwp_drop4>
    99b8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    99be:	66 48 0f 6e db       	movq   %rbx,%xmm3
    99c3:	31 ff                	xor    %edi,%edi
    99c5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    99ca:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    99ce:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    99d3:	e8 88 cb ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    99d8:	48 8b 15 b9 81 01 00 	mov    0x181b9(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    99df:	48 89 c5             	mov    %rax,%rbp
    99e2:	48 2b 05 87 81 01 00 	sub    0x18187(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    99e9:	48 c1 e2 10          	shl    $0x10,%rdx
    99ed:	48 39 d0             	cmp    %rdx,%rax
    99f0:	73 55                	jae    9a47 <f23+0x2a7>
    99f2:	48 89 c2             	mov    %rax,%rdx
    99f5:	48 c1 ea 10          	shr    $0x10,%rdx
    99f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99fd:	48 8b 15 b4 81 01 00 	mov    0x181b4(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9a04:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a08:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9a0c:	48 85 db             	test   %rbx,%rbx
    9a0f:	74 36                	je     9a47 <f23+0x2a7>
    9a11:	0f b6 0a             	movzbl (%rdx),%ecx
    9a14:	80 f9 02             	cmp    $0x2,%cl
    9a17:	0f 84 1b 01 00 00    	je     9b38 <f23+0x398>
    9a1d:	80 f9 01             	cmp    $0x1,%cl
    9a20:	75 25                	jne    9a47 <f23+0x2a7>
    9a22:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a25:	0f b7 c0             	movzwl %ax,%eax
    9a28:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a2b:	48 0f af c1          	imul   %rcx,%rax
    9a2f:	48 c1 e8 20          	shr    $0x20,%rax
    9a33:	48 39 d0             	cmp    %rdx,%rax
    9a36:	73 0f                	jae    9a47 <f23+0x2a7>
    9a38:	48 01 c3             	add    %rax,%rbx
    9a3b:	80 3b ff             	cmpb   $0xff,(%rbx)
    9a3e:	0f 84 ab 01 00 00    	je     9bef <f23+0x44f>
    9a44:	c6 03 01             	movb   $0x1,(%rbx)
    9a47:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9a4c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a53:	00 00 
    9a55:	0f 85 d0 01 00 00    	jne    9c2b <f23+0x48b>
    9a5b:	48 83 c4 38          	add    $0x38,%rsp
    9a5f:	48 89 e8             	mov    %rbp,%rax
    9a62:	5b                   	pop    %rbx
    9a63:	5d                   	pop    %rbp
    9a64:	41 5c                	pop    %r12
    9a66:	41 5d                	pop    %r13
    9a68:	41 5e                	pop    %r14
    9a6a:	41 5f                	pop    %r15
    9a6c:	c3                   	ret
    9a6d:	0f 1f 00             	nopl   (%rax)
    9a70:	66 85 c0             	test   %ax,%ax
    9a73:	0f 85 cd fd ff ff    	jne    9846 <f23+0xa6>
    9a79:	0f b6 07             	movzbl (%rdi),%eax
    9a7c:	84 c0                	test   %al,%al
    9a7e:	0f 84 c2 fd ff ff    	je     9846 <f23+0xa6>
    9a84:	3c fd                	cmp    $0xfd,%al
    9a86:	0f 87 95 01 00 00    	ja     9c21 <f23+0x481>
    9a8c:	83 c0 01             	add    $0x1,%eax
    9a8f:	88 07                	mov    %al,(%rdi)
    9a91:	e9 b0 fd ff ff       	jmp    9846 <f23+0xa6>
    9a96:	48 f7 d9             	neg    %rcx
    9a99:	48 39 d1             	cmp    %rdx,%rcx
    9a9c:	0f 83 ee 00 00 00    	jae    9b90 <f23+0x3f0>
    9aa2:	48 89 c8             	mov    %rcx,%rax
    9aa5:	48 c1 e8 10          	shr    $0x10,%rax
    9aa9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9aad:	48 8b 05 04 81 01 00 	mov    0x18104(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    9ab4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9ab8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9abc:	48 85 ff             	test   %rdi,%rdi
    9abf:	0f 84 cb 00 00 00    	je     9b90 <f23+0x3f0>
    9ac5:	0f b6 02             	movzbl (%rdx),%eax
    9ac8:	3c 02                	cmp    $0x2,%al
    9aca:	0f 84 9a 00 00 00    	je     9b6a <f23+0x3ca>
    9ad0:	3c 01                	cmp    $0x1,%al
    9ad2:	0f 85 b8 00 00 00    	jne    9b90 <f23+0x3f0>
    9ad8:	0f b7 c1             	movzwl %cx,%eax
    9adb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ade:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ae1:	48 0f af c1          	imul   %rcx,%rax
    9ae5:	48 c1 e8 20          	shr    $0x20,%rax
    9ae9:	48 39 d0             	cmp    %rdx,%rax
    9aec:	0f 83 9e 00 00 00    	jae    9b90 <f23+0x3f0>
    9af2:	48 01 c7             	add    %rax,%rdi
    9af5:	0f b6 07             	movzbl (%rdi),%eax
    9af8:	84 c0                	test   %al,%al
    9afa:	0f 84 90 00 00 00    	je     9b90 <f23+0x3f0>
    9b00:	31 db                	xor    %ebx,%ebx
    9b02:	0f 1f 00             	nopl   (%rax)
    9b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b0c:	00 00 00 00 
    9b10:	3c fd                	cmp    $0xfd,%al
    9b12:	0f 87 f1 00 00 00    	ja     9c09 <f23+0x469>
    9b18:	83 c0 01             	add    $0x1,%eax
    9b1b:	88 07                	mov    %al,(%rdi)
    9b1d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9b22:	31 d2                	xor    %edx,%edx
    9b24:	4d 85 e4             	test   %r12,%r12
    9b27:	0f 85 1e fd ff ff    	jne    984b <f23+0xab>
    9b2d:	e9 3b fd ff ff       	jmp    986d <f23+0xcd>
    9b32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b38:	66 85 c0             	test   %ax,%ax
    9b3b:	0f 85 06 ff ff ff    	jne    9a47 <f23+0x2a7>
    9b41:	e9 f5 fe ff ff       	jmp    9a3b <f23+0x29b>
    9b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b4d:	00 00 00 
    9b50:	66 85 c0             	test   %ax,%ax
    9b53:	0f 85 d2 fd ff ff    	jne    992b <f23+0x18b>
    9b59:	e9 bf fd ff ff       	jmp    991d <f23+0x17d>
    9b5e:	66 90                	xchg   %ax,%ax
    9b60:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9b65:	e9 e6 fc ff ff       	jmp    9850 <f23+0xb0>
    9b6a:	66 85 c9             	test   %cx,%cx
    9b6d:	75 21                	jne    9b90 <f23+0x3f0>
    9b6f:	0f b6 07             	movzbl (%rdi),%eax
    9b72:	84 c0                	test   %al,%al
    9b74:	74 1a                	je     9b90 <f23+0x3f0>
    9b76:	3c fd                	cmp    $0xfd,%al
    9b78:	0f 87 be 00 00 00    	ja     9c3c <f23+0x49c>
    9b7e:	83 c0 01             	add    $0x1,%eax
    9b81:	88 07                	mov    %al,(%rdi)
    9b83:	66 90                	xchg   %ax,%ax
    9b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b8c:	00 00 00 00 
    9b90:	be 02 00 00 00       	mov    $0x2,%esi
    9b95:	bf 08 00 00 00       	mov    $0x8,%edi
    9b9a:	e8 f1 c0 ff ff       	call   5c90 <fwp_heap_alloc>
    9b9f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9ba6:	48 8b 15 eb 7f 01 00 	mov    0x17feb(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9bad:	49 89 c6             	mov    %rax,%r14
    9bb0:	48 2b 05 b9 7f 01 00 	sub    0x17fb9(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9bb7:	48 c1 e2 10          	shl    $0x10,%rdx
    9bbb:	48 39 d0             	cmp    %rdx,%rax
    9bbe:	73 53                	jae    9c13 <f23+0x473>
    9bc0:	48 89 c2             	mov    %rax,%rdx
    9bc3:	48 c1 ea 10          	shr    $0x10,%rdx
    9bc7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bcb:	48 8b 15 e6 7f 01 00 	mov    0x17fe6(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9bd2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bd6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9bda:	48 85 ed             	test   %rbp,%rbp
    9bdd:	74 34                	je     9c13 <f23+0x473>
    9bdf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9be6:	00 00 
    9be8:	31 db                	xor    %ebx,%ebx
    9bea:	e9 04 fd ff ff       	jmp    98f3 <f23+0x153>
    9bef:	48 89 df             	mov    %rbx,%rdi
    9bf2:	e8 59 b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9bf7:	e9 48 fe ff ff       	jmp    9a44 <f23+0x2a4>
    9bfc:	48 89 ef             	mov    %rbp,%rdi
    9bff:	e8 4c b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9c04:	e9 1e fd ff ff       	jmp    9927 <f23+0x187>
    9c09:	e8 22 b8 ff ff       	call   5430 <fwp_rc_wide_dup>
    9c0e:	e9 0a ff ff ff       	jmp    9b1d <f23+0x37d>
    9c13:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9c1a:	00 00 
    9c1c:	e9 6c fd ff ff       	jmp    998d <f23+0x1ed>
    9c21:	e8 0a b8 ff ff       	call   5430 <fwp_rc_wide_dup>
    9c26:	e9 1b fc ff ff       	jmp    9846 <f23+0xa6>
    9c2b:	e8 30 98 ff ff       	call   3460 <__stack_chk_fail@plt>
    9c30:	48 8d 3d 73 25 00 00 	lea    0x2573(%rip),%rdi        # c1aa <_IO_stdin_used+0x1aa>
    9c37:	e8 b4 a7 ff ff       	call   43f0 <fwp_trap>
    9c3c:	e8 ef b7 ff ff       	call   5430 <fwp_rc_wide_dup>
    9c41:	e9 4a ff ff ff       	jmp    9b90 <f23+0x3f0>
    9c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c4d:	00 00 00 

0000000000009c50 <fwp_owned_entry23>:
    9c50:	f3 0f 1e fa          	endbr64
    9c54:	48 8b 3f             	mov    (%rdi),%rdi
    9c57:	e9 44 fb ff ff       	jmp    97a0 <f23>
    9c5c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009c60 <e23>:
    9c60:	f3 0f 1e fa          	endbr64
    9c64:	53                   	push   %rbx
    9c65:	48 8b 1f             	mov    (%rdi),%rbx
    9c68:	48 89 df             	mov    %rbx,%rdi
    9c6b:	e8 20 ca ff ff       	call   6690 <fwp_rc_share>
    9c70:	48 89 df             	mov    %rbx,%rdi
    9c73:	e8 28 fb ff ff       	call   97a0 <f23>
    9c78:	48 89 c3             	mov    %rax,%rbx
    9c7b:	48 89 c7             	mov    %rax,%rdi
    9c7e:	e8 0d ca ff ff       	call   6690 <fwp_rc_share>
    9c83:	48 89 d8             	mov    %rbx,%rax
    9c86:	5b                   	pop    %rbx
    9c87:	c3                   	ret
    9c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c8f:	00 

0000000000009c90 <fwp_write>:
    9c90:	41 57                	push   %r15
    9c92:	41 56                	push   %r14
    9c94:	41 55                	push   %r13
    9c96:	41 54                	push   %r12
    9c98:	55                   	push   %rbp
    9c99:	53                   	push   %rbx
    9c9a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9ca1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9ca8:	00 00 
    9caa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9cb1:	00 
    9cb2:	49 89 d4             	mov    %rdx,%r12
    9cb5:	8b 12                	mov    (%rdx),%edx
    9cb7:	83 fa 19             	cmp    $0x19,%edx
    9cba:	77 6a                	ja     9d26 <fwp_write+0x96>
    9cbc:	48 89 f5             	mov    %rsi,%rbp
    9cbf:	89 d0                	mov    %edx,%eax
    9cc1:	89 ce                	mov    %ecx,%esi
    9cc3:	48 89 fb             	mov    %rdi,%rbx
    9cc6:	48 8d 0d 33 2e 00 00 	lea    0x2e33(%rip),%rcx        # cb00 <_IO_stdin_used+0xb00>
    9ccd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9cd1:	48 01 c8             	add    %rcx,%rax
    9cd4:	3e ff e0             	notrack jmp *%rax
    9cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cde:	00 00 
    9ce0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9ce4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9ce8:	48 89 ca             	mov    %rcx,%rdx
    9ceb:	48 85 c9             	test   %rcx,%rcx
    9cee:	0f 88 9c 0c 00 00    	js     a990 <fwp_write+0xd00>
    9cf4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9cfb:	00 
    9cfc:	48 89 c6             	mov    %rax,%rsi
    9cff:	4c 89 e7             	mov    %r12,%rdi
    9d02:	e8 39 9d ff ff       	call   3a40 <fwp_fmt_u128>
    9d07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d0e:	00 00 
    9d10:	4c 89 e7             	mov    %r12,%rdi
    9d13:	e8 38 97 ff ff       	call   3450 <strlen@plt>
    9d18:	4c 89 e6             	mov    %r12,%rsi
    9d1b:	48 89 df             	mov    %rbx,%rdi
    9d1e:	48 89 c2             	mov    %rax,%rdx
    9d21:	e8 ea a4 ff ff       	call   4210 <buf_put>
    9d26:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d2d:	00 
    9d2e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d35:	00 00 
    9d37:	0f 85 28 04 00 00    	jne    a165 <fwp_write+0x4d5>
    9d3d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9d44:	5b                   	pop    %rbx
    9d45:	5d                   	pop    %rbp
    9d46:	41 5c                	pop    %r12
    9d48:	41 5d                	pop    %r13
    9d4a:	41 5e                	pop    %r14
    9d4c:	41 5f                	pop    %r15
    9d4e:	c3                   	ret
    9d4f:	90                   	nop
    9d50:	49 89 e9             	mov    %rbp,%r9
    9d53:	4c 8d 05 1b 23 00 00 	lea    0x231b(%rip),%r8        # c075 <_IO_stdin_used+0x75>
    9d5a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9d5f:	ba 02 00 00 00       	mov    $0x2,%edx
    9d64:	be 00 02 00 00       	mov    $0x200,%esi
    9d69:	31 c0                	xor    %eax,%eax
    9d6b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d72:	00 
    9d73:	e8 38 96 ff ff       	call   33b0 <__snprintf_chk@plt>
    9d78:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d7f:	00 
    9d80:	e8 cb 96 ff ff       	call   3450 <strlen@plt>
    9d85:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9d8c:	00 
    9d8d:	48 89 df             	mov    %rbx,%rdi
    9d90:	48 89 c2             	mov    %rax,%rdx
    9d93:	e8 78 a4 ff ff       	call   4210 <buf_put>
    9d98:	eb 8c                	jmp    9d26 <fwp_write+0x96>
    9d9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9da0:	49 89 e9             	mov    %rbp,%r9
    9da3:	4c 8d 05 35 24 00 00 	lea    0x2435(%rip),%r8        # c1df <_IO_stdin_used+0x1df>
    9daa:	eb ae                	jmp    9d5a <fwp_write+0xca>
    9dac:	0f 1f 40 00          	nopl   0x0(%rax)
    9db0:	83 fa 13             	cmp    $0x13,%edx
    9db3:	48 8d 05 1b 24 00 00 	lea    0x241b(%rip),%rax        # c1d5 <_IO_stdin_used+0x1d5>
    9dba:	48 8d 35 19 24 00 00 	lea    0x2419(%rip),%rsi        # c1da <_IO_stdin_used+0x1da>
    9dc1:	ba 04 00 00 00       	mov    $0x4,%edx
    9dc6:	48 0f 44 f0          	cmove  %rax,%rsi
    9dca:	45 31 ed             	xor    %r13d,%r13d
    9dcd:	e8 3e a4 ff ff       	call   4210 <buf_put>
    9dd2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9dd7:	0f 84 a3 08 00 00    	je     a680 <fwp_write+0x9f0>
    9ddd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9de2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9de7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9dec:	48 89 df             	mov    %rbx,%rdi
    9def:	49 0f 44 c5          	cmove  %r13,%rax
    9df3:	31 c9                	xor    %ecx,%ecx
    9df5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9dfa:	e8 91 fe ff ff       	call   9c90 <fwp_write>
    9dff:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9e04:	0f 84 6e 09 00 00    	je     a778 <fwp_write+0xae8>
    9e0a:	49 83 c5 01          	add    $0x1,%r13
    9e0e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9e12:	0f 83 68 08 00 00    	jae    a680 <fwp_write+0x9f0>
    9e18:	ba 02 00 00 00       	mov    $0x2,%edx
    9e1d:	48 8d 35 fb 23 00 00 	lea    0x23fb(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    9e24:	48 89 df             	mov    %rbx,%rdi
    9e27:	e8 e4 a3 ff ff       	call   4210 <buf_put>
    9e2c:	eb af                	jmp    9ddd <fwp_write+0x14d>
    9e2e:	66 90                	xchg   %ax,%ax
    9e30:	ba 06 00 00 00       	mov    $0x6,%edx
    9e35:	48 8d 35 bc 23 00 00 	lea    0x23bc(%rip),%rsi        # c1f8 <_IO_stdin_used+0x1f8>
    9e3c:	48 83 c5 10          	add    $0x10,%rbp
    9e40:	e8 cb a3 ff ff       	call   4210 <buf_put>
    9e45:	48 89 ef             	mov    %rbp,%rdi
    9e48:	e8 03 96 ff ff       	call   3450 <strlen@plt>
    9e4d:	48 89 ee             	mov    %rbp,%rsi
    9e50:	48 89 df             	mov    %rbx,%rdi
    9e53:	48 89 c2             	mov    %rax,%rdx
    9e56:	e8 b5 a3 ff ff       	call   4210 <buf_put>
    9e5b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9e60:	ba 01 00 00 00       	mov    $0x1,%edx
    9e65:	48 89 df             	mov    %rbx,%rdi
    9e68:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e6d:	e8 9e a3 ff ff       	call   4210 <buf_put>
    9e72:	e9 af fe ff ff       	jmp    9d26 <fwp_write+0x96>
    9e77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e7e:	00 00 
    9e80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e87:	00 
    9e88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e8f:	00 00 
    9e91:	0f 85 ce 02 00 00    	jne    a165 <fwp_write+0x4d5>
    9e97:	ba 0a 00 00 00       	mov    $0xa,%edx
    9e9c:	48 8d 35 41 23 00 00 	lea    0x2341(%rip),%rsi        # c1e4 <_IO_stdin_used+0x1e4>
    9ea3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9eaa:	48 89 df             	mov    %rbx,%rdi
    9ead:	5b                   	pop    %rbx
    9eae:	5d                   	pop    %rbp
    9eaf:	41 5c                	pop    %r12
    9eb1:	41 5d                	pop    %r13
    9eb3:	41 5e                	pop    %r14
    9eb5:	41 5f                	pop    %r15
    9eb7:	e9 54 a3 ff ff       	jmp    4210 <buf_put>
    9ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ec0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9ec5:	4d 85 ed             	test   %r13,%r13
    9ec8:	0f 84 02 0c 00 00    	je     aad0 <fwp_write+0xe40>
    9ece:	48 8d 35 57 23 00 00 	lea    0x2357(%rip),%rsi        # c22c <_IO_stdin_used+0x22c>
    9ed5:	4c 89 ef             	mov    %r13,%rdi
    9ed8:	e8 53 96 ff ff       	call   3530 <strcmp@plt>
    9edd:	41 89 c1             	mov    %eax,%r9d
    9ee0:	85 c0                	test   %eax,%eax
    9ee2:	0f 84 6c 0c 00 00    	je     ab54 <fwp_write+0xec4>
    9ee8:	4c 89 ef             	mov    %r13,%rdi
    9eeb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9ef0:	e8 5b 95 ff ff       	call   3450 <strlen@plt>
    9ef5:	4c 89 ee             	mov    %r13,%rsi
    9ef8:	48 89 df             	mov    %rbx,%rdi
    9efb:	48 89 c2             	mov    %rax,%rdx
    9efe:	e8 0d a3 ff ff       	call   4210 <buf_put>
    9f03:	ba 01 00 00 00       	mov    $0x1,%edx
    9f08:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f0d:	48 89 df             	mov    %rbx,%rdi
    9f10:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9f15:	e8 f6 a2 ff ff       	call   4210 <buf_put>
    9f1a:	ba 01 00 00 00       	mov    $0x1,%edx
    9f1f:	4c 89 fe             	mov    %r15,%rsi
    9f22:	48 89 df             	mov    %rbx,%rdi
    9f25:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9f2a:	e8 e1 a2 ff ff       	call   4210 <buf_put>
    9f2f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9f34:	45 31 f6             	xor    %r14d,%r14d
    9f37:	85 d2                	test   %edx,%edx
    9f39:	0f 8e 81 0a 00 00    	jle    a9c0 <fwp_write+0xd30>
    9f3f:	45 31 ed             	xor    %r13d,%r13d
    9f42:	4d 85 ed             	test   %r13,%r13
    9f45:	0f 85 75 07 00 00    	jne    a6c0 <fwp_write+0xa30>
    9f4b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9f52:	00 
    9f53:	45 85 f6             	test   %r14d,%r14d
    9f56:	0f 84 84 07 00 00    	je     a6e0 <fwp_write+0xa50>
    9f5c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9f61:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9f66:	48 89 df             	mov    %rbx,%rdi
    9f69:	49 83 c5 01          	add    $0x1,%r13
    9f6d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9f71:	31 c9                	xor    %ecx,%ecx
    9f73:	e8 18 fd ff ff       	call   9c90 <fwp_write>
    9f78:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9f7d:	7f c3                	jg     9f42 <fwp_write+0x2b2>
    9f7f:	45 85 f6             	test   %r14d,%r14d
    9f82:	0f 84 38 0a 00 00    	je     a9c0 <fwp_write+0xd30>
    9f88:	b8 29 00 00 00       	mov    $0x29,%eax
    9f8d:	ba 01 00 00 00       	mov    $0x1,%edx
    9f92:	4c 89 fe             	mov    %r15,%rsi
    9f95:	48 89 df             	mov    %rbx,%rdi
    9f98:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9f9c:	e8 6f a2 ff ff       	call   4210 <buf_put>
    9fa1:	e9 80 fd ff ff       	jmp    9d26 <fwp_write+0x96>
    9fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9fad:	00 00 00 
    9fb0:	ba 01 00 00 00       	mov    $0x1,%edx
    9fb5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fba:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9fbf:	e8 4c a2 ff ff       	call   4210 <buf_put>
    9fc4:	48 85 ed             	test   %rbp,%rbp
    9fc7:	0f 84 93 06 00 00    	je     a660 <fwp_write+0x9d0>
    9fcd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9fd1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fd6:	31 c9                	xor    %ecx,%ecx
    9fd8:	48 89 df             	mov    %rbx,%rdi
    9fdb:	e8 b0 fc ff ff       	call   9c90 <fwp_write>
    9fe0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9fe4:	48 85 ed             	test   %rbp,%rbp
    9fe7:	0f 84 73 06 00 00    	je     a660 <fwp_write+0x9d0>
    9fed:	ba 02 00 00 00       	mov    $0x2,%edx
    9ff2:	48 8d 35 26 22 00 00 	lea    0x2226(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    9ff9:	48 89 df             	mov    %rbx,%rdi
    9ffc:	e8 0f a2 ff ff       	call   4210 <buf_put>
    a001:	eb ca                	jmp    9fcd <fwp_write+0x33d>
    a003:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a008:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a00c:	85 f6                	test   %esi,%esi
    a00e:	0f 84 fc 07 00 00    	je     a810 <fwp_write+0xb80>
    a014:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a01b:	00 
    a01c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a023:	00 00 
    a025:	0f 85 3a 01 00 00    	jne    a165 <fwp_write+0x4d5>
    a02b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a02f:	4c 89 ea             	mov    %r13,%rdx
    a032:	e9 6c fe ff ff       	jmp    9ea3 <fwp_write+0x213>
    a037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a03e:	00 00 
    a040:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a045:	ba 01 00 00 00       	mov    $0x1,%edx
    a04a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a04f:	48 89 ee             	mov    %rbp,%rsi
    a052:	e8 b9 a1 ff ff       	call   4210 <buf_put>
    a057:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a05c:	4c 89 e7             	mov    %r12,%rdi
    a05f:	e8 ec 93 ff ff       	call   3450 <strlen@plt>
    a064:	4c 89 e6             	mov    %r12,%rsi
    a067:	48 89 df             	mov    %rbx,%rdi
    a06a:	48 89 c2             	mov    %rax,%rdx
    a06d:	e8 9e a1 ff ff       	call   4210 <buf_put>
    a072:	ba 01 00 00 00       	mov    $0x1,%edx
    a077:	48 89 ee             	mov    %rbp,%rsi
    a07a:	48 89 df             	mov    %rbx,%rdi
    a07d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a082:	e8 89 a1 ff ff       	call   4210 <buf_put>
    a087:	e9 9a fc ff ff       	jmp    9d26 <fwp_write+0x96>
    a08c:	0f 1f 40 00          	nopl   0x0(%rax)
    a090:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a095:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a099:	0f 8a 8e 0b 00 00    	jp     ac2d <fwp_write+0xf9d>
    a09f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0a3:	66 0f 54 05 55 2b 00 	andpd  0x2b55(%rip),%xmm0        # cc00 <msg.4+0x90>
    a0aa:	00 
    a0ab:	bd 01 00 00 00       	mov    $0x1,%ebp
    a0b0:	66 0f 2e 05 88 2b 00 	ucomisd 0x2b88(%rip),%xmm0        # cc40 <msg.4+0xd0>
    a0b7:	00 
    a0b8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a0bf:	00 
    a0c0:	0f 87 b2 09 00 00    	ja     aa78 <fwp_write+0xde8>
    a0c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0cd:	00 00 00 
    a0d0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0d4:	89 ee                	mov    %ebp,%esi
    a0d6:	4c 89 e7             	mov    %r12,%rdi
    a0d9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a0de:	e8 2d a6 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a0e3:	31 f6                	xor    %esi,%esi
    a0e5:	4c 89 e7             	mov    %r12,%rdi
    a0e8:	e8 23 93 ff ff       	call   3410 <strtod@plt>
    a0ed:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a0f2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a0f6:	7a 06                	jp     a0fe <fwp_write+0x46e>
    a0f8:	0f 84 e9 01 00 00    	je     a2e7 <fwp_write+0x657>
    a0fe:	83 c5 01             	add    $0x1,%ebp
    a101:	83 fd 12             	cmp    $0x12,%ebp
    a104:	75 ca                	jne    a0d0 <fwp_write+0x440>
    a106:	be 11 00 00 00       	mov    $0x11,%esi
    a10b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a10f:	4c 89 e7             	mov    %r12,%rdi
    a112:	e8 f9 a5 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a117:	e9 cb 01 00 00       	jmp    a2e7 <fwp_write+0x657>
    a11c:	0f 1f 40 00          	nopl   0x0(%rax)
    a120:	48 83 fd 01          	cmp    $0x1,%rbp
    a124:	0f 84 e6 08 00 00    	je     aa10 <fwp_write+0xd80>
    a12a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a12e:	b8 02 00 00 00       	mov    $0x2,%eax
    a133:	ba 01 00 00 00       	mov    $0x1,%edx
    a138:	48 0f 44 d0          	cmove  %rax,%rdx
    a13c:	48 8d 35 8a 20 00 00 	lea    0x208a(%rip),%rsi        # c1cd <_IO_stdin_used+0x1cd>
    a143:	48 8d 05 88 20 00 00 	lea    0x2088(%rip),%rax        # c1d2 <_IO_stdin_used+0x1d2>
    a14a:	48 0f 44 f0          	cmove  %rax,%rsi
    a14e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a155:	00 
    a156:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a15d:	00 00 
    a15f:	0f 84 3e fd ff ff    	je     9ea3 <fwp_write+0x213>
    a165:	e8 f6 92 ff ff       	call   3460 <__stack_chk_fail@plt>
    a16a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a170:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a175:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a17a:	e8 d1 9f ff ff       	call   4150 <buf_grow>
    a17f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a183:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a189:	4c 03 0b             	add    (%rbx),%r9
    a18c:	66 45 89 11          	mov    %r10w,(%r9)
    a190:	45 85 e4             	test   %r12d,%r12d
    a193:	0f 8e 07 05 00 00    	jle    a6a0 <fwp_write+0xa10>
    a199:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a1a0:	55 55 55 
    a1a3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a1a8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a1af:	aa aa aa 
    a1b2:	49 83 c1 01          	add    $0x1,%r9
    a1b6:	eb 45                	jmp    a1fd <fwp_write+0x56d>
    a1b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1bf:	00 
    a1c0:	be 01 00 00 00       	mov    $0x1,%esi
    a1c5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a1ca:	88 07                	mov    %al,(%rdi)
    a1cc:	48 89 e8             	mov    %rbp,%rax
    a1cf:	49 f7 e8             	imul   %r8
    a1d2:	48 89 e8             	mov    %rbp,%rax
    a1d5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a1d9:	48 29 c2             	sub    %rax,%rdx
    a1dc:	48 85 c9             	test   %rcx,%rcx
    a1df:	0f 95 c0             	setne  %al
    a1e2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a1e6:	48 83 ef 01          	sub    $0x1,%rdi
    a1ea:	48 21 c5             	and    %rax,%rbp
    a1ed:	48 29 ea             	sub    %rbp,%rdx
    a1f0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a1f4:	49 39 f9             	cmp    %rdi,%r9
    a1f7:	0f 84 a3 04 00 00    	je     a6a0 <fwp_write+0xa10>
    a1fd:	48 89 e8             	mov    %rbp,%rax
    a200:	49 f7 e8             	imul   %r8
    a203:	48 89 e8             	mov    %rbp,%rax
    a206:	48 c1 f8 3f          	sar    $0x3f,%rax
    a20a:	48 89 d1             	mov    %rdx,%rcx
    a20d:	48 29 c1             	sub    %rax,%rcx
    a210:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a214:	48 89 e9             	mov    %rbp,%rcx
    a217:	48 29 c1             	sub    %rax,%rcx
    a21a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a21e:	49 f7 e2             	mul    %r10
    a221:	b8 30 00 00 00       	mov    $0x30,%eax
    a226:	48 89 d6             	mov    %rdx,%rsi
    a229:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a22d:	48 d1 ee             	shr    $1,%rsi
    a230:	48 01 f2             	add    %rsi,%rdx
    a233:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a237:	48 29 d6             	sub    %rdx,%rsi
    a23a:	74 8e                	je     a1ca <fwp_write+0x53a>
    a23c:	48 83 fe 01          	cmp    $0x1,%rsi
    a240:	0f 85 7a ff ff ff    	jne    a1c0 <fwp_write+0x530>
    a246:	31 f6                	xor    %esi,%esi
    a248:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a24d:	e9 78 ff ff ff       	jmp    a1ca <fwp_write+0x53a>
    a252:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a258:	66 0f 6e cd          	movd   %ebp,%xmm1
    a25c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a25f:	0f 8a c8 09 00 00    	jp     ac2d <fwp_write+0xf9d>
    a265:	0f 28 c1             	movaps %xmm1,%xmm0
    a268:	0f 54 05 81 29 00 00 	andps  0x2981(%rip),%xmm0        # cbf0 <msg.4+0x80>
    a26f:	0f 2e 05 8e 1d 00 00 	ucomiss 0x1d8e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a276:	0f 87 24 08 00 00    	ja     aaa0 <fwp_write+0xe10>
    a27c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a280:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a286:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a28d:	00 
    a28e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a292:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a29e:	00 00 
    a2a0:	44 89 ee             	mov    %r13d,%esi
    a2a3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2a8:	4c 89 e7             	mov    %r12,%rdi
    a2ab:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a2b0:	e8 5b a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a2b5:	31 f6                	xor    %esi,%esi
    a2b7:	4c 89 e7             	mov    %r12,%rdi
    a2ba:	e8 f1 91 ff ff       	call   34b0 <strtof@plt>
    a2bf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a2c4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a2c7:	7a 02                	jp     a2cb <fwp_write+0x63b>
    a2c9:	74 1c                	je     a2e7 <fwp_write+0x657>
    a2cb:	41 83 c5 01          	add    $0x1,%r13d
    a2cf:	41 83 fd 0a          	cmp    $0xa,%r13d
    a2d3:	75 cb                	jne    a2a0 <fwp_write+0x610>
    a2d5:	be 09 00 00 00       	mov    $0x9,%esi
    a2da:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2df:	4c 89 e7             	mov    %r12,%rdi
    a2e2:	e8 29 a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a2e7:	4c 89 e7             	mov    %r12,%rdi
    a2ea:	e8 91 a0 ff ff       	call   4380 <fwp_finish_float>
    a2ef:	e9 1c fa ff ff       	jmp    9d10 <fwp_write+0x80>
    a2f4:	0f 1f 40 00          	nopl   0x0(%rax)
    a2f8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a2fc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a300:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a307:	00 
    a308:	48 89 ef             	mov    %rbp,%rdi
    a30b:	e8 30 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a310:	48 89 ef             	mov    %rbp,%rdi
    a313:	e8 38 91 ff ff       	call   3450 <strlen@plt>
    a318:	48 89 ee             	mov    %rbp,%rsi
    a31b:	48 89 df             	mov    %rbx,%rdi
    a31e:	48 89 c2             	mov    %rax,%rdx
    a321:	e8 ea 9e ff ff       	call   4210 <buf_put>
    a326:	e9 fb f9 ff ff       	jmp    9d26 <fwp_write+0x96>
    a32b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a330:	ba 06 00 00 00       	mov    $0x6,%edx
    a335:	48 8d 35 e6 1e 00 00 	lea    0x1ee6(%rip),%rsi        # c222 <_IO_stdin_used+0x222>
    a33c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a342:	e8 c9 9e ff ff       	call   4210 <buf_put>
    a347:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a34e:	ff ff 7f 
    a351:	48 23 55 00          	and    0x0(%rbp),%rdx
    a355:	0f 84 86 02 00 00    	je     a5e1 <fwp_write+0x951>
    a35b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a360:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a364:	48 85 d2             	test   %rdx,%rdx
    a367:	0f 84 ae 00 00 00    	je     a41b <fwp_write+0x78b>
    a36d:	8b 0a                	mov    (%rdx),%ecx
    a36f:	83 f9 1c             	cmp    $0x1c,%ecx
    a372:	0f 84 58 06 00 00    	je     a9d0 <fwp_write+0xd40>
    a378:	83 f9 1b             	cmp    $0x1b,%ecx
    a37b:	0f 87 9a 00 00 00    	ja     a41b <fwp_write+0x78b>
    a381:	be 01 00 00 00       	mov    $0x1,%esi
    a386:	48 d3 e6             	shl    %cl,%rsi
    a389:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a38f:	0f 85 4b 04 00 00    	jne    a7e0 <fwp_write+0xb50>
    a395:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a39b:	0f 85 0f 04 00 00    	jne    a7b0 <fwp_write+0xb20>
    a3a1:	83 e6 21             	and    $0x21,%esi
    a3a4:	74 75                	je     a41b <fwp_write+0x78b>
    a3a6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a3ab:	48 85 ff             	test   %rdi,%rdi
    a3ae:	79 07                	jns    a3b7 <fwp_write+0x727>
    a3b0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a3b4:	4c 01 ee             	add    %r13,%rsi
    a3b7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a3bb:	85 c9                	test   %ecx,%ecx
    a3bd:	40 0f b6 f7          	movzbl %dil,%esi
    a3c1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a3c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3cc:	00 00 00 00 
    a3d0:	31 c9                	xor    %ecx,%ecx
    a3d2:	48 89 df             	mov    %rbx,%rdi
    a3d5:	49 83 c5 01          	add    $0x1,%r13
    a3d9:	e8 b2 f8 ff ff       	call   9c90 <fwp_write>
    a3de:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a3e5:	ff ff 7f 
    a3e8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a3ec:	49 39 d5             	cmp    %rdx,%r13
    a3ef:	0f 83 ec 01 00 00    	jae    a5e1 <fwp_write+0x951>
    a3f5:	ba 02 00 00 00       	mov    $0x2,%edx
    a3fa:	48 89 df             	mov    %rbx,%rdi
    a3fd:	48 8d 35 1b 1e 00 00 	lea    0x1e1b(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    a404:	e8 07 9e ff ff       	call   4210 <buf_put>
    a409:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a40e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a412:	48 85 d2             	test   %rdx,%rdx
    a415:	0f 85 52 ff ff ff    	jne    a36d <fwp_write+0x6dd>
    a41b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a420:	48 85 ff             	test   %rdi,%rdi
    a423:	0f 88 cf 05 00 00    	js     a9f8 <fwp_write+0xd68>
    a429:	48 8b 31             	mov    (%rcx),%rsi
    a42c:	eb a2                	jmp    a3d0 <fwp_write+0x740>
    a42e:	66 90                	xchg   %ax,%ax
    a430:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a437:	00 
    a438:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a43f:	00 00 
    a441:	0f 85 1e fd ff ff    	jne    a165 <fwp_write+0x4d5>
    a447:	ba 08 00 00 00       	mov    $0x8,%edx
    a44c:	48 8d 35 9c 1d 00 00 	lea    0x1d9c(%rip),%rsi        # c1ef <_IO_stdin_used+0x1ef>
    a453:	e9 4b fa ff ff       	jmp    9ea3 <fwp_write+0x213>
    a458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a45f:	00 
    a460:	89 e8                	mov    %ebp,%eax
    a462:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a469:	76 03                	jbe    a46e <fwp_write+0x7de>
    a46b:	8b 45 00             	mov    0x0(%rbp),%eax
    a46e:	41 89 c6             	mov    %eax,%r14d
    a471:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a476:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a47b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a47f:	4c 89 ef             	mov    %r13,%rdi
    a482:	e8 c9 8f ff ff       	call   3450 <strlen@plt>
    a487:	4c 89 ee             	mov    %r13,%rsi
    a48a:	48 89 df             	mov    %rbx,%rdi
    a48d:	48 89 c2             	mov    %rax,%rdx
    a490:	e8 7b 9d ff ff       	call   4210 <buf_put>
    a495:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a49a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a49e:	85 f6                	test   %esi,%esi
    a4a0:	0f 8e 80 f8 ff ff    	jle    9d26 <fwp_write+0x96>
    a4a6:	45 31 ed             	xor    %r13d,%r13d
    a4a9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a4ae:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a4b3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a4b8:	ba 01 00 00 00       	mov    $0x1,%edx
    a4bd:	4c 89 fe             	mov    %r15,%rsi
    a4c0:	48 89 04 24          	mov    %rax,(%rsp)
    a4c4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a4c9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a4cd:	48 89 df             	mov    %rbx,%rdi
    a4d0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a4d4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a4d9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a4de:	e8 2d 9d ff ff       	call   4210 <buf_put>
    a4e3:	41 8b 06             	mov    (%r14),%eax
    a4e6:	83 f8 0e             	cmp    $0xe,%eax
    a4e9:	0f 84 71 02 00 00    	je     a760 <fwp_write+0xad0>
    a4ef:	83 f8 10             	cmp    $0x10,%eax
    a4f2:	0f 84 38 02 00 00    	je     a730 <fwp_write+0xaa0>
    a4f8:	83 f8 0a             	cmp    $0xa,%eax
    a4fb:	0f 84 7f 04 00 00    	je     a980 <fwp_write+0xcf0>
    a501:	0f 8f f9 00 00 00    	jg     a600 <fwp_write+0x970>
    a507:	83 f8 03             	cmp    $0x3,%eax
    a50a:	0f 8f 50 04 00 00    	jg     a960 <fwp_write+0xcd0>
    a510:	85 c0                	test   %eax,%eax
    a512:	78 10                	js     a524 <fwp_write+0x894>
    a514:	48 8b 04 24          	mov    (%rsp),%rax
    a518:	48 c1 e8 3f          	shr    $0x3f,%rax
    a51c:	85 c0                	test   %eax,%eax
    a51e:	0f 85 f9 00 00 00    	jne    a61d <fwp_write+0x98d>
    a524:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a529:	48 8b 34 24          	mov    (%rsp),%rsi
    a52d:	31 c9                	xor    %ecx,%ecx
    a52f:	48 89 df             	mov    %rbx,%rdi
    a532:	e8 59 f7 ff ff       	call   9c90 <fwp_write>
    a537:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a53c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a541:	49 83 c5 01          	add    $0x1,%r13
    a545:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a549:	0f 8f 5f ff ff ff    	jg     a4ae <fwp_write+0x81e>
    a54f:	e9 d2 f7 ff ff       	jmp    9d26 <fwp_write+0x96>
    a554:	0f 1f 40 00          	nopl   0x0(%rax)
    a558:	ba 06 00 00 00       	mov    $0x6,%edx
    a55d:	48 8d 35 b1 1c 00 00 	lea    0x1cb1(%rip),%rsi        # c215 <_IO_stdin_used+0x215>
    a564:	45 31 ed             	xor    %r13d,%r13d
    a567:	e8 a4 9c ff ff       	call   4210 <buf_put>
    a56c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a571:	75 19                	jne    a58c <fwp_write+0x8fc>
    a573:	eb 6c                	jmp    a5e1 <fwp_write+0x951>
    a575:	0f 1f 00             	nopl   (%rax)
    a578:	ba 02 00 00 00       	mov    $0x2,%edx
    a57d:	48 8d 35 9b 1c 00 00 	lea    0x1c9b(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    a584:	48 89 df             	mov    %rbx,%rdi
    a587:	e8 84 9c ff ff       	call   4210 <buf_put>
    a58c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a592:	b9 00 02 00 00       	mov    $0x200,%ecx
    a597:	31 c0                	xor    %eax,%eax
    a599:	49 83 c5 01          	add    $0x1,%r13
    a59d:	4c 8d 05 78 1c 00 00 	lea    0x1c78(%rip),%r8        # c21c <_IO_stdin_used+0x21c>
    a5a4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5a9:	be 00 02 00 00       	mov    $0x200,%esi
    a5ae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5b5:	00 
    a5b6:	e8 f5 8d ff ff       	call   33b0 <__snprintf_chk@plt>
    a5bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5c2:	00 
    a5c3:	e8 88 8e ff ff       	call   3450 <strlen@plt>
    a5c8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a5cf:	00 
    a5d0:	48 89 df             	mov    %rbx,%rdi
    a5d3:	48 89 c2             	mov    %rax,%rdx
    a5d6:	e8 35 9c ff ff       	call   4210 <buf_put>
    a5db:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a5df:	72 97                	jb     a578 <fwp_write+0x8e8>
    a5e1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5e6:	ba 01 00 00 00       	mov    $0x1,%edx
    a5eb:	48 89 df             	mov    %rbx,%rdi
    a5ee:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a5f3:	e8 18 9c ff ff       	call   4210 <buf_put>
    a5f8:	e9 29 f7 ff ff       	jmp    9d26 <fwp_write+0x96>
    a5fd:	0f 1f 00             	nopl   (%rax)
    a600:	83 f8 0b             	cmp    $0xb,%eax
    a603:	0f 85 1b ff ff ff    	jne    a524 <fwp_write+0x894>
    a609:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a60e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a612:	83 e0 01             	and    $0x1,%eax
    a615:	85 c0                	test   %eax,%eax
    a617:	0f 84 07 ff ff ff    	je     a524 <fwp_write+0x894>
    a61d:	4c 89 fe             	mov    %r15,%rsi
    a620:	48 89 df             	mov    %rbx,%rdi
    a623:	ba 01 00 00 00       	mov    $0x1,%edx
    a628:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a62d:	e8 de 9b ff ff       	call   4210 <buf_put>
    a632:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a637:	48 8b 34 24          	mov    (%rsp),%rsi
    a63b:	31 c9                	xor    %ecx,%ecx
    a63d:	48 89 df             	mov    %rbx,%rdi
    a640:	e8 4b f6 ff ff       	call   9c90 <fwp_write>
    a645:	ba 01 00 00 00       	mov    $0x1,%edx
    a64a:	4c 89 fe             	mov    %r15,%rsi
    a64d:	48 89 df             	mov    %rbx,%rdi
    a650:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a655:	e8 b6 9b ff ff       	call   4210 <buf_put>
    a65a:	e9 d8 fe ff ff       	jmp    a537 <fwp_write+0x8a7>
    a65f:	90                   	nop
    a660:	ba 01 00 00 00       	mov    $0x1,%edx
    a665:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a66a:	48 89 df             	mov    %rbx,%rdi
    a66d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a672:	e8 99 9b ff ff       	call   4210 <buf_put>
    a677:	e9 aa f6 ff ff       	jmp    9d26 <fwp_write+0x96>
    a67c:	0f 1f 40 00          	nopl   0x0(%rax)
    a680:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a685:	ba 01 00 00 00       	mov    $0x1,%edx
    a68a:	48 89 df             	mov    %rbx,%rdi
    a68d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a692:	e8 79 9b ff ff       	call   4210 <buf_put>
    a697:	e9 8a f6 ff ff       	jmp    9d26 <fwp_write+0x96>
    a69c:	0f 1f 40 00          	nopl   0x0(%rax)
    a6a0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a6a4:	48 8b 13             	mov    (%rbx),%rdx
    a6a7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a6ac:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a6b0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a6b4:	e9 6d f6 ff ff       	jmp    9d26 <fwp_write+0x96>
    a6b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6c5:	48 8d 35 53 1b 00 00 	lea    0x1b53(%rip),%rsi        # c21f <_IO_stdin_used+0x21f>
    a6cc:	48 89 df             	mov    %rbx,%rdi
    a6cf:	e8 3c 9b ff ff       	call   4210 <buf_put>
    a6d4:	e9 72 f8 ff ff       	jmp    9f4b <fwp_write+0x2bb>
    a6d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6e0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a6e5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a6ea:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a6ee:	48 89 f7             	mov    %rsi,%rdi
    a6f1:	48 89 34 24          	mov    %rsi,(%rsp)
    a6f5:	e8 56 8d ff ff       	call   3450 <strlen@plt>
    a6fa:	48 8b 34 24          	mov    (%rsp),%rsi
    a6fe:	48 89 df             	mov    %rbx,%rdi
    a701:	48 89 c2             	mov    %rax,%rdx
    a704:	e8 07 9b ff ff       	call   4210 <buf_put>
    a709:	ba 03 00 00 00       	mov    $0x3,%edx
    a70e:	48 8d 35 2d 1b 00 00 	lea    0x1b2d(%rip),%rsi        # c242 <_IO_stdin_used+0x242>
    a715:	48 89 df             	mov    %rbx,%rdi
    a718:	e8 f3 9a ff ff       	call   4210 <buf_put>
    a71d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a722:	e9 35 f8 ff ff       	jmp    9f5c <fwp_write+0x2cc>
    a727:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a72e:	00 00 
    a730:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a735:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a739:	48 85 ff             	test   %rdi,%rdi
    a73c:	0f 84 e2 fd ff ff    	je     a524 <fwp_write+0x894>
    a742:	48 8d 35 e3 1a 00 00 	lea    0x1ae3(%rip),%rsi        # c22c <_IO_stdin_used+0x22c>
    a749:	e8 e2 8d ff ff       	call   3530 <strcmp@plt>
    a74e:	85 c0                	test   %eax,%eax
    a750:	0f 95 c0             	setne  %al
    a753:	0f b6 c0             	movzbl %al,%eax
    a756:	e9 c1 fd ff ff       	jmp    a51c <fwp_write+0x88c>
    a75b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a760:	31 c0                	xor    %eax,%eax
    a762:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a769:	00 
    a76a:	0f 97 c0             	seta   %al
    a76d:	e9 aa fd ff ff       	jmp    a51c <fwp_write+0x88c>
    a772:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a778:	48 89 df             	mov    %rbx,%rdi
    a77b:	ba 02 00 00 00       	mov    $0x2,%edx
    a780:	48 8d 35 a2 1a 00 00 	lea    0x1aa2(%rip),%rsi        # c229 <_IO_stdin_used+0x229>
    a787:	e8 84 9a ff ff       	call   4210 <buf_put>
    a78c:	4c 89 e8             	mov    %r13,%rax
    a78f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a794:	31 c9                	xor    %ecx,%ecx
    a796:	48 c1 e0 04          	shl    $0x4,%rax
    a79a:	48 89 df             	mov    %rbx,%rdi
    a79d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a7a2:	e8 e9 f4 ff ff       	call   9c90 <fwp_write>
    a7a7:	e9 5e f6 ff ff       	jmp    9e0a <fwp_write+0x17a>
    a7ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a7b0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a7b5:	48 85 ff             	test   %rdi,%rdi
    a7b8:	79 0c                	jns    a7c6 <fwp_write+0xb36>
    a7ba:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a7c1:	00 
    a7c2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a7c6:	48 63 3e             	movslq (%rsi),%rdi
    a7c9:	83 f9 02             	cmp    $0x2,%ecx
    a7cc:	89 fe                	mov    %edi,%esi
    a7ce:	48 0f 44 f7          	cmove  %rdi,%rsi
    a7d2:	e9 f9 fb ff ff       	jmp    a3d0 <fwp_write+0x740>
    a7d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7de:	00 00 
    a7e0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a7e5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a7ea:	48 85 ff             	test   %rdi,%rdi
    a7ed:	0f 88 0f 03 00 00    	js     ab02 <fwp_write+0xe72>
    a7f3:	49 0f bf 38          	movswq (%r8),%rdi
    a7f7:	83 f9 01             	cmp    $0x1,%ecx
    a7fa:	0f b7 f7             	movzwl %di,%esi
    a7fd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a801:	e9 ca fb ff ff       	jmp    a3d0 <fwp_write+0x740>
    a806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a80d:	00 00 00 
    a810:	ba 01 00 00 00       	mov    $0x1,%edx
    a815:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a81a:	48 83 c5 08          	add    $0x8,%rbp
    a81e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a823:	e8 e8 99 ff ff       	call   4210 <buf_put>
    a828:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a82d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a832:	4d 85 ed             	test   %r13,%r13
    a835:	75 46                	jne    a87d <fwp_write+0xbed>
    a837:	e9 04 01 00 00       	jmp    a940 <fwp_write+0xcb0>
    a83c:	0f 1f 40 00          	nopl   0x0(%rax)
    a840:	41 80 f9 09          	cmp    $0x9,%r9b
    a844:	0f 84 d6 00 00 00    	je     a920 <fwp_write+0xc90>
    a84a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a84e:	0f 85 9c 00 00 00    	jne    a8f0 <fwp_write+0xc60>
    a854:	ba 02 00 00 00       	mov    $0x2,%edx
    a859:	48 8d 35 a5 19 00 00 	lea    0x19a5(%rip),%rsi        # c205 <_IO_stdin_used+0x205>
    a860:	48 89 df             	mov    %rbx,%rdi
    a863:	e8 a8 99 ff ff       	call   4210 <buf_put>
    a868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a86f:	00 
    a870:	48 83 c5 01          	add    $0x1,%rbp
    a874:	49 39 ec             	cmp    %rbp,%r12
    a877:	0f 84 c3 00 00 00    	je     a940 <fwp_write+0xcb0>
    a87d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a882:	41 80 f9 0d          	cmp    $0xd,%r9b
    a886:	74 28                	je     a8b0 <fwp_write+0xc20>
    a888:	7e b6                	jle    a840 <fwp_write+0xbb0>
    a88a:	41 80 f9 22          	cmp    $0x22,%r9b
    a88e:	74 40                	je     a8d0 <fwp_write+0xc40>
    a890:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a894:	75 5a                	jne    a8f0 <fwp_write+0xc60>
    a896:	ba 02 00 00 00       	mov    $0x2,%edx
    a89b:	48 8d 35 60 19 00 00 	lea    0x1960(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    a8a2:	48 89 df             	mov    %rbx,%rdi
    a8a5:	e8 66 99 ff ff       	call   4210 <buf_put>
    a8aa:	eb c4                	jmp    a870 <fwp_write+0xbe0>
    a8ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a8b0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8b5:	48 8d 35 4f 19 00 00 	lea    0x194f(%rip),%rsi        # c20b <_IO_stdin_used+0x20b>
    a8bc:	48 89 df             	mov    %rbx,%rdi
    a8bf:	e8 4c 99 ff ff       	call   4210 <buf_put>
    a8c4:	eb aa                	jmp    a870 <fwp_write+0xbe0>
    a8c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8cd:	00 00 00 
    a8d0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8d5:	48 8d 35 23 19 00 00 	lea    0x1923(%rip),%rsi        # c1ff <_IO_stdin_used+0x1ff>
    a8dc:	48 89 df             	mov    %rbx,%rdi
    a8df:	e8 2c 99 ff ff       	call   4210 <buf_put>
    a8e4:	eb 8a                	jmp    a870 <fwp_write+0xbe0>
    a8e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8ed:	00 00 00 
    a8f0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a8f4:	0f 86 2e 01 00 00    	jbe    aa28 <fwp_write+0xd98>
    a8fa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a8fe:	0f 84 24 01 00 00    	je     aa28 <fwp_write+0xd98>
    a904:	ba 01 00 00 00       	mov    $0x1,%edx
    a909:	4c 89 fe             	mov    %r15,%rsi
    a90c:	48 89 df             	mov    %rbx,%rdi
    a90f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a914:	e8 f7 98 ff ff       	call   4210 <buf_put>
    a919:	e9 52 ff ff ff       	jmp    a870 <fwp_write+0xbe0>
    a91e:	66 90                	xchg   %ax,%ax
    a920:	ba 02 00 00 00       	mov    $0x2,%edx
    a925:	48 8d 35 dc 18 00 00 	lea    0x18dc(%rip),%rsi        # c208 <_IO_stdin_used+0x208>
    a92c:	48 89 df             	mov    %rbx,%rdi
    a92f:	e8 dc 98 ff ff       	call   4210 <buf_put>
    a934:	e9 37 ff ff ff       	jmp    a870 <fwp_write+0xbe0>
    a939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a940:	ba 01 00 00 00       	mov    $0x1,%edx
    a945:	4c 89 fe             	mov    %r15,%rsi
    a948:	48 89 df             	mov    %rbx,%rdi
    a94b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a950:	e8 bb 98 ff ff       	call   4210 <buf_put>
    a955:	e9 cc f3 ff ff       	jmp    9d26 <fwp_write+0x96>
    a95a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a960:	83 f8 04             	cmp    $0x4,%eax
    a963:	0f 85 bb fb ff ff    	jne    a524 <fwp_write+0x894>
    a969:	48 8b 04 24          	mov    (%rsp),%rax
    a96d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a971:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a976:	48 c1 e8 3f          	shr    $0x3f,%rax
    a97a:	e9 96 fc ff ff       	jmp    a615 <fwp_write+0x985>
    a97f:	90                   	nop
    a980:	8b 0c 24             	mov    (%rsp),%ecx
    a983:	31 c0                	xor    %eax,%eax
    a985:	85 c9                	test   %ecx,%ecx
    a987:	0f 98 c0             	sets   %al
    a98a:	e9 86 fc ff ff       	jmp    a615 <fwp_write+0x985>
    a98f:	90                   	nop
    a990:	48 f7 d8             	neg    %rax
    a993:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a99a:	00 
    a99b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a9a2:	2d 
    a9a3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9aa:	00 
    a9ab:	48 83 d2 00          	adc    $0x0,%rdx
    a9af:	48 89 c6             	mov    %rax,%rsi
    a9b2:	48 f7 da             	neg    %rdx
    a9b5:	e8 86 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9ba:	e9 51 f3 ff ff       	jmp    9d10 <fwp_write+0x80>
    a9bf:	90                   	nop
    a9c0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a9c5:	e9 c3 f5 ff ff       	jmp    9f8d <fwp_write+0x2fd>
    a9ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9d0:	4c 89 e9             	mov    %r13,%rcx
    a9d3:	48 c1 e1 04          	shl    $0x4,%rcx
    a9d7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a9dc:	48 85 ff             	test   %rdi,%rdi
    a9df:	0f 89 eb f9 ff ff    	jns    a3d0 <fwp_write+0x740>
    a9e5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a9e9:	48 89 ce             	mov    %rcx,%rsi
    a9ec:	e9 df f9 ff ff       	jmp    a3d0 <fwp_write+0x740>
    a9f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9f8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a9ff:	00 
    aa00:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa04:	e9 20 fa ff ff       	jmp    a429 <fwp_write+0x799>
    aa09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa10:	ba 02 00 00 00       	mov    $0x2,%edx
    aa15:	48 8d 35 b3 17 00 00 	lea    0x17b3(%rip),%rsi        # c1cf <_IO_stdin_used+0x1cf>
    aa1c:	e9 2d f7 ff ff       	jmp    a14e <fwp_write+0x4be>
    aa21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa28:	4c 8d 05 df 17 00 00 	lea    0x17df(%rip),%r8        # c20e <_IO_stdin_used+0x20e>
    aa2f:	b9 10 00 00 00       	mov    $0x10,%ecx
    aa34:	31 c0                	xor    %eax,%eax
    aa36:	ba 02 00 00 00       	mov    $0x2,%edx
    aa3b:	be 10 00 00 00       	mov    $0x10,%esi
    aa40:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa47:	00 
    aa48:	e8 63 89 ff ff       	call   33b0 <__snprintf_chk@plt>
    aa4d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa54:	00 
    aa55:	e8 f6 89 ff ff       	call   3450 <strlen@plt>
    aa5a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aa61:	00 
    aa62:	48 89 df             	mov    %rbx,%rdi
    aa65:	48 89 c2             	mov    %rax,%rdx
    aa68:	e8 a3 97 ff ff       	call   4210 <buf_put>
    aa6d:	e9 fe fd ff ff       	jmp    a870 <fwp_write+0xbe0>
    aa72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aa7c:	48 8d 35 46 17 00 00 	lea    0x1746(%rip),%rsi        # c1c9 <_IO_stdin_used+0x1c9>
    aa83:	48 8d 05 3e 17 00 00 	lea    0x173e(%rip),%rax        # c1c8 <_IO_stdin_used+0x1c8>
    aa8a:	4c 89 e7             	mov    %r12,%rdi
    aa8d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    aa91:	48 0f 46 f0          	cmovbe %rax,%rsi
    aa95:	e8 56 89 ff ff       	call   33f0 <strcpy@plt>
    aa9a:	e9 71 f2 ff ff       	jmp    9d10 <fwp_write+0x80>
    aa9f:	90                   	nop
    aaa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aaa4:	48 8d 35 1e 17 00 00 	lea    0x171e(%rip),%rsi        # c1c9 <_IO_stdin_used+0x1c9>
    aaab:	48 8d 05 16 17 00 00 	lea    0x1716(%rip),%rax        # c1c8 <_IO_stdin_used+0x1c8>
    aab2:	0f 2f c8             	comiss %xmm0,%xmm1
    aab5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aabc:	00 
    aabd:	4c 89 e7             	mov    %r12,%rdi
    aac0:	48 0f 46 f0          	cmovbe %rax,%rsi
    aac4:	e8 27 89 ff ff       	call   33f0 <strcpy@plt>
    aac9:	e9 42 f2 ff ff       	jmp    9d10 <fwp_write+0x80>
    aace:	66 90                	xchg   %ax,%ax
    aad0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    aad5:	45 85 c0             	test   %r8d,%r8d
    aad8:	75 34                	jne    ab0e <fwp_write+0xe7e>
    aada:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aae1:	00 
    aae2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aae9:	00 00 
    aaeb:	0f 85 74 f6 ff ff    	jne    a165 <fwp_write+0x4d5>
    aaf1:	ba 02 00 00 00       	mov    $0x2,%edx
    aaf6:	48 8d 35 42 17 00 00 	lea    0x1742(%rip),%rsi        # c23f <_IO_stdin_used+0x23f>
    aafd:	e9 a1 f3 ff ff       	jmp    9ea3 <fwp_write+0x213>
    ab02:	48 03 75 10          	add    0x10(%rbp),%rsi
    ab06:	49 89 f0             	mov    %rsi,%r8
    ab09:	e9 e5 fc ff ff       	jmp    a7f3 <fwp_write+0xb63>
    ab0e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ab13:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab18:	85 ff                	test   %edi,%edi
    ab1a:	0f 84 fa f3 ff ff    	je     9f1a <fwp_write+0x28a>
    ab20:	ba 01 00 00 00       	mov    $0x1,%edx
    ab25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab2a:	48 89 df             	mov    %rbx,%rdi
    ab2d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab32:	e8 d9 96 ff ff       	call   4210 <buf_put>
    ab37:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ab3c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab41:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ab47:	85 c0                	test   %eax,%eax
    ab49:	0f 8f f0 f3 ff ff    	jg     9f3f <fwp_write+0x2af>
    ab4f:	e9 34 f4 ff ff       	jmp    9f88 <fwp_write+0x2f8>
    ab54:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab58:	49 89 c5             	mov    %rax,%r13
    ab5b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab60:	49 89 c4             	mov    %rax,%r12
    ab63:	49 c1 fd 3f          	sar    $0x3f,%r13
    ab67:	4c 09 e8             	or     %r13,%rax
    ab6a:	0f 84 a7 00 00 00    	je     ac17 <fwp_write+0xf87>
    ab70:	48 8d 2d 89 38 00 00 	lea    0x3889(%rip),%rbp        # e400 <units.1>
    ab77:	4d 89 e7             	mov    %r12,%r15
    ab7a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab7e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ab83:	4c 89 ff             	mov    %r15,%rdi
    ab86:	4c 89 ee             	mov    %r13,%rsi
    ab89:	44 89 0c 24          	mov    %r9d,(%rsp)
    ab8d:	48 99                	cqto
    ab8f:	48 89 d1             	mov    %rdx,%rcx
    ab92:	48 89 c2             	mov    %rax,%rdx
    ab95:	e8 06 10 00 00       	call   bba0 <__divmodti4>
    ab9a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ab9e:	48 89 c1             	mov    %rax,%rcx
    aba1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    aba6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    abab:	0f 84 94 00 00 00    	je     ac45 <fwp_write+0xfb5>
    abb1:	41 83 c1 01          	add    $0x1,%r9d
    abb5:	48 83 c5 10          	add    $0x10,%rbp
    abb9:	41 83 f9 05          	cmp    $0x5,%r9d
    abbd:	75 bb                	jne    ab7a <fwp_write+0xeea>
    abbf:	4d 85 ed             	test   %r13,%r13
    abc2:	79 53                	jns    ac17 <fwp_write+0xf87>
    abc4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    abc9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    abce:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    abd3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    abd8:	48 99                	cqto
    abda:	48 f7 d8             	neg    %rax
    abdd:	48 83 d2 00          	adc    $0x0,%rdx
    abe1:	48 89 c6             	mov    %rax,%rsi
    abe4:	48 f7 da             	neg    %rdx
    abe7:	e8 54 8e ff ff       	call   3a40 <fwp_fmt_u128>
    abec:	49 89 e8             	mov    %rbp,%r8
    abef:	ba 00 02 00 00       	mov    $0x200,%edx
    abf4:	be 02 00 00 00       	mov    $0x2,%esi
    abf9:	31 c0                	xor    %eax,%eax
    abfb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac02:	00 
    ac03:	48 8d 0d 30 16 00 00 	lea    0x1630(%rip),%rcx        # c23a <_IO_stdin_used+0x23a>
    ac0a:	4c 89 e7             	mov    %r12,%rdi
    ac0d:	e8 ce 8a ff ff       	call   36e0 <__sprintf_chk@plt>
    ac12:	e9 f9 f0 ff ff       	jmp    9d10 <fwp_write+0x80>
    ac17:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac1c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac21:	31 d2                	xor    %edx,%edx
    ac23:	48 89 ef             	mov    %rbp,%rdi
    ac26:	e8 15 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac2b:	eb bf                	jmp    abec <fwp_write+0xf5c>
    ac2d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ac34:	4e 61 4e 00 
    ac38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac3f:	00 
    ac40:	e9 cb f0 ff ff       	jmp    9d10 <fwp_write+0x80>
    ac45:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac49:	48 89 c8             	mov    %rcx,%rax
    ac4c:	48 85 d2             	test   %rdx,%rdx
    ac4f:	78 51                	js     aca2 <fwp_write+0x1012>
    ac51:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac56:	48 89 c6             	mov    %rax,%rsi
    ac59:	48 89 ef             	mov    %rbp,%rdi
    ac5c:	e8 df 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac61:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac65:	49 63 c1             	movslq %r9d,%rax
    ac68:	49 89 e8             	mov    %rbp,%r8
    ac6b:	ba 00 02 00 00       	mov    $0x200,%edx
    ac70:	be 02 00 00 00       	mov    $0x2,%esi
    ac75:	48 c1 e0 04          	shl    $0x4,%rax
    ac79:	48 8d 3d 80 37 00 00 	lea    0x3780(%rip),%rdi        # e400 <units.1>
    ac80:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac87:	00 
    ac88:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ac8c:	48 8d 0d a2 15 00 00 	lea    0x15a2(%rip),%rcx        # c235 <_IO_stdin_used+0x235>
    ac93:	4c 89 e7             	mov    %r12,%rdi
    ac96:	31 c0                	xor    %eax,%eax
    ac98:	e8 43 8a ff ff       	call   36e0 <__sprintf_chk@plt>
    ac9d:	e9 6e f0 ff ff       	jmp    9d10 <fwp_write+0x80>
    aca2:	48 f7 d8             	neg    %rax
    aca5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    acaa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    acaf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    acb4:	48 83 d2 00          	adc    $0x0,%rdx
    acb8:	48 89 c6             	mov    %rax,%rsi
    acbb:	48 f7 da             	neg    %rdx
    acbe:	e8 7d 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acc3:	44 8b 0c 24          	mov    (%rsp),%r9d
    acc7:	eb 9c                	jmp    ac65 <fwp_write+0xfd5>
    acc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000acd0 <fwp_main_thread>:
    acd0:	f3 0f 1e fa          	endbr64
    acd4:	41 57                	push   %r15
    acd6:	41 56                	push   %r14
    acd8:	41 55                	push   %r13
    acda:	41 54                	push   %r12
    acdc:	55                   	push   %rbp
    acdd:	53                   	push   %rbx
    acde:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    ace5:	8b 3d 79 6e 01 00    	mov    0x16e79(%rip),%edi        # 21b64 <fwp_heap+0x13a4>
    aceb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    acf2:	00 00 
    acf4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    acfb:	00 
    acfc:	31 c0                	xor    %eax,%eax
    acfe:	85 ff                	test   %edi,%edi
    ad00:	0f 84 5a 08 00 00    	je     b560 <fwp_main_thread+0x890>
    ad06:	8b 35 5c 6e 01 00    	mov    0x16e5c(%rip),%esi        # 21b68 <fwp_heap+0x13a8>
    ad0c:	85 f6                	test   %esi,%esi
    ad0e:	0f 85 34 08 00 00    	jne    b548 <fwp_main_thread+0x878>
    ad14:	48 8d 05 65 53 00 00 	lea    0x5365(%rip),%rax        # 10080 <alt.5>
    ad1b:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    ad20:	31 f6                	xor    %esi,%esi
    ad22:	48 c7 05 23 54 01 00 	movq   $0x40000000,0x15423(%rip)        # 20150 <fwp_main_stack_size>
    ad29:	00 00 00 40 
    ad2d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    ad32:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    ad37:	48 89 c7             	mov    %rax,%rdi
    ad3a:	48 89 1d 17 54 01 00 	mov    %rbx,0x15417(%rip)        # 20158 <fwp_main_stack_top>
    ad41:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    ad48:	01 00 
    ad4a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    ad51:	00 
    ad52:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad57:	e8 64 89 ff ff       	call   36c0 <sigaltstack@plt>
    ad5c:	85 c0                	test   %eax,%eax
    ad5e:	0f 85 f7 0d 00 00    	jne    bb5b <fwp_main_thread+0xe8b>
    ad64:	31 c0                	xor    %eax,%eax
    ad66:	b9 12 00 00 00       	mov    $0x12,%ecx
    ad6b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ad72:	00 
    ad73:	f3 48 ab             	rep stos %rax,(%rdi)
    ad76:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
    ad7d:	00 
    ad7e:	48 8d 05 6b 8f ff ff 	lea    -0x7095(%rip),%rax        # 3cf0 <fwp_segv>
    ad85:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    ad8c:	04 00 00 08 
    ad90:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ad97:	00 
    ad98:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    ad9d:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ada4:	00 
    ada5:	e8 d6 87 ff ff       	call   3580 <sigemptyset@plt>
    adaa:	85 c0                	test   %eax,%eax
    adac:	0f 85 a9 0d 00 00    	jne    bb5b <fwp_main_thread+0xe8b>
    adb2:	31 d2                	xor    %edx,%edx
    adb4:	4c 89 f6             	mov    %r14,%rsi
    adb7:	bf 0b 00 00 00       	mov    $0xb,%edi
    adbc:	e8 3f 86 ff ff       	call   3400 <sigaction@plt>
    adc1:	85 c0                	test   %eax,%eax
    adc3:	0f 85 92 0d 00 00    	jne    bb5b <fwp_main_thread+0xe8b>
    adc9:	31 d2                	xor    %edx,%edx
    adcb:	4c 89 f6             	mov    %r14,%rsi
    adce:	bf 07 00 00 00       	mov    $0x7,%edi
    add3:	e8 28 86 ff ff       	call   3400 <sigaction@plt>
    add8:	85 c0                	test   %eax,%eax
    adda:	0f 85 7b 0d 00 00    	jne    bb5b <fwp_main_thread+0xe8b>
    ade0:	8b 0d 12 53 01 00    	mov    0x15312(%rip),%ecx        # 200f8 <descent_registered>
    ade6:	85 c9                	test   %ecx,%ecx
    ade8:	0f 84 6a 05 00 00    	je     b358 <fwp_main_thread+0x688>
    adee:	8b 15 7c 52 00 00    	mov    0x527c(%rip),%edx        # 10070 <st.3>
    adf4:	85 d2                	test   %edx,%edx
    adf6:	0f 84 88 05 00 00    	je     b384 <fwp_main_thread+0x6b4>
    adfc:	48 8b 2d 9d 59 01 00 	mov    0x1599d(%rip),%rbp        # 207a0 <fwp_cur>
    ae03:	48 85 ed             	test   %rbp,%rbp
    ae06:	0f 84 c4 01 00 00    	je     afd0 <fwp_main_thread+0x300>
    ae0c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ae11:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ae15:	48 89 eb             	mov    %rbp,%rbx
    ae18:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ae1d:	0f 84 41 01 00 00    	je     af64 <fwp_main_thread+0x294>
    ae23:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ae28:	0f 84 a2 02 00 00    	je     b0d0 <fwp_main_thread+0x400>
    ae2e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ae32:	0f 84 78 02 00 00    	je     b0b0 <fwp_main_thread+0x3e0>
    ae38:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ae3c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ae40:	0f 85 0a 03 00 00    	jne    b150 <fwp_main_thread+0x480>
    ae46:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ae4a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae51:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ae55:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ae5c:	00 00 00 00 
    ae60:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ae67:	48 85 d2             	test   %rdx,%rdx
    ae6a:	74 07                	je     ae73 <fwp_main_thread+0x1a3>
    ae6c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ae73:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ae77:	48 85 c0             	test   %rax,%rax
    ae7a:	74 34                	je     aeb0 <fwp_main_thread+0x1e0>
    ae7c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    ae80:	48 8b 05 f1 58 01 00 	mov    0x158f1(%rip),%rax        # 20778 <fwp_timers>
    ae87:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ae8b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ae92:	00 00 00 00 
    ae96:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ae9d:	48 85 c0             	test   %rax,%rax
    aea0:	74 07                	je     aea9 <fwp_main_thread+0x1d9>
    aea2:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    aea9:	48 89 1d c8 58 01 00 	mov    %rbx,0x158c8(%rip)        # 20778 <fwp_timers>
    aeb0:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    aeb4:	e8 b7 c3 ff ff       	call   7270 <fwp_block>
    aeb9:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    aec0:	48 85 c9             	test   %rcx,%rcx
    aec3:	74 47                	je     af0c <fwp_main_thread+0x23c>
    aec5:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    aecc:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    aed3:	48 85 d2             	test   %rdx,%rdx
    aed6:	0f 84 b4 02 00 00    	je     b190 <fwp_main_thread+0x4c0>
    aedc:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    aee3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    aeea:	48 85 c0             	test   %rax,%rax
    aeed:	74 07                	je     aef6 <fwp_main_thread+0x226>
    aeef:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    aef6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    aefd:	00 00 00 00 
    af01:	66 0f ef c9          	pxor   %xmm1,%xmm1
    af05:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    af0c:	48 8b 0d 8d 58 01 00 	mov    0x1588d(%rip),%rcx        # 207a0 <fwp_cur>
    af13:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    af17:	0f 84 23 02 00 00    	je     b140 <fwp_main_thread+0x470>
    af1d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    af24:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    af2b:	48 85 d2             	test   %rdx,%rdx
    af2e:	0f 84 14 04 00 00    	je     b348 <fwp_main_thread+0x678>
    af34:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    af3b:	48 85 c0             	test   %rax,%rax
    af3e:	74 07                	je     af47 <fwp_main_thread+0x277>
    af40:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    af47:	66 0f ef d2          	pxor   %xmm2,%xmm2
    af4b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    af4f:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    af56:	48 89 cb             	mov    %rcx,%rbx
    af59:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    af5e:	0f 85 bf fe ff ff    	jne    ae23 <fwp_main_thread+0x153>
    af64:	48 83 3d cc 74 01 00 	cmpq   $0x0,0x174cc(%rip)        # 22438 <fwp_state_len>
    af6b:	00 
    af6c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    af70:	74 6e                	je     afe0 <fwp_main_thread+0x310>
    af72:	48 39 1d 1f 58 01 00 	cmp    %rbx,0x1581f(%rip)        # 20798 <fwp_root>
    af79:	c7 05 fd 50 01 00 00 	movl   $0x0,0x150fd(%rip)        # 20080 <fwp_exit_code>
    af80:	00 00 00 
    af83:	0f 85 05 0c 00 00    	jne    bb8e <fwp_main_thread+0xebe>
    af89:	48 85 db             	test   %rbx,%rbx
    af8c:	0f 84 26 02 00 00    	je     b1b8 <fwp_main_thread+0x4e8>
    af92:	48 8b 15 cf 57 01 00 	mov    0x157cf(%rip),%rdx        # 20768 <fwp_tasks_active>
    af99:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    af9d:	48 85 d2             	test   %rdx,%rdx
    afa0:	0f 84 12 02 00 00    	je     b1b8 <fwp_main_thread+0x4e8>
    afa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    afad:	00 00 00 
    afb0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    afb4:	75 08                	jne    afbe <fwp_main_thread+0x2ee>
    afb6:	48 89 d7             	mov    %rdx,%rdi
    afb9:	e8 42 93 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    afbe:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    afc5:	48 85 d2             	test   %rdx,%rdx
    afc8:	75 e6                	jne    afb0 <fwp_main_thread+0x2e0>
    afca:	e9 ae 00 00 00       	jmp    b07d <fwp_main_thread+0x3ad>
    afcf:	90                   	nop
    afd0:	48 83 3d 60 74 01 00 	cmpq   $0x0,0x17460(%rip)        # 22438 <fwp_state_len>
    afd7:	00 
    afd8:	0f 85 c2 01 00 00    	jne    b1a0 <fwp_main_thread+0x4d0>
    afde:	31 db                	xor    %ebx,%ebx
    afe0:	48 83 3d 40 74 01 00 	cmpq   $0x0,0x17440(%rip)        # 22428 <fwp_state_owners>
    afe7:	00 
    afe8:	75 88                	jne    af72 <fwp_main_thread+0x2a2>
    afea:	48 8b 3d 4f 74 01 00 	mov    0x1744f(%rip),%rdi        # 22440 <fwp_state>
    aff1:	e8 9a a7 ff ff       	call   5790 <fwp_mem_free>
    aff6:	48 c7 05 3f 74 01 00 	movq   $0x0,0x1743f(%rip)        # 22440 <fwp_state>
    affd:	00 00 00 00 
    b001:	48 c7 05 24 74 01 00 	movq   $0x0,0x17424(%rip)        # 22430 <fwp_state_cap>
    b008:	00 00 00 00 
    b00c:	48 85 db             	test   %rbx,%rbx
    b00f:	0f 84 3e 0a 00 00    	je     ba53 <fwp_main_thread+0xd83>
    b015:	48 39 1d 7c 57 01 00 	cmp    %rbx,0x1577c(%rip)        # 20798 <fwp_root>
    b01c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b023:	00 00 00 00 
    b027:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b02e:	00 00 00 00 
    b032:	c7 05 44 50 01 00 00 	movl   $0x0,0x15044(%rip)        # 20080 <fwp_exit_code>
    b039:	00 00 00 
    b03c:	0f 84 50 ff ff ff    	je     af92 <fwp_main_thread+0x2c2>
    b042:	e9 09 87 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b04e:	00 00 
    b050:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b057:	48 89 1d 22 57 01 00 	mov    %rbx,0x15722(%rip)        # 20780 <fwp_ready_tail>
    b05e:	e8 0d c2 ff ff       	call   7270 <fwp_block>
    b063:	e8 08 c0 ff ff       	call   7070 <fwp_free_zombie>
    b068:	48 83 3d f8 56 01 00 	cmpq   $0x0,0x156f8(%rip)        # 20768 <fwp_tasks_active>
    b06f:	00 
    b070:	0f 84 42 01 00 00    	je     b1b8 <fwp_main_thread+0x4e8>
    b076:	48 8b 1d 1b 57 01 00 	mov    0x1571b(%rip),%rbx        # 20798 <fwp_root>
    b07d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b081:	75 db                	jne    b05e <fwp_main_thread+0x38e>
    b083:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b087:	75 d5                	jne    b05e <fwp_main_thread+0x38e>
    b089:	48 8b 05 f0 56 01 00 	mov    0x156f0(%rip),%rax        # 20780 <fwp_ready_tail>
    b090:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b094:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b09b:	00 00 00 00 
    b09f:	48 85 c0             	test   %rax,%rax
    b0a2:	75 ac                	jne    b050 <fwp_main_thread+0x380>
    b0a4:	48 89 1d dd 56 01 00 	mov    %rbx,0x156dd(%rip)        # 20788 <fwp_ready_head>
    b0ab:	eb aa                	jmp    b057 <fwp_main_thread+0x387>
    b0ad:	0f 1f 00             	nopl   (%rax)
    b0b0:	e8 ab 94 ff ff       	call   4560 <fwp_now_ns>
    b0b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b0b9:	7c 15                	jl     b0d0 <fwp_main_thread+0x400>
    b0bb:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b0bf:	75 0f                	jne    b0d0 <fwp_main_thread+0x400>
    b0c1:	48 89 ef             	mov    %rbp,%rdi
    b0c4:	e8 37 92 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b0c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b0d0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b0d4:	0f 85 5e fd ff ff    	jne    ae38 <fwp_main_thread+0x168>
    b0da:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b0de:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b0e2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b0e6:	0f 85 5e fd ff ff    	jne    ae4a <fwp_main_thread+0x17a>
    b0ec:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b0f0:	48 85 c9             	test   %rcx,%rcx
    b0f3:	0f 84 51 fd ff ff    	je     ae4a <fwp_main_thread+0x17a>
    b0f9:	48 39 c8             	cmp    %rcx,%rax
    b0fc:	48 89 ce             	mov    %rcx,%rsi
    b0ff:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b106:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b10a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b111:	00 00 00 00 
    b115:	48 0f 4e f0          	cmovle %rax,%rsi
    b119:	48 85 c0             	test   %rax,%rax
    b11c:	48 89 c8             	mov    %rcx,%rax
    b11f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b126:	48 0f 45 c6          	cmovne %rsi,%rax
    b12a:	48 85 d2             	test   %rdx,%rdx
    b12d:	74 07                	je     b136 <fwp_main_thread+0x466>
    b12f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b136:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b13a:	e9 3d fd ff ff       	jmp    ae7c <fwp_main_thread+0x1ac>
    b13f:	90                   	nop
    b140:	48 89 cb             	mov    %rcx,%rbx
    b143:	e9 d0 fc ff ff       	jmp    ae18 <fwp_main_thread+0x148>
    b148:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b14f:	00 
    b150:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b154:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b15b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b162:	00 00 00 00 
    b166:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b16d:	48 85 c0             	test   %rax,%rax
    b170:	0f 84 5a 08 00 00    	je     b9d0 <fwp_main_thread+0xd00>
    b176:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b17d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b181:	e9 2a fd ff ff       	jmp    aeb0 <fwp_main_thread+0x1e0>
    b186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b18d:	00 00 00 
    b190:	48 89 01             	mov    %rax,(%rcx)
    b193:	e9 52 fd ff ff       	jmp    aeea <fwp_main_thread+0x21a>
    b198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b19f:	00 
    b1a0:	48 83 3d f0 55 01 00 	cmpq   $0x0,0x155f0(%rip)        # 20798 <fwp_root>
    b1a7:	00 
    b1a8:	c7 05 ce 4e 01 00 00 	movl   $0x0,0x14ece(%rip)        # 20080 <fwp_exit_code>
    b1af:	00 00 00 
    b1b2:	0f 85 db 09 00 00    	jne    bb93 <fwp_main_thread+0xec3>
    b1b8:	e8 b3 be ff ff       	call   7070 <fwp_free_zombie>
    b1bd:	48 83 3d c3 55 01 00 	cmpq   $0x0,0x155c3(%rip)        # 20788 <fwp_ready_head>
    b1c4:	00 
    b1c5:	0f 85 85 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1cb:	48 83 3d a5 55 01 00 	cmpq   $0x0,0x155a5(%rip)        # 20778 <fwp_timers>
    b1d2:	00 
    b1d3:	0f 85 77 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1d9:	8b 05 85 4f 01 00    	mov    0x14f85(%rip),%eax        # 20164 <fwp_stack_pool_n>
    b1df:	85 c0                	test   %eax,%eax
    b1e1:	74 3a                	je     b21d <fwp_main_thread+0x54d>
    b1e3:	83 e8 01             	sub    $0x1,%eax
    b1e6:	4c 8d 25 93 4f 01 00 	lea    0x14f93(%rip),%r12        # 20180 <fwp_stack_pool>
    b1ed:	48 63 d8             	movslq %eax,%rbx
    b1f0:	89 c0                	mov    %eax,%eax
    b1f2:	48 89 da             	mov    %rbx,%rdx
    b1f5:	48 29 c2             	sub    %rax,%rdx
    b1f8:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b1fc:	0f 1f 40 00          	nopl   0x0(%rax)
    b200:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b204:	89 1d 5a 4f 01 00    	mov    %ebx,0x14f5a(%rip)        # 20164 <fwp_stack_pool_n>
    b20a:	be 00 00 00 10       	mov    $0x10000000,%esi
    b20f:	48 83 eb 01          	sub    $0x1,%rbx
    b213:	e8 c8 83 ff ff       	call   35e0 <munmap@plt>
    b218:	48 39 dd             	cmp    %rbx,%rbp
    b21b:	75 e3                	jne    b200 <fwp_main_thread+0x530>
    b21d:	8b 3d f9 4d 00 00    	mov    0x4df9(%rip),%edi        # 1001c <fwp_epfd>
    b223:	85 ff                	test   %edi,%edi
    b225:	78 05                	js     b22c <fwp_main_thread+0x55c>
    b227:	e8 a4 82 ff ff       	call   34d0 <close@plt>
    b22c:	4c 8b 25 4d 51 01 00 	mov    0x1514d(%rip),%r12        # 20380 <fwp_nfdws>
    b233:	48 8b 2d 4e 51 01 00 	mov    0x1514e(%rip),%rbp        # 20388 <fwp_fdws>
    b23a:	31 db                	xor    %ebx,%ebx
    b23c:	c7 05 d6 4d 00 00 ff 	movl   $0xffffffff,0x4dd6(%rip)        # 1001c <fwp_epfd>
    b243:	ff ff ff 
    b246:	4d 85 e4             	test   %r12,%r12
    b249:	74 32                	je     b27d <fwp_main_thread+0x5ad>
    b24b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b250:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b255:	48 85 ff             	test   %rdi,%rdi
    b258:	74 1a                	je     b274 <fwp_main_thread+0x5a4>
    b25a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b25e:	0f 85 ec 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b264:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b269:	0f 85 e1 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b26f:	e8 1c a5 ff ff       	call   5790 <fwp_mem_free>
    b274:	48 83 c3 01          	add    $0x1,%rbx
    b278:	49 39 dc             	cmp    %rbx,%r12
    b27b:	75 d3                	jne    b250 <fwp_main_thread+0x580>
    b27d:	48 89 ef             	mov    %rbp,%rdi
    b280:	e8 0b a5 ff ff       	call   5790 <fwp_mem_free>
    b285:	48 8b 15 0c 55 01 00 	mov    0x1550c(%rip),%rdx        # 20798 <fwp_root>
    b28c:	48 c7 05 f1 50 01 00 	movq   $0x0,0x150f1(%rip)        # 20388 <fwp_fdws>
    b293:	00 00 00 00 
    b297:	48 c7 05 de 50 01 00 	movq   $0x0,0x150de(%rip)        # 20380 <fwp_nfdws>
    b29e:	00 00 00 00 
    b2a2:	48 85 d2             	test   %rdx,%rdx
    b2a5:	74 4e                	je     b2f5 <fwp_main_thread+0x625>
    b2a7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b2ac:	0f 85 9e 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2b2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b2b9:	00 
    b2ba:	0f 85 90 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2c0:	48 83 3d 70 71 01 00 	cmpq   $0x0,0x17170(%rip)        # 22438 <fwp_state_len>
    b2c7:	00 
    b2c8:	0f 85 82 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2ce:	48 83 3d 52 71 01 00 	cmpq   $0x0,0x17152(%rip)        # 22428 <fwp_state_owners>
    b2d5:	00 
    b2d6:	0f 85 74 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2dc:	b9 79 00 00 00       	mov    $0x79,%ecx
    b2e1:	31 c0                	xor    %eax,%eax
    b2e3:	48 8d 3d b6 50 01 00 	lea    0x150b6(%rip),%rdi        # 203a0 <fwp_root_context>
    b2ea:	f3 48 ab             	rep stos %rax,(%rdi)
    b2ed:	48 89 d7             	mov    %rdx,%rdi
    b2f0:	e8 9b a4 ff ff       	call   5790 <fwp_mem_free>
    b2f5:	48 8b 3d 24 4d 00 00 	mov    0x4d24(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b2fc:	48 c7 05 99 54 01 00 	movq   $0x0,0x15499(%rip)        # 207a0 <fwp_cur>
    b303:	00 00 00 00 
    b307:	48 c7 05 86 54 01 00 	movq   $0x0,0x15486(%rip)        # 20798 <fwp_root>
    b30e:	00 00 00 00 
    b312:	e8 a9 82 ff ff       	call   35c0 <fflush@plt>
    b317:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b31e:	00 
    b31f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b326:	00 00 
    b328:	0f 85 4f 08 00 00    	jne    bb7d <fwp_main_thread+0xead>
    b32e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b335:	31 c0                	xor    %eax,%eax
    b337:	5b                   	pop    %rbx
    b338:	5d                   	pop    %rbp
    b339:	41 5c                	pop    %r12
    b33b:	41 5d                	pop    %r13
    b33d:	41 5e                	pop    %r14
    b33f:	41 5f                	pop    %r15
    b341:	c3                   	ret
    b342:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b348:	48 89 05 29 54 01 00 	mov    %rax,0x15429(%rip)        # 20778 <fwp_timers>
    b34f:	e9 e7 fb ff ff       	jmp    af3b <fwp_main_thread+0x26b>
    b354:	0f 1f 40 00          	nopl   0x0(%rax)
    b358:	48 8d 3d b1 8a ff ff 	lea    -0x754f(%rip),%rdi        # 3e10 <descent_phase_report>
    b35f:	e8 4c 0a 00 00       	call   bdb0 <atexit>
    b364:	85 c0                	test   %eax,%eax
    b366:	0f 85 0c 08 00 00    	jne    bb78 <fwp_main_thread+0xea8>
    b36c:	c7 05 82 4d 01 00 01 	movl   $0x1,0x14d82(%rip)        # 200f8 <descent_registered>
    b373:	00 00 00 
    b376:	8b 15 f4 4c 00 00    	mov    0x4cf4(%rip),%edx        # 10070 <st.3>
    b37c:	85 d2                	test   %edx,%edx
    b37e:	0f 85 78 fa ff ff    	jne    adfc <fwp_main_thread+0x12c>
    b384:	48 8d 05 25 b6 ff ff 	lea    -0x49db(%rip),%rax        # 69b0 <fwp_drop1>
    b38b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b38f:	4c 8b 35 4a 18 00 00 	mov    0x184a(%rip),%r14        # cbe0 <msg.4+0x70>
    b396:	31 ed                	xor    %ebp,%ebp
    b398:	66 48 0f 6e d8       	movq   %rax,%xmm3
    b39d:	48 8b 05 b4 70 01 00 	mov    0x170b4(%rip),%rax        # 22458 <fwp_cleanups>
    b3a4:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b3ab:	00 00 
    b3ad:	41 bf ff 7f 00 00    	mov    $0x7fff,%r15d
    b3b3:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    b3b7:	48 89 1d 9a 70 01 00 	mov    %rbx,0x1709a(%rip)        # 22458 <fwp_cleanups>
    b3be:	48 8d 1d fb 53 01 00 	lea    0x153fb(%rip),%rbx        # 207c0 <fwp_heap>
    b3c5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b3ca:	48 8d 05 ff 87 ff ff 	lea    -0x7801(%rip),%rax        # 3bd0 <fwp_range_release>
    b3d1:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b3d6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b3db:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b3e0:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    b3e5:	e9 03 01 00 00       	jmp    b4ed <fwp_main_thread+0x81d>
    b3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b3f0:	49 8b 14 24          	mov    (%r12),%rdx
    b3f4:	48 f7 d2             	not    %rdx
    b3f7:	48 89 10             	mov    %rdx,(%rax)
    b3fa:	49 83 fd 18          	cmp    $0x18,%r13
    b3fe:	76 1c                	jbe    b41c <fwp_main_thread+0x74c>
    b400:	49 8d 45 e7          	lea    -0x19(%r13),%rax
    b404:	49 8d 7c 24 18       	lea    0x18(%r12),%rdi
    b409:	31 f6                	xor    %esi,%esi
    b40b:	48 c1 e8 03          	shr    $0x3,%rax
    b40f:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b416:	00 
    b417:	e8 a4 80 ff ff       	call   34c0 <memset@plt>
    b41c:	4c 89 e8             	mov    %r13,%rax
    b41f:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    b426:	0f 82 3b 07 00 00    	jb     bb67 <fwp_main_thread+0xe97>
    b42c:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    b433:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    b43a:	73 07                	jae    b443 <fwp_main_thread+0x773>
    b43c:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    b443:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b447:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    b44c:	f2 0f 58 83 38 14 00 	addsd  0x1438(%rbx),%xmm0
    b453:	00 
    b454:	f2 0f 11 83 38 14 00 	movsd  %xmm0,0x1438(%rbx)
    b45b:	00 
    b45c:	49 89 6c 24 10       	mov    %rbp,0x10(%r12)
    b461:	4c 89 e0             	mov    %r12,%rax
    b464:	4c 89 e5             	mov    %r12,%rbp
    b467:	4d 89 34 24          	mov    %r14,(%r12)
    b46b:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
    b470:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b477:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b47e:	48 c1 e2 10          	shl    $0x10,%rdx
    b482:	48 39 d0             	cmp    %rdx,%rax
    b485:	73 57                	jae    b4de <fwp_main_thread+0x80e>
    b487:	48 89 c2             	mov    %rax,%rdx
    b48a:	48 c1 ea 10          	shr    $0x10,%rdx
    b48e:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b492:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b499:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b49d:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b4a1:	48 85 d2             	test   %rdx,%rdx
    b4a4:	74 38                	je     b4de <fwp_main_thread+0x80e>
    b4a6:	0f b6 3e             	movzbl (%rsi),%edi
    b4a9:	40 80 ff 02          	cmp    $0x2,%dil
    b4ad:	0f 84 d5 00 00 00    	je     b588 <fwp_main_thread+0x8b8>
    b4b3:	40 80 ff 01          	cmp    $0x1,%dil
    b4b7:	75 25                	jne    b4de <fwp_main_thread+0x80e>
    b4b9:	8b 7e 18             	mov    0x18(%rsi),%edi
    b4bc:	0f b7 c0             	movzwl %ax,%eax
    b4bf:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b4c2:	48 0f af c7          	imul   %rdi,%rax
    b4c6:	48 c1 e8 20          	shr    $0x20,%rax
    b4ca:	48 39 f0             	cmp    %rsi,%rax
    b4cd:	73 0f                	jae    b4de <fwp_main_thread+0x80e>
    b4cf:	48 01 c2             	add    %rax,%rdx
    b4d2:	80 3a ff             	cmpb   $0xff,(%rdx)
    b4d5:	0f 84 45 05 00 00    	je     ba20 <fwp_main_thread+0xd50>
    b4db:	c6 02 01             	movb   $0x1,(%rdx)
    b4de:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b4e3:	49 83 ef 01          	sub    $0x1,%r15
    b4e7:	0f 82 b3 00 00 00    	jb     b5a0 <fwp_main_thread+0x8d0>
    b4ed:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b4f3:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
    b4f8:	85 c0                	test   %eax,%eax
    b4fa:	74 74                	je     b570 <fwp_main_thread+0x8a0>
    b4fc:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    b503:	44 8b ac 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r13d
    b50a:	00 
    b50b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b50f:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    b513:	4c 8b 20             	mov    (%rax),%r12
    b516:	4d 85 e4             	test   %r12,%r12
    b519:	0f 85 d1 fe ff ff    	jne    b3f0 <fwp_main_thread+0x720>
    b51f:	4c 8b 60 08          	mov    0x8(%rax),%r12
    b523:	4d 85 e4             	test   %r12,%r12
    b526:	74 48                	je     b570 <fwp_main_thread+0x8a0>
    b528:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b52c:	4c 29 e2             	sub    %r12,%rdx
    b52f:	4c 39 ea             	cmp    %r13,%rdx
    b532:	72 3c                	jb     b570 <fwp_main_thread+0x8a0>
    b534:	4b 8d 14 2c          	lea    (%r12,%r13,1),%rdx
    b538:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b53c:	e9 b9 fe ff ff       	jmp    b3fa <fwp_main_thread+0x72a>
    b541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b548:	48 8d 3d 11 97 ff ff 	lea    -0x68ef(%rip),%rdi        # 4c60 <fwp_heap_report>
    b54f:	e8 5c 08 00 00       	call   bdb0 <atexit>
    b554:	e9 bb f7 ff ff       	jmp    ad14 <fwp_main_thread+0x44>
    b559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b560:	e8 0b 98 ff ff       	call   4d70 <fwp_heap_init>
    b565:	e9 9c f7 ff ff       	jmp    ad06 <fwp_main_thread+0x36>
    b56a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b570:	31 f6                	xor    %esi,%esi
    b572:	bf 18 00 00 00       	mov    $0x18,%edi
    b577:	e8 14 a7 ff ff       	call   5c90 <fwp_heap_alloc>
    b57c:	49 89 c4             	mov    %rax,%r12
    b57f:	e9 d8 fe ff ff       	jmp    b45c <fwp_main_thread+0x78c>
    b584:	0f 1f 40 00          	nopl   0x0(%rax)
    b588:	66 85 c0             	test   %ax,%ax
    b58b:	0f 84 41 ff ff ff    	je     b4d2 <fwp_main_thread+0x802>
    b591:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b596:	49 83 ef 01          	sub    $0x1,%r15
    b59a:	0f 83 4d ff ff ff    	jae    b4ed <fwp_main_thread+0x81d>
    b5a0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b5a5:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    b5aa:	bf 01 00 00 00       	mov    $0x1,%edi
    b5af:	66 0f 6f 05 59 16 00 	movdqa 0x1659(%rip),%xmm0        # cc10 <msg.4+0xa0>
    b5b6:	00 
    b5b7:	48 89 05 9a 6e 01 00 	mov    %rax,0x16e9a(%rip)        # 22458 <fwp_cleanups>
    b5be:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b5c5:	00 
    b5c6:	e8 95 af ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b5cb:	48 8b 15 c6 65 01 00 	mov    0x165c6(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b5d2:	49 89 c6             	mov    %rax,%r14
    b5d5:	48 2b 05 94 65 01 00 	sub    0x16594(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    b5dc:	48 c1 e2 10          	shl    $0x10,%rdx
    b5e0:	48 39 d0             	cmp    %rdx,%rax
    b5e3:	73 59                	jae    b63e <fwp_main_thread+0x96e>
    b5e5:	48 89 c2             	mov    %rax,%rdx
    b5e8:	48 c1 ea 10          	shr    $0x10,%rdx
    b5ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5f0:	48 8b 15 c1 65 01 00 	mov    0x165c1(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    b5f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5fb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b5ff:	4d 85 ed             	test   %r13,%r13
    b602:	74 3a                	je     b63e <fwp_main_thread+0x96e>
    b604:	0f b6 0a             	movzbl (%rdx),%ecx
    b607:	80 f9 02             	cmp    $0x2,%cl
    b60a:	0f 84 e0 03 00 00    	je     b9f0 <fwp_main_thread+0xd20>
    b610:	80 f9 01             	cmp    $0x1,%cl
    b613:	75 29                	jne    b63e <fwp_main_thread+0x96e>
    b615:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b618:	0f b7 c0             	movzwl %ax,%eax
    b61b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b61e:	48 0f af c1          	imul   %rcx,%rax
    b622:	48 c1 e8 20          	shr    $0x20,%rax
    b626:	48 39 d0             	cmp    %rdx,%rax
    b629:	73 13                	jae    b63e <fwp_main_thread+0x96e>
    b62b:	49 01 c5             	add    %rax,%r13
    b62e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b633:	0f 84 6e 04 00 00    	je     baa7 <fwp_main_thread+0xdd7>
    b639:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b63e:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b643:	bf 01 00 00 00       	mov    $0x1,%edi
    b648:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b64d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b654:	00 f0 3f 
    b657:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b65c:	e8 ff ae ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b661:	48 8b 15 30 65 01 00 	mov    0x16530(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b668:	49 89 c6             	mov    %rax,%r14
    b66b:	48 2b 05 fe 64 01 00 	sub    0x164fe(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    b672:	48 c1 e2 10          	shl    $0x10,%rdx
    b676:	48 39 d0             	cmp    %rdx,%rax
    b679:	73 59                	jae    b6d4 <fwp_main_thread+0xa04>
    b67b:	48 89 c2             	mov    %rax,%rdx
    b67e:	48 c1 ea 10          	shr    $0x10,%rdx
    b682:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b686:	48 8b 15 2b 65 01 00 	mov    0x1652b(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    b68d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b691:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b695:	4d 85 ed             	test   %r13,%r13
    b698:	74 3a                	je     b6d4 <fwp_main_thread+0xa04>
    b69a:	0f b6 0a             	movzbl (%rdx),%ecx
    b69d:	80 f9 02             	cmp    $0x2,%cl
    b6a0:	0f 84 6a 03 00 00    	je     ba10 <fwp_main_thread+0xd40>
    b6a6:	80 f9 01             	cmp    $0x1,%cl
    b6a9:	75 29                	jne    b6d4 <fwp_main_thread+0xa04>
    b6ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6ae:	0f b7 c0             	movzwl %ax,%eax
    b6b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6b4:	48 0f af c1          	imul   %rcx,%rax
    b6b8:	48 c1 e8 20          	shr    $0x20,%rax
    b6bc:	48 39 d0             	cmp    %rdx,%rax
    b6bf:	73 13                	jae    b6d4 <fwp_main_thread+0xa04>
    b6c1:	49 01 c5             	add    %rax,%r13
    b6c4:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b6c9:	0f 84 e5 03 00 00    	je     bab4 <fwp_main_thread+0xde4>
    b6cf:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b6d4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b6d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6de:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b6e3:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b6ea:	33 f3 bf 
    b6ed:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b6f2:	e8 69 ae ff ff       	call   6560 <fwp_data.part.0.constprop.0>
    b6f7:	48 8b 15 9a 64 01 00 	mov    0x1649a(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b6fe:	48 8b 0d 6b 64 01 00 	mov    0x1646b(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    b705:	49 89 c5             	mov    %rax,%r13
    b708:	48 89 d6             	mov    %rdx,%rsi
    b70b:	48 29 c8             	sub    %rcx,%rax
    b70e:	48 c1 e6 10          	shl    $0x10,%rsi
    b712:	48 39 f0             	cmp    %rsi,%rax
    b715:	73 67                	jae    b77e <fwp_main_thread+0xaae>
    b717:	48 89 c6             	mov    %rax,%rsi
    b71a:	48 c1 ee 10          	shr    $0x10,%rsi
    b71e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b722:	48 8b 35 8f 64 01 00 	mov    0x1648f(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    b729:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b72d:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b731:	4d 85 f6             	test   %r14,%r14
    b734:	74 48                	je     b77e <fwp_main_thread+0xaae>
    b736:	0f b6 3e             	movzbl (%rsi),%edi
    b739:	40 80 ff 02          	cmp    $0x2,%dil
    b73d:	0f 84 bd 02 00 00    	je     ba00 <fwp_main_thread+0xd30>
    b743:	40 80 ff 01          	cmp    $0x1,%dil
    b747:	75 35                	jne    b77e <fwp_main_thread+0xaae>
    b749:	8b 7e 18             	mov    0x18(%rsi),%edi
    b74c:	0f b7 c0             	movzwl %ax,%eax
    b74f:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b752:	48 0f af c7          	imul   %rdi,%rax
    b756:	48 c1 e8 20          	shr    $0x20,%rax
    b75a:	48 39 f0             	cmp    %rsi,%rax
    b75d:	73 1f                	jae    b77e <fwp_main_thread+0xaae>
    b75f:	49 01 c6             	add    %rax,%r14
    b762:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b766:	0f 84 55 03 00 00    	je     bac1 <fwp_main_thread+0xdf1>
    b76c:	41 c6 06 01          	movb   $0x1,(%r14)
    b770:	48 8b 0d f9 63 01 00 	mov    0x163f9(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    b777:	48 8b 15 1a 64 01 00 	mov    0x1641a(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    b77e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    b783:	4c 89 e8             	mov    %r13,%rax
    b786:	48 c1 e2 10          	shl    $0x10,%rdx
    b78a:	48 29 c8             	sub    %rcx,%rax
    b78d:	48 39 d0             	cmp    %rdx,%rax
    b790:	73 5d                	jae    b7ef <fwp_main_thread+0xb1f>
    b792:	48 89 c2             	mov    %rax,%rdx
    b795:	48 c1 ea 10          	shr    $0x10,%rdx
    b799:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b79d:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b7a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7a8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b7ac:	48 85 ff             	test   %rdi,%rdi
    b7af:	74 3e                	je     b7ef <fwp_main_thread+0xb1f>
    b7b1:	0f b6 0a             	movzbl (%rdx),%ecx
    b7b4:	80 f9 02             	cmp    $0x2,%cl
    b7b7:	0f 84 23 02 00 00    	je     b9e0 <fwp_main_thread+0xd10>
    b7bd:	80 f9 01             	cmp    $0x1,%cl
    b7c0:	75 2d                	jne    b7ef <fwp_main_thread+0xb1f>
    b7c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7c5:	0f b7 c0             	movzwl %ax,%eax
    b7c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7cb:	48 0f af c1          	imul   %rcx,%rax
    b7cf:	48 c1 e8 20          	shr    $0x20,%rax
    b7d3:	48 39 d0             	cmp    %rdx,%rax
    b7d6:	73 17                	jae    b7ef <fwp_main_thread+0xb1f>
    b7d8:	48 01 c7             	add    %rax,%rdi
    b7db:	0f b6 07             	movzbl (%rdi),%eax
    b7de:	84 c0                	test   %al,%al
    b7e0:	74 0d                	je     b7ef <fwp_main_thread+0xb1f>
    b7e2:	3c fd                	cmp    $0xfd,%al
    b7e4:	0f 87 e4 02 00 00    	ja     bace <fwp_main_thread+0xdfe>
    b7ea:	83 c0 01             	add    $0x1,%eax
    b7ed:	88 07                	mov    %al,(%rdi)
    b7ef:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b7f4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b7f8:	b9 01 00 00 00       	mov    $0x1,%ecx
    b7fd:	4c 89 ee             	mov    %r13,%rsi
    b800:	48 8d 15 79 43 00 00 	lea    0x4379(%rip),%rdx        # fb80 <d0>
    b807:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b80c:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b813:	00 00 
    b815:	e8 76 e4 ff ff       	call   9c90 <fwp_write>
    b81a:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b81f:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
    b824:	48 8d 05 66 08 00 00 	lea    0x866(%rip),%rax        # c091 <_IO_stdin_used+0x91>
    b82b:	4d 85 f6             	test   %r14,%r14
    b82e:	4c 0f 44 f0          	cmove  %rax,%r14
    b832:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    b836:	0f 87 46 03 00 00    	ja     bb82 <fwp_main_thread+0xeb2>
    b83c:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    b840:	be 01 00 00 00       	mov    $0x1,%esi
    b845:	e8 46 a4 ff ff       	call   5c90 <fwp_heap_alloc>
    b84a:	4c 89 fa             	mov    %r15,%rdx
    b84d:	4c 89 f6             	mov    %r14,%rsi
    b850:	4c 89 38             	mov    %r15,(%rax)
    b853:	48 89 c5             	mov    %rax,%rbp
    b856:	48 8d 40 08          	lea    0x8(%rax),%rax
    b85a:	48 89 c7             	mov    %rax,%rdi
    b85d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    b862:	e8 39 7d ff ff       	call   35a0 <memcpy@plt>
    b867:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    b86d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b872:	e8 49 7b ff ff       	call   33c0 <free@plt>
    b877:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b87e:	48 89 e8             	mov    %rbp,%rax
    b881:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b888:	48 c1 e2 10          	shl    $0x10,%rdx
    b88c:	48 39 d0             	cmp    %rdx,%rax
    b88f:	73 57                	jae    b8e8 <fwp_main_thread+0xc18>
    b891:	48 89 c2             	mov    %rax,%rdx
    b894:	48 c1 ea 10          	shr    $0x10,%rdx
    b898:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b89c:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b8a3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8a7:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b8ab:	4d 85 f6             	test   %r14,%r14
    b8ae:	74 38                	je     b8e8 <fwp_main_thread+0xc18>
    b8b0:	0f b6 0a             	movzbl (%rdx),%ecx
    b8b3:	80 f9 02             	cmp    $0x2,%cl
    b8b6:	0f 84 89 01 00 00    	je     ba45 <fwp_main_thread+0xd75>
    b8bc:	80 f9 01             	cmp    $0x1,%cl
    b8bf:	75 27                	jne    b8e8 <fwp_main_thread+0xc18>
    b8c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8c4:	0f b7 c0             	movzwl %ax,%eax
    b8c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8ca:	48 0f af c1          	imul   %rcx,%rax
    b8ce:	48 c1 e8 20          	shr    $0x20,%rax
    b8d2:	48 39 d0             	cmp    %rdx,%rax
    b8d5:	73 11                	jae    b8e8 <fwp_main_thread+0xc18>
    b8d7:	49 01 c6             	add    %rax,%r14
    b8da:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b8de:	0f 84 f4 01 00 00    	je     bad8 <fwp_main_thread+0xe08>
    b8e4:	41 c6 06 01          	movb   $0x1,(%r14)
    b8e8:	4c 89 ef             	mov    %r13,%rdi
    b8eb:	e8 30 af ff ff       	call   6820 <fwp_drop0>
    b8f0:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    b8f4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    b8f9:	be 01 00 00 00       	mov    $0x1,%esi
    b8fe:	48 8b 0d 1b 6b 01 00 	mov    0x16b1b(%rip),%rcx        # 22420 <fwp_prog_out>
    b905:	e8 76 7d ff ff       	call   3680 <fwrite@plt>
    b90a:	48 8b 35 0f 6b 01 00 	mov    0x16b0f(%rip),%rsi        # 22420 <fwp_prog_out>
    b911:	bf 0a 00 00 00       	mov    $0xa,%edi
    b916:	e8 c5 7b ff ff       	call   34e0 <fputc@plt>
    b91b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b922:	48 89 e8             	mov    %rbp,%rax
    b925:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b92c:	48 c1 e2 10          	shl    $0x10,%rdx
    b930:	48 39 d0             	cmp    %rdx,%rax
    b933:	73 6b                	jae    b9a0 <fwp_main_thread+0xcd0>
    b935:	48 89 c2             	mov    %rax,%rdx
    b938:	48 c1 ea 10          	shr    $0x10,%rdx
    b93c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b940:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b947:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b94b:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b94f:	4d 85 f6             	test   %r14,%r14
    b952:	74 4c                	je     b9a0 <fwp_main_thread+0xcd0>
    b954:	0f b6 0a             	movzbl (%rdx),%ecx
    b957:	80 f9 02             	cmp    $0x2,%cl
    b95a:	0f 84 d7 00 00 00    	je     ba37 <fwp_main_thread+0xd67>
    b960:	80 f9 01             	cmp    $0x1,%cl
    b963:	75 3b                	jne    b9a0 <fwp_main_thread+0xcd0>
    b965:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b968:	0f b7 c0             	movzwl %ax,%eax
    b96b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b96e:	48 0f af c1          	imul   %rcx,%rax
    b972:	48 c1 e8 20          	shr    $0x20,%rax
    b976:	48 39 d0             	cmp    %rdx,%rax
    b979:	73 25                	jae    b9a0 <fwp_main_thread+0xcd0>
    b97b:	49 01 c6             	add    %rax,%r14
    b97e:	41 0f b6 06          	movzbl (%r14),%eax
    b982:	84 c0                	test   %al,%al
    b984:	74 1a                	je     b9a0 <fwp_main_thread+0xcd0>
    b986:	3c 01                	cmp    $0x1,%al
    b988:	0f 84 0c 01 00 00    	je     ba9a <fwp_main_thread+0xdca>
    b98e:	3c ff                	cmp    $0xff,%al
    b990:	0f 84 4f 01 00 00    	je     bae5 <fwp_main_thread+0xe15>
    b996:	83 e8 01             	sub    $0x1,%eax
    b999:	41 88 06             	mov    %al,(%r14)
    b99c:	0f 1f 40 00          	nopl   0x0(%rax)
    b9a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    b9a5:	48 8b 40 10          	mov    0x10(%rax),%rax
    b9a9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b9ae:	48 85 c0             	test   %rax,%rax
    b9b1:	0f 84 b9 00 00 00    	je     ba70 <fwp_main_thread+0xda0>
    b9b7:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    b9be:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b9c5:	e9 b9 fd ff ff       	jmp    b783 <fwp_main_thread+0xab3>
    b9ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b9d0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b9d4:	e9 d7 f4 ff ff       	jmp    aeb0 <fwp_main_thread+0x1e0>
    b9d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b9e0:	66 85 c0             	test   %ax,%ax
    b9e3:	0f 85 06 fe ff ff    	jne    b7ef <fwp_main_thread+0xb1f>
    b9e9:	e9 ed fd ff ff       	jmp    b7db <fwp_main_thread+0xb0b>
    b9ee:	66 90                	xchg   %ax,%ax
    b9f0:	66 85 c0             	test   %ax,%ax
    b9f3:	0f 85 45 fc ff ff    	jne    b63e <fwp_main_thread+0x96e>
    b9f9:	e9 30 fc ff ff       	jmp    b62e <fwp_main_thread+0x95e>
    b9fe:	66 90                	xchg   %ax,%ax
    ba00:	66 85 c0             	test   %ax,%ax
    ba03:	0f 85 75 fd ff ff    	jne    b77e <fwp_main_thread+0xaae>
    ba09:	e9 54 fd ff ff       	jmp    b762 <fwp_main_thread+0xa92>
    ba0e:	66 90                	xchg   %ax,%ax
    ba10:	66 85 c0             	test   %ax,%ax
    ba13:	0f 85 bb fc ff ff    	jne    b6d4 <fwp_main_thread+0xa04>
    ba19:	e9 a6 fc ff ff       	jmp    b6c4 <fwp_main_thread+0x9f4>
    ba1e:	66 90                	xchg   %ax,%ax
    ba20:	48 89 d7             	mov    %rdx,%rdi
    ba23:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    ba28:	e8 23 9b ff ff       	call   5550 <fwp_rc_forget_slot>
    ba2d:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    ba32:	e9 a4 fa ff ff       	jmp    b4db <fwp_main_thread+0x80b>
    ba37:	66 85 c0             	test   %ax,%ax
    ba3a:	0f 85 60 ff ff ff    	jne    b9a0 <fwp_main_thread+0xcd0>
    ba40:	e9 39 ff ff ff       	jmp    b97e <fwp_main_thread+0xcae>
    ba45:	66 85 c0             	test   %ax,%ax
    ba48:	0f 85 9a fe ff ff    	jne    b8e8 <fwp_main_thread+0xc18>
    ba4e:	e9 87 fe ff ff       	jmp    b8da <fwp_main_thread+0xc0a>
    ba53:	48 83 3d 3d 4d 01 00 	cmpq   $0x0,0x14d3d(%rip)        # 20798 <fwp_root>
    ba5a:	00 
    ba5b:	c7 05 1b 46 01 00 00 	movl   $0x0,0x1461b(%rip)        # 20080 <fwp_exit_code>
    ba62:	00 00 00 
    ba65:	0f 84 4d f7 ff ff    	je     b1b8 <fwp_main_thread+0x4e8>
    ba6b:	e9 e0 7c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ba70:	4c 89 ef             	mov    %r13,%rdi
    ba73:	e8 a8 ad ff ff       	call   6820 <fwp_drop0>
    ba78:	4c 89 e7             	mov    %r12,%rdi
    ba7b:	e8 a0 ad ff ff       	call   6820 <fwp_drop0>
    ba80:	48 c7 05 dd 45 00 00 	movq   $0x0,0x45dd(%rip)        # 10068 <v.2>
    ba87:	00 00 00 00 
    ba8b:	c7 05 db 45 00 00 01 	movl   $0x1,0x45db(%rip)        # 10070 <st.3>
    ba92:	00 00 00 
    ba95:	e9 62 f3 ff ff       	jmp    adfc <fwp_main_thread+0x12c>
    ba9a:	48 89 ef             	mov    %rbp,%rdi
    ba9d:	e8 6e ac ff ff       	call   6710 <fwp_rc_free_arr>
    baa2:	e9 f9 fe ff ff       	jmp    b9a0 <fwp_main_thread+0xcd0>
    baa7:	4c 89 ef             	mov    %r13,%rdi
    baaa:	e8 a1 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    baaf:	e9 85 fb ff ff       	jmp    b639 <fwp_main_thread+0x969>
    bab4:	4c 89 ef             	mov    %r13,%rdi
    bab7:	e8 94 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    babc:	e9 0e fc ff ff       	jmp    b6cf <fwp_main_thread+0x9ff>
    bac1:	4c 89 f7             	mov    %r14,%rdi
    bac4:	e8 87 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    bac9:	e9 9e fc ff ff       	jmp    b76c <fwp_main_thread+0xa9c>
    bace:	e8 5d 99 ff ff       	call   5430 <fwp_rc_wide_dup>
    bad3:	e9 17 fd ff ff       	jmp    b7ef <fwp_main_thread+0xb1f>
    bad8:	4c 89 f7             	mov    %r14,%rdi
    badb:	e8 70 9a ff ff       	call   5550 <fwp_rc_forget_slot>
    bae0:	e9 ff fd ff ff       	jmp    b8e4 <fwp_main_thread+0xc14>
    bae5:	4c 89 f0             	mov    %r14,%rax
    bae8:	48 c1 e8 11          	shr    $0x11,%rax
    baec:	4c 31 f0             	xor    %r14,%rax
    baef:	48 89 c2             	mov    %rax,%rdx
    baf2:	48 c1 ea 09          	shr    $0x9,%rdx
    baf6:	48 31 d0             	xor    %rdx,%rax
    baf9:	0f b6 d0             	movzbl %al,%edx
    bafc:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    bb03:	00 
    bb04:	48 85 c0             	test   %rax,%rax
    bb07:	75 20                	jne    bb29 <fwp_main_thread+0xe59>
    bb09:	eb 61                	jmp    bb6c <fwp_main_thread+0xe9c>
    bb0b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bb12:	00 00 00 
    bb15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bb1c:	00 00 00 00 
    bb20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bb24:	48 85 c0             	test   %rax,%rax
    bb27:	74 43                	je     bb6c <fwp_main_thread+0xe9c>
    bb29:	48 89 c2             	mov    %rax,%rdx
    bb2c:	4c 3b 30             	cmp    (%rax),%r14
    bb2f:	75 ef                	jne    bb20 <fwp_main_thread+0xe50>
    bb31:	48 8b 48 08          	mov    0x8(%rax),%rcx
    bb35:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    bb39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bb3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bb44:	0f 85 56 fe ff ff    	jne    b9a0 <fwp_main_thread+0xcd0>
    bb4a:	4c 89 f7             	mov    %r14,%rdi
    bb4d:	e8 fe 99 ff ff       	call   5550 <fwp_rc_forget_slot>
    bb52:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bb56:	e9 45 fe ff ff       	jmp    b9a0 <fwp_main_thread+0xcd0>
    bb5b:	48 8d 3d 7e 0e 00 00 	lea    0xe7e(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    bb62:	e8 89 88 ff ff       	call   43f0 <fwp_trap>
    bb67:	e8 44 81 ff ff       	call   3cb0 <fwp_heap_oom>
    bb6c:	48 8d 3d 15 0d 00 00 	lea    0xd15(%rip),%rdi        # c888 <_IO_stdin_used+0x888>
    bb73:	e8 78 88 ff ff       	call   43f0 <fwp_trap>
    bb78:	e8 63 82 ff ff       	call   3de0 <descent_phase_fail>
    bb7d:	e8 de 78 ff ff       	call   3460 <__stack_chk_fail@plt>
    bb82:	48 8d 3d bd 06 00 00 	lea    0x6bd(%rip),%rdi        # c246 <_IO_stdin_used+0x246>
    bb89:	e8 62 88 ff ff       	call   43f0 <fwp_trap>
    bb8e:	e9 bd 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bb93:	e9 b8 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bb98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bb9f:	00 

000000000000bba0 <__divmodti4>:
    bba0:	f3 0f 1e fa          	endbr64
    bba4:	55                   	push   %rbp
    bba5:	49 89 f1             	mov    %rsi,%r9
    bba8:	49 89 d2             	mov    %rdx,%r10
    bbab:	48 89 fe             	mov    %rdi,%rsi
    bbae:	49 89 cb             	mov    %rcx,%r11
    bbb1:	48 89 e5             	mov    %rsp,%rbp
    bbb4:	41 57                	push   %r15
    bbb6:	41 56                	push   %r14
    bbb8:	41 55                	push   %r13
    bbba:	41 54                	push   %r12
    bbbc:	53                   	push   %rbx
    bbbd:	4c 89 c3             	mov    %r8,%rbx
    bbc0:	45 31 c0             	xor    %r8d,%r8d
    bbc3:	4d 85 c9             	test   %r9,%r9
    bbc6:	79 12                	jns    bbda <__divmodti4+0x3a>
    bbc8:	31 ff                	xor    %edi,%edi
    bbca:	48 f7 de             	neg    %rsi
    bbcd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bbd4:	4c 19 cf             	sbb    %r9,%rdi
    bbd7:	49 89 f9             	mov    %rdi,%r9
    bbda:	4c 89 d8             	mov    %r11,%rax
    bbdd:	4d 85 db             	test   %r11,%r11
    bbe0:	0f 88 1a 01 00 00    	js     bd00 <__divmodti4+0x160>
    bbe6:	4c 89 d9             	mov    %r11,%rcx
    bbe9:	49 89 f3             	mov    %rsi,%r11
    bbec:	75 62                	jne    bc50 <__divmodti4+0xb0>
    bbee:	4d 89 c4             	mov    %r8,%r12
    bbf1:	4d 39 d1             	cmp    %r10,%r9
    bbf4:	0f 83 46 01 00 00    	jae    bd40 <__divmodti4+0x1a0>
    bbfa:	4c 89 d8             	mov    %r11,%rax
    bbfd:	4c 89 ca             	mov    %r9,%rdx
    bc00:	49 f7 f2             	div    %r10
    bc03:	49 89 c3             	mov    %rax,%r11
    bc06:	31 c0                	xor    %eax,%eax
    bc08:	48 89 d6             	mov    %rdx,%rsi
    bc0b:	31 ff                	xor    %edi,%edi
    bc0d:	4c 89 d9             	mov    %r11,%rcx
    bc10:	48 89 c2             	mov    %rax,%rdx
    bc13:	48 89 c8             	mov    %rcx,%rax
    bc16:	4d 85 e4             	test   %r12,%r12
    bc19:	74 0a                	je     bc25 <__divmodti4+0x85>
    bc1b:	48 f7 d8             	neg    %rax
    bc1e:	48 83 d2 00          	adc    $0x0,%rdx
    bc22:	48 f7 da             	neg    %rdx
    bc25:	4d 85 c0             	test   %r8,%r8
    bc28:	74 0a                	je     bc34 <__divmodti4+0x94>
    bc2a:	48 f7 de             	neg    %rsi
    bc2d:	48 83 d7 00          	adc    $0x0,%rdi
    bc31:	48 f7 df             	neg    %rdi
    bc34:	48 89 33             	mov    %rsi,(%rbx)
    bc37:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bc3b:	5b                   	pop    %rbx
    bc3c:	41 5c                	pop    %r12
    bc3e:	41 5d                	pop    %r13
    bc40:	41 5e                	pop    %r14
    bc42:	41 5f                	pop    %r15
    bc44:	5d                   	pop    %rbp
    bc45:	c3                   	ret
    bc46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc4d:	00 00 00 
    bc50:	4d 89 c4             	mov    %r8,%r12
    bc53:	49 39 c1             	cmp    %rax,%r9
    bc56:	0f 82 ce 00 00 00    	jb     bd2a <__divmodti4+0x18a>
    bc5c:	31 ff                	xor    %edi,%edi
    bc5e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bc63:	48 63 c7             	movslq %edi,%rax
    bc66:	be 40 00 00 00       	mov    $0x40,%esi
    bc6b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bc70:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bc75:	48 29 c6             	sub    %rax,%rsi
    bc78:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bc7d:	48 09 c8             	or     %rcx,%rax
    bc80:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bc85:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bc8a:	49 89 c6             	mov    %rax,%r14
    bc8d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bc91:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bc96:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bc9b:	49 09 c1             	or     %rax,%r9
    bc9e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bca2:	4c 89 c8             	mov    %r9,%rax
    bca5:	49 f7 f6             	div    %r14
    bca8:	48 89 d1             	mov    %rdx,%rcx
    bcab:	49 89 c3             	mov    %rax,%r11
    bcae:	49 89 c1             	mov    %rax,%r9
    bcb1:	49 f7 e2             	mul    %r10
    bcb4:	49 89 c6             	mov    %rax,%r14
    bcb7:	49 89 d2             	mov    %rdx,%r10
    bcba:	48 39 d1             	cmp    %rdx,%rcx
    bcbd:	72 07                	jb     bcc6 <__divmodti4+0x126>
    bcbf:	75 17                	jne    bcd8 <__divmodti4+0x138>
    bcc1:	49 39 c7             	cmp    %rax,%r15
    bcc4:	73 12                	jae    bcd8 <__divmodti4+0x138>
    bcc6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bcca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bcce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bcd2:	49 89 d2             	mov    %rdx,%r10
    bcd5:	49 89 c6             	mov    %rax,%r14
    bcd8:	4c 89 f8             	mov    %r15,%rax
    bcdb:	4c 29 f0             	sub    %r14,%rax
    bcde:	4c 19 d1             	sbb    %r10,%rcx
    bce1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bce6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bceb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bcf0:	48 09 c6             	or     %rax,%rsi
    bcf3:	48 89 cf             	mov    %rcx,%rdi
    bcf6:	31 c0                	xor    %eax,%eax
    bcf8:	4c 89 c9             	mov    %r9,%rcx
    bcfb:	e9 10 ff ff ff       	jmp    bc10 <__divmodti4+0x70>
    bd00:	4c 89 d0             	mov    %r10,%rax
    bd03:	4c 89 da             	mov    %r11,%rdx
    bd06:	4d 89 c4             	mov    %r8,%r12
    bd09:	49 89 f3             	mov    %rsi,%r11
    bd0c:	48 f7 d8             	neg    %rax
    bd0f:	49 f7 d4             	not    %r12
    bd12:	48 83 d2 00          	adc    $0x0,%rdx
    bd16:	49 89 c2             	mov    %rax,%r10
    bd19:	48 f7 da             	neg    %rdx
    bd1c:	48 89 d1             	mov    %rdx,%rcx
    bd1f:	0f 84 cc fe ff ff    	je     bbf1 <__divmodti4+0x51>
    bd25:	49 39 d1             	cmp    %rdx,%r9
    bd28:	73 46                	jae    bd70 <__divmodti4+0x1d0>
    bd2a:	4c 89 cf             	mov    %r9,%rdi
    bd2d:	31 c0                	xor    %eax,%eax
    bd2f:	31 c9                	xor    %ecx,%ecx
    bd31:	e9 da fe ff ff       	jmp    bc10 <__divmodti4+0x70>
    bd36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd3d:	00 00 00 
    bd40:	4d 85 d2             	test   %r10,%r10
    bd43:	75 0d                	jne    bd52 <__divmodti4+0x1b2>
    bd45:	b8 01 00 00 00       	mov    $0x1,%eax
    bd4a:	31 d2                	xor    %edx,%edx
    bd4c:	49 f7 f2             	div    %r10
    bd4f:	49 89 c2             	mov    %rax,%r10
    bd52:	4c 89 c8             	mov    %r9,%rax
    bd55:	31 d2                	xor    %edx,%edx
    bd57:	49 f7 f2             	div    %r10
    bd5a:	49 89 c1             	mov    %rax,%r9
    bd5d:	4c 89 d8             	mov    %r11,%rax
    bd60:	49 f7 f2             	div    %r10
    bd63:	49 89 c3             	mov    %rax,%r11
    bd66:	4c 89 c8             	mov    %r9,%rax
    bd69:	e9 9a fe ff ff       	jmp    bc08 <__divmodti4+0x68>
    bd6e:	66 90                	xchg   %ax,%ax
    bd70:	45 31 f6             	xor    %r14d,%r14d
    bd73:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bd78:	44 89 f7             	mov    %r14d,%edi
    bd7b:	45 85 f6             	test   %r14d,%r14d
    bd7e:	0f 85 df fe ff ff    	jne    bc63 <__divmodti4+0xc3>
    bd84:	4c 39 ca             	cmp    %r9,%rdx
    bd87:	72 17                	jb     bda0 <__divmodti4+0x200>
    bd89:	31 c9                	xor    %ecx,%ecx
    bd8b:	48 39 c6             	cmp    %rax,%rsi
    bd8e:	73 10                	jae    bda0 <__divmodti4+0x200>
    bd90:	4c 89 cf             	mov    %r9,%rdi
    bd93:	31 c0                	xor    %eax,%eax
    bd95:	e9 76 fe ff ff       	jmp    bc10 <__divmodti4+0x70>
    bd9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bda0:	4c 89 de             	mov    %r11,%rsi
    bda3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bda8:	48 29 c6             	sub    %rax,%rsi
    bdab:	49 19 d1             	sbb    %rdx,%r9
    bdae:	eb e0                	jmp    bd90 <__divmodti4+0x1f0>

000000000000bdb0 <atexit>:
    bdb0:	f3 0f 1e fa          	endbr64
    bdb4:	48 8b 15 4d 42 00 00 	mov    0x424d(%rip),%rdx        # 10008 <__dso_handle>
    bdbb:	31 f6                	xor    %esi,%esi
    bdbd:	e9 9e 78 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bdc4 <_fini>:
    bdc4:	f3 0f 1e fa          	endbr64
    bdc8:	48 83 ec 08          	sub    $0x8,%rsp
    bdcc:	48 83 c4 08          	add    $0x8,%rsp
    bdd0:	c3                   	ret
