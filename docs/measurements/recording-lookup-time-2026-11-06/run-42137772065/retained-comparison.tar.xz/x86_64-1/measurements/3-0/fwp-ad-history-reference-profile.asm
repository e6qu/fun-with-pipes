
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ad 00 00 	lea    0xad01(%rip),%rax        # e480 <fwp_fn_table>
    377f:	48 89 05 f2 6c 06 00 	mov    %rax,0x66cf2(%rip)        # 6a478 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 6c 06 00 	mov    %rax,0x66cec(%rip)        # 6a480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 2f 75 00 00 	lea    0x752f(%rip),%rdx        # ad90 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 93 00 00 	lea    0x9346(%rip),%rdi        # cc50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 93 00 00 	lea    0x9300(%rip),%rdi        # cc28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 92 00 00 	lea    0x92c4(%rip),%rdi        # cbf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 92 00 00 	lea    0x9290(%rip),%rdi        # cbd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 c5 04 00 	lea    0x4c597(%rip),%r8        # 501a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b c5 04 00 	lea    0x4c53b(%rip),%rcx        # 50160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f c5 04 00 	lea    0x4c50f(%rip),%rcx        # 50140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 c5 04 00 	lea    0x4c541(%rip),%rcx        # 50180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 c5 04 	movdqa 0x4c550(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 c5 04 	paddq  0x4c538(%rip),%xmm0        # 501a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f c4 04 00 	cmp    %rax,0x4c49f(%rip)        # 50120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 c4 04 	movq   %xmm0,0x4c495(%rip)        # 50120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e c4 01 00 	add    0x1c43e(%rip),%rdx        # 200f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c c4 01 00 	add    0x1c42c(%rip),%rax        # 200f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 67 06 00 	mov    0x66779(%rip),%rdi        # 6a480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 4a 06 00 	mov    0x64ab1(%rip),%rax        # 68800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 43 06 00 	mov    0x643f9(%rip),%rax        # 681c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 43 06 00 	sub    0x643e5(%rip),%rax        # 681c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d 8f 00 00 	lea    0x8f1d(%rip),%rsi        # cd30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 5d 06 00 	mov    0x65d8b(%rip),%rax        # 69c10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 5d 06 00 	lea    0x65d84(%rip),%r8        # 69c10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 5d 06 00 	mov    0x65d65(%rip),%rbx        # 69bf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 5d 06 00 	mov    0x65d75(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 5d 06 00 	mov    0x65d11(%rip),%rdi        # 69c00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 5d 06 00 	sub    %rsi,0x65d5a(%rip)        # 69c50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 5c 06 00 	mov    0x65cea(%rip),%rax        # 69bf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 5c 06 00 	add    0x65ca0(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 5c 06 00 	mov    0x65cae(%rip),%rsi        # 69c00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 5c 06 00 	mov    0x65cbc(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 5c 06 00 	mov    %r12,0x65c6b(%rip)        # 69c00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 5c 06 00 	mov    %rbp,0x65c59(%rip)        # 69bf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 5c 06 00 	cmp    %rdi,0x65c3e(%rip)        # 69be8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 5c 06 00 	mov    %rdi,0x65c35(%rip)        # 69be8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 5c 06 00 	sub    %rdi,0x65c79(%rip)        # 69c50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 5c 06 00 	mov    0x65c21(%rip),%rax        # 69c08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 5c 06 00 	lea    0x65c1a(%rip),%r8        # 69c08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef 86 00 00 	lea    0x86ef(%rip),%rdx        # c6f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 46 06 00 	cmp    0x646c9(%rip),%rdi        # 68800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 46 06 00 	mov    0x6468f(%rip),%rax        # 687e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 46 06 00 	mov    %rdi,0x6466d(%rip)        # 687e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 46 06 00 	mov    %rdi,0x64649(%rip)        # 687e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f 80 00 00 	lea    0x805f(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 bf 04 	movdqa 0x4bf76(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e bf 04 	paddq  0x4bf5e(%rip),%xmm0        # 501a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 be 01 00 	mov    0x1be84(%rip),%r8        # 200f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e be 04 00 	mov    0x4be9e(%rip),%rcx        # 50120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 84 00 00 	lea    0x84b5(%rip),%rdx        # c748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 be 04 00 	lea    0x4bee1(%rip),%r15        # 50180 <ad_raw_peak>
    429f:	4c 8d 35 9a be 04 00 	lea    0x4be9a(%rip),%r14        # 50140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f be 04 00 	lea    0x4be9f(%rip),%r13        # 50160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d 84 00 00 	lea    0x848d(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 bd 01 00 	cmpq   $0x0,0x1bda6(%rip)        # 20100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd bd 01 00 	mov    0x1bdbd(%rip),%r8        # 20120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be bd 01 00 	mov    0x1bdbe(%rip),%r9        # 20128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af bd 01 00 	lea    0x1bdaf(%rip),%rbx        # 20120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 bd 01 00 	mov    0x1bdb1(%rip),%rax        # 20130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 84 00 00 	lea    0x8429(%rip),%rdx        # c7e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 bd 01 00 	cmp    0x1bd33(%rip),%rbp        # 20100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 83 00 00 	lea    0x8384(%rip),%rdx        # c7a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da 82 00 00 	lea    0x82da(%rip),%rdi        # c720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 81 00 00 	lea    0x81d8(%rip),%rdi        # c828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 86 00 	movdqa 0x86e0(%rip),%xmm0        # cd50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 5d 06 00 	add    0x65daa(%rip),%rax        # 6a478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c 81 00 00 	lea    0x812c(%rip),%rdi        # c850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 b9 01 00 	cmp    %rax,0x1b9a5(%rip)        # 200e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 b9 01 00 	add    0x1b9a0(%rip),%rax        # 200f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 81 00 00 	lea    0x8115(%rip),%rdi        # c880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a 75 00 00 	lea    0x759a(%rip),%rsi        # c288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 4e 06 00 	mov    0x64e85(%rip),%r9        # 69be8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 4e 06 00 	mov    0x64ede(%rip),%r8        # 69c48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f 7b 00 00 	lea    0x7b5f(%rip),%rdx        # c8d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 4e 06 00 	mov    0x64ec6(%rip),%rcx        # 69c40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 4e 06 	movsd  0x64ed4(%rip),%xmm1        # 69c60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 4e 06 	movsd  0x64ec4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 7f 00 	movdqa 0x7f88(%rip),%xmm0        # cd60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 49 06 00 	lea    0x6497f(%rip),%rax        # 69760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 7f 00 	movdqa 0x7fb1(%rip),%xmm2        # cda0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 49 06 00 	movaps %xmm0,0x64925(%rip)        # 69720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d 7f 00 	movdqa 0x7f6d(%rip),%xmm0        # cd70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 4d 06 00 01 	movl   $0x1,0x64db3(%rip)        # 69bc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 49 06 00 	movaps %xmm0,0x64913(%rip)        # 69730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b 7f 00 	movdqa 0x7f5b(%rip),%xmm0        # cd80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 14 49 06 00 	movaps %xmm0,0x64914(%rip)        # 69740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c 7f 00 	movdqa 0x7f5c(%rip),%xmm0        # cd90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 15 49 06 00 	movaps %xmm0,0x64915(%rip)        # 69750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 39 06 00 	lea    0x63995(%rip),%r8        # 68820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 4c 06 00 	mov    %rax,0x64cb0(%rip)        # 69bd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 4c 06 00 	mov    %r12,0x64c8e(%rip)        # 69be0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 4c 06 00 	mov    %rax,0x64c77(%rip)        # 69bd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 4c 06 00 	mov    %rbx,0x64c90(%rip)        # 69bf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 4c 06 00 	mov    %rsi,0x64cb9(%rip)        # 69c20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 4c 06 00 	mov    %rax,0x64c98(%rip)        # 69c18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 4c 06 00    	mov    %eax,0x64c1c(%rip)        # 69bc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 38 06 00 	mov    0x6380c(%rip),%r8        # 687e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 37 06 00 	mov    %rbx,0x6373c(%rip)        # 687e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 37 06 00 	mov    %r8,0x63728(%rip)        # 687e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 b0 04 00 	lea    0x4b0e9(%rip),%rcx        # 501c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 b0 04 00 	lea    0x4b098(%rip),%rcx        # 501a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 6f 00 00 	lea    0x6fc2(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 b0 04 00 	lea    0x4b016(%rip),%r12        # 501c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 6e 00 00 	lea    0x6ee8(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 6e 00 00 	lea    0x6ecc(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 6f 00 00 	lea    0x6f04(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 6e 00 00 	lea    0x6edd(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 6e 00 00 	lea    0x6eaa(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae ad 01 00 	lea    0x1adae(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 ad 01 00 	movaps %xmm0,0x1ad96(%rip)        # 200a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 ad 01 00 	mov    %rsi,0x1ad72(%rip)        # 20088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 ad 01 00 	movaps %xmm0,0x1ad93(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 ad 01 00 	movaps %xmm0,0x1ad97(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 ad 01 00 	mov    %rax,0x1ad98(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 6e 00 00 	lea    0x6e09(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d ad 01 00 	mov    0x1ad1d(%rip),%rsi        # 20088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d ad 01 00 	imul   $0x68,0x1ad6d(%rip),%rdx        # 200e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 ae 04 00 	cmp    0x4ae26(%rip),%rdx        # 501a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 ae 04 00 	mov    0x4ae25(%rip),%rax        # 501a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f ae 04 00 	add    0x4ae1f(%rip),%rax        # 501b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 ae 04 00 	add    0x4ae20(%rip),%rax        # 501b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c ad 01 00 	mov    0x1ad5c(%rip),%rcx        # 20100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 ad 01 00 	mov    %rdi,0x1ad45(%rip)        # 20100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 ad 01 00 	lea    0x1ad57(%rip),%rcx        # 20120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 75 00 00 	lea    0x7562(%rip),%rdi        # c958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 6d 00 00 	lea    0x6d6f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 33 06 00 	mov    0x633a7(%rip),%rbx        # 687d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a ab 00 00 	mov    0xab0a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b 74 00 00 	lea    0x744b(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 32 06 00 	mov    0x6326d(%rip),%rax        # 687e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 32 06 00 	mov    %rdx,0x63247(%rip)        # 687e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 31 06 00 	mov    0x63194(%rip),%rbx        # 687d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 31 06 00 	mov    %rbx,0x63151(%rip)        # 687d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 31 06 00 	mov    %rdx,0x63151(%rip)        # 687e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 31 06 00 	lea    0x63166(%rip),%rsi        # 68820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 4c 06 00 	addq   $0x1,0x64ce5(%rip)        # 6a468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f 72 00 00 	lea    0x721f(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 72 00 00 	lea    0x7230(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 69 00 00 	lea    0x69d2(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 30 06 00 	lea    0x6301e(%rip),%rcx        # 68820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 4c 06 00 	subq   $0x1,0x64c1f(%rip)        # 6a468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b 71 00 00 	lea    0x718b(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 4c 06 00 	cmpq   $0x0,0x64c00(%rip)        # 6a468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 4b 06 00 	sub    %rax,0x64b55(%rip)        # 6a470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 4b 06 00 	add    %r12,0x64b33(%rip)        # 6a470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 42 06 00 	mov    0x6428f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 2e 06 00 	lea    0x62e8c(%rip),%rax        # 68820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 41 06 00 	add    0x641e3(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 41 06 00 	mov    0x641b0(%rip),%rsi        # 69bd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 41 06 00 	mov    0x641d1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 41 06 00 	add    0x641c5(%rip),%r8        # 69c18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 41 06 	addsd  0x6418d(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 2d 06 00 	lea    0x62d42(%rip),%rax        # 68820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 41 06 00 	sub    %rdi,0x6414c(%rip)        # 69c40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 41 06 	movsd  %xmm0,0x64164(%rip)        # 69c60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 41 06 00 	sub    %rdx,0x6411e(%rip)        # 69c40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 41 06 	addsd  0x64124(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 41 06 	movsd  %xmm0,0x64118(%rip)        # 69c60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 40 06 00 	mov    0x640af(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 40 06 00 	add    %rcx,0x640a9(%rip)        # 69c50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 40 06 00 	cmp    0x64062(%rip),%r9        # 69c10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 40 06 00 	mov    %r9,0x64059(%rip)        # 69c10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 40 06 00 	cmp    0x6404a(%rip),%r9        # 69c08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 40 06 00 	mov    %r9,0x6403d(%rip)        # 69c08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 3f 06 00 	add    0x63f53(%rip),%rdi        # 69c18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 2b 06 00 	lea    0x62b30(%rip),%r15        # 68820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 3e 06 00 	add    0x63ea0(%rip),%r12        # 69bd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 3e 06 00 	add    0x63ef9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 3e 06 00 	cmp    %rax,0x63ef8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 3e 06 00 	mov    %rax,0x63ee9(%rip)        # 69c40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 3e 06 00 	mov    %rax,0x63ee8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 3e 06 	addsd  0x63ee4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 3e 06 	movsd  %xmm0,0x63edc(%rip)        # 69c58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 3e 06 00    	mov    0x63e23(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 2a 06 00 	lea    0x62a5f(%rip),%rdi        # 68820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 3e 06 00 	add    0x63e18(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 3e 06 00 	cmp    %rax,0x63e13(%rip)        # 69c48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 3e 06 00 	mov    %rax,0x63e04(%rip)        # 69c40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 3e 06 00 	mov    %rax,0x63e03(%rip)        # 69c48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 3d 06 	addsd  0x63dff(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 3d 06 	movsd  %xmm0,0x63df7(%rip)        # 69c58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 45 06 00    	mov    0x645ca(%rip),%ebx        # 6a4e8 <iteration_active>
    5f1e:	8b 05 a0 3c 06 00    	mov    0x63ca0(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 28 06 00 	lea    0x628d4(%rip),%rax        # 68820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 3c 06 00 	add    0x63c8e(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 3c 06 00 	cmp    %rax,0x63c89(%rip)        # 69c48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 3c 06 00 	mov    %rax,0x63c7a(%rip)        # 69c40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 3c 06 00 	mov    %rax,0x63c79(%rip)        # 69c48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 3c 06 	addsd  0x63c78(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 3c 06 	movsd  %xmm0,0x63c70(%rip)        # 69c58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 3c 06 00 	mov    0x63c4d(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 44 06 	subsd  0x644bb(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 44 06 	comisd 0x644ab(%rip),%xmm0        # 6a4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 44 06 	movsd  %xmm0,0x644a1(%rip)        # 6a4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 44 06 00 	addq   $0x1,0x644a4(%rip)        # 6a4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 44 06 00 	add    %rdi,0x64495(%rip)        # 6a4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 3c 43 06 00 	add    0x6433c(%rip),%r9        # 6a478 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push.constprop.0>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push.constprop.0+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push.constprop.0+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 79 01 00 00    	jns    6500 <fwp_p_ad_push.constprop.0+0x1b0>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push.constprop.0+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 f7 02 00 00    	jne    66c4 <fwp_p_ad_push.constprop.0+0x374>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 49 02 00 00    	jg     6627 <fwp_p_ad_push.constprop.0+0x2d7>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	49 39 c7             	cmp    %rax,%r15
    63e4:	0f 8e 49 02 00 00    	jle    6633 <fwp_p_ad_push.constprop.0+0x2e3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push.constprop.0+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	49 39 c7             	cmp    %rax,%r15
    63f5:	0f 8e 38 02 00 00    	jle    6633 <fwp_p_ad_push.constprop.0+0x2e3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 15 02 00 00    	ja     6627 <fwp_p_ad_push.constprop.0+0x2d7>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push.constprop.0+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push.constprop.0+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push.constprop.0+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push.constprop.0+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 22 ed ff ff       	call   5190 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 c8 01 00 00    	je     663f <fwp_p_ad_push.constprop.0+0x2ef>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 e9             	mov    %rbp,%rcx
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e1 04          	shl    $0x4,%rcx
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	48 89 ce             	mov    %rcx,%rsi
    6491:	ba 02 00 00 00       	mov    $0x2,%edx
    6496:	48 89 43 28          	mov    %rax,0x28(%rbx)
    649a:	e8 f1 ec ff ff       	call   5190 <ad_raw_realloc>
    649f:	48 85 c0             	test   %rax,%rax
    64a2:	0f 84 97 01 00 00    	je     663f <fwp_p_ad_push.constprop.0+0x2ef>
    64a8:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64ac:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64b0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b7:	00 
    64b8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bf:	00 
    64c0:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c7:	00 
    64c8:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64cc:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64d1:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d5:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d9:	4d 85 f6             	test   %r14,%r14
    64dc:	0f 85 e6 00 00 00    	jne    65c8 <fwp_p_ad_push.constprop.0+0x278>
    64e2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e6:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64ea:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64ee:	48 01 d1             	add    %rdx,%rcx
    64f1:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f5:	eb 79                	jmp    6570 <fwp_p_ad_push.constprop.0+0x220>
    64f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    64fe:	00 00 
    6500:	48 89 d0             	mov    %rdx,%rax
    6503:	48 c1 ff 20          	sar    $0x20,%rdi
    6507:	48 c1 f8 20          	sar    $0x20,%rax
    650b:	48 39 c7             	cmp    %rax,%rdi
    650e:	0f 84 a3 fe ff ff    	je     63b7 <fwp_p_ad_push.constprop.0+0x67>
    6514:	48 8d 3d ed 64 00 00 	lea    0x64ed(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    651b:	e8 30 df ff ff       	call   4450 <fwp_trap>
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push.constprop.0+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	0f 1f 40 00          	nopl   0x0(%rax)
    65c8:	4c 89 ca             	mov    %r9,%rdx
    65cb:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65d0:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d5:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65da:	e8 11 d0 ff ff       	call   35f0 <memmove@plt>
    65df:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e4:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e8:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65ed:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65f1:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65fa:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fe:	4c 89 d2             	mov    %r10,%rdx
    6601:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6606:	e8 e5 cf ff ff       	call   35f0 <memmove@plt>
    660b:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660f:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6613:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6618:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    661d:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6622:	e9 bf fe ff ff       	jmp    64e6 <fwp_p_ad_push.constprop.0+0x196>
    6627:	48 8d 3d 79 5b 00 00 	lea    0x5b79(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    662e:	e8 1d de ff ff       	call   4450 <fwp_trap>
    6633:	48 8d 3d 88 5b 00 00 	lea    0x5b88(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    663a:	e8 11 de ff ff       	call   4450 <fwp_trap>
    663f:	48 89 df             	mov    %rbx,%rdi
    6642:	e8 49 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6647:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    664b:	48 85 ff             	test   %rdi,%rdi
    664e:	74 05                	je     6655 <fwp_p_ad_push.constprop.0+0x305>
    6650:	e8 7b ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6655:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6659:	48 85 ff             	test   %rdi,%rdi
    665c:	74 05                	je     6663 <fwp_p_ad_push.constprop.0+0x313>
    665e:	e8 6d ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6663:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6667:	48 85 ff             	test   %rdi,%rdi
    666a:	74 05                	je     6671 <fwp_p_ad_push.constprop.0+0x321>
    666c:	e8 5f ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6671:	31 c9                	xor    %ecx,%ecx
    6673:	31 c0                	xor    %eax,%eax
    6675:	31 d2                	xor    %edx,%edx
    6677:	be 01 00 00 00       	mov    $0x1,%esi
    667c:	89 53 04             	mov    %edx,0x4(%rbx)
    667f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6683:	ba 13 00 00 00       	mov    $0x13,%edx
    6688:	48 8d 3d 79 59 00 00 	lea    0x5979(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    668f:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6693:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6697:	48 8b 0d a2 99 00 00 	mov    0x99a2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    669e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66a2:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66a6:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66aa:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66ae:	e8 ad cf ff ff       	call   3660 <fwrite@plt>
    66b3:	31 ff                	xor    %edi,%edi
    66b5:	e8 e6 ce ff ff       	call   35a0 <fflush@plt>
    66ba:	bf 66 00 00 00       	mov    $0x66,%edi
    66bf:	e8 bc cf ff ff       	call   3680 <_Exit@plt>
    66c4:	48 8d 3d 85 63 00 00 	lea    0x6385(%rip),%rdi        # ca50 <_IO_stdin_used+0xa50>
    66cb:	e8 80 dd ff ff       	call   4450 <fwp_trap>

00000000000066d0 <w107>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66ff:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    670a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6710:	48 89 da             	mov    %rbx,%rdx
    6713:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6719:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6720:	00 f0 3f 
    6723:	48 89 c7             	mov    %rax,%rdi
    6726:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    672d:	00 f0 bf 
    6730:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6735:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673b:	e8 10 fc ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    6740:	f2 0f 10 05 98 66 00 	movsd  0x6698(%rip),%xmm0        # cde0 <msg.4+0xb0>
    6747:	00 
    6748:	4c 89 e7             	mov    %r12,%rdi
    674b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6751:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6758:	00 f0 3f 
    675b:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6762:	49 89 c5             	mov    %rax,%r13
    6765:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    676c:	00 f0 bf 
    676f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6774:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    677a:	e8 d1 fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    677f:	48 89 e9             	mov    %rbp,%rcx
    6782:	4c 89 ea             	mov    %r13,%rdx
    6785:	48 89 ee             	mov    %rbp,%rsi
    6788:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    678e:	4c 89 ef             	mov    %r13,%rdi
    6791:	49 89 c4             	mov    %rax,%r12
    6794:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6798:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    679e:	e8 ad fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    67a3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67a9:	f2 0f 59 1d 37 66 00 	mulsd  0x6637(%rip),%xmm3        # cde8 <msg.4+0xb8>
    67b0:	00 
    67b1:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67b8:	00 59 40 
    67bb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67c0:	48 89 c2             	mov    %rax,%rdx
    67c3:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67ca:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67d0:	e8 7b fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    67d5:	48 89 d9             	mov    %rbx,%rcx
    67d8:	4c 89 e2             	mov    %r12,%rdx
    67db:	48 89 de             	mov    %rbx,%rsi
    67de:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67e4:	4c 89 e7             	mov    %r12,%rdi
    67e7:	48 89 c5             	mov    %rax,%rbp
    67ea:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    67ee:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f4:	e8 57 fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    67f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67ff:	48 89 ea             	mov    %rbp,%rdx
    6802:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6808:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    680f:	00 f0 3f 
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	48 89 ce             	mov    %rcx,%rsi
    6818:	66 48 0f 7e db       	movq   %xmm3,%rbx
    681d:	e8 2e fb ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    6822:	48 83 c4 28          	add    $0x28,%rsp
    6826:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    682b:	5b                   	pop    %rbx
    682c:	5d                   	pop    %rbp
    682d:	41 5c                	pop    %r12
    682f:	41 5d                	pop    %r13
    6831:	c3                   	ret
    6832:	0f 1f 00             	nopl   (%rax)
    6835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    683c:	00 00 00 00 

0000000000006840 <w164.constprop.0>:
    6840:	41 54                	push   %r12
    6842:	55                   	push   %rbp
    6843:	53                   	push   %rbx
    6844:	48 83 ec 10          	sub    $0x10,%rsp
    6848:	4c 8b 27             	mov    (%rdi),%r12
    684b:	4d 85 e4             	test   %r12,%r12
    684e:	74 58                	je     68a8 <w164.constprop.0+0x68>
    6850:	48 89 fd             	mov    %rdi,%rbp
    6853:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6857:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    685e:	31 db                	xor    %ebx,%ebx
    6860:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6866:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    686b:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6872:	00 f0 3f 
    6875:	48 83 c3 02          	add    $0x2,%rbx
    6879:	48 89 ce             	mov    %rcx,%rsi
    687c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6882:	e8 c9 fa ff ff       	call   6350 <fwp_p_ad_push.constprop.0>
    6887:	4c 39 e3             	cmp    %r12,%rbx
    688a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6890:	48 89 c7             	mov    %rax,%rdi
    6893:	72 cb                	jb     6860 <w164.constprop.0+0x20>
    6895:	48 83 c4 10          	add    $0x10,%rsp
    6899:	48 89 f8             	mov    %rdi,%rax
    689c:	5b                   	pop    %rbx
    689d:	5d                   	pop    %rbp
    689e:	41 5c                	pop    %r12
    68a0:	c3                   	ret
    68a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68a8:	48 83 c4 10          	add    $0x10,%rsp
    68ac:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    68b7:	5b                   	pop    %rbx
    68b8:	48 89 f8             	mov    %rdi,%rax
    68bb:	5d                   	pop    %rbp
    68bc:	41 5c                	pop    %r12
    68be:	c3                   	ret
    68bf:	90                   	nop

00000000000068c0 <fwp_data.part.0.constprop.0>:
    68c0:	41 56                	push   %r14
    68c2:	8b 05 fc 32 06 00    	mov    0x632fc(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    68c8:	41 89 fe             	mov    %edi,%r14d
    68cb:	41 55                	push   %r13
    68cd:	44 8b 2d 14 3c 06 00 	mov    0x63c14(%rip),%r13d        # 6a4e8 <iteration_active>
    68d4:	41 54                	push   %r12
    68d6:	49 89 f4             	mov    %rsi,%r12
    68d9:	55                   	push   %rbp
    68da:	53                   	push   %rbx
    68db:	45 85 ed             	test   %r13d,%r13d
    68de:	0f 84 1c 01 00 00    	je     6a00 <fwp_data.part.0.constprop.0+0x140>
    68e4:	48 83 05 f4 3b 06 00 	addq   $0x1,0x63bf4(%rip)        # 6a4e0 <iteration_requests>
    68eb:	01 
    68ec:	48 83 05 e4 3b 06 00 	addq   $0x18,0x63be4(%rip)        # 6a4d8 <iteration_bytes>
    68f3:	18 
    68f4:	85 c0                	test   %eax,%eax
    68f6:	0f 84 8c 01 00 00    	je     6a88 <fwp_data.part.0.constprop.0+0x1c8>
    68fc:	0f b6 05 bf 2e 06 00 	movzbl 0x62ebf(%rip),%eax        # 697c2 <fwp_heap+0xfa2>
    6903:	48 8d 15 16 1f 06 00 	lea    0x61f16(%rip),%rdx        # 68820 <fwp_heap>
    690a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6911:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6915:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6919:	48 8b 18             	mov    (%rax),%rbx
    691c:	48 85 db             	test   %rbx,%rbx
    691f:	0f 84 fb 00 00 00    	je     6a20 <fwp_data.part.0.constprop.0+0x160>
    6925:	48 8b 13             	mov    (%rbx),%rdx
    6928:	48 f7 d2             	not    %rdx
    692b:	48 89 10             	mov    %rdx,(%rax)
    692e:	48 83 fd 18          	cmp    $0x18,%rbp
    6932:	76 1b                	jbe    694f <fwp_data.part.0.constprop.0+0x8f>
    6934:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6938:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    693c:	31 f6                	xor    %esi,%esi
    693e:	48 c1 e8 03          	shr    $0x3,%rax
    6942:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6949:	00 
    694a:	e8 61 cb ff ff       	call   34b0 <memset@plt>
    694f:	48 89 e8             	mov    %rbp,%rax
    6952:	48 03 05 e7 32 06 00 	add    0x632e7(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    6959:	0f 82 3d 01 00 00    	jb     6a9c <fwp_data.part.0.constprop.0+0x1dc>
    695f:	48 39 05 e2 32 06 00 	cmp    %rax,0x632e2(%rip)        # 69c48 <fwp_heap+0x1428>
    6966:	48 89 05 d3 32 06 00 	mov    %rax,0x632d3(%rip)        # 69c40 <fwp_heap+0x1420>
    696d:	73 07                	jae    6976 <fwp_data.part.0.constprop.0+0xb6>
    696f:	48 89 05 d2 32 06 00 	mov    %rax,0x632d2(%rip)        # 69c48 <fwp_heap+0x1428>
    6976:	66 0f ef c0          	pxor   %xmm0,%xmm0
    697a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    697f:	f2 0f 58 05 d1 32 06 	addsd  0x632d1(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    6986:	00 
    6987:	f2 0f 11 05 c9 32 06 	movsd  %xmm0,0x632c9(%rip)        # 69c58 <fwp_heap+0x1438>
    698e:	00 
    698f:	45 85 ed             	test   %r13d,%r13d
    6992:	74 33                	je     69c7 <fwp_data.part.0.constprop.0+0x107>
    6994:	48 8b 05 a5 32 06 00 	mov    0x632a5(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    699b:	48 85 c0             	test   %rax,%rax
    699e:	0f 88 a4 00 00 00    	js     6a48 <fwp_data.part.0.constprop.0+0x188>
    69a4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69a8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    69ad:	f2 0f 5c 05 13 3b 06 	subsd  0x63b13(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    69b4:	00 
    69b5:	66 0f 2f 05 03 3b 06 	comisd 0x63b03(%rip),%xmm0        # 6a4c0 <iteration_peak>
    69bc:	00 
    69bd:	76 08                	jbe    69c7 <fwp_data.part.0.constprop.0+0x107>
    69bf:	f2 0f 11 05 f9 3a 06 	movsd  %xmm0,0x63af9(%rip)        # 6a4c0 <iteration_peak>
    69c6:	00 
    69c7:	b8 02 00 00 00       	mov    $0x2,%eax
    69cc:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    69d1:	66 0f 6e c8          	movd   %eax,%xmm1
    69d5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    69d9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    69dd:	49 8b 04 24          	mov    (%r12),%rax
    69e1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    69e5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    69ea:	48 89 43 10          	mov    %rax,0x10(%rbx)
    69ee:	48 89 d8             	mov    %rbx,%rax
    69f1:	5b                   	pop    %rbx
    69f2:	5d                   	pop    %rbp
    69f3:	41 5c                	pop    %r12
    69f5:	41 5d                	pop    %r13
    69f7:	41 5e                	pop    %r14
    69f9:	c3                   	ret
    69fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a00:	85 c0                	test   %eax,%eax
    6a02:	0f 85 f4 fe ff ff    	jne    68fc <fwp_data.part.0.constprop.0+0x3c>
    6a08:	31 f6                	xor    %esi,%esi
    6a0a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a0f:	e8 fc f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a14:	48 89 c3             	mov    %rax,%rbx
    6a17:	eb ae                	jmp    69c7 <fwp_data.part.0.constprop.0+0x107>
    6a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a20:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6a24:	48 85 db             	test   %rbx,%rbx
    6a27:	74 47                	je     6a70 <fwp_data.part.0.constprop.0+0x1b0>
    6a29:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6a2d:	48 29 da             	sub    %rbx,%rdx
    6a30:	48 39 ea             	cmp    %rbp,%rdx
    6a33:	72 3b                	jb     6a70 <fwp_data.part.0.constprop.0+0x1b0>
    6a35:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6a39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6a3d:	e9 ec fe ff ff       	jmp    692e <fwp_data.part.0.constprop.0+0x6e>
    6a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a48:	48 89 c2             	mov    %rax,%rdx
    6a4b:	83 e0 01             	and    $0x1,%eax
    6a4e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a52:	48 d1 ea             	shr    $1,%rdx
    6a55:	48 09 c2             	or     %rax,%rdx
    6a58:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6a5d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6a61:	e9 47 ff ff ff       	jmp    69ad <fwp_data.part.0.constprop.0+0xed>
    6a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a6d:	00 00 00 
    6a70:	31 f6                	xor    %esi,%esi
    6a72:	bf 18 00 00 00       	mov    $0x18,%edi
    6a77:	e8 94 f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a7c:	48 89 c3             	mov    %rax,%rbx
    6a7f:	e9 0b ff ff ff       	jmp    698f <fwp_data.part.0.constprop.0+0xcf>
    6a84:	0f 1f 40 00          	nopl   0x0(%rax)
    6a88:	31 f6                	xor    %esi,%esi
    6a8a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a8f:	e8 7c f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a94:	48 89 c3             	mov    %rax,%rbx
    6a97:	e9 f8 fe ff ff       	jmp    6994 <fwp_data.part.0.constprop.0+0xd4>
    6a9c:	e8 8f d3 ff ff       	call   3e30 <fwp_heap_oom>
    6aa1:	0f 1f 40 00          	nopl   0x0(%rax)
    6aa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6aac:	00 00 00 00 

0000000000006ab0 <fwp_rc_share>:
    6ab0:	48 8b 05 41 31 06 00 	mov    0x63141(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6ab7:	48 2b 3d 12 31 06 00 	sub    0x63112(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6abe:	48 c1 e0 10          	shl    $0x10,%rax
    6ac2:	48 39 c7             	cmp    %rax,%rdi
    6ac5:	73 4a                	jae    6b11 <fwp_rc_share+0x61>
    6ac7:	48 89 f8             	mov    %rdi,%rax
    6aca:	48 c1 e8 10          	shr    $0x10,%rax
    6ace:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ad2:	48 8b 05 3f 31 06 00 	mov    0x6313f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6ad9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6add:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6ae1:	48 85 d2             	test   %rdx,%rdx
    6ae4:	74 2b                	je     6b11 <fwp_rc_share+0x61>
    6ae6:	0f b6 08             	movzbl (%rax),%ecx
    6ae9:	80 f9 02             	cmp    $0x2,%cl
    6aec:	74 2a                	je     6b18 <fwp_rc_share+0x68>
    6aee:	80 f9 01             	cmp    $0x1,%cl
    6af1:	75 1e                	jne    6b11 <fwp_rc_share+0x61>
    6af3:	8b 48 18             	mov    0x18(%rax),%ecx
    6af6:	0f b7 ff             	movzwl %di,%edi
    6af9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6afc:	48 0f af f9          	imul   %rcx,%rdi
    6b00:	48 c1 ef 20          	shr    $0x20,%rdi
    6b04:	48 39 c7             	cmp    %rax,%rdi
    6b07:	73 08                	jae    6b11 <fwp_rc_share+0x61>
    6b09:	48 01 fa             	add    %rdi,%rdx
    6b0c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6b0f:	75 0d                	jne    6b1e <fwp_rc_share+0x6e>
    6b11:	c3                   	ret
    6b12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b18:	66 85 ff             	test   %di,%di
    6b1b:	74 ef                	je     6b0c <fwp_rc_share+0x5c>
    6b1d:	c3                   	ret
    6b1e:	50                   	push   %rax
    6b1f:	48 8d 3d 5a 5f 00 00 	lea    0x5f5a(%rip),%rdi        # ca80 <_IO_stdin_used+0xa80>
    6b26:	e8 25 d9 ff ff       	call   4450 <fwp_trap>
    6b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006b30 <fwp_rc_free_arr>:
    6b30:	48 8b 15 c1 30 06 00 	mov    0x630c1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6b37:	48 89 f8             	mov    %rdi,%rax
    6b3a:	48 2b 05 8f 30 06 00 	sub    0x6308f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6b41:	48 c1 e2 10          	shl    $0x10,%rdx
    6b45:	48 39 d0             	cmp    %rdx,%rax
    6b48:	73 5b                	jae    6ba5 <fwp_rc_free_arr+0x75>
    6b4a:	48 89 c2             	mov    %rax,%rdx
    6b4d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b55:	48 8b 15 bc 30 06 00 	mov    0x630bc(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6b5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6b60:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6b64:	48 85 c9             	test   %rcx,%rcx
    6b67:	74 3c                	je     6ba5 <fwp_rc_free_arr+0x75>
    6b69:	0f b6 32             	movzbl (%rdx),%esi
    6b6c:	40 80 fe 02          	cmp    $0x2,%sil
    6b70:	74 2e                	je     6ba0 <fwp_rc_free_arr+0x70>
    6b72:	40 80 fe 01          	cmp    $0x1,%sil
    6b76:	75 2d                	jne    6ba5 <fwp_rc_free_arr+0x75>
    6b78:	8b 72 18             	mov    0x18(%rdx),%esi
    6b7b:	0f b7 c0             	movzwl %ax,%eax
    6b7e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b81:	48 0f af c6          	imul   %rsi,%rax
    6b85:	48 c1 e8 20          	shr    $0x20,%rax
    6b89:	48 39 d0             	cmp    %rdx,%rax
    6b8c:	73 17                	jae    6ba5 <fwp_rc_free_arr+0x75>
    6b8e:	48 01 c1             	add    %rax,%rcx
    6b91:	80 39 01             	cmpb   $0x1,(%rcx)
    6b94:	75 0f                	jne    6ba5 <fwp_rc_free_arr+0x75>
    6b96:	e9 75 ee ff ff       	jmp    5a10 <fwp_mem_free>
    6b9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ba0:	66 85 c0             	test   %ax,%ax
    6ba3:	74 ec                	je     6b91 <fwp_rc_free_arr+0x61>
    6ba5:	c3                   	ret
    6ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bad:	00 00 00 

0000000000006bb0 <fwp_rc_dup>:
    6bb0:	f3 0f 1e fa          	endbr64
    6bb4:	48 8b 05 3d 30 06 00 	mov    0x6303d(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    6bbb:	48 2b 3d 0e 30 06 00 	sub    0x6300e(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    6bc2:	48 c1 e0 10          	shl    $0x10,%rax
    6bc6:	48 39 c7             	cmp    %rax,%rdi
    6bc9:	73 60                	jae    6c2b <fwp_rc_dup+0x7b>
    6bcb:	48 89 f8             	mov    %rdi,%rax
    6bce:	48 c1 e8 10          	shr    $0x10,%rax
    6bd2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6bd6:	48 8b 05 3b 30 06 00 	mov    0x6303b(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6bdd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6be1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6be5:	48 85 c0             	test   %rax,%rax
    6be8:	74 41                	je     6c2b <fwp_rc_dup+0x7b>
    6bea:	0f b6 0a             	movzbl (%rdx),%ecx
    6bed:	80 f9 02             	cmp    $0x2,%cl
    6bf0:	74 3e                	je     6c30 <fwp_rc_dup+0x80>
    6bf2:	80 f9 01             	cmp    $0x1,%cl
    6bf5:	75 34                	jne    6c2b <fwp_rc_dup+0x7b>
    6bf7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6bfa:	0f b7 ff             	movzwl %di,%edi
    6bfd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c00:	48 0f af f9          	imul   %rcx,%rdi
    6c04:	48 c1 ef 20          	shr    $0x20,%rdi
    6c08:	48 39 d7             	cmp    %rdx,%rdi
    6c0b:	73 1e                	jae    6c2b <fwp_rc_dup+0x7b>
    6c0d:	48 01 f8             	add    %rdi,%rax
    6c10:	0f b6 10             	movzbl (%rax),%edx
    6c13:	84 d2                	test   %dl,%dl
    6c15:	74 14                	je     6c2b <fwp_rc_dup+0x7b>
    6c17:	8b 0d cb 38 06 00    	mov    0x638cb(%rip),%ecx        # 6a4e8 <iteration_active>
    6c1d:	85 c9                	test   %ecx,%ecx
    6c1f:	75 1f                	jne    6c40 <fwp_rc_dup+0x90>
    6c21:	80 fa fd             	cmp    $0xfd,%dl
    6c24:	77 2a                	ja     6c50 <fwp_rc_dup+0xa0>
    6c26:	83 c2 01             	add    $0x1,%edx
    6c29:	88 10                	mov    %dl,(%rax)
    6c2b:	c3                   	ret
    6c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c30:	66 85 ff             	test   %di,%di
    6c33:	74 db                	je     6c10 <fwp_rc_dup+0x60>
    6c35:	c3                   	ret
    6c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c3d:	00 00 00 
    6c40:	48 83 05 88 38 06 00 	addq   $0x1,0x63888(%rip)        # 6a4d0 <iteration_retains>
    6c47:	01 
    6c48:	eb d7                	jmp    6c21 <fwp_rc_dup+0x71>
    6c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c50:	48 89 c7             	mov    %rax,%rdi
    6c53:	e9 58 ea ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c5f:	00 

0000000000006c60 <fwp_owned_entry161>:
    6c60:	f3 0f 1e fa          	endbr64
    6c64:	48 83 ec 38          	sub    $0x38,%rsp
    6c68:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c6d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c74:	00 00 
    6c76:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6c7b:	31 c0                	xor    %eax,%eax
    6c7d:	48 8b 07             	mov    (%rdi),%rax
    6c80:	48 03 47 10          	add    0x10(%rdi),%rax
    6c84:	0f 80 c2 00 00 00    	jo     6d4c <fwp_owned_entry161+0xec>
    6c8a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c8f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c94:	31 ff                	xor    %edi,%edi
    6c96:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c9a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c9f:	e8 1c fc ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    6ca4:	48 8b 15 4d 2f 06 00 	mov    0x62f4d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6cab:	48 89 c6             	mov    %rax,%rsi
    6cae:	48 2b 05 1b 2f 06 00 	sub    0x62f1b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6cb5:	48 c1 e2 10          	shl    $0x10,%rdx
    6cb9:	48 39 d0             	cmp    %rdx,%rax
    6cbc:	73 4f                	jae    6d0d <fwp_owned_entry161+0xad>
    6cbe:	48 89 c2             	mov    %rax,%rdx
    6cc1:	48 c1 ea 10          	shr    $0x10,%rdx
    6cc5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cc9:	48 8b 15 48 2f 06 00 	mov    0x62f48(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6cd0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6cd4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6cd8:	48 85 d2             	test   %rdx,%rdx
    6cdb:	74 30                	je     6d0d <fwp_owned_entry161+0xad>
    6cdd:	0f b6 39             	movzbl (%rcx),%edi
    6ce0:	40 80 ff 02          	cmp    $0x2,%dil
    6ce4:	74 42                	je     6d28 <fwp_owned_entry161+0xc8>
    6ce6:	40 80 ff 01          	cmp    $0x1,%dil
    6cea:	75 21                	jne    6d0d <fwp_owned_entry161+0xad>
    6cec:	8b 79 18             	mov    0x18(%rcx),%edi
    6cef:	0f b7 c0             	movzwl %ax,%eax
    6cf2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6cf5:	48 0f af c7          	imul   %rdi,%rax
    6cf9:	48 c1 e8 20          	shr    $0x20,%rax
    6cfd:	48 39 c8             	cmp    %rcx,%rax
    6d00:	73 0b                	jae    6d0d <fwp_owned_entry161+0xad>
    6d02:	48 01 c2             	add    %rax,%rdx
    6d05:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d08:	74 26                	je     6d30 <fwp_owned_entry161+0xd0>
    6d0a:	c6 02 01             	movb   $0x1,(%rdx)
    6d0d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d12:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d19:	00 00 
    6d1b:	75 34                	jne    6d51 <fwp_owned_entry161+0xf1>
    6d1d:	48 89 f0             	mov    %rsi,%rax
    6d20:	48 83 c4 38          	add    $0x38,%rsp
    6d24:	c3                   	ret
    6d25:	0f 1f 00             	nopl   (%rax)
    6d28:	66 85 c0             	test   %ax,%ax
    6d2b:	75 e0                	jne    6d0d <fwp_owned_entry161+0xad>
    6d2d:	eb d6                	jmp    6d05 <fwp_owned_entry161+0xa5>
    6d2f:	90                   	nop
    6d30:	48 89 d7             	mov    %rdx,%rdi
    6d33:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6d38:	48 89 14 24          	mov    %rdx,(%rsp)
    6d3c:	e8 8f ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6d41:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6d46:	48 8b 14 24          	mov    (%rsp),%rdx
    6d4a:	eb be                	jmp    6d0a <fwp_owned_entry161+0xaa>
    6d4c:	e8 af c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6d51:	e8 fa c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d5d:	00 00 00 

0000000000006d60 <e161>:
    6d60:	f3 0f 1e fa          	endbr64
    6d64:	53                   	push   %rbx
    6d65:	48 83 ec 30          	sub    $0x30,%rsp
    6d69:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6d6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6d75:	00 00 
    6d77:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6d7c:	31 c0                	xor    %eax,%eax
    6d7e:	48 8b 07             	mov    (%rdi),%rax
    6d81:	48 03 47 10          	add    0x10(%rdi),%rax
    6d85:	0f 80 c9 00 00 00    	jo     6e54 <e161+0xf4>
    6d8b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d90:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d95:	31 ff                	xor    %edi,%edi
    6d97:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d9b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6da0:	e8 1b fb ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    6da5:	48 8b 15 4c 2e 06 00 	mov    0x62e4c(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6dac:	48 89 c3             	mov    %rax,%rbx
    6daf:	48 2b 05 1a 2e 06 00 	sub    0x62e1a(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6db6:	48 c1 e2 10          	shl    $0x10,%rdx
    6dba:	48 39 d0             	cmp    %rdx,%rax
    6dbd:	73 4f                	jae    6e0e <e161+0xae>
    6dbf:	48 89 c2             	mov    %rax,%rdx
    6dc2:	48 c1 ea 10          	shr    $0x10,%rdx
    6dc6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dca:	48 8b 15 47 2e 06 00 	mov    0x62e47(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6dd1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6dd5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6dd9:	48 85 d2             	test   %rdx,%rdx
    6ddc:	74 30                	je     6e0e <e161+0xae>
    6dde:	0f b6 31             	movzbl (%rcx),%esi
    6de1:	40 80 fe 02          	cmp    $0x2,%sil
    6de5:	74 49                	je     6e30 <e161+0xd0>
    6de7:	40 80 fe 01          	cmp    $0x1,%sil
    6deb:	75 21                	jne    6e0e <e161+0xae>
    6ded:	8b 71 18             	mov    0x18(%rcx),%esi
    6df0:	0f b7 c0             	movzwl %ax,%eax
    6df3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6df6:	48 0f af c6          	imul   %rsi,%rax
    6dfa:	48 c1 e8 20          	shr    $0x20,%rax
    6dfe:	48 39 c8             	cmp    %rcx,%rax
    6e01:	73 0b                	jae    6e0e <e161+0xae>
    6e03:	48 01 c2             	add    %rax,%rdx
    6e06:	80 3a ff             	cmpb   $0xff,(%rdx)
    6e09:	74 35                	je     6e40 <e161+0xe0>
    6e0b:	c6 02 01             	movb   $0x1,(%rdx)
    6e0e:	48 89 df             	mov    %rbx,%rdi
    6e11:	e8 9a fc ff ff       	call   6ab0 <fwp_rc_share>
    6e16:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6e1b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e22:	00 00 
    6e24:	75 33                	jne    6e59 <e161+0xf9>
    6e26:	48 83 c4 30          	add    $0x30,%rsp
    6e2a:	48 89 d8             	mov    %rbx,%rax
    6e2d:	5b                   	pop    %rbx
    6e2e:	c3                   	ret
    6e2f:	90                   	nop
    6e30:	66 85 c0             	test   %ax,%ax
    6e33:	75 d9                	jne    6e0e <e161+0xae>
    6e35:	eb cf                	jmp    6e06 <e161+0xa6>
    6e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e3e:	00 00 
    6e40:	48 89 d7             	mov    %rdx,%rdi
    6e43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e48:	e8 83 e9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6e4d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e52:	eb b7                	jmp    6e0b <e161+0xab>
    6e54:	e8 a7 c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6e59:	e8 f2 c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6e5e:	66 90                	xchg   %ax,%ax

0000000000006e60 <fwp_drop0>:
    6e60:	f3 0f 1e fa          	endbr64
    6e64:	48 8b 15 8d 2d 06 00 	mov    0x62d8d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6e6b:	48 89 f8             	mov    %rdi,%rax
    6e6e:	48 2b 05 5b 2d 06 00 	sub    0x62d5b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6e75:	48 c1 e2 10          	shl    $0x10,%rdx
    6e79:	48 39 d0             	cmp    %rdx,%rax
    6e7c:	0f 83 be 00 00 00    	jae    6f40 <fwp_drop0+0xe0>
    6e82:	48 83 ec 18          	sub    $0x18,%rsp
    6e86:	4c 8d 05 93 19 06 00 	lea    0x61993(%rip),%r8        # 68820 <fwp_heap>
    6e8d:	48 89 c2             	mov    %rax,%rdx
    6e90:	48 c1 ea 10          	shr    $0x10,%rdx
    6e94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e98:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6e9f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ea3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ea7:	48 85 d2             	test   %rdx,%rdx
    6eaa:	74 3c                	je     6ee8 <fwp_drop0+0x88>
    6eac:	0f b6 31             	movzbl (%rcx),%esi
    6eaf:	40 80 fe 02          	cmp    $0x2,%sil
    6eb3:	74 3b                	je     6ef0 <fwp_drop0+0x90>
    6eb5:	40 80 fe 01          	cmp    $0x1,%sil
    6eb9:	75 2d                	jne    6ee8 <fwp_drop0+0x88>
    6ebb:	8b 71 18             	mov    0x18(%rcx),%esi
    6ebe:	0f b7 c0             	movzwl %ax,%eax
    6ec1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ec4:	48 0f af c6          	imul   %rsi,%rax
    6ec8:	48 c1 e8 20          	shr    $0x20,%rax
    6ecc:	48 39 c8             	cmp    %rcx,%rax
    6ecf:	73 17                	jae    6ee8 <fwp_drop0+0x88>
    6ed1:	48 01 c2             	add    %rax,%rdx
    6ed4:	0f b6 02             	movzbl (%rdx),%eax
    6ed7:	84 c0                	test   %al,%al
    6ed9:	74 0d                	je     6ee8 <fwp_drop0+0x88>
    6edb:	3c 01                	cmp    $0x1,%al
    6edd:	74 21                	je     6f00 <fwp_drop0+0xa0>
    6edf:	3c ff                	cmp    $0xff,%al
    6ee1:	74 65                	je     6f48 <fwp_drop0+0xe8>
    6ee3:	83 e8 01             	sub    $0x1,%eax
    6ee6:	88 02                	mov    %al,(%rdx)
    6ee8:	48 83 c4 18          	add    $0x18,%rsp
    6eec:	c3                   	ret
    6eed:	0f 1f 00             	nopl   (%rax)
    6ef0:	66 85 c0             	test   %ax,%ax
    6ef3:	74 df                	je     6ed4 <fwp_drop0+0x74>
    6ef5:	48 83 c4 18          	add    $0x18,%rsp
    6ef9:	c3                   	ret
    6efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f00:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6f04:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6f09:	e8 22 fc ff ff       	call   6b30 <fwp_rc_free_arr>
    6f0e:	4c 8d 05 0b 19 06 00 	lea    0x6190b(%rip),%r8        # 68820 <fwp_heap>
    6f15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6f1a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6f21:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6f28:	48 c1 e2 10          	shl    $0x10,%rdx
    6f2c:	48 39 d0             	cmp    %rdx,%rax
    6f2f:	73 b7                	jae    6ee8 <fwp_drop0+0x88>
    6f31:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f36:	e9 52 ff ff ff       	jmp    6e8d <fwp_drop0+0x2d>
    6f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f40:	c3                   	ret
    6f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f48:	48 89 d0             	mov    %rdx,%rax
    6f4b:	48 c1 e8 11          	shr    $0x11,%rax
    6f4f:	48 31 d0             	xor    %rdx,%rax
    6f52:	48 89 c1             	mov    %rax,%rcx
    6f55:	48 c1 e9 09          	shr    $0x9,%rcx
    6f59:	48 31 c8             	xor    %rcx,%rax
    6f5c:	0f b6 c8             	movzbl %al,%ecx
    6f5f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6f66:	00 
    6f67:	48 85 c0             	test   %rax,%rax
    6f6a:	75 1d                	jne    6f89 <fwp_drop0+0x129>
    6f6c:	eb 56                	jmp    6fc4 <fwp_drop0+0x164>
    6f6e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f7c:	00 00 00 00 
    6f80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f84:	48 85 c0             	test   %rax,%rax
    6f87:	74 3b                	je     6fc4 <fwp_drop0+0x164>
    6f89:	48 89 c1             	mov    %rax,%rcx
    6f8c:	48 39 10             	cmp    %rdx,(%rax)
    6f8f:	75 ef                	jne    6f80 <fwp_drop0+0x120>
    6f91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6fa4:	0f 85 3e ff ff ff    	jne    6ee8 <fwp_drop0+0x88>
    6faa:	48 89 d7             	mov    %rdx,%rdi
    6fad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6fb2:	e8 19 e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6fb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6fbf:	e9 24 ff ff ff       	jmp    6ee8 <fwp_drop0+0x88>
    6fc4:	48 8d 3d 15 5a 00 00 	lea    0x5a15(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    6fcb:	e8 80 d4 ff ff       	call   4450 <fwp_trap>

0000000000006fd0 <fwp_arg_drop12>:
    6fd0:	f3 0f 1e fa          	endbr64
    6fd4:	85 f6                	test   %esi,%esi
    6fd6:	75 04                	jne    6fdc <fwp_arg_drop12+0xc>
    6fd8:	85 d2                	test   %edx,%edx
    6fda:	75 04                	jne    6fe0 <fwp_arg_drop12+0x10>
    6fdc:	c3                   	ret
    6fdd:	0f 1f 00             	nopl   (%rax)
    6fe0:	48 8b 3f             	mov    (%rdi),%rdi
    6fe3:	e9 78 fe ff ff       	jmp    6e60 <fwp_drop0>
    6fe8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6fef:	00 

0000000000006ff0 <fwp_drop1>:
    6ff0:	f3 0f 1e fa          	endbr64
    6ff4:	48 8b 15 fd 2b 06 00 	mov    0x62bfd(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6ffb:	48 89 f8             	mov    %rdi,%rax
    6ffe:	48 2b 05 cb 2b 06 00 	sub    0x62bcb(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7005:	48 c1 e2 10          	shl    $0x10,%rdx
    7009:	48 39 d0             	cmp    %rdx,%rax
    700c:	0f 83 be 00 00 00    	jae    70d0 <fwp_drop1+0xe0>
    7012:	48 83 ec 18          	sub    $0x18,%rsp
    7016:	4c 8d 05 03 18 06 00 	lea    0x61803(%rip),%r8        # 68820 <fwp_heap>
    701d:	48 89 c2             	mov    %rax,%rdx
    7020:	48 c1 ea 10          	shr    $0x10,%rdx
    7024:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7028:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    702f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7033:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7037:	48 85 d2             	test   %rdx,%rdx
    703a:	74 3c                	je     7078 <fwp_drop1+0x88>
    703c:	0f b6 31             	movzbl (%rcx),%esi
    703f:	40 80 fe 02          	cmp    $0x2,%sil
    7043:	74 3b                	je     7080 <fwp_drop1+0x90>
    7045:	40 80 fe 01          	cmp    $0x1,%sil
    7049:	75 2d                	jne    7078 <fwp_drop1+0x88>
    704b:	8b 71 18             	mov    0x18(%rcx),%esi
    704e:	0f b7 c0             	movzwl %ax,%eax
    7051:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7054:	48 0f af c6          	imul   %rsi,%rax
    7058:	48 c1 e8 20          	shr    $0x20,%rax
    705c:	48 39 c8             	cmp    %rcx,%rax
    705f:	73 17                	jae    7078 <fwp_drop1+0x88>
    7061:	48 01 c2             	add    %rax,%rdx
    7064:	0f b6 02             	movzbl (%rdx),%eax
    7067:	84 c0                	test   %al,%al
    7069:	74 0d                	je     7078 <fwp_drop1+0x88>
    706b:	3c 01                	cmp    $0x1,%al
    706d:	74 21                	je     7090 <fwp_drop1+0xa0>
    706f:	3c ff                	cmp    $0xff,%al
    7071:	74 65                	je     70d8 <fwp_drop1+0xe8>
    7073:	83 e8 01             	sub    $0x1,%eax
    7076:	88 02                	mov    %al,(%rdx)
    7078:	48 83 c4 18          	add    $0x18,%rsp
    707c:	c3                   	ret
    707d:	0f 1f 00             	nopl   (%rax)
    7080:	66 85 c0             	test   %ax,%ax
    7083:	74 df                	je     7064 <fwp_drop1+0x74>
    7085:	48 83 c4 18          	add    $0x18,%rsp
    7089:	c3                   	ret
    708a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7090:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7094:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7099:	e8 92 fa ff ff       	call   6b30 <fwp_rc_free_arr>
    709e:	4c 8d 05 7b 17 06 00 	lea    0x6177b(%rip),%r8        # 68820 <fwp_heap>
    70a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    70aa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    70b1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    70b8:	48 c1 e2 10          	shl    $0x10,%rdx
    70bc:	48 39 d0             	cmp    %rdx,%rax
    70bf:	73 b7                	jae    7078 <fwp_drop1+0x88>
    70c1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    70c6:	e9 52 ff ff ff       	jmp    701d <fwp_drop1+0x2d>
    70cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    70d0:	c3                   	ret
    70d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70d8:	48 89 d0             	mov    %rdx,%rax
    70db:	48 c1 e8 11          	shr    $0x11,%rax
    70df:	48 31 d0             	xor    %rdx,%rax
    70e2:	48 89 c1             	mov    %rax,%rcx
    70e5:	48 c1 e9 09          	shr    $0x9,%rcx
    70e9:	48 31 c8             	xor    %rcx,%rax
    70ec:	0f b6 c8             	movzbl %al,%ecx
    70ef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    70f6:	00 
    70f7:	48 85 c0             	test   %rax,%rax
    70fa:	75 0d                	jne    7109 <fwp_drop1+0x119>
    70fc:	eb 46                	jmp    7144 <fwp_drop1+0x154>
    70fe:	66 90                	xchg   %ax,%ax
    7100:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7104:	48 85 c0             	test   %rax,%rax
    7107:	74 3b                	je     7144 <fwp_drop1+0x154>
    7109:	48 89 c1             	mov    %rax,%rcx
    710c:	48 39 10             	cmp    %rdx,(%rax)
    710f:	75 ef                	jne    7100 <fwp_drop1+0x110>
    7111:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7115:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7119:	48 89 48 08          	mov    %rcx,0x8(%rax)
    711d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7124:	0f 85 4e ff ff ff    	jne    7078 <fwp_drop1+0x88>
    712a:	48 89 d7             	mov    %rdx,%rdi
    712d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7132:	e8 99 e6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7137:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    713c:	c6 02 fe             	movb   $0xfe,(%rdx)
    713f:	e9 34 ff ff ff       	jmp    7078 <fwp_drop1+0x88>
    7144:	48 8d 3d 95 58 00 00 	lea    0x5895(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    714b:	e8 00 d3 ff ff       	call   4450 <fwp_trap>

0000000000007150 <fwp_closure_drop>:
    7150:	48 8b 15 a1 2a 06 00 	mov    0x62aa1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7157:	48 89 f8             	mov    %rdi,%rax
    715a:	48 2b 05 6f 2a 06 00 	sub    0x62a6f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7161:	48 c1 e2 10          	shl    $0x10,%rdx
    7165:	48 39 d0             	cmp    %rdx,%rax
    7168:	73 6b                	jae    71d5 <fwp_closure_drop+0x85>
    716a:	48 89 c2             	mov    %rax,%rdx
    716d:	48 c1 ea 10          	shr    $0x10,%rdx
    7171:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7175:	48 8b 15 9c 2a 06 00 	mov    0x62a9c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    717c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7180:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7184:	48 85 d2             	test   %rdx,%rdx
    7187:	74 4c                	je     71d5 <fwp_closure_drop+0x85>
    7189:	0f b6 31             	movzbl (%rcx),%esi
    718c:	40 80 fe 02          	cmp    $0x2,%sil
    7190:	74 3e                	je     71d0 <fwp_closure_drop+0x80>
    7192:	40 80 fe 01          	cmp    $0x1,%sil
    7196:	75 3d                	jne    71d5 <fwp_closure_drop+0x85>
    7198:	8b 71 18             	mov    0x18(%rcx),%esi
    719b:	0f b7 c0             	movzwl %ax,%eax
    719e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    71a1:	48 0f af c6          	imul   %rsi,%rax
    71a5:	48 c1 e8 20          	shr    $0x20,%rax
    71a9:	48 39 c8             	cmp    %rcx,%rax
    71ac:	73 27                	jae    71d5 <fwp_closure_drop+0x85>
    71ae:	48 01 c2             	add    %rax,%rdx
    71b1:	0f b6 02             	movzbl (%rdx),%eax
    71b4:	84 c0                	test   %al,%al
    71b6:	74 1d                	je     71d5 <fwp_closure_drop+0x85>
    71b8:	3c 01                	cmp    $0x1,%al
    71ba:	74 24                	je     71e0 <fwp_closure_drop+0x90>
    71bc:	3c ff                	cmp    $0xff,%al
    71be:	74 48                	je     7208 <fwp_closure_drop+0xb8>
    71c0:	83 e8 01             	sub    $0x1,%eax
    71c3:	88 02                	mov    %al,(%rdx)
    71c5:	c3                   	ret
    71c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71cd:	00 00 00 
    71d0:	66 85 c0             	test   %ax,%ax
    71d3:	74 dc                	je     71b1 <fwp_closure_drop+0x61>
    71d5:	c3                   	ret
    71d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71dd:	00 00 00 
    71e0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    71e7:	ff ff 
    71e9:	48 85 c0             	test   %rax,%rax
    71ec:	74 12                	je     7200 <fwp_closure_drop+0xb0>
    71ee:	48 89 fe             	mov    %rdi,%rsi
    71f1:	48 89 c7             	mov    %rax,%rdi
    71f4:	e9 b7 d2 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    71f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7200:	e9 5b d4 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7205:	0f 1f 00             	nopl   (%rax)
    7208:	48 89 d0             	mov    %rdx,%rax
    720b:	48 8d 35 0e 16 06 00 	lea    0x6160e(%rip),%rsi        # 68820 <fwp_heap>
    7212:	48 83 ec 18          	sub    $0x18,%rsp
    7216:	48 c1 e8 11          	shr    $0x11,%rax
    721a:	48 31 d0             	xor    %rdx,%rax
    721d:	48 89 c1             	mov    %rax,%rcx
    7220:	48 c1 e9 09          	shr    $0x9,%rcx
    7224:	48 31 c8             	xor    %rcx,%rax
    7227:	0f b6 c8             	movzbl %al,%ecx
    722a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7231:	00 
    7232:	48 85 c0             	test   %rax,%rax
    7235:	75 12                	jne    7249 <fwp_closure_drop+0xf9>
    7237:	eb 49                	jmp    7282 <fwp_closure_drop+0x132>
    7239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7240:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7244:	48 85 c0             	test   %rax,%rax
    7247:	74 39                	je     7282 <fwp_closure_drop+0x132>
    7249:	48 89 c1             	mov    %rax,%rcx
    724c:	48 39 10             	cmp    %rdx,(%rax)
    724f:	75 ef                	jne    7240 <fwp_closure_drop+0xf0>
    7251:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7255:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7259:	48 89 48 08          	mov    %rcx,0x8(%rax)
    725d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7264:	74 05                	je     726b <fwp_closure_drop+0x11b>
    7266:	48 83 c4 18          	add    $0x18,%rsp
    726a:	c3                   	ret
    726b:	48 89 d7             	mov    %rdx,%rdi
    726e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7273:	e8 58 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7278:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    727d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7280:	eb e4                	jmp    7266 <fwp_closure_drop+0x116>
    7282:	48 8d 3d 57 57 00 00 	lea    0x5757(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    7289:	e8 c2 d1 ff ff       	call   4450 <fwp_trap>
    728e:	66 90                	xchg   %ax,%ax

0000000000007290 <fwp_owned_tape_release>:
    7290:	48 85 ff             	test   %rdi,%rdi
    7293:	0f 84 f7 00 00 00    	je     7390 <fwp_owned_tape_release+0x100>
    7299:	41 54                	push   %r12
    729b:	55                   	push   %rbp
    729c:	53                   	push   %rbx
    729d:	48 8b 07             	mov    (%rdi),%rax
    72a0:	48 85 c0             	test   %rax,%rax
    72a3:	74 08                	je     72ad <fwp_owned_tape_release+0x1d>
    72a5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    72a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72ad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    72b1:	48 85 d2             	test   %rdx,%rdx
    72b4:	74 03                	je     72b9 <fwp_owned_tape_release+0x29>
    72b6:	48 89 02             	mov    %rax,(%rdx)
    72b9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    72bd:	48 89 fb             	mov    %rdi,%rbx
    72c0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    72c4:	48 85 c0             	test   %rax,%rax
    72c7:	0f 84 89 00 00 00    	je     7356 <fwp_owned_tape_release+0xc6>
    72cd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    72d1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    72d5:	7e 47                	jle    731e <fwp_owned_tape_release+0x8e>
    72d7:	31 ed                	xor    %ebp,%ebp
    72d9:	eb 0d                	jmp    72e8 <fwp_owned_tape_release+0x58>
    72db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    72e0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    72e4:	48 8b 40 68          	mov    0x68(%rax),%rax
    72e8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    72ec:	49 89 ec             	mov    %rbp,%r12
    72ef:	48 83 c5 01          	add    $0x1,%rbp
    72f3:	49 c1 e4 04          	shl    $0x4,%r12
    72f7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    72fb:	ff d0                	call   *%rax
    72fd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7301:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7306:	48 8b 43 10          	mov    0x10(%rbx),%rax
    730a:	ff 50 68             	call   *0x68(%rax)
    730d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7311:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7315:	48 39 e8             	cmp    %rbp,%rax
    7318:	7f c6                	jg     72e0 <fwp_owned_tape_release+0x50>
    731a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    731e:	31 ed                	xor    %ebp,%ebp
    7320:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7325:	7e 28                	jle    734f <fwp_owned_tape_release+0xbf>
    7327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    732e:	00 00 
    7330:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7334:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7338:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    733c:	74 07                	je     7345 <fwp_owned_tape_release+0xb5>
    733e:	ff 52 68             	call   *0x68(%rdx)
    7341:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7345:	48 83 c5 01          	add    $0x1,%rbp
    7349:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    734d:	7f e1                	jg     7330 <fwp_owned_tape_release+0xa0>
    734f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7353:	ff 52 68             	call   *0x68(%rdx)
    7356:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    735a:	e8 f1 fd ff ff       	call   7150 <fwp_closure_drop>
    735f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7363:	e8 e8 fd ff ff       	call   7150 <fwp_closure_drop>
    7368:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    736c:	e8 df fd ff ff       	call   7150 <fwp_closure_drop>
    7371:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7375:	e8 96 e6 ff ff       	call   5a10 <fwp_mem_free>
    737a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    737e:	e8 8d e6 ff ff       	call   5a10 <fwp_mem_free>
    7383:	48 89 df             	mov    %rbx,%rdi
    7386:	5b                   	pop    %rbx
    7387:	5d                   	pop    %rbp
    7388:	41 5c                	pop    %r12
    738a:	e9 81 e6 ff ff       	jmp    5a10 <fwp_mem_free>
    738f:	90                   	nop
    7390:	c3                   	ret
    7391:	0f 1f 40 00          	nopl   0x0(%rax)
    7395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    739c:	00 00 00 00 

00000000000073a0 <fwp_tape_finish>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	41 55                	push   %r13
    73a6:	41 54                	push   %r12
    73a8:	55                   	push   %rbp
    73a9:	53                   	push   %rbx
    73aa:	48 83 ec 48          	sub    $0x48,%rsp
    73ae:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    73b5:	00 00 
    73b7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    73bc:	48 8d 3d dd 8c 01 00 	lea    0x18cdd(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    73c3:	e8 78 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    73c8:	48 83 3d 18 8d 01 00 	cmpq   $0x0,0x18d18(%rip)        # 200e8 <fwp_ntapes>
    73cf:	00 
    73d0:	48 c7 05 ad 8c 01 00 	movq   $0x0,0x18cad(%rip)        # 20088 <fwp_tape_cached_bytes>
    73d7:	00 00 00 00 
    73db:	7e 79                	jle    7456 <fwp_tape_finish+0xb6>
    73dd:	45 31 e4             	xor    %r12d,%r12d
    73e0:	31 ed                	xor    %ebp,%ebp
    73e2:	0f 1f 00             	nopl   (%rax)
    73e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73ec:	00 00 00 00 
    73f0:	48 8b 1d f9 8c 01 00 	mov    0x18cf9(%rip),%rbx        # 200f0 <fwp_tapes>
    73f7:	48 83 c5 01          	add    $0x1,%rbp
    73fb:	4c 01 e3             	add    %r12,%rbx
    73fe:	49 83 c4 68          	add    $0x68,%r12
    7402:	48 89 df             	mov    %rbx,%rdi
    7405:	e8 86 c8 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    740a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    740f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7414:	48 89 e7             	mov    %rsp,%rdi
    7417:	48 8b 43 40          	mov    0x40(%rbx),%rax
    741b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    741f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7424:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7429:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    742e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7432:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7437:	e8 04 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    743c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7440:	e8 4b fe ff ff       	call   7290 <fwp_owned_tape_release>
    7445:	48 39 2d 9c 8c 01 00 	cmp    %rbp,0x18c9c(%rip)        # 200e8 <fwp_ntapes>
    744c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7453:	00 
    7454:	7f 9a                	jg     73f0 <fwp_tape_finish+0x50>
    7456:	48 8b 3d 93 8c 01 00 	mov    0x18c93(%rip),%rdi        # 200f0 <fwp_tapes>
    745d:	48 85 ff             	test   %rdi,%rdi
    7460:	74 05                	je     7467 <fwp_tape_finish+0xc7>
    7462:	e8 69 dc ff ff       	call   50d0 <ad_raw_free.part.0>
    7467:	48 c7 05 7e 8c 01 00 	movq   $0x0,0x18c7e(%rip)        # 200f0 <fwp_tapes>
    746e:	00 00 00 00 
    7472:	48 c7 05 63 8c 01 00 	movq   $0x0,0x18c63(%rip)        # 200e0 <fwp_tapes_cap>
    7479:	00 00 00 00 
    747d:	48 c7 05 60 8c 01 00 	movq   $0x0,0x18c60(%rip)        # 200e8 <fwp_ntapes>
    7484:	00 00 00 00 
    7488:	48 c7 05 45 8c 01 00 	movq   $0x0,0x18c45(%rip)        # 200d8 <fwp_tape_next_slot>
    748f:	00 00 00 00 
    7493:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7498:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    749f:	00 00 
    74a1:	75 0b                	jne    74ae <fwp_tape_finish+0x10e>
    74a3:	48 83 c4 48          	add    $0x48,%rsp
    74a7:	5b                   	pop    %rbx
    74a8:	5d                   	pop    %rbp
    74a9:	41 5c                	pop    %r12
    74ab:	41 5d                	pop    %r13
    74ad:	c3                   	ret
    74ae:	e8 9d bf ff ff       	call   3450 <__stack_chk_fail@plt>
    74b3:	66 90                	xchg   %ax,%ax
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 

00000000000074c0 <fwp_tape_scope_release>:
    74c0:	f3 0f 1e fa          	endbr64
    74c4:	41 55                	push   %r13
    74c6:	41 54                	push   %r12
    74c8:	55                   	push   %rbp
    74c9:	53                   	push   %rbx
    74ca:	48 83 ec 48          	sub    $0x48,%rsp
    74ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    74d5:	00 00 
    74d7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    74dc:	48 63 07             	movslq (%rdi),%rax
    74df:	85 c0                	test   %eax,%eax
    74e1:	0f 88 e8 00 00 00    	js     75cf <fwp_tape_scope_release+0x10f>
    74e7:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    74ee:	ec c4 4e 
    74f1:	48 89 fb             	mov    %rdi,%rbx
    74f4:	48 89 e5             	mov    %rsp,%rbp
    74f7:	eb 1f                	jmp    7518 <fwp_tape_scope_release+0x58>
    74f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7500:	e8 3b dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7505:	4c 89 ef             	mov    %r13,%rdi
    7508:	e8 83 fd ff ff       	call   7290 <fwp_owned_tape_release>
    750d:	48 63 03             	movslq (%rbx),%rax
    7510:	85 c0                	test   %eax,%eax
    7512:	0f 88 b7 00 00 00    	js     75cf <fwp_tape_scope_release+0x10f>
    7518:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    751c:	48 8b 35 cd 8b 01 00 	mov    0x18bcd(%rip),%rsi        # 200f0 <fwp_tapes>
    7523:	4c 01 c6             	add    %r8,%rsi
    7526:	48 89 f7             	mov    %rsi,%rdi
    7529:	e8 62 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    752e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7533:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7538:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    753f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7543:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7547:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    754e:	00 
    754f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7554:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7559:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    755d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7562:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7566:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    756b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7572:	00 
    7573:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    757a:	00 
    757b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7582:	00 
    7583:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7587:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    758b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    758f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7593:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7599:	77 18                	ja     75b3 <fwp_tape_scope_release+0xf3>
    759b:	49 c1 f8 03          	sar    $0x3,%r8
    759f:	4d 0f af c4          	imul   %r12,%r8
    75a3:	4c 3b 05 2e 8b 01 00 	cmp    0x18b2e(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    75aa:	7d 07                	jge    75b3 <fwp_tape_scope_release+0xf3>
    75ac:	4c 89 05 25 8b 01 00 	mov    %r8,0x18b25(%rip)        # 200d8 <fwp_tape_next_slot>
    75b3:	48 89 ef             	mov    %rbp,%rdi
    75b6:	4d 85 ed             	test   %r13,%r13
    75b9:	0f 85 41 ff ff ff    	jne    7500 <fwp_tape_scope_release+0x40>
    75bf:	e8 9c dc ff ff       	call   5260 <fwp_tape_buffers_release>
    75c4:	48 63 03             	movslq (%rbx),%rax
    75c7:	85 c0                	test   %eax,%eax
    75c9:	0f 89 49 ff ff ff    	jns    7518 <fwp_tape_scope_release+0x58>
    75cf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    75d4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    75db:	00 00 
    75dd:	75 0b                	jne    75ea <fwp_tape_scope_release+0x12a>
    75df:	48 83 c4 48          	add    $0x48,%rsp
    75e3:	5b                   	pop    %rbx
    75e4:	5d                   	pop    %rbp
    75e5:	41 5c                	pop    %r12
    75e7:	41 5d                	pop    %r13
    75e9:	c3                   	ret
    75ea:	e8 61 be ff ff       	call   3450 <__stack_chk_fail@plt>
    75ef:	90                   	nop

00000000000075f0 <fwp_task_dispose>:
    75f0:	53                   	push   %rbx
    75f1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    75f5:	0f 84 4b c1 ff ff    	je     3746 <fwp_task_dispose.cold>
    75fb:	48 89 fb             	mov    %rdi,%rbx
    75fe:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7603:	0f 85 3d c1 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7609:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    760d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7614:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    761b:	00 
    761c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7620:	48 85 ff             	test   %rdi,%rdi
    7623:	74 07                	je     762c <fwp_task_dispose+0x3c>
    7625:	48 85 c0             	test   %rax,%rax
    7628:	74 02                	je     762c <fwp_task_dispose+0x3c>
    762a:	ff d0                	call   *%rax
    762c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7633:	e8 d8 e3 ff ff       	call   5a10 <fwp_mem_free>
    7638:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    763f:	00 00 00 00 
    7643:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7647:	74 6f                	je     76b8 <fwp_task_dispose+0xc8>
    7649:	48 8b 15 a8 25 06 00 	mov    0x625a8(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7650:	48 89 d8             	mov    %rbx,%rax
    7653:	48 2b 05 76 25 06 00 	sub    0x62576(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    765a:	48 c1 e2 10          	shl    $0x10,%rdx
    765e:	48 39 d0             	cmp    %rdx,%rax
    7661:	73 4c                	jae    76af <fwp_task_dispose+0xbf>
    7663:	48 89 c2             	mov    %rax,%rdx
    7666:	48 c1 ea 10          	shr    $0x10,%rdx
    766a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    766e:	48 8b 15 a3 25 06 00 	mov    0x625a3(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7675:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7679:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    767d:	48 85 c9             	test   %rcx,%rcx
    7680:	74 2d                	je     76af <fwp_task_dispose+0xbf>
    7682:	0f b6 32             	movzbl (%rdx),%esi
    7685:	40 80 fe 02          	cmp    $0x2,%sil
    7689:	74 3d                	je     76c8 <fwp_task_dispose+0xd8>
    768b:	40 80 fe 01          	cmp    $0x1,%sil
    768f:	75 1e                	jne    76af <fwp_task_dispose+0xbf>
    7691:	8b 72 18             	mov    0x18(%rdx),%esi
    7694:	0f b7 c0             	movzwl %ax,%eax
    7697:	8b 52 1c             	mov    0x1c(%rdx),%edx
    769a:	48 0f af c6          	imul   %rsi,%rax
    769e:	48 c1 e8 20          	shr    $0x20,%rax
    76a2:	48 39 d0             	cmp    %rdx,%rax
    76a5:	73 08                	jae    76af <fwp_task_dispose+0xbf>
    76a7:	48 01 c1             	add    %rax,%rcx
    76aa:	80 39 01             	cmpb   $0x1,(%rcx)
    76ad:	74 09                	je     76b8 <fwp_task_dispose+0xc8>
    76af:	5b                   	pop    %rbx
    76b0:	c3                   	ret
    76b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76b8:	48 89 df             	mov    %rbx,%rdi
    76bb:	5b                   	pop    %rbx
    76bc:	e9 4f e3 ff ff       	jmp    5a10 <fwp_mem_free>
    76c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76c8:	66 85 c0             	test   %ax,%ax
    76cb:	74 dd                	je     76aa <fwp_task_dispose+0xba>
    76cd:	5b                   	pop    %rbx
    76ce:	c3                   	ret
    76cf:	90                   	nop

00000000000076d0 <fwp_free_zombie>:
    76d0:	48 8b 15 19 11 06 00 	mov    0x61119(%rip),%rdx        # 687f0 <fwp_zombie>
    76d7:	48 85 d2             	test   %rdx,%rdx
    76da:	0f 84 98 00 00 00    	je     7778 <fwp_free_zombie+0xa8>
    76e0:	48 3b 15 19 11 06 00 	cmp    0x61119(%rip),%rdx        # 68800 <fwp_cur>
    76e7:	0f 84 8b 00 00 00    	je     7778 <fwp_free_zombie+0xa8>
    76ed:	48 83 ec 18          	sub    $0x18,%rsp
    76f1:	48 63 05 dc 0a 06 00 	movslq 0x60adc(%rip),%rax        # 681d4 <fwp_stack_pool_n>
    76f8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    76fc:	83 f8 3f             	cmp    $0x3f,%eax
    76ff:	7f 7f                	jg     7780 <fwp_free_zombie+0xb0>
    7701:	8d 48 01             	lea    0x1(%rax),%ecx
    7704:	89 0d ca 0a 06 00    	mov    %ecx,0x60aca(%rip)        # 681d4 <fwp_stack_pool_n>
    770a:	48 8d 0d cf 0a 06 00 	lea    0x60acf(%rip),%rcx        # 681e0 <fwp_stack_pool>
    7711:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7715:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    771c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7720:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7727:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    772b:	48 85 c9             	test   %rcx,%rcx
    772e:	0f 84 fc 00 00 00    	je     7830 <fwp_free_zombie+0x160>
    7734:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    773b:	48 85 c0             	test   %rax,%rax
    773e:	74 07                	je     7747 <fwp_free_zombie+0x77>
    7740:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7747:	8b 42 5c             	mov    0x5c(%rdx),%eax
    774a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    774e:	48 c7 05 97 10 06 00 	movq   $0x0,0x61097(%rip)        # 687f0 <fwp_zombie>
    7755:	00 00 00 00 
    7759:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7760:	85 c0                	test   %eax,%eax
    7762:	74 34                	je     7798 <fwp_free_zombie+0xc8>
    7764:	83 f8 01             	cmp    $0x1,%eax
    7767:	0f 84 b3 00 00 00    	je     7820 <fwp_free_zombie+0x150>
    776d:	48 83 c4 18          	add    $0x18,%rsp
    7771:	c3                   	ret
    7772:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7778:	c3                   	ret
    7779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7780:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7784:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7789:	e8 32 be ff ff       	call   35c0 <munmap@plt>
    778e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7793:	eb 80                	jmp    7715 <fwp_free_zombie+0x45>
    7795:	0f 1f 00             	nopl   (%rax)
    7798:	48 8b 0d 59 24 06 00 	mov    0x62459(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    779f:	48 89 d0             	mov    %rdx,%rax
    77a2:	48 2b 05 27 24 06 00 	sub    0x62427(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    77a9:	48 c1 e1 10          	shl    $0x10,%rcx
    77ad:	48 39 c8             	cmp    %rcx,%rax
    77b0:	73 bb                	jae    776d <fwp_free_zombie+0x9d>
    77b2:	48 89 c1             	mov    %rax,%rcx
    77b5:	48 c1 e9 10          	shr    $0x10,%rcx
    77b9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    77bd:	48 8b 0d 54 24 06 00 	mov    0x62454(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    77c4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    77c8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    77cc:	48 85 c9             	test   %rcx,%rcx
    77cf:	74 9c                	je     776d <fwp_free_zombie+0x9d>
    77d1:	0f b6 3e             	movzbl (%rsi),%edi
    77d4:	40 80 ff 02          	cmp    $0x2,%dil
    77d8:	74 66                	je     7840 <fwp_free_zombie+0x170>
    77da:	40 80 ff 01          	cmp    $0x1,%dil
    77de:	75 8d                	jne    776d <fwp_free_zombie+0x9d>
    77e0:	8b 7e 18             	mov    0x18(%rsi),%edi
    77e3:	0f b7 c0             	movzwl %ax,%eax
    77e6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    77e9:	48 0f af c7          	imul   %rdi,%rax
    77ed:	48 c1 e8 20          	shr    $0x20,%rax
    77f1:	48 39 f0             	cmp    %rsi,%rax
    77f4:	0f 83 73 ff ff ff    	jae    776d <fwp_free_zombie+0x9d>
    77fa:	48 01 c1             	add    %rax,%rcx
    77fd:	0f b6 01             	movzbl (%rcx),%eax
    7800:	84 c0                	test   %al,%al
    7802:	0f 84 65 ff ff ff    	je     776d <fwp_free_zombie+0x9d>
    7808:	3c 01                	cmp    $0x1,%al
    780a:	74 14                	je     7820 <fwp_free_zombie+0x150>
    780c:	3c ff                	cmp    $0xff,%al
    780e:	74 3b                	je     784b <fwp_free_zombie+0x17b>
    7810:	83 e8 01             	sub    $0x1,%eax
    7813:	88 01                	mov    %al,(%rcx)
    7815:	e9 53 ff ff ff       	jmp    776d <fwp_free_zombie+0x9d>
    781a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7820:	48 89 d7             	mov    %rdx,%rdi
    7823:	48 83 c4 18          	add    $0x18,%rsp
    7827:	e9 c4 fd ff ff       	jmp    75f0 <fwp_task_dispose>
    782c:	0f 1f 40 00          	nopl   0x0(%rax)
    7830:	48 89 05 91 0f 06 00 	mov    %rax,0x60f91(%rip)        # 687c8 <fwp_tasks_active>
    7837:	e9 ff fe ff ff       	jmp    773b <fwp_free_zombie+0x6b>
    783c:	0f 1f 40 00          	nopl   0x0(%rax)
    7840:	66 85 c0             	test   %ax,%ax
    7843:	0f 85 24 ff ff ff    	jne    776d <fwp_free_zombie+0x9d>
    7849:	eb b2                	jmp    77fd <fwp_free_zombie+0x12d>
    784b:	48 89 ca             	mov    %rcx,%rdx
    784e:	48 8d 35 cb 0f 06 00 	lea    0x60fcb(%rip),%rsi        # 68820 <fwp_heap>
    7855:	48 c1 ea 11          	shr    $0x11,%rdx
    7859:	48 31 ca             	xor    %rcx,%rdx
    785c:	48 89 d0             	mov    %rdx,%rax
    785f:	48 c1 e8 09          	shr    $0x9,%rax
    7863:	48 31 c2             	xor    %rax,%rdx
    7866:	0f b6 d2             	movzbl %dl,%edx
    7869:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7870:	00 
    7871:	48 85 c0             	test   %rax,%rax
    7874:	75 13                	jne    7889 <fwp_free_zombie+0x1b9>
    7876:	eb 4c                	jmp    78c4 <fwp_free_zombie+0x1f4>
    7878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    787f:	00 
    7880:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7884:	48 85 c0             	test   %rax,%rax
    7887:	74 3b                	je     78c4 <fwp_free_zombie+0x1f4>
    7889:	48 89 c2             	mov    %rax,%rdx
    788c:	48 39 08             	cmp    %rcx,(%rax)
    788f:	75 ef                	jne    7880 <fwp_free_zombie+0x1b0>
    7891:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7895:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7899:	48 89 50 08          	mov    %rdx,0x8(%rax)
    789d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    78a4:	0f 85 c3 fe ff ff    	jne    776d <fwp_free_zombie+0x9d>
    78aa:	48 89 cf             	mov    %rcx,%rdi
    78ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    78b2:	e8 19 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    78b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    78bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    78bf:	e9 a9 fe ff ff       	jmp    776d <fwp_free_zombie+0x9d>
    78c4:	48 8d 3d 15 51 00 00 	lea    0x5115(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    78cb:	e8 80 cb ff ff       	call   4450 <fwp_trap>

00000000000078d0 <fwp_block>:
    78d0:	48 83 ec 08          	sub    $0x8,%rsp
    78d4:	48 8b 05 0d 0f 06 00 	mov    0x60f0d(%rip),%rax        # 687e8 <fwp_ready_head>
    78db:	48 85 c0             	test   %rax,%rax
    78de:	0f 84 1c 01 00 00    	je     7a00 <fwp_block+0x130>
    78e4:	90                   	nop
    78e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78ec:	00 00 00 00 
    78f0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    78f7:	48 89 15 ea 0e 06 00 	mov    %rdx,0x60eea(%rip)        # 687e8 <fwp_ready_head>
    78fe:	48 85 d2             	test   %rdx,%rdx
    7901:	0f 84 19 01 00 00    	je     7a20 <fwp_block+0x150>
    7907:	48 8b 15 f2 0e 06 00 	mov    0x60ef2(%rip),%rdx        # 68800 <fwp_cur>
    790e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7912:	48 39 c2             	cmp    %rax,%rdx
    7915:	0f 84 d5 00 00 00    	je     79f0 <fwp_block+0x120>
    791b:	48 8b 0d 66 2b 06 00 	mov    0x62b66(%rip),%rcx        # 6a488 <fwp_state_owners>
    7922:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7926:	48 89 05 d3 0e 06 00 	mov    %rax,0x60ed3(%rip)        # 68800 <fwp_cur>
    792d:	f3 0f 7e 05 7b 2b 06 	movq   0x62b7b(%rip),%xmm0        # 6a4b0 <fwp_foreign_callbacks>
    7934:	00 
    7935:	0f 16 05 64 2b 06 00 	movhps 0x62b64(%rip),%xmm0        # 6a4a0 <fwp_state>
    793c:	f3 0f 7e 0d 64 2b 06 	movq   0x62b64(%rip),%xmm1        # 6a4a8 <fwp_handlers>
    7943:	00 
    7944:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    794b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7952:	0f 16 0d 5f 2b 06 00 	movhps 0x62b5f(%rip),%xmm1        # 6a4b8 <fwp_cleanups>
    7959:	f3 0f 7e 05 37 2b 06 	movq   0x62b37(%rip),%xmm0        # 6a498 <fwp_state_len>
    7960:	00 
    7961:	0f 16 05 28 2b 06 00 	movhps 0x62b28(%rip),%xmm0        # 6a490 <fwp_state_cap>
    7968:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    796f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7976:	48 8b 70 08          	mov    0x8(%rax),%rsi
    797a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7981:	48 89 0d 20 2b 06 00 	mov    %rcx,0x62b20(%rip)        # 6a4a8 <fwp_handlers>
    7988:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    798f:	48 89 0d 22 2b 06 00 	mov    %rcx,0x62b22(%rip)        # 6a4b8 <fwp_cleanups>
    7996:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    799d:	48 89 0d 0c 2b 06 00 	mov    %rcx,0x62b0c(%rip)        # 6a4b0 <fwp_foreign_callbacks>
    79a4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    79ab:	48 89 0d ee 2a 06 00 	mov    %rcx,0x62aee(%rip)        # 6a4a0 <fwp_state>
    79b2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    79b9:	48 89 0d d8 2a 06 00 	mov    %rcx,0x62ad8(%rip)        # 6a498 <fwp_state_len>
    79c0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    79c7:	48 89 0d c2 2a 06 00 	mov    %rcx,0x62ac2(%rip)        # 6a490 <fwp_state_cap>
    79ce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    79d5:	48 89 0d ac 2a 06 00 	mov    %rcx,0x62aac(%rip)        # 6a488 <fwp_state_owners>
    79dc:	e8 9f ba ff ff       	call   3480 <swapcontext@plt>
    79e1:	f3 0f 1e fa          	endbr64
    79e5:	e8 e6 fc ff ff       	call   76d0 <fwp_free_zombie>
    79ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79f0:	8b 05 da 07 06 00    	mov    0x607da(%rip),%eax        # 681d0 <fwp_slice>
    79f6:	85 c0                	test   %eax,%eax
    79f8:	74 36                	je     7a30 <fwp_block+0x160>
    79fa:	48 83 c4 08          	add    $0x8,%rsp
    79fe:	c3                   	ret
    79ff:	90                   	nop
    7a00:	e8 0b da ff ff       	call   5410 <fwp_poll_events>
    7a05:	48 8b 05 dc 0d 06 00 	mov    0x60ddc(%rip),%rax        # 687e8 <fwp_ready_head>
    7a0c:	48 85 c0             	test   %rax,%rax
    7a0f:	0f 85 db fe ff ff    	jne    78f0 <fwp_block+0x20>
    7a15:	eb e9                	jmp    7a00 <fwp_block+0x130>
    7a17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a1e:	00 00 
    7a20:	48 c7 05 b5 0d 06 00 	movq   $0x0,0x60db5(%rip)        # 687e0 <fwp_ready_tail>
    7a27:	00 00 00 00 
    7a2b:	e9 d7 fe ff ff       	jmp    7907 <fwp_block+0x37>
    7a30:	48 8d 3d a8 47 00 00 	lea    0x47a8(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    7a37:	e8 54 b9 ff ff       	call   3390 <getenv@plt>
    7a3c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7a41:	48 85 c0             	test   %rax,%rax
    7a44:	74 05                	je     7a4b <fwp_block+0x17b>
    7a46:	80 38 00             	cmpb   $0x0,(%rax)
    7a49:	75 0b                	jne    7a56 <fwp_block+0x186>
    7a4b:	89 15 7f 07 06 00    	mov    %edx,0x6077f(%rip)        # 681d0 <fwp_slice>
    7a51:	48 83 c4 08          	add    $0x8,%rsp
    7a55:	c3                   	ret
    7a56:	ba 0a 00 00 00       	mov    $0xa,%edx
    7a5b:	31 f6                	xor    %esi,%esi
    7a5d:	48 89 c7             	mov    %rax,%rdi
    7a60:	e8 db ba ff ff       	call   3540 <strtoll@plt>
    7a65:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7a69:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7a70:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7a75:	0f 46 d0             	cmovbe %eax,%edx
    7a78:	eb d1                	jmp    7a4b <fwp_block+0x17b>
    7a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007a80 <fwp_drop4>:
    7a80:	48 8b 15 71 21 06 00 	mov    0x62171(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7a87:	48 89 f8             	mov    %rdi,%rax
    7a8a:	48 2b 05 3f 21 06 00 	sub    0x6213f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7a91:	48 c1 e2 10          	shl    $0x10,%rdx
    7a95:	48 39 d0             	cmp    %rdx,%rax
    7a98:	0f 83 52 01 00 00    	jae    7bf0 <fwp_drop4+0x170>
    7a9e:	48 83 ec 18          	sub    $0x18,%rsp
    7aa2:	4c 8d 05 77 0d 06 00 	lea    0x60d77(%rip),%r8        # 68820 <fwp_heap>
    7aa9:	48 89 c2             	mov    %rax,%rdx
    7aac:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7ab3:	48 c1 ea 10          	shr    $0x10,%rdx
    7ab7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7abb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7abf:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ac3:	48 85 d2             	test   %rdx,%rdx
    7ac6:	74 46                	je     7b0e <fwp_drop4+0x8e>
    7ac8:	44 0f b6 09          	movzbl (%rcx),%r9d
    7acc:	41 80 f9 02          	cmp    $0x2,%r9b
    7ad0:	0f 84 ca 00 00 00    	je     7ba0 <fwp_drop4+0x120>
    7ad6:	41 80 f9 01          	cmp    $0x1,%r9b
    7ada:	75 32                	jne    7b0e <fwp_drop4+0x8e>
    7adc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7ae0:	0f b7 c0             	movzwl %ax,%eax
    7ae3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ae6:	49 0f af c1          	imul   %r9,%rax
    7aea:	48 c1 e8 20          	shr    $0x20,%rax
    7aee:	48 39 c8             	cmp    %rcx,%rax
    7af1:	73 1b                	jae    7b0e <fwp_drop4+0x8e>
    7af3:	48 01 c2             	add    %rax,%rdx
    7af6:	0f b6 02             	movzbl (%rdx),%eax
    7af9:	84 c0                	test   %al,%al
    7afb:	74 11                	je     7b0e <fwp_drop4+0x8e>
    7afd:	3c 01                	cmp    $0x1,%al
    7aff:	74 17                	je     7b18 <fwp_drop4+0x98>
    7b01:	3c ff                	cmp    $0xff,%al
    7b03:	0f 84 ef 00 00 00    	je     7bf8 <fwp_drop4+0x178>
    7b09:	83 e8 01             	sub    $0x1,%eax
    7b0c:	88 02                	mov    %al,(%rdx)
    7b0e:	48 83 c4 18          	add    $0x18,%rsp
    7b12:	c3                   	ret
    7b13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b18:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7b1c:	0f 88 8e 00 00 00    	js     7bb0 <fwp_drop4+0x130>
    7b22:	48 8b 15 cf 20 06 00 	mov    0x620cf(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7b29:	48 89 f8             	mov    %rdi,%rax
    7b2c:	48 2b 05 9d 20 06 00 	sub    0x6209d(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7b33:	48 c1 e2 10          	shl    $0x10,%rdx
    7b37:	48 39 d0             	cmp    %rdx,%rax
    7b3a:	73 d2                	jae    7b0e <fwp_drop4+0x8e>
    7b3c:	48 89 c2             	mov    %rax,%rdx
    7b3f:	48 c1 ea 10          	shr    $0x10,%rdx
    7b43:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b47:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7b4b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7b4f:	48 85 c9             	test   %rcx,%rcx
    7b52:	74 ba                	je     7b0e <fwp_drop4+0x8e>
    7b54:	0f b6 32             	movzbl (%rdx),%esi
    7b57:	40 80 fe 02          	cmp    $0x2,%sil
    7b5b:	74 33                	je     7b90 <fwp_drop4+0x110>
    7b5d:	40 80 fe 01          	cmp    $0x1,%sil
    7b61:	75 ab                	jne    7b0e <fwp_drop4+0x8e>
    7b63:	8b 72 18             	mov    0x18(%rdx),%esi
    7b66:	0f b7 c0             	movzwl %ax,%eax
    7b69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b6c:	48 0f af c6          	imul   %rsi,%rax
    7b70:	48 c1 e8 20          	shr    $0x20,%rax
    7b74:	48 39 d0             	cmp    %rdx,%rax
    7b77:	73 95                	jae    7b0e <fwp_drop4+0x8e>
    7b79:	48 01 c1             	add    %rax,%rcx
    7b7c:	80 39 01             	cmpb   $0x1,(%rcx)
    7b7f:	75 8d                	jne    7b0e <fwp_drop4+0x8e>
    7b81:	48 83 c4 18          	add    $0x18,%rsp
    7b85:	e9 86 de ff ff       	jmp    5a10 <fwp_mem_free>
    7b8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b90:	66 85 c0             	test   %ax,%ax
    7b93:	74 e7                	je     7b7c <fwp_drop4+0xfc>
    7b95:	48 83 c4 18          	add    $0x18,%rsp
    7b99:	c3                   	ret
    7b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ba0:	66 85 c0             	test   %ax,%ax
    7ba3:	0f 84 4d ff ff ff    	je     7af6 <fwp_drop4+0x76>
    7ba9:	48 83 c4 18          	add    $0x18,%rsp
    7bad:	c3                   	ret
    7bae:	66 90                	xchg   %ax,%ax
    7bb0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7bb4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7bb9:	e8 72 ef ff ff       	call   6b30 <fwp_rc_free_arr>
    7bbe:	4c 8d 05 5b 0c 06 00 	lea    0x60c5b(%rip),%r8        # 68820 <fwp_heap>
    7bc5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7bd1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7bd8:	48 c1 e2 10          	shl    $0x10,%rdx
    7bdc:	48 39 d0             	cmp    %rdx,%rax
    7bdf:	0f 83 29 ff ff ff    	jae    7b0e <fwp_drop4+0x8e>
    7be5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7bea:	e9 ba fe ff ff       	jmp    7aa9 <fwp_drop4+0x29>
    7bef:	90                   	nop
    7bf0:	c3                   	ret
    7bf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bf8:	48 89 d0             	mov    %rdx,%rax
    7bfb:	48 c1 e8 11          	shr    $0x11,%rax
    7bff:	48 31 d0             	xor    %rdx,%rax
    7c02:	48 89 c1             	mov    %rax,%rcx
    7c05:	48 c1 e9 09          	shr    $0x9,%rcx
    7c09:	48 31 c8             	xor    %rcx,%rax
    7c0c:	0f b6 c8             	movzbl %al,%ecx
    7c0f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7c16:	00 
    7c17:	48 85 c0             	test   %rax,%rax
    7c1a:	75 0d                	jne    7c29 <fwp_drop4+0x1a9>
    7c1c:	eb 46                	jmp    7c64 <fwp_drop4+0x1e4>
    7c1e:	66 90                	xchg   %ax,%ax
    7c20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c24:	48 85 c0             	test   %rax,%rax
    7c27:	74 3b                	je     7c64 <fwp_drop4+0x1e4>
    7c29:	48 89 c1             	mov    %rax,%rcx
    7c2c:	48 39 10             	cmp    %rdx,(%rax)
    7c2f:	75 ef                	jne    7c20 <fwp_drop4+0x1a0>
    7c31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c44:	0f 85 c4 fe ff ff    	jne    7b0e <fwp_drop4+0x8e>
    7c4a:	48 89 d7             	mov    %rdx,%rdi
    7c4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c52:	e8 79 db ff ff       	call   57d0 <fwp_rc_forget_slot>
    7c57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c5f:	e9 aa fe ff ff       	jmp    7b0e <fwp_drop4+0x8e>
    7c64:	48 8d 3d 75 4d 00 00 	lea    0x4d75(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    7c6b:	e8 e0 c7 ff ff       	call   4450 <fwp_trap>

0000000000007c70 <fwp_caps161>:
    7c70:	f3 0f 1e fa          	endbr64
    7c74:	85 f6                	test   %esi,%esi
    7c76:	74 08                	je     7c80 <fwp_caps161+0x10>
    7c78:	c3                   	ret
    7c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c80:	48 8b 15 71 1f 06 00 	mov    0x61f71(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7c87:	48 89 f8             	mov    %rdi,%rax
    7c8a:	48 2b 05 3f 1f 06 00 	sub    0x61f3f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7c91:	48 c1 e2 10          	shl    $0x10,%rdx
    7c95:	48 39 d0             	cmp    %rdx,%rax
    7c98:	73 de                	jae    7c78 <fwp_caps161+0x8>
    7c9a:	48 89 c2             	mov    %rax,%rdx
    7c9d:	48 c1 ea 10          	shr    $0x10,%rdx
    7ca1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ca5:	48 8b 15 6c 1f 06 00 	mov    0x61f6c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7cac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7cb0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7cb4:	48 85 c9             	test   %rcx,%rcx
    7cb7:	74 bf                	je     7c78 <fwp_caps161+0x8>
    7cb9:	0f b6 32             	movzbl (%rdx),%esi
    7cbc:	40 80 fe 02          	cmp    $0x2,%sil
    7cc0:	74 2e                	je     7cf0 <fwp_caps161+0x80>
    7cc2:	40 80 fe 01          	cmp    $0x1,%sil
    7cc6:	75 b0                	jne    7c78 <fwp_caps161+0x8>
    7cc8:	8b 72 18             	mov    0x18(%rdx),%esi
    7ccb:	0f b7 c0             	movzwl %ax,%eax
    7cce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cd1:	48 0f af c6          	imul   %rsi,%rax
    7cd5:	48 c1 e8 20          	shr    $0x20,%rax
    7cd9:	48 39 d0             	cmp    %rdx,%rax
    7cdc:	73 9a                	jae    7c78 <fwp_caps161+0x8>
    7cde:	48 01 c1             	add    %rax,%rcx
    7ce1:	80 39 01             	cmpb   $0x1,(%rcx)
    7ce4:	75 92                	jne    7c78 <fwp_caps161+0x8>
    7ce6:	e9 25 dd ff ff       	jmp    5a10 <fwp_mem_free>
    7ceb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7cf0:	66 85 c0             	test   %ax,%ax
    7cf3:	74 ec                	je     7ce1 <fwp_caps161+0x71>
    7cf5:	c3                   	ret
    7cf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cfd:	00 00 00 

0000000000007d00 <f12>:
    7d00:	41 57                	push   %r15
    7d02:	41 56                	push   %r14
    7d04:	41 55                	push   %r13
    7d06:	4c 8d 2d b3 f7 ff ff 	lea    -0x84d(%rip),%r13        # 74c0 <fwp_tape_scope_release>
    7d0d:	41 54                	push   %r12
    7d0f:	55                   	push   %rbp
    7d10:	53                   	push   %rbx
    7d11:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    7d18:	48 8b 05 99 27 06 00 	mov    0x62799(%rip),%rax        # 6a4b8 <fwp_cleanups>
    7d1f:	48 8b 15 d2 1e 06 00 	mov    0x61ed2(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7d26:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    7d2d:	00 00 
    7d2f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    7d36:	00 
    7d37:	48 89 fd             	mov    %rdi,%rbp
    7d3a:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7d3f:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7d46:	ff 
    7d47:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7d4c:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7d51:	48 c1 e2 10          	shl    $0x10,%rdx
    7d55:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7d5a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7d5f:	48 8d 05 aa 82 00 00 	lea    0x82aa(%rip),%rax        # 10010 <fc23>
    7d66:	48 2b 05 63 1e 06 00 	sub    0x61e63(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7d6d:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7d72:	4c 89 3d 3f 27 06 00 	mov    %r15,0x6273f(%rip)        # 6a4b8 <fwp_cleanups>
    7d79:	48 39 d0             	cmp    %rdx,%rax
    7d7c:	73 6d                	jae    7deb <f12+0xeb>
    7d7e:	48 89 c2             	mov    %rax,%rdx
    7d81:	48 c1 ea 10          	shr    $0x10,%rdx
    7d85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d89:	48 8b 15 88 1e 06 00 	mov    0x61e88(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7d90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d94:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d98:	48 85 ff             	test   %rdi,%rdi
    7d9b:	74 4e                	je     7deb <f12+0xeb>
    7d9d:	0f b6 0a             	movzbl (%rdx),%ecx
    7da0:	80 f9 02             	cmp    $0x2,%cl
    7da3:	0f 84 57 0f 00 00    	je     8d00 <f12+0x1000>
    7da9:	80 f9 01             	cmp    $0x1,%cl
    7dac:	75 3d                	jne    7deb <f12+0xeb>
    7dae:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7db1:	0f b7 c0             	movzwl %ax,%eax
    7db4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7db7:	48 0f af c1          	imul   %rcx,%rax
    7dbb:	48 c1 e8 20          	shr    $0x20,%rax
    7dbf:	48 39 d0             	cmp    %rdx,%rax
    7dc2:	73 27                	jae    7deb <f12+0xeb>
    7dc4:	48 01 c7             	add    %rax,%rdi
    7dc7:	0f b6 07             	movzbl (%rdi),%eax
    7dca:	84 c0                	test   %al,%al
    7dcc:	74 1d                	je     7deb <f12+0xeb>
    7dce:	44 8b 05 13 27 06 00 	mov    0x62713(%rip),%r8d        # 6a4e8 <iteration_active>
    7dd5:	45 85 c0             	test   %r8d,%r8d
    7dd8:	0f 85 52 10 00 00    	jne    8e30 <f12+0x1130>
    7dde:	3c fd                	cmp    $0xfd,%al
    7de0:	0f 87 06 12 00 00    	ja     8fec <f12+0x12ec>
    7de6:	83 c0 01             	add    $0x1,%eax
    7de9:	88 07                	mov    %al,(%rdi)
    7deb:	48 8d 3d 1e 82 00 00 	lea    0x821e(%rip),%rdi        # 10010 <fc23>
    7df2:	e8 59 f3 ff ff       	call   7150 <fwp_closure_drop>
    7df7:	48 85 ed             	test   %rbp,%rbp
    7dfa:	0f 84 41 11 00 00    	je     8f41 <f12+0x1241>
    7e00:	48 89 e8             	mov    %rbp,%rax
    7e03:	31 d2                	xor    %edx,%edx
    7e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e0c:	00 00 00 00 
    7e10:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e14:	48 83 c2 01          	add    $0x1,%rdx
    7e18:	48 85 c0             	test   %rax,%rax
    7e1b:	75 f3                	jne    7e10 <f12+0x110>
    7e1d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7e24:	0f 87 50 12 00 00    	ja     907a <f12+0x137a>
    7e2a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7e2f:	8b 35 2b 82 00 00    	mov    0x822b(%rip),%esi        # 10060 <registered_finish.0>
    7e35:	85 f6                	test   %esi,%esi
    7e37:	0f 84 93 0e 00 00    	je     8cd0 <f12+0xfd0>
    7e3d:	48 8b 1d 94 82 01 00 	mov    0x18294(%rip),%rbx        # 200d8 <fwp_tape_next_slot>
    7e44:	4c 8b 25 9d 82 01 00 	mov    0x1829d(%rip),%r12        # 200e8 <fwp_ntapes>
    7e4b:	4c 39 e3             	cmp    %r12,%rbx
    7e4e:	0f 8d d4 00 00 00    	jge    7f28 <f12+0x228>
    7e54:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7e58:	48 03 05 91 82 01 00 	add    0x18291(%rip),%rax        # 200f0 <fwp_tapes>
    7e5f:	90                   	nop
    7e60:	8b 48 04             	mov    0x4(%rax),%ecx
    7e63:	85 c9                	test   %ecx,%ecx
    7e65:	75 0c                	jne    7e73 <f12+0x173>
    7e67:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7e6d:	0f 86 b5 00 00 00    	jbe    7f28 <f12+0x228>
    7e73:	48 83 c3 01          	add    $0x1,%rbx
    7e77:	48 83 c0 68          	add    $0x68,%rax
    7e7b:	4c 39 e3             	cmp    %r12,%rbx
    7e7e:	75 e0                	jne    7e60 <f12+0x160>
    7e80:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    7e87:	0f 8f 62 12 00 00    	jg     90ef <f12+0x13ef>
    7e8d:	4c 39 25 4c 82 01 00 	cmp    %r12,0x1824c(%rip)        # 200e0 <fwp_tapes_cap>
    7e94:	4c 8b 35 55 82 01 00 	mov    0x18255(%rip),%r14        # 200f0 <fwp_tapes>
    7e9b:	75 4b                	jne    7ee8 <f12+0x1e8>
    7e9d:	4d 85 e4             	test   %r12,%r12
    7ea0:	0f 84 00 11 00 00    	je     8fa6 <f12+0x12a6>
    7ea6:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    7eaa:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7eaf:	48 39 c3             	cmp    %rax,%rbx
    7eb2:	48 0f 4f d8          	cmovg  %rax,%rbx
    7eb6:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    7eba:	31 d2                	xor    %edx,%edx
    7ebc:	4c 89 f7             	mov    %r14,%rdi
    7ebf:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7ec4:	e8 c7 d2 ff ff       	call   5190 <ad_raw_realloc>
    7ec9:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7ece:	48 85 c0             	test   %rax,%rax
    7ed1:	49 89 c6             	mov    %rax,%r14
    7ed4:	0f 84 db 11 00 00    	je     90b5 <f12+0x13b5>
    7eda:	48 89 05 0f 82 01 00 	mov    %rax,0x1820f(%rip)        # 200f0 <fwp_tapes>
    7ee1:	48 89 1d f8 81 01 00 	mov    %rbx,0x181f8(%rip)        # 200e0 <fwp_tapes_cap>
    7ee8:	49 6b c4 68          	imul   $0x68,%r12,%rax
    7eec:	4c 89 e3             	mov    %r12,%rbx
    7eef:	4c 01 f0             	add    %r14,%rax
    7ef2:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7ef6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7efd:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7f01:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7f08:	00 
    7f09:	48 29 f8             	sub    %rdi,%rax
    7f0c:	8d 48 68             	lea    0x68(%rax),%ecx
    7f0f:	31 c0                	xor    %eax,%eax
    7f11:	c1 e9 03             	shr    $0x3,%ecx
    7f14:	f3 48 ab             	rep stos %rax,(%rdi)
    7f17:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    7f1c:	48 89 05 c5 81 01 00 	mov    %rax,0x181c5(%rip)        # 200e8 <fwp_ntapes>
    7f23:	eb 13                	jmp    7f38 <f12+0x238>
    7f25:	0f 1f 00             	nopl   (%rax)
    7f28:	49 39 dc             	cmp    %rbx,%r12
    7f2b:	0f 84 4f ff ff ff    	je     7e80 <f12+0x180>
    7f31:	4c 8b 35 b8 81 01 00 	mov    0x181b8(%rip),%r14        # 200f0 <fwp_tapes>
    7f38:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    7f3c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7f40:	48 8d 3d 19 42 00 00 	lea    0x4219(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    7f47:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7f4b:	4d 01 f4             	add    %r14,%r12
    7f4e:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    7f55:	00 00 
    7f57:	e8 34 b4 ff ff       	call   3390 <getenv@plt>
    7f5c:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7f61:	48 85 c0             	test   %rax,%rax
    7f64:	74 09                	je     7f6f <f12+0x26f>
    7f66:	80 38 30             	cmpb   $0x30,(%rax)
    7f69:	0f 84 11 07 00 00    	je     8680 <f12+0x980>
    7f6f:	48 83 3d 11 81 01 00 	cmpq   $0x0,0x18111(%rip)        # 20088 <fwp_tape_cached_bytes>
    7f76:	00 
    7f77:	0f 85 e3 0d 00 00    	jne    8d60 <f12+0x1060>
    7f7d:	41 8b 04 24          	mov    (%r12),%eax
    7f81:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    7f85:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    7f8c:	00 00 
    7f8e:	48 89 3d 43 81 01 00 	mov    %rdi,0x18143(%rip)        # 200d8 <fwp_tape_next_slot>
    7f95:	8d 70 01             	lea    0x1(%rax),%esi
    7f98:	48 8b 05 19 25 06 00 	mov    0x62519(%rip),%rax        # 6a4b8 <fwp_cleanups>
    7f9f:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    7fa6:	00 00 
    7fa8:	41 89 34 24          	mov    %esi,(%r12)
    7fac:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    7fb3:	ff ff 
    7fb5:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    7fbb:	48 85 c0             	test   %rax,%rax
    7fbe:	75 1c                	jne    7fdc <f12+0x2dc>
    7fc0:	e9 47 11 00 00       	jmp    910c <f12+0x140c>
    7fc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fcc:	00 00 00 00 
    7fd0:	48 8b 00             	mov    (%rax),%rax
    7fd3:	48 85 c0             	test   %rax,%rax
    7fd6:	0f 84 30 11 00 00    	je     910c <f12+0x140c>
    7fdc:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    7fe0:	75 ee                	jne    7fd0 <f12+0x2d0>
    7fe2:	48 8b 50 10          	mov    0x10(%rax),%rdx
    7fe6:	89 d9                	mov    %ebx,%ecx
    7fe8:	48 63 02             	movslq (%rdx),%rax
    7feb:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    7ff0:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    7ff5:	85 c0                	test   %eax,%eax
    7ff7:	78 09                	js     8002 <f12+0x302>
    7ff9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7ffd:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8002:	89 0a                	mov    %ecx,(%rdx)
    8004:	48 89 e8             	mov    %rbp,%rax
    8007:	31 c9                	xor    %ecx,%ecx
    8009:	48 85 ed             	test   %rbp,%rbp
    800c:	0f 84 9e 0b 00 00    	je     8bb0 <f12+0xeb0>
    8012:	0f 1f 00             	nopl   (%rax)
    8015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    801c:	00 00 00 00 
    8020:	48 8b 40 10          	mov    0x10(%rax),%rax
    8024:	48 83 c1 01          	add    $0x1,%rcx
    8028:	48 85 c0             	test   %rax,%rax
    802b:	75 f3                	jne    8020 <f12+0x320>
    802d:	48 89 ea             	mov    %rbp,%rdx
    8030:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8034:	48 83 c0 01          	add    $0x1,%rax
    8038:	48 85 d2             	test   %rdx,%rdx
    803b:	75 f3                	jne    8030 <f12+0x330>
    803d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8044:	ff ff 1f 
    8047:	48 39 c2             	cmp    %rax,%rdx
    804a:	0f 82 36 10 00 00    	jb     9086 <f12+0x1386>
    8050:	48 85 c9             	test   %rcx,%rcx
    8053:	0f 8e 57 0b 00 00    	jle    8bb0 <f12+0xeb0>
    8059:	48 39 c1             	cmp    %rax,%rcx
    805c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8060:	49 89 c5             	mov    %rax,%r13
    8063:	48 c1 e8 3c          	shr    $0x3c,%rax
    8067:	0f 85 19 10 00 00    	jne    9086 <f12+0x1386>
    806d:	48 c1 e6 10          	shl    $0x10,%rsi
    8071:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8076:	48 09 fe             	or     %rdi,%rsi
    8079:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8080:	00 
    8081:	49 89 f4             	mov    %rsi,%r12
    8084:	be 02 00 00 00       	mov    $0x2,%esi
    8089:	e8 82 de ff ff       	call   5f10 <fwp_heap_alloc>
    808e:	4c 89 30             	mov    %r14,(%rax)
    8091:	48 8b 15 60 1b 06 00 	mov    0x61b60(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8098:	48 89 c3             	mov    %rax,%rbx
    809b:	48 2b 05 2e 1b 06 00 	sub    0x61b2e(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    80a2:	48 c1 e2 10          	shl    $0x10,%rdx
    80a6:	48 39 d0             	cmp    %rdx,%rax
    80a9:	0f 83 99 0b 00 00    	jae    8c48 <f12+0xf48>
    80af:	48 89 c2             	mov    %rax,%rdx
    80b2:	48 c1 ea 10          	shr    $0x10,%rdx
    80b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80ba:	48 8b 15 57 1b 06 00 	mov    0x61b57(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    80c1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    80c5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    80c9:	48 85 d2             	test   %rdx,%rdx
    80cc:	74 38                	je     8106 <f12+0x406>
    80ce:	0f b6 31             	movzbl (%rcx),%esi
    80d1:	40 80 fe 02          	cmp    $0x2,%sil
    80d5:	0f 84 42 0b 00 00    	je     8c1d <f12+0xf1d>
    80db:	40 80 fe 01          	cmp    $0x1,%sil
    80df:	75 25                	jne    8106 <f12+0x406>
    80e1:	8b 71 18             	mov    0x18(%rcx),%esi
    80e4:	0f b7 c0             	movzwl %ax,%eax
    80e7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    80ea:	48 0f af c6          	imul   %rsi,%rax
    80ee:	48 c1 e8 20          	shr    $0x20,%rax
    80f2:	48 39 c8             	cmp    %rcx,%rax
    80f5:	73 0f                	jae    8106 <f12+0x406>
    80f7:	48 01 c2             	add    %rax,%rdx
    80fa:	80 3a ff             	cmpb   $0xff,(%rdx)
    80fd:	0f 84 b2 0e 00 00    	je     8fb5 <f12+0x12b5>
    8103:	c6 02 01             	movb   $0x1,(%rdx)
    8106:	4d 85 ed             	test   %r13,%r13
    8109:	74 68                	je     8173 <f12+0x473>
    810b:	4c 89 e1             	mov    %r12,%rcx
    810e:	48 89 ea             	mov    %rbp,%rdx
    8111:	31 c0                	xor    %eax,%eax
    8113:	48 c1 e1 20          	shl    $0x20,%rcx
    8117:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    811e:	00 
    811f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8126:	00 00 00 00 
    812a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8131:	00 00 00 00 
    8135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    813c:	00 00 00 00 
    8140:	48 89 c6             	mov    %rax,%rsi
    8143:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8148:	48 01 ce             	add    %rcx,%rsi
    814b:	0f 80 1c 0f 00 00    	jo     906d <f12+0x136d>
    8151:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8156:	48 89 c6             	mov    %rax,%rsi
    8159:	48 83 c0 01          	add    $0x1,%rax
    815d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8161:	48 c1 e6 04          	shl    $0x4,%rsi
    8165:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    816a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    816e:	4c 39 e8             	cmp    %r13,%rax
    8171:	72 cd                	jb     8140 <f12+0x440>
    8173:	48 8b 03             	mov    (%rbx),%rax
    8176:	48 d1 e8             	shr    $1,%rax
    8179:	0f 84 e1 0a 00 00    	je     8c60 <f12+0xf60>
    817f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8183:	48 89 d1             	mov    %rdx,%rcx
    8186:	48 c1 e9 3c          	shr    $0x3c,%rcx
    818a:	0f 85 f6 0e 00 00    	jne    9086 <f12+0x1386>
    8190:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8194:	48 89 0c 24          	mov    %rcx,(%rsp)
    8198:	48 85 d2             	test   %rdx,%rdx
    819b:	74 41                	je     81de <f12+0x4de>
    819d:	48 c1 e0 04          	shl    $0x4,%rax
    81a1:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    81a5:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    81aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81b0:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    81b5:	49 8b 76 18          	mov    0x18(%r14),%rsi
    81b9:	49 83 c6 10          	add    $0x10,%r14
    81bd:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    81c1:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    81c6:	e8 05 e5 ff ff       	call   66d0 <w107>
    81cb:	66 48 0f 6e e8       	movq   %rax,%xmm5
    81d0:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    81d4:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    81d9:	4d 39 f5             	cmp    %r14,%r13
    81dc:	75 d2                	jne    81b0 <f12+0x4b0>
    81de:	48 8b 04 24          	mov    (%rsp),%rax
    81e2:	48 89 df             	mov    %rbx,%rdi
    81e5:	48 89 03             	mov    %rax,(%rbx)
    81e8:	e8 53 e6 ff ff       	call   6840 <w164.constprop.0>
    81ed:	48 89 df             	mov    %rbx,%rdi
    81f0:	49 63 dc             	movslq %r12d,%rbx
    81f3:	49 89 c5             	mov    %rax,%r13
    81f6:	e8 85 f8 ff ff       	call   7a80 <fwp_drop4>
    81fb:	48 89 df             	mov    %rbx,%rdi
    81fe:	e8 2d c5 ff ff       	call   4730 <fwp_tape_of>
    8203:	48 89 c6             	mov    %rax,%rsi
    8206:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    820b:	0f 85 ef 0e 00 00    	jne    9100 <f12+0x1400>
    8211:	48 89 c7             	mov    %rax,%rdi
    8214:	e8 77 ba ff ff       	call   3c90 <fwp_tape_unlink_scope>
    8219:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    821d:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8222:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8229:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    822d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8231:	66 49 0f 6e f8       	movq   %r8,%xmm7
    8236:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    823b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8240:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    8244:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8248:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    824e:	77 19                	ja     8269 <f12+0x569>
    8250:	41 0f b7 c4          	movzwl %r12w,%eax
    8254:	83 e8 01             	sub    $0x1,%eax
    8257:	48 98                	cltq
    8259:	48 3b 05 78 7e 01 00 	cmp    0x17e78(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    8260:	7d 07                	jge    8269 <f12+0x569>
    8262:	48 89 05 6f 7e 01 00 	mov    %rax,0x17e6f(%rip)        # 200d8 <fwp_tape_next_slot>
    8269:	48 8b 05 48 22 06 00 	mov    0x62248(%rip),%rax        # 6a4b8 <fwp_cleanups>
    8270:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8274:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    827b:	00 
    827c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8283:	00 
    8284:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8288:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    828f:	00 
    8290:	48 8d 05 c9 cf ff ff 	lea    -0x3037(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    8297:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    829e:	00 
    829f:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    82a6:	00 
    82a7:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    82ab:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    82af:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    82b6:	00 
    82b7:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    82be:	00 
    82bf:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    82c6:	00 
    82c7:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    82ce:	00 
    82cf:	48 89 05 e2 21 06 00 	mov    %rax,0x621e2(%rip)        # 6a4b8 <fwp_cleanups>
    82d6:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    82dd:	00 
    82de:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    82e5:	00 
    82e6:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    82ed:	00 
    82ee:	4d 85 ed             	test   %r13,%r13
    82f1:	0f 88 19 0a 00 00    	js     8d10 <f12+0x1010>
    82f7:	4c 89 e8             	mov    %r13,%rax
    82fa:	48 c1 f8 20          	sar    $0x20,%rax
    82fe:	48 39 c3             	cmp    %rax,%rbx
    8301:	0f 85 42 0d 00 00    	jne    9049 <f12+0x1349>
    8307:	44 89 e9             	mov    %r13d,%ecx
    830a:	48 39 ca             	cmp    %rcx,%rdx
    830d:	0f 8e 42 0d 00 00    	jle    9055 <f12+0x1355>
    8313:	49 39 ce             	cmp    %rcx,%r14
    8316:	0f 8e 54 09 00 00    	jle    8c70 <f12+0xf70>
    831c:	4d 39 c6             	cmp    %r8,%r14
    831f:	0f 8e b3 0a 00 00    	jle    8dd8 <f12+0x10d8>
    8325:	4c 89 f3             	mov    %r14,%rbx
    8328:	4d 85 c0             	test   %r8,%r8
    832b:	4c 0f 44 c3          	cmove  %rbx,%r8
    832f:	eb 24                	jmp    8355 <f12+0x655>
    8331:	0f 1f 40 00          	nopl   0x0(%rax)
    8335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    833c:	00 00 00 00 
    8340:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    8344:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    834b:	48 89 d8             	mov    %rbx,%rax
    834e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8352:	49 89 c0             	mov    %rax,%r8
    8355:	49 39 d8             	cmp    %rbx,%r8
    8358:	7c e6                	jl     8340 <f12+0x640>
    835a:	4d 85 c9             	test   %r9,%r9
    835d:	0f 84 0d 0b 00 00    	je     8e70 <f12+0x1170>
    8363:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    836a:	00 
    836b:	4c 89 cf             	mov    %r9,%rdi
    836e:	ba 03 00 00 00       	mov    $0x3,%edx
    8373:	4c 89 04 24          	mov    %r8,(%rsp)
    8377:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    837c:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8381:	e8 0a ce ff ff       	call   5190 <ad_raw_realloc>
    8386:	4c 8b 04 24          	mov    (%rsp),%r8
    838a:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8390:	48 85 c0             	test   %rax,%rax
    8393:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8399:	49 89 c1             	mov    %rax,%r9
    839c:	0f 84 8e 0b 00 00    	je     8f30 <f12+0x1230>
    83a2:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    83a9:	00 
    83aa:	4c 89 84 24 d0 00 00 	mov    %r8,0xd0(%rsp)
    83b1:	00 
    83b2:	48 85 db             	test   %rbx,%rbx
    83b5:	0f 85 3e 0c 00 00    	jne    8ff9 <f12+0x12f9>
    83bb:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    83c2:	4d 85 ed             	test   %r13,%r13
    83c5:	78 17                	js     83de <f12+0x6de>
    83c7:	44 89 e9             	mov    %r13d,%ecx
    83ca:	f2 0f 10 05 0e 4a 00 	movsd  0x4a0e(%rip),%xmm0        # cde0 <msg.4+0xb0>
    83d1:	00 
    83d2:	f2 41 0f 58 04 c9    	addsd  (%r9,%rcx,8),%xmm0
    83d8:	f2 41 0f 11 04 c9    	movsd  %xmm0,(%r9,%rcx,8)
    83de:	4d 39 de             	cmp    %r11,%r14
    83e1:	0f 8f 8a 00 00 00    	jg     8471 <f12+0x771>
    83e7:	0f 12 fb             	movhlps %xmm3,%xmm7
    83ea:	66 49 0f 7e d0       	movq   %xmm2,%r8
    83ef:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    83f4:	4d 29 f3             	sub    %r14,%r11
    83f7:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    83fc:	0f 12 fa             	movhlps %xmm2,%xmm7
    83ff:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
    8403:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    8408:	4a 8d 04 9e          	lea    (%rsi,%r11,4),%rax
    840c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8410:	48 29 f1             	sub    %rsi,%rcx
    8413:	4a 8d 14 db          	lea    (%rbx,%r11,8),%rdx
    8417:	48 29 df             	sub    %rbx,%rdi
    841a:	49 29 d8             	sub    %rbx,%r8
    841d:	eb 05                	jmp    8424 <f12+0x724>
    841f:	90                   	nop
    8420:	48 83 e8 04          	sub    $0x4,%rax
    8424:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    8429:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    842d:	7a 02                	jp     8431 <f12+0x731>
    842f:	74 37                	je     8468 <f12+0x768>
    8431:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    8435:	45 85 db             	test   %r11d,%r11d
    8438:	78 16                	js     8450 <f12+0x750>
    843a:	f2 41 0f 10 0c 10    	movsd  (%r8,%rdx,1),%xmm1
    8440:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8444:	f2 43 0f 58 0c d9    	addsd  (%r9,%r11,8),%xmm1
    844a:	f2 43 0f 11 0c d9    	movsd  %xmm1,(%r9,%r11,8)
    8450:	4c 63 18             	movslq (%rax),%r11
    8453:	45 85 db             	test   %r11d,%r11d
    8456:	78 10                	js     8468 <f12+0x768>
    8458:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    845c:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    8462:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    8468:	48 83 ea 08          	sub    $0x8,%rdx
    846c:	48 39 c6             	cmp    %rax,%rsi
    846f:	75 af                	jne    8420 <f12+0x720>
    8471:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8478:	ff ff 1f 
    847b:	4c 39 f0             	cmp    %r14,%rax
    847e:	0f 82 0e 0c 00 00    	jb     9092 <f12+0x1392>
    8484:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    848b:	00 
    848c:	be 02 00 00 00       	mov    $0x2,%esi
    8491:	4c 89 0c 24          	mov    %r9,(%rsp)
    8495:	e8 76 da ff ff       	call   5f10 <fwp_heap_alloc>
    849a:	4c 8b 0c 24          	mov    (%rsp),%r9
    849e:	4c 89 30             	mov    %r14,(%rax)
    84a1:	49 89 c5             	mov    %rax,%r13
    84a4:	31 c0                	xor    %eax,%eax
    84a6:	4d 85 f6             	test   %r14,%r14
    84a9:	74 27                	je     84d2 <f12+0x7d2>
    84ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84b2:	00 00 00 
    84b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84bc:	00 00 00 00 
    84c0:	49 8b 14 c1          	mov    (%r9,%rax,8),%rdx
    84c4:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    84c9:	48 83 c0 01          	add    $0x1,%rax
    84cd:	49 39 c6             	cmp    %rax,%r14
    84d0:	75 ee                	jne    84c0 <f12+0x7c0>
    84d2:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    84d9:	00 
    84da:	4c 89 e7             	mov    %r12,%rdi
    84dd:	48 89 0d d4 1f 06 00 	mov    %rcx,0x61fd4(%rip)        # 6a4b8 <fwp_cleanups>
    84e4:	48 89 0c 24          	mov    %rcx,(%rsp)
    84e8:	e8 73 cd ff ff       	call   5260 <fwp_tape_buffers_release>
    84ed:	48 8b 15 04 17 06 00 	mov    0x61704(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    84f4:	4c 89 e8             	mov    %r13,%rax
    84f7:	48 8b 0c 24          	mov    (%rsp),%rcx
    84fb:	48 2b 05 ce 16 06 00 	sub    0x616ce(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8502:	48 c1 e2 10          	shl    $0x10,%rdx
    8506:	48 39 d0             	cmp    %rdx,%rax
    8509:	73 57                	jae    8562 <f12+0x862>
    850b:	48 89 c2             	mov    %rax,%rdx
    850e:	48 c1 ea 10          	shr    $0x10,%rdx
    8512:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8516:	48 8b 15 fb 16 06 00 	mov    0x616fb(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    851d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8521:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8525:	48 85 db             	test   %rbx,%rbx
    8528:	74 38                	je     8562 <f12+0x862>
    852a:	0f b6 32             	movzbl (%rdx),%esi
    852d:	40 80 fe 02          	cmp    $0x2,%sil
    8531:	0f 84 09 08 00 00    	je     8d40 <f12+0x1040>
    8537:	40 80 fe 01          	cmp    $0x1,%sil
    853b:	75 25                	jne    8562 <f12+0x862>
    853d:	8b 72 18             	mov    0x18(%rdx),%esi
    8540:	0f b7 c0             	movzwl %ax,%eax
    8543:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8546:	48 0f af c6          	imul   %rsi,%rax
    854a:	48 c1 e8 20          	shr    $0x20,%rax
    854e:	48 39 d0             	cmp    %rdx,%rax
    8551:	73 0f                	jae    8562 <f12+0x862>
    8553:	48 01 c3             	add    %rax,%rbx
    8556:	80 3b ff             	cmpb   $0xff,(%rbx)
    8559:	0f 84 6b 0a 00 00    	je     8fca <f12+0x12ca>
    855f:	c6 03 01             	movb   $0x1,(%rbx)
    8562:	4c 39 f9             	cmp    %r15,%rcx
    8565:	0f 85 e0 b1 ff ff    	jne    374b <f12.cold>
    856b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8570:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8575:	48 89 05 3c 1f 06 00 	mov    %rax,0x61f3c(%rip)        # 6a4b8 <fwp_cleanups>
    857c:	e8 3f ef ff ff       	call   74c0 <fwp_tape_scope_release>
    8581:	49 8b 45 00          	mov    0x0(%r13),%rax
    8585:	49 89 c4             	mov    %rax,%r12
    8588:	49 0f ba f4 3f       	btr    $0x3f,%r12
    858d:	48 85 c0             	test   %rax,%rax
    8590:	0f 88 6a 05 00 00    	js     8b00 <f12+0xe00>
    8596:	48 8b 15 5b 16 06 00 	mov    0x6165b(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    859d:	4c 89 e8             	mov    %r13,%rax
    85a0:	48 2b 05 29 16 06 00 	sub    0x61629(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    85a7:	48 c1 e2 10          	shl    $0x10,%rdx
    85ab:	48 39 d0             	cmp    %rdx,%rax
    85ae:	0f 83 4c 05 00 00    	jae    8b00 <f12+0xe00>
    85b4:	48 89 c2             	mov    %rax,%rdx
    85b7:	48 c1 ea 10          	shr    $0x10,%rdx
    85bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85bf:	48 8b 15 52 16 06 00 	mov    0x61652(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    85c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85ca:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    85ce:	48 85 c9             	test   %rcx,%rcx
    85d1:	0f 84 29 05 00 00    	je     8b00 <f12+0xe00>
    85d7:	0f b6 32             	movzbl (%rdx),%esi
    85da:	40 80 fe 02          	cmp    $0x2,%sil
    85de:	0f 84 0c 05 00 00    	je     8af0 <f12+0xdf0>
    85e4:	40 80 fe 01          	cmp    $0x1,%sil
    85e8:	0f 85 12 05 00 00    	jne    8b00 <f12+0xe00>
    85ee:	8b 72 18             	mov    0x18(%rdx),%esi
    85f1:	0f b7 c0             	movzwl %ax,%eax
    85f4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85f7:	48 0f af c6          	imul   %rsi,%rax
    85fb:	48 c1 e8 20          	shr    $0x20,%rax
    85ff:	48 39 d0             	cmp    %rdx,%rax
    8602:	0f 83 f8 04 00 00    	jae    8b00 <f12+0xe00>
    8608:	48 01 c1             	add    %rax,%rcx
    860b:	80 39 01             	cmpb   $0x1,(%rcx)
    860e:	0f 85 ec 04 00 00    	jne    8b00 <f12+0xe00>
    8614:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    8619:	4d 89 ef             	mov    %r13,%r15
    861c:	31 ff                	xor    %edi,%edi
    861e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    8623:	f2 0f 10 0d c5 47 00 	movsd  0x47c5(%rip),%xmm1        # cdf0 <msg.4+0xc0>
    862a:	00 
    862b:	48 8d 50 08          	lea    0x8(%rax),%rdx
    862f:	31 c0                	xor    %eax,%eax
    8631:	4d 85 e4             	test   %r12,%r12
    8634:	75 2f                	jne    8665 <f12+0x965>
    8636:	eb 58                	jmp    8690 <f12+0x990>
    8638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    863f:	00 
    8640:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8644:	0f 88 17 0a 00 00    	js     9061 <f12+0x1361>
    864a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    864f:	48 83 c0 01          	add    $0x1,%rax
    8653:	48 83 c2 08          	add    $0x8,%rdx
    8657:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    865b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8660:	49 39 c4             	cmp    %rax,%r12
    8663:	74 2b                	je     8690 <f12+0x990>
    8665:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8669:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    866e:	79 d0                	jns    8640 <f12+0x940>
    8670:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8674:	eb ca                	jmp    8640 <f12+0x940>
    8676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    867d:	00 00 00 
    8680:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8684:	0f 84 f3 f8 ff ff    	je     7f7d <f12+0x27d>
    868a:	e9 e0 f8 ff ff       	jmp    7f6f <f12+0x26f>
    868f:	90                   	nop
    8690:	e8 eb f3 ff ff       	call   7a80 <fwp_drop4>
    8695:	48 89 e8             	mov    %rbp,%rax
    8698:	31 d2                	xor    %edx,%edx
    869a:	48 85 ed             	test   %rbp,%rbp
    869d:	0f 84 a7 08 00 00    	je     8f4a <f12+0x124a>
    86a3:	66 90                	xchg   %ax,%ax
    86a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86ac:	00 00 00 00 
    86b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    86b4:	48 83 c2 01          	add    $0x1,%rdx
    86b8:	48 85 c0             	test   %rax,%rax
    86bb:	75 f3                	jne    86b0 <f12+0x9b0>
    86bd:	49 8b 07             	mov    (%r15),%rax
    86c0:	49 89 c5             	mov    %rax,%r13
    86c3:	49 0f ba f5 3f       	btr    $0x3f,%r13
    86c8:	48 85 c0             	test   %rax,%rax
    86cb:	0f 88 81 03 00 00    	js     8a52 <f12+0xd52>
    86d1:	48 8b 05 20 15 06 00 	mov    0x61520(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    86d8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    86dd:	48 2b 0d ec 14 06 00 	sub    0x614ec(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    86e4:	48 c1 e0 10          	shl    $0x10,%rax
    86e8:	48 39 c1             	cmp    %rax,%rcx
    86eb:	0f 83 61 03 00 00    	jae    8a52 <f12+0xd52>
    86f1:	48 89 c8             	mov    %rcx,%rax
    86f4:	48 c1 e8 10          	shr    $0x10,%rax
    86f8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    86fc:	48 8b 05 15 15 06 00 	mov    0x61515(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    8703:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8707:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    870b:	48 85 ff             	test   %rdi,%rdi
    870e:	0f 84 3e 03 00 00    	je     8a52 <f12+0xd52>
    8714:	0f b6 06             	movzbl (%rsi),%eax
    8717:	3c 02                	cmp    $0x2,%al
    8719:	0f 84 21 03 00 00    	je     8a40 <f12+0xd40>
    871f:	3c 01                	cmp    $0x1,%al
    8721:	0f 85 22 03 00 00    	jne    8a49 <f12+0xd49>
    8727:	8b 46 18             	mov    0x18(%rsi),%eax
    872a:	0f b7 c9             	movzwl %cx,%ecx
    872d:	48 0f af c8          	imul   %rax,%rcx
    8731:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8734:	48 c1 e9 20          	shr    $0x20,%rcx
    8738:	48 39 c1             	cmp    %rax,%rcx
    873b:	0f 83 08 03 00 00    	jae    8a49 <f12+0xd49>
    8741:	48 01 cf             	add    %rcx,%rdi
    8744:	80 3f 01             	cmpb   $0x1,(%rdi)
    8747:	0f 85 fc 02 00 00    	jne    8a49 <f12+0xd49>
    874d:	4c 39 ea             	cmp    %r13,%rdx
    8750:	4c 89 e8             	mov    %r13,%rax
    8753:	48 0f 46 c2          	cmovbe %rdx,%rax
    8757:	48 85 c0             	test   %rax,%rax
    875a:	0f 84 12 09 00 00    	je     9072 <f12+0x1372>
    8760:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    8767:	00 
    8768:	4d 8d 77 08          	lea    0x8(%r15),%r14
    876c:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8771:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8778:	00 
    8779:	48 89 e9             	mov    %rbp,%rcx
    877c:	31 d2                	xor    %edx,%edx
    877e:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8782:	eb 59                	jmp    87dd <f12+0xadd>
    8784:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8789:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8790:	00 00 00 00 
    8794:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    879b:	00 00 00 00 
    879f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87a6:	00 00 00 00 
    87aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87b1:	00 00 00 00 
    87b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    87bc:	00 00 00 00 
    87c0:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    87c5:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    87ca:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    87d0:	48 83 c2 08          	add    $0x8,%rdx
    87d4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    87d8:	49 39 d0             	cmp    %rdx,%r8
    87db:	74 1b                	je     87f8 <f12+0xaf8>
    87dd:	48 89 fe             	mov    %rdi,%rsi
    87e0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    87e4:	79 da                	jns    87c0 <f12+0xac0>
    87e6:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    87eb:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    87ef:	eb cf                	jmp    87c0 <f12+0xac0>
    87f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    87f8:	48 85 ed             	test   %rbp,%rbp
    87fb:	0f 84 40 08 00 00    	je     9041 <f12+0x1341>
    8801:	4c 8b 05 f0 13 06 00 	mov    0x613f0(%rip),%r8        # 69bf8 <fwp_heap+0x13d8>
    8808:	4c 8b 0d c1 13 06 00 	mov    0x613c1(%rip),%r9        # 69bd0 <fwp_heap+0x13b0>
    880f:	48 89 e9             	mov    %rbp,%rcx
    8812:	45 31 ed             	xor    %r13d,%r13d
    8815:	4c 8b 15 fc 13 06 00 	mov    0x613fc(%rip),%r10        # 69c18 <fwp_heap+0x13f8>
    881c:	49 c1 e0 10          	shl    $0x10,%r8
    8820:	eb 1c                	jmp    883e <f12+0xb3e>
    8822:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8828:	49 83 c5 01          	add    $0x1,%r13
    882c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8830:	49 39 c5             	cmp    %rax,%r13
    8833:	0f 83 67 01 00 00    	jae    89a0 <f12+0xca0>
    8839:	48 85 c9             	test   %rcx,%rcx
    883c:	74 56                	je     8894 <f12+0xb94>
    883e:	48 89 ca             	mov    %rcx,%rdx
    8841:	4c 29 ca             	sub    %r9,%rdx
    8844:	4c 39 c2             	cmp    %r8,%rdx
    8847:	73 4b                	jae    8894 <f12+0xb94>
    8849:	48 89 d6             	mov    %rdx,%rsi
    884c:	48 c1 ee 10          	shr    $0x10,%rsi
    8850:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8854:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8858:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    885c:	48 85 ff             	test   %rdi,%rdi
    885f:	74 33                	je     8894 <f12+0xb94>
    8861:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8865:	41 80 fb 02          	cmp    $0x2,%r11b
    8869:	0f 84 19 01 00 00    	je     8988 <f12+0xc88>
    886f:	41 80 fb 01          	cmp    $0x1,%r11b
    8873:	75 1f                	jne    8894 <f12+0xb94>
    8875:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8879:	0f b7 d2             	movzwl %dx,%edx
    887c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    887f:	49 0f af d3          	imul   %r11,%rdx
    8883:	48 c1 ea 20          	shr    $0x20,%rdx
    8887:	48 39 f2             	cmp    %rsi,%rdx
    888a:	73 08                	jae    8894 <f12+0xb94>
    888c:	48 01 d7             	add    %rdx,%rdi
    888f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8892:	74 94                	je     8828 <f12+0xb28>
    8894:	49 39 c5             	cmp    %rax,%r13
    8897:	0f 83 03 01 00 00    	jae    89a0 <f12+0xca0>
    889d:	49 89 c7             	mov    %rax,%r15
    88a0:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    88a7:	00 
    88a8:	45 31 e4             	xor    %r12d,%r12d
    88ab:	48 89 04 24          	mov    %rax,(%rsp)
    88af:	48 8d 1d 6a ff 05 00 	lea    0x5ff6a(%rip),%rbx        # 68820 <fwp_heap>
    88b6:	eb 3a                	jmp    88f2 <f12+0xbf2>
    88b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    88bf:	00 
    88c0:	41 80 f9 01          	cmp    $0x1,%r9b
    88c4:	75 27                	jne    88ed <f12+0xbed>
    88c6:	45 8b 48 18          	mov    0x18(%r8),%r9d
    88ca:	0f b7 c0             	movzwl %ax,%eax
    88cd:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    88d1:	49 0f af c1          	imul   %r9,%rax
    88d5:	48 c1 e8 20          	shr    $0x20,%rax
    88d9:	4c 39 c0             	cmp    %r8,%rax
    88dc:	73 0f                	jae    88ed <f12+0xbed>
    88de:	48 01 c7             	add    %rax,%rdi
    88e1:	80 3f ff             	cmpb   $0xff,(%rdi)
    88e4:	0f 84 46 03 00 00    	je     8c30 <f12+0xf30>
    88ea:	c6 07 01             	movb   $0x1,(%rdi)
    88ed:	4d 39 fd             	cmp    %r15,%r13
    88f0:	73 7e                	jae    8970 <f12+0xc70>
    88f2:	49 83 ef 01          	sub    $0x1,%r15
    88f6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    88fb:	48 8b 34 24          	mov    (%rsp),%rsi
    88ff:	bf 01 00 00 00       	mov    $0x1,%edi
    8904:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    890a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    890e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    8915:	00 
    8916:	e8 a5 df ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    891b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    8922:	49 89 c4             	mov    %rax,%r12
    8925:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    892c:	48 c1 e7 10          	shl    $0x10,%rdi
    8930:	48 39 f8             	cmp    %rdi,%rax
    8933:	73 b8                	jae    88ed <f12+0xbed>
    8935:	48 89 c7             	mov    %rax,%rdi
    8938:	48 c1 ef 10          	shr    $0x10,%rdi
    893c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8940:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8947:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    894b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    894f:	48 85 ff             	test   %rdi,%rdi
    8952:	74 99                	je     88ed <f12+0xbed>
    8954:	45 0f b6 08          	movzbl (%r8),%r9d
    8958:	41 80 f9 02          	cmp    $0x2,%r9b
    895c:	0f 85 5e ff ff ff    	jne    88c0 <f12+0xbc0>
    8962:	66 85 c0             	test   %ax,%ax
    8965:	0f 84 76 ff ff ff    	je     88e1 <f12+0xbe1>
    896b:	4d 39 fd             	cmp    %r15,%r13
    896e:	72 82                	jb     88f2 <f12+0xbf2>
    8970:	4d 85 ed             	test   %r13,%r13
    8973:	75 2e                	jne    89a3 <f12+0xca3>
    8975:	8b 44 24 20          	mov    0x20(%rsp),%eax
    8979:	85 c0                	test   %eax,%eax
    897b:	4d 0f 45 f5          	cmovne %r13,%r14
    897f:	eb 6f                	jmp    89f0 <f12+0xcf0>
    8981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8988:	66 85 d2             	test   %dx,%dx
    898b:	0f 84 fe fe ff ff    	je     888f <f12+0xb8f>
    8991:	49 39 c5             	cmp    %rax,%r13
    8994:	0f 82 03 ff ff ff    	jb     889d <f12+0xb9d>
    899a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89a0:	45 31 e4             	xor    %r12d,%r12d
    89a3:	4c 89 f2             	mov    %r14,%rdx
    89a6:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    89aa:	48 89 e8             	mov    %rbp,%rax
    89ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89b4:	00 
    89b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    89bc:	00 00 00 00 
    89c0:	48 8b 0a             	mov    (%rdx),%rcx
    89c3:	48 83 c2 08          	add    $0x8,%rdx
    89c7:	48 89 c7             	mov    %rax,%rdi
    89ca:	48 89 48 08          	mov    %rcx,0x8(%rax)
    89ce:	48 8b 40 10          	mov    0x10(%rax),%rax
    89d2:	49 39 d0             	cmp    %rdx,%r8
    89d5:	75 e9                	jne    89c0 <f12+0xcc0>
    89d7:	8b 54 24 20          	mov    0x20(%rsp),%edx
    89db:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    89df:	85 d2                	test   %edx,%edx
    89e1:	0f 84 69 03 00 00    	je     8d50 <f12+0x1050>
    89e7:	49 89 ec             	mov    %rbp,%r12
    89ea:	45 31 f6             	xor    %r14d,%r14d
    89ed:	48 89 c5             	mov    %rax,%rbp
    89f0:	4c 89 f7             	mov    %r14,%rdi
    89f3:	e8 18 d0 ff ff       	call   5a10 <fwp_mem_free>
    89f8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    89fd:	e8 7e f0 ff ff       	call   7a80 <fwp_drop4>
    8a02:	48 89 ef             	mov    %rbp,%rdi
    8a05:	e8 56 e4 ff ff       	call   6e60 <fwp_drop0>
    8a0a:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    8a11:	00 
    8a12:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a19:	00 00 
    8a1b:	0f 85 da 06 00 00    	jne    90fb <f12+0x13fb>
    8a21:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    8a28:	4c 89 e0             	mov    %r12,%rax
    8a2b:	5b                   	pop    %rbx
    8a2c:	5d                   	pop    %rbp
    8a2d:	41 5c                	pop    %r12
    8a2f:	41 5d                	pop    %r13
    8a31:	41 5e                	pop    %r14
    8a33:	41 5f                	pop    %r15
    8a35:	c3                   	ret
    8a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a3d:	00 00 00 
    8a40:	66 85 c9             	test   %cx,%cx
    8a43:	0f 84 fb fc ff ff    	je     8744 <f12+0xa44>
    8a49:	48 85 ed             	test   %rbp,%rbp
    8a4c:	0f 84 eb 03 00 00    	je     8e3d <f12+0x113d>
    8a52:	48 89 e8             	mov    %rbp,%rax
    8a55:	45 31 e4             	xor    %r12d,%r12d
    8a58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8a5f:	00 
    8a60:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a64:	4c 89 e2             	mov    %r12,%rdx
    8a67:	49 83 c4 01          	add    $0x1,%r12
    8a6b:	48 85 c0             	test   %rax,%rax
    8a6e:	75 f0                	jne    8a60 <f12+0xd60>
    8a70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8a77:	ff ff 1f 
    8a7a:	4c 39 e0             	cmp    %r12,%rax
    8a7d:	0f 82 03 06 00 00    	jb     9086 <f12+0x1386>
    8a83:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8a8a:	00 
    8a8b:	be 02 00 00 00       	mov    $0x2,%esi
    8a90:	e8 7b d4 ff ff       	call   5f10 <fwp_heap_alloc>
    8a95:	4d 39 e5             	cmp    %r12,%r13
    8a98:	48 89 ea             	mov    %rbp,%rdx
    8a9b:	49 89 c6             	mov    %rax,%r14
    8a9e:	4c 89 e0             	mov    %r12,%rax
    8aa1:	49 0f 46 c5          	cmovbe %r13,%rax
    8aa5:	4c 89 f1             	mov    %r14,%rcx
    8aa8:	66 90                	xchg   %ax,%ax
    8aaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ab1:	00 00 00 00 
    8ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8abc:	00 00 00 00 
    8ac0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8ac4:	48 83 c1 08          	add    $0x8,%rcx
    8ac8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    8acc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8ad0:	48 85 d2             	test   %rdx,%rdx
    8ad3:	75 eb                	jne    8ac0 <f12+0xdc0>
    8ad5:	48 85 c0             	test   %rax,%rax
    8ad8:	0f 84 71 03 00 00    	je     8e4f <f12+0x114f>
    8ade:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    8ae5:	00 
    8ae6:	e9 81 fc ff ff       	jmp    876c <f12+0xa6c>
    8aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8af0:	66 85 c0             	test   %ax,%ax
    8af3:	0f 84 12 fb ff ff    	je     860b <f12+0x90b>
    8af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b00:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8b07:	ff ff 1f 
    8b0a:	4c 39 e0             	cmp    %r12,%rax
    8b0d:	0f 82 7f 05 00 00    	jb     9092 <f12+0x1392>
    8b13:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8b1a:	00 
    8b1b:	be 01 00 00 00       	mov    $0x1,%esi
    8b20:	e8 eb d3 ff ff       	call   5f10 <fwp_heap_alloc>
    8b25:	4c 89 20             	mov    %r12,(%rax)
    8b28:	48 8b 15 c9 10 06 00 	mov    0x610c9(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8b2f:	49 89 c7             	mov    %rax,%r15
    8b32:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8b37:	48 2b 05 92 10 06 00 	sub    0x61092(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8b3e:	48 c1 e2 10          	shl    $0x10,%rdx
    8b42:	48 39 d0             	cmp    %rdx,%rax
    8b45:	73 57                	jae    8b9e <f12+0xe9e>
    8b47:	48 89 c2             	mov    %rax,%rdx
    8b4a:	48 c1 ea 10          	shr    $0x10,%rdx
    8b4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b52:	48 8b 15 bf 10 06 00 	mov    0x610bf(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8b59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b5d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8b61:	4d 85 f6             	test   %r14,%r14
    8b64:	74 38                	je     8b9e <f12+0xe9e>
    8b66:	0f b6 0a             	movzbl (%rdx),%ecx
    8b69:	80 f9 02             	cmp    $0x2,%cl
    8b6c:	0f 84 ee 02 00 00    	je     8e60 <f12+0x1160>
    8b72:	80 f9 01             	cmp    $0x1,%cl
    8b75:	75 27                	jne    8b9e <f12+0xe9e>
    8b77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b7a:	0f b7 c0             	movzwl %ax,%eax
    8b7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b80:	48 0f af c1          	imul   %rcx,%rax
    8b84:	48 c1 e8 20          	shr    $0x20,%rax
    8b88:	48 39 d0             	cmp    %rdx,%rax
    8b8b:	73 11                	jae    8b9e <f12+0xe9e>
    8b8d:	49 01 c6             	add    %rax,%r14
    8b90:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8b94:	0f 84 45 04 00 00    	je     8fdf <f12+0x12df>
    8b9a:	41 c6 06 01          	movb   $0x1,(%r14)
    8b9e:	4c 89 ef             	mov    %r13,%rdi
    8ba1:	e9 78 fa ff ff       	jmp    861e <f12+0x91e>
    8ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bad:	00 00 00 
    8bb0:	48 c1 e6 10          	shl    $0x10,%rsi
    8bb4:	48 09 fe             	or     %rdi,%rsi
    8bb7:	bf 08 00 00 00       	mov    $0x8,%edi
    8bbc:	49 89 f4             	mov    %rsi,%r12
    8bbf:	be 02 00 00 00       	mov    $0x2,%esi
    8bc4:	e8 47 d3 ff ff       	call   5f10 <fwp_heap_alloc>
    8bc9:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8bd0:	48 8b 15 21 10 06 00 	mov    0x61021(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    8bd7:	48 89 c3             	mov    %rax,%rbx
    8bda:	48 2b 05 ef 0f 06 00 	sub    0x60fef(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8be1:	48 c1 e2 10          	shl    $0x10,%rdx
    8be5:	48 39 d0             	cmp    %rdx,%rax
    8be8:	73 76                	jae    8c60 <f12+0xf60>
    8bea:	48 89 c2             	mov    %rax,%rdx
    8bed:	48 c1 ea 10          	shr    $0x10,%rdx
    8bf1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bf5:	48 8b 15 1c 10 06 00 	mov    0x6101c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8bfc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8c00:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8c04:	48 85 d2             	test   %rdx,%rdx
    8c07:	0f 84 66 f5 ff ff    	je     8173 <f12+0x473>
    8c0d:	0f b6 31             	movzbl (%rcx),%esi
    8c10:	45 31 ed             	xor    %r13d,%r13d
    8c13:	40 80 fe 02          	cmp    $0x2,%sil
    8c17:	0f 85 be f4 ff ff    	jne    80db <f12+0x3db>
    8c1d:	66 85 c0             	test   %ax,%ax
    8c20:	0f 85 e0 f4 ff ff    	jne    8106 <f12+0x406>
    8c26:	e9 cf f4 ff ff       	jmp    80fa <f12+0x3fa>
    8c2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c30:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    8c35:	e8 96 cb ff ff       	call   57d0 <fwp_rc_forget_slot>
    8c3a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8c3f:	e9 a6 fc ff ff       	jmp    88ea <f12+0xbea>
    8c44:	0f 1f 40 00          	nopl   0x0(%rax)
    8c48:	4d 85 ed             	test   %r13,%r13
    8c4b:	0f 85 ba f4 ff ff    	jne    810b <f12+0x40b>
    8c51:	0f 1f 40 00          	nopl   0x0(%rax)
    8c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c5c:	00 00 00 00 
    8c60:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    8c67:	00 
    8c68:	e9 71 f5 ff ff       	jmp    81de <f12+0x4de>
    8c6d:	0f 1f 00             	nopl   (%rax)
    8c70:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    8c74:	49 39 d8             	cmp    %rbx,%r8
    8c77:	0f 8c ab f6 ff ff    	jl     8328 <f12+0x628>
    8c7d:	4d 85 c9             	test   %r9,%r9
    8c80:	0f 84 18 04 00 00    	je     909e <f12+0x139e>
    8c86:	4c 89 cf             	mov    %r9,%rdi
    8c89:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8c90:	00 
    8c91:	31 f6                	xor    %esi,%esi
    8c93:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8c97:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    8c9c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    8ca1:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    8ca6:	e8 05 a8 ff ff       	call   34b0 <memset@plt>
    8cab:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8cb0:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8cb6:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    8cbb:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
    8cc0:	49 89 c1             	mov    %rax,%r9
    8cc3:	e9 02 f7 ff ff       	jmp    83ca <f12+0x6ca>
    8cc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8ccf:	00 
    8cd0:	48 8d 3d c9 e6 ff ff 	lea    -0x1937(%rip),%rdi        # 73a0 <fwp_tape_finish>
    8cd7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8cdc:	e8 8f 31 00 00       	call   be70 <atexit>
    8ce1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8ce6:	85 c0                	test   %eax,%eax
    8ce8:	0f 85 c7 03 00 00    	jne    90b5 <f12+0x13b5>
    8cee:	c7 05 68 73 00 00 01 	movl   $0x1,0x7368(%rip)        # 10060 <registered_finish.0>
    8cf5:	00 00 00 
    8cf8:	e9 40 f1 ff ff       	jmp    7e3d <f12+0x13d>
    8cfd:	0f 1f 00             	nopl   (%rax)
    8d00:	66 85 c0             	test   %ax,%ax
    8d03:	0f 85 e2 f0 ff ff    	jne    7deb <f12+0xeb>
    8d09:	e9 b9 f0 ff ff       	jmp    7dc7 <f12+0xc7>
    8d0e:	66 90                	xchg   %ax,%ax
    8d10:	4d 39 c6             	cmp    %r8,%r14
    8d13:	0f 8f 0c f6 ff ff    	jg     8325 <f12+0x625>
    8d19:	4d 85 f6             	test   %r14,%r14
    8d1c:	74 12                	je     8d30 <f12+0x1030>
    8d1e:	4d 85 c9             	test   %r9,%r9
    8d21:	0f 84 77 03 00 00    	je     909e <f12+0x139e>
    8d27:	4d 85 f6             	test   %r14,%r14
    8d2a:	0f 85 c6 02 00 00    	jne    8ff6 <f12+0x12f6>
    8d30:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    8d37:	e9 a2 f6 ff ff       	jmp    83de <f12+0x6de>
    8d3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d40:	66 85 c0             	test   %ax,%ax
    8d43:	0f 85 19 f8 ff ff    	jne    8562 <f12+0x862>
    8d49:	e9 08 f8 ff ff       	jmp    8556 <f12+0x856>
    8d4e:	66 90                	xchg   %ax,%ax
    8d50:	49 89 ec             	mov    %rbp,%r12
    8d53:	48 89 c5             	mov    %rax,%rbp
    8d56:	e9 95 fc ff ff       	jmp    89f0 <f12+0xcf0>
    8d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d60:	66 0f 6f 0d 38 73 01 	movdqa 0x17338(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    8d67:	00 
    8d68:	48 c7 05 15 73 01 00 	movq   $0x0,0x17315(%rip)        # 20088 <fwp_tape_cached_bytes>
    8d6f:	00 00 00 00 
    8d73:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    8d79:	48 8b 05 40 73 01 00 	mov    0x17340(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    8d80:	66 0f 6f 0d 28 73 01 	movdqa 0x17328(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    8d87:	00 
    8d88:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    8d8d:	48 8b 05 34 73 01 00 	mov    0x17334(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    8d94:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    8d9a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8d9e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    8da3:	48 8b 05 26 73 01 00 	mov    0x17326(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    8daa:	0f 29 0d ef 72 01 00 	movaps %xmm1,0x172ef(%rip)        # 200a0 <fwp_tape_workspace>
    8db1:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    8db6:	0f 29 0d f3 72 01 00 	movaps %xmm1,0x172f3(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    8dbd:	48 c7 05 08 73 01 00 	movq   $0x0,0x17308(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    8dc4:	00 00 00 00 
    8dc8:	0f 29 0d f1 72 01 00 	movaps %xmm1,0x172f1(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    8dcf:	e9 a9 f1 ff ff       	jmp    7f7d <f12+0x27d>
    8dd4:	0f 1f 40 00          	nopl   0x0(%rax)
    8dd8:	4d 85 c9             	test   %r9,%r9
    8ddb:	0f 84 bd 02 00 00    	je     909e <f12+0x139e>
    8de1:	4d 8d 5e ff          	lea    -0x1(%r14),%r11
    8de5:	4c 89 cf             	mov    %r9,%rdi
    8de8:	31 f6                	xor    %esi,%esi
    8dea:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    8def:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8df6:	00 
    8df7:	4c 89 1c 24          	mov    %r11,(%rsp)
    8dfb:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8e00:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8e05:	e8 a6 a6 ff ff       	call   34b0 <memset@plt>
    8e0a:	4c 8b 1c 24          	mov    (%rsp),%r11
    8e0e:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8e14:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8e1a:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    8e1f:	49 89 c1             	mov    %rax,%r9
    8e22:	e9 a3 f5 ff ff       	jmp    83ca <f12+0x6ca>
    8e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e2e:	00 00 
    8e30:	48 83 05 98 16 06 00 	addq   $0x1,0x61698(%rip)        # 6a4d0 <iteration_retains>
    8e37:	01 
    8e38:	e9 a1 ef ff ff       	jmp    7dde <f12+0xde>
    8e3d:	be 02 00 00 00       	mov    $0x2,%esi
    8e42:	bf 08 00 00 00       	mov    $0x8,%edi
    8e47:	e8 c4 d0 ff ff       	call   5f10 <fwp_heap_alloc>
    8e4c:	49 89 c6             	mov    %rax,%r14
    8e4f:	45 31 e4             	xor    %r12d,%r12d
    8e52:	e9 99 fb ff ff       	jmp    89f0 <f12+0xcf0>
    8e57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e5e:	00 00 
    8e60:	66 85 c0             	test   %ax,%ax
    8e63:	0f 85 35 fd ff ff    	jne    8b9e <f12+0xe9e>
    8e69:	e9 22 fd ff ff       	jmp    8b90 <f12+0xe90>
    8e6e:	66 90                	xchg   %ax,%ax
    8e70:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8e77:	ff ff 1f 
    8e7a:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    8e7e:	48 39 c2             	cmp    %rax,%rdx
    8e81:	0f 82 5c 02 00 00    	jb     90e3 <f12+0x13e3>
    8e87:	48 8d 05 32 73 04 00 	lea    0x47332(%rip),%rax        # 501c0 <ad_raw_blocks>
    8e8e:	31 d2                	xor    %edx,%edx
    8e90:	eb 23                	jmp    8eb5 <f12+0x11b5>
    8e92:	0f 1f 00             	nopl   (%rax)
    8e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e9c:	00 00 00 00 
    8ea0:	48 83 c2 01          	add    $0x1,%rdx
    8ea4:	48 83 c0 18          	add    $0x18,%rax
    8ea8:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
    8eaf:	0f 84 80 01 00 00    	je     9035 <f12+0x1335>
    8eb5:	48 83 38 00          	cmpq   $0x0,(%rax)
    8eb9:	75 e5                	jne    8ea0 <f12+0x11a0>
    8ebb:	4c 89 c7             	mov    %r8,%rdi
    8ebe:	be 08 00 00 00       	mov    $0x8,%esi
    8ec3:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    8ec8:	4c 89 04 24          	mov    %r8,(%rsp)
    8ecc:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    8ed1:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    8ed6:	e8 35 a6 ff ff       	call   3510 <calloc@plt>
    8edb:	4c 8b 04 24          	mov    (%rsp),%r8
    8edf:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    8ee4:	48 8d 0d d5 72 04 00 	lea    0x472d5(%rip),%rcx        # 501c0 <ad_raw_blocks>
    8eeb:	48 85 c0             	test   %rax,%rax
    8eee:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    8ef4:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    8efa:	74 34                	je     8f30 <f12+0x1230>
    8efc:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    8f00:	48 89 c6             	mov    %rax,%rsi
    8f03:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    8f08:	48 8d 3c d1          	lea    (%rcx,%rdx,8),%rdi
    8f0c:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    8f13:	00 
    8f14:	b9 03 00 00 00       	mov    $0x3,%ecx
    8f19:	48 89 04 24          	mov    %rax,(%rsp)
    8f1d:	e8 de ac ff ff       	call   3c00 <ad_raw_record>
    8f22:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8f27:	4c 8b 0c 24          	mov    (%rsp),%r9
    8f2b:	e9 72 f4 ff ff       	jmp    83a2 <f12+0x6a2>
    8f30:	48 85 db             	test   %rbx,%rbx
    8f33:	0f 85 65 01 00 00    	jne    909e <f12+0x139e>
    8f39:	45 31 c9             	xor    %r9d,%r9d
    8f3c:	e9 7a f4 ff ff       	jmp    83bb <f12+0x6bb>
    8f41:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8f45:	e9 e5 ee ff ff       	jmp    7e2f <f12+0x12f>
    8f4a:	49 8b 07             	mov    (%r15),%rax
    8f4d:	48 85 c0             	test   %rax,%rax
    8f50:	0f 88 e7 fe ff ff    	js     8e3d <f12+0x113d>
    8f56:	48 8b 35 9b 0c 06 00 	mov    0x60c9b(%rip),%rsi        # 69bf8 <fwp_heap+0x13d8>
    8f5d:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8f62:	48 2b 0d 67 0c 06 00 	sub    0x60c67(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    8f69:	48 c1 e6 10          	shl    $0x10,%rsi
    8f6d:	48 39 f1             	cmp    %rsi,%rcx
    8f70:	0f 83 c7 fe ff ff    	jae    8e3d <f12+0x113d>
    8f76:	48 89 ce             	mov    %rcx,%rsi
    8f79:	48 c1 ee 10          	shr    $0x10,%rsi
    8f7d:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    8f81:	48 8b 35 90 0c 06 00 	mov    0x60c90(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    8f88:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    8f8c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8f90:	48 85 ff             	test   %rdi,%rdi
    8f93:	0f 84 a4 fe ff ff    	je     8e3d <f12+0x113d>
    8f99:	48 0f ba f0 3f       	btr    $0x3f,%rax
    8f9e:	49 89 c5             	mov    %rax,%r13
    8fa1:	e9 6e f7 ff ff       	jmp    8714 <f12+0xa14>
    8fa6:	be 68 00 00 00       	mov    $0x68,%esi
    8fab:	bb 01 00 00 00       	mov    $0x1,%ebx
    8fb0:	e9 05 ef ff ff       	jmp    7eba <f12+0x1ba>
    8fb5:	48 89 d7             	mov    %rdx,%rdi
    8fb8:	48 89 14 24          	mov    %rdx,(%rsp)
    8fbc:	e8 0f c8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8fc1:	48 8b 14 24          	mov    (%rsp),%rdx
    8fc5:	e9 39 f1 ff ff       	jmp    8103 <f12+0x403>
    8fca:	48 89 df             	mov    %rbx,%rdi
    8fcd:	48 89 0c 24          	mov    %rcx,(%rsp)
    8fd1:	e8 fa c7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8fd6:	48 8b 0c 24          	mov    (%rsp),%rcx
    8fda:	e9 80 f5 ff ff       	jmp    855f <f12+0x85f>
    8fdf:	4c 89 f7             	mov    %r14,%rdi
    8fe2:	e8 e9 c7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8fe7:	e9 ae fb ff ff       	jmp    8b9a <f12+0xe9a>
    8fec:	e8 bf c6 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8ff1:	e9 f5 ed ff ff       	jmp    7deb <f12+0xeb>
    8ff6:	4c 89 f3             	mov    %r14,%rbx
    8ff9:	4c 8d 5b ff          	lea    -0x1(%rbx),%r11
    8ffd:	4c 89 cf             	mov    %r9,%rdi
    9000:	31 f6                	xor    %esi,%esi
    9002:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9007:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    900e:	00 
    900f:	4c 89 1c 24          	mov    %r11,(%rsp)
    9013:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9018:	e8 93 a4 ff ff       	call   34b0 <memset@plt>
    901d:	4c 8b 1c 24          	mov    (%rsp),%r11
    9021:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9027:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    902d:	49 89 c1             	mov    %rax,%r9
    9030:	e9 8d f3 ff ff       	jmp    83c2 <f12+0x6c2>
    9035:	48 8d 3d d6 30 00 00 	lea    0x30d6(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    903c:	e8 bf af ff ff       	call   4000 <ad_raw_fail>
    9041:	45 31 ed             	xor    %r13d,%r13d
    9044:	e9 54 f8 ff ff       	jmp    889d <f12+0xb9d>
    9049:	48 8d 3d b8 39 00 00 	lea    0x39b8(%rip),%rdi        # ca08 <_IO_stdin_used+0xa08>
    9050:	e8 fb b3 ff ff       	call   4450 <fwp_trap>
    9055:	48 8d 3d 66 31 00 00 	lea    0x3166(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    905c:	e8 ef b3 ff ff       	call   4450 <fwp_trap>
    9061:	48 8d 3d a8 3a 00 00 	lea    0x3aa8(%rip),%rdi        # cb10 <_IO_stdin_used+0xb10>
    9068:	e8 e3 b3 ff ff       	call   4450 <fwp_trap>
    906d:	e8 8e a6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9072:	45 31 f6             	xor    %r14d,%r14d
    9075:	e9 d5 fd ff ff       	jmp    8e4f <f12+0x114f>
    907a:	48 8d 3d 6a 31 00 00 	lea    0x316a(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    9081:	e8 ca b3 ff ff       	call   4450 <fwp_trap>
    9086:	48 8d 3d 78 31 00 00 	lea    0x3178(%rip),%rdi        # c205 <_IO_stdin_used+0x205>
    908d:	e8 be b3 ff ff       	call   4450 <fwp_trap>
    9092:	48 8d 3d 96 31 00 00 	lea    0x3196(%rip),%rdi        # c22f <_IO_stdin_used+0x22f>
    9099:	e8 b2 b3 ff ff       	call   4450 <fwp_trap>
    909e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    90a5:	00 
    90a6:	4c 89 e7             	mov    %r12,%rdi
    90a9:	48 89 05 08 14 06 00 	mov    %rax,0x61408(%rip)        # 6a4b8 <fwp_cleanups>
    90b0:	e8 ab c1 ff ff       	call   5260 <fwp_tape_buffers_release>
    90b5:	48 8b 0d 84 6f 00 00 	mov    0x6f84(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    90bc:	ba 13 00 00 00       	mov    $0x13,%edx
    90c1:	be 01 00 00 00       	mov    $0x1,%esi
    90c6:	48 8d 3d 3b 2f 00 00 	lea    0x2f3b(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    90cd:	e8 8e a5 ff ff       	call   3660 <fwrite@plt>
    90d2:	31 ff                	xor    %edi,%edi
    90d4:	e8 c7 a4 ff ff       	call   35a0 <fflush@plt>
    90d9:	bf 66 00 00 00       	mov    $0x66,%edi
    90de:	e8 9d a5 ff ff       	call   3680 <_Exit@plt>
    90e3:	48 8d 3d 29 31 00 00 	lea    0x3129(%rip),%rdi        # c213 <_IO_stdin_used+0x213>
    90ea:	e8 11 af ff ff       	call   4000 <ad_raw_fail>
    90ef:	48 8d 3d ba 39 00 00 	lea    0x39ba(%rip),%rdi        # cab0 <_IO_stdin_used+0xab0>
    90f6:	e8 55 b3 ff ff       	call   4450 <fwp_trap>
    90fb:	e8 50 a3 ff ff       	call   3450 <__stack_chk_fail@plt>
    9100:	48 8d 3d 49 39 00 00 	lea    0x3949(%rip),%rdi        # ca50 <_IO_stdin_used+0xa50>
    9107:	e8 44 b3 ff ff       	call   4450 <fwp_trap>
    910c:	48 8d 3d cd 39 00 00 	lea    0x39cd(%rip),%rdi        # cae0 <_IO_stdin_used+0xae0>
    9113:	e8 38 b3 ff ff       	call   4450 <fwp_trap>
    9118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    911f:	00 

0000000000009120 <fwp_owned_entry12>:
    9120:	f3 0f 1e fa          	endbr64
    9124:	48 8b 3f             	mov    (%rdi),%rdi
    9127:	e9 d4 eb ff ff       	jmp    7d00 <f12>
    912c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009130 <e12>:
    9130:	f3 0f 1e fa          	endbr64
    9134:	53                   	push   %rbx
    9135:	48 8b 1f             	mov    (%rdi),%rbx
    9138:	48 89 df             	mov    %rbx,%rdi
    913b:	e8 70 d9 ff ff       	call   6ab0 <fwp_rc_share>
    9140:	48 89 df             	mov    %rbx,%rdi
    9143:	e8 b8 eb ff ff       	call   7d00 <f12>
    9148:	48 89 c3             	mov    %rax,%rbx
    914b:	48 89 c7             	mov    %rax,%rdi
    914e:	e8 5d d9 ff ff       	call   6ab0 <fwp_rc_share>
    9153:	48 89 d8             	mov    %rbx,%rax
    9156:	5b                   	pop    %rbx
    9157:	c3                   	ret
    9158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    915f:	00 

0000000000009160 <fwp_drop2>:
    9160:	48 8b 0d 91 0a 06 00 	mov    0x60a91(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    9167:	48 89 f8             	mov    %rdi,%rax
    916a:	48 2b 05 5f 0a 06 00 	sub    0x60a5f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9171:	48 c1 e1 10          	shl    $0x10,%rcx
    9175:	48 39 c8             	cmp    %rcx,%rax
    9178:	0f 83 42 01 00 00    	jae    92c0 <fwp_drop2+0x160>
    917e:	48 83 ec 18          	sub    $0x18,%rsp
    9182:	48 89 fa             	mov    %rdi,%rdx
    9185:	4c 8d 05 94 f6 05 00 	lea    0x5f694(%rip),%r8        # 68820 <fwp_heap>
    918c:	48 89 c1             	mov    %rax,%rcx
    918f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9196:	48 c1 e9 10          	shr    $0x10,%rcx
    919a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    919e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    91a2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    91a6:	48 85 c9             	test   %rcx,%rcx
    91a9:	74 40                	je     91eb <fwp_drop2+0x8b>
    91ab:	0f b6 3e             	movzbl (%rsi),%edi
    91ae:	40 80 ff 02          	cmp    $0x2,%dil
    91b2:	74 3c                	je     91f0 <fwp_drop2+0x90>
    91b4:	40 80 ff 01          	cmp    $0x1,%dil
    91b8:	75 31                	jne    91eb <fwp_drop2+0x8b>
    91ba:	8b 7e 18             	mov    0x18(%rsi),%edi
    91bd:	0f b7 c0             	movzwl %ax,%eax
    91c0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    91c3:	48 0f af c7          	imul   %rdi,%rax
    91c7:	48 c1 e8 20          	shr    $0x20,%rax
    91cb:	48 39 f0             	cmp    %rsi,%rax
    91ce:	73 1b                	jae    91eb <fwp_drop2+0x8b>
    91d0:	48 01 c1             	add    %rax,%rcx
    91d3:	0f b6 01             	movzbl (%rcx),%eax
    91d6:	84 c0                	test   %al,%al
    91d8:	74 11                	je     91eb <fwp_drop2+0x8b>
    91da:	3c 01                	cmp    $0x1,%al
    91dc:	74 22                	je     9200 <fwp_drop2+0xa0>
    91de:	3c ff                	cmp    $0xff,%al
    91e0:	0f 84 0a 01 00 00    	je     92f0 <fwp_drop2+0x190>
    91e6:	83 e8 01             	sub    $0x1,%eax
    91e9:	88 01                	mov    %al,(%rcx)
    91eb:	48 83 c4 18          	add    $0x18,%rsp
    91ef:	c3                   	ret
    91f0:	66 85 c0             	test   %ax,%ax
    91f3:	74 de                	je     91d3 <fwp_drop2+0x73>
    91f5:	48 83 c4 18          	add    $0x18,%rsp
    91f9:	c3                   	ret
    91fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9200:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9204:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    920b:	48 89 f8             	mov    %rdi,%rax
    920e:	48 c1 e1 10          	shl    $0x10,%rcx
    9212:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9219:	48 39 c8             	cmp    %rcx,%rax
    921c:	73 62                	jae    9280 <fwp_drop2+0x120>
    921e:	48 89 c1             	mov    %rax,%rcx
    9221:	48 c1 e9 10          	shr    $0x10,%rcx
    9225:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9229:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    922d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9231:	48 85 c9             	test   %rcx,%rcx
    9234:	74 4a                	je     9280 <fwp_drop2+0x120>
    9236:	44 0f b6 0e          	movzbl (%rsi),%r9d
    923a:	41 80 f9 02          	cmp    $0x2,%r9b
    923e:	0f 84 9c 00 00 00    	je     92e0 <fwp_drop2+0x180>
    9244:	41 80 f9 01          	cmp    $0x1,%r9b
    9248:	75 36                	jne    9280 <fwp_drop2+0x120>
    924a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    924e:	0f b7 c0             	movzwl %ax,%eax
    9251:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9254:	49 0f af c1          	imul   %r9,%rax
    9258:	48 c1 e8 20          	shr    $0x20,%rax
    925c:	48 39 f0             	cmp    %rsi,%rax
    925f:	73 1f                	jae    9280 <fwp_drop2+0x120>
    9261:	48 01 c1             	add    %rax,%rcx
    9264:	0f b6 01             	movzbl (%rcx),%eax
    9267:	84 c0                	test   %al,%al
    9269:	74 15                	je     9280 <fwp_drop2+0x120>
    926b:	3c 01                	cmp    $0x1,%al
    926d:	74 59                	je     92c8 <fwp_drop2+0x168>
    926f:	3c ff                	cmp    $0xff,%al
    9271:	0f 84 ef 00 00 00    	je     9366 <fwp_drop2+0x206>
    9277:	83 e8 01             	sub    $0x1,%eax
    927a:	88 01                	mov    %al,(%rcx)
    927c:	0f 1f 40 00          	nopl   0x0(%rax)
    9280:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9284:	48 89 d7             	mov    %rdx,%rdi
    9287:	48 89 0c 24          	mov    %rcx,(%rsp)
    928b:	e8 a0 d8 ff ff       	call   6b30 <fwp_rc_free_arr>
    9290:	4c 8d 05 89 f5 05 00 	lea    0x5f589(%rip),%r8        # 68820 <fwp_heap>
    9297:	48 8b 04 24          	mov    (%rsp),%rax
    929b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    92a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    92a9:	48 c1 e2 10          	shl    $0x10,%rdx
    92ad:	48 39 d0             	cmp    %rdx,%rax
    92b0:	0f 83 35 ff ff ff    	jae    91eb <fwp_drop2+0x8b>
    92b6:	48 8b 14 24          	mov    (%rsp),%rdx
    92ba:	e9 cd fe ff ff       	jmp    918c <fwp_drop2+0x2c>
    92bf:	90                   	nop
    92c0:	c3                   	ret
    92c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92c8:	48 89 14 24          	mov    %rdx,(%rsp)
    92cc:	e8 5f d8 ff ff       	call   6b30 <fwp_rc_free_arr>
    92d1:	48 8b 14 24          	mov    (%rsp),%rdx
    92d5:	eb a9                	jmp    9280 <fwp_drop2+0x120>
    92d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    92de:	00 00 
    92e0:	66 85 c0             	test   %ax,%ax
    92e3:	75 9b                	jne    9280 <fwp_drop2+0x120>
    92e5:	e9 7a ff ff ff       	jmp    9264 <fwp_drop2+0x104>
    92ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92f0:	48 89 c8             	mov    %rcx,%rax
    92f3:	48 c1 e8 11          	shr    $0x11,%rax
    92f7:	48 31 c8             	xor    %rcx,%rax
    92fa:	48 89 c2             	mov    %rax,%rdx
    92fd:	48 c1 ea 09          	shr    $0x9,%rdx
    9301:	48 31 d0             	xor    %rdx,%rax
    9304:	0f b6 d0             	movzbl %al,%edx
    9307:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    930e:	00 
    930f:	48 85 c0             	test   %rax,%rax
    9312:	75 19                	jne    932d <fwp_drop2+0x1cd>
    9314:	e9 d3 00 00 00       	jmp    93ec <fwp_drop2+0x28c>
    9319:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9320:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9324:	48 85 c0             	test   %rax,%rax
    9327:	0f 84 bf 00 00 00    	je     93ec <fwp_drop2+0x28c>
    932d:	48 89 c2             	mov    %rax,%rdx
    9330:	48 39 08             	cmp    %rcx,(%rax)
    9333:	75 eb                	jne    9320 <fwp_drop2+0x1c0>
    9335:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9339:	48 83 ea 01          	sub    $0x1,%rdx
    933d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9341:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9348:	0f 85 9d fe ff ff    	jne    91eb <fwp_drop2+0x8b>
    934e:	48 89 cf             	mov    %rcx,%rdi
    9351:	48 89 0c 24          	mov    %rcx,(%rsp)
    9355:	e8 76 c4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    935a:	48 8b 0c 24          	mov    (%rsp),%rcx
    935e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9361:	e9 85 fe ff ff       	jmp    91eb <fwp_drop2+0x8b>
    9366:	48 89 ce             	mov    %rcx,%rsi
    9369:	48 c1 ee 11          	shr    $0x11,%rsi
    936d:	48 31 ce             	xor    %rcx,%rsi
    9370:	48 89 f0             	mov    %rsi,%rax
    9373:	48 c1 e8 09          	shr    $0x9,%rax
    9377:	48 31 c6             	xor    %rax,%rsi
    937a:	40 0f b6 f6          	movzbl %sil,%esi
    937e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9385:	00 
    9386:	48 85 c0             	test   %rax,%rax
    9389:	75 1e                	jne    93a9 <fwp_drop2+0x249>
    938b:	eb 5f                	jmp    93ec <fwp_drop2+0x28c>
    938d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9394:	00 
    9395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    939c:	00 00 00 00 
    93a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    93a4:	48 85 c0             	test   %rax,%rax
    93a7:	74 43                	je     93ec <fwp_drop2+0x28c>
    93a9:	48 89 c6             	mov    %rax,%rsi
    93ac:	48 39 08             	cmp    %rcx,(%rax)
    93af:	75 ef                	jne    93a0 <fwp_drop2+0x240>
    93b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    93b5:	48 83 ee 01          	sub    $0x1,%rsi
    93b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    93bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    93c4:	0f 85 b6 fe ff ff    	jne    9280 <fwp_drop2+0x120>
    93ca:	48 89 cf             	mov    %rcx,%rdi
    93cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    93d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    93d6:	e8 f5 c3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    93db:	48 8b 0c 24          	mov    (%rsp),%rcx
    93df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    93e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    93e7:	e9 94 fe ff ff       	jmp    9280 <fwp_drop2+0x120>
    93ec:	48 8d 3d ed 35 00 00 	lea    0x35ed(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    93f3:	e8 58 b0 ff ff       	call   4450 <fwp_trap>
    93f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93ff:	00 

0000000000009400 <fwp_arg_drop23>:
    9400:	f3 0f 1e fa          	endbr64
    9404:	85 f6                	test   %esi,%esi
    9406:	75 04                	jne    940c <fwp_arg_drop23+0xc>
    9408:	85 d2                	test   %edx,%edx
    940a:	75 04                	jne    9410 <fwp_arg_drop23+0x10>
    940c:	c3                   	ret
    940d:	0f 1f 00             	nopl   (%rax)
    9410:	48 8b 3f             	mov    (%rdi),%rdi
    9413:	e9 48 fd ff ff       	jmp    9160 <fwp_drop2>
    9418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    941f:	00 

0000000000009420 <f23>:
    9420:	41 57                	push   %r15
    9422:	41 56                	push   %r14
    9424:	41 55                	push   %r13
    9426:	41 54                	push   %r12
    9428:	55                   	push   %rbp
    9429:	53                   	push   %rbx
    942a:	48 83 ec 38          	sub    $0x38,%rsp
    942e:	48 8b 15 c3 07 06 00 	mov    0x607c3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9435:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    943a:	48 c1 e2 10          	shl    $0x10,%rdx
    943e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    9445:	00 00 
    9447:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    944c:	48 8b 0d 7d 07 06 00 	mov    0x6077d(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    9453:	48 85 ff             	test   %rdi,%rdi
    9456:	0f 84 1e 03 00 00    	je     977a <f23+0x35a>
    945c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9461:	4c 8b 68 10          	mov    0x10(%rax),%r13
    9465:	4c 89 e8             	mov    %r13,%rax
    9468:	48 29 c8             	sub    %rcx,%rax
    946b:	48 39 d0             	cmp    %rdx,%rax
    946e:	0f 83 ec 02 00 00    	jae    9760 <f23+0x340>
    9474:	48 89 c2             	mov    %rax,%rdx
    9477:	48 c1 ea 10          	shr    $0x10,%rdx
    947b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    947f:	48 8b 15 92 07 06 00 	mov    0x60792(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9486:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    948a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    948e:	48 85 ff             	test   %rdi,%rdi
    9491:	0f 84 c9 02 00 00    	je     9760 <f23+0x340>
    9497:	0f b6 0a             	movzbl (%rdx),%ecx
    949a:	80 f9 02             	cmp    $0x2,%cl
    949d:	0f 84 4d 02 00 00    	je     96f0 <f23+0x2d0>
    94a3:	80 f9 01             	cmp    $0x1,%cl
    94a6:	75 24                	jne    94cc <f23+0xac>
    94a8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94ab:	0f b7 c0             	movzwl %ax,%eax
    94ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94b1:	48 0f af c1          	imul   %rcx,%rax
    94b5:	48 c1 e8 20          	shr    $0x20,%rax
    94b9:	48 39 d0             	cmp    %rdx,%rax
    94bc:	73 0e                	jae    94cc <f23+0xac>
    94be:	48 01 c7             	add    %rax,%rdi
    94c1:	0f b6 07             	movzbl (%rdi),%eax
    94c4:	84 c0                	test   %al,%al
    94c6:	0f 85 44 02 00 00    	jne    9710 <f23+0x2f0>
    94cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    94d1:	48 8b 40 10          	mov    0x10(%rax),%rax
    94d5:	ba 01 00 00 00       	mov    $0x1,%edx
    94da:	48 85 c0             	test   %rax,%rax
    94dd:	74 0e                	je     94ed <f23+0xcd>
    94df:	90                   	nop
    94e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    94e4:	48 83 c2 01          	add    $0x1,%rdx
    94e8:	48 85 c0             	test   %rax,%rax
    94eb:	75 f3                	jne    94e0 <f23+0xc0>
    94ed:	4d 85 ed             	test   %r13,%r13
    94f0:	0f 84 9a 02 00 00    	je     9790 <f23+0x370>
    94f6:	4c 89 e8             	mov    %r13,%rax
    94f9:	31 db                	xor    %ebx,%ebx
    94fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9500:	48 8b 40 10          	mov    0x10(%rax),%rax
    9504:	48 83 c3 01          	add    $0x1,%rbx
    9508:	48 85 c0             	test   %rax,%rax
    950b:	75 f3                	jne    9500 <f23+0xe0>
    950d:	48 39 d3             	cmp    %rdx,%rbx
    9510:	48 0f 47 da          	cmova  %rdx,%rbx
    9514:	48 89 d8             	mov    %rbx,%rax
    9517:	48 c1 e8 3c          	shr    $0x3c,%rax
    951b:	0f 85 7d 03 00 00    	jne    989e <f23+0x47e>
    9521:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9525:	be 02 00 00 00       	mov    $0x2,%esi
    952a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9531:	00 
    9532:	e8 d9 c9 ff ff       	call   5f10 <fwp_heap_alloc>
    9537:	48 89 28             	mov    %rbp,(%rax)
    953a:	48 8b 15 b7 06 06 00 	mov    0x606b7(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9541:	49 89 c4             	mov    %rax,%r12
    9544:	48 2b 05 85 06 06 00 	sub    0x60685(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    954b:	48 c1 e2 10          	shl    $0x10,%rdx
    954f:	48 39 d0             	cmp    %rdx,%rax
    9552:	73 57                	jae    95ab <f23+0x18b>
    9554:	48 89 c2             	mov    %rax,%rdx
    9557:	48 c1 ea 10          	shr    $0x10,%rdx
    955b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    955f:	48 8b 15 b2 06 06 00 	mov    0x606b2(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9566:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    956a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    956e:	48 85 ed             	test   %rbp,%rbp
    9571:	74 38                	je     95ab <f23+0x18b>
    9573:	0f b6 0a             	movzbl (%rdx),%ecx
    9576:	80 f9 02             	cmp    $0x2,%cl
    9579:	0f 84 d1 01 00 00    	je     9750 <f23+0x330>
    957f:	80 f9 01             	cmp    $0x1,%cl
    9582:	75 27                	jne    95ab <f23+0x18b>
    9584:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9587:	0f b7 c0             	movzwl %ax,%eax
    958a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    958d:	48 0f af c1          	imul   %rcx,%rax
    9591:	48 c1 e8 20          	shr    $0x20,%rax
    9595:	48 39 d0             	cmp    %rdx,%rax
    9598:	73 11                	jae    95ab <f23+0x18b>
    959a:	48 01 c5             	add    %rax,%rbp
    959d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    95a1:	0f 84 57 02 00 00    	je     97fe <f23+0x3de>
    95a7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    95ab:	48 85 db             	test   %rbx,%rbx
    95ae:	74 5d                	je     960d <f23+0x1ed>
    95b0:	48 c1 e3 04          	shl    $0x4,%rbx
    95b4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    95b9:	4c 89 e5             	mov    %r12,%rbp
    95bc:	4d 89 ef             	mov    %r13,%r15
    95bf:	4c 01 e3             	add    %r12,%rbx
    95c2:	0f 1f 00             	nopl   (%rax)
    95c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    95cc:	00 00 00 00 
    95d0:	49 8b 46 08          	mov    0x8(%r14),%rax
    95d4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    95d8:	48 83 c5 10          	add    $0x10,%rbp
    95dc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    95e1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    95e5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    95e9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    95ee:	e8 dd d0 ff ff       	call   66d0 <w107>
    95f3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    95f8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    95fc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9600:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9604:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9608:	48 39 dd             	cmp    %rbx,%rbp
    960b:	75 c3                	jne    95d0 <f23+0x1b0>
    960d:	4c 89 ef             	mov    %r13,%rdi
    9610:	e8 4b fb ff ff       	call   9160 <fwp_drop2>
    9615:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    961a:	e8 41 fb ff ff       	call   9160 <fwp_drop2>
    961f:	4c 89 e7             	mov    %r12,%rdi
    9622:	e8 19 d2 ff ff       	call   6840 <w164.constprop.0>
    9627:	4c 89 e7             	mov    %r12,%rdi
    962a:	48 89 c3             	mov    %rax,%rbx
    962d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9633:	e8 48 e4 ff ff       	call   7a80 <fwp_drop4>
    9638:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    963e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    9643:	31 ff                	xor    %edi,%edi
    9645:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    964a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    964e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9653:	e8 68 d2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    9658:	48 8b 15 99 05 06 00 	mov    0x60599(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    965f:	48 89 c5             	mov    %rax,%rbp
    9662:	48 2b 05 67 05 06 00 	sub    0x60567(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9669:	48 c1 e2 10          	shl    $0x10,%rdx
    966d:	48 39 d0             	cmp    %rdx,%rax
    9670:	73 55                	jae    96c7 <f23+0x2a7>
    9672:	48 89 c2             	mov    %rax,%rdx
    9675:	48 c1 ea 10          	shr    $0x10,%rdx
    9679:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    967d:	48 8b 15 94 05 06 00 	mov    0x60594(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9684:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9688:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    968c:	48 85 db             	test   %rbx,%rbx
    968f:	74 36                	je     96c7 <f23+0x2a7>
    9691:	0f b6 0a             	movzbl (%rdx),%ecx
    9694:	80 f9 02             	cmp    $0x2,%cl
    9697:	0f 84 a3 00 00 00    	je     9740 <f23+0x320>
    969d:	80 f9 01             	cmp    $0x1,%cl
    96a0:	75 25                	jne    96c7 <f23+0x2a7>
    96a2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96a5:	0f b7 c0             	movzwl %ax,%eax
    96a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96ab:	48 0f af c1          	imul   %rcx,%rax
    96af:	48 c1 e8 20          	shr    $0x20,%rax
    96b3:	48 39 d0             	cmp    %rdx,%rax
    96b6:	73 0f                	jae    96c7 <f23+0x2a7>
    96b8:	48 01 c3             	add    %rax,%rbx
    96bb:	80 3b ff             	cmpb   $0xff,(%rbx)
    96be:	0f 84 2d 01 00 00    	je     97f1 <f23+0x3d1>
    96c4:	c6 03 01             	movb   $0x1,(%rbx)
    96c7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    96cc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    96d3:	00 00 
    96d5:	0f 85 cf 01 00 00    	jne    98aa <f23+0x48a>
    96db:	48 83 c4 38          	add    $0x38,%rsp
    96df:	48 89 e8             	mov    %rbp,%rax
    96e2:	5b                   	pop    %rbx
    96e3:	5d                   	pop    %rbp
    96e4:	41 5c                	pop    %r12
    96e6:	41 5d                	pop    %r13
    96e8:	41 5e                	pop    %r14
    96ea:	41 5f                	pop    %r15
    96ec:	c3                   	ret
    96ed:	0f 1f 00             	nopl   (%rax)
    96f0:	66 85 c0             	test   %ax,%ax
    96f3:	0f 85 d3 fd ff ff    	jne    94cc <f23+0xac>
    96f9:	0f b6 07             	movzbl (%rdi),%eax
    96fc:	84 c0                	test   %al,%al
    96fe:	0f 84 c8 fd ff ff    	je     94cc <f23+0xac>
    9704:	90                   	nop
    9705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    970c:	00 00 00 00 
    9710:	8b 15 d2 0d 06 00    	mov    0x60dd2(%rip),%edx        # 6a4e8 <iteration_active>
    9716:	85 d2                	test   %edx,%edx
    9718:	75 56                	jne    9770 <f23+0x350>
    971a:	3c fd                	cmp    $0xfd,%al
    971c:	0f 87 4b 01 00 00    	ja     986d <f23+0x44d>
    9722:	83 c0 01             	add    $0x1,%eax
    9725:	88 07                	mov    %al,(%rdi)
    9727:	31 d2                	xor    %edx,%edx
    9729:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    972f:	0f 85 97 fd ff ff    	jne    94cc <f23+0xac>
    9735:	e9 b3 fd ff ff       	jmp    94ed <f23+0xcd>
    973a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9740:	66 85 c0             	test   %ax,%ax
    9743:	0f 85 7e ff ff ff    	jne    96c7 <f23+0x2a7>
    9749:	e9 6d ff ff ff       	jmp    96bb <f23+0x29b>
    974e:	66 90                	xchg   %ax,%ax
    9750:	66 85 c0             	test   %ax,%ax
    9753:	0f 85 52 fe ff ff    	jne    95ab <f23+0x18b>
    9759:	e9 3f fe ff ff       	jmp    959d <f23+0x17d>
    975e:	66 90                	xchg   %ax,%ax
    9760:	4c 89 e8             	mov    %r13,%rax
    9763:	e9 6d fd ff ff       	jmp    94d5 <f23+0xb5>
    9768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    976f:	00 
    9770:	48 83 05 58 0d 06 00 	addq   $0x1,0x60d58(%rip)        # 6a4d0 <iteration_retains>
    9777:	01 
    9778:	eb a0                	jmp    971a <f23+0x2fa>
    977a:	48 f7 d9             	neg    %rcx
    977d:	48 39 d1             	cmp    %rdx,%rcx
    9780:	0f 82 85 00 00 00    	jb     980b <f23+0x3eb>
    9786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    978d:	00 00 00 
    9790:	be 02 00 00 00       	mov    $0x2,%esi
    9795:	bf 08 00 00 00       	mov    $0x8,%edi
    979a:	e8 71 c7 ff ff       	call   5f10 <fwp_heap_alloc>
    979f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    97a6:	48 8b 15 4b 04 06 00 	mov    0x6044b(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    97ad:	49 89 c4             	mov    %rax,%r12
    97b0:	48 2b 05 19 04 06 00 	sub    0x60419(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    97b7:	48 c1 e2 10          	shl    $0x10,%rdx
    97bb:	48 39 d0             	cmp    %rdx,%rax
    97be:	0f 83 b3 00 00 00    	jae    9877 <f23+0x457>
    97c4:	48 89 c2             	mov    %rax,%rdx
    97c7:	48 c1 ea 10          	shr    $0x10,%rdx
    97cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97cf:	48 8b 15 42 04 06 00 	mov    0x60442(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    97d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97da:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    97de:	48 85 ed             	test   %rbp,%rbp
    97e1:	0f 84 90 00 00 00    	je     9877 <f23+0x457>
    97e7:	31 db                	xor    %ebx,%ebx
    97e9:	45 31 ed             	xor    %r13d,%r13d
    97ec:	e9 82 fd ff ff       	jmp    9573 <f23+0x153>
    97f1:	48 89 df             	mov    %rbx,%rdi
    97f4:	e8 d7 bf ff ff       	call   57d0 <fwp_rc_forget_slot>
    97f9:	e9 c6 fe ff ff       	jmp    96c4 <f23+0x2a4>
    97fe:	48 89 ef             	mov    %rbp,%rdi
    9801:	e8 ca bf ff ff       	call   57d0 <fwp_rc_forget_slot>
    9806:	e9 9c fd ff ff       	jmp    95a7 <f23+0x187>
    980b:	48 89 c8             	mov    %rcx,%rax
    980e:	48 c1 e8 10          	shr    $0x10,%rax
    9812:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9816:	48 8b 05 fb 03 06 00 	mov    0x603fb(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    981d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9821:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9825:	48 85 ff             	test   %rdi,%rdi
    9828:	0f 84 62 ff ff ff    	je     9790 <f23+0x370>
    982e:	0f b6 02             	movzbl (%rdx),%eax
    9831:	3c 02                	cmp    $0x2,%al
    9833:	74 4a                	je     987f <f23+0x45f>
    9835:	3c 01                	cmp    $0x1,%al
    9837:	0f 85 53 ff ff ff    	jne    9790 <f23+0x370>
    983d:	0f b7 c1             	movzwl %cx,%eax
    9840:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9843:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9846:	48 0f af c1          	imul   %rcx,%rax
    984a:	48 c1 e8 20          	shr    $0x20,%rax
    984e:	48 39 d0             	cmp    %rdx,%rax
    9851:	0f 83 39 ff ff ff    	jae    9790 <f23+0x370>
    9857:	48 01 c7             	add    %rax,%rdi
    985a:	0f b6 07             	movzbl (%rdi),%eax
    985d:	84 c0                	test   %al,%al
    985f:	0f 84 2b ff ff ff    	je     9790 <f23+0x370>
    9865:	45 31 ed             	xor    %r13d,%r13d
    9868:	e9 a3 fe ff ff       	jmp    9710 <f23+0x2f0>
    986d:	e8 3e be ff ff       	call   56b0 <fwp_rc_wide_dup>
    9872:	e9 b0 fe ff ff       	jmp    9727 <f23+0x307>
    9877:	45 31 ed             	xor    %r13d,%r13d
    987a:	e9 8e fd ff ff       	jmp    960d <f23+0x1ed>
    987f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    9885:	49 89 cd             	mov    %rcx,%r13
    9888:	0f 85 02 ff ff ff    	jne    9790 <f23+0x370>
    988e:	0f b6 07             	movzbl (%rdi),%eax
    9891:	84 c0                	test   %al,%al
    9893:	0f 85 77 fe ff ff    	jne    9710 <f23+0x2f0>
    9899:	e9 f2 fe ff ff       	jmp    9790 <f23+0x370>
    989e:	48 8d 3d 60 29 00 00 	lea    0x2960(%rip),%rdi        # c205 <_IO_stdin_used+0x205>
    98a5:	e8 a6 ab ff ff       	call   4450 <fwp_trap>
    98aa:	e8 a1 9b ff ff       	call   3450 <__stack_chk_fail@plt>
    98af:	90                   	nop

00000000000098b0 <fwp_owned_entry23>:
    98b0:	f3 0f 1e fa          	endbr64
    98b4:	48 8b 3f             	mov    (%rdi),%rdi
    98b7:	e9 64 fb ff ff       	jmp    9420 <f23>
    98bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000098c0 <e23>:
    98c0:	f3 0f 1e fa          	endbr64
    98c4:	53                   	push   %rbx
    98c5:	48 8b 1f             	mov    (%rdi),%rbx
    98c8:	48 89 df             	mov    %rbx,%rdi
    98cb:	e8 e0 d1 ff ff       	call   6ab0 <fwp_rc_share>
    98d0:	48 89 df             	mov    %rbx,%rdi
    98d3:	e8 48 fb ff ff       	call   9420 <f23>
    98d8:	48 89 c3             	mov    %rax,%rbx
    98db:	48 89 c7             	mov    %rax,%rdi
    98de:	e8 cd d1 ff ff       	call   6ab0 <fwp_rc_share>
    98e3:	48 89 d8             	mov    %rbx,%rax
    98e6:	5b                   	pop    %rbx
    98e7:	c3                   	ret
    98e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    98ef:	00 

00000000000098f0 <fwp_args12>:
    98f0:	f3 0f 1e fa          	endbr64
    98f4:	85 d2                	test   %edx,%edx
    98f6:	74 04                	je     98fc <fwp_args12+0xc>
    98f8:	85 f6                	test   %esi,%esi
    98fa:	74 04                	je     9900 <fwp_args12+0x10>
    98fc:	c3                   	ret
    98fd:	0f 1f 00             	nopl   (%rax)
    9900:	48 8b 15 f1 02 06 00 	mov    0x602f1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9907:	48 8b 07             	mov    (%rdi),%rax
    990a:	48 2b 05 bf 02 06 00 	sub    0x602bf(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9911:	48 c1 e2 10          	shl    $0x10,%rdx
    9915:	48 39 d0             	cmp    %rdx,%rax
    9918:	73 e2                	jae    98fc <fwp_args12+0xc>
    991a:	48 89 c2             	mov    %rax,%rdx
    991d:	48 c1 ea 10          	shr    $0x10,%rdx
    9921:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9925:	48 8b 15 ec 02 06 00 	mov    0x602ec(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    992c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9930:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9934:	48 85 ff             	test   %rdi,%rdi
    9937:	74 c3                	je     98fc <fwp_args12+0xc>
    9939:	0f b6 0a             	movzbl (%rdx),%ecx
    993c:	80 f9 02             	cmp    $0x2,%cl
    993f:	74 4f                	je     9990 <fwp_args12+0xa0>
    9941:	80 f9 01             	cmp    $0x1,%cl
    9944:	75 b6                	jne    98fc <fwp_args12+0xc>
    9946:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9949:	0f b7 c0             	movzwl %ax,%eax
    994c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    994f:	48 0f af c1          	imul   %rcx,%rax
    9953:	48 c1 e8 20          	shr    $0x20,%rax
    9957:	48 39 d0             	cmp    %rdx,%rax
    995a:	73 a0                	jae    98fc <fwp_args12+0xc>
    995c:	48 01 c7             	add    %rax,%rdi
    995f:	0f b6 07             	movzbl (%rdi),%eax
    9962:	84 c0                	test   %al,%al
    9964:	74 96                	je     98fc <fwp_args12+0xc>
    9966:	8b 15 7c 0b 06 00    	mov    0x60b7c(%rip),%edx        # 6a4e8 <iteration_active>
    996c:	85 d2                	test   %edx,%edx
    996e:	75 10                	jne    9980 <fwp_args12+0x90>
    9970:	3c fd                	cmp    $0xfd,%al
    9972:	77 22                	ja     9996 <fwp_args12+0xa6>
    9974:	83 c0 01             	add    $0x1,%eax
    9977:	88 07                	mov    %al,(%rdi)
    9979:	c3                   	ret
    997a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9980:	48 83 05 48 0b 06 00 	addq   $0x1,0x60b48(%rip)        # 6a4d0 <iteration_retains>
    9987:	01 
    9988:	eb e6                	jmp    9970 <fwp_args12+0x80>
    998a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9990:	66 85 c0             	test   %ax,%ax
    9993:	74 ca                	je     995f <fwp_args12+0x6f>
    9995:	c3                   	ret
    9996:	e9 15 bd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    999b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000099a0 <fwp_args23>:
    99a0:	f3 0f 1e fa          	endbr64
    99a4:	85 d2                	test   %edx,%edx
    99a6:	74 04                	je     99ac <fwp_args23+0xc>
    99a8:	85 f6                	test   %esi,%esi
    99aa:	74 04                	je     99b0 <fwp_args23+0x10>
    99ac:	c3                   	ret
    99ad:	0f 1f 00             	nopl   (%rax)
    99b0:	48 8b 15 41 02 06 00 	mov    0x60241(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    99b7:	48 8b 07             	mov    (%rdi),%rax
    99ba:	48 2b 05 0f 02 06 00 	sub    0x6020f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    99c1:	48 c1 e2 10          	shl    $0x10,%rdx
    99c5:	48 39 d0             	cmp    %rdx,%rax
    99c8:	73 e2                	jae    99ac <fwp_args23+0xc>
    99ca:	48 89 c2             	mov    %rax,%rdx
    99cd:	48 c1 ea 10          	shr    $0x10,%rdx
    99d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99d5:	48 8b 15 3c 02 06 00 	mov    0x6023c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    99dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99e0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99e4:	48 85 ff             	test   %rdi,%rdi
    99e7:	74 c3                	je     99ac <fwp_args23+0xc>
    99e9:	0f b6 0a             	movzbl (%rdx),%ecx
    99ec:	80 f9 02             	cmp    $0x2,%cl
    99ef:	74 4f                	je     9a40 <fwp_args23+0xa0>
    99f1:	80 f9 01             	cmp    $0x1,%cl
    99f4:	75 b6                	jne    99ac <fwp_args23+0xc>
    99f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99f9:	0f b7 c0             	movzwl %ax,%eax
    99fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99ff:	48 0f af c1          	imul   %rcx,%rax
    9a03:	48 c1 e8 20          	shr    $0x20,%rax
    9a07:	48 39 d0             	cmp    %rdx,%rax
    9a0a:	73 a0                	jae    99ac <fwp_args23+0xc>
    9a0c:	48 01 c7             	add    %rax,%rdi
    9a0f:	0f b6 07             	movzbl (%rdi),%eax
    9a12:	84 c0                	test   %al,%al
    9a14:	74 96                	je     99ac <fwp_args23+0xc>
    9a16:	8b 15 cc 0a 06 00    	mov    0x60acc(%rip),%edx        # 6a4e8 <iteration_active>
    9a1c:	85 d2                	test   %edx,%edx
    9a1e:	75 10                	jne    9a30 <fwp_args23+0x90>
    9a20:	3c fd                	cmp    $0xfd,%al
    9a22:	77 22                	ja     9a46 <fwp_args23+0xa6>
    9a24:	83 c0 01             	add    $0x1,%eax
    9a27:	88 07                	mov    %al,(%rdi)
    9a29:	c3                   	ret
    9a2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a30:	48 83 05 98 0a 06 00 	addq   $0x1,0x60a98(%rip)        # 6a4d0 <iteration_retains>
    9a37:	01 
    9a38:	eb e6                	jmp    9a20 <fwp_args23+0x80>
    9a3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a40:	66 85 c0             	test   %ax,%ax
    9a43:	74 ca                	je     9a0f <fwp_args23+0x6f>
    9a45:	c3                   	ret
    9a46:	e9 65 bc ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9a4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000009a50 <fwp_caps12>:
    9a50:	f3 0f 1e fa          	endbr64
    9a54:	48 83 ec 18          	sub    $0x18,%rsp
    9a58:	48 89 f8             	mov    %rdi,%rax
    9a5b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9a5e:	85 ff                	test   %edi,%edi
    9a60:	0f 84 9a 00 00 00    	je     9b00 <fwp_caps12+0xb0>
    9a66:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9a6a:	85 f6                	test   %esi,%esi
    9a6c:	0f 85 9e 00 00 00    	jne    9b10 <fwp_caps12+0xc0>
    9a72:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9a77:	e8 e4 d3 ff ff       	call   6e60 <fwp_drop0>
    9a7c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9a81:	48 8b 0d 70 01 06 00 	mov    0x60170(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    9a88:	48 89 c2             	mov    %rax,%rdx
    9a8b:	48 2b 15 3e 01 06 00 	sub    0x6013e(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    9a92:	48 c1 e1 10          	shl    $0x10,%rcx
    9a96:	48 39 ca             	cmp    %rcx,%rdx
    9a99:	73 6d                	jae    9b08 <fwp_caps12+0xb8>
    9a9b:	48 89 d1             	mov    %rdx,%rcx
    9a9e:	48 c1 e9 10          	shr    $0x10,%rcx
    9aa2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9aa6:	48 8b 0d 6b 01 06 00 	mov    0x6016b(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    9aad:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9ab1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9ab5:	48 85 f6             	test   %rsi,%rsi
    9ab8:	74 4e                	je     9b08 <fwp_caps12+0xb8>
    9aba:	0f b6 39             	movzbl (%rcx),%edi
    9abd:	40 80 ff 02          	cmp    $0x2,%dil
    9ac1:	0f 84 c9 00 00 00    	je     9b90 <fwp_caps12+0x140>
    9ac7:	40 80 ff 01          	cmp    $0x1,%dil
    9acb:	75 3b                	jne    9b08 <fwp_caps12+0xb8>
    9acd:	8b 79 18             	mov    0x18(%rcx),%edi
    9ad0:	0f b7 d2             	movzwl %dx,%edx
    9ad3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9ad6:	48 0f af d7          	imul   %rdi,%rdx
    9ada:	48 c1 ea 20          	shr    $0x20,%rdx
    9ade:	48 39 ca             	cmp    %rcx,%rdx
    9ae1:	73 25                	jae    9b08 <fwp_caps12+0xb8>
    9ae3:	48 01 d6             	add    %rdx,%rsi
    9ae6:	80 3e 01             	cmpb   $0x1,(%rsi)
    9ae9:	75 1d                	jne    9b08 <fwp_caps12+0xb8>
    9aeb:	48 89 c7             	mov    %rax,%rdi
    9aee:	48 83 c4 18          	add    $0x18,%rsp
    9af2:	e9 19 bf ff ff       	jmp    5a10 <fwp_mem_free>
    9af7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9afe:	00 00 
    9b00:	85 f6                	test   %esi,%esi
    9b02:	0f 84 79 ff ff ff    	je     9a81 <fwp_caps12+0x31>
    9b08:	48 83 c4 18          	add    $0x18,%rsp
    9b0c:	c3                   	ret
    9b0d:	0f 1f 00             	nopl   (%rax)
    9b10:	48 8b 05 e1 00 06 00 	mov    0x600e1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    9b17:	48 2b 3d b2 00 06 00 	sub    0x600b2(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    9b1e:	48 c1 e0 10          	shl    $0x10,%rax
    9b22:	48 39 c7             	cmp    %rax,%rdi
    9b25:	73 e1                	jae    9b08 <fwp_caps12+0xb8>
    9b27:	48 89 f8             	mov    %rdi,%rax
    9b2a:	48 c1 e8 10          	shr    $0x10,%rax
    9b2e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9b32:	48 8b 05 df 00 06 00 	mov    0x600df(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    9b39:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9b3d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9b41:	48 85 c0             	test   %rax,%rax
    9b44:	74 c2                	je     9b08 <fwp_caps12+0xb8>
    9b46:	0f b6 0a             	movzbl (%rdx),%ecx
    9b49:	80 f9 02             	cmp    $0x2,%cl
    9b4c:	74 52                	je     9ba0 <fwp_caps12+0x150>
    9b4e:	80 f9 01             	cmp    $0x1,%cl
    9b51:	75 b5                	jne    9b08 <fwp_caps12+0xb8>
    9b53:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b56:	0f b7 ff             	movzwl %di,%edi
    9b59:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b5c:	48 0f af f9          	imul   %rcx,%rdi
    9b60:	48 c1 ef 20          	shr    $0x20,%rdi
    9b64:	48 39 d7             	cmp    %rdx,%rdi
    9b67:	73 9f                	jae    9b08 <fwp_caps12+0xb8>
    9b69:	48 01 f8             	add    %rdi,%rax
    9b6c:	0f b6 10             	movzbl (%rax),%edx
    9b6f:	84 d2                	test   %dl,%dl
    9b71:	74 95                	je     9b08 <fwp_caps12+0xb8>
    9b73:	8b 0d 6f 09 06 00    	mov    0x6096f(%rip),%ecx        # 6a4e8 <iteration_active>
    9b79:	85 c9                	test   %ecx,%ecx
    9b7b:	75 33                	jne    9bb0 <fwp_caps12+0x160>
    9b7d:	80 fa fd             	cmp    $0xfd,%dl
    9b80:	77 38                	ja     9bba <fwp_caps12+0x16a>
    9b82:	83 c2 01             	add    $0x1,%edx
    9b85:	88 10                	mov    %dl,(%rax)
    9b87:	e9 7c ff ff ff       	jmp    9b08 <fwp_caps12+0xb8>
    9b8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b90:	66 85 d2             	test   %dx,%dx
    9b93:	0f 85 6f ff ff ff    	jne    9b08 <fwp_caps12+0xb8>
    9b99:	e9 48 ff ff ff       	jmp    9ae6 <fwp_caps12+0x96>
    9b9e:	66 90                	xchg   %ax,%ax
    9ba0:	66 85 ff             	test   %di,%di
    9ba3:	0f 85 5f ff ff ff    	jne    9b08 <fwp_caps12+0xb8>
    9ba9:	eb c1                	jmp    9b6c <fwp_caps12+0x11c>
    9bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9bb0:	48 83 05 18 09 06 00 	addq   $0x1,0x60918(%rip)        # 6a4d0 <iteration_retains>
    9bb7:	01 
    9bb8:	eb c3                	jmp    9b7d <fwp_caps12+0x12d>
    9bba:	48 89 c7             	mov    %rax,%rdi
    9bbd:	48 83 c4 18          	add    $0x18,%rsp
    9bc1:	e9 ea ba ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9bc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9bcd:	00 00 00 

0000000000009bd0 <fwp_caps23>:
    9bd0:	f3 0f 1e fa          	endbr64
    9bd4:	48 83 ec 18          	sub    $0x18,%rsp
    9bd8:	48 89 f8             	mov    %rdi,%rax
    9bdb:	8b 7f 04             	mov    0x4(%rdi),%edi
    9bde:	85 ff                	test   %edi,%edi
    9be0:	0f 84 9a 00 00 00    	je     9c80 <fwp_caps23+0xb0>
    9be6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9bea:	85 f6                	test   %esi,%esi
    9bec:	0f 85 9e 00 00 00    	jne    9c90 <fwp_caps23+0xc0>
    9bf2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9bf7:	e8 64 f5 ff ff       	call   9160 <fwp_drop2>
    9bfc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9c01:	48 8b 0d f0 ff 05 00 	mov    0x5fff0(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    9c08:	48 89 c2             	mov    %rax,%rdx
    9c0b:	48 2b 15 be ff 05 00 	sub    0x5ffbe(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    9c12:	48 c1 e1 10          	shl    $0x10,%rcx
    9c16:	48 39 ca             	cmp    %rcx,%rdx
    9c19:	73 6d                	jae    9c88 <fwp_caps23+0xb8>
    9c1b:	48 89 d1             	mov    %rdx,%rcx
    9c1e:	48 c1 e9 10          	shr    $0x10,%rcx
    9c22:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9c26:	48 8b 0d eb ff 05 00 	mov    0x5ffeb(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    9c2d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9c31:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9c35:	48 85 f6             	test   %rsi,%rsi
    9c38:	74 4e                	je     9c88 <fwp_caps23+0xb8>
    9c3a:	0f b6 39             	movzbl (%rcx),%edi
    9c3d:	40 80 ff 02          	cmp    $0x2,%dil
    9c41:	0f 84 c9 00 00 00    	je     9d10 <fwp_caps23+0x140>
    9c47:	40 80 ff 01          	cmp    $0x1,%dil
    9c4b:	75 3b                	jne    9c88 <fwp_caps23+0xb8>
    9c4d:	8b 79 18             	mov    0x18(%rcx),%edi
    9c50:	0f b7 d2             	movzwl %dx,%edx
    9c53:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9c56:	48 0f af d7          	imul   %rdi,%rdx
    9c5a:	48 c1 ea 20          	shr    $0x20,%rdx
    9c5e:	48 39 ca             	cmp    %rcx,%rdx
    9c61:	73 25                	jae    9c88 <fwp_caps23+0xb8>
    9c63:	48 01 d6             	add    %rdx,%rsi
    9c66:	80 3e 01             	cmpb   $0x1,(%rsi)
    9c69:	75 1d                	jne    9c88 <fwp_caps23+0xb8>
    9c6b:	48 89 c7             	mov    %rax,%rdi
    9c6e:	48 83 c4 18          	add    $0x18,%rsp
    9c72:	e9 99 bd ff ff       	jmp    5a10 <fwp_mem_free>
    9c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c7e:	00 00 
    9c80:	85 f6                	test   %esi,%esi
    9c82:	0f 84 79 ff ff ff    	je     9c01 <fwp_caps23+0x31>
    9c88:	48 83 c4 18          	add    $0x18,%rsp
    9c8c:	c3                   	ret
    9c8d:	0f 1f 00             	nopl   (%rax)
    9c90:	48 8b 05 61 ff 05 00 	mov    0x5ff61(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    9c97:	48 2b 3d 32 ff 05 00 	sub    0x5ff32(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    9c9e:	48 c1 e0 10          	shl    $0x10,%rax
    9ca2:	48 39 c7             	cmp    %rax,%rdi
    9ca5:	73 e1                	jae    9c88 <fwp_caps23+0xb8>
    9ca7:	48 89 f8             	mov    %rdi,%rax
    9caa:	48 c1 e8 10          	shr    $0x10,%rax
    9cae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9cb2:	48 8b 05 5f ff 05 00 	mov    0x5ff5f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    9cb9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9cbd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9cc1:	48 85 c0             	test   %rax,%rax
    9cc4:	74 c2                	je     9c88 <fwp_caps23+0xb8>
    9cc6:	0f b6 0a             	movzbl (%rdx),%ecx
    9cc9:	80 f9 02             	cmp    $0x2,%cl
    9ccc:	74 52                	je     9d20 <fwp_caps23+0x150>
    9cce:	80 f9 01             	cmp    $0x1,%cl
    9cd1:	75 b5                	jne    9c88 <fwp_caps23+0xb8>
    9cd3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cd6:	0f b7 ff             	movzwl %di,%edi
    9cd9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9cdc:	48 0f af f9          	imul   %rcx,%rdi
    9ce0:	48 c1 ef 20          	shr    $0x20,%rdi
    9ce4:	48 39 d7             	cmp    %rdx,%rdi
    9ce7:	73 9f                	jae    9c88 <fwp_caps23+0xb8>
    9ce9:	48 01 f8             	add    %rdi,%rax
    9cec:	0f b6 10             	movzbl (%rax),%edx
    9cef:	84 d2                	test   %dl,%dl
    9cf1:	74 95                	je     9c88 <fwp_caps23+0xb8>
    9cf3:	8b 0d ef 07 06 00    	mov    0x607ef(%rip),%ecx        # 6a4e8 <iteration_active>
    9cf9:	85 c9                	test   %ecx,%ecx
    9cfb:	75 33                	jne    9d30 <fwp_caps23+0x160>
    9cfd:	80 fa fd             	cmp    $0xfd,%dl
    9d00:	77 38                	ja     9d3a <fwp_caps23+0x16a>
    9d02:	83 c2 01             	add    $0x1,%edx
    9d05:	88 10                	mov    %dl,(%rax)
    9d07:	e9 7c ff ff ff       	jmp    9c88 <fwp_caps23+0xb8>
    9d0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d10:	66 85 d2             	test   %dx,%dx
    9d13:	0f 85 6f ff ff ff    	jne    9c88 <fwp_caps23+0xb8>
    9d19:	e9 48 ff ff ff       	jmp    9c66 <fwp_caps23+0x96>
    9d1e:	66 90                	xchg   %ax,%ax
    9d20:	66 85 ff             	test   %di,%di
    9d23:	0f 85 5f ff ff ff    	jne    9c88 <fwp_caps23+0xb8>
    9d29:	eb c1                	jmp    9cec <fwp_caps23+0x11c>
    9d2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d30:	48 83 05 98 07 06 00 	addq   $0x1,0x60798(%rip)        # 6a4d0 <iteration_retains>
    9d37:	01 
    9d38:	eb c3                	jmp    9cfd <fwp_caps23+0x12d>
    9d3a:	48 89 c7             	mov    %rax,%rdi
    9d3d:	48 83 c4 18          	add    $0x18,%rsp
    9d41:	e9 6a b9 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d4d:	00 00 00 

0000000000009d50 <fwp_write>:
    9d50:	41 57                	push   %r15
    9d52:	41 56                	push   %r14
    9d54:	41 55                	push   %r13
    9d56:	41 54                	push   %r12
    9d58:	55                   	push   %rbp
    9d59:	53                   	push   %rbx
    9d5a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9d61:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9d68:	00 00 
    9d6a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9d71:	00 
    9d72:	49 89 d4             	mov    %rdx,%r12
    9d75:	8b 12                	mov    (%rdx),%edx
    9d77:	83 fa 19             	cmp    $0x19,%edx
    9d7a:	77 6a                	ja     9de6 <fwp_write+0x96>
    9d7c:	48 89 f5             	mov    %rsi,%rbp
    9d7f:	89 d0                	mov    %edx,%eax
    9d81:	89 ce                	mov    %ecx,%esi
    9d83:	48 89 fb             	mov    %rdi,%rbx
    9d86:	48 8d 0d 33 2f 00 00 	lea    0x2f33(%rip),%rcx        # ccc0 <_IO_stdin_used+0xcc0>
    9d8d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9d91:	48 01 c8             	add    %rcx,%rax
    9d94:	3e ff e0             	notrack jmp *%rax
    9d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d9e:	00 00 
    9da0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9da4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9da8:	48 89 ca             	mov    %rcx,%rdx
    9dab:	48 85 c9             	test   %rcx,%rcx
    9dae:	0f 88 9c 0c 00 00    	js     aa50 <fwp_write+0xd00>
    9db4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9dbb:	00 
    9dbc:	48 89 c6             	mov    %rax,%rsi
    9dbf:	4c 89 e7             	mov    %r12,%rdi
    9dc2:	e8 79 9c ff ff       	call   3a40 <fwp_fmt_u128>
    9dc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dce:	00 00 
    9dd0:	4c 89 e7             	mov    %r12,%rdi
    9dd3:	e8 68 96 ff ff       	call   3440 <strlen@plt>
    9dd8:	4c 89 e6             	mov    %r12,%rsi
    9ddb:	48 89 df             	mov    %rbx,%rdi
    9dde:	48 89 c2             	mov    %rax,%rdx
    9de1:	e8 0a a3 ff ff       	call   40f0 <buf_put>
    9de6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ded:	00 
    9dee:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9df5:	00 00 
    9df7:	0f 85 28 04 00 00    	jne    a225 <fwp_write+0x4d5>
    9dfd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9e04:	5b                   	pop    %rbx
    9e05:	5d                   	pop    %rbp
    9e06:	41 5c                	pop    %r12
    9e08:	41 5d                	pop    %r13
    9e0a:	41 5e                	pop    %r14
    9e0c:	41 5f                	pop    %r15
    9e0e:	c3                   	ret
    9e0f:	90                   	nop
    9e10:	49 89 e9             	mov    %rbp,%r9
    9e13:	4c 8d 05 41 24 00 00 	lea    0x2441(%rip),%r8        # c25b <_IO_stdin_used+0x25b>
    9e1a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9e1f:	ba 02 00 00 00       	mov    $0x2,%edx
    9e24:	be 00 02 00 00       	mov    $0x200,%esi
    9e29:	31 c0                	xor    %eax,%eax
    9e2b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9e32:	00 
    9e33:	e8 68 95 ff ff       	call   33a0 <__snprintf_chk@plt>
    9e38:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9e3f:	00 
    9e40:	e8 fb 95 ff ff       	call   3440 <strlen@plt>
    9e45:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9e4c:	00 
    9e4d:	48 89 df             	mov    %rbx,%rdi
    9e50:	48 89 c2             	mov    %rax,%rdx
    9e53:	e8 98 a2 ff ff       	call   40f0 <buf_put>
    9e58:	eb 8c                	jmp    9de6 <fwp_write+0x96>
    9e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e60:	49 89 e9             	mov    %rbp,%r9
    9e63:	4c 8d 05 ec 23 00 00 	lea    0x23ec(%rip),%r8        # c256 <_IO_stdin_used+0x256>
    9e6a:	eb ae                	jmp    9e1a <fwp_write+0xca>
    9e6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e70:	83 fa 13             	cmp    $0x13,%edx
    9e73:	48 8d 05 d2 23 00 00 	lea    0x23d2(%rip),%rax        # c24c <_IO_stdin_used+0x24c>
    9e7a:	48 8d 35 d0 23 00 00 	lea    0x23d0(%rip),%rsi        # c251 <_IO_stdin_used+0x251>
    9e81:	ba 04 00 00 00       	mov    $0x4,%edx
    9e86:	48 0f 44 f0          	cmove  %rax,%rsi
    9e8a:	45 31 ed             	xor    %r13d,%r13d
    9e8d:	e8 5e a2 ff ff       	call   40f0 <buf_put>
    9e92:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e97:	0f 84 a3 08 00 00    	je     a740 <fwp_write+0x9f0>
    9e9d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9ea2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9ea7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9eac:	48 89 df             	mov    %rbx,%rdi
    9eaf:	49 0f 44 c5          	cmove  %r13,%rax
    9eb3:	31 c9                	xor    %ecx,%ecx
    9eb5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9eba:	e8 91 fe ff ff       	call   9d50 <fwp_write>
    9ebf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9ec4:	0f 84 6e 09 00 00    	je     a838 <fwp_write+0xae8>
    9eca:	49 83 c5 01          	add    $0x1,%r13
    9ece:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9ed2:	0f 83 68 08 00 00    	jae    a740 <fwp_write+0x9f0>
    9ed8:	ba 02 00 00 00       	mov    $0x2,%edx
    9edd:	48 8d 35 b7 23 00 00 	lea    0x23b7(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    9ee4:	48 89 df             	mov    %rbx,%rdi
    9ee7:	e8 04 a2 ff ff       	call   40f0 <buf_put>
    9eec:	eb af                	jmp    9e9d <fwp_write+0x14d>
    9eee:	66 90                	xchg   %ax,%ax
    9ef0:	ba 06 00 00 00       	mov    $0x6,%edx
    9ef5:	48 8d 35 78 23 00 00 	lea    0x2378(%rip),%rsi        # c274 <_IO_stdin_used+0x274>
    9efc:	48 83 c5 10          	add    $0x10,%rbp
    9f00:	e8 eb a1 ff ff       	call   40f0 <buf_put>
    9f05:	48 89 ef             	mov    %rbp,%rdi
    9f08:	e8 33 95 ff ff       	call   3440 <strlen@plt>
    9f0d:	48 89 ee             	mov    %rbp,%rsi
    9f10:	48 89 df             	mov    %rbx,%rdi
    9f13:	48 89 c2             	mov    %rax,%rdx
    9f16:	e8 d5 a1 ff ff       	call   40f0 <buf_put>
    9f1b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f20:	ba 01 00 00 00       	mov    $0x1,%edx
    9f25:	48 89 df             	mov    %rbx,%rdi
    9f28:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9f2d:	e8 be a1 ff ff       	call   40f0 <buf_put>
    9f32:	e9 af fe ff ff       	jmp    9de6 <fwp_write+0x96>
    9f37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f3e:	00 00 
    9f40:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f47:	00 
    9f48:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f4f:	00 00 
    9f51:	0f 85 ce 02 00 00    	jne    a225 <fwp_write+0x4d5>
    9f57:	ba 0a 00 00 00       	mov    $0xa,%edx
    9f5c:	48 8d 35 fd 22 00 00 	lea    0x22fd(%rip),%rsi        # c260 <_IO_stdin_used+0x260>
    9f63:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9f6a:	48 89 df             	mov    %rbx,%rdi
    9f6d:	5b                   	pop    %rbx
    9f6e:	5d                   	pop    %rbp
    9f6f:	41 5c                	pop    %r12
    9f71:	41 5d                	pop    %r13
    9f73:	41 5e                	pop    %r14
    9f75:	41 5f                	pop    %r15
    9f77:	e9 74 a1 ff ff       	jmp    40f0 <buf_put>
    9f7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f80:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9f85:	4d 85 ed             	test   %r13,%r13
    9f88:	0f 84 02 0c 00 00    	je     ab90 <fwp_write+0xe40>
    9f8e:	48 8d 35 13 23 00 00 	lea    0x2313(%rip),%rsi        # c2a8 <_IO_stdin_used+0x2a8>
    9f95:	4c 89 ef             	mov    %r13,%rdi
    9f98:	e8 83 95 ff ff       	call   3520 <strcmp@plt>
    9f9d:	41 89 c1             	mov    %eax,%r9d
    9fa0:	85 c0                	test   %eax,%eax
    9fa2:	0f 84 6c 0c 00 00    	je     ac14 <fwp_write+0xec4>
    9fa8:	4c 89 ef             	mov    %r13,%rdi
    9fab:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9fb0:	e8 8b 94 ff ff       	call   3440 <strlen@plt>
    9fb5:	4c 89 ee             	mov    %r13,%rsi
    9fb8:	48 89 df             	mov    %rbx,%rdi
    9fbb:	48 89 c2             	mov    %rax,%rdx
    9fbe:	e8 2d a1 ff ff       	call   40f0 <buf_put>
    9fc3:	ba 01 00 00 00       	mov    $0x1,%edx
    9fc8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fcd:	48 89 df             	mov    %rbx,%rdi
    9fd0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9fd5:	e8 16 a1 ff ff       	call   40f0 <buf_put>
    9fda:	ba 01 00 00 00       	mov    $0x1,%edx
    9fdf:	4c 89 fe             	mov    %r15,%rsi
    9fe2:	48 89 df             	mov    %rbx,%rdi
    9fe5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9fea:	e8 01 a1 ff ff       	call   40f0 <buf_put>
    9fef:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9ff4:	45 31 f6             	xor    %r14d,%r14d
    9ff7:	85 d2                	test   %edx,%edx
    9ff9:	0f 8e 81 0a 00 00    	jle    aa80 <fwp_write+0xd30>
    9fff:	45 31 ed             	xor    %r13d,%r13d
    a002:	4d 85 ed             	test   %r13,%r13
    a005:	0f 85 75 07 00 00    	jne    a780 <fwp_write+0xa30>
    a00b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a012:	00 
    a013:	45 85 f6             	test   %r14d,%r14d
    a016:	0f 84 84 07 00 00    	je     a7a0 <fwp_write+0xa50>
    a01c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a021:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a026:	48 89 df             	mov    %rbx,%rdi
    a029:	49 83 c5 01          	add    $0x1,%r13
    a02d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a031:	31 c9                	xor    %ecx,%ecx
    a033:	e8 18 fd ff ff       	call   9d50 <fwp_write>
    a038:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a03d:	7f c3                	jg     a002 <fwp_write+0x2b2>
    a03f:	45 85 f6             	test   %r14d,%r14d
    a042:	0f 84 38 0a 00 00    	je     aa80 <fwp_write+0xd30>
    a048:	b8 29 00 00 00       	mov    $0x29,%eax
    a04d:	ba 01 00 00 00       	mov    $0x1,%edx
    a052:	4c 89 fe             	mov    %r15,%rsi
    a055:	48 89 df             	mov    %rbx,%rdi
    a058:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a05c:	e8 8f a0 ff ff       	call   40f0 <buf_put>
    a061:	e9 80 fd ff ff       	jmp    9de6 <fwp_write+0x96>
    a066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a06d:	00 00 00 
    a070:	ba 01 00 00 00       	mov    $0x1,%edx
    a075:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a07a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a07f:	e8 6c a0 ff ff       	call   40f0 <buf_put>
    a084:	48 85 ed             	test   %rbp,%rbp
    a087:	0f 84 93 06 00 00    	je     a720 <fwp_write+0x9d0>
    a08d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a091:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a096:	31 c9                	xor    %ecx,%ecx
    a098:	48 89 df             	mov    %rbx,%rdi
    a09b:	e8 b0 fc ff ff       	call   9d50 <fwp_write>
    a0a0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a0a4:	48 85 ed             	test   %rbp,%rbp
    a0a7:	0f 84 73 06 00 00    	je     a720 <fwp_write+0x9d0>
    a0ad:	ba 02 00 00 00       	mov    $0x2,%edx
    a0b2:	48 8d 35 e2 21 00 00 	lea    0x21e2(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a0b9:	48 89 df             	mov    %rbx,%rdi
    a0bc:	e8 2f a0 ff ff       	call   40f0 <buf_put>
    a0c1:	eb ca                	jmp    a08d <fwp_write+0x33d>
    a0c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0c8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a0cc:	85 f6                	test   %esi,%esi
    a0ce:	0f 84 fc 07 00 00    	je     a8d0 <fwp_write+0xb80>
    a0d4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a0db:	00 
    a0dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a0e3:	00 00 
    a0e5:	0f 85 3a 01 00 00    	jne    a225 <fwp_write+0x4d5>
    a0eb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a0ef:	4c 89 ea             	mov    %r13,%rdx
    a0f2:	e9 6c fe ff ff       	jmp    9f63 <fwp_write+0x213>
    a0f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0fe:	00 00 
    a100:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a105:	ba 01 00 00 00       	mov    $0x1,%edx
    a10a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a10f:	48 89 ee             	mov    %rbp,%rsi
    a112:	e8 d9 9f ff ff       	call   40f0 <buf_put>
    a117:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a11c:	4c 89 e7             	mov    %r12,%rdi
    a11f:	e8 1c 93 ff ff       	call   3440 <strlen@plt>
    a124:	4c 89 e6             	mov    %r12,%rsi
    a127:	48 89 df             	mov    %rbx,%rdi
    a12a:	48 89 c2             	mov    %rax,%rdx
    a12d:	e8 be 9f ff ff       	call   40f0 <buf_put>
    a132:	ba 01 00 00 00       	mov    $0x1,%edx
    a137:	48 89 ee             	mov    %rbp,%rsi
    a13a:	48 89 df             	mov    %rbx,%rdi
    a13d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a142:	e8 a9 9f ff ff       	call   40f0 <buf_put>
    a147:	e9 9a fc ff ff       	jmp    9de6 <fwp_write+0x96>
    a14c:	0f 1f 40 00          	nopl   0x0(%rax)
    a150:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a155:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a159:	0f 8a 8e 0b 00 00    	jp     aced <fwp_write+0xf9d>
    a15f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a163:	66 0f 54 05 55 2c 00 	andpd  0x2c55(%rip),%xmm0        # cdc0 <msg.4+0x90>
    a16a:	00 
    a16b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a170:	66 0f 2e 05 80 2c 00 	ucomisd 0x2c80(%rip),%xmm0        # cdf8 <msg.4+0xc8>
    a177:	00 
    a178:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a17f:	00 
    a180:	0f 87 b2 09 00 00    	ja     ab38 <fwp_write+0xde8>
    a186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a18d:	00 00 00 
    a190:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a194:	89 ee                	mov    %ebp,%esi
    a196:	4c 89 e7             	mov    %r12,%rdi
    a199:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a19e:	e8 cd a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a1a3:	31 f6                	xor    %esi,%esi
    a1a5:	4c 89 e7             	mov    %r12,%rdi
    a1a8:	e8 53 92 ff ff       	call   3400 <strtod@plt>
    a1ad:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a1b2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a1b6:	7a 06                	jp     a1be <fwp_write+0x46e>
    a1b8:	0f 84 e9 01 00 00    	je     a3a7 <fwp_write+0x657>
    a1be:	83 c5 01             	add    $0x1,%ebp
    a1c1:	83 fd 12             	cmp    $0x12,%ebp
    a1c4:	75 ca                	jne    a190 <fwp_write+0x440>
    a1c6:	be 11 00 00 00       	mov    $0x11,%esi
    a1cb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a1cf:	4c 89 e7             	mov    %r12,%rdi
    a1d2:	e8 99 a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a1d7:	e9 cb 01 00 00       	jmp    a3a7 <fwp_write+0x657>
    a1dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a1e0:	48 83 fd 01          	cmp    $0x1,%rbp
    a1e4:	0f 84 e6 08 00 00    	je     aad0 <fwp_write+0xd80>
    a1ea:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a1ee:	b8 02 00 00 00       	mov    $0x2,%eax
    a1f3:	ba 01 00 00 00       	mov    $0x1,%edx
    a1f8:	48 0f 44 d0          	cmove  %rax,%rdx
    a1fc:	48 8d 35 41 20 00 00 	lea    0x2041(%rip),%rsi        # c244 <_IO_stdin_used+0x244>
    a203:	48 8d 05 3f 20 00 00 	lea    0x203f(%rip),%rax        # c249 <_IO_stdin_used+0x249>
    a20a:	48 0f 44 f0          	cmove  %rax,%rsi
    a20e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a215:	00 
    a216:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a21d:	00 00 
    a21f:	0f 84 3e fd ff ff    	je     9f63 <fwp_write+0x213>
    a225:	e8 26 92 ff ff       	call   3450 <__stack_chk_fail@plt>
    a22a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a230:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a235:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a23a:	e8 f1 9d ff ff       	call   4030 <buf_grow>
    a23f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a243:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a249:	4c 03 0b             	add    (%rbx),%r9
    a24c:	66 45 89 11          	mov    %r10w,(%r9)
    a250:	45 85 e4             	test   %r12d,%r12d
    a253:	0f 8e 07 05 00 00    	jle    a760 <fwp_write+0xa10>
    a259:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a260:	55 55 55 
    a263:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a268:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a26f:	aa aa aa 
    a272:	49 83 c1 01          	add    $0x1,%r9
    a276:	eb 45                	jmp    a2bd <fwp_write+0x56d>
    a278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a27f:	00 
    a280:	be 01 00 00 00       	mov    $0x1,%esi
    a285:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a28a:	88 07                	mov    %al,(%rdi)
    a28c:	48 89 e8             	mov    %rbp,%rax
    a28f:	49 f7 e8             	imul   %r8
    a292:	48 89 e8             	mov    %rbp,%rax
    a295:	48 c1 f8 3f          	sar    $0x3f,%rax
    a299:	48 29 c2             	sub    %rax,%rdx
    a29c:	48 85 c9             	test   %rcx,%rcx
    a29f:	0f 95 c0             	setne  %al
    a2a2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a2a6:	48 83 ef 01          	sub    $0x1,%rdi
    a2aa:	48 21 c5             	and    %rax,%rbp
    a2ad:	48 29 ea             	sub    %rbp,%rdx
    a2b0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a2b4:	49 39 f9             	cmp    %rdi,%r9
    a2b7:	0f 84 a3 04 00 00    	je     a760 <fwp_write+0xa10>
    a2bd:	48 89 e8             	mov    %rbp,%rax
    a2c0:	49 f7 e8             	imul   %r8
    a2c3:	48 89 e8             	mov    %rbp,%rax
    a2c6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a2ca:	48 89 d1             	mov    %rdx,%rcx
    a2cd:	48 29 c1             	sub    %rax,%rcx
    a2d0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a2d4:	48 89 e9             	mov    %rbp,%rcx
    a2d7:	48 29 c1             	sub    %rax,%rcx
    a2da:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a2de:	49 f7 e2             	mul    %r10
    a2e1:	b8 30 00 00 00       	mov    $0x30,%eax
    a2e6:	48 89 d6             	mov    %rdx,%rsi
    a2e9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a2ed:	48 d1 ee             	shr    $1,%rsi
    a2f0:	48 01 f2             	add    %rsi,%rdx
    a2f3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a2f7:	48 29 d6             	sub    %rdx,%rsi
    a2fa:	74 8e                	je     a28a <fwp_write+0x53a>
    a2fc:	48 83 fe 01          	cmp    $0x1,%rsi
    a300:	0f 85 7a ff ff ff    	jne    a280 <fwp_write+0x530>
    a306:	31 f6                	xor    %esi,%esi
    a308:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a30d:	e9 78 ff ff ff       	jmp    a28a <fwp_write+0x53a>
    a312:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a318:	66 0f 6e cd          	movd   %ebp,%xmm1
    a31c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a31f:	0f 8a c8 09 00 00    	jp     aced <fwp_write+0xf9d>
    a325:	0f 28 c1             	movaps %xmm1,%xmm0
    a328:	0f 54 05 81 2a 00 00 	andps  0x2a81(%rip),%xmm0        # cdb0 <msg.4+0x80>
    a32f:	0f 2e 05 ce 1c 00 00 	ucomiss 0x1cce(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a336:	0f 87 24 08 00 00    	ja     ab60 <fwp_write+0xe10>
    a33c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a340:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a346:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a34d:	00 
    a34e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a352:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a35e:	00 00 
    a360:	44 89 ee             	mov    %r13d,%esi
    a363:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a368:	4c 89 e7             	mov    %r12,%rdi
    a36b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a370:	e8 fb a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a375:	31 f6                	xor    %esi,%esi
    a377:	4c 89 e7             	mov    %r12,%rdi
    a37a:	e8 21 91 ff ff       	call   34a0 <strtof@plt>
    a37f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a384:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a387:	7a 02                	jp     a38b <fwp_write+0x63b>
    a389:	74 1c                	je     a3a7 <fwp_write+0x657>
    a38b:	41 83 c5 01          	add    $0x1,%r13d
    a38f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a393:	75 cb                	jne    a360 <fwp_write+0x610>
    a395:	be 09 00 00 00       	mov    $0x9,%esi
    a39a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a39f:	4c 89 e7             	mov    %r12,%rdi
    a3a2:	e8 c9 a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a3a7:	4c 89 e7             	mov    %r12,%rdi
    a3aa:	e8 01 9e ff ff       	call   41b0 <fwp_finish_float>
    a3af:	e9 1c fa ff ff       	jmp    9dd0 <fwp_write+0x80>
    a3b4:	0f 1f 40 00          	nopl   0x0(%rax)
    a3b8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a3bc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a3c0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a3c7:	00 
    a3c8:	48 89 ef             	mov    %rbp,%rdi
    a3cb:	e8 70 96 ff ff       	call   3a40 <fwp_fmt_u128>
    a3d0:	48 89 ef             	mov    %rbp,%rdi
    a3d3:	e8 68 90 ff ff       	call   3440 <strlen@plt>
    a3d8:	48 89 ee             	mov    %rbp,%rsi
    a3db:	48 89 df             	mov    %rbx,%rdi
    a3de:	48 89 c2             	mov    %rax,%rdx
    a3e1:	e8 0a 9d ff ff       	call   40f0 <buf_put>
    a3e6:	e9 fb f9 ff ff       	jmp    9de6 <fwp_write+0x96>
    a3eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a3f0:	ba 06 00 00 00       	mov    $0x6,%edx
    a3f5:	48 8d 35 a2 1e 00 00 	lea    0x1ea2(%rip),%rsi        # c29e <_IO_stdin_used+0x29e>
    a3fc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a402:	e8 e9 9c ff ff       	call   40f0 <buf_put>
    a407:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a40e:	ff ff 7f 
    a411:	48 23 55 00          	and    0x0(%rbp),%rdx
    a415:	0f 84 86 02 00 00    	je     a6a1 <fwp_write+0x951>
    a41b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a420:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a424:	48 85 d2             	test   %rdx,%rdx
    a427:	0f 84 ae 00 00 00    	je     a4db <fwp_write+0x78b>
    a42d:	8b 0a                	mov    (%rdx),%ecx
    a42f:	83 f9 1c             	cmp    $0x1c,%ecx
    a432:	0f 84 58 06 00 00    	je     aa90 <fwp_write+0xd40>
    a438:	83 f9 1b             	cmp    $0x1b,%ecx
    a43b:	0f 87 9a 00 00 00    	ja     a4db <fwp_write+0x78b>
    a441:	be 01 00 00 00       	mov    $0x1,%esi
    a446:	48 d3 e6             	shl    %cl,%rsi
    a449:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a44f:	0f 85 4b 04 00 00    	jne    a8a0 <fwp_write+0xb50>
    a455:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a45b:	0f 85 0f 04 00 00    	jne    a870 <fwp_write+0xb20>
    a461:	83 e6 21             	and    $0x21,%esi
    a464:	74 75                	je     a4db <fwp_write+0x78b>
    a466:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a46b:	48 85 ff             	test   %rdi,%rdi
    a46e:	79 07                	jns    a477 <fwp_write+0x727>
    a470:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a474:	4c 01 ee             	add    %r13,%rsi
    a477:	48 0f be 3e          	movsbq (%rsi),%rdi
    a47b:	85 c9                	test   %ecx,%ecx
    a47d:	40 0f b6 f7          	movzbl %dil,%esi
    a481:	48 0f 44 f7          	cmove  %rdi,%rsi
    a485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a48c:	00 00 00 00 
    a490:	31 c9                	xor    %ecx,%ecx
    a492:	48 89 df             	mov    %rbx,%rdi
    a495:	49 83 c5 01          	add    $0x1,%r13
    a499:	e8 b2 f8 ff ff       	call   9d50 <fwp_write>
    a49e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a4a5:	ff ff 7f 
    a4a8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a4ac:	49 39 d5             	cmp    %rdx,%r13
    a4af:	0f 83 ec 01 00 00    	jae    a6a1 <fwp_write+0x951>
    a4b5:	ba 02 00 00 00       	mov    $0x2,%edx
    a4ba:	48 89 df             	mov    %rbx,%rdi
    a4bd:	48 8d 35 d7 1d 00 00 	lea    0x1dd7(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a4c4:	e8 27 9c ff ff       	call   40f0 <buf_put>
    a4c9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a4ce:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a4d2:	48 85 d2             	test   %rdx,%rdx
    a4d5:	0f 85 52 ff ff ff    	jne    a42d <fwp_write+0x6dd>
    a4db:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a4e0:	48 85 ff             	test   %rdi,%rdi
    a4e3:	0f 88 cf 05 00 00    	js     aab8 <fwp_write+0xd68>
    a4e9:	48 8b 31             	mov    (%rcx),%rsi
    a4ec:	eb a2                	jmp    a490 <fwp_write+0x740>
    a4ee:	66 90                	xchg   %ax,%ax
    a4f0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a4f7:	00 
    a4f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a4ff:	00 00 
    a501:	0f 85 1e fd ff ff    	jne    a225 <fwp_write+0x4d5>
    a507:	ba 08 00 00 00       	mov    $0x8,%edx
    a50c:	48 8d 35 58 1d 00 00 	lea    0x1d58(%rip),%rsi        # c26b <_IO_stdin_used+0x26b>
    a513:	e9 4b fa ff ff       	jmp    9f63 <fwp_write+0x213>
    a518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a51f:	00 
    a520:	89 e8                	mov    %ebp,%eax
    a522:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a529:	76 03                	jbe    a52e <fwp_write+0x7de>
    a52b:	8b 45 00             	mov    0x0(%rbp),%eax
    a52e:	41 89 c6             	mov    %eax,%r14d
    a531:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a536:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a53b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a53f:	4c 89 ef             	mov    %r13,%rdi
    a542:	e8 f9 8e ff ff       	call   3440 <strlen@plt>
    a547:	4c 89 ee             	mov    %r13,%rsi
    a54a:	48 89 df             	mov    %rbx,%rdi
    a54d:	48 89 c2             	mov    %rax,%rdx
    a550:	e8 9b 9b ff ff       	call   40f0 <buf_put>
    a555:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a55a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a55e:	85 f6                	test   %esi,%esi
    a560:	0f 8e 80 f8 ff ff    	jle    9de6 <fwp_write+0x96>
    a566:	45 31 ed             	xor    %r13d,%r13d
    a569:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a56e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a573:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a578:	ba 01 00 00 00       	mov    $0x1,%edx
    a57d:	4c 89 fe             	mov    %r15,%rsi
    a580:	48 89 04 24          	mov    %rax,(%rsp)
    a584:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a589:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a58d:	48 89 df             	mov    %rbx,%rdi
    a590:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a594:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a599:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a59e:	e8 4d 9b ff ff       	call   40f0 <buf_put>
    a5a3:	41 8b 06             	mov    (%r14),%eax
    a5a6:	83 f8 0e             	cmp    $0xe,%eax
    a5a9:	0f 84 71 02 00 00    	je     a820 <fwp_write+0xad0>
    a5af:	83 f8 10             	cmp    $0x10,%eax
    a5b2:	0f 84 38 02 00 00    	je     a7f0 <fwp_write+0xaa0>
    a5b8:	83 f8 0a             	cmp    $0xa,%eax
    a5bb:	0f 84 7f 04 00 00    	je     aa40 <fwp_write+0xcf0>
    a5c1:	0f 8f f9 00 00 00    	jg     a6c0 <fwp_write+0x970>
    a5c7:	83 f8 03             	cmp    $0x3,%eax
    a5ca:	0f 8f 50 04 00 00    	jg     aa20 <fwp_write+0xcd0>
    a5d0:	85 c0                	test   %eax,%eax
    a5d2:	78 10                	js     a5e4 <fwp_write+0x894>
    a5d4:	48 8b 04 24          	mov    (%rsp),%rax
    a5d8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a5dc:	85 c0                	test   %eax,%eax
    a5de:	0f 85 f9 00 00 00    	jne    a6dd <fwp_write+0x98d>
    a5e4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a5e9:	48 8b 34 24          	mov    (%rsp),%rsi
    a5ed:	31 c9                	xor    %ecx,%ecx
    a5ef:	48 89 df             	mov    %rbx,%rdi
    a5f2:	e8 59 f7 ff ff       	call   9d50 <fwp_write>
    a5f7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a5fc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a601:	49 83 c5 01          	add    $0x1,%r13
    a605:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a609:	0f 8f 5f ff ff ff    	jg     a56e <fwp_write+0x81e>
    a60f:	e9 d2 f7 ff ff       	jmp    9de6 <fwp_write+0x96>
    a614:	0f 1f 40 00          	nopl   0x0(%rax)
    a618:	ba 06 00 00 00       	mov    $0x6,%edx
    a61d:	48 8d 35 6d 1c 00 00 	lea    0x1c6d(%rip),%rsi        # c291 <_IO_stdin_used+0x291>
    a624:	45 31 ed             	xor    %r13d,%r13d
    a627:	e8 c4 9a ff ff       	call   40f0 <buf_put>
    a62c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a631:	75 19                	jne    a64c <fwp_write+0x8fc>
    a633:	eb 6c                	jmp    a6a1 <fwp_write+0x951>
    a635:	0f 1f 00             	nopl   (%rax)
    a638:	ba 02 00 00 00       	mov    $0x2,%edx
    a63d:	48 8d 35 57 1c 00 00 	lea    0x1c57(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a644:	48 89 df             	mov    %rbx,%rdi
    a647:	e8 a4 9a ff ff       	call   40f0 <buf_put>
    a64c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a652:	b9 00 02 00 00       	mov    $0x200,%ecx
    a657:	31 c0                	xor    %eax,%eax
    a659:	49 83 c5 01          	add    $0x1,%r13
    a65d:	4c 8d 05 34 1c 00 00 	lea    0x1c34(%rip),%r8        # c298 <_IO_stdin_used+0x298>
    a664:	ba 02 00 00 00       	mov    $0x2,%edx
    a669:	be 00 02 00 00       	mov    $0x200,%esi
    a66e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a675:	00 
    a676:	e8 25 8d ff ff       	call   33a0 <__snprintf_chk@plt>
    a67b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a682:	00 
    a683:	e8 b8 8d ff ff       	call   3440 <strlen@plt>
    a688:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a68f:	00 
    a690:	48 89 df             	mov    %rbx,%rdi
    a693:	48 89 c2             	mov    %rax,%rdx
    a696:	e8 55 9a ff ff       	call   40f0 <buf_put>
    a69b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a69f:	72 97                	jb     a638 <fwp_write+0x8e8>
    a6a1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6a6:	ba 01 00 00 00       	mov    $0x1,%edx
    a6ab:	48 89 df             	mov    %rbx,%rdi
    a6ae:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a6b3:	e8 38 9a ff ff       	call   40f0 <buf_put>
    a6b8:	e9 29 f7 ff ff       	jmp    9de6 <fwp_write+0x96>
    a6bd:	0f 1f 00             	nopl   (%rax)
    a6c0:	83 f8 0b             	cmp    $0xb,%eax
    a6c3:	0f 85 1b ff ff ff    	jne    a5e4 <fwp_write+0x894>
    a6c9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a6ce:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a6d2:	83 e0 01             	and    $0x1,%eax
    a6d5:	85 c0                	test   %eax,%eax
    a6d7:	0f 84 07 ff ff ff    	je     a5e4 <fwp_write+0x894>
    a6dd:	4c 89 fe             	mov    %r15,%rsi
    a6e0:	48 89 df             	mov    %rbx,%rdi
    a6e3:	ba 01 00 00 00       	mov    $0x1,%edx
    a6e8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a6ed:	e8 fe 99 ff ff       	call   40f0 <buf_put>
    a6f2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a6f7:	48 8b 34 24          	mov    (%rsp),%rsi
    a6fb:	31 c9                	xor    %ecx,%ecx
    a6fd:	48 89 df             	mov    %rbx,%rdi
    a700:	e8 4b f6 ff ff       	call   9d50 <fwp_write>
    a705:	ba 01 00 00 00       	mov    $0x1,%edx
    a70a:	4c 89 fe             	mov    %r15,%rsi
    a70d:	48 89 df             	mov    %rbx,%rdi
    a710:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a715:	e8 d6 99 ff ff       	call   40f0 <buf_put>
    a71a:	e9 d8 fe ff ff       	jmp    a5f7 <fwp_write+0x8a7>
    a71f:	90                   	nop
    a720:	ba 01 00 00 00       	mov    $0x1,%edx
    a725:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a72a:	48 89 df             	mov    %rbx,%rdi
    a72d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a732:	e8 b9 99 ff ff       	call   40f0 <buf_put>
    a737:	e9 aa f6 ff ff       	jmp    9de6 <fwp_write+0x96>
    a73c:	0f 1f 40 00          	nopl   0x0(%rax)
    a740:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a745:	ba 01 00 00 00       	mov    $0x1,%edx
    a74a:	48 89 df             	mov    %rbx,%rdi
    a74d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a752:	e8 99 99 ff ff       	call   40f0 <buf_put>
    a757:	e9 8a f6 ff ff       	jmp    9de6 <fwp_write+0x96>
    a75c:	0f 1f 40 00          	nopl   0x0(%rax)
    a760:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a764:	48 8b 13             	mov    (%rbx),%rdx
    a767:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a76c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a770:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a774:	e9 6d f6 ff ff       	jmp    9de6 <fwp_write+0x96>
    a779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a780:	ba 02 00 00 00       	mov    $0x2,%edx
    a785:	48 8d 35 0f 1b 00 00 	lea    0x1b0f(%rip),%rsi        # c29b <_IO_stdin_used+0x29b>
    a78c:	48 89 df             	mov    %rbx,%rdi
    a78f:	e8 5c 99 ff ff       	call   40f0 <buf_put>
    a794:	e9 72 f8 ff ff       	jmp    a00b <fwp_write+0x2bb>
    a799:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a7a0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a7a5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a7aa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a7ae:	48 89 f7             	mov    %rsi,%rdi
    a7b1:	48 89 34 24          	mov    %rsi,(%rsp)
    a7b5:	e8 86 8c ff ff       	call   3440 <strlen@plt>
    a7ba:	48 8b 34 24          	mov    (%rsp),%rsi
    a7be:	48 89 df             	mov    %rbx,%rdi
    a7c1:	48 89 c2             	mov    %rax,%rdx
    a7c4:	e8 27 99 ff ff       	call   40f0 <buf_put>
    a7c9:	ba 03 00 00 00       	mov    $0x3,%edx
    a7ce:	48 8d 35 e9 1a 00 00 	lea    0x1ae9(%rip),%rsi        # c2be <_IO_stdin_used+0x2be>
    a7d5:	48 89 df             	mov    %rbx,%rdi
    a7d8:	e8 13 99 ff ff       	call   40f0 <buf_put>
    a7dd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a7e2:	e9 35 f8 ff ff       	jmp    a01c <fwp_write+0x2cc>
    a7e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7ee:	00 00 
    a7f0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a7f5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a7f9:	48 85 ff             	test   %rdi,%rdi
    a7fc:	0f 84 e2 fd ff ff    	je     a5e4 <fwp_write+0x894>
    a802:	48 8d 35 9f 1a 00 00 	lea    0x1a9f(%rip),%rsi        # c2a8 <_IO_stdin_used+0x2a8>
    a809:	e8 12 8d ff ff       	call   3520 <strcmp@plt>
    a80e:	85 c0                	test   %eax,%eax
    a810:	0f 95 c0             	setne  %al
    a813:	0f b6 c0             	movzbl %al,%eax
    a816:	e9 c1 fd ff ff       	jmp    a5dc <fwp_write+0x88c>
    a81b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a820:	31 c0                	xor    %eax,%eax
    a822:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a829:	00 
    a82a:	0f 97 c0             	seta   %al
    a82d:	e9 aa fd ff ff       	jmp    a5dc <fwp_write+0x88c>
    a832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a838:	48 89 df             	mov    %rbx,%rdi
    a83b:	ba 02 00 00 00       	mov    $0x2,%edx
    a840:	48 8d 35 5e 1a 00 00 	lea    0x1a5e(%rip),%rsi        # c2a5 <_IO_stdin_used+0x2a5>
    a847:	e8 a4 98 ff ff       	call   40f0 <buf_put>
    a84c:	4c 89 e8             	mov    %r13,%rax
    a84f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a854:	31 c9                	xor    %ecx,%ecx
    a856:	48 c1 e0 04          	shl    $0x4,%rax
    a85a:	48 89 df             	mov    %rbx,%rdi
    a85d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a862:	e8 e9 f4 ff ff       	call   9d50 <fwp_write>
    a867:	e9 5e f6 ff ff       	jmp    9eca <fwp_write+0x17a>
    a86c:	0f 1f 40 00          	nopl   0x0(%rax)
    a870:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a875:	48 85 ff             	test   %rdi,%rdi
    a878:	79 0c                	jns    a886 <fwp_write+0xb36>
    a87a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a881:	00 
    a882:	48 03 75 10          	add    0x10(%rbp),%rsi
    a886:	48 63 3e             	movslq (%rsi),%rdi
    a889:	83 f9 02             	cmp    $0x2,%ecx
    a88c:	89 fe                	mov    %edi,%esi
    a88e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a892:	e9 f9 fb ff ff       	jmp    a490 <fwp_write+0x740>
    a897:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a89e:	00 00 
    a8a0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a8a5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a8aa:	48 85 ff             	test   %rdi,%rdi
    a8ad:	0f 88 0f 03 00 00    	js     abc2 <fwp_write+0xe72>
    a8b3:	49 0f bf 38          	movswq (%r8),%rdi
    a8b7:	83 f9 01             	cmp    $0x1,%ecx
    a8ba:	0f b7 f7             	movzwl %di,%esi
    a8bd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a8c1:	e9 ca fb ff ff       	jmp    a490 <fwp_write+0x740>
    a8c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8cd:	00 00 00 
    a8d0:	ba 01 00 00 00       	mov    $0x1,%edx
    a8d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a8da:	48 83 c5 08          	add    $0x8,%rbp
    a8de:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a8e3:	e8 08 98 ff ff       	call   40f0 <buf_put>
    a8e8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a8ed:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a8f2:	4d 85 ed             	test   %r13,%r13
    a8f5:	75 46                	jne    a93d <fwp_write+0xbed>
    a8f7:	e9 04 01 00 00       	jmp    aa00 <fwp_write+0xcb0>
    a8fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a900:	41 80 f9 09          	cmp    $0x9,%r9b
    a904:	0f 84 d6 00 00 00    	je     a9e0 <fwp_write+0xc90>
    a90a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a90e:	0f 85 9c 00 00 00    	jne    a9b0 <fwp_write+0xc60>
    a914:	ba 02 00 00 00       	mov    $0x2,%edx
    a919:	48 8d 35 61 19 00 00 	lea    0x1961(%rip),%rsi        # c281 <_IO_stdin_used+0x281>
    a920:	48 89 df             	mov    %rbx,%rdi
    a923:	e8 c8 97 ff ff       	call   40f0 <buf_put>
    a928:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a92f:	00 
    a930:	48 83 c5 01          	add    $0x1,%rbp
    a934:	49 39 ec             	cmp    %rbp,%r12
    a937:	0f 84 c3 00 00 00    	je     aa00 <fwp_write+0xcb0>
    a93d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a942:	41 80 f9 0d          	cmp    $0xd,%r9b
    a946:	74 28                	je     a970 <fwp_write+0xc20>
    a948:	7e b6                	jle    a900 <fwp_write+0xbb0>
    a94a:	41 80 f9 22          	cmp    $0x22,%r9b
    a94e:	74 40                	je     a990 <fwp_write+0xc40>
    a950:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a954:	75 5a                	jne    a9b0 <fwp_write+0xc60>
    a956:	ba 02 00 00 00       	mov    $0x2,%edx
    a95b:	48 8d 35 1c 19 00 00 	lea    0x191c(%rip),%rsi        # c27e <_IO_stdin_used+0x27e>
    a962:	48 89 df             	mov    %rbx,%rdi
    a965:	e8 86 97 ff ff       	call   40f0 <buf_put>
    a96a:	eb c4                	jmp    a930 <fwp_write+0xbe0>
    a96c:	0f 1f 40 00          	nopl   0x0(%rax)
    a970:	ba 02 00 00 00       	mov    $0x2,%edx
    a975:	48 8d 35 0b 19 00 00 	lea    0x190b(%rip),%rsi        # c287 <_IO_stdin_used+0x287>
    a97c:	48 89 df             	mov    %rbx,%rdi
    a97f:	e8 6c 97 ff ff       	call   40f0 <buf_put>
    a984:	eb aa                	jmp    a930 <fwp_write+0xbe0>
    a986:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a98d:	00 00 00 
    a990:	ba 02 00 00 00       	mov    $0x2,%edx
    a995:	48 8d 35 df 18 00 00 	lea    0x18df(%rip),%rsi        # c27b <_IO_stdin_used+0x27b>
    a99c:	48 89 df             	mov    %rbx,%rdi
    a99f:	e8 4c 97 ff ff       	call   40f0 <buf_put>
    a9a4:	eb 8a                	jmp    a930 <fwp_write+0xbe0>
    a9a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9ad:	00 00 00 
    a9b0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a9b4:	0f 86 2e 01 00 00    	jbe    aae8 <fwp_write+0xd98>
    a9ba:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a9be:	0f 84 24 01 00 00    	je     aae8 <fwp_write+0xd98>
    a9c4:	ba 01 00 00 00       	mov    $0x1,%edx
    a9c9:	4c 89 fe             	mov    %r15,%rsi
    a9cc:	48 89 df             	mov    %rbx,%rdi
    a9cf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a9d4:	e8 17 97 ff ff       	call   40f0 <buf_put>
    a9d9:	e9 52 ff ff ff       	jmp    a930 <fwp_write+0xbe0>
    a9de:	66 90                	xchg   %ax,%ax
    a9e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a9e5:	48 8d 35 98 18 00 00 	lea    0x1898(%rip),%rsi        # c284 <_IO_stdin_used+0x284>
    a9ec:	48 89 df             	mov    %rbx,%rdi
    a9ef:	e8 fc 96 ff ff       	call   40f0 <buf_put>
    a9f4:	e9 37 ff ff ff       	jmp    a930 <fwp_write+0xbe0>
    a9f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa00:	ba 01 00 00 00       	mov    $0x1,%edx
    aa05:	4c 89 fe             	mov    %r15,%rsi
    aa08:	48 89 df             	mov    %rbx,%rdi
    aa0b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aa10:	e8 db 96 ff ff       	call   40f0 <buf_put>
    aa15:	e9 cc f3 ff ff       	jmp    9de6 <fwp_write+0x96>
    aa1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa20:	83 f8 04             	cmp    $0x4,%eax
    aa23:	0f 85 bb fb ff ff    	jne    a5e4 <fwp_write+0x894>
    aa29:	48 8b 04 24          	mov    (%rsp),%rax
    aa2d:	48 8b 40 08          	mov    0x8(%rax),%rax
    aa31:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    aa36:	48 c1 e8 3f          	shr    $0x3f,%rax
    aa3a:	e9 96 fc ff ff       	jmp    a6d5 <fwp_write+0x985>
    aa3f:	90                   	nop
    aa40:	8b 0c 24             	mov    (%rsp),%ecx
    aa43:	31 c0                	xor    %eax,%eax
    aa45:	85 c9                	test   %ecx,%ecx
    aa47:	0f 98 c0             	sets   %al
    aa4a:	e9 86 fc ff ff       	jmp    a6d5 <fwp_write+0x985>
    aa4f:	90                   	nop
    aa50:	48 f7 d8             	neg    %rax
    aa53:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    aa5a:	00 
    aa5b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    aa62:	2d 
    aa63:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa6a:	00 
    aa6b:	48 83 d2 00          	adc    $0x0,%rdx
    aa6f:	48 89 c6             	mov    %rax,%rsi
    aa72:	48 f7 da             	neg    %rdx
    aa75:	e8 c6 8f ff ff       	call   3a40 <fwp_fmt_u128>
    aa7a:	e9 51 f3 ff ff       	jmp    9dd0 <fwp_write+0x80>
    aa7f:	90                   	nop
    aa80:	b8 7d 00 00 00       	mov    $0x7d,%eax
    aa85:	e9 c3 f5 ff ff       	jmp    a04d <fwp_write+0x2fd>
    aa8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa90:	4c 89 e9             	mov    %r13,%rcx
    aa93:	48 c1 e1 04          	shl    $0x4,%rcx
    aa97:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    aa9c:	48 85 ff             	test   %rdi,%rdi
    aa9f:	0f 89 eb f9 ff ff    	jns    a490 <fwp_write+0x740>
    aaa5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aaa9:	48 89 ce             	mov    %rcx,%rsi
    aaac:	e9 df f9 ff ff       	jmp    a490 <fwp_write+0x740>
    aab1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aab8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aabf:	00 
    aac0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aac4:	e9 20 fa ff ff       	jmp    a4e9 <fwp_write+0x799>
    aac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aad0:	ba 02 00 00 00       	mov    $0x2,%edx
    aad5:	48 8d 35 6a 17 00 00 	lea    0x176a(%rip),%rsi        # c246 <_IO_stdin_used+0x246>
    aadc:	e9 2d f7 ff ff       	jmp    a20e <fwp_write+0x4be>
    aae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aae8:	4c 8d 05 9b 17 00 00 	lea    0x179b(%rip),%r8        # c28a <_IO_stdin_used+0x28a>
    aaef:	b9 10 00 00 00       	mov    $0x10,%ecx
    aaf4:	31 c0                	xor    %eax,%eax
    aaf6:	ba 02 00 00 00       	mov    $0x2,%edx
    aafb:	be 10 00 00 00       	mov    $0x10,%esi
    ab00:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab07:	00 
    ab08:	e8 93 88 ff ff       	call   33a0 <__snprintf_chk@plt>
    ab0d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab14:	00 
    ab15:	e8 26 89 ff ff       	call   3440 <strlen@plt>
    ab1a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ab21:	00 
    ab22:	48 89 df             	mov    %rbx,%rdi
    ab25:	48 89 c2             	mov    %rax,%rdx
    ab28:	e8 c3 95 ff ff       	call   40f0 <buf_put>
    ab2d:	e9 fe fd ff ff       	jmp    a930 <fwp_write+0xbe0>
    ab32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab3c:	48 8d 35 fd 16 00 00 	lea    0x16fd(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    ab43:	48 8d 05 f5 16 00 00 	lea    0x16f5(%rip),%rax        # c23f <_IO_stdin_used+0x23f>
    ab4a:	4c 89 e7             	mov    %r12,%rdi
    ab4d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    ab51:	48 0f 46 f0          	cmovbe %rax,%rsi
    ab55:	e8 86 88 ff ff       	call   33e0 <strcpy@plt>
    ab5a:	e9 71 f2 ff ff       	jmp    9dd0 <fwp_write+0x80>
    ab5f:	90                   	nop
    ab60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab64:	48 8d 35 d5 16 00 00 	lea    0x16d5(%rip),%rsi        # c240 <_IO_stdin_used+0x240>
    ab6b:	48 8d 05 cd 16 00 00 	lea    0x16cd(%rip),%rax        # c23f <_IO_stdin_used+0x23f>
    ab72:	0f 2f c8             	comiss %xmm0,%xmm1
    ab75:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab7c:	00 
    ab7d:	4c 89 e7             	mov    %r12,%rdi
    ab80:	48 0f 46 f0          	cmovbe %rax,%rsi
    ab84:	e8 57 88 ff ff       	call   33e0 <strcpy@plt>
    ab89:	e9 42 f2 ff ff       	jmp    9dd0 <fwp_write+0x80>
    ab8e:	66 90                	xchg   %ax,%ax
    ab90:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ab95:	45 85 c0             	test   %r8d,%r8d
    ab98:	75 34                	jne    abce <fwp_write+0xe7e>
    ab9a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aba1:	00 
    aba2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aba9:	00 00 
    abab:	0f 85 74 f6 ff ff    	jne    a225 <fwp_write+0x4d5>
    abb1:	ba 02 00 00 00       	mov    $0x2,%edx
    abb6:	48 8d 35 fe 16 00 00 	lea    0x16fe(%rip),%rsi        # c2bb <_IO_stdin_used+0x2bb>
    abbd:	e9 a1 f3 ff ff       	jmp    9f63 <fwp_write+0x213>
    abc2:	48 03 75 10          	add    0x10(%rbp),%rsi
    abc6:	49 89 f0             	mov    %rsi,%r8
    abc9:	e9 e5 fc ff ff       	jmp    a8b3 <fwp_write+0xb63>
    abce:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    abd3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    abd8:	85 ff                	test   %edi,%edi
    abda:	0f 84 fa f3 ff ff    	je     9fda <fwp_write+0x28a>
    abe0:	ba 01 00 00 00       	mov    $0x1,%edx
    abe5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    abea:	48 89 df             	mov    %rbx,%rdi
    abed:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    abf2:	e8 f9 94 ff ff       	call   40f0 <buf_put>
    abf7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    abfc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ac01:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ac07:	85 c0                	test   %eax,%eax
    ac09:	0f 8f f0 f3 ff ff    	jg     9fff <fwp_write+0x2af>
    ac0f:	e9 34 f4 ff ff       	jmp    a048 <fwp_write+0x2f8>
    ac14:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ac18:	49 89 c5             	mov    %rax,%r13
    ac1b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ac20:	49 89 c4             	mov    %rax,%r12
    ac23:	49 c1 fd 3f          	sar    $0x3f,%r13
    ac27:	4c 09 e8             	or     %r13,%rax
    ac2a:	0f 84 a7 00 00 00    	je     acd7 <fwp_write+0xf87>
    ac30:	48 8d 2d e9 37 00 00 	lea    0x37e9(%rip),%rbp        # e420 <units.1>
    ac37:	4d 89 e7             	mov    %r12,%r15
    ac3a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ac3e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ac43:	4c 89 ff             	mov    %r15,%rdi
    ac46:	4c 89 ee             	mov    %r13,%rsi
    ac49:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac4d:	48 99                	cqto
    ac4f:	48 89 d1             	mov    %rdx,%rcx
    ac52:	48 89 c2             	mov    %rax,%rdx
    ac55:	e8 06 10 00 00       	call   bc60 <__divmodti4>
    ac5a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac5e:	48 89 c1             	mov    %rax,%rcx
    ac61:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ac66:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ac6b:	0f 84 94 00 00 00    	je     ad05 <fwp_write+0xfb5>
    ac71:	41 83 c1 01          	add    $0x1,%r9d
    ac75:	48 83 c5 10          	add    $0x10,%rbp
    ac79:	41 83 f9 05          	cmp    $0x5,%r9d
    ac7d:	75 bb                	jne    ac3a <fwp_write+0xeea>
    ac7f:	4d 85 ed             	test   %r13,%r13
    ac82:	79 53                	jns    acd7 <fwp_write+0xf87>
    ac84:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ac89:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ac8e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ac93:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac98:	48 99                	cqto
    ac9a:	48 f7 d8             	neg    %rax
    ac9d:	48 83 d2 00          	adc    $0x0,%rdx
    aca1:	48 89 c6             	mov    %rax,%rsi
    aca4:	48 f7 da             	neg    %rdx
    aca7:	e8 94 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acac:	49 89 e8             	mov    %rbp,%r8
    acaf:	ba 00 02 00 00       	mov    $0x200,%edx
    acb4:	be 02 00 00 00       	mov    $0x2,%esi
    acb9:	31 c0                	xor    %eax,%eax
    acbb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acc2:	00 
    acc3:	48 8d 0d ec 15 00 00 	lea    0x15ec(%rip),%rcx        # c2b6 <_IO_stdin_used+0x2b6>
    acca:	4c 89 e7             	mov    %r12,%rdi
    accd:	e8 ee 89 ff ff       	call   36c0 <__sprintf_chk@plt>
    acd2:	e9 f9 f0 ff ff       	jmp    9dd0 <fwp_write+0x80>
    acd7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    acdc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ace1:	31 d2                	xor    %edx,%edx
    ace3:	48 89 ef             	mov    %rbp,%rdi
    ace6:	e8 55 8d ff ff       	call   3a40 <fwp_fmt_u128>
    aceb:	eb bf                	jmp    acac <fwp_write+0xf5c>
    aced:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    acf4:	4e 61 4e 00 
    acf8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acff:	00 
    ad00:	e9 cb f0 ff ff       	jmp    9dd0 <fwp_write+0x80>
    ad05:	44 89 0c 24          	mov    %r9d,(%rsp)
    ad09:	48 89 c8             	mov    %rcx,%rax
    ad0c:	48 85 d2             	test   %rdx,%rdx
    ad0f:	78 51                	js     ad62 <fwp_write+0x1012>
    ad11:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad16:	48 89 c6             	mov    %rax,%rsi
    ad19:	48 89 ef             	mov    %rbp,%rdi
    ad1c:	e8 1f 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ad21:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad25:	49 63 c1             	movslq %r9d,%rax
    ad28:	49 89 e8             	mov    %rbp,%r8
    ad2b:	ba 00 02 00 00       	mov    $0x200,%edx
    ad30:	be 02 00 00 00       	mov    $0x2,%esi
    ad35:	48 c1 e0 04          	shl    $0x4,%rax
    ad39:	48 8d 3d e0 36 00 00 	lea    0x36e0(%rip),%rdi        # e420 <units.1>
    ad40:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad47:	00 
    ad48:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ad4c:	48 8d 0d 5e 15 00 00 	lea    0x155e(%rip),%rcx        # c2b1 <_IO_stdin_used+0x2b1>
    ad53:	4c 89 e7             	mov    %r12,%rdi
    ad56:	31 c0                	xor    %eax,%eax
    ad58:	e8 63 89 ff ff       	call   36c0 <__sprintf_chk@plt>
    ad5d:	e9 6e f0 ff ff       	jmp    9dd0 <fwp_write+0x80>
    ad62:	48 f7 d8             	neg    %rax
    ad65:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ad6a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ad6f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad74:	48 83 d2 00          	adc    $0x0,%rdx
    ad78:	48 89 c6             	mov    %rax,%rsi
    ad7b:	48 f7 da             	neg    %rdx
    ad7e:	e8 bd 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ad83:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad87:	eb 9c                	jmp    ad25 <fwp_write+0xfd5>
    ad89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ad90 <fwp_main_thread>:
    ad90:	f3 0f 1e fa          	endbr64
    ad94:	41 57                	push   %r15
    ad96:	41 56                	push   %r14
    ad98:	41 55                	push   %r13
    ad9a:	41 54                	push   %r12
    ad9c:	55                   	push   %rbp
    ad9d:	53                   	push   %rbx
    ad9e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    ada5:	8b 3d 19 ee 05 00    	mov    0x5ee19(%rip),%edi        # 69bc4 <fwp_heap+0x13a4>
    adab:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    adb2:	00 00 
    adb4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    adbb:	00 
    adbc:	31 c0                	xor    %eax,%eax
    adbe:	85 ff                	test   %edi,%edi
    adc0:	0f 84 1a 07 00 00    	je     b4e0 <fwp_main_thread+0x750>
    adc6:	8b 35 fc ed 05 00    	mov    0x5edfc(%rip),%esi        # 69bc8 <fwp_heap+0x13a8>
    adcc:	85 f6                	test   %esi,%esi
    adce:	0f 85 1f 07 00 00    	jne    b4f3 <fwp_main_thread+0x763>
    add4:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    add9:	48 8d 5c 24 20       	lea    0x20(%rsp),%rbx
    adde:	31 f6                	xor    %esi,%esi
    ade0:	48 c7 05 d5 d3 05 00 	movq   $0x40000000,0x5d3d5(%rip)        # 681c0 <fwp_main_stack_size>
    ade7:	00 00 00 40 
    adeb:	48 8d 05 8e 52 00 00 	lea    0x528e(%rip),%rax        # 10080 <alt.5>
    adf2:	48 89 ef             	mov    %rbp,%rdi
    adf5:	48 89 1d cc d3 05 00 	mov    %rbx,0x5d3cc(%rip)        # 681c8 <fwp_main_stack_top>
    adfc:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    ae01:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    ae08:	01 00 
    ae0a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    ae11:	00 
    ae12:	e8 89 88 ff ff       	call   36a0 <sigaltstack@plt>
    ae17:	85 c0                	test   %eax,%eax
    ae19:	0f 85 fc 0d 00 00    	jne    bc1b <fwp_main_thread+0xe8b>
    ae1f:	31 c0                	xor    %eax,%eax
    ae21:	b9 12 00 00 00       	mov    $0x12,%ecx
    ae26:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ae2d:	00 
    ae2e:	f3 48 ab             	rep stos %rax,(%rdi)
    ae31:	48 8d 05 08 8f ff ff 	lea    -0x70f8(%rip),%rax        # 3d40 <fwp_segv>
    ae38:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    ae3f:	00 
    ae40:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    ae47:	04 00 00 08 
    ae4b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ae52:	00 
    ae53:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
    ae5a:	00 
    ae5b:	e8 00 87 ff ff       	call   3560 <sigemptyset@plt>
    ae60:	85 c0                	test   %eax,%eax
    ae62:	0f 85 b3 0d 00 00    	jne    bc1b <fwp_main_thread+0xe8b>
    ae68:	31 d2                	xor    %edx,%edx
    ae6a:	4c 89 ee             	mov    %r13,%rsi
    ae6d:	bf 0b 00 00 00       	mov    $0xb,%edi
    ae72:	e8 79 85 ff ff       	call   33f0 <sigaction@plt>
    ae77:	85 c0                	test   %eax,%eax
    ae79:	0f 85 9c 0d 00 00    	jne    bc1b <fwp_main_thread+0xe8b>
    ae7f:	31 d2                	xor    %edx,%edx
    ae81:	4c 89 ee             	mov    %r13,%rsi
    ae84:	bf 07 00 00 00       	mov    $0x7,%edi
    ae89:	e8 62 85 ff ff       	call   33f0 <sigaction@plt>
    ae8e:	85 c0                	test   %eax,%eax
    ae90:	0f 85 85 0d 00 00    	jne    bc1b <fwp_main_thread+0xe8b>
    ae96:	48 8b 05 a3 ed 05 00 	mov    0x5eda3(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    ae9d:	48 85 c0             	test   %rax,%rax
    aea0:	0f 88 1a 06 00 00    	js     b4c0 <fwp_main_thread+0x730>
    aea6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aeaa:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    aeaf:	48 8d 3d 6a 93 ff ff 	lea    -0x6c96(%rip),%rdi        # 4220 <ad_raw_report>
    aeb6:	f2 0f 11 05 0a f6 05 	movsd  %xmm0,0x5f60a(%rip)        # 6a4c8 <iteration_start_charge>
    aebd:	00 
    aebe:	c7 05 20 f6 05 00 01 	movl   $0x1,0x5f620(%rip)        # 6a4e8 <iteration_active>
    aec5:	00 00 00 
    aec8:	e8 a3 0f 00 00       	call   be70 <atexit>
    aecd:	85 c0                	test   %eax,%eax
    aecf:	0f 85 52 0d 00 00    	jne    bc27 <fwp_main_thread+0xe97>
    aed5:	8b 0d 95 51 00 00    	mov    0x5195(%rip),%ecx        # 10070 <st.3>
    aedb:	85 c9                	test   %ecx,%ecx
    aedd:	0f 84 25 06 00 00    	je     b508 <fwp_main_thread+0x778>
    aee3:	48 8b 2d 16 d9 05 00 	mov    0x5d916(%rip),%rbp        # 68800 <fwp_cur>
    aeea:	48 85 ed             	test   %rbp,%rbp
    aeed:	0f 84 bd 01 00 00    	je     b0b0 <fwp_main_thread+0x320>
    aef3:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    aef8:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    aefc:	48 89 eb             	mov    %rbp,%rbx
    aeff:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    af04:	0f 84 41 01 00 00    	je     b04b <fwp_main_thread+0x2bb>
    af0a:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    af0f:	0f 84 9b 02 00 00    	je     b1b0 <fwp_main_thread+0x420>
    af15:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    af19:	0f 84 71 02 00 00    	je     b190 <fwp_main_thread+0x400>
    af1f:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    af23:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    af27:	0f 85 03 03 00 00    	jne    b230 <fwp_main_thread+0x4a0>
    af2d:	48 8b 43 60          	mov    0x60(%rbx),%rax
    af31:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    af38:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    af3c:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    af43:	00 00 00 00 
    af47:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    af4e:	48 85 d2             	test   %rdx,%rdx
    af51:	74 07                	je     af5a <fwp_main_thread+0x1ca>
    af53:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    af5a:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    af5e:	48 85 c0             	test   %rax,%rax
    af61:	74 34                	je     af97 <fwp_main_thread+0x207>
    af63:	48 89 43 68          	mov    %rax,0x68(%rbx)
    af67:	48 8b 05 6a d8 05 00 	mov    0x5d86a(%rip),%rax        # 687d8 <fwp_timers>
    af6e:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    af72:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    af79:	00 00 00 00 
    af7d:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    af84:	48 85 c0             	test   %rax,%rax
    af87:	74 07                	je     af90 <fwp_main_thread+0x200>
    af89:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    af90:	48 89 1d 41 d8 05 00 	mov    %rbx,0x5d841(%rip)        # 687d8 <fwp_timers>
    af97:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    af9b:	e8 30 c9 ff ff       	call   78d0 <fwp_block>
    afa0:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    afa7:	48 85 c9             	test   %rcx,%rcx
    afaa:	74 47                	je     aff3 <fwp_main_thread+0x263>
    afac:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    afb3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    afba:	48 85 d2             	test   %rdx,%rdx
    afbd:	0f 84 ad 02 00 00    	je     b270 <fwp_main_thread+0x4e0>
    afc3:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    afca:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    afd1:	48 85 c0             	test   %rax,%rax
    afd4:	74 07                	je     afdd <fwp_main_thread+0x24d>
    afd6:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    afdd:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    afe4:	00 00 00 00 
    afe8:	66 0f ef d2          	pxor   %xmm2,%xmm2
    afec:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    aff3:	48 8b 0d 06 d8 05 00 	mov    0x5d806(%rip),%rcx        # 68800 <fwp_cur>
    affa:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    affe:	0f 84 1c 02 00 00    	je     b220 <fwp_main_thread+0x490>
    b004:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b00b:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b012:	48 85 d2             	test   %rdx,%rdx
    b015:	0f 84 95 04 00 00    	je     b4b0 <fwp_main_thread+0x720>
    b01b:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b022:	48 85 c0             	test   %rax,%rax
    b025:	74 07                	je     b02e <fwp_main_thread+0x29e>
    b027:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b02e:	66 0f ef db          	pxor   %xmm3,%xmm3
    b032:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b036:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b03d:	48 89 cb             	mov    %rcx,%rbx
    b040:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b045:	0f 85 bf fe ff ff    	jne    af0a <fwp_main_thread+0x17a>
    b04b:	48 83 3d 45 f4 05 00 	cmpq   $0x0,0x5f445(%rip)        # 6a498 <fwp_state_len>
    b052:	00 
    b053:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    b057:	74 67                	je     b0c0 <fwp_main_thread+0x330>
    b059:	48 39 1d 98 d7 05 00 	cmp    %rbx,0x5d798(%rip)        # 687f8 <fwp_root>
    b060:	c7 05 16 50 01 00 00 	movl   $0x0,0x15016(%rip)        # 20080 <fwp_exit_code>
    b067:	00 00 00 
    b06a:	0f 85 e5 0b 00 00    	jne    bc55 <fwp_main_thread+0xec5>
    b070:	48 85 db             	test   %rbx,%rbx
    b073:	0f 84 1f 02 00 00    	je     b298 <fwp_main_thread+0x508>
    b079:	48 8b 15 48 d7 05 00 	mov    0x5d748(%rip),%rdx        # 687c8 <fwp_tasks_active>
    b080:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b084:	48 85 d2             	test   %rdx,%rdx
    b087:	0f 84 0b 02 00 00    	je     b298 <fwp_main_thread+0x508>
    b08d:	0f 1f 00             	nopl   (%rax)
    b090:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b094:	75 08                	jne    b09e <fwp_main_thread+0x30e>
    b096:	48 89 d7             	mov    %rdx,%rdi
    b099:	e8 92 90 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b09e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b0a5:	48 85 d2             	test   %rdx,%rdx
    b0a8:	75 e6                	jne    b090 <fwp_main_thread+0x300>
    b0aa:	e9 ae 00 00 00       	jmp    b15d <fwp_main_thread+0x3cd>
    b0af:	90                   	nop
    b0b0:	48 83 3d e0 f3 05 00 	cmpq   $0x0,0x5f3e0(%rip)        # 6a498 <fwp_state_len>
    b0b7:	00 
    b0b8:	0f 85 c2 01 00 00    	jne    b280 <fwp_main_thread+0x4f0>
    b0be:	31 db                	xor    %ebx,%ebx
    b0c0:	48 83 3d c0 f3 05 00 	cmpq   $0x0,0x5f3c0(%rip)        # 6a488 <fwp_state_owners>
    b0c7:	00 
    b0c8:	75 8f                	jne    b059 <fwp_main_thread+0x2c9>
    b0ca:	48 8b 3d cf f3 05 00 	mov    0x5f3cf(%rip),%rdi        # 6a4a0 <fwp_state>
    b0d1:	e8 3a a9 ff ff       	call   5a10 <fwp_mem_free>
    b0d6:	48 c7 05 bf f3 05 00 	movq   $0x0,0x5f3bf(%rip)        # 6a4a0 <fwp_state>
    b0dd:	00 00 00 00 
    b0e1:	48 c7 05 a4 f3 05 00 	movq   $0x0,0x5f3a4(%rip)        # 6a490 <fwp_state_cap>
    b0e8:	00 00 00 00 
    b0ec:	48 85 db             	test   %rbx,%rbx
    b0ef:	0f 84 2d 0a 00 00    	je     bb22 <fwp_main_thread+0xd92>
    b0f5:	48 39 1d fc d6 05 00 	cmp    %rbx,0x5d6fc(%rip)        # 687f8 <fwp_root>
    b0fc:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b103:	00 00 00 00 
    b107:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b10e:	00 00 00 00 
    b112:	c7 05 64 4f 01 00 00 	movl   $0x0,0x14f64(%rip)        # 20080 <fwp_exit_code>
    b119:	00 00 00 
    b11c:	0f 84 57 ff ff ff    	je     b079 <fwp_main_thread+0x2e9>
    b122:	e9 29 86 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b12e:	00 00 
    b130:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b137:	48 89 1d a2 d6 05 00 	mov    %rbx,0x5d6a2(%rip)        # 687e0 <fwp_ready_tail>
    b13e:	e8 8d c7 ff ff       	call   78d0 <fwp_block>
    b143:	e8 88 c5 ff ff       	call   76d0 <fwp_free_zombie>
    b148:	48 83 3d 78 d6 05 00 	cmpq   $0x0,0x5d678(%rip)        # 687c8 <fwp_tasks_active>
    b14f:	00 
    b150:	0f 84 42 01 00 00    	je     b298 <fwp_main_thread+0x508>
    b156:	48 8b 1d 9b d6 05 00 	mov    0x5d69b(%rip),%rbx        # 687f8 <fwp_root>
    b15d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b161:	75 db                	jne    b13e <fwp_main_thread+0x3ae>
    b163:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b167:	75 d5                	jne    b13e <fwp_main_thread+0x3ae>
    b169:	48 8b 05 70 d6 05 00 	mov    0x5d670(%rip),%rax        # 687e0 <fwp_ready_tail>
    b170:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b174:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b17b:	00 00 00 00 
    b17f:	48 85 c0             	test   %rax,%rax
    b182:	75 ac                	jne    b130 <fwp_main_thread+0x3a0>
    b184:	48 89 1d 5d d6 05 00 	mov    %rbx,0x5d65d(%rip)        # 687e8 <fwp_ready_head>
    b18b:	eb aa                	jmp    b137 <fwp_main_thread+0x3a7>
    b18d:	0f 1f 00             	nopl   (%rax)
    b190:	e8 2b 94 ff ff       	call   45c0 <fwp_now_ns>
    b195:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b199:	7c 15                	jl     b1b0 <fwp_main_thread+0x420>
    b19b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b19f:	75 0f                	jne    b1b0 <fwp_main_thread+0x420>
    b1a1:	48 89 ef             	mov    %rbp,%rdi
    b1a4:	e8 87 8f ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b1a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1b0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b1b4:	0f 85 65 fd ff ff    	jne    af1f <fwp_main_thread+0x18f>
    b1ba:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b1be:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b1c2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b1c6:	0f 85 65 fd ff ff    	jne    af31 <fwp_main_thread+0x1a1>
    b1cc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b1d0:	48 85 c9             	test   %rcx,%rcx
    b1d3:	0f 84 58 fd ff ff    	je     af31 <fwp_main_thread+0x1a1>
    b1d9:	48 39 c8             	cmp    %rcx,%rax
    b1dc:	48 89 ce             	mov    %rcx,%rsi
    b1df:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b1e6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b1ea:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b1f1:	00 00 00 00 
    b1f5:	48 0f 4e f0          	cmovle %rax,%rsi
    b1f9:	48 85 c0             	test   %rax,%rax
    b1fc:	48 89 c8             	mov    %rcx,%rax
    b1ff:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b206:	48 0f 45 c6          	cmovne %rsi,%rax
    b20a:	48 85 d2             	test   %rdx,%rdx
    b20d:	74 07                	je     b216 <fwp_main_thread+0x486>
    b20f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b216:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b21a:	e9 44 fd ff ff       	jmp    af63 <fwp_main_thread+0x1d3>
    b21f:	90                   	nop
    b220:	48 89 cb             	mov    %rcx,%rbx
    b223:	e9 d7 fc ff ff       	jmp    aeff <fwp_main_thread+0x16f>
    b228:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b22f:	00 
    b230:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b234:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b23b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b242:	00 00 00 00 
    b246:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b24d:	48 85 c0             	test   %rax,%rax
    b250:	0f 84 4a 08 00 00    	je     baa0 <fwp_main_thread+0xd10>
    b256:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b25d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b261:	e9 31 fd ff ff       	jmp    af97 <fwp_main_thread+0x207>
    b266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b26d:	00 00 00 
    b270:	48 89 01             	mov    %rax,(%rcx)
    b273:	e9 59 fd ff ff       	jmp    afd1 <fwp_main_thread+0x241>
    b278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b27f:	00 
    b280:	48 83 3d 70 d5 05 00 	cmpq   $0x0,0x5d570(%rip)        # 687f8 <fwp_root>
    b287:	00 
    b288:	c7 05 ee 4d 01 00 00 	movl   $0x0,0x14dee(%rip)        # 20080 <fwp_exit_code>
    b28f:	00 00 00 
    b292:	0f 85 b8 09 00 00    	jne    bc50 <fwp_main_thread+0xec0>
    b298:	e8 33 c4 ff ff       	call   76d0 <fwp_free_zombie>
    b29d:	48 83 3d 43 d5 05 00 	cmpq   $0x0,0x5d543(%rip)        # 687e8 <fwp_ready_head>
    b2a4:	00 
    b2a5:	0f 85 a5 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2ab:	48 83 3d 25 d5 05 00 	cmpq   $0x0,0x5d525(%rip)        # 687d8 <fwp_timers>
    b2b2:	00 
    b2b3:	0f 85 97 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2b9:	8b 05 15 cf 05 00    	mov    0x5cf15(%rip),%eax        # 681d4 <fwp_stack_pool_n>
    b2bf:	85 c0                	test   %eax,%eax
    b2c1:	74 3a                	je     b2fd <fwp_main_thread+0x56d>
    b2c3:	83 e8 01             	sub    $0x1,%eax
    b2c6:	4c 8d 25 13 cf 05 00 	lea    0x5cf13(%rip),%r12        # 681e0 <fwp_stack_pool>
    b2cd:	48 63 d8             	movslq %eax,%rbx
    b2d0:	89 c0                	mov    %eax,%eax
    b2d2:	48 89 da             	mov    %rbx,%rdx
    b2d5:	48 29 c2             	sub    %rax,%rdx
    b2d8:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b2dc:	0f 1f 40 00          	nopl   0x0(%rax)
    b2e0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b2e4:	89 1d ea ce 05 00    	mov    %ebx,0x5ceea(%rip)        # 681d4 <fwp_stack_pool_n>
    b2ea:	be 00 00 00 10       	mov    $0x10000000,%esi
    b2ef:	48 83 eb 01          	sub    $0x1,%rbx
    b2f3:	e8 c8 82 ff ff       	call   35c0 <munmap@plt>
    b2f8:	48 39 dd             	cmp    %rbx,%rbp
    b2fb:	75 e3                	jne    b2e0 <fwp_main_thread+0x550>
    b2fd:	8b 3d 15 4d 00 00    	mov    0x4d15(%rip),%edi        # 10018 <fwp_epfd>
    b303:	85 ff                	test   %edi,%edi
    b305:	78 05                	js     b30c <fwp_main_thread+0x57c>
    b307:	e8 b4 81 ff ff       	call   34c0 <close@plt>
    b30c:	4c 8b 25 cd d0 05 00 	mov    0x5d0cd(%rip),%r12        # 683e0 <fwp_nfdws>
    b313:	48 8b 2d ce d0 05 00 	mov    0x5d0ce(%rip),%rbp        # 683e8 <fwp_fdws>
    b31a:	31 db                	xor    %ebx,%ebx
    b31c:	c7 05 f2 4c 00 00 ff 	movl   $0xffffffff,0x4cf2(%rip)        # 10018 <fwp_epfd>
    b323:	ff ff ff 
    b326:	4d 85 e4             	test   %r12,%r12
    b329:	74 32                	je     b35d <fwp_main_thread+0x5cd>
    b32b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b330:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b335:	48 85 ff             	test   %rdi,%rdi
    b338:	74 1a                	je     b354 <fwp_main_thread+0x5c4>
    b33a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b33e:	0f 85 0c 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b344:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b349:	0f 85 01 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b34f:	e8 bc a6 ff ff       	call   5a10 <fwp_mem_free>
    b354:	48 83 c3 01          	add    $0x1,%rbx
    b358:	49 39 dc             	cmp    %rbx,%r12
    b35b:	75 d3                	jne    b330 <fwp_main_thread+0x5a0>
    b35d:	48 89 ef             	mov    %rbp,%rdi
    b360:	e8 ab a6 ff ff       	call   5a10 <fwp_mem_free>
    b365:	48 8b 15 8c d4 05 00 	mov    0x5d48c(%rip),%rdx        # 687f8 <fwp_root>
    b36c:	48 c7 05 71 d0 05 00 	movq   $0x0,0x5d071(%rip)        # 683e8 <fwp_fdws>
    b373:	00 00 00 00 
    b377:	48 c7 05 5e d0 05 00 	movq   $0x0,0x5d05e(%rip)        # 683e0 <fwp_nfdws>
    b37e:	00 00 00 00 
    b382:	48 85 d2             	test   %rdx,%rdx
    b385:	74 4e                	je     b3d5 <fwp_main_thread+0x645>
    b387:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b38c:	0f 85 be 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b392:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b399:	00 
    b39a:	0f 85 b0 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3a0:	48 83 3d f0 f0 05 00 	cmpq   $0x0,0x5f0f0(%rip)        # 6a498 <fwp_state_len>
    b3a7:	00 
    b3a8:	0f 85 a2 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3ae:	48 83 3d d2 f0 05 00 	cmpq   $0x0,0x5f0d2(%rip)        # 6a488 <fwp_state_owners>
    b3b5:	00 
    b3b6:	0f 85 94 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3bc:	b9 79 00 00 00       	mov    $0x79,%ecx
    b3c1:	31 c0                	xor    %eax,%eax
    b3c3:	48 8d 3d 36 d0 05 00 	lea    0x5d036(%rip),%rdi        # 68400 <fwp_root_context>
    b3ca:	f3 48 ab             	rep stos %rax,(%rdi)
    b3cd:	48 89 d7             	mov    %rdx,%rdi
    b3d0:	e8 3b a6 ff ff       	call   5a10 <fwp_mem_free>
    b3d5:	66 0f 6f 05 d3 4d 04 	movdqa 0x44dd3(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    b3dc:	00 
    b3dd:	66 0f d4 05 bb 4d 04 	paddq  0x44dbb(%rip),%xmm0        # 501a0 <ad_raw_live>
    b3e4:	00 
    b3e5:	48 c7 05 10 d4 05 00 	movq   $0x0,0x5d410(%rip)        # 68800 <fwp_cur>
    b3ec:	00 00 00 00 
    b3f0:	48 8b 05 49 e8 05 00 	mov    0x5e849(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    b3f7:	48 c7 05 f6 d3 05 00 	movq   $0x0,0x5d3f6(%rip)        # 687f8 <fwp_root>
    b3fe:	00 00 00 00 
    b402:	c7 05 dc f0 05 00 00 	movl   $0x0,0x5f0dc(%rip)        # 6a4e8 <iteration_active>
    b409:	00 00 00 
    b40c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b410:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    b415:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    b419:	66 0f d6 05 d7 4c 01 	movq   %xmm0,0x14cd7(%rip)        # 200f8 <ad_raw_before_shutdown>
    b420:	00 
    b421:	48 85 c0             	test   %rax,%rax
    b424:	0f 88 56 06 00 00    	js     ba80 <fwp_main_thread+0xcf0>
    b42a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b42e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b433:	f2 0f 5c 0d 8d f0 05 	subsd  0x5f08d(%rip),%xmm1        # 6a4c8 <iteration_start_charge>
    b43a:	00 
    b43b:	48 8b 3d fe 4b 00 00 	mov    0x4bfe(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    b442:	48 8d 15 17 17 00 00 	lea    0x1717(%rip),%rdx        # cb60 <_IO_stdin_used+0xb60>
    b449:	be 02 00 00 00       	mov    $0x2,%esi
    b44e:	f2 0f 10 05 6a f0 05 	movsd  0x5f06a(%rip),%xmm0        # 6a4c0 <iteration_peak>
    b455:	00 
    b456:	4c 8b 0d 73 f0 05 00 	mov    0x5f073(%rip),%r9        # 6a4d0 <iteration_retains>
    b45d:	b8 02 00 00 00       	mov    $0x2,%eax
    b462:	4c 8b 05 6f f0 05 00 	mov    0x5f06f(%rip),%r8        # 6a4d8 <iteration_bytes>
    b469:	48 8b 0d 70 f0 05 00 	mov    0x5f070(%rip),%rcx        # 6a4e0 <iteration_requests>
    b470:	e8 fb 81 ff ff       	call   3670 <__fprintf_chk@plt>
    b475:	48 8b 3d a4 4b 00 00 	mov    0x4ba4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b47c:	e8 1f 81 ff ff       	call   35a0 <fflush@plt>
    b481:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b488:	00 
    b489:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b490:	00 00 
    b492:	0f 85 a7 07 00 00    	jne    bc3f <fwp_main_thread+0xeaf>
    b498:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b49f:	31 c0                	xor    %eax,%eax
    b4a1:	5b                   	pop    %rbx
    b4a2:	5d                   	pop    %rbp
    b4a3:	41 5c                	pop    %r12
    b4a5:	41 5d                	pop    %r13
    b4a7:	41 5e                	pop    %r14
    b4a9:	41 5f                	pop    %r15
    b4ab:	c3                   	ret
    b4ac:	0f 1f 40 00          	nopl   0x0(%rax)
    b4b0:	48 89 05 21 d3 05 00 	mov    %rax,0x5d321(%rip)        # 687d8 <fwp_timers>
    b4b7:	e9 66 fb ff ff       	jmp    b022 <fwp_main_thread+0x292>
    b4bc:	0f 1f 40 00          	nopl   0x0(%rax)
    b4c0:	48 89 c2             	mov    %rax,%rdx
    b4c3:	83 e0 01             	and    $0x1,%eax
    b4c6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b4ca:	48 d1 ea             	shr    $1,%rdx
    b4cd:	48 09 c2             	or     %rax,%rdx
    b4d0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b4d5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b4d9:	e9 d1 f9 ff ff       	jmp    aeaf <fwp_main_thread+0x11f>
    b4de:	66 90                	xchg   %ax,%ax
    b4e0:	e8 eb 98 ff ff       	call   4dd0 <fwp_heap_init>
    b4e5:	8b 35 dd e6 05 00    	mov    0x5e6dd(%rip),%esi        # 69bc8 <fwp_heap+0x13a8>
    b4eb:	85 f6                	test   %esi,%esi
    b4ed:	0f 84 e1 f8 ff ff    	je     add4 <fwp_main_thread+0x44>
    b4f3:	48 8d 3d c6 97 ff ff 	lea    -0x683a(%rip),%rdi        # 4cc0 <fwp_heap_report>
    b4fa:	e8 71 09 00 00       	call   be70 <atexit>
    b4ff:	e9 d0 f8 ff ff       	jmp    add4 <fwp_main_thread+0x44>
    b504:	0f 1f 40 00          	nopl   0x0(%rax)
    b508:	48 8d 05 e1 ba ff ff 	lea    -0x451f(%rip),%rax        # 6ff0 <fwp_drop1>
    b50f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b513:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b51a:	00 00 
    b51c:	41 be ff 7f 00 00    	mov    $0x7fff,%r14d
    b522:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b527:	48 8b 05 8a ef 05 00 	mov    0x5ef8a(%rip),%rax        # 6a4b8 <fwp_cleanups>
    b52e:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
    b533:	4c 8d 25 e6 d2 05 00 	lea    0x5d2e6(%rip),%r12        # 68820 <fwp_heap>
    b53a:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b53e:	48 89 1d 73 ef 05 00 	mov    %rbx,0x5ef73(%rip)        # 6a4b8 <fwp_cleanups>
    b545:	31 db                	xor    %ebx,%ebx
    b547:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b54c:	48 8d 05 7d 86 ff ff 	lea    -0x7983(%rip),%rax        # 3bd0 <fwp_range_release>
    b553:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b558:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b55d:	eb 3b                	jmp    b59a <fwp_main_thread+0x80a>
    b55f:	90                   	nop
    b560:	40 80 fe 01          	cmp    $0x1,%sil
    b564:	75 25                	jne    b58b <fwp_main_thread+0x7fb>
    b566:	8b 71 18             	mov    0x18(%rcx),%esi
    b569:	0f b7 c0             	movzwl %ax,%eax
    b56c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b56f:	48 0f af c6          	imul   %rsi,%rax
    b573:	48 c1 e8 20          	shr    $0x20,%rax
    b577:	48 39 c8             	cmp    %rcx,%rax
    b57a:	73 0f                	jae    b58b <fwp_main_thread+0x7fb>
    b57c:	48 01 c2             	add    %rax,%rdx
    b57f:	80 3a ff             	cmpb   $0xff,(%rdx)
    b582:	0f 84 68 05 00 00    	je     baf0 <fwp_main_thread+0xd60>
    b588:	c6 02 01             	movb   $0x1,(%rdx)
    b58b:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b590:	49 83 ee 01          	sub    $0x1,%r14
    b594:	0f 82 86 00 00 00    	jb     b620 <fwp_main_thread+0x890>
    b59a:	4c 89 ee             	mov    %r13,%rsi
    b59d:	bf 01 00 00 00       	mov    $0x1,%edi
    b5a2:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
    b5a9:	00 
    b5aa:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
    b5af:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    b5b6:	00 
    b5b7:	e8 04 b3 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    b5bc:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b5c3:	00 
    b5c4:	48 89 c3             	mov    %rax,%rbx
    b5c7:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b5ce:	00 
    b5cf:	48 c1 e2 10          	shl    $0x10,%rdx
    b5d3:	48 39 d0             	cmp    %rdx,%rax
    b5d6:	73 b3                	jae    b58b <fwp_main_thread+0x7fb>
    b5d8:	48 89 c2             	mov    %rax,%rdx
    b5db:	48 c1 ea 10          	shr    $0x10,%rdx
    b5df:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5e3:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b5ea:	00 
    b5eb:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    b5ef:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    b5f3:	48 85 d2             	test   %rdx,%rdx
    b5f6:	74 93                	je     b58b <fwp_main_thread+0x7fb>
    b5f8:	0f b6 31             	movzbl (%rcx),%esi
    b5fb:	40 80 fe 02          	cmp    $0x2,%sil
    b5ff:	0f 85 5b ff ff ff    	jne    b560 <fwp_main_thread+0x7d0>
    b605:	66 85 c0             	test   %ax,%ax
    b608:	0f 84 71 ff ff ff    	je     b57f <fwp_main_thread+0x7ef>
    b60e:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    b613:	49 83 ee 01          	sub    $0x1,%r14
    b617:	73 81                	jae    b59a <fwp_main_thread+0x80a>
    b619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b620:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b625:	66 0f 6f 05 a3 17 00 	movdqa 0x17a3(%rip),%xmm0        # cdd0 <msg.4+0xa0>
    b62c:	00 
    b62d:	4c 89 ee             	mov    %r13,%rsi
    b630:	bf 01 00 00 00       	mov    $0x1,%edi
    b635:	48 89 05 7c ee 05 00 	mov    %rax,0x5ee7c(%rip)        # 6a4b8 <fwp_cleanups>
    b63c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b643:	00 
    b644:	e8 77 b2 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    b649:	48 8b 15 a8 e5 05 00 	mov    0x5e5a8(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b650:	49 89 c6             	mov    %rax,%r14
    b653:	48 2b 05 76 e5 05 00 	sub    0x5e576(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    b65a:	48 c1 e2 10          	shl    $0x10,%rdx
    b65e:	48 39 d0             	cmp    %rdx,%rax
    b661:	73 59                	jae    b6bc <fwp_main_thread+0x92c>
    b663:	48 89 c2             	mov    %rax,%rdx
    b666:	48 c1 ea 10          	shr    $0x10,%rdx
    b66a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b66e:	48 8b 15 a3 e5 05 00 	mov    0x5e5a3(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    b675:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b679:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b67d:	4d 85 ed             	test   %r13,%r13
    b680:	74 3a                	je     b6bc <fwp_main_thread+0x92c>
    b682:	0f b6 0a             	movzbl (%rdx),%ecx
    b685:	80 f9 02             	cmp    $0x2,%cl
    b688:	0f 84 52 04 00 00    	je     bae0 <fwp_main_thread+0xd50>
    b68e:	80 f9 01             	cmp    $0x1,%cl
    b691:	75 29                	jne    b6bc <fwp_main_thread+0x92c>
    b693:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b696:	0f b7 c0             	movzwl %ax,%eax
    b699:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b69c:	48 0f af c1          	imul   %rcx,%rax
    b6a0:	48 c1 e8 20          	shr    $0x20,%rax
    b6a4:	48 39 d0             	cmp    %rdx,%rax
    b6a7:	73 13                	jae    b6bc <fwp_main_thread+0x92c>
    b6a9:	49 01 c5             	add    %rax,%r13
    b6ac:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b6b1:	0f 84 c2 04 00 00    	je     bb79 <fwp_main_thread+0xde9>
    b6b7:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b6bc:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b6c1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6c6:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b6cb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b6d2:	00 f0 3f 
    b6d5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b6da:	e8 e1 b1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    b6df:	48 8b 15 12 e5 05 00 	mov    0x5e512(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b6e6:	49 89 c6             	mov    %rax,%r14
    b6e9:	48 2b 05 e0 e4 05 00 	sub    0x5e4e0(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    b6f0:	48 c1 e2 10          	shl    $0x10,%rdx
    b6f4:	48 39 d0             	cmp    %rdx,%rax
    b6f7:	73 59                	jae    b752 <fwp_main_thread+0x9c2>
    b6f9:	48 89 c2             	mov    %rax,%rdx
    b6fc:	48 c1 ea 10          	shr    $0x10,%rdx
    b700:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b704:	48 8b 15 0d e5 05 00 	mov    0x5e50d(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    b70b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b70f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b713:	4d 85 ed             	test   %r13,%r13
    b716:	74 3a                	je     b752 <fwp_main_thread+0x9c2>
    b718:	0f b6 0a             	movzbl (%rdx),%ecx
    b71b:	80 f9 02             	cmp    $0x2,%cl
    b71e:	0f 84 ac 03 00 00    	je     bad0 <fwp_main_thread+0xd40>
    b724:	80 f9 01             	cmp    $0x1,%cl
    b727:	75 29                	jne    b752 <fwp_main_thread+0x9c2>
    b729:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b72c:	0f b7 c0             	movzwl %ax,%eax
    b72f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b732:	48 0f af c1          	imul   %rcx,%rax
    b736:	48 c1 e8 20          	shr    $0x20,%rax
    b73a:	48 39 d0             	cmp    %rdx,%rax
    b73d:	73 13                	jae    b752 <fwp_main_thread+0x9c2>
    b73f:	49 01 c5             	add    %rax,%r13
    b742:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b747:	0f 84 39 04 00 00    	je     bb86 <fwp_main_thread+0xdf6>
    b74d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b752:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b757:	bf 01 00 00 00       	mov    $0x1,%edi
    b75c:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b761:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b768:	33 f3 bf 
    b76b:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b770:	e8 4b b1 ff ff       	call   68c0 <fwp_data.part.0.constprop.0>
    b775:	48 8b 15 7c e4 05 00 	mov    0x5e47c(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b77c:	48 8b 0d 4d e4 05 00 	mov    0x5e44d(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    b783:	49 89 c5             	mov    %rax,%r13
    b786:	48 89 d6             	mov    %rdx,%rsi
    b789:	48 29 c8             	sub    %rcx,%rax
    b78c:	48 c1 e6 10          	shl    $0x10,%rsi
    b790:	48 39 f0             	cmp    %rsi,%rax
    b793:	73 67                	jae    b7fc <fwp_main_thread+0xa6c>
    b795:	48 89 c6             	mov    %rax,%rsi
    b798:	48 c1 ee 10          	shr    $0x10,%rsi
    b79c:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b7a0:	48 8b 35 71 e4 05 00 	mov    0x5e471(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    b7a7:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b7ab:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b7af:	4d 85 f6             	test   %r14,%r14
    b7b2:	74 48                	je     b7fc <fwp_main_thread+0xa6c>
    b7b4:	0f b6 3e             	movzbl (%rsi),%edi
    b7b7:	40 80 ff 02          	cmp    $0x2,%dil
    b7bb:	0f 84 ff 02 00 00    	je     bac0 <fwp_main_thread+0xd30>
    b7c1:	40 80 ff 01          	cmp    $0x1,%dil
    b7c5:	75 35                	jne    b7fc <fwp_main_thread+0xa6c>
    b7c7:	8b 7e 18             	mov    0x18(%rsi),%edi
    b7ca:	0f b7 c0             	movzwl %ax,%eax
    b7cd:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b7d0:	48 0f af c7          	imul   %rdi,%rax
    b7d4:	48 c1 e8 20          	shr    $0x20,%rax
    b7d8:	48 39 f0             	cmp    %rsi,%rax
    b7db:	73 1f                	jae    b7fc <fwp_main_thread+0xa6c>
    b7dd:	49 01 c6             	add    %rax,%r14
    b7e0:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b7e4:	0f 84 a9 03 00 00    	je     bb93 <fwp_main_thread+0xe03>
    b7ea:	41 c6 06 01          	movb   $0x1,(%r14)
    b7ee:	48 8b 0d db e3 05 00 	mov    0x5e3db(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    b7f5:	48 8b 15 fc e3 05 00 	mov    0x5e3fc(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    b7fc:	48 89 1c 24          	mov    %rbx,(%rsp)
    b800:	4c 89 e8             	mov    %r13,%rax
    b803:	48 c1 e2 10          	shl    $0x10,%rdx
    b807:	48 29 c8             	sub    %rcx,%rax
    b80a:	48 39 d0             	cmp    %rdx,%rax
    b80d:	73 70                	jae    b87f <fwp_main_thread+0xaef>
    b80f:	48 89 c2             	mov    %rax,%rdx
    b812:	48 c1 ea 10          	shr    $0x10,%rdx
    b816:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b81a:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b821:	00 
    b822:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b826:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b82a:	48 85 ff             	test   %rdi,%rdi
    b82d:	74 50                	je     b87f <fwp_main_thread+0xaef>
    b82f:	0f b6 0a             	movzbl (%rdx),%ecx
    b832:	80 f9 02             	cmp    $0x2,%cl
    b835:	0f 84 75 02 00 00    	je     bab0 <fwp_main_thread+0xd20>
    b83b:	80 f9 01             	cmp    $0x1,%cl
    b83e:	75 3f                	jne    b87f <fwp_main_thread+0xaef>
    b840:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b843:	0f b7 c0             	movzwl %ax,%eax
    b846:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b849:	48 0f af c1          	imul   %rcx,%rax
    b84d:	48 c1 e8 20          	shr    $0x20,%rax
    b851:	48 39 d0             	cmp    %rdx,%rax
    b854:	73 29                	jae    b87f <fwp_main_thread+0xaef>
    b856:	48 01 c7             	add    %rax,%rdi
    b859:	0f b6 07             	movzbl (%rdi),%eax
    b85c:	84 c0                	test   %al,%al
    b85e:	74 1f                	je     b87f <fwp_main_thread+0xaef>
    b860:	8b 15 82 ec 05 00    	mov    0x5ec82(%rip),%edx        # 6a4e8 <iteration_active>
    b866:	85 d2                	test   %edx,%edx
    b868:	74 08                	je     b872 <fwp_main_thread+0xae2>
    b86a:	48 83 05 5e ec 05 00 	addq   $0x1,0x5ec5e(%rip)        # 6a4d0 <iteration_retains>
    b871:	01 
    b872:	3c fd                	cmp    $0xfd,%al
    b874:	0f 87 26 03 00 00    	ja     bba0 <fwp_main_thread+0xe10>
    b87a:	83 c0 01             	add    $0x1,%eax
    b87d:	88 07                	mov    %al,(%rdi)
    b87f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b883:	b9 01 00 00 00       	mov    $0x1,%ecx
    b888:	4c 89 ee             	mov    %r13,%rsi
    b88b:	48 89 ef             	mov    %rbp,%rdi
    b88e:	48 8d 15 0b 43 00 00 	lea    0x430b(%rip),%rdx        # fba0 <d0>
    b895:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b89a:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b8a1:	00 00 
    b8a3:	e8 a8 e4 ff ff       	call   9d50 <fwp_write>
    b8a8:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b8ad:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    b8b2:	48 8d 05 b3 07 00 00 	lea    0x7b3(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    b8b9:	4d 85 f6             	test   %r14,%r14
    b8bc:	4c 0f 44 f0          	cmove  %rax,%r14
    b8c0:	48 83 fa f6          	cmp    $0xfffffffffffffff6,%rdx
    b8c4:	0f 87 7a 03 00 00    	ja     bc44 <fwp_main_thread+0xeb4>
    b8ca:	48 8d 7a 09          	lea    0x9(%rdx),%rdi
    b8ce:	be 01 00 00 00       	mov    $0x1,%esi
    b8d3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b8d8:	e8 33 a6 ff ff       	call   5f10 <fwp_heap_alloc>
    b8dd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b8e2:	4c 89 f6             	mov    %r14,%rsi
    b8e5:	48 8d 78 08          	lea    0x8(%rax),%rdi
    b8e9:	49 89 c7             	mov    %rax,%r15
    b8ec:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b8f1:	48 89 10             	mov    %rdx,(%rax)
    b8f4:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    b8f9:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    b8fe:	e8 7d 7c ff ff       	call   3580 <memcpy@plt>
    b903:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    b908:	41 c6 44 17 08 00    	movb   $0x0,0x8(%r15,%rdx,1)
    b90e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b913:	e8 98 7a ff ff       	call   33b0 <free@plt>
    b918:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b91f:	00 
    b920:	4d 2b bc 24 b0 13 00 	sub    0x13b0(%r12),%r15
    b927:	00 
    b928:	48 c1 e2 10          	shl    $0x10,%rdx
    b92c:	49 39 d7             	cmp    %rdx,%r15
    b92f:	73 59                	jae    b98a <fwp_main_thread+0xbfa>
    b931:	4c 89 fa             	mov    %r15,%rdx
    b934:	48 c1 ea 10          	shr    $0x10,%rdx
    b938:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b93c:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b943:	00 
    b944:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b948:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b94c:	4d 85 f6             	test   %r14,%r14
    b94f:	74 39                	je     b98a <fwp_main_thread+0xbfa>
    b951:	0f b6 0a             	movzbl (%rdx),%ecx
    b954:	80 f9 02             	cmp    $0x2,%cl
    b957:	0f 84 b6 01 00 00    	je     bb13 <fwp_main_thread+0xd83>
    b95d:	80 f9 01             	cmp    $0x1,%cl
    b960:	75 28                	jne    b98a <fwp_main_thread+0xbfa>
    b962:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b965:	41 0f b7 c7          	movzwl %r15w,%eax
    b969:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b96c:	48 0f af c1          	imul   %rcx,%rax
    b970:	48 c1 e8 20          	shr    $0x20,%rax
    b974:	48 39 d0             	cmp    %rdx,%rax
    b977:	73 11                	jae    b98a <fwp_main_thread+0xbfa>
    b979:	49 01 c6             	add    %rax,%r14
    b97c:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b980:	0f 84 24 02 00 00    	je     bbaa <fwp_main_thread+0xe1a>
    b986:	41 c6 06 01          	movb   $0x1,(%r14)
    b98a:	4c 89 ef             	mov    %r13,%rdi
    b98d:	e8 ce b4 ff ff       	call   6e60 <fwp_drop0>
    b992:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    b997:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    b99c:	be 01 00 00 00       	mov    $0x1,%esi
    b9a1:	48 8b 0d d8 ea 05 00 	mov    0x5ead8(%rip),%rcx        # 6a480 <fwp_prog_out>
    b9a8:	49 8b 17             	mov    (%r15),%rdx
    b9ab:	e8 b0 7c ff ff       	call   3660 <fwrite@plt>
    b9b0:	48 8b 35 c9 ea 05 00 	mov    0x5eac9(%rip),%rsi        # 6a480 <fwp_prog_out>
    b9b7:	bf 0a 00 00 00       	mov    $0xa,%edi
    b9bc:	e8 0f 7b ff ff       	call   34d0 <fputc@plt>
    b9c1:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b9c8:	00 
    b9c9:	4c 89 f8             	mov    %r15,%rax
    b9cc:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b9d3:	00 
    b9d4:	48 c1 e2 10          	shl    $0x10,%rdx
    b9d8:	48 39 d0             	cmp    %rdx,%rax
    b9db:	73 73                	jae    ba50 <fwp_main_thread+0xcc0>
    b9dd:	48 89 c2             	mov    %rax,%rdx
    b9e0:	48 c1 ea 10          	shr    $0x10,%rdx
    b9e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b9e8:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b9ef:	00 
    b9f0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b9f4:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b9f8:	4d 85 f6             	test   %r14,%r14
    b9fb:	74 53                	je     ba50 <fwp_main_thread+0xcc0>
    b9fd:	0f b6 0a             	movzbl (%rdx),%ecx
    ba00:	80 f9 02             	cmp    $0x2,%cl
    ba03:	0f 84 fc 00 00 00    	je     bb05 <fwp_main_thread+0xd75>
    ba09:	80 f9 01             	cmp    $0x1,%cl
    ba0c:	75 42                	jne    ba50 <fwp_main_thread+0xcc0>
    ba0e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba11:	0f b7 c0             	movzwl %ax,%eax
    ba14:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba17:	48 0f af c1          	imul   %rcx,%rax
    ba1b:	48 c1 e8 20          	shr    $0x20,%rax
    ba1f:	48 39 d0             	cmp    %rdx,%rax
    ba22:	73 2c                	jae    ba50 <fwp_main_thread+0xcc0>
    ba24:	49 01 c6             	add    %rax,%r14
    ba27:	41 0f b6 06          	movzbl (%r14),%eax
    ba2b:	84 c0                	test   %al,%al
    ba2d:	74 21                	je     ba50 <fwp_main_thread+0xcc0>
    ba2f:	3c 01                	cmp    $0x1,%al
    ba31:	0f 84 33 01 00 00    	je     bb6a <fwp_main_thread+0xdda>
    ba37:	3c ff                	cmp    $0xff,%al
    ba39:	0f 84 78 01 00 00    	je     bbb7 <fwp_main_thread+0xe27>
    ba3f:	83 e8 01             	sub    $0x1,%eax
    ba42:	41 88 06             	mov    %al,(%r14)
    ba45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba4c:	00 00 00 00 
    ba50:	48 8b 04 24          	mov    (%rsp),%rax
    ba54:	48 8b 40 10          	mov    0x10(%rax),%rax
    ba58:	48 89 04 24          	mov    %rax,(%rsp)
    ba5c:	48 85 c0             	test   %rax,%rax
    ba5f:	0f 84 db 00 00 00    	je     bb40 <fwp_main_thread+0xdb0>
    ba65:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    ba6c:	00 
    ba6d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ba74:	00 
    ba75:	e9 86 fd ff ff       	jmp    b800 <fwp_main_thread+0xa70>
    ba7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ba80:	48 89 c2             	mov    %rax,%rdx
    ba83:	83 e0 01             	and    $0x1,%eax
    ba86:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ba8a:	48 d1 ea             	shr    $1,%rdx
    ba8d:	48 09 c2             	or     %rax,%rdx
    ba90:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    ba95:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    ba99:	e9 95 f9 ff ff       	jmp    b433 <fwp_main_thread+0x6a3>
    ba9e:	66 90                	xchg   %ax,%ax
    baa0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    baa4:	e9 ee f4 ff ff       	jmp    af97 <fwp_main_thread+0x207>
    baa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bab0:	66 85 c0             	test   %ax,%ax
    bab3:	0f 85 c6 fd ff ff    	jne    b87f <fwp_main_thread+0xaef>
    bab9:	e9 9b fd ff ff       	jmp    b859 <fwp_main_thread+0xac9>
    babe:	66 90                	xchg   %ax,%ax
    bac0:	66 85 c0             	test   %ax,%ax
    bac3:	0f 85 33 fd ff ff    	jne    b7fc <fwp_main_thread+0xa6c>
    bac9:	e9 12 fd ff ff       	jmp    b7e0 <fwp_main_thread+0xa50>
    bace:	66 90                	xchg   %ax,%ax
    bad0:	66 85 c0             	test   %ax,%ax
    bad3:	0f 85 79 fc ff ff    	jne    b752 <fwp_main_thread+0x9c2>
    bad9:	e9 64 fc ff ff       	jmp    b742 <fwp_main_thread+0x9b2>
    bade:	66 90                	xchg   %ax,%ax
    bae0:	66 85 c0             	test   %ax,%ax
    bae3:	0f 85 d3 fb ff ff    	jne    b6bc <fwp_main_thread+0x92c>
    bae9:	e9 be fb ff ff       	jmp    b6ac <fwp_main_thread+0x91c>
    baee:	66 90                	xchg   %ax,%ax
    baf0:	48 89 d7             	mov    %rdx,%rdi
    baf3:	48 89 14 24          	mov    %rdx,(%rsp)
    baf7:	e8 d4 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bafc:	48 8b 14 24          	mov    (%rsp),%rdx
    bb00:	e9 83 fa ff ff       	jmp    b588 <fwp_main_thread+0x7f8>
    bb05:	66 85 c0             	test   %ax,%ax
    bb08:	0f 85 42 ff ff ff    	jne    ba50 <fwp_main_thread+0xcc0>
    bb0e:	e9 14 ff ff ff       	jmp    ba27 <fwp_main_thread+0xc97>
    bb13:	66 45 85 ff          	test   %r15w,%r15w
    bb17:	0f 85 6d fe ff ff    	jne    b98a <fwp_main_thread+0xbfa>
    bb1d:	e9 5a fe ff ff       	jmp    b97c <fwp_main_thread+0xbec>
    bb22:	48 83 3d ce cc 05 00 	cmpq   $0x0,0x5ccce(%rip)        # 687f8 <fwp_root>
    bb29:	00 
    bb2a:	c7 05 4c 45 01 00 00 	movl   $0x0,0x1454c(%rip)        # 20080 <fwp_exit_code>
    bb31:	00 00 00 
    bb34:	0f 84 5e f7 ff ff    	je     b298 <fwp_main_thread+0x508>
    bb3a:	e9 11 7c ff ff       	jmp    3750 <fwp_main_thread.cold>
    bb3f:	90                   	nop
    bb40:	4c 89 ef             	mov    %r13,%rdi
    bb43:	e8 18 b3 ff ff       	call   6e60 <fwp_drop0>
    bb48:	48 89 df             	mov    %rbx,%rdi
    bb4b:	e8 10 b3 ff ff       	call   6e60 <fwp_drop0>
    bb50:	48 c7 05 0d 45 00 00 	movq   $0x0,0x450d(%rip)        # 10068 <v.2>
    bb57:	00 00 00 00 
    bb5b:	c7 05 0b 45 00 00 01 	movl   $0x1,0x450b(%rip)        # 10070 <st.3>
    bb62:	00 00 00 
    bb65:	e9 79 f3 ff ff       	jmp    aee3 <fwp_main_thread+0x153>
    bb6a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    bb6f:	e8 bc af ff ff       	call   6b30 <fwp_rc_free_arr>
    bb74:	e9 d7 fe ff ff       	jmp    ba50 <fwp_main_thread+0xcc0>
    bb79:	4c 89 ef             	mov    %r13,%rdi
    bb7c:	e8 4f 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb81:	e9 31 fb ff ff       	jmp    b6b7 <fwp_main_thread+0x927>
    bb86:	4c 89 ef             	mov    %r13,%rdi
    bb89:	e8 42 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb8e:	e9 ba fb ff ff       	jmp    b74d <fwp_main_thread+0x9bd>
    bb93:	4c 89 f7             	mov    %r14,%rdi
    bb96:	e8 35 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb9b:	e9 4a fc ff ff       	jmp    b7ea <fwp_main_thread+0xa5a>
    bba0:	e8 0b 9b ff ff       	call   56b0 <fwp_rc_wide_dup>
    bba5:	e9 d5 fc ff ff       	jmp    b87f <fwp_main_thread+0xaef>
    bbaa:	4c 89 f7             	mov    %r14,%rdi
    bbad:	e8 1e 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bbb2:	e9 cf fd ff ff       	jmp    b986 <fwp_main_thread+0xbf6>
    bbb7:	4c 89 f0             	mov    %r14,%rax
    bbba:	48 c1 e8 11          	shr    $0x11,%rax
    bbbe:	4c 31 f0             	xor    %r14,%rax
    bbc1:	48 89 c2             	mov    %rax,%rdx
    bbc4:	48 c1 ea 09          	shr    $0x9,%rdx
    bbc8:	48 31 d0             	xor    %rdx,%rax
    bbcb:	0f b6 d0             	movzbl %al,%edx
    bbce:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bbd5:	00 
    bbd6:	48 85 c0             	test   %rax,%rax
    bbd9:	75 0e                	jne    bbe9 <fwp_main_thread+0xe59>
    bbdb:	eb 56                	jmp    bc33 <fwp_main_thread+0xea3>
    bbdd:	0f 1f 00             	nopl   (%rax)
    bbe0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bbe4:	48 85 c0             	test   %rax,%rax
    bbe7:	74 4a                	je     bc33 <fwp_main_thread+0xea3>
    bbe9:	48 89 c2             	mov    %rax,%rdx
    bbec:	4c 3b 30             	cmp    (%rax),%r14
    bbef:	75 ef                	jne    bbe0 <fwp_main_thread+0xe50>
    bbf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    bbf5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    bbf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bbfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bc04:	0f 85 46 fe ff ff    	jne    ba50 <fwp_main_thread+0xcc0>
    bc0a:	4c 89 f7             	mov    %r14,%rdi
    bc0d:	e8 be 9b ff ff       	call   57d0 <fwp_rc_forget_slot>
    bc12:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bc16:	e9 35 fe ff ff       	jmp    ba50 <fwp_main_thread+0xcc0>
    bc1b:	48 8d 3d 16 0f 00 00 	lea    0xf16(%rip),%rdi        # cb38 <_IO_stdin_used+0xb38>
    bc22:	e8 29 88 ff ff       	call   4450 <fwp_trap>
    bc27:	48 8d 3d 94 06 00 00 	lea    0x694(%rip),%rdi        # c2c2 <_IO_stdin_used+0x2c2>
    bc2e:	e8 cd 83 ff ff       	call   4000 <ad_raw_fail>
    bc33:	48 8d 3d a6 0d 00 00 	lea    0xda6(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    bc3a:	e8 11 88 ff ff       	call   4450 <fwp_trap>
    bc3f:	e8 0c 78 ff ff       	call   3450 <__stack_chk_fail@plt>
    bc44:	48 8d 3d 92 06 00 00 	lea    0x692(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    bc4b:	e8 00 88 ff ff       	call   4450 <fwp_trap>
    bc50:	e9 fb 7a ff ff       	jmp    3750 <fwp_main_thread.cold>
    bc55:	e9 f6 7a ff ff       	jmp    3750 <fwp_main_thread.cold>
    bc5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000bc60 <__divmodti4>:
    bc60:	f3 0f 1e fa          	endbr64
    bc64:	55                   	push   %rbp
    bc65:	49 89 f1             	mov    %rsi,%r9
    bc68:	49 89 d2             	mov    %rdx,%r10
    bc6b:	48 89 fe             	mov    %rdi,%rsi
    bc6e:	49 89 cb             	mov    %rcx,%r11
    bc71:	48 89 e5             	mov    %rsp,%rbp
    bc74:	41 57                	push   %r15
    bc76:	41 56                	push   %r14
    bc78:	41 55                	push   %r13
    bc7a:	41 54                	push   %r12
    bc7c:	53                   	push   %rbx
    bc7d:	4c 89 c3             	mov    %r8,%rbx
    bc80:	45 31 c0             	xor    %r8d,%r8d
    bc83:	4d 85 c9             	test   %r9,%r9
    bc86:	79 12                	jns    bc9a <__divmodti4+0x3a>
    bc88:	31 ff                	xor    %edi,%edi
    bc8a:	48 f7 de             	neg    %rsi
    bc8d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bc94:	4c 19 cf             	sbb    %r9,%rdi
    bc97:	49 89 f9             	mov    %rdi,%r9
    bc9a:	4c 89 d8             	mov    %r11,%rax
    bc9d:	4d 85 db             	test   %r11,%r11
    bca0:	0f 88 1a 01 00 00    	js     bdc0 <__divmodti4+0x160>
    bca6:	4c 89 d9             	mov    %r11,%rcx
    bca9:	49 89 f3             	mov    %rsi,%r11
    bcac:	75 62                	jne    bd10 <__divmodti4+0xb0>
    bcae:	4d 89 c4             	mov    %r8,%r12
    bcb1:	4d 39 d1             	cmp    %r10,%r9
    bcb4:	0f 83 46 01 00 00    	jae    be00 <__divmodti4+0x1a0>
    bcba:	4c 89 d8             	mov    %r11,%rax
    bcbd:	4c 89 ca             	mov    %r9,%rdx
    bcc0:	49 f7 f2             	div    %r10
    bcc3:	49 89 c3             	mov    %rax,%r11
    bcc6:	31 c0                	xor    %eax,%eax
    bcc8:	48 89 d6             	mov    %rdx,%rsi
    bccb:	31 ff                	xor    %edi,%edi
    bccd:	4c 89 d9             	mov    %r11,%rcx
    bcd0:	48 89 c2             	mov    %rax,%rdx
    bcd3:	48 89 c8             	mov    %rcx,%rax
    bcd6:	4d 85 e4             	test   %r12,%r12
    bcd9:	74 0a                	je     bce5 <__divmodti4+0x85>
    bcdb:	48 f7 d8             	neg    %rax
    bcde:	48 83 d2 00          	adc    $0x0,%rdx
    bce2:	48 f7 da             	neg    %rdx
    bce5:	4d 85 c0             	test   %r8,%r8
    bce8:	74 0a                	je     bcf4 <__divmodti4+0x94>
    bcea:	48 f7 de             	neg    %rsi
    bced:	48 83 d7 00          	adc    $0x0,%rdi
    bcf1:	48 f7 df             	neg    %rdi
    bcf4:	48 89 33             	mov    %rsi,(%rbx)
    bcf7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bcfb:	5b                   	pop    %rbx
    bcfc:	41 5c                	pop    %r12
    bcfe:	41 5d                	pop    %r13
    bd00:	41 5e                	pop    %r14
    bd02:	41 5f                	pop    %r15
    bd04:	5d                   	pop    %rbp
    bd05:	c3                   	ret
    bd06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd0d:	00 00 00 
    bd10:	4d 89 c4             	mov    %r8,%r12
    bd13:	49 39 c1             	cmp    %rax,%r9
    bd16:	0f 82 ce 00 00 00    	jb     bdea <__divmodti4+0x18a>
    bd1c:	31 ff                	xor    %edi,%edi
    bd1e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bd23:	48 63 c7             	movslq %edi,%rax
    bd26:	be 40 00 00 00       	mov    $0x40,%esi
    bd2b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bd30:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bd35:	48 29 c6             	sub    %rax,%rsi
    bd38:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bd3d:	48 09 c8             	or     %rcx,%rax
    bd40:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bd45:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bd4a:	49 89 c6             	mov    %rax,%r14
    bd4d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bd51:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bd56:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bd5b:	49 09 c1             	or     %rax,%r9
    bd5e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bd62:	4c 89 c8             	mov    %r9,%rax
    bd65:	49 f7 f6             	div    %r14
    bd68:	48 89 d1             	mov    %rdx,%rcx
    bd6b:	49 89 c3             	mov    %rax,%r11
    bd6e:	49 89 c1             	mov    %rax,%r9
    bd71:	49 f7 e2             	mul    %r10
    bd74:	49 89 c6             	mov    %rax,%r14
    bd77:	49 89 d2             	mov    %rdx,%r10
    bd7a:	48 39 d1             	cmp    %rdx,%rcx
    bd7d:	72 07                	jb     bd86 <__divmodti4+0x126>
    bd7f:	75 17                	jne    bd98 <__divmodti4+0x138>
    bd81:	49 39 c7             	cmp    %rax,%r15
    bd84:	73 12                	jae    bd98 <__divmodti4+0x138>
    bd86:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bd8a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bd8e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bd92:	49 89 d2             	mov    %rdx,%r10
    bd95:	49 89 c6             	mov    %rax,%r14
    bd98:	4c 89 f8             	mov    %r15,%rax
    bd9b:	4c 29 f0             	sub    %r14,%rax
    bd9e:	4c 19 d1             	sbb    %r10,%rcx
    bda1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bda6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bdab:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bdb0:	48 09 c6             	or     %rax,%rsi
    bdb3:	48 89 cf             	mov    %rcx,%rdi
    bdb6:	31 c0                	xor    %eax,%eax
    bdb8:	4c 89 c9             	mov    %r9,%rcx
    bdbb:	e9 10 ff ff ff       	jmp    bcd0 <__divmodti4+0x70>
    bdc0:	4c 89 d0             	mov    %r10,%rax
    bdc3:	4c 89 da             	mov    %r11,%rdx
    bdc6:	4d 89 c4             	mov    %r8,%r12
    bdc9:	49 89 f3             	mov    %rsi,%r11
    bdcc:	48 f7 d8             	neg    %rax
    bdcf:	49 f7 d4             	not    %r12
    bdd2:	48 83 d2 00          	adc    $0x0,%rdx
    bdd6:	49 89 c2             	mov    %rax,%r10
    bdd9:	48 f7 da             	neg    %rdx
    bddc:	48 89 d1             	mov    %rdx,%rcx
    bddf:	0f 84 cc fe ff ff    	je     bcb1 <__divmodti4+0x51>
    bde5:	49 39 d1             	cmp    %rdx,%r9
    bde8:	73 46                	jae    be30 <__divmodti4+0x1d0>
    bdea:	4c 89 cf             	mov    %r9,%rdi
    bded:	31 c0                	xor    %eax,%eax
    bdef:	31 c9                	xor    %ecx,%ecx
    bdf1:	e9 da fe ff ff       	jmp    bcd0 <__divmodti4+0x70>
    bdf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bdfd:	00 00 00 
    be00:	4d 85 d2             	test   %r10,%r10
    be03:	75 0d                	jne    be12 <__divmodti4+0x1b2>
    be05:	b8 01 00 00 00       	mov    $0x1,%eax
    be0a:	31 d2                	xor    %edx,%edx
    be0c:	49 f7 f2             	div    %r10
    be0f:	49 89 c2             	mov    %rax,%r10
    be12:	4c 89 c8             	mov    %r9,%rax
    be15:	31 d2                	xor    %edx,%edx
    be17:	49 f7 f2             	div    %r10
    be1a:	49 89 c1             	mov    %rax,%r9
    be1d:	4c 89 d8             	mov    %r11,%rax
    be20:	49 f7 f2             	div    %r10
    be23:	49 89 c3             	mov    %rax,%r11
    be26:	4c 89 c8             	mov    %r9,%rax
    be29:	e9 9a fe ff ff       	jmp    bcc8 <__divmodti4+0x68>
    be2e:	66 90                	xchg   %ax,%ax
    be30:	45 31 f6             	xor    %r14d,%r14d
    be33:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    be38:	44 89 f7             	mov    %r14d,%edi
    be3b:	45 85 f6             	test   %r14d,%r14d
    be3e:	0f 85 df fe ff ff    	jne    bd23 <__divmodti4+0xc3>
    be44:	4c 39 ca             	cmp    %r9,%rdx
    be47:	72 17                	jb     be60 <__divmodti4+0x200>
    be49:	31 c9                	xor    %ecx,%ecx
    be4b:	48 39 c6             	cmp    %rax,%rsi
    be4e:	73 10                	jae    be60 <__divmodti4+0x200>
    be50:	4c 89 cf             	mov    %r9,%rdi
    be53:	31 c0                	xor    %eax,%eax
    be55:	e9 76 fe ff ff       	jmp    bcd0 <__divmodti4+0x70>
    be5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    be60:	4c 89 de             	mov    %r11,%rsi
    be63:	b9 01 00 00 00       	mov    $0x1,%ecx
    be68:	48 29 c6             	sub    %rax,%rsi
    be6b:	49 19 d1             	sbb    %rdx,%r9
    be6e:	eb e0                	jmp    be50 <__divmodti4+0x1f0>

000000000000be70 <atexit>:
    be70:	f3 0f 1e fa          	endbr64
    be74:	48 8b 15 8d 41 00 00 	mov    0x418d(%rip),%rdx        # 10008 <__dso_handle>
    be7b:	31 f6                	xor    %esi,%esi
    be7d:	e9 be 77 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000be84 <_fini>:
    be84:	f3 0f 1e fa          	endbr64
    be88:	48 83 ec 08          	sub    $0x8,%rsp
    be8c:	48 83 c4 08          	add    $0x8,%rsp
    be90:	c3                   	ret
