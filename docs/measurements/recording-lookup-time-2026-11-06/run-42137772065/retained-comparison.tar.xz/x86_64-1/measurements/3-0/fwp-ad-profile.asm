
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 bf 00 00 	mov    0xbfd1(%rip),%rax        # efe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 bc 00 00    	jmp    *0xbc66(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # ee28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # ee30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # ee38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # ee40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # eea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # eea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # eeb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # eeb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # eec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # eec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # ef00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # ef08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # ef10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # ef18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # ef20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # ef28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # efa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # efa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # efb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # efb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # efc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # efc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036e0 <fwp_trap_overflow.constprop.0>:
    36e0:	53                   	push   %rbx
    36e1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36e6:	ba 02 00 00 00       	mov    $0x2,%edx
    36eb:	be 60 00 00 00       	mov    $0x60,%esi
    36f0:	4c 8d 0d d8 79 00 00 	lea    0x79d8(%rip),%r9        # b0cf <_IO_stdin_used+0xcf>
    36f7:	4c 8d 05 d5 79 00 00 	lea    0x79d5(%rip),%r8        # b0d3 <_IO_stdin_used+0xd3>
    36fe:	48 83 ec 70          	sub    $0x70,%rsp
    3702:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3709:	00 00 
    370b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3710:	31 c0                	xor    %eax,%eax
    3712:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3717:	e8 84 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    371c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3721:	e8 0a 0d 00 00       	call   4430 <fwp_trap>

0000000000003726 <fwp_task_dispose.cold>:
    3726:	e8 95 fc ff ff       	call   33c0 <abort@plt>

000000000000372b <fwp_main_thread.cold>:
    372b:	e8 90 fc ff ff       	call   33c0 <abort@plt>

0000000000003730 <main.cold>:
    3730:	e8 8b fc ff ff       	call   33c0 <abort@plt>
    3735:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    373c:	00 00 00 
    373f:	90                   	nop

0000000000003740 <main>:
    3740:	f3 0f 1e fa          	endbr64
    3744:	55                   	push   %rbp
    3745:	53                   	push   %rbx
    3746:	48 83 ec 68          	sub    $0x68,%rsp
    374a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3751:	00 00 
    3753:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3758:	48 8d 05 c1 9b 00 00 	lea    0x9bc1(%rip),%rax        # d320 <fwp_fn_table>
    375f:	48 89 05 12 5d 06 00 	mov    %rax,0x65d12(%rip)        # 69478 <fwp_fns>
    3766:	48 8b 05 b3 b8 00 00 	mov    0xb8b3(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    376d:	48 89 05 0c 5d 06 00 	mov    %rax,0x65d0c(%rip)        # 69480 <fwp_prog_out>
    3774:	e8 27 0e 00 00       	call   45a0 <fwp_now_ns>
    3779:	48 8d 3d 28 7b 00 00 	lea    0x7b28(%rip),%rdi        # b2a8 <_IO_stdin_used+0x2a8>
    3780:	e8 0b fc ff ff       	call   3390 <getenv@plt>
    3785:	48 85 c0             	test   %rax,%rax
    3788:	74 0c                	je     3796 <main+0x56>
    378a:	48 89 c3             	mov    %rax,%rbx
    378d:	80 38 00             	cmpb   $0x0,(%rax)
    3790:	0f 85 09 01 00 00    	jne    389f <main+0x15f>
    3796:	31 ff                	xor    %edi,%edi
    3798:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    379d:	e8 6e fc ff ff       	call   3410 <clock_gettime@plt>
    37a2:	85 c0                	test   %eax,%eax
    37a4:	0f 85 28 01 00 00    	jne    38d2 <main+0x192>
    37aa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37af:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37b4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37b9:	48 89 cb             	mov    %rcx,%rbx
    37bc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37c0:	48 01 c8             	add    %rcx,%rax
    37c3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ca:	00 00 80 
    37cd:	48 11 da             	adc    %rbx,%rdx
    37d0:	31 db                	xor    %ebx,%ebx
    37d2:	48 01 c8             	add    %rcx,%rax
    37d5:	48 11 da             	adc    %rbx,%rdx
    37d8:	48 85 d2             	test   %rdx,%rdx
    37db:	0f 85 38 01 00 00    	jne    3919 <main+0x1d9>
    37e1:	48 8b 3d 38 b8 00 00 	mov    0xb838(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    37e8:	31 d2                	xor    %edx,%edx
    37ea:	31 f6                	xor    %esi,%esi
    37ec:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37f1:	e8 da fd ff ff       	call   35d0 <setvbuf@plt>
    37f6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37fb:	be 01 00 00 00       	mov    $0x1,%esi
    3800:	e8 2b fd ff ff       	call   3530 <signal@plt>
    3805:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    380a:	e8 d1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    380f:	85 c0                	test   %eax,%eax
    3811:	0f 85 f6 00 00 00    	jne    390d <main+0x1cd>
    3817:	be 00 00 00 40       	mov    $0x40000000,%esi
    381c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3821:	e8 aa fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3826:	85 c0                	test   %eax,%eax
    3828:	0f 85 c1 00 00 00    	jne    38ef <main+0x1af>
    382e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3833:	31 c9                	xor    %ecx,%ecx
    3835:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    383a:	48 8d 15 bf 5f 00 00 	lea    0x5fbf(%rip),%rdx        # 9800 <fwp_main_thread>
    3841:	e8 9a fd ff ff       	call   35e0 <pthread_create@plt>
    3846:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    384b:	89 c5                	mov    %eax,%ebp
    384d:	e8 de fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3852:	85 c0                	test   %eax,%eax
    3854:	0f 85 d6 fe ff ff    	jne    3730 <main.cold>
    385a:	85 ed                	test   %ebp,%ebp
    385c:	0f 85 81 00 00 00    	jne    38e3 <main+0x1a3>
    3862:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3867:	31 f6                	xor    %esi,%esi
    3869:	e8 22 fe ff ff       	call   3690 <pthread_join@plt>
    386e:	85 c0                	test   %eax,%eax
    3870:	0f 85 ba fe ff ff    	jne    3730 <main.cold>
    3876:	48 8b 3d a3 b7 00 00 	mov    0xb7a3(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    387d:	e8 1e fd ff ff       	call   35a0 <fflush@plt>
    3882:	8b 05 f8 b7 01 00    	mov    0x1b7f8(%rip),%eax        # 1f080 <fwp_exit_code>
    3888:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    388d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3894:	00 00 
    3896:	75 46                	jne    38de <main+0x19e>
    3898:	48 83 c4 68          	add    $0x68,%rsp
    389c:	5b                   	pop    %rbx
    389d:	5d                   	pop    %rbp
    389e:	c3                   	ret
    389f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38a4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a9:	48 89 c7             	mov    %rax,%rdi
    38ac:	e8 4f fc ff ff       	call   3500 <strtoull@plt>
    38b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38b6:	80 38 00             	cmpb   $0x0,(%rax)
    38b9:	0f 85 d7 fe ff ff    	jne    3796 <main+0x56>
    38bf:	0f b6 03             	movzbl (%rbx),%eax
    38c2:	83 e8 2b             	sub    $0x2b,%eax
    38c5:	a8 fd                	test   $0xfd,%al
    38c7:	0f 84 c9 fe ff ff    	je     3796 <main+0x56>
    38cd:	e9 0f ff ff ff       	jmp    37e1 <main+0xa1>
    38d2:	48 8d 3d d8 79 00 00 	lea    0x79d8(%rip),%rdi        # b2b1 <_IO_stdin_used+0x2b1>
    38d9:	e8 52 0b 00 00       	call   4430 <fwp_trap>
    38de:	e8 6d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    38e3:	48 8d 3d a6 82 00 00 	lea    0x82a6(%rip),%rdi        # bb90 <_IO_stdin_used+0xb90>
    38ea:	e8 41 0b 00 00       	call   4430 <fwp_trap>
    38ef:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38f4:	e8 37 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    38f9:	85 c0                	test   %eax,%eax
    38fb:	0f 85 2f fe ff ff    	jne    3730 <main.cold>
    3901:	48 8d 3d 60 82 00 00 	lea    0x8260(%rip),%rdi        # bb68 <_IO_stdin_used+0xb68>
    3908:	e8 23 0b 00 00       	call   4430 <fwp_trap>
    390d:	48 8d 3d 24 82 00 00 	lea    0x8224(%rip),%rdi        # bb38 <_IO_stdin_used+0xb38>
    3914:	e8 17 0b 00 00       	call   4430 <fwp_trap>
    3919:	48 8d 3d f0 81 00 00 	lea    0x81f0(%rip),%rdi        # bb10 <_IO_stdin_used+0xb10>
    3920:	e8 0b 0b 00 00       	call   4430 <fwp_trap>
    3925:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    392c:	00 00 00 
    392f:	90                   	nop

0000000000003930 <_start>:
    3930:	f3 0f 1e fa          	endbr64
    3934:	31 ed                	xor    %ebp,%ebp
    3936:	49 89 d1             	mov    %rdx,%r9
    3939:	5e                   	pop    %rsi
    393a:	48 89 e2             	mov    %rsp,%rdx
    393d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3941:	50                   	push   %rax
    3942:	54                   	push   %rsp
    3943:	45 31 c0             	xor    %r8d,%r8d
    3946:	31 c9                	xor    %ecx,%ecx
    3948:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3740 <main>
    394f:	ff 15 7b b6 00 00    	call   *0xb67b(%rip)        # efd0 <__libc_start_main@GLIBC_2.34>
    3955:	f4                   	hlt
    3956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    395d:	00 00 00 

0000000000003960 <deregister_tm_clones>:
    3960:	48 8d 3d b1 b6 00 00 	lea    0xb6b1(%rip),%rdi        # f018 <__TMC_END__>
    3967:	48 8d 05 aa b6 00 00 	lea    0xb6aa(%rip),%rax        # f018 <__TMC_END__>
    396e:	48 39 f8             	cmp    %rdi,%rax
    3971:	74 15                	je     3988 <deregister_tm_clones+0x28>
    3973:	48 8b 05 5e b6 00 00 	mov    0xb65e(%rip),%rax        # efd8 <_ITM_deregisterTMCloneTable>
    397a:	48 85 c0             	test   %rax,%rax
    397d:	74 09                	je     3988 <deregister_tm_clones+0x28>
    397f:	ff e0                	jmp    *%rax
    3981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3988:	c3                   	ret
    3989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003990 <register_tm_clones>:
    3990:	48 8d 3d 81 b6 00 00 	lea    0xb681(%rip),%rdi        # f018 <__TMC_END__>
    3997:	48 8d 35 7a b6 00 00 	lea    0xb67a(%rip),%rsi        # f018 <__TMC_END__>
    399e:	48 29 fe             	sub    %rdi,%rsi
    39a1:	48 89 f0             	mov    %rsi,%rax
    39a4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39a8:	48 c1 f8 03          	sar    $0x3,%rax
    39ac:	48 01 c6             	add    %rax,%rsi
    39af:	48 d1 fe             	sar    $1,%rsi
    39b2:	74 14                	je     39c8 <register_tm_clones+0x38>
    39b4:	48 8b 05 2d b6 00 00 	mov    0xb62d(%rip),%rax        # efe8 <_ITM_registerTMCloneTable>
    39bb:	48 85 c0             	test   %rax,%rax
    39be:	74 08                	je     39c8 <register_tm_clones+0x38>
    39c0:	ff e0                	jmp    *%rax
    39c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39c8:	c3                   	ret
    39c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039d0 <__do_global_dtors_aux>:
    39d0:	f3 0f 1e fa          	endbr64
    39d4:	80 3d 6d b6 00 00 00 	cmpb   $0x0,0xb66d(%rip)        # f048 <completed.0>
    39db:	75 2b                	jne    3a08 <__do_global_dtors_aux+0x38>
    39dd:	55                   	push   %rbp
    39de:	48 83 3d 0a b6 00 00 	cmpq   $0x0,0xb60a(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    39e5:	00 
    39e6:	48 89 e5             	mov    %rsp,%rbp
    39e9:	74 0c                	je     39f7 <__do_global_dtors_aux+0x27>
    39eb:	48 8b 3d 16 b6 00 00 	mov    0xb616(%rip),%rdi        # f008 <__dso_handle>
    39f2:	e8 89 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    39f7:	e8 64 ff ff ff       	call   3960 <deregister_tm_clones>
    39fc:	c6 05 45 b6 00 00 01 	movb   $0x1,0xb645(%rip)        # f048 <completed.0>
    3a03:	5d                   	pop    %rbp
    3a04:	c3                   	ret
    3a05:	0f 1f 00             	nopl   (%rax)
    3a08:	c3                   	ret
    3a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a10 <frame_dummy>:
    3a10:	f3 0f 1e fa          	endbr64
    3a14:	e9 77 ff ff ff       	jmp    3990 <register_tm_clones>
    3a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a20 <fwp_fmt_u128>:
    3a20:	41 57                	push   %r15
    3a22:	41 56                	push   %r14
    3a24:	41 55                	push   %r13
    3a26:	41 54                	push   %r12
    3a28:	55                   	push   %rbp
    3a29:	53                   	push   %rbx
    3a2a:	48 83 ec 68          	sub    $0x68,%rsp
    3a2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a35:	00 00 
    3a37:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a3c:	48 89 f0             	mov    %rsi,%rax
    3a3f:	48 09 d0             	or     %rdx,%rax
    3a42:	75 7c                	jne    3ac0 <fwp_fmt_u128+0xa0>
    3a44:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a49:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a4e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a53:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a56:	48 89 f8             	mov    %rdi,%rax
    3a59:	49 01 d4             	add    %rdx,%r12
    3a5c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a61:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a68:	00 00 
    3a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a71:	00 00 00 00 
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 
    3a80:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a85:	48 83 c0 01          	add    $0x1,%rax
    3a89:	49 83 ec 01          	sub    $0x1,%r12
    3a8d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a90:	48 39 c8             	cmp    %rcx,%rax
    3a93:	75 eb                	jne    3a80 <fwp_fmt_u128+0x60>
    3a95:	48 63 ed             	movslq %ebp,%rbp
    3a98:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a9c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3aa1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3aa8:	00 00 
    3aaa:	0f 85 ef 00 00 00    	jne    3b9f <fwp_fmt_u128+0x17f>
    3ab0:	48 83 c4 68          	add    $0x68,%rsp
    3ab4:	5b                   	pop    %rbx
    3ab5:	5d                   	pop    %rbp
    3ab6:	41 5c                	pop    %r12
    3ab8:	41 5d                	pop    %r13
    3aba:	41 5e                	pop    %r14
    3abc:	41 5f                	pop    %r15
    3abe:	c3                   	ret
    3abf:	90                   	nop
    3ac0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ac5:	49 89 f2             	mov    %rsi,%r10
    3ac8:	49 89 d3             	mov    %rdx,%r11
    3acb:	31 ed                	xor    %ebp,%ebp
    3acd:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ad2:	4c 89 e3             	mov    %r12,%rbx
    3ad5:	45 31 f6             	xor    %r14d,%r14d
    3ad8:	49 89 f9             	mov    %rdi,%r9
    3adb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ae2:	cc cc cc 
    3ae5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3aeb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3af2:	cc cc cc 
    3af5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b00:	4c 89 d6             	mov    %r10,%rsi
    3b03:	4c 89 df             	mov    %r11,%rdi
    3b06:	4c 01 de             	add    %r11,%rsi
    3b09:	48 83 d6 00          	adc    $0x0,%rsi
    3b0d:	45 31 ed             	xor    %r13d,%r13d
    3b10:	48 89 f0             	mov    %rsi,%rax
    3b13:	48 f7 e1             	mul    %rcx
    3b16:	48 89 d0             	mov    %rdx,%rax
    3b19:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b1d:	48 c1 e8 02          	shr    $0x2,%rax
    3b21:	48 01 c2             	add    %rax,%rdx
    3b24:	48 8b 04 24          	mov    (%rsp),%rax
    3b28:	48 29 d6             	sub    %rdx,%rsi
    3b2b:	49 89 f4             	mov    %rsi,%r12
    3b2e:	4c 89 d6             	mov    %r10,%rsi
    3b31:	4c 29 e6             	sub    %r12,%rsi
    3b34:	4c 19 ef             	sbb    %r13,%rdi
    3b37:	48 0f af c6          	imul   %rsi,%rax
    3b3b:	49 89 f8             	mov    %rdi,%r8
    3b3e:	4c 0f af c1          	imul   %rcx,%r8
    3b42:	49 01 c0             	add    %rax,%r8
    3b45:	48 89 f0             	mov    %rsi,%rax
    3b48:	48 f7 e1             	mul    %rcx
    3b4b:	48 89 c6             	mov    %rax,%rsi
    3b4e:	83 e0 01             	and    $0x1,%eax
    3b51:	49 01 d0             	add    %rdx,%r8
    3b54:	49 f7 e7             	mul    %r15
    3b57:	4c 89 c7             	mov    %r8,%rdi
    3b5a:	4c 89 d2             	mov    %r10,%rdx
    3b5d:	4c 01 e0             	add    %r12,%rax
    3b60:	48 d1 ef             	shr    $1,%rdi
    3b63:	83 c5 01             	add    $0x1,%ebp
    3b66:	48 83 c3 01          	add    $0x1,%rbx
    3b6a:	83 c0 30             	add    $0x30,%eax
    3b6d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b72:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b75:	4c 89 d8             	mov    %r11,%rax
    3b78:	49 89 fb             	mov    %rdi,%r11
    3b7b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b80:	48 39 d7             	cmp    %rdx,%rdi
    3b83:	4c 89 f7             	mov    %r14,%rdi
    3b86:	49 89 f2             	mov    %rsi,%r10
    3b89:	48 19 c7             	sbb    %rax,%rdi
    3b8c:	0f 82 6e ff ff ff    	jb     3b00 <fwp_fmt_u128+0xe0>
    3b92:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b97:	4c 89 cf             	mov    %r9,%rdi
    3b9a:	e9 b4 fe ff ff       	jmp    3a53 <fwp_fmt_u128+0x33>
    3b9f:	e8 ac f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3ba4:	90                   	nop
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_range_release>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	53                   	push   %rbx
    3bb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bb9:	48 89 fb             	mov    %rdi,%rbx
    3bbc:	48 85 c0             	test   %rax,%rax
    3bbf:	74 06                	je     3bc7 <fwp_range_release+0x17>
    3bc1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3bc5:	ff d0                	call   *%rax
    3bc7:	48 8b 3b             	mov    (%rbx),%rdi
    3bca:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bce:	5b                   	pop    %rbx
    3bcf:	ff e0                	jmp    *%rax
    3bd1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 

0000000000003be0 <ad_raw_record>:
    3be0:	89 c8                	mov    %ecx,%eax
    3be2:	4c 8d 05 b7 b5 04 00 	lea    0x4b5b7(%rip),%r8        # 4f1a0 <ad_raw_live>
    3be9:	49 89 f1             	mov    %rsi,%r9
    3bec:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bf3:	00 
    3bf4:	48 89 d6             	mov    %rdx,%rsi
    3bf7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bfa:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bfe:	48 8d 0d 5b b5 04 00 	lea    0x4b55b(%rip),%rcx        # 4f160 <ad_raw_requests>
    3c05:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c0a:	48 8d 0d 2f b5 04 00 	lea    0x4b52f(%rip),%rcx        # 4f140 <ad_raw_bytes>
    3c11:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c15:	48 01 f2             	add    %rsi,%rdx
    3c18:	48 8d 0d 61 b5 04 00 	lea    0x4b561(%rip),%rcx        # 4f180 <ad_raw_peak>
    3c1f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c23:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c27:	4c 89 0f             	mov    %r9,(%rdi)
    3c2a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c2e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c32:	73 04                	jae    3c38 <ad_raw_record+0x58>
    3c34:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c38:	66 0f 6f 05 70 b5 04 	movdqa 0x4b570(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    3c3f:	00 
    3c40:	66 0f d4 05 58 b5 04 	paddq  0x4b558(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    3c47:	00 
    3c48:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c4c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c51:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c55:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c5a:	48 39 05 bf b4 04 00 	cmp    %rax,0x4b4bf(%rip)        # 4f120 <ad_raw_total_peak>
    3c61:	73 08                	jae    3c6b <ad_raw_record+0x8b>
    3c63:	66 0f d6 05 b5 b4 04 	movq   %xmm0,0x4b4b5(%rip)        # 4f120 <ad_raw_total_peak>
    3c6a:	00 
    3c6b:	c3                   	ret
    3c6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c70 <fwp_tape_unlink_scope>:
    3c70:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c74:	48 85 d2             	test   %rdx,%rdx
    3c77:	74 3e                	je     3cb7 <fwp_tape_unlink_scope+0x47>
    3c79:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c7c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c80:	85 c9                	test   %ecx,%ecx
    3c82:	78 3c                	js     3cc0 <fwp_tape_unlink_scope+0x50>
    3c84:	48 63 d1             	movslq %ecx,%rdx
    3c87:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c8b:	48 03 15 5e b4 01 00 	add    0x1b45e(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c92:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c95:	85 c0                	test   %eax,%eax
    3c97:	78 0e                	js     3ca7 <fwp_tape_unlink_scope+0x37>
    3c99:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c9d:	48 03 05 4c b4 01 00 	add    0x1b44c(%rip),%rax        # 1f0f0 <fwp_tapes>
    3ca4:	89 48 58             	mov    %ecx,0x58(%rax)
    3ca7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cae:	00 
    3caf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cb6:	ff 
    3cb7:	c3                   	ret
    3cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cbf:	00 
    3cc0:	89 02                	mov    %eax,(%rdx)
    3cc2:	eb d1                	jmp    3c95 <fwp_tape_unlink_scope+0x25>
    3cc4:	90                   	nop
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_args173>:
    3cd0:	f3 0f 1e fa          	endbr64
    3cd4:	c3                   	ret
    3cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cdc:	00 00 00 00 

0000000000003ce0 <fwp_flush>:
    3ce0:	48 8b 3d 99 57 06 00 	mov    0x65799(%rip),%rdi        # 69480 <fwp_prog_out>
    3ce7:	48 85 ff             	test   %rdi,%rdi
    3cea:	74 1c                	je     3d08 <fwp_flush+0x28>
    3cec:	48 83 ec 08          	sub    $0x8,%rsp
    3cf0:	e8 ab f8 ff ff       	call   35a0 <fflush@plt>
    3cf5:	48 8b 3d 24 b3 00 00 	mov    0xb324(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cfc:	48 83 c4 08          	add    $0x8,%rsp
    3d00:	e9 9b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d05:	0f 1f 00             	nopl   (%rax)
    3d08:	48 8b 3d 11 b3 00 00 	mov    0xb311(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3d0f:	e9 8c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d14:	90                   	nop
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 

0000000000003d20 <fwp_segv>:
    3d20:	f3 0f 1e fa          	endbr64
    3d24:	48 83 ec 28          	sub    $0x28,%rsp
    3d28:	48 8b 05 d1 3a 06 00 	mov    0x63ad1(%rip),%rax        # 67800 <fwp_cur>
    3d2f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d33:	41 89 f8             	mov    %edi,%r8d
    3d36:	48 85 c0             	test   %rax,%rax
    3d39:	74 6d                	je     3da8 <fwp_segv+0x88>
    3d3b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d3f:	48 85 d2             	test   %rdx,%rdx
    3d42:	74 64                	je     3da8 <fwp_segv+0x88>
    3d44:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d48:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d52:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d57:	e8 c4 f8 ff ff       	call   3620 <sysconf@plt>
    3d5c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d61:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d66:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d6b:	48 01 d0             	add    %rdx,%rax
    3d6e:	48 39 c1             	cmp    %rax,%rcx
    3d71:	b8 00 00 00 00       	mov    $0x0,%eax
    3d76:	40 0f 92 c6          	setb   %sil
    3d7a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d81:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d85:	31 c0                	xor    %eax,%eax
    3d87:	48 39 d1             	cmp    %rdx,%rcx
    3d8a:	0f 93 c0             	setae  %al
    3d8d:	21 f0                	and    %esi,%eax
    3d8f:	85 c0                	test   %eax,%eax
    3d91:	75 4a                	jne    3ddd <fwp_segv+0xbd>
    3d93:	31 f6                	xor    %esi,%esi
    3d95:	44 89 c7             	mov    %r8d,%edi
    3d98:	48 83 c4 28          	add    $0x28,%rsp
    3d9c:	e9 8f f7 ff ff       	jmp    3530 <signal@plt>
    3da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3da8:	48 8b 05 19 34 06 00 	mov    0x63419(%rip),%rax        # 671c8 <fwp_main_stack_top>
    3daf:	48 85 c0             	test   %rax,%rax
    3db2:	74 df                	je     3d93 <fwp_segv+0x73>
    3db4:	48 2b 05 05 34 06 00 	sub    0x63405(%rip),%rax        # 671c0 <fwp_main_stack_size>
    3dbb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3dc2:	48 39 d1             	cmp    %rdx,%rcx
    3dc5:	0f 93 c2             	setae  %dl
    3dc8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dce:	48 39 c1             	cmp    %rax,%rcx
    3dd1:	0f 92 c0             	setb   %al
    3dd4:	0f b6 c0             	movzbl %al,%eax
    3dd7:	21 d0                	and    %edx,%eax
    3dd9:	85 c0                	test   %eax,%eax
    3ddb:	74 b6                	je     3d93 <fwp_segv+0x73>
    3ddd:	e8 fe fe ff ff       	call   3ce0 <fwp_flush>
    3de2:	bf 02 00 00 00       	mov    $0x2,%edi
    3de7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dec:	48 8d 35 7d 7e 00 00 	lea    0x7e7d(%rip),%rsi        # bc70 <msg.4>
    3df3:	e8 28 f6 ff ff       	call   3420 <write@plt>
    3df8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dfd:	e8 ce f5 ff ff       	call   33d0 <_exit@plt>
    3e02:	0f 1f 00             	nopl   (%rax)
    3e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e0c:	00 00 00 00 

0000000000003e10 <fwp_heap_oom>:
    3e10:	50                   	push   %rax
    3e11:	58                   	pop    %rax
    3e12:	ba 13 00 00 00       	mov    $0x13,%edx
    3e17:	be 01 00 00 00       	mov    $0x1,%esi
    3e1c:	48 8d 3d e5 71 00 00 	lea    0x71e5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3e23:	48 83 ec 08          	sub    $0x8,%rsp
    3e27:	48 8b 0d 12 b2 00 00 	mov    0xb212(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3e2e:	e8 2d f8 ff ff       	call   3660 <fwrite@plt>
    3e33:	31 ff                	xor    %edi,%edi
    3e35:	e8 66 f7 ff ff       	call   35a0 <fflush@plt>
    3e3a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e3f:	e8 3c f8 ff ff       	call   3680 <_Exit@plt>
    3e44:	90                   	nop
    3e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e4c:	00 00 00 00 

0000000000003e50 <fwp_heap_chunks>:
    3e50:	41 54                	push   %r12
    3e52:	55                   	push   %rbp
    3e53:	53                   	push   %rbx
    3e54:	48 83 ff 01          	cmp    $0x1,%rdi
    3e58:	0f 84 62 01 00 00    	je     3fc0 <fwp_heap_chunks+0x170>
    3e5e:	48 8b 05 ab 4d 06 00 	mov    0x64dab(%rip),%rax        # 68c10 <fwp_heap+0x13f0>
    3e65:	4c 8d 05 a4 4d 06 00 	lea    0x64da4(%rip),%r8        # 68c10 <fwp_heap+0x13f0>
    3e6c:	48 8b 1d 85 4d 06 00 	mov    0x64d85(%rip),%rbx        # 68bf8 <fwp_heap+0x13d8>
    3e73:	48 39 d8             	cmp    %rbx,%rax
    3e76:	0f 83 57 01 00 00    	jae    3fd3 <fwp_heap_chunks+0x183>
    3e7c:	48 8b 0d 95 4d 06 00 	mov    0x64d95(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    3e83:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e87:	31 f6                	xor    %esi,%esi
    3e89:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e8d:	eb 1e                	jmp    3ead <fwp_heap_chunks+0x5d>
    3e8f:	90                   	nop
    3e90:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e94:	48 39 cf             	cmp    %rcx,%rdi
    3e97:	0f 84 03 01 00 00    	je     3fa0 <fwp_heap_chunks+0x150>
    3e9d:	48 83 c0 01          	add    $0x1,%rax
    3ea1:	48 89 ce             	mov    %rcx,%rsi
    3ea4:	48 83 c2 28          	add    $0x28,%rdx
    3ea8:	48 39 c3             	cmp    %rax,%rbx
    3eab:	74 14                	je     3ec1 <fwp_heap_chunks+0x71>
    3ead:	80 3a 00             	cmpb   $0x0,(%rdx)
    3eb0:	74 de                	je     3e90 <fwp_heap_chunks+0x40>
    3eb2:	48 83 c0 01          	add    $0x1,%rax
    3eb6:	31 f6                	xor    %esi,%esi
    3eb8:	48 83 c2 28          	add    $0x28,%rdx
    3ebc:	48 39 c3             	cmp    %rax,%rbx
    3ebf:	75 ec                	jne    3ead <fwp_heap_chunks+0x5d>
    3ec1:	48 29 f3             	sub    %rsi,%rbx
    3ec4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ec8:	48 8b 3d 31 4d 06 00 	mov    0x64d31(%rip),%rdi        # 68c00 <fwp_heap+0x13e0>
    3ecf:	48 29 35 7a 4d 06 00 	sub    %rsi,0x64d7a(%rip)        # 68c50 <fwp_heap+0x1430>
    3ed6:	48 39 ef             	cmp    %rbp,%rdi
    3ed9:	0f 83 96 00 00 00    	jae    3f75 <fwp_heap_chunks+0x125>
    3edf:	48 8b 05 0a 4d 06 00 	mov    0x64d0a(%rip),%rax        # 68bf0 <fwp_heap+0x13d0>
    3ee6:	48 39 e8             	cmp    %rbp,%rax
    3ee9:	0f 82 eb 00 00 00    	jb     3fda <fwp_heap_chunks+0x18a>
    3eef:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ef3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef8:	49 39 c4             	cmp    %rax,%r12
    3efb:	4c 0f 47 e0          	cmova  %rax,%r12
    3eff:	4c 89 e6             	mov    %r12,%rsi
    3f02:	48 29 fe             	sub    %rdi,%rsi
    3f05:	48 c1 e7 10          	shl    $0x10,%rdi
    3f09:	48 03 3d c0 4c 06 00 	add    0x64cc0(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    3f10:	48 c1 e6 10          	shl    $0x10,%rsi
    3f14:	e8 e7 f6 ff ff       	call   3600 <mprotect@plt>
    3f19:	85 c0                	test   %eax,%eax
    3f1b:	0f 85 b9 00 00 00    	jne    3fda <fwp_heap_chunks+0x18a>
    3f21:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f26:	e8 f5 f6 ff ff       	call   3620 <sysconf@plt>
    3f2b:	48 8b 35 ce 4c 06 00 	mov    0x64cce(%rip),%rsi        # 68c00 <fwp_heap+0x13e0>
    3f32:	48 89 c1             	mov    %rax,%rcx
    3f35:	48 8b 05 dc 4c 06 00 	mov    0x64cdc(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    3f3c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f40:	48 89 ca             	mov    %rcx,%rdx
    3f43:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f47:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f4b:	48 f7 da             	neg    %rdx
    3f4e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f53:	48 21 d7             	and    %rdx,%rdi
    3f56:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f5a:	48 21 d6             	and    %rdx,%rsi
    3f5d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f62:	48 29 fe             	sub    %rdi,%rsi
    3f65:	e8 96 f6 ff ff       	call   3600 <mprotect@plt>
    3f6a:	85 c0                	test   %eax,%eax
    3f6c:	75 6c                	jne    3fda <fwp_heap_chunks+0x18a>
    3f6e:	4c 89 25 8b 4c 06 00 	mov    %r12,0x64c8b(%rip)        # 68c00 <fwp_heap+0x13e0>
    3f75:	48 89 ef             	mov    %rbp,%rdi
    3f78:	48 89 2d 79 4c 06 00 	mov    %rbp,0x64c79(%rip)        # 68bf8 <fwp_heap+0x13d8>
    3f7f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f83:	48 39 3d 5e 4c 06 00 	cmp    %rdi,0x64c5e(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f8a:	73 07                	jae    3f93 <fwp_heap_chunks+0x143>
    3f8c:	48 89 3d 55 4c 06 00 	mov    %rdi,0x64c55(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f93:	48 89 d8             	mov    %rbx,%rax
    3f96:	5b                   	pop    %rbx
    3f97:	5d                   	pop    %rbp
    3f98:	41 5c                	pop    %r12
    3f9a:	c3                   	ret
    3f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fa0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fa4:	48 29 f0             	sub    %rsi,%rax
    3fa7:	48 89 c3             	mov    %rax,%rbx
    3faa:	49 89 10             	mov    %rdx,(%r8)
    3fad:	48 89 d8             	mov    %rbx,%rax
    3fb0:	48 29 3d 99 4c 06 00 	sub    %rdi,0x64c99(%rip)        # 68c50 <fwp_heap+0x1430>
    3fb7:	5b                   	pop    %rbx
    3fb8:	5d                   	pop    %rbp
    3fb9:	41 5c                	pop    %r12
    3fbb:	c3                   	ret
    3fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fc0:	48 8b 05 41 4c 06 00 	mov    0x64c41(%rip),%rax        # 68c08 <fwp_heap+0x13e8>
    3fc7:	4c 8d 05 3a 4c 06 00 	lea    0x64c3a(%rip),%r8        # 68c08 <fwp_heap+0x13e8>
    3fce:	e9 99 fe ff ff       	jmp    3e6c <fwp_heap_chunks+0x1c>
    3fd3:	31 f6                	xor    %esi,%esi
    3fd5:	e9 ea fe ff ff       	jmp    3ec4 <fwp_heap_chunks+0x74>
    3fda:	e8 31 fe ff ff       	call   3e10 <fwp_heap_oom>
    3fdf:	90                   	nop

0000000000003fe0 <ad_raw_fail>:
    3fe0:	50                   	push   %rax
    3fe1:	58                   	pop    %rax
    3fe2:	48 8d 15 d7 76 00 00 	lea    0x76d7(%rip),%rdx        # b6c0 <_IO_stdin_used+0x6c0>
    3fe9:	be 02 00 00 00       	mov    $0x2,%esi
    3fee:	31 c0                	xor    %eax,%eax
    3ff0:	48 83 ec 08          	sub    $0x8,%rsp
    3ff4:	48 89 f9             	mov    %rdi,%rcx
    3ff7:	48 8b 3d 42 b0 00 00 	mov    0xb042(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ffe:	e8 6d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4003:	bf e8 00 00 00       	mov    $0xe8,%edi
    4008:	e8 43 f6 ff ff       	call   3650 <exit@plt>
    400d:	0f 1f 00             	nopl   (%rax)

0000000000004010 <buf_grow>:
    4010:	48 83 ec 18          	sub    $0x18,%rsp
    4014:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4018:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    401c:	74 7e                	je     409c <buf_grow+0x8c>
    401e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4025:	48 29 c2             	sub    %rax,%rdx
    4028:	48 39 f2             	cmp    %rsi,%rdx
    402b:	72 6f                	jb     409c <buf_grow+0x8c>
    402d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4032:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4036:	48 89 f9             	mov    %rdi,%rcx
    4039:	48 39 d0             	cmp    %rdx,%rax
    403c:	73 48                	jae    4086 <buf_grow+0x76>
    403e:	48 85 c0             	test   %rax,%rax
    4041:	75 15                	jne    4058 <buf_grow+0x48>
    4043:	48 83 fa 40          	cmp    $0x40,%rdx
    4047:	76 4c                	jbe    4095 <buf_grow+0x85>
    4049:	b8 40 00 00 00       	mov    $0x40,%eax
    404e:	eb 08                	jmp    4058 <buf_grow+0x48>
    4050:	48 01 c0             	add    %rax,%rax
    4053:	48 39 d0             	cmp    %rdx,%rax
    4056:	73 38                	jae    4090 <buf_grow+0x80>
    4058:	48 85 c0             	test   %rax,%rax
    405b:	79 f3                	jns    4050 <buf_grow+0x40>
    405d:	48 8b 39             	mov    (%rcx),%rdi
    4060:	48 89 d6             	mov    %rdx,%rsi
    4063:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4068:	48 89 14 24          	mov    %rdx,(%rsp)
    406c:	e8 3f f5 ff ff       	call   35b0 <realloc@plt>
    4071:	48 8b 14 24          	mov    (%rsp),%rdx
    4075:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    407a:	48 85 c0             	test   %rax,%rax
    407d:	74 1d                	je     409c <buf_grow+0x8c>
    407f:	48 89 01             	mov    %rax,(%rcx)
    4082:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4086:	48 83 c4 18          	add    $0x18,%rsp
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 89 c2             	mov    %rax,%rdx
    4093:	eb c8                	jmp    405d <buf_grow+0x4d>
    4095:	ba 40 00 00 00       	mov    $0x40,%edx
    409a:	eb c1                	jmp    405d <buf_grow+0x4d>
    409c:	48 8b 0d 9d af 00 00 	mov    0xaf9d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    40a3:	ba 13 00 00 00       	mov    $0x13,%edx
    40a8:	be 01 00 00 00       	mov    $0x1,%esi
    40ad:	48 8d 3d 54 6f 00 00 	lea    0x6f54(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    40b4:	e8 a7 f5 ff ff       	call   3660 <fwrite@plt>
    40b9:	31 ff                	xor    %edi,%edi
    40bb:	e8 e0 f4 ff ff       	call   35a0 <fflush@plt>
    40c0:	bf 66 00 00 00       	mov    $0x66,%edi
    40c5:	e8 b6 f5 ff ff       	call   3680 <_Exit@plt>
    40ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040d0 <buf_put>:
    40d0:	41 54                	push   %r12
    40d2:	49 89 f4             	mov    %rsi,%r12
    40d5:	48 89 d6             	mov    %rdx,%rsi
    40d8:	55                   	push   %rbp
    40d9:	48 89 fd             	mov    %rdi,%rbp
    40dc:	53                   	push   %rbx
    40dd:	48 89 d3             	mov    %rdx,%rbx
    40e0:	e8 2b ff ff ff       	call   4010 <buf_grow>
    40e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40e9:	48 89 da             	mov    %rbx,%rdx
    40ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40f0:	4c 89 e6             	mov    %r12,%rsi
    40f3:	e8 88 f4 ff ff       	call   3580 <memcpy@plt>
    40f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4100:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4104:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4108:	5b                   	pop    %rbx
    4109:	5d                   	pop    %rbp
    410a:	41 5c                	pop    %r12
    410c:	c3                   	ret
    410d:	0f 1f 00             	nopl   (%rax)

0000000000004110 <fwp_cancel_tree.part.0>:
    4110:	48 3b 3d e9 36 06 00 	cmp    0x636e9(%rip),%rdi        # 67800 <fwp_cur>
    4117:	53                   	push   %rbx
    4118:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    411c:	74 35                	je     4153 <fwp_cancel_tree.part.0+0x43>
    411e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4122:	75 2f                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    4124:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4128:	75 29                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    412a:	48 8b 05 af 36 06 00 	mov    0x636af(%rip),%rax        # 677e0 <fwp_ready_tail>
    4131:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4135:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    413c:	00 00 00 00 
    4140:	48 85 c0             	test   %rax,%rax
    4143:	74 33                	je     4178 <fwp_cancel_tree.part.0+0x68>
    4145:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    414c:	48 89 3d 8d 36 06 00 	mov    %rdi,0x6368d(%rip)        # 677e0 <fwp_ready_tail>
    4153:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4157:	48 85 db             	test   %rbx,%rbx
    415a:	74 17                	je     4173 <fwp_cancel_tree.part.0+0x63>
    415c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4160:	75 08                	jne    416a <fwp_cancel_tree.part.0+0x5a>
    4162:	48 89 df             	mov    %rbx,%rdi
    4165:	e8 a6 ff ff ff       	call   4110 <fwp_cancel_tree.part.0>
    416a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    416e:	48 85 db             	test   %rbx,%rbx
    4171:	75 e9                	jne    415c <fwp_cancel_tree.part.0+0x4c>
    4173:	5b                   	pop    %rbx
    4174:	c3                   	ret
    4175:	0f 1f 00             	nopl   (%rax)
    4178:	48 89 3d 69 36 06 00 	mov    %rdi,0x63669(%rip)        # 677e8 <fwp_ready_head>
    417f:	eb cb                	jmp    414c <fwp_cancel_tree.part.0+0x3c>
    4181:	0f 1f 40 00          	nopl   0x0(%rax)
    4185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    418c:	00 00 00 00 

0000000000004190 <fwp_finish_float>:
    4190:	53                   	push   %rbx
    4191:	be 2e 00 00 00       	mov    $0x2e,%esi
    4196:	48 89 fb             	mov    %rdi,%rbx
    4199:	e8 d2 f2 ff ff       	call   3470 <strchr@plt>
    419e:	48 85 c0             	test   %rax,%rax
    41a1:	74 05                	je     41a8 <fwp_finish_float+0x18>
    41a3:	5b                   	pop    %rbx
    41a4:	c3                   	ret
    41a5:	0f 1f 00             	nopl   (%rax)
    41a8:	be 65 00 00 00       	mov    $0x65,%esi
    41ad:	48 89 df             	mov    %rbx,%rdi
    41b0:	e8 bb f2 ff ff       	call   3470 <strchr@plt>
    41b5:	48 85 c0             	test   %rax,%rax
    41b8:	75 e9                	jne    41a3 <fwp_finish_float+0x13>
    41ba:	48 8d 35 39 70 00 00 	lea    0x7039(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    41c1:	48 89 df             	mov    %rbx,%rdi
    41c4:	e8 e7 f4 ff ff       	call   36b0 <strstr@plt>
    41c9:	48 85 c0             	test   %rax,%rax
    41cc:	75 d5                	jne    41a3 <fwp_finish_float+0x13>
    41ce:	48 8d 35 47 6e 00 00 	lea    0x6e47(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    41d5:	48 89 df             	mov    %rbx,%rdi
    41d8:	e8 d3 f4 ff ff       	call   36b0 <strstr@plt>
    41dd:	48 85 c0             	test   %rax,%rax
    41e0:	75 c1                	jne    41a3 <fwp_finish_float+0x13>
    41e2:	48 89 df             	mov    %rbx,%rdi
    41e5:	e8 56 f2 ff ff       	call   3440 <strlen@plt>
    41ea:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41ef:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41f3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41f8:	5b                   	pop    %rbx
    41f9:	c3                   	ret
    41fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004200 <ad_raw_report>:
    4200:	f3 0f 1e fa          	endbr64
    4204:	41 57                	push   %r15
    4206:	41 56                	push   %r14
    4208:	41 55                	push   %r13
    420a:	41 54                	push   %r12
    420c:	55                   	push   %rbp
    420d:	53                   	push   %rbx
    420e:	48 83 ec 38          	sub    $0x38,%rsp
    4212:	66 0f 6f 05 96 af 04 	movdqa 0x4af96(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    4219:	00 
    421a:	66 0f d4 05 7e af 04 	paddq  0x4af7e(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    4221:	00 
    4222:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4229:	00 00 
    422b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4230:	31 c0                	xor    %eax,%eax
    4232:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4236:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    423b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    423f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4244:	48 85 ed             	test   %rbp,%rbp
    4247:	0f 85 d2 01 00 00    	jne    441f <ad_raw_report+0x21f>
    424d:	4c 8b 05 a4 ae 01 00 	mov    0x1aea4(%rip),%r8        # 1f0f8 <ad_raw_before_shutdown>
    4254:	45 31 c9             	xor    %r9d,%r9d
    4257:	31 c0                	xor    %eax,%eax
    4259:	31 db                	xor    %ebx,%ebx
    425b:	48 8b 0d be ae 04 00 	mov    0x4aebe(%rip),%rcx        # 4f120 <ad_raw_total_peak>
    4262:	48 8b 3d d7 ad 00 00 	mov    0xadd7(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4269:	49 89 e4             	mov    %rsp,%r12
    426c:	48 8d 15 9d 74 00 00 	lea    0x749d(%rip),%rdx        # b710 <_IO_stdin_used+0x710>
    4273:	be 02 00 00 00       	mov    $0x2,%esi
    4278:	4c 8d 3d 01 af 04 00 	lea    0x4af01(%rip),%r15        # 4f180 <ad_raw_peak>
    427f:	4c 8d 35 ba ae 04 00 	lea    0x4aeba(%rip),%r14        # 4f140 <ad_raw_bytes>
    4286:	e8 e5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    428b:	48 8d 05 99 6d 00 00 	lea    0x6d99(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    4292:	f3 0f 7e 05 76 a9 00 	movq   0xa976(%rip),%xmm0        # ec10 <d0+0x70>
    4299:	00 
    429a:	4c 8d 2d bf ae 04 00 	lea    0x4aebf(%rip),%r13        # 4f160 <ad_raw_requests>
    42a1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42a6:	48 8d 05 8f 6d 00 00 	lea    0x6d8f(%rip),%rax        # b03c <_IO_stdin_used+0x3c>
    42ad:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42b1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42b6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42ba:	f3 0f 7e 05 56 a9 00 	movq   0xa956(%rip),%xmm0        # ec18 <d0+0x78>
    42c1:	00 
    42c2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42c6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42cb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42cf:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42d3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42d8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42dc:	48 85 db             	test   %rbx,%rbx
    42df:	0f 84 0b 01 00 00    	je     43f0 <ad_raw_report+0x1f0>
    42e5:	52                   	push   %rdx
    42e6:	48 8b 3d 53 ad 00 00 	mov    0xad53(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    42ed:	48 8d 0d 2c 6d 00 00 	lea    0x6d2c(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    42f4:	48 8d 15 75 74 00 00 	lea    0x7475(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    42fb:	50                   	push   %rax
    42fc:	be 02 00 00 00       	mov    $0x2,%esi
    4301:	31 c0                	xor    %eax,%eax
    4303:	48 83 c3 01          	add    $0x1,%rbx
    4307:	e8 64 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    430c:	5f                   	pop    %rdi
    430d:	41 58                	pop    %r8
    430f:	48 83 fb 04          	cmp    $0x4,%rbx
    4313:	75 b6                	jne    42cb <ad_raw_report+0xcb>
    4315:	48 8b 0d 24 ad 00 00 	mov    0xad24(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    431c:	ba 13 00 00 00       	mov    $0x13,%edx
    4321:	be 01 00 00 00       	mov    $0x1,%esi
    4326:	48 8d 3d 18 6d 00 00 	lea    0x6d18(%rip),%rdi        # b045 <_IO_stdin_used+0x45>
    432d:	e8 2e f3 ff ff       	call   3660 <fwrite@plt>
    4332:	48 83 3d c6 ad 01 00 	cmpq   $0x0,0x1adc6(%rip)        # 1f100 <ad_raw_checkpoint_count>
    4339:	00 
    433a:	74 75                	je     43b1 <ad_raw_report+0x1b1>
    433c:	4c 8b 05 dd ad 01 00 	mov    0x1addd(%rip),%r8        # 1f120 <ad_raw_checkpoints>
    4343:	4c 8b 0d de ad 01 00 	mov    0x1adde(%rip),%r9        # 1f128 <ad_raw_checkpoints+0x8>
    434a:	48 8d 1d cf ad 01 00 	lea    0x1adcf(%rip),%rbx        # 1f120 <ad_raw_checkpoints>
    4351:	48 8d 0d 14 6d 00 00 	lea    0x6d14(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    4358:	48 8b 05 d1 ad 01 00 	mov    0x1add1(%rip),%rax        # 1f130 <ad_raw_checkpoints+0x10>
    435f:	4c 8d 25 ba 6c 00 00 	lea    0x6cba(%rip),%r12        # b020 <_IO_stdin_used+0x20>
    4366:	eb 1b                	jmp    4383 <ad_raw_report+0x183>
    4368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    436f:	00 
    4370:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4374:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4378:	48 83 c3 18          	add    $0x18,%rbx
    437c:	4c 89 e1             	mov    %r12,%rcx
    437f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4383:	48 83 ec 08          	sub    $0x8,%rsp
    4387:	be 02 00 00 00       	mov    $0x2,%esi
    438c:	48 83 c5 01          	add    $0x1,%rbp
    4390:	48 8b 3d a9 ac 00 00 	mov    0xaca9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4397:	50                   	push   %rax
    4398:	48 8d 15 11 74 00 00 	lea    0x7411(%rip),%rdx        # b7b0 <_IO_stdin_used+0x7b0>
    439f:	31 c0                	xor    %eax,%eax
    43a1:	e8 ca f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43a6:	48 3b 2d 53 ad 01 00 	cmp    0x1ad53(%rip),%rbp        # 1f100 <ad_raw_checkpoint_count>
    43ad:	59                   	pop    %rcx
    43ae:	5e                   	pop    %rsi
    43af:	72 bf                	jb     4370 <ad_raw_report+0x170>
    43b1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43bd:	00 00 
    43bf:	75 6a                	jne    442b <ad_raw_report+0x22b>
    43c1:	48 8b 0d 78 ac 00 00 	mov    0xac78(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    43c8:	48 83 c4 38          	add    $0x38,%rsp
    43cc:	ba 04 00 00 00       	mov    $0x4,%edx
    43d1:	be 01 00 00 00       	mov    $0x1,%esi
    43d6:	5b                   	pop    %rbx
    43d7:	48 8d 3d 7b 6c 00 00 	lea    0x6c7b(%rip),%rdi        # b059 <_IO_stdin_used+0x59>
    43de:	5d                   	pop    %rbp
    43df:	41 5c                	pop    %r12
    43e1:	41 5d                	pop    %r13
    43e3:	41 5e                	pop    %r14
    43e5:	41 5f                	pop    %r15
    43e7:	e9 74 f2 ff ff       	jmp    3660 <fwrite@plt>
    43ec:	0f 1f 40 00          	nopl   0x0(%rax)
    43f0:	52                   	push   %rdx
    43f1:	be 02 00 00 00       	mov    $0x2,%esi
    43f6:	48 8b 3d 43 ac 00 00 	mov    0xac43(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    43fd:	48 8d 15 6c 73 00 00 	lea    0x736c(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    4404:	50                   	push   %rax
    4405:	48 8d 0d 60 6c 00 00 	lea    0x6c60(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    440c:	31 c0                	xor    %eax,%eax
    440e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4413:	e8 58 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4418:	58                   	pop    %rax
    4419:	5a                   	pop    %rdx
    441a:	e9 ac fe ff ff       	jmp    42cb <ad_raw_report+0xcb>
    441f:	48 8d 3d c2 72 00 00 	lea    0x72c2(%rip),%rdi        # b6e8 <_IO_stdin_used+0x6e8>
    4426:	e8 b5 fb ff ff       	call   3fe0 <ad_raw_fail>
    442b:	e8 20 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004430 <fwp_trap>:
    4430:	55                   	push   %rbp
    4431:	48 89 fd             	mov    %rdi,%rbp
    4434:	53                   	push   %rbx
    4435:	48 83 ec 08          	sub    $0x8,%rsp
    4439:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4440:	ff ff 
    4442:	e8 99 f8 ff ff       	call   3ce0 <fwp_flush>
    4447:	31 c0                	xor    %eax,%eax
    4449:	48 89 e9             	mov    %rbp,%rcx
    444c:	be 02 00 00 00       	mov    $0x2,%esi
    4451:	48 8b 3d e8 ab 00 00 	mov    0xabe8(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4458:	48 8d 15 ff 6b 00 00 	lea    0x6bff(%rip),%rdx        # b05e <_IO_stdin_used+0x5e>
    445f:	e8 0c f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4464:	48 85 db             	test   %rbx,%rbx
    4467:	74 16                	je     447f <fwp_trap+0x4f>
    4469:	48 8b 3d d0 ab 00 00 	mov    0xabd0(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4470:	e8 2b f1 ff ff       	call   35a0 <fflush@plt>
    4475:	bf 65 00 00 00       	mov    $0x65,%edi
    447a:	e8 01 f2 ff ff       	call   3680 <_Exit@plt>
    447f:	bf 65 00 00 00       	mov    $0x65,%edi
    4484:	e8 c7 f1 ff ff       	call   3650 <exit@plt>
    4489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004490 <fwp_closure_drop_push>:
    4490:	41 56                	push   %r14
    4492:	41 54                	push   %r12
    4494:	49 89 f4             	mov    %rsi,%r12
    4497:	55                   	push   %rbp
    4498:	48 89 fd             	mov    %rdi,%rbp
    449b:	53                   	push   %rbx
    449c:	48 83 ec 18          	sub    $0x18,%rsp
    44a0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44a4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44a8:	74 26                	je     44d0 <fwp_closure_drop_push+0x40>
    44aa:	4c 8b 07             	mov    (%rdi),%r8
    44ad:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44b4:	00 
    44b5:	48 83 c3 01          	add    $0x1,%rbx
    44b9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44bd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44c1:	48 83 c4 18          	add    $0x18,%rsp
    44c5:	5b                   	pop    %rbx
    44c6:	5d                   	pop    %rbp
    44c7:	41 5c                	pop    %r12
    44c9:	41 5e                	pop    %r14
    44cb:	c3                   	ret
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)
    44d0:	48 89 d8             	mov    %rbx,%rax
    44d3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44d7:	0f 85 a9 00 00 00    	jne    4586 <fwp_closure_drop_push+0xf6>
    44dd:	48 89 d9             	mov    %rbx,%rcx
    44e0:	48 c1 e1 04          	shl    $0x4,%rcx
    44e4:	48 89 cf             	mov    %rcx,%rdi
    44e7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44eb:	e8 a0 f0 ff ff       	call   3590 <malloc@plt>
    44f0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44f4:	48 85 c0             	test   %rax,%rax
    44f7:	74 5f                	je     4558 <fwp_closure_drop_push+0xc8>
    44f9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44fd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4504:	00 
    4505:	48 89 c7             	mov    %rax,%rdi
    4508:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    450c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4511:	48 89 34 24          	mov    %rsi,(%rsp)
    4515:	e8 36 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    451a:	48 8b 34 24          	mov    (%rsp),%rsi
    451e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4523:	49 89 c0             	mov    %rax,%r8
    4526:	48 8d 45 18          	lea    0x18(%rbp),%rax
    452a:	48 39 c6             	cmp    %rax,%rsi
    452d:	74 1c                	je     454b <fwp_closure_drop_push+0xbb>
    452f:	48 89 f7             	mov    %rsi,%rdi
    4532:	4c 89 04 24          	mov    %r8,(%rsp)
    4536:	e8 75 ee ff ff       	call   33b0 <free@plt>
    453b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    453f:	4c 8b 04 24          	mov    (%rsp),%r8
    4543:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    454a:	00 
    454b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    454f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4553:	e9 5d ff ff ff       	jmp    44b5 <fwp_closure_drop_push+0x25>
    4558:	48 8b 0d e1 aa 00 00 	mov    0xaae1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    455f:	ba 13 00 00 00       	mov    $0x13,%edx
    4564:	be 01 00 00 00       	mov    $0x1,%esi
    4569:	48 8d 3d 98 6a 00 00 	lea    0x6a98(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4570:	e8 eb f0 ff ff       	call   3660 <fwrite@plt>
    4575:	31 ff                	xor    %edi,%edi
    4577:	e8 24 f0 ff ff       	call   35a0 <fflush@plt>
    457c:	bf 66 00 00 00       	mov    $0x66,%edi
    4581:	e8 fa f0 ff ff       	call   3680 <_Exit@plt>
    4586:	48 8d 3d e0 6a 00 00 	lea    0x6ae0(%rip),%rdi        # b06d <_IO_stdin_used+0x6d>
    458d:	e8 9e fe ff ff       	call   4430 <fwp_trap>
    4592:	0f 1f 00             	nopl   (%rax)
    4595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    459c:	00 00 00 00 

00000000000045a0 <fwp_now_ns>:
    45a0:	53                   	push   %rbx
    45a1:	bf 01 00 00 00       	mov    $0x1,%edi
    45a6:	48 83 ec 20          	sub    $0x20,%rsp
    45aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45b1:	00 00 
    45b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45b8:	31 db                	xor    %ebx,%ebx
    45ba:	48 89 e6             	mov    %rsp,%rsi
    45bd:	e8 4e ee ff ff       	call   3410 <clock_gettime@plt>
    45c2:	85 c0                	test   %eax,%eax
    45c4:	75 52                	jne    4618 <fwp_now_ns+0x78>
    45c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45d0:	48 f7 2c 24          	imulq  (%rsp)
    45d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45db:	48 89 f7             	mov    %rsi,%rdi
    45de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45e2:	48 01 f0             	add    %rsi,%rax
    45e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ec:	00 00 80 
    45ef:	48 11 fa             	adc    %rdi,%rdx
    45f2:	31 ff                	xor    %edi,%edi
    45f4:	48 01 c6             	add    %rax,%rsi
    45f7:	48 11 d7             	adc    %rdx,%rdi
    45fa:	48 39 f1             	cmp    %rsi,%rcx
    45fd:	48 19 fb             	sbb    %rdi,%rbx
    4600:	72 27                	jb     4629 <fwp_now_ns+0x89>
    4602:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4607:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    460e:	00 00 
    4610:	75 12                	jne    4624 <fwp_now_ns+0x84>
    4612:	48 83 c4 20          	add    $0x20,%rsp
    4616:	5b                   	pop    %rbx
    4617:	c3                   	ret
    4618:	48 8d 3d 68 6a 00 00 	lea    0x6a68(%rip),%rdi        # b087 <_IO_stdin_used+0x87>
    461f:	e8 0c fe ff ff       	call   4430 <fwp_trap>
    4624:	e8 27 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4629:	48 8d 3d c0 71 00 00 	lea    0x71c0(%rip),%rdi        # b7f0 <_IO_stdin_used+0x7f0>
    4630:	e8 fb fd ff ff       	call   4430 <fwp_trap>
    4635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    463c:	00 00 00 00 

0000000000004640 <fwp_closure_drop.part.0>:
    4640:	53                   	push   %rbx
    4641:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4648:	66 0f 6f 05 40 76 00 	movdqa 0x7640(%rip),%xmm0        # bc90 <msg.4+0x20>
    464f:	00 
    4650:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4657:	00 00 
    4659:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4660:	00 
    4661:	48 89 fe             	mov    %rdi,%rsi
    4664:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4669:	48 89 e7             	mov    %rsp,%rdi
    466c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4670:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4675:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    467c:	ff ff 
    467e:	e8 0d fe ff ff       	call   4490 <fwp_closure_drop_push>
    4683:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4688:	48 85 c0             	test   %rax,%rax
    468b:	74 39                	je     46c6 <fwp_closure_drop.part.0+0x86>
    468d:	0f 1f 00             	nopl   (%rax)
    4690:	48 8b 14 24          	mov    (%rsp),%rdx
    4694:	48 83 e8 01          	sub    $0x1,%rax
    4698:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    469d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46a1:	8b 07                	mov    (%rdi),%eax
    46a3:	48 c1 e0 05          	shl    $0x5,%rax
    46a7:	48 03 05 ca 4d 06 00 	add    0x64dca(%rip),%rax        # 69478 <fwp_fns>
    46ae:	48 8b 40 18          	mov    0x18(%rax),%rax
    46b2:	48 85 c0             	test   %rax,%rax
    46b5:	74 46                	je     46fd <fwp_closure_drop.part.0+0xbd>
    46b7:	31 f6                	xor    %esi,%esi
    46b9:	ff 50 08             	call   *0x8(%rax)
    46bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46c1:	48 85 c0             	test   %rax,%rax
    46c4:	75 ca                	jne    4690 <fwp_closure_drop.part.0+0x50>
    46c6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46cd:	ff ff 00 00 00 00 
    46d3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46d7:	48 39 df             	cmp    %rbx,%rdi
    46da:	74 05                	je     46e1 <fwp_closure_drop.part.0+0xa1>
    46dc:	e8 cf ec ff ff       	call   33b0 <free@plt>
    46e1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46e8:	00 
    46e9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46f0:	00 00 
    46f2:	75 15                	jne    4709 <fwp_closure_drop.part.0+0xc9>
    46f4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46fb:	5b                   	pop    %rbx
    46fc:	c3                   	ret
    46fd:	48 8d 3d 14 71 00 00 	lea    0x7114(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    4704:	e8 27 fd ff ff       	call   4430 <fwp_trap>
    4709:	e8 42 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    470e:	66 90                	xchg   %ax,%ax

0000000000004710 <fwp_tape_of>:
    4710:	0f b7 d7             	movzwl %di,%edx
    4713:	48 85 d2             	test   %rdx,%rdx
    4716:	74 28                	je     4740 <fwp_tape_of+0x30>
    4718:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    471c:	48 39 05 c5 a9 01 00 	cmp    %rax,0x1a9c5(%rip)        # 1f0e8 <fwp_ntapes>
    4723:	7e 1b                	jle    4740 <fwp_tape_of+0x30>
    4725:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4729:	48 03 05 c0 a9 01 00 	add    0x1a9c0(%rip),%rax        # 1f0f0 <fwp_tapes>
    4730:	8b 50 04             	mov    0x4(%rax),%edx
    4733:	85 d2                	test   %edx,%edx
    4735:	74 09                	je     4740 <fwp_tape_of+0x30>
    4737:	48 c1 ff 10          	sar    $0x10,%rdi
    473b:	39 38                	cmp    %edi,(%rax)
    473d:	75 01                	jne    4740 <fwp_tape_of+0x30>
    473f:	c3                   	ret
    4740:	48 83 ec 08          	sub    $0x8,%rsp
    4744:	48 8d 3d fd 70 00 00 	lea    0x70fd(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    474b:	e8 e0 fc ff ff       	call   4430 <fwp_trap>

0000000000004750 <fwp_format_g.constprop.0>:
    4750:	41 57                	push   %r15
    4752:	b9 40 00 00 00       	mov    $0x40,%ecx
    4757:	ba 02 00 00 00       	mov    $0x2,%edx
    475c:	4c 8d 05 40 69 00 00 	lea    0x6940(%rip),%r8        # b0a3 <_IO_stdin_used+0xa3>
    4763:	41 56                	push   %r14
    4765:	b8 01 00 00 00       	mov    $0x1,%eax
    476a:	41 55                	push   %r13
    476c:	41 54                	push   %r12
    476e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4772:	55                   	push   %rbp
    4773:	45 89 e1             	mov    %r12d,%r9d
    4776:	53                   	push   %rbx
    4777:	48 89 fb             	mov    %rdi,%rbx
    477a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4781:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4788:	00 00 
    478a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4791:	00 
    4792:	41 89 f7             	mov    %esi,%r15d
    4795:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    479a:	be 40 00 00 00       	mov    $0x40,%esi
    479f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47a4:	4c 89 f7             	mov    %r14,%rdi
    47a7:	e8 f4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47ac:	be 65 00 00 00       	mov    $0x65,%esi
    47b1:	4c 89 f7             	mov    %r14,%rdi
    47b4:	e8 b7 ec ff ff       	call   3470 <strchr@plt>
    47b9:	31 f6                	xor    %esi,%esi
    47bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    47c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47c4:	48 89 c5             	mov    %rax,%rbp
    47c7:	e8 a4 ed ff ff       	call   3570 <strtol@plt>
    47cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47d1:	49 89 c0             	mov    %rax,%r8
    47d4:	83 c0 05             	add    $0x5,%eax
    47d7:	83 f8 15             	cmp    $0x15,%eax
    47da:	0f 87 e0 01 00 00    	ja     49c0 <fwp_format_g.constprop.0+0x270>
    47e0:	45 89 e5             	mov    %r12d,%r13d
    47e3:	45 29 c5             	sub    %r8d,%r13d
    47e6:	45 85 ed             	test   %r13d,%r13d
    47e9:	0f 8e 21 01 00 00    	jle    4910 <fwp_format_g.constprop.0+0x1c0>
    47ef:	41 83 ff 01          	cmp    $0x1,%r15d
    47f3:	0f 84 17 01 00 00    	je     4910 <fwp_format_g.constprop.0+0x1c0>
    47f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47fe:	31 d2                	xor    %edx,%edx
    4800:	4d 63 df             	movslq %r15d,%r11
    4803:	3c 2d                	cmp    $0x2d,%al
    4805:	0f 94 c2             	sete   %dl
    4808:	4c 29 dd             	sub    %r11,%rbp
    480b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    480f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4813:	4d 89 f1             	mov    %r14,%r9
    4816:	4d 29 d1             	sub    %r10,%r9
    4819:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    481d:	3c 2d                	cmp    $0x2d,%al
    481f:	0f 84 fb 03 00 00    	je     4c20 <fwp_format_g.constprop.0+0x4d0>
    4825:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    482a:	b9 48 00 00 00       	mov    $0x48,%ecx
    482f:	48 89 e8             	mov    %rbp,%rax
    4832:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4836:	49 8d 72 01          	lea    0x1(%r10),%rsi
    483a:	49 83 c1 47          	add    $0x47,%r9
    483e:	45 85 c0             	test   %r8d,%r8d
    4841:	0f 88 f1 02 00 00    	js     4b38 <fwp_format_g.constprop.0+0x3e8>
    4847:	45 0f b6 12          	movzbl (%r10),%r10d
    484b:	4d 63 e0             	movslq %r8d,%r12
    484e:	44 88 10             	mov    %r10b,(%rax)
    4851:	41 83 f8 07          	cmp    $0x7,%r8d
    4855:	0f 87 2d 02 00 00    	ja     4a88 <fwp_format_g.constprop.0+0x338>
    485b:	41 f6 c4 04          	test   $0x4,%r12b
    485f:	0f 85 f2 03 00 00    	jne    4c57 <fwp_format_g.constprop.0+0x507>
    4865:	45 85 e4             	test   %r12d,%r12d
    4868:	74 12                	je     487c <fwp_format_g.constprop.0+0x12c>
    486a:	45 0f b6 06          	movzbl (%r14),%r8d
    486e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4872:	41 f6 c4 02          	test   $0x2,%r12b
    4876:	0f 85 03 04 00 00    	jne    4c7f <fwp_format_g.constprop.0+0x52f>
    487c:	4c 29 e1             	sub    %r12,%rcx
    487f:	4c 01 e7             	add    %r12,%rdi
    4882:	4c 89 fa             	mov    %r15,%rdx
    4885:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488a:	48 83 e9 01          	sub    $0x1,%rcx
    488e:	4d 63 ed             	movslq %r13d,%r13
    4891:	48 89 0c 24          	mov    %rcx,(%rsp)
    4895:	e8 b6 ec ff ff       	call   3550 <__memcpy_chk@plt>
    489a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    489f:	48 8b 0c 24          	mov    (%rsp),%rcx
    48a3:	ba 48 00 00 00       	mov    $0x48,%edx
    48a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48b0:	4c 89 c8             	mov    %r9,%rax
    48b3:	48 29 c8             	sub    %rcx,%rax
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48bd:	4c 29 c9             	sub    %r9,%rcx
    48c0:	4c 89 ea             	mov    %r13,%rdx
    48c3:	48 01 c1             	add    %rax,%rcx
    48c6:	e8 85 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	48 29 e8             	sub    %rbp,%rax
    48d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 47 c2          	cmova  %rdx,%rax
    48dd:	89 c1                	mov    %eax,%ecx
    48df:	83 f8 08             	cmp    $0x8,%eax
    48e2:	0f 83 18 02 00 00    	jae    4b00 <fwp_format_g.constprop.0+0x3b0>
    48e8:	a8 04                	test   $0x4,%al
    48ea:	0f 85 54 03 00 00    	jne    4c44 <fwp_format_g.constprop.0+0x4f4>
    48f0:	85 c0                	test   %eax,%eax
    48f2:	74 0f                	je     4903 <fwp_format_g.constprop.0+0x1b3>
    48f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48f9:	88 13                	mov    %dl,(%rbx)
    48fb:	a8 02                	test   $0x2,%al
    48fd:	0f 85 6b 03 00 00    	jne    4c6e <fwp_format_g.constprop.0+0x51e>
    4903:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4907:	eb 36                	jmp    493f <fwp_format_g.constprop.0+0x1ef>
    4909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4910:	45 31 c9             	xor    %r9d,%r9d
    4913:	45 85 ed             	test   %r13d,%r13d
    4916:	4c 8d 05 95 67 00 00 	lea    0x6795(%rip),%r8        # b0b2 <_IO_stdin_used+0xb2>
    491d:	48 89 df             	mov    %rbx,%rdi
    4920:	45 0f 49 cd          	cmovns %r13d,%r9d
    4924:	ba 02 00 00 00       	mov    $0x2,%edx
    4929:	be 90 01 00 00       	mov    $0x190,%esi
    492e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4935:	b8 01 00 00 00       	mov    $0x1,%eax
    493a:	e8 61 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    493f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4944:	48 89 df             	mov    %rbx,%rdi
    4947:	e8 24 eb ff ff       	call   3470 <strchr@plt>
    494c:	48 85 c0             	test   %rax,%rax
    494f:	74 3f                	je     4990 <fwp_format_g.constprop.0+0x240>
    4951:	48 89 df             	mov    %rbx,%rdi
    4954:	e8 e7 ea ff ff       	call   3440 <strlen@plt>
    4959:	48 85 c0             	test   %rax,%rax
    495c:	75 0b                	jne    4969 <fwp_format_g.constprop.0+0x219>
    495e:	eb 30                	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4960:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4964:	48 85 c0             	test   %rax,%rax
    4967:	74 27                	je     4990 <fwp_format_g.constprop.0+0x240>
    4969:	48 89 c2             	mov    %rax,%rdx
    496c:	48 83 e8 01          	sub    $0x1,%rax
    4970:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4974:	74 ea                	je     4960 <fwp_format_g.constprop.0+0x210>
    4976:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    497b:	0f 84 6f 01 00 00    	je     4af0 <fwp_format_g.constprop.0+0x3a0>
    4981:	0f 1f 40 00          	nopl   0x0(%rax)
    4985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    498c:	00 00 00 00 
    4990:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4997:	00 
    4998:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    499f:	00 00 
    49a1:	0f 85 ec 02 00 00    	jne    4c93 <fwp_format_g.constprop.0+0x543>
    49a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ae:	5b                   	pop    %rbx
    49af:	5d                   	pop    %rbp
    49b0:	41 5c                	pop    %r12
    49b2:	41 5d                	pop    %r13
    49b4:	41 5e                	pop    %r14
    49b6:	41 5f                	pop    %r15
    49b8:	c3                   	ret
    49b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49c0:	4c 29 f5             	sub    %r14,%rbp
    49c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49c8:	4c 89 f6             	mov    %r14,%rsi
    49cb:	4c 89 04 24          	mov    %r8,(%rsp)
    49cf:	49 89 ec             	mov    %rbp,%r12
    49d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49d7:	4c 89 e2             	mov    %r12,%rdx
    49da:	48 89 ef             	mov    %rbp,%rdi
    49dd:	e8 6e eb ff ff       	call   3550 <__memcpy_chk@plt>
    49e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ed:	48 89 ef             	mov    %rbp,%rdi
    49f0:	e8 7b ea ff ff       	call   3470 <strchr@plt>
    49f5:	4c 8b 04 24          	mov    (%rsp),%r8
    49f9:	48 85 c0             	test   %rax,%rax
    49fc:	74 40                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    49fe:	4d 85 e4             	test   %r12,%r12
    4a01:	74 3b                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a03:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a08:	eb 23                	jmp    4a2d <fwp_format_g.constprop.0+0x2dd>
    4a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a11:	00 00 00 00 
    4a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a1c:	00 00 00 00 
    4a20:	c6 00 00             	movb   $0x0,(%rax)
    4a23:	48 83 e8 01          	sub    $0x1,%rax
    4a27:	49 83 ec 01          	sub    $0x1,%r12
    4a2b:	74 11                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a2d:	80 38 30             	cmpb   $0x30,(%rax)
    4a30:	74 ee                	je     4a20 <fwp_format_g.constprop.0+0x2d0>
    4a32:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a38:	0f 84 fb 01 00 00    	je     4c39 <fwp_format_g.constprop.0+0x4e9>
    4a3e:	44 89 c0             	mov    %r8d,%eax
    4a41:	ba 02 00 00 00       	mov    $0x2,%edx
    4a46:	49 89 e9             	mov    %rbp,%r9
    4a49:	be 90 01 00 00       	mov    $0x190,%esi
    4a4e:	f7 d8                	neg    %eax
    4a50:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a57:	48 89 df             	mov    %rbx,%rdi
    4a5a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a5e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a62:	41 83 e0 02          	and    $0x2,%r8d
    4a66:	41 83 c0 2b          	add    $0x2b,%r8d
    4a6a:	50                   	push   %rax
    4a6b:	31 c0                	xor    %eax,%eax
    4a6d:	41 50                	push   %r8
    4a6f:	4c 8d 05 32 66 00 00 	lea    0x6632(%rip),%r8        # b0a8 <_IO_stdin_used+0xa8>
    4a76:	e8 25 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a7b:	58                   	pop    %rax
    4a7c:	5a                   	pop    %rdx
    4a7d:	e9 0e ff ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a88:	4d 8b 06             	mov    (%r14),%r8
    4a8b:	48 83 c0 09          	add    $0x9,%rax
    4a8f:	4c 89 f2             	mov    %r14,%rdx
    4a92:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a96:	4c 89 07             	mov    %r8,(%rdi)
    4a99:	45 89 e0             	mov    %r12d,%r8d
    4a9c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4aa1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4aa6:	49 89 f8             	mov    %rdi,%r8
    4aa9:	49 29 c0             	sub    %rax,%r8
    4aac:	4c 29 c2             	sub    %r8,%rdx
    4aaf:	45 01 e0             	add    %r12d,%r8d
    4ab2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ab6:	41 83 f8 08          	cmp    $0x8,%r8d
    4aba:	0f 82 bc fd ff ff    	jb     487c <fwp_format_g.constprop.0+0x12c>
    4ac0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ac4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ac8:	45 31 d2             	xor    %r10d,%r10d
    4acb:	45 89 d3             	mov    %r10d,%r11d
    4ace:	41 83 c2 08          	add    $0x8,%r10d
    4ad2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ad6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4ada:	45 39 c2             	cmp    %r8d,%r10d
    4add:	72 ec                	jb     4acb <fwp_format_g.constprop.0+0x37b>
    4adf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ae3:	e9 94 fd ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4ae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aef:	00 
    4af0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4af5:	e9 96 fe ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b00:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b05:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b09:	48 89 ee             	mov    %rbp,%rsi
    4b0c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b10:	48 89 13             	mov    %rdx,(%rbx)
    4b13:	89 c2                	mov    %eax,%edx
    4b15:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b1a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b1f:	48 89 d9             	mov    %rbx,%rcx
    4b22:	48 29 f9             	sub    %rdi,%rcx
    4b25:	48 29 ce             	sub    %rcx,%rsi
    4b28:	01 c1                	add    %eax,%ecx
    4b2a:	c1 e9 03             	shr    $0x3,%ecx
    4b2d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b30:	e9 ce fd ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4b35:	0f 1f 00             	nopl   (%rax)
    4b38:	c6 00 30             	movb   $0x30,(%rax)
    4b3b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b3f:	4c 89 fa             	mov    %r15,%rdx
    4b42:	4c 89 e9             	mov    %r13,%rcx
    4b45:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b4a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b4f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b53:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b58:	e8 f3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b5d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b62:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b67:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b6c:	48 89 c7             	mov    %rax,%rdi
    4b6f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b73:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b78:	4c 89 c8             	mov    %r9,%rax
    4b7b:	4c 29 e8             	sub    %r13,%rax
    4b7e:	48 39 c8             	cmp    %rcx,%rax
    4b81:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b85:	4d 29 cd             	sub    %r9,%r13
    4b88:	49 01 ff             	add    %rdi,%r15
    4b8b:	4c 01 e8             	add    %r13,%rax
    4b8e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b92:	74 3d                	je     4bd1 <fwp_format_g.constprop.0+0x481>
    4b94:	41 f7 d0             	not    %r8d
    4b97:	31 f6                	xor    %esi,%esi
    4b99:	ba 48 00 00 00       	mov    $0x48,%edx
    4b9e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4ba3:	48 39 d0             	cmp    %rdx,%rax
    4ba6:	48 0f 43 d0          	cmovae %rax,%rdx
    4baa:	48 89 d1             	mov    %rdx,%rcx
    4bad:	48 29 c1             	sub    %rax,%rcx
    4bb0:	48 83 c1 01          	add    $0x1,%rcx
    4bb4:	48 39 d1             	cmp    %rdx,%rcx
    4bb7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bbb:	48 83 e8 01          	sub    $0x1,%rax
    4bbf:	48 83 c6 01          	add    $0x1,%rsi
    4bc3:	48 29 d0             	sub    %rdx,%rax
    4bc6:	48 01 c8             	add    %rcx,%rax
    4bc9:	41 39 f0             	cmp    %esi,%r8d
    4bcc:	7f cb                	jg     4b99 <fwp_format_g.constprop.0+0x449>
    4bce:	4d 01 c7             	add    %r8,%r15
    4bd1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bd6:	41 0f b6 12          	movzbl (%r10),%edx
    4bda:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bde:	4c 89 f6             	mov    %r14,%rsi
    4be1:	48 39 c8             	cmp    %rcx,%rax
    4be4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4be8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bec:	41 88 17             	mov    %dl,(%r15)
    4bef:	48 89 ca             	mov    %rcx,%rdx
    4bf2:	48 29 c2             	sub    %rax,%rdx
    4bf5:	48 83 c2 01          	add    $0x1,%rdx
    4bf9:	48 39 ca             	cmp    %rcx,%rdx
    4bfc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c00:	48 83 e8 01          	sub    $0x1,%rax
    4c04:	48 29 c8             	sub    %rcx,%rax
    4c07:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c0b:	49 63 d4             	movslq %r12d,%rdx
    4c0e:	e8 3d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c13:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c17:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c1b:	e9 ae fc ff ff       	jmp    48ce <fwp_format_g.constprop.0+0x17e>
    4c20:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c25:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c2a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c2f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c34:	e9 f9 fb ff ff       	jmp    4832 <fwp_format_g.constprop.0+0xe2>
    4c39:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c3f:	e9 fa fd ff ff       	jmp    4a3e <fwp_format_g.constprop.0+0x2ee>
    4c44:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c48:	89 13                	mov    %edx,(%rbx)
    4c4a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c4e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c52:	e9 ac fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c57:	41 8b 06             	mov    (%r14),%eax
    4c5a:	89 07                	mov    %eax,(%rdi)
    4c5c:	44 89 e0             	mov    %r12d,%eax
    4c5f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c64:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c69:	e9 0e fc ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c6e:	89 c2                	mov    %eax,%edx
    4c70:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c75:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c7a:	e9 84 fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c7f:	44 89 e0             	mov    %r12d,%eax
    4c82:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c88:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c8e:	e9 e9 fb ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c93:	e8 b8 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c9f:	00 

0000000000004ca0 <fwp_heap_report>:
    4ca0:	f3 0f 1e fa          	endbr64
    4ca4:	41 54                	push   %r12
    4ca6:	48 8d 3d 0a 64 00 00 	lea    0x640a(%rip),%rdi        # b0b7 <_IO_stdin_used+0xb7>
    4cad:	55                   	push   %rbp
    4cae:	53                   	push   %rbx
    4caf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cb6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cbd:	00 00 
    4cbf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4cc6:	00 
    4cc7:	48 8d 35 74 65 00 00 	lea    0x6574(%rip),%rsi        # b242 <_IO_stdin_used+0x242>
    4cce:	e8 3d e9 ff ff       	call   3610 <fopen@plt>
    4cd3:	48 85 c0             	test   %rax,%rax
    4cd6:	0f 84 c5 00 00 00    	je     4da1 <fwp_heap_report+0x101>
    4cdc:	48 89 c5             	mov    %rax,%rbp
    4cdf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ce6:	48 89 e3             	mov    %rsp,%rbx
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	48 89 ea             	mov    %rbp,%rdx
    4cf3:	be 00 01 00 00       	mov    $0x100,%esi
    4cf8:	48 89 df             	mov    %rbx,%rdi
    4cfb:	e8 f0 e7 ff ff       	call   34f0 <fgets@plt>
    4d00:	48 85 c0             	test   %rax,%rax
    4d03:	74 2b                	je     4d30 <fwp_heap_report+0x90>
    4d05:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d0b:	75 e3                	jne    4cf0 <fwp_heap_report+0x50>
    4d0d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d11:	75 dd                	jne    4cf0 <fwp_heap_report+0x50>
    4d13:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d18:	75 d6                	jne    4cf0 <fwp_heap_report+0x50>
    4d1a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d1f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d24:	31 f6                	xor    %esi,%esi
    4d26:	e8 45 e8 ff ff       	call   3570 <strtol@plt>
    4d2b:	49 89 c4             	mov    %rax,%r12
    4d2e:	eb c0                	jmp    4cf0 <fwp_heap_report+0x50>
    4d30:	48 89 ef             	mov    %rbp,%rdi
    4d33:	e8 f8 e6 ff ff       	call   3430 <fclose@plt>
    4d38:	48 83 ec 08          	sub    $0x8,%rsp
    4d3c:	4c 8b 0d a5 3e 06 00 	mov    0x63ea5(%rip),%r9        # 68be8 <fwp_heap+0x13c8>
    4d43:	4c 8b 05 fe 3e 06 00 	mov    0x63efe(%rip),%r8        # 68c48 <fwp_heap+0x1428>
    4d4a:	48 8d 15 47 6b 00 00 	lea    0x6b47(%rip),%rdx        # b898 <_IO_stdin_used+0x898>
    4d51:	41 54                	push   %r12
    4d53:	48 8b 0d e6 3e 06 00 	mov    0x63ee6(%rip),%rcx        # 68c40 <fwp_heap+0x1420>
    4d5a:	be 02 00 00 00       	mov    $0x2,%esi
    4d5f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d64:	f2 0f 10 0d f4 3e 06 	movsd  0x63ef4(%rip),%xmm1        # 68c60 <fwp_heap+0x1440>
    4d6b:	00 
    4d6c:	f2 0f 10 05 e4 3e 06 	movsd  0x63ee4(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    4d73:	00 
    4d74:	48 8b 3d c5 a2 00 00 	mov    0xa2c5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d7b:	e8 f0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4d80:	58                   	pop    %rax
    4d81:	5a                   	pop    %rdx
    4d82:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d89:	00 
    4d8a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d91:	00 00 
    4d93:	75 15                	jne    4daa <fwp_heap_report+0x10a>
    4d95:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d9c:	5b                   	pop    %rbx
    4d9d:	5d                   	pop    %rbp
    4d9e:	41 5c                	pop    %r12
    4da0:	c3                   	ret
    4da1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4da8:	eb 8e                	jmp    4d38 <fwp_heap_report+0x98>
    4daa:	e8 a1 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4daf:	90                   	nop

0000000000004db0 <fwp_heap_init>:
    4db0:	66 0f 6f 05 e8 6e 00 	movdqa 0x6ee8(%rip),%xmm0        # bca0 <msg.4+0x30>
    4db7:	00 
    4db8:	41 54                	push   %r12
    4dba:	48 8d 05 9f 39 06 00 	lea    0x6399f(%rip),%rax        # 68760 <fwp_heap+0xf40>
    4dc1:	ba 00 01 00 00       	mov    $0x100,%edx
    4dc6:	55                   	push   %rbp
    4dc7:	66 0f 6f 15 11 6f 00 	movdqa 0x6f11(%rip),%xmm2        # bce0 <msg.4+0x70>
    4dce:	00 
    4dcf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4dd3:	53                   	push   %rbx
    4dd4:	0f 29 05 45 39 06 00 	movaps %xmm0,0x63945(%rip)        # 68720 <fwp_heap+0xf00>
    4ddb:	66 0f 6f 05 cd 6e 00 	movdqa 0x6ecd(%rip),%xmm0        # bcb0 <msg.4+0x40>
    4de2:	00 
    4de3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4de7:	c7 05 d3 3d 06 00 01 	movl   $0x1,0x63dd3(%rip)        # 68bc4 <fwp_heap+0x13a4>
    4dee:	00 00 00 
    4df1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4df6:	0f 29 05 33 39 06 00 	movaps %xmm0,0x63933(%rip)        # 68730 <fwp_heap+0xf10>
    4dfd:	66 0f 6f 05 bb 6e 00 	movdqa 0x6ebb(%rip),%xmm0        # bcc0 <msg.4+0x50>
    4e04:	00 
    4e05:	0f 29 05 34 39 06 00 	movaps %xmm0,0x63934(%rip)        # 68740 <fwp_heap+0xf20>
    4e0c:	66 0f 6f 05 bc 6e 00 	movdqa 0x6ebc(%rip),%xmm0        # bcd0 <msg.4+0x60>
    4e13:	00 
    4e14:	0f 29 05 35 39 06 00 	movaps %xmm0,0x63935(%rip)        # 68750 <fwp_heap+0xf30>
    4e1b:	89 d3                	mov    %edx,%ebx
    4e1d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e21:	48 83 c0 10          	add    $0x10,%rax
    4e25:	01 d2                	add    %edx,%edx
    4e27:	c1 eb 02             	shr    $0x2,%ebx
    4e2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e5f:	48 39 c7             	cmp    %rax,%rdi
    4e62:	75 b7                	jne    4e1b <fwp_heap_init+0x6b>
    4e64:	4c 8d 05 b5 29 06 00 	lea    0x629b5(%rip),%r8        # 67820 <fwp_heap>
    4e6b:	31 c9                	xor    %ecx,%ecx
    4e6d:	31 c0                	xor    %eax,%eax
    4e6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e7d:	00 00 00 
    4e80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e87:	00 
    4e88:	48 39 ca             	cmp    %rcx,%rdx
    4e8b:	73 0f                	jae    4e9c <fwp_heap_init+0xec>
    4e8d:	0f 1f 00             	nopl   (%rax)
    4e90:	48 83 c0 01          	add    $0x1,%rax
    4e94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e97:	48 39 ca             	cmp    %rcx,%rdx
    4e9a:	72 f4                	jb     4e90 <fwp_heap_init+0xe0>
    4e9c:	48 83 c1 10          	add    $0x10,%rcx
    4ea0:	88 07                	mov    %al,(%rdi)
    4ea2:	48 83 c7 01          	add    $0x1,%rdi
    4ea6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ead:	75 d1                	jne    4e80 <fwp_heap_init+0xd0>
    4eaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4eb6:	00 00 00 
    4eb9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ebe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ec5:	45 31 c9             	xor    %r9d,%r9d
    4ec8:	31 d2                	xor    %edx,%edx
    4eca:	31 ff                	xor    %edi,%edi
    4ecc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ed2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ed7:	4c 89 e6             	mov    %r12,%rsi
    4eda:	e8 81 e5 ff ff       	call   3460 <mmap@plt>
    4edf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ee3:	75 13                	jne    4ef8 <fwp_heap_init+0x148>
    4ee5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ee9:	83 ed 01             	sub    $0x1,%ebp
    4eec:	75 d0                	jne    4ebe <fwp_heap_init+0x10e>
    4eee:	e8 1d ef ff ff       	call   3e10 <fwp_heap_oom>
    4ef3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ef8:	48 85 c0             	test   %rax,%rax
    4efb:	74 f1                	je     4eee <fwp_heap_init+0x13e>
    4efd:	48 c1 eb 10          	shr    $0x10,%rbx
    4f01:	48 89 05 d0 3c 06 00 	mov    %rax,0x63cd0(%rip)        # 68bd8 <fwp_heap+0x13b8>
    4f08:	45 31 c9             	xor    %r9d,%r9d
    4f0b:	31 d2                	xor    %edx,%edx
    4f0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f17:	31 ff                	xor    %edi,%edi
    4f19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f1f:	66 31 c0             	xor    %ax,%ax
    4f22:	48 c1 e6 03          	shl    $0x3,%rsi
    4f26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f2b:	4c 89 25 ae 3c 06 00 	mov    %r12,0x63cae(%rip)        # 68be0 <fwp_heap+0x13c0>
    4f32:	48 89 05 97 3c 06 00 	mov    %rax,0x63c97(%rip)        # 68bd0 <fwp_heap+0x13b0>
    4f39:	48 89 1d b0 3c 06 00 	mov    %rbx,0x63cb0(%rip)        # 68bf0 <fwp_heap+0x13d0>
    4f40:	48 89 35 d9 3c 06 00 	mov    %rsi,0x63cd9(%rip)        # 68c20 <fwp_heap+0x1400>
    4f47:	e8 14 e5 ff ff       	call   3460 <mmap@plt>
    4f4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f50:	74 9c                	je     4eee <fwp_heap_init+0x13e>
    4f52:	48 8d 3d 94 61 00 00 	lea    0x6194(%rip),%rdi        # b0ed <_IO_stdin_used+0xed>
    4f59:	48 89 05 b8 3c 06 00 	mov    %rax,0x63cb8(%rip)        # 68c18 <fwp_heap+0x13f8>
    4f60:	e8 2b e4 ff ff       	call   3390 <getenv@plt>
    4f65:	48 89 c2             	mov    %rax,%rdx
    4f68:	31 c0                	xor    %eax,%eax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 15                	je     4f84 <fwp_heap_init+0x1d4>
    4f6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f72:	74 10                	je     4f84 <fwp_heap_init+0x1d4>
    4f74:	0f b6 02             	movzbl (%rdx),%eax
    4f77:	83 e8 30             	sub    $0x30,%eax
    4f7a:	74 13                	je     4f8f <fwp_heap_init+0x1df>
    4f7c:	85 c0                	test   %eax,%eax
    4f7e:	0f 95 c0             	setne  %al
    4f81:	0f b6 c0             	movzbl %al,%eax
    4f84:	5b                   	pop    %rbx
    4f85:	5d                   	pop    %rbp
    4f86:	89 05 3c 3c 06 00    	mov    %eax,0x63c3c(%rip)        # 68bc8 <fwp_heap+0x13a8>
    4f8c:	41 5c                	pop    %r12
    4f8e:	c3                   	ret
    4f8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f93:	85 c0                	test   %eax,%eax
    4f95:	0f 95 c0             	setne  %al
    4f98:	0f b6 c0             	movzbl %al,%eax
    4f9b:	eb e7                	jmp    4f84 <fwp_heap_init+0x1d4>
    4f9d:	0f 1f 00             	nopl   (%rax)

0000000000004fa0 <fwp_wake_io>:
    4fa0:	48 8b 07             	mov    (%rdi),%rax
    4fa3:	48 85 c0             	test   %rax,%rax
    4fa6:	0f 84 f4 00 00 00    	je     50a0 <fwp_wake_io+0x100>
    4fac:	53                   	push   %rbx
    4fad:	4c 8b 05 2c 28 06 00 	mov    0x6282c(%rip),%r8        # 677e0 <fwp_ready_tail>
    4fb4:	49 89 f9             	mov    %rdi,%r9
    4fb7:	48 89 c2             	mov    %rax,%rdx
    4fba:	45 31 db             	xor    %r11d,%r11d
    4fbd:	45 31 d2             	xor    %r10d,%r10d
    4fc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fc4:	eb 71                	jmp    5037 <fwp_wake_io+0x97>
    4fc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fcd:	00 00 00 
    4fd0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4fd7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fde:	48 85 c9             	test   %rcx,%rcx
    4fe1:	74 07                	je     4fea <fwp_wake_io+0x4a>
    4fe3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4fea:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4ff1:	00 00 00 00 
    4ff5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ffc:	49 8b 01             	mov    (%r9),%rax
    4fff:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5003:	75 2a                	jne    502f <fwp_wake_io+0x8f>
    5005:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5009:	75 24                	jne    502f <fwp_wake_io+0x8f>
    500b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    500f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5016:	00 00 00 00 
    501a:	4d 85 c0             	test   %r8,%r8
    501d:	74 51                	je     5070 <fwp_wake_io+0xd0>
    501f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5026:	49 89 d0             	mov    %rdx,%r8
    5029:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    502f:	48 89 c2             	mov    %rax,%rdx
    5032:	48 85 c0             	test   %rax,%rax
    5035:	74 49                	je     5080 <fwp_wake_io+0xe0>
    5037:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    503e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5042:	48 85 ff             	test   %rdi,%rdi
    5045:	74 b8                	je     4fff <fwp_wake_io+0x5f>
    5047:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    504e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5055:	48 85 f6             	test   %rsi,%rsi
    5058:	0f 85 72 ff ff ff    	jne    4fd0 <fwp_wake_io+0x30>
    505e:	48 89 0f             	mov    %rcx,(%rdi)
    5061:	e9 78 ff ff ff       	jmp    4fde <fwp_wake_io+0x3e>
    5066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    506d:	00 00 00 
    5070:	48 89 d3             	mov    %rdx,%rbx
    5073:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5079:	eb ab                	jmp    5026 <fwp_wake_io+0x86>
    507b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5080:	45 84 db             	test   %r11b,%r11b
    5083:	74 07                	je     508c <fwp_wake_io+0xec>
    5085:	48 89 1d 5c 27 06 00 	mov    %rbx,0x6275c(%rip)        # 677e8 <fwp_ready_head>
    508c:	45 84 d2             	test   %r10b,%r10b
    508f:	74 07                	je     5098 <fwp_wake_io+0xf8>
    5091:	4c 89 05 48 27 06 00 	mov    %r8,0x62748(%rip)        # 677e0 <fwp_ready_tail>
    5098:	5b                   	pop    %rbx
    5099:	c3                   	ret
    509a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50a0:	c3                   	ret
    50a1:	0f 1f 40 00          	nopl   0x0(%rax)
    50a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50ac:	00 00 00 00 

00000000000050b0 <ad_raw_free.part.0>:
    50b0:	48 8d 0d 09 a1 04 00 	lea    0x4a109(%rip),%rcx        # 4f1c0 <ad_raw_blocks>
    50b7:	31 c0                	xor    %eax,%eax
    50b9:	48 89 ca             	mov    %rcx,%rdx
    50bc:	eb 12                	jmp    50d0 <ad_raw_free.part.0+0x20>
    50be:	66 90                	xchg   %ax,%ax
    50c0:	48 83 c0 01          	add    $0x1,%rax
    50c4:	48 83 c2 18          	add    $0x18,%rdx
    50c8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ce:	74 40                	je     5110 <ad_raw_free.part.0+0x60>
    50d0:	48 3b 3a             	cmp    (%rdx),%rdi
    50d3:	75 eb                	jne    50c0 <ad_raw_free.part.0+0x10>
    50d5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50d9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50dd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    50e1:	48 8d 0d b8 a0 04 00 	lea    0x4a0b8(%rip),%rcx        # 4f1a0 <ad_raw_live>
    50e8:	8b 70 10             	mov    0x10(%rax),%esi
    50eb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    50f2:	00 
    50f3:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    50f7:	48 2b 50 08          	sub    0x8(%rax),%rdx
    50fb:	0f 11 00             	movups %xmm0,(%rax)
    50fe:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5102:	e9 a9 e2 ff ff       	jmp    33b0 <free@plt>
    5107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    510e:	00 00 
    5110:	48 83 ec 08          	sub    $0x8,%rsp
    5114:	48 8d 3d e2 5f 00 00 	lea    0x5fe2(%rip),%rdi        # b0fd <_IO_stdin_used+0xfd>
    511b:	e8 c0 ee ff ff       	call   3fe0 <ad_raw_fail>

0000000000005120 <fwp_tape_buffers_dispose>:
    5120:	53                   	push   %rbx
    5121:	48 89 fb             	mov    %rdi,%rbx
    5124:	48 8b 3f             	mov    (%rdi),%rdi
    5127:	48 85 ff             	test   %rdi,%rdi
    512a:	74 05                	je     5131 <fwp_tape_buffers_dispose+0x11>
    512c:	e8 7f ff ff ff       	call   50b0 <ad_raw_free.part.0>
    5131:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5135:	48 85 ff             	test   %rdi,%rdi
    5138:	74 05                	je     513f <fwp_tape_buffers_dispose+0x1f>
    513a:	e8 71 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    513f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5143:	48 85 ff             	test   %rdi,%rdi
    5146:	74 05                	je     514d <fwp_tape_buffers_dispose+0x2d>
    5148:	e8 63 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    514d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5151:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5158:	00 
    5159:	0f 11 03             	movups %xmm0,(%rbx)
    515c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5160:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5164:	5b                   	pop    %rbx
    5165:	c3                   	ret
    5166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    516d:	00 00 00 

0000000000005170 <ad_raw_realloc>:
    5170:	41 55                	push   %r13
    5172:	41 54                	push   %r12
    5174:	55                   	push   %rbp
    5175:	53                   	push   %rbx
    5176:	48 83 ec 08          	sub    $0x8,%rsp
    517a:	48 85 f6             	test   %rsi,%rsi
    517d:	0f 84 a6 00 00 00    	je     5229 <ad_raw_realloc+0xb9>
    5183:	4c 8d 25 36 a0 04 00 	lea    0x4a036(%rip),%r12        # 4f1c0 <ad_raw_blocks>
    518a:	48 89 f5             	mov    %rsi,%rbp
    518d:	41 89 d5             	mov    %edx,%r13d
    5190:	31 db                	xor    %ebx,%ebx
    5192:	4c 89 e0             	mov    %r12,%rax
    5195:	eb 1a                	jmp    51b1 <ad_raw_realloc+0x41>
    5197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    519e:	00 00 
    51a0:	48 83 c3 01          	add    $0x1,%rbx
    51a4:	48 83 c0 18          	add    $0x18,%rax
    51a8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51af:	74 4f                	je     5200 <ad_raw_realloc+0x90>
    51b1:	48 3b 38             	cmp    (%rax),%rdi
    51b4:	75 ea                	jne    51a0 <ad_raw_realloc+0x30>
    51b6:	48 85 ff             	test   %rdi,%rdi
    51b9:	74 0b                	je     51c6 <ad_raw_realloc+0x56>
    51bb:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51bf:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51c4:	75 57                	jne    521d <ad_raw_realloc+0xad>
    51c6:	48 89 ee             	mov    %rbp,%rsi
    51c9:	e8 e2 e3 ff ff       	call   35b0 <realloc@plt>
    51ce:	49 89 c2             	mov    %rax,%r10
    51d1:	48 85 c0             	test   %rax,%rax
    51d4:	74 16                	je     51ec <ad_raw_realloc+0x7c>
    51d6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51da:	44 89 e9             	mov    %r13d,%ecx
    51dd:	48 89 ea             	mov    %rbp,%rdx
    51e0:	4c 89 d6             	mov    %r10,%rsi
    51e3:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    51e7:	e8 f4 e9 ff ff       	call   3be0 <ad_raw_record>
    51ec:	48 83 c4 08          	add    $0x8,%rsp
    51f0:	4c 89 d0             	mov    %r10,%rax
    51f3:	5b                   	pop    %rbx
    51f4:	5d                   	pop    %rbp
    51f5:	41 5c                	pop    %r12
    51f7:	41 5d                	pop    %r13
    51f9:	c3                   	ret
    51fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5200:	48 85 ff             	test   %rdi,%rdi
    5203:	48 8d 05 08 5f 00 00 	lea    0x5f08(%rip),%rax        # b112 <_IO_stdin_used+0x112>
    520a:	48 8d 15 ec 5e 00 00 	lea    0x5eec(%rip),%rdx        # b0fd <_IO_stdin_used+0xfd>
    5211:	48 0f 45 c2          	cmovne %rdx,%rax
    5215:	48 89 c7             	mov    %rax,%rdi
    5218:	e8 c3 ed ff ff       	call   3fe0 <ad_raw_fail>
    521d:	48 8d 3d 24 5f 00 00 	lea    0x5f24(%rip),%rdi        # b148 <_IO_stdin_used+0x148>
    5224:	e8 b7 ed ff ff       	call   3fe0 <ad_raw_fail>
    5229:	48 8d 3d fd 5e 00 00 	lea    0x5efd(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    5230:	e8 ab ed ff ff       	call   3fe0 <ad_raw_fail>
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 

0000000000005240 <fwp_tape_buffers_release>:
    5240:	f3 0f 1e fa          	endbr64
    5244:	53                   	push   %rbx
    5245:	48 89 fb             	mov    %rdi,%rbx
    5248:	48 83 ec 10          	sub    $0x10,%rsp
    524c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5250:	48 85 c0             	test   %rax,%rax
    5253:	0f 88 d7 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5259:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    525d:	48 85 d2             	test   %rdx,%rdx
    5260:	0f 88 ca 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5266:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    526c:	0f 87 be 00 00 00    	ja     5330 <fwp_tape_buffers_release+0xf0>
    5272:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5276:	b8 00 00 08 00       	mov    $0x80000,%eax
    527b:	48 c1 e1 03          	shl    $0x3,%rcx
    527f:	48 29 c8             	sub    %rcx,%rax
    5282:	48 c1 e8 03          	shr    $0x3,%rax
    5286:	48 39 d0             	cmp    %rdx,%rax
    5289:	0f 82 a1 00 00 00    	jb     5330 <fwp_tape_buffers_release+0xf0>
    528f:	48 8d 3d ca 5e 00 00 	lea    0x5eca(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5296:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    529b:	48 89 14 24          	mov    %rdx,(%rsp)
    529f:	e8 ec e0 ff ff       	call   3390 <getenv@plt>
    52a4:	48 8b 14 24          	mov    (%rsp),%rdx
    52a8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52ad:	48 85 c0             	test   %rax,%rax
    52b0:	74 09                	je     52bb <fwp_tape_buffers_release+0x7b>
    52b2:	80 38 30             	cmpb   $0x30,(%rax)
    52b5:	0f 84 05 01 00 00    	je     53c0 <fwp_tape_buffers_release+0x180>
    52bb:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52bf:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52c3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52c9:	77 71                	ja     533c <fwp_tape_buffers_release+0xfc>
    52cb:	48 8d 3d ce 9d 01 00 	lea    0x19dce(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    52d2:	48 89 34 24          	mov    %rsi,(%rsp)
    52d6:	e8 45 fe ff ff       	call   5120 <fwp_tape_buffers_dispose>
    52db:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52df:	48 8b 34 24          	mov    (%rsp),%rsi
    52e3:	0f 29 05 b6 9d 01 00 	movaps %xmm0,0x19db6(%rip)        # 1f0a0 <fwp_tape_workspace>
    52ea:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    52ef:	48 89 35 92 9d 01 00 	mov    %rsi,0x19d92(%rip)        # 1f088 <fwp_tape_cached_bytes>
    52f6:	0f 29 05 b3 9d 01 00 	movaps %xmm0,0x19db3(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    52fd:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5302:	0f 29 05 b7 9d 01 00 	movaps %xmm0,0x19db7(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    5309:	48 8b 43 30          	mov    0x30(%rbx),%rax
    530d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5311:	48 89 05 b8 9d 01 00 	mov    %rax,0x19db8(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    5318:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    531f:	00 
    5320:	0f 11 03             	movups %xmm0,(%rbx)
    5323:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5327:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    532b:	eb 1e                	jmp    534b <fwp_tape_buffers_release+0x10b>
    532d:	0f 1f 00             	nopl   (%rax)
    5330:	48 8d 3d 29 5e 00 00 	lea    0x5e29(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5337:	e8 54 e0 ff ff       	call   3390 <getenv@plt>
    533c:	48 89 df             	mov    %rbx,%rdi
    533f:	e8 dc fd ff ff       	call   5120 <fwp_tape_buffers_dispose>
    5344:	48 8b 35 3d 9d 01 00 	mov    0x19d3d(%rip),%rsi        # 1f088 <fwp_tape_cached_bytes>
    534b:	48 6b 15 8d 9d 01 00 	imul   $0x68,0x19d8d(%rip),%rdx        # 1f0e0 <fwp_tapes_cap>
    5352:	68 
    5353:	48 3b 15 46 9e 04 00 	cmp    0x49e46(%rip),%rdx        # 4f1a0 <ad_raw_live>
    535a:	75 73                	jne    53cf <fwp_tape_buffers_release+0x18f>
    535c:	48 8b 05 45 9e 04 00 	mov    0x49e45(%rip),%rax        # 4f1a8 <ad_raw_live+0x8>
    5363:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5367:	48 01 d0             	add    %rdx,%rax
    536a:	48 03 05 3f 9e 04 00 	add    0x49e3f(%rip),%rax        # 4f1b0 <ad_raw_live+0x10>
    5371:	48 03 05 40 9e 04 00 	add    0x49e40(%rip),%rax        # 4f1b8 <ad_raw_live+0x18>
    5378:	48 39 c8             	cmp    %rcx,%rax
    537b:	72 52                	jb     53cf <fwp_tape_buffers_release+0x18f>
    537d:	48 8b 0d 7c 9d 01 00 	mov    0x19d7c(%rip),%rcx        # 1f100 <ad_raw_checkpoint_count>
    5384:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    538b:	74 4e                	je     53db <fwp_tape_buffers_release+0x19b>
    538d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5391:	48 29 d0             	sub    %rdx,%rax
    5394:	48 89 3d 65 9d 01 00 	mov    %rdi,0x19d65(%rip)        # 1f100 <ad_raw_checkpoint_count>
    539b:	48 29 f0             	sub    %rsi,%rax
    539e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53a2:	48 8d 0d 77 9d 01 00 	lea    0x19d77(%rip),%rcx        # 1f120 <ad_raw_checkpoints>
    53a9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53ad:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53b2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53b7:	48 83 c4 10          	add    $0x10,%rsp
    53bb:	5b                   	pop    %rbx
    53bc:	c3                   	ret
    53bd:	0f 1f 00             	nopl   (%rax)
    53c0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53c4:	0f 84 72 ff ff ff    	je     533c <fwp_tape_buffers_release+0xfc>
    53ca:	e9 ec fe ff ff       	jmp    52bb <fwp_tape_buffers_release+0x7b>
    53cf:	48 8d 3d 4a 65 00 00 	lea    0x654a(%rip),%rdi        # b920 <_IO_stdin_used+0x920>
    53d6:	e8 05 ec ff ff       	call   3fe0 <ad_raw_fail>
    53db:	48 8d 3d 8f 5d 00 00 	lea    0x5d8f(%rip),%rdi        # b171 <_IO_stdin_used+0x171>
    53e2:	e8 f9 eb ff ff       	call   3fe0 <ad_raw_fail>
    53e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53ee:	00 00 

00000000000053f0 <fwp_poll_events>:
    53f0:	53                   	push   %rbx
    53f1:	48 83 ec 20          	sub    $0x20,%rsp
    53f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    53fc:	00 00 
    53fe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5403:	31 c0                	xor    %eax,%eax
    5405:	e8 96 f1 ff ff       	call   45a0 <fwp_now_ns>
    540a:	48 8b 1d c7 23 06 00 	mov    0x623c7(%rip),%rbx        # 677d8 <fwp_timers>
    5411:	48 85 db             	test   %rbx,%rbx
    5414:	0f 84 e6 00 00 00    	je     5500 <fwp_poll_events+0x110>
    541a:	48 89 c6             	mov    %rax,%rsi
    541d:	48 89 da             	mov    %rbx,%rdx
    5420:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5427:	eb 26                	jmp    544f <fwp_poll_events+0x5f>
    5429:	90                   	nop
    542a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5431:	00 00 00 00 
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5447:	48 89 c8             	mov    %rcx,%rax
    544a:	48 85 d2             	test   %rdx,%rdx
    544d:	74 31                	je     5480 <fwp_poll_events+0x90>
    544f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5453:	48 85 c0             	test   %rax,%rax
    5456:	78 e8                	js     5440 <fwp_poll_events+0x50>
    5458:	48 39 c1             	cmp    %rax,%rcx
    545b:	7c e3                	jl     5440 <fwp_poll_events+0x50>
    545d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5464:	48 85 d2             	test   %rdx,%rdx
    5467:	74 1c                	je     5485 <fwp_poll_events+0x95>
    5469:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    546d:	48 39 c1             	cmp    %rax,%rcx
    5470:	7c ce                	jl     5440 <fwp_poll_events+0x50>
    5472:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5479:	48 85 d2             	test   %rdx,%rdx
    547c:	75 d1                	jne    544f <fwp_poll_events+0x5f>
    547e:	66 90                	xchg   %ax,%ax
    5480:	48 85 c0             	test   %rax,%rax
    5483:	78 7b                	js     5500 <fwp_poll_events+0x110>
    5485:	48 29 f0             	sub    %rsi,%rax
    5488:	48 89 c1             	mov    %rax,%rcx
    548b:	48 85 c0             	test   %rax,%rax
    548e:	0f 8e 9c 00 00 00    	jle    5530 <fwp_poll_events+0x140>
    5494:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    549b:	de 1b 43 
    549e:	48 f7 ea             	imul   %rdx
    54a1:	48 89 c8             	mov    %rcx,%rax
    54a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54a8:	48 c1 fa 12          	sar    $0x12,%rdx
    54ac:	48 29 c2             	sub    %rax,%rdx
    54af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54b6:	48 39 c1             	cmp    %rax,%rcx
    54b9:	0f 95 c0             	setne  %al
    54bc:	0f b6 c0             	movzbl %al,%eax
    54bf:	48 01 d0             	add    %rdx,%rax
    54c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54c8:	0f 8f 32 01 00 00    	jg     5600 <fwp_poll_events+0x210>
    54ce:	48 85 c0             	test   %rax,%rax
    54d1:	74 5d                	je     5530 <fwp_poll_events+0x140>
    54d3:	89 c1                	mov    %eax,%ecx
    54d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54dc:	48 c1 e9 26          	shr    $0x26,%rcx
    54e0:	48 63 d1             	movslq %ecx,%rdx
    54e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    54e9:	29 c8                	sub    %ecx,%eax
    54eb:	48 98                	cltq
    54ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    54f4:	e9 11 01 00 00       	jmp    560a <fwp_poll_events+0x21a>
    54f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5500:	e8 db e7 ff ff       	call   3ce0 <fwp_flush>
    5505:	ba 2b 00 00 00       	mov    $0x2b,%edx
    550a:	be 01 00 00 00       	mov    $0x1,%esi
    550f:	48 8b 0d 2a 9b 00 00 	mov    0x9b2a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5516:	48 8d 3d 33 64 00 00 	lea    0x6433(%rip),%rdi        # b950 <_IO_stdin_used+0x950>
    551d:	e8 3e e1 ff ff       	call   3660 <fwrite@plt>
    5522:	bf 65 00 00 00       	mov    $0x65,%edi
    5527:	e8 24 e1 ff ff       	call   3650 <exit@plt>
    552c:	0f 1f 40 00          	nopl   0x0(%rax)
    5530:	e8 6b f0 ff ff       	call   45a0 <fwp_now_ns>
    5535:	48 89 c1             	mov    %rax,%rcx
    5538:	66 0f ef c0          	pxor   %xmm0,%xmm0
    553c:	eb 44                	jmp    5582 <fwp_poll_events+0x192>
    553e:	66 90                	xchg   %ax,%ax
    5540:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5544:	75 33                	jne    5579 <fwp_poll_events+0x189>
    5546:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    554a:	75 2d                	jne    5579 <fwp_poll_events+0x189>
    554c:	48 8b 05 8d 22 06 00 	mov    0x6228d(%rip),%rax        # 677e0 <fwp_ready_tail>
    5553:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5557:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    555e:	00 00 00 00 
    5562:	48 85 c0             	test   %rax,%rax
    5565:	0f 84 05 01 00 00    	je     5670 <fwp_poll_events+0x280>
    556b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5572:	48 89 15 67 22 06 00 	mov    %rdx,0x62267(%rip)        # 677e0 <fwp_ready_tail>
    5579:	48 85 db             	test   %rbx,%rbx
    557c:	0f 84 be 00 00 00    	je     5640 <fwp_poll_events+0x250>
    5582:	48 89 da             	mov    %rbx,%rdx
    5585:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    558c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5590:	7f e7                	jg     5579 <fwp_poll_events+0x189>
    5592:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5596:	74 2e                	je     55c6 <fwp_poll_events+0x1d6>
    5598:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    559f:	48 85 c0             	test   %rax,%rax
    55a2:	0f 84 b8 00 00 00    	je     5660 <fwp_poll_events+0x270>
    55a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55af:	48 85 db             	test   %rbx,%rbx
    55b2:	74 07                	je     55bb <fwp_poll_events+0x1cb>
    55b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ce:	48 85 c0             	test   %rax,%rax
    55d1:	0f 84 69 ff ff ff    	je     5540 <fwp_poll_events+0x150>
    55d7:	48 39 c8             	cmp    %rcx,%rax
    55da:	0f 8f 60 ff ff ff    	jg     5540 <fwp_poll_events+0x150>
    55e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    55e4:	0f 85 56 ff ff ff    	jne    5540 <fwp_poll_events+0x150>
    55ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ee:	75 89                	jne    5579 <fwp_poll_events+0x189>
    55f0:	48 89 d7             	mov    %rdx,%rdi
    55f3:	e8 18 eb ff ff       	call   4110 <fwp_cancel_tree.part.0>
    55f8:	e9 43 ff ff ff       	jmp    5540 <fwp_poll_events+0x150>
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5605:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    560a:	48 89 e7             	mov    %rsp,%rdi
    560d:	31 f6                	xor    %esi,%esi
    560f:	48 89 14 24          	mov    %rdx,(%rsp)
    5613:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5618:	e8 73 de ff ff       	call   3490 <nanosleep@plt>
    561d:	48 8b 1d b4 21 06 00 	mov    0x621b4(%rip),%rbx        # 677d8 <fwp_timers>
    5624:	e8 77 ef ff ff       	call   45a0 <fwp_now_ns>
    5629:	48 89 c1             	mov    %rax,%rcx
    562c:	48 85 db             	test   %rbx,%rbx
    562f:	0f 85 03 ff ff ff    	jne    5538 <fwp_poll_events+0x148>
    5635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    563c:	00 00 00 00 
    5640:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5645:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    564c:	00 00 
    564e:	75 2c                	jne    567c <fwp_poll_events+0x28c>
    5650:	48 83 c4 20          	add    $0x20,%rsp
    5654:	5b                   	pop    %rbx
    5655:	c3                   	ret
    5656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    565d:	00 00 00 
    5660:	48 89 1d 71 21 06 00 	mov    %rbx,0x62171(%rip)        # 677d8 <fwp_timers>
    5667:	e9 43 ff ff ff       	jmp    55af <fwp_poll_events+0x1bf>
    566c:	0f 1f 40 00          	nopl   0x0(%rax)
    5670:	48 89 15 71 21 06 00 	mov    %rdx,0x62171(%rip)        # 677e8 <fwp_ready_head>
    5677:	e9 f6 fe ff ff       	jmp    5572 <fwp_poll_events+0x182>
    567c:	e8 cf dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5681:	0f 1f 40 00          	nopl   0x0(%rax)
    5685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    568c:	00 00 00 00 

0000000000005690 <fwp_rc_wide_dup>:
    5690:	48 89 fa             	mov    %rdi,%rdx
    5693:	48 8d 35 86 21 06 00 	lea    0x62186(%rip),%rsi        # 67820 <fwp_heap>
    569a:	48 83 ec 18          	sub    $0x18,%rsp
    569e:	48 89 f9             	mov    %rdi,%rcx
    56a1:	48 c1 ea 11          	shr    $0x11,%rdx
    56a5:	48 31 fa             	xor    %rdi,%rdx
    56a8:	48 89 d0             	mov    %rdx,%rax
    56ab:	48 c1 e8 09          	shr    $0x9,%rax
    56af:	48 31 c2             	xor    %rax,%rdx
    56b2:	0f b6 d2             	movzbl %dl,%edx
    56b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56bc:	00 
    56bd:	49 8b 00             	mov    (%r8),%rax
    56c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56c7:	00 00 
    56c9:	75 21                	jne    56ec <fwp_rc_wide_dup+0x5c>
    56cb:	e9 98 00 00 00       	jmp    5768 <fwp_rc_wide_dup+0xd8>
    56d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56dc:	00 00 00 00 
    56e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    56e4:	48 85 d2             	test   %rdx,%rdx
    56e7:	74 2f                	je     5718 <fwp_rc_wide_dup+0x88>
    56e9:	48 89 d0             	mov    %rdx,%rax
    56ec:	48 3b 08             	cmp    (%rax),%rcx
    56ef:	75 ef                	jne    56e0 <fwp_rc_wide_dup+0x50>
    56f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56f4:	74 7c                	je     5772 <fwp_rc_wide_dup+0xe2>
    56f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    56fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    56fe:	0f 84 91 00 00 00    	je     5795 <fwp_rc_wide_dup+0x105>
    5704:	48 83 c2 01          	add    $0x1,%rdx
    5708:	48 89 50 08          	mov    %rdx,0x8(%rax)
    570c:	48 83 c4 18          	add    $0x18,%rsp
    5710:	c3                   	ret
    5711:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5718:	4c 8d 40 10          	lea    0x10(%rax),%r8
    571c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    571f:	75 68                	jne    5789 <fwp_rc_wide_dup+0xf9>
    5721:	bf 18 00 00 00       	mov    $0x18,%edi
    5726:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    572b:	4c 89 04 24          	mov    %r8,(%rsp)
    572f:	e8 5c de ff ff       	call   3590 <malloc@plt>
    5734:	4c 8b 04 24          	mov    (%rsp),%r8
    5738:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    573d:	48 85 c0             	test   %rax,%rax
    5740:	74 5f                	je     57a1 <fwp_rc_wide_dup+0x111>
    5742:	48 89 08             	mov    %rcx,(%rax)
    5745:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    574c:	00 
    574d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5754:	00 
    5755:	49 89 00             	mov    %rax,(%r8)
    5758:	c6 01 ff             	movb   $0xff,(%rcx)
    575b:	48 83 05 05 3d 06 00 	addq   $0x1,0x63d05(%rip)        # 69468 <fwp_heap+0x1c48>
    5762:	01 
    5763:	48 83 c4 18          	add    $0x18,%rsp
    5767:	c3                   	ret
    5768:	80 3f fe             	cmpb   $0xfe,(%rdi)
    576b:	75 13                	jne    5780 <fwp_rc_wide_dup+0xf0>
    576d:	48 85 c0             	test   %rax,%rax
    5770:	74 af                	je     5721 <fwp_rc_wide_dup+0x91>
    5772:	48 8d 3d 07 62 00 00 	lea    0x6207(%rip),%rdi        # b980 <_IO_stdin_used+0x980>
    5779:	e8 b2 ec ff ff       	call   4430 <fwp_trap>
    577e:	66 90                	xchg   %ax,%ax
    5780:	48 85 c0             	test   %rax,%rax
    5783:	0f 85 6d ff ff ff    	jne    56f6 <fwp_rc_wide_dup+0x66>
    5789:	48 8d 3d 18 62 00 00 	lea    0x6218(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5790:	e8 9b ec ff ff       	call   4430 <fwp_trap>
    5795:	48 8d 3d f2 59 00 00 	lea    0x59f2(%rip),%rdi        # b18e <_IO_stdin_used+0x18e>
    579c:	e8 8f ec ff ff       	call   4430 <fwp_trap>
    57a1:	e8 6a e6 ff ff       	call   3e10 <fwp_heap_oom>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_rc_forget_slot>:
    57b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57b3:	74 0b                	je     57c0 <fwp_rc_forget_slot+0x10>
    57b5:	c3                   	ret
    57b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57bd:	00 00 00 
    57c0:	48 89 f8             	mov    %rdi,%rax
    57c3:	48 83 ec 08          	sub    $0x8,%rsp
    57c7:	48 89 fa             	mov    %rdi,%rdx
    57ca:	48 c1 e8 11          	shr    $0x11,%rax
    57ce:	48 31 f8             	xor    %rdi,%rax
    57d1:	48 89 c1             	mov    %rax,%rcx
    57d4:	48 c1 e9 09          	shr    $0x9,%rcx
    57d8:	48 31 c8             	xor    %rcx,%rax
    57db:	48 8d 0d 3e 20 06 00 	lea    0x6203e(%rip),%rcx        # 67820 <fwp_heap>
    57e2:	0f b6 c0             	movzbl %al,%eax
    57e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    57ec:	00 
    57ed:	48 85 ff             	test   %rdi,%rdi
    57f0:	74 3c                	je     582e <fwp_rc_forget_slot+0x7e>
    57f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    57f9:	00 
    57fa:	48 8b 01             	mov    (%rcx),%rax
    57fd:	eb 11                	jmp    5810 <fwp_rc_forget_slot+0x60>
    57ff:	90                   	nop
    5800:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5804:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5808:	48 85 ff             	test   %rdi,%rdi
    580b:	74 21                	je     582e <fwp_rc_forget_slot+0x7e>
    580d:	48 89 f8             	mov    %rdi,%rax
    5810:	48 3b 10             	cmp    (%rax),%rdx
    5813:	75 eb                	jne    5800 <fwp_rc_forget_slot+0x50>
    5815:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5819:	48 89 01             	mov    %rax,(%rcx)
    581c:	e8 8f db ff ff       	call   33b0 <free@plt>
    5821:	48 83 2d 3f 3c 06 00 	subq   $0x1,0x63c3f(%rip)        # 69468 <fwp_heap+0x1c48>
    5828:	01 
    5829:	48 83 c4 08          	add    $0x8,%rsp
    582d:	c3                   	ret
    582e:	48 8d 3d 73 61 00 00 	lea    0x6173(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5835:	e8 f6 eb ff ff       	call   4430 <fwp_trap>
    583a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005840 <fwp_rc_prepare_chunk>:
    5840:	48 83 3d 20 3c 06 00 	cmpq   $0x0,0x63c20(%rip)        # 69468 <fwp_heap+0x1c48>
    5847:	00 
    5848:	41 54                	push   %r12
    584a:	49 89 f4             	mov    %rsi,%r12
    584d:	55                   	push   %rbp
    584e:	48 89 fd             	mov    %rdi,%rbp
    5851:	53                   	push   %rbx
    5852:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5855:	0f 84 7d 00 00 00    	je     58d8 <fwp_rc_prepare_chunk+0x98>
    585b:	31 db                	xor    %ebx,%ebx
    585d:	85 c0                	test   %eax,%eax
    585f:	75 5f                	jne    58c0 <fwp_rc_prepare_chunk+0x80>
    5861:	48 85 f6             	test   %rsi,%rsi
    5864:	74 7c                	je     58e2 <fwp_rc_prepare_chunk+0xa2>
    5866:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    586a:	e8 41 db ff ff       	call   33b0 <free@plt>
    586f:	90                   	nop
    5870:	be 01 00 00 00       	mov    $0x1,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 93 dc ff ff       	call   3510 <calloc@plt>
    587d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5881:	48 85 c0             	test   %rax,%rax
    5884:	0f 85 87 00 00 00    	jne    5911 <fwp_rc_prepare_chunk+0xd1>
    588a:	e8 81 e5 ff ff       	call   3e10 <fwp_heap_oom>
    588f:	90                   	nop
    5890:	e8 1b ff ff ff       	call   57b0 <fwp_rc_forget_slot>
    5895:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5898:	48 83 c3 01          	add    $0x1,%rbx
    589c:	48 39 c3             	cmp    %rax,%rbx
    589f:	73 37                	jae    58d8 <fwp_rc_prepare_chunk+0x98>
    58a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58a8:	00 00 
    58aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58b1:	00 00 00 00 
    58b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58bc:	00 00 00 00 
    58c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58c4:	48 01 df             	add    %rbx,%rdi
    58c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ca:	74 c4                	je     5890 <fwp_rc_prepare_chunk+0x50>
    58cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58cf:	48 83 c3 01          	add    $0x1,%rbx
    58d3:	48 39 c3             	cmp    %rax,%rbx
    58d6:	72 e8                	jb     58c0 <fwp_rc_prepare_chunk+0x80>
    58d8:	49 39 c4             	cmp    %rax,%r12
    58db:	75 13                	jne    58f0 <fwp_rc_prepare_chunk+0xb0>
    58dd:	4d 85 e4             	test   %r12,%r12
    58e0:	75 46                	jne    5928 <fwp_rc_prepare_chunk+0xe8>
    58e2:	5b                   	pop    %rbx
    58e3:	5d                   	pop    %rbp
    58e4:	41 5c                	pop    %r12
    58e6:	c3                   	ret
    58e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58ee:	00 00 
    58f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58f4:	48 29 05 75 3b 06 00 	sub    %rax,0x63b75(%rip)        # 69470 <fwp_heap+0x1c50>
    58fb:	e8 b0 da ff ff       	call   33b0 <free@plt>
    5900:	4d 85 e4             	test   %r12,%r12
    5903:	0f 85 67 ff ff ff    	jne    5870 <fwp_rc_prepare_chunk+0x30>
    5909:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5910:	00 
    5911:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5915:	5b                   	pop    %rbx
    5916:	4c 01 25 53 3b 06 00 	add    %r12,0x63b53(%rip)        # 69470 <fwp_heap+0x1c50>
    591d:	5d                   	pop    %rbp
    591e:	41 5c                	pop    %r12
    5920:	c3                   	ret
    5921:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5928:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    592c:	5b                   	pop    %rbx
    592d:	4c 89 e2             	mov    %r12,%rdx
    5930:	31 f6                	xor    %esi,%esi
    5932:	5d                   	pop    %rbp
    5933:	41 5c                	pop    %r12
    5935:	e9 76 db ff ff       	jmp    34b0 <memset@plt>
    593a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005940 <fwp_heap_refill>:
    5940:	41 56                	push   %r14
    5942:	41 89 d6             	mov    %edx,%r14d
    5945:	41 55                	push   %r13
    5947:	41 89 f5             	mov    %esi,%r13d
    594a:	41 54                	push   %r12
    594c:	49 89 fc             	mov    %rdi,%r12
    594f:	bf 01 00 00 00       	mov    $0x1,%edi
    5954:	55                   	push   %rbp
    5955:	53                   	push   %rbx
    5956:	e8 f5 e4 ff ff       	call   3e50 <fwp_heap_chunks>
    595b:	48 89 c3             	mov    %rax,%rbx
    595e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5962:	48 8b 05 af 32 06 00 	mov    0x632af(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    5969:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    596d:	48 8d 05 ac 1e 06 00 	lea    0x61eac(%rip),%rax        # 67820 <fwp_heap>
    5974:	31 d2                	xor    %edx,%edx
    5976:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    597a:	48 89 ef             	mov    %rbp,%rdi
    597d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5981:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5985:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    598c:	00 
    598d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5992:	f7 f1                	div    %ecx
    5994:	31 d2                	xor    %edx,%edx
    5996:	66 0f 6e c1          	movd   %ecx,%xmm0
    599a:	66 0f 6e c8          	movd   %eax,%xmm1
    599e:	89 c6                	mov    %eax,%esi
    59a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59a5:	48 01 c8             	add    %rcx,%rax
    59a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59ac:	48 f7 f1             	div    %rcx
    59af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59b4:	89 45 18             	mov    %eax,0x18(%rbp)
    59b7:	e8 84 fe ff ff       	call   5840 <fwp_rc_prepare_chunk>
    59bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59bf:	48 89 d8             	mov    %rbx,%rax
    59c2:	48 c1 e0 10          	shl    $0x10,%rax
    59c6:	48 03 05 03 32 06 00 	add    0x63203(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    59cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59d6:	8b 55 08             	mov    0x8(%rbp),%edx
    59d9:	48 0f af d1          	imul   %rcx,%rdx
    59dd:	48 01 c2             	add    %rax,%rdx
    59e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    59e5:	5b                   	pop    %rbx
    59e6:	5d                   	pop    %rbp
    59e7:	41 5c                	pop    %r12
    59e9:	41 5d                	pop    %r13
    59eb:	41 5e                	pop    %r14
    59ed:	c3                   	ret
    59ee:	66 90                	xchg   %ax,%ax

00000000000059f0 <fwp_mem_free>:
    59f0:	48 85 ff             	test   %rdi,%rdi
    59f3:	0f 84 17 02 00 00    	je     5c10 <fwp_mem_free+0x220>
    59f9:	48 8b 35 d0 31 06 00 	mov    0x631d0(%rip),%rsi        # 68bd0 <fwp_heap+0x13b0>
    5a00:	48 8b 05 f1 31 06 00 	mov    0x631f1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    5a07:	48 89 fa             	mov    %rdi,%rdx
    5a0a:	48 29 f2             	sub    %rsi,%rdx
    5a0d:	48 c1 e0 10          	shl    $0x10,%rax
    5a11:	48 39 c2             	cmp    %rax,%rdx
    5a14:	0f 83 f6 01 00 00    	jae    5c10 <fwp_mem_free+0x220>
    5a1a:	49 89 d1             	mov    %rdx,%r9
    5a1d:	49 c1 e9 10          	shr    $0x10,%r9
    5a21:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a25:	48 c1 e0 03          	shl    $0x3,%rax
    5a29:	49 89 c0             	mov    %rax,%r8
    5a2c:	4c 03 05 e5 31 06 00 	add    0x631e5(%rip),%r8        # 68c18 <fwp_heap+0x13f8>
    5a33:	0f 84 d7 01 00 00    	je     5c10 <fwp_mem_free+0x220>
    5a39:	48 83 ec 38          	sub    $0x38,%rsp
    5a3d:	48 89 f9             	mov    %rdi,%rcx
    5a40:	41 0f b6 38          	movzbl (%r8),%edi
    5a44:	40 80 ff 01          	cmp    $0x1,%dil
    5a48:	74 16                	je     5a60 <fwp_mem_free+0x70>
    5a4a:	40 80 ff 02          	cmp    $0x2,%dil
    5a4e:	0f 84 94 00 00 00    	je     5ae8 <fwp_mem_free+0xf8>
    5a54:	48 83 c4 38          	add    $0x38,%rsp
    5a58:	c3                   	ret
    5a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a60:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a64:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a69:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a6e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a72:	4d 85 d2             	test   %r10,%r10
    5a75:	74 1d                	je     5a94 <fwp_mem_free+0xa4>
    5a77:	0f b7 c1             	movzwl %cx,%eax
    5a7a:	31 d2                	xor    %edx,%edx
    5a7c:	48 f7 f7             	div    %rdi
    5a7f:	49 01 c2             	add    %rax,%r10
    5a82:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5a86:	0f 84 44 01 00 00    	je     5bd0 <fwp_mem_free+0x1e0>
    5a8c:	41 c6 02 00          	movb   $0x0,(%r10)
    5a90:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a94:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a9b:	49 63 c1             	movslq %r9d,%rax
    5a9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5aa2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5aa6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5aab:	f2 0f 58 05 ad 31 06 	addsd  0x631ad(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5ab2:	00 
    5ab3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ab7:	48 8d 05 62 1d 06 00 	lea    0x61d62(%rip),%rax        # 67820 <fwp_heap>
    5abe:	48 01 d0             	add    %rdx,%rax
    5ac1:	48 8b 10             	mov    (%rax),%rdx
    5ac4:	48 f7 d2             	not    %rdx
    5ac7:	48 89 11             	mov    %rdx,(%rcx)
    5aca:	48 89 08             	mov    %rcx,(%rax)
    5acd:	48 29 3d 6c 31 06 00 	sub    %rdi,0x6316c(%rip)        # 68c40 <fwp_heap+0x1420>
    5ad4:	f2 0f 11 05 84 31 06 	movsd  %xmm0,0x63184(%rip)        # 68c60 <fwp_heap+0x1440>
    5adb:	00 
    5adc:	48 83 c4 38          	add    $0x38,%rsp
    5ae0:	c3                   	ret
    5ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae8:	66 31 d2             	xor    %dx,%dx
    5aeb:	48 01 d6             	add    %rdx,%rsi
    5aee:	48 39 f1             	cmp    %rsi,%rcx
    5af1:	0f 85 5d ff ff ff    	jne    5a54 <fwp_mem_free+0x64>
    5af7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5afb:	48 29 15 3e 31 06 00 	sub    %rdx,0x6313e(%rip)        # 68c40 <fwp_heap+0x1420>
    5b02:	48 85 d2             	test   %rdx,%rdx
    5b05:	0f 88 a5 00 00 00    	js     5bb0 <fwp_mem_free+0x1c0>
    5b0b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b0f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b14:	f2 0f 58 05 44 31 06 	addsd  0x63144(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5b1b:	00 
    5b1c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b20:	f2 0f 11 05 38 31 06 	movsd  %xmm0,0x63138(%rip)        # 68c60 <fwp_heap+0x1440>
    5b27:	00 
    5b28:	48 85 d2             	test   %rdx,%rdx
    5b2b:	74 0c                	je     5b39 <fwp_mem_free+0x149>
    5b2d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b30:	0f 84 db 00 00 00    	je     5c11 <fwp_mem_free+0x221>
    5b36:	c6 02 00             	movb   $0x0,(%rdx)
    5b39:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b3d:	48 85 c9             	test   %rcx,%rcx
    5b40:	74 3e                	je     5b80 <fwp_mem_free+0x190>
    5b42:	48 8b 15 cf 30 06 00 	mov    0x630cf(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    5b49:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b51:	48 01 d0             	add    %rdx,%rax
    5b54:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b58:	48 89 d6             	mov    %rdx,%rsi
    5b5b:	48 29 c6             	sub    %rax,%rsi
    5b5e:	83 e6 08             	and    $0x8,%esi
    5b61:	74 0d                	je     5b70 <fwp_mem_free+0x180>
    5b63:	c6 00 00             	movb   $0x0,(%rax)
    5b66:	48 83 c0 28          	add    $0x28,%rax
    5b6a:	48 39 c2             	cmp    %rax,%rdx
    5b6d:	74 11                	je     5b80 <fwp_mem_free+0x190>
    5b6f:	90                   	nop
    5b70:	c6 00 00             	movb   $0x0,(%rax)
    5b73:	48 83 c0 50          	add    $0x50,%rax
    5b77:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b7b:	48 39 c2             	cmp    %rax,%rdx
    5b7e:	75 f0                	jne    5b70 <fwp_mem_free+0x180>
    5b80:	48 01 0d c9 30 06 00 	add    %rcx,0x630c9(%rip)        # 68c50 <fwp_heap+0x1430>
    5b87:	4c 3b 0d 82 30 06 00 	cmp    0x63082(%rip),%r9        # 68c10 <fwp_heap+0x13f0>
    5b8e:	73 07                	jae    5b97 <fwp_mem_free+0x1a7>
    5b90:	4c 89 0d 79 30 06 00 	mov    %r9,0x63079(%rip)        # 68c10 <fwp_heap+0x13f0>
    5b97:	4c 3b 0d 6a 30 06 00 	cmp    0x6306a(%rip),%r9        # 68c08 <fwp_heap+0x13e8>
    5b9e:	0f 83 b0 fe ff ff    	jae    5a54 <fwp_mem_free+0x64>
    5ba4:	4c 89 0d 5d 30 06 00 	mov    %r9,0x6305d(%rip)        # 68c08 <fwp_heap+0x13e8>
    5bab:	e9 a4 fe ff ff       	jmp    5a54 <fwp_mem_free+0x64>
    5bb0:	48 89 d1             	mov    %rdx,%rcx
    5bb3:	83 e2 01             	and    $0x1,%edx
    5bb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bba:	48 d1 e9             	shr    $1,%rcx
    5bbd:	48 09 d1             	or     %rdx,%rcx
    5bc0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5bc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5bc9:	e9 46 ff ff ff       	jmp    5b14 <fwp_mem_free+0x124>
    5bce:	66 90                	xchg   %ax,%ax
    5bd0:	4c 89 d7             	mov    %r10,%rdi
    5bd3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bd8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bdd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5be2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5be6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5beb:	e8 c0 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5bf0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5bf5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5bfa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5bff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c09:	e9 7e fe ff ff       	jmp    5a8c <fwp_mem_free+0x9c>
    5c0e:	66 90                	xchg   %ax,%ax
    5c10:	c3                   	ret
    5c11:	48 89 d7             	mov    %rdx,%rdi
    5c14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c28:	e8 83 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5c2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c41:	e9 f0 fe ff ff       	jmp    5b36 <fwp_mem_free+0x146>
    5c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c4d:	00 00 00 

0000000000005c50 <fwp_heap_alloc_big>:
    5c50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c57:	00 00 40 
    5c5a:	41 57                	push   %r15
    5c5c:	41 56                	push   %r14
    5c5e:	41 55                	push   %r13
    5c60:	41 54                	push   %r12
    5c62:	55                   	push   %rbp
    5c63:	53                   	push   %rbx
    5c64:	48 83 ec 08          	sub    $0x8,%rsp
    5c68:	48 39 f8             	cmp    %rdi,%rax
    5c6b:	0f 82 fa 00 00 00    	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5c71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c78:	49 89 fd             	mov    %rdi,%r13
    5c7b:	41 89 f6             	mov    %esi,%r14d
    5c7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5c82:	48 89 ef             	mov    %rbp,%rdi
    5c85:	e8 c6 e1 ff ff       	call   3e50 <fwp_heap_chunks>
    5c8a:	be 01 00 00 00       	mov    $0x1,%esi
    5c8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5c93:	49 89 c4             	mov    %rax,%r12
    5c96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5c9d:	00 
    5c9e:	48 03 3d 73 2f 06 00 	add    0x62f73(%rip),%rdi        # 68c18 <fwp_heap+0x13f8>
    5ca5:	c6 07 02             	movb   $0x2,(%rdi)
    5ca8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5cac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5caf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cb3:	e8 88 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cb8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cbc:	76 47                	jbe    5d05 <fwp_heap_alloc_big+0xb5>
    5cbe:	4c 01 e5             	add    %r12,%rbp
    5cc1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5cc8:	00 
    5cc9:	4c 8d 3d 50 1b 06 00 	lea    0x61b50(%rip),%r15        # 67820 <fwp_heap>
    5cd0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cd5:	49 c1 e6 03          	shl    $0x3,%r14
    5cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ce0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ce7:	31 f6                	xor    %esi,%esi
    5ce9:	48 01 dd             	add    %rbx,%rbp
    5cec:	48 83 c3 28          	add    $0x28,%rbx
    5cf0:	48 89 ef             	mov    %rbp,%rdi
    5cf3:	e8 48 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cf8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5cfc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d00:	49 39 de             	cmp    %rbx,%r14
    5d03:	75 db                	jne    5ce0 <fwp_heap_alloc_big+0x90>
    5d05:	49 c1 e4 10          	shl    $0x10,%r12
    5d09:	4c 03 25 c0 2e 06 00 	add    0x62ec0(%rip),%r12        # 68bd0 <fwp_heap+0x13b0>
    5d10:	4c 89 ea             	mov    %r13,%rdx
    5d13:	31 f6                	xor    %esi,%esi
    5d15:	4c 89 e7             	mov    %r12,%rdi
    5d18:	e8 93 d7 ff ff       	call   34b0 <memset@plt>
    5d1d:	4c 89 e8             	mov    %r13,%rax
    5d20:	48 03 05 19 2f 06 00 	add    0x62f19(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5d27:	72 42                	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5d29:	48 39 05 18 2f 06 00 	cmp    %rax,0x62f18(%rip)        # 68c48 <fwp_heap+0x1428>
    5d30:	48 89 05 09 2f 06 00 	mov    %rax,0x62f09(%rip)        # 68c40 <fwp_heap+0x1420>
    5d37:	73 07                	jae    5d40 <fwp_heap_alloc_big+0xf0>
    5d39:	48 89 05 08 2f 06 00 	mov    %rax,0x62f08(%rip)        # 68c48 <fwp_heap+0x1428>
    5d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d44:	4c 89 e0             	mov    %r12,%rax
    5d47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d4c:	f2 0f 58 05 04 2f 06 	addsd  0x62f04(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5d53:	00 
    5d54:	f2 0f 11 05 fc 2e 06 	movsd  %xmm0,0x62efc(%rip)        # 68c58 <fwp_heap+0x1438>
    5d5b:	00 
    5d5c:	48 83 c4 08          	add    $0x8,%rsp
    5d60:	5b                   	pop    %rbx
    5d61:	5d                   	pop    %rbp
    5d62:	41 5c                	pop    %r12
    5d64:	41 5d                	pop    %r13
    5d66:	41 5e                	pop    %r14
    5d68:	41 5f                	pop    %r15
    5d6a:	c3                   	ret
    5d6b:	e8 a0 e0 ff ff       	call   3e10 <fwp_heap_oom>

0000000000005d70 <fwp_heap_alloc_slow>:
    5d70:	53                   	push   %rbx
    5d71:	48 89 f9             	mov    %rdi,%rcx
    5d74:	41 89 f1             	mov    %esi,%r9d
    5d77:	48 83 ec 10          	sub    $0x10,%rsp
    5d7b:	8b 05 43 2e 06 00    	mov    0x62e43(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5d81:	85 c0                	test   %eax,%eax
    5d83:	0f 84 c7 00 00 00    	je     5e50 <fwp_heap_alloc_slow+0xe0>
    5d89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5d90:	0f 87 dd 00 00 00    	ja     5e73 <fwp_heap_alloc_slow+0x103>
    5d96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5d9a:	48 8d 3d 7f 1a 06 00 	lea    0x61a7f(%rip),%rdi        # 67820 <fwp_heap>
    5da1:	49 63 f1             	movslq %r9d,%rsi
    5da4:	48 c1 e8 04          	shr    $0x4,%rax
    5da8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5daf:	00 00 
    5db1:	41 0f b6 c2          	movzbl %r10b,%eax
    5db5:	4c 89 d2             	mov    %r10,%rdx
    5db8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5dbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5dc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dce:	48 01 f8             	add    %rdi,%rax
    5dd1:	4c 8b 00             	mov    (%rax),%r8
    5dd4:	4d 85 c0             	test   %r8,%r8
    5dd7:	0f 84 ab 00 00 00    	je     5e88 <fwp_heap_alloc_slow+0x118>
    5ddd:	49 8b 10             	mov    (%r8),%rdx
    5de0:	48 f7 d2             	not    %rdx
    5de3:	48 89 10             	mov    %rdx,(%rax)
    5de6:	41 83 f9 01          	cmp    $0x1,%r9d
    5dea:	4c 89 c7             	mov    %r8,%rdi
    5ded:	48 0f 45 cb          	cmovne %rbx,%rcx
    5df1:	31 f6                	xor    %esi,%esi
    5df3:	48 89 ca             	mov    %rcx,%rdx
    5df6:	e8 b5 d6 ff ff       	call   34b0 <memset@plt>
    5dfb:	49 89 c0             	mov    %rax,%r8
    5dfe:	48 89 d8             	mov    %rbx,%rax
    5e01:	48 03 05 38 2e 06 00 	add    0x62e38(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5e08:	0f 82 d9 00 00 00    	jb     5ee7 <fwp_heap_alloc_slow+0x177>
    5e0e:	48 39 05 33 2e 06 00 	cmp    %rax,0x62e33(%rip)        # 68c48 <fwp_heap+0x1428>
    5e15:	48 89 05 24 2e 06 00 	mov    %rax,0x62e24(%rip)        # 68c40 <fwp_heap+0x1420>
    5e1c:	73 07                	jae    5e25 <fwp_heap_alloc_slow+0xb5>
    5e1e:	48 89 05 23 2e 06 00 	mov    %rax,0x62e23(%rip)        # 68c48 <fwp_heap+0x1428>
    5e25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e29:	4c 89 c0             	mov    %r8,%rax
    5e2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e31:	f2 0f 58 05 1f 2e 06 	addsd  0x62e1f(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5e38:	00 
    5e39:	f2 0f 11 05 17 2e 06 	movsd  %xmm0,0x62e17(%rip)        # 68c58 <fwp_heap+0x1438>
    5e40:	00 
    5e41:	48 83 c4 10          	add    $0x10,%rsp
    5e45:	5b                   	pop    %rbx
    5e46:	c3                   	ret
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e58:	e8 53 ef ff ff       	call   4db0 <fwp_heap_init>
    5e5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e6d:	0f 86 23 ff ff ff    	jbe    5d96 <fwp_heap_alloc_slow+0x26>
    5e73:	48 83 c4 10          	add    $0x10,%rsp
    5e77:	44 89 ce             	mov    %r9d,%esi
    5e7a:	48 89 cf             	mov    %rcx,%rdi
    5e7d:	5b                   	pop    %rbx
    5e7e:	e9 cd fd ff ff       	jmp    5c50 <fwp_heap_alloc_big>
    5e83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5e8c:	4d 85 c0             	test   %r8,%r8
    5e8f:	74 1f                	je     5eb0 <fwp_heap_alloc_slow+0x140>
    5e91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5e95:	4d 29 c3             	sub    %r8,%r11
    5e98:	49 39 db             	cmp    %rbx,%r11
    5e9b:	72 13                	jb     5eb0 <fwp_heap_alloc_slow+0x140>
    5e9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ea1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ea5:	e9 3c ff ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5eb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5eb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5ebb:	44 89 ca             	mov    %r9d,%edx
    5ebe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ec3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ec7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ecb:	44 89 d6             	mov    %r10d,%esi
    5ece:	48 01 c7             	add    %rax,%rdi
    5ed1:	e8 6a fa ff ff       	call   5940 <fwp_heap_refill>
    5ed6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5edb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5edf:	49 89 c0             	mov    %rax,%r8
    5ee2:	e9 ff fe ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5ee7:	e8 24 df ff ff       	call   3e10 <fwp_heap_oom>
    5eec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ef0 <fwp_heap_alloc>:
    5ef0:	53                   	push   %rbx
    5ef1:	48 89 fa             	mov    %rdi,%rdx
    5ef4:	48 83 ec 10          	sub    $0x10,%rsp
    5ef8:	8b 1d ea 35 06 00    	mov    0x635ea(%rip),%ebx        # 694e8 <iteration_active>
    5efe:	8b 05 c0 2c 06 00    	mov    0x62cc0(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5f04:	85 db                	test   %ebx,%ebx
    5f06:	0f 85 04 01 00 00    	jne    6010 <fwp_heap_alloc+0x120>
    5f0c:	85 c0                	test   %eax,%eax
    5f0e:	0f 84 ac 01 00 00    	je     60c0 <fwp_heap_alloc+0x1d0>
    5f14:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f1b:	0f 87 9f 01 00 00    	ja     60c0 <fwp_heap_alloc+0x1d0>
    5f21:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f25:	48 8d 05 f4 18 06 00 	lea    0x618f4(%rip),%rax        # 67820 <fwp_heap>
    5f2c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f30:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f37:	00 
    5f38:	48 63 ce             	movslq %esi,%rcx
    5f3b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f42:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f49:	00 
    5f4a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f4e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f52:	48 01 c8             	add    %rcx,%rax
    5f55:	48 8b 08             	mov    (%rax),%rcx
    5f58:	48 85 c9             	test   %rcx,%rcx
    5f5b:	0f 84 ff 00 00 00    	je     6060 <fwp_heap_alloc+0x170>
    5f61:	48 8b 39             	mov    (%rcx),%rdi
    5f64:	48 f7 d7             	not    %rdi
    5f67:	48 89 38             	mov    %rdi,(%rax)
    5f6a:	83 fe 01             	cmp    $0x1,%esi
    5f6d:	48 89 cf             	mov    %rcx,%rdi
    5f70:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f75:	49 0f 45 d0          	cmovne %r8,%rdx
    5f79:	31 f6                	xor    %esi,%esi
    5f7b:	e8 30 d5 ff ff       	call   34b0 <memset@plt>
    5f80:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5f85:	48 89 c1             	mov    %rax,%rcx
    5f88:	4c 89 c0             	mov    %r8,%rax
    5f8b:	48 03 05 ae 2c 06 00 	add    0x62cae(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5f92:	0f 82 35 01 00 00    	jb     60cd <fwp_heap_alloc+0x1dd>
    5f98:	48 39 05 a9 2c 06 00 	cmp    %rax,0x62ca9(%rip)        # 68c48 <fwp_heap+0x1428>
    5f9f:	48 89 05 9a 2c 06 00 	mov    %rax,0x62c9a(%rip)        # 68c40 <fwp_heap+0x1420>
    5fa6:	73 07                	jae    5faf <fwp_heap_alloc+0xbf>
    5fa8:	48 89 05 99 2c 06 00 	mov    %rax,0x62c99(%rip)        # 68c48 <fwp_heap+0x1428>
    5faf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fb3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fb8:	f2 0f 58 05 98 2c 06 	addsd  0x62c98(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5fbf:	00 
    5fc0:	f2 0f 11 05 90 2c 06 	movsd  %xmm0,0x62c90(%rip)        # 68c58 <fwp_heap+0x1438>
    5fc7:	00 
    5fc8:	85 db                	test   %ebx,%ebx
    5fca:	74 33                	je     5fff <fwp_heap_alloc+0x10f>
    5fcc:	48 8b 05 6d 2c 06 00 	mov    0x62c6d(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5fd3:	48 85 c0             	test   %rax,%rax
    5fd6:	0f 88 ac 00 00 00    	js     6088 <fwp_heap_alloc+0x198>
    5fdc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fe0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5fe5:	f2 0f 5c 05 db 34 06 	subsd  0x634db(%rip),%xmm0        # 694c8 <iteration_start_charge>
    5fec:	00 
    5fed:	66 0f 2f 05 cb 34 06 	comisd 0x634cb(%rip),%xmm0        # 694c0 <iteration_peak>
    5ff4:	00 
    5ff5:	76 08                	jbe    5fff <fwp_heap_alloc+0x10f>
    5ff7:	f2 0f 11 05 c1 34 06 	movsd  %xmm0,0x634c1(%rip)        # 694c0 <iteration_peak>
    5ffe:	00 
    5fff:	48 83 c4 10          	add    $0x10,%rsp
    6003:	48 89 c8             	mov    %rcx,%rax
    6006:	5b                   	pop    %rbx
    6007:	c3                   	ret
    6008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    600f:	00 
    6010:	85 f6                	test   %esi,%esi
    6012:	74 34                	je     6048 <fwp_heap_alloc+0x158>
    6014:	48 83 05 c4 34 06 00 	addq   $0x1,0x634c4(%rip)        # 694e0 <iteration_requests>
    601b:	01 
    601c:	48 01 3d b5 34 06 00 	add    %rdi,0x634b5(%rip)        # 694d8 <iteration_bytes>
    6023:	85 c0                	test   %eax,%eax
    6025:	74 0d                	je     6034 <fwp_heap_alloc+0x144>
    6027:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    602e:	0f 86 ed fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6034:	48 89 d7             	mov    %rdx,%rdi
    6037:	e8 34 fd ff ff       	call   5d70 <fwp_heap_alloc_slow>
    603c:	48 89 c1             	mov    %rax,%rcx
    603f:	eb 8b                	jmp    5fcc <fwp_heap_alloc+0xdc>
    6041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6048:	85 c0                	test   %eax,%eax
    604a:	74 0d                	je     6059 <fwp_heap_alloc+0x169>
    604c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6053:	0f 86 c8 fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6059:	31 f6                	xor    %esi,%esi
    605b:	eb d7                	jmp    6034 <fwp_heap_alloc+0x144>
    605d:	0f 1f 00             	nopl   (%rax)
    6060:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6064:	48 85 c9             	test   %rcx,%rcx
    6067:	74 0c                	je     6075 <fwp_heap_alloc+0x185>
    6069:	48 8b 78 10          	mov    0x10(%rax),%rdi
    606d:	48 29 cf             	sub    %rcx,%rdi
    6070:	4c 39 c7             	cmp    %r8,%rdi
    6073:	73 3b                	jae    60b0 <fwp_heap_alloc+0x1c0>
    6075:	48 89 d7             	mov    %rdx,%rdi
    6078:	e8 f3 fc ff ff       	call   5d70 <fwp_heap_alloc_slow>
    607d:	48 89 c1             	mov    %rax,%rcx
    6080:	e9 43 ff ff ff       	jmp    5fc8 <fwp_heap_alloc+0xd8>
    6085:	0f 1f 00             	nopl   (%rax)
    6088:	48 89 c2             	mov    %rax,%rdx
    608b:	83 e0 01             	and    $0x1,%eax
    608e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6092:	48 d1 ea             	shr    $1,%rdx
    6095:	48 09 c2             	or     %rax,%rdx
    6098:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    609d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60a1:	e9 3f ff ff ff       	jmp    5fe5 <fwp_heap_alloc+0xf5>
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 
    60b0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60b4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60b8:	e9 ad fe ff ff       	jmp    5f6a <fwp_heap_alloc+0x7a>
    60bd:	0f 1f 00             	nopl   (%rax)
    60c0:	48 83 c4 10          	add    $0x10,%rsp
    60c4:	48 89 d7             	mov    %rdx,%rdi
    60c7:	5b                   	pop    %rbx
    60c8:	e9 a3 fc ff ff       	jmp    5d70 <fwp_heap_alloc_slow>
    60cd:	e8 3e dd ff ff       	call   3e10 <fwp_heap_oom>
    60d2:	0f 1f 00             	nopl   (%rax)
    60d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60dc:	00 00 00 00 

00000000000060e0 <fwp_data.part.0.constprop.0>:
    60e0:	41 56                	push   %r14
    60e2:	8b 05 dc 2a 06 00    	mov    0x62adc(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    60e8:	41 89 fe             	mov    %edi,%r14d
    60eb:	41 55                	push   %r13
    60ed:	44 8b 2d f4 33 06 00 	mov    0x633f4(%rip),%r13d        # 694e8 <iteration_active>
    60f4:	41 54                	push   %r12
    60f6:	49 89 f4             	mov    %rsi,%r12
    60f9:	55                   	push   %rbp
    60fa:	53                   	push   %rbx
    60fb:	45 85 ed             	test   %r13d,%r13d
    60fe:	0f 84 1c 01 00 00    	je     6220 <fwp_data.part.0.constprop.0+0x140>
    6104:	48 83 05 d4 33 06 00 	addq   $0x1,0x633d4(%rip)        # 694e0 <iteration_requests>
    610b:	01 
    610c:	48 83 05 c4 33 06 00 	addq   $0x18,0x633c4(%rip)        # 694d8 <iteration_bytes>
    6113:	18 
    6114:	85 c0                	test   %eax,%eax
    6116:	0f 84 8c 01 00 00    	je     62a8 <fwp_data.part.0.constprop.0+0x1c8>
    611c:	0f b6 05 9f 26 06 00 	movzbl 0x6269f(%rip),%eax        # 687c2 <fwp_heap+0xfa2>
    6123:	48 8d 15 f6 16 06 00 	lea    0x616f6(%rip),%rdx        # 67820 <fwp_heap>
    612a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6131:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6135:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6139:	48 8b 18             	mov    (%rax),%rbx
    613c:	48 85 db             	test   %rbx,%rbx
    613f:	0f 84 fb 00 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x160>
    6145:	48 8b 13             	mov    (%rbx),%rdx
    6148:	48 f7 d2             	not    %rdx
    614b:	48 89 10             	mov    %rdx,(%rax)
    614e:	48 83 fd 18          	cmp    $0x18,%rbp
    6152:	76 1b                	jbe    616f <fwp_data.part.0.constprop.0+0x8f>
    6154:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6158:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    615c:	31 f6                	xor    %esi,%esi
    615e:	48 c1 e8 03          	shr    $0x3,%rax
    6162:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6169:	00 
    616a:	e8 41 d3 ff ff       	call   34b0 <memset@plt>
    616f:	48 89 e8             	mov    %rbp,%rax
    6172:	48 03 05 c7 2a 06 00 	add    0x62ac7(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    6179:	0f 82 3d 01 00 00    	jb     62bc <fwp_data.part.0.constprop.0+0x1dc>
    617f:	48 39 05 c2 2a 06 00 	cmp    %rax,0x62ac2(%rip)        # 68c48 <fwp_heap+0x1428>
    6186:	48 89 05 b3 2a 06 00 	mov    %rax,0x62ab3(%rip)        # 68c40 <fwp_heap+0x1420>
    618d:	73 07                	jae    6196 <fwp_data.part.0.constprop.0+0xb6>
    618f:	48 89 05 b2 2a 06 00 	mov    %rax,0x62ab2(%rip)        # 68c48 <fwp_heap+0x1428>
    6196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    619a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    619f:	f2 0f 58 05 b1 2a 06 	addsd  0x62ab1(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    61a6:	00 
    61a7:	f2 0f 11 05 a9 2a 06 	movsd  %xmm0,0x62aa9(%rip)        # 68c58 <fwp_heap+0x1438>
    61ae:	00 
    61af:	45 85 ed             	test   %r13d,%r13d
    61b2:	74 33                	je     61e7 <fwp_data.part.0.constprop.0+0x107>
    61b4:	48 8b 05 85 2a 06 00 	mov    0x62a85(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    61bb:	48 85 c0             	test   %rax,%rax
    61be:	0f 88 a4 00 00 00    	js     6268 <fwp_data.part.0.constprop.0+0x188>
    61c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61c8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61cd:	f2 0f 5c 05 f3 32 06 	subsd  0x632f3(%rip),%xmm0        # 694c8 <iteration_start_charge>
    61d4:	00 
    61d5:	66 0f 2f 05 e3 32 06 	comisd 0x632e3(%rip),%xmm0        # 694c0 <iteration_peak>
    61dc:	00 
    61dd:	76 08                	jbe    61e7 <fwp_data.part.0.constprop.0+0x107>
    61df:	f2 0f 11 05 d9 32 06 	movsd  %xmm0,0x632d9(%rip)        # 694c0 <iteration_peak>
    61e6:	00 
    61e7:	b8 02 00 00 00       	mov    $0x2,%eax
    61ec:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    61f1:	66 0f 6e c8          	movd   %eax,%xmm1
    61f5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    61f9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    61fd:	49 8b 04 24          	mov    (%r12),%rax
    6201:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6205:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    620a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    620e:	48 89 d8             	mov    %rbx,%rax
    6211:	5b                   	pop    %rbx
    6212:	5d                   	pop    %rbp
    6213:	41 5c                	pop    %r12
    6215:	41 5d                	pop    %r13
    6217:	41 5e                	pop    %r14
    6219:	c3                   	ret
    621a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6220:	85 c0                	test   %eax,%eax
    6222:	0f 85 f4 fe ff ff    	jne    611c <fwp_data.part.0.constprop.0+0x3c>
    6228:	31 f6                	xor    %esi,%esi
    622a:	bf 18 00 00 00       	mov    $0x18,%edi
    622f:	e8 bc fc ff ff       	call   5ef0 <fwp_heap_alloc>
    6234:	48 89 c3             	mov    %rax,%rbx
    6237:	eb ae                	jmp    61e7 <fwp_data.part.0.constprop.0+0x107>
    6239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6240:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6244:	48 85 db             	test   %rbx,%rbx
    6247:	74 47                	je     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6249:	48 8b 50 10          	mov    0x10(%rax),%rdx
    624d:	48 29 da             	sub    %rbx,%rdx
    6250:	48 39 ea             	cmp    %rbp,%rdx
    6253:	72 3b                	jb     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6255:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6259:	48 89 50 08          	mov    %rdx,0x8(%rax)
    625d:	e9 ec fe ff ff       	jmp    614e <fwp_data.part.0.constprop.0+0x6e>
    6262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6268:	48 89 c2             	mov    %rax,%rdx
    626b:	83 e0 01             	and    $0x1,%eax
    626e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6272:	48 d1 ea             	shr    $1,%rdx
    6275:	48 09 c2             	or     %rax,%rdx
    6278:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    627d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6281:	e9 47 ff ff ff       	jmp    61cd <fwp_data.part.0.constprop.0+0xed>
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 
    6290:	31 f6                	xor    %esi,%esi
    6292:	bf 18 00 00 00       	mov    $0x18,%edi
    6297:	e8 54 fc ff ff       	call   5ef0 <fwp_heap_alloc>
    629c:	48 89 c3             	mov    %rax,%rbx
    629f:	e9 0b ff ff ff       	jmp    61af <fwp_data.part.0.constprop.0+0xcf>
    62a4:	0f 1f 40 00          	nopl   0x0(%rax)
    62a8:	31 f6                	xor    %esi,%esi
    62aa:	bf 18 00 00 00       	mov    $0x18,%edi
    62af:	e8 3c fc ff ff       	call   5ef0 <fwp_heap_alloc>
    62b4:	48 89 c3             	mov    %rax,%rbx
    62b7:	e9 f8 fe ff ff       	jmp    61b4 <fwp_data.part.0.constprop.0+0xd4>
    62bc:	e8 4f db ff ff       	call   3e10 <fwp_heap_oom>
    62c1:	0f 1f 40 00          	nopl   0x0(%rax)
    62c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62cc:	00 00 00 00 

00000000000062d0 <fwp_p_ad_push>:
    62d0:	41 57                	push   %r15
    62d2:	41 56                	push   %r14
    62d4:	41 55                	push   %r13
    62d6:	49 89 d5             	mov    %rdx,%r13
    62d9:	41 54                	push   %r12
    62db:	49 89 fc             	mov    %rdi,%r12
    62de:	55                   	push   %rbp
    62df:	53                   	push   %rbx
    62e0:	48 83 ec 48          	sub    $0x48,%rsp
    62e4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    62e9:	48 85 ff             	test   %rdi,%rdi
    62ec:	79 09                	jns    62f7 <fwp_p_ad_push+0x27>
    62ee:	48 85 d2             	test   %rdx,%rdx
    62f1:	0f 88 b9 02 00 00    	js     65b0 <fwp_p_ad_push+0x2e0>
    62f7:	48 89 f8             	mov    %rdi,%rax
    62fa:	48 89 0c 24          	mov    %rcx,(%rsp)
    62fe:	4c 89 c5             	mov    %r8,%rbp
    6301:	48 09 d0             	or     %rdx,%rax
    6304:	0f 89 86 02 00 00    	jns    6590 <fwp_p_ad_push+0x2c0>
    630a:	48 85 ff             	test   %rdi,%rdi
    630d:	0f 89 df 03 00 00    	jns    66f2 <fwp_p_ad_push+0x422>
    6313:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6318:	49 89 d6             	mov    %rdx,%r14
    631b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6322:	00 
    6323:	49 89 d4             	mov    %rdx,%r12
    6326:	49 c1 fe 20          	sar    $0x20,%r14
    632a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6331:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6337:	48 85 ed             	test   %rbp,%rbp
    633a:	0f 84 40 03 00 00    	je     6680 <fwp_p_ad_push+0x3b0>
    6340:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    6344:	0f 84 be 02 00 00    	je     6608 <fwp_p_ad_push+0x338>
    634a:	4c 89 f7             	mov    %r14,%rdi
    634d:	e8 be e3 ff ff       	call   4710 <fwp_tape_of>
    6352:	48 89 c3             	mov    %rax,%rbx
    6355:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    635a:	0f 85 36 03 00 00    	jne    6696 <fwp_p_ad_push+0x3c6>
    6360:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    6364:	48 89 45 08          	mov    %rax,0x8(%rbp)
    6368:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    636c:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6373:	0f 8f bc 03 00 00    	jg     6735 <fwp_p_ad_push+0x465>
    6379:	44 89 e0             	mov    %r12d,%eax
    637c:	4c 39 f8             	cmp    %r15,%rax
    637f:	0f 8d a4 03 00 00    	jge    6729 <fwp_p_ad_push+0x459>
    6385:	4d 85 ed             	test   %r13,%r13
    6388:	78 0c                	js     6396 <fwp_p_ad_push+0xc6>
    638a:	44 89 e8             	mov    %r13d,%eax
    638d:	4c 39 f8             	cmp    %r15,%rax
    6390:	0f 8d 93 03 00 00    	jge    6729 <fwp_p_ad_push+0x459>
    6396:	4d 89 fe             	mov    %r15,%r14
    6399:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    639d:	49 8d 46 01          	lea    0x1(%r14),%rax
    63a1:	4c 89 f1             	mov    %r14,%rcx
    63a4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63aa:	0f 87 85 03 00 00    	ja     6735 <fwp_p_ad_push+0x465>
    63b0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63b4:	48 39 e8             	cmp    %rbp,%rax
    63b7:	0f 8e 23 02 00 00    	jle    65e0 <fwp_p_ad_push+0x310>
    63bd:	48 85 ed             	test   %rbp,%rbp
    63c0:	ba 40 00 00 00       	mov    $0x40,%edx
    63c5:	48 0f 44 ea          	cmove  %rdx,%rbp
    63c9:	48 39 e8             	cmp    %rbp,%rax
    63cc:	7e 22                	jle    63f0 <fwp_p_ad_push+0x120>
    63ce:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63d5:	0f 8f f5 01 00 00    	jg     65d0 <fwp_p_ad_push+0x300>
    63db:	48 01 ed             	add    %rbp,%rbp
    63de:	48 39 e8             	cmp    %rbp,%rax
    63e1:	7f eb                	jg     63ce <fwp_p_ad_push+0xfe>
    63e3:	66 90                	xchg   %ax,%ax
    63e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ec:	00 00 00 00 
    63f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63f7:	00 
    63f8:	4c 8b 43 60          	mov    0x60(%rbx),%r8
    63fc:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6400:	ba 01 00 00 00       	mov    $0x1,%edx
    6405:	48 89 c6             	mov    %rax,%rsi
    6408:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    640d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6412:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6417:	e8 54 ed ff ff       	call   5170 <ad_raw_realloc>
    641c:	48 85 c0             	test   %rax,%rax
    641f:	0f 84 1c 03 00 00    	je     6741 <fwp_p_ad_push+0x471>
    6425:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6429:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    642e:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6432:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6437:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    643b:	4d 85 c0             	test   %r8,%r8
    643e:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    6442:	0f 84 d0 01 00 00    	je     6618 <fwp_p_ad_push+0x348>
    6448:	49 8b 50 60          	mov    0x60(%r8),%rdx
    644c:	48 39 ea             	cmp    %rbp,%rdx
    644f:	0f 8d bb 00 00 00    	jge    6510 <fwp_p_ad_push+0x240>
    6455:	49 8b 70 40          	mov    0x40(%r8),%rsi
    6459:	48 89 ef             	mov    %rbp,%rdi
    645c:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6461:	48 c1 e7 04          	shl    $0x4,%rdi
    6465:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    646a:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    646f:	be 02 00 00 00       	mov    $0x2,%esi
    6474:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6479:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    647e:	e8 6d fa ff ff       	call   5ef0 <fwp_heap_alloc>
    6483:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6488:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    648d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6492:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6497:	48 85 f6             	test   %rsi,%rsi
    649a:	74 31                	je     64cd <fwp_p_ad_push+0x1fd>
    649c:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    64a1:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    64a6:	48 c1 e2 04          	shl    $0x4,%rdx
    64aa:	48 39 fa             	cmp    %rdi,%rdx
    64ad:	48 0f 47 d7          	cmova  %rdi,%rdx
    64b1:	48 89 c7             	mov    %rax,%rdi
    64b4:	e8 c7 d0 ff ff       	call   3580 <memcpy@plt>
    64b9:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    64be:	e8 2d f5 ff ff       	call   59f0 <fwp_mem_free>
    64c3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    64c8:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    64cd:	49 8b 78 60          	mov    0x60(%r8),%rdi
    64d1:	48 89 ea             	mov    %rbp,%rdx
    64d4:	31 f6                	xor    %esi,%esi
    64d6:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    64db:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    64e0:	48 29 fa             	sub    %rdi,%rdx
    64e3:	48 c1 e7 04          	shl    $0x4,%rdi
    64e7:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    64ec:	48 c1 e2 04          	shl    $0x4,%rdx
    64f0:	e8 bb cf ff ff       	call   34b0 <memset@plt>
    64f5:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    64fa:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    64ff:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6504:	49 89 68 60          	mov    %rbp,0x60(%r8)
    6508:	49 89 40 40          	mov    %rax,0x40(%r8)
    650c:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6510:	4d 85 f6             	test   %r14,%r14
    6513:	0f 85 8f 01 00 00    	jne    66a8 <fwp_p_ad_push+0x3d8>
    6519:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    651d:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6521:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6528:	00 
    6529:	31 d2                	xor    %edx,%edx
    652b:	49 01 c6             	add    %rax,%r14
    652e:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    6532:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    6536:	44 89 24 10          	mov    %r12d,(%rax,%rdx,1)
    653a:	4d 85 ed             	test   %r13,%r13
    653d:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6543:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    654a:	4c 0f 48 e8          	cmovs  %rax,%r13
    654e:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6553:	49 8d 47 01          	lea    0x1(%r15),%rax
    6557:	f2 0f 11 0c 0e       	movsd  %xmm1,(%rsi,%rcx,1)
    655c:	45 89 2c 16          	mov    %r13d,(%r14,%rdx,1)
    6560:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    6565:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6569:	48 83 c4 48          	add    $0x48,%rsp
    656d:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6574:	ff ff ff 
    6577:	4c 21 e0             	and    %r12,%rax
    657a:	5b                   	pop    %rbx
    657b:	5d                   	pop    %rbp
    657c:	4c 09 f8             	or     %r15,%rax
    657f:	41 5c                	pop    %r12
    6581:	41 5d                	pop    %r13
    6583:	41 5e                	pop    %r14
    6585:	41 5f                	pop    %r15
    6587:	c3                   	ret
    6588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    658f:	00 
    6590:	48 c1 fa 20          	sar    $0x20,%rdx
    6594:	48 c1 ff 20          	sar    $0x20,%rdi
    6598:	49 89 d6             	mov    %rdx,%r14
    659b:	48 39 d7             	cmp    %rdx,%rdi
    659e:	0f 84 93 fd ff ff    	je     6337 <fwp_p_ad_push+0x67>
    65a4:	48 8d 3d 25 54 00 00 	lea    0x5425(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    65ab:	e8 80 de ff ff       	call   4430 <fwp_trap>
    65b0:	48 83 c4 48          	add    $0x48,%rsp
    65b4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65bb:	5b                   	pop    %rbx
    65bc:	5d                   	pop    %rbp
    65bd:	41 5c                	pop    %r12
    65bf:	41 5d                	pop    %r13
    65c1:	41 5e                	pop    %r14
    65c3:	41 5f                	pop    %r15
    65c5:	c3                   	ret
    65c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65cd:	00 00 00 
    65d0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    65d5:	e9 16 fe ff ff       	jmp    63f0 <fwp_p_ad_push+0x120>
    65da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65e0:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    65e7:	00 
    65e8:	48 8b 43 20          	mov    0x20(%rbx),%rax
    65ec:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    65f0:	48 c1 e1 03          	shl    $0x3,%rcx
    65f4:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    65f8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65fc:	e9 35 ff ff ff       	jmp    6536 <fwp_p_ad_push+0x266>
    6601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6608:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    660c:	e9 57 fd ff ff       	jmp    6368 <fwp_p_ad_push+0x98>
    6611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6618:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    661c:	48 89 ee             	mov    %rbp,%rsi
    661f:	ba 02 00 00 00       	mov    $0x2,%edx
    6624:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    6629:	48 c1 e6 04          	shl    $0x4,%rsi
    662d:	e8 3e eb ff ff       	call   5170 <ad_raw_realloc>
    6632:	48 89 c6             	mov    %rax,%rsi
    6635:	48 85 c0             	test   %rax,%rax
    6638:	0f 84 03 01 00 00    	je     6741 <fwp_p_ad_push+0x471>
    663e:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6642:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6646:	4d 85 f6             	test   %r14,%r14
    6649:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    664e:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    6652:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    6656:	48 89 43 38          	mov    %rax,0x38(%rbx)
    665a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    665f:	0f 85 99 00 00 00    	jne    66fe <fwp_p_ad_push+0x42e>
    6665:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6669:	48 8b 43 20          	mov    0x20(%rbx),%rax
    666d:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6674:	00 
    6675:	31 d2                	xor    %edx,%edx
    6677:	e9 af fe ff ff       	jmp    652b <fwp_p_ad_push+0x25b>
    667c:	0f 1f 40 00          	nopl   0x0(%rax)
    6680:	4c 89 f7             	mov    %r14,%rdi
    6683:	e8 88 e0 ff ff       	call   4710 <fwp_tape_of>
    6688:	48 89 c3             	mov    %rax,%rbx
    668b:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6690:	0f 84 d2 fc ff ff    	je     6368 <fwp_p_ad_push+0x98>
    6696:	48 8d 3d 7b 53 00 00 	lea    0x537b(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    669d:	e8 8e dd ff ff       	call   4430 <fwp_trap>
    66a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66a8:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    66af:	00 
    66b0:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    66b5:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    66bc:	00 
    66bd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    66c1:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    66c8:	00 
    66c9:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    66cd:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    66d2:	e8 19 cf ff ff       	call   35f0 <memmove@plt>
    66d7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66db:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    66df:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    66e3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    66e8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    66ed:	e9 39 fe ff ff       	jmp    652b <fwp_p_ad_push+0x25b>
    66f2:	48 c1 ff 20          	sar    $0x20,%rdi
    66f6:	49 89 fe             	mov    %rdi,%r14
    66f9:	e9 39 fc ff ff       	jmp    6337 <fwp_p_ad_push+0x67>
    66fe:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    6705:	00 
    6706:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    670b:	48 89 f2             	mov    %rsi,%rdx
    670e:	48 89 c6             	mov    %rax,%rsi
    6711:	e8 da ce ff ff       	call   35f0 <memmove@plt>
    6716:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    671b:	48 03 43 30          	add    0x30(%rbx),%rax
    671f:	48 89 43 38          	mov    %rax,0x38(%rbx)
    6723:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6727:	eb 8c                	jmp    66b5 <fwp_p_ad_push+0x3e5>
    6729:	48 8d 3d 92 4a 00 00 	lea    0x4a92(%rip),%rdi        # b1c2 <_IO_stdin_used+0x1c2>
    6730:	e8 fb dc ff ff       	call   4430 <fwp_trap>
    6735:	48 8d 3d 6b 4a 00 00 	lea    0x4a6b(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    673c:	e8 ef dc ff ff       	call   4430 <fwp_trap>
    6741:	48 89 df             	mov    %rbx,%rdi
    6744:	e8 27 d5 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    6749:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    674d:	48 85 ff             	test   %rdi,%rdi
    6750:	74 05                	je     6757 <fwp_p_ad_push+0x487>
    6752:	e8 59 e9 ff ff       	call   50b0 <ad_raw_free.part.0>
    6757:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    675b:	48 85 ff             	test   %rdi,%rdi
    675e:	74 05                	je     6765 <fwp_p_ad_push+0x495>
    6760:	e8 4b e9 ff ff       	call   50b0 <ad_raw_free.part.0>
    6765:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6769:	48 85 ff             	test   %rdi,%rdi
    676c:	74 05                	je     6773 <fwp_p_ad_push+0x4a3>
    676e:	e8 3d e9 ff ff       	call   50b0 <ad_raw_free.part.0>
    6773:	31 c9                	xor    %ecx,%ecx
    6775:	31 c0                	xor    %eax,%eax
    6777:	31 d2                	xor    %edx,%edx
    6779:	be 01 00 00 00       	mov    $0x1,%esi
    677e:	89 53 04             	mov    %edx,0x4(%rbx)
    6781:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6785:	ba 13 00 00 00       	mov    $0x13,%edx
    678a:	48 8d 3d 77 48 00 00 	lea    0x4877(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    6791:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6795:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6799:	48 8b 0d a0 88 00 00 	mov    0x88a0(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    67a0:	48 89 43 40          	mov    %rax,0x40(%rbx)
    67a4:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    67a8:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    67ac:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    67b0:	e8 ab ce ff ff       	call   3660 <fwrite@plt>
    67b5:	31 ff                	xor    %edi,%edi
    67b7:	e8 e4 cd ff ff       	call   35a0 <fflush@plt>
    67bc:	bf 66 00 00 00       	mov    $0x66,%edi
    67c1:	e8 ba ce ff ff       	call   3680 <_Exit@plt>
    67c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67cd:	00 00 00 

00000000000067d0 <w120>:
    67d0:	41 56                	push   %r14
    67d2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    67d6:	48 89 fa             	mov    %rdi,%rdx
    67d9:	41 55                	push   %r13
    67db:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    67df:	49 89 fd             	mov    %rdi,%r13
    67e2:	41 54                	push   %r12
    67e4:	55                   	push   %rbp
    67e5:	53                   	push   %rbx
    67e6:	48 83 ec 40          	sub    $0x40,%rsp
    67ea:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    67f0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    67f5:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    67fc:	00 00 
    67fe:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6803:	48 89 f5             	mov    %rsi,%rbp
    6806:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    680b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6811:	48 89 f1             	mov    %rsi,%rcx
    6814:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    681a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6821:	ff ff 
    6823:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    682a:	00 00 
    682c:	e8 9f fa ff ff       	call   62d0 <fwp_p_ad_push>
    6831:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6837:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    683c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6842:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6849:	00 f0 3f 
    684c:	48 89 c7             	mov    %rax,%rdi
    684f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6856:	00 f0 bf 
    6859:	48 89 ea             	mov    %rbp,%rdx
    685c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6861:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6867:	e8 64 fa ff ff       	call   62d0 <fwp_p_ad_push>
    686c:	f2 0f 10 05 ac 54 00 	movsd  0x54ac(%rip),%xmm0        # bd20 <msg.4+0xb0>
    6873:	00 
    6874:	4c 89 ef             	mov    %r13,%rdi
    6877:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    687d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6882:	49 89 c6             	mov    %rax,%r14
    6885:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    688c:	00 f0 3f 
    688f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6896:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    689d:	00 f0 bf 
    68a0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    68a5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    68ab:	e8 20 fa ff ff       	call   62d0 <fwp_p_ad_push>
    68b0:	4c 89 e1             	mov    %r12,%rcx
    68b3:	4c 89 e6             	mov    %r12,%rsi
    68b6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68bb:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    68c1:	4c 89 f2             	mov    %r14,%rdx
    68c4:	4c 89 f7             	mov    %r14,%rdi
    68c7:	49 89 c5             	mov    %rax,%r13
    68ca:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    68ce:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68d4:	e8 f7 f9 ff ff       	call   62d0 <fwp_p_ad_push>
    68d9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    68df:	f2 0f 59 1d 41 54 00 	mulsd  0x5441(%rip),%xmm3        # bd28 <msg.4+0xb8>
    68e6:	00 
    68e7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68ec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    68f1:	48 89 c2             	mov    %rax,%rdx
    68f4:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    68fb:	00 59 40 
    68fe:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6905:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    690b:	e8 c0 f9 ff ff       	call   62d0 <fwp_p_ad_push>
    6910:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6915:	48 89 e9             	mov    %rbp,%rcx
    6918:	4c 89 ea             	mov    %r13,%rdx
    691b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6921:	48 89 ee             	mov    %rbp,%rsi
    6924:	4c 89 ef             	mov    %r13,%rdi
    6927:	49 89 c4             	mov    %rax,%r12
    692a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    692e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6934:	e8 97 f9 ff ff       	call   62d0 <fwp_p_ad_push>
    6939:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    693f:	45 31 c0             	xor    %r8d,%r8d
    6942:	4c 89 e2             	mov    %r12,%rdx
    6945:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    694b:	48 89 c7             	mov    %rax,%rdi
    694e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6955:	00 f0 3f 
    6958:	48 89 ce             	mov    %rcx,%rsi
    695b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6960:	e8 6b f9 ff ff       	call   62d0 <fwp_p_ad_push>
    6965:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    696a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6971:	00 00 
    6973:	75 12                	jne    6987 <w120+0x1b7>
    6975:	48 83 c4 40          	add    $0x40,%rsp
    6979:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    697e:	5b                   	pop    %rbx
    697f:	5d                   	pop    %rbp
    6980:	41 5c                	pop    %r12
    6982:	41 5d                	pop    %r13
    6984:	41 5e                	pop    %r14
    6986:	c3                   	ret
    6987:	e8 c4 ca ff ff       	call   3450 <__stack_chk_fail@plt>
    698c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006990 <w176.constprop.0>:
    6990:	41 54                	push   %r12
    6992:	55                   	push   %rbp
    6993:	53                   	push   %rbx
    6994:	48 83 ec 10          	sub    $0x10,%rsp
    6998:	4c 8b 27             	mov    (%rdi),%r12
    699b:	4d 85 e4             	test   %r12,%r12
    699e:	74 58                	je     69f8 <w176.constprop.0+0x68>
    69a0:	48 89 fd             	mov    %rdi,%rbp
    69a3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69a7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    69ae:	31 db                	xor    %ebx,%ebx
    69b0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    69b6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    69bb:	45 31 c0             	xor    %r8d,%r8d
    69be:	48 83 c3 02          	add    $0x2,%rbx
    69c2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    69c9:	00 f0 3f 
    69cc:	48 89 ce             	mov    %rcx,%rsi
    69cf:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    69d5:	e8 f6 f8 ff ff       	call   62d0 <fwp_p_ad_push>
    69da:	4c 39 e3             	cmp    %r12,%rbx
    69dd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    69e3:	48 89 c7             	mov    %rax,%rdi
    69e6:	72 c8                	jb     69b0 <w176.constprop.0+0x20>
    69e8:	48 83 c4 10          	add    $0x10,%rsp
    69ec:	48 89 f8             	mov    %rdi,%rax
    69ef:	5b                   	pop    %rbx
    69f0:	5d                   	pop    %rbp
    69f1:	41 5c                	pop    %r12
    69f3:	c3                   	ret
    69f4:	0f 1f 40 00          	nopl   0x0(%rax)
    69f8:	48 83 c4 10          	add    $0x10,%rsp
    69fc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a03:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a07:	5b                   	pop    %rbx
    6a08:	48 89 f8             	mov    %rdi,%rax
    6a0b:	5d                   	pop    %rbp
    6a0c:	41 5c                	pop    %r12
    6a0e:	c3                   	ret
    6a0f:	90                   	nop

0000000000006a10 <fwp_rc_share>:
    6a10:	48 8b 05 e1 21 06 00 	mov    0x621e1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    6a17:	48 2b 3d b2 21 06 00 	sub    0x621b2(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    6a1e:	48 c1 e0 10          	shl    $0x10,%rax
    6a22:	48 39 c7             	cmp    %rax,%rdi
    6a25:	73 4a                	jae    6a71 <fwp_rc_share+0x61>
    6a27:	48 89 f8             	mov    %rdi,%rax
    6a2a:	48 c1 e8 10          	shr    $0x10,%rax
    6a2e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a32:	48 8b 05 df 21 06 00 	mov    0x621df(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    6a39:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a3d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a41:	48 85 d2             	test   %rdx,%rdx
    6a44:	74 2b                	je     6a71 <fwp_rc_share+0x61>
    6a46:	0f b6 08             	movzbl (%rax),%ecx
    6a49:	80 f9 02             	cmp    $0x2,%cl
    6a4c:	74 2a                	je     6a78 <fwp_rc_share+0x68>
    6a4e:	80 f9 01             	cmp    $0x1,%cl
    6a51:	75 1e                	jne    6a71 <fwp_rc_share+0x61>
    6a53:	8b 48 18             	mov    0x18(%rax),%ecx
    6a56:	0f b7 ff             	movzwl %di,%edi
    6a59:	8b 40 1c             	mov    0x1c(%rax),%eax
    6a5c:	48 0f af f9          	imul   %rcx,%rdi
    6a60:	48 c1 ef 20          	shr    $0x20,%rdi
    6a64:	48 39 c7             	cmp    %rax,%rdi
    6a67:	73 08                	jae    6a71 <fwp_rc_share+0x61>
    6a69:	48 01 fa             	add    %rdi,%rdx
    6a6c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6a6f:	75 0d                	jne    6a7e <fwp_rc_share+0x6e>
    6a71:	c3                   	ret
    6a72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a78:	66 85 ff             	test   %di,%di
    6a7b:	74 ef                	je     6a6c <fwp_rc_share+0x5c>
    6a7d:	c3                   	ret
    6a7e:	50                   	push   %rax
    6a7f:	48 8d 3d c2 4f 00 00 	lea    0x4fc2(%rip),%rdi        # ba48 <_IO_stdin_used+0xa48>
    6a86:	e8 a5 d9 ff ff       	call   4430 <fwp_trap>
    6a8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006a90 <fwp_rc_free_obj>:
    6a90:	48 8b 15 61 21 06 00 	mov    0x62161(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6a97:	48 89 f8             	mov    %rdi,%rax
    6a9a:	48 2b 05 2f 21 06 00 	sub    0x6212f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6aa1:	48 c1 e2 10          	shl    $0x10,%rdx
    6aa5:	48 39 d0             	cmp    %rdx,%rax
    6aa8:	73 5b                	jae    6b05 <fwp_rc_free_obj+0x75>
    6aaa:	48 89 c2             	mov    %rax,%rdx
    6aad:	48 c1 ea 10          	shr    $0x10,%rdx
    6ab1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ab5:	48 8b 15 5c 21 06 00 	mov    0x6215c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6abc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ac0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ac4:	48 85 c9             	test   %rcx,%rcx
    6ac7:	74 3c                	je     6b05 <fwp_rc_free_obj+0x75>
    6ac9:	0f b6 32             	movzbl (%rdx),%esi
    6acc:	40 80 fe 02          	cmp    $0x2,%sil
    6ad0:	74 2e                	je     6b00 <fwp_rc_free_obj+0x70>
    6ad2:	40 80 fe 01          	cmp    $0x1,%sil
    6ad6:	75 2d                	jne    6b05 <fwp_rc_free_obj+0x75>
    6ad8:	8b 72 18             	mov    0x18(%rdx),%esi
    6adb:	0f b7 c0             	movzwl %ax,%eax
    6ade:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ae1:	48 0f af c6          	imul   %rsi,%rax
    6ae5:	48 c1 e8 20          	shr    $0x20,%rax
    6ae9:	48 39 d0             	cmp    %rdx,%rax
    6aec:	73 17                	jae    6b05 <fwp_rc_free_obj+0x75>
    6aee:	48 01 c1             	add    %rax,%rcx
    6af1:	80 39 01             	cmpb   $0x1,(%rcx)
    6af4:	75 0f                	jne    6b05 <fwp_rc_free_obj+0x75>
    6af6:	e9 f5 ee ff ff       	jmp    59f0 <fwp_mem_free>
    6afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b00:	66 85 c0             	test   %ax,%ax
    6b03:	74 ec                	je     6af1 <fwp_rc_free_obj+0x61>
    6b05:	c3                   	ret
    6b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b0d:	00 00 00 

0000000000006b10 <fwp_rc_dup>:
    6b10:	f3 0f 1e fa          	endbr64
    6b14:	48 8b 05 dd 20 06 00 	mov    0x620dd(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    6b1b:	48 2b 3d ae 20 06 00 	sub    0x620ae(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    6b22:	48 c1 e0 10          	shl    $0x10,%rax
    6b26:	48 39 c7             	cmp    %rax,%rdi
    6b29:	73 60                	jae    6b8b <fwp_rc_dup+0x7b>
    6b2b:	48 89 f8             	mov    %rdi,%rax
    6b2e:	48 c1 e8 10          	shr    $0x10,%rax
    6b32:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b36:	48 8b 05 db 20 06 00 	mov    0x620db(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    6b3d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6b41:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6b45:	48 85 c0             	test   %rax,%rax
    6b48:	74 41                	je     6b8b <fwp_rc_dup+0x7b>
    6b4a:	0f b6 0a             	movzbl (%rdx),%ecx
    6b4d:	80 f9 02             	cmp    $0x2,%cl
    6b50:	74 3e                	je     6b90 <fwp_rc_dup+0x80>
    6b52:	80 f9 01             	cmp    $0x1,%cl
    6b55:	75 34                	jne    6b8b <fwp_rc_dup+0x7b>
    6b57:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6b5a:	0f b7 ff             	movzwl %di,%edi
    6b5d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b60:	48 0f af f9          	imul   %rcx,%rdi
    6b64:	48 c1 ef 20          	shr    $0x20,%rdi
    6b68:	48 39 d7             	cmp    %rdx,%rdi
    6b6b:	73 1e                	jae    6b8b <fwp_rc_dup+0x7b>
    6b6d:	48 01 f8             	add    %rdi,%rax
    6b70:	0f b6 10             	movzbl (%rax),%edx
    6b73:	84 d2                	test   %dl,%dl
    6b75:	74 14                	je     6b8b <fwp_rc_dup+0x7b>
    6b77:	8b 0d 6b 29 06 00    	mov    0x6296b(%rip),%ecx        # 694e8 <iteration_active>
    6b7d:	85 c9                	test   %ecx,%ecx
    6b7f:	75 1f                	jne    6ba0 <fwp_rc_dup+0x90>
    6b81:	80 fa fd             	cmp    $0xfd,%dl
    6b84:	77 2a                	ja     6bb0 <fwp_rc_dup+0xa0>
    6b86:	83 c2 01             	add    $0x1,%edx
    6b89:	88 10                	mov    %dl,(%rax)
    6b8b:	c3                   	ret
    6b8c:	0f 1f 40 00          	nopl   0x0(%rax)
    6b90:	66 85 ff             	test   %di,%di
    6b93:	74 db                	je     6b70 <fwp_rc_dup+0x60>
    6b95:	c3                   	ret
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 
    6ba0:	48 83 05 28 29 06 00 	addq   $0x1,0x62928(%rip)        # 694d0 <iteration_retains>
    6ba7:	01 
    6ba8:	eb d7                	jmp    6b81 <fwp_rc_dup+0x71>
    6baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bb0:	48 89 c7             	mov    %rax,%rdi
    6bb3:	e9 d8 ea ff ff       	jmp    5690 <fwp_rc_wide_dup>
    6bb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bbf:	00 

0000000000006bc0 <fwp_owned_entry173>:
    6bc0:	f3 0f 1e fa          	endbr64
    6bc4:	48 83 ec 38          	sub    $0x38,%rsp
    6bc8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bcd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bd4:	00 00 
    6bd6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bdb:	31 c0                	xor    %eax,%eax
    6bdd:	48 8b 07             	mov    (%rdi),%rax
    6be0:	48 03 47 10          	add    0x10(%rdi),%rax
    6be4:	0f 80 c2 00 00 00    	jo     6cac <fwp_owned_entry173+0xec>
    6bea:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6bef:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6bf4:	31 ff                	xor    %edi,%edi
    6bf6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6bfa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6bff:	e8 dc f4 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6c04:	48 8b 15 ed 1f 06 00 	mov    0x61fed(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6c0b:	48 89 c6             	mov    %rax,%rsi
    6c0e:	48 2b 05 bb 1f 06 00 	sub    0x61fbb(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6c15:	48 c1 e2 10          	shl    $0x10,%rdx
    6c19:	48 39 d0             	cmp    %rdx,%rax
    6c1c:	73 4f                	jae    6c6d <fwp_owned_entry173+0xad>
    6c1e:	48 89 c2             	mov    %rax,%rdx
    6c21:	48 c1 ea 10          	shr    $0x10,%rdx
    6c25:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c29:	48 8b 15 e8 1f 06 00 	mov    0x61fe8(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6c30:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c34:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c38:	48 85 d2             	test   %rdx,%rdx
    6c3b:	74 30                	je     6c6d <fwp_owned_entry173+0xad>
    6c3d:	0f b6 39             	movzbl (%rcx),%edi
    6c40:	40 80 ff 02          	cmp    $0x2,%dil
    6c44:	74 42                	je     6c88 <fwp_owned_entry173+0xc8>
    6c46:	40 80 ff 01          	cmp    $0x1,%dil
    6c4a:	75 21                	jne    6c6d <fwp_owned_entry173+0xad>
    6c4c:	8b 79 18             	mov    0x18(%rcx),%edi
    6c4f:	0f b7 c0             	movzwl %ax,%eax
    6c52:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c55:	48 0f af c7          	imul   %rdi,%rax
    6c59:	48 c1 e8 20          	shr    $0x20,%rax
    6c5d:	48 39 c8             	cmp    %rcx,%rax
    6c60:	73 0b                	jae    6c6d <fwp_owned_entry173+0xad>
    6c62:	48 01 c2             	add    %rax,%rdx
    6c65:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c68:	74 26                	je     6c90 <fwp_owned_entry173+0xd0>
    6c6a:	c6 02 01             	movb   $0x1,(%rdx)
    6c6d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c72:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c79:	00 00 
    6c7b:	75 34                	jne    6cb1 <fwp_owned_entry173+0xf1>
    6c7d:	48 89 f0             	mov    %rsi,%rax
    6c80:	48 83 c4 38          	add    $0x38,%rsp
    6c84:	c3                   	ret
    6c85:	0f 1f 00             	nopl   (%rax)
    6c88:	66 85 c0             	test   %ax,%ax
    6c8b:	75 e0                	jne    6c6d <fwp_owned_entry173+0xad>
    6c8d:	eb d6                	jmp    6c65 <fwp_owned_entry173+0xa5>
    6c8f:	90                   	nop
    6c90:	48 89 d7             	mov    %rdx,%rdi
    6c93:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6c98:	48 89 14 24          	mov    %rdx,(%rsp)
    6c9c:	e8 0f eb ff ff       	call   57b0 <fwp_rc_forget_slot>
    6ca1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6ca6:	48 8b 14 24          	mov    (%rsp),%rdx
    6caa:	eb be                	jmp    6c6a <fwp_owned_entry173+0xaa>
    6cac:	e8 2f ca ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6cb1:	e8 9a c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cbd:	00 00 00 

0000000000006cc0 <e173>:
    6cc0:	f3 0f 1e fa          	endbr64
    6cc4:	53                   	push   %rbx
    6cc5:	48 83 ec 30          	sub    $0x30,%rsp
    6cc9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6cce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6cd5:	00 00 
    6cd7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6cdc:	31 c0                	xor    %eax,%eax
    6cde:	48 8b 07             	mov    (%rdi),%rax
    6ce1:	48 03 47 10          	add    0x10(%rdi),%rax
    6ce5:	0f 80 c9 00 00 00    	jo     6db4 <e173+0xf4>
    6ceb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6cf0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6cf5:	31 ff                	xor    %edi,%edi
    6cf7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6cfb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d00:	e8 db f3 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6d05:	48 8b 15 ec 1e 06 00 	mov    0x61eec(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6d0c:	48 89 c3             	mov    %rax,%rbx
    6d0f:	48 2b 05 ba 1e 06 00 	sub    0x61eba(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6d16:	48 c1 e2 10          	shl    $0x10,%rdx
    6d1a:	48 39 d0             	cmp    %rdx,%rax
    6d1d:	73 4f                	jae    6d6e <e173+0xae>
    6d1f:	48 89 c2             	mov    %rax,%rdx
    6d22:	48 c1 ea 10          	shr    $0x10,%rdx
    6d26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d2a:	48 8b 15 e7 1e 06 00 	mov    0x61ee7(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6d31:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d35:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d39:	48 85 d2             	test   %rdx,%rdx
    6d3c:	74 30                	je     6d6e <e173+0xae>
    6d3e:	0f b6 31             	movzbl (%rcx),%esi
    6d41:	40 80 fe 02          	cmp    $0x2,%sil
    6d45:	74 49                	je     6d90 <e173+0xd0>
    6d47:	40 80 fe 01          	cmp    $0x1,%sil
    6d4b:	75 21                	jne    6d6e <e173+0xae>
    6d4d:	8b 71 18             	mov    0x18(%rcx),%esi
    6d50:	0f b7 c0             	movzwl %ax,%eax
    6d53:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d56:	48 0f af c6          	imul   %rsi,%rax
    6d5a:	48 c1 e8 20          	shr    $0x20,%rax
    6d5e:	48 39 c8             	cmp    %rcx,%rax
    6d61:	73 0b                	jae    6d6e <e173+0xae>
    6d63:	48 01 c2             	add    %rax,%rdx
    6d66:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d69:	74 35                	je     6da0 <e173+0xe0>
    6d6b:	c6 02 01             	movb   $0x1,(%rdx)
    6d6e:	48 89 df             	mov    %rbx,%rdi
    6d71:	e8 9a fc ff ff       	call   6a10 <fwp_rc_share>
    6d76:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d7b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d82:	00 00 
    6d84:	75 33                	jne    6db9 <e173+0xf9>
    6d86:	48 83 c4 30          	add    $0x30,%rsp
    6d8a:	48 89 d8             	mov    %rbx,%rax
    6d8d:	5b                   	pop    %rbx
    6d8e:	c3                   	ret
    6d8f:	90                   	nop
    6d90:	66 85 c0             	test   %ax,%ax
    6d93:	75 d9                	jne    6d6e <e173+0xae>
    6d95:	eb cf                	jmp    6d66 <e173+0xa6>
    6d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d9e:	00 00 
    6da0:	48 89 d7             	mov    %rdx,%rdi
    6da3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6da8:	e8 03 ea ff ff       	call   57b0 <fwp_rc_forget_slot>
    6dad:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6db2:	eb b7                	jmp    6d6b <e173+0xab>
    6db4:	e8 27 c9 ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6db9:	e8 92 c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6dbe:	66 90                	xchg   %ax,%ax

0000000000006dc0 <fwp_closure_drop>:
    6dc0:	48 8b 15 31 1e 06 00 	mov    0x61e31(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6dc7:	48 89 f8             	mov    %rdi,%rax
    6dca:	48 2b 05 ff 1d 06 00 	sub    0x61dff(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6dd1:	48 c1 e2 10          	shl    $0x10,%rdx
    6dd5:	48 39 d0             	cmp    %rdx,%rax
    6dd8:	73 6b                	jae    6e45 <fwp_closure_drop+0x85>
    6dda:	48 89 c2             	mov    %rax,%rdx
    6ddd:	48 c1 ea 10          	shr    $0x10,%rdx
    6de1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6de5:	48 8b 15 2c 1e 06 00 	mov    0x61e2c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6dec:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6df0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6df4:	48 85 d2             	test   %rdx,%rdx
    6df7:	74 4c                	je     6e45 <fwp_closure_drop+0x85>
    6df9:	0f b6 31             	movzbl (%rcx),%esi
    6dfc:	40 80 fe 02          	cmp    $0x2,%sil
    6e00:	74 3e                	je     6e40 <fwp_closure_drop+0x80>
    6e02:	40 80 fe 01          	cmp    $0x1,%sil
    6e06:	75 3d                	jne    6e45 <fwp_closure_drop+0x85>
    6e08:	8b 71 18             	mov    0x18(%rcx),%esi
    6e0b:	0f b7 c0             	movzwl %ax,%eax
    6e0e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e11:	48 0f af c6          	imul   %rsi,%rax
    6e15:	48 c1 e8 20          	shr    $0x20,%rax
    6e19:	48 39 c8             	cmp    %rcx,%rax
    6e1c:	73 27                	jae    6e45 <fwp_closure_drop+0x85>
    6e1e:	48 01 c2             	add    %rax,%rdx
    6e21:	0f b6 02             	movzbl (%rdx),%eax
    6e24:	84 c0                	test   %al,%al
    6e26:	74 1d                	je     6e45 <fwp_closure_drop+0x85>
    6e28:	3c 01                	cmp    $0x1,%al
    6e2a:	74 24                	je     6e50 <fwp_closure_drop+0x90>
    6e2c:	3c ff                	cmp    $0xff,%al
    6e2e:	74 48                	je     6e78 <fwp_closure_drop+0xb8>
    6e30:	83 e8 01             	sub    $0x1,%eax
    6e33:	88 02                	mov    %al,(%rdx)
    6e35:	c3                   	ret
    6e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e3d:	00 00 00 
    6e40:	66 85 c0             	test   %ax,%ax
    6e43:	74 dc                	je     6e21 <fwp_closure_drop+0x61>
    6e45:	c3                   	ret
    6e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e4d:	00 00 00 
    6e50:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6e57:	ff ff 
    6e59:	48 85 c0             	test   %rax,%rax
    6e5c:	74 12                	je     6e70 <fwp_closure_drop+0xb0>
    6e5e:	48 89 fe             	mov    %rdi,%rsi
    6e61:	48 89 c7             	mov    %rax,%rdi
    6e64:	e9 27 d6 ff ff       	jmp    4490 <fwp_closure_drop_push>
    6e69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e70:	e9 cb d7 ff ff       	jmp    4640 <fwp_closure_drop.part.0>
    6e75:	0f 1f 00             	nopl   (%rax)
    6e78:	48 89 d0             	mov    %rdx,%rax
    6e7b:	48 8d 35 9e 09 06 00 	lea    0x6099e(%rip),%rsi        # 67820 <fwp_heap>
    6e82:	48 83 ec 18          	sub    $0x18,%rsp
    6e86:	48 c1 e8 11          	shr    $0x11,%rax
    6e8a:	48 31 d0             	xor    %rdx,%rax
    6e8d:	48 89 c1             	mov    %rax,%rcx
    6e90:	48 c1 e9 09          	shr    $0x9,%rcx
    6e94:	48 31 c8             	xor    %rcx,%rax
    6e97:	0f b6 c8             	movzbl %al,%ecx
    6e9a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6ea1:	00 
    6ea2:	48 85 c0             	test   %rax,%rax
    6ea5:	75 22                	jne    6ec9 <fwp_closure_drop+0x109>
    6ea7:	eb 59                	jmp    6f02 <fwp_closure_drop+0x142>
    6ea9:	90                   	nop
    6eaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6eb1:	00 00 00 00 
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 
    6ec0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	74 39                	je     6f02 <fwp_closure_drop+0x142>
    6ec9:	48 89 c1             	mov    %rax,%rcx
    6ecc:	48 39 10             	cmp    %rdx,(%rax)
    6ecf:	75 ef                	jne    6ec0 <fwp_closure_drop+0x100>
    6ed1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ed5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6ed9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6edd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ee4:	74 05                	je     6eeb <fwp_closure_drop+0x12b>
    6ee6:	48 83 c4 18          	add    $0x18,%rsp
    6eea:	c3                   	ret
    6eeb:	48 89 d7             	mov    %rdx,%rdi
    6eee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ef3:	e8 b8 e8 ff ff       	call   57b0 <fwp_rc_forget_slot>
    6ef8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6efd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f00:	eb e4                	jmp    6ee6 <fwp_closure_drop+0x126>
    6f02:	48 8d 3d 9f 4a 00 00 	lea    0x4a9f(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    6f09:	e8 22 d5 ff ff       	call   4430 <fwp_trap>
    6f0e:	66 90                	xchg   %ax,%ax

0000000000006f10 <fwp_owned_tape_release>:
    6f10:	48 85 ff             	test   %rdi,%rdi
    6f13:	0f 84 f7 00 00 00    	je     7010 <fwp_owned_tape_release+0x100>
    6f19:	41 54                	push   %r12
    6f1b:	55                   	push   %rbp
    6f1c:	53                   	push   %rbx
    6f1d:	48 8b 07             	mov    (%rdi),%rax
    6f20:	48 85 c0             	test   %rax,%rax
    6f23:	74 08                	je     6f2d <fwp_owned_tape_release+0x1d>
    6f25:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f29:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6f2d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6f31:	48 85 d2             	test   %rdx,%rdx
    6f34:	74 03                	je     6f39 <fwp_owned_tape_release+0x29>
    6f36:	48 89 02             	mov    %rax,(%rdx)
    6f39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6f3d:	48 89 fb             	mov    %rdi,%rbx
    6f40:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6f44:	48 85 c0             	test   %rax,%rax
    6f47:	0f 84 89 00 00 00    	je     6fd6 <fwp_owned_tape_release+0xc6>
    6f4d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6f51:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6f55:	7e 47                	jle    6f9e <fwp_owned_tape_release+0x8e>
    6f57:	31 ed                	xor    %ebp,%ebp
    6f59:	eb 0d                	jmp    6f68 <fwp_owned_tape_release+0x58>
    6f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f60:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f64:	48 8b 40 68          	mov    0x68(%rax),%rax
    6f68:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6f6c:	49 89 ec             	mov    %rbp,%r12
    6f6f:	48 83 c5 01          	add    $0x1,%rbp
    6f73:	49 c1 e4 04          	shl    $0x4,%r12
    6f77:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6f7b:	ff d0                	call   *%rax
    6f7d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f81:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6f86:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f8a:	ff 50 68             	call   *0x68(%rax)
    6f8d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6f91:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6f95:	48 39 e8             	cmp    %rbp,%rax
    6f98:	7f c6                	jg     6f60 <fwp_owned_tape_release+0x50>
    6f9a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f9e:	31 ed                	xor    %ebp,%ebp
    6fa0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6fa5:	7e 28                	jle    6fcf <fwp_owned_tape_release+0xbf>
    6fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6fae:	00 00 
    6fb0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6fb4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6fb8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6fbc:	74 07                	je     6fc5 <fwp_owned_tape_release+0xb5>
    6fbe:	ff 52 68             	call   *0x68(%rdx)
    6fc1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6fc5:	48 83 c5 01          	add    $0x1,%rbp
    6fc9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6fcd:	7f e1                	jg     6fb0 <fwp_owned_tape_release+0xa0>
    6fcf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6fd3:	ff 52 68             	call   *0x68(%rdx)
    6fd6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6fda:	e8 e1 fd ff ff       	call   6dc0 <fwp_closure_drop>
    6fdf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6fe3:	e8 d8 fd ff ff       	call   6dc0 <fwp_closure_drop>
    6fe8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6fec:	e8 cf fd ff ff       	call   6dc0 <fwp_closure_drop>
    6ff1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6ff5:	e8 f6 e9 ff ff       	call   59f0 <fwp_mem_free>
    6ffa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6ffe:	e8 ed e9 ff ff       	call   59f0 <fwp_mem_free>
    7003:	48 89 df             	mov    %rbx,%rdi
    7006:	5b                   	pop    %rbx
    7007:	5d                   	pop    %rbp
    7008:	41 5c                	pop    %r12
    700a:	e9 e1 e9 ff ff       	jmp    59f0 <fwp_mem_free>
    700f:	90                   	nop
    7010:	c3                   	ret
    7011:	0f 1f 40 00          	nopl   0x0(%rax)
    7015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    701c:	00 00 00 00 

0000000000007020 <fwp_tape_finish>:
    7020:	f3 0f 1e fa          	endbr64
    7024:	41 55                	push   %r13
    7026:	41 54                	push   %r12
    7028:	55                   	push   %rbp
    7029:	53                   	push   %rbx
    702a:	48 83 ec 48          	sub    $0x48,%rsp
    702e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7035:	00 00 
    7037:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    703c:	48 8d 3d 5d 80 01 00 	lea    0x1805d(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    7043:	e8 d8 e0 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    7048:	48 83 3d 98 80 01 00 	cmpq   $0x0,0x18098(%rip)        # 1f0e8 <fwp_ntapes>
    704f:	00 
    7050:	48 c7 05 2d 80 01 00 	movq   $0x0,0x1802d(%rip)        # 1f088 <fwp_tape_cached_bytes>
    7057:	00 00 00 00 
    705b:	7e 79                	jle    70d6 <fwp_tape_finish+0xb6>
    705d:	45 31 e4             	xor    %r12d,%r12d
    7060:	31 ed                	xor    %ebp,%ebp
    7062:	0f 1f 00             	nopl   (%rax)
    7065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    706c:	00 00 00 00 
    7070:	48 8b 1d 79 80 01 00 	mov    0x18079(%rip),%rbx        # 1f0f0 <fwp_tapes>
    7077:	48 83 c5 01          	add    $0x1,%rbp
    707b:	4c 01 e3             	add    %r12,%rbx
    707e:	49 83 c4 68          	add    $0x68,%r12
    7082:	48 89 df             	mov    %rbx,%rdi
    7085:	e8 e6 cb ff ff       	call   3c70 <fwp_tape_unlink_scope>
    708a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    708f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7094:	48 89 e7             	mov    %rsp,%rdi
    7097:	48 8b 43 40          	mov    0x40(%rbx),%rax
    709b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    709f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    70a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    70a9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    70ae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    70b2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    70b7:	e8 64 e0 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    70bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    70c0:	e8 4b fe ff ff       	call   6f10 <fwp_owned_tape_release>
    70c5:	48 39 2d 1c 80 01 00 	cmp    %rbp,0x1801c(%rip)        # 1f0e8 <fwp_ntapes>
    70cc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    70d3:	00 
    70d4:	7f 9a                	jg     7070 <fwp_tape_finish+0x50>
    70d6:	48 8b 3d 13 80 01 00 	mov    0x18013(%rip),%rdi        # 1f0f0 <fwp_tapes>
    70dd:	48 85 ff             	test   %rdi,%rdi
    70e0:	74 05                	je     70e7 <fwp_tape_finish+0xc7>
    70e2:	e8 c9 df ff ff       	call   50b0 <ad_raw_free.part.0>
    70e7:	48 c7 05 fe 7f 01 00 	movq   $0x0,0x17ffe(%rip)        # 1f0f0 <fwp_tapes>
    70ee:	00 00 00 00 
    70f2:	48 c7 05 e3 7f 01 00 	movq   $0x0,0x17fe3(%rip)        # 1f0e0 <fwp_tapes_cap>
    70f9:	00 00 00 00 
    70fd:	48 c7 05 e0 7f 01 00 	movq   $0x0,0x17fe0(%rip)        # 1f0e8 <fwp_ntapes>
    7104:	00 00 00 00 
    7108:	48 c7 05 c5 7f 01 00 	movq   $0x0,0x17fc5(%rip)        # 1f0d8 <fwp_tape_next_slot>
    710f:	00 00 00 00 
    7113:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7118:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    711f:	00 00 
    7121:	75 0b                	jne    712e <fwp_tape_finish+0x10e>
    7123:	48 83 c4 48          	add    $0x48,%rsp
    7127:	5b                   	pop    %rbx
    7128:	5d                   	pop    %rbp
    7129:	41 5c                	pop    %r12
    712b:	41 5d                	pop    %r13
    712d:	c3                   	ret
    712e:	e8 1d c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    7133:	66 90                	xchg   %ax,%ax
    7135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    713c:	00 00 00 00 

0000000000007140 <fwp_tape_scope_release>:
    7140:	f3 0f 1e fa          	endbr64
    7144:	41 55                	push   %r13
    7146:	41 54                	push   %r12
    7148:	55                   	push   %rbp
    7149:	53                   	push   %rbx
    714a:	48 83 ec 48          	sub    $0x48,%rsp
    714e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7155:	00 00 
    7157:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    715c:	48 63 07             	movslq (%rdi),%rax
    715f:	85 c0                	test   %eax,%eax
    7161:	0f 88 e8 00 00 00    	js     724f <fwp_tape_scope_release+0x10f>
    7167:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    716e:	ec c4 4e 
    7171:	48 89 fb             	mov    %rdi,%rbx
    7174:	48 89 e5             	mov    %rsp,%rbp
    7177:	eb 1f                	jmp    7198 <fwp_tape_scope_release+0x58>
    7179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7180:	e8 9b df ff ff       	call   5120 <fwp_tape_buffers_dispose>
    7185:	4c 89 ef             	mov    %r13,%rdi
    7188:	e8 83 fd ff ff       	call   6f10 <fwp_owned_tape_release>
    718d:	48 63 03             	movslq (%rbx),%rax
    7190:	85 c0                	test   %eax,%eax
    7192:	0f 88 b7 00 00 00    	js     724f <fwp_tape_scope_release+0x10f>
    7198:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    719c:	48 8b 35 4d 7f 01 00 	mov    0x17f4d(%rip),%rsi        # 1f0f0 <fwp_tapes>
    71a3:	4c 01 c6             	add    %r8,%rsi
    71a6:	48 89 f7             	mov    %rsi,%rdi
    71a9:	e8 c2 ca ff ff       	call   3c70 <fwp_tape_unlink_scope>
    71ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    71b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    71b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    71bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    71c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    71c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    71ce:	00 
    71cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    71d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    71d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    71dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    71e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    71eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    71f2:	00 
    71f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    71fa:	00 
    71fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7202:	00 
    7203:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7207:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    720b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    720f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7213:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7219:	77 18                	ja     7233 <fwp_tape_scope_release+0xf3>
    721b:	49 c1 f8 03          	sar    $0x3,%r8
    721f:	4d 0f af c4          	imul   %r12,%r8
    7223:	4c 3b 05 ae 7e 01 00 	cmp    0x17eae(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    722a:	7d 07                	jge    7233 <fwp_tape_scope_release+0xf3>
    722c:	4c 89 05 a5 7e 01 00 	mov    %r8,0x17ea5(%rip)        # 1f0d8 <fwp_tape_next_slot>
    7233:	48 89 ef             	mov    %rbp,%rdi
    7236:	4d 85 ed             	test   %r13,%r13
    7239:	0f 85 41 ff ff ff    	jne    7180 <fwp_tape_scope_release+0x40>
    723f:	e8 fc df ff ff       	call   5240 <fwp_tape_buffers_release>
    7244:	48 63 03             	movslq (%rbx),%rax
    7247:	85 c0                	test   %eax,%eax
    7249:	0f 89 49 ff ff ff    	jns    7198 <fwp_tape_scope_release+0x58>
    724f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7254:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    725b:	00 00 
    725d:	75 0b                	jne    726a <fwp_tape_scope_release+0x12a>
    725f:	48 83 c4 48          	add    $0x48,%rsp
    7263:	5b                   	pop    %rbx
    7264:	5d                   	pop    %rbp
    7265:	41 5c                	pop    %r12
    7267:	41 5d                	pop    %r13
    7269:	c3                   	ret
    726a:	e8 e1 c1 ff ff       	call   3450 <__stack_chk_fail@plt>
    726f:	90                   	nop

0000000000007270 <fwp_drop4>:
    7270:	48 8b 0d 81 19 06 00 	mov    0x61981(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7277:	48 89 f8             	mov    %rdi,%rax
    727a:	48 2b 05 4f 19 06 00 	sub    0x6194f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7281:	48 c1 e1 10          	shl    $0x10,%rcx
    7285:	48 39 c8             	cmp    %rcx,%rax
    7288:	0f 83 42 01 00 00    	jae    73d0 <fwp_drop4+0x160>
    728e:	48 83 ec 18          	sub    $0x18,%rsp
    7292:	48 89 fa             	mov    %rdi,%rdx
    7295:	4c 8d 05 84 05 06 00 	lea    0x60584(%rip),%r8        # 67820 <fwp_heap>
    729c:	48 89 c1             	mov    %rax,%rcx
    729f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    72a6:	48 c1 e9 10          	shr    $0x10,%rcx
    72aa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    72ae:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    72b2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    72b6:	48 85 c9             	test   %rcx,%rcx
    72b9:	74 40                	je     72fb <fwp_drop4+0x8b>
    72bb:	0f b6 3e             	movzbl (%rsi),%edi
    72be:	40 80 ff 02          	cmp    $0x2,%dil
    72c2:	74 3c                	je     7300 <fwp_drop4+0x90>
    72c4:	40 80 ff 01          	cmp    $0x1,%dil
    72c8:	75 31                	jne    72fb <fwp_drop4+0x8b>
    72ca:	8b 7e 18             	mov    0x18(%rsi),%edi
    72cd:	0f b7 c0             	movzwl %ax,%eax
    72d0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    72d3:	48 0f af c7          	imul   %rdi,%rax
    72d7:	48 c1 e8 20          	shr    $0x20,%rax
    72db:	48 39 f0             	cmp    %rsi,%rax
    72de:	73 1b                	jae    72fb <fwp_drop4+0x8b>
    72e0:	48 01 c1             	add    %rax,%rcx
    72e3:	0f b6 01             	movzbl (%rcx),%eax
    72e6:	84 c0                	test   %al,%al
    72e8:	74 11                	je     72fb <fwp_drop4+0x8b>
    72ea:	3c 01                	cmp    $0x1,%al
    72ec:	74 22                	je     7310 <fwp_drop4+0xa0>
    72ee:	3c ff                	cmp    $0xff,%al
    72f0:	0f 84 0a 01 00 00    	je     7400 <fwp_drop4+0x190>
    72f6:	83 e8 01             	sub    $0x1,%eax
    72f9:	88 01                	mov    %al,(%rcx)
    72fb:	48 83 c4 18          	add    $0x18,%rsp
    72ff:	c3                   	ret
    7300:	66 85 c0             	test   %ax,%ax
    7303:	74 de                	je     72e3 <fwp_drop4+0x73>
    7305:	48 83 c4 18          	add    $0x18,%rsp
    7309:	c3                   	ret
    730a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7310:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7314:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    731b:	48 89 f8             	mov    %rdi,%rax
    731e:	48 c1 e1 10          	shl    $0x10,%rcx
    7322:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7329:	48 39 c8             	cmp    %rcx,%rax
    732c:	73 62                	jae    7390 <fwp_drop4+0x120>
    732e:	48 89 c1             	mov    %rax,%rcx
    7331:	48 c1 e9 10          	shr    $0x10,%rcx
    7335:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7339:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    733d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7341:	48 85 c9             	test   %rcx,%rcx
    7344:	74 4a                	je     7390 <fwp_drop4+0x120>
    7346:	44 0f b6 0e          	movzbl (%rsi),%r9d
    734a:	41 80 f9 02          	cmp    $0x2,%r9b
    734e:	0f 84 9c 00 00 00    	je     73f0 <fwp_drop4+0x180>
    7354:	41 80 f9 01          	cmp    $0x1,%r9b
    7358:	75 36                	jne    7390 <fwp_drop4+0x120>
    735a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    735e:	0f b7 c0             	movzwl %ax,%eax
    7361:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7364:	49 0f af c1          	imul   %r9,%rax
    7368:	48 c1 e8 20          	shr    $0x20,%rax
    736c:	48 39 f0             	cmp    %rsi,%rax
    736f:	73 1f                	jae    7390 <fwp_drop4+0x120>
    7371:	48 01 c1             	add    %rax,%rcx
    7374:	0f b6 01             	movzbl (%rcx),%eax
    7377:	84 c0                	test   %al,%al
    7379:	74 15                	je     7390 <fwp_drop4+0x120>
    737b:	3c 01                	cmp    $0x1,%al
    737d:	74 59                	je     73d8 <fwp_drop4+0x168>
    737f:	3c ff                	cmp    $0xff,%al
    7381:	0f 84 ff 00 00 00    	je     7486 <fwp_drop4+0x216>
    7387:	83 e8 01             	sub    $0x1,%eax
    738a:	88 01                	mov    %al,(%rcx)
    738c:	0f 1f 40 00          	nopl   0x0(%rax)
    7390:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7394:	48 89 d7             	mov    %rdx,%rdi
    7397:	48 89 0c 24          	mov    %rcx,(%rsp)
    739b:	e8 f0 f6 ff ff       	call   6a90 <fwp_rc_free_obj>
    73a0:	4c 8d 05 79 04 06 00 	lea    0x60479(%rip),%r8        # 67820 <fwp_heap>
    73a7:	48 8b 04 24          	mov    (%rsp),%rax
    73ab:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    73b2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    73b9:	48 c1 e2 10          	shl    $0x10,%rdx
    73bd:	48 39 d0             	cmp    %rdx,%rax
    73c0:	0f 83 35 ff ff ff    	jae    72fb <fwp_drop4+0x8b>
    73c6:	48 8b 14 24          	mov    (%rsp),%rdx
    73ca:	e9 cd fe ff ff       	jmp    729c <fwp_drop4+0x2c>
    73cf:	90                   	nop
    73d0:	c3                   	ret
    73d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73d8:	48 89 14 24          	mov    %rdx,(%rsp)
    73dc:	e8 af f6 ff ff       	call   6a90 <fwp_rc_free_obj>
    73e1:	48 8b 14 24          	mov    (%rsp),%rdx
    73e5:	eb a9                	jmp    7390 <fwp_drop4+0x120>
    73e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73ee:	00 00 
    73f0:	66 85 c0             	test   %ax,%ax
    73f3:	75 9b                	jne    7390 <fwp_drop4+0x120>
    73f5:	e9 7a ff ff ff       	jmp    7374 <fwp_drop4+0x104>
    73fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7400:	48 89 c8             	mov    %rcx,%rax
    7403:	48 c1 e8 11          	shr    $0x11,%rax
    7407:	48 31 c8             	xor    %rcx,%rax
    740a:	48 89 c2             	mov    %rax,%rdx
    740d:	48 c1 ea 09          	shr    $0x9,%rdx
    7411:	48 31 d0             	xor    %rdx,%rax
    7414:	0f b6 d0             	movzbl %al,%edx
    7417:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    741e:	00 
    741f:	48 85 c0             	test   %rax,%rax
    7422:	75 29                	jne    744d <fwp_drop4+0x1dd>
    7424:	e9 e3 00 00 00       	jmp    750c <fwp_drop4+0x29c>
    7429:	90                   	nop
    742a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7431:	00 00 00 00 
    7435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    743c:	00 00 00 00 
    7440:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7444:	48 85 c0             	test   %rax,%rax
    7447:	0f 84 bf 00 00 00    	je     750c <fwp_drop4+0x29c>
    744d:	48 89 c2             	mov    %rax,%rdx
    7450:	48 39 08             	cmp    %rcx,(%rax)
    7453:	75 eb                	jne    7440 <fwp_drop4+0x1d0>
    7455:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7459:	48 83 ea 01          	sub    $0x1,%rdx
    745d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7461:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7468:	0f 85 8d fe ff ff    	jne    72fb <fwp_drop4+0x8b>
    746e:	48 89 cf             	mov    %rcx,%rdi
    7471:	48 89 0c 24          	mov    %rcx,(%rsp)
    7475:	e8 36 e3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    747a:	48 8b 0c 24          	mov    (%rsp),%rcx
    747e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7481:	e9 75 fe ff ff       	jmp    72fb <fwp_drop4+0x8b>
    7486:	48 89 ce             	mov    %rcx,%rsi
    7489:	48 c1 ee 11          	shr    $0x11,%rsi
    748d:	48 31 ce             	xor    %rcx,%rsi
    7490:	48 89 f0             	mov    %rsi,%rax
    7493:	48 c1 e8 09          	shr    $0x9,%rax
    7497:	48 31 c6             	xor    %rax,%rsi
    749a:	40 0f b6 f6          	movzbl %sil,%esi
    749e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    74a5:	00 
    74a6:	48 85 c0             	test   %rax,%rax
    74a9:	75 1e                	jne    74c9 <fwp_drop4+0x259>
    74ab:	eb 5f                	jmp    750c <fwp_drop4+0x29c>
    74ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    74b4:	00 
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 
    74c0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	74 43                	je     750c <fwp_drop4+0x29c>
    74c9:	48 89 c6             	mov    %rax,%rsi
    74cc:	48 39 08             	cmp    %rcx,(%rax)
    74cf:	75 ef                	jne    74c0 <fwp_drop4+0x250>
    74d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d5:	48 83 ee 01          	sub    $0x1,%rsi
    74d9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    74dd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    74e4:	0f 85 a6 fe ff ff    	jne    7390 <fwp_drop4+0x120>
    74ea:	48 89 cf             	mov    %rcx,%rdi
    74ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    74f2:	48 89 0c 24          	mov    %rcx,(%rsp)
    74f6:	e8 b5 e2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    74fb:	48 8b 0c 24          	mov    (%rsp),%rcx
    74ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7504:	c6 01 fe             	movb   $0xfe,(%rcx)
    7507:	e9 84 fe ff ff       	jmp    7390 <fwp_drop4+0x120>
    750c:	48 8d 3d 95 44 00 00 	lea    0x4495(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7513:	e8 18 cf ff ff       	call   4430 <fwp_trap>
    7518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    751f:	00 

0000000000007520 <fwp_arg_drop37>:
    7520:	f3 0f 1e fa          	endbr64
    7524:	85 f6                	test   %esi,%esi
    7526:	75 04                	jne    752c <fwp_arg_drop37+0xc>
    7528:	85 d2                	test   %edx,%edx
    752a:	75 04                	jne    7530 <fwp_arg_drop37+0x10>
    752c:	c3                   	ret
    752d:	0f 1f 00             	nopl   (%rax)
    7530:	48 8b 3f             	mov    (%rdi),%rdi
    7533:	e9 38 fd ff ff       	jmp    7270 <fwp_drop4>
    7538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    753f:	00 

0000000000007540 <fwp_task_dispose>:
    7540:	53                   	push   %rbx
    7541:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7545:	0f 84 db c1 ff ff    	je     3726 <fwp_task_dispose.cold>
    754b:	48 89 fb             	mov    %rdi,%rbx
    754e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7553:	0f 85 cd c1 ff ff    	jne    3726 <fwp_task_dispose.cold>
    7559:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    755d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7564:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    756b:	00 
    756c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7570:	48 85 ff             	test   %rdi,%rdi
    7573:	74 07                	je     757c <fwp_task_dispose+0x3c>
    7575:	48 85 c0             	test   %rax,%rax
    7578:	74 02                	je     757c <fwp_task_dispose+0x3c>
    757a:	ff d0                	call   *%rax
    757c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7583:	e8 68 e4 ff ff       	call   59f0 <fwp_mem_free>
    7588:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    758f:	00 00 00 00 
    7593:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7597:	74 6f                	je     7608 <fwp_task_dispose+0xc8>
    7599:	48 8b 15 58 16 06 00 	mov    0x61658(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    75a0:	48 89 d8             	mov    %rbx,%rax
    75a3:	48 2b 05 26 16 06 00 	sub    0x61626(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    75aa:	48 c1 e2 10          	shl    $0x10,%rdx
    75ae:	48 39 d0             	cmp    %rdx,%rax
    75b1:	73 4c                	jae    75ff <fwp_task_dispose+0xbf>
    75b3:	48 89 c2             	mov    %rax,%rdx
    75b6:	48 c1 ea 10          	shr    $0x10,%rdx
    75ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75be:	48 8b 15 53 16 06 00 	mov    0x61653(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    75c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75c9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75cd:	48 85 c9             	test   %rcx,%rcx
    75d0:	74 2d                	je     75ff <fwp_task_dispose+0xbf>
    75d2:	0f b6 32             	movzbl (%rdx),%esi
    75d5:	40 80 fe 02          	cmp    $0x2,%sil
    75d9:	74 3d                	je     7618 <fwp_task_dispose+0xd8>
    75db:	40 80 fe 01          	cmp    $0x1,%sil
    75df:	75 1e                	jne    75ff <fwp_task_dispose+0xbf>
    75e1:	8b 72 18             	mov    0x18(%rdx),%esi
    75e4:	0f b7 c0             	movzwl %ax,%eax
    75e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    75ea:	48 0f af c6          	imul   %rsi,%rax
    75ee:	48 c1 e8 20          	shr    $0x20,%rax
    75f2:	48 39 d0             	cmp    %rdx,%rax
    75f5:	73 08                	jae    75ff <fwp_task_dispose+0xbf>
    75f7:	48 01 c1             	add    %rax,%rcx
    75fa:	80 39 01             	cmpb   $0x1,(%rcx)
    75fd:	74 09                	je     7608 <fwp_task_dispose+0xc8>
    75ff:	5b                   	pop    %rbx
    7600:	c3                   	ret
    7601:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7608:	48 89 df             	mov    %rbx,%rdi
    760b:	5b                   	pop    %rbx
    760c:	e9 df e3 ff ff       	jmp    59f0 <fwp_mem_free>
    7611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7618:	66 85 c0             	test   %ax,%ax
    761b:	74 dd                	je     75fa <fwp_task_dispose+0xba>
    761d:	5b                   	pop    %rbx
    761e:	c3                   	ret
    761f:	90                   	nop

0000000000007620 <fwp_free_zombie>:
    7620:	48 8b 15 c9 01 06 00 	mov    0x601c9(%rip),%rdx        # 677f0 <fwp_zombie>
    7627:	48 85 d2             	test   %rdx,%rdx
    762a:	0f 84 98 00 00 00    	je     76c8 <fwp_free_zombie+0xa8>
    7630:	48 3b 15 c9 01 06 00 	cmp    0x601c9(%rip),%rdx        # 67800 <fwp_cur>
    7637:	0f 84 8b 00 00 00    	je     76c8 <fwp_free_zombie+0xa8>
    763d:	48 83 ec 18          	sub    $0x18,%rsp
    7641:	48 63 05 8c fb 05 00 	movslq 0x5fb8c(%rip),%rax        # 671d4 <fwp_stack_pool_n>
    7648:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    764c:	83 f8 3f             	cmp    $0x3f,%eax
    764f:	7f 7f                	jg     76d0 <fwp_free_zombie+0xb0>
    7651:	8d 48 01             	lea    0x1(%rax),%ecx
    7654:	89 0d 7a fb 05 00    	mov    %ecx,0x5fb7a(%rip)        # 671d4 <fwp_stack_pool_n>
    765a:	48 8d 0d 7f fb 05 00 	lea    0x5fb7f(%rip),%rcx        # 671e0 <fwp_stack_pool>
    7661:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7665:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    766c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7670:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7677:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    767b:	48 85 c9             	test   %rcx,%rcx
    767e:	0f 84 fc 00 00 00    	je     7780 <fwp_free_zombie+0x160>
    7684:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    768b:	48 85 c0             	test   %rax,%rax
    768e:	74 07                	je     7697 <fwp_free_zombie+0x77>
    7690:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7697:	8b 42 5c             	mov    0x5c(%rdx),%eax
    769a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    769e:	48 c7 05 47 01 06 00 	movq   $0x0,0x60147(%rip)        # 677f0 <fwp_zombie>
    76a5:	00 00 00 00 
    76a9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    76b0:	85 c0                	test   %eax,%eax
    76b2:	74 34                	je     76e8 <fwp_free_zombie+0xc8>
    76b4:	83 f8 01             	cmp    $0x1,%eax
    76b7:	0f 84 b3 00 00 00    	je     7770 <fwp_free_zombie+0x150>
    76bd:	48 83 c4 18          	add    $0x18,%rsp
    76c1:	c3                   	ret
    76c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76c8:	c3                   	ret
    76c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76d0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    76d4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    76d9:	e8 e2 be ff ff       	call   35c0 <munmap@plt>
    76de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    76e3:	eb 80                	jmp    7665 <fwp_free_zombie+0x45>
    76e5:	0f 1f 00             	nopl   (%rax)
    76e8:	48 8b 0d 09 15 06 00 	mov    0x61509(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    76ef:	48 89 d0             	mov    %rdx,%rax
    76f2:	48 2b 05 d7 14 06 00 	sub    0x614d7(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    76f9:	48 c1 e1 10          	shl    $0x10,%rcx
    76fd:	48 39 c8             	cmp    %rcx,%rax
    7700:	73 bb                	jae    76bd <fwp_free_zombie+0x9d>
    7702:	48 89 c1             	mov    %rax,%rcx
    7705:	48 c1 e9 10          	shr    $0x10,%rcx
    7709:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    770d:	48 8b 0d 04 15 06 00 	mov    0x61504(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    7714:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7718:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    771c:	48 85 c9             	test   %rcx,%rcx
    771f:	74 9c                	je     76bd <fwp_free_zombie+0x9d>
    7721:	0f b6 3e             	movzbl (%rsi),%edi
    7724:	40 80 ff 02          	cmp    $0x2,%dil
    7728:	74 66                	je     7790 <fwp_free_zombie+0x170>
    772a:	40 80 ff 01          	cmp    $0x1,%dil
    772e:	75 8d                	jne    76bd <fwp_free_zombie+0x9d>
    7730:	8b 7e 18             	mov    0x18(%rsi),%edi
    7733:	0f b7 c0             	movzwl %ax,%eax
    7736:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7739:	48 0f af c7          	imul   %rdi,%rax
    773d:	48 c1 e8 20          	shr    $0x20,%rax
    7741:	48 39 f0             	cmp    %rsi,%rax
    7744:	0f 83 73 ff ff ff    	jae    76bd <fwp_free_zombie+0x9d>
    774a:	48 01 c1             	add    %rax,%rcx
    774d:	0f b6 01             	movzbl (%rcx),%eax
    7750:	84 c0                	test   %al,%al
    7752:	0f 84 65 ff ff ff    	je     76bd <fwp_free_zombie+0x9d>
    7758:	3c 01                	cmp    $0x1,%al
    775a:	74 14                	je     7770 <fwp_free_zombie+0x150>
    775c:	3c ff                	cmp    $0xff,%al
    775e:	74 3b                	je     779b <fwp_free_zombie+0x17b>
    7760:	83 e8 01             	sub    $0x1,%eax
    7763:	88 01                	mov    %al,(%rcx)
    7765:	e9 53 ff ff ff       	jmp    76bd <fwp_free_zombie+0x9d>
    776a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7770:	48 89 d7             	mov    %rdx,%rdi
    7773:	48 83 c4 18          	add    $0x18,%rsp
    7777:	e9 c4 fd ff ff       	jmp    7540 <fwp_task_dispose>
    777c:	0f 1f 40 00          	nopl   0x0(%rax)
    7780:	48 89 05 41 00 06 00 	mov    %rax,0x60041(%rip)        # 677c8 <fwp_tasks_active>
    7787:	e9 ff fe ff ff       	jmp    768b <fwp_free_zombie+0x6b>
    778c:	0f 1f 40 00          	nopl   0x0(%rax)
    7790:	66 85 c0             	test   %ax,%ax
    7793:	0f 85 24 ff ff ff    	jne    76bd <fwp_free_zombie+0x9d>
    7799:	eb b2                	jmp    774d <fwp_free_zombie+0x12d>
    779b:	48 89 ca             	mov    %rcx,%rdx
    779e:	48 8d 35 7b 00 06 00 	lea    0x6007b(%rip),%rsi        # 67820 <fwp_heap>
    77a5:	48 c1 ea 11          	shr    $0x11,%rdx
    77a9:	48 31 ca             	xor    %rcx,%rdx
    77ac:	48 89 d0             	mov    %rdx,%rax
    77af:	48 c1 e8 09          	shr    $0x9,%rax
    77b3:	48 31 c2             	xor    %rax,%rdx
    77b6:	0f b6 d2             	movzbl %dl,%edx
    77b9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    77c0:	00 
    77c1:	48 85 c0             	test   %rax,%rax
    77c4:	75 23                	jne    77e9 <fwp_free_zombie+0x1c9>
    77c6:	eb 5c                	jmp    7824 <fwp_free_zombie+0x204>
    77c8:	66 90                	xchg   %ax,%ax
    77ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77d1:	00 00 00 00 
    77d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77dc:	00 00 00 00 
    77e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    77e4:	48 85 c0             	test   %rax,%rax
    77e7:	74 3b                	je     7824 <fwp_free_zombie+0x204>
    77e9:	48 89 c2             	mov    %rax,%rdx
    77ec:	48 39 08             	cmp    %rcx,(%rax)
    77ef:	75 ef                	jne    77e0 <fwp_free_zombie+0x1c0>
    77f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    77f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    77fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7804:	0f 85 b3 fe ff ff    	jne    76bd <fwp_free_zombie+0x9d>
    780a:	48 89 cf             	mov    %rcx,%rdi
    780d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7812:	e8 99 df ff ff       	call   57b0 <fwp_rc_forget_slot>
    7817:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    781c:	c6 01 fe             	movb   $0xfe,(%rcx)
    781f:	e9 99 fe ff ff       	jmp    76bd <fwp_free_zombie+0x9d>
    7824:	48 8d 3d 7d 41 00 00 	lea    0x417d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    782b:	e8 00 cc ff ff       	call   4430 <fwp_trap>

0000000000007830 <fwp_block>:
    7830:	48 83 ec 08          	sub    $0x8,%rsp
    7834:	48 8b 05 ad ff 05 00 	mov    0x5ffad(%rip),%rax        # 677e8 <fwp_ready_head>
    783b:	48 85 c0             	test   %rax,%rax
    783e:	0f 84 1c 01 00 00    	je     7960 <fwp_block+0x130>
    7844:	90                   	nop
    7845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    784c:	00 00 00 00 
    7850:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7857:	48 89 15 8a ff 05 00 	mov    %rdx,0x5ff8a(%rip)        # 677e8 <fwp_ready_head>
    785e:	48 85 d2             	test   %rdx,%rdx
    7861:	0f 84 19 01 00 00    	je     7980 <fwp_block+0x150>
    7867:	48 8b 15 92 ff 05 00 	mov    0x5ff92(%rip),%rdx        # 67800 <fwp_cur>
    786e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7872:	48 39 c2             	cmp    %rax,%rdx
    7875:	0f 84 d5 00 00 00    	je     7950 <fwp_block+0x120>
    787b:	48 8b 0d 06 1c 06 00 	mov    0x61c06(%rip),%rcx        # 69488 <fwp_state_owners>
    7882:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7886:	48 89 05 73 ff 05 00 	mov    %rax,0x5ff73(%rip)        # 67800 <fwp_cur>
    788d:	f3 0f 7e 05 1b 1c 06 	movq   0x61c1b(%rip),%xmm0        # 694b0 <fwp_foreign_callbacks>
    7894:	00 
    7895:	0f 16 05 04 1c 06 00 	movhps 0x61c04(%rip),%xmm0        # 694a0 <fwp_state>
    789c:	f3 0f 7e 0d 04 1c 06 	movq   0x61c04(%rip),%xmm1        # 694a8 <fwp_handlers>
    78a3:	00 
    78a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    78ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    78b2:	0f 16 0d ff 1b 06 00 	movhps 0x61bff(%rip),%xmm1        # 694b8 <fwp_cleanups>
    78b9:	f3 0f 7e 05 d7 1b 06 	movq   0x61bd7(%rip),%xmm0        # 69498 <fwp_state_len>
    78c0:	00 
    78c1:	0f 16 05 c8 1b 06 00 	movhps 0x61bc8(%rip),%xmm0        # 69490 <fwp_state_cap>
    78c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    78cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    78d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    78e1:	48 89 0d c0 1b 06 00 	mov    %rcx,0x61bc0(%rip)        # 694a8 <fwp_handlers>
    78e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    78ef:	48 89 0d c2 1b 06 00 	mov    %rcx,0x61bc2(%rip)        # 694b8 <fwp_cleanups>
    78f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    78fd:	48 89 0d ac 1b 06 00 	mov    %rcx,0x61bac(%rip)        # 694b0 <fwp_foreign_callbacks>
    7904:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    790b:	48 89 0d 8e 1b 06 00 	mov    %rcx,0x61b8e(%rip)        # 694a0 <fwp_state>
    7912:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7919:	48 89 0d 78 1b 06 00 	mov    %rcx,0x61b78(%rip)        # 69498 <fwp_state_len>
    7920:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7927:	48 89 0d 62 1b 06 00 	mov    %rcx,0x61b62(%rip)        # 69490 <fwp_state_cap>
    792e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7935:	48 89 0d 4c 1b 06 00 	mov    %rcx,0x61b4c(%rip)        # 69488 <fwp_state_owners>
    793c:	e8 3f bb ff ff       	call   3480 <swapcontext@plt>
    7941:	f3 0f 1e fa          	endbr64
    7945:	e8 d6 fc ff ff       	call   7620 <fwp_free_zombie>
    794a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7950:	8b 05 7a f8 05 00    	mov    0x5f87a(%rip),%eax        # 671d0 <fwp_slice>
    7956:	85 c0                	test   %eax,%eax
    7958:	74 36                	je     7990 <fwp_block+0x160>
    795a:	48 83 c4 08          	add    $0x8,%rsp
    795e:	c3                   	ret
    795f:	90                   	nop
    7960:	e8 8b da ff ff       	call   53f0 <fwp_poll_events>
    7965:	48 8b 05 7c fe 05 00 	mov    0x5fe7c(%rip),%rax        # 677e8 <fwp_ready_head>
    796c:	48 85 c0             	test   %rax,%rax
    796f:	0f 85 db fe ff ff    	jne    7850 <fwp_block+0x20>
    7975:	eb e9                	jmp    7960 <fwp_block+0x130>
    7977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    797e:	00 00 
    7980:	48 c7 05 55 fe 05 00 	movq   $0x0,0x5fe55(%rip)        # 677e0 <fwp_ready_tail>
    7987:	00 00 00 00 
    798b:	e9 d7 fe ff ff       	jmp    7867 <fwp_block+0x37>
    7990:	48 8d 3d 48 38 00 00 	lea    0x3848(%rip),%rdi        # b1df <_IO_stdin_used+0x1df>
    7997:	e8 f4 b9 ff ff       	call   3390 <getenv@plt>
    799c:	ba 10 27 00 00       	mov    $0x2710,%edx
    79a1:	48 85 c0             	test   %rax,%rax
    79a4:	74 05                	je     79ab <fwp_block+0x17b>
    79a6:	80 38 00             	cmpb   $0x0,(%rax)
    79a9:	75 0b                	jne    79b6 <fwp_block+0x186>
    79ab:	89 15 1f f8 05 00    	mov    %edx,0x5f81f(%rip)        # 671d0 <fwp_slice>
    79b1:	48 83 c4 08          	add    $0x8,%rsp
    79b5:	c3                   	ret
    79b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    79bb:	31 f6                	xor    %esi,%esi
    79bd:	48 89 c7             	mov    %rax,%rdi
    79c0:	e8 7b bb ff ff       	call   3540 <strtoll@plt>
    79c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    79c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    79d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    79d5:	0f 46 d0             	cmovbe %eax,%edx
    79d8:	eb d1                	jmp    79ab <fwp_block+0x17b>
    79da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000079e0 <fwp_caps173>:
    79e0:	f3 0f 1e fa          	endbr64
    79e4:	85 f6                	test   %esi,%esi
    79e6:	74 08                	je     79f0 <fwp_caps173+0x10>
    79e8:	c3                   	ret
    79e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79f0:	48 8b 15 01 12 06 00 	mov    0x61201(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    79f7:	48 89 f8             	mov    %rdi,%rax
    79fa:	48 2b 05 cf 11 06 00 	sub    0x611cf(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7a01:	48 c1 e2 10          	shl    $0x10,%rdx
    7a05:	48 39 d0             	cmp    %rdx,%rax
    7a08:	73 de                	jae    79e8 <fwp_caps173+0x8>
    7a0a:	48 89 c2             	mov    %rax,%rdx
    7a0d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a15:	48 8b 15 fc 11 06 00 	mov    0x611fc(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    7a1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a20:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7a24:	48 85 c9             	test   %rcx,%rcx
    7a27:	74 bf                	je     79e8 <fwp_caps173+0x8>
    7a29:	0f b6 32             	movzbl (%rdx),%esi
    7a2c:	40 80 fe 02          	cmp    $0x2,%sil
    7a30:	74 2e                	je     7a60 <fwp_caps173+0x80>
    7a32:	40 80 fe 01          	cmp    $0x1,%sil
    7a36:	75 b0                	jne    79e8 <fwp_caps173+0x8>
    7a38:	8b 72 18             	mov    0x18(%rdx),%esi
    7a3b:	0f b7 c0             	movzwl %ax,%eax
    7a3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a41:	48 0f af c6          	imul   %rsi,%rax
    7a45:	48 c1 e8 20          	shr    $0x20,%rax
    7a49:	48 39 d0             	cmp    %rdx,%rax
    7a4c:	73 9a                	jae    79e8 <fwp_caps173+0x8>
    7a4e:	48 01 c1             	add    %rax,%rcx
    7a51:	80 39 01             	cmpb   $0x1,(%rcx)
    7a54:	75 92                	jne    79e8 <fwp_caps173+0x8>
    7a56:	e9 95 df ff ff       	jmp    59f0 <fwp_mem_free>
    7a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a60:	66 85 c0             	test   %ax,%ax
    7a63:	74 ec                	je     7a51 <fwp_caps173+0x71>
    7a65:	c3                   	ret
    7a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a6d:	00 00 00 

0000000000007a70 <fwp_args37>:
    7a70:	f3 0f 1e fa          	endbr64
    7a74:	85 d2                	test   %edx,%edx
    7a76:	74 04                	je     7a7c <fwp_args37+0xc>
    7a78:	85 f6                	test   %esi,%esi
    7a7a:	74 04                	je     7a80 <fwp_args37+0x10>
    7a7c:	c3                   	ret
    7a7d:	0f 1f 00             	nopl   (%rax)
    7a80:	48 8b 15 71 11 06 00 	mov    0x61171(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7a87:	48 8b 07             	mov    (%rdi),%rax
    7a8a:	48 2b 05 3f 11 06 00 	sub    0x6113f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7a91:	48 c1 e2 10          	shl    $0x10,%rdx
    7a95:	48 39 d0             	cmp    %rdx,%rax
    7a98:	73 e2                	jae    7a7c <fwp_args37+0xc>
    7a9a:	48 89 c2             	mov    %rax,%rdx
    7a9d:	48 c1 ea 10          	shr    $0x10,%rdx
    7aa1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7aa5:	48 8b 15 6c 11 06 00 	mov    0x6116c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    7aac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ab0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ab4:	48 85 ff             	test   %rdi,%rdi
    7ab7:	74 c3                	je     7a7c <fwp_args37+0xc>
    7ab9:	0f b6 0a             	movzbl (%rdx),%ecx
    7abc:	80 f9 02             	cmp    $0x2,%cl
    7abf:	74 4f                	je     7b10 <fwp_args37+0xa0>
    7ac1:	80 f9 01             	cmp    $0x1,%cl
    7ac4:	75 b6                	jne    7a7c <fwp_args37+0xc>
    7ac6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ac9:	0f b7 c0             	movzwl %ax,%eax
    7acc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7acf:	48 0f af c1          	imul   %rcx,%rax
    7ad3:	48 c1 e8 20          	shr    $0x20,%rax
    7ad7:	48 39 d0             	cmp    %rdx,%rax
    7ada:	73 a0                	jae    7a7c <fwp_args37+0xc>
    7adc:	48 01 c7             	add    %rax,%rdi
    7adf:	0f b6 07             	movzbl (%rdi),%eax
    7ae2:	84 c0                	test   %al,%al
    7ae4:	74 96                	je     7a7c <fwp_args37+0xc>
    7ae6:	8b 15 fc 19 06 00    	mov    0x619fc(%rip),%edx        # 694e8 <iteration_active>
    7aec:	85 d2                	test   %edx,%edx
    7aee:	75 10                	jne    7b00 <fwp_args37+0x90>
    7af0:	3c fd                	cmp    $0xfd,%al
    7af2:	77 22                	ja     7b16 <fwp_args37+0xa6>
    7af4:	83 c0 01             	add    $0x1,%eax
    7af7:	88 07                	mov    %al,(%rdi)
    7af9:	c3                   	ret
    7afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b00:	48 83 05 c8 19 06 00 	addq   $0x1,0x619c8(%rip)        # 694d0 <iteration_retains>
    7b07:	01 
    7b08:	eb e6                	jmp    7af0 <fwp_args37+0x80>
    7b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	74 ca                	je     7adf <fwp_args37+0x6f>
    7b15:	c3                   	ret
    7b16:	e9 75 db ff ff       	jmp    5690 <fwp_rc_wide_dup>
    7b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b20 <fwp_caps37>:
    7b20:	f3 0f 1e fa          	endbr64
    7b24:	48 83 ec 18          	sub    $0x18,%rsp
    7b28:	48 89 f8             	mov    %rdi,%rax
    7b2b:	8b 7f 04             	mov    0x4(%rdi),%edi
    7b2e:	85 ff                	test   %edi,%edi
    7b30:	0f 84 9a 00 00 00    	je     7bd0 <fwp_caps37+0xb0>
    7b36:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7b3a:	85 f6                	test   %esi,%esi
    7b3c:	0f 85 9e 00 00 00    	jne    7be0 <fwp_caps37+0xc0>
    7b42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b47:	e8 24 f7 ff ff       	call   7270 <fwp_drop4>
    7b4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b51:	48 8b 0d a0 10 06 00 	mov    0x610a0(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7b58:	48 89 c2             	mov    %rax,%rdx
    7b5b:	48 2b 15 6e 10 06 00 	sub    0x6106e(%rip),%rdx        # 68bd0 <fwp_heap+0x13b0>
    7b62:	48 c1 e1 10          	shl    $0x10,%rcx
    7b66:	48 39 ca             	cmp    %rcx,%rdx
    7b69:	73 6d                	jae    7bd8 <fwp_caps37+0xb8>
    7b6b:	48 89 d1             	mov    %rdx,%rcx
    7b6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7b72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b76:	48 8b 0d 9b 10 06 00 	mov    0x6109b(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    7b7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7b81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b85:	48 85 f6             	test   %rsi,%rsi
    7b88:	74 4e                	je     7bd8 <fwp_caps37+0xb8>
    7b8a:	0f b6 39             	movzbl (%rcx),%edi
    7b8d:	40 80 ff 02          	cmp    $0x2,%dil
    7b91:	0f 84 c9 00 00 00    	je     7c60 <fwp_caps37+0x140>
    7b97:	40 80 ff 01          	cmp    $0x1,%dil
    7b9b:	75 3b                	jne    7bd8 <fwp_caps37+0xb8>
    7b9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7ba0:	0f b7 d2             	movzwl %dx,%edx
    7ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ba6:	48 0f af d7          	imul   %rdi,%rdx
    7baa:	48 c1 ea 20          	shr    $0x20,%rdx
    7bae:	48 39 ca             	cmp    %rcx,%rdx
    7bb1:	73 25                	jae    7bd8 <fwp_caps37+0xb8>
    7bb3:	48 01 d6             	add    %rdx,%rsi
    7bb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bb9:	75 1d                	jne    7bd8 <fwp_caps37+0xb8>
    7bbb:	48 89 c7             	mov    %rax,%rdi
    7bbe:	48 83 c4 18          	add    $0x18,%rsp
    7bc2:	e9 29 de ff ff       	jmp    59f0 <fwp_mem_free>
    7bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bce:	00 00 
    7bd0:	85 f6                	test   %esi,%esi
    7bd2:	0f 84 79 ff ff ff    	je     7b51 <fwp_caps37+0x31>
    7bd8:	48 83 c4 18          	add    $0x18,%rsp
    7bdc:	c3                   	ret
    7bdd:	0f 1f 00             	nopl   (%rax)
    7be0:	48 8b 05 11 10 06 00 	mov    0x61011(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    7be7:	48 2b 3d e2 0f 06 00 	sub    0x60fe2(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    7bee:	48 c1 e0 10          	shl    $0x10,%rax
    7bf2:	48 39 c7             	cmp    %rax,%rdi
    7bf5:	73 e1                	jae    7bd8 <fwp_caps37+0xb8>
    7bf7:	48 89 f8             	mov    %rdi,%rax
    7bfa:	48 c1 e8 10          	shr    $0x10,%rax
    7bfe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7c02:	48 8b 05 0f 10 06 00 	mov    0x6100f(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    7c09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7c0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7c11:	48 85 c0             	test   %rax,%rax
    7c14:	74 c2                	je     7bd8 <fwp_caps37+0xb8>
    7c16:	0f b6 0a             	movzbl (%rdx),%ecx
    7c19:	80 f9 02             	cmp    $0x2,%cl
    7c1c:	74 52                	je     7c70 <fwp_caps37+0x150>
    7c1e:	80 f9 01             	cmp    $0x1,%cl
    7c21:	75 b5                	jne    7bd8 <fwp_caps37+0xb8>
    7c23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c26:	0f b7 ff             	movzwl %di,%edi
    7c29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c2c:	48 0f af f9          	imul   %rcx,%rdi
    7c30:	48 c1 ef 20          	shr    $0x20,%rdi
    7c34:	48 39 d7             	cmp    %rdx,%rdi
    7c37:	73 9f                	jae    7bd8 <fwp_caps37+0xb8>
    7c39:	48 01 f8             	add    %rdi,%rax
    7c3c:	0f b6 10             	movzbl (%rax),%edx
    7c3f:	84 d2                	test   %dl,%dl
    7c41:	74 95                	je     7bd8 <fwp_caps37+0xb8>
    7c43:	8b 0d 9f 18 06 00    	mov    0x6189f(%rip),%ecx        # 694e8 <iteration_active>
    7c49:	85 c9                	test   %ecx,%ecx
    7c4b:	75 33                	jne    7c80 <fwp_caps37+0x160>
    7c4d:	80 fa fd             	cmp    $0xfd,%dl
    7c50:	77 38                	ja     7c8a <fwp_caps37+0x16a>
    7c52:	83 c2 01             	add    $0x1,%edx
    7c55:	88 10                	mov    %dl,(%rax)
    7c57:	e9 7c ff ff ff       	jmp    7bd8 <fwp_caps37+0xb8>
    7c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c60:	66 85 d2             	test   %dx,%dx
    7c63:	0f 85 6f ff ff ff    	jne    7bd8 <fwp_caps37+0xb8>
    7c69:	e9 48 ff ff ff       	jmp    7bb6 <fwp_caps37+0x96>
    7c6e:	66 90                	xchg   %ax,%ax
    7c70:	66 85 ff             	test   %di,%di
    7c73:	0f 85 5f ff ff ff    	jne    7bd8 <fwp_caps37+0xb8>
    7c79:	eb c1                	jmp    7c3c <fwp_caps37+0x11c>
    7c7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c80:	48 83 05 48 18 06 00 	addq   $0x1,0x61848(%rip)        # 694d0 <iteration_retains>
    7c87:	01 
    7c88:	eb c3                	jmp    7c4d <fwp_caps37+0x12d>
    7c8a:	48 89 c7             	mov    %rax,%rdi
    7c8d:	48 83 c4 18          	add    $0x18,%rsp
    7c91:	e9 fa d9 ff ff       	jmp    5690 <fwp_rc_wide_dup>
    7c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c9d:	00 00 00 

0000000000007ca0 <fwp_drop0>:
    7ca0:	f3 0f 1e fa          	endbr64
    7ca4:	48 8b 15 4d 0f 06 00 	mov    0x60f4d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7cab:	48 89 f8             	mov    %rdi,%rax
    7cae:	48 2b 05 1b 0f 06 00 	sub    0x60f1b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7cb5:	48 c1 e2 10          	shl    $0x10,%rdx
    7cb9:	48 39 d0             	cmp    %rdx,%rax
    7cbc:	0f 83 36 01 00 00    	jae    7df8 <fwp_drop0+0x158>
    7cc2:	48 83 ec 18          	sub    $0x18,%rsp
    7cc6:	48 8d 35 53 fb 05 00 	lea    0x5fb53(%rip),%rsi        # 67820 <fwp_heap>
    7ccd:	48 89 c2             	mov    %rax,%rdx
    7cd0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7cd7:	48 c1 ea 10          	shr    $0x10,%rdx
    7cdb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7cdf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7ce3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ce7:	48 85 d2             	test   %rdx,%rdx
    7cea:	74 42                	je     7d2e <fwp_drop0+0x8e>
    7cec:	44 0f b6 01          	movzbl (%rcx),%r8d
    7cf0:	41 80 f8 02          	cmp    $0x2,%r8b
    7cf4:	74 42                	je     7d38 <fwp_drop0+0x98>
    7cf6:	41 80 f8 01          	cmp    $0x1,%r8b
    7cfa:	75 32                	jne    7d2e <fwp_drop0+0x8e>
    7cfc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d00:	0f b7 c0             	movzwl %ax,%eax
    7d03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d06:	49 0f af c0          	imul   %r8,%rax
    7d0a:	48 c1 e8 20          	shr    $0x20,%rax
    7d0e:	48 39 c8             	cmp    %rcx,%rax
    7d11:	73 1b                	jae    7d2e <fwp_drop0+0x8e>
    7d13:	48 01 c2             	add    %rax,%rdx
    7d16:	0f b6 02             	movzbl (%rdx),%eax
    7d19:	84 c0                	test   %al,%al
    7d1b:	74 11                	je     7d2e <fwp_drop0+0x8e>
    7d1d:	3c 01                	cmp    $0x1,%al
    7d1f:	74 27                	je     7d48 <fwp_drop0+0xa8>
    7d21:	3c ff                	cmp    $0xff,%al
    7d23:	0f 84 e7 00 00 00    	je     7e10 <fwp_drop0+0x170>
    7d29:	83 e8 01             	sub    $0x1,%eax
    7d2c:	88 02                	mov    %al,(%rdx)
    7d2e:	48 83 c4 18          	add    $0x18,%rsp
    7d32:	c3                   	ret
    7d33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d38:	66 85 c0             	test   %ax,%ax
    7d3b:	74 d9                	je     7d16 <fwp_drop0+0x76>
    7d3d:	48 83 c4 18          	add    $0x18,%rsp
    7d41:	c3                   	ret
    7d42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d48:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d4f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d56:	48 89 f8             	mov    %rdi,%rax
    7d59:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d5d:	48 29 c8             	sub    %rcx,%rax
    7d60:	48 c1 e2 10          	shl    $0x10,%rdx
    7d64:	48 39 d0             	cmp    %rdx,%rax
    7d67:	73 71                	jae    7dda <fwp_drop0+0x13a>
    7d69:	49 89 c2             	mov    %rax,%r10
    7d6c:	49 c1 ea 10          	shr    $0x10,%r10
    7d70:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d74:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d78:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d7c:	4d 85 d2             	test   %r10,%r10
    7d7f:	74 59                	je     7dda <fwp_drop0+0x13a>
    7d81:	45 0f b6 19          	movzbl (%r9),%r11d
    7d85:	41 80 fb 02          	cmp    $0x2,%r11b
    7d89:	74 75                	je     7e00 <fwp_drop0+0x160>
    7d8b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d8f:	75 49                	jne    7dda <fwp_drop0+0x13a>
    7d91:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7d95:	0f b7 c0             	movzwl %ax,%eax
    7d98:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7d9c:	49 0f af c3          	imul   %r11,%rax
    7da0:	48 c1 e8 20          	shr    $0x20,%rax
    7da4:	4c 39 c8             	cmp    %r9,%rax
    7da7:	73 31                	jae    7dda <fwp_drop0+0x13a>
    7da9:	49 01 c2             	add    %rax,%r10
    7dac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7db0:	75 28                	jne    7dda <fwp_drop0+0x13a>
    7db2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7db7:	e8 34 dc ff ff       	call   59f0 <fwp_mem_free>
    7dbc:	48 8d 35 5d fa 05 00 	lea    0x5fa5d(%rip),%rsi        # 67820 <fwp_heap>
    7dc3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7dc8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7dcf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7dd6:	48 c1 e2 10          	shl    $0x10,%rdx
    7dda:	4c 89 c0             	mov    %r8,%rax
    7ddd:	48 29 c8             	sub    %rcx,%rax
    7de0:	48 39 d0             	cmp    %rdx,%rax
    7de3:	0f 83 45 ff ff ff    	jae    7d2e <fwp_drop0+0x8e>
    7de9:	4c 89 c7             	mov    %r8,%rdi
    7dec:	e9 dc fe ff ff       	jmp    7ccd <fwp_drop0+0x2d>
    7df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7df8:	c3                   	ret
    7df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e00:	66 85 c0             	test   %ax,%ax
    7e03:	75 d5                	jne    7dda <fwp_drop0+0x13a>
    7e05:	eb a5                	jmp    7dac <fwp_drop0+0x10c>
    7e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e0e:	00 00 
    7e10:	48 89 d0             	mov    %rdx,%rax
    7e13:	48 c1 e8 11          	shr    $0x11,%rax
    7e17:	48 31 d0             	xor    %rdx,%rax
    7e1a:	48 89 c1             	mov    %rax,%rcx
    7e1d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e21:	48 31 c8             	xor    %rcx,%rax
    7e24:	0f b6 c8             	movzbl %al,%ecx
    7e27:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e2e:	00 
    7e2f:	48 85 c0             	test   %rax,%rax
    7e32:	75 15                	jne    7e49 <fwp_drop0+0x1a9>
    7e34:	eb 4e                	jmp    7e84 <fwp_drop0+0x1e4>
    7e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e3d:	00 00 00 
    7e40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e44:	48 85 c0             	test   %rax,%rax
    7e47:	74 3b                	je     7e84 <fwp_drop0+0x1e4>
    7e49:	48 89 c1             	mov    %rax,%rcx
    7e4c:	48 39 10             	cmp    %rdx,(%rax)
    7e4f:	75 ef                	jne    7e40 <fwp_drop0+0x1a0>
    7e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e64:	0f 85 c4 fe ff ff    	jne    7d2e <fwp_drop0+0x8e>
    7e6a:	48 89 d7             	mov    %rdx,%rdi
    7e6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e72:	e8 39 d9 ff ff       	call   57b0 <fwp_rc_forget_slot>
    7e77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e7f:	e9 aa fe ff ff       	jmp    7d2e <fwp_drop0+0x8e>
    7e84:	48 8d 3d 1d 3b 00 00 	lea    0x3b1d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7e8b:	e8 a0 c5 ff ff       	call   4430 <fwp_trap>

0000000000007e90 <fwp_drop1>:
    7e90:	f3 0f 1e fa          	endbr64
    7e94:	48 8b 15 5d 0d 06 00 	mov    0x60d5d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7e9b:	48 89 f8             	mov    %rdi,%rax
    7e9e:	48 2b 05 2b 0d 06 00 	sub    0x60d2b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7ea5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ea9:	48 39 d0             	cmp    %rdx,%rax
    7eac:	0f 83 36 01 00 00    	jae    7fe8 <fwp_drop1+0x158>
    7eb2:	48 83 ec 18          	sub    $0x18,%rsp
    7eb6:	48 8d 35 63 f9 05 00 	lea    0x5f963(%rip),%rsi        # 67820 <fwp_heap>
    7ebd:	48 89 c2             	mov    %rax,%rdx
    7ec0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7ec7:	48 c1 ea 10          	shr    $0x10,%rdx
    7ecb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7ecf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7ed3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ed7:	48 85 d2             	test   %rdx,%rdx
    7eda:	74 42                	je     7f1e <fwp_drop1+0x8e>
    7edc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7ee0:	41 80 f8 02          	cmp    $0x2,%r8b
    7ee4:	74 42                	je     7f28 <fwp_drop1+0x98>
    7ee6:	41 80 f8 01          	cmp    $0x1,%r8b
    7eea:	75 32                	jne    7f1e <fwp_drop1+0x8e>
    7eec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7ef0:	0f b7 c0             	movzwl %ax,%eax
    7ef3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ef6:	49 0f af c0          	imul   %r8,%rax
    7efa:	48 c1 e8 20          	shr    $0x20,%rax
    7efe:	48 39 c8             	cmp    %rcx,%rax
    7f01:	73 1b                	jae    7f1e <fwp_drop1+0x8e>
    7f03:	48 01 c2             	add    %rax,%rdx
    7f06:	0f b6 02             	movzbl (%rdx),%eax
    7f09:	84 c0                	test   %al,%al
    7f0b:	74 11                	je     7f1e <fwp_drop1+0x8e>
    7f0d:	3c 01                	cmp    $0x1,%al
    7f0f:	74 27                	je     7f38 <fwp_drop1+0xa8>
    7f11:	3c ff                	cmp    $0xff,%al
    7f13:	0f 84 e7 00 00 00    	je     8000 <fwp_drop1+0x170>
    7f19:	83 e8 01             	sub    $0x1,%eax
    7f1c:	88 02                	mov    %al,(%rdx)
    7f1e:	48 83 c4 18          	add    $0x18,%rsp
    7f22:	c3                   	ret
    7f23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f28:	66 85 c0             	test   %ax,%ax
    7f2b:	74 d9                	je     7f06 <fwp_drop1+0x76>
    7f2d:	48 83 c4 18          	add    $0x18,%rsp
    7f31:	c3                   	ret
    7f32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f38:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7f3f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7f46:	48 89 f8             	mov    %rdi,%rax
    7f49:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7f4d:	48 29 c8             	sub    %rcx,%rax
    7f50:	48 c1 e2 10          	shl    $0x10,%rdx
    7f54:	48 39 d0             	cmp    %rdx,%rax
    7f57:	73 71                	jae    7fca <fwp_drop1+0x13a>
    7f59:	49 89 c2             	mov    %rax,%r10
    7f5c:	49 c1 ea 10          	shr    $0x10,%r10
    7f60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7f64:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7f68:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7f6c:	4d 85 d2             	test   %r10,%r10
    7f6f:	74 59                	je     7fca <fwp_drop1+0x13a>
    7f71:	45 0f b6 19          	movzbl (%r9),%r11d
    7f75:	41 80 fb 02          	cmp    $0x2,%r11b
    7f79:	74 75                	je     7ff0 <fwp_drop1+0x160>
    7f7b:	41 80 fb 01          	cmp    $0x1,%r11b
    7f7f:	75 49                	jne    7fca <fwp_drop1+0x13a>
    7f81:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7f85:	0f b7 c0             	movzwl %ax,%eax
    7f88:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7f8c:	49 0f af c3          	imul   %r11,%rax
    7f90:	48 c1 e8 20          	shr    $0x20,%rax
    7f94:	4c 39 c8             	cmp    %r9,%rax
    7f97:	73 31                	jae    7fca <fwp_drop1+0x13a>
    7f99:	49 01 c2             	add    %rax,%r10
    7f9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7fa0:	75 28                	jne    7fca <fwp_drop1+0x13a>
    7fa2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7fa7:	e8 44 da ff ff       	call   59f0 <fwp_mem_free>
    7fac:	48 8d 35 6d f8 05 00 	lea    0x5f86d(%rip),%rsi        # 67820 <fwp_heap>
    7fb3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7fb8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7fbf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7fc6:	48 c1 e2 10          	shl    $0x10,%rdx
    7fca:	4c 89 c0             	mov    %r8,%rax
    7fcd:	48 29 c8             	sub    %rcx,%rax
    7fd0:	48 39 d0             	cmp    %rdx,%rax
    7fd3:	0f 83 45 ff ff ff    	jae    7f1e <fwp_drop1+0x8e>
    7fd9:	4c 89 c7             	mov    %r8,%rdi
    7fdc:	e9 dc fe ff ff       	jmp    7ebd <fwp_drop1+0x2d>
    7fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7fe8:	c3                   	ret
    7fe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ff0:	66 85 c0             	test   %ax,%ax
    7ff3:	75 d5                	jne    7fca <fwp_drop1+0x13a>
    7ff5:	eb a5                	jmp    7f9c <fwp_drop1+0x10c>
    7ff7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ffe:	00 00 
    8000:	48 89 d0             	mov    %rdx,%rax
    8003:	48 c1 e8 11          	shr    $0x11,%rax
    8007:	48 31 d0             	xor    %rdx,%rax
    800a:	48 89 c1             	mov    %rax,%rcx
    800d:	48 c1 e9 09          	shr    $0x9,%rcx
    8011:	48 31 c8             	xor    %rcx,%rax
    8014:	0f b6 c8             	movzbl %al,%ecx
    8017:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    801e:	00 
    801f:	48 85 c0             	test   %rax,%rax
    8022:	75 25                	jne    8049 <fwp_drop1+0x1b9>
    8024:	eb 5e                	jmp    8084 <fwp_drop1+0x1f4>
    8026:	0f 1f 40 00          	nopl   0x0(%rax)
    802a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8031:	00 00 00 00 
    8035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    803c:	00 00 00 00 
    8040:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8044:	48 85 c0             	test   %rax,%rax
    8047:	74 3b                	je     8084 <fwp_drop1+0x1f4>
    8049:	48 89 c1             	mov    %rax,%rcx
    804c:	48 39 10             	cmp    %rdx,(%rax)
    804f:	75 ef                	jne    8040 <fwp_drop1+0x1b0>
    8051:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8055:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8059:	48 89 48 08          	mov    %rcx,0x8(%rax)
    805d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8064:	0f 85 b4 fe ff ff    	jne    7f1e <fwp_drop1+0x8e>
    806a:	48 89 d7             	mov    %rdx,%rdi
    806d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8072:	e8 39 d7 ff ff       	call   57b0 <fwp_rc_forget_slot>
    8077:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    807c:	c6 02 fe             	movb   $0xfe,(%rdx)
    807f:	e9 9a fe ff ff       	jmp    7f1e <fwp_drop1+0x8e>
    8084:	48 8d 3d 1d 39 00 00 	lea    0x391d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    808b:	e8 a0 c3 ff ff       	call   4430 <fwp_trap>

0000000000008090 <fwp_drop10>:
    8090:	48 8b 0d 61 0b 06 00 	mov    0x60b61(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    8097:	48 89 f8             	mov    %rdi,%rax
    809a:	48 2b 05 2f 0b 06 00 	sub    0x60b2f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    80a1:	48 c1 e1 10          	shl    $0x10,%rcx
    80a5:	48 39 c8             	cmp    %rcx,%rax
    80a8:	0f 83 c2 01 00 00    	jae    8270 <fwp_drop10+0x1e0>
    80ae:	48 83 ec 18          	sub    $0x18,%rsp
    80b2:	48 89 fa             	mov    %rdi,%rdx
    80b5:	48 8d 35 64 f7 05 00 	lea    0x5f764(%rip),%rsi        # 67820 <fwp_heap>
    80bc:	48 89 c1             	mov    %rax,%rcx
    80bf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    80c6:	48 c1 e9 10          	shr    $0x10,%rcx
    80ca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    80ce:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    80d2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    80d6:	48 85 c9             	test   %rcx,%rcx
    80d9:	74 46                	je     8121 <fwp_drop10+0x91>
    80db:	44 0f b6 0f          	movzbl (%rdi),%r9d
    80df:	41 80 f9 02          	cmp    $0x2,%r9b
    80e3:	0f 84 d7 00 00 00    	je     81c0 <fwp_drop10+0x130>
    80e9:	41 80 f9 01          	cmp    $0x1,%r9b
    80ed:	75 32                	jne    8121 <fwp_drop10+0x91>
    80ef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    80f3:	0f b7 c0             	movzwl %ax,%eax
    80f6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    80f9:	49 0f af c1          	imul   %r9,%rax
    80fd:	48 c1 e8 20          	shr    $0x20,%rax
    8101:	48 39 f8             	cmp    %rdi,%rax
    8104:	73 1b                	jae    8121 <fwp_drop10+0x91>
    8106:	48 01 c1             	add    %rax,%rcx
    8109:	0f b6 01             	movzbl (%rcx),%eax
    810c:	84 c0                	test   %al,%al
    810e:	74 11                	je     8121 <fwp_drop10+0x91>
    8110:	3c 01                	cmp    $0x1,%al
    8112:	74 1c                	je     8130 <fwp_drop10+0xa0>
    8114:	3c ff                	cmp    $0xff,%al
    8116:	0f 84 5c 01 00 00    	je     8278 <fwp_drop10+0x1e8>
    811c:	83 e8 01             	sub    $0x1,%eax
    811f:	88 01                	mov    %al,(%rcx)
    8121:	48 83 c4 18          	add    $0x18,%rsp
    8125:	c3                   	ret
    8126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    812d:	00 00 00 
    8130:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8137:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    813e:	48 89 d0             	mov    %rdx,%rax
    8141:	49 89 d1             	mov    %rdx,%r9
    8144:	48 c1 e1 10          	shl    $0x10,%rcx
    8148:	48 29 f8             	sub    %rdi,%rax
    814b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    814f:	78 7f                	js     81d0 <fwp_drop10+0x140>
    8151:	48 39 c8             	cmp    %rcx,%rax
    8154:	73 cb                	jae    8121 <fwp_drop10+0x91>
    8156:	48 89 c1             	mov    %rax,%rcx
    8159:	48 c1 e9 10          	shr    $0x10,%rcx
    815d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8161:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8165:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8169:	48 85 f6             	test   %rsi,%rsi
    816c:	74 b3                	je     8121 <fwp_drop10+0x91>
    816e:	0f b6 39             	movzbl (%rcx),%edi
    8171:	40 80 ff 02          	cmp    $0x2,%dil
    8175:	74 39                	je     81b0 <fwp_drop10+0x120>
    8177:	40 80 ff 01          	cmp    $0x1,%dil
    817b:	75 a4                	jne    8121 <fwp_drop10+0x91>
    817d:	8b 79 18             	mov    0x18(%rcx),%edi
    8180:	0f b7 c0             	movzwl %ax,%eax
    8183:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8186:	48 0f af c7          	imul   %rdi,%rax
    818a:	48 c1 e8 20          	shr    $0x20,%rax
    818e:	48 39 c8             	cmp    %rcx,%rax
    8191:	73 8e                	jae    8121 <fwp_drop10+0x91>
    8193:	48 01 c6             	add    %rax,%rsi
    8196:	80 3e 01             	cmpb   $0x1,(%rsi)
    8199:	75 86                	jne    8121 <fwp_drop10+0x91>
    819b:	48 89 d7             	mov    %rdx,%rdi
    819e:	48 83 c4 18          	add    $0x18,%rsp
    81a2:	e9 49 d8 ff ff       	jmp    59f0 <fwp_mem_free>
    81a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ae:	00 00 
    81b0:	66 85 c0             	test   %ax,%ax
    81b3:	74 e1                	je     8196 <fwp_drop10+0x106>
    81b5:	48 83 c4 18          	add    $0x18,%rsp
    81b9:	c3                   	ret
    81ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81c0:	66 85 c0             	test   %ax,%ax
    81c3:	0f 84 40 ff ff ff    	je     8109 <fwp_drop10+0x79>
    81c9:	48 83 c4 18          	add    $0x18,%rsp
    81cd:	c3                   	ret
    81ce:	66 90                	xchg   %ax,%ax
    81d0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    81d4:	48 39 c8             	cmp    %rcx,%rax
    81d7:	73 74                	jae    824d <fwp_drop10+0x1bd>
    81d9:	49 89 c2             	mov    %rax,%r10
    81dc:	49 c1 ea 10          	shr    $0x10,%r10
    81e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    81e4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    81e8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    81ec:	4d 85 d2             	test   %r10,%r10
    81ef:	74 5c                	je     824d <fwp_drop10+0x1bd>
    81f1:	45 0f b6 18          	movzbl (%r8),%r11d
    81f5:	41 80 fb 02          	cmp    $0x2,%r11b
    81f9:	74 6d                	je     8268 <fwp_drop10+0x1d8>
    81fb:	41 80 fb 01          	cmp    $0x1,%r11b
    81ff:	75 4c                	jne    824d <fwp_drop10+0x1bd>
    8201:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8205:	0f b7 c0             	movzwl %ax,%eax
    8208:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    820c:	49 0f af c3          	imul   %r11,%rax
    8210:	48 c1 e8 20          	shr    $0x20,%rax
    8214:	4c 39 c0             	cmp    %r8,%rax
    8217:	73 34                	jae    824d <fwp_drop10+0x1bd>
    8219:	49 01 c2             	add    %rax,%r10
    821c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8220:	75 2b                	jne    824d <fwp_drop10+0x1bd>
    8222:	4c 89 cf             	mov    %r9,%rdi
    8225:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    822a:	e8 c1 d7 ff ff       	call   59f0 <fwp_mem_free>
    822f:	48 8d 35 ea f5 05 00 	lea    0x5f5ea(%rip),%rsi        # 67820 <fwp_heap>
    8236:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    823b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8242:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8249:	48 c1 e1 10          	shl    $0x10,%rcx
    824d:	48 89 d0             	mov    %rdx,%rax
    8250:	48 29 f8             	sub    %rdi,%rax
    8253:	48 39 c8             	cmp    %rcx,%rax
    8256:	0f 82 60 fe ff ff    	jb     80bc <fwp_drop10+0x2c>
    825c:	e9 c0 fe ff ff       	jmp    8121 <fwp_drop10+0x91>
    8261:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8268:	66 85 c0             	test   %ax,%ax
    826b:	75 e0                	jne    824d <fwp_drop10+0x1bd>
    826d:	eb ad                	jmp    821c <fwp_drop10+0x18c>
    826f:	90                   	nop
    8270:	c3                   	ret
    8271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8278:	48 89 c8             	mov    %rcx,%rax
    827b:	48 c1 e8 11          	shr    $0x11,%rax
    827f:	48 31 c8             	xor    %rcx,%rax
    8282:	48 89 c2             	mov    %rax,%rdx
    8285:	48 c1 ea 09          	shr    $0x9,%rdx
    8289:	48 31 d0             	xor    %rdx,%rax
    828c:	0f b6 d0             	movzbl %al,%edx
    828f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8296:	00 
    8297:	48 85 c0             	test   %rax,%rax
    829a:	75 0d                	jne    82a9 <fwp_drop10+0x219>
    829c:	eb 46                	jmp    82e4 <fwp_drop10+0x254>
    829e:	66 90                	xchg   %ax,%ax
    82a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    82a4:	48 85 c0             	test   %rax,%rax
    82a7:	74 3b                	je     82e4 <fwp_drop10+0x254>
    82a9:	48 89 c2             	mov    %rax,%rdx
    82ac:	48 39 08             	cmp    %rcx,(%rax)
    82af:	75 ef                	jne    82a0 <fwp_drop10+0x210>
    82b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    82b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    82b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    82bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    82c4:	0f 85 57 fe ff ff    	jne    8121 <fwp_drop10+0x91>
    82ca:	48 89 cf             	mov    %rcx,%rdi
    82cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    82d2:	e8 d9 d4 ff ff       	call   57b0 <fwp_rc_forget_slot>
    82d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    82dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    82df:	e9 3d fe ff ff       	jmp    8121 <fwp_drop10+0x91>
    82e4:	48 8d 3d bd 36 00 00 	lea    0x36bd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    82eb:	e8 40 c1 ff ff       	call   4430 <fwp_trap>

00000000000082f0 <f37>:
    82f0:	41 57                	push   %r15
    82f2:	41 56                	push   %r14
    82f4:	41 55                	push   %r13
    82f6:	41 54                	push   %r12
    82f8:	55                   	push   %rbp
    82f9:	53                   	push   %rbx
    82fa:	48 83 ec 38          	sub    $0x38,%rsp
    82fe:	48 8b 15 f3 08 06 00 	mov    0x608f3(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    8305:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    830a:	48 c1 e2 10          	shl    $0x10,%rdx
    830e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8315:	00 00 
    8317:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    831c:	48 8b 0d ad 08 06 00 	mov    0x608ad(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    8323:	48 85 ff             	test   %rdi,%rdi
    8326:	0f 84 1e 03 00 00    	je     864a <f37+0x35a>
    832c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8331:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8335:	4c 89 e8             	mov    %r13,%rax
    8338:	48 29 c8             	sub    %rcx,%rax
    833b:	48 39 d0             	cmp    %rdx,%rax
    833e:	0f 83 ec 02 00 00    	jae    8630 <f37+0x340>
    8344:	48 89 c2             	mov    %rax,%rdx
    8347:	48 c1 ea 10          	shr    $0x10,%rdx
    834b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    834f:	48 8b 15 c2 08 06 00 	mov    0x608c2(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8356:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    835a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    835e:	48 85 ff             	test   %rdi,%rdi
    8361:	0f 84 c9 02 00 00    	je     8630 <f37+0x340>
    8367:	0f b6 0a             	movzbl (%rdx),%ecx
    836a:	80 f9 02             	cmp    $0x2,%cl
    836d:	0f 84 4d 02 00 00    	je     85c0 <f37+0x2d0>
    8373:	80 f9 01             	cmp    $0x1,%cl
    8376:	75 24                	jne    839c <f37+0xac>
    8378:	8b 4a 18             	mov    0x18(%rdx),%ecx
    837b:	0f b7 c0             	movzwl %ax,%eax
    837e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8381:	48 0f af c1          	imul   %rcx,%rax
    8385:	48 c1 e8 20          	shr    $0x20,%rax
    8389:	48 39 d0             	cmp    %rdx,%rax
    838c:	73 0e                	jae    839c <f37+0xac>
    838e:	48 01 c7             	add    %rax,%rdi
    8391:	0f b6 07             	movzbl (%rdi),%eax
    8394:	84 c0                	test   %al,%al
    8396:	0f 85 44 02 00 00    	jne    85e0 <f37+0x2f0>
    839c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    83a1:	48 8b 40 10          	mov    0x10(%rax),%rax
    83a5:	ba 01 00 00 00       	mov    $0x1,%edx
    83aa:	48 85 c0             	test   %rax,%rax
    83ad:	74 0e                	je     83bd <f37+0xcd>
    83af:	90                   	nop
    83b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    83b4:	48 83 c2 01          	add    $0x1,%rdx
    83b8:	48 85 c0             	test   %rax,%rax
    83bb:	75 f3                	jne    83b0 <f37+0xc0>
    83bd:	4d 85 ed             	test   %r13,%r13
    83c0:	0f 84 9a 02 00 00    	je     8660 <f37+0x370>
    83c6:	4c 89 e8             	mov    %r13,%rax
    83c9:	31 db                	xor    %ebx,%ebx
    83cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    83d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    83d4:	48 83 c3 01          	add    $0x1,%rbx
    83d8:	48 85 c0             	test   %rax,%rax
    83db:	75 f3                	jne    83d0 <f37+0xe0>
    83dd:	48 39 d3             	cmp    %rdx,%rbx
    83e0:	48 0f 47 da          	cmova  %rdx,%rbx
    83e4:	48 89 d8             	mov    %rbx,%rax
    83e7:	48 c1 e8 3c          	shr    $0x3c,%rax
    83eb:	0f 85 7d 03 00 00    	jne    876e <f37+0x47e>
    83f1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    83f5:	be 02 00 00 00       	mov    $0x2,%esi
    83fa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8401:	00 
    8402:	e8 e9 da ff ff       	call   5ef0 <fwp_heap_alloc>
    8407:	48 89 28             	mov    %rbp,(%rax)
    840a:	48 8b 15 e7 07 06 00 	mov    0x607e7(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    8411:	49 89 c4             	mov    %rax,%r12
    8414:	48 2b 05 b5 07 06 00 	sub    0x607b5(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    841b:	48 c1 e2 10          	shl    $0x10,%rdx
    841f:	48 39 d0             	cmp    %rdx,%rax
    8422:	73 57                	jae    847b <f37+0x18b>
    8424:	48 89 c2             	mov    %rax,%rdx
    8427:	48 c1 ea 10          	shr    $0x10,%rdx
    842b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    842f:	48 8b 15 e2 07 06 00 	mov    0x607e2(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8436:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    843a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    843e:	48 85 ed             	test   %rbp,%rbp
    8441:	74 38                	je     847b <f37+0x18b>
    8443:	0f b6 0a             	movzbl (%rdx),%ecx
    8446:	80 f9 02             	cmp    $0x2,%cl
    8449:	0f 84 d1 01 00 00    	je     8620 <f37+0x330>
    844f:	80 f9 01             	cmp    $0x1,%cl
    8452:	75 27                	jne    847b <f37+0x18b>
    8454:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8457:	0f b7 c0             	movzwl %ax,%eax
    845a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    845d:	48 0f af c1          	imul   %rcx,%rax
    8461:	48 c1 e8 20          	shr    $0x20,%rax
    8465:	48 39 d0             	cmp    %rdx,%rax
    8468:	73 11                	jae    847b <f37+0x18b>
    846a:	48 01 c5             	add    %rax,%rbp
    846d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8471:	0f 84 57 02 00 00    	je     86ce <f37+0x3de>
    8477:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    847b:	48 85 db             	test   %rbx,%rbx
    847e:	74 5d                	je     84dd <f37+0x1ed>
    8480:	48 c1 e3 04          	shl    $0x4,%rbx
    8484:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8489:	4c 89 e5             	mov    %r12,%rbp
    848c:	4d 89 ef             	mov    %r13,%r15
    848f:	4c 01 e3             	add    %r12,%rbx
    8492:	0f 1f 00             	nopl   (%rax)
    8495:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    849c:	00 00 00 00 
    84a0:	49 8b 46 08          	mov    0x8(%r14),%rax
    84a4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    84a8:	48 83 c5 10          	add    $0x10,%rbp
    84ac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    84b1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    84b5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    84b9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    84be:	e8 0d e3 ff ff       	call   67d0 <w120>
    84c3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    84c8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    84cc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    84d0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    84d4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    84d8:	48 39 dd             	cmp    %rbx,%rbp
    84db:	75 c3                	jne    84a0 <f37+0x1b0>
    84dd:	4c 89 ef             	mov    %r13,%rdi
    84e0:	e8 8b ed ff ff       	call   7270 <fwp_drop4>
    84e5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    84ea:	e8 81 ed ff ff       	call   7270 <fwp_drop4>
    84ef:	4c 89 e7             	mov    %r12,%rdi
    84f2:	e8 99 e4 ff ff       	call   6990 <w176.constprop.0>
    84f7:	4c 89 e7             	mov    %r12,%rdi
    84fa:	48 89 c3             	mov    %rax,%rbx
    84fd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8503:	e8 88 fb ff ff       	call   8090 <fwp_drop10>
    8508:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    850e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8513:	31 ff                	xor    %edi,%edi
    8515:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    851a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    851e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8523:	e8 b8 db ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    8528:	48 8b 15 c9 06 06 00 	mov    0x606c9(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    852f:	48 89 c5             	mov    %rax,%rbp
    8532:	48 2b 05 97 06 06 00 	sub    0x60697(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8539:	48 c1 e2 10          	shl    $0x10,%rdx
    853d:	48 39 d0             	cmp    %rdx,%rax
    8540:	73 55                	jae    8597 <f37+0x2a7>
    8542:	48 89 c2             	mov    %rax,%rdx
    8545:	48 c1 ea 10          	shr    $0x10,%rdx
    8549:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    854d:	48 8b 15 c4 06 06 00 	mov    0x606c4(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8554:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8558:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    855c:	48 85 db             	test   %rbx,%rbx
    855f:	74 36                	je     8597 <f37+0x2a7>
    8561:	0f b6 0a             	movzbl (%rdx),%ecx
    8564:	80 f9 02             	cmp    $0x2,%cl
    8567:	0f 84 a3 00 00 00    	je     8610 <f37+0x320>
    856d:	80 f9 01             	cmp    $0x1,%cl
    8570:	75 25                	jne    8597 <f37+0x2a7>
    8572:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8575:	0f b7 c0             	movzwl %ax,%eax
    8578:	8b 52 1c             	mov    0x1c(%rdx),%edx
    857b:	48 0f af c1          	imul   %rcx,%rax
    857f:	48 c1 e8 20          	shr    $0x20,%rax
    8583:	48 39 d0             	cmp    %rdx,%rax
    8586:	73 0f                	jae    8597 <f37+0x2a7>
    8588:	48 01 c3             	add    %rax,%rbx
    858b:	80 3b ff             	cmpb   $0xff,(%rbx)
    858e:	0f 84 2d 01 00 00    	je     86c1 <f37+0x3d1>
    8594:	c6 03 01             	movb   $0x1,(%rbx)
    8597:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    859c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85a3:	00 00 
    85a5:	0f 85 cf 01 00 00    	jne    877a <f37+0x48a>
    85ab:	48 83 c4 38          	add    $0x38,%rsp
    85af:	48 89 e8             	mov    %rbp,%rax
    85b2:	5b                   	pop    %rbx
    85b3:	5d                   	pop    %rbp
    85b4:	41 5c                	pop    %r12
    85b6:	41 5d                	pop    %r13
    85b8:	41 5e                	pop    %r14
    85ba:	41 5f                	pop    %r15
    85bc:	c3                   	ret
    85bd:	0f 1f 00             	nopl   (%rax)
    85c0:	66 85 c0             	test   %ax,%ax
    85c3:	0f 85 d3 fd ff ff    	jne    839c <f37+0xac>
    85c9:	0f b6 07             	movzbl (%rdi),%eax
    85cc:	84 c0                	test   %al,%al
    85ce:	0f 84 c8 fd ff ff    	je     839c <f37+0xac>
    85d4:	90                   	nop
    85d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85dc:	00 00 00 00 
    85e0:	8b 15 02 0f 06 00    	mov    0x60f02(%rip),%edx        # 694e8 <iteration_active>
    85e6:	85 d2                	test   %edx,%edx
    85e8:	75 56                	jne    8640 <f37+0x350>
    85ea:	3c fd                	cmp    $0xfd,%al
    85ec:	0f 87 4b 01 00 00    	ja     873d <f37+0x44d>
    85f2:	83 c0 01             	add    $0x1,%eax
    85f5:	88 07                	mov    %al,(%rdi)
    85f7:	31 d2                	xor    %edx,%edx
    85f9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    85ff:	0f 85 97 fd ff ff    	jne    839c <f37+0xac>
    8605:	e9 b3 fd ff ff       	jmp    83bd <f37+0xcd>
    860a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8610:	66 85 c0             	test   %ax,%ax
    8613:	0f 85 7e ff ff ff    	jne    8597 <f37+0x2a7>
    8619:	e9 6d ff ff ff       	jmp    858b <f37+0x29b>
    861e:	66 90                	xchg   %ax,%ax
    8620:	66 85 c0             	test   %ax,%ax
    8623:	0f 85 52 fe ff ff    	jne    847b <f37+0x18b>
    8629:	e9 3f fe ff ff       	jmp    846d <f37+0x17d>
    862e:	66 90                	xchg   %ax,%ax
    8630:	4c 89 e8             	mov    %r13,%rax
    8633:	e9 6d fd ff ff       	jmp    83a5 <f37+0xb5>
    8638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    863f:	00 
    8640:	48 83 05 88 0e 06 00 	addq   $0x1,0x60e88(%rip)        # 694d0 <iteration_retains>
    8647:	01 
    8648:	eb a0                	jmp    85ea <f37+0x2fa>
    864a:	48 f7 d9             	neg    %rcx
    864d:	48 39 d1             	cmp    %rdx,%rcx
    8650:	0f 82 85 00 00 00    	jb     86db <f37+0x3eb>
    8656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    865d:	00 00 00 
    8660:	be 02 00 00 00       	mov    $0x2,%esi
    8665:	bf 08 00 00 00       	mov    $0x8,%edi
    866a:	e8 81 d8 ff ff       	call   5ef0 <fwp_heap_alloc>
    866f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8676:	48 8b 15 7b 05 06 00 	mov    0x6057b(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    867d:	49 89 c4             	mov    %rax,%r12
    8680:	48 2b 05 49 05 06 00 	sub    0x60549(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8687:	48 c1 e2 10          	shl    $0x10,%rdx
    868b:	48 39 d0             	cmp    %rdx,%rax
    868e:	0f 83 b3 00 00 00    	jae    8747 <f37+0x457>
    8694:	48 89 c2             	mov    %rax,%rdx
    8697:	48 c1 ea 10          	shr    $0x10,%rdx
    869b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    869f:	48 8b 15 72 05 06 00 	mov    0x60572(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    86a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86aa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    86ae:	48 85 ed             	test   %rbp,%rbp
    86b1:	0f 84 90 00 00 00    	je     8747 <f37+0x457>
    86b7:	31 db                	xor    %ebx,%ebx
    86b9:	45 31 ed             	xor    %r13d,%r13d
    86bc:	e9 82 fd ff ff       	jmp    8443 <f37+0x153>
    86c1:	48 89 df             	mov    %rbx,%rdi
    86c4:	e8 e7 d0 ff ff       	call   57b0 <fwp_rc_forget_slot>
    86c9:	e9 c6 fe ff ff       	jmp    8594 <f37+0x2a4>
    86ce:	48 89 ef             	mov    %rbp,%rdi
    86d1:	e8 da d0 ff ff       	call   57b0 <fwp_rc_forget_slot>
    86d6:	e9 9c fd ff ff       	jmp    8477 <f37+0x187>
    86db:	48 89 c8             	mov    %rcx,%rax
    86de:	48 c1 e8 10          	shr    $0x10,%rax
    86e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    86e6:	48 8b 05 2b 05 06 00 	mov    0x6052b(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    86ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    86f1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    86f5:	48 85 ff             	test   %rdi,%rdi
    86f8:	0f 84 62 ff ff ff    	je     8660 <f37+0x370>
    86fe:	0f b6 02             	movzbl (%rdx),%eax
    8701:	3c 02                	cmp    $0x2,%al
    8703:	74 4a                	je     874f <f37+0x45f>
    8705:	3c 01                	cmp    $0x1,%al
    8707:	0f 85 53 ff ff ff    	jne    8660 <f37+0x370>
    870d:	0f b7 c1             	movzwl %cx,%eax
    8710:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8713:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8716:	48 0f af c1          	imul   %rcx,%rax
    871a:	48 c1 e8 20          	shr    $0x20,%rax
    871e:	48 39 d0             	cmp    %rdx,%rax
    8721:	0f 83 39 ff ff ff    	jae    8660 <f37+0x370>
    8727:	48 01 c7             	add    %rax,%rdi
    872a:	0f b6 07             	movzbl (%rdi),%eax
    872d:	84 c0                	test   %al,%al
    872f:	0f 84 2b ff ff ff    	je     8660 <f37+0x370>
    8735:	45 31 ed             	xor    %r13d,%r13d
    8738:	e9 a3 fe ff ff       	jmp    85e0 <f37+0x2f0>
    873d:	e8 4e cf ff ff       	call   5690 <fwp_rc_wide_dup>
    8742:	e9 b0 fe ff ff       	jmp    85f7 <f37+0x307>
    8747:	45 31 ed             	xor    %r13d,%r13d
    874a:	e9 8e fd ff ff       	jmp    84dd <f37+0x1ed>
    874f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8755:	49 89 cd             	mov    %rcx,%r13
    8758:	0f 85 02 ff ff ff    	jne    8660 <f37+0x370>
    875e:	0f b6 07             	movzbl (%rdi),%eax
    8761:	84 c0                	test   %al,%al
    8763:	0f 85 77 fe ff ff    	jne    85e0 <f37+0x2f0>
    8769:	e9 f2 fe ff ff       	jmp    8660 <f37+0x370>
    876e:	48 8d 3d 76 2a 00 00 	lea    0x2a76(%rip),%rdi        # b1eb <_IO_stdin_used+0x1eb>
    8775:	e8 b6 bc ff ff       	call   4430 <fwp_trap>
    877a:	e8 d1 ac ff ff       	call   3450 <__stack_chk_fail@plt>
    877f:	90                   	nop

0000000000008780 <fwp_owned_entry37>:
    8780:	f3 0f 1e fa          	endbr64
    8784:	48 8b 3f             	mov    (%rdi),%rdi
    8787:	e9 64 fb ff ff       	jmp    82f0 <f37>
    878c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008790 <e37>:
    8790:	f3 0f 1e fa          	endbr64
    8794:	53                   	push   %rbx
    8795:	48 8b 1f             	mov    (%rdi),%rbx
    8798:	48 89 df             	mov    %rbx,%rdi
    879b:	e8 70 e2 ff ff       	call   6a10 <fwp_rc_share>
    87a0:	48 89 df             	mov    %rbx,%rdi
    87a3:	e8 48 fb ff ff       	call   82f0 <f37>
    87a8:	48 89 c3             	mov    %rax,%rbx
    87ab:	48 89 c7             	mov    %rax,%rdi
    87ae:	e8 5d e2 ff ff       	call   6a10 <fwp_rc_share>
    87b3:	48 89 d8             	mov    %rbx,%rax
    87b6:	5b                   	pop    %rbx
    87b7:	c3                   	ret
    87b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87bf:	00 

00000000000087c0 <fwp_write>:
    87c0:	41 57                	push   %r15
    87c2:	41 56                	push   %r14
    87c4:	41 55                	push   %r13
    87c6:	41 54                	push   %r12
    87c8:	55                   	push   %rbp
    87c9:	53                   	push   %rbx
    87ca:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    87d1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    87d8:	00 00 
    87da:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    87e1:	00 
    87e2:	49 89 d4             	mov    %rdx,%r12
    87e5:	8b 12                	mov    (%rdx),%edx
    87e7:	83 fa 19             	cmp    $0x19,%edx
    87ea:	77 6a                	ja     8856 <fwp_write+0x96>
    87ec:	48 89 f5             	mov    %rsi,%rbp
    87ef:	89 d0                	mov    %edx,%eax
    87f1:	89 ce                	mov    %ecx,%esi
    87f3:	48 89 fb             	mov    %rdi,%rbx
    87f6:	48 8d 0d 03 34 00 00 	lea    0x3403(%rip),%rcx        # bc00 <_IO_stdin_used+0xc00>
    87fd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8801:	48 01 c8             	add    %rcx,%rax
    8804:	3e ff e0             	notrack jmp *%rax
    8807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    880e:	00 00 
    8810:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8814:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8818:	48 89 ca             	mov    %rcx,%rdx
    881b:	48 85 c9             	test   %rcx,%rcx
    881e:	0f 88 9c 0c 00 00    	js     94c0 <fwp_write+0xd00>
    8824:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    882b:	00 
    882c:	48 89 c6             	mov    %rax,%rsi
    882f:	4c 89 e7             	mov    %r12,%rdi
    8832:	e8 e9 b1 ff ff       	call   3a20 <fwp_fmt_u128>
    8837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    883e:	00 00 
    8840:	4c 89 e7             	mov    %r12,%rdi
    8843:	e8 f8 ab ff ff       	call   3440 <strlen@plt>
    8848:	4c 89 e6             	mov    %r12,%rsi
    884b:	48 89 df             	mov    %rbx,%rdi
    884e:	48 89 c2             	mov    %rax,%rdx
    8851:	e8 7a b8 ff ff       	call   40d0 <buf_put>
    8856:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    885d:	00 
    885e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8865:	00 00 
    8867:	0f 85 28 04 00 00    	jne    8c95 <fwp_write+0x4d5>
    886d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8874:	5b                   	pop    %rbx
    8875:	5d                   	pop    %rbp
    8876:	41 5c                	pop    %r12
    8878:	41 5d                	pop    %r13
    887a:	41 5e                	pop    %r14
    887c:	41 5f                	pop    %r15
    887e:	c3                   	ret
    887f:	90                   	nop
    8880:	49 89 e9             	mov    %rbp,%r9
    8883:	4c 8d 05 8b 29 00 00 	lea    0x298b(%rip),%r8        # b215 <_IO_stdin_used+0x215>
    888a:	b9 00 02 00 00       	mov    $0x200,%ecx
    888f:	ba 02 00 00 00       	mov    $0x2,%edx
    8894:	be 00 02 00 00       	mov    $0x200,%esi
    8899:	31 c0                	xor    %eax,%eax
    889b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88a2:	00 
    88a3:	e8 f8 aa ff ff       	call   33a0 <__snprintf_chk@plt>
    88a8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    88af:	00 
    88b0:	e8 8b ab ff ff       	call   3440 <strlen@plt>
    88b5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    88bc:	00 
    88bd:	48 89 df             	mov    %rbx,%rdi
    88c0:	48 89 c2             	mov    %rax,%rdx
    88c3:	e8 08 b8 ff ff       	call   40d0 <buf_put>
    88c8:	eb 8c                	jmp    8856 <fwp_write+0x96>
    88ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88d0:	49 89 e9             	mov    %rbp,%r9
    88d3:	4c 8d 05 36 29 00 00 	lea    0x2936(%rip),%r8        # b210 <_IO_stdin_used+0x210>
    88da:	eb ae                	jmp    888a <fwp_write+0xca>
    88dc:	0f 1f 40 00          	nopl   0x0(%rax)
    88e0:	83 fa 13             	cmp    $0x13,%edx
    88e3:	48 8d 05 1c 29 00 00 	lea    0x291c(%rip),%rax        # b206 <_IO_stdin_used+0x206>
    88ea:	48 8d 35 1a 29 00 00 	lea    0x291a(%rip),%rsi        # b20b <_IO_stdin_used+0x20b>
    88f1:	ba 04 00 00 00       	mov    $0x4,%edx
    88f6:	48 0f 44 f0          	cmove  %rax,%rsi
    88fa:	45 31 ed             	xor    %r13d,%r13d
    88fd:	e8 ce b7 ff ff       	call   40d0 <buf_put>
    8902:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8907:	0f 84 a3 08 00 00    	je     91b0 <fwp_write+0x9f0>
    890d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8912:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8917:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    891c:	48 89 df             	mov    %rbx,%rdi
    891f:	49 0f 44 c5          	cmove  %r13,%rax
    8923:	31 c9                	xor    %ecx,%ecx
    8925:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    892a:	e8 91 fe ff ff       	call   87c0 <fwp_write>
    892f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8934:	0f 84 6e 09 00 00    	je     92a8 <fwp_write+0xae8>
    893a:	49 83 c5 01          	add    $0x1,%r13
    893e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8942:	0f 83 68 08 00 00    	jae    91b0 <fwp_write+0x9f0>
    8948:	ba 02 00 00 00       	mov    $0x2,%edx
    894d:	48 8d 35 01 29 00 00 	lea    0x2901(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8954:	48 89 df             	mov    %rbx,%rdi
    8957:	e8 74 b7 ff ff       	call   40d0 <buf_put>
    895c:	eb af                	jmp    890d <fwp_write+0x14d>
    895e:	66 90                	xchg   %ax,%ax
    8960:	ba 06 00 00 00       	mov    $0x6,%edx
    8965:	48 8d 35 c2 28 00 00 	lea    0x28c2(%rip),%rsi        # b22e <_IO_stdin_used+0x22e>
    896c:	48 83 c5 10          	add    $0x10,%rbp
    8970:	e8 5b b7 ff ff       	call   40d0 <buf_put>
    8975:	48 89 ef             	mov    %rbp,%rdi
    8978:	e8 c3 aa ff ff       	call   3440 <strlen@plt>
    897d:	48 89 ee             	mov    %rbp,%rsi
    8980:	48 89 df             	mov    %rbx,%rdi
    8983:	48 89 c2             	mov    %rax,%rdx
    8986:	e8 45 b7 ff ff       	call   40d0 <buf_put>
    898b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8990:	ba 01 00 00 00       	mov    $0x1,%edx
    8995:	48 89 df             	mov    %rbx,%rdi
    8998:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    899d:	e8 2e b7 ff ff       	call   40d0 <buf_put>
    89a2:	e9 af fe ff ff       	jmp    8856 <fwp_write+0x96>
    89a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89ae:	00 00 
    89b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89b7:	00 
    89b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89bf:	00 00 
    89c1:	0f 85 ce 02 00 00    	jne    8c95 <fwp_write+0x4d5>
    89c7:	ba 0a 00 00 00       	mov    $0xa,%edx
    89cc:	48 8d 35 47 28 00 00 	lea    0x2847(%rip),%rsi        # b21a <_IO_stdin_used+0x21a>
    89d3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    89da:	48 89 df             	mov    %rbx,%rdi
    89dd:	5b                   	pop    %rbx
    89de:	5d                   	pop    %rbp
    89df:	41 5c                	pop    %r12
    89e1:	41 5d                	pop    %r13
    89e3:	41 5e                	pop    %r14
    89e5:	41 5f                	pop    %r15
    89e7:	e9 e4 b6 ff ff       	jmp    40d0 <buf_put>
    89ec:	0f 1f 40 00          	nopl   0x0(%rax)
    89f0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    89f5:	4d 85 ed             	test   %r13,%r13
    89f8:	0f 84 02 0c 00 00    	je     9600 <fwp_write+0xe40>
    89fe:	48 8d 35 5d 28 00 00 	lea    0x285d(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    8a05:	4c 89 ef             	mov    %r13,%rdi
    8a08:	e8 13 ab ff ff       	call   3520 <strcmp@plt>
    8a0d:	41 89 c1             	mov    %eax,%r9d
    8a10:	85 c0                	test   %eax,%eax
    8a12:	0f 84 6c 0c 00 00    	je     9684 <fwp_write+0xec4>
    8a18:	4c 89 ef             	mov    %r13,%rdi
    8a1b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a20:	e8 1b aa ff ff       	call   3440 <strlen@plt>
    8a25:	4c 89 ee             	mov    %r13,%rsi
    8a28:	48 89 df             	mov    %rbx,%rdi
    8a2b:	48 89 c2             	mov    %rax,%rdx
    8a2e:	e8 9d b6 ff ff       	call   40d0 <buf_put>
    8a33:	ba 01 00 00 00       	mov    $0x1,%edx
    8a38:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a3d:	48 89 df             	mov    %rbx,%rdi
    8a40:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a45:	e8 86 b6 ff ff       	call   40d0 <buf_put>
    8a4a:	ba 01 00 00 00       	mov    $0x1,%edx
    8a4f:	4c 89 fe             	mov    %r15,%rsi
    8a52:	48 89 df             	mov    %rbx,%rdi
    8a55:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8a5a:	e8 71 b6 ff ff       	call   40d0 <buf_put>
    8a5f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8a64:	45 31 f6             	xor    %r14d,%r14d
    8a67:	85 d2                	test   %edx,%edx
    8a69:	0f 8e 81 0a 00 00    	jle    94f0 <fwp_write+0xd30>
    8a6f:	45 31 ed             	xor    %r13d,%r13d
    8a72:	4d 85 ed             	test   %r13,%r13
    8a75:	0f 85 75 07 00 00    	jne    91f0 <fwp_write+0xa30>
    8a7b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8a82:	00 
    8a83:	45 85 f6             	test   %r14d,%r14d
    8a86:	0f 84 84 07 00 00    	je     9210 <fwp_write+0xa50>
    8a8c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8a91:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8a96:	48 89 df             	mov    %rbx,%rdi
    8a99:	49 83 c5 01          	add    $0x1,%r13
    8a9d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8aa1:	31 c9                	xor    %ecx,%ecx
    8aa3:	e8 18 fd ff ff       	call   87c0 <fwp_write>
    8aa8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8aad:	7f c3                	jg     8a72 <fwp_write+0x2b2>
    8aaf:	45 85 f6             	test   %r14d,%r14d
    8ab2:	0f 84 38 0a 00 00    	je     94f0 <fwp_write+0xd30>
    8ab8:	b8 29 00 00 00       	mov    $0x29,%eax
    8abd:	ba 01 00 00 00       	mov    $0x1,%edx
    8ac2:	4c 89 fe             	mov    %r15,%rsi
    8ac5:	48 89 df             	mov    %rbx,%rdi
    8ac8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8acc:	e8 ff b5 ff ff       	call   40d0 <buf_put>
    8ad1:	e9 80 fd ff ff       	jmp    8856 <fwp_write+0x96>
    8ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8add:	00 00 00 
    8ae0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ae5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8aea:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8aef:	e8 dc b5 ff ff       	call   40d0 <buf_put>
    8af4:	48 85 ed             	test   %rbp,%rbp
    8af7:	0f 84 93 06 00 00    	je     9190 <fwp_write+0x9d0>
    8afd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8b01:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8b06:	31 c9                	xor    %ecx,%ecx
    8b08:	48 89 df             	mov    %rbx,%rdi
    8b0b:	e8 b0 fc ff ff       	call   87c0 <fwp_write>
    8b10:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8b14:	48 85 ed             	test   %rbp,%rbp
    8b17:	0f 84 73 06 00 00    	je     9190 <fwp_write+0x9d0>
    8b1d:	ba 02 00 00 00       	mov    $0x2,%edx
    8b22:	48 8d 35 2c 27 00 00 	lea    0x272c(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8b29:	48 89 df             	mov    %rbx,%rdi
    8b2c:	e8 9f b5 ff ff       	call   40d0 <buf_put>
    8b31:	eb ca                	jmp    8afd <fwp_write+0x33d>
    8b33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b38:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8b3c:	85 f6                	test   %esi,%esi
    8b3e:	0f 84 fc 07 00 00    	je     9340 <fwp_write+0xb80>
    8b44:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b4b:	00 
    8b4c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b53:	00 00 
    8b55:	0f 85 3a 01 00 00    	jne    8c95 <fwp_write+0x4d5>
    8b5b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8b5f:	4c 89 ea             	mov    %r13,%rdx
    8b62:	e9 6c fe ff ff       	jmp    89d3 <fwp_write+0x213>
    8b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b6e:	00 00 
    8b70:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8b75:	ba 01 00 00 00       	mov    $0x1,%edx
    8b7a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8b7f:	48 89 ee             	mov    %rbp,%rsi
    8b82:	e8 49 b5 ff ff       	call   40d0 <buf_put>
    8b87:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8b8c:	4c 89 e7             	mov    %r12,%rdi
    8b8f:	e8 ac a8 ff ff       	call   3440 <strlen@plt>
    8b94:	4c 89 e6             	mov    %r12,%rsi
    8b97:	48 89 df             	mov    %rbx,%rdi
    8b9a:	48 89 c2             	mov    %rax,%rdx
    8b9d:	e8 2e b5 ff ff       	call   40d0 <buf_put>
    8ba2:	ba 01 00 00 00       	mov    $0x1,%edx
    8ba7:	48 89 ee             	mov    %rbp,%rsi
    8baa:	48 89 df             	mov    %rbx,%rdi
    8bad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8bb2:	e8 19 b5 ff ff       	call   40d0 <buf_put>
    8bb7:	e9 9a fc ff ff       	jmp    8856 <fwp_write+0x96>
    8bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8bc0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8bc5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8bc9:	0f 8a 8e 0b 00 00    	jp     975d <fwp_write+0xf9d>
    8bcf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8bd3:	66 0f 54 05 25 31 00 	andpd  0x3125(%rip),%xmm0        # bd00 <msg.4+0x90>
    8bda:	00 
    8bdb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8be0:	66 0f 2e 05 48 31 00 	ucomisd 0x3148(%rip),%xmm0        # bd30 <msg.4+0xc0>
    8be7:	00 
    8be8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8bef:	00 
    8bf0:	0f 87 b2 09 00 00    	ja     95a8 <fwp_write+0xde8>
    8bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bfd:	00 00 00 
    8c00:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c04:	89 ee                	mov    %ebp,%esi
    8c06:	4c 89 e7             	mov    %r12,%rdi
    8c09:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8c0e:	e8 3d bb ff ff       	call   4750 <fwp_format_g.constprop.0>
    8c13:	31 f6                	xor    %esi,%esi
    8c15:	4c 89 e7             	mov    %r12,%rdi
    8c18:	e8 e3 a7 ff ff       	call   3400 <strtod@plt>
    8c1d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8c22:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8c26:	7a 06                	jp     8c2e <fwp_write+0x46e>
    8c28:	0f 84 e9 01 00 00    	je     8e17 <fwp_write+0x657>
    8c2e:	83 c5 01             	add    $0x1,%ebp
    8c31:	83 fd 12             	cmp    $0x12,%ebp
    8c34:	75 ca                	jne    8c00 <fwp_write+0x440>
    8c36:	be 11 00 00 00       	mov    $0x11,%esi
    8c3b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8c3f:	4c 89 e7             	mov    %r12,%rdi
    8c42:	e8 09 bb ff ff       	call   4750 <fwp_format_g.constprop.0>
    8c47:	e9 cb 01 00 00       	jmp    8e17 <fwp_write+0x657>
    8c4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c50:	48 83 fd 01          	cmp    $0x1,%rbp
    8c54:	0f 84 e6 08 00 00    	je     9540 <fwp_write+0xd80>
    8c5a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8c5e:	b8 02 00 00 00       	mov    $0x2,%eax
    8c63:	ba 01 00 00 00       	mov    $0x1,%edx
    8c68:	48 0f 44 d0          	cmove  %rax,%rdx
    8c6c:	48 8d 35 8b 25 00 00 	lea    0x258b(%rip),%rsi        # b1fe <_IO_stdin_used+0x1fe>
    8c73:	48 8d 05 89 25 00 00 	lea    0x2589(%rip),%rax        # b203 <_IO_stdin_used+0x203>
    8c7a:	48 0f 44 f0          	cmove  %rax,%rsi
    8c7e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8c85:	00 
    8c86:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c8d:	00 00 
    8c8f:	0f 84 3e fd ff ff    	je     89d3 <fwp_write+0x213>
    8c95:	e8 b6 a7 ff ff       	call   3450 <__stack_chk_fail@plt>
    8c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ca0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8ca5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8caa:	e8 61 b3 ff ff       	call   4010 <buf_grow>
    8caf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8cb3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8cb9:	4c 03 0b             	add    (%rbx),%r9
    8cbc:	66 45 89 11          	mov    %r10w,(%r9)
    8cc0:	45 85 e4             	test   %r12d,%r12d
    8cc3:	0f 8e 07 05 00 00    	jle    91d0 <fwp_write+0xa10>
    8cc9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8cd0:	55 55 55 
    8cd3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8cd8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8cdf:	aa aa aa 
    8ce2:	49 83 c1 01          	add    $0x1,%r9
    8ce6:	eb 45                	jmp    8d2d <fwp_write+0x56d>
    8ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8cef:	00 
    8cf0:	be 01 00 00 00       	mov    $0x1,%esi
    8cf5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8cfa:	88 07                	mov    %al,(%rdi)
    8cfc:	48 89 e8             	mov    %rbp,%rax
    8cff:	49 f7 e8             	imul   %r8
    8d02:	48 89 e8             	mov    %rbp,%rax
    8d05:	48 c1 f8 3f          	sar    $0x3f,%rax
    8d09:	48 29 c2             	sub    %rax,%rdx
    8d0c:	48 85 c9             	test   %rcx,%rcx
    8d0f:	0f 95 c0             	setne  %al
    8d12:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8d16:	48 83 ef 01          	sub    $0x1,%rdi
    8d1a:	48 21 c5             	and    %rax,%rbp
    8d1d:	48 29 ea             	sub    %rbp,%rdx
    8d20:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8d24:	49 39 f9             	cmp    %rdi,%r9
    8d27:	0f 84 a3 04 00 00    	je     91d0 <fwp_write+0xa10>
    8d2d:	48 89 e8             	mov    %rbp,%rax
    8d30:	49 f7 e8             	imul   %r8
    8d33:	48 89 e8             	mov    %rbp,%rax
    8d36:	48 c1 f8 3f          	sar    $0x3f,%rax
    8d3a:	48 89 d1             	mov    %rdx,%rcx
    8d3d:	48 29 c1             	sub    %rax,%rcx
    8d40:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8d44:	48 89 e9             	mov    %rbp,%rcx
    8d47:	48 29 c1             	sub    %rax,%rcx
    8d4a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8d4e:	49 f7 e2             	mul    %r10
    8d51:	b8 30 00 00 00       	mov    $0x30,%eax
    8d56:	48 89 d6             	mov    %rdx,%rsi
    8d59:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8d5d:	48 d1 ee             	shr    $1,%rsi
    8d60:	48 01 f2             	add    %rsi,%rdx
    8d63:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8d67:	48 29 d6             	sub    %rdx,%rsi
    8d6a:	74 8e                	je     8cfa <fwp_write+0x53a>
    8d6c:	48 83 fe 01          	cmp    $0x1,%rsi
    8d70:	0f 85 7a ff ff ff    	jne    8cf0 <fwp_write+0x530>
    8d76:	31 f6                	xor    %esi,%esi
    8d78:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8d7d:	e9 78 ff ff ff       	jmp    8cfa <fwp_write+0x53a>
    8d82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d88:	66 0f 6e cd          	movd   %ebp,%xmm1
    8d8c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8d8f:	0f 8a c8 09 00 00    	jp     975d <fwp_write+0xf9d>
    8d95:	0f 28 c1             	movaps %xmm1,%xmm0
    8d98:	0f 54 05 51 2f 00 00 	andps  0x2f51(%rip),%xmm0        # bcf0 <msg.4+0x80>
    8d9f:	0f 2e 05 5e 22 00 00 	ucomiss 0x225e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8da6:	0f 87 24 08 00 00    	ja     95d0 <fwp_write+0xe10>
    8dac:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8db0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8db6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8dbd:	00 
    8dbe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8dc2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8dc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8dce:	00 00 
    8dd0:	44 89 ee             	mov    %r13d,%esi
    8dd3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8dd8:	4c 89 e7             	mov    %r12,%rdi
    8ddb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8de0:	e8 6b b9 ff ff       	call   4750 <fwp_format_g.constprop.0>
    8de5:	31 f6                	xor    %esi,%esi
    8de7:	4c 89 e7             	mov    %r12,%rdi
    8dea:	e8 b1 a6 ff ff       	call   34a0 <strtof@plt>
    8def:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8df4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8df7:	7a 02                	jp     8dfb <fwp_write+0x63b>
    8df9:	74 1c                	je     8e17 <fwp_write+0x657>
    8dfb:	41 83 c5 01          	add    $0x1,%r13d
    8dff:	41 83 fd 0a          	cmp    $0xa,%r13d
    8e03:	75 cb                	jne    8dd0 <fwp_write+0x610>
    8e05:	be 09 00 00 00       	mov    $0x9,%esi
    8e0a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8e0f:	4c 89 e7             	mov    %r12,%rdi
    8e12:	e8 39 b9 ff ff       	call   4750 <fwp_format_g.constprop.0>
    8e17:	4c 89 e7             	mov    %r12,%rdi
    8e1a:	e8 71 b3 ff ff       	call   4190 <fwp_finish_float>
    8e1f:	e9 1c fa ff ff       	jmp    8840 <fwp_write+0x80>
    8e24:	0f 1f 40 00          	nopl   0x0(%rax)
    8e28:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8e2c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8e30:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8e37:	00 
    8e38:	48 89 ef             	mov    %rbp,%rdi
    8e3b:	e8 e0 ab ff ff       	call   3a20 <fwp_fmt_u128>
    8e40:	48 89 ef             	mov    %rbp,%rdi
    8e43:	e8 f8 a5 ff ff       	call   3440 <strlen@plt>
    8e48:	48 89 ee             	mov    %rbp,%rsi
    8e4b:	48 89 df             	mov    %rbx,%rdi
    8e4e:	48 89 c2             	mov    %rax,%rdx
    8e51:	e8 7a b2 ff ff       	call   40d0 <buf_put>
    8e56:	e9 fb f9 ff ff       	jmp    8856 <fwp_write+0x96>
    8e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e60:	ba 06 00 00 00       	mov    $0x6,%edx
    8e65:	48 8d 35 ec 23 00 00 	lea    0x23ec(%rip),%rsi        # b258 <_IO_stdin_used+0x258>
    8e6c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8e72:	e8 59 b2 ff ff       	call   40d0 <buf_put>
    8e77:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8e7e:	ff ff 7f 
    8e81:	48 23 55 00          	and    0x0(%rbp),%rdx
    8e85:	0f 84 86 02 00 00    	je     9111 <fwp_write+0x951>
    8e8b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e90:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e94:	48 85 d2             	test   %rdx,%rdx
    8e97:	0f 84 ae 00 00 00    	je     8f4b <fwp_write+0x78b>
    8e9d:	8b 0a                	mov    (%rdx),%ecx
    8e9f:	83 f9 1c             	cmp    $0x1c,%ecx
    8ea2:	0f 84 58 06 00 00    	je     9500 <fwp_write+0xd40>
    8ea8:	83 f9 1b             	cmp    $0x1b,%ecx
    8eab:	0f 87 9a 00 00 00    	ja     8f4b <fwp_write+0x78b>
    8eb1:	be 01 00 00 00       	mov    $0x1,%esi
    8eb6:	48 d3 e6             	shl    %cl,%rsi
    8eb9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8ebf:	0f 85 4b 04 00 00    	jne    9310 <fwp_write+0xb50>
    8ec5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8ecb:	0f 85 0f 04 00 00    	jne    92e0 <fwp_write+0xb20>
    8ed1:	83 e6 21             	and    $0x21,%esi
    8ed4:	74 75                	je     8f4b <fwp_write+0x78b>
    8ed6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8edb:	48 85 ff             	test   %rdi,%rdi
    8ede:	79 07                	jns    8ee7 <fwp_write+0x727>
    8ee0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8ee4:	4c 01 ee             	add    %r13,%rsi
    8ee7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8eeb:	85 c9                	test   %ecx,%ecx
    8eed:	40 0f b6 f7          	movzbl %dil,%esi
    8ef1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8efc:	00 00 00 00 
    8f00:	31 c9                	xor    %ecx,%ecx
    8f02:	48 89 df             	mov    %rbx,%rdi
    8f05:	49 83 c5 01          	add    $0x1,%r13
    8f09:	e8 b2 f8 ff ff       	call   87c0 <fwp_write>
    8f0e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8f15:	ff ff 7f 
    8f18:	48 23 55 00          	and    0x0(%rbp),%rdx
    8f1c:	49 39 d5             	cmp    %rdx,%r13
    8f1f:	0f 83 ec 01 00 00    	jae    9111 <fwp_write+0x951>
    8f25:	ba 02 00 00 00       	mov    $0x2,%edx
    8f2a:	48 89 df             	mov    %rbx,%rdi
    8f2d:	48 8d 35 21 23 00 00 	lea    0x2321(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8f34:	e8 97 b1 ff ff       	call   40d0 <buf_put>
    8f39:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8f3e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8f42:	48 85 d2             	test   %rdx,%rdx
    8f45:	0f 85 52 ff ff ff    	jne    8e9d <fwp_write+0x6dd>
    8f4b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8f50:	48 85 ff             	test   %rdi,%rdi
    8f53:	0f 88 cf 05 00 00    	js     9528 <fwp_write+0xd68>
    8f59:	48 8b 31             	mov    (%rcx),%rsi
    8f5c:	eb a2                	jmp    8f00 <fwp_write+0x740>
    8f5e:	66 90                	xchg   %ax,%ax
    8f60:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8f67:	00 
    8f68:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f6f:	00 00 
    8f71:	0f 85 1e fd ff ff    	jne    8c95 <fwp_write+0x4d5>
    8f77:	ba 08 00 00 00       	mov    $0x8,%edx
    8f7c:	48 8d 35 a2 22 00 00 	lea    0x22a2(%rip),%rsi        # b225 <_IO_stdin_used+0x225>
    8f83:	e9 4b fa ff ff       	jmp    89d3 <fwp_write+0x213>
    8f88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f8f:	00 
    8f90:	89 e8                	mov    %ebp,%eax
    8f92:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8f99:	76 03                	jbe    8f9e <fwp_write+0x7de>
    8f9b:	8b 45 00             	mov    0x0(%rbp),%eax
    8f9e:	41 89 c6             	mov    %eax,%r14d
    8fa1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8fa6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8fab:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8faf:	4c 89 ef             	mov    %r13,%rdi
    8fb2:	e8 89 a4 ff ff       	call   3440 <strlen@plt>
    8fb7:	4c 89 ee             	mov    %r13,%rsi
    8fba:	48 89 df             	mov    %rbx,%rdi
    8fbd:	48 89 c2             	mov    %rax,%rdx
    8fc0:	e8 0b b1 ff ff       	call   40d0 <buf_put>
    8fc5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8fca:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8fce:	85 f6                	test   %esi,%esi
    8fd0:	0f 8e 80 f8 ff ff    	jle    8856 <fwp_write+0x96>
    8fd6:	45 31 ed             	xor    %r13d,%r13d
    8fd9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8fde:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8fe3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8fe8:	ba 01 00 00 00       	mov    $0x1,%edx
    8fed:	4c 89 fe             	mov    %r15,%rsi
    8ff0:	48 89 04 24          	mov    %rax,(%rsp)
    8ff4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8ff9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8ffd:	48 89 df             	mov    %rbx,%rdi
    9000:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9004:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9009:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    900e:	e8 bd b0 ff ff       	call   40d0 <buf_put>
    9013:	41 8b 06             	mov    (%r14),%eax
    9016:	83 f8 0e             	cmp    $0xe,%eax
    9019:	0f 84 71 02 00 00    	je     9290 <fwp_write+0xad0>
    901f:	83 f8 10             	cmp    $0x10,%eax
    9022:	0f 84 38 02 00 00    	je     9260 <fwp_write+0xaa0>
    9028:	83 f8 0a             	cmp    $0xa,%eax
    902b:	0f 84 7f 04 00 00    	je     94b0 <fwp_write+0xcf0>
    9031:	0f 8f f9 00 00 00    	jg     9130 <fwp_write+0x970>
    9037:	83 f8 03             	cmp    $0x3,%eax
    903a:	0f 8f 50 04 00 00    	jg     9490 <fwp_write+0xcd0>
    9040:	85 c0                	test   %eax,%eax
    9042:	78 10                	js     9054 <fwp_write+0x894>
    9044:	48 8b 04 24          	mov    (%rsp),%rax
    9048:	48 c1 e8 3f          	shr    $0x3f,%rax
    904c:	85 c0                	test   %eax,%eax
    904e:	0f 85 f9 00 00 00    	jne    914d <fwp_write+0x98d>
    9054:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9059:	48 8b 34 24          	mov    (%rsp),%rsi
    905d:	31 c9                	xor    %ecx,%ecx
    905f:	48 89 df             	mov    %rbx,%rdi
    9062:	e8 59 f7 ff ff       	call   87c0 <fwp_write>
    9067:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    906c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9071:	49 83 c5 01          	add    $0x1,%r13
    9075:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9079:	0f 8f 5f ff ff ff    	jg     8fde <fwp_write+0x81e>
    907f:	e9 d2 f7 ff ff       	jmp    8856 <fwp_write+0x96>
    9084:	0f 1f 40 00          	nopl   0x0(%rax)
    9088:	ba 06 00 00 00       	mov    $0x6,%edx
    908d:	48 8d 35 b7 21 00 00 	lea    0x21b7(%rip),%rsi        # b24b <_IO_stdin_used+0x24b>
    9094:	45 31 ed             	xor    %r13d,%r13d
    9097:	e8 34 b0 ff ff       	call   40d0 <buf_put>
    909c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    90a1:	75 19                	jne    90bc <fwp_write+0x8fc>
    90a3:	eb 6c                	jmp    9111 <fwp_write+0x951>
    90a5:	0f 1f 00             	nopl   (%rax)
    90a8:	ba 02 00 00 00       	mov    $0x2,%edx
    90ad:	48 8d 35 a1 21 00 00 	lea    0x21a1(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    90b4:	48 89 df             	mov    %rbx,%rdi
    90b7:	e8 14 b0 ff ff       	call   40d0 <buf_put>
    90bc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    90c2:	b9 00 02 00 00       	mov    $0x200,%ecx
    90c7:	31 c0                	xor    %eax,%eax
    90c9:	49 83 c5 01          	add    $0x1,%r13
    90cd:	4c 8d 05 7e 21 00 00 	lea    0x217e(%rip),%r8        # b252 <_IO_stdin_used+0x252>
    90d4:	ba 02 00 00 00       	mov    $0x2,%edx
    90d9:	be 00 02 00 00       	mov    $0x200,%esi
    90de:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    90e5:	00 
    90e6:	e8 b5 a2 ff ff       	call   33a0 <__snprintf_chk@plt>
    90eb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    90f2:	00 
    90f3:	e8 48 a3 ff ff       	call   3440 <strlen@plt>
    90f8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    90ff:	00 
    9100:	48 89 df             	mov    %rbx,%rdi
    9103:	48 89 c2             	mov    %rax,%rdx
    9106:	e8 c5 af ff ff       	call   40d0 <buf_put>
    910b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    910f:	72 97                	jb     90a8 <fwp_write+0x8e8>
    9111:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9116:	ba 01 00 00 00       	mov    $0x1,%edx
    911b:	48 89 df             	mov    %rbx,%rdi
    911e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9123:	e8 a8 af ff ff       	call   40d0 <buf_put>
    9128:	e9 29 f7 ff ff       	jmp    8856 <fwp_write+0x96>
    912d:	0f 1f 00             	nopl   (%rax)
    9130:	83 f8 0b             	cmp    $0xb,%eax
    9133:	0f 85 1b ff ff ff    	jne    9054 <fwp_write+0x894>
    9139:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    913e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9142:	83 e0 01             	and    $0x1,%eax
    9145:	85 c0                	test   %eax,%eax
    9147:	0f 84 07 ff ff ff    	je     9054 <fwp_write+0x894>
    914d:	4c 89 fe             	mov    %r15,%rsi
    9150:	48 89 df             	mov    %rbx,%rdi
    9153:	ba 01 00 00 00       	mov    $0x1,%edx
    9158:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    915d:	e8 6e af ff ff       	call   40d0 <buf_put>
    9162:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9167:	48 8b 34 24          	mov    (%rsp),%rsi
    916b:	31 c9                	xor    %ecx,%ecx
    916d:	48 89 df             	mov    %rbx,%rdi
    9170:	e8 4b f6 ff ff       	call   87c0 <fwp_write>
    9175:	ba 01 00 00 00       	mov    $0x1,%edx
    917a:	4c 89 fe             	mov    %r15,%rsi
    917d:	48 89 df             	mov    %rbx,%rdi
    9180:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9185:	e8 46 af ff ff       	call   40d0 <buf_put>
    918a:	e9 d8 fe ff ff       	jmp    9067 <fwp_write+0x8a7>
    918f:	90                   	nop
    9190:	ba 01 00 00 00       	mov    $0x1,%edx
    9195:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    919a:	48 89 df             	mov    %rbx,%rdi
    919d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    91a2:	e8 29 af ff ff       	call   40d0 <buf_put>
    91a7:	e9 aa f6 ff ff       	jmp    8856 <fwp_write+0x96>
    91ac:	0f 1f 40 00          	nopl   0x0(%rax)
    91b0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91b5:	ba 01 00 00 00       	mov    $0x1,%edx
    91ba:	48 89 df             	mov    %rbx,%rdi
    91bd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    91c2:	e8 09 af ff ff       	call   40d0 <buf_put>
    91c7:	e9 8a f6 ff ff       	jmp    8856 <fwp_write+0x96>
    91cc:	0f 1f 40 00          	nopl   0x0(%rax)
    91d0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    91d4:	48 8b 13             	mov    (%rbx),%rdx
    91d7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    91dc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    91e0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    91e4:	e9 6d f6 ff ff       	jmp    8856 <fwp_write+0x96>
    91e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91f0:	ba 02 00 00 00       	mov    $0x2,%edx
    91f5:	48 8d 35 59 20 00 00 	lea    0x2059(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    91fc:	48 89 df             	mov    %rbx,%rdi
    91ff:	e8 cc ae ff ff       	call   40d0 <buf_put>
    9204:	e9 72 f8 ff ff       	jmp    8a7b <fwp_write+0x2bb>
    9209:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9210:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9215:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    921a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    921e:	48 89 f7             	mov    %rsi,%rdi
    9221:	48 89 34 24          	mov    %rsi,(%rsp)
    9225:	e8 16 a2 ff ff       	call   3440 <strlen@plt>
    922a:	48 8b 34 24          	mov    (%rsp),%rsi
    922e:	48 89 df             	mov    %rbx,%rdi
    9231:	48 89 c2             	mov    %rax,%rdx
    9234:	e8 97 ae ff ff       	call   40d0 <buf_put>
    9239:	ba 03 00 00 00       	mov    $0x3,%edx
    923e:	48 8d 35 33 20 00 00 	lea    0x2033(%rip),%rsi        # b278 <_IO_stdin_used+0x278>
    9245:	48 89 df             	mov    %rbx,%rdi
    9248:	e8 83 ae ff ff       	call   40d0 <buf_put>
    924d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9252:	e9 35 f8 ff ff       	jmp    8a8c <fwp_write+0x2cc>
    9257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    925e:	00 00 
    9260:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9265:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9269:	48 85 ff             	test   %rdi,%rdi
    926c:	0f 84 e2 fd ff ff    	je     9054 <fwp_write+0x894>
    9272:	48 8d 35 e9 1f 00 00 	lea    0x1fe9(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    9279:	e8 a2 a2 ff ff       	call   3520 <strcmp@plt>
    927e:	85 c0                	test   %eax,%eax
    9280:	0f 95 c0             	setne  %al
    9283:	0f b6 c0             	movzbl %al,%eax
    9286:	e9 c1 fd ff ff       	jmp    904c <fwp_write+0x88c>
    928b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9290:	31 c0                	xor    %eax,%eax
    9292:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9299:	00 
    929a:	0f 97 c0             	seta   %al
    929d:	e9 aa fd ff ff       	jmp    904c <fwp_write+0x88c>
    92a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92a8:	48 89 df             	mov    %rbx,%rdi
    92ab:	ba 02 00 00 00       	mov    $0x2,%edx
    92b0:	48 8d 35 a8 1f 00 00 	lea    0x1fa8(%rip),%rsi        # b25f <_IO_stdin_used+0x25f>
    92b7:	e8 14 ae ff ff       	call   40d0 <buf_put>
    92bc:	4c 89 e8             	mov    %r13,%rax
    92bf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    92c4:	31 c9                	xor    %ecx,%ecx
    92c6:	48 c1 e0 04          	shl    $0x4,%rax
    92ca:	48 89 df             	mov    %rbx,%rdi
    92cd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    92d2:	e8 e9 f4 ff ff       	call   87c0 <fwp_write>
    92d7:	e9 5e f6 ff ff       	jmp    893a <fwp_write+0x17a>
    92dc:	0f 1f 40 00          	nopl   0x0(%rax)
    92e0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    92e5:	48 85 ff             	test   %rdi,%rdi
    92e8:	79 0c                	jns    92f6 <fwp_write+0xb36>
    92ea:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    92f1:	00 
    92f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    92f6:	48 63 3e             	movslq (%rsi),%rdi
    92f9:	83 f9 02             	cmp    $0x2,%ecx
    92fc:	89 fe                	mov    %edi,%esi
    92fe:	48 0f 44 f7          	cmove  %rdi,%rsi
    9302:	e9 f9 fb ff ff       	jmp    8f00 <fwp_write+0x740>
    9307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    930e:	00 00 
    9310:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9315:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    931a:	48 85 ff             	test   %rdi,%rdi
    931d:	0f 88 0f 03 00 00    	js     9632 <fwp_write+0xe72>
    9323:	49 0f bf 38          	movswq (%r8),%rdi
    9327:	83 f9 01             	cmp    $0x1,%ecx
    932a:	0f b7 f7             	movzwl %di,%esi
    932d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9331:	e9 ca fb ff ff       	jmp    8f00 <fwp_write+0x740>
    9336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    933d:	00 00 00 
    9340:	ba 01 00 00 00       	mov    $0x1,%edx
    9345:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    934a:	48 83 c5 08          	add    $0x8,%rbp
    934e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9353:	e8 78 ad ff ff       	call   40d0 <buf_put>
    9358:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    935d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9362:	4d 85 ed             	test   %r13,%r13
    9365:	75 46                	jne    93ad <fwp_write+0xbed>
    9367:	e9 04 01 00 00       	jmp    9470 <fwp_write+0xcb0>
    936c:	0f 1f 40 00          	nopl   0x0(%rax)
    9370:	41 80 f9 09          	cmp    $0x9,%r9b
    9374:	0f 84 d6 00 00 00    	je     9450 <fwp_write+0xc90>
    937a:	41 80 f9 0a          	cmp    $0xa,%r9b
    937e:	0f 85 9c 00 00 00    	jne    9420 <fwp_write+0xc60>
    9384:	ba 02 00 00 00       	mov    $0x2,%edx
    9389:	48 8d 35 ab 1e 00 00 	lea    0x1eab(%rip),%rsi        # b23b <_IO_stdin_used+0x23b>
    9390:	48 89 df             	mov    %rbx,%rdi
    9393:	e8 38 ad ff ff       	call   40d0 <buf_put>
    9398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    939f:	00 
    93a0:	48 83 c5 01          	add    $0x1,%rbp
    93a4:	49 39 ec             	cmp    %rbp,%r12
    93a7:	0f 84 c3 00 00 00    	je     9470 <fwp_write+0xcb0>
    93ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    93b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    93b6:	74 28                	je     93e0 <fwp_write+0xc20>
    93b8:	7e b6                	jle    9370 <fwp_write+0xbb0>
    93ba:	41 80 f9 22          	cmp    $0x22,%r9b
    93be:	74 40                	je     9400 <fwp_write+0xc40>
    93c0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    93c4:	75 5a                	jne    9420 <fwp_write+0xc60>
    93c6:	ba 02 00 00 00       	mov    $0x2,%edx
    93cb:	48 8d 35 66 1e 00 00 	lea    0x1e66(%rip),%rsi        # b238 <_IO_stdin_used+0x238>
    93d2:	48 89 df             	mov    %rbx,%rdi
    93d5:	e8 f6 ac ff ff       	call   40d0 <buf_put>
    93da:	eb c4                	jmp    93a0 <fwp_write+0xbe0>
    93dc:	0f 1f 40 00          	nopl   0x0(%rax)
    93e0:	ba 02 00 00 00       	mov    $0x2,%edx
    93e5:	48 8d 35 55 1e 00 00 	lea    0x1e55(%rip),%rsi        # b241 <_IO_stdin_used+0x241>
    93ec:	48 89 df             	mov    %rbx,%rdi
    93ef:	e8 dc ac ff ff       	call   40d0 <buf_put>
    93f4:	eb aa                	jmp    93a0 <fwp_write+0xbe0>
    93f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93fd:	00 00 00 
    9400:	ba 02 00 00 00       	mov    $0x2,%edx
    9405:	48 8d 35 29 1e 00 00 	lea    0x1e29(%rip),%rsi        # b235 <_IO_stdin_used+0x235>
    940c:	48 89 df             	mov    %rbx,%rdi
    940f:	e8 bc ac ff ff       	call   40d0 <buf_put>
    9414:	eb 8a                	jmp    93a0 <fwp_write+0xbe0>
    9416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    941d:	00 00 00 
    9420:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9424:	0f 86 2e 01 00 00    	jbe    9558 <fwp_write+0xd98>
    942a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    942e:	0f 84 24 01 00 00    	je     9558 <fwp_write+0xd98>
    9434:	ba 01 00 00 00       	mov    $0x1,%edx
    9439:	4c 89 fe             	mov    %r15,%rsi
    943c:	48 89 df             	mov    %rbx,%rdi
    943f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9444:	e8 87 ac ff ff       	call   40d0 <buf_put>
    9449:	e9 52 ff ff ff       	jmp    93a0 <fwp_write+0xbe0>
    944e:	66 90                	xchg   %ax,%ax
    9450:	ba 02 00 00 00       	mov    $0x2,%edx
    9455:	48 8d 35 e2 1d 00 00 	lea    0x1de2(%rip),%rsi        # b23e <_IO_stdin_used+0x23e>
    945c:	48 89 df             	mov    %rbx,%rdi
    945f:	e8 6c ac ff ff       	call   40d0 <buf_put>
    9464:	e9 37 ff ff ff       	jmp    93a0 <fwp_write+0xbe0>
    9469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9470:	ba 01 00 00 00       	mov    $0x1,%edx
    9475:	4c 89 fe             	mov    %r15,%rsi
    9478:	48 89 df             	mov    %rbx,%rdi
    947b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9480:	e8 4b ac ff ff       	call   40d0 <buf_put>
    9485:	e9 cc f3 ff ff       	jmp    8856 <fwp_write+0x96>
    948a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9490:	83 f8 04             	cmp    $0x4,%eax
    9493:	0f 85 bb fb ff ff    	jne    9054 <fwp_write+0x894>
    9499:	48 8b 04 24          	mov    (%rsp),%rax
    949d:	48 8b 40 08          	mov    0x8(%rax),%rax
    94a1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    94a6:	48 c1 e8 3f          	shr    $0x3f,%rax
    94aa:	e9 96 fc ff ff       	jmp    9145 <fwp_write+0x985>
    94af:	90                   	nop
    94b0:	8b 0c 24             	mov    (%rsp),%ecx
    94b3:	31 c0                	xor    %eax,%eax
    94b5:	85 c9                	test   %ecx,%ecx
    94b7:	0f 98 c0             	sets   %al
    94ba:	e9 86 fc ff ff       	jmp    9145 <fwp_write+0x985>
    94bf:	90                   	nop
    94c0:	48 f7 d8             	neg    %rax
    94c3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    94ca:	00 
    94cb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    94d2:	2d 
    94d3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94da:	00 
    94db:	48 83 d2 00          	adc    $0x0,%rdx
    94df:	48 89 c6             	mov    %rax,%rsi
    94e2:	48 f7 da             	neg    %rdx
    94e5:	e8 36 a5 ff ff       	call   3a20 <fwp_fmt_u128>
    94ea:	e9 51 f3 ff ff       	jmp    8840 <fwp_write+0x80>
    94ef:	90                   	nop
    94f0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    94f5:	e9 c3 f5 ff ff       	jmp    8abd <fwp_write+0x2fd>
    94fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9500:	4c 89 e9             	mov    %r13,%rcx
    9503:	48 c1 e1 04          	shl    $0x4,%rcx
    9507:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    950c:	48 85 ff             	test   %rdi,%rdi
    950f:	0f 89 eb f9 ff ff    	jns    8f00 <fwp_write+0x740>
    9515:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9519:	48 89 ce             	mov    %rcx,%rsi
    951c:	e9 df f9 ff ff       	jmp    8f00 <fwp_write+0x740>
    9521:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9528:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    952f:	00 
    9530:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9534:	e9 20 fa ff ff       	jmp    8f59 <fwp_write+0x799>
    9539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9540:	ba 02 00 00 00       	mov    $0x2,%edx
    9545:	48 8d 35 b4 1c 00 00 	lea    0x1cb4(%rip),%rsi        # b200 <_IO_stdin_used+0x200>
    954c:	e9 2d f7 ff ff       	jmp    8c7e <fwp_write+0x4be>
    9551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9558:	4c 8d 05 e5 1c 00 00 	lea    0x1ce5(%rip),%r8        # b244 <_IO_stdin_used+0x244>
    955f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9564:	31 c0                	xor    %eax,%eax
    9566:	ba 02 00 00 00       	mov    $0x2,%edx
    956b:	be 10 00 00 00       	mov    $0x10,%esi
    9570:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9577:	00 
    9578:	e8 23 9e ff ff       	call   33a0 <__snprintf_chk@plt>
    957d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9584:	00 
    9585:	e8 b6 9e ff ff       	call   3440 <strlen@plt>
    958a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9591:	00 
    9592:	48 89 df             	mov    %rbx,%rdi
    9595:	48 89 c2             	mov    %rax,%rdx
    9598:	e8 33 ab ff ff       	call   40d0 <buf_put>
    959d:	e9 fe fd ff ff       	jmp    93a0 <fwp_write+0xbe0>
    95a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    95ac:	48 8d 35 47 1c 00 00 	lea    0x1c47(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    95b3:	48 8d 05 3f 1c 00 00 	lea    0x1c3f(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    95ba:	4c 89 e7             	mov    %r12,%rdi
    95bd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    95c1:	48 0f 46 f0          	cmovbe %rax,%rsi
    95c5:	e8 16 9e ff ff       	call   33e0 <strcpy@plt>
    95ca:	e9 71 f2 ff ff       	jmp    8840 <fwp_write+0x80>
    95cf:	90                   	nop
    95d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    95d4:	48 8d 35 1f 1c 00 00 	lea    0x1c1f(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    95db:	48 8d 05 17 1c 00 00 	lea    0x1c17(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    95e2:	0f 2f c8             	comiss %xmm0,%xmm1
    95e5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95ec:	00 
    95ed:	4c 89 e7             	mov    %r12,%rdi
    95f0:	48 0f 46 f0          	cmovbe %rax,%rsi
    95f4:	e8 e7 9d ff ff       	call   33e0 <strcpy@plt>
    95f9:	e9 42 f2 ff ff       	jmp    8840 <fwp_write+0x80>
    95fe:	66 90                	xchg   %ax,%ax
    9600:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9605:	45 85 c0             	test   %r8d,%r8d
    9608:	75 34                	jne    963e <fwp_write+0xe7e>
    960a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9611:	00 
    9612:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9619:	00 00 
    961b:	0f 85 74 f6 ff ff    	jne    8c95 <fwp_write+0x4d5>
    9621:	ba 02 00 00 00       	mov    $0x2,%edx
    9626:	48 8d 35 48 1c 00 00 	lea    0x1c48(%rip),%rsi        # b275 <_IO_stdin_used+0x275>
    962d:	e9 a1 f3 ff ff       	jmp    89d3 <fwp_write+0x213>
    9632:	48 03 75 10          	add    0x10(%rbp),%rsi
    9636:	49 89 f0             	mov    %rsi,%r8
    9639:	e9 e5 fc ff ff       	jmp    9323 <fwp_write+0xb63>
    963e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9643:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9648:	85 ff                	test   %edi,%edi
    964a:	0f 84 fa f3 ff ff    	je     8a4a <fwp_write+0x28a>
    9650:	ba 01 00 00 00       	mov    $0x1,%edx
    9655:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    965a:	48 89 df             	mov    %rbx,%rdi
    965d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9662:	e8 69 aa ff ff       	call   40d0 <buf_put>
    9667:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    966c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9671:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9677:	85 c0                	test   %eax,%eax
    9679:	0f 8f f0 f3 ff ff    	jg     8a6f <fwp_write+0x2af>
    967f:	e9 34 f4 ff ff       	jmp    8ab8 <fwp_write+0x2f8>
    9684:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9688:	49 89 c5             	mov    %rax,%r13
    968b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9690:	49 89 c4             	mov    %rax,%r12
    9693:	49 c1 fd 3f          	sar    $0x3f,%r13
    9697:	4c 09 e8             	or     %r13,%rax
    969a:	0f 84 a7 00 00 00    	je     9747 <fwp_write+0xf87>
    96a0:	48 8d 2d 19 3c 00 00 	lea    0x3c19(%rip),%rbp        # d2c0 <units.0>
    96a7:	4d 89 e7             	mov    %r12,%r15
    96aa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    96ae:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    96b3:	4c 89 ff             	mov    %r15,%rdi
    96b6:	4c 89 ee             	mov    %r13,%rsi
    96b9:	44 89 0c 24          	mov    %r9d,(%rsp)
    96bd:	48 99                	cqto
    96bf:	48 89 d1             	mov    %rdx,%rcx
    96c2:	48 89 c2             	mov    %rax,%rdx
    96c5:	e8 56 10 00 00       	call   a720 <__divmodti4>
    96ca:	44 8b 0c 24          	mov    (%rsp),%r9d
    96ce:	48 89 c1             	mov    %rax,%rcx
    96d1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    96d6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    96db:	0f 84 94 00 00 00    	je     9775 <fwp_write+0xfb5>
    96e1:	41 83 c1 01          	add    $0x1,%r9d
    96e5:	48 83 c5 10          	add    $0x10,%rbp
    96e9:	41 83 f9 05          	cmp    $0x5,%r9d
    96ed:	75 bb                	jne    96aa <fwp_write+0xeea>
    96ef:	4d 85 ed             	test   %r13,%r13
    96f2:	79 53                	jns    9747 <fwp_write+0xf87>
    96f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    96f9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    96fe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9703:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9708:	48 99                	cqto
    970a:	48 f7 d8             	neg    %rax
    970d:	48 83 d2 00          	adc    $0x0,%rdx
    9711:	48 89 c6             	mov    %rax,%rsi
    9714:	48 f7 da             	neg    %rdx
    9717:	e8 04 a3 ff ff       	call   3a20 <fwp_fmt_u128>
    971c:	49 89 e8             	mov    %rbp,%r8
    971f:	ba 00 02 00 00       	mov    $0x200,%edx
    9724:	be 02 00 00 00       	mov    $0x2,%esi
    9729:	31 c0                	xor    %eax,%eax
    972b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9732:	00 
    9733:	48 8d 0d 36 1b 00 00 	lea    0x1b36(%rip),%rcx        # b270 <_IO_stdin_used+0x270>
    973a:	4c 89 e7             	mov    %r12,%rdi
    973d:	e8 7e 9f ff ff       	call   36c0 <__sprintf_chk@plt>
    9742:	e9 f9 f0 ff ff       	jmp    8840 <fwp_write+0x80>
    9747:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    974c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9751:	31 d2                	xor    %edx,%edx
    9753:	48 89 ef             	mov    %rbp,%rdi
    9756:	e8 c5 a2 ff ff       	call   3a20 <fwp_fmt_u128>
    975b:	eb bf                	jmp    971c <fwp_write+0xf5c>
    975d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9764:	4e 61 4e 00 
    9768:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    976f:	00 
    9770:	e9 cb f0 ff ff       	jmp    8840 <fwp_write+0x80>
    9775:	44 89 0c 24          	mov    %r9d,(%rsp)
    9779:	48 89 c8             	mov    %rcx,%rax
    977c:	48 85 d2             	test   %rdx,%rdx
    977f:	78 51                	js     97d2 <fwp_write+0x1012>
    9781:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9786:	48 89 c6             	mov    %rax,%rsi
    9789:	48 89 ef             	mov    %rbp,%rdi
    978c:	e8 8f a2 ff ff       	call   3a20 <fwp_fmt_u128>
    9791:	44 8b 0c 24          	mov    (%rsp),%r9d
    9795:	49 63 c1             	movslq %r9d,%rax
    9798:	49 89 e8             	mov    %rbp,%r8
    979b:	ba 00 02 00 00       	mov    $0x200,%edx
    97a0:	be 02 00 00 00       	mov    $0x2,%esi
    97a5:	48 c1 e0 04          	shl    $0x4,%rax
    97a9:	48 8d 3d 10 3b 00 00 	lea    0x3b10(%rip),%rdi        # d2c0 <units.0>
    97b0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97b7:	00 
    97b8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    97bc:	48 8d 0d a8 1a 00 00 	lea    0x1aa8(%rip),%rcx        # b26b <_IO_stdin_used+0x26b>
    97c3:	4c 89 e7             	mov    %r12,%rdi
    97c6:	31 c0                	xor    %eax,%eax
    97c8:	e8 f3 9e ff ff       	call   36c0 <__sprintf_chk@plt>
    97cd:	e9 6e f0 ff ff       	jmp    8840 <fwp_write+0x80>
    97d2:	48 f7 d8             	neg    %rax
    97d5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    97da:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    97df:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    97e4:	48 83 d2 00          	adc    $0x0,%rdx
    97e8:	48 89 c6             	mov    %rax,%rsi
    97eb:	48 f7 da             	neg    %rdx
    97ee:	e8 2d a2 ff ff       	call   3a20 <fwp_fmt_u128>
    97f3:	44 8b 0c 24          	mov    (%rsp),%r9d
    97f7:	eb 9c                	jmp    9795 <fwp_write+0xfd5>
    97f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009800 <fwp_main_thread>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	41 57                	push   %r15
    9806:	41 56                	push   %r14
    9808:	41 55                	push   %r13
    980a:	41 54                	push   %r12
    980c:	55                   	push   %rbp
    980d:	53                   	push   %rbx
    980e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9815:	8b 3d a9 f3 05 00    	mov    0x5f3a9(%rip),%edi        # 68bc4 <fwp_heap+0x13a4>
    981b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9822:	00 00 
    9824:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    982b:	00 
    982c:	31 c0                	xor    %eax,%eax
    982e:	85 ff                	test   %edi,%edi
    9830:	0f 84 72 07 00 00    	je     9fa8 <fwp_main_thread+0x7a8>
    9836:	8b 35 8c f3 05 00    	mov    0x5f38c(%rip),%esi        # 68bc8 <fwp_heap+0x13a8>
    983c:	85 f6                	test   %esi,%esi
    983e:	0f 85 4c 07 00 00    	jne    9f90 <fwp_main_thread+0x790>
    9844:	48 8d 05 35 58 00 00 	lea    0x5835(%rip),%rax        # f080 <alt.5>
    984b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9850:	31 f6                	xor    %esi,%esi
    9852:	48 c7 05 63 d9 05 00 	movq   $0x40000000,0x5d963(%rip)        # 671c0 <fwp_main_stack_size>
    9859:	00 00 00 40 
    985d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9862:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9867:	48 89 c7             	mov    %rax,%rdi
    986a:	48 89 2d 57 d9 05 00 	mov    %rbp,0x5d957(%rip)        # 671c8 <fwp_main_stack_top>
    9871:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9878:	01 00 
    987a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9881:	00 
    9882:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9887:	e8 14 9e ff ff       	call   36a0 <sigaltstack@plt>
    988c:	85 c0                	test   %eax,%eax
    988e:	0f 85 43 0e 00 00    	jne    a6d7 <fwp_main_thread+0xed7>
    9894:	31 c0                	xor    %eax,%eax
    9896:	b9 12 00 00 00       	mov    $0x12,%ecx
    989b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    98a2:	00 
    98a3:	f3 48 ab             	rep stos %rax,(%rdi)
    98a6:	48 8d 05 73 a4 ff ff 	lea    -0x5b8d(%rip),%rax        # 3d20 <fwp_segv>
    98ad:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    98b4:	00 
    98b5:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    98bc:	04 00 00 08 
    98c0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    98c7:	00 
    98c8:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    98cf:	00 
    98d0:	e8 8b 9c ff ff       	call   3560 <sigemptyset@plt>
    98d5:	85 c0                	test   %eax,%eax
    98d7:	0f 85 fa 0d 00 00    	jne    a6d7 <fwp_main_thread+0xed7>
    98dd:	31 d2                	xor    %edx,%edx
    98df:	48 89 de             	mov    %rbx,%rsi
    98e2:	bf 0b 00 00 00       	mov    $0xb,%edi
    98e7:	e8 04 9b ff ff       	call   33f0 <sigaction@plt>
    98ec:	85 c0                	test   %eax,%eax
    98ee:	0f 85 e3 0d 00 00    	jne    a6d7 <fwp_main_thread+0xed7>
    98f4:	31 d2                	xor    %edx,%edx
    98f6:	48 89 de             	mov    %rbx,%rsi
    98f9:	bf 07 00 00 00       	mov    $0x7,%edi
    98fe:	e8 ed 9a ff ff       	call   33f0 <sigaction@plt>
    9903:	85 c0                	test   %eax,%eax
    9905:	0f 85 cc 0d 00 00    	jne    a6d7 <fwp_main_thread+0xed7>
    990b:	48 8b 05 2e f3 05 00 	mov    0x5f32e(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9912:	48 85 c0             	test   %rax,%rax
    9915:	0f 88 35 06 00 00    	js     9f50 <fwp_main_thread+0x750>
    991b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    991f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9924:	48 8d 3d d5 a8 ff ff 	lea    -0x572b(%rip),%rdi        # 4200 <ad_raw_report>
    992b:	f2 0f 11 05 95 fb 05 	movsd  %xmm0,0x5fb95(%rip)        # 694c8 <iteration_start_charge>
    9932:	00 
    9933:	c7 05 ab fb 05 00 01 	movl   $0x1,0x5fbab(%rip)        # 694e8 <iteration_active>
    993a:	00 00 00 
    993d:	e8 ee 0f 00 00       	call   a930 <atexit>
    9942:	85 c0                	test   %eax,%eax
    9944:	0f 85 aa 0d 00 00    	jne    a6f4 <fwp_main_thread+0xef4>
    994a:	8b 0d 18 57 00 00    	mov    0x5718(%rip),%ecx        # f068 <st.3>
    9950:	85 c9                	test   %ecx,%ecx
    9952:	0f 84 60 06 00 00    	je     9fb8 <fwp_main_thread+0x7b8>
    9958:	48 8b 2d a1 de 05 00 	mov    0x5dea1(%rip),%rbp        # 67800 <fwp_cur>
    995f:	48 85 ed             	test   %rbp,%rbp
    9962:	0f 84 08 03 00 00    	je     9c70 <fwp_main_thread+0x470>
    9968:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    996d:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9971:	48 89 eb             	mov    %rbp,%rbx
    9974:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9979:	0f 84 41 01 00 00    	je     9ac0 <fwp_main_thread+0x2c0>
    997f:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9984:	0f 84 16 02 00 00    	je     9ba0 <fwp_main_thread+0x3a0>
    998a:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    998e:	0f 84 fc 01 00 00    	je     9b90 <fwp_main_thread+0x390>
    9994:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9998:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    999c:	0f 85 7e 02 00 00    	jne    9c20 <fwp_main_thread+0x420>
    99a2:	48 8b 43 60          	mov    0x60(%rbx),%rax
    99a6:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    99ad:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    99b1:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    99b8:	00 00 00 00 
    99bc:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    99c3:	48 85 d2             	test   %rdx,%rdx
    99c6:	74 07                	je     99cf <fwp_main_thread+0x1cf>
    99c8:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    99cf:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    99d3:	48 85 c0             	test   %rax,%rax
    99d6:	74 34                	je     9a0c <fwp_main_thread+0x20c>
    99d8:	48 89 43 68          	mov    %rax,0x68(%rbx)
    99dc:	48 8b 05 f5 dd 05 00 	mov    0x5ddf5(%rip),%rax        # 677d8 <fwp_timers>
    99e3:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    99e7:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    99ee:	00 00 00 00 
    99f2:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    99f9:	48 85 c0             	test   %rax,%rax
    99fc:	74 07                	je     9a05 <fwp_main_thread+0x205>
    99fe:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9a05:	48 89 1d cc dd 05 00 	mov    %rbx,0x5ddcc(%rip)        # 677d8 <fwp_timers>
    9a0c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9a10:	e8 1b de ff ff       	call   7830 <fwp_block>
    9a15:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9a1c:	48 85 c9             	test   %rcx,%rcx
    9a1f:	74 47                	je     9a68 <fwp_main_thread+0x268>
    9a21:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9a28:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9a2f:	48 85 d2             	test   %rdx,%rdx
    9a32:	0f 84 28 02 00 00    	je     9c60 <fwp_main_thread+0x460>
    9a38:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9a3f:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9a46:	48 85 c0             	test   %rax,%rax
    9a49:	74 07                	je     9a52 <fwp_main_thread+0x252>
    9a4b:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9a52:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9a59:	00 00 00 00 
    9a5d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9a61:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9a68:	48 8b 0d 91 dd 05 00 	mov    0x5dd91(%rip),%rcx        # 67800 <fwp_cur>
    9a6f:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9a73:	0f 84 97 01 00 00    	je     9c10 <fwp_main_thread+0x410>
    9a79:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9a80:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9a87:	48 85 d2             	test   %rdx,%rdx
    9a8a:	0f 84 20 04 00 00    	je     9eb0 <fwp_main_thread+0x6b0>
    9a90:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9a97:	48 85 c0             	test   %rax,%rax
    9a9a:	74 07                	je     9aa3 <fwp_main_thread+0x2a3>
    9a9c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9aa3:	66 0f ef db          	pxor   %xmm3,%xmm3
    9aa7:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9aab:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    9ab2:	48 89 cb             	mov    %rcx,%rbx
    9ab5:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9aba:	0f 85 bf fe ff ff    	jne    997f <fwp_main_thread+0x17f>
    9ac0:	48 83 3d d0 f9 05 00 	cmpq   $0x0,0x5f9d0(%rip)        # 69498 <fwp_state_len>
    9ac7:	00 
    9ac8:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9acc:	0f 84 10 04 00 00    	je     9ee2 <fwp_main_thread+0x6e2>
    9ad2:	48 39 1d 1f dd 05 00 	cmp    %rbx,0x5dd1f(%rip)        # 677f8 <fwp_root>
    9ad9:	c7 05 9d 55 01 00 00 	movl   $0x0,0x1559d(%rip)        # 1f080 <fwp_exit_code>
    9ae0:	00 00 00 
    9ae3:	0f 85 28 0c 00 00    	jne    a711 <fwp_main_thread+0xf11>
    9ae9:	48 85 db             	test   %rbx,%rbx
    9aec:	0f 84 a4 01 00 00    	je     9c96 <fwp_main_thread+0x496>
    9af2:	48 8b 15 cf dc 05 00 	mov    0x5dccf(%rip),%rdx        # 677c8 <fwp_tasks_active>
    9af9:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9afd:	48 85 d2             	test   %rdx,%rdx
    9b00:	0f 84 90 01 00 00    	je     9c96 <fwp_main_thread+0x496>
    9b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b0d:	00 00 00 
    9b10:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9b14:	75 08                	jne    9b1e <fwp_main_thread+0x31e>
    9b16:	48 89 d7             	mov    %rdx,%rdi
    9b19:	e8 f2 a5 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    9b1e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9b25:	48 85 d2             	test   %rdx,%rdx
    9b28:	75 e6                	jne    9b10 <fwp_main_thread+0x310>
    9b2a:	eb 31                	jmp    9b5d <fwp_main_thread+0x35d>
    9b2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b30:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9b37:	48 89 1d a2 dc 05 00 	mov    %rbx,0x5dca2(%rip)        # 677e0 <fwp_ready_tail>
    9b3e:	e8 ed dc ff ff       	call   7830 <fwp_block>
    9b43:	e8 d8 da ff ff       	call   7620 <fwp_free_zombie>
    9b48:	48 83 3d 78 dc 05 00 	cmpq   $0x0,0x5dc78(%rip)        # 677c8 <fwp_tasks_active>
    9b4f:	00 
    9b50:	0f 84 40 01 00 00    	je     9c96 <fwp_main_thread+0x496>
    9b56:	48 8b 1d 9b dc 05 00 	mov    0x5dc9b(%rip),%rbx        # 677f8 <fwp_root>
    9b5d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9b61:	75 db                	jne    9b3e <fwp_main_thread+0x33e>
    9b63:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9b67:	75 d5                	jne    9b3e <fwp_main_thread+0x33e>
    9b69:	48 8b 05 70 dc 05 00 	mov    0x5dc70(%rip),%rax        # 677e0 <fwp_ready_tail>
    9b70:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9b74:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9b7b:	00 00 00 00 
    9b7f:	48 85 c0             	test   %rax,%rax
    9b82:	75 ac                	jne    9b30 <fwp_main_thread+0x330>
    9b84:	48 89 1d 5d dc 05 00 	mov    %rbx,0x5dc5d(%rip)        # 677e8 <fwp_ready_head>
    9b8b:	eb aa                	jmp    9b37 <fwp_main_thread+0x337>
    9b8d:	0f 1f 00             	nopl   (%rax)
    9b90:	e8 0b aa ff ff       	call   45a0 <fwp_now_ns>
    9b95:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9b99:	0f 8d 21 03 00 00    	jge    9ec0 <fwp_main_thread+0x6c0>
    9b9f:	90                   	nop
    9ba0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9ba4:	0f 85 ea fd ff ff    	jne    9994 <fwp_main_thread+0x194>
    9baa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9bae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9bb2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9bb6:	0f 85 ea fd ff ff    	jne    99a6 <fwp_main_thread+0x1a6>
    9bbc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9bc0:	48 85 c9             	test   %rcx,%rcx
    9bc3:	0f 84 dd fd ff ff    	je     99a6 <fwp_main_thread+0x1a6>
    9bc9:	48 39 c8             	cmp    %rcx,%rax
    9bcc:	48 89 ce             	mov    %rcx,%rsi
    9bcf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9bd6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9bda:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9be1:	00 00 00 00 
    9be5:	48 0f 4e f0          	cmovle %rax,%rsi
    9be9:	48 85 c0             	test   %rax,%rax
    9bec:	48 89 c8             	mov    %rcx,%rax
    9bef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9bf6:	48 0f 45 c6          	cmovne %rsi,%rax
    9bfa:	48 85 d2             	test   %rdx,%rdx
    9bfd:	74 07                	je     9c06 <fwp_main_thread+0x406>
    9bff:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9c06:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9c0a:	e9 c9 fd ff ff       	jmp    99d8 <fwp_main_thread+0x1d8>
    9c0f:	90                   	nop
    9c10:	48 89 cb             	mov    %rcx,%rbx
    9c13:	e9 5c fd ff ff       	jmp    9974 <fwp_main_thread+0x174>
    9c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c1f:	00 
    9c20:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9c24:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9c2b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9c32:	00 00 00 00 
    9c36:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9c3d:	48 85 c0             	test   %rax,%rax
    9c40:	0f 84 6a 09 00 00    	je     a5b0 <fwp_main_thread+0xdb0>
    9c46:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9c4d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9c51:	e9 b6 fd ff ff       	jmp    9a0c <fwp_main_thread+0x20c>
    9c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c5d:	00 00 00 
    9c60:	48 89 01             	mov    %rax,(%rcx)
    9c63:	e9 de fd ff ff       	jmp    9a46 <fwp_main_thread+0x246>
    9c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c6f:	00 
    9c70:	48 83 3d 20 f8 05 00 	cmpq   $0x0,0x5f820(%rip)        # 69498 <fwp_state_len>
    9c77:	00 
    9c78:	0f 84 62 02 00 00    	je     9ee0 <fwp_main_thread+0x6e0>
    9c7e:	48 83 3d 72 db 05 00 	cmpq   $0x0,0x5db72(%rip)        # 677f8 <fwp_root>
    9c85:	00 
    9c86:	c7 05 f0 53 01 00 00 	movl   $0x0,0x153f0(%rip)        # 1f080 <fwp_exit_code>
    9c8d:	00 00 00 
    9c90:	0f 85 76 0a 00 00    	jne    a70c <fwp_main_thread+0xf0c>
    9c96:	e8 85 d9 ff ff       	call   7620 <fwp_free_zombie>
    9c9b:	48 83 3d 45 db 05 00 	cmpq   $0x0,0x5db45(%rip)        # 677e8 <fwp_ready_head>
    9ca2:	00 
    9ca3:	0f 85 82 9a ff ff    	jne    372b <fwp_main_thread.cold>
    9ca9:	48 83 3d 27 db 05 00 	cmpq   $0x0,0x5db27(%rip)        # 677d8 <fwp_timers>
    9cb0:	00 
    9cb1:	0f 85 74 9a ff ff    	jne    372b <fwp_main_thread.cold>
    9cb7:	8b 05 17 d5 05 00    	mov    0x5d517(%rip),%eax        # 671d4 <fwp_stack_pool_n>
    9cbd:	85 c0                	test   %eax,%eax
    9cbf:	74 3c                	je     9cfd <fwp_main_thread+0x4fd>
    9cc1:	83 e8 01             	sub    $0x1,%eax
    9cc4:	4c 8d 25 15 d5 05 00 	lea    0x5d515(%rip),%r12        # 671e0 <fwp_stack_pool>
    9ccb:	48 63 d8             	movslq %eax,%rbx
    9cce:	89 c0                	mov    %eax,%eax
    9cd0:	48 89 da             	mov    %rbx,%rdx
    9cd3:	48 29 c2             	sub    %rax,%rdx
    9cd6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ce0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9ce4:	89 1d ea d4 05 00    	mov    %ebx,0x5d4ea(%rip)        # 671d4 <fwp_stack_pool_n>
    9cea:	be 00 00 00 10       	mov    $0x10000000,%esi
    9cef:	48 83 eb 01          	sub    $0x1,%rbx
    9cf3:	e8 c8 98 ff ff       	call   35c0 <munmap@plt>
    9cf8:	48 39 dd             	cmp    %rbx,%rbp
    9cfb:	75 e3                	jne    9ce0 <fwp_main_thread+0x4e0>
    9cfd:	8b 3d 0d 53 00 00    	mov    0x530d(%rip),%edi        # f010 <fwp_epfd>
    9d03:	85 ff                	test   %edi,%edi
    9d05:	78 05                	js     9d0c <fwp_main_thread+0x50c>
    9d07:	e8 b4 97 ff ff       	call   34c0 <close@plt>
    9d0c:	4c 8b 25 cd d6 05 00 	mov    0x5d6cd(%rip),%r12        # 673e0 <fwp_nfdws>
    9d13:	48 8b 2d ce d6 05 00 	mov    0x5d6ce(%rip),%rbp        # 673e8 <fwp_fdws>
    9d1a:	31 db                	xor    %ebx,%ebx
    9d1c:	c7 05 ea 52 00 00 ff 	movl   $0xffffffff,0x52ea(%rip)        # f010 <fwp_epfd>
    9d23:	ff ff ff 
    9d26:	4d 85 e4             	test   %r12,%r12
    9d29:	74 32                	je     9d5d <fwp_main_thread+0x55d>
    9d2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d30:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9d35:	48 85 ff             	test   %rdi,%rdi
    9d38:	74 1a                	je     9d54 <fwp_main_thread+0x554>
    9d3a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9d3e:	0f 85 e7 99 ff ff    	jne    372b <fwp_main_thread.cold>
    9d44:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9d49:	0f 85 dc 99 ff ff    	jne    372b <fwp_main_thread.cold>
    9d4f:	e8 9c bc ff ff       	call   59f0 <fwp_mem_free>
    9d54:	48 83 c3 01          	add    $0x1,%rbx
    9d58:	49 39 dc             	cmp    %rbx,%r12
    9d5b:	75 d3                	jne    9d30 <fwp_main_thread+0x530>
    9d5d:	48 89 ef             	mov    %rbp,%rdi
    9d60:	e8 8b bc ff ff       	call   59f0 <fwp_mem_free>
    9d65:	48 8b 15 8c da 05 00 	mov    0x5da8c(%rip),%rdx        # 677f8 <fwp_root>
    9d6c:	48 c7 05 71 d6 05 00 	movq   $0x0,0x5d671(%rip)        # 673e8 <fwp_fdws>
    9d73:	00 00 00 00 
    9d77:	48 c7 05 5e d6 05 00 	movq   $0x0,0x5d65e(%rip)        # 673e0 <fwp_nfdws>
    9d7e:	00 00 00 00 
    9d82:	48 85 d2             	test   %rdx,%rdx
    9d85:	74 4e                	je     9dd5 <fwp_main_thread+0x5d5>
    9d87:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9d8c:	0f 85 99 99 ff ff    	jne    372b <fwp_main_thread.cold>
    9d92:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9d99:	00 
    9d9a:	0f 85 8b 99 ff ff    	jne    372b <fwp_main_thread.cold>
    9da0:	48 83 3d f0 f6 05 00 	cmpq   $0x0,0x5f6f0(%rip)        # 69498 <fwp_state_len>
    9da7:	00 
    9da8:	0f 85 7d 99 ff ff    	jne    372b <fwp_main_thread.cold>
    9dae:	48 83 3d d2 f6 05 00 	cmpq   $0x0,0x5f6d2(%rip)        # 69488 <fwp_state_owners>
    9db5:	00 
    9db6:	0f 85 6f 99 ff ff    	jne    372b <fwp_main_thread.cold>
    9dbc:	b9 79 00 00 00       	mov    $0x79,%ecx
    9dc1:	31 c0                	xor    %eax,%eax
    9dc3:	48 8d 3d 36 d6 05 00 	lea    0x5d636(%rip),%rdi        # 67400 <fwp_root_context>
    9dca:	f3 48 ab             	rep stos %rax,(%rdi)
    9dcd:	48 89 d7             	mov    %rdx,%rdi
    9dd0:	e8 1b bc ff ff       	call   59f0 <fwp_mem_free>
    9dd5:	66 0f 6f 05 d3 53 04 	movdqa 0x453d3(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    9ddc:	00 
    9ddd:	66 0f d4 05 bb 53 04 	paddq  0x453bb(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    9de4:	00 
    9de5:	48 c7 05 10 da 05 00 	movq   $0x0,0x5da10(%rip)        # 67800 <fwp_cur>
    9dec:	00 00 00 00 
    9df0:	48 8b 05 49 ee 05 00 	mov    0x5ee49(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9df7:	48 c7 05 f6 d9 05 00 	movq   $0x0,0x5d9f6(%rip)        # 677f8 <fwp_root>
    9dfe:	00 00 00 00 
    9e02:	c7 05 dc f6 05 00 00 	movl   $0x0,0x5f6dc(%rip)        # 694e8 <iteration_active>
    9e09:	00 00 00 
    9e0c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9e10:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9e15:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9e19:	66 0f d6 05 d7 52 01 	movq   %xmm0,0x152d7(%rip)        # 1f0f8 <ad_raw_before_shutdown>
    9e20:	00 
    9e21:	48 85 c0             	test   %rax,%rax
    9e24:	0f 88 46 01 00 00    	js     9f70 <fwp_main_thread+0x770>
    9e2a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9e2e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9e33:	f2 0f 5c 0d 8d f6 05 	subsd  0x5f68d(%rip),%xmm1        # 694c8 <iteration_start_charge>
    9e3a:	00 
    9e3b:	48 8b 3d fe 51 00 00 	mov    0x51fe(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    9e42:	48 8d 15 57 1c 00 00 	lea    0x1c57(%rip),%rdx        # baa0 <_IO_stdin_used+0xaa0>
    9e49:	be 02 00 00 00       	mov    $0x2,%esi
    9e4e:	f2 0f 10 05 6a f6 05 	movsd  0x5f66a(%rip),%xmm0        # 694c0 <iteration_peak>
    9e55:	00 
    9e56:	4c 8b 0d 73 f6 05 00 	mov    0x5f673(%rip),%r9        # 694d0 <iteration_retains>
    9e5d:	b8 02 00 00 00       	mov    $0x2,%eax
    9e62:	4c 8b 05 6f f6 05 00 	mov    0x5f66f(%rip),%r8        # 694d8 <iteration_bytes>
    9e69:	48 8b 0d 70 f6 05 00 	mov    0x5f670(%rip),%rcx        # 694e0 <iteration_requests>
    9e70:	e8 fb 97 ff ff       	call   3670 <__fprintf_chk@plt>
    9e75:	48 8b 3d a4 51 00 00 	mov    0x51a4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    9e7c:	e8 1f 97 ff ff       	call   35a0 <fflush@plt>
    9e81:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9e88:	00 
    9e89:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e90:	00 00 
    9e92:	0f 85 57 08 00 00    	jne    a6ef <fwp_main_thread+0xeef>
    9e98:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9e9f:	31 c0                	xor    %eax,%eax
    9ea1:	5b                   	pop    %rbx
    9ea2:	5d                   	pop    %rbp
    9ea3:	41 5c                	pop    %r12
    9ea5:	41 5d                	pop    %r13
    9ea7:	41 5e                	pop    %r14
    9ea9:	41 5f                	pop    %r15
    9eab:	c3                   	ret
    9eac:	0f 1f 40 00          	nopl   0x0(%rax)
    9eb0:	48 89 05 21 d9 05 00 	mov    %rax,0x5d921(%rip)        # 677d8 <fwp_timers>
    9eb7:	e9 db fb ff ff       	jmp    9a97 <fwp_main_thread+0x297>
    9ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ec0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9ec4:	0f 85 d6 fc ff ff    	jne    9ba0 <fwp_main_thread+0x3a0>
    9eca:	48 89 ef             	mov    %rbp,%rdi
    9ecd:	e8 3e a2 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    9ed2:	e9 c9 fc ff ff       	jmp    9ba0 <fwp_main_thread+0x3a0>
    9ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ede:	00 00 
    9ee0:	31 db                	xor    %ebx,%ebx
    9ee2:	48 83 3d 9e f5 05 00 	cmpq   $0x0,0x5f59e(%rip)        # 69488 <fwp_state_owners>
    9ee9:	00 
    9eea:	0f 85 e2 fb ff ff    	jne    9ad2 <fwp_main_thread+0x2d2>
    9ef0:	48 8b 3d a9 f5 05 00 	mov    0x5f5a9(%rip),%rdi        # 694a0 <fwp_state>
    9ef7:	e8 f4 ba ff ff       	call   59f0 <fwp_mem_free>
    9efc:	48 c7 05 99 f5 05 00 	movq   $0x0,0x5f599(%rip)        # 694a0 <fwp_state>
    9f03:	00 00 00 00 
    9f07:	48 c7 05 7e f5 05 00 	movq   $0x0,0x5f57e(%rip)        # 69490 <fwp_state_cap>
    9f0e:	00 00 00 00 
    9f12:	48 85 db             	test   %rbx,%rbx
    9f15:	0f 84 6f 07 00 00    	je     a68a <fwp_main_thread+0xe8a>
    9f1b:	48 3b 1d d6 d8 05 00 	cmp    0x5d8d6(%rip),%rbx        # 677f8 <fwp_root>
    9f22:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9f29:	00 00 00 00 
    9f2d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9f34:	00 00 00 00 
    9f38:	c7 05 3e 51 01 00 00 	movl   $0x0,0x1513e(%rip)        # 1f080 <fwp_exit_code>
    9f3f:	00 00 00 
    9f42:	0f 84 aa fb ff ff    	je     9af2 <fwp_main_thread+0x2f2>
    9f48:	e9 de 97 ff ff       	jmp    372b <fwp_main_thread.cold>
    9f4d:	0f 1f 00             	nopl   (%rax)
    9f50:	48 89 c2             	mov    %rax,%rdx
    9f53:	83 e0 01             	and    $0x1,%eax
    9f56:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9f5a:	48 d1 ea             	shr    $1,%rdx
    9f5d:	48 09 c2             	or     %rax,%rdx
    9f60:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9f65:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9f69:	e9 b6 f9 ff ff       	jmp    9924 <fwp_main_thread+0x124>
    9f6e:	66 90                	xchg   %ax,%ax
    9f70:	48 89 c2             	mov    %rax,%rdx
    9f73:	83 e0 01             	and    $0x1,%eax
    9f76:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9f7a:	48 d1 ea             	shr    $1,%rdx
    9f7d:	48 09 c2             	or     %rax,%rdx
    9f80:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9f85:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9f89:	e9 a5 fe ff ff       	jmp    9e33 <fwp_main_thread+0x633>
    9f8e:	66 90                	xchg   %ax,%ax
    9f90:	48 8d 3d 09 ad ff ff 	lea    -0x52f7(%rip),%rdi        # 4ca0 <fwp_heap_report>
    9f97:	e8 94 09 00 00       	call   a930 <atexit>
    9f9c:	e9 a3 f8 ff ff       	jmp    9844 <fwp_main_thread+0x44>
    9fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9fa8:	e8 03 ae ff ff       	call   4db0 <fwp_heap_init>
    9fad:	e9 84 f8 ff ff       	jmp    9836 <fwp_main_thread+0x36>
    9fb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fb8:	48 8d 05 d1 de ff ff 	lea    -0x212f(%rip),%rax        # 7e90 <fwp_drop1>
    9fbf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9fc3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    9fca:	00 00 
    9fcc:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9fd2:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9fd7:	48 8b 05 da f4 05 00 	mov    0x5f4da(%rip),%rax        # 694b8 <fwp_cleanups>
    9fde:	4c 8d 3d 3b d8 05 00 	lea    0x5d83b(%rip),%r15        # 67820 <fwp_heap>
    9fe5:	48 89 2d cc f4 05 00 	mov    %rbp,0x5f4cc(%rip)        # 694b8 <fwp_cleanups>
    9fec:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9ff0:	31 ed                	xor    %ebp,%ebp
    9ff2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9ff7:	48 8d 05 b2 9b ff ff 	lea    -0x644e(%rip),%rax        # 3bb0 <fwp_range_release>
    9ffe:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a003:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    a008:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    a00d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a012:	eb 3d                	jmp    a051 <fwp_main_thread+0x851>
    a014:	0f 1f 40 00          	nopl   0x0(%rax)
    a018:	80 f9 01             	cmp    $0x1,%cl
    a01b:	75 29                	jne    a046 <fwp_main_thread+0x846>
    a01d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a020:	0f b7 c0             	movzwl %ax,%eax
    a023:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a026:	48 0f af c1          	imul   %rcx,%rax
    a02a:	48 c1 e8 20          	shr    $0x20,%rax
    a02e:	48 39 d0             	cmp    %rdx,%rax
    a031:	73 13                	jae    a046 <fwp_main_thread+0x846>
    a033:	49 01 c5             	add    %rax,%r13
    a036:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a03b:	0f 84 af 05 00 00    	je     a5f0 <fwp_main_thread+0xdf0>
    a041:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a046:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    a04b:	49 83 ec 01          	sub    $0x1,%r12
    a04f:	72 7f                	jb     a0d0 <fwp_main_thread+0x8d0>
    a051:	48 89 de             	mov    %rbx,%rsi
    a054:	bf 01 00 00 00       	mov    $0x1,%edi
    a059:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    a060:	00 
    a061:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    a066:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    a06d:	00 
    a06e:	e8 6d c0 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a073:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a07a:	48 89 c5             	mov    %rax,%rbp
    a07d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a084:	48 c1 e2 10          	shl    $0x10,%rdx
    a088:	48 39 d0             	cmp    %rdx,%rax
    a08b:	73 b9                	jae    a046 <fwp_main_thread+0x846>
    a08d:	48 89 c2             	mov    %rax,%rdx
    a090:	48 c1 ea 10          	shr    $0x10,%rdx
    a094:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a098:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a09f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a0a3:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a0a7:	4d 85 ed             	test   %r13,%r13
    a0aa:	74 9a                	je     a046 <fwp_main_thread+0x846>
    a0ac:	0f b6 0a             	movzbl (%rdx),%ecx
    a0af:	80 f9 02             	cmp    $0x2,%cl
    a0b2:	0f 85 60 ff ff ff    	jne    a018 <fwp_main_thread+0x818>
    a0b8:	66 85 c0             	test   %ax,%ax
    a0bb:	0f 84 75 ff ff ff    	je     a036 <fwp_main_thread+0x836>
    a0c1:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    a0c6:	49 83 ec 01          	sub    $0x1,%r12
    a0ca:	73 85                	jae    a051 <fwp_main_thread+0x851>
    a0cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a0d0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a0d5:	66 0f 6f 05 33 1c 00 	movdqa 0x1c33(%rip),%xmm0        # bd10 <msg.4+0xa0>
    a0dc:	00 
    a0dd:	48 89 de             	mov    %rbx,%rsi
    a0e0:	bf 01 00 00 00       	mov    $0x1,%edi
    a0e5:	48 89 05 cc f3 05 00 	mov    %rax,0x5f3cc(%rip)        # 694b8 <fwp_cleanups>
    a0ec:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    a0f3:	00 
    a0f4:	e8 e7 bf ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a0f9:	48 8b 15 f8 ea 05 00 	mov    0x5eaf8(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a100:	49 89 c4             	mov    %rax,%r12
    a103:	48 2b 05 c6 ea 05 00 	sub    0x5eac6(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    a10a:	48 c1 e2 10          	shl    $0x10,%rdx
    a10e:	48 39 d0             	cmp    %rdx,%rax
    a111:	73 55                	jae    a168 <fwp_main_thread+0x968>
    a113:	48 89 c2             	mov    %rax,%rdx
    a116:	48 c1 ea 10          	shr    $0x10,%rdx
    a11a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a11e:	48 8b 15 f3 ea 05 00 	mov    0x5eaf3(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    a125:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a129:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a12d:	48 85 db             	test   %rbx,%rbx
    a130:	74 36                	je     a168 <fwp_main_thread+0x968>
    a132:	0f b6 0a             	movzbl (%rdx),%ecx
    a135:	80 f9 02             	cmp    $0x2,%cl
    a138:	0f 84 a2 04 00 00    	je     a5e0 <fwp_main_thread+0xde0>
    a13e:	80 f9 01             	cmp    $0x1,%cl
    a141:	75 25                	jne    a168 <fwp_main_thread+0x968>
    a143:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a146:	0f b7 c0             	movzwl %ax,%eax
    a149:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a14c:	48 0f af c1          	imul   %rcx,%rax
    a150:	48 c1 e8 20          	shr    $0x20,%rax
    a154:	48 39 d0             	cmp    %rdx,%rax
    a157:	73 0f                	jae    a168 <fwp_main_thread+0x968>
    a159:	48 01 c3             	add    %rax,%rbx
    a15c:	80 3b ff             	cmpb   $0xff,(%rbx)
    a15f:	0f 84 4b 05 00 00    	je     a6b0 <fwp_main_thread+0xeb0>
    a165:	c6 03 01             	movb   $0x1,(%rbx)
    a168:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    a16d:	bf 01 00 00 00       	mov    $0x1,%edi
    a172:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    a177:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a17e:	00 f0 3f 
    a181:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    a186:	e8 55 bf ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a18b:	48 8b 15 66 ea 05 00 	mov    0x5ea66(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a192:	49 89 c4             	mov    %rax,%r12
    a195:	48 2b 05 34 ea 05 00 	sub    0x5ea34(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    a19c:	48 c1 e2 10          	shl    $0x10,%rdx
    a1a0:	48 39 d0             	cmp    %rdx,%rax
    a1a3:	73 55                	jae    a1fa <fwp_main_thread+0x9fa>
    a1a5:	48 89 c2             	mov    %rax,%rdx
    a1a8:	48 c1 ea 10          	shr    $0x10,%rdx
    a1ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1b0:	48 8b 15 61 ea 05 00 	mov    0x5ea61(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    a1b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1bb:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a1bf:	48 85 db             	test   %rbx,%rbx
    a1c2:	74 36                	je     a1fa <fwp_main_thread+0x9fa>
    a1c4:	0f b6 0a             	movzbl (%rdx),%ecx
    a1c7:	80 f9 02             	cmp    $0x2,%cl
    a1ca:	0f 84 00 04 00 00    	je     a5d0 <fwp_main_thread+0xdd0>
    a1d0:	80 f9 01             	cmp    $0x1,%cl
    a1d3:	75 25                	jne    a1fa <fwp_main_thread+0x9fa>
    a1d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1d8:	0f b7 c0             	movzwl %ax,%eax
    a1db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1de:	48 0f af c1          	imul   %rcx,%rax
    a1e2:	48 c1 e8 20          	shr    $0x20,%rax
    a1e6:	48 39 d0             	cmp    %rdx,%rax
    a1e9:	73 0f                	jae    a1fa <fwp_main_thread+0x9fa>
    a1eb:	48 01 c3             	add    %rax,%rbx
    a1ee:	80 3b ff             	cmpb   $0xff,(%rbx)
    a1f1:	0f 84 c6 04 00 00    	je     a6bd <fwp_main_thread+0xebd>
    a1f7:	c6 03 01             	movb   $0x1,(%rbx)
    a1fa:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    a1ff:	bf 01 00 00 00       	mov    $0x1,%edi
    a204:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    a209:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a210:	33 f3 bf 
    a213:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a218:	e8 c3 be ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a21d:	48 8b 15 d4 e9 05 00 	mov    0x5e9d4(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a224:	48 8b 0d a5 e9 05 00 	mov    0x5e9a5(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a22b:	49 89 c4             	mov    %rax,%r12
    a22e:	48 89 d6             	mov    %rdx,%rsi
    a231:	48 29 c8             	sub    %rcx,%rax
    a234:	48 c1 e6 10          	shl    $0x10,%rsi
    a238:	48 39 f0             	cmp    %rsi,%rax
    a23b:	73 65                	jae    a2a2 <fwp_main_thread+0xaa2>
    a23d:	48 89 c6             	mov    %rax,%rsi
    a240:	48 c1 ee 10          	shr    $0x10,%rsi
    a244:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a248:	48 8b 35 c9 e9 05 00 	mov    0x5e9c9(%rip),%rsi        # 68c18 <fwp_heap+0x13f8>
    a24f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a253:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a257:	48 85 db             	test   %rbx,%rbx
    a25a:	74 46                	je     a2a2 <fwp_main_thread+0xaa2>
    a25c:	0f b6 3e             	movzbl (%rsi),%edi
    a25f:	40 80 ff 02          	cmp    $0x2,%dil
    a263:	0f 84 57 03 00 00    	je     a5c0 <fwp_main_thread+0xdc0>
    a269:	40 80 ff 01          	cmp    $0x1,%dil
    a26d:	75 33                	jne    a2a2 <fwp_main_thread+0xaa2>
    a26f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a272:	0f b7 c0             	movzwl %ax,%eax
    a275:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a278:	48 0f af c7          	imul   %rdi,%rax
    a27c:	48 c1 e8 20          	shr    $0x20,%rax
    a280:	48 39 f0             	cmp    %rsi,%rax
    a283:	73 1d                	jae    a2a2 <fwp_main_thread+0xaa2>
    a285:	48 01 c3             	add    %rax,%rbx
    a288:	80 3b ff             	cmpb   $0xff,(%rbx)
    a28b:	0f 84 39 04 00 00    	je     a6ca <fwp_main_thread+0xeca>
    a291:	c6 03 01             	movb   $0x1,(%rbx)
    a294:	48 8b 0d 35 e9 05 00 	mov    0x5e935(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a29b:	48 8b 15 56 e9 05 00 	mov    0x5e956(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a2a2:	49 89 ed             	mov    %rbp,%r13
    a2a5:	e9 13 02 00 00       	jmp    a4bd <fwp_main_thread+0xcbd>
    a2aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2b0:	80 f9 01             	cmp    $0x1,%cl
    a2b3:	75 3f                	jne    a2f4 <fwp_main_thread+0xaf4>
    a2b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a2b8:	0f b7 c0             	movzwl %ax,%eax
    a2bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a2be:	48 0f af c1          	imul   %rcx,%rax
    a2c2:	48 c1 e8 20          	shr    $0x20,%rax
    a2c6:	48 39 d0             	cmp    %rdx,%rax
    a2c9:	73 29                	jae    a2f4 <fwp_main_thread+0xaf4>
    a2cb:	48 01 c7             	add    %rax,%rdi
    a2ce:	0f b6 07             	movzbl (%rdi),%eax
    a2d1:	84 c0                	test   %al,%al
    a2d3:	74 1f                	je     a2f4 <fwp_main_thread+0xaf4>
    a2d5:	8b 15 0d f2 05 00    	mov    0x5f20d(%rip),%edx        # 694e8 <iteration_active>
    a2db:	85 d2                	test   %edx,%edx
    a2dd:	74 08                	je     a2e7 <fwp_main_thread+0xae7>
    a2df:	48 83 05 e9 f1 05 00 	addq   $0x1,0x5f1e9(%rip)        # 694d0 <iteration_retains>
    a2e6:	01 
    a2e7:	3c fd                	cmp    $0xfd,%al
    a2e9:	0f 87 91 03 00 00    	ja     a680 <fwp_main_thread+0xe80>
    a2ef:	83 c0 01             	add    $0x1,%eax
    a2f2:	88 07                	mov    %al,(%rdi)
    a2f4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a2f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a2fd:	b9 01 00 00 00       	mov    $0x1,%ecx
    a302:	4c 89 e6             	mov    %r12,%rsi
    a305:	48 8d 15 94 48 00 00 	lea    0x4894(%rip),%rdx        # eba0 <d0>
    a30c:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a311:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a318:	00 00 
    a31a:	e8 a1 e4 ff ff       	call   87c0 <fwp_write>
    a31f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a324:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a329:	48 8d 05 3c 0d 00 00 	lea    0xd3c(%rip),%rax        # b06c <_IO_stdin_used+0x6c>
    a330:	48 85 c9             	test   %rcx,%rcx
    a333:	48 0f 44 c8          	cmove  %rax,%rcx
    a337:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a33b:	0f 87 a2 03 00 00    	ja     a6e3 <fwp_main_thread+0xee3>
    a341:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a345:	be 01 00 00 00       	mov    $0x1,%esi
    a34a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a34f:	e8 9c bb ff ff       	call   5ef0 <fwp_heap_alloc>
    a354:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a359:	4c 89 f2             	mov    %r14,%rdx
    a35c:	4c 89 30             	mov    %r14,(%rax)
    a35f:	48 89 c3             	mov    %rax,%rbx
    a362:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a366:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a36b:	e8 10 92 ff ff       	call   3580 <memcpy@plt>
    a370:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a376:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a37b:	e8 30 90 ff ff       	call   33b0 <free@plt>
    a380:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a387:	48 89 d8             	mov    %rbx,%rax
    a38a:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a391:	48 c1 e2 10          	shl    $0x10,%rdx
    a395:	48 39 d0             	cmp    %rdx,%rax
    a398:	73 55                	jae    a3ef <fwp_main_thread+0xbef>
    a39a:	48 89 c2             	mov    %rax,%rdx
    a39d:	48 c1 ea 10          	shr    $0x10,%rdx
    a3a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3a5:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a3ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3b0:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a3b4:	48 85 f6             	test   %rsi,%rsi
    a3b7:	74 36                	je     a3ef <fwp_main_thread+0xbef>
    a3b9:	0f b6 0a             	movzbl (%rdx),%ecx
    a3bc:	80 f9 02             	cmp    $0x2,%cl
    a3bf:	0f 84 4b 01 00 00    	je     a510 <fwp_main_thread+0xd10>
    a3c5:	80 f9 01             	cmp    $0x1,%cl
    a3c8:	75 25                	jne    a3ef <fwp_main_thread+0xbef>
    a3ca:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a3cd:	0f b7 c0             	movzwl %ax,%eax
    a3d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a3d3:	48 0f af c1          	imul   %rcx,%rax
    a3d7:	48 c1 e8 20          	shr    $0x20,%rax
    a3db:	48 39 d0             	cmp    %rdx,%rax
    a3de:	73 0f                	jae    a3ef <fwp_main_thread+0xbef>
    a3e0:	48 01 c6             	add    %rax,%rsi
    a3e3:	80 3e ff             	cmpb   $0xff,(%rsi)
    a3e6:	0f 84 44 01 00 00    	je     a530 <fwp_main_thread+0xd30>
    a3ec:	c6 06 01             	movb   $0x1,(%rsi)
    a3ef:	4c 89 e7             	mov    %r12,%rdi
    a3f2:	e8 a9 d8 ff ff       	call   7ca0 <fwp_drop0>
    a3f7:	48 8b 13             	mov    (%rbx),%rdx
    a3fa:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a3ff:	be 01 00 00 00       	mov    $0x1,%esi
    a404:	48 8b 0d 75 f0 05 00 	mov    0x5f075(%rip),%rcx        # 69480 <fwp_prog_out>
    a40b:	e8 50 92 ff ff       	call   3660 <fwrite@plt>
    a410:	48 8b 35 69 f0 05 00 	mov    0x5f069(%rip),%rsi        # 69480 <fwp_prog_out>
    a417:	bf 0a 00 00 00       	mov    $0xa,%edi
    a41c:	e8 af 90 ff ff       	call   34d0 <fputc@plt>
    a421:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a428:	48 89 d8             	mov    %rbx,%rax
    a42b:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a432:	48 c1 e2 10          	shl    $0x10,%rdx
    a436:	48 39 d0             	cmp    %rdx,%rax
    a439:	73 67                	jae    a4a2 <fwp_main_thread+0xca2>
    a43b:	48 89 c2             	mov    %rax,%rdx
    a43e:	48 c1 ea 10          	shr    $0x10,%rdx
    a442:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a446:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a44d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a451:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a455:	4d 85 f6             	test   %r14,%r14
    a458:	74 48                	je     a4a2 <fwp_main_thread+0xca2>
    a45a:	0f b6 0a             	movzbl (%rdx),%ecx
    a45d:	80 f9 02             	cmp    $0x2,%cl
    a460:	0f 84 ea 00 00 00    	je     a550 <fwp_main_thread+0xd50>
    a466:	80 f9 01             	cmp    $0x1,%cl
    a469:	75 37                	jne    a4a2 <fwp_main_thread+0xca2>
    a46b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a46e:	0f b7 c0             	movzwl %ax,%eax
    a471:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a474:	48 0f af c1          	imul   %rcx,%rax
    a478:	48 c1 e8 20          	shr    $0x20,%rax
    a47c:	48 39 d0             	cmp    %rdx,%rax
    a47f:	73 21                	jae    a4a2 <fwp_main_thread+0xca2>
    a481:	49 01 c6             	add    %rax,%r14
    a484:	41 0f b6 06          	movzbl (%r14),%eax
    a488:	84 c0                	test   %al,%al
    a48a:	74 16                	je     a4a2 <fwp_main_thread+0xca2>
    a48c:	3c 01                	cmp    $0x1,%al
    a48e:	0f 84 0c 01 00 00    	je     a5a0 <fwp_main_thread+0xda0>
    a494:	3c ff                	cmp    $0xff,%al
    a496:	0f 84 64 01 00 00    	je     a600 <fwp_main_thread+0xe00>
    a49c:	83 e8 01             	sub    $0x1,%eax
    a49f:	41 88 06             	mov    %al,(%r14)
    a4a2:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a4a6:	4d 85 ed             	test   %r13,%r13
    a4a9:	0f 84 c1 00 00 00    	je     a570 <fwp_main_thread+0xd70>
    a4af:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a4b6:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a4bd:	4c 89 e0             	mov    %r12,%rax
    a4c0:	48 c1 e2 10          	shl    $0x10,%rdx
    a4c4:	48 29 c8             	sub    %rcx,%rax
    a4c7:	48 39 d0             	cmp    %rdx,%rax
    a4ca:	0f 83 24 fe ff ff    	jae    a2f4 <fwp_main_thread+0xaf4>
    a4d0:	48 89 c2             	mov    %rax,%rdx
    a4d3:	48 c1 ea 10          	shr    $0x10,%rdx
    a4d7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a4db:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a4e2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4e6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a4ea:	48 85 ff             	test   %rdi,%rdi
    a4ed:	0f 84 01 fe ff ff    	je     a2f4 <fwp_main_thread+0xaf4>
    a4f3:	0f b6 0a             	movzbl (%rdx),%ecx
    a4f6:	80 f9 02             	cmp    $0x2,%cl
    a4f9:	0f 85 b1 fd ff ff    	jne    a2b0 <fwp_main_thread+0xab0>
    a4ff:	66 85 c0             	test   %ax,%ax
    a502:	0f 85 ec fd ff ff    	jne    a2f4 <fwp_main_thread+0xaf4>
    a508:	e9 c1 fd ff ff       	jmp    a2ce <fwp_main_thread+0xace>
    a50d:	0f 1f 00             	nopl   (%rax)
    a510:	66 85 c0             	test   %ax,%ax
    a513:	0f 85 d6 fe ff ff    	jne    a3ef <fwp_main_thread+0xbef>
    a519:	80 3e ff             	cmpb   $0xff,(%rsi)
    a51c:	0f 85 ca fe ff ff    	jne    a3ec <fwp_main_thread+0xbec>
    a522:	0f 1f 00             	nopl   (%rax)
    a525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a52c:	00 00 00 00 
    a530:	48 89 f7             	mov    %rsi,%rdi
    a533:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a538:	e8 73 b2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a53d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a542:	e9 a5 fe ff ff       	jmp    a3ec <fwp_main_thread+0xbec>
    a547:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a54e:	00 00 
    a550:	66 85 c0             	test   %ax,%ax
    a553:	0f 84 2b ff ff ff    	je     a484 <fwp_main_thread+0xc84>
    a559:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a55d:	4d 85 ed             	test   %r13,%r13
    a560:	0f 85 49 ff ff ff    	jne    a4af <fwp_main_thread+0xcaf>
    a566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a56d:	00 00 00 
    a570:	4c 89 e7             	mov    %r12,%rdi
    a573:	e8 28 d7 ff ff       	call   7ca0 <fwp_drop0>
    a578:	48 89 ef             	mov    %rbp,%rdi
    a57b:	e8 20 d7 ff ff       	call   7ca0 <fwp_drop0>
    a580:	48 c7 05 d5 4a 00 00 	movq   $0x0,0x4ad5(%rip)        # f060 <v.2>
    a587:	00 00 00 00 
    a58b:	c7 05 d3 4a 00 00 01 	movl   $0x1,0x4ad3(%rip)        # f068 <st.3>
    a592:	00 00 00 
    a595:	e9 be f3 ff ff       	jmp    9958 <fwp_main_thread+0x158>
    a59a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5a0:	48 89 df             	mov    %rbx,%rdi
    a5a3:	e8 48 b4 ff ff       	call   59f0 <fwp_mem_free>
    a5a8:	e9 f5 fe ff ff       	jmp    a4a2 <fwp_main_thread+0xca2>
    a5ad:	0f 1f 00             	nopl   (%rax)
    a5b0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a5b4:	e9 53 f4 ff ff       	jmp    9a0c <fwp_main_thread+0x20c>
    a5b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a5c0:	66 85 c0             	test   %ax,%ax
    a5c3:	0f 85 d9 fc ff ff    	jne    a2a2 <fwp_main_thread+0xaa2>
    a5c9:	e9 ba fc ff ff       	jmp    a288 <fwp_main_thread+0xa88>
    a5ce:	66 90                	xchg   %ax,%ax
    a5d0:	66 85 c0             	test   %ax,%ax
    a5d3:	0f 85 21 fc ff ff    	jne    a1fa <fwp_main_thread+0x9fa>
    a5d9:	e9 10 fc ff ff       	jmp    a1ee <fwp_main_thread+0x9ee>
    a5de:	66 90                	xchg   %ax,%ax
    a5e0:	66 85 c0             	test   %ax,%ax
    a5e3:	0f 85 7f fb ff ff    	jne    a168 <fwp_main_thread+0x968>
    a5e9:	e9 6e fb ff ff       	jmp    a15c <fwp_main_thread+0x95c>
    a5ee:	66 90                	xchg   %ax,%ax
    a5f0:	4c 89 ef             	mov    %r13,%rdi
    a5f3:	e8 b8 b1 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a5f8:	e9 44 fa ff ff       	jmp    a041 <fwp_main_thread+0x841>
    a5fd:	0f 1f 00             	nopl   (%rax)
    a600:	4c 89 f0             	mov    %r14,%rax
    a603:	48 c1 e8 11          	shr    $0x11,%rax
    a607:	4c 31 f0             	xor    %r14,%rax
    a60a:	48 89 c2             	mov    %rax,%rdx
    a60d:	48 c1 ea 09          	shr    $0x9,%rdx
    a611:	48 31 d0             	xor    %rdx,%rax
    a614:	0f b6 d0             	movzbl %al,%edx
    a617:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a61e:	00 
    a61f:	48 85 c0             	test   %rax,%rax
    a622:	75 29                	jne    a64d <fwp_main_thread+0xe4d>
    a624:	e9 d7 00 00 00       	jmp    a700 <fwp_main_thread+0xf00>
    a629:	90                   	nop
    a62a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a631:	00 00 00 00 
    a635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a63c:	00 00 00 00 
    a640:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a644:	48 85 c0             	test   %rax,%rax
    a647:	0f 84 b3 00 00 00    	je     a700 <fwp_main_thread+0xf00>
    a64d:	48 89 c2             	mov    %rax,%rdx
    a650:	4c 3b 30             	cmp    (%rax),%r14
    a653:	75 eb                	jne    a640 <fwp_main_thread+0xe40>
    a655:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a659:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a65d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a661:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a668:	0f 85 34 fe ff ff    	jne    a4a2 <fwp_main_thread+0xca2>
    a66e:	4c 89 f7             	mov    %r14,%rdi
    a671:	e8 3a b1 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a676:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a67a:	e9 23 fe ff ff       	jmp    a4a2 <fwp_main_thread+0xca2>
    a67f:	90                   	nop
    a680:	e8 0b b0 ff ff       	call   5690 <fwp_rc_wide_dup>
    a685:	e9 6a fc ff ff       	jmp    a2f4 <fwp_main_thread+0xaf4>
    a68a:	48 83 3d 66 d1 05 00 	cmpq   $0x0,0x5d166(%rip)        # 677f8 <fwp_root>
    a691:	00 
    a692:	c7 05 e4 49 01 00 00 	movl   $0x0,0x149e4(%rip)        # 1f080 <fwp_exit_code>
    a699:	00 00 00 
    a69c:	0f 84 f4 f5 ff ff    	je     9c96 <fwp_main_thread+0x496>
    a6a2:	e9 84 90 ff ff       	jmp    372b <fwp_main_thread.cold>
    a6a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a6ae:	00 00 
    a6b0:	48 89 df             	mov    %rbx,%rdi
    a6b3:	e8 f8 b0 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a6b8:	e9 a8 fa ff ff       	jmp    a165 <fwp_main_thread+0x965>
    a6bd:	48 89 df             	mov    %rbx,%rdi
    a6c0:	e8 eb b0 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a6c5:	e9 2d fb ff ff       	jmp    a1f7 <fwp_main_thread+0x9f7>
    a6ca:	48 89 df             	mov    %rbx,%rdi
    a6cd:	e8 de b0 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a6d2:	e9 ba fb ff ff       	jmp    a291 <fwp_main_thread+0xa91>
    a6d7:	48 8d 3d 9a 13 00 00 	lea    0x139a(%rip),%rdi        # ba78 <_IO_stdin_used+0xa78>
    a6de:	e8 4d 9d ff ff       	call   4430 <fwp_trap>
    a6e3:	48 8d 3d ad 0b 00 00 	lea    0xbad(%rip),%rdi        # b297 <_IO_stdin_used+0x297>
    a6ea:	e8 41 9d ff ff       	call   4430 <fwp_trap>
    a6ef:	e8 5c 8d ff ff       	call   3450 <__stack_chk_fail@plt>
    a6f4:	48 8d 3d 81 0b 00 00 	lea    0xb81(%rip),%rdi        # b27c <_IO_stdin_used+0x27c>
    a6fb:	e8 e0 98 ff ff       	call   3fe0 <ad_raw_fail>
    a700:	48 8d 3d a1 12 00 00 	lea    0x12a1(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    a707:	e8 24 9d ff ff       	call   4430 <fwp_trap>
    a70c:	e9 1a 90 ff ff       	jmp    372b <fwp_main_thread.cold>
    a711:	e9 15 90 ff ff       	jmp    372b <fwp_main_thread.cold>
    a716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a71d:	00 00 00 

000000000000a720 <__divmodti4>:
    a720:	f3 0f 1e fa          	endbr64
    a724:	55                   	push   %rbp
    a725:	49 89 f1             	mov    %rsi,%r9
    a728:	49 89 d2             	mov    %rdx,%r10
    a72b:	48 89 fe             	mov    %rdi,%rsi
    a72e:	49 89 cb             	mov    %rcx,%r11
    a731:	48 89 e5             	mov    %rsp,%rbp
    a734:	41 57                	push   %r15
    a736:	41 56                	push   %r14
    a738:	41 55                	push   %r13
    a73a:	41 54                	push   %r12
    a73c:	53                   	push   %rbx
    a73d:	4c 89 c3             	mov    %r8,%rbx
    a740:	45 31 c0             	xor    %r8d,%r8d
    a743:	4d 85 c9             	test   %r9,%r9
    a746:	79 12                	jns    a75a <__divmodti4+0x3a>
    a748:	31 ff                	xor    %edi,%edi
    a74a:	48 f7 de             	neg    %rsi
    a74d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a754:	4c 19 cf             	sbb    %r9,%rdi
    a757:	49 89 f9             	mov    %rdi,%r9
    a75a:	4c 89 d8             	mov    %r11,%rax
    a75d:	4d 85 db             	test   %r11,%r11
    a760:	0f 88 1a 01 00 00    	js     a880 <__divmodti4+0x160>
    a766:	4c 89 d9             	mov    %r11,%rcx
    a769:	49 89 f3             	mov    %rsi,%r11
    a76c:	75 62                	jne    a7d0 <__divmodti4+0xb0>
    a76e:	4d 89 c4             	mov    %r8,%r12
    a771:	4d 39 d1             	cmp    %r10,%r9
    a774:	0f 83 46 01 00 00    	jae    a8c0 <__divmodti4+0x1a0>
    a77a:	4c 89 d8             	mov    %r11,%rax
    a77d:	4c 89 ca             	mov    %r9,%rdx
    a780:	49 f7 f2             	div    %r10
    a783:	49 89 c3             	mov    %rax,%r11
    a786:	31 c0                	xor    %eax,%eax
    a788:	48 89 d6             	mov    %rdx,%rsi
    a78b:	31 ff                	xor    %edi,%edi
    a78d:	4c 89 d9             	mov    %r11,%rcx
    a790:	48 89 c2             	mov    %rax,%rdx
    a793:	48 89 c8             	mov    %rcx,%rax
    a796:	4d 85 e4             	test   %r12,%r12
    a799:	74 0a                	je     a7a5 <__divmodti4+0x85>
    a79b:	48 f7 d8             	neg    %rax
    a79e:	48 83 d2 00          	adc    $0x0,%rdx
    a7a2:	48 f7 da             	neg    %rdx
    a7a5:	4d 85 c0             	test   %r8,%r8
    a7a8:	74 0a                	je     a7b4 <__divmodti4+0x94>
    a7aa:	48 f7 de             	neg    %rsi
    a7ad:	48 83 d7 00          	adc    $0x0,%rdi
    a7b1:	48 f7 df             	neg    %rdi
    a7b4:	48 89 33             	mov    %rsi,(%rbx)
    a7b7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a7bb:	5b                   	pop    %rbx
    a7bc:	41 5c                	pop    %r12
    a7be:	41 5d                	pop    %r13
    a7c0:	41 5e                	pop    %r14
    a7c2:	41 5f                	pop    %r15
    a7c4:	5d                   	pop    %rbp
    a7c5:	c3                   	ret
    a7c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a7cd:	00 00 00 
    a7d0:	4d 89 c4             	mov    %r8,%r12
    a7d3:	49 39 c1             	cmp    %rax,%r9
    a7d6:	0f 82 ce 00 00 00    	jb     a8aa <__divmodti4+0x18a>
    a7dc:	31 ff                	xor    %edi,%edi
    a7de:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a7e3:	48 63 c7             	movslq %edi,%rax
    a7e6:	be 40 00 00 00       	mov    $0x40,%esi
    a7eb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a7f0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a7f5:	48 29 c6             	sub    %rax,%rsi
    a7f8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a7fd:	48 09 c8             	or     %rcx,%rax
    a800:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a805:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a80a:	49 89 c6             	mov    %rax,%r14
    a80d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a811:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a816:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a81b:	49 09 c1             	or     %rax,%r9
    a81e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a822:	4c 89 c8             	mov    %r9,%rax
    a825:	49 f7 f6             	div    %r14
    a828:	48 89 d1             	mov    %rdx,%rcx
    a82b:	49 89 c3             	mov    %rax,%r11
    a82e:	49 89 c1             	mov    %rax,%r9
    a831:	49 f7 e2             	mul    %r10
    a834:	49 89 c6             	mov    %rax,%r14
    a837:	49 89 d2             	mov    %rdx,%r10
    a83a:	48 39 d1             	cmp    %rdx,%rcx
    a83d:	72 07                	jb     a846 <__divmodti4+0x126>
    a83f:	75 17                	jne    a858 <__divmodti4+0x138>
    a841:	49 39 c7             	cmp    %rax,%r15
    a844:	73 12                	jae    a858 <__divmodti4+0x138>
    a846:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a84a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a84e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a852:	49 89 d2             	mov    %rdx,%r10
    a855:	49 89 c6             	mov    %rax,%r14
    a858:	4c 89 f8             	mov    %r15,%rax
    a85b:	4c 29 f0             	sub    %r14,%rax
    a85e:	4c 19 d1             	sbb    %r10,%rcx
    a861:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a866:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a86b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a870:	48 09 c6             	or     %rax,%rsi
    a873:	48 89 cf             	mov    %rcx,%rdi
    a876:	31 c0                	xor    %eax,%eax
    a878:	4c 89 c9             	mov    %r9,%rcx
    a87b:	e9 10 ff ff ff       	jmp    a790 <__divmodti4+0x70>
    a880:	4c 89 d0             	mov    %r10,%rax
    a883:	4c 89 da             	mov    %r11,%rdx
    a886:	4d 89 c4             	mov    %r8,%r12
    a889:	49 89 f3             	mov    %rsi,%r11
    a88c:	48 f7 d8             	neg    %rax
    a88f:	49 f7 d4             	not    %r12
    a892:	48 83 d2 00          	adc    $0x0,%rdx
    a896:	49 89 c2             	mov    %rax,%r10
    a899:	48 f7 da             	neg    %rdx
    a89c:	48 89 d1             	mov    %rdx,%rcx
    a89f:	0f 84 cc fe ff ff    	je     a771 <__divmodti4+0x51>
    a8a5:	49 39 d1             	cmp    %rdx,%r9
    a8a8:	73 46                	jae    a8f0 <__divmodti4+0x1d0>
    a8aa:	4c 89 cf             	mov    %r9,%rdi
    a8ad:	31 c0                	xor    %eax,%eax
    a8af:	31 c9                	xor    %ecx,%ecx
    a8b1:	e9 da fe ff ff       	jmp    a790 <__divmodti4+0x70>
    a8b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8bd:	00 00 00 
    a8c0:	4d 85 d2             	test   %r10,%r10
    a8c3:	75 0d                	jne    a8d2 <__divmodti4+0x1b2>
    a8c5:	b8 01 00 00 00       	mov    $0x1,%eax
    a8ca:	31 d2                	xor    %edx,%edx
    a8cc:	49 f7 f2             	div    %r10
    a8cf:	49 89 c2             	mov    %rax,%r10
    a8d2:	4c 89 c8             	mov    %r9,%rax
    a8d5:	31 d2                	xor    %edx,%edx
    a8d7:	49 f7 f2             	div    %r10
    a8da:	49 89 c1             	mov    %rax,%r9
    a8dd:	4c 89 d8             	mov    %r11,%rax
    a8e0:	49 f7 f2             	div    %r10
    a8e3:	49 89 c3             	mov    %rax,%r11
    a8e6:	4c 89 c8             	mov    %r9,%rax
    a8e9:	e9 9a fe ff ff       	jmp    a788 <__divmodti4+0x68>
    a8ee:	66 90                	xchg   %ax,%ax
    a8f0:	45 31 f6             	xor    %r14d,%r14d
    a8f3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a8f8:	44 89 f7             	mov    %r14d,%edi
    a8fb:	45 85 f6             	test   %r14d,%r14d
    a8fe:	0f 85 df fe ff ff    	jne    a7e3 <__divmodti4+0xc3>
    a904:	4c 39 ca             	cmp    %r9,%rdx
    a907:	72 17                	jb     a920 <__divmodti4+0x200>
    a909:	31 c9                	xor    %ecx,%ecx
    a90b:	48 39 c6             	cmp    %rax,%rsi
    a90e:	73 10                	jae    a920 <__divmodti4+0x200>
    a910:	4c 89 cf             	mov    %r9,%rdi
    a913:	31 c0                	xor    %eax,%eax
    a915:	e9 76 fe ff ff       	jmp    a790 <__divmodti4+0x70>
    a91a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a920:	4c 89 de             	mov    %r11,%rsi
    a923:	b9 01 00 00 00       	mov    $0x1,%ecx
    a928:	48 29 c6             	sub    %rax,%rsi
    a92b:	49 19 d1             	sbb    %rdx,%r9
    a92e:	eb e0                	jmp    a910 <__divmodti4+0x1f0>

000000000000a930 <atexit>:
    a930:	f3 0f 1e fa          	endbr64
    a934:	48 8b 15 cd 46 00 00 	mov    0x46cd(%rip),%rdx        # f008 <__dso_handle>
    a93b:	31 f6                	xor    %esi,%esi
    a93d:	e9 fe 8c ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a944 <_fini>:
    a944:	f3 0f 1e fa          	endbr64
    a948:	48 83 ec 08          	sub    $0x8,%rsp
    a94c:	48 83 c4 08          	add    $0x8,%rsp
    a950:	c3                   	ret
