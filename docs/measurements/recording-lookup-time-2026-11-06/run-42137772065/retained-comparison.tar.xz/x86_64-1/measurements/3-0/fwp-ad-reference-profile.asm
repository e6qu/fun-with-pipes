
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 bf 00 00 	mov    0xbfd1(%rip),%rax        # efe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 bc 00 00    	jmp    *0xbc66(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # ee28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # ee30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # ee38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # ee40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # eea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # eea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # eeb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # eeb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # eec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # eec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # ef00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # ef08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # ef10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # ef18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # ef20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # ef28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # efa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # efa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # efb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # efb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # efc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # efc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036e0 <fwp_trap_overflow.constprop.0>:
    36e0:	53                   	push   %rbx
    36e1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36e6:	ba 02 00 00 00       	mov    $0x2,%edx
    36eb:	be 60 00 00 00       	mov    $0x60,%esi
    36f0:	4c 8d 0d d8 79 00 00 	lea    0x79d8(%rip),%r9        # b0cf <_IO_stdin_used+0xcf>
    36f7:	4c 8d 05 d5 79 00 00 	lea    0x79d5(%rip),%r8        # b0d3 <_IO_stdin_used+0xd3>
    36fe:	48 83 ec 70          	sub    $0x70,%rsp
    3702:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3709:	00 00 
    370b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3710:	31 c0                	xor    %eax,%eax
    3712:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3717:	e8 84 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    371c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3721:	e8 0a 0d 00 00       	call   4430 <fwp_trap>

0000000000003726 <fwp_task_dispose.cold>:
    3726:	e8 95 fc ff ff       	call   33c0 <abort@plt>

000000000000372b <fwp_main_thread.cold>:
    372b:	e8 90 fc ff ff       	call   33c0 <abort@plt>

0000000000003730 <main.cold>:
    3730:	e8 8b fc ff ff       	call   33c0 <abort@plt>
    3735:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    373c:	00 00 00 
    373f:	90                   	nop

0000000000003740 <main>:
    3740:	f3 0f 1e fa          	endbr64
    3744:	55                   	push   %rbp
    3745:	53                   	push   %rbx
    3746:	48 83 ec 68          	sub    $0x68,%rsp
    374a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3751:	00 00 
    3753:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3758:	48 8d 05 c1 9b 00 00 	lea    0x9bc1(%rip),%rax        # d320 <fwp_fn_table>
    375f:	48 89 05 12 5d 06 00 	mov    %rax,0x65d12(%rip)        # 69478 <fwp_fns>
    3766:	48 8b 05 b3 b8 00 00 	mov    0xb8b3(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    376d:	48 89 05 0c 5d 06 00 	mov    %rax,0x65d0c(%rip)        # 69480 <fwp_prog_out>
    3774:	e8 27 0e 00 00       	call   45a0 <fwp_now_ns>
    3779:	48 8d 3d 28 7b 00 00 	lea    0x7b28(%rip),%rdi        # b2a8 <_IO_stdin_used+0x2a8>
    3780:	e8 0b fc ff ff       	call   3390 <getenv@plt>
    3785:	48 85 c0             	test   %rax,%rax
    3788:	74 0c                	je     3796 <main+0x56>
    378a:	48 89 c3             	mov    %rax,%rbx
    378d:	80 38 00             	cmpb   $0x0,(%rax)
    3790:	0f 85 09 01 00 00    	jne    389f <main+0x15f>
    3796:	31 ff                	xor    %edi,%edi
    3798:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    379d:	e8 6e fc ff ff       	call   3410 <clock_gettime@plt>
    37a2:	85 c0                	test   %eax,%eax
    37a4:	0f 85 28 01 00 00    	jne    38d2 <main+0x192>
    37aa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37af:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37b4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37b9:	48 89 cb             	mov    %rcx,%rbx
    37bc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37c0:	48 01 c8             	add    %rcx,%rax
    37c3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ca:	00 00 80 
    37cd:	48 11 da             	adc    %rbx,%rdx
    37d0:	31 db                	xor    %ebx,%ebx
    37d2:	48 01 c8             	add    %rcx,%rax
    37d5:	48 11 da             	adc    %rbx,%rdx
    37d8:	48 85 d2             	test   %rdx,%rdx
    37db:	0f 85 38 01 00 00    	jne    3919 <main+0x1d9>
    37e1:	48 8b 3d 38 b8 00 00 	mov    0xb838(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    37e8:	31 d2                	xor    %edx,%edx
    37ea:	31 f6                	xor    %esi,%esi
    37ec:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37f1:	e8 da fd ff ff       	call   35d0 <setvbuf@plt>
    37f6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37fb:	be 01 00 00 00       	mov    $0x1,%esi
    3800:	e8 2b fd ff ff       	call   3530 <signal@plt>
    3805:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    380a:	e8 d1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    380f:	85 c0                	test   %eax,%eax
    3811:	0f 85 f6 00 00 00    	jne    390d <main+0x1cd>
    3817:	be 00 00 00 40       	mov    $0x40000000,%esi
    381c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3821:	e8 aa fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3826:	85 c0                	test   %eax,%eax
    3828:	0f 85 c1 00 00 00    	jne    38ef <main+0x1af>
    382e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3833:	31 c9                	xor    %ecx,%ecx
    3835:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    383a:	48 8d 15 df 5d 00 00 	lea    0x5ddf(%rip),%rdx        # 9620 <fwp_main_thread>
    3841:	e8 9a fd ff ff       	call   35e0 <pthread_create@plt>
    3846:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    384b:	89 c5                	mov    %eax,%ebp
    384d:	e8 de fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3852:	85 c0                	test   %eax,%eax
    3854:	0f 85 d6 fe ff ff    	jne    3730 <main.cold>
    385a:	85 ed                	test   %ebp,%ebp
    385c:	0f 85 81 00 00 00    	jne    38e3 <main+0x1a3>
    3862:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3867:	31 f6                	xor    %esi,%esi
    3869:	e8 22 fe ff ff       	call   3690 <pthread_join@plt>
    386e:	85 c0                	test   %eax,%eax
    3870:	0f 85 ba fe ff ff    	jne    3730 <main.cold>
    3876:	48 8b 3d a3 b7 00 00 	mov    0xb7a3(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    387d:	e8 1e fd ff ff       	call   35a0 <fflush@plt>
    3882:	8b 05 f8 b7 01 00    	mov    0x1b7f8(%rip),%eax        # 1f080 <fwp_exit_code>
    3888:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    388d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3894:	00 00 
    3896:	75 46                	jne    38de <main+0x19e>
    3898:	48 83 c4 68          	add    $0x68,%rsp
    389c:	5b                   	pop    %rbx
    389d:	5d                   	pop    %rbp
    389e:	c3                   	ret
    389f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38a4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a9:	48 89 c7             	mov    %rax,%rdi
    38ac:	e8 4f fc ff ff       	call   3500 <strtoull@plt>
    38b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38b6:	80 38 00             	cmpb   $0x0,(%rax)
    38b9:	0f 85 d7 fe ff ff    	jne    3796 <main+0x56>
    38bf:	0f b6 03             	movzbl (%rbx),%eax
    38c2:	83 e8 2b             	sub    $0x2b,%eax
    38c5:	a8 fd                	test   $0xfd,%al
    38c7:	0f 84 c9 fe ff ff    	je     3796 <main+0x56>
    38cd:	e9 0f ff ff ff       	jmp    37e1 <main+0xa1>
    38d2:	48 8d 3d d8 79 00 00 	lea    0x79d8(%rip),%rdi        # b2b1 <_IO_stdin_used+0x2b1>
    38d9:	e8 52 0b 00 00       	call   4430 <fwp_trap>
    38de:	e8 6d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    38e3:	48 8d 3d a6 82 00 00 	lea    0x82a6(%rip),%rdi        # bb90 <_IO_stdin_used+0xb90>
    38ea:	e8 41 0b 00 00       	call   4430 <fwp_trap>
    38ef:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38f4:	e8 37 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    38f9:	85 c0                	test   %eax,%eax
    38fb:	0f 85 2f fe ff ff    	jne    3730 <main.cold>
    3901:	48 8d 3d 60 82 00 00 	lea    0x8260(%rip),%rdi        # bb68 <_IO_stdin_used+0xb68>
    3908:	e8 23 0b 00 00       	call   4430 <fwp_trap>
    390d:	48 8d 3d 24 82 00 00 	lea    0x8224(%rip),%rdi        # bb38 <_IO_stdin_used+0xb38>
    3914:	e8 17 0b 00 00       	call   4430 <fwp_trap>
    3919:	48 8d 3d f0 81 00 00 	lea    0x81f0(%rip),%rdi        # bb10 <_IO_stdin_used+0xb10>
    3920:	e8 0b 0b 00 00       	call   4430 <fwp_trap>
    3925:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    392c:	00 00 00 
    392f:	90                   	nop

0000000000003930 <_start>:
    3930:	f3 0f 1e fa          	endbr64
    3934:	31 ed                	xor    %ebp,%ebp
    3936:	49 89 d1             	mov    %rdx,%r9
    3939:	5e                   	pop    %rsi
    393a:	48 89 e2             	mov    %rsp,%rdx
    393d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3941:	50                   	push   %rax
    3942:	54                   	push   %rsp
    3943:	45 31 c0             	xor    %r8d,%r8d
    3946:	31 c9                	xor    %ecx,%ecx
    3948:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3740 <main>
    394f:	ff 15 7b b6 00 00    	call   *0xb67b(%rip)        # efd0 <__libc_start_main@GLIBC_2.34>
    3955:	f4                   	hlt
    3956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    395d:	00 00 00 

0000000000003960 <deregister_tm_clones>:
    3960:	48 8d 3d b1 b6 00 00 	lea    0xb6b1(%rip),%rdi        # f018 <__TMC_END__>
    3967:	48 8d 05 aa b6 00 00 	lea    0xb6aa(%rip),%rax        # f018 <__TMC_END__>
    396e:	48 39 f8             	cmp    %rdi,%rax
    3971:	74 15                	je     3988 <deregister_tm_clones+0x28>
    3973:	48 8b 05 5e b6 00 00 	mov    0xb65e(%rip),%rax        # efd8 <_ITM_deregisterTMCloneTable>
    397a:	48 85 c0             	test   %rax,%rax
    397d:	74 09                	je     3988 <deregister_tm_clones+0x28>
    397f:	ff e0                	jmp    *%rax
    3981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3988:	c3                   	ret
    3989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003990 <register_tm_clones>:
    3990:	48 8d 3d 81 b6 00 00 	lea    0xb681(%rip),%rdi        # f018 <__TMC_END__>
    3997:	48 8d 35 7a b6 00 00 	lea    0xb67a(%rip),%rsi        # f018 <__TMC_END__>
    399e:	48 29 fe             	sub    %rdi,%rsi
    39a1:	48 89 f0             	mov    %rsi,%rax
    39a4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39a8:	48 c1 f8 03          	sar    $0x3,%rax
    39ac:	48 01 c6             	add    %rax,%rsi
    39af:	48 d1 fe             	sar    $1,%rsi
    39b2:	74 14                	je     39c8 <register_tm_clones+0x38>
    39b4:	48 8b 05 2d b6 00 00 	mov    0xb62d(%rip),%rax        # efe8 <_ITM_registerTMCloneTable>
    39bb:	48 85 c0             	test   %rax,%rax
    39be:	74 08                	je     39c8 <register_tm_clones+0x38>
    39c0:	ff e0                	jmp    *%rax
    39c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39c8:	c3                   	ret
    39c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039d0 <__do_global_dtors_aux>:
    39d0:	f3 0f 1e fa          	endbr64
    39d4:	80 3d 6d b6 00 00 00 	cmpb   $0x0,0xb66d(%rip)        # f048 <completed.0>
    39db:	75 2b                	jne    3a08 <__do_global_dtors_aux+0x38>
    39dd:	55                   	push   %rbp
    39de:	48 83 3d 0a b6 00 00 	cmpq   $0x0,0xb60a(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    39e5:	00 
    39e6:	48 89 e5             	mov    %rsp,%rbp
    39e9:	74 0c                	je     39f7 <__do_global_dtors_aux+0x27>
    39eb:	48 8b 3d 16 b6 00 00 	mov    0xb616(%rip),%rdi        # f008 <__dso_handle>
    39f2:	e8 89 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    39f7:	e8 64 ff ff ff       	call   3960 <deregister_tm_clones>
    39fc:	c6 05 45 b6 00 00 01 	movb   $0x1,0xb645(%rip)        # f048 <completed.0>
    3a03:	5d                   	pop    %rbp
    3a04:	c3                   	ret
    3a05:	0f 1f 00             	nopl   (%rax)
    3a08:	c3                   	ret
    3a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a10 <frame_dummy>:
    3a10:	f3 0f 1e fa          	endbr64
    3a14:	e9 77 ff ff ff       	jmp    3990 <register_tm_clones>
    3a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a20 <fwp_fmt_u128>:
    3a20:	41 57                	push   %r15
    3a22:	41 56                	push   %r14
    3a24:	41 55                	push   %r13
    3a26:	41 54                	push   %r12
    3a28:	55                   	push   %rbp
    3a29:	53                   	push   %rbx
    3a2a:	48 83 ec 68          	sub    $0x68,%rsp
    3a2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a35:	00 00 
    3a37:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a3c:	48 89 f0             	mov    %rsi,%rax
    3a3f:	48 09 d0             	or     %rdx,%rax
    3a42:	75 7c                	jne    3ac0 <fwp_fmt_u128+0xa0>
    3a44:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a49:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a4e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a53:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a56:	48 89 f8             	mov    %rdi,%rax
    3a59:	49 01 d4             	add    %rdx,%r12
    3a5c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a61:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a68:	00 00 
    3a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a71:	00 00 00 00 
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 
    3a80:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a85:	48 83 c0 01          	add    $0x1,%rax
    3a89:	49 83 ec 01          	sub    $0x1,%r12
    3a8d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a90:	48 39 c8             	cmp    %rcx,%rax
    3a93:	75 eb                	jne    3a80 <fwp_fmt_u128+0x60>
    3a95:	48 63 ed             	movslq %ebp,%rbp
    3a98:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a9c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3aa1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3aa8:	00 00 
    3aaa:	0f 85 ef 00 00 00    	jne    3b9f <fwp_fmt_u128+0x17f>
    3ab0:	48 83 c4 68          	add    $0x68,%rsp
    3ab4:	5b                   	pop    %rbx
    3ab5:	5d                   	pop    %rbp
    3ab6:	41 5c                	pop    %r12
    3ab8:	41 5d                	pop    %r13
    3aba:	41 5e                	pop    %r14
    3abc:	41 5f                	pop    %r15
    3abe:	c3                   	ret
    3abf:	90                   	nop
    3ac0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ac5:	49 89 f2             	mov    %rsi,%r10
    3ac8:	49 89 d3             	mov    %rdx,%r11
    3acb:	31 ed                	xor    %ebp,%ebp
    3acd:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ad2:	4c 89 e3             	mov    %r12,%rbx
    3ad5:	45 31 f6             	xor    %r14d,%r14d
    3ad8:	49 89 f9             	mov    %rdi,%r9
    3adb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ae2:	cc cc cc 
    3ae5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3aeb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3af2:	cc cc cc 
    3af5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b00:	4c 89 d6             	mov    %r10,%rsi
    3b03:	4c 89 df             	mov    %r11,%rdi
    3b06:	4c 01 de             	add    %r11,%rsi
    3b09:	48 83 d6 00          	adc    $0x0,%rsi
    3b0d:	45 31 ed             	xor    %r13d,%r13d
    3b10:	48 89 f0             	mov    %rsi,%rax
    3b13:	48 f7 e1             	mul    %rcx
    3b16:	48 89 d0             	mov    %rdx,%rax
    3b19:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b1d:	48 c1 e8 02          	shr    $0x2,%rax
    3b21:	48 01 c2             	add    %rax,%rdx
    3b24:	48 8b 04 24          	mov    (%rsp),%rax
    3b28:	48 29 d6             	sub    %rdx,%rsi
    3b2b:	49 89 f4             	mov    %rsi,%r12
    3b2e:	4c 89 d6             	mov    %r10,%rsi
    3b31:	4c 29 e6             	sub    %r12,%rsi
    3b34:	4c 19 ef             	sbb    %r13,%rdi
    3b37:	48 0f af c6          	imul   %rsi,%rax
    3b3b:	49 89 f8             	mov    %rdi,%r8
    3b3e:	4c 0f af c1          	imul   %rcx,%r8
    3b42:	49 01 c0             	add    %rax,%r8
    3b45:	48 89 f0             	mov    %rsi,%rax
    3b48:	48 f7 e1             	mul    %rcx
    3b4b:	48 89 c6             	mov    %rax,%rsi
    3b4e:	83 e0 01             	and    $0x1,%eax
    3b51:	49 01 d0             	add    %rdx,%r8
    3b54:	49 f7 e7             	mul    %r15
    3b57:	4c 89 c7             	mov    %r8,%rdi
    3b5a:	4c 89 d2             	mov    %r10,%rdx
    3b5d:	4c 01 e0             	add    %r12,%rax
    3b60:	48 d1 ef             	shr    $1,%rdi
    3b63:	83 c5 01             	add    $0x1,%ebp
    3b66:	48 83 c3 01          	add    $0x1,%rbx
    3b6a:	83 c0 30             	add    $0x30,%eax
    3b6d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b72:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b75:	4c 89 d8             	mov    %r11,%rax
    3b78:	49 89 fb             	mov    %rdi,%r11
    3b7b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b80:	48 39 d7             	cmp    %rdx,%rdi
    3b83:	4c 89 f7             	mov    %r14,%rdi
    3b86:	49 89 f2             	mov    %rsi,%r10
    3b89:	48 19 c7             	sbb    %rax,%rdi
    3b8c:	0f 82 6e ff ff ff    	jb     3b00 <fwp_fmt_u128+0xe0>
    3b92:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b97:	4c 89 cf             	mov    %r9,%rdi
    3b9a:	e9 b4 fe ff ff       	jmp    3a53 <fwp_fmt_u128+0x33>
    3b9f:	e8 ac f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3ba4:	90                   	nop
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_range_release>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	53                   	push   %rbx
    3bb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bb9:	48 89 fb             	mov    %rdi,%rbx
    3bbc:	48 85 c0             	test   %rax,%rax
    3bbf:	74 06                	je     3bc7 <fwp_range_release+0x17>
    3bc1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3bc5:	ff d0                	call   *%rax
    3bc7:	48 8b 3b             	mov    (%rbx),%rdi
    3bca:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bce:	5b                   	pop    %rbx
    3bcf:	ff e0                	jmp    *%rax
    3bd1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 

0000000000003be0 <ad_raw_record>:
    3be0:	89 c8                	mov    %ecx,%eax
    3be2:	4c 8d 05 b7 b5 04 00 	lea    0x4b5b7(%rip),%r8        # 4f1a0 <ad_raw_live>
    3be9:	49 89 f1             	mov    %rsi,%r9
    3bec:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bf3:	00 
    3bf4:	48 89 d6             	mov    %rdx,%rsi
    3bf7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bfa:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bfe:	48 8d 0d 5b b5 04 00 	lea    0x4b55b(%rip),%rcx        # 4f160 <ad_raw_requests>
    3c05:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c0a:	48 8d 0d 2f b5 04 00 	lea    0x4b52f(%rip),%rcx        # 4f140 <ad_raw_bytes>
    3c11:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c15:	48 01 f2             	add    %rsi,%rdx
    3c18:	48 8d 0d 61 b5 04 00 	lea    0x4b561(%rip),%rcx        # 4f180 <ad_raw_peak>
    3c1f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c23:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c27:	4c 89 0f             	mov    %r9,(%rdi)
    3c2a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c2e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c32:	73 04                	jae    3c38 <ad_raw_record+0x58>
    3c34:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c38:	66 0f 6f 05 70 b5 04 	movdqa 0x4b570(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    3c3f:	00 
    3c40:	66 0f d4 05 58 b5 04 	paddq  0x4b558(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    3c47:	00 
    3c48:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c4c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c51:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c55:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c5a:	48 39 05 bf b4 04 00 	cmp    %rax,0x4b4bf(%rip)        # 4f120 <ad_raw_total_peak>
    3c61:	73 08                	jae    3c6b <ad_raw_record+0x8b>
    3c63:	66 0f d6 05 b5 b4 04 	movq   %xmm0,0x4b4b5(%rip)        # 4f120 <ad_raw_total_peak>
    3c6a:	00 
    3c6b:	c3                   	ret
    3c6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c70 <fwp_tape_unlink_scope>:
    3c70:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c74:	48 85 d2             	test   %rdx,%rdx
    3c77:	74 3e                	je     3cb7 <fwp_tape_unlink_scope+0x47>
    3c79:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c7c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c80:	85 c9                	test   %ecx,%ecx
    3c82:	78 3c                	js     3cc0 <fwp_tape_unlink_scope+0x50>
    3c84:	48 63 d1             	movslq %ecx,%rdx
    3c87:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c8b:	48 03 15 5e b4 01 00 	add    0x1b45e(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c92:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c95:	85 c0                	test   %eax,%eax
    3c97:	78 0e                	js     3ca7 <fwp_tape_unlink_scope+0x37>
    3c99:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c9d:	48 03 05 4c b4 01 00 	add    0x1b44c(%rip),%rax        # 1f0f0 <fwp_tapes>
    3ca4:	89 48 58             	mov    %ecx,0x58(%rax)
    3ca7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cae:	00 
    3caf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cb6:	ff 
    3cb7:	c3                   	ret
    3cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cbf:	00 
    3cc0:	89 02                	mov    %eax,(%rdx)
    3cc2:	eb d1                	jmp    3c95 <fwp_tape_unlink_scope+0x25>
    3cc4:	90                   	nop
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_args173>:
    3cd0:	f3 0f 1e fa          	endbr64
    3cd4:	c3                   	ret
    3cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cdc:	00 00 00 00 

0000000000003ce0 <fwp_flush>:
    3ce0:	48 8b 3d 99 57 06 00 	mov    0x65799(%rip),%rdi        # 69480 <fwp_prog_out>
    3ce7:	48 85 ff             	test   %rdi,%rdi
    3cea:	74 1c                	je     3d08 <fwp_flush+0x28>
    3cec:	48 83 ec 08          	sub    $0x8,%rsp
    3cf0:	e8 ab f8 ff ff       	call   35a0 <fflush@plt>
    3cf5:	48 8b 3d 24 b3 00 00 	mov    0xb324(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cfc:	48 83 c4 08          	add    $0x8,%rsp
    3d00:	e9 9b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d05:	0f 1f 00             	nopl   (%rax)
    3d08:	48 8b 3d 11 b3 00 00 	mov    0xb311(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3d0f:	e9 8c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d14:	90                   	nop
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 

0000000000003d20 <fwp_segv>:
    3d20:	f3 0f 1e fa          	endbr64
    3d24:	48 83 ec 28          	sub    $0x28,%rsp
    3d28:	48 8b 05 d1 3a 06 00 	mov    0x63ad1(%rip),%rax        # 67800 <fwp_cur>
    3d2f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d33:	41 89 f8             	mov    %edi,%r8d
    3d36:	48 85 c0             	test   %rax,%rax
    3d39:	74 6d                	je     3da8 <fwp_segv+0x88>
    3d3b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d3f:	48 85 d2             	test   %rdx,%rdx
    3d42:	74 64                	je     3da8 <fwp_segv+0x88>
    3d44:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d48:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d52:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d57:	e8 c4 f8 ff ff       	call   3620 <sysconf@plt>
    3d5c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d61:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d66:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d6b:	48 01 d0             	add    %rdx,%rax
    3d6e:	48 39 c1             	cmp    %rax,%rcx
    3d71:	b8 00 00 00 00       	mov    $0x0,%eax
    3d76:	40 0f 92 c6          	setb   %sil
    3d7a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d81:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d85:	31 c0                	xor    %eax,%eax
    3d87:	48 39 d1             	cmp    %rdx,%rcx
    3d8a:	0f 93 c0             	setae  %al
    3d8d:	21 f0                	and    %esi,%eax
    3d8f:	85 c0                	test   %eax,%eax
    3d91:	75 4a                	jne    3ddd <fwp_segv+0xbd>
    3d93:	31 f6                	xor    %esi,%esi
    3d95:	44 89 c7             	mov    %r8d,%edi
    3d98:	48 83 c4 28          	add    $0x28,%rsp
    3d9c:	e9 8f f7 ff ff       	jmp    3530 <signal@plt>
    3da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3da8:	48 8b 05 19 34 06 00 	mov    0x63419(%rip),%rax        # 671c8 <fwp_main_stack_top>
    3daf:	48 85 c0             	test   %rax,%rax
    3db2:	74 df                	je     3d93 <fwp_segv+0x73>
    3db4:	48 2b 05 05 34 06 00 	sub    0x63405(%rip),%rax        # 671c0 <fwp_main_stack_size>
    3dbb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3dc2:	48 39 d1             	cmp    %rdx,%rcx
    3dc5:	0f 93 c2             	setae  %dl
    3dc8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dce:	48 39 c1             	cmp    %rax,%rcx
    3dd1:	0f 92 c0             	setb   %al
    3dd4:	0f b6 c0             	movzbl %al,%eax
    3dd7:	21 d0                	and    %edx,%eax
    3dd9:	85 c0                	test   %eax,%eax
    3ddb:	74 b6                	je     3d93 <fwp_segv+0x73>
    3ddd:	e8 fe fe ff ff       	call   3ce0 <fwp_flush>
    3de2:	bf 02 00 00 00       	mov    $0x2,%edi
    3de7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dec:	48 8d 35 7d 7e 00 00 	lea    0x7e7d(%rip),%rsi        # bc70 <msg.4>
    3df3:	e8 28 f6 ff ff       	call   3420 <write@plt>
    3df8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dfd:	e8 ce f5 ff ff       	call   33d0 <_exit@plt>
    3e02:	0f 1f 00             	nopl   (%rax)
    3e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e0c:	00 00 00 00 

0000000000003e10 <fwp_heap_oom>:
    3e10:	50                   	push   %rax
    3e11:	58                   	pop    %rax
    3e12:	ba 13 00 00 00       	mov    $0x13,%edx
    3e17:	be 01 00 00 00       	mov    $0x1,%esi
    3e1c:	48 8d 3d e5 71 00 00 	lea    0x71e5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3e23:	48 83 ec 08          	sub    $0x8,%rsp
    3e27:	48 8b 0d 12 b2 00 00 	mov    0xb212(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3e2e:	e8 2d f8 ff ff       	call   3660 <fwrite@plt>
    3e33:	31 ff                	xor    %edi,%edi
    3e35:	e8 66 f7 ff ff       	call   35a0 <fflush@plt>
    3e3a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e3f:	e8 3c f8 ff ff       	call   3680 <_Exit@plt>
    3e44:	90                   	nop
    3e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e4c:	00 00 00 00 

0000000000003e50 <fwp_heap_chunks>:
    3e50:	41 54                	push   %r12
    3e52:	55                   	push   %rbp
    3e53:	53                   	push   %rbx
    3e54:	48 83 ff 01          	cmp    $0x1,%rdi
    3e58:	0f 84 62 01 00 00    	je     3fc0 <fwp_heap_chunks+0x170>
    3e5e:	48 8b 05 ab 4d 06 00 	mov    0x64dab(%rip),%rax        # 68c10 <fwp_heap+0x13f0>
    3e65:	4c 8d 05 a4 4d 06 00 	lea    0x64da4(%rip),%r8        # 68c10 <fwp_heap+0x13f0>
    3e6c:	48 8b 1d 85 4d 06 00 	mov    0x64d85(%rip),%rbx        # 68bf8 <fwp_heap+0x13d8>
    3e73:	48 39 d8             	cmp    %rbx,%rax
    3e76:	0f 83 57 01 00 00    	jae    3fd3 <fwp_heap_chunks+0x183>
    3e7c:	48 8b 0d 95 4d 06 00 	mov    0x64d95(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    3e83:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e87:	31 f6                	xor    %esi,%esi
    3e89:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e8d:	eb 1e                	jmp    3ead <fwp_heap_chunks+0x5d>
    3e8f:	90                   	nop
    3e90:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e94:	48 39 cf             	cmp    %rcx,%rdi
    3e97:	0f 84 03 01 00 00    	je     3fa0 <fwp_heap_chunks+0x150>
    3e9d:	48 83 c0 01          	add    $0x1,%rax
    3ea1:	48 89 ce             	mov    %rcx,%rsi
    3ea4:	48 83 c2 28          	add    $0x28,%rdx
    3ea8:	48 39 c3             	cmp    %rax,%rbx
    3eab:	74 14                	je     3ec1 <fwp_heap_chunks+0x71>
    3ead:	80 3a 00             	cmpb   $0x0,(%rdx)
    3eb0:	74 de                	je     3e90 <fwp_heap_chunks+0x40>
    3eb2:	48 83 c0 01          	add    $0x1,%rax
    3eb6:	31 f6                	xor    %esi,%esi
    3eb8:	48 83 c2 28          	add    $0x28,%rdx
    3ebc:	48 39 c3             	cmp    %rax,%rbx
    3ebf:	75 ec                	jne    3ead <fwp_heap_chunks+0x5d>
    3ec1:	48 29 f3             	sub    %rsi,%rbx
    3ec4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ec8:	48 8b 3d 31 4d 06 00 	mov    0x64d31(%rip),%rdi        # 68c00 <fwp_heap+0x13e0>
    3ecf:	48 29 35 7a 4d 06 00 	sub    %rsi,0x64d7a(%rip)        # 68c50 <fwp_heap+0x1430>
    3ed6:	48 39 ef             	cmp    %rbp,%rdi
    3ed9:	0f 83 96 00 00 00    	jae    3f75 <fwp_heap_chunks+0x125>
    3edf:	48 8b 05 0a 4d 06 00 	mov    0x64d0a(%rip),%rax        # 68bf0 <fwp_heap+0x13d0>
    3ee6:	48 39 e8             	cmp    %rbp,%rax
    3ee9:	0f 82 eb 00 00 00    	jb     3fda <fwp_heap_chunks+0x18a>
    3eef:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ef3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef8:	49 39 c4             	cmp    %rax,%r12
    3efb:	4c 0f 47 e0          	cmova  %rax,%r12
    3eff:	4c 89 e6             	mov    %r12,%rsi
    3f02:	48 29 fe             	sub    %rdi,%rsi
    3f05:	48 c1 e7 10          	shl    $0x10,%rdi
    3f09:	48 03 3d c0 4c 06 00 	add    0x64cc0(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    3f10:	48 c1 e6 10          	shl    $0x10,%rsi
    3f14:	e8 e7 f6 ff ff       	call   3600 <mprotect@plt>
    3f19:	85 c0                	test   %eax,%eax
    3f1b:	0f 85 b9 00 00 00    	jne    3fda <fwp_heap_chunks+0x18a>
    3f21:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f26:	e8 f5 f6 ff ff       	call   3620 <sysconf@plt>
    3f2b:	48 8b 35 ce 4c 06 00 	mov    0x64cce(%rip),%rsi        # 68c00 <fwp_heap+0x13e0>
    3f32:	48 89 c1             	mov    %rax,%rcx
    3f35:	48 8b 05 dc 4c 06 00 	mov    0x64cdc(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    3f3c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f40:	48 89 ca             	mov    %rcx,%rdx
    3f43:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f47:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f4b:	48 f7 da             	neg    %rdx
    3f4e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f53:	48 21 d7             	and    %rdx,%rdi
    3f56:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f5a:	48 21 d6             	and    %rdx,%rsi
    3f5d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f62:	48 29 fe             	sub    %rdi,%rsi
    3f65:	e8 96 f6 ff ff       	call   3600 <mprotect@plt>
    3f6a:	85 c0                	test   %eax,%eax
    3f6c:	75 6c                	jne    3fda <fwp_heap_chunks+0x18a>
    3f6e:	4c 89 25 8b 4c 06 00 	mov    %r12,0x64c8b(%rip)        # 68c00 <fwp_heap+0x13e0>
    3f75:	48 89 ef             	mov    %rbp,%rdi
    3f78:	48 89 2d 79 4c 06 00 	mov    %rbp,0x64c79(%rip)        # 68bf8 <fwp_heap+0x13d8>
    3f7f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f83:	48 39 3d 5e 4c 06 00 	cmp    %rdi,0x64c5e(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f8a:	73 07                	jae    3f93 <fwp_heap_chunks+0x143>
    3f8c:	48 89 3d 55 4c 06 00 	mov    %rdi,0x64c55(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f93:	48 89 d8             	mov    %rbx,%rax
    3f96:	5b                   	pop    %rbx
    3f97:	5d                   	pop    %rbp
    3f98:	41 5c                	pop    %r12
    3f9a:	c3                   	ret
    3f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fa0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fa4:	48 29 f0             	sub    %rsi,%rax
    3fa7:	48 89 c3             	mov    %rax,%rbx
    3faa:	49 89 10             	mov    %rdx,(%r8)
    3fad:	48 89 d8             	mov    %rbx,%rax
    3fb0:	48 29 3d 99 4c 06 00 	sub    %rdi,0x64c99(%rip)        # 68c50 <fwp_heap+0x1430>
    3fb7:	5b                   	pop    %rbx
    3fb8:	5d                   	pop    %rbp
    3fb9:	41 5c                	pop    %r12
    3fbb:	c3                   	ret
    3fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fc0:	48 8b 05 41 4c 06 00 	mov    0x64c41(%rip),%rax        # 68c08 <fwp_heap+0x13e8>
    3fc7:	4c 8d 05 3a 4c 06 00 	lea    0x64c3a(%rip),%r8        # 68c08 <fwp_heap+0x13e8>
    3fce:	e9 99 fe ff ff       	jmp    3e6c <fwp_heap_chunks+0x1c>
    3fd3:	31 f6                	xor    %esi,%esi
    3fd5:	e9 ea fe ff ff       	jmp    3ec4 <fwp_heap_chunks+0x74>
    3fda:	e8 31 fe ff ff       	call   3e10 <fwp_heap_oom>
    3fdf:	90                   	nop

0000000000003fe0 <ad_raw_fail>:
    3fe0:	50                   	push   %rax
    3fe1:	58                   	pop    %rax
    3fe2:	48 8d 15 d7 76 00 00 	lea    0x76d7(%rip),%rdx        # b6c0 <_IO_stdin_used+0x6c0>
    3fe9:	be 02 00 00 00       	mov    $0x2,%esi
    3fee:	31 c0                	xor    %eax,%eax
    3ff0:	48 83 ec 08          	sub    $0x8,%rsp
    3ff4:	48 89 f9             	mov    %rdi,%rcx
    3ff7:	48 8b 3d 42 b0 00 00 	mov    0xb042(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ffe:	e8 6d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4003:	bf e8 00 00 00       	mov    $0xe8,%edi
    4008:	e8 43 f6 ff ff       	call   3650 <exit@plt>
    400d:	0f 1f 00             	nopl   (%rax)

0000000000004010 <buf_grow>:
    4010:	48 83 ec 18          	sub    $0x18,%rsp
    4014:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4018:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    401c:	74 7e                	je     409c <buf_grow+0x8c>
    401e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4025:	48 29 c2             	sub    %rax,%rdx
    4028:	48 39 f2             	cmp    %rsi,%rdx
    402b:	72 6f                	jb     409c <buf_grow+0x8c>
    402d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4032:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4036:	48 89 f9             	mov    %rdi,%rcx
    4039:	48 39 d0             	cmp    %rdx,%rax
    403c:	73 48                	jae    4086 <buf_grow+0x76>
    403e:	48 85 c0             	test   %rax,%rax
    4041:	75 15                	jne    4058 <buf_grow+0x48>
    4043:	48 83 fa 40          	cmp    $0x40,%rdx
    4047:	76 4c                	jbe    4095 <buf_grow+0x85>
    4049:	b8 40 00 00 00       	mov    $0x40,%eax
    404e:	eb 08                	jmp    4058 <buf_grow+0x48>
    4050:	48 01 c0             	add    %rax,%rax
    4053:	48 39 d0             	cmp    %rdx,%rax
    4056:	73 38                	jae    4090 <buf_grow+0x80>
    4058:	48 85 c0             	test   %rax,%rax
    405b:	79 f3                	jns    4050 <buf_grow+0x40>
    405d:	48 8b 39             	mov    (%rcx),%rdi
    4060:	48 89 d6             	mov    %rdx,%rsi
    4063:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4068:	48 89 14 24          	mov    %rdx,(%rsp)
    406c:	e8 3f f5 ff ff       	call   35b0 <realloc@plt>
    4071:	48 8b 14 24          	mov    (%rsp),%rdx
    4075:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    407a:	48 85 c0             	test   %rax,%rax
    407d:	74 1d                	je     409c <buf_grow+0x8c>
    407f:	48 89 01             	mov    %rax,(%rcx)
    4082:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4086:	48 83 c4 18          	add    $0x18,%rsp
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 89 c2             	mov    %rax,%rdx
    4093:	eb c8                	jmp    405d <buf_grow+0x4d>
    4095:	ba 40 00 00 00       	mov    $0x40,%edx
    409a:	eb c1                	jmp    405d <buf_grow+0x4d>
    409c:	48 8b 0d 9d af 00 00 	mov    0xaf9d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    40a3:	ba 13 00 00 00       	mov    $0x13,%edx
    40a8:	be 01 00 00 00       	mov    $0x1,%esi
    40ad:	48 8d 3d 54 6f 00 00 	lea    0x6f54(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    40b4:	e8 a7 f5 ff ff       	call   3660 <fwrite@plt>
    40b9:	31 ff                	xor    %edi,%edi
    40bb:	e8 e0 f4 ff ff       	call   35a0 <fflush@plt>
    40c0:	bf 66 00 00 00       	mov    $0x66,%edi
    40c5:	e8 b6 f5 ff ff       	call   3680 <_Exit@plt>
    40ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040d0 <buf_put>:
    40d0:	41 54                	push   %r12
    40d2:	49 89 f4             	mov    %rsi,%r12
    40d5:	48 89 d6             	mov    %rdx,%rsi
    40d8:	55                   	push   %rbp
    40d9:	48 89 fd             	mov    %rdi,%rbp
    40dc:	53                   	push   %rbx
    40dd:	48 89 d3             	mov    %rdx,%rbx
    40e0:	e8 2b ff ff ff       	call   4010 <buf_grow>
    40e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40e9:	48 89 da             	mov    %rbx,%rdx
    40ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40f0:	4c 89 e6             	mov    %r12,%rsi
    40f3:	e8 88 f4 ff ff       	call   3580 <memcpy@plt>
    40f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4100:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4104:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4108:	5b                   	pop    %rbx
    4109:	5d                   	pop    %rbp
    410a:	41 5c                	pop    %r12
    410c:	c3                   	ret
    410d:	0f 1f 00             	nopl   (%rax)

0000000000004110 <fwp_cancel_tree.part.0>:
    4110:	48 3b 3d e9 36 06 00 	cmp    0x636e9(%rip),%rdi        # 67800 <fwp_cur>
    4117:	53                   	push   %rbx
    4118:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    411c:	74 35                	je     4153 <fwp_cancel_tree.part.0+0x43>
    411e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4122:	75 2f                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    4124:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4128:	75 29                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    412a:	48 8b 05 af 36 06 00 	mov    0x636af(%rip),%rax        # 677e0 <fwp_ready_tail>
    4131:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4135:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    413c:	00 00 00 00 
    4140:	48 85 c0             	test   %rax,%rax
    4143:	74 33                	je     4178 <fwp_cancel_tree.part.0+0x68>
    4145:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    414c:	48 89 3d 8d 36 06 00 	mov    %rdi,0x6368d(%rip)        # 677e0 <fwp_ready_tail>
    4153:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4157:	48 85 db             	test   %rbx,%rbx
    415a:	74 17                	je     4173 <fwp_cancel_tree.part.0+0x63>
    415c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4160:	75 08                	jne    416a <fwp_cancel_tree.part.0+0x5a>
    4162:	48 89 df             	mov    %rbx,%rdi
    4165:	e8 a6 ff ff ff       	call   4110 <fwp_cancel_tree.part.0>
    416a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    416e:	48 85 db             	test   %rbx,%rbx
    4171:	75 e9                	jne    415c <fwp_cancel_tree.part.0+0x4c>
    4173:	5b                   	pop    %rbx
    4174:	c3                   	ret
    4175:	0f 1f 00             	nopl   (%rax)
    4178:	48 89 3d 69 36 06 00 	mov    %rdi,0x63669(%rip)        # 677e8 <fwp_ready_head>
    417f:	eb cb                	jmp    414c <fwp_cancel_tree.part.0+0x3c>
    4181:	0f 1f 40 00          	nopl   0x0(%rax)
    4185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    418c:	00 00 00 00 

0000000000004190 <fwp_finish_float>:
    4190:	53                   	push   %rbx
    4191:	be 2e 00 00 00       	mov    $0x2e,%esi
    4196:	48 89 fb             	mov    %rdi,%rbx
    4199:	e8 d2 f2 ff ff       	call   3470 <strchr@plt>
    419e:	48 85 c0             	test   %rax,%rax
    41a1:	74 05                	je     41a8 <fwp_finish_float+0x18>
    41a3:	5b                   	pop    %rbx
    41a4:	c3                   	ret
    41a5:	0f 1f 00             	nopl   (%rax)
    41a8:	be 65 00 00 00       	mov    $0x65,%esi
    41ad:	48 89 df             	mov    %rbx,%rdi
    41b0:	e8 bb f2 ff ff       	call   3470 <strchr@plt>
    41b5:	48 85 c0             	test   %rax,%rax
    41b8:	75 e9                	jne    41a3 <fwp_finish_float+0x13>
    41ba:	48 8d 35 39 70 00 00 	lea    0x7039(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    41c1:	48 89 df             	mov    %rbx,%rdi
    41c4:	e8 e7 f4 ff ff       	call   36b0 <strstr@plt>
    41c9:	48 85 c0             	test   %rax,%rax
    41cc:	75 d5                	jne    41a3 <fwp_finish_float+0x13>
    41ce:	48 8d 35 47 6e 00 00 	lea    0x6e47(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    41d5:	48 89 df             	mov    %rbx,%rdi
    41d8:	e8 d3 f4 ff ff       	call   36b0 <strstr@plt>
    41dd:	48 85 c0             	test   %rax,%rax
    41e0:	75 c1                	jne    41a3 <fwp_finish_float+0x13>
    41e2:	48 89 df             	mov    %rbx,%rdi
    41e5:	e8 56 f2 ff ff       	call   3440 <strlen@plt>
    41ea:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41ef:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41f3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41f8:	5b                   	pop    %rbx
    41f9:	c3                   	ret
    41fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004200 <ad_raw_report>:
    4200:	f3 0f 1e fa          	endbr64
    4204:	41 57                	push   %r15
    4206:	41 56                	push   %r14
    4208:	41 55                	push   %r13
    420a:	41 54                	push   %r12
    420c:	55                   	push   %rbp
    420d:	53                   	push   %rbx
    420e:	48 83 ec 38          	sub    $0x38,%rsp
    4212:	66 0f 6f 05 96 af 04 	movdqa 0x4af96(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    4219:	00 
    421a:	66 0f d4 05 7e af 04 	paddq  0x4af7e(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    4221:	00 
    4222:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4229:	00 00 
    422b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4230:	31 c0                	xor    %eax,%eax
    4232:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4236:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    423b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    423f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4244:	48 85 ed             	test   %rbp,%rbp
    4247:	0f 85 d2 01 00 00    	jne    441f <ad_raw_report+0x21f>
    424d:	4c 8b 05 a4 ae 01 00 	mov    0x1aea4(%rip),%r8        # 1f0f8 <ad_raw_before_shutdown>
    4254:	45 31 c9             	xor    %r9d,%r9d
    4257:	31 c0                	xor    %eax,%eax
    4259:	31 db                	xor    %ebx,%ebx
    425b:	48 8b 0d be ae 04 00 	mov    0x4aebe(%rip),%rcx        # 4f120 <ad_raw_total_peak>
    4262:	48 8b 3d d7 ad 00 00 	mov    0xadd7(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4269:	49 89 e4             	mov    %rsp,%r12
    426c:	48 8d 15 9d 74 00 00 	lea    0x749d(%rip),%rdx        # b710 <_IO_stdin_used+0x710>
    4273:	be 02 00 00 00       	mov    $0x2,%esi
    4278:	4c 8d 3d 01 af 04 00 	lea    0x4af01(%rip),%r15        # 4f180 <ad_raw_peak>
    427f:	4c 8d 35 ba ae 04 00 	lea    0x4aeba(%rip),%r14        # 4f140 <ad_raw_bytes>
    4286:	e8 e5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    428b:	48 8d 05 99 6d 00 00 	lea    0x6d99(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    4292:	f3 0f 7e 05 76 a9 00 	movq   0xa976(%rip),%xmm0        # ec10 <d0+0x70>
    4299:	00 
    429a:	4c 8d 2d bf ae 04 00 	lea    0x4aebf(%rip),%r13        # 4f160 <ad_raw_requests>
    42a1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42a6:	48 8d 05 8f 6d 00 00 	lea    0x6d8f(%rip),%rax        # b03c <_IO_stdin_used+0x3c>
    42ad:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42b1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42b6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42ba:	f3 0f 7e 05 56 a9 00 	movq   0xa956(%rip),%xmm0        # ec18 <d0+0x78>
    42c1:	00 
    42c2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42c6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42cb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42cf:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42d3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42d8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42dc:	48 85 db             	test   %rbx,%rbx
    42df:	0f 84 0b 01 00 00    	je     43f0 <ad_raw_report+0x1f0>
    42e5:	52                   	push   %rdx
    42e6:	48 8b 3d 53 ad 00 00 	mov    0xad53(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    42ed:	48 8d 0d 2c 6d 00 00 	lea    0x6d2c(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    42f4:	48 8d 15 75 74 00 00 	lea    0x7475(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    42fb:	50                   	push   %rax
    42fc:	be 02 00 00 00       	mov    $0x2,%esi
    4301:	31 c0                	xor    %eax,%eax
    4303:	48 83 c3 01          	add    $0x1,%rbx
    4307:	e8 64 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    430c:	5f                   	pop    %rdi
    430d:	41 58                	pop    %r8
    430f:	48 83 fb 04          	cmp    $0x4,%rbx
    4313:	75 b6                	jne    42cb <ad_raw_report+0xcb>
    4315:	48 8b 0d 24 ad 00 00 	mov    0xad24(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    431c:	ba 13 00 00 00       	mov    $0x13,%edx
    4321:	be 01 00 00 00       	mov    $0x1,%esi
    4326:	48 8d 3d 18 6d 00 00 	lea    0x6d18(%rip),%rdi        # b045 <_IO_stdin_used+0x45>
    432d:	e8 2e f3 ff ff       	call   3660 <fwrite@plt>
    4332:	48 83 3d c6 ad 01 00 	cmpq   $0x0,0x1adc6(%rip)        # 1f100 <ad_raw_checkpoint_count>
    4339:	00 
    433a:	74 75                	je     43b1 <ad_raw_report+0x1b1>
    433c:	4c 8b 05 dd ad 01 00 	mov    0x1addd(%rip),%r8        # 1f120 <ad_raw_checkpoints>
    4343:	4c 8b 0d de ad 01 00 	mov    0x1adde(%rip),%r9        # 1f128 <ad_raw_checkpoints+0x8>
    434a:	48 8d 1d cf ad 01 00 	lea    0x1adcf(%rip),%rbx        # 1f120 <ad_raw_checkpoints>
    4351:	48 8d 0d 14 6d 00 00 	lea    0x6d14(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    4358:	48 8b 05 d1 ad 01 00 	mov    0x1add1(%rip),%rax        # 1f130 <ad_raw_checkpoints+0x10>
    435f:	4c 8d 25 ba 6c 00 00 	lea    0x6cba(%rip),%r12        # b020 <_IO_stdin_used+0x20>
    4366:	eb 1b                	jmp    4383 <ad_raw_report+0x183>
    4368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    436f:	00 
    4370:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4374:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4378:	48 83 c3 18          	add    $0x18,%rbx
    437c:	4c 89 e1             	mov    %r12,%rcx
    437f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4383:	48 83 ec 08          	sub    $0x8,%rsp
    4387:	be 02 00 00 00       	mov    $0x2,%esi
    438c:	48 83 c5 01          	add    $0x1,%rbp
    4390:	48 8b 3d a9 ac 00 00 	mov    0xaca9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4397:	50                   	push   %rax
    4398:	48 8d 15 11 74 00 00 	lea    0x7411(%rip),%rdx        # b7b0 <_IO_stdin_used+0x7b0>
    439f:	31 c0                	xor    %eax,%eax
    43a1:	e8 ca f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43a6:	48 3b 2d 53 ad 01 00 	cmp    0x1ad53(%rip),%rbp        # 1f100 <ad_raw_checkpoint_count>
    43ad:	59                   	pop    %rcx
    43ae:	5e                   	pop    %rsi
    43af:	72 bf                	jb     4370 <ad_raw_report+0x170>
    43b1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43bd:	00 00 
    43bf:	75 6a                	jne    442b <ad_raw_report+0x22b>
    43c1:	48 8b 0d 78 ac 00 00 	mov    0xac78(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    43c8:	48 83 c4 38          	add    $0x38,%rsp
    43cc:	ba 04 00 00 00       	mov    $0x4,%edx
    43d1:	be 01 00 00 00       	mov    $0x1,%esi
    43d6:	5b                   	pop    %rbx
    43d7:	48 8d 3d 7b 6c 00 00 	lea    0x6c7b(%rip),%rdi        # b059 <_IO_stdin_used+0x59>
    43de:	5d                   	pop    %rbp
    43df:	41 5c                	pop    %r12
    43e1:	41 5d                	pop    %r13
    43e3:	41 5e                	pop    %r14
    43e5:	41 5f                	pop    %r15
    43e7:	e9 74 f2 ff ff       	jmp    3660 <fwrite@plt>
    43ec:	0f 1f 40 00          	nopl   0x0(%rax)
    43f0:	52                   	push   %rdx
    43f1:	be 02 00 00 00       	mov    $0x2,%esi
    43f6:	48 8b 3d 43 ac 00 00 	mov    0xac43(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    43fd:	48 8d 15 6c 73 00 00 	lea    0x736c(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    4404:	50                   	push   %rax
    4405:	48 8d 0d 60 6c 00 00 	lea    0x6c60(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    440c:	31 c0                	xor    %eax,%eax
    440e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4413:	e8 58 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4418:	58                   	pop    %rax
    4419:	5a                   	pop    %rdx
    441a:	e9 ac fe ff ff       	jmp    42cb <ad_raw_report+0xcb>
    441f:	48 8d 3d c2 72 00 00 	lea    0x72c2(%rip),%rdi        # b6e8 <_IO_stdin_used+0x6e8>
    4426:	e8 b5 fb ff ff       	call   3fe0 <ad_raw_fail>
    442b:	e8 20 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004430 <fwp_trap>:
    4430:	55                   	push   %rbp
    4431:	48 89 fd             	mov    %rdi,%rbp
    4434:	53                   	push   %rbx
    4435:	48 83 ec 08          	sub    $0x8,%rsp
    4439:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4440:	ff ff 
    4442:	e8 99 f8 ff ff       	call   3ce0 <fwp_flush>
    4447:	31 c0                	xor    %eax,%eax
    4449:	48 89 e9             	mov    %rbp,%rcx
    444c:	be 02 00 00 00       	mov    $0x2,%esi
    4451:	48 8b 3d e8 ab 00 00 	mov    0xabe8(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4458:	48 8d 15 ff 6b 00 00 	lea    0x6bff(%rip),%rdx        # b05e <_IO_stdin_used+0x5e>
    445f:	e8 0c f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4464:	48 85 db             	test   %rbx,%rbx
    4467:	74 16                	je     447f <fwp_trap+0x4f>
    4469:	48 8b 3d d0 ab 00 00 	mov    0xabd0(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4470:	e8 2b f1 ff ff       	call   35a0 <fflush@plt>
    4475:	bf 65 00 00 00       	mov    $0x65,%edi
    447a:	e8 01 f2 ff ff       	call   3680 <_Exit@plt>
    447f:	bf 65 00 00 00       	mov    $0x65,%edi
    4484:	e8 c7 f1 ff ff       	call   3650 <exit@plt>
    4489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004490 <fwp_closure_drop_push>:
    4490:	41 56                	push   %r14
    4492:	41 54                	push   %r12
    4494:	49 89 f4             	mov    %rsi,%r12
    4497:	55                   	push   %rbp
    4498:	48 89 fd             	mov    %rdi,%rbp
    449b:	53                   	push   %rbx
    449c:	48 83 ec 18          	sub    $0x18,%rsp
    44a0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44a4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44a8:	74 26                	je     44d0 <fwp_closure_drop_push+0x40>
    44aa:	4c 8b 07             	mov    (%rdi),%r8
    44ad:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44b4:	00 
    44b5:	48 83 c3 01          	add    $0x1,%rbx
    44b9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44bd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44c1:	48 83 c4 18          	add    $0x18,%rsp
    44c5:	5b                   	pop    %rbx
    44c6:	5d                   	pop    %rbp
    44c7:	41 5c                	pop    %r12
    44c9:	41 5e                	pop    %r14
    44cb:	c3                   	ret
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)
    44d0:	48 89 d8             	mov    %rbx,%rax
    44d3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44d7:	0f 85 a9 00 00 00    	jne    4586 <fwp_closure_drop_push+0xf6>
    44dd:	48 89 d9             	mov    %rbx,%rcx
    44e0:	48 c1 e1 04          	shl    $0x4,%rcx
    44e4:	48 89 cf             	mov    %rcx,%rdi
    44e7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44eb:	e8 a0 f0 ff ff       	call   3590 <malloc@plt>
    44f0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44f4:	48 85 c0             	test   %rax,%rax
    44f7:	74 5f                	je     4558 <fwp_closure_drop_push+0xc8>
    44f9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44fd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4504:	00 
    4505:	48 89 c7             	mov    %rax,%rdi
    4508:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    450c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4511:	48 89 34 24          	mov    %rsi,(%rsp)
    4515:	e8 36 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    451a:	48 8b 34 24          	mov    (%rsp),%rsi
    451e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4523:	49 89 c0             	mov    %rax,%r8
    4526:	48 8d 45 18          	lea    0x18(%rbp),%rax
    452a:	48 39 c6             	cmp    %rax,%rsi
    452d:	74 1c                	je     454b <fwp_closure_drop_push+0xbb>
    452f:	48 89 f7             	mov    %rsi,%rdi
    4532:	4c 89 04 24          	mov    %r8,(%rsp)
    4536:	e8 75 ee ff ff       	call   33b0 <free@plt>
    453b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    453f:	4c 8b 04 24          	mov    (%rsp),%r8
    4543:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    454a:	00 
    454b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    454f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4553:	e9 5d ff ff ff       	jmp    44b5 <fwp_closure_drop_push+0x25>
    4558:	48 8b 0d e1 aa 00 00 	mov    0xaae1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    455f:	ba 13 00 00 00       	mov    $0x13,%edx
    4564:	be 01 00 00 00       	mov    $0x1,%esi
    4569:	48 8d 3d 98 6a 00 00 	lea    0x6a98(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4570:	e8 eb f0 ff ff       	call   3660 <fwrite@plt>
    4575:	31 ff                	xor    %edi,%edi
    4577:	e8 24 f0 ff ff       	call   35a0 <fflush@plt>
    457c:	bf 66 00 00 00       	mov    $0x66,%edi
    4581:	e8 fa f0 ff ff       	call   3680 <_Exit@plt>
    4586:	48 8d 3d e0 6a 00 00 	lea    0x6ae0(%rip),%rdi        # b06d <_IO_stdin_used+0x6d>
    458d:	e8 9e fe ff ff       	call   4430 <fwp_trap>
    4592:	0f 1f 00             	nopl   (%rax)
    4595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    459c:	00 00 00 00 

00000000000045a0 <fwp_now_ns>:
    45a0:	53                   	push   %rbx
    45a1:	bf 01 00 00 00       	mov    $0x1,%edi
    45a6:	48 83 ec 20          	sub    $0x20,%rsp
    45aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45b1:	00 00 
    45b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45b8:	31 db                	xor    %ebx,%ebx
    45ba:	48 89 e6             	mov    %rsp,%rsi
    45bd:	e8 4e ee ff ff       	call   3410 <clock_gettime@plt>
    45c2:	85 c0                	test   %eax,%eax
    45c4:	75 52                	jne    4618 <fwp_now_ns+0x78>
    45c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45d0:	48 f7 2c 24          	imulq  (%rsp)
    45d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45db:	48 89 f7             	mov    %rsi,%rdi
    45de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45e2:	48 01 f0             	add    %rsi,%rax
    45e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ec:	00 00 80 
    45ef:	48 11 fa             	adc    %rdi,%rdx
    45f2:	31 ff                	xor    %edi,%edi
    45f4:	48 01 c6             	add    %rax,%rsi
    45f7:	48 11 d7             	adc    %rdx,%rdi
    45fa:	48 39 f1             	cmp    %rsi,%rcx
    45fd:	48 19 fb             	sbb    %rdi,%rbx
    4600:	72 27                	jb     4629 <fwp_now_ns+0x89>
    4602:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4607:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    460e:	00 00 
    4610:	75 12                	jne    4624 <fwp_now_ns+0x84>
    4612:	48 83 c4 20          	add    $0x20,%rsp
    4616:	5b                   	pop    %rbx
    4617:	c3                   	ret
    4618:	48 8d 3d 68 6a 00 00 	lea    0x6a68(%rip),%rdi        # b087 <_IO_stdin_used+0x87>
    461f:	e8 0c fe ff ff       	call   4430 <fwp_trap>
    4624:	e8 27 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4629:	48 8d 3d c0 71 00 00 	lea    0x71c0(%rip),%rdi        # b7f0 <_IO_stdin_used+0x7f0>
    4630:	e8 fb fd ff ff       	call   4430 <fwp_trap>
    4635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    463c:	00 00 00 00 

0000000000004640 <fwp_closure_drop.part.0>:
    4640:	53                   	push   %rbx
    4641:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4648:	66 0f 6f 05 40 76 00 	movdqa 0x7640(%rip),%xmm0        # bc90 <msg.4+0x20>
    464f:	00 
    4650:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4657:	00 00 
    4659:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4660:	00 
    4661:	48 89 fe             	mov    %rdi,%rsi
    4664:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4669:	48 89 e7             	mov    %rsp,%rdi
    466c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4670:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4675:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    467c:	ff ff 
    467e:	e8 0d fe ff ff       	call   4490 <fwp_closure_drop_push>
    4683:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4688:	48 85 c0             	test   %rax,%rax
    468b:	74 39                	je     46c6 <fwp_closure_drop.part.0+0x86>
    468d:	0f 1f 00             	nopl   (%rax)
    4690:	48 8b 14 24          	mov    (%rsp),%rdx
    4694:	48 83 e8 01          	sub    $0x1,%rax
    4698:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    469d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46a1:	8b 07                	mov    (%rdi),%eax
    46a3:	48 c1 e0 05          	shl    $0x5,%rax
    46a7:	48 03 05 ca 4d 06 00 	add    0x64dca(%rip),%rax        # 69478 <fwp_fns>
    46ae:	48 8b 40 18          	mov    0x18(%rax),%rax
    46b2:	48 85 c0             	test   %rax,%rax
    46b5:	74 46                	je     46fd <fwp_closure_drop.part.0+0xbd>
    46b7:	31 f6                	xor    %esi,%esi
    46b9:	ff 50 08             	call   *0x8(%rax)
    46bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46c1:	48 85 c0             	test   %rax,%rax
    46c4:	75 ca                	jne    4690 <fwp_closure_drop.part.0+0x50>
    46c6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46cd:	ff ff 00 00 00 00 
    46d3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46d7:	48 39 df             	cmp    %rbx,%rdi
    46da:	74 05                	je     46e1 <fwp_closure_drop.part.0+0xa1>
    46dc:	e8 cf ec ff ff       	call   33b0 <free@plt>
    46e1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46e8:	00 
    46e9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46f0:	00 00 
    46f2:	75 15                	jne    4709 <fwp_closure_drop.part.0+0xc9>
    46f4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46fb:	5b                   	pop    %rbx
    46fc:	c3                   	ret
    46fd:	48 8d 3d 14 71 00 00 	lea    0x7114(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    4704:	e8 27 fd ff ff       	call   4430 <fwp_trap>
    4709:	e8 42 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    470e:	66 90                	xchg   %ax,%ax

0000000000004710 <fwp_tape_of>:
    4710:	0f b7 d7             	movzwl %di,%edx
    4713:	48 85 d2             	test   %rdx,%rdx
    4716:	74 28                	je     4740 <fwp_tape_of+0x30>
    4718:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    471c:	48 39 05 c5 a9 01 00 	cmp    %rax,0x1a9c5(%rip)        # 1f0e8 <fwp_ntapes>
    4723:	7e 1b                	jle    4740 <fwp_tape_of+0x30>
    4725:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4729:	48 03 05 c0 a9 01 00 	add    0x1a9c0(%rip),%rax        # 1f0f0 <fwp_tapes>
    4730:	8b 50 04             	mov    0x4(%rax),%edx
    4733:	85 d2                	test   %edx,%edx
    4735:	74 09                	je     4740 <fwp_tape_of+0x30>
    4737:	48 c1 ff 10          	sar    $0x10,%rdi
    473b:	39 38                	cmp    %edi,(%rax)
    473d:	75 01                	jne    4740 <fwp_tape_of+0x30>
    473f:	c3                   	ret
    4740:	48 83 ec 08          	sub    $0x8,%rsp
    4744:	48 8d 3d fd 70 00 00 	lea    0x70fd(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    474b:	e8 e0 fc ff ff       	call   4430 <fwp_trap>

0000000000004750 <fwp_format_g.constprop.0>:
    4750:	41 57                	push   %r15
    4752:	b9 40 00 00 00       	mov    $0x40,%ecx
    4757:	ba 02 00 00 00       	mov    $0x2,%edx
    475c:	4c 8d 05 40 69 00 00 	lea    0x6940(%rip),%r8        # b0a3 <_IO_stdin_used+0xa3>
    4763:	41 56                	push   %r14
    4765:	b8 01 00 00 00       	mov    $0x1,%eax
    476a:	41 55                	push   %r13
    476c:	41 54                	push   %r12
    476e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4772:	55                   	push   %rbp
    4773:	45 89 e1             	mov    %r12d,%r9d
    4776:	53                   	push   %rbx
    4777:	48 89 fb             	mov    %rdi,%rbx
    477a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4781:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4788:	00 00 
    478a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4791:	00 
    4792:	41 89 f7             	mov    %esi,%r15d
    4795:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    479a:	be 40 00 00 00       	mov    $0x40,%esi
    479f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47a4:	4c 89 f7             	mov    %r14,%rdi
    47a7:	e8 f4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47ac:	be 65 00 00 00       	mov    $0x65,%esi
    47b1:	4c 89 f7             	mov    %r14,%rdi
    47b4:	e8 b7 ec ff ff       	call   3470 <strchr@plt>
    47b9:	31 f6                	xor    %esi,%esi
    47bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    47c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47c4:	48 89 c5             	mov    %rax,%rbp
    47c7:	e8 a4 ed ff ff       	call   3570 <strtol@plt>
    47cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47d1:	49 89 c0             	mov    %rax,%r8
    47d4:	83 c0 05             	add    $0x5,%eax
    47d7:	83 f8 15             	cmp    $0x15,%eax
    47da:	0f 87 e0 01 00 00    	ja     49c0 <fwp_format_g.constprop.0+0x270>
    47e0:	45 89 e5             	mov    %r12d,%r13d
    47e3:	45 29 c5             	sub    %r8d,%r13d
    47e6:	45 85 ed             	test   %r13d,%r13d
    47e9:	0f 8e 21 01 00 00    	jle    4910 <fwp_format_g.constprop.0+0x1c0>
    47ef:	41 83 ff 01          	cmp    $0x1,%r15d
    47f3:	0f 84 17 01 00 00    	je     4910 <fwp_format_g.constprop.0+0x1c0>
    47f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47fe:	31 d2                	xor    %edx,%edx
    4800:	4d 63 df             	movslq %r15d,%r11
    4803:	3c 2d                	cmp    $0x2d,%al
    4805:	0f 94 c2             	sete   %dl
    4808:	4c 29 dd             	sub    %r11,%rbp
    480b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    480f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4813:	4d 89 f1             	mov    %r14,%r9
    4816:	4d 29 d1             	sub    %r10,%r9
    4819:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    481d:	3c 2d                	cmp    $0x2d,%al
    481f:	0f 84 fb 03 00 00    	je     4c20 <fwp_format_g.constprop.0+0x4d0>
    4825:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    482a:	b9 48 00 00 00       	mov    $0x48,%ecx
    482f:	48 89 e8             	mov    %rbp,%rax
    4832:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4836:	49 8d 72 01          	lea    0x1(%r10),%rsi
    483a:	49 83 c1 47          	add    $0x47,%r9
    483e:	45 85 c0             	test   %r8d,%r8d
    4841:	0f 88 f1 02 00 00    	js     4b38 <fwp_format_g.constprop.0+0x3e8>
    4847:	45 0f b6 12          	movzbl (%r10),%r10d
    484b:	4d 63 e0             	movslq %r8d,%r12
    484e:	44 88 10             	mov    %r10b,(%rax)
    4851:	41 83 f8 07          	cmp    $0x7,%r8d
    4855:	0f 87 2d 02 00 00    	ja     4a88 <fwp_format_g.constprop.0+0x338>
    485b:	41 f6 c4 04          	test   $0x4,%r12b
    485f:	0f 85 f2 03 00 00    	jne    4c57 <fwp_format_g.constprop.0+0x507>
    4865:	45 85 e4             	test   %r12d,%r12d
    4868:	74 12                	je     487c <fwp_format_g.constprop.0+0x12c>
    486a:	45 0f b6 06          	movzbl (%r14),%r8d
    486e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4872:	41 f6 c4 02          	test   $0x2,%r12b
    4876:	0f 85 03 04 00 00    	jne    4c7f <fwp_format_g.constprop.0+0x52f>
    487c:	4c 29 e1             	sub    %r12,%rcx
    487f:	4c 01 e7             	add    %r12,%rdi
    4882:	4c 89 fa             	mov    %r15,%rdx
    4885:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488a:	48 83 e9 01          	sub    $0x1,%rcx
    488e:	4d 63 ed             	movslq %r13d,%r13
    4891:	48 89 0c 24          	mov    %rcx,(%rsp)
    4895:	e8 b6 ec ff ff       	call   3550 <__memcpy_chk@plt>
    489a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    489f:	48 8b 0c 24          	mov    (%rsp),%rcx
    48a3:	ba 48 00 00 00       	mov    $0x48,%edx
    48a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48b0:	4c 89 c8             	mov    %r9,%rax
    48b3:	48 29 c8             	sub    %rcx,%rax
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48bd:	4c 29 c9             	sub    %r9,%rcx
    48c0:	4c 89 ea             	mov    %r13,%rdx
    48c3:	48 01 c1             	add    %rax,%rcx
    48c6:	e8 85 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	48 29 e8             	sub    %rbp,%rax
    48d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 47 c2          	cmova  %rdx,%rax
    48dd:	89 c1                	mov    %eax,%ecx
    48df:	83 f8 08             	cmp    $0x8,%eax
    48e2:	0f 83 18 02 00 00    	jae    4b00 <fwp_format_g.constprop.0+0x3b0>
    48e8:	a8 04                	test   $0x4,%al
    48ea:	0f 85 54 03 00 00    	jne    4c44 <fwp_format_g.constprop.0+0x4f4>
    48f0:	85 c0                	test   %eax,%eax
    48f2:	74 0f                	je     4903 <fwp_format_g.constprop.0+0x1b3>
    48f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48f9:	88 13                	mov    %dl,(%rbx)
    48fb:	a8 02                	test   $0x2,%al
    48fd:	0f 85 6b 03 00 00    	jne    4c6e <fwp_format_g.constprop.0+0x51e>
    4903:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4907:	eb 36                	jmp    493f <fwp_format_g.constprop.0+0x1ef>
    4909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4910:	45 31 c9             	xor    %r9d,%r9d
    4913:	45 85 ed             	test   %r13d,%r13d
    4916:	4c 8d 05 95 67 00 00 	lea    0x6795(%rip),%r8        # b0b2 <_IO_stdin_used+0xb2>
    491d:	48 89 df             	mov    %rbx,%rdi
    4920:	45 0f 49 cd          	cmovns %r13d,%r9d
    4924:	ba 02 00 00 00       	mov    $0x2,%edx
    4929:	be 90 01 00 00       	mov    $0x190,%esi
    492e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4935:	b8 01 00 00 00       	mov    $0x1,%eax
    493a:	e8 61 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    493f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4944:	48 89 df             	mov    %rbx,%rdi
    4947:	e8 24 eb ff ff       	call   3470 <strchr@plt>
    494c:	48 85 c0             	test   %rax,%rax
    494f:	74 3f                	je     4990 <fwp_format_g.constprop.0+0x240>
    4951:	48 89 df             	mov    %rbx,%rdi
    4954:	e8 e7 ea ff ff       	call   3440 <strlen@plt>
    4959:	48 85 c0             	test   %rax,%rax
    495c:	75 0b                	jne    4969 <fwp_format_g.constprop.0+0x219>
    495e:	eb 30                	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4960:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4964:	48 85 c0             	test   %rax,%rax
    4967:	74 27                	je     4990 <fwp_format_g.constprop.0+0x240>
    4969:	48 89 c2             	mov    %rax,%rdx
    496c:	48 83 e8 01          	sub    $0x1,%rax
    4970:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4974:	74 ea                	je     4960 <fwp_format_g.constprop.0+0x210>
    4976:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    497b:	0f 84 6f 01 00 00    	je     4af0 <fwp_format_g.constprop.0+0x3a0>
    4981:	0f 1f 40 00          	nopl   0x0(%rax)
    4985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    498c:	00 00 00 00 
    4990:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4997:	00 
    4998:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    499f:	00 00 
    49a1:	0f 85 ec 02 00 00    	jne    4c93 <fwp_format_g.constprop.0+0x543>
    49a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ae:	5b                   	pop    %rbx
    49af:	5d                   	pop    %rbp
    49b0:	41 5c                	pop    %r12
    49b2:	41 5d                	pop    %r13
    49b4:	41 5e                	pop    %r14
    49b6:	41 5f                	pop    %r15
    49b8:	c3                   	ret
    49b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49c0:	4c 29 f5             	sub    %r14,%rbp
    49c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49c8:	4c 89 f6             	mov    %r14,%rsi
    49cb:	4c 89 04 24          	mov    %r8,(%rsp)
    49cf:	49 89 ec             	mov    %rbp,%r12
    49d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49d7:	4c 89 e2             	mov    %r12,%rdx
    49da:	48 89 ef             	mov    %rbp,%rdi
    49dd:	e8 6e eb ff ff       	call   3550 <__memcpy_chk@plt>
    49e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ed:	48 89 ef             	mov    %rbp,%rdi
    49f0:	e8 7b ea ff ff       	call   3470 <strchr@plt>
    49f5:	4c 8b 04 24          	mov    (%rsp),%r8
    49f9:	48 85 c0             	test   %rax,%rax
    49fc:	74 40                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    49fe:	4d 85 e4             	test   %r12,%r12
    4a01:	74 3b                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a03:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a08:	eb 23                	jmp    4a2d <fwp_format_g.constprop.0+0x2dd>
    4a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a11:	00 00 00 00 
    4a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a1c:	00 00 00 00 
    4a20:	c6 00 00             	movb   $0x0,(%rax)
    4a23:	48 83 e8 01          	sub    $0x1,%rax
    4a27:	49 83 ec 01          	sub    $0x1,%r12
    4a2b:	74 11                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a2d:	80 38 30             	cmpb   $0x30,(%rax)
    4a30:	74 ee                	je     4a20 <fwp_format_g.constprop.0+0x2d0>
    4a32:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a38:	0f 84 fb 01 00 00    	je     4c39 <fwp_format_g.constprop.0+0x4e9>
    4a3e:	44 89 c0             	mov    %r8d,%eax
    4a41:	ba 02 00 00 00       	mov    $0x2,%edx
    4a46:	49 89 e9             	mov    %rbp,%r9
    4a49:	be 90 01 00 00       	mov    $0x190,%esi
    4a4e:	f7 d8                	neg    %eax
    4a50:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a57:	48 89 df             	mov    %rbx,%rdi
    4a5a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a5e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a62:	41 83 e0 02          	and    $0x2,%r8d
    4a66:	41 83 c0 2b          	add    $0x2b,%r8d
    4a6a:	50                   	push   %rax
    4a6b:	31 c0                	xor    %eax,%eax
    4a6d:	41 50                	push   %r8
    4a6f:	4c 8d 05 32 66 00 00 	lea    0x6632(%rip),%r8        # b0a8 <_IO_stdin_used+0xa8>
    4a76:	e8 25 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a7b:	58                   	pop    %rax
    4a7c:	5a                   	pop    %rdx
    4a7d:	e9 0e ff ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a88:	4d 8b 06             	mov    (%r14),%r8
    4a8b:	48 83 c0 09          	add    $0x9,%rax
    4a8f:	4c 89 f2             	mov    %r14,%rdx
    4a92:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a96:	4c 89 07             	mov    %r8,(%rdi)
    4a99:	45 89 e0             	mov    %r12d,%r8d
    4a9c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4aa1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4aa6:	49 89 f8             	mov    %rdi,%r8
    4aa9:	49 29 c0             	sub    %rax,%r8
    4aac:	4c 29 c2             	sub    %r8,%rdx
    4aaf:	45 01 e0             	add    %r12d,%r8d
    4ab2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ab6:	41 83 f8 08          	cmp    $0x8,%r8d
    4aba:	0f 82 bc fd ff ff    	jb     487c <fwp_format_g.constprop.0+0x12c>
    4ac0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ac4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ac8:	45 31 d2             	xor    %r10d,%r10d
    4acb:	45 89 d3             	mov    %r10d,%r11d
    4ace:	41 83 c2 08          	add    $0x8,%r10d
    4ad2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ad6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4ada:	45 39 c2             	cmp    %r8d,%r10d
    4add:	72 ec                	jb     4acb <fwp_format_g.constprop.0+0x37b>
    4adf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ae3:	e9 94 fd ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4ae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aef:	00 
    4af0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4af5:	e9 96 fe ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b00:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b05:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b09:	48 89 ee             	mov    %rbp,%rsi
    4b0c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b10:	48 89 13             	mov    %rdx,(%rbx)
    4b13:	89 c2                	mov    %eax,%edx
    4b15:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b1a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b1f:	48 89 d9             	mov    %rbx,%rcx
    4b22:	48 29 f9             	sub    %rdi,%rcx
    4b25:	48 29 ce             	sub    %rcx,%rsi
    4b28:	01 c1                	add    %eax,%ecx
    4b2a:	c1 e9 03             	shr    $0x3,%ecx
    4b2d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b30:	e9 ce fd ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4b35:	0f 1f 00             	nopl   (%rax)
    4b38:	c6 00 30             	movb   $0x30,(%rax)
    4b3b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b3f:	4c 89 fa             	mov    %r15,%rdx
    4b42:	4c 89 e9             	mov    %r13,%rcx
    4b45:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b4a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b4f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b53:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b58:	e8 f3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b5d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b62:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b67:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b6c:	48 89 c7             	mov    %rax,%rdi
    4b6f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b73:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b78:	4c 89 c8             	mov    %r9,%rax
    4b7b:	4c 29 e8             	sub    %r13,%rax
    4b7e:	48 39 c8             	cmp    %rcx,%rax
    4b81:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b85:	4d 29 cd             	sub    %r9,%r13
    4b88:	49 01 ff             	add    %rdi,%r15
    4b8b:	4c 01 e8             	add    %r13,%rax
    4b8e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b92:	74 3d                	je     4bd1 <fwp_format_g.constprop.0+0x481>
    4b94:	41 f7 d0             	not    %r8d
    4b97:	31 f6                	xor    %esi,%esi
    4b99:	ba 48 00 00 00       	mov    $0x48,%edx
    4b9e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4ba3:	48 39 d0             	cmp    %rdx,%rax
    4ba6:	48 0f 43 d0          	cmovae %rax,%rdx
    4baa:	48 89 d1             	mov    %rdx,%rcx
    4bad:	48 29 c1             	sub    %rax,%rcx
    4bb0:	48 83 c1 01          	add    $0x1,%rcx
    4bb4:	48 39 d1             	cmp    %rdx,%rcx
    4bb7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bbb:	48 83 e8 01          	sub    $0x1,%rax
    4bbf:	48 83 c6 01          	add    $0x1,%rsi
    4bc3:	48 29 d0             	sub    %rdx,%rax
    4bc6:	48 01 c8             	add    %rcx,%rax
    4bc9:	41 39 f0             	cmp    %esi,%r8d
    4bcc:	7f cb                	jg     4b99 <fwp_format_g.constprop.0+0x449>
    4bce:	4d 01 c7             	add    %r8,%r15
    4bd1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bd6:	41 0f b6 12          	movzbl (%r10),%edx
    4bda:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bde:	4c 89 f6             	mov    %r14,%rsi
    4be1:	48 39 c8             	cmp    %rcx,%rax
    4be4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4be8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bec:	41 88 17             	mov    %dl,(%r15)
    4bef:	48 89 ca             	mov    %rcx,%rdx
    4bf2:	48 29 c2             	sub    %rax,%rdx
    4bf5:	48 83 c2 01          	add    $0x1,%rdx
    4bf9:	48 39 ca             	cmp    %rcx,%rdx
    4bfc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c00:	48 83 e8 01          	sub    $0x1,%rax
    4c04:	48 29 c8             	sub    %rcx,%rax
    4c07:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c0b:	49 63 d4             	movslq %r12d,%rdx
    4c0e:	e8 3d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c13:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c17:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c1b:	e9 ae fc ff ff       	jmp    48ce <fwp_format_g.constprop.0+0x17e>
    4c20:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c25:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c2a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c2f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c34:	e9 f9 fb ff ff       	jmp    4832 <fwp_format_g.constprop.0+0xe2>
    4c39:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c3f:	e9 fa fd ff ff       	jmp    4a3e <fwp_format_g.constprop.0+0x2ee>
    4c44:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c48:	89 13                	mov    %edx,(%rbx)
    4c4a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c4e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c52:	e9 ac fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c57:	41 8b 06             	mov    (%r14),%eax
    4c5a:	89 07                	mov    %eax,(%rdi)
    4c5c:	44 89 e0             	mov    %r12d,%eax
    4c5f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c64:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c69:	e9 0e fc ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c6e:	89 c2                	mov    %eax,%edx
    4c70:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c75:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c7a:	e9 84 fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c7f:	44 89 e0             	mov    %r12d,%eax
    4c82:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c88:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c8e:	e9 e9 fb ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c93:	e8 b8 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c9f:	00 

0000000000004ca0 <fwp_heap_report>:
    4ca0:	f3 0f 1e fa          	endbr64
    4ca4:	41 54                	push   %r12
    4ca6:	48 8d 3d 0a 64 00 00 	lea    0x640a(%rip),%rdi        # b0b7 <_IO_stdin_used+0xb7>
    4cad:	55                   	push   %rbp
    4cae:	53                   	push   %rbx
    4caf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cb6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cbd:	00 00 
    4cbf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4cc6:	00 
    4cc7:	48 8d 35 74 65 00 00 	lea    0x6574(%rip),%rsi        # b242 <_IO_stdin_used+0x242>
    4cce:	e8 3d e9 ff ff       	call   3610 <fopen@plt>
    4cd3:	48 85 c0             	test   %rax,%rax
    4cd6:	0f 84 c5 00 00 00    	je     4da1 <fwp_heap_report+0x101>
    4cdc:	48 89 c5             	mov    %rax,%rbp
    4cdf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ce6:	48 89 e3             	mov    %rsp,%rbx
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	48 89 ea             	mov    %rbp,%rdx
    4cf3:	be 00 01 00 00       	mov    $0x100,%esi
    4cf8:	48 89 df             	mov    %rbx,%rdi
    4cfb:	e8 f0 e7 ff ff       	call   34f0 <fgets@plt>
    4d00:	48 85 c0             	test   %rax,%rax
    4d03:	74 2b                	je     4d30 <fwp_heap_report+0x90>
    4d05:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d0b:	75 e3                	jne    4cf0 <fwp_heap_report+0x50>
    4d0d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d11:	75 dd                	jne    4cf0 <fwp_heap_report+0x50>
    4d13:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d18:	75 d6                	jne    4cf0 <fwp_heap_report+0x50>
    4d1a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d1f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d24:	31 f6                	xor    %esi,%esi
    4d26:	e8 45 e8 ff ff       	call   3570 <strtol@plt>
    4d2b:	49 89 c4             	mov    %rax,%r12
    4d2e:	eb c0                	jmp    4cf0 <fwp_heap_report+0x50>
    4d30:	48 89 ef             	mov    %rbp,%rdi
    4d33:	e8 f8 e6 ff ff       	call   3430 <fclose@plt>
    4d38:	48 83 ec 08          	sub    $0x8,%rsp
    4d3c:	4c 8b 0d a5 3e 06 00 	mov    0x63ea5(%rip),%r9        # 68be8 <fwp_heap+0x13c8>
    4d43:	4c 8b 05 fe 3e 06 00 	mov    0x63efe(%rip),%r8        # 68c48 <fwp_heap+0x1428>
    4d4a:	48 8d 15 47 6b 00 00 	lea    0x6b47(%rip),%rdx        # b898 <_IO_stdin_used+0x898>
    4d51:	41 54                	push   %r12
    4d53:	48 8b 0d e6 3e 06 00 	mov    0x63ee6(%rip),%rcx        # 68c40 <fwp_heap+0x1420>
    4d5a:	be 02 00 00 00       	mov    $0x2,%esi
    4d5f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d64:	f2 0f 10 0d f4 3e 06 	movsd  0x63ef4(%rip),%xmm1        # 68c60 <fwp_heap+0x1440>
    4d6b:	00 
    4d6c:	f2 0f 10 05 e4 3e 06 	movsd  0x63ee4(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    4d73:	00 
    4d74:	48 8b 3d c5 a2 00 00 	mov    0xa2c5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d7b:	e8 f0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4d80:	58                   	pop    %rax
    4d81:	5a                   	pop    %rdx
    4d82:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d89:	00 
    4d8a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d91:	00 00 
    4d93:	75 15                	jne    4daa <fwp_heap_report+0x10a>
    4d95:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d9c:	5b                   	pop    %rbx
    4d9d:	5d                   	pop    %rbp
    4d9e:	41 5c                	pop    %r12
    4da0:	c3                   	ret
    4da1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4da8:	eb 8e                	jmp    4d38 <fwp_heap_report+0x98>
    4daa:	e8 a1 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4daf:	90                   	nop

0000000000004db0 <fwp_heap_init>:
    4db0:	66 0f 6f 05 e8 6e 00 	movdqa 0x6ee8(%rip),%xmm0        # bca0 <msg.4+0x30>
    4db7:	00 
    4db8:	41 54                	push   %r12
    4dba:	48 8d 05 9f 39 06 00 	lea    0x6399f(%rip),%rax        # 68760 <fwp_heap+0xf40>
    4dc1:	ba 00 01 00 00       	mov    $0x100,%edx
    4dc6:	55                   	push   %rbp
    4dc7:	66 0f 6f 15 11 6f 00 	movdqa 0x6f11(%rip),%xmm2        # bce0 <msg.4+0x70>
    4dce:	00 
    4dcf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4dd3:	53                   	push   %rbx
    4dd4:	0f 29 05 45 39 06 00 	movaps %xmm0,0x63945(%rip)        # 68720 <fwp_heap+0xf00>
    4ddb:	66 0f 6f 05 cd 6e 00 	movdqa 0x6ecd(%rip),%xmm0        # bcb0 <msg.4+0x40>
    4de2:	00 
    4de3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4de7:	c7 05 d3 3d 06 00 01 	movl   $0x1,0x63dd3(%rip)        # 68bc4 <fwp_heap+0x13a4>
    4dee:	00 00 00 
    4df1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4df6:	0f 29 05 33 39 06 00 	movaps %xmm0,0x63933(%rip)        # 68730 <fwp_heap+0xf10>
    4dfd:	66 0f 6f 05 bb 6e 00 	movdqa 0x6ebb(%rip),%xmm0        # bcc0 <msg.4+0x50>
    4e04:	00 
    4e05:	0f 29 05 34 39 06 00 	movaps %xmm0,0x63934(%rip)        # 68740 <fwp_heap+0xf20>
    4e0c:	66 0f 6f 05 bc 6e 00 	movdqa 0x6ebc(%rip),%xmm0        # bcd0 <msg.4+0x60>
    4e13:	00 
    4e14:	0f 29 05 35 39 06 00 	movaps %xmm0,0x63935(%rip)        # 68750 <fwp_heap+0xf30>
    4e1b:	89 d3                	mov    %edx,%ebx
    4e1d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e21:	48 83 c0 10          	add    $0x10,%rax
    4e25:	01 d2                	add    %edx,%edx
    4e27:	c1 eb 02             	shr    $0x2,%ebx
    4e2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e5f:	48 39 c7             	cmp    %rax,%rdi
    4e62:	75 b7                	jne    4e1b <fwp_heap_init+0x6b>
    4e64:	4c 8d 05 b5 29 06 00 	lea    0x629b5(%rip),%r8        # 67820 <fwp_heap>
    4e6b:	31 c9                	xor    %ecx,%ecx
    4e6d:	31 c0                	xor    %eax,%eax
    4e6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e7d:	00 00 00 
    4e80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e87:	00 
    4e88:	48 39 ca             	cmp    %rcx,%rdx
    4e8b:	73 0f                	jae    4e9c <fwp_heap_init+0xec>
    4e8d:	0f 1f 00             	nopl   (%rax)
    4e90:	48 83 c0 01          	add    $0x1,%rax
    4e94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e97:	48 39 ca             	cmp    %rcx,%rdx
    4e9a:	72 f4                	jb     4e90 <fwp_heap_init+0xe0>
    4e9c:	48 83 c1 10          	add    $0x10,%rcx
    4ea0:	88 07                	mov    %al,(%rdi)
    4ea2:	48 83 c7 01          	add    $0x1,%rdi
    4ea6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ead:	75 d1                	jne    4e80 <fwp_heap_init+0xd0>
    4eaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4eb6:	00 00 00 
    4eb9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ebe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ec5:	45 31 c9             	xor    %r9d,%r9d
    4ec8:	31 d2                	xor    %edx,%edx
    4eca:	31 ff                	xor    %edi,%edi
    4ecc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ed2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ed7:	4c 89 e6             	mov    %r12,%rsi
    4eda:	e8 81 e5 ff ff       	call   3460 <mmap@plt>
    4edf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ee3:	75 13                	jne    4ef8 <fwp_heap_init+0x148>
    4ee5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ee9:	83 ed 01             	sub    $0x1,%ebp
    4eec:	75 d0                	jne    4ebe <fwp_heap_init+0x10e>
    4eee:	e8 1d ef ff ff       	call   3e10 <fwp_heap_oom>
    4ef3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ef8:	48 85 c0             	test   %rax,%rax
    4efb:	74 f1                	je     4eee <fwp_heap_init+0x13e>
    4efd:	48 c1 eb 10          	shr    $0x10,%rbx
    4f01:	48 89 05 d0 3c 06 00 	mov    %rax,0x63cd0(%rip)        # 68bd8 <fwp_heap+0x13b8>
    4f08:	45 31 c9             	xor    %r9d,%r9d
    4f0b:	31 d2                	xor    %edx,%edx
    4f0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f17:	31 ff                	xor    %edi,%edi
    4f19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f1f:	66 31 c0             	xor    %ax,%ax
    4f22:	48 c1 e6 03          	shl    $0x3,%rsi
    4f26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f2b:	4c 89 25 ae 3c 06 00 	mov    %r12,0x63cae(%rip)        # 68be0 <fwp_heap+0x13c0>
    4f32:	48 89 05 97 3c 06 00 	mov    %rax,0x63c97(%rip)        # 68bd0 <fwp_heap+0x13b0>
    4f39:	48 89 1d b0 3c 06 00 	mov    %rbx,0x63cb0(%rip)        # 68bf0 <fwp_heap+0x13d0>
    4f40:	48 89 35 d9 3c 06 00 	mov    %rsi,0x63cd9(%rip)        # 68c20 <fwp_heap+0x1400>
    4f47:	e8 14 e5 ff ff       	call   3460 <mmap@plt>
    4f4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f50:	74 9c                	je     4eee <fwp_heap_init+0x13e>
    4f52:	48 8d 3d 94 61 00 00 	lea    0x6194(%rip),%rdi        # b0ed <_IO_stdin_used+0xed>
    4f59:	48 89 05 b8 3c 06 00 	mov    %rax,0x63cb8(%rip)        # 68c18 <fwp_heap+0x13f8>
    4f60:	e8 2b e4 ff ff       	call   3390 <getenv@plt>
    4f65:	48 89 c2             	mov    %rax,%rdx
    4f68:	31 c0                	xor    %eax,%eax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 15                	je     4f84 <fwp_heap_init+0x1d4>
    4f6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f72:	74 10                	je     4f84 <fwp_heap_init+0x1d4>
    4f74:	0f b6 02             	movzbl (%rdx),%eax
    4f77:	83 e8 30             	sub    $0x30,%eax
    4f7a:	74 13                	je     4f8f <fwp_heap_init+0x1df>
    4f7c:	85 c0                	test   %eax,%eax
    4f7e:	0f 95 c0             	setne  %al
    4f81:	0f b6 c0             	movzbl %al,%eax
    4f84:	5b                   	pop    %rbx
    4f85:	5d                   	pop    %rbp
    4f86:	89 05 3c 3c 06 00    	mov    %eax,0x63c3c(%rip)        # 68bc8 <fwp_heap+0x13a8>
    4f8c:	41 5c                	pop    %r12
    4f8e:	c3                   	ret
    4f8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f93:	85 c0                	test   %eax,%eax
    4f95:	0f 95 c0             	setne  %al
    4f98:	0f b6 c0             	movzbl %al,%eax
    4f9b:	eb e7                	jmp    4f84 <fwp_heap_init+0x1d4>
    4f9d:	0f 1f 00             	nopl   (%rax)

0000000000004fa0 <fwp_wake_io>:
    4fa0:	48 8b 07             	mov    (%rdi),%rax
    4fa3:	48 85 c0             	test   %rax,%rax
    4fa6:	0f 84 f4 00 00 00    	je     50a0 <fwp_wake_io+0x100>
    4fac:	53                   	push   %rbx
    4fad:	4c 8b 05 2c 28 06 00 	mov    0x6282c(%rip),%r8        # 677e0 <fwp_ready_tail>
    4fb4:	49 89 f9             	mov    %rdi,%r9
    4fb7:	48 89 c2             	mov    %rax,%rdx
    4fba:	45 31 db             	xor    %r11d,%r11d
    4fbd:	45 31 d2             	xor    %r10d,%r10d
    4fc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fc4:	eb 71                	jmp    5037 <fwp_wake_io+0x97>
    4fc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fcd:	00 00 00 
    4fd0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4fd7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fde:	48 85 c9             	test   %rcx,%rcx
    4fe1:	74 07                	je     4fea <fwp_wake_io+0x4a>
    4fe3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4fea:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4ff1:	00 00 00 00 
    4ff5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ffc:	49 8b 01             	mov    (%r9),%rax
    4fff:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5003:	75 2a                	jne    502f <fwp_wake_io+0x8f>
    5005:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5009:	75 24                	jne    502f <fwp_wake_io+0x8f>
    500b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    500f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5016:	00 00 00 00 
    501a:	4d 85 c0             	test   %r8,%r8
    501d:	74 51                	je     5070 <fwp_wake_io+0xd0>
    501f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5026:	49 89 d0             	mov    %rdx,%r8
    5029:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    502f:	48 89 c2             	mov    %rax,%rdx
    5032:	48 85 c0             	test   %rax,%rax
    5035:	74 49                	je     5080 <fwp_wake_io+0xe0>
    5037:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    503e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5042:	48 85 ff             	test   %rdi,%rdi
    5045:	74 b8                	je     4fff <fwp_wake_io+0x5f>
    5047:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    504e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5055:	48 85 f6             	test   %rsi,%rsi
    5058:	0f 85 72 ff ff ff    	jne    4fd0 <fwp_wake_io+0x30>
    505e:	48 89 0f             	mov    %rcx,(%rdi)
    5061:	e9 78 ff ff ff       	jmp    4fde <fwp_wake_io+0x3e>
    5066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    506d:	00 00 00 
    5070:	48 89 d3             	mov    %rdx,%rbx
    5073:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5079:	eb ab                	jmp    5026 <fwp_wake_io+0x86>
    507b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5080:	45 84 db             	test   %r11b,%r11b
    5083:	74 07                	je     508c <fwp_wake_io+0xec>
    5085:	48 89 1d 5c 27 06 00 	mov    %rbx,0x6275c(%rip)        # 677e8 <fwp_ready_head>
    508c:	45 84 d2             	test   %r10b,%r10b
    508f:	74 07                	je     5098 <fwp_wake_io+0xf8>
    5091:	4c 89 05 48 27 06 00 	mov    %r8,0x62748(%rip)        # 677e0 <fwp_ready_tail>
    5098:	5b                   	pop    %rbx
    5099:	c3                   	ret
    509a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50a0:	c3                   	ret
    50a1:	0f 1f 40 00          	nopl   0x0(%rax)
    50a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50ac:	00 00 00 00 

00000000000050b0 <ad_raw_free.part.0>:
    50b0:	48 8d 0d 09 a1 04 00 	lea    0x4a109(%rip),%rcx        # 4f1c0 <ad_raw_blocks>
    50b7:	31 c0                	xor    %eax,%eax
    50b9:	48 89 ca             	mov    %rcx,%rdx
    50bc:	eb 12                	jmp    50d0 <ad_raw_free.part.0+0x20>
    50be:	66 90                	xchg   %ax,%ax
    50c0:	48 83 c0 01          	add    $0x1,%rax
    50c4:	48 83 c2 18          	add    $0x18,%rdx
    50c8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ce:	74 40                	je     5110 <ad_raw_free.part.0+0x60>
    50d0:	48 3b 3a             	cmp    (%rdx),%rdi
    50d3:	75 eb                	jne    50c0 <ad_raw_free.part.0+0x10>
    50d5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50d9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50dd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    50e1:	48 8d 0d b8 a0 04 00 	lea    0x4a0b8(%rip),%rcx        # 4f1a0 <ad_raw_live>
    50e8:	8b 70 10             	mov    0x10(%rax),%esi
    50eb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    50f2:	00 
    50f3:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    50f7:	48 2b 50 08          	sub    0x8(%rax),%rdx
    50fb:	0f 11 00             	movups %xmm0,(%rax)
    50fe:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5102:	e9 a9 e2 ff ff       	jmp    33b0 <free@plt>
    5107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    510e:	00 00 
    5110:	48 83 ec 08          	sub    $0x8,%rsp
    5114:	48 8d 3d e2 5f 00 00 	lea    0x5fe2(%rip),%rdi        # b0fd <_IO_stdin_used+0xfd>
    511b:	e8 c0 ee ff ff       	call   3fe0 <ad_raw_fail>

0000000000005120 <fwp_tape_buffers_dispose>:
    5120:	53                   	push   %rbx
    5121:	48 89 fb             	mov    %rdi,%rbx
    5124:	48 8b 3f             	mov    (%rdi),%rdi
    5127:	48 85 ff             	test   %rdi,%rdi
    512a:	74 05                	je     5131 <fwp_tape_buffers_dispose+0x11>
    512c:	e8 7f ff ff ff       	call   50b0 <ad_raw_free.part.0>
    5131:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5135:	48 85 ff             	test   %rdi,%rdi
    5138:	74 05                	je     513f <fwp_tape_buffers_dispose+0x1f>
    513a:	e8 71 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    513f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5143:	48 85 ff             	test   %rdi,%rdi
    5146:	74 05                	je     514d <fwp_tape_buffers_dispose+0x2d>
    5148:	e8 63 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    514d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5151:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5158:	00 
    5159:	0f 11 03             	movups %xmm0,(%rbx)
    515c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5160:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5164:	5b                   	pop    %rbx
    5165:	c3                   	ret
    5166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    516d:	00 00 00 

0000000000005170 <ad_raw_realloc>:
    5170:	41 55                	push   %r13
    5172:	41 54                	push   %r12
    5174:	55                   	push   %rbp
    5175:	53                   	push   %rbx
    5176:	48 83 ec 08          	sub    $0x8,%rsp
    517a:	48 85 f6             	test   %rsi,%rsi
    517d:	0f 84 a6 00 00 00    	je     5229 <ad_raw_realloc+0xb9>
    5183:	4c 8d 25 36 a0 04 00 	lea    0x4a036(%rip),%r12        # 4f1c0 <ad_raw_blocks>
    518a:	48 89 f5             	mov    %rsi,%rbp
    518d:	41 89 d5             	mov    %edx,%r13d
    5190:	31 db                	xor    %ebx,%ebx
    5192:	4c 89 e0             	mov    %r12,%rax
    5195:	eb 1a                	jmp    51b1 <ad_raw_realloc+0x41>
    5197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    519e:	00 00 
    51a0:	48 83 c3 01          	add    $0x1,%rbx
    51a4:	48 83 c0 18          	add    $0x18,%rax
    51a8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51af:	74 4f                	je     5200 <ad_raw_realloc+0x90>
    51b1:	48 3b 38             	cmp    (%rax),%rdi
    51b4:	75 ea                	jne    51a0 <ad_raw_realloc+0x30>
    51b6:	48 85 ff             	test   %rdi,%rdi
    51b9:	74 0b                	je     51c6 <ad_raw_realloc+0x56>
    51bb:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51bf:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51c4:	75 57                	jne    521d <ad_raw_realloc+0xad>
    51c6:	48 89 ee             	mov    %rbp,%rsi
    51c9:	e8 e2 e3 ff ff       	call   35b0 <realloc@plt>
    51ce:	49 89 c2             	mov    %rax,%r10
    51d1:	48 85 c0             	test   %rax,%rax
    51d4:	74 16                	je     51ec <ad_raw_realloc+0x7c>
    51d6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51da:	44 89 e9             	mov    %r13d,%ecx
    51dd:	48 89 ea             	mov    %rbp,%rdx
    51e0:	4c 89 d6             	mov    %r10,%rsi
    51e3:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    51e7:	e8 f4 e9 ff ff       	call   3be0 <ad_raw_record>
    51ec:	48 83 c4 08          	add    $0x8,%rsp
    51f0:	4c 89 d0             	mov    %r10,%rax
    51f3:	5b                   	pop    %rbx
    51f4:	5d                   	pop    %rbp
    51f5:	41 5c                	pop    %r12
    51f7:	41 5d                	pop    %r13
    51f9:	c3                   	ret
    51fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5200:	48 85 ff             	test   %rdi,%rdi
    5203:	48 8d 05 08 5f 00 00 	lea    0x5f08(%rip),%rax        # b112 <_IO_stdin_used+0x112>
    520a:	48 8d 15 ec 5e 00 00 	lea    0x5eec(%rip),%rdx        # b0fd <_IO_stdin_used+0xfd>
    5211:	48 0f 45 c2          	cmovne %rdx,%rax
    5215:	48 89 c7             	mov    %rax,%rdi
    5218:	e8 c3 ed ff ff       	call   3fe0 <ad_raw_fail>
    521d:	48 8d 3d 24 5f 00 00 	lea    0x5f24(%rip),%rdi        # b148 <_IO_stdin_used+0x148>
    5224:	e8 b7 ed ff ff       	call   3fe0 <ad_raw_fail>
    5229:	48 8d 3d fd 5e 00 00 	lea    0x5efd(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    5230:	e8 ab ed ff ff       	call   3fe0 <ad_raw_fail>
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 

0000000000005240 <fwp_tape_buffers_release>:
    5240:	f3 0f 1e fa          	endbr64
    5244:	53                   	push   %rbx
    5245:	48 89 fb             	mov    %rdi,%rbx
    5248:	48 83 ec 10          	sub    $0x10,%rsp
    524c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5250:	48 85 c0             	test   %rax,%rax
    5253:	0f 88 d7 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5259:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    525d:	48 85 d2             	test   %rdx,%rdx
    5260:	0f 88 ca 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5266:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    526c:	0f 87 be 00 00 00    	ja     5330 <fwp_tape_buffers_release+0xf0>
    5272:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5276:	b8 00 00 08 00       	mov    $0x80000,%eax
    527b:	48 c1 e1 03          	shl    $0x3,%rcx
    527f:	48 29 c8             	sub    %rcx,%rax
    5282:	48 c1 e8 03          	shr    $0x3,%rax
    5286:	48 39 d0             	cmp    %rdx,%rax
    5289:	0f 82 a1 00 00 00    	jb     5330 <fwp_tape_buffers_release+0xf0>
    528f:	48 8d 3d ca 5e 00 00 	lea    0x5eca(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5296:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    529b:	48 89 14 24          	mov    %rdx,(%rsp)
    529f:	e8 ec e0 ff ff       	call   3390 <getenv@plt>
    52a4:	48 8b 14 24          	mov    (%rsp),%rdx
    52a8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52ad:	48 85 c0             	test   %rax,%rax
    52b0:	74 09                	je     52bb <fwp_tape_buffers_release+0x7b>
    52b2:	80 38 30             	cmpb   $0x30,(%rax)
    52b5:	0f 84 05 01 00 00    	je     53c0 <fwp_tape_buffers_release+0x180>
    52bb:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52bf:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52c3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52c9:	77 71                	ja     533c <fwp_tape_buffers_release+0xfc>
    52cb:	48 8d 3d ce 9d 01 00 	lea    0x19dce(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    52d2:	48 89 34 24          	mov    %rsi,(%rsp)
    52d6:	e8 45 fe ff ff       	call   5120 <fwp_tape_buffers_dispose>
    52db:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52df:	48 8b 34 24          	mov    (%rsp),%rsi
    52e3:	0f 29 05 b6 9d 01 00 	movaps %xmm0,0x19db6(%rip)        # 1f0a0 <fwp_tape_workspace>
    52ea:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    52ef:	48 89 35 92 9d 01 00 	mov    %rsi,0x19d92(%rip)        # 1f088 <fwp_tape_cached_bytes>
    52f6:	0f 29 05 b3 9d 01 00 	movaps %xmm0,0x19db3(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    52fd:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5302:	0f 29 05 b7 9d 01 00 	movaps %xmm0,0x19db7(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    5309:	48 8b 43 30          	mov    0x30(%rbx),%rax
    530d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5311:	48 89 05 b8 9d 01 00 	mov    %rax,0x19db8(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    5318:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    531f:	00 
    5320:	0f 11 03             	movups %xmm0,(%rbx)
    5323:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5327:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    532b:	eb 1e                	jmp    534b <fwp_tape_buffers_release+0x10b>
    532d:	0f 1f 00             	nopl   (%rax)
    5330:	48 8d 3d 29 5e 00 00 	lea    0x5e29(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5337:	e8 54 e0 ff ff       	call   3390 <getenv@plt>
    533c:	48 89 df             	mov    %rbx,%rdi
    533f:	e8 dc fd ff ff       	call   5120 <fwp_tape_buffers_dispose>
    5344:	48 8b 35 3d 9d 01 00 	mov    0x19d3d(%rip),%rsi        # 1f088 <fwp_tape_cached_bytes>
    534b:	48 6b 15 8d 9d 01 00 	imul   $0x68,0x19d8d(%rip),%rdx        # 1f0e0 <fwp_tapes_cap>
    5352:	68 
    5353:	48 3b 15 46 9e 04 00 	cmp    0x49e46(%rip),%rdx        # 4f1a0 <ad_raw_live>
    535a:	75 73                	jne    53cf <fwp_tape_buffers_release+0x18f>
    535c:	48 8b 05 45 9e 04 00 	mov    0x49e45(%rip),%rax        # 4f1a8 <ad_raw_live+0x8>
    5363:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5367:	48 01 d0             	add    %rdx,%rax
    536a:	48 03 05 3f 9e 04 00 	add    0x49e3f(%rip),%rax        # 4f1b0 <ad_raw_live+0x10>
    5371:	48 03 05 40 9e 04 00 	add    0x49e40(%rip),%rax        # 4f1b8 <ad_raw_live+0x18>
    5378:	48 39 c8             	cmp    %rcx,%rax
    537b:	72 52                	jb     53cf <fwp_tape_buffers_release+0x18f>
    537d:	48 8b 0d 7c 9d 01 00 	mov    0x19d7c(%rip),%rcx        # 1f100 <ad_raw_checkpoint_count>
    5384:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    538b:	74 4e                	je     53db <fwp_tape_buffers_release+0x19b>
    538d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5391:	48 29 d0             	sub    %rdx,%rax
    5394:	48 89 3d 65 9d 01 00 	mov    %rdi,0x19d65(%rip)        # 1f100 <ad_raw_checkpoint_count>
    539b:	48 29 f0             	sub    %rsi,%rax
    539e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53a2:	48 8d 0d 77 9d 01 00 	lea    0x19d77(%rip),%rcx        # 1f120 <ad_raw_checkpoints>
    53a9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53ad:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53b2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53b7:	48 83 c4 10          	add    $0x10,%rsp
    53bb:	5b                   	pop    %rbx
    53bc:	c3                   	ret
    53bd:	0f 1f 00             	nopl   (%rax)
    53c0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53c4:	0f 84 72 ff ff ff    	je     533c <fwp_tape_buffers_release+0xfc>
    53ca:	e9 ec fe ff ff       	jmp    52bb <fwp_tape_buffers_release+0x7b>
    53cf:	48 8d 3d 4a 65 00 00 	lea    0x654a(%rip),%rdi        # b920 <_IO_stdin_used+0x920>
    53d6:	e8 05 ec ff ff       	call   3fe0 <ad_raw_fail>
    53db:	48 8d 3d 8f 5d 00 00 	lea    0x5d8f(%rip),%rdi        # b171 <_IO_stdin_used+0x171>
    53e2:	e8 f9 eb ff ff       	call   3fe0 <ad_raw_fail>
    53e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53ee:	00 00 

00000000000053f0 <fwp_poll_events>:
    53f0:	53                   	push   %rbx
    53f1:	48 83 ec 20          	sub    $0x20,%rsp
    53f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    53fc:	00 00 
    53fe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5403:	31 c0                	xor    %eax,%eax
    5405:	e8 96 f1 ff ff       	call   45a0 <fwp_now_ns>
    540a:	48 8b 1d c7 23 06 00 	mov    0x623c7(%rip),%rbx        # 677d8 <fwp_timers>
    5411:	48 85 db             	test   %rbx,%rbx
    5414:	0f 84 e6 00 00 00    	je     5500 <fwp_poll_events+0x110>
    541a:	48 89 c6             	mov    %rax,%rsi
    541d:	48 89 da             	mov    %rbx,%rdx
    5420:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5427:	eb 26                	jmp    544f <fwp_poll_events+0x5f>
    5429:	90                   	nop
    542a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5431:	00 00 00 00 
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5447:	48 89 c8             	mov    %rcx,%rax
    544a:	48 85 d2             	test   %rdx,%rdx
    544d:	74 31                	je     5480 <fwp_poll_events+0x90>
    544f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5453:	48 85 c0             	test   %rax,%rax
    5456:	78 e8                	js     5440 <fwp_poll_events+0x50>
    5458:	48 39 c1             	cmp    %rax,%rcx
    545b:	7c e3                	jl     5440 <fwp_poll_events+0x50>
    545d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5464:	48 85 d2             	test   %rdx,%rdx
    5467:	74 1c                	je     5485 <fwp_poll_events+0x95>
    5469:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    546d:	48 39 c1             	cmp    %rax,%rcx
    5470:	7c ce                	jl     5440 <fwp_poll_events+0x50>
    5472:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5479:	48 85 d2             	test   %rdx,%rdx
    547c:	75 d1                	jne    544f <fwp_poll_events+0x5f>
    547e:	66 90                	xchg   %ax,%ax
    5480:	48 85 c0             	test   %rax,%rax
    5483:	78 7b                	js     5500 <fwp_poll_events+0x110>
    5485:	48 29 f0             	sub    %rsi,%rax
    5488:	48 89 c1             	mov    %rax,%rcx
    548b:	48 85 c0             	test   %rax,%rax
    548e:	0f 8e 9c 00 00 00    	jle    5530 <fwp_poll_events+0x140>
    5494:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    549b:	de 1b 43 
    549e:	48 f7 ea             	imul   %rdx
    54a1:	48 89 c8             	mov    %rcx,%rax
    54a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54a8:	48 c1 fa 12          	sar    $0x12,%rdx
    54ac:	48 29 c2             	sub    %rax,%rdx
    54af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54b6:	48 39 c1             	cmp    %rax,%rcx
    54b9:	0f 95 c0             	setne  %al
    54bc:	0f b6 c0             	movzbl %al,%eax
    54bf:	48 01 d0             	add    %rdx,%rax
    54c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54c8:	0f 8f 32 01 00 00    	jg     5600 <fwp_poll_events+0x210>
    54ce:	48 85 c0             	test   %rax,%rax
    54d1:	74 5d                	je     5530 <fwp_poll_events+0x140>
    54d3:	89 c1                	mov    %eax,%ecx
    54d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54dc:	48 c1 e9 26          	shr    $0x26,%rcx
    54e0:	48 63 d1             	movslq %ecx,%rdx
    54e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    54e9:	29 c8                	sub    %ecx,%eax
    54eb:	48 98                	cltq
    54ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    54f4:	e9 11 01 00 00       	jmp    560a <fwp_poll_events+0x21a>
    54f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5500:	e8 db e7 ff ff       	call   3ce0 <fwp_flush>
    5505:	ba 2b 00 00 00       	mov    $0x2b,%edx
    550a:	be 01 00 00 00       	mov    $0x1,%esi
    550f:	48 8b 0d 2a 9b 00 00 	mov    0x9b2a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5516:	48 8d 3d 33 64 00 00 	lea    0x6433(%rip),%rdi        # b950 <_IO_stdin_used+0x950>
    551d:	e8 3e e1 ff ff       	call   3660 <fwrite@plt>
    5522:	bf 65 00 00 00       	mov    $0x65,%edi
    5527:	e8 24 e1 ff ff       	call   3650 <exit@plt>
    552c:	0f 1f 40 00          	nopl   0x0(%rax)
    5530:	e8 6b f0 ff ff       	call   45a0 <fwp_now_ns>
    5535:	48 89 c1             	mov    %rax,%rcx
    5538:	66 0f ef c0          	pxor   %xmm0,%xmm0
    553c:	eb 44                	jmp    5582 <fwp_poll_events+0x192>
    553e:	66 90                	xchg   %ax,%ax
    5540:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5544:	75 33                	jne    5579 <fwp_poll_events+0x189>
    5546:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    554a:	75 2d                	jne    5579 <fwp_poll_events+0x189>
    554c:	48 8b 05 8d 22 06 00 	mov    0x6228d(%rip),%rax        # 677e0 <fwp_ready_tail>
    5553:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5557:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    555e:	00 00 00 00 
    5562:	48 85 c0             	test   %rax,%rax
    5565:	0f 84 05 01 00 00    	je     5670 <fwp_poll_events+0x280>
    556b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5572:	48 89 15 67 22 06 00 	mov    %rdx,0x62267(%rip)        # 677e0 <fwp_ready_tail>
    5579:	48 85 db             	test   %rbx,%rbx
    557c:	0f 84 be 00 00 00    	je     5640 <fwp_poll_events+0x250>
    5582:	48 89 da             	mov    %rbx,%rdx
    5585:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    558c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5590:	7f e7                	jg     5579 <fwp_poll_events+0x189>
    5592:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5596:	74 2e                	je     55c6 <fwp_poll_events+0x1d6>
    5598:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    559f:	48 85 c0             	test   %rax,%rax
    55a2:	0f 84 b8 00 00 00    	je     5660 <fwp_poll_events+0x270>
    55a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55af:	48 85 db             	test   %rbx,%rbx
    55b2:	74 07                	je     55bb <fwp_poll_events+0x1cb>
    55b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ce:	48 85 c0             	test   %rax,%rax
    55d1:	0f 84 69 ff ff ff    	je     5540 <fwp_poll_events+0x150>
    55d7:	48 39 c8             	cmp    %rcx,%rax
    55da:	0f 8f 60 ff ff ff    	jg     5540 <fwp_poll_events+0x150>
    55e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    55e4:	0f 85 56 ff ff ff    	jne    5540 <fwp_poll_events+0x150>
    55ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ee:	75 89                	jne    5579 <fwp_poll_events+0x189>
    55f0:	48 89 d7             	mov    %rdx,%rdi
    55f3:	e8 18 eb ff ff       	call   4110 <fwp_cancel_tree.part.0>
    55f8:	e9 43 ff ff ff       	jmp    5540 <fwp_poll_events+0x150>
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5605:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    560a:	48 89 e7             	mov    %rsp,%rdi
    560d:	31 f6                	xor    %esi,%esi
    560f:	48 89 14 24          	mov    %rdx,(%rsp)
    5613:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5618:	e8 73 de ff ff       	call   3490 <nanosleep@plt>
    561d:	48 8b 1d b4 21 06 00 	mov    0x621b4(%rip),%rbx        # 677d8 <fwp_timers>
    5624:	e8 77 ef ff ff       	call   45a0 <fwp_now_ns>
    5629:	48 89 c1             	mov    %rax,%rcx
    562c:	48 85 db             	test   %rbx,%rbx
    562f:	0f 85 03 ff ff ff    	jne    5538 <fwp_poll_events+0x148>
    5635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    563c:	00 00 00 00 
    5640:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5645:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    564c:	00 00 
    564e:	75 2c                	jne    567c <fwp_poll_events+0x28c>
    5650:	48 83 c4 20          	add    $0x20,%rsp
    5654:	5b                   	pop    %rbx
    5655:	c3                   	ret
    5656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    565d:	00 00 00 
    5660:	48 89 1d 71 21 06 00 	mov    %rbx,0x62171(%rip)        # 677d8 <fwp_timers>
    5667:	e9 43 ff ff ff       	jmp    55af <fwp_poll_events+0x1bf>
    566c:	0f 1f 40 00          	nopl   0x0(%rax)
    5670:	48 89 15 71 21 06 00 	mov    %rdx,0x62171(%rip)        # 677e8 <fwp_ready_head>
    5677:	e9 f6 fe ff ff       	jmp    5572 <fwp_poll_events+0x182>
    567c:	e8 cf dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5681:	0f 1f 40 00          	nopl   0x0(%rax)
    5685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    568c:	00 00 00 00 

0000000000005690 <fwp_rc_wide_dup>:
    5690:	48 89 fa             	mov    %rdi,%rdx
    5693:	48 8d 35 86 21 06 00 	lea    0x62186(%rip),%rsi        # 67820 <fwp_heap>
    569a:	48 83 ec 18          	sub    $0x18,%rsp
    569e:	48 89 f9             	mov    %rdi,%rcx
    56a1:	48 c1 ea 11          	shr    $0x11,%rdx
    56a5:	48 31 fa             	xor    %rdi,%rdx
    56a8:	48 89 d0             	mov    %rdx,%rax
    56ab:	48 c1 e8 09          	shr    $0x9,%rax
    56af:	48 31 c2             	xor    %rax,%rdx
    56b2:	0f b6 d2             	movzbl %dl,%edx
    56b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56bc:	00 
    56bd:	49 8b 00             	mov    (%r8),%rax
    56c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56c7:	00 00 
    56c9:	75 21                	jne    56ec <fwp_rc_wide_dup+0x5c>
    56cb:	e9 98 00 00 00       	jmp    5768 <fwp_rc_wide_dup+0xd8>
    56d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56dc:	00 00 00 00 
    56e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    56e4:	48 85 d2             	test   %rdx,%rdx
    56e7:	74 2f                	je     5718 <fwp_rc_wide_dup+0x88>
    56e9:	48 89 d0             	mov    %rdx,%rax
    56ec:	48 3b 08             	cmp    (%rax),%rcx
    56ef:	75 ef                	jne    56e0 <fwp_rc_wide_dup+0x50>
    56f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56f4:	74 7c                	je     5772 <fwp_rc_wide_dup+0xe2>
    56f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    56fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    56fe:	0f 84 91 00 00 00    	je     5795 <fwp_rc_wide_dup+0x105>
    5704:	48 83 c2 01          	add    $0x1,%rdx
    5708:	48 89 50 08          	mov    %rdx,0x8(%rax)
    570c:	48 83 c4 18          	add    $0x18,%rsp
    5710:	c3                   	ret
    5711:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5718:	4c 8d 40 10          	lea    0x10(%rax),%r8
    571c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    571f:	75 68                	jne    5789 <fwp_rc_wide_dup+0xf9>
    5721:	bf 18 00 00 00       	mov    $0x18,%edi
    5726:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    572b:	4c 89 04 24          	mov    %r8,(%rsp)
    572f:	e8 5c de ff ff       	call   3590 <malloc@plt>
    5734:	4c 8b 04 24          	mov    (%rsp),%r8
    5738:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    573d:	48 85 c0             	test   %rax,%rax
    5740:	74 5f                	je     57a1 <fwp_rc_wide_dup+0x111>
    5742:	48 89 08             	mov    %rcx,(%rax)
    5745:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    574c:	00 
    574d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5754:	00 
    5755:	49 89 00             	mov    %rax,(%r8)
    5758:	c6 01 ff             	movb   $0xff,(%rcx)
    575b:	48 83 05 05 3d 06 00 	addq   $0x1,0x63d05(%rip)        # 69468 <fwp_heap+0x1c48>
    5762:	01 
    5763:	48 83 c4 18          	add    $0x18,%rsp
    5767:	c3                   	ret
    5768:	80 3f fe             	cmpb   $0xfe,(%rdi)
    576b:	75 13                	jne    5780 <fwp_rc_wide_dup+0xf0>
    576d:	48 85 c0             	test   %rax,%rax
    5770:	74 af                	je     5721 <fwp_rc_wide_dup+0x91>
    5772:	48 8d 3d 07 62 00 00 	lea    0x6207(%rip),%rdi        # b980 <_IO_stdin_used+0x980>
    5779:	e8 b2 ec ff ff       	call   4430 <fwp_trap>
    577e:	66 90                	xchg   %ax,%ax
    5780:	48 85 c0             	test   %rax,%rax
    5783:	0f 85 6d ff ff ff    	jne    56f6 <fwp_rc_wide_dup+0x66>
    5789:	48 8d 3d 18 62 00 00 	lea    0x6218(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5790:	e8 9b ec ff ff       	call   4430 <fwp_trap>
    5795:	48 8d 3d f2 59 00 00 	lea    0x59f2(%rip),%rdi        # b18e <_IO_stdin_used+0x18e>
    579c:	e8 8f ec ff ff       	call   4430 <fwp_trap>
    57a1:	e8 6a e6 ff ff       	call   3e10 <fwp_heap_oom>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_rc_forget_slot>:
    57b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57b3:	74 0b                	je     57c0 <fwp_rc_forget_slot+0x10>
    57b5:	c3                   	ret
    57b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57bd:	00 00 00 
    57c0:	48 89 f8             	mov    %rdi,%rax
    57c3:	48 83 ec 08          	sub    $0x8,%rsp
    57c7:	48 89 fa             	mov    %rdi,%rdx
    57ca:	48 c1 e8 11          	shr    $0x11,%rax
    57ce:	48 31 f8             	xor    %rdi,%rax
    57d1:	48 89 c1             	mov    %rax,%rcx
    57d4:	48 c1 e9 09          	shr    $0x9,%rcx
    57d8:	48 31 c8             	xor    %rcx,%rax
    57db:	48 8d 0d 3e 20 06 00 	lea    0x6203e(%rip),%rcx        # 67820 <fwp_heap>
    57e2:	0f b6 c0             	movzbl %al,%eax
    57e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    57ec:	00 
    57ed:	48 85 ff             	test   %rdi,%rdi
    57f0:	74 3c                	je     582e <fwp_rc_forget_slot+0x7e>
    57f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    57f9:	00 
    57fa:	48 8b 01             	mov    (%rcx),%rax
    57fd:	eb 11                	jmp    5810 <fwp_rc_forget_slot+0x60>
    57ff:	90                   	nop
    5800:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5804:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5808:	48 85 ff             	test   %rdi,%rdi
    580b:	74 21                	je     582e <fwp_rc_forget_slot+0x7e>
    580d:	48 89 f8             	mov    %rdi,%rax
    5810:	48 3b 10             	cmp    (%rax),%rdx
    5813:	75 eb                	jne    5800 <fwp_rc_forget_slot+0x50>
    5815:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5819:	48 89 01             	mov    %rax,(%rcx)
    581c:	e8 8f db ff ff       	call   33b0 <free@plt>
    5821:	48 83 2d 3f 3c 06 00 	subq   $0x1,0x63c3f(%rip)        # 69468 <fwp_heap+0x1c48>
    5828:	01 
    5829:	48 83 c4 08          	add    $0x8,%rsp
    582d:	c3                   	ret
    582e:	48 8d 3d 73 61 00 00 	lea    0x6173(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5835:	e8 f6 eb ff ff       	call   4430 <fwp_trap>
    583a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005840 <fwp_rc_prepare_chunk>:
    5840:	48 83 3d 20 3c 06 00 	cmpq   $0x0,0x63c20(%rip)        # 69468 <fwp_heap+0x1c48>
    5847:	00 
    5848:	41 54                	push   %r12
    584a:	49 89 f4             	mov    %rsi,%r12
    584d:	55                   	push   %rbp
    584e:	48 89 fd             	mov    %rdi,%rbp
    5851:	53                   	push   %rbx
    5852:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5855:	0f 84 7d 00 00 00    	je     58d8 <fwp_rc_prepare_chunk+0x98>
    585b:	31 db                	xor    %ebx,%ebx
    585d:	85 c0                	test   %eax,%eax
    585f:	75 5f                	jne    58c0 <fwp_rc_prepare_chunk+0x80>
    5861:	48 85 f6             	test   %rsi,%rsi
    5864:	74 7c                	je     58e2 <fwp_rc_prepare_chunk+0xa2>
    5866:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    586a:	e8 41 db ff ff       	call   33b0 <free@plt>
    586f:	90                   	nop
    5870:	be 01 00 00 00       	mov    $0x1,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 93 dc ff ff       	call   3510 <calloc@plt>
    587d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5881:	48 85 c0             	test   %rax,%rax
    5884:	0f 85 87 00 00 00    	jne    5911 <fwp_rc_prepare_chunk+0xd1>
    588a:	e8 81 e5 ff ff       	call   3e10 <fwp_heap_oom>
    588f:	90                   	nop
    5890:	e8 1b ff ff ff       	call   57b0 <fwp_rc_forget_slot>
    5895:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5898:	48 83 c3 01          	add    $0x1,%rbx
    589c:	48 39 c3             	cmp    %rax,%rbx
    589f:	73 37                	jae    58d8 <fwp_rc_prepare_chunk+0x98>
    58a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58a8:	00 00 
    58aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58b1:	00 00 00 00 
    58b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58bc:	00 00 00 00 
    58c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58c4:	48 01 df             	add    %rbx,%rdi
    58c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ca:	74 c4                	je     5890 <fwp_rc_prepare_chunk+0x50>
    58cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58cf:	48 83 c3 01          	add    $0x1,%rbx
    58d3:	48 39 c3             	cmp    %rax,%rbx
    58d6:	72 e8                	jb     58c0 <fwp_rc_prepare_chunk+0x80>
    58d8:	49 39 c4             	cmp    %rax,%r12
    58db:	75 13                	jne    58f0 <fwp_rc_prepare_chunk+0xb0>
    58dd:	4d 85 e4             	test   %r12,%r12
    58e0:	75 46                	jne    5928 <fwp_rc_prepare_chunk+0xe8>
    58e2:	5b                   	pop    %rbx
    58e3:	5d                   	pop    %rbp
    58e4:	41 5c                	pop    %r12
    58e6:	c3                   	ret
    58e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58ee:	00 00 
    58f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58f4:	48 29 05 75 3b 06 00 	sub    %rax,0x63b75(%rip)        # 69470 <fwp_heap+0x1c50>
    58fb:	e8 b0 da ff ff       	call   33b0 <free@plt>
    5900:	4d 85 e4             	test   %r12,%r12
    5903:	0f 85 67 ff ff ff    	jne    5870 <fwp_rc_prepare_chunk+0x30>
    5909:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5910:	00 
    5911:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5915:	5b                   	pop    %rbx
    5916:	4c 01 25 53 3b 06 00 	add    %r12,0x63b53(%rip)        # 69470 <fwp_heap+0x1c50>
    591d:	5d                   	pop    %rbp
    591e:	41 5c                	pop    %r12
    5920:	c3                   	ret
    5921:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5928:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    592c:	5b                   	pop    %rbx
    592d:	4c 89 e2             	mov    %r12,%rdx
    5930:	31 f6                	xor    %esi,%esi
    5932:	5d                   	pop    %rbp
    5933:	41 5c                	pop    %r12
    5935:	e9 76 db ff ff       	jmp    34b0 <memset@plt>
    593a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005940 <fwp_heap_refill>:
    5940:	41 56                	push   %r14
    5942:	41 89 d6             	mov    %edx,%r14d
    5945:	41 55                	push   %r13
    5947:	41 89 f5             	mov    %esi,%r13d
    594a:	41 54                	push   %r12
    594c:	49 89 fc             	mov    %rdi,%r12
    594f:	bf 01 00 00 00       	mov    $0x1,%edi
    5954:	55                   	push   %rbp
    5955:	53                   	push   %rbx
    5956:	e8 f5 e4 ff ff       	call   3e50 <fwp_heap_chunks>
    595b:	48 89 c3             	mov    %rax,%rbx
    595e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5962:	48 8b 05 af 32 06 00 	mov    0x632af(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    5969:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    596d:	48 8d 05 ac 1e 06 00 	lea    0x61eac(%rip),%rax        # 67820 <fwp_heap>
    5974:	31 d2                	xor    %edx,%edx
    5976:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    597a:	48 89 ef             	mov    %rbp,%rdi
    597d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5981:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5985:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    598c:	00 
    598d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5992:	f7 f1                	div    %ecx
    5994:	31 d2                	xor    %edx,%edx
    5996:	66 0f 6e c1          	movd   %ecx,%xmm0
    599a:	66 0f 6e c8          	movd   %eax,%xmm1
    599e:	89 c6                	mov    %eax,%esi
    59a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59a5:	48 01 c8             	add    %rcx,%rax
    59a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59ac:	48 f7 f1             	div    %rcx
    59af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59b4:	89 45 18             	mov    %eax,0x18(%rbp)
    59b7:	e8 84 fe ff ff       	call   5840 <fwp_rc_prepare_chunk>
    59bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59bf:	48 89 d8             	mov    %rbx,%rax
    59c2:	48 c1 e0 10          	shl    $0x10,%rax
    59c6:	48 03 05 03 32 06 00 	add    0x63203(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    59cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59d6:	8b 55 08             	mov    0x8(%rbp),%edx
    59d9:	48 0f af d1          	imul   %rcx,%rdx
    59dd:	48 01 c2             	add    %rax,%rdx
    59e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    59e5:	5b                   	pop    %rbx
    59e6:	5d                   	pop    %rbp
    59e7:	41 5c                	pop    %r12
    59e9:	41 5d                	pop    %r13
    59eb:	41 5e                	pop    %r14
    59ed:	c3                   	ret
    59ee:	66 90                	xchg   %ax,%ax

00000000000059f0 <fwp_mem_free>:
    59f0:	48 85 ff             	test   %rdi,%rdi
    59f3:	0f 84 17 02 00 00    	je     5c10 <fwp_mem_free+0x220>
    59f9:	48 8b 35 d0 31 06 00 	mov    0x631d0(%rip),%rsi        # 68bd0 <fwp_heap+0x13b0>
    5a00:	48 8b 05 f1 31 06 00 	mov    0x631f1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    5a07:	48 89 fa             	mov    %rdi,%rdx
    5a0a:	48 29 f2             	sub    %rsi,%rdx
    5a0d:	48 c1 e0 10          	shl    $0x10,%rax
    5a11:	48 39 c2             	cmp    %rax,%rdx
    5a14:	0f 83 f6 01 00 00    	jae    5c10 <fwp_mem_free+0x220>
    5a1a:	49 89 d1             	mov    %rdx,%r9
    5a1d:	49 c1 e9 10          	shr    $0x10,%r9
    5a21:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a25:	48 c1 e0 03          	shl    $0x3,%rax
    5a29:	49 89 c0             	mov    %rax,%r8
    5a2c:	4c 03 05 e5 31 06 00 	add    0x631e5(%rip),%r8        # 68c18 <fwp_heap+0x13f8>
    5a33:	0f 84 d7 01 00 00    	je     5c10 <fwp_mem_free+0x220>
    5a39:	48 83 ec 38          	sub    $0x38,%rsp
    5a3d:	48 89 f9             	mov    %rdi,%rcx
    5a40:	41 0f b6 38          	movzbl (%r8),%edi
    5a44:	40 80 ff 01          	cmp    $0x1,%dil
    5a48:	74 16                	je     5a60 <fwp_mem_free+0x70>
    5a4a:	40 80 ff 02          	cmp    $0x2,%dil
    5a4e:	0f 84 94 00 00 00    	je     5ae8 <fwp_mem_free+0xf8>
    5a54:	48 83 c4 38          	add    $0x38,%rsp
    5a58:	c3                   	ret
    5a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a60:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a64:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a69:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a6e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a72:	4d 85 d2             	test   %r10,%r10
    5a75:	74 1d                	je     5a94 <fwp_mem_free+0xa4>
    5a77:	0f b7 c1             	movzwl %cx,%eax
    5a7a:	31 d2                	xor    %edx,%edx
    5a7c:	48 f7 f7             	div    %rdi
    5a7f:	49 01 c2             	add    %rax,%r10
    5a82:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5a86:	0f 84 44 01 00 00    	je     5bd0 <fwp_mem_free+0x1e0>
    5a8c:	41 c6 02 00          	movb   $0x0,(%r10)
    5a90:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a94:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a9b:	49 63 c1             	movslq %r9d,%rax
    5a9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5aa2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5aa6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5aab:	f2 0f 58 05 ad 31 06 	addsd  0x631ad(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5ab2:	00 
    5ab3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ab7:	48 8d 05 62 1d 06 00 	lea    0x61d62(%rip),%rax        # 67820 <fwp_heap>
    5abe:	48 01 d0             	add    %rdx,%rax
    5ac1:	48 8b 10             	mov    (%rax),%rdx
    5ac4:	48 f7 d2             	not    %rdx
    5ac7:	48 89 11             	mov    %rdx,(%rcx)
    5aca:	48 89 08             	mov    %rcx,(%rax)
    5acd:	48 29 3d 6c 31 06 00 	sub    %rdi,0x6316c(%rip)        # 68c40 <fwp_heap+0x1420>
    5ad4:	f2 0f 11 05 84 31 06 	movsd  %xmm0,0x63184(%rip)        # 68c60 <fwp_heap+0x1440>
    5adb:	00 
    5adc:	48 83 c4 38          	add    $0x38,%rsp
    5ae0:	c3                   	ret
    5ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae8:	66 31 d2             	xor    %dx,%dx
    5aeb:	48 01 d6             	add    %rdx,%rsi
    5aee:	48 39 f1             	cmp    %rsi,%rcx
    5af1:	0f 85 5d ff ff ff    	jne    5a54 <fwp_mem_free+0x64>
    5af7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5afb:	48 29 15 3e 31 06 00 	sub    %rdx,0x6313e(%rip)        # 68c40 <fwp_heap+0x1420>
    5b02:	48 85 d2             	test   %rdx,%rdx
    5b05:	0f 88 a5 00 00 00    	js     5bb0 <fwp_mem_free+0x1c0>
    5b0b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b0f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b14:	f2 0f 58 05 44 31 06 	addsd  0x63144(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5b1b:	00 
    5b1c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b20:	f2 0f 11 05 38 31 06 	movsd  %xmm0,0x63138(%rip)        # 68c60 <fwp_heap+0x1440>
    5b27:	00 
    5b28:	48 85 d2             	test   %rdx,%rdx
    5b2b:	74 0c                	je     5b39 <fwp_mem_free+0x149>
    5b2d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b30:	0f 84 db 00 00 00    	je     5c11 <fwp_mem_free+0x221>
    5b36:	c6 02 00             	movb   $0x0,(%rdx)
    5b39:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b3d:	48 85 c9             	test   %rcx,%rcx
    5b40:	74 3e                	je     5b80 <fwp_mem_free+0x190>
    5b42:	48 8b 15 cf 30 06 00 	mov    0x630cf(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    5b49:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b51:	48 01 d0             	add    %rdx,%rax
    5b54:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b58:	48 89 d6             	mov    %rdx,%rsi
    5b5b:	48 29 c6             	sub    %rax,%rsi
    5b5e:	83 e6 08             	and    $0x8,%esi
    5b61:	74 0d                	je     5b70 <fwp_mem_free+0x180>
    5b63:	c6 00 00             	movb   $0x0,(%rax)
    5b66:	48 83 c0 28          	add    $0x28,%rax
    5b6a:	48 39 c2             	cmp    %rax,%rdx
    5b6d:	74 11                	je     5b80 <fwp_mem_free+0x190>
    5b6f:	90                   	nop
    5b70:	c6 00 00             	movb   $0x0,(%rax)
    5b73:	48 83 c0 50          	add    $0x50,%rax
    5b77:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b7b:	48 39 c2             	cmp    %rax,%rdx
    5b7e:	75 f0                	jne    5b70 <fwp_mem_free+0x180>
    5b80:	48 01 0d c9 30 06 00 	add    %rcx,0x630c9(%rip)        # 68c50 <fwp_heap+0x1430>
    5b87:	4c 3b 0d 82 30 06 00 	cmp    0x63082(%rip),%r9        # 68c10 <fwp_heap+0x13f0>
    5b8e:	73 07                	jae    5b97 <fwp_mem_free+0x1a7>
    5b90:	4c 89 0d 79 30 06 00 	mov    %r9,0x63079(%rip)        # 68c10 <fwp_heap+0x13f0>
    5b97:	4c 3b 0d 6a 30 06 00 	cmp    0x6306a(%rip),%r9        # 68c08 <fwp_heap+0x13e8>
    5b9e:	0f 83 b0 fe ff ff    	jae    5a54 <fwp_mem_free+0x64>
    5ba4:	4c 89 0d 5d 30 06 00 	mov    %r9,0x6305d(%rip)        # 68c08 <fwp_heap+0x13e8>
    5bab:	e9 a4 fe ff ff       	jmp    5a54 <fwp_mem_free+0x64>
    5bb0:	48 89 d1             	mov    %rdx,%rcx
    5bb3:	83 e2 01             	and    $0x1,%edx
    5bb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bba:	48 d1 e9             	shr    $1,%rcx
    5bbd:	48 09 d1             	or     %rdx,%rcx
    5bc0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5bc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5bc9:	e9 46 ff ff ff       	jmp    5b14 <fwp_mem_free+0x124>
    5bce:	66 90                	xchg   %ax,%ax
    5bd0:	4c 89 d7             	mov    %r10,%rdi
    5bd3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bd8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bdd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5be2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5be6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5beb:	e8 c0 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5bf0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5bf5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5bfa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5bff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c09:	e9 7e fe ff ff       	jmp    5a8c <fwp_mem_free+0x9c>
    5c0e:	66 90                	xchg   %ax,%ax
    5c10:	c3                   	ret
    5c11:	48 89 d7             	mov    %rdx,%rdi
    5c14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c28:	e8 83 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5c2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c41:	e9 f0 fe ff ff       	jmp    5b36 <fwp_mem_free+0x146>
    5c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c4d:	00 00 00 

0000000000005c50 <fwp_heap_alloc_big>:
    5c50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c57:	00 00 40 
    5c5a:	41 57                	push   %r15
    5c5c:	41 56                	push   %r14
    5c5e:	41 55                	push   %r13
    5c60:	41 54                	push   %r12
    5c62:	55                   	push   %rbp
    5c63:	53                   	push   %rbx
    5c64:	48 83 ec 08          	sub    $0x8,%rsp
    5c68:	48 39 f8             	cmp    %rdi,%rax
    5c6b:	0f 82 fa 00 00 00    	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5c71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c78:	49 89 fd             	mov    %rdi,%r13
    5c7b:	41 89 f6             	mov    %esi,%r14d
    5c7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5c82:	48 89 ef             	mov    %rbp,%rdi
    5c85:	e8 c6 e1 ff ff       	call   3e50 <fwp_heap_chunks>
    5c8a:	be 01 00 00 00       	mov    $0x1,%esi
    5c8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5c93:	49 89 c4             	mov    %rax,%r12
    5c96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5c9d:	00 
    5c9e:	48 03 3d 73 2f 06 00 	add    0x62f73(%rip),%rdi        # 68c18 <fwp_heap+0x13f8>
    5ca5:	c6 07 02             	movb   $0x2,(%rdi)
    5ca8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5cac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5caf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cb3:	e8 88 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cb8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cbc:	76 47                	jbe    5d05 <fwp_heap_alloc_big+0xb5>
    5cbe:	4c 01 e5             	add    %r12,%rbp
    5cc1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5cc8:	00 
    5cc9:	4c 8d 3d 50 1b 06 00 	lea    0x61b50(%rip),%r15        # 67820 <fwp_heap>
    5cd0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cd5:	49 c1 e6 03          	shl    $0x3,%r14
    5cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ce0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ce7:	31 f6                	xor    %esi,%esi
    5ce9:	48 01 dd             	add    %rbx,%rbp
    5cec:	48 83 c3 28          	add    $0x28,%rbx
    5cf0:	48 89 ef             	mov    %rbp,%rdi
    5cf3:	e8 48 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cf8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5cfc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d00:	49 39 de             	cmp    %rbx,%r14
    5d03:	75 db                	jne    5ce0 <fwp_heap_alloc_big+0x90>
    5d05:	49 c1 e4 10          	shl    $0x10,%r12
    5d09:	4c 03 25 c0 2e 06 00 	add    0x62ec0(%rip),%r12        # 68bd0 <fwp_heap+0x13b0>
    5d10:	4c 89 ea             	mov    %r13,%rdx
    5d13:	31 f6                	xor    %esi,%esi
    5d15:	4c 89 e7             	mov    %r12,%rdi
    5d18:	e8 93 d7 ff ff       	call   34b0 <memset@plt>
    5d1d:	4c 89 e8             	mov    %r13,%rax
    5d20:	48 03 05 19 2f 06 00 	add    0x62f19(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5d27:	72 42                	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5d29:	48 39 05 18 2f 06 00 	cmp    %rax,0x62f18(%rip)        # 68c48 <fwp_heap+0x1428>
    5d30:	48 89 05 09 2f 06 00 	mov    %rax,0x62f09(%rip)        # 68c40 <fwp_heap+0x1420>
    5d37:	73 07                	jae    5d40 <fwp_heap_alloc_big+0xf0>
    5d39:	48 89 05 08 2f 06 00 	mov    %rax,0x62f08(%rip)        # 68c48 <fwp_heap+0x1428>
    5d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d44:	4c 89 e0             	mov    %r12,%rax
    5d47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d4c:	f2 0f 58 05 04 2f 06 	addsd  0x62f04(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5d53:	00 
    5d54:	f2 0f 11 05 fc 2e 06 	movsd  %xmm0,0x62efc(%rip)        # 68c58 <fwp_heap+0x1438>
    5d5b:	00 
    5d5c:	48 83 c4 08          	add    $0x8,%rsp
    5d60:	5b                   	pop    %rbx
    5d61:	5d                   	pop    %rbp
    5d62:	41 5c                	pop    %r12
    5d64:	41 5d                	pop    %r13
    5d66:	41 5e                	pop    %r14
    5d68:	41 5f                	pop    %r15
    5d6a:	c3                   	ret
    5d6b:	e8 a0 e0 ff ff       	call   3e10 <fwp_heap_oom>

0000000000005d70 <fwp_heap_alloc_slow>:
    5d70:	53                   	push   %rbx
    5d71:	48 89 f9             	mov    %rdi,%rcx
    5d74:	41 89 f1             	mov    %esi,%r9d
    5d77:	48 83 ec 10          	sub    $0x10,%rsp
    5d7b:	8b 05 43 2e 06 00    	mov    0x62e43(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5d81:	85 c0                	test   %eax,%eax
    5d83:	0f 84 c7 00 00 00    	je     5e50 <fwp_heap_alloc_slow+0xe0>
    5d89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5d90:	0f 87 dd 00 00 00    	ja     5e73 <fwp_heap_alloc_slow+0x103>
    5d96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5d9a:	48 8d 3d 7f 1a 06 00 	lea    0x61a7f(%rip),%rdi        # 67820 <fwp_heap>
    5da1:	49 63 f1             	movslq %r9d,%rsi
    5da4:	48 c1 e8 04          	shr    $0x4,%rax
    5da8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5daf:	00 00 
    5db1:	41 0f b6 c2          	movzbl %r10b,%eax
    5db5:	4c 89 d2             	mov    %r10,%rdx
    5db8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5dbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5dc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dce:	48 01 f8             	add    %rdi,%rax
    5dd1:	4c 8b 00             	mov    (%rax),%r8
    5dd4:	4d 85 c0             	test   %r8,%r8
    5dd7:	0f 84 ab 00 00 00    	je     5e88 <fwp_heap_alloc_slow+0x118>
    5ddd:	49 8b 10             	mov    (%r8),%rdx
    5de0:	48 f7 d2             	not    %rdx
    5de3:	48 89 10             	mov    %rdx,(%rax)
    5de6:	41 83 f9 01          	cmp    $0x1,%r9d
    5dea:	4c 89 c7             	mov    %r8,%rdi
    5ded:	48 0f 45 cb          	cmovne %rbx,%rcx
    5df1:	31 f6                	xor    %esi,%esi
    5df3:	48 89 ca             	mov    %rcx,%rdx
    5df6:	e8 b5 d6 ff ff       	call   34b0 <memset@plt>
    5dfb:	49 89 c0             	mov    %rax,%r8
    5dfe:	48 89 d8             	mov    %rbx,%rax
    5e01:	48 03 05 38 2e 06 00 	add    0x62e38(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5e08:	0f 82 d9 00 00 00    	jb     5ee7 <fwp_heap_alloc_slow+0x177>
    5e0e:	48 39 05 33 2e 06 00 	cmp    %rax,0x62e33(%rip)        # 68c48 <fwp_heap+0x1428>
    5e15:	48 89 05 24 2e 06 00 	mov    %rax,0x62e24(%rip)        # 68c40 <fwp_heap+0x1420>
    5e1c:	73 07                	jae    5e25 <fwp_heap_alloc_slow+0xb5>
    5e1e:	48 89 05 23 2e 06 00 	mov    %rax,0x62e23(%rip)        # 68c48 <fwp_heap+0x1428>
    5e25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e29:	4c 89 c0             	mov    %r8,%rax
    5e2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e31:	f2 0f 58 05 1f 2e 06 	addsd  0x62e1f(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5e38:	00 
    5e39:	f2 0f 11 05 17 2e 06 	movsd  %xmm0,0x62e17(%rip)        # 68c58 <fwp_heap+0x1438>
    5e40:	00 
    5e41:	48 83 c4 10          	add    $0x10,%rsp
    5e45:	5b                   	pop    %rbx
    5e46:	c3                   	ret
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e58:	e8 53 ef ff ff       	call   4db0 <fwp_heap_init>
    5e5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e6d:	0f 86 23 ff ff ff    	jbe    5d96 <fwp_heap_alloc_slow+0x26>
    5e73:	48 83 c4 10          	add    $0x10,%rsp
    5e77:	44 89 ce             	mov    %r9d,%esi
    5e7a:	48 89 cf             	mov    %rcx,%rdi
    5e7d:	5b                   	pop    %rbx
    5e7e:	e9 cd fd ff ff       	jmp    5c50 <fwp_heap_alloc_big>
    5e83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5e8c:	4d 85 c0             	test   %r8,%r8
    5e8f:	74 1f                	je     5eb0 <fwp_heap_alloc_slow+0x140>
    5e91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5e95:	4d 29 c3             	sub    %r8,%r11
    5e98:	49 39 db             	cmp    %rbx,%r11
    5e9b:	72 13                	jb     5eb0 <fwp_heap_alloc_slow+0x140>
    5e9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ea1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ea5:	e9 3c ff ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5eb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5eb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5ebb:	44 89 ca             	mov    %r9d,%edx
    5ebe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ec3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ec7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ecb:	44 89 d6             	mov    %r10d,%esi
    5ece:	48 01 c7             	add    %rax,%rdi
    5ed1:	e8 6a fa ff ff       	call   5940 <fwp_heap_refill>
    5ed6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5edb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5edf:	49 89 c0             	mov    %rax,%r8
    5ee2:	e9 ff fe ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5ee7:	e8 24 df ff ff       	call   3e10 <fwp_heap_oom>
    5eec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ef0 <fwp_heap_alloc>:
    5ef0:	53                   	push   %rbx
    5ef1:	48 89 fa             	mov    %rdi,%rdx
    5ef4:	48 83 ec 10          	sub    $0x10,%rsp
    5ef8:	8b 1d ea 35 06 00    	mov    0x635ea(%rip),%ebx        # 694e8 <iteration_active>
    5efe:	8b 05 c0 2c 06 00    	mov    0x62cc0(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5f04:	85 db                	test   %ebx,%ebx
    5f06:	0f 85 04 01 00 00    	jne    6010 <fwp_heap_alloc+0x120>
    5f0c:	85 c0                	test   %eax,%eax
    5f0e:	0f 84 ac 01 00 00    	je     60c0 <fwp_heap_alloc+0x1d0>
    5f14:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f1b:	0f 87 9f 01 00 00    	ja     60c0 <fwp_heap_alloc+0x1d0>
    5f21:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f25:	48 8d 05 f4 18 06 00 	lea    0x618f4(%rip),%rax        # 67820 <fwp_heap>
    5f2c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f30:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f37:	00 
    5f38:	48 63 ce             	movslq %esi,%rcx
    5f3b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f42:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f49:	00 
    5f4a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f4e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f52:	48 01 c8             	add    %rcx,%rax
    5f55:	48 8b 08             	mov    (%rax),%rcx
    5f58:	48 85 c9             	test   %rcx,%rcx
    5f5b:	0f 84 ff 00 00 00    	je     6060 <fwp_heap_alloc+0x170>
    5f61:	48 8b 39             	mov    (%rcx),%rdi
    5f64:	48 f7 d7             	not    %rdi
    5f67:	48 89 38             	mov    %rdi,(%rax)
    5f6a:	83 fe 01             	cmp    $0x1,%esi
    5f6d:	48 89 cf             	mov    %rcx,%rdi
    5f70:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f75:	49 0f 45 d0          	cmovne %r8,%rdx
    5f79:	31 f6                	xor    %esi,%esi
    5f7b:	e8 30 d5 ff ff       	call   34b0 <memset@plt>
    5f80:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5f85:	48 89 c1             	mov    %rax,%rcx
    5f88:	4c 89 c0             	mov    %r8,%rax
    5f8b:	48 03 05 ae 2c 06 00 	add    0x62cae(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5f92:	0f 82 35 01 00 00    	jb     60cd <fwp_heap_alloc+0x1dd>
    5f98:	48 39 05 a9 2c 06 00 	cmp    %rax,0x62ca9(%rip)        # 68c48 <fwp_heap+0x1428>
    5f9f:	48 89 05 9a 2c 06 00 	mov    %rax,0x62c9a(%rip)        # 68c40 <fwp_heap+0x1420>
    5fa6:	73 07                	jae    5faf <fwp_heap_alloc+0xbf>
    5fa8:	48 89 05 99 2c 06 00 	mov    %rax,0x62c99(%rip)        # 68c48 <fwp_heap+0x1428>
    5faf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fb3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fb8:	f2 0f 58 05 98 2c 06 	addsd  0x62c98(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5fbf:	00 
    5fc0:	f2 0f 11 05 90 2c 06 	movsd  %xmm0,0x62c90(%rip)        # 68c58 <fwp_heap+0x1438>
    5fc7:	00 
    5fc8:	85 db                	test   %ebx,%ebx
    5fca:	74 33                	je     5fff <fwp_heap_alloc+0x10f>
    5fcc:	48 8b 05 6d 2c 06 00 	mov    0x62c6d(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5fd3:	48 85 c0             	test   %rax,%rax
    5fd6:	0f 88 ac 00 00 00    	js     6088 <fwp_heap_alloc+0x198>
    5fdc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fe0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5fe5:	f2 0f 5c 05 db 34 06 	subsd  0x634db(%rip),%xmm0        # 694c8 <iteration_start_charge>
    5fec:	00 
    5fed:	66 0f 2f 05 cb 34 06 	comisd 0x634cb(%rip),%xmm0        # 694c0 <iteration_peak>
    5ff4:	00 
    5ff5:	76 08                	jbe    5fff <fwp_heap_alloc+0x10f>
    5ff7:	f2 0f 11 05 c1 34 06 	movsd  %xmm0,0x634c1(%rip)        # 694c0 <iteration_peak>
    5ffe:	00 
    5fff:	48 83 c4 10          	add    $0x10,%rsp
    6003:	48 89 c8             	mov    %rcx,%rax
    6006:	5b                   	pop    %rbx
    6007:	c3                   	ret
    6008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    600f:	00 
    6010:	85 f6                	test   %esi,%esi
    6012:	74 34                	je     6048 <fwp_heap_alloc+0x158>
    6014:	48 83 05 c4 34 06 00 	addq   $0x1,0x634c4(%rip)        # 694e0 <iteration_requests>
    601b:	01 
    601c:	48 01 3d b5 34 06 00 	add    %rdi,0x634b5(%rip)        # 694d8 <iteration_bytes>
    6023:	85 c0                	test   %eax,%eax
    6025:	74 0d                	je     6034 <fwp_heap_alloc+0x144>
    6027:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    602e:	0f 86 ed fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6034:	48 89 d7             	mov    %rdx,%rdi
    6037:	e8 34 fd ff ff       	call   5d70 <fwp_heap_alloc_slow>
    603c:	48 89 c1             	mov    %rax,%rcx
    603f:	eb 8b                	jmp    5fcc <fwp_heap_alloc+0xdc>
    6041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6048:	85 c0                	test   %eax,%eax
    604a:	74 0d                	je     6059 <fwp_heap_alloc+0x169>
    604c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6053:	0f 86 c8 fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6059:	31 f6                	xor    %esi,%esi
    605b:	eb d7                	jmp    6034 <fwp_heap_alloc+0x144>
    605d:	0f 1f 00             	nopl   (%rax)
    6060:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6064:	48 85 c9             	test   %rcx,%rcx
    6067:	74 0c                	je     6075 <fwp_heap_alloc+0x185>
    6069:	48 8b 78 10          	mov    0x10(%rax),%rdi
    606d:	48 29 cf             	sub    %rcx,%rdi
    6070:	4c 39 c7             	cmp    %r8,%rdi
    6073:	73 3b                	jae    60b0 <fwp_heap_alloc+0x1c0>
    6075:	48 89 d7             	mov    %rdx,%rdi
    6078:	e8 f3 fc ff ff       	call   5d70 <fwp_heap_alloc_slow>
    607d:	48 89 c1             	mov    %rax,%rcx
    6080:	e9 43 ff ff ff       	jmp    5fc8 <fwp_heap_alloc+0xd8>
    6085:	0f 1f 00             	nopl   (%rax)
    6088:	48 89 c2             	mov    %rax,%rdx
    608b:	83 e0 01             	and    $0x1,%eax
    608e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6092:	48 d1 ea             	shr    $1,%rdx
    6095:	48 09 c2             	or     %rax,%rdx
    6098:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    609d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60a1:	e9 3f ff ff ff       	jmp    5fe5 <fwp_heap_alloc+0xf5>
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 
    60b0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60b4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60b8:	e9 ad fe ff ff       	jmp    5f6a <fwp_heap_alloc+0x7a>
    60bd:	0f 1f 00             	nopl   (%rax)
    60c0:	48 83 c4 10          	add    $0x10,%rsp
    60c4:	48 89 d7             	mov    %rdx,%rdi
    60c7:	5b                   	pop    %rbx
    60c8:	e9 a3 fc ff ff       	jmp    5d70 <fwp_heap_alloc_slow>
    60cd:	e8 3e dd ff ff       	call   3e10 <fwp_heap_oom>
    60d2:	0f 1f 00             	nopl   (%rax)
    60d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60dc:	00 00 00 00 

00000000000060e0 <fwp_data.part.0.constprop.0>:
    60e0:	41 56                	push   %r14
    60e2:	8b 05 dc 2a 06 00    	mov    0x62adc(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    60e8:	41 89 fe             	mov    %edi,%r14d
    60eb:	41 55                	push   %r13
    60ed:	44 8b 2d f4 33 06 00 	mov    0x633f4(%rip),%r13d        # 694e8 <iteration_active>
    60f4:	41 54                	push   %r12
    60f6:	49 89 f4             	mov    %rsi,%r12
    60f9:	55                   	push   %rbp
    60fa:	53                   	push   %rbx
    60fb:	45 85 ed             	test   %r13d,%r13d
    60fe:	0f 84 1c 01 00 00    	je     6220 <fwp_data.part.0.constprop.0+0x140>
    6104:	48 83 05 d4 33 06 00 	addq   $0x1,0x633d4(%rip)        # 694e0 <iteration_requests>
    610b:	01 
    610c:	48 83 05 c4 33 06 00 	addq   $0x18,0x633c4(%rip)        # 694d8 <iteration_bytes>
    6113:	18 
    6114:	85 c0                	test   %eax,%eax
    6116:	0f 84 8c 01 00 00    	je     62a8 <fwp_data.part.0.constprop.0+0x1c8>
    611c:	0f b6 05 9f 26 06 00 	movzbl 0x6269f(%rip),%eax        # 687c2 <fwp_heap+0xfa2>
    6123:	48 8d 15 f6 16 06 00 	lea    0x616f6(%rip),%rdx        # 67820 <fwp_heap>
    612a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6131:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6135:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6139:	48 8b 18             	mov    (%rax),%rbx
    613c:	48 85 db             	test   %rbx,%rbx
    613f:	0f 84 fb 00 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x160>
    6145:	48 8b 13             	mov    (%rbx),%rdx
    6148:	48 f7 d2             	not    %rdx
    614b:	48 89 10             	mov    %rdx,(%rax)
    614e:	48 83 fd 18          	cmp    $0x18,%rbp
    6152:	76 1b                	jbe    616f <fwp_data.part.0.constprop.0+0x8f>
    6154:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6158:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    615c:	31 f6                	xor    %esi,%esi
    615e:	48 c1 e8 03          	shr    $0x3,%rax
    6162:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6169:	00 
    616a:	e8 41 d3 ff ff       	call   34b0 <memset@plt>
    616f:	48 89 e8             	mov    %rbp,%rax
    6172:	48 03 05 c7 2a 06 00 	add    0x62ac7(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    6179:	0f 82 3d 01 00 00    	jb     62bc <fwp_data.part.0.constprop.0+0x1dc>
    617f:	48 39 05 c2 2a 06 00 	cmp    %rax,0x62ac2(%rip)        # 68c48 <fwp_heap+0x1428>
    6186:	48 89 05 b3 2a 06 00 	mov    %rax,0x62ab3(%rip)        # 68c40 <fwp_heap+0x1420>
    618d:	73 07                	jae    6196 <fwp_data.part.0.constprop.0+0xb6>
    618f:	48 89 05 b2 2a 06 00 	mov    %rax,0x62ab2(%rip)        # 68c48 <fwp_heap+0x1428>
    6196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    619a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    619f:	f2 0f 58 05 b1 2a 06 	addsd  0x62ab1(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    61a6:	00 
    61a7:	f2 0f 11 05 a9 2a 06 	movsd  %xmm0,0x62aa9(%rip)        # 68c58 <fwp_heap+0x1438>
    61ae:	00 
    61af:	45 85 ed             	test   %r13d,%r13d
    61b2:	74 33                	je     61e7 <fwp_data.part.0.constprop.0+0x107>
    61b4:	48 8b 05 85 2a 06 00 	mov    0x62a85(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    61bb:	48 85 c0             	test   %rax,%rax
    61be:	0f 88 a4 00 00 00    	js     6268 <fwp_data.part.0.constprop.0+0x188>
    61c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61c8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61cd:	f2 0f 5c 05 f3 32 06 	subsd  0x632f3(%rip),%xmm0        # 694c8 <iteration_start_charge>
    61d4:	00 
    61d5:	66 0f 2f 05 e3 32 06 	comisd 0x632e3(%rip),%xmm0        # 694c0 <iteration_peak>
    61dc:	00 
    61dd:	76 08                	jbe    61e7 <fwp_data.part.0.constprop.0+0x107>
    61df:	f2 0f 11 05 d9 32 06 	movsd  %xmm0,0x632d9(%rip)        # 694c0 <iteration_peak>
    61e6:	00 
    61e7:	b8 02 00 00 00       	mov    $0x2,%eax
    61ec:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    61f1:	66 0f 6e c8          	movd   %eax,%xmm1
    61f5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    61f9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    61fd:	49 8b 04 24          	mov    (%r12),%rax
    6201:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6205:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    620a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    620e:	48 89 d8             	mov    %rbx,%rax
    6211:	5b                   	pop    %rbx
    6212:	5d                   	pop    %rbp
    6213:	41 5c                	pop    %r12
    6215:	41 5d                	pop    %r13
    6217:	41 5e                	pop    %r14
    6219:	c3                   	ret
    621a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6220:	85 c0                	test   %eax,%eax
    6222:	0f 85 f4 fe ff ff    	jne    611c <fwp_data.part.0.constprop.0+0x3c>
    6228:	31 f6                	xor    %esi,%esi
    622a:	bf 18 00 00 00       	mov    $0x18,%edi
    622f:	e8 bc fc ff ff       	call   5ef0 <fwp_heap_alloc>
    6234:	48 89 c3             	mov    %rax,%rbx
    6237:	eb ae                	jmp    61e7 <fwp_data.part.0.constprop.0+0x107>
    6239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6240:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6244:	48 85 db             	test   %rbx,%rbx
    6247:	74 47                	je     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6249:	48 8b 50 10          	mov    0x10(%rax),%rdx
    624d:	48 29 da             	sub    %rbx,%rdx
    6250:	48 39 ea             	cmp    %rbp,%rdx
    6253:	72 3b                	jb     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6255:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6259:	48 89 50 08          	mov    %rdx,0x8(%rax)
    625d:	e9 ec fe ff ff       	jmp    614e <fwp_data.part.0.constprop.0+0x6e>
    6262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6268:	48 89 c2             	mov    %rax,%rdx
    626b:	83 e0 01             	and    $0x1,%eax
    626e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6272:	48 d1 ea             	shr    $1,%rdx
    6275:	48 09 c2             	or     %rax,%rdx
    6278:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    627d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6281:	e9 47 ff ff ff       	jmp    61cd <fwp_data.part.0.constprop.0+0xed>
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 
    6290:	31 f6                	xor    %esi,%esi
    6292:	bf 18 00 00 00       	mov    $0x18,%edi
    6297:	e8 54 fc ff ff       	call   5ef0 <fwp_heap_alloc>
    629c:	48 89 c3             	mov    %rax,%rbx
    629f:	e9 0b ff ff ff       	jmp    61af <fwp_data.part.0.constprop.0+0xcf>
    62a4:	0f 1f 40 00          	nopl   0x0(%rax)
    62a8:	31 f6                	xor    %esi,%esi
    62aa:	bf 18 00 00 00       	mov    $0x18,%edi
    62af:	e8 3c fc ff ff       	call   5ef0 <fwp_heap_alloc>
    62b4:	48 89 c3             	mov    %rax,%rbx
    62b7:	e9 f8 fe ff ff       	jmp    61b4 <fwp_data.part.0.constprop.0+0xd4>
    62bc:	e8 4f db ff ff       	call   3e10 <fwp_heap_oom>
    62c1:	0f 1f 40 00          	nopl   0x0(%rax)
    62c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62cc:	00 00 00 00 

00000000000062d0 <fwp_p_ad_push.constprop.0>:
    62d0:	41 57                	push   %r15
    62d2:	41 56                	push   %r14
    62d4:	41 55                	push   %r13
    62d6:	49 89 d5             	mov    %rdx,%r13
    62d9:	41 54                	push   %r12
    62db:	49 89 fc             	mov    %rdi,%r12
    62de:	55                   	push   %rbp
    62df:	53                   	push   %rbx
    62e0:	48 83 ec 38          	sub    $0x38,%rsp
    62e4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    62e9:	48 85 ff             	test   %rdi,%rdi
    62ec:	79 09                	jns    62f7 <fwp_p_ad_push.constprop.0+0x27>
    62ee:	48 85 d2             	test   %rdx,%rdx
    62f1:	0f 88 a9 01 00 00    	js     64a0 <fwp_p_ad_push.constprop.0+0x1d0>
    62f7:	48 89 f8             	mov    %rdi,%rax
    62fa:	48 89 0c 24          	mov    %rcx,(%rsp)
    62fe:	48 09 d0             	or     %rdx,%rax
    6301:	0f 89 79 01 00 00    	jns    6480 <fwp_p_ad_push.constprop.0+0x1b0>
    6307:	48 89 f8             	mov    %rdi,%rax
    630a:	48 c1 f8 20          	sar    $0x20,%rax
    630e:	48 85 ff             	test   %rdi,%rdi
    6311:	79 24                	jns    6337 <fwp_p_ad_push.constprop.0+0x67>
    6313:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6318:	48 89 d0             	mov    %rdx,%rax
    631b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6322:	00 
    6323:	49 89 d4             	mov    %rdx,%r12
    6326:	48 c1 f8 20          	sar    $0x20,%rax
    632a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6331:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6337:	48 89 c7             	mov    %rax,%rdi
    633a:	e8 d1 e3 ff ff       	call   4710 <fwp_tape_of>
    633f:	48 89 c3             	mov    %rax,%rbx
    6342:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6347:	0f 85 f7 02 00 00    	jne    6644 <fwp_p_ad_push.constprop.0+0x374>
    634d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6351:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6358:	0f 8f 49 02 00 00    	jg     65a7 <fwp_p_ad_push.constprop.0+0x2d7>
    635e:	44 89 e0             	mov    %r12d,%eax
    6361:	49 39 c7             	cmp    %rax,%r15
    6364:	0f 8e 49 02 00 00    	jle    65b3 <fwp_p_ad_push.constprop.0+0x2e3>
    636a:	4d 85 ed             	test   %r13,%r13
    636d:	78 0c                	js     637b <fwp_p_ad_push.constprop.0+0xab>
    636f:	44 89 e8             	mov    %r13d,%eax
    6372:	49 39 c7             	cmp    %rax,%r15
    6375:	0f 8e 38 02 00 00    	jle    65b3 <fwp_p_ad_push.constprop.0+0x2e3>
    637b:	4d 89 fe             	mov    %r15,%r14
    637e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6382:	49 8d 46 01          	lea    0x1(%r14),%rax
    6386:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    638c:	0f 87 15 02 00 00    	ja     65a7 <fwp_p_ad_push.constprop.0+0x2d7>
    6392:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6396:	48 39 e8             	cmp    %rbp,%rax
    6399:	0f 8e 31 01 00 00    	jle    64d0 <fwp_p_ad_push.constprop.0+0x200>
    639f:	48 85 ed             	test   %rbp,%rbp
    63a2:	ba 40 00 00 00       	mov    $0x40,%edx
    63a7:	48 0f 44 ea          	cmove  %rdx,%rbp
    63ab:	48 39 e8             	cmp    %rbp,%rax
    63ae:	7e 20                	jle    63d0 <fwp_p_ad_push.constprop.0+0x100>
    63b0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63b7:	0f 8f 03 01 00 00    	jg     64c0 <fwp_p_ad_push.constprop.0+0x1f0>
    63bd:	48 01 ed             	add    %rbp,%rbp
    63c0:	48 39 e8             	cmp    %rbp,%rax
    63c3:	7f eb                	jg     63b0 <fwp_p_ad_push.constprop.0+0xe0>
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 
    63d0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63d7:	00 
    63d8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    63dc:	ba 01 00 00 00       	mov    $0x1,%edx
    63e1:	48 89 c6             	mov    %rax,%rsi
    63e4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    63e9:	e8 82 ed ff ff       	call   5170 <ad_raw_realloc>
    63ee:	48 85 c0             	test   %rax,%rax
    63f1:	0f 84 c8 01 00 00    	je     65bf <fwp_p_ad_push.constprop.0+0x2ef>
    63f7:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    63fb:	48 89 e9             	mov    %rbp,%rcx
    63fe:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6402:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6406:	48 c1 e1 04          	shl    $0x4,%rcx
    640a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    640e:	48 89 ce             	mov    %rcx,%rsi
    6411:	ba 02 00 00 00       	mov    $0x2,%edx
    6416:	48 89 43 28          	mov    %rax,0x28(%rbx)
    641a:	e8 51 ed ff ff       	call   5170 <ad_raw_realloc>
    641f:	48 85 c0             	test   %rax,%rax
    6422:	0f 84 97 01 00 00    	je     65bf <fwp_p_ad_push.constprop.0+0x2ef>
    6428:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    642c:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6430:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6437:	00 
    6438:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    643f:	00 
    6440:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6447:	00 
    6448:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    644c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    6451:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6455:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6459:	4d 85 f6             	test   %r14,%r14
    645c:	0f 85 e6 00 00 00    	jne    6548 <fwp_p_ad_push.constprop.0+0x278>
    6462:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6466:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    646a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    646e:	48 01 d1             	add    %rdx,%rcx
    6471:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6475:	eb 79                	jmp    64f0 <fwp_p_ad_push.constprop.0+0x220>
    6477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    647e:	00 00 
    6480:	48 89 d0             	mov    %rdx,%rax
    6483:	48 c1 ff 20          	sar    $0x20,%rdi
    6487:	48 c1 f8 20          	sar    $0x20,%rax
    648b:	48 39 c7             	cmp    %rax,%rdi
    648e:	0f 84 a3 fe ff ff    	je     6337 <fwp_p_ad_push.constprop.0+0x67>
    6494:	48 8d 3d 35 55 00 00 	lea    0x5535(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    649b:	e8 90 df ff ff       	call   4430 <fwp_trap>
    64a0:	48 83 c4 38          	add    $0x38,%rsp
    64a4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    64ab:	5b                   	pop    %rbx
    64ac:	5d                   	pop    %rbp
    64ad:	41 5c                	pop    %r12
    64af:	41 5d                	pop    %r13
    64b1:	41 5e                	pop    %r14
    64b3:	41 5f                	pop    %r15
    64b5:	c3                   	ret
    64b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64bd:	00 00 00 
    64c0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    64c5:	e9 06 ff ff ff       	jmp    63d0 <fwp_p_ad_push.constprop.0+0x100>
    64ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64d0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64d4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64d8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64df:	00 
    64e0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64e7:	00 
    64e8:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    64ec:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    64f0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    64f6:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    64fa:	4d 85 ed             	test   %r13,%r13
    64fd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6502:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6508:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    650f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6513:	49 8d 47 01          	lea    0x1(%r15),%rax
    6517:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    651b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6521:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6525:	48 83 c4 38          	add    $0x38,%rsp
    6529:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6530:	ff ff ff 
    6533:	4c 21 e0             	and    %r12,%rax
    6536:	5b                   	pop    %rbx
    6537:	5d                   	pop    %rbp
    6538:	4c 09 f8             	or     %r15,%rax
    653b:	41 5c                	pop    %r12
    653d:	41 5d                	pop    %r13
    653f:	41 5e                	pop    %r14
    6541:	41 5f                	pop    %r15
    6543:	c3                   	ret
    6544:	0f 1f 40 00          	nopl   0x0(%rax)
    6548:	4c 89 ca             	mov    %r9,%rdx
    654b:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6550:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6555:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    655a:	e8 91 d0 ff ff       	call   35f0 <memmove@plt>
    655f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6564:	4c 03 73 30          	add    0x30(%rbx),%r14
    6568:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    656d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6571:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6575:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    657a:	48 03 7b 20          	add    0x20(%rbx),%rdi
    657e:	4c 89 d2             	mov    %r10,%rdx
    6581:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6586:	e8 65 d0 ff ff       	call   35f0 <memmove@plt>
    658b:	48 8b 43 30          	mov    0x30(%rbx),%rax
    658f:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6593:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6598:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    659d:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    65a2:	e9 bf fe ff ff       	jmp    6466 <fwp_p_ad_push.constprop.0+0x196>
    65a7:	48 8d 3d f9 4b 00 00 	lea    0x4bf9(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    65ae:	e8 7d de ff ff       	call   4430 <fwp_trap>
    65b3:	48 8d 3d 08 4c 00 00 	lea    0x4c08(%rip),%rdi        # b1c2 <_IO_stdin_used+0x1c2>
    65ba:	e8 71 de ff ff       	call   4430 <fwp_trap>
    65bf:	48 89 df             	mov    %rbx,%rdi
    65c2:	e8 a9 d6 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    65c7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    65cb:	48 85 ff             	test   %rdi,%rdi
    65ce:	74 05                	je     65d5 <fwp_p_ad_push.constprop.0+0x305>
    65d0:	e8 db ea ff ff       	call   50b0 <ad_raw_free.part.0>
    65d5:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    65d9:	48 85 ff             	test   %rdi,%rdi
    65dc:	74 05                	je     65e3 <fwp_p_ad_push.constprop.0+0x313>
    65de:	e8 cd ea ff ff       	call   50b0 <ad_raw_free.part.0>
    65e3:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    65e7:	48 85 ff             	test   %rdi,%rdi
    65ea:	74 05                	je     65f1 <fwp_p_ad_push.constprop.0+0x321>
    65ec:	e8 bf ea ff ff       	call   50b0 <ad_raw_free.part.0>
    65f1:	31 c9                	xor    %ecx,%ecx
    65f3:	31 c0                	xor    %eax,%eax
    65f5:	31 d2                	xor    %edx,%edx
    65f7:	be 01 00 00 00       	mov    $0x1,%esi
    65fc:	89 53 04             	mov    %edx,0x4(%rbx)
    65ff:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6603:	ba 13 00 00 00       	mov    $0x13,%edx
    6608:	48 8d 3d f9 49 00 00 	lea    0x49f9(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    660f:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6613:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6617:	48 8b 0d 22 8a 00 00 	mov    0x8a22(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    661e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6622:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6626:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    662a:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    662e:	e8 2d d0 ff ff       	call   3660 <fwrite@plt>
    6633:	31 ff                	xor    %edi,%edi
    6635:	e8 66 cf ff ff       	call   35a0 <fflush@plt>
    663a:	bf 66 00 00 00       	mov    $0x66,%edi
    663f:	e8 3c d0 ff ff       	call   3680 <_Exit@plt>
    6644:	48 8d 3d cd 53 00 00 	lea    0x53cd(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    664b:	e8 e0 dd ff ff       	call   4430 <fwp_trap>

0000000000006650 <w120>:
    6650:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6654:	41 55                	push   %r13
    6656:	48 89 fa             	mov    %rdi,%rdx
    6659:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    665d:	41 54                	push   %r12
    665f:	49 89 fc             	mov    %rdi,%r12
    6662:	55                   	push   %rbp
    6663:	53                   	push   %rbx
    6664:	48 89 f3             	mov    %rsi,%rbx
    6667:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    666c:	48 89 f1             	mov    %rsi,%rcx
    666f:	48 83 ec 28          	sub    $0x28,%rsp
    6673:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6679:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    667f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6685:	e8 46 fc ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    668a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6690:	48 89 da             	mov    %rbx,%rdx
    6693:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6699:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66a0:	00 f0 3f 
    66a3:	48 89 c7             	mov    %rax,%rdi
    66a6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66ad:	00 f0 bf 
    66b0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    66b5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66bb:	e8 10 fc ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    66c0:	f2 0f 10 05 58 56 00 	movsd  0x5658(%rip),%xmm0        # bd20 <msg.4+0xb0>
    66c7:	00 
    66c8:	4c 89 e7             	mov    %r12,%rdi
    66cb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    66d1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66d8:	00 f0 3f 
    66db:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    66e2:	49 89 c5             	mov    %rax,%r13
    66e5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66ec:	00 f0 bf 
    66ef:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    66f4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66fa:	e8 d1 fb ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    66ff:	48 89 e9             	mov    %rbp,%rcx
    6702:	4c 89 ea             	mov    %r13,%rdx
    6705:	48 89 ee             	mov    %rbp,%rsi
    6708:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    670e:	4c 89 ef             	mov    %r13,%rdi
    6711:	49 89 c4             	mov    %rax,%r12
    6714:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6718:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    671e:	e8 ad fb ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    6723:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6729:	f2 0f 59 1d f7 55 00 	mulsd  0x55f7(%rip),%xmm3        # bd28 <msg.4+0xb8>
    6730:	00 
    6731:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6738:	00 59 40 
    673b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6740:	48 89 c2             	mov    %rax,%rdx
    6743:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    674a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6750:	e8 7b fb ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    6755:	48 89 d9             	mov    %rbx,%rcx
    6758:	4c 89 e2             	mov    %r12,%rdx
    675b:	48 89 de             	mov    %rbx,%rsi
    675e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6764:	4c 89 e7             	mov    %r12,%rdi
    6767:	48 89 c5             	mov    %rax,%rbp
    676a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    676e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6774:	e8 57 fb ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    6779:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    677f:	48 89 ea             	mov    %rbp,%rdx
    6782:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6788:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    678f:	00 f0 3f 
    6792:	48 89 c7             	mov    %rax,%rdi
    6795:	48 89 ce             	mov    %rcx,%rsi
    6798:	66 48 0f 7e db       	movq   %xmm3,%rbx
    679d:	e8 2e fb ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    67a2:	48 83 c4 28          	add    $0x28,%rsp
    67a6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    67ab:	5b                   	pop    %rbx
    67ac:	5d                   	pop    %rbp
    67ad:	41 5c                	pop    %r12
    67af:	41 5d                	pop    %r13
    67b1:	c3                   	ret
    67b2:	0f 1f 00             	nopl   (%rax)
    67b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67bc:	00 00 00 00 

00000000000067c0 <w176.constprop.0>:
    67c0:	41 54                	push   %r12
    67c2:	55                   	push   %rbp
    67c3:	53                   	push   %rbx
    67c4:	48 83 ec 10          	sub    $0x10,%rsp
    67c8:	4c 8b 27             	mov    (%rdi),%r12
    67cb:	4d 85 e4             	test   %r12,%r12
    67ce:	74 58                	je     6828 <w176.constprop.0+0x68>
    67d0:	48 89 fd             	mov    %rdi,%rbp
    67d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67d7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67de:	31 db                	xor    %ebx,%ebx
    67e0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    67e6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    67eb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    67f2:	00 f0 3f 
    67f5:	48 83 c3 02          	add    $0x2,%rbx
    67f9:	48 89 ce             	mov    %rcx,%rsi
    67fc:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6802:	e8 c9 fa ff ff       	call   62d0 <fwp_p_ad_push.constprop.0>
    6807:	4c 39 e3             	cmp    %r12,%rbx
    680a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6810:	48 89 c7             	mov    %rax,%rdi
    6813:	72 cb                	jb     67e0 <w176.constprop.0+0x20>
    6815:	48 83 c4 10          	add    $0x10,%rsp
    6819:	48 89 f8             	mov    %rdi,%rax
    681c:	5b                   	pop    %rbx
    681d:	5d                   	pop    %rbp
    681e:	41 5c                	pop    %r12
    6820:	c3                   	ret
    6821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6828:	48 83 c4 10          	add    $0x10,%rsp
    682c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6833:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6837:	5b                   	pop    %rbx
    6838:	48 89 f8             	mov    %rdi,%rax
    683b:	5d                   	pop    %rbp
    683c:	41 5c                	pop    %r12
    683e:	c3                   	ret
    683f:	90                   	nop

0000000000006840 <fwp_rc_share>:
    6840:	48 8b 05 b1 23 06 00 	mov    0x623b1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    6847:	48 2b 3d 82 23 06 00 	sub    0x62382(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    684e:	48 c1 e0 10          	shl    $0x10,%rax
    6852:	48 39 c7             	cmp    %rax,%rdi
    6855:	73 4a                	jae    68a1 <fwp_rc_share+0x61>
    6857:	48 89 f8             	mov    %rdi,%rax
    685a:	48 c1 e8 10          	shr    $0x10,%rax
    685e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6862:	48 8b 05 af 23 06 00 	mov    0x623af(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    6869:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    686d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6871:	48 85 d2             	test   %rdx,%rdx
    6874:	74 2b                	je     68a1 <fwp_rc_share+0x61>
    6876:	0f b6 08             	movzbl (%rax),%ecx
    6879:	80 f9 02             	cmp    $0x2,%cl
    687c:	74 2a                	je     68a8 <fwp_rc_share+0x68>
    687e:	80 f9 01             	cmp    $0x1,%cl
    6881:	75 1e                	jne    68a1 <fwp_rc_share+0x61>
    6883:	8b 48 18             	mov    0x18(%rax),%ecx
    6886:	0f b7 ff             	movzwl %di,%edi
    6889:	8b 40 1c             	mov    0x1c(%rax),%eax
    688c:	48 0f af f9          	imul   %rcx,%rdi
    6890:	48 c1 ef 20          	shr    $0x20,%rdi
    6894:	48 39 c7             	cmp    %rax,%rdi
    6897:	73 08                	jae    68a1 <fwp_rc_share+0x61>
    6899:	48 01 fa             	add    %rdi,%rdx
    689c:	80 3a 00             	cmpb   $0x0,(%rdx)
    689f:	75 0d                	jne    68ae <fwp_rc_share+0x6e>
    68a1:	c3                   	ret
    68a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68a8:	66 85 ff             	test   %di,%di
    68ab:	74 ef                	je     689c <fwp_rc_share+0x5c>
    68ad:	c3                   	ret
    68ae:	50                   	push   %rax
    68af:	48 8d 3d 92 51 00 00 	lea    0x5192(%rip),%rdi        # ba48 <_IO_stdin_used+0xa48>
    68b6:	e8 75 db ff ff       	call   4430 <fwp_trap>
    68bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068c0 <fwp_rc_free_obj>:
    68c0:	48 8b 15 31 23 06 00 	mov    0x62331(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    68c7:	48 89 f8             	mov    %rdi,%rax
    68ca:	48 2b 05 ff 22 06 00 	sub    0x622ff(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    68d1:	48 c1 e2 10          	shl    $0x10,%rdx
    68d5:	48 39 d0             	cmp    %rdx,%rax
    68d8:	73 5b                	jae    6935 <fwp_rc_free_obj+0x75>
    68da:	48 89 c2             	mov    %rax,%rdx
    68dd:	48 c1 ea 10          	shr    $0x10,%rdx
    68e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68e5:	48 8b 15 2c 23 06 00 	mov    0x6232c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    68ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    68f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    68f4:	48 85 c9             	test   %rcx,%rcx
    68f7:	74 3c                	je     6935 <fwp_rc_free_obj+0x75>
    68f9:	0f b6 32             	movzbl (%rdx),%esi
    68fc:	40 80 fe 02          	cmp    $0x2,%sil
    6900:	74 2e                	je     6930 <fwp_rc_free_obj+0x70>
    6902:	40 80 fe 01          	cmp    $0x1,%sil
    6906:	75 2d                	jne    6935 <fwp_rc_free_obj+0x75>
    6908:	8b 72 18             	mov    0x18(%rdx),%esi
    690b:	0f b7 c0             	movzwl %ax,%eax
    690e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6911:	48 0f af c6          	imul   %rsi,%rax
    6915:	48 c1 e8 20          	shr    $0x20,%rax
    6919:	48 39 d0             	cmp    %rdx,%rax
    691c:	73 17                	jae    6935 <fwp_rc_free_obj+0x75>
    691e:	48 01 c1             	add    %rax,%rcx
    6921:	80 39 01             	cmpb   $0x1,(%rcx)
    6924:	75 0f                	jne    6935 <fwp_rc_free_obj+0x75>
    6926:	e9 c5 f0 ff ff       	jmp    59f0 <fwp_mem_free>
    692b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6930:	66 85 c0             	test   %ax,%ax
    6933:	74 ec                	je     6921 <fwp_rc_free_obj+0x61>
    6935:	c3                   	ret
    6936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    693d:	00 00 00 

0000000000006940 <fwp_rc_dup>:
    6940:	f3 0f 1e fa          	endbr64
    6944:	48 8b 05 ad 22 06 00 	mov    0x622ad(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    694b:	48 2b 3d 7e 22 06 00 	sub    0x6227e(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    6952:	48 c1 e0 10          	shl    $0x10,%rax
    6956:	48 39 c7             	cmp    %rax,%rdi
    6959:	73 60                	jae    69bb <fwp_rc_dup+0x7b>
    695b:	48 89 f8             	mov    %rdi,%rax
    695e:	48 c1 e8 10          	shr    $0x10,%rax
    6962:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6966:	48 8b 05 ab 22 06 00 	mov    0x622ab(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    696d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6971:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6975:	48 85 c0             	test   %rax,%rax
    6978:	74 41                	je     69bb <fwp_rc_dup+0x7b>
    697a:	0f b6 0a             	movzbl (%rdx),%ecx
    697d:	80 f9 02             	cmp    $0x2,%cl
    6980:	74 3e                	je     69c0 <fwp_rc_dup+0x80>
    6982:	80 f9 01             	cmp    $0x1,%cl
    6985:	75 34                	jne    69bb <fwp_rc_dup+0x7b>
    6987:	8b 4a 18             	mov    0x18(%rdx),%ecx
    698a:	0f b7 ff             	movzwl %di,%edi
    698d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6990:	48 0f af f9          	imul   %rcx,%rdi
    6994:	48 c1 ef 20          	shr    $0x20,%rdi
    6998:	48 39 d7             	cmp    %rdx,%rdi
    699b:	73 1e                	jae    69bb <fwp_rc_dup+0x7b>
    699d:	48 01 f8             	add    %rdi,%rax
    69a0:	0f b6 10             	movzbl (%rax),%edx
    69a3:	84 d2                	test   %dl,%dl
    69a5:	74 14                	je     69bb <fwp_rc_dup+0x7b>
    69a7:	8b 0d 3b 2b 06 00    	mov    0x62b3b(%rip),%ecx        # 694e8 <iteration_active>
    69ad:	85 c9                	test   %ecx,%ecx
    69af:	75 1f                	jne    69d0 <fwp_rc_dup+0x90>
    69b1:	80 fa fd             	cmp    $0xfd,%dl
    69b4:	77 2a                	ja     69e0 <fwp_rc_dup+0xa0>
    69b6:	83 c2 01             	add    $0x1,%edx
    69b9:	88 10                	mov    %dl,(%rax)
    69bb:	c3                   	ret
    69bc:	0f 1f 40 00          	nopl   0x0(%rax)
    69c0:	66 85 ff             	test   %di,%di
    69c3:	74 db                	je     69a0 <fwp_rc_dup+0x60>
    69c5:	c3                   	ret
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 
    69d0:	48 83 05 f8 2a 06 00 	addq   $0x1,0x62af8(%rip)        # 694d0 <iteration_retains>
    69d7:	01 
    69d8:	eb d7                	jmp    69b1 <fwp_rc_dup+0x71>
    69da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69e0:	48 89 c7             	mov    %rax,%rdi
    69e3:	e9 a8 ec ff ff       	jmp    5690 <fwp_rc_wide_dup>
    69e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    69ef:	00 

00000000000069f0 <fwp_owned_entry173>:
    69f0:	f3 0f 1e fa          	endbr64
    69f4:	48 83 ec 38          	sub    $0x38,%rsp
    69f8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    69fd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a04:	00 00 
    6a06:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a0b:	31 c0                	xor    %eax,%eax
    6a0d:	48 8b 07             	mov    (%rdi),%rax
    6a10:	48 03 47 10          	add    0x10(%rdi),%rax
    6a14:	0f 80 c2 00 00 00    	jo     6adc <fwp_owned_entry173+0xec>
    6a1a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a1f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a24:	31 ff                	xor    %edi,%edi
    6a26:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a2a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6a2f:	e8 ac f6 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6a34:	48 8b 15 bd 21 06 00 	mov    0x621bd(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6a3b:	48 89 c6             	mov    %rax,%rsi
    6a3e:	48 2b 05 8b 21 06 00 	sub    0x6218b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6a45:	48 c1 e2 10          	shl    $0x10,%rdx
    6a49:	48 39 d0             	cmp    %rdx,%rax
    6a4c:	73 4f                	jae    6a9d <fwp_owned_entry173+0xad>
    6a4e:	48 89 c2             	mov    %rax,%rdx
    6a51:	48 c1 ea 10          	shr    $0x10,%rdx
    6a55:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a59:	48 8b 15 b8 21 06 00 	mov    0x621b8(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6a60:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a64:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a68:	48 85 d2             	test   %rdx,%rdx
    6a6b:	74 30                	je     6a9d <fwp_owned_entry173+0xad>
    6a6d:	0f b6 39             	movzbl (%rcx),%edi
    6a70:	40 80 ff 02          	cmp    $0x2,%dil
    6a74:	74 42                	je     6ab8 <fwp_owned_entry173+0xc8>
    6a76:	40 80 ff 01          	cmp    $0x1,%dil
    6a7a:	75 21                	jne    6a9d <fwp_owned_entry173+0xad>
    6a7c:	8b 79 18             	mov    0x18(%rcx),%edi
    6a7f:	0f b7 c0             	movzwl %ax,%eax
    6a82:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a85:	48 0f af c7          	imul   %rdi,%rax
    6a89:	48 c1 e8 20          	shr    $0x20,%rax
    6a8d:	48 39 c8             	cmp    %rcx,%rax
    6a90:	73 0b                	jae    6a9d <fwp_owned_entry173+0xad>
    6a92:	48 01 c2             	add    %rax,%rdx
    6a95:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a98:	74 26                	je     6ac0 <fwp_owned_entry173+0xd0>
    6a9a:	c6 02 01             	movb   $0x1,(%rdx)
    6a9d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6aa2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6aa9:	00 00 
    6aab:	75 34                	jne    6ae1 <fwp_owned_entry173+0xf1>
    6aad:	48 89 f0             	mov    %rsi,%rax
    6ab0:	48 83 c4 38          	add    $0x38,%rsp
    6ab4:	c3                   	ret
    6ab5:	0f 1f 00             	nopl   (%rax)
    6ab8:	66 85 c0             	test   %ax,%ax
    6abb:	75 e0                	jne    6a9d <fwp_owned_entry173+0xad>
    6abd:	eb d6                	jmp    6a95 <fwp_owned_entry173+0xa5>
    6abf:	90                   	nop
    6ac0:	48 89 d7             	mov    %rdx,%rdi
    6ac3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6ac8:	48 89 14 24          	mov    %rdx,(%rsp)
    6acc:	e8 df ec ff ff       	call   57b0 <fwp_rc_forget_slot>
    6ad1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6ad6:	48 8b 14 24          	mov    (%rsp),%rdx
    6ada:	eb be                	jmp    6a9a <fwp_owned_entry173+0xaa>
    6adc:	e8 ff cb ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6ae1:	e8 6a c9 ff ff       	call   3450 <__stack_chk_fail@plt>
    6ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6aed:	00 00 00 

0000000000006af0 <e173>:
    6af0:	f3 0f 1e fa          	endbr64
    6af4:	53                   	push   %rbx
    6af5:	48 83 ec 30          	sub    $0x30,%rsp
    6af9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6afe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b05:	00 00 
    6b07:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b0c:	31 c0                	xor    %eax,%eax
    6b0e:	48 8b 07             	mov    (%rdi),%rax
    6b11:	48 03 47 10          	add    0x10(%rdi),%rax
    6b15:	0f 80 c9 00 00 00    	jo     6be4 <e173+0xf4>
    6b1b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b20:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b25:	31 ff                	xor    %edi,%edi
    6b27:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b2b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b30:	e8 ab f5 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6b35:	48 8b 15 bc 20 06 00 	mov    0x620bc(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6b3c:	48 89 c3             	mov    %rax,%rbx
    6b3f:	48 2b 05 8a 20 06 00 	sub    0x6208a(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6b46:	48 c1 e2 10          	shl    $0x10,%rdx
    6b4a:	48 39 d0             	cmp    %rdx,%rax
    6b4d:	73 4f                	jae    6b9e <e173+0xae>
    6b4f:	48 89 c2             	mov    %rax,%rdx
    6b52:	48 c1 ea 10          	shr    $0x10,%rdx
    6b56:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b5a:	48 8b 15 b7 20 06 00 	mov    0x620b7(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6b61:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b65:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b69:	48 85 d2             	test   %rdx,%rdx
    6b6c:	74 30                	je     6b9e <e173+0xae>
    6b6e:	0f b6 31             	movzbl (%rcx),%esi
    6b71:	40 80 fe 02          	cmp    $0x2,%sil
    6b75:	74 49                	je     6bc0 <e173+0xd0>
    6b77:	40 80 fe 01          	cmp    $0x1,%sil
    6b7b:	75 21                	jne    6b9e <e173+0xae>
    6b7d:	8b 71 18             	mov    0x18(%rcx),%esi
    6b80:	0f b7 c0             	movzwl %ax,%eax
    6b83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b86:	48 0f af c6          	imul   %rsi,%rax
    6b8a:	48 c1 e8 20          	shr    $0x20,%rax
    6b8e:	48 39 c8             	cmp    %rcx,%rax
    6b91:	73 0b                	jae    6b9e <e173+0xae>
    6b93:	48 01 c2             	add    %rax,%rdx
    6b96:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b99:	74 35                	je     6bd0 <e173+0xe0>
    6b9b:	c6 02 01             	movb   $0x1,(%rdx)
    6b9e:	48 89 df             	mov    %rbx,%rdi
    6ba1:	e8 9a fc ff ff       	call   6840 <fwp_rc_share>
    6ba6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6bab:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6bb2:	00 00 
    6bb4:	75 33                	jne    6be9 <e173+0xf9>
    6bb6:	48 83 c4 30          	add    $0x30,%rsp
    6bba:	48 89 d8             	mov    %rbx,%rax
    6bbd:	5b                   	pop    %rbx
    6bbe:	c3                   	ret
    6bbf:	90                   	nop
    6bc0:	66 85 c0             	test   %ax,%ax
    6bc3:	75 d9                	jne    6b9e <e173+0xae>
    6bc5:	eb cf                	jmp    6b96 <e173+0xa6>
    6bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bce:	00 00 
    6bd0:	48 89 d7             	mov    %rdx,%rdi
    6bd3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bd8:	e8 d3 eb ff ff       	call   57b0 <fwp_rc_forget_slot>
    6bdd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6be2:	eb b7                	jmp    6b9b <e173+0xab>
    6be4:	e8 f7 ca ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6be9:	e8 62 c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6bee:	66 90                	xchg   %ax,%ax

0000000000006bf0 <fwp_closure_drop>:
    6bf0:	48 8b 15 01 20 06 00 	mov    0x62001(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6bf7:	48 89 f8             	mov    %rdi,%rax
    6bfa:	48 2b 05 cf 1f 06 00 	sub    0x61fcf(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6c01:	48 c1 e2 10          	shl    $0x10,%rdx
    6c05:	48 39 d0             	cmp    %rdx,%rax
    6c08:	73 6b                	jae    6c75 <fwp_closure_drop+0x85>
    6c0a:	48 89 c2             	mov    %rax,%rdx
    6c0d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c15:	48 8b 15 fc 1f 06 00 	mov    0x61ffc(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6c1c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c20:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c24:	48 85 d2             	test   %rdx,%rdx
    6c27:	74 4c                	je     6c75 <fwp_closure_drop+0x85>
    6c29:	0f b6 31             	movzbl (%rcx),%esi
    6c2c:	40 80 fe 02          	cmp    $0x2,%sil
    6c30:	74 3e                	je     6c70 <fwp_closure_drop+0x80>
    6c32:	40 80 fe 01          	cmp    $0x1,%sil
    6c36:	75 3d                	jne    6c75 <fwp_closure_drop+0x85>
    6c38:	8b 71 18             	mov    0x18(%rcx),%esi
    6c3b:	0f b7 c0             	movzwl %ax,%eax
    6c3e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c41:	48 0f af c6          	imul   %rsi,%rax
    6c45:	48 c1 e8 20          	shr    $0x20,%rax
    6c49:	48 39 c8             	cmp    %rcx,%rax
    6c4c:	73 27                	jae    6c75 <fwp_closure_drop+0x85>
    6c4e:	48 01 c2             	add    %rax,%rdx
    6c51:	0f b6 02             	movzbl (%rdx),%eax
    6c54:	84 c0                	test   %al,%al
    6c56:	74 1d                	je     6c75 <fwp_closure_drop+0x85>
    6c58:	3c 01                	cmp    $0x1,%al
    6c5a:	74 24                	je     6c80 <fwp_closure_drop+0x90>
    6c5c:	3c ff                	cmp    $0xff,%al
    6c5e:	74 48                	je     6ca8 <fwp_closure_drop+0xb8>
    6c60:	83 e8 01             	sub    $0x1,%eax
    6c63:	88 02                	mov    %al,(%rdx)
    6c65:	c3                   	ret
    6c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c6d:	00 00 00 
    6c70:	66 85 c0             	test   %ax,%ax
    6c73:	74 dc                	je     6c51 <fwp_closure_drop+0x61>
    6c75:	c3                   	ret
    6c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c7d:	00 00 00 
    6c80:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6c87:	ff ff 
    6c89:	48 85 c0             	test   %rax,%rax
    6c8c:	74 12                	je     6ca0 <fwp_closure_drop+0xb0>
    6c8e:	48 89 fe             	mov    %rdi,%rsi
    6c91:	48 89 c7             	mov    %rax,%rdi
    6c94:	e9 f7 d7 ff ff       	jmp    4490 <fwp_closure_drop_push>
    6c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ca0:	e9 9b d9 ff ff       	jmp    4640 <fwp_closure_drop.part.0>
    6ca5:	0f 1f 00             	nopl   (%rax)
    6ca8:	48 89 d0             	mov    %rdx,%rax
    6cab:	48 8d 35 6e 0b 06 00 	lea    0x60b6e(%rip),%rsi        # 67820 <fwp_heap>
    6cb2:	48 83 ec 18          	sub    $0x18,%rsp
    6cb6:	48 c1 e8 11          	shr    $0x11,%rax
    6cba:	48 31 d0             	xor    %rdx,%rax
    6cbd:	48 89 c1             	mov    %rax,%rcx
    6cc0:	48 c1 e9 09          	shr    $0x9,%rcx
    6cc4:	48 31 c8             	xor    %rcx,%rax
    6cc7:	0f b6 c8             	movzbl %al,%ecx
    6cca:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6cd1:	00 
    6cd2:	48 85 c0             	test   %rax,%rax
    6cd5:	75 12                	jne    6ce9 <fwp_closure_drop+0xf9>
    6cd7:	eb 49                	jmp    6d22 <fwp_closure_drop+0x132>
    6cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ce0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6ce4:	48 85 c0             	test   %rax,%rax
    6ce7:	74 39                	je     6d22 <fwp_closure_drop+0x132>
    6ce9:	48 89 c1             	mov    %rax,%rcx
    6cec:	48 39 10             	cmp    %rdx,(%rax)
    6cef:	75 ef                	jne    6ce0 <fwp_closure_drop+0xf0>
    6cf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6cf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6cf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6cfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d04:	74 05                	je     6d0b <fwp_closure_drop+0x11b>
    6d06:	48 83 c4 18          	add    $0x18,%rsp
    6d0a:	c3                   	ret
    6d0b:	48 89 d7             	mov    %rdx,%rdi
    6d0e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d13:	e8 98 ea ff ff       	call   57b0 <fwp_rc_forget_slot>
    6d18:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d1d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d20:	eb e4                	jmp    6d06 <fwp_closure_drop+0x116>
    6d22:	48 8d 3d 7f 4c 00 00 	lea    0x4c7f(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    6d29:	e8 02 d7 ff ff       	call   4430 <fwp_trap>
    6d2e:	66 90                	xchg   %ax,%ax

0000000000006d30 <fwp_owned_tape_release>:
    6d30:	48 85 ff             	test   %rdi,%rdi
    6d33:	0f 84 f7 00 00 00    	je     6e30 <fwp_owned_tape_release+0x100>
    6d39:	41 54                	push   %r12
    6d3b:	55                   	push   %rbp
    6d3c:	53                   	push   %rbx
    6d3d:	48 8b 07             	mov    (%rdi),%rax
    6d40:	48 85 c0             	test   %rax,%rax
    6d43:	74 08                	je     6d4d <fwp_owned_tape_release+0x1d>
    6d45:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d49:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d4d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d51:	48 85 d2             	test   %rdx,%rdx
    6d54:	74 03                	je     6d59 <fwp_owned_tape_release+0x29>
    6d56:	48 89 02             	mov    %rax,(%rdx)
    6d59:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6d5d:	48 89 fb             	mov    %rdi,%rbx
    6d60:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6d64:	48 85 c0             	test   %rax,%rax
    6d67:	0f 84 89 00 00 00    	je     6df6 <fwp_owned_tape_release+0xc6>
    6d6d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6d71:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6d75:	7e 47                	jle    6dbe <fwp_owned_tape_release+0x8e>
    6d77:	31 ed                	xor    %ebp,%ebp
    6d79:	eb 0d                	jmp    6d88 <fwp_owned_tape_release+0x58>
    6d7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d80:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d84:	48 8b 40 68          	mov    0x68(%rax),%rax
    6d88:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6d8c:	49 89 ec             	mov    %rbp,%r12
    6d8f:	48 83 c5 01          	add    $0x1,%rbp
    6d93:	49 c1 e4 04          	shl    $0x4,%r12
    6d97:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6d9b:	ff d0                	call   *%rax
    6d9d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6da1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6da6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6daa:	ff 50 68             	call   *0x68(%rax)
    6dad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6db1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6db5:	48 39 e8             	cmp    %rbp,%rax
    6db8:	7f c6                	jg     6d80 <fwp_owned_tape_release+0x50>
    6dba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6dbe:	31 ed                	xor    %ebp,%ebp
    6dc0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6dc5:	7e 28                	jle    6def <fwp_owned_tape_release+0xbf>
    6dc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dce:	00 00 
    6dd0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6dd4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6dd8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6ddc:	74 07                	je     6de5 <fwp_owned_tape_release+0xb5>
    6dde:	ff 52 68             	call   *0x68(%rdx)
    6de1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6de5:	48 83 c5 01          	add    $0x1,%rbp
    6de9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6ded:	7f e1                	jg     6dd0 <fwp_owned_tape_release+0xa0>
    6def:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6df3:	ff 52 68             	call   *0x68(%rdx)
    6df6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6dfa:	e8 f1 fd ff ff       	call   6bf0 <fwp_closure_drop>
    6dff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6e03:	e8 e8 fd ff ff       	call   6bf0 <fwp_closure_drop>
    6e08:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6e0c:	e8 df fd ff ff       	call   6bf0 <fwp_closure_drop>
    6e11:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6e15:	e8 d6 eb ff ff       	call   59f0 <fwp_mem_free>
    6e1a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6e1e:	e8 cd eb ff ff       	call   59f0 <fwp_mem_free>
    6e23:	48 89 df             	mov    %rbx,%rdi
    6e26:	5b                   	pop    %rbx
    6e27:	5d                   	pop    %rbp
    6e28:	41 5c                	pop    %r12
    6e2a:	e9 c1 eb ff ff       	jmp    59f0 <fwp_mem_free>
    6e2f:	90                   	nop
    6e30:	c3                   	ret
    6e31:	0f 1f 40 00          	nopl   0x0(%rax)
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 

0000000000006e40 <fwp_tape_finish>:
    6e40:	f3 0f 1e fa          	endbr64
    6e44:	41 55                	push   %r13
    6e46:	41 54                	push   %r12
    6e48:	55                   	push   %rbp
    6e49:	53                   	push   %rbx
    6e4a:	48 83 ec 48          	sub    $0x48,%rsp
    6e4e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6e55:	00 00 
    6e57:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6e5c:	48 8d 3d 3d 82 01 00 	lea    0x1823d(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    6e63:	e8 b8 e2 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    6e68:	48 83 3d 78 82 01 00 	cmpq   $0x0,0x18278(%rip)        # 1f0e8 <fwp_ntapes>
    6e6f:	00 
    6e70:	48 c7 05 0d 82 01 00 	movq   $0x0,0x1820d(%rip)        # 1f088 <fwp_tape_cached_bytes>
    6e77:	00 00 00 00 
    6e7b:	7e 79                	jle    6ef6 <fwp_tape_finish+0xb6>
    6e7d:	45 31 e4             	xor    %r12d,%r12d
    6e80:	31 ed                	xor    %ebp,%ebp
    6e82:	0f 1f 00             	nopl   (%rax)
    6e85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e8c:	00 00 00 00 
    6e90:	48 8b 1d 59 82 01 00 	mov    0x18259(%rip),%rbx        # 1f0f0 <fwp_tapes>
    6e97:	48 83 c5 01          	add    $0x1,%rbp
    6e9b:	4c 01 e3             	add    %r12,%rbx
    6e9e:	49 83 c4 68          	add    $0x68,%r12
    6ea2:	48 89 df             	mov    %rbx,%rdi
    6ea5:	e8 c6 cd ff ff       	call   3c70 <fwp_tape_unlink_scope>
    6eaa:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6eaf:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6eb4:	48 89 e7             	mov    %rsp,%rdi
    6eb7:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6ebb:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6ebf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6ec4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ec9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6ece:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6ed2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6ed7:	e8 44 e2 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    6edc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6ee0:	e8 4b fe ff ff       	call   6d30 <fwp_owned_tape_release>
    6ee5:	48 39 2d fc 81 01 00 	cmp    %rbp,0x181fc(%rip)        # 1f0e8 <fwp_ntapes>
    6eec:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6ef3:	00 
    6ef4:	7f 9a                	jg     6e90 <fwp_tape_finish+0x50>
    6ef6:	48 8b 3d f3 81 01 00 	mov    0x181f3(%rip),%rdi        # 1f0f0 <fwp_tapes>
    6efd:	48 85 ff             	test   %rdi,%rdi
    6f00:	74 05                	je     6f07 <fwp_tape_finish+0xc7>
    6f02:	e8 a9 e1 ff ff       	call   50b0 <ad_raw_free.part.0>
    6f07:	48 c7 05 de 81 01 00 	movq   $0x0,0x181de(%rip)        # 1f0f0 <fwp_tapes>
    6f0e:	00 00 00 00 
    6f12:	48 c7 05 c3 81 01 00 	movq   $0x0,0x181c3(%rip)        # 1f0e0 <fwp_tapes_cap>
    6f19:	00 00 00 00 
    6f1d:	48 c7 05 c0 81 01 00 	movq   $0x0,0x181c0(%rip)        # 1f0e8 <fwp_ntapes>
    6f24:	00 00 00 00 
    6f28:	48 c7 05 a5 81 01 00 	movq   $0x0,0x181a5(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6f2f:	00 00 00 00 
    6f33:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6f38:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f3f:	00 00 
    6f41:	75 0b                	jne    6f4e <fwp_tape_finish+0x10e>
    6f43:	48 83 c4 48          	add    $0x48,%rsp
    6f47:	5b                   	pop    %rbx
    6f48:	5d                   	pop    %rbp
    6f49:	41 5c                	pop    %r12
    6f4b:	41 5d                	pop    %r13
    6f4d:	c3                   	ret
    6f4e:	e8 fd c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f53:	66 90                	xchg   %ax,%ax
    6f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f5c:	00 00 00 00 

0000000000006f60 <fwp_tape_scope_release>:
    6f60:	f3 0f 1e fa          	endbr64
    6f64:	41 55                	push   %r13
    6f66:	41 54                	push   %r12
    6f68:	55                   	push   %rbp
    6f69:	53                   	push   %rbx
    6f6a:	48 83 ec 48          	sub    $0x48,%rsp
    6f6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f75:	00 00 
    6f77:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6f7c:	48 63 07             	movslq (%rdi),%rax
    6f7f:	85 c0                	test   %eax,%eax
    6f81:	0f 88 e8 00 00 00    	js     706f <fwp_tape_scope_release+0x10f>
    6f87:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    6f8e:	ec c4 4e 
    6f91:	48 89 fb             	mov    %rdi,%rbx
    6f94:	48 89 e5             	mov    %rsp,%rbp
    6f97:	eb 1f                	jmp    6fb8 <fwp_tape_scope_release+0x58>
    6f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6fa0:	e8 7b e1 ff ff       	call   5120 <fwp_tape_buffers_dispose>
    6fa5:	4c 89 ef             	mov    %r13,%rdi
    6fa8:	e8 83 fd ff ff       	call   6d30 <fwp_owned_tape_release>
    6fad:	48 63 03             	movslq (%rbx),%rax
    6fb0:	85 c0                	test   %eax,%eax
    6fb2:	0f 88 b7 00 00 00    	js     706f <fwp_tape_scope_release+0x10f>
    6fb8:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6fbc:	48 8b 35 2d 81 01 00 	mov    0x1812d(%rip),%rsi        # 1f0f0 <fwp_tapes>
    6fc3:	4c 01 c6             	add    %r8,%rsi
    6fc6:	48 89 f7             	mov    %rsi,%rdi
    6fc9:	e8 a2 cc ff ff       	call   3c70 <fwp_tape_unlink_scope>
    6fce:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6fd3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6fd8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6fdf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    6fe3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    6fe7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6fee:	00 
    6fef:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ff4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    6ff9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    6ffd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7002:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7006:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    700b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7012:	00 
    7013:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    701a:	00 
    701b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7022:	00 
    7023:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7027:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    702b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    702f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7033:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7039:	77 18                	ja     7053 <fwp_tape_scope_release+0xf3>
    703b:	49 c1 f8 03          	sar    $0x3,%r8
    703f:	4d 0f af c4          	imul   %r12,%r8
    7043:	4c 3b 05 8e 80 01 00 	cmp    0x1808e(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    704a:	7d 07                	jge    7053 <fwp_tape_scope_release+0xf3>
    704c:	4c 89 05 85 80 01 00 	mov    %r8,0x18085(%rip)        # 1f0d8 <fwp_tape_next_slot>
    7053:	48 89 ef             	mov    %rbp,%rdi
    7056:	4d 85 ed             	test   %r13,%r13
    7059:	0f 85 41 ff ff ff    	jne    6fa0 <fwp_tape_scope_release+0x40>
    705f:	e8 dc e1 ff ff       	call   5240 <fwp_tape_buffers_release>
    7064:	48 63 03             	movslq (%rbx),%rax
    7067:	85 c0                	test   %eax,%eax
    7069:	0f 89 49 ff ff ff    	jns    6fb8 <fwp_tape_scope_release+0x58>
    706f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7074:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    707b:	00 00 
    707d:	75 0b                	jne    708a <fwp_tape_scope_release+0x12a>
    707f:	48 83 c4 48          	add    $0x48,%rsp
    7083:	5b                   	pop    %rbx
    7084:	5d                   	pop    %rbp
    7085:	41 5c                	pop    %r12
    7087:	41 5d                	pop    %r13
    7089:	c3                   	ret
    708a:	e8 c1 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    708f:	90                   	nop

0000000000007090 <fwp_drop4>:
    7090:	48 8b 0d 61 1b 06 00 	mov    0x61b61(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7097:	48 89 f8             	mov    %rdi,%rax
    709a:	48 2b 05 2f 1b 06 00 	sub    0x61b2f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    70a1:	48 c1 e1 10          	shl    $0x10,%rcx
    70a5:	48 39 c8             	cmp    %rcx,%rax
    70a8:	0f 83 42 01 00 00    	jae    71f0 <fwp_drop4+0x160>
    70ae:	48 83 ec 18          	sub    $0x18,%rsp
    70b2:	48 89 fa             	mov    %rdi,%rdx
    70b5:	4c 8d 05 64 07 06 00 	lea    0x60764(%rip),%r8        # 67820 <fwp_heap>
    70bc:	48 89 c1             	mov    %rax,%rcx
    70bf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    70c6:	48 c1 e9 10          	shr    $0x10,%rcx
    70ca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    70ce:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    70d2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    70d6:	48 85 c9             	test   %rcx,%rcx
    70d9:	74 40                	je     711b <fwp_drop4+0x8b>
    70db:	0f b6 3e             	movzbl (%rsi),%edi
    70de:	40 80 ff 02          	cmp    $0x2,%dil
    70e2:	74 3c                	je     7120 <fwp_drop4+0x90>
    70e4:	40 80 ff 01          	cmp    $0x1,%dil
    70e8:	75 31                	jne    711b <fwp_drop4+0x8b>
    70ea:	8b 7e 18             	mov    0x18(%rsi),%edi
    70ed:	0f b7 c0             	movzwl %ax,%eax
    70f0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    70f3:	48 0f af c7          	imul   %rdi,%rax
    70f7:	48 c1 e8 20          	shr    $0x20,%rax
    70fb:	48 39 f0             	cmp    %rsi,%rax
    70fe:	73 1b                	jae    711b <fwp_drop4+0x8b>
    7100:	48 01 c1             	add    %rax,%rcx
    7103:	0f b6 01             	movzbl (%rcx),%eax
    7106:	84 c0                	test   %al,%al
    7108:	74 11                	je     711b <fwp_drop4+0x8b>
    710a:	3c 01                	cmp    $0x1,%al
    710c:	74 22                	je     7130 <fwp_drop4+0xa0>
    710e:	3c ff                	cmp    $0xff,%al
    7110:	0f 84 0a 01 00 00    	je     7220 <fwp_drop4+0x190>
    7116:	83 e8 01             	sub    $0x1,%eax
    7119:	88 01                	mov    %al,(%rcx)
    711b:	48 83 c4 18          	add    $0x18,%rsp
    711f:	c3                   	ret
    7120:	66 85 c0             	test   %ax,%ax
    7123:	74 de                	je     7103 <fwp_drop4+0x73>
    7125:	48 83 c4 18          	add    $0x18,%rsp
    7129:	c3                   	ret
    712a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7130:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7134:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    713b:	48 89 f8             	mov    %rdi,%rax
    713e:	48 c1 e1 10          	shl    $0x10,%rcx
    7142:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7149:	48 39 c8             	cmp    %rcx,%rax
    714c:	73 62                	jae    71b0 <fwp_drop4+0x120>
    714e:	48 89 c1             	mov    %rax,%rcx
    7151:	48 c1 e9 10          	shr    $0x10,%rcx
    7155:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7159:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    715d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7161:	48 85 c9             	test   %rcx,%rcx
    7164:	74 4a                	je     71b0 <fwp_drop4+0x120>
    7166:	44 0f b6 0e          	movzbl (%rsi),%r9d
    716a:	41 80 f9 02          	cmp    $0x2,%r9b
    716e:	0f 84 9c 00 00 00    	je     7210 <fwp_drop4+0x180>
    7174:	41 80 f9 01          	cmp    $0x1,%r9b
    7178:	75 36                	jne    71b0 <fwp_drop4+0x120>
    717a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    717e:	0f b7 c0             	movzwl %ax,%eax
    7181:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7184:	49 0f af c1          	imul   %r9,%rax
    7188:	48 c1 e8 20          	shr    $0x20,%rax
    718c:	48 39 f0             	cmp    %rsi,%rax
    718f:	73 1f                	jae    71b0 <fwp_drop4+0x120>
    7191:	48 01 c1             	add    %rax,%rcx
    7194:	0f b6 01             	movzbl (%rcx),%eax
    7197:	84 c0                	test   %al,%al
    7199:	74 15                	je     71b0 <fwp_drop4+0x120>
    719b:	3c 01                	cmp    $0x1,%al
    719d:	74 59                	je     71f8 <fwp_drop4+0x168>
    719f:	3c ff                	cmp    $0xff,%al
    71a1:	0f 84 ff 00 00 00    	je     72a6 <fwp_drop4+0x216>
    71a7:	83 e8 01             	sub    $0x1,%eax
    71aa:	88 01                	mov    %al,(%rcx)
    71ac:	0f 1f 40 00          	nopl   0x0(%rax)
    71b0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    71b4:	48 89 d7             	mov    %rdx,%rdi
    71b7:	48 89 0c 24          	mov    %rcx,(%rsp)
    71bb:	e8 00 f7 ff ff       	call   68c0 <fwp_rc_free_obj>
    71c0:	4c 8d 05 59 06 06 00 	lea    0x60659(%rip),%r8        # 67820 <fwp_heap>
    71c7:	48 8b 04 24          	mov    (%rsp),%rax
    71cb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    71d2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71d9:	48 c1 e2 10          	shl    $0x10,%rdx
    71dd:	48 39 d0             	cmp    %rdx,%rax
    71e0:	0f 83 35 ff ff ff    	jae    711b <fwp_drop4+0x8b>
    71e6:	48 8b 14 24          	mov    (%rsp),%rdx
    71ea:	e9 cd fe ff ff       	jmp    70bc <fwp_drop4+0x2c>
    71ef:	90                   	nop
    71f0:	c3                   	ret
    71f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71f8:	48 89 14 24          	mov    %rdx,(%rsp)
    71fc:	e8 bf f6 ff ff       	call   68c0 <fwp_rc_free_obj>
    7201:	48 8b 14 24          	mov    (%rsp),%rdx
    7205:	eb a9                	jmp    71b0 <fwp_drop4+0x120>
    7207:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    720e:	00 00 
    7210:	66 85 c0             	test   %ax,%ax
    7213:	75 9b                	jne    71b0 <fwp_drop4+0x120>
    7215:	e9 7a ff ff ff       	jmp    7194 <fwp_drop4+0x104>
    721a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7220:	48 89 c8             	mov    %rcx,%rax
    7223:	48 c1 e8 11          	shr    $0x11,%rax
    7227:	48 31 c8             	xor    %rcx,%rax
    722a:	48 89 c2             	mov    %rax,%rdx
    722d:	48 c1 ea 09          	shr    $0x9,%rdx
    7231:	48 31 d0             	xor    %rdx,%rax
    7234:	0f b6 d0             	movzbl %al,%edx
    7237:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    723e:	00 
    723f:	48 85 c0             	test   %rax,%rax
    7242:	75 29                	jne    726d <fwp_drop4+0x1dd>
    7244:	e9 e3 00 00 00       	jmp    732c <fwp_drop4+0x29c>
    7249:	90                   	nop
    724a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7251:	00 00 00 00 
    7255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    725c:	00 00 00 00 
    7260:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7264:	48 85 c0             	test   %rax,%rax
    7267:	0f 84 bf 00 00 00    	je     732c <fwp_drop4+0x29c>
    726d:	48 89 c2             	mov    %rax,%rdx
    7270:	48 39 08             	cmp    %rcx,(%rax)
    7273:	75 eb                	jne    7260 <fwp_drop4+0x1d0>
    7275:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7279:	48 83 ea 01          	sub    $0x1,%rdx
    727d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7281:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7288:	0f 85 8d fe ff ff    	jne    711b <fwp_drop4+0x8b>
    728e:	48 89 cf             	mov    %rcx,%rdi
    7291:	48 89 0c 24          	mov    %rcx,(%rsp)
    7295:	e8 16 e5 ff ff       	call   57b0 <fwp_rc_forget_slot>
    729a:	48 8b 0c 24          	mov    (%rsp),%rcx
    729e:	c6 01 fe             	movb   $0xfe,(%rcx)
    72a1:	e9 75 fe ff ff       	jmp    711b <fwp_drop4+0x8b>
    72a6:	48 89 ce             	mov    %rcx,%rsi
    72a9:	48 c1 ee 11          	shr    $0x11,%rsi
    72ad:	48 31 ce             	xor    %rcx,%rsi
    72b0:	48 89 f0             	mov    %rsi,%rax
    72b3:	48 c1 e8 09          	shr    $0x9,%rax
    72b7:	48 31 c6             	xor    %rax,%rsi
    72ba:	40 0f b6 f6          	movzbl %sil,%esi
    72be:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    72c5:	00 
    72c6:	48 85 c0             	test   %rax,%rax
    72c9:	75 1e                	jne    72e9 <fwp_drop4+0x259>
    72cb:	eb 5f                	jmp    732c <fwp_drop4+0x29c>
    72cd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72d4:	00 
    72d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72dc:	00 00 00 00 
    72e0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    72e4:	48 85 c0             	test   %rax,%rax
    72e7:	74 43                	je     732c <fwp_drop4+0x29c>
    72e9:	48 89 c6             	mov    %rax,%rsi
    72ec:	48 39 08             	cmp    %rcx,(%rax)
    72ef:	75 ef                	jne    72e0 <fwp_drop4+0x250>
    72f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72f5:	48 83 ee 01          	sub    $0x1,%rsi
    72f9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    72fd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7304:	0f 85 a6 fe ff ff    	jne    71b0 <fwp_drop4+0x120>
    730a:	48 89 cf             	mov    %rcx,%rdi
    730d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7312:	48 89 0c 24          	mov    %rcx,(%rsp)
    7316:	e8 95 e4 ff ff       	call   57b0 <fwp_rc_forget_slot>
    731b:	48 8b 0c 24          	mov    (%rsp),%rcx
    731f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7324:	c6 01 fe             	movb   $0xfe,(%rcx)
    7327:	e9 84 fe ff ff       	jmp    71b0 <fwp_drop4+0x120>
    732c:	48 8d 3d 75 46 00 00 	lea    0x4675(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7333:	e8 f8 d0 ff ff       	call   4430 <fwp_trap>
    7338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    733f:	00 

0000000000007340 <fwp_arg_drop37>:
    7340:	f3 0f 1e fa          	endbr64
    7344:	85 f6                	test   %esi,%esi
    7346:	75 04                	jne    734c <fwp_arg_drop37+0xc>
    7348:	85 d2                	test   %edx,%edx
    734a:	75 04                	jne    7350 <fwp_arg_drop37+0x10>
    734c:	c3                   	ret
    734d:	0f 1f 00             	nopl   (%rax)
    7350:	48 8b 3f             	mov    (%rdi),%rdi
    7353:	e9 38 fd ff ff       	jmp    7090 <fwp_drop4>
    7358:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    735f:	00 

0000000000007360 <fwp_task_dispose>:
    7360:	53                   	push   %rbx
    7361:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7365:	0f 84 bb c3 ff ff    	je     3726 <fwp_task_dispose.cold>
    736b:	48 89 fb             	mov    %rdi,%rbx
    736e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7373:	0f 85 ad c3 ff ff    	jne    3726 <fwp_task_dispose.cold>
    7379:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    737d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7384:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    738b:	00 
    738c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7390:	48 85 ff             	test   %rdi,%rdi
    7393:	74 07                	je     739c <fwp_task_dispose+0x3c>
    7395:	48 85 c0             	test   %rax,%rax
    7398:	74 02                	je     739c <fwp_task_dispose+0x3c>
    739a:	ff d0                	call   *%rax
    739c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    73a3:	e8 48 e6 ff ff       	call   59f0 <fwp_mem_free>
    73a8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    73af:	00 00 00 00 
    73b3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    73b7:	74 6f                	je     7428 <fwp_task_dispose+0xc8>
    73b9:	48 8b 15 38 18 06 00 	mov    0x61838(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    73c0:	48 89 d8             	mov    %rbx,%rax
    73c3:	48 2b 05 06 18 06 00 	sub    0x61806(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    73ca:	48 c1 e2 10          	shl    $0x10,%rdx
    73ce:	48 39 d0             	cmp    %rdx,%rax
    73d1:	73 4c                	jae    741f <fwp_task_dispose+0xbf>
    73d3:	48 89 c2             	mov    %rax,%rdx
    73d6:	48 c1 ea 10          	shr    $0x10,%rdx
    73da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73de:	48 8b 15 33 18 06 00 	mov    0x61833(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    73e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73e9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    73ed:	48 85 c9             	test   %rcx,%rcx
    73f0:	74 2d                	je     741f <fwp_task_dispose+0xbf>
    73f2:	0f b6 32             	movzbl (%rdx),%esi
    73f5:	40 80 fe 02          	cmp    $0x2,%sil
    73f9:	74 3d                	je     7438 <fwp_task_dispose+0xd8>
    73fb:	40 80 fe 01          	cmp    $0x1,%sil
    73ff:	75 1e                	jne    741f <fwp_task_dispose+0xbf>
    7401:	8b 72 18             	mov    0x18(%rdx),%esi
    7404:	0f b7 c0             	movzwl %ax,%eax
    7407:	8b 52 1c             	mov    0x1c(%rdx),%edx
    740a:	48 0f af c6          	imul   %rsi,%rax
    740e:	48 c1 e8 20          	shr    $0x20,%rax
    7412:	48 39 d0             	cmp    %rdx,%rax
    7415:	73 08                	jae    741f <fwp_task_dispose+0xbf>
    7417:	48 01 c1             	add    %rax,%rcx
    741a:	80 39 01             	cmpb   $0x1,(%rcx)
    741d:	74 09                	je     7428 <fwp_task_dispose+0xc8>
    741f:	5b                   	pop    %rbx
    7420:	c3                   	ret
    7421:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7428:	48 89 df             	mov    %rbx,%rdi
    742b:	5b                   	pop    %rbx
    742c:	e9 bf e5 ff ff       	jmp    59f0 <fwp_mem_free>
    7431:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7438:	66 85 c0             	test   %ax,%ax
    743b:	74 dd                	je     741a <fwp_task_dispose+0xba>
    743d:	5b                   	pop    %rbx
    743e:	c3                   	ret
    743f:	90                   	nop

0000000000007440 <fwp_free_zombie>:
    7440:	48 8b 15 a9 03 06 00 	mov    0x603a9(%rip),%rdx        # 677f0 <fwp_zombie>
    7447:	48 85 d2             	test   %rdx,%rdx
    744a:	0f 84 98 00 00 00    	je     74e8 <fwp_free_zombie+0xa8>
    7450:	48 3b 15 a9 03 06 00 	cmp    0x603a9(%rip),%rdx        # 67800 <fwp_cur>
    7457:	0f 84 8b 00 00 00    	je     74e8 <fwp_free_zombie+0xa8>
    745d:	48 83 ec 18          	sub    $0x18,%rsp
    7461:	48 63 05 6c fd 05 00 	movslq 0x5fd6c(%rip),%rax        # 671d4 <fwp_stack_pool_n>
    7468:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    746c:	83 f8 3f             	cmp    $0x3f,%eax
    746f:	7f 7f                	jg     74f0 <fwp_free_zombie+0xb0>
    7471:	8d 48 01             	lea    0x1(%rax),%ecx
    7474:	89 0d 5a fd 05 00    	mov    %ecx,0x5fd5a(%rip)        # 671d4 <fwp_stack_pool_n>
    747a:	48 8d 0d 5f fd 05 00 	lea    0x5fd5f(%rip),%rcx        # 671e0 <fwp_stack_pool>
    7481:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7485:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    748c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7490:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7497:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    749b:	48 85 c9             	test   %rcx,%rcx
    749e:	0f 84 fc 00 00 00    	je     75a0 <fwp_free_zombie+0x160>
    74a4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    74ab:	48 85 c0             	test   %rax,%rax
    74ae:	74 07                	je     74b7 <fwp_free_zombie+0x77>
    74b0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    74b7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    74ba:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74be:	48 c7 05 27 03 06 00 	movq   $0x0,0x60327(%rip)        # 677f0 <fwp_zombie>
    74c5:	00 00 00 00 
    74c9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    74d0:	85 c0                	test   %eax,%eax
    74d2:	74 34                	je     7508 <fwp_free_zombie+0xc8>
    74d4:	83 f8 01             	cmp    $0x1,%eax
    74d7:	0f 84 b3 00 00 00    	je     7590 <fwp_free_zombie+0x150>
    74dd:	48 83 c4 18          	add    $0x18,%rsp
    74e1:	c3                   	ret
    74e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74e8:	c3                   	ret
    74e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74f0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    74f4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    74f9:	e8 c2 c0 ff ff       	call   35c0 <munmap@plt>
    74fe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7503:	eb 80                	jmp    7485 <fwp_free_zombie+0x45>
    7505:	0f 1f 00             	nopl   (%rax)
    7508:	48 8b 0d e9 16 06 00 	mov    0x616e9(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    750f:	48 89 d0             	mov    %rdx,%rax
    7512:	48 2b 05 b7 16 06 00 	sub    0x616b7(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7519:	48 c1 e1 10          	shl    $0x10,%rcx
    751d:	48 39 c8             	cmp    %rcx,%rax
    7520:	73 bb                	jae    74dd <fwp_free_zombie+0x9d>
    7522:	48 89 c1             	mov    %rax,%rcx
    7525:	48 c1 e9 10          	shr    $0x10,%rcx
    7529:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    752d:	48 8b 0d e4 16 06 00 	mov    0x616e4(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    7534:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7538:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    753c:	48 85 c9             	test   %rcx,%rcx
    753f:	74 9c                	je     74dd <fwp_free_zombie+0x9d>
    7541:	0f b6 3e             	movzbl (%rsi),%edi
    7544:	40 80 ff 02          	cmp    $0x2,%dil
    7548:	74 66                	je     75b0 <fwp_free_zombie+0x170>
    754a:	40 80 ff 01          	cmp    $0x1,%dil
    754e:	75 8d                	jne    74dd <fwp_free_zombie+0x9d>
    7550:	8b 7e 18             	mov    0x18(%rsi),%edi
    7553:	0f b7 c0             	movzwl %ax,%eax
    7556:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7559:	48 0f af c7          	imul   %rdi,%rax
    755d:	48 c1 e8 20          	shr    $0x20,%rax
    7561:	48 39 f0             	cmp    %rsi,%rax
    7564:	0f 83 73 ff ff ff    	jae    74dd <fwp_free_zombie+0x9d>
    756a:	48 01 c1             	add    %rax,%rcx
    756d:	0f b6 01             	movzbl (%rcx),%eax
    7570:	84 c0                	test   %al,%al
    7572:	0f 84 65 ff ff ff    	je     74dd <fwp_free_zombie+0x9d>
    7578:	3c 01                	cmp    $0x1,%al
    757a:	74 14                	je     7590 <fwp_free_zombie+0x150>
    757c:	3c ff                	cmp    $0xff,%al
    757e:	74 3b                	je     75bb <fwp_free_zombie+0x17b>
    7580:	83 e8 01             	sub    $0x1,%eax
    7583:	88 01                	mov    %al,(%rcx)
    7585:	e9 53 ff ff ff       	jmp    74dd <fwp_free_zombie+0x9d>
    758a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7590:	48 89 d7             	mov    %rdx,%rdi
    7593:	48 83 c4 18          	add    $0x18,%rsp
    7597:	e9 c4 fd ff ff       	jmp    7360 <fwp_task_dispose>
    759c:	0f 1f 40 00          	nopl   0x0(%rax)
    75a0:	48 89 05 21 02 06 00 	mov    %rax,0x60221(%rip)        # 677c8 <fwp_tasks_active>
    75a7:	e9 ff fe ff ff       	jmp    74ab <fwp_free_zombie+0x6b>
    75ac:	0f 1f 40 00          	nopl   0x0(%rax)
    75b0:	66 85 c0             	test   %ax,%ax
    75b3:	0f 85 24 ff ff ff    	jne    74dd <fwp_free_zombie+0x9d>
    75b9:	eb b2                	jmp    756d <fwp_free_zombie+0x12d>
    75bb:	48 89 ca             	mov    %rcx,%rdx
    75be:	48 8d 35 5b 02 06 00 	lea    0x6025b(%rip),%rsi        # 67820 <fwp_heap>
    75c5:	48 c1 ea 11          	shr    $0x11,%rdx
    75c9:	48 31 ca             	xor    %rcx,%rdx
    75cc:	48 89 d0             	mov    %rdx,%rax
    75cf:	48 c1 e8 09          	shr    $0x9,%rax
    75d3:	48 31 c2             	xor    %rax,%rdx
    75d6:	0f b6 d2             	movzbl %dl,%edx
    75d9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    75e0:	00 
    75e1:	48 85 c0             	test   %rax,%rax
    75e4:	75 23                	jne    7609 <fwp_free_zombie+0x1c9>
    75e6:	eb 5c                	jmp    7644 <fwp_free_zombie+0x204>
    75e8:	66 90                	xchg   %ax,%ax
    75ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75f1:	00 00 00 00 
    75f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75fc:	00 00 00 00 
    7600:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7604:	48 85 c0             	test   %rax,%rax
    7607:	74 3b                	je     7644 <fwp_free_zombie+0x204>
    7609:	48 89 c2             	mov    %rax,%rdx
    760c:	48 39 08             	cmp    %rcx,(%rax)
    760f:	75 ef                	jne    7600 <fwp_free_zombie+0x1c0>
    7611:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7615:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7619:	48 89 50 08          	mov    %rdx,0x8(%rax)
    761d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7624:	0f 85 b3 fe ff ff    	jne    74dd <fwp_free_zombie+0x9d>
    762a:	48 89 cf             	mov    %rcx,%rdi
    762d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7632:	e8 79 e1 ff ff       	call   57b0 <fwp_rc_forget_slot>
    7637:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    763c:	c6 01 fe             	movb   $0xfe,(%rcx)
    763f:	e9 99 fe ff ff       	jmp    74dd <fwp_free_zombie+0x9d>
    7644:	48 8d 3d 5d 43 00 00 	lea    0x435d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    764b:	e8 e0 cd ff ff       	call   4430 <fwp_trap>

0000000000007650 <fwp_block>:
    7650:	48 83 ec 08          	sub    $0x8,%rsp
    7654:	48 8b 05 8d 01 06 00 	mov    0x6018d(%rip),%rax        # 677e8 <fwp_ready_head>
    765b:	48 85 c0             	test   %rax,%rax
    765e:	0f 84 1c 01 00 00    	je     7780 <fwp_block+0x130>
    7664:	90                   	nop
    7665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    766c:	00 00 00 00 
    7670:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7677:	48 89 15 6a 01 06 00 	mov    %rdx,0x6016a(%rip)        # 677e8 <fwp_ready_head>
    767e:	48 85 d2             	test   %rdx,%rdx
    7681:	0f 84 19 01 00 00    	je     77a0 <fwp_block+0x150>
    7687:	48 8b 15 72 01 06 00 	mov    0x60172(%rip),%rdx        # 67800 <fwp_cur>
    768e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7692:	48 39 c2             	cmp    %rax,%rdx
    7695:	0f 84 d5 00 00 00    	je     7770 <fwp_block+0x120>
    769b:	48 8b 0d e6 1d 06 00 	mov    0x61de6(%rip),%rcx        # 69488 <fwp_state_owners>
    76a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    76a6:	48 89 05 53 01 06 00 	mov    %rax,0x60153(%rip)        # 67800 <fwp_cur>
    76ad:	f3 0f 7e 05 fb 1d 06 	movq   0x61dfb(%rip),%xmm0        # 694b0 <fwp_foreign_callbacks>
    76b4:	00 
    76b5:	0f 16 05 e4 1d 06 00 	movhps 0x61de4(%rip),%xmm0        # 694a0 <fwp_state>
    76bc:	f3 0f 7e 0d e4 1d 06 	movq   0x61de4(%rip),%xmm1        # 694a8 <fwp_handlers>
    76c3:	00 
    76c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    76cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    76d2:	0f 16 0d df 1d 06 00 	movhps 0x61ddf(%rip),%xmm1        # 694b8 <fwp_cleanups>
    76d9:	f3 0f 7e 05 b7 1d 06 	movq   0x61db7(%rip),%xmm0        # 69498 <fwp_state_len>
    76e0:	00 
    76e1:	0f 16 05 a8 1d 06 00 	movhps 0x61da8(%rip),%xmm0        # 69490 <fwp_state_cap>
    76e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    76ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    76f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7701:	48 89 0d a0 1d 06 00 	mov    %rcx,0x61da0(%rip)        # 694a8 <fwp_handlers>
    7708:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    770f:	48 89 0d a2 1d 06 00 	mov    %rcx,0x61da2(%rip)        # 694b8 <fwp_cleanups>
    7716:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    771d:	48 89 0d 8c 1d 06 00 	mov    %rcx,0x61d8c(%rip)        # 694b0 <fwp_foreign_callbacks>
    7724:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    772b:	48 89 0d 6e 1d 06 00 	mov    %rcx,0x61d6e(%rip)        # 694a0 <fwp_state>
    7732:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7739:	48 89 0d 58 1d 06 00 	mov    %rcx,0x61d58(%rip)        # 69498 <fwp_state_len>
    7740:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7747:	48 89 0d 42 1d 06 00 	mov    %rcx,0x61d42(%rip)        # 69490 <fwp_state_cap>
    774e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7755:	48 89 0d 2c 1d 06 00 	mov    %rcx,0x61d2c(%rip)        # 69488 <fwp_state_owners>
    775c:	e8 1f bd ff ff       	call   3480 <swapcontext@plt>
    7761:	f3 0f 1e fa          	endbr64
    7765:	e8 d6 fc ff ff       	call   7440 <fwp_free_zombie>
    776a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7770:	8b 05 5a fa 05 00    	mov    0x5fa5a(%rip),%eax        # 671d0 <fwp_slice>
    7776:	85 c0                	test   %eax,%eax
    7778:	74 36                	je     77b0 <fwp_block+0x160>
    777a:	48 83 c4 08          	add    $0x8,%rsp
    777e:	c3                   	ret
    777f:	90                   	nop
    7780:	e8 6b dc ff ff       	call   53f0 <fwp_poll_events>
    7785:	48 8b 05 5c 00 06 00 	mov    0x6005c(%rip),%rax        # 677e8 <fwp_ready_head>
    778c:	48 85 c0             	test   %rax,%rax
    778f:	0f 85 db fe ff ff    	jne    7670 <fwp_block+0x20>
    7795:	eb e9                	jmp    7780 <fwp_block+0x130>
    7797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    779e:	00 00 
    77a0:	48 c7 05 35 00 06 00 	movq   $0x0,0x60035(%rip)        # 677e0 <fwp_ready_tail>
    77a7:	00 00 00 00 
    77ab:	e9 d7 fe ff ff       	jmp    7687 <fwp_block+0x37>
    77b0:	48 8d 3d 28 3a 00 00 	lea    0x3a28(%rip),%rdi        # b1df <_IO_stdin_used+0x1df>
    77b7:	e8 d4 bb ff ff       	call   3390 <getenv@plt>
    77bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    77c1:	48 85 c0             	test   %rax,%rax
    77c4:	74 05                	je     77cb <fwp_block+0x17b>
    77c6:	80 38 00             	cmpb   $0x0,(%rax)
    77c9:	75 0b                	jne    77d6 <fwp_block+0x186>
    77cb:	89 15 ff f9 05 00    	mov    %edx,0x5f9ff(%rip)        # 671d0 <fwp_slice>
    77d1:	48 83 c4 08          	add    $0x8,%rsp
    77d5:	c3                   	ret
    77d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    77db:	31 f6                	xor    %esi,%esi
    77dd:	48 89 c7             	mov    %rax,%rdi
    77e0:	e8 5b bd ff ff       	call   3540 <strtoll@plt>
    77e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    77e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    77f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    77f5:	0f 46 d0             	cmovbe %eax,%edx
    77f8:	eb d1                	jmp    77cb <fwp_block+0x17b>
    77fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007800 <fwp_caps173>:
    7800:	f3 0f 1e fa          	endbr64
    7804:	85 f6                	test   %esi,%esi
    7806:	74 08                	je     7810 <fwp_caps173+0x10>
    7808:	c3                   	ret
    7809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7810:	48 8b 15 e1 13 06 00 	mov    0x613e1(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7817:	48 89 f8             	mov    %rdi,%rax
    781a:	48 2b 05 af 13 06 00 	sub    0x613af(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7821:	48 c1 e2 10          	shl    $0x10,%rdx
    7825:	48 39 d0             	cmp    %rdx,%rax
    7828:	73 de                	jae    7808 <fwp_caps173+0x8>
    782a:	48 89 c2             	mov    %rax,%rdx
    782d:	48 c1 ea 10          	shr    $0x10,%rdx
    7831:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7835:	48 8b 15 dc 13 06 00 	mov    0x613dc(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    783c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7840:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7844:	48 85 c9             	test   %rcx,%rcx
    7847:	74 bf                	je     7808 <fwp_caps173+0x8>
    7849:	0f b6 32             	movzbl (%rdx),%esi
    784c:	40 80 fe 02          	cmp    $0x2,%sil
    7850:	74 2e                	je     7880 <fwp_caps173+0x80>
    7852:	40 80 fe 01          	cmp    $0x1,%sil
    7856:	75 b0                	jne    7808 <fwp_caps173+0x8>
    7858:	8b 72 18             	mov    0x18(%rdx),%esi
    785b:	0f b7 c0             	movzwl %ax,%eax
    785e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7861:	48 0f af c6          	imul   %rsi,%rax
    7865:	48 c1 e8 20          	shr    $0x20,%rax
    7869:	48 39 d0             	cmp    %rdx,%rax
    786c:	73 9a                	jae    7808 <fwp_caps173+0x8>
    786e:	48 01 c1             	add    %rax,%rcx
    7871:	80 39 01             	cmpb   $0x1,(%rcx)
    7874:	75 92                	jne    7808 <fwp_caps173+0x8>
    7876:	e9 75 e1 ff ff       	jmp    59f0 <fwp_mem_free>
    787b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7880:	66 85 c0             	test   %ax,%ax
    7883:	74 ec                	je     7871 <fwp_caps173+0x71>
    7885:	c3                   	ret
    7886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    788d:	00 00 00 

0000000000007890 <fwp_args37>:
    7890:	f3 0f 1e fa          	endbr64
    7894:	85 d2                	test   %edx,%edx
    7896:	74 04                	je     789c <fwp_args37+0xc>
    7898:	85 f6                	test   %esi,%esi
    789a:	74 04                	je     78a0 <fwp_args37+0x10>
    789c:	c3                   	ret
    789d:	0f 1f 00             	nopl   (%rax)
    78a0:	48 8b 15 51 13 06 00 	mov    0x61351(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    78a7:	48 8b 07             	mov    (%rdi),%rax
    78aa:	48 2b 05 1f 13 06 00 	sub    0x6131f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    78b1:	48 c1 e2 10          	shl    $0x10,%rdx
    78b5:	48 39 d0             	cmp    %rdx,%rax
    78b8:	73 e2                	jae    789c <fwp_args37+0xc>
    78ba:	48 89 c2             	mov    %rax,%rdx
    78bd:	48 c1 ea 10          	shr    $0x10,%rdx
    78c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78c5:	48 8b 15 4c 13 06 00 	mov    0x6134c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    78cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78d0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    78d4:	48 85 ff             	test   %rdi,%rdi
    78d7:	74 c3                	je     789c <fwp_args37+0xc>
    78d9:	0f b6 0a             	movzbl (%rdx),%ecx
    78dc:	80 f9 02             	cmp    $0x2,%cl
    78df:	74 4f                	je     7930 <fwp_args37+0xa0>
    78e1:	80 f9 01             	cmp    $0x1,%cl
    78e4:	75 b6                	jne    789c <fwp_args37+0xc>
    78e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    78e9:	0f b7 c0             	movzwl %ax,%eax
    78ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78ef:	48 0f af c1          	imul   %rcx,%rax
    78f3:	48 c1 e8 20          	shr    $0x20,%rax
    78f7:	48 39 d0             	cmp    %rdx,%rax
    78fa:	73 a0                	jae    789c <fwp_args37+0xc>
    78fc:	48 01 c7             	add    %rax,%rdi
    78ff:	0f b6 07             	movzbl (%rdi),%eax
    7902:	84 c0                	test   %al,%al
    7904:	74 96                	je     789c <fwp_args37+0xc>
    7906:	8b 15 dc 1b 06 00    	mov    0x61bdc(%rip),%edx        # 694e8 <iteration_active>
    790c:	85 d2                	test   %edx,%edx
    790e:	75 10                	jne    7920 <fwp_args37+0x90>
    7910:	3c fd                	cmp    $0xfd,%al
    7912:	77 22                	ja     7936 <fwp_args37+0xa6>
    7914:	83 c0 01             	add    $0x1,%eax
    7917:	88 07                	mov    %al,(%rdi)
    7919:	c3                   	ret
    791a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7920:	48 83 05 a8 1b 06 00 	addq   $0x1,0x61ba8(%rip)        # 694d0 <iteration_retains>
    7927:	01 
    7928:	eb e6                	jmp    7910 <fwp_args37+0x80>
    792a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7930:	66 85 c0             	test   %ax,%ax
    7933:	74 ca                	je     78ff <fwp_args37+0x6f>
    7935:	c3                   	ret
    7936:	e9 55 dd ff ff       	jmp    5690 <fwp_rc_wide_dup>
    793b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007940 <fwp_caps37>:
    7940:	f3 0f 1e fa          	endbr64
    7944:	48 83 ec 18          	sub    $0x18,%rsp
    7948:	48 89 f8             	mov    %rdi,%rax
    794b:	8b 7f 04             	mov    0x4(%rdi),%edi
    794e:	85 ff                	test   %edi,%edi
    7950:	0f 84 9a 00 00 00    	je     79f0 <fwp_caps37+0xb0>
    7956:	48 8b 78 08          	mov    0x8(%rax),%rdi
    795a:	85 f6                	test   %esi,%esi
    795c:	0f 85 9e 00 00 00    	jne    7a00 <fwp_caps37+0xc0>
    7962:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7967:	e8 24 f7 ff ff       	call   7090 <fwp_drop4>
    796c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7971:	48 8b 0d 80 12 06 00 	mov    0x61280(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7978:	48 89 c2             	mov    %rax,%rdx
    797b:	48 2b 15 4e 12 06 00 	sub    0x6124e(%rip),%rdx        # 68bd0 <fwp_heap+0x13b0>
    7982:	48 c1 e1 10          	shl    $0x10,%rcx
    7986:	48 39 ca             	cmp    %rcx,%rdx
    7989:	73 6d                	jae    79f8 <fwp_caps37+0xb8>
    798b:	48 89 d1             	mov    %rdx,%rcx
    798e:	48 c1 e9 10          	shr    $0x10,%rcx
    7992:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7996:	48 8b 0d 7b 12 06 00 	mov    0x6127b(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    799d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    79a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    79a5:	48 85 f6             	test   %rsi,%rsi
    79a8:	74 4e                	je     79f8 <fwp_caps37+0xb8>
    79aa:	0f b6 39             	movzbl (%rcx),%edi
    79ad:	40 80 ff 02          	cmp    $0x2,%dil
    79b1:	0f 84 c9 00 00 00    	je     7a80 <fwp_caps37+0x140>
    79b7:	40 80 ff 01          	cmp    $0x1,%dil
    79bb:	75 3b                	jne    79f8 <fwp_caps37+0xb8>
    79bd:	8b 79 18             	mov    0x18(%rcx),%edi
    79c0:	0f b7 d2             	movzwl %dx,%edx
    79c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79c6:	48 0f af d7          	imul   %rdi,%rdx
    79ca:	48 c1 ea 20          	shr    $0x20,%rdx
    79ce:	48 39 ca             	cmp    %rcx,%rdx
    79d1:	73 25                	jae    79f8 <fwp_caps37+0xb8>
    79d3:	48 01 d6             	add    %rdx,%rsi
    79d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    79d9:	75 1d                	jne    79f8 <fwp_caps37+0xb8>
    79db:	48 89 c7             	mov    %rax,%rdi
    79de:	48 83 c4 18          	add    $0x18,%rsp
    79e2:	e9 09 e0 ff ff       	jmp    59f0 <fwp_mem_free>
    79e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79ee:	00 00 
    79f0:	85 f6                	test   %esi,%esi
    79f2:	0f 84 79 ff ff ff    	je     7971 <fwp_caps37+0x31>
    79f8:	48 83 c4 18          	add    $0x18,%rsp
    79fc:	c3                   	ret
    79fd:	0f 1f 00             	nopl   (%rax)
    7a00:	48 8b 05 f1 11 06 00 	mov    0x611f1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    7a07:	48 2b 3d c2 11 06 00 	sub    0x611c2(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    7a0e:	48 c1 e0 10          	shl    $0x10,%rax
    7a12:	48 39 c7             	cmp    %rax,%rdi
    7a15:	73 e1                	jae    79f8 <fwp_caps37+0xb8>
    7a17:	48 89 f8             	mov    %rdi,%rax
    7a1a:	48 c1 e8 10          	shr    $0x10,%rax
    7a1e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7a22:	48 8b 05 ef 11 06 00 	mov    0x611ef(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    7a29:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7a2d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7a31:	48 85 c0             	test   %rax,%rax
    7a34:	74 c2                	je     79f8 <fwp_caps37+0xb8>
    7a36:	0f b6 0a             	movzbl (%rdx),%ecx
    7a39:	80 f9 02             	cmp    $0x2,%cl
    7a3c:	74 52                	je     7a90 <fwp_caps37+0x150>
    7a3e:	80 f9 01             	cmp    $0x1,%cl
    7a41:	75 b5                	jne    79f8 <fwp_caps37+0xb8>
    7a43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a46:	0f b7 ff             	movzwl %di,%edi
    7a49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a4c:	48 0f af f9          	imul   %rcx,%rdi
    7a50:	48 c1 ef 20          	shr    $0x20,%rdi
    7a54:	48 39 d7             	cmp    %rdx,%rdi
    7a57:	73 9f                	jae    79f8 <fwp_caps37+0xb8>
    7a59:	48 01 f8             	add    %rdi,%rax
    7a5c:	0f b6 10             	movzbl (%rax),%edx
    7a5f:	84 d2                	test   %dl,%dl
    7a61:	74 95                	je     79f8 <fwp_caps37+0xb8>
    7a63:	8b 0d 7f 1a 06 00    	mov    0x61a7f(%rip),%ecx        # 694e8 <iteration_active>
    7a69:	85 c9                	test   %ecx,%ecx
    7a6b:	75 33                	jne    7aa0 <fwp_caps37+0x160>
    7a6d:	80 fa fd             	cmp    $0xfd,%dl
    7a70:	77 38                	ja     7aaa <fwp_caps37+0x16a>
    7a72:	83 c2 01             	add    $0x1,%edx
    7a75:	88 10                	mov    %dl,(%rax)
    7a77:	e9 7c ff ff ff       	jmp    79f8 <fwp_caps37+0xb8>
    7a7c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a80:	66 85 d2             	test   %dx,%dx
    7a83:	0f 85 6f ff ff ff    	jne    79f8 <fwp_caps37+0xb8>
    7a89:	e9 48 ff ff ff       	jmp    79d6 <fwp_caps37+0x96>
    7a8e:	66 90                	xchg   %ax,%ax
    7a90:	66 85 ff             	test   %di,%di
    7a93:	0f 85 5f ff ff ff    	jne    79f8 <fwp_caps37+0xb8>
    7a99:	eb c1                	jmp    7a5c <fwp_caps37+0x11c>
    7a9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7aa0:	48 83 05 28 1a 06 00 	addq   $0x1,0x61a28(%rip)        # 694d0 <iteration_retains>
    7aa7:	01 
    7aa8:	eb c3                	jmp    7a6d <fwp_caps37+0x12d>
    7aaa:	48 89 c7             	mov    %rax,%rdi
    7aad:	48 83 c4 18          	add    $0x18,%rsp
    7ab1:	e9 da db ff ff       	jmp    5690 <fwp_rc_wide_dup>
    7ab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7abd:	00 00 00 

0000000000007ac0 <fwp_drop0>:
    7ac0:	f3 0f 1e fa          	endbr64
    7ac4:	48 8b 15 2d 11 06 00 	mov    0x6112d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7acb:	48 89 f8             	mov    %rdi,%rax
    7ace:	48 2b 05 fb 10 06 00 	sub    0x610fb(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7ad5:	48 c1 e2 10          	shl    $0x10,%rdx
    7ad9:	48 39 d0             	cmp    %rdx,%rax
    7adc:	0f 83 36 01 00 00    	jae    7c18 <fwp_drop0+0x158>
    7ae2:	48 83 ec 18          	sub    $0x18,%rsp
    7ae6:	48 8d 35 33 fd 05 00 	lea    0x5fd33(%rip),%rsi        # 67820 <fwp_heap>
    7aed:	48 89 c2             	mov    %rax,%rdx
    7af0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7af7:	48 c1 ea 10          	shr    $0x10,%rdx
    7afb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7aff:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b03:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b07:	48 85 d2             	test   %rdx,%rdx
    7b0a:	74 42                	je     7b4e <fwp_drop0+0x8e>
    7b0c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b10:	41 80 f8 02          	cmp    $0x2,%r8b
    7b14:	74 42                	je     7b58 <fwp_drop0+0x98>
    7b16:	41 80 f8 01          	cmp    $0x1,%r8b
    7b1a:	75 32                	jne    7b4e <fwp_drop0+0x8e>
    7b1c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b20:	0f b7 c0             	movzwl %ax,%eax
    7b23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b26:	49 0f af c0          	imul   %r8,%rax
    7b2a:	48 c1 e8 20          	shr    $0x20,%rax
    7b2e:	48 39 c8             	cmp    %rcx,%rax
    7b31:	73 1b                	jae    7b4e <fwp_drop0+0x8e>
    7b33:	48 01 c2             	add    %rax,%rdx
    7b36:	0f b6 02             	movzbl (%rdx),%eax
    7b39:	84 c0                	test   %al,%al
    7b3b:	74 11                	je     7b4e <fwp_drop0+0x8e>
    7b3d:	3c 01                	cmp    $0x1,%al
    7b3f:	74 27                	je     7b68 <fwp_drop0+0xa8>
    7b41:	3c ff                	cmp    $0xff,%al
    7b43:	0f 84 e7 00 00 00    	je     7c30 <fwp_drop0+0x170>
    7b49:	83 e8 01             	sub    $0x1,%eax
    7b4c:	88 02                	mov    %al,(%rdx)
    7b4e:	48 83 c4 18          	add    $0x18,%rsp
    7b52:	c3                   	ret
    7b53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b58:	66 85 c0             	test   %ax,%ax
    7b5b:	74 d9                	je     7b36 <fwp_drop0+0x76>
    7b5d:	48 83 c4 18          	add    $0x18,%rsp
    7b61:	c3                   	ret
    7b62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b68:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b6f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b76:	48 89 f8             	mov    %rdi,%rax
    7b79:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b7d:	48 29 c8             	sub    %rcx,%rax
    7b80:	48 c1 e2 10          	shl    $0x10,%rdx
    7b84:	48 39 d0             	cmp    %rdx,%rax
    7b87:	73 71                	jae    7bfa <fwp_drop0+0x13a>
    7b89:	49 89 c2             	mov    %rax,%r10
    7b8c:	49 c1 ea 10          	shr    $0x10,%r10
    7b90:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b94:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7b98:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7b9c:	4d 85 d2             	test   %r10,%r10
    7b9f:	74 59                	je     7bfa <fwp_drop0+0x13a>
    7ba1:	45 0f b6 19          	movzbl (%r9),%r11d
    7ba5:	41 80 fb 02          	cmp    $0x2,%r11b
    7ba9:	74 75                	je     7c20 <fwp_drop0+0x160>
    7bab:	41 80 fb 01          	cmp    $0x1,%r11b
    7baf:	75 49                	jne    7bfa <fwp_drop0+0x13a>
    7bb1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7bb5:	0f b7 c0             	movzwl %ax,%eax
    7bb8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7bbc:	49 0f af c3          	imul   %r11,%rax
    7bc0:	48 c1 e8 20          	shr    $0x20,%rax
    7bc4:	4c 39 c8             	cmp    %r9,%rax
    7bc7:	73 31                	jae    7bfa <fwp_drop0+0x13a>
    7bc9:	49 01 c2             	add    %rax,%r10
    7bcc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7bd0:	75 28                	jne    7bfa <fwp_drop0+0x13a>
    7bd2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7bd7:	e8 14 de ff ff       	call   59f0 <fwp_mem_free>
    7bdc:	48 8d 35 3d fc 05 00 	lea    0x5fc3d(%rip),%rsi        # 67820 <fwp_heap>
    7be3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7be8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7bef:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7bf6:	48 c1 e2 10          	shl    $0x10,%rdx
    7bfa:	4c 89 c0             	mov    %r8,%rax
    7bfd:	48 29 c8             	sub    %rcx,%rax
    7c00:	48 39 d0             	cmp    %rdx,%rax
    7c03:	0f 83 45 ff ff ff    	jae    7b4e <fwp_drop0+0x8e>
    7c09:	4c 89 c7             	mov    %r8,%rdi
    7c0c:	e9 dc fe ff ff       	jmp    7aed <fwp_drop0+0x2d>
    7c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c18:	c3                   	ret
    7c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c20:	66 85 c0             	test   %ax,%ax
    7c23:	75 d5                	jne    7bfa <fwp_drop0+0x13a>
    7c25:	eb a5                	jmp    7bcc <fwp_drop0+0x10c>
    7c27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c2e:	00 00 
    7c30:	48 89 d0             	mov    %rdx,%rax
    7c33:	48 c1 e8 11          	shr    $0x11,%rax
    7c37:	48 31 d0             	xor    %rdx,%rax
    7c3a:	48 89 c1             	mov    %rax,%rcx
    7c3d:	48 c1 e9 09          	shr    $0x9,%rcx
    7c41:	48 31 c8             	xor    %rcx,%rax
    7c44:	0f b6 c8             	movzbl %al,%ecx
    7c47:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7c4e:	00 
    7c4f:	48 85 c0             	test   %rax,%rax
    7c52:	75 15                	jne    7c69 <fwp_drop0+0x1a9>
    7c54:	eb 4e                	jmp    7ca4 <fwp_drop0+0x1e4>
    7c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c5d:	00 00 00 
    7c60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c64:	48 85 c0             	test   %rax,%rax
    7c67:	74 3b                	je     7ca4 <fwp_drop0+0x1e4>
    7c69:	48 89 c1             	mov    %rax,%rcx
    7c6c:	48 39 10             	cmp    %rdx,(%rax)
    7c6f:	75 ef                	jne    7c60 <fwp_drop0+0x1a0>
    7c71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c84:	0f 85 c4 fe ff ff    	jne    7b4e <fwp_drop0+0x8e>
    7c8a:	48 89 d7             	mov    %rdx,%rdi
    7c8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c92:	e8 19 db ff ff       	call   57b0 <fwp_rc_forget_slot>
    7c97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c9f:	e9 aa fe ff ff       	jmp    7b4e <fwp_drop0+0x8e>
    7ca4:	48 8d 3d fd 3c 00 00 	lea    0x3cfd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7cab:	e8 80 c7 ff ff       	call   4430 <fwp_trap>

0000000000007cb0 <fwp_drop1>:
    7cb0:	f3 0f 1e fa          	endbr64
    7cb4:	48 8b 15 3d 0f 06 00 	mov    0x60f3d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7cbb:	48 89 f8             	mov    %rdi,%rax
    7cbe:	48 2b 05 0b 0f 06 00 	sub    0x60f0b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7cc5:	48 c1 e2 10          	shl    $0x10,%rdx
    7cc9:	48 39 d0             	cmp    %rdx,%rax
    7ccc:	0f 83 36 01 00 00    	jae    7e08 <fwp_drop1+0x158>
    7cd2:	48 83 ec 18          	sub    $0x18,%rsp
    7cd6:	48 8d 35 43 fb 05 00 	lea    0x5fb43(%rip),%rsi        # 67820 <fwp_heap>
    7cdd:	48 89 c2             	mov    %rax,%rdx
    7ce0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7ce7:	48 c1 ea 10          	shr    $0x10,%rdx
    7ceb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7cef:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7cf3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7cf7:	48 85 d2             	test   %rdx,%rdx
    7cfa:	74 42                	je     7d3e <fwp_drop1+0x8e>
    7cfc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d00:	41 80 f8 02          	cmp    $0x2,%r8b
    7d04:	74 42                	je     7d48 <fwp_drop1+0x98>
    7d06:	41 80 f8 01          	cmp    $0x1,%r8b
    7d0a:	75 32                	jne    7d3e <fwp_drop1+0x8e>
    7d0c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d10:	0f b7 c0             	movzwl %ax,%eax
    7d13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d16:	49 0f af c0          	imul   %r8,%rax
    7d1a:	48 c1 e8 20          	shr    $0x20,%rax
    7d1e:	48 39 c8             	cmp    %rcx,%rax
    7d21:	73 1b                	jae    7d3e <fwp_drop1+0x8e>
    7d23:	48 01 c2             	add    %rax,%rdx
    7d26:	0f b6 02             	movzbl (%rdx),%eax
    7d29:	84 c0                	test   %al,%al
    7d2b:	74 11                	je     7d3e <fwp_drop1+0x8e>
    7d2d:	3c 01                	cmp    $0x1,%al
    7d2f:	74 27                	je     7d58 <fwp_drop1+0xa8>
    7d31:	3c ff                	cmp    $0xff,%al
    7d33:	0f 84 e7 00 00 00    	je     7e20 <fwp_drop1+0x170>
    7d39:	83 e8 01             	sub    $0x1,%eax
    7d3c:	88 02                	mov    %al,(%rdx)
    7d3e:	48 83 c4 18          	add    $0x18,%rsp
    7d42:	c3                   	ret
    7d43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d48:	66 85 c0             	test   %ax,%ax
    7d4b:	74 d9                	je     7d26 <fwp_drop1+0x76>
    7d4d:	48 83 c4 18          	add    $0x18,%rsp
    7d51:	c3                   	ret
    7d52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d58:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d5f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d66:	48 89 f8             	mov    %rdi,%rax
    7d69:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d6d:	48 29 c8             	sub    %rcx,%rax
    7d70:	48 c1 e2 10          	shl    $0x10,%rdx
    7d74:	48 39 d0             	cmp    %rdx,%rax
    7d77:	73 71                	jae    7dea <fwp_drop1+0x13a>
    7d79:	49 89 c2             	mov    %rax,%r10
    7d7c:	49 c1 ea 10          	shr    $0x10,%r10
    7d80:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d84:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d88:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d8c:	4d 85 d2             	test   %r10,%r10
    7d8f:	74 59                	je     7dea <fwp_drop1+0x13a>
    7d91:	45 0f b6 19          	movzbl (%r9),%r11d
    7d95:	41 80 fb 02          	cmp    $0x2,%r11b
    7d99:	74 75                	je     7e10 <fwp_drop1+0x160>
    7d9b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d9f:	75 49                	jne    7dea <fwp_drop1+0x13a>
    7da1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7da5:	0f b7 c0             	movzwl %ax,%eax
    7da8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7dac:	49 0f af c3          	imul   %r11,%rax
    7db0:	48 c1 e8 20          	shr    $0x20,%rax
    7db4:	4c 39 c8             	cmp    %r9,%rax
    7db7:	73 31                	jae    7dea <fwp_drop1+0x13a>
    7db9:	49 01 c2             	add    %rax,%r10
    7dbc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7dc0:	75 28                	jne    7dea <fwp_drop1+0x13a>
    7dc2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7dc7:	e8 24 dc ff ff       	call   59f0 <fwp_mem_free>
    7dcc:	48 8d 35 4d fa 05 00 	lea    0x5fa4d(%rip),%rsi        # 67820 <fwp_heap>
    7dd3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7dd8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ddf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7de6:	48 c1 e2 10          	shl    $0x10,%rdx
    7dea:	4c 89 c0             	mov    %r8,%rax
    7ded:	48 29 c8             	sub    %rcx,%rax
    7df0:	48 39 d0             	cmp    %rdx,%rax
    7df3:	0f 83 45 ff ff ff    	jae    7d3e <fwp_drop1+0x8e>
    7df9:	4c 89 c7             	mov    %r8,%rdi
    7dfc:	e9 dc fe ff ff       	jmp    7cdd <fwp_drop1+0x2d>
    7e01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e08:	c3                   	ret
    7e09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e10:	66 85 c0             	test   %ax,%ax
    7e13:	75 d5                	jne    7dea <fwp_drop1+0x13a>
    7e15:	eb a5                	jmp    7dbc <fwp_drop1+0x10c>
    7e17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e1e:	00 00 
    7e20:	48 89 d0             	mov    %rdx,%rax
    7e23:	48 c1 e8 11          	shr    $0x11,%rax
    7e27:	48 31 d0             	xor    %rdx,%rax
    7e2a:	48 89 c1             	mov    %rax,%rcx
    7e2d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e31:	48 31 c8             	xor    %rcx,%rax
    7e34:	0f b6 c8             	movzbl %al,%ecx
    7e37:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e3e:	00 
    7e3f:	48 85 c0             	test   %rax,%rax
    7e42:	75 25                	jne    7e69 <fwp_drop1+0x1b9>
    7e44:	eb 5e                	jmp    7ea4 <fwp_drop1+0x1f4>
    7e46:	0f 1f 40 00          	nopl   0x0(%rax)
    7e4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e51:	00 00 00 00 
    7e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e5c:	00 00 00 00 
    7e60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e64:	48 85 c0             	test   %rax,%rax
    7e67:	74 3b                	je     7ea4 <fwp_drop1+0x1f4>
    7e69:	48 89 c1             	mov    %rax,%rcx
    7e6c:	48 39 10             	cmp    %rdx,(%rax)
    7e6f:	75 ef                	jne    7e60 <fwp_drop1+0x1b0>
    7e71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e84:	0f 85 b4 fe ff ff    	jne    7d3e <fwp_drop1+0x8e>
    7e8a:	48 89 d7             	mov    %rdx,%rdi
    7e8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e92:	e8 19 d9 ff ff       	call   57b0 <fwp_rc_forget_slot>
    7e97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e9f:	e9 9a fe ff ff       	jmp    7d3e <fwp_drop1+0x8e>
    7ea4:	48 8d 3d fd 3a 00 00 	lea    0x3afd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7eab:	e8 80 c5 ff ff       	call   4430 <fwp_trap>

0000000000007eb0 <fwp_drop10>:
    7eb0:	48 8b 0d 41 0d 06 00 	mov    0x60d41(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7eb7:	48 89 f8             	mov    %rdi,%rax
    7eba:	48 2b 05 0f 0d 06 00 	sub    0x60d0f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7ec1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ec5:	48 39 c8             	cmp    %rcx,%rax
    7ec8:	0f 83 c2 01 00 00    	jae    8090 <fwp_drop10+0x1e0>
    7ece:	48 83 ec 18          	sub    $0x18,%rsp
    7ed2:	48 89 fa             	mov    %rdi,%rdx
    7ed5:	48 8d 35 44 f9 05 00 	lea    0x5f944(%rip),%rsi        # 67820 <fwp_heap>
    7edc:	48 89 c1             	mov    %rax,%rcx
    7edf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7ee6:	48 c1 e9 10          	shr    $0x10,%rcx
    7eea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7eee:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7ef2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7ef6:	48 85 c9             	test   %rcx,%rcx
    7ef9:	74 46                	je     7f41 <fwp_drop10+0x91>
    7efb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7eff:	41 80 f9 02          	cmp    $0x2,%r9b
    7f03:	0f 84 d7 00 00 00    	je     7fe0 <fwp_drop10+0x130>
    7f09:	41 80 f9 01          	cmp    $0x1,%r9b
    7f0d:	75 32                	jne    7f41 <fwp_drop10+0x91>
    7f0f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7f13:	0f b7 c0             	movzwl %ax,%eax
    7f16:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7f19:	49 0f af c1          	imul   %r9,%rax
    7f1d:	48 c1 e8 20          	shr    $0x20,%rax
    7f21:	48 39 f8             	cmp    %rdi,%rax
    7f24:	73 1b                	jae    7f41 <fwp_drop10+0x91>
    7f26:	48 01 c1             	add    %rax,%rcx
    7f29:	0f b6 01             	movzbl (%rcx),%eax
    7f2c:	84 c0                	test   %al,%al
    7f2e:	74 11                	je     7f41 <fwp_drop10+0x91>
    7f30:	3c 01                	cmp    $0x1,%al
    7f32:	74 1c                	je     7f50 <fwp_drop10+0xa0>
    7f34:	3c ff                	cmp    $0xff,%al
    7f36:	0f 84 5c 01 00 00    	je     8098 <fwp_drop10+0x1e8>
    7f3c:	83 e8 01             	sub    $0x1,%eax
    7f3f:	88 01                	mov    %al,(%rcx)
    7f41:	48 83 c4 18          	add    $0x18,%rsp
    7f45:	c3                   	ret
    7f46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f4d:	00 00 00 
    7f50:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7f57:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7f5e:	48 89 d0             	mov    %rdx,%rax
    7f61:	49 89 d1             	mov    %rdx,%r9
    7f64:	48 c1 e1 10          	shl    $0x10,%rcx
    7f68:	48 29 f8             	sub    %rdi,%rax
    7f6b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7f6f:	78 7f                	js     7ff0 <fwp_drop10+0x140>
    7f71:	48 39 c8             	cmp    %rcx,%rax
    7f74:	73 cb                	jae    7f41 <fwp_drop10+0x91>
    7f76:	48 89 c1             	mov    %rax,%rcx
    7f79:	48 c1 e9 10          	shr    $0x10,%rcx
    7f7d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f81:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7f85:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f89:	48 85 f6             	test   %rsi,%rsi
    7f8c:	74 b3                	je     7f41 <fwp_drop10+0x91>
    7f8e:	0f b6 39             	movzbl (%rcx),%edi
    7f91:	40 80 ff 02          	cmp    $0x2,%dil
    7f95:	74 39                	je     7fd0 <fwp_drop10+0x120>
    7f97:	40 80 ff 01          	cmp    $0x1,%dil
    7f9b:	75 a4                	jne    7f41 <fwp_drop10+0x91>
    7f9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7fa0:	0f b7 c0             	movzwl %ax,%eax
    7fa3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fa6:	48 0f af c7          	imul   %rdi,%rax
    7faa:	48 c1 e8 20          	shr    $0x20,%rax
    7fae:	48 39 c8             	cmp    %rcx,%rax
    7fb1:	73 8e                	jae    7f41 <fwp_drop10+0x91>
    7fb3:	48 01 c6             	add    %rax,%rsi
    7fb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7fb9:	75 86                	jne    7f41 <fwp_drop10+0x91>
    7fbb:	48 89 d7             	mov    %rdx,%rdi
    7fbe:	48 83 c4 18          	add    $0x18,%rsp
    7fc2:	e9 29 da ff ff       	jmp    59f0 <fwp_mem_free>
    7fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fce:	00 00 
    7fd0:	66 85 c0             	test   %ax,%ax
    7fd3:	74 e1                	je     7fb6 <fwp_drop10+0x106>
    7fd5:	48 83 c4 18          	add    $0x18,%rsp
    7fd9:	c3                   	ret
    7fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7fe0:	66 85 c0             	test   %ax,%ax
    7fe3:	0f 84 40 ff ff ff    	je     7f29 <fwp_drop10+0x79>
    7fe9:	48 83 c4 18          	add    $0x18,%rsp
    7fed:	c3                   	ret
    7fee:	66 90                	xchg   %ax,%ax
    7ff0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7ff4:	48 39 c8             	cmp    %rcx,%rax
    7ff7:	73 74                	jae    806d <fwp_drop10+0x1bd>
    7ff9:	49 89 c2             	mov    %rax,%r10
    7ffc:	49 c1 ea 10          	shr    $0x10,%r10
    8000:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8004:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8008:	4d 8b 50 20          	mov    0x20(%r8),%r10
    800c:	4d 85 d2             	test   %r10,%r10
    800f:	74 5c                	je     806d <fwp_drop10+0x1bd>
    8011:	45 0f b6 18          	movzbl (%r8),%r11d
    8015:	41 80 fb 02          	cmp    $0x2,%r11b
    8019:	74 6d                	je     8088 <fwp_drop10+0x1d8>
    801b:	41 80 fb 01          	cmp    $0x1,%r11b
    801f:	75 4c                	jne    806d <fwp_drop10+0x1bd>
    8021:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8025:	0f b7 c0             	movzwl %ax,%eax
    8028:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    802c:	49 0f af c3          	imul   %r11,%rax
    8030:	48 c1 e8 20          	shr    $0x20,%rax
    8034:	4c 39 c0             	cmp    %r8,%rax
    8037:	73 34                	jae    806d <fwp_drop10+0x1bd>
    8039:	49 01 c2             	add    %rax,%r10
    803c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8040:	75 2b                	jne    806d <fwp_drop10+0x1bd>
    8042:	4c 89 cf             	mov    %r9,%rdi
    8045:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    804a:	e8 a1 d9 ff ff       	call   59f0 <fwp_mem_free>
    804f:	48 8d 35 ca f7 05 00 	lea    0x5f7ca(%rip),%rsi        # 67820 <fwp_heap>
    8056:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    805b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8062:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8069:	48 c1 e1 10          	shl    $0x10,%rcx
    806d:	48 89 d0             	mov    %rdx,%rax
    8070:	48 29 f8             	sub    %rdi,%rax
    8073:	48 39 c8             	cmp    %rcx,%rax
    8076:	0f 82 60 fe ff ff    	jb     7edc <fwp_drop10+0x2c>
    807c:	e9 c0 fe ff ff       	jmp    7f41 <fwp_drop10+0x91>
    8081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8088:	66 85 c0             	test   %ax,%ax
    808b:	75 e0                	jne    806d <fwp_drop10+0x1bd>
    808d:	eb ad                	jmp    803c <fwp_drop10+0x18c>
    808f:	90                   	nop
    8090:	c3                   	ret
    8091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8098:	48 89 c8             	mov    %rcx,%rax
    809b:	48 c1 e8 11          	shr    $0x11,%rax
    809f:	48 31 c8             	xor    %rcx,%rax
    80a2:	48 89 c2             	mov    %rax,%rdx
    80a5:	48 c1 ea 09          	shr    $0x9,%rdx
    80a9:	48 31 d0             	xor    %rdx,%rax
    80ac:	0f b6 d0             	movzbl %al,%edx
    80af:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    80b6:	00 
    80b7:	48 85 c0             	test   %rax,%rax
    80ba:	75 0d                	jne    80c9 <fwp_drop10+0x219>
    80bc:	eb 46                	jmp    8104 <fwp_drop10+0x254>
    80be:	66 90                	xchg   %ax,%ax
    80c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    80c4:	48 85 c0             	test   %rax,%rax
    80c7:	74 3b                	je     8104 <fwp_drop10+0x254>
    80c9:	48 89 c2             	mov    %rax,%rdx
    80cc:	48 39 08             	cmp    %rcx,(%rax)
    80cf:	75 ef                	jne    80c0 <fwp_drop10+0x210>
    80d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    80d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    80d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    80dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    80e4:	0f 85 57 fe ff ff    	jne    7f41 <fwp_drop10+0x91>
    80ea:	48 89 cf             	mov    %rcx,%rdi
    80ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    80f2:	e8 b9 d6 ff ff       	call   57b0 <fwp_rc_forget_slot>
    80f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    80fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    80ff:	e9 3d fe ff ff       	jmp    7f41 <fwp_drop10+0x91>
    8104:	48 8d 3d 9d 38 00 00 	lea    0x389d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    810b:	e8 20 c3 ff ff       	call   4430 <fwp_trap>

0000000000008110 <f37>:
    8110:	41 57                	push   %r15
    8112:	41 56                	push   %r14
    8114:	41 55                	push   %r13
    8116:	41 54                	push   %r12
    8118:	55                   	push   %rbp
    8119:	53                   	push   %rbx
    811a:	48 83 ec 38          	sub    $0x38,%rsp
    811e:	48 8b 15 d3 0a 06 00 	mov    0x60ad3(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    8125:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    812a:	48 c1 e2 10          	shl    $0x10,%rdx
    812e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8135:	00 00 
    8137:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    813c:	48 8b 0d 8d 0a 06 00 	mov    0x60a8d(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    8143:	48 85 ff             	test   %rdi,%rdi
    8146:	0f 84 1e 03 00 00    	je     846a <f37+0x35a>
    814c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8151:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8155:	4c 89 e8             	mov    %r13,%rax
    8158:	48 29 c8             	sub    %rcx,%rax
    815b:	48 39 d0             	cmp    %rdx,%rax
    815e:	0f 83 ec 02 00 00    	jae    8450 <f37+0x340>
    8164:	48 89 c2             	mov    %rax,%rdx
    8167:	48 c1 ea 10          	shr    $0x10,%rdx
    816b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    816f:	48 8b 15 a2 0a 06 00 	mov    0x60aa2(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8176:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    817a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    817e:	48 85 ff             	test   %rdi,%rdi
    8181:	0f 84 c9 02 00 00    	je     8450 <f37+0x340>
    8187:	0f b6 0a             	movzbl (%rdx),%ecx
    818a:	80 f9 02             	cmp    $0x2,%cl
    818d:	0f 84 4d 02 00 00    	je     83e0 <f37+0x2d0>
    8193:	80 f9 01             	cmp    $0x1,%cl
    8196:	75 24                	jne    81bc <f37+0xac>
    8198:	8b 4a 18             	mov    0x18(%rdx),%ecx
    819b:	0f b7 c0             	movzwl %ax,%eax
    819e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81a1:	48 0f af c1          	imul   %rcx,%rax
    81a5:	48 c1 e8 20          	shr    $0x20,%rax
    81a9:	48 39 d0             	cmp    %rdx,%rax
    81ac:	73 0e                	jae    81bc <f37+0xac>
    81ae:	48 01 c7             	add    %rax,%rdi
    81b1:	0f b6 07             	movzbl (%rdi),%eax
    81b4:	84 c0                	test   %al,%al
    81b6:	0f 85 44 02 00 00    	jne    8400 <f37+0x2f0>
    81bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81c1:	48 8b 40 10          	mov    0x10(%rax),%rax
    81c5:	ba 01 00 00 00       	mov    $0x1,%edx
    81ca:	48 85 c0             	test   %rax,%rax
    81cd:	74 0e                	je     81dd <f37+0xcd>
    81cf:	90                   	nop
    81d0:	48 8b 40 10          	mov    0x10(%rax),%rax
    81d4:	48 83 c2 01          	add    $0x1,%rdx
    81d8:	48 85 c0             	test   %rax,%rax
    81db:	75 f3                	jne    81d0 <f37+0xc0>
    81dd:	4d 85 ed             	test   %r13,%r13
    81e0:	0f 84 9a 02 00 00    	je     8480 <f37+0x370>
    81e6:	4c 89 e8             	mov    %r13,%rax
    81e9:	31 db                	xor    %ebx,%ebx
    81eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    81f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    81f4:	48 83 c3 01          	add    $0x1,%rbx
    81f8:	48 85 c0             	test   %rax,%rax
    81fb:	75 f3                	jne    81f0 <f37+0xe0>
    81fd:	48 39 d3             	cmp    %rdx,%rbx
    8200:	48 0f 47 da          	cmova  %rdx,%rbx
    8204:	48 89 d8             	mov    %rbx,%rax
    8207:	48 c1 e8 3c          	shr    $0x3c,%rax
    820b:	0f 85 7d 03 00 00    	jne    858e <f37+0x47e>
    8211:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8215:	be 02 00 00 00       	mov    $0x2,%esi
    821a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8221:	00 
    8222:	e8 c9 dc ff ff       	call   5ef0 <fwp_heap_alloc>
    8227:	48 89 28             	mov    %rbp,(%rax)
    822a:	48 8b 15 c7 09 06 00 	mov    0x609c7(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    8231:	49 89 c4             	mov    %rax,%r12
    8234:	48 2b 05 95 09 06 00 	sub    0x60995(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    823b:	48 c1 e2 10          	shl    $0x10,%rdx
    823f:	48 39 d0             	cmp    %rdx,%rax
    8242:	73 57                	jae    829b <f37+0x18b>
    8244:	48 89 c2             	mov    %rax,%rdx
    8247:	48 c1 ea 10          	shr    $0x10,%rdx
    824b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    824f:	48 8b 15 c2 09 06 00 	mov    0x609c2(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8256:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    825a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    825e:	48 85 ed             	test   %rbp,%rbp
    8261:	74 38                	je     829b <f37+0x18b>
    8263:	0f b6 0a             	movzbl (%rdx),%ecx
    8266:	80 f9 02             	cmp    $0x2,%cl
    8269:	0f 84 d1 01 00 00    	je     8440 <f37+0x330>
    826f:	80 f9 01             	cmp    $0x1,%cl
    8272:	75 27                	jne    829b <f37+0x18b>
    8274:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8277:	0f b7 c0             	movzwl %ax,%eax
    827a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    827d:	48 0f af c1          	imul   %rcx,%rax
    8281:	48 c1 e8 20          	shr    $0x20,%rax
    8285:	48 39 d0             	cmp    %rdx,%rax
    8288:	73 11                	jae    829b <f37+0x18b>
    828a:	48 01 c5             	add    %rax,%rbp
    828d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8291:	0f 84 57 02 00 00    	je     84ee <f37+0x3de>
    8297:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    829b:	48 85 db             	test   %rbx,%rbx
    829e:	74 5d                	je     82fd <f37+0x1ed>
    82a0:	48 c1 e3 04          	shl    $0x4,%rbx
    82a4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    82a9:	4c 89 e5             	mov    %r12,%rbp
    82ac:	4d 89 ef             	mov    %r13,%r15
    82af:	4c 01 e3             	add    %r12,%rbx
    82b2:	0f 1f 00             	nopl   (%rax)
    82b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82bc:	00 00 00 00 
    82c0:	49 8b 46 08          	mov    0x8(%r14),%rax
    82c4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    82c8:	48 83 c5 10          	add    $0x10,%rbp
    82cc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    82d1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    82d5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    82d9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    82de:	e8 6d e3 ff ff       	call   6650 <w120>
    82e3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    82e8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    82ec:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    82f0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    82f4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    82f8:	48 39 dd             	cmp    %rbx,%rbp
    82fb:	75 c3                	jne    82c0 <f37+0x1b0>
    82fd:	4c 89 ef             	mov    %r13,%rdi
    8300:	e8 8b ed ff ff       	call   7090 <fwp_drop4>
    8305:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    830a:	e8 81 ed ff ff       	call   7090 <fwp_drop4>
    830f:	4c 89 e7             	mov    %r12,%rdi
    8312:	e8 a9 e4 ff ff       	call   67c0 <w176.constprop.0>
    8317:	4c 89 e7             	mov    %r12,%rdi
    831a:	48 89 c3             	mov    %rax,%rbx
    831d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8323:	e8 88 fb ff ff       	call   7eb0 <fwp_drop10>
    8328:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    832e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8333:	31 ff                	xor    %edi,%edi
    8335:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    833a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    833e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8343:	e8 98 dd ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    8348:	48 8b 15 a9 08 06 00 	mov    0x608a9(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    834f:	48 89 c5             	mov    %rax,%rbp
    8352:	48 2b 05 77 08 06 00 	sub    0x60877(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8359:	48 c1 e2 10          	shl    $0x10,%rdx
    835d:	48 39 d0             	cmp    %rdx,%rax
    8360:	73 55                	jae    83b7 <f37+0x2a7>
    8362:	48 89 c2             	mov    %rax,%rdx
    8365:	48 c1 ea 10          	shr    $0x10,%rdx
    8369:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    836d:	48 8b 15 a4 08 06 00 	mov    0x608a4(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8374:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8378:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    837c:	48 85 db             	test   %rbx,%rbx
    837f:	74 36                	je     83b7 <f37+0x2a7>
    8381:	0f b6 0a             	movzbl (%rdx),%ecx
    8384:	80 f9 02             	cmp    $0x2,%cl
    8387:	0f 84 a3 00 00 00    	je     8430 <f37+0x320>
    838d:	80 f9 01             	cmp    $0x1,%cl
    8390:	75 25                	jne    83b7 <f37+0x2a7>
    8392:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8395:	0f b7 c0             	movzwl %ax,%eax
    8398:	8b 52 1c             	mov    0x1c(%rdx),%edx
    839b:	48 0f af c1          	imul   %rcx,%rax
    839f:	48 c1 e8 20          	shr    $0x20,%rax
    83a3:	48 39 d0             	cmp    %rdx,%rax
    83a6:	73 0f                	jae    83b7 <f37+0x2a7>
    83a8:	48 01 c3             	add    %rax,%rbx
    83ab:	80 3b ff             	cmpb   $0xff,(%rbx)
    83ae:	0f 84 2d 01 00 00    	je     84e1 <f37+0x3d1>
    83b4:	c6 03 01             	movb   $0x1,(%rbx)
    83b7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    83bc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    83c3:	00 00 
    83c5:	0f 85 cf 01 00 00    	jne    859a <f37+0x48a>
    83cb:	48 83 c4 38          	add    $0x38,%rsp
    83cf:	48 89 e8             	mov    %rbp,%rax
    83d2:	5b                   	pop    %rbx
    83d3:	5d                   	pop    %rbp
    83d4:	41 5c                	pop    %r12
    83d6:	41 5d                	pop    %r13
    83d8:	41 5e                	pop    %r14
    83da:	41 5f                	pop    %r15
    83dc:	c3                   	ret
    83dd:	0f 1f 00             	nopl   (%rax)
    83e0:	66 85 c0             	test   %ax,%ax
    83e3:	0f 85 d3 fd ff ff    	jne    81bc <f37+0xac>
    83e9:	0f b6 07             	movzbl (%rdi),%eax
    83ec:	84 c0                	test   %al,%al
    83ee:	0f 84 c8 fd ff ff    	je     81bc <f37+0xac>
    83f4:	90                   	nop
    83f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83fc:	00 00 00 00 
    8400:	8b 15 e2 10 06 00    	mov    0x610e2(%rip),%edx        # 694e8 <iteration_active>
    8406:	85 d2                	test   %edx,%edx
    8408:	75 56                	jne    8460 <f37+0x350>
    840a:	3c fd                	cmp    $0xfd,%al
    840c:	0f 87 4b 01 00 00    	ja     855d <f37+0x44d>
    8412:	83 c0 01             	add    $0x1,%eax
    8415:	88 07                	mov    %al,(%rdi)
    8417:	31 d2                	xor    %edx,%edx
    8419:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    841f:	0f 85 97 fd ff ff    	jne    81bc <f37+0xac>
    8425:	e9 b3 fd ff ff       	jmp    81dd <f37+0xcd>
    842a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8430:	66 85 c0             	test   %ax,%ax
    8433:	0f 85 7e ff ff ff    	jne    83b7 <f37+0x2a7>
    8439:	e9 6d ff ff ff       	jmp    83ab <f37+0x29b>
    843e:	66 90                	xchg   %ax,%ax
    8440:	66 85 c0             	test   %ax,%ax
    8443:	0f 85 52 fe ff ff    	jne    829b <f37+0x18b>
    8449:	e9 3f fe ff ff       	jmp    828d <f37+0x17d>
    844e:	66 90                	xchg   %ax,%ax
    8450:	4c 89 e8             	mov    %r13,%rax
    8453:	e9 6d fd ff ff       	jmp    81c5 <f37+0xb5>
    8458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    845f:	00 
    8460:	48 83 05 68 10 06 00 	addq   $0x1,0x61068(%rip)        # 694d0 <iteration_retains>
    8467:	01 
    8468:	eb a0                	jmp    840a <f37+0x2fa>
    846a:	48 f7 d9             	neg    %rcx
    846d:	48 39 d1             	cmp    %rdx,%rcx
    8470:	0f 82 85 00 00 00    	jb     84fb <f37+0x3eb>
    8476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    847d:	00 00 00 
    8480:	be 02 00 00 00       	mov    $0x2,%esi
    8485:	bf 08 00 00 00       	mov    $0x8,%edi
    848a:	e8 61 da ff ff       	call   5ef0 <fwp_heap_alloc>
    848f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8496:	48 8b 15 5b 07 06 00 	mov    0x6075b(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    849d:	49 89 c4             	mov    %rax,%r12
    84a0:	48 2b 05 29 07 06 00 	sub    0x60729(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    84a7:	48 c1 e2 10          	shl    $0x10,%rdx
    84ab:	48 39 d0             	cmp    %rdx,%rax
    84ae:	0f 83 b3 00 00 00    	jae    8567 <f37+0x457>
    84b4:	48 89 c2             	mov    %rax,%rdx
    84b7:	48 c1 ea 10          	shr    $0x10,%rdx
    84bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84bf:	48 8b 15 52 07 06 00 	mov    0x60752(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    84c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84ca:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84ce:	48 85 ed             	test   %rbp,%rbp
    84d1:	0f 84 90 00 00 00    	je     8567 <f37+0x457>
    84d7:	31 db                	xor    %ebx,%ebx
    84d9:	45 31 ed             	xor    %r13d,%r13d
    84dc:	e9 82 fd ff ff       	jmp    8263 <f37+0x153>
    84e1:	48 89 df             	mov    %rbx,%rdi
    84e4:	e8 c7 d2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    84e9:	e9 c6 fe ff ff       	jmp    83b4 <f37+0x2a4>
    84ee:	48 89 ef             	mov    %rbp,%rdi
    84f1:	e8 ba d2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    84f6:	e9 9c fd ff ff       	jmp    8297 <f37+0x187>
    84fb:	48 89 c8             	mov    %rcx,%rax
    84fe:	48 c1 e8 10          	shr    $0x10,%rax
    8502:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8506:	48 8b 05 0b 07 06 00 	mov    0x6070b(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    850d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8511:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8515:	48 85 ff             	test   %rdi,%rdi
    8518:	0f 84 62 ff ff ff    	je     8480 <f37+0x370>
    851e:	0f b6 02             	movzbl (%rdx),%eax
    8521:	3c 02                	cmp    $0x2,%al
    8523:	74 4a                	je     856f <f37+0x45f>
    8525:	3c 01                	cmp    $0x1,%al
    8527:	0f 85 53 ff ff ff    	jne    8480 <f37+0x370>
    852d:	0f b7 c1             	movzwl %cx,%eax
    8530:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8533:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8536:	48 0f af c1          	imul   %rcx,%rax
    853a:	48 c1 e8 20          	shr    $0x20,%rax
    853e:	48 39 d0             	cmp    %rdx,%rax
    8541:	0f 83 39 ff ff ff    	jae    8480 <f37+0x370>
    8547:	48 01 c7             	add    %rax,%rdi
    854a:	0f b6 07             	movzbl (%rdi),%eax
    854d:	84 c0                	test   %al,%al
    854f:	0f 84 2b ff ff ff    	je     8480 <f37+0x370>
    8555:	45 31 ed             	xor    %r13d,%r13d
    8558:	e9 a3 fe ff ff       	jmp    8400 <f37+0x2f0>
    855d:	e8 2e d1 ff ff       	call   5690 <fwp_rc_wide_dup>
    8562:	e9 b0 fe ff ff       	jmp    8417 <f37+0x307>
    8567:	45 31 ed             	xor    %r13d,%r13d
    856a:	e9 8e fd ff ff       	jmp    82fd <f37+0x1ed>
    856f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8575:	49 89 cd             	mov    %rcx,%r13
    8578:	0f 85 02 ff ff ff    	jne    8480 <f37+0x370>
    857e:	0f b6 07             	movzbl (%rdi),%eax
    8581:	84 c0                	test   %al,%al
    8583:	0f 85 77 fe ff ff    	jne    8400 <f37+0x2f0>
    8589:	e9 f2 fe ff ff       	jmp    8480 <f37+0x370>
    858e:	48 8d 3d 56 2c 00 00 	lea    0x2c56(%rip),%rdi        # b1eb <_IO_stdin_used+0x1eb>
    8595:	e8 96 be ff ff       	call   4430 <fwp_trap>
    859a:	e8 b1 ae ff ff       	call   3450 <__stack_chk_fail@plt>
    859f:	90                   	nop

00000000000085a0 <fwp_owned_entry37>:
    85a0:	f3 0f 1e fa          	endbr64
    85a4:	48 8b 3f             	mov    (%rdi),%rdi
    85a7:	e9 64 fb ff ff       	jmp    8110 <f37>
    85ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000085b0 <e37>:
    85b0:	f3 0f 1e fa          	endbr64
    85b4:	53                   	push   %rbx
    85b5:	48 8b 1f             	mov    (%rdi),%rbx
    85b8:	48 89 df             	mov    %rbx,%rdi
    85bb:	e8 80 e2 ff ff       	call   6840 <fwp_rc_share>
    85c0:	48 89 df             	mov    %rbx,%rdi
    85c3:	e8 48 fb ff ff       	call   8110 <f37>
    85c8:	48 89 c3             	mov    %rax,%rbx
    85cb:	48 89 c7             	mov    %rax,%rdi
    85ce:	e8 6d e2 ff ff       	call   6840 <fwp_rc_share>
    85d3:	48 89 d8             	mov    %rbx,%rax
    85d6:	5b                   	pop    %rbx
    85d7:	c3                   	ret
    85d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    85df:	00 

00000000000085e0 <fwp_write>:
    85e0:	41 57                	push   %r15
    85e2:	41 56                	push   %r14
    85e4:	41 55                	push   %r13
    85e6:	41 54                	push   %r12
    85e8:	55                   	push   %rbp
    85e9:	53                   	push   %rbx
    85ea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    85f1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    85f8:	00 00 
    85fa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8601:	00 
    8602:	49 89 d4             	mov    %rdx,%r12
    8605:	8b 12                	mov    (%rdx),%edx
    8607:	83 fa 19             	cmp    $0x19,%edx
    860a:	77 6a                	ja     8676 <fwp_write+0x96>
    860c:	48 89 f5             	mov    %rsi,%rbp
    860f:	89 d0                	mov    %edx,%eax
    8611:	89 ce                	mov    %ecx,%esi
    8613:	48 89 fb             	mov    %rdi,%rbx
    8616:	48 8d 0d e3 35 00 00 	lea    0x35e3(%rip),%rcx        # bc00 <_IO_stdin_used+0xc00>
    861d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8621:	48 01 c8             	add    %rcx,%rax
    8624:	3e ff e0             	notrack jmp *%rax
    8627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    862e:	00 00 
    8630:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8634:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8638:	48 89 ca             	mov    %rcx,%rdx
    863b:	48 85 c9             	test   %rcx,%rcx
    863e:	0f 88 9c 0c 00 00    	js     92e0 <fwp_write+0xd00>
    8644:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    864b:	00 
    864c:	48 89 c6             	mov    %rax,%rsi
    864f:	4c 89 e7             	mov    %r12,%rdi
    8652:	e8 c9 b3 ff ff       	call   3a20 <fwp_fmt_u128>
    8657:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    865e:	00 00 
    8660:	4c 89 e7             	mov    %r12,%rdi
    8663:	e8 d8 ad ff ff       	call   3440 <strlen@plt>
    8668:	4c 89 e6             	mov    %r12,%rsi
    866b:	48 89 df             	mov    %rbx,%rdi
    866e:	48 89 c2             	mov    %rax,%rdx
    8671:	e8 5a ba ff ff       	call   40d0 <buf_put>
    8676:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    867d:	00 
    867e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8685:	00 00 
    8687:	0f 85 28 04 00 00    	jne    8ab5 <fwp_write+0x4d5>
    868d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8694:	5b                   	pop    %rbx
    8695:	5d                   	pop    %rbp
    8696:	41 5c                	pop    %r12
    8698:	41 5d                	pop    %r13
    869a:	41 5e                	pop    %r14
    869c:	41 5f                	pop    %r15
    869e:	c3                   	ret
    869f:	90                   	nop
    86a0:	49 89 e9             	mov    %rbp,%r9
    86a3:	4c 8d 05 6b 2b 00 00 	lea    0x2b6b(%rip),%r8        # b215 <_IO_stdin_used+0x215>
    86aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    86af:	ba 02 00 00 00       	mov    $0x2,%edx
    86b4:	be 00 02 00 00       	mov    $0x200,%esi
    86b9:	31 c0                	xor    %eax,%eax
    86bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    86c2:	00 
    86c3:	e8 d8 ac ff ff       	call   33a0 <__snprintf_chk@plt>
    86c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    86cf:	00 
    86d0:	e8 6b ad ff ff       	call   3440 <strlen@plt>
    86d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    86dc:	00 
    86dd:	48 89 df             	mov    %rbx,%rdi
    86e0:	48 89 c2             	mov    %rax,%rdx
    86e3:	e8 e8 b9 ff ff       	call   40d0 <buf_put>
    86e8:	eb 8c                	jmp    8676 <fwp_write+0x96>
    86ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86f0:	49 89 e9             	mov    %rbp,%r9
    86f3:	4c 8d 05 16 2b 00 00 	lea    0x2b16(%rip),%r8        # b210 <_IO_stdin_used+0x210>
    86fa:	eb ae                	jmp    86aa <fwp_write+0xca>
    86fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8700:	83 fa 13             	cmp    $0x13,%edx
    8703:	48 8d 05 fc 2a 00 00 	lea    0x2afc(%rip),%rax        # b206 <_IO_stdin_used+0x206>
    870a:	48 8d 35 fa 2a 00 00 	lea    0x2afa(%rip),%rsi        # b20b <_IO_stdin_used+0x20b>
    8711:	ba 04 00 00 00       	mov    $0x4,%edx
    8716:	48 0f 44 f0          	cmove  %rax,%rsi
    871a:	45 31 ed             	xor    %r13d,%r13d
    871d:	e8 ae b9 ff ff       	call   40d0 <buf_put>
    8722:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8727:	0f 84 a3 08 00 00    	je     8fd0 <fwp_write+0x9f0>
    872d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8732:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8737:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    873c:	48 89 df             	mov    %rbx,%rdi
    873f:	49 0f 44 c5          	cmove  %r13,%rax
    8743:	31 c9                	xor    %ecx,%ecx
    8745:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    874a:	e8 91 fe ff ff       	call   85e0 <fwp_write>
    874f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8754:	0f 84 6e 09 00 00    	je     90c8 <fwp_write+0xae8>
    875a:	49 83 c5 01          	add    $0x1,%r13
    875e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8762:	0f 83 68 08 00 00    	jae    8fd0 <fwp_write+0x9f0>
    8768:	ba 02 00 00 00       	mov    $0x2,%edx
    876d:	48 8d 35 e1 2a 00 00 	lea    0x2ae1(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8774:	48 89 df             	mov    %rbx,%rdi
    8777:	e8 54 b9 ff ff       	call   40d0 <buf_put>
    877c:	eb af                	jmp    872d <fwp_write+0x14d>
    877e:	66 90                	xchg   %ax,%ax
    8780:	ba 06 00 00 00       	mov    $0x6,%edx
    8785:	48 8d 35 a2 2a 00 00 	lea    0x2aa2(%rip),%rsi        # b22e <_IO_stdin_used+0x22e>
    878c:	48 83 c5 10          	add    $0x10,%rbp
    8790:	e8 3b b9 ff ff       	call   40d0 <buf_put>
    8795:	48 89 ef             	mov    %rbp,%rdi
    8798:	e8 a3 ac ff ff       	call   3440 <strlen@plt>
    879d:	48 89 ee             	mov    %rbp,%rsi
    87a0:	48 89 df             	mov    %rbx,%rdi
    87a3:	48 89 c2             	mov    %rax,%rdx
    87a6:	e8 25 b9 ff ff       	call   40d0 <buf_put>
    87ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    87b0:	ba 01 00 00 00       	mov    $0x1,%edx
    87b5:	48 89 df             	mov    %rbx,%rdi
    87b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    87bd:	e8 0e b9 ff ff       	call   40d0 <buf_put>
    87c2:	e9 af fe ff ff       	jmp    8676 <fwp_write+0x96>
    87c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87ce:	00 00 
    87d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87d7:	00 
    87d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87df:	00 00 
    87e1:	0f 85 ce 02 00 00    	jne    8ab5 <fwp_write+0x4d5>
    87e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    87ec:	48 8d 35 27 2a 00 00 	lea    0x2a27(%rip),%rsi        # b21a <_IO_stdin_used+0x21a>
    87f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    87fa:	48 89 df             	mov    %rbx,%rdi
    87fd:	5b                   	pop    %rbx
    87fe:	5d                   	pop    %rbp
    87ff:	41 5c                	pop    %r12
    8801:	41 5d                	pop    %r13
    8803:	41 5e                	pop    %r14
    8805:	41 5f                	pop    %r15
    8807:	e9 c4 b8 ff ff       	jmp    40d0 <buf_put>
    880c:	0f 1f 40 00          	nopl   0x0(%rax)
    8810:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8815:	4d 85 ed             	test   %r13,%r13
    8818:	0f 84 02 0c 00 00    	je     9420 <fwp_write+0xe40>
    881e:	48 8d 35 3d 2a 00 00 	lea    0x2a3d(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    8825:	4c 89 ef             	mov    %r13,%rdi
    8828:	e8 f3 ac ff ff       	call   3520 <strcmp@plt>
    882d:	41 89 c1             	mov    %eax,%r9d
    8830:	85 c0                	test   %eax,%eax
    8832:	0f 84 6c 0c 00 00    	je     94a4 <fwp_write+0xec4>
    8838:	4c 89 ef             	mov    %r13,%rdi
    883b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8840:	e8 fb ab ff ff       	call   3440 <strlen@plt>
    8845:	4c 89 ee             	mov    %r13,%rsi
    8848:	48 89 df             	mov    %rbx,%rdi
    884b:	48 89 c2             	mov    %rax,%rdx
    884e:	e8 7d b8 ff ff       	call   40d0 <buf_put>
    8853:	ba 01 00 00 00       	mov    $0x1,%edx
    8858:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    885d:	48 89 df             	mov    %rbx,%rdi
    8860:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8865:	e8 66 b8 ff ff       	call   40d0 <buf_put>
    886a:	ba 01 00 00 00       	mov    $0x1,%edx
    886f:	4c 89 fe             	mov    %r15,%rsi
    8872:	48 89 df             	mov    %rbx,%rdi
    8875:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    887a:	e8 51 b8 ff ff       	call   40d0 <buf_put>
    887f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8884:	45 31 f6             	xor    %r14d,%r14d
    8887:	85 d2                	test   %edx,%edx
    8889:	0f 8e 81 0a 00 00    	jle    9310 <fwp_write+0xd30>
    888f:	45 31 ed             	xor    %r13d,%r13d
    8892:	4d 85 ed             	test   %r13,%r13
    8895:	0f 85 75 07 00 00    	jne    9010 <fwp_write+0xa30>
    889b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    88a2:	00 
    88a3:	45 85 f6             	test   %r14d,%r14d
    88a6:	0f 84 84 07 00 00    	je     9030 <fwp_write+0xa50>
    88ac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    88b1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    88b6:	48 89 df             	mov    %rbx,%rdi
    88b9:	49 83 c5 01          	add    $0x1,%r13
    88bd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    88c1:	31 c9                	xor    %ecx,%ecx
    88c3:	e8 18 fd ff ff       	call   85e0 <fwp_write>
    88c8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    88cd:	7f c3                	jg     8892 <fwp_write+0x2b2>
    88cf:	45 85 f6             	test   %r14d,%r14d
    88d2:	0f 84 38 0a 00 00    	je     9310 <fwp_write+0xd30>
    88d8:	b8 29 00 00 00       	mov    $0x29,%eax
    88dd:	ba 01 00 00 00       	mov    $0x1,%edx
    88e2:	4c 89 fe             	mov    %r15,%rsi
    88e5:	48 89 df             	mov    %rbx,%rdi
    88e8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    88ec:	e8 df b7 ff ff       	call   40d0 <buf_put>
    88f1:	e9 80 fd ff ff       	jmp    8676 <fwp_write+0x96>
    88f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88fd:	00 00 00 
    8900:	ba 01 00 00 00       	mov    $0x1,%edx
    8905:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    890a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    890f:	e8 bc b7 ff ff       	call   40d0 <buf_put>
    8914:	48 85 ed             	test   %rbp,%rbp
    8917:	0f 84 93 06 00 00    	je     8fb0 <fwp_write+0x9d0>
    891d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8921:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8926:	31 c9                	xor    %ecx,%ecx
    8928:	48 89 df             	mov    %rbx,%rdi
    892b:	e8 b0 fc ff ff       	call   85e0 <fwp_write>
    8930:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8934:	48 85 ed             	test   %rbp,%rbp
    8937:	0f 84 73 06 00 00    	je     8fb0 <fwp_write+0x9d0>
    893d:	ba 02 00 00 00       	mov    $0x2,%edx
    8942:	48 8d 35 0c 29 00 00 	lea    0x290c(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8949:	48 89 df             	mov    %rbx,%rdi
    894c:	e8 7f b7 ff ff       	call   40d0 <buf_put>
    8951:	eb ca                	jmp    891d <fwp_write+0x33d>
    8953:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8958:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    895c:	85 f6                	test   %esi,%esi
    895e:	0f 84 fc 07 00 00    	je     9160 <fwp_write+0xb80>
    8964:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    896b:	00 
    896c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8973:	00 00 
    8975:	0f 85 3a 01 00 00    	jne    8ab5 <fwp_write+0x4d5>
    897b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    897f:	4c 89 ea             	mov    %r13,%rdx
    8982:	e9 6c fe ff ff       	jmp    87f3 <fwp_write+0x213>
    8987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    898e:	00 00 
    8990:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8995:	ba 01 00 00 00       	mov    $0x1,%edx
    899a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    899f:	48 89 ee             	mov    %rbp,%rsi
    89a2:	e8 29 b7 ff ff       	call   40d0 <buf_put>
    89a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    89ac:	4c 89 e7             	mov    %r12,%rdi
    89af:	e8 8c aa ff ff       	call   3440 <strlen@plt>
    89b4:	4c 89 e6             	mov    %r12,%rsi
    89b7:	48 89 df             	mov    %rbx,%rdi
    89ba:	48 89 c2             	mov    %rax,%rdx
    89bd:	e8 0e b7 ff ff       	call   40d0 <buf_put>
    89c2:	ba 01 00 00 00       	mov    $0x1,%edx
    89c7:	48 89 ee             	mov    %rbp,%rsi
    89ca:	48 89 df             	mov    %rbx,%rdi
    89cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    89d2:	e8 f9 b6 ff ff       	call   40d0 <buf_put>
    89d7:	e9 9a fc ff ff       	jmp    8676 <fwp_write+0x96>
    89dc:	0f 1f 40 00          	nopl   0x0(%rax)
    89e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    89e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    89e9:	0f 8a 8e 0b 00 00    	jp     957d <fwp_write+0xf9d>
    89ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    89f3:	66 0f 54 05 05 33 00 	andpd  0x3305(%rip),%xmm0        # bd00 <msg.4+0x90>
    89fa:	00 
    89fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8a00:	66 0f 2e 05 28 33 00 	ucomisd 0x3328(%rip),%xmm0        # bd30 <msg.4+0xc0>
    8a07:	00 
    8a08:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8a0f:	00 
    8a10:	0f 87 b2 09 00 00    	ja     93c8 <fwp_write+0xde8>
    8a16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a1d:	00 00 00 
    8a20:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a24:	89 ee                	mov    %ebp,%esi
    8a26:	4c 89 e7             	mov    %r12,%rdi
    8a29:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8a2e:	e8 1d bd ff ff       	call   4750 <fwp_format_g.constprop.0>
    8a33:	31 f6                	xor    %esi,%esi
    8a35:	4c 89 e7             	mov    %r12,%rdi
    8a38:	e8 c3 a9 ff ff       	call   3400 <strtod@plt>
    8a3d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8a42:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8a46:	7a 06                	jp     8a4e <fwp_write+0x46e>
    8a48:	0f 84 e9 01 00 00    	je     8c37 <fwp_write+0x657>
    8a4e:	83 c5 01             	add    $0x1,%ebp
    8a51:	83 fd 12             	cmp    $0x12,%ebp
    8a54:	75 ca                	jne    8a20 <fwp_write+0x440>
    8a56:	be 11 00 00 00       	mov    $0x11,%esi
    8a5b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a5f:	4c 89 e7             	mov    %r12,%rdi
    8a62:	e8 e9 bc ff ff       	call   4750 <fwp_format_g.constprop.0>
    8a67:	e9 cb 01 00 00       	jmp    8c37 <fwp_write+0x657>
    8a6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a70:	48 83 fd 01          	cmp    $0x1,%rbp
    8a74:	0f 84 e6 08 00 00    	je     9360 <fwp_write+0xd80>
    8a7a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8a7e:	b8 02 00 00 00       	mov    $0x2,%eax
    8a83:	ba 01 00 00 00       	mov    $0x1,%edx
    8a88:	48 0f 44 d0          	cmove  %rax,%rdx
    8a8c:	48 8d 35 6b 27 00 00 	lea    0x276b(%rip),%rsi        # b1fe <_IO_stdin_used+0x1fe>
    8a93:	48 8d 05 69 27 00 00 	lea    0x2769(%rip),%rax        # b203 <_IO_stdin_used+0x203>
    8a9a:	48 0f 44 f0          	cmove  %rax,%rsi
    8a9e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8aa5:	00 
    8aa6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8aad:	00 00 
    8aaf:	0f 84 3e fd ff ff    	je     87f3 <fwp_write+0x213>
    8ab5:	e8 96 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ac0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8ac5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8aca:	e8 41 b5 ff ff       	call   4010 <buf_grow>
    8acf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8ad3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8ad9:	4c 03 0b             	add    (%rbx),%r9
    8adc:	66 45 89 11          	mov    %r10w,(%r9)
    8ae0:	45 85 e4             	test   %r12d,%r12d
    8ae3:	0f 8e 07 05 00 00    	jle    8ff0 <fwp_write+0xa10>
    8ae9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8af0:	55 55 55 
    8af3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8af8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8aff:	aa aa aa 
    8b02:	49 83 c1 01          	add    $0x1,%r9
    8b06:	eb 45                	jmp    8b4d <fwp_write+0x56d>
    8b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b0f:	00 
    8b10:	be 01 00 00 00       	mov    $0x1,%esi
    8b15:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8b1a:	88 07                	mov    %al,(%rdi)
    8b1c:	48 89 e8             	mov    %rbp,%rax
    8b1f:	49 f7 e8             	imul   %r8
    8b22:	48 89 e8             	mov    %rbp,%rax
    8b25:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b29:	48 29 c2             	sub    %rax,%rdx
    8b2c:	48 85 c9             	test   %rcx,%rcx
    8b2f:	0f 95 c0             	setne  %al
    8b32:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8b36:	48 83 ef 01          	sub    $0x1,%rdi
    8b3a:	48 21 c5             	and    %rax,%rbp
    8b3d:	48 29 ea             	sub    %rbp,%rdx
    8b40:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8b44:	49 39 f9             	cmp    %rdi,%r9
    8b47:	0f 84 a3 04 00 00    	je     8ff0 <fwp_write+0xa10>
    8b4d:	48 89 e8             	mov    %rbp,%rax
    8b50:	49 f7 e8             	imul   %r8
    8b53:	48 89 e8             	mov    %rbp,%rax
    8b56:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b5a:	48 89 d1             	mov    %rdx,%rcx
    8b5d:	48 29 c1             	sub    %rax,%rcx
    8b60:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8b64:	48 89 e9             	mov    %rbp,%rcx
    8b67:	48 29 c1             	sub    %rax,%rcx
    8b6a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8b6e:	49 f7 e2             	mul    %r10
    8b71:	b8 30 00 00 00       	mov    $0x30,%eax
    8b76:	48 89 d6             	mov    %rdx,%rsi
    8b79:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8b7d:	48 d1 ee             	shr    $1,%rsi
    8b80:	48 01 f2             	add    %rsi,%rdx
    8b83:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8b87:	48 29 d6             	sub    %rdx,%rsi
    8b8a:	74 8e                	je     8b1a <fwp_write+0x53a>
    8b8c:	48 83 fe 01          	cmp    $0x1,%rsi
    8b90:	0f 85 7a ff ff ff    	jne    8b10 <fwp_write+0x530>
    8b96:	31 f6                	xor    %esi,%esi
    8b98:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8b9d:	e9 78 ff ff ff       	jmp    8b1a <fwp_write+0x53a>
    8ba2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ba8:	66 0f 6e cd          	movd   %ebp,%xmm1
    8bac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8baf:	0f 8a c8 09 00 00    	jp     957d <fwp_write+0xf9d>
    8bb5:	0f 28 c1             	movaps %xmm1,%xmm0
    8bb8:	0f 54 05 31 31 00 00 	andps  0x3131(%rip),%xmm0        # bcf0 <msg.4+0x80>
    8bbf:	0f 2e 05 3e 24 00 00 	ucomiss 0x243e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8bc6:	0f 87 24 08 00 00    	ja     93f0 <fwp_write+0xe10>
    8bcc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8bd0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8bd6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8bdd:	00 
    8bde:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8be2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bee:	00 00 
    8bf0:	44 89 ee             	mov    %r13d,%esi
    8bf3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8bf8:	4c 89 e7             	mov    %r12,%rdi
    8bfb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8c00:	e8 4b bb ff ff       	call   4750 <fwp_format_g.constprop.0>
    8c05:	31 f6                	xor    %esi,%esi
    8c07:	4c 89 e7             	mov    %r12,%rdi
    8c0a:	e8 91 a8 ff ff       	call   34a0 <strtof@plt>
    8c0f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8c14:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8c17:	7a 02                	jp     8c1b <fwp_write+0x63b>
    8c19:	74 1c                	je     8c37 <fwp_write+0x657>
    8c1b:	41 83 c5 01          	add    $0x1,%r13d
    8c1f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8c23:	75 cb                	jne    8bf0 <fwp_write+0x610>
    8c25:	be 09 00 00 00       	mov    $0x9,%esi
    8c2a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c2f:	4c 89 e7             	mov    %r12,%rdi
    8c32:	e8 19 bb ff ff       	call   4750 <fwp_format_g.constprop.0>
    8c37:	4c 89 e7             	mov    %r12,%rdi
    8c3a:	e8 51 b5 ff ff       	call   4190 <fwp_finish_float>
    8c3f:	e9 1c fa ff ff       	jmp    8660 <fwp_write+0x80>
    8c44:	0f 1f 40 00          	nopl   0x0(%rax)
    8c48:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8c4c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8c50:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8c57:	00 
    8c58:	48 89 ef             	mov    %rbp,%rdi
    8c5b:	e8 c0 ad ff ff       	call   3a20 <fwp_fmt_u128>
    8c60:	48 89 ef             	mov    %rbp,%rdi
    8c63:	e8 d8 a7 ff ff       	call   3440 <strlen@plt>
    8c68:	48 89 ee             	mov    %rbp,%rsi
    8c6b:	48 89 df             	mov    %rbx,%rdi
    8c6e:	48 89 c2             	mov    %rax,%rdx
    8c71:	e8 5a b4 ff ff       	call   40d0 <buf_put>
    8c76:	e9 fb f9 ff ff       	jmp    8676 <fwp_write+0x96>
    8c7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c80:	ba 06 00 00 00       	mov    $0x6,%edx
    8c85:	48 8d 35 cc 25 00 00 	lea    0x25cc(%rip),%rsi        # b258 <_IO_stdin_used+0x258>
    8c8c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8c92:	e8 39 b4 ff ff       	call   40d0 <buf_put>
    8c97:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8c9e:	ff ff 7f 
    8ca1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8ca5:	0f 84 86 02 00 00    	je     8f31 <fwp_write+0x951>
    8cab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8cb0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8cb4:	48 85 d2             	test   %rdx,%rdx
    8cb7:	0f 84 ae 00 00 00    	je     8d6b <fwp_write+0x78b>
    8cbd:	8b 0a                	mov    (%rdx),%ecx
    8cbf:	83 f9 1c             	cmp    $0x1c,%ecx
    8cc2:	0f 84 58 06 00 00    	je     9320 <fwp_write+0xd40>
    8cc8:	83 f9 1b             	cmp    $0x1b,%ecx
    8ccb:	0f 87 9a 00 00 00    	ja     8d6b <fwp_write+0x78b>
    8cd1:	be 01 00 00 00       	mov    $0x1,%esi
    8cd6:	48 d3 e6             	shl    %cl,%rsi
    8cd9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8cdf:	0f 85 4b 04 00 00    	jne    9130 <fwp_write+0xb50>
    8ce5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8ceb:	0f 85 0f 04 00 00    	jne    9100 <fwp_write+0xb20>
    8cf1:	83 e6 21             	and    $0x21,%esi
    8cf4:	74 75                	je     8d6b <fwp_write+0x78b>
    8cf6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8cfb:	48 85 ff             	test   %rdi,%rdi
    8cfe:	79 07                	jns    8d07 <fwp_write+0x727>
    8d00:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8d04:	4c 01 ee             	add    %r13,%rsi
    8d07:	48 0f be 3e          	movsbq (%rsi),%rdi
    8d0b:	85 c9                	test   %ecx,%ecx
    8d0d:	40 0f b6 f7          	movzbl %dil,%esi
    8d11:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d1c:	00 00 00 00 
    8d20:	31 c9                	xor    %ecx,%ecx
    8d22:	48 89 df             	mov    %rbx,%rdi
    8d25:	49 83 c5 01          	add    $0x1,%r13
    8d29:	e8 b2 f8 ff ff       	call   85e0 <fwp_write>
    8d2e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d35:	ff ff 7f 
    8d38:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d3c:	49 39 d5             	cmp    %rdx,%r13
    8d3f:	0f 83 ec 01 00 00    	jae    8f31 <fwp_write+0x951>
    8d45:	ba 02 00 00 00       	mov    $0x2,%edx
    8d4a:	48 89 df             	mov    %rbx,%rdi
    8d4d:	48 8d 35 01 25 00 00 	lea    0x2501(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8d54:	e8 77 b3 ff ff       	call   40d0 <buf_put>
    8d59:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d5e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d62:	48 85 d2             	test   %rdx,%rdx
    8d65:	0f 85 52 ff ff ff    	jne    8cbd <fwp_write+0x6dd>
    8d6b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8d70:	48 85 ff             	test   %rdi,%rdi
    8d73:	0f 88 cf 05 00 00    	js     9348 <fwp_write+0xd68>
    8d79:	48 8b 31             	mov    (%rcx),%rsi
    8d7c:	eb a2                	jmp    8d20 <fwp_write+0x740>
    8d7e:	66 90                	xchg   %ax,%ax
    8d80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d87:	00 
    8d88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d8f:	00 00 
    8d91:	0f 85 1e fd ff ff    	jne    8ab5 <fwp_write+0x4d5>
    8d97:	ba 08 00 00 00       	mov    $0x8,%edx
    8d9c:	48 8d 35 82 24 00 00 	lea    0x2482(%rip),%rsi        # b225 <_IO_stdin_used+0x225>
    8da3:	e9 4b fa ff ff       	jmp    87f3 <fwp_write+0x213>
    8da8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8daf:	00 
    8db0:	89 e8                	mov    %ebp,%eax
    8db2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8db9:	76 03                	jbe    8dbe <fwp_write+0x7de>
    8dbb:	8b 45 00             	mov    0x0(%rbp),%eax
    8dbe:	41 89 c6             	mov    %eax,%r14d
    8dc1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8dc6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8dcb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8dcf:	4c 89 ef             	mov    %r13,%rdi
    8dd2:	e8 69 a6 ff ff       	call   3440 <strlen@plt>
    8dd7:	4c 89 ee             	mov    %r13,%rsi
    8dda:	48 89 df             	mov    %rbx,%rdi
    8ddd:	48 89 c2             	mov    %rax,%rdx
    8de0:	e8 eb b2 ff ff       	call   40d0 <buf_put>
    8de5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8dea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8dee:	85 f6                	test   %esi,%esi
    8df0:	0f 8e 80 f8 ff ff    	jle    8676 <fwp_write+0x96>
    8df6:	45 31 ed             	xor    %r13d,%r13d
    8df9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8dfe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8e03:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e08:	ba 01 00 00 00       	mov    $0x1,%edx
    8e0d:	4c 89 fe             	mov    %r15,%rsi
    8e10:	48 89 04 24          	mov    %rax,(%rsp)
    8e14:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8e19:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8e1d:	48 89 df             	mov    %rbx,%rdi
    8e20:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8e24:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8e29:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8e2e:	e8 9d b2 ff ff       	call   40d0 <buf_put>
    8e33:	41 8b 06             	mov    (%r14),%eax
    8e36:	83 f8 0e             	cmp    $0xe,%eax
    8e39:	0f 84 71 02 00 00    	je     90b0 <fwp_write+0xad0>
    8e3f:	83 f8 10             	cmp    $0x10,%eax
    8e42:	0f 84 38 02 00 00    	je     9080 <fwp_write+0xaa0>
    8e48:	83 f8 0a             	cmp    $0xa,%eax
    8e4b:	0f 84 7f 04 00 00    	je     92d0 <fwp_write+0xcf0>
    8e51:	0f 8f f9 00 00 00    	jg     8f50 <fwp_write+0x970>
    8e57:	83 f8 03             	cmp    $0x3,%eax
    8e5a:	0f 8f 50 04 00 00    	jg     92b0 <fwp_write+0xcd0>
    8e60:	85 c0                	test   %eax,%eax
    8e62:	78 10                	js     8e74 <fwp_write+0x894>
    8e64:	48 8b 04 24          	mov    (%rsp),%rax
    8e68:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e6c:	85 c0                	test   %eax,%eax
    8e6e:	0f 85 f9 00 00 00    	jne    8f6d <fwp_write+0x98d>
    8e74:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8e79:	48 8b 34 24          	mov    (%rsp),%rsi
    8e7d:	31 c9                	xor    %ecx,%ecx
    8e7f:	48 89 df             	mov    %rbx,%rdi
    8e82:	e8 59 f7 ff ff       	call   85e0 <fwp_write>
    8e87:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e8c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e91:	49 83 c5 01          	add    $0x1,%r13
    8e95:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8e99:	0f 8f 5f ff ff ff    	jg     8dfe <fwp_write+0x81e>
    8e9f:	e9 d2 f7 ff ff       	jmp    8676 <fwp_write+0x96>
    8ea4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ea8:	ba 06 00 00 00       	mov    $0x6,%edx
    8ead:	48 8d 35 97 23 00 00 	lea    0x2397(%rip),%rsi        # b24b <_IO_stdin_used+0x24b>
    8eb4:	45 31 ed             	xor    %r13d,%r13d
    8eb7:	e8 14 b2 ff ff       	call   40d0 <buf_put>
    8ebc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8ec1:	75 19                	jne    8edc <fwp_write+0x8fc>
    8ec3:	eb 6c                	jmp    8f31 <fwp_write+0x951>
    8ec5:	0f 1f 00             	nopl   (%rax)
    8ec8:	ba 02 00 00 00       	mov    $0x2,%edx
    8ecd:	48 8d 35 81 23 00 00 	lea    0x2381(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8ed4:	48 89 df             	mov    %rbx,%rdi
    8ed7:	e8 f4 b1 ff ff       	call   40d0 <buf_put>
    8edc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8ee2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8ee7:	31 c0                	xor    %eax,%eax
    8ee9:	49 83 c5 01          	add    $0x1,%r13
    8eed:	4c 8d 05 5e 23 00 00 	lea    0x235e(%rip),%r8        # b252 <_IO_stdin_used+0x252>
    8ef4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ef9:	be 00 02 00 00       	mov    $0x200,%esi
    8efe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f05:	00 
    8f06:	e8 95 a4 ff ff       	call   33a0 <__snprintf_chk@plt>
    8f0b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f12:	00 
    8f13:	e8 28 a5 ff ff       	call   3440 <strlen@plt>
    8f18:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f1f:	00 
    8f20:	48 89 df             	mov    %rbx,%rdi
    8f23:	48 89 c2             	mov    %rax,%rdx
    8f26:	e8 a5 b1 ff ff       	call   40d0 <buf_put>
    8f2b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8f2f:	72 97                	jb     8ec8 <fwp_write+0x8e8>
    8f31:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f36:	ba 01 00 00 00       	mov    $0x1,%edx
    8f3b:	48 89 df             	mov    %rbx,%rdi
    8f3e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f43:	e8 88 b1 ff ff       	call   40d0 <buf_put>
    8f48:	e9 29 f7 ff ff       	jmp    8676 <fwp_write+0x96>
    8f4d:	0f 1f 00             	nopl   (%rax)
    8f50:	83 f8 0b             	cmp    $0xb,%eax
    8f53:	0f 85 1b ff ff ff    	jne    8e74 <fwp_write+0x894>
    8f59:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8f5e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8f62:	83 e0 01             	and    $0x1,%eax
    8f65:	85 c0                	test   %eax,%eax
    8f67:	0f 84 07 ff ff ff    	je     8e74 <fwp_write+0x894>
    8f6d:	4c 89 fe             	mov    %r15,%rsi
    8f70:	48 89 df             	mov    %rbx,%rdi
    8f73:	ba 01 00 00 00       	mov    $0x1,%edx
    8f78:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8f7d:	e8 4e b1 ff ff       	call   40d0 <buf_put>
    8f82:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f87:	48 8b 34 24          	mov    (%rsp),%rsi
    8f8b:	31 c9                	xor    %ecx,%ecx
    8f8d:	48 89 df             	mov    %rbx,%rdi
    8f90:	e8 4b f6 ff ff       	call   85e0 <fwp_write>
    8f95:	ba 01 00 00 00       	mov    $0x1,%edx
    8f9a:	4c 89 fe             	mov    %r15,%rsi
    8f9d:	48 89 df             	mov    %rbx,%rdi
    8fa0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8fa5:	e8 26 b1 ff ff       	call   40d0 <buf_put>
    8faa:	e9 d8 fe ff ff       	jmp    8e87 <fwp_write+0x8a7>
    8faf:	90                   	nop
    8fb0:	ba 01 00 00 00       	mov    $0x1,%edx
    8fb5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fba:	48 89 df             	mov    %rbx,%rdi
    8fbd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8fc2:	e8 09 b1 ff ff       	call   40d0 <buf_put>
    8fc7:	e9 aa f6 ff ff       	jmp    8676 <fwp_write+0x96>
    8fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fd0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8fda:	48 89 df             	mov    %rbx,%rdi
    8fdd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8fe2:	e8 e9 b0 ff ff       	call   40d0 <buf_put>
    8fe7:	e9 8a f6 ff ff       	jmp    8676 <fwp_write+0x96>
    8fec:	0f 1f 40 00          	nopl   0x0(%rax)
    8ff0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8ff4:	48 8b 13             	mov    (%rbx),%rdx
    8ff7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8ffc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9000:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9004:	e9 6d f6 ff ff       	jmp    8676 <fwp_write+0x96>
    9009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9010:	ba 02 00 00 00       	mov    $0x2,%edx
    9015:	48 8d 35 39 22 00 00 	lea    0x2239(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    901c:	48 89 df             	mov    %rbx,%rdi
    901f:	e8 ac b0 ff ff       	call   40d0 <buf_put>
    9024:	e9 72 f8 ff ff       	jmp    889b <fwp_write+0x2bb>
    9029:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9030:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9035:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    903a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    903e:	48 89 f7             	mov    %rsi,%rdi
    9041:	48 89 34 24          	mov    %rsi,(%rsp)
    9045:	e8 f6 a3 ff ff       	call   3440 <strlen@plt>
    904a:	48 8b 34 24          	mov    (%rsp),%rsi
    904e:	48 89 df             	mov    %rbx,%rdi
    9051:	48 89 c2             	mov    %rax,%rdx
    9054:	e8 77 b0 ff ff       	call   40d0 <buf_put>
    9059:	ba 03 00 00 00       	mov    $0x3,%edx
    905e:	48 8d 35 13 22 00 00 	lea    0x2213(%rip),%rsi        # b278 <_IO_stdin_used+0x278>
    9065:	48 89 df             	mov    %rbx,%rdi
    9068:	e8 63 b0 ff ff       	call   40d0 <buf_put>
    906d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9072:	e9 35 f8 ff ff       	jmp    88ac <fwp_write+0x2cc>
    9077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    907e:	00 00 
    9080:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9085:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9089:	48 85 ff             	test   %rdi,%rdi
    908c:	0f 84 e2 fd ff ff    	je     8e74 <fwp_write+0x894>
    9092:	48 8d 35 c9 21 00 00 	lea    0x21c9(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    9099:	e8 82 a4 ff ff       	call   3520 <strcmp@plt>
    909e:	85 c0                	test   %eax,%eax
    90a0:	0f 95 c0             	setne  %al
    90a3:	0f b6 c0             	movzbl %al,%eax
    90a6:	e9 c1 fd ff ff       	jmp    8e6c <fwp_write+0x88c>
    90ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90b0:	31 c0                	xor    %eax,%eax
    90b2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    90b9:	00 
    90ba:	0f 97 c0             	seta   %al
    90bd:	e9 aa fd ff ff       	jmp    8e6c <fwp_write+0x88c>
    90c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90c8:	48 89 df             	mov    %rbx,%rdi
    90cb:	ba 02 00 00 00       	mov    $0x2,%edx
    90d0:	48 8d 35 88 21 00 00 	lea    0x2188(%rip),%rsi        # b25f <_IO_stdin_used+0x25f>
    90d7:	e8 f4 af ff ff       	call   40d0 <buf_put>
    90dc:	4c 89 e8             	mov    %r13,%rax
    90df:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    90e4:	31 c9                	xor    %ecx,%ecx
    90e6:	48 c1 e0 04          	shl    $0x4,%rax
    90ea:	48 89 df             	mov    %rbx,%rdi
    90ed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    90f2:	e8 e9 f4 ff ff       	call   85e0 <fwp_write>
    90f7:	e9 5e f6 ff ff       	jmp    875a <fwp_write+0x17a>
    90fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9100:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9105:	48 85 ff             	test   %rdi,%rdi
    9108:	79 0c                	jns    9116 <fwp_write+0xb36>
    910a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9111:	00 
    9112:	48 03 75 10          	add    0x10(%rbp),%rsi
    9116:	48 63 3e             	movslq (%rsi),%rdi
    9119:	83 f9 02             	cmp    $0x2,%ecx
    911c:	89 fe                	mov    %edi,%esi
    911e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9122:	e9 f9 fb ff ff       	jmp    8d20 <fwp_write+0x740>
    9127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    912e:	00 00 
    9130:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9135:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    913a:	48 85 ff             	test   %rdi,%rdi
    913d:	0f 88 0f 03 00 00    	js     9452 <fwp_write+0xe72>
    9143:	49 0f bf 38          	movswq (%r8),%rdi
    9147:	83 f9 01             	cmp    $0x1,%ecx
    914a:	0f b7 f7             	movzwl %di,%esi
    914d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9151:	e9 ca fb ff ff       	jmp    8d20 <fwp_write+0x740>
    9156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    915d:	00 00 00 
    9160:	ba 01 00 00 00       	mov    $0x1,%edx
    9165:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    916a:	48 83 c5 08          	add    $0x8,%rbp
    916e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9173:	e8 58 af ff ff       	call   40d0 <buf_put>
    9178:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    917d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9182:	4d 85 ed             	test   %r13,%r13
    9185:	75 46                	jne    91cd <fwp_write+0xbed>
    9187:	e9 04 01 00 00       	jmp    9290 <fwp_write+0xcb0>
    918c:	0f 1f 40 00          	nopl   0x0(%rax)
    9190:	41 80 f9 09          	cmp    $0x9,%r9b
    9194:	0f 84 d6 00 00 00    	je     9270 <fwp_write+0xc90>
    919a:	41 80 f9 0a          	cmp    $0xa,%r9b
    919e:	0f 85 9c 00 00 00    	jne    9240 <fwp_write+0xc60>
    91a4:	ba 02 00 00 00       	mov    $0x2,%edx
    91a9:	48 8d 35 8b 20 00 00 	lea    0x208b(%rip),%rsi        # b23b <_IO_stdin_used+0x23b>
    91b0:	48 89 df             	mov    %rbx,%rdi
    91b3:	e8 18 af ff ff       	call   40d0 <buf_put>
    91b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91bf:	00 
    91c0:	48 83 c5 01          	add    $0x1,%rbp
    91c4:	49 39 ec             	cmp    %rbp,%r12
    91c7:	0f 84 c3 00 00 00    	je     9290 <fwp_write+0xcb0>
    91cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    91d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    91d6:	74 28                	je     9200 <fwp_write+0xc20>
    91d8:	7e b6                	jle    9190 <fwp_write+0xbb0>
    91da:	41 80 f9 22          	cmp    $0x22,%r9b
    91de:	74 40                	je     9220 <fwp_write+0xc40>
    91e0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    91e4:	75 5a                	jne    9240 <fwp_write+0xc60>
    91e6:	ba 02 00 00 00       	mov    $0x2,%edx
    91eb:	48 8d 35 46 20 00 00 	lea    0x2046(%rip),%rsi        # b238 <_IO_stdin_used+0x238>
    91f2:	48 89 df             	mov    %rbx,%rdi
    91f5:	e8 d6 ae ff ff       	call   40d0 <buf_put>
    91fa:	eb c4                	jmp    91c0 <fwp_write+0xbe0>
    91fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9200:	ba 02 00 00 00       	mov    $0x2,%edx
    9205:	48 8d 35 35 20 00 00 	lea    0x2035(%rip),%rsi        # b241 <_IO_stdin_used+0x241>
    920c:	48 89 df             	mov    %rbx,%rdi
    920f:	e8 bc ae ff ff       	call   40d0 <buf_put>
    9214:	eb aa                	jmp    91c0 <fwp_write+0xbe0>
    9216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    921d:	00 00 00 
    9220:	ba 02 00 00 00       	mov    $0x2,%edx
    9225:	48 8d 35 09 20 00 00 	lea    0x2009(%rip),%rsi        # b235 <_IO_stdin_used+0x235>
    922c:	48 89 df             	mov    %rbx,%rdi
    922f:	e8 9c ae ff ff       	call   40d0 <buf_put>
    9234:	eb 8a                	jmp    91c0 <fwp_write+0xbe0>
    9236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    923d:	00 00 00 
    9240:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9244:	0f 86 2e 01 00 00    	jbe    9378 <fwp_write+0xd98>
    924a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    924e:	0f 84 24 01 00 00    	je     9378 <fwp_write+0xd98>
    9254:	ba 01 00 00 00       	mov    $0x1,%edx
    9259:	4c 89 fe             	mov    %r15,%rsi
    925c:	48 89 df             	mov    %rbx,%rdi
    925f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9264:	e8 67 ae ff ff       	call   40d0 <buf_put>
    9269:	e9 52 ff ff ff       	jmp    91c0 <fwp_write+0xbe0>
    926e:	66 90                	xchg   %ax,%ax
    9270:	ba 02 00 00 00       	mov    $0x2,%edx
    9275:	48 8d 35 c2 1f 00 00 	lea    0x1fc2(%rip),%rsi        # b23e <_IO_stdin_used+0x23e>
    927c:	48 89 df             	mov    %rbx,%rdi
    927f:	e8 4c ae ff ff       	call   40d0 <buf_put>
    9284:	e9 37 ff ff ff       	jmp    91c0 <fwp_write+0xbe0>
    9289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9290:	ba 01 00 00 00       	mov    $0x1,%edx
    9295:	4c 89 fe             	mov    %r15,%rsi
    9298:	48 89 df             	mov    %rbx,%rdi
    929b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    92a0:	e8 2b ae ff ff       	call   40d0 <buf_put>
    92a5:	e9 cc f3 ff ff       	jmp    8676 <fwp_write+0x96>
    92aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92b0:	83 f8 04             	cmp    $0x4,%eax
    92b3:	0f 85 bb fb ff ff    	jne    8e74 <fwp_write+0x894>
    92b9:	48 8b 04 24          	mov    (%rsp),%rax
    92bd:	48 8b 40 08          	mov    0x8(%rax),%rax
    92c1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    92c6:	48 c1 e8 3f          	shr    $0x3f,%rax
    92ca:	e9 96 fc ff ff       	jmp    8f65 <fwp_write+0x985>
    92cf:	90                   	nop
    92d0:	8b 0c 24             	mov    (%rsp),%ecx
    92d3:	31 c0                	xor    %eax,%eax
    92d5:	85 c9                	test   %ecx,%ecx
    92d7:	0f 98 c0             	sets   %al
    92da:	e9 86 fc ff ff       	jmp    8f65 <fwp_write+0x985>
    92df:	90                   	nop
    92e0:	48 f7 d8             	neg    %rax
    92e3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    92ea:	00 
    92eb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    92f2:	2d 
    92f3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92fa:	00 
    92fb:	48 83 d2 00          	adc    $0x0,%rdx
    92ff:	48 89 c6             	mov    %rax,%rsi
    9302:	48 f7 da             	neg    %rdx
    9305:	e8 16 a7 ff ff       	call   3a20 <fwp_fmt_u128>
    930a:	e9 51 f3 ff ff       	jmp    8660 <fwp_write+0x80>
    930f:	90                   	nop
    9310:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9315:	e9 c3 f5 ff ff       	jmp    88dd <fwp_write+0x2fd>
    931a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9320:	4c 89 e9             	mov    %r13,%rcx
    9323:	48 c1 e1 04          	shl    $0x4,%rcx
    9327:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    932c:	48 85 ff             	test   %rdi,%rdi
    932f:	0f 89 eb f9 ff ff    	jns    8d20 <fwp_write+0x740>
    9335:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9339:	48 89 ce             	mov    %rcx,%rsi
    933c:	e9 df f9 ff ff       	jmp    8d20 <fwp_write+0x740>
    9341:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9348:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    934f:	00 
    9350:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9354:	e9 20 fa ff ff       	jmp    8d79 <fwp_write+0x799>
    9359:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9360:	ba 02 00 00 00       	mov    $0x2,%edx
    9365:	48 8d 35 94 1e 00 00 	lea    0x1e94(%rip),%rsi        # b200 <_IO_stdin_used+0x200>
    936c:	e9 2d f7 ff ff       	jmp    8a9e <fwp_write+0x4be>
    9371:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9378:	4c 8d 05 c5 1e 00 00 	lea    0x1ec5(%rip),%r8        # b244 <_IO_stdin_used+0x244>
    937f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9384:	31 c0                	xor    %eax,%eax
    9386:	ba 02 00 00 00       	mov    $0x2,%edx
    938b:	be 10 00 00 00       	mov    $0x10,%esi
    9390:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9397:	00 
    9398:	e8 03 a0 ff ff       	call   33a0 <__snprintf_chk@plt>
    939d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93a4:	00 
    93a5:	e8 96 a0 ff ff       	call   3440 <strlen@plt>
    93aa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    93b1:	00 
    93b2:	48 89 df             	mov    %rbx,%rdi
    93b5:	48 89 c2             	mov    %rax,%rdx
    93b8:	e8 13 ad ff ff       	call   40d0 <buf_put>
    93bd:	e9 fe fd ff ff       	jmp    91c0 <fwp_write+0xbe0>
    93c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93cc:	48 8d 35 27 1e 00 00 	lea    0x1e27(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    93d3:	48 8d 05 1f 1e 00 00 	lea    0x1e1f(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    93da:	4c 89 e7             	mov    %r12,%rdi
    93dd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    93e1:	48 0f 46 f0          	cmovbe %rax,%rsi
    93e5:	e8 f6 9f ff ff       	call   33e0 <strcpy@plt>
    93ea:	e9 71 f2 ff ff       	jmp    8660 <fwp_write+0x80>
    93ef:	90                   	nop
    93f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93f4:	48 8d 35 ff 1d 00 00 	lea    0x1dff(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    93fb:	48 8d 05 f7 1d 00 00 	lea    0x1df7(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    9402:	0f 2f c8             	comiss %xmm0,%xmm1
    9405:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    940c:	00 
    940d:	4c 89 e7             	mov    %r12,%rdi
    9410:	48 0f 46 f0          	cmovbe %rax,%rsi
    9414:	e8 c7 9f ff ff       	call   33e0 <strcpy@plt>
    9419:	e9 42 f2 ff ff       	jmp    8660 <fwp_write+0x80>
    941e:	66 90                	xchg   %ax,%ax
    9420:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9425:	45 85 c0             	test   %r8d,%r8d
    9428:	75 34                	jne    945e <fwp_write+0xe7e>
    942a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9431:	00 
    9432:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9439:	00 00 
    943b:	0f 85 74 f6 ff ff    	jne    8ab5 <fwp_write+0x4d5>
    9441:	ba 02 00 00 00       	mov    $0x2,%edx
    9446:	48 8d 35 28 1e 00 00 	lea    0x1e28(%rip),%rsi        # b275 <_IO_stdin_used+0x275>
    944d:	e9 a1 f3 ff ff       	jmp    87f3 <fwp_write+0x213>
    9452:	48 03 75 10          	add    0x10(%rbp),%rsi
    9456:	49 89 f0             	mov    %rsi,%r8
    9459:	e9 e5 fc ff ff       	jmp    9143 <fwp_write+0xb63>
    945e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9463:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9468:	85 ff                	test   %edi,%edi
    946a:	0f 84 fa f3 ff ff    	je     886a <fwp_write+0x28a>
    9470:	ba 01 00 00 00       	mov    $0x1,%edx
    9475:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    947a:	48 89 df             	mov    %rbx,%rdi
    947d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9482:	e8 49 ac ff ff       	call   40d0 <buf_put>
    9487:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    948c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9491:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9497:	85 c0                	test   %eax,%eax
    9499:	0f 8f f0 f3 ff ff    	jg     888f <fwp_write+0x2af>
    949f:	e9 34 f4 ff ff       	jmp    88d8 <fwp_write+0x2f8>
    94a4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    94a8:	49 89 c5             	mov    %rax,%r13
    94ab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    94b0:	49 89 c4             	mov    %rax,%r12
    94b3:	49 c1 fd 3f          	sar    $0x3f,%r13
    94b7:	4c 09 e8             	or     %r13,%rax
    94ba:	0f 84 a7 00 00 00    	je     9567 <fwp_write+0xf87>
    94c0:	48 8d 2d f9 3d 00 00 	lea    0x3df9(%rip),%rbp        # d2c0 <units.0>
    94c7:	4d 89 e7             	mov    %r12,%r15
    94ca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    94ce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    94d3:	4c 89 ff             	mov    %r15,%rdi
    94d6:	4c 89 ee             	mov    %r13,%rsi
    94d9:	44 89 0c 24          	mov    %r9d,(%rsp)
    94dd:	48 99                	cqto
    94df:	48 89 d1             	mov    %rdx,%rcx
    94e2:	48 89 c2             	mov    %rax,%rdx
    94e5:	e8 56 10 00 00       	call   a540 <__divmodti4>
    94ea:	44 8b 0c 24          	mov    (%rsp),%r9d
    94ee:	48 89 c1             	mov    %rax,%rcx
    94f1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    94f6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    94fb:	0f 84 94 00 00 00    	je     9595 <fwp_write+0xfb5>
    9501:	41 83 c1 01          	add    $0x1,%r9d
    9505:	48 83 c5 10          	add    $0x10,%rbp
    9509:	41 83 f9 05          	cmp    $0x5,%r9d
    950d:	75 bb                	jne    94ca <fwp_write+0xeea>
    950f:	4d 85 ed             	test   %r13,%r13
    9512:	79 53                	jns    9567 <fwp_write+0xf87>
    9514:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9519:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    951e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9523:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9528:	48 99                	cqto
    952a:	48 f7 d8             	neg    %rax
    952d:	48 83 d2 00          	adc    $0x0,%rdx
    9531:	48 89 c6             	mov    %rax,%rsi
    9534:	48 f7 da             	neg    %rdx
    9537:	e8 e4 a4 ff ff       	call   3a20 <fwp_fmt_u128>
    953c:	49 89 e8             	mov    %rbp,%r8
    953f:	ba 00 02 00 00       	mov    $0x200,%edx
    9544:	be 02 00 00 00       	mov    $0x2,%esi
    9549:	31 c0                	xor    %eax,%eax
    954b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9552:	00 
    9553:	48 8d 0d 16 1d 00 00 	lea    0x1d16(%rip),%rcx        # b270 <_IO_stdin_used+0x270>
    955a:	4c 89 e7             	mov    %r12,%rdi
    955d:	e8 5e a1 ff ff       	call   36c0 <__sprintf_chk@plt>
    9562:	e9 f9 f0 ff ff       	jmp    8660 <fwp_write+0x80>
    9567:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    956c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9571:	31 d2                	xor    %edx,%edx
    9573:	48 89 ef             	mov    %rbp,%rdi
    9576:	e8 a5 a4 ff ff       	call   3a20 <fwp_fmt_u128>
    957b:	eb bf                	jmp    953c <fwp_write+0xf5c>
    957d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9584:	4e 61 4e 00 
    9588:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    958f:	00 
    9590:	e9 cb f0 ff ff       	jmp    8660 <fwp_write+0x80>
    9595:	44 89 0c 24          	mov    %r9d,(%rsp)
    9599:	48 89 c8             	mov    %rcx,%rax
    959c:	48 85 d2             	test   %rdx,%rdx
    959f:	78 51                	js     95f2 <fwp_write+0x1012>
    95a1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95a6:	48 89 c6             	mov    %rax,%rsi
    95a9:	48 89 ef             	mov    %rbp,%rdi
    95ac:	e8 6f a4 ff ff       	call   3a20 <fwp_fmt_u128>
    95b1:	44 8b 0c 24          	mov    (%rsp),%r9d
    95b5:	49 63 c1             	movslq %r9d,%rax
    95b8:	49 89 e8             	mov    %rbp,%r8
    95bb:	ba 00 02 00 00       	mov    $0x200,%edx
    95c0:	be 02 00 00 00       	mov    $0x2,%esi
    95c5:	48 c1 e0 04          	shl    $0x4,%rax
    95c9:	48 8d 3d f0 3c 00 00 	lea    0x3cf0(%rip),%rdi        # d2c0 <units.0>
    95d0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95d7:	00 
    95d8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    95dc:	48 8d 0d 88 1c 00 00 	lea    0x1c88(%rip),%rcx        # b26b <_IO_stdin_used+0x26b>
    95e3:	4c 89 e7             	mov    %r12,%rdi
    95e6:	31 c0                	xor    %eax,%eax
    95e8:	e8 d3 a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    95ed:	e9 6e f0 ff ff       	jmp    8660 <fwp_write+0x80>
    95f2:	48 f7 d8             	neg    %rax
    95f5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95fa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95ff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9604:	48 83 d2 00          	adc    $0x0,%rdx
    9608:	48 89 c6             	mov    %rax,%rsi
    960b:	48 f7 da             	neg    %rdx
    960e:	e8 0d a4 ff ff       	call   3a20 <fwp_fmt_u128>
    9613:	44 8b 0c 24          	mov    (%rsp),%r9d
    9617:	eb 9c                	jmp    95b5 <fwp_write+0xfd5>
    9619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009620 <fwp_main_thread>:
    9620:	f3 0f 1e fa          	endbr64
    9624:	41 57                	push   %r15
    9626:	41 56                	push   %r14
    9628:	41 55                	push   %r13
    962a:	41 54                	push   %r12
    962c:	55                   	push   %rbp
    962d:	53                   	push   %rbx
    962e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9635:	8b 3d 89 f5 05 00    	mov    0x5f589(%rip),%edi        # 68bc4 <fwp_heap+0x13a4>
    963b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9642:	00 00 
    9644:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    964b:	00 
    964c:	31 c0                	xor    %eax,%eax
    964e:	85 ff                	test   %edi,%edi
    9650:	0f 84 72 07 00 00    	je     9dc8 <fwp_main_thread+0x7a8>
    9656:	8b 35 6c f5 05 00    	mov    0x5f56c(%rip),%esi        # 68bc8 <fwp_heap+0x13a8>
    965c:	85 f6                	test   %esi,%esi
    965e:	0f 85 4c 07 00 00    	jne    9db0 <fwp_main_thread+0x790>
    9664:	48 8d 05 15 5a 00 00 	lea    0x5a15(%rip),%rax        # f080 <alt.5>
    966b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9670:	31 f6                	xor    %esi,%esi
    9672:	48 c7 05 43 db 05 00 	movq   $0x40000000,0x5db43(%rip)        # 671c0 <fwp_main_stack_size>
    9679:	00 00 00 40 
    967d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9682:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9687:	48 89 c7             	mov    %rax,%rdi
    968a:	48 89 2d 37 db 05 00 	mov    %rbp,0x5db37(%rip)        # 671c8 <fwp_main_stack_top>
    9691:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9698:	01 00 
    969a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    96a1:	00 
    96a2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    96a7:	e8 f4 9f ff ff       	call   36a0 <sigaltstack@plt>
    96ac:	85 c0                	test   %eax,%eax
    96ae:	0f 85 43 0e 00 00    	jne    a4f7 <fwp_main_thread+0xed7>
    96b4:	31 c0                	xor    %eax,%eax
    96b6:	b9 12 00 00 00       	mov    $0x12,%ecx
    96bb:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    96c2:	00 
    96c3:	f3 48 ab             	rep stos %rax,(%rdi)
    96c6:	48 8d 05 53 a6 ff ff 	lea    -0x59ad(%rip),%rax        # 3d20 <fwp_segv>
    96cd:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    96d4:	00 
    96d5:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    96dc:	04 00 00 08 
    96e0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    96e7:	00 
    96e8:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    96ef:	00 
    96f0:	e8 6b 9e ff ff       	call   3560 <sigemptyset@plt>
    96f5:	85 c0                	test   %eax,%eax
    96f7:	0f 85 fa 0d 00 00    	jne    a4f7 <fwp_main_thread+0xed7>
    96fd:	31 d2                	xor    %edx,%edx
    96ff:	48 89 de             	mov    %rbx,%rsi
    9702:	bf 0b 00 00 00       	mov    $0xb,%edi
    9707:	e8 e4 9c ff ff       	call   33f0 <sigaction@plt>
    970c:	85 c0                	test   %eax,%eax
    970e:	0f 85 e3 0d 00 00    	jne    a4f7 <fwp_main_thread+0xed7>
    9714:	31 d2                	xor    %edx,%edx
    9716:	48 89 de             	mov    %rbx,%rsi
    9719:	bf 07 00 00 00       	mov    $0x7,%edi
    971e:	e8 cd 9c ff ff       	call   33f0 <sigaction@plt>
    9723:	85 c0                	test   %eax,%eax
    9725:	0f 85 cc 0d 00 00    	jne    a4f7 <fwp_main_thread+0xed7>
    972b:	48 8b 05 0e f5 05 00 	mov    0x5f50e(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9732:	48 85 c0             	test   %rax,%rax
    9735:	0f 88 35 06 00 00    	js     9d70 <fwp_main_thread+0x750>
    973b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    973f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9744:	48 8d 3d b5 aa ff ff 	lea    -0x554b(%rip),%rdi        # 4200 <ad_raw_report>
    974b:	f2 0f 11 05 75 fd 05 	movsd  %xmm0,0x5fd75(%rip)        # 694c8 <iteration_start_charge>
    9752:	00 
    9753:	c7 05 8b fd 05 00 01 	movl   $0x1,0x5fd8b(%rip)        # 694e8 <iteration_active>
    975a:	00 00 00 
    975d:	e8 ee 0f 00 00       	call   a750 <atexit>
    9762:	85 c0                	test   %eax,%eax
    9764:	0f 85 aa 0d 00 00    	jne    a514 <fwp_main_thread+0xef4>
    976a:	8b 0d f8 58 00 00    	mov    0x58f8(%rip),%ecx        # f068 <st.3>
    9770:	85 c9                	test   %ecx,%ecx
    9772:	0f 84 60 06 00 00    	je     9dd8 <fwp_main_thread+0x7b8>
    9778:	48 8b 2d 81 e0 05 00 	mov    0x5e081(%rip),%rbp        # 67800 <fwp_cur>
    977f:	48 85 ed             	test   %rbp,%rbp
    9782:	0f 84 08 03 00 00    	je     9a90 <fwp_main_thread+0x470>
    9788:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    978d:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9791:	48 89 eb             	mov    %rbp,%rbx
    9794:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9799:	0f 84 41 01 00 00    	je     98e0 <fwp_main_thread+0x2c0>
    979f:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    97a4:	0f 84 16 02 00 00    	je     99c0 <fwp_main_thread+0x3a0>
    97aa:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    97ae:	0f 84 fc 01 00 00    	je     99b0 <fwp_main_thread+0x390>
    97b4:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    97b8:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    97bc:	0f 85 7e 02 00 00    	jne    9a40 <fwp_main_thread+0x420>
    97c2:	48 8b 43 60          	mov    0x60(%rbx),%rax
    97c6:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    97cd:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    97d1:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    97d8:	00 00 00 00 
    97dc:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    97e3:	48 85 d2             	test   %rdx,%rdx
    97e6:	74 07                	je     97ef <fwp_main_thread+0x1cf>
    97e8:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    97ef:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    97f3:	48 85 c0             	test   %rax,%rax
    97f6:	74 34                	je     982c <fwp_main_thread+0x20c>
    97f8:	48 89 43 68          	mov    %rax,0x68(%rbx)
    97fc:	48 8b 05 d5 df 05 00 	mov    0x5dfd5(%rip),%rax        # 677d8 <fwp_timers>
    9803:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9807:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    980e:	00 00 00 00 
    9812:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9819:	48 85 c0             	test   %rax,%rax
    981c:	74 07                	je     9825 <fwp_main_thread+0x205>
    981e:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9825:	48 89 1d ac df 05 00 	mov    %rbx,0x5dfac(%rip)        # 677d8 <fwp_timers>
    982c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9830:	e8 1b de ff ff       	call   7650 <fwp_block>
    9835:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    983c:	48 85 c9             	test   %rcx,%rcx
    983f:	74 47                	je     9888 <fwp_main_thread+0x268>
    9841:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9848:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    984f:	48 85 d2             	test   %rdx,%rdx
    9852:	0f 84 28 02 00 00    	je     9a80 <fwp_main_thread+0x460>
    9858:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    985f:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9866:	48 85 c0             	test   %rax,%rax
    9869:	74 07                	je     9872 <fwp_main_thread+0x252>
    986b:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9872:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9879:	00 00 00 00 
    987d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9881:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9888:	48 8b 0d 71 df 05 00 	mov    0x5df71(%rip),%rcx        # 67800 <fwp_cur>
    988f:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9893:	0f 84 97 01 00 00    	je     9a30 <fwp_main_thread+0x410>
    9899:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    98a0:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    98a7:	48 85 d2             	test   %rdx,%rdx
    98aa:	0f 84 20 04 00 00    	je     9cd0 <fwp_main_thread+0x6b0>
    98b0:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    98b7:	48 85 c0             	test   %rax,%rax
    98ba:	74 07                	je     98c3 <fwp_main_thread+0x2a3>
    98bc:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    98c3:	66 0f ef db          	pxor   %xmm3,%xmm3
    98c7:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    98cb:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    98d2:	48 89 cb             	mov    %rcx,%rbx
    98d5:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    98da:	0f 85 bf fe ff ff    	jne    979f <fwp_main_thread+0x17f>
    98e0:	48 83 3d b0 fb 05 00 	cmpq   $0x0,0x5fbb0(%rip)        # 69498 <fwp_state_len>
    98e7:	00 
    98e8:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    98ec:	0f 84 10 04 00 00    	je     9d02 <fwp_main_thread+0x6e2>
    98f2:	48 39 1d ff de 05 00 	cmp    %rbx,0x5deff(%rip)        # 677f8 <fwp_root>
    98f9:	c7 05 7d 57 01 00 00 	movl   $0x0,0x1577d(%rip)        # 1f080 <fwp_exit_code>
    9900:	00 00 00 
    9903:	0f 85 28 0c 00 00    	jne    a531 <fwp_main_thread+0xf11>
    9909:	48 85 db             	test   %rbx,%rbx
    990c:	0f 84 a4 01 00 00    	je     9ab6 <fwp_main_thread+0x496>
    9912:	48 8b 15 af de 05 00 	mov    0x5deaf(%rip),%rdx        # 677c8 <fwp_tasks_active>
    9919:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    991d:	48 85 d2             	test   %rdx,%rdx
    9920:	0f 84 90 01 00 00    	je     9ab6 <fwp_main_thread+0x496>
    9926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    992d:	00 00 00 
    9930:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9934:	75 08                	jne    993e <fwp_main_thread+0x31e>
    9936:	48 89 d7             	mov    %rdx,%rdi
    9939:	e8 d2 a7 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    993e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9945:	48 85 d2             	test   %rdx,%rdx
    9948:	75 e6                	jne    9930 <fwp_main_thread+0x310>
    994a:	eb 31                	jmp    997d <fwp_main_thread+0x35d>
    994c:	0f 1f 40 00          	nopl   0x0(%rax)
    9950:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9957:	48 89 1d 82 de 05 00 	mov    %rbx,0x5de82(%rip)        # 677e0 <fwp_ready_tail>
    995e:	e8 ed dc ff ff       	call   7650 <fwp_block>
    9963:	e8 d8 da ff ff       	call   7440 <fwp_free_zombie>
    9968:	48 83 3d 58 de 05 00 	cmpq   $0x0,0x5de58(%rip)        # 677c8 <fwp_tasks_active>
    996f:	00 
    9970:	0f 84 40 01 00 00    	je     9ab6 <fwp_main_thread+0x496>
    9976:	48 8b 1d 7b de 05 00 	mov    0x5de7b(%rip),%rbx        # 677f8 <fwp_root>
    997d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9981:	75 db                	jne    995e <fwp_main_thread+0x33e>
    9983:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9987:	75 d5                	jne    995e <fwp_main_thread+0x33e>
    9989:	48 8b 05 50 de 05 00 	mov    0x5de50(%rip),%rax        # 677e0 <fwp_ready_tail>
    9990:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9994:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    999b:	00 00 00 00 
    999f:	48 85 c0             	test   %rax,%rax
    99a2:	75 ac                	jne    9950 <fwp_main_thread+0x330>
    99a4:	48 89 1d 3d de 05 00 	mov    %rbx,0x5de3d(%rip)        # 677e8 <fwp_ready_head>
    99ab:	eb aa                	jmp    9957 <fwp_main_thread+0x337>
    99ad:	0f 1f 00             	nopl   (%rax)
    99b0:	e8 eb ab ff ff       	call   45a0 <fwp_now_ns>
    99b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    99b9:	0f 8d 21 03 00 00    	jge    9ce0 <fwp_main_thread+0x6c0>
    99bf:	90                   	nop
    99c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    99c4:	0f 85 ea fd ff ff    	jne    97b4 <fwp_main_thread+0x194>
    99ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    99ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    99d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    99d6:	0f 85 ea fd ff ff    	jne    97c6 <fwp_main_thread+0x1a6>
    99dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    99e0:	48 85 c9             	test   %rcx,%rcx
    99e3:	0f 84 dd fd ff ff    	je     97c6 <fwp_main_thread+0x1a6>
    99e9:	48 39 c8             	cmp    %rcx,%rax
    99ec:	48 89 ce             	mov    %rcx,%rsi
    99ef:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    99f6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    99fa:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9a01:	00 00 00 00 
    9a05:	48 0f 4e f0          	cmovle %rax,%rsi
    9a09:	48 85 c0             	test   %rax,%rax
    9a0c:	48 89 c8             	mov    %rcx,%rax
    9a0f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9a16:	48 0f 45 c6          	cmovne %rsi,%rax
    9a1a:	48 85 d2             	test   %rdx,%rdx
    9a1d:	74 07                	je     9a26 <fwp_main_thread+0x406>
    9a1f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9a26:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9a2a:	e9 c9 fd ff ff       	jmp    97f8 <fwp_main_thread+0x1d8>
    9a2f:	90                   	nop
    9a30:	48 89 cb             	mov    %rcx,%rbx
    9a33:	e9 5c fd ff ff       	jmp    9794 <fwp_main_thread+0x174>
    9a38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a3f:	00 
    9a40:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9a44:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9a4b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9a52:	00 00 00 00 
    9a56:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9a5d:	48 85 c0             	test   %rax,%rax
    9a60:	0f 84 6a 09 00 00    	je     a3d0 <fwp_main_thread+0xdb0>
    9a66:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9a6d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9a71:	e9 b6 fd ff ff       	jmp    982c <fwp_main_thread+0x20c>
    9a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a7d:	00 00 00 
    9a80:	48 89 01             	mov    %rax,(%rcx)
    9a83:	e9 de fd ff ff       	jmp    9866 <fwp_main_thread+0x246>
    9a88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a8f:	00 
    9a90:	48 83 3d 00 fa 05 00 	cmpq   $0x0,0x5fa00(%rip)        # 69498 <fwp_state_len>
    9a97:	00 
    9a98:	0f 84 62 02 00 00    	je     9d00 <fwp_main_thread+0x6e0>
    9a9e:	48 83 3d 52 dd 05 00 	cmpq   $0x0,0x5dd52(%rip)        # 677f8 <fwp_root>
    9aa5:	00 
    9aa6:	c7 05 d0 55 01 00 00 	movl   $0x0,0x155d0(%rip)        # 1f080 <fwp_exit_code>
    9aad:	00 00 00 
    9ab0:	0f 85 76 0a 00 00    	jne    a52c <fwp_main_thread+0xf0c>
    9ab6:	e8 85 d9 ff ff       	call   7440 <fwp_free_zombie>
    9abb:	48 83 3d 25 dd 05 00 	cmpq   $0x0,0x5dd25(%rip)        # 677e8 <fwp_ready_head>
    9ac2:	00 
    9ac3:	0f 85 62 9c ff ff    	jne    372b <fwp_main_thread.cold>
    9ac9:	48 83 3d 07 dd 05 00 	cmpq   $0x0,0x5dd07(%rip)        # 677d8 <fwp_timers>
    9ad0:	00 
    9ad1:	0f 85 54 9c ff ff    	jne    372b <fwp_main_thread.cold>
    9ad7:	8b 05 f7 d6 05 00    	mov    0x5d6f7(%rip),%eax        # 671d4 <fwp_stack_pool_n>
    9add:	85 c0                	test   %eax,%eax
    9adf:	74 3c                	je     9b1d <fwp_main_thread+0x4fd>
    9ae1:	83 e8 01             	sub    $0x1,%eax
    9ae4:	4c 8d 25 f5 d6 05 00 	lea    0x5d6f5(%rip),%r12        # 671e0 <fwp_stack_pool>
    9aeb:	48 63 d8             	movslq %eax,%rbx
    9aee:	89 c0                	mov    %eax,%eax
    9af0:	48 89 da             	mov    %rbx,%rdx
    9af3:	48 29 c2             	sub    %rax,%rdx
    9af6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b00:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9b04:	89 1d ca d6 05 00    	mov    %ebx,0x5d6ca(%rip)        # 671d4 <fwp_stack_pool_n>
    9b0a:	be 00 00 00 10       	mov    $0x10000000,%esi
    9b0f:	48 83 eb 01          	sub    $0x1,%rbx
    9b13:	e8 a8 9a ff ff       	call   35c0 <munmap@plt>
    9b18:	48 39 dd             	cmp    %rbx,%rbp
    9b1b:	75 e3                	jne    9b00 <fwp_main_thread+0x4e0>
    9b1d:	8b 3d ed 54 00 00    	mov    0x54ed(%rip),%edi        # f010 <fwp_epfd>
    9b23:	85 ff                	test   %edi,%edi
    9b25:	78 05                	js     9b2c <fwp_main_thread+0x50c>
    9b27:	e8 94 99 ff ff       	call   34c0 <close@plt>
    9b2c:	4c 8b 25 ad d8 05 00 	mov    0x5d8ad(%rip),%r12        # 673e0 <fwp_nfdws>
    9b33:	48 8b 2d ae d8 05 00 	mov    0x5d8ae(%rip),%rbp        # 673e8 <fwp_fdws>
    9b3a:	31 db                	xor    %ebx,%ebx
    9b3c:	c7 05 ca 54 00 00 ff 	movl   $0xffffffff,0x54ca(%rip)        # f010 <fwp_epfd>
    9b43:	ff ff ff 
    9b46:	4d 85 e4             	test   %r12,%r12
    9b49:	74 32                	je     9b7d <fwp_main_thread+0x55d>
    9b4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b50:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9b55:	48 85 ff             	test   %rdi,%rdi
    9b58:	74 1a                	je     9b74 <fwp_main_thread+0x554>
    9b5a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9b5e:	0f 85 c7 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b64:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9b69:	0f 85 bc 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9b6f:	e8 7c be ff ff       	call   59f0 <fwp_mem_free>
    9b74:	48 83 c3 01          	add    $0x1,%rbx
    9b78:	49 39 dc             	cmp    %rbx,%r12
    9b7b:	75 d3                	jne    9b50 <fwp_main_thread+0x530>
    9b7d:	48 89 ef             	mov    %rbp,%rdi
    9b80:	e8 6b be ff ff       	call   59f0 <fwp_mem_free>
    9b85:	48 8b 15 6c dc 05 00 	mov    0x5dc6c(%rip),%rdx        # 677f8 <fwp_root>
    9b8c:	48 c7 05 51 d8 05 00 	movq   $0x0,0x5d851(%rip)        # 673e8 <fwp_fdws>
    9b93:	00 00 00 00 
    9b97:	48 c7 05 3e d8 05 00 	movq   $0x0,0x5d83e(%rip)        # 673e0 <fwp_nfdws>
    9b9e:	00 00 00 00 
    9ba2:	48 85 d2             	test   %rdx,%rdx
    9ba5:	74 4e                	je     9bf5 <fwp_main_thread+0x5d5>
    9ba7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9bac:	0f 85 79 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9bb2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9bb9:	00 
    9bba:	0f 85 6b 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9bc0:	48 83 3d d0 f8 05 00 	cmpq   $0x0,0x5f8d0(%rip)        # 69498 <fwp_state_len>
    9bc7:	00 
    9bc8:	0f 85 5d 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9bce:	48 83 3d b2 f8 05 00 	cmpq   $0x0,0x5f8b2(%rip)        # 69488 <fwp_state_owners>
    9bd5:	00 
    9bd6:	0f 85 4f 9b ff ff    	jne    372b <fwp_main_thread.cold>
    9bdc:	b9 79 00 00 00       	mov    $0x79,%ecx
    9be1:	31 c0                	xor    %eax,%eax
    9be3:	48 8d 3d 16 d8 05 00 	lea    0x5d816(%rip),%rdi        # 67400 <fwp_root_context>
    9bea:	f3 48 ab             	rep stos %rax,(%rdi)
    9bed:	48 89 d7             	mov    %rdx,%rdi
    9bf0:	e8 fb bd ff ff       	call   59f0 <fwp_mem_free>
    9bf5:	66 0f 6f 05 b3 55 04 	movdqa 0x455b3(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    9bfc:	00 
    9bfd:	66 0f d4 05 9b 55 04 	paddq  0x4559b(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    9c04:	00 
    9c05:	48 c7 05 f0 db 05 00 	movq   $0x0,0x5dbf0(%rip)        # 67800 <fwp_cur>
    9c0c:	00 00 00 00 
    9c10:	48 8b 05 29 f0 05 00 	mov    0x5f029(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9c17:	48 c7 05 d6 db 05 00 	movq   $0x0,0x5dbd6(%rip)        # 677f8 <fwp_root>
    9c1e:	00 00 00 00 
    9c22:	c7 05 bc f8 05 00 00 	movl   $0x0,0x5f8bc(%rip)        # 694e8 <iteration_active>
    9c29:	00 00 00 
    9c2c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9c30:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9c35:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9c39:	66 0f d6 05 b7 54 01 	movq   %xmm0,0x154b7(%rip)        # 1f0f8 <ad_raw_before_shutdown>
    9c40:	00 
    9c41:	48 85 c0             	test   %rax,%rax
    9c44:	0f 88 46 01 00 00    	js     9d90 <fwp_main_thread+0x770>
    9c4a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9c4e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9c53:	f2 0f 5c 0d 6d f8 05 	subsd  0x5f86d(%rip),%xmm1        # 694c8 <iteration_start_charge>
    9c5a:	00 
    9c5b:	48 8b 3d de 53 00 00 	mov    0x53de(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    9c62:	48 8d 15 37 1e 00 00 	lea    0x1e37(%rip),%rdx        # baa0 <_IO_stdin_used+0xaa0>
    9c69:	be 02 00 00 00       	mov    $0x2,%esi
    9c6e:	f2 0f 10 05 4a f8 05 	movsd  0x5f84a(%rip),%xmm0        # 694c0 <iteration_peak>
    9c75:	00 
    9c76:	4c 8b 0d 53 f8 05 00 	mov    0x5f853(%rip),%r9        # 694d0 <iteration_retains>
    9c7d:	b8 02 00 00 00       	mov    $0x2,%eax
    9c82:	4c 8b 05 4f f8 05 00 	mov    0x5f84f(%rip),%r8        # 694d8 <iteration_bytes>
    9c89:	48 8b 0d 50 f8 05 00 	mov    0x5f850(%rip),%rcx        # 694e0 <iteration_requests>
    9c90:	e8 db 99 ff ff       	call   3670 <__fprintf_chk@plt>
    9c95:	48 8b 3d 84 53 00 00 	mov    0x5384(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    9c9c:	e8 ff 98 ff ff       	call   35a0 <fflush@plt>
    9ca1:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    9ca8:	00 
    9ca9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9cb0:	00 00 
    9cb2:	0f 85 57 08 00 00    	jne    a50f <fwp_main_thread+0xeef>
    9cb8:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9cbf:	31 c0                	xor    %eax,%eax
    9cc1:	5b                   	pop    %rbx
    9cc2:	5d                   	pop    %rbp
    9cc3:	41 5c                	pop    %r12
    9cc5:	41 5d                	pop    %r13
    9cc7:	41 5e                	pop    %r14
    9cc9:	41 5f                	pop    %r15
    9ccb:	c3                   	ret
    9ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    9cd0:	48 89 05 01 db 05 00 	mov    %rax,0x5db01(%rip)        # 677d8 <fwp_timers>
    9cd7:	e9 db fb ff ff       	jmp    98b7 <fwp_main_thread+0x297>
    9cdc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ce0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9ce4:	0f 85 d6 fc ff ff    	jne    99c0 <fwp_main_thread+0x3a0>
    9cea:	48 89 ef             	mov    %rbp,%rdi
    9ced:	e8 1e a4 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    9cf2:	e9 c9 fc ff ff       	jmp    99c0 <fwp_main_thread+0x3a0>
    9cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cfe:	00 00 
    9d00:	31 db                	xor    %ebx,%ebx
    9d02:	48 83 3d 7e f7 05 00 	cmpq   $0x0,0x5f77e(%rip)        # 69488 <fwp_state_owners>
    9d09:	00 
    9d0a:	0f 85 e2 fb ff ff    	jne    98f2 <fwp_main_thread+0x2d2>
    9d10:	48 8b 3d 89 f7 05 00 	mov    0x5f789(%rip),%rdi        # 694a0 <fwp_state>
    9d17:	e8 d4 bc ff ff       	call   59f0 <fwp_mem_free>
    9d1c:	48 c7 05 79 f7 05 00 	movq   $0x0,0x5f779(%rip)        # 694a0 <fwp_state>
    9d23:	00 00 00 00 
    9d27:	48 c7 05 5e f7 05 00 	movq   $0x0,0x5f75e(%rip)        # 69490 <fwp_state_cap>
    9d2e:	00 00 00 00 
    9d32:	48 85 db             	test   %rbx,%rbx
    9d35:	0f 84 6f 07 00 00    	je     a4aa <fwp_main_thread+0xe8a>
    9d3b:	48 3b 1d b6 da 05 00 	cmp    0x5dab6(%rip),%rbx        # 677f8 <fwp_root>
    9d42:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9d49:	00 00 00 00 
    9d4d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9d54:	00 00 00 00 
    9d58:	c7 05 1e 53 01 00 00 	movl   $0x0,0x1531e(%rip)        # 1f080 <fwp_exit_code>
    9d5f:	00 00 00 
    9d62:	0f 84 aa fb ff ff    	je     9912 <fwp_main_thread+0x2f2>
    9d68:	e9 be 99 ff ff       	jmp    372b <fwp_main_thread.cold>
    9d6d:	0f 1f 00             	nopl   (%rax)
    9d70:	48 89 c2             	mov    %rax,%rdx
    9d73:	83 e0 01             	and    $0x1,%eax
    9d76:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d7a:	48 d1 ea             	shr    $1,%rdx
    9d7d:	48 09 c2             	or     %rax,%rdx
    9d80:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9d85:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9d89:	e9 b6 f9 ff ff       	jmp    9744 <fwp_main_thread+0x124>
    9d8e:	66 90                	xchg   %ax,%ax
    9d90:	48 89 c2             	mov    %rax,%rdx
    9d93:	83 e0 01             	and    $0x1,%eax
    9d96:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9d9a:	48 d1 ea             	shr    $1,%rdx
    9d9d:	48 09 c2             	or     %rax,%rdx
    9da0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9da5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9da9:	e9 a5 fe ff ff       	jmp    9c53 <fwp_main_thread+0x633>
    9dae:	66 90                	xchg   %ax,%ax
    9db0:	48 8d 3d e9 ae ff ff 	lea    -0x5117(%rip),%rdi        # 4ca0 <fwp_heap_report>
    9db7:	e8 94 09 00 00       	call   a750 <atexit>
    9dbc:	e9 a3 f8 ff ff       	jmp    9664 <fwp_main_thread+0x44>
    9dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9dc8:	e8 e3 af ff ff       	call   4db0 <fwp_heap_init>
    9dcd:	e9 84 f8 ff ff       	jmp    9656 <fwp_main_thread+0x36>
    9dd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9dd8:	48 8d 05 d1 de ff ff 	lea    -0x212f(%rip),%rax        # 7cb0 <fwp_drop1>
    9ddf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9de3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    9dea:	00 00 
    9dec:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    9df2:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9df7:	48 8b 05 ba f6 05 00 	mov    0x5f6ba(%rip),%rax        # 694b8 <fwp_cleanups>
    9dfe:	4c 8d 3d 1b da 05 00 	lea    0x5da1b(%rip),%r15        # 67820 <fwp_heap>
    9e05:	48 89 2d ac f6 05 00 	mov    %rbp,0x5f6ac(%rip)        # 694b8 <fwp_cleanups>
    9e0c:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9e10:	31 ed                	xor    %ebp,%ebp
    9e12:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9e17:	48 8d 05 92 9d ff ff 	lea    -0x626e(%rip),%rax        # 3bb0 <fwp_range_release>
    9e1e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9e23:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9e28:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    9e2d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9e32:	eb 3d                	jmp    9e71 <fwp_main_thread+0x851>
    9e34:	0f 1f 40 00          	nopl   0x0(%rax)
    9e38:	80 f9 01             	cmp    $0x1,%cl
    9e3b:	75 29                	jne    9e66 <fwp_main_thread+0x846>
    9e3d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e40:	0f b7 c0             	movzwl %ax,%eax
    9e43:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e46:	48 0f af c1          	imul   %rcx,%rax
    9e4a:	48 c1 e8 20          	shr    $0x20,%rax
    9e4e:	48 39 d0             	cmp    %rdx,%rax
    9e51:	73 13                	jae    9e66 <fwp_main_thread+0x846>
    9e53:	49 01 c5             	add    %rax,%r13
    9e56:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9e5b:	0f 84 af 05 00 00    	je     a410 <fwp_main_thread+0xdf0>
    9e61:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9e66:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9e6b:	49 83 ec 01          	sub    $0x1,%r12
    9e6f:	72 7f                	jb     9ef0 <fwp_main_thread+0x8d0>
    9e71:	48 89 de             	mov    %rbx,%rsi
    9e74:	bf 01 00 00 00       	mov    $0x1,%edi
    9e79:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    9e80:	00 
    9e81:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9e86:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    9e8d:	00 
    9e8e:	e8 4d c2 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    9e93:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9e9a:	48 89 c5             	mov    %rax,%rbp
    9e9d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9ea4:	48 c1 e2 10          	shl    $0x10,%rdx
    9ea8:	48 39 d0             	cmp    %rdx,%rax
    9eab:	73 b9                	jae    9e66 <fwp_main_thread+0x846>
    9ead:	48 89 c2             	mov    %rax,%rdx
    9eb0:	48 c1 ea 10          	shr    $0x10,%rdx
    9eb4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9eb8:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9ebf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ec3:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9ec7:	4d 85 ed             	test   %r13,%r13
    9eca:	74 9a                	je     9e66 <fwp_main_thread+0x846>
    9ecc:	0f b6 0a             	movzbl (%rdx),%ecx
    9ecf:	80 f9 02             	cmp    $0x2,%cl
    9ed2:	0f 85 60 ff ff ff    	jne    9e38 <fwp_main_thread+0x818>
    9ed8:	66 85 c0             	test   %ax,%ax
    9edb:	0f 84 75 ff ff ff    	je     9e56 <fwp_main_thread+0x836>
    9ee1:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9ee6:	49 83 ec 01          	sub    $0x1,%r12
    9eea:	73 85                	jae    9e71 <fwp_main_thread+0x851>
    9eec:	0f 1f 40 00          	nopl   0x0(%rax)
    9ef0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9ef5:	66 0f 6f 05 13 1e 00 	movdqa 0x1e13(%rip),%xmm0        # bd10 <msg.4+0xa0>
    9efc:	00 
    9efd:	48 89 de             	mov    %rbx,%rsi
    9f00:	bf 01 00 00 00       	mov    $0x1,%edi
    9f05:	48 89 05 ac f5 05 00 	mov    %rax,0x5f5ac(%rip)        # 694b8 <fwp_cleanups>
    9f0c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9f13:	00 
    9f14:	e8 c7 c1 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    9f19:	48 8b 15 d8 ec 05 00 	mov    0x5ecd8(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    9f20:	49 89 c4             	mov    %rax,%r12
    9f23:	48 2b 05 a6 ec 05 00 	sub    0x5eca6(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    9f2a:	48 c1 e2 10          	shl    $0x10,%rdx
    9f2e:	48 39 d0             	cmp    %rdx,%rax
    9f31:	73 55                	jae    9f88 <fwp_main_thread+0x968>
    9f33:	48 89 c2             	mov    %rax,%rdx
    9f36:	48 c1 ea 10          	shr    $0x10,%rdx
    9f3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f3e:	48 8b 15 d3 ec 05 00 	mov    0x5ecd3(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    9f45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f49:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9f4d:	48 85 db             	test   %rbx,%rbx
    9f50:	74 36                	je     9f88 <fwp_main_thread+0x968>
    9f52:	0f b6 0a             	movzbl (%rdx),%ecx
    9f55:	80 f9 02             	cmp    $0x2,%cl
    9f58:	0f 84 a2 04 00 00    	je     a400 <fwp_main_thread+0xde0>
    9f5e:	80 f9 01             	cmp    $0x1,%cl
    9f61:	75 25                	jne    9f88 <fwp_main_thread+0x968>
    9f63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f66:	0f b7 c0             	movzwl %ax,%eax
    9f69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f6c:	48 0f af c1          	imul   %rcx,%rax
    9f70:	48 c1 e8 20          	shr    $0x20,%rax
    9f74:	48 39 d0             	cmp    %rdx,%rax
    9f77:	73 0f                	jae    9f88 <fwp_main_thread+0x968>
    9f79:	48 01 c3             	add    %rax,%rbx
    9f7c:	80 3b ff             	cmpb   $0xff,(%rbx)
    9f7f:	0f 84 4b 05 00 00    	je     a4d0 <fwp_main_thread+0xeb0>
    9f85:	c6 03 01             	movb   $0x1,(%rbx)
    9f88:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    9f8d:	bf 01 00 00 00       	mov    $0x1,%edi
    9f92:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9f97:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9f9e:	00 f0 3f 
    9fa1:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9fa6:	e8 35 c1 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    9fab:	48 8b 15 46 ec 05 00 	mov    0x5ec46(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    9fb2:	49 89 c4             	mov    %rax,%r12
    9fb5:	48 2b 05 14 ec 05 00 	sub    0x5ec14(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    9fbc:	48 c1 e2 10          	shl    $0x10,%rdx
    9fc0:	48 39 d0             	cmp    %rdx,%rax
    9fc3:	73 55                	jae    a01a <fwp_main_thread+0x9fa>
    9fc5:	48 89 c2             	mov    %rax,%rdx
    9fc8:	48 c1 ea 10          	shr    $0x10,%rdx
    9fcc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fd0:	48 8b 15 41 ec 05 00 	mov    0x5ec41(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    9fd7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fdb:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9fdf:	48 85 db             	test   %rbx,%rbx
    9fe2:	74 36                	je     a01a <fwp_main_thread+0x9fa>
    9fe4:	0f b6 0a             	movzbl (%rdx),%ecx
    9fe7:	80 f9 02             	cmp    $0x2,%cl
    9fea:	0f 84 00 04 00 00    	je     a3f0 <fwp_main_thread+0xdd0>
    9ff0:	80 f9 01             	cmp    $0x1,%cl
    9ff3:	75 25                	jne    a01a <fwp_main_thread+0x9fa>
    9ff5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ff8:	0f b7 c0             	movzwl %ax,%eax
    9ffb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ffe:	48 0f af c1          	imul   %rcx,%rax
    a002:	48 c1 e8 20          	shr    $0x20,%rax
    a006:	48 39 d0             	cmp    %rdx,%rax
    a009:	73 0f                	jae    a01a <fwp_main_thread+0x9fa>
    a00b:	48 01 c3             	add    %rax,%rbx
    a00e:	80 3b ff             	cmpb   $0xff,(%rbx)
    a011:	0f 84 c6 04 00 00    	je     a4dd <fwp_main_thread+0xebd>
    a017:	c6 03 01             	movb   $0x1,(%rbx)
    a01a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    a01f:	bf 01 00 00 00       	mov    $0x1,%edi
    a024:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    a029:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a030:	33 f3 bf 
    a033:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a038:	e8 a3 c0 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a03d:	48 8b 15 b4 eb 05 00 	mov    0x5ebb4(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a044:	48 8b 0d 85 eb 05 00 	mov    0x5eb85(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a04b:	49 89 c4             	mov    %rax,%r12
    a04e:	48 89 d6             	mov    %rdx,%rsi
    a051:	48 29 c8             	sub    %rcx,%rax
    a054:	48 c1 e6 10          	shl    $0x10,%rsi
    a058:	48 39 f0             	cmp    %rsi,%rax
    a05b:	73 65                	jae    a0c2 <fwp_main_thread+0xaa2>
    a05d:	48 89 c6             	mov    %rax,%rsi
    a060:	48 c1 ee 10          	shr    $0x10,%rsi
    a064:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a068:	48 8b 35 a9 eb 05 00 	mov    0x5eba9(%rip),%rsi        # 68c18 <fwp_heap+0x13f8>
    a06f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a073:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a077:	48 85 db             	test   %rbx,%rbx
    a07a:	74 46                	je     a0c2 <fwp_main_thread+0xaa2>
    a07c:	0f b6 3e             	movzbl (%rsi),%edi
    a07f:	40 80 ff 02          	cmp    $0x2,%dil
    a083:	0f 84 57 03 00 00    	je     a3e0 <fwp_main_thread+0xdc0>
    a089:	40 80 ff 01          	cmp    $0x1,%dil
    a08d:	75 33                	jne    a0c2 <fwp_main_thread+0xaa2>
    a08f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a092:	0f b7 c0             	movzwl %ax,%eax
    a095:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a098:	48 0f af c7          	imul   %rdi,%rax
    a09c:	48 c1 e8 20          	shr    $0x20,%rax
    a0a0:	48 39 f0             	cmp    %rsi,%rax
    a0a3:	73 1d                	jae    a0c2 <fwp_main_thread+0xaa2>
    a0a5:	48 01 c3             	add    %rax,%rbx
    a0a8:	80 3b ff             	cmpb   $0xff,(%rbx)
    a0ab:	0f 84 39 04 00 00    	je     a4ea <fwp_main_thread+0xeca>
    a0b1:	c6 03 01             	movb   $0x1,(%rbx)
    a0b4:	48 8b 0d 15 eb 05 00 	mov    0x5eb15(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a0bb:	48 8b 15 36 eb 05 00 	mov    0x5eb36(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a0c2:	49 89 ed             	mov    %rbp,%r13
    a0c5:	e9 13 02 00 00       	jmp    a2dd <fwp_main_thread+0xcbd>
    a0ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a0d0:	80 f9 01             	cmp    $0x1,%cl
    a0d3:	75 3f                	jne    a114 <fwp_main_thread+0xaf4>
    a0d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0d8:	0f b7 c0             	movzwl %ax,%eax
    a0db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0de:	48 0f af c1          	imul   %rcx,%rax
    a0e2:	48 c1 e8 20          	shr    $0x20,%rax
    a0e6:	48 39 d0             	cmp    %rdx,%rax
    a0e9:	73 29                	jae    a114 <fwp_main_thread+0xaf4>
    a0eb:	48 01 c7             	add    %rax,%rdi
    a0ee:	0f b6 07             	movzbl (%rdi),%eax
    a0f1:	84 c0                	test   %al,%al
    a0f3:	74 1f                	je     a114 <fwp_main_thread+0xaf4>
    a0f5:	8b 15 ed f3 05 00    	mov    0x5f3ed(%rip),%edx        # 694e8 <iteration_active>
    a0fb:	85 d2                	test   %edx,%edx
    a0fd:	74 08                	je     a107 <fwp_main_thread+0xae7>
    a0ff:	48 83 05 c9 f3 05 00 	addq   $0x1,0x5f3c9(%rip)        # 694d0 <iteration_retains>
    a106:	01 
    a107:	3c fd                	cmp    $0xfd,%al
    a109:	0f 87 91 03 00 00    	ja     a4a0 <fwp_main_thread+0xe80>
    a10f:	83 c0 01             	add    $0x1,%eax
    a112:	88 07                	mov    %al,(%rdi)
    a114:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a119:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a11d:	b9 01 00 00 00       	mov    $0x1,%ecx
    a122:	4c 89 e6             	mov    %r12,%rsi
    a125:	48 8d 15 74 4a 00 00 	lea    0x4a74(%rip),%rdx        # eba0 <d0>
    a12c:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a131:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a138:	00 00 
    a13a:	e8 a1 e4 ff ff       	call   85e0 <fwp_write>
    a13f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a144:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a149:	48 8d 05 1c 0f 00 00 	lea    0xf1c(%rip),%rax        # b06c <_IO_stdin_used+0x6c>
    a150:	48 85 c9             	test   %rcx,%rcx
    a153:	48 0f 44 c8          	cmove  %rax,%rcx
    a157:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a15b:	0f 87 a2 03 00 00    	ja     a503 <fwp_main_thread+0xee3>
    a161:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a165:	be 01 00 00 00       	mov    $0x1,%esi
    a16a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a16f:	e8 7c bd ff ff       	call   5ef0 <fwp_heap_alloc>
    a174:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a179:	4c 89 f2             	mov    %r14,%rdx
    a17c:	4c 89 30             	mov    %r14,(%rax)
    a17f:	48 89 c3             	mov    %rax,%rbx
    a182:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a186:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a18b:	e8 f0 93 ff ff       	call   3580 <memcpy@plt>
    a190:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a196:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a19b:	e8 10 92 ff ff       	call   33b0 <free@plt>
    a1a0:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a1a7:	48 89 d8             	mov    %rbx,%rax
    a1aa:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a1b1:	48 c1 e2 10          	shl    $0x10,%rdx
    a1b5:	48 39 d0             	cmp    %rdx,%rax
    a1b8:	73 55                	jae    a20f <fwp_main_thread+0xbef>
    a1ba:	48 89 c2             	mov    %rax,%rdx
    a1bd:	48 c1 ea 10          	shr    $0x10,%rdx
    a1c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a1c5:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a1cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a1d0:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a1d4:	48 85 f6             	test   %rsi,%rsi
    a1d7:	74 36                	je     a20f <fwp_main_thread+0xbef>
    a1d9:	0f b6 0a             	movzbl (%rdx),%ecx
    a1dc:	80 f9 02             	cmp    $0x2,%cl
    a1df:	0f 84 4b 01 00 00    	je     a330 <fwp_main_thread+0xd10>
    a1e5:	80 f9 01             	cmp    $0x1,%cl
    a1e8:	75 25                	jne    a20f <fwp_main_thread+0xbef>
    a1ea:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1ed:	0f b7 c0             	movzwl %ax,%eax
    a1f0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1f3:	48 0f af c1          	imul   %rcx,%rax
    a1f7:	48 c1 e8 20          	shr    $0x20,%rax
    a1fb:	48 39 d0             	cmp    %rdx,%rax
    a1fe:	73 0f                	jae    a20f <fwp_main_thread+0xbef>
    a200:	48 01 c6             	add    %rax,%rsi
    a203:	80 3e ff             	cmpb   $0xff,(%rsi)
    a206:	0f 84 44 01 00 00    	je     a350 <fwp_main_thread+0xd30>
    a20c:	c6 06 01             	movb   $0x1,(%rsi)
    a20f:	4c 89 e7             	mov    %r12,%rdi
    a212:	e8 a9 d8 ff ff       	call   7ac0 <fwp_drop0>
    a217:	48 8b 13             	mov    (%rbx),%rdx
    a21a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a21f:	be 01 00 00 00       	mov    $0x1,%esi
    a224:	48 8b 0d 55 f2 05 00 	mov    0x5f255(%rip),%rcx        # 69480 <fwp_prog_out>
    a22b:	e8 30 94 ff ff       	call   3660 <fwrite@plt>
    a230:	48 8b 35 49 f2 05 00 	mov    0x5f249(%rip),%rsi        # 69480 <fwp_prog_out>
    a237:	bf 0a 00 00 00       	mov    $0xa,%edi
    a23c:	e8 8f 92 ff ff       	call   34d0 <fputc@plt>
    a241:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a248:	48 89 d8             	mov    %rbx,%rax
    a24b:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a252:	48 c1 e2 10          	shl    $0x10,%rdx
    a256:	48 39 d0             	cmp    %rdx,%rax
    a259:	73 67                	jae    a2c2 <fwp_main_thread+0xca2>
    a25b:	48 89 c2             	mov    %rax,%rdx
    a25e:	48 c1 ea 10          	shr    $0x10,%rdx
    a262:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a266:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a26d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a271:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a275:	4d 85 f6             	test   %r14,%r14
    a278:	74 48                	je     a2c2 <fwp_main_thread+0xca2>
    a27a:	0f b6 0a             	movzbl (%rdx),%ecx
    a27d:	80 f9 02             	cmp    $0x2,%cl
    a280:	0f 84 ea 00 00 00    	je     a370 <fwp_main_thread+0xd50>
    a286:	80 f9 01             	cmp    $0x1,%cl
    a289:	75 37                	jne    a2c2 <fwp_main_thread+0xca2>
    a28b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a28e:	0f b7 c0             	movzwl %ax,%eax
    a291:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a294:	48 0f af c1          	imul   %rcx,%rax
    a298:	48 c1 e8 20          	shr    $0x20,%rax
    a29c:	48 39 d0             	cmp    %rdx,%rax
    a29f:	73 21                	jae    a2c2 <fwp_main_thread+0xca2>
    a2a1:	49 01 c6             	add    %rax,%r14
    a2a4:	41 0f b6 06          	movzbl (%r14),%eax
    a2a8:	84 c0                	test   %al,%al
    a2aa:	74 16                	je     a2c2 <fwp_main_thread+0xca2>
    a2ac:	3c 01                	cmp    $0x1,%al
    a2ae:	0f 84 0c 01 00 00    	je     a3c0 <fwp_main_thread+0xda0>
    a2b4:	3c ff                	cmp    $0xff,%al
    a2b6:	0f 84 64 01 00 00    	je     a420 <fwp_main_thread+0xe00>
    a2bc:	83 e8 01             	sub    $0x1,%eax
    a2bf:	41 88 06             	mov    %al,(%r14)
    a2c2:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a2c6:	4d 85 ed             	test   %r13,%r13
    a2c9:	0f 84 c1 00 00 00    	je     a390 <fwp_main_thread+0xd70>
    a2cf:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a2d6:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a2dd:	4c 89 e0             	mov    %r12,%rax
    a2e0:	48 c1 e2 10          	shl    $0x10,%rdx
    a2e4:	48 29 c8             	sub    %rcx,%rax
    a2e7:	48 39 d0             	cmp    %rdx,%rax
    a2ea:	0f 83 24 fe ff ff    	jae    a114 <fwp_main_thread+0xaf4>
    a2f0:	48 89 c2             	mov    %rax,%rdx
    a2f3:	48 c1 ea 10          	shr    $0x10,%rdx
    a2f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2fb:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a302:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a306:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a30a:	48 85 ff             	test   %rdi,%rdi
    a30d:	0f 84 01 fe ff ff    	je     a114 <fwp_main_thread+0xaf4>
    a313:	0f b6 0a             	movzbl (%rdx),%ecx
    a316:	80 f9 02             	cmp    $0x2,%cl
    a319:	0f 85 b1 fd ff ff    	jne    a0d0 <fwp_main_thread+0xab0>
    a31f:	66 85 c0             	test   %ax,%ax
    a322:	0f 85 ec fd ff ff    	jne    a114 <fwp_main_thread+0xaf4>
    a328:	e9 c1 fd ff ff       	jmp    a0ee <fwp_main_thread+0xace>
    a32d:	0f 1f 00             	nopl   (%rax)
    a330:	66 85 c0             	test   %ax,%ax
    a333:	0f 85 d6 fe ff ff    	jne    a20f <fwp_main_thread+0xbef>
    a339:	80 3e ff             	cmpb   $0xff,(%rsi)
    a33c:	0f 85 ca fe ff ff    	jne    a20c <fwp_main_thread+0xbec>
    a342:	0f 1f 00             	nopl   (%rax)
    a345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a34c:	00 00 00 00 
    a350:	48 89 f7             	mov    %rsi,%rdi
    a353:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a358:	e8 53 b4 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a35d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a362:	e9 a5 fe ff ff       	jmp    a20c <fwp_main_thread+0xbec>
    a367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a36e:	00 00 
    a370:	66 85 c0             	test   %ax,%ax
    a373:	0f 84 2b ff ff ff    	je     a2a4 <fwp_main_thread+0xc84>
    a379:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a37d:	4d 85 ed             	test   %r13,%r13
    a380:	0f 85 49 ff ff ff    	jne    a2cf <fwp_main_thread+0xcaf>
    a386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a38d:	00 00 00 
    a390:	4c 89 e7             	mov    %r12,%rdi
    a393:	e8 28 d7 ff ff       	call   7ac0 <fwp_drop0>
    a398:	48 89 ef             	mov    %rbp,%rdi
    a39b:	e8 20 d7 ff ff       	call   7ac0 <fwp_drop0>
    a3a0:	48 c7 05 b5 4c 00 00 	movq   $0x0,0x4cb5(%rip)        # f060 <v.2>
    a3a7:	00 00 00 00 
    a3ab:	c7 05 b3 4c 00 00 01 	movl   $0x1,0x4cb3(%rip)        # f068 <st.3>
    a3b2:	00 00 00 
    a3b5:	e9 be f3 ff ff       	jmp    9778 <fwp_main_thread+0x158>
    a3ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3c0:	48 89 df             	mov    %rbx,%rdi
    a3c3:	e8 28 b6 ff ff       	call   59f0 <fwp_mem_free>
    a3c8:	e9 f5 fe ff ff       	jmp    a2c2 <fwp_main_thread+0xca2>
    a3cd:	0f 1f 00             	nopl   (%rax)
    a3d0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a3d4:	e9 53 f4 ff ff       	jmp    982c <fwp_main_thread+0x20c>
    a3d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3e0:	66 85 c0             	test   %ax,%ax
    a3e3:	0f 85 d9 fc ff ff    	jne    a0c2 <fwp_main_thread+0xaa2>
    a3e9:	e9 ba fc ff ff       	jmp    a0a8 <fwp_main_thread+0xa88>
    a3ee:	66 90                	xchg   %ax,%ax
    a3f0:	66 85 c0             	test   %ax,%ax
    a3f3:	0f 85 21 fc ff ff    	jne    a01a <fwp_main_thread+0x9fa>
    a3f9:	e9 10 fc ff ff       	jmp    a00e <fwp_main_thread+0x9ee>
    a3fe:	66 90                	xchg   %ax,%ax
    a400:	66 85 c0             	test   %ax,%ax
    a403:	0f 85 7f fb ff ff    	jne    9f88 <fwp_main_thread+0x968>
    a409:	e9 6e fb ff ff       	jmp    9f7c <fwp_main_thread+0x95c>
    a40e:	66 90                	xchg   %ax,%ax
    a410:	4c 89 ef             	mov    %r13,%rdi
    a413:	e8 98 b3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a418:	e9 44 fa ff ff       	jmp    9e61 <fwp_main_thread+0x841>
    a41d:	0f 1f 00             	nopl   (%rax)
    a420:	4c 89 f0             	mov    %r14,%rax
    a423:	48 c1 e8 11          	shr    $0x11,%rax
    a427:	4c 31 f0             	xor    %r14,%rax
    a42a:	48 89 c2             	mov    %rax,%rdx
    a42d:	48 c1 ea 09          	shr    $0x9,%rdx
    a431:	48 31 d0             	xor    %rdx,%rax
    a434:	0f b6 d0             	movzbl %al,%edx
    a437:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a43e:	00 
    a43f:	48 85 c0             	test   %rax,%rax
    a442:	75 29                	jne    a46d <fwp_main_thread+0xe4d>
    a444:	e9 d7 00 00 00       	jmp    a520 <fwp_main_thread+0xf00>
    a449:	90                   	nop
    a44a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a451:	00 00 00 00 
    a455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a45c:	00 00 00 00 
    a460:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a464:	48 85 c0             	test   %rax,%rax
    a467:	0f 84 b3 00 00 00    	je     a520 <fwp_main_thread+0xf00>
    a46d:	48 89 c2             	mov    %rax,%rdx
    a470:	4c 3b 30             	cmp    (%rax),%r14
    a473:	75 eb                	jne    a460 <fwp_main_thread+0xe40>
    a475:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a479:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a47d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a481:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a488:	0f 85 34 fe ff ff    	jne    a2c2 <fwp_main_thread+0xca2>
    a48e:	4c 89 f7             	mov    %r14,%rdi
    a491:	e8 1a b3 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a496:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a49a:	e9 23 fe ff ff       	jmp    a2c2 <fwp_main_thread+0xca2>
    a49f:	90                   	nop
    a4a0:	e8 eb b1 ff ff       	call   5690 <fwp_rc_wide_dup>
    a4a5:	e9 6a fc ff ff       	jmp    a114 <fwp_main_thread+0xaf4>
    a4aa:	48 83 3d 46 d3 05 00 	cmpq   $0x0,0x5d346(%rip)        # 677f8 <fwp_root>
    a4b1:	00 
    a4b2:	c7 05 c4 4b 01 00 00 	movl   $0x0,0x14bc4(%rip)        # 1f080 <fwp_exit_code>
    a4b9:	00 00 00 
    a4bc:	0f 84 f4 f5 ff ff    	je     9ab6 <fwp_main_thread+0x496>
    a4c2:	e9 64 92 ff ff       	jmp    372b <fwp_main_thread.cold>
    a4c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4ce:	00 00 
    a4d0:	48 89 df             	mov    %rbx,%rdi
    a4d3:	e8 d8 b2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a4d8:	e9 a8 fa ff ff       	jmp    9f85 <fwp_main_thread+0x965>
    a4dd:	48 89 df             	mov    %rbx,%rdi
    a4e0:	e8 cb b2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a4e5:	e9 2d fb ff ff       	jmp    a017 <fwp_main_thread+0x9f7>
    a4ea:	48 89 df             	mov    %rbx,%rdi
    a4ed:	e8 be b2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    a4f2:	e9 ba fb ff ff       	jmp    a0b1 <fwp_main_thread+0xa91>
    a4f7:	48 8d 3d 7a 15 00 00 	lea    0x157a(%rip),%rdi        # ba78 <_IO_stdin_used+0xa78>
    a4fe:	e8 2d 9f ff ff       	call   4430 <fwp_trap>
    a503:	48 8d 3d 8d 0d 00 00 	lea    0xd8d(%rip),%rdi        # b297 <_IO_stdin_used+0x297>
    a50a:	e8 21 9f ff ff       	call   4430 <fwp_trap>
    a50f:	e8 3c 8f ff ff       	call   3450 <__stack_chk_fail@plt>
    a514:	48 8d 3d 61 0d 00 00 	lea    0xd61(%rip),%rdi        # b27c <_IO_stdin_used+0x27c>
    a51b:	e8 c0 9a ff ff       	call   3fe0 <ad_raw_fail>
    a520:	48 8d 3d 81 14 00 00 	lea    0x1481(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    a527:	e8 04 9f ff ff       	call   4430 <fwp_trap>
    a52c:	e9 fa 91 ff ff       	jmp    372b <fwp_main_thread.cold>
    a531:	e9 f5 91 ff ff       	jmp    372b <fwp_main_thread.cold>
    a536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a53d:	00 00 00 

000000000000a540 <__divmodti4>:
    a540:	f3 0f 1e fa          	endbr64
    a544:	55                   	push   %rbp
    a545:	49 89 f1             	mov    %rsi,%r9
    a548:	49 89 d2             	mov    %rdx,%r10
    a54b:	48 89 fe             	mov    %rdi,%rsi
    a54e:	49 89 cb             	mov    %rcx,%r11
    a551:	48 89 e5             	mov    %rsp,%rbp
    a554:	41 57                	push   %r15
    a556:	41 56                	push   %r14
    a558:	41 55                	push   %r13
    a55a:	41 54                	push   %r12
    a55c:	53                   	push   %rbx
    a55d:	4c 89 c3             	mov    %r8,%rbx
    a560:	45 31 c0             	xor    %r8d,%r8d
    a563:	4d 85 c9             	test   %r9,%r9
    a566:	79 12                	jns    a57a <__divmodti4+0x3a>
    a568:	31 ff                	xor    %edi,%edi
    a56a:	48 f7 de             	neg    %rsi
    a56d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a574:	4c 19 cf             	sbb    %r9,%rdi
    a577:	49 89 f9             	mov    %rdi,%r9
    a57a:	4c 89 d8             	mov    %r11,%rax
    a57d:	4d 85 db             	test   %r11,%r11
    a580:	0f 88 1a 01 00 00    	js     a6a0 <__divmodti4+0x160>
    a586:	4c 89 d9             	mov    %r11,%rcx
    a589:	49 89 f3             	mov    %rsi,%r11
    a58c:	75 62                	jne    a5f0 <__divmodti4+0xb0>
    a58e:	4d 89 c4             	mov    %r8,%r12
    a591:	4d 39 d1             	cmp    %r10,%r9
    a594:	0f 83 46 01 00 00    	jae    a6e0 <__divmodti4+0x1a0>
    a59a:	4c 89 d8             	mov    %r11,%rax
    a59d:	4c 89 ca             	mov    %r9,%rdx
    a5a0:	49 f7 f2             	div    %r10
    a5a3:	49 89 c3             	mov    %rax,%r11
    a5a6:	31 c0                	xor    %eax,%eax
    a5a8:	48 89 d6             	mov    %rdx,%rsi
    a5ab:	31 ff                	xor    %edi,%edi
    a5ad:	4c 89 d9             	mov    %r11,%rcx
    a5b0:	48 89 c2             	mov    %rax,%rdx
    a5b3:	48 89 c8             	mov    %rcx,%rax
    a5b6:	4d 85 e4             	test   %r12,%r12
    a5b9:	74 0a                	je     a5c5 <__divmodti4+0x85>
    a5bb:	48 f7 d8             	neg    %rax
    a5be:	48 83 d2 00          	adc    $0x0,%rdx
    a5c2:	48 f7 da             	neg    %rdx
    a5c5:	4d 85 c0             	test   %r8,%r8
    a5c8:	74 0a                	je     a5d4 <__divmodti4+0x94>
    a5ca:	48 f7 de             	neg    %rsi
    a5cd:	48 83 d7 00          	adc    $0x0,%rdi
    a5d1:	48 f7 df             	neg    %rdi
    a5d4:	48 89 33             	mov    %rsi,(%rbx)
    a5d7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a5db:	5b                   	pop    %rbx
    a5dc:	41 5c                	pop    %r12
    a5de:	41 5d                	pop    %r13
    a5e0:	41 5e                	pop    %r14
    a5e2:	41 5f                	pop    %r15
    a5e4:	5d                   	pop    %rbp
    a5e5:	c3                   	ret
    a5e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5ed:	00 00 00 
    a5f0:	4d 89 c4             	mov    %r8,%r12
    a5f3:	49 39 c1             	cmp    %rax,%r9
    a5f6:	0f 82 ce 00 00 00    	jb     a6ca <__divmodti4+0x18a>
    a5fc:	31 ff                	xor    %edi,%edi
    a5fe:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a603:	48 63 c7             	movslq %edi,%rax
    a606:	be 40 00 00 00       	mov    $0x40,%esi
    a60b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a610:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a615:	48 29 c6             	sub    %rax,%rsi
    a618:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a61d:	48 09 c8             	or     %rcx,%rax
    a620:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a625:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a62a:	49 89 c6             	mov    %rax,%r14
    a62d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a631:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a636:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a63b:	49 09 c1             	or     %rax,%r9
    a63e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a642:	4c 89 c8             	mov    %r9,%rax
    a645:	49 f7 f6             	div    %r14
    a648:	48 89 d1             	mov    %rdx,%rcx
    a64b:	49 89 c3             	mov    %rax,%r11
    a64e:	49 89 c1             	mov    %rax,%r9
    a651:	49 f7 e2             	mul    %r10
    a654:	49 89 c6             	mov    %rax,%r14
    a657:	49 89 d2             	mov    %rdx,%r10
    a65a:	48 39 d1             	cmp    %rdx,%rcx
    a65d:	72 07                	jb     a666 <__divmodti4+0x126>
    a65f:	75 17                	jne    a678 <__divmodti4+0x138>
    a661:	49 39 c7             	cmp    %rax,%r15
    a664:	73 12                	jae    a678 <__divmodti4+0x138>
    a666:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a66a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a66e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a672:	49 89 d2             	mov    %rdx,%r10
    a675:	49 89 c6             	mov    %rax,%r14
    a678:	4c 89 f8             	mov    %r15,%rax
    a67b:	4c 29 f0             	sub    %r14,%rax
    a67e:	4c 19 d1             	sbb    %r10,%rcx
    a681:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a686:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a68b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a690:	48 09 c6             	or     %rax,%rsi
    a693:	48 89 cf             	mov    %rcx,%rdi
    a696:	31 c0                	xor    %eax,%eax
    a698:	4c 89 c9             	mov    %r9,%rcx
    a69b:	e9 10 ff ff ff       	jmp    a5b0 <__divmodti4+0x70>
    a6a0:	4c 89 d0             	mov    %r10,%rax
    a6a3:	4c 89 da             	mov    %r11,%rdx
    a6a6:	4d 89 c4             	mov    %r8,%r12
    a6a9:	49 89 f3             	mov    %rsi,%r11
    a6ac:	48 f7 d8             	neg    %rax
    a6af:	49 f7 d4             	not    %r12
    a6b2:	48 83 d2 00          	adc    $0x0,%rdx
    a6b6:	49 89 c2             	mov    %rax,%r10
    a6b9:	48 f7 da             	neg    %rdx
    a6bc:	48 89 d1             	mov    %rdx,%rcx
    a6bf:	0f 84 cc fe ff ff    	je     a591 <__divmodti4+0x51>
    a6c5:	49 39 d1             	cmp    %rdx,%r9
    a6c8:	73 46                	jae    a710 <__divmodti4+0x1d0>
    a6ca:	4c 89 cf             	mov    %r9,%rdi
    a6cd:	31 c0                	xor    %eax,%eax
    a6cf:	31 c9                	xor    %ecx,%ecx
    a6d1:	e9 da fe ff ff       	jmp    a5b0 <__divmodti4+0x70>
    a6d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a6dd:	00 00 00 
    a6e0:	4d 85 d2             	test   %r10,%r10
    a6e3:	75 0d                	jne    a6f2 <__divmodti4+0x1b2>
    a6e5:	b8 01 00 00 00       	mov    $0x1,%eax
    a6ea:	31 d2                	xor    %edx,%edx
    a6ec:	49 f7 f2             	div    %r10
    a6ef:	49 89 c2             	mov    %rax,%r10
    a6f2:	4c 89 c8             	mov    %r9,%rax
    a6f5:	31 d2                	xor    %edx,%edx
    a6f7:	49 f7 f2             	div    %r10
    a6fa:	49 89 c1             	mov    %rax,%r9
    a6fd:	4c 89 d8             	mov    %r11,%rax
    a700:	49 f7 f2             	div    %r10
    a703:	49 89 c3             	mov    %rax,%r11
    a706:	4c 89 c8             	mov    %r9,%rax
    a709:	e9 9a fe ff ff       	jmp    a5a8 <__divmodti4+0x68>
    a70e:	66 90                	xchg   %ax,%ax
    a710:	45 31 f6             	xor    %r14d,%r14d
    a713:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a718:	44 89 f7             	mov    %r14d,%edi
    a71b:	45 85 f6             	test   %r14d,%r14d
    a71e:	0f 85 df fe ff ff    	jne    a603 <__divmodti4+0xc3>
    a724:	4c 39 ca             	cmp    %r9,%rdx
    a727:	72 17                	jb     a740 <__divmodti4+0x200>
    a729:	31 c9                	xor    %ecx,%ecx
    a72b:	48 39 c6             	cmp    %rax,%rsi
    a72e:	73 10                	jae    a740 <__divmodti4+0x200>
    a730:	4c 89 cf             	mov    %r9,%rdi
    a733:	31 c0                	xor    %eax,%eax
    a735:	e9 76 fe ff ff       	jmp    a5b0 <__divmodti4+0x70>
    a73a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a740:	4c 89 de             	mov    %r11,%rsi
    a743:	b9 01 00 00 00       	mov    $0x1,%ecx
    a748:	48 29 c6             	sub    %rax,%rsi
    a74b:	49 19 d1             	sbb    %rdx,%r9
    a74e:	eb e0                	jmp    a730 <__divmodti4+0x1f0>

000000000000a750 <atexit>:
    a750:	f3 0f 1e fa          	endbr64
    a754:	48 8b 15 ad 48 00 00 	mov    0x48ad(%rip),%rdx        # f008 <__dso_handle>
    a75b:	31 f6                	xor    %esi,%esi
    a75d:	e9 de 8e ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a764 <_fini>:
    a764:	f3 0f 1e fa          	endbr64
    a768:	48 83 ec 08          	sub    $0x8,%rsp
    a76c:	48 83 c4 08          	add    $0x8,%rsp
    a770:	c3                   	ret
