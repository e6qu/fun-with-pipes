
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 bf 00 00 	mov    0xbfc1(%rip),%rax        # efd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da bd 00 00    	push   0xbdda(%rip)        # ee00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc bd 00 00    	jmp    *0xbddc(%rip)        # ee08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 bc 00 00    	jmp    *0xbc46(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # ee60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # ee68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # ee70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # ee78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # ee80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # ee88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # ee90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # ee98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eeb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eeb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # eec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # eec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # eed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # eed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # eee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # eee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # eef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # eef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # ef60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # ef68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # ef70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # ef78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # ef80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # ef88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 b8 00 00    	jmp    *0xb8e6(%rip)        # ef90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de b8 00 00    	jmp    *0xb8de(%rip)        # ef98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 b8 00 00    	jmp    *0xb8d6(%rip)        # efa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce b8 00 00    	jmp    *0xb8ce(%rip)        # efa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 b8 00 00    	jmp    *0xb8c6(%rip)        # efb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be b8 00 00    	jmp    *0xb8be(%rip)        # efb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 79 00 00 	lea    0x79dd(%rip),%r9        # b0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 79 00 00 	lea    0x79da(%rip),%r8        # b0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 9b 00 00 	lea    0x9b81(%rip),%rax        # d300 <fwp_fn_table>
    377f:	48 89 05 92 dc 01 00 	mov    %rax,0x1dc92(%rip)        # 21418 <fwp_fns>
    3786:	48 8b 05 93 b8 00 00 	mov    0xb893(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c dc 01 00 	mov    %rax,0x1dc8c(%rip)        # 21420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d 8d 7a 00 00 	lea    0x7a8d(%rip),%rdi        # b22d <_IO_stdin_used+0x22d>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 b8 00 00 	mov    0xb818(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f 59 00 00 	lea    0x597f(%rip),%rdx        # 91e0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 b7 00 00 	mov    0xb783(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 b7 01 00    	mov    0x1b7d8(%rip),%eax        # 1f080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 3d 79 00 00 	lea    0x793d(%rip),%rdi        # b236 <_IO_stdin_used+0x236>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d d6 80 00 00 	lea    0x80d6(%rip),%rdi        # b9e0 <_IO_stdin_used+0x9e0>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 90 80 00 00 	lea    0x8090(%rip),%rdi        # b9b8 <_IO_stdin_used+0x9b8>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 54 80 00 00 	lea    0x8054(%rip),%rdi        # b988 <_IO_stdin_used+0x988>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d 20 80 00 00 	lea    0x8020(%rip),%rdi        # b960 <_IO_stdin_used+0x960>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b b6 00 00    	call   *0xb64b(%rip)        # efc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 b6 00 00 	lea    0xb691(%rip),%rdi        # f018 <__TMC_END__>
    3987:	48 8d 05 8a b6 00 00 	lea    0xb68a(%rip),%rax        # f018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e b6 00 00 	mov    0xb62e(%rip),%rax        # efc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 b6 00 00 	lea    0xb661(%rip),%rdi        # f018 <__TMC_END__>
    39b7:	48 8d 35 5a b6 00 00 	lea    0xb65a(%rip),%rsi        # f018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd b5 00 00 	mov    0xb5fd(%rip),%rax        # efd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d b6 00 00 00 	cmpb   $0x0,0xb64d(%rip)        # f048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da b5 00 00 	cmpq   $0x0,0xb5da(%rip)        # efe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 b5 00 00 	mov    0xb5f6(%rip),%rdi        # f008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 b6 00 00 01 	movb   $0x1,0xb625(%rip)        # f048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce b4 01 00 	add    0x1b4ce(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc b4 01 00 	add    0x1b4bc(%rip),%rax        # 1f0f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 d7 01 00 	mov    0x1d7a9(%rip),%rdi        # 21420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 b3 00 00 	mov    0xb394(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 b3 00 00 	mov    0xb381(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 73 00 00 	lea    0x7345(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 b3 00 00 	mov    0xb372(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 ba 01 00 	mov    0x1baa1(%rip),%rax        # 1f7a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 b3 01 00 	mov    0x1b3d9(%rip),%rax        # 1f158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 b3 01 00 	sub    0x1b3c5(%rip),%rax        # 1f150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 fd 7c 00 00 	lea    0x7cfd(%rip),%rsi        # bac0 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 5f 78 00 00 	lea    0x785f(%rip),%rdi        # b648 <_IO_stdin_used+0x648>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 b2 00 00 	mov    0xb242(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d dd b1 00 00 ff 	cmpl   $0xffffffff,0xb1dd(%rip)        # f010 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 71 00 00 	lea    0x71e2(%rip),%rax        # b022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 b2 01 00 	mov    0x1b2c1(%rip),%r9        # 1f108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ad 00 	movq   0xad9f(%rip),%xmm0        # ebf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 71 00 00 	lea    0x71e7(%rip),%rax        # b044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c b2 01 00 	mov    0x1b29c(%rip),%r8        # 1f100 <descent_inputs>
    3e64:	48 8b 0d a5 b2 01 00 	mov    0x1b2a5(%rip),%rcx        # 1f110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 b1 00 00 	mov    0xb1c2(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 71 00 00 	lea    0x71d8(%rip),%rax        # b061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ad 00 	movq   0xad67(%rip),%xmm0        # ebf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 f8 77 00 00 	lea    0x77f8(%rip),%rdx        # b690 <_IO_stdin_used+0x690>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 b2 01 00 	lea    0x1b271(%rip),%r12        # 1f120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ad 00 	movq   0xad44(%rip),%xmm0        # ec00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b b1 00 00 	mov    0xb15b(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 71 00 00 	lea    0x7175(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 71 00 00 	lea    0x7170(%rip),%rdx        # b06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 b1 00 00 	mov    0xb120(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 71 00 00 	lea    0x7144(%rip),%rdi        # b07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 b0 00 00 	mov    0xb0f9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 71 00 00 	lea    0x7143(%rip),%rcx        # b091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 71 00 00 	lea    0x7119(%rip),%rdx        # b06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b cc 01 00 	mov    0x1cc1b(%rip),%rax        # 20bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 cc 01 00 	lea    0x1cc14(%rip),%r8        # 20bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 cb 01 00 	mov    0x1cbf5(%rip),%rbx        # 20b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 cc 01 00 	mov    0x1cc05(%rip),%rcx        # 20bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 cb 01 00 	mov    0x1cba1(%rip),%rdi        # 20ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea cb 01 00 	sub    %rsi,0x1cbea(%rip)        # 20bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a cb 01 00 	mov    0x1cb7a(%rip),%rax        # 20b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 cb 01 00 	add    0x1cb30(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e cb 01 00 	mov    0x1cb3e(%rip),%rsi        # 20ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c cb 01 00 	mov    0x1cb4c(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb ca 01 00 	mov    %r12,0x1cafb(%rip)        # 20ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 ca 01 00 	mov    %rbp,0x1cae9(%rip)        # 20b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce ca 01 00 	cmp    %rdi,0x1cace(%rip)        # 20b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 ca 01 00 	mov    %rdi,0x1cac5(%rip)        # 20b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 cb 01 00 	sub    %rdi,0x1cb09(%rip)        # 20bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 ca 01 00 	mov    0x1cab1(%rip),%rax        # 20ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa ca 01 00 	lea    0x1caaa(%rip),%r8        # 20ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ae 00 00 	mov    0xae5d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 6e 00 00 	lea    0x6e14(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d a5 ad 00 00 	movslq 0xada5(%rip),%rbp        # f010 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a ae 01 00 	mov    0x1ae7a(%rip),%rsi        # 1f118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 ae 01 00 	lea    0x1ae76(%rip),%rcx        # 1f120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b ae 01 00 	addq   $0x1,0x1ae4b(%rip)        # 1f110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 40 ad 00 00    	mov    %ebx,0xad40(%rip)        # f010 <descent_active_phase>
    42d0:	48 89 05 41 ae 01 00 	mov    %rax,0x1ae41(%rip)        # 1f118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 b4 01 00 	cmp    0x1b499(%rip),%rdi        # 1f7a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f b4 01 00 	mov    0x1b45f(%rip),%rax        # 1f780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d b4 01 00 	mov    %rdi,0x1b43d(%rip)        # 1f780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 b4 01 00 	mov    %rdi,0x1b419(%rip)        # 1f788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee 6d 00 00 	lea    0x6dee(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 6c 00 00 	lea    0x6cba(%rip),%rsi        # b07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ac 00 00 	mov    0xac28(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 6c 00 00 	lea    0x6c64(%rip),%rdx        # b083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ac 00 00 	mov    0xac10(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 ab 00 00 	mov    0xab21(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 6a 00 00 	lea    0x6ad8(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 6b 00 00 	lea    0x6b45(%rip),%rdi        # b092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 6a 00 00 	lea    0x6acd(%rip),%rdi        # b0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d f0 70 00 00 	lea    0x70f0(%rip),%rdi        # b6e0 <_IO_stdin_used+0x6e0>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 d0 74 00 	movdqa 0x74d0(%rip),%xmm0        # bae0 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa cd 01 00 	add    0x1cdaa(%rip),%rax        # 21418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 44 70 00 00 	lea    0x7044(%rip),%rdi        # b708 <_IO_stdin_used+0x708>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 aa 01 00 	cmp    %rax,0x1aa05(%rip)        # 1f0e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 aa 01 00 	add    0x1aa00(%rip),%rax        # 1f0f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 2d 70 00 00 	lea    0x702d(%rip),%rdi        # b738 <_IO_stdin_used+0x738>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 69 00 00 	lea    0x69a5(%rip),%r8        # b0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 67 00 00 	lea    0x67fa(%rip),%r8        # b0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 66 00 00 	lea    0x6697(%rip),%r8        # b0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 64 00 00 	lea    0x646f(%rip),%rdi        # b0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 65 00 00 	lea    0x6554(%rip),%rsi        # b1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 be 01 00 	mov    0x1be85(%rip),%r9        # 20b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de be 01 00 	mov    0x1bede(%rip),%r8        # 20be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 77 6a 00 00 	lea    0x6a77(%rip),%rdx        # b788 <_IO_stdin_used+0x788>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 be 01 00 	mov    0x1bec6(%rip),%rcx        # 20be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 be 01 	movsd  0x1bed4(%rip),%xmm1        # 20c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 be 01 	movsd  0x1bec4(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 a3 00 00 	mov    0xa305(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 78 6d 00 	movdqa 0x6d78(%rip),%xmm0        # baf0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f b9 01 00 	lea    0x1b97f(%rip),%rax        # 20700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 a1 6d 00 	movdqa 0x6da1(%rip),%xmm2        # bb30 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 b9 01 00 	movaps %xmm0,0x1b925(%rip)        # 206c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 5d 6d 00 	movdqa 0x6d5d(%rip),%xmm0        # bb00 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 bd 01 00 01 	movl   $0x1,0x1bdb3(%rip)        # 20b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 b9 01 00 	movaps %xmm0,0x1b913(%rip)        # 206d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 4b 6d 00 	movdqa 0x6d4b(%rip),%xmm0        # bb10 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 14 b9 01 00 	movaps %xmm0,0x1b914(%rip)        # 206e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 4c 6d 00 	movdqa 0x6d4c(%rip),%xmm0        # bb20 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 15 b9 01 00 	movaps %xmm0,0x1b915(%rip)        # 206f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 a9 01 00 	lea    0x1a995(%rip),%r8        # 1f7c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 bc 01 00 	mov    %rax,0x1bcb0(%rip)        # 20b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e bc 01 00 	mov    %r12,0x1bc8e(%rip)        # 20b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 bc 01 00 	mov    %rax,0x1bc77(%rip)        # 20b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 bc 01 00 	mov    %rbx,0x1bc90(%rip)        # 20b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 bc 01 00 	mov    %rsi,0x1bcb9(%rip)        # 20bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 61 00 00 	lea    0x61f9(%rip),%rdi        # b112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 bc 01 00 	mov    %rax,0x1bc98(%rip)        # 20bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c bc 01 00    	mov    %eax,0x1bc1c(%rip)        # 20b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c a8 01 00 	mov    0x1a80c(%rip),%r8        # 1f780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c a7 01 00 	mov    %rbx,0x1a73c(%rip)        # 1f788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 a7 01 00 	mov    %r8,0x1a728(%rip)        # 1f780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 60 00 00 	lea    0x605c(%rip),%rdi        # b122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d 9f 01 00 	lea    0x19f9d(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 9f 01 00 	movaps %xmm0,0x19f85(%rip)        # 1f0a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 9f 01 00 	mov    %rax,0x19f61(%rip)        # 1f088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 9f 01 00 	movaps %xmm0,0x19f82(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 9f 01 00 	movaps %xmm0,0x19f86(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 9f 01 00 	mov    %rdx,0x19f87(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 5f 00 00 	lea    0x5fb3(%rip),%rdi        # b122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 a5 01 00 	mov    0x1a5b7(%rip),%rbx        # 1f778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a 9d 00 00 	mov    0x9d8a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 53 65 00 00 	lea    0x6553(%rip),%rdi        # b810 <_IO_stdin_used+0x810>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d a4 01 00 	mov    0x1a48d(%rip),%rax        # 1f780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 a4 01 00 	mov    %rdx,0x1a467(%rip)        # 1f780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 a3 01 00 	mov    0x1a3b4(%rip),%rbx        # 1f778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 a3 01 00 	mov    %rbx,0x1a371(%rip)        # 1f778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 a3 01 00 	mov    %rdx,0x1a371(%rip)        # 1f788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 a3 01 00 	lea    0x1a386(%rip),%rsi        # 1f7c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 bf 01 00 	addq   $0x1,0x1bf05(%rip)        # 21408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 27 63 00 00 	lea    0x6327(%rip),%rdi        # b840 <_IO_stdin_used+0x840>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 38 63 00 00 	lea    0x6338(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 5b 00 00 	lea    0x5bf7(%rip),%rdi        # b133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e a2 01 00 	lea    0x1a23e(%rip),%rcx        # 1f7c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f be 01 00 	subq   $0x1,0x1be3f(%rip)        # 21408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d 93 62 00 00 	lea    0x6293(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 be 01 00 	cmpq   $0x0,0x1be20(%rip)        # 21408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 bd 01 00 	sub    %rax,0x1bd75(%rip)        # 21410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 bd 01 00 	add    %r12,0x1bd53(%rip)        # 21410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af b4 01 00 	mov    0x1b4af(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac a0 01 00 	lea    0x1a0ac(%rip),%rax        # 1f7c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 b4 01 00 	add    0x1b403(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 b3 01 00 	mov    0x1b3d0(%rip),%rsi        # 20b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 b3 01 00 	mov    0x1b3f1(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 b3 01 00 	add    0x1b3e5(%rip),%r8        # 20bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad b3 01 	addsd  0x1b3ad(%rip),%xmm0        # 20c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 9f 01 00 	lea    0x19f62(%rip),%rax        # 1f7c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c b3 01 00 	sub    %rdi,0x1b36c(%rip)        # 20be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 b3 01 	movsd  %xmm0,0x1b384(%rip)        # 20c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e b3 01 00 	sub    %rdx,0x1b33e(%rip)        # 20be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 b3 01 	addsd  0x1b344(%rip),%xmm0        # 20c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 b3 01 	movsd  %xmm0,0x1b338(%rip)        # 20c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf b2 01 00 	mov    0x1b2cf(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 b2 01 00 	add    %rcx,0x1b2c9(%rip)        # 20bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 b2 01 00 	cmp    0x1b282(%rip),%r9        # 20bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 b2 01 00 	mov    %r9,0x1b279(%rip)        # 20bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a b2 01 00 	cmp    0x1b26a(%rip),%r9        # 20ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d b2 01 00 	mov    %r9,0x1b25d(%rip)        # 20ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 b1 01 00 	add    0x1b173(%rip),%rdi        # 20bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 9d 01 00 	lea    0x19d50(%rip),%r15        # 1f7c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 b0 01 00 	add    0x1b0c0(%rip),%r12        # 20b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 b1 01 00 	add    0x1b119(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 b1 01 00 	cmp    %rax,0x1b118(%rip)        # 20be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 b1 01 00 	mov    %rax,0x1b109(%rip)        # 20be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 b1 01 00 	mov    %rax,0x1b108(%rip)        # 20be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 b1 01 	addsd  0x1b104(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc b0 01 	movsd  %xmm0,0x1b0fc(%rip)        # 20bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 b0 01 00    	mov    0x1b043(%rip),%eax        # 20b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f 9c 01 00 	lea    0x19c7f(%rip),%rdi        # 1f7c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 b0 01 00 	add    0x1b038(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 b0 01 00 	cmp    %rax,0x1b033(%rip)        # 20be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 b0 01 00 	mov    %rax,0x1b024(%rip)        # 20be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 b0 01 00 	mov    %rax,0x1b023(%rip)        # 20be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f b0 01 	addsd  0x1b01f(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 b0 01 	movsd  %xmm0,0x1b017(%rip)        # 20bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce ae 01 00    	mov    0x1aece(%rip),%eax        # 20b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 9b 01 00 	lea    0x19b05(%rip),%rax        # 1f7c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb ae 01 00 	add    0x1aebb(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba ae 01 00 	cmp    %rax,0x1aeba(%rip)        # 20be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab ae 01 00 	mov    %rax,0x1aeab(%rip)        # 20be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa ae 01 00 	mov    %rax,0x1aeaa(%rip)        # 20be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 ae 01 	addsd  0x1aea6(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e ae 01 	movsd  %xmm0,0x1ae9e(%rip)        # 20bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e ad 01 00    	mov    0x1ad9e(%rip),%eax        # 20b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d a9 01 00 	movzbl 0x1a98d(%rip),%eax        # 20762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 99 01 00 	lea    0x199e4(%rip),%rdx        # 1f7c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 ad 01 00 	add    0x1adb5(%rip),%rax        # 20be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 ad 01 00 	cmp    %rax,0x1adb0(%rip)        # 20be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 ad 01 00 	mov    %rax,0x1ada1(%rip)        # 20be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 ad 01 00 	mov    %rax,0x1ada0(%rip)        # 20be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f ad 01 	addsd  0x1ad9f(%rip),%xmm0        # 20bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 ad 01 	movsd  %xmm0,0x1ad97(%rip)        # 20bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_p_ad_push.constprop.0>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	49 89 d5             	mov    %rdx,%r13
    5ee9:	41 54                	push   %r12
    5eeb:	49 89 fc             	mov    %rdi,%r12
    5eee:	55                   	push   %rbp
    5eef:	53                   	push   %rbx
    5ef0:	48 83 ec 38          	sub    $0x38,%rsp
    5ef4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5ef9:	48 85 ff             	test   %rdi,%rdi
    5efc:	79 09                	jns    5f07 <fwp_p_ad_push.constprop.0+0x27>
    5efe:	48 85 d2             	test   %rdx,%rdx
    5f01:	0f 88 a9 01 00 00    	js     60b0 <fwp_p_ad_push.constprop.0+0x1d0>
    5f07:	48 89 f8             	mov    %rdi,%rax
    5f0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f0e:	48 09 d0             	or     %rdx,%rax
    5f11:	0f 89 79 01 00 00    	jns    6090 <fwp_p_ad_push.constprop.0+0x1b0>
    5f17:	48 89 f8             	mov    %rdi,%rax
    5f1a:	48 c1 f8 20          	sar    $0x20,%rax
    5f1e:	48 85 ff             	test   %rdi,%rdi
    5f21:	79 24                	jns    5f47 <fwp_p_ad_push.constprop.0+0x67>
    5f23:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f28:	48 89 d0             	mov    %rdx,%rax
    5f2b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f32:	00 
    5f33:	49 89 d4             	mov    %rdx,%r12
    5f36:	48 c1 f8 20          	sar    $0x20,%rax
    5f3a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5f41:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5f47:	48 89 c7             	mov    %rax,%rdi
    5f4a:	e8 81 e7 ff ff       	call   46d0 <fwp_tape_of>
    5f4f:	48 89 c3             	mov    %rax,%rbx
    5f52:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f57:	0f 85 f0 02 00 00    	jne    624d <fwp_p_ad_push.constprop.0+0x36d>
    5f5d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5f61:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5f68:	0f 8f 51 02 00 00    	jg     61bf <fwp_p_ad_push.constprop.0+0x2df>
    5f6e:	44 89 e0             	mov    %r12d,%eax
    5f71:	49 39 c7             	cmp    %rax,%r15
    5f74:	0f 8e 51 02 00 00    	jle    61cb <fwp_p_ad_push.constprop.0+0x2eb>
    5f7a:	4d 85 ed             	test   %r13,%r13
    5f7d:	78 0c                	js     5f8b <fwp_p_ad_push.constprop.0+0xab>
    5f7f:	44 89 e8             	mov    %r13d,%eax
    5f82:	49 39 c7             	cmp    %rax,%r15
    5f85:	0f 8e 40 02 00 00    	jle    61cb <fwp_p_ad_push.constprop.0+0x2eb>
    5f8b:	4d 89 fe             	mov    %r15,%r14
    5f8e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5f92:	49 8d 46 01          	lea    0x1(%r14),%rax
    5f96:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5f9c:	0f 87 1d 02 00 00    	ja     61bf <fwp_p_ad_push.constprop.0+0x2df>
    5fa2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5fa6:	48 39 e8             	cmp    %rbp,%rax
    5fa9:	0f 8e 31 01 00 00    	jle    60e0 <fwp_p_ad_push.constprop.0+0x200>
    5faf:	48 85 ed             	test   %rbp,%rbp
    5fb2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5fb7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5fbb:	48 39 e8             	cmp    %rbp,%rax
    5fbe:	7e 20                	jle    5fe0 <fwp_p_ad_push.constprop.0+0x100>
    5fc0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5fc7:	0f 8f 03 01 00 00    	jg     60d0 <fwp_p_ad_push.constprop.0+0x1f0>
    5fcd:	48 01 ed             	add    %rbp,%rbp
    5fd0:	48 39 e8             	cmp    %rbp,%rax
    5fd3:	7f eb                	jg     5fc0 <fwp_p_ad_push.constprop.0+0xe0>
    5fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fdc:	00 00 00 00 
    5fe0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5fe7:	00 
    5fe8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fec:	48 89 c6             	mov    %rax,%rsi
    5fef:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ff4:	e8 d7 d5 ff ff       	call   35d0 <realloc@plt>
    5ff9:	48 85 c0             	test   %rax,%rax
    5ffc:	0f 84 d5 01 00 00    	je     61d7 <fwp_p_ad_push.constprop.0+0x2f7>
    6002:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6006:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    600a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    600e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6012:	48 89 e9             	mov    %rbp,%rcx
    6015:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6019:	48 c1 e1 04          	shl    $0x4,%rcx
    601d:	48 89 ce             	mov    %rcx,%rsi
    6020:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6025:	e8 a6 d5 ff ff       	call   35d0 <realloc@plt>
    602a:	48 85 c0             	test   %rax,%rax
    602d:	0f 84 a4 01 00 00    	je     61d7 <fwp_p_ad_push.constprop.0+0x2f7>
    6033:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6037:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    603c:	4d 85 f6             	test   %r14,%r14
    603f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6043:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6048:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    604f:	00 
    6050:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6057:	00 
    6058:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    605c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6063:	00 
    6064:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6068:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    606c:	0f 85 e6 00 00 00    	jne    6158 <fwp_p_ad_push.constprop.0+0x278>
    6072:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6076:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    607a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    607e:	49 01 c8             	add    %rcx,%r8
    6081:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6085:	eb 79                	jmp    6100 <fwp_p_ad_push.constprop.0+0x220>
    6087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    608e:	00 00 
    6090:	48 89 d0             	mov    %rdx,%rax
    6093:	48 c1 ff 20          	sar    $0x20,%rdi
    6097:	48 c1 f8 20          	sar    $0x20,%rax
    609b:	48 39 c7             	cmp    %rax,%rdi
    609e:	0f 84 a3 fe ff ff    	je     5f47 <fwp_p_ad_push.constprop.0+0x67>
    60a4:	48 8d 3d e5 57 00 00 	lea    0x57e5(%rip),%rdi        # b890 <_IO_stdin_used+0x890>
    60ab:	e8 40 e3 ff ff       	call   43f0 <fwp_trap>
    60b0:	48 83 c4 38          	add    $0x38,%rsp
    60b4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    60bb:	5b                   	pop    %rbx
    60bc:	5d                   	pop    %rbp
    60bd:	41 5c                	pop    %r12
    60bf:	41 5d                	pop    %r13
    60c1:	41 5e                	pop    %r14
    60c3:	41 5f                	pop    %r15
    60c5:	c3                   	ret
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    60d5:	e9 06 ff ff ff       	jmp    5fe0 <fwp_p_ad_push.constprop.0+0x100>
    60da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    60e0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60e4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60e8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60ef:	00 
    60f0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60f7:	00 
    60f8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    60fc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6100:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6106:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    610a:	4d 85 ed             	test   %r13,%r13
    610d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6112:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6118:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6123:	49 8d 47 01          	lea    0x1(%r15),%rax
    6127:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    612b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6131:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6135:	48 83 c4 38          	add    $0x38,%rsp
    6139:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6140:	ff ff ff 
    6143:	4c 21 e0             	and    %r12,%rax
    6146:	5b                   	pop    %rbx
    6147:	5d                   	pop    %rbp
    6148:	4c 09 f8             	or     %r15,%rax
    614b:	41 5c                	pop    %r12
    614d:	41 5d                	pop    %r13
    614f:	41 5e                	pop    %r14
    6151:	41 5f                	pop    %r15
    6153:	c3                   	ret
    6154:	0f 1f 40 00          	nopl   0x0(%rax)
    6158:	48 39 ca             	cmp    %rcx,%rdx
    615b:	49 89 d6             	mov    %rdx,%r14
    615e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6163:	48 0f 43 ca          	cmovae %rdx,%rcx
    6167:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    616c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6171:	48 29 d1             	sub    %rdx,%rcx
    6174:	4c 89 ca             	mov    %r9,%rdx
    6177:	e8 e4 d3 ff ff       	call   3560 <__memmove_chk@plt>
    617c:	4c 03 73 30          	add    0x30(%rbx),%r14
    6180:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6185:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6189:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    618e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6192:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6196:	4c 89 d2             	mov    %r10,%rdx
    6199:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    619e:	e8 6d d4 ff ff       	call   3610 <memmove@plt>
    61a3:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61a7:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    61ab:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    61b0:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    61b5:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    61ba:	e9 b7 fe ff ff       	jmp    6076 <fwp_p_ad_push.constprop.0+0x196>
    61bf:	48 8d 3d 86 4f 00 00 	lea    0x4f86(%rip),%rdi        # b14c <_IO_stdin_used+0x14c>
    61c6:	e8 25 e2 ff ff       	call   43f0 <fwp_trap>
    61cb:	48 8d 3d 95 4f 00 00 	lea    0x4f95(%rip),%rdi        # b167 <_IO_stdin_used+0x167>
    61d2:	e8 19 e2 ff ff       	call   43f0 <fwp_trap>
    61d7:	48 89 df             	mov    %rbx,%rdi
    61da:	e8 21 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    61df:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    61e3:	e8 d8 d1 ff ff       	call   33c0 <free@plt>
    61e8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    61ec:	e8 cf d1 ff ff       	call   33c0 <free@plt>
    61f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    61f5:	e8 c6 d1 ff ff       	call   33c0 <free@plt>
    61fa:	31 c9                	xor    %ecx,%ecx
    61fc:	31 c0                	xor    %eax,%eax
    61fe:	31 d2                	xor    %edx,%edx
    6200:	89 53 04             	mov    %edx,0x4(%rbx)
    6203:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6207:	ba 13 00 00 00       	mov    $0x13,%edx
    620c:	be 01 00 00 00       	mov    $0x1,%esi
    6211:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6215:	48 8d 3d ec 4d 00 00 	lea    0x4dec(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    621c:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6220:	48 8b 0d 19 8e 00 00 	mov    0x8e19(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    6227:	48 89 43 40          	mov    %rax,0x40(%rbx)
    622b:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    622f:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6233:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6237:	e8 44 d4 ff ff       	call   3680 <fwrite@plt>
    623c:	31 ff                	xor    %edi,%edi
    623e:	e8 7d d3 ff ff       	call   35c0 <fflush@plt>
    6243:	bf 66 00 00 00       	mov    $0x66,%edi
    6248:	e8 53 d4 ff ff       	call   36a0 <_Exit@plt>
    624d:	48 8d 3d 84 56 00 00 	lea    0x5684(%rip),%rdi        # b8d8 <_IO_stdin_used+0x8d8>
    6254:	e8 97 e1 ff ff       	call   43f0 <fwp_trap>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006260 <w120>:
    6260:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6264:	41 55                	push   %r13
    6266:	48 89 fa             	mov    %rdi,%rdx
    6269:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    626d:	41 54                	push   %r12
    626f:	49 89 fc             	mov    %rdi,%r12
    6272:	55                   	push   %rbp
    6273:	53                   	push   %rbx
    6274:	48 89 f3             	mov    %rsi,%rbx
    6277:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    627c:	48 89 f1             	mov    %rsi,%rcx
    627f:	48 83 ec 28          	sub    $0x28,%rsp
    6283:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6289:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    628f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6295:	e8 46 fc ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    629a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    62a0:	48 89 da             	mov    %rbx,%rdx
    62a3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    62a9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62b0:	00 f0 3f 
    62b3:	48 89 c7             	mov    %rax,%rdi
    62b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62bd:	00 f0 bf 
    62c0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    62c5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    62cb:	e8 10 fc ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    62d0:	f2 0f 10 05 98 58 00 	movsd  0x5898(%rip),%xmm0        # bb70 <msg.4+0xb0>
    62d7:	00 
    62d8:	4c 89 e7             	mov    %r12,%rdi
    62db:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    62e1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62e8:	00 f0 3f 
    62eb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    62f2:	49 89 c5             	mov    %rax,%r13
    62f5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62fc:	00 f0 bf 
    62ff:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6304:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    630a:	e8 d1 fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    630f:	48 89 e9             	mov    %rbp,%rcx
    6312:	4c 89 ea             	mov    %r13,%rdx
    6315:	48 89 ee             	mov    %rbp,%rsi
    6318:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    631e:	4c 89 ef             	mov    %r13,%rdi
    6321:	49 89 c4             	mov    %rax,%r12
    6324:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6328:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    632e:	e8 ad fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6333:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6339:	f2 0f 59 1d 37 58 00 	mulsd  0x5837(%rip),%xmm3        # bb78 <msg.4+0xb8>
    6340:	00 
    6341:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6348:	00 59 40 
    634b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6350:	48 89 c2             	mov    %rax,%rdx
    6353:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    635a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6360:	e8 7b fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6365:	48 89 d9             	mov    %rbx,%rcx
    6368:	4c 89 e2             	mov    %r12,%rdx
    636b:	48 89 de             	mov    %rbx,%rsi
    636e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6374:	4c 89 e7             	mov    %r12,%rdi
    6377:	48 89 c5             	mov    %rax,%rbp
    637a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    637e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6384:	e8 57 fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6389:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    638f:	48 89 ea             	mov    %rbp,%rdx
    6392:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6398:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    639f:	00 f0 3f 
    63a2:	48 89 c7             	mov    %rax,%rdi
    63a5:	48 89 ce             	mov    %rcx,%rsi
    63a8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    63ad:	e8 2e fb ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    63b2:	48 83 c4 28          	add    $0x28,%rsp
    63b6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    63bb:	5b                   	pop    %rbx
    63bc:	5d                   	pop    %rbp
    63bd:	41 5c                	pop    %r12
    63bf:	41 5d                	pop    %r13
    63c1:	c3                   	ret
    63c2:	0f 1f 00             	nopl   (%rax)
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 

00000000000063d0 <w176.constprop.0>:
    63d0:	41 54                	push   %r12
    63d2:	55                   	push   %rbp
    63d3:	53                   	push   %rbx
    63d4:	48 83 ec 10          	sub    $0x10,%rsp
    63d8:	4c 8b 27             	mov    (%rdi),%r12
    63db:	4d 85 e4             	test   %r12,%r12
    63de:	74 58                	je     6438 <w176.constprop.0+0x68>
    63e0:	48 89 fd             	mov    %rdi,%rbp
    63e3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    63e7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63ee:	31 db                	xor    %ebx,%ebx
    63f0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    63f6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    63fb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6402:	00 f0 3f 
    6405:	48 83 c3 02          	add    $0x2,%rbx
    6409:	48 89 ce             	mov    %rcx,%rsi
    640c:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6412:	e8 c9 fa ff ff       	call   5ee0 <fwp_p_ad_push.constprop.0>
    6417:	4c 39 e3             	cmp    %r12,%rbx
    641a:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6420:	48 89 c7             	mov    %rax,%rdi
    6423:	72 cb                	jb     63f0 <w176.constprop.0+0x20>
    6425:	48 83 c4 10          	add    $0x10,%rsp
    6429:	48 89 f8             	mov    %rdi,%rax
    642c:	5b                   	pop    %rbx
    642d:	5d                   	pop    %rbp
    642e:	41 5c                	pop    %r12
    6430:	c3                   	ret
    6431:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6438:	48 83 c4 10          	add    $0x10,%rsp
    643c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6443:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6447:	5b                   	pop    %rbx
    6448:	48 89 f8             	mov    %rdi,%rax
    644b:	5d                   	pop    %rbp
    644c:	41 5c                	pop    %r12
    644e:	c3                   	ret
    644f:	90                   	nop

0000000000006450 <fwp_rc_share>:
    6450:	48 8b 05 41 a7 01 00 	mov    0x1a741(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    6457:	48 2b 3d 12 a7 01 00 	sub    0x1a712(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    645e:	48 c1 e0 10          	shl    $0x10,%rax
    6462:	48 39 c7             	cmp    %rax,%rdi
    6465:	73 4a                	jae    64b1 <fwp_rc_share+0x61>
    6467:	48 89 f8             	mov    %rdi,%rax
    646a:	48 c1 e8 10          	shr    $0x10,%rax
    646e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6472:	48 8b 05 3f a7 01 00 	mov    0x1a73f(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    6479:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    647d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6481:	48 85 d2             	test   %rdx,%rdx
    6484:	74 2b                	je     64b1 <fwp_rc_share+0x61>
    6486:	0f b6 08             	movzbl (%rax),%ecx
    6489:	80 f9 02             	cmp    $0x2,%cl
    648c:	74 2a                	je     64b8 <fwp_rc_share+0x68>
    648e:	80 f9 01             	cmp    $0x1,%cl
    6491:	75 1e                	jne    64b1 <fwp_rc_share+0x61>
    6493:	8b 48 18             	mov    0x18(%rax),%ecx
    6496:	0f b7 ff             	movzwl %di,%edi
    6499:	8b 40 1c             	mov    0x1c(%rax),%eax
    649c:	48 0f af f9          	imul   %rcx,%rdi
    64a0:	48 c1 ef 20          	shr    $0x20,%rdi
    64a4:	48 39 c7             	cmp    %rax,%rdi
    64a7:	73 08                	jae    64b1 <fwp_rc_share+0x61>
    64a9:	48 01 fa             	add    %rdi,%rdx
    64ac:	80 3a 00             	cmpb   $0x0,(%rdx)
    64af:	75 0d                	jne    64be <fwp_rc_share+0x6e>
    64b1:	c3                   	ret
    64b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64b8:	66 85 ff             	test   %di,%di
    64bb:	74 ef                	je     64ac <fwp_rc_share+0x5c>
    64bd:	c3                   	ret
    64be:	50                   	push   %rax
    64bf:	48 8d 3d 42 54 00 00 	lea    0x5442(%rip),%rdi        # b908 <_IO_stdin_used+0x908>
    64c6:	e8 25 df ff ff       	call   43f0 <fwp_trap>
    64cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000064d0 <fwp_rc_free_obj>:
    64d0:	48 8b 15 c1 a6 01 00 	mov    0x1a6c1(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    64d7:	48 89 f8             	mov    %rdi,%rax
    64da:	48 2b 05 8f a6 01 00 	sub    0x1a68f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    64e1:	48 c1 e2 10          	shl    $0x10,%rdx
    64e5:	48 39 d0             	cmp    %rdx,%rax
    64e8:	73 5b                	jae    6545 <fwp_rc_free_obj+0x75>
    64ea:	48 89 c2             	mov    %rax,%rdx
    64ed:	48 c1 ea 10          	shr    $0x10,%rdx
    64f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    64f5:	48 8b 15 bc a6 01 00 	mov    0x1a6bc(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    64fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6500:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6504:	48 85 c9             	test   %rcx,%rcx
    6507:	74 3c                	je     6545 <fwp_rc_free_obj+0x75>
    6509:	0f b6 32             	movzbl (%rdx),%esi
    650c:	40 80 fe 02          	cmp    $0x2,%sil
    6510:	74 2e                	je     6540 <fwp_rc_free_obj+0x70>
    6512:	40 80 fe 01          	cmp    $0x1,%sil
    6516:	75 2d                	jne    6545 <fwp_rc_free_obj+0x75>
    6518:	8b 72 18             	mov    0x18(%rdx),%esi
    651b:	0f b7 c0             	movzwl %ax,%eax
    651e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6521:	48 0f af c6          	imul   %rsi,%rax
    6525:	48 c1 e8 20          	shr    $0x20,%rax
    6529:	48 39 d0             	cmp    %rdx,%rax
    652c:	73 17                	jae    6545 <fwp_rc_free_obj+0x75>
    652e:	48 01 c1             	add    %rax,%rcx
    6531:	80 39 01             	cmpb   $0x1,(%rcx)
    6534:	75 0f                	jne    6545 <fwp_rc_free_obj+0x75>
    6536:	e9 55 f2 ff ff       	jmp    5790 <fwp_mem_free>
    653b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6540:	66 85 c0             	test   %ax,%ax
    6543:	74 ec                	je     6531 <fwp_rc_free_obj+0x61>
    6545:	c3                   	ret
    6546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    654d:	00 00 00 

0000000000006550 <fwp_rc_dup>:
    6550:	f3 0f 1e fa          	endbr64
    6554:	48 8b 05 3d a6 01 00 	mov    0x1a63d(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    655b:	48 2b 3d 0e a6 01 00 	sub    0x1a60e(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    6562:	48 c1 e0 10          	shl    $0x10,%rax
    6566:	48 39 c7             	cmp    %rax,%rdi
    6569:	73 56                	jae    65c1 <fwp_rc_dup+0x71>
    656b:	48 89 f8             	mov    %rdi,%rax
    656e:	48 c1 e8 10          	shr    $0x10,%rax
    6572:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6576:	48 8b 05 3b a6 01 00 	mov    0x1a63b(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    657d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6581:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6585:	48 85 c0             	test   %rax,%rax
    6588:	74 37                	je     65c1 <fwp_rc_dup+0x71>
    658a:	0f b6 0a             	movzbl (%rdx),%ecx
    658d:	80 f9 02             	cmp    $0x2,%cl
    6590:	74 36                	je     65c8 <fwp_rc_dup+0x78>
    6592:	80 f9 01             	cmp    $0x1,%cl
    6595:	75 2a                	jne    65c1 <fwp_rc_dup+0x71>
    6597:	8b 4a 18             	mov    0x18(%rdx),%ecx
    659a:	0f b7 ff             	movzwl %di,%edi
    659d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65a0:	48 0f af f9          	imul   %rcx,%rdi
    65a4:	48 c1 ef 20          	shr    $0x20,%rdi
    65a8:	48 39 d7             	cmp    %rdx,%rdi
    65ab:	73 14                	jae    65c1 <fwp_rc_dup+0x71>
    65ad:	48 01 f8             	add    %rdi,%rax
    65b0:	0f b6 10             	movzbl (%rax),%edx
    65b3:	84 d2                	test   %dl,%dl
    65b5:	74 0a                	je     65c1 <fwp_rc_dup+0x71>
    65b7:	80 fa fd             	cmp    $0xfd,%dl
    65ba:	77 14                	ja     65d0 <fwp_rc_dup+0x80>
    65bc:	83 c2 01             	add    $0x1,%edx
    65bf:	88 10                	mov    %dl,(%rax)
    65c1:	c3                   	ret
    65c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65c8:	66 85 ff             	test   %di,%di
    65cb:	74 e3                	je     65b0 <fwp_rc_dup+0x60>
    65cd:	c3                   	ret
    65ce:	66 90                	xchg   %ax,%ax
    65d0:	48 89 c7             	mov    %rax,%rdi
    65d3:	e9 58 ee ff ff       	jmp    5430 <fwp_rc_wide_dup>
    65d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    65df:	00 

00000000000065e0 <fwp_owned_entry173>:
    65e0:	f3 0f 1e fa          	endbr64
    65e4:	48 83 ec 38          	sub    $0x38,%rsp
    65e8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    65ed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    65f4:	00 00 
    65f6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    65fb:	31 c0                	xor    %eax,%eax
    65fd:	48 8b 07             	mov    (%rdi),%rax
    6600:	48 03 47 10          	add    0x10(%rdi),%rax
    6604:	0f 80 c2 00 00 00    	jo     66cc <fwp_owned_entry173+0xec>
    660a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    660f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6614:	31 ff                	xor    %edi,%edi
    6616:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    661a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    661f:	e8 8c f7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6624:	48 8b 15 6d a5 01 00 	mov    0x1a56d(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    662b:	48 89 c6             	mov    %rax,%rsi
    662e:	48 2b 05 3b a5 01 00 	sub    0x1a53b(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6635:	48 c1 e2 10          	shl    $0x10,%rdx
    6639:	48 39 d0             	cmp    %rdx,%rax
    663c:	73 4f                	jae    668d <fwp_owned_entry173+0xad>
    663e:	48 89 c2             	mov    %rax,%rdx
    6641:	48 c1 ea 10          	shr    $0x10,%rdx
    6645:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6649:	48 8b 15 68 a5 01 00 	mov    0x1a568(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    6650:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6654:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6658:	48 85 d2             	test   %rdx,%rdx
    665b:	74 30                	je     668d <fwp_owned_entry173+0xad>
    665d:	0f b6 39             	movzbl (%rcx),%edi
    6660:	40 80 ff 02          	cmp    $0x2,%dil
    6664:	74 42                	je     66a8 <fwp_owned_entry173+0xc8>
    6666:	40 80 ff 01          	cmp    $0x1,%dil
    666a:	75 21                	jne    668d <fwp_owned_entry173+0xad>
    666c:	8b 79 18             	mov    0x18(%rcx),%edi
    666f:	0f b7 c0             	movzwl %ax,%eax
    6672:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6675:	48 0f af c7          	imul   %rdi,%rax
    6679:	48 c1 e8 20          	shr    $0x20,%rax
    667d:	48 39 c8             	cmp    %rcx,%rax
    6680:	73 0b                	jae    668d <fwp_owned_entry173+0xad>
    6682:	48 01 c2             	add    %rax,%rdx
    6685:	80 3a ff             	cmpb   $0xff,(%rdx)
    6688:	74 26                	je     66b0 <fwp_owned_entry173+0xd0>
    668a:	c6 02 01             	movb   $0x1,(%rdx)
    668d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6692:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6699:	00 00 
    669b:	75 34                	jne    66d1 <fwp_owned_entry173+0xf1>
    669d:	48 89 f0             	mov    %rsi,%rax
    66a0:	48 83 c4 38          	add    $0x38,%rsp
    66a4:	c3                   	ret
    66a5:	0f 1f 00             	nopl   (%rax)
    66a8:	66 85 c0             	test   %ax,%ax
    66ab:	75 e0                	jne    668d <fwp_owned_entry173+0xad>
    66ad:	eb d6                	jmp    6685 <fwp_owned_entry173+0xa5>
    66af:	90                   	nop
    66b0:	48 89 d7             	mov    %rdx,%rdi
    66b3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    66b8:	48 89 14 24          	mov    %rdx,(%rsp)
    66bc:	e8 8f ee ff ff       	call   5550 <fwp_rc_forget_slot>
    66c1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    66c6:	48 8b 14 24          	mov    (%rsp),%rdx
    66ca:	eb be                	jmp    668a <fwp_owned_entry173+0xaa>
    66cc:	e8 2f d0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    66d1:	e8 8a cd ff ff       	call   3460 <__stack_chk_fail@plt>
    66d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66dd:	00 00 00 

00000000000066e0 <e173>:
    66e0:	f3 0f 1e fa          	endbr64
    66e4:	53                   	push   %rbx
    66e5:	48 83 ec 30          	sub    $0x30,%rsp
    66e9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    66ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    66f5:	00 00 
    66f7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    66fc:	31 c0                	xor    %eax,%eax
    66fe:	48 8b 07             	mov    (%rdi),%rax
    6701:	48 03 47 10          	add    0x10(%rdi),%rax
    6705:	0f 80 c9 00 00 00    	jo     67d4 <e173+0xf4>
    670b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6710:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6715:	31 ff                	xor    %edi,%edi
    6717:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    671b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6720:	e8 8b f6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6725:	48 8b 15 6c a4 01 00 	mov    0x1a46c(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    672c:	48 89 c3             	mov    %rax,%rbx
    672f:	48 2b 05 3a a4 01 00 	sub    0x1a43a(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6736:	48 c1 e2 10          	shl    $0x10,%rdx
    673a:	48 39 d0             	cmp    %rdx,%rax
    673d:	73 4f                	jae    678e <e173+0xae>
    673f:	48 89 c2             	mov    %rax,%rdx
    6742:	48 c1 ea 10          	shr    $0x10,%rdx
    6746:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    674a:	48 8b 15 67 a4 01 00 	mov    0x1a467(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    6751:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6755:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6759:	48 85 d2             	test   %rdx,%rdx
    675c:	74 30                	je     678e <e173+0xae>
    675e:	0f b6 31             	movzbl (%rcx),%esi
    6761:	40 80 fe 02          	cmp    $0x2,%sil
    6765:	74 49                	je     67b0 <e173+0xd0>
    6767:	40 80 fe 01          	cmp    $0x1,%sil
    676b:	75 21                	jne    678e <e173+0xae>
    676d:	8b 71 18             	mov    0x18(%rcx),%esi
    6770:	0f b7 c0             	movzwl %ax,%eax
    6773:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6776:	48 0f af c6          	imul   %rsi,%rax
    677a:	48 c1 e8 20          	shr    $0x20,%rax
    677e:	48 39 c8             	cmp    %rcx,%rax
    6781:	73 0b                	jae    678e <e173+0xae>
    6783:	48 01 c2             	add    %rax,%rdx
    6786:	80 3a ff             	cmpb   $0xff,(%rdx)
    6789:	74 35                	je     67c0 <e173+0xe0>
    678b:	c6 02 01             	movb   $0x1,(%rdx)
    678e:	48 89 df             	mov    %rbx,%rdi
    6791:	e8 ba fc ff ff       	call   6450 <fwp_rc_share>
    6796:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    679b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    67a2:	00 00 
    67a4:	75 33                	jne    67d9 <e173+0xf9>
    67a6:	48 83 c4 30          	add    $0x30,%rsp
    67aa:	48 89 d8             	mov    %rbx,%rax
    67ad:	5b                   	pop    %rbx
    67ae:	c3                   	ret
    67af:	90                   	nop
    67b0:	66 85 c0             	test   %ax,%ax
    67b3:	75 d9                	jne    678e <e173+0xae>
    67b5:	eb cf                	jmp    6786 <e173+0xa6>
    67b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67be:	00 00 
    67c0:	48 89 d7             	mov    %rdx,%rdi
    67c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    67c8:	e8 83 ed ff ff       	call   5550 <fwp_rc_forget_slot>
    67cd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    67d2:	eb b7                	jmp    678b <e173+0xab>
    67d4:	e8 27 cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    67d9:	e8 82 cc ff ff       	call   3460 <__stack_chk_fail@plt>
    67de:	66 90                	xchg   %ax,%ax

00000000000067e0 <fwp_closure_drop>:
    67e0:	48 8b 15 b1 a3 01 00 	mov    0x1a3b1(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    67e7:	48 89 f8             	mov    %rdi,%rax
    67ea:	48 2b 05 7f a3 01 00 	sub    0x1a37f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    67f1:	48 c1 e2 10          	shl    $0x10,%rdx
    67f5:	48 39 d0             	cmp    %rdx,%rax
    67f8:	73 6b                	jae    6865 <fwp_closure_drop+0x85>
    67fa:	48 89 c2             	mov    %rax,%rdx
    67fd:	48 c1 ea 10          	shr    $0x10,%rdx
    6801:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6805:	48 8b 15 ac a3 01 00 	mov    0x1a3ac(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    680c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6810:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6814:	48 85 d2             	test   %rdx,%rdx
    6817:	74 4c                	je     6865 <fwp_closure_drop+0x85>
    6819:	0f b6 31             	movzbl (%rcx),%esi
    681c:	40 80 fe 02          	cmp    $0x2,%sil
    6820:	74 3e                	je     6860 <fwp_closure_drop+0x80>
    6822:	40 80 fe 01          	cmp    $0x1,%sil
    6826:	75 3d                	jne    6865 <fwp_closure_drop+0x85>
    6828:	8b 71 18             	mov    0x18(%rcx),%esi
    682b:	0f b7 c0             	movzwl %ax,%eax
    682e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6831:	48 0f af c6          	imul   %rsi,%rax
    6835:	48 c1 e8 20          	shr    $0x20,%rax
    6839:	48 39 c8             	cmp    %rcx,%rax
    683c:	73 27                	jae    6865 <fwp_closure_drop+0x85>
    683e:	48 01 c2             	add    %rax,%rdx
    6841:	0f b6 02             	movzbl (%rdx),%eax
    6844:	84 c0                	test   %al,%al
    6846:	74 1d                	je     6865 <fwp_closure_drop+0x85>
    6848:	3c 01                	cmp    $0x1,%al
    684a:	74 24                	je     6870 <fwp_closure_drop+0x90>
    684c:	3c ff                	cmp    $0xff,%al
    684e:	74 48                	je     6898 <fwp_closure_drop+0xb8>
    6850:	83 e8 01             	sub    $0x1,%eax
    6853:	88 02                	mov    %al,(%rdx)
    6855:	c3                   	ret
    6856:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    685d:	00 00 00 
    6860:	66 85 c0             	test   %ax,%ax
    6863:	74 dc                	je     6841 <fwp_closure_drop+0x61>
    6865:	c3                   	ret
    6866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    686d:	00 00 00 
    6870:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6877:	ff ff 
    6879:	48 85 c0             	test   %rax,%rax
    687c:	74 12                	je     6890 <fwp_closure_drop+0xb0>
    687e:	48 89 fe             	mov    %rdi,%rsi
    6881:	48 89 c7             	mov    %rax,%rdi
    6884:	e9 c7 db ff ff       	jmp    4450 <fwp_closure_drop_push>
    6889:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6890:	e9 6b dd ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6895:	0f 1f 00             	nopl   (%rax)
    6898:	48 89 d0             	mov    %rdx,%rax
    689b:	48 8d 35 1e 8f 01 00 	lea    0x18f1e(%rip),%rsi        # 1f7c0 <fwp_heap>
    68a2:	48 83 ec 18          	sub    $0x18,%rsp
    68a6:	48 c1 e8 11          	shr    $0x11,%rax
    68aa:	48 31 d0             	xor    %rdx,%rax
    68ad:	48 89 c1             	mov    %rax,%rcx
    68b0:	48 c1 e9 09          	shr    $0x9,%rcx
    68b4:	48 31 c8             	xor    %rcx,%rax
    68b7:	0f b6 c8             	movzbl %al,%ecx
    68ba:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    68c1:	00 
    68c2:	48 85 c0             	test   %rax,%rax
    68c5:	75 22                	jne    68e9 <fwp_closure_drop+0x109>
    68c7:	eb 59                	jmp    6922 <fwp_closure_drop+0x142>
    68c9:	90                   	nop
    68ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68d1:	00 00 00 00 
    68d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68dc:	00 00 00 00 
    68e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    68e4:	48 85 c0             	test   %rax,%rax
    68e7:	74 39                	je     6922 <fwp_closure_drop+0x142>
    68e9:	48 89 c1             	mov    %rax,%rcx
    68ec:	48 39 10             	cmp    %rdx,(%rax)
    68ef:	75 ef                	jne    68e0 <fwp_closure_drop+0x100>
    68f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    68f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    68f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    68fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6904:	74 05                	je     690b <fwp_closure_drop+0x12b>
    6906:	48 83 c4 18          	add    $0x18,%rsp
    690a:	c3                   	ret
    690b:	48 89 d7             	mov    %rdx,%rdi
    690e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6913:	e8 38 ec ff ff       	call   5550 <fwp_rc_forget_slot>
    6918:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    691d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6920:	eb e4                	jmp    6906 <fwp_closure_drop+0x126>
    6922:	48 8d 3d 3f 4f 00 00 	lea    0x4f3f(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    6929:	e8 c2 da ff ff       	call   43f0 <fwp_trap>
    692e:	66 90                	xchg   %ax,%ax

0000000000006930 <fwp_owned_tape_release>:
    6930:	48 85 ff             	test   %rdi,%rdi
    6933:	0f 84 f7 00 00 00    	je     6a30 <fwp_owned_tape_release+0x100>
    6939:	41 54                	push   %r12
    693b:	55                   	push   %rbp
    693c:	53                   	push   %rbx
    693d:	48 8b 07             	mov    (%rdi),%rax
    6940:	48 85 c0             	test   %rax,%rax
    6943:	74 08                	je     694d <fwp_owned_tape_release+0x1d>
    6945:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6949:	48 89 50 08          	mov    %rdx,0x8(%rax)
    694d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6951:	48 85 d2             	test   %rdx,%rdx
    6954:	74 03                	je     6959 <fwp_owned_tape_release+0x29>
    6956:	48 89 02             	mov    %rax,(%rdx)
    6959:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    695d:	48 89 fb             	mov    %rdi,%rbx
    6960:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6964:	48 85 c0             	test   %rax,%rax
    6967:	0f 84 89 00 00 00    	je     69f6 <fwp_owned_tape_release+0xc6>
    696d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6971:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6975:	7e 47                	jle    69be <fwp_owned_tape_release+0x8e>
    6977:	31 ed                	xor    %ebp,%ebp
    6979:	eb 0d                	jmp    6988 <fwp_owned_tape_release+0x58>
    697b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6980:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6984:	48 8b 40 68          	mov    0x68(%rax),%rax
    6988:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    698c:	49 89 ec             	mov    %rbp,%r12
    698f:	48 83 c5 01          	add    $0x1,%rbp
    6993:	49 c1 e4 04          	shl    $0x4,%r12
    6997:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    699b:	ff d0                	call   *%rax
    699d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    69a1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    69a6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    69aa:	ff 50 68             	call   *0x68(%rax)
    69ad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    69b1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    69b5:	48 39 e8             	cmp    %rbp,%rax
    69b8:	7f c6                	jg     6980 <fwp_owned_tape_release+0x50>
    69ba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    69be:	31 ed                	xor    %ebp,%ebp
    69c0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    69c5:	7e 28                	jle    69ef <fwp_owned_tape_release+0xbf>
    69c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    69ce:	00 00 
    69d0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    69d4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    69d8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    69dc:	74 07                	je     69e5 <fwp_owned_tape_release+0xb5>
    69de:	ff 52 68             	call   *0x68(%rdx)
    69e1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    69e5:	48 83 c5 01          	add    $0x1,%rbp
    69e9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    69ed:	7f e1                	jg     69d0 <fwp_owned_tape_release+0xa0>
    69ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    69f3:	ff 52 68             	call   *0x68(%rdx)
    69f6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    69fa:	e8 e1 fd ff ff       	call   67e0 <fwp_closure_drop>
    69ff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6a03:	e8 d8 fd ff ff       	call   67e0 <fwp_closure_drop>
    6a08:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6a0c:	e8 cf fd ff ff       	call   67e0 <fwp_closure_drop>
    6a11:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6a15:	e8 76 ed ff ff       	call   5790 <fwp_mem_free>
    6a1a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6a1e:	e8 6d ed ff ff       	call   5790 <fwp_mem_free>
    6a23:	48 89 df             	mov    %rbx,%rdi
    6a26:	5b                   	pop    %rbx
    6a27:	5d                   	pop    %rbp
    6a28:	41 5c                	pop    %r12
    6a2a:	e9 61 ed ff ff       	jmp    5790 <fwp_mem_free>
    6a2f:	90                   	nop
    6a30:	c3                   	ret
    6a31:	0f 1f 40 00          	nopl   0x0(%rax)
    6a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a3c:	00 00 00 00 

0000000000006a40 <fwp_tape_finish>:
    6a40:	f3 0f 1e fa          	endbr64
    6a44:	41 56                	push   %r14
    6a46:	48 8d 3d 53 86 01 00 	lea    0x18653(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    6a4d:	41 55                	push   %r13
    6a4f:	41 54                	push   %r12
    6a51:	55                   	push   %rbp
    6a52:	53                   	push   %rbx
    6a53:	e8 b8 d6 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6a58:	48 83 3d 88 86 01 00 	cmpq   $0x0,0x18688(%rip)        # 1f0e8 <fwp_ntapes>
    6a5f:	00 
    6a60:	48 c7 05 1d 86 01 00 	movq   $0x0,0x1861d(%rip)        # 1f088 <fwp_tape_cached_bytes>
    6a67:	00 00 00 00 
    6a6b:	7e 68                	jle    6ad5 <fwp_tape_finish+0x95>
    6a6d:	45 31 e4             	xor    %r12d,%r12d
    6a70:	31 ed                	xor    %ebp,%ebp
    6a72:	0f 1f 00             	nopl   (%rax)
    6a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a7c:	00 00 00 00 
    6a80:	48 8b 1d 69 86 01 00 	mov    0x18669(%rip),%rbx        # 1f0f0 <fwp_tapes>
    6a87:	48 83 c5 01          	add    $0x1,%rbp
    6a8b:	4c 01 e3             	add    %r12,%rbx
    6a8e:	49 83 c4 68          	add    $0x68,%r12
    6a92:	48 89 df             	mov    %rbx,%rdi
    6a95:	e8 66 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6a9a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6a9e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6aa2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6aa6:	e8 15 c9 ff ff       	call   33c0 <free@plt>
    6aab:	4c 89 f7             	mov    %r14,%rdi
    6aae:	e8 0d c9 ff ff       	call   33c0 <free@plt>
    6ab3:	4c 89 ef             	mov    %r13,%rdi
    6ab6:	e8 05 c9 ff ff       	call   33c0 <free@plt>
    6abb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6abf:	e8 6c fe ff ff       	call   6930 <fwp_owned_tape_release>
    6ac4:	48 39 2d 1d 86 01 00 	cmp    %rbp,0x1861d(%rip)        # 1f0e8 <fwp_ntapes>
    6acb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6ad2:	00 
    6ad3:	7f ab                	jg     6a80 <fwp_tape_finish+0x40>
    6ad5:	48 8b 3d 14 86 01 00 	mov    0x18614(%rip),%rdi        # 1f0f0 <fwp_tapes>
    6adc:	e8 df c8 ff ff       	call   33c0 <free@plt>
    6ae1:	5b                   	pop    %rbx
    6ae2:	5d                   	pop    %rbp
    6ae3:	48 c7 05 02 86 01 00 	movq   $0x0,0x18602(%rip)        # 1f0f0 <fwp_tapes>
    6aea:	00 00 00 00 
    6aee:	48 c7 05 e7 85 01 00 	movq   $0x0,0x185e7(%rip)        # 1f0e0 <fwp_tapes_cap>
    6af5:	00 00 00 00 
    6af9:	41 5c                	pop    %r12
    6afb:	48 c7 05 e2 85 01 00 	movq   $0x0,0x185e2(%rip)        # 1f0e8 <fwp_ntapes>
    6b02:	00 00 00 00 
    6b06:	41 5d                	pop    %r13
    6b08:	48 c7 05 c5 85 01 00 	movq   $0x0,0x185c5(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6b0f:	00 00 00 00 
    6b13:	41 5e                	pop    %r14
    6b15:	c3                   	ret
    6b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b1d:	00 00 00 

0000000000006b20 <fwp_tape_scope_release>:
    6b20:	f3 0f 1e fa          	endbr64
    6b24:	41 55                	push   %r13
    6b26:	41 54                	push   %r12
    6b28:	55                   	push   %rbp
    6b29:	53                   	push   %rbx
    6b2a:	48 83 ec 58          	sub    $0x58,%rsp
    6b2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b35:	00 00 
    6b37:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6b3c:	48 63 07             	movslq (%rdi),%rax
    6b3f:	85 c0                	test   %eax,%eax
    6b41:	0f 88 05 01 00 00    	js     6c4c <fwp_tape_scope_release+0x12c>
    6b47:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6b4e:	ec c4 4e 
    6b51:	48 89 fb             	mov    %rdi,%rbx
    6b54:	eb 3c                	jmp    6b92 <fwp_tape_scope_release+0x72>
    6b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b5d:	00 00 00 
    6b60:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6b65:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6b69:	e8 52 c8 ff ff       	call   33c0 <free@plt>
    6b6e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6b72:	e8 49 c8 ff ff       	call   33c0 <free@plt>
    6b77:	4c 89 ef             	mov    %r13,%rdi
    6b7a:	e8 41 c8 ff ff       	call   33c0 <free@plt>
    6b7f:	4c 89 e7             	mov    %r12,%rdi
    6b82:	e8 a9 fd ff ff       	call   6930 <fwp_owned_tape_release>
    6b87:	48 63 03             	movslq (%rbx),%rax
    6b8a:	85 c0                	test   %eax,%eax
    6b8c:	0f 88 ba 00 00 00    	js     6c4c <fwp_tape_scope_release+0x12c>
    6b92:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6b96:	48 8b 35 53 85 01 00 	mov    0x18553(%rip),%rsi        # 1f0f0 <fwp_tapes>
    6b9d:	4c 01 c6             	add    %r8,%rsi
    6ba0:	48 89 f7             	mov    %rsi,%rdi
    6ba3:	e8 58 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ba8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6bad:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6bb2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6bb9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6bbd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6bc1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6bc8:	00 
    6bc9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6bce:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6bd2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6bd7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6bdb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6be0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6be7:	00 
    6be8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6bef:	00 
    6bf0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6bf7:	00 
    6bf8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6bfd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6c02:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6c06:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6c0a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6c0e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6c14:	77 18                	ja     6c2e <fwp_tape_scope_release+0x10e>
    6c16:	49 c1 f8 03          	sar    $0x3,%r8
    6c1a:	4c 0f af c5          	imul   %rbp,%r8
    6c1e:	4c 3b 05 b3 84 01 00 	cmp    0x184b3(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    6c25:	7d 07                	jge    6c2e <fwp_tape_scope_release+0x10e>
    6c27:	4c 89 05 aa 84 01 00 	mov    %r8,0x184aa(%rip)        # 1f0d8 <fwp_tape_next_slot>
    6c2e:	4d 85 e4             	test   %r12,%r12
    6c31:	0f 85 29 ff ff ff    	jne    6b60 <fwp_tape_scope_release+0x40>
    6c37:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6c3c:	e8 2f e4 ff ff       	call   5070 <fwp_tape_buffers_release>
    6c41:	48 63 03             	movslq (%rbx),%rax
    6c44:	85 c0                	test   %eax,%eax
    6c46:	0f 89 46 ff ff ff    	jns    6b92 <fwp_tape_scope_release+0x72>
    6c4c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6c51:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c58:	00 00 
    6c5a:	75 0b                	jne    6c67 <fwp_tape_scope_release+0x147>
    6c5c:	48 83 c4 58          	add    $0x58,%rsp
    6c60:	5b                   	pop    %rbx
    6c61:	5d                   	pop    %rbp
    6c62:	41 5c                	pop    %r12
    6c64:	41 5d                	pop    %r13
    6c66:	c3                   	ret
    6c67:	e8 f4 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6c6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006c70 <fwp_drop4>:
    6c70:	48 8b 0d 21 9f 01 00 	mov    0x19f21(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    6c77:	48 89 f8             	mov    %rdi,%rax
    6c7a:	48 2b 05 ef 9e 01 00 	sub    0x19eef(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6c81:	48 c1 e1 10          	shl    $0x10,%rcx
    6c85:	48 39 c8             	cmp    %rcx,%rax
    6c88:	0f 83 42 01 00 00    	jae    6dd0 <fwp_drop4+0x160>
    6c8e:	48 83 ec 18          	sub    $0x18,%rsp
    6c92:	48 89 fa             	mov    %rdi,%rdx
    6c95:	4c 8d 05 24 8b 01 00 	lea    0x18b24(%rip),%r8        # 1f7c0 <fwp_heap>
    6c9c:	48 89 c1             	mov    %rax,%rcx
    6c9f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6ca6:	48 c1 e9 10          	shr    $0x10,%rcx
    6caa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6cae:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6cb2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6cb6:	48 85 c9             	test   %rcx,%rcx
    6cb9:	74 40                	je     6cfb <fwp_drop4+0x8b>
    6cbb:	0f b6 3e             	movzbl (%rsi),%edi
    6cbe:	40 80 ff 02          	cmp    $0x2,%dil
    6cc2:	74 3c                	je     6d00 <fwp_drop4+0x90>
    6cc4:	40 80 ff 01          	cmp    $0x1,%dil
    6cc8:	75 31                	jne    6cfb <fwp_drop4+0x8b>
    6cca:	8b 7e 18             	mov    0x18(%rsi),%edi
    6ccd:	0f b7 c0             	movzwl %ax,%eax
    6cd0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6cd3:	48 0f af c7          	imul   %rdi,%rax
    6cd7:	48 c1 e8 20          	shr    $0x20,%rax
    6cdb:	48 39 f0             	cmp    %rsi,%rax
    6cde:	73 1b                	jae    6cfb <fwp_drop4+0x8b>
    6ce0:	48 01 c1             	add    %rax,%rcx
    6ce3:	0f b6 01             	movzbl (%rcx),%eax
    6ce6:	84 c0                	test   %al,%al
    6ce8:	74 11                	je     6cfb <fwp_drop4+0x8b>
    6cea:	3c 01                	cmp    $0x1,%al
    6cec:	74 22                	je     6d10 <fwp_drop4+0xa0>
    6cee:	3c ff                	cmp    $0xff,%al
    6cf0:	0f 84 0a 01 00 00    	je     6e00 <fwp_drop4+0x190>
    6cf6:	83 e8 01             	sub    $0x1,%eax
    6cf9:	88 01                	mov    %al,(%rcx)
    6cfb:	48 83 c4 18          	add    $0x18,%rsp
    6cff:	c3                   	ret
    6d00:	66 85 c0             	test   %ax,%ax
    6d03:	74 de                	je     6ce3 <fwp_drop4+0x73>
    6d05:	48 83 c4 18          	add    $0x18,%rsp
    6d09:	c3                   	ret
    6d0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d10:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6d14:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6d1b:	48 89 f8             	mov    %rdi,%rax
    6d1e:	48 c1 e1 10          	shl    $0x10,%rcx
    6d22:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d29:	48 39 c8             	cmp    %rcx,%rax
    6d2c:	73 62                	jae    6d90 <fwp_drop4+0x120>
    6d2e:	48 89 c1             	mov    %rax,%rcx
    6d31:	48 c1 e9 10          	shr    $0x10,%rcx
    6d35:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6d39:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6d3d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6d41:	48 85 c9             	test   %rcx,%rcx
    6d44:	74 4a                	je     6d90 <fwp_drop4+0x120>
    6d46:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6d4a:	41 80 f9 02          	cmp    $0x2,%r9b
    6d4e:	0f 84 9c 00 00 00    	je     6df0 <fwp_drop4+0x180>
    6d54:	41 80 f9 01          	cmp    $0x1,%r9b
    6d58:	75 36                	jne    6d90 <fwp_drop4+0x120>
    6d5a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6d5e:	0f b7 c0             	movzwl %ax,%eax
    6d61:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d64:	49 0f af c1          	imul   %r9,%rax
    6d68:	48 c1 e8 20          	shr    $0x20,%rax
    6d6c:	48 39 f0             	cmp    %rsi,%rax
    6d6f:	73 1f                	jae    6d90 <fwp_drop4+0x120>
    6d71:	48 01 c1             	add    %rax,%rcx
    6d74:	0f b6 01             	movzbl (%rcx),%eax
    6d77:	84 c0                	test   %al,%al
    6d79:	74 15                	je     6d90 <fwp_drop4+0x120>
    6d7b:	3c 01                	cmp    $0x1,%al
    6d7d:	74 59                	je     6dd8 <fwp_drop4+0x168>
    6d7f:	3c ff                	cmp    $0xff,%al
    6d81:	0f 84 ff 00 00 00    	je     6e86 <fwp_drop4+0x216>
    6d87:	83 e8 01             	sub    $0x1,%eax
    6d8a:	88 01                	mov    %al,(%rcx)
    6d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    6d90:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6d94:	48 89 d7             	mov    %rdx,%rdi
    6d97:	48 89 0c 24          	mov    %rcx,(%rsp)
    6d9b:	e8 30 f7 ff ff       	call   64d0 <fwp_rc_free_obj>
    6da0:	4c 8d 05 19 8a 01 00 	lea    0x18a19(%rip),%r8        # 1f7c0 <fwp_heap>
    6da7:	48 8b 04 24          	mov    (%rsp),%rax
    6dab:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6db2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6db9:	48 c1 e2 10          	shl    $0x10,%rdx
    6dbd:	48 39 d0             	cmp    %rdx,%rax
    6dc0:	0f 83 35 ff ff ff    	jae    6cfb <fwp_drop4+0x8b>
    6dc6:	48 8b 14 24          	mov    (%rsp),%rdx
    6dca:	e9 cd fe ff ff       	jmp    6c9c <fwp_drop4+0x2c>
    6dcf:	90                   	nop
    6dd0:	c3                   	ret
    6dd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dd8:	48 89 14 24          	mov    %rdx,(%rsp)
    6ddc:	e8 ef f6 ff ff       	call   64d0 <fwp_rc_free_obj>
    6de1:	48 8b 14 24          	mov    (%rsp),%rdx
    6de5:	eb a9                	jmp    6d90 <fwp_drop4+0x120>
    6de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dee:	00 00 
    6df0:	66 85 c0             	test   %ax,%ax
    6df3:	75 9b                	jne    6d90 <fwp_drop4+0x120>
    6df5:	e9 7a ff ff ff       	jmp    6d74 <fwp_drop4+0x104>
    6dfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e00:	48 89 c8             	mov    %rcx,%rax
    6e03:	48 c1 e8 11          	shr    $0x11,%rax
    6e07:	48 31 c8             	xor    %rcx,%rax
    6e0a:	48 89 c2             	mov    %rax,%rdx
    6e0d:	48 c1 ea 09          	shr    $0x9,%rdx
    6e11:	48 31 d0             	xor    %rdx,%rax
    6e14:	0f b6 d0             	movzbl %al,%edx
    6e17:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6e1e:	00 
    6e1f:	48 85 c0             	test   %rax,%rax
    6e22:	75 29                	jne    6e4d <fwp_drop4+0x1dd>
    6e24:	e9 e3 00 00 00       	jmp    6f0c <fwp_drop4+0x29c>
    6e29:	90                   	nop
    6e2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e31:	00 00 00 00 
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	0f 84 bf 00 00 00    	je     6f0c <fwp_drop4+0x29c>
    6e4d:	48 89 c2             	mov    %rax,%rdx
    6e50:	48 39 08             	cmp    %rcx,(%rax)
    6e53:	75 eb                	jne    6e40 <fwp_drop4+0x1d0>
    6e55:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6e59:	48 83 ea 01          	sub    $0x1,%rdx
    6e5d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e61:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6e68:	0f 85 8d fe ff ff    	jne    6cfb <fwp_drop4+0x8b>
    6e6e:	48 89 cf             	mov    %rcx,%rdi
    6e71:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e75:	e8 d6 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6e7a:	48 8b 0c 24          	mov    (%rsp),%rcx
    6e7e:	c6 01 fe             	movb   $0xfe,(%rcx)
    6e81:	e9 75 fe ff ff       	jmp    6cfb <fwp_drop4+0x8b>
    6e86:	48 89 ce             	mov    %rcx,%rsi
    6e89:	48 c1 ee 11          	shr    $0x11,%rsi
    6e8d:	48 31 ce             	xor    %rcx,%rsi
    6e90:	48 89 f0             	mov    %rsi,%rax
    6e93:	48 c1 e8 09          	shr    $0x9,%rax
    6e97:	48 31 c6             	xor    %rax,%rsi
    6e9a:	40 0f b6 f6          	movzbl %sil,%esi
    6e9e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6ea5:	00 
    6ea6:	48 85 c0             	test   %rax,%rax
    6ea9:	75 1e                	jne    6ec9 <fwp_drop4+0x259>
    6eab:	eb 5f                	jmp    6f0c <fwp_drop4+0x29c>
    6ead:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6eb4:	00 
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 
    6ec0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	74 43                	je     6f0c <fwp_drop4+0x29c>
    6ec9:	48 89 c6             	mov    %rax,%rsi
    6ecc:	48 39 08             	cmp    %rcx,(%rax)
    6ecf:	75 ef                	jne    6ec0 <fwp_drop4+0x250>
    6ed1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ed5:	48 83 ee 01          	sub    $0x1,%rsi
    6ed9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6edd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6ee4:	0f 85 a6 fe ff ff    	jne    6d90 <fwp_drop4+0x120>
    6eea:	48 89 cf             	mov    %rcx,%rdi
    6eed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ef2:	48 89 0c 24          	mov    %rcx,(%rsp)
    6ef6:	e8 55 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6efb:	48 8b 0c 24          	mov    (%rsp),%rcx
    6eff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f04:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f07:	e9 84 fe ff ff       	jmp    6d90 <fwp_drop4+0x120>
    6f0c:	48 8d 3d 55 49 00 00 	lea    0x4955(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    6f13:	e8 d8 d4 ff ff       	call   43f0 <fwp_trap>
    6f18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f1f:	00 

0000000000006f20 <fwp_arg_drop37>:
    6f20:	f3 0f 1e fa          	endbr64
    6f24:	85 f6                	test   %esi,%esi
    6f26:	75 04                	jne    6f2c <fwp_arg_drop37+0xc>
    6f28:	85 d2                	test   %edx,%edx
    6f2a:	75 04                	jne    6f30 <fwp_arg_drop37+0x10>
    6f2c:	c3                   	ret
    6f2d:	0f 1f 00             	nopl   (%rax)
    6f30:	48 8b 3f             	mov    (%rdi),%rdi
    6f33:	e9 38 fd ff ff       	jmp    6c70 <fwp_drop4>
    6f38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f3f:	00 

0000000000006f40 <fwp_task_dispose>:
    6f40:	53                   	push   %rbx
    6f41:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f45:	0f 84 fb c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f4b:	48 89 fb             	mov    %rdi,%rbx
    6f4e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6f53:	0f 85 ed c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6f59:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6f5d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6f64:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6f6b:	00 
    6f6c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6f70:	48 85 ff             	test   %rdi,%rdi
    6f73:	74 07                	je     6f7c <fwp_task_dispose+0x3c>
    6f75:	48 85 c0             	test   %rax,%rax
    6f78:	74 02                	je     6f7c <fwp_task_dispose+0x3c>
    6f7a:	ff d0                	call   *%rax
    6f7c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6f83:	e8 08 e8 ff ff       	call   5790 <fwp_mem_free>
    6f88:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6f8f:	00 00 00 00 
    6f93:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6f97:	74 6f                	je     7008 <fwp_task_dispose+0xc8>
    6f99:	48 8b 15 f8 9b 01 00 	mov    0x19bf8(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    6fa0:	48 89 d8             	mov    %rbx,%rax
    6fa3:	48 2b 05 c6 9b 01 00 	sub    0x19bc6(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    6faa:	48 c1 e2 10          	shl    $0x10,%rdx
    6fae:	48 39 d0             	cmp    %rdx,%rax
    6fb1:	73 4c                	jae    6fff <fwp_task_dispose+0xbf>
    6fb3:	48 89 c2             	mov    %rax,%rdx
    6fb6:	48 c1 ea 10          	shr    $0x10,%rdx
    6fba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fbe:	48 8b 15 f3 9b 01 00 	mov    0x19bf3(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    6fc5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6fc9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6fcd:	48 85 c9             	test   %rcx,%rcx
    6fd0:	74 2d                	je     6fff <fwp_task_dispose+0xbf>
    6fd2:	0f b6 32             	movzbl (%rdx),%esi
    6fd5:	40 80 fe 02          	cmp    $0x2,%sil
    6fd9:	74 3d                	je     7018 <fwp_task_dispose+0xd8>
    6fdb:	40 80 fe 01          	cmp    $0x1,%sil
    6fdf:	75 1e                	jne    6fff <fwp_task_dispose+0xbf>
    6fe1:	8b 72 18             	mov    0x18(%rdx),%esi
    6fe4:	0f b7 c0             	movzwl %ax,%eax
    6fe7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6fea:	48 0f af c6          	imul   %rsi,%rax
    6fee:	48 c1 e8 20          	shr    $0x20,%rax
    6ff2:	48 39 d0             	cmp    %rdx,%rax
    6ff5:	73 08                	jae    6fff <fwp_task_dispose+0xbf>
    6ff7:	48 01 c1             	add    %rax,%rcx
    6ffa:	80 39 01             	cmpb   $0x1,(%rcx)
    6ffd:	74 09                	je     7008 <fwp_task_dispose+0xc8>
    6fff:	5b                   	pop    %rbx
    7000:	c3                   	ret
    7001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7008:	48 89 df             	mov    %rbx,%rdi
    700b:	5b                   	pop    %rbx
    700c:	e9 7f e7 ff ff       	jmp    5790 <fwp_mem_free>
    7011:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7018:	66 85 c0             	test   %ax,%ax
    701b:	74 dd                	je     6ffa <fwp_task_dispose+0xba>
    701d:	5b                   	pop    %rbx
    701e:	c3                   	ret
    701f:	90                   	nop

0000000000007020 <fwp_free_zombie>:
    7020:	48 8b 15 69 87 01 00 	mov    0x18769(%rip),%rdx        # 1f790 <fwp_zombie>
    7027:	48 85 d2             	test   %rdx,%rdx
    702a:	0f 84 98 00 00 00    	je     70c8 <fwp_free_zombie+0xa8>
    7030:	48 3b 15 69 87 01 00 	cmp    0x18769(%rip),%rdx        # 1f7a0 <fwp_cur>
    7037:	0f 84 8b 00 00 00    	je     70c8 <fwp_free_zombie+0xa8>
    703d:	48 83 ec 18          	sub    $0x18,%rsp
    7041:	48 63 05 1c 81 01 00 	movslq 0x1811c(%rip),%rax        # 1f164 <fwp_stack_pool_n>
    7048:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    704c:	83 f8 3f             	cmp    $0x3f,%eax
    704f:	7f 7f                	jg     70d0 <fwp_free_zombie+0xb0>
    7051:	8d 48 01             	lea    0x1(%rax),%ecx
    7054:	89 0d 0a 81 01 00    	mov    %ecx,0x1810a(%rip)        # 1f164 <fwp_stack_pool_n>
    705a:	48 8d 0d 1f 81 01 00 	lea    0x1811f(%rip),%rcx        # 1f180 <fwp_stack_pool>
    7061:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7065:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    706c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7070:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7077:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    707b:	48 85 c9             	test   %rcx,%rcx
    707e:	0f 84 fc 00 00 00    	je     7180 <fwp_free_zombie+0x160>
    7084:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    708b:	48 85 c0             	test   %rax,%rax
    708e:	74 07                	je     7097 <fwp_free_zombie+0x77>
    7090:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7097:	8b 42 5c             	mov    0x5c(%rdx),%eax
    709a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    709e:	48 c7 05 e7 86 01 00 	movq   $0x0,0x186e7(%rip)        # 1f790 <fwp_zombie>
    70a5:	00 00 00 00 
    70a9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    70b0:	85 c0                	test   %eax,%eax
    70b2:	74 34                	je     70e8 <fwp_free_zombie+0xc8>
    70b4:	83 f8 01             	cmp    $0x1,%eax
    70b7:	0f 84 b3 00 00 00    	je     7170 <fwp_free_zombie+0x150>
    70bd:	48 83 c4 18          	add    $0x18,%rsp
    70c1:	c3                   	ret
    70c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70c8:	c3                   	ret
    70c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70d0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    70d4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70d9:	e8 02 c5 ff ff       	call   35e0 <munmap@plt>
    70de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70e3:	eb 80                	jmp    7065 <fwp_free_zombie+0x45>
    70e5:	0f 1f 00             	nopl   (%rax)
    70e8:	48 8b 0d a9 9a 01 00 	mov    0x19aa9(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    70ef:	48 89 d0             	mov    %rdx,%rax
    70f2:	48 2b 05 77 9a 01 00 	sub    0x19a77(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    70f9:	48 c1 e1 10          	shl    $0x10,%rcx
    70fd:	48 39 c8             	cmp    %rcx,%rax
    7100:	73 bb                	jae    70bd <fwp_free_zombie+0x9d>
    7102:	48 89 c1             	mov    %rax,%rcx
    7105:	48 c1 e9 10          	shr    $0x10,%rcx
    7109:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    710d:	48 8b 0d a4 9a 01 00 	mov    0x19aa4(%rip),%rcx        # 20bb8 <fwp_heap+0x13f8>
    7114:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7118:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    711c:	48 85 c9             	test   %rcx,%rcx
    711f:	74 9c                	je     70bd <fwp_free_zombie+0x9d>
    7121:	0f b6 3e             	movzbl (%rsi),%edi
    7124:	40 80 ff 02          	cmp    $0x2,%dil
    7128:	74 66                	je     7190 <fwp_free_zombie+0x170>
    712a:	40 80 ff 01          	cmp    $0x1,%dil
    712e:	75 8d                	jne    70bd <fwp_free_zombie+0x9d>
    7130:	8b 7e 18             	mov    0x18(%rsi),%edi
    7133:	0f b7 c0             	movzwl %ax,%eax
    7136:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7139:	48 0f af c7          	imul   %rdi,%rax
    713d:	48 c1 e8 20          	shr    $0x20,%rax
    7141:	48 39 f0             	cmp    %rsi,%rax
    7144:	0f 83 73 ff ff ff    	jae    70bd <fwp_free_zombie+0x9d>
    714a:	48 01 c1             	add    %rax,%rcx
    714d:	0f b6 01             	movzbl (%rcx),%eax
    7150:	84 c0                	test   %al,%al
    7152:	0f 84 65 ff ff ff    	je     70bd <fwp_free_zombie+0x9d>
    7158:	3c 01                	cmp    $0x1,%al
    715a:	74 14                	je     7170 <fwp_free_zombie+0x150>
    715c:	3c ff                	cmp    $0xff,%al
    715e:	74 3b                	je     719b <fwp_free_zombie+0x17b>
    7160:	83 e8 01             	sub    $0x1,%eax
    7163:	88 01                	mov    %al,(%rcx)
    7165:	e9 53 ff ff ff       	jmp    70bd <fwp_free_zombie+0x9d>
    716a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7170:	48 89 d7             	mov    %rdx,%rdi
    7173:	48 83 c4 18          	add    $0x18,%rsp
    7177:	e9 c4 fd ff ff       	jmp    6f40 <fwp_task_dispose>
    717c:	0f 1f 40 00          	nopl   0x0(%rax)
    7180:	48 89 05 e1 85 01 00 	mov    %rax,0x185e1(%rip)        # 1f768 <fwp_tasks_active>
    7187:	e9 ff fe ff ff       	jmp    708b <fwp_free_zombie+0x6b>
    718c:	0f 1f 40 00          	nopl   0x0(%rax)
    7190:	66 85 c0             	test   %ax,%ax
    7193:	0f 85 24 ff ff ff    	jne    70bd <fwp_free_zombie+0x9d>
    7199:	eb b2                	jmp    714d <fwp_free_zombie+0x12d>
    719b:	48 89 ca             	mov    %rcx,%rdx
    719e:	48 8d 35 1b 86 01 00 	lea    0x1861b(%rip),%rsi        # 1f7c0 <fwp_heap>
    71a5:	48 c1 ea 11          	shr    $0x11,%rdx
    71a9:	48 31 ca             	xor    %rcx,%rdx
    71ac:	48 89 d0             	mov    %rdx,%rax
    71af:	48 c1 e8 09          	shr    $0x9,%rax
    71b3:	48 31 c2             	xor    %rax,%rdx
    71b6:	0f b6 d2             	movzbl %dl,%edx
    71b9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    71c0:	00 
    71c1:	48 85 c0             	test   %rax,%rax
    71c4:	75 23                	jne    71e9 <fwp_free_zombie+0x1c9>
    71c6:	eb 5c                	jmp    7224 <fwp_free_zombie+0x204>
    71c8:	66 90                	xchg   %ax,%ax
    71ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71d1:	00 00 00 00 
    71d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71dc:	00 00 00 00 
    71e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    71e4:	48 85 c0             	test   %rax,%rax
    71e7:	74 3b                	je     7224 <fwp_free_zombie+0x204>
    71e9:	48 89 c2             	mov    %rax,%rdx
    71ec:	48 39 08             	cmp    %rcx,(%rax)
    71ef:	75 ef                	jne    71e0 <fwp_free_zombie+0x1c0>
    71f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    71f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    71fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7204:	0f 85 b3 fe ff ff    	jne    70bd <fwp_free_zombie+0x9d>
    720a:	48 89 cf             	mov    %rcx,%rdi
    720d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7212:	e8 39 e3 ff ff       	call   5550 <fwp_rc_forget_slot>
    7217:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    721c:	c6 01 fe             	movb   $0xfe,(%rcx)
    721f:	e9 99 fe ff ff       	jmp    70bd <fwp_free_zombie+0x9d>
    7224:	48 8d 3d 3d 46 00 00 	lea    0x463d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    722b:	e8 c0 d1 ff ff       	call   43f0 <fwp_trap>

0000000000007230 <fwp_block>:
    7230:	48 83 ec 08          	sub    $0x8,%rsp
    7234:	48 8b 05 4d 85 01 00 	mov    0x1854d(%rip),%rax        # 1f788 <fwp_ready_head>
    723b:	48 85 c0             	test   %rax,%rax
    723e:	0f 84 1c 01 00 00    	je     7360 <fwp_block+0x130>
    7244:	90                   	nop
    7245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    724c:	00 00 00 00 
    7250:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7257:	48 89 15 2a 85 01 00 	mov    %rdx,0x1852a(%rip)        # 1f788 <fwp_ready_head>
    725e:	48 85 d2             	test   %rdx,%rdx
    7261:	0f 84 19 01 00 00    	je     7380 <fwp_block+0x150>
    7267:	48 8b 15 32 85 01 00 	mov    0x18532(%rip),%rdx        # 1f7a0 <fwp_cur>
    726e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7272:	48 39 c2             	cmp    %rax,%rdx
    7275:	0f 84 d5 00 00 00    	je     7350 <fwp_block+0x120>
    727b:	48 8b 0d a6 a1 01 00 	mov    0x1a1a6(%rip),%rcx        # 21428 <fwp_state_owners>
    7282:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7286:	48 89 05 13 85 01 00 	mov    %rax,0x18513(%rip)        # 1f7a0 <fwp_cur>
    728d:	f3 0f 7e 05 bb a1 01 	movq   0x1a1bb(%rip),%xmm0        # 21450 <fwp_foreign_callbacks>
    7294:	00 
    7295:	0f 16 05 a4 a1 01 00 	movhps 0x1a1a4(%rip),%xmm0        # 21440 <fwp_state>
    729c:	f3 0f 7e 0d a4 a1 01 	movq   0x1a1a4(%rip),%xmm1        # 21448 <fwp_handlers>
    72a3:	00 
    72a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    72ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    72b2:	0f 16 0d 9f a1 01 00 	movhps 0x1a19f(%rip),%xmm1        # 21458 <fwp_cleanups>
    72b9:	f3 0f 7e 05 77 a1 01 	movq   0x1a177(%rip),%xmm0        # 21438 <fwp_state_len>
    72c0:	00 
    72c1:	0f 16 05 68 a1 01 00 	movhps 0x1a168(%rip),%xmm0        # 21430 <fwp_state_cap>
    72c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    72cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    72d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    72e1:	48 89 0d 60 a1 01 00 	mov    %rcx,0x1a160(%rip)        # 21448 <fwp_handlers>
    72e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    72ef:	48 89 0d 62 a1 01 00 	mov    %rcx,0x1a162(%rip)        # 21458 <fwp_cleanups>
    72f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    72fd:	48 89 0d 4c a1 01 00 	mov    %rcx,0x1a14c(%rip)        # 21450 <fwp_foreign_callbacks>
    7304:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    730b:	48 89 0d 2e a1 01 00 	mov    %rcx,0x1a12e(%rip)        # 21440 <fwp_state>
    7312:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7319:	48 89 0d 18 a1 01 00 	mov    %rcx,0x1a118(%rip)        # 21438 <fwp_state_len>
    7320:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7327:	48 89 0d 02 a1 01 00 	mov    %rcx,0x1a102(%rip)        # 21430 <fwp_state_cap>
    732e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7335:	48 89 0d ec a0 01 00 	mov    %rcx,0x1a0ec(%rip)        # 21428 <fwp_state_owners>
    733c:	e8 4f c1 ff ff       	call   3490 <swapcontext@plt>
    7341:	f3 0f 1e fa          	endbr64
    7345:	e8 d6 fc ff ff       	call   7020 <fwp_free_zombie>
    734a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7350:	8b 05 0a 7e 01 00    	mov    0x17e0a(%rip),%eax        # 1f160 <fwp_slice>
    7356:	85 c0                	test   %eax,%eax
    7358:	74 36                	je     7390 <fwp_block+0x160>
    735a:	48 83 c4 08          	add    $0x8,%rsp
    735e:	c3                   	ret
    735f:	90                   	nop
    7360:	e8 3b de ff ff       	call   51a0 <fwp_poll_events>
    7365:	48 8b 05 1c 84 01 00 	mov    0x1841c(%rip),%rax        # 1f788 <fwp_ready_head>
    736c:	48 85 c0             	test   %rax,%rax
    736f:	0f 85 db fe ff ff    	jne    7250 <fwp_block+0x20>
    7375:	eb e9                	jmp    7360 <fwp_block+0x130>
    7377:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    737e:	00 00 
    7380:	48 c7 05 f5 83 01 00 	movq   $0x0,0x183f5(%rip)        # 1f780 <fwp_ready_tail>
    7387:	00 00 00 00 
    738b:	e9 d7 fe ff ff       	jmp    7267 <fwp_block+0x37>
    7390:	48 8d 3d ed 3d 00 00 	lea    0x3ded(%rip),%rdi        # b184 <_IO_stdin_used+0x184>
    7397:	e8 04 c0 ff ff       	call   33a0 <getenv@plt>
    739c:	ba 10 27 00 00       	mov    $0x2710,%edx
    73a1:	48 85 c0             	test   %rax,%rax
    73a4:	74 05                	je     73ab <fwp_block+0x17b>
    73a6:	80 38 00             	cmpb   $0x0,(%rax)
    73a9:	75 0b                	jne    73b6 <fwp_block+0x186>
    73ab:	89 15 af 7d 01 00    	mov    %edx,0x17daf(%rip)        # 1f160 <fwp_slice>
    73b1:	48 83 c4 08          	add    $0x8,%rsp
    73b5:	c3                   	ret
    73b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    73bb:	31 f6                	xor    %esi,%esi
    73bd:	48 89 c7             	mov    %rax,%rdi
    73c0:	e8 8b c1 ff ff       	call   3550 <strtoll@plt>
    73c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    73c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    73d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    73d5:	0f 46 d0             	cmovbe %eax,%edx
    73d8:	eb d1                	jmp    73ab <fwp_block+0x17b>
    73da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000073e0 <fwp_caps173>:
    73e0:	f3 0f 1e fa          	endbr64
    73e4:	85 f6                	test   %esi,%esi
    73e6:	74 08                	je     73f0 <fwp_caps173+0x10>
    73e8:	c3                   	ret
    73e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73f0:	48 8b 15 a1 97 01 00 	mov    0x197a1(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    73f7:	48 89 f8             	mov    %rdi,%rax
    73fa:	48 2b 05 6f 97 01 00 	sub    0x1976f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7401:	48 c1 e2 10          	shl    $0x10,%rdx
    7405:	48 39 d0             	cmp    %rdx,%rax
    7408:	73 de                	jae    73e8 <fwp_caps173+0x8>
    740a:	48 89 c2             	mov    %rax,%rdx
    740d:	48 c1 ea 10          	shr    $0x10,%rdx
    7411:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7415:	48 8b 15 9c 97 01 00 	mov    0x1979c(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    741c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7420:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7424:	48 85 c9             	test   %rcx,%rcx
    7427:	74 bf                	je     73e8 <fwp_caps173+0x8>
    7429:	0f b6 32             	movzbl (%rdx),%esi
    742c:	40 80 fe 02          	cmp    $0x2,%sil
    7430:	74 2e                	je     7460 <fwp_caps173+0x80>
    7432:	40 80 fe 01          	cmp    $0x1,%sil
    7436:	75 b0                	jne    73e8 <fwp_caps173+0x8>
    7438:	8b 72 18             	mov    0x18(%rdx),%esi
    743b:	0f b7 c0             	movzwl %ax,%eax
    743e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7441:	48 0f af c6          	imul   %rsi,%rax
    7445:	48 c1 e8 20          	shr    $0x20,%rax
    7449:	48 39 d0             	cmp    %rdx,%rax
    744c:	73 9a                	jae    73e8 <fwp_caps173+0x8>
    744e:	48 01 c1             	add    %rax,%rcx
    7451:	80 39 01             	cmpb   $0x1,(%rcx)
    7454:	75 92                	jne    73e8 <fwp_caps173+0x8>
    7456:	e9 35 e3 ff ff       	jmp    5790 <fwp_mem_free>
    745b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7460:	66 85 c0             	test   %ax,%ax
    7463:	74 ec                	je     7451 <fwp_caps173+0x71>
    7465:	c3                   	ret
    7466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    746d:	00 00 00 

0000000000007470 <fwp_args37>:
    7470:	f3 0f 1e fa          	endbr64
    7474:	85 d2                	test   %edx,%edx
    7476:	74 04                	je     747c <fwp_args37+0xc>
    7478:	85 f6                	test   %esi,%esi
    747a:	74 04                	je     7480 <fwp_args37+0x10>
    747c:	c3                   	ret
    747d:	0f 1f 00             	nopl   (%rax)
    7480:	48 8b 15 11 97 01 00 	mov    0x19711(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7487:	48 8b 07             	mov    (%rdi),%rax
    748a:	48 2b 05 df 96 01 00 	sub    0x196df(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7491:	48 c1 e2 10          	shl    $0x10,%rdx
    7495:	48 39 d0             	cmp    %rdx,%rax
    7498:	73 e2                	jae    747c <fwp_args37+0xc>
    749a:	48 89 c2             	mov    %rax,%rdx
    749d:	48 c1 ea 10          	shr    $0x10,%rdx
    74a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74a5:	48 8b 15 0c 97 01 00 	mov    0x1970c(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    74ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74b0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    74b4:	48 85 ff             	test   %rdi,%rdi
    74b7:	74 c3                	je     747c <fwp_args37+0xc>
    74b9:	0f b6 0a             	movzbl (%rdx),%ecx
    74bc:	80 f9 02             	cmp    $0x2,%cl
    74bf:	74 2f                	je     74f0 <fwp_args37+0x80>
    74c1:	80 f9 01             	cmp    $0x1,%cl
    74c4:	75 b6                	jne    747c <fwp_args37+0xc>
    74c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    74c9:	0f b7 c0             	movzwl %ax,%eax
    74cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74cf:	48 0f af c1          	imul   %rcx,%rax
    74d3:	48 c1 e8 20          	shr    $0x20,%rax
    74d7:	48 39 d0             	cmp    %rdx,%rax
    74da:	73 a0                	jae    747c <fwp_args37+0xc>
    74dc:	48 01 c7             	add    %rax,%rdi
    74df:	0f b6 07             	movzbl (%rdi),%eax
    74e2:	84 c0                	test   %al,%al
    74e4:	74 96                	je     747c <fwp_args37+0xc>
    74e6:	3c fd                	cmp    $0xfd,%al
    74e8:	77 0c                	ja     74f6 <fwp_args37+0x86>
    74ea:	83 c0 01             	add    $0x1,%eax
    74ed:	88 07                	mov    %al,(%rdi)
    74ef:	c3                   	ret
    74f0:	66 85 c0             	test   %ax,%ax
    74f3:	74 ea                	je     74df <fwp_args37+0x6f>
    74f5:	c3                   	ret
    74f6:	e9 35 df ff ff       	jmp    5430 <fwp_rc_wide_dup>
    74fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007500 <fwp_caps37>:
    7500:	f3 0f 1e fa          	endbr64
    7504:	48 83 ec 18          	sub    $0x18,%rsp
    7508:	8b 57 04             	mov    0x4(%rdi),%edx
    750b:	48 89 f8             	mov    %rdi,%rax
    750e:	85 d2                	test   %edx,%edx
    7510:	0f 84 9a 00 00 00    	je     75b0 <fwp_caps37+0xb0>
    7516:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    751a:	85 f6                	test   %esi,%esi
    751c:	0f 85 9e 00 00 00    	jne    75c0 <fwp_caps37+0xc0>
    7522:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7527:	e8 44 f7 ff ff       	call   6c70 <fwp_drop4>
    752c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7531:	48 8b 0d 60 96 01 00 	mov    0x19660(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    7538:	48 89 c2             	mov    %rax,%rdx
    753b:	48 2b 15 2e 96 01 00 	sub    0x1962e(%rip),%rdx        # 20b70 <fwp_heap+0x13b0>
    7542:	48 c1 e1 10          	shl    $0x10,%rcx
    7546:	48 39 ca             	cmp    %rcx,%rdx
    7549:	73 6d                	jae    75b8 <fwp_caps37+0xb8>
    754b:	48 89 d1             	mov    %rdx,%rcx
    754e:	48 c1 e9 10          	shr    $0x10,%rcx
    7552:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7556:	48 8b 0d 5b 96 01 00 	mov    0x1965b(%rip),%rcx        # 20bb8 <fwp_heap+0x13f8>
    755d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7561:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7565:	48 85 f6             	test   %rsi,%rsi
    7568:	74 4e                	je     75b8 <fwp_caps37+0xb8>
    756a:	0f b6 39             	movzbl (%rcx),%edi
    756d:	40 80 ff 02          	cmp    $0x2,%dil
    7571:	0f 84 b9 00 00 00    	je     7630 <fwp_caps37+0x130>
    7577:	40 80 ff 01          	cmp    $0x1,%dil
    757b:	75 3b                	jne    75b8 <fwp_caps37+0xb8>
    757d:	8b 79 18             	mov    0x18(%rcx),%edi
    7580:	0f b7 d2             	movzwl %dx,%edx
    7583:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7586:	48 0f af d7          	imul   %rdi,%rdx
    758a:	48 c1 ea 20          	shr    $0x20,%rdx
    758e:	48 39 ca             	cmp    %rcx,%rdx
    7591:	73 25                	jae    75b8 <fwp_caps37+0xb8>
    7593:	48 01 d6             	add    %rdx,%rsi
    7596:	80 3e 01             	cmpb   $0x1,(%rsi)
    7599:	75 1d                	jne    75b8 <fwp_caps37+0xb8>
    759b:	48 89 c7             	mov    %rax,%rdi
    759e:	48 83 c4 18          	add    $0x18,%rsp
    75a2:	e9 e9 e1 ff ff       	jmp    5790 <fwp_mem_free>
    75a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75ae:	00 00 
    75b0:	85 f6                	test   %esi,%esi
    75b2:	0f 84 79 ff ff ff    	je     7531 <fwp_caps37+0x31>
    75b8:	48 83 c4 18          	add    $0x18,%rsp
    75bc:	c3                   	ret
    75bd:	0f 1f 00             	nopl   (%rax)
    75c0:	48 8b 05 d1 95 01 00 	mov    0x195d1(%rip),%rax        # 20b98 <fwp_heap+0x13d8>
    75c7:	48 2b 3d a2 95 01 00 	sub    0x195a2(%rip),%rdi        # 20b70 <fwp_heap+0x13b0>
    75ce:	48 c1 e0 10          	shl    $0x10,%rax
    75d2:	48 39 c7             	cmp    %rax,%rdi
    75d5:	73 e1                	jae    75b8 <fwp_caps37+0xb8>
    75d7:	48 89 f8             	mov    %rdi,%rax
    75da:	48 c1 e8 10          	shr    $0x10,%rax
    75de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    75e2:	48 8b 05 cf 95 01 00 	mov    0x195cf(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    75e9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    75ed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    75f1:	48 85 c0             	test   %rax,%rax
    75f4:	74 c2                	je     75b8 <fwp_caps37+0xb8>
    75f6:	0f b6 0a             	movzbl (%rdx),%ecx
    75f9:	80 f9 02             	cmp    $0x2,%cl
    75fc:	74 42                	je     7640 <fwp_caps37+0x140>
    75fe:	80 f9 01             	cmp    $0x1,%cl
    7601:	75 b5                	jne    75b8 <fwp_caps37+0xb8>
    7603:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7606:	0f b7 ff             	movzwl %di,%edi
    7609:	8b 52 1c             	mov    0x1c(%rdx),%edx
    760c:	48 0f af f9          	imul   %rcx,%rdi
    7610:	48 c1 ef 20          	shr    $0x20,%rdi
    7614:	48 39 d7             	cmp    %rdx,%rdi
    7617:	73 9f                	jae    75b8 <fwp_caps37+0xb8>
    7619:	48 01 f8             	add    %rdi,%rax
    761c:	0f b6 10             	movzbl (%rax),%edx
    761f:	84 d2                	test   %dl,%dl
    7621:	74 95                	je     75b8 <fwp_caps37+0xb8>
    7623:	80 fa fd             	cmp    $0xfd,%dl
    7626:	77 23                	ja     764b <fwp_caps37+0x14b>
    7628:	83 c2 01             	add    $0x1,%edx
    762b:	88 10                	mov    %dl,(%rax)
    762d:	eb 89                	jmp    75b8 <fwp_caps37+0xb8>
    762f:	90                   	nop
    7630:	66 85 d2             	test   %dx,%dx
    7633:	0f 85 7f ff ff ff    	jne    75b8 <fwp_caps37+0xb8>
    7639:	e9 58 ff ff ff       	jmp    7596 <fwp_caps37+0x96>
    763e:	66 90                	xchg   %ax,%ax
    7640:	66 85 ff             	test   %di,%di
    7643:	0f 85 6f ff ff ff    	jne    75b8 <fwp_caps37+0xb8>
    7649:	eb d1                	jmp    761c <fwp_caps37+0x11c>
    764b:	48 89 c7             	mov    %rax,%rdi
    764e:	48 83 c4 18          	add    $0x18,%rsp
    7652:	e9 d9 dd ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7657:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    765e:	00 00 

0000000000007660 <fwp_drop0>:
    7660:	f3 0f 1e fa          	endbr64
    7664:	48 8b 15 2d 95 01 00 	mov    0x1952d(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    766b:	48 89 f8             	mov    %rdi,%rax
    766e:	48 2b 05 fb 94 01 00 	sub    0x194fb(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7675:	48 c1 e2 10          	shl    $0x10,%rdx
    7679:	48 39 d0             	cmp    %rdx,%rax
    767c:	0f 83 36 01 00 00    	jae    77b8 <fwp_drop0+0x158>
    7682:	48 83 ec 18          	sub    $0x18,%rsp
    7686:	48 8d 35 33 81 01 00 	lea    0x18133(%rip),%rsi        # 1f7c0 <fwp_heap>
    768d:	48 89 c2             	mov    %rax,%rdx
    7690:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7697:	48 c1 ea 10          	shr    $0x10,%rdx
    769b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    769f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    76a3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76a7:	48 85 d2             	test   %rdx,%rdx
    76aa:	74 42                	je     76ee <fwp_drop0+0x8e>
    76ac:	44 0f b6 01          	movzbl (%rcx),%r8d
    76b0:	41 80 f8 02          	cmp    $0x2,%r8b
    76b4:	74 42                	je     76f8 <fwp_drop0+0x98>
    76b6:	41 80 f8 01          	cmp    $0x1,%r8b
    76ba:	75 32                	jne    76ee <fwp_drop0+0x8e>
    76bc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    76c0:	0f b7 c0             	movzwl %ax,%eax
    76c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76c6:	49 0f af c0          	imul   %r8,%rax
    76ca:	48 c1 e8 20          	shr    $0x20,%rax
    76ce:	48 39 c8             	cmp    %rcx,%rax
    76d1:	73 1b                	jae    76ee <fwp_drop0+0x8e>
    76d3:	48 01 c2             	add    %rax,%rdx
    76d6:	0f b6 02             	movzbl (%rdx),%eax
    76d9:	84 c0                	test   %al,%al
    76db:	74 11                	je     76ee <fwp_drop0+0x8e>
    76dd:	3c 01                	cmp    $0x1,%al
    76df:	74 27                	je     7708 <fwp_drop0+0xa8>
    76e1:	3c ff                	cmp    $0xff,%al
    76e3:	0f 84 e7 00 00 00    	je     77d0 <fwp_drop0+0x170>
    76e9:	83 e8 01             	sub    $0x1,%eax
    76ec:	88 02                	mov    %al,(%rdx)
    76ee:	48 83 c4 18          	add    $0x18,%rsp
    76f2:	c3                   	ret
    76f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76f8:	66 85 c0             	test   %ax,%ax
    76fb:	74 d9                	je     76d6 <fwp_drop0+0x76>
    76fd:	48 83 c4 18          	add    $0x18,%rsp
    7701:	c3                   	ret
    7702:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7708:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    770f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7716:	48 89 f8             	mov    %rdi,%rax
    7719:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    771d:	48 29 c8             	sub    %rcx,%rax
    7720:	48 c1 e2 10          	shl    $0x10,%rdx
    7724:	48 39 d0             	cmp    %rdx,%rax
    7727:	73 71                	jae    779a <fwp_drop0+0x13a>
    7729:	49 89 c2             	mov    %rax,%r10
    772c:	49 c1 ea 10          	shr    $0x10,%r10
    7730:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7734:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7738:	4d 8b 51 20          	mov    0x20(%r9),%r10
    773c:	4d 85 d2             	test   %r10,%r10
    773f:	74 59                	je     779a <fwp_drop0+0x13a>
    7741:	45 0f b6 19          	movzbl (%r9),%r11d
    7745:	41 80 fb 02          	cmp    $0x2,%r11b
    7749:	74 75                	je     77c0 <fwp_drop0+0x160>
    774b:	41 80 fb 01          	cmp    $0x1,%r11b
    774f:	75 49                	jne    779a <fwp_drop0+0x13a>
    7751:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7755:	0f b7 c0             	movzwl %ax,%eax
    7758:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    775c:	49 0f af c3          	imul   %r11,%rax
    7760:	48 c1 e8 20          	shr    $0x20,%rax
    7764:	4c 39 c8             	cmp    %r9,%rax
    7767:	73 31                	jae    779a <fwp_drop0+0x13a>
    7769:	49 01 c2             	add    %rax,%r10
    776c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7770:	75 28                	jne    779a <fwp_drop0+0x13a>
    7772:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7777:	e8 14 e0 ff ff       	call   5790 <fwp_mem_free>
    777c:	48 8d 35 3d 80 01 00 	lea    0x1803d(%rip),%rsi        # 1f7c0 <fwp_heap>
    7783:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7788:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    778f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7796:	48 c1 e2 10          	shl    $0x10,%rdx
    779a:	4c 89 c0             	mov    %r8,%rax
    779d:	48 29 c8             	sub    %rcx,%rax
    77a0:	48 39 d0             	cmp    %rdx,%rax
    77a3:	0f 83 45 ff ff ff    	jae    76ee <fwp_drop0+0x8e>
    77a9:	4c 89 c7             	mov    %r8,%rdi
    77ac:	e9 dc fe ff ff       	jmp    768d <fwp_drop0+0x2d>
    77b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77b8:	c3                   	ret
    77b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77c0:	66 85 c0             	test   %ax,%ax
    77c3:	75 d5                	jne    779a <fwp_drop0+0x13a>
    77c5:	eb a5                	jmp    776c <fwp_drop0+0x10c>
    77c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77ce:	00 00 
    77d0:	48 89 d0             	mov    %rdx,%rax
    77d3:	48 c1 e8 11          	shr    $0x11,%rax
    77d7:	48 31 d0             	xor    %rdx,%rax
    77da:	48 89 c1             	mov    %rax,%rcx
    77dd:	48 c1 e9 09          	shr    $0x9,%rcx
    77e1:	48 31 c8             	xor    %rcx,%rax
    77e4:	0f b6 c8             	movzbl %al,%ecx
    77e7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    77ee:	00 
    77ef:	48 85 c0             	test   %rax,%rax
    77f2:	75 15                	jne    7809 <fwp_drop0+0x1a9>
    77f4:	eb 4e                	jmp    7844 <fwp_drop0+0x1e4>
    77f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    77fd:	00 00 00 
    7800:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7804:	48 85 c0             	test   %rax,%rax
    7807:	74 3b                	je     7844 <fwp_drop0+0x1e4>
    7809:	48 89 c1             	mov    %rax,%rcx
    780c:	48 39 10             	cmp    %rdx,(%rax)
    780f:	75 ef                	jne    7800 <fwp_drop0+0x1a0>
    7811:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7815:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7819:	48 89 48 08          	mov    %rcx,0x8(%rax)
    781d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7824:	0f 85 c4 fe ff ff    	jne    76ee <fwp_drop0+0x8e>
    782a:	48 89 d7             	mov    %rdx,%rdi
    782d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7832:	e8 19 dd ff ff       	call   5550 <fwp_rc_forget_slot>
    7837:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    783c:	c6 02 fe             	movb   $0xfe,(%rdx)
    783f:	e9 aa fe ff ff       	jmp    76ee <fwp_drop0+0x8e>
    7844:	48 8d 3d 1d 40 00 00 	lea    0x401d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    784b:	e8 a0 cb ff ff       	call   43f0 <fwp_trap>

0000000000007850 <fwp_drop1>:
    7850:	f3 0f 1e fa          	endbr64
    7854:	48 8b 15 3d 93 01 00 	mov    0x1933d(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    785b:	48 89 f8             	mov    %rdi,%rax
    785e:	48 2b 05 0b 93 01 00 	sub    0x1930b(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7865:	48 c1 e2 10          	shl    $0x10,%rdx
    7869:	48 39 d0             	cmp    %rdx,%rax
    786c:	0f 83 36 01 00 00    	jae    79a8 <fwp_drop1+0x158>
    7872:	48 83 ec 18          	sub    $0x18,%rsp
    7876:	48 8d 35 43 7f 01 00 	lea    0x17f43(%rip),%rsi        # 1f7c0 <fwp_heap>
    787d:	48 89 c2             	mov    %rax,%rdx
    7880:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7887:	48 c1 ea 10          	shr    $0x10,%rdx
    788b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    788f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7893:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7897:	48 85 d2             	test   %rdx,%rdx
    789a:	74 42                	je     78de <fwp_drop1+0x8e>
    789c:	44 0f b6 01          	movzbl (%rcx),%r8d
    78a0:	41 80 f8 02          	cmp    $0x2,%r8b
    78a4:	74 42                	je     78e8 <fwp_drop1+0x98>
    78a6:	41 80 f8 01          	cmp    $0x1,%r8b
    78aa:	75 32                	jne    78de <fwp_drop1+0x8e>
    78ac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    78b0:	0f b7 c0             	movzwl %ax,%eax
    78b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    78b6:	49 0f af c0          	imul   %r8,%rax
    78ba:	48 c1 e8 20          	shr    $0x20,%rax
    78be:	48 39 c8             	cmp    %rcx,%rax
    78c1:	73 1b                	jae    78de <fwp_drop1+0x8e>
    78c3:	48 01 c2             	add    %rax,%rdx
    78c6:	0f b6 02             	movzbl (%rdx),%eax
    78c9:	84 c0                	test   %al,%al
    78cb:	74 11                	je     78de <fwp_drop1+0x8e>
    78cd:	3c 01                	cmp    $0x1,%al
    78cf:	74 27                	je     78f8 <fwp_drop1+0xa8>
    78d1:	3c ff                	cmp    $0xff,%al
    78d3:	0f 84 e7 00 00 00    	je     79c0 <fwp_drop1+0x170>
    78d9:	83 e8 01             	sub    $0x1,%eax
    78dc:	88 02                	mov    %al,(%rdx)
    78de:	48 83 c4 18          	add    $0x18,%rsp
    78e2:	c3                   	ret
    78e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78e8:	66 85 c0             	test   %ax,%ax
    78eb:	74 d9                	je     78c6 <fwp_drop1+0x76>
    78ed:	48 83 c4 18          	add    $0x18,%rsp
    78f1:	c3                   	ret
    78f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78f8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    78ff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7906:	48 89 f8             	mov    %rdi,%rax
    7909:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    790d:	48 29 c8             	sub    %rcx,%rax
    7910:	48 c1 e2 10          	shl    $0x10,%rdx
    7914:	48 39 d0             	cmp    %rdx,%rax
    7917:	73 71                	jae    798a <fwp_drop1+0x13a>
    7919:	49 89 c2             	mov    %rax,%r10
    791c:	49 c1 ea 10          	shr    $0x10,%r10
    7920:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7924:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7928:	4d 8b 51 20          	mov    0x20(%r9),%r10
    792c:	4d 85 d2             	test   %r10,%r10
    792f:	74 59                	je     798a <fwp_drop1+0x13a>
    7931:	45 0f b6 19          	movzbl (%r9),%r11d
    7935:	41 80 fb 02          	cmp    $0x2,%r11b
    7939:	74 75                	je     79b0 <fwp_drop1+0x160>
    793b:	41 80 fb 01          	cmp    $0x1,%r11b
    793f:	75 49                	jne    798a <fwp_drop1+0x13a>
    7941:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7945:	0f b7 c0             	movzwl %ax,%eax
    7948:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    794c:	49 0f af c3          	imul   %r11,%rax
    7950:	48 c1 e8 20          	shr    $0x20,%rax
    7954:	4c 39 c8             	cmp    %r9,%rax
    7957:	73 31                	jae    798a <fwp_drop1+0x13a>
    7959:	49 01 c2             	add    %rax,%r10
    795c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7960:	75 28                	jne    798a <fwp_drop1+0x13a>
    7962:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7967:	e8 24 de ff ff       	call   5790 <fwp_mem_free>
    796c:	48 8d 35 4d 7e 01 00 	lea    0x17e4d(%rip),%rsi        # 1f7c0 <fwp_heap>
    7973:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7978:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    797f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7986:	48 c1 e2 10          	shl    $0x10,%rdx
    798a:	4c 89 c0             	mov    %r8,%rax
    798d:	48 29 c8             	sub    %rcx,%rax
    7990:	48 39 d0             	cmp    %rdx,%rax
    7993:	0f 83 45 ff ff ff    	jae    78de <fwp_drop1+0x8e>
    7999:	4c 89 c7             	mov    %r8,%rdi
    799c:	e9 dc fe ff ff       	jmp    787d <fwp_drop1+0x2d>
    79a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79a8:	c3                   	ret
    79a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79b0:	66 85 c0             	test   %ax,%ax
    79b3:	75 d5                	jne    798a <fwp_drop1+0x13a>
    79b5:	eb a5                	jmp    795c <fwp_drop1+0x10c>
    79b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79be:	00 00 
    79c0:	48 89 d0             	mov    %rdx,%rax
    79c3:	48 c1 e8 11          	shr    $0x11,%rax
    79c7:	48 31 d0             	xor    %rdx,%rax
    79ca:	48 89 c1             	mov    %rax,%rcx
    79cd:	48 c1 e9 09          	shr    $0x9,%rcx
    79d1:	48 31 c8             	xor    %rcx,%rax
    79d4:	0f b6 c8             	movzbl %al,%ecx
    79d7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    79de:	00 
    79df:	48 85 c0             	test   %rax,%rax
    79e2:	75 25                	jne    7a09 <fwp_drop1+0x1b9>
    79e4:	eb 5e                	jmp    7a44 <fwp_drop1+0x1f4>
    79e6:	0f 1f 40 00          	nopl   0x0(%rax)
    79ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    79f1:	00 00 00 00 
    79f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    79fc:	00 00 00 00 
    7a00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a04:	48 85 c0             	test   %rax,%rax
    7a07:	74 3b                	je     7a44 <fwp_drop1+0x1f4>
    7a09:	48 89 c1             	mov    %rax,%rcx
    7a0c:	48 39 10             	cmp    %rdx,(%rax)
    7a0f:	75 ef                	jne    7a00 <fwp_drop1+0x1b0>
    7a11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7a24:	0f 85 b4 fe ff ff    	jne    78de <fwp_drop1+0x8e>
    7a2a:	48 89 d7             	mov    %rdx,%rdi
    7a2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a32:	e8 19 db ff ff       	call   5550 <fwp_rc_forget_slot>
    7a37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7a3f:	e9 9a fe ff ff       	jmp    78de <fwp_drop1+0x8e>
    7a44:	48 8d 3d 1d 3e 00 00 	lea    0x3e1d(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7a4b:	e8 a0 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007a50 <fwp_drop10>:
    7a50:	48 8b 0d 41 91 01 00 	mov    0x19141(%rip),%rcx        # 20b98 <fwp_heap+0x13d8>
    7a57:	48 89 f8             	mov    %rdi,%rax
    7a5a:	48 2b 05 0f 91 01 00 	sub    0x1910f(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7a61:	48 c1 e1 10          	shl    $0x10,%rcx
    7a65:	48 39 c8             	cmp    %rcx,%rax
    7a68:	0f 83 c2 01 00 00    	jae    7c30 <fwp_drop10+0x1e0>
    7a6e:	48 83 ec 18          	sub    $0x18,%rsp
    7a72:	48 89 fa             	mov    %rdi,%rdx
    7a75:	48 8d 35 44 7d 01 00 	lea    0x17d44(%rip),%rsi        # 1f7c0 <fwp_heap>
    7a7c:	48 89 c1             	mov    %rax,%rcx
    7a7f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7a86:	48 c1 e9 10          	shr    $0x10,%rcx
    7a8a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7a8e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7a92:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7a96:	48 85 c9             	test   %rcx,%rcx
    7a99:	74 46                	je     7ae1 <fwp_drop10+0x91>
    7a9b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7a9f:	41 80 f9 02          	cmp    $0x2,%r9b
    7aa3:	0f 84 d7 00 00 00    	je     7b80 <fwp_drop10+0x130>
    7aa9:	41 80 f9 01          	cmp    $0x1,%r9b
    7aad:	75 32                	jne    7ae1 <fwp_drop10+0x91>
    7aaf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7ab3:	0f b7 c0             	movzwl %ax,%eax
    7ab6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7ab9:	49 0f af c1          	imul   %r9,%rax
    7abd:	48 c1 e8 20          	shr    $0x20,%rax
    7ac1:	48 39 f8             	cmp    %rdi,%rax
    7ac4:	73 1b                	jae    7ae1 <fwp_drop10+0x91>
    7ac6:	48 01 c1             	add    %rax,%rcx
    7ac9:	0f b6 01             	movzbl (%rcx),%eax
    7acc:	84 c0                	test   %al,%al
    7ace:	74 11                	je     7ae1 <fwp_drop10+0x91>
    7ad0:	3c 01                	cmp    $0x1,%al
    7ad2:	74 1c                	je     7af0 <fwp_drop10+0xa0>
    7ad4:	3c ff                	cmp    $0xff,%al
    7ad6:	0f 84 5c 01 00 00    	je     7c38 <fwp_drop10+0x1e8>
    7adc:	83 e8 01             	sub    $0x1,%eax
    7adf:	88 01                	mov    %al,(%rcx)
    7ae1:	48 83 c4 18          	add    $0x18,%rsp
    7ae5:	c3                   	ret
    7ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7aed:	00 00 00 
    7af0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7af7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7afe:	48 89 d0             	mov    %rdx,%rax
    7b01:	49 89 d1             	mov    %rdx,%r9
    7b04:	48 c1 e1 10          	shl    $0x10,%rcx
    7b08:	48 29 f8             	sub    %rdi,%rax
    7b0b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7b0f:	78 7f                	js     7b90 <fwp_drop10+0x140>
    7b11:	48 39 c8             	cmp    %rcx,%rax
    7b14:	73 cb                	jae    7ae1 <fwp_drop10+0x91>
    7b16:	48 89 c1             	mov    %rax,%rcx
    7b19:	48 c1 e9 10          	shr    $0x10,%rcx
    7b1d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b21:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7b25:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b29:	48 85 f6             	test   %rsi,%rsi
    7b2c:	74 b3                	je     7ae1 <fwp_drop10+0x91>
    7b2e:	0f b6 39             	movzbl (%rcx),%edi
    7b31:	40 80 ff 02          	cmp    $0x2,%dil
    7b35:	74 39                	je     7b70 <fwp_drop10+0x120>
    7b37:	40 80 ff 01          	cmp    $0x1,%dil
    7b3b:	75 a4                	jne    7ae1 <fwp_drop10+0x91>
    7b3d:	8b 79 18             	mov    0x18(%rcx),%edi
    7b40:	0f b7 c0             	movzwl %ax,%eax
    7b43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b46:	48 0f af c7          	imul   %rdi,%rax
    7b4a:	48 c1 e8 20          	shr    $0x20,%rax
    7b4e:	48 39 c8             	cmp    %rcx,%rax
    7b51:	73 8e                	jae    7ae1 <fwp_drop10+0x91>
    7b53:	48 01 c6             	add    %rax,%rsi
    7b56:	80 3e 01             	cmpb   $0x1,(%rsi)
    7b59:	75 86                	jne    7ae1 <fwp_drop10+0x91>
    7b5b:	48 89 d7             	mov    %rdx,%rdi
    7b5e:	48 83 c4 18          	add    $0x18,%rsp
    7b62:	e9 29 dc ff ff       	jmp    5790 <fwp_mem_free>
    7b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b6e:	00 00 
    7b70:	66 85 c0             	test   %ax,%ax
    7b73:	74 e1                	je     7b56 <fwp_drop10+0x106>
    7b75:	48 83 c4 18          	add    $0x18,%rsp
    7b79:	c3                   	ret
    7b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b80:	66 85 c0             	test   %ax,%ax
    7b83:	0f 84 40 ff ff ff    	je     7ac9 <fwp_drop10+0x79>
    7b89:	48 83 c4 18          	add    $0x18,%rsp
    7b8d:	c3                   	ret
    7b8e:	66 90                	xchg   %ax,%ax
    7b90:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7b94:	48 39 c8             	cmp    %rcx,%rax
    7b97:	73 74                	jae    7c0d <fwp_drop10+0x1bd>
    7b99:	49 89 c2             	mov    %rax,%r10
    7b9c:	49 c1 ea 10          	shr    $0x10,%r10
    7ba0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7ba4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7ba8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7bac:	4d 85 d2             	test   %r10,%r10
    7baf:	74 5c                	je     7c0d <fwp_drop10+0x1bd>
    7bb1:	45 0f b6 18          	movzbl (%r8),%r11d
    7bb5:	41 80 fb 02          	cmp    $0x2,%r11b
    7bb9:	74 6d                	je     7c28 <fwp_drop10+0x1d8>
    7bbb:	41 80 fb 01          	cmp    $0x1,%r11b
    7bbf:	75 4c                	jne    7c0d <fwp_drop10+0x1bd>
    7bc1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7bc5:	0f b7 c0             	movzwl %ax,%eax
    7bc8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7bcc:	49 0f af c3          	imul   %r11,%rax
    7bd0:	48 c1 e8 20          	shr    $0x20,%rax
    7bd4:	4c 39 c0             	cmp    %r8,%rax
    7bd7:	73 34                	jae    7c0d <fwp_drop10+0x1bd>
    7bd9:	49 01 c2             	add    %rax,%r10
    7bdc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7be0:	75 2b                	jne    7c0d <fwp_drop10+0x1bd>
    7be2:	4c 89 cf             	mov    %r9,%rdi
    7be5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bea:	e8 a1 db ff ff       	call   5790 <fwp_mem_free>
    7bef:	48 8d 35 ca 7b 01 00 	lea    0x17bca(%rip),%rsi        # 1f7c0 <fwp_heap>
    7bf6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7bfb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7c02:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7c09:	48 c1 e1 10          	shl    $0x10,%rcx
    7c0d:	48 89 d0             	mov    %rdx,%rax
    7c10:	48 29 f8             	sub    %rdi,%rax
    7c13:	48 39 c8             	cmp    %rcx,%rax
    7c16:	0f 82 60 fe ff ff    	jb     7a7c <fwp_drop10+0x2c>
    7c1c:	e9 c0 fe ff ff       	jmp    7ae1 <fwp_drop10+0x91>
    7c21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c28:	66 85 c0             	test   %ax,%ax
    7c2b:	75 e0                	jne    7c0d <fwp_drop10+0x1bd>
    7c2d:	eb ad                	jmp    7bdc <fwp_drop10+0x18c>
    7c2f:	90                   	nop
    7c30:	c3                   	ret
    7c31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c38:	48 89 c8             	mov    %rcx,%rax
    7c3b:	48 c1 e8 11          	shr    $0x11,%rax
    7c3f:	48 31 c8             	xor    %rcx,%rax
    7c42:	48 89 c2             	mov    %rax,%rdx
    7c45:	48 c1 ea 09          	shr    $0x9,%rdx
    7c49:	48 31 d0             	xor    %rdx,%rax
    7c4c:	0f b6 d0             	movzbl %al,%edx
    7c4f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7c56:	00 
    7c57:	48 85 c0             	test   %rax,%rax
    7c5a:	75 0d                	jne    7c69 <fwp_drop10+0x219>
    7c5c:	eb 46                	jmp    7ca4 <fwp_drop10+0x254>
    7c5e:	66 90                	xchg   %ax,%ax
    7c60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7c64:	48 85 c0             	test   %rax,%rax
    7c67:	74 3b                	je     7ca4 <fwp_drop10+0x254>
    7c69:	48 89 c2             	mov    %rax,%rdx
    7c6c:	48 39 08             	cmp    %rcx,(%rax)
    7c6f:	75 ef                	jne    7c60 <fwp_drop10+0x210>
    7c71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c75:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7c7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7c84:	0f 85 57 fe ff ff    	jne    7ae1 <fwp_drop10+0x91>
    7c8a:	48 89 cf             	mov    %rcx,%rdi
    7c8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c92:	e8 b9 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7c97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7c9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7c9f:	e9 3d fe ff ff       	jmp    7ae1 <fwp_drop10+0x91>
    7ca4:	48 8d 3d bd 3b 00 00 	lea    0x3bbd(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    7cab:	e8 40 c7 ff ff       	call   43f0 <fwp_trap>

0000000000007cb0 <f37>:
    7cb0:	41 57                	push   %r15
    7cb2:	41 56                	push   %r14
    7cb4:	41 55                	push   %r13
    7cb6:	41 54                	push   %r12
    7cb8:	55                   	push   %rbp
    7cb9:	53                   	push   %rbx
    7cba:	48 83 ec 38          	sub    $0x38,%rsp
    7cbe:	48 8b 15 d3 8e 01 00 	mov    0x18ed3(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7cc5:	48 8b 0d a4 8e 01 00 	mov    0x18ea4(%rip),%rcx        # 20b70 <fwp_heap+0x13b0>
    7ccc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7cd3:	00 00 
    7cd5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7cda:	49 89 fc             	mov    %rdi,%r12
    7cdd:	48 c1 e2 10          	shl    $0x10,%rdx
    7ce1:	48 85 ff             	test   %rdi,%rdi
    7ce4:	0f 84 bc 02 00 00    	je     7fa6 <f37+0x2f6>
    7cea:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7cef:	48 89 d8             	mov    %rbx,%rax
    7cf2:	48 29 c8             	sub    %rcx,%rax
    7cf5:	48 39 d0             	cmp    %rdx,%rax
    7cf8:	0f 83 72 03 00 00    	jae    8070 <f37+0x3c0>
    7cfe:	48 89 c2             	mov    %rax,%rdx
    7d01:	48 c1 ea 10          	shr    $0x10,%rdx
    7d05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d09:	48 8b 15 a8 8e 01 00 	mov    0x18ea8(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    7d10:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d14:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d18:	48 85 ff             	test   %rdi,%rdi
    7d1b:	0f 84 4f 03 00 00    	je     8070 <f37+0x3c0>
    7d21:	0f b6 0a             	movzbl (%rdx),%ecx
    7d24:	80 f9 02             	cmp    $0x2,%cl
    7d27:	0f 84 53 02 00 00    	je     7f80 <f37+0x2d0>
    7d2d:	80 f9 01             	cmp    $0x1,%cl
    7d30:	75 24                	jne    7d56 <f37+0xa6>
    7d32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d35:	0f b7 c0             	movzwl %ax,%eax
    7d38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d3b:	48 0f af c1          	imul   %rcx,%rax
    7d3f:	48 c1 e8 20          	shr    $0x20,%rax
    7d43:	48 39 d0             	cmp    %rdx,%rax
    7d46:	73 0e                	jae    7d56 <f37+0xa6>
    7d48:	48 01 c7             	add    %rax,%rdi
    7d4b:	0f b6 07             	movzbl (%rdi),%eax
    7d4e:	84 c0                	test   %al,%al
    7d50:	0f 85 ca 02 00 00    	jne    8020 <f37+0x370>
    7d56:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7d5b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7d60:	ba 01 00 00 00       	mov    $0x1,%edx
    7d65:	48 85 db             	test   %rbx,%rbx
    7d68:	74 13                	je     7d7d <f37+0xcd>
    7d6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d70:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7d74:	48 83 c2 01          	add    $0x1,%rdx
    7d78:	48 85 db             	test   %rbx,%rbx
    7d7b:	75 f3                	jne    7d70 <f37+0xc0>
    7d7d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d82:	48 85 c0             	test   %rax,%rax
    7d85:	0f 84 15 03 00 00    	je     80a0 <f37+0x3f0>
    7d8b:	31 db                	xor    %ebx,%ebx
    7d8d:	0f 1f 00             	nopl   (%rax)
    7d90:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d94:	48 83 c3 01          	add    $0x1,%rbx
    7d98:	48 85 c0             	test   %rax,%rax
    7d9b:	75 f3                	jne    7d90 <f37+0xe0>
    7d9d:	48 39 d3             	cmp    %rdx,%rbx
    7da0:	48 0f 47 da          	cmova  %rdx,%rbx
    7da4:	48 89 d8             	mov    %rbx,%rax
    7da7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7dab:	0f 85 8f 03 00 00    	jne    8140 <f37+0x490>
    7db1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7db5:	be 02 00 00 00       	mov    $0x2,%esi
    7dba:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7dc1:	00 
    7dc2:	e8 c9 de ff ff       	call   5c90 <fwp_heap_alloc>
    7dc7:	48 89 28             	mov    %rbp,(%rax)
    7dca:	48 8b 15 c7 8d 01 00 	mov    0x18dc7(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7dd1:	49 89 c6             	mov    %rax,%r14
    7dd4:	48 2b 05 95 8d 01 00 	sub    0x18d95(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7ddb:	48 c1 e2 10          	shl    $0x10,%rdx
    7ddf:	48 39 d0             	cmp    %rdx,%rax
    7de2:	73 57                	jae    7e3b <f37+0x18b>
    7de4:	48 89 c2             	mov    %rax,%rdx
    7de7:	48 c1 ea 10          	shr    $0x10,%rdx
    7deb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7def:	48 8b 15 c2 8d 01 00 	mov    0x18dc2(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    7df6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7dfa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7dfe:	48 85 ed             	test   %rbp,%rbp
    7e01:	74 38                	je     7e3b <f37+0x18b>
    7e03:	0f b6 0a             	movzbl (%rdx),%ecx
    7e06:	80 f9 02             	cmp    $0x2,%cl
    7e09:	0f 84 51 02 00 00    	je     8060 <f37+0x3b0>
    7e0f:	80 f9 01             	cmp    $0x1,%cl
    7e12:	75 27                	jne    7e3b <f37+0x18b>
    7e14:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e17:	0f b7 c0             	movzwl %ax,%eax
    7e1a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e1d:	48 0f af c1          	imul   %rcx,%rax
    7e21:	48 c1 e8 20          	shr    $0x20,%rax
    7e25:	48 39 d0             	cmp    %rdx,%rax
    7e28:	73 11                	jae    7e3b <f37+0x18b>
    7e2a:	48 01 c5             	add    %rax,%rbp
    7e2d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7e31:	0f 84 d5 02 00 00    	je     810c <f37+0x45c>
    7e37:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7e3b:	48 85 db             	test   %rbx,%rbx
    7e3e:	74 5d                	je     7e9d <f37+0x1ed>
    7e40:	48 c1 e3 04          	shl    $0x4,%rbx
    7e44:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7e49:	4c 89 f5             	mov    %r14,%rbp
    7e4c:	4d 89 e5             	mov    %r12,%r13
    7e4f:	4c 01 f3             	add    %r14,%rbx
    7e52:	0f 1f 00             	nopl   (%rax)
    7e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e5c:	00 00 00 00 
    7e60:	49 8b 45 08          	mov    0x8(%r13),%rax
    7e64:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7e68:	48 83 c5 10          	add    $0x10,%rbp
    7e6c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7e71:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7e75:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7e79:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7e7e:	e8 dd e3 ff ff       	call   6260 <w120>
    7e83:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7e88:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7e8c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7e90:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7e94:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7e98:	48 39 dd             	cmp    %rbx,%rbp
    7e9b:	75 c3                	jne    7e60 <f37+0x1b0>
    7e9d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7ea2:	e8 c9 ed ff ff       	call   6c70 <fwp_drop4>
    7ea7:	4c 89 e7             	mov    %r12,%rdi
    7eaa:	e8 c1 ed ff ff       	call   6c70 <fwp_drop4>
    7eaf:	4c 89 f7             	mov    %r14,%rdi
    7eb2:	e8 19 e5 ff ff       	call   63d0 <w176.constprop.0>
    7eb7:	4c 89 f7             	mov    %r14,%rdi
    7eba:	48 89 c3             	mov    %rax,%rbx
    7ebd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7ec3:	e8 88 fb ff ff       	call   7a50 <fwp_drop10>
    7ec8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7ece:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7ed3:	31 ff                	xor    %edi,%edi
    7ed5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7eda:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7ede:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7ee3:	e8 c8 de ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    7ee8:	48 8b 15 a9 8c 01 00 	mov    0x18ca9(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    7eef:	48 89 c5             	mov    %rax,%rbp
    7ef2:	48 2b 05 77 8c 01 00 	sub    0x18c77(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    7ef9:	48 c1 e2 10          	shl    $0x10,%rdx
    7efd:	48 39 d0             	cmp    %rdx,%rax
    7f00:	73 55                	jae    7f57 <f37+0x2a7>
    7f02:	48 89 c2             	mov    %rax,%rdx
    7f05:	48 c1 ea 10          	shr    $0x10,%rdx
    7f09:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f0d:	48 8b 15 a4 8c 01 00 	mov    0x18ca4(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    7f14:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f18:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7f1c:	48 85 db             	test   %rbx,%rbx
    7f1f:	74 36                	je     7f57 <f37+0x2a7>
    7f21:	0f b6 0a             	movzbl (%rdx),%ecx
    7f24:	80 f9 02             	cmp    $0x2,%cl
    7f27:	0f 84 1b 01 00 00    	je     8048 <f37+0x398>
    7f2d:	80 f9 01             	cmp    $0x1,%cl
    7f30:	75 25                	jne    7f57 <f37+0x2a7>
    7f32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f35:	0f b7 c0             	movzwl %ax,%eax
    7f38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f3b:	48 0f af c1          	imul   %rcx,%rax
    7f3f:	48 c1 e8 20          	shr    $0x20,%rax
    7f43:	48 39 d0             	cmp    %rdx,%rax
    7f46:	73 0f                	jae    7f57 <f37+0x2a7>
    7f48:	48 01 c3             	add    %rax,%rbx
    7f4b:	80 3b ff             	cmpb   $0xff,(%rbx)
    7f4e:	0f 84 ab 01 00 00    	je     80ff <f37+0x44f>
    7f54:	c6 03 01             	movb   $0x1,(%rbx)
    7f57:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7f5c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7f63:	00 00 
    7f65:	0f 85 d0 01 00 00    	jne    813b <f37+0x48b>
    7f6b:	48 83 c4 38          	add    $0x38,%rsp
    7f6f:	48 89 e8             	mov    %rbp,%rax
    7f72:	5b                   	pop    %rbx
    7f73:	5d                   	pop    %rbp
    7f74:	41 5c                	pop    %r12
    7f76:	41 5d                	pop    %r13
    7f78:	41 5e                	pop    %r14
    7f7a:	41 5f                	pop    %r15
    7f7c:	c3                   	ret
    7f7d:	0f 1f 00             	nopl   (%rax)
    7f80:	66 85 c0             	test   %ax,%ax
    7f83:	0f 85 cd fd ff ff    	jne    7d56 <f37+0xa6>
    7f89:	0f b6 07             	movzbl (%rdi),%eax
    7f8c:	84 c0                	test   %al,%al
    7f8e:	0f 84 c2 fd ff ff    	je     7d56 <f37+0xa6>
    7f94:	3c fd                	cmp    $0xfd,%al
    7f96:	0f 87 95 01 00 00    	ja     8131 <f37+0x481>
    7f9c:	83 c0 01             	add    $0x1,%eax
    7f9f:	88 07                	mov    %al,(%rdi)
    7fa1:	e9 b0 fd ff ff       	jmp    7d56 <f37+0xa6>
    7fa6:	48 f7 d9             	neg    %rcx
    7fa9:	48 39 d1             	cmp    %rdx,%rcx
    7fac:	0f 83 ee 00 00 00    	jae    80a0 <f37+0x3f0>
    7fb2:	48 89 c8             	mov    %rcx,%rax
    7fb5:	48 c1 e8 10          	shr    $0x10,%rax
    7fb9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7fbd:	48 8b 05 f4 8b 01 00 	mov    0x18bf4(%rip),%rax        # 20bb8 <fwp_heap+0x13f8>
    7fc4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7fc8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7fcc:	48 85 ff             	test   %rdi,%rdi
    7fcf:	0f 84 cb 00 00 00    	je     80a0 <f37+0x3f0>
    7fd5:	0f b6 02             	movzbl (%rdx),%eax
    7fd8:	3c 02                	cmp    $0x2,%al
    7fda:	0f 84 9a 00 00 00    	je     807a <f37+0x3ca>
    7fe0:	3c 01                	cmp    $0x1,%al
    7fe2:	0f 85 b8 00 00 00    	jne    80a0 <f37+0x3f0>
    7fe8:	0f b7 c1             	movzwl %cx,%eax
    7feb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ff1:	48 0f af c1          	imul   %rcx,%rax
    7ff5:	48 c1 e8 20          	shr    $0x20,%rax
    7ff9:	48 39 d0             	cmp    %rdx,%rax
    7ffc:	0f 83 9e 00 00 00    	jae    80a0 <f37+0x3f0>
    8002:	48 01 c7             	add    %rax,%rdi
    8005:	0f b6 07             	movzbl (%rdi),%eax
    8008:	84 c0                	test   %al,%al
    800a:	0f 84 90 00 00 00    	je     80a0 <f37+0x3f0>
    8010:	31 db                	xor    %ebx,%ebx
    8012:	0f 1f 00             	nopl   (%rax)
    8015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    801c:	00 00 00 00 
    8020:	3c fd                	cmp    $0xfd,%al
    8022:	0f 87 f1 00 00 00    	ja     8119 <f37+0x469>
    8028:	83 c0 01             	add    $0x1,%eax
    802b:	88 07                	mov    %al,(%rdi)
    802d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8032:	31 d2                	xor    %edx,%edx
    8034:	4d 85 e4             	test   %r12,%r12
    8037:	0f 85 1e fd ff ff    	jne    7d5b <f37+0xab>
    803d:	e9 3b fd ff ff       	jmp    7d7d <f37+0xcd>
    8042:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8048:	66 85 c0             	test   %ax,%ax
    804b:	0f 85 06 ff ff ff    	jne    7f57 <f37+0x2a7>
    8051:	e9 f5 fe ff ff       	jmp    7f4b <f37+0x29b>
    8056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    805d:	00 00 00 
    8060:	66 85 c0             	test   %ax,%ax
    8063:	0f 85 d2 fd ff ff    	jne    7e3b <f37+0x18b>
    8069:	e9 bf fd ff ff       	jmp    7e2d <f37+0x17d>
    806e:	66 90                	xchg   %ax,%ax
    8070:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8075:	e9 e6 fc ff ff       	jmp    7d60 <f37+0xb0>
    807a:	66 85 c9             	test   %cx,%cx
    807d:	75 21                	jne    80a0 <f37+0x3f0>
    807f:	0f b6 07             	movzbl (%rdi),%eax
    8082:	84 c0                	test   %al,%al
    8084:	74 1a                	je     80a0 <f37+0x3f0>
    8086:	3c fd                	cmp    $0xfd,%al
    8088:	0f 87 be 00 00 00    	ja     814c <f37+0x49c>
    808e:	83 c0 01             	add    $0x1,%eax
    8091:	88 07                	mov    %al,(%rdi)
    8093:	66 90                	xchg   %ax,%ax
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	be 02 00 00 00       	mov    $0x2,%esi
    80a5:	bf 08 00 00 00       	mov    $0x8,%edi
    80aa:	e8 e1 db ff ff       	call   5c90 <fwp_heap_alloc>
    80af:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    80b6:	48 8b 15 db 8a 01 00 	mov    0x18adb(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    80bd:	49 89 c6             	mov    %rax,%r14
    80c0:	48 2b 05 a9 8a 01 00 	sub    0x18aa9(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    80c7:	48 c1 e2 10          	shl    $0x10,%rdx
    80cb:	48 39 d0             	cmp    %rdx,%rax
    80ce:	73 53                	jae    8123 <f37+0x473>
    80d0:	48 89 c2             	mov    %rax,%rdx
    80d3:	48 c1 ea 10          	shr    $0x10,%rdx
    80d7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80db:	48 8b 15 d6 8a 01 00 	mov    0x18ad6(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    80e2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80e6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    80ea:	48 85 ed             	test   %rbp,%rbp
    80ed:	74 34                	je     8123 <f37+0x473>
    80ef:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    80f6:	00 00 
    80f8:	31 db                	xor    %ebx,%ebx
    80fa:	e9 04 fd ff ff       	jmp    7e03 <f37+0x153>
    80ff:	48 89 df             	mov    %rbx,%rdi
    8102:	e8 49 d4 ff ff       	call   5550 <fwp_rc_forget_slot>
    8107:	e9 48 fe ff ff       	jmp    7f54 <f37+0x2a4>
    810c:	48 89 ef             	mov    %rbp,%rdi
    810f:	e8 3c d4 ff ff       	call   5550 <fwp_rc_forget_slot>
    8114:	e9 1e fd ff ff       	jmp    7e37 <f37+0x187>
    8119:	e8 12 d3 ff ff       	call   5430 <fwp_rc_wide_dup>
    811e:	e9 0a ff ff ff       	jmp    802d <f37+0x37d>
    8123:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    812a:	00 00 
    812c:	e9 6c fd ff ff       	jmp    7e9d <f37+0x1ed>
    8131:	e8 fa d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    8136:	e9 1b fc ff ff       	jmp    7d56 <f37+0xa6>
    813b:	e8 20 b3 ff ff       	call   3460 <__stack_chk_fail@plt>
    8140:	48 8d 3d 49 30 00 00 	lea    0x3049(%rip),%rdi        # b190 <_IO_stdin_used+0x190>
    8147:	e8 a4 c2 ff ff       	call   43f0 <fwp_trap>
    814c:	e8 df d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    8151:	e9 4a ff ff ff       	jmp    80a0 <f37+0x3f0>
    8156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    815d:	00 00 00 

0000000000008160 <fwp_owned_entry37>:
    8160:	f3 0f 1e fa          	endbr64
    8164:	48 8b 3f             	mov    (%rdi),%rdi
    8167:	e9 44 fb ff ff       	jmp    7cb0 <f37>
    816c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008170 <e37>:
    8170:	f3 0f 1e fa          	endbr64
    8174:	53                   	push   %rbx
    8175:	48 8b 1f             	mov    (%rdi),%rbx
    8178:	48 89 df             	mov    %rbx,%rdi
    817b:	e8 d0 e2 ff ff       	call   6450 <fwp_rc_share>
    8180:	48 89 df             	mov    %rbx,%rdi
    8183:	e8 28 fb ff ff       	call   7cb0 <f37>
    8188:	48 89 c3             	mov    %rax,%rbx
    818b:	48 89 c7             	mov    %rax,%rdi
    818e:	e8 bd e2 ff ff       	call   6450 <fwp_rc_share>
    8193:	48 89 d8             	mov    %rbx,%rax
    8196:	5b                   	pop    %rbx
    8197:	c3                   	ret
    8198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    819f:	00 

00000000000081a0 <fwp_write>:
    81a0:	41 57                	push   %r15
    81a2:	41 56                	push   %r14
    81a4:	41 55                	push   %r13
    81a6:	41 54                	push   %r12
    81a8:	55                   	push   %rbp
    81a9:	53                   	push   %rbx
    81aa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    81b1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    81b8:	00 00 
    81ba:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    81c1:	00 
    81c2:	49 89 d4             	mov    %rdx,%r12
    81c5:	8b 12                	mov    (%rdx),%edx
    81c7:	83 fa 19             	cmp    $0x19,%edx
    81ca:	77 6a                	ja     8236 <fwp_write+0x96>
    81cc:	48 89 f5             	mov    %rsi,%rbp
    81cf:	89 d0                	mov    %edx,%eax
    81d1:	89 ce                	mov    %ecx,%esi
    81d3:	48 89 fb             	mov    %rdi,%rbx
    81d6:	48 8d 0d 73 38 00 00 	lea    0x3873(%rip),%rcx        # ba50 <_IO_stdin_used+0xa50>
    81dd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    81e1:	48 01 c8             	add    %rcx,%rax
    81e4:	3e ff e0             	notrack jmp *%rax
    81e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ee:	00 00 
    81f0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    81f4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    81f8:	48 89 ca             	mov    %rcx,%rdx
    81fb:	48 85 c9             	test   %rcx,%rcx
    81fe:	0f 88 9c 0c 00 00    	js     8ea0 <fwp_write+0xd00>
    8204:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    820b:	00 
    820c:	48 89 c6             	mov    %rax,%rsi
    820f:	4c 89 e7             	mov    %r12,%rdi
    8212:	e8 29 b8 ff ff       	call   3a40 <fwp_fmt_u128>
    8217:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    821e:	00 00 
    8220:	4c 89 e7             	mov    %r12,%rdi
    8223:	e8 28 b2 ff ff       	call   3450 <strlen@plt>
    8228:	4c 89 e6             	mov    %r12,%rsi
    822b:	48 89 df             	mov    %rbx,%rdi
    822e:	48 89 c2             	mov    %rax,%rdx
    8231:	e8 da bf ff ff       	call   4210 <buf_put>
    8236:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    823d:	00 
    823e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8245:	00 00 
    8247:	0f 85 28 04 00 00    	jne    8675 <fwp_write+0x4d5>
    824d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8254:	5b                   	pop    %rbx
    8255:	5d                   	pop    %rbp
    8256:	41 5c                	pop    %r12
    8258:	41 5d                	pop    %r13
    825a:	41 5e                	pop    %r14
    825c:	41 5f                	pop    %r15
    825e:	c3                   	ret
    825f:	90                   	nop
    8260:	49 89 e9             	mov    %rbp,%r9
    8263:	4c 8d 05 0b 2e 00 00 	lea    0x2e0b(%rip),%r8        # b075 <_IO_stdin_used+0x75>
    826a:	b9 00 02 00 00       	mov    $0x200,%ecx
    826f:	ba 02 00 00 00       	mov    $0x2,%edx
    8274:	be 00 02 00 00       	mov    $0x200,%esi
    8279:	31 c0                	xor    %eax,%eax
    827b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8282:	00 
    8283:	e8 28 b1 ff ff       	call   33b0 <__snprintf_chk@plt>
    8288:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    828f:	00 
    8290:	e8 bb b1 ff ff       	call   3450 <strlen@plt>
    8295:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    829c:	00 
    829d:	48 89 df             	mov    %rbx,%rdi
    82a0:	48 89 c2             	mov    %rax,%rdx
    82a3:	e8 68 bf ff ff       	call   4210 <buf_put>
    82a8:	eb 8c                	jmp    8236 <fwp_write+0x96>
    82aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82b0:	49 89 e9             	mov    %rbp,%r9
    82b3:	4c 8d 05 fb 2e 00 00 	lea    0x2efb(%rip),%r8        # b1b5 <_IO_stdin_used+0x1b5>
    82ba:	eb ae                	jmp    826a <fwp_write+0xca>
    82bc:	0f 1f 40 00          	nopl   0x0(%rax)
    82c0:	83 fa 13             	cmp    $0x13,%edx
    82c3:	48 8d 05 e1 2e 00 00 	lea    0x2ee1(%rip),%rax        # b1ab <_IO_stdin_used+0x1ab>
    82ca:	48 8d 35 df 2e 00 00 	lea    0x2edf(%rip),%rsi        # b1b0 <_IO_stdin_used+0x1b0>
    82d1:	ba 04 00 00 00       	mov    $0x4,%edx
    82d6:	48 0f 44 f0          	cmove  %rax,%rsi
    82da:	45 31 ed             	xor    %r13d,%r13d
    82dd:	e8 2e bf ff ff       	call   4210 <buf_put>
    82e2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    82e7:	0f 84 a3 08 00 00    	je     8b90 <fwp_write+0x9f0>
    82ed:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    82f2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    82f7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    82fc:	48 89 df             	mov    %rbx,%rdi
    82ff:	49 0f 44 c5          	cmove  %r13,%rax
    8303:	31 c9                	xor    %ecx,%ecx
    8305:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    830a:	e8 91 fe ff ff       	call   81a0 <fwp_write>
    830f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8314:	0f 84 6e 09 00 00    	je     8c88 <fwp_write+0xae8>
    831a:	49 83 c5 01          	add    $0x1,%r13
    831e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8322:	0f 83 68 08 00 00    	jae    8b90 <fwp_write+0x9f0>
    8328:	ba 02 00 00 00       	mov    $0x2,%edx
    832d:	48 8d 35 c1 2e 00 00 	lea    0x2ec1(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8334:	48 89 df             	mov    %rbx,%rdi
    8337:	e8 d4 be ff ff       	call   4210 <buf_put>
    833c:	eb af                	jmp    82ed <fwp_write+0x14d>
    833e:	66 90                	xchg   %ax,%ax
    8340:	ba 06 00 00 00       	mov    $0x6,%edx
    8345:	48 8d 35 82 2e 00 00 	lea    0x2e82(%rip),%rsi        # b1ce <_IO_stdin_used+0x1ce>
    834c:	48 83 c5 10          	add    $0x10,%rbp
    8350:	e8 bb be ff ff       	call   4210 <buf_put>
    8355:	48 89 ef             	mov    %rbp,%rdi
    8358:	e8 f3 b0 ff ff       	call   3450 <strlen@plt>
    835d:	48 89 ee             	mov    %rbp,%rsi
    8360:	48 89 df             	mov    %rbx,%rdi
    8363:	48 89 c2             	mov    %rax,%rdx
    8366:	e8 a5 be ff ff       	call   4210 <buf_put>
    836b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8370:	ba 01 00 00 00       	mov    $0x1,%edx
    8375:	48 89 df             	mov    %rbx,%rdi
    8378:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    837d:	e8 8e be ff ff       	call   4210 <buf_put>
    8382:	e9 af fe ff ff       	jmp    8236 <fwp_write+0x96>
    8387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    838e:	00 00 
    8390:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8397:	00 
    8398:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    839f:	00 00 
    83a1:	0f 85 ce 02 00 00    	jne    8675 <fwp_write+0x4d5>
    83a7:	ba 0a 00 00 00       	mov    $0xa,%edx
    83ac:	48 8d 35 07 2e 00 00 	lea    0x2e07(%rip),%rsi        # b1ba <_IO_stdin_used+0x1ba>
    83b3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    83ba:	48 89 df             	mov    %rbx,%rdi
    83bd:	5b                   	pop    %rbx
    83be:	5d                   	pop    %rbp
    83bf:	41 5c                	pop    %r12
    83c1:	41 5d                	pop    %r13
    83c3:	41 5e                	pop    %r14
    83c5:	41 5f                	pop    %r15
    83c7:	e9 44 be ff ff       	jmp    4210 <buf_put>
    83cc:	0f 1f 40 00          	nopl   0x0(%rax)
    83d0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    83d5:	4d 85 ed             	test   %r13,%r13
    83d8:	0f 84 02 0c 00 00    	je     8fe0 <fwp_write+0xe40>
    83de:	48 8d 35 1d 2e 00 00 	lea    0x2e1d(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    83e5:	4c 89 ef             	mov    %r13,%rdi
    83e8:	e8 43 b1 ff ff       	call   3530 <strcmp@plt>
    83ed:	41 89 c1             	mov    %eax,%r9d
    83f0:	85 c0                	test   %eax,%eax
    83f2:	0f 84 6c 0c 00 00    	je     9064 <fwp_write+0xec4>
    83f8:	4c 89 ef             	mov    %r13,%rdi
    83fb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8400:	e8 4b b0 ff ff       	call   3450 <strlen@plt>
    8405:	4c 89 ee             	mov    %r13,%rsi
    8408:	48 89 df             	mov    %rbx,%rdi
    840b:	48 89 c2             	mov    %rax,%rdx
    840e:	e8 fd bd ff ff       	call   4210 <buf_put>
    8413:	ba 01 00 00 00       	mov    $0x1,%edx
    8418:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    841d:	48 89 df             	mov    %rbx,%rdi
    8420:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8425:	e8 e6 bd ff ff       	call   4210 <buf_put>
    842a:	ba 01 00 00 00       	mov    $0x1,%edx
    842f:	4c 89 fe             	mov    %r15,%rsi
    8432:	48 89 df             	mov    %rbx,%rdi
    8435:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    843a:	e8 d1 bd ff ff       	call   4210 <buf_put>
    843f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8444:	45 31 f6             	xor    %r14d,%r14d
    8447:	85 d2                	test   %edx,%edx
    8449:	0f 8e 81 0a 00 00    	jle    8ed0 <fwp_write+0xd30>
    844f:	45 31 ed             	xor    %r13d,%r13d
    8452:	4d 85 ed             	test   %r13,%r13
    8455:	0f 85 75 07 00 00    	jne    8bd0 <fwp_write+0xa30>
    845b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8462:	00 
    8463:	45 85 f6             	test   %r14d,%r14d
    8466:	0f 84 84 07 00 00    	je     8bf0 <fwp_write+0xa50>
    846c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8471:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8476:	48 89 df             	mov    %rbx,%rdi
    8479:	49 83 c5 01          	add    $0x1,%r13
    847d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8481:	31 c9                	xor    %ecx,%ecx
    8483:	e8 18 fd ff ff       	call   81a0 <fwp_write>
    8488:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    848d:	7f c3                	jg     8452 <fwp_write+0x2b2>
    848f:	45 85 f6             	test   %r14d,%r14d
    8492:	0f 84 38 0a 00 00    	je     8ed0 <fwp_write+0xd30>
    8498:	b8 29 00 00 00       	mov    $0x29,%eax
    849d:	ba 01 00 00 00       	mov    $0x1,%edx
    84a2:	4c 89 fe             	mov    %r15,%rsi
    84a5:	48 89 df             	mov    %rbx,%rdi
    84a8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    84ac:	e8 5f bd ff ff       	call   4210 <buf_put>
    84b1:	e9 80 fd ff ff       	jmp    8236 <fwp_write+0x96>
    84b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84bd:	00 00 00 
    84c0:	ba 01 00 00 00       	mov    $0x1,%edx
    84c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    84ca:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    84cf:	e8 3c bd ff ff       	call   4210 <buf_put>
    84d4:	48 85 ed             	test   %rbp,%rbp
    84d7:	0f 84 93 06 00 00    	je     8b70 <fwp_write+0x9d0>
    84dd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    84e1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    84e6:	31 c9                	xor    %ecx,%ecx
    84e8:	48 89 df             	mov    %rbx,%rdi
    84eb:	e8 b0 fc ff ff       	call   81a0 <fwp_write>
    84f0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    84f4:	48 85 ed             	test   %rbp,%rbp
    84f7:	0f 84 73 06 00 00    	je     8b70 <fwp_write+0x9d0>
    84fd:	ba 02 00 00 00       	mov    $0x2,%edx
    8502:	48 8d 35 ec 2c 00 00 	lea    0x2cec(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8509:	48 89 df             	mov    %rbx,%rdi
    850c:	e8 ff bc ff ff       	call   4210 <buf_put>
    8511:	eb ca                	jmp    84dd <fwp_write+0x33d>
    8513:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8518:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    851c:	85 f6                	test   %esi,%esi
    851e:	0f 84 fc 07 00 00    	je     8d20 <fwp_write+0xb80>
    8524:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    852b:	00 
    852c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8533:	00 00 
    8535:	0f 85 3a 01 00 00    	jne    8675 <fwp_write+0x4d5>
    853b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    853f:	4c 89 ea             	mov    %r13,%rdx
    8542:	e9 6c fe ff ff       	jmp    83b3 <fwp_write+0x213>
    8547:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    854e:	00 00 
    8550:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8555:	ba 01 00 00 00       	mov    $0x1,%edx
    855a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    855f:	48 89 ee             	mov    %rbp,%rsi
    8562:	e8 a9 bc ff ff       	call   4210 <buf_put>
    8567:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    856c:	4c 89 e7             	mov    %r12,%rdi
    856f:	e8 dc ae ff ff       	call   3450 <strlen@plt>
    8574:	4c 89 e6             	mov    %r12,%rsi
    8577:	48 89 df             	mov    %rbx,%rdi
    857a:	48 89 c2             	mov    %rax,%rdx
    857d:	e8 8e bc ff ff       	call   4210 <buf_put>
    8582:	ba 01 00 00 00       	mov    $0x1,%edx
    8587:	48 89 ee             	mov    %rbp,%rsi
    858a:	48 89 df             	mov    %rbx,%rdi
    858d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8592:	e8 79 bc ff ff       	call   4210 <buf_put>
    8597:	e9 9a fc ff ff       	jmp    8236 <fwp_write+0x96>
    859c:	0f 1f 40 00          	nopl   0x0(%rax)
    85a0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    85a5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    85a9:	0f 8a 8e 0b 00 00    	jp     913d <fwp_write+0xf9d>
    85af:	66 0f 28 c1          	movapd %xmm1,%xmm0
    85b3:	66 0f 54 05 95 35 00 	andpd  0x3595(%rip),%xmm0        # bb50 <msg.4+0x90>
    85ba:	00 
    85bb:	bd 01 00 00 00       	mov    $0x1,%ebp
    85c0:	66 0f 2e 05 b8 35 00 	ucomisd 0x35b8(%rip),%xmm0        # bb80 <msg.4+0xc0>
    85c7:	00 
    85c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    85cf:	00 
    85d0:	0f 87 b2 09 00 00    	ja     8f88 <fwp_write+0xde8>
    85d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85dd:	00 00 00 
    85e0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    85e4:	89 ee                	mov    %ebp,%esi
    85e6:	4c 89 e7             	mov    %r12,%rdi
    85e9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    85ee:	e8 1d c1 ff ff       	call   4710 <fwp_format_g.constprop.0>
    85f3:	31 f6                	xor    %esi,%esi
    85f5:	4c 89 e7             	mov    %r12,%rdi
    85f8:	e8 13 ae ff ff       	call   3410 <strtod@plt>
    85fd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8602:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8606:	7a 06                	jp     860e <fwp_write+0x46e>
    8608:	0f 84 e9 01 00 00    	je     87f7 <fwp_write+0x657>
    860e:	83 c5 01             	add    $0x1,%ebp
    8611:	83 fd 12             	cmp    $0x12,%ebp
    8614:	75 ca                	jne    85e0 <fwp_write+0x440>
    8616:	be 11 00 00 00       	mov    $0x11,%esi
    861b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    861f:	4c 89 e7             	mov    %r12,%rdi
    8622:	e8 e9 c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8627:	e9 cb 01 00 00       	jmp    87f7 <fwp_write+0x657>
    862c:	0f 1f 40 00          	nopl   0x0(%rax)
    8630:	48 83 fd 01          	cmp    $0x1,%rbp
    8634:	0f 84 e6 08 00 00    	je     8f20 <fwp_write+0xd80>
    863a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    863e:	b8 02 00 00 00       	mov    $0x2,%eax
    8643:	ba 01 00 00 00       	mov    $0x1,%edx
    8648:	48 0f 44 d0          	cmove  %rax,%rdx
    864c:	48 8d 35 50 2b 00 00 	lea    0x2b50(%rip),%rsi        # b1a3 <_IO_stdin_used+0x1a3>
    8653:	48 8d 05 4e 2b 00 00 	lea    0x2b4e(%rip),%rax        # b1a8 <_IO_stdin_used+0x1a8>
    865a:	48 0f 44 f0          	cmove  %rax,%rsi
    865e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8665:	00 
    8666:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    866d:	00 00 
    866f:	0f 84 3e fd ff ff    	je     83b3 <fwp_write+0x213>
    8675:	e8 e6 ad ff ff       	call   3460 <__stack_chk_fail@plt>
    867a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8680:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8685:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    868a:	e8 c1 ba ff ff       	call   4150 <buf_grow>
    868f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8693:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8699:	4c 03 0b             	add    (%rbx),%r9
    869c:	66 45 89 11          	mov    %r10w,(%r9)
    86a0:	45 85 e4             	test   %r12d,%r12d
    86a3:	0f 8e 07 05 00 00    	jle    8bb0 <fwp_write+0xa10>
    86a9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    86b0:	55 55 55 
    86b3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    86b8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    86bf:	aa aa aa 
    86c2:	49 83 c1 01          	add    $0x1,%r9
    86c6:	eb 45                	jmp    870d <fwp_write+0x56d>
    86c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86cf:	00 
    86d0:	be 01 00 00 00       	mov    $0x1,%esi
    86d5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    86da:	88 07                	mov    %al,(%rdi)
    86dc:	48 89 e8             	mov    %rbp,%rax
    86df:	49 f7 e8             	imul   %r8
    86e2:	48 89 e8             	mov    %rbp,%rax
    86e5:	48 c1 f8 3f          	sar    $0x3f,%rax
    86e9:	48 29 c2             	sub    %rax,%rdx
    86ec:	48 85 c9             	test   %rcx,%rcx
    86ef:	0f 95 c0             	setne  %al
    86f2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    86f6:	48 83 ef 01          	sub    $0x1,%rdi
    86fa:	48 21 c5             	and    %rax,%rbp
    86fd:	48 29 ea             	sub    %rbp,%rdx
    8700:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8704:	49 39 f9             	cmp    %rdi,%r9
    8707:	0f 84 a3 04 00 00    	je     8bb0 <fwp_write+0xa10>
    870d:	48 89 e8             	mov    %rbp,%rax
    8710:	49 f7 e8             	imul   %r8
    8713:	48 89 e8             	mov    %rbp,%rax
    8716:	48 c1 f8 3f          	sar    $0x3f,%rax
    871a:	48 89 d1             	mov    %rdx,%rcx
    871d:	48 29 c1             	sub    %rax,%rcx
    8720:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8724:	48 89 e9             	mov    %rbp,%rcx
    8727:	48 29 c1             	sub    %rax,%rcx
    872a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    872e:	49 f7 e2             	mul    %r10
    8731:	b8 30 00 00 00       	mov    $0x30,%eax
    8736:	48 89 d6             	mov    %rdx,%rsi
    8739:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    873d:	48 d1 ee             	shr    $1,%rsi
    8740:	48 01 f2             	add    %rsi,%rdx
    8743:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8747:	48 29 d6             	sub    %rdx,%rsi
    874a:	74 8e                	je     86da <fwp_write+0x53a>
    874c:	48 83 fe 01          	cmp    $0x1,%rsi
    8750:	0f 85 7a ff ff ff    	jne    86d0 <fwp_write+0x530>
    8756:	31 f6                	xor    %esi,%esi
    8758:	b8 2b 00 00 00       	mov    $0x2b,%eax
    875d:	e9 78 ff ff ff       	jmp    86da <fwp_write+0x53a>
    8762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8768:	66 0f 6e cd          	movd   %ebp,%xmm1
    876c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    876f:	0f 8a c8 09 00 00    	jp     913d <fwp_write+0xf9d>
    8775:	0f 28 c1             	movaps %xmm1,%xmm0
    8778:	0f 54 05 c1 33 00 00 	andps  0x33c1(%rip),%xmm0        # bb40 <msg.4+0x80>
    877f:	0f 2e 05 7e 28 00 00 	ucomiss 0x287e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    8786:	0f 87 24 08 00 00    	ja     8fb0 <fwp_write+0xe10>
    878c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8790:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8796:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    879d:	00 
    879e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    87a2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    87a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87ae:	00 00 
    87b0:	44 89 ee             	mov    %r13d,%esi
    87b3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    87b8:	4c 89 e7             	mov    %r12,%rdi
    87bb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    87c0:	e8 4b bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    87c5:	31 f6                	xor    %esi,%esi
    87c7:	4c 89 e7             	mov    %r12,%rdi
    87ca:	e8 e1 ac ff ff       	call   34b0 <strtof@plt>
    87cf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    87d4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    87d7:	7a 02                	jp     87db <fwp_write+0x63b>
    87d9:	74 1c                	je     87f7 <fwp_write+0x657>
    87db:	41 83 c5 01          	add    $0x1,%r13d
    87df:	41 83 fd 0a          	cmp    $0xa,%r13d
    87e3:	75 cb                	jne    87b0 <fwp_write+0x610>
    87e5:	be 09 00 00 00       	mov    $0x9,%esi
    87ea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    87ef:	4c 89 e7             	mov    %r12,%rdi
    87f2:	e8 19 bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    87f7:	4c 89 e7             	mov    %r12,%rdi
    87fa:	e8 81 bb ff ff       	call   4380 <fwp_finish_float>
    87ff:	e9 1c fa ff ff       	jmp    8220 <fwp_write+0x80>
    8804:	0f 1f 40 00          	nopl   0x0(%rax)
    8808:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    880c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8810:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8817:	00 
    8818:	48 89 ef             	mov    %rbp,%rdi
    881b:	e8 20 b2 ff ff       	call   3a40 <fwp_fmt_u128>
    8820:	48 89 ef             	mov    %rbp,%rdi
    8823:	e8 28 ac ff ff       	call   3450 <strlen@plt>
    8828:	48 89 ee             	mov    %rbp,%rsi
    882b:	48 89 df             	mov    %rbx,%rdi
    882e:	48 89 c2             	mov    %rax,%rdx
    8831:	e8 da b9 ff ff       	call   4210 <buf_put>
    8836:	e9 fb f9 ff ff       	jmp    8236 <fwp_write+0x96>
    883b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8840:	ba 06 00 00 00       	mov    $0x6,%edx
    8845:	48 8d 35 ac 29 00 00 	lea    0x29ac(%rip),%rsi        # b1f8 <_IO_stdin_used+0x1f8>
    884c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8852:	e8 b9 b9 ff ff       	call   4210 <buf_put>
    8857:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    885e:	ff ff 7f 
    8861:	48 23 55 00          	and    0x0(%rbp),%rdx
    8865:	0f 84 86 02 00 00    	je     8af1 <fwp_write+0x951>
    886b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8870:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8874:	48 85 d2             	test   %rdx,%rdx
    8877:	0f 84 ae 00 00 00    	je     892b <fwp_write+0x78b>
    887d:	8b 0a                	mov    (%rdx),%ecx
    887f:	83 f9 1c             	cmp    $0x1c,%ecx
    8882:	0f 84 58 06 00 00    	je     8ee0 <fwp_write+0xd40>
    8888:	83 f9 1b             	cmp    $0x1b,%ecx
    888b:	0f 87 9a 00 00 00    	ja     892b <fwp_write+0x78b>
    8891:	be 01 00 00 00       	mov    $0x1,%esi
    8896:	48 d3 e6             	shl    %cl,%rsi
    8899:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    889f:	0f 85 4b 04 00 00    	jne    8cf0 <fwp_write+0xb50>
    88a5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    88ab:	0f 85 0f 04 00 00    	jne    8cc0 <fwp_write+0xb20>
    88b1:	83 e6 21             	and    $0x21,%esi
    88b4:	74 75                	je     892b <fwp_write+0x78b>
    88b6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    88bb:	48 85 ff             	test   %rdi,%rdi
    88be:	79 07                	jns    88c7 <fwp_write+0x727>
    88c0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    88c4:	4c 01 ee             	add    %r13,%rsi
    88c7:	48 0f be 3e          	movsbq (%rsi),%rdi
    88cb:	85 c9                	test   %ecx,%ecx
    88cd:	40 0f b6 f7          	movzbl %dil,%esi
    88d1:	48 0f 44 f7          	cmove  %rdi,%rsi
    88d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88dc:	00 00 00 00 
    88e0:	31 c9                	xor    %ecx,%ecx
    88e2:	48 89 df             	mov    %rbx,%rdi
    88e5:	49 83 c5 01          	add    $0x1,%r13
    88e9:	e8 b2 f8 ff ff       	call   81a0 <fwp_write>
    88ee:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    88f5:	ff ff 7f 
    88f8:	48 23 55 00          	and    0x0(%rbp),%rdx
    88fc:	49 39 d5             	cmp    %rdx,%r13
    88ff:	0f 83 ec 01 00 00    	jae    8af1 <fwp_write+0x951>
    8905:	ba 02 00 00 00       	mov    $0x2,%edx
    890a:	48 89 df             	mov    %rbx,%rdi
    890d:	48 8d 35 e1 28 00 00 	lea    0x28e1(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8914:	e8 f7 b8 ff ff       	call   4210 <buf_put>
    8919:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    891e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8922:	48 85 d2             	test   %rdx,%rdx
    8925:	0f 85 52 ff ff ff    	jne    887d <fwp_write+0x6dd>
    892b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8930:	48 85 ff             	test   %rdi,%rdi
    8933:	0f 88 cf 05 00 00    	js     8f08 <fwp_write+0xd68>
    8939:	48 8b 31             	mov    (%rcx),%rsi
    893c:	eb a2                	jmp    88e0 <fwp_write+0x740>
    893e:	66 90                	xchg   %ax,%ax
    8940:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8947:	00 
    8948:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    894f:	00 00 
    8951:	0f 85 1e fd ff ff    	jne    8675 <fwp_write+0x4d5>
    8957:	ba 08 00 00 00       	mov    $0x8,%edx
    895c:	48 8d 35 62 28 00 00 	lea    0x2862(%rip),%rsi        # b1c5 <_IO_stdin_used+0x1c5>
    8963:	e9 4b fa ff ff       	jmp    83b3 <fwp_write+0x213>
    8968:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    896f:	00 
    8970:	89 e8                	mov    %ebp,%eax
    8972:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8979:	76 03                	jbe    897e <fwp_write+0x7de>
    897b:	8b 45 00             	mov    0x0(%rbp),%eax
    897e:	41 89 c6             	mov    %eax,%r14d
    8981:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8986:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    898b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    898f:	4c 89 ef             	mov    %r13,%rdi
    8992:	e8 b9 aa ff ff       	call   3450 <strlen@plt>
    8997:	4c 89 ee             	mov    %r13,%rsi
    899a:	48 89 df             	mov    %rbx,%rdi
    899d:	48 89 c2             	mov    %rax,%rdx
    89a0:	e8 6b b8 ff ff       	call   4210 <buf_put>
    89a5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    89aa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    89ae:	85 f6                	test   %esi,%esi
    89b0:	0f 8e 80 f8 ff ff    	jle    8236 <fwp_write+0x96>
    89b6:	45 31 ed             	xor    %r13d,%r13d
    89b9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    89be:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    89c3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    89c8:	ba 01 00 00 00       	mov    $0x1,%edx
    89cd:	4c 89 fe             	mov    %r15,%rsi
    89d0:	48 89 04 24          	mov    %rax,(%rsp)
    89d4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    89d9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    89dd:	48 89 df             	mov    %rbx,%rdi
    89e0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    89e4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    89e9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    89ee:	e8 1d b8 ff ff       	call   4210 <buf_put>
    89f3:	41 8b 06             	mov    (%r14),%eax
    89f6:	83 f8 0e             	cmp    $0xe,%eax
    89f9:	0f 84 71 02 00 00    	je     8c70 <fwp_write+0xad0>
    89ff:	83 f8 10             	cmp    $0x10,%eax
    8a02:	0f 84 38 02 00 00    	je     8c40 <fwp_write+0xaa0>
    8a08:	83 f8 0a             	cmp    $0xa,%eax
    8a0b:	0f 84 7f 04 00 00    	je     8e90 <fwp_write+0xcf0>
    8a11:	0f 8f f9 00 00 00    	jg     8b10 <fwp_write+0x970>
    8a17:	83 f8 03             	cmp    $0x3,%eax
    8a1a:	0f 8f 50 04 00 00    	jg     8e70 <fwp_write+0xcd0>
    8a20:	85 c0                	test   %eax,%eax
    8a22:	78 10                	js     8a34 <fwp_write+0x894>
    8a24:	48 8b 04 24          	mov    (%rsp),%rax
    8a28:	48 c1 e8 3f          	shr    $0x3f,%rax
    8a2c:	85 c0                	test   %eax,%eax
    8a2e:	0f 85 f9 00 00 00    	jne    8b2d <fwp_write+0x98d>
    8a34:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8a39:	48 8b 34 24          	mov    (%rsp),%rsi
    8a3d:	31 c9                	xor    %ecx,%ecx
    8a3f:	48 89 df             	mov    %rbx,%rdi
    8a42:	e8 59 f7 ff ff       	call   81a0 <fwp_write>
    8a47:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a4c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a51:	49 83 c5 01          	add    $0x1,%r13
    8a55:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8a59:	0f 8f 5f ff ff ff    	jg     89be <fwp_write+0x81e>
    8a5f:	e9 d2 f7 ff ff       	jmp    8236 <fwp_write+0x96>
    8a64:	0f 1f 40 00          	nopl   0x0(%rax)
    8a68:	ba 06 00 00 00       	mov    $0x6,%edx
    8a6d:	48 8d 35 77 27 00 00 	lea    0x2777(%rip),%rsi        # b1eb <_IO_stdin_used+0x1eb>
    8a74:	45 31 ed             	xor    %r13d,%r13d
    8a77:	e8 94 b7 ff ff       	call   4210 <buf_put>
    8a7c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8a81:	75 19                	jne    8a9c <fwp_write+0x8fc>
    8a83:	eb 6c                	jmp    8af1 <fwp_write+0x951>
    8a85:	0f 1f 00             	nopl   (%rax)
    8a88:	ba 02 00 00 00       	mov    $0x2,%edx
    8a8d:	48 8d 35 61 27 00 00 	lea    0x2761(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8a94:	48 89 df             	mov    %rbx,%rdi
    8a97:	e8 74 b7 ff ff       	call   4210 <buf_put>
    8a9c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8aa2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8aa7:	31 c0                	xor    %eax,%eax
    8aa9:	49 83 c5 01          	add    $0x1,%r13
    8aad:	4c 8d 05 3e 27 00 00 	lea    0x273e(%rip),%r8        # b1f2 <_IO_stdin_used+0x1f2>
    8ab4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ab9:	be 00 02 00 00       	mov    $0x200,%esi
    8abe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ac5:	00 
    8ac6:	e8 e5 a8 ff ff       	call   33b0 <__snprintf_chk@plt>
    8acb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ad2:	00 
    8ad3:	e8 78 a9 ff ff       	call   3450 <strlen@plt>
    8ad8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8adf:	00 
    8ae0:	48 89 df             	mov    %rbx,%rdi
    8ae3:	48 89 c2             	mov    %rax,%rdx
    8ae6:	e8 25 b7 ff ff       	call   4210 <buf_put>
    8aeb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8aef:	72 97                	jb     8a88 <fwp_write+0x8e8>
    8af1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8af6:	ba 01 00 00 00       	mov    $0x1,%edx
    8afb:	48 89 df             	mov    %rbx,%rdi
    8afe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b03:	e8 08 b7 ff ff       	call   4210 <buf_put>
    8b08:	e9 29 f7 ff ff       	jmp    8236 <fwp_write+0x96>
    8b0d:	0f 1f 00             	nopl   (%rax)
    8b10:	83 f8 0b             	cmp    $0xb,%eax
    8b13:	0f 85 1b ff ff ff    	jne    8a34 <fwp_write+0x894>
    8b19:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8b1e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8b22:	83 e0 01             	and    $0x1,%eax
    8b25:	85 c0                	test   %eax,%eax
    8b27:	0f 84 07 ff ff ff    	je     8a34 <fwp_write+0x894>
    8b2d:	4c 89 fe             	mov    %r15,%rsi
    8b30:	48 89 df             	mov    %rbx,%rdi
    8b33:	ba 01 00 00 00       	mov    $0x1,%edx
    8b38:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8b3d:	e8 ce b6 ff ff       	call   4210 <buf_put>
    8b42:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8b47:	48 8b 34 24          	mov    (%rsp),%rsi
    8b4b:	31 c9                	xor    %ecx,%ecx
    8b4d:	48 89 df             	mov    %rbx,%rdi
    8b50:	e8 4b f6 ff ff       	call   81a0 <fwp_write>
    8b55:	ba 01 00 00 00       	mov    $0x1,%edx
    8b5a:	4c 89 fe             	mov    %r15,%rsi
    8b5d:	48 89 df             	mov    %rbx,%rdi
    8b60:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8b65:	e8 a6 b6 ff ff       	call   4210 <buf_put>
    8b6a:	e9 d8 fe ff ff       	jmp    8a47 <fwp_write+0x8a7>
    8b6f:	90                   	nop
    8b70:	ba 01 00 00 00       	mov    $0x1,%edx
    8b75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b7a:	48 89 df             	mov    %rbx,%rdi
    8b7d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b82:	e8 89 b6 ff ff       	call   4210 <buf_put>
    8b87:	e9 aa f6 ff ff       	jmp    8236 <fwp_write+0x96>
    8b8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b90:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b95:	ba 01 00 00 00       	mov    $0x1,%edx
    8b9a:	48 89 df             	mov    %rbx,%rdi
    8b9d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8ba2:	e8 69 b6 ff ff       	call   4210 <buf_put>
    8ba7:	e9 8a f6 ff ff       	jmp    8236 <fwp_write+0x96>
    8bac:	0f 1f 40 00          	nopl   0x0(%rax)
    8bb0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8bb4:	48 8b 13             	mov    (%rbx),%rdx
    8bb7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8bbc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8bc0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8bc4:	e9 6d f6 ff ff       	jmp    8236 <fwp_write+0x96>
    8bc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8bd0:	ba 02 00 00 00       	mov    $0x2,%edx
    8bd5:	48 8d 35 19 26 00 00 	lea    0x2619(%rip),%rsi        # b1f5 <_IO_stdin_used+0x1f5>
    8bdc:	48 89 df             	mov    %rbx,%rdi
    8bdf:	e8 2c b6 ff ff       	call   4210 <buf_put>
    8be4:	e9 72 f8 ff ff       	jmp    845b <fwp_write+0x2bb>
    8be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8bf0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8bf5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8bfa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8bfe:	48 89 f7             	mov    %rsi,%rdi
    8c01:	48 89 34 24          	mov    %rsi,(%rsp)
    8c05:	e8 46 a8 ff ff       	call   3450 <strlen@plt>
    8c0a:	48 8b 34 24          	mov    (%rsp),%rsi
    8c0e:	48 89 df             	mov    %rbx,%rdi
    8c11:	48 89 c2             	mov    %rax,%rdx
    8c14:	e8 f7 b5 ff ff       	call   4210 <buf_put>
    8c19:	ba 03 00 00 00       	mov    $0x3,%edx
    8c1e:	48 8d 35 f3 25 00 00 	lea    0x25f3(%rip),%rsi        # b218 <_IO_stdin_used+0x218>
    8c25:	48 89 df             	mov    %rbx,%rdi
    8c28:	e8 e3 b5 ff ff       	call   4210 <buf_put>
    8c2d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8c32:	e9 35 f8 ff ff       	jmp    846c <fwp_write+0x2cc>
    8c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c3e:	00 00 
    8c40:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8c45:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8c49:	48 85 ff             	test   %rdi,%rdi
    8c4c:	0f 84 e2 fd ff ff    	je     8a34 <fwp_write+0x894>
    8c52:	48 8d 35 a9 25 00 00 	lea    0x25a9(%rip),%rsi        # b202 <_IO_stdin_used+0x202>
    8c59:	e8 d2 a8 ff ff       	call   3530 <strcmp@plt>
    8c5e:	85 c0                	test   %eax,%eax
    8c60:	0f 95 c0             	setne  %al
    8c63:	0f b6 c0             	movzbl %al,%eax
    8c66:	e9 c1 fd ff ff       	jmp    8a2c <fwp_write+0x88c>
    8c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c70:	31 c0                	xor    %eax,%eax
    8c72:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8c79:	00 
    8c7a:	0f 97 c0             	seta   %al
    8c7d:	e9 aa fd ff ff       	jmp    8a2c <fwp_write+0x88c>
    8c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c88:	48 89 df             	mov    %rbx,%rdi
    8c8b:	ba 02 00 00 00       	mov    $0x2,%edx
    8c90:	48 8d 35 68 25 00 00 	lea    0x2568(%rip),%rsi        # b1ff <_IO_stdin_used+0x1ff>
    8c97:	e8 74 b5 ff ff       	call   4210 <buf_put>
    8c9c:	4c 89 e8             	mov    %r13,%rax
    8c9f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8ca4:	31 c9                	xor    %ecx,%ecx
    8ca6:	48 c1 e0 04          	shl    $0x4,%rax
    8caa:	48 89 df             	mov    %rbx,%rdi
    8cad:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8cb2:	e8 e9 f4 ff ff       	call   81a0 <fwp_write>
    8cb7:	e9 5e f6 ff ff       	jmp    831a <fwp_write+0x17a>
    8cbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8cc0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8cc5:	48 85 ff             	test   %rdi,%rdi
    8cc8:	79 0c                	jns    8cd6 <fwp_write+0xb36>
    8cca:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8cd1:	00 
    8cd2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8cd6:	48 63 3e             	movslq (%rsi),%rdi
    8cd9:	83 f9 02             	cmp    $0x2,%ecx
    8cdc:	89 fe                	mov    %edi,%esi
    8cde:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ce2:	e9 f9 fb ff ff       	jmp    88e0 <fwp_write+0x740>
    8ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cee:	00 00 
    8cf0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8cf5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8cfa:	48 85 ff             	test   %rdi,%rdi
    8cfd:	0f 88 0f 03 00 00    	js     9012 <fwp_write+0xe72>
    8d03:	49 0f bf 38          	movswq (%r8),%rdi
    8d07:	83 f9 01             	cmp    $0x1,%ecx
    8d0a:	0f b7 f7             	movzwl %di,%esi
    8d0d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d11:	e9 ca fb ff ff       	jmp    88e0 <fwp_write+0x740>
    8d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d1d:	00 00 00 
    8d20:	ba 01 00 00 00       	mov    $0x1,%edx
    8d25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d2a:	48 83 c5 08          	add    $0x8,%rbp
    8d2e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8d33:	e8 d8 b4 ff ff       	call   4210 <buf_put>
    8d38:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8d3d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8d42:	4d 85 ed             	test   %r13,%r13
    8d45:	75 46                	jne    8d8d <fwp_write+0xbed>
    8d47:	e9 04 01 00 00       	jmp    8e50 <fwp_write+0xcb0>
    8d4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d50:	41 80 f9 09          	cmp    $0x9,%r9b
    8d54:	0f 84 d6 00 00 00    	je     8e30 <fwp_write+0xc90>
    8d5a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8d5e:	0f 85 9c 00 00 00    	jne    8e00 <fwp_write+0xc60>
    8d64:	ba 02 00 00 00       	mov    $0x2,%edx
    8d69:	48 8d 35 6b 24 00 00 	lea    0x246b(%rip),%rsi        # b1db <_IO_stdin_used+0x1db>
    8d70:	48 89 df             	mov    %rbx,%rdi
    8d73:	e8 98 b4 ff ff       	call   4210 <buf_put>
    8d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d7f:	00 
    8d80:	48 83 c5 01          	add    $0x1,%rbp
    8d84:	49 39 ec             	cmp    %rbp,%r12
    8d87:	0f 84 c3 00 00 00    	je     8e50 <fwp_write+0xcb0>
    8d8d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8d92:	41 80 f9 0d          	cmp    $0xd,%r9b
    8d96:	74 28                	je     8dc0 <fwp_write+0xc20>
    8d98:	7e b6                	jle    8d50 <fwp_write+0xbb0>
    8d9a:	41 80 f9 22          	cmp    $0x22,%r9b
    8d9e:	74 40                	je     8de0 <fwp_write+0xc40>
    8da0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8da4:	75 5a                	jne    8e00 <fwp_write+0xc60>
    8da6:	ba 02 00 00 00       	mov    $0x2,%edx
    8dab:	48 8d 35 26 24 00 00 	lea    0x2426(%rip),%rsi        # b1d8 <_IO_stdin_used+0x1d8>
    8db2:	48 89 df             	mov    %rbx,%rdi
    8db5:	e8 56 b4 ff ff       	call   4210 <buf_put>
    8dba:	eb c4                	jmp    8d80 <fwp_write+0xbe0>
    8dbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8dc0:	ba 02 00 00 00       	mov    $0x2,%edx
    8dc5:	48 8d 35 15 24 00 00 	lea    0x2415(%rip),%rsi        # b1e1 <_IO_stdin_used+0x1e1>
    8dcc:	48 89 df             	mov    %rbx,%rdi
    8dcf:	e8 3c b4 ff ff       	call   4210 <buf_put>
    8dd4:	eb aa                	jmp    8d80 <fwp_write+0xbe0>
    8dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8ddd:	00 00 00 
    8de0:	ba 02 00 00 00       	mov    $0x2,%edx
    8de5:	48 8d 35 e9 23 00 00 	lea    0x23e9(%rip),%rsi        # b1d5 <_IO_stdin_used+0x1d5>
    8dec:	48 89 df             	mov    %rbx,%rdi
    8def:	e8 1c b4 ff ff       	call   4210 <buf_put>
    8df4:	eb 8a                	jmp    8d80 <fwp_write+0xbe0>
    8df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8dfd:	00 00 00 
    8e00:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8e04:	0f 86 2e 01 00 00    	jbe    8f38 <fwp_write+0xd98>
    8e0a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8e0e:	0f 84 24 01 00 00    	je     8f38 <fwp_write+0xd98>
    8e14:	ba 01 00 00 00       	mov    $0x1,%edx
    8e19:	4c 89 fe             	mov    %r15,%rsi
    8e1c:	48 89 df             	mov    %rbx,%rdi
    8e1f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8e24:	e8 e7 b3 ff ff       	call   4210 <buf_put>
    8e29:	e9 52 ff ff ff       	jmp    8d80 <fwp_write+0xbe0>
    8e2e:	66 90                	xchg   %ax,%ax
    8e30:	ba 02 00 00 00       	mov    $0x2,%edx
    8e35:	48 8d 35 a2 23 00 00 	lea    0x23a2(%rip),%rsi        # b1de <_IO_stdin_used+0x1de>
    8e3c:	48 89 df             	mov    %rbx,%rdi
    8e3f:	e8 cc b3 ff ff       	call   4210 <buf_put>
    8e44:	e9 37 ff ff ff       	jmp    8d80 <fwp_write+0xbe0>
    8e49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e50:	ba 01 00 00 00       	mov    $0x1,%edx
    8e55:	4c 89 fe             	mov    %r15,%rsi
    8e58:	48 89 df             	mov    %rbx,%rdi
    8e5b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8e60:	e8 ab b3 ff ff       	call   4210 <buf_put>
    8e65:	e9 cc f3 ff ff       	jmp    8236 <fwp_write+0x96>
    8e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e70:	83 f8 04             	cmp    $0x4,%eax
    8e73:	0f 85 bb fb ff ff    	jne    8a34 <fwp_write+0x894>
    8e79:	48 8b 04 24          	mov    (%rsp),%rax
    8e7d:	48 8b 40 08          	mov    0x8(%rax),%rax
    8e81:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8e86:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e8a:	e9 96 fc ff ff       	jmp    8b25 <fwp_write+0x985>
    8e8f:	90                   	nop
    8e90:	8b 0c 24             	mov    (%rsp),%ecx
    8e93:	31 c0                	xor    %eax,%eax
    8e95:	85 c9                	test   %ecx,%ecx
    8e97:	0f 98 c0             	sets   %al
    8e9a:	e9 86 fc ff ff       	jmp    8b25 <fwp_write+0x985>
    8e9f:	90                   	nop
    8ea0:	48 f7 d8             	neg    %rax
    8ea3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8eaa:	00 
    8eab:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8eb2:	2d 
    8eb3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8eba:	00 
    8ebb:	48 83 d2 00          	adc    $0x0,%rdx
    8ebf:	48 89 c6             	mov    %rax,%rsi
    8ec2:	48 f7 da             	neg    %rdx
    8ec5:	e8 76 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8eca:	e9 51 f3 ff ff       	jmp    8220 <fwp_write+0x80>
    8ecf:	90                   	nop
    8ed0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8ed5:	e9 c3 f5 ff ff       	jmp    849d <fwp_write+0x2fd>
    8eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ee0:	4c 89 e9             	mov    %r13,%rcx
    8ee3:	48 c1 e1 04          	shl    $0x4,%rcx
    8ee7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8eec:	48 85 ff             	test   %rdi,%rdi
    8eef:	0f 89 eb f9 ff ff    	jns    88e0 <fwp_write+0x740>
    8ef5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8ef9:	48 89 ce             	mov    %rcx,%rsi
    8efc:	e9 df f9 ff ff       	jmp    88e0 <fwp_write+0x740>
    8f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f08:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8f0f:	00 
    8f10:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f14:	e9 20 fa ff ff       	jmp    8939 <fwp_write+0x799>
    8f19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f20:	ba 02 00 00 00       	mov    $0x2,%edx
    8f25:	48 8d 35 79 22 00 00 	lea    0x2279(%rip),%rsi        # b1a5 <_IO_stdin_used+0x1a5>
    8f2c:	e9 2d f7 ff ff       	jmp    865e <fwp_write+0x4be>
    8f31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f38:	4c 8d 05 a5 22 00 00 	lea    0x22a5(%rip),%r8        # b1e4 <_IO_stdin_used+0x1e4>
    8f3f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8f44:	31 c0                	xor    %eax,%eax
    8f46:	ba 02 00 00 00       	mov    $0x2,%edx
    8f4b:	be 10 00 00 00       	mov    $0x10,%esi
    8f50:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f57:	00 
    8f58:	e8 53 a4 ff ff       	call   33b0 <__snprintf_chk@plt>
    8f5d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f64:	00 
    8f65:	e8 e6 a4 ff ff       	call   3450 <strlen@plt>
    8f6a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f71:	00 
    8f72:	48 89 df             	mov    %rbx,%rdi
    8f75:	48 89 c2             	mov    %rax,%rdx
    8f78:	e8 93 b2 ff ff       	call   4210 <buf_put>
    8f7d:	e9 fe fd ff ff       	jmp    8d80 <fwp_write+0xbe0>
    8f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f88:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8f8c:	48 8d 35 0c 22 00 00 	lea    0x220c(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    8f93:	48 8d 05 04 22 00 00 	lea    0x2204(%rip),%rax        # b19e <_IO_stdin_used+0x19e>
    8f9a:	4c 89 e7             	mov    %r12,%rdi
    8f9d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8fa1:	48 0f 46 f0          	cmovbe %rax,%rsi
    8fa5:	e8 46 a4 ff ff       	call   33f0 <strcpy@plt>
    8faa:	e9 71 f2 ff ff       	jmp    8220 <fwp_write+0x80>
    8faf:	90                   	nop
    8fb0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8fb4:	48 8d 35 e4 21 00 00 	lea    0x21e4(%rip),%rsi        # b19f <_IO_stdin_used+0x19f>
    8fbb:	48 8d 05 dc 21 00 00 	lea    0x21dc(%rip),%rax        # b19e <_IO_stdin_used+0x19e>
    8fc2:	0f 2f c8             	comiss %xmm0,%xmm1
    8fc5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8fcc:	00 
    8fcd:	4c 89 e7             	mov    %r12,%rdi
    8fd0:	48 0f 46 f0          	cmovbe %rax,%rsi
    8fd4:	e8 17 a4 ff ff       	call   33f0 <strcpy@plt>
    8fd9:	e9 42 f2 ff ff       	jmp    8220 <fwp_write+0x80>
    8fde:	66 90                	xchg   %ax,%ax
    8fe0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8fe5:	45 85 c0             	test   %r8d,%r8d
    8fe8:	75 34                	jne    901e <fwp_write+0xe7e>
    8fea:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ff1:	00 
    8ff2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8ff9:	00 00 
    8ffb:	0f 85 74 f6 ff ff    	jne    8675 <fwp_write+0x4d5>
    9001:	ba 02 00 00 00       	mov    $0x2,%edx
    9006:	48 8d 35 08 22 00 00 	lea    0x2208(%rip),%rsi        # b215 <_IO_stdin_used+0x215>
    900d:	e9 a1 f3 ff ff       	jmp    83b3 <fwp_write+0x213>
    9012:	48 03 75 10          	add    0x10(%rbp),%rsi
    9016:	49 89 f0             	mov    %rsi,%r8
    9019:	e9 e5 fc ff ff       	jmp    8d03 <fwp_write+0xb63>
    901e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9023:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9028:	85 ff                	test   %edi,%edi
    902a:	0f 84 fa f3 ff ff    	je     842a <fwp_write+0x28a>
    9030:	ba 01 00 00 00       	mov    $0x1,%edx
    9035:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    903a:	48 89 df             	mov    %rbx,%rdi
    903d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9042:	e8 c9 b1 ff ff       	call   4210 <buf_put>
    9047:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    904c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9051:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9057:	85 c0                	test   %eax,%eax
    9059:	0f 8f f0 f3 ff ff    	jg     844f <fwp_write+0x2af>
    905f:	e9 34 f4 ff ff       	jmp    8498 <fwp_write+0x2f8>
    9064:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9068:	49 89 c5             	mov    %rax,%r13
    906b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9070:	49 89 c4             	mov    %rax,%r12
    9073:	49 c1 fd 3f          	sar    $0x3f,%r13
    9077:	4c 09 e8             	or     %r13,%rax
    907a:	0f 84 a7 00 00 00    	je     9127 <fwp_write+0xf87>
    9080:	48 8d 2d 19 42 00 00 	lea    0x4219(%rip),%rbp        # d2a0 <units.0>
    9087:	4d 89 e7             	mov    %r12,%r15
    908a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    908e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9093:	4c 89 ff             	mov    %r15,%rdi
    9096:	4c 89 ee             	mov    %r13,%rsi
    9099:	44 89 0c 24          	mov    %r9d,(%rsp)
    909d:	48 99                	cqto
    909f:	48 89 d1             	mov    %rdx,%rcx
    90a2:	48 89 c2             	mov    %rax,%rdx
    90a5:	e8 66 0f 00 00       	call   a010 <__divmodti4>
    90aa:	44 8b 0c 24          	mov    (%rsp),%r9d
    90ae:	48 89 c1             	mov    %rax,%rcx
    90b1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    90b6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    90bb:	0f 84 94 00 00 00    	je     9155 <fwp_write+0xfb5>
    90c1:	41 83 c1 01          	add    $0x1,%r9d
    90c5:	48 83 c5 10          	add    $0x10,%rbp
    90c9:	41 83 f9 05          	cmp    $0x5,%r9d
    90cd:	75 bb                	jne    908a <fwp_write+0xeea>
    90cf:	4d 85 ed             	test   %r13,%r13
    90d2:	79 53                	jns    9127 <fwp_write+0xf87>
    90d4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    90d9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    90de:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    90e3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    90e8:	48 99                	cqto
    90ea:	48 f7 d8             	neg    %rax
    90ed:	48 83 d2 00          	adc    $0x0,%rdx
    90f1:	48 89 c6             	mov    %rax,%rsi
    90f4:	48 f7 da             	neg    %rdx
    90f7:	e8 44 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    90fc:	49 89 e8             	mov    %rbp,%r8
    90ff:	ba 00 02 00 00       	mov    $0x200,%edx
    9104:	be 02 00 00 00       	mov    $0x2,%esi
    9109:	31 c0                	xor    %eax,%eax
    910b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9112:	00 
    9113:	48 8d 0d f6 20 00 00 	lea    0x20f6(%rip),%rcx        # b210 <_IO_stdin_used+0x210>
    911a:	4c 89 e7             	mov    %r12,%rdi
    911d:	e8 be a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    9122:	e9 f9 f0 ff ff       	jmp    8220 <fwp_write+0x80>
    9127:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    912c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9131:	31 d2                	xor    %edx,%edx
    9133:	48 89 ef             	mov    %rbp,%rdi
    9136:	e8 05 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    913b:	eb bf                	jmp    90fc <fwp_write+0xf5c>
    913d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9144:	4e 61 4e 00 
    9148:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    914f:	00 
    9150:	e9 cb f0 ff ff       	jmp    8220 <fwp_write+0x80>
    9155:	44 89 0c 24          	mov    %r9d,(%rsp)
    9159:	48 89 c8             	mov    %rcx,%rax
    915c:	48 85 d2             	test   %rdx,%rdx
    915f:	78 51                	js     91b2 <fwp_write+0x1012>
    9161:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9166:	48 89 c6             	mov    %rax,%rsi
    9169:	48 89 ef             	mov    %rbp,%rdi
    916c:	e8 cf a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9171:	44 8b 0c 24          	mov    (%rsp),%r9d
    9175:	49 63 c1             	movslq %r9d,%rax
    9178:	49 89 e8             	mov    %rbp,%r8
    917b:	ba 00 02 00 00       	mov    $0x200,%edx
    9180:	be 02 00 00 00       	mov    $0x2,%esi
    9185:	48 c1 e0 04          	shl    $0x4,%rax
    9189:	48 8d 3d 10 41 00 00 	lea    0x4110(%rip),%rdi        # d2a0 <units.0>
    9190:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9197:	00 
    9198:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    919c:	48 8d 0d 68 20 00 00 	lea    0x2068(%rip),%rcx        # b20b <_IO_stdin_used+0x20b>
    91a3:	4c 89 e7             	mov    %r12,%rdi
    91a6:	31 c0                	xor    %eax,%eax
    91a8:	e8 33 a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    91ad:	e9 6e f0 ff ff       	jmp    8220 <fwp_write+0x80>
    91b2:	48 f7 d8             	neg    %rax
    91b5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    91ba:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    91bf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91c4:	48 83 d2 00          	adc    $0x0,%rdx
    91c8:	48 89 c6             	mov    %rax,%rsi
    91cb:	48 f7 da             	neg    %rdx
    91ce:	e8 6d a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91d3:	44 8b 0c 24          	mov    (%rsp),%r9d
    91d7:	eb 9c                	jmp    9175 <fwp_write+0xfd5>
    91d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000091e0 <fwp_main_thread>:
    91e0:	f3 0f 1e fa          	endbr64
    91e4:	41 57                	push   %r15
    91e6:	41 56                	push   %r14
    91e8:	41 55                	push   %r13
    91ea:	41 54                	push   %r12
    91ec:	55                   	push   %rbp
    91ed:	53                   	push   %rbx
    91ee:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    91f5:	8b 35 69 79 01 00    	mov    0x17969(%rip),%esi        # 20b64 <fwp_heap+0x13a4>
    91fb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9202:	00 00 
    9204:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    920b:	00 
    920c:	31 c0                	xor    %eax,%eax
    920e:	85 f6                	test   %esi,%esi
    9210:	0f 84 f2 0b 00 00    	je     9e08 <fwp_main_thread+0xc28>
    9216:	8b 0d 4c 79 01 00    	mov    0x1794c(%rip),%ecx        # 20b68 <fwp_heap+0x13a8>
    921c:	85 c9                	test   %ecx,%ecx
    921e:	0f 85 cc 0b 00 00    	jne    9df0 <fwp_main_thread+0xc10>
    9224:	48 8d 05 55 5e 00 00 	lea    0x5e55(%rip),%rax        # f080 <alt.5>
    922b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9230:	31 f6                	xor    %esi,%esi
    9232:	48 c7 05 13 5f 01 00 	movq   $0x40000000,0x15f13(%rip)        # 1f150 <fwp_main_stack_size>
    9239:	00 00 00 40 
    923d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9242:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9247:	48 89 c7             	mov    %rax,%rdi
    924a:	48 89 2d 07 5f 01 00 	mov    %rbp,0x15f07(%rip)        # 1f158 <fwp_main_stack_top>
    9251:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9258:	01 00 
    925a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9261:	00 
    9262:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9267:	e8 54 a4 ff ff       	call   36c0 <sigaltstack@plt>
    926c:	85 c0                	test   %eax,%eax
    926e:	0f 85 63 0d 00 00    	jne    9fd7 <fwp_main_thread+0xdf7>
    9274:	31 c0                	xor    %eax,%eax
    9276:	b9 12 00 00 00       	mov    $0x12,%ecx
    927b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9282:	00 
    9283:	f3 48 ab             	rep stos %rax,(%rdi)
    9286:	48 8d 05 63 aa ff ff 	lea    -0x559d(%rip),%rax        # 3cf0 <fwp_segv>
    928d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9294:	00 
    9295:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    929c:	04 00 00 08 
    92a0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    92a7:	00 
    92a8:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    92af:	00 
    92b0:	e8 cb a2 ff ff       	call   3580 <sigemptyset@plt>
    92b5:	85 c0                	test   %eax,%eax
    92b7:	0f 85 1a 0d 00 00    	jne    9fd7 <fwp_main_thread+0xdf7>
    92bd:	31 d2                	xor    %edx,%edx
    92bf:	48 89 de             	mov    %rbx,%rsi
    92c2:	bf 0b 00 00 00       	mov    $0xb,%edi
    92c7:	e8 34 a1 ff ff       	call   3400 <sigaction@plt>
    92cc:	85 c0                	test   %eax,%eax
    92ce:	0f 85 03 0d 00 00    	jne    9fd7 <fwp_main_thread+0xdf7>
    92d4:	31 d2                	xor    %edx,%edx
    92d6:	48 89 de             	mov    %rbx,%rsi
    92d9:	bf 07 00 00 00       	mov    $0x7,%edi
    92de:	e8 1d a1 ff ff       	call   3400 <sigaction@plt>
    92e3:	85 c0                	test   %eax,%eax
    92e5:	0f 85 ec 0c 00 00    	jne    9fd7 <fwp_main_thread+0xdf7>
    92eb:	8b 15 07 5e 01 00    	mov    0x15e07(%rip),%edx        # 1f0f8 <descent_registered>
    92f1:	85 d2                	test   %edx,%edx
    92f3:	0f 84 77 05 00 00    	je     9870 <fwp_main_thread+0x690>
    92f9:	8b 05 69 5d 00 00    	mov    0x5d69(%rip),%eax        # f068 <st.3>
    92ff:	85 c0                	test   %eax,%eax
    9301:	0f 84 95 05 00 00    	je     989c <fwp_main_thread+0x6bc>
    9307:	48 8b 2d 92 64 01 00 	mov    0x16492(%rip),%rbp        # 1f7a0 <fwp_cur>
    930e:	48 85 ed             	test   %rbp,%rbp
    9311:	0f 84 09 03 00 00    	je     9620 <fwp_main_thread+0x440>
    9317:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    931c:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9320:	48 89 eb             	mov    %rbp,%rbx
    9323:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9328:	0f 84 41 01 00 00    	je     946f <fwp_main_thread+0x28f>
    932e:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9333:	0f 84 17 02 00 00    	je     9550 <fwp_main_thread+0x370>
    9339:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    933d:	0f 84 fd 01 00 00    	je     9540 <fwp_main_thread+0x360>
    9343:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9347:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    934b:	0f 85 7f 02 00 00    	jne    95d0 <fwp_main_thread+0x3f0>
    9351:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9355:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    935c:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9360:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9367:	00 00 00 00 
    936b:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9372:	48 85 d2             	test   %rdx,%rdx
    9375:	74 07                	je     937e <fwp_main_thread+0x19e>
    9377:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    937e:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9382:	48 85 c0             	test   %rax,%rax
    9385:	74 34                	je     93bb <fwp_main_thread+0x1db>
    9387:	48 89 43 68          	mov    %rax,0x68(%rbx)
    938b:	48 8b 05 e6 63 01 00 	mov    0x163e6(%rip),%rax        # 1f778 <fwp_timers>
    9392:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9396:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    939d:	00 00 00 00 
    93a1:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    93a8:	48 85 c0             	test   %rax,%rax
    93ab:	74 07                	je     93b4 <fwp_main_thread+0x1d4>
    93ad:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    93b4:	48 89 1d bd 63 01 00 	mov    %rbx,0x163bd(%rip)        # 1f778 <fwp_timers>
    93bb:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    93bf:	e8 6c de ff ff       	call   7230 <fwp_block>
    93c4:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    93cb:	48 85 c9             	test   %rcx,%rcx
    93ce:	74 47                	je     9417 <fwp_main_thread+0x237>
    93d0:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    93d7:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    93de:	48 85 d2             	test   %rdx,%rdx
    93e1:	0f 84 29 02 00 00    	je     9610 <fwp_main_thread+0x430>
    93e7:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    93ee:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    93f5:	48 85 c0             	test   %rax,%rax
    93f8:	74 07                	je     9401 <fwp_main_thread+0x221>
    93fa:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9401:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9408:	00 00 00 00 
    940c:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9410:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    9417:	48 8b 0d 82 63 01 00 	mov    0x16382(%rip),%rcx        # 1f7a0 <fwp_cur>
    941e:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9422:	0f 84 98 01 00 00    	je     95c0 <fwp_main_thread+0x3e0>
    9428:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    942f:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9436:	48 85 d2             	test   %rdx,%rdx
    9439:	0f 84 99 03 00 00    	je     97d8 <fwp_main_thread+0x5f8>
    943f:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9446:	48 85 c0             	test   %rax,%rax
    9449:	74 07                	je     9452 <fwp_main_thread+0x272>
    944b:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9452:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9456:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    945a:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    9461:	48 89 cb             	mov    %rcx,%rbx
    9464:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9469:	0f 85 bf fe ff ff    	jne    932e <fwp_main_thread+0x14e>
    946f:	48 83 3d c1 7f 01 00 	cmpq   $0x0,0x17fc1(%rip)        # 21438 <fwp_state_len>
    9476:	00 
    9477:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    947b:	0f 84 81 03 00 00    	je     9802 <fwp_main_thread+0x622>
    9481:	48 39 1d 10 63 01 00 	cmp    %rbx,0x16310(%rip)        # 1f798 <fwp_root>
    9488:	c7 05 ee 5b 01 00 00 	movl   $0x0,0x15bee(%rip)        # 1f080 <fwp_exit_code>
    948f:	00 00 00 
    9492:	0f 85 6d 0b 00 00    	jne    a005 <fwp_main_thread+0xe25>
    9498:	48 85 db             	test   %rbx,%rbx
    949b:	0f 84 a5 01 00 00    	je     9646 <fwp_main_thread+0x466>
    94a1:	48 8b 15 c0 62 01 00 	mov    0x162c0(%rip),%rdx        # 1f768 <fwp_tasks_active>
    94a8:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    94ac:	48 85 d2             	test   %rdx,%rdx
    94af:	0f 84 91 01 00 00    	je     9646 <fwp_main_thread+0x466>
    94b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94bc:	00 00 00 00 
    94c0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    94c4:	75 08                	jne    94ce <fwp_main_thread+0x2ee>
    94c6:	48 89 d7             	mov    %rdx,%rdi
    94c9:	e8 32 ae ff ff       	call   4300 <fwp_cancel_tree.part.0>
    94ce:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    94d5:	48 85 d2             	test   %rdx,%rdx
    94d8:	75 e6                	jne    94c0 <fwp_main_thread+0x2e0>
    94da:	eb 31                	jmp    950d <fwp_main_thread+0x32d>
    94dc:	0f 1f 40 00          	nopl   0x0(%rax)
    94e0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    94e7:	48 89 1d 92 62 01 00 	mov    %rbx,0x16292(%rip)        # 1f780 <fwp_ready_tail>
    94ee:	e8 3d dd ff ff       	call   7230 <fwp_block>
    94f3:	e8 28 db ff ff       	call   7020 <fwp_free_zombie>
    94f8:	48 83 3d 68 62 01 00 	cmpq   $0x0,0x16268(%rip)        # 1f768 <fwp_tasks_active>
    94ff:	00 
    9500:	0f 84 40 01 00 00    	je     9646 <fwp_main_thread+0x466>
    9506:	48 8b 1d 8b 62 01 00 	mov    0x1628b(%rip),%rbx        # 1f798 <fwp_root>
    950d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9511:	75 db                	jne    94ee <fwp_main_thread+0x30e>
    9513:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9517:	75 d5                	jne    94ee <fwp_main_thread+0x30e>
    9519:	48 8b 05 60 62 01 00 	mov    0x16260(%rip),%rax        # 1f780 <fwp_ready_tail>
    9520:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9524:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    952b:	00 00 00 00 
    952f:	48 85 c0             	test   %rax,%rax
    9532:	75 ac                	jne    94e0 <fwp_main_thread+0x300>
    9534:	48 89 1d 4d 62 01 00 	mov    %rbx,0x1624d(%rip)        # 1f788 <fwp_ready_head>
    953b:	eb aa                	jmp    94e7 <fwp_main_thread+0x307>
    953d:	0f 1f 00             	nopl   (%rax)
    9540:	e8 1b b0 ff ff       	call   4560 <fwp_now_ns>
    9545:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9549:	0f 8d 99 02 00 00    	jge    97e8 <fwp_main_thread+0x608>
    954f:	90                   	nop
    9550:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9554:	0f 85 e9 fd ff ff    	jne    9343 <fwp_main_thread+0x163>
    955a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    955e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9562:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9566:	0f 85 e9 fd ff ff    	jne    9355 <fwp_main_thread+0x175>
    956c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9570:	48 85 c9             	test   %rcx,%rcx
    9573:	0f 84 dc fd ff ff    	je     9355 <fwp_main_thread+0x175>
    9579:	48 39 c8             	cmp    %rcx,%rax
    957c:	48 89 ce             	mov    %rcx,%rsi
    957f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9586:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    958a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9591:	00 00 00 00 
    9595:	48 0f 4e f0          	cmovle %rax,%rsi
    9599:	48 85 c0             	test   %rax,%rax
    959c:	48 89 c8             	mov    %rcx,%rax
    959f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    95a6:	48 0f 45 c6          	cmovne %rsi,%rax
    95aa:	48 85 d2             	test   %rdx,%rdx
    95ad:	74 07                	je     95b6 <fwp_main_thread+0x3d6>
    95af:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    95b6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    95ba:	e9 c8 fd ff ff       	jmp    9387 <fwp_main_thread+0x1a7>
    95bf:	90                   	nop
    95c0:	48 89 cb             	mov    %rcx,%rbx
    95c3:	e9 5b fd ff ff       	jmp    9323 <fwp_main_thread+0x143>
    95c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95cf:	00 
    95d0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    95d4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    95db:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    95e2:	00 00 00 00 
    95e6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    95ed:	48 85 c0             	test   %rax,%rax
    95f0:	0f 84 ba 08 00 00    	je     9eb0 <fwp_main_thread+0xcd0>
    95f6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    95fd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9601:	e9 b5 fd ff ff       	jmp    93bb <fwp_main_thread+0x1db>
    9606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    960d:	00 00 00 
    9610:	48 89 01             	mov    %rax,(%rcx)
    9613:	e9 dd fd ff ff       	jmp    93f5 <fwp_main_thread+0x215>
    9618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    961f:	00 
    9620:	48 83 3d 10 7e 01 00 	cmpq   $0x0,0x17e10(%rip)        # 21438 <fwp_state_len>
    9627:	00 
    9628:	0f 84 d2 01 00 00    	je     9800 <fwp_main_thread+0x620>
    962e:	48 83 3d 62 61 01 00 	cmpq   $0x0,0x16162(%rip)        # 1f798 <fwp_root>
    9635:	00 
    9636:	c7 05 40 5a 01 00 00 	movl   $0x0,0x15a40(%rip)        # 1f080 <fwp_exit_code>
    963d:	00 00 00 
    9640:	0f 85 c4 09 00 00    	jne    a00a <fwp_main_thread+0xe2a>
    9646:	e8 d5 d9 ff ff       	call   7020 <fwp_free_zombie>
    964b:	48 83 3d 35 61 01 00 	cmpq   $0x0,0x16135(%rip)        # 1f788 <fwp_ready_head>
    9652:	00 
    9653:	0f 85 f2 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    9659:	48 83 3d 17 61 01 00 	cmpq   $0x0,0x16117(%rip)        # 1f778 <fwp_timers>
    9660:	00 
    9661:	0f 85 e4 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    9667:	8b 05 f7 5a 01 00    	mov    0x15af7(%rip),%eax        # 1f164 <fwp_stack_pool_n>
    966d:	85 c0                	test   %eax,%eax
    966f:	74 3c                	je     96ad <fwp_main_thread+0x4cd>
    9671:	83 e8 01             	sub    $0x1,%eax
    9674:	4c 8d 25 05 5b 01 00 	lea    0x15b05(%rip),%r12        # 1f180 <fwp_stack_pool>
    967b:	48 63 d8             	movslq %eax,%rbx
    967e:	89 c0                	mov    %eax,%eax
    9680:	48 89 da             	mov    %rbx,%rdx
    9683:	48 29 c2             	sub    %rax,%rdx
    9686:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    968a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9690:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9694:	89 1d ca 5a 01 00    	mov    %ebx,0x15aca(%rip)        # 1f164 <fwp_stack_pool_n>
    969a:	be 00 00 00 10       	mov    $0x10000000,%esi
    969f:	48 83 eb 01          	sub    $0x1,%rbx
    96a3:	e8 38 9f ff ff       	call   35e0 <munmap@plt>
    96a8:	48 39 dd             	cmp    %rbx,%rbp
    96ab:	75 e3                	jne    9690 <fwp_main_thread+0x4b0>
    96ad:	8b 3d 61 59 00 00    	mov    0x5961(%rip),%edi        # f014 <fwp_epfd>
    96b3:	85 ff                	test   %edi,%edi
    96b5:	78 05                	js     96bc <fwp_main_thread+0x4dc>
    96b7:	e8 14 9e ff ff       	call   34d0 <close@plt>
    96bc:	4c 8b 25 bd 5c 01 00 	mov    0x15cbd(%rip),%r12        # 1f380 <fwp_nfdws>
    96c3:	48 8b 2d be 5c 01 00 	mov    0x15cbe(%rip),%rbp        # 1f388 <fwp_fdws>
    96ca:	31 db                	xor    %ebx,%ebx
    96cc:	c7 05 3e 59 00 00 ff 	movl   $0xffffffff,0x593e(%rip)        # f014 <fwp_epfd>
    96d3:	ff ff ff 
    96d6:	4d 85 e4             	test   %r12,%r12
    96d9:	74 32                	je     970d <fwp_main_thread+0x52d>
    96db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    96e0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    96e5:	48 85 ff             	test   %rdi,%rdi
    96e8:	74 1a                	je     9704 <fwp_main_thread+0x524>
    96ea:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    96ee:	0f 85 57 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96f4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    96f9:	0f 85 4c a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96ff:	e8 8c c0 ff ff       	call   5790 <fwp_mem_free>
    9704:	48 83 c3 01          	add    $0x1,%rbx
    9708:	49 39 dc             	cmp    %rbx,%r12
    970b:	75 d3                	jne    96e0 <fwp_main_thread+0x500>
    970d:	48 89 ef             	mov    %rbp,%rdi
    9710:	e8 7b c0 ff ff       	call   5790 <fwp_mem_free>
    9715:	48 8b 15 7c 60 01 00 	mov    0x1607c(%rip),%rdx        # 1f798 <fwp_root>
    971c:	48 c7 05 61 5c 01 00 	movq   $0x0,0x15c61(%rip)        # 1f388 <fwp_fdws>
    9723:	00 00 00 00 
    9727:	48 c7 05 4e 5c 01 00 	movq   $0x0,0x15c4e(%rip)        # 1f380 <fwp_nfdws>
    972e:	00 00 00 00 
    9732:	48 85 d2             	test   %rdx,%rdx
    9735:	74 4e                	je     9785 <fwp_main_thread+0x5a5>
    9737:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    973c:	0f 85 09 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    9742:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9749:	00 
    974a:	0f 85 fb 9f ff ff    	jne    374b <fwp_main_thread.cold>
    9750:	48 83 3d e0 7c 01 00 	cmpq   $0x0,0x17ce0(%rip)        # 21438 <fwp_state_len>
    9757:	00 
    9758:	0f 85 ed 9f ff ff    	jne    374b <fwp_main_thread.cold>
    975e:	48 83 3d c2 7c 01 00 	cmpq   $0x0,0x17cc2(%rip)        # 21428 <fwp_state_owners>
    9765:	00 
    9766:	0f 85 df 9f ff ff    	jne    374b <fwp_main_thread.cold>
    976c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9771:	31 c0                	xor    %eax,%eax
    9773:	48 8d 3d 26 5c 01 00 	lea    0x15c26(%rip),%rdi        # 1f3a0 <fwp_root_context>
    977a:	f3 48 ab             	rep stos %rax,(%rdi)
    977d:	48 89 d7             	mov    %rdx,%rdi
    9780:	e8 0b c0 ff ff       	call   5790 <fwp_mem_free>
    9785:	48 8b 3d 94 58 00 00 	mov    0x5894(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    978c:	48 c7 05 09 60 01 00 	movq   $0x0,0x16009(%rip)        # 1f7a0 <fwp_cur>
    9793:	00 00 00 00 
    9797:	48 c7 05 f6 5f 01 00 	movq   $0x0,0x15ff6(%rip)        # 1f798 <fwp_root>
    979e:	00 00 00 00 
    97a2:	e8 19 9e ff ff       	call   35c0 <fflush@plt>
    97a7:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    97ae:	00 
    97af:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    97b6:	00 00 
    97b8:	0f 85 36 08 00 00    	jne    9ff4 <fwp_main_thread+0xe14>
    97be:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    97c5:	31 c0                	xor    %eax,%eax
    97c7:	5b                   	pop    %rbx
    97c8:	5d                   	pop    %rbp
    97c9:	41 5c                	pop    %r12
    97cb:	41 5d                	pop    %r13
    97cd:	41 5e                	pop    %r14
    97cf:	41 5f                	pop    %r15
    97d1:	c3                   	ret
    97d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    97d8:	48 89 05 99 5f 01 00 	mov    %rax,0x15f99(%rip)        # 1f778 <fwp_timers>
    97df:	e9 62 fc ff ff       	jmp    9446 <fwp_main_thread+0x266>
    97e4:	0f 1f 40 00          	nopl   0x0(%rax)
    97e8:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    97ec:	0f 85 5e fd ff ff    	jne    9550 <fwp_main_thread+0x370>
    97f2:	48 89 ef             	mov    %rbp,%rdi
    97f5:	e8 06 ab ff ff       	call   4300 <fwp_cancel_tree.part.0>
    97fa:	e9 51 fd ff ff       	jmp    9550 <fwp_main_thread+0x370>
    97ff:	90                   	nop
    9800:	31 db                	xor    %ebx,%ebx
    9802:	48 83 3d 1e 7c 01 00 	cmpq   $0x0,0x17c1e(%rip)        # 21428 <fwp_state_owners>
    9809:	00 
    980a:	0f 85 71 fc ff ff    	jne    9481 <fwp_main_thread+0x2a1>
    9810:	48 8b 3d 29 7c 01 00 	mov    0x17c29(%rip),%rdi        # 21440 <fwp_state>
    9817:	e8 74 bf ff ff       	call   5790 <fwp_mem_free>
    981c:	48 c7 05 19 7c 01 00 	movq   $0x0,0x17c19(%rip)        # 21440 <fwp_state>
    9823:	00 00 00 00 
    9827:	48 c7 05 fe 7b 01 00 	movq   $0x0,0x17bfe(%rip)        # 21430 <fwp_state_cap>
    982e:	00 00 00 00 
    9832:	48 85 db             	test   %rbx,%rbx
    9835:	0f 84 4f 07 00 00    	je     9f8a <fwp_main_thread+0xdaa>
    983b:	48 39 1d 56 5f 01 00 	cmp    %rbx,0x15f56(%rip)        # 1f798 <fwp_root>
    9842:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    9849:	00 00 00 00 
    984d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9854:	00 00 00 00 
    9858:	c7 05 1e 58 01 00 00 	movl   $0x0,0x1581e(%rip)        # 1f080 <fwp_exit_code>
    985f:	00 00 00 
    9862:	0f 84 39 fc ff ff    	je     94a1 <fwp_main_thread+0x2c1>
    9868:	e9 de 9e ff ff       	jmp    374b <fwp_main_thread.cold>
    986d:	0f 1f 00             	nopl   (%rax)
    9870:	48 8d 3d 99 a5 ff ff 	lea    -0x5a67(%rip),%rdi        # 3e10 <descent_phase_report>
    9877:	e8 a4 09 00 00       	call   a220 <atexit>
    987c:	85 c0                	test   %eax,%eax
    987e:	0f 85 6b 07 00 00    	jne    9fef <fwp_main_thread+0xe0f>
    9884:	c7 05 6a 58 01 00 01 	movl   $0x1,0x1586a(%rip)        # 1f0f8 <descent_registered>
    988b:	00 00 00 
    988e:	8b 05 d4 57 00 00    	mov    0x57d4(%rip),%eax        # f068 <st.3>
    9894:	85 c0                	test   %eax,%eax
    9896:	0f 85 6b fa ff ff    	jne    9307 <fwp_main_thread+0x127>
    989c:	48 8d 05 ad df ff ff 	lea    -0x2053(%rip),%rax        # 7850 <fwp_drop1>
    98a3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    98a7:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    98ae:	00 00 
    98b0:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    98b6:	66 48 0f 6e d8       	movq   %rax,%xmm3
    98bb:	48 8b 05 96 7b 01 00 	mov    0x17b96(%rip),%rax        # 21458 <fwp_cleanups>
    98c2:	4c 8d 3d f7 5e 01 00 	lea    0x15ef7(%rip),%r15        # 1f7c0 <fwp_heap>
    98c9:	48 89 2d 88 7b 01 00 	mov    %rbp,0x17b88(%rip)        # 21458 <fwp_cleanups>
    98d0:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    98d4:	31 ed                	xor    %ebp,%ebp
    98d6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    98db:	48 8d 05 ee a2 ff ff 	lea    -0x5d12(%rip),%rax        # 3bd0 <fwp_range_release>
    98e2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    98e7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    98ec:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    98f1:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    98f6:	eb 45                	jmp    993d <fwp_main_thread+0x75d>
    98f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    98ff:	00 
    9900:	80 f9 01             	cmp    $0x1,%cl
    9903:	75 29                	jne    992e <fwp_main_thread+0x74e>
    9905:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9908:	0f b7 c0             	movzwl %ax,%eax
    990b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    990e:	48 0f af c1          	imul   %rcx,%rax
    9912:	48 c1 e8 20          	shr    $0x20,%rax
    9916:	48 39 d0             	cmp    %rdx,%rax
    9919:	73 13                	jae    992e <fwp_main_thread+0x74e>
    991b:	49 01 c5             	add    %rax,%r13
    991e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9923:	0f 84 c7 05 00 00    	je     9ef0 <fwp_main_thread+0xd10>
    9929:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    992e:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9933:	49 83 ec 01          	sub    $0x1,%r12
    9937:	0f 82 83 00 00 00    	jb     99c0 <fwp_main_thread+0x7e0>
    993d:	48 89 de             	mov    %rbx,%rsi
    9940:	bf 01 00 00 00       	mov    $0x1,%edi
    9945:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    994c:	00 
    994d:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    9952:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    9959:	00 
    995a:	e8 51 c4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    995f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9966:	48 89 c5             	mov    %rax,%rbp
    9969:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9970:	48 c1 e2 10          	shl    $0x10,%rdx
    9974:	48 39 d0             	cmp    %rdx,%rax
    9977:	73 b5                	jae    992e <fwp_main_thread+0x74e>
    9979:	48 89 c2             	mov    %rax,%rdx
    997c:	48 c1 ea 10          	shr    $0x10,%rdx
    9980:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9984:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    998b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    998f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9993:	4d 85 ed             	test   %r13,%r13
    9996:	74 96                	je     992e <fwp_main_thread+0x74e>
    9998:	0f b6 0a             	movzbl (%rdx),%ecx
    999b:	80 f9 02             	cmp    $0x2,%cl
    999e:	0f 85 5c ff ff ff    	jne    9900 <fwp_main_thread+0x720>
    99a4:	66 85 c0             	test   %ax,%ax
    99a7:	0f 84 71 ff ff ff    	je     991e <fwp_main_thread+0x73e>
    99ad:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    99b2:	49 83 ec 01          	sub    $0x1,%r12
    99b6:	73 85                	jae    993d <fwp_main_thread+0x75d>
    99b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    99bf:	00 
    99c0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    99c5:	66 0f 6f 05 93 21 00 	movdqa 0x2193(%rip),%xmm0        # bb60 <msg.4+0xa0>
    99cc:	00 
    99cd:	48 89 de             	mov    %rbx,%rsi
    99d0:	bf 01 00 00 00       	mov    $0x1,%edi
    99d5:	48 89 05 7c 7a 01 00 	mov    %rax,0x17a7c(%rip)        # 21458 <fwp_cleanups>
    99dc:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    99e3:	00 
    99e4:	e8 c7 c3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    99e9:	48 8b 15 a8 71 01 00 	mov    0x171a8(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    99f0:	49 89 c4             	mov    %rax,%r12
    99f3:	48 2b 05 76 71 01 00 	sub    0x17176(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    99fa:	48 c1 e2 10          	shl    $0x10,%rdx
    99fe:	48 39 d0             	cmp    %rdx,%rax
    9a01:	73 55                	jae    9a58 <fwp_main_thread+0x878>
    9a03:	48 89 c2             	mov    %rax,%rdx
    9a06:	48 c1 ea 10          	shr    $0x10,%rdx
    9a0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a0e:	48 8b 15 a3 71 01 00 	mov    0x171a3(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    9a15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a19:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9a1d:	48 85 db             	test   %rbx,%rbx
    9a20:	74 36                	je     9a58 <fwp_main_thread+0x878>
    9a22:	0f b6 0a             	movzbl (%rdx),%ecx
    9a25:	80 f9 02             	cmp    $0x2,%cl
    9a28:	0f 84 b2 04 00 00    	je     9ee0 <fwp_main_thread+0xd00>
    9a2e:	80 f9 01             	cmp    $0x1,%cl
    9a31:	75 25                	jne    9a58 <fwp_main_thread+0x878>
    9a33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a36:	0f b7 c0             	movzwl %ax,%eax
    9a39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a3c:	48 0f af c1          	imul   %rcx,%rax
    9a40:	48 c1 e8 20          	shr    $0x20,%rax
    9a44:	48 39 d0             	cmp    %rdx,%rax
    9a47:	73 0f                	jae    9a58 <fwp_main_thread+0x878>
    9a49:	48 01 c3             	add    %rax,%rbx
    9a4c:	80 3b ff             	cmpb   $0xff,(%rbx)
    9a4f:	0f 84 5b 05 00 00    	je     9fb0 <fwp_main_thread+0xdd0>
    9a55:	c6 03 01             	movb   $0x1,(%rbx)
    9a58:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    9a5d:	bf 01 00 00 00       	mov    $0x1,%edi
    9a62:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9a67:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9a6e:	00 f0 3f 
    9a71:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9a76:	e8 35 c3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9a7b:	48 8b 15 16 71 01 00 	mov    0x17116(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    9a82:	49 89 c4             	mov    %rax,%r12
    9a85:	48 2b 05 e4 70 01 00 	sub    0x170e4(%rip),%rax        # 20b70 <fwp_heap+0x13b0>
    9a8c:	48 c1 e2 10          	shl    $0x10,%rdx
    9a90:	48 39 d0             	cmp    %rdx,%rax
    9a93:	73 55                	jae    9aea <fwp_main_thread+0x90a>
    9a95:	48 89 c2             	mov    %rax,%rdx
    9a98:	48 c1 ea 10          	shr    $0x10,%rdx
    9a9c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9aa0:	48 8b 15 11 71 01 00 	mov    0x17111(%rip),%rdx        # 20bb8 <fwp_heap+0x13f8>
    9aa7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aab:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9aaf:	48 85 db             	test   %rbx,%rbx
    9ab2:	74 36                	je     9aea <fwp_main_thread+0x90a>
    9ab4:	0f b6 0a             	movzbl (%rdx),%ecx
    9ab7:	80 f9 02             	cmp    $0x2,%cl
    9aba:	0f 84 10 04 00 00    	je     9ed0 <fwp_main_thread+0xcf0>
    9ac0:	80 f9 01             	cmp    $0x1,%cl
    9ac3:	75 25                	jne    9aea <fwp_main_thread+0x90a>
    9ac5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ac8:	0f b7 c0             	movzwl %ax,%eax
    9acb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ace:	48 0f af c1          	imul   %rcx,%rax
    9ad2:	48 c1 e8 20          	shr    $0x20,%rax
    9ad6:	48 39 d0             	cmp    %rdx,%rax
    9ad9:	73 0f                	jae    9aea <fwp_main_thread+0x90a>
    9adb:	48 01 c3             	add    %rax,%rbx
    9ade:	80 3b ff             	cmpb   $0xff,(%rbx)
    9ae1:	0f 84 d6 04 00 00    	je     9fbd <fwp_main_thread+0xddd>
    9ae7:	c6 03 01             	movb   $0x1,(%rbx)
    9aea:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    9aef:	bf 01 00 00 00       	mov    $0x1,%edi
    9af4:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9af9:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9b00:	33 f3 bf 
    9b03:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9b08:	e8 a3 c2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9b0d:	48 8b 15 84 70 01 00 	mov    0x17084(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    9b14:	48 8b 0d 55 70 01 00 	mov    0x17055(%rip),%rcx        # 20b70 <fwp_heap+0x13b0>
    9b1b:	49 89 c4             	mov    %rax,%r12
    9b1e:	48 89 d6             	mov    %rdx,%rsi
    9b21:	48 29 c8             	sub    %rcx,%rax
    9b24:	48 c1 e6 10          	shl    $0x10,%rsi
    9b28:	48 39 f0             	cmp    %rsi,%rax
    9b2b:	73 65                	jae    9b92 <fwp_main_thread+0x9b2>
    9b2d:	48 89 c6             	mov    %rax,%rsi
    9b30:	48 c1 ee 10          	shr    $0x10,%rsi
    9b34:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9b38:	48 8b 35 79 70 01 00 	mov    0x17079(%rip),%rsi        # 20bb8 <fwp_heap+0x13f8>
    9b3f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9b43:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    9b47:	48 85 db             	test   %rbx,%rbx
    9b4a:	74 46                	je     9b92 <fwp_main_thread+0x9b2>
    9b4c:	0f b6 3e             	movzbl (%rsi),%edi
    9b4f:	40 80 ff 02          	cmp    $0x2,%dil
    9b53:	0f 84 67 03 00 00    	je     9ec0 <fwp_main_thread+0xce0>
    9b59:	40 80 ff 01          	cmp    $0x1,%dil
    9b5d:	75 33                	jne    9b92 <fwp_main_thread+0x9b2>
    9b5f:	8b 7e 18             	mov    0x18(%rsi),%edi
    9b62:	0f b7 c0             	movzwl %ax,%eax
    9b65:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9b68:	48 0f af c7          	imul   %rdi,%rax
    9b6c:	48 c1 e8 20          	shr    $0x20,%rax
    9b70:	48 39 f0             	cmp    %rsi,%rax
    9b73:	73 1d                	jae    9b92 <fwp_main_thread+0x9b2>
    9b75:	48 01 c3             	add    %rax,%rbx
    9b78:	80 3b ff             	cmpb   $0xff,(%rbx)
    9b7b:	0f 84 49 04 00 00    	je     9fca <fwp_main_thread+0xdea>
    9b81:	c6 03 01             	movb   $0x1,(%rbx)
    9b84:	48 8b 0d e5 6f 01 00 	mov    0x16fe5(%rip),%rcx        # 20b70 <fwp_heap+0x13b0>
    9b8b:	48 8b 15 06 70 01 00 	mov    0x17006(%rip),%rdx        # 20b98 <fwp_heap+0x13d8>
    9b92:	49 89 ed             	mov    %rbp,%r13
    9b95:	e9 01 02 00 00       	jmp    9d9b <fwp_main_thread+0xbbb>
    9b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ba0:	80 f9 01             	cmp    $0x1,%cl
    9ba3:	75 2d                	jne    9bd2 <fwp_main_thread+0x9f2>
    9ba5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ba8:	0f b7 c0             	movzwl %ax,%eax
    9bab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bae:	48 0f af c1          	imul   %rcx,%rax
    9bb2:	48 c1 e8 20          	shr    $0x20,%rax
    9bb6:	48 39 d0             	cmp    %rdx,%rax
    9bb9:	73 17                	jae    9bd2 <fwp_main_thread+0x9f2>
    9bbb:	48 01 c7             	add    %rax,%rdi
    9bbe:	0f b6 07             	movzbl (%rdi),%eax
    9bc1:	84 c0                	test   %al,%al
    9bc3:	74 0d                	je     9bd2 <fwp_main_thread+0x9f2>
    9bc5:	3c fd                	cmp    $0xfd,%al
    9bc7:	0f 87 b3 03 00 00    	ja     9f80 <fwp_main_thread+0xda0>
    9bcd:	83 c0 01             	add    $0x1,%eax
    9bd0:	88 07                	mov    %al,(%rdi)
    9bd2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9bd7:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9bdb:	b9 01 00 00 00       	mov    $0x1,%ecx
    9be0:	4c 89 e6             	mov    %r12,%rsi
    9be3:	48 8d 15 96 4f 00 00 	lea    0x4f96(%rip),%rdx        # eb80 <d0>
    9bea:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    9bef:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    9bf6:	00 00 
    9bf8:	e8 a3 e5 ff ff       	call   81a0 <fwp_write>
    9bfd:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9c02:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    9c07:	48 8d 05 83 14 00 00 	lea    0x1483(%rip),%rax        # b091 <_IO_stdin_used+0x91>
    9c0e:	48 85 c9             	test   %rcx,%rcx
    9c11:	48 0f 44 c8          	cmove  %rax,%rcx
    9c15:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    9c19:	0f 87 c4 03 00 00    	ja     9fe3 <fwp_main_thread+0xe03>
    9c1f:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    9c23:	be 01 00 00 00       	mov    $0x1,%esi
    9c28:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9c2d:	e8 5e c0 ff ff       	call   5c90 <fwp_heap_alloc>
    9c32:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9c37:	4c 89 f2             	mov    %r14,%rdx
    9c3a:	4c 89 30             	mov    %r14,(%rax)
    9c3d:	48 89 c3             	mov    %rax,%rbx
    9c40:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9c44:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    9c49:	e8 52 99 ff ff       	call   35a0 <memcpy@plt>
    9c4e:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    9c54:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    9c59:	e8 62 97 ff ff       	call   33c0 <free@plt>
    9c5e:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9c65:	48 89 d8             	mov    %rbx,%rax
    9c68:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9c6f:	48 c1 e2 10          	shl    $0x10,%rdx
    9c73:	48 39 d0             	cmp    %rdx,%rax
    9c76:	73 55                	jae    9ccd <fwp_main_thread+0xaed>
    9c78:	48 89 c2             	mov    %rax,%rdx
    9c7b:	48 c1 ea 10          	shr    $0x10,%rdx
    9c7f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c83:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9c8a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c8e:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    9c92:	48 85 f6             	test   %rsi,%rsi
    9c95:	74 36                	je     9ccd <fwp_main_thread+0xaed>
    9c97:	0f b6 0a             	movzbl (%rdx),%ecx
    9c9a:	80 f9 02             	cmp    $0x2,%cl
    9c9d:	0f 84 bd 01 00 00    	je     9e60 <fwp_main_thread+0xc80>
    9ca3:	80 f9 01             	cmp    $0x1,%cl
    9ca6:	75 25                	jne    9ccd <fwp_main_thread+0xaed>
    9ca8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cab:	0f b7 c0             	movzwl %ax,%eax
    9cae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9cb1:	48 0f af c1          	imul   %rcx,%rax
    9cb5:	48 c1 e8 20          	shr    $0x20,%rax
    9cb9:	48 39 d0             	cmp    %rdx,%rax
    9cbc:	73 0f                	jae    9ccd <fwp_main_thread+0xaed>
    9cbe:	48 01 c6             	add    %rax,%rsi
    9cc1:	80 3e ff             	cmpb   $0xff,(%rsi)
    9cc4:	0f 84 b6 01 00 00    	je     9e80 <fwp_main_thread+0xca0>
    9cca:	c6 06 01             	movb   $0x1,(%rsi)
    9ccd:	4c 89 e7             	mov    %r12,%rdi
    9cd0:	e8 8b d9 ff ff       	call   7660 <fwp_drop0>
    9cd5:	48 8b 13             	mov    (%rbx),%rdx
    9cd8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9cdd:	be 01 00 00 00       	mov    $0x1,%esi
    9ce2:	48 8b 0d 37 77 01 00 	mov    0x17737(%rip),%rcx        # 21420 <fwp_prog_out>
    9ce9:	e8 92 99 ff ff       	call   3680 <fwrite@plt>
    9cee:	48 8b 35 2b 77 01 00 	mov    0x1772b(%rip),%rsi        # 21420 <fwp_prog_out>
    9cf5:	bf 0a 00 00 00       	mov    $0xa,%edi
    9cfa:	e8 e1 97 ff ff       	call   34e0 <fputc@plt>
    9cff:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9d06:	48 89 d8             	mov    %rbx,%rax
    9d09:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9d10:	48 c1 e2 10          	shl    $0x10,%rdx
    9d14:	48 39 d0             	cmp    %rdx,%rax
    9d17:	73 67                	jae    9d80 <fwp_main_thread+0xba0>
    9d19:	48 89 c2             	mov    %rax,%rdx
    9d1c:	48 c1 ea 10          	shr    $0x10,%rdx
    9d20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d24:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9d2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d2f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9d33:	4d 85 f6             	test   %r14,%r14
    9d36:	74 48                	je     9d80 <fwp_main_thread+0xba0>
    9d38:	0f b6 0a             	movzbl (%rdx),%ecx
    9d3b:	80 f9 02             	cmp    $0x2,%cl
    9d3e:	0f 84 d4 00 00 00    	je     9e18 <fwp_main_thread+0xc38>
    9d44:	80 f9 01             	cmp    $0x1,%cl
    9d47:	75 37                	jne    9d80 <fwp_main_thread+0xba0>
    9d49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d4c:	0f b7 c0             	movzwl %ax,%eax
    9d4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d52:	48 0f af c1          	imul   %rcx,%rax
    9d56:	48 c1 e8 20          	shr    $0x20,%rax
    9d5a:	48 39 d0             	cmp    %rdx,%rax
    9d5d:	73 21                	jae    9d80 <fwp_main_thread+0xba0>
    9d5f:	49 01 c6             	add    %rax,%r14
    9d62:	41 0f b6 06          	movzbl (%r14),%eax
    9d66:	84 c0                	test   %al,%al
    9d68:	74 16                	je     9d80 <fwp_main_thread+0xba0>
    9d6a:	3c 01                	cmp    $0x1,%al
    9d6c:	0f 84 2e 01 00 00    	je     9ea0 <fwp_main_thread+0xcc0>
    9d72:	3c ff                	cmp    $0xff,%al
    9d74:	0f 84 86 01 00 00    	je     9f00 <fwp_main_thread+0xd20>
    9d7a:	83 e8 01             	sub    $0x1,%eax
    9d7d:	41 88 06             	mov    %al,(%r14)
    9d80:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9d84:	4d 85 ed             	test   %r13,%r13
    9d87:	0f 84 a3 00 00 00    	je     9e30 <fwp_main_thread+0xc50>
    9d8d:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    9d94:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9d9b:	4c 89 e0             	mov    %r12,%rax
    9d9e:	48 c1 e2 10          	shl    $0x10,%rdx
    9da2:	48 29 c8             	sub    %rcx,%rax
    9da5:	48 39 d0             	cmp    %rdx,%rax
    9da8:	0f 83 24 fe ff ff    	jae    9bd2 <fwp_main_thread+0x9f2>
    9dae:	48 89 c2             	mov    %rax,%rdx
    9db1:	48 c1 ea 10          	shr    $0x10,%rdx
    9db5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9db9:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9dc0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9dc4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9dc8:	48 85 ff             	test   %rdi,%rdi
    9dcb:	0f 84 01 fe ff ff    	je     9bd2 <fwp_main_thread+0x9f2>
    9dd1:	0f b6 0a             	movzbl (%rdx),%ecx
    9dd4:	80 f9 02             	cmp    $0x2,%cl
    9dd7:	0f 85 c3 fd ff ff    	jne    9ba0 <fwp_main_thread+0x9c0>
    9ddd:	66 85 c0             	test   %ax,%ax
    9de0:	0f 85 ec fd ff ff    	jne    9bd2 <fwp_main_thread+0x9f2>
    9de6:	e9 d3 fd ff ff       	jmp    9bbe <fwp_main_thread+0x9de>
    9deb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9df0:	48 8d 3d 69 ae ff ff 	lea    -0x5197(%rip),%rdi        # 4c60 <fwp_heap_report>
    9df7:	e8 24 04 00 00       	call   a220 <atexit>
    9dfc:	e9 23 f4 ff ff       	jmp    9224 <fwp_main_thread+0x44>
    9e01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9e08:	e8 63 af ff ff       	call   4d70 <fwp_heap_init>
    9e0d:	e9 04 f4 ff ff       	jmp    9216 <fwp_main_thread+0x36>
    9e12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e18:	66 85 c0             	test   %ax,%ax
    9e1b:	0f 84 41 ff ff ff    	je     9d62 <fwp_main_thread+0xb82>
    9e21:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9e25:	4d 85 ed             	test   %r13,%r13
    9e28:	0f 85 5f ff ff ff    	jne    9d8d <fwp_main_thread+0xbad>
    9e2e:	66 90                	xchg   %ax,%ax
    9e30:	4c 89 e7             	mov    %r12,%rdi
    9e33:	e8 28 d8 ff ff       	call   7660 <fwp_drop0>
    9e38:	48 89 ef             	mov    %rbp,%rdi
    9e3b:	e8 20 d8 ff ff       	call   7660 <fwp_drop0>
    9e40:	48 c7 05 15 52 00 00 	movq   $0x0,0x5215(%rip)        # f060 <v.2>
    9e47:	00 00 00 00 
    9e4b:	c7 05 13 52 00 00 01 	movl   $0x1,0x5213(%rip)        # f068 <st.3>
    9e52:	00 00 00 
    9e55:	e9 ad f4 ff ff       	jmp    9307 <fwp_main_thread+0x127>
    9e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e60:	66 85 c0             	test   %ax,%ax
    9e63:	0f 85 64 fe ff ff    	jne    9ccd <fwp_main_thread+0xaed>
    9e69:	80 3e ff             	cmpb   $0xff,(%rsi)
    9e6c:	0f 85 58 fe ff ff    	jne    9cca <fwp_main_thread+0xaea>
    9e72:	0f 1f 00             	nopl   (%rax)
    9e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e7c:	00 00 00 00 
    9e80:	48 89 f7             	mov    %rsi,%rdi
    9e83:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    9e88:	e8 c3 b6 ff ff       	call   5550 <fwp_rc_forget_slot>
    9e8d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9e92:	e9 33 fe ff ff       	jmp    9cca <fwp_main_thread+0xaea>
    9e97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e9e:	00 00 
    9ea0:	48 89 df             	mov    %rbx,%rdi
    9ea3:	e8 e8 b8 ff ff       	call   5790 <fwp_mem_free>
    9ea8:	e9 d3 fe ff ff       	jmp    9d80 <fwp_main_thread+0xba0>
    9ead:	0f 1f 00             	nopl   (%rax)
    9eb0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9eb4:	e9 02 f5 ff ff       	jmp    93bb <fwp_main_thread+0x1db>
    9eb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9ec0:	66 85 c0             	test   %ax,%ax
    9ec3:	0f 85 c9 fc ff ff    	jne    9b92 <fwp_main_thread+0x9b2>
    9ec9:	e9 aa fc ff ff       	jmp    9b78 <fwp_main_thread+0x998>
    9ece:	66 90                	xchg   %ax,%ax
    9ed0:	66 85 c0             	test   %ax,%ax
    9ed3:	0f 85 11 fc ff ff    	jne    9aea <fwp_main_thread+0x90a>
    9ed9:	e9 00 fc ff ff       	jmp    9ade <fwp_main_thread+0x8fe>
    9ede:	66 90                	xchg   %ax,%ax
    9ee0:	66 85 c0             	test   %ax,%ax
    9ee3:	0f 85 6f fb ff ff    	jne    9a58 <fwp_main_thread+0x878>
    9ee9:	e9 5e fb ff ff       	jmp    9a4c <fwp_main_thread+0x86c>
    9eee:	66 90                	xchg   %ax,%ax
    9ef0:	4c 89 ef             	mov    %r13,%rdi
    9ef3:	e8 58 b6 ff ff       	call   5550 <fwp_rc_forget_slot>
    9ef8:	e9 2c fa ff ff       	jmp    9929 <fwp_main_thread+0x749>
    9efd:	0f 1f 00             	nopl   (%rax)
    9f00:	4c 89 f0             	mov    %r14,%rax
    9f03:	48 c1 e8 11          	shr    $0x11,%rax
    9f07:	4c 31 f0             	xor    %r14,%rax
    9f0a:	48 89 c2             	mov    %rax,%rdx
    9f0d:	48 c1 ea 09          	shr    $0x9,%rdx
    9f11:	48 31 d0             	xor    %rdx,%rax
    9f14:	0f b6 d0             	movzbl %al,%edx
    9f17:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    9f1e:	00 
    9f1f:	48 85 c0             	test   %rax,%rax
    9f22:	75 29                	jne    9f4d <fwp_main_thread+0xd6d>
    9f24:	e9 d0 00 00 00       	jmp    9ff9 <fwp_main_thread+0xe19>
    9f29:	90                   	nop
    9f2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f31:	00 00 00 00 
    9f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f3c:	00 00 00 00 
    9f40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9f44:	48 85 c0             	test   %rax,%rax
    9f47:	0f 84 ac 00 00 00    	je     9ff9 <fwp_main_thread+0xe19>
    9f4d:	48 89 c2             	mov    %rax,%rdx
    9f50:	4c 3b 30             	cmp    (%rax),%r14
    9f53:	75 eb                	jne    9f40 <fwp_main_thread+0xd60>
    9f55:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9f59:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    9f5d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9f61:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9f68:	0f 85 12 fe ff ff    	jne    9d80 <fwp_main_thread+0xba0>
    9f6e:	4c 89 f7             	mov    %r14,%rdi
    9f71:	e8 da b5 ff ff       	call   5550 <fwp_rc_forget_slot>
    9f76:	41 c6 06 fe          	movb   $0xfe,(%r14)
    9f7a:	e9 01 fe ff ff       	jmp    9d80 <fwp_main_thread+0xba0>
    9f7f:	90                   	nop
    9f80:	e8 ab b4 ff ff       	call   5430 <fwp_rc_wide_dup>
    9f85:	e9 48 fc ff ff       	jmp    9bd2 <fwp_main_thread+0x9f2>
    9f8a:	48 83 3d 06 58 01 00 	cmpq   $0x0,0x15806(%rip)        # 1f798 <fwp_root>
    9f91:	00 
    9f92:	c7 05 e4 50 01 00 00 	movl   $0x0,0x150e4(%rip)        # 1f080 <fwp_exit_code>
    9f99:	00 00 00 
    9f9c:	0f 84 a4 f6 ff ff    	je     9646 <fwp_main_thread+0x466>
    9fa2:	e9 a4 97 ff ff       	jmp    374b <fwp_main_thread.cold>
    9fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9fae:	00 00 
    9fb0:	48 89 df             	mov    %rbx,%rdi
    9fb3:	e8 98 b5 ff ff       	call   5550 <fwp_rc_forget_slot>
    9fb8:	e9 98 fa ff ff       	jmp    9a55 <fwp_main_thread+0x875>
    9fbd:	48 89 df             	mov    %rbx,%rdi
    9fc0:	e8 8b b5 ff ff       	call   5550 <fwp_rc_forget_slot>
    9fc5:	e9 1d fb ff ff       	jmp    9ae7 <fwp_main_thread+0x907>
    9fca:	48 89 df             	mov    %rbx,%rdi
    9fcd:	e8 7e b5 ff ff       	call   5550 <fwp_rc_forget_slot>
    9fd2:	e9 aa fb ff ff       	jmp    9b81 <fwp_main_thread+0x9a1>
    9fd7:	48 8d 3d 5a 19 00 00 	lea    0x195a(%rip),%rdi        # b938 <_IO_stdin_used+0x938>
    9fde:	e8 0d a4 ff ff       	call   43f0 <fwp_trap>
    9fe3:	48 8d 3d 32 12 00 00 	lea    0x1232(%rip),%rdi        # b21c <_IO_stdin_used+0x21c>
    9fea:	e8 01 a4 ff ff       	call   43f0 <fwp_trap>
    9fef:	e8 ec 9d ff ff       	call   3de0 <descent_phase_fail>
    9ff4:	e8 67 94 ff ff       	call   3460 <__stack_chk_fail@plt>
    9ff9:	48 8d 3d 68 18 00 00 	lea    0x1868(%rip),%rdi        # b868 <_IO_stdin_used+0x868>
    a000:	e8 eb a3 ff ff       	call   43f0 <fwp_trap>
    a005:	e9 41 97 ff ff       	jmp    374b <fwp_main_thread.cold>
    a00a:	e9 3c 97 ff ff       	jmp    374b <fwp_main_thread.cold>
    a00f:	90                   	nop

000000000000a010 <__divmodti4>:
    a010:	f3 0f 1e fa          	endbr64
    a014:	55                   	push   %rbp
    a015:	49 89 f1             	mov    %rsi,%r9
    a018:	49 89 d2             	mov    %rdx,%r10
    a01b:	48 89 fe             	mov    %rdi,%rsi
    a01e:	49 89 cb             	mov    %rcx,%r11
    a021:	48 89 e5             	mov    %rsp,%rbp
    a024:	41 57                	push   %r15
    a026:	41 56                	push   %r14
    a028:	41 55                	push   %r13
    a02a:	41 54                	push   %r12
    a02c:	53                   	push   %rbx
    a02d:	4c 89 c3             	mov    %r8,%rbx
    a030:	45 31 c0             	xor    %r8d,%r8d
    a033:	4d 85 c9             	test   %r9,%r9
    a036:	79 12                	jns    a04a <__divmodti4+0x3a>
    a038:	31 ff                	xor    %edi,%edi
    a03a:	48 f7 de             	neg    %rsi
    a03d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    a044:	4c 19 cf             	sbb    %r9,%rdi
    a047:	49 89 f9             	mov    %rdi,%r9
    a04a:	4c 89 d8             	mov    %r11,%rax
    a04d:	4d 85 db             	test   %r11,%r11
    a050:	0f 88 1a 01 00 00    	js     a170 <__divmodti4+0x160>
    a056:	4c 89 d9             	mov    %r11,%rcx
    a059:	49 89 f3             	mov    %rsi,%r11
    a05c:	75 62                	jne    a0c0 <__divmodti4+0xb0>
    a05e:	4d 89 c4             	mov    %r8,%r12
    a061:	4d 39 d1             	cmp    %r10,%r9
    a064:	0f 83 46 01 00 00    	jae    a1b0 <__divmodti4+0x1a0>
    a06a:	4c 89 d8             	mov    %r11,%rax
    a06d:	4c 89 ca             	mov    %r9,%rdx
    a070:	49 f7 f2             	div    %r10
    a073:	49 89 c3             	mov    %rax,%r11
    a076:	31 c0                	xor    %eax,%eax
    a078:	48 89 d6             	mov    %rdx,%rsi
    a07b:	31 ff                	xor    %edi,%edi
    a07d:	4c 89 d9             	mov    %r11,%rcx
    a080:	48 89 c2             	mov    %rax,%rdx
    a083:	48 89 c8             	mov    %rcx,%rax
    a086:	4d 85 e4             	test   %r12,%r12
    a089:	74 0a                	je     a095 <__divmodti4+0x85>
    a08b:	48 f7 d8             	neg    %rax
    a08e:	48 83 d2 00          	adc    $0x0,%rdx
    a092:	48 f7 da             	neg    %rdx
    a095:	4d 85 c0             	test   %r8,%r8
    a098:	74 0a                	je     a0a4 <__divmodti4+0x94>
    a09a:	48 f7 de             	neg    %rsi
    a09d:	48 83 d7 00          	adc    $0x0,%rdi
    a0a1:	48 f7 df             	neg    %rdi
    a0a4:	48 89 33             	mov    %rsi,(%rbx)
    a0a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    a0ab:	5b                   	pop    %rbx
    a0ac:	41 5c                	pop    %r12
    a0ae:	41 5d                	pop    %r13
    a0b0:	41 5e                	pop    %r14
    a0b2:	41 5f                	pop    %r15
    a0b4:	5d                   	pop    %rbp
    a0b5:	c3                   	ret
    a0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0bd:	00 00 00 
    a0c0:	4d 89 c4             	mov    %r8,%r12
    a0c3:	49 39 c1             	cmp    %rax,%r9
    a0c6:	0f 82 ce 00 00 00    	jb     a19a <__divmodti4+0x18a>
    a0cc:	31 ff                	xor    %edi,%edi
    a0ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    a0d3:	48 63 c7             	movslq %edi,%rax
    a0d6:	be 40 00 00 00       	mov    $0x40,%esi
    a0db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    a0e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    a0e5:	48 29 c6             	sub    %rax,%rsi
    a0e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    a0ed:	48 09 c8             	or     %rcx,%rax
    a0f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    a0f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    a0fa:	49 89 c6             	mov    %rax,%r14
    a0fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a101:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    a106:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    a10b:	49 09 c1             	or     %rax,%r9
    a10e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    a112:	4c 89 c8             	mov    %r9,%rax
    a115:	49 f7 f6             	div    %r14
    a118:	48 89 d1             	mov    %rdx,%rcx
    a11b:	49 89 c3             	mov    %rax,%r11
    a11e:	49 89 c1             	mov    %rax,%r9
    a121:	49 f7 e2             	mul    %r10
    a124:	49 89 c6             	mov    %rax,%r14
    a127:	49 89 d2             	mov    %rdx,%r10
    a12a:	48 39 d1             	cmp    %rdx,%rcx
    a12d:	72 07                	jb     a136 <__divmodti4+0x126>
    a12f:	75 17                	jne    a148 <__divmodti4+0x138>
    a131:	49 39 c7             	cmp    %rax,%r15
    a134:	73 12                	jae    a148 <__divmodti4+0x138>
    a136:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    a13a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    a13e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    a142:	49 89 d2             	mov    %rdx,%r10
    a145:	49 89 c6             	mov    %rax,%r14
    a148:	4c 89 f8             	mov    %r15,%rax
    a14b:	4c 29 f0             	sub    %r14,%rax
    a14e:	4c 19 d1             	sbb    %r10,%rcx
    a151:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    a156:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    a15b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    a160:	48 09 c6             	or     %rax,%rsi
    a163:	48 89 cf             	mov    %rcx,%rdi
    a166:	31 c0                	xor    %eax,%eax
    a168:	4c 89 c9             	mov    %r9,%rcx
    a16b:	e9 10 ff ff ff       	jmp    a080 <__divmodti4+0x70>
    a170:	4c 89 d0             	mov    %r10,%rax
    a173:	4c 89 da             	mov    %r11,%rdx
    a176:	4d 89 c4             	mov    %r8,%r12
    a179:	49 89 f3             	mov    %rsi,%r11
    a17c:	48 f7 d8             	neg    %rax
    a17f:	49 f7 d4             	not    %r12
    a182:	48 83 d2 00          	adc    $0x0,%rdx
    a186:	49 89 c2             	mov    %rax,%r10
    a189:	48 f7 da             	neg    %rdx
    a18c:	48 89 d1             	mov    %rdx,%rcx
    a18f:	0f 84 cc fe ff ff    	je     a061 <__divmodti4+0x51>
    a195:	49 39 d1             	cmp    %rdx,%r9
    a198:	73 46                	jae    a1e0 <__divmodti4+0x1d0>
    a19a:	4c 89 cf             	mov    %r9,%rdi
    a19d:	31 c0                	xor    %eax,%eax
    a19f:	31 c9                	xor    %ecx,%ecx
    a1a1:	e9 da fe ff ff       	jmp    a080 <__divmodti4+0x70>
    a1a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1ad:	00 00 00 
    a1b0:	4d 85 d2             	test   %r10,%r10
    a1b3:	75 0d                	jne    a1c2 <__divmodti4+0x1b2>
    a1b5:	b8 01 00 00 00       	mov    $0x1,%eax
    a1ba:	31 d2                	xor    %edx,%edx
    a1bc:	49 f7 f2             	div    %r10
    a1bf:	49 89 c2             	mov    %rax,%r10
    a1c2:	4c 89 c8             	mov    %r9,%rax
    a1c5:	31 d2                	xor    %edx,%edx
    a1c7:	49 f7 f2             	div    %r10
    a1ca:	49 89 c1             	mov    %rax,%r9
    a1cd:	4c 89 d8             	mov    %r11,%rax
    a1d0:	49 f7 f2             	div    %r10
    a1d3:	49 89 c3             	mov    %rax,%r11
    a1d6:	4c 89 c8             	mov    %r9,%rax
    a1d9:	e9 9a fe ff ff       	jmp    a078 <__divmodti4+0x68>
    a1de:	66 90                	xchg   %ax,%ax
    a1e0:	45 31 f6             	xor    %r14d,%r14d
    a1e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    a1e8:	44 89 f7             	mov    %r14d,%edi
    a1eb:	45 85 f6             	test   %r14d,%r14d
    a1ee:	0f 85 df fe ff ff    	jne    a0d3 <__divmodti4+0xc3>
    a1f4:	4c 39 ca             	cmp    %r9,%rdx
    a1f7:	72 17                	jb     a210 <__divmodti4+0x200>
    a1f9:	31 c9                	xor    %ecx,%ecx
    a1fb:	48 39 c6             	cmp    %rax,%rsi
    a1fe:	73 10                	jae    a210 <__divmodti4+0x200>
    a200:	4c 89 cf             	mov    %r9,%rdi
    a203:	31 c0                	xor    %eax,%eax
    a205:	e9 76 fe ff ff       	jmp    a080 <__divmodti4+0x70>
    a20a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a210:	4c 89 de             	mov    %r11,%rsi
    a213:	b9 01 00 00 00       	mov    $0x1,%ecx
    a218:	48 29 c6             	sub    %rax,%rsi
    a21b:	49 19 d1             	sbb    %rdx,%r9
    a21e:	eb e0                	jmp    a200 <__divmodti4+0x1f0>

000000000000a220 <atexit>:
    a220:	f3 0f 1e fa          	endbr64
    a224:	48 8b 15 dd 4d 00 00 	mov    0x4ddd(%rip),%rdx        # f008 <__dso_handle>
    a22b:	31 f6                	xor    %esi,%esi
    a22d:	e9 2e 94 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a234 <_fini>:
    a234:	f3 0f 1e fa          	endbr64
    a238:	48 83 ec 08          	sub    $0x8,%rsp
    a23c:	48 83 c4 08          	add    $0x8,%rsp
    a240:	c3                   	ret
