
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 af 00 00 	mov    0xafc9(%rip),%rax        # dfd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 ad 00 00    	push   0xade2(%rip)        # de08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 ad 00 00    	jmp    *0xade4(%rip)        # de10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e ac 00 00    	jmp    *0xac4e(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e aa 00 00    	jmp    *0xaa6e(%rip)        # de18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 aa 00 00    	jmp    *0xaa66(%rip)        # de20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e aa 00 00    	jmp    *0xaa5e(%rip)        # de28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 aa 00 00    	jmp    *0xaa56(%rip)        # de30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e aa 00 00    	jmp    *0xaa4e(%rip)        # de38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 aa 00 00    	jmp    *0xaa46(%rip)        # de40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e aa 00 00    	jmp    *0xaa3e(%rip)        # de48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 aa 00 00    	jmp    *0xaa36(%rip)        # de50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e aa 00 00    	jmp    *0xaa2e(%rip)        # de58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 aa 00 00    	jmp    *0xaa26(%rip)        # de60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e aa 00 00    	jmp    *0xaa1e(%rip)        # de68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 aa 00 00    	jmp    *0xaa16(%rip)        # de70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e aa 00 00    	jmp    *0xaa0e(%rip)        # de78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 aa 00 00    	jmp    *0xaa06(%rip)        # de80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe a9 00 00    	jmp    *0xa9fe(%rip)        # de88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 a9 00 00    	jmp    *0xa9f6(%rip)        # de90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee a9 00 00    	jmp    *0xa9ee(%rip)        # de98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 a9 00 00    	jmp    *0xa9e6(%rip)        # dea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de a9 00 00    	jmp    *0xa9de(%rip)        # dea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 a9 00 00    	jmp    *0xa9d6(%rip)        # deb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce a9 00 00    	jmp    *0xa9ce(%rip)        # deb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 a9 00 00    	jmp    *0xa9c6(%rip)        # dec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be a9 00 00    	jmp    *0xa9be(%rip)        # dec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 a9 00 00    	jmp    *0xa9b6(%rip)        # ded0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae a9 00 00    	jmp    *0xa9ae(%rip)        # ded8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 a9 00 00    	jmp    *0xa9a6(%rip)        # dee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e a9 00 00    	jmp    *0xa99e(%rip)        # dee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 a9 00 00    	jmp    *0xa996(%rip)        # def0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e a9 00 00    	jmp    *0xa98e(%rip)        # def8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 a9 00 00    	jmp    *0xa986(%rip)        # df00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e a9 00 00    	jmp    *0xa97e(%rip)        # df08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 a9 00 00    	jmp    *0xa976(%rip)        # df10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e a9 00 00    	jmp    *0xa96e(%rip)        # df18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 a9 00 00    	jmp    *0xa966(%rip)        # df20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e a9 00 00    	jmp    *0xa95e(%rip)        # df28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 a9 00 00    	jmp    *0xa956(%rip)        # df30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e a9 00 00    	jmp    *0xa94e(%rip)        # df38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 a9 00 00    	jmp    *0xa946(%rip)        # df40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e a9 00 00    	jmp    *0xa93e(%rip)        # df48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 a9 00 00    	jmp    *0xa936(%rip)        # df50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e a9 00 00    	jmp    *0xa92e(%rip)        # df58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 a9 00 00    	jmp    *0xa926(%rip)        # df60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e a9 00 00    	jmp    *0xa91e(%rip)        # df68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 a9 00 00    	jmp    *0xa916(%rip)        # df70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e a9 00 00    	jmp    *0xa90e(%rip)        # df78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 a9 00 00    	jmp    *0xa906(%rip)        # df80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe a8 00 00    	jmp    *0xa8fe(%rip)        # df88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 a8 00 00    	jmp    *0xa8f6(%rip)        # df90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee a8 00 00    	jmp    *0xa8ee(%rip)        # df98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 a8 00 00    	jmp    *0xa8e6(%rip)        # dfa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de a8 00 00    	jmp    *0xa8de(%rip)        # dfa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 a8 00 00    	jmp    *0xa8d6(%rip)        # dfb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce a8 00 00    	jmp    *0xa8ce(%rip)        # dfb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 a8 00 00    	jmp    *0xa8c6(%rip)        # dfc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 69 00 00 	lea    0x697a(%rip),%r9        # a091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 69 00 00 	lea    0x6977(%rip),%r8        # a095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 8b 00 00 	lea    0x8ba1(%rip),%rax        # c320 <fwp_fn_table>
    377f:	48 89 05 32 cc 01 00 	mov    %rax,0x1cc32(%rip)        # 203b8 <fwp_fns>
    3786:	48 8b 05 93 a8 00 00 	mov    0xa893(%rip),%rax        # e020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c cc 01 00 	mov    %rax,0x1cc2c(%rip)        # 203c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 2f 6a 00 00 	lea    0x6a2f(%rip),%rdi        # a1cf <_IO_stdin_used+0x1cf>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 a8 00 00 	mov    0xa818(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f 57 00 00 	lea    0x573f(%rip),%rdx        # 8fa0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 a7 00 00 	mov    0xa783(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 a7 01 00    	mov    0x1a7d8(%rip),%eax        # 1e080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d df 68 00 00 	lea    0x68df(%rip),%rdi        # a1d8 <_IO_stdin_used+0x1d8>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d e6 6f 00 00 	lea    0x6fe6(%rip),%rdi        # a8f0 <_IO_stdin_used+0x8f0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d a0 6f 00 00 	lea    0x6fa0(%rip),%rdi        # a8c8 <_IO_stdin_used+0x8c8>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 64 6f 00 00 	lea    0x6f64(%rip),%rdi        # a898 <_IO_stdin_used+0x898>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d 30 6f 00 00 	lea    0x6f30(%rip),%rdi        # a870 <_IO_stdin_used+0x870>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 a6 00 00    	call   *0xa653(%rip)        # dfc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 91 a6 00 00 	lea    0xa691(%rip),%rdi        # e018 <__TMC_END__>
    3987:	48 8d 05 8a a6 00 00 	lea    0xa68a(%rip),%rax        # e018 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 a6 00 00 	mov    0xa636(%rip),%rax        # dfd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 61 a6 00 00 	lea    0xa661(%rip),%rdi        # e018 <__TMC_END__>
    39b7:	48 8d 35 5a a6 00 00 	lea    0xa65a(%rip),%rsi        # e018 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 a6 00 00 	mov    0xa605(%rip),%rax        # dfe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d a6 00 00 00 	cmpb   $0x0,0xa64d(%rip)        # e048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 a5 00 00 	cmpq   $0x0,0xa5e2(%rip)        # dfe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 a5 00 00 	mov    0xa5f6(%rip),%rdi        # e008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 a6 00 00 01 	movb   $0x1,0xa625(%rip)        # e048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce a4 01 00 	add    0x1a4ce(%rip),%rdx        # 1e0f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc a4 01 00 	add    0x1a4bc(%rip),%rax        # 1e0f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 c7 01 00 	mov    0x1c749(%rip),%rdi        # 203c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 a3 00 00 	mov    0xa394(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 a3 00 00 	mov    0xa381(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 63 00 00 	lea    0x6345(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 a3 00 00 	mov    0xa372(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 aa 01 00 	mov    0x1aa41(%rip),%rax        # 1e740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 a3 01 00 	mov    0x1a381(%rip),%rax        # 1e100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d a3 01 00 	sub    0x1a36d(%rip),%rax        # 1e0f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 0d 6c 00 00 	lea    0x6c0d(%rip),%rsi        # a9d0 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b bd 01 00 	mov    0x1bd5b(%rip),%rax        # 1fb50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 bd 01 00 	lea    0x1bd54(%rip),%r8        # 1fb50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 bd 01 00 	mov    0x1bd35(%rip),%rbx        # 1fb38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 bd 01 00 	mov    0x1bd45(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 bc 01 00 	mov    0x1bce1(%rip),%rdi        # 1fb40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a bd 01 00 	sub    %rsi,0x1bd2a(%rip)        # 1fb90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba bc 01 00 	mov    0x1bcba(%rip),%rax        # 1fb30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 bc 01 00 	add    0x1bc70(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e bc 01 00 	mov    0x1bc7e(%rip),%rsi        # 1fb40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c bc 01 00 	mov    0x1bc8c(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b bc 01 00 	mov    %r12,0x1bc3b(%rip)        # 1fb40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 bc 01 00 	mov    %rbp,0x1bc29(%rip)        # 1fb38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e bc 01 00 	cmp    %rdi,0x1bc0e(%rip)        # 1fb28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 bc 01 00 	mov    %rdi,0x1bc05(%rip)        # 1fb28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 bc 01 00 	sub    %rdi,0x1bc49(%rip)        # 1fb90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 bb 01 00 	mov    0x1bbf1(%rip),%rax        # 1fb48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea bb 01 00 	lea    0x1bbea(%rip),%r8        # 1fb48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd 9f 00 00 	mov    0x9ffd(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 5f 00 00 	lea    0x5fb4(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 a6 01 00 	cmp    0x1a689(%rip),%rdi        # 1e740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f a6 01 00 	mov    0x1a64f(%rip),%rax        # 1e720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d a6 01 00 	mov    %rdi,0x1a62d(%rip)        # 1e720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 a6 01 00 	mov    %rdi,0x1a609(%rip)        # 1e728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 5f 00 00 	lea    0x5fdb(%rip),%rsi        # a13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 5e 00 00 	lea    0x5ea7(%rip),%rsi        # a01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 9e 00 00 	mov    0x9e78(%rip),%rdi        # e040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 5e 00 00 	lea    0x5e51(%rip),%rdx        # a020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 9e 00 00 	mov    0x9e60(%rip),%rdi        # e040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 9d 00 00 	mov    0x9d71(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 5d 00 00 	lea    0x5d28(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 5d 00 00 	lea    0x5d32(%rip),%rdi        # a02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 5c 00 00 	lea    0x5cba(%rip),%rdi        # a049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 48 62 00 00 	lea    0x6248(%rip),%rdi        # a5e8 <_IO_stdin_used+0x5e8>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 30 66 00 	movdqa 0x6630(%rip),%xmm0        # a9f0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a bf 01 00 	add    0x1bf9a(%rip),%rax        # 203b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d a4 61 00 00 	lea    0x61a4(%rip),%rdi        # a618 <_IO_stdin_used+0x618>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 9c 01 00 	cmp    %rax,0x19c55(%rip)        # 1e0e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 9c 01 00 	add    0x19c50(%rip),%rax        # 1e0f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d 8d 61 00 00 	lea    0x618d(%rip),%rdi        # a648 <_IO_stdin_used+0x648>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 5b 00 00 	lea    0x5b92(%rip),%r8        # a065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 59 00 00 	lea    0x59e7(%rip),%r8        # a074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 58 00 00 	lea    0x5874(%rip),%r8        # a06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 56 00 00 	lea    0x564c(%rip),%rdi        # a079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 57 00 00 	lea    0x5736(%rip),%rsi        # a184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 b0 01 00 	mov    0x1b065(%rip),%r9        # 1fb28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be b0 01 00 	mov    0x1b0be(%rip),%r8        # 1fb88 <fwp_heap+0x1428>
    4aca:	48 8d 15 c7 5b 00 00 	lea    0x5bc7(%rip),%rdx        # a698 <_IO_stdin_used+0x698>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 b0 01 00 	mov    0x1b0a6(%rip),%rcx        # 1fb80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 b0 01 	movsd  0x1b0b4(%rip),%xmm1        # 1fba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 b0 01 	movsd  0x1b0a4(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 95 00 00 	mov    0x9545(%rip),%rdi        # e040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 c8 5e 00 	movdqa 0x5ec8(%rip),%xmm0        # aa00 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f ab 01 00 	lea    0x1ab5f(%rip),%rax        # 1f6a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 f1 5e 00 	movdqa 0x5ef1(%rip),%xmm2        # aa40 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 ab 01 00 	movaps %xmm0,0x1ab05(%rip)        # 1f660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 ad 5e 00 	movdqa 0x5ead(%rip),%xmm0        # aa10 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 af 01 00 01 	movl   $0x1,0x1af93(%rip)        # 1fb04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 aa 01 00 	movaps %xmm0,0x1aaf3(%rip)        # 1f670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 9b 5e 00 	movdqa 0x5e9b(%rip),%xmm0        # aa20 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 f4 aa 01 00 	movaps %xmm0,0x1aaf4(%rip)        # 1f680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 9c 5e 00 	movdqa 0x5e9c(%rip),%xmm0        # aa30 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 f5 aa 01 00 	movaps %xmm0,0x1aaf5(%rip)        # 1f690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 9b 01 00 	lea    0x19b75(%rip),%r8        # 1e760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ae 01 00 	mov    %rax,0x1ae90(%rip)        # 1fb18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ae 01 00 	mov    %r12,0x1ae6e(%rip)        # 1fb20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ae 01 00 	mov    %rax,0x1ae57(%rip)        # 1fb10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ae 01 00 	mov    %rbx,0x1ae70(%rip)        # 1fb30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ae 01 00 	mov    %rsi,0x1ae99(%rip)        # 1fb60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 53 00 00 	lea    0x53d6(%rip),%rdi        # a0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ae 01 00 	mov    %rax,0x1ae78(%rip)        # 1fb58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc ad 01 00    	mov    %eax,0x1adfc(%rip)        # 1fb08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec 99 01 00 	mov    0x199ec(%rip),%r8        # 1e720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c 99 01 00 	mov    %rbx,0x1991c(%rip)        # 1e728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 99 01 00 	mov    %r8,0x19908(%rip)        # 1e720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 52 00 00 	lea    0x5239(%rip),%rdi        # a0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd 91 01 00 	lea    0x191dd(%rip),%rdi        # 1e0a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 91 01 00 	movaps %xmm0,0x191c5(%rip)        # 1e0a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 91 01 00 	mov    %rax,0x191a1(%rip)        # 1e088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 91 01 00 	movaps %xmm0,0x191c2(%rip)        # 1e0b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 91 01 00 	movaps %xmm0,0x191c6(%rip)        # 1e0c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 91 01 00 	mov    %rdx,0x191c7(%rip)        # 1e0d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 51 00 00 	lea    0x5190(%rip),%rdi        # a0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 97 01 00 	mov    0x19797(%rip),%rbx        # 1e718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca 8f 00 00 	mov    0x8fca(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d a3 56 00 00 	lea    0x56a3(%rip),%rdi        # a720 <_IO_stdin_used+0x720>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d 96 01 00 	mov    0x1966d(%rip),%rax        # 1e720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 96 01 00 	mov    %rdx,0x19647(%rip)        # 1e720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 95 01 00 	mov    0x19594(%rip),%rbx        # 1e718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 95 01 00 	mov    %rbx,0x19551(%rip)        # 1e718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 95 01 00 	mov    %rdx,0x19551(%rip)        # 1e728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 95 01 00 	lea    0x19566(%rip),%rsi        # 1e760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 b0 01 00 	addq   $0x1,0x1b0e5(%rip)        # 203a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 77 54 00 00 	lea    0x5477(%rip),%rdi        # a750 <_IO_stdin_used+0x750>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d 88 54 00 00 	lea    0x5488(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 4d 00 00 	lea    0x4dd4(%rip),%rdi        # a0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e 94 01 00 	lea    0x1941e(%rip),%rcx        # 1e760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f b0 01 00 	subq   $0x1,0x1b01f(%rip)        # 203a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d e3 53 00 00 	lea    0x53e3(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 b0 01 00 	cmpq   $0x0,0x1b000(%rip)        # 203a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 af 01 00 	sub    %rax,0x1af55(%rip)        # 203b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 af 01 00 	add    %r12,0x1af33(%rip)        # 203b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f a6 01 00 	mov    0x1a68f(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c 92 01 00 	lea    0x1928c(%rip),%rax        # 1e760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 a5 01 00 	add    0x1a5e3(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 a5 01 00 	mov    0x1a5b0(%rip),%rsi        # 1fb10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 a5 01 00 	mov    0x1a5d1(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 a5 01 00 	add    0x1a5c5(%rip),%r8        # 1fb58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d a5 01 	addsd  0x1a58d(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 91 01 00 	lea    0x19142(%rip),%rax        # 1e760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c a5 01 00 	sub    %rdi,0x1a54c(%rip)        # 1fb80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 a5 01 	movsd  %xmm0,0x1a564(%rip)        # 1fba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e a5 01 00 	sub    %rdx,0x1a51e(%rip)        # 1fb80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 a5 01 	addsd  0x1a524(%rip),%xmm0        # 1fba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 a5 01 	movsd  %xmm0,0x1a518(%rip)        # 1fba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af a4 01 00 	mov    0x1a4af(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 a4 01 00 	add    %rcx,0x1a4a9(%rip)        # 1fb90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 a4 01 00 	cmp    0x1a462(%rip),%r9        # 1fb50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 a4 01 00 	mov    %r9,0x1a459(%rip)        # 1fb50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a a4 01 00 	cmp    0x1a44a(%rip),%r9        # 1fb48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d a4 01 00 	mov    %r9,0x1a43d(%rip)        # 1fb48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 a3 01 00 	add    0x1a353(%rip),%rdi        # 1fb58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 8f 01 00 	lea    0x18f30(%rip),%r15        # 1e760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 a2 01 00 	add    0x1a2a0(%rip),%r12        # 1fb10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 a2 01 00 	add    0x1a2f9(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 a2 01 00 	cmp    %rax,0x1a2f8(%rip)        # 1fb88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 a2 01 00 	mov    %rax,0x1a2e9(%rip)        # 1fb80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 a2 01 00 	mov    %rax,0x1a2e8(%rip)        # 1fb88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 a2 01 	addsd  0x1a2e4(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc a2 01 	movsd  %xmm0,0x1a2dc(%rip)        # 1fb98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 a2 01 00    	mov    0x1a223(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f 8e 01 00 	lea    0x18e5f(%rip),%rdi        # 1e760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 a2 01 00 	add    0x1a218(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 a2 01 00 	cmp    %rax,0x1a213(%rip)        # 1fb88 <fwp_heap+0x1428>
    5975:	48 89 05 04 a2 01 00 	mov    %rax,0x1a204(%rip)        # 1fb80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 a2 01 00 	mov    %rax,0x1a203(%rip)        # 1fb88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff a1 01 	addsd  0x1a1ff(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 a1 01 	movsd  %xmm0,0x1a1f7(%rip)        # 1fb98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae a0 01 00    	mov    0x1a0ae(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 8c 01 00 	lea    0x18ce5(%rip),%rax        # 1e760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b a0 01 00 	add    0x1a09b(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a a0 01 00 	cmp    %rax,0x1a09a(%rip)        # 1fb88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b a0 01 00 	mov    %rax,0x1a08b(%rip)        # 1fb80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a a0 01 00 	mov    %rax,0x1a08a(%rip)        # 1fb88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 a0 01 	addsd  0x1a086(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e a0 01 	movsd  %xmm0,0x1a07e(%rip)        # 1fb98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e 9f 01 00    	mov    0x19f7e(%rip),%eax        # 1fb04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d 9b 01 00 	movzbl 0x19b6d(%rip),%eax        # 1f702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 8b 01 00 	lea    0x18bc4(%rip),%rdx        # 1e760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 9f 01 00 	add    0x19f95(%rip),%rax        # 1fb80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 9f 01 00 	cmp    %rax,0x19f90(%rip)        # 1fb88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 9f 01 00 	mov    %rax,0x19f81(%rip)        # 1fb80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 9f 01 00 	mov    %rax,0x19f80(%rip)        # 1fb88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f 9f 01 	addsd  0x19f7f(%rip),%xmm0        # 1fb98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 9f 01 	movsd  %xmm0,0x19f77(%rip)        # 1fb98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_p_ad_push.constprop.0>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	49 89 d5             	mov    %rdx,%r13
    5ca9:	41 54                	push   %r12
    5cab:	49 89 fc             	mov    %rdi,%r12
    5cae:	55                   	push   %rbp
    5caf:	53                   	push   %rbx
    5cb0:	48 83 ec 38          	sub    $0x38,%rsp
    5cb4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5cb9:	48 85 ff             	test   %rdi,%rdi
    5cbc:	79 09                	jns    5cc7 <fwp_p_ad_push.constprop.0+0x27>
    5cbe:	48 85 d2             	test   %rdx,%rdx
    5cc1:	0f 88 a9 01 00 00    	js     5e70 <fwp_p_ad_push.constprop.0+0x1d0>
    5cc7:	48 89 f8             	mov    %rdi,%rax
    5cca:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cce:	48 09 d0             	or     %rdx,%rax
    5cd1:	0f 89 79 01 00 00    	jns    5e50 <fwp_p_ad_push.constprop.0+0x1b0>
    5cd7:	48 89 f8             	mov    %rdi,%rax
    5cda:	48 c1 f8 20          	sar    $0x20,%rax
    5cde:	48 85 ff             	test   %rdi,%rdi
    5ce1:	79 24                	jns    5d07 <fwp_p_ad_push.constprop.0+0x67>
    5ce3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5ce8:	48 89 d0             	mov    %rdx,%rax
    5ceb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5cf2:	00 
    5cf3:	49 89 d4             	mov    %rdx,%r12
    5cf6:	48 c1 f8 20          	sar    $0x20,%rax
    5cfa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d01:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d07:	48 89 c7             	mov    %rax,%rdi
    5d0a:	e8 71 e7 ff ff       	call   4480 <fwp_tape_of>
    5d0f:	48 89 c3             	mov    %rax,%rbx
    5d12:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d17:	0f 85 f0 02 00 00    	jne    600d <fwp_p_ad_push.constprop.0+0x36d>
    5d1d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5d21:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5d28:	0f 8f 51 02 00 00    	jg     5f7f <fwp_p_ad_push.constprop.0+0x2df>
    5d2e:	44 89 e0             	mov    %r12d,%eax
    5d31:	49 39 c7             	cmp    %rax,%r15
    5d34:	0f 8e 51 02 00 00    	jle    5f8b <fwp_p_ad_push.constprop.0+0x2eb>
    5d3a:	4d 85 ed             	test   %r13,%r13
    5d3d:	78 0c                	js     5d4b <fwp_p_ad_push.constprop.0+0xab>
    5d3f:	44 89 e8             	mov    %r13d,%eax
    5d42:	49 39 c7             	cmp    %rax,%r15
    5d45:	0f 8e 40 02 00 00    	jle    5f8b <fwp_p_ad_push.constprop.0+0x2eb>
    5d4b:	4d 89 fe             	mov    %r15,%r14
    5d4e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5d52:	49 8d 46 01          	lea    0x1(%r14),%rax
    5d56:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5d5c:	0f 87 1d 02 00 00    	ja     5f7f <fwp_p_ad_push.constprop.0+0x2df>
    5d62:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5d66:	48 39 e8             	cmp    %rbp,%rax
    5d69:	0f 8e 31 01 00 00    	jle    5ea0 <fwp_p_ad_push.constprop.0+0x200>
    5d6f:	48 85 ed             	test   %rbp,%rbp
    5d72:	b9 40 00 00 00       	mov    $0x40,%ecx
    5d77:	48 0f 44 e9          	cmove  %rcx,%rbp
    5d7b:	48 39 e8             	cmp    %rbp,%rax
    5d7e:	7e 20                	jle    5da0 <fwp_p_ad_push.constprop.0+0x100>
    5d80:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5d87:	0f 8f 03 01 00 00    	jg     5e90 <fwp_p_ad_push.constprop.0+0x1f0>
    5d8d:	48 01 ed             	add    %rbp,%rbp
    5d90:	48 39 e8             	cmp    %rbp,%rax
    5d93:	7f eb                	jg     5d80 <fwp_p_ad_push.constprop.0+0xe0>
    5d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d9c:	00 00 00 00 
    5da0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5da7:	00 
    5da8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5dac:	48 89 c6             	mov    %rax,%rsi
    5daf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5db4:	e8 17 d8 ff ff       	call   35d0 <realloc@plt>
    5db9:	48 85 c0             	test   %rax,%rax
    5dbc:	0f 84 d5 01 00 00    	je     5f97 <fwp_p_ad_push.constprop.0+0x2f7>
    5dc2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5dc6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5dca:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5dce:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5dd2:	48 89 e9             	mov    %rbp,%rcx
    5dd5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5dd9:	48 c1 e1 04          	shl    $0x4,%rcx
    5ddd:	48 89 ce             	mov    %rcx,%rsi
    5de0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5de5:	e8 e6 d7 ff ff       	call   35d0 <realloc@plt>
    5dea:	48 85 c0             	test   %rax,%rax
    5ded:	0f 84 a4 01 00 00    	je     5f97 <fwp_p_ad_push.constprop.0+0x2f7>
    5df3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5df7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5dfc:	4d 85 f6             	test   %r14,%r14
    5dff:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5e03:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e08:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5e0f:	00 
    5e10:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5e17:	00 
    5e18:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5e1c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5e23:	00 
    5e24:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5e28:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5e2c:	0f 85 e6 00 00 00    	jne    5f18 <fwp_p_ad_push.constprop.0+0x278>
    5e32:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5e36:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5e3a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5e3e:	49 01 c8             	add    %rcx,%r8
    5e41:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5e45:	eb 79                	jmp    5ec0 <fwp_p_ad_push.constprop.0+0x220>
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	48 89 d0             	mov    %rdx,%rax
    5e53:	48 c1 ff 20          	sar    $0x20,%rdi
    5e57:	48 c1 f8 20          	sar    $0x20,%rax
    5e5b:	48 39 c7             	cmp    %rax,%rdi
    5e5e:	0f 84 a3 fe ff ff    	je     5d07 <fwp_p_ad_push.constprop.0+0x67>
    5e64:	48 8d 3d 35 49 00 00 	lea    0x4935(%rip),%rdi        # a7a0 <_IO_stdin_used+0x7a0>
    5e6b:	e8 30 e3 ff ff       	call   41a0 <fwp_trap>
    5e70:	48 83 c4 38          	add    $0x38,%rsp
    5e74:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5e7b:	5b                   	pop    %rbx
    5e7c:	5d                   	pop    %rbp
    5e7d:	41 5c                	pop    %r12
    5e7f:	41 5d                	pop    %r13
    5e81:	41 5e                	pop    %r14
    5e83:	41 5f                	pop    %r15
    5e85:	c3                   	ret
    5e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e8d:	00 00 00 
    5e90:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5e95:	e9 06 ff ff ff       	jmp    5da0 <fwp_p_ad_push.constprop.0+0x100>
    5e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ea0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5ea4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5ea8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5eaf:	00 
    5eb0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5eb7:	00 
    5eb8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5ebc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5ec0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5ec6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5eca:	4d 85 ed             	test   %r13,%r13
    5ecd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5ed2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5ed8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5edf:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ee3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ee7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5eeb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    5ef1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ef5:	48 83 c4 38          	add    $0x38,%rsp
    5ef9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f00:	ff ff ff 
    5f03:	4c 21 e0             	and    %r12,%rax
    5f06:	5b                   	pop    %rbx
    5f07:	5d                   	pop    %rbp
    5f08:	4c 09 f8             	or     %r15,%rax
    5f0b:	41 5c                	pop    %r12
    5f0d:	41 5d                	pop    %r13
    5f0f:	41 5e                	pop    %r14
    5f11:	41 5f                	pop    %r15
    5f13:	c3                   	ret
    5f14:	0f 1f 40 00          	nopl   0x0(%rax)
    5f18:	48 39 ca             	cmp    %rcx,%rdx
    5f1b:	49 89 d6             	mov    %rdx,%r14
    5f1e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5f23:	48 0f 43 ca          	cmovae %rdx,%rcx
    5f27:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    5f2c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    5f31:	48 29 d1             	sub    %rdx,%rcx
    5f34:	4c 89 ca             	mov    %r9,%rdx
    5f37:	e8 24 d6 ff ff       	call   3560 <__memmove_chk@plt>
    5f3c:	4c 03 73 30          	add    0x30(%rbx),%r14
    5f40:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    5f45:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    5f49:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    5f4e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    5f52:	48 03 7b 20          	add    0x20(%rbx),%rdi
    5f56:	4c 89 d2             	mov    %r10,%rdx
    5f59:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    5f5e:	e8 ad d6 ff ff       	call   3610 <memmove@plt>
    5f63:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5f67:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5f6b:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    5f70:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5f75:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    5f7a:	e9 b7 fe ff ff       	jmp    5e36 <fwp_p_ad_push.constprop.0+0x196>
    5f7f:	48 8d 3d 63 41 00 00 	lea    0x4163(%rip),%rdi        # a0e9 <_IO_stdin_used+0xe9>
    5f86:	e8 15 e2 ff ff       	call   41a0 <fwp_trap>
    5f8b:	48 8d 3d 72 41 00 00 	lea    0x4172(%rip),%rdi        # a104 <_IO_stdin_used+0x104>
    5f92:	e8 09 e2 ff ff       	call   41a0 <fwp_trap>
    5f97:	48 89 df             	mov    %rbx,%rdi
    5f9a:	e8 61 dc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5f9f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fa3:	e8 18 d4 ff ff       	call   33c0 <free@plt>
    5fa8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5fac:	e8 0f d4 ff ff       	call   33c0 <free@plt>
    5fb1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    5fb5:	e8 06 d4 ff ff       	call   33c0 <free@plt>
    5fba:	31 c9                	xor    %ecx,%ecx
    5fbc:	31 c0                	xor    %eax,%eax
    5fbe:	31 d2                	xor    %edx,%edx
    5fc0:	89 53 04             	mov    %edx,0x4(%rbx)
    5fc3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fc7:	ba 13 00 00 00       	mov    $0x13,%edx
    5fcc:	be 01 00 00 00       	mov    $0x1,%esi
    5fd1:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    5fd5:	48 8d 3d 2c 40 00 00 	lea    0x402c(%rip),%rdi        # a008 <_IO_stdin_used+0x8>
    5fdc:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    5fe0:	48 8b 0d 59 80 00 00 	mov    0x8059(%rip),%rcx        # e040 <stderr@GLIBC_2.2.5>
    5fe7:	48 89 43 40          	mov    %rax,0x40(%rbx)
    5feb:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5fef:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    5ff3:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    5ff7:	e8 84 d6 ff ff       	call   3680 <fwrite@plt>
    5ffc:	31 ff                	xor    %edi,%edi
    5ffe:	e8 bd d5 ff ff       	call   35c0 <fflush@plt>
    6003:	bf 66 00 00 00       	mov    $0x66,%edi
    6008:	e8 93 d6 ff ff       	call   36a0 <_Exit@plt>
    600d:	48 8d 3d d4 47 00 00 	lea    0x47d4(%rip),%rdi        # a7e8 <_IO_stdin_used+0x7e8>
    6014:	e8 87 e1 ff ff       	call   41a0 <fwp_trap>
    6019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006020 <w120>:
    6020:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6024:	41 55                	push   %r13
    6026:	48 89 fa             	mov    %rdi,%rdx
    6029:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    602d:	41 54                	push   %r12
    602f:	49 89 fc             	mov    %rdi,%r12
    6032:	55                   	push   %rbp
    6033:	53                   	push   %rbx
    6034:	48 89 f3             	mov    %rsi,%rbx
    6037:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    603c:	48 89 f1             	mov    %rsi,%rcx
    603f:	48 83 ec 28          	sub    $0x28,%rsp
    6043:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6049:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    604f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6055:	e8 46 fc ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    605a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6060:	48 89 da             	mov    %rbx,%rdx
    6063:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6069:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6070:	00 f0 3f 
    6073:	48 89 c7             	mov    %rax,%rdi
    6076:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    607d:	00 f0 bf 
    6080:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6085:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    608b:	e8 10 fc ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6090:	f2 0f 10 05 e8 49 00 	movsd  0x49e8(%rip),%xmm0        # aa80 <msg.4+0xb0>
    6097:	00 
    6098:	4c 89 e7             	mov    %r12,%rdi
    609b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    60a1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    60a8:	00 f0 3f 
    60ab:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    60b2:	49 89 c5             	mov    %rax,%r13
    60b5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    60bc:	00 f0 bf 
    60bf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    60c4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    60ca:	e8 d1 fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    60cf:	48 89 e9             	mov    %rbp,%rcx
    60d2:	4c 89 ea             	mov    %r13,%rdx
    60d5:	48 89 ee             	mov    %rbp,%rsi
    60d8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    60de:	4c 89 ef             	mov    %r13,%rdi
    60e1:	49 89 c4             	mov    %rax,%r12
    60e4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    60e8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    60ee:	e8 ad fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    60f3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    60f9:	f2 0f 59 1d 87 49 00 	mulsd  0x4987(%rip),%xmm3        # aa88 <msg.4+0xb8>
    6100:	00 
    6101:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6108:	00 59 40 
    610b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6110:	48 89 c2             	mov    %rax,%rdx
    6113:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    611a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6120:	e8 7b fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6125:	48 89 d9             	mov    %rbx,%rcx
    6128:	4c 89 e2             	mov    %r12,%rdx
    612b:	48 89 de             	mov    %rbx,%rsi
    612e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6134:	4c 89 e7             	mov    %r12,%rdi
    6137:	48 89 c5             	mov    %rax,%rbp
    613a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    613e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6144:	e8 57 fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6149:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    614f:	48 89 ea             	mov    %rbp,%rdx
    6152:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6158:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    615f:	00 f0 3f 
    6162:	48 89 c7             	mov    %rax,%rdi
    6165:	48 89 ce             	mov    %rcx,%rsi
    6168:	66 48 0f 7e db       	movq   %xmm3,%rbx
    616d:	e8 2e fb ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    6172:	48 83 c4 28          	add    $0x28,%rsp
    6176:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    617b:	5b                   	pop    %rbx
    617c:	5d                   	pop    %rbp
    617d:	41 5c                	pop    %r12
    617f:	41 5d                	pop    %r13
    6181:	c3                   	ret
    6182:	0f 1f 00             	nopl   (%rax)
    6185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    618c:	00 00 00 00 

0000000000006190 <w176.constprop.0>:
    6190:	41 54                	push   %r12
    6192:	55                   	push   %rbp
    6193:	53                   	push   %rbx
    6194:	48 83 ec 10          	sub    $0x10,%rsp
    6198:	4c 8b 27             	mov    (%rdi),%r12
    619b:	4d 85 e4             	test   %r12,%r12
    619e:	74 58                	je     61f8 <w176.constprop.0+0x68>
    61a0:	48 89 fd             	mov    %rdi,%rbp
    61a3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61a7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    61ae:	31 db                	xor    %ebx,%ebx
    61b0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    61b6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    61bb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    61c2:	00 f0 3f 
    61c5:	48 83 c3 02          	add    $0x2,%rbx
    61c9:	48 89 ce             	mov    %rcx,%rsi
    61cc:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    61d2:	e8 c9 fa ff ff       	call   5ca0 <fwp_p_ad_push.constprop.0>
    61d7:	4c 39 e3             	cmp    %r12,%rbx
    61da:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    61e0:	48 89 c7             	mov    %rax,%rdi
    61e3:	72 cb                	jb     61b0 <w176.constprop.0+0x20>
    61e5:	48 83 c4 10          	add    $0x10,%rsp
    61e9:	48 89 f8             	mov    %rdi,%rax
    61ec:	5b                   	pop    %rbx
    61ed:	5d                   	pop    %rbp
    61ee:	41 5c                	pop    %r12
    61f0:	c3                   	ret
    61f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    61f8:	48 83 c4 10          	add    $0x10,%rsp
    61fc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6203:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6207:	5b                   	pop    %rbx
    6208:	48 89 f8             	mov    %rdi,%rax
    620b:	5d                   	pop    %rbp
    620c:	41 5c                	pop    %r12
    620e:	c3                   	ret
    620f:	90                   	nop

0000000000006210 <fwp_rc_share>:
    6210:	48 8b 05 21 99 01 00 	mov    0x19921(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    6217:	48 2b 3d f2 98 01 00 	sub    0x198f2(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    621e:	48 c1 e0 10          	shl    $0x10,%rax
    6222:	48 39 c7             	cmp    %rax,%rdi
    6225:	73 4a                	jae    6271 <fwp_rc_share+0x61>
    6227:	48 89 f8             	mov    %rdi,%rax
    622a:	48 c1 e8 10          	shr    $0x10,%rax
    622e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6232:	48 8b 05 1f 99 01 00 	mov    0x1991f(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    6239:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    623d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6241:	48 85 d2             	test   %rdx,%rdx
    6244:	74 2b                	je     6271 <fwp_rc_share+0x61>
    6246:	0f b6 08             	movzbl (%rax),%ecx
    6249:	80 f9 02             	cmp    $0x2,%cl
    624c:	74 2a                	je     6278 <fwp_rc_share+0x68>
    624e:	80 f9 01             	cmp    $0x1,%cl
    6251:	75 1e                	jne    6271 <fwp_rc_share+0x61>
    6253:	8b 48 18             	mov    0x18(%rax),%ecx
    6256:	0f b7 ff             	movzwl %di,%edi
    6259:	8b 40 1c             	mov    0x1c(%rax),%eax
    625c:	48 0f af f9          	imul   %rcx,%rdi
    6260:	48 c1 ef 20          	shr    $0x20,%rdi
    6264:	48 39 c7             	cmp    %rax,%rdi
    6267:	73 08                	jae    6271 <fwp_rc_share+0x61>
    6269:	48 01 fa             	add    %rdi,%rdx
    626c:	80 3a 00             	cmpb   $0x0,(%rdx)
    626f:	75 0d                	jne    627e <fwp_rc_share+0x6e>
    6271:	c3                   	ret
    6272:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6278:	66 85 ff             	test   %di,%di
    627b:	74 ef                	je     626c <fwp_rc_share+0x5c>
    627d:	c3                   	ret
    627e:	50                   	push   %rax
    627f:	48 8d 3d 92 45 00 00 	lea    0x4592(%rip),%rdi        # a818 <_IO_stdin_used+0x818>
    6286:	e8 15 df ff ff       	call   41a0 <fwp_trap>
    628b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006290 <fwp_rc_free_obj>:
    6290:	48 8b 15 a1 98 01 00 	mov    0x198a1(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    6297:	48 89 f8             	mov    %rdi,%rax
    629a:	48 2b 05 6f 98 01 00 	sub    0x1986f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    62a1:	48 c1 e2 10          	shl    $0x10,%rdx
    62a5:	48 39 d0             	cmp    %rdx,%rax
    62a8:	73 5b                	jae    6305 <fwp_rc_free_obj+0x75>
    62aa:	48 89 c2             	mov    %rax,%rdx
    62ad:	48 c1 ea 10          	shr    $0x10,%rdx
    62b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    62b5:	48 8b 15 9c 98 01 00 	mov    0x1989c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    62bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    62c0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    62c4:	48 85 c9             	test   %rcx,%rcx
    62c7:	74 3c                	je     6305 <fwp_rc_free_obj+0x75>
    62c9:	0f b6 32             	movzbl (%rdx),%esi
    62cc:	40 80 fe 02          	cmp    $0x2,%sil
    62d0:	74 2e                	je     6300 <fwp_rc_free_obj+0x70>
    62d2:	40 80 fe 01          	cmp    $0x1,%sil
    62d6:	75 2d                	jne    6305 <fwp_rc_free_obj+0x75>
    62d8:	8b 72 18             	mov    0x18(%rdx),%esi
    62db:	0f b7 c0             	movzwl %ax,%eax
    62de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    62e1:	48 0f af c6          	imul   %rsi,%rax
    62e5:	48 c1 e8 20          	shr    $0x20,%rax
    62e9:	48 39 d0             	cmp    %rdx,%rax
    62ec:	73 17                	jae    6305 <fwp_rc_free_obj+0x75>
    62ee:	48 01 c1             	add    %rax,%rcx
    62f1:	80 39 01             	cmpb   $0x1,(%rcx)
    62f4:	75 0f                	jne    6305 <fwp_rc_free_obj+0x75>
    62f6:	e9 55 f2 ff ff       	jmp    5550 <fwp_mem_free>
    62fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6300:	66 85 c0             	test   %ax,%ax
    6303:	74 ec                	je     62f1 <fwp_rc_free_obj+0x61>
    6305:	c3                   	ret
    6306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    630d:	00 00 00 

0000000000006310 <fwp_rc_dup>:
    6310:	f3 0f 1e fa          	endbr64
    6314:	48 8b 05 1d 98 01 00 	mov    0x1981d(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    631b:	48 2b 3d ee 97 01 00 	sub    0x197ee(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    6322:	48 c1 e0 10          	shl    $0x10,%rax
    6326:	48 39 c7             	cmp    %rax,%rdi
    6329:	73 56                	jae    6381 <fwp_rc_dup+0x71>
    632b:	48 89 f8             	mov    %rdi,%rax
    632e:	48 c1 e8 10          	shr    $0x10,%rax
    6332:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6336:	48 8b 05 1b 98 01 00 	mov    0x1981b(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    633d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6341:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6345:	48 85 c0             	test   %rax,%rax
    6348:	74 37                	je     6381 <fwp_rc_dup+0x71>
    634a:	0f b6 0a             	movzbl (%rdx),%ecx
    634d:	80 f9 02             	cmp    $0x2,%cl
    6350:	74 36                	je     6388 <fwp_rc_dup+0x78>
    6352:	80 f9 01             	cmp    $0x1,%cl
    6355:	75 2a                	jne    6381 <fwp_rc_dup+0x71>
    6357:	8b 4a 18             	mov    0x18(%rdx),%ecx
    635a:	0f b7 ff             	movzwl %di,%edi
    635d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6360:	48 0f af f9          	imul   %rcx,%rdi
    6364:	48 c1 ef 20          	shr    $0x20,%rdi
    6368:	48 39 d7             	cmp    %rdx,%rdi
    636b:	73 14                	jae    6381 <fwp_rc_dup+0x71>
    636d:	48 01 f8             	add    %rdi,%rax
    6370:	0f b6 10             	movzbl (%rax),%edx
    6373:	84 d2                	test   %dl,%dl
    6375:	74 0a                	je     6381 <fwp_rc_dup+0x71>
    6377:	80 fa fd             	cmp    $0xfd,%dl
    637a:	77 14                	ja     6390 <fwp_rc_dup+0x80>
    637c:	83 c2 01             	add    $0x1,%edx
    637f:	88 10                	mov    %dl,(%rax)
    6381:	c3                   	ret
    6382:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6388:	66 85 ff             	test   %di,%di
    638b:	74 e3                	je     6370 <fwp_rc_dup+0x60>
    638d:	c3                   	ret
    638e:	66 90                	xchg   %ax,%ax
    6390:	48 89 c7             	mov    %rax,%rdi
    6393:	e9 58 ee ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    639f:	00 

00000000000063a0 <fwp_owned_entry173>:
    63a0:	f3 0f 1e fa          	endbr64
    63a4:	48 83 ec 38          	sub    $0x38,%rsp
    63a8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    63ad:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    63b4:	00 00 
    63b6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    63bb:	31 c0                	xor    %eax,%eax
    63bd:	48 8b 07             	mov    (%rdi),%rax
    63c0:	48 03 47 10          	add    0x10(%rdi),%rax
    63c4:	0f 80 c2 00 00 00    	jo     648c <fwp_owned_entry173+0xec>
    63ca:	66 48 0f 6e c8       	movq   %rax,%xmm1
    63cf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    63d4:	31 ff                	xor    %edi,%edi
    63d6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    63da:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    63df:	e8 8c f7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    63e4:	48 8b 15 4d 97 01 00 	mov    0x1974d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    63eb:	48 89 c6             	mov    %rax,%rsi
    63ee:	48 2b 05 1b 97 01 00 	sub    0x1971b(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    63f5:	48 c1 e2 10          	shl    $0x10,%rdx
    63f9:	48 39 d0             	cmp    %rdx,%rax
    63fc:	73 4f                	jae    644d <fwp_owned_entry173+0xad>
    63fe:	48 89 c2             	mov    %rax,%rdx
    6401:	48 c1 ea 10          	shr    $0x10,%rdx
    6405:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6409:	48 8b 15 48 97 01 00 	mov    0x19748(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    6410:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6414:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6418:	48 85 d2             	test   %rdx,%rdx
    641b:	74 30                	je     644d <fwp_owned_entry173+0xad>
    641d:	0f b6 39             	movzbl (%rcx),%edi
    6420:	40 80 ff 02          	cmp    $0x2,%dil
    6424:	74 42                	je     6468 <fwp_owned_entry173+0xc8>
    6426:	40 80 ff 01          	cmp    $0x1,%dil
    642a:	75 21                	jne    644d <fwp_owned_entry173+0xad>
    642c:	8b 79 18             	mov    0x18(%rcx),%edi
    642f:	0f b7 c0             	movzwl %ax,%eax
    6432:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6435:	48 0f af c7          	imul   %rdi,%rax
    6439:	48 c1 e8 20          	shr    $0x20,%rax
    643d:	48 39 c8             	cmp    %rcx,%rax
    6440:	73 0b                	jae    644d <fwp_owned_entry173+0xad>
    6442:	48 01 c2             	add    %rax,%rdx
    6445:	80 3a ff             	cmpb   $0xff,(%rdx)
    6448:	74 26                	je     6470 <fwp_owned_entry173+0xd0>
    644a:	c6 02 01             	movb   $0x1,(%rdx)
    644d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6452:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6459:	00 00 
    645b:	75 34                	jne    6491 <fwp_owned_entry173+0xf1>
    645d:	48 89 f0             	mov    %rsi,%rax
    6460:	48 83 c4 38          	add    $0x38,%rsp
    6464:	c3                   	ret
    6465:	0f 1f 00             	nopl   (%rax)
    6468:	66 85 c0             	test   %ax,%ax
    646b:	75 e0                	jne    644d <fwp_owned_entry173+0xad>
    646d:	eb d6                	jmp    6445 <fwp_owned_entry173+0xa5>
    646f:	90                   	nop
    6470:	48 89 d7             	mov    %rdx,%rdi
    6473:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6478:	48 89 14 24          	mov    %rdx,(%rsp)
    647c:	e8 8f ee ff ff       	call   5310 <fwp_rc_forget_slot>
    6481:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6486:	48 8b 14 24          	mov    (%rsp),%rdx
    648a:	eb be                	jmp    644a <fwp_owned_entry173+0xaa>
    648c:	e8 6f d2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6491:	e8 ca cf ff ff       	call   3460 <__stack_chk_fail@plt>
    6496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    649d:	00 00 00 

00000000000064a0 <e173>:
    64a0:	f3 0f 1e fa          	endbr64
    64a4:	53                   	push   %rbx
    64a5:	48 83 ec 30          	sub    $0x30,%rsp
    64a9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    64ae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    64b5:	00 00 
    64b7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    64bc:	31 c0                	xor    %eax,%eax
    64be:	48 8b 07             	mov    (%rdi),%rax
    64c1:	48 03 47 10          	add    0x10(%rdi),%rax
    64c5:	0f 80 c9 00 00 00    	jo     6594 <e173+0xf4>
    64cb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    64d0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    64d5:	31 ff                	xor    %edi,%edi
    64d7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    64db:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    64e0:	e8 8b f6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    64e5:	48 8b 15 4c 96 01 00 	mov    0x1964c(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    64ec:	48 89 c3             	mov    %rax,%rbx
    64ef:	48 2b 05 1a 96 01 00 	sub    0x1961a(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    64f6:	48 c1 e2 10          	shl    $0x10,%rdx
    64fa:	48 39 d0             	cmp    %rdx,%rax
    64fd:	73 4f                	jae    654e <e173+0xae>
    64ff:	48 89 c2             	mov    %rax,%rdx
    6502:	48 c1 ea 10          	shr    $0x10,%rdx
    6506:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    650a:	48 8b 15 47 96 01 00 	mov    0x19647(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    6511:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6515:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6519:	48 85 d2             	test   %rdx,%rdx
    651c:	74 30                	je     654e <e173+0xae>
    651e:	0f b6 31             	movzbl (%rcx),%esi
    6521:	40 80 fe 02          	cmp    $0x2,%sil
    6525:	74 49                	je     6570 <e173+0xd0>
    6527:	40 80 fe 01          	cmp    $0x1,%sil
    652b:	75 21                	jne    654e <e173+0xae>
    652d:	8b 71 18             	mov    0x18(%rcx),%esi
    6530:	0f b7 c0             	movzwl %ax,%eax
    6533:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6536:	48 0f af c6          	imul   %rsi,%rax
    653a:	48 c1 e8 20          	shr    $0x20,%rax
    653e:	48 39 c8             	cmp    %rcx,%rax
    6541:	73 0b                	jae    654e <e173+0xae>
    6543:	48 01 c2             	add    %rax,%rdx
    6546:	80 3a ff             	cmpb   $0xff,(%rdx)
    6549:	74 35                	je     6580 <e173+0xe0>
    654b:	c6 02 01             	movb   $0x1,(%rdx)
    654e:	48 89 df             	mov    %rbx,%rdi
    6551:	e8 ba fc ff ff       	call   6210 <fwp_rc_share>
    6556:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    655b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6562:	00 00 
    6564:	75 33                	jne    6599 <e173+0xf9>
    6566:	48 83 c4 30          	add    $0x30,%rsp
    656a:	48 89 d8             	mov    %rbx,%rax
    656d:	5b                   	pop    %rbx
    656e:	c3                   	ret
    656f:	90                   	nop
    6570:	66 85 c0             	test   %ax,%ax
    6573:	75 d9                	jne    654e <e173+0xae>
    6575:	eb cf                	jmp    6546 <e173+0xa6>
    6577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    657e:	00 00 
    6580:	48 89 d7             	mov    %rdx,%rdi
    6583:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6588:	e8 83 ed ff ff       	call   5310 <fwp_rc_forget_slot>
    658d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6592:	eb b7                	jmp    654b <e173+0xab>
    6594:	e8 67 d1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6599:	e8 c2 ce ff ff       	call   3460 <__stack_chk_fail@plt>
    659e:	66 90                	xchg   %ax,%ax

00000000000065a0 <fwp_closure_drop>:
    65a0:	48 8b 15 91 95 01 00 	mov    0x19591(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    65a7:	48 89 f8             	mov    %rdi,%rax
    65aa:	48 2b 05 5f 95 01 00 	sub    0x1955f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    65b1:	48 c1 e2 10          	shl    $0x10,%rdx
    65b5:	48 39 d0             	cmp    %rdx,%rax
    65b8:	73 6b                	jae    6625 <fwp_closure_drop+0x85>
    65ba:	48 89 c2             	mov    %rax,%rdx
    65bd:	48 c1 ea 10          	shr    $0x10,%rdx
    65c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65c5:	48 8b 15 8c 95 01 00 	mov    0x1958c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    65cc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    65d0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    65d4:	48 85 d2             	test   %rdx,%rdx
    65d7:	74 4c                	je     6625 <fwp_closure_drop+0x85>
    65d9:	0f b6 31             	movzbl (%rcx),%esi
    65dc:	40 80 fe 02          	cmp    $0x2,%sil
    65e0:	74 3e                	je     6620 <fwp_closure_drop+0x80>
    65e2:	40 80 fe 01          	cmp    $0x1,%sil
    65e6:	75 3d                	jne    6625 <fwp_closure_drop+0x85>
    65e8:	8b 71 18             	mov    0x18(%rcx),%esi
    65eb:	0f b7 c0             	movzwl %ax,%eax
    65ee:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65f1:	48 0f af c6          	imul   %rsi,%rax
    65f5:	48 c1 e8 20          	shr    $0x20,%rax
    65f9:	48 39 c8             	cmp    %rcx,%rax
    65fc:	73 27                	jae    6625 <fwp_closure_drop+0x85>
    65fe:	48 01 c2             	add    %rax,%rdx
    6601:	0f b6 02             	movzbl (%rdx),%eax
    6604:	84 c0                	test   %al,%al
    6606:	74 1d                	je     6625 <fwp_closure_drop+0x85>
    6608:	3c 01                	cmp    $0x1,%al
    660a:	74 24                	je     6630 <fwp_closure_drop+0x90>
    660c:	3c ff                	cmp    $0xff,%al
    660e:	74 48                	je     6658 <fwp_closure_drop+0xb8>
    6610:	83 e8 01             	sub    $0x1,%eax
    6613:	88 02                	mov    %al,(%rdx)
    6615:	c3                   	ret
    6616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    661d:	00 00 00 
    6620:	66 85 c0             	test   %ax,%ax
    6623:	74 dc                	je     6601 <fwp_closure_drop+0x61>
    6625:	c3                   	ret
    6626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    662d:	00 00 00 
    6630:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6637:	ff ff 
    6639:	48 85 c0             	test   %rax,%rax
    663c:	74 12                	je     6650 <fwp_closure_drop+0xb0>
    663e:	48 89 fe             	mov    %rdi,%rsi
    6641:	48 89 c7             	mov    %rax,%rdi
    6644:	e9 b7 db ff ff       	jmp    4200 <fwp_closure_drop_push>
    6649:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6650:	e9 5b dd ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6655:	0f 1f 00             	nopl   (%rax)
    6658:	48 89 d0             	mov    %rdx,%rax
    665b:	48 8d 35 fe 80 01 00 	lea    0x180fe(%rip),%rsi        # 1e760 <fwp_heap>
    6662:	48 83 ec 18          	sub    $0x18,%rsp
    6666:	48 c1 e8 11          	shr    $0x11,%rax
    666a:	48 31 d0             	xor    %rdx,%rax
    666d:	48 89 c1             	mov    %rax,%rcx
    6670:	48 c1 e9 09          	shr    $0x9,%rcx
    6674:	48 31 c8             	xor    %rcx,%rax
    6677:	0f b6 c8             	movzbl %al,%ecx
    667a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6681:	00 
    6682:	48 85 c0             	test   %rax,%rax
    6685:	75 22                	jne    66a9 <fwp_closure_drop+0x109>
    6687:	eb 59                	jmp    66e2 <fwp_closure_drop+0x142>
    6689:	90                   	nop
    668a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6691:	00 00 00 00 
    6695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    669c:	00 00 00 00 
    66a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    66a4:	48 85 c0             	test   %rax,%rax
    66a7:	74 39                	je     66e2 <fwp_closure_drop+0x142>
    66a9:	48 89 c1             	mov    %rax,%rcx
    66ac:	48 39 10             	cmp    %rdx,(%rax)
    66af:	75 ef                	jne    66a0 <fwp_closure_drop+0x100>
    66b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    66b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    66b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    66bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    66c4:	74 05                	je     66cb <fwp_closure_drop+0x12b>
    66c6:	48 83 c4 18          	add    $0x18,%rsp
    66ca:	c3                   	ret
    66cb:	48 89 d7             	mov    %rdx,%rdi
    66ce:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    66d3:	e8 38 ec ff ff       	call   5310 <fwp_rc_forget_slot>
    66d8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    66dd:	c6 02 fe             	movb   $0xfe,(%rdx)
    66e0:	eb e4                	jmp    66c6 <fwp_closure_drop+0x126>
    66e2:	48 8d 3d 8f 40 00 00 	lea    0x408f(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    66e9:	e8 b2 da ff ff       	call   41a0 <fwp_trap>
    66ee:	66 90                	xchg   %ax,%ax

00000000000066f0 <fwp_owned_tape_release>:
    66f0:	48 85 ff             	test   %rdi,%rdi
    66f3:	0f 84 f7 00 00 00    	je     67f0 <fwp_owned_tape_release+0x100>
    66f9:	41 54                	push   %r12
    66fb:	55                   	push   %rbp
    66fc:	53                   	push   %rbx
    66fd:	48 8b 07             	mov    (%rdi),%rax
    6700:	48 85 c0             	test   %rax,%rax
    6703:	74 08                	je     670d <fwp_owned_tape_release+0x1d>
    6705:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6709:	48 89 50 08          	mov    %rdx,0x8(%rax)
    670d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6711:	48 85 d2             	test   %rdx,%rdx
    6714:	74 03                	je     6719 <fwp_owned_tape_release+0x29>
    6716:	48 89 02             	mov    %rax,(%rdx)
    6719:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    671d:	48 89 fb             	mov    %rdi,%rbx
    6720:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6724:	48 85 c0             	test   %rax,%rax
    6727:	0f 84 89 00 00 00    	je     67b6 <fwp_owned_tape_release+0xc6>
    672d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6731:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6735:	7e 47                	jle    677e <fwp_owned_tape_release+0x8e>
    6737:	31 ed                	xor    %ebp,%ebp
    6739:	eb 0d                	jmp    6748 <fwp_owned_tape_release+0x58>
    673b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6740:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6744:	48 8b 40 68          	mov    0x68(%rax),%rax
    6748:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    674c:	49 89 ec             	mov    %rbp,%r12
    674f:	48 83 c5 01          	add    $0x1,%rbp
    6753:	49 c1 e4 04          	shl    $0x4,%r12
    6757:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    675b:	ff d0                	call   *%rax
    675d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6761:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6766:	48 8b 43 10          	mov    0x10(%rbx),%rax
    676a:	ff 50 68             	call   *0x68(%rax)
    676d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6771:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6775:	48 39 e8             	cmp    %rbp,%rax
    6778:	7f c6                	jg     6740 <fwp_owned_tape_release+0x50>
    677a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    677e:	31 ed                	xor    %ebp,%ebp
    6780:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6785:	7e 28                	jle    67af <fwp_owned_tape_release+0xbf>
    6787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    678e:	00 00 
    6790:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6794:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6798:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    679c:	74 07                	je     67a5 <fwp_owned_tape_release+0xb5>
    679e:	ff 52 68             	call   *0x68(%rdx)
    67a1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    67a5:	48 83 c5 01          	add    $0x1,%rbp
    67a9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    67ad:	7f e1                	jg     6790 <fwp_owned_tape_release+0xa0>
    67af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    67b3:	ff 52 68             	call   *0x68(%rdx)
    67b6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    67ba:	e8 e1 fd ff ff       	call   65a0 <fwp_closure_drop>
    67bf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    67c3:	e8 d8 fd ff ff       	call   65a0 <fwp_closure_drop>
    67c8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    67cc:	e8 cf fd ff ff       	call   65a0 <fwp_closure_drop>
    67d1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    67d5:	e8 76 ed ff ff       	call   5550 <fwp_mem_free>
    67da:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    67de:	e8 6d ed ff ff       	call   5550 <fwp_mem_free>
    67e3:	48 89 df             	mov    %rbx,%rdi
    67e6:	5b                   	pop    %rbx
    67e7:	5d                   	pop    %rbp
    67e8:	41 5c                	pop    %r12
    67ea:	e9 61 ed ff ff       	jmp    5550 <fwp_mem_free>
    67ef:	90                   	nop
    67f0:	c3                   	ret
    67f1:	0f 1f 40 00          	nopl   0x0(%rax)
    67f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67fc:	00 00 00 00 

0000000000006800 <fwp_tape_finish>:
    6800:	f3 0f 1e fa          	endbr64
    6804:	41 56                	push   %r14
    6806:	48 8d 3d 93 78 01 00 	lea    0x17893(%rip),%rdi        # 1e0a0 <fwp_tape_workspace>
    680d:	41 55                	push   %r13
    680f:	41 54                	push   %r12
    6811:	55                   	push   %rbp
    6812:	53                   	push   %rbx
    6813:	e8 58 d7 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6818:	48 83 3d c8 78 01 00 	cmpq   $0x0,0x178c8(%rip)        # 1e0e8 <fwp_ntapes>
    681f:	00 
    6820:	48 c7 05 5d 78 01 00 	movq   $0x0,0x1785d(%rip)        # 1e088 <fwp_tape_cached_bytes>
    6827:	00 00 00 00 
    682b:	7e 68                	jle    6895 <fwp_tape_finish+0x95>
    682d:	45 31 e4             	xor    %r12d,%r12d
    6830:	31 ed                	xor    %ebp,%ebp
    6832:	0f 1f 00             	nopl   (%rax)
    6835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    683c:	00 00 00 00 
    6840:	48 8b 1d a9 78 01 00 	mov    0x178a9(%rip),%rbx        # 1e0f0 <fwp_tapes>
    6847:	48 83 c5 01          	add    $0x1,%rbp
    684b:	4c 01 e3             	add    %r12,%rbx
    684e:	49 83 c4 68          	add    $0x68,%r12
    6852:	48 89 df             	mov    %rbx,%rdi
    6855:	e8 a6 d3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    685a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    685e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6862:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6866:	e8 55 cb ff ff       	call   33c0 <free@plt>
    686b:	4c 89 f7             	mov    %r14,%rdi
    686e:	e8 4d cb ff ff       	call   33c0 <free@plt>
    6873:	4c 89 ef             	mov    %r13,%rdi
    6876:	e8 45 cb ff ff       	call   33c0 <free@plt>
    687b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    687f:	e8 6c fe ff ff       	call   66f0 <fwp_owned_tape_release>
    6884:	48 39 2d 5d 78 01 00 	cmp    %rbp,0x1785d(%rip)        # 1e0e8 <fwp_ntapes>
    688b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6892:	00 
    6893:	7f ab                	jg     6840 <fwp_tape_finish+0x40>
    6895:	48 8b 3d 54 78 01 00 	mov    0x17854(%rip),%rdi        # 1e0f0 <fwp_tapes>
    689c:	e8 1f cb ff ff       	call   33c0 <free@plt>
    68a1:	5b                   	pop    %rbx
    68a2:	5d                   	pop    %rbp
    68a3:	48 c7 05 42 78 01 00 	movq   $0x0,0x17842(%rip)        # 1e0f0 <fwp_tapes>
    68aa:	00 00 00 00 
    68ae:	48 c7 05 27 78 01 00 	movq   $0x0,0x17827(%rip)        # 1e0e0 <fwp_tapes_cap>
    68b5:	00 00 00 00 
    68b9:	41 5c                	pop    %r12
    68bb:	48 c7 05 22 78 01 00 	movq   $0x0,0x17822(%rip)        # 1e0e8 <fwp_ntapes>
    68c2:	00 00 00 00 
    68c6:	41 5d                	pop    %r13
    68c8:	48 c7 05 05 78 01 00 	movq   $0x0,0x17805(%rip)        # 1e0d8 <fwp_tape_next_slot>
    68cf:	00 00 00 00 
    68d3:	41 5e                	pop    %r14
    68d5:	c3                   	ret
    68d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68dd:	00 00 00 

00000000000068e0 <fwp_tape_scope_release>:
    68e0:	f3 0f 1e fa          	endbr64
    68e4:	41 55                	push   %r13
    68e6:	41 54                	push   %r12
    68e8:	55                   	push   %rbp
    68e9:	53                   	push   %rbx
    68ea:	48 83 ec 58          	sub    $0x58,%rsp
    68ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    68f5:	00 00 
    68f7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    68fc:	48 63 07             	movslq (%rdi),%rax
    68ff:	85 c0                	test   %eax,%eax
    6901:	0f 88 05 01 00 00    	js     6a0c <fwp_tape_scope_release+0x12c>
    6907:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    690e:	ec c4 4e 
    6911:	48 89 fb             	mov    %rdi,%rbx
    6914:	eb 3c                	jmp    6952 <fwp_tape_scope_release+0x72>
    6916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    691d:	00 00 00 
    6920:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6925:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6929:	e8 92 ca ff ff       	call   33c0 <free@plt>
    692e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6932:	e8 89 ca ff ff       	call   33c0 <free@plt>
    6937:	4c 89 ef             	mov    %r13,%rdi
    693a:	e8 81 ca ff ff       	call   33c0 <free@plt>
    693f:	4c 89 e7             	mov    %r12,%rdi
    6942:	e8 a9 fd ff ff       	call   66f0 <fwp_owned_tape_release>
    6947:	48 63 03             	movslq (%rbx),%rax
    694a:	85 c0                	test   %eax,%eax
    694c:	0f 88 ba 00 00 00    	js     6a0c <fwp_tape_scope_release+0x12c>
    6952:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6956:	48 8b 35 93 77 01 00 	mov    0x17793(%rip),%rsi        # 1e0f0 <fwp_tapes>
    695d:	4c 01 c6             	add    %r8,%rsi
    6960:	48 89 f7             	mov    %rsi,%rdi
    6963:	e8 98 d2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6968:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    696d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6972:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6979:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    697d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6981:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6988:	00 
    6989:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    698e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6992:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6997:	66 0f ef d2          	pxor   %xmm2,%xmm2
    699b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    69a0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    69a7:	00 
    69a8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    69af:	00 
    69b0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    69b7:	00 
    69b8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    69bd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    69c2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    69c6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    69ca:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    69ce:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    69d4:	77 18                	ja     69ee <fwp_tape_scope_release+0x10e>
    69d6:	49 c1 f8 03          	sar    $0x3,%r8
    69da:	4c 0f af c5          	imul   %rbp,%r8
    69de:	4c 3b 05 f3 76 01 00 	cmp    0x176f3(%rip),%r8        # 1e0d8 <fwp_tape_next_slot>
    69e5:	7d 07                	jge    69ee <fwp_tape_scope_release+0x10e>
    69e7:	4c 89 05 ea 76 01 00 	mov    %r8,0x176ea(%rip)        # 1e0d8 <fwp_tape_next_slot>
    69ee:	4d 85 e4             	test   %r12,%r12
    69f1:	0f 85 29 ff ff ff    	jne    6920 <fwp_tape_scope_release+0x40>
    69f7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    69fc:	e8 2f e4 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6a01:	48 63 03             	movslq (%rbx),%rax
    6a04:	85 c0                	test   %eax,%eax
    6a06:	0f 89 46 ff ff ff    	jns    6952 <fwp_tape_scope_release+0x72>
    6a0c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6a11:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a18:	00 00 
    6a1a:	75 0b                	jne    6a27 <fwp_tape_scope_release+0x147>
    6a1c:	48 83 c4 58          	add    $0x58,%rsp
    6a20:	5b                   	pop    %rbx
    6a21:	5d                   	pop    %rbp
    6a22:	41 5c                	pop    %r12
    6a24:	41 5d                	pop    %r13
    6a26:	c3                   	ret
    6a27:	e8 34 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a2c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006a30 <fwp_drop4>:
    6a30:	48 8b 0d 01 91 01 00 	mov    0x19101(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    6a37:	48 89 f8             	mov    %rdi,%rax
    6a3a:	48 2b 05 cf 90 01 00 	sub    0x190cf(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6a41:	48 c1 e1 10          	shl    $0x10,%rcx
    6a45:	48 39 c8             	cmp    %rcx,%rax
    6a48:	0f 83 42 01 00 00    	jae    6b90 <fwp_drop4+0x160>
    6a4e:	48 83 ec 18          	sub    $0x18,%rsp
    6a52:	48 89 fa             	mov    %rdi,%rdx
    6a55:	4c 8d 05 04 7d 01 00 	lea    0x17d04(%rip),%r8        # 1e760 <fwp_heap>
    6a5c:	48 89 c1             	mov    %rax,%rcx
    6a5f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6a66:	48 c1 e9 10          	shr    $0x10,%rcx
    6a6a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6a6e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6a72:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6a76:	48 85 c9             	test   %rcx,%rcx
    6a79:	74 40                	je     6abb <fwp_drop4+0x8b>
    6a7b:	0f b6 3e             	movzbl (%rsi),%edi
    6a7e:	40 80 ff 02          	cmp    $0x2,%dil
    6a82:	74 3c                	je     6ac0 <fwp_drop4+0x90>
    6a84:	40 80 ff 01          	cmp    $0x1,%dil
    6a88:	75 31                	jne    6abb <fwp_drop4+0x8b>
    6a8a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6a8d:	0f b7 c0             	movzwl %ax,%eax
    6a90:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6a93:	48 0f af c7          	imul   %rdi,%rax
    6a97:	48 c1 e8 20          	shr    $0x20,%rax
    6a9b:	48 39 f0             	cmp    %rsi,%rax
    6a9e:	73 1b                	jae    6abb <fwp_drop4+0x8b>
    6aa0:	48 01 c1             	add    %rax,%rcx
    6aa3:	0f b6 01             	movzbl (%rcx),%eax
    6aa6:	84 c0                	test   %al,%al
    6aa8:	74 11                	je     6abb <fwp_drop4+0x8b>
    6aaa:	3c 01                	cmp    $0x1,%al
    6aac:	74 22                	je     6ad0 <fwp_drop4+0xa0>
    6aae:	3c ff                	cmp    $0xff,%al
    6ab0:	0f 84 0a 01 00 00    	je     6bc0 <fwp_drop4+0x190>
    6ab6:	83 e8 01             	sub    $0x1,%eax
    6ab9:	88 01                	mov    %al,(%rcx)
    6abb:	48 83 c4 18          	add    $0x18,%rsp
    6abf:	c3                   	ret
    6ac0:	66 85 c0             	test   %ax,%ax
    6ac3:	74 de                	je     6aa3 <fwp_drop4+0x73>
    6ac5:	48 83 c4 18          	add    $0x18,%rsp
    6ac9:	c3                   	ret
    6aca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6ad4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6adb:	48 89 f8             	mov    %rdi,%rax
    6ade:	48 c1 e1 10          	shl    $0x10,%rcx
    6ae2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ae9:	48 39 c8             	cmp    %rcx,%rax
    6aec:	73 62                	jae    6b50 <fwp_drop4+0x120>
    6aee:	48 89 c1             	mov    %rax,%rcx
    6af1:	48 c1 e9 10          	shr    $0x10,%rcx
    6af5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6af9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6afd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6b01:	48 85 c9             	test   %rcx,%rcx
    6b04:	74 4a                	je     6b50 <fwp_drop4+0x120>
    6b06:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6b0a:	41 80 f9 02          	cmp    $0x2,%r9b
    6b0e:	0f 84 9c 00 00 00    	je     6bb0 <fwp_drop4+0x180>
    6b14:	41 80 f9 01          	cmp    $0x1,%r9b
    6b18:	75 36                	jne    6b50 <fwp_drop4+0x120>
    6b1a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6b1e:	0f b7 c0             	movzwl %ax,%eax
    6b21:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6b24:	49 0f af c1          	imul   %r9,%rax
    6b28:	48 c1 e8 20          	shr    $0x20,%rax
    6b2c:	48 39 f0             	cmp    %rsi,%rax
    6b2f:	73 1f                	jae    6b50 <fwp_drop4+0x120>
    6b31:	48 01 c1             	add    %rax,%rcx
    6b34:	0f b6 01             	movzbl (%rcx),%eax
    6b37:	84 c0                	test   %al,%al
    6b39:	74 15                	je     6b50 <fwp_drop4+0x120>
    6b3b:	3c 01                	cmp    $0x1,%al
    6b3d:	74 59                	je     6b98 <fwp_drop4+0x168>
    6b3f:	3c ff                	cmp    $0xff,%al
    6b41:	0f 84 ff 00 00 00    	je     6c46 <fwp_drop4+0x216>
    6b47:	83 e8 01             	sub    $0x1,%eax
    6b4a:	88 01                	mov    %al,(%rcx)
    6b4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6b50:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6b54:	48 89 d7             	mov    %rdx,%rdi
    6b57:	48 89 0c 24          	mov    %rcx,(%rsp)
    6b5b:	e8 30 f7 ff ff       	call   6290 <fwp_rc_free_obj>
    6b60:	4c 8d 05 f9 7b 01 00 	lea    0x17bf9(%rip),%r8        # 1e760 <fwp_heap>
    6b67:	48 8b 04 24          	mov    (%rsp),%rax
    6b6b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b72:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b79:	48 c1 e2 10          	shl    $0x10,%rdx
    6b7d:	48 39 d0             	cmp    %rdx,%rax
    6b80:	0f 83 35 ff ff ff    	jae    6abb <fwp_drop4+0x8b>
    6b86:	48 8b 14 24          	mov    (%rsp),%rdx
    6b8a:	e9 cd fe ff ff       	jmp    6a5c <fwp_drop4+0x2c>
    6b8f:	90                   	nop
    6b90:	c3                   	ret
    6b91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b98:	48 89 14 24          	mov    %rdx,(%rsp)
    6b9c:	e8 ef f6 ff ff       	call   6290 <fwp_rc_free_obj>
    6ba1:	48 8b 14 24          	mov    (%rsp),%rdx
    6ba5:	eb a9                	jmp    6b50 <fwp_drop4+0x120>
    6ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bae:	00 00 
    6bb0:	66 85 c0             	test   %ax,%ax
    6bb3:	75 9b                	jne    6b50 <fwp_drop4+0x120>
    6bb5:	e9 7a ff ff ff       	jmp    6b34 <fwp_drop4+0x104>
    6bba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bc0:	48 89 c8             	mov    %rcx,%rax
    6bc3:	48 c1 e8 11          	shr    $0x11,%rax
    6bc7:	48 31 c8             	xor    %rcx,%rax
    6bca:	48 89 c2             	mov    %rax,%rdx
    6bcd:	48 c1 ea 09          	shr    $0x9,%rdx
    6bd1:	48 31 d0             	xor    %rdx,%rax
    6bd4:	0f b6 d0             	movzbl %al,%edx
    6bd7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6bde:	00 
    6bdf:	48 85 c0             	test   %rax,%rax
    6be2:	75 29                	jne    6c0d <fwp_drop4+0x1dd>
    6be4:	e9 e3 00 00 00       	jmp    6ccc <fwp_drop4+0x29c>
    6be9:	90                   	nop
    6bea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bf1:	00 00 00 00 
    6bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bfc:	00 00 00 00 
    6c00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6c04:	48 85 c0             	test   %rax,%rax
    6c07:	0f 84 bf 00 00 00    	je     6ccc <fwp_drop4+0x29c>
    6c0d:	48 89 c2             	mov    %rax,%rdx
    6c10:	48 39 08             	cmp    %rcx,(%rax)
    6c13:	75 eb                	jne    6c00 <fwp_drop4+0x1d0>
    6c15:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6c19:	48 83 ea 01          	sub    $0x1,%rdx
    6c1d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c21:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6c28:	0f 85 8d fe ff ff    	jne    6abb <fwp_drop4+0x8b>
    6c2e:	48 89 cf             	mov    %rcx,%rdi
    6c31:	48 89 0c 24          	mov    %rcx,(%rsp)
    6c35:	e8 d6 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6c3a:	48 8b 0c 24          	mov    (%rsp),%rcx
    6c3e:	c6 01 fe             	movb   $0xfe,(%rcx)
    6c41:	e9 75 fe ff ff       	jmp    6abb <fwp_drop4+0x8b>
    6c46:	48 89 ce             	mov    %rcx,%rsi
    6c49:	48 c1 ee 11          	shr    $0x11,%rsi
    6c4d:	48 31 ce             	xor    %rcx,%rsi
    6c50:	48 89 f0             	mov    %rsi,%rax
    6c53:	48 c1 e8 09          	shr    $0x9,%rax
    6c57:	48 31 c6             	xor    %rax,%rsi
    6c5a:	40 0f b6 f6          	movzbl %sil,%esi
    6c5e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6c65:	00 
    6c66:	48 85 c0             	test   %rax,%rax
    6c69:	75 1e                	jne    6c89 <fwp_drop4+0x259>
    6c6b:	eb 5f                	jmp    6ccc <fwp_drop4+0x29c>
    6c6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c74:	00 
    6c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c7c:	00 00 00 00 
    6c80:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	74 43                	je     6ccc <fwp_drop4+0x29c>
    6c89:	48 89 c6             	mov    %rax,%rsi
    6c8c:	48 39 08             	cmp    %rcx,(%rax)
    6c8f:	75 ef                	jne    6c80 <fwp_drop4+0x250>
    6c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c95:	48 83 ee 01          	sub    $0x1,%rsi
    6c99:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6c9d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6ca4:	0f 85 a6 fe ff ff    	jne    6b50 <fwp_drop4+0x120>
    6caa:	48 89 cf             	mov    %rcx,%rdi
    6cad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cb2:	48 89 0c 24          	mov    %rcx,(%rsp)
    6cb6:	e8 55 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6cbb:	48 8b 0c 24          	mov    (%rsp),%rcx
    6cbf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cc4:	c6 01 fe             	movb   $0xfe,(%rcx)
    6cc7:	e9 84 fe ff ff       	jmp    6b50 <fwp_drop4+0x120>
    6ccc:	48 8d 3d a5 3a 00 00 	lea    0x3aa5(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    6cd3:	e8 c8 d4 ff ff       	call   41a0 <fwp_trap>
    6cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6cdf:	00 

0000000000006ce0 <fwp_arg_drop37>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	85 f6                	test   %esi,%esi
    6ce6:	75 04                	jne    6cec <fwp_arg_drop37+0xc>
    6ce8:	85 d2                	test   %edx,%edx
    6cea:	75 04                	jne    6cf0 <fwp_arg_drop37+0x10>
    6cec:	c3                   	ret
    6ced:	0f 1f 00             	nopl   (%rax)
    6cf0:	48 8b 3f             	mov    (%rdi),%rdi
    6cf3:	e9 38 fd ff ff       	jmp    6a30 <fwp_drop4>
    6cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6cff:	00 

0000000000006d00 <fwp_task_dispose>:
    6d00:	53                   	push   %rbx
    6d01:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6d05:	0f 84 3b ca ff ff    	je     3746 <fwp_task_dispose.cold>
    6d0b:	48 89 fb             	mov    %rdi,%rbx
    6d0e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6d13:	0f 85 2d ca ff ff    	jne    3746 <fwp_task_dispose.cold>
    6d19:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6d1d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6d24:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6d2b:	00 
    6d2c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6d30:	48 85 ff             	test   %rdi,%rdi
    6d33:	74 07                	je     6d3c <fwp_task_dispose+0x3c>
    6d35:	48 85 c0             	test   %rax,%rax
    6d38:	74 02                	je     6d3c <fwp_task_dispose+0x3c>
    6d3a:	ff d0                	call   *%rax
    6d3c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6d43:	e8 08 e8 ff ff       	call   5550 <fwp_mem_free>
    6d48:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6d4f:	00 00 00 00 
    6d53:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6d57:	74 6f                	je     6dc8 <fwp_task_dispose+0xc8>
    6d59:	48 8b 15 d8 8d 01 00 	mov    0x18dd8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    6d60:	48 89 d8             	mov    %rbx,%rax
    6d63:	48 2b 05 a6 8d 01 00 	sub    0x18da6(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6d6a:	48 c1 e2 10          	shl    $0x10,%rdx
    6d6e:	48 39 d0             	cmp    %rdx,%rax
    6d71:	73 4c                	jae    6dbf <fwp_task_dispose+0xbf>
    6d73:	48 89 c2             	mov    %rax,%rdx
    6d76:	48 c1 ea 10          	shr    $0x10,%rdx
    6d7a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d7e:	48 8b 15 d3 8d 01 00 	mov    0x18dd3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    6d85:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6d89:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6d8d:	48 85 c9             	test   %rcx,%rcx
    6d90:	74 2d                	je     6dbf <fwp_task_dispose+0xbf>
    6d92:	0f b6 32             	movzbl (%rdx),%esi
    6d95:	40 80 fe 02          	cmp    $0x2,%sil
    6d99:	74 3d                	je     6dd8 <fwp_task_dispose+0xd8>
    6d9b:	40 80 fe 01          	cmp    $0x1,%sil
    6d9f:	75 1e                	jne    6dbf <fwp_task_dispose+0xbf>
    6da1:	8b 72 18             	mov    0x18(%rdx),%esi
    6da4:	0f b7 c0             	movzwl %ax,%eax
    6da7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6daa:	48 0f af c6          	imul   %rsi,%rax
    6dae:	48 c1 e8 20          	shr    $0x20,%rax
    6db2:	48 39 d0             	cmp    %rdx,%rax
    6db5:	73 08                	jae    6dbf <fwp_task_dispose+0xbf>
    6db7:	48 01 c1             	add    %rax,%rcx
    6dba:	80 39 01             	cmpb   $0x1,(%rcx)
    6dbd:	74 09                	je     6dc8 <fwp_task_dispose+0xc8>
    6dbf:	5b                   	pop    %rbx
    6dc0:	c3                   	ret
    6dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dc8:	48 89 df             	mov    %rbx,%rdi
    6dcb:	5b                   	pop    %rbx
    6dcc:	e9 7f e7 ff ff       	jmp    5550 <fwp_mem_free>
    6dd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dd8:	66 85 c0             	test   %ax,%ax
    6ddb:	74 dd                	je     6dba <fwp_task_dispose+0xba>
    6ddd:	5b                   	pop    %rbx
    6dde:	c3                   	ret
    6ddf:	90                   	nop

0000000000006de0 <fwp_free_zombie>:
    6de0:	48 8b 15 49 79 01 00 	mov    0x17949(%rip),%rdx        # 1e730 <fwp_zombie>
    6de7:	48 85 d2             	test   %rdx,%rdx
    6dea:	0f 84 98 00 00 00    	je     6e88 <fwp_free_zombie+0xa8>
    6df0:	48 3b 15 49 79 01 00 	cmp    0x17949(%rip),%rdx        # 1e740 <fwp_cur>
    6df7:	0f 84 8b 00 00 00    	je     6e88 <fwp_free_zombie+0xa8>
    6dfd:	48 83 ec 18          	sub    $0x18,%rsp
    6e01:	48 63 05 04 73 01 00 	movslq 0x17304(%rip),%rax        # 1e10c <fwp_stack_pool_n>
    6e08:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6e0c:	83 f8 3f             	cmp    $0x3f,%eax
    6e0f:	7f 7f                	jg     6e90 <fwp_free_zombie+0xb0>
    6e11:	8d 48 01             	lea    0x1(%rax),%ecx
    6e14:	89 0d f2 72 01 00    	mov    %ecx,0x172f2(%rip)        # 1e10c <fwp_stack_pool_n>
    6e1a:	48 8d 0d ff 72 01 00 	lea    0x172ff(%rip),%rcx        # 1e120 <fwp_stack_pool>
    6e21:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6e25:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6e2c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e30:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6e37:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6e3b:	48 85 c9             	test   %rcx,%rcx
    6e3e:	0f 84 fc 00 00 00    	je     6f40 <fwp_free_zombie+0x160>
    6e44:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6e4b:	48 85 c0             	test   %rax,%rax
    6e4e:	74 07                	je     6e57 <fwp_free_zombie+0x77>
    6e50:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6e57:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6e5a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e5e:	48 c7 05 c7 78 01 00 	movq   $0x0,0x178c7(%rip)        # 1e730 <fwp_zombie>
    6e65:	00 00 00 00 
    6e69:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6e70:	85 c0                	test   %eax,%eax
    6e72:	74 34                	je     6ea8 <fwp_free_zombie+0xc8>
    6e74:	83 f8 01             	cmp    $0x1,%eax
    6e77:	0f 84 b3 00 00 00    	je     6f30 <fwp_free_zombie+0x150>
    6e7d:	48 83 c4 18          	add    $0x18,%rsp
    6e81:	c3                   	ret
    6e82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e88:	c3                   	ret
    6e89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e90:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6e94:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e99:	e8 42 c7 ff ff       	call   35e0 <munmap@plt>
    6e9e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ea3:	eb 80                	jmp    6e25 <fwp_free_zombie+0x45>
    6ea5:	0f 1f 00             	nopl   (%rax)
    6ea8:	48 8b 0d 89 8c 01 00 	mov    0x18c89(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    6eaf:	48 89 d0             	mov    %rdx,%rax
    6eb2:	48 2b 05 57 8c 01 00 	sub    0x18c57(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    6eb9:	48 c1 e1 10          	shl    $0x10,%rcx
    6ebd:	48 39 c8             	cmp    %rcx,%rax
    6ec0:	73 bb                	jae    6e7d <fwp_free_zombie+0x9d>
    6ec2:	48 89 c1             	mov    %rax,%rcx
    6ec5:	48 c1 e9 10          	shr    $0x10,%rcx
    6ec9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6ecd:	48 8b 0d 84 8c 01 00 	mov    0x18c84(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    6ed4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6ed8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6edc:	48 85 c9             	test   %rcx,%rcx
    6edf:	74 9c                	je     6e7d <fwp_free_zombie+0x9d>
    6ee1:	0f b6 3e             	movzbl (%rsi),%edi
    6ee4:	40 80 ff 02          	cmp    $0x2,%dil
    6ee8:	74 66                	je     6f50 <fwp_free_zombie+0x170>
    6eea:	40 80 ff 01          	cmp    $0x1,%dil
    6eee:	75 8d                	jne    6e7d <fwp_free_zombie+0x9d>
    6ef0:	8b 7e 18             	mov    0x18(%rsi),%edi
    6ef3:	0f b7 c0             	movzwl %ax,%eax
    6ef6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ef9:	48 0f af c7          	imul   %rdi,%rax
    6efd:	48 c1 e8 20          	shr    $0x20,%rax
    6f01:	48 39 f0             	cmp    %rsi,%rax
    6f04:	0f 83 73 ff ff ff    	jae    6e7d <fwp_free_zombie+0x9d>
    6f0a:	48 01 c1             	add    %rax,%rcx
    6f0d:	0f b6 01             	movzbl (%rcx),%eax
    6f10:	84 c0                	test   %al,%al
    6f12:	0f 84 65 ff ff ff    	je     6e7d <fwp_free_zombie+0x9d>
    6f18:	3c 01                	cmp    $0x1,%al
    6f1a:	74 14                	je     6f30 <fwp_free_zombie+0x150>
    6f1c:	3c ff                	cmp    $0xff,%al
    6f1e:	74 3b                	je     6f5b <fwp_free_zombie+0x17b>
    6f20:	83 e8 01             	sub    $0x1,%eax
    6f23:	88 01                	mov    %al,(%rcx)
    6f25:	e9 53 ff ff ff       	jmp    6e7d <fwp_free_zombie+0x9d>
    6f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f30:	48 89 d7             	mov    %rdx,%rdi
    6f33:	48 83 c4 18          	add    $0x18,%rsp
    6f37:	e9 c4 fd ff ff       	jmp    6d00 <fwp_task_dispose>
    6f3c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f40:	48 89 05 c1 77 01 00 	mov    %rax,0x177c1(%rip)        # 1e708 <fwp_tasks_active>
    6f47:	e9 ff fe ff ff       	jmp    6e4b <fwp_free_zombie+0x6b>
    6f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f50:	66 85 c0             	test   %ax,%ax
    6f53:	0f 85 24 ff ff ff    	jne    6e7d <fwp_free_zombie+0x9d>
    6f59:	eb b2                	jmp    6f0d <fwp_free_zombie+0x12d>
    6f5b:	48 89 ca             	mov    %rcx,%rdx
    6f5e:	48 8d 35 fb 77 01 00 	lea    0x177fb(%rip),%rsi        # 1e760 <fwp_heap>
    6f65:	48 c1 ea 11          	shr    $0x11,%rdx
    6f69:	48 31 ca             	xor    %rcx,%rdx
    6f6c:	48 89 d0             	mov    %rdx,%rax
    6f6f:	48 c1 e8 09          	shr    $0x9,%rax
    6f73:	48 31 c2             	xor    %rax,%rdx
    6f76:	0f b6 d2             	movzbl %dl,%edx
    6f79:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    6f80:	00 
    6f81:	48 85 c0             	test   %rax,%rax
    6f84:	75 23                	jne    6fa9 <fwp_free_zombie+0x1c9>
    6f86:	eb 5c                	jmp    6fe4 <fwp_free_zombie+0x204>
    6f88:	66 90                	xchg   %ax,%ax
    6f8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f91:	00 00 00 00 
    6f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f9c:	00 00 00 00 
    6fa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6fa4:	48 85 c0             	test   %rax,%rax
    6fa7:	74 3b                	je     6fe4 <fwp_free_zombie+0x204>
    6fa9:	48 89 c2             	mov    %rax,%rdx
    6fac:	48 39 08             	cmp    %rcx,(%rax)
    6faf:	75 ef                	jne    6fa0 <fwp_free_zombie+0x1c0>
    6fb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6fb5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    6fb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6fbd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6fc4:	0f 85 b3 fe ff ff    	jne    6e7d <fwp_free_zombie+0x9d>
    6fca:	48 89 cf             	mov    %rcx,%rdi
    6fcd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6fd2:	e8 39 e3 ff ff       	call   5310 <fwp_rc_forget_slot>
    6fd7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    6fdc:	c6 01 fe             	movb   $0xfe,(%rcx)
    6fdf:	e9 99 fe ff ff       	jmp    6e7d <fwp_free_zombie+0x9d>
    6fe4:	48 8d 3d 8d 37 00 00 	lea    0x378d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    6feb:	e8 b0 d1 ff ff       	call   41a0 <fwp_trap>

0000000000006ff0 <fwp_block>:
    6ff0:	48 83 ec 08          	sub    $0x8,%rsp
    6ff4:	48 8b 05 2d 77 01 00 	mov    0x1772d(%rip),%rax        # 1e728 <fwp_ready_head>
    6ffb:	48 85 c0             	test   %rax,%rax
    6ffe:	0f 84 1c 01 00 00    	je     7120 <fwp_block+0x130>
    7004:	90                   	nop
    7005:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    700c:	00 00 00 00 
    7010:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7017:	48 89 15 0a 77 01 00 	mov    %rdx,0x1770a(%rip)        # 1e728 <fwp_ready_head>
    701e:	48 85 d2             	test   %rdx,%rdx
    7021:	0f 84 19 01 00 00    	je     7140 <fwp_block+0x150>
    7027:	48 8b 15 12 77 01 00 	mov    0x17712(%rip),%rdx        # 1e740 <fwp_cur>
    702e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7032:	48 39 c2             	cmp    %rax,%rdx
    7035:	0f 84 d5 00 00 00    	je     7110 <fwp_block+0x120>
    703b:	48 8b 0d 86 93 01 00 	mov    0x19386(%rip),%rcx        # 203c8 <fwp_state_owners>
    7042:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7046:	48 89 05 f3 76 01 00 	mov    %rax,0x176f3(%rip)        # 1e740 <fwp_cur>
    704d:	f3 0f 7e 05 9b 93 01 	movq   0x1939b(%rip),%xmm0        # 203f0 <fwp_foreign_callbacks>
    7054:	00 
    7055:	0f 16 05 84 93 01 00 	movhps 0x19384(%rip),%xmm0        # 203e0 <fwp_state>
    705c:	f3 0f 7e 0d 84 93 01 	movq   0x19384(%rip),%xmm1        # 203e8 <fwp_handlers>
    7063:	00 
    7064:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    706b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7072:	0f 16 0d 7f 93 01 00 	movhps 0x1937f(%rip),%xmm1        # 203f8 <fwp_cleanups>
    7079:	f3 0f 7e 05 57 93 01 	movq   0x19357(%rip),%xmm0        # 203d8 <fwp_state_len>
    7080:	00 
    7081:	0f 16 05 48 93 01 00 	movhps 0x19348(%rip),%xmm0        # 203d0 <fwp_state_cap>
    7088:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    708f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7096:	48 8b 70 08          	mov    0x8(%rax),%rsi
    709a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    70a1:	48 89 0d 40 93 01 00 	mov    %rcx,0x19340(%rip)        # 203e8 <fwp_handlers>
    70a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    70af:	48 89 0d 42 93 01 00 	mov    %rcx,0x19342(%rip)        # 203f8 <fwp_cleanups>
    70b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    70bd:	48 89 0d 2c 93 01 00 	mov    %rcx,0x1932c(%rip)        # 203f0 <fwp_foreign_callbacks>
    70c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    70cb:	48 89 0d 0e 93 01 00 	mov    %rcx,0x1930e(%rip)        # 203e0 <fwp_state>
    70d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    70d9:	48 89 0d f8 92 01 00 	mov    %rcx,0x192f8(%rip)        # 203d8 <fwp_state_len>
    70e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    70e7:	48 89 0d e2 92 01 00 	mov    %rcx,0x192e2(%rip)        # 203d0 <fwp_state_cap>
    70ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    70f5:	48 89 0d cc 92 01 00 	mov    %rcx,0x192cc(%rip)        # 203c8 <fwp_state_owners>
    70fc:	e8 8f c3 ff ff       	call   3490 <swapcontext@plt>
    7101:	f3 0f 1e fa          	endbr64
    7105:	e8 d6 fc ff ff       	call   6de0 <fwp_free_zombie>
    710a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7110:	8b 05 f2 6f 01 00    	mov    0x16ff2(%rip),%eax        # 1e108 <fwp_slice>
    7116:	85 c0                	test   %eax,%eax
    7118:	74 36                	je     7150 <fwp_block+0x160>
    711a:	48 83 c4 08          	add    $0x8,%rsp
    711e:	c3                   	ret
    711f:	90                   	nop
    7120:	e8 3b de ff ff       	call   4f60 <fwp_poll_events>
    7125:	48 8b 05 fc 75 01 00 	mov    0x175fc(%rip),%rax        # 1e728 <fwp_ready_head>
    712c:	48 85 c0             	test   %rax,%rax
    712f:	0f 85 db fe ff ff    	jne    7010 <fwp_block+0x20>
    7135:	eb e9                	jmp    7120 <fwp_block+0x130>
    7137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    713e:	00 00 
    7140:	48 c7 05 d5 75 01 00 	movq   $0x0,0x175d5(%rip)        # 1e720 <fwp_ready_tail>
    7147:	00 00 00 00 
    714b:	e9 d7 fe ff ff       	jmp    7027 <fwp_block+0x37>
    7150:	48 8d 3d ca 2f 00 00 	lea    0x2fca(%rip),%rdi        # a121 <_IO_stdin_used+0x121>
    7157:	e8 44 c2 ff ff       	call   33a0 <getenv@plt>
    715c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7161:	48 85 c0             	test   %rax,%rax
    7164:	74 05                	je     716b <fwp_block+0x17b>
    7166:	80 38 00             	cmpb   $0x0,(%rax)
    7169:	75 0b                	jne    7176 <fwp_block+0x186>
    716b:	89 15 97 6f 01 00    	mov    %edx,0x16f97(%rip)        # 1e108 <fwp_slice>
    7171:	48 83 c4 08          	add    $0x8,%rsp
    7175:	c3                   	ret
    7176:	ba 0a 00 00 00       	mov    $0xa,%edx
    717b:	31 f6                	xor    %esi,%esi
    717d:	48 89 c7             	mov    %rax,%rdi
    7180:	e8 cb c3 ff ff       	call   3550 <strtoll@plt>
    7185:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7189:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7190:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7195:	0f 46 d0             	cmovbe %eax,%edx
    7198:	eb d1                	jmp    716b <fwp_block+0x17b>
    719a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000071a0 <fwp_caps173>:
    71a0:	f3 0f 1e fa          	endbr64
    71a4:	85 f6                	test   %esi,%esi
    71a6:	74 08                	je     71b0 <fwp_caps173+0x10>
    71a8:	c3                   	ret
    71a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71b0:	48 8b 15 81 89 01 00 	mov    0x18981(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    71b7:	48 89 f8             	mov    %rdi,%rax
    71ba:	48 2b 05 4f 89 01 00 	sub    0x1894f(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    71c1:	48 c1 e2 10          	shl    $0x10,%rdx
    71c5:	48 39 d0             	cmp    %rdx,%rax
    71c8:	73 de                	jae    71a8 <fwp_caps173+0x8>
    71ca:	48 89 c2             	mov    %rax,%rdx
    71cd:	48 c1 ea 10          	shr    $0x10,%rdx
    71d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71d5:	48 8b 15 7c 89 01 00 	mov    0x1897c(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    71dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    71e0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    71e4:	48 85 c9             	test   %rcx,%rcx
    71e7:	74 bf                	je     71a8 <fwp_caps173+0x8>
    71e9:	0f b6 32             	movzbl (%rdx),%esi
    71ec:	40 80 fe 02          	cmp    $0x2,%sil
    71f0:	74 2e                	je     7220 <fwp_caps173+0x80>
    71f2:	40 80 fe 01          	cmp    $0x1,%sil
    71f6:	75 b0                	jne    71a8 <fwp_caps173+0x8>
    71f8:	8b 72 18             	mov    0x18(%rdx),%esi
    71fb:	0f b7 c0             	movzwl %ax,%eax
    71fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7201:	48 0f af c6          	imul   %rsi,%rax
    7205:	48 c1 e8 20          	shr    $0x20,%rax
    7209:	48 39 d0             	cmp    %rdx,%rax
    720c:	73 9a                	jae    71a8 <fwp_caps173+0x8>
    720e:	48 01 c1             	add    %rax,%rcx
    7211:	80 39 01             	cmpb   $0x1,(%rcx)
    7214:	75 92                	jne    71a8 <fwp_caps173+0x8>
    7216:	e9 35 e3 ff ff       	jmp    5550 <fwp_mem_free>
    721b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7220:	66 85 c0             	test   %ax,%ax
    7223:	74 ec                	je     7211 <fwp_caps173+0x71>
    7225:	c3                   	ret
    7226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    722d:	00 00 00 

0000000000007230 <fwp_args37>:
    7230:	f3 0f 1e fa          	endbr64
    7234:	85 d2                	test   %edx,%edx
    7236:	74 04                	je     723c <fwp_args37+0xc>
    7238:	85 f6                	test   %esi,%esi
    723a:	74 04                	je     7240 <fwp_args37+0x10>
    723c:	c3                   	ret
    723d:	0f 1f 00             	nopl   (%rax)
    7240:	48 8b 15 f1 88 01 00 	mov    0x188f1(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7247:	48 8b 07             	mov    (%rdi),%rax
    724a:	48 2b 05 bf 88 01 00 	sub    0x188bf(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7251:	48 c1 e2 10          	shl    $0x10,%rdx
    7255:	48 39 d0             	cmp    %rdx,%rax
    7258:	73 e2                	jae    723c <fwp_args37+0xc>
    725a:	48 89 c2             	mov    %rax,%rdx
    725d:	48 c1 ea 10          	shr    $0x10,%rdx
    7261:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7265:	48 8b 15 ec 88 01 00 	mov    0x188ec(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    726c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7270:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7274:	48 85 ff             	test   %rdi,%rdi
    7277:	74 c3                	je     723c <fwp_args37+0xc>
    7279:	0f b6 0a             	movzbl (%rdx),%ecx
    727c:	80 f9 02             	cmp    $0x2,%cl
    727f:	74 2f                	je     72b0 <fwp_args37+0x80>
    7281:	80 f9 01             	cmp    $0x1,%cl
    7284:	75 b6                	jne    723c <fwp_args37+0xc>
    7286:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7289:	0f b7 c0             	movzwl %ax,%eax
    728c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    728f:	48 0f af c1          	imul   %rcx,%rax
    7293:	48 c1 e8 20          	shr    $0x20,%rax
    7297:	48 39 d0             	cmp    %rdx,%rax
    729a:	73 a0                	jae    723c <fwp_args37+0xc>
    729c:	48 01 c7             	add    %rax,%rdi
    729f:	0f b6 07             	movzbl (%rdi),%eax
    72a2:	84 c0                	test   %al,%al
    72a4:	74 96                	je     723c <fwp_args37+0xc>
    72a6:	3c fd                	cmp    $0xfd,%al
    72a8:	77 0c                	ja     72b6 <fwp_args37+0x86>
    72aa:	83 c0 01             	add    $0x1,%eax
    72ad:	88 07                	mov    %al,(%rdi)
    72af:	c3                   	ret
    72b0:	66 85 c0             	test   %ax,%ax
    72b3:	74 ea                	je     729f <fwp_args37+0x6f>
    72b5:	c3                   	ret
    72b6:	e9 35 df ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    72bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000072c0 <fwp_caps37>:
    72c0:	f3 0f 1e fa          	endbr64
    72c4:	48 83 ec 18          	sub    $0x18,%rsp
    72c8:	8b 57 04             	mov    0x4(%rdi),%edx
    72cb:	48 89 f8             	mov    %rdi,%rax
    72ce:	85 d2                	test   %edx,%edx
    72d0:	0f 84 9a 00 00 00    	je     7370 <fwp_caps37+0xb0>
    72d6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    72da:	85 f6                	test   %esi,%esi
    72dc:	0f 85 9e 00 00 00    	jne    7380 <fwp_caps37+0xc0>
    72e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    72e7:	e8 44 f7 ff ff       	call   6a30 <fwp_drop4>
    72ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    72f1:	48 8b 0d 40 88 01 00 	mov    0x18840(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    72f8:	48 89 c2             	mov    %rax,%rdx
    72fb:	48 2b 15 0e 88 01 00 	sub    0x1880e(%rip),%rdx        # 1fb10 <fwp_heap+0x13b0>
    7302:	48 c1 e1 10          	shl    $0x10,%rcx
    7306:	48 39 ca             	cmp    %rcx,%rdx
    7309:	73 6d                	jae    7378 <fwp_caps37+0xb8>
    730b:	48 89 d1             	mov    %rdx,%rcx
    730e:	48 c1 e9 10          	shr    $0x10,%rcx
    7312:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7316:	48 8b 0d 3b 88 01 00 	mov    0x1883b(%rip),%rcx        # 1fb58 <fwp_heap+0x13f8>
    731d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7321:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7325:	48 85 f6             	test   %rsi,%rsi
    7328:	74 4e                	je     7378 <fwp_caps37+0xb8>
    732a:	0f b6 39             	movzbl (%rcx),%edi
    732d:	40 80 ff 02          	cmp    $0x2,%dil
    7331:	0f 84 b9 00 00 00    	je     73f0 <fwp_caps37+0x130>
    7337:	40 80 ff 01          	cmp    $0x1,%dil
    733b:	75 3b                	jne    7378 <fwp_caps37+0xb8>
    733d:	8b 79 18             	mov    0x18(%rcx),%edi
    7340:	0f b7 d2             	movzwl %dx,%edx
    7343:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7346:	48 0f af d7          	imul   %rdi,%rdx
    734a:	48 c1 ea 20          	shr    $0x20,%rdx
    734e:	48 39 ca             	cmp    %rcx,%rdx
    7351:	73 25                	jae    7378 <fwp_caps37+0xb8>
    7353:	48 01 d6             	add    %rdx,%rsi
    7356:	80 3e 01             	cmpb   $0x1,(%rsi)
    7359:	75 1d                	jne    7378 <fwp_caps37+0xb8>
    735b:	48 89 c7             	mov    %rax,%rdi
    735e:	48 83 c4 18          	add    $0x18,%rsp
    7362:	e9 e9 e1 ff ff       	jmp    5550 <fwp_mem_free>
    7367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    736e:	00 00 
    7370:	85 f6                	test   %esi,%esi
    7372:	0f 84 79 ff ff ff    	je     72f1 <fwp_caps37+0x31>
    7378:	48 83 c4 18          	add    $0x18,%rsp
    737c:	c3                   	ret
    737d:	0f 1f 00             	nopl   (%rax)
    7380:	48 8b 05 b1 87 01 00 	mov    0x187b1(%rip),%rax        # 1fb38 <fwp_heap+0x13d8>
    7387:	48 2b 3d 82 87 01 00 	sub    0x18782(%rip),%rdi        # 1fb10 <fwp_heap+0x13b0>
    738e:	48 c1 e0 10          	shl    $0x10,%rax
    7392:	48 39 c7             	cmp    %rax,%rdi
    7395:	73 e1                	jae    7378 <fwp_caps37+0xb8>
    7397:	48 89 f8             	mov    %rdi,%rax
    739a:	48 c1 e8 10          	shr    $0x10,%rax
    739e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    73a2:	48 8b 05 af 87 01 00 	mov    0x187af(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    73a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    73ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    73b1:	48 85 c0             	test   %rax,%rax
    73b4:	74 c2                	je     7378 <fwp_caps37+0xb8>
    73b6:	0f b6 0a             	movzbl (%rdx),%ecx
    73b9:	80 f9 02             	cmp    $0x2,%cl
    73bc:	74 42                	je     7400 <fwp_caps37+0x140>
    73be:	80 f9 01             	cmp    $0x1,%cl
    73c1:	75 b5                	jne    7378 <fwp_caps37+0xb8>
    73c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    73c6:	0f b7 ff             	movzwl %di,%edi
    73c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73cc:	48 0f af f9          	imul   %rcx,%rdi
    73d0:	48 c1 ef 20          	shr    $0x20,%rdi
    73d4:	48 39 d7             	cmp    %rdx,%rdi
    73d7:	73 9f                	jae    7378 <fwp_caps37+0xb8>
    73d9:	48 01 f8             	add    %rdi,%rax
    73dc:	0f b6 10             	movzbl (%rax),%edx
    73df:	84 d2                	test   %dl,%dl
    73e1:	74 95                	je     7378 <fwp_caps37+0xb8>
    73e3:	80 fa fd             	cmp    $0xfd,%dl
    73e6:	77 23                	ja     740b <fwp_caps37+0x14b>
    73e8:	83 c2 01             	add    $0x1,%edx
    73eb:	88 10                	mov    %dl,(%rax)
    73ed:	eb 89                	jmp    7378 <fwp_caps37+0xb8>
    73ef:	90                   	nop
    73f0:	66 85 d2             	test   %dx,%dx
    73f3:	0f 85 7f ff ff ff    	jne    7378 <fwp_caps37+0xb8>
    73f9:	e9 58 ff ff ff       	jmp    7356 <fwp_caps37+0x96>
    73fe:	66 90                	xchg   %ax,%ax
    7400:	66 85 ff             	test   %di,%di
    7403:	0f 85 6f ff ff ff    	jne    7378 <fwp_caps37+0xb8>
    7409:	eb d1                	jmp    73dc <fwp_caps37+0x11c>
    740b:	48 89 c7             	mov    %rax,%rdi
    740e:	48 83 c4 18          	add    $0x18,%rsp
    7412:	e9 d9 dd ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    741e:	00 00 

0000000000007420 <fwp_drop0>:
    7420:	f3 0f 1e fa          	endbr64
    7424:	48 8b 15 0d 87 01 00 	mov    0x1870d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    742b:	48 89 f8             	mov    %rdi,%rax
    742e:	48 2b 05 db 86 01 00 	sub    0x186db(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7435:	48 c1 e2 10          	shl    $0x10,%rdx
    7439:	48 39 d0             	cmp    %rdx,%rax
    743c:	0f 83 36 01 00 00    	jae    7578 <fwp_drop0+0x158>
    7442:	48 83 ec 18          	sub    $0x18,%rsp
    7446:	48 8d 35 13 73 01 00 	lea    0x17313(%rip),%rsi        # 1e760 <fwp_heap>
    744d:	48 89 c2             	mov    %rax,%rdx
    7450:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7457:	48 c1 ea 10          	shr    $0x10,%rdx
    745b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    745f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7463:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7467:	48 85 d2             	test   %rdx,%rdx
    746a:	74 42                	je     74ae <fwp_drop0+0x8e>
    746c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7470:	41 80 f8 02          	cmp    $0x2,%r8b
    7474:	74 42                	je     74b8 <fwp_drop0+0x98>
    7476:	41 80 f8 01          	cmp    $0x1,%r8b
    747a:	75 32                	jne    74ae <fwp_drop0+0x8e>
    747c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7480:	0f b7 c0             	movzwl %ax,%eax
    7483:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7486:	49 0f af c0          	imul   %r8,%rax
    748a:	48 c1 e8 20          	shr    $0x20,%rax
    748e:	48 39 c8             	cmp    %rcx,%rax
    7491:	73 1b                	jae    74ae <fwp_drop0+0x8e>
    7493:	48 01 c2             	add    %rax,%rdx
    7496:	0f b6 02             	movzbl (%rdx),%eax
    7499:	84 c0                	test   %al,%al
    749b:	74 11                	je     74ae <fwp_drop0+0x8e>
    749d:	3c 01                	cmp    $0x1,%al
    749f:	74 27                	je     74c8 <fwp_drop0+0xa8>
    74a1:	3c ff                	cmp    $0xff,%al
    74a3:	0f 84 e7 00 00 00    	je     7590 <fwp_drop0+0x170>
    74a9:	83 e8 01             	sub    $0x1,%eax
    74ac:	88 02                	mov    %al,(%rdx)
    74ae:	48 83 c4 18          	add    $0x18,%rsp
    74b2:	c3                   	ret
    74b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    74b8:	66 85 c0             	test   %ax,%ax
    74bb:	74 d9                	je     7496 <fwp_drop0+0x76>
    74bd:	48 83 c4 18          	add    $0x18,%rsp
    74c1:	c3                   	ret
    74c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    74c8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    74cf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    74d6:	48 89 f8             	mov    %rdi,%rax
    74d9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    74dd:	48 29 c8             	sub    %rcx,%rax
    74e0:	48 c1 e2 10          	shl    $0x10,%rdx
    74e4:	48 39 d0             	cmp    %rdx,%rax
    74e7:	73 71                	jae    755a <fwp_drop0+0x13a>
    74e9:	49 89 c2             	mov    %rax,%r10
    74ec:	49 c1 ea 10          	shr    $0x10,%r10
    74f0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    74f4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    74f8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    74fc:	4d 85 d2             	test   %r10,%r10
    74ff:	74 59                	je     755a <fwp_drop0+0x13a>
    7501:	45 0f b6 19          	movzbl (%r9),%r11d
    7505:	41 80 fb 02          	cmp    $0x2,%r11b
    7509:	74 75                	je     7580 <fwp_drop0+0x160>
    750b:	41 80 fb 01          	cmp    $0x1,%r11b
    750f:	75 49                	jne    755a <fwp_drop0+0x13a>
    7511:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7515:	0f b7 c0             	movzwl %ax,%eax
    7518:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    751c:	49 0f af c3          	imul   %r11,%rax
    7520:	48 c1 e8 20          	shr    $0x20,%rax
    7524:	4c 39 c8             	cmp    %r9,%rax
    7527:	73 31                	jae    755a <fwp_drop0+0x13a>
    7529:	49 01 c2             	add    %rax,%r10
    752c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7530:	75 28                	jne    755a <fwp_drop0+0x13a>
    7532:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7537:	e8 14 e0 ff ff       	call   5550 <fwp_mem_free>
    753c:	48 8d 35 1d 72 01 00 	lea    0x1721d(%rip),%rsi        # 1e760 <fwp_heap>
    7543:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7548:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    754f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7556:	48 c1 e2 10          	shl    $0x10,%rdx
    755a:	4c 89 c0             	mov    %r8,%rax
    755d:	48 29 c8             	sub    %rcx,%rax
    7560:	48 39 d0             	cmp    %rdx,%rax
    7563:	0f 83 45 ff ff ff    	jae    74ae <fwp_drop0+0x8e>
    7569:	4c 89 c7             	mov    %r8,%rdi
    756c:	e9 dc fe ff ff       	jmp    744d <fwp_drop0+0x2d>
    7571:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7578:	c3                   	ret
    7579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7580:	66 85 c0             	test   %ax,%ax
    7583:	75 d5                	jne    755a <fwp_drop0+0x13a>
    7585:	eb a5                	jmp    752c <fwp_drop0+0x10c>
    7587:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    758e:	00 00 
    7590:	48 89 d0             	mov    %rdx,%rax
    7593:	48 c1 e8 11          	shr    $0x11,%rax
    7597:	48 31 d0             	xor    %rdx,%rax
    759a:	48 89 c1             	mov    %rax,%rcx
    759d:	48 c1 e9 09          	shr    $0x9,%rcx
    75a1:	48 31 c8             	xor    %rcx,%rax
    75a4:	0f b6 c8             	movzbl %al,%ecx
    75a7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    75ae:	00 
    75af:	48 85 c0             	test   %rax,%rax
    75b2:	75 15                	jne    75c9 <fwp_drop0+0x1a9>
    75b4:	eb 4e                	jmp    7604 <fwp_drop0+0x1e4>
    75b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    75bd:	00 00 00 
    75c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    75c4:	48 85 c0             	test   %rax,%rax
    75c7:	74 3b                	je     7604 <fwp_drop0+0x1e4>
    75c9:	48 89 c1             	mov    %rax,%rcx
    75cc:	48 39 10             	cmp    %rdx,(%rax)
    75cf:	75 ef                	jne    75c0 <fwp_drop0+0x1a0>
    75d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    75d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    75dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    75e4:	0f 85 c4 fe ff ff    	jne    74ae <fwp_drop0+0x8e>
    75ea:	48 89 d7             	mov    %rdx,%rdi
    75ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75f2:	e8 19 dd ff ff       	call   5310 <fwp_rc_forget_slot>
    75f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    75ff:	e9 aa fe ff ff       	jmp    74ae <fwp_drop0+0x8e>
    7604:	48 8d 3d 6d 31 00 00 	lea    0x316d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    760b:	e8 90 cb ff ff       	call   41a0 <fwp_trap>

0000000000007610 <fwp_drop1>:
    7610:	f3 0f 1e fa          	endbr64
    7614:	48 8b 15 1d 85 01 00 	mov    0x1851d(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    761b:	48 89 f8             	mov    %rdi,%rax
    761e:	48 2b 05 eb 84 01 00 	sub    0x184eb(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7625:	48 c1 e2 10          	shl    $0x10,%rdx
    7629:	48 39 d0             	cmp    %rdx,%rax
    762c:	0f 83 36 01 00 00    	jae    7768 <fwp_drop1+0x158>
    7632:	48 83 ec 18          	sub    $0x18,%rsp
    7636:	48 8d 35 23 71 01 00 	lea    0x17123(%rip),%rsi        # 1e760 <fwp_heap>
    763d:	48 89 c2             	mov    %rax,%rdx
    7640:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7647:	48 c1 ea 10          	shr    $0x10,%rdx
    764b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    764f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7653:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7657:	48 85 d2             	test   %rdx,%rdx
    765a:	74 42                	je     769e <fwp_drop1+0x8e>
    765c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7660:	41 80 f8 02          	cmp    $0x2,%r8b
    7664:	74 42                	je     76a8 <fwp_drop1+0x98>
    7666:	41 80 f8 01          	cmp    $0x1,%r8b
    766a:	75 32                	jne    769e <fwp_drop1+0x8e>
    766c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7670:	0f b7 c0             	movzwl %ax,%eax
    7673:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7676:	49 0f af c0          	imul   %r8,%rax
    767a:	48 c1 e8 20          	shr    $0x20,%rax
    767e:	48 39 c8             	cmp    %rcx,%rax
    7681:	73 1b                	jae    769e <fwp_drop1+0x8e>
    7683:	48 01 c2             	add    %rax,%rdx
    7686:	0f b6 02             	movzbl (%rdx),%eax
    7689:	84 c0                	test   %al,%al
    768b:	74 11                	je     769e <fwp_drop1+0x8e>
    768d:	3c 01                	cmp    $0x1,%al
    768f:	74 27                	je     76b8 <fwp_drop1+0xa8>
    7691:	3c ff                	cmp    $0xff,%al
    7693:	0f 84 e7 00 00 00    	je     7780 <fwp_drop1+0x170>
    7699:	83 e8 01             	sub    $0x1,%eax
    769c:	88 02                	mov    %al,(%rdx)
    769e:	48 83 c4 18          	add    $0x18,%rsp
    76a2:	c3                   	ret
    76a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76a8:	66 85 c0             	test   %ax,%ax
    76ab:	74 d9                	je     7686 <fwp_drop1+0x76>
    76ad:	48 83 c4 18          	add    $0x18,%rsp
    76b1:	c3                   	ret
    76b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76b8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    76bf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    76c6:	48 89 f8             	mov    %rdi,%rax
    76c9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    76cd:	48 29 c8             	sub    %rcx,%rax
    76d0:	48 c1 e2 10          	shl    $0x10,%rdx
    76d4:	48 39 d0             	cmp    %rdx,%rax
    76d7:	73 71                	jae    774a <fwp_drop1+0x13a>
    76d9:	49 89 c2             	mov    %rax,%r10
    76dc:	49 c1 ea 10          	shr    $0x10,%r10
    76e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    76e4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    76e8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    76ec:	4d 85 d2             	test   %r10,%r10
    76ef:	74 59                	je     774a <fwp_drop1+0x13a>
    76f1:	45 0f b6 19          	movzbl (%r9),%r11d
    76f5:	41 80 fb 02          	cmp    $0x2,%r11b
    76f9:	74 75                	je     7770 <fwp_drop1+0x160>
    76fb:	41 80 fb 01          	cmp    $0x1,%r11b
    76ff:	75 49                	jne    774a <fwp_drop1+0x13a>
    7701:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7705:	0f b7 c0             	movzwl %ax,%eax
    7708:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    770c:	49 0f af c3          	imul   %r11,%rax
    7710:	48 c1 e8 20          	shr    $0x20,%rax
    7714:	4c 39 c8             	cmp    %r9,%rax
    7717:	73 31                	jae    774a <fwp_drop1+0x13a>
    7719:	49 01 c2             	add    %rax,%r10
    771c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7720:	75 28                	jne    774a <fwp_drop1+0x13a>
    7722:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7727:	e8 24 de ff ff       	call   5550 <fwp_mem_free>
    772c:	48 8d 35 2d 70 01 00 	lea    0x1702d(%rip),%rsi        # 1e760 <fwp_heap>
    7733:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7738:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    773f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7746:	48 c1 e2 10          	shl    $0x10,%rdx
    774a:	4c 89 c0             	mov    %r8,%rax
    774d:	48 29 c8             	sub    %rcx,%rax
    7750:	48 39 d0             	cmp    %rdx,%rax
    7753:	0f 83 45 ff ff ff    	jae    769e <fwp_drop1+0x8e>
    7759:	4c 89 c7             	mov    %r8,%rdi
    775c:	e9 dc fe ff ff       	jmp    763d <fwp_drop1+0x2d>
    7761:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7768:	c3                   	ret
    7769:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7770:	66 85 c0             	test   %ax,%ax
    7773:	75 d5                	jne    774a <fwp_drop1+0x13a>
    7775:	eb a5                	jmp    771c <fwp_drop1+0x10c>
    7777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    777e:	00 00 
    7780:	48 89 d0             	mov    %rdx,%rax
    7783:	48 c1 e8 11          	shr    $0x11,%rax
    7787:	48 31 d0             	xor    %rdx,%rax
    778a:	48 89 c1             	mov    %rax,%rcx
    778d:	48 c1 e9 09          	shr    $0x9,%rcx
    7791:	48 31 c8             	xor    %rcx,%rax
    7794:	0f b6 c8             	movzbl %al,%ecx
    7797:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    779e:	00 
    779f:	48 85 c0             	test   %rax,%rax
    77a2:	75 25                	jne    77c9 <fwp_drop1+0x1b9>
    77a4:	eb 5e                	jmp    7804 <fwp_drop1+0x1f4>
    77a6:	0f 1f 40 00          	nopl   0x0(%rax)
    77aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77b1:	00 00 00 00 
    77b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77bc:	00 00 00 00 
    77c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    77c4:	48 85 c0             	test   %rax,%rax
    77c7:	74 3b                	je     7804 <fwp_drop1+0x1f4>
    77c9:	48 89 c1             	mov    %rax,%rcx
    77cc:	48 39 10             	cmp    %rdx,(%rax)
    77cf:	75 ef                	jne    77c0 <fwp_drop1+0x1b0>
    77d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    77d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    77dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    77e4:	0f 85 b4 fe ff ff    	jne    769e <fwp_drop1+0x8e>
    77ea:	48 89 d7             	mov    %rdx,%rdi
    77ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77f2:	e8 19 db ff ff       	call   5310 <fwp_rc_forget_slot>
    77f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    77ff:	e9 9a fe ff ff       	jmp    769e <fwp_drop1+0x8e>
    7804:	48 8d 3d 6d 2f 00 00 	lea    0x2f6d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    780b:	e8 90 c9 ff ff       	call   41a0 <fwp_trap>

0000000000007810 <fwp_drop10>:
    7810:	48 8b 0d 21 83 01 00 	mov    0x18321(%rip),%rcx        # 1fb38 <fwp_heap+0x13d8>
    7817:	48 89 f8             	mov    %rdi,%rax
    781a:	48 2b 05 ef 82 01 00 	sub    0x182ef(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7821:	48 c1 e1 10          	shl    $0x10,%rcx
    7825:	48 39 c8             	cmp    %rcx,%rax
    7828:	0f 83 c2 01 00 00    	jae    79f0 <fwp_drop10+0x1e0>
    782e:	48 83 ec 18          	sub    $0x18,%rsp
    7832:	48 89 fa             	mov    %rdi,%rdx
    7835:	48 8d 35 24 6f 01 00 	lea    0x16f24(%rip),%rsi        # 1e760 <fwp_heap>
    783c:	48 89 c1             	mov    %rax,%rcx
    783f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7846:	48 c1 e9 10          	shr    $0x10,%rcx
    784a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    784e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7852:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7856:	48 85 c9             	test   %rcx,%rcx
    7859:	74 46                	je     78a1 <fwp_drop10+0x91>
    785b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    785f:	41 80 f9 02          	cmp    $0x2,%r9b
    7863:	0f 84 d7 00 00 00    	je     7940 <fwp_drop10+0x130>
    7869:	41 80 f9 01          	cmp    $0x1,%r9b
    786d:	75 32                	jne    78a1 <fwp_drop10+0x91>
    786f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7873:	0f b7 c0             	movzwl %ax,%eax
    7876:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7879:	49 0f af c1          	imul   %r9,%rax
    787d:	48 c1 e8 20          	shr    $0x20,%rax
    7881:	48 39 f8             	cmp    %rdi,%rax
    7884:	73 1b                	jae    78a1 <fwp_drop10+0x91>
    7886:	48 01 c1             	add    %rax,%rcx
    7889:	0f b6 01             	movzbl (%rcx),%eax
    788c:	84 c0                	test   %al,%al
    788e:	74 11                	je     78a1 <fwp_drop10+0x91>
    7890:	3c 01                	cmp    $0x1,%al
    7892:	74 1c                	je     78b0 <fwp_drop10+0xa0>
    7894:	3c ff                	cmp    $0xff,%al
    7896:	0f 84 5c 01 00 00    	je     79f8 <fwp_drop10+0x1e8>
    789c:	83 e8 01             	sub    $0x1,%eax
    789f:	88 01                	mov    %al,(%rcx)
    78a1:	48 83 c4 18          	add    $0x18,%rsp
    78a5:	c3                   	ret
    78a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78ad:	00 00 00 
    78b0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    78b7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    78be:	48 89 d0             	mov    %rdx,%rax
    78c1:	49 89 d1             	mov    %rdx,%r9
    78c4:	48 c1 e1 10          	shl    $0x10,%rcx
    78c8:	48 29 f8             	sub    %rdi,%rax
    78cb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    78cf:	78 7f                	js     7950 <fwp_drop10+0x140>
    78d1:	48 39 c8             	cmp    %rcx,%rax
    78d4:	73 cb                	jae    78a1 <fwp_drop10+0x91>
    78d6:	48 89 c1             	mov    %rax,%rcx
    78d9:	48 c1 e9 10          	shr    $0x10,%rcx
    78dd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    78e1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    78e5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    78e9:	48 85 f6             	test   %rsi,%rsi
    78ec:	74 b3                	je     78a1 <fwp_drop10+0x91>
    78ee:	0f b6 39             	movzbl (%rcx),%edi
    78f1:	40 80 ff 02          	cmp    $0x2,%dil
    78f5:	74 39                	je     7930 <fwp_drop10+0x120>
    78f7:	40 80 ff 01          	cmp    $0x1,%dil
    78fb:	75 a4                	jne    78a1 <fwp_drop10+0x91>
    78fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7900:	0f b7 c0             	movzwl %ax,%eax
    7903:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7906:	48 0f af c7          	imul   %rdi,%rax
    790a:	48 c1 e8 20          	shr    $0x20,%rax
    790e:	48 39 c8             	cmp    %rcx,%rax
    7911:	73 8e                	jae    78a1 <fwp_drop10+0x91>
    7913:	48 01 c6             	add    %rax,%rsi
    7916:	80 3e 01             	cmpb   $0x1,(%rsi)
    7919:	75 86                	jne    78a1 <fwp_drop10+0x91>
    791b:	48 89 d7             	mov    %rdx,%rdi
    791e:	48 83 c4 18          	add    $0x18,%rsp
    7922:	e9 29 dc ff ff       	jmp    5550 <fwp_mem_free>
    7927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    792e:	00 00 
    7930:	66 85 c0             	test   %ax,%ax
    7933:	74 e1                	je     7916 <fwp_drop10+0x106>
    7935:	48 83 c4 18          	add    $0x18,%rsp
    7939:	c3                   	ret
    793a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7940:	66 85 c0             	test   %ax,%ax
    7943:	0f 84 40 ff ff ff    	je     7889 <fwp_drop10+0x79>
    7949:	48 83 c4 18          	add    $0x18,%rsp
    794d:	c3                   	ret
    794e:	66 90                	xchg   %ax,%ax
    7950:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7954:	48 39 c8             	cmp    %rcx,%rax
    7957:	73 74                	jae    79cd <fwp_drop10+0x1bd>
    7959:	49 89 c2             	mov    %rax,%r10
    795c:	49 c1 ea 10          	shr    $0x10,%r10
    7960:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7964:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7968:	4d 8b 50 20          	mov    0x20(%r8),%r10
    796c:	4d 85 d2             	test   %r10,%r10
    796f:	74 5c                	je     79cd <fwp_drop10+0x1bd>
    7971:	45 0f b6 18          	movzbl (%r8),%r11d
    7975:	41 80 fb 02          	cmp    $0x2,%r11b
    7979:	74 6d                	je     79e8 <fwp_drop10+0x1d8>
    797b:	41 80 fb 01          	cmp    $0x1,%r11b
    797f:	75 4c                	jne    79cd <fwp_drop10+0x1bd>
    7981:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7985:	0f b7 c0             	movzwl %ax,%eax
    7988:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    798c:	49 0f af c3          	imul   %r11,%rax
    7990:	48 c1 e8 20          	shr    $0x20,%rax
    7994:	4c 39 c0             	cmp    %r8,%rax
    7997:	73 34                	jae    79cd <fwp_drop10+0x1bd>
    7999:	49 01 c2             	add    %rax,%r10
    799c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79a0:	75 2b                	jne    79cd <fwp_drop10+0x1bd>
    79a2:	4c 89 cf             	mov    %r9,%rdi
    79a5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79aa:	e8 a1 db ff ff       	call   5550 <fwp_mem_free>
    79af:	48 8d 35 aa 6d 01 00 	lea    0x16daa(%rip),%rsi        # 1e760 <fwp_heap>
    79b6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79bb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    79c2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    79c9:	48 c1 e1 10          	shl    $0x10,%rcx
    79cd:	48 89 d0             	mov    %rdx,%rax
    79d0:	48 29 f8             	sub    %rdi,%rax
    79d3:	48 39 c8             	cmp    %rcx,%rax
    79d6:	0f 82 60 fe ff ff    	jb     783c <fwp_drop10+0x2c>
    79dc:	e9 c0 fe ff ff       	jmp    78a1 <fwp_drop10+0x91>
    79e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79e8:	66 85 c0             	test   %ax,%ax
    79eb:	75 e0                	jne    79cd <fwp_drop10+0x1bd>
    79ed:	eb ad                	jmp    799c <fwp_drop10+0x18c>
    79ef:	90                   	nop
    79f0:	c3                   	ret
    79f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79f8:	48 89 c8             	mov    %rcx,%rax
    79fb:	48 c1 e8 11          	shr    $0x11,%rax
    79ff:	48 31 c8             	xor    %rcx,%rax
    7a02:	48 89 c2             	mov    %rax,%rdx
    7a05:	48 c1 ea 09          	shr    $0x9,%rdx
    7a09:	48 31 d0             	xor    %rdx,%rax
    7a0c:	0f b6 d0             	movzbl %al,%edx
    7a0f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7a16:	00 
    7a17:	48 85 c0             	test   %rax,%rax
    7a1a:	75 0d                	jne    7a29 <fwp_drop10+0x219>
    7a1c:	eb 46                	jmp    7a64 <fwp_drop10+0x254>
    7a1e:	66 90                	xchg   %ax,%ax
    7a20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7a24:	48 85 c0             	test   %rax,%rax
    7a27:	74 3b                	je     7a64 <fwp_drop10+0x254>
    7a29:	48 89 c2             	mov    %rax,%rdx
    7a2c:	48 39 08             	cmp    %rcx,(%rax)
    7a2f:	75 ef                	jne    7a20 <fwp_drop10+0x210>
    7a31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a35:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7a39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7a3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7a44:	0f 85 57 fe ff ff    	jne    78a1 <fwp_drop10+0x91>
    7a4a:	48 89 cf             	mov    %rcx,%rdi
    7a4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7a52:	e8 b9 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7a57:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7a5c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7a5f:	e9 3d fe ff ff       	jmp    78a1 <fwp_drop10+0x91>
    7a64:	48 8d 3d 0d 2d 00 00 	lea    0x2d0d(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    7a6b:	e8 30 c7 ff ff       	call   41a0 <fwp_trap>

0000000000007a70 <f37>:
    7a70:	41 57                	push   %r15
    7a72:	41 56                	push   %r14
    7a74:	41 55                	push   %r13
    7a76:	41 54                	push   %r12
    7a78:	55                   	push   %rbp
    7a79:	53                   	push   %rbx
    7a7a:	48 83 ec 38          	sub    $0x38,%rsp
    7a7e:	48 8b 15 b3 80 01 00 	mov    0x180b3(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7a85:	48 8b 0d 84 80 01 00 	mov    0x18084(%rip),%rcx        # 1fb10 <fwp_heap+0x13b0>
    7a8c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7a93:	00 00 
    7a95:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7a9a:	49 89 fc             	mov    %rdi,%r12
    7a9d:	48 c1 e2 10          	shl    $0x10,%rdx
    7aa1:	48 85 ff             	test   %rdi,%rdi
    7aa4:	0f 84 bc 02 00 00    	je     7d66 <f37+0x2f6>
    7aaa:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7aaf:	48 89 d8             	mov    %rbx,%rax
    7ab2:	48 29 c8             	sub    %rcx,%rax
    7ab5:	48 39 d0             	cmp    %rdx,%rax
    7ab8:	0f 83 72 03 00 00    	jae    7e30 <f37+0x3c0>
    7abe:	48 89 c2             	mov    %rax,%rdx
    7ac1:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ac9:	48 8b 15 88 80 01 00 	mov    0x18088(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7ad0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ad4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ad8:	48 85 ff             	test   %rdi,%rdi
    7adb:	0f 84 4f 03 00 00    	je     7e30 <f37+0x3c0>
    7ae1:	0f b6 0a             	movzbl (%rdx),%ecx
    7ae4:	80 f9 02             	cmp    $0x2,%cl
    7ae7:	0f 84 53 02 00 00    	je     7d40 <f37+0x2d0>
    7aed:	80 f9 01             	cmp    $0x1,%cl
    7af0:	75 24                	jne    7b16 <f37+0xa6>
    7af2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7af5:	0f b7 c0             	movzwl %ax,%eax
    7af8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7afb:	48 0f af c1          	imul   %rcx,%rax
    7aff:	48 c1 e8 20          	shr    $0x20,%rax
    7b03:	48 39 d0             	cmp    %rdx,%rax
    7b06:	73 0e                	jae    7b16 <f37+0xa6>
    7b08:	48 01 c7             	add    %rax,%rdi
    7b0b:	0f b6 07             	movzbl (%rdi),%eax
    7b0e:	84 c0                	test   %al,%al
    7b10:	0f 85 ca 02 00 00    	jne    7de0 <f37+0x370>
    7b16:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7b1b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7b20:	ba 01 00 00 00       	mov    $0x1,%edx
    7b25:	48 85 db             	test   %rbx,%rbx
    7b28:	74 13                	je     7b3d <f37+0xcd>
    7b2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b30:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7b34:	48 83 c2 01          	add    $0x1,%rdx
    7b38:	48 85 db             	test   %rbx,%rbx
    7b3b:	75 f3                	jne    7b30 <f37+0xc0>
    7b3d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b42:	48 85 c0             	test   %rax,%rax
    7b45:	0f 84 15 03 00 00    	je     7e60 <f37+0x3f0>
    7b4b:	31 db                	xor    %ebx,%ebx
    7b4d:	0f 1f 00             	nopl   (%rax)
    7b50:	48 8b 40 10          	mov    0x10(%rax),%rax
    7b54:	48 83 c3 01          	add    $0x1,%rbx
    7b58:	48 85 c0             	test   %rax,%rax
    7b5b:	75 f3                	jne    7b50 <f37+0xe0>
    7b5d:	48 39 d3             	cmp    %rdx,%rbx
    7b60:	48 0f 47 da          	cmova  %rdx,%rbx
    7b64:	48 89 d8             	mov    %rbx,%rax
    7b67:	48 c1 e8 3c          	shr    $0x3c,%rax
    7b6b:	0f 85 8f 03 00 00    	jne    7f00 <f37+0x490>
    7b71:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7b75:	be 02 00 00 00       	mov    $0x2,%esi
    7b7a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7b81:	00 
    7b82:	e8 c9 de ff ff       	call   5a50 <fwp_heap_alloc>
    7b87:	48 89 28             	mov    %rbp,(%rax)
    7b8a:	48 8b 15 a7 7f 01 00 	mov    0x17fa7(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7b91:	49 89 c6             	mov    %rax,%r14
    7b94:	48 2b 05 75 7f 01 00 	sub    0x17f75(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7b9b:	48 c1 e2 10          	shl    $0x10,%rdx
    7b9f:	48 39 d0             	cmp    %rdx,%rax
    7ba2:	73 57                	jae    7bfb <f37+0x18b>
    7ba4:	48 89 c2             	mov    %rax,%rdx
    7ba7:	48 c1 ea 10          	shr    $0x10,%rdx
    7bab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7baf:	48 8b 15 a2 7f 01 00 	mov    0x17fa2(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7bb6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bba:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7bbe:	48 85 ed             	test   %rbp,%rbp
    7bc1:	74 38                	je     7bfb <f37+0x18b>
    7bc3:	0f b6 0a             	movzbl (%rdx),%ecx
    7bc6:	80 f9 02             	cmp    $0x2,%cl
    7bc9:	0f 84 51 02 00 00    	je     7e20 <f37+0x3b0>
    7bcf:	80 f9 01             	cmp    $0x1,%cl
    7bd2:	75 27                	jne    7bfb <f37+0x18b>
    7bd4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7bd7:	0f b7 c0             	movzwl %ax,%eax
    7bda:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bdd:	48 0f af c1          	imul   %rcx,%rax
    7be1:	48 c1 e8 20          	shr    $0x20,%rax
    7be5:	48 39 d0             	cmp    %rdx,%rax
    7be8:	73 11                	jae    7bfb <f37+0x18b>
    7bea:	48 01 c5             	add    %rax,%rbp
    7bed:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7bf1:	0f 84 d5 02 00 00    	je     7ecc <f37+0x45c>
    7bf7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7bfb:	48 85 db             	test   %rbx,%rbx
    7bfe:	74 5d                	je     7c5d <f37+0x1ed>
    7c00:	48 c1 e3 04          	shl    $0x4,%rbx
    7c04:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7c09:	4c 89 f5             	mov    %r14,%rbp
    7c0c:	4d 89 e5             	mov    %r12,%r13
    7c0f:	4c 01 f3             	add    %r14,%rbx
    7c12:	0f 1f 00             	nopl   (%rax)
    7c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c1c:	00 00 00 00 
    7c20:	49 8b 45 08          	mov    0x8(%r13),%rax
    7c24:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7c28:	48 83 c5 10          	add    $0x10,%rbp
    7c2c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7c31:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7c35:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7c39:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7c3e:	e8 dd e3 ff ff       	call   6020 <w120>
    7c43:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7c48:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7c4c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7c50:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7c54:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7c58:	48 39 dd             	cmp    %rbx,%rbp
    7c5b:	75 c3                	jne    7c20 <f37+0x1b0>
    7c5d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7c62:	e8 c9 ed ff ff       	call   6a30 <fwp_drop4>
    7c67:	4c 89 e7             	mov    %r12,%rdi
    7c6a:	e8 c1 ed ff ff       	call   6a30 <fwp_drop4>
    7c6f:	4c 89 f7             	mov    %r14,%rdi
    7c72:	e8 19 e5 ff ff       	call   6190 <w176.constprop.0>
    7c77:	4c 89 f7             	mov    %r14,%rdi
    7c7a:	48 89 c3             	mov    %rax,%rbx
    7c7d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7c83:	e8 88 fb ff ff       	call   7810 <fwp_drop10>
    7c88:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7c8e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7c93:	31 ff                	xor    %edi,%edi
    7c95:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7c9a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7c9e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7ca3:	e8 c8 de ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    7ca8:	48 8b 15 89 7e 01 00 	mov    0x17e89(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7caf:	48 89 c5             	mov    %rax,%rbp
    7cb2:	48 2b 05 57 7e 01 00 	sub    0x17e57(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7cb9:	48 c1 e2 10          	shl    $0x10,%rdx
    7cbd:	48 39 d0             	cmp    %rdx,%rax
    7cc0:	73 55                	jae    7d17 <f37+0x2a7>
    7cc2:	48 89 c2             	mov    %rax,%rdx
    7cc5:	48 c1 ea 10          	shr    $0x10,%rdx
    7cc9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ccd:	48 8b 15 84 7e 01 00 	mov    0x17e84(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7cd4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7cd8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7cdc:	48 85 db             	test   %rbx,%rbx
    7cdf:	74 36                	je     7d17 <f37+0x2a7>
    7ce1:	0f b6 0a             	movzbl (%rdx),%ecx
    7ce4:	80 f9 02             	cmp    $0x2,%cl
    7ce7:	0f 84 1b 01 00 00    	je     7e08 <f37+0x398>
    7ced:	80 f9 01             	cmp    $0x1,%cl
    7cf0:	75 25                	jne    7d17 <f37+0x2a7>
    7cf2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7cf5:	0f b7 c0             	movzwl %ax,%eax
    7cf8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cfb:	48 0f af c1          	imul   %rcx,%rax
    7cff:	48 c1 e8 20          	shr    $0x20,%rax
    7d03:	48 39 d0             	cmp    %rdx,%rax
    7d06:	73 0f                	jae    7d17 <f37+0x2a7>
    7d08:	48 01 c3             	add    %rax,%rbx
    7d0b:	80 3b ff             	cmpb   $0xff,(%rbx)
    7d0e:	0f 84 ab 01 00 00    	je     7ebf <f37+0x44f>
    7d14:	c6 03 01             	movb   $0x1,(%rbx)
    7d17:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7d1c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7d23:	00 00 
    7d25:	0f 85 d0 01 00 00    	jne    7efb <f37+0x48b>
    7d2b:	48 83 c4 38          	add    $0x38,%rsp
    7d2f:	48 89 e8             	mov    %rbp,%rax
    7d32:	5b                   	pop    %rbx
    7d33:	5d                   	pop    %rbp
    7d34:	41 5c                	pop    %r12
    7d36:	41 5d                	pop    %r13
    7d38:	41 5e                	pop    %r14
    7d3a:	41 5f                	pop    %r15
    7d3c:	c3                   	ret
    7d3d:	0f 1f 00             	nopl   (%rax)
    7d40:	66 85 c0             	test   %ax,%ax
    7d43:	0f 85 cd fd ff ff    	jne    7b16 <f37+0xa6>
    7d49:	0f b6 07             	movzbl (%rdi),%eax
    7d4c:	84 c0                	test   %al,%al
    7d4e:	0f 84 c2 fd ff ff    	je     7b16 <f37+0xa6>
    7d54:	3c fd                	cmp    $0xfd,%al
    7d56:	0f 87 95 01 00 00    	ja     7ef1 <f37+0x481>
    7d5c:	83 c0 01             	add    $0x1,%eax
    7d5f:	88 07                	mov    %al,(%rdi)
    7d61:	e9 b0 fd ff ff       	jmp    7b16 <f37+0xa6>
    7d66:	48 f7 d9             	neg    %rcx
    7d69:	48 39 d1             	cmp    %rdx,%rcx
    7d6c:	0f 83 ee 00 00 00    	jae    7e60 <f37+0x3f0>
    7d72:	48 89 c8             	mov    %rcx,%rax
    7d75:	48 c1 e8 10          	shr    $0x10,%rax
    7d79:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7d7d:	48 8b 05 d4 7d 01 00 	mov    0x17dd4(%rip),%rax        # 1fb58 <fwp_heap+0x13f8>
    7d84:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7d88:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d8c:	48 85 ff             	test   %rdi,%rdi
    7d8f:	0f 84 cb 00 00 00    	je     7e60 <f37+0x3f0>
    7d95:	0f b6 02             	movzbl (%rdx),%eax
    7d98:	3c 02                	cmp    $0x2,%al
    7d9a:	0f 84 9a 00 00 00    	je     7e3a <f37+0x3ca>
    7da0:	3c 01                	cmp    $0x1,%al
    7da2:	0f 85 b8 00 00 00    	jne    7e60 <f37+0x3f0>
    7da8:	0f b7 c1             	movzwl %cx,%eax
    7dab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7dae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7db1:	48 0f af c1          	imul   %rcx,%rax
    7db5:	48 c1 e8 20          	shr    $0x20,%rax
    7db9:	48 39 d0             	cmp    %rdx,%rax
    7dbc:	0f 83 9e 00 00 00    	jae    7e60 <f37+0x3f0>
    7dc2:	48 01 c7             	add    %rax,%rdi
    7dc5:	0f b6 07             	movzbl (%rdi),%eax
    7dc8:	84 c0                	test   %al,%al
    7dca:	0f 84 90 00 00 00    	je     7e60 <f37+0x3f0>
    7dd0:	31 db                	xor    %ebx,%ebx
    7dd2:	0f 1f 00             	nopl   (%rax)
    7dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ddc:	00 00 00 00 
    7de0:	3c fd                	cmp    $0xfd,%al
    7de2:	0f 87 f1 00 00 00    	ja     7ed9 <f37+0x469>
    7de8:	83 c0 01             	add    $0x1,%eax
    7deb:	88 07                	mov    %al,(%rdi)
    7ded:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7df2:	31 d2                	xor    %edx,%edx
    7df4:	4d 85 e4             	test   %r12,%r12
    7df7:	0f 85 1e fd ff ff    	jne    7b1b <f37+0xab>
    7dfd:	e9 3b fd ff ff       	jmp    7b3d <f37+0xcd>
    7e02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e08:	66 85 c0             	test   %ax,%ax
    7e0b:	0f 85 06 ff ff ff    	jne    7d17 <f37+0x2a7>
    7e11:	e9 f5 fe ff ff       	jmp    7d0b <f37+0x29b>
    7e16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e1d:	00 00 00 
    7e20:	66 85 c0             	test   %ax,%ax
    7e23:	0f 85 d2 fd ff ff    	jne    7bfb <f37+0x18b>
    7e29:	e9 bf fd ff ff       	jmp    7bed <f37+0x17d>
    7e2e:	66 90                	xchg   %ax,%ax
    7e30:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e35:	e9 e6 fc ff ff       	jmp    7b20 <f37+0xb0>
    7e3a:	66 85 c9             	test   %cx,%cx
    7e3d:	75 21                	jne    7e60 <f37+0x3f0>
    7e3f:	0f b6 07             	movzbl (%rdi),%eax
    7e42:	84 c0                	test   %al,%al
    7e44:	74 1a                	je     7e60 <f37+0x3f0>
    7e46:	3c fd                	cmp    $0xfd,%al
    7e48:	0f 87 be 00 00 00    	ja     7f0c <f37+0x49c>
    7e4e:	83 c0 01             	add    $0x1,%eax
    7e51:	88 07                	mov    %al,(%rdi)
    7e53:	66 90                	xchg   %ax,%ax
    7e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e5c:	00 00 00 00 
    7e60:	be 02 00 00 00       	mov    $0x2,%esi
    7e65:	bf 08 00 00 00       	mov    $0x8,%edi
    7e6a:	e8 e1 db ff ff       	call   5a50 <fwp_heap_alloc>
    7e6f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7e76:	48 8b 15 bb 7c 01 00 	mov    0x17cbb(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    7e7d:	49 89 c6             	mov    %rax,%r14
    7e80:	48 2b 05 89 7c 01 00 	sub    0x17c89(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    7e87:	48 c1 e2 10          	shl    $0x10,%rdx
    7e8b:	48 39 d0             	cmp    %rdx,%rax
    7e8e:	73 53                	jae    7ee3 <f37+0x473>
    7e90:	48 89 c2             	mov    %rax,%rdx
    7e93:	48 c1 ea 10          	shr    $0x10,%rdx
    7e97:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e9b:	48 8b 15 b6 7c 01 00 	mov    0x17cb6(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    7ea2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ea6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7eaa:	48 85 ed             	test   %rbp,%rbp
    7ead:	74 34                	je     7ee3 <f37+0x473>
    7eaf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7eb6:	00 00 
    7eb8:	31 db                	xor    %ebx,%ebx
    7eba:	e9 04 fd ff ff       	jmp    7bc3 <f37+0x153>
    7ebf:	48 89 df             	mov    %rbx,%rdi
    7ec2:	e8 49 d4 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ec7:	e9 48 fe ff ff       	jmp    7d14 <f37+0x2a4>
    7ecc:	48 89 ef             	mov    %rbp,%rdi
    7ecf:	e8 3c d4 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ed4:	e9 1e fd ff ff       	jmp    7bf7 <f37+0x187>
    7ed9:	e8 12 d3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7ede:	e9 0a ff ff ff       	jmp    7ded <f37+0x37d>
    7ee3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    7eea:	00 00 
    7eec:	e9 6c fd ff ff       	jmp    7c5d <f37+0x1ed>
    7ef1:	e8 fa d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7ef6:	e9 1b fc ff ff       	jmp    7b16 <f37+0xa6>
    7efb:	e8 60 b5 ff ff       	call   3460 <__stack_chk_fail@plt>
    7f00:	48 8d 3d 26 22 00 00 	lea    0x2226(%rip),%rdi        # a12d <_IO_stdin_used+0x12d>
    7f07:	e8 94 c2 ff ff       	call   41a0 <fwp_trap>
    7f0c:	e8 df d2 ff ff       	call   51f0 <fwp_rc_wide_dup>
    7f11:	e9 4a ff ff ff       	jmp    7e60 <f37+0x3f0>
    7f16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f1d:	00 00 00 

0000000000007f20 <fwp_owned_entry37>:
    7f20:	f3 0f 1e fa          	endbr64
    7f24:	48 8b 3f             	mov    (%rdi),%rdi
    7f27:	e9 44 fb ff ff       	jmp    7a70 <f37>
    7f2c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007f30 <e37>:
    7f30:	f3 0f 1e fa          	endbr64
    7f34:	53                   	push   %rbx
    7f35:	48 8b 1f             	mov    (%rdi),%rbx
    7f38:	48 89 df             	mov    %rbx,%rdi
    7f3b:	e8 d0 e2 ff ff       	call   6210 <fwp_rc_share>
    7f40:	48 89 df             	mov    %rbx,%rdi
    7f43:	e8 28 fb ff ff       	call   7a70 <f37>
    7f48:	48 89 c3             	mov    %rax,%rbx
    7f4b:	48 89 c7             	mov    %rax,%rdi
    7f4e:	e8 bd e2 ff ff       	call   6210 <fwp_rc_share>
    7f53:	48 89 d8             	mov    %rbx,%rax
    7f56:	5b                   	pop    %rbx
    7f57:	c3                   	ret
    7f58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7f5f:	00 

0000000000007f60 <fwp_write>:
    7f60:	41 57                	push   %r15
    7f62:	41 56                	push   %r14
    7f64:	41 55                	push   %r13
    7f66:	41 54                	push   %r12
    7f68:	55                   	push   %rbp
    7f69:	53                   	push   %rbx
    7f6a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    7f71:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7f78:	00 00 
    7f7a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    7f81:	00 
    7f82:	49 89 d4             	mov    %rdx,%r12
    7f85:	8b 12                	mov    (%rdx),%edx
    7f87:	83 fa 19             	cmp    $0x19,%edx
    7f8a:	77 6a                	ja     7ff6 <fwp_write+0x96>
    7f8c:	48 89 f5             	mov    %rsi,%rbp
    7f8f:	89 d0                	mov    %edx,%eax
    7f91:	89 ce                	mov    %ecx,%esi
    7f93:	48 89 fb             	mov    %rdi,%rbx
    7f96:	48 8d 0d c3 29 00 00 	lea    0x29c3(%rip),%rcx        # a960 <_IO_stdin_used+0x960>
    7f9d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    7fa1:	48 01 c8             	add    %rcx,%rax
    7fa4:	3e ff e0             	notrack jmp *%rax
    7fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fae:	00 00 
    7fb0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    7fb4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    7fb8:	48 89 ca             	mov    %rcx,%rdx
    7fbb:	48 85 c9             	test   %rcx,%rcx
    7fbe:	0f 88 9c 0c 00 00    	js     8c60 <fwp_write+0xd00>
    7fc4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    7fcb:	00 
    7fcc:	48 89 c6             	mov    %rax,%rsi
    7fcf:	4c 89 e7             	mov    %r12,%rdi
    7fd2:	e8 69 ba ff ff       	call   3a40 <fwp_fmt_u128>
    7fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fde:	00 00 
    7fe0:	4c 89 e7             	mov    %r12,%rdi
    7fe3:	e8 68 b4 ff ff       	call   3450 <strlen@plt>
    7fe8:	4c 89 e6             	mov    %r12,%rsi
    7feb:	48 89 df             	mov    %rbx,%rdi
    7fee:	48 89 c2             	mov    %rax,%rdx
    7ff1:	e8 7a c0 ff ff       	call   4070 <buf_put>
    7ff6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    7ffd:	00 
    7ffe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8005:	00 00 
    8007:	0f 85 28 04 00 00    	jne    8435 <fwp_write+0x4d5>
    800d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8014:	5b                   	pop    %rbx
    8015:	5d                   	pop    %rbp
    8016:	41 5c                	pop    %r12
    8018:	41 5d                	pop    %r13
    801a:	41 5e                	pop    %r14
    801c:	41 5f                	pop    %r15
    801e:	c3                   	ret
    801f:	90                   	nop
    8020:	49 89 e9             	mov    %rbp,%r9
    8023:	4c 8d 05 2d 21 00 00 	lea    0x212d(%rip),%r8        # a157 <_IO_stdin_used+0x157>
    802a:	b9 00 02 00 00       	mov    $0x200,%ecx
    802f:	ba 02 00 00 00       	mov    $0x2,%edx
    8034:	be 00 02 00 00       	mov    $0x200,%esi
    8039:	31 c0                	xor    %eax,%eax
    803b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8042:	00 
    8043:	e8 68 b3 ff ff       	call   33b0 <__snprintf_chk@plt>
    8048:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    804f:	00 
    8050:	e8 fb b3 ff ff       	call   3450 <strlen@plt>
    8055:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    805c:	00 
    805d:	48 89 df             	mov    %rbx,%rdi
    8060:	48 89 c2             	mov    %rax,%rdx
    8063:	e8 08 c0 ff ff       	call   4070 <buf_put>
    8068:	eb 8c                	jmp    7ff6 <fwp_write+0x96>
    806a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8070:	49 89 e9             	mov    %rbp,%r9
    8073:	4c 8d 05 d8 20 00 00 	lea    0x20d8(%rip),%r8        # a152 <_IO_stdin_used+0x152>
    807a:	eb ae                	jmp    802a <fwp_write+0xca>
    807c:	0f 1f 40 00          	nopl   0x0(%rax)
    8080:	83 fa 13             	cmp    $0x13,%edx
    8083:	48 8d 05 be 20 00 00 	lea    0x20be(%rip),%rax        # a148 <_IO_stdin_used+0x148>
    808a:	48 8d 35 bc 20 00 00 	lea    0x20bc(%rip),%rsi        # a14d <_IO_stdin_used+0x14d>
    8091:	ba 04 00 00 00       	mov    $0x4,%edx
    8096:	48 0f 44 f0          	cmove  %rax,%rsi
    809a:	45 31 ed             	xor    %r13d,%r13d
    809d:	e8 ce bf ff ff       	call   4070 <buf_put>
    80a2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    80a7:	0f 84 a3 08 00 00    	je     8950 <fwp_write+0x9f0>
    80ad:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    80b2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    80b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    80bc:	48 89 df             	mov    %rbx,%rdi
    80bf:	49 0f 44 c5          	cmove  %r13,%rax
    80c3:	31 c9                	xor    %ecx,%ecx
    80c5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    80ca:	e8 91 fe ff ff       	call   7f60 <fwp_write>
    80cf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    80d4:	0f 84 6e 09 00 00    	je     8a48 <fwp_write+0xae8>
    80da:	49 83 c5 01          	add    $0x1,%r13
    80de:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    80e2:	0f 83 68 08 00 00    	jae    8950 <fwp_write+0x9f0>
    80e8:	ba 02 00 00 00       	mov    $0x2,%edx
    80ed:	48 8d 35 a3 20 00 00 	lea    0x20a3(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    80f4:	48 89 df             	mov    %rbx,%rdi
    80f7:	e8 74 bf ff ff       	call   4070 <buf_put>
    80fc:	eb af                	jmp    80ad <fwp_write+0x14d>
    80fe:	66 90                	xchg   %ax,%ax
    8100:	ba 06 00 00 00       	mov    $0x6,%edx
    8105:	48 8d 35 64 20 00 00 	lea    0x2064(%rip),%rsi        # a170 <_IO_stdin_used+0x170>
    810c:	48 83 c5 10          	add    $0x10,%rbp
    8110:	e8 5b bf ff ff       	call   4070 <buf_put>
    8115:	48 89 ef             	mov    %rbp,%rdi
    8118:	e8 33 b3 ff ff       	call   3450 <strlen@plt>
    811d:	48 89 ee             	mov    %rbp,%rsi
    8120:	48 89 df             	mov    %rbx,%rdi
    8123:	48 89 c2             	mov    %rax,%rdx
    8126:	e8 45 bf ff ff       	call   4070 <buf_put>
    812b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8130:	ba 01 00 00 00       	mov    $0x1,%edx
    8135:	48 89 df             	mov    %rbx,%rdi
    8138:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    813d:	e8 2e bf ff ff       	call   4070 <buf_put>
    8142:	e9 af fe ff ff       	jmp    7ff6 <fwp_write+0x96>
    8147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    814e:	00 00 
    8150:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8157:	00 
    8158:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    815f:	00 00 
    8161:	0f 85 ce 02 00 00    	jne    8435 <fwp_write+0x4d5>
    8167:	ba 0a 00 00 00       	mov    $0xa,%edx
    816c:	48 8d 35 e9 1f 00 00 	lea    0x1fe9(%rip),%rsi        # a15c <_IO_stdin_used+0x15c>
    8173:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    817a:	48 89 df             	mov    %rbx,%rdi
    817d:	5b                   	pop    %rbx
    817e:	5d                   	pop    %rbp
    817f:	41 5c                	pop    %r12
    8181:	41 5d                	pop    %r13
    8183:	41 5e                	pop    %r14
    8185:	41 5f                	pop    %r15
    8187:	e9 e4 be ff ff       	jmp    4070 <buf_put>
    818c:	0f 1f 40 00          	nopl   0x0(%rax)
    8190:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8195:	4d 85 ed             	test   %r13,%r13
    8198:	0f 84 02 0c 00 00    	je     8da0 <fwp_write+0xe40>
    819e:	48 8d 35 ff 1f 00 00 	lea    0x1fff(%rip),%rsi        # a1a4 <_IO_stdin_used+0x1a4>
    81a5:	4c 89 ef             	mov    %r13,%rdi
    81a8:	e8 83 b3 ff ff       	call   3530 <strcmp@plt>
    81ad:	41 89 c1             	mov    %eax,%r9d
    81b0:	85 c0                	test   %eax,%eax
    81b2:	0f 84 6c 0c 00 00    	je     8e24 <fwp_write+0xec4>
    81b8:	4c 89 ef             	mov    %r13,%rdi
    81bb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    81c0:	e8 8b b2 ff ff       	call   3450 <strlen@plt>
    81c5:	4c 89 ee             	mov    %r13,%rsi
    81c8:	48 89 df             	mov    %rbx,%rdi
    81cb:	48 89 c2             	mov    %rax,%rdx
    81ce:	e8 9d be ff ff       	call   4070 <buf_put>
    81d3:	ba 01 00 00 00       	mov    $0x1,%edx
    81d8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    81dd:	48 89 df             	mov    %rbx,%rdi
    81e0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    81e5:	e8 86 be ff ff       	call   4070 <buf_put>
    81ea:	ba 01 00 00 00       	mov    $0x1,%edx
    81ef:	4c 89 fe             	mov    %r15,%rsi
    81f2:	48 89 df             	mov    %rbx,%rdi
    81f5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    81fa:	e8 71 be ff ff       	call   4070 <buf_put>
    81ff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8204:	45 31 f6             	xor    %r14d,%r14d
    8207:	85 d2                	test   %edx,%edx
    8209:	0f 8e 81 0a 00 00    	jle    8c90 <fwp_write+0xd30>
    820f:	45 31 ed             	xor    %r13d,%r13d
    8212:	4d 85 ed             	test   %r13,%r13
    8215:	0f 85 75 07 00 00    	jne    8990 <fwp_write+0xa30>
    821b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8222:	00 
    8223:	45 85 f6             	test   %r14d,%r14d
    8226:	0f 84 84 07 00 00    	je     89b0 <fwp_write+0xa50>
    822c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8231:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8236:	48 89 df             	mov    %rbx,%rdi
    8239:	49 83 c5 01          	add    $0x1,%r13
    823d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8241:	31 c9                	xor    %ecx,%ecx
    8243:	e8 18 fd ff ff       	call   7f60 <fwp_write>
    8248:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    824d:	7f c3                	jg     8212 <fwp_write+0x2b2>
    824f:	45 85 f6             	test   %r14d,%r14d
    8252:	0f 84 38 0a 00 00    	je     8c90 <fwp_write+0xd30>
    8258:	b8 29 00 00 00       	mov    $0x29,%eax
    825d:	ba 01 00 00 00       	mov    $0x1,%edx
    8262:	4c 89 fe             	mov    %r15,%rsi
    8265:	48 89 df             	mov    %rbx,%rdi
    8268:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    826c:	e8 ff bd ff ff       	call   4070 <buf_put>
    8271:	e9 80 fd ff ff       	jmp    7ff6 <fwp_write+0x96>
    8276:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    827d:	00 00 00 
    8280:	ba 01 00 00 00       	mov    $0x1,%edx
    8285:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    828a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    828f:	e8 dc bd ff ff       	call   4070 <buf_put>
    8294:	48 85 ed             	test   %rbp,%rbp
    8297:	0f 84 93 06 00 00    	je     8930 <fwp_write+0x9d0>
    829d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    82a1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    82a6:	31 c9                	xor    %ecx,%ecx
    82a8:	48 89 df             	mov    %rbx,%rdi
    82ab:	e8 b0 fc ff ff       	call   7f60 <fwp_write>
    82b0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    82b4:	48 85 ed             	test   %rbp,%rbp
    82b7:	0f 84 73 06 00 00    	je     8930 <fwp_write+0x9d0>
    82bd:	ba 02 00 00 00       	mov    $0x2,%edx
    82c2:	48 8d 35 ce 1e 00 00 	lea    0x1ece(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    82c9:	48 89 df             	mov    %rbx,%rdi
    82cc:	e8 9f bd ff ff       	call   4070 <buf_put>
    82d1:	eb ca                	jmp    829d <fwp_write+0x33d>
    82d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82d8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    82dc:	85 f6                	test   %esi,%esi
    82de:	0f 84 fc 07 00 00    	je     8ae0 <fwp_write+0xb80>
    82e4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    82eb:	00 
    82ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    82f3:	00 00 
    82f5:	0f 85 3a 01 00 00    	jne    8435 <fwp_write+0x4d5>
    82fb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    82ff:	4c 89 ea             	mov    %r13,%rdx
    8302:	e9 6c fe ff ff       	jmp    8173 <fwp_write+0x213>
    8307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    830e:	00 00 
    8310:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8315:	ba 01 00 00 00       	mov    $0x1,%edx
    831a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    831f:	48 89 ee             	mov    %rbp,%rsi
    8322:	e8 49 bd ff ff       	call   4070 <buf_put>
    8327:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    832c:	4c 89 e7             	mov    %r12,%rdi
    832f:	e8 1c b1 ff ff       	call   3450 <strlen@plt>
    8334:	4c 89 e6             	mov    %r12,%rsi
    8337:	48 89 df             	mov    %rbx,%rdi
    833a:	48 89 c2             	mov    %rax,%rdx
    833d:	e8 2e bd ff ff       	call   4070 <buf_put>
    8342:	ba 01 00 00 00       	mov    $0x1,%edx
    8347:	48 89 ee             	mov    %rbp,%rsi
    834a:	48 89 df             	mov    %rbx,%rdi
    834d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8352:	e8 19 bd ff ff       	call   4070 <buf_put>
    8357:	e9 9a fc ff ff       	jmp    7ff6 <fwp_write+0x96>
    835c:	0f 1f 40 00          	nopl   0x0(%rax)
    8360:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8365:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8369:	0f 8a 8e 0b 00 00    	jp     8efd <fwp_write+0xf9d>
    836f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8373:	66 0f 54 05 e5 26 00 	andpd  0x26e5(%rip),%xmm0        # aa60 <msg.4+0x90>
    837a:	00 
    837b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8380:	66 0f 2e 05 08 27 00 	ucomisd 0x2708(%rip),%xmm0        # aa90 <msg.4+0xc0>
    8387:	00 
    8388:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    838f:	00 
    8390:	0f 87 b2 09 00 00    	ja     8d48 <fwp_write+0xde8>
    8396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    839d:	00 00 00 
    83a0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    83a4:	89 ee                	mov    %ebp,%esi
    83a6:	4c 89 e7             	mov    %r12,%rdi
    83a9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    83ae:	e8 0d c1 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    83b3:	31 f6                	xor    %esi,%esi
    83b5:	4c 89 e7             	mov    %r12,%rdi
    83b8:	e8 53 b0 ff ff       	call   3410 <strtod@plt>
    83bd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    83c2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    83c6:	7a 06                	jp     83ce <fwp_write+0x46e>
    83c8:	0f 84 e9 01 00 00    	je     85b7 <fwp_write+0x657>
    83ce:	83 c5 01             	add    $0x1,%ebp
    83d1:	83 fd 12             	cmp    $0x12,%ebp
    83d4:	75 ca                	jne    83a0 <fwp_write+0x440>
    83d6:	be 11 00 00 00       	mov    $0x11,%esi
    83db:	66 0f 28 c1          	movapd %xmm1,%xmm0
    83df:	4c 89 e7             	mov    %r12,%rdi
    83e2:	e8 d9 c0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    83e7:	e9 cb 01 00 00       	jmp    85b7 <fwp_write+0x657>
    83ec:	0f 1f 40 00          	nopl   0x0(%rax)
    83f0:	48 83 fd 01          	cmp    $0x1,%rbp
    83f4:	0f 84 e6 08 00 00    	je     8ce0 <fwp_write+0xd80>
    83fa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    83fe:	b8 02 00 00 00       	mov    $0x2,%eax
    8403:	ba 01 00 00 00       	mov    $0x1,%edx
    8408:	48 0f 44 d0          	cmove  %rax,%rdx
    840c:	48 8d 35 2d 1d 00 00 	lea    0x1d2d(%rip),%rsi        # a140 <_IO_stdin_used+0x140>
    8413:	48 8d 05 2b 1d 00 00 	lea    0x1d2b(%rip),%rax        # a145 <_IO_stdin_used+0x145>
    841a:	48 0f 44 f0          	cmove  %rax,%rsi
    841e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8425:	00 
    8426:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    842d:	00 00 
    842f:	0f 84 3e fd ff ff    	je     8173 <fwp_write+0x213>
    8435:	e8 26 b0 ff ff       	call   3460 <__stack_chk_fail@plt>
    843a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8440:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8445:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    844a:	e8 61 bb ff ff       	call   3fb0 <buf_grow>
    844f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8453:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8459:	4c 03 0b             	add    (%rbx),%r9
    845c:	66 45 89 11          	mov    %r10w,(%r9)
    8460:	45 85 e4             	test   %r12d,%r12d
    8463:	0f 8e 07 05 00 00    	jle    8970 <fwp_write+0xa10>
    8469:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8470:	55 55 55 
    8473:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8478:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    847f:	aa aa aa 
    8482:	49 83 c1 01          	add    $0x1,%r9
    8486:	eb 45                	jmp    84cd <fwp_write+0x56d>
    8488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    848f:	00 
    8490:	be 01 00 00 00       	mov    $0x1,%esi
    8495:	b8 2d 00 00 00       	mov    $0x2d,%eax
    849a:	88 07                	mov    %al,(%rdi)
    849c:	48 89 e8             	mov    %rbp,%rax
    849f:	49 f7 e8             	imul   %r8
    84a2:	48 89 e8             	mov    %rbp,%rax
    84a5:	48 c1 f8 3f          	sar    $0x3f,%rax
    84a9:	48 29 c2             	sub    %rax,%rdx
    84ac:	48 85 c9             	test   %rcx,%rcx
    84af:	0f 95 c0             	setne  %al
    84b2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    84b6:	48 83 ef 01          	sub    $0x1,%rdi
    84ba:	48 21 c5             	and    %rax,%rbp
    84bd:	48 29 ea             	sub    %rbp,%rdx
    84c0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    84c4:	49 39 f9             	cmp    %rdi,%r9
    84c7:	0f 84 a3 04 00 00    	je     8970 <fwp_write+0xa10>
    84cd:	48 89 e8             	mov    %rbp,%rax
    84d0:	49 f7 e8             	imul   %r8
    84d3:	48 89 e8             	mov    %rbp,%rax
    84d6:	48 c1 f8 3f          	sar    $0x3f,%rax
    84da:	48 89 d1             	mov    %rdx,%rcx
    84dd:	48 29 c1             	sub    %rax,%rcx
    84e0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    84e4:	48 89 e9             	mov    %rbp,%rcx
    84e7:	48 29 c1             	sub    %rax,%rcx
    84ea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    84ee:	49 f7 e2             	mul    %r10
    84f1:	b8 30 00 00 00       	mov    $0x30,%eax
    84f6:	48 89 d6             	mov    %rdx,%rsi
    84f9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    84fd:	48 d1 ee             	shr    $1,%rsi
    8500:	48 01 f2             	add    %rsi,%rdx
    8503:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8507:	48 29 d6             	sub    %rdx,%rsi
    850a:	74 8e                	je     849a <fwp_write+0x53a>
    850c:	48 83 fe 01          	cmp    $0x1,%rsi
    8510:	0f 85 7a ff ff ff    	jne    8490 <fwp_write+0x530>
    8516:	31 f6                	xor    %esi,%esi
    8518:	b8 2b 00 00 00       	mov    $0x2b,%eax
    851d:	e9 78 ff ff ff       	jmp    849a <fwp_write+0x53a>
    8522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8528:	66 0f 6e cd          	movd   %ebp,%xmm1
    852c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    852f:	0f 8a c8 09 00 00    	jp     8efd <fwp_write+0xf9d>
    8535:	0f 28 c1             	movaps %xmm1,%xmm0
    8538:	0f 54 05 11 25 00 00 	andps  0x2511(%rip),%xmm0        # aa50 <msg.4+0x80>
    853f:	0f 2e 05 be 1a 00 00 	ucomiss 0x1abe(%rip),%xmm0        # a004 <_IO_stdin_used+0x4>
    8546:	0f 87 24 08 00 00    	ja     8d70 <fwp_write+0xe10>
    854c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8550:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8556:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    855d:	00 
    855e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8562:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    856e:	00 00 
    8570:	44 89 ee             	mov    %r13d,%esi
    8573:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8578:	4c 89 e7             	mov    %r12,%rdi
    857b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8580:	e8 3b bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8585:	31 f6                	xor    %esi,%esi
    8587:	4c 89 e7             	mov    %r12,%rdi
    858a:	e8 21 af ff ff       	call   34b0 <strtof@plt>
    858f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8594:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8597:	7a 02                	jp     859b <fwp_write+0x63b>
    8599:	74 1c                	je     85b7 <fwp_write+0x657>
    859b:	41 83 c5 01          	add    $0x1,%r13d
    859f:	41 83 fd 0a          	cmp    $0xa,%r13d
    85a3:	75 cb                	jne    8570 <fwp_write+0x610>
    85a5:	be 09 00 00 00       	mov    $0x9,%esi
    85aa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    85af:	4c 89 e7             	mov    %r12,%rdi
    85b2:	e8 09 bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    85b7:	4c 89 e7             	mov    %r12,%rdi
    85ba:	e8 71 bb ff ff       	call   4130 <fwp_finish_float>
    85bf:	e9 1c fa ff ff       	jmp    7fe0 <fwp_write+0x80>
    85c4:	0f 1f 40 00          	nopl   0x0(%rax)
    85c8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    85cc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    85d0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    85d7:	00 
    85d8:	48 89 ef             	mov    %rbp,%rdi
    85db:	e8 60 b4 ff ff       	call   3a40 <fwp_fmt_u128>
    85e0:	48 89 ef             	mov    %rbp,%rdi
    85e3:	e8 68 ae ff ff       	call   3450 <strlen@plt>
    85e8:	48 89 ee             	mov    %rbp,%rsi
    85eb:	48 89 df             	mov    %rbx,%rdi
    85ee:	48 89 c2             	mov    %rax,%rdx
    85f1:	e8 7a ba ff ff       	call   4070 <buf_put>
    85f6:	e9 fb f9 ff ff       	jmp    7ff6 <fwp_write+0x96>
    85fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8600:	ba 06 00 00 00       	mov    $0x6,%edx
    8605:	48 8d 35 8e 1b 00 00 	lea    0x1b8e(%rip),%rsi        # a19a <_IO_stdin_used+0x19a>
    860c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8612:	e8 59 ba ff ff       	call   4070 <buf_put>
    8617:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    861e:	ff ff 7f 
    8621:	48 23 55 00          	and    0x0(%rbp),%rdx
    8625:	0f 84 86 02 00 00    	je     88b1 <fwp_write+0x951>
    862b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8630:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8634:	48 85 d2             	test   %rdx,%rdx
    8637:	0f 84 ae 00 00 00    	je     86eb <fwp_write+0x78b>
    863d:	8b 0a                	mov    (%rdx),%ecx
    863f:	83 f9 1c             	cmp    $0x1c,%ecx
    8642:	0f 84 58 06 00 00    	je     8ca0 <fwp_write+0xd40>
    8648:	83 f9 1b             	cmp    $0x1b,%ecx
    864b:	0f 87 9a 00 00 00    	ja     86eb <fwp_write+0x78b>
    8651:	be 01 00 00 00       	mov    $0x1,%esi
    8656:	48 d3 e6             	shl    %cl,%rsi
    8659:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    865f:	0f 85 4b 04 00 00    	jne    8ab0 <fwp_write+0xb50>
    8665:	f7 c6 84 04 00 00    	test   $0x484,%esi
    866b:	0f 85 0f 04 00 00    	jne    8a80 <fwp_write+0xb20>
    8671:	83 e6 21             	and    $0x21,%esi
    8674:	74 75                	je     86eb <fwp_write+0x78b>
    8676:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    867b:	48 85 ff             	test   %rdi,%rdi
    867e:	79 07                	jns    8687 <fwp_write+0x727>
    8680:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8684:	4c 01 ee             	add    %r13,%rsi
    8687:	48 0f be 3e          	movsbq (%rsi),%rdi
    868b:	85 c9                	test   %ecx,%ecx
    868d:	40 0f b6 f7          	movzbl %dil,%esi
    8691:	48 0f 44 f7          	cmove  %rdi,%rsi
    8695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    869c:	00 00 00 00 
    86a0:	31 c9                	xor    %ecx,%ecx
    86a2:	48 89 df             	mov    %rbx,%rdi
    86a5:	49 83 c5 01          	add    $0x1,%r13
    86a9:	e8 b2 f8 ff ff       	call   7f60 <fwp_write>
    86ae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    86b5:	ff ff 7f 
    86b8:	48 23 55 00          	and    0x0(%rbp),%rdx
    86bc:	49 39 d5             	cmp    %rdx,%r13
    86bf:	0f 83 ec 01 00 00    	jae    88b1 <fwp_write+0x951>
    86c5:	ba 02 00 00 00       	mov    $0x2,%edx
    86ca:	48 89 df             	mov    %rbx,%rdi
    86cd:	48 8d 35 c3 1a 00 00 	lea    0x1ac3(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    86d4:	e8 97 b9 ff ff       	call   4070 <buf_put>
    86d9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86de:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    86e2:	48 85 d2             	test   %rdx,%rdx
    86e5:	0f 85 52 ff ff ff    	jne    863d <fwp_write+0x6dd>
    86eb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    86f0:	48 85 ff             	test   %rdi,%rdi
    86f3:	0f 88 cf 05 00 00    	js     8cc8 <fwp_write+0xd68>
    86f9:	48 8b 31             	mov    (%rcx),%rsi
    86fc:	eb a2                	jmp    86a0 <fwp_write+0x740>
    86fe:	66 90                	xchg   %ax,%ax
    8700:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8707:	00 
    8708:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    870f:	00 00 
    8711:	0f 85 1e fd ff ff    	jne    8435 <fwp_write+0x4d5>
    8717:	ba 08 00 00 00       	mov    $0x8,%edx
    871c:	48 8d 35 44 1a 00 00 	lea    0x1a44(%rip),%rsi        # a167 <_IO_stdin_used+0x167>
    8723:	e9 4b fa ff ff       	jmp    8173 <fwp_write+0x213>
    8728:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    872f:	00 
    8730:	89 e8                	mov    %ebp,%eax
    8732:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8739:	76 03                	jbe    873e <fwp_write+0x7de>
    873b:	8b 45 00             	mov    0x0(%rbp),%eax
    873e:	41 89 c6             	mov    %eax,%r14d
    8741:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8746:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    874b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    874f:	4c 89 ef             	mov    %r13,%rdi
    8752:	e8 f9 ac ff ff       	call   3450 <strlen@plt>
    8757:	4c 89 ee             	mov    %r13,%rsi
    875a:	48 89 df             	mov    %rbx,%rdi
    875d:	48 89 c2             	mov    %rax,%rdx
    8760:	e8 0b b9 ff ff       	call   4070 <buf_put>
    8765:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    876a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    876e:	85 f6                	test   %esi,%esi
    8770:	0f 8e 80 f8 ff ff    	jle    7ff6 <fwp_write+0x96>
    8776:	45 31 ed             	xor    %r13d,%r13d
    8779:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    877e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8783:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8788:	ba 01 00 00 00       	mov    $0x1,%edx
    878d:	4c 89 fe             	mov    %r15,%rsi
    8790:	48 89 04 24          	mov    %rax,(%rsp)
    8794:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8799:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    879d:	48 89 df             	mov    %rbx,%rdi
    87a0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    87a4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    87a9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    87ae:	e8 bd b8 ff ff       	call   4070 <buf_put>
    87b3:	41 8b 06             	mov    (%r14),%eax
    87b6:	83 f8 0e             	cmp    $0xe,%eax
    87b9:	0f 84 71 02 00 00    	je     8a30 <fwp_write+0xad0>
    87bf:	83 f8 10             	cmp    $0x10,%eax
    87c2:	0f 84 38 02 00 00    	je     8a00 <fwp_write+0xaa0>
    87c8:	83 f8 0a             	cmp    $0xa,%eax
    87cb:	0f 84 7f 04 00 00    	je     8c50 <fwp_write+0xcf0>
    87d1:	0f 8f f9 00 00 00    	jg     88d0 <fwp_write+0x970>
    87d7:	83 f8 03             	cmp    $0x3,%eax
    87da:	0f 8f 50 04 00 00    	jg     8c30 <fwp_write+0xcd0>
    87e0:	85 c0                	test   %eax,%eax
    87e2:	78 10                	js     87f4 <fwp_write+0x894>
    87e4:	48 8b 04 24          	mov    (%rsp),%rax
    87e8:	48 c1 e8 3f          	shr    $0x3f,%rax
    87ec:	85 c0                	test   %eax,%eax
    87ee:	0f 85 f9 00 00 00    	jne    88ed <fwp_write+0x98d>
    87f4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    87f9:	48 8b 34 24          	mov    (%rsp),%rsi
    87fd:	31 c9                	xor    %ecx,%ecx
    87ff:	48 89 df             	mov    %rbx,%rdi
    8802:	e8 59 f7 ff ff       	call   7f60 <fwp_write>
    8807:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    880c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8811:	49 83 c5 01          	add    $0x1,%r13
    8815:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8819:	0f 8f 5f ff ff ff    	jg     877e <fwp_write+0x81e>
    881f:	e9 d2 f7 ff ff       	jmp    7ff6 <fwp_write+0x96>
    8824:	0f 1f 40 00          	nopl   0x0(%rax)
    8828:	ba 06 00 00 00       	mov    $0x6,%edx
    882d:	48 8d 35 59 19 00 00 	lea    0x1959(%rip),%rsi        # a18d <_IO_stdin_used+0x18d>
    8834:	45 31 ed             	xor    %r13d,%r13d
    8837:	e8 34 b8 ff ff       	call   4070 <buf_put>
    883c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8841:	75 19                	jne    885c <fwp_write+0x8fc>
    8843:	eb 6c                	jmp    88b1 <fwp_write+0x951>
    8845:	0f 1f 00             	nopl   (%rax)
    8848:	ba 02 00 00 00       	mov    $0x2,%edx
    884d:	48 8d 35 43 19 00 00 	lea    0x1943(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    8854:	48 89 df             	mov    %rbx,%rdi
    8857:	e8 14 b8 ff ff       	call   4070 <buf_put>
    885c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8862:	b9 00 02 00 00       	mov    $0x200,%ecx
    8867:	31 c0                	xor    %eax,%eax
    8869:	49 83 c5 01          	add    $0x1,%r13
    886d:	4c 8d 05 20 19 00 00 	lea    0x1920(%rip),%r8        # a194 <_IO_stdin_used+0x194>
    8874:	ba 02 00 00 00       	mov    $0x2,%edx
    8879:	be 00 02 00 00       	mov    $0x200,%esi
    887e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8885:	00 
    8886:	e8 25 ab ff ff       	call   33b0 <__snprintf_chk@plt>
    888b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8892:	00 
    8893:	e8 b8 ab ff ff       	call   3450 <strlen@plt>
    8898:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    889f:	00 
    88a0:	48 89 df             	mov    %rbx,%rdi
    88a3:	48 89 c2             	mov    %rax,%rdx
    88a6:	e8 c5 b7 ff ff       	call   4070 <buf_put>
    88ab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    88af:	72 97                	jb     8848 <fwp_write+0x8e8>
    88b1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88b6:	ba 01 00 00 00       	mov    $0x1,%edx
    88bb:	48 89 df             	mov    %rbx,%rdi
    88be:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    88c3:	e8 a8 b7 ff ff       	call   4070 <buf_put>
    88c8:	e9 29 f7 ff ff       	jmp    7ff6 <fwp_write+0x96>
    88cd:	0f 1f 00             	nopl   (%rax)
    88d0:	83 f8 0b             	cmp    $0xb,%eax
    88d3:	0f 85 1b ff ff ff    	jne    87f4 <fwp_write+0x894>
    88d9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    88de:	66 0f 50 c3          	movmskpd %xmm3,%eax
    88e2:	83 e0 01             	and    $0x1,%eax
    88e5:	85 c0                	test   %eax,%eax
    88e7:	0f 84 07 ff ff ff    	je     87f4 <fwp_write+0x894>
    88ed:	4c 89 fe             	mov    %r15,%rsi
    88f0:	48 89 df             	mov    %rbx,%rdi
    88f3:	ba 01 00 00 00       	mov    $0x1,%edx
    88f8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    88fd:	e8 6e b7 ff ff       	call   4070 <buf_put>
    8902:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8907:	48 8b 34 24          	mov    (%rsp),%rsi
    890b:	31 c9                	xor    %ecx,%ecx
    890d:	48 89 df             	mov    %rbx,%rdi
    8910:	e8 4b f6 ff ff       	call   7f60 <fwp_write>
    8915:	ba 01 00 00 00       	mov    $0x1,%edx
    891a:	4c 89 fe             	mov    %r15,%rsi
    891d:	48 89 df             	mov    %rbx,%rdi
    8920:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8925:	e8 46 b7 ff ff       	call   4070 <buf_put>
    892a:	e9 d8 fe ff ff       	jmp    8807 <fwp_write+0x8a7>
    892f:	90                   	nop
    8930:	ba 01 00 00 00       	mov    $0x1,%edx
    8935:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    893a:	48 89 df             	mov    %rbx,%rdi
    893d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8942:	e8 29 b7 ff ff       	call   4070 <buf_put>
    8947:	e9 aa f6 ff ff       	jmp    7ff6 <fwp_write+0x96>
    894c:	0f 1f 40 00          	nopl   0x0(%rax)
    8950:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8955:	ba 01 00 00 00       	mov    $0x1,%edx
    895a:	48 89 df             	mov    %rbx,%rdi
    895d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8962:	e8 09 b7 ff ff       	call   4070 <buf_put>
    8967:	e9 8a f6 ff ff       	jmp    7ff6 <fwp_write+0x96>
    896c:	0f 1f 40 00          	nopl   0x0(%rax)
    8970:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8974:	48 8b 13             	mov    (%rbx),%rdx
    8977:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    897c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8980:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8984:	e9 6d f6 ff ff       	jmp    7ff6 <fwp_write+0x96>
    8989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8990:	ba 02 00 00 00       	mov    $0x2,%edx
    8995:	48 8d 35 fb 17 00 00 	lea    0x17fb(%rip),%rsi        # a197 <_IO_stdin_used+0x197>
    899c:	48 89 df             	mov    %rbx,%rdi
    899f:	e8 cc b6 ff ff       	call   4070 <buf_put>
    89a4:	e9 72 f8 ff ff       	jmp    821b <fwp_write+0x2bb>
    89a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    89b0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    89b5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    89ba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    89be:	48 89 f7             	mov    %rsi,%rdi
    89c1:	48 89 34 24          	mov    %rsi,(%rsp)
    89c5:	e8 86 aa ff ff       	call   3450 <strlen@plt>
    89ca:	48 8b 34 24          	mov    (%rsp),%rsi
    89ce:	48 89 df             	mov    %rbx,%rdi
    89d1:	48 89 c2             	mov    %rax,%rdx
    89d4:	e8 97 b6 ff ff       	call   4070 <buf_put>
    89d9:	ba 03 00 00 00       	mov    $0x3,%edx
    89de:	48 8d 35 d5 17 00 00 	lea    0x17d5(%rip),%rsi        # a1ba <_IO_stdin_used+0x1ba>
    89e5:	48 89 df             	mov    %rbx,%rdi
    89e8:	e8 83 b6 ff ff       	call   4070 <buf_put>
    89ed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    89f2:	e9 35 f8 ff ff       	jmp    822c <fwp_write+0x2cc>
    89f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    89fe:	00 00 
    8a00:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8a05:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8a09:	48 85 ff             	test   %rdi,%rdi
    8a0c:	0f 84 e2 fd ff ff    	je     87f4 <fwp_write+0x894>
    8a12:	48 8d 35 8b 17 00 00 	lea    0x178b(%rip),%rsi        # a1a4 <_IO_stdin_used+0x1a4>
    8a19:	e8 12 ab ff ff       	call   3530 <strcmp@plt>
    8a1e:	85 c0                	test   %eax,%eax
    8a20:	0f 95 c0             	setne  %al
    8a23:	0f b6 c0             	movzbl %al,%eax
    8a26:	e9 c1 fd ff ff       	jmp    87ec <fwp_write+0x88c>
    8a2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a30:	31 c0                	xor    %eax,%eax
    8a32:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8a39:	00 
    8a3a:	0f 97 c0             	seta   %al
    8a3d:	e9 aa fd ff ff       	jmp    87ec <fwp_write+0x88c>
    8a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a48:	48 89 df             	mov    %rbx,%rdi
    8a4b:	ba 02 00 00 00       	mov    $0x2,%edx
    8a50:	48 8d 35 4a 17 00 00 	lea    0x174a(%rip),%rsi        # a1a1 <_IO_stdin_used+0x1a1>
    8a57:	e8 14 b6 ff ff       	call   4070 <buf_put>
    8a5c:	4c 89 e8             	mov    %r13,%rax
    8a5f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8a64:	31 c9                	xor    %ecx,%ecx
    8a66:	48 c1 e0 04          	shl    $0x4,%rax
    8a6a:	48 89 df             	mov    %rbx,%rdi
    8a6d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8a72:	e8 e9 f4 ff ff       	call   7f60 <fwp_write>
    8a77:	e9 5e f6 ff ff       	jmp    80da <fwp_write+0x17a>
    8a7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a80:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8a85:	48 85 ff             	test   %rdi,%rdi
    8a88:	79 0c                	jns    8a96 <fwp_write+0xb36>
    8a8a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8a91:	00 
    8a92:	48 03 75 10          	add    0x10(%rbp),%rsi
    8a96:	48 63 3e             	movslq (%rsi),%rdi
    8a99:	83 f9 02             	cmp    $0x2,%ecx
    8a9c:	89 fe                	mov    %edi,%esi
    8a9e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8aa2:	e9 f9 fb ff ff       	jmp    86a0 <fwp_write+0x740>
    8aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8aae:	00 00 
    8ab0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8ab5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8aba:	48 85 ff             	test   %rdi,%rdi
    8abd:	0f 88 0f 03 00 00    	js     8dd2 <fwp_write+0xe72>
    8ac3:	49 0f bf 38          	movswq (%r8),%rdi
    8ac7:	83 f9 01             	cmp    $0x1,%ecx
    8aca:	0f b7 f7             	movzwl %di,%esi
    8acd:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ad1:	e9 ca fb ff ff       	jmp    86a0 <fwp_write+0x740>
    8ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8add:	00 00 00 
    8ae0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ae5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8aea:	48 83 c5 08          	add    $0x8,%rbp
    8aee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8af3:	e8 78 b5 ff ff       	call   4070 <buf_put>
    8af8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8afd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8b02:	4d 85 ed             	test   %r13,%r13
    8b05:	75 46                	jne    8b4d <fwp_write+0xbed>
    8b07:	e9 04 01 00 00       	jmp    8c10 <fwp_write+0xcb0>
    8b0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b10:	41 80 f9 09          	cmp    $0x9,%r9b
    8b14:	0f 84 d6 00 00 00    	je     8bf0 <fwp_write+0xc90>
    8b1a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8b1e:	0f 85 9c 00 00 00    	jne    8bc0 <fwp_write+0xc60>
    8b24:	ba 02 00 00 00       	mov    $0x2,%edx
    8b29:	48 8d 35 4d 16 00 00 	lea    0x164d(%rip),%rsi        # a17d <_IO_stdin_used+0x17d>
    8b30:	48 89 df             	mov    %rbx,%rdi
    8b33:	e8 38 b5 ff ff       	call   4070 <buf_put>
    8b38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b3f:	00 
    8b40:	48 83 c5 01          	add    $0x1,%rbp
    8b44:	49 39 ec             	cmp    %rbp,%r12
    8b47:	0f 84 c3 00 00 00    	je     8c10 <fwp_write+0xcb0>
    8b4d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8b52:	41 80 f9 0d          	cmp    $0xd,%r9b
    8b56:	74 28                	je     8b80 <fwp_write+0xc20>
    8b58:	7e b6                	jle    8b10 <fwp_write+0xbb0>
    8b5a:	41 80 f9 22          	cmp    $0x22,%r9b
    8b5e:	74 40                	je     8ba0 <fwp_write+0xc40>
    8b60:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8b64:	75 5a                	jne    8bc0 <fwp_write+0xc60>
    8b66:	ba 02 00 00 00       	mov    $0x2,%edx
    8b6b:	48 8d 35 08 16 00 00 	lea    0x1608(%rip),%rsi        # a17a <_IO_stdin_used+0x17a>
    8b72:	48 89 df             	mov    %rbx,%rdi
    8b75:	e8 f6 b4 ff ff       	call   4070 <buf_put>
    8b7a:	eb c4                	jmp    8b40 <fwp_write+0xbe0>
    8b7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b80:	ba 02 00 00 00       	mov    $0x2,%edx
    8b85:	48 8d 35 f7 15 00 00 	lea    0x15f7(%rip),%rsi        # a183 <_IO_stdin_used+0x183>
    8b8c:	48 89 df             	mov    %rbx,%rdi
    8b8f:	e8 dc b4 ff ff       	call   4070 <buf_put>
    8b94:	eb aa                	jmp    8b40 <fwp_write+0xbe0>
    8b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b9d:	00 00 00 
    8ba0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ba5:	48 8d 35 cb 15 00 00 	lea    0x15cb(%rip),%rsi        # a177 <_IO_stdin_used+0x177>
    8bac:	48 89 df             	mov    %rbx,%rdi
    8baf:	e8 bc b4 ff ff       	call   4070 <buf_put>
    8bb4:	eb 8a                	jmp    8b40 <fwp_write+0xbe0>
    8bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8bbd:	00 00 00 
    8bc0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8bc4:	0f 86 2e 01 00 00    	jbe    8cf8 <fwp_write+0xd98>
    8bca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8bce:	0f 84 24 01 00 00    	je     8cf8 <fwp_write+0xd98>
    8bd4:	ba 01 00 00 00       	mov    $0x1,%edx
    8bd9:	4c 89 fe             	mov    %r15,%rsi
    8bdc:	48 89 df             	mov    %rbx,%rdi
    8bdf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8be4:	e8 87 b4 ff ff       	call   4070 <buf_put>
    8be9:	e9 52 ff ff ff       	jmp    8b40 <fwp_write+0xbe0>
    8bee:	66 90                	xchg   %ax,%ax
    8bf0:	ba 02 00 00 00       	mov    $0x2,%edx
    8bf5:	48 8d 35 84 15 00 00 	lea    0x1584(%rip),%rsi        # a180 <_IO_stdin_used+0x180>
    8bfc:	48 89 df             	mov    %rbx,%rdi
    8bff:	e8 6c b4 ff ff       	call   4070 <buf_put>
    8c04:	e9 37 ff ff ff       	jmp    8b40 <fwp_write+0xbe0>
    8c09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c10:	ba 01 00 00 00       	mov    $0x1,%edx
    8c15:	4c 89 fe             	mov    %r15,%rsi
    8c18:	48 89 df             	mov    %rbx,%rdi
    8c1b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8c20:	e8 4b b4 ff ff       	call   4070 <buf_put>
    8c25:	e9 cc f3 ff ff       	jmp    7ff6 <fwp_write+0x96>
    8c2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c30:	83 f8 04             	cmp    $0x4,%eax
    8c33:	0f 85 bb fb ff ff    	jne    87f4 <fwp_write+0x894>
    8c39:	48 8b 04 24          	mov    (%rsp),%rax
    8c3d:	48 8b 40 08          	mov    0x8(%rax),%rax
    8c41:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8c46:	48 c1 e8 3f          	shr    $0x3f,%rax
    8c4a:	e9 96 fc ff ff       	jmp    88e5 <fwp_write+0x985>
    8c4f:	90                   	nop
    8c50:	8b 0c 24             	mov    (%rsp),%ecx
    8c53:	31 c0                	xor    %eax,%eax
    8c55:	85 c9                	test   %ecx,%ecx
    8c57:	0f 98 c0             	sets   %al
    8c5a:	e9 86 fc ff ff       	jmp    88e5 <fwp_write+0x985>
    8c5f:	90                   	nop
    8c60:	48 f7 d8             	neg    %rax
    8c63:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8c6a:	00 
    8c6b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8c72:	2d 
    8c73:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c7a:	00 
    8c7b:	48 83 d2 00          	adc    $0x0,%rdx
    8c7f:	48 89 c6             	mov    %rax,%rsi
    8c82:	48 f7 da             	neg    %rdx
    8c85:	e8 b6 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8c8a:	e9 51 f3 ff ff       	jmp    7fe0 <fwp_write+0x80>
    8c8f:	90                   	nop
    8c90:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8c95:	e9 c3 f5 ff ff       	jmp    825d <fwp_write+0x2fd>
    8c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ca0:	4c 89 e9             	mov    %r13,%rcx
    8ca3:	48 c1 e1 04          	shl    $0x4,%rcx
    8ca7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8cac:	48 85 ff             	test   %rdi,%rdi
    8caf:	0f 89 eb f9 ff ff    	jns    86a0 <fwp_write+0x740>
    8cb5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8cb9:	48 89 ce             	mov    %rcx,%rsi
    8cbc:	e9 df f9 ff ff       	jmp    86a0 <fwp_write+0x740>
    8cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cc8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8ccf:	00 
    8cd0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8cd4:	e9 20 fa ff ff       	jmp    86f9 <fwp_write+0x799>
    8cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ce0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ce5:	48 8d 35 56 14 00 00 	lea    0x1456(%rip),%rsi        # a142 <_IO_stdin_used+0x142>
    8cec:	e9 2d f7 ff ff       	jmp    841e <fwp_write+0x4be>
    8cf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8cf8:	4c 8d 05 87 14 00 00 	lea    0x1487(%rip),%r8        # a186 <_IO_stdin_used+0x186>
    8cff:	b9 10 00 00 00       	mov    $0x10,%ecx
    8d04:	31 c0                	xor    %eax,%eax
    8d06:	ba 02 00 00 00       	mov    $0x2,%edx
    8d0b:	be 10 00 00 00       	mov    $0x10,%esi
    8d10:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d17:	00 
    8d18:	e8 93 a6 ff ff       	call   33b0 <__snprintf_chk@plt>
    8d1d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8d24:	00 
    8d25:	e8 26 a7 ff ff       	call   3450 <strlen@plt>
    8d2a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8d31:	00 
    8d32:	48 89 df             	mov    %rbx,%rdi
    8d35:	48 89 c2             	mov    %rax,%rdx
    8d38:	e8 33 b3 ff ff       	call   4070 <buf_put>
    8d3d:	e9 fe fd ff ff       	jmp    8b40 <fwp_write+0xbe0>
    8d42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8d4c:	48 8d 35 e9 13 00 00 	lea    0x13e9(%rip),%rsi        # a13c <_IO_stdin_used+0x13c>
    8d53:	48 8d 05 e1 13 00 00 	lea    0x13e1(%rip),%rax        # a13b <_IO_stdin_used+0x13b>
    8d5a:	4c 89 e7             	mov    %r12,%rdi
    8d5d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8d61:	48 0f 46 f0          	cmovbe %rax,%rsi
    8d65:	e8 86 a6 ff ff       	call   33f0 <strcpy@plt>
    8d6a:	e9 71 f2 ff ff       	jmp    7fe0 <fwp_write+0x80>
    8d6f:	90                   	nop
    8d70:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8d74:	48 8d 35 c1 13 00 00 	lea    0x13c1(%rip),%rsi        # a13c <_IO_stdin_used+0x13c>
    8d7b:	48 8d 05 b9 13 00 00 	lea    0x13b9(%rip),%rax        # a13b <_IO_stdin_used+0x13b>
    8d82:	0f 2f c8             	comiss %xmm0,%xmm1
    8d85:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8d8c:	00 
    8d8d:	4c 89 e7             	mov    %r12,%rdi
    8d90:	48 0f 46 f0          	cmovbe %rax,%rsi
    8d94:	e8 57 a6 ff ff       	call   33f0 <strcpy@plt>
    8d99:	e9 42 f2 ff ff       	jmp    7fe0 <fwp_write+0x80>
    8d9e:	66 90                	xchg   %ax,%ax
    8da0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8da5:	45 85 c0             	test   %r8d,%r8d
    8da8:	75 34                	jne    8dde <fwp_write+0xe7e>
    8daa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8db1:	00 
    8db2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8db9:	00 00 
    8dbb:	0f 85 74 f6 ff ff    	jne    8435 <fwp_write+0x4d5>
    8dc1:	ba 02 00 00 00       	mov    $0x2,%edx
    8dc6:	48 8d 35 ea 13 00 00 	lea    0x13ea(%rip),%rsi        # a1b7 <_IO_stdin_used+0x1b7>
    8dcd:	e9 a1 f3 ff ff       	jmp    8173 <fwp_write+0x213>
    8dd2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8dd6:	49 89 f0             	mov    %rsi,%r8
    8dd9:	e9 e5 fc ff ff       	jmp    8ac3 <fwp_write+0xb63>
    8dde:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8de3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8de8:	85 ff                	test   %edi,%edi
    8dea:	0f 84 fa f3 ff ff    	je     81ea <fwp_write+0x28a>
    8df0:	ba 01 00 00 00       	mov    $0x1,%edx
    8df5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dfa:	48 89 df             	mov    %rbx,%rdi
    8dfd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8e02:	e8 69 b2 ff ff       	call   4070 <buf_put>
    8e07:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8e0c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e11:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8e17:	85 c0                	test   %eax,%eax
    8e19:	0f 8f f0 f3 ff ff    	jg     820f <fwp_write+0x2af>
    8e1f:	e9 34 f4 ff ff       	jmp    8258 <fwp_write+0x2f8>
    8e24:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8e28:	49 89 c5             	mov    %rax,%r13
    8e2b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8e30:	49 89 c4             	mov    %rax,%r12
    8e33:	49 c1 fd 3f          	sar    $0x3f,%r13
    8e37:	4c 09 e8             	or     %r13,%rax
    8e3a:	0f 84 a7 00 00 00    	je     8ee7 <fwp_write+0xf87>
    8e40:	48 8d 2d 79 34 00 00 	lea    0x3479(%rip),%rbp        # c2c0 <units.0>
    8e47:	4d 89 e7             	mov    %r12,%r15
    8e4a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8e4e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    8e53:	4c 89 ff             	mov    %r15,%rdi
    8e56:	4c 89 ee             	mov    %r13,%rsi
    8e59:	44 89 0c 24          	mov    %r9d,(%rsp)
    8e5d:	48 99                	cqto
    8e5f:	48 89 d1             	mov    %rdx,%rcx
    8e62:	48 89 c2             	mov    %rax,%rdx
    8e65:	e8 26 0f 00 00       	call   9d90 <__divmodti4>
    8e6a:	44 8b 0c 24          	mov    (%rsp),%r9d
    8e6e:	48 89 c1             	mov    %rax,%rcx
    8e71:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    8e76:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    8e7b:	0f 84 94 00 00 00    	je     8f15 <fwp_write+0xfb5>
    8e81:	41 83 c1 01          	add    $0x1,%r9d
    8e85:	48 83 c5 10          	add    $0x10,%rbp
    8e89:	41 83 f9 05          	cmp    $0x5,%r9d
    8e8d:	75 bb                	jne    8e4a <fwp_write+0xeea>
    8e8f:	4d 85 ed             	test   %r13,%r13
    8e92:	79 53                	jns    8ee7 <fwp_write+0xf87>
    8e94:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8e99:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8e9e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8ea3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8ea8:	48 99                	cqto
    8eaa:	48 f7 d8             	neg    %rax
    8ead:	48 83 d2 00          	adc    $0x0,%rdx
    8eb1:	48 89 c6             	mov    %rax,%rsi
    8eb4:	48 f7 da             	neg    %rdx
    8eb7:	e8 84 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8ebc:	49 89 e8             	mov    %rbp,%r8
    8ebf:	ba 00 02 00 00       	mov    $0x200,%edx
    8ec4:	be 02 00 00 00       	mov    $0x2,%esi
    8ec9:	31 c0                	xor    %eax,%eax
    8ecb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8ed2:	00 
    8ed3:	48 8d 0d d8 12 00 00 	lea    0x12d8(%rip),%rcx        # a1b2 <_IO_stdin_used+0x1b2>
    8eda:	4c 89 e7             	mov    %r12,%rdi
    8edd:	e8 fe a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8ee2:	e9 f9 f0 ff ff       	jmp    7fe0 <fwp_write+0x80>
    8ee7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8eec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    8ef1:	31 d2                	xor    %edx,%edx
    8ef3:	48 89 ef             	mov    %rbp,%rdi
    8ef6:	e8 45 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8efb:	eb bf                	jmp    8ebc <fwp_write+0xf5c>
    8efd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    8f04:	4e 61 4e 00 
    8f08:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f0f:	00 
    8f10:	e9 cb f0 ff ff       	jmp    7fe0 <fwp_write+0x80>
    8f15:	44 89 0c 24          	mov    %r9d,(%rsp)
    8f19:	48 89 c8             	mov    %rcx,%rax
    8f1c:	48 85 d2             	test   %rdx,%rdx
    8f1f:	78 51                	js     8f72 <fwp_write+0x1012>
    8f21:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f26:	48 89 c6             	mov    %rax,%rsi
    8f29:	48 89 ef             	mov    %rbp,%rdi
    8f2c:	e8 0f ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f31:	44 8b 0c 24          	mov    (%rsp),%r9d
    8f35:	49 63 c1             	movslq %r9d,%rax
    8f38:	49 89 e8             	mov    %rbp,%r8
    8f3b:	ba 00 02 00 00       	mov    $0x200,%edx
    8f40:	be 02 00 00 00       	mov    $0x2,%esi
    8f45:	48 c1 e0 04          	shl    $0x4,%rax
    8f49:	48 8d 3d 70 33 00 00 	lea    0x3370(%rip),%rdi        # c2c0 <units.0>
    8f50:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f57:	00 
    8f58:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    8f5c:	48 8d 0d 4a 12 00 00 	lea    0x124a(%rip),%rcx        # a1ad <_IO_stdin_used+0x1ad>
    8f63:	4c 89 e7             	mov    %r12,%rdi
    8f66:	31 c0                	xor    %eax,%eax
    8f68:	e8 73 a7 ff ff       	call   36e0 <__sprintf_chk@plt>
    8f6d:	e9 6e f0 ff ff       	jmp    7fe0 <fwp_write+0x80>
    8f72:	48 f7 d8             	neg    %rax
    8f75:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    8f7a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    8f7f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    8f84:	48 83 d2 00          	adc    $0x0,%rdx
    8f88:	48 89 c6             	mov    %rax,%rsi
    8f8b:	48 f7 da             	neg    %rdx
    8f8e:	e8 ad aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f93:	44 8b 0c 24          	mov    (%rsp),%r9d
    8f97:	eb 9c                	jmp    8f35 <fwp_write+0xfd5>
    8f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000008fa0 <fwp_main_thread>:
    8fa0:	f3 0f 1e fa          	endbr64
    8fa4:	41 57                	push   %r15
    8fa6:	41 56                	push   %r14
    8fa8:	41 55                	push   %r13
    8faa:	41 54                	push   %r12
    8fac:	55                   	push   %rbp
    8fad:	53                   	push   %rbx
    8fae:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    8fb5:	8b 0d 49 6b 01 00    	mov    0x16b49(%rip),%ecx        # 1fb04 <fwp_heap+0x13a4>
    8fbb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    8fc2:	00 00 
    8fc4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    8fcb:	00 
    8fcc:	31 c0                	xor    %eax,%eax
    8fce:	85 c9                	test   %ecx,%ecx
    8fd0:	0f 84 62 06 00 00    	je     9638 <fwp_main_thread+0x698>
    8fd6:	8b 15 2c 6b 01 00    	mov    0x16b2c(%rip),%edx        # 1fb08 <fwp_heap+0x13a8>
    8fdc:	85 d2                	test   %edx,%edx
    8fde:	0f 85 3c 06 00 00    	jne    9620 <fwp_main_thread+0x680>
    8fe4:	48 8d 05 95 50 00 00 	lea    0x5095(%rip),%rax        # e080 <alt.5>
    8feb:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    8ff0:	31 f6                	xor    %esi,%esi
    8ff2:	48 c7 05 fb 50 01 00 	movq   $0x40000000,0x150fb(%rip)        # 1e0f8 <fwp_main_stack_size>
    8ff9:	00 00 00 40 
    8ffd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9002:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9007:	48 89 c7             	mov    %rax,%rdi
    900a:	4c 89 25 ef 50 01 00 	mov    %r12,0x150ef(%rip)        # 1e100 <fwp_main_stack_top>
    9011:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9018:	01 00 
    901a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9021:	00 
    9022:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9027:	e8 94 a6 ff ff       	call   36c0 <sigaltstack@plt>
    902c:	85 c0                	test   %eax,%eax
    902e:	0f 85 23 0d 00 00    	jne    9d57 <fwp_main_thread+0xdb7>
    9034:	31 ed                	xor    %ebp,%ebp
    9036:	b9 12 00 00 00       	mov    $0x12,%ecx
    903b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9042:	00 
    9043:	48 89 e8             	mov    %rbp,%rax
    9046:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    904d:	00 
    904e:	f3 48 ab             	rep stos %rax,(%rdi)
    9051:	48 8d 05 98 ac ff ff 	lea    -0x5368(%rip),%rax        # 3cf0 <fwp_segv>
    9058:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    905f:	00 
    9060:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    9067:	04 00 00 08 
    906b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9072:	00 
    9073:	e8 08 a5 ff ff       	call   3580 <sigemptyset@plt>
    9078:	85 c0                	test   %eax,%eax
    907a:	0f 85 d7 0c 00 00    	jne    9d57 <fwp_main_thread+0xdb7>
    9080:	31 d2                	xor    %edx,%edx
    9082:	48 89 de             	mov    %rbx,%rsi
    9085:	bf 0b 00 00 00       	mov    $0xb,%edi
    908a:	e8 71 a3 ff ff       	call   3400 <sigaction@plt>
    908f:	85 c0                	test   %eax,%eax
    9091:	0f 85 c0 0c 00 00    	jne    9d57 <fwp_main_thread+0xdb7>
    9097:	31 d2                	xor    %edx,%edx
    9099:	48 89 de             	mov    %rbx,%rsi
    909c:	bf 07 00 00 00       	mov    $0x7,%edi
    90a1:	e8 5a a3 ff ff       	call   3400 <sigaction@plt>
    90a6:	85 c0                	test   %eax,%eax
    90a8:	0f 85 a9 0c 00 00    	jne    9d57 <fwp_main_thread+0xdb7>
    90ae:	8b 05 b4 4f 00 00    	mov    0x4fb4(%rip),%eax        # e068 <st.3>
    90b4:	85 c0                	test   %eax,%eax
    90b6:	0f 84 8c 05 00 00    	je     9648 <fwp_main_thread+0x6a8>
    90bc:	48 8b 2d 7d 56 01 00 	mov    0x1567d(%rip),%rbp        # 1e740 <fwp_cur>
    90c3:	48 85 ed             	test   %rbp,%rbp
    90c6:	0f 84 04 03 00 00    	je     93d0 <fwp_main_thread+0x430>
    90cc:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    90d1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    90d5:	48 89 eb             	mov    %rbp,%rbx
    90d8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    90dd:	0f 84 41 01 00 00    	je     9224 <fwp_main_thread+0x284>
    90e3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    90e8:	0f 84 12 02 00 00    	je     9300 <fwp_main_thread+0x360>
    90ee:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    90f2:	0f 84 f8 01 00 00    	je     92f0 <fwp_main_thread+0x350>
    90f8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    90fc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9100:	0f 85 7a 02 00 00    	jne    9380 <fwp_main_thread+0x3e0>
    9106:	48 8b 43 60          	mov    0x60(%rbx),%rax
    910a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9111:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9115:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    911c:	00 00 00 00 
    9120:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9127:	48 85 d2             	test   %rdx,%rdx
    912a:	74 07                	je     9133 <fwp_main_thread+0x193>
    912c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9133:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9137:	48 85 c0             	test   %rax,%rax
    913a:	74 34                	je     9170 <fwp_main_thread+0x1d0>
    913c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9140:	48 8b 05 d1 55 01 00 	mov    0x155d1(%rip),%rax        # 1e718 <fwp_timers>
    9147:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    914b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9152:	00 00 00 00 
    9156:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    915d:	48 85 c0             	test   %rax,%rax
    9160:	74 07                	je     9169 <fwp_main_thread+0x1c9>
    9162:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9169:	48 89 1d a8 55 01 00 	mov    %rbx,0x155a8(%rip)        # 1e718 <fwp_timers>
    9170:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9174:	e8 77 de ff ff       	call   6ff0 <fwp_block>
    9179:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9180:	48 85 c9             	test   %rcx,%rcx
    9183:	74 47                	je     91cc <fwp_main_thread+0x22c>
    9185:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    918c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9193:	48 85 d2             	test   %rdx,%rdx
    9196:	0f 84 24 02 00 00    	je     93c0 <fwp_main_thread+0x420>
    919c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    91a3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    91aa:	48 85 c0             	test   %rax,%rax
    91ad:	74 07                	je     91b6 <fwp_main_thread+0x216>
    91af:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    91b6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    91bd:	00 00 00 00 
    91c1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    91c5:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    91cc:	48 8b 0d 6d 55 01 00 	mov    0x1556d(%rip),%rcx        # 1e740 <fwp_cur>
    91d3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    91d7:	0f 84 93 01 00 00    	je     9370 <fwp_main_thread+0x3d0>
    91dd:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    91e4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    91eb:	48 85 d2             	test   %rdx,%rdx
    91ee:	0f 84 94 03 00 00    	je     9588 <fwp_main_thread+0x5e8>
    91f4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    91fb:	48 85 c0             	test   %rax,%rax
    91fe:	74 07                	je     9207 <fwp_main_thread+0x267>
    9200:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9207:	66 0f ef d2          	pxor   %xmm2,%xmm2
    920b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    920f:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    9216:	48 89 cb             	mov    %rcx,%rbx
    9219:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    921e:	0f 85 bf fe ff ff    	jne    90e3 <fwp_main_thread+0x143>
    9224:	48 83 3d ac 71 01 00 	cmpq   $0x0,0x171ac(%rip)        # 203d8 <fwp_state_len>
    922b:	00 
    922c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9230:	0f 84 7c 03 00 00    	je     95b2 <fwp_main_thread+0x612>
    9236:	48 39 1d fb 54 01 00 	cmp    %rbx,0x154fb(%rip)        # 1e738 <fwp_root>
    923d:	c7 05 39 4e 01 00 00 	movl   $0x0,0x14e39(%rip)        # 1e080 <fwp_exit_code>
    9244:	00 00 00 
    9247:	0f 85 38 0b 00 00    	jne    9d85 <fwp_main_thread+0xde5>
    924d:	48 85 db             	test   %rbx,%rbx
    9250:	0f 84 a0 01 00 00    	je     93f6 <fwp_main_thread+0x456>
    9256:	48 8b 15 ab 54 01 00 	mov    0x154ab(%rip),%rdx        # 1e708 <fwp_tasks_active>
    925d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9261:	48 85 d2             	test   %rdx,%rdx
    9264:	0f 84 8c 01 00 00    	je     93f6 <fwp_main_thread+0x456>
    926a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9270:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9274:	75 08                	jne    927e <fwp_main_thread+0x2de>
    9276:	48 89 d7             	mov    %rdx,%rdi
    9279:	e8 32 ae ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    927e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9285:	48 85 d2             	test   %rdx,%rdx
    9288:	75 e6                	jne    9270 <fwp_main_thread+0x2d0>
    928a:	eb 31                	jmp    92bd <fwp_main_thread+0x31d>
    928c:	0f 1f 40 00          	nopl   0x0(%rax)
    9290:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9297:	48 89 1d 82 54 01 00 	mov    %rbx,0x15482(%rip)        # 1e720 <fwp_ready_tail>
    929e:	e8 4d dd ff ff       	call   6ff0 <fwp_block>
    92a3:	e8 38 db ff ff       	call   6de0 <fwp_free_zombie>
    92a8:	48 83 3d 58 54 01 00 	cmpq   $0x0,0x15458(%rip)        # 1e708 <fwp_tasks_active>
    92af:	00 
    92b0:	0f 84 40 01 00 00    	je     93f6 <fwp_main_thread+0x456>
    92b6:	48 8b 1d 7b 54 01 00 	mov    0x1547b(%rip),%rbx        # 1e738 <fwp_root>
    92bd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    92c1:	75 db                	jne    929e <fwp_main_thread+0x2fe>
    92c3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    92c7:	75 d5                	jne    929e <fwp_main_thread+0x2fe>
    92c9:	48 8b 05 50 54 01 00 	mov    0x15450(%rip),%rax        # 1e720 <fwp_ready_tail>
    92d0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    92d4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    92db:	00 00 00 00 
    92df:	48 85 c0             	test   %rax,%rax
    92e2:	75 ac                	jne    9290 <fwp_main_thread+0x2f0>
    92e4:	48 89 1d 3d 54 01 00 	mov    %rbx,0x1543d(%rip)        # 1e728 <fwp_ready_head>
    92eb:	eb aa                	jmp    9297 <fwp_main_thread+0x2f7>
    92ed:	0f 1f 00             	nopl   (%rax)
    92f0:	e8 1b b0 ff ff       	call   4310 <fwp_now_ns>
    92f5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    92f9:	0f 8d 99 02 00 00    	jge    9598 <fwp_main_thread+0x5f8>
    92ff:	90                   	nop
    9300:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9304:	0f 85 ee fd ff ff    	jne    90f8 <fwp_main_thread+0x158>
    930a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    930e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9312:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9316:	0f 85 ee fd ff ff    	jne    910a <fwp_main_thread+0x16a>
    931c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9320:	48 85 c9             	test   %rcx,%rcx
    9323:	0f 84 e1 fd ff ff    	je     910a <fwp_main_thread+0x16a>
    9329:	48 39 c8             	cmp    %rcx,%rax
    932c:	48 89 ce             	mov    %rcx,%rsi
    932f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9336:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    933a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9341:	00 00 00 00 
    9345:	48 0f 4e f0          	cmovle %rax,%rsi
    9349:	48 85 c0             	test   %rax,%rax
    934c:	48 89 c8             	mov    %rcx,%rax
    934f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9356:	48 0f 45 c6          	cmovne %rsi,%rax
    935a:	48 85 d2             	test   %rdx,%rdx
    935d:	74 07                	je     9366 <fwp_main_thread+0x3c6>
    935f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9366:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    936a:	e9 cd fd ff ff       	jmp    913c <fwp_main_thread+0x19c>
    936f:	90                   	nop
    9370:	48 89 cb             	mov    %rcx,%rbx
    9373:	e9 60 fd ff ff       	jmp    90d8 <fwp_main_thread+0x138>
    9378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    937f:	00 
    9380:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9384:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    938b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9392:	00 00 00 00 
    9396:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    939d:	48 85 c0             	test   %rax,%rax
    93a0:	0f 84 8a 08 00 00    	je     9c30 <fwp_main_thread+0xc90>
    93a6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    93ad:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    93b1:	e9 ba fd ff ff       	jmp    9170 <fwp_main_thread+0x1d0>
    93b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93bd:	00 00 00 
    93c0:	48 89 01             	mov    %rax,(%rcx)
    93c3:	e9 e2 fd ff ff       	jmp    91aa <fwp_main_thread+0x20a>
    93c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93cf:	00 
    93d0:	48 83 3d 00 70 01 00 	cmpq   $0x0,0x17000(%rip)        # 203d8 <fwp_state_len>
    93d7:	00 
    93d8:	0f 84 d2 01 00 00    	je     95b0 <fwp_main_thread+0x610>
    93de:	48 83 3d 52 53 01 00 	cmpq   $0x0,0x15352(%rip)        # 1e738 <fwp_root>
    93e5:	00 
    93e6:	c7 05 90 4c 01 00 00 	movl   $0x0,0x14c90(%rip)        # 1e080 <fwp_exit_code>
    93ed:	00 00 00 
    93f0:	0f 85 8a 09 00 00    	jne    9d80 <fwp_main_thread+0xde0>
    93f6:	e8 e5 d9 ff ff       	call   6de0 <fwp_free_zombie>
    93fb:	48 83 3d 25 53 01 00 	cmpq   $0x0,0x15325(%rip)        # 1e728 <fwp_ready_head>
    9402:	00 
    9403:	0f 85 42 a3 ff ff    	jne    374b <fwp_main_thread.cold>
    9409:	48 83 3d 07 53 01 00 	cmpq   $0x0,0x15307(%rip)        # 1e718 <fwp_timers>
    9410:	00 
    9411:	0f 85 34 a3 ff ff    	jne    374b <fwp_main_thread.cold>
    9417:	8b 05 ef 4c 01 00    	mov    0x14cef(%rip),%eax        # 1e10c <fwp_stack_pool_n>
    941d:	85 c0                	test   %eax,%eax
    941f:	74 3c                	je     945d <fwp_main_thread+0x4bd>
    9421:	83 e8 01             	sub    $0x1,%eax
    9424:	4c 8d 25 f5 4c 01 00 	lea    0x14cf5(%rip),%r12        # 1e120 <fwp_stack_pool>
    942b:	48 63 d8             	movslq %eax,%rbx
    942e:	89 c0                	mov    %eax,%eax
    9430:	48 89 da             	mov    %rbx,%rdx
    9433:	48 29 c2             	sub    %rax,%rdx
    9436:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    943a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9440:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9444:	89 1d c2 4c 01 00    	mov    %ebx,0x14cc2(%rip)        # 1e10c <fwp_stack_pool_n>
    944a:	be 00 00 00 10       	mov    $0x10000000,%esi
    944f:	48 83 eb 01          	sub    $0x1,%rbx
    9453:	e8 88 a1 ff ff       	call   35e0 <munmap@plt>
    9458:	48 39 dd             	cmp    %rbx,%rbp
    945b:	75 e3                	jne    9440 <fwp_main_thread+0x4a0>
    945d:	8b 3d ad 4b 00 00    	mov    0x4bad(%rip),%edi        # e010 <fwp_epfd>
    9463:	85 ff                	test   %edi,%edi
    9465:	78 05                	js     946c <fwp_main_thread+0x4cc>
    9467:	e8 64 a0 ff ff       	call   34d0 <close@plt>
    946c:	4c 8b 25 ad 4e 01 00 	mov    0x14ead(%rip),%r12        # 1e320 <fwp_nfdws>
    9473:	48 8b 2d ae 4e 01 00 	mov    0x14eae(%rip),%rbp        # 1e328 <fwp_fdws>
    947a:	31 db                	xor    %ebx,%ebx
    947c:	c7 05 8a 4b 00 00 ff 	movl   $0xffffffff,0x4b8a(%rip)        # e010 <fwp_epfd>
    9483:	ff ff ff 
    9486:	4d 85 e4             	test   %r12,%r12
    9489:	74 32                	je     94bd <fwp_main_thread+0x51d>
    948b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9490:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9495:	48 85 ff             	test   %rdi,%rdi
    9498:	74 1a                	je     94b4 <fwp_main_thread+0x514>
    949a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    949e:	0f 85 a7 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94a4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    94a9:	0f 85 9c a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94af:	e8 9c c0 ff ff       	call   5550 <fwp_mem_free>
    94b4:	48 83 c3 01          	add    $0x1,%rbx
    94b8:	49 39 dc             	cmp    %rbx,%r12
    94bb:	75 d3                	jne    9490 <fwp_main_thread+0x4f0>
    94bd:	48 89 ef             	mov    %rbp,%rdi
    94c0:	e8 8b c0 ff ff       	call   5550 <fwp_mem_free>
    94c5:	48 8b 15 6c 52 01 00 	mov    0x1526c(%rip),%rdx        # 1e738 <fwp_root>
    94cc:	48 c7 05 51 4e 01 00 	movq   $0x0,0x14e51(%rip)        # 1e328 <fwp_fdws>
    94d3:	00 00 00 00 
    94d7:	48 c7 05 3e 4e 01 00 	movq   $0x0,0x14e3e(%rip)        # 1e320 <fwp_nfdws>
    94de:	00 00 00 00 
    94e2:	48 85 d2             	test   %rdx,%rdx
    94e5:	74 4e                	je     9535 <fwp_main_thread+0x595>
    94e7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    94ec:	0f 85 59 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94f2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    94f9:	00 
    94fa:	0f 85 4b a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9500:	48 83 3d d0 6e 01 00 	cmpq   $0x0,0x16ed0(%rip)        # 203d8 <fwp_state_len>
    9507:	00 
    9508:	0f 85 3d a2 ff ff    	jne    374b <fwp_main_thread.cold>
    950e:	48 83 3d b2 6e 01 00 	cmpq   $0x0,0x16eb2(%rip)        # 203c8 <fwp_state_owners>
    9515:	00 
    9516:	0f 85 2f a2 ff ff    	jne    374b <fwp_main_thread.cold>
    951c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9521:	31 c0                	xor    %eax,%eax
    9523:	48 8d 3d 16 4e 01 00 	lea    0x14e16(%rip),%rdi        # 1e340 <fwp_root_context>
    952a:	f3 48 ab             	rep stos %rax,(%rdi)
    952d:	48 89 d7             	mov    %rdx,%rdi
    9530:	e8 1b c0 ff ff       	call   5550 <fwp_mem_free>
    9535:	48 8b 3d e4 4a 00 00 	mov    0x4ae4(%rip),%rdi        # e020 <stdout@GLIBC_2.2.5>
    953c:	48 c7 05 f9 51 01 00 	movq   $0x0,0x151f9(%rip)        # 1e740 <fwp_cur>
    9543:	00 00 00 00 
    9547:	48 c7 05 e6 51 01 00 	movq   $0x0,0x151e6(%rip)        # 1e738 <fwp_root>
    954e:	00 00 00 00 
    9552:	e8 69 a0 ff ff       	call   35c0 <fflush@plt>
    9557:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    955e:	00 
    955f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9566:	00 00 
    9568:	0f 85 01 08 00 00    	jne    9d6f <fwp_main_thread+0xdcf>
    956e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    9575:	31 c0                	xor    %eax,%eax
    9577:	5b                   	pop    %rbx
    9578:	5d                   	pop    %rbp
    9579:	41 5c                	pop    %r12
    957b:	41 5d                	pop    %r13
    957d:	41 5e                	pop    %r14
    957f:	41 5f                	pop    %r15
    9581:	c3                   	ret
    9582:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9588:	48 89 05 89 51 01 00 	mov    %rax,0x15189(%rip)        # 1e718 <fwp_timers>
    958f:	e9 67 fc ff ff       	jmp    91fb <fwp_main_thread+0x25b>
    9594:	0f 1f 40 00          	nopl   0x0(%rax)
    9598:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    959c:	0f 85 5e fd ff ff    	jne    9300 <fwp_main_thread+0x360>
    95a2:	48 89 ef             	mov    %rbp,%rdi
    95a5:	e8 06 ab ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    95aa:	e9 51 fd ff ff       	jmp    9300 <fwp_main_thread+0x360>
    95af:	90                   	nop
    95b0:	31 db                	xor    %ebx,%ebx
    95b2:	48 83 3d 0e 6e 01 00 	cmpq   $0x0,0x16e0e(%rip)        # 203c8 <fwp_state_owners>
    95b9:	00 
    95ba:	0f 85 76 fc ff ff    	jne    9236 <fwp_main_thread+0x296>
    95c0:	48 8b 3d 19 6e 01 00 	mov    0x16e19(%rip),%rdi        # 203e0 <fwp_state>
    95c7:	e8 84 bf ff ff       	call   5550 <fwp_mem_free>
    95cc:	48 c7 05 09 6e 01 00 	movq   $0x0,0x16e09(%rip)        # 203e0 <fwp_state>
    95d3:	00 00 00 00 
    95d7:	48 c7 05 ee 6d 01 00 	movq   $0x0,0x16dee(%rip)        # 203d0 <fwp_state_cap>
    95de:	00 00 00 00 
    95e2:	48 85 db             	test   %rbx,%rbx
    95e5:	0f 84 1f 07 00 00    	je     9d0a <fwp_main_thread+0xd6a>
    95eb:	48 39 1d 46 51 01 00 	cmp    %rbx,0x15146(%rip)        # 1e738 <fwp_root>
    95f2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    95f9:	00 00 00 00 
    95fd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    9604:	00 00 00 00 
    9608:	c7 05 6e 4a 01 00 00 	movl   $0x0,0x14a6e(%rip)        # 1e080 <fwp_exit_code>
    960f:	00 00 00 
    9612:	0f 84 3e fc ff ff    	je     9256 <fwp_main_thread+0x2b6>
    9618:	e9 2e a1 ff ff       	jmp    374b <fwp_main_thread.cold>
    961d:	0f 1f 00             	nopl   (%rax)
    9620:	48 8d 3d f9 b3 ff ff 	lea    -0x4c07(%rip),%rdi        # 4a20 <fwp_heap_report>
    9627:	e8 74 09 00 00       	call   9fa0 <atexit>
    962c:	e9 b3 f9 ff ff       	jmp    8fe4 <fwp_main_thread+0x44>
    9631:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9638:	e8 f3 b4 ff ff       	call   4b30 <fwp_heap_init>
    963d:	e9 94 f9 ff ff       	jmp    8fd6 <fwp_main_thread+0x36>
    9642:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9648:	48 8d 05 c1 df ff ff 	lea    -0x203f(%rip),%rax        # 7610 <fwp_drop1>
    964f:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9654:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    965b:	00 00 
    965d:	4c 8d 3d fc 50 01 00 	lea    0x150fc(%rip),%r15        # 1e760 <fwp_heap>
    9664:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9669:	48 8b 05 88 6d 01 00 	mov    0x16d88(%rip),%rax        # 203f8 <fwp_cleanups>
    9670:	4c 89 25 81 6d 01 00 	mov    %r12,0x16d81(%rip)        # 203f8 <fwp_cleanups>
    9677:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    967d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9681:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9686:	48 8d 05 43 a5 ff ff 	lea    -0x5abd(%rip),%rax        # 3bd0 <fwp_range_release>
    968d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9692:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9697:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    969c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    96a1:	eb 3e                	jmp    96e1 <fwp_main_thread+0x741>
    96a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    96a8:	80 f9 01             	cmp    $0x1,%cl
    96ab:	75 29                	jne    96d6 <fwp_main_thread+0x736>
    96ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96b0:	0f b7 c0             	movzwl %ax,%eax
    96b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96b6:	48 0f af c1          	imul   %rcx,%rax
    96ba:	48 c1 e8 20          	shr    $0x20,%rax
    96be:	48 39 d0             	cmp    %rdx,%rax
    96c1:	73 13                	jae    96d6 <fwp_main_thread+0x736>
    96c3:	49 01 c5             	add    %rax,%r13
    96c6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    96cb:	0f 84 9f 05 00 00    	je     9c70 <fwp_main_thread+0xcd0>
    96d1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    96d6:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    96db:	49 83 ec 01          	sub    $0x1,%r12
    96df:	72 7f                	jb     9760 <fwp_main_thread+0x7c0>
    96e1:	48 89 de             	mov    %rbx,%rsi
    96e4:	bf 01 00 00 00       	mov    $0x1,%edi
    96e9:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    96f0:	00 
    96f1:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    96f6:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    96fd:	00 
    96fe:	e8 6d c4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9703:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    970a:	48 89 c5             	mov    %rax,%rbp
    970d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9714:	48 c1 e2 10          	shl    $0x10,%rdx
    9718:	48 39 d0             	cmp    %rdx,%rax
    971b:	73 b9                	jae    96d6 <fwp_main_thread+0x736>
    971d:	48 89 c2             	mov    %rax,%rdx
    9720:	48 c1 ea 10          	shr    $0x10,%rdx
    9724:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9728:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    972f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9733:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9737:	4d 85 ed             	test   %r13,%r13
    973a:	74 9a                	je     96d6 <fwp_main_thread+0x736>
    973c:	0f b6 0a             	movzbl (%rdx),%ecx
    973f:	80 f9 02             	cmp    $0x2,%cl
    9742:	0f 85 60 ff ff ff    	jne    96a8 <fwp_main_thread+0x708>
    9748:	66 85 c0             	test   %ax,%ax
    974b:	0f 84 75 ff ff ff    	je     96c6 <fwp_main_thread+0x726>
    9751:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    9756:	49 83 ec 01          	sub    $0x1,%r12
    975a:	73 85                	jae    96e1 <fwp_main_thread+0x741>
    975c:	0f 1f 40 00          	nopl   0x0(%rax)
    9760:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9765:	66 0f 6f 05 03 13 00 	movdqa 0x1303(%rip),%xmm0        # aa70 <msg.4+0xa0>
    976c:	00 
    976d:	48 89 de             	mov    %rbx,%rsi
    9770:	bf 01 00 00 00       	mov    $0x1,%edi
    9775:	48 89 05 7c 6c 01 00 	mov    %rax,0x16c7c(%rip)        # 203f8 <fwp_cleanups>
    977c:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    9783:	00 
    9784:	e8 e7 c3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9789:	48 8b 15 a8 63 01 00 	mov    0x163a8(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9790:	49 89 c4             	mov    %rax,%r12
    9793:	48 2b 05 76 63 01 00 	sub    0x16376(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    979a:	48 c1 e2 10          	shl    $0x10,%rdx
    979e:	48 39 d0             	cmp    %rdx,%rax
    97a1:	73 55                	jae    97f8 <fwp_main_thread+0x858>
    97a3:	48 89 c2             	mov    %rax,%rdx
    97a6:	48 c1 ea 10          	shr    $0x10,%rdx
    97aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97ae:	48 8b 15 a3 63 01 00 	mov    0x163a3(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    97b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97b9:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    97bd:	48 85 db             	test   %rbx,%rbx
    97c0:	74 36                	je     97f8 <fwp_main_thread+0x858>
    97c2:	0f b6 0a             	movzbl (%rdx),%ecx
    97c5:	80 f9 02             	cmp    $0x2,%cl
    97c8:	0f 84 92 04 00 00    	je     9c60 <fwp_main_thread+0xcc0>
    97ce:	80 f9 01             	cmp    $0x1,%cl
    97d1:	75 25                	jne    97f8 <fwp_main_thread+0x858>
    97d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97d6:	0f b7 c0             	movzwl %ax,%eax
    97d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97dc:	48 0f af c1          	imul   %rcx,%rax
    97e0:	48 c1 e8 20          	shr    $0x20,%rax
    97e4:	48 39 d0             	cmp    %rdx,%rax
    97e7:	73 0f                	jae    97f8 <fwp_main_thread+0x858>
    97e9:	48 01 c3             	add    %rax,%rbx
    97ec:	80 3b ff             	cmpb   $0xff,(%rbx)
    97ef:	0f 84 3b 05 00 00    	je     9d30 <fwp_main_thread+0xd90>
    97f5:	c6 03 01             	movb   $0x1,(%rbx)
    97f8:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    97fd:	bf 01 00 00 00       	mov    $0x1,%edi
    9802:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    9807:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    980e:	00 f0 3f 
    9811:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9816:	e8 55 c3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    981b:	48 8b 15 16 63 01 00 	mov    0x16316(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9822:	49 89 c4             	mov    %rax,%r12
    9825:	48 2b 05 e4 62 01 00 	sub    0x162e4(%rip),%rax        # 1fb10 <fwp_heap+0x13b0>
    982c:	48 c1 e2 10          	shl    $0x10,%rdx
    9830:	48 39 d0             	cmp    %rdx,%rax
    9833:	73 55                	jae    988a <fwp_main_thread+0x8ea>
    9835:	48 89 c2             	mov    %rax,%rdx
    9838:	48 c1 ea 10          	shr    $0x10,%rdx
    983c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9840:	48 8b 15 11 63 01 00 	mov    0x16311(%rip),%rdx        # 1fb58 <fwp_heap+0x13f8>
    9847:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    984b:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    984f:	48 85 db             	test   %rbx,%rbx
    9852:	74 36                	je     988a <fwp_main_thread+0x8ea>
    9854:	0f b6 0a             	movzbl (%rdx),%ecx
    9857:	80 f9 02             	cmp    $0x2,%cl
    985a:	0f 84 f0 03 00 00    	je     9c50 <fwp_main_thread+0xcb0>
    9860:	80 f9 01             	cmp    $0x1,%cl
    9863:	75 25                	jne    988a <fwp_main_thread+0x8ea>
    9865:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9868:	0f b7 c0             	movzwl %ax,%eax
    986b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    986e:	48 0f af c1          	imul   %rcx,%rax
    9872:	48 c1 e8 20          	shr    $0x20,%rax
    9876:	48 39 d0             	cmp    %rdx,%rax
    9879:	73 0f                	jae    988a <fwp_main_thread+0x8ea>
    987b:	48 01 c3             	add    %rax,%rbx
    987e:	80 3b ff             	cmpb   $0xff,(%rbx)
    9881:	0f 84 b6 04 00 00    	je     9d3d <fwp_main_thread+0xd9d>
    9887:	c6 03 01             	movb   $0x1,(%rbx)
    988a:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    988f:	bf 01 00 00 00       	mov    $0x1,%edi
    9894:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    9899:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    98a0:	33 f3 bf 
    98a3:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    98a8:	e8 c3 c2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    98ad:	48 8b 15 84 62 01 00 	mov    0x16284(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    98b4:	48 8b 0d 55 62 01 00 	mov    0x16255(%rip),%rcx        # 1fb10 <fwp_heap+0x13b0>
    98bb:	49 89 c4             	mov    %rax,%r12
    98be:	48 89 d6             	mov    %rdx,%rsi
    98c1:	48 29 c8             	sub    %rcx,%rax
    98c4:	48 c1 e6 10          	shl    $0x10,%rsi
    98c8:	48 39 f0             	cmp    %rsi,%rax
    98cb:	73 65                	jae    9932 <fwp_main_thread+0x992>
    98cd:	48 89 c6             	mov    %rax,%rsi
    98d0:	48 c1 ee 10          	shr    $0x10,%rsi
    98d4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    98d8:	48 8b 35 79 62 01 00 	mov    0x16279(%rip),%rsi        # 1fb58 <fwp_heap+0x13f8>
    98df:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    98e3:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    98e7:	48 85 db             	test   %rbx,%rbx
    98ea:	74 46                	je     9932 <fwp_main_thread+0x992>
    98ec:	0f b6 3e             	movzbl (%rsi),%edi
    98ef:	40 80 ff 02          	cmp    $0x2,%dil
    98f3:	0f 84 47 03 00 00    	je     9c40 <fwp_main_thread+0xca0>
    98f9:	40 80 ff 01          	cmp    $0x1,%dil
    98fd:	75 33                	jne    9932 <fwp_main_thread+0x992>
    98ff:	8b 7e 18             	mov    0x18(%rsi),%edi
    9902:	0f b7 c0             	movzwl %ax,%eax
    9905:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9908:	48 0f af c7          	imul   %rdi,%rax
    990c:	48 c1 e8 20          	shr    $0x20,%rax
    9910:	48 39 f0             	cmp    %rsi,%rax
    9913:	73 1d                	jae    9932 <fwp_main_thread+0x992>
    9915:	48 01 c3             	add    %rax,%rbx
    9918:	80 3b ff             	cmpb   $0xff,(%rbx)
    991b:	0f 84 29 04 00 00    	je     9d4a <fwp_main_thread+0xdaa>
    9921:	c6 03 01             	movb   $0x1,(%rbx)
    9924:	48 8b 0d e5 61 01 00 	mov    0x161e5(%rip),%rcx        # 1fb10 <fwp_heap+0x13b0>
    992b:	48 8b 15 06 62 01 00 	mov    0x16206(%rip),%rdx        # 1fb38 <fwp_heap+0x13d8>
    9932:	49 89 ed             	mov    %rbp,%r13
    9935:	e9 01 02 00 00       	jmp    9b3b <fwp_main_thread+0xb9b>
    993a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9940:	80 f9 01             	cmp    $0x1,%cl
    9943:	75 2d                	jne    9972 <fwp_main_thread+0x9d2>
    9945:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9948:	0f b7 c0             	movzwl %ax,%eax
    994b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    994e:	48 0f af c1          	imul   %rcx,%rax
    9952:	48 c1 e8 20          	shr    $0x20,%rax
    9956:	48 39 d0             	cmp    %rdx,%rax
    9959:	73 17                	jae    9972 <fwp_main_thread+0x9d2>
    995b:	48 01 c7             	add    %rax,%rdi
    995e:	0f b6 07             	movzbl (%rdi),%eax
    9961:	84 c0                	test   %al,%al
    9963:	74 0d                	je     9972 <fwp_main_thread+0x9d2>
    9965:	3c fd                	cmp    $0xfd,%al
    9967:	0f 87 93 03 00 00    	ja     9d00 <fwp_main_thread+0xd60>
    996d:	83 c0 01             	add    $0x1,%eax
    9970:	88 07                	mov    %al,(%rdi)
    9972:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9977:	66 0f ef c0          	pxor   %xmm0,%xmm0
    997b:	b9 01 00 00 00       	mov    $0x1,%ecx
    9980:	4c 89 e6             	mov    %r12,%rsi
    9983:	48 8d 15 16 42 00 00 	lea    0x4216(%rip),%rdx        # dba0 <d0>
    998a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    998f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    9996:	00 00 
    9998:	e8 c3 e5 ff ff       	call   7f60 <fwp_write>
    999d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    99a2:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    99a7:	48 8d 05 80 06 00 00 	lea    0x680(%rip),%rax        # a02e <_IO_stdin_used+0x2e>
    99ae:	48 85 c9             	test   %rcx,%rcx
    99b1:	48 0f 44 c8          	cmove  %rax,%rcx
    99b5:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    99b9:	0f 87 a4 03 00 00    	ja     9d63 <fwp_main_thread+0xdc3>
    99bf:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    99c3:	be 01 00 00 00       	mov    $0x1,%esi
    99c8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    99cd:	e8 7e c0 ff ff       	call   5a50 <fwp_heap_alloc>
    99d2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    99d7:	4c 89 f2             	mov    %r14,%rdx
    99da:	4c 89 30             	mov    %r14,(%rax)
    99dd:	48 89 c3             	mov    %rax,%rbx
    99e0:	48 8d 78 08          	lea    0x8(%rax),%rdi
    99e4:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    99e9:	e8 b2 9b ff ff       	call   35a0 <memcpy@plt>
    99ee:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    99f4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    99f9:	e8 c2 99 ff ff       	call   33c0 <free@plt>
    99fe:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9a05:	48 89 d8             	mov    %rbx,%rax
    9a08:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9a0f:	48 c1 e2 10          	shl    $0x10,%rdx
    9a13:	48 39 d0             	cmp    %rdx,%rax
    9a16:	73 55                	jae    9a6d <fwp_main_thread+0xacd>
    9a18:	48 89 c2             	mov    %rax,%rdx
    9a1b:	48 c1 ea 10          	shr    $0x10,%rdx
    9a1f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a23:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9a2a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a2e:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    9a32:	48 85 f6             	test   %rsi,%rsi
    9a35:	74 36                	je     9a6d <fwp_main_thread+0xacd>
    9a37:	0f b6 0a             	movzbl (%rdx),%ecx
    9a3a:	80 f9 02             	cmp    $0x2,%cl
    9a3d:	0f 84 9d 01 00 00    	je     9be0 <fwp_main_thread+0xc40>
    9a43:	80 f9 01             	cmp    $0x1,%cl
    9a46:	75 25                	jne    9a6d <fwp_main_thread+0xacd>
    9a48:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a4b:	0f b7 c0             	movzwl %ax,%eax
    9a4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a51:	48 0f af c1          	imul   %rcx,%rax
    9a55:	48 c1 e8 20          	shr    $0x20,%rax
    9a59:	48 39 d0             	cmp    %rdx,%rax
    9a5c:	73 0f                	jae    9a6d <fwp_main_thread+0xacd>
    9a5e:	48 01 c6             	add    %rax,%rsi
    9a61:	80 3e ff             	cmpb   $0xff,(%rsi)
    9a64:	0f 84 96 01 00 00    	je     9c00 <fwp_main_thread+0xc60>
    9a6a:	c6 06 01             	movb   $0x1,(%rsi)
    9a6d:	4c 89 e7             	mov    %r12,%rdi
    9a70:	e8 ab d9 ff ff       	call   7420 <fwp_drop0>
    9a75:	48 8b 13             	mov    (%rbx),%rdx
    9a78:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9a7d:	be 01 00 00 00       	mov    $0x1,%esi
    9a82:	48 8b 0d 37 69 01 00 	mov    0x16937(%rip),%rcx        # 203c0 <fwp_prog_out>
    9a89:	e8 f2 9b ff ff       	call   3680 <fwrite@plt>
    9a8e:	48 8b 35 2b 69 01 00 	mov    0x1692b(%rip),%rsi        # 203c0 <fwp_prog_out>
    9a95:	bf 0a 00 00 00       	mov    $0xa,%edi
    9a9a:	e8 41 9a ff ff       	call   34e0 <fputc@plt>
    9a9f:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9aa6:	48 89 d8             	mov    %rbx,%rax
    9aa9:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    9ab0:	48 c1 e2 10          	shl    $0x10,%rdx
    9ab4:	48 39 d0             	cmp    %rdx,%rax
    9ab7:	73 67                	jae    9b20 <fwp_main_thread+0xb80>
    9ab9:	48 89 c2             	mov    %rax,%rdx
    9abc:	48 c1 ea 10          	shr    $0x10,%rdx
    9ac0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ac4:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9acb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9acf:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9ad3:	4d 85 f6             	test   %r14,%r14
    9ad6:	74 48                	je     9b20 <fwp_main_thread+0xb80>
    9ad8:	0f b6 0a             	movzbl (%rdx),%ecx
    9adb:	80 f9 02             	cmp    $0x2,%cl
    9ade:	0f 84 ac 00 00 00    	je     9b90 <fwp_main_thread+0xbf0>
    9ae4:	80 f9 01             	cmp    $0x1,%cl
    9ae7:	75 37                	jne    9b20 <fwp_main_thread+0xb80>
    9ae9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9aec:	0f b7 c0             	movzwl %ax,%eax
    9aef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9af2:	48 0f af c1          	imul   %rcx,%rax
    9af6:	48 c1 e8 20          	shr    $0x20,%rax
    9afa:	48 39 d0             	cmp    %rdx,%rax
    9afd:	73 21                	jae    9b20 <fwp_main_thread+0xb80>
    9aff:	49 01 c6             	add    %rax,%r14
    9b02:	41 0f b6 06          	movzbl (%r14),%eax
    9b06:	84 c0                	test   %al,%al
    9b08:	74 16                	je     9b20 <fwp_main_thread+0xb80>
    9b0a:	3c 01                	cmp    $0x1,%al
    9b0c:	0f 84 0e 01 00 00    	je     9c20 <fwp_main_thread+0xc80>
    9b12:	3c ff                	cmp    $0xff,%al
    9b14:	0f 84 66 01 00 00    	je     9c80 <fwp_main_thread+0xce0>
    9b1a:	83 e8 01             	sub    $0x1,%eax
    9b1d:	41 88 06             	mov    %al,(%r14)
    9b20:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9b24:	4d 85 ed             	test   %r13,%r13
    9b27:	0f 84 83 00 00 00    	je     9bb0 <fwp_main_thread+0xc10>
    9b2d:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    9b34:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    9b3b:	4c 89 e0             	mov    %r12,%rax
    9b3e:	48 c1 e2 10          	shl    $0x10,%rdx
    9b42:	48 29 c8             	sub    %rcx,%rax
    9b45:	48 39 d0             	cmp    %rdx,%rax
    9b48:	0f 83 24 fe ff ff    	jae    9972 <fwp_main_thread+0x9d2>
    9b4e:	48 89 c2             	mov    %rax,%rdx
    9b51:	48 c1 ea 10          	shr    $0x10,%rdx
    9b55:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b59:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    9b60:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b64:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9b68:	48 85 ff             	test   %rdi,%rdi
    9b6b:	0f 84 01 fe ff ff    	je     9972 <fwp_main_thread+0x9d2>
    9b71:	0f b6 0a             	movzbl (%rdx),%ecx
    9b74:	80 f9 02             	cmp    $0x2,%cl
    9b77:	0f 85 c3 fd ff ff    	jne    9940 <fwp_main_thread+0x9a0>
    9b7d:	66 85 c0             	test   %ax,%ax
    9b80:	0f 85 ec fd ff ff    	jne    9972 <fwp_main_thread+0x9d2>
    9b86:	e9 d3 fd ff ff       	jmp    995e <fwp_main_thread+0x9be>
    9b8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b90:	66 85 c0             	test   %ax,%ax
    9b93:	0f 84 69 ff ff ff    	je     9b02 <fwp_main_thread+0xb62>
    9b99:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9b9d:	4d 85 ed             	test   %r13,%r13
    9ba0:	75 8b                	jne    9b2d <fwp_main_thread+0xb8d>
    9ba2:	0f 1f 00             	nopl   (%rax)
    9ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bac:	00 00 00 00 
    9bb0:	4c 89 e7             	mov    %r12,%rdi
    9bb3:	e8 68 d8 ff ff       	call   7420 <fwp_drop0>
    9bb8:	48 89 ef             	mov    %rbp,%rdi
    9bbb:	e8 60 d8 ff ff       	call   7420 <fwp_drop0>
    9bc0:	48 c7 05 95 44 00 00 	movq   $0x0,0x4495(%rip)        # e060 <v.2>
    9bc7:	00 00 00 00 
    9bcb:	c7 05 93 44 00 00 01 	movl   $0x1,0x4493(%rip)        # e068 <st.3>
    9bd2:	00 00 00 
    9bd5:	e9 e2 f4 ff ff       	jmp    90bc <fwp_main_thread+0x11c>
    9bda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9be0:	66 85 c0             	test   %ax,%ax
    9be3:	0f 85 84 fe ff ff    	jne    9a6d <fwp_main_thread+0xacd>
    9be9:	80 3e ff             	cmpb   $0xff,(%rsi)
    9bec:	0f 85 78 fe ff ff    	jne    9a6a <fwp_main_thread+0xaca>
    9bf2:	0f 1f 00             	nopl   (%rax)
    9bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bfc:	00 00 00 00 
    9c00:	48 89 f7             	mov    %rsi,%rdi
    9c03:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    9c08:	e8 03 b7 ff ff       	call   5310 <fwp_rc_forget_slot>
    9c0d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    9c12:	e9 53 fe ff ff       	jmp    9a6a <fwp_main_thread+0xaca>
    9c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c1e:	00 00 
    9c20:	48 89 df             	mov    %rbx,%rdi
    9c23:	e8 28 b9 ff ff       	call   5550 <fwp_mem_free>
    9c28:	e9 f3 fe ff ff       	jmp    9b20 <fwp_main_thread+0xb80>
    9c2d:	0f 1f 00             	nopl   (%rax)
    9c30:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9c34:	e9 37 f5 ff ff       	jmp    9170 <fwp_main_thread+0x1d0>
    9c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9c40:	66 85 c0             	test   %ax,%ax
    9c43:	0f 85 e9 fc ff ff    	jne    9932 <fwp_main_thread+0x992>
    9c49:	e9 ca fc ff ff       	jmp    9918 <fwp_main_thread+0x978>
    9c4e:	66 90                	xchg   %ax,%ax
    9c50:	66 85 c0             	test   %ax,%ax
    9c53:	0f 85 31 fc ff ff    	jne    988a <fwp_main_thread+0x8ea>
    9c59:	e9 20 fc ff ff       	jmp    987e <fwp_main_thread+0x8de>
    9c5e:	66 90                	xchg   %ax,%ax
    9c60:	66 85 c0             	test   %ax,%ax
    9c63:	0f 85 8f fb ff ff    	jne    97f8 <fwp_main_thread+0x858>
    9c69:	e9 7e fb ff ff       	jmp    97ec <fwp_main_thread+0x84c>
    9c6e:	66 90                	xchg   %ax,%ax
    9c70:	4c 89 ef             	mov    %r13,%rdi
    9c73:	e8 98 b6 ff ff       	call   5310 <fwp_rc_forget_slot>
    9c78:	e9 54 fa ff ff       	jmp    96d1 <fwp_main_thread+0x731>
    9c7d:	0f 1f 00             	nopl   (%rax)
    9c80:	4c 89 f0             	mov    %r14,%rax
    9c83:	48 c1 e8 11          	shr    $0x11,%rax
    9c87:	4c 31 f0             	xor    %r14,%rax
    9c8a:	48 89 c2             	mov    %rax,%rdx
    9c8d:	48 c1 ea 09          	shr    $0x9,%rdx
    9c91:	48 31 d0             	xor    %rdx,%rax
    9c94:	0f b6 d0             	movzbl %al,%edx
    9c97:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    9c9e:	00 
    9c9f:	48 85 c0             	test   %rax,%rax
    9ca2:	75 29                	jne    9ccd <fwp_main_thread+0xd2d>
    9ca4:	e9 cb 00 00 00       	jmp    9d74 <fwp_main_thread+0xdd4>
    9ca9:	90                   	nop
    9caa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cb1:	00 00 00 00 
    9cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cbc:	00 00 00 00 
    9cc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9cc4:	48 85 c0             	test   %rax,%rax
    9cc7:	0f 84 a7 00 00 00    	je     9d74 <fwp_main_thread+0xdd4>
    9ccd:	48 89 c2             	mov    %rax,%rdx
    9cd0:	4c 3b 30             	cmp    (%rax),%r14
    9cd3:	75 eb                	jne    9cc0 <fwp_main_thread+0xd20>
    9cd5:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9cd9:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    9cdd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9ce1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9ce8:	0f 85 32 fe ff ff    	jne    9b20 <fwp_main_thread+0xb80>
    9cee:	4c 89 f7             	mov    %r14,%rdi
    9cf1:	e8 1a b6 ff ff       	call   5310 <fwp_rc_forget_slot>
    9cf6:	41 c6 06 fe          	movb   $0xfe,(%r14)
    9cfa:	e9 21 fe ff ff       	jmp    9b20 <fwp_main_thread+0xb80>
    9cff:	90                   	nop
    9d00:	e8 eb b4 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9d05:	e9 68 fc ff ff       	jmp    9972 <fwp_main_thread+0x9d2>
    9d0a:	48 83 3d 26 4a 01 00 	cmpq   $0x0,0x14a26(%rip)        # 1e738 <fwp_root>
    9d11:	00 
    9d12:	c7 05 64 43 01 00 00 	movl   $0x0,0x14364(%rip)        # 1e080 <fwp_exit_code>
    9d19:	00 00 00 
    9d1c:	0f 84 d4 f6 ff ff    	je     93f6 <fwp_main_thread+0x456>
    9d22:	e9 24 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9d27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d2e:	00 00 
    9d30:	48 89 df             	mov    %rbx,%rdi
    9d33:	e8 d8 b5 ff ff       	call   5310 <fwp_rc_forget_slot>
    9d38:	e9 b8 fa ff ff       	jmp    97f5 <fwp_main_thread+0x855>
    9d3d:	48 89 df             	mov    %rbx,%rdi
    9d40:	e8 cb b5 ff ff       	call   5310 <fwp_rc_forget_slot>
    9d45:	e9 3d fb ff ff       	jmp    9887 <fwp_main_thread+0x8e7>
    9d4a:	48 89 df             	mov    %rbx,%rdi
    9d4d:	e8 be b5 ff ff       	call   5310 <fwp_rc_forget_slot>
    9d52:	e9 ca fb ff ff       	jmp    9921 <fwp_main_thread+0x981>
    9d57:	48 8d 3d ea 0a 00 00 	lea    0xaea(%rip),%rdi        # a848 <_IO_stdin_used+0x848>
    9d5e:	e8 3d a4 ff ff       	call   41a0 <fwp_trap>
    9d63:	48 8d 3d 54 04 00 00 	lea    0x454(%rip),%rdi        # a1be <_IO_stdin_used+0x1be>
    9d6a:	e8 31 a4 ff ff       	call   41a0 <fwp_trap>
    9d6f:	e8 ec 96 ff ff       	call   3460 <__stack_chk_fail@plt>
    9d74:	48 8d 3d fd 09 00 00 	lea    0x9fd(%rip),%rdi        # a778 <_IO_stdin_used+0x778>
    9d7b:	e8 20 a4 ff ff       	call   41a0 <fwp_trap>
    9d80:	e9 c6 99 ff ff       	jmp    374b <fwp_main_thread.cold>
    9d85:	e9 c1 99 ff ff       	jmp    374b <fwp_main_thread.cold>
    9d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009d90 <__divmodti4>:
    9d90:	f3 0f 1e fa          	endbr64
    9d94:	55                   	push   %rbp
    9d95:	49 89 f1             	mov    %rsi,%r9
    9d98:	49 89 d2             	mov    %rdx,%r10
    9d9b:	48 89 fe             	mov    %rdi,%rsi
    9d9e:	49 89 cb             	mov    %rcx,%r11
    9da1:	48 89 e5             	mov    %rsp,%rbp
    9da4:	41 57                	push   %r15
    9da6:	41 56                	push   %r14
    9da8:	41 55                	push   %r13
    9daa:	41 54                	push   %r12
    9dac:	53                   	push   %rbx
    9dad:	4c 89 c3             	mov    %r8,%rbx
    9db0:	45 31 c0             	xor    %r8d,%r8d
    9db3:	4d 85 c9             	test   %r9,%r9
    9db6:	79 12                	jns    9dca <__divmodti4+0x3a>
    9db8:	31 ff                	xor    %edi,%edi
    9dba:	48 f7 de             	neg    %rsi
    9dbd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    9dc4:	4c 19 cf             	sbb    %r9,%rdi
    9dc7:	49 89 f9             	mov    %rdi,%r9
    9dca:	4c 89 d8             	mov    %r11,%rax
    9dcd:	4d 85 db             	test   %r11,%r11
    9dd0:	0f 88 1a 01 00 00    	js     9ef0 <__divmodti4+0x160>
    9dd6:	4c 89 d9             	mov    %r11,%rcx
    9dd9:	49 89 f3             	mov    %rsi,%r11
    9ddc:	75 62                	jne    9e40 <__divmodti4+0xb0>
    9dde:	4d 89 c4             	mov    %r8,%r12
    9de1:	4d 39 d1             	cmp    %r10,%r9
    9de4:	0f 83 46 01 00 00    	jae    9f30 <__divmodti4+0x1a0>
    9dea:	4c 89 d8             	mov    %r11,%rax
    9ded:	4c 89 ca             	mov    %r9,%rdx
    9df0:	49 f7 f2             	div    %r10
    9df3:	49 89 c3             	mov    %rax,%r11
    9df6:	31 c0                	xor    %eax,%eax
    9df8:	48 89 d6             	mov    %rdx,%rsi
    9dfb:	31 ff                	xor    %edi,%edi
    9dfd:	4c 89 d9             	mov    %r11,%rcx
    9e00:	48 89 c2             	mov    %rax,%rdx
    9e03:	48 89 c8             	mov    %rcx,%rax
    9e06:	4d 85 e4             	test   %r12,%r12
    9e09:	74 0a                	je     9e15 <__divmodti4+0x85>
    9e0b:	48 f7 d8             	neg    %rax
    9e0e:	48 83 d2 00          	adc    $0x0,%rdx
    9e12:	48 f7 da             	neg    %rdx
    9e15:	4d 85 c0             	test   %r8,%r8
    9e18:	74 0a                	je     9e24 <__divmodti4+0x94>
    9e1a:	48 f7 de             	neg    %rsi
    9e1d:	48 83 d7 00          	adc    $0x0,%rdi
    9e21:	48 f7 df             	neg    %rdi
    9e24:	48 89 33             	mov    %rsi,(%rbx)
    9e27:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    9e2b:	5b                   	pop    %rbx
    9e2c:	41 5c                	pop    %r12
    9e2e:	41 5d                	pop    %r13
    9e30:	41 5e                	pop    %r14
    9e32:	41 5f                	pop    %r15
    9e34:	5d                   	pop    %rbp
    9e35:	c3                   	ret
    9e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e3d:	00 00 00 
    9e40:	4d 89 c4             	mov    %r8,%r12
    9e43:	49 39 c1             	cmp    %rax,%r9
    9e46:	0f 82 ce 00 00 00    	jb     9f1a <__divmodti4+0x18a>
    9e4c:	31 ff                	xor    %edi,%edi
    9e4e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    9e53:	48 63 c7             	movslq %edi,%rax
    9e56:	be 40 00 00 00       	mov    $0x40,%esi
    9e5b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    9e60:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    9e65:	48 29 c6             	sub    %rax,%rsi
    9e68:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    9e6d:	48 09 c8             	or     %rcx,%rax
    9e70:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    9e75:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    9e7a:	49 89 c6             	mov    %rax,%r14
    9e7d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    9e81:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    9e86:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    9e8b:	49 09 c1             	or     %rax,%r9
    9e8e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    9e92:	4c 89 c8             	mov    %r9,%rax
    9e95:	49 f7 f6             	div    %r14
    9e98:	48 89 d1             	mov    %rdx,%rcx
    9e9b:	49 89 c3             	mov    %rax,%r11
    9e9e:	49 89 c1             	mov    %rax,%r9
    9ea1:	49 f7 e2             	mul    %r10
    9ea4:	49 89 c6             	mov    %rax,%r14
    9ea7:	49 89 d2             	mov    %rdx,%r10
    9eaa:	48 39 d1             	cmp    %rdx,%rcx
    9ead:	72 07                	jb     9eb6 <__divmodti4+0x126>
    9eaf:	75 17                	jne    9ec8 <__divmodti4+0x138>
    9eb1:	49 39 c7             	cmp    %rax,%r15
    9eb4:	73 12                	jae    9ec8 <__divmodti4+0x138>
    9eb6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    9eba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    9ebe:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    9ec2:	49 89 d2             	mov    %rdx,%r10
    9ec5:	49 89 c6             	mov    %rax,%r14
    9ec8:	4c 89 f8             	mov    %r15,%rax
    9ecb:	4c 29 f0             	sub    %r14,%rax
    9ece:	4c 19 d1             	sbb    %r10,%rcx
    9ed1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    9ed6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    9edb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    9ee0:	48 09 c6             	or     %rax,%rsi
    9ee3:	48 89 cf             	mov    %rcx,%rdi
    9ee6:	31 c0                	xor    %eax,%eax
    9ee8:	4c 89 c9             	mov    %r9,%rcx
    9eeb:	e9 10 ff ff ff       	jmp    9e00 <__divmodti4+0x70>
    9ef0:	4c 89 d0             	mov    %r10,%rax
    9ef3:	4c 89 da             	mov    %r11,%rdx
    9ef6:	4d 89 c4             	mov    %r8,%r12
    9ef9:	49 89 f3             	mov    %rsi,%r11
    9efc:	48 f7 d8             	neg    %rax
    9eff:	49 f7 d4             	not    %r12
    9f02:	48 83 d2 00          	adc    $0x0,%rdx
    9f06:	49 89 c2             	mov    %rax,%r10
    9f09:	48 f7 da             	neg    %rdx
    9f0c:	48 89 d1             	mov    %rdx,%rcx
    9f0f:	0f 84 cc fe ff ff    	je     9de1 <__divmodti4+0x51>
    9f15:	49 39 d1             	cmp    %rdx,%r9
    9f18:	73 46                	jae    9f60 <__divmodti4+0x1d0>
    9f1a:	4c 89 cf             	mov    %r9,%rdi
    9f1d:	31 c0                	xor    %eax,%eax
    9f1f:	31 c9                	xor    %ecx,%ecx
    9f21:	e9 da fe ff ff       	jmp    9e00 <__divmodti4+0x70>
    9f26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f2d:	00 00 00 
    9f30:	4d 85 d2             	test   %r10,%r10
    9f33:	75 0d                	jne    9f42 <__divmodti4+0x1b2>
    9f35:	b8 01 00 00 00       	mov    $0x1,%eax
    9f3a:	31 d2                	xor    %edx,%edx
    9f3c:	49 f7 f2             	div    %r10
    9f3f:	49 89 c2             	mov    %rax,%r10
    9f42:	4c 89 c8             	mov    %r9,%rax
    9f45:	31 d2                	xor    %edx,%edx
    9f47:	49 f7 f2             	div    %r10
    9f4a:	49 89 c1             	mov    %rax,%r9
    9f4d:	4c 89 d8             	mov    %r11,%rax
    9f50:	49 f7 f2             	div    %r10
    9f53:	49 89 c3             	mov    %rax,%r11
    9f56:	4c 89 c8             	mov    %r9,%rax
    9f59:	e9 9a fe ff ff       	jmp    9df8 <__divmodti4+0x68>
    9f5e:	66 90                	xchg   %ax,%ax
    9f60:	45 31 f6             	xor    %r14d,%r14d
    9f63:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    9f68:	44 89 f7             	mov    %r14d,%edi
    9f6b:	45 85 f6             	test   %r14d,%r14d
    9f6e:	0f 85 df fe ff ff    	jne    9e53 <__divmodti4+0xc3>
    9f74:	4c 39 ca             	cmp    %r9,%rdx
    9f77:	72 17                	jb     9f90 <__divmodti4+0x200>
    9f79:	31 c9                	xor    %ecx,%ecx
    9f7b:	48 39 c6             	cmp    %rax,%rsi
    9f7e:	73 10                	jae    9f90 <__divmodti4+0x200>
    9f80:	4c 89 cf             	mov    %r9,%rdi
    9f83:	31 c0                	xor    %eax,%eax
    9f85:	e9 76 fe ff ff       	jmp    9e00 <__divmodti4+0x70>
    9f8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f90:	4c 89 de             	mov    %r11,%rsi
    9f93:	b9 01 00 00 00       	mov    $0x1,%ecx
    9f98:	48 29 c6             	sub    %rax,%rsi
    9f9b:	49 19 d1             	sbb    %rdx,%r9
    9f9e:	eb e0                	jmp    9f80 <__divmodti4+0x1f0>

0000000000009fa0 <atexit>:
    9fa0:	f3 0f 1e fa          	endbr64
    9fa4:	48 8b 15 5d 40 00 00 	mov    0x405d(%rip),%rdx        # e008 <__dso_handle>
    9fab:	31 f6                	xor    %esi,%esi
    9fad:	e9 ae 96 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000009fb4 <_fini>:
    9fb4:	f3 0f 1e fa          	endbr64
    9fb8:	48 83 ec 08          	sub    $0x8,%rsp
    9fbc:	48 83 c4 08          	add    $0x8,%rsp
    9fc0:	c3                   	ret
