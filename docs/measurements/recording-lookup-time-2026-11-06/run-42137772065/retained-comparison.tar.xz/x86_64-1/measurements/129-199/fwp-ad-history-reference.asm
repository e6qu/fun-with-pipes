
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 dd 00 00 	lea    0xdd01(%rip),%rax        # 11480 <fwp_fn_table>
    377f:	48 89 05 52 1c 02 00 	mov    %rax,0x21c52(%rip)        # 253d8 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c 1c 02 00 	mov    %rax,0x21c4c(%rip)        # 253e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 df a6 00 00 	lea    0xa6df(%rip),%rdx        # df40 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e c0 00 00 	lea    0xc08e(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 c0 00 00 	lea    0xc048(%rip),%rdi        # f970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c c0 00 00 	lea    0xc00c(%rip),%rdi        # f940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 bf 00 00 	lea    0xbfd8(%rip),%rdi        # f918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 17 02 00 	mov    0x21769(%rip),%rdi        # 253e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 fa 01 00 	mov    0x1fa61(%rip),%rax        # 23760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 f3 01 00 	mov    0x1f3a1(%rip),%rax        # 23120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d f3 01 00 	sub    0x1f38d(%rip),%rax        # 23118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b 0d 02 00 	mov    0x20d7b(%rip),%rax        # 24b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 0d 02 00 	lea    0x20d74(%rip),%r8        # 24b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 0d 02 00 	mov    0x20d55(%rip),%rbx        # 24b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 0d 02 00 	mov    0x20d65(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 0d 02 00 	mov    0x20d01(%rip),%rdi        # 24b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a 0d 02 00 	sub    %rsi,0x20d4a(%rip)        # 24bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da 0c 02 00 	mov    0x20cda(%rip),%rax        # 24b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 0c 02 00 	add    0x20c90(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e 0c 02 00 	mov    0x20c9e(%rip),%rsi        # 24b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac 0c 02 00 	mov    0x20cac(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b 0c 02 00 	mov    %r12,0x20c5b(%rip)        # 24b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 0c 02 00 	mov    %rbp,0x20c49(%rip)        # 24b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e 0c 02 00 	cmp    %rdi,0x20c2e(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 0c 02 00 	mov    %rdi,0x20c25(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 0c 02 00 	sub    %rdi,0x20c69(%rip)        # 24bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 0c 02 00 	mov    0x20c11(%rip),%rax        # 24b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a 0c 02 00 	lea    0x20c0a(%rip),%r8        # 24b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d f0 00 00 	mov    0xf01d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 f6 01 00 	cmp    0x1f6a9(%rip),%rdi        # 23760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f f6 01 00 	mov    0x1f66f(%rip),%rax        # 23740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d f6 01 00 	mov    %rdi,0x1f64d(%rip)        # 23740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 f6 01 00 	mov    %rdi,0x1f629(%rip)        # 23748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 b0 00 00 	lea    0xb005(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ee 00 00 	mov    0xee98(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ee 00 00 	mov    0xee80(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 ed 00 00 	mov    0xed91(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 b2 00 00 	lea    0xb268(%rip),%rdi        # f608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 b6 00 	movdqa 0xb6e0(%rip),%xmm0        # faa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba 0f 02 00 	add    0x20fba(%rip),%rax        # 253d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 b1 00 00 	lea    0xb1c4(%rip),%rdi        # f638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 ec 01 00 	cmp    %rax,0x1ec75(%rip)        # 23108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 ec 01 00 	add    0x1ec70(%rip),%rax        # 23110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad b1 00 00 	lea    0xb1ad(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 a7 00 00 	lea    0xa760(%rip),%rsi        # f1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 00 02 00 	mov    0x20085(%rip),%r9        # 24b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de 00 02 00 	mov    0x200de(%rip),%r8        # 24ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 ab 00 00 	lea    0xabe7(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 00 02 00 	mov    0x200c6(%rip),%rcx        # 24ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 00 02 	movsd  0x200d4(%rip),%xmm1        # 24bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 00 02 	movsd  0x200c4(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 e5 00 00 	mov    0xe565(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 af 00 	movdqa 0xaf78(%rip),%xmm0        # fab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f fb 01 00 	lea    0x1fb7f(%rip),%rax        # 246c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 af 00 	movdqa 0xafa1(%rip),%xmm2        # faf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 fb 01 00 	movaps %xmm0,0x1fb25(%rip)        # 24680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d af 00 	movdqa 0xaf5d(%rip),%xmm0        # fac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 ff 01 00 01 	movl   $0x1,0x1ffb3(%rip)        # 24b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 fb 01 00 	movaps %xmm0,0x1fb13(%rip)        # 24690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b af 00 	movdqa 0xaf4b(%rip),%xmm0        # fad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 14 fb 01 00 	movaps %xmm0,0x1fb14(%rip)        # 246a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c af 00 	movdqa 0xaf4c(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 15 fb 01 00 	movaps %xmm0,0x1fb15(%rip)        # 246b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 eb 01 00 	lea    0x1eb95(%rip),%r8        # 23780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 fe 01 00 	mov    %rax,0x1feb0(%rip)        # 24b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e fe 01 00 	mov    %r12,0x1fe8e(%rip)        # 24b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 fe 01 00 	mov    %rax,0x1fe77(%rip)        # 24b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 fe 01 00 	mov    %rbx,0x1fe90(%rip)        # 24b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 fe 01 00 	mov    %rsi,0x1feb9(%rip)        # 24b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 fe 01 00 	mov    %rax,0x1fe98(%rip)        # 24b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c fe 01 00    	mov    %eax,0x1fe1c(%rip)        # 24b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 0c ea 01 00 	mov    0x1ea0c(%rip),%r8        # 23740 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 3c e9 01 00 	mov    %rbx,0x1e93c(%rip)        # 23748 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 28 e9 01 00 	mov    %r8,0x1e928(%rip)        # 23740 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d fd e1 01 00 	lea    0x1e1fd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 e5 e1 01 00 	movaps %xmm0,0x1e1e5(%rip)        # 230c0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 c1 e1 01 00 	mov    %rax,0x1e1c1(%rip)        # 230a8 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 e2 e1 01 00 	movaps %xmm0,0x1e1e2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 e6 e1 01 00 	movaps %xmm0,0x1e1e6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 e7 e1 01 00 	mov    %rdx,0x1e1e7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 a1 00 00 	lea    0xa190(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d b7 e7 01 00 	mov    0x1e7b7(%rip),%rbx        # 23738 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ea df 00 00 	mov    0xdfea(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 a6 00 00 	lea    0xa6c3(%rip),%rdi        # f740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 8d e6 01 00 	mov    0x1e68d(%rip),%rax        # 23740 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 67 e6 01 00 	mov    %rdx,0x1e667(%rip)        # 23740 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d b4 e5 01 00 	mov    0x1e5b4(%rip),%rbx        # 23738 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 71 e5 01 00 	mov    %rbx,0x1e571(%rip)        # 23738 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 71 e5 01 00 	mov    %rdx,0x1e571(%rip)        # 23748 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 86 e5 01 00 	lea    0x1e586(%rip),%rsi        # 23780 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 05 01 02 00 	addq   $0x1,0x20105(%rip)        # 253c8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 a4 00 00 	lea    0xa497(%rip),%rdi        # f770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 a4 00 00 	lea    0xa4a8(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 9d 00 00 	lea    0x9dd4(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 3e e4 01 00 	lea    0x1e43e(%rip),%rcx        # 23780 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 3f 00 02 00 	subq   $0x1,0x2003f(%rip)        # 253c8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 a4 00 00 	lea    0xa403(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 20 00 02 00 	cmpq   $0x0,0x20020(%rip)        # 253c8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 75 ff 01 00 	sub    %rax,0x1ff75(%rip)        # 253d0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 53 ff 01 00 	add    %r12,0x1ff53(%rip)        # 253d0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 af f6 01 00 	mov    0x1f6af(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 ac e2 01 00 	lea    0x1e2ac(%rip),%rax        # 23780 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 03 f6 01 00 	add    0x1f603(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 d0 f5 01 00 	mov    0x1f5d0(%rip),%rsi        # 24b30 <fwp_heap+0x13b0>
    5560:	48 8b 05 f1 f5 01 00 	mov    0x1f5f1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 e5 f5 01 00 	add    0x1f5e5(%rip),%r8        # 24b78 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 ad f5 01 	addsd  0x1f5ad(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 62 e1 01 00 	lea    0x1e162(%rip),%rax        # 23780 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 6c f5 01 00 	sub    %rdi,0x1f56c(%rip)        # 24ba0 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 84 f5 01 	movsd  %xmm0,0x1f584(%rip)        # 24bc0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 3e f5 01 00 	sub    %rdx,0x1f53e(%rip)        # 24ba0 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 44 f5 01 	addsd  0x1f544(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 38 f5 01 	movsd  %xmm0,0x1f538(%rip)        # 24bc0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 cf f4 01 00 	mov    0x1f4cf(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d c9 f4 01 00 	add    %rcx,0x1f4c9(%rip)        # 24bb0 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 82 f4 01 00 	cmp    0x1f482(%rip),%r9        # 24b70 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 79 f4 01 00 	mov    %r9,0x1f479(%rip)        # 24b70 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 6a f4 01 00 	cmp    0x1f46a(%rip),%r9        # 24b68 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 5d f4 01 00 	mov    %r9,0x1f45d(%rip)        # 24b68 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 73 f3 01 00 	add    0x1f373(%rip),%rdi        # 24b78 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 50 df 01 00 	lea    0x1df50(%rip),%r15        # 23780 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 c0 f2 01 00 	add    0x1f2c0(%rip),%r12        # 24b30 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 19 f3 01 00 	add    0x1f319(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 18 f3 01 00 	cmp    %rax,0x1f318(%rip)        # 24ba8 <fwp_heap+0x1428>
    5890:	48 89 05 09 f3 01 00 	mov    %rax,0x1f309(%rip)        # 24ba0 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 08 f3 01 00 	mov    %rax,0x1f308(%rip)        # 24ba8 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 04 f3 01 	addsd  0x1f304(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 fc f2 01 	movsd  %xmm0,0x1f2fc(%rip)        # 24bb8 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 43 f2 01 00    	mov    0x1f243(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 7f de 01 00 	lea    0x1de7f(%rip),%rdi        # 23780 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 38 f2 01 00 	add    0x1f238(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 33 f2 01 00 	cmp    %rax,0x1f233(%rip)        # 24ba8 <fwp_heap+0x1428>
    5975:	48 89 05 24 f2 01 00 	mov    %rax,0x1f224(%rip)        # 24ba0 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 23 f2 01 00 	mov    %rax,0x1f223(%rip)        # 24ba8 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 1f f2 01 	addsd  0x1f21f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 17 f2 01 	movsd  %xmm0,0x1f217(%rip)        # 24bb8 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ce f0 01 00    	mov    0x1f0ce(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 05 dd 01 00 	lea    0x1dd05(%rip),%rax        # 23780 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 bb f0 01 00 	add    0x1f0bb(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 ba f0 01 00 	cmp    %rax,0x1f0ba(%rip)        # 24ba8 <fwp_heap+0x1428>
    5aee:	48 89 05 ab f0 01 00 	mov    %rax,0x1f0ab(%rip)        # 24ba0 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 aa f0 01 00 	mov    %rax,0x1f0aa(%rip)        # 24ba8 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 a6 f0 01 	addsd  0x1f0a6(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 9e f0 01 	movsd  %xmm0,0x1f09e(%rip)        # 24bb8 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 2c f8 01 00 	add    0x1f82c(%rip),%r9        # 253d8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_p_ad_push.constprop.0>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	49 89 d5             	mov    %rdx,%r13
    5db9:	41 54                	push   %r12
    5dbb:	49 89 fc             	mov    %rdi,%r12
    5dbe:	55                   	push   %rbp
    5dbf:	53                   	push   %rbx
    5dc0:	48 83 ec 38          	sub    $0x38,%rsp
    5dc4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	79 09                	jns    5dd7 <fwp_p_ad_push.constprop.0+0x27>
    5dce:	48 85 d2             	test   %rdx,%rdx
    5dd1:	0f 88 a9 01 00 00    	js     5f80 <fwp_p_ad_push.constprop.0+0x1d0>
    5dd7:	48 89 f8             	mov    %rdi,%rax
    5dda:	48 89 0c 24          	mov    %rcx,(%rsp)
    5dde:	48 09 d0             	or     %rdx,%rax
    5de1:	0f 89 79 01 00 00    	jns    5f60 <fwp_p_ad_push.constprop.0+0x1b0>
    5de7:	48 89 f8             	mov    %rdi,%rax
    5dea:	48 c1 f8 20          	sar    $0x20,%rax
    5dee:	48 85 ff             	test   %rdi,%rdi
    5df1:	79 24                	jns    5e17 <fwp_p_ad_push.constprop.0+0x67>
    5df3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5df8:	48 89 d0             	mov    %rdx,%rax
    5dfb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e02:	00 
    5e03:	49 89 d4             	mov    %rdx,%r12
    5e06:	48 c1 f8 20          	sar    $0x20,%rax
    5e0a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e11:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e17:	48 89 c7             	mov    %rax,%rdi
    5e1a:	e8 61 e6 ff ff       	call   4480 <fwp_tape_of>
    5e1f:	48 89 c3             	mov    %rax,%rbx
    5e22:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e27:	0f 85 f0 02 00 00    	jne    611d <fwp_p_ad_push.constprop.0+0x36d>
    5e2d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5e31:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5e38:	0f 8f 51 02 00 00    	jg     608f <fwp_p_ad_push.constprop.0+0x2df>
    5e3e:	44 89 e0             	mov    %r12d,%eax
    5e41:	49 39 c7             	cmp    %rax,%r15
    5e44:	0f 8e 51 02 00 00    	jle    609b <fwp_p_ad_push.constprop.0+0x2eb>
    5e4a:	4d 85 ed             	test   %r13,%r13
    5e4d:	78 0c                	js     5e5b <fwp_p_ad_push.constprop.0+0xab>
    5e4f:	44 89 e8             	mov    %r13d,%eax
    5e52:	49 39 c7             	cmp    %rax,%r15
    5e55:	0f 8e 40 02 00 00    	jle    609b <fwp_p_ad_push.constprop.0+0x2eb>
    5e5b:	4d 89 fe             	mov    %r15,%r14
    5e5e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5e62:	49 8d 46 01          	lea    0x1(%r14),%rax
    5e66:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5e6c:	0f 87 1d 02 00 00    	ja     608f <fwp_p_ad_push.constprop.0+0x2df>
    5e72:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5e76:	48 39 e8             	cmp    %rbp,%rax
    5e79:	0f 8e 31 01 00 00    	jle    5fb0 <fwp_p_ad_push.constprop.0+0x200>
    5e7f:	48 85 ed             	test   %rbp,%rbp
    5e82:	b9 40 00 00 00       	mov    $0x40,%ecx
    5e87:	48 0f 44 e9          	cmove  %rcx,%rbp
    5e8b:	48 39 e8             	cmp    %rbp,%rax
    5e8e:	7e 20                	jle    5eb0 <fwp_p_ad_push.constprop.0+0x100>
    5e90:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5e97:	0f 8f 03 01 00 00    	jg     5fa0 <fwp_p_ad_push.constprop.0+0x1f0>
    5e9d:	48 01 ed             	add    %rbp,%rbp
    5ea0:	48 39 e8             	cmp    %rbp,%rax
    5ea3:	7f eb                	jg     5e90 <fwp_p_ad_push.constprop.0+0xe0>
    5ea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5eac:	00 00 00 00 
    5eb0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5eb7:	00 
    5eb8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5ebc:	48 89 c6             	mov    %rax,%rsi
    5ebf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ec4:	e8 07 d7 ff ff       	call   35d0 <realloc@plt>
    5ec9:	48 85 c0             	test   %rax,%rax
    5ecc:	0f 84 d5 01 00 00    	je     60a7 <fwp_p_ad_push.constprop.0+0x2f7>
    5ed2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5ed6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5eda:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5ede:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5ee2:	48 89 e9             	mov    %rbp,%rcx
    5ee5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5ee9:	48 c1 e1 04          	shl    $0x4,%rcx
    5eed:	48 89 ce             	mov    %rcx,%rsi
    5ef0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ef5:	e8 d6 d6 ff ff       	call   35d0 <realloc@plt>
    5efa:	48 85 c0             	test   %rax,%rax
    5efd:	0f 84 a4 01 00 00    	je     60a7 <fwp_p_ad_push.constprop.0+0x2f7>
    5f03:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5f07:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5f0c:	4d 85 f6             	test   %r14,%r14
    5f0f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5f13:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f18:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f1f:	00 
    5f20:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f27:	00 
    5f28:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5f2c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5f33:	00 
    5f34:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5f38:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5f3c:	0f 85 e6 00 00 00    	jne    6028 <fwp_p_ad_push.constprop.0+0x278>
    5f42:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5f46:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5f4a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5f4e:	49 01 c8             	add    %rcx,%r8
    5f51:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5f55:	eb 79                	jmp    5fd0 <fwp_p_ad_push.constprop.0+0x220>
    5f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f5e:	00 00 
    5f60:	48 89 d0             	mov    %rdx,%rax
    5f63:	48 c1 ff 20          	sar    $0x20,%rdi
    5f67:	48 c1 f8 20          	sar    $0x20,%rax
    5f6b:	48 39 c7             	cmp    %rax,%rdi
    5f6e:	0f 84 a3 fe ff ff    	je     5e17 <fwp_p_ad_push.constprop.0+0x67>
    5f74:	48 8d 3d 45 98 00 00 	lea    0x9845(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    5f7b:	e8 20 e2 ff ff       	call   41a0 <fwp_trap>
    5f80:	48 83 c4 38          	add    $0x38,%rsp
    5f84:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f8b:	5b                   	pop    %rbx
    5f8c:	5d                   	pop    %rbp
    5f8d:	41 5c                	pop    %r12
    5f8f:	41 5d                	pop    %r13
    5f91:	41 5e                	pop    %r14
    5f93:	41 5f                	pop    %r15
    5f95:	c3                   	ret
    5f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f9d:	00 00 00 
    5fa0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5fa5:	e9 06 ff ff ff       	jmp    5eb0 <fwp_p_ad_push.constprop.0+0x100>
    5faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fb0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5fb4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fb8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5fbf:	00 
    5fc0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5fc7:	00 
    5fc8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5fcc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fd0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5fd6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5fe2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5fe8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5fef:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ff3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ff7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5ffb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6001:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6005:	48 83 c4 38          	add    $0x38,%rsp
    6009:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6010:	ff ff ff 
    6013:	4c 21 e0             	and    %r12,%rax
    6016:	5b                   	pop    %rbx
    6017:	5d                   	pop    %rbp
    6018:	4c 09 f8             	or     %r15,%rax
    601b:	41 5c                	pop    %r12
    601d:	41 5d                	pop    %r13
    601f:	41 5e                	pop    %r14
    6021:	41 5f                	pop    %r15
    6023:	c3                   	ret
    6024:	0f 1f 40 00          	nopl   0x0(%rax)
    6028:	48 39 ca             	cmp    %rcx,%rdx
    602b:	49 89 d6             	mov    %rdx,%r14
    602e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    6033:	48 0f 43 ca          	cmovae %rdx,%rcx
    6037:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    603c:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6041:	48 29 d1             	sub    %rdx,%rcx
    6044:	4c 89 ca             	mov    %r9,%rdx
    6047:	e8 14 d5 ff ff       	call   3560 <__memmove_chk@plt>
    604c:	4c 03 73 30          	add    0x30(%rbx),%r14
    6050:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6055:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6059:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    605e:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6062:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6066:	4c 89 d2             	mov    %r10,%rdx
    6069:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    606e:	e8 9d d5 ff ff       	call   3610 <memmove@plt>
    6073:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6077:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    607b:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6080:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6085:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    608a:	e9 b7 fe ff ff       	jmp    5f46 <fwp_p_ad_push.constprop.0+0x196>
    608f:	48 8d 3d 53 90 00 00 	lea    0x9053(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    6096:	e8 05 e1 ff ff       	call   41a0 <fwp_trap>
    609b:	48 8d 3d 62 90 00 00 	lea    0x9062(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    60a2:	e8 f9 e0 ff ff       	call   41a0 <fwp_trap>
    60a7:	48 89 df             	mov    %rbx,%rdi
    60aa:	e8 51 db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    60af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60b3:	e8 08 d3 ff ff       	call   33c0 <free@plt>
    60b8:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    60bc:	e8 ff d2 ff ff       	call   33c0 <free@plt>
    60c1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    60c5:	e8 f6 d2 ff ff       	call   33c0 <free@plt>
    60ca:	31 c9                	xor    %ecx,%ecx
    60cc:	31 c0                	xor    %eax,%eax
    60ce:	31 d2                	xor    %edx,%edx
    60d0:	89 53 04             	mov    %edx,0x4(%rbx)
    60d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60d7:	ba 13 00 00 00       	mov    $0x13,%edx
    60dc:	be 01 00 00 00       	mov    $0x1,%esi
    60e1:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    60e5:	48 8d 3d 1c 8f 00 00 	lea    0x8f1c(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    60ec:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    60f0:	48 8b 0d 69 cf 00 00 	mov    0xcf69(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    60f7:	48 89 43 40          	mov    %rax,0x40(%rbx)
    60fb:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    60ff:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6103:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6107:	e8 74 d5 ff ff       	call   3680 <fwrite@plt>
    610c:	31 ff                	xor    %edi,%edi
    610e:	e8 ad d4 ff ff       	call   35c0 <fflush@plt>
    6113:	bf 66 00 00 00       	mov    $0x66,%edi
    6118:	e8 83 d5 ff ff       	call   36a0 <_Exit@plt>
    611d:	48 8d 3d e4 96 00 00 	lea    0x96e4(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    6124:	e8 77 e0 ff ff       	call   41a0 <fwp_trap>
    6129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006130 <w107>:
    6130:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6134:	41 55                	push   %r13
    6136:	48 89 fa             	mov    %rdi,%rdx
    6139:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    613d:	41 54                	push   %r12
    613f:	49 89 fc             	mov    %rdi,%r12
    6142:	55                   	push   %rbp
    6143:	53                   	push   %rbx
    6144:	48 89 f3             	mov    %rsi,%rbx
    6147:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    614c:	48 89 f1             	mov    %rsi,%rcx
    614f:	48 83 ec 28          	sub    $0x28,%rsp
    6153:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6159:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    615f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6165:	e8 46 fc ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    616a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6170:	48 89 da             	mov    %rbx,%rdx
    6173:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6179:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6180:	00 f0 3f 
    6183:	48 89 c7             	mov    %rax,%rdi
    6186:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    618d:	00 f0 bf 
    6190:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6195:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    619b:	e8 10 fc ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    61a0:	f2 0f 10 05 88 99 00 	movsd  0x9988(%rip),%xmm0        # fb30 <msg.4+0xb0>
    61a7:	00 
    61a8:	4c 89 e7             	mov    %r12,%rdi
    61ab:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    61b1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    61b8:	00 f0 3f 
    61bb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    61c2:	49 89 c5             	mov    %rax,%r13
    61c5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    61cc:	00 f0 bf 
    61cf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    61d4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61da:	e8 d1 fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    61df:	48 89 e9             	mov    %rbp,%rcx
    61e2:	4c 89 ea             	mov    %r13,%rdx
    61e5:	48 89 ee             	mov    %rbp,%rsi
    61e8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    61ee:	4c 89 ef             	mov    %r13,%rdi
    61f1:	49 89 c4             	mov    %rax,%r12
    61f4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    61f8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    61fe:	e8 ad fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6203:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6209:	f2 0f 59 1d 27 99 00 	mulsd  0x9927(%rip),%xmm3        # fb38 <msg.4+0xb8>
    6210:	00 
    6211:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6218:	00 59 40 
    621b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6220:	48 89 c2             	mov    %rax,%rdx
    6223:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    622a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6230:	e8 7b fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6235:	48 89 d9             	mov    %rbx,%rcx
    6238:	4c 89 e2             	mov    %r12,%rdx
    623b:	48 89 de             	mov    %rbx,%rsi
    623e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6244:	4c 89 e7             	mov    %r12,%rdi
    6247:	48 89 c5             	mov    %rax,%rbp
    624a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    624e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6254:	e8 57 fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6259:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    625f:	48 89 ea             	mov    %rbp,%rdx
    6262:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6268:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    626f:	00 f0 3f 
    6272:	48 89 c7             	mov    %rax,%rdi
    6275:	48 89 ce             	mov    %rcx,%rsi
    6278:	66 48 0f 7e db       	movq   %xmm3,%rbx
    627d:	e8 2e fb ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    6282:	48 83 c4 28          	add    $0x28,%rsp
    6286:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    628b:	5b                   	pop    %rbx
    628c:	5d                   	pop    %rbp
    628d:	41 5c                	pop    %r12
    628f:	41 5d                	pop    %r13
    6291:	c3                   	ret
    6292:	0f 1f 00             	nopl   (%rax)
    6295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    629c:	00 00 00 00 

00000000000062a0 <w164.constprop.0>:
    62a0:	41 54                	push   %r12
    62a2:	55                   	push   %rbp
    62a3:	53                   	push   %rbx
    62a4:	48 83 ec 10          	sub    $0x10,%rsp
    62a8:	4c 8b 27             	mov    (%rdi),%r12
    62ab:	4d 85 e4             	test   %r12,%r12
    62ae:	74 58                	je     6308 <w164.constprop.0+0x68>
    62b0:	48 89 fd             	mov    %rdi,%rbp
    62b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    62b7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    62be:	31 db                	xor    %ebx,%ebx
    62c0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    62c6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    62cb:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62d2:	00 f0 3f 
    62d5:	48 83 c3 02          	add    $0x2,%rbx
    62d9:	48 89 ce             	mov    %rcx,%rsi
    62dc:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    62e2:	e8 c9 fa ff ff       	call   5db0 <fwp_p_ad_push.constprop.0>
    62e7:	4c 39 e3             	cmp    %r12,%rbx
    62ea:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    62f0:	48 89 c7             	mov    %rax,%rdi
    62f3:	72 cb                	jb     62c0 <w164.constprop.0+0x20>
    62f5:	48 83 c4 10          	add    $0x10,%rsp
    62f9:	48 89 f8             	mov    %rdi,%rax
    62fc:	5b                   	pop    %rbx
    62fd:	5d                   	pop    %rbp
    62fe:	41 5c                	pop    %r12
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	48 83 c4 10          	add    $0x10,%rsp
    630c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6313:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6317:	5b                   	pop    %rbx
    6318:	48 89 f8             	mov    %rdi,%rax
    631b:	5d                   	pop    %rbp
    631c:	41 5c                	pop    %r12
    631e:	c3                   	ret
    631f:	90                   	nop

0000000000006320 <fwp_data.part.0.constprop.0>:
    6320:	41 56                	push   %r14
    6322:	41 89 fe             	mov    %edi,%r14d
    6325:	41 54                	push   %r12
    6327:	49 89 f4             	mov    %rsi,%r12
    632a:	55                   	push   %rbp
    632b:	53                   	push   %rbx
    632c:	48 83 ec 08          	sub    $0x8,%rsp
    6330:	8b 05 ee e7 01 00    	mov    0x1e7ee(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    6336:	85 c0                	test   %eax,%eax
    6338:	0f 84 fa 00 00 00    	je     6438 <fwp_data.part.0.constprop.0+0x118>
    633e:	0f b6 05 dd e3 01 00 	movzbl 0x1e3dd(%rip),%eax        # 24722 <fwp_heap+0xfa2>
    6345:	48 8d 15 34 d4 01 00 	lea    0x1d434(%rip),%rdx        # 23780 <fwp_heap>
    634c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6353:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6357:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    635b:	48 8b 18             	mov    (%rax),%rbx
    635e:	48 85 db             	test   %rbx,%rbx
    6361:	0f 84 a9 00 00 00    	je     6410 <fwp_data.part.0.constprop.0+0xf0>
    6367:	48 8b 13             	mov    (%rbx),%rdx
    636a:	48 f7 d2             	not    %rdx
    636d:	48 89 10             	mov    %rdx,(%rax)
    6370:	48 83 fd 18          	cmp    $0x18,%rbp
    6374:	76 1b                	jbe    6391 <fwp_data.part.0.constprop.0+0x71>
    6376:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    637a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    637e:	31 f6                	xor    %esi,%esi
    6380:	48 c1 e8 03          	shr    $0x3,%rax
    6384:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    638b:	00 
    638c:	e8 2f d1 ff ff       	call   34c0 <memset@plt>
    6391:	48 89 e8             	mov    %rbp,%rax
    6394:	48 03 05 05 e8 01 00 	add    0x1e805(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    639b:	0f 82 a8 00 00 00    	jb     6449 <fwp_data.part.0.constprop.0+0x129>
    63a1:	48 39 05 00 e8 01 00 	cmp    %rax,0x1e800(%rip)        # 24ba8 <fwp_heap+0x1428>
    63a8:	48 89 05 f1 e7 01 00 	mov    %rax,0x1e7f1(%rip)        # 24ba0 <fwp_heap+0x1420>
    63af:	73 07                	jae    63b8 <fwp_data.part.0.constprop.0+0x98>
    63b1:	48 89 05 f0 e7 01 00 	mov    %rax,0x1e7f0(%rip)        # 24ba8 <fwp_heap+0x1428>
    63b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    63bc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    63c1:	f2 0f 58 05 ef e7 01 	addsd  0x1e7ef(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    63c8:	00 
    63c9:	f2 0f 11 05 e7 e7 01 	movsd  %xmm0,0x1e7e7(%rip)        # 24bb8 <fwp_heap+0x1438>
    63d0:	00 
    63d1:	b8 02 00 00 00       	mov    $0x2,%eax
    63d6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    63db:	66 0f 6e c8          	movd   %eax,%xmm1
    63df:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    63e3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    63e7:	49 8b 04 24          	mov    (%r12),%rax
    63eb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    63ef:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    63f4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    63f8:	48 83 c4 08          	add    $0x8,%rsp
    63fc:	48 89 d8             	mov    %rbx,%rax
    63ff:	5b                   	pop    %rbx
    6400:	5d                   	pop    %rbp
    6401:	41 5c                	pop    %r12
    6403:	41 5e                	pop    %r14
    6405:	c3                   	ret
    6406:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    640d:	00 00 00 
    6410:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6414:	48 85 db             	test   %rbx,%rbx
    6417:	74 1f                	je     6438 <fwp_data.part.0.constprop.0+0x118>
    6419:	48 8b 50 10          	mov    0x10(%rax),%rdx
    641d:	48 29 da             	sub    %rbx,%rdx
    6420:	48 39 ea             	cmp    %rbp,%rdx
    6423:	72 13                	jb     6438 <fwp_data.part.0.constprop.0+0x118>
    6425:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6429:	48 89 50 08          	mov    %rdx,0x8(%rax)
    642d:	e9 3e ff ff ff       	jmp    6370 <fwp_data.part.0.constprop.0+0x50>
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	31 f6                	xor    %esi,%esi
    643a:	bf 18 00 00 00       	mov    $0x18,%edi
    643f:	e8 0c f6 ff ff       	call   5a50 <fwp_heap_alloc>
    6444:	48 89 c3             	mov    %rax,%rbx
    6447:	eb 88                	jmp    63d1 <fwp_data.part.0.constprop.0+0xb1>
    6449:	e8 62 d8 ff ff       	call   3cb0 <fwp_heap_oom>
    644e:	66 90                	xchg   %ax,%ax

0000000000006450 <fwp_rc_share>:
    6450:	48 8b 05 01 e7 01 00 	mov    0x1e701(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    6457:	48 2b 3d d2 e6 01 00 	sub    0x1e6d2(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    645e:	48 c1 e0 10          	shl    $0x10,%rax
    6462:	48 39 c7             	cmp    %rax,%rdi
    6465:	73 4a                	jae    64b1 <fwp_rc_share+0x61>
    6467:	48 89 f8             	mov    %rdi,%rax
    646a:	48 c1 e8 10          	shr    $0x10,%rax
    646e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6472:	48 8b 05 ff e6 01 00 	mov    0x1e6ff(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    6479:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    647d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6481:	48 85 d2             	test   %rdx,%rdx
    6484:	74 2b                	je     64b1 <fwp_rc_share+0x61>
    6486:	0f b6 08             	movzbl (%rax),%ecx
    6489:	80 f9 02             	cmp    $0x2,%cl
    648c:	74 2a                	je     64b8 <fwp_rc_share+0x68>
    648e:	80 f9 01             	cmp    $0x1,%cl
    6491:	75 1e                	jne    64b1 <fwp_rc_share+0x61>
    6493:	8b 48 18             	mov    0x18(%rax),%ecx
    6496:	0f b7 ff             	movzwl %di,%edi
    6499:	8b 40 1c             	mov    0x1c(%rax),%eax
    649c:	48 0f af f9          	imul   %rcx,%rdi
    64a0:	48 c1 ef 20          	shr    $0x20,%rdi
    64a4:	48 39 c7             	cmp    %rax,%rdi
    64a7:	73 08                	jae    64b1 <fwp_rc_share+0x61>
    64a9:	48 01 fa             	add    %rdi,%rdx
    64ac:	80 3a 00             	cmpb   $0x0,(%rdx)
    64af:	75 0d                	jne    64be <fwp_rc_share+0x6e>
    64b1:	c3                   	ret
    64b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64b8:	66 85 ff             	test   %di,%di
    64bb:	74 ef                	je     64ac <fwp_rc_share+0x5c>
    64bd:	c3                   	ret
    64be:	50                   	push   %rax
    64bf:	48 8d 3d 72 93 00 00 	lea    0x9372(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    64c6:	e8 d5 dc ff ff       	call   41a0 <fwp_trap>
    64cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000064d0 <fwp_rc_fresh>:
    64d0:	48 8b 15 81 e6 01 00 	mov    0x1e681(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    64d7:	48 89 f8             	mov    %rdi,%rax
    64da:	48 89 fe             	mov    %rdi,%rsi
    64dd:	48 2b 05 4c e6 01 00 	sub    0x1e64c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    64e4:	48 c1 e2 10          	shl    $0x10,%rdx
    64e8:	48 39 d0             	cmp    %rdx,%rax
    64eb:	73 4f                	jae    653c <fwp_rc_fresh+0x6c>
    64ed:	48 89 c2             	mov    %rax,%rdx
    64f0:	48 c1 ea 10          	shr    $0x10,%rdx
    64f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    64f8:	48 8b 15 79 e6 01 00 	mov    0x1e679(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    64ff:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6503:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6507:	48 85 d2             	test   %rdx,%rdx
    650a:	74 30                	je     653c <fwp_rc_fresh+0x6c>
    650c:	0f b6 39             	movzbl (%rcx),%edi
    650f:	40 80 ff 02          	cmp    $0x2,%dil
    6513:	74 2b                	je     6540 <fwp_rc_fresh+0x70>
    6515:	40 80 ff 01          	cmp    $0x1,%dil
    6519:	75 21                	jne    653c <fwp_rc_fresh+0x6c>
    651b:	8b 79 18             	mov    0x18(%rcx),%edi
    651e:	0f b7 c0             	movzwl %ax,%eax
    6521:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6524:	48 0f af c7          	imul   %rdi,%rax
    6528:	48 c1 e8 20          	shr    $0x20,%rax
    652c:	48 39 c8             	cmp    %rcx,%rax
    652f:	73 0b                	jae    653c <fwp_rc_fresh+0x6c>
    6531:	48 01 c2             	add    %rax,%rdx
    6534:	80 3a ff             	cmpb   $0xff,(%rdx)
    6537:	74 17                	je     6550 <fwp_rc_fresh+0x80>
    6539:	c6 02 01             	movb   $0x1,(%rdx)
    653c:	48 89 f0             	mov    %rsi,%rax
    653f:	c3                   	ret
    6540:	66 85 c0             	test   %ax,%ax
    6543:	74 ef                	je     6534 <fwp_rc_fresh+0x64>
    6545:	48 89 f0             	mov    %rsi,%rax
    6548:	c3                   	ret
    6549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6550:	48 83 ec 18          	sub    $0x18,%rsp
    6554:	48 89 d7             	mov    %rdx,%rdi
    6557:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    655c:	48 89 14 24          	mov    %rdx,(%rsp)
    6560:	e8 ab ed ff ff       	call   5310 <fwp_rc_forget_slot>
    6565:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    656a:	48 8b 14 24          	mov    (%rsp),%rdx
    656e:	48 89 f0             	mov    %rsi,%rax
    6571:	c6 02 01             	movb   $0x1,(%rdx)
    6574:	48 83 c4 18          	add    $0x18,%rsp
    6578:	c3                   	ret
    6579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006580 <fwp_rc_free_arr>:
    6580:	48 8b 15 d1 e5 01 00 	mov    0x1e5d1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6587:	48 89 f8             	mov    %rdi,%rax
    658a:	48 2b 05 9f e5 01 00 	sub    0x1e59f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6591:	48 c1 e2 10          	shl    $0x10,%rdx
    6595:	48 39 d0             	cmp    %rdx,%rax
    6598:	73 5b                	jae    65f5 <fwp_rc_free_arr+0x75>
    659a:	48 89 c2             	mov    %rax,%rdx
    659d:	48 c1 ea 10          	shr    $0x10,%rdx
    65a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65a5:	48 8b 15 cc e5 01 00 	mov    0x1e5cc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    65ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    65b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    65b4:	48 85 c9             	test   %rcx,%rcx
    65b7:	74 3c                	je     65f5 <fwp_rc_free_arr+0x75>
    65b9:	0f b6 32             	movzbl (%rdx),%esi
    65bc:	40 80 fe 02          	cmp    $0x2,%sil
    65c0:	74 2e                	je     65f0 <fwp_rc_free_arr+0x70>
    65c2:	40 80 fe 01          	cmp    $0x1,%sil
    65c6:	75 2d                	jne    65f5 <fwp_rc_free_arr+0x75>
    65c8:	8b 72 18             	mov    0x18(%rdx),%esi
    65cb:	0f b7 c0             	movzwl %ax,%eax
    65ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65d1:	48 0f af c6          	imul   %rsi,%rax
    65d5:	48 c1 e8 20          	shr    $0x20,%rax
    65d9:	48 39 d0             	cmp    %rdx,%rax
    65dc:	73 17                	jae    65f5 <fwp_rc_free_arr+0x75>
    65de:	48 01 c1             	add    %rax,%rcx
    65e1:	80 39 01             	cmpb   $0x1,(%rcx)
    65e4:	75 0f                	jne    65f5 <fwp_rc_free_arr+0x75>
    65e6:	e9 65 ef ff ff       	jmp    5550 <fwp_mem_free>
    65eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65f0:	66 85 c0             	test   %ax,%ax
    65f3:	74 ec                	je     65e1 <fwp_rc_free_arr+0x61>
    65f5:	c3                   	ret
    65f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65fd:	00 00 00 

0000000000006600 <fwp_rc_dup>:
    6600:	f3 0f 1e fa          	endbr64
    6604:	48 8b 05 4d e5 01 00 	mov    0x1e54d(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    660b:	48 2b 3d 1e e5 01 00 	sub    0x1e51e(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    6612:	48 c1 e0 10          	shl    $0x10,%rax
    6616:	48 39 c7             	cmp    %rax,%rdi
    6619:	73 56                	jae    6671 <fwp_rc_dup+0x71>
    661b:	48 89 f8             	mov    %rdi,%rax
    661e:	48 c1 e8 10          	shr    $0x10,%rax
    6622:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6626:	48 8b 05 4b e5 01 00 	mov    0x1e54b(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    662d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6631:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6635:	48 85 c0             	test   %rax,%rax
    6638:	74 37                	je     6671 <fwp_rc_dup+0x71>
    663a:	0f b6 0a             	movzbl (%rdx),%ecx
    663d:	80 f9 02             	cmp    $0x2,%cl
    6640:	74 36                	je     6678 <fwp_rc_dup+0x78>
    6642:	80 f9 01             	cmp    $0x1,%cl
    6645:	75 2a                	jne    6671 <fwp_rc_dup+0x71>
    6647:	8b 4a 18             	mov    0x18(%rdx),%ecx
    664a:	0f b7 ff             	movzwl %di,%edi
    664d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6650:	48 0f af f9          	imul   %rcx,%rdi
    6654:	48 c1 ef 20          	shr    $0x20,%rdi
    6658:	48 39 d7             	cmp    %rdx,%rdi
    665b:	73 14                	jae    6671 <fwp_rc_dup+0x71>
    665d:	48 01 f8             	add    %rdi,%rax
    6660:	0f b6 10             	movzbl (%rax),%edx
    6663:	84 d2                	test   %dl,%dl
    6665:	74 0a                	je     6671 <fwp_rc_dup+0x71>
    6667:	80 fa fd             	cmp    $0xfd,%dl
    666a:	77 14                	ja     6680 <fwp_rc_dup+0x80>
    666c:	83 c2 01             	add    $0x1,%edx
    666f:	88 10                	mov    %dl,(%rax)
    6671:	c3                   	ret
    6672:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6678:	66 85 ff             	test   %di,%di
    667b:	74 e3                	je     6660 <fwp_rc_dup+0x60>
    667d:	c3                   	ret
    667e:	66 90                	xchg   %ax,%ax
    6680:	48 89 c7             	mov    %rax,%rdi
    6683:	e9 68 eb ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    668f:	00 

0000000000006690 <fwp_owned_entry161>:
    6690:	f3 0f 1e fa          	endbr64
    6694:	48 83 ec 38          	sub    $0x38,%rsp
    6698:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    669d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    66a4:	00 00 
    66a6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    66ab:	31 c0                	xor    %eax,%eax
    66ad:	48 8b 07             	mov    (%rdi),%rax
    66b0:	48 03 47 10          	add    0x10(%rdi),%rax
    66b4:	0f 80 c2 00 00 00    	jo     677c <fwp_owned_entry161+0xec>
    66ba:	66 48 0f 6e c8       	movq   %rax,%xmm1
    66bf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    66c4:	31 ff                	xor    %edi,%edi
    66c6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    66ca:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    66cf:	e8 4c fc ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    66d4:	48 8b 15 7d e4 01 00 	mov    0x1e47d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    66db:	48 89 c6             	mov    %rax,%rsi
    66de:	48 2b 05 4b e4 01 00 	sub    0x1e44b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    66e5:	48 c1 e2 10          	shl    $0x10,%rdx
    66e9:	48 39 d0             	cmp    %rdx,%rax
    66ec:	73 4f                	jae    673d <fwp_owned_entry161+0xad>
    66ee:	48 89 c2             	mov    %rax,%rdx
    66f1:	48 c1 ea 10          	shr    $0x10,%rdx
    66f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66f9:	48 8b 15 78 e4 01 00 	mov    0x1e478(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6700:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6704:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6708:	48 85 d2             	test   %rdx,%rdx
    670b:	74 30                	je     673d <fwp_owned_entry161+0xad>
    670d:	0f b6 39             	movzbl (%rcx),%edi
    6710:	40 80 ff 02          	cmp    $0x2,%dil
    6714:	74 42                	je     6758 <fwp_owned_entry161+0xc8>
    6716:	40 80 ff 01          	cmp    $0x1,%dil
    671a:	75 21                	jne    673d <fwp_owned_entry161+0xad>
    671c:	8b 79 18             	mov    0x18(%rcx),%edi
    671f:	0f b7 c0             	movzwl %ax,%eax
    6722:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6725:	48 0f af c7          	imul   %rdi,%rax
    6729:	48 c1 e8 20          	shr    $0x20,%rax
    672d:	48 39 c8             	cmp    %rcx,%rax
    6730:	73 0b                	jae    673d <fwp_owned_entry161+0xad>
    6732:	48 01 c2             	add    %rax,%rdx
    6735:	80 3a ff             	cmpb   $0xff,(%rdx)
    6738:	74 26                	je     6760 <fwp_owned_entry161+0xd0>
    673a:	c6 02 01             	movb   $0x1,(%rdx)
    673d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6742:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6749:	00 00 
    674b:	75 34                	jne    6781 <fwp_owned_entry161+0xf1>
    674d:	48 89 f0             	mov    %rsi,%rax
    6750:	48 83 c4 38          	add    $0x38,%rsp
    6754:	c3                   	ret
    6755:	0f 1f 00             	nopl   (%rax)
    6758:	66 85 c0             	test   %ax,%ax
    675b:	75 e0                	jne    673d <fwp_owned_entry161+0xad>
    675d:	eb d6                	jmp    6735 <fwp_owned_entry161+0xa5>
    675f:	90                   	nop
    6760:	48 89 d7             	mov    %rdx,%rdi
    6763:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6768:	48 89 14 24          	mov    %rdx,(%rsp)
    676c:	e8 9f eb ff ff       	call   5310 <fwp_rc_forget_slot>
    6771:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6776:	48 8b 14 24          	mov    (%rsp),%rdx
    677a:	eb be                	jmp    673a <fwp_owned_entry161+0xaa>
    677c:	e8 7f cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6781:	e8 da cc ff ff       	call   3460 <__stack_chk_fail@plt>
    6786:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    678d:	00 00 00 

0000000000006790 <e161>:
    6790:	f3 0f 1e fa          	endbr64
    6794:	53                   	push   %rbx
    6795:	48 83 ec 30          	sub    $0x30,%rsp
    6799:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    679e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    67a5:	00 00 
    67a7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    67ac:	31 c0                	xor    %eax,%eax
    67ae:	48 8b 07             	mov    (%rdi),%rax
    67b1:	48 03 47 10          	add    0x10(%rdi),%rax
    67b5:	0f 80 c9 00 00 00    	jo     6884 <e161+0xf4>
    67bb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    67c0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    67c5:	31 ff                	xor    %edi,%edi
    67c7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    67cb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    67d0:	e8 4b fb ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    67d5:	48 8b 15 7c e3 01 00 	mov    0x1e37c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    67dc:	48 89 c3             	mov    %rax,%rbx
    67df:	48 2b 05 4a e3 01 00 	sub    0x1e34a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    67e6:	48 c1 e2 10          	shl    $0x10,%rdx
    67ea:	48 39 d0             	cmp    %rdx,%rax
    67ed:	73 4f                	jae    683e <e161+0xae>
    67ef:	48 89 c2             	mov    %rax,%rdx
    67f2:	48 c1 ea 10          	shr    $0x10,%rdx
    67f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67fa:	48 8b 15 77 e3 01 00 	mov    0x1e377(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6801:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6805:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6809:	48 85 d2             	test   %rdx,%rdx
    680c:	74 30                	je     683e <e161+0xae>
    680e:	0f b6 31             	movzbl (%rcx),%esi
    6811:	40 80 fe 02          	cmp    $0x2,%sil
    6815:	74 49                	je     6860 <e161+0xd0>
    6817:	40 80 fe 01          	cmp    $0x1,%sil
    681b:	75 21                	jne    683e <e161+0xae>
    681d:	8b 71 18             	mov    0x18(%rcx),%esi
    6820:	0f b7 c0             	movzwl %ax,%eax
    6823:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6826:	48 0f af c6          	imul   %rsi,%rax
    682a:	48 c1 e8 20          	shr    $0x20,%rax
    682e:	48 39 c8             	cmp    %rcx,%rax
    6831:	73 0b                	jae    683e <e161+0xae>
    6833:	48 01 c2             	add    %rax,%rdx
    6836:	80 3a ff             	cmpb   $0xff,(%rdx)
    6839:	74 35                	je     6870 <e161+0xe0>
    683b:	c6 02 01             	movb   $0x1,(%rdx)
    683e:	48 89 df             	mov    %rbx,%rdi
    6841:	e8 0a fc ff ff       	call   6450 <fwp_rc_share>
    6846:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    684b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6852:	00 00 
    6854:	75 33                	jne    6889 <e161+0xf9>
    6856:	48 83 c4 30          	add    $0x30,%rsp
    685a:	48 89 d8             	mov    %rbx,%rax
    685d:	5b                   	pop    %rbx
    685e:	c3                   	ret
    685f:	90                   	nop
    6860:	66 85 c0             	test   %ax,%ax
    6863:	75 d9                	jne    683e <e161+0xae>
    6865:	eb cf                	jmp    6836 <e161+0xa6>
    6867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    686e:	00 00 
    6870:	48 89 d7             	mov    %rdx,%rdi
    6873:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6878:	e8 93 ea ff ff       	call   5310 <fwp_rc_forget_slot>
    687d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6882:	eb b7                	jmp    683b <e161+0xab>
    6884:	e8 77 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6889:	e8 d2 cb ff ff       	call   3460 <__stack_chk_fail@plt>
    688e:	66 90                	xchg   %ax,%ax

0000000000006890 <fwp_drop0>:
    6890:	f3 0f 1e fa          	endbr64
    6894:	48 8b 15 bd e2 01 00 	mov    0x1e2bd(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    689b:	48 89 f8             	mov    %rdi,%rax
    689e:	48 2b 05 8b e2 01 00 	sub    0x1e28b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    68a5:	48 c1 e2 10          	shl    $0x10,%rdx
    68a9:	48 39 d0             	cmp    %rdx,%rax
    68ac:	0f 83 be 00 00 00    	jae    6970 <fwp_drop0+0xe0>
    68b2:	48 83 ec 18          	sub    $0x18,%rsp
    68b6:	4c 8d 05 c3 ce 01 00 	lea    0x1cec3(%rip),%r8        # 23780 <fwp_heap>
    68bd:	48 89 c2             	mov    %rax,%rdx
    68c0:	48 c1 ea 10          	shr    $0x10,%rdx
    68c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68c8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    68cf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68d7:	48 85 d2             	test   %rdx,%rdx
    68da:	74 3c                	je     6918 <fwp_drop0+0x88>
    68dc:	0f b6 31             	movzbl (%rcx),%esi
    68df:	40 80 fe 02          	cmp    $0x2,%sil
    68e3:	74 3b                	je     6920 <fwp_drop0+0x90>
    68e5:	40 80 fe 01          	cmp    $0x1,%sil
    68e9:	75 2d                	jne    6918 <fwp_drop0+0x88>
    68eb:	8b 71 18             	mov    0x18(%rcx),%esi
    68ee:	0f b7 c0             	movzwl %ax,%eax
    68f1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68f4:	48 0f af c6          	imul   %rsi,%rax
    68f8:	48 c1 e8 20          	shr    $0x20,%rax
    68fc:	48 39 c8             	cmp    %rcx,%rax
    68ff:	73 17                	jae    6918 <fwp_drop0+0x88>
    6901:	48 01 c2             	add    %rax,%rdx
    6904:	0f b6 02             	movzbl (%rdx),%eax
    6907:	84 c0                	test   %al,%al
    6909:	74 0d                	je     6918 <fwp_drop0+0x88>
    690b:	3c 01                	cmp    $0x1,%al
    690d:	74 21                	je     6930 <fwp_drop0+0xa0>
    690f:	3c ff                	cmp    $0xff,%al
    6911:	74 65                	je     6978 <fwp_drop0+0xe8>
    6913:	83 e8 01             	sub    $0x1,%eax
    6916:	88 02                	mov    %al,(%rdx)
    6918:	48 83 c4 18          	add    $0x18,%rsp
    691c:	c3                   	ret
    691d:	0f 1f 00             	nopl   (%rax)
    6920:	66 85 c0             	test   %ax,%ax
    6923:	74 df                	je     6904 <fwp_drop0+0x74>
    6925:	48 83 c4 18          	add    $0x18,%rsp
    6929:	c3                   	ret
    692a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6930:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6934:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6939:	e8 42 fc ff ff       	call   6580 <fwp_rc_free_arr>
    693e:	4c 8d 05 3b ce 01 00 	lea    0x1ce3b(%rip),%r8        # 23780 <fwp_heap>
    6945:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    694a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6951:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6958:	48 c1 e2 10          	shl    $0x10,%rdx
    695c:	48 39 d0             	cmp    %rdx,%rax
    695f:	73 b7                	jae    6918 <fwp_drop0+0x88>
    6961:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6966:	e9 52 ff ff ff       	jmp    68bd <fwp_drop0+0x2d>
    696b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6970:	c3                   	ret
    6971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6978:	48 89 d0             	mov    %rdx,%rax
    697b:	48 c1 e8 11          	shr    $0x11,%rax
    697f:	48 31 d0             	xor    %rdx,%rax
    6982:	48 89 c1             	mov    %rax,%rcx
    6985:	48 c1 e9 09          	shr    $0x9,%rcx
    6989:	48 31 c8             	xor    %rcx,%rax
    698c:	0f b6 c8             	movzbl %al,%ecx
    698f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6996:	00 
    6997:	48 85 c0             	test   %rax,%rax
    699a:	75 0d                	jne    69a9 <fwp_drop0+0x119>
    699c:	eb 46                	jmp    69e4 <fwp_drop0+0x154>
    699e:	66 90                	xchg   %ax,%ax
    69a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    69a4:	48 85 c0             	test   %rax,%rax
    69a7:	74 3b                	je     69e4 <fwp_drop0+0x154>
    69a9:	48 89 c1             	mov    %rax,%rcx
    69ac:	48 39 10             	cmp    %rdx,(%rax)
    69af:	75 ef                	jne    69a0 <fwp_drop0+0x110>
    69b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    69b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    69b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    69bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    69c4:	0f 85 4e ff ff ff    	jne    6918 <fwp_drop0+0x88>
    69ca:	48 89 d7             	mov    %rdx,%rdi
    69cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    69d2:	e8 39 e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    69d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    69dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    69df:	e9 34 ff ff ff       	jmp    6918 <fwp_drop0+0x88>
    69e4:	48 8d 3d ad 8d 00 00 	lea    0x8dad(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    69eb:	e8 b0 d7 ff ff       	call   41a0 <fwp_trap>

00000000000069f0 <fwp_arg_drop12>:
    69f0:	f3 0f 1e fa          	endbr64
    69f4:	85 f6                	test   %esi,%esi
    69f6:	75 04                	jne    69fc <fwp_arg_drop12+0xc>
    69f8:	85 d2                	test   %edx,%edx
    69fa:	75 04                	jne    6a00 <fwp_arg_drop12+0x10>
    69fc:	c3                   	ret
    69fd:	0f 1f 00             	nopl   (%rax)
    6a00:	48 8b 3f             	mov    (%rdi),%rdi
    6a03:	e9 88 fe ff ff       	jmp    6890 <fwp_drop0>
    6a08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a0f:	00 

0000000000006a10 <fwp_drop1>:
    6a10:	f3 0f 1e fa          	endbr64
    6a14:	48 8b 15 3d e1 01 00 	mov    0x1e13d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6a1b:	48 89 f8             	mov    %rdi,%rax
    6a1e:	48 2b 05 0b e1 01 00 	sub    0x1e10b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6a25:	48 c1 e2 10          	shl    $0x10,%rdx
    6a29:	48 39 d0             	cmp    %rdx,%rax
    6a2c:	0f 83 be 00 00 00    	jae    6af0 <fwp_drop1+0xe0>
    6a32:	48 83 ec 18          	sub    $0x18,%rsp
    6a36:	4c 8d 05 43 cd 01 00 	lea    0x1cd43(%rip),%r8        # 23780 <fwp_heap>
    6a3d:	48 89 c2             	mov    %rax,%rdx
    6a40:	48 c1 ea 10          	shr    $0x10,%rdx
    6a44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a48:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6a4f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a57:	48 85 d2             	test   %rdx,%rdx
    6a5a:	74 3c                	je     6a98 <fwp_drop1+0x88>
    6a5c:	0f b6 31             	movzbl (%rcx),%esi
    6a5f:	40 80 fe 02          	cmp    $0x2,%sil
    6a63:	74 3b                	je     6aa0 <fwp_drop1+0x90>
    6a65:	40 80 fe 01          	cmp    $0x1,%sil
    6a69:	75 2d                	jne    6a98 <fwp_drop1+0x88>
    6a6b:	8b 71 18             	mov    0x18(%rcx),%esi
    6a6e:	0f b7 c0             	movzwl %ax,%eax
    6a71:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a74:	48 0f af c6          	imul   %rsi,%rax
    6a78:	48 c1 e8 20          	shr    $0x20,%rax
    6a7c:	48 39 c8             	cmp    %rcx,%rax
    6a7f:	73 17                	jae    6a98 <fwp_drop1+0x88>
    6a81:	48 01 c2             	add    %rax,%rdx
    6a84:	0f b6 02             	movzbl (%rdx),%eax
    6a87:	84 c0                	test   %al,%al
    6a89:	74 0d                	je     6a98 <fwp_drop1+0x88>
    6a8b:	3c 01                	cmp    $0x1,%al
    6a8d:	74 21                	je     6ab0 <fwp_drop1+0xa0>
    6a8f:	3c ff                	cmp    $0xff,%al
    6a91:	74 65                	je     6af8 <fwp_drop1+0xe8>
    6a93:	83 e8 01             	sub    $0x1,%eax
    6a96:	88 02                	mov    %al,(%rdx)
    6a98:	48 83 c4 18          	add    $0x18,%rsp
    6a9c:	c3                   	ret
    6a9d:	0f 1f 00             	nopl   (%rax)
    6aa0:	66 85 c0             	test   %ax,%ax
    6aa3:	74 df                	je     6a84 <fwp_drop1+0x74>
    6aa5:	48 83 c4 18          	add    $0x18,%rsp
    6aa9:	c3                   	ret
    6aaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ab0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6ab4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6ab9:	e8 c2 fa ff ff       	call   6580 <fwp_rc_free_arr>
    6abe:	4c 8d 05 bb cc 01 00 	lea    0x1ccbb(%rip),%r8        # 23780 <fwp_heap>
    6ac5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6aca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ad1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ad8:	48 c1 e2 10          	shl    $0x10,%rdx
    6adc:	48 39 d0             	cmp    %rdx,%rax
    6adf:	73 b7                	jae    6a98 <fwp_drop1+0x88>
    6ae1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ae6:	e9 52 ff ff ff       	jmp    6a3d <fwp_drop1+0x2d>
    6aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6af0:	c3                   	ret
    6af1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6af8:	48 89 d0             	mov    %rdx,%rax
    6afb:	48 c1 e8 11          	shr    $0x11,%rax
    6aff:	48 31 d0             	xor    %rdx,%rax
    6b02:	48 89 c1             	mov    %rax,%rcx
    6b05:	48 c1 e9 09          	shr    $0x9,%rcx
    6b09:	48 31 c8             	xor    %rcx,%rax
    6b0c:	0f b6 c8             	movzbl %al,%ecx
    6b0f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6b16:	00 
    6b17:	48 85 c0             	test   %rax,%rax
    6b1a:	75 0d                	jne    6b29 <fwp_drop1+0x119>
    6b1c:	eb 46                	jmp    6b64 <fwp_drop1+0x154>
    6b1e:	66 90                	xchg   %ax,%ax
    6b20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b24:	48 85 c0             	test   %rax,%rax
    6b27:	74 3b                	je     6b64 <fwp_drop1+0x154>
    6b29:	48 89 c1             	mov    %rax,%rcx
    6b2c:	48 39 10             	cmp    %rdx,(%rax)
    6b2f:	75 ef                	jne    6b20 <fwp_drop1+0x110>
    6b31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6b44:	0f 85 4e ff ff ff    	jne    6a98 <fwp_drop1+0x88>
    6b4a:	48 89 d7             	mov    %rdx,%rdi
    6b4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b52:	e8 b9 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6b57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6b5f:	e9 34 ff ff ff       	jmp    6a98 <fwp_drop1+0x88>
    6b64:	48 8d 3d 2d 8c 00 00 	lea    0x8c2d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6b6b:	e8 30 d6 ff ff       	call   41a0 <fwp_trap>

0000000000006b70 <fwp_closure_drop>:
    6b70:	48 8b 15 e1 df 01 00 	mov    0x1dfe1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6b77:	48 89 f8             	mov    %rdi,%rax
    6b7a:	48 2b 05 af df 01 00 	sub    0x1dfaf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6b81:	48 c1 e2 10          	shl    $0x10,%rdx
    6b85:	48 39 d0             	cmp    %rdx,%rax
    6b88:	73 6b                	jae    6bf5 <fwp_closure_drop+0x85>
    6b8a:	48 89 c2             	mov    %rax,%rdx
    6b8d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b95:	48 8b 15 dc df 01 00 	mov    0x1dfdc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6b9c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ba0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ba4:	48 85 d2             	test   %rdx,%rdx
    6ba7:	74 4c                	je     6bf5 <fwp_closure_drop+0x85>
    6ba9:	0f b6 31             	movzbl (%rcx),%esi
    6bac:	40 80 fe 02          	cmp    $0x2,%sil
    6bb0:	74 3e                	je     6bf0 <fwp_closure_drop+0x80>
    6bb2:	40 80 fe 01          	cmp    $0x1,%sil
    6bb6:	75 3d                	jne    6bf5 <fwp_closure_drop+0x85>
    6bb8:	8b 71 18             	mov    0x18(%rcx),%esi
    6bbb:	0f b7 c0             	movzwl %ax,%eax
    6bbe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6bc1:	48 0f af c6          	imul   %rsi,%rax
    6bc5:	48 c1 e8 20          	shr    $0x20,%rax
    6bc9:	48 39 c8             	cmp    %rcx,%rax
    6bcc:	73 27                	jae    6bf5 <fwp_closure_drop+0x85>
    6bce:	48 01 c2             	add    %rax,%rdx
    6bd1:	0f b6 02             	movzbl (%rdx),%eax
    6bd4:	84 c0                	test   %al,%al
    6bd6:	74 1d                	je     6bf5 <fwp_closure_drop+0x85>
    6bd8:	3c 01                	cmp    $0x1,%al
    6bda:	74 24                	je     6c00 <fwp_closure_drop+0x90>
    6bdc:	3c ff                	cmp    $0xff,%al
    6bde:	74 48                	je     6c28 <fwp_closure_drop+0xb8>
    6be0:	83 e8 01             	sub    $0x1,%eax
    6be3:	88 02                	mov    %al,(%rdx)
    6be5:	c3                   	ret
    6be6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bed:	00 00 00 
    6bf0:	66 85 c0             	test   %ax,%ax
    6bf3:	74 dc                	je     6bd1 <fwp_closure_drop+0x61>
    6bf5:	c3                   	ret
    6bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bfd:	00 00 00 
    6c00:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6c07:	ff ff 
    6c09:	48 85 c0             	test   %rax,%rax
    6c0c:	74 12                	je     6c20 <fwp_closure_drop+0xb0>
    6c0e:	48 89 fe             	mov    %rdi,%rsi
    6c11:	48 89 c7             	mov    %rax,%rdi
    6c14:	e9 e7 d5 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c20:	e9 8b d7 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6c25:	0f 1f 00             	nopl   (%rax)
    6c28:	48 89 d0             	mov    %rdx,%rax
    6c2b:	48 8d 35 4e cb 01 00 	lea    0x1cb4e(%rip),%rsi        # 23780 <fwp_heap>
    6c32:	48 83 ec 18          	sub    $0x18,%rsp
    6c36:	48 c1 e8 11          	shr    $0x11,%rax
    6c3a:	48 31 d0             	xor    %rdx,%rax
    6c3d:	48 89 c1             	mov    %rax,%rcx
    6c40:	48 c1 e9 09          	shr    $0x9,%rcx
    6c44:	48 31 c8             	xor    %rcx,%rax
    6c47:	0f b6 c8             	movzbl %al,%ecx
    6c4a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6c51:	00 
    6c52:	48 85 c0             	test   %rax,%rax
    6c55:	75 12                	jne    6c69 <fwp_closure_drop+0xf9>
    6c57:	eb 49                	jmp    6ca2 <fwp_closure_drop+0x132>
    6c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c64:	48 85 c0             	test   %rax,%rax
    6c67:	74 39                	je     6ca2 <fwp_closure_drop+0x132>
    6c69:	48 89 c1             	mov    %rax,%rcx
    6c6c:	48 39 10             	cmp    %rdx,(%rax)
    6c6f:	75 ef                	jne    6c60 <fwp_closure_drop+0xf0>
    6c71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6c84:	74 05                	je     6c8b <fwp_closure_drop+0x11b>
    6c86:	48 83 c4 18          	add    $0x18,%rsp
    6c8a:	c3                   	ret
    6c8b:	48 89 d7             	mov    %rdx,%rdi
    6c8e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c93:	e8 78 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6c98:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c9d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6ca0:	eb e4                	jmp    6c86 <fwp_closure_drop+0x116>
    6ca2:	48 8d 3d ef 8a 00 00 	lea    0x8aef(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6ca9:	e8 f2 d4 ff ff       	call   41a0 <fwp_trap>
    6cae:	66 90                	xchg   %ax,%ax

0000000000006cb0 <fwp_owned_tape_release>:
    6cb0:	48 85 ff             	test   %rdi,%rdi
    6cb3:	0f 84 f7 00 00 00    	je     6db0 <fwp_owned_tape_release+0x100>
    6cb9:	41 54                	push   %r12
    6cbb:	55                   	push   %rbp
    6cbc:	53                   	push   %rbx
    6cbd:	48 8b 07             	mov    (%rdi),%rax
    6cc0:	48 85 c0             	test   %rax,%rax
    6cc3:	74 08                	je     6ccd <fwp_owned_tape_release+0x1d>
    6cc5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6cc9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ccd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6cd1:	48 85 d2             	test   %rdx,%rdx
    6cd4:	74 03                	je     6cd9 <fwp_owned_tape_release+0x29>
    6cd6:	48 89 02             	mov    %rax,(%rdx)
    6cd9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6cdd:	48 89 fb             	mov    %rdi,%rbx
    6ce0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ce4:	48 85 c0             	test   %rax,%rax
    6ce7:	0f 84 89 00 00 00    	je     6d76 <fwp_owned_tape_release+0xc6>
    6ced:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6cf1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6cf5:	7e 47                	jle    6d3e <fwp_owned_tape_release+0x8e>
    6cf7:	31 ed                	xor    %ebp,%ebp
    6cf9:	eb 0d                	jmp    6d08 <fwp_owned_tape_release+0x58>
    6cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6d08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6d0c:	49 89 ec             	mov    %rbp,%r12
    6d0f:	48 83 c5 01          	add    $0x1,%rbp
    6d13:	49 c1 e4 04          	shl    $0x4,%r12
    6d17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6d1b:	ff d0                	call   *%rax
    6d1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6d21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6d26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d2a:	ff 50 68             	call   *0x68(%rax)
    6d2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6d31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6d35:	48 39 e8             	cmp    %rbp,%rax
    6d38:	7f c6                	jg     6d00 <fwp_owned_tape_release+0x50>
    6d3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d3e:	31 ed                	xor    %ebp,%ebp
    6d40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6d45:	7e 28                	jle    6d6f <fwp_owned_tape_release+0xbf>
    6d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d4e:	00 00 
    6d50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6d54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6d58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6d5c:	74 07                	je     6d65 <fwp_owned_tape_release+0xb5>
    6d5e:	ff 52 68             	call   *0x68(%rdx)
    6d61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d65:	48 83 c5 01          	add    $0x1,%rbp
    6d69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6d6d:	7f e1                	jg     6d50 <fwp_owned_tape_release+0xa0>
    6d6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d73:	ff 52 68             	call   *0x68(%rdx)
    6d76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6d7a:	e8 f1 fd ff ff       	call   6b70 <fwp_closure_drop>
    6d7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6d83:	e8 e8 fd ff ff       	call   6b70 <fwp_closure_drop>
    6d88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6d8c:	e8 df fd ff ff       	call   6b70 <fwp_closure_drop>
    6d91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6d95:	e8 b6 e7 ff ff       	call   5550 <fwp_mem_free>
    6d9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6d9e:	e8 ad e7 ff ff       	call   5550 <fwp_mem_free>
    6da3:	48 89 df             	mov    %rbx,%rdi
    6da6:	5b                   	pop    %rbx
    6da7:	5d                   	pop    %rbp
    6da8:	41 5c                	pop    %r12
    6daa:	e9 a1 e7 ff ff       	jmp    5550 <fwp_mem_free>
    6daf:	90                   	nop
    6db0:	c3                   	ret
    6db1:	0f 1f 40 00          	nopl   0x0(%rax)
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 

0000000000006dc0 <fwp_tape_finish>:
    6dc0:	f3 0f 1e fa          	endbr64
    6dc4:	41 56                	push   %r14
    6dc6:	48 8d 3d f3 c2 01 00 	lea    0x1c2f3(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    6dcd:	41 55                	push   %r13
    6dcf:	41 54                	push   %r12
    6dd1:	55                   	push   %rbp
    6dd2:	53                   	push   %rbx
    6dd3:	e8 98 d1 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6dd8:	48 83 3d 28 c3 01 00 	cmpq   $0x0,0x1c328(%rip)        # 23108 <fwp_ntapes>
    6ddf:	00 
    6de0:	48 c7 05 bd c2 01 00 	movq   $0x0,0x1c2bd(%rip)        # 230a8 <fwp_tape_cached_bytes>
    6de7:	00 00 00 00 
    6deb:	7e 68                	jle    6e55 <fwp_tape_finish+0x95>
    6ded:	45 31 e4             	xor    %r12d,%r12d
    6df0:	31 ed                	xor    %ebp,%ebp
    6df2:	0f 1f 00             	nopl   (%rax)
    6df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dfc:	00 00 00 00 
    6e00:	48 8b 1d 09 c3 01 00 	mov    0x1c309(%rip),%rbx        # 23110 <fwp_tapes>
    6e07:	48 83 c5 01          	add    $0x1,%rbp
    6e0b:	4c 01 e3             	add    %r12,%rbx
    6e0e:	49 83 c4 68          	add    $0x68,%r12
    6e12:	48 89 df             	mov    %rbx,%rdi
    6e15:	e8 e6 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6e1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6e1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6e26:	e8 95 c5 ff ff       	call   33c0 <free@plt>
    6e2b:	4c 89 f7             	mov    %r14,%rdi
    6e2e:	e8 8d c5 ff ff       	call   33c0 <free@plt>
    6e33:	4c 89 ef             	mov    %r13,%rdi
    6e36:	e8 85 c5 ff ff       	call   33c0 <free@plt>
    6e3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6e3f:	e8 6c fe ff ff       	call   6cb0 <fwp_owned_tape_release>
    6e44:	48 39 2d bd c2 01 00 	cmp    %rbp,0x1c2bd(%rip)        # 23108 <fwp_ntapes>
    6e4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6e52:	00 
    6e53:	7f ab                	jg     6e00 <fwp_tape_finish+0x40>
    6e55:	48 8b 3d b4 c2 01 00 	mov    0x1c2b4(%rip),%rdi        # 23110 <fwp_tapes>
    6e5c:	e8 5f c5 ff ff       	call   33c0 <free@plt>
    6e61:	5b                   	pop    %rbx
    6e62:	5d                   	pop    %rbp
    6e63:	48 c7 05 a2 c2 01 00 	movq   $0x0,0x1c2a2(%rip)        # 23110 <fwp_tapes>
    6e6a:	00 00 00 00 
    6e6e:	48 c7 05 87 c2 01 00 	movq   $0x0,0x1c287(%rip)        # 23100 <fwp_tapes_cap>
    6e75:	00 00 00 00 
    6e79:	41 5c                	pop    %r12
    6e7b:	48 c7 05 82 c2 01 00 	movq   $0x0,0x1c282(%rip)        # 23108 <fwp_ntapes>
    6e82:	00 00 00 00 
    6e86:	41 5d                	pop    %r13
    6e88:	48 c7 05 65 c2 01 00 	movq   $0x0,0x1c265(%rip)        # 230f8 <fwp_tape_next_slot>
    6e8f:	00 00 00 00 
    6e93:	41 5e                	pop    %r14
    6e95:	c3                   	ret
    6e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e9d:	00 00 00 

0000000000006ea0 <fwp_tape_scope_release>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	41 55                	push   %r13
    6ea6:	41 54                	push   %r12
    6ea8:	55                   	push   %rbp
    6ea9:	53                   	push   %rbx
    6eaa:	48 83 ec 58          	sub    $0x58,%rsp
    6eae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6eb5:	00 00 
    6eb7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6ebc:	48 63 07             	movslq (%rdi),%rax
    6ebf:	85 c0                	test   %eax,%eax
    6ec1:	0f 88 05 01 00 00    	js     6fcc <fwp_tape_scope_release+0x12c>
    6ec7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6ece:	ec c4 4e 
    6ed1:	48 89 fb             	mov    %rdi,%rbx
    6ed4:	eb 3c                	jmp    6f12 <fwp_tape_scope_release+0x72>
    6ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6edd:	00 00 00 
    6ee0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6ee5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6ee9:	e8 d2 c4 ff ff       	call   33c0 <free@plt>
    6eee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6ef2:	e8 c9 c4 ff ff       	call   33c0 <free@plt>
    6ef7:	4c 89 ef             	mov    %r13,%rdi
    6efa:	e8 c1 c4 ff ff       	call   33c0 <free@plt>
    6eff:	4c 89 e7             	mov    %r12,%rdi
    6f02:	e8 a9 fd ff ff       	call   6cb0 <fwp_owned_tape_release>
    6f07:	48 63 03             	movslq (%rbx),%rax
    6f0a:	85 c0                	test   %eax,%eax
    6f0c:	0f 88 ba 00 00 00    	js     6fcc <fwp_tape_scope_release+0x12c>
    6f12:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6f16:	48 8b 35 f3 c1 01 00 	mov    0x1c1f3(%rip),%rsi        # 23110 <fwp_tapes>
    6f1d:	4c 01 c6             	add    %r8,%rsi
    6f20:	48 89 f7             	mov    %rsi,%rdi
    6f23:	e8 d8 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6f28:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6f2d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6f32:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6f39:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6f3d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6f41:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6f48:	00 
    6f49:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6f4e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6f52:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6f57:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6f5b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6f60:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6f67:	00 
    6f68:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6f6f:	00 
    6f70:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6f77:	00 
    6f78:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6f7d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6f82:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6f86:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6f8a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6f8e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6f94:	77 18                	ja     6fae <fwp_tape_scope_release+0x10e>
    6f96:	49 c1 f8 03          	sar    $0x3,%r8
    6f9a:	4c 0f af c5          	imul   %rbp,%r8
    6f9e:	4c 3b 05 53 c1 01 00 	cmp    0x1c153(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    6fa5:	7d 07                	jge    6fae <fwp_tape_scope_release+0x10e>
    6fa7:	4c 89 05 4a c1 01 00 	mov    %r8,0x1c14a(%rip)        # 230f8 <fwp_tape_next_slot>
    6fae:	4d 85 e4             	test   %r12,%r12
    6fb1:	0f 85 29 ff ff ff    	jne    6ee0 <fwp_tape_scope_release+0x40>
    6fb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6fbc:	e8 6f de ff ff       	call   4e30 <fwp_tape_buffers_release>
    6fc1:	48 63 03             	movslq (%rbx),%rax
    6fc4:	85 c0                	test   %eax,%eax
    6fc6:	0f 89 46 ff ff ff    	jns    6f12 <fwp_tape_scope_release+0x72>
    6fcc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6fd1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6fd8:	00 00 
    6fda:	75 0b                	jne    6fe7 <fwp_tape_scope_release+0x147>
    6fdc:	48 83 c4 58          	add    $0x58,%rsp
    6fe0:	5b                   	pop    %rbx
    6fe1:	5d                   	pop    %rbp
    6fe2:	41 5c                	pop    %r12
    6fe4:	41 5d                	pop    %r13
    6fe6:	c3                   	ret
    6fe7:	e8 74 c4 ff ff       	call   3460 <__stack_chk_fail@plt>
    6fec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006ff0 <fwp_task_dispose>:
    6ff0:	53                   	push   %rbx
    6ff1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6ff5:	0f 84 4b c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6ffb:	48 89 fb             	mov    %rdi,%rbx
    6ffe:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7003:	0f 85 3d c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7009:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    700d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7014:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    701b:	00 
    701c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7020:	48 85 ff             	test   %rdi,%rdi
    7023:	74 07                	je     702c <fwp_task_dispose+0x3c>
    7025:	48 85 c0             	test   %rax,%rax
    7028:	74 02                	je     702c <fwp_task_dispose+0x3c>
    702a:	ff d0                	call   *%rax
    702c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7033:	e8 18 e5 ff ff       	call   5550 <fwp_mem_free>
    7038:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    703f:	00 00 00 00 
    7043:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7047:	74 6f                	je     70b8 <fwp_task_dispose+0xc8>
    7049:	48 8b 15 08 db 01 00 	mov    0x1db08(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7050:	48 89 d8             	mov    %rbx,%rax
    7053:	48 2b 05 d6 da 01 00 	sub    0x1dad6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    705a:	48 c1 e2 10          	shl    $0x10,%rdx
    705e:	48 39 d0             	cmp    %rdx,%rax
    7061:	73 4c                	jae    70af <fwp_task_dispose+0xbf>
    7063:	48 89 c2             	mov    %rax,%rdx
    7066:	48 c1 ea 10          	shr    $0x10,%rdx
    706a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    706e:	48 8b 15 03 db 01 00 	mov    0x1db03(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7075:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7079:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    707d:	48 85 c9             	test   %rcx,%rcx
    7080:	74 2d                	je     70af <fwp_task_dispose+0xbf>
    7082:	0f b6 32             	movzbl (%rdx),%esi
    7085:	40 80 fe 02          	cmp    $0x2,%sil
    7089:	74 3d                	je     70c8 <fwp_task_dispose+0xd8>
    708b:	40 80 fe 01          	cmp    $0x1,%sil
    708f:	75 1e                	jne    70af <fwp_task_dispose+0xbf>
    7091:	8b 72 18             	mov    0x18(%rdx),%esi
    7094:	0f b7 c0             	movzwl %ax,%eax
    7097:	8b 52 1c             	mov    0x1c(%rdx),%edx
    709a:	48 0f af c6          	imul   %rsi,%rax
    709e:	48 c1 e8 20          	shr    $0x20,%rax
    70a2:	48 39 d0             	cmp    %rdx,%rax
    70a5:	73 08                	jae    70af <fwp_task_dispose+0xbf>
    70a7:	48 01 c1             	add    %rax,%rcx
    70aa:	80 39 01             	cmpb   $0x1,(%rcx)
    70ad:	74 09                	je     70b8 <fwp_task_dispose+0xc8>
    70af:	5b                   	pop    %rbx
    70b0:	c3                   	ret
    70b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70b8:	48 89 df             	mov    %rbx,%rdi
    70bb:	5b                   	pop    %rbx
    70bc:	e9 8f e4 ff ff       	jmp    5550 <fwp_mem_free>
    70c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70c8:	66 85 c0             	test   %ax,%ax
    70cb:	74 dd                	je     70aa <fwp_task_dispose+0xba>
    70cd:	5b                   	pop    %rbx
    70ce:	c3                   	ret
    70cf:	90                   	nop

00000000000070d0 <fwp_free_zombie>:
    70d0:	48 8b 15 79 c6 01 00 	mov    0x1c679(%rip),%rdx        # 23750 <fwp_zombie>
    70d7:	48 85 d2             	test   %rdx,%rdx
    70da:	0f 84 98 00 00 00    	je     7178 <fwp_free_zombie+0xa8>
    70e0:	48 3b 15 79 c6 01 00 	cmp    0x1c679(%rip),%rdx        # 23760 <fwp_cur>
    70e7:	0f 84 8b 00 00 00    	je     7178 <fwp_free_zombie+0xa8>
    70ed:	48 83 ec 18          	sub    $0x18,%rsp
    70f1:	48 63 05 34 c0 01 00 	movslq 0x1c034(%rip),%rax        # 2312c <fwp_stack_pool_n>
    70f8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    70fc:	83 f8 3f             	cmp    $0x3f,%eax
    70ff:	7f 7f                	jg     7180 <fwp_free_zombie+0xb0>
    7101:	8d 48 01             	lea    0x1(%rax),%ecx
    7104:	89 0d 22 c0 01 00    	mov    %ecx,0x1c022(%rip)        # 2312c <fwp_stack_pool_n>
    710a:	48 8d 0d 2f c0 01 00 	lea    0x1c02f(%rip),%rcx        # 23140 <fwp_stack_pool>
    7111:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7115:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    711c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7120:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7127:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    712b:	48 85 c9             	test   %rcx,%rcx
    712e:	0f 84 fc 00 00 00    	je     7230 <fwp_free_zombie+0x160>
    7134:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    713b:	48 85 c0             	test   %rax,%rax
    713e:	74 07                	je     7147 <fwp_free_zombie+0x77>
    7140:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7147:	8b 42 5c             	mov    0x5c(%rdx),%eax
    714a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    714e:	48 c7 05 f7 c5 01 00 	movq   $0x0,0x1c5f7(%rip)        # 23750 <fwp_zombie>
    7155:	00 00 00 00 
    7159:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7160:	85 c0                	test   %eax,%eax
    7162:	74 34                	je     7198 <fwp_free_zombie+0xc8>
    7164:	83 f8 01             	cmp    $0x1,%eax
    7167:	0f 84 b3 00 00 00    	je     7220 <fwp_free_zombie+0x150>
    716d:	48 83 c4 18          	add    $0x18,%rsp
    7171:	c3                   	ret
    7172:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7178:	c3                   	ret
    7179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7180:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7184:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7189:	e8 52 c4 ff ff       	call   35e0 <munmap@plt>
    718e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7193:	eb 80                	jmp    7115 <fwp_free_zombie+0x45>
    7195:	0f 1f 00             	nopl   (%rax)
    7198:	48 8b 0d b9 d9 01 00 	mov    0x1d9b9(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    719f:	48 89 d0             	mov    %rdx,%rax
    71a2:	48 2b 05 87 d9 01 00 	sub    0x1d987(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    71a9:	48 c1 e1 10          	shl    $0x10,%rcx
    71ad:	48 39 c8             	cmp    %rcx,%rax
    71b0:	73 bb                	jae    716d <fwp_free_zombie+0x9d>
    71b2:	48 89 c1             	mov    %rax,%rcx
    71b5:	48 c1 e9 10          	shr    $0x10,%rcx
    71b9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    71bd:	48 8b 0d b4 d9 01 00 	mov    0x1d9b4(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    71c4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    71c8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71cc:	48 85 c9             	test   %rcx,%rcx
    71cf:	74 9c                	je     716d <fwp_free_zombie+0x9d>
    71d1:	0f b6 3e             	movzbl (%rsi),%edi
    71d4:	40 80 ff 02          	cmp    $0x2,%dil
    71d8:	74 66                	je     7240 <fwp_free_zombie+0x170>
    71da:	40 80 ff 01          	cmp    $0x1,%dil
    71de:	75 8d                	jne    716d <fwp_free_zombie+0x9d>
    71e0:	8b 7e 18             	mov    0x18(%rsi),%edi
    71e3:	0f b7 c0             	movzwl %ax,%eax
    71e6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71e9:	48 0f af c7          	imul   %rdi,%rax
    71ed:	48 c1 e8 20          	shr    $0x20,%rax
    71f1:	48 39 f0             	cmp    %rsi,%rax
    71f4:	0f 83 73 ff ff ff    	jae    716d <fwp_free_zombie+0x9d>
    71fa:	48 01 c1             	add    %rax,%rcx
    71fd:	0f b6 01             	movzbl (%rcx),%eax
    7200:	84 c0                	test   %al,%al
    7202:	0f 84 65 ff ff ff    	je     716d <fwp_free_zombie+0x9d>
    7208:	3c 01                	cmp    $0x1,%al
    720a:	74 14                	je     7220 <fwp_free_zombie+0x150>
    720c:	3c ff                	cmp    $0xff,%al
    720e:	74 3b                	je     724b <fwp_free_zombie+0x17b>
    7210:	83 e8 01             	sub    $0x1,%eax
    7213:	88 01                	mov    %al,(%rcx)
    7215:	e9 53 ff ff ff       	jmp    716d <fwp_free_zombie+0x9d>
    721a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7220:	48 89 d7             	mov    %rdx,%rdi
    7223:	48 83 c4 18          	add    $0x18,%rsp
    7227:	e9 c4 fd ff ff       	jmp    6ff0 <fwp_task_dispose>
    722c:	0f 1f 40 00          	nopl   0x0(%rax)
    7230:	48 89 05 f1 c4 01 00 	mov    %rax,0x1c4f1(%rip)        # 23728 <fwp_tasks_active>
    7237:	e9 ff fe ff ff       	jmp    713b <fwp_free_zombie+0x6b>
    723c:	0f 1f 40 00          	nopl   0x0(%rax)
    7240:	66 85 c0             	test   %ax,%ax
    7243:	0f 85 24 ff ff ff    	jne    716d <fwp_free_zombie+0x9d>
    7249:	eb b2                	jmp    71fd <fwp_free_zombie+0x12d>
    724b:	48 89 ca             	mov    %rcx,%rdx
    724e:	48 8d 35 2b c5 01 00 	lea    0x1c52b(%rip),%rsi        # 23780 <fwp_heap>
    7255:	48 c1 ea 11          	shr    $0x11,%rdx
    7259:	48 31 ca             	xor    %rcx,%rdx
    725c:	48 89 d0             	mov    %rdx,%rax
    725f:	48 c1 e8 09          	shr    $0x9,%rax
    7263:	48 31 c2             	xor    %rax,%rdx
    7266:	0f b6 d2             	movzbl %dl,%edx
    7269:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7270:	00 
    7271:	48 85 c0             	test   %rax,%rax
    7274:	75 13                	jne    7289 <fwp_free_zombie+0x1b9>
    7276:	eb 4c                	jmp    72c4 <fwp_free_zombie+0x1f4>
    7278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    727f:	00 
    7280:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7284:	48 85 c0             	test   %rax,%rax
    7287:	74 3b                	je     72c4 <fwp_free_zombie+0x1f4>
    7289:	48 89 c2             	mov    %rax,%rdx
    728c:	48 39 08             	cmp    %rcx,(%rax)
    728f:	75 ef                	jne    7280 <fwp_free_zombie+0x1b0>
    7291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7295:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7299:	48 89 50 08          	mov    %rdx,0x8(%rax)
    729d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72a4:	0f 85 c3 fe ff ff    	jne    716d <fwp_free_zombie+0x9d>
    72aa:	48 89 cf             	mov    %rcx,%rdi
    72ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    72b2:	e8 59 e0 ff ff       	call   5310 <fwp_rc_forget_slot>
    72b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    72bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    72bf:	e9 a9 fe ff ff       	jmp    716d <fwp_free_zombie+0x9d>
    72c4:	48 8d 3d cd 84 00 00 	lea    0x84cd(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    72cb:	e8 d0 ce ff ff       	call   41a0 <fwp_trap>

00000000000072d0 <fwp_block>:
    72d0:	48 83 ec 08          	sub    $0x8,%rsp
    72d4:	48 8b 05 6d c4 01 00 	mov    0x1c46d(%rip),%rax        # 23748 <fwp_ready_head>
    72db:	48 85 c0             	test   %rax,%rax
    72de:	0f 84 1c 01 00 00    	je     7400 <fwp_block+0x130>
    72e4:	90                   	nop
    72e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72ec:	00 00 00 00 
    72f0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    72f7:	48 89 15 4a c4 01 00 	mov    %rdx,0x1c44a(%rip)        # 23748 <fwp_ready_head>
    72fe:	48 85 d2             	test   %rdx,%rdx
    7301:	0f 84 19 01 00 00    	je     7420 <fwp_block+0x150>
    7307:	48 8b 15 52 c4 01 00 	mov    0x1c452(%rip),%rdx        # 23760 <fwp_cur>
    730e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7312:	48 39 c2             	cmp    %rax,%rdx
    7315:	0f 84 d5 00 00 00    	je     73f0 <fwp_block+0x120>
    731b:	48 8b 0d c6 e0 01 00 	mov    0x1e0c6(%rip),%rcx        # 253e8 <fwp_state_owners>
    7322:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7326:	48 89 05 33 c4 01 00 	mov    %rax,0x1c433(%rip)        # 23760 <fwp_cur>
    732d:	f3 0f 7e 05 db e0 01 	movq   0x1e0db(%rip),%xmm0        # 25410 <fwp_foreign_callbacks>
    7334:	00 
    7335:	0f 16 05 c4 e0 01 00 	movhps 0x1e0c4(%rip),%xmm0        # 25400 <fwp_state>
    733c:	f3 0f 7e 0d c4 e0 01 	movq   0x1e0c4(%rip),%xmm1        # 25408 <fwp_handlers>
    7343:	00 
    7344:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    734b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7352:	0f 16 0d bf e0 01 00 	movhps 0x1e0bf(%rip),%xmm1        # 25418 <fwp_cleanups>
    7359:	f3 0f 7e 05 97 e0 01 	movq   0x1e097(%rip),%xmm0        # 253f8 <fwp_state_len>
    7360:	00 
    7361:	0f 16 05 88 e0 01 00 	movhps 0x1e088(%rip),%xmm0        # 253f0 <fwp_state_cap>
    7368:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    736f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7376:	48 8b 70 08          	mov    0x8(%rax),%rsi
    737a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7381:	48 89 0d 80 e0 01 00 	mov    %rcx,0x1e080(%rip)        # 25408 <fwp_handlers>
    7388:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    738f:	48 89 0d 82 e0 01 00 	mov    %rcx,0x1e082(%rip)        # 25418 <fwp_cleanups>
    7396:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    739d:	48 89 0d 6c e0 01 00 	mov    %rcx,0x1e06c(%rip)        # 25410 <fwp_foreign_callbacks>
    73a4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    73ab:	48 89 0d 4e e0 01 00 	mov    %rcx,0x1e04e(%rip)        # 25400 <fwp_state>
    73b2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    73b9:	48 89 0d 38 e0 01 00 	mov    %rcx,0x1e038(%rip)        # 253f8 <fwp_state_len>
    73c0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    73c7:	48 89 0d 22 e0 01 00 	mov    %rcx,0x1e022(%rip)        # 253f0 <fwp_state_cap>
    73ce:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    73d5:	48 89 0d 0c e0 01 00 	mov    %rcx,0x1e00c(%rip)        # 253e8 <fwp_state_owners>
    73dc:	e8 af c0 ff ff       	call   3490 <swapcontext@plt>
    73e1:	f3 0f 1e fa          	endbr64
    73e5:	e8 e6 fc ff ff       	call   70d0 <fwp_free_zombie>
    73ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73f0:	8b 05 32 bd 01 00    	mov    0x1bd32(%rip),%eax        # 23128 <fwp_slice>
    73f6:	85 c0                	test   %eax,%eax
    73f8:	74 36                	je     7430 <fwp_block+0x160>
    73fa:	48 83 c4 08          	add    $0x8,%rsp
    73fe:	c3                   	ret
    73ff:	90                   	nop
    7400:	e8 5b db ff ff       	call   4f60 <fwp_poll_events>
    7405:	48 8b 05 3c c3 01 00 	mov    0x1c33c(%rip),%rax        # 23748 <fwp_ready_head>
    740c:	48 85 c0             	test   %rax,%rax
    740f:	0f 85 db fe ff ff    	jne    72f0 <fwp_block+0x20>
    7415:	eb e9                	jmp    7400 <fwp_block+0x130>
    7417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    741e:	00 00 
    7420:	48 c7 05 15 c3 01 00 	movq   $0x0,0x1c315(%rip)        # 23740 <fwp_ready_tail>
    7427:	00 00 00 00 
    742b:	e9 d7 fe ff ff       	jmp    7307 <fwp_block+0x37>
    7430:	48 8d 3d ea 7c 00 00 	lea    0x7cea(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    7437:	e8 64 bf ff ff       	call   33a0 <getenv@plt>
    743c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7441:	48 85 c0             	test   %rax,%rax
    7444:	74 05                	je     744b <fwp_block+0x17b>
    7446:	80 38 00             	cmpb   $0x0,(%rax)
    7449:	75 0b                	jne    7456 <fwp_block+0x186>
    744b:	89 15 d7 bc 01 00    	mov    %edx,0x1bcd7(%rip)        # 23128 <fwp_slice>
    7451:	48 83 c4 08          	add    $0x8,%rsp
    7455:	c3                   	ret
    7456:	ba 0a 00 00 00       	mov    $0xa,%edx
    745b:	31 f6                	xor    %esi,%esi
    745d:	48 89 c7             	mov    %rax,%rdi
    7460:	e8 eb c0 ff ff       	call   3550 <strtoll@plt>
    7465:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7469:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7470:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7475:	0f 46 d0             	cmovbe %eax,%edx
    7478:	eb d1                	jmp    744b <fwp_block+0x17b>
    747a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007480 <fwp_drop4>:
    7480:	48 8b 15 d1 d6 01 00 	mov    0x1d6d1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7487:	48 89 f8             	mov    %rdi,%rax
    748a:	48 2b 05 9f d6 01 00 	sub    0x1d69f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7491:	48 c1 e2 10          	shl    $0x10,%rdx
    7495:	48 39 d0             	cmp    %rdx,%rax
    7498:	0f 83 52 01 00 00    	jae    75f0 <fwp_drop4+0x170>
    749e:	48 83 ec 18          	sub    $0x18,%rsp
    74a2:	4c 8d 05 d7 c2 01 00 	lea    0x1c2d7(%rip),%r8        # 23780 <fwp_heap>
    74a9:	48 89 c2             	mov    %rax,%rdx
    74ac:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    74b3:	48 c1 ea 10          	shr    $0x10,%rdx
    74b7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    74bb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    74bf:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    74c3:	48 85 d2             	test   %rdx,%rdx
    74c6:	74 46                	je     750e <fwp_drop4+0x8e>
    74c8:	44 0f b6 09          	movzbl (%rcx),%r9d
    74cc:	41 80 f9 02          	cmp    $0x2,%r9b
    74d0:	0f 84 ca 00 00 00    	je     75a0 <fwp_drop4+0x120>
    74d6:	41 80 f9 01          	cmp    $0x1,%r9b
    74da:	75 32                	jne    750e <fwp_drop4+0x8e>
    74dc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    74e0:	0f b7 c0             	movzwl %ax,%eax
    74e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    74e6:	49 0f af c1          	imul   %r9,%rax
    74ea:	48 c1 e8 20          	shr    $0x20,%rax
    74ee:	48 39 c8             	cmp    %rcx,%rax
    74f1:	73 1b                	jae    750e <fwp_drop4+0x8e>
    74f3:	48 01 c2             	add    %rax,%rdx
    74f6:	0f b6 02             	movzbl (%rdx),%eax
    74f9:	84 c0                	test   %al,%al
    74fb:	74 11                	je     750e <fwp_drop4+0x8e>
    74fd:	3c 01                	cmp    $0x1,%al
    74ff:	74 17                	je     7518 <fwp_drop4+0x98>
    7501:	3c ff                	cmp    $0xff,%al
    7503:	0f 84 ef 00 00 00    	je     75f8 <fwp_drop4+0x178>
    7509:	83 e8 01             	sub    $0x1,%eax
    750c:	88 02                	mov    %al,(%rdx)
    750e:	48 83 c4 18          	add    $0x18,%rsp
    7512:	c3                   	ret
    7513:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7518:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    751c:	0f 88 8e 00 00 00    	js     75b0 <fwp_drop4+0x130>
    7522:	48 8b 15 2f d6 01 00 	mov    0x1d62f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7529:	48 89 f8             	mov    %rdi,%rax
    752c:	48 2b 05 fd d5 01 00 	sub    0x1d5fd(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7533:	48 c1 e2 10          	shl    $0x10,%rdx
    7537:	48 39 d0             	cmp    %rdx,%rax
    753a:	73 d2                	jae    750e <fwp_drop4+0x8e>
    753c:	48 89 c2             	mov    %rax,%rdx
    753f:	48 c1 ea 10          	shr    $0x10,%rdx
    7543:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7547:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    754b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    754f:	48 85 c9             	test   %rcx,%rcx
    7552:	74 ba                	je     750e <fwp_drop4+0x8e>
    7554:	0f b6 32             	movzbl (%rdx),%esi
    7557:	40 80 fe 02          	cmp    $0x2,%sil
    755b:	74 33                	je     7590 <fwp_drop4+0x110>
    755d:	40 80 fe 01          	cmp    $0x1,%sil
    7561:	75 ab                	jne    750e <fwp_drop4+0x8e>
    7563:	8b 72 18             	mov    0x18(%rdx),%esi
    7566:	0f b7 c0             	movzwl %ax,%eax
    7569:	8b 52 1c             	mov    0x1c(%rdx),%edx
    756c:	48 0f af c6          	imul   %rsi,%rax
    7570:	48 c1 e8 20          	shr    $0x20,%rax
    7574:	48 39 d0             	cmp    %rdx,%rax
    7577:	73 95                	jae    750e <fwp_drop4+0x8e>
    7579:	48 01 c1             	add    %rax,%rcx
    757c:	80 39 01             	cmpb   $0x1,(%rcx)
    757f:	75 8d                	jne    750e <fwp_drop4+0x8e>
    7581:	48 83 c4 18          	add    $0x18,%rsp
    7585:	e9 c6 df ff ff       	jmp    5550 <fwp_mem_free>
    758a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7590:	66 85 c0             	test   %ax,%ax
    7593:	74 e7                	je     757c <fwp_drop4+0xfc>
    7595:	48 83 c4 18          	add    $0x18,%rsp
    7599:	c3                   	ret
    759a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75a0:	66 85 c0             	test   %ax,%ax
    75a3:	0f 84 4d ff ff ff    	je     74f6 <fwp_drop4+0x76>
    75a9:	48 83 c4 18          	add    $0x18,%rsp
    75ad:	c3                   	ret
    75ae:	66 90                	xchg   %ax,%ax
    75b0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    75b4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    75b9:	e8 c2 ef ff ff       	call   6580 <fwp_rc_free_arr>
    75be:	4c 8d 05 bb c1 01 00 	lea    0x1c1bb(%rip),%r8        # 23780 <fwp_heap>
    75c5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    75ca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    75d1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    75d8:	48 c1 e2 10          	shl    $0x10,%rdx
    75dc:	48 39 d0             	cmp    %rdx,%rax
    75df:	0f 83 29 ff ff ff    	jae    750e <fwp_drop4+0x8e>
    75e5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    75ea:	e9 ba fe ff ff       	jmp    74a9 <fwp_drop4+0x29>
    75ef:	90                   	nop
    75f0:	c3                   	ret
    75f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75f8:	48 89 d0             	mov    %rdx,%rax
    75fb:	48 c1 e8 11          	shr    $0x11,%rax
    75ff:	48 31 d0             	xor    %rdx,%rax
    7602:	48 89 c1             	mov    %rax,%rcx
    7605:	48 c1 e9 09          	shr    $0x9,%rcx
    7609:	48 31 c8             	xor    %rcx,%rax
    760c:	0f b6 c8             	movzbl %al,%ecx
    760f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7616:	00 
    7617:	48 85 c0             	test   %rax,%rax
    761a:	75 0d                	jne    7629 <fwp_drop4+0x1a9>
    761c:	eb 46                	jmp    7664 <fwp_drop4+0x1e4>
    761e:	66 90                	xchg   %ax,%ax
    7620:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7624:	48 85 c0             	test   %rax,%rax
    7627:	74 3b                	je     7664 <fwp_drop4+0x1e4>
    7629:	48 89 c1             	mov    %rax,%rcx
    762c:	48 39 10             	cmp    %rdx,(%rax)
    762f:	75 ef                	jne    7620 <fwp_drop4+0x1a0>
    7631:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7635:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7639:	48 89 48 08          	mov    %rcx,0x8(%rax)
    763d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7644:	0f 85 c4 fe ff ff    	jne    750e <fwp_drop4+0x8e>
    764a:	48 89 d7             	mov    %rdx,%rdi
    764d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7652:	e8 b9 dc ff ff       	call   5310 <fwp_rc_forget_slot>
    7657:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    765c:	c6 02 fe             	movb   $0xfe,(%rdx)
    765f:	e9 aa fe ff ff       	jmp    750e <fwp_drop4+0x8e>
    7664:	48 8d 3d 2d 81 00 00 	lea    0x812d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    766b:	e8 30 cb ff ff       	call   41a0 <fwp_trap>

0000000000007670 <fwp_caps161>:
    7670:	f3 0f 1e fa          	endbr64
    7674:	85 f6                	test   %esi,%esi
    7676:	74 08                	je     7680 <fwp_caps161+0x10>
    7678:	c3                   	ret
    7679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7680:	48 8b 15 d1 d4 01 00 	mov    0x1d4d1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7687:	48 89 f8             	mov    %rdi,%rax
    768a:	48 2b 05 9f d4 01 00 	sub    0x1d49f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7691:	48 c1 e2 10          	shl    $0x10,%rdx
    7695:	48 39 d0             	cmp    %rdx,%rax
    7698:	73 de                	jae    7678 <fwp_caps161+0x8>
    769a:	48 89 c2             	mov    %rax,%rdx
    769d:	48 c1 ea 10          	shr    $0x10,%rdx
    76a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76a5:	48 8b 15 cc d4 01 00 	mov    0x1d4cc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    76ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76b0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    76b4:	48 85 c9             	test   %rcx,%rcx
    76b7:	74 bf                	je     7678 <fwp_caps161+0x8>
    76b9:	0f b6 32             	movzbl (%rdx),%esi
    76bc:	40 80 fe 02          	cmp    $0x2,%sil
    76c0:	74 2e                	je     76f0 <fwp_caps161+0x80>
    76c2:	40 80 fe 01          	cmp    $0x1,%sil
    76c6:	75 b0                	jne    7678 <fwp_caps161+0x8>
    76c8:	8b 72 18             	mov    0x18(%rdx),%esi
    76cb:	0f b7 c0             	movzwl %ax,%eax
    76ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76d1:	48 0f af c6          	imul   %rsi,%rax
    76d5:	48 c1 e8 20          	shr    $0x20,%rax
    76d9:	48 39 d0             	cmp    %rdx,%rax
    76dc:	73 9a                	jae    7678 <fwp_caps161+0x8>
    76de:	48 01 c1             	add    %rax,%rcx
    76e1:	80 39 01             	cmpb   $0x1,(%rcx)
    76e4:	75 92                	jne    7678 <fwp_caps161+0x8>
    76e6:	e9 65 de ff ff       	jmp    5550 <fwp_mem_free>
    76eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76f0:	66 85 c0             	test   %ax,%ax
    76f3:	74 ec                	je     76e1 <fwp_caps161+0x71>
    76f5:	c3                   	ret
    76f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    76fd:	00 00 00 

0000000000007700 <fwp_args12>:
    7700:	f3 0f 1e fa          	endbr64
    7704:	85 d2                	test   %edx,%edx
    7706:	74 04                	je     770c <fwp_args12+0xc>
    7708:	85 f6                	test   %esi,%esi
    770a:	74 04                	je     7710 <fwp_args12+0x10>
    770c:	c3                   	ret
    770d:	0f 1f 00             	nopl   (%rax)
    7710:	48 8b 15 41 d4 01 00 	mov    0x1d441(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7717:	48 8b 07             	mov    (%rdi),%rax
    771a:	48 2b 05 0f d4 01 00 	sub    0x1d40f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7721:	48 c1 e2 10          	shl    $0x10,%rdx
    7725:	48 39 d0             	cmp    %rdx,%rax
    7728:	73 e2                	jae    770c <fwp_args12+0xc>
    772a:	48 89 c2             	mov    %rax,%rdx
    772d:	48 c1 ea 10          	shr    $0x10,%rdx
    7731:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7735:	48 8b 15 3c d4 01 00 	mov    0x1d43c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    773c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7740:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7744:	48 85 ff             	test   %rdi,%rdi
    7747:	74 c3                	je     770c <fwp_args12+0xc>
    7749:	0f b6 0a             	movzbl (%rdx),%ecx
    774c:	80 f9 02             	cmp    $0x2,%cl
    774f:	74 2f                	je     7780 <fwp_args12+0x80>
    7751:	80 f9 01             	cmp    $0x1,%cl
    7754:	75 b6                	jne    770c <fwp_args12+0xc>
    7756:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7759:	0f b7 c0             	movzwl %ax,%eax
    775c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    775f:	48 0f af c1          	imul   %rcx,%rax
    7763:	48 c1 e8 20          	shr    $0x20,%rax
    7767:	48 39 d0             	cmp    %rdx,%rax
    776a:	73 a0                	jae    770c <fwp_args12+0xc>
    776c:	48 01 c7             	add    %rax,%rdi
    776f:	0f b6 07             	movzbl (%rdi),%eax
    7772:	84 c0                	test   %al,%al
    7774:	74 96                	je     770c <fwp_args12+0xc>
    7776:	3c fd                	cmp    $0xfd,%al
    7778:	77 0c                	ja     7786 <fwp_args12+0x86>
    777a:	83 c0 01             	add    $0x1,%eax
    777d:	88 07                	mov    %al,(%rdi)
    777f:	c3                   	ret
    7780:	66 85 c0             	test   %ax,%ax
    7783:	74 ea                	je     776f <fwp_args12+0x6f>
    7785:	c3                   	ret
    7786:	e9 65 da ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    778b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007790 <fwp_args23>:
    7790:	f3 0f 1e fa          	endbr64
    7794:	85 d2                	test   %edx,%edx
    7796:	74 04                	je     779c <fwp_args23+0xc>
    7798:	85 f6                	test   %esi,%esi
    779a:	74 04                	je     77a0 <fwp_args23+0x10>
    779c:	c3                   	ret
    779d:	0f 1f 00             	nopl   (%rax)
    77a0:	48 8b 15 b1 d3 01 00 	mov    0x1d3b1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    77a7:	48 8b 07             	mov    (%rdi),%rax
    77aa:	48 2b 05 7f d3 01 00 	sub    0x1d37f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    77b1:	48 c1 e2 10          	shl    $0x10,%rdx
    77b5:	48 39 d0             	cmp    %rdx,%rax
    77b8:	73 e2                	jae    779c <fwp_args23+0xc>
    77ba:	48 89 c2             	mov    %rax,%rdx
    77bd:	48 c1 ea 10          	shr    $0x10,%rdx
    77c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77c5:	48 8b 15 ac d3 01 00 	mov    0x1d3ac(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    77cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77d0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    77d4:	48 85 ff             	test   %rdi,%rdi
    77d7:	74 c3                	je     779c <fwp_args23+0xc>
    77d9:	0f b6 0a             	movzbl (%rdx),%ecx
    77dc:	80 f9 02             	cmp    $0x2,%cl
    77df:	74 2f                	je     7810 <fwp_args23+0x80>
    77e1:	80 f9 01             	cmp    $0x1,%cl
    77e4:	75 b6                	jne    779c <fwp_args23+0xc>
    77e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    77e9:	0f b7 c0             	movzwl %ax,%eax
    77ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77ef:	48 0f af c1          	imul   %rcx,%rax
    77f3:	48 c1 e8 20          	shr    $0x20,%rax
    77f7:	48 39 d0             	cmp    %rdx,%rax
    77fa:	73 a0                	jae    779c <fwp_args23+0xc>
    77fc:	48 01 c7             	add    %rax,%rdi
    77ff:	0f b6 07             	movzbl (%rdi),%eax
    7802:	84 c0                	test   %al,%al
    7804:	74 96                	je     779c <fwp_args23+0xc>
    7806:	3c fd                	cmp    $0xfd,%al
    7808:	77 0c                	ja     7816 <fwp_args23+0x86>
    780a:	83 c0 01             	add    $0x1,%eax
    780d:	88 07                	mov    %al,(%rdi)
    780f:	c3                   	ret
    7810:	66 85 c0             	test   %ax,%ax
    7813:	74 ea                	je     77ff <fwp_args23+0x6f>
    7815:	c3                   	ret
    7816:	e9 d5 d9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    781b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007820 <fwp_caps12>:
    7820:	f3 0f 1e fa          	endbr64
    7824:	48 83 ec 18          	sub    $0x18,%rsp
    7828:	8b 57 04             	mov    0x4(%rdi),%edx
    782b:	48 89 f8             	mov    %rdi,%rax
    782e:	85 d2                	test   %edx,%edx
    7830:	0f 84 9a 00 00 00    	je     78d0 <fwp_caps12+0xb0>
    7836:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    783a:	85 f6                	test   %esi,%esi
    783c:	0f 85 9e 00 00 00    	jne    78e0 <fwp_caps12+0xc0>
    7842:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7847:	e8 44 f0 ff ff       	call   6890 <fwp_drop0>
    784c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7851:	48 8b 0d 00 d3 01 00 	mov    0x1d300(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7858:	48 89 c2             	mov    %rax,%rdx
    785b:	48 2b 15 ce d2 01 00 	sub    0x1d2ce(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    7862:	48 c1 e1 10          	shl    $0x10,%rcx
    7866:	48 39 ca             	cmp    %rcx,%rdx
    7869:	73 6d                	jae    78d8 <fwp_caps12+0xb8>
    786b:	48 89 d1             	mov    %rdx,%rcx
    786e:	48 c1 e9 10          	shr    $0x10,%rcx
    7872:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7876:	48 8b 0d fb d2 01 00 	mov    0x1d2fb(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    787d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7881:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7885:	48 85 f6             	test   %rsi,%rsi
    7888:	74 4e                	je     78d8 <fwp_caps12+0xb8>
    788a:	0f b6 39             	movzbl (%rcx),%edi
    788d:	40 80 ff 02          	cmp    $0x2,%dil
    7891:	0f 84 b9 00 00 00    	je     7950 <fwp_caps12+0x130>
    7897:	40 80 ff 01          	cmp    $0x1,%dil
    789b:	75 3b                	jne    78d8 <fwp_caps12+0xb8>
    789d:	8b 79 18             	mov    0x18(%rcx),%edi
    78a0:	0f b7 d2             	movzwl %dx,%edx
    78a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    78a6:	48 0f af d7          	imul   %rdi,%rdx
    78aa:	48 c1 ea 20          	shr    $0x20,%rdx
    78ae:	48 39 ca             	cmp    %rcx,%rdx
    78b1:	73 25                	jae    78d8 <fwp_caps12+0xb8>
    78b3:	48 01 d6             	add    %rdx,%rsi
    78b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    78b9:	75 1d                	jne    78d8 <fwp_caps12+0xb8>
    78bb:	48 89 c7             	mov    %rax,%rdi
    78be:	48 83 c4 18          	add    $0x18,%rsp
    78c2:	e9 89 dc ff ff       	jmp    5550 <fwp_mem_free>
    78c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78ce:	00 00 
    78d0:	85 f6                	test   %esi,%esi
    78d2:	0f 84 79 ff ff ff    	je     7851 <fwp_caps12+0x31>
    78d8:	48 83 c4 18          	add    $0x18,%rsp
    78dc:	c3                   	ret
    78dd:	0f 1f 00             	nopl   (%rax)
    78e0:	48 8b 05 71 d2 01 00 	mov    0x1d271(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    78e7:	48 2b 3d 42 d2 01 00 	sub    0x1d242(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    78ee:	48 c1 e0 10          	shl    $0x10,%rax
    78f2:	48 39 c7             	cmp    %rax,%rdi
    78f5:	73 e1                	jae    78d8 <fwp_caps12+0xb8>
    78f7:	48 89 f8             	mov    %rdi,%rax
    78fa:	48 c1 e8 10          	shr    $0x10,%rax
    78fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7902:	48 8b 05 6f d2 01 00 	mov    0x1d26f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7909:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    790d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7911:	48 85 c0             	test   %rax,%rax
    7914:	74 c2                	je     78d8 <fwp_caps12+0xb8>
    7916:	0f b6 0a             	movzbl (%rdx),%ecx
    7919:	80 f9 02             	cmp    $0x2,%cl
    791c:	74 42                	je     7960 <fwp_caps12+0x140>
    791e:	80 f9 01             	cmp    $0x1,%cl
    7921:	75 b5                	jne    78d8 <fwp_caps12+0xb8>
    7923:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7926:	0f b7 ff             	movzwl %di,%edi
    7929:	8b 52 1c             	mov    0x1c(%rdx),%edx
    792c:	48 0f af f9          	imul   %rcx,%rdi
    7930:	48 c1 ef 20          	shr    $0x20,%rdi
    7934:	48 39 d7             	cmp    %rdx,%rdi
    7937:	73 9f                	jae    78d8 <fwp_caps12+0xb8>
    7939:	48 01 f8             	add    %rdi,%rax
    793c:	0f b6 10             	movzbl (%rax),%edx
    793f:	84 d2                	test   %dl,%dl
    7941:	74 95                	je     78d8 <fwp_caps12+0xb8>
    7943:	80 fa fd             	cmp    $0xfd,%dl
    7946:	77 23                	ja     796b <fwp_caps12+0x14b>
    7948:	83 c2 01             	add    $0x1,%edx
    794b:	88 10                	mov    %dl,(%rax)
    794d:	eb 89                	jmp    78d8 <fwp_caps12+0xb8>
    794f:	90                   	nop
    7950:	66 85 d2             	test   %dx,%dx
    7953:	0f 85 7f ff ff ff    	jne    78d8 <fwp_caps12+0xb8>
    7959:	e9 58 ff ff ff       	jmp    78b6 <fwp_caps12+0x96>
    795e:	66 90                	xchg   %ax,%ax
    7960:	66 85 ff             	test   %di,%di
    7963:	0f 85 6f ff ff ff    	jne    78d8 <fwp_caps12+0xb8>
    7969:	eb d1                	jmp    793c <fwp_caps12+0x11c>
    796b:	48 89 c7             	mov    %rax,%rdi
    796e:	48 83 c4 18          	add    $0x18,%rsp
    7972:	e9 79 d8 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    797e:	00 00 

0000000000007980 <fwp_drop2>:
    7980:	48 8b 0d d1 d1 01 00 	mov    0x1d1d1(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7987:	48 89 f8             	mov    %rdi,%rax
    798a:	48 2b 05 9f d1 01 00 	sub    0x1d19f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7991:	48 c1 e1 10          	shl    $0x10,%rcx
    7995:	48 39 c8             	cmp    %rcx,%rax
    7998:	0f 83 42 01 00 00    	jae    7ae0 <fwp_drop2+0x160>
    799e:	48 83 ec 18          	sub    $0x18,%rsp
    79a2:	48 89 fa             	mov    %rdi,%rdx
    79a5:	4c 8d 05 d4 bd 01 00 	lea    0x1bdd4(%rip),%r8        # 23780 <fwp_heap>
    79ac:	48 89 c1             	mov    %rax,%rcx
    79af:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    79b6:	48 c1 e9 10          	shr    $0x10,%rcx
    79ba:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    79be:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    79c2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    79c6:	48 85 c9             	test   %rcx,%rcx
    79c9:	74 40                	je     7a0b <fwp_drop2+0x8b>
    79cb:	0f b6 3e             	movzbl (%rsi),%edi
    79ce:	40 80 ff 02          	cmp    $0x2,%dil
    79d2:	74 3c                	je     7a10 <fwp_drop2+0x90>
    79d4:	40 80 ff 01          	cmp    $0x1,%dil
    79d8:	75 31                	jne    7a0b <fwp_drop2+0x8b>
    79da:	8b 7e 18             	mov    0x18(%rsi),%edi
    79dd:	0f b7 c0             	movzwl %ax,%eax
    79e0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    79e3:	48 0f af c7          	imul   %rdi,%rax
    79e7:	48 c1 e8 20          	shr    $0x20,%rax
    79eb:	48 39 f0             	cmp    %rsi,%rax
    79ee:	73 1b                	jae    7a0b <fwp_drop2+0x8b>
    79f0:	48 01 c1             	add    %rax,%rcx
    79f3:	0f b6 01             	movzbl (%rcx),%eax
    79f6:	84 c0                	test   %al,%al
    79f8:	74 11                	je     7a0b <fwp_drop2+0x8b>
    79fa:	3c 01                	cmp    $0x1,%al
    79fc:	74 22                	je     7a20 <fwp_drop2+0xa0>
    79fe:	3c ff                	cmp    $0xff,%al
    7a00:	0f 84 0a 01 00 00    	je     7b10 <fwp_drop2+0x190>
    7a06:	83 e8 01             	sub    $0x1,%eax
    7a09:	88 01                	mov    %al,(%rcx)
    7a0b:	48 83 c4 18          	add    $0x18,%rsp
    7a0f:	c3                   	ret
    7a10:	66 85 c0             	test   %ax,%ax
    7a13:	74 de                	je     79f3 <fwp_drop2+0x73>
    7a15:	48 83 c4 18          	add    $0x18,%rsp
    7a19:	c3                   	ret
    7a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a20:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7a24:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7a2b:	48 89 f8             	mov    %rdi,%rax
    7a2e:	48 c1 e1 10          	shl    $0x10,%rcx
    7a32:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7a39:	48 39 c8             	cmp    %rcx,%rax
    7a3c:	73 62                	jae    7aa0 <fwp_drop2+0x120>
    7a3e:	48 89 c1             	mov    %rax,%rcx
    7a41:	48 c1 e9 10          	shr    $0x10,%rcx
    7a45:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7a49:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7a4d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7a51:	48 85 c9             	test   %rcx,%rcx
    7a54:	74 4a                	je     7aa0 <fwp_drop2+0x120>
    7a56:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7a5a:	41 80 f9 02          	cmp    $0x2,%r9b
    7a5e:	0f 84 9c 00 00 00    	je     7b00 <fwp_drop2+0x180>
    7a64:	41 80 f9 01          	cmp    $0x1,%r9b
    7a68:	75 36                	jne    7aa0 <fwp_drop2+0x120>
    7a6a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7a6e:	0f b7 c0             	movzwl %ax,%eax
    7a71:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7a74:	49 0f af c1          	imul   %r9,%rax
    7a78:	48 c1 e8 20          	shr    $0x20,%rax
    7a7c:	48 39 f0             	cmp    %rsi,%rax
    7a7f:	73 1f                	jae    7aa0 <fwp_drop2+0x120>
    7a81:	48 01 c1             	add    %rax,%rcx
    7a84:	0f b6 01             	movzbl (%rcx),%eax
    7a87:	84 c0                	test   %al,%al
    7a89:	74 15                	je     7aa0 <fwp_drop2+0x120>
    7a8b:	3c 01                	cmp    $0x1,%al
    7a8d:	74 59                	je     7ae8 <fwp_drop2+0x168>
    7a8f:	3c ff                	cmp    $0xff,%al
    7a91:	0f 84 ef 00 00 00    	je     7b86 <fwp_drop2+0x206>
    7a97:	83 e8 01             	sub    $0x1,%eax
    7a9a:	88 01                	mov    %al,(%rcx)
    7a9c:	0f 1f 40 00          	nopl   0x0(%rax)
    7aa0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7aa4:	48 89 d7             	mov    %rdx,%rdi
    7aa7:	48 89 0c 24          	mov    %rcx,(%rsp)
    7aab:	e8 d0 ea ff ff       	call   6580 <fwp_rc_free_arr>
    7ab0:	4c 8d 05 c9 bc 01 00 	lea    0x1bcc9(%rip),%r8        # 23780 <fwp_heap>
    7ab7:	48 8b 04 24          	mov    (%rsp),%rax
    7abb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7ac2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7ac9:	48 c1 e2 10          	shl    $0x10,%rdx
    7acd:	48 39 d0             	cmp    %rdx,%rax
    7ad0:	0f 83 35 ff ff ff    	jae    7a0b <fwp_drop2+0x8b>
    7ad6:	48 8b 14 24          	mov    (%rsp),%rdx
    7ada:	e9 cd fe ff ff       	jmp    79ac <fwp_drop2+0x2c>
    7adf:	90                   	nop
    7ae0:	c3                   	ret
    7ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ae8:	48 89 14 24          	mov    %rdx,(%rsp)
    7aec:	e8 8f ea ff ff       	call   6580 <fwp_rc_free_arr>
    7af1:	48 8b 14 24          	mov    (%rsp),%rdx
    7af5:	eb a9                	jmp    7aa0 <fwp_drop2+0x120>
    7af7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7afe:	00 00 
    7b00:	66 85 c0             	test   %ax,%ax
    7b03:	75 9b                	jne    7aa0 <fwp_drop2+0x120>
    7b05:	e9 7a ff ff ff       	jmp    7a84 <fwp_drop2+0x104>
    7b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b10:	48 89 c8             	mov    %rcx,%rax
    7b13:	48 c1 e8 11          	shr    $0x11,%rax
    7b17:	48 31 c8             	xor    %rcx,%rax
    7b1a:	48 89 c2             	mov    %rax,%rdx
    7b1d:	48 c1 ea 09          	shr    $0x9,%rdx
    7b21:	48 31 d0             	xor    %rdx,%rax
    7b24:	0f b6 d0             	movzbl %al,%edx
    7b27:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7b2e:	00 
    7b2f:	48 85 c0             	test   %rax,%rax
    7b32:	75 19                	jne    7b4d <fwp_drop2+0x1cd>
    7b34:	e9 d3 00 00 00       	jmp    7c0c <fwp_drop2+0x28c>
    7b39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7b44:	48 85 c0             	test   %rax,%rax
    7b47:	0f 84 bf 00 00 00    	je     7c0c <fwp_drop2+0x28c>
    7b4d:	48 89 c2             	mov    %rax,%rdx
    7b50:	48 39 08             	cmp    %rcx,(%rax)
    7b53:	75 eb                	jne    7b40 <fwp_drop2+0x1c0>
    7b55:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7b59:	48 83 ea 01          	sub    $0x1,%rdx
    7b5d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7b61:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7b68:	0f 85 9d fe ff ff    	jne    7a0b <fwp_drop2+0x8b>
    7b6e:	48 89 cf             	mov    %rcx,%rdi
    7b71:	48 89 0c 24          	mov    %rcx,(%rsp)
    7b75:	e8 96 d7 ff ff       	call   5310 <fwp_rc_forget_slot>
    7b7a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7b7e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7b81:	e9 85 fe ff ff       	jmp    7a0b <fwp_drop2+0x8b>
    7b86:	48 89 ce             	mov    %rcx,%rsi
    7b89:	48 c1 ee 11          	shr    $0x11,%rsi
    7b8d:	48 31 ce             	xor    %rcx,%rsi
    7b90:	48 89 f0             	mov    %rsi,%rax
    7b93:	48 c1 e8 09          	shr    $0x9,%rax
    7b97:	48 31 c6             	xor    %rax,%rsi
    7b9a:	40 0f b6 f6          	movzbl %sil,%esi
    7b9e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7ba5:	00 
    7ba6:	48 85 c0             	test   %rax,%rax
    7ba9:	75 1e                	jne    7bc9 <fwp_drop2+0x249>
    7bab:	eb 5f                	jmp    7c0c <fwp_drop2+0x28c>
    7bad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7bb4:	00 
    7bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7bbc:	00 00 00 00 
    7bc0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7bc4:	48 85 c0             	test   %rax,%rax
    7bc7:	74 43                	je     7c0c <fwp_drop2+0x28c>
    7bc9:	48 89 c6             	mov    %rax,%rsi
    7bcc:	48 39 08             	cmp    %rcx,(%rax)
    7bcf:	75 ef                	jne    7bc0 <fwp_drop2+0x240>
    7bd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bd5:	48 83 ee 01          	sub    $0x1,%rsi
    7bd9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7bdd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7be4:	0f 85 b6 fe ff ff    	jne    7aa0 <fwp_drop2+0x120>
    7bea:	48 89 cf             	mov    %rcx,%rdi
    7bed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bf2:	48 89 0c 24          	mov    %rcx,(%rsp)
    7bf6:	e8 15 d7 ff ff       	call   5310 <fwp_rc_forget_slot>
    7bfb:	48 8b 0c 24          	mov    (%rsp),%rcx
    7bff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c04:	c6 01 fe             	movb   $0xfe,(%rcx)
    7c07:	e9 94 fe ff ff       	jmp    7aa0 <fwp_drop2+0x120>
    7c0c:	48 8d 3d 85 7b 00 00 	lea    0x7b85(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    7c13:	e8 88 c5 ff ff       	call   41a0 <fwp_trap>
    7c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7c1f:	00 

0000000000007c20 <fwp_arg_drop23>:
    7c20:	f3 0f 1e fa          	endbr64
    7c24:	85 f6                	test   %esi,%esi
    7c26:	75 04                	jne    7c2c <fwp_arg_drop23+0xc>
    7c28:	85 d2                	test   %edx,%edx
    7c2a:	75 04                	jne    7c30 <fwp_arg_drop23+0x10>
    7c2c:	c3                   	ret
    7c2d:	0f 1f 00             	nopl   (%rax)
    7c30:	48 8b 3f             	mov    (%rdi),%rdi
    7c33:	e9 48 fd ff ff       	jmp    7980 <fwp_drop2>
    7c38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7c3f:	00 

0000000000007c40 <fwp_caps23>:
    7c40:	f3 0f 1e fa          	endbr64
    7c44:	48 83 ec 18          	sub    $0x18,%rsp
    7c48:	8b 57 04             	mov    0x4(%rdi),%edx
    7c4b:	48 89 f8             	mov    %rdi,%rax
    7c4e:	85 d2                	test   %edx,%edx
    7c50:	0f 84 9a 00 00 00    	je     7cf0 <fwp_caps23+0xb0>
    7c56:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7c5a:	85 f6                	test   %esi,%esi
    7c5c:	0f 85 9e 00 00 00    	jne    7d00 <fwp_caps23+0xc0>
    7c62:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7c67:	e8 14 fd ff ff       	call   7980 <fwp_drop2>
    7c6c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c71:	48 8b 0d e0 ce 01 00 	mov    0x1cee0(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7c78:	48 89 c2             	mov    %rax,%rdx
    7c7b:	48 2b 15 ae ce 01 00 	sub    0x1ceae(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    7c82:	48 c1 e1 10          	shl    $0x10,%rcx
    7c86:	48 39 ca             	cmp    %rcx,%rdx
    7c89:	73 6d                	jae    7cf8 <fwp_caps23+0xb8>
    7c8b:	48 89 d1             	mov    %rdx,%rcx
    7c8e:	48 c1 e9 10          	shr    $0x10,%rcx
    7c92:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7c96:	48 8b 0d db ce 01 00 	mov    0x1cedb(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7c9d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7ca1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ca5:	48 85 f6             	test   %rsi,%rsi
    7ca8:	74 4e                	je     7cf8 <fwp_caps23+0xb8>
    7caa:	0f b6 39             	movzbl (%rcx),%edi
    7cad:	40 80 ff 02          	cmp    $0x2,%dil
    7cb1:	0f 84 b9 00 00 00    	je     7d70 <fwp_caps23+0x130>
    7cb7:	40 80 ff 01          	cmp    $0x1,%dil
    7cbb:	75 3b                	jne    7cf8 <fwp_caps23+0xb8>
    7cbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7cc0:	0f b7 d2             	movzwl %dx,%edx
    7cc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7cc6:	48 0f af d7          	imul   %rdi,%rdx
    7cca:	48 c1 ea 20          	shr    $0x20,%rdx
    7cce:	48 39 ca             	cmp    %rcx,%rdx
    7cd1:	73 25                	jae    7cf8 <fwp_caps23+0xb8>
    7cd3:	48 01 d6             	add    %rdx,%rsi
    7cd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7cd9:	75 1d                	jne    7cf8 <fwp_caps23+0xb8>
    7cdb:	48 89 c7             	mov    %rax,%rdi
    7cde:	48 83 c4 18          	add    $0x18,%rsp
    7ce2:	e9 69 d8 ff ff       	jmp    5550 <fwp_mem_free>
    7ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cee:	00 00 
    7cf0:	85 f6                	test   %esi,%esi
    7cf2:	0f 84 79 ff ff ff    	je     7c71 <fwp_caps23+0x31>
    7cf8:	48 83 c4 18          	add    $0x18,%rsp
    7cfc:	c3                   	ret
    7cfd:	0f 1f 00             	nopl   (%rax)
    7d00:	48 8b 05 51 ce 01 00 	mov    0x1ce51(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    7d07:	48 2b 3d 22 ce 01 00 	sub    0x1ce22(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    7d0e:	48 c1 e0 10          	shl    $0x10,%rax
    7d12:	48 39 c7             	cmp    %rax,%rdi
    7d15:	73 e1                	jae    7cf8 <fwp_caps23+0xb8>
    7d17:	48 89 f8             	mov    %rdi,%rax
    7d1a:	48 c1 e8 10          	shr    $0x10,%rax
    7d1e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7d22:	48 8b 05 4f ce 01 00 	mov    0x1ce4f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7d29:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7d2d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7d31:	48 85 c0             	test   %rax,%rax
    7d34:	74 c2                	je     7cf8 <fwp_caps23+0xb8>
    7d36:	0f b6 0a             	movzbl (%rdx),%ecx
    7d39:	80 f9 02             	cmp    $0x2,%cl
    7d3c:	74 42                	je     7d80 <fwp_caps23+0x140>
    7d3e:	80 f9 01             	cmp    $0x1,%cl
    7d41:	75 b5                	jne    7cf8 <fwp_caps23+0xb8>
    7d43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d46:	0f b7 ff             	movzwl %di,%edi
    7d49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d4c:	48 0f af f9          	imul   %rcx,%rdi
    7d50:	48 c1 ef 20          	shr    $0x20,%rdi
    7d54:	48 39 d7             	cmp    %rdx,%rdi
    7d57:	73 9f                	jae    7cf8 <fwp_caps23+0xb8>
    7d59:	48 01 f8             	add    %rdi,%rax
    7d5c:	0f b6 10             	movzbl (%rax),%edx
    7d5f:	84 d2                	test   %dl,%dl
    7d61:	74 95                	je     7cf8 <fwp_caps23+0xb8>
    7d63:	80 fa fd             	cmp    $0xfd,%dl
    7d66:	77 23                	ja     7d8b <fwp_caps23+0x14b>
    7d68:	83 c2 01             	add    $0x1,%edx
    7d6b:	88 10                	mov    %dl,(%rax)
    7d6d:	eb 89                	jmp    7cf8 <fwp_caps23+0xb8>
    7d6f:	90                   	nop
    7d70:	66 85 d2             	test   %dx,%dx
    7d73:	0f 85 7f ff ff ff    	jne    7cf8 <fwp_caps23+0xb8>
    7d79:	e9 58 ff ff ff       	jmp    7cd6 <fwp_caps23+0x96>
    7d7e:	66 90                	xchg   %ax,%ax
    7d80:	66 85 ff             	test   %di,%di
    7d83:	0f 85 6f ff ff ff    	jne    7cf8 <fwp_caps23+0xb8>
    7d89:	eb d1                	jmp    7d5c <fwp_caps23+0x11c>
    7d8b:	48 89 c7             	mov    %rax,%rdi
    7d8e:	48 83 c4 18          	add    $0x18,%rsp
    7d92:	e9 59 d4 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d9e:	00 00 

0000000000007da0 <f23>:
    7da0:	41 57                	push   %r15
    7da2:	41 56                	push   %r14
    7da4:	41 55                	push   %r13
    7da6:	41 54                	push   %r12
    7da8:	55                   	push   %rbp
    7da9:	53                   	push   %rbx
    7daa:	48 83 ec 38          	sub    $0x38,%rsp
    7dae:	48 8b 15 a3 cd 01 00 	mov    0x1cda3(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7db5:	48 8b 0d 74 cd 01 00 	mov    0x1cd74(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    7dbc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7dc3:	00 00 
    7dc5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7dca:	49 89 fc             	mov    %rdi,%r12
    7dcd:	48 c1 e2 10          	shl    $0x10,%rdx
    7dd1:	48 85 ff             	test   %rdi,%rdi
    7dd4:	0f 84 bc 02 00 00    	je     8096 <f23+0x2f6>
    7dda:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7ddf:	48 89 d8             	mov    %rbx,%rax
    7de2:	48 29 c8             	sub    %rcx,%rax
    7de5:	48 39 d0             	cmp    %rdx,%rax
    7de8:	0f 83 72 03 00 00    	jae    8160 <f23+0x3c0>
    7dee:	48 89 c2             	mov    %rax,%rdx
    7df1:	48 c1 ea 10          	shr    $0x10,%rdx
    7df5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7df9:	48 8b 15 78 cd 01 00 	mov    0x1cd78(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7e00:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e04:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e08:	48 85 ff             	test   %rdi,%rdi
    7e0b:	0f 84 4f 03 00 00    	je     8160 <f23+0x3c0>
    7e11:	0f b6 0a             	movzbl (%rdx),%ecx
    7e14:	80 f9 02             	cmp    $0x2,%cl
    7e17:	0f 84 53 02 00 00    	je     8070 <f23+0x2d0>
    7e1d:	80 f9 01             	cmp    $0x1,%cl
    7e20:	75 24                	jne    7e46 <f23+0xa6>
    7e22:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e25:	0f b7 c0             	movzwl %ax,%eax
    7e28:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e2b:	48 0f af c1          	imul   %rcx,%rax
    7e2f:	48 c1 e8 20          	shr    $0x20,%rax
    7e33:	48 39 d0             	cmp    %rdx,%rax
    7e36:	73 0e                	jae    7e46 <f23+0xa6>
    7e38:	48 01 c7             	add    %rax,%rdi
    7e3b:	0f b6 07             	movzbl (%rdi),%eax
    7e3e:	84 c0                	test   %al,%al
    7e40:	0f 85 ca 02 00 00    	jne    8110 <f23+0x370>
    7e46:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e4b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7e50:	ba 01 00 00 00       	mov    $0x1,%edx
    7e55:	48 85 db             	test   %rbx,%rbx
    7e58:	74 13                	je     7e6d <f23+0xcd>
    7e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e60:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7e64:	48 83 c2 01          	add    $0x1,%rdx
    7e68:	48 85 db             	test   %rbx,%rbx
    7e6b:	75 f3                	jne    7e60 <f23+0xc0>
    7e6d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e72:	48 85 c0             	test   %rax,%rax
    7e75:	0f 84 15 03 00 00    	je     8190 <f23+0x3f0>
    7e7b:	31 db                	xor    %ebx,%ebx
    7e7d:	0f 1f 00             	nopl   (%rax)
    7e80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e84:	48 83 c3 01          	add    $0x1,%rbx
    7e88:	48 85 c0             	test   %rax,%rax
    7e8b:	75 f3                	jne    7e80 <f23+0xe0>
    7e8d:	48 39 d3             	cmp    %rdx,%rbx
    7e90:	48 0f 47 da          	cmova  %rdx,%rbx
    7e94:	48 89 d8             	mov    %rbx,%rax
    7e97:	48 c1 e8 3c          	shr    $0x3c,%rax
    7e9b:	0f 85 8f 03 00 00    	jne    8230 <f23+0x490>
    7ea1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7ea5:	be 02 00 00 00       	mov    $0x2,%esi
    7eaa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7eb1:	00 
    7eb2:	e8 99 db ff ff       	call   5a50 <fwp_heap_alloc>
    7eb7:	48 89 28             	mov    %rbp,(%rax)
    7eba:	48 8b 15 97 cc 01 00 	mov    0x1cc97(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7ec1:	49 89 c6             	mov    %rax,%r14
    7ec4:	48 2b 05 65 cc 01 00 	sub    0x1cc65(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7ecb:	48 c1 e2 10          	shl    $0x10,%rdx
    7ecf:	48 39 d0             	cmp    %rdx,%rax
    7ed2:	73 57                	jae    7f2b <f23+0x18b>
    7ed4:	48 89 c2             	mov    %rax,%rdx
    7ed7:	48 c1 ea 10          	shr    $0x10,%rdx
    7edb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7edf:	48 8b 15 92 cc 01 00 	mov    0x1cc92(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7ee6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7eea:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7eee:	48 85 ed             	test   %rbp,%rbp
    7ef1:	74 38                	je     7f2b <f23+0x18b>
    7ef3:	0f b6 0a             	movzbl (%rdx),%ecx
    7ef6:	80 f9 02             	cmp    $0x2,%cl
    7ef9:	0f 84 51 02 00 00    	je     8150 <f23+0x3b0>
    7eff:	80 f9 01             	cmp    $0x1,%cl
    7f02:	75 27                	jne    7f2b <f23+0x18b>
    7f04:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f07:	0f b7 c0             	movzwl %ax,%eax
    7f0a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f0d:	48 0f af c1          	imul   %rcx,%rax
    7f11:	48 c1 e8 20          	shr    $0x20,%rax
    7f15:	48 39 d0             	cmp    %rdx,%rax
    7f18:	73 11                	jae    7f2b <f23+0x18b>
    7f1a:	48 01 c5             	add    %rax,%rbp
    7f1d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7f21:	0f 84 d5 02 00 00    	je     81fc <f23+0x45c>
    7f27:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7f2b:	48 85 db             	test   %rbx,%rbx
    7f2e:	74 5d                	je     7f8d <f23+0x1ed>
    7f30:	48 c1 e3 04          	shl    $0x4,%rbx
    7f34:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7f39:	4c 89 f5             	mov    %r14,%rbp
    7f3c:	4d 89 e5             	mov    %r12,%r13
    7f3f:	4c 01 f3             	add    %r14,%rbx
    7f42:	0f 1f 00             	nopl   (%rax)
    7f45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f4c:	00 00 00 00 
    7f50:	49 8b 45 08          	mov    0x8(%r13),%rax
    7f54:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7f58:	48 83 c5 10          	add    $0x10,%rbp
    7f5c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7f61:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7f65:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7f69:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7f6e:	e8 bd e1 ff ff       	call   6130 <w107>
    7f73:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7f78:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7f7c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7f80:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7f84:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7f88:	48 39 dd             	cmp    %rbx,%rbp
    7f8b:	75 c3                	jne    7f50 <f23+0x1b0>
    7f8d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f92:	e8 e9 f9 ff ff       	call   7980 <fwp_drop2>
    7f97:	4c 89 e7             	mov    %r12,%rdi
    7f9a:	e8 e1 f9 ff ff       	call   7980 <fwp_drop2>
    7f9f:	4c 89 f7             	mov    %r14,%rdi
    7fa2:	e8 f9 e2 ff ff       	call   62a0 <w164.constprop.0>
    7fa7:	4c 89 f7             	mov    %r14,%rdi
    7faa:	48 89 c3             	mov    %rax,%rbx
    7fad:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7fb3:	e8 c8 f4 ff ff       	call   7480 <fwp_drop4>
    7fb8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7fbe:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7fc3:	31 ff                	xor    %edi,%edi
    7fc5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7fca:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7fce:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7fd3:	e8 48 e3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    7fd8:	48 8b 15 79 cb 01 00 	mov    0x1cb79(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7fdf:	48 89 c5             	mov    %rax,%rbp
    7fe2:	48 2b 05 47 cb 01 00 	sub    0x1cb47(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7fe9:	48 c1 e2 10          	shl    $0x10,%rdx
    7fed:	48 39 d0             	cmp    %rdx,%rax
    7ff0:	73 55                	jae    8047 <f23+0x2a7>
    7ff2:	48 89 c2             	mov    %rax,%rdx
    7ff5:	48 c1 ea 10          	shr    $0x10,%rdx
    7ff9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ffd:	48 8b 15 74 cb 01 00 	mov    0x1cb74(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8004:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8008:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    800c:	48 85 db             	test   %rbx,%rbx
    800f:	74 36                	je     8047 <f23+0x2a7>
    8011:	0f b6 0a             	movzbl (%rdx),%ecx
    8014:	80 f9 02             	cmp    $0x2,%cl
    8017:	0f 84 1b 01 00 00    	je     8138 <f23+0x398>
    801d:	80 f9 01             	cmp    $0x1,%cl
    8020:	75 25                	jne    8047 <f23+0x2a7>
    8022:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8025:	0f b7 c0             	movzwl %ax,%eax
    8028:	8b 52 1c             	mov    0x1c(%rdx),%edx
    802b:	48 0f af c1          	imul   %rcx,%rax
    802f:	48 c1 e8 20          	shr    $0x20,%rax
    8033:	48 39 d0             	cmp    %rdx,%rax
    8036:	73 0f                	jae    8047 <f23+0x2a7>
    8038:	48 01 c3             	add    %rax,%rbx
    803b:	80 3b ff             	cmpb   $0xff,(%rbx)
    803e:	0f 84 ab 01 00 00    	je     81ef <f23+0x44f>
    8044:	c6 03 01             	movb   $0x1,(%rbx)
    8047:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    804c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8053:	00 00 
    8055:	0f 85 d0 01 00 00    	jne    822b <f23+0x48b>
    805b:	48 83 c4 38          	add    $0x38,%rsp
    805f:	48 89 e8             	mov    %rbp,%rax
    8062:	5b                   	pop    %rbx
    8063:	5d                   	pop    %rbp
    8064:	41 5c                	pop    %r12
    8066:	41 5d                	pop    %r13
    8068:	41 5e                	pop    %r14
    806a:	41 5f                	pop    %r15
    806c:	c3                   	ret
    806d:	0f 1f 00             	nopl   (%rax)
    8070:	66 85 c0             	test   %ax,%ax
    8073:	0f 85 cd fd ff ff    	jne    7e46 <f23+0xa6>
    8079:	0f b6 07             	movzbl (%rdi),%eax
    807c:	84 c0                	test   %al,%al
    807e:	0f 84 c2 fd ff ff    	je     7e46 <f23+0xa6>
    8084:	3c fd                	cmp    $0xfd,%al
    8086:	0f 87 95 01 00 00    	ja     8221 <f23+0x481>
    808c:	83 c0 01             	add    $0x1,%eax
    808f:	88 07                	mov    %al,(%rdi)
    8091:	e9 b0 fd ff ff       	jmp    7e46 <f23+0xa6>
    8096:	48 f7 d9             	neg    %rcx
    8099:	48 39 d1             	cmp    %rdx,%rcx
    809c:	0f 83 ee 00 00 00    	jae    8190 <f23+0x3f0>
    80a2:	48 89 c8             	mov    %rcx,%rax
    80a5:	48 c1 e8 10          	shr    $0x10,%rax
    80a9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    80ad:	48 8b 05 c4 ca 01 00 	mov    0x1cac4(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    80b4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    80b8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    80bc:	48 85 ff             	test   %rdi,%rdi
    80bf:	0f 84 cb 00 00 00    	je     8190 <f23+0x3f0>
    80c5:	0f b6 02             	movzbl (%rdx),%eax
    80c8:	3c 02                	cmp    $0x2,%al
    80ca:	0f 84 9a 00 00 00    	je     816a <f23+0x3ca>
    80d0:	3c 01                	cmp    $0x1,%al
    80d2:	0f 85 b8 00 00 00    	jne    8190 <f23+0x3f0>
    80d8:	0f b7 c1             	movzwl %cx,%eax
    80db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80e1:	48 0f af c1          	imul   %rcx,%rax
    80e5:	48 c1 e8 20          	shr    $0x20,%rax
    80e9:	48 39 d0             	cmp    %rdx,%rax
    80ec:	0f 83 9e 00 00 00    	jae    8190 <f23+0x3f0>
    80f2:	48 01 c7             	add    %rax,%rdi
    80f5:	0f b6 07             	movzbl (%rdi),%eax
    80f8:	84 c0                	test   %al,%al
    80fa:	0f 84 90 00 00 00    	je     8190 <f23+0x3f0>
    8100:	31 db                	xor    %ebx,%ebx
    8102:	0f 1f 00             	nopl   (%rax)
    8105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    810c:	00 00 00 00 
    8110:	3c fd                	cmp    $0xfd,%al
    8112:	0f 87 f1 00 00 00    	ja     8209 <f23+0x469>
    8118:	83 c0 01             	add    $0x1,%eax
    811b:	88 07                	mov    %al,(%rdi)
    811d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8122:	31 d2                	xor    %edx,%edx
    8124:	4d 85 e4             	test   %r12,%r12
    8127:	0f 85 1e fd ff ff    	jne    7e4b <f23+0xab>
    812d:	e9 3b fd ff ff       	jmp    7e6d <f23+0xcd>
    8132:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8138:	66 85 c0             	test   %ax,%ax
    813b:	0f 85 06 ff ff ff    	jne    8047 <f23+0x2a7>
    8141:	e9 f5 fe ff ff       	jmp    803b <f23+0x29b>
    8146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    814d:	00 00 00 
    8150:	66 85 c0             	test   %ax,%ax
    8153:	0f 85 d2 fd ff ff    	jne    7f2b <f23+0x18b>
    8159:	e9 bf fd ff ff       	jmp    7f1d <f23+0x17d>
    815e:	66 90                	xchg   %ax,%ax
    8160:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8165:	e9 e6 fc ff ff       	jmp    7e50 <f23+0xb0>
    816a:	66 85 c9             	test   %cx,%cx
    816d:	75 21                	jne    8190 <f23+0x3f0>
    816f:	0f b6 07             	movzbl (%rdi),%eax
    8172:	84 c0                	test   %al,%al
    8174:	74 1a                	je     8190 <f23+0x3f0>
    8176:	3c fd                	cmp    $0xfd,%al
    8178:	0f 87 be 00 00 00    	ja     823c <f23+0x49c>
    817e:	83 c0 01             	add    $0x1,%eax
    8181:	88 07                	mov    %al,(%rdi)
    8183:	66 90                	xchg   %ax,%ax
    8185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    818c:	00 00 00 00 
    8190:	be 02 00 00 00       	mov    $0x2,%esi
    8195:	bf 08 00 00 00       	mov    $0x8,%edi
    819a:	e8 b1 d8 ff ff       	call   5a50 <fwp_heap_alloc>
    819f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    81a6:	48 8b 15 ab c9 01 00 	mov    0x1c9ab(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    81ad:	49 89 c6             	mov    %rax,%r14
    81b0:	48 2b 05 79 c9 01 00 	sub    0x1c979(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    81b7:	48 c1 e2 10          	shl    $0x10,%rdx
    81bb:	48 39 d0             	cmp    %rdx,%rax
    81be:	73 53                	jae    8213 <f23+0x473>
    81c0:	48 89 c2             	mov    %rax,%rdx
    81c3:	48 c1 ea 10          	shr    $0x10,%rdx
    81c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81cb:	48 8b 15 a6 c9 01 00 	mov    0x1c9a6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    81d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81d6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    81da:	48 85 ed             	test   %rbp,%rbp
    81dd:	74 34                	je     8213 <f23+0x473>
    81df:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    81e6:	00 00 
    81e8:	31 db                	xor    %ebx,%ebx
    81ea:	e9 04 fd ff ff       	jmp    7ef3 <f23+0x153>
    81ef:	48 89 df             	mov    %rbx,%rdi
    81f2:	e8 19 d1 ff ff       	call   5310 <fwp_rc_forget_slot>
    81f7:	e9 48 fe ff ff       	jmp    8044 <f23+0x2a4>
    81fc:	48 89 ef             	mov    %rbp,%rdi
    81ff:	e8 0c d1 ff ff       	call   5310 <fwp_rc_forget_slot>
    8204:	e9 1e fd ff ff       	jmp    7f27 <f23+0x187>
    8209:	e8 e2 cf ff ff       	call   51f0 <fwp_rc_wide_dup>
    820e:	e9 0a ff ff ff       	jmp    811d <f23+0x37d>
    8213:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    821a:	00 00 
    821c:	e9 6c fd ff ff       	jmp    7f8d <f23+0x1ed>
    8221:	e8 ca cf ff ff       	call   51f0 <fwp_rc_wide_dup>
    8226:	e9 1b fc ff ff       	jmp    7e46 <f23+0xa6>
    822b:	e8 30 b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    8230:	48 8d 3d f6 6e 00 00 	lea    0x6ef6(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    8237:	e8 64 bf ff ff       	call   41a0 <fwp_trap>
    823c:	e8 af cf ff ff       	call   51f0 <fwp_rc_wide_dup>
    8241:	e9 4a ff ff ff       	jmp    8190 <f23+0x3f0>
    8246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    824d:	00 00 00 

0000000000008250 <fwp_owned_entry23>:
    8250:	f3 0f 1e fa          	endbr64
    8254:	48 8b 3f             	mov    (%rdi),%rdi
    8257:	e9 44 fb ff ff       	jmp    7da0 <f23>
    825c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008260 <e23>:
    8260:	f3 0f 1e fa          	endbr64
    8264:	53                   	push   %rbx
    8265:	48 8b 1f             	mov    (%rdi),%rbx
    8268:	48 89 df             	mov    %rbx,%rdi
    826b:	e8 e0 e1 ff ff       	call   6450 <fwp_rc_share>
    8270:	48 89 df             	mov    %rbx,%rdi
    8273:	e8 28 fb ff ff       	call   7da0 <f23>
    8278:	48 89 c3             	mov    %rax,%rbx
    827b:	48 89 c7             	mov    %rax,%rdi
    827e:	e8 cd e1 ff ff       	call   6450 <fwp_rc_share>
    8283:	48 89 d8             	mov    %rbx,%rax
    8286:	5b                   	pop    %rbx
    8287:	c3                   	ret
    8288:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    828f:	00 

0000000000008290 <f12>:
    8290:	41 57                	push   %r15
    8292:	41 56                	push   %r14
    8294:	41 55                	push   %r13
    8296:	4c 8d 2d 03 ec ff ff 	lea    -0x13fd(%rip),%r13        # 6ea0 <fwp_tape_scope_release>
    829d:	41 54                	push   %r12
    829f:	55                   	push   %rbp
    82a0:	53                   	push   %rbx
    82a1:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
    82a8:	48 8b 05 69 d1 01 00 	mov    0x1d169(%rip),%rax        # 25418 <fwp_cleanups>
    82af:	48 8b 15 a2 c8 01 00 	mov    0x1c8a2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    82b6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    82bd:	00 00 
    82bf:	48 89 ac 24 e8 00 00 	mov    %rbp,0xe8(%rsp)
    82c6:	00 
    82c7:	48 89 fd             	mov    %rdi,%rbp
    82ca:	4c 8d 7c 24 50       	lea    0x50(%rsp),%r15
    82cf:	c7 44 24 4c ff ff ff 	movl   $0xffffffff,0x4c(%rsp)
    82d6:	ff 
    82d7:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    82dc:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
    82e1:	48 c1 e2 10          	shl    $0x10,%rdx
    82e5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    82ea:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    82ef:	48 8d 05 1a ad 00 00 	lea    0xad1a(%rip),%rax        # 13010 <fc23>
    82f6:	48 2b 05 33 c8 01 00 	sub    0x1c833(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    82fd:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    8302:	4c 89 3d 0f d1 01 00 	mov    %r15,0x1d10f(%rip)        # 25418 <fwp_cleanups>
    8309:	48 39 d0             	cmp    %rdx,%rax
    830c:	73 5d                	jae    836b <f12+0xdb>
    830e:	48 89 c2             	mov    %rax,%rdx
    8311:	48 c1 ea 10          	shr    $0x10,%rdx
    8315:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8319:	48 8b 15 58 c8 01 00 	mov    0x1c858(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8320:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8324:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8328:	48 85 ff             	test   %rdi,%rdi
    832b:	74 3e                	je     836b <f12+0xdb>
    832d:	0f b6 0a             	movzbl (%rdx),%ecx
    8330:	80 f9 02             	cmp    $0x2,%cl
    8333:	0f 84 e7 0e 00 00    	je     9220 <f12+0xf90>
    8339:	80 f9 01             	cmp    $0x1,%cl
    833c:	75 2d                	jne    836b <f12+0xdb>
    833e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8341:	0f b7 c0             	movzwl %ax,%eax
    8344:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8347:	48 0f af c1          	imul   %rcx,%rax
    834b:	48 c1 e8 20          	shr    $0x20,%rax
    834f:	48 39 d0             	cmp    %rdx,%rax
    8352:	73 17                	jae    836b <f12+0xdb>
    8354:	48 01 c7             	add    %rax,%rdi
    8357:	0f b6 07             	movzbl (%rdi),%eax
    835a:	84 c0                	test   %al,%al
    835c:	74 0d                	je     836b <f12+0xdb>
    835e:	3c fd                	cmp    $0xfd,%al
    8360:	0f 87 df 10 00 00    	ja     9445 <f12+0x11b5>
    8366:	83 c0 01             	add    $0x1,%eax
    8369:	88 07                	mov    %al,(%rdi)
    836b:	48 8d 3d 9e ac 00 00 	lea    0xac9e(%rip),%rdi        # 13010 <fc23>
    8372:	e8 f9 e7 ff ff       	call   6b70 <fwp_closure_drop>
    8377:	48 85 ed             	test   %rbp,%rbp
    837a:	0f 84 1e 10 00 00    	je     939e <f12+0x110e>
    8380:	48 89 e8             	mov    %rbp,%rax
    8383:	31 d2                	xor    %edx,%edx
    8385:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    838c:	00 00 00 00 
    8390:	48 8b 40 10          	mov    0x10(%rax),%rax
    8394:	48 83 c2 01          	add    $0x1,%rdx
    8398:	48 85 c0             	test   %rax,%rax
    839b:	75 f3                	jne    8390 <f12+0x100>
    839d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    83a4:	0f 87 76 11 00 00    	ja     9520 <f12+0x1290>
    83aa:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    83af:	8b 35 cb ac 00 00    	mov    0xaccb(%rip),%esi        # 13080 <registered_finish.0>
    83b5:	85 f6                	test   %esi,%esi
    83b7:	0f 84 33 0e 00 00    	je     91f0 <f12+0xf60>
    83bd:	48 8b 1d 34 ad 01 00 	mov    0x1ad34(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    83c4:	4c 8b 25 3d ad 01 00 	mov    0x1ad3d(%rip),%r12        # 23108 <fwp_ntapes>
    83cb:	4c 39 e3             	cmp    %r12,%rbx
    83ce:	0f 8d dc 00 00 00    	jge    84b0 <f12+0x220>
    83d4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    83d8:	48 03 05 31 ad 01 00 	add    0x1ad31(%rip),%rax        # 23110 <fwp_tapes>
    83df:	90                   	nop
    83e0:	8b 48 04             	mov    0x4(%rax),%ecx
    83e3:	85 c9                	test   %ecx,%ecx
    83e5:	75 0c                	jne    83f3 <f12+0x163>
    83e7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    83ed:	0f 86 bd 00 00 00    	jbe    84b0 <f12+0x220>
    83f3:	48 83 c3 01          	add    $0x1,%rbx
    83f7:	48 83 c0 68          	add    $0x68,%rax
    83fb:	4c 39 e3             	cmp    %r12,%rbx
    83fe:	75 e0                	jne    83e0 <f12+0x150>
    8400:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8407:	0f 8f 3c 11 00 00    	jg     9549 <f12+0x12b9>
    840d:	4c 39 25 ec ac 01 00 	cmp    %r12,0x1acec(%rip)        # 23100 <fwp_tapes_cap>
    8414:	4c 8b 35 f5 ac 01 00 	mov    0x1acf5(%rip),%r14        # 23110 <fwp_tapes>
    841b:	75 53                	jne    8470 <f12+0x1e0>
    841d:	4d 85 e4             	test   %r12,%r12
    8420:	0f 84 d9 0f 00 00    	je     93ff <f12+0x116f>
    8426:	4b 8d 0c 24          	lea    (%r12,%r12,1),%rcx
    842a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    842f:	48 39 c1             	cmp    %rax,%rcx
    8432:	48 0f 4f c8          	cmovg  %rax,%rcx
    8436:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    843a:	4c 89 f7             	mov    %r14,%rdi
    843d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    8442:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8447:	e8 84 b1 ff ff       	call   35d0 <realloc@plt>
    844c:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8451:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    8456:	48 85 c0             	test   %rax,%rax
    8459:	49 89 c6             	mov    %rax,%r14
    845c:	0f 84 78 10 00 00    	je     94da <f12+0x124a>
    8462:	48 89 05 a7 ac 01 00 	mov    %rax,0x1aca7(%rip)        # 23110 <fwp_tapes>
    8469:	48 89 0d 90 ac 01 00 	mov    %rcx,0x1ac90(%rip)        # 23100 <fwp_tapes_cap>
    8470:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8474:	49 83 c4 01          	add    $0x1,%r12
    8478:	4c 01 f0             	add    %r14,%rax
    847b:	48 8d 78 08          	lea    0x8(%rax),%rdi
    847f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8486:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    848a:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8491:	00 
    8492:	48 29 f8             	sub    %rdi,%rax
    8495:	8d 48 68             	lea    0x68(%rax),%ecx
    8498:	31 c0                	xor    %eax,%eax
    849a:	c1 e9 03             	shr    $0x3,%ecx
    849d:	f3 48 ab             	rep stos %rax,(%rdi)
    84a0:	4c 89 25 61 ac 01 00 	mov    %r12,0x1ac61(%rip)        # 23108 <fwp_ntapes>
    84a7:	eb 17                	jmp    84c0 <f12+0x230>
    84a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    84b0:	4c 39 e3             	cmp    %r12,%rbx
    84b3:	0f 84 47 ff ff ff    	je     8400 <f12+0x170>
    84b9:	4c 8b 35 50 ac 01 00 	mov    0x1ac50(%rip),%r14        # 23110 <fwp_tapes>
    84c0:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    84c4:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    84c8:	48 8d 3d f0 6b 00 00 	lea    0x6bf0(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    84cf:	0f 29 04 24          	movaps %xmm0,(%rsp)
    84d3:	4d 01 f4             	add    %r14,%r12
    84d6:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    84dd:	00 00 
    84df:	e8 bc ae ff ff       	call   33a0 <getenv@plt>
    84e4:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    84e9:	48 85 c0             	test   %rax,%rax
    84ec:	74 09                	je     84f7 <f12+0x267>
    84ee:	80 38 30             	cmpb   $0x30,(%rax)
    84f1:	0f 84 f9 06 00 00    	je     8bf0 <f12+0x960>
    84f7:	48 83 3d a9 ab 01 00 	cmpq   $0x0,0x1aba9(%rip)        # 230a8 <fwp_tape_cached_bytes>
    84fe:	00 
    84ff:	0f 85 7b 0d 00 00    	jne    9280 <f12+0xff0>
    8505:	41 8b 04 24          	mov    (%r12),%eax
    8509:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    850d:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8514:	00 00 
    8516:	48 89 3d db ab 01 00 	mov    %rdi,0x1abdb(%rip)        # 230f8 <fwp_tape_next_slot>
    851d:	8d 70 01             	lea    0x1(%rax),%esi
    8520:	48 8b 05 f1 ce 01 00 	mov    0x1cef1(%rip),%rax        # 25418 <fwp_cleanups>
    8527:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    852e:	00 00 
    8530:	41 89 34 24          	mov    %esi,(%r12)
    8534:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    853b:	ff ff 
    853d:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8543:	48 85 c0             	test   %rax,%rax
    8546:	75 14                	jne    855c <f12+0x2cc>
    8548:	e9 f0 0f 00 00       	jmp    953d <f12+0x12ad>
    854d:	0f 1f 00             	nopl   (%rax)
    8550:	48 8b 00             	mov    (%rax),%rax
    8553:	48 85 c0             	test   %rax,%rax
    8556:	0f 84 e1 0f 00 00    	je     953d <f12+0x12ad>
    855c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8560:	75 ee                	jne    8550 <f12+0x2c0>
    8562:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8566:	41 89 d8             	mov    %ebx,%r8d
    8569:	48 63 01             	movslq (%rcx),%rax
    856c:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    8571:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8576:	85 c0                	test   %eax,%eax
    8578:	78 09                	js     8583 <f12+0x2f3>
    857a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    857e:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8583:	44 89 01             	mov    %r8d,(%rcx)
    8586:	48 89 e8             	mov    %rbp,%rax
    8589:	31 c9                	xor    %ecx,%ecx
    858b:	48 85 ed             	test   %rbp,%rbp
    858e:	0f 84 74 0b 00 00    	je     9108 <f12+0xe78>
    8594:	90                   	nop
    8595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    859c:	00 00 00 00 
    85a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    85a4:	48 83 c1 01          	add    $0x1,%rcx
    85a8:	48 85 c0             	test   %rax,%rax
    85ab:	75 f3                	jne    85a0 <f12+0x310>
    85ad:	48 89 ea             	mov    %rbp,%rdx
    85b0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    85b4:	48 83 c0 01          	add    $0x1,%rax
    85b8:	48 85 d2             	test   %rdx,%rdx
    85bb:	75 f3                	jne    85b0 <f12+0x320>
    85bd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    85c4:	ff ff 1f 
    85c7:	48 39 c2             	cmp    %rax,%rdx
    85ca:	0f 82 44 0f 00 00    	jb     9514 <f12+0x1284>
    85d0:	48 85 c9             	test   %rcx,%rcx
    85d3:	0f 8e 2f 0b 00 00    	jle    9108 <f12+0xe78>
    85d9:	48 39 c1             	cmp    %rax,%rcx
    85dc:	48 0f 46 c1          	cmovbe %rcx,%rax
    85e0:	49 89 c5             	mov    %rax,%r13
    85e3:	48 c1 e8 3c          	shr    $0x3c,%rax
    85e7:	0f 85 27 0f 00 00    	jne    9514 <f12+0x1284>
    85ed:	48 c1 e6 10          	shl    $0x10,%rsi
    85f1:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    85f6:	48 09 fe             	or     %rdi,%rsi
    85f9:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8600:	00 
    8601:	49 89 f4             	mov    %rsi,%r12
    8604:	be 02 00 00 00       	mov    $0x2,%esi
    8609:	e8 42 d4 ff ff       	call   5a50 <fwp_heap_alloc>
    860e:	4c 89 30             	mov    %r14,(%rax)
    8611:	48 8b 15 40 c5 01 00 	mov    0x1c540(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8618:	48 89 c3             	mov    %rax,%rbx
    861b:	48 2b 05 0e c5 01 00 	sub    0x1c50e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8622:	48 c1 e2 10          	shl    $0x10,%rdx
    8626:	48 39 d0             	cmp    %rdx,%rax
    8629:	0f 83 59 0b 00 00    	jae    9188 <f12+0xef8>
    862f:	48 89 c2             	mov    %rax,%rdx
    8632:	48 c1 ea 10          	shr    $0x10,%rdx
    8636:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    863a:	48 8b 15 37 c5 01 00 	mov    0x1c537(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8641:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8645:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8649:	48 85 d2             	test   %rdx,%rdx
    864c:	74 38                	je     8686 <f12+0x3f6>
    864e:	0f b6 31             	movzbl (%rcx),%esi
    8651:	40 80 fe 02          	cmp    $0x2,%sil
    8655:	0f 84 1a 0b 00 00    	je     9175 <f12+0xee5>
    865b:	40 80 fe 01          	cmp    $0x1,%sil
    865f:	75 25                	jne    8686 <f12+0x3f6>
    8661:	8b 71 18             	mov    0x18(%rcx),%esi
    8664:	0f b7 c0             	movzwl %ax,%eax
    8667:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    866a:	48 0f af c6          	imul   %rsi,%rax
    866e:	48 c1 e8 20          	shr    $0x20,%rax
    8672:	48 39 c8             	cmp    %rcx,%rax
    8675:	73 0f                	jae    8686 <f12+0x3f6>
    8677:	48 01 c2             	add    %rax,%rdx
    867a:	80 3a ff             	cmpb   $0xff,(%rdx)
    867d:	0f 84 8b 0d 00 00    	je     940e <f12+0x117e>
    8683:	c6 02 01             	movb   $0x1,(%rdx)
    8686:	4d 85 ed             	test   %r13,%r13
    8689:	74 68                	je     86f3 <f12+0x463>
    868b:	4c 89 e1             	mov    %r12,%rcx
    868e:	48 89 ea             	mov    %rbp,%rdx
    8691:	31 c0                	xor    %eax,%eax
    8693:	48 c1 e1 20          	shl    $0x20,%rcx
    8697:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    869e:	00 
    869f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86a6:	00 00 00 00 
    86aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86b1:	00 00 00 00 
    86b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    86bc:	00 00 00 00 
    86c0:	48 89 c6             	mov    %rax,%rsi
    86c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    86c8:	48 01 ce             	add    %rcx,%rsi
    86cb:	0f 80 df 0d 00 00    	jo     94b0 <f12+0x1220>
    86d1:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    86d6:	48 89 c6             	mov    %rax,%rsi
    86d9:	48 83 c0 01          	add    $0x1,%rax
    86dd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    86e1:	48 c1 e6 04          	shl    $0x4,%rsi
    86e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    86ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    86ee:	4c 39 e8             	cmp    %r13,%rax
    86f1:	72 cd                	jb     86c0 <f12+0x430>
    86f3:	48 8b 03             	mov    (%rbx),%rax
    86f6:	48 d1 e8             	shr    $1,%rax
    86f9:	0f 84 a1 0a 00 00    	je     91a0 <f12+0xf10>
    86ff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8703:	48 89 d1             	mov    %rdx,%rcx
    8706:	48 c1 e9 3c          	shr    $0x3c,%rcx
    870a:	0f 85 04 0e 00 00    	jne    9514 <f12+0x1284>
    8710:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8714:	48 89 0c 24          	mov    %rcx,(%rsp)
    8718:	48 85 d2             	test   %rdx,%rdx
    871b:	74 41                	je     875e <f12+0x4ce>
    871d:	48 c1 e0 04          	shl    $0x4,%rax
    8721:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8725:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    872a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8730:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8735:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8739:	49 83 c6 10          	add    $0x10,%r14
    873d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8741:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8746:	e8 e5 d9 ff ff       	call   6130 <w107>
    874b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8750:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8754:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8759:	4d 39 f5             	cmp    %r14,%r13
    875c:	75 d2                	jne    8730 <f12+0x4a0>
    875e:	48 8b 04 24          	mov    (%rsp),%rax
    8762:	48 89 df             	mov    %rbx,%rdi
    8765:	48 89 03             	mov    %rax,(%rbx)
    8768:	e8 33 db ff ff       	call   62a0 <w164.constprop.0>
    876d:	48 89 df             	mov    %rbx,%rdi
    8770:	49 63 dc             	movslq %r12d,%rbx
    8773:	49 89 c5             	mov    %rax,%r13
    8776:	e8 05 ed ff ff       	call   7480 <fwp_drop4>
    877b:	48 89 df             	mov    %rbx,%rdi
    877e:	e8 fd bc ff ff       	call   4480 <fwp_tape_of>
    8783:	48 89 c6             	mov    %rax,%rsi
    8786:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    878b:	0f 85 9b 0d 00 00    	jne    952c <f12+0x129c>
    8791:	48 89 c7             	mov    %rax,%rdi
    8794:	e8 67 b4 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8799:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    879d:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    87a2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    87a9:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    87ad:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    87b1:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    87b6:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    87bb:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    87c0:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    87c4:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    87c8:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    87ce:	77 19                	ja     87e9 <f12+0x559>
    87d0:	41 0f b7 c4          	movzwl %r12w,%eax
    87d4:	83 e8 01             	sub    $0x1,%eax
    87d7:	48 98                	cltq
    87d9:	48 3b 05 18 a9 01 00 	cmp    0x1a918(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    87e0:	7d 07                	jge    87e9 <f12+0x559>
    87e2:	48 89 05 0f a9 01 00 	mov    %rax,0x1a90f(%rip)        # 230f8 <fwp_tape_next_slot>
    87e9:	48 8b 05 28 cc 01 00 	mov    0x1cc28(%rip),%rax        # 25418 <fwp_cleanups>
    87f0:	66 0f ef c9          	pxor   %xmm1,%xmm1
    87f4:	4c 8d a4 24 90 00 00 	lea    0x90(%rsp),%r12
    87fb:	00 
    87fc:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8803:	00 
    8804:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8808:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    880d:	48 8d 05 1c c6 ff ff 	lea    -0x39e4(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    8814:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
    8819:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    881e:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8822:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8826:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    882d:	00 
    882e:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8835:	00 
    8836:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    883d:	00 
    883e:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    8845:	00 
    8846:	48 89 05 cb cb 01 00 	mov    %rax,0x1cbcb(%rip)        # 25418 <fwp_cleanups>
    884d:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
    8854:	00 
    8855:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
    885c:	00 
    885d:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    8864:	00 
    8865:	4d 85 ed             	test   %r13,%r13
    8868:	0f 88 c2 09 00 00    	js     9230 <f12+0xfa0>
    886e:	4c 89 e8             	mov    %r13,%rax
    8871:	48 c1 f8 20          	sar    $0x20,%rax
    8875:	48 39 c3             	cmp    %rax,%rbx
    8878:	0f 85 1a 0c 00 00    	jne    9498 <f12+0x1208>
    887e:	45 89 ea             	mov    %r13d,%r10d
    8881:	4c 89 d3             	mov    %r10,%rbx
    8884:	4c 39 d7             	cmp    %r10,%rdi
    8887:	0f 8e ff 0b 00 00    	jle    948c <f12+0x11fc>
    888d:	4d 39 d6             	cmp    %r10,%r14
    8890:	0f 8e 1a 09 00 00    	jle    91b0 <f12+0xf20>
    8896:	49 39 d6             	cmp    %rdx,%r14
    8899:	0f 8e 59 0a 00 00    	jle    92f8 <f12+0x1068>
    889f:	4d 89 f1             	mov    %r14,%r9
    88a2:	48 85 d2             	test   %rdx,%rdx
    88a5:	49 0f 44 d1          	cmove  %r9,%rdx
    88a9:	eb 2a                	jmp    88d5 <f12+0x645>
    88ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88b2:	00 00 00 
    88b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88bc:	00 00 00 00 
    88c0:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    88c4:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    88cb:	4c 89 c8             	mov    %r9,%rax
    88ce:	48 0f 4c c6          	cmovl  %rsi,%rax
    88d2:	48 89 c2             	mov    %rax,%rdx
    88d5:	4c 39 ca             	cmp    %r9,%rdx
    88d8:	7c e6                	jl     88c0 <f12+0x630>
    88da:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    88df:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    88e4:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    88e9:	48 85 c9             	test   %rcx,%rcx
    88ec:	0f 84 7e 0a 00 00    	je     9370 <f12+0x10e0>
    88f2:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    88f9:	00 
    88fa:	48 89 cf             	mov    %rcx,%rdi
    88fd:	48 89 14 24          	mov    %rdx,(%rsp)
    8901:	e8 ca ac ff ff       	call   35d0 <realloc@plt>
    8906:	48 8b 14 24          	mov    (%rsp),%rdx
    890a:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    8910:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8916:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    891b:	48 89 c1             	mov    %rax,%rcx
    891e:	48 85 c9             	test   %rcx,%rcx
    8921:	0f 84 96 0b 00 00    	je     94bd <f12+0x122d>
    8927:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    892e:	00 
    892f:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
    8936:	00 
    8937:	4d 85 c9             	test   %r9,%r9
    893a:	0f 85 12 0b 00 00    	jne    9452 <f12+0x11c2>
    8940:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8947:	4d 85 ed             	test   %r13,%r13
    894a:	78 17                	js     8963 <f12+0x6d3>
    894c:	45 89 ea             	mov    %r13d,%r10d
    894f:	f2 0f 10 05 d9 71 00 	movsd  0x71d9(%rip),%xmm0        # fb30 <msg.4+0xb0>
    8956:	00 
    8957:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    895d:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    8963:	4c 39 f3             	cmp    %r14,%rbx
    8966:	0f 8c 8e 00 00 00    	jl     89fa <f12+0x76a>
    896c:	0f 12 fb             	movhlps %xmm3,%xmm7
    896f:	66 49 0f 7e d2       	movq   %xmm2,%r10
    8974:	66 48 0f 7e de       	movq   %xmm3,%rsi
    8979:	4c 29 f3             	sub    %r14,%rbx
    897c:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    8981:	0f 12 fa             	movhlps %xmm2,%xmm7
    8984:	4e 8d 0c f1          	lea    (%rcx,%r14,8),%r9
    8988:	66 49 0f 7e fb       	movq   %xmm7,%r11
    898d:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    8991:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8995:	48 29 fe             	sub    %rdi,%rsi
    8998:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    899c:	4d 29 d9             	sub    %r11,%r9
    899f:	4d 29 da             	sub    %r11,%r10
    89a2:	eb 08                	jmp    89ac <f12+0x71c>
    89a4:	0f 1f 40 00          	nopl   0x0(%rax)
    89a8:	48 83 e8 04          	sub    $0x4,%rax
    89ac:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    89b2:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    89b6:	7a 02                	jp     89ba <f12+0x72a>
    89b8:	74 37                	je     89f1 <f12+0x761>
    89ba:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    89be:	45 85 db             	test   %r11d,%r11d
    89c1:	78 16                	js     89d9 <f12+0x749>
    89c3:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    89c9:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    89cd:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    89d3:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    89d9:	4c 63 18             	movslq (%rax),%r11
    89dc:	45 85 db             	test   %r11d,%r11d
    89df:	78 10                	js     89f1 <f12+0x761>
    89e1:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    89e5:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    89eb:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    89f1:	48 83 ea 08          	sub    $0x8,%rdx
    89f5:	48 39 c7             	cmp    %rax,%rdi
    89f8:	75 ae                	jne    89a8 <f12+0x718>
    89fa:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8a01:	ff ff 1f 
    8a04:	4c 39 f0             	cmp    %r14,%rax
    8a07:	0f 82 fb 0a 00 00    	jb     9508 <f12+0x1278>
    8a0d:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8a14:	00 
    8a15:	be 02 00 00 00       	mov    $0x2,%esi
    8a1a:	48 89 0c 24          	mov    %rcx,(%rsp)
    8a1e:	e8 2d d0 ff ff       	call   5a50 <fwp_heap_alloc>
    8a23:	48 8b 0c 24          	mov    (%rsp),%rcx
    8a27:	4c 89 30             	mov    %r14,(%rax)
    8a2a:	49 89 c5             	mov    %rax,%r13
    8a2d:	31 c0                	xor    %eax,%eax
    8a2f:	4d 85 f6             	test   %r14,%r14
    8a32:	74 1e                	je     8a52 <f12+0x7c2>
    8a34:	90                   	nop
    8a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a3c:	00 00 00 00 
    8a40:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8a44:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8a49:	48 83 c0 01          	add    $0x1,%rax
    8a4d:	49 39 c6             	cmp    %rax,%r14
    8a50:	75 ee                	jne    8a40 <f12+0x7b0>
    8a52:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    8a57:	4c 89 e7             	mov    %r12,%rdi
    8a5a:	48 89 0d b7 c9 01 00 	mov    %rcx,0x1c9b7(%rip)        # 25418 <fwp_cleanups>
    8a61:	48 89 0c 24          	mov    %rcx,(%rsp)
    8a65:	e8 c6 c3 ff ff       	call   4e30 <fwp_tape_buffers_release>
    8a6a:	48 8b 15 e7 c0 01 00 	mov    0x1c0e7(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8a71:	4c 89 e8             	mov    %r13,%rax
    8a74:	48 8b 0c 24          	mov    (%rsp),%rcx
    8a78:	48 2b 05 b1 c0 01 00 	sub    0x1c0b1(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8a7f:	48 c1 e2 10          	shl    $0x10,%rdx
    8a83:	48 39 d0             	cmp    %rdx,%rax
    8a86:	73 57                	jae    8adf <f12+0x84f>
    8a88:	48 89 c2             	mov    %rax,%rdx
    8a8b:	48 c1 ea 10          	shr    $0x10,%rdx
    8a8f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8a93:	48 8b 15 de c0 01 00 	mov    0x1c0de(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8a9a:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8a9e:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8aa2:	48 85 db             	test   %rbx,%rbx
    8aa5:	74 38                	je     8adf <f12+0x84f>
    8aa7:	0f b6 32             	movzbl (%rdx),%esi
    8aaa:	40 80 fe 02          	cmp    $0x2,%sil
    8aae:	0f 84 ac 07 00 00    	je     9260 <f12+0xfd0>
    8ab4:	40 80 fe 01          	cmp    $0x1,%sil
    8ab8:	75 25                	jne    8adf <f12+0x84f>
    8aba:	8b 72 18             	mov    0x18(%rdx),%esi
    8abd:	0f b7 c0             	movzwl %ax,%eax
    8ac0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ac3:	48 0f af c6          	imul   %rsi,%rax
    8ac7:	48 c1 e8 20          	shr    $0x20,%rax
    8acb:	48 39 d0             	cmp    %rdx,%rax
    8ace:	73 0f                	jae    8adf <f12+0x84f>
    8ad0:	48 01 c3             	add    %rax,%rbx
    8ad3:	80 3b ff             	cmpb   $0xff,(%rbx)
    8ad6:	0f 84 47 09 00 00    	je     9423 <f12+0x1193>
    8adc:	c6 03 01             	movb   $0x1,(%rbx)
    8adf:	4c 39 f9             	cmp    %r15,%rcx
    8ae2:	0f 85 63 ac ff ff    	jne    374b <f12.cold>
    8ae8:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    8aed:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8af2:	48 89 05 1f c9 01 00 	mov    %rax,0x1c91f(%rip)        # 25418 <fwp_cleanups>
    8af9:	e8 a2 e3 ff ff       	call   6ea0 <fwp_tape_scope_release>
    8afe:	49 8b 45 00          	mov    0x0(%r13),%rax
    8b02:	49 89 c4             	mov    %rax,%r12
    8b05:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8b0a:	48 85 c0             	test   %rax,%rax
    8b0d:	0f 88 2d 05 00 00    	js     9040 <f12+0xdb0>
    8b13:	48 8b 15 3e c0 01 00 	mov    0x1c03e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8b1a:	4c 89 e8             	mov    %r13,%rax
    8b1d:	48 2b 05 0c c0 01 00 	sub    0x1c00c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8b24:	48 c1 e2 10          	shl    $0x10,%rdx
    8b28:	48 39 d0             	cmp    %rdx,%rax
    8b2b:	0f 83 0f 05 00 00    	jae    9040 <f12+0xdb0>
    8b31:	48 89 c2             	mov    %rax,%rdx
    8b34:	48 c1 ea 10          	shr    $0x10,%rdx
    8b38:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b3c:	48 8b 15 35 c0 01 00 	mov    0x1c035(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8b43:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b47:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8b4b:	48 85 c9             	test   %rcx,%rcx
    8b4e:	0f 84 ec 04 00 00    	je     9040 <f12+0xdb0>
    8b54:	0f b6 32             	movzbl (%rdx),%esi
    8b57:	40 80 fe 02          	cmp    $0x2,%sil
    8b5b:	0f 84 cf 04 00 00    	je     9030 <f12+0xda0>
    8b61:	40 80 fe 01          	cmp    $0x1,%sil
    8b65:	0f 85 d5 04 00 00    	jne    9040 <f12+0xdb0>
    8b6b:	8b 72 18             	mov    0x18(%rdx),%esi
    8b6e:	0f b7 c0             	movzwl %ax,%eax
    8b71:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b74:	48 0f af c6          	imul   %rsi,%rax
    8b78:	48 c1 e8 20          	shr    $0x20,%rax
    8b7c:	48 39 d0             	cmp    %rdx,%rax
    8b7f:	0f 83 bb 04 00 00    	jae    9040 <f12+0xdb0>
    8b85:	48 01 c1             	add    %rax,%rcx
    8b88:	80 39 01             	cmpb   $0x1,(%rcx)
    8b8b:	0f 85 af 04 00 00    	jne    9040 <f12+0xdb0>
    8b91:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    8b96:	4d 89 ef             	mov    %r13,%r15
    8b99:	31 ff                	xor    %edi,%edi
    8b9b:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    8ba0:	f2 0f 10 0d 98 6f 00 	movsd  0x6f98(%rip),%xmm1        # fb40 <msg.4+0xc0>
    8ba7:	00 
    8ba8:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8bac:	31 c0                	xor    %eax,%eax
    8bae:	4d 85 e4             	test   %r12,%r12
    8bb1:	75 2a                	jne    8bdd <f12+0x94d>
    8bb3:	eb 4b                	jmp    8c00 <f12+0x970>
    8bb5:	0f 1f 00             	nopl   (%rax)
    8bb8:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8bbc:	0f 88 e2 08 00 00    	js     94a4 <f12+0x1214>
    8bc2:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8bc7:	48 83 c0 01          	add    $0x1,%rax
    8bcb:	48 83 c2 08          	add    $0x8,%rdx
    8bcf:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8bd3:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8bd8:	49 39 c4             	cmp    %rax,%r12
    8bdb:	74 23                	je     8c00 <f12+0x970>
    8bdd:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8be1:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8be6:	79 d0                	jns    8bb8 <f12+0x928>
    8be8:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8bec:	eb ca                	jmp    8bb8 <f12+0x928>
    8bee:	66 90                	xchg   %ax,%ax
    8bf0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8bf4:	0f 84 0b f9 ff ff    	je     8505 <f12+0x275>
    8bfa:	e9 f8 f8 ff ff       	jmp    84f7 <f12+0x267>
    8bff:	90                   	nop
    8c00:	e8 7b e8 ff ff       	call   7480 <fwp_drop4>
    8c05:	48 89 e8             	mov    %rbp,%rax
    8c08:	31 d2                	xor    %edx,%edx
    8c0a:	48 85 ed             	test   %rbp,%rbp
    8c0d:	0f 84 94 07 00 00    	je     93a7 <f12+0x1117>
    8c13:	66 90                	xchg   %ax,%ax
    8c15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c1c:	00 00 00 00 
    8c20:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c24:	48 83 c2 01          	add    $0x1,%rdx
    8c28:	48 85 c0             	test   %rax,%rax
    8c2b:	75 f3                	jne    8c20 <f12+0x990>
    8c2d:	49 8b 07             	mov    (%r15),%rax
    8c30:	49 89 c5             	mov    %rax,%r13
    8c33:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8c38:	48 85 c0             	test   %rax,%rax
    8c3b:	0f 88 51 03 00 00    	js     8f92 <f12+0xd02>
    8c41:	48 8b 05 10 bf 01 00 	mov    0x1bf10(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    8c48:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    8c4d:	48 2b 0d dc be 01 00 	sub    0x1bedc(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    8c54:	48 c1 e0 10          	shl    $0x10,%rax
    8c58:	48 39 c1             	cmp    %rax,%rcx
    8c5b:	0f 83 31 03 00 00    	jae    8f92 <f12+0xd02>
    8c61:	48 89 c8             	mov    %rcx,%rax
    8c64:	48 c1 e8 10          	shr    $0x10,%rax
    8c68:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8c6c:	48 8b 05 05 bf 01 00 	mov    0x1bf05(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    8c73:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8c77:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8c7b:	48 85 ff             	test   %rdi,%rdi
    8c7e:	0f 84 0e 03 00 00    	je     8f92 <f12+0xd02>
    8c84:	0f b6 06             	movzbl (%rsi),%eax
    8c87:	3c 02                	cmp    $0x2,%al
    8c89:	0f 84 f1 02 00 00    	je     8f80 <f12+0xcf0>
    8c8f:	3c 01                	cmp    $0x1,%al
    8c91:	0f 85 f2 02 00 00    	jne    8f89 <f12+0xcf9>
    8c97:	8b 46 18             	mov    0x18(%rsi),%eax
    8c9a:	0f b7 c9             	movzwl %cx,%ecx
    8c9d:	48 0f af c8          	imul   %rax,%rcx
    8ca1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8ca4:	48 c1 e9 20          	shr    $0x20,%rcx
    8ca8:	48 39 c1             	cmp    %rax,%rcx
    8cab:	0f 83 d8 02 00 00    	jae    8f89 <f12+0xcf9>
    8cb1:	48 01 cf             	add    %rcx,%rdi
    8cb4:	80 3f 01             	cmpb   $0x1,(%rdi)
    8cb7:	0f 85 cc 02 00 00    	jne    8f89 <f12+0xcf9>
    8cbd:	4c 39 ea             	cmp    %r13,%rdx
    8cc0:	4c 89 e8             	mov    %r13,%rax
    8cc3:	48 0f 46 c2          	cmovbe %rdx,%rax
    8cc7:	48 85 c0             	test   %rax,%rax
    8cca:	0f 84 e5 07 00 00    	je     94b5 <f12+0x1225>
    8cd0:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    8cd7:	00 
    8cd8:	4d 8d 77 08          	lea    0x8(%r15),%r14
    8cdc:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
    8ce1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8ce8:	00 
    8ce9:	48 89 e9             	mov    %rbp,%rcx
    8cec:	31 d2                	xor    %edx,%edx
    8cee:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8cf2:	eb 29                	jmp    8d1d <f12+0xa8d>
    8cf4:	90                   	nop
    8cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cfc:	00 00 00 00 
    8d00:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8d05:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    8d0a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8d10:	48 83 c2 08          	add    $0x8,%rdx
    8d14:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8d18:	49 39 d0             	cmp    %rdx,%r8
    8d1b:	74 1b                	je     8d38 <f12+0xaa8>
    8d1d:	48 89 fe             	mov    %rdi,%rsi
    8d20:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8d24:	79 da                	jns    8d00 <f12+0xa70>
    8d26:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
    8d2b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    8d2f:	eb cf                	jmp    8d00 <f12+0xa70>
    8d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d38:	48 85 ed             	test   %rbp,%rbp
    8d3b:	0f 84 43 07 00 00    	je     9484 <f12+0x11f4>
    8d41:	4c 8b 05 10 be 01 00 	mov    0x1be10(%rip),%r8        # 24b58 <fwp_heap+0x13d8>
    8d48:	4c 8b 0d e1 bd 01 00 	mov    0x1bde1(%rip),%r9        # 24b30 <fwp_heap+0x13b0>
    8d4f:	48 89 e9             	mov    %rbp,%rcx
    8d52:	45 31 ed             	xor    %r13d,%r13d
    8d55:	4c 8b 15 1c be 01 00 	mov    0x1be1c(%rip),%r10        # 24b78 <fwp_heap+0x13f8>
    8d5c:	49 c1 e0 10          	shl    $0x10,%r8
    8d60:	eb 1c                	jmp    8d7e <f12+0xaee>
    8d62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d68:	49 83 c5 01          	add    $0x1,%r13
    8d6c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8d70:	49 39 c5             	cmp    %rax,%r13
    8d73:	0f 83 67 01 00 00    	jae    8ee0 <f12+0xc50>
    8d79:	48 85 c9             	test   %rcx,%rcx
    8d7c:	74 56                	je     8dd4 <f12+0xb44>
    8d7e:	48 89 ca             	mov    %rcx,%rdx
    8d81:	4c 29 ca             	sub    %r9,%rdx
    8d84:	4c 39 c2             	cmp    %r8,%rdx
    8d87:	73 4b                	jae    8dd4 <f12+0xb44>
    8d89:	48 89 d6             	mov    %rdx,%rsi
    8d8c:	48 c1 ee 10          	shr    $0x10,%rsi
    8d90:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8d94:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8d98:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8d9c:	48 85 ff             	test   %rdi,%rdi
    8d9f:	74 33                	je     8dd4 <f12+0xb44>
    8da1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8da5:	41 80 fb 02          	cmp    $0x2,%r11b
    8da9:	0f 84 19 01 00 00    	je     8ec8 <f12+0xc38>
    8daf:	41 80 fb 01          	cmp    $0x1,%r11b
    8db3:	75 1f                	jne    8dd4 <f12+0xb44>
    8db5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8db9:	0f b7 d2             	movzwl %dx,%edx
    8dbc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8dbf:	49 0f af d3          	imul   %r11,%rdx
    8dc3:	48 c1 ea 20          	shr    $0x20,%rdx
    8dc7:	48 39 f2             	cmp    %rsi,%rdx
    8dca:	73 08                	jae    8dd4 <f12+0xb44>
    8dcc:	48 01 d7             	add    %rdx,%rdi
    8dcf:	80 3f 01             	cmpb   $0x1,(%rdi)
    8dd2:	74 94                	je     8d68 <f12+0xad8>
    8dd4:	49 39 c5             	cmp    %rax,%r13
    8dd7:	0f 83 03 01 00 00    	jae    8ee0 <f12+0xc50>
    8ddd:	49 89 c7             	mov    %rax,%r15
    8de0:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    8de7:	00 
    8de8:	45 31 e4             	xor    %r12d,%r12d
    8deb:	48 89 04 24          	mov    %rax,(%rsp)
    8def:	48 8d 1d 8a a9 01 00 	lea    0x1a98a(%rip),%rbx        # 23780 <fwp_heap>
    8df6:	eb 3a                	jmp    8e32 <f12+0xba2>
    8df8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8dff:	00 
    8e00:	41 80 f9 01          	cmp    $0x1,%r9b
    8e04:	75 27                	jne    8e2d <f12+0xb9d>
    8e06:	45 8b 48 18          	mov    0x18(%r8),%r9d
    8e0a:	0f b7 c0             	movzwl %ax,%eax
    8e0d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8e11:	49 0f af c1          	imul   %r9,%rax
    8e15:	48 c1 e8 20          	shr    $0x20,%rax
    8e19:	4c 39 c0             	cmp    %r8,%rax
    8e1c:	73 0f                	jae    8e2d <f12+0xb9d>
    8e1e:	48 01 c7             	add    %rax,%rdi
    8e21:	80 3f ff             	cmpb   $0xff,(%rdi)
    8e24:	0f 84 c6 02 00 00    	je     90f0 <f12+0xe60>
    8e2a:	c6 07 01             	movb   $0x1,(%rdi)
    8e2d:	4d 39 fd             	cmp    %r15,%r13
    8e30:	73 7e                	jae    8eb0 <f12+0xc20>
    8e32:	49 83 ef 01          	sub    $0x1,%r15
    8e36:	66 49 0f 6e f4       	movq   %r12,%xmm6
    8e3b:	48 8b 34 24          	mov    (%rsp),%rsi
    8e3f:	bf 01 00 00 00       	mov    $0x1,%edi
    8e44:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    8e4a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8e4e:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    8e55:	00 
    8e56:	e8 c5 d4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    8e5b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    8e62:	49 89 c4             	mov    %rax,%r12
    8e65:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8e6c:	48 c1 e7 10          	shl    $0x10,%rdi
    8e70:	48 39 f8             	cmp    %rdi,%rax
    8e73:	73 b8                	jae    8e2d <f12+0xb9d>
    8e75:	48 89 c7             	mov    %rax,%rdi
    8e78:	48 c1 ef 10          	shr    $0x10,%rdi
    8e7c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8e80:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8e87:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    8e8b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    8e8f:	48 85 ff             	test   %rdi,%rdi
    8e92:	74 99                	je     8e2d <f12+0xb9d>
    8e94:	45 0f b6 08          	movzbl (%r8),%r9d
    8e98:	41 80 f9 02          	cmp    $0x2,%r9b
    8e9c:	0f 85 5e ff ff ff    	jne    8e00 <f12+0xb70>
    8ea2:	66 85 c0             	test   %ax,%ax
    8ea5:	0f 84 76 ff ff ff    	je     8e21 <f12+0xb91>
    8eab:	4d 39 fd             	cmp    %r15,%r13
    8eae:	72 82                	jb     8e32 <f12+0xba2>
    8eb0:	4d 85 ed             	test   %r13,%r13
    8eb3:	75 2e                	jne    8ee3 <f12+0xc53>
    8eb5:	8b 44 24 10          	mov    0x10(%rsp),%eax
    8eb9:	85 c0                	test   %eax,%eax
    8ebb:	4d 0f 45 f5          	cmovne %r13,%r14
    8ebf:	eb 6f                	jmp    8f30 <f12+0xca0>
    8ec1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ec8:	66 85 d2             	test   %dx,%dx
    8ecb:	0f 84 fe fe ff ff    	je     8dcf <f12+0xb3f>
    8ed1:	49 39 c5             	cmp    %rax,%r13
    8ed4:	0f 82 03 ff ff ff    	jb     8ddd <f12+0xb4d>
    8eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ee0:	45 31 e4             	xor    %r12d,%r12d
    8ee3:	4c 89 f2             	mov    %r14,%rdx
    8ee6:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    8eea:	48 89 e8             	mov    %rbp,%rax
    8eed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8ef4:	00 
    8ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8efc:	00 00 00 00 
    8f00:	48 8b 0a             	mov    (%rdx),%rcx
    8f03:	48 83 c2 08          	add    $0x8,%rdx
    8f07:	48 89 c7             	mov    %rax,%rdi
    8f0a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8f0e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8f12:	4c 39 c2             	cmp    %r8,%rdx
    8f15:	75 e9                	jne    8f00 <f12+0xc70>
    8f17:	8b 54 24 10          	mov    0x10(%rsp),%edx
    8f1b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    8f1f:	85 d2                	test   %edx,%edx
    8f21:	0f 84 49 03 00 00    	je     9270 <f12+0xfe0>
    8f27:	49 89 ec             	mov    %rbp,%r12
    8f2a:	45 31 f6             	xor    %r14d,%r14d
    8f2d:	48 89 c5             	mov    %rax,%rbp
    8f30:	4c 89 f7             	mov    %r14,%rdi
    8f33:	e8 18 c6 ff ff       	call   5550 <fwp_mem_free>
    8f38:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8f3d:	e8 3e e5 ff ff       	call   7480 <fwp_drop4>
    8f42:	48 89 ef             	mov    %rbp,%rdi
    8f45:	e8 46 d9 ff ff       	call   6890 <fwp_drop0>
    8f4a:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
    8f51:	00 
    8f52:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f59:	00 00 
    8f5b:	0f 85 d7 05 00 00    	jne    9538 <f12+0x12a8>
    8f61:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
    8f68:	4c 89 e0             	mov    %r12,%rax
    8f6b:	5b                   	pop    %rbx
    8f6c:	5d                   	pop    %rbp
    8f6d:	41 5c                	pop    %r12
    8f6f:	41 5d                	pop    %r13
    8f71:	41 5e                	pop    %r14
    8f73:	41 5f                	pop    %r15
    8f75:	c3                   	ret
    8f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f7d:	00 00 00 
    8f80:	66 85 c9             	test   %cx,%cx
    8f83:	0f 84 2b fd ff ff    	je     8cb4 <f12+0xa24>
    8f89:	48 85 ed             	test   %rbp,%rbp
    8f8c:	0f 84 ab 03 00 00    	je     933d <f12+0x10ad>
    8f92:	48 89 e8             	mov    %rbp,%rax
    8f95:	45 31 e4             	xor    %r12d,%r12d
    8f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f9f:	00 
    8fa0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8fa4:	4c 89 e2             	mov    %r12,%rdx
    8fa7:	49 83 c4 01          	add    $0x1,%r12
    8fab:	48 85 c0             	test   %rax,%rax
    8fae:	75 f0                	jne    8fa0 <f12+0xd10>
    8fb0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8fb7:	ff ff 1f 
    8fba:	4c 39 e0             	cmp    %r12,%rax
    8fbd:	0f 82 51 05 00 00    	jb     9514 <f12+0x1284>
    8fc3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8fca:	00 
    8fcb:	be 02 00 00 00       	mov    $0x2,%esi
    8fd0:	e8 7b ca ff ff       	call   5a50 <fwp_heap_alloc>
    8fd5:	4d 39 e5             	cmp    %r12,%r13
    8fd8:	48 89 ea             	mov    %rbp,%rdx
    8fdb:	49 89 c6             	mov    %rax,%r14
    8fde:	4c 89 e0             	mov    %r12,%rax
    8fe1:	49 0f 46 c5          	cmovbe %r13,%rax
    8fe5:	4c 89 f1             	mov    %r14,%rcx
    8fe8:	66 90                	xchg   %ax,%ax
    8fea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ff1:	00 00 00 00 
    8ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ffc:	00 00 00 00 
    9000:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9004:	48 83 c1 08          	add    $0x8,%rcx
    9008:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    900c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9010:	48 85 d2             	test   %rdx,%rdx
    9013:	75 eb                	jne    9000 <f12+0xd70>
    9015:	48 85 c0             	test   %rax,%rax
    9018:	0f 84 31 03 00 00    	je     934f <f12+0x10bf>
    901e:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    9025:	00 
    9026:	e9 b1 fc ff ff       	jmp    8cdc <f12+0xa4c>
    902b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9030:	66 85 c0             	test   %ax,%ax
    9033:	0f 84 4f fb ff ff    	je     8b88 <f12+0x8f8>
    9039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9040:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9047:	ff ff 1f 
    904a:	4c 39 e0             	cmp    %r12,%rax
    904d:	0f 82 b5 04 00 00    	jb     9508 <f12+0x1278>
    9053:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    905a:	00 
    905b:	be 01 00 00 00       	mov    $0x1,%esi
    9060:	e8 eb c9 ff ff       	call   5a50 <fwp_heap_alloc>
    9065:	4c 89 20             	mov    %r12,(%rax)
    9068:	48 8b 15 e9 ba 01 00 	mov    0x1bae9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    906f:	49 89 c7             	mov    %rax,%r15
    9072:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9077:	48 2b 05 b2 ba 01 00 	sub    0x1bab2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    907e:	48 c1 e2 10          	shl    $0x10,%rdx
    9082:	48 39 d0             	cmp    %rdx,%rax
    9085:	73 57                	jae    90de <f12+0xe4e>
    9087:	48 89 c2             	mov    %rax,%rdx
    908a:	48 c1 ea 10          	shr    $0x10,%rdx
    908e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9092:	48 8b 15 df ba 01 00 	mov    0x1badf(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    9099:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    909d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    90a1:	4d 85 f6             	test   %r14,%r14
    90a4:	74 38                	je     90de <f12+0xe4e>
    90a6:	0f b6 0a             	movzbl (%rdx),%ecx
    90a9:	80 f9 02             	cmp    $0x2,%cl
    90ac:	0f 84 ae 02 00 00    	je     9360 <f12+0x10d0>
    90b2:	80 f9 01             	cmp    $0x1,%cl
    90b5:	75 27                	jne    90de <f12+0xe4e>
    90b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    90ba:	0f b7 c0             	movzwl %ax,%eax
    90bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90c0:	48 0f af c1          	imul   %rcx,%rax
    90c4:	48 c1 e8 20          	shr    $0x20,%rax
    90c8:	48 39 d0             	cmp    %rdx,%rax
    90cb:	73 11                	jae    90de <f12+0xe4e>
    90cd:	49 01 c6             	add    %rax,%r14
    90d0:	41 80 3e ff          	cmpb   $0xff,(%r14)
    90d4:	0f 84 5e 03 00 00    	je     9438 <f12+0x11a8>
    90da:	41 c6 06 01          	movb   $0x1,(%r14)
    90de:	4c 89 ef             	mov    %r13,%rdi
    90e1:	e9 b5 fa ff ff       	jmp    8b9b <f12+0x90b>
    90e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    90ed:	00 00 00 
    90f0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    90f5:	e8 16 c2 ff ff       	call   5310 <fwp_rc_forget_slot>
    90fa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    90ff:	e9 26 fd ff ff       	jmp    8e2a <f12+0xb9a>
    9104:	0f 1f 40 00          	nopl   0x0(%rax)
    9108:	48 c1 e6 10          	shl    $0x10,%rsi
    910c:	48 09 fe             	or     %rdi,%rsi
    910f:	bf 08 00 00 00       	mov    $0x8,%edi
    9114:	49 89 f4             	mov    %rsi,%r12
    9117:	be 02 00 00 00       	mov    $0x2,%esi
    911c:	e8 2f c9 ff ff       	call   5a50 <fwp_heap_alloc>
    9121:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9128:	48 8b 15 29 ba 01 00 	mov    0x1ba29(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    912f:	48 89 c3             	mov    %rax,%rbx
    9132:	48 2b 05 f7 b9 01 00 	sub    0x1b9f7(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    9139:	48 c1 e2 10          	shl    $0x10,%rdx
    913d:	48 39 d0             	cmp    %rdx,%rax
    9140:	73 5e                	jae    91a0 <f12+0xf10>
    9142:	48 89 c2             	mov    %rax,%rdx
    9145:	48 c1 ea 10          	shr    $0x10,%rdx
    9149:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    914d:	48 8b 15 24 ba 01 00 	mov    0x1ba24(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    9154:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9158:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    915c:	48 85 d2             	test   %rdx,%rdx
    915f:	0f 84 8e f5 ff ff    	je     86f3 <f12+0x463>
    9165:	0f b6 31             	movzbl (%rcx),%esi
    9168:	45 31 ed             	xor    %r13d,%r13d
    916b:	40 80 fe 02          	cmp    $0x2,%sil
    916f:	0f 85 e6 f4 ff ff    	jne    865b <f12+0x3cb>
    9175:	66 85 c0             	test   %ax,%ax
    9178:	0f 85 08 f5 ff ff    	jne    8686 <f12+0x3f6>
    917e:	e9 f7 f4 ff ff       	jmp    867a <f12+0x3ea>
    9183:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9188:	4d 85 ed             	test   %r13,%r13
    918b:	0f 85 fa f4 ff ff    	jne    868b <f12+0x3fb>
    9191:	0f 1f 40 00          	nopl   0x0(%rax)
    9195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    919c:	00 00 00 00 
    91a0:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    91a7:	00 
    91a8:	e9 b1 f5 ff ff       	jmp    875e <f12+0x4ce>
    91ad:	0f 1f 00             	nopl   (%rax)
    91b0:	4d 8d 4a 01          	lea    0x1(%r10),%r9
    91b4:	4c 39 ca             	cmp    %r9,%rdx
    91b7:	0f 8c e5 f6 ff ff    	jl     88a2 <f12+0x612>
    91bd:	48 85 c9             	test   %rcx,%rcx
    91c0:	0f 84 00 03 00 00    	je     94c6 <f12+0x1236>
    91c6:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    91cb:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    91d2:	00 
    91d3:	31 f6                	xor    %esi,%esi
    91d5:	48 89 cf             	mov    %rcx,%rdi
    91d8:	0f 29 14 24          	movaps %xmm2,(%rsp)
    91dc:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    91e1:	e9 3a 01 00 00       	jmp    9320 <f12+0x1090>
    91e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91ed:	00 00 00 
    91f0:	48 8d 3d c9 db ff ff 	lea    -0x2437(%rip),%rdi        # 6dc0 <fwp_tape_finish>
    91f7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    91fc:	e8 4f 56 00 00       	call   e850 <atexit>
    9201:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9206:	85 c0                	test   %eax,%eax
    9208:	0f 85 cc 02 00 00    	jne    94da <f12+0x124a>
    920e:	c7 05 68 9e 00 00 01 	movl   $0x1,0x9e68(%rip)        # 13080 <registered_finish.0>
    9215:	00 00 00 
    9218:	e9 a0 f1 ff ff       	jmp    83bd <f12+0x12d>
    921d:	0f 1f 00             	nopl   (%rax)
    9220:	66 85 c0             	test   %ax,%ax
    9223:	0f 85 42 f1 ff ff    	jne    836b <f12+0xdb>
    9229:	e9 29 f1 ff ff       	jmp    8357 <f12+0xc7>
    922e:	66 90                	xchg   %ax,%ax
    9230:	49 39 d6             	cmp    %rdx,%r14
    9233:	0f 8f 66 f6 ff ff    	jg     889f <f12+0x60f>
    9239:	4d 85 f6             	test   %r14,%r14
    923c:	74 12                	je     9250 <f12+0xfc0>
    923e:	48 85 c9             	test   %rcx,%rcx
    9241:	0f 84 7f 02 00 00    	je     94c6 <f12+0x1236>
    9247:	4d 85 f6             	test   %r14,%r14
    924a:	0f 85 ff 01 00 00    	jne    944f <f12+0x11bf>
    9250:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    9257:	e9 07 f7 ff ff       	jmp    8963 <f12+0x6d3>
    925c:	0f 1f 40 00          	nopl   0x0(%rax)
    9260:	66 85 c0             	test   %ax,%ax
    9263:	0f 85 76 f8 ff ff    	jne    8adf <f12+0x84f>
    9269:	e9 65 f8 ff ff       	jmp    8ad3 <f12+0x843>
    926e:	66 90                	xchg   %ax,%ax
    9270:	49 89 ec             	mov    %rbp,%r12
    9273:	48 89 c5             	mov    %rax,%rbp
    9276:	e9 b5 fc ff ff       	jmp    8f30 <f12+0xca0>
    927b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9280:	66 0f 6f 0d 38 9e 01 	movdqa 0x19e38(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9287:	00 
    9288:	48 c7 05 15 9e 01 00 	movq   $0x0,0x19e15(%rip)        # 230a8 <fwp_tape_cached_bytes>
    928f:	00 00 00 00 
    9293:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9299:	48 8b 05 40 9e 01 00 	mov    0x19e40(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    92a0:	66 0f 6f 0d 28 9e 01 	movdqa 0x19e28(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    92a7:	00 
    92a8:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    92ad:	48 8b 05 34 9e 01 00 	mov    0x19e34(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    92b4:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    92ba:	66 0f ef c9          	pxor   %xmm1,%xmm1
    92be:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    92c3:	48 8b 05 26 9e 01 00 	mov    0x19e26(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    92ca:	0f 29 0d ef 9d 01 00 	movaps %xmm1,0x19def(%rip)        # 230c0 <fwp_tape_workspace>
    92d1:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    92d6:	0f 29 0d f3 9d 01 00 	movaps %xmm1,0x19df3(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    92dd:	48 c7 05 08 9e 01 00 	movq   $0x0,0x19e08(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    92e4:	00 00 00 00 
    92e8:	0f 29 0d f1 9d 01 00 	movaps %xmm1,0x19df1(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    92ef:	e9 11 f2 ff ff       	jmp    8505 <f12+0x275>
    92f4:	0f 1f 40 00          	nopl   0x0(%rax)
    92f8:	48 85 c9             	test   %rcx,%rcx
    92fb:	0f 84 c5 01 00 00    	je     94c6 <f12+0x1236>
    9301:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    9306:	49 8d 5e ff          	lea    -0x1(%r14),%rbx
    930a:	31 f6                	xor    %esi,%esi
    930c:	48 89 cf             	mov    %rcx,%rdi
    930f:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    9314:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    931b:	00 
    931c:	0f 29 14 24          	movaps %xmm2,(%rsp)
    9320:	e8 9b a1 ff ff       	call   34c0 <memset@plt>
    9325:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    932a:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    9330:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    9335:	48 89 c1             	mov    %rax,%rcx
    9338:	e9 12 f6 ff ff       	jmp    894f <f12+0x6bf>
    933d:	be 02 00 00 00       	mov    $0x2,%esi
    9342:	bf 08 00 00 00       	mov    $0x8,%edi
    9347:	e8 04 c7 ff ff       	call   5a50 <fwp_heap_alloc>
    934c:	49 89 c6             	mov    %rax,%r14
    934f:	45 31 e4             	xor    %r12d,%r12d
    9352:	e9 d9 fb ff ff       	jmp    8f30 <f12+0xca0>
    9357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    935e:	00 00 
    9360:	66 85 c0             	test   %ax,%ax
    9363:	0f 85 75 fd ff ff    	jne    90de <f12+0xe4e>
    9369:	e9 62 fd ff ff       	jmp    90d0 <f12+0xe40>
    936e:	66 90                	xchg   %ax,%ax
    9370:	48 89 d7             	mov    %rdx,%rdi
    9373:	be 08 00 00 00       	mov    $0x8,%esi
    9378:	48 89 14 24          	mov    %rdx,(%rsp)
    937c:	e8 9f a1 ff ff       	call   3520 <calloc@plt>
    9381:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    9386:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    938c:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    9392:	48 8b 14 24          	mov    (%rsp),%rdx
    9396:	48 89 c1             	mov    %rax,%rcx
    9399:	e9 80 f5 ff ff       	jmp    891e <f12+0x68e>
    939e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93a2:	e9 08 f0 ff ff       	jmp    83af <f12+0x11f>
    93a7:	49 8b 07             	mov    (%r15),%rax
    93aa:	48 85 c0             	test   %rax,%rax
    93ad:	78 8e                	js     933d <f12+0x10ad>
    93af:	48 8b 35 a2 b7 01 00 	mov    0x1b7a2(%rip),%rsi        # 24b58 <fwp_heap+0x13d8>
    93b6:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    93bb:	48 2b 0d 6e b7 01 00 	sub    0x1b76e(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    93c2:	48 c1 e6 10          	shl    $0x10,%rsi
    93c6:	48 39 f1             	cmp    %rsi,%rcx
    93c9:	0f 83 6e ff ff ff    	jae    933d <f12+0x10ad>
    93cf:	48 89 ce             	mov    %rcx,%rsi
    93d2:	48 c1 ee 10          	shr    $0x10,%rsi
    93d6:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    93da:	48 8b 35 97 b7 01 00 	mov    0x1b797(%rip),%rsi        # 24b78 <fwp_heap+0x13f8>
    93e1:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    93e5:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    93e9:	48 85 ff             	test   %rdi,%rdi
    93ec:	0f 84 4b ff ff ff    	je     933d <f12+0x10ad>
    93f2:	48 0f ba f0 3f       	btr    $0x3f,%rax
    93f7:	49 89 c5             	mov    %rax,%r13
    93fa:	e9 85 f8 ff ff       	jmp    8c84 <f12+0x9f4>
    93ff:	be 68 00 00 00       	mov    $0x68,%esi
    9404:	b9 01 00 00 00       	mov    $0x1,%ecx
    9409:	e9 2c f0 ff ff       	jmp    843a <f12+0x1aa>
    940e:	48 89 d7             	mov    %rdx,%rdi
    9411:	48 89 14 24          	mov    %rdx,(%rsp)
    9415:	e8 f6 be ff ff       	call   5310 <fwp_rc_forget_slot>
    941a:	48 8b 14 24          	mov    (%rsp),%rdx
    941e:	e9 60 f2 ff ff       	jmp    8683 <f12+0x3f3>
    9423:	48 89 df             	mov    %rbx,%rdi
    9426:	48 89 0c 24          	mov    %rcx,(%rsp)
    942a:	e8 e1 be ff ff       	call   5310 <fwp_rc_forget_slot>
    942f:	48 8b 0c 24          	mov    (%rsp),%rcx
    9433:	e9 a4 f6 ff ff       	jmp    8adc <f12+0x84c>
    9438:	4c 89 f7             	mov    %r14,%rdi
    943b:	e8 d0 be ff ff       	call   5310 <fwp_rc_forget_slot>
    9440:	e9 95 fc ff ff       	jmp    90da <f12+0xe4a>
    9445:	e8 a6 bd ff ff       	call   51f0 <fwp_rc_wide_dup>
    944a:	e9 1c ef ff ff       	jmp    836b <f12+0xdb>
    944f:	4d 89 f1             	mov    %r14,%r9
    9452:	48 89 cf             	mov    %rcx,%rdi
    9455:	31 f6                	xor    %esi,%esi
    9457:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    945c:	49 8d 59 ff          	lea    -0x1(%r9),%rbx
    9460:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    9467:	00 
    9468:	0f 29 14 24          	movaps %xmm2,(%rsp)
    946c:	e8 4f a0 ff ff       	call   34c0 <memset@plt>
    9471:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    9476:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    947c:	48 89 c1             	mov    %rax,%rcx
    947f:	e9 c3 f4 ff ff       	jmp    8947 <f12+0x6b7>
    9484:	45 31 ed             	xor    %r13d,%r13d
    9487:	e9 51 f9 ff ff       	jmp    8ddd <f12+0xb4d>
    948c:	48 8d 3d 71 5c 00 00 	lea    0x5c71(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    9493:	e8 08 ad ff ff       	call   41a0 <fwp_trap>
    9498:	48 8d 3d 21 63 00 00 	lea    0x6321(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    949f:	e8 fc ac ff ff       	call   41a0 <fwp_trap>
    94a4:	48 8d 3d 1d 64 00 00 	lea    0x641d(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    94ab:	e8 f0 ac ff ff       	call   41a0 <fwp_trap>
    94b0:	e8 4b a2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    94b5:	45 31 f6             	xor    %r14d,%r14d
    94b8:	e9 92 fe ff ff       	jmp    934f <f12+0x10bf>
    94bd:	4d 85 c9             	test   %r9,%r9
    94c0:	0f 84 7a f4 ff ff    	je     8940 <f12+0x6b0>
    94c6:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    94cb:	4c 89 e7             	mov    %r12,%rdi
    94ce:	48 89 05 43 bf 01 00 	mov    %rax,0x1bf43(%rip)        # 25418 <fwp_cleanups>
    94d5:	e8 56 b9 ff ff       	call   4e30 <fwp_tape_buffers_release>
    94da:	48 8b 0d 7f 9b 00 00 	mov    0x9b7f(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    94e1:	ba 13 00 00 00       	mov    $0x13,%edx
    94e6:	be 01 00 00 00       	mov    $0x1,%esi
    94eb:	48 8d 3d 16 5b 00 00 	lea    0x5b16(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    94f2:	e8 89 a1 ff ff       	call   3680 <fwrite@plt>
    94f7:	31 ff                	xor    %edi,%edi
    94f9:	e8 c2 a0 ff ff       	call   35c0 <fflush@plt>
    94fe:	bf 66 00 00 00       	mov    $0x66,%edi
    9503:	e8 98 a1 ff ff       	call   36a0 <_Exit@plt>
    9508:	48 8d 3d 46 5c 00 00 	lea    0x5c46(%rip),%rdi        # f155 <_IO_stdin_used+0x155>
    950f:	e8 8c ac ff ff       	call   41a0 <fwp_trap>
    9514:	48 8d 3d 12 5c 00 00 	lea    0x5c12(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    951b:	e8 80 ac ff ff       	call   41a0 <fwp_trap>
    9520:	48 8d 3d 14 5c 00 00 	lea    0x5c14(%rip),%rdi        # f13b <_IO_stdin_used+0x13b>
    9527:	e8 74 ac ff ff       	call   41a0 <fwp_trap>
    952c:	48 8d 3d d5 62 00 00 	lea    0x62d5(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    9533:	e8 68 ac ff ff       	call   41a0 <fwp_trap>
    9538:	e8 23 9f ff ff       	call   3460 <__stack_chk_fail@plt>
    953d:	48 8d 3d 54 63 00 00 	lea    0x6354(%rip),%rdi        # f898 <_IO_stdin_used+0x898>
    9544:	e8 57 ac ff ff       	call   41a0 <fwp_trap>
    9549:	48 8d 3d 18 63 00 00 	lea    0x6318(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    9550:	e8 4b ac ff ff       	call   41a0 <fwp_trap>
    9555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    955c:	00 00 00 00 

0000000000009560 <fwp_owned_entry12>:
    9560:	f3 0f 1e fa          	endbr64
    9564:	48 8b 3f             	mov    (%rdi),%rdi
    9567:	e9 24 ed ff ff       	jmp    8290 <f12>
    956c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009570 <e12>:
    9570:	f3 0f 1e fa          	endbr64
    9574:	53                   	push   %rbx
    9575:	48 8b 1f             	mov    (%rdi),%rbx
    9578:	48 89 df             	mov    %rbx,%rdi
    957b:	e8 d0 ce ff ff       	call   6450 <fwp_rc_share>
    9580:	48 89 df             	mov    %rbx,%rdi
    9583:	e8 08 ed ff ff       	call   8290 <f12>
    9588:	48 89 c3             	mov    %rax,%rbx
    958b:	48 89 c7             	mov    %rax,%rdi
    958e:	e8 bd ce ff ff       	call   6450 <fwp_rc_share>
    9593:	48 89 d8             	mov    %rbx,%rax
    9596:	5b                   	pop    %rbx
    9597:	c3                   	ret
    9598:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    959f:	00 

00000000000095a0 <fwp_write>:
    95a0:	41 57                	push   %r15
    95a2:	41 56                	push   %r14
    95a4:	41 55                	push   %r13
    95a6:	41 54                	push   %r12
    95a8:	55                   	push   %rbp
    95a9:	53                   	push   %rbx
    95aa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    95b1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    95b8:	00 00 
    95ba:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    95c1:	00 
    95c2:	49 89 d4             	mov    %rdx,%r12
    95c5:	8b 12                	mov    (%rdx),%edx
    95c7:	83 fa 19             	cmp    $0x19,%edx
    95ca:	77 6a                	ja     9636 <fwp_write+0x96>
    95cc:	48 89 f5             	mov    %rsi,%rbp
    95cf:	89 d0                	mov    %edx,%eax
    95d1:	89 ce                	mov    %ecx,%esi
    95d3:	48 89 fb             	mov    %rdi,%rbx
    95d6:	48 8d 0d 33 64 00 00 	lea    0x6433(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    95dd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    95e1:	48 01 c8             	add    %rcx,%rax
    95e4:	3e ff e0             	notrack jmp *%rax
    95e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    95ee:	00 00 
    95f0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    95f4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    95f8:	48 89 ca             	mov    %rcx,%rdx
    95fb:	48 85 c9             	test   %rcx,%rcx
    95fe:	0f 88 9c 0c 00 00    	js     a2a0 <fwp_write+0xd00>
    9604:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    960b:	00 
    960c:	48 89 c6             	mov    %rax,%rsi
    960f:	4c 89 e7             	mov    %r12,%rdi
    9612:	e8 29 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    9617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    961e:	00 00 
    9620:	4c 89 e7             	mov    %r12,%rdi
    9623:	e8 28 9e ff ff       	call   3450 <strlen@plt>
    9628:	4c 89 e6             	mov    %r12,%rsi
    962b:	48 89 df             	mov    %rbx,%rdi
    962e:	48 89 c2             	mov    %rax,%rdx
    9631:	e8 3a aa ff ff       	call   4070 <buf_put>
    9636:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    963d:	00 
    963e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9645:	00 00 
    9647:	0f 85 28 04 00 00    	jne    9a75 <fwp_write+0x4d5>
    964d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9654:	5b                   	pop    %rbx
    9655:	5d                   	pop    %rbp
    9656:	41 5c                	pop    %r12
    9658:	41 5d                	pop    %r13
    965a:	41 5e                	pop    %r14
    965c:	41 5f                	pop    %r15
    965e:	c3                   	ret
    965f:	90                   	nop
    9660:	49 89 e9             	mov    %rbp,%r9
    9663:	4c 8d 05 17 5b 00 00 	lea    0x5b17(%rip),%r8        # f181 <_IO_stdin_used+0x181>
    966a:	b9 00 02 00 00       	mov    $0x200,%ecx
    966f:	ba 02 00 00 00       	mov    $0x2,%edx
    9674:	be 00 02 00 00       	mov    $0x200,%esi
    9679:	31 c0                	xor    %eax,%eax
    967b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9682:	00 
    9683:	e8 28 9d ff ff       	call   33b0 <__snprintf_chk@plt>
    9688:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    968f:	00 
    9690:	e8 bb 9d ff ff       	call   3450 <strlen@plt>
    9695:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    969c:	00 
    969d:	48 89 df             	mov    %rbx,%rdi
    96a0:	48 89 c2             	mov    %rax,%rdx
    96a3:	e8 c8 a9 ff ff       	call   4070 <buf_put>
    96a8:	eb 8c                	jmp    9636 <fwp_write+0x96>
    96aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96b0:	49 89 e9             	mov    %rbp,%r9
    96b3:	4c 8d 05 c2 5a 00 00 	lea    0x5ac2(%rip),%r8        # f17c <_IO_stdin_used+0x17c>
    96ba:	eb ae                	jmp    966a <fwp_write+0xca>
    96bc:	0f 1f 40 00          	nopl   0x0(%rax)
    96c0:	83 fa 13             	cmp    $0x13,%edx
    96c3:	48 8d 05 a8 5a 00 00 	lea    0x5aa8(%rip),%rax        # f172 <_IO_stdin_used+0x172>
    96ca:	48 8d 35 a6 5a 00 00 	lea    0x5aa6(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    96d1:	ba 04 00 00 00       	mov    $0x4,%edx
    96d6:	48 0f 44 f0          	cmove  %rax,%rsi
    96da:	45 31 ed             	xor    %r13d,%r13d
    96dd:	e8 8e a9 ff ff       	call   4070 <buf_put>
    96e2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    96e7:	0f 84 a3 08 00 00    	je     9f90 <fwp_write+0x9f0>
    96ed:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    96f2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    96f7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    96fc:	48 89 df             	mov    %rbx,%rdi
    96ff:	49 0f 44 c5          	cmove  %r13,%rax
    9703:	31 c9                	xor    %ecx,%ecx
    9705:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    970a:	e8 91 fe ff ff       	call   95a0 <fwp_write>
    970f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9714:	0f 84 6e 09 00 00    	je     a088 <fwp_write+0xae8>
    971a:	49 83 c5 01          	add    $0x1,%r13
    971e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9722:	0f 83 68 08 00 00    	jae    9f90 <fwp_write+0x9f0>
    9728:	ba 02 00 00 00       	mov    $0x2,%edx
    972d:	48 8d 35 8d 5a 00 00 	lea    0x5a8d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9734:	48 89 df             	mov    %rbx,%rdi
    9737:	e8 34 a9 ff ff       	call   4070 <buf_put>
    973c:	eb af                	jmp    96ed <fwp_write+0x14d>
    973e:	66 90                	xchg   %ax,%ax
    9740:	ba 06 00 00 00       	mov    $0x6,%edx
    9745:	48 8d 35 4e 5a 00 00 	lea    0x5a4e(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    974c:	48 83 c5 10          	add    $0x10,%rbp
    9750:	e8 1b a9 ff ff       	call   4070 <buf_put>
    9755:	48 89 ef             	mov    %rbp,%rdi
    9758:	e8 f3 9c ff ff       	call   3450 <strlen@plt>
    975d:	48 89 ee             	mov    %rbp,%rsi
    9760:	48 89 df             	mov    %rbx,%rdi
    9763:	48 89 c2             	mov    %rax,%rdx
    9766:	e8 05 a9 ff ff       	call   4070 <buf_put>
    976b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9770:	ba 01 00 00 00       	mov    $0x1,%edx
    9775:	48 89 df             	mov    %rbx,%rdi
    9778:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    977d:	e8 ee a8 ff ff       	call   4070 <buf_put>
    9782:	e9 af fe ff ff       	jmp    9636 <fwp_write+0x96>
    9787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    978e:	00 00 
    9790:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9797:	00 
    9798:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    979f:	00 00 
    97a1:	0f 85 ce 02 00 00    	jne    9a75 <fwp_write+0x4d5>
    97a7:	ba 0a 00 00 00       	mov    $0xa,%edx
    97ac:	48 8d 35 d3 59 00 00 	lea    0x59d3(%rip),%rsi        # f186 <_IO_stdin_used+0x186>
    97b3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    97ba:	48 89 df             	mov    %rbx,%rdi
    97bd:	5b                   	pop    %rbx
    97be:	5d                   	pop    %rbp
    97bf:	41 5c                	pop    %r12
    97c1:	41 5d                	pop    %r13
    97c3:	41 5e                	pop    %r14
    97c5:	41 5f                	pop    %r15
    97c7:	e9 a4 a8 ff ff       	jmp    4070 <buf_put>
    97cc:	0f 1f 40 00          	nopl   0x0(%rax)
    97d0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    97d5:	4d 85 ed             	test   %r13,%r13
    97d8:	0f 84 02 0c 00 00    	je     a3e0 <fwp_write+0xe40>
    97de:	48 8d 35 e9 59 00 00 	lea    0x59e9(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    97e5:	4c 89 ef             	mov    %r13,%rdi
    97e8:	e8 43 9d ff ff       	call   3530 <strcmp@plt>
    97ed:	41 89 c1             	mov    %eax,%r9d
    97f0:	85 c0                	test   %eax,%eax
    97f2:	0f 84 6c 0c 00 00    	je     a464 <fwp_write+0xec4>
    97f8:	4c 89 ef             	mov    %r13,%rdi
    97fb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9800:	e8 4b 9c ff ff       	call   3450 <strlen@plt>
    9805:	4c 89 ee             	mov    %r13,%rsi
    9808:	48 89 df             	mov    %rbx,%rdi
    980b:	48 89 c2             	mov    %rax,%rdx
    980e:	e8 5d a8 ff ff       	call   4070 <buf_put>
    9813:	ba 01 00 00 00       	mov    $0x1,%edx
    9818:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    981d:	48 89 df             	mov    %rbx,%rdi
    9820:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9825:	e8 46 a8 ff ff       	call   4070 <buf_put>
    982a:	ba 01 00 00 00       	mov    $0x1,%edx
    982f:	4c 89 fe             	mov    %r15,%rsi
    9832:	48 89 df             	mov    %rbx,%rdi
    9835:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    983a:	e8 31 a8 ff ff       	call   4070 <buf_put>
    983f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9844:	45 31 f6             	xor    %r14d,%r14d
    9847:	85 d2                	test   %edx,%edx
    9849:	0f 8e 81 0a 00 00    	jle    a2d0 <fwp_write+0xd30>
    984f:	45 31 ed             	xor    %r13d,%r13d
    9852:	4d 85 ed             	test   %r13,%r13
    9855:	0f 85 75 07 00 00    	jne    9fd0 <fwp_write+0xa30>
    985b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9862:	00 
    9863:	45 85 f6             	test   %r14d,%r14d
    9866:	0f 84 84 07 00 00    	je     9ff0 <fwp_write+0xa50>
    986c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9871:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9876:	48 89 df             	mov    %rbx,%rdi
    9879:	49 83 c5 01          	add    $0x1,%r13
    987d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9881:	31 c9                	xor    %ecx,%ecx
    9883:	e8 18 fd ff ff       	call   95a0 <fwp_write>
    9888:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    988d:	7f c3                	jg     9852 <fwp_write+0x2b2>
    988f:	45 85 f6             	test   %r14d,%r14d
    9892:	0f 84 38 0a 00 00    	je     a2d0 <fwp_write+0xd30>
    9898:	b8 29 00 00 00       	mov    $0x29,%eax
    989d:	ba 01 00 00 00       	mov    $0x1,%edx
    98a2:	4c 89 fe             	mov    %r15,%rsi
    98a5:	48 89 df             	mov    %rbx,%rdi
    98a8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    98ac:	e8 bf a7 ff ff       	call   4070 <buf_put>
    98b1:	e9 80 fd ff ff       	jmp    9636 <fwp_write+0x96>
    98b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98bd:	00 00 00 
    98c0:	ba 01 00 00 00       	mov    $0x1,%edx
    98c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    98ca:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    98cf:	e8 9c a7 ff ff       	call   4070 <buf_put>
    98d4:	48 85 ed             	test   %rbp,%rbp
    98d7:	0f 84 93 06 00 00    	je     9f70 <fwp_write+0x9d0>
    98dd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    98e1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    98e6:	31 c9                	xor    %ecx,%ecx
    98e8:	48 89 df             	mov    %rbx,%rdi
    98eb:	e8 b0 fc ff ff       	call   95a0 <fwp_write>
    98f0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    98f4:	48 85 ed             	test   %rbp,%rbp
    98f7:	0f 84 73 06 00 00    	je     9f70 <fwp_write+0x9d0>
    98fd:	ba 02 00 00 00       	mov    $0x2,%edx
    9902:	48 8d 35 b8 58 00 00 	lea    0x58b8(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9909:	48 89 df             	mov    %rbx,%rdi
    990c:	e8 5f a7 ff ff       	call   4070 <buf_put>
    9911:	eb ca                	jmp    98dd <fwp_write+0x33d>
    9913:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9918:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    991c:	85 f6                	test   %esi,%esi
    991e:	0f 84 fc 07 00 00    	je     a120 <fwp_write+0xb80>
    9924:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    992b:	00 
    992c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9933:	00 00 
    9935:	0f 85 3a 01 00 00    	jne    9a75 <fwp_write+0x4d5>
    993b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    993f:	4c 89 ea             	mov    %r13,%rdx
    9942:	e9 6c fe ff ff       	jmp    97b3 <fwp_write+0x213>
    9947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    994e:	00 00 
    9950:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9955:	ba 01 00 00 00       	mov    $0x1,%edx
    995a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    995f:	48 89 ee             	mov    %rbp,%rsi
    9962:	e8 09 a7 ff ff       	call   4070 <buf_put>
    9967:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    996c:	4c 89 e7             	mov    %r12,%rdi
    996f:	e8 dc 9a ff ff       	call   3450 <strlen@plt>
    9974:	4c 89 e6             	mov    %r12,%rsi
    9977:	48 89 df             	mov    %rbx,%rdi
    997a:	48 89 c2             	mov    %rax,%rdx
    997d:	e8 ee a6 ff ff       	call   4070 <buf_put>
    9982:	ba 01 00 00 00       	mov    $0x1,%edx
    9987:	48 89 ee             	mov    %rbp,%rsi
    998a:	48 89 df             	mov    %rbx,%rdi
    998d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9992:	e8 d9 a6 ff ff       	call   4070 <buf_put>
    9997:	e9 9a fc ff ff       	jmp    9636 <fwp_write+0x96>
    999c:	0f 1f 40 00          	nopl   0x0(%rax)
    99a0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    99a5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    99a9:	0f 8a 8e 0b 00 00    	jp     a53d <fwp_write+0xf9d>
    99af:	66 0f 28 c1          	movapd %xmm1,%xmm0
    99b3:	66 0f 54 05 55 61 00 	andpd  0x6155(%rip),%xmm0        # fb10 <msg.4+0x90>
    99ba:	00 
    99bb:	bd 01 00 00 00       	mov    $0x1,%ebp
    99c0:	66 0f 2e 05 80 61 00 	ucomisd 0x6180(%rip),%xmm0        # fb48 <msg.4+0xc8>
    99c7:	00 
    99c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    99cf:	00 
    99d0:	0f 87 b2 09 00 00    	ja     a388 <fwp_write+0xde8>
    99d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    99dd:	00 00 00 
    99e0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    99e4:	89 ee                	mov    %ebp,%esi
    99e6:	4c 89 e7             	mov    %r12,%rdi
    99e9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    99ee:	e8 cd aa ff ff       	call   44c0 <fwp_format_g.constprop.0>
    99f3:	31 f6                	xor    %esi,%esi
    99f5:	4c 89 e7             	mov    %r12,%rdi
    99f8:	e8 13 9a ff ff       	call   3410 <strtod@plt>
    99fd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9a02:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9a06:	7a 06                	jp     9a0e <fwp_write+0x46e>
    9a08:	0f 84 e9 01 00 00    	je     9bf7 <fwp_write+0x657>
    9a0e:	83 c5 01             	add    $0x1,%ebp
    9a11:	83 fd 12             	cmp    $0x12,%ebp
    9a14:	75 ca                	jne    99e0 <fwp_write+0x440>
    9a16:	be 11 00 00 00       	mov    $0x11,%esi
    9a1b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9a1f:	4c 89 e7             	mov    %r12,%rdi
    9a22:	e8 99 aa ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9a27:	e9 cb 01 00 00       	jmp    9bf7 <fwp_write+0x657>
    9a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a30:	48 83 fd 01          	cmp    $0x1,%rbp
    9a34:	0f 84 e6 08 00 00    	je     a320 <fwp_write+0xd80>
    9a3a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9a3e:	b8 02 00 00 00       	mov    $0x2,%eax
    9a43:	ba 01 00 00 00       	mov    $0x1,%edx
    9a48:	48 0f 44 d0          	cmove  %rax,%rdx
    9a4c:	48 8d 35 17 57 00 00 	lea    0x5717(%rip),%rsi        # f16a <_IO_stdin_used+0x16a>
    9a53:	48 8d 05 15 57 00 00 	lea    0x5715(%rip),%rax        # f16f <_IO_stdin_used+0x16f>
    9a5a:	48 0f 44 f0          	cmove  %rax,%rsi
    9a5e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9a65:	00 
    9a66:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a6d:	00 00 
    9a6f:	0f 84 3e fd ff ff    	je     97b3 <fwp_write+0x213>
    9a75:	e8 e6 99 ff ff       	call   3460 <__stack_chk_fail@plt>
    9a7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a80:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9a85:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9a8a:	e8 21 a5 ff ff       	call   3fb0 <buf_grow>
    9a8f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9a93:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9a99:	4c 03 0b             	add    (%rbx),%r9
    9a9c:	66 45 89 11          	mov    %r10w,(%r9)
    9aa0:	45 85 e4             	test   %r12d,%r12d
    9aa3:	0f 8e 07 05 00 00    	jle    9fb0 <fwp_write+0xa10>
    9aa9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9ab0:	55 55 55 
    9ab3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9ab8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9abf:	aa aa aa 
    9ac2:	49 83 c1 01          	add    $0x1,%r9
    9ac6:	eb 45                	jmp    9b0d <fwp_write+0x56d>
    9ac8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9acf:	00 
    9ad0:	be 01 00 00 00       	mov    $0x1,%esi
    9ad5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9ada:	88 07                	mov    %al,(%rdi)
    9adc:	48 89 e8             	mov    %rbp,%rax
    9adf:	49 f7 e8             	imul   %r8
    9ae2:	48 89 e8             	mov    %rbp,%rax
    9ae5:	48 c1 f8 3f          	sar    $0x3f,%rax
    9ae9:	48 29 c2             	sub    %rax,%rdx
    9aec:	48 85 c9             	test   %rcx,%rcx
    9aef:	0f 95 c0             	setne  %al
    9af2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9af6:	48 83 ef 01          	sub    $0x1,%rdi
    9afa:	48 21 c5             	and    %rax,%rbp
    9afd:	48 29 ea             	sub    %rbp,%rdx
    9b00:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9b04:	49 39 f9             	cmp    %rdi,%r9
    9b07:	0f 84 a3 04 00 00    	je     9fb0 <fwp_write+0xa10>
    9b0d:	48 89 e8             	mov    %rbp,%rax
    9b10:	49 f7 e8             	imul   %r8
    9b13:	48 89 e8             	mov    %rbp,%rax
    9b16:	48 c1 f8 3f          	sar    $0x3f,%rax
    9b1a:	48 89 d1             	mov    %rdx,%rcx
    9b1d:	48 29 c1             	sub    %rax,%rcx
    9b20:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9b24:	48 89 e9             	mov    %rbp,%rcx
    9b27:	48 29 c1             	sub    %rax,%rcx
    9b2a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9b2e:	49 f7 e2             	mul    %r10
    9b31:	b8 30 00 00 00       	mov    $0x30,%eax
    9b36:	48 89 d6             	mov    %rdx,%rsi
    9b39:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9b3d:	48 d1 ee             	shr    $1,%rsi
    9b40:	48 01 f2             	add    %rsi,%rdx
    9b43:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9b47:	48 29 d6             	sub    %rdx,%rsi
    9b4a:	74 8e                	je     9ada <fwp_write+0x53a>
    9b4c:	48 83 fe 01          	cmp    $0x1,%rsi
    9b50:	0f 85 7a ff ff ff    	jne    9ad0 <fwp_write+0x530>
    9b56:	31 f6                	xor    %esi,%esi
    9b58:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9b5d:	e9 78 ff ff ff       	jmp    9ada <fwp_write+0x53a>
    9b62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b68:	66 0f 6e cd          	movd   %ebp,%xmm1
    9b6c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9b6f:	0f 8a c8 09 00 00    	jp     a53d <fwp_write+0xf9d>
    9b75:	0f 28 c1             	movaps %xmm1,%xmm0
    9b78:	0f 54 05 81 5f 00 00 	andps  0x5f81(%rip),%xmm0        # fb00 <msg.4+0x80>
    9b7f:	0f 2e 05 7e 54 00 00 	ucomiss 0x547e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9b86:	0f 87 24 08 00 00    	ja     a3b0 <fwp_write+0xe10>
    9b8c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9b90:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9b96:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9b9d:	00 
    9b9e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9ba2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bae:	00 00 
    9bb0:	44 89 ee             	mov    %r13d,%esi
    9bb3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9bb8:	4c 89 e7             	mov    %r12,%rdi
    9bbb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9bc0:	e8 fb a8 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9bc5:	31 f6                	xor    %esi,%esi
    9bc7:	4c 89 e7             	mov    %r12,%rdi
    9bca:	e8 e1 98 ff ff       	call   34b0 <strtof@plt>
    9bcf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9bd4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9bd7:	7a 02                	jp     9bdb <fwp_write+0x63b>
    9bd9:	74 1c                	je     9bf7 <fwp_write+0x657>
    9bdb:	41 83 c5 01          	add    $0x1,%r13d
    9bdf:	41 83 fd 0a          	cmp    $0xa,%r13d
    9be3:	75 cb                	jne    9bb0 <fwp_write+0x610>
    9be5:	be 09 00 00 00       	mov    $0x9,%esi
    9bea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9bef:	4c 89 e7             	mov    %r12,%rdi
    9bf2:	e8 c9 a8 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9bf7:	4c 89 e7             	mov    %r12,%rdi
    9bfa:	e8 31 a5 ff ff       	call   4130 <fwp_finish_float>
    9bff:	e9 1c fa ff ff       	jmp    9620 <fwp_write+0x80>
    9c04:	0f 1f 40 00          	nopl   0x0(%rax)
    9c08:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9c0c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9c10:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9c17:	00 
    9c18:	48 89 ef             	mov    %rbp,%rdi
    9c1b:	e8 20 9e ff ff       	call   3a40 <fwp_fmt_u128>
    9c20:	48 89 ef             	mov    %rbp,%rdi
    9c23:	e8 28 98 ff ff       	call   3450 <strlen@plt>
    9c28:	48 89 ee             	mov    %rbp,%rsi
    9c2b:	48 89 df             	mov    %rbx,%rdi
    9c2e:	48 89 c2             	mov    %rax,%rdx
    9c31:	e8 3a a4 ff ff       	call   4070 <buf_put>
    9c36:	e9 fb f9 ff ff       	jmp    9636 <fwp_write+0x96>
    9c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c40:	ba 06 00 00 00       	mov    $0x6,%edx
    9c45:	48 8d 35 78 55 00 00 	lea    0x5578(%rip),%rsi        # f1c4 <_IO_stdin_used+0x1c4>
    9c4c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9c52:	e8 19 a4 ff ff       	call   4070 <buf_put>
    9c57:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9c5e:	ff ff 7f 
    9c61:	48 23 55 00          	and    0x0(%rbp),%rdx
    9c65:	0f 84 86 02 00 00    	je     9ef1 <fwp_write+0x951>
    9c6b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9c70:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9c74:	48 85 d2             	test   %rdx,%rdx
    9c77:	0f 84 ae 00 00 00    	je     9d2b <fwp_write+0x78b>
    9c7d:	8b 0a                	mov    (%rdx),%ecx
    9c7f:	83 f9 1c             	cmp    $0x1c,%ecx
    9c82:	0f 84 58 06 00 00    	je     a2e0 <fwp_write+0xd40>
    9c88:	83 f9 1b             	cmp    $0x1b,%ecx
    9c8b:	0f 87 9a 00 00 00    	ja     9d2b <fwp_write+0x78b>
    9c91:	be 01 00 00 00       	mov    $0x1,%esi
    9c96:	48 d3 e6             	shl    %cl,%rsi
    9c99:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9c9f:	0f 85 4b 04 00 00    	jne    a0f0 <fwp_write+0xb50>
    9ca5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9cab:	0f 85 0f 04 00 00    	jne    a0c0 <fwp_write+0xb20>
    9cb1:	83 e6 21             	and    $0x21,%esi
    9cb4:	74 75                	je     9d2b <fwp_write+0x78b>
    9cb6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9cbb:	48 85 ff             	test   %rdi,%rdi
    9cbe:	79 07                	jns    9cc7 <fwp_write+0x727>
    9cc0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9cc4:	4c 01 ee             	add    %r13,%rsi
    9cc7:	48 0f be 3e          	movsbq (%rsi),%rdi
    9ccb:	85 c9                	test   %ecx,%ecx
    9ccd:	40 0f b6 f7          	movzbl %dil,%esi
    9cd1:	48 0f 44 f7          	cmove  %rdi,%rsi
    9cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cdc:	00 00 00 00 
    9ce0:	31 c9                	xor    %ecx,%ecx
    9ce2:	48 89 df             	mov    %rbx,%rdi
    9ce5:	49 83 c5 01          	add    $0x1,%r13
    9ce9:	e8 b2 f8 ff ff       	call   95a0 <fwp_write>
    9cee:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9cf5:	ff ff 7f 
    9cf8:	48 23 55 00          	and    0x0(%rbp),%rdx
    9cfc:	49 39 d5             	cmp    %rdx,%r13
    9cff:	0f 83 ec 01 00 00    	jae    9ef1 <fwp_write+0x951>
    9d05:	ba 02 00 00 00       	mov    $0x2,%edx
    9d0a:	48 89 df             	mov    %rbx,%rdi
    9d0d:	48 8d 35 ad 54 00 00 	lea    0x54ad(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9d14:	e8 57 a3 ff ff       	call   4070 <buf_put>
    9d19:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d1e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9d22:	48 85 d2             	test   %rdx,%rdx
    9d25:	0f 85 52 ff ff ff    	jne    9c7d <fwp_write+0x6dd>
    9d2b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9d30:	48 85 ff             	test   %rdi,%rdi
    9d33:	0f 88 cf 05 00 00    	js     a308 <fwp_write+0xd68>
    9d39:	48 8b 31             	mov    (%rcx),%rsi
    9d3c:	eb a2                	jmp    9ce0 <fwp_write+0x740>
    9d3e:	66 90                	xchg   %ax,%ax
    9d40:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d47:	00 
    9d48:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d4f:	00 00 
    9d51:	0f 85 1e fd ff ff    	jne    9a75 <fwp_write+0x4d5>
    9d57:	ba 08 00 00 00       	mov    $0x8,%edx
    9d5c:	48 8d 35 2e 54 00 00 	lea    0x542e(%rip),%rsi        # f191 <_IO_stdin_used+0x191>
    9d63:	e9 4b fa ff ff       	jmp    97b3 <fwp_write+0x213>
    9d68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d6f:	00 
    9d70:	89 e8                	mov    %ebp,%eax
    9d72:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9d79:	76 03                	jbe    9d7e <fwp_write+0x7de>
    9d7b:	8b 45 00             	mov    0x0(%rbp),%eax
    9d7e:	41 89 c6             	mov    %eax,%r14d
    9d81:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9d86:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    9d8b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    9d8f:	4c 89 ef             	mov    %r13,%rdi
    9d92:	e8 b9 96 ff ff       	call   3450 <strlen@plt>
    9d97:	4c 89 ee             	mov    %r13,%rsi
    9d9a:	48 89 df             	mov    %rbx,%rdi
    9d9d:	48 89 c2             	mov    %rax,%rdx
    9da0:	e8 cb a2 ff ff       	call   4070 <buf_put>
    9da5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9daa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    9dae:	85 f6                	test   %esi,%esi
    9db0:	0f 8e 80 f8 ff ff    	jle    9636 <fwp_write+0x96>
    9db6:	45 31 ed             	xor    %r13d,%r13d
    9db9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9dbe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9dc3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9dc8:	ba 01 00 00 00       	mov    $0x1,%edx
    9dcd:	4c 89 fe             	mov    %r15,%rsi
    9dd0:	48 89 04 24          	mov    %rax,(%rsp)
    9dd4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9dd9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    9ddd:	48 89 df             	mov    %rbx,%rdi
    9de0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9de4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9de9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    9dee:	e8 7d a2 ff ff       	call   4070 <buf_put>
    9df3:	41 8b 06             	mov    (%r14),%eax
    9df6:	83 f8 0e             	cmp    $0xe,%eax
    9df9:	0f 84 71 02 00 00    	je     a070 <fwp_write+0xad0>
    9dff:	83 f8 10             	cmp    $0x10,%eax
    9e02:	0f 84 38 02 00 00    	je     a040 <fwp_write+0xaa0>
    9e08:	83 f8 0a             	cmp    $0xa,%eax
    9e0b:	0f 84 7f 04 00 00    	je     a290 <fwp_write+0xcf0>
    9e11:	0f 8f f9 00 00 00    	jg     9f10 <fwp_write+0x970>
    9e17:	83 f8 03             	cmp    $0x3,%eax
    9e1a:	0f 8f 50 04 00 00    	jg     a270 <fwp_write+0xcd0>
    9e20:	85 c0                	test   %eax,%eax
    9e22:	78 10                	js     9e34 <fwp_write+0x894>
    9e24:	48 8b 04 24          	mov    (%rsp),%rax
    9e28:	48 c1 e8 3f          	shr    $0x3f,%rax
    9e2c:	85 c0                	test   %eax,%eax
    9e2e:	0f 85 f9 00 00 00    	jne    9f2d <fwp_write+0x98d>
    9e34:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9e39:	48 8b 34 24          	mov    (%rsp),%rsi
    9e3d:	31 c9                	xor    %ecx,%ecx
    9e3f:	48 89 df             	mov    %rbx,%rdi
    9e42:	e8 59 f7 ff ff       	call   95a0 <fwp_write>
    9e47:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9e4c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9e51:	49 83 c5 01          	add    $0x1,%r13
    9e55:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9e59:	0f 8f 5f ff ff ff    	jg     9dbe <fwp_write+0x81e>
    9e5f:	e9 d2 f7 ff ff       	jmp    9636 <fwp_write+0x96>
    9e64:	0f 1f 40 00          	nopl   0x0(%rax)
    9e68:	ba 06 00 00 00       	mov    $0x6,%edx
    9e6d:	48 8d 35 43 53 00 00 	lea    0x5343(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    9e74:	45 31 ed             	xor    %r13d,%r13d
    9e77:	e8 f4 a1 ff ff       	call   4070 <buf_put>
    9e7c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e81:	75 19                	jne    9e9c <fwp_write+0x8fc>
    9e83:	eb 6c                	jmp    9ef1 <fwp_write+0x951>
    9e85:	0f 1f 00             	nopl   (%rax)
    9e88:	ba 02 00 00 00       	mov    $0x2,%edx
    9e8d:	48 8d 35 2d 53 00 00 	lea    0x532d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9e94:	48 89 df             	mov    %rbx,%rdi
    9e97:	e8 d4 a1 ff ff       	call   4070 <buf_put>
    9e9c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9ea2:	b9 00 02 00 00       	mov    $0x200,%ecx
    9ea7:	31 c0                	xor    %eax,%eax
    9ea9:	49 83 c5 01          	add    $0x1,%r13
    9ead:	4c 8d 05 0a 53 00 00 	lea    0x530a(%rip),%r8        # f1be <_IO_stdin_used+0x1be>
    9eb4:	ba 02 00 00 00       	mov    $0x2,%edx
    9eb9:	be 00 02 00 00       	mov    $0x200,%esi
    9ebe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ec5:	00 
    9ec6:	e8 e5 94 ff ff       	call   33b0 <__snprintf_chk@plt>
    9ecb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ed2:	00 
    9ed3:	e8 78 95 ff ff       	call   3450 <strlen@plt>
    9ed8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9edf:	00 
    9ee0:	48 89 df             	mov    %rbx,%rdi
    9ee3:	48 89 c2             	mov    %rax,%rdx
    9ee6:	e8 85 a1 ff ff       	call   4070 <buf_put>
    9eeb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9eef:	72 97                	jb     9e88 <fwp_write+0x8e8>
    9ef1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9ef6:	ba 01 00 00 00       	mov    $0x1,%edx
    9efb:	48 89 df             	mov    %rbx,%rdi
    9efe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9f03:	e8 68 a1 ff ff       	call   4070 <buf_put>
    9f08:	e9 29 f7 ff ff       	jmp    9636 <fwp_write+0x96>
    9f0d:	0f 1f 00             	nopl   (%rax)
    9f10:	83 f8 0b             	cmp    $0xb,%eax
    9f13:	0f 85 1b ff ff ff    	jne    9e34 <fwp_write+0x894>
    9f19:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    9f1e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9f22:	83 e0 01             	and    $0x1,%eax
    9f25:	85 c0                	test   %eax,%eax
    9f27:	0f 84 07 ff ff ff    	je     9e34 <fwp_write+0x894>
    9f2d:	4c 89 fe             	mov    %r15,%rsi
    9f30:	48 89 df             	mov    %rbx,%rdi
    9f33:	ba 01 00 00 00       	mov    $0x1,%edx
    9f38:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9f3d:	e8 2e a1 ff ff       	call   4070 <buf_put>
    9f42:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9f47:	48 8b 34 24          	mov    (%rsp),%rsi
    9f4b:	31 c9                	xor    %ecx,%ecx
    9f4d:	48 89 df             	mov    %rbx,%rdi
    9f50:	e8 4b f6 ff ff       	call   95a0 <fwp_write>
    9f55:	ba 01 00 00 00       	mov    $0x1,%edx
    9f5a:	4c 89 fe             	mov    %r15,%rsi
    9f5d:	48 89 df             	mov    %rbx,%rdi
    9f60:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9f65:	e8 06 a1 ff ff       	call   4070 <buf_put>
    9f6a:	e9 d8 fe ff ff       	jmp    9e47 <fwp_write+0x8a7>
    9f6f:	90                   	nop
    9f70:	ba 01 00 00 00       	mov    $0x1,%edx
    9f75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f7a:	48 89 df             	mov    %rbx,%rdi
    9f7d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9f82:	e8 e9 a0 ff ff       	call   4070 <buf_put>
    9f87:	e9 aa f6 ff ff       	jmp    9636 <fwp_write+0x96>
    9f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f90:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f95:	ba 01 00 00 00       	mov    $0x1,%edx
    9f9a:	48 89 df             	mov    %rbx,%rdi
    9f9d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9fa2:	e8 c9 a0 ff ff       	call   4070 <buf_put>
    9fa7:	e9 8a f6 ff ff       	jmp    9636 <fwp_write+0x96>
    9fac:	0f 1f 40 00          	nopl   0x0(%rax)
    9fb0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9fb4:	48 8b 13             	mov    (%rbx),%rdx
    9fb7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    9fbc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9fc0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9fc4:	e9 6d f6 ff ff       	jmp    9636 <fwp_write+0x96>
    9fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9fd0:	ba 02 00 00 00       	mov    $0x2,%edx
    9fd5:	48 8d 35 e5 51 00 00 	lea    0x51e5(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9fdc:	48 89 df             	mov    %rbx,%rdi
    9fdf:	e8 8c a0 ff ff       	call   4070 <buf_put>
    9fe4:	e9 72 f8 ff ff       	jmp    985b <fwp_write+0x2bb>
    9fe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9ff0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9ff5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9ffa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    9ffe:	48 89 f7             	mov    %rsi,%rdi
    a001:	48 89 34 24          	mov    %rsi,(%rsp)
    a005:	e8 46 94 ff ff       	call   3450 <strlen@plt>
    a00a:	48 8b 34 24          	mov    (%rsp),%rsi
    a00e:	48 89 df             	mov    %rbx,%rdi
    a011:	48 89 c2             	mov    %rax,%rdx
    a014:	e8 57 a0 ff ff       	call   4070 <buf_put>
    a019:	ba 03 00 00 00       	mov    $0x3,%edx
    a01e:	48 8d 35 bf 51 00 00 	lea    0x51bf(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    a025:	48 89 df             	mov    %rbx,%rdi
    a028:	e8 43 a0 ff ff       	call   4070 <buf_put>
    a02d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a032:	e9 35 f8 ff ff       	jmp    986c <fwp_write+0x2cc>
    a037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a03e:	00 00 
    a040:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a045:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a049:	48 85 ff             	test   %rdi,%rdi
    a04c:	0f 84 e2 fd ff ff    	je     9e34 <fwp_write+0x894>
    a052:	48 8d 35 75 51 00 00 	lea    0x5175(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    a059:	e8 d2 94 ff ff       	call   3530 <strcmp@plt>
    a05e:	85 c0                	test   %eax,%eax
    a060:	0f 95 c0             	setne  %al
    a063:	0f b6 c0             	movzbl %al,%eax
    a066:	e9 c1 fd ff ff       	jmp    9e2c <fwp_write+0x88c>
    a06b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a070:	31 c0                	xor    %eax,%eax
    a072:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a079:	00 
    a07a:	0f 97 c0             	seta   %al
    a07d:	e9 aa fd ff ff       	jmp    9e2c <fwp_write+0x88c>
    a082:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a088:	48 89 df             	mov    %rbx,%rdi
    a08b:	ba 02 00 00 00       	mov    $0x2,%edx
    a090:	48 8d 35 34 51 00 00 	lea    0x5134(%rip),%rsi        # f1cb <_IO_stdin_used+0x1cb>
    a097:	e8 d4 9f ff ff       	call   4070 <buf_put>
    a09c:	4c 89 e8             	mov    %r13,%rax
    a09f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a0a4:	31 c9                	xor    %ecx,%ecx
    a0a6:	48 c1 e0 04          	shl    $0x4,%rax
    a0aa:	48 89 df             	mov    %rbx,%rdi
    a0ad:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a0b2:	e8 e9 f4 ff ff       	call   95a0 <fwp_write>
    a0b7:	e9 5e f6 ff ff       	jmp    971a <fwp_write+0x17a>
    a0bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a0c0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a0c5:	48 85 ff             	test   %rdi,%rdi
    a0c8:	79 0c                	jns    a0d6 <fwp_write+0xb36>
    a0ca:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a0d1:	00 
    a0d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a0d6:	48 63 3e             	movslq (%rsi),%rdi
    a0d9:	83 f9 02             	cmp    $0x2,%ecx
    a0dc:	89 fe                	mov    %edi,%esi
    a0de:	48 0f 44 f7          	cmove  %rdi,%rsi
    a0e2:	e9 f9 fb ff ff       	jmp    9ce0 <fwp_write+0x740>
    a0e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0ee:	00 00 
    a0f0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a0f5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a0fa:	48 85 ff             	test   %rdi,%rdi
    a0fd:	0f 88 0f 03 00 00    	js     a412 <fwp_write+0xe72>
    a103:	49 0f bf 38          	movswq (%r8),%rdi
    a107:	83 f9 01             	cmp    $0x1,%ecx
    a10a:	0f b7 f7             	movzwl %di,%esi
    a10d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a111:	e9 ca fb ff ff       	jmp    9ce0 <fwp_write+0x740>
    a116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a11d:	00 00 00 
    a120:	ba 01 00 00 00       	mov    $0x1,%edx
    a125:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a12a:	48 83 c5 08          	add    $0x8,%rbp
    a12e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a133:	e8 38 9f ff ff       	call   4070 <buf_put>
    a138:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a13d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a142:	4d 85 ed             	test   %r13,%r13
    a145:	75 46                	jne    a18d <fwp_write+0xbed>
    a147:	e9 04 01 00 00       	jmp    a250 <fwp_write+0xcb0>
    a14c:	0f 1f 40 00          	nopl   0x0(%rax)
    a150:	41 80 f9 09          	cmp    $0x9,%r9b
    a154:	0f 84 d6 00 00 00    	je     a230 <fwp_write+0xc90>
    a15a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a15e:	0f 85 9c 00 00 00    	jne    a200 <fwp_write+0xc60>
    a164:	ba 02 00 00 00       	mov    $0x2,%edx
    a169:	48 8d 35 37 50 00 00 	lea    0x5037(%rip),%rsi        # f1a7 <_IO_stdin_used+0x1a7>
    a170:	48 89 df             	mov    %rbx,%rdi
    a173:	e8 f8 9e ff ff       	call   4070 <buf_put>
    a178:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a17f:	00 
    a180:	48 83 c5 01          	add    $0x1,%rbp
    a184:	49 39 ec             	cmp    %rbp,%r12
    a187:	0f 84 c3 00 00 00    	je     a250 <fwp_write+0xcb0>
    a18d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a192:	41 80 f9 0d          	cmp    $0xd,%r9b
    a196:	74 28                	je     a1c0 <fwp_write+0xc20>
    a198:	7e b6                	jle    a150 <fwp_write+0xbb0>
    a19a:	41 80 f9 22          	cmp    $0x22,%r9b
    a19e:	74 40                	je     a1e0 <fwp_write+0xc40>
    a1a0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a1a4:	75 5a                	jne    a200 <fwp_write+0xc60>
    a1a6:	ba 02 00 00 00       	mov    $0x2,%edx
    a1ab:	48 8d 35 f2 4f 00 00 	lea    0x4ff2(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    a1b2:	48 89 df             	mov    %rbx,%rdi
    a1b5:	e8 b6 9e ff ff       	call   4070 <buf_put>
    a1ba:	eb c4                	jmp    a180 <fwp_write+0xbe0>
    a1bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a1c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a1c5:	48 8d 35 e1 4f 00 00 	lea    0x4fe1(%rip),%rsi        # f1ad <_IO_stdin_used+0x1ad>
    a1cc:	48 89 df             	mov    %rbx,%rdi
    a1cf:	e8 9c 9e ff ff       	call   4070 <buf_put>
    a1d4:	eb aa                	jmp    a180 <fwp_write+0xbe0>
    a1d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1dd:	00 00 00 
    a1e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a1e5:	48 8d 35 b5 4f 00 00 	lea    0x4fb5(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    a1ec:	48 89 df             	mov    %rbx,%rdi
    a1ef:	e8 7c 9e ff ff       	call   4070 <buf_put>
    a1f4:	eb 8a                	jmp    a180 <fwp_write+0xbe0>
    a1f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1fd:	00 00 00 
    a200:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a204:	0f 86 2e 01 00 00    	jbe    a338 <fwp_write+0xd98>
    a20a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a20e:	0f 84 24 01 00 00    	je     a338 <fwp_write+0xd98>
    a214:	ba 01 00 00 00       	mov    $0x1,%edx
    a219:	4c 89 fe             	mov    %r15,%rsi
    a21c:	48 89 df             	mov    %rbx,%rdi
    a21f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a224:	e8 47 9e ff ff       	call   4070 <buf_put>
    a229:	e9 52 ff ff ff       	jmp    a180 <fwp_write+0xbe0>
    a22e:	66 90                	xchg   %ax,%ax
    a230:	ba 02 00 00 00       	mov    $0x2,%edx
    a235:	48 8d 35 6e 4f 00 00 	lea    0x4f6e(%rip),%rsi        # f1aa <_IO_stdin_used+0x1aa>
    a23c:	48 89 df             	mov    %rbx,%rdi
    a23f:	e8 2c 9e ff ff       	call   4070 <buf_put>
    a244:	e9 37 ff ff ff       	jmp    a180 <fwp_write+0xbe0>
    a249:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a250:	ba 01 00 00 00       	mov    $0x1,%edx
    a255:	4c 89 fe             	mov    %r15,%rsi
    a258:	48 89 df             	mov    %rbx,%rdi
    a25b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a260:	e8 0b 9e ff ff       	call   4070 <buf_put>
    a265:	e9 cc f3 ff ff       	jmp    9636 <fwp_write+0x96>
    a26a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a270:	83 f8 04             	cmp    $0x4,%eax
    a273:	0f 85 bb fb ff ff    	jne    9e34 <fwp_write+0x894>
    a279:	48 8b 04 24          	mov    (%rsp),%rax
    a27d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a281:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a286:	48 c1 e8 3f          	shr    $0x3f,%rax
    a28a:	e9 96 fc ff ff       	jmp    9f25 <fwp_write+0x985>
    a28f:	90                   	nop
    a290:	8b 0c 24             	mov    (%rsp),%ecx
    a293:	31 c0                	xor    %eax,%eax
    a295:	85 c9                	test   %ecx,%ecx
    a297:	0f 98 c0             	sets   %al
    a29a:	e9 86 fc ff ff       	jmp    9f25 <fwp_write+0x985>
    a29f:	90                   	nop
    a2a0:	48 f7 d8             	neg    %rax
    a2a3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a2aa:	00 
    a2ab:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a2b2:	2d 
    a2b3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a2ba:	00 
    a2bb:	48 83 d2 00          	adc    $0x0,%rdx
    a2bf:	48 89 c6             	mov    %rax,%rsi
    a2c2:	48 f7 da             	neg    %rdx
    a2c5:	e8 76 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a2ca:	e9 51 f3 ff ff       	jmp    9620 <fwp_write+0x80>
    a2cf:	90                   	nop
    a2d0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a2d5:	e9 c3 f5 ff ff       	jmp    989d <fwp_write+0x2fd>
    a2da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2e0:	4c 89 e9             	mov    %r13,%rcx
    a2e3:	48 c1 e1 04          	shl    $0x4,%rcx
    a2e7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a2ec:	48 85 ff             	test   %rdi,%rdi
    a2ef:	0f 89 eb f9 ff ff    	jns    9ce0 <fwp_write+0x740>
    a2f5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a2f9:	48 89 ce             	mov    %rcx,%rsi
    a2fc:	e9 df f9 ff ff       	jmp    9ce0 <fwp_write+0x740>
    a301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a308:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a30f:	00 
    a310:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a314:	e9 20 fa ff ff       	jmp    9d39 <fwp_write+0x799>
    a319:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a320:	ba 02 00 00 00       	mov    $0x2,%edx
    a325:	48 8d 35 40 4e 00 00 	lea    0x4e40(%rip),%rsi        # f16c <_IO_stdin_used+0x16c>
    a32c:	e9 2d f7 ff ff       	jmp    9a5e <fwp_write+0x4be>
    a331:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a338:	4c 8d 05 71 4e 00 00 	lea    0x4e71(%rip),%r8        # f1b0 <_IO_stdin_used+0x1b0>
    a33f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a344:	31 c0                	xor    %eax,%eax
    a346:	ba 02 00 00 00       	mov    $0x2,%edx
    a34b:	be 10 00 00 00       	mov    $0x10,%esi
    a350:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a357:	00 
    a358:	e8 53 90 ff ff       	call   33b0 <__snprintf_chk@plt>
    a35d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a364:	00 
    a365:	e8 e6 90 ff ff       	call   3450 <strlen@plt>
    a36a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a371:	00 
    a372:	48 89 df             	mov    %rbx,%rdi
    a375:	48 89 c2             	mov    %rax,%rdx
    a378:	e8 f3 9c ff ff       	call   4070 <buf_put>
    a37d:	e9 fe fd ff ff       	jmp    a180 <fwp_write+0xbe0>
    a382:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a388:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a38c:	48 8d 35 d3 4d 00 00 	lea    0x4dd3(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a393:	48 8d 05 cb 4d 00 00 	lea    0x4dcb(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a39a:	4c 89 e7             	mov    %r12,%rdi
    a39d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a3a1:	48 0f 46 f0          	cmovbe %rax,%rsi
    a3a5:	e8 46 90 ff ff       	call   33f0 <strcpy@plt>
    a3aa:	e9 71 f2 ff ff       	jmp    9620 <fwp_write+0x80>
    a3af:	90                   	nop
    a3b0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a3b4:	48 8d 35 ab 4d 00 00 	lea    0x4dab(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a3bb:	48 8d 05 a3 4d 00 00 	lea    0x4da3(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a3c2:	0f 2f c8             	comiss %xmm0,%xmm1
    a3c5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a3cc:	00 
    a3cd:	4c 89 e7             	mov    %r12,%rdi
    a3d0:	48 0f 46 f0          	cmovbe %rax,%rsi
    a3d4:	e8 17 90 ff ff       	call   33f0 <strcpy@plt>
    a3d9:	e9 42 f2 ff ff       	jmp    9620 <fwp_write+0x80>
    a3de:	66 90                	xchg   %ax,%ax
    a3e0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a3e5:	45 85 c0             	test   %r8d,%r8d
    a3e8:	75 34                	jne    a41e <fwp_write+0xe7e>
    a3ea:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a3f1:	00 
    a3f2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a3f9:	00 00 
    a3fb:	0f 85 74 f6 ff ff    	jne    9a75 <fwp_write+0x4d5>
    a401:	ba 02 00 00 00       	mov    $0x2,%edx
    a406:	48 8d 35 d4 4d 00 00 	lea    0x4dd4(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    a40d:	e9 a1 f3 ff ff       	jmp    97b3 <fwp_write+0x213>
    a412:	48 03 75 10          	add    0x10(%rbp),%rsi
    a416:	49 89 f0             	mov    %rsi,%r8
    a419:	e9 e5 fc ff ff       	jmp    a103 <fwp_write+0xb63>
    a41e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a423:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a428:	85 ff                	test   %edi,%edi
    a42a:	0f 84 fa f3 ff ff    	je     982a <fwp_write+0x28a>
    a430:	ba 01 00 00 00       	mov    $0x1,%edx
    a435:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a43a:	48 89 df             	mov    %rbx,%rdi
    a43d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a442:	e8 29 9c ff ff       	call   4070 <buf_put>
    a447:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a44c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a451:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a457:	85 c0                	test   %eax,%eax
    a459:	0f 8f f0 f3 ff ff    	jg     984f <fwp_write+0x2af>
    a45f:	e9 34 f4 ff ff       	jmp    9898 <fwp_write+0x2f8>
    a464:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a468:	49 89 c5             	mov    %rax,%r13
    a46b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a470:	49 89 c4             	mov    %rax,%r12
    a473:	49 c1 fd 3f          	sar    $0x3f,%r13
    a477:	4c 09 e8             	or     %r13,%rax
    a47a:	0f 84 a7 00 00 00    	je     a527 <fwp_write+0xf87>
    a480:	48 8d 2d 99 6f 00 00 	lea    0x6f99(%rip),%rbp        # 11420 <units.1>
    a487:	4d 89 e7             	mov    %r12,%r15
    a48a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a48e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a493:	4c 89 ff             	mov    %r15,%rdi
    a496:	4c 89 ee             	mov    %r13,%rsi
    a499:	44 89 0c 24          	mov    %r9d,(%rsp)
    a49d:	48 99                	cqto
    a49f:	48 89 d1             	mov    %rdx,%rcx
    a4a2:	48 89 c2             	mov    %rax,%rdx
    a4a5:	e8 96 41 00 00       	call   e640 <__divmodti4>
    a4aa:	44 8b 0c 24          	mov    (%rsp),%r9d
    a4ae:	48 89 c1             	mov    %rax,%rcx
    a4b1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a4b6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a4bb:	0f 84 94 00 00 00    	je     a555 <fwp_write+0xfb5>
    a4c1:	41 83 c1 01          	add    $0x1,%r9d
    a4c5:	48 83 c5 10          	add    $0x10,%rbp
    a4c9:	41 83 f9 05          	cmp    $0x5,%r9d
    a4cd:	75 bb                	jne    a48a <fwp_write+0xeea>
    a4cf:	4d 85 ed             	test   %r13,%r13
    a4d2:	79 53                	jns    a527 <fwp_write+0xf87>
    a4d4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a4d9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a4de:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a4e3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a4e8:	48 99                	cqto
    a4ea:	48 f7 d8             	neg    %rax
    a4ed:	48 83 d2 00          	adc    $0x0,%rdx
    a4f1:	48 89 c6             	mov    %rax,%rsi
    a4f4:	48 f7 da             	neg    %rdx
    a4f7:	e8 44 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a4fc:	49 89 e8             	mov    %rbp,%r8
    a4ff:	ba 00 02 00 00       	mov    $0x200,%edx
    a504:	be 02 00 00 00       	mov    $0x2,%esi
    a509:	31 c0                	xor    %eax,%eax
    a50b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a512:	00 
    a513:	48 8d 0d c2 4c 00 00 	lea    0x4cc2(%rip),%rcx        # f1dc <_IO_stdin_used+0x1dc>
    a51a:	4c 89 e7             	mov    %r12,%rdi
    a51d:	e8 be 91 ff ff       	call   36e0 <__sprintf_chk@plt>
    a522:	e9 f9 f0 ff ff       	jmp    9620 <fwp_write+0x80>
    a527:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a52c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a531:	31 d2                	xor    %edx,%edx
    a533:	48 89 ef             	mov    %rbp,%rdi
    a536:	e8 05 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a53b:	eb bf                	jmp    a4fc <fwp_write+0xf5c>
    a53d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a544:	4e 61 4e 00 
    a548:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a54f:	00 
    a550:	e9 cb f0 ff ff       	jmp    9620 <fwp_write+0x80>
    a555:	44 89 0c 24          	mov    %r9d,(%rsp)
    a559:	48 89 c8             	mov    %rcx,%rax
    a55c:	48 85 d2             	test   %rdx,%rdx
    a55f:	78 51                	js     a5b2 <fwp_write+0x1012>
    a561:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a566:	48 89 c6             	mov    %rax,%rsi
    a569:	48 89 ef             	mov    %rbp,%rdi
    a56c:	e8 cf 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a571:	44 8b 0c 24          	mov    (%rsp),%r9d
    a575:	49 63 c1             	movslq %r9d,%rax
    a578:	49 89 e8             	mov    %rbp,%r8
    a57b:	ba 00 02 00 00       	mov    $0x200,%edx
    a580:	be 02 00 00 00       	mov    $0x2,%esi
    a585:	48 c1 e0 04          	shl    $0x4,%rax
    a589:	48 8d 3d 90 6e 00 00 	lea    0x6e90(%rip),%rdi        # 11420 <units.1>
    a590:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a597:	00 
    a598:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a59c:	48 8d 0d 34 4c 00 00 	lea    0x4c34(%rip),%rcx        # f1d7 <_IO_stdin_used+0x1d7>
    a5a3:	4c 89 e7             	mov    %r12,%rdi
    a5a6:	31 c0                	xor    %eax,%eax
    a5a8:	e8 33 91 ff ff       	call   36e0 <__sprintf_chk@plt>
    a5ad:	e9 6e f0 ff ff       	jmp    9620 <fwp_write+0x80>
    a5b2:	48 f7 d8             	neg    %rax
    a5b5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a5ba:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a5bf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a5c4:	48 83 d2 00          	adc    $0x0,%rdx
    a5c8:	48 89 c6             	mov    %rax,%rsi
    a5cb:	48 f7 da             	neg    %rdx
    a5ce:	e8 6d 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a5d3:	44 8b 0c 24          	mov    (%rsp),%r9d
    a5d7:	eb 9c                	jmp    a575 <fwp_write+0xfd5>
    a5d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a5e0 <fwp_hof0.constprop.0>:
    a5e0:	55                   	push   %rbp
    a5e1:	48 89 e5             	mov    %rsp,%rbp
    a5e4:	41 57                	push   %r15
    a5e6:	41 56                	push   %r14
    a5e8:	41 55                	push   %r13
    a5ea:	41 54                	push   %r12
    a5ec:	53                   	push   %rbx
    a5ed:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a5f4:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a5fb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a602:	00 00 
    a604:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a608:	31 c0                	xor    %eax,%eax
    a60a:	48 85 f6             	test   %rsi,%rsi
    a60d:	0f 84 86 06 00 00    	je     ac99 <fwp_hof0.constprop.0+0x6b9>
    a613:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a617:	49 89 f7             	mov    %rsi,%r15
    a61a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a621:	48 8d 35 58 91 01 00 	lea    0x19158(%rip),%rsi        # 23780 <fwp_heap>
    a628:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a62f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a636:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a63d:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a641:	48 c1 e2 10          	shl    $0x10,%rdx
    a645:	48 39 d0             	cmp    %rdx,%rax
    a648:	73 5d                	jae    a6a7 <fwp_hof0.constprop.0+0xc7>
    a64a:	48 89 c2             	mov    %rax,%rdx
    a64d:	48 c1 ea 10          	shr    $0x10,%rdx
    a651:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a655:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a65c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a660:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a664:	48 85 ff             	test   %rdi,%rdi
    a667:	74 3e                	je     a6a7 <fwp_hof0.constprop.0+0xc7>
    a669:	0f b6 0a             	movzbl (%rdx),%ecx
    a66c:	80 f9 02             	cmp    $0x2,%cl
    a66f:	0f 84 cd 0a 00 00    	je     b142 <fwp_hof0.constprop.0+0xb62>
    a675:	80 f9 01             	cmp    $0x1,%cl
    a678:	75 2d                	jne    a6a7 <fwp_hof0.constprop.0+0xc7>
    a67a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a67d:	0f b7 c0             	movzwl %ax,%eax
    a680:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a683:	48 0f af c1          	imul   %rcx,%rax
    a687:	48 c1 e8 20          	shr    $0x20,%rax
    a68b:	48 39 d0             	cmp    %rdx,%rax
    a68e:	73 17                	jae    a6a7 <fwp_hof0.constprop.0+0xc7>
    a690:	48 01 c7             	add    %rax,%rdi
    a693:	0f b6 07             	movzbl (%rdi),%eax
    a696:	84 c0                	test   %al,%al
    a698:	74 0d                	je     a6a7 <fwp_hof0.constprop.0+0xc7>
    a69a:	3c fd                	cmp    $0xfd,%al
    a69c:	0f 87 7e 0b 00 00    	ja     b220 <fwp_hof0.constprop.0+0xc40>
    a6a2:	83 c0 01             	add    $0x1,%eax
    a6a5:	88 07                	mov    %al,(%rdi)
    a6a7:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a6ae:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a6b5:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a6bc:	c7 00 00 00 
    a6c0:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a6c4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a6c8:	48 8b 15 09 ad 01 00 	mov    0x1ad09(%rip),%rdx        # 253d8 <fwp_fns>
    a6cf:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a6d3:	48 8d 05 3e 89 00 00 	lea    0x893e(%rip),%rax        # 13018 <fc12>
    a6da:	44 8b 20             	mov    (%rax),%r12d
    a6dd:	49 c1 e4 05          	shl    $0x5,%r12
    a6e1:	49 01 d4             	add    %rdx,%r12
    a6e4:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a6e9:	48 85 c9             	test   %rcx,%rcx
    a6ec:	0f 84 1d 0a 00 00    	je     b10f <fwp_hof0.constprop.0+0xb2f>
    a6f2:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    a6f7:	0f 84 7b 08 00 00    	je     af78 <fwp_hof0.constprop.0+0x998>
    a6fd:	48 8d 3d 7c 90 01 00 	lea    0x1907c(%rip),%rdi        # 23780 <fwp_heap>
    a704:	48 8d 05 0d 89 00 00 	lea    0x890d(%rip),%rax        # 13018 <fc12>
    a70b:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    a712:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    a719:	48 89 f1             	mov    %rsi,%rcx
    a71c:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    a720:	48 c1 e1 10          	shl    $0x10,%rcx
    a724:	48 39 c8             	cmp    %rcx,%rax
    a727:	73 5f                	jae    a788 <fwp_hof0.constprop.0+0x1a8>
    a729:	48 89 c1             	mov    %rax,%rcx
    a72c:	48 c1 e9 10          	shr    $0x10,%rcx
    a730:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a734:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    a73b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a73f:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    a743:	48 85 ff             	test   %rdi,%rdi
    a746:	74 40                	je     a788 <fwp_hof0.constprop.0+0x1a8>
    a748:	0f b6 31             	movzbl (%rcx),%esi
    a74b:	40 80 fe 02          	cmp    $0x2,%sil
    a74f:	0f 84 08 09 00 00    	je     b05d <fwp_hof0.constprop.0+0xa7d>
    a755:	40 80 fe 01          	cmp    $0x1,%sil
    a759:	75 2d                	jne    a788 <fwp_hof0.constprop.0+0x1a8>
    a75b:	8b 71 18             	mov    0x18(%rcx),%esi
    a75e:	0f b7 c0             	movzwl %ax,%eax
    a761:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a764:	48 0f af c6          	imul   %rsi,%rax
    a768:	48 c1 e8 20          	shr    $0x20,%rax
    a76c:	48 39 c8             	cmp    %rcx,%rax
    a76f:	73 17                	jae    a788 <fwp_hof0.constprop.0+0x1a8>
    a771:	48 01 c7             	add    %rax,%rdi
    a774:	0f b6 07             	movzbl (%rdi),%eax
    a777:	84 c0                	test   %al,%al
    a779:	74 0d                	je     a788 <fwp_hof0.constprop.0+0x1a8>
    a77b:	3c fd                	cmp    $0xfd,%al
    a77d:	0f 87 66 09 00 00    	ja     b0e9 <fwp_hof0.constprop.0+0xb09>
    a783:	83 c0 01             	add    $0x1,%eax
    a786:	88 07                	mov    %al,(%rdi)
    a788:	48 8d 05 89 88 00 00 	lea    0x8889(%rip),%rax        # 13018 <fc12>
    a78f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    a796:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a79a:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    a7a1:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    a7a5:	48 8d 05 6c 88 00 00 	lea    0x886c(%rip),%rax        # 13018 <fc12>
    a7ac:	41 8b 0c 24          	mov    (%r12),%ecx
    a7b0:	2b 48 04             	sub    0x4(%rax),%ecx
    a7b3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a7b7:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    a7bb:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    a7be:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    a7c2:	49 89 c1             	mov    %rax,%r9
    a7c5:	8b 00                	mov    (%rax),%eax
    a7c7:	44 39 e9             	cmp    %r13d,%ecx
    a7ca:	44 0f 46 e9          	cmovbe %ecx,%r13d
    a7ce:	4d 89 cf             	mov    %r9,%r15
    a7d1:	48 c1 e0 05          	shl    $0x5,%rax
    a7d5:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    a7d9:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    a7e0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a7e4:	4d 85 d2             	test   %r10,%r10
    a7e7:	75 58                	jne    a841 <fwp_hof0.constprop.0+0x261>
    a7e9:	e9 f5 01 00 00       	jmp    a9e3 <fwp_hof0.constprop.0+0x403>
    a7ee:	66 90                	xchg   %ax,%ax
    a7f0:	45 85 ff             	test   %r15d,%r15d
    a7f3:	74 69                	je     a85e <fwp_hof0.constprop.0+0x27e>
    a7f5:	4c 89 e7             	mov    %r12,%rdi
    a7f8:	41 ff 12             	call   *(%r10)
    a7fb:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    a7ff:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    a803:	e8 68 c3 ff ff       	call   6b70 <fwp_closure_drop>
    a808:	44 39 eb             	cmp    %r13d,%ebx
    a80b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    a80f:	0f 84 53 07 00 00    	je     af68 <fwp_hof0.constprop.0+0x988>
    a815:	44 8b 00             	mov    (%rax),%r8d
    a818:	45 29 fe             	sub    %r15d,%r14d
    a81b:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    a81f:	49 89 c1             	mov    %rax,%r9
    a822:	45 89 f5             	mov    %r14d,%r13d
    a825:	49 c1 e0 05          	shl    $0x5,%r8
    a829:	4c 03 05 a8 ab 01 00 	add    0x1aba8(%rip),%r8        # 253d8 <fwp_fns>
    a830:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a834:	4d 85 d2             	test   %r10,%r10
    a837:	0f 84 a3 01 00 00    	je     a9e0 <fwp_hof0.constprop.0+0x400>
    a83d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a841:	41 8b 49 04          	mov    0x4(%r9),%ecx
    a845:	45 8b 38             	mov    (%r8),%r15d
    a848:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    a84c:	45 39 fe             	cmp    %r15d,%r14d
    a84f:	0f 82 6b 04 00 00    	jb     acc0 <fwp_hof0.constprop.0+0x6e0>
    a855:	44 89 fb             	mov    %r15d,%ebx
    a858:	29 cb                	sub    %ecx,%ebx
    a85a:	85 c9                	test   %ecx,%ecx
    a85c:	74 92                	je     a7f0 <fwp_hof0.constprop.0+0x210>
    a85e:	45 85 ff             	test   %r15d,%r15d
    a861:	b8 01 00 00 00       	mov    $0x1,%eax
    a866:	48 89 e6             	mov    %rsp,%rsi
    a869:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    a86d:	41 0f 45 c7          	cmovne %r15d,%eax
    a871:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    a878:	00 
    a879:	48 c1 e8 04          	shr    $0x4,%rax
    a87d:	48 c1 e0 04          	shl    $0x4,%rax
    a881:	48 89 c7             	mov    %rax,%rdi
    a884:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    a88b:	48 29 fe             	sub    %rdi,%rsi
    a88e:	48 39 f4             	cmp    %rsi,%rsp
    a891:	74 15                	je     a8a8 <fwp_hof0.constprop.0+0x2c8>
    a893:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    a89a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    a8a1:	00 00 
    a8a3:	48 39 f4             	cmp    %rsi,%rsp
    a8a6:	75 eb                	jne    a893 <fwp_hof0.constprop.0+0x2b3>
    a8a8:	25 ff 0f 00 00       	and    $0xfff,%eax
    a8ad:	48 29 c4             	sub    %rax,%rsp
    a8b0:	48 85 c0             	test   %rax,%rax
    a8b3:	74 06                	je     a8bb <fwp_hof0.constprop.0+0x2db>
    a8b5:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    a8bb:	89 cf                	mov    %ecx,%edi
    a8bd:	49 89 e3             	mov    %rsp,%r11
    a8c0:	31 c0                	xor    %eax,%eax
    a8c2:	48 c1 e7 03          	shl    $0x3,%rdi
    a8c6:	85 c9                	test   %ecx,%ecx
    a8c8:	74 28                	je     a8f2 <fwp_hof0.constprop.0+0x312>
    a8ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8d1:	00 00 00 00 
    a8d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8dc:	00 00 00 00 
    a8e0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    a8e5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    a8e9:	48 83 c0 08          	add    $0x8,%rax
    a8ed:	48 39 c7             	cmp    %rax,%rdi
    a8f0:	75 ee                	jne    a8e0 <fwp_hof0.constprop.0+0x300>
    a8f2:	85 db                	test   %ebx,%ebx
    a8f4:	74 1f                	je     a915 <fwp_hof0.constprop.0+0x335>
    a8f6:	89 de                	mov    %ebx,%esi
    a8f8:	4c 89 e0             	mov    %r12,%rax
    a8fb:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    a8ff:	90                   	nop
    a900:	48 8b 30             	mov    (%rax),%rsi
    a903:	89 ca                	mov    %ecx,%edx
    a905:	48 83 c0 08          	add    $0x8,%rax
    a909:	83 c1 01             	add    $0x1,%ecx
    a90c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    a910:	48 39 c7             	cmp    %rax,%rdi
    a913:	75 eb                	jne    a900 <fwp_hof0.constprop.0+0x320>
    a915:	48 8d 15 64 8e 01 00 	lea    0x18e64(%rip),%rdx        # 23780 <fwp_heap>
    a91c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a920:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    a927:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    a92e:	48 89 f1             	mov    %rsi,%rcx
    a931:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    a935:	48 c1 e1 10          	shl    $0x10,%rcx
    a939:	48 39 c8             	cmp    %rcx,%rax
    a93c:	73 4c                	jae    a98a <fwp_hof0.constprop.0+0x3aa>
    a93e:	48 89 c1             	mov    %rax,%rcx
    a941:	48 c1 e9 10          	shr    $0x10,%rcx
    a945:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a949:	48 8b 0d 28 a2 01 00 	mov    0x1a228(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    a950:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a954:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a958:	48 85 f6             	test   %rsi,%rsi
    a95b:	74 2d                	je     a98a <fwp_hof0.constprop.0+0x3aa>
    a95d:	0f b6 39             	movzbl (%rcx),%edi
    a960:	40 80 ff 02          	cmp    $0x2,%dil
    a964:	74 6a                	je     a9d0 <fwp_hof0.constprop.0+0x3f0>
    a966:	40 80 ff 01          	cmp    $0x1,%dil
    a96a:	75 1e                	jne    a98a <fwp_hof0.constprop.0+0x3aa>
    a96c:	8b 79 18             	mov    0x18(%rcx),%edi
    a96f:	0f b7 c0             	movzwl %ax,%eax
    a972:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a975:	48 0f af c7          	imul   %rdi,%rax
    a979:	48 c1 e8 20          	shr    $0x20,%rax
    a97d:	48 39 c8             	cmp    %rcx,%rax
    a980:	73 08                	jae    a98a <fwp_hof0.constprop.0+0x3aa>
    a982:	48 01 c6             	add    %rax,%rsi
    a985:	80 3e 01             	cmpb   $0x1,(%rsi)
    a988:	74 36                	je     a9c0 <fwp_hof0.constprop.0+0x3e0>
    a98a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    a98e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    a992:	be 01 00 00 00       	mov    $0x1,%esi
    a997:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    a99b:	41 ff 52 08          	call   *0x8(%r10)
    a99f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    a9a3:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    a9a7:	49 8b 40 18          	mov    0x18(%r8),%rax
    a9ab:	4c 89 df             	mov    %r11,%rdi
    a9ae:	ff 10                	call   *(%rax)
    a9b0:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    a9b4:	e9 42 fe ff ff       	jmp    a7fb <fwp_hof0.constprop.0+0x21b>
    a9b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9c0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    a9c7:	00 
    a9c8:	eb dd                	jmp    a9a7 <fwp_hof0.constprop.0+0x3c7>
    a9ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9d0:	66 85 c0             	test   %ax,%ax
    a9d3:	75 b5                	jne    a98a <fwp_hof0.constprop.0+0x3aa>
    a9d5:	eb ae                	jmp    a985 <fwp_hof0.constprop.0+0x3a5>
    a9d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9de:	00 00 
    a9e0:	49 89 c7             	mov    %rax,%r15
    a9e3:	4c 89 ff             	mov    %r15,%rdi
    a9e6:	e8 65 ba ff ff       	call   6450 <fwp_rc_share>
    a9eb:	45 85 ed             	test   %r13d,%r13d
    a9ee:	74 21                	je     aa11 <fwp_hof0.constprop.0+0x431>
    a9f0:	44 89 ea             	mov    %r13d,%edx
    a9f3:	4c 89 e3             	mov    %r12,%rbx
    a9f6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    a9fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa00:	48 8b 3b             	mov    (%rbx),%rdi
    aa03:	48 83 c3 08          	add    $0x8,%rbx
    aa07:	e8 44 ba ff ff       	call   6450 <fwp_rc_share>
    aa0c:	4c 39 f3             	cmp    %r14,%rbx
    aa0f:	75 ef                	jne    aa00 <fwp_hof0.constprop.0+0x420>
    aa11:	4c 89 e2             	mov    %r12,%rdx
    aa14:	44 89 ee             	mov    %r13d,%esi
    aa17:	4c 89 ff             	mov    %r15,%rdi
    aa1a:	e8 51 b1 ff ff       	call   5b70 <fwp_apply>
    aa1f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aa23:	8b 75 94             	mov    -0x6c(%rbp),%esi
    aa26:	39 75 90             	cmp    %esi,-0x70(%rbp)
    aa29:	0f 83 87 00 00 00    	jae    aab6 <fwp_hof0.constprop.0+0x4d6>
    aa2f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    aa35:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    aa39:	48 89 c2             	mov    %rax,%rdx
    aa3c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    aa40:	29 d6                	sub    %edx,%esi
    aa42:	48 8b 15 8f a9 01 00 	mov    0x1a98f(%rip),%rdx        # 253d8 <fwp_fns>
    aa49:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aa4d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    aa50:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    aa54:	44 8b 26             	mov    (%rsi),%r12d
    aa57:	48 89 f0             	mov    %rsi,%rax
    aa5a:	49 c1 e4 05          	shl    $0x5,%r12
    aa5e:	49 01 d4             	add    %rdx,%r12
    aa61:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    aa67:	0f 85 3f fd ff ff    	jne    a7ac <fwp_hof0.constprop.0+0x1cc>
    aa6d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aa71:	e8 da b9 ff ff       	call   6450 <fwp_rc_share>
    aa76:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    aa7a:	45 85 f6             	test   %r14d,%r14d
    aa7d:	74 23                	je     aaa2 <fwp_hof0.constprop.0+0x4c2>
    aa7f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    aa83:	31 db                	xor    %ebx,%ebx
    aa85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa8c:	00 00 00 00 
    aa90:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    aa94:	48 83 c3 01          	add    $0x1,%rbx
    aa98:	e8 b3 b9 ff ff       	call   6450 <fwp_rc_share>
    aa9d:	44 39 f3             	cmp    %r14d,%ebx
    aaa0:	72 ee                	jb     aa90 <fwp_hof0.constprop.0+0x4b0>
    aaa2:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    aaa6:	8b 75 94             	mov    -0x6c(%rbp),%esi
    aaa9:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aaad:	e8 be b0 ff ff       	call   5b70 <fwp_apply>
    aab2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aab6:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    aabd:	01 
    aabe:	0f 85 00 fc ff ff    	jne    a6c4 <fwp_hof0.constprop.0+0xe4>
    aac4:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    aac8:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    aacf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aad3:	b9 01 00 00 00       	mov    $0x1,%ecx
    aad8:	48 8d 15 c1 80 00 00 	lea    0x80c1(%rip),%rdx        # 12ba0 <d0>
    aadf:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    aae6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    aaed:	00 
    aaee:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    aaf2:	e8 a9 ea ff ff       	call   95a0 <fwp_write>
    aaf7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    aafb:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    aaff:	48 8d 05 28 45 00 00 	lea    0x4528(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    ab06:	48 85 c9             	test   %rcx,%rcx
    ab09:	48 0f 44 c8          	cmove  %rax,%rcx
    ab0d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    ab11:	0f 87 f5 06 00 00    	ja     b20c <fwp_hof0.constprop.0+0xc2c>
    ab17:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    ab1b:	be 01 00 00 00       	mov    $0x1,%esi
    ab20:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    ab24:	e8 27 af ff ff       	call   5a50 <fwp_heap_alloc>
    ab29:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    ab2d:	4c 89 f2             	mov    %r14,%rdx
    ab30:	4c 89 30             	mov    %r14,(%rax)
    ab33:	4c 8d 60 08          	lea    0x8(%rax),%r12
    ab37:	48 89 c3             	mov    %rax,%rbx
    ab3a:	4c 89 e7             	mov    %r12,%rdi
    ab3d:	e8 5e 8a ff ff       	call   35a0 <memcpy@plt>
    ab42:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ab48:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    ab4c:	e8 6f 88 ff ff       	call   33c0 <free@plt>
    ab51:	48 8d 35 28 8c 01 00 	lea    0x18c28(%rip),%rsi        # 23780 <fwp_heap>
    ab58:	48 89 d8             	mov    %rbx,%rax
    ab5b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ab62:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ab69:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ab6d:	48 c1 e2 10          	shl    $0x10,%rdx
    ab71:	48 39 d0             	cmp    %rdx,%rax
    ab74:	73 57                	jae    abcd <fwp_hof0.constprop.0+0x5ed>
    ab76:	48 89 c2             	mov    %rax,%rdx
    ab79:	48 c1 ea 10          	shr    $0x10,%rdx
    ab7d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab81:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ab88:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab8c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ab90:	4d 85 f6             	test   %r14,%r14
    ab93:	74 38                	je     abcd <fwp_hof0.constprop.0+0x5ed>
    ab95:	0f b6 0a             	movzbl (%rdx),%ecx
    ab98:	80 f9 02             	cmp    $0x2,%cl
    ab9b:	0f 84 c9 05 00 00    	je     b16a <fwp_hof0.constprop.0+0xb8a>
    aba1:	80 f9 01             	cmp    $0x1,%cl
    aba4:	75 27                	jne    abcd <fwp_hof0.constprop.0+0x5ed>
    aba6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aba9:	0f b7 c0             	movzwl %ax,%eax
    abac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    abaf:	48 0f af c1          	imul   %rcx,%rax
    abb3:	48 c1 e8 20          	shr    $0x20,%rax
    abb7:	48 39 d0             	cmp    %rdx,%rax
    abba:	73 11                	jae    abcd <fwp_hof0.constprop.0+0x5ed>
    abbc:	49 01 c6             	add    %rax,%r14
    abbf:	41 80 3e ff          	cmpb   $0xff,(%r14)
    abc3:	0f 84 67 06 00 00    	je     b230 <fwp_hof0.constprop.0+0xc50>
    abc9:	41 c6 06 01          	movb   $0x1,(%r14)
    abcd:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    abd1:	e8 ba bc ff ff       	call   6890 <fwp_drop0>
    abd6:	48 8b 13             	mov    (%rbx),%rdx
    abd9:	be 01 00 00 00       	mov    $0x1,%esi
    abde:	4c 89 e7             	mov    %r12,%rdi
    abe1:	48 8b 0d f8 a7 01 00 	mov    0x1a7f8(%rip),%rcx        # 253e0 <fwp_prog_out>
    abe8:	e8 93 8a ff ff       	call   3680 <fwrite@plt>
    abed:	48 8b 35 ec a7 01 00 	mov    0x1a7ec(%rip),%rsi        # 253e0 <fwp_prog_out>
    abf4:	bf 0a 00 00 00       	mov    $0xa,%edi
    abf9:	e8 e2 88 ff ff       	call   34e0 <fputc@plt>
    abfe:	48 8d 35 7b 8b 01 00 	lea    0x18b7b(%rip),%rsi        # 23780 <fwp_heap>
    ac05:	48 89 d8             	mov    %rbx,%rax
    ac08:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ac0f:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ac16:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    ac1a:	48 c1 e2 10          	shl    $0x10,%rdx
    ac1e:	48 39 d0             	cmp    %rdx,%rax
    ac21:	73 69                	jae    ac8c <fwp_hof0.constprop.0+0x6ac>
    ac23:	48 89 c2             	mov    %rax,%rdx
    ac26:	48 c1 ea 10          	shr    $0x10,%rdx
    ac2a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac2e:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ac35:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac39:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac3d:	4d 85 e4             	test   %r12,%r12
    ac40:	74 4a                	je     ac8c <fwp_hof0.constprop.0+0x6ac>
    ac42:	0f b6 0a             	movzbl (%rdx),%ecx
    ac45:	80 f9 02             	cmp    $0x2,%cl
    ac48:	0f 84 2a 05 00 00    	je     b178 <fwp_hof0.constprop.0+0xb98>
    ac4e:	80 f9 01             	cmp    $0x1,%cl
    ac51:	75 39                	jne    ac8c <fwp_hof0.constprop.0+0x6ac>
    ac53:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac56:	0f b7 c0             	movzwl %ax,%eax
    ac59:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac5c:	48 0f af c1          	imul   %rcx,%rax
    ac60:	48 c1 e8 20          	shr    $0x20,%rax
    ac64:	48 39 d0             	cmp    %rdx,%rax
    ac67:	73 23                	jae    ac8c <fwp_hof0.constprop.0+0x6ac>
    ac69:	49 01 c4             	add    %rax,%r12
    ac6c:	41 0f b6 04 24       	movzbl (%r12),%eax
    ac71:	84 c0                	test   %al,%al
    ac73:	74 17                	je     ac8c <fwp_hof0.constprop.0+0x6ac>
    ac75:	3c 01                	cmp    $0x1,%al
    ac77:	0f 84 d3 04 00 00    	je     b150 <fwp_hof0.constprop.0+0xb70>
    ac7d:	3c ff                	cmp    $0xff,%al
    ac7f:	0f 84 01 05 00 00    	je     b186 <fwp_hof0.constprop.0+0xba6>
    ac85:	83 e8 01             	sub    $0x1,%eax
    ac88:	41 88 04 24          	mov    %al,(%r12)
    ac8c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    ac90:	4d 85 ff             	test   %r15,%r15
    ac93:	0f 85 88 f9 ff ff    	jne    a621 <fwp_hof0.constprop.0+0x41>
    ac99:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    ac9d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aca4:	00 00 
    aca6:	0f 85 7e 05 00 00    	jne    b22a <fwp_hof0.constprop.0+0xc4a>
    acac:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    acb0:	31 c0                	xor    %eax,%eax
    acb2:	5b                   	pop    %rbx
    acb3:	41 5c                	pop    %r12
    acb5:	41 5d                	pop    %r13
    acb7:	41 5e                	pop    %r14
    acb9:	41 5f                	pop    %r15
    acbb:	5d                   	pop    %rbp
    acbc:	c3                   	ret
    acbd:	0f 1f 00             	nopl   (%rax)
    acc0:	48 8d 1d b9 8a 01 00 	lea    0x18ab9(%rip),%rbx        # 23780 <fwp_heap>
    acc7:	41 8d 76 01          	lea    0x1(%r14),%esi
    accb:	45 89 f7             	mov    %r14d,%r15d
    acce:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    acd4:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    acdb:	00 
    acdc:	85 c0                	test   %eax,%eax
    acde:	0f 84 a9 03 00 00    	je     b08d <fwp_hof0.constprop.0+0xaad>
    ace4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    aceb:	0f 87 9c 03 00 00    	ja     b08d <fwp_hof0.constprop.0+0xaad>
    acf1:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    acf5:	48 c1 e8 04          	shr    $0x4,%rax
    acf9:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    ad00:	00 
    ad01:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    ad08:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    ad0c:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    ad10:	4c 8b 12             	mov    (%rdx),%r10
    ad13:	4d 85 d2             	test   %r10,%r10
    ad16:	0f 84 4f 03 00 00    	je     b06b <fwp_hof0.constprop.0+0xa8b>
    ad1c:	4d 8b 1a             	mov    (%r10),%r11
    ad1f:	49 f7 d3             	not    %r11
    ad22:	4c 89 1a             	mov    %r11,(%rdx)
    ad25:	48 39 c7             	cmp    %rax,%rdi
    ad28:	73 50                	jae    ad7a <fwp_hof0.constprop.0+0x79a>
    ad2a:	48 89 fa             	mov    %rdi,%rdx
    ad2d:	48 83 c7 08          	add    $0x8,%rdi
    ad31:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    ad38:	00 
    ad39:	48 f7 d2             	not    %rdx
    ad3c:	48 01 c2             	add    %rax,%rdx
    ad3f:	48 c1 ea 03          	shr    $0x3,%rdx
    ad43:	48 39 c7             	cmp    %rax,%rdi
    ad46:	73 32                	jae    ad7a <fwp_hof0.constprop.0+0x79a>
    ad48:	83 e2 01             	and    $0x1,%edx
    ad4b:	74 13                	je     ad60 <fwp_hof0.constprop.0+0x780>
    ad4d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ad54:	00 
    ad55:	48 83 c7 08          	add    $0x8,%rdi
    ad59:	48 39 c7             	cmp    %rax,%rdi
    ad5c:	73 1c                	jae    ad7a <fwp_hof0.constprop.0+0x79a>
    ad5e:	66 90                	xchg   %ax,%ax
    ad60:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ad67:	00 
    ad68:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    ad6f:	00 00 
    ad71:	48 83 c7 10          	add    $0x10,%rdi
    ad75:	48 39 c7             	cmp    %rax,%rdi
    ad78:	72 e6                	jb     ad60 <fwp_hof0.constprop.0+0x780>
    ad7a:	48 8d 35 ff 89 01 00 	lea    0x189ff(%rip),%rsi        # 23780 <fwp_heap>
    ad81:	48 89 c2             	mov    %rax,%rdx
    ad84:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    ad8b:	0f 82 6a 04 00 00    	jb     b1fb <fwp_hof0.constprop.0+0xc1b>
    ad91:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    ad98:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    ad9f:	73 07                	jae    ada8 <fwp_hof0.constprop.0+0x7c8>
    ada1:	48 89 15 00 9e 01 00 	mov    %rdx,0x19e00(%rip)        # 24ba8 <fwp_heap+0x1428>
    ada8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    adac:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    adb1:	f2 0f 58 05 ff 9d 01 	addsd  0x19dff(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    adb8:	00 
    adb9:	f2 0f 11 05 f7 9d 01 	movsd  %xmm0,0x19df7(%rip)        # 24bb8 <fwp_heap+0x1438>
    adc0:	00 
    adc1:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    adc6:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    adcb:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    adcf:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    add4:	85 c9                	test   %ecx,%ecx
    add6:	74 37                	je     ae0f <fwp_hof0.constprop.0+0x82f>
    add8:	89 ca                	mov    %ecx,%edx
    adda:	49 8d 71 08          	lea    0x8(%r9),%rsi
    adde:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    ade2:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    ade5:	48 c1 e2 03          	shl    $0x3,%rdx
    ade9:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    adf0:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    adf4:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    adf8:	e8 13 88 ff ff       	call   3610 <memmove@plt>
    adfd:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    ae01:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    ae05:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    ae08:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    ae0f:	45 85 ed             	test   %r13d,%r13d
    ae12:	74 23                	je     ae37 <fwp_hof0.constprop.0+0x857>
    ae14:	45 89 ed             	mov    %r13d,%r13d
    ae17:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    ae1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ae20:	49 8b 14 24          	mov    (%r12),%rdx
    ae24:	89 c8                	mov    %ecx,%eax
    ae26:	49 83 c4 08          	add    $0x8,%r12
    ae2a:	83 c1 01             	add    $0x1,%ecx
    ae2d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    ae32:	4c 39 e6             	cmp    %r12,%rsi
    ae35:	75 e9                	jne    ae20 <fwp_hof0.constprop.0+0x840>
    ae37:	48 8d 35 42 89 01 00 	lea    0x18942(%rip),%rsi        # 23780 <fwp_heap>
    ae3e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ae42:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ae49:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ae50:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ae54:	48 c1 e2 10          	shl    $0x10,%rdx
    ae58:	48 39 d0             	cmp    %rdx,%rax
    ae5b:	73 54                	jae    aeb1 <fwp_hof0.constprop.0+0x8d1>
    ae5d:	48 89 c2             	mov    %rax,%rdx
    ae60:	48 c1 ea 10          	shr    $0x10,%rdx
    ae64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae68:	48 8b 15 09 9d 01 00 	mov    0x19d09(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ae6f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae73:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    ae77:	48 85 c9             	test   %rcx,%rcx
    ae7a:	74 35                	je     aeb1 <fwp_hof0.constprop.0+0x8d1>
    ae7c:	0f b6 32             	movzbl (%rdx),%esi
    ae7f:	40 80 fe 02          	cmp    $0x2,%sil
    ae83:	0f 84 52 02 00 00    	je     b0db <fwp_hof0.constprop.0+0xafb>
    ae89:	40 80 fe 01          	cmp    $0x1,%sil
    ae8d:	75 22                	jne    aeb1 <fwp_hof0.constprop.0+0x8d1>
    ae8f:	8b 72 18             	mov    0x18(%rdx),%esi
    ae92:	0f b7 c0             	movzwl %ax,%eax
    ae95:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae98:	48 0f af c6          	imul   %rsi,%rax
    ae9c:	48 c1 e8 20          	shr    $0x20,%rax
    aea0:	48 39 d0             	cmp    %rdx,%rax
    aea3:	73 0c                	jae    aeb1 <fwp_hof0.constprop.0+0x8d1>
    aea5:	48 01 c1             	add    %rax,%rcx
    aea8:	80 39 01             	cmpb   $0x1,(%rcx)
    aeab:	0f 84 9f 01 00 00    	je     b050 <fwp_hof0.constprop.0+0xa70>
    aeb1:	49 8b 40 18          	mov    0x18(%r8),%rax
    aeb5:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    aeb9:	be 01 00 00 00       	mov    $0x1,%esi
    aebe:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aec2:	ff 50 08             	call   *0x8(%rax)
    aec5:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    aec9:	48 8d 35 b0 88 01 00 	lea    0x188b0(%rip),%rsi        # 23780 <fwp_heap>
    aed0:	4c 89 d0             	mov    %r10,%rax
    aed3:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    aeda:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    aee1:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    aee5:	48 c1 e2 10          	shl    $0x10,%rdx
    aee9:	48 39 d0             	cmp    %rdx,%rax
    aeec:	73 59                	jae    af47 <fwp_hof0.constprop.0+0x967>
    aeee:	48 89 c2             	mov    %rax,%rdx
    aef1:	48 c1 ea 10          	shr    $0x10,%rdx
    aef5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aef9:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    af00:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af04:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af08:	4d 85 e4             	test   %r12,%r12
    af0b:	74 3a                	je     af47 <fwp_hof0.constprop.0+0x967>
    af0d:	0f b6 0a             	movzbl (%rdx),%ecx
    af10:	80 f9 02             	cmp    $0x2,%cl
    af13:	0f 84 99 01 00 00    	je     b0b2 <fwp_hof0.constprop.0+0xad2>
    af19:	80 f9 01             	cmp    $0x1,%cl
    af1c:	75 29                	jne    af47 <fwp_hof0.constprop.0+0x967>
    af1e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af21:	0f b7 c0             	movzwl %ax,%eax
    af24:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af27:	48 0f af c1          	imul   %rcx,%rax
    af2b:	48 c1 e8 20          	shr    $0x20,%rax
    af2f:	48 39 d0             	cmp    %rdx,%rax
    af32:	73 13                	jae    af47 <fwp_hof0.constprop.0+0x967>
    af34:	49 01 c4             	add    %rax,%r12
    af37:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af3c:	0f 84 84 01 00 00    	je     b0c6 <fwp_hof0.constprop.0+0xae6>
    af42:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af47:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    af4b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    af4f:	e8 1c bc ff ff       	call   6b70 <fwp_closure_drop>
    af54:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    af58:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    af5c:	e9 c2 fa ff ff       	jmp    aa23 <fwp_hof0.constprop.0+0x443>
    af61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af68:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af6c:	e9 b2 fa ff ff       	jmp    aa23 <fwp_hof0.constprop.0+0x443>
    af71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af78:	41 8b 34 24          	mov    (%r12),%esi
    af7c:	8b 05 9a 80 00 00    	mov    0x809a(%rip),%eax        # 1301c <fc12+0x4>
    af82:	89 f7                	mov    %esi,%edi
    af84:	29 c7                	sub    %eax,%edi
    af86:	83 ff 01             	cmp    $0x1,%edi
    af89:	0f 85 6e f7 ff ff    	jne    a6fd <fwp_hof0.constprop.0+0x11d>
    af8f:	48 89 e3             	mov    %rsp,%rbx
    af92:	85 c0                	test   %eax,%eax
    af94:	0f 84 60 01 00 00    	je     b0fa <fwp_hof0.constprop.0+0xb1a>
    af9a:	89 f1                	mov    %esi,%ecx
    af9c:	ba 08 00 00 00       	mov    $0x8,%edx
    afa1:	48 c1 e1 03          	shl    $0x3,%rcx
    afa5:	85 f6                	test   %esi,%esi
    afa7:	48 89 e6             	mov    %rsp,%rsi
    afaa:	48 0f 45 d1          	cmovne %rcx,%rdx
    afae:	49 89 d7             	mov    %rdx,%r15
    afb1:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    afb5:	48 c1 ea 04          	shr    $0x4,%rdx
    afb9:	48 c1 e2 04          	shl    $0x4,%rdx
    afbd:	48 89 d7             	mov    %rdx,%rdi
    afc0:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    afc7:	48 29 fe             	sub    %rdi,%rsi
    afca:	48 39 f4             	cmp    %rsi,%rsp
    afcd:	74 15                	je     afe4 <fwp_hof0.constprop.0+0xa04>
    afcf:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    afd6:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    afdd:	00 00 
    afdf:	48 39 f4             	cmp    %rsi,%rsp
    afe2:	75 eb                	jne    afcf <fwp_hof0.constprop.0+0x9ef>
    afe4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    afea:	48 29 d4             	sub    %rdx,%rsp
    afed:	48 85 d2             	test   %rdx,%rdx
    aff0:	74 06                	je     aff8 <fwp_hof0.constprop.0+0xa18>
    aff2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    aff8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    afff:	00 
    b000:	4c 89 f9             	mov    %r15,%rcx
    b003:	48 8d 35 16 80 00 00 	lea    0x8016(%rip),%rsi        # 13020 <fwp_epfd>
    b00a:	48 89 e7             	mov    %rsp,%rdi
    b00d:	4c 89 f2             	mov    %r14,%rdx
    b010:	e8 5b 85 ff ff       	call   3570 <__memcpy_chk@plt>
    b015:	4d 39 f7             	cmp    %r14,%r15
    b018:	4c 89 f9             	mov    %r15,%rcx
    b01b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b01f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b023:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b02a:	ba 08 00 00 00       	mov    $0x8,%edx
    b02f:	4c 29 f1             	sub    %r14,%rcx
    b032:	e8 39 85 ff ff       	call   3570 <__memcpy_chk@plt>
    b037:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b03c:	48 89 e7             	mov    %rsp,%rdi
    b03f:	ff 10                	call   *(%rax)
    b041:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b045:	e9 bd 00 00 00       	jmp    b107 <fwp_hof0.constprop.0+0xb27>
    b04a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b050:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b057:	00 
    b058:	e9 6c fe ff ff       	jmp    aec9 <fwp_hof0.constprop.0+0x8e9>
    b05d:	66 85 c0             	test   %ax,%ax
    b060:	0f 85 22 f7 ff ff    	jne    a788 <fwp_hof0.constprop.0+0x1a8>
    b066:	e9 09 f7 ff ff       	jmp    a774 <fwp_hof0.constprop.0+0x194>
    b06b:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b06f:	4d 85 d2             	test   %r10,%r10
    b072:	74 19                	je     b08d <fwp_hof0.constprop.0+0xaad>
    b074:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b078:	4d 29 d3             	sub    %r10,%r11
    b07b:	49 39 c3             	cmp    %rax,%r11
    b07e:	72 0d                	jb     b08d <fwp_hof0.constprop.0+0xaad>
    b080:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b084:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b088:	e9 98 fc ff ff       	jmp    ad25 <fwp_hof0.constprop.0+0x745>
    b08d:	31 f6                	xor    %esi,%esi
    b08f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b092:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b096:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b09a:	e8 b1 a9 ff ff       	call   5a50 <fwp_heap_alloc>
    b09f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b0a2:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b0a6:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b0aa:	49 89 c2             	mov    %rax,%r10
    b0ad:	e9 0f fd ff ff       	jmp    adc1 <fwp_hof0.constprop.0+0x7e1>
    b0b2:	66 85 c0             	test   %ax,%ax
    b0b5:	0f 85 8c fe ff ff    	jne    af47 <fwp_hof0.constprop.0+0x967>
    b0bb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b0c0:	0f 85 7c fe ff ff    	jne    af42 <fwp_hof0.constprop.0+0x962>
    b0c6:	4c 89 e7             	mov    %r12,%rdi
    b0c9:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b0cd:	e8 3e a2 ff ff       	call   5310 <fwp_rc_forget_slot>
    b0d2:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b0d6:	e9 67 fe ff ff       	jmp    af42 <fwp_hof0.constprop.0+0x962>
    b0db:	66 85 c0             	test   %ax,%ax
    b0de:	0f 85 cd fd ff ff    	jne    aeb1 <fwp_hof0.constprop.0+0x8d1>
    b0e4:	e9 bf fd ff ff       	jmp    aea8 <fwp_hof0.constprop.0+0x8c8>
    b0e9:	e8 02 a1 ff ff       	call   51f0 <fwp_rc_wide_dup>
    b0ee:	48 8b 15 e3 a2 01 00 	mov    0x1a2e3(%rip),%rdx        # 253d8 <fwp_fns>
    b0f5:	e9 8e f6 ff ff       	jmp    a788 <fwp_hof0.constprop.0+0x1a8>
    b0fa:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b101:	ff 11                	call   *(%rcx)
    b103:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b107:	48 89 dc             	mov    %rbx,%rsp
    b10a:	e9 a7 f9 ff ff       	jmp    aab6 <fwp_hof0.constprop.0+0x4d6>
    b10f:	48 89 c7             	mov    %rax,%rdi
    b112:	e8 39 b3 ff ff       	call   6450 <fwp_rc_share>
    b117:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b11b:	e8 30 b3 ff ff       	call   6450 <fwp_rc_share>
    b120:	48 8d 05 f1 7e 00 00 	lea    0x7ef1(%rip),%rax        # 13018 <fc12>
    b127:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b12e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b132:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b139:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b13d:	e9 60 f9 ff ff       	jmp    aaa2 <fwp_hof0.constprop.0+0x4c2>
    b142:	66 85 c0             	test   %ax,%ax
    b145:	0f 85 5c f5 ff ff    	jne    a6a7 <fwp_hof0.constprop.0+0xc7>
    b14b:	e9 43 f5 ff ff       	jmp    a693 <fwp_hof0.constprop.0+0xb3>
    b150:	48 89 df             	mov    %rbx,%rdi
    b153:	e8 28 b4 ff ff       	call   6580 <fwp_rc_free_arr>
    b158:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b15c:	4d 85 ff             	test   %r15,%r15
    b15f:	0f 85 bc f4 ff ff    	jne    a621 <fwp_hof0.constprop.0+0x41>
    b165:	e9 2f fb ff ff       	jmp    ac99 <fwp_hof0.constprop.0+0x6b9>
    b16a:	66 85 c0             	test   %ax,%ax
    b16d:	0f 85 5a fa ff ff    	jne    abcd <fwp_hof0.constprop.0+0x5ed>
    b173:	e9 47 fa ff ff       	jmp    abbf <fwp_hof0.constprop.0+0x5df>
    b178:	66 85 c0             	test   %ax,%ax
    b17b:	0f 85 0b fb ff ff    	jne    ac8c <fwp_hof0.constprop.0+0x6ac>
    b181:	e9 e6 fa ff ff       	jmp    ac6c <fwp_hof0.constprop.0+0x68c>
    b186:	4c 89 e0             	mov    %r12,%rax
    b189:	48 8d 35 f0 85 01 00 	lea    0x185f0(%rip),%rsi        # 23780 <fwp_heap>
    b190:	48 c1 e8 11          	shr    $0x11,%rax
    b194:	4c 31 e0             	xor    %r12,%rax
    b197:	48 89 c2             	mov    %rax,%rdx
    b19a:	48 c1 ea 09          	shr    $0x9,%rdx
    b19e:	48 31 d0             	xor    %rdx,%rax
    b1a1:	0f b6 c0             	movzbl %al,%eax
    b1a4:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b1ab:	00 
    b1ac:	48 85 d2             	test   %rdx,%rdx
    b1af:	75 18                	jne    b1c9 <fwp_hof0.constprop.0+0xbe9>
    b1b1:	eb 4d                	jmp    b200 <fwp_hof0.constprop.0+0xc20>
    b1b3:	66 90                	xchg   %ax,%ax
    b1b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b1bc:	00 00 00 00 
    b1c0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b1c4:	48 85 d2             	test   %rdx,%rdx
    b1c7:	74 37                	je     b200 <fwp_hof0.constprop.0+0xc20>
    b1c9:	48 89 d0             	mov    %rdx,%rax
    b1cc:	4c 39 22             	cmp    %r12,(%rdx)
    b1cf:	75 ef                	jne    b1c0 <fwp_hof0.constprop.0+0xbe0>
    b1d1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b1d5:	48 83 e8 01          	sub    $0x1,%rax
    b1d9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b1dd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b1e3:	0f 85 a3 fa ff ff    	jne    ac8c <fwp_hof0.constprop.0+0x6ac>
    b1e9:	4c 89 e7             	mov    %r12,%rdi
    b1ec:	e8 1f a1 ff ff       	call   5310 <fwp_rc_forget_slot>
    b1f1:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b1f6:	e9 91 fa ff ff       	jmp    ac8c <fwp_hof0.constprop.0+0x6ac>
    b1fb:	e8 b0 8a ff ff       	call   3cb0 <fwp_heap_oom>
    b200:	48 8d 3d 91 45 00 00 	lea    0x4591(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    b207:	e8 94 8f ff ff       	call   41a0 <fwp_trap>
    b20c:	48 8d 3d d5 3f 00 00 	lea    0x3fd5(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    b213:	e8 88 8f ff ff       	call   41a0 <fwp_trap>
    b218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b21f:	00 
    b220:	e8 cb 9f ff ff       	call   51f0 <fwp_rc_wide_dup>
    b225:	e9 7d f4 ff ff       	jmp    a6a7 <fwp_hof0.constprop.0+0xc7>
    b22a:	e8 31 82 ff ff       	call   3460 <__stack_chk_fail@plt>
    b22f:	90                   	nop
    b230:	4c 89 f7             	mov    %r14,%rdi
    b233:	e8 d8 a0 ff ff       	call   5310 <fwp_rc_forget_slot>
    b238:	e9 8c f9 ff ff       	jmp    abc9 <fwp_hof0.constprop.0+0x5e9>
    b23d:	0f 1f 00             	nopl   (%rax)

000000000000b240 <f0>:
    b240:	41 56                	push   %r14
    b242:	4c 8d 35 37 85 01 00 	lea    0x18537(%rip),%r14        # 23780 <fwp_heap>
    b249:	41 55                	push   %r13
    b24b:	41 54                	push   %r12
    b24d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b253:	55                   	push   %rbp
    b254:	53                   	push   %rbx
    b255:	31 db                	xor    %ebx,%ebx
    b257:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b25e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b265:	00 00 
    b267:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b26e:	00 
    b26f:	31 c0                	xor    %eax,%eax
    b271:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b278:	00 
    b279:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b280:	00 00 
    b282:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b287:	48 8d 05 82 b7 ff ff 	lea    -0x487e(%rip),%rax        # 6a10 <fwp_drop1>
    b28e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b293:	48 8b 05 7e a1 01 00 	mov    0x1a17e(%rip),%rax        # 25418 <fwp_cleanups>
    b29a:	48 89 25 77 a1 01 00 	mov    %rsp,0x1a177(%rip)        # 25418 <fwp_cleanups>
    b2a1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b2a5:	48 89 04 24          	mov    %rax,(%rsp)
    b2a9:	48 8d 05 20 89 ff ff 	lea    -0x76e0(%rip),%rax        # 3bd0 <fwp_range_release>
    b2b0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b2b5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b2ba:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b2bf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b2c4:	eb 47                	jmp    b30d <f0+0xcd>
    b2c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b2cd:	00 00 00 
    b2d0:	80 f9 01             	cmp    $0x1,%cl
    b2d3:	75 29                	jne    b2fe <f0+0xbe>
    b2d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2d8:	0f b7 c0             	movzwl %ax,%eax
    b2db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2de:	48 0f af c1          	imul   %rcx,%rax
    b2e2:	48 c1 e8 20          	shr    $0x20,%rax
    b2e6:	48 39 d0             	cmp    %rdx,%rax
    b2e9:	73 13                	jae    b2fe <f0+0xbe>
    b2eb:	49 01 c5             	add    %rax,%r13
    b2ee:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b2f3:	0f 84 c7 27 00 00    	je     dac0 <f0+0x2880>
    b2f9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b2fe:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b303:	49 83 ec 01          	sub    $0x1,%r12
    b307:	0f 82 83 00 00 00    	jb     b390 <f0+0x150>
    b30d:	48 89 ee             	mov    %rbp,%rsi
    b310:	bf 01 00 00 00       	mov    $0x1,%edi
    b315:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b31c:	00 
    b31d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b322:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b329:	00 
    b32a:	e8 f1 af ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b32f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b336:	48 89 c3             	mov    %rax,%rbx
    b339:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b340:	48 c1 e2 10          	shl    $0x10,%rdx
    b344:	48 39 d0             	cmp    %rdx,%rax
    b347:	73 b5                	jae    b2fe <f0+0xbe>
    b349:	48 89 c2             	mov    %rax,%rdx
    b34c:	48 c1 ea 10          	shr    $0x10,%rdx
    b350:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b354:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b35b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b35f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b363:	4d 85 ed             	test   %r13,%r13
    b366:	74 96                	je     b2fe <f0+0xbe>
    b368:	0f b6 0a             	movzbl (%rdx),%ecx
    b36b:	80 f9 02             	cmp    $0x2,%cl
    b36e:	0f 85 5c ff ff ff    	jne    b2d0 <f0+0x90>
    b374:	66 85 c0             	test   %ax,%ax
    b377:	0f 84 71 ff ff ff    	je     b2ee <f0+0xae>
    b37d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b382:	49 83 ec 01          	sub    $0x1,%r12
    b386:	73 85                	jae    b30d <f0+0xcd>
    b388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b38f:	00 
    b390:	48 8b 04 24          	mov    (%rsp),%rax
    b394:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b399:	bf 01 00 00 00       	mov    $0x1,%edi
    b39e:	66 0f 6f 05 7a 47 00 	movdqa 0x477a(%rip),%xmm0        # fb20 <msg.4+0xa0>
    b3a5:	00 
    b3a6:	48 89 05 6b a0 01 00 	mov    %rax,0x1a06b(%rip)        # 25418 <fwp_cleanups>
    b3ad:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b3b2:	e8 69 af ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b3b7:	48 8b 15 9a 97 01 00 	mov    0x1979a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b3be:	49 89 c5             	mov    %rax,%r13
    b3c1:	48 2b 05 68 97 01 00 	sub    0x19768(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b3c8:	48 c1 e2 10          	shl    $0x10,%rdx
    b3cc:	48 39 d0             	cmp    %rdx,%rax
    b3cf:	73 59                	jae    b42a <f0+0x1ea>
    b3d1:	48 89 c2             	mov    %rax,%rdx
    b3d4:	48 c1 ea 10          	shr    $0x10,%rdx
    b3d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3dc:	48 8b 15 95 97 01 00 	mov    0x19795(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b3e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b3eb:	4d 85 e4             	test   %r12,%r12
    b3ee:	74 3a                	je     b42a <f0+0x1ea>
    b3f0:	0f b6 0a             	movzbl (%rdx),%ecx
    b3f3:	80 f9 02             	cmp    $0x2,%cl
    b3f6:	0f 84 74 27 00 00    	je     db70 <f0+0x2930>
    b3fc:	80 f9 01             	cmp    $0x1,%cl
    b3ff:	75 29                	jne    b42a <f0+0x1ea>
    b401:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b404:	0f b7 c0             	movzwl %ax,%eax
    b407:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b40a:	48 0f af c1          	imul   %rcx,%rax
    b40e:	48 c1 e8 20          	shr    $0x20,%rax
    b412:	48 39 d0             	cmp    %rdx,%rax
    b415:	73 13                	jae    b42a <f0+0x1ea>
    b417:	49 01 c4             	add    %rax,%r12
    b41a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b41f:	0f 84 26 29 00 00    	je     dd4b <f0+0x2b0b>
    b425:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b42a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b42f:	bf 01 00 00 00       	mov    $0x1,%edi
    b434:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b439:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b440:	00 f0 3f 
    b443:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b448:	e8 d3 ae ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b44d:	48 8b 15 04 97 01 00 	mov    0x19704(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b454:	49 89 c5             	mov    %rax,%r13
    b457:	48 2b 05 d2 96 01 00 	sub    0x196d2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b45e:	48 c1 e2 10          	shl    $0x10,%rdx
    b462:	48 39 d0             	cmp    %rdx,%rax
    b465:	73 59                	jae    b4c0 <f0+0x280>
    b467:	48 89 c2             	mov    %rax,%rdx
    b46a:	48 c1 ea 10          	shr    $0x10,%rdx
    b46e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b472:	48 8b 15 ff 96 01 00 	mov    0x196ff(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b479:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b47d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b481:	4d 85 e4             	test   %r12,%r12
    b484:	74 3a                	je     b4c0 <f0+0x280>
    b486:	0f b6 0a             	movzbl (%rdx),%ecx
    b489:	80 f9 02             	cmp    $0x2,%cl
    b48c:	0f 84 ce 26 00 00    	je     db60 <f0+0x2920>
    b492:	80 f9 01             	cmp    $0x1,%cl
    b495:	75 29                	jne    b4c0 <f0+0x280>
    b497:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b49a:	0f b7 c0             	movzwl %ax,%eax
    b49d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4a0:	48 0f af c1          	imul   %rcx,%rax
    b4a4:	48 c1 e8 20          	shr    $0x20,%rax
    b4a8:	48 39 d0             	cmp    %rdx,%rax
    b4ab:	73 13                	jae    b4c0 <f0+0x280>
    b4ad:	49 01 c4             	add    %rax,%r12
    b4b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4b5:	0f 84 9d 28 00 00    	je     dd58 <f0+0x2b18>
    b4bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4c0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b4c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b4ca:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b4cf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b4d6:	33 f3 bf 
    b4d9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b4de:	e8 3d ae ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b4e3:	48 8b 15 6e 96 01 00 	mov    0x1966e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b4ea:	49 89 c5             	mov    %rax,%r13
    b4ed:	48 2b 05 3c 96 01 00 	sub    0x1963c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b4f4:	48 c1 e2 10          	shl    $0x10,%rdx
    b4f8:	48 39 d0             	cmp    %rdx,%rax
    b4fb:	73 59                	jae    b556 <f0+0x316>
    b4fd:	48 89 c2             	mov    %rax,%rdx
    b500:	48 c1 ea 10          	shr    $0x10,%rdx
    b504:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b508:	48 8b 15 69 96 01 00 	mov    0x19669(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b50f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b513:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b517:	4d 85 e4             	test   %r12,%r12
    b51a:	74 3a                	je     b556 <f0+0x316>
    b51c:	0f b6 0a             	movzbl (%rdx),%ecx
    b51f:	80 f9 02             	cmp    $0x2,%cl
    b522:	0f 84 28 26 00 00    	je     db50 <f0+0x2910>
    b528:	80 f9 01             	cmp    $0x1,%cl
    b52b:	75 29                	jne    b556 <f0+0x316>
    b52d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b530:	0f b7 c0             	movzwl %ax,%eax
    b533:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b536:	48 0f af c1          	imul   %rcx,%rax
    b53a:	48 c1 e8 20          	shr    $0x20,%rax
    b53e:	48 39 d0             	cmp    %rdx,%rax
    b541:	73 13                	jae    b556 <f0+0x316>
    b543:	49 01 c4             	add    %rax,%r12
    b546:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b54b:	0f 84 14 28 00 00    	je     dd65 <f0+0x2b25>
    b551:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b556:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b55b:	bf 01 00 00 00       	mov    $0x1,%edi
    b560:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b565:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b56c:	00 f0 3f 
    b56f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b574:	e8 a7 ad ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b579:	48 8b 15 d8 95 01 00 	mov    0x195d8(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b580:	49 89 c5             	mov    %rax,%r13
    b583:	48 2b 05 a6 95 01 00 	sub    0x195a6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b58a:	48 c1 e2 10          	shl    $0x10,%rdx
    b58e:	48 39 d0             	cmp    %rdx,%rax
    b591:	73 59                	jae    b5ec <f0+0x3ac>
    b593:	48 89 c2             	mov    %rax,%rdx
    b596:	48 c1 ea 10          	shr    $0x10,%rdx
    b59a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b59e:	48 8b 15 d3 95 01 00 	mov    0x195d3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b5a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5a9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b5ad:	4d 85 e4             	test   %r12,%r12
    b5b0:	74 3a                	je     b5ec <f0+0x3ac>
    b5b2:	0f b6 0a             	movzbl (%rdx),%ecx
    b5b5:	80 f9 02             	cmp    $0x2,%cl
    b5b8:	0f 84 f2 25 00 00    	je     dbb0 <f0+0x2970>
    b5be:	80 f9 01             	cmp    $0x1,%cl
    b5c1:	75 29                	jne    b5ec <f0+0x3ac>
    b5c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5c6:	0f b7 c0             	movzwl %ax,%eax
    b5c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5cc:	48 0f af c1          	imul   %rcx,%rax
    b5d0:	48 c1 e8 20          	shr    $0x20,%rax
    b5d4:	48 39 d0             	cmp    %rdx,%rax
    b5d7:	73 13                	jae    b5ec <f0+0x3ac>
    b5d9:	49 01 c4             	add    %rax,%r12
    b5dc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b5e1:	0f 84 8b 27 00 00    	je     dd72 <f0+0x2b32>
    b5e7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b5ec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b5f3:	33 f3 bf 
    b5f6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b5fd:	00 
    b5fe:	bf 01 00 00 00       	mov    $0x1,%edi
    b603:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b60a:	00 
    b60b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b612:	00 
    b613:	e8 08 ad ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b618:	48 8b 15 39 95 01 00 	mov    0x19539(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b61f:	49 89 c5             	mov    %rax,%r13
    b622:	48 2b 05 07 95 01 00 	sub    0x19507(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b629:	48 c1 e2 10          	shl    $0x10,%rdx
    b62d:	48 39 d0             	cmp    %rdx,%rax
    b630:	73 59                	jae    b68b <f0+0x44b>
    b632:	48 89 c2             	mov    %rax,%rdx
    b635:	48 c1 ea 10          	shr    $0x10,%rdx
    b639:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b63d:	48 8b 15 34 95 01 00 	mov    0x19534(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b644:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b648:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b64c:	4d 85 e4             	test   %r12,%r12
    b64f:	74 3a                	je     b68b <f0+0x44b>
    b651:	0f b6 0a             	movzbl (%rdx),%ecx
    b654:	80 f9 02             	cmp    $0x2,%cl
    b657:	0f 84 43 25 00 00    	je     dba0 <f0+0x2960>
    b65d:	80 f9 01             	cmp    $0x1,%cl
    b660:	75 29                	jne    b68b <f0+0x44b>
    b662:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b665:	0f b7 c0             	movzwl %ax,%eax
    b668:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b66b:	48 0f af c1          	imul   %rcx,%rax
    b66f:	48 c1 e8 20          	shr    $0x20,%rax
    b673:	48 39 d0             	cmp    %rdx,%rax
    b676:	73 13                	jae    b68b <f0+0x44b>
    b678:	49 01 c4             	add    %rax,%r12
    b67b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b680:	0f 84 f9 26 00 00    	je     dd7f <f0+0x2b3f>
    b686:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b68b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b692:	00 f0 3f 
    b695:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b69c:	00 
    b69d:	bf 01 00 00 00       	mov    $0x1,%edi
    b6a2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b6a9:	00 
    b6aa:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b6b1:	00 
    b6b2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b6b9:	33 f3 bf 
    b6bc:	e8 5f ac ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b6c1:	48 89 c7             	mov    %rax,%rdi
    b6c4:	e8 07 ae ff ff       	call   64d0 <fwp_rc_fresh>
    b6c9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b6d0:	00 
    b6d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6d6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b6dd:	00 
    b6de:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b6e5:	00 
    b6e6:	e8 35 ac ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b6eb:	48 89 c7             	mov    %rax,%rdi
    b6ee:	e8 dd ad ff ff       	call   64d0 <fwp_rc_fresh>
    b6f3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b6fa:	00 
    b6fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b700:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b707:	00 
    b708:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b70f:	00 
    b710:	e8 0b ac ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b715:	48 89 c7             	mov    %rax,%rdi
    b718:	e8 b3 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b71d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b724:	00 
    b725:	bf 01 00 00 00       	mov    $0x1,%edi
    b72a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b731:	00 
    b732:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b739:	00 
    b73a:	e8 e1 ab ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b73f:	48 89 c7             	mov    %rax,%rdi
    b742:	e8 89 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b747:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b74e:	00 
    b74f:	bf 01 00 00 00       	mov    $0x1,%edi
    b754:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b75b:	00 
    b75c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b763:	00 
    b764:	e8 b7 ab ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b769:	48 89 c7             	mov    %rax,%rdi
    b76c:	e8 5f ad ff ff       	call   64d0 <fwp_rc_fresh>
    b771:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b778:	00 
    b779:	bf 01 00 00 00       	mov    $0x1,%edi
    b77e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b785:	00 
    b786:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b78d:	00 
    b78e:	e8 8d ab ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b793:	48 89 c7             	mov    %rax,%rdi
    b796:	e8 35 ad ff ff       	call   64d0 <fwp_rc_fresh>
    b79b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b7a2:	00 
    b7a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7a8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b7af:	00 
    b7b0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b7b7:	00 
    b7b8:	e8 63 ab ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b7bd:	48 89 c7             	mov    %rax,%rdi
    b7c0:	e8 0b ad ff ff       	call   64d0 <fwp_rc_fresh>
    b7c5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b7cc:	00 
    b7cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b7d2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b7d9:	00 
    b7da:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b7e1:	00 
    b7e2:	e8 39 ab ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b7e7:	48 89 c7             	mov    %rax,%rdi
    b7ea:	e8 e1 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b7ef:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b7f6:	00 
    b7f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7fc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b803:	00 
    b804:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b80b:	00 
    b80c:	e8 0f ab ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b811:	48 89 c7             	mov    %rax,%rdi
    b814:	e8 b7 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b819:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b820:	00 
    b821:	bf 01 00 00 00       	mov    $0x1,%edi
    b826:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b82d:	00 
    b82e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b835:	00 
    b836:	e8 e5 aa ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b83b:	48 89 c7             	mov    %rax,%rdi
    b83e:	e8 8d ac ff ff       	call   64d0 <fwp_rc_fresh>
    b843:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b84a:	00 
    b84b:	bf 01 00 00 00       	mov    $0x1,%edi
    b850:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b857:	00 
    b858:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b85f:	00 
    b860:	e8 bb aa ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b865:	48 89 c7             	mov    %rax,%rdi
    b868:	e8 63 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b86d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b874:	00 
    b875:	bf 01 00 00 00       	mov    $0x1,%edi
    b87a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b881:	00 
    b882:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b889:	00 
    b88a:	e8 91 aa ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b88f:	48 89 c7             	mov    %rax,%rdi
    b892:	e8 39 ac ff ff       	call   64d0 <fwp_rc_fresh>
    b897:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b89e:	00 
    b89f:	bf 01 00 00 00       	mov    $0x1,%edi
    b8a4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b8ab:	00 
    b8ac:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b8b3:	00 
    b8b4:	e8 67 aa ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b8b9:	48 89 c7             	mov    %rax,%rdi
    b8bc:	e8 0f ac ff ff       	call   64d0 <fwp_rc_fresh>
    b8c1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b8c8:	00 
    b8c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ce:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b8d5:	00 
    b8d6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b8dd:	00 
    b8de:	e8 3d aa ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b8e3:	48 89 c7             	mov    %rax,%rdi
    b8e6:	e8 e5 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b8eb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b8f2:	00 
    b8f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b8f8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b8ff:	00 
    b900:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b907:	00 
    b908:	e8 13 aa ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b90d:	48 89 c7             	mov    %rax,%rdi
    b910:	e8 bb ab ff ff       	call   64d0 <fwp_rc_fresh>
    b915:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b91c:	00 
    b91d:	bf 01 00 00 00       	mov    $0x1,%edi
    b922:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b929:	00 
    b92a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b931:	00 
    b932:	e8 e9 a9 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b937:	48 89 c7             	mov    %rax,%rdi
    b93a:	e8 91 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b93f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b946:	00 
    b947:	bf 01 00 00 00       	mov    $0x1,%edi
    b94c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b953:	00 
    b954:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b95b:	00 
    b95c:	e8 bf a9 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b961:	48 89 c7             	mov    %rax,%rdi
    b964:	e8 67 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b969:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b970:	00 
    b971:	bf 01 00 00 00       	mov    $0x1,%edi
    b976:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b97d:	00 
    b97e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b985:	00 
    b986:	e8 95 a9 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b98b:	48 89 c7             	mov    %rax,%rdi
    b98e:	e8 3d ab ff ff       	call   64d0 <fwp_rc_fresh>
    b993:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b99a:	00 
    b99b:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b9a7:	00 
    b9a8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b9af:	00 
    b9b0:	e8 6b a9 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b9b5:	48 89 c7             	mov    %rax,%rdi
    b9b8:	e8 13 ab ff ff       	call   64d0 <fwp_rc_fresh>
    b9bd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b9c4:	00 
    b9c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ca:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b9d1:	00 
    b9d2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b9d9:	00 
    b9da:	e8 41 a9 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    b9df:	48 89 c7             	mov    %rax,%rdi
    b9e2:	e8 e9 aa ff ff       	call   64d0 <fwp_rc_fresh>
    b9e7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b9ee:	00 
    b9ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b9f4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b9fb:	00 
    b9fc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    ba03:	00 
    ba04:	e8 17 a9 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ba09:	48 89 c7             	mov    %rax,%rdi
    ba0c:	e8 bf aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba11:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    ba18:	00 
    ba19:	bf 01 00 00 00       	mov    $0x1,%edi
    ba1e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    ba25:	00 
    ba26:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    ba2d:	00 
    ba2e:	e8 ed a8 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ba33:	48 89 c7             	mov    %rax,%rdi
    ba36:	e8 95 aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba3b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    ba42:	00 
    ba43:	bf 01 00 00 00       	mov    $0x1,%edi
    ba48:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    ba4f:	00 
    ba50:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    ba57:	00 
    ba58:	e8 c3 a8 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ba5d:	48 89 c7             	mov    %rax,%rdi
    ba60:	e8 6b aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba65:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    ba6c:	00 
    ba6d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba72:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    ba79:	00 
    ba7a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    ba81:	00 
    ba82:	e8 99 a8 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ba87:	48 89 c7             	mov    %rax,%rdi
    ba8a:	e8 41 aa ff ff       	call   64d0 <fwp_rc_fresh>
    ba8f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    ba96:	00 
    ba97:	bf 01 00 00 00       	mov    $0x1,%edi
    ba9c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    baa3:	00 
    baa4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    baab:	00 
    baac:	e8 6f a8 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bab1:	48 89 c7             	mov    %rax,%rdi
    bab4:	e8 17 aa ff ff       	call   64d0 <fwp_rc_fresh>
    bab9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bac0:	00 
    bac1:	bf 01 00 00 00       	mov    $0x1,%edi
    bac6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bacd:	00 
    bace:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bad5:	00 
    bad6:	e8 45 a8 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    badb:	48 89 c7             	mov    %rax,%rdi
    bade:	e8 ed a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bae3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    baea:	00 
    baeb:	bf 01 00 00 00       	mov    $0x1,%edi
    baf0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    baf7:	00 
    baf8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    baff:	00 
    bb00:	e8 1b a8 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bb05:	48 89 c7             	mov    %rax,%rdi
    bb08:	e8 c3 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb0d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bb14:	00 
    bb15:	bf 01 00 00 00       	mov    $0x1,%edi
    bb1a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bb21:	00 
    bb22:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bb29:	00 
    bb2a:	e8 f1 a7 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bb2f:	48 89 c7             	mov    %rax,%rdi
    bb32:	e8 99 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb37:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bb3e:	00 
    bb3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb44:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bb4b:	00 
    bb4c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bb53:	00 
    bb54:	e8 c7 a7 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bb59:	48 89 c7             	mov    %rax,%rdi
    bb5c:	e8 6f a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb61:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bb68:	00 
    bb69:	bf 01 00 00 00       	mov    $0x1,%edi
    bb6e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bb75:	00 
    bb76:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bb7d:	00 
    bb7e:	e8 9d a7 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bb83:	48 89 c7             	mov    %rax,%rdi
    bb86:	e8 45 a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bb8b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bb92:	00 
    bb93:	bf 01 00 00 00       	mov    $0x1,%edi
    bb98:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bb9f:	00 
    bba0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bba7:	00 
    bba8:	e8 73 a7 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bbad:	48 89 c7             	mov    %rax,%rdi
    bbb0:	e8 1b a9 ff ff       	call   64d0 <fwp_rc_fresh>
    bbb5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bbbc:	00 
    bbbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbc2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bbc9:	00 
    bbca:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bbd1:	00 
    bbd2:	e8 49 a7 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bbd7:	48 89 c7             	mov    %rax,%rdi
    bbda:	e8 f1 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bbdf:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bbe6:	00 
    bbe7:	bf 01 00 00 00       	mov    $0x1,%edi
    bbec:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bbf3:	00 
    bbf4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bbfb:	00 
    bbfc:	e8 1f a7 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bc01:	48 89 c7             	mov    %rax,%rdi
    bc04:	e8 c7 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc09:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bc10:	00 
    bc11:	bf 01 00 00 00       	mov    $0x1,%edi
    bc16:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bc1d:	00 
    bc1e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bc25:	00 
    bc26:	e8 f5 a6 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bc2b:	48 89 c7             	mov    %rax,%rdi
    bc2e:	e8 9d a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc33:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bc3a:	00 
    bc3b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc40:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bc47:	00 
    bc48:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bc4f:	00 
    bc50:	e8 cb a6 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bc55:	48 89 c7             	mov    %rax,%rdi
    bc58:	e8 73 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc5d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bc64:	00 
    bc65:	bf 01 00 00 00       	mov    $0x1,%edi
    bc6a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bc71:	00 
    bc72:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bc79:	00 
    bc7a:	e8 a1 a6 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bc7f:	48 89 c7             	mov    %rax,%rdi
    bc82:	e8 49 a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bc87:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bc8e:	00 
    bc8f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc94:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bc9b:	00 
    bc9c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bca3:	00 
    bca4:	e8 77 a6 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bca9:	48 89 c7             	mov    %rax,%rdi
    bcac:	e8 1f a8 ff ff       	call   64d0 <fwp_rc_fresh>
    bcb1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bcb8:	00 
    bcb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcbe:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bcc5:	00 
    bcc6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bccd:	00 
    bcce:	e8 4d a6 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bcd3:	48 89 c7             	mov    %rax,%rdi
    bcd6:	e8 f5 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bcdb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bce2:	00 
    bce3:	bf 01 00 00 00       	mov    $0x1,%edi
    bce8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bcef:	00 
    bcf0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bcf7:	00 
    bcf8:	e8 23 a6 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bcfd:	48 89 c7             	mov    %rax,%rdi
    bd00:	e8 cb a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd05:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bd0c:	00 
    bd0d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd12:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bd19:	00 
    bd1a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bd21:	00 
    bd22:	e8 f9 a5 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bd27:	48 89 c7             	mov    %rax,%rdi
    bd2a:	e8 a1 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd2f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bd36:	00 
    bd37:	bf 01 00 00 00       	mov    $0x1,%edi
    bd3c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bd43:	00 
    bd44:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bd4b:	00 
    bd4c:	e8 cf a5 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bd51:	48 89 c7             	mov    %rax,%rdi
    bd54:	e8 77 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd59:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bd60:	00 
    bd61:	bf 01 00 00 00       	mov    $0x1,%edi
    bd66:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bd6d:	00 
    bd6e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bd75:	00 
    bd76:	e8 a5 a5 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bd7b:	48 89 c7             	mov    %rax,%rdi
    bd7e:	e8 4d a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bd83:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bd8a:	00 
    bd8b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd90:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bd97:	00 
    bd98:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bd9f:	00 
    bda0:	e8 7b a5 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bda5:	48 89 c7             	mov    %rax,%rdi
    bda8:	e8 23 a7 ff ff       	call   64d0 <fwp_rc_fresh>
    bdad:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bdb4:	00 
    bdb5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdba:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bdc1:	00 
    bdc2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bdc9:	00 
    bdca:	e8 51 a5 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bdcf:	48 89 c7             	mov    %rax,%rdi
    bdd2:	e8 f9 a6 ff ff       	call   64d0 <fwp_rc_fresh>
    bdd7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bdde:	00 
    bddf:	bf 01 00 00 00       	mov    $0x1,%edi
    bde4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bdeb:	00 
    bdec:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bdf3:	00 
    bdf4:	e8 27 a5 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bdf9:	48 89 c7             	mov    %rax,%rdi
    bdfc:	e8 cf a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be01:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    be08:	00 
    be09:	bf 01 00 00 00       	mov    $0x1,%edi
    be0e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    be15:	00 
    be16:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    be1d:	00 
    be1e:	e8 fd a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    be23:	48 89 c7             	mov    %rax,%rdi
    be26:	e8 a5 a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be2b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    be32:	00 
    be33:	bf 01 00 00 00       	mov    $0x1,%edi
    be38:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    be3f:	00 
    be40:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    be47:	00 
    be48:	e8 d3 a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    be4d:	48 89 c7             	mov    %rax,%rdi
    be50:	e8 7b a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be55:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    be5c:	00 
    be5d:	bf 01 00 00 00       	mov    $0x1,%edi
    be62:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    be69:	00 
    be6a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    be71:	00 
    be72:	e8 a9 a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    be77:	48 89 c7             	mov    %rax,%rdi
    be7a:	e8 51 a6 ff ff       	call   64d0 <fwp_rc_fresh>
    be7f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    be86:	00 
    be87:	bf 01 00 00 00       	mov    $0x1,%edi
    be8c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    be93:	00 
    be94:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    be9b:	00 
    be9c:	e8 7f a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bea1:	48 89 c7             	mov    %rax,%rdi
    bea4:	e8 27 a6 ff ff       	call   64d0 <fwp_rc_fresh>
    bea9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    beb0:	00 
    beb1:	bf 01 00 00 00       	mov    $0x1,%edi
    beb6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bebd:	00 
    bebe:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bec5:	00 
    bec6:	e8 55 a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    becb:	48 89 c7             	mov    %rax,%rdi
    bece:	e8 fd a5 ff ff       	call   64d0 <fwp_rc_fresh>
    bed3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    beda:	00 
    bedb:	bf 01 00 00 00       	mov    $0x1,%edi
    bee0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bee7:	00 
    bee8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    beef:	00 
    bef0:	e8 2b a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bef5:	48 89 c7             	mov    %rax,%rdi
    bef8:	e8 d3 a5 ff ff       	call   64d0 <fwp_rc_fresh>
    befd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bf04:	00 
    bf05:	bf 01 00 00 00       	mov    $0x1,%edi
    bf0a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bf11:	00 
    bf12:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bf19:	00 
    bf1a:	e8 01 a4 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bf1f:	48 89 c7             	mov    %rax,%rdi
    bf22:	e8 a9 a5 ff ff       	call   64d0 <fwp_rc_fresh>
    bf27:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bf2e:	00 
    bf2f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf34:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bf3b:	00 
    bf3c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bf43:	00 
    bf44:	e8 d7 a3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bf49:	48 89 c7             	mov    %rax,%rdi
    bf4c:	e8 7f a5 ff ff       	call   64d0 <fwp_rc_fresh>
    bf51:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bf58:	00 
    bf59:	bf 01 00 00 00       	mov    $0x1,%edi
    bf5e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bf65:	00 
    bf66:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bf6d:	00 
    bf6e:	e8 ad a3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bf73:	48 89 c7             	mov    %rax,%rdi
    bf76:	e8 55 a5 ff ff       	call   64d0 <fwp_rc_fresh>
    bf7b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bf82:	00 
    bf83:	bf 01 00 00 00       	mov    $0x1,%edi
    bf88:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bf8f:	00 
    bf90:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bf97:	00 
    bf98:	e8 83 a3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bf9d:	48 89 c7             	mov    %rax,%rdi
    bfa0:	e8 2b a5 ff ff       	call   64d0 <fwp_rc_fresh>
    bfa5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bfac:	00 
    bfad:	bf 01 00 00 00       	mov    $0x1,%edi
    bfb2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bfb9:	00 
    bfba:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bfc1:	00 
    bfc2:	e8 59 a3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bfc7:	48 89 c7             	mov    %rax,%rdi
    bfca:	e8 01 a5 ff ff       	call   64d0 <fwp_rc_fresh>
    bfcf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bfd6:	00 
    bfd7:	bf 01 00 00 00       	mov    $0x1,%edi
    bfdc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bfe3:	00 
    bfe4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    bfeb:	00 
    bfec:	e8 2f a3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    bff1:	48 89 c7             	mov    %rax,%rdi
    bff4:	e8 d7 a4 ff ff       	call   64d0 <fwp_rc_fresh>
    bff9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c000:	00 
    c001:	bf 01 00 00 00       	mov    $0x1,%edi
    c006:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c00d:	00 
    c00e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c015:	00 
    c016:	e8 05 a3 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c01b:	48 89 c7             	mov    %rax,%rdi
    c01e:	e8 ad a4 ff ff       	call   64d0 <fwp_rc_fresh>
    c023:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c02a:	00 
    c02b:	bf 01 00 00 00       	mov    $0x1,%edi
    c030:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c037:	00 
    c038:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c03f:	00 
    c040:	e8 db a2 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c045:	48 89 c7             	mov    %rax,%rdi
    c048:	e8 83 a4 ff ff       	call   64d0 <fwp_rc_fresh>
    c04d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c054:	00 
    c055:	bf 01 00 00 00       	mov    $0x1,%edi
    c05a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c061:	00 
    c062:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c069:	00 
    c06a:	e8 b1 a2 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c06f:	48 89 c7             	mov    %rax,%rdi
    c072:	e8 59 a4 ff ff       	call   64d0 <fwp_rc_fresh>
    c077:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c07e:	00 
    c07f:	bf 01 00 00 00       	mov    $0x1,%edi
    c084:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c08b:	00 
    c08c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c093:	00 
    c094:	e8 87 a2 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c099:	48 89 c7             	mov    %rax,%rdi
    c09c:	e8 2f a4 ff ff       	call   64d0 <fwp_rc_fresh>
    c0a1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c0a8:	00 
    c0a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ae:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c0b5:	00 
    c0b6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c0bd:	00 
    c0be:	e8 5d a2 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c0c3:	48 89 c7             	mov    %rax,%rdi
    c0c6:	e8 05 a4 ff ff       	call   64d0 <fwp_rc_fresh>
    c0cb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c0d2:	00 
    c0d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c0d8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c0df:	00 
    c0e0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c0e7:	00 
    c0e8:	e8 33 a2 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c0ed:	48 89 c7             	mov    %rax,%rdi
    c0f0:	e8 db a3 ff ff       	call   64d0 <fwp_rc_fresh>
    c0f5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c0fc:	00 
    c0fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c102:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c109:	00 
    c10a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c111:	00 
    c112:	e8 09 a2 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c117:	48 89 c7             	mov    %rax,%rdi
    c11a:	e8 b1 a3 ff ff       	call   64d0 <fwp_rc_fresh>
    c11f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c126:	00 
    c127:	bf 01 00 00 00       	mov    $0x1,%edi
    c12c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c133:	00 
    c134:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c13b:	00 
    c13c:	e8 df a1 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c141:	48 89 c7             	mov    %rax,%rdi
    c144:	e8 87 a3 ff ff       	call   64d0 <fwp_rc_fresh>
    c149:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c150:	00 
    c151:	bf 01 00 00 00       	mov    $0x1,%edi
    c156:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c15d:	00 
    c15e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c165:	00 
    c166:	e8 b5 a1 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c16b:	48 89 c7             	mov    %rax,%rdi
    c16e:	e8 5d a3 ff ff       	call   64d0 <fwp_rc_fresh>
    c173:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c17a:	00 
    c17b:	bf 01 00 00 00       	mov    $0x1,%edi
    c180:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c187:	00 
    c188:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c18f:	00 
    c190:	e8 8b a1 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c195:	48 89 c7             	mov    %rax,%rdi
    c198:	e8 33 a3 ff ff       	call   64d0 <fwp_rc_fresh>
    c19d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c1a4:	00 
    c1a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c1aa:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c1b1:	00 
    c1b2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c1b9:	00 
    c1ba:	e8 61 a1 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c1bf:	48 89 c7             	mov    %rax,%rdi
    c1c2:	e8 09 a3 ff ff       	call   64d0 <fwp_rc_fresh>
    c1c7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c1ce:	00 
    c1cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c1db:	00 
    c1dc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c1e3:	00 
    c1e4:	e8 37 a1 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c1e9:	48 89 c7             	mov    %rax,%rdi
    c1ec:	e8 df a2 ff ff       	call   64d0 <fwp_rc_fresh>
    c1f1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c1f8:	00 
    c1f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c1fe:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c205:	00 
    c206:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c20d:	00 
    c20e:	e8 0d a1 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c213:	48 89 c7             	mov    %rax,%rdi
    c216:	e8 b5 a2 ff ff       	call   64d0 <fwp_rc_fresh>
    c21b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c222:	00 
    c223:	bf 01 00 00 00       	mov    $0x1,%edi
    c228:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c22f:	00 
    c230:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c237:	00 
    c238:	e8 e3 a0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c23d:	48 89 c7             	mov    %rax,%rdi
    c240:	e8 8b a2 ff ff       	call   64d0 <fwp_rc_fresh>
    c245:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c24c:	00 
    c24d:	bf 01 00 00 00       	mov    $0x1,%edi
    c252:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c259:	00 
    c25a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c261:	00 
    c262:	e8 b9 a0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c267:	48 89 c7             	mov    %rax,%rdi
    c26a:	e8 61 a2 ff ff       	call   64d0 <fwp_rc_fresh>
    c26f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c276:	00 
    c277:	bf 01 00 00 00       	mov    $0x1,%edi
    c27c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c283:	00 
    c284:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c28b:	00 
    c28c:	e8 8f a0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c291:	48 89 c7             	mov    %rax,%rdi
    c294:	e8 37 a2 ff ff       	call   64d0 <fwp_rc_fresh>
    c299:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c2a0:	00 
    c2a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c2a6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c2ad:	00 
    c2ae:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c2b5:	00 
    c2b6:	e8 65 a0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c2bb:	48 89 c7             	mov    %rax,%rdi
    c2be:	e8 0d a2 ff ff       	call   64d0 <fwp_rc_fresh>
    c2c3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c2ca:	00 
    c2cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c2d7:	00 
    c2d8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c2df:	00 
    c2e0:	e8 3b a0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c2e5:	48 89 c7             	mov    %rax,%rdi
    c2e8:	e8 e3 a1 ff ff       	call   64d0 <fwp_rc_fresh>
    c2ed:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c2f4:	00 
    c2f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2fa:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c301:	00 
    c302:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c309:	00 
    c30a:	e8 11 a0 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c30f:	48 89 c7             	mov    %rax,%rdi
    c312:	e8 b9 a1 ff ff       	call   64d0 <fwp_rc_fresh>
    c317:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c31e:	00 
    c31f:	bf 01 00 00 00       	mov    $0x1,%edi
    c324:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c32b:	00 
    c32c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c333:	00 
    c334:	e8 e7 9f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c339:	48 89 c7             	mov    %rax,%rdi
    c33c:	e8 8f a1 ff ff       	call   64d0 <fwp_rc_fresh>
    c341:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c348:	00 
    c349:	bf 01 00 00 00       	mov    $0x1,%edi
    c34e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c355:	00 
    c356:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c35d:	00 
    c35e:	e8 bd 9f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c363:	48 89 c7             	mov    %rax,%rdi
    c366:	e8 65 a1 ff ff       	call   64d0 <fwp_rc_fresh>
    c36b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c372:	00 
    c373:	bf 01 00 00 00       	mov    $0x1,%edi
    c378:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c37f:	00 
    c380:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c387:	00 
    c388:	e8 93 9f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c38d:	48 89 c7             	mov    %rax,%rdi
    c390:	e8 3b a1 ff ff       	call   64d0 <fwp_rc_fresh>
    c395:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c39c:	00 
    c39d:	bf 01 00 00 00       	mov    $0x1,%edi
    c3a2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c3a9:	00 
    c3aa:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c3b1:	00 
    c3b2:	e8 69 9f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c3b7:	48 89 c7             	mov    %rax,%rdi
    c3ba:	e8 11 a1 ff ff       	call   64d0 <fwp_rc_fresh>
    c3bf:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c3c6:	00 
    c3c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c3cc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c3d3:	00 
    c3d4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c3db:	00 
    c3dc:	e8 3f 9f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c3e1:	48 89 c7             	mov    %rax,%rdi
    c3e4:	e8 e7 a0 ff ff       	call   64d0 <fwp_rc_fresh>
    c3e9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c3f0:	00 
    c3f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c3f6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c3fd:	00 
    c3fe:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c405:	00 
    c406:	e8 15 9f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c40b:	48 89 c7             	mov    %rax,%rdi
    c40e:	e8 bd a0 ff ff       	call   64d0 <fwp_rc_fresh>
    c413:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c41a:	00 
    c41b:	bf 01 00 00 00       	mov    $0x1,%edi
    c420:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c427:	00 
    c428:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c42f:	00 
    c430:	e8 eb 9e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c435:	48 89 c7             	mov    %rax,%rdi
    c438:	e8 93 a0 ff ff       	call   64d0 <fwp_rc_fresh>
    c43d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c444:	00 
    c445:	bf 01 00 00 00       	mov    $0x1,%edi
    c44a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c451:	00 
    c452:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c459:	00 
    c45a:	e8 c1 9e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c45f:	48 89 c7             	mov    %rax,%rdi
    c462:	e8 69 a0 ff ff       	call   64d0 <fwp_rc_fresh>
    c467:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c46e:	00 
    c46f:	bf 01 00 00 00       	mov    $0x1,%edi
    c474:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c47b:	00 
    c47c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c483:	00 
    c484:	e8 97 9e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c489:	48 89 c7             	mov    %rax,%rdi
    c48c:	e8 3f a0 ff ff       	call   64d0 <fwp_rc_fresh>
    c491:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c498:	00 
    c499:	bf 01 00 00 00       	mov    $0x1,%edi
    c49e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c4a5:	00 
    c4a6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c4ad:	00 
    c4ae:	e8 6d 9e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c4b3:	48 89 c7             	mov    %rax,%rdi
    c4b6:	e8 15 a0 ff ff       	call   64d0 <fwp_rc_fresh>
    c4bb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c4c2:	00 
    c4c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c4c8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c4cf:	00 
    c4d0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c4d7:	00 
    c4d8:	e8 43 9e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c4dd:	48 89 c7             	mov    %rax,%rdi
    c4e0:	e8 eb 9f ff ff       	call   64d0 <fwp_rc_fresh>
    c4e5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c4ec:	00 
    c4ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c4f2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c4f9:	00 
    c4fa:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c501:	00 
    c502:	e8 19 9e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c507:	48 89 c7             	mov    %rax,%rdi
    c50a:	e8 c1 9f ff ff       	call   64d0 <fwp_rc_fresh>
    c50f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c516:	00 
    c517:	bf 01 00 00 00       	mov    $0x1,%edi
    c51c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c523:	00 
    c524:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c52b:	00 
    c52c:	e8 ef 9d ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c531:	48 89 c7             	mov    %rax,%rdi
    c534:	e8 97 9f ff ff       	call   64d0 <fwp_rc_fresh>
    c539:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c540:	00 
    c541:	bf 01 00 00 00       	mov    $0x1,%edi
    c546:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c54d:	00 
    c54e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c555:	00 
    c556:	e8 c5 9d ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c55b:	48 89 c7             	mov    %rax,%rdi
    c55e:	e8 6d 9f ff ff       	call   64d0 <fwp_rc_fresh>
    c563:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c56a:	00 
    c56b:	bf 01 00 00 00       	mov    $0x1,%edi
    c570:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c577:	00 
    c578:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c57f:	00 
    c580:	e8 9b 9d ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c585:	48 8b 15 cc 85 01 00 	mov    0x185cc(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c58c:	49 89 c5             	mov    %rax,%r13
    c58f:	48 2b 05 9a 85 01 00 	sub    0x1859a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c596:	48 c1 e2 10          	shl    $0x10,%rdx
    c59a:	48 39 d0             	cmp    %rdx,%rax
    c59d:	73 59                	jae    c5f8 <f0+0x13b8>
    c59f:	48 89 c2             	mov    %rax,%rdx
    c5a2:	48 c1 ea 10          	shr    $0x10,%rdx
    c5a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5aa:	48 8b 15 c7 85 01 00 	mov    0x185c7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c5b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5b9:	4d 85 e4             	test   %r12,%r12
    c5bc:	74 3a                	je     c5f8 <f0+0x13b8>
    c5be:	0f b6 0a             	movzbl (%rdx),%ecx
    c5c1:	80 f9 02             	cmp    $0x2,%cl
    c5c4:	0f 84 c6 15 00 00    	je     db90 <f0+0x2950>
    c5ca:	80 f9 01             	cmp    $0x1,%cl
    c5cd:	75 29                	jne    c5f8 <f0+0x13b8>
    c5cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5d2:	0f b7 c0             	movzwl %ax,%eax
    c5d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5d8:	48 0f af c1          	imul   %rcx,%rax
    c5dc:	48 c1 e8 20          	shr    $0x20,%rax
    c5e0:	48 39 d0             	cmp    %rdx,%rax
    c5e3:	73 13                	jae    c5f8 <f0+0x13b8>
    c5e5:	49 01 c4             	add    %rax,%r12
    c5e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5ed:	0f 84 99 17 00 00    	je     dd8c <f0+0x2b4c>
    c5f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5f8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c5ff:	33 f3 bf 
    c602:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c609:	00 
    c60a:	bf 01 00 00 00       	mov    $0x1,%edi
    c60f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c616:	00 
    c617:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c61e:	00 
    c61f:	e8 fc 9c ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c624:	48 8b 15 2d 85 01 00 	mov    0x1852d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c62b:	49 89 c5             	mov    %rax,%r13
    c62e:	48 2b 05 fb 84 01 00 	sub    0x184fb(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c635:	48 c1 e2 10          	shl    $0x10,%rdx
    c639:	48 39 d0             	cmp    %rdx,%rax
    c63c:	73 59                	jae    c697 <f0+0x1457>
    c63e:	48 89 c2             	mov    %rax,%rdx
    c641:	48 c1 ea 10          	shr    $0x10,%rdx
    c645:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c649:	48 8b 15 28 85 01 00 	mov    0x18528(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c650:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c654:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c658:	4d 85 e4             	test   %r12,%r12
    c65b:	74 3a                	je     c697 <f0+0x1457>
    c65d:	0f b6 0a             	movzbl (%rdx),%ecx
    c660:	80 f9 02             	cmp    $0x2,%cl
    c663:	0f 84 17 15 00 00    	je     db80 <f0+0x2940>
    c669:	80 f9 01             	cmp    $0x1,%cl
    c66c:	75 29                	jne    c697 <f0+0x1457>
    c66e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c671:	0f b7 c0             	movzwl %ax,%eax
    c674:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c677:	48 0f af c1          	imul   %rcx,%rax
    c67b:	48 c1 e8 20          	shr    $0x20,%rax
    c67f:	48 39 d0             	cmp    %rdx,%rax
    c682:	73 13                	jae    c697 <f0+0x1457>
    c684:	49 01 c4             	add    %rax,%r12
    c687:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c68c:	0f 84 07 17 00 00    	je     dd99 <f0+0x2b59>
    c692:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c697:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c69e:	00 f0 3f 
    c6a1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c6a8:	00 
    c6a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c6ae:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c6b5:	00 
    c6b6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c6bd:	00 
    c6be:	e8 5d 9c ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c6c3:	48 8b 15 8e 84 01 00 	mov    0x1848e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c6ca:	49 89 c5             	mov    %rax,%r13
    c6cd:	48 2b 05 5c 84 01 00 	sub    0x1845c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c6d4:	48 c1 e2 10          	shl    $0x10,%rdx
    c6d8:	48 39 d0             	cmp    %rdx,%rax
    c6db:	73 59                	jae    c736 <f0+0x14f6>
    c6dd:	48 89 c2             	mov    %rax,%rdx
    c6e0:	48 c1 ea 10          	shr    $0x10,%rdx
    c6e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6e8:	48 8b 15 89 84 01 00 	mov    0x18489(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c6ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6f7:	4d 85 e4             	test   %r12,%r12
    c6fa:	74 3a                	je     c736 <f0+0x14f6>
    c6fc:	0f b6 0a             	movzbl (%rdx),%ecx
    c6ff:	80 f9 02             	cmp    $0x2,%cl
    c702:	0f 84 28 15 00 00    	je     dc30 <f0+0x29f0>
    c708:	80 f9 01             	cmp    $0x1,%cl
    c70b:	75 29                	jne    c736 <f0+0x14f6>
    c70d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c710:	0f b7 c0             	movzwl %ax,%eax
    c713:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c716:	48 0f af c1          	imul   %rcx,%rax
    c71a:	48 c1 e8 20          	shr    $0x20,%rax
    c71e:	48 39 d0             	cmp    %rdx,%rax
    c721:	73 13                	jae    c736 <f0+0x14f6>
    c723:	49 01 c4             	add    %rax,%r12
    c726:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c72b:	0f 84 75 16 00 00    	je     dda6 <f0+0x2b66>
    c731:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c736:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c73d:	33 f3 bf 
    c740:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c747:	00 
    c748:	bf 01 00 00 00       	mov    $0x1,%edi
    c74d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c754:	00 
    c755:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c75c:	00 
    c75d:	e8 be 9b ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c762:	48 8b 15 ef 83 01 00 	mov    0x183ef(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c769:	49 89 c5             	mov    %rax,%r13
    c76c:	48 2b 05 bd 83 01 00 	sub    0x183bd(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c773:	48 c1 e2 10          	shl    $0x10,%rdx
    c777:	48 39 d0             	cmp    %rdx,%rax
    c77a:	73 59                	jae    c7d5 <f0+0x1595>
    c77c:	48 89 c2             	mov    %rax,%rdx
    c77f:	48 c1 ea 10          	shr    $0x10,%rdx
    c783:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c787:	48 8b 15 ea 83 01 00 	mov    0x183ea(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c78e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c792:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c796:	4d 85 e4             	test   %r12,%r12
    c799:	74 3a                	je     c7d5 <f0+0x1595>
    c79b:	0f b6 0a             	movzbl (%rdx),%ecx
    c79e:	80 f9 02             	cmp    $0x2,%cl
    c7a1:	0f 84 79 14 00 00    	je     dc20 <f0+0x29e0>
    c7a7:	80 f9 01             	cmp    $0x1,%cl
    c7aa:	75 29                	jne    c7d5 <f0+0x1595>
    c7ac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7af:	0f b7 c0             	movzwl %ax,%eax
    c7b2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7b5:	48 0f af c1          	imul   %rcx,%rax
    c7b9:	48 c1 e8 20          	shr    $0x20,%rax
    c7bd:	48 39 d0             	cmp    %rdx,%rax
    c7c0:	73 13                	jae    c7d5 <f0+0x1595>
    c7c2:	49 01 c4             	add    %rax,%r12
    c7c5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7ca:	0f 84 e3 15 00 00    	je     ddb3 <f0+0x2b73>
    c7d0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7d5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7dc:	00 f0 3f 
    c7df:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c7e6:	00 
    c7e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c7ec:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c7f3:	00 
    c7f4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c7fb:	00 
    c7fc:	e8 1f 9b ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c801:	48 8b 15 50 83 01 00 	mov    0x18350(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c808:	49 89 c5             	mov    %rax,%r13
    c80b:	48 2b 05 1e 83 01 00 	sub    0x1831e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c812:	48 c1 e2 10          	shl    $0x10,%rdx
    c816:	48 39 d0             	cmp    %rdx,%rax
    c819:	73 59                	jae    c874 <f0+0x1634>
    c81b:	48 89 c2             	mov    %rax,%rdx
    c81e:	48 c1 ea 10          	shr    $0x10,%rdx
    c822:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c826:	48 8b 15 4b 83 01 00 	mov    0x1834b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c82d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c831:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c835:	4d 85 e4             	test   %r12,%r12
    c838:	74 3a                	je     c874 <f0+0x1634>
    c83a:	0f b6 0a             	movzbl (%rdx),%ecx
    c83d:	80 f9 02             	cmp    $0x2,%cl
    c840:	0f 84 ca 13 00 00    	je     dc10 <f0+0x29d0>
    c846:	80 f9 01             	cmp    $0x1,%cl
    c849:	75 29                	jne    c874 <f0+0x1634>
    c84b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c84e:	0f b7 c0             	movzwl %ax,%eax
    c851:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c854:	48 0f af c1          	imul   %rcx,%rax
    c858:	48 c1 e8 20          	shr    $0x20,%rax
    c85c:	48 39 d0             	cmp    %rdx,%rax
    c85f:	73 13                	jae    c874 <f0+0x1634>
    c861:	49 01 c4             	add    %rax,%r12
    c864:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c869:	0f 84 51 15 00 00    	je     ddc0 <f0+0x2b80>
    c86f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c874:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c87b:	33 f3 bf 
    c87e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c885:	00 
    c886:	bf 01 00 00 00       	mov    $0x1,%edi
    c88b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c892:	00 
    c893:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c89a:	00 
    c89b:	e8 80 9a ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c8a0:	48 8b 15 b1 82 01 00 	mov    0x182b1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c8a7:	49 89 c5             	mov    %rax,%r13
    c8aa:	48 2b 05 7f 82 01 00 	sub    0x1827f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c8b1:	48 c1 e2 10          	shl    $0x10,%rdx
    c8b5:	48 39 d0             	cmp    %rdx,%rax
    c8b8:	73 59                	jae    c913 <f0+0x16d3>
    c8ba:	48 89 c2             	mov    %rax,%rdx
    c8bd:	48 c1 ea 10          	shr    $0x10,%rdx
    c8c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8c5:	48 8b 15 ac 82 01 00 	mov    0x182ac(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c8cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8d0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8d4:	4d 85 e4             	test   %r12,%r12
    c8d7:	74 3a                	je     c913 <f0+0x16d3>
    c8d9:	0f b6 0a             	movzbl (%rdx),%ecx
    c8dc:	80 f9 02             	cmp    $0x2,%cl
    c8df:	0f 84 1b 13 00 00    	je     dc00 <f0+0x29c0>
    c8e5:	80 f9 01             	cmp    $0x1,%cl
    c8e8:	75 29                	jne    c913 <f0+0x16d3>
    c8ea:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8ed:	0f b7 c0             	movzwl %ax,%eax
    c8f0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8f3:	48 0f af c1          	imul   %rcx,%rax
    c8f7:	48 c1 e8 20          	shr    $0x20,%rax
    c8fb:	48 39 d0             	cmp    %rdx,%rax
    c8fe:	73 13                	jae    c913 <f0+0x16d3>
    c900:	49 01 c4             	add    %rax,%r12
    c903:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c908:	0f 84 bf 14 00 00    	je     ddcd <f0+0x2b8d>
    c90e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c913:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c91a:	00 f0 3f 
    c91d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c924:	00 
    c925:	bf 01 00 00 00       	mov    $0x1,%edi
    c92a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c931:	00 
    c932:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c939:	00 
    c93a:	e8 e1 99 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c93f:	48 8b 15 12 82 01 00 	mov    0x18212(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c946:	49 89 c5             	mov    %rax,%r13
    c949:	48 2b 05 e0 81 01 00 	sub    0x181e0(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c950:	48 c1 e2 10          	shl    $0x10,%rdx
    c954:	48 39 d0             	cmp    %rdx,%rax
    c957:	73 59                	jae    c9b2 <f0+0x1772>
    c959:	48 89 c2             	mov    %rax,%rdx
    c95c:	48 c1 ea 10          	shr    $0x10,%rdx
    c960:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c964:	48 8b 15 0d 82 01 00 	mov    0x1820d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c96b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c96f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c973:	4d 85 e4             	test   %r12,%r12
    c976:	74 3a                	je     c9b2 <f0+0x1772>
    c978:	0f b6 0a             	movzbl (%rdx),%ecx
    c97b:	80 f9 02             	cmp    $0x2,%cl
    c97e:	0f 84 6c 12 00 00    	je     dbf0 <f0+0x29b0>
    c984:	80 f9 01             	cmp    $0x1,%cl
    c987:	75 29                	jne    c9b2 <f0+0x1772>
    c989:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c98c:	0f b7 c0             	movzwl %ax,%eax
    c98f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c992:	48 0f af c1          	imul   %rcx,%rax
    c996:	48 c1 e8 20          	shr    $0x20,%rax
    c99a:	48 39 d0             	cmp    %rdx,%rax
    c99d:	73 13                	jae    c9b2 <f0+0x1772>
    c99f:	49 01 c4             	add    %rax,%r12
    c9a2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9a7:	0f 84 2d 14 00 00    	je     ddda <f0+0x2b9a>
    c9ad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9b2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c9b9:	33 f3 bf 
    c9bc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c9c3:	00 
    c9c4:	bf 01 00 00 00       	mov    $0x1,%edi
    c9c9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c9d0:	00 
    c9d1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c9d8:	00 
    c9d9:	e8 42 99 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    c9de:	48 8b 15 73 81 01 00 	mov    0x18173(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c9e5:	49 89 c5             	mov    %rax,%r13
    c9e8:	48 2b 05 41 81 01 00 	sub    0x18141(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c9ef:	48 c1 e2 10          	shl    $0x10,%rdx
    c9f3:	48 39 d0             	cmp    %rdx,%rax
    c9f6:	73 59                	jae    ca51 <f0+0x1811>
    c9f8:	48 89 c2             	mov    %rax,%rdx
    c9fb:	48 c1 ea 10          	shr    $0x10,%rdx
    c9ff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca03:	48 8b 15 6e 81 01 00 	mov    0x1816e(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ca0a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca0e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca12:	4d 85 e4             	test   %r12,%r12
    ca15:	74 3a                	je     ca51 <f0+0x1811>
    ca17:	0f b6 0a             	movzbl (%rdx),%ecx
    ca1a:	80 f9 02             	cmp    $0x2,%cl
    ca1d:	0f 84 bd 11 00 00    	je     dbe0 <f0+0x29a0>
    ca23:	80 f9 01             	cmp    $0x1,%cl
    ca26:	75 29                	jne    ca51 <f0+0x1811>
    ca28:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca2b:	0f b7 c0             	movzwl %ax,%eax
    ca2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca31:	48 0f af c1          	imul   %rcx,%rax
    ca35:	48 c1 e8 20          	shr    $0x20,%rax
    ca39:	48 39 d0             	cmp    %rdx,%rax
    ca3c:	73 13                	jae    ca51 <f0+0x1811>
    ca3e:	49 01 c4             	add    %rax,%r12
    ca41:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca46:	0f 84 9b 13 00 00    	je     dde7 <f0+0x2ba7>
    ca4c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca51:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca58:	00 f0 3f 
    ca5b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    ca62:	00 
    ca63:	bf 01 00 00 00       	mov    $0x1,%edi
    ca68:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    ca6f:	00 
    ca70:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    ca77:	00 
    ca78:	e8 a3 98 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ca7d:	48 8b 15 d4 80 01 00 	mov    0x180d4(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ca84:	49 89 c5             	mov    %rax,%r13
    ca87:	48 2b 05 a2 80 01 00 	sub    0x180a2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ca8e:	48 c1 e2 10          	shl    $0x10,%rdx
    ca92:	48 39 d0             	cmp    %rdx,%rax
    ca95:	73 59                	jae    caf0 <f0+0x18b0>
    ca97:	48 89 c2             	mov    %rax,%rdx
    ca9a:	48 c1 ea 10          	shr    $0x10,%rdx
    ca9e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    caa2:	48 8b 15 cf 80 01 00 	mov    0x180cf(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    caa9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    caad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cab1:	4d 85 e4             	test   %r12,%r12
    cab4:	74 3a                	je     caf0 <f0+0x18b0>
    cab6:	0f b6 0a             	movzbl (%rdx),%ecx
    cab9:	80 f9 02             	cmp    $0x2,%cl
    cabc:	0f 84 0e 11 00 00    	je     dbd0 <f0+0x2990>
    cac2:	80 f9 01             	cmp    $0x1,%cl
    cac5:	75 29                	jne    caf0 <f0+0x18b0>
    cac7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caca:	0f b7 c0             	movzwl %ax,%eax
    cacd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cad0:	48 0f af c1          	imul   %rcx,%rax
    cad4:	48 c1 e8 20          	shr    $0x20,%rax
    cad8:	48 39 d0             	cmp    %rdx,%rax
    cadb:	73 13                	jae    caf0 <f0+0x18b0>
    cadd:	49 01 c4             	add    %rax,%r12
    cae0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cae5:	0f 84 09 13 00 00    	je     ddf4 <f0+0x2bb4>
    caeb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    caf0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    caf7:	33 f3 bf 
    cafa:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cb01:	00 
    cb02:	bf 01 00 00 00       	mov    $0x1,%edi
    cb07:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cb0e:	00 
    cb0f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cb16:	00 
    cb17:	e8 04 98 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    cb1c:	48 8b 15 35 80 01 00 	mov    0x18035(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cb23:	49 89 c5             	mov    %rax,%r13
    cb26:	48 2b 05 03 80 01 00 	sub    0x18003(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cb2d:	48 c1 e2 10          	shl    $0x10,%rdx
    cb31:	48 39 d0             	cmp    %rdx,%rax
    cb34:	73 59                	jae    cb8f <f0+0x194f>
    cb36:	48 89 c2             	mov    %rax,%rdx
    cb39:	48 c1 ea 10          	shr    $0x10,%rdx
    cb3d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb41:	48 8b 15 30 80 01 00 	mov    0x18030(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cb48:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb4c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb50:	4d 85 e4             	test   %r12,%r12
    cb53:	74 3a                	je     cb8f <f0+0x194f>
    cb55:	0f b6 0a             	movzbl (%rdx),%ecx
    cb58:	80 f9 02             	cmp    $0x2,%cl
    cb5b:	0f 84 5f 10 00 00    	je     dbc0 <f0+0x2980>
    cb61:	80 f9 01             	cmp    $0x1,%cl
    cb64:	75 29                	jne    cb8f <f0+0x194f>
    cb66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb69:	0f b7 c0             	movzwl %ax,%eax
    cb6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb6f:	48 0f af c1          	imul   %rcx,%rax
    cb73:	48 c1 e8 20          	shr    $0x20,%rax
    cb77:	48 39 d0             	cmp    %rdx,%rax
    cb7a:	73 13                	jae    cb8f <f0+0x194f>
    cb7c:	49 01 c4             	add    %rax,%r12
    cb7f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb84:	0f 84 77 12 00 00    	je     de01 <f0+0x2bc1>
    cb8a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb8f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb96:	00 f0 3f 
    cb99:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cba0:	00 
    cba1:	bf 01 00 00 00       	mov    $0x1,%edi
    cba6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cbad:	00 
    cbae:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cbb5:	00 
    cbb6:	e8 65 97 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    cbbb:	48 8b 15 96 7f 01 00 	mov    0x17f96(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cbc2:	49 89 c5             	mov    %rax,%r13
    cbc5:	48 2b 05 64 7f 01 00 	sub    0x17f64(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cbcc:	48 c1 e2 10          	shl    $0x10,%rdx
    cbd0:	48 39 d0             	cmp    %rdx,%rax
    cbd3:	73 59                	jae    cc2e <f0+0x19ee>
    cbd5:	48 89 c2             	mov    %rax,%rdx
    cbd8:	48 c1 ea 10          	shr    $0x10,%rdx
    cbdc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbe0:	48 8b 15 91 7f 01 00 	mov    0x17f91(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cbe7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbeb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbef:	4d 85 e4             	test   %r12,%r12
    cbf2:	74 3a                	je     cc2e <f0+0x19ee>
    cbf4:	0f b6 0a             	movzbl (%rdx),%ecx
    cbf7:	80 f9 02             	cmp    $0x2,%cl
    cbfa:	0f 84 40 0f 00 00    	je     db40 <f0+0x2900>
    cc00:	80 f9 01             	cmp    $0x1,%cl
    cc03:	75 29                	jne    cc2e <f0+0x19ee>
    cc05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc08:	0f b7 c0             	movzwl %ax,%eax
    cc0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc0e:	48 0f af c1          	imul   %rcx,%rax
    cc12:	48 c1 e8 20          	shr    $0x20,%rax
    cc16:	48 39 d0             	cmp    %rdx,%rax
    cc19:	73 13                	jae    cc2e <f0+0x19ee>
    cc1b:	49 01 c4             	add    %rax,%r12
    cc1e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc23:	0f 84 e5 11 00 00    	je     de0e <f0+0x2bce>
    cc29:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc2e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc35:	33 f3 bf 
    cc38:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cc3f:	00 
    cc40:	bf 01 00 00 00       	mov    $0x1,%edi
    cc45:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cc4c:	00 
    cc4d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cc54:	00 
    cc55:	e8 c6 96 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    cc5a:	48 8b 15 f7 7e 01 00 	mov    0x17ef7(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cc61:	49 89 c5             	mov    %rax,%r13
    cc64:	48 2b 05 c5 7e 01 00 	sub    0x17ec5(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cc6b:	48 c1 e2 10          	shl    $0x10,%rdx
    cc6f:	48 39 d0             	cmp    %rdx,%rax
    cc72:	73 59                	jae    cccd <f0+0x1a8d>
    cc74:	48 89 c2             	mov    %rax,%rdx
    cc77:	48 c1 ea 10          	shr    $0x10,%rdx
    cc7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc7f:	48 8b 15 f2 7e 01 00 	mov    0x17ef2(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cc86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc8a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc8e:	4d 85 e4             	test   %r12,%r12
    cc91:	74 3a                	je     cccd <f0+0x1a8d>
    cc93:	0f b6 0a             	movzbl (%rdx),%ecx
    cc96:	80 f9 02             	cmp    $0x2,%cl
    cc99:	0f 84 91 0e 00 00    	je     db30 <f0+0x28f0>
    cc9f:	80 f9 01             	cmp    $0x1,%cl
    cca2:	75 29                	jne    cccd <f0+0x1a8d>
    cca4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cca7:	0f b7 c0             	movzwl %ax,%eax
    ccaa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccad:	48 0f af c1          	imul   %rcx,%rax
    ccb1:	48 c1 e8 20          	shr    $0x20,%rax
    ccb5:	48 39 d0             	cmp    %rdx,%rax
    ccb8:	73 13                	jae    cccd <f0+0x1a8d>
    ccba:	49 01 c4             	add    %rax,%r12
    ccbd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccc2:	0f 84 53 11 00 00    	je     de1b <f0+0x2bdb>
    ccc8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cccd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccd4:	00 f0 3f 
    ccd7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    ccde:	00 
    ccdf:	bf 01 00 00 00       	mov    $0x1,%edi
    cce4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cceb:	00 
    ccec:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    ccf3:	00 
    ccf4:	e8 27 96 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ccf9:	48 8b 15 58 7e 01 00 	mov    0x17e58(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cd00:	49 89 c5             	mov    %rax,%r13
    cd03:	48 2b 05 26 7e 01 00 	sub    0x17e26(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cd0a:	48 c1 e2 10          	shl    $0x10,%rdx
    cd0e:	48 39 d0             	cmp    %rdx,%rax
    cd11:	73 59                	jae    cd6c <f0+0x1b2c>
    cd13:	48 89 c2             	mov    %rax,%rdx
    cd16:	48 c1 ea 10          	shr    $0x10,%rdx
    cd1a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd1e:	48 8b 15 53 7e 01 00 	mov    0x17e53(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cd25:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd29:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd2d:	4d 85 e4             	test   %r12,%r12
    cd30:	74 3a                	je     cd6c <f0+0x1b2c>
    cd32:	0f b6 0a             	movzbl (%rdx),%ecx
    cd35:	80 f9 02             	cmp    $0x2,%cl
    cd38:	0f 84 e2 0d 00 00    	je     db20 <f0+0x28e0>
    cd3e:	80 f9 01             	cmp    $0x1,%cl
    cd41:	75 29                	jne    cd6c <f0+0x1b2c>
    cd43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd46:	0f b7 c0             	movzwl %ax,%eax
    cd49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd4c:	48 0f af c1          	imul   %rcx,%rax
    cd50:	48 c1 e8 20          	shr    $0x20,%rax
    cd54:	48 39 d0             	cmp    %rdx,%rax
    cd57:	73 13                	jae    cd6c <f0+0x1b2c>
    cd59:	49 01 c4             	add    %rax,%r12
    cd5c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd61:	0f 84 c1 10 00 00    	je     de28 <f0+0x2be8>
    cd67:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd6c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd73:	33 f3 bf 
    cd76:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cd7d:	00 
    cd7e:	bf 01 00 00 00       	mov    $0x1,%edi
    cd83:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cd8a:	00 
    cd8b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cd92:	00 
    cd93:	e8 88 95 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    cd98:	48 8b 15 b9 7d 01 00 	mov    0x17db9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cd9f:	49 89 c5             	mov    %rax,%r13
    cda2:	48 2b 05 87 7d 01 00 	sub    0x17d87(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cda9:	48 c1 e2 10          	shl    $0x10,%rdx
    cdad:	48 39 d0             	cmp    %rdx,%rax
    cdb0:	73 59                	jae    ce0b <f0+0x1bcb>
    cdb2:	48 89 c2             	mov    %rax,%rdx
    cdb5:	48 c1 ea 10          	shr    $0x10,%rdx
    cdb9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdbd:	48 8b 15 b4 7d 01 00 	mov    0x17db4(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cdc4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdc8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdcc:	4d 85 e4             	test   %r12,%r12
    cdcf:	74 3a                	je     ce0b <f0+0x1bcb>
    cdd1:	0f b6 0a             	movzbl (%rdx),%ecx
    cdd4:	80 f9 02             	cmp    $0x2,%cl
    cdd7:	0f 84 33 0d 00 00    	je     db10 <f0+0x28d0>
    cddd:	80 f9 01             	cmp    $0x1,%cl
    cde0:	75 29                	jne    ce0b <f0+0x1bcb>
    cde2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cde5:	0f b7 c0             	movzwl %ax,%eax
    cde8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdeb:	48 0f af c1          	imul   %rcx,%rax
    cdef:	48 c1 e8 20          	shr    $0x20,%rax
    cdf3:	48 39 d0             	cmp    %rdx,%rax
    cdf6:	73 13                	jae    ce0b <f0+0x1bcb>
    cdf8:	49 01 c4             	add    %rax,%r12
    cdfb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce00:	0f 84 2f 10 00 00    	je     de35 <f0+0x2bf5>
    ce06:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce0b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce12:	00 f0 3f 
    ce15:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    ce1c:	00 
    ce1d:	bf 01 00 00 00       	mov    $0x1,%edi
    ce22:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    ce29:	00 
    ce2a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    ce31:	00 
    ce32:	e8 e9 94 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ce37:	48 8b 15 1a 7d 01 00 	mov    0x17d1a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ce3e:	49 89 c5             	mov    %rax,%r13
    ce41:	48 2b 05 e8 7c 01 00 	sub    0x17ce8(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ce48:	48 c1 e2 10          	shl    $0x10,%rdx
    ce4c:	48 39 d0             	cmp    %rdx,%rax
    ce4f:	73 59                	jae    ceaa <f0+0x1c6a>
    ce51:	48 89 c2             	mov    %rax,%rdx
    ce54:	48 c1 ea 10          	shr    $0x10,%rdx
    ce58:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce5c:	48 8b 15 15 7d 01 00 	mov    0x17d15(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ce63:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce67:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce6b:	4d 85 e4             	test   %r12,%r12
    ce6e:	74 3a                	je     ceaa <f0+0x1c6a>
    ce70:	0f b6 0a             	movzbl (%rdx),%ecx
    ce73:	80 f9 02             	cmp    $0x2,%cl
    ce76:	0f 84 84 0c 00 00    	je     db00 <f0+0x28c0>
    ce7c:	80 f9 01             	cmp    $0x1,%cl
    ce7f:	75 29                	jne    ceaa <f0+0x1c6a>
    ce81:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce84:	0f b7 c0             	movzwl %ax,%eax
    ce87:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce8a:	48 0f af c1          	imul   %rcx,%rax
    ce8e:	48 c1 e8 20          	shr    $0x20,%rax
    ce92:	48 39 d0             	cmp    %rdx,%rax
    ce95:	73 13                	jae    ceaa <f0+0x1c6a>
    ce97:	49 01 c4             	add    %rax,%r12
    ce9a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce9f:	0f 84 9d 0f 00 00    	je     de42 <f0+0x2c02>
    cea5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceaa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ceb1:	33 f3 bf 
    ceb4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cebb:	00 
    cebc:	bf 01 00 00 00       	mov    $0x1,%edi
    cec1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cec8:	00 
    cec9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    ced0:	00 
    ced1:	e8 4a 94 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    ced6:	48 8b 15 7b 7c 01 00 	mov    0x17c7b(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cedd:	49 89 c5             	mov    %rax,%r13
    cee0:	48 2b 05 49 7c 01 00 	sub    0x17c49(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cee7:	48 c1 e2 10          	shl    $0x10,%rdx
    ceeb:	48 39 d0             	cmp    %rdx,%rax
    ceee:	73 59                	jae    cf49 <f0+0x1d09>
    cef0:	48 89 c2             	mov    %rax,%rdx
    cef3:	48 c1 ea 10          	shr    $0x10,%rdx
    cef7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cefb:	48 8b 15 76 7c 01 00 	mov    0x17c76(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cf02:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf06:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf0a:	4d 85 e4             	test   %r12,%r12
    cf0d:	74 3a                	je     cf49 <f0+0x1d09>
    cf0f:	0f b6 0a             	movzbl (%rdx),%ecx
    cf12:	80 f9 02             	cmp    $0x2,%cl
    cf15:	0f 84 d5 0b 00 00    	je     daf0 <f0+0x28b0>
    cf1b:	80 f9 01             	cmp    $0x1,%cl
    cf1e:	75 29                	jne    cf49 <f0+0x1d09>
    cf20:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf23:	0f b7 c0             	movzwl %ax,%eax
    cf26:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf29:	48 0f af c1          	imul   %rcx,%rax
    cf2d:	48 c1 e8 20          	shr    $0x20,%rax
    cf31:	48 39 d0             	cmp    %rdx,%rax
    cf34:	73 13                	jae    cf49 <f0+0x1d09>
    cf36:	49 01 c4             	add    %rax,%r12
    cf39:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf3e:	0f 84 0b 0f 00 00    	je     de4f <f0+0x2c0f>
    cf44:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf49:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf50:	00 f0 3f 
    cf53:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cf5a:	00 
    cf5b:	bf 01 00 00 00       	mov    $0x1,%edi
    cf60:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cf67:	00 
    cf68:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cf6f:	00 
    cf70:	e8 ab 93 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    cf75:	48 8b 15 dc 7b 01 00 	mov    0x17bdc(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cf7c:	49 89 c5             	mov    %rax,%r13
    cf7f:	48 2b 05 aa 7b 01 00 	sub    0x17baa(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cf86:	48 c1 e2 10          	shl    $0x10,%rdx
    cf8a:	48 39 d0             	cmp    %rdx,%rax
    cf8d:	73 59                	jae    cfe8 <f0+0x1da8>
    cf8f:	48 89 c2             	mov    %rax,%rdx
    cf92:	48 c1 ea 10          	shr    $0x10,%rdx
    cf96:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf9a:	48 8b 15 d7 7b 01 00 	mov    0x17bd7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cfa1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfa5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfa9:	4d 85 e4             	test   %r12,%r12
    cfac:	74 3a                	je     cfe8 <f0+0x1da8>
    cfae:	0f b6 0a             	movzbl (%rdx),%ecx
    cfb1:	80 f9 02             	cmp    $0x2,%cl
    cfb4:	0f 84 26 0b 00 00    	je     dae0 <f0+0x28a0>
    cfba:	80 f9 01             	cmp    $0x1,%cl
    cfbd:	75 29                	jne    cfe8 <f0+0x1da8>
    cfbf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfc2:	0f b7 c0             	movzwl %ax,%eax
    cfc5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfc8:	48 0f af c1          	imul   %rcx,%rax
    cfcc:	48 c1 e8 20          	shr    $0x20,%rax
    cfd0:	48 39 d0             	cmp    %rdx,%rax
    cfd3:	73 13                	jae    cfe8 <f0+0x1da8>
    cfd5:	49 01 c4             	add    %rax,%r12
    cfd8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfdd:	0f 84 79 0e 00 00    	je     de5c <f0+0x2c1c>
    cfe3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfe8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cfef:	33 f3 bf 
    cff2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    cff9:	00 
    cffa:	bf 01 00 00 00       	mov    $0x1,%edi
    cfff:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d006:	00 
    d007:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d00e:	00 
    d00f:	e8 0c 93 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d014:	48 8b 15 3d 7b 01 00 	mov    0x17b3d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d01b:	49 89 c5             	mov    %rax,%r13
    d01e:	48 2b 05 0b 7b 01 00 	sub    0x17b0b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d025:	48 c1 e2 10          	shl    $0x10,%rdx
    d029:	48 39 d0             	cmp    %rdx,%rax
    d02c:	73 59                	jae    d087 <f0+0x1e47>
    d02e:	48 89 c2             	mov    %rax,%rdx
    d031:	48 c1 ea 10          	shr    $0x10,%rdx
    d035:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d039:	48 8b 15 38 7b 01 00 	mov    0x17b38(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d040:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d044:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d048:	4d 85 e4             	test   %r12,%r12
    d04b:	74 3a                	je     d087 <f0+0x1e47>
    d04d:	0f b6 0a             	movzbl (%rdx),%ecx
    d050:	80 f9 02             	cmp    $0x2,%cl
    d053:	0f 84 77 0a 00 00    	je     dad0 <f0+0x2890>
    d059:	80 f9 01             	cmp    $0x1,%cl
    d05c:	75 29                	jne    d087 <f0+0x1e47>
    d05e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d061:	0f b7 c0             	movzwl %ax,%eax
    d064:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d067:	48 0f af c1          	imul   %rcx,%rax
    d06b:	48 c1 e8 20          	shr    $0x20,%rax
    d06f:	48 39 d0             	cmp    %rdx,%rax
    d072:	73 13                	jae    d087 <f0+0x1e47>
    d074:	49 01 c4             	add    %rax,%r12
    d077:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d07c:	0f 84 e7 0d 00 00    	je     de69 <f0+0x2c29>
    d082:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d087:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d08e:	00 f0 3f 
    d091:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d098:	00 
    d099:	bf 01 00 00 00       	mov    $0x1,%edi
    d09e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d0a5:	00 
    d0a6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d0ad:	00 
    d0ae:	e8 6d 92 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d0b3:	48 8b 15 9e 7a 01 00 	mov    0x17a9e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d0ba:	49 89 c5             	mov    %rax,%r13
    d0bd:	48 2b 05 6c 7a 01 00 	sub    0x17a6c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d0c4:	48 c1 e2 10          	shl    $0x10,%rdx
    d0c8:	48 39 d0             	cmp    %rdx,%rax
    d0cb:	73 59                	jae    d126 <f0+0x1ee6>
    d0cd:	48 89 c2             	mov    %rax,%rdx
    d0d0:	48 c1 ea 10          	shr    $0x10,%rdx
    d0d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0d8:	48 8b 15 99 7a 01 00 	mov    0x17a99(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d0df:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0e3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0e7:	4d 85 e4             	test   %r12,%r12
    d0ea:	74 3a                	je     d126 <f0+0x1ee6>
    d0ec:	0f b6 0a             	movzbl (%rdx),%ecx
    d0ef:	80 f9 02             	cmp    $0x2,%cl
    d0f2:	0f 84 38 0c 00 00    	je     dd30 <f0+0x2af0>
    d0f8:	80 f9 01             	cmp    $0x1,%cl
    d0fb:	75 29                	jne    d126 <f0+0x1ee6>
    d0fd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d100:	0f b7 c0             	movzwl %ax,%eax
    d103:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d106:	48 0f af c1          	imul   %rcx,%rax
    d10a:	48 c1 e8 20          	shr    $0x20,%rax
    d10e:	48 39 d0             	cmp    %rdx,%rax
    d111:	73 13                	jae    d126 <f0+0x1ee6>
    d113:	49 01 c4             	add    %rax,%r12
    d116:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d11b:	0f 84 55 0d 00 00    	je     de76 <f0+0x2c36>
    d121:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d126:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d12d:	33 f3 bf 
    d130:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d137:	00 
    d138:	bf 01 00 00 00       	mov    $0x1,%edi
    d13d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d144:	00 
    d145:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d14c:	00 
    d14d:	e8 ce 91 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d152:	48 8b 15 ff 79 01 00 	mov    0x179ff(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d159:	49 89 c5             	mov    %rax,%r13
    d15c:	48 2b 05 cd 79 01 00 	sub    0x179cd(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d163:	48 c1 e2 10          	shl    $0x10,%rdx
    d167:	48 39 d0             	cmp    %rdx,%rax
    d16a:	73 59                	jae    d1c5 <f0+0x1f85>
    d16c:	48 89 c2             	mov    %rax,%rdx
    d16f:	48 c1 ea 10          	shr    $0x10,%rdx
    d173:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d177:	48 8b 15 fa 79 01 00 	mov    0x179fa(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d17e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d182:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d186:	4d 85 e4             	test   %r12,%r12
    d189:	74 3a                	je     d1c5 <f0+0x1f85>
    d18b:	0f b6 0a             	movzbl (%rdx),%ecx
    d18e:	80 f9 02             	cmp    $0x2,%cl
    d191:	0f 84 89 0b 00 00    	je     dd20 <f0+0x2ae0>
    d197:	80 f9 01             	cmp    $0x1,%cl
    d19a:	75 29                	jne    d1c5 <f0+0x1f85>
    d19c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d19f:	0f b7 c0             	movzwl %ax,%eax
    d1a2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1a5:	48 0f af c1          	imul   %rcx,%rax
    d1a9:	48 c1 e8 20          	shr    $0x20,%rax
    d1ad:	48 39 d0             	cmp    %rdx,%rax
    d1b0:	73 13                	jae    d1c5 <f0+0x1f85>
    d1b2:	49 01 c4             	add    %rax,%r12
    d1b5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1ba:	0f 84 c3 0c 00 00    	je     de83 <f0+0x2c43>
    d1c0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d1cc:	00 f0 3f 
    d1cf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d1d6:	00 
    d1d7:	bf 01 00 00 00       	mov    $0x1,%edi
    d1dc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d1e3:	00 
    d1e4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d1eb:	00 
    d1ec:	e8 2f 91 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d1f1:	48 8b 15 60 79 01 00 	mov    0x17960(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d1f8:	49 89 c5             	mov    %rax,%r13
    d1fb:	48 2b 05 2e 79 01 00 	sub    0x1792e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d202:	48 c1 e2 10          	shl    $0x10,%rdx
    d206:	48 39 d0             	cmp    %rdx,%rax
    d209:	73 59                	jae    d264 <f0+0x2024>
    d20b:	48 89 c2             	mov    %rax,%rdx
    d20e:	48 c1 ea 10          	shr    $0x10,%rdx
    d212:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d216:	48 8b 15 5b 79 01 00 	mov    0x1795b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d21d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d221:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d225:	4d 85 e4             	test   %r12,%r12
    d228:	74 3a                	je     d264 <f0+0x2024>
    d22a:	0f b6 0a             	movzbl (%rdx),%ecx
    d22d:	80 f9 02             	cmp    $0x2,%cl
    d230:	0f 84 da 0a 00 00    	je     dd10 <f0+0x2ad0>
    d236:	80 f9 01             	cmp    $0x1,%cl
    d239:	75 29                	jne    d264 <f0+0x2024>
    d23b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d23e:	0f b7 c0             	movzwl %ax,%eax
    d241:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d244:	48 0f af c1          	imul   %rcx,%rax
    d248:	48 c1 e8 20          	shr    $0x20,%rax
    d24c:	48 39 d0             	cmp    %rdx,%rax
    d24f:	73 13                	jae    d264 <f0+0x2024>
    d251:	49 01 c4             	add    %rax,%r12
    d254:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d259:	0f 84 31 0c 00 00    	je     de90 <f0+0x2c50>
    d25f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d264:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d26b:	33 f3 bf 
    d26e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d275:	00 
    d276:	bf 01 00 00 00       	mov    $0x1,%edi
    d27b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d282:	00 
    d283:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d28a:	00 
    d28b:	e8 90 90 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d290:	48 8b 15 c1 78 01 00 	mov    0x178c1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d297:	49 89 c5             	mov    %rax,%r13
    d29a:	48 2b 05 8f 78 01 00 	sub    0x1788f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d2a1:	48 c1 e2 10          	shl    $0x10,%rdx
    d2a5:	48 39 d0             	cmp    %rdx,%rax
    d2a8:	73 59                	jae    d303 <f0+0x20c3>
    d2aa:	48 89 c2             	mov    %rax,%rdx
    d2ad:	48 c1 ea 10          	shr    $0x10,%rdx
    d2b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2b5:	48 8b 15 bc 78 01 00 	mov    0x178bc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d2bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2c0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2c4:	4d 85 e4             	test   %r12,%r12
    d2c7:	74 3a                	je     d303 <f0+0x20c3>
    d2c9:	0f b6 0a             	movzbl (%rdx),%ecx
    d2cc:	80 f9 02             	cmp    $0x2,%cl
    d2cf:	0f 84 2b 0a 00 00    	je     dd00 <f0+0x2ac0>
    d2d5:	80 f9 01             	cmp    $0x1,%cl
    d2d8:	75 29                	jne    d303 <f0+0x20c3>
    d2da:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2dd:	0f b7 c0             	movzwl %ax,%eax
    d2e0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2e3:	48 0f af c1          	imul   %rcx,%rax
    d2e7:	48 c1 e8 20          	shr    $0x20,%rax
    d2eb:	48 39 d0             	cmp    %rdx,%rax
    d2ee:	73 13                	jae    d303 <f0+0x20c3>
    d2f0:	49 01 c4             	add    %rax,%r12
    d2f3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2f8:	0f 84 9f 0b 00 00    	je     de9d <f0+0x2c5d>
    d2fe:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d303:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d30a:	00 f0 3f 
    d30d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d314:	00 
    d315:	bf 01 00 00 00       	mov    $0x1,%edi
    d31a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d321:	00 
    d322:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d329:	00 
    d32a:	e8 f1 8f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d32f:	48 8b 15 22 78 01 00 	mov    0x17822(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d336:	49 89 c5             	mov    %rax,%r13
    d339:	48 2b 05 f0 77 01 00 	sub    0x177f0(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d340:	48 c1 e2 10          	shl    $0x10,%rdx
    d344:	48 39 d0             	cmp    %rdx,%rax
    d347:	73 59                	jae    d3a2 <f0+0x2162>
    d349:	48 89 c2             	mov    %rax,%rdx
    d34c:	48 c1 ea 10          	shr    $0x10,%rdx
    d350:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d354:	48 8b 15 1d 78 01 00 	mov    0x1781d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d35b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d35f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d363:	4d 85 e4             	test   %r12,%r12
    d366:	74 3a                	je     d3a2 <f0+0x2162>
    d368:	0f b6 0a             	movzbl (%rdx),%ecx
    d36b:	80 f9 02             	cmp    $0x2,%cl
    d36e:	0f 84 7c 09 00 00    	je     dcf0 <f0+0x2ab0>
    d374:	80 f9 01             	cmp    $0x1,%cl
    d377:	75 29                	jne    d3a2 <f0+0x2162>
    d379:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d37c:	0f b7 c0             	movzwl %ax,%eax
    d37f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d382:	48 0f af c1          	imul   %rcx,%rax
    d386:	48 c1 e8 20          	shr    $0x20,%rax
    d38a:	48 39 d0             	cmp    %rdx,%rax
    d38d:	73 13                	jae    d3a2 <f0+0x2162>
    d38f:	49 01 c4             	add    %rax,%r12
    d392:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d397:	0f 84 0d 0b 00 00    	je     deaa <f0+0x2c6a>
    d39d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3a2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d3a9:	33 f3 bf 
    d3ac:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d3b3:	00 
    d3b4:	bf 01 00 00 00       	mov    $0x1,%edi
    d3b9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d3c0:	00 
    d3c1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d3c8:	00 
    d3c9:	e8 52 8f ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d3ce:	48 8b 15 83 77 01 00 	mov    0x17783(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d3d5:	49 89 c5             	mov    %rax,%r13
    d3d8:	48 2b 05 51 77 01 00 	sub    0x17751(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d3df:	48 c1 e2 10          	shl    $0x10,%rdx
    d3e3:	48 39 d0             	cmp    %rdx,%rax
    d3e6:	73 59                	jae    d441 <f0+0x2201>
    d3e8:	48 89 c2             	mov    %rax,%rdx
    d3eb:	48 c1 ea 10          	shr    $0x10,%rdx
    d3ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3f3:	48 8b 15 7e 77 01 00 	mov    0x1777e(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d3fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3fe:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d402:	4d 85 e4             	test   %r12,%r12
    d405:	74 3a                	je     d441 <f0+0x2201>
    d407:	0f b6 0a             	movzbl (%rdx),%ecx
    d40a:	80 f9 02             	cmp    $0x2,%cl
    d40d:	0f 84 cd 08 00 00    	je     dce0 <f0+0x2aa0>
    d413:	80 f9 01             	cmp    $0x1,%cl
    d416:	75 29                	jne    d441 <f0+0x2201>
    d418:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d41b:	0f b7 c0             	movzwl %ax,%eax
    d41e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d421:	48 0f af c1          	imul   %rcx,%rax
    d425:	48 c1 e8 20          	shr    $0x20,%rax
    d429:	48 39 d0             	cmp    %rdx,%rax
    d42c:	73 13                	jae    d441 <f0+0x2201>
    d42e:	49 01 c4             	add    %rax,%r12
    d431:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d436:	0f 84 7b 0a 00 00    	je     deb7 <f0+0x2c77>
    d43c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d441:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d448:	00 f0 3f 
    d44b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d452:	00 
    d453:	bf 01 00 00 00       	mov    $0x1,%edi
    d458:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d45f:	00 
    d460:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d467:	00 
    d468:	e8 b3 8e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d46d:	48 8b 15 e4 76 01 00 	mov    0x176e4(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d474:	49 89 c5             	mov    %rax,%r13
    d477:	48 2b 05 b2 76 01 00 	sub    0x176b2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d47e:	48 c1 e2 10          	shl    $0x10,%rdx
    d482:	48 39 d0             	cmp    %rdx,%rax
    d485:	73 59                	jae    d4e0 <f0+0x22a0>
    d487:	48 89 c2             	mov    %rax,%rdx
    d48a:	48 c1 ea 10          	shr    $0x10,%rdx
    d48e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d492:	48 8b 15 df 76 01 00 	mov    0x176df(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d499:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d49d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4a1:	4d 85 e4             	test   %r12,%r12
    d4a4:	74 3a                	je     d4e0 <f0+0x22a0>
    d4a6:	0f b6 0a             	movzbl (%rdx),%ecx
    d4a9:	80 f9 02             	cmp    $0x2,%cl
    d4ac:	0f 84 1e 08 00 00    	je     dcd0 <f0+0x2a90>
    d4b2:	80 f9 01             	cmp    $0x1,%cl
    d4b5:	75 29                	jne    d4e0 <f0+0x22a0>
    d4b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4ba:	0f b7 c0             	movzwl %ax,%eax
    d4bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4c0:	48 0f af c1          	imul   %rcx,%rax
    d4c4:	48 c1 e8 20          	shr    $0x20,%rax
    d4c8:	48 39 d0             	cmp    %rdx,%rax
    d4cb:	73 13                	jae    d4e0 <f0+0x22a0>
    d4cd:	49 01 c4             	add    %rax,%r12
    d4d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4d5:	0f 84 e9 09 00 00    	je     dec4 <f0+0x2c84>
    d4db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d4e7:	33 f3 bf 
    d4ea:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d4f1:	00 
    d4f2:	bf 01 00 00 00       	mov    $0x1,%edi
    d4f7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d4fe:	00 
    d4ff:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d506:	00 
    d507:	e8 14 8e ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d50c:	48 8b 15 45 76 01 00 	mov    0x17645(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d513:	49 89 c5             	mov    %rax,%r13
    d516:	48 2b 05 13 76 01 00 	sub    0x17613(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d51d:	48 c1 e2 10          	shl    $0x10,%rdx
    d521:	48 39 d0             	cmp    %rdx,%rax
    d524:	73 59                	jae    d57f <f0+0x233f>
    d526:	48 89 c2             	mov    %rax,%rdx
    d529:	48 c1 ea 10          	shr    $0x10,%rdx
    d52d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d531:	48 8b 15 40 76 01 00 	mov    0x17640(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d538:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d53c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d540:	4d 85 e4             	test   %r12,%r12
    d543:	74 3a                	je     d57f <f0+0x233f>
    d545:	0f b6 0a             	movzbl (%rdx),%ecx
    d548:	80 f9 02             	cmp    $0x2,%cl
    d54b:	0f 84 6f 07 00 00    	je     dcc0 <f0+0x2a80>
    d551:	80 f9 01             	cmp    $0x1,%cl
    d554:	75 29                	jne    d57f <f0+0x233f>
    d556:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d559:	0f b7 c0             	movzwl %ax,%eax
    d55c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d55f:	48 0f af c1          	imul   %rcx,%rax
    d563:	48 c1 e8 20          	shr    $0x20,%rax
    d567:	48 39 d0             	cmp    %rdx,%rax
    d56a:	73 13                	jae    d57f <f0+0x233f>
    d56c:	49 01 c4             	add    %rax,%r12
    d56f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d574:	0f 84 57 09 00 00    	je     ded1 <f0+0x2c91>
    d57a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d57f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d586:	00 f0 3f 
    d589:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d590:	00 
    d591:	bf 01 00 00 00       	mov    $0x1,%edi
    d596:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d59d:	00 
    d59e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d5a5:	00 
    d5a6:	e8 75 8d ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d5ab:	48 8b 15 a6 75 01 00 	mov    0x175a6(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d5b2:	49 89 c5             	mov    %rax,%r13
    d5b5:	48 2b 05 74 75 01 00 	sub    0x17574(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d5bc:	48 c1 e2 10          	shl    $0x10,%rdx
    d5c0:	48 39 d0             	cmp    %rdx,%rax
    d5c3:	73 59                	jae    d61e <f0+0x23de>
    d5c5:	48 89 c2             	mov    %rax,%rdx
    d5c8:	48 c1 ea 10          	shr    $0x10,%rdx
    d5cc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5d0:	48 8b 15 a1 75 01 00 	mov    0x175a1(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d5d7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5db:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5df:	4d 85 e4             	test   %r12,%r12
    d5e2:	74 3a                	je     d61e <f0+0x23de>
    d5e4:	0f b6 0a             	movzbl (%rdx),%ecx
    d5e7:	80 f9 02             	cmp    $0x2,%cl
    d5ea:	0f 84 c0 06 00 00    	je     dcb0 <f0+0x2a70>
    d5f0:	80 f9 01             	cmp    $0x1,%cl
    d5f3:	75 29                	jne    d61e <f0+0x23de>
    d5f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5f8:	0f b7 c0             	movzwl %ax,%eax
    d5fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5fe:	48 0f af c1          	imul   %rcx,%rax
    d602:	48 c1 e8 20          	shr    $0x20,%rax
    d606:	48 39 d0             	cmp    %rdx,%rax
    d609:	73 13                	jae    d61e <f0+0x23de>
    d60b:	49 01 c4             	add    %rax,%r12
    d60e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d613:	0f 84 c5 08 00 00    	je     dede <f0+0x2c9e>
    d619:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d61e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d625:	33 f3 bf 
    d628:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d62f:	00 
    d630:	bf 01 00 00 00       	mov    $0x1,%edi
    d635:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d63c:	00 
    d63d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d644:	00 
    d645:	e8 d6 8c ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d64a:	48 8b 15 07 75 01 00 	mov    0x17507(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d651:	49 89 c5             	mov    %rax,%r13
    d654:	48 2b 05 d5 74 01 00 	sub    0x174d5(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d65b:	48 c1 e2 10          	shl    $0x10,%rdx
    d65f:	48 39 d0             	cmp    %rdx,%rax
    d662:	73 59                	jae    d6bd <f0+0x247d>
    d664:	48 89 c2             	mov    %rax,%rdx
    d667:	48 c1 ea 10          	shr    $0x10,%rdx
    d66b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d66f:	48 8b 15 02 75 01 00 	mov    0x17502(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d676:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d67a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d67e:	4d 85 e4             	test   %r12,%r12
    d681:	74 3a                	je     d6bd <f0+0x247d>
    d683:	0f b6 0a             	movzbl (%rdx),%ecx
    d686:	80 f9 02             	cmp    $0x2,%cl
    d689:	0f 84 11 06 00 00    	je     dca0 <f0+0x2a60>
    d68f:	80 f9 01             	cmp    $0x1,%cl
    d692:	75 29                	jne    d6bd <f0+0x247d>
    d694:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d697:	0f b7 c0             	movzwl %ax,%eax
    d69a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d69d:	48 0f af c1          	imul   %rcx,%rax
    d6a1:	48 c1 e8 20          	shr    $0x20,%rax
    d6a5:	48 39 d0             	cmp    %rdx,%rax
    d6a8:	73 13                	jae    d6bd <f0+0x247d>
    d6aa:	49 01 c4             	add    %rax,%r12
    d6ad:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6b2:	0f 84 33 08 00 00    	je     deeb <f0+0x2cab>
    d6b8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6bd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d6c4:	00 f0 3f 
    d6c7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d6ce:	00 
    d6cf:	bf 01 00 00 00       	mov    $0x1,%edi
    d6d4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d6db:	00 
    d6dc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d6e3:	00 
    d6e4:	e8 37 8c ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d6e9:	48 8b 15 68 74 01 00 	mov    0x17468(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d6f0:	49 89 c5             	mov    %rax,%r13
    d6f3:	48 2b 05 36 74 01 00 	sub    0x17436(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d6fa:	48 c1 e2 10          	shl    $0x10,%rdx
    d6fe:	48 39 d0             	cmp    %rdx,%rax
    d701:	73 59                	jae    d75c <f0+0x251c>
    d703:	48 89 c2             	mov    %rax,%rdx
    d706:	48 c1 ea 10          	shr    $0x10,%rdx
    d70a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d70e:	48 8b 15 63 74 01 00 	mov    0x17463(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d715:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d719:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d71d:	4d 85 e4             	test   %r12,%r12
    d720:	74 3a                	je     d75c <f0+0x251c>
    d722:	0f b6 0a             	movzbl (%rdx),%ecx
    d725:	80 f9 02             	cmp    $0x2,%cl
    d728:	0f 84 62 05 00 00    	je     dc90 <f0+0x2a50>
    d72e:	80 f9 01             	cmp    $0x1,%cl
    d731:	75 29                	jne    d75c <f0+0x251c>
    d733:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d736:	0f b7 c0             	movzwl %ax,%eax
    d739:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d73c:	48 0f af c1          	imul   %rcx,%rax
    d740:	48 c1 e8 20          	shr    $0x20,%rax
    d744:	48 39 d0             	cmp    %rdx,%rax
    d747:	73 13                	jae    d75c <f0+0x251c>
    d749:	49 01 c4             	add    %rax,%r12
    d74c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d751:	0f 84 a1 07 00 00    	je     def8 <f0+0x2cb8>
    d757:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d75c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d763:	33 f3 bf 
    d766:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d76d:	00 
    d76e:	bf 01 00 00 00       	mov    $0x1,%edi
    d773:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d77a:	00 
    d77b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d782:	00 
    d783:	e8 98 8b ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d788:	48 8b 15 c9 73 01 00 	mov    0x173c9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d78f:	49 89 c5             	mov    %rax,%r13
    d792:	48 2b 05 97 73 01 00 	sub    0x17397(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d799:	48 c1 e2 10          	shl    $0x10,%rdx
    d79d:	48 39 d0             	cmp    %rdx,%rax
    d7a0:	73 59                	jae    d7fb <f0+0x25bb>
    d7a2:	48 89 c2             	mov    %rax,%rdx
    d7a5:	48 c1 ea 10          	shr    $0x10,%rdx
    d7a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7ad:	48 8b 15 c4 73 01 00 	mov    0x173c4(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d7b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7b8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7bc:	4d 85 e4             	test   %r12,%r12
    d7bf:	74 3a                	je     d7fb <f0+0x25bb>
    d7c1:	0f b6 0a             	movzbl (%rdx),%ecx
    d7c4:	80 f9 02             	cmp    $0x2,%cl
    d7c7:	0f 84 b3 04 00 00    	je     dc80 <f0+0x2a40>
    d7cd:	80 f9 01             	cmp    $0x1,%cl
    d7d0:	75 29                	jne    d7fb <f0+0x25bb>
    d7d2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7d5:	0f b7 c0             	movzwl %ax,%eax
    d7d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7db:	48 0f af c1          	imul   %rcx,%rax
    d7df:	48 c1 e8 20          	shr    $0x20,%rax
    d7e3:	48 39 d0             	cmp    %rdx,%rax
    d7e6:	73 13                	jae    d7fb <f0+0x25bb>
    d7e8:	49 01 c4             	add    %rax,%r12
    d7eb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7f0:	0f 84 0f 07 00 00    	je     df05 <f0+0x2cc5>
    d7f6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7fb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d802:	00 f0 3f 
    d805:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d80c:	00 
    d80d:	bf 01 00 00 00       	mov    $0x1,%edi
    d812:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d819:	00 
    d81a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d821:	00 
    d822:	e8 f9 8a ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d827:	48 8b 15 2a 73 01 00 	mov    0x1732a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d82e:	49 89 c5             	mov    %rax,%r13
    d831:	48 2b 05 f8 72 01 00 	sub    0x172f8(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d838:	48 c1 e2 10          	shl    $0x10,%rdx
    d83c:	48 39 d0             	cmp    %rdx,%rax
    d83f:	73 59                	jae    d89a <f0+0x265a>
    d841:	48 89 c2             	mov    %rax,%rdx
    d844:	48 c1 ea 10          	shr    $0x10,%rdx
    d848:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d84c:	48 8b 15 25 73 01 00 	mov    0x17325(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d853:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d857:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d85b:	4d 85 e4             	test   %r12,%r12
    d85e:	74 3a                	je     d89a <f0+0x265a>
    d860:	0f b6 0a             	movzbl (%rdx),%ecx
    d863:	80 f9 02             	cmp    $0x2,%cl
    d866:	0f 84 04 04 00 00    	je     dc70 <f0+0x2a30>
    d86c:	80 f9 01             	cmp    $0x1,%cl
    d86f:	75 29                	jne    d89a <f0+0x265a>
    d871:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d874:	0f b7 c0             	movzwl %ax,%eax
    d877:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d87a:	48 0f af c1          	imul   %rcx,%rax
    d87e:	48 c1 e8 20          	shr    $0x20,%rax
    d882:	48 39 d0             	cmp    %rdx,%rax
    d885:	73 13                	jae    d89a <f0+0x265a>
    d887:	49 01 c4             	add    %rax,%r12
    d88a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d88f:	0f 84 7d 06 00 00    	je     df12 <f0+0x2cd2>
    d895:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d89a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d8a1:	33 f3 bf 
    d8a4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d8ab:	00 
    d8ac:	bf 01 00 00 00       	mov    $0x1,%edi
    d8b1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d8b8:	00 
    d8b9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d8c0:	00 
    d8c1:	e8 5a 8a ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d8c6:	48 8b 15 8b 72 01 00 	mov    0x1728b(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d8cd:	49 89 c5             	mov    %rax,%r13
    d8d0:	48 2b 05 59 72 01 00 	sub    0x17259(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d8d7:	48 c1 e2 10          	shl    $0x10,%rdx
    d8db:	48 39 d0             	cmp    %rdx,%rax
    d8de:	73 59                	jae    d939 <f0+0x26f9>
    d8e0:	48 89 c2             	mov    %rax,%rdx
    d8e3:	48 c1 ea 10          	shr    $0x10,%rdx
    d8e7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8eb:	48 8b 15 86 72 01 00 	mov    0x17286(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d8f2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8f6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8fa:	4d 85 e4             	test   %r12,%r12
    d8fd:	74 3a                	je     d939 <f0+0x26f9>
    d8ff:	0f b6 0a             	movzbl (%rdx),%ecx
    d902:	80 f9 02             	cmp    $0x2,%cl
    d905:	0f 84 55 03 00 00    	je     dc60 <f0+0x2a20>
    d90b:	80 f9 01             	cmp    $0x1,%cl
    d90e:	75 29                	jne    d939 <f0+0x26f9>
    d910:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d913:	0f b7 c0             	movzwl %ax,%eax
    d916:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d919:	48 0f af c1          	imul   %rcx,%rax
    d91d:	48 c1 e8 20          	shr    $0x20,%rax
    d921:	48 39 d0             	cmp    %rdx,%rax
    d924:	73 13                	jae    d939 <f0+0x26f9>
    d926:	49 01 c4             	add    %rax,%r12
    d929:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d92e:	0f 84 eb 05 00 00    	je     df1f <f0+0x2cdf>
    d934:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d939:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d940:	00 f0 3f 
    d943:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d94a:	00 
    d94b:	bf 01 00 00 00       	mov    $0x1,%edi
    d950:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d957:	00 
    d958:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d95f:	00 
    d960:	e8 bb 89 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d965:	48 8b 15 ec 71 01 00 	mov    0x171ec(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d96c:	49 89 c5             	mov    %rax,%r13
    d96f:	48 2b 05 ba 71 01 00 	sub    0x171ba(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d976:	48 c1 e2 10          	shl    $0x10,%rdx
    d97a:	48 39 d0             	cmp    %rdx,%rax
    d97d:	73 59                	jae    d9d8 <f0+0x2798>
    d97f:	48 89 c2             	mov    %rax,%rdx
    d982:	48 c1 ea 10          	shr    $0x10,%rdx
    d986:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d98a:	48 8b 15 e7 71 01 00 	mov    0x171e7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d991:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d995:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d999:	4d 85 e4             	test   %r12,%r12
    d99c:	74 3a                	je     d9d8 <f0+0x2798>
    d99e:	0f b6 0a             	movzbl (%rdx),%ecx
    d9a1:	80 f9 02             	cmp    $0x2,%cl
    d9a4:	0f 84 a6 02 00 00    	je     dc50 <f0+0x2a10>
    d9aa:	80 f9 01             	cmp    $0x1,%cl
    d9ad:	75 29                	jne    d9d8 <f0+0x2798>
    d9af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9b2:	0f b7 c0             	movzwl %ax,%eax
    d9b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9b8:	48 0f af c1          	imul   %rcx,%rax
    d9bc:	48 c1 e8 20          	shr    $0x20,%rax
    d9c0:	48 39 d0             	cmp    %rdx,%rax
    d9c3:	73 13                	jae    d9d8 <f0+0x2798>
    d9c5:	49 01 c4             	add    %rax,%r12
    d9c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9cd:	0f 84 59 05 00 00    	je     df2c <f0+0x2cec>
    d9d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9d8:	48 89 ee             	mov    %rbp,%rsi
    d9db:	bf 01 00 00 00       	mov    $0x1,%edi
    d9e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d9e7:	33 f3 bf 
    d9ea:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d9f1:	00 
    d9f2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d9f9:	00 
    d9fa:	e8 21 89 ff ff       	call   6320 <fwp_data.part.0.constprop.0>
    d9ff:	48 8b 15 52 71 01 00 	mov    0x17152(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    da06:	48 89 c5             	mov    %rax,%rbp
    da09:	48 2b 05 20 71 01 00 	sub    0x17120(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    da10:	48 c1 e2 10          	shl    $0x10,%rdx
    da14:	48 39 d0             	cmp    %rdx,%rax
    da17:	73 59                	jae    da72 <f0+0x2832>
    da19:	48 89 c2             	mov    %rax,%rdx
    da1c:	48 c1 ea 10          	shr    $0x10,%rdx
    da20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da24:	48 8b 15 4d 71 01 00 	mov    0x1714d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    da2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da2f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da33:	4d 85 e4             	test   %r12,%r12
    da36:	74 3a                	je     da72 <f0+0x2832>
    da38:	0f b6 0a             	movzbl (%rdx),%ecx
    da3b:	80 f9 02             	cmp    $0x2,%cl
    da3e:	0f 84 fc 01 00 00    	je     dc40 <f0+0x2a00>
    da44:	80 f9 01             	cmp    $0x1,%cl
    da47:	75 29                	jne    da72 <f0+0x2832>
    da49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da4c:	0f b7 c0             	movzwl %ax,%eax
    da4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da52:	48 0f af c1          	imul   %rcx,%rax
    da56:	48 c1 e8 20          	shr    $0x20,%rax
    da5a:	48 39 d0             	cmp    %rdx,%rax
    da5d:	73 13                	jae    da72 <f0+0x2832>
    da5f:	49 01 c4             	add    %rax,%r12
    da62:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da67:	0f 84 d1 02 00 00    	je     dd3e <f0+0x2afe>
    da6d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da72:	48 89 de             	mov    %rbx,%rsi
    da75:	48 89 ef             	mov    %rbp,%rdi
    da78:	e8 63 cb ff ff       	call   a5e0 <fwp_hof0.constprop.0>
    da7d:	48 89 ef             	mov    %rbp,%rdi
    da80:	e8 0b 8e ff ff       	call   6890 <fwp_drop0>
    da85:	48 89 df             	mov    %rbx,%rdi
    da88:	e8 03 8e ff ff       	call   6890 <fwp_drop0>
    da8d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    da94:	00 
    da95:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    da9c:	00 00 
    da9e:	0f 85 95 04 00 00    	jne    df39 <f0+0x2cf9>
    daa4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    daab:	31 c0                	xor    %eax,%eax
    daad:	5b                   	pop    %rbx
    daae:	5d                   	pop    %rbp
    daaf:	41 5c                	pop    %r12
    dab1:	41 5d                	pop    %r13
    dab3:	41 5e                	pop    %r14
    dab5:	c3                   	ret
    dab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dabd:	00 00 00 
    dac0:	4c 89 ef             	mov    %r13,%rdi
    dac3:	e8 48 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    dac8:	e9 2c d8 ff ff       	jmp    b2f9 <f0+0xb9>
    dacd:	0f 1f 00             	nopl   (%rax)
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 ae f5 ff ff    	jne    d087 <f0+0x1e47>
    dad9:	e9 99 f5 ff ff       	jmp    d077 <f0+0x1e37>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 ff f4 ff ff    	jne    cfe8 <f0+0x1da8>
    dae9:	e9 ea f4 ff ff       	jmp    cfd8 <f0+0x1d98>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 50 f4 ff ff    	jne    cf49 <f0+0x1d09>
    daf9:	e9 3b f4 ff ff       	jmp    cf39 <f0+0x1cf9>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 a1 f3 ff ff    	jne    ceaa <f0+0x1c6a>
    db09:	e9 8c f3 ff ff       	jmp    ce9a <f0+0x1c5a>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 f2 f2 ff ff    	jne    ce0b <f0+0x1bcb>
    db19:	e9 dd f2 ff ff       	jmp    cdfb <f0+0x1bbb>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 43 f2 ff ff    	jne    cd6c <f0+0x1b2c>
    db29:	e9 2e f2 ff ff       	jmp    cd5c <f0+0x1b1c>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 94 f1 ff ff    	jne    cccd <f0+0x1a8d>
    db39:	e9 7f f1 ff ff       	jmp    ccbd <f0+0x1a7d>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 e5 f0 ff ff    	jne    cc2e <f0+0x19ee>
    db49:	e9 d0 f0 ff ff       	jmp    cc1e <f0+0x19de>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 fd d9 ff ff    	jne    b556 <f0+0x316>
    db59:	e9 e8 d9 ff ff       	jmp    b546 <f0+0x306>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 57 d9 ff ff    	jne    b4c0 <f0+0x280>
    db69:	e9 42 d9 ff ff       	jmp    b4b0 <f0+0x270>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 b1 d8 ff ff    	jne    b42a <f0+0x1ea>
    db79:	e9 9c d8 ff ff       	jmp    b41a <f0+0x1da>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 0e eb ff ff    	jne    c697 <f0+0x1457>
    db89:	e9 f9 ea ff ff       	jmp    c687 <f0+0x1447>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 5f ea ff ff    	jne    c5f8 <f0+0x13b8>
    db99:	e9 4a ea ff ff       	jmp    c5e8 <f0+0x13a8>
    db9e:	66 90                	xchg   %ax,%ax
    dba0:	66 85 c0             	test   %ax,%ax
    dba3:	0f 85 e2 da ff ff    	jne    b68b <f0+0x44b>
    dba9:	e9 cd da ff ff       	jmp    b67b <f0+0x43b>
    dbae:	66 90                	xchg   %ax,%ax
    dbb0:	66 85 c0             	test   %ax,%ax
    dbb3:	0f 85 33 da ff ff    	jne    b5ec <f0+0x3ac>
    dbb9:	e9 1e da ff ff       	jmp    b5dc <f0+0x39c>
    dbbe:	66 90                	xchg   %ax,%ax
    dbc0:	66 85 c0             	test   %ax,%ax
    dbc3:	0f 85 c6 ef ff ff    	jne    cb8f <f0+0x194f>
    dbc9:	e9 b1 ef ff ff       	jmp    cb7f <f0+0x193f>
    dbce:	66 90                	xchg   %ax,%ax
    dbd0:	66 85 c0             	test   %ax,%ax
    dbd3:	0f 85 17 ef ff ff    	jne    caf0 <f0+0x18b0>
    dbd9:	e9 02 ef ff ff       	jmp    cae0 <f0+0x18a0>
    dbde:	66 90                	xchg   %ax,%ax
    dbe0:	66 85 c0             	test   %ax,%ax
    dbe3:	0f 85 68 ee ff ff    	jne    ca51 <f0+0x1811>
    dbe9:	e9 53 ee ff ff       	jmp    ca41 <f0+0x1801>
    dbee:	66 90                	xchg   %ax,%ax
    dbf0:	66 85 c0             	test   %ax,%ax
    dbf3:	0f 85 b9 ed ff ff    	jne    c9b2 <f0+0x1772>
    dbf9:	e9 a4 ed ff ff       	jmp    c9a2 <f0+0x1762>
    dbfe:	66 90                	xchg   %ax,%ax
    dc00:	66 85 c0             	test   %ax,%ax
    dc03:	0f 85 0a ed ff ff    	jne    c913 <f0+0x16d3>
    dc09:	e9 f5 ec ff ff       	jmp    c903 <f0+0x16c3>
    dc0e:	66 90                	xchg   %ax,%ax
    dc10:	66 85 c0             	test   %ax,%ax
    dc13:	0f 85 5b ec ff ff    	jne    c874 <f0+0x1634>
    dc19:	e9 46 ec ff ff       	jmp    c864 <f0+0x1624>
    dc1e:	66 90                	xchg   %ax,%ax
    dc20:	66 85 c0             	test   %ax,%ax
    dc23:	0f 85 ac eb ff ff    	jne    c7d5 <f0+0x1595>
    dc29:	e9 97 eb ff ff       	jmp    c7c5 <f0+0x1585>
    dc2e:	66 90                	xchg   %ax,%ax
    dc30:	66 85 c0             	test   %ax,%ax
    dc33:	0f 85 fd ea ff ff    	jne    c736 <f0+0x14f6>
    dc39:	e9 e8 ea ff ff       	jmp    c726 <f0+0x14e6>
    dc3e:	66 90                	xchg   %ax,%ax
    dc40:	66 85 c0             	test   %ax,%ax
    dc43:	0f 85 29 fe ff ff    	jne    da72 <f0+0x2832>
    dc49:	e9 14 fe ff ff       	jmp    da62 <f0+0x2822>
    dc4e:	66 90                	xchg   %ax,%ax
    dc50:	66 85 c0             	test   %ax,%ax
    dc53:	0f 85 7f fd ff ff    	jne    d9d8 <f0+0x2798>
    dc59:	e9 6a fd ff ff       	jmp    d9c8 <f0+0x2788>
    dc5e:	66 90                	xchg   %ax,%ax
    dc60:	66 85 c0             	test   %ax,%ax
    dc63:	0f 85 d0 fc ff ff    	jne    d939 <f0+0x26f9>
    dc69:	e9 bb fc ff ff       	jmp    d929 <f0+0x26e9>
    dc6e:	66 90                	xchg   %ax,%ax
    dc70:	66 85 c0             	test   %ax,%ax
    dc73:	0f 85 21 fc ff ff    	jne    d89a <f0+0x265a>
    dc79:	e9 0c fc ff ff       	jmp    d88a <f0+0x264a>
    dc7e:	66 90                	xchg   %ax,%ax
    dc80:	66 85 c0             	test   %ax,%ax
    dc83:	0f 85 72 fb ff ff    	jne    d7fb <f0+0x25bb>
    dc89:	e9 5d fb ff ff       	jmp    d7eb <f0+0x25ab>
    dc8e:	66 90                	xchg   %ax,%ax
    dc90:	66 85 c0             	test   %ax,%ax
    dc93:	0f 85 c3 fa ff ff    	jne    d75c <f0+0x251c>
    dc99:	e9 ae fa ff ff       	jmp    d74c <f0+0x250c>
    dc9e:	66 90                	xchg   %ax,%ax
    dca0:	66 85 c0             	test   %ax,%ax
    dca3:	0f 85 14 fa ff ff    	jne    d6bd <f0+0x247d>
    dca9:	e9 ff f9 ff ff       	jmp    d6ad <f0+0x246d>
    dcae:	66 90                	xchg   %ax,%ax
    dcb0:	66 85 c0             	test   %ax,%ax
    dcb3:	0f 85 65 f9 ff ff    	jne    d61e <f0+0x23de>
    dcb9:	e9 50 f9 ff ff       	jmp    d60e <f0+0x23ce>
    dcbe:	66 90                	xchg   %ax,%ax
    dcc0:	66 85 c0             	test   %ax,%ax
    dcc3:	0f 85 b6 f8 ff ff    	jne    d57f <f0+0x233f>
    dcc9:	e9 a1 f8 ff ff       	jmp    d56f <f0+0x232f>
    dcce:	66 90                	xchg   %ax,%ax
    dcd0:	66 85 c0             	test   %ax,%ax
    dcd3:	0f 85 07 f8 ff ff    	jne    d4e0 <f0+0x22a0>
    dcd9:	e9 f2 f7 ff ff       	jmp    d4d0 <f0+0x2290>
    dcde:	66 90                	xchg   %ax,%ax
    dce0:	66 85 c0             	test   %ax,%ax
    dce3:	0f 85 58 f7 ff ff    	jne    d441 <f0+0x2201>
    dce9:	e9 43 f7 ff ff       	jmp    d431 <f0+0x21f1>
    dcee:	66 90                	xchg   %ax,%ax
    dcf0:	66 85 c0             	test   %ax,%ax
    dcf3:	0f 85 a9 f6 ff ff    	jne    d3a2 <f0+0x2162>
    dcf9:	e9 94 f6 ff ff       	jmp    d392 <f0+0x2152>
    dcfe:	66 90                	xchg   %ax,%ax
    dd00:	66 85 c0             	test   %ax,%ax
    dd03:	0f 85 fa f5 ff ff    	jne    d303 <f0+0x20c3>
    dd09:	e9 e5 f5 ff ff       	jmp    d2f3 <f0+0x20b3>
    dd0e:	66 90                	xchg   %ax,%ax
    dd10:	66 85 c0             	test   %ax,%ax
    dd13:	0f 85 4b f5 ff ff    	jne    d264 <f0+0x2024>
    dd19:	e9 36 f5 ff ff       	jmp    d254 <f0+0x2014>
    dd1e:	66 90                	xchg   %ax,%ax
    dd20:	66 85 c0             	test   %ax,%ax
    dd23:	0f 85 9c f4 ff ff    	jne    d1c5 <f0+0x1f85>
    dd29:	e9 87 f4 ff ff       	jmp    d1b5 <f0+0x1f75>
    dd2e:	66 90                	xchg   %ax,%ax
    dd30:	66 85 c0             	test   %ax,%ax
    dd33:	0f 85 ed f3 ff ff    	jne    d126 <f0+0x1ee6>
    dd39:	e9 d8 f3 ff ff       	jmp    d116 <f0+0x1ed6>
    dd3e:	4c 89 e7             	mov    %r12,%rdi
    dd41:	e8 ca 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd46:	e9 22 fd ff ff       	jmp    da6d <f0+0x282d>
    dd4b:	4c 89 e7             	mov    %r12,%rdi
    dd4e:	e8 bd 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd53:	e9 cd d6 ff ff       	jmp    b425 <f0+0x1e5>
    dd58:	4c 89 e7             	mov    %r12,%rdi
    dd5b:	e8 b0 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd60:	e9 56 d7 ff ff       	jmp    b4bb <f0+0x27b>
    dd65:	4c 89 e7             	mov    %r12,%rdi
    dd68:	e8 a3 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd6d:	e9 df d7 ff ff       	jmp    b551 <f0+0x311>
    dd72:	4c 89 e7             	mov    %r12,%rdi
    dd75:	e8 96 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd7a:	e9 68 d8 ff ff       	jmp    b5e7 <f0+0x3a7>
    dd7f:	4c 89 e7             	mov    %r12,%rdi
    dd82:	e8 89 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd87:	e9 fa d8 ff ff       	jmp    b686 <f0+0x446>
    dd8c:	4c 89 e7             	mov    %r12,%rdi
    dd8f:	e8 7c 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd94:	e9 5a e8 ff ff       	jmp    c5f3 <f0+0x13b3>
    dd99:	4c 89 e7             	mov    %r12,%rdi
    dd9c:	e8 6f 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dda1:	e9 ec e8 ff ff       	jmp    c692 <f0+0x1452>
    dda6:	4c 89 e7             	mov    %r12,%rdi
    dda9:	e8 62 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddae:	e9 7e e9 ff ff       	jmp    c731 <f0+0x14f1>
    ddb3:	4c 89 e7             	mov    %r12,%rdi
    ddb6:	e8 55 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddbb:	e9 10 ea ff ff       	jmp    c7d0 <f0+0x1590>
    ddc0:	4c 89 e7             	mov    %r12,%rdi
    ddc3:	e8 48 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddc8:	e9 a2 ea ff ff       	jmp    c86f <f0+0x162f>
    ddcd:	4c 89 e7             	mov    %r12,%rdi
    ddd0:	e8 3b 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddd5:	e9 34 eb ff ff       	jmp    c90e <f0+0x16ce>
    ddda:	4c 89 e7             	mov    %r12,%rdi
    dddd:	e8 2e 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dde2:	e9 c6 eb ff ff       	jmp    c9ad <f0+0x176d>
    dde7:	4c 89 e7             	mov    %r12,%rdi
    ddea:	e8 21 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddef:	e9 58 ec ff ff       	jmp    ca4c <f0+0x180c>
    ddf4:	4c 89 e7             	mov    %r12,%rdi
    ddf7:	e8 14 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddfc:	e9 ea ec ff ff       	jmp    caeb <f0+0x18ab>
    de01:	4c 89 e7             	mov    %r12,%rdi
    de04:	e8 07 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    de09:	e9 7c ed ff ff       	jmp    cb8a <f0+0x194a>
    de0e:	4c 89 e7             	mov    %r12,%rdi
    de11:	e8 fa 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de16:	e9 0e ee ff ff       	jmp    cc29 <f0+0x19e9>
    de1b:	4c 89 e7             	mov    %r12,%rdi
    de1e:	e8 ed 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de23:	e9 a0 ee ff ff       	jmp    ccc8 <f0+0x1a88>
    de28:	4c 89 e7             	mov    %r12,%rdi
    de2b:	e8 e0 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de30:	e9 32 ef ff ff       	jmp    cd67 <f0+0x1b27>
    de35:	4c 89 e7             	mov    %r12,%rdi
    de38:	e8 d3 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de3d:	e9 c4 ef ff ff       	jmp    ce06 <f0+0x1bc6>
    de42:	4c 89 e7             	mov    %r12,%rdi
    de45:	e8 c6 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de4a:	e9 56 f0 ff ff       	jmp    cea5 <f0+0x1c65>
    de4f:	4c 89 e7             	mov    %r12,%rdi
    de52:	e8 b9 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de57:	e9 e8 f0 ff ff       	jmp    cf44 <f0+0x1d04>
    de5c:	4c 89 e7             	mov    %r12,%rdi
    de5f:	e8 ac 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de64:	e9 7a f1 ff ff       	jmp    cfe3 <f0+0x1da3>
    de69:	4c 89 e7             	mov    %r12,%rdi
    de6c:	e8 9f 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de71:	e9 0c f2 ff ff       	jmp    d082 <f0+0x1e42>
    de76:	4c 89 e7             	mov    %r12,%rdi
    de79:	e8 92 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de7e:	e9 9e f2 ff ff       	jmp    d121 <f0+0x1ee1>
    de83:	4c 89 e7             	mov    %r12,%rdi
    de86:	e8 85 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de8b:	e9 30 f3 ff ff       	jmp    d1c0 <f0+0x1f80>
    de90:	4c 89 e7             	mov    %r12,%rdi
    de93:	e8 78 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de98:	e9 c2 f3 ff ff       	jmp    d25f <f0+0x201f>
    de9d:	4c 89 e7             	mov    %r12,%rdi
    dea0:	e8 6b 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    dea5:	e9 54 f4 ff ff       	jmp    d2fe <f0+0x20be>
    deaa:	4c 89 e7             	mov    %r12,%rdi
    dead:	e8 5e 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    deb2:	e9 e6 f4 ff ff       	jmp    d39d <f0+0x215d>
    deb7:	4c 89 e7             	mov    %r12,%rdi
    deba:	e8 51 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    debf:	e9 78 f5 ff ff       	jmp    d43c <f0+0x21fc>
    dec4:	4c 89 e7             	mov    %r12,%rdi
    dec7:	e8 44 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    decc:	e9 0a f6 ff ff       	jmp    d4db <f0+0x229b>
    ded1:	4c 89 e7             	mov    %r12,%rdi
    ded4:	e8 37 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    ded9:	e9 9c f6 ff ff       	jmp    d57a <f0+0x233a>
    dede:	4c 89 e7             	mov    %r12,%rdi
    dee1:	e8 2a 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    dee6:	e9 2e f7 ff ff       	jmp    d619 <f0+0x23d9>
    deeb:	4c 89 e7             	mov    %r12,%rdi
    deee:	e8 1d 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    def3:	e9 c0 f7 ff ff       	jmp    d6b8 <f0+0x2478>
    def8:	4c 89 e7             	mov    %r12,%rdi
    defb:	e8 10 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    df00:	e9 52 f8 ff ff       	jmp    d757 <f0+0x2517>
    df05:	4c 89 e7             	mov    %r12,%rdi
    df08:	e8 03 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    df0d:	e9 e4 f8 ff ff       	jmp    d7f6 <f0+0x25b6>
    df12:	4c 89 e7             	mov    %r12,%rdi
    df15:	e8 f6 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df1a:	e9 76 f9 ff ff       	jmp    d895 <f0+0x2655>
    df1f:	4c 89 e7             	mov    %r12,%rdi
    df22:	e8 e9 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df27:	e9 08 fa ff ff       	jmp    d934 <f0+0x26f4>
    df2c:	4c 89 e7             	mov    %r12,%rdi
    df2f:	e8 dc 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df34:	e9 9a fa ff ff       	jmp    d9d3 <f0+0x2793>
    df39:	e8 22 55 ff ff       	call   3460 <__stack_chk_fail@plt>
    df3e:	66 90                	xchg   %ax,%ax

000000000000df40 <fwp_main_thread>:
    df40:	f3 0f 1e fa          	endbr64
    df44:	41 54                	push   %r12
    df46:	55                   	push   %rbp
    df47:	53                   	push   %rbx
    df48:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    df4f:	8b 0d cf 6b 01 00    	mov    0x16bcf(%rip),%ecx        # 24b24 <fwp_heap+0x13a4>
    df55:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    df5c:	00 00 
    df5e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    df65:	00 
    df66:	31 c0                	xor    %eax,%eax
    df68:	85 c9                	test   %ecx,%ecx
    df6a:	0f 84 68 06 00 00    	je     e5d8 <fwp_main_thread+0x698>
    df70:	8b 15 b2 6b 01 00    	mov    0x16bb2(%rip),%edx        # 24b28 <fwp_heap+0x13a8>
    df76:	85 d2                	test   %edx,%edx
    df78:	0f 85 42 06 00 00    	jne    e5c0 <fwp_main_thread+0x680>
    df7e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    df83:	31 f6                	xor    %esi,%esi
    df85:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    df8a:	48 c7 05 83 51 01 00 	movq   $0x40000000,0x15183(%rip)        # 23118 <fwp_main_stack_size>
    df91:	00 00 00 40 
    df95:	48 89 05 84 51 01 00 	mov    %rax,0x15184(%rip)        # 23120 <fwp_main_stack_top>
    df9c:	48 8d 05 fd 50 00 00 	lea    0x50fd(%rip),%rax        # 130a0 <alt.5>
    dfa3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    dfa8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    dfaf:	01 00 
    dfb1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    dfb8:	00 
    dfb9:	e8 02 57 ff ff       	call   36c0 <sigaltstack@plt>
    dfbe:	85 c0                	test   %eax,%eax
    dfc0:	0f 85 4a 06 00 00    	jne    e610 <fwp_main_thread+0x6d0>
    dfc6:	31 c0                	xor    %eax,%eax
    dfc8:	b9 12 00 00 00       	mov    $0x12,%ecx
    dfcd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dfd2:	f3 48 ab             	rep stos %rax,(%rdi)
    dfd5:	48 8d 05 14 5d ff ff 	lea    -0xa2ec(%rip),%rax        # 3cf0 <fwp_segv>
    dfdc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dfe1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    dfe8:	04 00 00 08 
    dfec:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    dff1:	e8 8a 55 ff ff       	call   3580 <sigemptyset@plt>
    dff6:	85 c0                	test   %eax,%eax
    dff8:	0f 85 12 06 00 00    	jne    e610 <fwp_main_thread+0x6d0>
    dffe:	31 d2                	xor    %edx,%edx
    e000:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e005:	bf 0b 00 00 00       	mov    $0xb,%edi
    e00a:	e8 f1 53 ff ff       	call   3400 <sigaction@plt>
    e00f:	85 c0                	test   %eax,%eax
    e011:	0f 85 f9 05 00 00    	jne    e610 <fwp_main_thread+0x6d0>
    e017:	31 d2                	xor    %edx,%edx
    e019:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e01e:	bf 07 00 00 00       	mov    $0x7,%edi
    e023:	e8 d8 53 ff ff       	call   3400 <sigaction@plt>
    e028:	85 c0                	test   %eax,%eax
    e02a:	0f 85 e0 05 00 00    	jne    e610 <fwp_main_thread+0x6d0>
    e030:	8b 05 5a 50 00 00    	mov    0x505a(%rip),%eax        # 13090 <st.3>
    e036:	85 c0                	test   %eax,%eax
    e038:	0f 84 62 05 00 00    	je     e5a0 <fwp_main_thread+0x660>
    e03e:	48 8b 2d 1b 57 01 00 	mov    0x1571b(%rip),%rbp        # 23760 <fwp_cur>
    e045:	48 85 ed             	test   %rbp,%rbp
    e048:	0f 84 72 03 00 00    	je     e3c0 <fwp_main_thread+0x480>
    e04e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e053:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e057:	48 89 eb             	mov    %rbp,%rbx
    e05a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e05f:	0f 84 41 01 00 00    	je     e1a6 <fwp_main_thread+0x266>
    e065:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e06a:	0f 84 80 02 00 00    	je     e2f0 <fwp_main_thread+0x3b0>
    e070:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e074:	0f 84 66 02 00 00    	je     e2e0 <fwp_main_thread+0x3a0>
    e07a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e07e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e082:	0f 85 e8 02 00 00    	jne    e370 <fwp_main_thread+0x430>
    e088:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e08c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e093:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e097:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e09e:	00 00 00 00 
    e0a2:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e0a9:	48 85 d2             	test   %rdx,%rdx
    e0ac:	74 07                	je     e0b5 <fwp_main_thread+0x175>
    e0ae:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e0b5:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e0b9:	48 85 c0             	test   %rax,%rax
    e0bc:	74 34                	je     e0f2 <fwp_main_thread+0x1b2>
    e0be:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e0c2:	48 8b 05 6f 56 01 00 	mov    0x1566f(%rip),%rax        # 23738 <fwp_timers>
    e0c9:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e0cd:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e0d4:	00 00 00 00 
    e0d8:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e0df:	48 85 c0             	test   %rax,%rax
    e0e2:	74 07                	je     e0eb <fwp_main_thread+0x1ab>
    e0e4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e0eb:	48 89 1d 46 56 01 00 	mov    %rbx,0x15646(%rip)        # 23738 <fwp_timers>
    e0f2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e0f6:	e8 d5 91 ff ff       	call   72d0 <fwp_block>
    e0fb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e102:	48 85 c9             	test   %rcx,%rcx
    e105:	74 47                	je     e14e <fwp_main_thread+0x20e>
    e107:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e10e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e115:	48 85 d2             	test   %rdx,%rdx
    e118:	0f 84 92 02 00 00    	je     e3b0 <fwp_main_thread+0x470>
    e11e:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e125:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e12c:	48 85 c0             	test   %rax,%rax
    e12f:	74 07                	je     e138 <fwp_main_thread+0x1f8>
    e131:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e138:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e13f:	00 00 00 00 
    e143:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e147:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e14e:	48 8b 0d 0b 56 01 00 	mov    0x1560b(%rip),%rcx        # 23760 <fwp_cur>
    e155:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e159:	0f 84 01 02 00 00    	je     e360 <fwp_main_thread+0x420>
    e15f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e166:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e16d:	48 85 d2             	test   %rdx,%rdx
    e170:	0f 84 fa 03 00 00    	je     e570 <fwp_main_thread+0x630>
    e176:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e17d:	48 85 c0             	test   %rax,%rax
    e180:	74 07                	je     e189 <fwp_main_thread+0x249>
    e182:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e189:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e18d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e191:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e198:	48 89 cb             	mov    %rcx,%rbx
    e19b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e1a0:	0f 85 bf fe ff ff    	jne    e065 <fwp_main_thread+0x125>
    e1a6:	48 83 3d 4a 72 01 00 	cmpq   $0x0,0x1724a(%rip)        # 253f8 <fwp_state_len>
    e1ad:	00 
    e1ae:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e1b2:	0f 84 ba 00 00 00    	je     e272 <fwp_main_thread+0x332>
    e1b8:	48 39 1d 99 55 01 00 	cmp    %rbx,0x15599(%rip)        # 23758 <fwp_root>
    e1bf:	c7 05 d7 4e 01 00 00 	movl   $0x0,0x14ed7(%rip)        # 230a0 <fwp_exit_code>
    e1c6:	00 00 00 
    e1c9:	0f 85 5f 04 00 00    	jne    e62e <fwp_main_thread+0x6ee>
    e1cf:	48 85 db             	test   %rbx,%rbx
    e1d2:	0f 84 0e 02 00 00    	je     e3e6 <fwp_main_thread+0x4a6>
    e1d8:	48 8b 15 49 55 01 00 	mov    0x15549(%rip),%rdx        # 23728 <fwp_tasks_active>
    e1df:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e1e3:	48 85 d2             	test   %rdx,%rdx
    e1e6:	0f 84 fa 01 00 00    	je     e3e6 <fwp_main_thread+0x4a6>
    e1ec:	0f 1f 40 00          	nopl   0x0(%rax)
    e1f0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e1f4:	75 08                	jne    e1fe <fwp_main_thread+0x2be>
    e1f6:	48 89 d7             	mov    %rdx,%rdi
    e1f9:	e8 b2 5e ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e1fe:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e205:	48 85 d2             	test   %rdx,%rdx
    e208:	75 e6                	jne    e1f0 <fwp_main_thread+0x2b0>
    e20a:	eb 31                	jmp    e23d <fwp_main_thread+0x2fd>
    e20c:	0f 1f 40 00          	nopl   0x0(%rax)
    e210:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e217:	48 89 1d 22 55 01 00 	mov    %rbx,0x15522(%rip)        # 23740 <fwp_ready_tail>
    e21e:	e8 ad 90 ff ff       	call   72d0 <fwp_block>
    e223:	e8 a8 8e ff ff       	call   70d0 <fwp_free_zombie>
    e228:	48 83 3d f8 54 01 00 	cmpq   $0x0,0x154f8(%rip)        # 23728 <fwp_tasks_active>
    e22f:	00 
    e230:	0f 84 b0 01 00 00    	je     e3e6 <fwp_main_thread+0x4a6>
    e236:	48 8b 1d 1b 55 01 00 	mov    0x1551b(%rip),%rbx        # 23758 <fwp_root>
    e23d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e241:	75 db                	jne    e21e <fwp_main_thread+0x2de>
    e243:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e247:	75 d5                	jne    e21e <fwp_main_thread+0x2de>
    e249:	48 8b 05 f0 54 01 00 	mov    0x154f0(%rip),%rax        # 23740 <fwp_ready_tail>
    e250:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e254:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e25b:	00 00 00 00 
    e25f:	48 85 c0             	test   %rax,%rax
    e262:	75 ac                	jne    e210 <fwp_main_thread+0x2d0>
    e264:	48 89 1d dd 54 01 00 	mov    %rbx,0x154dd(%rip)        # 23748 <fwp_ready_head>
    e26b:	eb aa                	jmp    e217 <fwp_main_thread+0x2d7>
    e26d:	0f 1f 00             	nopl   (%rax)
    e270:	31 db                	xor    %ebx,%ebx
    e272:	48 83 3d 6e 71 01 00 	cmpq   $0x0,0x1716e(%rip)        # 253e8 <fwp_state_owners>
    e279:	00 
    e27a:	0f 85 38 ff ff ff    	jne    e1b8 <fwp_main_thread+0x278>
    e280:	48 8b 3d 79 71 01 00 	mov    0x17179(%rip),%rdi        # 25400 <fwp_state>
    e287:	e8 c4 72 ff ff       	call   5550 <fwp_mem_free>
    e28c:	48 c7 05 69 71 01 00 	movq   $0x0,0x17169(%rip)        # 25400 <fwp_state>
    e293:	00 00 00 00 
    e297:	48 c7 05 4e 71 01 00 	movq   $0x0,0x1714e(%rip)        # 253f0 <fwp_state_cap>
    e29e:	00 00 00 00 
    e2a2:	48 85 db             	test   %rbx,%rbx
    e2a5:	0f 84 46 03 00 00    	je     e5f1 <fwp_main_thread+0x6b1>
    e2ab:	48 39 1d a6 54 01 00 	cmp    %rbx,0x154a6(%rip)        # 23758 <fwp_root>
    e2b2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e2b9:	00 00 00 00 
    e2bd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e2c4:	00 00 00 00 
    e2c8:	c7 05 ce 4d 01 00 00 	movl   $0x0,0x14dce(%rip)        # 230a0 <fwp_exit_code>
    e2cf:	00 00 00 
    e2d2:	0f 84 00 ff ff ff    	je     e1d8 <fwp_main_thread+0x298>
    e2d8:	e9 73 54 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e2dd:	0f 1f 00             	nopl   (%rax)
    e2e0:	e8 2b 60 ff ff       	call   4310 <fwp_now_ns>
    e2e5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e2e9:	0f 8d 91 02 00 00    	jge    e580 <fwp_main_thread+0x640>
    e2ef:	90                   	nop
    e2f0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e2f4:	0f 85 80 fd ff ff    	jne    e07a <fwp_main_thread+0x13a>
    e2fa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e2fe:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e302:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e306:	0f 85 80 fd ff ff    	jne    e08c <fwp_main_thread+0x14c>
    e30c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e310:	48 85 c9             	test   %rcx,%rcx
    e313:	0f 84 73 fd ff ff    	je     e08c <fwp_main_thread+0x14c>
    e319:	48 85 c0             	test   %rax,%rax
    e31c:	0f 84 ff 02 00 00    	je     e621 <fwp_main_thread+0x6e1>
    e322:	48 39 c8             	cmp    %rcx,%rax
    e325:	48 0f 4f c1          	cmovg  %rcx,%rax
    e329:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e330:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e334:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e33b:	00 00 00 00 
    e33f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e346:	48 85 d2             	test   %rdx,%rdx
    e349:	74 07                	je     e352 <fwp_main_thread+0x412>
    e34b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e352:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e356:	e9 63 fd ff ff       	jmp    e0be <fwp_main_thread+0x17e>
    e35b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e360:	48 89 cb             	mov    %rcx,%rbx
    e363:	e9 f2 fc ff ff       	jmp    e05a <fwp_main_thread+0x11a>
    e368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e36f:	00 
    e370:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e374:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e37b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e382:	00 00 00 00 
    e386:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e38d:	48 85 c0             	test   %rax,%rax
    e390:	0f 84 52 02 00 00    	je     e5e8 <fwp_main_thread+0x6a8>
    e396:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e39d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e3a1:	e9 4c fd ff ff       	jmp    e0f2 <fwp_main_thread+0x1b2>
    e3a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e3ad:	00 00 00 
    e3b0:	48 89 01             	mov    %rax,(%rcx)
    e3b3:	e9 74 fd ff ff       	jmp    e12c <fwp_main_thread+0x1ec>
    e3b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e3bf:	00 
    e3c0:	48 83 3d 30 70 01 00 	cmpq   $0x0,0x17030(%rip)        # 253f8 <fwp_state_len>
    e3c7:	00 
    e3c8:	0f 84 a2 fe ff ff    	je     e270 <fwp_main_thread+0x330>
    e3ce:	48 83 3d 82 53 01 00 	cmpq   $0x0,0x15382(%rip)        # 23758 <fwp_root>
    e3d5:	00 
    e3d6:	c7 05 c0 4c 01 00 00 	movl   $0x0,0x14cc0(%rip)        # 230a0 <fwp_exit_code>
    e3dd:	00 00 00 
    e3e0:	0f 85 43 02 00 00    	jne    e629 <fwp_main_thread+0x6e9>
    e3e6:	e8 e5 8c ff ff       	call   70d0 <fwp_free_zombie>
    e3eb:	48 83 3d 55 53 01 00 	cmpq   $0x0,0x15355(%rip)        # 23748 <fwp_ready_head>
    e3f2:	00 
    e3f3:	0f 85 57 53 ff ff    	jne    3750 <fwp_main_thread.cold>
    e3f9:	48 83 3d 37 53 01 00 	cmpq   $0x0,0x15337(%rip)        # 23738 <fwp_timers>
    e400:	00 
    e401:	0f 85 49 53 ff ff    	jne    3750 <fwp_main_thread.cold>
    e407:	8b 1d 1f 4d 01 00    	mov    0x14d1f(%rip),%ebx        # 2312c <fwp_stack_pool_n>
    e40d:	85 db                	test   %ebx,%ebx
    e40f:	74 36                	je     e447 <fwp_main_thread+0x507>
    e411:	83 eb 01             	sub    $0x1,%ebx
    e414:	48 8d 05 25 4d 01 00 	lea    0x14d25(%rip),%rax        # 23140 <fwp_stack_pool>
    e41b:	48 63 d3             	movslq %ebx,%rdx
    e41e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e422:	eb 07                	jmp    e42b <fwp_main_thread+0x4eb>
    e424:	0f 1f 40 00          	nopl   0x0(%rax)
    e428:	83 eb 01             	sub    $0x1,%ebx
    e42b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e42f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e434:	89 1d f2 4c 01 00    	mov    %ebx,0x14cf2(%rip)        # 2312c <fwp_stack_pool_n>
    e43a:	48 83 ed 08          	sub    $0x8,%rbp
    e43e:	e8 9d 51 ff ff       	call   35e0 <munmap@plt>
    e443:	85 db                	test   %ebx,%ebx
    e445:	75 e1                	jne    e428 <fwp_main_thread+0x4e8>
    e447:	8b 3d d3 4b 00 00    	mov    0x4bd3(%rip),%edi        # 13020 <fwp_epfd>
    e44d:	85 ff                	test   %edi,%edi
    e44f:	78 05                	js     e456 <fwp_main_thread+0x516>
    e451:	e8 7a 50 ff ff       	call   34d0 <close@plt>
    e456:	4c 8b 25 e3 4e 01 00 	mov    0x14ee3(%rip),%r12        # 23340 <fwp_nfdws>
    e45d:	48 8b 2d e4 4e 01 00 	mov    0x14ee4(%rip),%rbp        # 23348 <fwp_fdws>
    e464:	31 db                	xor    %ebx,%ebx
    e466:	c7 05 b0 4b 00 00 ff 	movl   $0xffffffff,0x4bb0(%rip)        # 13020 <fwp_epfd>
    e46d:	ff ff ff 
    e470:	4d 85 e4             	test   %r12,%r12
    e473:	74 38                	je     e4ad <fwp_main_thread+0x56d>
    e475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e47c:	00 00 00 00 
    e480:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e485:	48 85 ff             	test   %rdi,%rdi
    e488:	74 1a                	je     e4a4 <fwp_main_thread+0x564>
    e48a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e48e:	0f 85 bc 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e494:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e499:	0f 85 b1 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e49f:	e8 ac 70 ff ff       	call   5550 <fwp_mem_free>
    e4a4:	48 83 c3 01          	add    $0x1,%rbx
    e4a8:	4c 39 e3             	cmp    %r12,%rbx
    e4ab:	75 d3                	jne    e480 <fwp_main_thread+0x540>
    e4ad:	48 89 ef             	mov    %rbp,%rdi
    e4b0:	e8 9b 70 ff ff       	call   5550 <fwp_mem_free>
    e4b5:	48 8b 15 9c 52 01 00 	mov    0x1529c(%rip),%rdx        # 23758 <fwp_root>
    e4bc:	48 c7 05 81 4e 01 00 	movq   $0x0,0x14e81(%rip)        # 23348 <fwp_fdws>
    e4c3:	00 00 00 00 
    e4c7:	48 c7 05 6e 4e 01 00 	movq   $0x0,0x14e6e(%rip)        # 23340 <fwp_nfdws>
    e4ce:	00 00 00 00 
    e4d2:	48 85 d2             	test   %rdx,%rdx
    e4d5:	74 4e                	je     e525 <fwp_main_thread+0x5e5>
    e4d7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e4dc:	0f 85 6e 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4e2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e4e9:	00 
    e4ea:	0f 85 60 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4f0:	48 83 3d 00 6f 01 00 	cmpq   $0x0,0x16f00(%rip)        # 253f8 <fwp_state_len>
    e4f7:	00 
    e4f8:	0f 85 52 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4fe:	48 83 3d e2 6e 01 00 	cmpq   $0x0,0x16ee2(%rip)        # 253e8 <fwp_state_owners>
    e505:	00 
    e506:	0f 85 44 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e50c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e511:	31 c0                	xor    %eax,%eax
    e513:	48 8d 3d 46 4e 01 00 	lea    0x14e46(%rip),%rdi        # 23360 <fwp_root_context>
    e51a:	f3 48 ab             	rep stos %rax,(%rdi)
    e51d:	48 89 d7             	mov    %rdx,%rdi
    e520:	e8 2b 70 ff ff       	call   5550 <fwp_mem_free>
    e525:	48 8b 3d 14 4b 00 00 	mov    0x4b14(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e52c:	48 c7 05 29 52 01 00 	movq   $0x0,0x15229(%rip)        # 23760 <fwp_cur>
    e533:	00 00 00 00 
    e537:	48 c7 05 16 52 01 00 	movq   $0x0,0x15216(%rip)        # 23758 <fwp_root>
    e53e:	00 00 00 00 
    e542:	e8 79 50 ff ff       	call   35c0 <fflush@plt>
    e547:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e54e:	00 
    e54f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e556:	00 00 
    e558:	0f 85 be 00 00 00    	jne    e61c <fwp_main_thread+0x6dc>
    e55e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e565:	31 c0                	xor    %eax,%eax
    e567:	5b                   	pop    %rbx
    e568:	5d                   	pop    %rbp
    e569:	41 5c                	pop    %r12
    e56b:	c3                   	ret
    e56c:	0f 1f 40 00          	nopl   0x0(%rax)
    e570:	48 89 05 c1 51 01 00 	mov    %rax,0x151c1(%rip)        # 23738 <fwp_timers>
    e577:	e9 01 fc ff ff       	jmp    e17d <fwp_main_thread+0x23d>
    e57c:	0f 1f 40 00          	nopl   0x0(%rax)
    e580:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e584:	0f 85 66 fd ff ff    	jne    e2f0 <fwp_main_thread+0x3b0>
    e58a:	48 89 ef             	mov    %rbp,%rdi
    e58d:	e8 1e 5b ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e592:	e9 59 fd ff ff       	jmp    e2f0 <fwp_main_thread+0x3b0>
    e597:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e59e:	00 00 
    e5a0:	e8 9b cc ff ff       	call   b240 <f0>
    e5a5:	48 c7 05 d8 4a 00 00 	movq   $0x0,0x4ad8(%rip)        # 13088 <v.2>
    e5ac:	00 00 00 00 
    e5b0:	c7 05 d6 4a 00 00 01 	movl   $0x1,0x4ad6(%rip)        # 13090 <st.3>
    e5b7:	00 00 00 
    e5ba:	e9 7f fa ff ff       	jmp    e03e <fwp_main_thread+0xfe>
    e5bf:	90                   	nop
    e5c0:	48 8d 3d 59 64 ff ff 	lea    -0x9ba7(%rip),%rdi        # 4a20 <fwp_heap_report>
    e5c7:	e8 84 02 00 00       	call   e850 <atexit>
    e5cc:	e9 ad f9 ff ff       	jmp    df7e <fwp_main_thread+0x3e>
    e5d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e5d8:	e8 53 65 ff ff       	call   4b30 <fwp_heap_init>
    e5dd:	e9 8e f9 ff ff       	jmp    df70 <fwp_main_thread+0x30>
    e5e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e5e8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e5ec:	e9 01 fb ff ff       	jmp    e0f2 <fwp_main_thread+0x1b2>
    e5f1:	48 83 3d 5f 51 01 00 	cmpq   $0x0,0x1515f(%rip)        # 23758 <fwp_root>
    e5f8:	00 
    e5f9:	c7 05 9d 4a 01 00 00 	movl   $0x0,0x14a9d(%rip)        # 230a0 <fwp_exit_code>
    e600:	00 00 00 
    e603:	0f 84 dd fd ff ff    	je     e3e6 <fwp_main_thread+0x4a6>
    e609:	e9 42 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e60e:	66 90                	xchg   %ax,%ax
    e610:	48 8d 3d d9 12 00 00 	lea    0x12d9(%rip),%rdi        # f8f0 <_IO_stdin_used+0x8f0>
    e617:	e8 84 5b ff ff       	call   41a0 <fwp_trap>
    e61c:	e8 3f 4e ff ff       	call   3460 <__stack_chk_fail@plt>
    e621:	48 89 c8             	mov    %rcx,%rax
    e624:	e9 00 fd ff ff       	jmp    e329 <fwp_main_thread+0x3e9>
    e629:	e9 22 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e62e:	e9 1d 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e633:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e63a:	00 00 00 
    e63d:	0f 1f 00             	nopl   (%rax)

000000000000e640 <__divmodti4>:
    e640:	f3 0f 1e fa          	endbr64
    e644:	55                   	push   %rbp
    e645:	49 89 f1             	mov    %rsi,%r9
    e648:	49 89 d2             	mov    %rdx,%r10
    e64b:	48 89 fe             	mov    %rdi,%rsi
    e64e:	49 89 cb             	mov    %rcx,%r11
    e651:	48 89 e5             	mov    %rsp,%rbp
    e654:	41 57                	push   %r15
    e656:	41 56                	push   %r14
    e658:	41 55                	push   %r13
    e65a:	41 54                	push   %r12
    e65c:	53                   	push   %rbx
    e65d:	4c 89 c3             	mov    %r8,%rbx
    e660:	45 31 c0             	xor    %r8d,%r8d
    e663:	4d 85 c9             	test   %r9,%r9
    e666:	79 12                	jns    e67a <__divmodti4+0x3a>
    e668:	31 ff                	xor    %edi,%edi
    e66a:	48 f7 de             	neg    %rsi
    e66d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e674:	4c 19 cf             	sbb    %r9,%rdi
    e677:	49 89 f9             	mov    %rdi,%r9
    e67a:	4c 89 d8             	mov    %r11,%rax
    e67d:	4d 85 db             	test   %r11,%r11
    e680:	0f 88 1a 01 00 00    	js     e7a0 <__divmodti4+0x160>
    e686:	4c 89 d9             	mov    %r11,%rcx
    e689:	49 89 f3             	mov    %rsi,%r11
    e68c:	75 62                	jne    e6f0 <__divmodti4+0xb0>
    e68e:	4d 89 c4             	mov    %r8,%r12
    e691:	4d 39 d1             	cmp    %r10,%r9
    e694:	0f 83 46 01 00 00    	jae    e7e0 <__divmodti4+0x1a0>
    e69a:	4c 89 d8             	mov    %r11,%rax
    e69d:	4c 89 ca             	mov    %r9,%rdx
    e6a0:	49 f7 f2             	div    %r10
    e6a3:	49 89 c3             	mov    %rax,%r11
    e6a6:	31 c0                	xor    %eax,%eax
    e6a8:	48 89 d6             	mov    %rdx,%rsi
    e6ab:	31 ff                	xor    %edi,%edi
    e6ad:	4c 89 d9             	mov    %r11,%rcx
    e6b0:	48 89 c2             	mov    %rax,%rdx
    e6b3:	48 89 c8             	mov    %rcx,%rax
    e6b6:	4d 85 e4             	test   %r12,%r12
    e6b9:	74 0a                	je     e6c5 <__divmodti4+0x85>
    e6bb:	48 f7 d8             	neg    %rax
    e6be:	48 83 d2 00          	adc    $0x0,%rdx
    e6c2:	48 f7 da             	neg    %rdx
    e6c5:	4d 85 c0             	test   %r8,%r8
    e6c8:	74 0a                	je     e6d4 <__divmodti4+0x94>
    e6ca:	48 f7 de             	neg    %rsi
    e6cd:	48 83 d7 00          	adc    $0x0,%rdi
    e6d1:	48 f7 df             	neg    %rdi
    e6d4:	48 89 33             	mov    %rsi,(%rbx)
    e6d7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e6db:	5b                   	pop    %rbx
    e6dc:	41 5c                	pop    %r12
    e6de:	41 5d                	pop    %r13
    e6e0:	41 5e                	pop    %r14
    e6e2:	41 5f                	pop    %r15
    e6e4:	5d                   	pop    %rbp
    e6e5:	c3                   	ret
    e6e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e6ed:	00 00 00 
    e6f0:	4d 89 c4             	mov    %r8,%r12
    e6f3:	49 39 c1             	cmp    %rax,%r9
    e6f6:	0f 82 ce 00 00 00    	jb     e7ca <__divmodti4+0x18a>
    e6fc:	31 ff                	xor    %edi,%edi
    e6fe:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e703:	48 63 c7             	movslq %edi,%rax
    e706:	be 40 00 00 00       	mov    $0x40,%esi
    e70b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e710:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e715:	48 29 c6             	sub    %rax,%rsi
    e718:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e71d:	48 09 c8             	or     %rcx,%rax
    e720:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e725:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e72a:	49 89 c6             	mov    %rax,%r14
    e72d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e731:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e736:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e73b:	49 09 c1             	or     %rax,%r9
    e73e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e742:	4c 89 c8             	mov    %r9,%rax
    e745:	49 f7 f6             	div    %r14
    e748:	48 89 d1             	mov    %rdx,%rcx
    e74b:	49 89 c3             	mov    %rax,%r11
    e74e:	49 89 c1             	mov    %rax,%r9
    e751:	49 f7 e2             	mul    %r10
    e754:	49 89 c6             	mov    %rax,%r14
    e757:	49 89 d2             	mov    %rdx,%r10
    e75a:	48 39 d1             	cmp    %rdx,%rcx
    e75d:	72 07                	jb     e766 <__divmodti4+0x126>
    e75f:	75 17                	jne    e778 <__divmodti4+0x138>
    e761:	49 39 c7             	cmp    %rax,%r15
    e764:	73 12                	jae    e778 <__divmodti4+0x138>
    e766:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e76a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e76e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e772:	49 89 d2             	mov    %rdx,%r10
    e775:	49 89 c6             	mov    %rax,%r14
    e778:	4c 89 f8             	mov    %r15,%rax
    e77b:	4c 29 f0             	sub    %r14,%rax
    e77e:	4c 19 d1             	sbb    %r10,%rcx
    e781:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e786:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e78b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e790:	48 09 c6             	or     %rax,%rsi
    e793:	48 89 cf             	mov    %rcx,%rdi
    e796:	31 c0                	xor    %eax,%eax
    e798:	4c 89 c9             	mov    %r9,%rcx
    e79b:	e9 10 ff ff ff       	jmp    e6b0 <__divmodti4+0x70>
    e7a0:	4c 89 d0             	mov    %r10,%rax
    e7a3:	4c 89 da             	mov    %r11,%rdx
    e7a6:	4d 89 c4             	mov    %r8,%r12
    e7a9:	49 89 f3             	mov    %rsi,%r11
    e7ac:	48 f7 d8             	neg    %rax
    e7af:	49 f7 d4             	not    %r12
    e7b2:	48 83 d2 00          	adc    $0x0,%rdx
    e7b6:	49 89 c2             	mov    %rax,%r10
    e7b9:	48 f7 da             	neg    %rdx
    e7bc:	48 89 d1             	mov    %rdx,%rcx
    e7bf:	0f 84 cc fe ff ff    	je     e691 <__divmodti4+0x51>
    e7c5:	49 39 d1             	cmp    %rdx,%r9
    e7c8:	73 46                	jae    e810 <__divmodti4+0x1d0>
    e7ca:	4c 89 cf             	mov    %r9,%rdi
    e7cd:	31 c0                	xor    %eax,%eax
    e7cf:	31 c9                	xor    %ecx,%ecx
    e7d1:	e9 da fe ff ff       	jmp    e6b0 <__divmodti4+0x70>
    e7d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e7dd:	00 00 00 
    e7e0:	4d 85 d2             	test   %r10,%r10
    e7e3:	75 0d                	jne    e7f2 <__divmodti4+0x1b2>
    e7e5:	b8 01 00 00 00       	mov    $0x1,%eax
    e7ea:	31 d2                	xor    %edx,%edx
    e7ec:	49 f7 f2             	div    %r10
    e7ef:	49 89 c2             	mov    %rax,%r10
    e7f2:	4c 89 c8             	mov    %r9,%rax
    e7f5:	31 d2                	xor    %edx,%edx
    e7f7:	49 f7 f2             	div    %r10
    e7fa:	49 89 c1             	mov    %rax,%r9
    e7fd:	4c 89 d8             	mov    %r11,%rax
    e800:	49 f7 f2             	div    %r10
    e803:	49 89 c3             	mov    %rax,%r11
    e806:	4c 89 c8             	mov    %r9,%rax
    e809:	e9 9a fe ff ff       	jmp    e6a8 <__divmodti4+0x68>
    e80e:	66 90                	xchg   %ax,%ax
    e810:	45 31 f6             	xor    %r14d,%r14d
    e813:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e818:	44 89 f7             	mov    %r14d,%edi
    e81b:	45 85 f6             	test   %r14d,%r14d
    e81e:	0f 85 df fe ff ff    	jne    e703 <__divmodti4+0xc3>
    e824:	4c 39 ca             	cmp    %r9,%rdx
    e827:	72 17                	jb     e840 <__divmodti4+0x200>
    e829:	31 c9                	xor    %ecx,%ecx
    e82b:	48 39 c6             	cmp    %rax,%rsi
    e82e:	73 10                	jae    e840 <__divmodti4+0x200>
    e830:	4c 89 cf             	mov    %r9,%rdi
    e833:	31 c0                	xor    %eax,%eax
    e835:	e9 76 fe ff ff       	jmp    e6b0 <__divmodti4+0x70>
    e83a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e840:	4c 89 de             	mov    %r11,%rsi
    e843:	b9 01 00 00 00       	mov    $0x1,%ecx
    e848:	48 29 c6             	sub    %rax,%rsi
    e84b:	49 19 d1             	sbb    %rdx,%r9
    e84e:	eb e0                	jmp    e830 <__divmodti4+0x1f0>

000000000000e850 <atexit>:
    e850:	f3 0f 1e fa          	endbr64
    e854:	48 8b 15 ad 47 00 00 	mov    0x47ad(%rip),%rdx        # 13008 <__dso_handle>
    e85b:	31 f6                	xor    %esi,%esi
    e85d:	e9 fe 4d ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e864 <_fini>:
    e864:	f3 0f 1e fa          	endbr64
    e868:	48 83 ec 08          	sub    $0x8,%rsp
    e86c:	48 83 c4 08          	add    $0x8,%rsp
    e870:	c3                   	ret
